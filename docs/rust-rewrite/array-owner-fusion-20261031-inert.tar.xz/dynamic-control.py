import importlib.util,json,statistics
from pathlib import Path
p=Path(__file__).with_name('cohort.py');spec=importlib.util.spec_from_file_location('cohort',p);c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
order=['baseline','candidate','candidate','baseline','candidate','baseline','baseline','candidate']
c.save(c.OUT/'dynamic-control-resources-before.json',c.resources())
for index,label in enumerate(order):
 directory=c.OUT/f'dynamic-control-r{index}-wasm';directory.mkdir()
 for name in (['dynamic-string-4096.js','integer.js'] if index%2==0 else ['integer.js','dynamic-string-4096.js']):
  c.invoke(f'dynamic-control-r{index}-{label}-{name}',[c.runner(label),c.FIX,'21','10',name,directory])
rows=[]
for name in ('dynamic-string-4096.js','integer.js'):
 products={}
 for label in ('baseline','candidate'):
  observations=[];rounds=[]
  for i,l in enumerate(order):
   if l!=label:continue
   stem=f'dynamic-control-r{i}-{label}-{name}';v=json.loads((c.OUT/(stem+'.stdout')).read_text());case=v['cases'][0]
   expected=next(x['stdout'] for x in c.PLAN['execution'] if x['file']==name)
   assert case['source_sha256']==c.digest(c.FIX/name) and all(o['stdout']==expected for o in case['observations'])
   values=[o['execution_ns'] for o in case['observations'] if not o['warmup']];assert len(values)==21
   observations+=values;rounds.append(dict(index=i,median_ns=statistics.median(values),mean_ns=statistics.mean(values),raw=stem+'.stdout'))
  products[label]=dict(median_ns=statistics.median(observations),mean_ns=statistics.mean(observations),rounds=rounds)
 rows.append(dict(file=name,products=products,median_change_percent=100*(products['candidate']['median_ns']/products['baseline']['median_ns']-1),mean_change_percent=100*(products['candidate']['mean_ns']/products['baseline']['mean_ns']-1)))
c.save(c.OUT/'dynamic-control-analysis.json',dict(order=order,samples=21,warmups=10,workloads=rows,scope='Additional ordinary-only balanced control to resolve borderline pooled dynamic-string differences; all earlier results retained.'))
c.save(c.OUT/'dynamic-control-resources-after.json',c.resources())
for row in rows:print(row['file'],row['median_change_percent'],row['mean_change_percent'],flush=True)
