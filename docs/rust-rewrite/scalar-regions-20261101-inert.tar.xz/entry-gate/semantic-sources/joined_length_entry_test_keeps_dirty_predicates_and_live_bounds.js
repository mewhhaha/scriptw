
function dirty(a, steps) {
  'use strict';var total=0;
  for(var i=0;i++<steps;i++)total+=a.join(',').length;
  return [total,i];
}
function shrink(a, limit) {
  'use strict';var total=0;
  for(var i=0;i<limit;i++){total+=a.join(',').length;limit=0;}
  return [total,i,limit];
}
function joined(a, steps) {
  'use strict';var total=-0;
  for(var i=0;i<steps;i++)total+=a.join(',').length;
  return [total,i];
}
var zero=dirty(['x','y'],0), twice=dirty(['x','y'],4);
var reduced=shrink(['x','y'],4), nan=shrink(['x','y'],NaN);
var hits=0, coerced=joined(['x','y'],{valueOf(){hits++;return 2;}});
var events=0, receiver=[];
Object.defineProperty(receiver,'join',{get(){events++;throw 'unused getter';}});
var untouched=joined(receiver,-0), notANumber=joined(receiver,NaN);
zero[0]===0 && zero[1]===1 && twice[0]===6 && twice[1]===5 &&
reduced[0]===3 && reduced[1]===1 && reduced[2]===0 &&
nan[0]===0 && nan[1]===0 && Number.isNaN(nan[2]) &&
coerced[0]===6 && coerced[1]===2 && hits===3 && events===0 &&
Object.is(untouched[0],-0) && untouched[1]===0 && Object.is(notANumber[0],-0);
