"""Ignored, source-bound paired runner for a separate join-boundary study.

Run only after an explicit measurement go-ahead, inside limited_verification.
This file intentionally has no default run action.
"""
from pathlib import Path
import argparse
import datetime
import json
import os
import statistics
import subprocess
import sys

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
PRODUCTS = OUT.parent
sys.path.insert(0, str(ROOT / "scripts"))
from benchmark_metrics import digest, measure_process
from limited_verification import kernel_group, require_kernel_budget

CORPUS = OUT / "corpus"
SORTS = []
BOUNDARIES = [f"join-boundary-{n}-trip{trips}.js" for n in (256, 257, 4096) for trips in (0, 1)]
JOIN_CONTROLS = ["join-empty-1024.js", "join-singleton-1024.js", "join-small-1024.js"]
TARGETS = JOIN_CONTROLS
CONTROLS = BOUNDARIES + ["retained-objects.js"]
SCREEN = TARGETS + CONTROLS
AA_CASES = SCREEN
SCHEDULES = [
    ("block0", ["baseline", "candidate", "candidate", "baseline",
        "candidate", "baseline", "baseline", "candidate"]),
    ("block1", ["candidate", "baseline", "baseline", "candidate",
        "baseline", "candidate", "candidate", "baseline"]),
]
POLICY_FIELDS = ["memory.max", "memory.swap.max", "memory.oom.group", "cpu.max", "memory.events"]
CACHE_LIMIT_BYTES = 1024 * 1024 * 1024


def load(path):
    return json.loads(Path(path).read_text())


def save_new(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")


def check_corpus():
    record = load(OUT / "corpus.json")
    manifest = CORPUS / "manifest.json"
    assert digest(manifest) == record["manifest_sha256"], "join-boundary manifest changed"
    for name, expected in record["files_sha256"].items():
        assert digest(CORPUS / name) == expected, f"join-boundary workload changed: {name}"
    return record["manifest"]


def check_product(label):
    product_dir = PRODUCTS / label
    # products.json is the untouched frozen source record; host-products.json
    # names only the independently copied executables used by this cohort.
    all_rows = load(product_dir / "products.json")
    rows = load(product_dir / "host-products.json")
    for name, row in rows.items():
        path = product_dir / name
        assert path.is_file() and not path.is_symlink(), f"missing regular product: {path}"
        assert path.stat().st_nlink == 1, f"product is not an independent copy: {path}"
        assert digest(path) == row["sha256"], f"product hash mismatch: {path}"
    identity = load(product_dir / "identity.json")
    assert identity["executable_sha256"] == all_rows["compiler_precompiled_baseline"]["sha256"]
    assert "runtime_baseline" in rows
    return dict(source_commit=identity["source_commit"],
        source_fingerprint=identity["source_fingerprint"],
        compiler_identity_scheme=identity["compiler_identity_scheme"],
        executed_host="runtime_baseline",
        executed_host_sha256=rows["runtime_baseline"]["sha256"],
        host_report_schema="scriptw-wasmtime-baseline-v2",
        requested_native_policy=None)


def invoke(run_dir, stem, argv, expected_exit=0):
    raw = run_dir / "raw"
    raw.mkdir(exist_ok=True)
    group = kernel_group()
    before = {name: (group / name).read_text() for name in POLICY_FIELDS}
    env = dict(os.environ)
    if env.get("NODE_OPTIONS"):
        raise ValueError("NODE_OPTIONS must be unset for comparable benchmark execution")
    env.pop("NODE_COMPILE_CACHE", None)
    env["NODE_DISABLE_COMPILE_CACHE"] = "1"
    env["SCRIPTW_CACHE_DIR"] = str(OUT / "cache")
    env["SCRIPTW_CACHE_LIMIT_BYTES"] = str(CACHE_LIMIT_BYTES)
    (OUT / "cache").mkdir(exist_ok=True)
    time_binary = OUT / "tools-time"
    with (raw / f"{stem}.stdout").open("xb") as stdout, (raw / f"{stem}.stderr").open("xb") as stderr:
        result = measure_process(list(map(str, argv)), cwd=ROOT, env=env,
            stdout=stdout, stderr=stderr, timeout=900, time_binary=time_binary)
    after = {name: (group / name).read_text() for name in POLICY_FIELDS}
    result.update(argv=list(map(str, argv)), affinity=sorted(os.sched_getaffinity(0)),
        resources_before=before, resources_after=after)
    save_new(raw / f"{stem}.command.json", result)
    assert all(before[name] == after[name] for name in POLICY_FIELDS if name != "memory.events"), "resource policy changed"
    old_events = dict(line.split() for line in before["memory.events"].splitlines())
    new_events = dict(line.split() for line in after["memory.events"].splitlines())
    assert all(old_events[key] == new_events[key] for key in ("oom", "oom_kill", "oom_group_kill")), "OOM event; receipts retained"
    assert result["exit_code"] == expected_exit and not result["timed_out"], f"process failed: {stem}"
    return result


def cache_metadata():
    cache = OUT / "cache"
    cache.mkdir(exist_ok=True)
    filesystem = subprocess.check_output(["stat", "-f", "-c", "%T", str(cache)], text=True).strip()
    return dict(path=str(cache), filesystem=filesystem,
        limit_bytes=CACHE_LIMIT_BYTES)


def verify_observations(run_dir, stem, product, case, samples, warmups):
    report = load(run_dir / "raw" / f"{stem}.stdout")
    identity = check_product(product)
    assert report["source_fingerprint"] == identity["source_fingerprint"], f"wrong compiler identity: {stem}"
    assert report["source_commit"] == identity["source_commit"], f"wrong source commit: {stem}"
    assert report["executable_sha256"] == identity["executed_host_sha256"], f"wrong executed host: {stem}"
    assert report["schema"] == identity["host_report_schema"], f"unexpected report schema: {stem}"
    assert report["requested_native_policy"] is None, f"unexpected native policy: {stem}"
    observations = report["cases"][0]["observations"]
    assert len(observations) == samples + warmups, f"incomplete rows: {stem}"
    assert all(row["stdout"] == case["stdout"] for row in observations), f"output mismatch: {stem}"
    times = [row["execution_ns"] for row in observations if not row["warmup"]]
    assert len(times) == samples
    return times


def run_paired(action, profile, samples, warmups):
    if action == "aa":
        products = ["baseline", "baseline-aa"]
        cases = AA_CASES
    else:
        products = ["baseline", "candidate"]
        cases = SCREEN if profile == "screen" else [row["file"] for row in check_corpus()["execution"]]
        assert (OUT / "aa-analysis.json").is_file(), "run and inspect the A/A block before candidate scoring"
        aa = load(OUT / "aa-analysis.json")
        assert aa["status"] == "complete", "A/A block is incomplete"
    manifest = check_corpus()
    cases_by_name = {row["file"]: row for row in manifest["execution"]}
    for product in products:
        check_product(product)

    run_id = datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%dT%H%M%SZ") + f"-{action}-{profile}"
    run_dir = OUT / "runs" / run_id
    run_dir.mkdir(parents=True, exist_ok=False)
    plan = dict(action=action, profile=profile, samples=samples, warmups=warmups,
        cases=cases, schedules=[dict(block=block, order=order) for block, order in SCHEDULES],
        product_identities={name: check_product(name) for name in products},
        corpus_sha256=load(OUT / "corpus.json")["manifest_sha256"],
        cache=cache_metadata(),
        resource_policy=dict(memory_bytes=4096 * 1024 * 1024, swap_bytes=0,
            affinity=sorted(os.sched_getaffinity(0)), cgroup=str(kernel_group()),
            module_cache_entries=os.environ.get("SCRIPTW_MODULE_MEMORY_CACHE_ENTRIES"),
            module_cache_bytes=os.environ.get("SCRIPTW_MODULE_MEMORY_CACHE_LIMIT_BYTES")),
        process_accounting=dict(supervisor=str(OUT / "tools-time"), supervisor_sha256=digest(OUT / "tools-time")),
        gate=dict(unit="process invocation", block_median="median of four invocation medians",
            block_mean="mean of four invocation means",
            target_requirement="all three canonical join target block medians improve in both blocks",
            control_veto="any boundary or retained-objects control with >=3% slowdown in both block metrics in both blocks",
            a_a="review all ten A/A cases before candidate scoring; retain all observations"))
    save_new(run_dir / "plan.json", plan)

    raw_rows = []
    for case_index, name in enumerate(cases):
        case = cases_by_name[name]
        for block_index, (block, order) in enumerate(SCHEDULES):
            if action == "aa":
                order = ["baseline" if label == "baseline" else "baseline-aa" for label in order]
            for round_index, product in enumerate(order):
                stem = f"{block}-case{case_index:02}-{round_index}-{product}-{name}"
                artifact_dir = run_dir / "artifacts" / stem
                artifact_dir.mkdir(parents=True, exist_ok=False)
                host = PRODUCTS / product / "runtime_baseline"
                argv = [host, CORPUS, str(samples), str(warmups), name, artifact_dir]
                event = invoke(run_dir, stem, argv)
                times = verify_observations(run_dir, stem, product, case, samples, warmups)
                raw_rows.append(dict(block=block, case=name, product=product,
                    round=round_index, times_ns=times,
                    invocation_median_ns=statistics.median(times),
                    invocation_mean_ns=statistics.mean(times),
                    process_elapsed_ns=event["elapsed_ns"], raw=stem))
    report = summarize(action, profile, samples, warmups, raw_rows, cases, run_dir)
    save_new(run_dir / "analysis.json", report)
    if action == "aa":
        save_new(OUT / "aa-analysis.json", dict(status="complete", run_id=run_id,
            analysis=str((run_dir / "analysis.json").relative_to(OUT)), comparisons=report["comparisons"]))
    print(run_dir)


def summarize(action, profile, samples, warmups, rows, cases, run_dir):
    comparisons = []
    controls = set(cases) - set(TARGETS)
    vetoed_controls = []
    controls_vetoed_in_both_blocks = []
    targets_not_improved_both_blocks = []
    for name in cases:
        item = dict(case=name, control=name in controls, blocks=[])
        for block, _ in SCHEDULES:
            by_product = {}
            for product in ("baseline", "baseline-aa") if action == "aa" else ("baseline", "candidate"):
                selected = [row for row in rows if row["case"] == name and row["block"] == block and row["product"] == product]
                values = [n for row in selected for n in row["times_ns"]]
                process_medians = [row["invocation_median_ns"] for row in selected]
                process_means = [row["invocation_mean_ns"] for row in selected]
                by_product[product] = dict(
                    invocation_count=len(selected), sample_count=len(values),
                    block_median_of_invocation_medians_ns=statistics.median(process_medians),
                    block_mean_of_invocation_means_ns=statistics.mean(process_means),
                    pooled_sample_median_ns=statistics.median(values),
                    pooled_sample_mean_ns=statistics.mean(values),
                    invocations=[dict(raw=row["raw"], median_ns=row["invocation_median_ns"],
                        mean_ns=row["invocation_mean_ns"], process_elapsed_ns=row["process_elapsed_ns"])
                        for row in selected])
            labels = list(by_product)
            changes = {
                "block_median_of_invocation_medians_percent": 100 * (
                    by_product[labels[1]]["block_median_of_invocation_medians_ns"] /
                    by_product[labels[0]]["block_median_of_invocation_medians_ns"] - 1),
                "block_mean_of_invocation_means_percent": 100 * (
                    by_product[labels[1]]["block_mean_of_invocation_means_ns"] /
                    by_product[labels[0]]["block_mean_of_invocation_means_ns"] - 1),
                "pooled_sample_median_percent": 100 * (
                    by_product[labels[1]]["pooled_sample_median_ns"] /
                    by_product[labels[0]]["pooled_sample_median_ns"] - 1),
                "pooled_sample_mean_percent": 100 * (
                    by_product[labels[1]]["pooled_sample_mean_ns"] /
                    by_product[labels[0]]["pooled_sample_mean_ns"] - 1),
            }
            item["blocks"].append(dict(block=block, products=by_product, change_percent=changes))
            if name in controls and changes["block_median_of_invocation_medians_percent"] >= 3 and changes["block_mean_of_invocation_means_percent"] >= 3:
                vetoed_controls.append(dict(case=name, block=block,
                    median_slowdown_percent=changes["block_median_of_invocation_medians_percent"],
                    mean_slowdown_percent=changes["block_mean_of_invocation_means_percent"]))
        comparisons.append(item)
    for name in controls:
        rows_for_case = next(row for row in comparisons if row["case"] == name)
        if all(block["change_percent"]["block_median_of_invocation_medians_percent"] >= 3
                and block["change_percent"]["block_mean_of_invocation_means_percent"] >= 3
                for block in rows_for_case["blocks"]):
            controls_vetoed_in_both_blocks.append(name)
    if action != "aa":
        for name in set(cases) & set(TARGETS):
            row = next(row for row in comparisons if row["case"] == name)
            if not all(block["change_percent"]["block_median_of_invocation_medians_percent"] < 0
                    for block in row["blocks"]):
                targets_not_improved_both_blocks.append(name)
    return dict(status="complete", action=action, profile=profile, samples_per_invocation=samples,
        warmups_per_invocation=warmups, cases=cases, rows=rows, comparisons=comparisons,
        control_veto=">=3% median AND mean slowdown in both blocks",
        vetoed_control_blocks=vetoed_controls,
        controls_vetoed_in_both_blocks=sorted(controls_vetoed_in_both_blocks),
        experimental_unit="independent host process invocation; block gate uses the median of four invocation medians and mean of four invocation means; pooled 21-sample summaries are descriptive",
        target_rule="all three canonical join target cases must show median improvement in both blocks",
        targets_not_improved_both_blocks=sorted(targets_not_improved_both_blocks),
        raw_directory=str((run_dir / "raw").relative_to(OUT)))


def main():
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="action", required=True)
    sub.add_parser("verify-setup", help="read-only hashes and resource preflight")
    aa = sub.add_parser("aa", help="baseline-versus-identical-copy A/A controls")
    aa.add_argument("--samples", type=int, default=21)
    aa.add_argument("--warmups", type=int, default=10)
    run = sub.add_parser("run", help="paired frozen baseline/candidate measurement")
    run.add_argument("--profile", choices=("screen", "full17"), default="screen")
    run.add_argument("--samples", type=int, default=21)
    run.add_argument("--warmups", type=int, default=10)
    args = parser.parse_args()
    if os.environ.get("NODE_OPTIONS"):
        parser.error("NODE_OPTIONS must be unset for comparable benchmark execution")
    require_kernel_budget(4096 * 1024 * 1024)
    check_corpus()
    check_product("baseline")
    assert (OUT / "tools-time").is_file() and os.access(OUT / "tools-time", os.X_OK)
    if args.action == "verify-setup":
        print(json.dumps(dict(status="ready", baseline=check_product("baseline"),
            corpus=load(OUT / "corpus.json")["manifest_sha256"],
            time_binary=digest(OUT / "tools-time"), affinity=sorted(os.sched_getaffinity(0))), indent=2))
    elif args.action == "aa":
        check_product("baseline-aa")
        if args.samples != 21 or args.warmups != 10:
            parser.error("A/A is predeclared at exactly 21 samples and 10 warmups")
        run_paired("aa", "controls12", args.samples, args.warmups)
    else:
        if args.samples != 21 or args.warmups != 10:
            parser.error("use exactly 21 samples and 10 warmups")
        run_paired("candidate", args.profile, args.samples, args.warmups)


if __name__ == "__main__":
    main()
