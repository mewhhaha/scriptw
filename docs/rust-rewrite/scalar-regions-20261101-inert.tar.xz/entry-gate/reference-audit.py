import json,statistics,hashlib,collections,subprocess
from pathlib import Path
b=Path('target/performance-scalar-regions-entry-gate');x=json.loads((b/'reference-analysis.json').read_text());manifest=json.loads((b/'sources/manifest.json').read_text());expected={c['file']:c['stdout'] for c in manifest['execution']};assert len(expected)==17
fp={'baseline':'a35adbcb61dbc57b4ee44dd1527019358deb137b11ae559de7d0d4b4a860b480','candidate':'ce4d1397299c945cffdc9ec80de0cb96c146fc4d7e83e63d24c437de6fea764b'}
hosts={'baseline':'4a882ea53d5de4b762571c22cb6efe0957a6e3a1783f7ed832bc5188316214e1','candidate':'7d88201ade1af7dcd6cb9878d38708ef3d7a4bbbe1af97ea95438dab410c6a31'}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def resource(c):
 assert c['exit_code']==0 and not c['timed_out'] and c['affinity']==[0]
 for phase in ['resources_before','resources_after']:
  r=c[phase];assert r['memory.max'].strip()=='4294967296' and r['memory.swap.max'].strip()=='0' and r['memory.oom.group'].strip()=='1';assert all(int(v.split()[1])==0 for v in r['memory.events'].splitlines())
scriptc_hashes={};source_hashes={};adapter=b'function print(value) { console.log(String(value)); }\n'
for name,c in x['compilation'].items():
 resource(c['compile']);assert c['compile']==json.loads((b/'raw'/('reference-compile-'+name+'.command.json')).read_text());original=(b/'sources'/name).read_bytes();assert original==(Path('crates/scriptw-cli/tests/fixtures/v8_execution_hotpaths')/name).read_bytes();assert (b/'adapted-scriptc'/name).read_bytes()==adapter+original;source_hashes[name]=hashlib.sha256(original).hexdigest();assert (b/'expected'/name).read_text()==expected[name]
 p=b/'scriptc-wasm'/(name+'.wasm');scriptc_hashes[name]=sha(p);assert scriptc_hashes[name]==c['wasm_sha256'];assert c['compile']['argv'][-1]==str(p.resolve())
assert len(scriptc_hashes)==17
assert sha(b/'candidate/wasi_baseline')==x['tools']['wasi_host_sha256'];assert sha(b/'tools/scriptc/package-lock.json')==x['tools']['scriptc_package_lock_sha256']
for package in ['scriptc','@scriptc/runtime-wasm32-wasi','@scriptc/cli-linux-x64-gnu']:
 assert json.loads((b/'tools/scriptc/node_modules'/package/'package.json').read_text())['version']=='0.4.5'
assert subprocess.check_output(['node','--version'],text=True).strip()==x['tools']['node'];assert subprocess.check_output(['node','-p','process.versions.v8'],text=True).strip()==x['tools']['v8'];assert subprocess.check_output([str(b/'tools/zig-x86_64-linux-0.16.0/zig'),'version'],text=True).strip()==x['tools']['zig']
groups=collections.defaultdict(list);seen=set();P=collections.defaultdict(set);fullroot=b/'runs/20261101T022013Z-candidate-full17';full=json.loads((fullroot/'analysis.json').read_text());fullP={}
for r in full['rows']:
 k=(r['case'],r['product'])
 if k not in fullP:fullP[k]=json.loads((fullroot/'raw'/(r['raw']+'.stdout')).read_text())['cases'][0]['wasm_sha256']
for a in x['attempts']:
 assert a['status']=='ok';key=(a['file'],a['runtime'],a['round']);assert key not in seen;seen.add(key);name=a['file'];rt=a['runtime'];raw=b/'raw'/a['raw'];r=json.loads(raw.read_text());cmd=json.loads(raw.with_name(raw.name.removesuffix('.stdout')+'.command.json').read_text());resource(cmd);assert r['samples']==21 and r['warmups']==10
 if rt=='scriptc':
  assert r['schema']=='scriptw-wasi-baseline-v1' and r['wasmtime_version']=='47.0.0' and r['wasm_sha256']==scriptc_hashes[name];obs=r['observations'];assert all(o['matched'] and o['completion']=='normal' and o['stderr']=='' for o in obs)
 else:
  assert len(r['cases'])==1;c=r['cases'][0];assert c['file']==name and c['source_sha256']==source_hashes[name];obs=c['observations']
  if rt=='v8':assert r['schema']=='scriptw-v8-baseline-v2' and r['node']==x['tools']['node'] and r['v8']==x['tools']['v8']
  else:
   assert r['schema']=='scriptw-wasmtime-baseline-v2' and r['source_fingerprint']==fp[rt] and r['executable_sha256']==hosts[rt] and r['requested_native_policy'] is None;assert c['source_compilation_profile']=='portable';assert c['linked_runtime']['wasm_sha256']=='208535ae2c9885a9294774ccf82ffcc15e2f9296450feb4d1a7cac900eb93975';assert c['wasm_sha256']==fullP[(name,rt)]
   p=Path(cmd['argv'][-1])/(name+'.wasm');assert sha(p)==c['wasm_sha256'];P[(name,rt)].add(c['wasm_sha256'])
 assert len(obs)==31 and [o['warmup'] for o in obs]==[True]*10+[False]*21 and all(o['stdout']==expected[name] for o in obs)
 vals=[o['execution_ns'] for o in obs if not o['warmup']];assert vals==a['times_ns'];rss=[o['rss_after_bytes'] if rt=='scriptc' else o['memory']['after']['rss'] if rt=='v8' else o['memory']['process_rss']['final_rss_bytes'] for o in obs if not o['warmup']];assert rss==a['rss_bytes'];groups[(name,rt)].append({'round':a['round'],'median':statistics.median(vals),'mean':statistics.mean(vals),'values':vals})
assert len(seen)==136 and all(len(v)==2 for v in groups.values()) and len(groups)==68
print('VERIFIED136 successful attempts,2856 measured observations,1360 warmups,17 successfulScriptc compilations; all checksums/source/adapters/resources/artifacts/tools matched.')
print('tools',x['tools']);print('PRIMARY median of2 invocation medians, mean of2 invocation means; units us; CE/reference ratios below1 favorCE')
wins={'v8':[],'scriptc':[]};ambiguous=[]
for s in x['summary']:
 name=s['file'];primary={}
 for rt in ['baseline','candidate','v8','scriptc']:
  rows=groups[(name,rt)];flat=[v for r in rows for v in r['values']];assert statistics.median(flat)==s['runtimes'][rt]['median_ns'];assert abs(statistics.mean(flat)-s['runtimes'][rt]['mean_ns'])<1e-7
  primary[rt]=(statistics.median(r['median'] for r in rows),statistics.mean(r['mean'] for r in rows))
 for rt in wins:
  if primary['candidate'][0]<primary[rt][0]:wins[rt].append(name)
 print(name,'medians',','.join(rt+'='+format(primary[rt][0]/1000,'.3f') for rt in primary),'means',','.join(rt+'='+format(primary[rt][1]/1000,'.3f') for rt in primary),'ratios',','.join(rt+'='+format(primary['candidate'][0]/primary[rt][0],'.5f') for rt in ['v8','scriptc']))
 if name=='to-sorted-512.js':print('TOSORTED rounds',{rt:[(r['round'],r['median'],r['mean']) for r in groups[(name,rt)]] for rt in ['candidate','scriptc']},'primarygappercent',100*(primary['candidate'][0]/primary['scriptc'][0]-1),'pooledgappercent',100*(s['runtimes']['candidate']['median_ns']/s['runtimes']['scriptc']['median_ns']-1))
print('PRIMARY wins',wins)
