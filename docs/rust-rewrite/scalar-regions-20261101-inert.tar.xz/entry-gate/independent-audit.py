import json,statistics,collections,hashlib
from pathlib import Path
base=Path('target/performance-scalar-regions-entry-gate')
scopes=[('aa',base/'runs/20261101T020800Z-aa-controls12',base/'sources/manifest.json'),('boundary',base/'join-boundary/runs/20261101T021048Z-candidate-screen',base/'join-boundary/corpus/manifest.json'),('screen',base/'runs/20261101T021656Z-candidate-screen',base/'sources/manifest.json'),('full17',base/'runs/20261101T022013Z-candidate-full17',base/'sources/manifest.json'),('kernels',base/'kernels-run',base/'kernels/manifest.json')]
expected_fp={'baseline':'a35adbcb61dbc57b4ee44dd1527019358deb137b11ae559de7d0d4b4a860b480','baseline-aa':'a35adbcb61dbc57b4ee44dd1527019358deb137b11ae559de7d0d4b4a860b480','candidate':'ce4d1397299c945cffdc9ec80de0cb96c146fc4d7e83e63d24c437de6fea764b'}
expected_host={'baseline':'4a882ea53d5de4b762571c22cb6efe0957a6e3a1783f7ed832bc5188316214e1','baseline-aa':'4a882ea53d5de4b762571c22cb6efe0957a6e3a1783f7ed832bc5188316214e1','candidate':'7d88201ade1af7dcd6cb9878d38708ef3d7a4bbbe1af97ea95438dab410c6a31'}
rhash='208535ae2c9885a9294774ccf82ffcc15e2f9296450feb4d1a7cac900eb93975'
source_cache={};host_files={};cohort_results={};full={};all_p=collections.defaultdict(set);total_raw=0;maxrss=0;max_discrepancy=0

def sha(data):return hashlib.sha256(data).hexdigest()
def leb(b,p):
 n=s=0
 while True:
  v=b[p];p+=1;n|=(v&127)<<s
  if v<128:return n,p
  s+=7

def footprint(b):
 assert b[:8]==b'\x00asm\x01\x00\x00\x00';p=8
 while p<len(b):
  kind=b[p];p+=1;size,p=leb(b,p);end=p+size
  if kind==10:
   n,p=leb(b,p);sizes=[]
   for _ in range(n):
    length,p=leb(b,p);sizes.append(length);p+=length
   assert p==end
   return len(sizes),sum(sizes),max(sizes,default=0)
  p=end
 return 0,0,0

for label,root,manifest in scopes:
 a=json.loads((root/'analysis.json').read_text());plan=json.loads((root/'plan.json').read_text());expected={r['file']:r['stdout'] for r in json.loads(manifest.read_text())['execution']};groups=collections.defaultdict(list);orders=collections.defaultdict(list);seen=set();warm=0;artifact_count=0
 schedules={r['block']:r['order'] for r in plan['schedules']} if isinstance(plan['schedules'][0],dict) else dict(plan['schedules'])
 for row in a['rows']:
  assert row['raw'] not in seen;seen.add(row['raw']);raw=root/'raw'/row['raw'];x=json.loads(raw.with_name(raw.name+'.stdout').read_text());cmd=json.loads(raw.with_name(raw.name+'.command.json').read_text());product=row['product'];case=row['case'];block=row['block'];ordinal=row['round'] if 'round' in row else int(row['raw'].split('-')[1]);orders[(case,block)].append((ordinal,product))
  assert cmd['exit_code']==0 and not cmd['timed_out'];assert cmd['affinity']==[0];maxrss=max(maxrss,cmd['peak_rss_bytes']);assert cmd['peak_rss_bytes']<=4294967296
  for phase in ['resources_before','resources_after']:
   r=cmd[phase];assert r['memory.max'].strip()=='4294967296' and r['memory.swap.max'].strip()=='0' and r['memory.oom.group'].strip()=='1';assert all(int(line.split()[1])==0 for line in r['memory.events'].splitlines())
  argv=cmd['argv'];assert len(argv)==6 and Path(argv[0]).name=='runtime_baseline' and argv[2:5]==['21','10',case]
  assert x['schema']=='scriptw-wasmtime-baseline-v2' and x['requested_native_policy'] is None and x['samples']==21 and x['warmups']==10;assert x['source_fingerprint']==expected_fp[product] and x['executable_sha256']==expected_host[product]
  expected_commit='39b6f24ac1eb01e0a1cd59907699810b81cf8900' if product=='candidate' else 'ae07c2921d34b65f09e2458ed577bad9a03ae6ff';assert x['source_commit']==expected_commit
  if 'product_identities' in plan:
   identity=plan['product_identities'][product];assert identity['source_fingerprint']==x['source_fingerprint'] and identity['executed_host_sha256']==x['executable_sha256'] and identity['source_commit']==x['source_commit']
  host_files[Path(argv[0])]=x['executable_sha256']
  assert len(x['cases'])==1;c=x['cases'][0];assert c['file']==case and c['source_compilation_profile']=='portable';assert c['linked_runtime']['wasm_sha256']==rhash and c['linked_runtime']['wasm_bytes']==39035706
  src=Path(argv[1])/case
  if src not in source_cache:source_cache[src]=sha(src.read_bytes())
  assert c['source_sha256']==source_cache[src]
  if 'source_hashes' in plan:assert plan['source_hashes'][case]==c['source_sha256']
  artifact=Path(argv[5])/(case+'.wasm');data=artifact.read_bytes();assert len(data)==c['wasm_bytes'] and sha(data)==c['wasm_sha256'];artifact_count+=1
  observed_fp=footprint(data);assert observed_fp==(c['footprint']['defined_functions'],c['footprint']['code_body_bytes'],c['footprint']['largest_code_body_bytes'])
  all_p[(case,product)].add((c['source_sha256'],c['wasm_sha256']))
  if label=='full17':
   key=(case,product)
   if key in full:assert full[key]['bytes']==data
   else:full[key]={'bytes':data,'sha':c['wasm_sha256'],'size':len(data),'code':observed_fp[1],'largest':observed_fp[2]}
  obs=c['observations'];assert len(obs)==31 and [o['warmup'] for o in obs]==[True]*10+[False]*21
  assert all(o['stdout']==expected[case] for o in obs);vals=[o['execution_ns'] for o in obs if not o['warmup']];assert vals==row.get('times_ns',row.get('samples_ns'));med=statistics.median(vals);mean=statistics.mean(vals);assert med==row.get('invocation_median_ns',row.get('median_ns'));assert abs(mean-row.get('invocation_mean_ns',row.get('mean_ns')))<1e-7
  groups[(case,block,product)].append((med,mean));warm+=10
 for (case,block),order in orders.items():
  actual=[p for _,p in sorted(order)];expected_order=schedules[block]
  if label=='aa':expected_order=['baseline-aa' if p=='candidate' else p for p in expected_order]
  assert actual==expected_order,(label,case,block,actual)
 results=[];veto=[];target_fail=[]
 for c in a['comparisons']:
  control=c.get('control',c['case'] in ['checksum-0.js','checksum-1.js']);out=[]
  for b in c['blocks']:
   products=b['products'];other=next(p for p in products if p!='baseline');stats={}
   for p in ['baseline',other]:
    values=groups[(c['case'],b['block'],p)];assert len(values)==4
    stats[p]=(statistics.median(v[0] for v in values),statistics.mean(v[1] for v in values))
   changes=[100*(stats[other][i]/stats['baseline'][i]-1) for i in range(2)];keys=['block_median_of_invocation_medians_percent','block_mean_of_invocation_means_percent'] if 'block_median_of_invocation_medians_percent' in b['change_percent'] else ['median_ns','mean_ns']
   max_discrepancy=max(max_discrepancy,*[abs(changes[i]-b['change_percent'][keys[i]]) for i in range(2)]);out.append(changes)
  if control and all(all(v>=3 for v in block) for block in out):veto.append(c['case'])
  if label!='aa' and not control and any(block[0]>=0 for block in out):target_fail.append(c['case'])
  results.append((c['case'],control,out))
 assert not veto and not target_fail,(label,veto,target_fail)
 assert len(seen)==len(list((root/'raw').glob('*.stdout')))
 cohort_results[label]=results;total_raw+=len(seen);print(label,{'raw':len(seen),'measured':len(seen)*21,'warmups':warm,'artifacts_hashed_and_code_sections_parsed':artifact_count,'controls_veto':veto,'target_fail':target_fail},flush=True)
for path,expected in host_files.items():
 with path.open('rb') as f:actual=hashlib.file_digest(f,'sha256').hexdigest()
 assert actual==expected
print('TOTAL',{'raw':total_raw,'measured':total_raw*21,'warmups':total_raw*10,'host_files_hashed':len(host_files),'max_report_delta':max_discrepancy,'peak_child_rss_bytes':maxrss})
print('FULL17 percent median,mean per block')
for case,control,blocks in cohort_results['full17']:
 p=full[(case,'baseline')];q=full[(case,'candidate')];equal=p['bytes']==q['bytes']
 if control:assert equal
 print(case,'control='+str(control),'changes='+str([[round(v,6) for v in block] for block in blocks]),'Pbytes='+str((p['size'],q['size'])),'codebytes='+str((p['code'],q['code'])),'largest='+str((p['largest'],q['largest'])),'equal='+str(equal),'candidate_sha='+q['sha'])
print('KERNELS',[(c,[[round(v,6) for v in block] for block in changes]) for c,_,changes in cohort_results['kernels']])
print('BOUNDARY256',next((c,changes) for c,_,changes in cohort_results['boundary'] if c=='join-boundary-256-trip0.js'))
print('AA largest absolute median',max((abs(changes[i][0]),c,i,changes[i]) for c,_,changes in cohort_results['aa'] for i in [0,1]))
assert all(len(identities)==1 for identities in all_p.values());print('cross-cohort source/P identity stable for all',len(all_p),'case-product pairs')
