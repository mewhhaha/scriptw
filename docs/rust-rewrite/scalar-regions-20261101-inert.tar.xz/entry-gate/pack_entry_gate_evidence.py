"""Package allowlisted entry-gate receipts as inert UTF-8 evidence."""
import argparse
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import stat
import tarfile

HERE = Path(__file__).resolve().parent
EXTENSIONS = {".json", ".jsonl", ".log", ".stdout", ".stderr", ".py", ".patch",
    ".txt", ".csv", ".map", ".js", ".mjs", ".inventory", ".md", ".rs", ".html", ".wat", ".ll"}
SKIP_PARTS = {"cache", "artifacts", "runtime-build", "verification-cache", "tools",
    "node_modules", ".git", "inspection"}
TREES = ("sources", "retained-sources", "expected", "semantic-sources", "kernels",
    "runs", "native-focused", "native-broad", "kernels-run", "product-semantics", "test262", "test262-all",
    "test262-sort", "test262-to-sorted", "reference", "reference-raw", "reference-runs", "raw",
    "unadmitted", "program-inspection", "source-fixture-correction", "carrier-fix")
PRODUCT_METADATA = ("identity.json", "products.json", "host-products.json", "source.json",
    "source.patch", "source-files.json", "identity.stdout", "identity.stderr")


def add(records, archive_path, path):
    path = Path(path)
    if not path.exists() or path.suffix.lower() not in EXTENSIONS:
        return
    mode = path.lstat().st_mode
    if path.is_symlink() or not stat.S_ISREG(mode) or mode & 0o111:
        raise ValueError(f"non-regular or executable evidence refused: {path}")
    payload = path.read_bytes()
    if payload.startswith((b"\x7fELF", b"\x00asm", b"MZ")):
        raise ValueError(f"binary payload refused: {path}")
    payload.decode("utf-8", errors="strict")
    pure = PurePosixPath(archive_path)
    if pure.is_absolute() or ".." in pure.parts:
        raise ValueError(f"unsafe archive path: {archive_path}")
    if archive_path in records:
        raise ValueError(f"duplicate archive member: {archive_path}")
    records[archive_path] = payload


def add_tree(records, relative, member_prefix=None, excluded_first_parts=()):
    root = HERE / relative
    member_prefix = member_prefix or relative
    if not root.exists() or root.is_symlink():
        return
    for path in sorted(root.rglob("*")):
        if path.is_symlink() or not path.is_file():
            continue
        rel = path.relative_to(root)
        if rel.parts and rel.parts[0] in excluded_first_parts:
            continue
        if any(part in SKIP_PARTS for part in rel.parts):
            continue
        if path.suffix.lower() == ".wat" and (root.name != "program-inspection" or path.name == "runtime.wat"):
            continue
        add(records, f"entry-gate/{member_prefix}/{rel.as_posix()}", path)


def verify_source_identity():
    candidate = json.loads((HERE / "candidate/identity.json").read_text())
    candidate_source = candidate["source_fingerprint"]
    current_runtime = json.loads((HERE / "runtime-invariance.json").read_text())
    predecessor = json.loads((HERE / "predecessor-runtime-invariance.json").read_text())
    current_fp = current_runtime["scriptw-runtime-package.bin"]["source_fingerprint"]
    predecessor_fp = predecessor["scriptw-runtime-package.bin"]["source_fingerprint"]
    if candidate_source != "ce4d1397299c945cffdc9ec80de0cb96c146fc4d7e83e63d24c437de6fea764b":
        raise ValueError("entry-gate candidate source fingerprint changed")
    if current_fp != candidate_source or predecessor_fp != "b7fe482be872af94a11247a63df4f306acbbf5799eba6da446b1bc393aaae544":
        raise ValueError("current/predecessor runtime provenance is mixed or incomplete")
    failed = (HERE / "freeze-first-attempt.stdout", HERE / "freeze-first-attempt.stderr")
    if not all(path.is_file() for path in failed):
        raise ValueError("initial freeze failure receipts are missing")
    return dict(candidate_source_fingerprint=candidate_source,
        predecessor_source_fingerprint=predecessor_fp)


def collect():
    identities = verify_source_identity()
    records = {}
    for path in sorted(HERE.iterdir()):
        if path.is_file() and path.name not in {"report-draft.json", "final-report-draft.json", "predecessor-aa-analysis.json"}:
            add(records, f"entry-gate/{path.name}", path)
    # This is the imported A35-only calibration; keep it outside current ce4d runs.
    add(records, "entry-gate/calibration-a35-only/predecessor-aa-analysis.json",
        HERE / "predecessor-aa-analysis.json")
    for product in ("baseline", "baseline-aa", "candidate"):
        for name in PRODUCT_METADATA:
            add(records, f"entry-gate/{product}/{name}", HERE / product / name)
    for directory in TREES:
        if directory == "runs":
            add_tree(records, "runs", excluded_first_parts={"20261101T014033Z-aa-controls12"})
        else:
            add_tree(records, directory)
    # The imported A35-only calibration is separate from the current 020800 A/A.
    add_tree(records, "runs/20261101T014033Z-aa-controls12", "calibration-a35-only/runs/20261101T014033Z-aa-controls12")
    # This folder contains the fresh current ce4d boundary cohort, not b7fe.
    add_tree(records, "join-boundary")
    for path in sorted(HERE.iterdir()):
        if path.is_dir() and (path.name.startswith("test262-") or path.name.startswith("reference-")):
            if path.name not in TREES:
                add_tree(records, path.name)
    if not records:
        raise ValueError("no allowlisted text evidence found")
    return records, identities


def package(output):
    records, identities = collect()
    rows = [dict(path=name, bytes=len(payload), sha256=hashlib.sha256(payload).hexdigest())
        for name,payload in sorted(records.items())]
    index = dict(schema="scriptw-entry-gate-inert-evidence-v1", member_count=len(rows),
        expanded_bytes=sum(row["bytes"] for row in rows), files=rows,
        source_identities=identities,
        policy="UTF-8 regular non-executable text only; native/Wasm images, caches, toolchains, binaries and runtime WAT excluded. Curated program WAT only.")
    records["evidence-index.json"] = (json.dumps(index,indent=2)+"\n").encode()
    output = Path(output)
    output.parent.mkdir(parents=True,exist_ok=True)
    with tarfile.open(output,"w:xz",preset=3,format=tarfile.PAX_FORMAT) as archive:
        for name,payload in sorted(records.items()):
            member=tarfile.TarInfo(name); member.size=len(payload); member.mode=0o644; member.mtime=0
            archive.addfile(member,io.BytesIO(payload))
    with tarfile.open(output,"r:xz") as archive:
        members=archive.getmembers()
        if len(members)!=len(records):
            raise ValueError("archive member count changed")
        for member in members:
            pure=PurePosixPath(member.name)
            if not member.isreg() or pure.is_absolute() or ".." in pure.parts or member.mode & 0o111:
                raise ValueError(f"unsafe member: {member.name}")
            if archive.extractfile(member).read()!=records[member.name]:
                raise ValueError(f"archive payload mismatch: {member.name}")
    print(json.dumps(dict(output=str(output),sha256=hashlib.file_digest(output.open("rb"),"sha256").hexdigest(),
        bytes=output.stat().st_size,member_count=len(records),expanded_bytes=sum(map(len,records.values())),
        source_identities=identities),indent=2))


if __name__ == "__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output",type=Path,required=True)
    package(parser.parse_args().output)
