"""Run the frozen candidate CLI over its nine semantic predicates; never builds it."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
CLI = OUT / "candidate/scriptw"
SOURCES = OUT / "semantic-sources"
DEST = OUT / "product-semantics"
EXPECTED = 'run outcome: RunOutcome { backend_used: WasmAot, note: "wasm-aot completion: boolean(true)" }\n'


def digest(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def main():
    sources = sorted(SOURCES.glob("*.js"))
    assert len(sources) == 9, f"expected nine semantic fixtures, found {len(sources)}"
    assert CLI.is_file() and os.access(CLI, os.X_OK) and not CLI.is_symlink()
    identity = json.loads((OUT / "candidate/identity.json").read_text())
    hosts = json.loads((OUT / "candidate/host-products.json").read_text())
    source_fingerprint = identity["source_fingerprint"]
    cli_sha_before = digest(CLI)
    assert hosts["scriptw"]["sha256"] == cli_sha_before, "CLI differs from frozen product identity"
    DEST.mkdir(parents=True, exist_ok=False)
    records = []
    env = dict(os.environ)
    for source in sources:
        stem = source.stem
        stdout_path = DEST / f"{stem}.stdout"
        stderr_path = DEST / f"{stem}.stderr"
        argv = [str(CLI), "--jobs", "1", "--host-surface", "test262", "run", str(source)]
        source_sha_before = digest(source)
        cli_sha_before_run = digest(CLI)
        started = time.perf_counter_ns()
        timed_out = False
        exit_code = None
        with stdout_path.open("xb") as stdout, stderr_path.open("xb") as stderr:
            try:
                exit_code = subprocess.run(argv, cwd=ROOT, env=env,
                    stdout=stdout, stderr=stderr, timeout=60, check=False).returncode
            except subprocess.TimeoutExpired:
                timed_out = True
        elapsed_ns = time.perf_counter_ns() - started
        cli_sha_after_run = digest(CLI)
        source_sha_after = digest(source)
        actual = stdout_path.read_text(errors="replace")
        record = dict(source=source.name, source_sha256=source_sha_before,
            source_sha256_after=source_sha_after, argv=argv, returncode=exit_code,
            timed_out=timed_out, stdout=stdout_path.name, stdout_sha256=digest(stdout_path),
            stderr=stderr_path.name, stderr_sha256=digest(stderr_path),
            cli_sha256_before=cli_sha_before_run, cli_sha256_after=cli_sha_after_run,
            source_fingerprint_binder=source_fingerprint, elapsed_ns=elapsed_ns,
            exact_expected_stdout=EXPECTED, exact_stdout_match=actual == EXPECTED)
        receipt = DEST / f"{stem}.command.json"
        receipt.write_text(json.dumps(record, indent=2) + "\n")
        records.append(record)
        assert not timed_out and exit_code == 0, f"CLI failed or timed out: {source.name}; see {stderr_path}"
        assert source_sha_after == source_sha_before, f"fixture changed during run: {source.name}"
        assert cli_sha_before_run == cli_sha_after_run == cli_sha_before, f"CLI changed during run: {source.name}"
        assert actual == EXPECTED, f"unexpected exact CLI output for {source.name}: {actual!r}"
        print(source.name, "PASS", flush=True)
    summary = dict(status="pass", purpose="frozen candidate CLI delivery-path semantic check; not benchmark evidence",
        cli=str(CLI), cli_sha256=cli_sha_before, source_fingerprint_binder=source_fingerprint,
        expected_stdout=EXPECTED, fixture_count=len(records), records=records)
    (DEST / "product-semantics.json").write_text(json.dumps(summary, indent=2) + "\n")
    assert digest(CLI) == cli_sha_before, "CLI changed after semantic run"
    print(json.dumps(dict(status=summary["status"], fixture_count=len(records),
        product_semantics=str(DEST / "product-semantics.json")), indent=2))


if __name__ == "__main__":
    main()
