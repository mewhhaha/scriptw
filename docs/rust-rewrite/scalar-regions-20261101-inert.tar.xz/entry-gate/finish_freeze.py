"""Finish immutable runtime receipt after removing an imported predecessor record."""
import hashlib,json,struct,subprocess
from run import OUT,ROOT,digest,load,save_new
destination=OUT/'candidate'
identity=load(destination/'identity.json')
products=load(destination/'products.json')
for name,record in products.items():
    assert digest(destination/name)==record['sha256']
assert hashlib.sha256((destination/'source.patch').read_bytes()).hexdigest()==load(destination/'source.json')['patch_sha256']
build = ROOT / 'target/release/build/scriptw-runtime-image-f4bdc99efd9bf0e2/out'
baseline = ROOT / 'target/performance-fresh-sort/baseline/runtime-build'
frozen = destination / 'runtime-build'
frozen.mkdir(exist_ok=True)
receipts = {}
for profile in ['', '-portable']:
    package = f'scriptw-runtime{profile}-package.bin'
    native = f'scriptw-runtime{profile}-native.bin'
    for name in [package, native]:
        subprocess.run(['cp', '--reflink=auto', build / name, frozen / name], check=True)
    current, previous = (frozen / package).read_bytes(), (baseline / package).read_bytes()
    assert current[:8] == previous[:8] == b'SCRWRB01'
    assert struct.unpack_from('<I', current, 8)[0] == struct.unpack_from('<I', previous, 8)[0] == 42
    assert current[12:44].hex() == identity['source_fingerprint']
    assert previous[12:44].hex() == load(OUT / 'baseline/identity.json')['source_fingerprint']
    current_wasm, previous_wasm = current[136:-32], previous[136:-32]
    assert len(current_wasm) == struct.unpack_from('<Q', current, 128)[0]
    assert len(previous_wasm) == struct.unpack_from('<Q', previous, 128)[0]
    assert hashlib.sha256(current[:-32]).digest() == current[-32:]
    assert hashlib.sha256(previous[:-32]).digest() == previous[-32:]
    assert current_wasm == previous_wasm
    assert digest(frozen / native) == digest(baseline / native)
    receipts[package] = dict(source_fingerprint=identity['source_fingerprint'],
        runtime_abi=42, runtime_wasm_identical=True, runtime_wasm_bytes=len(current_wasm),
        runtime_wasm_sha256=hashlib.sha256(current_wasm).hexdigest())
    receipts[native] = dict(native_identical=True, bytes=(frozen / native).stat().st_size,
                          sha256=digest(frozen / native))
save_new(OUT / 'runtime-invariance.json', receipts)
print(json.dumps(dict(source_fingerprint=identity['source_fingerprint'], products=products,
                     runtime_invariance=receipts), indent=2))
