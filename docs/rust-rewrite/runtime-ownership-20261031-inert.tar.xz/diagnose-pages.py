#!/usr/bin/env python3
"""Unscored normal-host R page observations; never load archived native code.

Run serially under limited_verification.py --cloud after frozen products and
their original images exist. Reuses the repository phase protocol/capture and
presence reader. No perf map, live text reads, or native-text hashing is enabled.
"""
import argparse
import hashlib
import importlib.util
import json
import mmap
import os
from pathlib import Path
import stat
import struct
import sys
import time

import zstandard

WORK = Path(__file__).resolve().parent
ROOT = WORK.parents[1]
OLD = ROOT / 'target/performance-dense-numbers-20261030'
sys.path.insert(0, str(ROOT / 'scripts'))
import benchmark_module_images as elf
import precompiled_comparison as comparison
from limited_verification import kernel_group, require_cloud_budget

spec = importlib.util.spec_from_file_location('mapping_capture', ROOT / 'scripts/diagnose-precompiled-mappings.py')
capture_tools = importlib.util.module_from_spec(spec)
spec.loader.exec_module(capture_tools)

MAX_NATIVE = 128 * 1024**2
MAX_TABLE = 4096 * 64
MAX_FDS = 512
SAMPLES, WARMUPS, INDEX = 7, 10, 16
require = elf.require


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def save(path, value):
    pending = path.with_suffix(path.suffix + '.pending')
    pending.write_text(json.dumps(value, indent=2) + '\n')
    pending.replace(path)


def resources():
    budget = require_cloud_budget()
    affinity = sorted(os.sched_getaffinity(0))
    require(len(affinity) == 1, 'page capture requires serial CPU affinity')
    group = kernel_group()
    return dict(cloud_budget_bytes=budget, cpu_affinity=affinity, counters={
        key: (group / key).read_text().strip() for key in (
            'memory.max', 'memory.swap.max', 'memory.oom.group', 'cpu.max',
            'memory.current', 'memory.peak', 'memory.events')})


def inert_elf(raw):
    """Bounded ET_REL-capable variant of native-cause/inspect.py's reader."""
    require(64 <= len(raw) <= elf.MAX_ELF and raw[:7] == b'\x7fELF\x02\x01\x01', 'unsupported ELF identity')
    header = struct.unpack_from('<16sHHIQQQIHHHHHH', raw)
    require(header[1] in (1, 2, 3) and header[2] == 62 and header[3] == 1 and header[8] == 64,
            'requires ELF64 little-endian x86_64')
    require(header[11] == 64 and 0 < header[12] <= 4096 and 0 < header[13] < header[12], 'unsupported section counts')
    table_offset, table_bytes = header[6], header[12] * 64
    table = bytes(elf._extent(raw, table_offset, table_bytes))
    rows = [struct.unpack_from('<IIQQQQIIQQ', table, n * 64) for n in range(header[12])]
    strings = rows[header[13]]
    names = bytes(elf._extent(raw, strings[4], strings[5]))
    require(strings[1] == 3 and len(names) <= elf.MAX_NAME_BYTES, 'section name table bound')

    def name_at(data, offset, bound):
        require(0 <= offset < len(data), 'invalid string offset')
        end = data.find(b'\0', offset, min(len(data), offset + bound + 1))
        require(end >= offset, 'unterminated ELF name')
        return data[offset:end].decode('utf-8', errors='strict')

    sections = []
    for index, row in enumerate(rows):
        if row[1] != 8:
            elf._extent(raw, row[4], row[5])
        sections.append(dict(index=index, name=name_at(names, row[0], elf.MAX_SECTION_NAME_BYTES),
            type=row[1], flags=row[2], vaddr=row[3], offset=row[4], bytes=row[5]))
    symbols = {}
    ambiguous = set()
    entries = 0
    total_names = 0
    for table_row in rows:
        if table_row[1] != 2:
            continue
        require(table_row[9] == 24 and table_row[5] % 24 == 0 and table_row[6] < len(rows), 'invalid symbols')
        entries += table_row[5] // 24
        require(entries <= elf.MAX_SYMBOLS, 'symbol count bound')
        strings = rows[table_row[6]]
        require(strings[1] == 3 and strings[5] <= elf.MAX_NAME_BYTES, 'symbol string table bound')
        names = bytes(elf._extent(raw, strings[4], strings[5]))
        for offset in range(table_row[4], table_row[4] + table_row[5], 24):
            name, info, other, index, value, size = struct.unpack_from('<IBBHQQ', raw, offset)
            if not name or not size or not 0 < index < len(rows) or info & 15 not in (1, 2):
                continue
            owner = rows[index]
            if owner[1] == 8:
                continue
            require(owner[3] <= value and value - owner[3] <= owner[5] and size <= owner[5] - (value - owner[3]),
                    'symbol escapes its section')
            start = owner[4] + value - owner[3]
            elf._extent(raw, start, size)
            name = name_at(names, name, elf.MAX_SYMBOL_NAME_BYTES)
            total_names += len(name.encode())
            require(total_names <= elf.MAX_NAME_BYTES, 'aggregate symbol name bound')
            if name in symbols:
                if symbols[name]['file_offset'] != start or symbols[name]['bytes'] != size:
                    ambiguous.add(name)
                continue
            symbols[name] = dict(name=name, value=value, bytes=size, file_offset=start,
                type=info & 15, section=index, section_name=sections[index]['name'], section_flags=owner[2])
    return dict(header=bytes(raw[:64]), table=table, table_offset=table_offset,
                sections=sections, symbols=symbols, ambiguous_symbols=sorted(ambiguous))


def extract_runtime(label, output):
    folder = ROOT / 'target/performance-memory-parity-20261031/candidate' if label == 'baseline' else WORK / 'candidate'
    host = folder / 'compiler_precompiled_baseline'
    capture_tools.owned_file(host)
    identity = json.loads((folder / 'identity.json').read_text())
    products = json.loads((folder / 'products.json').read_text())
    expected = products['compiler_precompiled_baseline']['sha256']
    require(expected == identity['executable_sha256'], 'frozen product/identity disagree')
    before = host.stat()
    require(before.st_size <= elf.MAX_ELF, 'host byte bound')
    with host.open('rb') as stream, mmap.mmap(stream.fileno(), 0, access=mmap.ACCESS_READ) as raw:
        require(sha(raw) == expected, 'frozen host hash differs')
        host_elf = inert_elf(raw)
        require(not {'SCRIPTW_RUNTIME_PORTABLE_NATIVE', 'SCRIPTW_RUNTIME_PORTABLE_EXECUTION'} &
            set(host_elf['ambiguous_symbols']), 'portable runtime symbol binding is ambiguous')
        native = host_elf['symbols']['SCRIPTW_RUNTIME_PORTABLE_NATIVE']
        execution = host_elf['symbols']['SCRIPTW_RUNTIME_PORTABLE_EXECUTION']
        require(native['type'] == execution['type'] == 1, 'portable runtime symbols are not objects')
        packed = bytes(elf._extent(raw, native['file_offset'], native['bytes']))
        receipt = bytes(elf._extent(raw, execution['file_offset'], execution['bytes']))
    require(receipt[:8] == b'SCRWEX01' and sha(receipt[:-32]) == receipt[-32:].hex(), 'execution receipt integrity differs')
    require(receipt[13:45].hex() == identity['source_fingerprint'], 'runtime/host source differ')
    require(packed[:8] == b'SWRTZ001' and len(packed) > 48, 'packed runtime framing differs')
    length = struct.unpack_from('<Q', packed, 8)[0]
    require(0 < length <= MAX_NATIVE, 'decoded runtime byte bound')
    raw = zstandard.ZstdDecompressor(max_window_size=8 * 1024**2).decompress(
        packed[48:], max_output_size=length, allow_extra_data=False)
    require(len(raw) == length and sha(raw) == packed[16:48].hex(), 'inert decoded runtime hash differs')
    native_elf = inert_elf(raw)
    native_path = output / (label + '-runtime-portable.elf')
    native_path.write_bytes(raw)  # Inert own-host extraction; never loaded or executed.
    text = [row for row in native_elf['sections'] if row['name'] == '.text']
    require(len(text) == 1 and text[0]['type'] == 1 and text[0]['flags'] & 4, 'runtime text section absent')
    functions = [row for row in native_elf['symbols'].values() if row['type'] == 2 and row['section_flags'] & 4
        and row['name'] not in native_elf['ambiguous_symbols']]
    require(functions, 'runtime function symbols absent')
    require(digest(host) == expected and (host.stat().st_dev, host.stat().st_ino, host.stat().st_size) ==
        (before.st_dev, before.st_ino, before.st_size), 'frozen host changed during extraction')
    record = dict(host=str(host), host_sha256=expected, source_commit=identity['source_commit'],
        source_fingerprint=identity['source_fingerprint'], runtime_key=receipt[45:77].hex(),
        runtime_layout=struct.unpack_from('<I', receipt, 8)[0], packed_symbol=native,
        packed_sha256=sha(packed), native_sha256=sha(raw), native_bytes=length,
        inert_native_file=native_path.name, text=text[0], functions=functions,
        excluded_ambiguous_native_symbols=native_elf['ambiguous_symbols'],
        fd_metadata=dict(header_hex=native_elf['header'].hex(),
            section_table_offset=native_elf['table_offset'], section_table_bytes=len(native_elf['table']),
            section_table_sha256=sha(native_elf['table'])),
        interpretation='Exact Portable R decoded from verified frozen own host; file SHA computed only inertly outside child. No native payload is loaded.')
    save(output / (label + '-runtime-symbols.json'), record)
    del raw, packed, host_elf, native_elf
    return host, identity, record


def private_backing_fds(pid, runtime):
    result = dict(status='unavailable', candidates=[], matched=[])
    try:
        paths = list(Path(f'/proc/{pid}/fd').iterdir())
        require(len(paths) <= MAX_FDS, 'open descriptor bound')
        meta = runtime['fd_metadata']
        for path in paths:
            try:
                info = path.stat()
                link = os.readlink(path)
                if not (stat.S_ISREG(info.st_mode) and info.st_uid == os.getuid() and info.st_nlink == 0
                        and info.st_size == runtime['native_bytes'] and 'private-native-backing-v1/' in link):
                    continue
                row = dict(fd=int(path.name), path=link, inode=info.st_ino,
                    device=[os.major(info.st_dev), os.minor(info.st_dev)], bytes=info.st_size,
                    links=info.st_nlink, status='metadata-mismatch')
                result['candidates'].append(row)
                with path.open('rb', buffering=0) as stream:
                    header = os.pread(stream.fileno(), 64, 0)
                    require(len(header) == 64, 'short live ELF header')
                    require(0 < meta['section_table_bytes'] <= MAX_TABLE, 'live section-table bound')
                    table = os.pread(stream.fileno(), meta['section_table_bytes'], meta['section_table_offset'])
                    after = os.fstat(stream.fileno())
                require((info.st_dev, info.st_ino, info.st_size) ==
                    (after.st_dev, after.st_ino, after.st_size), 'live backing identity changed')
                row.update(header_hex=header.hex(), section_table_bytes=len(table), section_table_sha256=sha(table))
                if header.hex() == meta['header_hex'] and len(table) == meta['section_table_bytes'] and sha(table) == meta['section_table_sha256']:
                    row['status'] = 'matched-source-owned-private-Cargo-backing'
                    result['matched'].append(dict(row))
            except (OSError, ValueError) as error:
                result.setdefault('fd_errors', []).append(dict(fd=path.name, error=str(error)))
        require(result['matched'], 'no exact-metadata private Cargo backing descriptor found')
        require(len({(row['inode'], tuple(row['device'])) for row in result['matched']}) == 1,
            'multiple runtime backing inodes are ambiguous')
        result['status'] = 'bound-private-Cargo-backing'
    except (OSError, ValueError) as error:
        result['error'] = str(error)
    result['interpretation'] = ('Only descriptor identity, ELF header and section table were read. '
        'Full-byte identity relies on the verified own host Cargo decoder checking its native SHA before private-file publication. '
        'No live text bytes, contents of JavaScript memory, or PFNs were read.')
    return result


def interval_union_bytes(spans):
    total, end = 0, -1
    for lo, hi in sorted(spans):
        if hi <= end:
            continue
        total += hi - max(lo, end)
        end = hi
    return total


def attribute_runtime(runtime, snapshots, fds):
    result = dict(status='unavailable', phases=[], functions=[],
        interpretation='Nonexclusive symbol/page overlap and PTE presence, never executed calls, live JS heap, or causal savings. Warm phases follow 16 earlier observations; transport drop precedes the first Store.')
    try:
        require(len(snapshots) == len(fds) == 4, 'missing paused FD/mapping observations')
        functions = runtime['functions']
        text_lo, text_hi = runtime['text']['offset'], runtime['text']['offset'] + runtime['text']['bytes']
        by_phase = {}
        transport = None
        for snapshot, fd_record in zip(snapshots, fds):
            require(fd_record['status'] == 'bound-private-Cargo-backing', 'runtime FD binding unavailable')
            owner = fd_record['matched'][0]
            page, present = elf.presence_pages(snapshot)
            rows = [row for row in snapshot['mappings'] if row['inode'] == owner['inode'] and row['device'] == owner['device']]
            require(rows, 'bound runtime inode has no captured mappings')
            bases = {row['start'] - row['file_offset'] for row in rows}
            require(len(bases) == 1, 'runtime inode mapping bias is ambiguous')
            base = next(iter(bases))
            elf.covered(rows, base + text_lo, base + text_hi, executable=True)
            file_pages, rx_pages = set(), set()
            for row in rows:
                for address in range(row['start'], row['end'], page):
                    if address not in present:
                        continue
                    offset = row['file_offset'] + address - row['start']
                    file_pages.add(offset)
                    if 'x' in row['permissions'] and offset < text_hi and text_lo < offset + page:
                        rx_pages.add(offset)
            if transport is None:
                transport = rx_pages
            by_phase[snapshot['phase']] = (page, rx_pages)
            pages = []
            for offset in sorted(rx_pages):
                lo, hi = max(offset, text_lo), min(offset + page, text_hi)
                overlaps = [(i, max(lo, fn['file_offset']), min(hi, fn['file_offset'] + fn['bytes']))
                    for i, fn in enumerate(functions) if fn['file_offset'] < hi and lo < fn['file_offset'] + fn['bytes']]
                named = interval_union_bytes([(a, b) for _, a, b in overlaps])
                pages.append(dict(file_offset=offset, text_overlap_bytes=hi-lo, symbol_ids=[i for i, _, _ in overlaps],
                    symbol_union_bytes=named, unnamed_or_padding_bytes=hi-lo-named))
            result['phases'].append(dict(phase=snapshot['phase'], observation_index=snapshot['observation_index'],
                history='before-first-Store' if snapshot['phase'] == 'after_transport_drop' else 'observation16-after10-warmups-and6-prior-measured',
                binding_inode=owner['inode'], binding_device=owner['device'], image_base=base,
                backing_mappings=rows, page_bytes=page, runtime_file_present_pages=len(file_pages),
                runtime_whole_backing_vma_rss_bytes=sum(row['Rss'] for row in rows),
                text_present_pages=len(rx_pages), text_present_bytes_in_pages=sum(row['text_overlap_bytes'] for row in pages),
                newly_present_text_pages_since_transport=sorted(rx_pages - transport),
                pages_with_multiple_symbols=sum(len(row['symbol_ids']) > 1 for row in pages), pages=pages,
                potential_nonexecuted_neighbor_bytes_bounds=dict(lower=0,
                    upper=sum(row['text_overlap_bytes'] for row in pages),
                    explanation='Presence alone cannot separate executed bytes from neighboring or previously touched code; no causal cold-neighbor saving is established.')))
        for index, function in enumerate(functions):
            overlaps = {}
            for phase, (page, present) in by_phase.items():
                lo, hi = elf.page_interval(function['file_offset'], function['file_offset'] + function['bytes'], page)
                overlaps[phase] = sum(offset in present for offset in range(lo, hi, page))
            if any(overlaps.values()):
                result['functions'].append(dict(function, symbol_id=index, present_page_overlaps=overlaps))
        result['status'] = 'bound-symbol-page-overlap'
    except (ValueError, KeyError, TypeError) as error:
        result['error'] = str(error)
    return result


def validate_endpoint(record, directory, identity, image, case, runtime):
    value = capture_tools.unique_json(capture_tools.bounded_read(directory / 'stdout'))
    require(value['executable_sha256'] == identity['executable_sha256'] and
        value['source_fingerprint'] == identity['source_fingerprint'] and
        value['source_commit'] == identity['source_commit'] and
        value['shared_configuration'] == identity['shared_configuration'] and
        value['compiler_enabled'] is False and value['runtime_key'] == runtime['runtime_key'] and
        value['image_sha256'] == image['sha256'], 'endpoint product/source/image identity differs')
    require(value['samples'] == SAMPLES and value['warmups'] == WARMUPS and
        value['excluded_from_scored_cohorts'] is True and value['diagnostic_total_timings_include_barrier_waits'] is True,
        'endpoint sample/diagnostic policy differs')
    marker = value['phase_barriers']
    require(marker['schema'] == 'scriptw-precompiled-phase-barriers-v1' and marker['nonce'] == record['nonce'] and
        marker['observation_index'] == INDEX and marker['completed_phases'] == list(capture_tools.PHASES),
        'endpoint completed protocol differs')
    observations = value['observations']
    require(len(observations) == SAMPLES + WARMUPS, 'endpoint observation count differs')
    require(all(row['index'] == index and row['warmup'] == (index < WARMUPS) and
        row['stdout'] == case['stdout'] and row['stderr'] == '' and row['matched'] is True
        for index, row in enumerate(observations)), 'original observations or checksums differ')
    return dict(status='validated', cold_transport_drop=value['process_snapshots']['after_transport_drop'],
        first_observation_raw=observations[0], warm_observation_raw=observations[INDEX],
        interpretation='Observation0 endpoints are the first Store invocation and are raw self-observations; no cold instantiate PTE capture is claimed. Cold means no earlier invocation in this child, not cold filesystem/cache.')


def run(output):
    output.mkdir(parents=True, exist_ok=False)
    result = dict(scored=False, excluded_from_scored_cohorts=True, status='incomplete', cases=[],
        scope='Own frozen normal release hosts; unscored phase barriers and PTE-present code ownership only.',
        samples=SAMPLES, warmups=WARMUPS, observation_index=INDEX,
        tool_sha256={str(path.relative_to(ROOT)): digest(path) for path in (
            Path(__file__).resolve(), ROOT/'scripts/diagnose-precompiled-mappings.py',
            ROOT/'scripts/benchmark_module_images.py', OLD/'native-cause/inspect.py')},
        environment_policy='capture clears SCRIPTW_PERF_MAP_DIR and all execution-window options; no live text hash or module serialization requested')
    report_path = output / 'report.json'
    save(report_path, result)
    try:
        result['resources'] = dict(before=resources())
        manifest = json.loads((WORK / 'sources/manifest.json').read_text())
        cases = {row['file']: row for row in manifest['execution']}
        remaining = [capture_tools.MAX_TOTAL]
        for label in ('baseline', 'candidate'):
            host, identity, runtime = extract_runtime(label, output)
            producer_path = ((ROOT / 'target/performance-memory-parity-20261031/candidate-original') if label == 'baseline' else WORK / 'candidate-original') / 'producer.json'
            producer = json.loads(producer_path.read_text())
            require(producer['executable_sha256'] == identity['executable_sha256'] and
                producer['source_fingerprint'] == identity['source_fingerprint'], 'original producer differs')
            for name in ('integer.js', 'retained-objects.js'):
                case = cases[name]
                producer_case = next(row for row in producer['cases'] if row['file'] == name)
                image_path = producer_path.parent / (name + '.swpc')
                capture_tools.owned_file(image_path)
                require(image_path.stat().st_size <= 8 * 1024**2, 'original image byte bound')
                image = comparison.image_metadata(image_path.read_bytes(), 'scriptw', identity['source_fingerprint'])
                require(image['sha256'] == producer_case['image_sha256'] and image['runtime_key'] == runtime['runtime_key']
                    and digest(WORK / 'sources' / name) == producer_case['source_sha256'], 'original image/source receipt differs')
                directory = output / (label + '-' + name)
                fd_records = []
                original_presence = capture_tools.module_images.readable_presence
                def paused_presence(pid, rows):
                    fd_records.append(private_backing_fds(pid, runtime))
                    return original_presence(pid, rows)
                capture_tools.module_images.readable_presence = paused_presence
                before = resources()
                try:
                    record = capture_tools.capture(host, [str(host), 'execute-scriptw', str(image_path),
                        case['stdout'], str(SAMPLES), str(WARMUPS)], directory, remaining, True, INDEX)
                finally:
                    capture_tools.module_images.readable_presence = original_presence
                record.update(label=label, file=name, image=image, frozen_host_sha256=identity['executable_sha256'],
                    runtime_sha256=runtime['native_sha256'], fd_snapshots=fd_records,
                    resource_facts=dict(before=before, after=resources()))
                try:
                    require(record['status'] == 'barriers_complete', 'phase capture incomplete')
                    record['endpoint_validation'] = validate_endpoint(record, directory, identity, image, case, runtime)
                    record['runtime_attribution'] = attribute_runtime(runtime, record['snapshots'], fd_records)
                    record['phase_attribution_validated'] = True
                    record['status'] = ('captured' if record['runtime_attribution']['status'] == 'bound-symbol-page-overlap'
                        else 'captured-with-runtime-attribution-unavailable')
                except (OSError, ValueError, KeyError, TypeError) as error:
                    record.update(status='failed', endpoint_validation_error=str(error))
                result['cases'].append(record)
                save(directory / 'record.json', record)
                save(report_path, result)
                require(digest(host) == identity['executable_sha256'] and digest(image_path) == image['sha256'],
                    'frozen host/image changed during capture')
        result['status'] = 'captured' if all(row['status'] == 'captured' for row in result['cases']) else 'incomplete'
    except (OSError, ValueError, KeyError, TypeError, StopIteration) as error:
        result['error'] = str(error)
    finally:
        try:
            result.setdefault('resources', {})['after'] = resources()
        except (OSError, ValueError) as error:
            result['resource_after_error'] = str(error)
        save(report_path, result)
    print(result['status'], report_path, flush=True)
    return 0 if result['status'] == 'captured' else 1


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=WORK/'page-diagnostic')
    args = parser.parse_args()
    destination = args.output.resolve()
    require(WORK in destination.parents, 'output must stay under this target work directory')
    raise SystemExit(run(destination))
