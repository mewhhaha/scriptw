function check(ok, message) { if (!ok) throw message; }

const pristine = [-0, , NaN];
const changed = [1, 2];
const empty = [];
const symbol = Symbol('named');
changed.note = { owner: changed };
changed[symbol] = pristine;
Object.defineProperty(changed, 'hidden', { value: pristine, configurable: true });
gc();
check(!Object.hasOwn(pristine, 'note') && !Object.hasOwn(pristine, symbol) &&
  !Object.hasOwn(empty, 'note') && !Object.hasOwn(empty, 'hidden') &&
  changed.note.owner === changed && changed[symbol] === pristine && changed.hidden === pristine,
  'first named and symbol definitions promote only their own array');
check(Array.prototype.length === 0 && Object.hasOwn(Array.prototype, 'push') &&
  !Object.hasOwn(empty, 'push') && !Object.hasOwn(pristine, 'constructor'),
  'Array.prototype bootstrap properties never enter fresh array storage');

const frozenFresh = [-0, , 5], sealedEmpty = [], writableSibling = [7];
Object.freeze(frozenFresh);
Object.seal(sealedEmpty);
const frozenIndex = Object.getOwnPropertyDescriptor(frozenFresh, '0');
const frozenLength = Object.getOwnPropertyDescriptor(frozenFresh, 'length');
const sealedLength = Object.getOwnPropertyDescriptor(sealedEmpty, 'length');
check(Object.isFrozen(frozenFresh) && Object.is(frozenIndex.value, -0) && !frozenIndex.writable &&
  frozenIndex.enumerable && !frozenIndex.configurable && frozenLength.value === 3 &&
  !frozenLength.writable && !frozenLength.enumerable && !frozenLength.configurable &&
  !Reflect.set(frozenFresh, '1', 2) && !Reflect.set(frozenFresh, 'length', 1) &&
  Reflect.ownKeys(frozenFresh).join(',') === '0,2,length',
  'freezing a fresh array preserves indexed descriptors, holes and virtual length');
check(Object.isSealed(sealedEmpty) && !Object.isExtensible(sealedEmpty) &&
  sealedLength.writable && !sealedLength.enumerable && !sealedLength.configurable &&
  !Reflect.set(sealedEmpty, '0', 1) && !Reflect.set(sealedEmpty, 'note', 1) &&
  Reflect.set(sealedEmpty, 'length', 3) && Reflect.ownKeys(sealedEmpty).join(',') === 'length',
  'sealing a fresh empty array keeps writable length separate from extensibility');
check(Object.isExtensible(writableSibling) && Reflect.deleteProperty(writableSibling, 'absent'),
  'integrity changes and deleting an absent named key stay local to one array');
writableSibling[0] = 11;
writableSibling.note = writableSibling;
check(writableSibling.push(13) === 2 && writableSibling[0] === 11 && writableSibling[1] === 13 &&
  writableSibling.note === writableSibling && !Object.hasOwn(frozenFresh, 'note'),
  'fresh siblings remain extensible with writable indices after shared-storage integrity changes');

const sparse = [1, , 3];
check(Reflect.ownKeys(sparse).join(',') === '0,2,length' &&
  Reflect.ownKeys(empty).join(',') === 'length' &&
  Object.getOwnPropertyNames(pristine).join(',') === '0,2,length',
  'fresh compact named storage still enumerates exotic indices and length');
const forwarded = new Proxy([4, , 6], {});
check(Reflect.ownKeys(forwarded).join(',') === '0,2,length',
  'proxy forwarding retains the Array own-key path');
const sealedKeys = [7, , 9];
Object.preventExtensions(sealedKeys);
let rejected = false;
try { Reflect.ownKeys(new Proxy(sealedKeys, { ownKeys() { return ['length']; } })); }
catch (error) { rejected = error instanceof TypeError; }
check(rejected, 'proxy invariants see indexed target keys on a nonextensible array');

const prototype = Object.create(Array.prototype);
Object.defineProperty(prototype, 'self', { get() { gc(); return this; } });
Object.setPrototypeOf(pristine, prototype);
Object.freeze(changed);
pristine[1] = pristine;
pristine.note = pristine;
empty.push(11);
gc();
check(pristine.self === pristine && Object.is(pristine[0], -0) && pristine[1] === pristine &&
  Number.isNaN(pristine[2]) && pristine.note === pristine && empty.length === 1 && empty[0] === 11 &&
  Object.isFrozen(changed) && changed.note.owner === changed && changed[symbol] === pristine &&
  !Reflect.set(changed, 'other', 1) && !Reflect.deleteProperty(changed, 'hidden'),
  'prototype, integrity, cyclic roots and indexed mutations stay independent across arrays');

print('array-shared-empty-named-storage:ok');
262;
