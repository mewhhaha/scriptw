//! ArrayCreate shares only an empty named-property graph, never an object header.
//! No slot in either zero-length array can be written. Structural mutation
//! replaces the storage on the affected header before publishing any entry.
//! The immutable global is initialized before bootstrap and owns no Realm or
//! user references; each runtime instance/Store receives its own graph.
use super::*;

#[derive(Debug, PartialEq, Eq)]
pub(super) struct EmptyArrayPropertiesGlobal {
    index: u32,
}

impl EmptyArrayPropertiesGlobal {
    pub(super) fn declare(layouts: &GcLayoutRegistry, globals: &mut GlobalLedger) -> Self {
        let index = globals.len();
        globals.global(
            GlobalType {
                val_type: ValType::Ref(
                    layouts.reference(ArrayCompactDataStorage::LAYOUT, GcNullability::NonNullable),
                ),
                mutable: false,
                shared: false,
            },
            &ConstExpr::extended([
                Instruction::ArrayNewFixed {
                    array_type_index: layouts.array_type::<CompactShapeKeys>().type_index().raw(),
                    array_size: 0,
                },
                Instruction::I32Const(
                    crate::heap::StoredPropertyAttributes::Data {
                        writable: true,
                        enumerable: true,
                        configurable: true,
                    }
                    .descriptor_word()
                    .as_i32(),
                ),
                Instruction::StructNew(
                    layouts.struct_type::<CompactDataShape>().type_index().raw(),
                ),
                Instruction::ArrayNewFixed {
                    array_type_index: layouts.array_type::<CompactTagArray>().type_index().raw(),
                    array_size: 0,
                },
                Instruction::RefNull(
                    layouts
                        .reference(CompactScalarArray::LAYOUT, GcNullability::Nullable)
                        .heap_type,
                ),
                Instruction::RefNull(
                    layouts
                        .reference(CompactReferenceArray::LAYOUT, GcNullability::Nullable)
                        .heap_type,
                ),
                Instruction::StructNew(
                    layouts
                        .struct_type::<ArrayCompactDataStorage>()
                        .type_index()
                        .raw(),
                ),
            ]),
        );
        Self { index }
    }

    pub(super) fn index(&self) -> u32 {
        self.index
    }
}
