use super::*;
use wasmtime_environ::{
    copying::CopyingTypeLayouts, EngineOrModuleTypeIndex, GcTypeLayouts, ModuleInternedTypeIndex,
    WasmArrayType, WasmFieldType, WasmHeapType, WasmRefType, WasmStorageType, WasmStructType,
    WasmValType,
};

#[test]
fn shared_empty_array_properties_global_encodes_only_the_zero_key_graph() {
    for kind in [
        ModuleKind::Runtime(crate::RuntimeSourceCompilationProfile::NativeHost),
        ModuleKind::Runtime(crate::RuntimeSourceCompilationProfile::Portable),
        ModuleKind::Standalone,
    ] {
        let (runtime, bytes) = encoded(kind);
        let schema = runtime.globals().schema();
        let index = schema.empty_array_properties.index();
        let type_index = |layout| schema.layouts().layout_index(layout);
        let mut checked = false;
        for payload in Parser::new(0).parse_all(&bytes) {
            let Payload::GlobalSection(globals) = payload.unwrap() else {
                continue;
            };
            let global = globals.into_iter().nth(index as usize).unwrap().unwrap();
            assert!(!global.ty.mutable && !global.ty.shared);
            assert_eq!(
                global.ty.content_type,
                wasmparser::ValType::Ref(
                    wasmparser::RefType::new(
                        false,
                        wasmparser::HeapType::Concrete(wasmparser::UnpackedIndex::Module(
                            type_index(GcLayout::ArrayCompactDataStorage),
                        )),
                    )
                    .unwrap(),
                )
            );
            let operators = global
                .init_expr
                .get_operators_reader()
                .into_iter()
                .map(Result::unwrap)
                .collect::<Vec<_>>();
            let attributes = crate::heap::StoredPropertyAttributes::Data {
                writable: true,
                enumerable: true,
                configurable: true,
            }
            .descriptor_word()
            .as_i32();
            assert!(
                matches!(&operators[..], [
                wasmparser::Operator::ArrayNewFixed { array_type_index: keys, array_size: 0 },
                wasmparser::Operator::I32Const { value },
                wasmparser::Operator::StructNew { struct_type_index: shape },
                wasmparser::Operator::ArrayNewFixed { array_type_index: tags, array_size: 0 },
                wasmparser::Operator::RefNull { hty: scalars },
                wasmparser::Operator::RefNull { hty: references },
                wasmparser::Operator::StructNew { struct_type_index: storage },
                wasmparser::Operator::End,
            ] if *keys == type_index(GcLayout::CompactShapeKeys)
                && *value == attributes
                && *shape == type_index(GcLayout::CompactDataShape)
                && *tags == type_index(GcLayout::CompactTagArray)
                && *scalars == wasmparser::HeapType::Concrete(wasmparser::UnpackedIndex::Module(type_index(GcLayout::CompactScalarArray)))
                && *references == wasmparser::HeapType::Concrete(wasmparser::UnpackedIndex::Module(type_index(GcLayout::CompactReferenceArray)))
                && *storage == type_index(GcLayout::ArrayCompactDataStorage)),
                "the four-record graph has no Realm, user value or addressable mutable slot"
            );
            checked = true;
        }
        assert!(
            checked,
            "the declaration owns an actual nonnull immutable global"
        );
    }
}

#[test]
fn encoded_empty_array_properties_graph_costs_four_copying_collector_records() {
    let (runtime, bytes) = encoded(ModuleKind::Runtime(
        crate::RuntimeSourceCompilationProfile::Portable,
    ));
    let (types, _, _) = declarations(&bytes);
    let field = |field: &wasmparser::FieldType| {
        let element_type = match field.element_type {
            wasmparser::StorageType::I8 => WasmStorageType::I8,
            wasmparser::StorageType::Val(wasmparser::ValType::I32) => {
                WasmStorageType::Val(WasmValType::I32)
            }
            wasmparser::StorageType::Val(wasmparser::ValType::Ref(reference)) => {
                let wasmparser::HeapType::Concrete(wasmparser::UnpackedIndex::Module(index)) =
                    reference.heap_type()
                else {
                    panic!("the shared graph has only concrete typed edges");
                };
                let typed_index =
                    EngineOrModuleTypeIndex::Module(ModuleInternedTypeIndex::from_u32(index));
                let heap_type = match &types[index as usize].composite_type.inner {
                    CompositeInnerType::Struct(_) => WasmHeapType::ConcreteStruct(typed_index),
                    CompositeInnerType::Array(_) => WasmHeapType::ConcreteArray(typed_index),
                    unexpected => panic!("unexpected shared graph edge: {unexpected:?}"),
                };
                WasmStorageType::Val(WasmValType::Ref(WasmRefType {
                    nullable: reference.is_nullable(),
                    heap_type,
                }))
            }
            unexpected => panic!("unexpected shared graph field: {unexpected:?}"),
        };
        WasmFieldType {
            element_type,
            mutable: field.mutable,
        }
    };
    let record_size = |layout| {
        let index = runtime.globals().schema().layouts().layout_index(layout);
        match &types[index as usize].composite_type.inner {
            CompositeInnerType::Struct(ty) => {
                CopyingTypeLayouts
                    .struct_layout(&WasmStructType {
                        fields: ty
                            .fields
                            .iter()
                            .map(&field)
                            .collect::<Vec<_>>()
                            .into_boxed_slice(),
                    })
                    .unwrap()
                    .size
            }
            CompositeInnerType::Array(ty) => u32::try_from(
                CopyingTypeLayouts
                    .array_layout(&WasmArrayType(field(&ty.0)))
                    .layout(0)
                    .unwrap()
                    .pad_to_align()
                    .size(),
            )
            .unwrap(),
            unexpected => panic!("unexpected shared graph record: {unexpected:?}"),
        }
    };
    let graph = [
        GcLayout::CompactShapeKeys,
        GcLayout::CompactDataShape,
        GcLayout::CompactTagArray,
        GcLayout::ArrayCompactDataStorage,
    ]
    .map(record_size);
    assert_eq!(graph, [32, 32, 32, 32]);
    assert_eq!(graph.into_iter().sum::<u32>(), 128);
    assert_eq!(record_size(GcLayout::OrdinaryPropertyStorage), 32);
}
