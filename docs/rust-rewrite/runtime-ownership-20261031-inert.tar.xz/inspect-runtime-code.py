"""Inspect exact native R bytes as inert data outside scored runs; never load them."""
from pathlib import Path
import importlib.util,json
ROOT=Path('/workspace/scriptw');OUT=Path(__file__).resolve().parent
path=ROOT/'target/performance-memory-parity-20261031/diagnose-pages.py'
spec=importlib.util.spec_from_file_location('owned_runtime_inspector',path)
d=importlib.util.module_from_spec(spec);spec.loader.exec_module(d)
rows={}
for label,folder in [('baseline',ROOT/'target/performance-memory-parity-20261031'),('candidate',OUT)]:
    d.WORK=folder
    target=OUT/'code-size-private'/label;target.mkdir(parents=True,exist_ok=False)
    host,identity,record=d.extract_runtime('candidate',target)
    functions=[f for f in record['functions'] if 'helper::property_value_resolve' in f['name']]
    assert len(functions)==1
    rows[label]=dict(host=str(host),host_sha256=record['host_sha256'],source_commit=record['source_commit'],source_fingerprint=record['source_fingerprint'],runtime_key=record['runtime_key'],runtime_layout=record['runtime_layout'],native_sha256=record['native_sha256'],native_bytes=record['native_bytes'],runtime_text_bytes=record['text']['bytes'],resolver=functions[0],raw_symbols=str((target/'candidate-runtime-symbols.json').relative_to(OUT)))
assert rows['baseline']['source_fingerprint']=='6764a3510a89a7830e6277cd91df09c9fc2769da901bcf578d87e9289d7050c5'
assert rows['baseline']['runtime_layout']==41 and rows['candidate']['runtime_layout']==42
report=dict(schema='scriptw-inert-runtime-code-size-v1',scored=False,products=rows,changes_bytes={key:rows['candidate'][key]-rows['baseline'][key] for key in ['native_bytes','runtime_text_bytes']},resolver_change_bytes=rows['candidate']['resolver']['bytes']-rows['baseline']['resolver']['bytes'],limits='Verified own frozen executables decoded as bounded inert ELF data only. No payload loaded/executed, no child mapping capture, and no executed-function/page/RSS or causal memory claim. Extracted ELF files must stay outside the published inert archive.')
(OUT/'runtime-code-size.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2),flush=True)
