#!/usr/bin/env python3
"""Prepare documentation candidates without changing tracked documents."""
from pathlib import Path
import difflib
import hashlib
import json
import subprocess

ROOT = Path('/workspace/scriptw')
OUT = ROOT / 'target/performance-runtime-ownership-20261031'
BASE = OUT / 'documentation-base'
CANDIDATE = OUT / 'documentation-candidate'
originals = {}
candidates = {}


def change(path, before, after):
    if path not in originals:
        originals[path] = (ROOT / path).read_text()
        candidates[path] = originals[path]
    source = candidates[path]
    assert source.count(before) == 1, (path, before)
    candidates[path] = source.replace(before, after, 1)


change('README.md',
       '''Runtime initialization uses compact intrinsic-installation tables and defers
the Error, Temporal, Intl and binary-data intrinsic graphs until their first observable or internal use.
Each Realm retains its own canonical constructors, prototypes and descriptors.
''',
       '''Runtime initialization uses compact intrinsic-installation tables and defers
the Error, Temporal, Intl and binary-data intrinsic graphs until their first observable or internal use.
Deferred native methods share emitted code and string-resolution paths while
retaining their defining Realm, allocation order and independent callable state.
Each Realm retains its own canonical constructors, prototypes and descriptors.
''')
change('README.md',
       '''host execution stacks; callers own Store and Realm lifetimes. Runtime ABI 41
requires rebuilding older Portable bundles and native images. Native images use
binary execution facts (`SCRWEP03`).
''',
       '''host execution stacks; callers own Store and Realm lifetimes. ArrayCreate
shares immutable empty named-property storage; every Array retains its own header,
indexed data and independent named-property promotion. Runtime ABI 42 adds that
shared storage root and requires rebuilding older Portable bundles and native
images. Native images use binary execution facts (`SCRWEP03`). These ownership
changes do not yet establish timing or RSS benefits.
''')

change('docs/rust-rewrite/contracts/runtime-byte-ownership.md',
       'The current private runtime ABI is layout 41. Stored values put the 64-bit scalar\n',
       'The current private runtime ABI is layout 42. Stored values put the 64-bit scalar\n')
change('docs/rust-rewrite/contracts/runtime-byte-ownership.md',
       '''These are per-record layout sizes, not measured process RSS reductions. GC
headers, backing arrays, native code, compiler metadata and allocator retention
remain separate costs.
''',
       '''Layout 42 adds a nonnull immutable empty-Array named-storage root to the
canonical R/P global prefix. The global ledger declares it after the canonical
empty-array globals and before stored undefined, native metadata, snapshot roots
and per-program module guards. R exports its actual typed global; P references
it through the existing import and index-remapping machinery.
Snapshot roots and module guards still derive their positions from that ledger.
Older raw runtime packages, Portable bundles and native images must be rebuilt
for this changed global contract. No additional GC type or indexed storage mode
is introduced.

These are per-record layout sizes, not measured process RSS reductions. GC
headers, backing arrays, native code, compiler metadata and allocator retention
remain separate costs.
''')
change('docs/rust-rewrite/contracts/runtime-byte-ownership.md',
       '''a second object identity. These layout savings do not predict process RSS.

Eager Realm constructors allocate their initial dictionary metadata directly,
''',
       '''a second object identity. These layout savings do not predict process RSS.

ArrayCreate loads one runtime-owned empty named-property graph: a zero-key
CompactDataShape and its key array, zero tags, and ArrayCompactDataStorage with
null scalar/reference lanes. These four records occupy 128 bytes under the
pinned copying collector and contain no Realm or user references. The global
is initialized before bootstrap; every runtime instance owns its own graph.
Each Array still constructs a fresh ordinary header and indexed owner. Named
dictionary conversion replaces only the affected header's storage, including
Array.prototype's first named bootstrap definition. Ordinary object, native
metadata and frozen-template allocators retain their existing paths. Some read
paths also promote named storage; snapshots read the canonical empty graph
without promotion. This source-layout accounting establishes no timing or RSS
benefit. The [compact storage contract](compact-ordinary-data-storage.md)
defines enumeration, snapshot and mutation requirements.

Eager Realm constructors allocate their initial dictionary metadata directly,
''')
change('docs/rust-rewrite/contracts/runtime-byte-ownership.md',
       '''The callable shared by Array and TypedArray `toString` remains core-owned.

## Execution stacks
''',
       '''The callable shared by Array and TypedArray `toString` remains core-owned.

Deferred-method selection leaves carry typed builtin entry references and scalar
metadata into one shared construction tail. That tail allocates ExecutableCode,
resolves the pooled name, resolves the pooled source, then constructs the existing
header/context/callable graph in the original order. Earlier references remain
rooted across later allocations; recipe caching follows complete construction.
The dynamic allocation and resolution counts, aliases and defining-Realm owners
are unchanged. The [ordered installation contract](ordered-realm-bootstrap.md)
owns the exact selection and publication boundary. Smaller emitted duplication
does not establish native-code residency, timing or RSS savings.

## Execution stacks
''')

change('docs/rust-rewrite/contracts/compact-ordinary-data-storage.md',
       'The current private runtime ABI is layout 35. Compact ordinary property storage\n',
       'The current private runtime ABI is layout 42. Compact ordinary property storage\n')
change('docs/rust-rewrite/contracts/compact-ordinary-data-storage.md',
       '''current metadata values and follows ordinary structural mutation rules.

## Physical storage and value updates
''',
       '''current metadata values and follows ordinary structural mutation rules.

ArrayCreate uses a separate runtime-owned zero-key ArrayCompactDataStorage graph
from an immutable nonnull global. Its shape has default data attributes, its key
and tag arrays have length zero, and both scalar/reference lanes are null. With
no valid slot, existing compact writes cannot mutate this graph. Its four
records occupy 128 bytes under the pinned copying collector, once per runtime
instance/Store. It contains no Realm or user value. Each Array has a fresh
ordinary header and independent indexed storage. First dictionary conversion
publishes a fresh replacement on that header alone; Array.prototype likewise
promotes when bootstrap installs its first named property. Empty ordinary source
literals, native callable metadata and frozen template arrays retain their
existing allocators. The layout accounting does not measure timing or RSS.

## Physical storage and value updates
''')
change('docs/rust-rewrite/contracts/compact-ordinary-data-storage.md',
       '''order and existing integer-key sorter.

The native graph observer admits the exact canonical concrete inline or array
''',
       '''order and existing integer-key sorter. The compact-only shortcut excludes
Arrays: their own-key path must include occupied indices and virtual length
before named String/Symbol keys, including through Proxy forwarding and trap
invariant checks. That path can promote empty named storage to a fresh dictionary
without changing the Array's indexed state.

The native graph observer admits the exact canonical concrete inline or array
''')
change('docs/rust-rewrite/contracts/compact-ordinary-data-storage.md',
       '''Shared shape-field access does not weaken these concrete snapshot witnesses.

## Own-data read caches
''',
       '''Shared shape-field access does not weaken these concrete snapshot witnesses.
An Array header admits only zero-key ArrayCompactDataStorage with zero tags and
null scalar/reference lanes; nonempty compact Array storage and inline compact
Array headers remain invariant violations. Its occupied indices and length are
observed through the actual Array witness before the empty named graph, without
conversion, callbacks or a scan of logical Array length.

## Own-data read caches
''')

change('docs/rust-rewrite/contracts/ordered-realm-bootstrap.md',
       '''layout-33 admission; previous packages and cache entries are replaced.

`IntrinsicConstructorAllocate` receives the caller's already rooted native
''',
       '''layout-33 admission; previous packages and cache entries are replaced.

Deferred-method resolution retains its balanced exact-builtin-ID decision tree.
Its leaves select a checked OrdinaryCallable reference, paired source/builtin
identity, runtime name/source ordinals and length, without allocating a code
record or resolving a String. A private selection owner keeps the entry and
metadata together; unsupported entry protocols and program-owned string ordinals
fail emission, while an invalid or unselected runtime identity traps before
construction. No eager metadata table is introduced.

One shared tail then allocates ExecutableCode, resolves the pooled name, resolves
the pooled source and enters the existing native-header, FunctionContext,
FunctionObject and metadata-publication tail. Code, name and source remain
independently rooted across each subsequent allocation. String resolution can
allocate or trap and keeps its original position. Recipe caching follows complete
construction. Each materialized method retains the same dynamic allocation and
resolution counts, defining-Realm context, alias identities and mutable callable
state. Only the emitted sites are shared; no additional schema or helper ABI is
needed. Timing and native-memory effects require separate measurement.

`IntrinsicConstructorAllocate` receives the caller's already rooted native
''')

change('docs/performance-hills.md',
       '| P156/P157 — emitted size | Measure folding repeated deferred-method executable-code allocation and pooled-string resolution into the existing shared construction tail. Preserve exact builtin entries, defining-Realm identities, allocation order and reflective reachability. |',
       '| P156/P157 — emitted size | Measure the shared deferred-method executable-code and pooled-string construction tail against the accepted fusion source. Dynamic allocation counts, exact builtin entries, defining-Realm identities, allocation order and reflective reachability remain unchanged; emitted-site counts do not establish native residency or RSS savings. |')
change('docs/performance-hills.md',
       '| Empty Array headers | Can ArrayCreate share immutable zero-key compact named storage? Preserve indexed keys and virtual length in own-key enumeration, exact snapshot witnesses and independent promotion; keep ordinary/native/frozen-template allocators separate in the first experiment. |',
       '| Empty Array headers | Measure ArrayCreate\'s shared immutable zero-key named storage against the accepted fusion source. Its 128-byte/four-record fixed graph and independent promotion are layout facts; validate indexed keys, virtual length, exact snapshots and freeze/seal on fresh Arrays, then require repeatable target benefit with acceptable controls. Ordinary/native/frozen-template allocators retain their paths. |')

change('docs/rust-rewrite/current-inventory.md',
       '''products and both balanced orders. Next measure shared empty Array named
  storage and one shared deferred-method code/string construction tail. Preserve
  exotic own keys, exact rooted snapshots, independent named-storage promotion,
  defining-Realm identities and allocation order.
''',
       '''products and both balanced orders. Measure the runtime ownership batch
  against the accepted fusion source: ArrayCreate's shared empty named graph
  (128 bytes/four fixed records) and the shared deferred-method code/string tail.
  Keep static layout/site accounting separate from timing and RSS; benefits remain
  unestablished. Preserve exotic own keys, exact rooted snapshots, independent
  promotion, freeze/seal on fresh Arrays, dynamic allocation order, aliases and
  defining-Realm identities. Require repeatable target benefit and acceptable
  ordinary, retained, startup and integer controls before acceptance.
''')

# Preserve the rejected numeric hypothesis and all published suite/chart identities.
readme = originals['README.md']
updated = candidates['README.md']
assert readme[readme.index('## Tests\n'):] == updated[updated.index('## Tests\n'):]
assert [line for line in readme.splitlines() if '<img ' in line] == [
    line for line in updated.splitlines() if '<img ' in line
]
numeric = readme[readme.index('Moving the existing numeric Array probe before `ToObject`'):readme.index('\n## Tests')]
assert numeric in updated
for path in ['docs/performance-hills.md', 'docs/rust-rewrite/current-inventory.md']:
    assert 'numeric-getv-probe-20261031.json' in candidates[path]

patch = []
manifest = {
    'base_head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
    'scope': 'Small documentation files only; current working contents include the numeric rejection prose.',
    'files': {},
    'validation': 'Target-only draft. No tracked edits, builds, tests, product/native execution, or large artifact hashing.',
}
for path in sorted(originals):
    before, after = originals[path], candidates[path]
    for directory, contents in [(BASE, before), (CANDIDATE, after)]:
        destination = directory / path
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_text(contents)
    patch.append(''.join(difflib.unified_diff(
        before.splitlines(keepends=True), after.splitlines(keepends=True),
        fromfile='a/' + path, tofile='b/' + path,
    )))
    manifest['files'][path] = {
        'base_sha256': hashlib.sha256(before.encode()).hexdigest(),
        'candidate_sha256': hashlib.sha256(after.encode()).hexdigest(),
    }
(OUT / 'documentation.patch').write_text(''.join(patch))
(OUT / 'documentation-base-hashes.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'files': list(manifest['files']), 'patch_lines': sum(len(part.splitlines()) for part in patch)}))
