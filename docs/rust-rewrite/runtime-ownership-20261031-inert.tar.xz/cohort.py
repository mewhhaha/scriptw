from pathlib import Path
import hashlib, json, os, shutil, statistics, subprocess, sys, tarfile, time
ROOT=Path('/workspace/scriptw'); OUT=ROOT/'target/performance-runtime-ownership-20261031'
OLD=ROOT/'target/performance-memory-parity-20261031'
BASELINE=OLD/'candidate'
sys.path.insert(0,str(ROOT/'scripts'))
from benchmark_metrics import measure_process
from limited_verification import require_cloud_budget, kernel_group
TIME=Path('/workspace/toolchains/system/usr/bin/time')
NODE=Path(shutil.which('node'))
NODE_HARNESS=ROOT/'crates/scriptw-cli/tests/fixtures/v8_baseline/node-runtime.cjs'
FIX=ROOT/'crates/scriptw-cli/tests/fixtures/v8_execution_hotpaths'
PLAN=json.loads((FIX/'manifest.json').read_text())
def digest(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
def host(label):return (BASELINE if label=='baseline' else OUT/'candidate')/'compiler_precompiled_baseline'
def runner(label):return (BASELINE if label=='baseline' else OUT/'candidate')/'runtime_baseline'
def invoke(stem,argv,timeout=900,node=False):
 print(stem,flush=True)
 env=dict(os.environ)
 if node:
  assert not env.get('NODE_OPTIONS')
  env.pop('NODE_COMPILE_CACHE',None);env['NODE_DISABLE_COMPILE_CACHE']='1'
 with (OUT/(stem+'.stdout')).open('xb') as out,(OUT/(stem+'.stderr')).open('xb') as err:
  r=measure_process(list(map(str,argv)),cwd=ROOT,env=env,stdout=out,stderr=err,timeout=timeout,time_binary=TIME)
 r.update(argv=list(map(str,argv)),executable_sha256=digest(argv[0]),cwd=str(ROOT))
 save(OUT/(stem+'.command.json'),r)
 assert r['exit_code']==0 and not r['timed_out'],r
 return json.loads((OUT/(stem+'.stdout')).read_text())
def resources():
 return dict(cloud_budget_bytes=require_cloud_budget(),affinity=sorted(os.sched_getaffinity(0)),cgroup={k:(kernel_group()/k).read_text().strip() for k in ('memory.max','memory.swap.max','memory.oom.group','cpu.max','memory.events')})
def prepare(label):
 if not (OUT/'sources').exists():
  shutil.copytree(FIX,OUT/'sources')
  plan=dict(PLAN);plan['execution']=[*PLAN['execution'],PLAN['startup']]
  save(OUT/'sources/manifest.json',plan)
 invoke(label+'-prepare-original',[host(label),'prepare-scriptw',OUT/'sources',OUT/(label+'-original')])
 if label=='candidate':invoke(label+'-prepare-retained',[host(label),'prepare-retained',FIX,OUT/(label+'-retained')])
def scriptc():
 report=json.loads((ROOT/'docs/rust-rewrite/precompiled-comparison.json').read_text())
 assert digest(ROOT/'docs/rust-rewrite/precompiled-comparison.tar.gz')==report['archive']['sha256']
 directory=OUT/'scriptc-wasm';directory.mkdir()
 images=OUT/'scriptc-native';images.mkdir()
 with tarfile.open(ROOT/'docs/rust-rewrite/precompiled-comparison.tar.gz') as tar:
  for case in PLAN['execution']:
   name=case['file'];member=tar.getmember('wasm/scriptc/'+name+'.wasm')
   original=next(f for f in report['retained_files'] if f['path']=='sources/'+name)
   assert digest(FIX/name)==original['sha256']
   assert next(c['stdout'] for c in report['workloads'] if c['file']==name)==case['stdout']
   assert member.isfile() and member.size<4*1024**2
   data=tar.extractfile(member).read(member.size+1);assert len(data)==member.size
   expected=next(a['image']['program_wasm_sha256'] for a in report['attempts'] if a['runtime']=='scriptc' and a['file']==name)
   assert hashlib.sha256(data).hexdigest()==expected
   (directory/(name+'.wasm')).write_bytes(data)
   invoke('scriptc-precompile-'+name,[host('candidate'),'prepare-wasi',directory/(name+'.wasm'),images/(name+'.cwasm')])
 save(OUT/'scriptc-origin.json',dict(report_sha256=digest(ROOT/'docs/rust-rewrite/precompiled-comparison.json'),archive_sha256=digest(ROOT/'docs/rust-rewrite/precompiled-comparison.tar.gz'),source_commit=report['source_commit'],tools=report['tools'],note='Only bounded digest-checked raw Wasm extracted. Fresh native images produced locally; no archived native code executed.'))
def measure(prefix,order):
 identities={label:json.loads(((BASELINE if label=='baseline' else OUT/'candidate')/'identity.json').read_text()) for label in ('baseline','candidate')}
 assert identities['baseline']['shared_configuration']==identities['candidate']['shared_configuration']
 save(OUT/(prefix+'-resources-before.json'),resources())
 save(OUT/(prefix+'-node-identity.json'),dict(path=str(NODE),sha256=digest(NODE),harness_sha256=digest(NODE_HARNESS),versions=json.loads(subprocess.check_output([str(NODE),'-p','JSON.stringify(process.versions)'],text=True))))
 for round_index,label in enumerate(order):
  art=OUT/(prefix+f'-r{round_index}-ordinary');art.mkdir()
  cases=PLAN['execution'] if round_index%2==0 else list(reversed(PLAN['execution']))
  for case in cases:
   name=case['file'];base=prefix+f'-r{round_index}-{label}-'
   if round_index%2==0:invoke(base+'v8-'+name,[NODE,NODE_HARNESS,FIX,'21','10',name],node=True)
   invoke(base+'original-'+name,[host(label),'execute-scriptw',(OLD/'candidate-original' if label=='baseline' else OUT/'candidate-original')/(name+'.swpc'),case['stdout'],'21','10'])
   retained=(OLD/'candidate-retained' if label=='baseline' else OUT/'candidate-retained')/(name+'.retained.swpc')
   invoke(base+'retained-'+name,[host(label),'execute-retained',retained,case['stdout'],'21','10'])
   invoke(base+'ordinary-'+name,[runner(label),FIX,'21','10',name,art])
   if round_index%2==1:invoke(base+'v8-'+name,[NODE,NODE_HARNESS,FIX,'21','10',name],node=True)
  case=PLAN['startup'];invoke(prefix+f'-r{round_index}-{label}-startup',[host(label),'execute-scriptw',(OLD/'candidate-original' if label=='baseline' else OUT/'candidate-original')/(case['file']+'.swpc'),case['stdout'],'21','10'])
 save(OUT/(prefix+'-resources-after.json'),resources())
 analyze(prefix,order)
def analyze(prefix,order):
 rows=[]
 for case in PLAN['execution']:
  row=dict(file=case['file'],source_sha256=digest(FIX/case['file']))
  for boundary in ('original','retained','ordinary'):
   products={}
   for label in ('baseline','candidate'):
    folder=BASELINE if label=='baseline' else OUT/'candidate'
    identity=json.loads((folder/'identity.json').read_text());products_meta=json.loads((folder/'products.json').read_text())
    scores=[];rss=[];rounds=[]
    for i,l in enumerate(order):
     if l!=label:continue
     stem=prefix+f'-r{i}-{label}-{boundary}-'+case['file']
     v=json.loads((OUT/(stem+'.stdout')).read_text())
     tool='runtime_baseline' if boundary=='ordinary' else 'compiler_precompiled_baseline'
     assert v['source_fingerprint']==identity['source_fingerprint'] and v['executable_sha256']==products_meta[tool]['sha256']
     if boundary=='ordinary':assert v['cases'][0]['source_sha256']==row['source_sha256']
     values=v['cases'][0]['observations'] if boundary=='ordinary' else v['observations']
     assert len(values)==31 and all(o.get('matched',True) and o['stdout']==case['stdout'] for o in values)
     samples=[o for o in values if not o['warmup']];assert len(samples)==21
     times=[o['call_ns'] if boundary=='retained' else o['phases_ns']['execution'] if boundary=='original' else o['execution_ns'] for o in samples];scores+=times
     if boundary=='original':rss += [o['process_snapshots']['after_execution']['rss_bytes'] for o in samples]
     rounds.append(dict(index=i,median_ns=statistics.median(times),raw=stem+'.stdout'))
    products[label]=dict(median_ns=statistics.median(scores),rounds=rounds)
    if rss:products[label]['rss_bytes']=statistics.median(rss)
   row[boundary]=dict(products=products,change_percent=100*(products['candidate']['median_ns']/products['baseline']['median_ns']-1))
  rows.append(row)
  v8=[];v8_rounds=[]
  for i,label in enumerate(order):
   stem=prefix+f'-r{i}-{label}-v8-'+case['file'];v=json.loads((OUT/(stem+'.stdout')).read_text());actual=v['cases'][0]
   assert v['samples']==21 and v['warmups']==10 and len(actual['observations'])==31
   assert actual['file']==case['file'] and actual['source_sha256']==row['source_sha256'] and all(o['stdout']==case['stdout'] for o in actual['observations'])
   values=[o['execution_ns'] for o in actual['observations'] if not o['warmup']];assert len(values)==21
   v8+=values;v8_rounds.append(dict(index=i,median_ns=statistics.median(values),raw=stem+'.stdout'))
  row['v8_reference']=dict(median_ns=statistics.median(v8),rounds=v8_rounds,scope='Existing vm.Script fresh-Realm Node harness; same original source; current Node version retained separately. No published chart refresh.')
 save(OUT/(prefix+'-analysis.json'),dict(order=order,samples=21,warmups=10,workloads=rows,scope='local same-machine before/after diagnostic; original precompiled fresh Store, retained strict-derived call and ordinary runner are separate cohorts; no parity or published comparison claim'))
 for r in rows:print(r['file'],*[f'{b}={r[b]["change_percent"]:+.2f}%' for b in ('original','retained','ordinary')],flush=True)
if __name__=='__main__':
 OUT.mkdir(exist_ok=True,parents=True)
 if sys.argv[1]=='prepare':prepare(sys.argv[2])
 elif sys.argv[1]=='scriptc':scriptc()
 elif sys.argv[1]=='measure':measure(sys.argv[2],sys.argv[3:])
 elif sys.argv[1]=='analyze':analyze(sys.argv[2],sys.argv[3:])
