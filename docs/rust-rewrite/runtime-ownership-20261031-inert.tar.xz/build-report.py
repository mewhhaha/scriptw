"""Assemble report-core.json after the runtime-ownership cohort completes; never publish."""
from pathlib import Path
import datetime
import hashlib
import json
import math
import re
import statistics

ROOT = Path('/workspace/scriptw')
OUT = Path(__file__).resolve().parent
PARENT = 'e15843397c217c0e113c50e2164c0d1fa5552112'
BASELINE = '6764a3510a89a7830e6277cd91df09c9fc2769da901bcf578d87e9289d7050c5'
REPAIRED_TEST = 'tests::array_data_producers::array_create_loads_shared_empty_named_storage_but_keeps_its_fresh_header'
REPAIRED_SOURCE = 'crates/scriptw-aot-wasm/src/tests/array_data_producers.rs'
SCOPES = {
    ('scriptw-aot-wasm', 'scriptw_aot_wasm'): 568,
    ('scriptw-aot-wasm', 'emission'): 41,
    ('scriptw-aot-wasm', 'runtime_link'): 31,
    ('scriptw-aot-wasm', 'structure_builtins'): 172,
    ('scriptw-aot-wasm', 'structure_language'): 152,
    ('scriptw-engine', 'scriptw_engine'): 34,
    ('scriptw-engine', 'aot_builtins'): 570,
    ('scriptw-engine', 'aot_gc_entries'): 257,
    ('scriptw-engine', 'aot_language'): 386,
    ('scriptw-engine', 'aot_realm_modules'): 438,
    ('scriptw-engine', 'runtime_cache'): 4,
}



def read(name):
    path = OUT / name
    assert path.stat().st_size <= 16 * 1024**2, path
    return json.loads(path.read_text())


def digest(path):
    # Only source/patch inputs are hashed here; product identities come from receipts.
    assert path.stat().st_size <= 4 * 1024**2, path
    return hashlib.sha256(path.read_bytes()).hexdigest()


def outcome(case, passed, failed=0):
    assert case['outcomes'] == [dict(passed=passed, failed=failed, ignored=0)]
    assert case['state'] == ('failed' if failed else 'passed')
    assert case['exit_code'] == (101 if failed else 0)


def raw_files(stdout):
    assert stdout.endswith('.stdout') and Path(stdout).name == stdout, stdout
    stem = stdout.removesuffix('.stdout')
    paths = dict(stdout=stdout, stderr=stem + '.stderr', command=stem + '.command.json')
    assert all((OUT / name).is_file() for name in paths.values()), paths
    return paths


def validate_analysis(name, order, expected, identities, product_records, node_identity):
    report = read(name)
    assert report['order'] == order
    assert report['samples'] == 21 and report['warmups'] == 10
    rows = report['workloads']
    assert len(rows) == len(expected) == 17
    assert len({row['file'] for row in rows}) == 17
    assert {row['file'] for row in rows} == set(expected)
    raw = []
    for row in rows:
        assert row['source_sha256'] == digest(OUT / 'sources' / row['file'])
        for boundary in ('original', 'retained', 'ordinary'):
            products = row[boundary]['products']
            assert set(products) == {'baseline', 'candidate'}
            for label, values in products.items():
                assert math.isfinite(values['median_ns']) and values['median_ns'] > 0
                rounds = values['rounds']
                assert [r['index'] for r in rounds] == [i for i, actual in enumerate(order) if actual == label]
                paths = [raw_files(r['raw']) for r in rounds]
                raw.extend(paths)
                scores = []
                for files in paths:
                    record = read(files['stdout'])
                    command = read(files['command'])
                    tool = 'runtime_baseline' if boundary == 'ordinary' else 'compiler_precompiled_baseline'
                    identity = product_records[label][tool]['sha256']
                    assert command['exit_code'] == 0 and not command['timed_out']
                    assert command['executable_sha256'] == identity
                    assert record['source_fingerprint'] == identities[label]['source_fingerprint']
                    assert record['executable_sha256'] == identity
                    if boundary != 'ordinary':
                        assert record['compiler_enabled'] is False
                    else:
                        assert record['cases'][0]['source_sha256'] == row['source_sha256']
                    observations = record['cases'][0]['observations'] if boundary == 'ordinary' else record['observations']
                    assert len(observations) == 31
                    assert all(o.get('matched', True) and o['stdout'] == expected[row['file']]['stdout'] for o in observations)
                    samples = [o for o in observations if not o['warmup']]
                    assert len(samples) == 21
                    scores.extend(o['call_ns'] if boundary == 'retained' else o['phases_ns']['execution'] if boundary == 'original' else o['execution_ns'] for o in samples)
                assert statistics.median(scores) == values['median_ns']
            calculated = 100 * (products['candidate']['median_ns'] / products['baseline']['median_ns'] - 1)
            assert math.isclose(row[boundary]['change_percent'], calculated, abs_tol=1e-9)
        reference = row['v8_reference']
        assert reference['median_ns'] > 0 and math.isfinite(reference['median_ns'])
        assert [r['index'] for r in reference['rounds']] == list(range(4))
        v8_scores = []
        for round_row in reference['rounds']:
            paths = raw_files(round_row['raw'])
            raw.append(paths)
            command, record = read(paths['command']), read(paths['stdout'])
            assert command['exit_code'] == 0 and not command['timed_out']
            assert command['executable_sha256'] == node_identity['sha256']
            assert record['samples'] == 21 and record['warmups'] == 10
            case = record['cases'][0]
            assert case['file'] == row['file'] and case['source_sha256'] == row['source_sha256']
            assert len(case['observations']) == 31
            assert all(o['stdout'] == expected[row['file']]['stdout'] for o in case['observations'])
            samples = [o for o in case['observations'] if not o['warmup']]
            assert len(samples) == 21
            v8_scores.extend(o['execution_ns'] for o in samples)
        assert statistics.median(v8_scores) == reference['median_ns']
    return report, raw


def startup_rows(prefix, order, expected_stdout, identities, products):
    rows = []
    for index, label in enumerate(order):
        stem = f'{prefix}-r{index}-{label}-startup'
        paths = raw_files(stem + '.stdout')
        command = read(paths['command'])
        assert command['exit_code'] == 0 and not command['timed_out']
        record = read(paths['stdout'])
        assert record['source_fingerprint'] == identities[label]['source_fingerprint']
        product = products[label]['compiler_precompiled_baseline']['sha256']
        assert command['executable_sha256'] == record['executable_sha256'] == product
        assert record['compiler_enabled'] is False
        observations = record['observations']
        assert len(observations) == 31
        assert all(o['matched'] and o['stdout'] == expected_stdout for o in observations)
        samples = [o for o in observations if not o['warmup']]
        assert len(samples) == 21
        rows.append(dict(
            index=index, product=label, raw=paths,
            median_execution_ns=statistics.median(o['phases_ns']['execution'] for o in samples),
        ))
    return rows


def main():
    interrupted = read('native-runtime-ownership/receipt.json')
    initial = read('native-runtime-ownership-v2/receipt.json')
    final = read('native-runtime-ownership-final/receipt.json')
    for receipt in (interrupted, initial, final):
        assert receipt['head'] == PARENT and receipt['source_unchanged']
        assert receipt['shared_runtime_linker_unchanged']
    assert all(not case.get('outcomes') for case in interrupted['cases'])
    cases = {(case['package'], case['target']): case for case in initial['cases']}
    assert len(initial['cases']) == len(cases) == len(SCOPES) == 11
    assert set(cases) == set(SCOPES)
    for key, count in SCOPES.items():
        if key == ('scriptw-aot-wasm', 'scriptw_aot_wasm'):
            outcome(cases[key], 567, 1)
        else:
            outcome(cases[key], count)
    assert len(final['cases']) == 1
    repaired_case = final['cases'][0]
    assert (repaired_case['package'], repaired_case['target']) == ('scriptw-aot-wasm', 'scriptw_aot_wasm')
    assert repaired_case['native_filter'] == REPAIRED_TEST
    assert REPAIRED_TEST in repaired_case['command'] and repaired_case['inventory_matches']
    outcome(repaired_case, 1)
    assert sum(SCOPES.values()) == 2653

    api_repair = read('test-api-repair.json')
    assert api_repair['production_rust_change'] is False
    selection_repair = read('test-source-selection-repair/plan.json')
    assert selection_repair['production_unchanged'] is True
    assert selection_repair['affected_test'] == REPAIRED_TEST
    previous_inputs = read('compiled-inputs-v2.json')
    inputs = read('compiled-inputs-v3.json')
    assert len(previous_inputs) == len(inputs) == 22
    assert set(previous_inputs) == set(inputs)
    checked_inputs, changed_crate_inputs = {}, []
    for name, record in inputs.items():
        if name.startswith(('crates/', 'fixtures/')):
            assert not Path(name).is_absolute() and '..' not in Path(name).parts
            assert digest(ROOT / name) == record['sha256'], name
            checked_inputs[name] = record
            if record != previous_inputs[name]:
                changed_crate_inputs.append(name)
    assert set(changed_crate_inputs) == {REPAIRED_SOURCE}
    repaired_source = (ROOT / REPAIRED_SOURCE).read_text()
    assert re.search(r'\[\s*makeArray\s*,\s*makeObject\s*\]\s*;', repaired_source)
    runtime_source_path = 'crates/scriptw-aot-wasm/src/runtime_artifact.rs'
    assert runtime_source_path in checked_inputs
    assert re.search(r'const\s+LAYOUT_VERSION\s*:\s*u32\s*=\s*42\s*;', (ROOT / runtime_source_path).read_text())

    identities = dict(baseline=read('baseline-identity.json'), candidate=read('candidate/identity.json'))
    candidate_fingerprint = identities['candidate']['source_fingerprint']
    assert re.fullmatch(r'[0-9a-f]{64}', candidate_fingerprint)
    assert candidate_fingerprint not in {BASELINE, 'c615b6e3b896f4aedc8a4292199a11e27114e914d1e6970fe67b3ea8790a03d1'}
    assert identities['candidate']['source_commit'] == PARENT
    assert identities['baseline']['source_fingerprint'] == BASELINE
    assert identities['baseline']['source_commit'] == '69ce371b964cc3af8da79750507ba5018eb2aef2'
    assert identities['baseline']['shared_configuration'] == identities['candidate']['shared_configuration']
    baseline_reuse = read('baseline-reuse-proof.json')
    assert baseline_reuse['parent_commit'] == PARENT
    assert baseline_reuse['accepted_production_commit'] == '658d61568f82b088fcff8783a3fc5073be1fc3f3'
    assert baseline_reuse['baseline_original_identity'] == identities['baseline']
    products = dict(baseline=read('baseline-products.json'), candidate=read('candidate/products.json'))
    for label in products:
        assert set(products[label]) == {'compiler_precompiled_baseline', 'runtime_baseline', 'scriptw'}
        assert products[label]['compiler_precompiled_baseline']['sha256'] == identities[label]['executable_sha256']
    assert baseline_reuse['baseline_products'] == products['baseline']
    build = read('candidate-build.json')
    assert build['head'] == PARENT and build['exit_code'] == 0

    test262_plan = read('test262-plan.json')
    families = test262_plan['families']
    assert len(families) == 25 and len({row['scope'] for row in families}) == 25
    assert sum(row['js_files'] for row in families) == test262_plan['js_files'] == 709
    suite = read('test262-candidate-summary.json')
    assert len(suite['runs']) == 25
    assert {row['scope'] for row in suite['runs']} == {row['scope'] for row in families}
    for run in suite['runs']:
        assert run['product'] == 'candidate' and run['exit_code'] == 0
        assert run['passed'] == run['total'] and run['total'] > 0
        assert run['executable_sha256'] == products['candidate']['scriptw']['sha256']
        assert Path(run['raw']).name == run['raw'] and (OUT / run['raw']).is_file()
    test262_executions = sum(run['passed'] for run in suite['runs'])

    guards = (OUT / 'source-guards.log').read_text()
    assert sum(map(int, re.findall(r'test result: ok\. (\d+) passed; 0 failed;', guards))) == 359
    assert 'ok (30 permanent areas)' in (OUT / 'ownership.log').read_text()
    assert len(re.findall(r'^PASS ', (OUT / 'intl-source.log').read_text(), re.M)) == 15
    audit = dict(status='not separately recorded for this cohort')
    if (OUT / 'product-graph.log').exists():
        assert 'check-no-interpreter-in-product-graph: ok' in (OUT / 'product-graph.log').read_text()
        audit = dict(status='passed', raw='product-graph.log')

    manifest = read('sources/manifest.json')
    startup = manifest['startup']
    expected = {row['file']: row for row in manifest['execution'] if row['file'] != startup['file']}
    assert len(expected) == 17
    orders = dict(initial=['baseline', 'candidate', 'candidate', 'baseline'])
    if (OUT / 'confirmation-analysis.json').exists():
        orders['confirmation'] = ['candidate', 'baseline', 'baseline', 'candidate']
    cohorts, raw_index, startup_controls, resources = {}, {}, {}, {}
    for prefix, order in orders.items():
        resources[prefix] = dict(before=read(prefix + '-resources-before.json'),
                                 after=read(prefix + '-resources-after.json'),
                                 node_identity=read(prefix + '-node-identity.json'))
        cohorts[prefix], raw_index[prefix] = validate_analysis(
            prefix + '-analysis.json', order, expected, identities, products, resources[prefix]['node_identity'],
        )
        startup_controls[prefix] = startup_rows(prefix, order, startup['stdout'], identities, products)
    table = []
    for name in expected:
        row = dict(file=name, source_sha256=None, cohorts={})
        for prefix, analysis in cohorts.items():
            actual = next(value for value in analysis['workloads'] if value['file'] == name)
            if row['source_sha256'] is None:
                row['source_sha256'] = actual['source_sha256']
            assert actual['source_sha256'] == row['source_sha256']
            row['cohorts'][prefix] = {key: actual[key] for key in ('original', 'retained', 'ordinary', 'v8_reference')}
        table.append(row)
    optional_controls = {}
    for path in sorted(OUT.glob('*control*-analysis.json')):
        control = read(path.name)
        assert isinstance(control, dict) and control
        if 'complete' in control:
            assert control['complete']
        optional_controls[path.name] = control
    diagnostics = {}
    if (OUT / 'scriptc-comparison.json').exists():
        comparison = read('scriptc-comparison.json')
        if comparison.get('complete') is True:
            diagnostics['scriptc_comparison'] = comparison
        else:
            diagnostics['scriptc_comparison_pending'] = dict(raw='scriptc-comparison.json',
                                                            scope='Incomplete optional comparison; excluded from measured claims.')
    code_size_paths = set(OUT.glob('*code*size*.json'))
    nested_code_size = OUT / 'code-size-diagnostic/report.json'
    if nested_code_size.is_file():
        code_size_paths.add(nested_code_size)
    code_size = {}
    for path in sorted(code_size_paths):
        name = str(path.relative_to(OUT))
        diagnostic = read(name)
        assert isinstance(diagnostic, dict) and diagnostic
        code_size[name] = diagnostic
    if code_size:
        diagnostics['code_size'] = dict(reports=code_size,
                                       scope='Optional saved JSON diagnostics only; code-site counts do not imply native byte or resident-page savings.')

    array_count = 8193
    assert array_count * 32 - 128 == 262048 and array_count - 4 == 8189
    report = dict(
        schema='scriptw-runtime-ownership-v1',
        recorded_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        status='measured; retention decision remains with reviewer',
        source=dict(
            parent_commit=PARENT, candidate_fingerprint=candidate_fingerprint, baseline_fingerprint=BASELINE,
            candidate_identity=identities['candidate'], baseline_identity=identities['baseline'],
            candidate_build=build, baseline_reuse_proof=baseline_reuse,
            patches={path.name: digest(path) for path in sorted(OUT.glob('compile-inputs*.patch'))},
            source_snapshots=dict(initial='compiled-inputs.json', corrected_api='compiled-inputs-v2.json',
                                  final_source_fixture='compiled-inputs-v3.json'),
            inputs=inputs, verified_current_crate_fixture_inputs=checked_inputs,
            source_fixture_change=dict(path=REPAIRED_SOURCE, before=previous_inputs[REPAIRED_SOURCE],
                                       after=inputs[REPAIRED_SOURCE], excluded_from_compiler_fingerprint=True),
            identity_note='Candidate is the frozen parent e15843397 plus the recorded 22-file patch/snapshots, with its actual fingerprint read from candidate/identity.json; not a clean-parent build. Baseline is accepted fusion originally built from 69ce371b plus its exact patch, fingerprint 6764a351, with extended source-bound reuse proof. Rejected numeric c615 products are excluded. Current crate/fixture hashes must match v3; README/docs may receive measured prose after snapshotting.',
        ),
        change=dict(
            runtime_layout_before=41, runtime_layout_version=42, abi_layout_changed=True, default_policy_changed=False,
            arrays=dict(
                behavior='ArrayCreate loads one shared immutable zero-key compact named-storage graph. Array headers and indexed owners remain fresh; named mutations promote through existing ownership paths; snapshots and exotic own-key consumers accept the valid compact representation.',
                shared_graph_bytes=128, shared_graph_records=4, old_empty_dictionary_bytes_per_array=32,
                conditional_fixture_arrays=array_count, conditional_net_bytes_removed=262048,
                conditional_net_records_removed=8189,
                accounting_scope='Static heap-layout accounting: if all 8193 relevant ArrayCreate instances would otherwise retain distinct 32-byte empty dictionaries, replacing those records with one 128-byte/four-record shared graph yields 8193*32-128 bytes and 8193-4 records removed. This is conditional structural accounting, not measured live heap, process RSS or peak memory.',
            ),
            resolver=dict(
                code_allocation_sites_before=823, code_allocation_sites_after=1,
                string_resolution_call_sites_before=1646, string_resolution_call_sites_after=2,
                behavior='Selected deferred-method metadata passes through one shared code-allocation tail and two ordered string-resolution sites. Runtime dynamic allocation/string counts, evaluation order, Realm identity and GC rooting remain unchanged; no eager metadata table is introduced.',
                scope='Emitted resolver code-site counts; no inferred native code-size, page residency or JavaScript allocation reduction.',
            ),
            attribution='The time/RSS cohort measures the combined batch only. Separate structural record/byte counts and resolver call-site counts do not causally apportion the observed process-level difference.',
        ),
        products=products,
        validation=dict(
            native_passing_cases=2653, native_unique_scopes=11,
            retained_native_scopes=[dict(package=p, target=t, passed=n) for (p, t), n in SCOPES.items()],
            interrupted_build='native-runtime-ownership/receipt.json', initial='native-runtime-ownership-v2/receipt.json',
            final='native-runtime-ownership-final/receipt.json', native_streams=read('native-stream-index.json'),
            test_api_repair=api_repair, source_fixture_repair=selection_repair,
            source_bound_continuation=dict(unchanged_crate_fixture_inputs=[name for name in checked_inputs if name != REPAIRED_SOURCE],
                                           changed_test_source=REPAIRED_SOURCE,
                                           proof='The v2 and v3 manifests differ among crate/fixture inputs only in the source-selection test fixture; all production inputs remain byte-identical, and each native receipt preserves its source and executable identities.'),
            native_count_note='2653 unique retained cases = 568+41+31+172+152+34+570+257+386+438+4. The interrupted initial build executed zero tests and contributes no passes. The fresh v2 library run passed 567 and failed one new source-selection fixture; its exact repaired library test later passed once. All other ten completed v2 scopes are retained. No fresh full 568-case library run on the final fixture is claimed; no failed or rerun case is counted twice.',
            test262_selected_js_files=709, test262_selected_family_count=25,
            test262_passing_executions=test262_executions, test262_plan=test262_plan,
            test262_original_families=suite,
            test262_inventory_note='709 is the planned on-disk JavaScript file count. Passing strict/sloppy/module/negative executions are taken only from the completed 25-run summary and may differ from that file count.',
            source_only_guards=359, conformance_owners=30, intl_recipes=15,
            product_interpreter_audit=audit,
            formatting=dict(changed_rust='All 15 changed Rust files formatted with edition 2021 per cohort record.',
                            full_workspace='Inherited 17 pre-existing file failures remain unresolved; no fresh full-workspace formatting or release acceptance claim.'),
        ),
        failures_preserved=[
            dict(kind='interrupted-private-test-api-build', receipt='native-runtime-ownership/receipt.json',
                 reason='The union build exposed two uses of a private test API and was interrupted before native test execution. test-api-repair.json records use of the existing typed public-to-crate schema authority; no passing scopes existed to reuse.'),
            dict(kind='source-consumer-selection', receipt='native-runtime-ownership-v2/receipt.json',
                 executable=read('failed-native/identity.json'),
                 reason='A function-name prefix also matched an exact_helper_context clone after direct known calls. The source-only fixture now publishes [makeArray,makeObject], retaining an unspecialized consumer. Production code is unchanged; the exact repaired test result is retained separately.'),
            dict(kind='failed-native-archive-exclusion',
                 scope='Failed binaries in failed-native are excluded from the inert archive. Failed receipts, executable identities and sealed full build/test streams remain evidence.'),
        ],
        measurement=dict(
            plan=read('measurement-plan.json'), cohorts=table, complete_cohort_reports=cohorts,
            raw_stream_index=raw_index, startup_controls=startup_controls,
            optional_targeted_controls=optional_controls, resources=resources,
            boundaries='All 17 unchanged originals use compiler-disabled precompiled fresh Store/Realm execution. Strict-derived retained calls, ordinary runtime_baseline compile/setup/execute and Node fresh-context references remain separate boundaries. Every raw stream, startup control and slower control is retained, with executable/source identities checked.',
            memory='Post-execution smaps process RSS with Store alive is not live JavaScript bytes, peak memory or causal per-owner attribution. Whole-child GNU time peaks include loading/compiler and identity hashing. The 262048-byte conditional structural count is not a predicted or measured RSS reduction.',
            resource_policy='Inherited managed-cloud 32 GiB cap; CPU 0 for measurements/tests, quota-bound build CPUs; serial Cargo/libtest and retained module cache 512 entries/2 GiB. Swap/group OOM settings are inherited, not local 4 GiB guarantees.',
        ),
        diagnostics=diagnostics,
        limits=[
            'The 25 selected original Test262 families are not full pinned-suite publication or full release acceptance.',
            'Published benchmark graphs and full Test262 status remain unchanged.',
            'Every-case V8/Scriptc execution-time and RSS parity remains open; optional saved comparisons do not imply parity.',
            'All 17 original, retained, ordinary and V8 controls and startup raw results remain visible; no universal speedup claim.',
            'Resolver static code-site folding preserves dynamic counts/order and establishes no native byte or memory saving by itself.',
            'Array storage savings are conditional structural accounting; process-level measurements are combined-batch observations with no per-owner causal subtraction.',
        ],
    )
    (OUT / 'report-core.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(dict(native_retained_cases=2653, native_scopes=11,
                          test262_executions=test262_executions, selected_js_files=709,
                          candidate_fingerprint=candidate_fingerprint, workloads=len(table),
                          cohorts=list(cohorts), output='report-core.json'), indent=2), flush=True)


if __name__ == '__main__':
    main()


