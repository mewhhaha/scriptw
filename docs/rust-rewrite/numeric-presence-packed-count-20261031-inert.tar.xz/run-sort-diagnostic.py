from pathlib import Path
import importlib.util,json,subprocess,sys
ROOT=Path('/workspace/scriptw');OUT=Path(__file__).resolve().parent;dest=OUT/'native-sort-diagnostic2'
argv=['python3','-B','scripts/run_workspace_tests.py','--profile','release','--packages','scriptw-aot-wasm','scriptw-engine','--output',str(dest),'--test-processes','1','--no-test-incremental','--idle-builds','--preserve-test-artifacts','--stop-on-build-failure','--only-targets','scriptw-aot-wasm:emission','--native-filter','scriptw-aot-wasm:emission=packed_array_storage::real_array_sort_snapshots_packed_values_and_revalidates_after_all_comparisons']
with (OUT/'native-sort-diagnostic2.log').open('x') as f:r=subprocess.run(argv,cwd=ROOT,stdout=f,stderr=subprocess.STDOUT)
receipt=json.loads((dest/'receipt.json').read_text());assert receipt['source_unchanged']
spec=importlib.util.spec_from_file_location('count_native_runner',OUT/'run-native.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);module.retire_products(dest,receipt,set(),{})
print([(x['state'],x.get('outcomes')) for x in receipt['cases']],flush=True);sys.exit(r.returncode)
