These report/packager sources adapt the sealed I31 strict validators. Only AST
and source-schema checks have run; report helpers, assembly and packaging wait
until root marks the native/preparation/timing jobs idle and complete.

Assembly uses `compiled-inputs-final-test-repair.json` and the matching final
implementation, patch and source map. Original and first-repair25-file snapshots
remain immutable. Exactly2 emission test files differ; all23 other inputs,
including production, must match byte for byte. The original library/link
passes keep their original source maps and binary identities. Final scopes use
`-repair3` directories; their full emission rerun supersedes earlier7-pass/1-fail
runs rather than counting their passing siblings again.

Both full failed images retain freeze metadata. The focused diagnostic's failed
image was lost after the wrapper's retirement TypeError and later Cargo work;
`native-evidence-limits.json` and actual source/transcript/digest are preserved.
The report never claims retention, reconstruction or re-execution of that image.

Assembly requires25 frozen inputs including the2 new Rust modules, own ABI46
products at accepted6365, completed10-scope native receipts, complete24-original
push runs, fresh Node21 goldens, the full504 normal-overlay children and an
explicit Astra decision bound to the actual candidate. Actual native inventories
and variants are derived, never predicted or adopted from rejected43/44/45.
Emission's3 filters and language's2 filters preserve exact keep/use/retire chains;
the full GC target executes once. At most one predeclared follow-up of up to8
sources is reconstructed separately without pooling or replacing the full cohort.

The old closed-comparison cache relocation is historical post-rejection metadata.
COUNTB uses its own fresh canonical `normal-cache` overlay; native verification
cache under `/tmp` is separate. Packaging retains inert raw/source/metadata and
the candidate's2 JSON metadata files while excluding cache/native payloads,
symlinks and next drafts. Root supplies the reviewed public artifact stem and
runs the packager through `scripts/limited_verification.py --cloud`.
