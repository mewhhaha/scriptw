from pathlib import Path
import hashlib,json,subprocess,sys
ROOT=Path('/workspace/scriptw');OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'scripts'));from verification_identity import source_map
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):
 with p.open('x') as f:f.write(json.dumps(v,indent=2)+'\n')
original=json.loads((OUT/'compiled-inputs.json').read_text());expected={'crates/scriptw-aot-wasm/tests/emission/packed_array_storage.rs','crates/scriptw-aot-wasm/tests/emission/property_read_plans.rs'}
current={};changed=[]
for name,row in original.items():
 p=ROOT/name;r=dict(row,sha256=sha(p),bytes=p.stat().st_size);current[name]=r
 if r!=row:changed.append(name)
assert set(changed)==expected and all('/tests/emission/' in n for n in changed)
new_map=source_map(ROOT);old_map=json.loads((OUT/'source-map-at-freeze.json').read_text());assert new_map['head']==old_map['head'] and new_map['untracked']==old_map['untracked']
dest=OUT/'implementation-after-test-repair';dest.mkdir()
for name in current:
 p=dest/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((ROOT/name).read_bytes())
tracked=subprocess.check_output(['git','diff','--name-only','-z'],cwd=ROOT).decode().split('\0');tracked=[n for n in tracked if n]
patch=subprocess.check_output(['git','diff','--binary','HEAD','--',*tracked],cwd=ROOT)
for name in new_map['untracked']:
 r=subprocess.run(['git','diff','--no-index','--binary','/dev/null',name],cwd=ROOT,capture_output=True);assert r.returncode==1;patch+=r.stdout
with (OUT/'compile-inputs-after-test-repair.patch').open('xb') as f:f.write(patch)
save(OUT/'compiled-inputs-after-test-repair.json',current);save(OUT/'source-map-after-test-repair.json',new_map)
reuse=dict(reason='Two emission witness files distinguish legitimate raw presence-word reads from logical-count guards; production and all other frozen inputs are byte-identical. Full affected emission owner is rerun; completed library/link scopes retain their original source/binary identities.',changed_test_files=changed,unchanged_inputs=[n for n in original if n not in expected],original_manifest='compiled-inputs.json',repaired_manifest='compiled-inputs-after-test-repair.json',original_source_map='source-map-at-freeze.json',repaired_source_map='source-map-after-test-repair.json',preserved_passing_scope_indices=[0,1,2],initial_failure='native-batch-02-emission/receipt.json',repair_receipt='structural-repair/receipt.json',original_source_identity=old_map,repaired_source_identity=new_map,production_changes=False)
save(OUT/'test-repair-reuse-proof.json',reuse);assert source_map(ROOT)==new_map;print('Frozen25repairedinputs;exactly2emissiontestfileschanged;allproduction/other23inputsunchanged')
