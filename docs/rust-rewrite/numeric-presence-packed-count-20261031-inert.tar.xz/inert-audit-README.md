# CountB ABI46 inert code audit: prepared, HOLD

inspect-runtime-code.py is adapted from the unchanged source-known I31 driver. It has only been parsed as Python source, never imported or executed. No product, identity, raw Wasm, native image, ELF, archive or cache was opened for this preparation. No tracked file was edited. inert-audit-source-draft.json seals the new driver and extractor source hashes.

Root may run the exact driver only during the authorized idle window after fresh product/image preparation and before timings:

```sh
python3 -B scripts/limited_verification.py --cloud -- python3 -B target/performance-packed-count-presence-20261031/inspect-runtime-code.py --candidate-fingerprint <new-frozen-CountB-FP>
```

Optional --source-manifest and --source-patch accept local filenames for a documented continuation without changing this driver. Defaults are compiled-inputs.json/compile-inputs.patch. Require exactly25 inputs including2 new Rust modules (array_index_word and private Engine number_presence); current crates Rust hashes must match the chosen snapshot. Current Markdown may receive actual measurements. The candidate must retain source6365+snapshot identity and ABI46. Baseline must be accepted Date a35/ABI42 with its actual7c producer; no rejected i31/append/lazy identity is accepted as baseline.

The later audit reuses diagnose-pages.py::extract_runtime for verified own-host hashes, packed native framing, execution receipt/source/ABI, decompression bounds/SHA, ELF extents/symbols and before/after host identity. It retains the same13 helper sizes, optional Array constructor, serialized-native/.text totals and6 entry captures (3 functions*2 products), at most256 bytes each. Publication/object_read/push1 prologues only report clear stack/register patterns; an absent pattern means unknown. No payload is loaded/executed. No live profile, code residency/RSS or causal CPU/GC claim follows. Extracted ELF/native files remain private and archives must exclude them by suffix/magic/regular-file policy.

The requested raw R TypeSection equality diagnostic is explicitly unavailable: source inspection confirms the existing extractor returns only Portable native ELF data and execution receipt, with no digest-bound raw R Wasm output. The report records unavailable/compared=false rather than assuming unchanged bytes from the unchanged physical source types. No alternate extraction harness or compiler tool was added. If raw R becomes available through a separately reviewed existing extractor contract later, compare strictly framed opaque section1 payload length/SHA; no GC operator byte counts are required or permitted as substitute proof.

This source preparation makes no cache qualification, candidate product verification or runtime cost claim. Verification tmpfs is separate from root's later fresh CountB normal-overlay cache. Runtime count decode/mutation costs, native text/frame observations and conditional bitmap ownership bounds remain separate evidence. Preserve failed attempts; runtime-code-size.json is create-only.
