"""Assemble complete packed count/presence evidence from inert records only; never run products."""
from pathlib import Path
import ast
import datetime
import hashlib
import json
import re
import statistics

ROOT = Path('/workspace/scriptw')
OUT = Path(__file__).resolve().parent
PARENT = '6365a67cc523d4428f4d7d5c2c091bf60faab1b8'
BASELINE = 'a35adbcb61dbc57b4ee44dd1527019358deb137b11ae559de7d0d4b4a860b480'
BASELINE_SOURCE = '7c47e38274c9645b6701552c87d38362b2bfbcd5'
ORDER = ['baseline', 'candidate', 'candidate', 'baseline',
         'candidate', 'baseline', 'baseline', 'candidate']
DATE_FILES = ['date-first-descriptor.js', 'date-first-epoch.js', 'date-repeated-256.js']
MANIFEST = 'compiled-inputs-final-test-repair.json'
IMPLEMENTATION = 'implementation-final-test-repair'
SOURCE_MAP = 'source-map-final-test-repair.json'
COMPILED_PATCH = 'compile-inputs-final-test-repair.patch'


def require(value, message):
    if not value:
        raise ValueError(message)


def inert(path, limit=16 * 1024**2):
    path = Path(path)
    require(path.is_file() and not path.is_symlink() and path.stat().st_size <= limit,
            'missing, nonregular or oversized inert input: ' + str(path))
    require(path.suffix in {'.json', '.jsonl', '.log', '.stdout', '.stderr', '.gz',
                           '.rs', '.md', '.py', '.patch', '.js', '.mjs', '.cjs', '.txt'},
            'inert metadata/source/log required: ' + str(path))
    return path


def read(name):
    path = Path(name)
    return json.loads(inert(path if path.is_absolute() else OUT / path).read_text())


def digest(path):
    # Native product/image files are never opened; identities come from receipts.
    return hashlib.sha256(inert(path).read_bytes()).hexdigest()


def origin(path, expected_sha256=None, archive=False):
    path = Path(path)
    if not path.is_absolute():
        path = ROOT / path
    require(path.is_relative_to(ROOT), 'raw origin outside workspace')
    actual = digest(path)
    require(expected_sha256 is None or actual == expected_sha256, 'raw origin digest differs: ' + str(path))
    archived = path
    if archive and not path.is_relative_to(OUT):
        archived = OUT / 'raw-streams' / path.name
        archived.parent.mkdir(exist_ok=True)
        if archived.exists():
            require(digest(archived) == actual, 'archived raw stream differs')
        else:
            with archived.open('xb') as stream:
                stream.write(path.read_bytes())
    return dict(origin=str(path.relative_to(ROOT)), sha256=actual,
                archive_path=str(archived.relative_to(OUT)) if archived.is_relative_to(OUT) else None)


def native_case(directory, case):
    inventory = origin(case['inventory_log'], case['inventory_sha256'])
    inventory_text = (ROOT / inventory['origin']).read_text()
    names = re.findall(r'^(.+): test$', inventory_text, re.M)
    require(len(names) == len(set(names)) == case['inventoried_tests'] > 0,
            'native inventory differs: ' + directory)
    stream = origin(case['transcript_log'], case['transcript_sha256'], archive=True)
    text = (ROOT / stream['origin']).read_text()
    printed = re.findall(r'^test (.+) \.\.\. (ok|FAILED|ignored)$', text, re.M)
    # libtest annotates #[should_panic] execution labels, while --list emits the
    # canonical Rust test name without that suffix.
    actual = [(name.removesuffix(' - should panic'), status) for name, status in printed]
    require(len(actual) == len(names) and {name for name, _ in actual} == set(names),
            'native transcript does not cover its inventory: ' + directory)
    totals = dict(passed=sum(status == 'ok' for _, status in actual),
                  failed=sum(status == 'FAILED' for _, status in actual),
                  ignored=sum(status == 'ignored' for _, status in actual))
    require(case['outcomes'] == [totals] and totals['ignored'] == 0, 'native outcome differs')
    summaries = re.findall(r'^test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', text, re.M)
    require(summaries == [(str(totals['passed']), str(totals['failed']), '0')],
            'native summary differs')
    failed = totals['failed'] > 0
    require(case['build_exit'] == 0 and case['state'] == ('failed' if failed else 'passed') and
            case['exit_code'] == (101 if failed else 0) and case['inventory_matches'] is (not failed),
            'native completion/inventory state differs')
    for row in case['sealed_build_logs']:
        origin(row['path'], row['gzip_sha256'])
    keys = {(case['package'], case['target'], name): status for name, status in actual}
    return dict(receipt=directory + '/receipt.json', package=case['package'], target=case['target'],
                filter=case.get('native_filter'), outcomes=totals, inventory=inventory,
                failing_tests=[name for name, status in actual if status == 'FAILED'],
                transcript=stream, executable_sha256=case['executable_sha256'],
                executable_bytes=case['executable_bytes'],
                executable_released_by_driver=case['executable_released']), keys


def source_versions():
    proof, prior_proof = read('test-repair-reuse-proof-final.json'), read('test-repair-reuse-proof.json')
    repair, prior_repair = read('structural-repair3/receipt.json'), read('structural-repair/receipt.json')
    diagnostic = read('structural-repair2/diagnostic-receipt.json')
    review = read('structural-repair/independent-review2.json')
    versions = {}
    for name, manifest, directory, source_map, patch in [
        ('original', 'compiled-inputs.json', 'implementation', 'source-map-at-freeze.json', 'compile-inputs.patch'),
        ('repair1', 'compiled-inputs-after-test-repair.json', 'implementation-after-test-repair',
         'source-map-after-test-repair.json', 'compile-inputs-after-test-repair.patch'),
        ('repaired', MANIFEST, IMPLEMENTATION, SOURCE_MAP, COMPILED_PATCH),
    ]:
        inputs, frozen = read(manifest), read(source_map)
        require(len(inputs) == 25 and frozen['head'] == PARENT, 'source version parent/input count differs')
        for path, record in inputs.items():
            source = OUT / directory / path
            require(not Path(path).is_absolute() and '..' not in Path(path).parts and
                    source.stat().st_size == record['bytes'] and digest(source) == record['sha256'],
                    'frozen source version differs: ' + name + '/' + path)
        versions[name] = dict(manifest=manifest, implementation=directory, patch=patch,
                              patch_sha256=digest(OUT / patch), source_map_file=source_map,
                              source_map=frozen, source_map_sha256=hashlib.sha256(
                                  json.dumps(frozen, sort_keys=True).encode()).hexdigest(), inputs=inputs)
    original = versions['original']
    expected = {'crates/scriptw-aot-wasm/tests/emission/packed_array_storage.rs',
                'crates/scriptw-aot-wasm/tests/emission/property_read_plans.rs'}
    for version_name, reuse, receipt_name, receipt in [
        ('repair1', prior_proof, 'structural-repair/receipt.json', prior_repair),
        ('repaired', proof, 'structural-repair3/receipt.json', repair),
    ]:
        target = versions[version_name]
        require(set(original['inputs']) == set(target['inputs']), 'repair changes the frozen path inventory')
        changed = {name for name in original['inputs'] if original['inputs'][name] != target['inputs'][name]}
        require(changed == expected == set(reuse['changed_test_files']) == set(receipt['changed_sources']) and
                set(reuse['unchanged_inputs']) == set(original['inputs']) - changed and
                len(reuse['unchanged_inputs']) == 23 and reuse['production_changes'] is False and
                reuse['original_manifest'] == original['manifest'] and reuse['repaired_manifest'] == target['manifest'] and
                reuse['original_source_map'] == original['source_map_file'] and
                reuse['repaired_source_map'] == target['source_map_file'] and
                reuse['original_source_identity'] == original['source_map'] and
                reuse['repaired_source_identity'] == target['source_map'] and
                reuse['preserved_passing_scope_indices'] == [0,1,2] and
                reuse['initial_failure'] == 'native-batch-02-emission/receipt.json' and
                reuse['repair_receipt'] == receipt_name and receipt['production_edits'] is False,
                'two-file test-only source repair/reuse proof differs: ' + version_name)
        require(all(check['exit_code'] == 0 for check in receipt['checks']) and
                receipt['independent_review']['result'].startswith('approved') and
                'astra' in receipt['independent_review']['agent'].lower(),
                'source repair checks/review incomplete')
    require(prior_repair['frozen_compiled_inputs_snapshot_edits'] is False and
            repair['immutable_prior_inputs_edits'] is False and
            proof['previous_failed_repair'] == 'native-batch-02-emission-repair1/receipt.json' and
            proof['diagnostic'] == 'native-sort-diagnostic2/receipt.json' and
            review['status'] == 'source_only_approved' and 'astra' in review['reviewer'].lower() and
            review['runtime_abi'] == 46 and review['production_changed'] is False and
            set(review['reviewed_files']) == expected and
            repair['logical_guard_inventory'] == {'sort':4, 'toSorted':2},
            'final repair continuation/independent review differs')
    initial = {row['path']: row for row in read('structural-repair3/initial-source-hashes.json')['sources']}
    guarded = 'crates/scriptw-aot-wasm/tests/emission/guarded_push.rs'
    require(set(initial) == expected | {guarded}, 'final repair initial source inventory differs')
    for name, record in initial.items():
        source = OUT / 'structural-repair3/initial' / name
        require(source.stat().st_size == record['bytes'] and digest(source) == record['sha256'],
                'diagnostic source before final repair differs')
    diagnostic_name = 'crates/scriptw-aot-wasm/tests/emission/property_read_plans.rs'
    require(diagnostic['changed_source'] == diagnostic_name and diagnostic['production_changes'] is False and
            all(check['exit_code'] == 0 for check in diagnostic['checks']) and
            diagnostic['sha256'] == initial[diagnostic_name]['sha256'] ==
            digest(OUT / 'structural-repair2/diagnostic' / diagnostic_name) and
            all(initial[name]['sha256'] == versions['repair1']['inputs'][name]['sha256']
                for name in initial if name != diagnostic_name), 'diagnostic-only text/source chain differs')
    for receipt, initial_records, final_records, patch in [
        (prior_repair, original['inputs'], versions['repair1']['inputs'], 'structural-repair/repair.patch'),
        (repair, initial, versions['repaired']['inputs'], 'structural-repair3/repair.patch'),
    ]:
        require({row['path'] for row in receipt['sources']} == expected | {guarded} and
                digest(OUT / patch) == receipt['repair_patch_sha256'], 'repair source/patch inventory differs')
        for row in receipt['sources']:
            name = row['path']
            require(row['initial_sha256'] == initial_records[name]['sha256'] and
                    row['repaired_sha256'] == final_records[name]['sha256'] and row['changed'] is (name in expected),
                    'repair source identity chain differs: ' + name)
    return versions, dict(proof=proof, repair=repair, prior_proof=prior_proof, prior_repair=prior_repair,
                          diagnostic=diagnostic, independent_final_review=review,
                          initial_failure_test=prior_repair['initial_failure'],
                          qualification='Only2 emission test witnesses differ from the original; all23 other frozen inputs including production are identical in original, repair1 and final snapshots. A diagnostic-only assertion-text step is retained separately. Original library/link binaries/maps are reused; all affected emission cases execute freshly under final repair3.')


def source_and_native():
    versions, repair_proof = source_versions()
    inputs, summary = versions['repaired']['inputs'], read('native-final-summary.json')
    native_plan = read('native-plan.json')
    new_modules = {'crates/scriptw-aot-wasm/src/gc_types/value/array_index_word.rs',
                   'crates/scriptw-engine/src/wasm_rooted_snapshot/number_presence.rs'}
    require(len(inputs) == 25 and native_plan['accepted_parent'] == PARENT and
            {name for name, row in inputs.items() if row['untracked_new_module']} == new_modules,
            'frozen25-input/ABI46 source plan differs')
    runtime_source = OUT / IMPLEMENTATION / 'crates/scriptw-aot-wasm/src/runtime_artifact.rs'
    require(re.search(r'const\s+LAYOUT_VERSION\s*:\s*u32\s*=\s*46\s*;', runtime_source.read_text()),
            'ABI46 source authority absent')
    expected = [('scriptw-aot-wasm', 'scriptw_aot_wasm', 'lib', None),
                ('scriptw-engine', 'scriptw_engine', 'lib', 'wasm_rooted_snapshot::'),
                ('scriptw-aot-wasm', 'runtime_link', 'test', None),
                ('scriptw-aot-wasm', 'emission', 'test', 'packed_array_storage::'),
                ('scriptw-aot-wasm', 'emission', 'test', 'property_read_plans::'),
                ('scriptw-aot-wasm', 'emission', 'test', 'guarded_push::'),
                ('scriptw-engine', 'aot_gc_entries', 'test', None),
                ('scriptw-engine', 'aot_builtins', 'test', 'aot_array'),
                ('scriptw-engine', 'aot_language', 'test', 'aot_compact_array_literals::'),
                ('scriptw-engine', 'aot_language', 'test', 'aot_packed_array_producers::')]
    require([(row['package'], row['target'], row['kind'], row['filter'])
             for row in native_plan['scopes']] == expected and
            summary['complete'] is True and summary['all_passed'] is True and
            len(summary['scopes']) == len(expected) and
            summary['source_snapshot'] == MANIFEST and
            summary['source_unchanged_every_scope'] is True,
            'fresh native ten-scope coverage incomplete')
    rows, selected, retained, chains, used_directories = [], {}, {}, [], set()
    for index, (planned, run) in enumerate(zip(native_plan['scopes'], summary['scopes'])):
        version_name = 'original' if index < 3 else 'repaired'
        version = versions[version_name]
        frozen, source_map = version['source_map'], version['source_map_sha256']
        batch_index = 0 if index < 2 else index - 1
        batch_name = 'libraries' if index < 2 else planned['target']
        directory = run['label']
        expected_directory = f'native-batch-{batch_index:02d}-{batch_name}' + ('' if index < 3 else '-repair3')
        require(directory == expected_directory and
                run['index'] == index and run['batch_index'] == batch_index and
                run['package'] == planned['package'] and run['target'] == planned['target'] and
                run['filter'] == planned['filter'] and run['state'] == 'passed' and run['exit_code'] == 0,
                'native final union selector or original/resume directory differs')
        if index == 1:
            require(directory == rows[0]['receipt'].split('/')[0], 'library cases do not share one receipt')
        used_directories.add(directory)
        receipt = read(directory + '/receipt.json')
        require(receipt['head'] == PARENT and receipt['source_unchanged'] is True and
                receipt['shared_runtime_linker_unchanged'] is True and receipt['profile'] == 'release' and
                receipt['all_features'] is False and receipt['include_ignored'] is False and
                set(receipt['selected_workspace_packages']) == {'scriptw-aot-wasm', 'scriptw-engine'} and
                receipt['preserve_test_artifacts'] is True and receipt['selected_feature_roots'] is False,
                'native source/features/selection changed')
        expected_cases = expected[:2] if index < 2 else [expected[index]]
        require({(case['package'], case['target'], case['kind']) for case in receipt['cases']} ==
                {row[:3] for row in expected_cases} and len(receipt['cases']) == len(expected_cases),
                'native receipt has extra or missing selected cases')
        start = read(directory + '/source-start.json')
        require(start == frozen and receipt['source_map_sha256'] == source_map,
                'native source map differs across scopes')
        schedule = receipt['scheduling']
        require(schedule['cargo_jobs'] == schedule['test_processes'] == schedule['test_threads_per_process'] == 1,
                'native serial policy differs')
        case = next(case for case in receipt['cases'] if case['package'] == planned['package'] and
                    case['target'] == planned['target'])
        require(case['kind'] == planned['kind'] and case.get('native_filter') == planned['filter'],
                'native case selector differs')
        row, tests = native_case(directory, case)
        count = len(tests)
        require(count > 0 and row['outcomes'] == dict(passed=count, failed=0, ignored=0) and
                run['inventoried_tests'] == count and run['outcomes'] == case['outcomes'] and
                run['executable_sha256'] == case['executable_sha256'] and
                not (selected.keys() & tests.keys()), 'native fresh inventory is failing, empty or overlapping')
        lifecycle = read(directory + '/native-image-retirement.json')
        records = [record for record in lifecycle['records'] if record['selected']]
        require(lifecycle['exit_code'] == 0 and lifecycle['source_map_sha256'] == source_map and
                {(record['package'], record['target']) for record in records} ==
                {(other['package'], other['target']) for other in receipt['cases']} and
                len(records) == len(receipt['cases']), 'selected image lifecycle inventory differs')
        image = next(record for record in records if record['package'] == case['package'] and
                     record['target'] == case['target'])
        require(image['sha256'] == case['executable_sha256'] and image['bytes'] == case['executable_bytes'],
                'selected image lifecycle identity differs')
        selector = (case['package'], case['target'], tuple(case['selector']))
        if selector in retained:
            previous = retained.pop(selector)
            require(all(image[key] == previous['record'][key] for key in ['path', 'sha256', 'bytes']) and
                    previous['source_map_sha256'] == source_map,
                    'same-selector keep/use/retire chain differs')
            chains.append(dict(first=previous['receipt'], second=directory + '/receipt.json',
                               package=case['package'], target=case['target'], sha256=image['sha256'],
                               bytes=image['bytes'], source_map_sha256=source_map))
        future = any(other['package'] == planned['package'] and other['target'] == planned['target']
                     for other in native_plan['scopes'][index + 1:])
        expected_action = ('retained exact passing image for next filter in same Cargo selector' if future else
                           'retired exact passing image after complete source-bound transcript')
        require(image['action'] == expected_action, 'selected passing image keep/retire policy differs')
        if future:
            retained[selector] = dict(record=image, receipt=directory + '/receipt.json', source_map_sha256=source_map)
        row.update(source_map_sha256=source_map, source_start=start, scheduling=schedule,
                   selector=case['selector'], lifecycle=lifecycle, batch_index=batch_index,
                   source_version=version_name, source_snapshot=version['manifest'])
        rows.append(row)
        selected.update(tests)
    require(not retained and len(used_directories) == 9 and len(chains) == 3 and
            selected and set(selected.values()) == {'ok'}, 'native union or image chains incomplete')
    require(summary.get('unique_passed', summary.get('actual_passed')) == len(selected),
            'final native union count differs from actual inventories')
    proof_tests = {
        'count_word_domain': ('scriptw-aot-wasm', 'scriptw_aot_wasm',
            'gc_types::value::array_index_word::tests::count_word_decoder_rejects_reserved_flags_and_inconsistent_masks'),
        'fresh_prefix_word': ('scriptw-aot-wasm', 'scriptw_aot_wasm',
            'gc_types::value::array_index_word::tests::fresh_numeric_prefix_words_admit_only_complete_nonempty_small_states'),
        'array_layout': ('scriptw-aot-wasm', 'scriptw_aot_wasm',
            'gc_types::type_registration_tests::array_storage_fusion::encoded_actual_array_fits_one_64_byte_copying_collector_record'),
        'bitmap_allocation': ('scriptw-aot-wasm', 'scriptw_aot_wasm',
            'gc_types::type_registration_tests::array_storage_fusion::actual_one_word_presence_bitmap_occupies_32_copying_collector_bytes'),
        'encoded_presence': ('scriptw-aot-wasm', 'emission',
            'packed_array_storage::compiled_numbers_use_bitmap_arrays_and_keep_real_descriptor_fallback'),
        'encoded_property_read': ('scriptw-aot-wasm', 'emission',
            'property_read_plans::own_data_cache_and_numeric_array_reads_keep_guarded_loads_and_get_fallbacks'),
        'encoded_count_guard': ('scriptw-aot-wasm', 'emission',
            'guarded_push::fixed_push_proves_actual_native_then_keeps_argument_allocations_in_fallback'),
        'promotion_count_lifecycle': ('scriptw-engine', 'aot_gc_entries',
            'aot_gc_packed_array_storage::logical_count_survives_nonempty_numeric_value_descriptor_and_sparse_promotions'),
        'growth_lifecycle': ('scriptw-engine', 'aot_gc_entries',
            'aot_gc_packed_array_storage::four_element_capacity_growth_keeps_holes_and_number_bits'),
        'cyclic_snapshot_portable': ('scriptw-engine', 'aot_gc_entries',
            'aot_gc_packed_array_storage::graph_snapshot_keeps_presence_cycles_across_later_program_mutation_and_gc'),
    }
    for name in read('snapshot-owner/receipt.json')['new_private_tests']:
        proof_tests['decoder_' + name] = ('scriptw-engine', 'scriptw_engine',
                                         'wasm_rooted_snapshot::number_presence::tests::' + name)
    require(len([name for name in proof_tests if name.startswith('decoder_')]) == 4 and
            all(selected.get(key) == 'ok' for key in proof_tests.values()),
            'actual collector/domain/decoder/encoded/lifecycle proofs did not pass')
    owner = 'crates/scriptw-engine/tests/aot_gc_entries/aot_gc_packed_array_storage.rs'
    owner_tests = set(re.findall(r'(?m)^#\[test\]\nfn (\w+)\(', (OUT / IMPLEMENTATION / owner).read_text()))
    owner_actual = {key[2].removeprefix('aot_gc_packed_array_storage::') for key in selected
                    if key[:2] == ('scriptw-engine', 'aot_gc_entries') and
                    key[2].startswith('aot_gc_packed_array_storage::')}
    require(owner_tests == owner_actual and owner_tests, 'frozen Engine owner inventory not completely executed')
    layout = (OUT / IMPLEMENTATION / 'crates/scriptw-aot-wasm/src/gc_types/type_registration_tests/array_storage_fusion.rs').read_text()
    flat = re.sub(r'\s+', '', layout)
    require('assert_eq!(layout.size,64);' in flat and 'assert_eq!(layout.align,16);' in flat and
            '[16,20,24,32,40,44,48,52,56,60]' in flat and
            'assert_eq!(layout.size_for_len(1),Some(32));' in flat and
            '.filter(|field|field.is_gc_ref).count(),6' in flat and
            'assert_eq!(ArrayObjectSchema::COUNT.ordinal().raw(),3);' in flat and
            'array.fields[3].element_type,wasmparser::StorageType::Val(wasmparser::ValType::I64)' in flat and
            'layouts.layout_index(GcLayout::NumberPresenceU64Array)' in flat,
            'reported Array/bitmap layout differs from passing frozen source')
    census_path = ROOT / 'target/performance-packed-count-presence-plan-20261031/owner-census.json'
    census = read(census_path)
    paths = census['direct_sites_by_path']
    require(census['direct_production_count_sites'] == sum(paths.values()) == 25 and len(paths) == 7 and
            set(paths) <= set(inputs), 'original25-site COUNT authority census differs')
    for name in paths:
        require(not re.search(r'ArrayObjectSchema\s*::\s*COUNT',
                              (OUT / IMPLEMENTATION / name).read_text()),
                'external raw COUNT survived migration: ' + name)
    registry = (OUT / IMPLEMENTATION / 'crates/scriptw-aot-wasm/src/gc_types/layouts.rs').read_text()
    registry_flat = re.sub(r'\s+', '', registry)
    require('pub(super)constCOUNT:GcField<ArrayObject,' in registry_flat and
            registry_flat.index('(@fieldsArrayObject$ordinal:expr;COUNT:') <
            registry_flat.index('(@fields$owner:ident$ordinal:expr;$field:ident:'),
            'Array-only private raw COUNT rule is not before the generic public field rule')
    failures, failure_directories = [], set()
    diagnostic_limits = read('native-evidence-limits.json')
    for directory, version_name, wanted_filter in [
        ('native-batch-02-emission', 'original', 'packed_array_storage::'),
        ('native-batch-02-emission-repair1', 'repair1', 'packed_array_storage::'),
        ('native-sort-diagnostic2', 'diagnostic-only', repair_proof['initial_failure_test']),
    ]:
        failure_directories.add(directory)
        receipt = read(directory + '/receipt.json')
        start = read(directory + '/source-start.json')
        start_sha = hashlib.sha256(json.dumps(start, sort_keys=True).encode()).hexdigest()
        require(len(receipt['cases']) == 1 and receipt['head'] == start['head'] == PARENT and
                receipt['source_unchanged'] is True and receipt['source_map_sha256'] == start_sha,
                'historical failed test source identity differs')
        if version_name != 'diagnostic-only':
            require(start == versions[version_name]['source_map'], 'historical failure changed source version')
        else:
            require(start['untracked'] == versions['original']['source_map']['untracked'],
                    'diagnostic changed new production modules')
        case = receipt['cases'][0]
        require((case['package'], case['target'], case.get('native_filter')) ==
                ('scriptw-aot-wasm', 'emission', wanted_filter), 'historical failed emission selector differs')
        failure, superseded = native_case(directory, case)
        failed_names = [key[2] for key, status in superseded.items() if status == 'FAILED']
        require(failed_names == [repair_proof['initial_failure_test']] and failure['outcomes']['failed'] == 1 and
                superseded.keys() <= selected.keys() and all(selected[key] == 'ok' for key in superseded),
                'historical failed owner/diagnostic did not pass freshly in final full emission scope')
        if version_name != 'diagnostic-only':
            require(failure['outcomes']['passed'] > 0, 'full failed owner has no preserved passing siblings')
            lifecycle = read(directory + '/native-image-retirement.json')
            images = [row for row in lifecycle['records'] if row['selected']]
            require(lifecycle['exit_code'] != 0 and lifecycle['source_map_sha256'] == start_sha and
                    len(images) == 1 and images[0]['sha256'] == case['executable_sha256'] and
                    images[0]['bytes'] == case['executable_bytes'] and
                    images[0]['action'] == 'frozen selected non-passing image outside Cargo' and
                    Path(images[0]['frozen_path']).parent == OUT / 'failed-native' / directory,
                    'historical full failed image freeze metadata differs')
            image_evidence = dict(native_image_retained=True, lifecycle=lifecycle,
                                  qualification='Freeze identity comes from original metadata; this assembler never opens/hashes native bytes, and the inert archive excludes them.')
        else:
            require(failure['outcomes']['passed'] == 0 and len(superseded) == 1 and
                    diagnostic_limits['diagnostic'] == directory + '/receipt.json' and
                    diagnostic_limits['native_image_retained'] is False and
                    diagnostic_limits['executable_sha256'] == case['executable_sha256'] and
                    diagnostic_limits['executable_bytes'] == case['executable_bytes'] and
                    diagnostic_limits['reason'].strip(), 'missing diagnostic image limitation differs')
            driver_log = OUT / 'native-sort-diagnostic2-driver.log'
            require('TypeError: retire_products() missing 2 required positional arguments' in
                    inert(driver_log).read_text(), 'diagnostic wrapper retirement failure origin differs')
            image_evidence = dict(native_image_retained=False, limits=diagnostic_limits,
                                  wrapper_failure=origin(driver_log),
                                  qualification='Actual source/transcript/digest remain, but the diagnostic native image was not retained after the wrapper TypeError and later Cargo replacement. No reconstruction/re-execution/replacement is represented as the original image.')
        failure.update(source_version=version_name, source_start=start, source_map_sha256=start_sha,
                       image_evidence=image_evidence, reused_as_passing_coverage=False,
                       superseded_passing_cases=failure['outcomes']['passed'],
                       fresh_final_owner_cases=len(superseded),
                       qualification='Rust structural-witness assertion failure, not an observed JavaScript runtime failure. All originally selected keys pass in the final full emission rerun; historical passing siblings are not counted twice.')
        failures.append(failure)
    original_summary = read('native-summary-start0.json')
    repair1_summary = read('native-summary-start2-repair1.json')
    repaired_summary = read('native-summary-start2-repair3.json')
    require(original_summary['complete'] is False and original_summary['all_passed'] is False and
            repair1_summary['complete'] is False and repair1_summary['all_passed'] is False and
            repaired_summary['complete'] is True and repaired_summary['all_passed'] is True and
            original_summary['scopes'][:3] == summary['scopes'][:3] and
            repaired_summary['scopes'] == summary['scopes'][3:],
            'final native union does not preserve original passing prefix and complete final repair continuation')
    historical = []
    for receipt_path in sorted(OUT.glob('native-batch-*/receipt.json')):
        directory = receipt_path.parent.name
        if directory in used_directories or directory in failure_directories:
            continue
        receipt = read(receipt_path)
        cases = []
        for case in receipt['cases']:
            if case.get('transcript_log'):
                row, _ = native_case(directory, case)
                cases.append(row)
            else:
                require(not case.get('outcomes') and not case.get('exit_code'),
                        'unexecuted historical case claims a verdict')
                cases.append(dict(package=case['package'], target=case['target'], state=case.get('state'),
                                  qualification='No completed native transcript/verdict; not adopted as passing coverage.'))
        lifecycle = receipt_path.parent / 'native-image-retirement.json'
        historical.append(dict(receipt=origin(receipt_path), cases=cases,
                               image_policy=read(lifecycle) if lifecycle.exists() else None,
                               reused_as_passing_coverage=False))
    events = {path.name: dict(record=read(path), scope=(
        'Post-rejection relocation of earlier closed-comparison caches only. This is not active COUNTB cache, native coverage, admission or timing evidence; COUNTB normal-cache is freshly bound overlay and checked separately.'
        if path.name == 'closed-comparison-cache-relocation.json' else
        'Regenerable resource-policy event only; scored normal-overlay cache identity is checked separately.'))
        for path in sorted(OUT.glob('*cache-relocation.json'))}
    return dict(inputs=inputs, snapshot=MANIFEST, implementation_snapshot=IMPLEMENTATION,
                patch_sha256=versions['repaired']['patch_sha256'], original_patch_sha256=versions['original']['patch_sha256'],
                source_map_sha256=versions['repaired']['source_map_sha256'], source_versions=versions,
                scopes=rows, unique_passes=len(selected), failures=failures,
                repairs=[dict(**repair_proof, original_summary=original_summary, failed_repair1_summary=repair1_summary,
                              continuation_summary=repaired_summary,
                              source_authority='Raw historical summary labels are preserved. Final union canonical manifest and each original/final source-start map are authoritative; no original passing scope is retagged as final.')],
                shared_image_chains=chains, final_union_summary=summary, actual_engine_owner_tests=len(owner_actual),
                array_layout=dict(bytes=64, alignment=16, potential_gc_slots=6,
                                  field_offsets=[16,20,24,32,40,44,48,52,56,60],
                                  count_field_ordinal=3, count_physical_type='i64',
                                  presence_field_ordinal=8, presence_physical_type='concrete nonnull nominal NumberPresenceU64Array',
                                  result='passed'),
                nominal_bitmap_allocation=dict(one_word_bytes=32, alignment=16, result='passed',
                                               test=proof_tests['bitmap_allocation'][2]),
                new_proof_tests={name: key[2] for name, key in proof_tests.items()},
                count_access_authority=dict(original_census=origin(census_path, archive=True),
                                            migrated_external_sites=25, paths=paths, raw_COUNT_private_to_gc_types=True,
                                            qualification='Frozen-source migration plus passing normal native compilation, codec tests and encoded guards; raw physical snapshot witness remains inside gc_types.'),
                historical_native_attempts=historical, resource_policy_events=events,
                scope='Final source-bound union of10 scopes: original passing library/link prefix plus final repair3 emission/later scopes, with an explicit2-test-file/23-unchanged production proof. First2 library cases share one receipt, fullGC executes once, and three same-selector use transitions cover emission3/language2 filters. Initial/repair1 full failures and diagnostic failure remain separate; diagnostic image loss is explicit; prior passing siblings are superseded. No rejected43/44/45 coverage or full-workspace claim.')


def product_metadata():
    identities = {label: read('baseline-identity.json' if label == 'baseline' else 'candidate/identity.json')
                  for label in ['baseline', 'candidate']}
    products = {label: read('baseline-products.json' if label == 'baseline' else 'candidate/products.json')
                for label in identities}
    require(identities['baseline']['source_fingerprint'] == BASELINE and
            identities['baseline']['source_commit'] == BASELINE_SOURCE and
            re.fullmatch(r'[0-9a-f]{64}', identities['candidate']['source_fingerprint']) is not None and
            identities['candidate']['source_fingerprint'] != BASELINE and
            identities['candidate']['source_commit'] == PARENT, 'DATE-parent/COUNTB source identity differs')
    for label, identity in identities.items():
        require(set(products[label]) == {'scriptw', 'runtime_baseline', 'compiler_precompiled_baseline'} and
                products[label]['compiler_precompiled_baseline']['sha256'] == identity['executable_sha256'] and
                identity['shared_configuration'] == identities['baseline']['shared_configuration'],
                'frozen product metadata differs')
    build, reuse = read('candidate-build.json'), read('baseline-reuse-proof.json')
    matches = reuse['committed_parent_matches_all54_Date_published_non_markdown_inputs']
    markdown, differences = reuse['historical_markdown_inputs'], reuse['accepted_markdown_differences']
    require(build['exit_code'] == 0 and build['head'] == PARENT and build['source_map'] == read(SOURCE_MAP) and
            reuse['accepted_commit'] == PARENT and
            reuse['original_identity'] == identities['baseline'] and reuse['baseline_products'] == products['baseline'] and
            len(matches) == 54 and not any(name.endswith('.md') for name in matches) and
            len(markdown) == 7 and all(name.endswith('.md') for name in markdown) and
            differences == {name: row for name, row in markdown.items() if row['same'] is False} and
            len(differences) == 3 and all(row['same'] is
                (row['historical_published_identity'] == row['accepted_parent_identity']) for row in markdown.values()),
            'candidate build or accepted54-source/7-historical-Markdown Date reuse proof differs')
    return dict(identities=identities, products=products, candidate_build=build,
                accepted_baseline_reuse_proof=reuse,
                identity_note='Accepted6365 production equals a9 and reuses actual a35 Date products built at7c47 plus their original frozen patch. All54 non-Markdown published inputs match accepted Git blobs;7 historical Markdown identities and3 later differences stay explicit. Products are not retagged as a6365 build.')


def prior_rejection_evidence():
    rows = []
    for stem, abi in [('append-key-summary-20261031', 43), ('append-key-lazy-summary-20261031', 44),
                      ('numeric-presence-i31-20261031', 45)]:
        path = ROOT / 'docs/rust-rewrite' / (stem + '.json')
        prior = read(path)
        require(prior['status'].lower().startswith('rejected') and
                prior['change']['runtime_abi_after'] == abi and
                prior['source']['candidate_fingerprint'] != read('candidate/identity.json')['source_fingerprint'],
                'historical summary evidence is not a separate rejected candidate')
        archive = path.parent / prior['archive']['file']
        require(archive.name == stem + '-inert.tar.xz' and archive.is_file() and not archive.is_symlink() and
                archive.stat().st_size == prior['archive']['bytes'] <= 64 * 1024**2,
                'historical public inert archive size/path differs')
        # These are public inert archives, never products or native images.
        with archive.open('rb') as stream:
            archive_sha = hashlib.file_digest(stream, 'sha256').hexdigest()
        require(archive_sha == prior['archive']['sha256'], 'historical public inert archive differs')
        rows.append(dict(report=origin(path), runtime_abi=abi,
                         candidate_fingerprint=prior['source']['candidate_fingerprint'], status=prior['status'],
                         archive=dict(path=str(archive.relative_to(ROOT)), bytes=archive.stat().st_size,
                                      sha256=archive_sha), baseline=False, candidate_validation_reused=False))
    return dict(reports=rows,
                scope='Committed6365 ABI43,44 and45 rejected reports/archives are read-only historical references; no baseline, candidate validation, acceptance or performance credit is reused. Accepted measurement baseline remains Date/a35/ABI42.')


def optional_followup(directory, source_plan, cases, hashes, lock, validators, cache):
    predeclaration = OUT / 'followup-predeclaration.json'
    paths = [directory / ('controls-normal-' + suffix + '.json') for suffix in ['plan', 'complete', 'analysis']]
    if not predeclaration.exists() and not any(path.exists() for path in paths):
        return None
    require(predeclaration.is_file() and all(path.is_file() for path in paths),
            'predeclared optional follow-up incomplete or missing approval')
    review = read(predeclaration)
    require(isinstance(review.get('reviewer'), str) and 'astra' in review['reviewer'].lower() and
            isinstance(review.get('status'), str) and review['status'].lower().startswith('approved') and
            isinstance(review.get('selected_cases'), list), 'explicit Astra follow-up predeclaration required')
    wanted = review['selected_cases']
    require(1 <= len(wanted) <= 8 and len(set(wanted)) == len(wanted) and
            set(wanted) <= {case['file'] for case in cases}, 'follow-up is not a bounded original-source subset')
    selected = [case for case in cases if case['file'] in wanted]
    names = [case['file'] for case in selected]
    plan, complete, analysis = [read(path) for path in paths]
    wrapper = OUT / 'targeted-normal-controls.py'
    wrapper_sha = digest(wrapper)
    require(plan['selected_cases'] == complete['cases'] == analysis['selected_cases'] == names and
            plan['cache_policy_before'] == complete['cache_policy_after'] ==
            analysis['cache_policy_before'] == analysis['cache_policy_after'] == cache and
            plan['followup_driver_sha256'] == complete['followup_driver_sha256'] ==
            analysis['followup_driver_sha256'] == review['followup_driver_sha256'] == wrapper_sha,
            'predeclared follow-up selection/wrapper/cache policy differs')
    # Read the frozen wrapper's literal annotation without executing/importing
    # it. Statistics are always recomputed by the original strict analyzer.
    scope_values = [keyword.value.value
                    for node in ast.parse(wrapper.read_text()).body
                    if isinstance(node, ast.FunctionDef) and node.name == 'save_analysis'
                    for call in ast.walk(node) if isinstance(call, ast.Call)
                    for keyword in call.keywords if keyword.arg == 'scope' and
                    isinstance(keyword.value, ast.Constant) and isinstance(keyword.value.value, str)]
    require(len(scope_values) == 1, 'follow-up wrapper literal scope annotation changed')
    captured = {}
    validators['inputs'] = lambda: (source_plan, selected, hashes)

    def capture(path, value):
        require(Path(path).name == 'controls-normal-analysis.json', 'unexpected follow-up output')
        value.update(scope=scope_values[0], cache_policy_before=cache, cache_policy_after=cache,
                     selected_cases=names, followup_driver_sha256=wrapper_sha)
        captured[Path(path).name] = value

    validators['save'] = capture
    validators['analyze']('controls-normal', ORDER, lock)
    require(captured == {'controls-normal-analysis.json': analysis}, 'optional follow-up raw reconstruction differs')
    return dict(predeclaration=review, plan=plan, completion=complete, analysis=analysis,
                raw_children=len(selected) * 3 * len(ORDER), followup_driver_sha256=wrapper_sha,
                scope='One explicitly predeclared original-source subset; same own products/images/normal cache; independent full raw reconstruction with no pooling/replacement of the complete21 cohort.')


def test262_evidence(products):
    plan, summary = read('test262-selection.json'), read('test262-candidate-summary.json')
    entries = {row['path']: row for row in plan['entries']}
    require(len(entries) == plan['original_file_count'] == len(summary['runs']) == 24,
            'original24 Test262 selection incomplete')
    root = ROOT / plan['suite_root'] / 'test'
    push = {str(path.relative_to(root)) for path in (root / 'built-ins/Array/prototype/push').rglob('*.js')}
    require(len(push) == 24 and push == set(entries), 'complete24 original push family differs')
    actual, variants, raws = set(), 0, []
    for run in summary['runs']:
        name = run['scope']
        require(name in entries and name not in actual and run['product'] == 'candidate' and
                run['exit_code'] == 0 and run['total'] == run['passed'] > 0 and
                run['executable_sha256'] == products['products']['candidate']['scriptw']['sha256'],
                'Test262 run incomplete, duplicated or wrong product')
        path = root / name
        require(path.stat().st_size == entries[name]['bytes'] and digest(path) == entries[name]['sha256'],
                'original Test262 source differs')
        argv = run['argv']
        require(argv[0] == str(OUT / 'candidate/scriptw') and argv[argv.index('run') + 1] == name and
                argv[argv.index('--execution-backend') + 1] == 'wasm-aot' and
                Path(run['raw']).name == run['raw'], 'Test262 raw selector/backend differs')
        raw = inert(OUT / run['raw']).read_text()
        require(re.findall(r'^total: (\d+)$', raw, re.M) == [str(run['total'])] and
                re.findall(r'^passed: (\d+)$', raw, re.M) == [str(run['passed'])], 'Test262 raw totals differ')
        actual.add(name)
        variants += run['passed']
        raws.append(origin(OUT / run['raw']))
    require(actual == set(entries), 'Test262 original-file coverage differs')
    return dict(original_files=24, complete_push_files=24, adjoining_subset_files=0,
                actual_passing_variants=variants, selection=plan, summary=summary, raw_origins=raws,
                scope='Complete pinned24-file push family only; actual variants derive from completed raw runs. No complete Array/Object/Reflect/full-Test262 or status publication claim.')


def measurement_evidence(products):
    directory = OUT / 'measurement'
    lock = read(directory / 'product-lock.json')
    hashes, plan = read(directory / 'source-hashes.json'), read(directory / 'sources/manifest.json')
    canonical = ROOT / 'crates/scriptw-cli/tests/fixtures/v8_execution_hotpaths'
    canonical_plan = read(canonical / 'manifest.json')
    cases = [*plan['execution'], plan['startup']]
    require(len(cases) == len({case['file'] for case in cases}) == 21 and
            [case['file'] for case in plan['execution'][17:]] == DATE_FILES and lock['source_hashes'] == hashes,
            'measurement21 source inventory differs')
    require(plan['execution'][:17] == canonical_plan['execution'] and
            plan['startup'] == canonical_plan['startup'], 'canonical source gate changed')
    for case in [*canonical_plan['execution'], canonical_plan['startup']]:
        require(digest(directory / 'sources' / case['file']) == digest(canonical / case['file']),
                'canonical source copy changed: ' + case['file'])
    for name, sha in hashes.items():
        require(Path(name).name == name and digest(directory / 'sources' / name) == sha, 'measurement source changed')
    for name, sha in lock['support'].items():
        require(digest(ROOT / name) == sha, 'bound measurement validator/support changed')
    for label in ['baseline', 'candidate']:
        require(lock[label]['identity'] == products['identities'][label] and
                lock[label]['expected_runtime_abi'] == (42 if label == 'baseline' else 46), 'measurement product identity differs')
        for tool in ['compiler_precompiled_baseline', 'runtime_baseline']:
            require(lock[label]['products'][tool]['sha256'] == products['products'][label][tool]['sha256'] and
                    lock[label]['products'][tool]['bytes'] == products['products'][label][tool]['bytes'],
                    'measurement product metadata differs')
    # Reuse the measured driver's exact pure validators; never call its product
    # checks, native-image loader, prepare, invoke, measure or main functions.
    selected = {'require', 'check_report_identity', 'statistics_row', 'retained_wrapper', 'producer_header',
                'image_group', 'image_directory', 'arguments', 'observations', 'score',
                'boundary_scope', 'policy_key', 'validate_cache_policy', 'analyze'}
    tree = ast.parse((directory / 'cohort.py').read_text())
    definitions = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name in selected]
    require({node.name for node in definitions} == selected, 'measurement pure-validator interface changed')
    captured, producers = {}, {}
    namespace = dict(OUT=directory, ROOT=ROOT, Path=Path, statistics=statistics,
                     NORMAL_CACHE=OUT / 'normal-cache',
                     DATE_FILES=DATE_FILES, BOUNDARIES=['original', 'retained', 'ordinary'], SAMPLES=21, WARMUPS=10,
                     load=read, digest=digest, inputs=lambda: (plan, cases, hashes),
                     save=lambda path, value: captured.update({Path(path).name: value}))
    exec(compile(ast.Module(body=definitions, type_ignores=[]), str(directory / 'cohort.py'), 'exec'), namespace)
    groups = dict(original=cases, **{'retained-canonical': plan['execution'][:17],
                                   'retained-date': [*plan['execution'][17:], plan['startup'], *plan['execution'][4:17]]})
    for label in ['baseline', 'candidate']:
        for group, expected in groups.items():
            folder = directory / f'images-{label}-{group}'
            report = read(folder / 'producer.json')
            namespace['producer_header'](report, label, group, lock, expected,
                                         digest(directory / ('prepared-' + group) / 'manifest.json'))
            for case in report['cases']:
                if group.startswith('retained-'):
                    require(read(folder / Path(case['image']).with_suffix('.json')) == case,
                            'retained sidecar differs')
                    original, derived = folder / case['original_source_file'], folder / case['derived_source_file']
                    require(digest(original) == case['original_source_sha256'] and
                            digest(derived) == case['derived_source_sha256'] and
                            derived.read_text() == namespace['retained_wrapper'](original.read_text()),
                            'retained exact wrapper/provenance differs')
            producers[label, group] = report
    namespace['producer'] = lambda label, group, bound: producers[label, group]
    namespace['analyze']('balanced', ORDER, lock)
    analysis = read(directory / 'balanced-analysis.json')
    require(captured == {'balanced-analysis.json': analysis}, 'saved analysis differs from strict raw reassembly')
    require(lock['schema'] == 'scriptw-packed-count-presence-product-lock-v1' and
            lock['baseline']['cohort'] == 'DATE-parent' and lock['candidate']['cohort'] == 'COUNTB',
            'measurement cohort labels/lock schema differ')
    namespace['validate_cache_policy'](lock['cache_policy_at_bind'])
    before, after = analysis['cache_policy_before'], analysis['cache_policy_after']
    require(before == after == lock['cache_policy_at_bind'], 'normal cache substrate changed after binding')
    followup = optional_followup(directory, plan, cases, hashes, lock, namespace, before)
    node = node_evidence(directory, cases, hashes, namespace)
    reference = node['verification']
    namespace['validate_cache_policy'](reference['cache_policy_before'])
    require(reference['cache_policy_before'] == reference['cache_policy_after'] == before,
            'fresh COUNTB Node command cache binding differs')
    return dict(directory='measurement', analysis_file='measurement/balanced-analysis.json',
                analysis_sha256=digest(directory / 'balanced-analysis.json'), product_lock=lock,
                plan=read(directory / 'balanced-plan.json'), completion=read(directory / 'balanced-complete.json'),
                analysis=analysis, raw_children=504, independent_node_goldens=node,
                targeted_followup=followup,
                raw_validation='Unchanged strict analyzer reconstructs the full504 children and any separately predeclared follow-up. Exact source/producers/sidecars/argv/identities/resources/normal-overlay cache/warmup/output/timing/RSS checked without native product/image reads.',
                scope='Complete21-source normal-overlay DATE-parent versus COUNTB cohort; optional predeclared follow-up stays separate with no pooling/replacement. Fresh original, ordinary and retained boundaries remain distinct; no subtraction, causal RSS benefit or parity inferred.')



def node_evidence(directory, cases, hashes, validators):
    reference = read(directory / 'reference-node-verification.json')
    require(reference['status'] == 'Independently verified' and
            reference['cases'] == [case['file'] for case in cases] and reference['source_hashes'] == hashes and
            reference['samples'] == 21 and reference['warmups_checked'] == 10,
            'independent Node reference scope differs')
    harness = ROOT / 'crates/scriptw-cli/tests/fixtures/v8_baseline/node-runtime.cjs'
    require(reference['harness_sha256'] == digest(harness), 'Node reference harness changed')
    raw = []
    for case in cases:
        stem = 'reference-node-' + case['file']
        report, command = read(directory / (stem + '.stdout')), read(directory / (stem + '.command.json'))
        require(command['argv'] == [reference['node'], str(harness), str(directory / 'prepared-original'),
                                    '21', '10', case['file']] and command['exit_code'] == 0 and
                command['timed_out'] is False and command['cwd'] == str(ROOT) and
                command['executable_sha256'] == reference['executable_sha256'] and
                command['resource_policy_unchanged'] is True and
                all(delta == 0 for delta in command['oom_event_delta'].values()) and
                validators['policy_key'](command['resources_before']) ==
                validators['policy_key'](command['resources_after']),
                'Node reference raw command/resources differ')
        require(report['schema'] == 'scriptw-v8-baseline-v2' and report['samples'] == 21 and
                report['warmups'] == 10 and len(report['cases']) == 1 and
                dict(node=report['node'], v8=report['v8']) == reference['versions'],
                'Node reference identity/counts differ')
        actual = report['cases'][0]
        require(actual['file'] == case['file'] and actual['source_sha256'] == hashes[case['file']] and
                len(actual['observations']) == 31 and all(
                    value['warmup'] is (index < 10) and value['stdout'] == case['stdout']
                    for index, value in enumerate(actual['observations'])), 'Node reference outputs differ')
        raw.extend(origin(directory / (stem + suffix), archive=True) for suffix in ['.stdout', '.stderr', '.command.json'])
    return dict(verification=reference, raw_origins=raw,
                scope='All21 original source goldens in the existing fresh-context Node/V8 harness; independent output/reference scope, not Scriptw native-cache admission or normal-substrate performance qualification.')


def main():
    required = ['decision.json', 'candidate/identity.json', 'candidate/products.json', 'candidate-build.json',
                'native-final-summary.json', 'native-plan.json', 'compiled-inputs.json', 'source-map-at-freeze.json',
                MANIFEST, SOURCE_MAP, 'test-repair-reuse-proof-final.json', 'native-evidence-limits.json',
                'test262-candidate-summary.json', 'measurement/product-lock.json',
                'measurement/balanced-plan.json', 'measurement/balanced-complete.json',
                'measurement/balanced-analysis.json', 'measurement/reference-node-verification.json']
    for name in required:
        inert(OUT / name)
    decision = read('decision.json')
    def narrative(value):
        return (isinstance(value, str) and bool(value.strip())) or (
            isinstance(value, list) and bool(value) and
            all(isinstance(item, str) and bool(item.strip()) for item in value))
    require(all(isinstance(decision.get(key), str) and decision[key].strip()
                for key in ['status', 'reviewer']) and 'astra' in decision['reviewer'].lower() and
            all(narrative(decision.get(key)) for key in ['basis', 'next']) and
            isinstance(decision.get('limits'), list) and decision['limits'] and
            all(isinstance(value, str) and value.strip() for value in decision['limits']) and
            decision['status'].lower().startswith(('accepted', 'rejected')),
            'explicit completed Astra decision required')
    products = product_metadata()
    require(decision['candidateFP'] == products['identities']['candidate']['source_fingerprint'] and
            decision['runtimeABI'] == 46 and decision['accepted_baselineFP'] == BASELINE and
            decision['accepted_runtimeABI'] == 42 and decision['candidate_parent'] == PARENT,
            'explicit decision source/ABI binding differs')
    native = source_and_native()
    suite = test262_evidence(products)
    measurement = measurement_evidence(products)
    prior = prior_rejection_evidence()
    report = dict(schema='scriptw-packed-count-presence-v1', complete=True,
                  recorded_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  status=decision['status'], decision=decision,
                  source=dict(parent_commit=PARENT, candidate_fingerprint=products['identities']['candidate']['source_fingerprint'],
                              **products, snapshot=native['snapshot'], implementation_snapshot=native['implementation_snapshot'],
                              source_versions=native['source_versions'], inputs=native['inputs'],
                              patch_sha256=native['patch_sha256']),
                  change=dict(runtime_abi_before=42, runtime_abi_after=46, default_runtime_policy_changed=False,
                              behavior='An Array-only scalar word reuses the existing physical I64 COUNT field: low32 logical indexed count, bits32..47 small numeric presence and bit63 flag, with remaining high bits zero. Active small capacities4/8/16 borrow the original empty nominal bitmap; capacities32 and above retain allocated nominal bitmaps. NUMBER_PRESENT remains concrete nonnull nominal storage, with no i31/EqRef union. Numeric insert/delete commits count and mask together; overwrites preserve count; nonempty promotion removes metadata while preserving count. Existing Number bits, indexed modes, occupancy admission, growth, literal effects, holes and descriptors remain.',
                              scalar_word=dict(logical_count_bits=[0,31], small_presence_bits=[32,47],
                                               small_flag_bit=63, reserved_zero_bits=[48,62],
                                               small_capacities=[4,8,16], heap_bitmap_minimum_capacity=32,
                                               empty_word=0, inactive_modes='plain logical count with no high metadata',
                                               raw_COUNT_authority='private gc_types codec; all25 direct external sites migrated',
                                               new_indexed_modes=0, new_runtime_globals=0,
                                               new_runtime_helpers=0, new_gc_roots=0),
                              array_layout=native['array_layout'],
                              nominal_bitmap_allocation=native['nominal_bitmap_allocation'],
                              allocation_accounting=dict(conditional_records_removed_per_active_small_numeric_array=1,
                                  record_kind='one-word nominal NumberPresenceU64Array',
                                  one_word_record_bytes=32, retained_objects_child_arrays=8192,
                                  conditional_records_removed=8192, conditional_live_bytes_removed=262144,
                                  qualification='Conditional encoded-route/collector accounting for8192 active four-number child Arrays. No whole-heap allocation census, fixed startup RSS reduction, causal measured-memory benefit or Scriptc parity is inferred. The64-byte Array owner and Number backing remain.')),
                  validation=dict(native=native, test262=suite),
                  measurement=measurement, prior_rejection_evidence=prior,
                  limits=[f"{native['unique_passes']} distinct source-bound passes cover the selected10-scope union: original passing library/link scopes plus final repaired scopes. This is not one fresh final-source execution or complete Engine/workspace coverage.",
                          'Original library/link passes retain V1 sources/images under an explicit test-only reuse proof; only2 emission tests changed and all23 other inputs/production are identical. Original and repair1 passing emission siblings are superseded by the final full rerun. Both library cases share the original receipt. Emission uses one image for3 disjoint filters and language uses one image for2 filters; all3 keep/use transitions and final retirements retain exact SHA/size/path/source continuity.',
                          'Two full structural-witness failures retain their frozen image metadata. The focused failing diagnostic lost its mutable image after a retirement-wrapper TypeError; actual source/transcript/SHA and the honest native-evidence limit remain. No diagnostic reconstruction or re-execution is claimed.',
                          'Test262 covers the complete24-file pinned push family only; actual variants derive from completed raw runs.',
                          'All21 source controls, all three actual boundaries and every slower round/group/sample remain visible; no boundary subtraction or inferred memory/parity claim.',
                          'At most one explicitly Astra-predeclared subset of at most8 original sources may be reconstructed separately on the same products/images/normal cache. It cannot replace or pool with the complete504 children.',
                          'The closed-comparison cache relocation journal is a post-rejection resource event for earlier experiments, not active COUNTB evidence. COUNTB canonical normal-cache is fresh overlay; native verification cache under/tmp is separate. Any historical failures/deferrals remain recorded, never passing coverage. Cache/symlink/native payloads are excluded from the archive.',
                          'Committed rejected ABI43,44 and45 reports/archives are unchanged historical references, never a baseline or reused candidate acceptance.',
                          'Native identities are read from frozen receipts; this assembler never reads, hashes or executes native products/images. Full-suite status, published charts and release acceptance are unchanged.'])
    with (OUT / 'report-core.json').open('x') as stream:
        stream.write(json.dumps(report, indent=2) + '\n')
    print(json.dumps(dict(output='report-core.json', status=report['status'], native_unique=native['unique_passes'],
                          test262_original_files=suite['original_files'],
                          test262_actual_variants=suite['actual_passing_variants'], workload_rows=21), indent=2))


if __name__ == '__main__':
    main()
