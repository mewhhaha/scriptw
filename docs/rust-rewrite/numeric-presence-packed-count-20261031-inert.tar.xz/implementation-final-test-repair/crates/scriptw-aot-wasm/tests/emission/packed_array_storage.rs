//! P calls shared R publication, physical Number/bitmap and descriptor owners.
use super::property_read_plans::{
    array_count_read_roles, frame_else, frame_end, local_producer, metadata_strip_sources,
    reference_operand, scalar_presence_decodes,
};
use scriptw_aot_wasm::{
    emit_with_rooted_snapshot, GcSnapshotLayout, PromiseRejectionPolicy, RUNTIME_IMPORT_NAMESPACE,
};
use scriptw_front::{parse, ParseOptions};
use scriptw_ir::{lower, ExprIr, SpecOperationIr, StatementIr};
use std::collections::BTreeMap;
use wasmparser::{
    ExternalKind, HeapType, KnownCustom, Name, Operator, Parser, Payload, TypeRef, UnpackedIndex,
    ValType, Validator, WasmFeatures,
};

#[derive(Default)]
struct Module<'a> {
    types: Vec<wasmparser::SubType>,
    type_group_sizes: Vec<usize>,
    names: BTreeMap<u32, String>,
    imports: BTreeMap<u32, (String, String)>,
    functions: BTreeMap<u32, Vec<Operator<'a>>>,
    body_bytes: BTreeMap<u32, usize>,
    exports: BTreeMap<String, u32>,
    globals: Vec<wasmparser::GlobalType>,
    global_initializers: BTreeMap<u32, Vec<Operator<'a>>>,
    global_exports: BTreeMap<String, u32>,
}

impl<'a> Module<'a> {
    fn read(bytes: &'a [u8]) -> Self {
        let mut output = Self::default();
        let mut next = 0;
        for payload in Parser::new(0).parse_all(bytes) {
            match payload.unwrap() {
                Payload::TypeSection(reader) => {
                    for group in reader {
                        let group = group.unwrap();
                        output.type_group_sizes.push(group.types().len());
                        output.types.extend(group.types().cloned());
                    }
                }
                Payload::ImportSection(reader) => {
                    for import in reader.into_imports() {
                        let import = import.unwrap();
                        match import.ty {
                            TypeRef::Func(_) | TypeRef::FuncExact(_) => {
                                output
                                    .imports
                                    .insert(next, (import.module.into(), import.name.into()));
                                next += 1;
                            }
                            TypeRef::Global(ty) => output.globals.push(ty),
                            _ => {}
                        }
                    }
                }
                Payload::GlobalSection(reader) => {
                    for global in reader {
                        let global = global.unwrap();
                        let index = output.globals.len() as u32;
                        output.globals.push(global.ty);
                        output.global_initializers.insert(
                            index,
                            global
                                .init_expr
                                .get_operators_reader()
                                .into_iter()
                                .map(Result::unwrap)
                                .collect(),
                        );
                    }
                }
                Payload::ExportSection(reader) => {
                    for export in reader {
                        let export = export.unwrap();
                        match export.kind {
                            ExternalKind::Func => {
                                output.exports.insert(export.name.into(), export.index);
                            }
                            ExternalKind::Global => {
                                output
                                    .global_exports
                                    .insert(export.name.into(), export.index);
                            }
                            _ => {}
                        }
                    }
                }
                Payload::CodeSectionEntry(body) => {
                    output.body_bytes.insert(next, body.range().len());
                    output.functions.insert(
                        next,
                        body.get_operators_reader()
                            .unwrap()
                            .into_iter()
                            .map(Result::unwrap)
                            .collect(),
                    );
                    next += 1;
                }
                Payload::CustomSection(section) => {
                    if let KnownCustom::Name(reader) = section.as_known() {
                        for subsection in reader {
                            if let Name::Function(names) = subsection.unwrap() {
                                for name in names {
                                    let name = name.unwrap();
                                    output.names.insert(name.index, name.name.into());
                                }
                            }
                        }
                    }
                }
                _ => {}
            }
        }
        output
    }

    fn named(&self, prefix: &str) -> (u32, &[Operator<'a>]) {
        let names = self
            .names
            .iter()
            .filter(|(_, name)| {
                if prefix.ends_with('#') {
                    assert!(
                        prefix.starts_with("js::"),
                        "only an explicit source function prefix may end in '#': {prefix}"
                    );
                    name.starts_with(prefix)
                } else {
                    name.as_str() == prefix
                }
            })
            .collect::<Vec<_>>();
        assert_eq!(
            names.len(),
            1,
            "one actual body for {prefix}; matching names: {names:?}"
        );
        let index = *names[0].0;
        (index, self.functions.get(&index).unwrap())
    }

    fn witness_type(&self, layout: GcSnapshotLayout) -> u32 {
        let index = *self
            .global_exports
            .get(layout.witness_export())
            .unwrap_or_else(|| panic!("observation owner must export {:?} witness", layout));
        let ValType::Ref(reference) = self.globals[index as usize].content_type else {
            panic!("typed GC witness");
        };
        let HeapType::Concrete(UnpackedIndex::Module(index)) = reference.heap_type() else {
            panic!("concrete witness");
        };
        index
    }

    fn empty_array_global(&self, array: u32) -> u32 {
        let globals = self.global_initializers.iter().filter_map(|(&index, initializer)| {
            let declaration = self.globals[index as usize];
            (!declaration.mutable && matches!(declaration.content_type, ValType::Ref(reference)
                if !reference.is_nullable() && reference.heap_type() == HeapType::Concrete(UnpackedIndex::Module(array)))
                && matches!(&initializer[..], [Operator::ArrayNewFixed { array_type_index, array_size: 0 }, Operator::End]
                    if *array_type_index == array)).then_some(index)
        }).collect::<Vec<_>>();
        assert_eq!(
            globals.len(),
            1,
            "one immutable canonical empty global of the actual nominal array type"
        );
        globals[0]
    }

    fn imported_runtime(&self, runtime: &Self, definition: u32) -> u32 {
        let indices = self
            .imports
            .iter()
            .filter_map(|(&index, (namespace, name))| {
                (namespace == RUNTIME_IMPORT_NAMESPACE
                    && runtime.exports.get(name) == Some(&definition))
                .then_some(index)
            })
            .collect::<Vec<_>>();
        assert_eq!(
            indices.len(),
            1,
            "actual exported R definition is linked into P"
        );
        indices[0]
    }
}

fn calls(body: &[Operator<'_>], target: u32) -> bool {
    body.iter().any(|operator| {
        matches!(operator,
        Operator::Call { function_index } | Operator::ReturnCall { function_index }
            if *function_index == target)
    })
}

fn primitive_only(body: &[Operator<'_>]) -> bool {
    !body.iter().any(|op| {
        matches!(
            op,
            Operator::Call { .. }
                | Operator::ReturnCall { .. }
                | Operator::CallRef { .. }
                | Operator::CallIndirect { .. }
                | Operator::ReturnCallRef { .. }
                | Operator::ReturnCallIndirect { .. }
                | Operator::StructNew { .. }
                | Operator::StructNewDefault { .. }
                | Operator::ArrayNew { .. }
                | Operator::ArrayNewDefault { .. }
                | Operator::ArrayNewFixed { .. }
                | Operator::ArrayNewData { .. }
                | Operator::ArrayNewElem { .. }
                | Operator::RefI31
        )
    })
}

fn field_owner(body: &[Operator<'_>], write: usize) -> u32 {
    let mut operands = body[..write]
        .iter()
        .rev()
        .filter(|op| !matches!(op, Operator::RefAsNonNull));
    operands
        .next()
        .expect("the completed field value has an operand");
    let Some(Operator::LocalGet { local_index }) = operands.next() else {
        panic!("the field owner remains rooted")
    };
    *local_index
}

fn word_constant(body: &[Operator<'_>], write: usize) -> i64 {
    let position = match body[write - 1] {
        Operator::LocalGet { local_index } => local_producer(body, write - 1, local_index),
        _ => write - 1,
    };
    let Operator::I64Const { value } = body[position] else {
        panic!("the complete literal word has a closed constant producer")
    };
    value
}

// Follow the actual scalar-bit publication frames rather than counting all
// COUNT stores in a helper that also owns unrelated storage modes.
fn scalar_bit_publications(
    body: &[Operator<'_>],
    array: u32,
    bitmap: u32,
    numbers: u32,
    insert: bool,
) -> usize {
    let mut checked = 0;
    for (zero, ops) in body.windows(3).enumerate() {
        let [Operator::LocalGet { local_index: count }, Operator::I64Eqz, Operator::If { .. }] =
            ops
        else {
            continue;
        };
        let inner = zero + 2;
        let Some(nonzero) = frame_else(body, inner) else {
            continue;
        };
        let end = frame_end(body, inner);
        let [Operator::I64Const { value: 0 }, Operator::LocalSet {
            local_index: encoded,
        }] = &body[inner + 1..nonzero]
        else {
            continue;
        };
        let [Operator::LocalGet { local_index: bits }, Operator::I64Const { value: 32 }, Operator::I64Shl, Operator::LocalGet {
            local_index: encoded_count,
        }, Operator::I64Or, Operator::I64Const { value: i64::MIN }, Operator::I64Or, Operator::LocalSet {
            local_index: result,
        }] = &body[nonzero + 1..end]
        else {
            continue;
        };
        assert_eq!(count, encoded_count);
        assert_eq!(
            encoded, result,
            "zero and nonzero small results merge in one complete word"
        );
        let outer = zero
            .checked_sub(2)
            .expect("the zero case belongs to a small-state If");
        let [Operator::LocalGet { local_index: small }, Operator::If { .. }] = &body[outer..zero]
        else {
            panic!("only active-small state selects scalar encoding")
        };
        let alternative = frame_else(body, outer + 1).unwrap();
        assert_eq!(
            alternative,
            end + 1,
            "the heap update is the other representation arm"
        );
        let complete = frame_end(body, outer + 1);
        let writes = (alternative + 1..complete)
            .filter(|&position| {
                matches!(body[position],
            Operator::ArraySet { array_type_index } if array_type_index == bitmap)
            })
            .collect::<Vec<_>>();
        assert_eq!(
            writes.len(),
            1,
            "plain state retains exactly one actual bitmap update"
        );
        assert!(
            matches!(body[writes[0] - 1], Operator::LocalGet { local_index } if local_index == *bits)
        );
        assert!(matches!(&body[writes[0] + 1..complete],
            [Operator::LocalGet { local_index }, Operator::LocalSet { local_index: output }]
                if local_index == count && output == encoded));
        let commit = complete + 4;
        assert!(matches!(&body[complete + 1..commit],
            [Operator::LocalGet { .. }, Operator::RefAsNonNull, Operator::LocalGet { local_index }]
                if local_index == encoded));
        assert!(
            matches!(body[commit], Operator::StructSet { struct_type_index, field_index }
            if struct_type_index == array && field_index == scriptw_aot_wasm::GcSnapshotField::ArrayCount.index())
        );
        assert_eq!(body[outer..=commit].iter().filter(|op| matches!(op,
            Operator::StructSet { struct_type_index, field_index }
                if *struct_type_index == array && *field_index == scriptw_aot_wasm::GcSnapshotField::ArrayCount.index())).count(), 1,
            "mask and count publish once after the mutually exclusive representation arms");
        let flag = local_producer(body, outer, *small);
        assert!(matches!(body[flag], Operator::I64LtS));
        let [Operator::LocalGet { local_index: raw }, Operator::I64Const { value: 0 }] =
            &body[flag - 2..flag]
        else {
            panic!("the cached small discriminator tests the raw COUNT flag")
        };
        let source = local_producer(body, flag - 2, *raw);
        assert!(
            matches!(body[source], Operator::StructGet { struct_type_index, field_index }
            if struct_type_index == array && field_index == scriptw_aot_wasm::GcSnapshotField::ArrayCount.index())
        );
        assert_eq!(
            reference_operand(body, source),
            field_owner(body, commit),
            "the combined word returns to the retained owner that supplied it"
        );
        assert!(
            matches!(&body[commit + 1..commit + 3],
            [Operator::LocalGet { local_index }, Operator::LocalSet { local_index: cached }]
                if local_index == encoded && cached == raw),
            "the owner and cached word synchronize without a second publication"
        );
        assert!(
            primitive_only(&body[outer..commit + 3]),
            "bit publication is callback/allocation free"
        );
        let delta = local_producer(body, zero, *count);
        if insert {
            assert!(
                matches!(&body[delta - 2..=delta],
                [Operator::LocalGet { local_index }, Operator::I64Const { value: 1 }, Operator::I64Add]
                    if local_index == count),
                "an absent insertion increments logical occupancy exactly once"
            );
            let missing = (6..delta).rev().find(|&position| {
                matches!(&body[position - 6..=position],
                    [Operator::LocalGet { local_index }, Operator::LocalGet { .. }, Operator::I64And,
                     Operator::I64Eqz, Operator::I32Eqz, Operator::I32Eqz, Operator::If { .. }]
                        if local_index == bits)
                    && frame_end(body, position) == commit + 3
            }).expect("only an absent old bit enters count/mask/bitmap publication");
            assert!(
                frame_else(body, missing).is_none(),
                "overwrite skips metadata publication entirely"
            );
            let payload = (0..missing - 6)
                .rev()
                .find(|&position| {
                    matches!(body[position],
                Operator::ArraySet { array_type_index } if array_type_index == numbers)
                })
                .expect("Number overwrites publish payload before testing old occupancy");
            let payload_owner =
                local_producer(body, payload - 2, reference_operand(body, payload - 2));
            assert!(
                matches!(body[payload_owner], Operator::StructGet { struct_type_index, field_index }
                if struct_type_index == array && field_index == scriptw_aot_wasm::GcSnapshotField::ArrayNumbers.index())
            );
            assert_eq!(
                reference_operand(body, payload_owner),
                field_owner(body, commit)
            );
            assert!(primitive_only(&body[payload + 1..missing]));
            assert!(
                !body[missing + 1..commit].iter().any(|op| matches!(op,
                Operator::ArraySet { array_type_index } if *array_type_index == numbers)),
                "the metadata guard cannot suppress an existing-slot Number payload update"
            );
        } else {
            assert!(
                matches!(&body[delta - 7..=delta],
                [Operator::LocalGet { local_index }, Operator::LocalGet { local_index: old_bits }, Operator::LocalGet { .. },
                 Operator::I64And, Operator::I64Eqz, Operator::I32Eqz, Operator::I64ExtendI32U, Operator::I64Sub]
                    if local_index == count && old_bits == bits),
                "deletion decrements exactly the old occupied bit"
            );
        }
        let changed = local_producer(body, zero, *bits);
        assert!(
            if insert {
                matches!(body[changed], Operator::I64Or)
            } else {
                matches!(
                    &body[changed - 2..=changed],
                    [
                        Operator::I64Const { value: -1 },
                        Operator::I64Xor,
                        Operator::I64And
                    ]
                )
            },
            "the same publication contains the inserted or removed presence bit"
        );
        assert!(body[source + 1..delta].windows(4).any(|ops| matches!(ops,
            [Operator::LocalGet { local_index }, Operator::I32WrapI64, Operator::I64ExtendI32U, Operator::LocalSet { .. }]
                if local_index == raw)), "occupancy arithmetic starts from the decoded low32");
        checked += 1;
    }
    checked
}

fn complete_numeric_growth(body: &[Operator<'_>], array: u32, numbers: u32, bitmap: u32) -> usize {
    use scriptw_aot_wasm::GcSnapshotField as Field;
    let fields = body
        .iter()
        .enumerate()
        .filter_map(|(position, op)| match op {
            Operator::StructSet {
                struct_type_index,
                field_index,
            } if *struct_type_index == array => Some((position, *field_index)),
            _ => None,
        })
        .collect::<Vec<_>>();
    let mut checked = 0;
    for writes in fields.windows(3) {
        let [(number_write, number_field), (presence_write, presence_field), (commit, count_field)] =
            writes
        else {
            unreachable!()
        };
        if (*number_field, *presence_field, *count_field)
            != (
                Field::ArrayNumbers.index(),
                Field::ArrayNumberPresent.index(),
                Field::ArrayCount.index(),
            )
        {
            continue;
        }
        let number_root = reference_operand(body, *number_write);
        let presence_root = reference_operand(body, *presence_write);
        let number_new = local_producer(body, *number_write, number_root);
        let bitmap_new = local_producer(body, *presence_write, presence_root);
        assert!(
            matches!(body[number_new], Operator::ArrayNew { array_type_index } if array_type_index == numbers)
        );
        assert!(
            matches!(body[bitmap_new], Operator::ArrayNew { array_type_index } if array_type_index == bitmap)
        );
        let Operator::LocalGet { local_index: grown } = body[number_new - 1] else {
            panic!("the actual new Number capacity is rooted")
        };
        let cap = (number_new + 1..bitmap_new).find(|&position| matches!(&body[position..position + 4],
            [Operator::LocalGet { local_index }, Operator::I32Const { value: 16 }, Operator::I32GtU, Operator::If { .. }]
                if *local_index == grown)).expect("only capacities above16 allocate the nominal bitmap");
        let cap_end = frame_end(body, cap + 3);
        assert!(bitmap_new < cap_end);
        let bitmap_allocations = (number_new + 1..*number_write)
            .filter(|&position| {
                matches!(body[position],
            Operator::ArrayNew { array_type_index } | Operator::ArrayNewDefault { array_type_index }
            | Operator::ArrayNewFixed { array_type_index, .. } if array_type_index == bitmap)
            })
            .collect::<Vec<_>>();
        assert_eq!(bitmap_allocations, [bitmap_new],
            "small growth allocates no bitmap; the sole large allocation stays under the actual-capacity guard");
        let payload_copy = (number_new + 1..cap)
            .find(|&position| {
                matches!(body[position],
            Operator::ArrayCopy { array_type_index_dst, array_type_index_src }
                if array_type_index_dst == numbers && array_type_index_src == numbers)
            })
            .expect("growth retains the actual Number prefix");
        assert_eq!(reference_operand(body, payload_copy - 5), number_root);
        let Operator::LocalGet { local_index: words } = body[bitmap_new - 1] else {
            panic!("bitmap allocation uses the prepared word extent")
        };
        let extent = local_producer(body, bitmap_new - 1, words);
        assert!(
            matches!(&body[extent - 4..=extent],
            [Operator::LocalGet { local_index }, Operator::I32Const { value: 63 }, Operator::I32Add,
             Operator::I32Const { value: 6 }, Operator::I32ShrU] if *local_index == grown),
            "large presence allocates ceil(actual new Number capacity/64) words"
        );
        assert!(
            matches!(body[bitmap_new - 2], Operator::I64Const { value: 0 }),
            "the full heap bitmap starts zeroed"
        );
        let old_choice = (bitmap_new + 1..cap_end)
            .find(|&position| {
                matches!(
                    &body[position..position + 4],
                    [
                        Operator::LocalGet { .. },
                        Operator::I32Const { value: 16 },
                        Operator::I32LeU,
                        Operator::If { .. }
                    ]
                )
            })
            .expect("growth distinguishes old small storage from the nominal bitmap");
        let old_else = frame_else(body, old_choice + 3).unwrap();
        let old_end = frame_end(body, old_choice + 3);
        assert_eq!(
            scalar_presence_decodes(&body[..old_else], array, bitmap),
            1,
            "small-to-large growth seeds the complete decoded old mask"
        );
        let seed = (old_choice + 4..old_else)
            .find(|&position| {
                matches!(body[position],
            Operator::ArraySet { array_type_index } if array_type_index == bitmap)
            })
            .unwrap();
        assert_eq!(reference_operand(body, seed - 2), presence_root);
        let Operator::LocalGet { local_index: zero } = body[seed - 2] else {
            panic!("small mask seeds word0")
        };
        assert!(matches!(
            body[local_producer(body, seed - 2, zero)],
            Operator::I32Const { value: 0 }
        ));
        let copy = (old_else + 1..old_end)
            .find(|&position| {
                matches!(body[position],
            Operator::ArrayCopy { array_type_index_dst, array_type_index_src }
                if array_type_index_dst == bitmap && array_type_index_src == bitmap)
            })
            .expect("large growth preserves every old nominal bitmap word");
        assert_eq!(
            reference_operand(body, copy - 5),
            presence_root,
            "large growth copies into the same private bitmap later published"
        );
        let old_bitmap = reference_operand(body, copy - 2);
        let Operator::LocalGet {
            local_index: copied_words,
        } = body[copy - 1]
        else {
            panic!("the full old bitmap extent is rooted")
        };
        let old_length = local_producer(body, copy - 1, copied_words);
        assert!(matches!(body[old_length], Operator::ArrayLen));
        assert_eq!(
            reference_operand(body, old_length),
            old_bitmap,
            "the actual old nominal bitmap length controls the entire prefix copy"
        );
        let inserts = (old_end + 1..cap_end)
            .filter(|&position| {
                matches!(body[position],
            Operator::ArraySet { array_type_index } if array_type_index == bitmap)
            })
            .collect::<Vec<_>>();
        assert_eq!(
            inserts.len(),
            1,
            "heap growth applies the inserted bit before publication"
        );
        let insert = inserts[0];
        assert_eq!(reference_operand(body, insert - 2), presence_root);
        let Operator::LocalGet { local_index: bits } = body[insert - 1] else {
            panic!("the prepared heap word is rooted")
        };
        let merge = local_producer(body, insert - 1, bits);
        assert!(matches!(&body[merge - 5..=merge],
            [Operator::LocalGet { local_index }, Operator::I64Const { value: 1 }, Operator::LocalGet { .. },
             Operator::I64ExtendI32U, Operator::I64Shl, Operator::I64Or] if *local_index == bits));
        let number_value = (cap_end + 1..*number_write)
            .find(|&position| {
                matches!(body[position],
            Operator::ArraySet { array_type_index } if array_type_index == numbers)
            })
            .expect("growth writes the new Number payload privately");
        assert_eq!(reference_operand(body, number_value - 2), number_root);
        let prepare = (number_value + 1..*number_write)
            .find(|&position| {
                matches!(
                    &body[position..position + 4],
                    [
                        Operator::LocalGet { .. },
                        Operator::I32Const { value: 16 },
                        Operator::I32LeU,
                        Operator::If { .. }
                    ]
                )
            })
            .expect("the prepared complete word uses the actual new capacity");
        let Operator::LocalGet {
            local_index: new_capacity,
        } = body[prepare]
        else {
            unreachable!()
        };
        let length = local_producer(body, prepare, new_capacity);
        assert!(matches!(body[length], Operator::ArrayLen));
        assert_eq!(reference_operand(body, length), number_root);
        let plain = frame_else(body, prepare + 3).unwrap();
        let prepared_end = frame_end(body, prepare + 3);
        let [Operator::LocalGet { local_index: count }, Operator::LocalSet {
            local_index: prepared,
        }] = &body[plain + 1..prepared_end]
        else {
            panic!("large growth publishes a plain logical count")
        };
        let encode = &body[plain - 8..plain];
        assert!(
            matches!(encode,
            [Operator::LocalGet { .. }, Operator::I64Const { value: 32 }, Operator::I64Shl,
             Operator::LocalGet { local_index }, Operator::I64Or, Operator::I64Const { value: i64::MIN }, Operator::I64Or,
             Operator::LocalSet { local_index: output }] if local_index == count && output == prepared),
            "small growth prepares one complete flag/mask/count word"
        );
        assert!(
            body[prepare + 4..plain - 8].windows(11).any(|ops| matches!(
                ops,
                [
                    Operator::LocalGet { .. },
                    Operator::I64Const { value: 32 },
                    Operator::I64ShrU,
                    Operator::I64Const { value: 65535 },
                    Operator::I64And,
                    Operator::I64Const { value: 1 },
                    Operator::LocalGet { .. },
                    Operator::I64ExtendI32U,
                    Operator::I64Shl,
                    Operator::I64Or,
                    Operator::LocalSet { .. }
                ]
            )),
            "small growth preserves old holes and includes the inserted bit before publication"
        );
        let Operator::LocalGet { local_index: raw } = body[prepare + 4] else {
            panic!("small growth preserves the cached mask")
        };
        let source = local_producer(body, prepare, raw);
        assert!(
            matches!(body[source], Operator::StructGet { struct_type_index, field_index }
            if struct_type_index == array && field_index == Field::ArrayCount.index())
        );
        assert_eq!(reference_operand(body, source), field_owner(body, *commit));
        let delta = local_producer(body, prepare, *count);
        assert!(matches!(
            &body[delta - 2..=delta],
            [
                Operator::LocalGet { .. },
                Operator::I64Const { value: 1 },
                Operator::I64Add
            ]
        ));
        assert!(
            body[number_value + 1..delta].windows(4).any(|ops| matches!(
                ops,
                [
                    Operator::LocalGet { local_index },
                    Operator::I32WrapI64,
                    Operator::I64ExtendI32U,
                    Operator::LocalSet { .. }
                ] if *local_index == raw
            )),
            "growth increments the same owner's decoded occupied count exactly once"
        );
        assert!(
            matches!(body[*commit - 1], Operator::LocalGet { local_index } if local_index == *prepared)
        );
        assert_eq!(
            field_owner(body, *number_write),
            field_owner(body, *presence_write)
        );
        assert_eq!(field_owner(body, *number_write), field_owner(body, *commit));
        assert!(
            primitive_only(&body[number_value + 1..=*commit]),
            "preparation and paired-root/word publication contain no safepoint or callback"
        );
        assert!(
            !body[number_new + 1..*number_write]
                .iter()
                .any(|op| matches!(op,
            Operator::StructSet { struct_type_index, field_index }
                if *struct_type_index == array && *field_index == Field::ArrayCount.index())),
            "growth cannot publish a stale intermediate occupancy word"
        );
        checked += 1;
    }
    checked
}

#[test]
fn real_push_and_join_builtins_reach_guarded_canonical_packed_kernels() {
    std::thread::Builder::new()
        .stack_size(64 * 1024 * 1024)
        .spawn(|| {
            let lowered = lower(
                &parse(
                    "[Array.prototype.push, Array.prototype.join];",
                    ParseOptions::script(),
                )
                .unwrap(),
            );
            let artifact = emit_with_rooted_snapshot(
                &lowered,
                PromiseRejectionPolicy::Ignore,
                &scriptw_intl::IntlCompilationProfile::Minimal,
            )
            .unwrap();
            let runtime = artifact.runtime().unwrap();
            for bytes in [&artifact.bytes[..], runtime.bytes()] {
                Validator::new_with_features(WasmFeatures::all())
                    .validate_all(bytes)
                    .expect("actual packed builtin modules validate");
            }
            let runtime = Module::read(runtime.bytes());
            let array = runtime.witness_type(GcSnapshotLayout::Array);
            let storage = runtime.witness_type(GcSnapshotLayout::Array);
            let values = runtime.witness_type(GcSnapshotLayout::ArrayValues);
            let units = runtime.witness_type(GcSnapshotLayout::CodeUnits);
            let (publish, _) = runtime.named("helper::array_indexed_publish_default_data");
            let (own_descriptor, _) = runtime.named("helper::ordinary_own_descriptor");
            let (ordinary_set, _) = runtime.named("helper::ordinary_set");
            let (object_write, object_write_body) = runtime.named("helper::object_write");
            let (_, push) = runtime.named("builtin::Array.prototype.push");
            let publication = push
                .iter()
                .position(|op| matches!(op, Operator::Call { function_index } if *function_index == publish))
                .expect("the actual push builtin reaches the sole canonical growth/publication helper");
            for (owner, field) in [
                (array, scriptw_aot_wasm::GcSnapshotField::ArrayLengthWritable),
                (storage, scriptw_aot_wasm::GcSnapshotField::ArrayCount),
            ] {
                assert!(push[..publication].iter().any(|op| matches!(op,
                    Operator::StructGet { struct_type_index, field_index }
                        if *struct_type_index == owner && *field_index == field.index())),
                    "push checks {field:?} before any canonical publication");
            }
            assert!(calls(&push[..publication], own_descriptor),
                "live ordinary prototype descriptors are checked before publication");
            // emit_object_write_strict enters ObjectWrite with its strict flag;
            // ObjectWrite owns rejection around the canonical [[Set]] result.
            // Follow both real encoded edges instead of assuming push calls
            // the lower OrdinarySet owner directly.
            assert_eq!(push[publication..].iter().filter(|op| matches!(op,
                Operator::Call { function_index } | Operator::ReturnCall { function_index }
                    if *function_index == object_write)).count(), 2,
                "declined push retains indexed Set and the final length Set, including zero arguments");
            assert!(calls(object_write_body, ordinary_set),
                "the rejection owner reaches the canonical ordinary Set dispatcher");
            assert!(push[publication..].iter().any(|op| matches!(op,
                Operator::StructSet { struct_type_index, field_index }
                    if *struct_type_index == array && *field_index == scriptw_aot_wasm::GcSnapshotField::ArrayLength.index())),
                "successful packed append publishes the canonical receiver length");
            let (_, join) = runtime.named("builtin::Array.prototype.join");
            let (packed_join, kernel) = runtime.named("helper::array_packed_join");
            assert!(calls(join, packed_join),
                "actual builtin join calls the sole shared String-producing kernel");
            let first_value_read = kernel.iter().position(|op| matches!(op,
                Operator::ArrayGet { array_type_index } if *array_type_index == values))
                .expect("shared join kernel validates packed immutable value slots");
            let exact_allocation = kernel.iter().position(|op| matches!(op,
                Operator::ArrayNew { array_type_index } if *array_type_index == units))
                .expect("shared join kernel allocates a result backing");
            assert!(first_value_read < exact_allocation,
                "packed value validation precedes the first result allocation");
            assert!(kernel[exact_allocation..].iter().any(|op| matches!(op,
                Operator::ArrayGet { array_type_index } if *array_type_index == values)),
                "the exact-size result consumes the validated packed backing");
            assert!(kernel[exact_allocation..].iter().any(|op| matches!(op,
                Operator::ArrayCopy { array_type_index_dst, array_type_index_src }
                    if *array_type_index_dst == units && *array_type_index_src == units)),
                "join copies exact UTF16 units through the private String construction owner");
        })
        .unwrap()
        .join()
        .unwrap();
}

#[test]
fn source_join_calls_reach_shared_kernel_only_after_actual_code_realm_and_array_guards() {
    std::thread::Builder::new()
        .stack_size(64 * 1024 * 1024)
        .spawn(|| {
            let lowered = lower(&parse(
                "function joinOne(){var a=['x',null,'y'];var text=a.join(':');return text;} \
                 function joinZero(){var a=['x'];var text=a.join();return text;} \
                 function joinExtra(){var a=['x'];var text=a.join(':',undefined);return text;} \
                 [joinOne,joinZero,joinExtra];",
                ParseOptions::script(),
            ).unwrap());
            let artifact = emit_with_rooted_snapshot(&lowered, PromiseRejectionPolicy::Ignore,
                &scriptw_intl::IntlCompilationProfile::Minimal).unwrap();
            let runtime_bytes = artifact.runtime().unwrap().bytes();
            for bytes in [&artifact.bytes[..], runtime_bytes] {
                Validator::new_with_features(WasmFeatures::all()).validate_all(bytes).unwrap();
            }
            let runtime = Module::read(runtime_bytes);
            let program = Module::read(&artifact.bytes);
            let (kernel, _) = runtime.named("helper::array_packed_join");
            let kernel = program.imported_runtime(&runtime, kernel);
            let (call, _) = runtime.named("helper::proxy_call");
            let call = program.imported_runtime(&runtime, call);
            let array = runtime.witness_type(GcSnapshotLayout::Array);
            let code = runtime.witness_type(GcSnapshotLayout::Code);
            let context = runtime.witness_type(GcSnapshotLayout::Context);
            for name in ["js::joinOne#", "js::joinZero#"] {
                let (_, body) = program.named(name);
                let direct = body.iter().position(|op| matches!(op,
                    Operator::Call { function_index } if *function_index == kernel))
                    .expect("ordinary source join reaches the shared packed kernel");
                assert!(body[..direct].iter().any(|op| matches!(op,
                    Operator::RefTestNonNull { hty: HeapType::Concrete(UnpackedIndex::Module(index)) }
                        if *index == array)), "actual concrete Array guard precedes kernel call");
                assert!(body[..direct].iter().filter(|op| matches!(op,
                    Operator::StructGet { struct_type_index, .. } if *struct_type_index == code)).count() >= 2,
                    "actual immutable code kind and native builtin identity precede kernel call");
                assert!(body[..direct].iter().any(|op| matches!(op,
                    Operator::StructGet { struct_type_index, field_index }
                        if *struct_type_index == context && *field_index == scriptw_aot_wasm::GcSnapshotField::ContextRealm.index())),
                    "actual defining Realm is read before the direct kernel route");
                assert!(body[..direct].iter().any(|op| matches!(op, Operator::RefEq)),
                    "actual defining Realm identity is compared before the direct route");
                assert!(calls(&body[direct..], call),
                    "unhandled kernel/identity checks retain the saved-operand ordinary call");
            }
            let (_, extra) = program.named("js::joinExtra#");
            assert!(!calls(extra, kernel), "extra arguments decline before direct-call argument evaluation");
            assert!(calls(extra, call), "extra arguments retain ordinary invocation");
        }).unwrap().join().unwrap();
}

#[test]
fn source_packed_join_resolves_the_default_comma_only_in_the_undefined_separator_arm() {
    std::thread::Builder::new()
        .stack_size(64 * 1024 * 1024)
        .spawn(|| {
            let lowered = lower(&parse(
                "function joinChoice(separator){var a=['left','right'];var text=a.join(separator);return text;} [joinChoice];",
                ParseOptions::script(),
            ).unwrap());
            let artifact = emit_with_rooted_snapshot(
                &lowered, PromiseRejectionPolicy::Ignore,
                &scriptw_intl::IntlCompilationProfile::Minimal,
            ).unwrap();
            let runtime_bytes = artifact.runtime().unwrap().bytes();
            for bytes in [&artifact.bytes[..], runtime_bytes] {
                Validator::new_with_features(WasmFeatures::all()).validate_all(bytes).unwrap();
            }
            let runtime = Module::read(runtime_bytes);
            let program = Module::read(&artifact.bytes);
            let (resolver, _) = runtime.named("helper::pooled_string_resolve");
            let resolver = program.imported_runtime(&runtime, resolver);
            let (kernel, _) = runtime.named("helper::array_packed_join");
            let kernel = program.imported_runtime(&runtime, kernel);
            let string = runtime.witness_type(GcSnapshotLayout::String);
            let (_, body) = program.named("js::joinChoice#");
            let direct = body.iter().position(|op| matches!(op,
                Operator::Call { function_index } if *function_index == kernel))
                .expect("the dynamic separator candidate reaches the shared join kernel");
            let mut selected = Vec::new();
            for (start, ops) in body[..direct].windows(4).enumerate() {
                let [Operator::LocalGet { local_index: tag }, Operator::I32Const { value },
                     Operator::I32Eq, Operator::If { .. }] = ops else { continue; };
                if *value != scriptw_aot_wasm::WasmRuntimeValueTag::Undefined.tag() { continue; }
                let mut depth = 1;
                let mut otherwise = None;
                let mut end = None;
                for (offset, op) in body[start + 4..direct].iter().enumerate() {
                    let index = start + 4 + offset;
                    match op {
                        Operator::If { .. } | Operator::Block { .. } | Operator::Loop { .. }
                            | Operator::TryTable { .. } | Operator::Try { .. } => depth += 1,
                        Operator::Else if depth == 1 => otherwise = Some(index),
                        Operator::End => {
                            depth -= 1;
                            if depth == 0 { end = Some(index); break; }
                        }
                        _ => {},
                    }
                }
                let (Some(otherwise), Some(end)) = (otherwise, end) else { continue; };
                let undefined_arm = &body[start + 4..otherwise];
                let string_arm = &body[otherwise + 1..end];
                if !calls(undefined_arm, resolver) || !string_arm.iter().any(|op| matches!(op,
                    Operator::RefCastNonNull { hty: HeapType::Concrete(UnpackedIndex::Module(index)) }
                        if *index == string)) { continue; }
                selected.push((*tag, start, otherwise, end));
            }
            assert_eq!(selected.len(), 1, "the actual Undefined guard owns one comma/string selection");
            let (separator_tag, start, otherwise, end) = selected[0];
            assert!(body[..start].windows(3).any(|ops| matches!(ops,
                [Operator::LocalGet { local_index }, Operator::I32Const { value }, Operator::I32Eq]
                    if *local_index == separator_tag && *value == scriptw_aot_wasm::WasmRuntimeValueTag::String.tag())),
                "the direct route first admits the same saved separator as String or Undefined");
            let undefined_arm = &body[start + 4..otherwise];
            let string_arm = &body[otherwise + 1..end];
            assert_eq!(undefined_arm.iter().filter(|op| matches!(op,
                Operator::Call { function_index } if *function_index == resolver)).count(), 1,
                "only the Undefined arm resolves the canonical comma");
            assert!(!string_arm.iter().any(|op| matches!(op,
                Operator::Call { .. } | Operator::ReturnCall { .. } | Operator::CallRef { .. }
                    | Operator::CallIndirect { .. })), "an explicit String reuses its root without any resolver/call");
            let (Some(Operator::LocalSet { local_index: default_root }),
                 Some(Operator::LocalSet { local_index: explicit_root })) =
                (undefined_arm.last(), string_arm.last()) else {
                    panic!("both selection arms publish their completed String root");
                };
            assert_eq!(default_root, explicit_root, "both arms initialize the same rooted separator local");
            assert!(matches!(&body[direct - 2..direct],
                [Operator::LocalGet { local_index }, Operator::RefAsNonNull]
                    if local_index == default_root),
                "the guarded kernel receives that exact completed String root after selection");
        }).unwrap().join().unwrap();
}

#[test]
fn real_array_sort_snapshots_packed_values_and_revalidates_after_all_comparisons() {
    std::thread::Builder::new()
        .stack_size(64 * 1024 * 1024)
        .spawn(|| {
            let lowered = lower(
                &parse(
                    "function compare(a,b){return a-b;} var arrow=(a,b)=>a-b; \
                 [Array.prototype.sort,Array.prototype.toSorted,compare,arrow];",
                    ParseOptions::script(),
                )
                .unwrap(),
            );
            let artifact = emit_with_rooted_snapshot(
                &lowered,
                PromiseRejectionPolicy::Ignore,
                &scriptw_intl::IntlCompilationProfile::Minimal,
            )
            .unwrap();
            let runtime_bytes = artifact.runtime().unwrap().bytes();
            for bytes in [&artifact.bytes[..], runtime_bytes] {
                Validator::new_with_features(WasmFeatures::all())
                    .validate_all(bytes)
                    .unwrap();
            }
            let runtime = Module::read(runtime_bytes);
            let signatures = runtime
                .types
                .iter()
                .enumerate()
                .filter_map(|(index, ty)| {
                    let wasmparser::CompositeInnerType::Func(signature) = &ty.composite_type.inner
                    else {
                        return None;
                    };
                    (signature.params() == [ValType::F64, ValType::F64]
                        && signature.results() == [ValType::I32, ValType::F64])
                    .then_some(index as u32)
                })
                .collect::<Vec<_>>();
            assert_eq!(
                signatures.len(),
                1,
                "one non-Completion binary numeric callback signature"
            );
            let binary = signatures[0];
            let code = runtime.witness_type(GcSnapshotLayout::Code);
            let wasmparser::CompositeInnerType::Struct(fields) =
                &runtime.types[code as usize].composite_type.inner
            else {
                panic!("actual ExecutableCode is a struct");
            };
            let callback_fields = fields
                .fields
                .iter()
                .enumerate()
                .filter_map(|(index, field)| {
                    let wasmparser::StorageType::Val(ValType::Ref(reference)) = field.element_type
                    else {
                        return None;
                    };
                    (reference.heap_type() == HeapType::Concrete(UnpackedIndex::Module(binary)))
                        .then_some((index as u32, reference.is_nullable(), field.mutable))
                })
                .collect::<Vec<_>>();
            assert_eq!(
                callback_fields.len(),
                1,
                "ExecutableCode owns one optional binary entry"
            );
            let (callback_field, nullable, mutable) = callback_fields[0];
            assert!(
                nullable && !mutable,
                "the typed entry is optional and immutable"
            );
            let array = runtime.witness_type(GcSnapshotLayout::Array);
            let storage = runtime.witness_type(GcSnapshotLayout::Array);
            let object = runtime.witness_type(GcSnapshotLayout::Object);
            let values = runtime.witness_type(GcSnapshotLayout::ArrayValues);
            let numbers = runtime.witness_type(GcSnapshotLayout::ArrayNumbers);
            let (publish, _) = runtime.named("helper::array_indexed_publish_default_data");
            let (ordinary_set, _) = runtime.named("helper::ordinary_set");
            let (delete, _) = runtime.named("helper::object_delete");
            let callback_helpers = [
                "helper::proxy_call",
                "helper::value_to_number",
                "helper::value_to_string",
            ]
            .map(|name| runtime.named(name).0);
            for name in [
                "builtin::Array.prototype.sort",
                "builtin::Array.prototype.toSorted",
            ] {
                let (_, body) = runtime.named(name);
                let bitmap = runtime.witness_type(GcSnapshotLayout::ArrayNumberPresence);
                let roles = array_count_read_roles(body, array, bitmap,
                    runtime.empty_array_global(numbers), runtime.empty_array_global(bitmap));
                let logical_guards = if name == "builtin::Array.prototype.sort" { 4 } else { 2 };
                assert_eq!(roles.0, logical_guards,
                    "snapshot/writeback guards decode logical count; every raw source has a validated presence or retirement consumer: {roles:?}");
                eprintln!("{name} COUNT read roles (logical, presence, strip): {roles:?}");
                let typed_call = |op: &Operator<'_>| {
                    matches!(op,
                    Operator::CallRef { type_index } if *type_index == binary)
                };
                let first_comparison = body
                    .iter()
                    .position(typed_call)
                    .expect("real Array builtin invokes the optional typed callback");
                assert!(
                    body[..first_comparison].iter().any(|op| matches!(op,
                    Operator::StructGet { struct_type_index, field_index }
                        if *struct_type_index == code && *field_index == callback_field)),
                    "the typed call uses the actual callable's immutable optional entry"
                );
                let last_comparison = body
                    .iter()
                    .rposition(|op| {
                        typed_call(op)
                            || matches!(op,
                    Operator::Call { function_index } | Operator::ReturnCall { function_index }
                        if callback_helpers.contains(function_index))
                    })
                    .unwrap();
                for backing in [values, numbers] {
                    assert!(
                        body[..last_comparison].iter().any(|op| matches!(op,
                        Operator::ArrayGet { array_type_index } if *array_type_index == backing)),
                        "the generic private-snapshot path retains each packed source representation"
                    );
                }
                assert!(body[..first_comparison].iter().any(|op| matches!(op,
                    Operator::ArrayCopy { array_type_index_dst, array_type_index_src }
                        if *array_type_index_dst == numbers && *array_type_index_src == numbers)),
                    "the earlier pure numeric branch copies its unboxed snapshot before comparison");
                let publication = body
                    .iter()
                    .rposition(|op| {
                        matches!(op,
                    Operator::Call { function_index } if *function_index == publish)
                    })
                    .expect("sorted output uses the sole canonical indexed publisher");
                assert!(
                    last_comparison < publication,
                    "all callback/coercion branches precede output writes"
                );
                if name.ends_with(".sort") {
                    let proof = &body[last_comparison + 1..publication];
                    for (owner, field) in [
                        (array, scriptw_aot_wasm::GcSnapshotField::ArrayLength),
                        (storage, scriptw_aot_wasm::GcSnapshotField::ArrayCount),
                    ] {
                        assert!(
                            proof.iter().any(|op| matches!(op,
                            Operator::StructGet { struct_type_index, field_index }
                                if *struct_type_index == owner && *field_index == field.index())),
                            "writeback reacquires {field:?} after every comparison"
                        );
                    }
                    for (owner, field) in [
                        (
                            array,
                            scriptw_aot_wasm::GcSnapshotField::ArrayLengthWritable,
                        ),
                        (object, scriptw_aot_wasm::GcSnapshotField::ObjectExtensible),
                    ] {
                        assert!(
                            !proof.iter().any(|op| matches!(op,
                            Operator::StructGet { struct_type_index, field_index }
                                if *struct_type_index == owner && *field_index == field.index())),
                            "replacing own writable data does not require {field:?}"
                        );
                    }
                    assert!(
                        calls(&body[publication..], ordinary_set),
                        "declined proof retains ordered Set from index zero"
                    );
                    assert!(
                        calls(&body[publication..], delete),
                        "sparse sort retains trailing deletion"
                    );
                } else {
                    assert!(
                        !calls(&body[publication..], ordinary_set),
                        "fresh toSorted output needs no ordinary Set"
                    );
                }
                assert!(
                    calls(body, callback_helpers[0]),
                    "unsupported callback/operands retain fresh ordinary invocation"
                );
            }
        })
        .unwrap()
        .join()
        .unwrap();
}

#[test]
fn numeric_sort_keeps_bits_unboxed_and_admits_the_actual_callback_once() {
    std::thread::Builder::new().stack_size(64 * 1024 * 1024).spawn(|| {
        let lowered = lower(&parse(
            "function compare(a,b){return a-b;} [Array.prototype.sort,compare];",
            ParseOptions::script(),
        ).unwrap());
        let artifact = emit_with_rooted_snapshot(&lowered, PromiseRejectionPolicy::Ignore,
            &scriptw_intl::IntlCompilationProfile::Minimal).unwrap();
        for bytes in [&artifact.bytes[..], artifact.runtime().unwrap().bytes()] {
            Validator::new_with_features(WasmFeatures::all()).validate_all(bytes).unwrap();
        }
        let runtime = Module::read(artifact.runtime().unwrap().bytes());
        let numbers = runtime.witness_type(GcSnapshotLayout::ArrayNumbers);
        let stored = runtime.witness_type(GcSnapshotLayout::Stored);
        let code = runtime.witness_type(GcSnapshotLayout::Code);
        let (_, body) = runtime.named("builtin::Array.prototype.sort");
        let copies = body.iter().enumerate().filter_map(|(i,op)| matches!(op,
            Operator::ArrayCopy { array_type_index_dst, array_type_index_src }
                if *array_type_index_dst == numbers && *array_type_index_src == numbers).then_some(i)).collect::<Vec<_>>();
        assert_eq!(copies.len(), 2, "one private Number snapshot and one guarded live writeback");
        let binary = runtime.types.iter().enumerate().find_map(|(i,t)| {
            let wasmparser::CompositeInnerType::Func(signature) = &t.composite_type.inner else {return None;};
            (signature.params() == [ValType::F64,ValType::F64] && signature.results() == [ValType::I32,ValType::F64]).then_some(i as u32)
        }).unwrap();
        let typed = body.iter().enumerate().filter_map(|(i,op)| matches!(op,
            Operator::CallRef { type_index } if *type_index == binary).then_some(i)).filter(|i| copies[0] < *i && *i < copies[1]).collect::<Vec<_>>();
        assert_eq!(typed.len(), 2, "the numeric scan and merge use the admitted typed entry");
        assert!(!body[copies[0]+1..typed[0]].iter().any(|op| matches!(op,
            Operator::StructNew { struct_type_index } if *struct_type_index == stored)),
            "collecting and loading Numbers requires no per-element value boxes");
        assert!(!body[copies[0]+1..copies[1]].iter().any(|op| matches!(op,
            Operator::StructGet { struct_type_index, .. } if *struct_type_index == code)),
            "the private kernel never re-reads callable code metadata");
        let mut frames = Vec::<(usize,bool)>::new();
        for (i,op) in body.iter().enumerate() {
            match op {
                Operator::Block {..} | Operator::Loop {..} | Operator::If {..} | Operator::TryTable {..} => frames.push((i,false)),
                Operator::Else => frames.last_mut().unwrap().1 = true,
                Operator::End => {frames.pop();},
                Operator::StructNew { struct_type_index } if *struct_type_index == stored && copies[0] < i && i < copies[1] => {
                    assert!(frames.iter().any(|&(at,otherwise)| otherwise && at >= 4 &&
                        matches!(&body[at-4],Operator::CallRef { type_index } if *type_index == binary) &&
                        matches!((&body[at-2],&body[at-1]),(Operator::LocalSet {local_index:a},Operator::LocalGet {local_index:b}) if a==b)),
                        "only scalar-thunk refusal may allocate ordinary callback arguments");
                }
                _ => {}
            }
        }
    }).unwrap().join().unwrap();
}

#[test]
fn compiled_numbers_use_bitmap_arrays_and_keep_real_descriptor_fallback() {
    std::thread::Builder::new().stack_size(64 * 1024 * 1024).spawn(|| {
        // Publish callable values without directly calling them. This retains
        // their generic bodies and avoids direct-call-specialized clones; the
        // operand assertions must describe that one declared generic body.
        let parsed = parse("function make(value){var a=[value];return a;}function read(array,index){return array[index];}[make,read];", ParseOptions::script()).unwrap();
        let lowered = lower(&parsed);
        let read_sources = lowered.script.as_ref().unwrap().functions.iter()
            .filter(|function| function.name == "read").collect::<Vec<_>>();
        assert_eq!(read_sources.len(), 1, "fixture retains one generic read IR carrier");
        let read_result = read_sources[0].body.statements.iter().find_map(|statement| match statement {
            StatementIr::Return(value) => Some(value),
            _ => None,
        }).expect("read source has its actual return expression");
        let ExprIr::SpecOperation { operation: SpecOperationIr::GetV, operands } = &read_result.expr else {
            panic!("unknown receiver/computed key must retain canonical GetV, got {read_result:?}");
        };
        assert_eq!(operands.len(), 2, "GetV retains target and key operands");
        assert!(!matches!(&operands[1].expr, ExprIr::String(_)),
            "this nonliteral key reaches ObjectRead after GetV's operand/ToObject/ToPropertyKey steps");
        let artifact = emit_with_rooted_snapshot(&lowered, PromiseRejectionPolicy::Ignore,
            &scriptw_intl::IntlCompilationProfile::Minimal).unwrap();
        // Preserve the same generic signature, locals, argument read and
        // callable publication protocol. Its empty literal owns any ordinary
        // activation descriptors independently of element publication.
        let control = lower(&parse("function make(value){var a=[];value;return a;}function read(array,index){return array[index];}[make,read];", ParseOptions::script()).unwrap());
        let control_artifact = emit_with_rooted_snapshot(&control, PromiseRejectionPolicy::Ignore,
            &scriptw_intl::IntlCompilationProfile::Minimal).unwrap();
        let runtime = artifact.runtime().unwrap();
        let features = WasmFeatures::default() | WasmFeatures::THREADS | WasmFeatures::MULTI_MEMORY
            | WasmFeatures::REFERENCE_TYPES | WasmFeatures::FUNCTION_REFERENCES | WasmFeatures::GC
            | WasmFeatures::EXCEPTIONS | WasmFeatures::TAIL_CALL;
        for bytes in [&artifact.bytes[..], &runtime.bytes()[..], &control_artifact.bytes[..]] {
            Validator::new_with_features(features).validate_all(bytes).unwrap();
        }
        let program = Module::read(&artifact.bytes);
        let control_program = Module::read(&control_artifact.bytes);
        let runtime = Module::read(runtime.bytes());
        // Linked R owns snapshot globals, and the Engine observes that R
        // instance. P imports R's core and appends program-only signatures.
        // Verify the actual encoded index/type/recursion-group agreement before
        // using R's witness indices to classify any instruction in P.
        assert!(program.types.len() >= runtime.types.len());
        assert_eq!(&program.types[..runtime.types.len()], &runtime.types,
            "P and R declare the exact same core types at the same indices");
        assert!(control_program.types.len() >= runtime.types.len());
        assert_eq!(&control_program.types[..runtime.types.len()], &runtime.types,
            "the matched control uses the same concrete descriptor index");
        assert!(program.type_group_sizes.len() >= runtime.type_group_sizes.len());
        assert_eq!(&program.type_group_sizes[..runtime.type_group_sizes.len()], &runtime.type_group_sizes,
            "P's program-only type suffix must not alter shared recursive groups");
        let numbers = runtime.witness_type(GcSnapshotLayout::ArrayNumbers);
        let presence = runtime.witness_type(GcSnapshotLayout::ArrayNumberPresence);
        let array = runtime.witness_type(GcSnapshotLayout::Array);
        let wasmparser::CompositeInnerType::Struct(fields) = &runtime.types[array as usize].composite_type.inner else { panic!("the actual Array witness names a struct") };
        assert_eq!(scriptw_aot_wasm::GcSnapshotField::ArrayCount.index(), 3);
        assert_eq!(scriptw_aot_wasm::GcSnapshotField::ArrayNumberPresent.index(), 8);
        assert_eq!(fields.fields[3].element_type, wasmparser::StorageType::Val(ValType::I64));
        assert!(matches!(fields.fields[8].element_type, wasmparser::StorageType::Val(ValType::Ref(reference))
            if !reference.is_nullable() && reference.heap_type() == HeapType::Concrete(UnpackedIndex::Module(presence))),
            "packed scalar metadata retains the original concrete nonnull bitmap field");
        let values = runtime.witness_type(GcSnapshotLayout::ArrayValues);
        let stored = runtime.witness_type(GcSnapshotLayout::Stored);
        let descriptor = runtime.witness_type(GcSnapshotLayout::Descriptor);
        let dense = runtime.witness_type(GcSnapshotLayout::ArrayDense);
        assert_ne!(numbers, presence, "Number payload and hole presence are distinct arrays");
        let (_, make) = program.named("js::make#");
        let (_, control_make) = control_program.named("js::make#");
        let (default_publish, default_publish_body) = runtime.named("helper::array_indexed_publish_default_data");
        assert!(calls(make, program.imported_runtime(&runtime, default_publish)),
            "the fresh producer calls the actual linked R default-data publication owner");
        assert!(!calls(control_make, control_program.imported_runtime(&runtime, default_publish)),
            "the empty-array control has no element publication");
        for array in [numbers, presence] {
            assert!(default_publish_body.iter().any(|op| matches!(op, Operator::ArraySet { array_type_index } if *array_type_index == array)), "shared R publication writes its physical packed backing");
            assert!(!make.iter().any(|op| matches!(op, Operator::ArraySet { array_type_index } if *array_type_index == array)), "P never duplicates the shared packed publication CFG");
        }
        assert!(default_publish_body.iter().any(|op| matches!(op, Operator::ArrayNew { array_type_index } if *array_type_index == values)), "the shared owner grows a nullable immutable-value table for general ordinary data");
        assert!(default_publish_body.iter().any(|op| matches!(op, Operator::ArraySet { array_type_index } if *array_type_index == values)), "general data publication writes the actual typed slot table");
        assert!(default_publish_body.iter().any(|op| matches!(op, Operator::StructNew { struct_type_index } if *struct_type_index == stored)), "numeric promotion and incoming general values publish real immutable StoredValues");
        assert!(complete_numeric_growth(default_publish_body, array, numbers, presence) > 0,
            "the canonical publisher completes small/heap growth before paired roots and count publication");
        assert!(scalar_bit_publications(default_publish_body, array, presence, numbers, true) > 0,
            "shared numeric insertion/overwrite combines count and small mask in one store");
        assert!(metadata_strip_sources(default_publish_body, array, runtime.empty_array_global(numbers), runtime.empty_array_global(presence)).len() > 0,
            "Number-to-Values promotion preserves occupied count while retiring scalar metadata");
        let (publish, publish_body) = runtime.named("helper::array_indexed_publish");
        assert!(metadata_strip_sources(publish_body, array, runtime.empty_array_global(numbers), runtime.empty_array_global(presence)).len() > 0,
            "descriptor promotion preserves occupied count while retiring scalar metadata");
        assert!(calls(default_publish_body, publish), "ineligible default-data values retain R's actual descriptor publication fallback");
        assert!(default_publish_body.iter().any(|op| matches!(op, Operator::StructNew { struct_type_index } if *struct_type_index == descriptor)), "the shared default-data owner boxes the incoming descriptor before its raw publication fallback");
        let descriptor_count = |body: &[Operator<'_>]| body.iter().filter(|op|
            matches!(op, Operator::StructNew { struct_type_index } if *struct_type_index == descriptor)).count();
        assert_eq!(descriptor_count(make), descriptor_count(control_make),
            "element publication adds no P descriptor allocation beyond the matched empty-array activation");
        assert!(publish_body.iter().any(|op| matches!(op, Operator::StructNew { struct_type_index } if *struct_type_index == descriptor)), "R's cold promotion constructs real descriptors for previously packed entries");
        assert!(publish_body.iter().any(|op| matches!(op, Operator::ArraySet { array_type_index } if *array_type_index == dense)), "cold descriptors enter the actual dense store");
        let (_, source_read) = program.named("js::read#");
        let (object_read, read) = runtime.named("helper::object_read");
        assert!(calls(source_read, program.imported_runtime(&runtime, object_read)),
            "the canonical nonliteral GetV source body calls the actual linked R ObjectRead definition");
        for array in [numbers, presence, values] {
            assert!(read.iter().any(|op| matches!(op, Operator::ArrayGet { array_type_index } if *array_type_index == array)), "ordinary read reaches encoded packed value/presence loads");
        }
        assert!(scalar_presence_decodes(read, array, presence) > 0,
            "ordinary reads branch between the encoded scalar mask and original heap bitmap");
        let (_, delete) = runtime.named("helper::array_indexed_delete");
        assert!(scalar_bit_publications(delete, array, presence, numbers, false) > 0,
            "present deletion publishes the decremented count and remaining mask together; last delete selects plain zero");
        assert!(metadata_strip_sources(delete, array, runtime.empty_array_global(numbers), runtime.empty_array_global(presence)).len() > 0,
            "common deletion retirement skips the second word commit once plain zero is published");
        assert!(delete.iter().any(|op| matches!(op, Operator::ArraySet { array_type_index } if *array_type_index == values)), "general deletion clears the actual nullable value edge");
        assert!(delete.iter().any(|op| matches!(op, Operator::ArraySet { array_type_index } if *array_type_index == presence)), "deletion clears explicit presence rather than inventing a Number sentinel");
    }).unwrap().join().unwrap();
}

#[test]
fn many_short_array_literals_keep_publication_cfg_in_one_runtime_body() {
    std::thread::Builder::new()
        .stack_size(64 * 1024 * 1024)
        .spawn(|| {
            const LITERALS: usize = 256;
            const ELEMENTS: usize = 3;
            // This fixed source stays below the current Engine's 1-MiB
            // large-body native-policy boundary. Unrelated lowering may
            // change exact operator counts without duplicating publication.
            const SOURCE_BODY_BYTE_CEILING: usize = 1024 * 1024;
            // Each literal is far below passive-recipe admission. One source
            // body must remain cheap even when it contains many such literals.
            let mut source = String::from("function make(consume){");
            for ordinal in 0..LITERALS {
                source.push_str(&format!(
                    "consume([{ordinal},{},{}]);",
                    ordinal + 1,
                    ordinal + 2
                ));
            }
            source.push_str("}make;");
            let lowered = lower(&parse(&source, ParseOptions::script()).unwrap());
            let artifact = emit_with_rooted_snapshot(
                &lowered,
                PromiseRejectionPolicy::Ignore,
                &scriptw_intl::IntlCompilationProfile::Minimal,
            )
            .unwrap();
            let program = Module::read(&artifact.bytes);
            let runtime = Module::read(artifact.runtime().unwrap().bytes());
            let (publish, publication) =
                runtime.named("helper::array_indexed_publish_default_data");
            let imported_publish = program.imported_runtime(&runtime, publish);
            let (make_index, make) = program.named("js::make#");
            assert!(program.types.len() >= runtime.types.len());
            assert_eq!(&program.types[..runtime.types.len()], &runtime.types,
                "backing witnesses retain their actual shared core indices");
            for array in [
                runtime.witness_type(GcSnapshotLayout::ArrayNumbers),
                runtime.witness_type(GcSnapshotLayout::ArrayNumberPresence),
            ] {
                assert!(!make.iter().any(|op| matches!(op,
                    Operator::ArraySet { array_type_index } if *array_type_index == array)),
                    "the many-literal P body has no duplicated packed backing publication");
            }
            let publications = make
                .iter()
                .filter(|operator| {
                    matches!(operator,
                        Operator::Call { function_index }
                        | Operator::ReturnCall { function_index }
                        if *function_index == imported_publish)
                })
                .count();
            assert_eq!(
                publications,
                LITERALS * ELEMENTS,
                "every occupied source element reaches the actual R publication owner"
            );
            assert!(
                publication
                    .iter()
                    .any(|op| matches!(op, Operator::Loop { .. })),
                "the one R publication body owns geometric growth rather than deleting it"
            );
            assert!(
                program.body_bytes[&make_index] < SOURCE_BODY_BYTE_CEILING,
                "the fixed many-short-literal control stays below the large-body native-policy boundary, got {} bytes",
                program.body_bytes[&make_index]
            );
        })
        .unwrap()
        .join()
        .unwrap();
}
#[test]
fn bounded_dynamic_literals_guard_one_complete_number_backing_and_retain_the_runtime_fallback() {
    std::thread::Builder::new()
        .stack_size(64 * 1024 * 1024)
        .spawn(|| {
            // Publishing the functions keeps their original generic argument
            // reads and prevents direct-call specialization from proving tags.
            let source = "function three(a,b,c){return[a,b,c];}\
                function four(a,b,c,d){return[a,b,c,d];}\
                function eight(x){return[x,x,x,x,x,x,x,x];}\
                function effects(next){return[next(),next(),next()];}\
                function hole(x){return[x,,x,x];}\
                function long(x){return[x,x,x,x,x,x,x,x,x];}\
                function empty(){return[];}[three,four,eight,effects,hole,long,empty];";
            let lowered = lower(&parse(source, ParseOptions::script()).unwrap());
            let artifact = emit_with_rooted_snapshot(
                &lowered,
                PromiseRejectionPolicy::Ignore,
                &scriptw_intl::IntlCompilationProfile::Minimal,
            )
            .unwrap();
            let features = WasmFeatures::default()
                | WasmFeatures::THREADS
                | WasmFeatures::MULTI_MEMORY
                | WasmFeatures::REFERENCE_TYPES
                | WasmFeatures::FUNCTION_REFERENCES
                | WasmFeatures::GC
                | WasmFeatures::EXCEPTIONS
                | WasmFeatures::TAIL_CALL;
            for bytes in [&artifact.bytes[..], artifact.runtime().unwrap().bytes()] {
                Validator::new_with_features(features)
                    .validate_all(bytes)
                    .unwrap();
            }
            let program = Module::read(&artifact.bytes);
            let runtime = Module::read(artifact.runtime().unwrap().bytes());
            assert_eq!(&program.types[..runtime.types.len()], &runtime.types);
            let numbers = runtime.witness_type(GcSnapshotLayout::ArrayNumbers);
            let presence = runtime.witness_type(GcSnapshotLayout::ArrayNumberPresence);
            let storage = runtime.witness_type(GcSnapshotLayout::Array);
            let (publish, _) = runtime.named("helper::array_indexed_publish_default_data");
            let publish = program.imported_runtime(&runtime, publish);
            for (name, length, capacity) in [("js::three#", 3, 4), ("js::four#", 4, 4), ("js::eight#", 8, 8), ("js::effects#", 3, 4)] {
                let (_, body) = program.named(name);
                let backing = body
                    .iter()
                    .position(|op| matches!(op, Operator::ArrayNewFixed { array_type_index, array_size }
                        if *array_type_index == numbers && *array_size == capacity))
                    .expect("one power-of-two Number backing in the original generic source body");
                let guard = body[..backing]
                    .iter()
                    .rposition(|op| matches!(op, Operator::If { .. }))
                    .expect("the Number backing is guarded");
                // One combined run-time test checks actual captured Value tags;
                // unknown parameters may subsequently be strings, BigInts or refs.
                let condition_ops = (length * 4 - 1) as usize;
                let condition = &body[guard - condition_ops..guard];
                assert_eq!(condition.iter().filter(|op| matches!(op,
                    Operator::I32Const { value } if *value == scriptw_ir::ValueKind::Number.tag() as i32)).count(), length as usize);
                assert_eq!(condition.iter().filter(|op| matches!(op, Operator::I32Eq)).count(), length as usize);
                assert_eq!(condition.iter().filter(|op| matches!(op, Operator::I32And)).count(), length as usize - 1);
                let creation = body[..guard].iter().position(|op| matches!(op,
                    Operator::StructNew { struct_type_index } if *struct_type_index == storage)).expect("ArrayCreate precedes element evaluation and representation admission");
                let canonical = local_producer(body, creation, reference_operand(body, creation - 1));
                let Operator::GlobalGet { global_index } = body[canonical] else { panic!("the fresh constructor borrows its canonical nominal bitmap") };
                assert!(matches!(program.globals[global_index as usize].content_type, ValType::Ref(reference)
                    if !reference.is_nullable() && reference.heap_type() == HeapType::Concrete(UnpackedIndex::Module(presence))));
                assert!(!program.globals[global_index as usize].mutable);
                if name == "js::effects#" {
                    let dispatch = program.imported_runtime(&runtime, runtime.named("helper::proxy_call").0);
                    let callbacks = body.iter().enumerate().filter_map(|(position, op)| matches!(op,
                        Operator::Call { function_index } if *function_index == dispatch).then_some(position)).collect::<Vec<_>>();
                    assert_eq!(callbacks.len(), 3, "each source element retains one generic callback dispatch fallback");
                    assert!(callbacks.iter().all(|&position| creation < position && position < guard),
                        "ArrayCreate precedes all element effects; the all-Number choice follows their captured results");
                    let realm = runtime.witness_type(GcSnapshotLayout::Realm);
                    assert!(body[..creation].iter().any(|op| matches!(op,
                        Operator::StructGet { struct_type_index, field_index }
                            if *struct_type_index == realm && *field_index == scriptw_aot_wasm::GcSnapshotField::RealmIntrinsics.index())),
                        "the source Realm supplies the Array prototype before element callbacks");
                }
                let alternative = frame_else(body, guard).expect("non-Numbers retain their ordinary fallback");
                let complete = frame_end(body, guard);
                assert!(!body[guard + 1..alternative].iter().any(|op| matches!(op,
                    Operator::ArrayNew { array_type_index } | Operator::ArrayNewDefault { array_type_index }
                    | Operator::ArrayNewFixed { array_type_index, .. } if *array_type_index == presence)),
                    "the small all-Number arm borrows the nominal empty bitmap instead of allocating one");
                assert!(!body[guard + 1..alternative].iter().any(|op| matches!(op, Operator::RefI31)),
                    "small presence remains scalar metadata, not a GC type union");
                for field in [
                    scriptw_aot_wasm::GcSnapshotField::ArrayNumbers,
                    scriptw_aot_wasm::GcSnapshotField::ArrayCount,
                ] {
                    assert!(body[backing..].iter().any(|op| matches!(op,
                        Operator::StructSet { struct_type_index, field_index }
                            if *struct_type_index == storage && *field_index == field.index())),
                        "complete Number backing publication writes {field:?}");
                }
                let words = (backing + 1..alternative).filter(|&position| matches!(body[position],
                    Operator::StructSet { struct_type_index, field_index }
                        if struct_type_index == storage && field_index == scriptw_aot_wasm::GcSnapshotField::ArrayCount.index())).collect::<Vec<_>>();
                assert_eq!(words.len(), 1, "the literal publishes count and complete small mask in one store");
                let expected = (1_u64 << 63) | (((1_u64 << length) - 1) << 32) | length as u64;
                assert_eq!(word_constant(body, words[0]) as u64, expected);
                let number_write = (backing + 1..words[0]).find(|&position| matches!(body[position],
                    Operator::StructSet { struct_type_index, field_index }
                        if struct_type_index == storage && field_index == scriptw_aot_wasm::GcSnapshotField::ArrayNumbers.index())).unwrap();
                assert!(!body[guard + 1..alternative].iter().any(|op| matches!(op,
                    Operator::StructSet { struct_type_index, field_index }
                        if *struct_type_index == storage && *field_index == scriptw_aot_wasm::GcSnapshotField::ArrayNumberPresent.index())),
                    "the private fresh literal retains its constructor-owned canonical empty bitmap");
                assert_eq!(field_owner(body, number_write), field_owner(body, words[0]));
                assert!(primitive_only(&body[number_write + 1..words[0]]),
                    "complete backing roots and scalar metadata publish without an intervening allocation or callback");
                let publications = body.iter().filter(|op| matches!(op,
                    Operator::Call { function_index } | Operator::ReturnCall { function_index }
                        if *function_index == publish)).count();
                assert_eq!(publications, length as usize);
                assert!(!calls(&body[..alternative], publish));
                assert!(calls(&body[alternative + 1..complete], publish));
                for array in [numbers, presence] {
                    assert!(!body.iter().any(|op| matches!(op,
                        Operator::ArraySet { array_type_index } if *array_type_index == array)),
                        "bounded source bodies never duplicate the backing-growth CFG");
                }
            }
            for (name, occupied) in [("js::hole#", 3), ("js::long#", 9), ("js::empty#", 0)] {
                let (_, body) = program.named(name);
                assert!(!body.iter().any(|op| matches!(op,
                    Operator::ArrayNewFixed { array_type_index, .. }
                        if *array_type_index == numbers || *array_type_index == presence)),
                    "holes, empty and larger literals keep their existing path");
                assert_eq!(body.iter().filter(|op| matches!(op,
                    Operator::Call { function_index } | Operator::ReturnCall { function_index }
                        if *function_index == publish)).count(), occupied);
            }
        })
        .unwrap()
        .join()
        .unwrap();
}
