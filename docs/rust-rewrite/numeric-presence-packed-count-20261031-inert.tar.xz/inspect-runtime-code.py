"""Idle-only own-R inert ABI42/46 CountB audit; never load or execute payloads."""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import re
import subprocess

ROOT = Path('/workspace/scriptw')
OUT = Path(__file__).resolve().parent
BASELINE = ROOT / 'target/performance-date-demand-20261031'
ACCEPTED_PARENT = '6365a67cc523d4428f4d7d5c2c091bf60faab1b8'
DATE_ACCEPTED_SOURCE = 'a9d31bddb6fa2efc81315e46d1798d78b1d314b6'
DATE_PRODUCER_COMMIT = '7c47e38274c9645b6701552c87d38362b2bfbcd5'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--candidate-fingerprint', required=True)
    parser.add_argument('--source-manifest', default='compiled-inputs.json')
    parser.add_argument('--source-patch', default='compile-inputs.patch')
    args = parser.parse_args()
    candidate_fingerprint = args.candidate_fingerprint
    assert re.fullmatch(r'[0-9a-f]{64}', candidate_fingerprint)
    assert candidate_fingerprint not in {
        'a35adbcb61dbc57b4ee44dd1527019358deb137b11ae559de7d0d4b4a860b480',
        '661084f09940b7242250ba476566cfbee929db4167eb00a43e1fe571cf398d5a',
    }, 'require the newly frozen CountB candidate, not the parent or sealed append v1'
    # Variable manifest/patch names permit a documented test-only continuation
    # without retagging the original frozen snapshot or changing this driver.
    inputs_path = OUT / args.source_manifest
    patch_path = OUT / args.source_patch
    for source_path in [inputs_path, patch_path]:
        assert source_path.parent == OUT and source_path.is_file() and not source_path.is_symlink()
        assert source_path.stat().st_size < 1024**2
    inputs = json.loads(inputs_path.read_text())
    assert isinstance(inputs, dict) and len(inputs) == 25
    expected_new_modules = {
        'crates/scriptw-aot-wasm/src/gc_types/value/array_index_word.rs',
        'crates/scriptw-engine/src/wasm_rooted_snapshot/number_presence.rs',
    }
    assert {name for name, row in inputs.items() if row['untracked_new_module']} == expected_new_modules
    # Documentation may receive actual measurements after compilation. Bind
    # all frozen inputs, but compare only current Rust source bytes here.
    checked_rust = {}
    for name, expected in inputs.items():
        assert name.startswith('crates/') or name.endswith('.md')
        if name.startswith('crates/'):
            assert name.endswith('.rs')
            source_path = ROOT / name
            assert source_path.is_file() and not source_path.is_symlink()
            data = source_path.read_bytes()
            actual = dict(sha256=hashlib.sha256(data).hexdigest(), bytes=len(data))
            assert actual == {key: expected[key] for key in ['sha256', 'bytes']}, name
            checked_rust[name] = actual
    source_binding = dict(candidate_parent_commit=ACCEPTED_PARENT,
        accepted_Date_source_blob_commit=DATE_ACCEPTED_SOURCE,
        changed_input_files=len(inputs), untracked_new_modules=sorted(expected_new_modules),
        candidate_fingerprint_argument=candidate_fingerprint,
        snapshot_manifest=inputs_path.name, snapshot_manifest_sha256=hashlib.sha256(inputs_path.read_bytes()).hexdigest(),
        source_patch=patch_path.name, source_patch_sha256=hashlib.sha256(patch_path.read_bytes()).hexdigest(),
        current_rust_matches_snapshot=checked_rust,
        scope='Frozen own host/runtime receipts must match the explicit new candidate FP and6365 parent. Manifest/patch bind all25 inputs including2 new Rust modules; current Rust bytes must match. Docs may receive actual measurements. Date baseline retains actual7c producer and accepted a9 source; no retagging. Root owns full build-input and unchanged-source continuation proof.')
    spec = importlib.util.spec_from_file_location(
        'owned_runtime_inspector', ROOT / 'target/performance-memory-parity-20261031/diagnose-pages.py')
    inspector = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(inspector)

    identities = {
        'baseline': ('a35adbcb61dbc57b4ee44dd1527019358deb137b11ae559de7d0d4b4a860b480', 42),
        'candidate': (candidate_fingerprint, 46),
    }
    wanted = {
        'array_packed_push1': 'helper::array_packed_push1',
        'array_packed_push2': 'helper::array_packed_push2',
        'array_packed_push3': 'helper::array_packed_push3',
        'array_prototype_push': 'builtin::Array.prototype.push',
        'ordinary_property_append': 'helper::ordinary_property_append',
        'native_constructor_header_allocate': 'helper::native_constructor_header_allocate',
        'property_value_resolve': 'helper::property_value_resolve',
        'array_indexed_publish_default_data': 'helper::array_indexed_publish_default_data',
        'array_indexed_publish': 'helper::array_indexed_publish',
        'array_indexed_delete': 'helper::array_indexed_delete',
        'object_read': 'helper::object_read',
        'cached_property_read': 'helper::cached_property_read',
        'array_packed_join': 'helper::array_packed_join',
    }
    optional_wanted = {'array_constructor': 'builtin::Array'}
    rows = {}
    for label, folder in [('baseline', BASELINE), ('candidate', OUT)]:
        inspector.WORK = folder
        target = OUT / 'code-size-private' / label
        target.mkdir(parents=True, exist_ok=False)
        host, identity, record = inspector.extract_runtime('candidate', target)
        expected_fingerprint, expected_layout = identities[label]
        assert record['source_fingerprint'] == expected_fingerprint and record['runtime_layout'] == expected_layout
        if label == 'candidate':
            assert record['source_commit'] == ACCEPTED_PARENT
        else:
            assert record['source_commit'] == DATE_PRODUCER_COMMIT
        helpers = {}
        for key, suffix in wanted.items():
            matches = [function for function in record['functions'] if function['name'].endswith('::' + suffix)]
            assert len(matches) == 1, (key, len(matches))
            helpers[key] = matches[0]
        optional_helpers = {}
        for key, suffix in optional_wanted.items():
            matches = [function for function in record['functions'] if function['name'].endswith('::' + suffix)]
            assert len(matches) <= 1, (key, len(matches))
            optional_helpers[key] = dict(status='present' if matches else 'symbol unavailable',
                                         function=matches[0] if matches else None)
        image = target / record['inert_native_file']
        captures = {}
        for key in ['array_indexed_publish_default_data', 'object_read', 'array_packed_push1']:
            function = helpers[key]
            length = min(256, function['bytes'])
            with image.open('rb') as stream:
                stream.seek(function['file_offset'])
                entry = stream.read(length)
            assert len(entry) == length
            command = ['/usr/bin/objdump', '-d', f'--start-address={function["value"]}',
                       f'--stop-address={function["value"] + length}', str(image)]
            capture = subprocess.run(command, text=True, capture_output=True, check=True)
            entry_path = target / (key + '-entry-256.txt')
            entry_path.write_text(capture.stdout)
            stderr = target / (key + '-entry-256.stderr')
            stderr.write_text(capture.stderr)
            reservations = re.findall(r'\bsub\s+\$0x([0-9a-f]+),%rsp', capture.stdout)
            allowances = re.findall(r'\badd\s+\$0x([0-9a-f]+),%r10', capture.stdout)
            saved = list(dict.fromkeys(re.findall(r'\bmov\s+%(rbx|r12|r13|r14|r15),0x[0-9a-f]+\(%rsp\)', capture.stdout)))
            captures[key] = dict(raw=str(entry_path.relative_to(OUT)), stderr=str(stderr.relative_to(OUT)),
                                command=command, bytes=length, span_sha256=hashlib.sha256(entry).hexdigest(),
                                observed_stack_reservation_bytes=int(reservations[0], 16) if reservations else None,
                                observed_stack_limit_allowance_bytes=int(allowances[0], 16) if allowances else None,
                                observed_saved_registers=saved,
                                observed_push_rbp=bool(re.search(r'\bpush\s+%rbp', capture.stdout)),
                                scope='Only clear instructions within the first256B. A missing pattern is unknown, not zero. Stack reservation excludes pushed RBP/caller return address. No execution or residency attribution.')
        rows[label] = dict(host=str(host), host_sha256=record['host_sha256'], source_commit=record['source_commit'],
            source_fingerprint=record['source_fingerprint'], runtime_key=record['runtime_key'], runtime_layout=record['runtime_layout'],
            native_sha256=record['native_sha256'], native_bytes=record['native_bytes'], runtime_text_bytes=record['text']['bytes'],
            resolver=helpers['property_value_resolve'], helpers=helpers, optional_helpers=optional_helpers, entry_captures=captures,
            raw_symbols=str((target / 'candidate-runtime-symbols.json').relative_to(OUT)))
    report = dict(schema='scriptw-inert-runtime-code-size-v1', scored=False, native_execution=False, products=rows,
        source_binding=source_binding,
        raw_runtime_wasm_type_section=dict(
            schema='scriptw-inert-raw-runtime-type-section-v1',
            status='unavailable', compared=False, identical_payload=None,
            reason='The existing own-host diagnose-pages.py::extract_runtime returns the verified decompressed Portable native ELF and execution receipt only. It provides no raw R Wasm bytes or digest-bound raw-R Wasm path. No alternate host harness, compiler invocation, native payload load or opcode-byte counting was added.',
            physical_source_contract='COUNT remains I64 and NUMBER_PRESENT retains its original nominal bitmap field; actual raw R TypeSection equality is unverified by this diagnostic.'),
        helper_ownership=dict(
            changed_numeric_paths=['array_indexed_publish_default_data','array_indexed_publish','array_indexed_delete','object_read','cached_property_read'],
            source_controls=['property_value_resolve','ordinary_property_append','native_constructor_header_allocate','array_packed_push1','array_packed_push2','array_packed_push3','array_prototype_push','array_packed_join'],
            inline_emission='GetV and emit_packed_array_value/emit_packed_number_probe are emitted into their owning functions, including P; they have no separate runtime-helper symbol. R object_read/cached_property_read and indexed publication/delete are concrete surrounding owners. Source-control classification does not assert native byte identity.'),
        optional_helper_changes_bytes={name: (rows['candidate']['optional_helpers'][name]['function']['bytes'] - rows['baseline']['optional_helpers'][name]['function']['bytes']) if all(rows[label]['optional_helpers'][name]['function'] is not None for label in rows) else None for name in optional_wanted},
        changes_bytes={key: rows['candidate'][key] - rows['baseline'][key] for key in ['native_bytes', 'runtime_text_bytes']},
        resolver_change_bytes=rows['candidate']['resolver']['bytes'] - rows['baseline']['resolver']['bytes'],
        helper_changes_bytes={name: rows['candidate']['helpers'][name]['bytes'] - rows['baseline']['helpers'][name]['bytes'] for name in wanted},
        identity_policy='Existing bounded extractor hashes each frozen own host against products/identity metadata before and after extraction; validates packed framing, execution receipt, source FP, ABI42/46, decompressed native length/SHA and ELF extents/symbols. No archived native image is loaded or read.',
        limits='Own frozen ELF data and six bounded256B entry captures only. No native payload/module loading or execution, live profiling, executed-code/residency/RSS or causal performance claim. Native images and extracted ELF remain private; archive must exclude them by suffix/magic/regular-file policy. This diagnostic makes no GC byte claim; conditional source counts remain separate.')
    with (OUT / 'runtime-code-size.json').open('x') as stream:
        stream.write(json.dumps(report, indent=2) + '\n')
    print(json.dumps(dict(status='complete', products={label: dict(source_fingerprint=row['source_fingerprint'], runtime_layout=row['runtime_layout'], native_bytes=row['native_bytes'], runtime_text_bytes=row['runtime_text_bytes'], helpers={name: value['bytes'] for name, value in row['helpers'].items()}, entries={name: {key: capture[key] for key in ['observed_stack_reservation_bytes','observed_stack_limit_allowance_bytes','observed_saved_registers']} for name,capture in row['entry_captures'].items()}) for label,row in rows.items()}, changes_bytes=report['changes_bytes'], helper_changes_bytes=report['helper_changes_bytes']), indent=2), flush=True)


if __name__ == '__main__':
    main()
