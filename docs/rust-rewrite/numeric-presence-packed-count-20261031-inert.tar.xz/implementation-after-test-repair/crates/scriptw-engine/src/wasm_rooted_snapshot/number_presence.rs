//! Read-only domain checks for scalar small presence and nominal large bitmaps.
//! Raw word encoding belongs exclusively to the production AOT codec.
use super::{invariant, SnapshotBudget, SnapshotRejection};
use scriptw_aot_wasm::{ArrayIndexedStorageMode, DecodedArrayIndexWord};

pub(super) fn decode_word(raw: i64) -> Result<DecodedArrayIndexWord, SnapshotRejection> {
    scriptw_aot_wasm::snapshot_array_index_word(raw)
        .ok_or_else(|| invariant("noncanonical Array count/presence word"))
}

pub(super) enum NumberPresenceView {
    Inactive,
    Small { mask: u16, count: u32 },
    Bitmap { words: u32, count: u32 },
}

impl NumberPresenceView {
    pub(super) fn validate(
        word: DecodedArrayIndexWord,
        mode: ArrayIndexedStorageMode,
        capacity: u32,
        bitmap_words: u32,
        length: i64,
    ) -> Result<Self, SnapshotRejection> {
        if !(0..=u32::MAX as i64).contains(&length) || i64::from(word.count()) > length {
            return Err(invariant("invalid Array presence count/length"));
        }
        if mode != ArrayIndexedStorageMode::PackedNumbers {
            if word.small_mask().is_some() || capacity != 0 || bitmap_words != 0 {
                return Err(invariant(
                    "inactive Array Number metadata/backing is not empty",
                ));
            }
            return Ok(Self::Inactive);
        }
        if capacity > (1 << 20)
            || (capacity != 0 && (capacity < 4 || !capacity.is_power_of_two()))
            || word.count() > capacity
        {
            return Err(invariant("invalid packed Number Array capacity/count"));
        }
        if let Some(mask) = word.small_mask() {
            if !matches!(capacity, 4 | 8 | 16)
                || bitmap_words != 0
                || u32::from(mask) >> capacity != 0
                || i64::from(u16::BITS - 1 - mask.leading_zeros()) >= length
            {
                return Err(invariant(
                    "invalid scalar Array presence capacity/bitmap/length",
                ));
            }
            // The canonical decoder already proves mask != 0 and its popcount
            // equals the logical count. It exposes no way to forge this view.
            return Ok(Self::Small {
                mask,
                count: word.count(),
            });
        }
        if (capacity != 0 && capacity < 32) || bitmap_words != capacity.div_ceil(64) {
            return Err(invariant("invalid nominal Array presence capacity/extent"));
        }
        Ok(Self::Bitmap {
            words: bitmap_words,
            count: word.count(),
        })
    }

    pub(super) fn word_count(&self) -> u32 {
        match self {
            Self::Inactive => 0,
            Self::Small { .. } => 1,
            Self::Bitmap { words, .. } => *words,
        }
    }

    pub(super) fn scalar_word(&self) -> Option<u64> {
        match self {
            Self::Small { mask, .. } => Some(u64::from(*mask)),
            Self::Inactive | Self::Bitmap { .. } => None,
        }
    }

    /// The scalar mask costs one virtual word, despite retaining an empty
    /// nominal bitmap. Occupied entries are still charged before traversal.
    pub(super) fn charge_work(&self, budget: &mut SnapshotBudget) -> Result<(), SnapshotRejection> {
        let count = match self {
            Self::Small { count, .. } | Self::Bitmap { count, .. } => *count,
            Self::Inactive => return Err(invariant("inactive Number presence was enumerated")),
        };
        budget.work(count as usize + self.word_count() as usize)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use scriptw_runtime::rooted_snapshot::{SnapshotBudgetDimension, SnapshotLimits};

    // Frozen ABI fixtures exercise the real cross-crate decoder. Host code has
    // no encoder or duplicate constants describing the physical word layout.
    const SMALL_4: i64 = 0x8000_0005_0000_0002_u64 as i64;
    const SMALL_8: i64 = 0x8000_0081_0000_0002_u64 as i64;
    const SMALL_16: i64 = 0x8000_8008_0000_0002_u64 as i64;

    fn view(
        raw: i64,
        mode: ArrayIndexedStorageMode,
        capacity: u32,
        bitmap_words: u32,
        length: i64,
    ) -> Result<NumberPresenceView, SnapshotRejection> {
        NumberPresenceView::validate(decode_word(raw)?, mode, capacity, bitmap_words, length)
    }

    fn rejects<T>(result: Result<T, SnapshotRejection>) {
        assert!(matches!(
            result,
            Err(SnapshotRejection::BackendInvariant { .. })
        ));
    }

    fn budget(work: u32) -> SnapshotBudget {
        SnapshotBudget::new(SnapshotLimits::new(1, 1, 1, 1, 1, 1, work, 1).unwrap())
    }

    #[test]
    fn count_word_bridge_decodes_signed_small_words_and_rejects_noncanonical_words() {
        for (raw, expected) in [(0, 0), (1, 1), (i64::from(u32::MAX), u32::MAX)] {
            let decoded = decode_word(raw).unwrap();
            assert_eq!(decoded.count(), expected);
            assert_eq!(decoded.small_mask(), None);
        }
        assert!(SMALL_4 < 0);
        let decoded = decode_word(SMALL_4).unwrap();
        assert_eq!(decoded.count(), 2);
        assert_eq!(decoded.small_mask(), Some(0b0101));
        for raw in [
            0x8000_0000_0000_0000_u64,
            0x0000_0001_0000_0001,
            0x8001_0001_0000_0001,
            0xc000_0001_0000_0001,
            0x8000_0003_0000_0001,
            u64::MAX,
        ] {
            rejects(decode_word(raw as i64));
        }
    }

    #[test]
    fn scalar_presence_checks_mode_capacity_nominal_empty_extent_and_length() {
        for (raw, capacity, expected, length) in [
            (SMALL_4, 4, 0b0101, 3),
            (SMALL_8, 8, 0b1000_0001, 8),
            (SMALL_16, 16, (1 << 15) | (1 << 3), 16),
            (SMALL_4, 4, 0b0101, i64::from(u32::MAX)),
        ] {
            let presence = view(
                raw,
                ArrayIndexedStorageMode::PackedNumbers,
                capacity,
                0,
                length,
            )
            .unwrap();
            assert_eq!(presence.word_count(), 1);
            assert_eq!(presence.scalar_word(), Some(expected));
        }
        for mode in [
            ArrayIndexedStorageMode::PackedValues,
            ArrayIndexedStorageMode::DenseDescriptors,
            ArrayIndexedStorageMode::SparseDescriptors,
        ] {
            rejects(view(SMALL_4, mode, 0, 0, 3));
        }
        for capacity in [0, 1, 2, 3, 5, 32, 64, 1 << 21] {
            rejects(view(
                SMALL_4,
                ArrayIndexedStorageMode::PackedNumbers,
                capacity,
                0,
                64,
            ));
        }
        for (raw, capacity, words, length) in [
            (SMALL_4, 4, 1, 4),
            (SMALL_8, 4, 0, 8),
            (SMALL_16, 8, 0, 16),
            (SMALL_4, 4, 0, 2),
            (SMALL_4, 4, 0, 1),
            (SMALL_4, 4, 0, -1),
            (SMALL_4, 4, 0, i64::from(u32::MAX) + 1),
        ] {
            rejects(view(
                raw,
                ArrayIndexedStorageMode::PackedNumbers,
                capacity,
                words,
                length,
            ));
        }
    }

    #[test]
    fn plain_presence_preserves_large_bitmap_and_inactive_domains() {
        for (count, capacity, words, length) in [
            (0, 0, 0, i64::from(u32::MAX)),
            (1, 32, 1, 32),
            (2, 64, 1, 64),
            (2, 128, 2, 128),
        ] {
            let presence = view(
                count,
                ArrayIndexedStorageMode::PackedNumbers,
                capacity,
                words,
                length,
            )
            .unwrap();
            assert_eq!(presence.word_count(), words);
            assert_eq!(presence.scalar_word(), None);
        }
        for mode in [
            ArrayIndexedStorageMode::PackedValues,
            ArrayIndexedStorageMode::DenseDescriptors,
            ArrayIndexedStorageMode::SparseDescriptors,
        ] {
            let presence = view(7, mode, 0, 0, 7).unwrap();
            assert_eq!(presence.word_count(), 0);
            rejects(presence.charge_work(&mut budget(1)));
            rejects(view(1, mode, 4, 0, 4));
            rejects(view(1, mode, 0, 1, 4));
        }
        for (count, capacity, words, length) in [
            (0, 4, 0, 4),
            (1, 4, 1, 4),
            (1, 8, 1, 8),
            (1, 16, 1, 16),
            (0, 0, 1, 0),
            (0, 32, 0, 32),
            (1, 128, 1, 128),
            (0, 33, 1, 33),
            (33, 32, 1, 33),
            (1, 32, 1, 0),
        ] {
            rejects(view(
                count,
                ArrayIndexedStorageMode::PackedNumbers,
                capacity,
                words,
                length,
            ));
        }
    }

    #[test]
    fn scalar_presence_charges_a_virtual_word_before_the_single_occupied_traversal() {
        let small = view(SMALL_4, ArrayIndexedStorageMode::PackedNumbers, 4, 0, 3).unwrap();
        let mut exact = budget(3);
        small.charge_work(&mut exact).unwrap();
        assert_eq!(exact.remaining(SnapshotBudgetDimension::Work), 0);
        let mut short = budget(2);
        assert_eq!(
            small.charge_work(&mut short),
            Err(SnapshotRejection::BudgetExceeded {
                dimension: SnapshotBudgetDimension::Work,
            })
        );
        assert_eq!(short.remaining(SnapshotBudgetDimension::Work), 2);

        let large = view(2, ArrayIndexedStorageMode::PackedNumbers, 128, 2, 128).unwrap();
        let mut exact = budget(4);
        large.charge_work(&mut exact).unwrap();
        assert_eq!(exact.remaining(SnapshotBudgetDimension::Work), 0);
        assert!(large.charge_work(&mut budget(3)).is_err());

        let empty = view(0, ArrayIndexedStorageMode::PackedNumbers, 0, 0, 0).unwrap();
        let mut unchanged = budget(1);
        empty.charge_work(&mut unchanged).unwrap();
        assert_eq!(unchanged.remaining(SnapshotBudgetDimension::Work), 1);
    }
}
