//! Closed Array-only count/presence words and callback-free mutation owners.
use super::*;

const COUNT_MASK: u64 = u32::MAX as u64;
const PRESENCE_SHIFT: i64 = 32;
const PRESENCE_MASK: u64 = u16::MAX as u64;
const SMALL_FLAG: u64 = 1 << 63;
const RESERVED_MASK: u64 = !(COUNT_MASK | (PRESENCE_MASK << PRESENCE_SHIFT) | SMALL_FLAG);

/// A validated physical Array COUNT payload. Construction stays in the codec;
/// snapshots additionally validate storage mode, actual capacity and extent.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct DecodedArrayIndexWord {
    count: u32,
    small_mask: Option<u16>,
}

impl DecodedArrayIndexWord {
    pub(crate) fn decode(raw: i64) -> Option<Self> {
        let word = raw as u64;
        if word & RESERVED_MASK != 0 {
            return None;
        }
        let count = (word & COUNT_MASK) as u32;
        let mask = ((word >> PRESENCE_SHIFT) & PRESENCE_MASK) as u16;
        let small_mask = if word & SMALL_FLAG != 0 {
            if mask == 0 || mask.count_ones() != count {
                return None;
            }
            Some(mask)
        } else {
            if mask != 0 {
                return None;
            }
            None
        };
        Some(Self { count, small_mask })
    }

    /// Logical occupied indexed-property count, excluding all metadata bits.
    pub fn count(self) -> u32 {
        self.count
    }

    /// Complete small numeric presence mask, or the original bitmap state.
    pub fn small_mask(self) -> Option<u16> {
        self.small_mask
    }
}

impl ArrayIndexWordStorage {
    pub(super) const EMPTY: GcOperand<'static, Self, NonNullable> = GcOperand {
        source: OperandSource::I64(0),
        shape: PhantomData,
    };
}

fn raw_operand(word: I64Local) -> GcOperand<'static, ArrayIndexWordStorage, NonNullable> {
    GcOperand {
        source: OperandSource::Local(word.index),
        shape: PhantomData,
    }
}

fn load_raw(owner: &GcLocal<ArrayObject>, schema: &RuntimeSchema, function: &mut Function) {
    let _ = schema
        .field(ArrayObjectSchema::COUNT)
        .read(owner, schema, function);
}

fn decode_count(function: &mut Function) {
    function.instruction(&Instruction::I32WrapI64);
    function.instruction(&Instruction::I64ExtendI32U);
}

fn load_small(word: I64Local, function: &mut Function) {
    word.load(function);
    function.instruction(&Instruction::I64Const(0));
    function.instruction(&Instruction::I64LtS);
}

fn load_mask(word: I64Local, function: &mut Function) {
    word.load(function);
    function.instruction(&Instruction::I64Const(PRESENCE_SHIFT));
    function.instruction(&Instruction::I64ShrU);
    function.instruction(&Instruction::I64Const(PRESENCE_MASK as i64));
    function.instruction(&Instruction::I64And);
}

fn trap_if(function: &mut Function) {
    function.instruction(&Instruction::If(BlockType::Empty));
    function.instruction(&Instruction::Unreachable);
    function.instruction(&Instruction::End);
}

fn check_count_bound(count: I64Local, function: &mut Function) {
    count.load(function);
    function.instruction(&Instruction::I64Const(COUNT_MASK as i64));
    function.instruction(&Instruction::I64GtU);
    trap_if(function);
}

fn encode_small(mask: I64Local, count: I64Local, function: &mut Function) {
    mask.load(function);
    function.instruction(&Instruction::I64Const(PRESENCE_SHIFT));
    function.instruction(&Instruction::I64Shl);
    count.load(function);
    function.instruction(&Instruction::I64Or);
    function.instruction(&Instruction::I64Const(SMALL_FLAG as i64));
    function.instruction(&Instruction::I64Or);
}

impl RuntimeSchema {
    /// Every external count reader sees the logical zero-extended u32 count.
    pub(crate) fn array_index_count(&self, owner: &GcLocal<ArrayObject>, function: &mut Function) {
        load_raw(owner, self, function);
        decode_count(function);
    }

    pub(crate) fn load_array_index_count(
        &self,
        owner: &GcLocal<ArrayObject>,
        output: I64Local,
        function: &mut Function,
    ) {
        self.array_index_count(owner, function);
        output.store(function);
    }

    fn commit_plain_array_index_delta(
        &self,
        owner: &GcLocal<ArrayObject>,
        insert: bool,
        function: &mut Function,
    ) {
        // Read at commit rather than publishing a cached admission estimate.
        let word = self.reserve_i64_local(function);
        load_raw(owner, self, function);
        word.store(function);
        word.load(function);
        function.instruction(&Instruction::I64Const(PRESENCE_SHIFT));
        function.instruction(&Instruction::I64ShrU);
        function.instruction(&Instruction::I64Eqz);
        function.instruction(&Instruction::I32Eqz);
        trap_if(function);
        word.load(function);
        function.instruction(&Instruction::I64Const(if insert {
            COUNT_MASK as i64
        } else {
            0
        }));
        function.instruction(&Instruction::I64Eq);
        trap_if(function);
        word.load(function);
        function.instruction(&Instruction::I64Const(1));
        function.instruction(&if insert {
            Instruction::I64Add
        } else {
            Instruction::I64Sub
        });
        word.store(function);
        self.field(ArrayObjectSchema::COUNT)
            .write(owner, raw_operand(word), self, function);
        self.release_i64_local(word, function);
    }

    /// Requires an absent indexed slot in a non-small storage mode.
    pub(crate) fn insert_plain_array_index(
        &self,
        owner: &GcLocal<ArrayObject>,
        function: &mut Function,
    ) {
        self.commit_plain_array_index_delta(owner, true, function);
    }

    /// Requires a present indexed slot in a non-small storage mode.
    pub(crate) fn delete_plain_array_index(
        &self,
        owner: &GcLocal<ArrayObject>,
        function: &mut Function,
    ) {
        self.commit_plain_array_index_delta(owner, false, function);
    }

    /// Promotions retain occupancy. An already-plain delete-last word is left
    /// alone, so common backing retirement cannot perform another zero commit.
    pub(crate) fn strip_array_index_presence(
        &self,
        owner: &GcLocal<ArrayObject>,
        function: &mut Function,
    ) {
        let word = self.reserve_i64_local(function);
        load_raw(owner, self, function);
        word.store(function);
        load_small(word, function);
        function.instruction(&Instruction::If(BlockType::Empty));
        word.load(function);
        decode_count(function);
        word.store(function);
        self.field(ArrayObjectSchema::COUNT)
            .write(owner, raw_operand(word), self, function);
        function.instruction(&Instruction::End);
        self.release_i64_local(word, function);
    }

    pub(crate) fn array_index_word<'owner>(
        &self,
        owner: &'owner GcLocal<ArrayObject>,
        function: &mut Function,
    ) -> ArrayIndexWord<'owner> {
        let word = self.reserve_i64_local(function);
        load_raw(owner, self, function);
        word.store(function);
        ArrayIndexWord { owner, word }
    }
}

/// Only a nonempty, complete fresh literal prefix creates a constant word.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) struct SmallArrayIndexWord {
    word: i64,
}

impl SmallArrayIndexWord {
    pub(crate) fn prefix(capacity: u32, length: u32) -> Option<Self> {
        if !matches!(capacity, 4 | 8 | 16) || length == 0 || length > capacity {
            return None;
        }
        let mask = (1_u64 << length) - 1;
        Some(Self {
            word: (SMALL_FLAG | (mask << PRESENCE_SHIFT) | u64::from(length)) as i64,
        })
    }

    pub(crate) fn publish_fresh_numeric_prefix(
        self,
        owner: &GcLocal<ArrayObject>,
        schema: &RuntimeSchema,
        function: &mut Function,
    ) {
        schema.field(ArrayObjectSchema::COUNT).write(
            owner,
            GcOperand {
                source: OperandSource::I64(self.word),
                shape: PhantomData,
            },
            schema,
            function,
        );
    }
}

/// The retained owner and cached scalar word belong to one callback-free
/// operation. No encoded operand or unchecked count setter escapes.
#[must_use = "release the cached scalar word before leaving the operation"]
pub(crate) struct ArrayIndexWord<'owner> {
    owner: &'owner GcLocal<ArrayObject>,
    word: I64Local,
}

impl<'owner> ArrayIndexWord<'owner> {
    pub(crate) fn load_count(&self, output: I64Local, function: &mut Function) {
        self.word.load(function);
        decode_count(function);
        output.store(function);
    }

    fn read_selected_presence_word(
        &self,
        bitmap: &GcLocal<NumberPresenceU64Array>,
        word: I32Local,
        output: I64Local,
        schema: &RuntimeSchema,
        function: &mut Function,
    ) {
        function.instruction(&Instruction::If(BlockType::Empty));
        word.load(function);
        trap_if(function);
        load_mask(self.word, function);
        output.store(function);
        function.instruction(&Instruction::Else);
        schema
            .array_type::<NumberPresenceU64Array>()
            .read(bitmap, word, schema, function)
            .store_i64(output, function);
        function.instruction(&Instruction::End);
    }

    /// Caller keeps its existing actual Number-capacity admission. Small state
    /// covers only word0; plain state retains the original nominal array.get.
    pub(crate) fn read_presence_word(
        &self,
        bitmap: &GcLocal<NumberPresenceU64Array>,
        word: I32Local,
        output: I64Local,
        schema: &RuntimeSchema,
        function: &mut Function,
    ) {
        load_small(self.word, function);
        self.read_selected_presence_word(bitmap, word, output, schema, function);
    }

    pub(crate) fn bit<'operation>(
        &'operation mut self,
        bitmap: &'operation GcLocal<NumberPresenceU64Array>,
        index: I32Local,
        schema: &RuntimeSchema,
        function: &mut Function,
    ) -> ArrayIndexBit<'operation, 'owner> {
        let word = schema.reserve_i32_local(function);
        let mask = schema.reserve_i64_local(function);
        let bits = schema.reserve_i64_local(function);
        let small = schema.reserve_i32_local(function);
        index.load(function);
        function.instruction(&Instruction::I32Const(6));
        function.instruction(&Instruction::I32ShrU);
        word.store(function);
        function.instruction(&Instruction::I64Const(1));
        index.load(function);
        function.instruction(&Instruction::I64ExtendI32U);
        function.instruction(&Instruction::I64Shl);
        mask.store(function);
        load_small(self.word, function);
        small.store(function);
        small.load(function);
        self.read_selected_presence_word(bitmap, word, bits, schema, function);
        ArrayIndexBit {
            state: self,
            bitmap,
            word,
            mask,
            bits,
            small,
        }
    }

    /// All allocation belongs to the caller. Actual old/new Number lengths
    /// prove growth and absence; the returned word already includes the new bit
    /// and count before either replacement backing is published.
    pub(crate) fn prepare_growth_insert<'operation>(
        &'operation mut self,
        new_numbers: &GcLocal<NumberBitsI64Array>,
        index: I32Local,
        schema: &RuntimeSchema,
        function: &mut Function,
    ) -> PreparedNumericInsertion<'operation, 'owner> {
        let old_numbers = schema.reserve_gc_local(function).initialize(
            schema
                .field(ArrayObjectSchema::NUMBERS)
                .read(self.owner, schema, function)
                .reference(),
            function,
        );
        let old_capacity = schema.reserve_i32_local(function);
        let new_capacity = schema.reserve_i32_local(function);
        schema
            .array_type::<NumberBitsI64Array>()
            .length(&old_numbers, schema, function);
        old_capacity.store(function);
        schema
            .array_type::<NumberBitsI64Array>()
            .length(new_numbers, schema, function);
        new_capacity.store(function);
        new_capacity.load(function);
        old_capacity.load(function);
        function.instruction(&Instruction::I32LeU);
        new_capacity.load(function);
        function.instruction(&Instruction::I32Const(4));
        function.instruction(&Instruction::I32LtU);
        function.instruction(&Instruction::I32Or);
        new_capacity.load(function);
        new_capacity.load(function);
        function.instruction(&Instruction::I32Const(1));
        function.instruction(&Instruction::I32Sub);
        function.instruction(&Instruction::I32And);
        function.instruction(&Instruction::I32Or);
        index.load(function);
        old_capacity.load(function);
        function.instruction(&Instruction::I32LtU);
        function.instruction(&Instruction::I32Or);
        index.load(function);
        new_capacity.load(function);
        function.instruction(&Instruction::I32GeU);
        function.instruction(&Instruction::I32Or);
        trap_if(function);
        let count = schema.reserve_i64_local(function);
        self.load_count(count, function);
        count.load(function);
        function.instruction(&Instruction::I64Const(1));
        function.instruction(&Instruction::I64Add);
        count.store(function);
        check_count_bound(count, function);
        let prepared = schema.reserve_i64_local(function);
        new_capacity.load(function);
        function.instruction(&Instruction::I32Const(16));
        function.instruction(&Instruction::I32LeU);
        function.instruction(&Instruction::If(BlockType::Empty));
        let mask = schema.reserve_i64_local(function);
        load_mask(self.word, function);
        function.instruction(&Instruction::I64Const(1));
        index.load(function);
        function.instruction(&Instruction::I64ExtendI32U);
        function.instruction(&Instruction::I64Shl);
        function.instruction(&Instruction::I64Or);
        mask.store(function);
        encode_small(mask, count, function);
        prepared.store(function);
        schema.release_i64_local(mask, function);
        function.instruction(&Instruction::Else);
        count.load(function);
        prepared.store(function);
        function.instruction(&Instruction::End);
        schema.release_i64_local(count, function);
        schema.release_i32_local(new_capacity, function);
        schema.release_i32_local(old_capacity, function);
        old_numbers.clear(function);
        PreparedNumericInsertion {
            state: self,
            prepared,
        }
    }

    fn publish_word(&mut self, word: I64Local, schema: &RuntimeSchema, function: &mut Function) {
        schema.field(ArrayObjectSchema::COUNT).write(
            self.owner,
            raw_operand(word),
            schema,
            function,
        );
        word.load(function);
        self.word.store(function);
    }

    pub(crate) fn release(self, schema: &RuntimeSchema, function: &mut Function) {
        schema.release_i64_local(self.word, function);
    }
}

/// A replacement count/mask tied to the same live owner. The Number payload and
/// nominal bitmap must be complete and paired-published immediately before commit.
#[must_use = "commit the complete growth word after staging both replacement backings"]
pub(crate) struct PreparedNumericInsertion<'operation, 'owner> {
    state: &'operation mut ArrayIndexWord<'owner>,
    prepared: I64Local,
}

impl PreparedNumericInsertion<'_, '_> {
    pub(crate) fn commit(self, schema: &RuntimeSchema, function: &mut Function) {
        self.state.publish_word(self.prepared, schema, function);
        schema.release_i64_local(self.prepared, function);
    }
}

/// One admitted bit and complete cached word, consumed before any separate
/// backing/count mutation or callback. The nominal bitmap root stays typed.
#[must_use = "release the bit capability before retiring or replacing the backings"]
pub(crate) struct ArrayIndexBit<'operation, 'owner> {
    state: &'operation mut ArrayIndexWord<'owner>,
    bitmap: &'operation GcLocal<NumberPresenceU64Array>,
    word: I32Local,
    mask: I64Local,
    bits: I64Local,
    small: I32Local,
}

impl ArrayIndexBit<'_, '_> {
    pub(crate) fn is_present(&self, function: &mut Function) {
        self.bits.load(function);
        self.mask.load(function);
        function.instruction(&Instruction::I64And);
        function.instruction(&Instruction::I64Eqz);
        function.instruction(&Instruction::I32Eqz);
    }

    pub(crate) fn set_present(&mut self, schema: &RuntimeSchema, function: &mut Function) {
        self.is_present(function);
        function.instruction(&Instruction::I32Eqz);
        function.instruction(&Instruction::If(BlockType::Empty));
        // The caller already wrote the Number payload. Existing elements
        // retain their complete count/mask/bitmap without another publication.
        let count = schema.reserve_i64_local(function);
        self.state.load_count(count, function);
        count.load(function);
        function.instruction(&Instruction::I64Const(1));
        function.instruction(&Instruction::I64Add);
        count.store(function);
        check_count_bound(count, function);
        self.bits.load(function);
        self.mask.load(function);
        function.instruction(&Instruction::I64Or);
        self.bits.store(function);
        self.publish(count, schema, function);
        schema.release_i64_local(count, function);
        function.instruction(&Instruction::End);
    }

    pub(crate) fn clear_present(&mut self, schema: &RuntimeSchema, function: &mut Function) {
        let count = schema.reserve_i64_local(function);
        self.state.load_count(count, function);
        count.load(function);
        self.is_present(function);
        function.instruction(&Instruction::I64ExtendI32U);
        function.instruction(&Instruction::I64Sub);
        count.store(function);
        check_count_bound(count, function);
        self.bits.load(function);
        self.mask.load(function);
        function.instruction(&Instruction::I64Const(-1));
        function.instruction(&Instruction::I64Xor);
        function.instruction(&Instruction::I64And);
        self.bits.store(function);
        self.publish(count, schema, function);
        schema.release_i64_local(count, function);
    }

    fn publish(&mut self, count: I64Local, schema: &RuntimeSchema, function: &mut Function) {
        let encoded = schema.reserve_i64_local(function);
        self.small.load(function);
        function.instruction(&Instruction::If(BlockType::Empty));
        count.load(function);
        function.instruction(&Instruction::I64Eqz);
        function.instruction(&Instruction::If(BlockType::Empty));
        encoded.set_constant(0, function);
        function.instruction(&Instruction::Else);
        encode_small(self.bits, count, function);
        encoded.store(function);
        function.instruction(&Instruction::End);
        function.instruction(&Instruction::Else);
        schema.array_type::<NumberPresenceU64Array>().write(
            self.bitmap,
            self.word,
            GcOperand::i64_local(self.bits),
            schema,
            function,
        );
        count.load(function);
        encoded.store(function);
        function.instruction(&Instruction::End);
        self.state.publish_word(encoded, schema, function);
        schema.release_i64_local(encoded, function);
    }

    pub(crate) fn release(self, schema: &RuntimeSchema, function: &mut Function) {
        schema.release_i32_local(self.small, function);
        schema.release_i64_local(self.bits, function);
        schema.release_i64_local(self.mask, function);
        schema.release_i32_local(self.word, function);
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn count_word_decoder_rejects_reserved_flags_and_inconsistent_masks() {
        for count in [0, 1, u32::MAX] {
            let decoded = DecodedArrayIndexWord::decode(i64::from(count)).unwrap();
            assert_eq!(decoded.count(), count);
            assert_eq!(decoded.small_mask(), None);
        }
        for (mask, count) in [(1_u16, 1), (5, 2), (0x8001, 2), (u16::MAX, 16)] {
            let raw = (SMALL_FLAG | (u64::from(mask) << PRESENCE_SHIFT) | count) as i64;
            let decoded = DecodedArrayIndexWord::decode(raw).unwrap();
            assert_eq!(decoded.count(), count as u32);
            assert_eq!(decoded.small_mask(), Some(mask));
        }
        for raw in [
            SMALL_FLAG,
            SMALL_FLAG | 1,
            1_u64 << 32 | 1,
            SMALL_FLAG | 3_u64 << 32 | 1,
            SMALL_FLAG | 1_u64 << 32,
            u64::MAX,
            i64::MAX as u64,
        ] {
            assert_eq!(DecodedArrayIndexWord::decode(raw as i64), None);
        }
        for bit in 48..63 {
            assert!(DecodedArrayIndexWord::decode((1_u64 << bit) as i64).is_none());
            assert!(DecodedArrayIndexWord::decode(
                (SMALL_FLAG | 1_u64 << 32 | 1 | 1_u64 << bit) as i64
            )
            .is_none());
        }
    }

    #[test]
    fn fresh_numeric_prefix_words_admit_only_complete_nonempty_small_states() {
        for capacity in [0, 1, 2, 3, 5, 15, 17, 32, u32::MAX] {
            assert_eq!(SmallArrayIndexWord::prefix(capacity, 1), None);
        }
        for capacity in [4, 8, 16] {
            assert_eq!(SmallArrayIndexWord::prefix(capacity, 0), None);
            assert_eq!(SmallArrayIndexWord::prefix(capacity, capacity + 1), None);
            for count in 1..=capacity {
                let word = SmallArrayIndexWord::prefix(capacity, count).unwrap();
                let decoded = DecodedArrayIndexWord::decode(word.word).unwrap();
                assert_eq!(decoded.count(), count);
                assert_eq!(decoded.small_mask(), Some(((1_u32 << count) - 1) as u16));
            }
        }
    }
}
