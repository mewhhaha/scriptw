# COUNTB measurement source preparation

This is a source-only copy of the I31 measurement driver and exact21 fixtures,
not a new result or replay. See ../ORCHESTRATION.md for the future gate/commands.
No candidate identities/products/images were accessed or hashed; no cache query,
Node/native/build/bind/preparation/measurement command ran.

Baseline remains actual Date/a35/7c-plus-patch/ABI42, reused by accepted6365.
Future COUNTB is ABI46 with an explicit unknown fingerprint. The driver requires
that exact future candidate to retain6365 as its honest producer commit and
rejects both sealed summary fingerprints and requires the new accepted producer source commit. Own producer/image/sidecar/runtime-key
and source validators stay intact; no admission bypass or archived image use.

The canonical nonsymlink normal-cache path is ../normal-cache under this COUNTB
experiment, with fixed overlayfs:794c7630. Source code records path/filesystem and
child SCRIPTW_CACHE_DIR before/after and rejects tmpfs/ramfs/other roots. Root
must create it and set the environment before a future entrypoint.

source-draft-audit.json records only21 unchanged critical function bodies,
namespace/path checks, exact copied21 source hashes, and pure synthetic cache
policy tests. It never imports or runs the cohort entrypoint. The inherited
b6b7 date-inert-compatibility.json is unchanged historical protocol/golden
compatibility evidence, not a fresh504-record audit or COUNTB execution. The
optional historical auditor would write a separately named fresh receipt; it
was copied as source but not executed.
