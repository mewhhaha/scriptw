from pathlib import Path
import hashlib,json,shutil,stat,subprocess
ROOT=Path('/workspace/scriptw');OUT=Path(__file__).resolve().parent
DST=Path('/tmp/scriptw-closed-comparison-caches-20261031');DST.mkdir(exist_ok=False)
def digest(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
entries=[('performance-append-key-summary-20261031','append-key-summary-20261031'),('performance-append-key-lazy-summary-20261031','append-key-lazy-summary-20261031'),('performance-i31-presence-20261031','numeric-presence-i31-20261031')]
r=dict(basis='After all three exact candidates were rejected, sealed, restored and closed to further cohorts, preserve regenerable cache data by digest and relocate it. No frozen runner, prepared image, failed executable, source or raw receipt is moved. Old cache symlinks fail the scored drivers canonical normal-overlay policy; future candidates use a fresh normal-overlay directory.',before_free=shutil.disk_usage(ROOT).free,records=[])
for directory,stem in entries:
 report=json.loads((ROOT/'docs/rust-rewrite'/(stem+'.json')).read_text());assert report['status'].startswith('rejected')
 src=ROOT/'target'/directory/'normal-cache';assert src.is_dir() and not src.is_symlink()
 fs=subprocess.check_output(['stat','-f','--format=%T:%t',str(src)],text=True).strip();assert fs=='overlayfs:794c7630'
 manifest=[]
 for p in sorted(src.rglob('*')):
  if p.is_dir():assert not p.is_symlink();continue
  assert stat.S_ISREG(p.lstat().st_mode) and not p.is_symlink(),p
  manifest.append(dict(path=str(p.relative_to(src)),bytes=p.stat().st_size,sha256=digest(p)))
 dest=DST/directory;shutil.move(str(src),str(dest));assert not src.exists()
 for row in manifest:
  p=dest/row['path'];assert p.stat().st_size==row['bytes'] and digest(p)==row['sha256']
 src.symlink_to(dest,target_is_directory=True)
 r['records'].append(dict(logical_path=str(src),physical_path=str(dest),original_filesystem=fs,bytes=sum(x['bytes'] for x in manifest),files=manifest))
r.update(after_free=shutil.disk_usage(ROOT).free,moved_bytes=sum(x['bytes'] for x in r['records']))
(OUT/'closed-comparison-cache-relocation.json').write_text(json.dumps(r,indent=2)+'\n');print({k:v for k,v in r.items() if k!='records'})
