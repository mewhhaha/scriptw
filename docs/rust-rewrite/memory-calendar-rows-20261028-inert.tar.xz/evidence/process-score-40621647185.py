import hashlib,json,os,sys
from pathlib import Path
BASE=Path(__file__).resolve().parent;ROOT=BASE.parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from limited_verification import require_kernel_budget,kernel_group
import precompiled_comparison as p
require_kernel_budget(1024**3);assert sorted(os.sched_getaffinity(0))==[0]
def budget():return {k:(kernel_group()/k).read_text().strip() for k in ['memory.max','memory.swap.max','memory.oom.group','memory.peak','memory.events']}
before=budget();source=BASE/'github-40621647185-scored/precompiled-evidence/report.json';report,rows=p.load_report(source)
assert report['source_commit']=='7b81ba6c9a6a30189acf75fed72f3f8a434d0992' and report['source_fingerprint']=='7507e0ad8a91869492bfca2dbce101c768170c718e2a04fa52c427b8b343b1c6'
assert len(rows)==17 and len(report['attempts'])==68 and all(x['status']=='ok' for x in report['attempts'])
charts={}
for metric,chart in p.CHARTS.items():
 raw=p.render(report,rows,metric,BASE/('preview-40621647185-'+metric+'.png'));out=BASE/('preview-40621647185-'+metric+'.svg')
 with out.open('xb') as f:f.write(raw)
 charts[metric]=dict(file=out.name,sha256=hashlib.sha256(raw).hexdigest())
ratios=[x['runtimes']['scriptw']['rss_mib']/x['runtimes']['scriptc']['rss_mib'] for x in rows]
selected={x['file']:{runtime:{k:values[k] for k in ['ms','rss_mib']} for runtime,values in x['runtimes'].items()} for x in rows if x['file'] in ['integer.js','objects.js','retained-objects.js']}
after=budget();events=[dict(line.split() for line in x['memory.events'].splitlines()) for x in [before,after]];assert all(events[0][k]==events[1][k] for k in ['oom','oom_kill','oom_group_kill'])
r=dict(complete=True,source_commit=report['source_commit'],report_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),source_fingerprint=report['source_fingerprint'],selected=selected,rss_ratio_range=[min(ratios),max(ratios)],charts=charts,before=before,after=after,cpu_affinity=[0],workloads=17,attempts=68,all_attempts_ok=True)
with (BASE/'score-40621647185.json').open('x') as f:f.write(json.dumps(r,indent=2)+'\n')
print(json.dumps(r))
