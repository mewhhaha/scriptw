"""Private source-bound nine-target calendar verification; prepare, do not autorun.

One serial Cargo build with no optional features produces every executable. Seven focused
controls run first and count toward their full scopes, without duplicate runs.
All observed IDs in nine full scopes run once. Three selected engine-lib
controls run separately; its remaining IDs are not run or credited.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import selectors
import shutil
import signal
import stat
import subprocess
import sys
import time

BASE = Path(__file__).resolve().parent
REPOSITORY = BASE.parents[1]
ROOT = REPOSITORY / 'target/memory-calendar-rows-20261028'
BUILD = REPOSITORY / 'target/performance-work-20261024/build'
BASELINE = REPOSITORY / 'target/memory-ordered-bootstrap-20261027-evidence/native-main-a036f1144/report.json'
REVIEWED_SOURCE = 'd6cacf8350c4a4ad660c40674cfe822f09ae56c1'
SOURCE = REVIEWED_SOURCE
BASELINE_SOURCE = 'a036f1144ea3d3cf502d888b8a07f442837a857f'
MIB = 1024**2

# Select exactly nine retained scopes from the complete a036 native predecessor.
PLAN = [
    ('scriptw-aot-wasm', 'scriptw_aot_wasm', 'lib'),
    ('scriptw-aot-wasm', 'emission', 'test'),
    ('scriptw-aot-wasm', 'modules_realms', 'test'),
    ('scriptw-aot-wasm', 'intl_temporal', 'test'),
    ('scriptw-aot-wasm', 'runtime_link', 'test'),
    ('scriptw-engine', 'aot_temporal', 'test'),
    ('scriptw-engine', 'aot_realm_modules', 'test'),
    ('scriptw-engine', 'aot_gc_entries', 'test'),
    ('scriptw-engine', 'aot_regexp', 'test'),
]
AOT_IDS = [
    'runtime_artifact::cache::tests::runtime_cache_reconstructs_calendar_rows_between_exact_active_fragments',
    'runtime_artifact::cache::tests::abi29_runtime_cache_is_replaced_before_lazy_calendar_rows_are_admitted',
    'runtime_artifact::build_package::tests::abi29_package_is_replaced_before_lazy_calendar_rows_are_admitted',
    'runtime_artifact::build_package::metadata::tests::receipt_metadata_rejects_missing_overlapping_and_unbounded_calendar_spans',
    'data::compiler_owned_pool::tests::normalization_region_is_passive_and_active_fragments_preserve_exact_virtual_addresses',
]
FOCUS = [
    (PLAN[0], AOT_IDS),
    (PLAN[4], ['pooled_string_data::calendar_rows_have_a_separate_lazy_passive_initializer']),
    (PLAN[5], ['aot_temporal_east_asian_calendars::east_asian_rows_initialize_after_gc_in_independent_stores_and_data_orders']),
]
SELECTED_ENGINE = ('scriptw-engine', 'scriptw_engine', 'lib')
SELECTED_ENGINE_IDS = [
    'wasm_gc_host::tests::emitted_portable_and_native_r_keep_actual_compiler_import_domains',
    'wasm_gc_host::tests::present_compiler_names_preserve_wrong_signature_kind_and_duplicate_rejection',
    'wasm_gc_host::tests::native_compilers_still_arm_after_linking_before_all_three_dynamic_calls',
]


def require(value, message):
    if not value:
        raise ValueError(message)


def stamp():
    return datetime.now(timezone.utc).isoformat()


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def source():
    require(re.fullmatch('[0-9a-f]{40}', REVIEWED_SOURCE) is not None and SOURCE == REVIEWED_SOURCE,
            'reviewed final commit is unset or differs from --expected-source')
    require(subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == SOURCE,
            'isolated checkout differs from admitted source')
    require(not subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=normal'], cwd=ROOT),
            'tracked/untracked source changes are not admitted')


def scope():
    require_kernel_budget(4 * 1024**3)
    require(sorted(os.sched_getaffinity(0)) == [0], 'native verification requires CPU0')
    require(os.environ.get('CARGO_BUILD_JOBS') == os.environ.get('RUST_TEST_THREADS') == '1',
            'Cargo and libtest must remain serial')
    require(os.environ.get('SCRIPTW_JOBS') == os.environ.get('RAYON_NUM_THREADS') == '1',
            'native compilation workers must remain serial')
    require(os.environ.get('SCRIPTW_MODULE_MEMORY_CACHE_ENTRIES') == '1'
            and os.environ.get('SCRIPTW_MODULE_MEMORY_CACHE_LIMIT_BYTES') == str(64 * MIB),
            'retained module cache differs from one entry/64 MiB')
    require(os.environ.get('SCRIPTW_EXPECTED_SOURCE') == SOURCE, 'expected-source environment differs')


def budget():
    group = kernel_group()
    return {key: (group / key).read_text().strip() for key in
            ('memory.max', 'memory.swap.max', 'memory.oom.group', 'memory.peak', 'memory.events')}


def no_oom(before, after):
    events = [dict(line.split() for line in row['memory.events'].splitlines()) for row in (before, after)]
    require(all(events[0][key] == events[1][key] for key in ('oom', 'oom_kill', 'oom_group_kill')),
            'kernel OOM event occurred during verification')


def save(output, report):
    temporary = output / 'report.pending.json'
    temporary.write_text(json.dumps(report, indent=2) + '\n')
    temporary.replace(output / 'report.json')


def kill_owned(process):
    try:
        os.killpg(process.pid, signal.SIGKILL)
    except ProcessLookupError:
        pass


def run_command(row, output, *, timeout, stdout_limit, stderr_limit):
    """Drain bounded pipes; preserve metadata even on timeout/spawn/pipe errors."""
    started = time.monotonic()
    row.update(started_at=stamp(), timeout_seconds=timeout, stdout_limit_bytes=stdout_limit,
               stderr_limit_bytes=stderr_limit, timed_out=False, output_limit_exceeded=False)
    paths = {name: output / row[name] for name in ('stdout', 'stderr')}
    process = None
    try:
        with paths['stdout'].open('xb') as stdout, paths['stderr'].open('xb') as stderr:
            streams = dict(stdout=stdout, stderr=stderr)
            limits = dict(stdout=stdout_limit, stderr=stderr_limit)
            retained = dict(stdout=0, stderr=0)
            process = subprocess.Popen(row['command'], cwd=row['cwd'], stdin=subprocess.DEVNULL,
                                       stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True)
            row['owned_child_pid'] = process.pid
            deadline = started + timeout
            stopping = False
            with selectors.DefaultSelector() as selector:
                for name, pipe in [('stdout', process.stdout), ('stderr', process.stderr)]:
                    os.set_blocking(pipe.fileno(), False)
                    selector.register(pipe, selectors.EVENT_READ, name)
                while selector.get_map() or process.poll() is None:
                    if time.monotonic() >= deadline:
                        if stopping:
                            row['pipe_cleanup_incomplete'] = True
                            break
                        row['timed_out'] = True
                        stopping = True
                        deadline = time.monotonic() + 5
                        kill_owned(process)
                    for key, _ in selector.select(0.1):
                        try:
                            raw = os.read(key.fileobj.fileno(), 65536)
                        except BlockingIOError:
                            continue
                        if not raw:
                            selector.unregister(key.fileobj)
                            continue
                        name = key.data
                        keep = min(len(raw), limits[name] - retained[name])
                        streams[name].write(raw[:keep])
                        retained[name] += keep
                        if keep != len(raw) and not stopping:
                            row['output_limit_exceeded'] = True
                            stopping = True
                            deadline = time.monotonic() + 5
                            kill_owned(process)
                if process.poll() is None:
                    kill_owned(process)
                row['exit_code'] = process.wait(timeout=5)
    except BaseException as error:
        row.update(error=str(error), error_type=type(error).__name__)
        raise
    finally:
        try:
            if process is not None:
                if process.poll() is None:
                    kill_owned(process)
                    process.wait(timeout=5)
                row.setdefault('exit_code', process.returncode)
        finally:
            if process is not None:
                for pipe in (process.stdout, process.stderr):
                    if pipe is not None:
                        pipe.close()
            row.update(seconds=time.monotonic() - started, finished_at=stamp())
            for name, path in paths.items():
                if path.exists():
                    row[name + '_sha256'] = sha(path)
                    row[name + '_bytes'] = path.stat().st_size


def main():
    global ROOT, SOURCE, kernel_group, require_kernel_budget, parse_inventory, result_summaries
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--workspace', type=Path, default=ROOT,
                        help='selected clean checkout; defaults to isolated reviewed worktree')
    parser.add_argument('--expected-source', required=True,
                        help='exact final commit frozen into REVIEWED_SOURCE; descendants are not admitted')
    parser.add_argument('--output', type=Path, required=True, help='fresh directory below the private evidence parent')
    args = parser.parse_args()
    ROOT = args.workspace.resolve(strict=True)
    require(ROOT.is_relative_to(REPOSITORY / 'target') and ROOT != REPOSITORY / 'target',
            'workspace must be an isolated checkout below target, never main')
    SOURCE = args.expected_source
    require(re.fullmatch('[0-9a-f]{40}', SOURCE) is not None, 'expected source must be an exact commit')
    sys.path.insert(0, str(ROOT / 'scripts'))
    from limited_verification import kernel_group, require_kernel_budget
    from native_test_protocol import parse_inventory, result_summaries
    output = args.output.resolve()
    require(output.is_relative_to(BASE) and output != BASE and not output.exists(), 'fresh private output required')
    output.mkdir(parents=True, exist_ok=False)
    report = dict(schema='scriptw-calendar-rows-native-verification-v1', source_commit=SOURCE,
                  reviewed_source_commit=REVIEWED_SOURCE, source_checkout=str(ROOT), build_directory=str(BUILD), complete=False, started_at=stamp(),
                  commands=[], scopes=[], selected_scopes=[],
                  plan=[dict(package=p, target=t, kind=k) for p, t, k in PLAN],
                  features=[], predecessor_binary_reuse=False,
                  resource_scope='One serial Cargo build and ten frozen actual Cargo producers. Every native ID in nine affected targets runs once, including seven focus controls. The engine lib is inventoried but only three selected prefilter controls run; its full scope is not claimed. No inherited passes/binaries or pinned Test262 execution is claimed.',
                  expected_native_inventory_total=1763,
                  expected_disjoint_execution_total=1766,
                  count_expectation='1757 retained a036 cases +4 new AOT artifact IDs +2 new lazy-calendar IDs =1763 expected full-scope IDs, plus3 separately selected engine-lib controls =1766 executions. Actual compiled --list inventories determine full-scope totals.')
    save(output, report)
    try:
        scope()
        report.update(cpu_affinity=[0], before=budget(), driver_sha256=sha(Path(__file__)))
        source()
        require(Path(subprocess.check_output(['git', 'rev-parse', '--show-toplevel'], cwd=ROOT, text=True).strip()).resolve() == ROOT,
                'workspace must name the checkout root')
        report['reviewed_source_admission'] = dict(
            reviewed_source_commit=REVIEWED_SOURCE, selected_source_commit=SOURCE,
            interpretation='Exact reviewed commit and clean checkout only; no descendant/equivalent-source admission.')
        require(subprocess.run(['git', 'merge-base', '--is-ancestor', BASELINE_SOURCE, SOURCE], cwd=ROOT).returncode == 0,
                'baseline source is not an ancestor')
        require(BASELINE.stat().st_size <= 16 * MIB, 'oversized baseline report')
        baseline = json.loads(BASELINE.read_text())
        baseline_sha = sha(BASELINE)
        require(baseline['complete'] is True and baseline['source_commit'] == BASELINE_SOURCE
                and baseline['passed_disjoint_scopes'] == 4894 and len(baseline['scopes']) == 19,
                'complete a036 4894-case baseline required')
        all_baseline_scopes = {(s['package'], s['target'], s['kind']): s for s in baseline['scopes']}
        require(len(all_baseline_scopes) == 19 and len(set(PLAN)) == 9
                and set(PLAN) <= set(all_baseline_scopes), 'exact predecessor nine-target selection differs')
        baseline_scopes = {key: all_baseline_scopes[key] for key in PLAN}
        for old in all_baseline_scopes.values():
            require(old['complete'] and len(old['inventory']) == len(set(old['inventory'])) == old['passed'],
                    'baseline target inventory is incomplete')
        require(sum(len(s['inventory']) for s in baseline_scopes.values()) == 1757,
                'selected a036 inventories do not total 1757 IDs')
        report['baseline'] = dict(path=str(BASELINE), sha256=baseline_sha, source_commit=BASELINE_SOURCE,
                                  complete=True, predecessor_all_scopes_passed=4894,
                                  retained_scope_inventory_total=1757, inherited_passes=0,
                                  retained_scopes=[dict(package=p, target=t, kind=k,
                                                       inventory=baseline_scopes[p, t, k]['inventory'])
                                                   for p, t, k in PLAN])
        save(output, report)

        def run(label, command, cwd=ROOT, *, timeout=3600, cargo=False, test_ids=None):
            source()
            scope()
            require(sha(BASELINE) == baseline_sha, 'baseline evidence changed')
            require(sha(Path(__file__)) == report['driver_sha256'], 'frozen driver changed')
            row = dict(label=label, command=list(map(str, command)), cwd=str(cwd),
                       stdout=label + '.stdout', stderr=label + '.stderr')
            if test_ids is not None:
                row['expected_test_ids'] = list(test_ids)
            report['commands'].append(row)
            save(output, report)
            print(label, 'started', flush=True)
            try:
                run_command(row, output, timeout=timeout,
                            stdout_limit=(128 if cargo else 4) * MIB,
                            stderr_limit=(32 if cargo else 4) * MIB)
            finally:
                try:
                    if test_ids is not None and (output / row['stdout']).exists():
                        text = (output / row['stdout']).read_text()
                        row['reported_passing_test_ids'] = [name.removesuffix(' - should panic') for name in
                            re.findall(r'^test ([^\r\n]+) \.\.\. ok$', text, re.M)]
                        row['reported_result_summaries'] = result_summaries(text)
                finally:
                    save(output, report)
            source()
            scope()
            require(row.get('exit_code') == 0 and not row['timed_out'] and not row['output_limit_exceeded']
                    and not row.get('pipe_cleanup_incomplete'), label + ' failed; original streams retained')
            print(label, 'finished', row['exit_code'], flush=True)
            return row, (output / row['stdout']).read_text()

        command = ['cargo', 'test', '--locked', '--offline', '--release', '--jobs', '1', '--target-dir', BUILD,
                   '-p', 'scriptw-engine', '-p', 'scriptw-aot-wasm', '--lib']
        for name in sorted({name for _, name, kind in PLAN if kind == 'test'}):
            command += ['--test', name]
        command += ['--no-default-features', '--no-run', '--message-format=json']
        _, text = run('cargo-native', command, timeout=10800, cargo=True)
        cargo = [json.loads(line) for line in text.splitlines()]
        require(cargo and cargo[-1] == dict(reason='build-finished', success=True)
                and sum(r.get('reason') == 'build-finished' for r in cargo) == 1, 'Cargo build did not finish successfully')
        frozen = {}
        admitted_producers = []
        for package, name, kind in [*PLAN, SELECTED_ENGINE]:
            crate = ROOT / 'crates' / package
            producer_path = 'path+file://' + str(crate) + '#'
            producers = [r for r in cargo if r.get('reason') == 'compiler-artifact' and r.get('executable')
                         and r['target']['name'] == name and r['target']['kind'] == [kind] and r['profile']['test']
                         and r['package_id'].startswith(producer_path)]
            require(len(producers) == 1, 'target lacks a unique actual isolated-source Cargo producer: ' + package + '/' + name)
            producer = producers[0]
            old = all_baseline_scopes[package, name, kind]
            old_crate = REPOSITORY / 'crates' / package
            expected_src = crate / Path(old['cargo_producer']['target']['src_path']).relative_to(old_crate)
            require(Path(producer['target']['src_path']).resolve() == expected_src
                    and producer['features'] == [] and producer['profile']['opt_level'] == '3',
                    'Cargo source/feature/release producer differs')
            original = Path(producer['executable'])
            info = original.lstat()
            require(original.resolve() == original and original.is_relative_to(BUILD)
                    and stat.S_ISREG(info.st_mode), 'Cargo executable is not a regular file in the admitted build directory')
            original_sha = sha(original)
            directory = output / (package + '-' + name)
            directory.mkdir()
            binary = directory / 'tests'
            with original.open('rb') as src, binary.open('xb') as dst:
                shutil.copyfileobj(src, dst)
            binary.chmod(0o500)
            require(sha(binary) == original_sha == sha(original) and binary.stat().st_nlink == 1
                    and binary.stat().st_mode & 0o222 == 0, 'private frozen executable copy differs/is writable')
            target = dict(package=package, target=name, kind=kind, cargo_producer=producer,
                          binary=str(binary.relative_to(output)), executable_sha256=original_sha,
                          baseline_inventory_count=len(old['inventory']), complete=False, passed=0,
                          passed_test_ids=[], focused_test_ids=[], broad_test_ids=[])
            if (package, name, kind) == SELECTED_ENGINE:
                target.pop('complete')
                target.update(selected_complete=False, full_target_coverage_claimed=False,
                              selected_test_ids=SELECTED_ENGINE_IDS)
                report['selected_scopes'].append(target)
            else:
                report['scopes'].append(target)
            frozen[package, name, kind] = (target, binary)
            admitted_producers.append(producer)
            save(output, report)
        actual_target_producers = [r for r in cargo if r.get('reason') == 'compiler-artifact' and r.get('executable')
                                   and r['profile']['test'] and any(r['package_id'].startswith('path+file://' + str(ROOT / 'crates' / p) + '#')
                                   for p in ('scriptw-aot-wasm', 'scriptw-engine'))]
        require(actual_target_producers == [r for r in cargo if r in admitted_producers]
                and len(actual_target_producers) == 10, 'unplanned Cargo native target producer')
        source()
        # Inventory every frozen executable before running any semantic control.
        for key in [*PLAN, SELECTED_ENGINE]:
            target, binary = frozen[key]
            label = key[0] + '-' + key[1]
            _, text = run(label + '-inventory', [binary, '--list', '--color=never'], ROOT / 'crates' / key[0])
            inventory = parse_inventory(text)
            old_ids = set(all_baseline_scopes[key]['inventory'])
            require(old_ids <= set(inventory), 'previously verified native IDs disappeared: ' + label)
            target.update(inventory=inventory, added_test_ids=sorted(set(inventory) - old_ids), removed_test_ids=[])
            if key == SELECTED_ENGINE:
                require(set(SELECTED_ENGINE_IDS) <= set(inventory), 'selected engine IDs missing')
                target['unexecuted_test_ids'] = sorted(set(inventory) - set(SELECTED_ENGINE_IDS))
            save(output, report)
        actual_total = sum(len(frozen[key][0]['inventory']) for key in PLAN)
        report.update(observed_native_inventory_total=actual_total,
                      expected_native_inventory_total_matches=actual_total == report['expected_native_inventory_total'],
                      added_native_ids=sum(len(frozen[key][0]['added_test_ids']) for key in PLAN))
        save(output, report)

        def execute_ids(key, ids, label, phase):
            target, binary = frozen[key]
            require(ids and len(ids) == len(set(ids)) and set(ids) <= set(target['inventory']), 'exact ID chunk differs')
            require(not set(ids).intersection(target['passed_test_ids']), 'native ID would be executed twice')
            row, text = run(label, [binary, '--exact', '--include-ignored', '--test-threads=1', '--color=never', *ids],
                            ROOT / 'crates' / key[0], test_ids=ids)
            names = row['reported_passing_test_ids']
            require(len(names) == len(set(names)) == len(ids) and set(names) == set(ids), 'actual passing exact-name inventory differs')
            require(result_summaries(text) == [('ok', str(len(ids)), '0', '0', '0', str(len(target['inventory']) - len(ids)))],
                    'native terminal summary does not match the full target inventory')
            target['passed_test_ids'] += sorted(names)
            target[phase + '_test_ids'] += sorted(names)
            target['passed'] = len(target['passed_test_ids'])
            save(output, report)

        for key, ids in FOCUS:
            execute_ids(key, ids, key[0] + '-' + key[1] + '-focused', 'focused')
        report.update(focused_complete=True, focused_passed=7,
                      focused_interpretation='All seven controls ran before broad semantic suites. They are credited once toward full target coverage and excluded from each broad remainder; focused overlap is not additional passes.')
        save(output, report)
        execute_ids(SELECTED_ENGINE, SELECTED_ENGINE_IDS, 'scriptw-engine-scriptw_engine-selected', 'focused')
        selected, selected_binary = frozen[SELECTED_ENGINE]
        require(set(selected['passed_test_ids']) == set(SELECTED_ENGINE_IDS)
                and len(selected['passed_test_ids']) == 3
                and sha(selected_binary) == selected['executable_sha256'],
                'selected engine coverage or frozen executable differs')
        selected['selected_complete'] = True
        report.update(selected_controls_complete=True, selected_controls_passed=3)
        save(output, report)
        for key in PLAN:
            target, binary = frozen[key]
            focused_ids = set(target['focused_test_ids'])
            remainder = [name for name in target['inventory'] if name not in focused_ids]
            chunks = [remainder[i:i+8] for i in range(0, len(remainder), 8)] if key[1] == 'aot_gc_entries' else ([remainder] if remainder else [])
            for index, ids in enumerate(chunks):
                execute_ids(key, ids, key[0] + '-' + key[1] + f'-part-{index:03d}', 'broad')
            require(len(target['passed_test_ids']) == len(set(target['passed_test_ids'])) == len(target['inventory'])
                    and set(target['passed_test_ids']) == set(target['inventory'])
                    and sha(binary) == target['executable_sha256'], 'full target coverage or frozen executable changed')
            target['complete'] = True
            save(output, report)
            print(key[0], key[1], target['passed'], 'passed', flush=True)
        source()
        scope()
        require(sha(BASELINE) == baseline_sha and all(frozen[key][0]['complete'] for key in PLAN)
                and len(report['scopes']) == 9
                and len(report['selected_scopes']) == 1 and selected['selected_complete']
                and sha(selected_binary) == selected['executable_sha256']
                and sha(Path(__file__)) == report['driver_sha256'], 'complete target/source/evidence closure differs')
        passed = sum(frozen[key][0]['passed'] for key in PLAN)
        require(passed == actual_total and sum(len(frozen[key][0]['focused_test_ids']) for key in PLAN) == 7,
                'actual disjoint native coverage differs')
        after = budget()
        report['after'] = after
        no_oom(report['before'], after)
        report.update(complete=True, finished_at=stamp(), passed_disjoint_scopes=passed,
                      executed_disjoint_passes=passed + selected['passed'], inherited_disjoint_passes=0,
                      selected_only_passes=selected['passed'],
                      expected_disjoint_execution_total_matches=passed + selected['passed'] == report['expected_disjoint_execution_total'],
                      focused_passes_included=7, broad_remainder_passes=passed - 7,
                      repeated_native_test_ids=0)
        return 0
    except BaseException as error:
        report.update(error=str(error), error_type=type(error).__name__, finished_at=stamp())
        return 1
    finally:
        if 'before' in report and 'after' not in report:
            try:
                report['after'] = budget()
                no_oom(report['before'], report['after'])
            except (OSError, ValueError) as error:
                report['resource_after_error'] = str(error)
        save(output, report)
        print(json.dumps(dict(complete=report['complete'], passed=report.get('passed_disjoint_scopes'),
                              selected_only_passed=report.get('selected_only_passes'),
                              executed_disjoint_passes=report.get('executed_disjoint_passes'),
                              observed_inventory=report.get('observed_native_inventory_total'),
                              expected_count_matches=report.get('expected_native_inventory_total_matches'),
                              error=report.get('error'), output=str(output))), flush=True)


if __name__ == '__main__':
    raise SystemExit(main())
