"""Compare exact Git-tree compiler inputs with captured CI/local identities."""
import hashlib,json,re,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
ROOTS=['Cargo.toml','Cargo.lock','crates/scriptw-front','crates/scriptw-ir','crates/scriptw-aot-wasm','crates/scriptw-runtime','crates/scriptw-runtime-image','crates/scriptw-intl','crates/scriptw-intl-build-data','crates/scriptw-engine/Cargo.toml','crates/scriptw-engine/src','crates/scriptw-engine/build.rs','crates/scriptw-engine/compiler_fingerprint.rs','vendor']
def one(args):return subprocess.check_output(args,cwd=ROOT)
def fingerprint(revision,extra=False):
 source=one(['git','show',revision+':crates/scriptw-engine/compiler_fingerprint.rs']).decode()
 block=source.split('const TEST_ONLY_INPUTS: &[&str] = &[',1)[1].split('];',1)[0]
 excluded=re.findall(r'^\s*"([^"]+)",',block,re.M)
 items=[]
 for raw in one(['git','ls-tree','-r','-z',revision,'--',*ROOTS]).split(b'\0'):
  if not raw:continue
  fields,path=raw.split(b'\t',1);mode,kind,oid=fields.decode().split();path=path.decode()
  if any(path==x or path.startswith(x+'/') for x in excluded):continue
  assert kind=='blob' and mode=='100644',(mode,kind,path)
  items.append((path,oid))
 if extra:items.append(('vendor/regress-0.10.5/Cargo.lock',None))
 digest=hashlib.sha256(b'scriptw-program-cache-compiler-v3');total=0
 child=subprocess.Popen(['git','cat-file','--batch'],cwd=ROOT,stdin=subprocess.PIPE,stdout=subprocess.PIPE)
 try:
  for path,oid in sorted(items,key=lambda x:tuple(x[0].split('/'))):
   if oid is None:data=(ROOT/path).read_bytes()
   else:
    child.stdin.write((oid+'\n').encode());child.stdin.flush();header=child.stdout.readline().split();assert header[:2]==[oid.encode(),b'blob'];length=int(header[2]);data=child.stdout.read(length);assert len(data)==length and child.stdout.read(1)==b'\n'
   label=path.encode();digest.update(len(label).to_bytes(8,'little'));digest.update(label);digest.update(len(data).to_bytes(8,'little'));digest.update(data);total+=len(data)
 finally:child.stdin.close();child.stdout.close();assert child.wait()==0
 return dict(revision=one(['git','rev-parse',revision]).decode().strip(),extra_ignored_regress_lock=extra,source_fingerprint=digest.hexdigest(),files=len(items),bytes=total)

import os,sys
sys.path.insert(0,str(ROOT/'scripts'))
from limited_verification import require_kernel_budget,kernel_group
require_kernel_budget(256*1024**2);assert sorted(os.sched_getaffinity(0))==[0]
original='d6cacf8350c4a4ad660c40674cfe822f09ae56c1';repaired='18a7e16e5742f047d95bc6e49b0d2420203a5a16';probe='7b81ba6c9a6a30189acf75fed72f3f8a434d0992'
path='crates/scriptw-aot-wasm/src/runtime_artifact/cache/tests.rs'
assert one(['git','diff','--name-only',original,repaired]).decode().splitlines()==[path]
assert one(['git','diff','--numstat',original,repaired]).decode().splitlines()==['1\t0\t'+path]
owner=one(['git','show',repaired+':crates/scriptw-engine/compiler_fingerprint.rs']).decode()
assert '"'+path+'"' in owner.split('const TEST_ONLY_INPUTS: &[&str] = &[',1)[1].split('];',1)[0]
group=kernel_group()
def budget():return {k:(group/k).read_text().strip() for k in ['memory.max','memory.swap.max','memory.oom.group','memory.peak','memory.events']}
before=budget();rows=[fingerprint(r,extra) for r in [original,repaired,probe] for extra in [False,True]]
for extra,fp in [(False,'7507e0ad8a91869492bfca2dbce101c768170c718e2a04fa52c427b8b343b1c6'),(True,'032217201018870331201994438ce22f42d132256b3ecff4fcd2b8e053c9eed3')]:
 selected=[r for r in rows if r['extra_ignored_regress_lock']==extra];assert len(selected)==3 and {r['source_fingerprint'] for r in selected}=={fp};assert len({(r['files'],r['bytes']) for r in selected})==1
r=dict(original=original,repaired=repaired,probe=probe,test_only_repair=path,computed_compiler_inputs_equal=True,rows=rows,before=before,after=budget(),cpu_affinity=[0])
out=OUT/'source-bindings-repaired-local-probe.json';assert not out.exists();out.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
