import hashlib,json,os,subprocess,sys
from pathlib import Path
ROOT=Path('/home/mewhhaha/src/porffor/target/memory-calendar-rows-20261028')
BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'scripts'))
from limited_verification import kernel_group, require_kernel_budget
require_kernel_budget(1024**3)
out=BASE/'cheap-r1';out.mkdir(exist_ok=False)
def budget():
 g=kernel_group();return {k:(g/k).read_text().strip() for k in ('memory.max','memory.swap.max','memory.oom.group','memory.peak','memory.events')}
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
paths=subprocess.check_output(['git','diff','--name-only','16ede408f','--'],cwd=ROOT,text=True).splitlines()
paths+=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=ROOT,text=True).splitlines()
report=dict(complete=False,base='16ede408f',driver_sha256=sha(__file__),before=budget(),cpu_affinity=sorted(os.sched_getaffinity(0)),source_files={p:sha(ROOT/p) for p in paths},commands=[])
def save():(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
commands=[('guard-mutations',['python3','-B','-m','unittest','scripts.tests.test_maintenance_source_guards']),('rustfmt',['rustfmt','--edition','2021','--config','skip_children=true','--check',*sorted(p for p in paths if p.endswith('.rs'))]),('source-guards',['python3','-B','scripts/check-source-guards.py','--output',str(out/'guards')]),('immutable-pool',['python3','-B','scripts/check-immutable-compiler-pool.py']),('source-profile',['python3','-B','scripts/check-runtime-source-compilation-profile.py']),('identities',['python3','-B','scripts/intl_source_identities.py']),('retired-js',['bash','scripts/check-no-legacy-js.sh']),('diff',['git','diff','--check'])]
try:
 save()
 for label,cmd in commands:
  row=dict(label=label,command=cmd);report['commands'].append(row);save()
  with (out/(label+'.stdout')).open('xb') as stdout,(out/(label+'.stderr')).open('xb') as stderr:
   child=subprocess.run(cmd,cwd=ROOT,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=300)
  row.update(exit_code=child.returncode,stdout_sha256=sha(out/(label+'.stdout')),stderr_sha256=sha(out/(label+'.stderr')));save();print(label,child.returncode,flush=True)
  if child.returncode:raise RuntimeError(label+' failed; retained streams')
 report['complete']=True
except BaseException as e:
 report.update(error=str(e),error_type=type(e).__name__)
finally:
 report['after']=budget();save()
raise SystemExit(0 if report['complete'] else 1)
