CI40621647185: 68/68 scored attempts,17 workload checksums and six actual engine controls validated. Optional v2 ownership status: validated.
Exact v2 parsers are bound to feature1fd and the new producer source. Layout30 and the current R key are recorded independently; no prior-key or cross-runner native equality is asserted.
CLI example-test raw job output is unavailable; no exact CLI example pass count is claimed.

| Case | R image pages | Text pages | Nontext image pages | Mixed | Boundary | Uncovered | Header overlap | Section-table overlap |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| integer.js | 633 | 462 | 171 | 6 | 6 | 0 | 1 | 1 |
| retained-objects.js | 921 | 558 | 363 | 7 | 7 | 0 | 1 | 1 |

Retained warm after_store_drop at observation16; overlapping counts below must not be summed.

| Case | Nontext R section | Section bytes | Present-page overlaps | Full present pages |
|---|---|---:|---:|---:|
| integer.js | .wasmtime.engine | 1102 | 1 | 0 |
| integer.js | .wasmtime.bti | 1 | 1 | 0 |
| integer.js | .eh_frame | 107316 | 27 | 26 |
| integer.js | .wasmtime.addrmap | 7182992 | 7 | 6 |
| integer.js | .wasmtime.stackmap | 4294388 | 0 | 0 |
| integer.js | .wasmtime.traps | 2111940 | 0 | 0 |
| integer.js | .wasmtime.exceptions | 25544 | 6 | 5 |
| integer.js | .rodata.wasm | 2039616 | 107 | 106 |
| integer.js | .name.wasm | 38327 | 1 | 0 |
| integer.js | .wasmtime.info | 61993 | 16 | 14 |
| integer.js | .symtab | 54072 | 1 | 0 |
| integer.js | .strtab | 111597 | 9 | 8 |
| integer.js | .shstrtab | 187 | 1 | 0 |
| retained-objects.js | .wasmtime.engine | 1102 | 1 | 0 |
| retained-objects.js | .wasmtime.bti | 1 | 1 | 0 |
| retained-objects.js | .eh_frame | 107316 | 27 | 26 |
| retained-objects.js | .wasmtime.addrmap | 7182992 | 10 | 8 |
| retained-objects.js | .wasmtime.stackmap | 4294388 | 190 | 189 |
| retained-objects.js | .wasmtime.traps | 2111940 | 0 | 0 |
| retained-objects.js | .wasmtime.exceptions | 25544 | 6 | 5 |
| retained-objects.js | .rodata.wasm | 2039616 | 107 | 106 |
| retained-objects.js | .name.wasm | 38327 | 1 | 0 |
| retained-objects.js | .wasmtime.info | 61993 | 16 | 14 |
| retained-objects.js | .symtab | 54072 | 1 | 0 |
| retained-objects.js | .strtab | 111597 | 9 | 8 |
| retained-objects.js | .shstrtab | 187 | 1 | 0 |

Nontext leaders are derived per current case in next_measurement_targets; no section leader or reduction is assumed from a prior run. Inspect required data/GC metadata origins before a matched intervention; presence establishes no saving or live heap ownership and does not authorize dropping stack maps. Warm history contains16 earlier calls; no last-sample causal/bootstrap claim follows. Native payloads were not retained/executed.
