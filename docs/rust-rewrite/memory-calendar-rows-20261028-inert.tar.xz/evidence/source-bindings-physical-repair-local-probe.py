"""Compare exact Git-tree compiler inputs with captured CI/local identities."""
import hashlib,json,re,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
ROOTS=['Cargo.toml','Cargo.lock','crates/scriptw-front','crates/scriptw-ir','crates/scriptw-aot-wasm','crates/scriptw-runtime','crates/scriptw-runtime-image','crates/scriptw-intl','crates/scriptw-intl-build-data','crates/scriptw-engine/Cargo.toml','crates/scriptw-engine/src','crates/scriptw-engine/build.rs','crates/scriptw-engine/compiler_fingerprint.rs','vendor']
def one(args):return subprocess.check_output(args,cwd=ROOT)
def fingerprint(revision,extra=False):
 source=one(['git','show',revision+':crates/scriptw-engine/compiler_fingerprint.rs']).decode()
 block=source.split('const TEST_ONLY_INPUTS: &[&str] = &[',1)[1].split('];',1)[0]
 excluded=re.findall(r'^\s*"([^"]+)",',block,re.M)
 items=[]
 for raw in one(['git','ls-tree','-r','-z',revision,'--',*ROOTS]).split(b'\0'):
  if not raw:continue
  fields,path=raw.split(b'\t',1);mode,kind,oid=fields.decode().split();path=path.decode()
  if any(path==x or path.startswith(x+'/') for x in excluded):continue
  assert kind=='blob' and mode=='100644',(mode,kind,path)
  items.append((path,oid))
 if extra:items.append(('vendor/regress-0.10.5/Cargo.lock',None))
 digest=hashlib.sha256(b'scriptw-program-cache-compiler-v3');total=0
 child=subprocess.Popen(['git','cat-file','--batch'],cwd=ROOT,stdin=subprocess.PIPE,stdout=subprocess.PIPE)
 try:
  for path,oid in sorted(items,key=lambda x:tuple(x[0].split('/'))):
   if oid is None:data=(ROOT/path).read_bytes()
   else:
    child.stdin.write((oid+'\n').encode());child.stdin.flush();header=child.stdout.readline().split();assert header[:2]==[oid.encode(),b'blob'];length=int(header[2]);data=child.stdout.read(length);assert len(data)==length and child.stdout.read(1)==b'\n'
   label=path.encode();digest.update(len(label).to_bytes(8,'little'));digest.update(label);digest.update(len(data).to_bytes(8,'little'));digest.update(data);total+=len(data)
 finally:child.stdin.close();child.stdout.close();assert child.wait()==0
 return dict(revision=one(['git','rev-parse',revision]).decode().strip(),extra_ignored_regress_lock=extra,source_fingerprint=digest.hexdigest(),files=len(items),bytes=total)

import os,sys
sys.path.insert(0,str(ROOT/'scripts'))
from limited_verification import require_kernel_budget,kernel_group
require_kernel_budget(256*1024**2);assert sorted(os.sched_getaffinity(0))==[0]
original='d6cacf8350c4a4ad660c40674cfe822f09ae56c1'
repaired='18a7e16e5742f047d95bc6e49b0d2420203a5a16'
final='0a29835741bb9b1477f5946ec4ba1812c902959b'
probe='7b81ba6c9a6a30189acf75fed72f3f8a434d0992'
first='crates/scriptw-aot-wasm/src/runtime_artifact/cache/tests.rs'
second='crates/scriptw-aot-wasm/src/tests.rs'
assert one(['git','diff','--name-only',original,repaired]).decode().splitlines()==[first]
assert one(['git','diff','--name-only',repaired,final]).decode().splitlines()==[second]
owner=one(['git','show',final+':crates/scriptw-engine/compiler_fingerprint.rs']).decode()
block=owner.split('const TEST_ONLY_INPUTS: &[&str] = &[',1)[1].split('];',1)[0]
assert all('"'+path+'"' in block for path in [first,second])
previous=OUT/'source-bindings-repaired-local-probe.json'
previous_sha=hashlib.sha256(previous.read_bytes()).hexdigest()
assert previous_sha=='063f4ab84baa383ef47e32aea46716fac998c1ce7d15b9d190a7bee78bc165d5'
group=kernel_group()
def budget():return {k:(group/k).read_text().strip() for k in ['memory.max','memory.swap.max','memory.oom.group','memory.peak','memory.events']}
before=budget();r=dict(complete=False,original=original,repaired=repaired,final_local=final,probe=probe,
 test_only_repairs=[first,second],computed_compiler_inputs_equal=False,before=before,cpu_affinity=[0],
 previous_six_row_proof_sha256=previous_sha,driver_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
out=OUT/'source-bindings-physical-repair-local-probe.json';assert not out.exists()
try:
 rows=[fingerprint(rev,extra) for rev in [original,repaired,final,probe] for extra in [False,True]]
 for extra,fp in [(False,'7507e0ad8a91869492bfca2dbce101c768170c718e2a04fa52c427b8b343b1c6'),(True,'032217201018870331201994438ce22f42d132256b3ecff4fcd2b8e053c9eed3')]:
  selected=[row for row in rows if row['extra_ignored_regress_lock']==extra]
  assert len(selected)==4 and {row['source_fingerprint'] for row in selected}=={fp}
  assert len({(row['files'],row['bytes']) for row in selected})==1
 previous_rows=json.loads(previous.read_text())['rows']
 assert all(row in rows for row in previous_rows)
 after=budget();events=[dict(line.split() for line in sample['memory.events'].splitlines()) for sample in [before,after]]
 assert all(events[0][key]==events[1][key]=='0' for key in ['oom','oom_kill','oom_group_kill'])
 r.update(complete=True,computed_compiler_inputs_equal=True,rows=rows,after=after)
except BaseException as error:
 r.update(error=repr(error),error_type=type(error).__name__,after=budget());raise
finally:
 with out.open('x') as stream:json.dump(r,stream,indent=2);stream.write('\n')
print(json.dumps(dict(complete=True,rows=len(rows),output=str(out))))
