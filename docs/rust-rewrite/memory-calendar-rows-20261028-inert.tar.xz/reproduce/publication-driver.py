"""Private calendar-row candidate. Run only after the native r2 closure exists."""
from datetime import datetime,timezone
import hashlib
import json
import lzma
import os
from pathlib import Path
import re
import stat
import subprocess
import sys
import tarfile

BASE=Path(__file__).resolve().parent
ROOT=BASE.parents[1]
SOURCE='0a29835741bb9b1477f5946ec4ba1812c902959b'
FEATURE='d6cacf8350c4a4ad660c40674cfe822f09ae56c1'
MEASURED='7b81ba6c9a6a30189acf75fed72f3f8a434d0992'
FP='7507e0ad8a91869492bfca2dbce101c768170c718e2a04fa52c427b8b343b1c6'
LOCAL_FP='032217201018870331201994438ce22f42d132256b3ecff4fcd2b8e053c9eed3'
NATIVE=BASE/'native-0a2983574'
CI=BASE/'ci-40621647185-validated'
SCORED=BASE/'github-40621647185-scored/precompiled-evidence'
PROOF=BASE/'source-bindings-physical-repair-local-probe.json'
PROOF_SHA='c0664d1167606e5b4018e1ec5017ef25e0e10baee33f3a870bd3f669810756a8'
CI_SHA='cfdc7c0980f96e8c222f68f290118bf463ae0d86bbeb5115a1e071f5d513bf5e'
OUT=BASE/'publication-candidate-0a2983574'
STEM='memory-calendar-rows-20261028'
MAX_MEMBER,MAX_COMPRESSED=64*1024**2,64*1024**2
sys.path.insert(0,str(ROOT/'scripts'))
import precompiled_comparison as p
from limited_verification import require_kernel_budget,kernel_group
from native_test_protocol import parse_inventory,result_summaries


def sha(path):
    with Path(path).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()


def read(path):
    path=Path(path);assert not path.is_symlink() and stat.S_ISREG(path.lstat().st_mode) and path.stat().st_size<=MAX_MEMBER
    return json.loads(path.read_text())


def root_state():
    assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=ROOT)
    return subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()


def budget(group):
    return {key:(group/key).read_text().strip() for key in ('memory.max','memory.swap.max','memory.oom.group','memory.peak','memory.events')}


def resources(value,maximum=4*1024**3):
    assert value['cpu_affinity']==[0]
    for row in (value['before'],value['after']):
        assert 0<int(row['memory.max'])<=maximum and row['memory.swap.max']=='0' and row['memory.oom.group']=='1'
    counters=[dict(line.split() for line in row['memory.events'].splitlines()) for row in (value['before'],value['after'])]
    assert all(counters[0][key]==counters[1][key]=='0' for key in ('oom','oom_kill','oom_group_kill'))


def streams(directory,commands,allow_failure=False):
    for command in commands:
        assert command.get('exit_code',0)==0 or allow_failure
        assert not command.get('timed_out') and not command.get('output_limit_exceeded') and not command.get('pipe_cleanup_incomplete')
        for channel in ('stdout','stderr'):
            name=command.get(channel,command['label']+'.'+channel)
            assert p.safe_name(name)==command['label']+'.'+channel
            path=directory/name
            assert path.stat().st_size<=MAX_MEMBER and sha(path)==command[channel+'_sha256']
            if channel+'_bytes' in command:assert path.stat().st_size==command[channel+'_bytes']


def native_admission(native):
    assert native['complete'] is True and native['source_commit']==SOURCE and native['features']==[]
    assert native['passed_disjoint_scopes']==1763 and native['selected_only_passes']==3 and native['covered_disjoint_passes']==1766
    assert native['full_engine_lib_coverage_claimed'] is False and len(native['scopes'])==9 and len(native['selected_scopes'])==1
    assert native['repeated_native_test_ids']==0 and native['production_equivalence']['sha256']==PROOF_SHA
    assert sha(Path(native['production_equivalence']['path']))==PROOF_SHA
    resources(native);streams(NATIVE,native['commands'])
    all_scopes=[*native['scopes'],*native['selected_scopes']]
    by_binary={str(NATIVE/scope['binary']):scope for scope in all_scopes}
    fresh={scope['binary']:[] for scope in all_scopes}
    for command in native['commands']:
        if 'expected_test_ids' not in command:continue
        scope=by_binary[command['command'][0]]
        text=(NATIVE/command['stdout']).read_text()
        names=[name.removesuffix(' - should panic') for name in re.findall(r'^test ([^\r\n]+) \.\.\. ok$',text,re.M)]
        expected=command['expected_test_ids']
        assert len(names)==len(set(names))==len(expected) and set(names)==set(expected)
        assert result_summaries(text)==[('ok',str(len(expected)),'0','0','0',str(len(scope['inventory'])-len(expected)))]
        assert not set(names).intersection(fresh[scope['binary']]);fresh[scope['binary']]+=names
    imports=native['imported_completed_ids'];assert len(imports)==native['inherited_disjoint_passes']
    assert len(imports) in (0,5) and bool(imports)==native['retention_admission']['group_admitted']
    for scope in all_scopes:
        key=(scope['package'],scope['target'],scope['kind'])
        label=scope['package']+'-'+scope['target']
        assert parse_inventory((NATIVE/(label+'-inventory.stdout')).read_text())==scope['inventory']
        retained=[row['test_id'] for row in imports if (row['package'],row['target'],row['kind'])==key]
        assert not set(retained).intersection(fresh[scope['binary']])
        covered=fresh[scope['binary']]+retained
        expected=scope['selected_test_ids'] if 'selected_test_ids' in scope else scope['inventory']
        assert len(covered)==len(set(covered))==scope['passed'] and set(covered)==set(expected)==set(scope['passed_test_ids'])
        if 'selected_test_ids' in scope:assert scope['selected_complete'] is True and scope['full_target_coverage_claimed'] is False
        else:assert scope['complete'] is True
    fresh_count=sum(len(ids) for ids in fresh.values())
    assert fresh_count==native['executed_disjoint_passes'] and fresh_count+len(imports)==1766
    aot=next(scope for scope in native['scopes'] if scope['target']=='scriptw_aot_wasm')
    assert len(aot['inventory'])==512 and len(fresh[aot['binary']])==512 and not any(row['target']=='scriptw_aot_wasm' for row in imports)
    return dict(full_scope_passes=1763,full_scopes=9,selected_engine_passes=3,covered_qualified_ids=1766,
        freshly_executed=fresh_count,retained_passes=len(imports),full_engine_lib_claimed=False,
        aot_library_fresh_passes=512,original_js_executions=0,inherited_js_executions=0)


def archive(files,bound):
    expanded=sum(row['bytes'] for row in files.values());assert expanded<=bound and len(files)<=4096
    path=OUT/(STEM+'-inert.tar.xz')
    with path.open('xb') as raw,lzma.LZMAFile(raw,'w',filters=[dict(id=lzma.FILTER_LZMA2,preset=1,dict_size=16*1024**2)]) as compressed:
        with tarfile.open(fileobj=compressed,mode='w|') as bundle:
            for name,row in sorted(files.items()):
                member=tarfile.TarInfo(name);member.size=row['bytes'];member.mode=0o644
                with row['source'].open('rb') as stream:bundle.addfile(member,stream)
    assert path.stat().st_size<=MAX_COMPRESSED
    seen,total=set(),0
    with tarfile.open(path,'r|xz') as bundle:
        for member in bundle:
            assert member.isfile() and member.name in files and member.name not in seen
            row=files[member.name];assert member.size==row['bytes']<=MAX_MEMBER
            total+=member.size;assert total<=bound
            with bundle.extractfile(member) as stream:assert hashlib.file_digest(stream,'sha256').hexdigest()==row['sha256']
            seen.add(member.name)
    assert seen==set(files) and total==expanded
    return dict(file=path.name,sha256=sha(path),bytes=path.stat().st_size,expanded_bytes=expanded,member_count=len(files),
        max_member_bytes=MAX_MEMBER,max_expanded_bytes=bound,max_compressed_bytes=MAX_COMPRESSED,
        roundtrip_sha256_verified=True,roundtrip_passes=1,native_payloads_retained=False,
        members=[dict(path=name,bytes=row['bytes'],sha256=row['sha256']) for name,row in sorted(files.items())])


def main():
    require_kernel_budget(1024**3)
    assert sorted(os.sched_getaffinity(0))==[0] and not OUT.exists()
    # This is the terminal gate; an active or incomplete native run cannot
    # create a candidate, even if its currently observed commands have passed.
    native=read(NATIVE/'report.json');assert native['complete'] is True
    native_sha=sha(NATIVE/'report.json');root_before=root_state();group=kernel_group();OUT.mkdir()
    processing=dict(complete=False,started_at=datetime.now(timezone.utc).isoformat(),cpu_affinity=[0],before=budget(group),
        driver=dict(path=str(Path(__file__).resolve()),sha256=sha(Path(__file__))),processing_checkout=root_before,
        scope='Private inert publication candidate only; no source, README, graph, shared build or workload change.')
    try:
        coverage=native_admission(native)
        assert sha(CI/'report.json')==CI_SHA and sha(PROOF)==PROOF_SHA
        ci=read(CI/'report.json');proof=read(PROOF)
        assert ci['complete'] is True and ci['source_commit']==MEASURED and ci['source_fingerprint']==FP
        assert ci['diagnostic']['status']=='validated' and ci['native_controls']['passed']==6
        assert proof['complete'] is True and proof['computed_compiler_inputs_equal'] is True and len(proof['rows'])==8
        for revision in (FEATURE,'18a7e16e5742f047d95bc6e49b0d2420203a5a16',SOURCE,MEASURED):
            for ignored,fp in ((False,FP),(True,LOCAL_FP)):
                rows=[row for row in proof['rows'] if row['revision']==revision and row['extra_ignored_regress_lock'] is ignored]
                assert len(rows)==1 and rows[0]['source_fingerprint']==fp
        campaign,table=p.load_report(SCORED/'report.json')
        assert campaign['source_commit']==MEASURED and campaign['source_fingerprint']==FP and table==ci['scored_table']
        assert len(campaign['attempts'])==68 and len(table)==17 and all(row['status']=='ok' for row in campaign['attempts'])
        score=read(BASE/'score-40621647185.json')
        assert score['complete'] is True and score['report_sha256']==sha(SCORED/'report.json')
        assert score['source_commit']==MEASURED and score['source_fingerprint']==FP
        for name,selected in score['selected'].items():
            canonical=next(row for row in table if row['file']==name)
            for runtime,metrics in selected.items():
                assert all(metrics[field]==canonical['runtimes'][runtime][field] for field in ('ms','rss_mib'))
        ratios=[row['runtimes']['scriptw']['rss_mib']/row['runtimes']['scriptc']['rss_mib'] for row in table]
        assert score['rss_ratio_range']==[min(ratios),max(ratios)]
        cheap=read(BASE/'cheap-r1/report.json');assert cheap['complete'] is True;resources(cheap,1024**3)
        streams(BASE/'cheap-r1',cheap['commands'])
        mutation=(BASE/'cheap-r1/guard-mutations.stderr').read_text()
        assert re.findall(r'Ran (\d+) tests?',mutation)==['15'] and re.search(r'^OK$',mutation,re.M)
        counts=result_summaries((BASE/'cheap-r1/source-guards.stdout').read_text())
        assert [(row[0],row[1],row[2],row[3]) for row in counts]==[('ok','143','0','0'),('ok','135','0','0')]
        identity_lines=(BASE/'cheap-r1/identities.stdout').read_text().splitlines()
        assert len(identity_lines)==15 and all(line.startswith('PASS ') for line in identity_lines)
        first=read(BASE/'native-d6cacf835/report.json');stale=read(BASE/'native-18a7e16e5/report.json')
        assert first['complete'] is False and first['source_commit']==FEATURE and not first['scopes'] and len(first['commands'])==1
        assert first['commands'][0]['exit_code']==101
        assert stale['complete'] is False and stale['source_commit']=='18a7e16e5742f047d95bc6e49b0d2420203a5a16'
        resources(first);resources(stale);streams(BASE/'native-d6cacf835',first['commands'],True);streams(BASE/'native-18a7e16e5',stale['commands'],True)
        failed=next(row for row in stale['commands'] if row['exit_code']!=0)
        assert result_summaries((BASE/'native-18a7e16e5'/failed['stdout']).read_text())==[('FAILED','505','2','0','0','5')]
        files,excluded={},[]
        def add(name,path,expected=None):
            path=Path(path);assert name not in files and not name.startswith('/') and '..' not in Path(name).parts
            assert not path.is_symlink() and stat.S_ISREG(path.lstat().st_mode)
            with path.open('rb') as stream:magic=stream.read(8)
            if magic.startswith((b'\x7fELF',b'MZ',b'SWRTZ001',b'SCRWRB',b'SCRWEP',b'SCRWWA',b'SCRWNR')):
                excluded.append(dict(path=name,bytes=path.stat().st_size,reason='native executable or packed runtime payload'));return
            assert path.stat().st_size<=MAX_MEMBER
            row=dict(source=path,bytes=path.stat().st_size,sha256=sha(path))
            if expected is not None:assert (row['bytes'],row['sha256'])==(expected['bytes'],expected['sha256'])
            files[name]=row
        for directory in (BASE/'native-d6cacf835',BASE/'native-18a7e16e5',NATIVE,BASE/'cheap',BASE/'cheap-r1'):
            for path in sorted(directory.rglob('*')):
                if path.is_file():add(directory.name+'/'+path.relative_to(directory).as_posix(),path)
        for name,expected in ci['inputs'].items():
            path=Path(name)
            alias='evidence/'+path.relative_to(BASE).as_posix() if path.is_relative_to(BASE) else 'reproduce/'+path.relative_to(ROOT).as_posix()
            add(alias,path,expected)
        for name in ('ci-40621647185-validated/report.json','ci-40621647185-validated/summary.md',
            'ci-40621647185-validated/runtime-artifact-layout-source.rs','validate-ci-40621647185-final-reviewed.py',
            'validate-ci-40621647185.stdout','validate-ci-40621647185.stderr','score-40621647185.json','process-score-40621647185.py',
            'source-bindings-physical-repair-local-probe.json','source-bindings-physical-repair-local-probe.py',
            'source-bindings-physical-repair-local-probe.stdout','source-bindings-physical-repair-local-probe.stderr',
            'source-bindings-repaired-local-probe.json','source-bindings-repaired-local-probe.py','source-bindings-feature-probe.json','source-bindings.py',
            'native-reviewed-calendar-rows.py','native-reviewed-calendar-rows-r1.py','native-reviewed-calendar-rows-r2.py',
            'native-d6cacf835-launch.json','native-18a7e16e5-launch.json','native-0a2983574-launch.json',
            'cheap.py','cheap-r1.py','github-artifacts-40621647185-check01.stdout',
            'download-ci-40621647185-scored.stdout','download-ci-40621647185-scored.stderr',
            'download-ci-40621647185-diagnostic.stdout','download-ci-40621647185-diagnostic.stderr'):
            alias='evidence/'+name
            if alias not in files:add(alias,BASE/name)
        pattern=ROOT/'target/memory-module-ownership-20261027-evidence/validate-ci-40594118953.py'
        assert sha(pattern)==ci['reused_validator_sha256'];add('reproduce/ownership-validator-pattern.py',pattern)
        add('reproduce/publication-driver.py',Path(__file__).resolve())
        for name in ('limited_verification.py','native_test_protocol.py'):add('reproduce/scripts/'+name,ROOT/'scripts'/name)
        previous=ROOT/'docs/rust-rewrite/memory-module-sections-20261028.json'
        reference=dict(file=previous.name,sha256=sha(previous),inherited_executions=0)
        add('reference/'+previous.name,previous)
        expanded=sum(row['bytes'] for row in files.values())
        bound=256*1024**2 if expanded<=256*1024**2 else 512*1024**2
        assert expanded<=bound
        large=[dict(path=name,bytes=row['bytes']) for name,row in files.items() if row['bytes']>32*1024**2]
        retained=archive(files,bound)
        retained['bound_reason']='Actual retained text/metadata totals '+str(expanded)+' bytes; native payloads excluded. The principal large members are the three distinct Cargo logs and current scored Cargo log.'
        retained['large_text_members']=large
        assert sha(NATIVE/'report.json')==native_sha and sha(CI/'report.json')==CI_SHA and sha(PROOF)==PROOF_SHA
        assert all(sha(row['source'])==row['sha256'] for row in files.values()) and root_state()==root_before
        after=budget(group);resources(dict(cpu_affinity=[0],before=processing['before'],after=after),1024**3)
        processing.update(complete=True,after=after,finished_at=datetime.now(timezone.utc).isoformat(),excluded_payloads=excluded)
        document=dict(schema='scriptw-calendar-rows-evidence-v1',recorded_at=datetime.now(timezone.utc).isoformat(),
            verified_source_commit=SOURCE,compiler_feature_source_commit=FEATURE,measured_source_commit=MEASURED,runtime_layout=30,
            source_bindings=dict(proof_sha256=PROOF_SHA,clean_fingerprint=FP,local_fingerprint=LOCAL_FP,rows=proof['rows']),
            native=dict(report_sha256=native_sha,coverage=coverage,retention_admission=native['retention_admission'],
                interpretation='Nine complete affected scopes plus three selected engine controls. No full engine-library, original JS/Test262 or inherited execution claim.'),
            cheap_checkpoint=dict(report_sha256=sha(BASE/'cheap-r1/report.json'),rust_source_guard_controls=278,guard_mutation_tests=15,
                current_intl_identities=15,scope='Completed pre-build checkpoint on the feature batch. The two later unit-only repairs are bound by production equivalence and the complete fresh AOT512 native run.'),
            verification_only_repairs=[dict(source='18a7e16e5742f047d95bc6e49b0d2420203a5a16',file='crates/scriptw-aot-wasm/src/runtime_artifact/cache/tests.rs',
                    reason='Use the data-section iterator in the new cache test; initial Rust test compilation failed before any native test executed.'),
                dict(source=SOURCE,file='crates/scriptw-aot-wasm/src/tests.rs',reason='Update stale physical-layout test helpers from six to eight segments while preserving byte-offset checks. The old505 passing results are not credited; all512 AOT IDs ran freshly.')],
            failure_lineage=dict(first_compile=dict(report_sha256=sha(BASE/'native-d6cacf835/report.json'),complete=False,native_tests_executed=0,error=first['error']),
                stale_layout=dict(report_sha256=sha(BASE/'native-18a7e16e5/report.json'),complete=False,old_broad_passes_not_credited=505,stale_test_assertions=2,error=stale['error'])),
            measurement=dict(run=40621647185,validated_report_sha256=CI_SHA,scored_report_sha256=sha(SCORED/'report.json'),attempts=68,workloads=17,
                all_attempts_ok=True,rss_ratio_min=min(ratios),rss_ratio_max=max(ratios),selected=score['selected'],table=table),
            runtime_identity=ci['runtime_identity'],runtime_sections=ci['runtime_sections'],next_measurement_targets=ci['next_measurement_targets'],
            cold_data_accounting=dict(previous_active_bytes=366448,current_active_bytes=232736,deferred_calendar_bytes=133712,
                interpretation='Sealed static data-segment accounting for the declared change. The exact133712-byte span/no-active-intersection is checked by the source-bound emission and native controls. This is copied-byte accounting, not a causal RSS or live-heap claim.'),
            resource_origins=dict(initial_cheap=dict(before=read(BASE/'cheap/report.json')['before'],after=read(BASE/'cheap/report.json')['after'],complete=False),
                cheap=dict(before=cheap['before'],after=cheap['after']),first_compile=dict(before=first['before'],after=first['after'],complete=False),
                stale_layout=dict(before=stale['before'],after=stale['after'],complete=False),native_r2=dict(before=native['before'],after=native['after']),
                ci_validation=dict(before=ci['before'],after=ci['after'])),
            prior_checkpoint=reference,archive=retained,publication_processing=processing,
            interpretation='The changed R/layout30 has no prior-key or cross-runner native-byte equality assumption. All current native and CI results are scope-specific. No overall causal RSS/speed saving, parity, full ECMAScript/Test262 or goal-completion claim is established. Warm captures follow16 prior calls; section overlaps are nonadditive. README, graphs, V8/status and main remain unchanged by this candidate processor.')
        lines=['# Lazy retained calendar rows','',
            'Verified source `'+SOURCE+'` has 1763 passes across nine affected full native scopes plus three selected engine controls: '+str(coverage['freshly_executed'])+' fresh executions and '+str(coverage['retained_passes'])+' byte/source-bound retained passes. The full engine library and original JS/Test262 executions are not claimed.','',
            'The whole changed AOT library passed 512 freshly, including the five focused controls. Earlier Rust test compilation and two stale physical-layout assertions were repaired only in excluded test files; their raw failures/counters remain preserved, and the old 505 broad passes receive no credit. Cheap validation records 278 Rust source controls, 15 guard-mutation tests and 15 current Intl identities.','',
            'CI40621647185 (`'+MEASURED+'`) passes 68/68 attempts across 17 workload checksums. Current Scriptw/Scriptc RSS ratios are '+format(min(ratios),'.9f')+'–'+format(max(ratios),'.9f')+'. Integer is '+format(score['selected']['integer.js']['scriptw']['rss_mib'],'.3f')+'/'+format(score['selected']['integer.js']['scriptc']['rss_mib'],'.3f')+' MiB and retained objects '+format(score['selected']['retained-objects.js']['scriptw']['rss_mib'],'.3f')+'/'+format(score['selected']['retained-objects.js']['scriptc']['rss_mib'],'.3f')+' MiB. No overall causal RSS saving is established. V8/status remain separate.','',
            'The change defers 133712 exact calendar-row bytes: cold active data accounting changes 366448→232736 bytes. A readiness bit belongs to each R instance; retained readers initialize once after their range guard. Outside-range calculations keep their existing path. This copied-byte reduction does not establish a heap or RSS reduction.','',
            '| Current retained warm case | R image pages | Text | Nontext image pages | .rodata.wasm overlaps/full |',
            '|---|---:|---:|---:|---:|']
        for case in ci['runtime_sections']:
            warm=case['phases'][-1];ro=next(row for row in warm['nontext_sections'] if row['name']=='.rodata.wasm')
            lines.append('| '+case['file']+' | '+str(warm['image_present_pages'])+' | '+str(warm['text_present_pages'])+' | '+str(warm['nontext_image_present_pages'])+' | '+str(ro['present_page_overlaps'])+'/'+str(ro['full_present_pages'])+' |')
        lines+=['','Warm observation16 follows 16 prior calls. Section/page overlaps are nonadditive; presence does not prove execution. Layout30 has a new runtime key, with no prior-runtime or cross-runner native equality claim.','',
            'The bounded inert archive preserves native inventories/results, both failure prefixes, cheap controls, current scored/unscored observations, exact parsers, source-equivalence proofs and drivers. Native executables and runtime packages are excluded. README, graphs and main are not changed by candidate generation.']
        (OUT/(STEM+'.json')).write_text(json.dumps(document,indent=2)+'\n')
        (OUT/(STEM+'.md')).write_text('\n'.join(lines)+'\n')
    except BaseException as error:
        processing.update(complete=False,error=repr(error),error_type=type(error).__name__,after=budget(group),finished_at=datetime.now(timezone.utc).isoformat());raise
    finally:(OUT/'processing.json').write_text(json.dumps(processing,indent=2)+'\n')
    print(json.dumps(dict(complete=True,output=str(OUT),native_report_sha256=native_sha,coverage=coverage,archive_sha256=retained['sha256'],expanded_bytes=retained['expanded_bytes'])))


if __name__=='__main__':main()
