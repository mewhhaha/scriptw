import pathlib,subprocess,sys
root=pathlib.Path(__file__).resolve().parent
if len(sys.argv)>1:
 root=root/sys.argv[1];root.mkdir(exist_ok=True)
command=['cargo','build','--locked','--release','--jobs','1','-p','scriptw-cli','--bin','scriptw','--example','runtime_baseline','--example','runtime_boundaries','--message-format=json']
with (root/'cargo-product.jsonl').open('wb') as out,(root/'cargo-product.stderr').open('wb') as err:
 result=subprocess.run(command,stdout=out,stderr=err)
print((root/'cargo-product.stderr').read_text()[-3000:],flush=True)
sys.exit(result.returncode)
