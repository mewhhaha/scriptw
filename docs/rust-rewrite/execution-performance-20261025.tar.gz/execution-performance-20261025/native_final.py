import collections, hashlib, json, pathlib, re, subprocess, sys
root=pathlib.Path(__file__).resolve().parent
source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
historical=json.loads(pathlib.Path('docs/rust-rewrite/foreign-modules-20261024.json').read_text())
commands=[item['command'] for item in historical['native']['broad']['commands'] if '--list' not in item['command']]
scopes=[]
groups=collections.OrderedDict()
for command in commands:
 package=command[command.index('-p')+1]
 kind=next(flag for flag in ['--lib','--test','--example'] if flag in command)
 name=None if kind=='--lib' else command[command.index(kind)+1]
 scope={'package':package,'kind':kind,'name':name}
 scopes.append(scope)
 groups.setdefault(package,[]).append(scope)
(root/'native-scopes.json').write_text(json.dumps(scopes,indent=2)+'\n')
def check(label,command):
 code=subprocess.call([sys.executable,'-B',str(root/'run_check.py'),label,*command])
 if code: sys.exit(code)
 return json.loads((root/(label+'.json')).read_text())
for package,items in groups.items():
 command=['cargo','test','--locked','--release','--jobs','1','-p',package,'--no-run']
 for item in items:
  command.append(item['kind'])
  if item['name']: command.append(item['name'])
 label='frozen-build-'+package
 receipt=root/(label+'.json')
 if receipt.exists():
  previous=json.loads(receipt.read_text())
  if previous.get('source_head')==source and previous['exit_code']==0 and previous['command']==command: continue
  label='frozen-build-final-'+package
 check(label,command)
closed=[]
for index,item in enumerate(scopes):
 target=item['name'] or 'lib'
 label=f'broad-{index:02d}-{item["package"]}-{target}'
 if item['package']=='scriptw-engine' and item['kind']=='--lib':
  result=json.loads((root/'engine-accepted.json').read_text())
  if not result['complete'] or result['source_head']!=source or len(result['inventory'])!=1029: raise RuntimeError('incomplete engine split')
  closed.append(result)
  (root/'native-closed.json').write_text(json.dumps({'source':source,'complete':len(closed)==len(scopes),'total':sum(len(row['inventory']) for row in closed),'targets':closed},indent=2)+'\n')
  continue
 command=['cargo','test','--locked','--release','--jobs','1','-p',item['package'],item['kind']]
 if item['name']: command.append(item['name'])
 if not (root/(label+'-inventory.json')).exists(): check(label+'-inventory',command+['--','--list','--include-ignored'])
 inventory=sorted(re.findall(r'^([^\s]+): test$',(root/(label+'-inventory.log')).read_text(),re.M))
 expected=command+['--','--test-threads=1','--include-ignored']
 if (root/(label+'.json')).exists():
  result=json.loads((root/(label+'.json')).read_text())
  if result.get('source_head')!=source or result['command']!=expected or result['exit_code']!=0 or result['log_sha256']!=hashlib.sha256((root/(label+'.log')).read_bytes()).hexdigest(): raise RuntimeError('incompatible completed receipt '+label)
 else: result=check(label,expected)
 transcript=(root/(label+'.log')).read_text()
 observed=[(name.removesuffix(' - should panic'),status) for name,status in re.findall(r'^test (.+) \.\.\. (ok|FAILED|ignored)$',transcript,re.M)]
 if sorted(name for name,status in observed)!=inventory or any(status!='ok' for _,status in observed):
  raise RuntimeError('complete exact inventory did not pass: '+label)
 result.update(item,inventory=inventory,inventory_sha256=hashlib.sha256(('\n'.join(inventory)+'\n').encode()).hexdigest())
 closed.append(result)
 (root/'native-closed.json').write_text(json.dumps({'source':source,'complete':len(closed)==len(scopes),'total':sum(len(row['inventory']) for row in closed),'targets':closed},indent=2)+'\n')
print('ALL BROAD NATIVE TARGETS PASSED; RUN PRODUCT EXAMPLES AFTER FINAL RELEASE BUILD',flush=True)
