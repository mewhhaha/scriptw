import collections, hashlib, json, pathlib, re, subprocess, sys
root=pathlib.Path(__file__).resolve().parent
source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
historical=json.loads(pathlib.Path('docs/rust-rewrite/foreign-modules-20261024.json').read_text())
commands=[item['command'] for item in historical['native']['broad']['commands'] if '--list' not in item['command']]
scopes=[]
groups=collections.OrderedDict()
for command in commands:
 package=command[command.index('-p')+1]
 kind=next(flag for flag in ['--lib','--test','--example'] if flag in command)
 name=None if kind=='--lib' else command[command.index(kind)+1]
 scope={'package':package,'kind':kind,'name':name}
 scopes.append(scope)
 groups.setdefault(package,[]).append(scope)
(root/'native-scopes.json').write_text(json.dumps(scopes,indent=2)+'\n')
def check(label,command):
 code=subprocess.call([sys.executable,'-B',str(root/'run_check.py'),label,*command])
 if code: sys.exit(code)
 return json.loads((root/(label+'.json')).read_text())
for package,items in groups.items():
 command=['cargo','test','--locked','--release','--jobs','1','-p',package,'--no-run']
 for item in items:
  command.append(item['kind'])
  if item['name']: command.append(item['name'])
 label='frozen-build-'+package
 receipt=root/(label+'.json')
 if receipt.exists():
  previous=json.loads(receipt.read_text())
  if previous.get('source_head')==source and previous['exit_code']==0 and previous['command']==command: continue
  label='frozen-build-final-'+package
 check(label,command)
