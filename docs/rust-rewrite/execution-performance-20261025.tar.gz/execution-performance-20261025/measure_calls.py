#!/usr/bin/env python3
"""Separate transformed-source, existing-Realm hotpath call cohort.

No product source changes. The original IIFE body becomes batch(seed); its one
final print expression becomes the return expression. Inputs remain unchanged,
including original String(checksum) expressions. The exact decimal result is
checked outside every call span. This is not the ordinary fresh-Realm cohort.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import sys

BASE = Path(__file__).resolve().parent
REPO = BASE.parent.parent
sys.path.insert(0, str(REPO / "scripts"))
from benchmark_boundaries import validate_cache_identity, validate_child, require
from benchmark_metrics import digest, measure_process
from boundary_corpus import call_program, GUEST_WARMUPS
from boundary_process import measure_ready_process, validate_ready
from limited_verification import require_kernel_budget, limited_environment

FIXTURES = REPO / "crates/scriptw-cli/tests/fixtures/v8_execution_hotpaths"
SAMPLES = 7
HARNESS = [
    "scripts/boundary_corpus.py", "scripts/boundary_node.cjs",
    "scripts/benchmark_boundaries.py", "scripts/benchmark_metrics.py",
    "scripts/boundary_process.py", "scripts/limited_verification.py",
    "scripts/resource_numbers.py",
]


def stamp():
    return datetime.now(timezone.utc).isoformat()


def transformed_cases():
    """Pure, strict transformation of the17 admitted checked source fixtures."""
    plan = json.loads((FIXTURES / "manifest.json").read_text())["execution"]
    require(len(plan) == len({case["file"] for case in plan}) == 17, "need exact17-case manifest")
    result = []
    for case in plan:
        original = (FIXTURES / case["file"]).read_text()
        match = re.fullmatch(r"\s*(?://[^\n]*\n)*\(function workload\(\)\s*\{(.*)\}\)\(\);\s*", original, re.S)
        require(match is not None, "fixture is not one admitted workload IIFE: " + case["file"])
        body = match[1]
        require(len(re.findall(r"\bprint\s*\(", body)) == 1, "fixture must have exactly one print")
        final = re.search(r"\bprint\((.*)\);\s*\Z", body, re.S)
        require(final is not None, "fixture print must be the final statement")
        expected = re.fullmatch(r"(-?(?:0|[1-9][0-9]*))\n", case["stdout"])
        require(expected is not None, "fixture oracle must be exact decimal text")
        transformed = body[:final.start()] + "return (" + final[1] + ");\n"
        prefix = "(function () {\nfunction batch(seed) {\n" + transformed + "}\n"
        source, stdout = call_program(prefix, SAMPLES, lambda seed, call: expected[1])
        result.append({
            "file": case["file"], "work": case["work"],
            "original_source_sha256": digest(FIXTURES / case["file"]),
            "source": source, "source_sha256": hashlib.sha256(source.encode()).hexdigest(),
            "expected_numeric_text": expected[1], "expected_stdout": stdout,
            "expected_stdout_sha256": hashlib.sha256(stdout.encode()).hexdigest(),
        })
    return result


def run(args):
    require_kernel_budget(4 * 1024**3)
    require(len(os.sched_getaffinity(0)) == 1, "one inherited CPU required")
    require(GUEST_WARMUPS == 10, "guest warmup protocol changed")
    environment = limited_environment()
    for name in ["SCRIPTW_BOUNDARY_READY_FD", "SCRIPTW_BOUNDARY_READY_NONCE",
                 "SCRIPTW_WASM_TRACE", "SCRIPTW_ROW_PERF_CONTROL"]:
        require(not environment.get(name), "unset unrelated instrumentation: " + name)
    environment.pop("NODE_OPTIONS", None)
    environment.pop("NODE_COMPILE_CACHE", None)
    environment["NODE_DISABLE_COMPILE_CACHE"] = "1"
    environment["SCRIPTW_COMPILER_CACHE_IMAGE_HASH"] = "sha256"
    product = BASE / args.product
    runner = product / "runtime_boundaries"
    require(runner.is_file(), "frozen runtime_boundaries binary required")
    identity = json.loads((product / "identity.json").read_text())
    node = Path(shutil.which("node") or "/missing-node").resolve()
    time_binary = Path(shutil.which("gtime") or shutil.which("time") or "/missing-time").resolve()
    require(node.is_file() and time_binary.is_file(), "Node and GNUtime required")
    output = BASE / args.label
    output.mkdir(exist_ok=False)
    for name in HARNESS:
        destination = output / "harness" / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(REPO / name, destination)
    helper = output / "harness/scripts/boundary_node.cjs"
    environment["SCRIPTW_CACHE_DIR"] = str(output / "native-cache")
    report = {
        "schema": "scriptw-execution-same-realm-round-v1", "complete": False,
        "product": args.product, "label": args.label, "started_at": stamp(),
        "compiler_identity": identity, "runtime_boundaries_sha256": digest(runner),
        "samples": SAMPLES, "guest_warmups": GUEST_WARMUPS,
        "affinity": sorted(os.sched_getaffinity(0)), "loadavg_start": list(os.getloadavg()),
        "source_transform": "Original workload IIFE body becomes batch(seed), final print(expression) becomes return(expression); unchanged inputs, unused seed; original String(checksum) expressions retained. Exact numeric output text is checked outside call spans.",
        "boundary": "One initialized Realm per runtime/process/session; ten guest warmups then seven callback-exit-to-callback-entry call spans. Construction and checksum calculation stay inside each batch. Setup/bootstrap, checksum printing, raw-bundle/cache admission and native compilation stay outside spans. No empty-program subtraction.",
        "ambient_load": "Shared host with observed unrelated CPU/desktop activity; loadavg retained. Descriptive evidence, not idle-machine repeatability, significance, causal or V8 parity certification.",
        "binaries": {"wasmtime": {"path": str(runner), "sha256": digest(runner)},
                     "v8": {"path": str(node), "sha256": digest(node)},
                     "accounting": {"path": str(time_binary), "sha256": digest(time_binary)}},
        "harness_sha256": {name: digest(output / "harness" / name) for name in HARNESS},
        "manifest_sha256": digest(FIXTURES / "manifest.json"), "commands": [], "cases": [],
    }

    def save():
        pending = output / "report.pending"
        pending.write_text(json.dumps(report, indent=2) + "\n")
        pending.replace(output / "report.json")

    def invoke(label, runtime, command, expected_sha=None):
        require(digest(report["binaries"][runtime]["path"]) == report["binaries"][runtime]["sha256"],
                "frozen runtime executable changed")
        item = {"label": label, "runtime": runtime, "command": list(map(str, command)),
                "cwd": str(REPO), "started_at": stamp(), "state": "running",
                "stdout_file": label + ".stdout", "stderr_file": label + ".stderr"}
        report["commands"].append(item)
        save()
        with (output / item["stdout_file"]).open("xb") as stdout, (output / item["stderr_file"]).open("xb") as stderr:
            measure = measure_process if expected_sha is None else measure_ready_process
            accounting = measure(command, cwd=REPO, env=environment, stdout=stdout,
                                 stderr=stderr, timeout=900, time_binary=time_binary)
        item.update(accounting=accounting, state="finished", finished_at=stamp(),
                    stdout_sha256=digest(output / item["stdout_file"]),
                    stderr_sha256=digest(output / item["stderr_file"]))
        save()
        require(accounting["exit_code"] == 0 and not accounting["timed_out"], "child failed: " + label)
        child = json.loads((output / item["stdout_file"]).read_text())
        if expected_sha is not None:
            validate_ready(accounting, child, expected_sha)
        require(digest(report["binaries"][runtime]["path"]) == report["binaries"][runtime]["sha256"],
                "runtime bytes changed during invocation")
        return child

    try:
        order = ["v8", "wasmtime"] if args.reverse else ["wasmtime", "v8"]
        for fixture in transformed_cases():
            name = fixture["file"]
            source, expected = output / (name + "-calls.js"), output / (name + "-calls.expected")
            bundle, cache = output / (name + ".swbundle"), output / (name + ".v8cache")
            source.write_text(fixture["source"])
            expected.write_text(fixture["expected_stdout"])
            row = {key: value for key, value in fixture.items() if key != "source"}
            row.update(source_file=source.name, expected_file=expected.name,
                       bundle_file=bundle.name, cached_data_file=cache.name,
                       runtime_order=order, runtimes={})
            report["cases"].append(row)
            save()
            prepared = {}
            for runtime in order:
                label = name + "-prepare-" + runtime
                command = [runner, "prepare", source, bundle] if runtime == "wasmtime" else [
                    node, helper, "prepare", source, cache, expected]
                child = invoke(label, runtime, command)
                if runtime == "wasmtime":
                    require(child["schema"] == "scriptw-portable-boundaries-child-v1" and
                            child["mode"] == "prepare" and child["source_sha256"] == fixture["source_sha256"] and
                            child["bundle_sha256"] == digest(bundle) and child["executable_sha256"] == report["runtime_boundaries_sha256"],
                            "Scriptw prepared another source/artifact")
                    require(child["source_commit"] == identity["source_revision"]["commit"] and
                            child["source_fingerprint"] == identity["source_fingerprint"],
                            "Scriptw preparation source identity differs")
                    validate_cache_identity(child["compiler_cache_identity"], "sha256", child["executable_sha256"])
                else:
                    require(child["schema"] == "scriptw-v8-boundaries-child-v1" and child["mode"] == "prepare" and
                            child["source_sha256"] == fixture["source_sha256"] and
                            child["stdout"] == fixture["expected_stdout"] and child["cached_data_sha256"] == digest(cache),
                            "V8 prepared another source/output/cache")
                prepared[runtime] = child
                row["runtimes"][runtime] = {"prepare_command": label}
                save()
            row["bundle_sha256"], row["bundle_bytes"] = digest(bundle), bundle.stat().st_size
            row["cached_data_sha256"], row["cached_data_bytes"] = digest(cache), cache.stat().st_size
            for runtime in order:
                label = name + "-calls-" + runtime
                command = [runner, "calls", bundle, expected, str(SAMPLES)] if runtime == "wasmtime" else [
                    node, helper, "calls", source, cache, expected, str(SAMPLES)]
                child = invoke(label, runtime, command, fixture["expected_stdout_sha256"])
                validate_child(child, runtime="scriptw" if runtime == "wasmtime" else "node", mode="calls",
                               expected=fixture["expected_stdout"], source_sha=fixture["source_sha256"],
                               prepared=prepared[runtime], samples=SAMPLES)
                row["runtimes"][runtime]["calls_command"] = label
                save()
            print(name + ": one checked live-Realm session per runtime completed", flush=True)
        report["complete"] = True
        report["finished_at"] = stamp()
        report["loadavg_end"] = list(os.getloadavg())
    except BaseException as error:
        report["failure"] = str(error)
        raise
    finally:
        save()
    return output / "report.json"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("product", choices=["baseline", "candidate"])
    parser.add_argument("label")
    parser.add_argument("--reverse", action="store_true")
    parser.add_argument("--plan-only", action="store_true")
    args = parser.parse_args()
    if args.plan_only:
        print(json.dumps([{k: v for k, v in case.items() if k not in ["source", "expected_stdout"]}
                          for case in transformed_cases()], indent=2))
        return
    print(run(args))


if __name__ == "__main__":
    main()
