"""Read-only admission of the immutable preceding campaign; never accepted totals.

The old files retain their own actual source IDs and launcher observations.
No current-source aliases, fixture patches, binary payloads or cache payloads.
"""
from contextlib import contextmanager
import hashlib
import importlib.util
import json
from pathlib import Path
import statistics
import subprocess
import sys

BASE = Path(__file__).resolve().parent
REPO = BASE.parent.parent
PRIOR = REPO / "target/execution-performance-20261025"
SOURCE = "4b325de348f049a638f2e57fdc9749c74d926cbc"
INITIAL = "d67cbfbf02f3e8566a23f576ec48493d3d37646a"
BASELINE_CHECKOUT = "d41d6c9d2cb4b69e6cae783d4c868f53677fa46c"
EMPTY = hashlib.sha256(b"").hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError("prior diagnostics: " + message)


def digest(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


@contextmanager
def old_modules():
    # analysis_calls imports these module names. Keep its actual old BASE and
    # source constants separate from the fresh final campaign's module cache.
    names = ["analyze", "measure_calls", "analysis_calls", "prior_campaign_publisher"]
    saved = {name: sys.modules.get(name) for name in names}
    old_path = list(sys.path)
    try:
        sys.path.insert(0, str(PRIOR))
        for name in names:
            sys.modules.pop(name, None)
        ordinary = load("analyze", PRIOR / "analyze.py")
        load("measure_calls", PRIOR / "measure_calls.py")
        calls = load("analysis_calls", PRIOR / "analysis_calls.py")
        publisher = load("prior_campaign_publisher", PRIOR / "publish_evidence.py")
        require(ordinary.CANDIDATE_SOURCE == publisher.SOURCE == SOURCE,
                "old analyzer source identity changed")
        yield ordinary, calls, publisher
    finally:
        sys.path[:] = old_path
        for name, module in saved.items():
            if module is None:
                sys.modules.pop(name, None)
            else:
                sys.modules[name] = module


def u32(raw, offset):
    value = 0
    for shift in range(0, 35, 7):
        require(offset < len(raw), "truncated u32 LEB")
        byte = raw[offset]
        offset += 1
        value |= (byte & 127) << shift
        if byte < 128:
            require(value <= 0xffffffff, "overflowing u32 LEB")
            return value, offset
    raise ValueError("invalid u32 LEB")


def leb(value):
    result = bytearray()
    while True:
        byte, value = value & 127, value >> 7
        result.append(byte | (128 if value else 0))
        if not value:
            return bytes(result)


def rederive_patch(original, report):
    require(original[:8] == b"\0asm\x01\0\0\0", "ablation original header changed")
    patch = report["patch"]
    require(patch.get("changed_bodies") == 2 and patch.get("inserted_opcode_bytes") == 4,
            "ablation patch inventory changed")
    functions = patch["functions"]
    require(len(functions) == 2 and len({f["function_index"] for f in functions}) == 2 and
            all(f["name"].startswith("js::workload#") for f in functions), "unexpected patched source bodies")
    by_start = {f["original_body_start"]: f for f in functions}
    result, position, changed, sections = bytearray(original[:8]), 8, 0, 0
    while position < len(original):
        start, section = position, original[position]
        size, content = u32(original, position + 1)
        end = content + size
        require(end <= len(original), "truncated section")
        if section != 10:
            result.extend(original[start:end])
        else:
            sections += 1
            count, cursor = u32(original, content)
            code = bytearray(leb(count))
            for _ in range(count):
                prefix = cursor
                size, cursor = u32(original, cursor)
                body_start, body_end = cursor, cursor + size
                require(body_end <= end, "truncated body")
                if body_start not in by_start:
                    code.extend(original[prefix:body_end])
                else:
                    record = by_start[body_start]
                    require(record["original_body_end"] == body_end and
                            record["original_body_sha256"] == hashlib.sha256(original[body_start:body_end]).hexdigest(),
                            "patched body original identity changed")
                    require(len(record["patches"]) == 1, "unexpected insertions per source body")
                    insertion = record["patches"][0]
                    offset = insertion["insert_at_original_offset"]
                    require(insertion["instruction_start"] == offset - 1 and
                            insertion["body_relative_insert_offset"] == offset - body_start and
                            insertion["insert_hex"] == "4545" and
                            insertion["before_operators"] == ["F64ReinterpretI64", "F64Const(0.0)", "F64Lt"] and
                            insertion["insert_operators"] == ["I32Eqz", "I32Eqz"] and
                            original[offset - 11:offset] == b"\xbf\x44" + bytes(8) + b"\x63" and
                            body_start < offset < body_end, "predicate insertion shape changed")
                    body = original[body_start:offset] + b"\x45\x45" + original[offset:body_end]
                    code.extend(leb(len(body)))
                    code.extend(body)
                    changed += 1
                cursor = body_end
            require(cursor == end, "code section framing changed")
            result.extend(bytes([10]) + leb(len(code)) + code)
        position = end
    require(sections == 1 and changed == 2, "ablation changed unexpected sections/bodies")
    return bytes(result)


def negative_ablation(evidence, ordinary):
    plan_path = PRIOR / "predicate-ablation-data.plan.json"
    plan = read(plan_path)
    report_path = PRIOR / "predicate-ablation-data/report.json"
    report = read(report_path)
    require(plan["experimental_only"] is True and plan["source_commit"] == SOURCE and plan["exit_code"] == 0,
            "ablation plan source/exit changed")
    for name, key in [("ablate_predicate.py", "script_sha256"), ("ablate_predicate.rs", "rust_source_sha256"),
                      ("cargo-product.jsonl", "cargo_metadata_sha256"),
                      ("predicate-ablation-data.stdout", "stdout_sha256"),
                      ("predicate-ablation-data.stderr", "stderr_sha256")]:
        path = PRIOR / name
        require(digest(path) == plan[key], "ablation retained source/stream/metadata identity changed: " + name)
        evidence.add(path)
    require(read(PRIOR / plan["stdout"]) == report and plan["stderr"] == "predicate-ablation-data.stderr" and
            (PRIOR / plan["stderr"]).read_bytes() == b"", "ablation stdout/report/stderr differ")
    require(report["schema"] == "scriptw-experimental-predicate-bytepatch-v1" and report["complete"] is True and
            report["accepted_product_cohort"] is False and report["source_commit"] == SOURCE and
            report["round_order"] == "ABBA" and report["warmups_per_round"] == 10 and
            report["measured_samples_per_round"] == 7, "experimental boundary or sample denominator changed")
    identity = read(PRIOR / "candidate/identity.json")
    require(report["source_fingerprint"] == identity["source_fingerprint"] and
            report["diagnostic_executable_sha256"] == plan["diagnostic_executable_sha256"],
            "ablation actual engine/executable identity changed")
    original_path, patched_path = PRIOR / "predicate-ablation-data/original.wasm", PRIOR / "predicate-ablation-data/eqz-twice.wasm"
    original, patched = original_path.read_bytes(), patched_path.read_bytes()
    cohort = PRIOR / "candidate-round-b-data/integer.js-wasm/integer.js.wasm"
    require(original == cohort.read_bytes() and digest(cohort) == plan["accepted_cohort_p_sha256"] == report["original_p_sha256"] and
            digest(patched_path) == report["patched_p_sha256"] and len(original) == report["original_p_bytes"] and
            len(patched) == report["patched_p_bytes"] and rederive_patch(original, report) == patched,
            "ablation is not exactly the recorded canonical-i32 no-op insertion")
    case = next(c for c in read(PRIOR / "candidate-round-b-data/report.json")["case_results"] if c["file"] == "integer.js")
    raw = case["runtimes"]["wasmtime"]["data"]["cases"][0]
    require(report["same_linked_runtime"] == raw["linked_runtime"] and report["source_sha256"] == case["source_sha256"] == plan["fixture_sha256"] and
            report["expected_stdout"] == case["expected_stdout"] == "730532261\n" and
            report["artifact_fields_except_bytes_unchanged"] is True and report["accepted_cohort_original_p_exactly_equal"] is True,
            "ablation runtime/source/output identity changed")
    require([r["label"] for r in report["rounds"]] == ["original-a", "eqz-twice-b", "eqz-twice-c", "original-d"],
            "ablation round inventory changed")
    pooled = {"original": [], "eqz-twice": []}
    for index, row in enumerate(report["rounds"]):
        variant = "original" if index in [0, 3] else "eqz-twice"
        expected_p = report["original_p_sha256" if variant == "original" else "patched_p_sha256"]
        require(row["index"] == index and row["variant"] == variant and row["p_sha256"] == expected_p,
                "ablation round artifact identity changed")
        observations = row["observations"]
        require(len(observations) == 17, "ablation invocation denominator changed")
        for number, observation in enumerate(observations):
            require(observation["index"] == number and observation["warmup"] is (number < 10) and
                    observation["backend"] == "wasm-aot" and observation["normal_completion"] is True and
                    observation["stdout"] == "730532261\n" and type(observation["execution_ns"]) is int and observation["execution_ns"] > 0,
                    "ablation missing actual exact-output execution")
            require(observation["actual_policy"] == {"native_mode": "fast", "gc_initial_mib": 16,
                    "register_allocation": "single-pass", "inlining": "Disabled"}, "ablation actual runtime policy changed")
        samples = [o["execution_ns"] for o in observations if not o["warmup"]]
        require(row["samples_ns"] == samples and row["median_execution_ns"] == statistics.median(samples),
                "ablation round summary not derived from raw observations")
        pooled[variant].extend(samples)
    for variant, samples in pooled.items():
        require(report["pooled"][variant] == {"samples_ns": samples, "median_ns": statistics.median(samples)},
                "ablation pooled summary changed")
    change = 100 * (statistics.median(pooled["eqz-twice"]) / statistics.median(pooled["original"]) - 1)
    require(report["median_change_percent"] == change and change > 0, "negative no-op ablation outcome was hidden or changed")
    for label, code, clean in [("predicate-ablation", 1, False), ("predicate-ablation-final", 1, True),
                               ("predicate-ablation-linked", 0, True)]:
        evidence.receipt(label, exit_code=code, checkout_source=SOURCE, clean_source=clean)
    for path in [plan_path, report_path, original_path, patched_path]:
        evidence.add(path)
    return {"source_commit": SOURCE, "experimental_only": True, "excluded_from_final_totals": True,
            "decision": "reject canonical-i32 no-op insertion; defer ABI expansion; no measured benefit",
            "actual_median_change_percent": change, "exact_output_invocations": 68,
            "report": "predicate-ablation-data/report.json", "raw_observations": report,
            "setup_failures": ["predicate-ablation.json", "predicate-ablation-final.json"],
            "successful_diagnostic_receipt": "predicate-ablation-linked.json",
            "interpretation": "Descriptive artifact ablation only; no causal claim about the prior integer variation."}


def build_report(evidence, accepted_source):
    manifest_path = BASE / "prior-diagnostic-inventory.json"
    manifest = read(manifest_path)
    require(manifest["root"] == "target/execution-performance-20261025" and manifest["excluded_from_final_totals"] is True,
            "archive root or acceptance boundary changed")
    files = manifest["files"]
    require(files and len(files) == len({f["path"] for f in files}), "prior archive inventory empty or repeated")
    receipt_observations = []
    for record in files:
        path = PRIOR / record["path"]
        require(path.resolve().is_relative_to(PRIOR) and path.is_file() and not path.is_symlink() and
                path.stat().st_size == record["bytes"] and digest(path) == record["sha256"],
                "retained prior file changed: " + record["path"])
        evidence.add(path)
        if path.suffix == ".json":
            row = read(path)
            if isinstance(row, dict) and {"label", "source_head", "source_patch_sha256", "exit_code", "log", "log_sha256"}.issubset(row):
                # The saved missing-time failure deliberately preserves its
                # original embedded label/log fields after relocation.
                log = (path.with_suffix(".log") if path.name == "baseline-calls-round-a-failed-tooling-original.json"
                       else path.parent / row["log"])
                require(Path(row["log"]).name == row["log"] and log.is_file() and
                        digest(log) == row["log_sha256"] and type(row["exit_code"]) is int,
                        "original receipt/log no longer reconcile: " + record["path"])
                receipt_observations.append({"path": record["path"], "original_label": row["label"],
                    "source_head": row["source_head"], "source_patch_sha256": row["source_patch_sha256"],
                    "actual_exit_code": row["exit_code"], "actual_test_results": row.get("test_results"),
                    "included_in_final_totals": False})
    with old_modules() as (ordinary, calls, publisher):
        initial = publisher.original_diagnostics(evidence)
        previous = ordinary.build_report()
        previous_calls = calls.build_report()
        require(previous == read(PRIOR / "analysis.json") and previous_calls == read(PRIOR / "analysis_calls.json"),
                "retained4b ABBA aggregate differs from actual raw evidence")
        require(len(previous["cases"]) == len(previous_calls["cases"]) == 17 and previous_calls["case_count"] == 17,
                "retained4b cohorts lost workloads")
        for path in [*ordinary.evidence_files(), *calls.evidence_files()]:
            evidence.add(path)
        for index, label in enumerate(ordinary.ROUNDS):
            evidence.receipt(label.removesuffix("-data"), checkout_source=BASELINE_CHECKOUT if index == 0 else SOURCE,
                             clean_source=index != 0)
        for label in calls.ROUNDS:
            evidence.receipt(label.removesuffix("-data"), checkout_source=SOURCE)
        focused = []
        for label, count in [("focused-aot-scalar", 1), ("focused-aot-string", 1), ("focused-ir-string", 2),
                             ("focused-engine-buffers", 4), ("focused-engine-scalar", 6), ("focused-engine-string", 3)]:
            row, text = evidence.receipt(label, checkout_source=SOURCE)
            summaries = publisher.SUMMARY_RE.findall(text)
            names = [name for name, status in publisher.observed_names(text) if status == "ok"]
            require(len(names) == count and len(summaries) == 1, "prior corrected-source focused denominator changed")
            publisher.closed_native_log(row, text, names, filtered=int(summaries[0][-1]))
            focused.append({"receipt": label + ".json", "actual_terminal_counts": row["test_results"]})
        ablation = negative_ablation(evidence, previous)
    # The encoded guard stayed intact in both corrected and final product sources.
    path = ":crates/scriptw-aot-wasm/src/tests/scalar_predicates.rs"
    require(subprocess.check_output(["git", "show", INITIAL + path], cwd=REPO) ==
            subprocess.check_output(["git", "show", accepted_source + path], cwd=REPO),
            "final source changed the original encoded optimization guard")
    # Preserve the failed tool receipt's original embedded label/log names.
    failed_path = PRIOR / "baseline-calls-round-a-failed-tooling-original.json"
    failed = read(failed_path)
    failed_log = PRIOR / "baseline-calls-round-a-failed-tooling-original.log"
    require(failed["exit_code"] == 1 and failed["source_head"] == SOURCE and
            failed["log_sha256"] == digest(failed_log) and failed["source_patch_sha256"] == EMPTY,
            "original missing-GNUtime failure changed")
    evidence.resource(failed, "original-missing-gnu-time")
    table = []
    call_map = {row["file"]: row for row in previous_calls["cases"]}
    for row in previous["cases"]:
        live = call_map[row["file"]]
        table.append({"file": row["file"], "fresh_realm_change_percent": row["median_change_percent"],
                      "existing_realm_change_percent": live["median_change_percent"]})
    return {"excluded_from_final_totals": True, "reason": "Complete prior source/cohort retained as diagnostics; final acceptance requires fresh observations of the final source.",
            "archive_inventory": manifest_path.name, "archive_files": len(files),
            "original_receipt_observations": receipt_observations,
            "initial_d67": initial, "prior_source_commit": SOURCE,
            "corrected_source_focused": focused, "corrected_source_focused_passed": 17,
            "ordinary_4b_abba": previous, "existing_realm_4b_abba": previous_calls,
            "prior_comparison_table": table, "negative_predicate_ablation": ablation,
            "original_missing_gnu_time_failure": {"receipt": failed_path.name, "log": failed_log.name,
                "actual_exit_code": failed["exit_code"], "original_embedded_label": failed["label"],
                "original_embedded_log_name": failed["log"], "recovered_by": "separate completed ABBA sessions; failed records unchanged"},
            "interpretation": "All prior wins and regressions remain actual source4b observations. Fresh-Realm integer variation and flat existing-Realm results do not establish a compiler/native-code causal explanation."}
