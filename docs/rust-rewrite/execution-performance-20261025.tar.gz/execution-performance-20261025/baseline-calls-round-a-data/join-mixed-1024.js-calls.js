(function () {
function batch(seed) {

var a=[];for(var i=0;i<1024;i++)a.push(i%4===0?null:i%4===1?undefined:i%4===2?"xy":"z");return (a.join(",").length);
}
var result;
for (var warmup = 0; warmup < 10; warmup++) {
  result = batch(warmup % 8);
  print('warmup:' + warmup + ':' + result);
}
print('scriptw:call:ready');
for (var sample = 0; sample < 7; sample++) {
  print('scriptw:call:start:' + sample);
  result = batch(sample % 8);
  print('scriptw:call:end:' + sample);
  print('sample:' + sample + ':' + result);
}
})();
