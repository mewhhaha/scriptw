(function () {
function batch(seed) {

  var rows = [];
  for (var i = 0; i < 500; i++) rows.push({x: i, y: (i * 7) % 101});
  var sum = 0;
  for (var i = 0; i < rows.length; i++) sum += rows[i].x + rows[i].y;
  return (String(sum));
}
var result;
for (var warmup = 0; warmup < 10; warmup++) {
  result = batch(warmup % 8);
  print('warmup:' + warmup + ':' + result);
}
print('scriptw:call:ready');
for (var sample = 0; sample < 7; sample++) {
  print('scriptw:call:start:' + sample);
  result = batch(sample % 8);
  print('scriptw:call:end:' + sample);
  print('sample:' + sample + ':' + result);
}
})();
