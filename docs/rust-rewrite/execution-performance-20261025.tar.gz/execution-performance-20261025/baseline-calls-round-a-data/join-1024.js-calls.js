(function () {
function batch(seed) {

var a=[];for(var i=0;i<1024;i++)a.push("ab\ud800\u0000");var s=a.join("\udfff");return (s.length+s.charCodeAt(2)+s.charCodeAt(s.length-1));
}
var result;
for (var warmup = 0; warmup < 10; warmup++) {
  result = batch(warmup % 8);
  print('warmup:' + warmup + ':' + result);
}
print('scriptw:call:ready');
for (var sample = 0; sample < 7; sample++) {
  print('scriptw:call:start:' + sample);
  result = batch(sample % 8);
  print('scriptw:call:end:' + sample);
  print('sample:' + sample + ':' + result);
}
})();
