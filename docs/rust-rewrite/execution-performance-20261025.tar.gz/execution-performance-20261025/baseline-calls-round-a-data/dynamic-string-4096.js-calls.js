(function () {
function batch(seed) {

var a="abcd",b="efgh",s=0;for(var i=0;i<4096;i++){a=i%2?"abcd":"efgh";b=i%2?"efgh":"abcd";s+=(a+b).length;}return (s);
}
var result;
for (var warmup = 0; warmup < 10; warmup++) {
  result = batch(warmup % 8);
  print('warmup:' + warmup + ':' + result);
}
print('scriptw:call:ready');
for (var sample = 0; sample < 7; sample++) {
  print('scriptw:call:start:' + sample);
  result = batch(sample % 8);
  print('scriptw:call:end:' + sample);
  print('sample:' + sample + ':' + result);
}
})();
