(function () {
function batch(seed) {

var a=[];for(var i=128;i>0;i--)a.push(i);a.sort(function(a,b){return a-b;});var s=0;for(var i=0;i<a.length;i++)s+=(i+1)*a[i];return (s);
}
var result;
for (var warmup = 0; warmup < 10; warmup++) {
  result = batch(warmup % 8);
  print('warmup:' + warmup + ':' + result);
}
print('scriptw:call:ready');
for (var sample = 0; sample < 7; sample++) {
  print('scriptw:call:start:' + sample);
  result = batch(sample % 8);
  print('scriptw:call:end:' + sample);
  print('sample:' + sample + ':' + result);
}
})();
