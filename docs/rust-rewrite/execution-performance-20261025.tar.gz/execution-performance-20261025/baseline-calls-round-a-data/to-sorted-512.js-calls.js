(function () {
function batch(seed) {

var a=[];for(var i=512;i>0;i--)a.push(i);var b=a.toSorted(function(a,b){return a-b;});var s=a[0];for(var i=0;i<b.length;i++)s+=(i+1)*b[i];return (s);
}
var result;
for (var warmup = 0; warmup < 10; warmup++) {
  result = batch(warmup % 8);
  print('warmup:' + warmup + ':' + result);
}
print('scriptw:call:ready');
for (var sample = 0; sample < 7; sample++) {
  print('scriptw:call:start:' + sample);
  result = batch(sample % 8);
  print('scriptw:call:end:' + sample);
  print('sample:' + sample + ':' + result);
}
})();
