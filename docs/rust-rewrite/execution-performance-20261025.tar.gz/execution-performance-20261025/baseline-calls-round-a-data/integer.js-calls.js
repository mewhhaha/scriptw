(function () {
function batch(seed) {

  var state = 123456789;
  for (var i = 0; i < 10000; i++) {
    state = (Math.imul(state, 1664525) + 1013904223) >>> 0;
  }
  return (String(state));
}
var result;
for (var warmup = 0; warmup < 10; warmup++) {
  result = batch(warmup % 8);
  print('warmup:' + warmup + ':' + result);
}
print('scriptw:call:ready');
for (var sample = 0; sample < 7; sample++) {
  print('scriptw:call:start:' + sample);
  result = batch(sample % 8);
  print('scriptw:call:end:' + sample);
  print('sample:' + sample + ':' + result);
}
})();
