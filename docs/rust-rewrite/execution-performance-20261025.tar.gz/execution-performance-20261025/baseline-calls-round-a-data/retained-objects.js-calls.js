(function () {
function batch(seed) {

  var rows = [];
  for (var i = 0; i < 8192; i++) {
    rows.push({name: 'row-' + i, values: [i, i + 1, i + 2, i + 3]});
  }
  var sum = 0;
  for (var column = 0; column < 4; column++) {
    for (var i = 0; i < rows.length; i++) sum += rows[i].values[column];
  }
  return (String(sum));
}
var result;
for (var warmup = 0; warmup < 10; warmup++) {
  result = batch(warmup % 8);
  print('warmup:' + warmup + ':' + result);
}
print('scriptw:call:ready');
for (var sample = 0; sample < 7; sample++) {
  print('scriptw:call:start:' + sample);
  result = batch(sample % 8);
  print('scriptw:call:end:' + sample);
  print('sample:' + sample + ':' + result);
}
})();
