#!/usr/bin/env python3
"""Reconcile closed ABBA execution measurements; never execute a workload.

This is descriptive analysis of seven measured fresh Store/Realm or V8-context
invocations after ten warmups in each fresh process. It does not estimate an
isolated builtin cost, significance, live heap bytes or allocation counts.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timedelta
import hashlib
import json
from pathlib import Path
import statistics

BASE = Path(__file__).resolve().parent
REPO = BASE.parent.parent
FIXTURES = REPO / "crates/scriptw-cli/tests/fixtures/v8_execution_hotpaths"
BASELINE_SOURCE = "4ad59d1ebbc64c9e3384aee9cefd19e3c8b8e92d"
CANDIDATE_SOURCE = "ab97459e54f9e0cd3ed983d098c46ccacac8fec6"
ROUNDS = (
    "baseline-round-a-data",
    "candidate-round-b-data",
    "candidate-round-c-data",
    "baseline-round-d-data",
)
LIMIT = 4 * 1024**3
PRODUCT_HASHES = {}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def uint(value):
    return type(value) is int and value >= 0


def code_footprint(path):
    """Count the actual P code-section bodies without interpreting instructions."""
    raw = path.read_bytes()
    require(raw[:8] == b"\0asm\x01\0\0\0", f"invalid Wasm header: {path}")

    def leb(offset):
        value = 0
        for ordinal in range(5):
            require(offset < len(raw), f"truncated Wasm size: {path}")
            byte = raw[offset]
            offset += 1
            value |= (byte & 127) << (ordinal * 7)
            if not byte & 128:
                require(value <= 0xffffffff, f"overflowing Wasm size: {path}")
                return value, offset
        raise ValueError(f"invalid Wasm size: {path}")

    offset = 8
    sizes = None
    while offset < len(raw):
        section = raw[offset]
        size, start = leb(offset + 1)
        end = start + size
        require(end <= len(raw), f"truncated Wasm section: {path}")
        if section == 10:
            require(sizes is None, f"duplicate Wasm code section: {path}")
            count, cursor = leb(start)
            sizes = []
            for _ in range(count):
                body, cursor = leb(cursor)
                sizes.append(body)
                cursor += body
                require(cursor <= end, f"truncated Wasm function: {path}")
            require(cursor == end, f"code section trailing bytes: {path}")
        offset = end
    require(sizes is not None, f"missing Wasm code section: {path}")
    return {
        "defined_functions": len(sizes),
        "code_body_bytes": sum(sizes),
        "largest_code_body_bytes": max(sizes, default=0),
    }


def resources(receipt, label):
    require(receipt.get("exit_code") == 0, f"{label}: measurement command failed")
    require(str(receipt.get("memory.max")) == str(LIMIT), f"{label}: cap differs")
    require(str(receipt.get("memory.swap.max")) == "0", f"{label}: swap differs")
    require(str(receipt.get("memory.oom.group")) == "1", f"{label}: OOM group differs")
    require(receipt.get("cpu_affinity") == [0], f"{label}: CPU differs")
    require(0 <= int(receipt.get("memory.peak", -1)) <= LIMIT, f"{label}: invalid peak")
    events = dict(row.split() for row in receipt["memory.events"].splitlines())
    require(all(events.get(k) == "0" for k in ("oom", "oom_kill", "oom_group_kill")),
            f"{label}: measurement had OOM events")
    environment = receipt.get("resource_environment", {})
    expected = {
        "CARGO_BUILD_JOBS": "1", "SCRIPTW_JOBS": "1", "RUST_TEST_THREADS": "1",
        "RAYON_NUM_THREADS": "1", "SCRIPTW_MODULE_MEMORY_CACHE_ENTRIES": "1",
        "SCRIPTW_MODULE_MEMORY_CACHE_LIMIT_BYTES": str(64 * 1024**2),
    }
    require(all(environment.get(k) == v for k, v in expected.items()),
            f"{label}: serial/cache policy differs")
    log = BASE / receipt["log"]
    require(digest(log) == receipt.get("log_sha256"), f"{label}: resource log changed")


def memory_sample(runtime, observation):
    memory = observation["memory"]
    if runtime == "wasmtime":
        rss = memory.get("process_rss", {})
        return {
            "process_rss_status": rss.get("status"),
            "process_rss_scope": rss.get("scope"),
            "initial_rss_bytes": rss.get("initial_rss_bytes"),
            "final_rss_bytes": rss.get("final_rss_bytes"),
            "maximum_sampled_rss_bytes": rss.get("maximum_rss_bytes"),
            "rss_sample_count": rss.get("sample_count"),
            "gc_capacity_before_bytes": memory.get("gc_capacity_before_bytes"),
            "gc_capacity_after_bytes": memory.get("gc_capacity_after_bytes"),
            "unavailable": memory.get("unavailable", {}),
        }
    return {
        "scope": memory["scope"],
        "rss_before_context_bytes": memory["before_context"]["rss"],
        "rss_before_execution_bytes": memory["before"]["rss"],
        "rss_after_execution_bytes": memory["after"]["rss"],
        "heap_total_before_bytes": memory["before"]["heapTotal"],
        "heap_total_after_bytes": memory["after"]["heapTotal"],
        "heap_used_before_bytes": memory["before"]["heapUsed"],
        "heap_used_after_bytes": memory["after"]["heapUsed"],
    }


def one_round(label, plan):
    directory = BASE / label
    path = directory / "report.json"
    report = read(path)
    require(report.get("complete") is True and report.get("label") == label,
            f"{label}: missing/partial/mislabelled report")
    expected_product = label.split("-")[0]
    require(report.get("product") == expected_product, f"{label}: product differs")
    require(report.get("samples") == 7 and report.get("warmups") == 10,
            f"{label}: measurement/warmup denominator differs")
    require(report.get("affinity") == [0], f"{label}: affinity differs")
    identity = report["compiler_identity"]
    expected_source = BASELINE_SOURCE if expected_product == "baseline" else CANDIDATE_SOURCE
    require(identity.get("source_revision") == {"kind": "git-commit", "commit": expected_source},
            f"{label}: actual executed source is not the admitted {expected_product} revision")
    product = BASE / expected_product
    require(read(product / "identity.json") == identity, f"{label}: frozen compiler identity differs")
    for executable, expected in [
        ("scriptw", identity["executable_sha256"]),
        ("runtime_baseline", report["runtime_runner_sha256"]),
    ]:
        key = str(product / executable)
        if key not in PRODUCT_HASHES:
            PRODUCT_HASHES[key] = digest(key)
        require(PRODUCT_HASHES[key] == expected, f"{label}: frozen {executable} bytes differ")
    receipt_label = label.removesuffix("-data")
    receipt_path = BASE / (receipt_label + ".json")
    receipt = read(receipt_path)
    require(receipt.get("label") == receipt_label, f"{label}: receipt label differs")
    resources(receipt, label)
    require(receipt.get("source_head") == CANDIDATE_SOURCE and receipt.get("source_patch_sha256") == hashlib.sha256(b"").hexdigest(),
            label + ": final campaign launcher must be the actual clean final checkout; baseline compiler identity remains separately admitted")
    require(report["case_results"] and [r["file"] for r in report["case_results"]] == [c["file"] for c in plan],
            f"{label}: exact ordered17-case inventory differs")
    rows = {}
    node_versions = set()
    for row, fixture in zip(report["case_results"], plan):
        name = fixture["file"]
        source_hash = digest(FIXTURES / name)
        require(row["source_sha256"] == source_hash and row["expected_stdout"] == fixture["stdout"],
                f"{label}/{name}: source/oracle differs")
        require(set(row["runtimes"]) == {"wasmtime", "v8"}, f"{label}/{name}: runtime inventory differs")
        entry = {"file": name, "source_sha256": source_hash, "expected_stdout": fixture["stdout"]}
        for runtime, record in row["runtimes"].items():
            require(record["exit_code"] == 0, f"{label}/{name}/{runtime}: process failed")
            stdout = directory / record["stdout_file"]
            stderr = directory / record["stderr_file"]
            data = record["data"]
            require(read(stdout) == data and stderr.is_file(), f"{label}/{name}/{runtime}: raw streams differ/missing")
            require(data["samples"] == 7 and data["warmups"] == 10 and len(data["cases"]) == 1,
                    f"{label}/{name}/{runtime}: observation denominator differs")
            case = data["cases"][0]
            require(case["file"] == name and case["source_sha256"] == source_hash,
                    f"{label}/{name}/{runtime}: nested case identity differs")
            observations = case["observations"]
            require(len(observations) == 17 and [o["warmup"] for o in observations] == [True] * 10 + [False] * 7,
                    f"{label}/{name}/{runtime}: exact warmup/sample order differs")
            require(all(o["stdout"] == fixture["stdout"] and uint(o["execution_ns"]) for o in observations),
                    f"{label}/{name}/{runtime}: output or execution duration differs")
            measured = observations[10:]
            timings = [o["execution_ns"] for o in measured]
            details = {
                "execution_ns": timings,
                "median_execution_ns": statistics.median(timings),
                "memory": [memory_sample(runtime, o) for o in measured],
                "stdout_file": stdout.name, "stdout_sha256": digest(stdout),
                "stderr_file": stderr.name, "stderr_sha256": digest(stderr),
                "command": record["command"],
            }
            if runtime == "wasmtime":
                revision = identity["source_revision"]
                require(revision.get("kind") == "git-commit" and data["source_commit"] == revision["commit"] and
                        data["source_fingerprint"] == identity["source_fingerprint"] and
                        data["executable_sha256"] == report["runtime_runner_sha256"],
                        f"{label}/{name}: actual runner source/bytes differ")
                require(data["requested_native_policy"] is None and case["source_compilation_profile"] == "portable",
                        f"{label}/{name}: native/profile cohort differs")
                raw_wasm = directory / (name + "-wasm") / (name + ".wasm")
                require(raw_wasm.stat().st_size == case["wasm_bytes"] and digest(raw_wasm) == case["wasm_sha256"],
                        f"{label}/{name}: raw P bytes differ")
                footprint = code_footprint(raw_wasm)
                require(all(case["footprint"][k] == value for k, value in footprint.items()),
                        f"{label}/{name}: P code-body footprint differs")
                linked = case["linked_runtime"]
                details["code"] = {
                    "p_wasm_bytes": case["wasm_bytes"], "p_wasm_sha256": case["wasm_sha256"],
                    **{"p_" + k: value for k, value in case["footprint"].items()},
                    "r_key": linked["key"], "r_wasm_bytes": linked["wasm_bytes"],
                    "r_wasm_sha256": linked["wasm_sha256"],
                    "r_code_body_bytes": None, "native_text_bytes": None,
                    "unavailable_sizes": "Boundary reports R module bytes but no R code-body or native-text counter.",
                }
                details["runtime_policies"] = sorted({o["runtime_policy"] for o in observations})
            else:
                node_versions.add((data["node"], data["v8"]))
            entry[runtime] = details
        rows[name] = entry
    require(len(node_versions) == 1, f"{label}: Node/V8 versions differ within round")
    end = datetime.fromisoformat(receipt["date"])
    authority_path = product / "source-authority.json"
    authority = read(authority_path) if authority_path.is_file() else None
    return {
        "product": expected_product, "compiler_identity": identity,
        "runtime_runner_sha256": report["runtime_runner_sha256"],
        "report_sha256": digest(path), "receipt_sha256": digest(receipt_path),
        "receipt_label": receipt_label, "start": (end - timedelta(seconds=receipt["seconds"])).isoformat(),
        "end": end.isoformat(), "node_v8": list(next(iter(node_versions))),
        "boundary": report["boundary"], "memory_scope": report["memory"],
        "loadavg_start": report["loadavg_start"], "loadavg_end": report["loadavg_end"],
        "resource_receipt": receipt_path.name,
        "product_source_authority": authority,
        "product_verification_patch_sha256": digest(REPO / authority["source_patch"])
            if authority is not None and "source_patch" in authority else None,
        "launcher_checkout_only": {
            "source_head": receipt["source_head"],
            "source_patch_sha256": receipt["source_patch_sha256"],
            "note": "Launcher working-tree provenance; actual executed product identity is compiler_identity, not this checkout.",
        },
    }, rows


def percentage(before, after):
    require(before > 0, "zero baseline cannot produce a relative change")
    return (after / before - 1) * 100


def memory_summary(samples):
    fields = sorted({field for sample in samples for field, value in sample.items() if uint(value)})
    return {
        field: {
            "values": [sample.get(field) for sample in samples],
            "median": statistics.median(sample[field] for sample in samples if uint(sample.get(field))),
            "minimum": min(sample[field] for sample in samples if uint(sample.get(field))),
            "maximum": max(sample[field] for sample in samples if uint(sample.get(field))),
        }
        for field in fields
    }


def manifest_plan():
    plan = read(FIXTURES / "manifest.json")["execution"]
    require(len(plan) == len({c["file"] for c in plan}) == 17, "workload manifest is not exactly17 unique cases")
    return plan


def build_report():
    """Rederive complete analysis from actual immutable evidence; write nothing."""
    PRODUCT_HASHES.clear()
    plan = manifest_plan()
    rounds, data = {}, {}
    for label in ROUNDS:
        rounds[label], data[label] = one_round(label, plan)
    a, b, c, d = ROUNDS
    for first, second in [(a, d), (b, c)]:
        for key in ["compiler_identity", "runtime_runner_sha256"]:
            require(rounds[first][key] == rounds[second][key], f"{first}/{second}: {key} differs")
    for first, second in zip(ROUNDS, ROUNDS[1:]):
        require(datetime.fromisoformat(rounds[first]["end"]) <= datetime.fromisoformat(rounds[second]["start"]),
                "ABBA rounds overlap or are out of order")
    require(len({tuple(r["node_v8"]) for r in rounds.values()}) == 1, "Node/V8 cohort changed across ABBA")
    require(len({r["boundary"] for r in rounds.values()}) == 1, "execution boundary changed across ABBA")
    cases = []
    for fixture in plan:
        name = fixture["file"]
        observations = {label: data[label][name] for label in ROUNDS}
        for first, second in [(a, d), (b, c)]:
            require(observations[first]["wasmtime"]["code"] == observations[second]["wasmtime"]["code"],
                    f"{name}: same-product emitted bytes/footprint changed")
        pooled = {}
        for product, labels in [("baseline", [a, d]), ("candidate", [b, c])]:
            pooled[product] = {}
            for runtime in ["wasmtime", "v8"]:
                samples = [value for label in labels for value in observations[label][runtime]["execution_ns"]]
                pooled[product][runtime] = {
                    "execution_ns": samples, "median_execution_ns": statistics.median(samples),
                    "round_median_execution_ns": [observations[label][runtime]["median_execution_ns"] for label in labels],
                    "memory_observations": memory_summary([
                        value for label in labels for value in observations[label][runtime]["memory"]
                    ]),
                }
        pairs = []
        for control, candidate in [(a, b), (d, c)]:
            before = observations[control]["wasmtime"]["median_execution_ns"]
            after = observations[candidate]["wasmtime"]["median_execution_ns"]
            pairs.append({"baseline_round": control, "candidate_round": candidate,
                          "baseline_median_execution_ns": before, "candidate_median_execution_ns": after,
                          "change_percent": percentage(before, after)})
        before = pooled["baseline"]["wasmtime"]["median_execution_ns"]
        after = pooled["candidate"]["wasmtime"]["median_execution_ns"]
        cases.append({
            "file": name, "source_sha256": observations[a]["source_sha256"],
            "expected_stdout": fixture["stdout"], "work": fixture["work"],
            "rounds": {label: {runtime: observations[label][runtime] for runtime in ["wasmtime", "v8"]} for label in ROUNDS},
            "pooled": pooled, "adjacent_pairs": pairs, "median_change_percent": percentage(before, after),
            "both_adjacent_pairs_improve": all(pair["change_percent"] < 0 for pair in pairs),
            "both_adjacent_pairs_regress": all(pair["change_percent"] > 0 for pair in pairs),
            "scriptw_over_v8": {product: pooled[product]["wasmtime"]["median_execution_ns"] /
                                pooled[product]["v8"]["median_execution_ns"] for product in pooled},
            "code_size_changes": {
                field: {
                    "baseline": observations[a]["wasmtime"]["code"][field],
                    "candidate": observations[b]["wasmtime"]["code"][field],
                    "delta": observations[b]["wasmtime"]["code"][field] - observations[a]["wasmtime"]["code"][field],
                }
                for field in ["p_wasm_bytes", "p_defined_functions", "p_code_body_bytes",
                              "p_largest_code_body_bytes", "p_data_payload_bytes", "r_wasm_bytes"]
            },
        })
    result = {
        "schema": "scriptw-execution-performance-comparison-v1", "complete": True,
        "round_order": list(ROUNDS), "rounds": rounds, "case_count": len(cases), "cases": cases,
        "notes": [
            "Pooled medians use14 checked samples per product; adjacent AB and DC comparisons use seven-sample round medians.",
            "Descriptive observations, not significance estimates; construction and checksums remain in execution time.",
            "Wasmtime RSS is a sampled whole-invocation process value, not isolated guest peak/live heap/allocation bytes.",
            "V8 RSS/heap are process-wide endpoints under natural GC; they are not comparable live workload counters.",
            "GC capacity is reserved heap capacity, not live bytes, allocated bytes or collection count.",
            "R module bytes are reported by the executing boundary; R code-body/native-text sizes are unavailable.",
            "Measurements used a shared host with observed unrelated CPU activity and desktop work; per-round load averages are retained. This is not idle-machine repeatability, statistical or causal certification, or V8 parity certification.",
        ],
    }
    return result


def evidence_files():
    """Explicit raw evidence inventory, excluding ELF executables and caches."""
    plan = manifest_plan()
    paths = {Path(__file__).resolve(), BASE / "measure.py", FIXTURES / "manifest.json"}
    paths.update(FIXTURES / case["file"] for case in plan)
    for product in ["baseline", "candidate"]:
        paths.add(BASE / product / "identity.json")
        authority = BASE / product / "source-authority.json"
        if authority.is_file():
            paths.add(authority)
    for label in ROUNDS:
        directory = BASE / label
        report = read(directory / "report.json")
        paths.add(directory / "report.json")
        receipt_label = label.removesuffix("-data")
        receipt = read(BASE / (receipt_label + ".json"))
        paths.add(BASE / (receipt_label + ".json"))
        paths.add(BASE / receipt["log"])
        for row in report["case_results"]:
            for record in row["runtimes"].values():
                paths.add(directory / record["stdout_file"])
                paths.add(directory / record["stderr_file"])
            paths.add(directory / (row["file"] + "-wasm") / (row["file"] + ".wasm"))
    require(all(path.is_file() for path in paths), "raw evidence inventory is incomplete")
    return sorted(paths)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=BASE / "analysis.json")
    parser.add_argument("--check-round", choices=ROUNDS, help="validate one completed round without writing an aggregate")
    args = parser.parse_args()
    if args.check_round:
        metadata, rows = one_round(args.check_round, manifest_plan())
        print(json.dumps({"validated": args.check_round, "cases": len(rows), "metadata": metadata}, indent=2))
        return
    result = build_report()
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    for row in result["cases"]:
        before = row["pooled"]["baseline"]["wasmtime"]["median_execution_ns"] / 1e6
        after = row["pooled"]["candidate"]["wasmtime"]["median_execution_ns"] / 1e6
        print(f'{row["file"]}: {before:.3f} -> {after:.3f}ms ({row["median_change_percent"]:+.1f}%); '
              f'AB {row["adjacent_pairs"][0]["change_percent"]:+.1f}%, DC {row["adjacent_pairs"][1]["change_percent"]:+.1f}%')
    print(f"Wrote verified descriptive comparison: {args.output}")


if __name__ == "__main__":
    try:
        main()
    except (KeyError, ValueError, OSError, TypeError) as error:
        raise SystemExit(f"Comparison refused: {error}")
