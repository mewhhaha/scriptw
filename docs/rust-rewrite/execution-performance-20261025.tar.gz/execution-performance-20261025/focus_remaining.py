import json,pathlib,subprocess,sys
root=pathlib.Path(__file__).resolve().parent
commands=[('aot-scalar',['cargo','test','--locked','--release','--jobs','1','-p','scriptw-aot-wasm','--lib','scalar_predicates::']),('aot-string',['cargo','test','--locked','--release','--jobs','1','-p','scriptw-aot-wasm','--test','emission','numeric_bitwise_emission::literal_string_addition']),('ir-string',['cargo','test','--locked','--release','--jobs','1','-p','scriptw-ir','--lib','string_addition']),('engine-buffers',['cargo','test','--locked','--release','--jobs','1','-p','scriptw-engine','--test','aot_builtins','aot_array_private_buffers::']),('engine-scalar',['cargo','test','--locked','--release','--jobs','1','-p','scriptw-engine','--test','aot_language','aot_scalar_execution::']),('engine-string',['cargo','test','--locked','--release','--jobs','1','-p','scriptw-engine','--test','aot_language','aot_string_addition::'])]
for name,command in commands[1:]:
 code=subprocess.call([sys.executable,'-B',str(root/'run_check.py'),'focused-'+name,*command,'--','--test-threads=1','--include-ignored'])
 if code:sys.exit(code)
 receipt=json.loads((root/('focused-'+name+'.json')).read_text());results=receipt['test_results']
 if not results or sum(int(row[1]) for row in results)==0 or any(row[0]!='ok' or row[2]!='0' or row[3]!='0' for row in results):raise RuntimeError('focused inventory failed or empty: '+name)
