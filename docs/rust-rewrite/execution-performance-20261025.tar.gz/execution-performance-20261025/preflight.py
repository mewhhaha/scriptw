import pathlib,subprocess,sys
root=pathlib.Path(__file__).resolve().parent
for label,command in [('source-guards',['python3','-B','scripts/check-source-guards.py']),('identity-refresh',['python3','-B','scripts/intl_source_identities.py','--write'])]:
 code=subprocess.call([sys.executable,'-B',str(root/'run_check.py'),label,*command])
 if code:sys.exit(code)
