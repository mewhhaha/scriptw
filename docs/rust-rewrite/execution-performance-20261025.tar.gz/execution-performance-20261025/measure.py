import argparse,hashlib,json,os,pathlib,resource,subprocess,time
root=pathlib.Path(__file__).resolve().parent
repo=root.parent.parent
parser=argparse.ArgumentParser();parser.add_argument('product');parser.add_argument('label');parser.add_argument('--samples',type=int,default=3);parser.add_argument('--warmups',type=int,default=3);parser.add_argument('--cases',nargs='*');parser.add_argument('--reverse',action='store_true');a=parser.parse_args()
product=root/a.product
out=root/a.label;out.mkdir(exist_ok=False)
fixtures=repo/'crates/scriptw-cli/tests/fixtures/v8_execution_hotpaths'
plan=json.loads((fixtures/'manifest.json').read_text())
identity=json.loads(subprocess.check_output([str(product/'scriptw'),'compiler-identity']))
report={'complete':False,'product':a.product,'label':a.label,'compiler_identity':identity,'runtime_runner_sha256':hashlib.file_digest((product/'runtime_baseline').open('rb'),'sha256').hexdigest(),'samples':a.samples,'warmups':a.warmups,'case_results':[],'affinity':sorted(os.sched_getaffinity(0)),'loadavg_start':list(os.getloadavg()),'boundary':'ordinary precompiled source, fresh Store/Realm or V8 context, execution+completion only; construction/checksum included; no subtracting empty program','memory':'process RSS and GC capacity; not allocation count or live JS bytes'}
def save(): (out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
save()
for case in plan['execution']:
 name=case['file']
 if a.cases and name not in a.cases:continue
 row={'file':name,'source_sha256':hashlib.file_digest((fixtures/name).open('rb'),'sha256').hexdigest(),'expected_stdout':case['stdout'],'runtimes':{}}
 order=['v8','wasmtime'] if a.reverse else ['wasmtime','v8']
 for runtime in order:
  label=out/(name+'-'+runtime); artifacts=out/(name+'-wasm')
  if runtime=='wasmtime':
   artifacts.mkdir();command=[str(product/'runtime_baseline'),str(fixtures),str(a.samples),str(a.warmups),name,str(artifacts)]
  else:command=['node',str(repo/'crates/scriptw-cli/tests/fixtures/v8_baseline/node-runtime.cjs'),str(fixtures),str(a.samples),str(a.warmups),name]
  env=dict(os.environ,SCRIPTW_CACHE_DIR=str(out/'execution-cache'));env.pop('NODE_OPTIONS',None);env.pop('NODE_COMPILE_CACHE',None);env['NODE_DISABLE_COMPILE_CACHE']='1'
  begin=time.monotonic()
  with label.with_suffix(label.suffix+'.stdout').open('wb') as stdout,label.with_suffix(label.suffix+'.stderr').open('wb') as stderr:
   result=subprocess.run(command,stdout=stdout,stderr=stderr,env=env,timeout=900)
  receipt={'command':command,'exit_code':result.returncode,'wall_seconds':time.monotonic()-begin,'stderr_file':label.name+'.stderr','stdout_file':label.name+'.stdout'}
  row['runtimes'][runtime]=receipt
  if result.returncode:
   report['failed_case']=row;save();raise SystemExit('benchmark failed '+name+' '+runtime)
  data=json.loads(label.with_suffix(label.suffix+'.stdout').read_text());observations=data['cases'][0]['observations']
  assert len(observations)==a.samples+a.warmups
  assert all(x['stdout']==case['stdout'] for x in observations)
  assert data['cases'][0]['source_sha256']==row['source_sha256']
  receipt['data']=data
 report['case_results'].append(row);save()
 import statistics
 print(name,*(runtime+':'+str(round(statistics.median(x['execution_ns'] for x in row['runtimes'][runtime]['data']['cases'][0]['observations'] if not x['warmup'])/1e6,3))+'ms' for runtime in order),flush=True)
report['complete']=True;report['loadavg_end']=list(os.getloadavg());save()
