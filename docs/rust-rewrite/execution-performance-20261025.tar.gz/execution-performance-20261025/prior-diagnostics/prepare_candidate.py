import json,pathlib,shutil,subprocess,sys
root=pathlib.Path(__file__).resolve().parent
def run(command):
 code=subprocess.call(command)
 if code:sys.exit(code)
run([sys.executable,'-B',str(root/'focus.py')])
run([sys.executable,'-B',str(root/'run_check.py'),'release-final','python3','-B','target/execution-performance-20261025/build_product.py'])
product=root/'candidate';product.mkdir(exist_ok=False)
for source,name in [('/tmp/scriptw-v8-target-20261024/release/scriptw','scriptw'),('/tmp/scriptw-v8-target-20261024/release/examples/runtime_baseline','runtime_baseline'),('/tmp/scriptw-v8-target-20261024/release/examples/runtime_boundaries','runtime_boundaries')]:shutil.copy2(source,product/name)
(product/'identity.json').write_bytes(subprocess.check_output([str(product/'scriptw'),'compiler-identity']))
run([sys.executable,'-B',str(root/'validate_inventory.py')])
run([sys.executable,'-B',str(root/'run_check.py'),'candidate-screen','python3','-B','target/execution-performance-20261025/measure.py','candidate','candidate-screen-data','--samples','3','--warmups','3'])
print('FINAL FOCUSED CHECKS AND ALL17 CANDIDATE OUTPUTS PASSED; INVENTORY VERIFIED',flush=True)
