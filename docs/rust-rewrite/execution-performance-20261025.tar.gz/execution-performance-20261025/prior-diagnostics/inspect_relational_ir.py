"""Root-only standalone IR diagnostic using actual selected Cargo rlib paths."""
import json
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
selected = {name: set() for name in ["scriptw_ir", "scriptw_front"]}
with (root / "cargo-product.jsonl").open() as stream:
    for line in stream:
        if '"reason":"compiler-artifact"' not in line and '"reason": "compiler-artifact"' not in line:
            continue
        row = json.loads(line)
        name = row.get("target", {}).get("name")
        if name in selected and row["profile"]["opt_level"] == "3":
            selected[name].update(Path(path) for path in row["filenames"] if path.endswith(".rlib"))
assert all(len(paths) == 1 for paths in selected.values()), selected
libraries = {name: paths.pop() for name, paths in selected.items()}
assert all(path.is_file() for path in libraries.values())
assert len({path.parent for path in libraries.values()}) == 1
binary = root / "inspect_relational_ir"
command = ["rustc", "--edition=2021", "-C", "opt-level=0", "-C", "codegen-units=1",
           "-C", "link-arg=-fuse-ld=lld", str(root / "inspect_relational_ir.rs"),
           "-L", "dependency=" + str(next(iter(libraries.values())).parent), "-o", str(binary)]
for name, path in libraries.items():
    command.extend(["--extern", name + "=" + str(path)])
print("Standalone diagnostic command:", command, flush=True)
subprocess.run(command, check=True)
guard = root / "scalar-predicate-guard.js"
guard.write_text("function hot() { var index=0; while(+index<32) { index=index+1; } return index; } hot();\n")
fixtures = root.parent.parent / "crates/scriptw-cli/tests/fixtures/v8_execution_hotpaths"
result = subprocess.run([str(binary), str(fixtures / "integer.js"),
                         str(fixtures / "numeric-loop-50000.js"), str(guard)],
                        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
(root / "relational-ir-inspection.log").write_text(result.stdout)
print(result.stdout, end="")
sys.exit(result.returncode)
