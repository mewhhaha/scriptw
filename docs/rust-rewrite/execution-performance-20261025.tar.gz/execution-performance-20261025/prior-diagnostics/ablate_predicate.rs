//! Experimental artifact-only predicate ablation. This does not change Scriptw.
use scriptw_engine::{
    Artifact, CompileOptions, CompilerIdentity, CompilerSourceRevision, Engine, ExecutionBackend,
    HostOutputEvent, ObservedCompletion, RealmBuilder, WasmProcessMemoryObservation,
    WasmProcessMemorySample, WasmProfileGcInitialCapacity, WasmProfileNativeMode,
    WasmProfileRegisterAllocation, WasmRuntimeProfileOptions,
};
use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::{collections::BTreeMap, fs, io::Write, path::Path};
use wasmparser::{Operator, Parser, Payload};

const SOURCE: &str = "4b325de348f049a638f2e57fdc9749c74d926cbc";
const EXPECTED: &str = "730532261\n";
const WARMUPS: usize = 10;
const SAMPLES: usize = 7;

fn sha(bytes: &[u8]) -> String { format!("{:x}", Sha256::digest(bytes)) }
fn write_new(path: &Path, bytes: &[u8]) -> Result<(), String> {
    fs::OpenOptions::new().write(true).create_new(true).open(path)
        .and_then(|mut f| f.write_all(bytes)).map_err(|e| format!("{}: {e}", path.display()))
}
fn read_u32(bytes: &[u8], cursor: &mut usize) -> Result<u32, String> {
    let mut value = 0u32;
    for shift in (0..35).step_by(7) {
        let byte = *bytes.get(*cursor).ok_or("truncated u32 LEB")?;
        *cursor += 1;
        if shift == 28 && byte & 0xf0 != 0 { return Err("invalid u32 LEB".into()); }
        value |= u32::from(byte & 127) << shift;
        if byte & 128 == 0 { return Ok(value); }
    }
    Err("invalid u32 LEB".into())
}
fn put_u32(mut n: u32, bytes: &mut Vec<u8>) {
    loop {
        let byte = (n & 127) as u8;
        n >>= 7;
        bytes.push(byte | if n == 0 { 0 } else { 128 });
        if n == 0 { break; }
    }
}

fn names(bytes: &[u8]) -> Result<BTreeMap<u32, String>, String> {
    let mut out = BTreeMap::new();
    for payload in Parser::new(0).parse_all(bytes) {
        if let Payload::CustomSection(section) = payload.map_err(|e| e.to_string())? {
            if let wasmparser::KnownCustom::Name(subsections) = section.as_known() {
                for subsection in subsections {
                    if let wasmparser::Name::Function(map) = subsection.map_err(|e| e.to_string())? {
                        for naming in map {
                            let naming = naming.map_err(|e| e.to_string())?;
                            out.insert(naming.index, naming.name.to_string());
                        }
                    }
                }
            }
        }
    }
    Ok(out)
}

/// Select by decoded operators, never by scanning arbitrary immediate bytes.
/// The cloned exact-context source body carries the same source predicate.
fn patch(bytes: &[u8]) -> Result<(Vec<u8>, Value), String> {
    let names = names(bytes)?;
    let targets: BTreeMap<_, _> = names.iter()
        .filter(|(_, name)| name.starts_with("js::workload#"))
        .map(|(&i, name)| (i, name.clone())).collect();
    if targets.len() != 2 { return Err(format!("expected two workload versions: {targets:?}")); }
    let mut imported = 0u32;
    let mut defined = 0u32;
    let mut patches: BTreeMap<usize, Vec<usize>> = BTreeMap::new();
    let mut evidence = Vec::new();
    for payload in Parser::new(0).parse_all(bytes) {
        match payload.map_err(|e| e.to_string())? {
            Payload::ImportSection(reader) => {
                for import in reader.into_imports() {
                    if matches!(import.map_err(|e| e.to_string())?.ty,
                        wasmparser::TypeRef::Func(_) | wasmparser::TypeRef::FuncExact(_)) { imported += 1; }
                }
            }
            Payload::CodeSectionEntry(body) => {
                let index = imported + defined;
                if let Some(name) = targets.get(&index) {
                    let range = body.range();
                    let mut reader = body.get_operators_reader().map_err(|e| e.to_string())?;
                    let mut previous_reinterpret = false;
                    let mut previous_zero = false;
                    let mut offsets = Vec::new();
                    let mut decoded = Vec::new();
                    while !reader.eof() {
                        let start = reader.original_position();
                        let op = reader.read().map_err(|e| e.to_string())?;
                        let end = reader.original_position();
                        if matches!(op, Operator::F64Lt) && previous_zero {
                            if bytes.get(start..end) != Some(&[0x63][..]) { return Err("F64Lt encoding differs".into()); }
                            offsets.push(end);
                            decoded.push(json!({"instruction_start": start, "insert_at_original_offset": end,
                                "body_relative_insert_offset": end-range.start,
                                "before_operators": ["F64ReinterpretI64", "F64Const(0.0)", "F64Lt"],
                                "insert_operators": ["I32Eqz", "I32Eqz"], "insert_hex":"4545"}));
                        }
                        previous_zero = previous_reinterpret && matches!(op, Operator::F64Const { value } if value.bits() == 0);
                        previous_reinterpret = matches!(op, Operator::F64ReinterpretI64);
                    }
                    if offsets.len() != 1 { return Err(format!("{name}: expected exactly one decoded generic F64Lt(result,0), found {}",offsets.len())); }
                    patches.insert(range.start, offsets);
                    evidence.push(json!({"function_index":index,"name":name,"original_body_start":range.start,
                        "original_body_end":range.end,"original_body_sha256":sha(&bytes[range.clone()]),"patches":decoded}));
                }
                defined += 1;
            }
            _ => {}
        }
    }
    if evidence.len() != targets.len() { return Err("not every named workload body was found".into()); }
    // Rebuild only code section/body length prefixes. Every other section is copied literally.
    let mut result = bytes.get(..8).ok_or("missing Wasm header")?.to_vec();
    let mut position = 8;
    let mut code_sections = 0;
    let mut changed_bodies = 0;
    let mut other_sections = Vec::new();
    while position < bytes.len() {
        let section_start = position;
        let id = bytes[position];
        position += 1;
        let size = read_u32(bytes, &mut position)? as usize;
        let section_end = position.checked_add(size).ok_or("section range overflow")?;
        if section_end > bytes.len() { return Err("section truncated".into()); }
        if id == 10 {
            code_sections += 1;
            let mut cursor = position;
            let count = read_u32(bytes, &mut cursor)?;
            let mut code = Vec::new();
            put_u32(count, &mut code);
            for _ in 0..count {
                let size_prefix_start = cursor;
                let size = read_u32(bytes, &mut cursor)? as usize;
                let body_start = cursor;
                let body_end = cursor.checked_add(size).ok_or("body range overflow")?;
                if body_end > section_end { return Err("body truncated".into()); }
                if let Some(insertions) = patches.get(&body_start) {
                    let mut body = Vec::new();
                    let mut begin = body_start;
                    for &offset in insertions {
                        if offset <= begin || offset >= body_end { return Err("invalid insertion range".into()); }
                        body.extend_from_slice(&bytes[begin..offset]);
                        body.extend_from_slice(&[0x45,0x45]);
                        begin = offset;
                    }
                    body.extend_from_slice(&bytes[begin..body_end]);
                    put_u32(u32::try_from(body.len()).map_err(|e| e.to_string())?, &mut code);
                    code.extend_from_slice(&body);
                    changed_bodies += 1;
                } else { code.extend_from_slice(&bytes[size_prefix_start..body_end]); }
                cursor = body_end;
            }
            if cursor != section_end { return Err("trailing code section bytes".into()); }
            result.push(10);
            put_u32(u32::try_from(code.len()).map_err(|e| e.to_string())?, &mut result);
            result.extend_from_slice(&code);
        } else {
            result.extend_from_slice(&bytes[section_start..section_end]);
            other_sections.push(json!({"id":id,"original_start":section_start,"bytes":section_end-section_start,
                "sha256":sha(&bytes[section_start..section_end])}));
        }
        position = section_end;
    }
    if code_sections != 1 || changed_bodies != 2 || names != names_of_patched(&result)? {
        return Err("unexpected sections/body/name change".into());
    }
    for module in [bytes, &result] {
        wasmparser::Validator::new_with_features(wasmparser::WasmFeatures::all())
            .validate_all(module).map_err(|e| format!("Wasm validation: {e}"))?;
    }
    Ok((result, json!({"scope":"experimental-artifact-only", "changed_bodies":changed_bodies,
        "all_non_code_sections_copied_byte_for_byte":true,"all_other_bodies_copied_byte_for_byte":true,
        "inserted_opcode_bytes":4,"functions":evidence,"unchanged_sections":other_sections,
        "validation":"wasmparser-0.245.1 all features; actual Engine validates and admits on every execution",
        "semantics":"Wasm F64Lt returns canonical 0 or 1; eqz(eqz(x)) == x for those results"})))
}
fn names_of_patched(bytes: &[u8]) -> Result<BTreeMap<u32,String>,String> { names(bytes) }

fn runtime(artifact: &Artifact) -> Result<Value,String> {
    let r = artifact.runtime.as_ref().ok_or("expected linked R")?;
    Ok(json!({"key":r.key().as_bytes().iter().map(|v|format!("{v:02x}")).collect::<String>(),
        "wasm_sha256":sha(r.bytes()),"wasm_bytes":r.bytes().len()}))
}
fn median(mut values: Vec<u64>) -> f64 {
    values.sort_unstable();
    if values.len()%2 == 0 {
        (values[values.len()/2-1] as f64 + values[values.len()/2] as f64)/2.0
    } else { values[values.len()/2] as f64 }
}
fn run() -> Result<(),String> {
    let args: Vec<_> = std::env::args().skip(1).collect();
    if args.len()!=3 { return Err("usage: ablate_predicate INTEGER_JS ORIGINAL_P_WASM NEW_OUTPUT_DIR".into()); }
    let out = Path::new(&args[2]);
    fs::create_dir(out).map_err(|e|format!("new diagnostic output directory: {e}"))?;
    let identity = CompilerIdentity::current()?;
    let revision = match identity.source_revision() {
        CompilerSourceRevision::GitCommit(commit) => commit.as_str(),
        CompilerSourceRevision::UnversionedArchive => return Err("unversioned linked engine".into()),
    };
    if revision != SOURCE { return Err(format!("linked engine source {revision} differs from final source")); }
    scriptw_engine::configure_compilation_jobs(1)?;
    let source = fs::read_to_string(&args[0]).map_err(|e|e.to_string())?;
    let engine = Engine::new(RealmBuilder::new().build());
    let compilation = engine.profile_script_compilation(&source,CompileOptions{
        filename:Some("integer.js".into()),..CompileOptions::default()}).map_err(|e|e.to_string())?;
    let original = compilation.artifact;
    let cohort_p = fs::read(&args[1]).map_err(|e|e.to_string())?;
    if original.bytes != cohort_p { return Err(format!("diagnostic compiler P {} differs from accepted cohort P {}",sha(&original.bytes),sha(&cohort_p))); }
    let (patched_bytes, patch_evidence) = patch(&original.bytes)?;
    let mut patched = original.clone();
    patched.bytes = patched_bytes;
    if original.runtime != patched.runtime || original.compilation_policy != patched.compilation_policy
        || original.description != patched.description || original.debug_dump != patched.debug_dump {
        return Err("artifact fields other than P bytes differ".into());
    }
    let r = runtime(&original)?;
    if r != runtime(&patched)? { return Err("linked runtime changed".into()); }
    write_new(&out.join("original.wasm"),&original.bytes)?;
    write_new(&out.join("eqz-twice.wasm"),&patched.bytes)?;
    let load_start = fs::read_to_string("/proc/loadavg").ok();
    let actual_policy = WasmRuntimeProfileOptions::new(WasmProfileNativeMode::Fast,
        WasmProfileGcInitialCapacity::MiB16,WasmProfileRegisterAllocation::SinglePass);
    let mut rounds = Vec::new();
    let mut pooled = BTreeMap::<&str, Vec<u64>>::new();
    for (round,(label,artifact)) in [("original-a",&original),("eqz-twice-b",&patched),
        ("eqz-twice-c",&patched),("original-d",&original)].into_iter().enumerate() {
        let product = if label.starts_with("original") { "original" } else { "eqz-twice" };
        let mut observations = Vec::new();
        let mut measured = Vec::new();
        for index in 0..WARMUPS+SAMPLES {
            // Same Engine, fresh Store/Realm for each invocation; ordinary automatic policy.
            let p = engine.profile_wasm_execution(artifact,Some(60_000),false).map_err(|e|format!("{label}/{index}: {e}"))?;
            if p.options != actual_policy { return Err(format!("{label}: actual policy {:?}",p.options)); }
            let mut output=String::new();
            for event in &p.outcome.output_events {
                match event { HostOutputEvent::PrintLine(line)=>{output.push_str(line);output.push('\n');},
                    HostOutputEvent::ReportedException(line)=>return Err(format!("{label}: {line}")) }
            }
            if p.outcome.backend_used!=ExecutionBackend::WasmAot
                || !matches!(p.outcome.completion,ObservedCompletion::Normal(_)) || output!=EXPECTED {
                return Err(format!("{label}: unexpected execution {:?}; stdout {output:?}",p.outcome));
            }
            let ns=u64::try_from(p.timings.execution_and_completion.as_nanos()).map_err(|e|e.to_string())?;
            if index>=WARMUPS { measured.push(ns);pooled.entry(product).or_default().push(ns); }
            let rss=match &p.process_memory {
                WasmProcessMemoryObservation::Sampled(sample)=>json!({"status":"sampled",
                    "scope":"runtime-invocation-process-rss","interval_ns":WasmProcessMemorySample::SAMPLE_INTERVAL.as_nanos(),
                    "elapsed_ns":sample.elapsed().as_nanos(),"sample_count":sample.sample_count(),
                    "initial_rss_bytes":sample.initial_rss_bytes(),"final_rss_bytes":sample.final_rss_bytes(),
                    "maximum_rss_bytes":sample.maximum_rss_bytes()}),
                WasmProcessMemoryObservation::Unavailable(reason)=>json!({"status":"unavailable","reason":format!("{reason:?}")})};
            observations.push(json!({"index":index,"warmup":index<WARMUPS,"execution_ns":ns,
                "backend":p.outcome.backend_used.as_str(),"normal_completion":true,"stdout":output,
                "phases_ns":{"admission":p.timings.admission.as_nanos(),"engine":p.timings.engine.as_nanos(),
                    "module":p.timings.module.as_nanos(),"store_and_linker":p.timings.store_and_linker.as_nanos(),
                    "host_import_registration":p.timings.host_import_registration.as_nanos(),
                    "instantiate":p.timings.instantiate.as_nanos(),"export_lookup":p.timings.export_lookup.as_nanos(),
                    "total":p.timings.total.as_nanos()},
                "memory":{"process_rss":rss,"gc_capacity_before_bytes":p.heap.capacity_before_execution_bytes,
                    "gc_capacity_after_bytes":p.heap.capacity_after_execution_bytes},
                "module_cache":format!("{:?}",p.module_cache),"module_loading":format!("{:?}",p.module_loading),
                "host_import_cache":format!("{:?}",p.host_import_cache),
                "matched_runtime_image_cache":format!("{:?}",p.matched_runtime_image_cache),
                "actual_policy":{"native_mode":p.options.native_mode().as_str(),
                    "gc_initial_mib":p.options.initial_gc_capacity().mebibytes(),
                    "register_allocation":p.options.register_allocation().as_str(),
                    "inlining":format!("{:?}",p.options.native_inlining())},"runtime_policy":p.runtime_policy}));
        }
        rounds.push(json!({"index":round,"label":label,"variant":product,"p_sha256":sha(&artifact.bytes),
            "samples_ns":measured,"median_execution_ns":median(measured.clone()),"observations":observations}));
    }
    let original_median=median(pooled["original"].clone());
    let patched_median=median(pooled["eqz-twice"].clone());
    let mut adjacent_pairs = Vec::new();
    for (label, baseline, candidate) in [("AB",0,1),("DC",3,2)] {
        let a=rounds[baseline]["median_execution_ns"].as_f64().ok_or("round median missing")?;
        let b=rounds[candidate]["median_execution_ns"].as_f64().ok_or("round median missing")?;
        adjacent_pairs.push(json!({"pair":label,"original_median_ns":a,"eqz_twice_median_ns":b,
            "median_change_percent":100.0*(b/a-1.0)}));
    }
    let report=json!({"schema":"scriptw-experimental-predicate-bytepatch-v1","complete":true,
        "accepted_product_cohort":false,"source_commit":revision,
        "source_fingerprint":identity.source_fingerprint().to_string(),
        "diagnostic_executable_sha256":identity.executable_sha256().to_string(),
        "file":"integer.js","source_sha256":sha(source.as_bytes()),"expected_stdout":EXPECTED,
        "original_p_sha256":sha(&original.bytes),"patched_p_sha256":sha(&patched.bytes),
        "original_p_bytes":original.bytes.len(),"patched_p_bytes":patched.bytes.len(),
        "accepted_cohort_original_p_exactly_equal":true,"same_linked_runtime":r,
        "artifact_fields_except_bytes_unchanged":true,"patch":patch_evidence,
        "warmups_per_round":WARMUPS,"measured_samples_per_round":SAMPLES,"round_order":"ABBA",
        "invocation_boundary":"same Engine; fresh Store/Realm per profile_wasm_execution",
        "rounds":rounds,"pooled":{"original":{"samples_ns":pooled["original"],"median_ns":original_median},
            "eqz-twice":{"samples_ns":pooled["eqz-twice"],"median_ns":patched_median}},
        "median_change_percent":100.0*(patched_median/original_median-1.0),
        "adjacent_pairs":adjacent_pairs,
        "loadavg_start":load_start,"loadavg_end":fs::read_to_string("/proc/loadavg").ok(),
        "notes":["Experimental Wasm byte patch, not shipped compiler output and excluded from accepted performance totals.",
            "Same R bytes/key and artifact metadata; only two canonical i32 predicate no-ops added per source-body version.",
            "Descriptive elapsed execution/completion intervals under observed ambient machine load; not CPU clocks, significance, causal attribution or idle-machine repeatability.",
            "GC capacities and sampled whole-process RSS do not measure live object bytes or allocation counts."]});
    write_new(&out.join("report.json"),serde_json::to_string_pretty(&report).map_err(|e|e.to_string())?.as_bytes())?;
    println!("{}",serde_json::to_string(&report).map_err(|e|e.to_string())?);
    Ok(())
}
fn main() { if let Err(error)=run() { eprintln!("{error}");std::process::exit(1); } }
