//! Read-only compiler-IR diagnostic; it does not emit or execute Wasm.
use scriptw_front::{parse, ParseOptions};
use scriptw_ir::{HostSurfacePolicy, StatementIr};

fn statement(statement: &StatementIr) {
    match statement {
        StatementIr::For { test, update, body, .. } => {
            println!("FOR TEST:\n{test:#?}\nFOR UPDATE:\n{update:#?}");
            statement_body(body);
        }
        StatementIr::While { condition, body } | StatementIr::DoWhile { condition, body } => {
            println!("LOOP CONDITION:\n{condition:#?}");
            statement_body(body);
        }
        StatementIr::Block(block) => {
            for item in &block.statements { statement_body(item); }
        }
        StatementIr::LexicalBlock(items) => {
            for item in items { statement_body(item); }
        }
        StatementIr::EmptyStatementCompletion(item) => statement_body(item.statement()),
        _ => {}
    }
}

fn statement_body(item: &StatementIr) {
    statement(item);
}

fn main() {
    for path in std::env::args().skip(1) {
        let source = std::fs::read_to_string(&path).expect("read diagnostic JavaScript");
        let parsed = parse(&source, ParseOptions::script()).expect("parse diagnostic JavaScript");
        let program = scriptw_ir::lower_with_host_surface_policy(&parsed, HostSurfacePolicy::Test262);
        assert!(program.is_wasm_supported(), "{:?}", program.diagnostics);
        let script = program.script.as_ref().expect("lowered script");
        println!("SOURCE {path}\n{source}");
        for function in &script.functions {
            if function.name == "workload" || function.name == "hot" {
                println!("FUNCTION {}", function.name);
                for item in &function.body.statements { statement_body(item); }
            }
        }
    }
}
