"""Root-only artifact ablation. Default only prints the existing-rlib link/run plan.

Run --run under the one-CPU/4-GiB limited_verification wrapper. No Cargo build,
product edits, source transformations, R changes or accepted-cohort replacement.
"""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys

BASE = Path(__file__).resolve().parent
REPO = BASE.parent.parent
SOURCE = "4b325de348f049a638f2e57fdc9749c74d926cbc"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run", action="store_true")
    parser.add_argument("--output", default="predicate-ablation-data")
    args = parser.parse_args()
    selected = {name: set() for name in ["scriptw_engine", "wasmparser", "serde_json", "sha2"]}
    metadata = BASE / "cargo-product.jsonl"
    for line in metadata.read_text().splitlines():
        row = json.loads(line)
        if row.get("reason") != "compiler-artifact" or row.get("profile", {}).get("opt_level") != "3":
            continue
        name = row.get("target", {}).get("name")
        if name not in selected:
            continue
        if name == "wasmparser" and not row["package_id"].endswith("#wasmparser@0.245.1"):
            continue
        if name == "sha2" and not row["package_id"].endswith("#sha2@0.10.9"):
            continue
        selected[name].update(Path(p) for p in row["filenames"] if p.endswith(".rlib"))
    if not all(len(paths) == 1 for paths in selected.values()):
        raise ValueError(f"ambiguous or missing release target rlibs: {selected}")
    libraries = {name: next(iter(paths)) for name, paths in selected.items()}
    if not all(path.is_file() for path in libraries.values()):
        raise ValueError("selected rlib missing")
    if len({path.parent for path in libraries.values()}) != 1:
        raise ValueError("selected rlibs do not share target dependency directory")
    binary = BASE / "ablate_predicate"
    command = ["rustc", "--edition=2021", "-C", "opt-level=0", "-C", "codegen-units=1",
               "-C", "link-arg=-fuse-ld=lld", str(BASE / "ablate_predicate.rs"),
               "-L", "dependency=" + str(next(iter(libraries.values())).parent), "-o", str(binary)]
    for name, path in libraries.items():
        command.extend(["--extern", name + "=" + str(path)])
    native_paths=set()
    for line in metadata.read_text().splitlines():
        row=json.loads(line)
        if row.get("reason")=="build-script-executed":
            native_paths.update(row.get("linked_paths",[]))
    for path in sorted(native_paths):
        command.extend(["-L",path])
    output = BASE / args.output
    if output.parent != BASE or output.exists():
        raise ValueError("output must be a new direct child directory of evidence root")
    fixture = REPO / "crates/scriptw-cli/tests/fixtures/v8_execution_hotpaths/integer.js"
    original = BASE / "candidate-round-b-data/integer.js-wasm/integer.js.wasm"
    execute = [str(binary), str(fixture), str(original), str(output)]
    plan = {"source_commit": SOURCE, "experimental_only": True, "compile_command": command,
            "run_command": execute, "cargo_metadata_sha256": hashlib.sha256(metadata.read_bytes()).hexdigest(),
            "selected_libraries": {name: {"path": str(path), "bytes": path.stat().st_size}
                                   for name, path in libraries.items()},
            "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            "rust_source_sha256": hashlib.sha256((BASE / "ablate_predicate.rs").read_bytes()).hexdigest(),
            "fixture_sha256": hashlib.sha256(fixture.read_bytes()).hexdigest(),
            "accepted_cohort_p_sha256": hashlib.sha256(original.read_bytes()).hexdigest()}
    print(json.dumps(plan, indent=2), flush=True)
    if not args.run:
        return
    head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=REPO, text=True).strip()
    diff = subprocess.check_output(["git", "diff", "--binary", "HEAD", "--", "crates", "Cargo.toml", "Cargo.lock"], cwd=REPO)
    if head != SOURCE or diff:
        raise ValueError("product checkout differs from frozen final source")
    subprocess.run(command, check=True, cwd=REPO)
    plan["diagnostic_executable_sha256"] = hashlib.sha256(binary.read_bytes()).hexdigest()
    # Only the diagnostic directory may be created by the Rust executable.
    stdout = BASE / (args.output + ".stdout")
    stderr = BASE / (args.output + ".stderr")
    if stdout.exists() or stderr.exists():
        raise ValueError("refusing to overwrite earlier diagnostic observations")
    with stdout.open("xb") as out, stderr.open("xb") as err:
        result = subprocess.run(execute, cwd=REPO, stdout=out, stderr=err)
    plan.update(exit_code=result.returncode, stdout=stdout.name, stderr=stderr.name,
                stdout_sha256=hashlib.sha256(stdout.read_bytes()).hexdigest(),
                stderr_sha256=hashlib.sha256(stderr.read_bytes()).hexdigest())
    (BASE / (args.output + ".plan.json")).write_text(json.dumps(plan, indent=2) + "\n")
    if result.returncode:
        print(stderr.read_text(errors="replace"), file=sys.stderr)
    else:
        report = json.loads(stdout.read_text())
        if report != json.loads((output / "report.json").read_text()):
            raise ValueError("diagnostic raw stdout differs from saved report")
        if report["diagnostic_executable_sha256"] != plan["diagnostic_executable_sha256"]:
            raise ValueError("diagnostic executable identity mismatch")
        print(json.dumps({"report": str(output / "report.json"), "complete": report["complete"],
                          "original_p_sha256": report["original_p_sha256"],
                          "patched_p_sha256": report["patched_p_sha256"],
                          "median_change_percent": report["median_change_percent"]}, indent=2))
    raise SystemExit(result.returncode)


if __name__ == "__main__":
    main()
