"""Static inspection of preserved native module caches; execute no guest code."""
from compression import zstd
import hashlib
import json
from pathlib import Path
import struct
import subprocess

BASE = Path(__file__).resolve().parent
OUTPUT = BASE / "integer-native-inspection"
OUTPUT.mkdir(exist_ok=True)


def symbols(raw):
    assert raw[:6] == b"\x7fELF\x02\x01", "expected little-endian ELF64"
    header = struct.unpack_from("<16sHHIQQQIHHHHHH", raw)
    offset, size, count = header[6], header[11], header[12]
    sections = [struct.unpack_from("<IIQQQQIIQQ", raw, offset + index * size)
                for index in range(count)]
    result = []
    for section in sections:
        if section[1] not in [2, 11]:
            continue
        names = sections[section[6]]
        strings = raw[names[4]:names[4] + names[5]]
        for start in range(section[4], section[4] + section[5], section[9]):
            name, info, other, index, value, length = struct.unpack_from("<IBBHQQ", raw, start)
            if (info & 15) == 2 and length:
                end = strings.index(b"\0", name)
                result.append({"name": strings[name:end].decode(errors="replace"),
                               "address": value, "bytes": length})
    return result


rows = []
for label in ["baseline-round-a-data", "probe-d67-screen-data", "candidate-round-b-data"]:
    directory = BASE / label / "execution-cache/wasmtime-modules-v1/modules/wasmtime-47.0.0"
    hits = []
    for path in directory.iterdir():
        if not path.is_file() or path.suffix == ".stats":
            continue
        with zstd.ZstdFile(path) as stream:
            raw = stream.read(8 * 1024**2 + 1)
        if len(raw) > 8 * 1024**2 or not raw.startswith(b"\x7fELF"):
            continue
        tags = []
        if "Math.imul".encode("utf-16-le") in raw or b"Math.imul" in raw:
            tags.append("literal Math.imul")
        if struct.pack("<d", 1664525.0) in raw:
            tags.append("LCG multiplier bits")
        if not tags:
            continue
        target = OUTPUT / (label + "-" + path.name + ".elf")
        target.write_bytes(raw)
        functions = symbols(raw)
        named = [symbol for symbol in functions if "workload" in symbol["name"]]
        dumps = []
        for index, symbol in enumerate(named):
            output = OUTPUT / (label + "-" + path.name + "-" + str(index) + ".asm")
            command = ["objdump", "-d", "--no-show-raw-insn",
                       "--disassemble=" + symbol["name"], str(target)]
            with output.open("w") as stream:
                subprocess.run(command, stdout=stream, stderr=subprocess.STDOUT, check=True)
            dumps.append(output.name)
        hits.append({"cache_file": str(path.relative_to(BASE)), "cache_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                     "elf_file": target.name, "elf_sha256": hashlib.sha256(raw).hexdigest(),
                     "identifying_markers": tags, "native_functions": functions, "assembly_files": dumps})
    rows.append({"round": label, "candidate_modules": hits})
report = {"scope": "static compressed-cache ELF/symbol/disassembly inspection, no executable or JavaScript run",
          "rows": rows}
(OUTPUT / "report.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps({"report": str(OUTPUT / "report.json"),
                  "candidates": {row["round"]: len(row["candidate_modules"]) for row in rows}}, indent=2))
