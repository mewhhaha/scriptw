function hot() { var index=0; while(+index<32) { index=index+1; } return index; } hot();
