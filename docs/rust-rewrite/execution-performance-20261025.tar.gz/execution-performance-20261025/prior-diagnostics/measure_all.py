import pathlib,subprocess,sys
root=pathlib.Path(__file__).resolve().parent
for product,label,reverse in [('candidate','candidate-round-b',True),('candidate','candidate-round-c',False),('baseline','baseline-round-d',True)]:
 command=['python3','-B',str(root/'measure.py'),product,label+'-data','--samples','7','--warmups','10']
 if reverse:command.append('--reverse')
 code=subprocess.call([sys.executable,'-B',str(root/'run_check.py'),label,*command])
 if code:sys.exit(code)
for product,label,reverse in [('baseline','baseline-calls-round-a',False),('candidate','candidate-calls-round-b',True),('candidate','candidate-calls-round-c',False),('baseline','baseline-calls-round-d',True)]:
 command=['python3','-B',str(root/'measure_calls.py'),product,label+'-data']
 if reverse:command.append('--reverse')
 code=subprocess.call([sys.executable,'-B',str(root/'run_check.py'),label,*command])
 if code:sys.exit(code)
for script in ['analyze.py','analysis_calls.py']:
 code=subprocess.call([sys.executable,'-B',str(root/script)])
 if code:sys.exit(code)
