import datetime, hashlib, json, os, pathlib, re, resource, subprocess, sys, time
root=pathlib.Path(__file__).resolve().parent
label=sys.argv[1]
command=sys.argv[2:]
log=root/(label+'.log')
source_head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
source_diff=hashlib.sha256(subprocess.check_output(['git','diff','--binary','HEAD','--','crates','Cargo.toml','Cargo.lock'])).hexdigest()
start=time.monotonic()
with log.open('w') as out:
    result=subprocess.run(command,stdout=out,stderr=subprocess.STDOUT)
text=log.read_text(errors='replace')
counts=re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out',text)
receipt={'source_head':source_head,'source_patch_sha256':source_diff,'label':label,'command':command,'exit_code':result.returncode,'seconds':time.monotonic()-start,'date':datetime.datetime.now(datetime.timezone.utc).isoformat(),'child_maxrss_kib':resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,'cpu_affinity':sorted(os.sched_getaffinity(0)),'test_results':counts,'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest(),'log':log.name}
executables=re.findall(r'Running [^\n]*\((/[^)]+)\)',text)
if pathlib.Path(command[0]).is_file(): executables.append(command[0])
receipt['resource_environment']={key:os.environ.get(key) for key in ['CARGO_BUILD_JOBS','SCRIPTW_JOBS','RUST_TEST_THREADS','RAYON_NUM_THREADS','SCRIPTW_MODULE_MEMORY_CACHE_ENTRIES','SCRIPTW_MODULE_MEMORY_CACHE_LIMIT_BYTES']}
receipt['executables']=[]
for name in sorted(set(executables)):
    executable=pathlib.Path(name).resolve()
    if executable.is_file():
        with executable.open('rb') as stream: digest=hashlib.file_digest(stream,'sha256').hexdigest()
        receipt['executables'].append({'path':str(executable),'sha256':digest,'bytes':executable.stat().st_size})
for line in pathlib.Path('/proc/self/cgroup').read_text().splitlines():
    if line.startswith('0::'):
        cg=pathlib.Path('/sys/fs/cgroup')/line[3:].lstrip('/')
        for name in ['memory.max','memory.swap.max','memory.peak','memory.events','memory.oom.group','cpuset.cpus.effective']:
            try: receipt[name]= (cg/name).read_text().strip()
            except OSError: pass
(root/(label+'.json')).write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2),flush=True)
if result.returncode:
    lines=text.splitlines()
    selected=set(range(max(0,len(lines)-18),len(lines)))
    for i,line in enumerate(lines):
        if line.startswith('error') or line.startswith('failures:'):
            selected.update(range(max(0,i-2),min(len(lines),i+24)))
    print('\n'.join(lines[i] for i in sorted(selected)),flush=True)
else:
    print('\n'.join(text.splitlines()[-8:]),flush=True)
sys.exit(result.returncode)
