#!/usr/bin/env python3
"""Validate closed native, selected Test262 and balanced runtime evidence.

Default mode reads only. --publish writes one new documentation checkpoint.
No product, test or compiler executable is invoked by this tool.
"""
from __future__ import annotations

import argparse
import gzip
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tarfile
import types

BASE = Path(__file__).resolve().parent
REPO = BASE.parent.parent
SOURCE = "4b325de348f049a638f2e57fdc9749c74d926cbc"
DIAGNOSTIC_SOURCE = "d67cbfbf02f3e8566a23f576ec48493d3d37646a"
BASELINE_SOURCE = "4ad59d1ebbc64c9e3384aee9cefd19e3c8b8e92d"
BASELINE_CHECKOUT = "d41d6c9d2cb4b69e6cae783d4c868f53677fa46c"
BASELINE_PATCH = "6af747d35ab196853d7d8218b2a3a62da4ada2e7a11047432a262d1ef055a2d4"
BASELINE_BOUNDARIES_SHA256 = "a40a259a8c52a9b17b275faf04703ef2f80a2d5c5e047838b3e60e2315367f78"
EMPTY_PATCH = hashlib.sha256(b"").hexdigest()
STEM = "execution-performance-20261025"
PREFIX = STEM + "/"
BUDGET = 4 * 1024**3
SUMMARY_RE = re.compile(r"test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out")
KNOWN = {
    "sloppy-script:annexB/language/function-code/block-decl-func-skip-arguments.js",
    "sloppy-script:intl402/Temporal/ZonedDateTime/links.js",
    "strict-script:intl402/Temporal/ZonedDateTime/links.js",
    "sloppy-script:staging/sm/lexical-environment/block-scoped-functions-annex-b-label.js",
}
ROUNDS = ["baseline-round-a-data", "candidate-round-b-data", "candidate-round-c-data", "baseline-round-d-data"]
CALL_ROUNDS = ["baseline-calls-round-a-data", "candidate-calls-round-b-data", "candidate-calls-round-c-data", "baseline-calls-round-d-data"]
EXPECTED_SCOPES = [
    ("scriptw-aot-wasm", "--lib", None),
    *[("scriptw-aot-wasm", "--test", name) for name in ["emission", "modules_realms", "runtime_link", "structure_async", "structure_builtins", "structure_language"]],
    ("scriptw-engine", "--lib", None),
    *[("scriptw-engine", "--test", name) for name in ["aot_async", "aot_async_generator_returns", "aot_builtins", "aot_gc_entries", "aot_generators", "aot_language", "aot_native_program_templates", "aot_realm_modules", "runtime_cache", "structure", "weak_gc_facility"]],
    ("scriptw-runtime-image", "--lib", None), ("scriptw-ir", "--lib", None),
    ("scriptw-cli", "--example", "runtime_baseline"), ("scriptw-cli", "--example", "runtime_boundaries"),
]


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def read_json(path):
    path = Path(path)
    require(path.is_file() and not path.is_symlink(), f"missing or symlinked evidence: {path}")
    return json.loads(path.read_text())


def member_path(path):
    path = Path(path)
    require(path.is_file() and not path.is_symlink(), f"missing or symlinked archive input: {path}")
    resolved = path.resolve()
    require(resolved.is_relative_to(REPO), f"archive input escaped repository: {path}")
    require(path.stat().st_size < 64 * 1024**2, f"oversized evidence input: {path}")
    require(path.suffix not in {".swbundle", ".v8cache"}, f"session bundle/cache payload excluded: {path}")
    with path.open("rb") as stream:
        require(stream.read(4) != b"\x7fELF", f"binaries excluded from evidence archive: {path}")
    relative = resolved.relative_to(BASE) if resolved.is_relative_to(BASE) else Path("reproduction") / resolved.relative_to(REPO)
    require(not any(part in {"cache", "execution-cache", "native-cache", "tmp", "__pycache__", ".git"} for part in relative.parts), f"temporary/cache input excluded: {path}")
    return PREFIX + relative.as_posix()


class Evidence:
    def __init__(self):
        self.paths = {}
        self.resources = []

    def add(self, path):
        path = Path(path)
        name = member_path(path)
        require(name not in self.paths or self.paths[name].resolve() == path.resolve(), f"conflicting archive name: {name}")
        self.paths[name] = path
        return name

    def resource(self, row, label):
        require(row.get("cpu_affinity") == [0], f"{label}: expected observed one-CPU affinity")
        require(str(row.get("memory.max")) == str(BUDGET) and str(row.get("memory.swap.max")) == "0", f"{label}: missing exact 4-GiB/no-swap cap")
        require(str(row.get("memory.oom.group")) == "1", f"{label}: missing grouped OOM policy")
        events = dict(line.split() for line in row.get("memory.events", "").splitlines())
        require(all(events.get(name) == "0" for name in ["oom", "oom_kill", "oom_group_kill"]), f"{label}: accepted receipt records OOM or missing observations")
        peak = int(row.get("memory.peak", -1))
        require(0 <= peak <= BUDGET, f"{label}: invalid cumulative cgroup peak")
        env = row.get("resource_environment", {})
        for name in ["CARGO_BUILD_JOBS", "SCRIPTW_JOBS", "RUST_TEST_THREADS", "RAYON_NUM_THREADS", "SCRIPTW_MODULE_MEMORY_CACHE_ENTRIES"]:
            require(env.get(name) == "1", f"{label}: nonserial or unbounded retained-cache environment")
        require(env.get("SCRIPTW_MODULE_MEMORY_CACHE_LIMIT_BYTES") == str(64 * 1024**2), f"{label}: cache image limit differs")
        self.resources.append({"label": label, "memory_peak_bytes": peak, "memory_events": events, "cpu_affinity": row["cpu_affinity"]})

    def receipt(self, label, *, exit_code=0, checkout_source=SOURCE, clean_source=True):
        require(re.fullmatch(r"[A-Za-z0-9_-]+", label) is not None, "invalid receipt label")
        path = BASE / (label + ".json")
        row = read_json(path)
        require(row.get("label") == label and row.get("exit_code") == exit_code, f"{label}: actual receipt label/exit disagrees")
        require(row.get("source_head") == checkout_source, f"{label}: receipt checkout source differs")
        if clean_source:
            require(row.get("source_patch_sha256") == EMPTY_PATCH, f"{label}: product source was dirty")
        else:
            require(re.fullmatch(r"[0-9a-f]{64}", row.get("source_patch_sha256", "")) is not None, f"{label}: missing checkout patch observation")
        require(isinstance(row.get("command"), list) and row["command"], f"{label}: missing actual command")
        require(row.get("log") == label + ".log", f"{label}: log path differs")
        log = BASE / row["log"]
        require(digest(log) == row.get("log_sha256"), f"{label}: log hash differs")
        self.resource(row, label)
        self.add(path)
        self.add(log)
        return row, log.read_text(errors="replace")


def current_source():
    actual = subprocess.check_output(["git", "rev-parse", SOURCE + "^{commit}"], cwd=REPO, text=True).strip()
    require(actual == SOURCE, "candidate product source is unavailable")
    difference = subprocess.check_output(["git", "diff", "--binary", SOURCE, "--", "crates", "Cargo.toml", "Cargo.lock"], cwd=REPO)
    require(difference == b"", "product inputs differ from the measured source commit")
    require(subprocess.check_output(["git", "ls-files", "--others", "--exclude-standard", "--", "crates", "Cargo.toml", "Cargo.lock"], cwd=REPO) == b"", "untracked product files are outside measured authority")


def inventory_names(log):
    names = sorted(re.findall(r"^([^\s]+): test$", log, re.M))
    require(names and len(set(names)) == len(names), "native inventory is empty or repeated")
    return names


def observed_names(log):
    return [(name.removesuffix(" - should panic"), status) for name, status in re.findall(r"^test (.+) \.\.\. (ok|FAILED|ignored)$", log, re.M)]


def closed_native_log(row, log, inventory, *, filtered=0):
    observed = observed_names(log)
    require(sorted(name for name, _ in observed) == sorted(inventory) and all(status == "ok" for _, status in observed), f'{row["label"]}: native transcript lost, repeated, failed or ignored an identity')
    expected = [("ok", str(len(inventory)), "0", "0", "0", str(filtered))]
    require(SUMMARY_RE.findall(log) == expected and row.get("test_results") == [list(expected[0])], f'{row["label"]}: terminal counts do not reconcile to exact inventory')


def original_diagnostics(evidence):
    """Preserve the rejected source's observations without accepting its tests."""
    path = BASE / "diagnostic-closed.json"
    manifest = read_json(path)
    require(manifest.get("source") == DIAGNOSTIC_SOURCE and manifest.get("excluded_from_acceptance") is True, "original diagnostic source/acceptance boundary changed")
    focus_counts = {"focused-aot-string": 1, "focused-ir-string": 2, "focused-engine-buffers": 4, "focused-engine-scalar": 5, "focused-engine-string": 3}
    labels = ["focused-aot-scalar", *focus_counts, *("frozen-build-" + package for package in sorted({scope[0] for scope in EXPECTED_SCOPES}))]
    expected_paths = {"diagnostic-d67/" + label + extension for label in labels for extension in [".json", ".log"]}
    members = manifest.get("original_files", [])
    require(len(members) == len(expected_paths) == 22 and {item["path"] for item in members} == expected_paths, "original diagnostic22-file inventory differs")
    for item in members:
        member = BASE / item["path"]
        require(digest(member) == item.get("sha256"), "original preserved diagnostic member hash differs")
        evidence.add(member)
    records = {}
    for label in labels:
        row = read_json(BASE / "diagnostic-d67" / (label + ".json"))
        log_path = BASE / "diagnostic-d67" / (label + ".log")
        log = log_path.read_text(errors="replace")
        require(row.get("label") == label and row.get("log") == label + ".log" and row.get("source_head") == DIAGNOSTIC_SOURCE and row.get("source_patch_sha256") == EMPTY_PATCH, f"{label}: original diagnostic was relabeled or used another source")
        require(digest(log_path) == row.get("log_sha256"), f"{label}: original raw log differs")
        evidence.resource(row, "excluded-d67/" + label)
        if label == "focused-aot-scalar":
            expected = [("FAILED", "0", "1", "0", "0", "472")]
            require(row.get("exit_code") == 101 and SUMMARY_RE.findall(log) == expected and row.get("test_results") == [list(expected[0])], "original actual0pass/1failure encoded guard was not retained")
            guard = "tests::scalar_predicates::number_loop_comparison_reaches_control_without_boolean_materialization"
            require(observed_names(log) == [(guard, "FAILED")] and "a predicate must not materialize a tagged Boolean before its loop edge" in log, "original failure was not the actual Boolean-materialization guard")
        elif label in focus_counts:
            names = [name for name, status in observed_names(log) if status == "ok"]
            summaries = SUMMARY_RE.findall(log)
            require(row.get("exit_code") == 0 and len(names) == focus_counts[label] and len(summaries) == 1, f"{label}: original focused successes differ")
            closed_native_log(row, log, names, filtered=int(summaries[0][-1]))
        else:
            require(row.get("exit_code") == 0 and row.get("test_results") == [] and not observed_names(log) and not SUMMARY_RE.findall(log), f"{label}: no-run diagnostic build must not claim executed tests")
            require(row.get("command", [])[:2] == ["cargo", "test"] and "--no-run" in row["command"] and "--jobs" in row["command"] and row["command"][row["command"].index("--jobs") + 1] == "1", "original serial no-run build policy differs")
        records[label] = {"receipt": "diagnostic-d67/" + label + ".json", "exit_code": row["exit_code"], "actual_terminal_counts": row["test_results"], "added_to_accepted_totals": False}
    guard_path = "crates/scriptw-aot-wasm/src/tests/scalar_predicates.rs"
    require(subprocess.check_output(["git", "show", DIAGNOSTIC_SOURCE + ":" + guard_path], cwd=REPO) == subprocess.check_output(["git", "show", SOURCE + ":" + guard_path], cwd=REPO), "corrected source weakened or changed the original encoded artifact guard")
    require(manifest.get("probe_receipts") == ["release-probe-d67.json", "probe-d67-screen.json"] and manifest.get("probe_products") == "probe-d67" and manifest.get("probe_report") == "probe-d67-screen-data/report.json", "diagnostic probe authority differs")
    release, _ = evidence.receipt("release-probe-d67", checkout_source=DIAGNOSTIC_SOURCE)
    require(release["command"] == ["python3", "-B", "target/execution-performance-20261025/build_product.py", "probe-d67"], "original probe build invocation differs")
    screen, _ = evidence.receipt("probe-d67-screen", checkout_source=DIAGNOSTIC_SOURCE)
    require(screen["command"] == ["python3", "-B", "target/execution-performance-20261025/measure.py", "probe-d67", "probe-d67-screen-data", "--samples", "3", "--warmups", "3"], "original probe screen invocation differs")
    product = BASE / "probe-d67"
    probe_path = BASE / manifest["probe_report"]
    probe = read_json(probe_path)
    identity = read_json(product / "identity.json")
    require(identity.get("source_revision") == {"kind": "git-commit", "commit": DIAGNOSTIC_SOURCE} and probe.get("compiler_identity") == identity and digest(product / "scriptw") == identity.get("executable_sha256"), "original probe CLI source/binary changed")
    require(probe.get("complete") is True and probe.get("samples") == 3 and probe.get("warmups") == 3 and probe.get("product") == "probe-d67" and probe.get("label") == "probe-d67-screen-data" and probe.get("affinity") == [0], "original probe screen is incomplete or mislabeled")
    require(digest(product / "runtime_baseline") == probe.get("runtime_runner_sha256"), "original probe runner bytes changed")
    fixtures = REPO / "crates/scriptw-cli/tests/fixtures/v8_execution_hotpaths"
    plan = read_json(fixtures / "manifest.json")["execution"]
    require([row["file"] for row in probe.get("case_results", [])] == [row["file"] for row in plan] and len(plan) == 17, "original probe did not cover all17 workloads")
    spec = importlib.util.spec_from_file_location("execution_probe_code_sizes", BASE / "analyze.py")
    analysis = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(analysis)
    for fixture, case in zip(plan, probe["case_results"]):
        name = fixture["file"]
        require(case.get("source_sha256") == digest(fixtures / name) and case.get("expected_stdout") == fixture["stdout"] and set(case["runtimes"]) == {"wasmtime", "v8"}, "original probe source/output/runtime inventory differs")
        for runtime, row in case["runtimes"].items():
            stdout, stderr = probe_path.parent / row["stdout_file"], probe_path.parent / row["stderr_file"]
            data = row["data"]
            require(Path(row["stdout_file"]).name == row["stdout_file"] and Path(row["stderr_file"]).name == row["stderr_file"] and read_json(stdout) == data and row["exit_code"] == 0, "original probe raw stream/exit changed")
            require(data.get("samples") == 3 and data.get("warmups") == 3 and len(data.get("cases", [])) == 1, "original probe sample denominator differs")
            actual_case = data["cases"][0]
            observations = actual_case["observations"]
            require(actual_case["file"] == name and actual_case["source_sha256"] == case["source_sha256"] and len(observations) == 6 and [item["warmup"] for item in observations] == [True] * 3 + [False] * 3, "original probe exact observation identities differ")
            require(all(item["stdout"] == fixture["stdout"] and type(item["execution_ns"]) is int and item["execution_ns"] >= 0 for item in observations), "original probe output or duration differs")
            if runtime == "wasmtime":
                require(data["source_commit"] == DIAGNOSTIC_SOURCE and data["source_fingerprint"] == identity["source_fingerprint"] and data["executable_sha256"] == probe["runtime_runner_sha256"] and data["requested_native_policy"] is None, "original actual probe runner source/policy differs")
                wasm = probe_path.parent / (name + "-wasm") / (name + ".wasm")
                require(digest(wasm) == actual_case["wasm_sha256"] and wasm.stat().st_size == actual_case["wasm_bytes"], "original probe P bytes changed")
                require(all(actual_case["footprint"][key] == value for key, value in analysis.code_footprint(wasm).items()), "original probe P code footprint differs")
                evidence.add(wasm)
            evidence.add(stdout)
            evidence.add(stderr)
    cargo_path = product / "cargo-product.jsonl"
    cargo = [json.loads(line) for line in cargo_path.read_text().splitlines()]
    require([row.get("success") for row in cargo if row.get("reason") == "build-finished"] == [True], "original diagnostic Cargo build did not complete")
    for extra in [path, probe_path, product / "identity.json", cargo_path, product / "cargo-product.stderr"]:
        evidence.add(extra)
    return {"source_commit": DIAGNOSTIC_SOURCE, "excluded_from_acceptance": True, "reason": manifest["reason"], "original_native_observations": records, "original_failed": 1, "independent_focused_passed": sum(focus_counts.values()), "accepted_total_contribution": 0, "artifact_guard_unchanged": True, "probe": {"complete": True, "cases": 17, "samples_per_runtime": 3, "warmups_per_runtime": 3, "compiler_identity": identity, "runtime_runner_sha256": probe["runtime_runner_sha256"], "frozen_product_hashes": {name: digest(product / name) for name in ["scriptw", "runtime_baseline", "runtime_boundaries"]}, "report": manifest["probe_report"], "used_for_final_balanced_measurements": False}}


def engine_native(evidence, scope, recorded):
    path = BASE / "engine-accepted.json"
    aggregate = read_json(path)
    manifest_path = BASE / "engine-batches.json"
    manifest = read_json(manifest_path)
    require(aggregate == recorded and aggregate.get("source_head") == SOURCE and aggregate.get("source_patch_sha256") == EMPTY_PATCH, "engine aggregate source differs")
    require(aggregate.get("complete") is True and aggregate.get("exit_code") == 0 and manifest.get("complete") is True and manifest.get("source_head") == SOURCE, "engine aggregate or exact batch manifest is incomplete")
    require("log" not in aggregate and "test_results" not in aggregate and "no synthetic single-process transcript" in aggregate.get("aggregation", ""), "engine observations must remain an explicit aggregate")
    inventory = manifest.get("inventory", [])
    require(inventory and sorted(set(inventory)) == inventory and aggregate.get("inventory") == inventory and aggregate.get("passed") == len(inventory), "engine denominator differs")
    enumerated, enumeration_log = evidence.receipt("engine-batches-inventory")
    require(enumerated["command"] == [manifest["binary"], "--list", "--include-ignored"] or Path(enumerated["command"][0]).resolve() == Path(manifest["binary"]).resolve() and enumerated["command"][1:] == ["--list", "--include-ignored"], "engine inventory invocation differs")
    require(inventory_names(enumeration_log) == inventory, "engine inventory does not match actual native enumeration")
    require(len(enumerated.get("executables", [])) == 1, "engine executable identity is missing")
    binary = enumerated["executables"]
    seen = []
    labels = []
    for index, batch in enumerate(manifest.get("batches", [])):
        label = f"engine-batch-{index:03d}"
        require(batch.get("label") == label and set(batch) == {"label", "inventory"}, "engine batch metadata differs")
        names = batch["inventory"]
        require(isinstance(names, list) and 1 <= len(names) <= 32 and len(set(names)) == len(names) and set(names).issubset(inventory), f"{label}: invalid bounded inventory")
        if any(name.startswith("runtime_profile::") or "capacity" in name or "inlining" in name for name in names):
            require(len(names) == 1, f"{label}: capacity/inlining/profile case was not isolated")
        row, log = evidence.receipt(label)
        require(Path(row["command"][0]).resolve() == Path(manifest["binary"]).resolve() and row["command"][1:] == names + ["--exact", "--test-threads=1", "--include-ignored"], f"{label}: exact-name invocation differs")
        require(row.get("executables") == binary, f"{label}: executed engine binary differs from complete enumeration")
        closed_native_log(row, log, names, filtered=len(inventory) - len(names))
        seen.extend(names)
        labels.append(label + ".json")
    require(sorted(seen) == inventory and len(set(seen)) == len(seen), "engine batch union omits or repeats native identities")
    require(aggregate.get("batch_manifest") == manifest_path.name, "engine aggregate names another manifest")
    evidence.receipt("engine-batches-build")
    for extra in [path, manifest_path]:
        evidence.add(extra)
    return {**scope, "passed": len(inventory), "inventory_sha256": hashlib.sha256(("\n".join(inventory) + "\n").encode()).hexdigest(), "verification": "exact disjoint bounded native process observations", "aggregate_receipt": path.name, "manifest": manifest_path.name, "batch_count": len(labels), "receipts": labels, "executables": binary}


def native(evidence):
    scopes = read_json(BASE / "native-scopes.json")
    closed = read_json(BASE / "native-closed.json")
    require([(s["package"], s["kind"], s["name"]) for s in scopes] == EXPECTED_SCOPES, "complete affected 23-target inventory changed")
    require(closed.get("source") == SOURCE and closed.get("complete") is True and len(closed.get("targets", [])) == len(scopes), "native target manifest is incomplete or stale")
    total, qualified, targets = 0, [], []
    for index, (scope, recorded) in enumerate(zip(scopes, closed["targets"])):
        if scope["package"] == "scriptw-engine" and scope["kind"] == "--lib":
            result = engine_native(evidence, scope, recorded)
            names = recorded["inventory"]
        else:
            label = f'broad-{index:02d}-{scope["package"]}-{scope["name"] or "lib"}'
            row, log = evidence.receipt(label)
            enumerated, enumeration_log = evidence.receipt(label + "-inventory")
            command = ["cargo", "test", "--locked", "--release", "--jobs", "1", "-p", scope["package"], scope["kind"]]
            if scope["name"] is not None:
                command.append(scope["name"])
            require(row["command"] == command + ["--", "--test-threads=1", "--include-ignored"] and enumerated["command"] == command + ["--", "--list", "--include-ignored"], f"{label}: broad/inventory commands contain filters or changed policy")
            names = inventory_names(enumeration_log)
            closed_native_log(row, log, names)
            require(row.get("executables") and row["executables"] == enumerated.get("executables"), f"{label}: enumerated and executed native binaries differ")
            inventory_sha = hashlib.sha256(("\n".join(names) + "\n").encode()).hexdigest()
            require(recorded == dict(row, **scope, inventory=names, inventory_sha256=inventory_sha), f"{label}: closed manifest differs from actual native evidence")
            result = {**scope, "passed": len(names), "inventory_sha256": inventory_sha, "run_receipt": label + ".json", "inventory_receipt": label + "-inventory.json", "executables": row["executables"]}
        total += len(names)
        qualified.extend(f'{scope["package"]}:{scope["kind"]}:{scope["name"] or "lib"}:{name}' for name in names)
        targets.append(result)
    require(total == closed.get("total") and len(qualified) == len(set(qualified)), "native totals or qualified identity union differs")
    for package in sorted({scope["package"] for scope in scopes}):
        label = next((value for value in [f"frozen-build-final-{package}", f"frozen-build-{package}"] if (BASE / (value + ".json")).is_file()), None)
        require(label is not None, f"missing final serial native build: {package}")
        row, _ = evidence.receipt(label)
        expected = ["cargo", "test", "--locked", "--release", "--jobs", "1", "-p", package, "--no-run"]
        for scope in scopes:
            if scope["package"] == package:
                expected.append(scope["kind"])
                if scope["name"]:
                    expected.append(scope["name"])
        require(row["command"] == expected, f"{label}: native build omitted a selected target or changed policy")
    focused = []
    for path in sorted(BASE.glob("focused-*.json")):
        row, log = evidence.receipt(path.stem)
        names = [name for name, status in observed_names(log) if status == "ok"]
        command = row["command"]
        package = command[command.index("-p") + 1]
        kind = next(flag for flag in ["--lib", "--test", "--example"] if flag in command)
        name = None if kind == "--lib" else command[command.index(kind) + 1]
        selected = next(item for item in closed["targets"] if (item["package"], item["kind"], item["name"]) == (package, kind, name))
        require(names and set(names).issubset(selected["inventory"]), f'{row["label"]}: focused identities are absent from the complete target')
        closed_native_log(row, log, names, filtered=len(selected["inventory"]) - len(names))
        focused.append({"receipt": path.name, "passed": len(names), "overlaps_complete_targets": True, "added_to_total": False})
    require(focused, "focused regression receipts are missing")
    for path in [BASE / "native-scopes.json", BASE / "native-closed.json"]:
        evidence.add(path)
    return {"complete": True, "target_count": len(targets), "passed": total, "failed": 0, "ignored": 0, "inventory_sha256": hashlib.sha256(("\n".join(sorted(qualified)) + "\n").encode()).hexdigest(), "targets": targets, "focused": focused}


def selected_scopes(evidence, summary, batches):
    plan_path = BASE / "selected-scopes.json"
    plan = read_json(plan_path)
    controls_path = BASE / "selected.ids"
    controls = controls_path.read_text().splitlines()
    require(plan.get("complete") is True and plan.get("total") == 2417 and plan.get("source_inventory_reused_for_scope_planning_only") is True and plan.get("require_current_compiler_inventory_exact_match_before_execution") is True, "scope plan lacks its planning-only/final-admission boundary")
    require(len(controls) == len(set(controls)) == 2417 and digest(controls_path) == plan.get("execution_ids_sha256") and plan.get("execution_ids_file") == controls_path.name, "exact requested 2,417-ID input changed")
    replay = BASE / "conformance"
    inventory = summary["native_inventory"]
    require(inventory.get("command") == [summary["binary"], "--jobs", "1", "test262", "list-all", "--suite-root", summary["suite_root"]], "final native inventory command does not use the exact frozen compiler/suite")
    inventory_path = replay / inventory["stdout"]
    require(Path(inventory["stdout"]).name == inventory["stdout"] and digest(inventory_path) == inventory.get("stdout_sha256"), "final CLI inventory hash differs")
    current = batches.native_inventory(inventory_path.read_text())
    require(len(current) == 102994, "final CLI no longer enumerates the pinned full denominator")
    require(digest(inventory_path) == plan.get("source_inventory_sha256"), "final CLI full inventory differs from the historical planning authority")
    precheck_path = BASE / "conformance-inventory-validated.json"
    precheck = read_json(precheck_path)
    enumerated, enumeration_log = evidence.receipt("conformance-inventory-final")
    require(enumerated["command"] == [str(BASE / "candidate/scriptw"), "--jobs", "1", "test262", "list-all", "--suite-root", "test262/vendor/test262"], "pre-execution inventory command did not use the frozen final CLI/suite")
    require(digest(BASE / enumerated["log"]) == digest(inventory_path) and batches.native_inventory(enumeration_log) == current, "pre-execution inventory and frozen replay enumeration disagree")
    require(precheck == {"complete": True, "source_head": SOURCE, "compiler_identity": summary["compiler_identity"], "receipt": "conformance-inventory-final.json", "inventory_sha256": digest(inventory_path), "total": len(current), "selected_total": len(controls), "selected_ids_sha256": digest(controls_path), "scope_plan_sha256": digest(plan_path)}, "pre-execution complete-inventory admission manifest changed")
    evidence.add(precheck_path)
    union = set()
    scope_rows = []
    require(len(plan.get("scopes", [])) == 18, "selected scope prefix inventory is incomplete")
    for scope in plan["scopes"]:
        prefix = scope["prefix"]
        require(prefix.endswith("/") and ":" not in prefix, "invalid complete family prefix")
        actual = sorted(value for value in current if value.split(":", 1)[1].startswith(prefix))
        require(actual and actual == sorted(scope["execution_ids"]) and len(actual) == scope["count"], f"complete final CLI family differs: {prefix}")
        require(not union.intersection(actual), f"selected family inventories overlap: {prefix}")
        union.update(actual)
        scope_rows.append({"prefix": prefix, "count": len(actual)})
    require(set(plan.get("known_failure_controls", [])) == KNOWN and len(plan["known_failure_controls"]) == 4, "four known failure controls changed")
    union.update(KNOWN)
    require(union == set(controls), "selected complete families/controls do not exactly form requested IDs")
    for path in [plan_path, controls_path, inventory_path]:
        evidence.add(path)
    return controls, {"complete": True, "pre_execution_admission": precheck, "final_full_inventory_sha256": digest(inventory_path), "final_full_inventory_total": len(current), "scopes": scope_rows, "known_failure_controls": sorted(KNOWN), "execution_ids_sha256": digest(controls_path)}


def conformance(evidence):
    sys.path.insert(0, str(REPO / "scripts"))
    import test262_execution_batches as batches
    replay = BASE / "conformance"
    summary = read_json(replay / "summary.json")
    receipt, _ = evidence.receipt("conformance-final", exit_code=1)
    require("--workers" in receipt["command"] and receipt["command"][receipt["command"].index("--workers") + 1] == "1" and "--reuse-case-workers" in receipt["command"], "actual replay launcher lost serial workers or native batch evidence")
    command = receipt["command"]
    require(any(Path(part).name == "replay-test262-executions.py" for part in command) and any(Path(part).resolve() == (BASE / "selected.ids").resolve() for part in command), "actual replay launcher does not consume the exact selected input")
    controls, scopes = selected_scopes(evidence, summary, batches)
    identity = summary.get("compiler_identity", {})
    require(identity.get("source_revision") == {"kind": "git-commit", "commit": SOURCE} and identity.get("source_fingerprint_scheme") == "scriptw-program-cache-compiler-v3", "selected native snapshot comes from another compiler source")
    require(identity == read_json(BASE / "candidate/identity.json"), "frozen measured candidate and selected conformance compiler differ")
    require(summary.get("total") == len(controls) and summary.get("replay_mode") == "native-execution-list-v1" and summary.get("outcomes") == {"Success": 2413, "Bug": 4, "Crash": 0, "NotImplemented": 0}, "selected replay is incomplete or has new failures")
    require(summary.get("absent_executions") == [] and summary.get("batch_threads") == 1 and sorted(summary.get("batch_executions", [])) == sorted(controls), "selected replay omits, repeats or parallelizes requested executions")
    frozen_binary = Path(summary["binary"])
    require(frozen_binary.resolve().is_relative_to(replay.resolve()) and digest(frozen_binary) == summary.get("binary_sha256") == identity.get("executable_sha256"), "frozen replay compiler bytes differ")
    require((replay / "executions").read_bytes() == (BASE / "selected.ids").read_bytes() and digest(replay / "executions") == summary.get("execution_list_sha256"), "frozen requested execution list changed")
    fixtures = pinned_fixtures(summary, controls)
    results = summary.get("results", [])
    require(len(results) == len(controls) and {row["execution_id"] for row in results} == set(controls), "actual per-execution result inventory differs")
    require({row["execution_id"] for row in results if row.get("outcome") == "Bug"} == KNOWN, "selected failures differ from the four known controls")
    options = types.SimpleNamespace(output_dir=replay)
    snapshots, invocations = {}, {}
    for row in results:
        require(row.get("protocol") == "native-execution-list-v1" and "infrastructure_error" not in row, "selected verdict lacks native execution evidence")
        batches.verify_saved_result(row, summary, options, snapshots)
        require(row.get("exit_code") == (0 if row["outcome"] == "Success" else 1), "per-execution exit disagrees with verdict")
        path = replay / (hashlib.sha256(row["execution_id"].encode()).hexdigest() + ".json")
        require(read_json(path) == row, "per-execution receipt differs from summary")
        evidence.add(path)
        for name in [row["transcript"], row["native_snapshot"]["path"], row["invocation"]]:
            require(Path(name).name == name, "native replay evidence escaped its directory")
            evidence.add(replay / name)
        invocation_path = replay / row["invocation"]
        if invocation_path not in invocations:
            invocation = read_json(invocation_path)
            require(invocation.get("exit_code") == 1, "native suite exit1 was not retained")
            command = invocation.get("command", [])
            require("run-list" in command and "--threads" in command and command[command.index("--threads") + 1] == "1" and "--timeout-ms" in command and command[command.index("--timeout-ms") + 1] == "60000", "native batch changed worker/deadline policy")
            for stream in ["stdout", "stderr"]:
                stream_path = batches.owned_file(options, invocation[stream])
                require(digest(stream_path) == invocation.get(stream + "_sha256"), "actual native invocation stream changed")
                evidence.add(stream_path)
            invocations[invocation_path] = invocation
    baseline_path = REPO / "docs/rust-rewrite/foreign-modules-20261024.json"
    baseline = read_json(baseline_path)["conformance"]["native_snapshot"]
    signature = lambda rows: sorted((row["test_id"], row["kind"], row["outcome"], row["detail_hash"]) for row in rows)
    failures = signature(baseline["failures"])
    require({row[0] for row in failures} == KNOWN, "historical known-failure reference differs")
    pins = read_json(REPO / "crates/scriptw-test262/src/source-pins.json")
    for path in snapshots:
        snapshot = read_json(path)
        require(signature(snapshot.get("failures", [])) == failures and snapshot.get("timeout_test_ids") == [], "selected failure kind/diagnostics changed or a timeout occurred")
        require(snapshot.get("pinned_revisions") == {"ecma262": pins["ecma262"], "test262": pins["test262_tree"]}, "selected native snapshot changed source pins")
        batches.snapshot_verdicts(snapshot, controls, identity, exit_code=1)
    for name in ["summary.json", "run.json", "executions", "batch-executions", "compiler-identity.stdout", "compiler-identity.stderr", "native-inventory.stderr"]:
        evidence.add(replay / name)
    require(read_json(replay / "run.json").get("compiler_identity") == identity and digest(replay / "batch-executions") == summary.get("batch_execution_list_sha256"), "native replay manifest/list changed")
    return {"complete": True, "total": len(controls), "passed": 2413, "bug": 4, "crash": 0, "not_implemented": 0, "timeout": 0, "actual_command_exit": 1, "scope": scopes, "execution_ids": sorted(controls), "compiler_identity": identity, "pinned_fixtures": fixtures, "known_failure_reference": {"path": str(baseline_path.relative_to(REPO)), "sha256": digest(baseline_path), "signatures": failures}, "native_snapshots": [{"path": str(path.relative_to(BASE)), "sha256": digest(path)} for path in snapshots], "invocations": list(invocations.values()), "full_test262_chart_refreshed": False}


def products(evidence):
    authority_path = BASE / "baseline/source-authority.json"
    authority = read_json(authority_path)
    require(authority.get("checkout") == BASELINE_CHECKOUT, "baseline checkout authority changed")
    release_path = REPO / authority["build_receipt"]
    release = read_json(release_path)
    patch_path = REPO / authority["source_patch"]
    require(digest(patch_path) == BASELINE_PATCH and release.get("source_head") == BASELINE_SOURCE and release.get("source_patch_sha256") == BASELINE_PATCH and release.get("exit_code") == 0, "baseline release was not actual4ad plus exact6af patch")
    require(subprocess.check_output(["git", "diff", "--binary", BASELINE_SOURCE, BASELINE_CHECKOUT, "--", "crates", "Cargo.toml", "Cargo.lock"], cwd=REPO) == patch_path.read_bytes(), "baseline checkout does not preserve the exact old fixture/doc patch")
    old_report = read_json(REPO / "docs/rust-rewrite/embedding-bridge-20261024.json")
    baseline = read_json(BASE / "baseline/identity.json")
    require(baseline == old_report["test262"]["compiler_identity"], "frozen baseline CLI differs from its already published native identity")
    require(digest(BASE / "baseline/scriptw") == baseline.get("executable_sha256"), "frozen baseline CLI bytes changed")
    require(digest(BASE / "baseline/runtime_boundaries") == BASELINE_BOUNDARIES_SHA256, "preserved baseline existing-Realm observer bytes changed")
    candidate = read_json(BASE / "candidate/identity.json")
    require(candidate.get("source_revision") == {"kind": "git-commit", "commit": SOURCE} and digest(BASE / "candidate/scriptw") == candidate.get("executable_sha256"), "candidate frozen CLI source/bytes differ")
    require(candidate.get("source_fingerprint_scheme") == "scriptw-program-cache-compiler-v3" and re.fullmatch(r"[0-9a-f]{64}", candidate.get("source_fingerprint", "")), "candidate compiler source fingerprint missing")
    final, _ = evidence.receipt("release-final")
    require(final["command"] == ["python3", "-B", "target/execution-performance-20261025/build_product.py"], "final product build wrapper differs")
    cargo_path = BASE / "cargo-product.jsonl"
    cargo = [json.loads(line) for line in cargo_path.read_text().splitlines()]
    require([row.get("success") for row in cargo if row.get("reason") == "build-finished"] == [True], "actual Cargo product build did not finish successfully")
    expected_products = {"scriptw", "runtime_baseline", "runtime_boundaries"}
    artifacts = {Path(row["executable"]).name: row for row in cargo if row.get("reason") == "compiler-artifact" and row.get("executable") and Path(row["executable"]).name in expected_products}
    require(set(artifacts) == expected_products, "actual Cargo artifacts omit CLI or benchmark runner")
    for name, row in artifacts.items():
        require(digest(row["executable"]) == digest(BASE / "candidate" / name), f"frozen candidate {name} differs from the actual Cargo build product")
    for path in [authority_path, release_path, REPO / "target/embedding-bridge-20261024/release-final.log", patch_path, BASE / "baseline/identity.json", BASE / "candidate/identity.json", cargo_path, BASE / "cargo-product.stderr"]:
        evidence.add(path)
    return {"baseline": {"compiler_identity": baseline, "runtime_runner_sha256": digest(BASE / "baseline/runtime_baseline"), "runtime_boundaries_sha256": BASELINE_BOUNDARIES_SHA256, "actual_build_source": BASELINE_SOURCE, "actual_source_patch_sha256": BASELINE_PATCH, "checkout_at_measurement_start": BASELINE_CHECKOUT, "provenance": "the prior release's exact4ad+6af build and published CLI identity are retained; baseline measurement launcher checkout/dirty hashes describe tooling observations, not replacement compiler source"}, "candidate": {"compiler_identity": candidate, "runtime_runner_sha256": digest(BASE / "candidate/runtime_baseline"), "runtime_boundaries_sha256": digest(BASE / "candidate/runtime_boundaries"), "source_tree_clean": True, "release_receipt": "release-final.json"}}


def performance(evidence, product_report):
    module_path = BASE / "analyze.py"
    spec = importlib.util.spec_from_file_location("execution_performance_analysis", module_path)
    analysis = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(analysis)
    require(callable(getattr(analysis, "build_report", None)), "analysis tool must expose read-only build_report()")
    actual = analysis.build_report()
    path = BASE / "analysis.json"
    require(read_json(path) == actual and actual.get("complete") is True and actual.get("round_order") == ROUNDS, "comparison summary differs from validated actual observations")
    require(len(actual.get("cases", [])) == 17, "balanced comparison did not finish all17 exact workloads")
    rows = []
    for index, label in enumerate(ROUNDS):
        product = "baseline" if index in [0, 3] else "candidate"
        report = read_json(BASE / label / "report.json")
        identity = product_report[product]["compiler_identity"]
        require(report.get("compiler_identity") == identity and report.get("runtime_runner_sha256") == product_report[product]["runtime_runner_sha256"], f"{label}: measured binary/source identity differs")
        receipt_label = label.removesuffix("-data")
        if index == 0:
            receipt, _ = evidence.receipt(receipt_label, checkout_source=BASELINE_CHECKOUT, clean_source=False)
        else:
            receipt, _ = evidence.receipt(receipt_label)
        require(report.get("samples") == 7 and report.get("warmups") == 10 and report.get("complete") is True, f"{label}: incomplete sample/warmup policy")
        for item in (BASE / label).iterdir():
            if item.is_file() and (item.name == "report.json" or item.suffix in {".stdout", ".stderr"}):
                evidence.add(item)
            elif item.is_dir() and item.name.endswith("-wasm"):
                for artifact in item.iterdir():
                    require(artifact.is_file() and artifact.suffix == ".wasm", "unexpected measured artifact member")
                    evidence.add(artifact)
    for case in actual["cases"]:
        before = case["pooled"]["baseline"]["wasmtime"]["median_execution_ns"]
        after = case["pooled"]["candidate"]["wasmtime"]["median_execution_ns"]
        v8 = case["pooled"]["candidate"]["v8"]["median_execution_ns"]
        rows.append({"file": case["file"], "baseline_ms": before / 1e6, "candidate_ms": after / 1e6, "change_percent": 100 * (after / before - 1), "paired_candidate_v8_ms": v8 / 1e6, "candidate_over_paired_v8": after / v8})
    for extra in [module_path, path, REPO / "crates/scriptw-cli/tests/fixtures/v8_baseline/node-runtime.cjs"]:
        evidence.add(extra)
    for extra in analysis.evidence_files():
        evidence.add(extra)
    fixtures = REPO / "crates/scriptw-cli/tests/fixtures/v8_execution_hotpaths"
    for path in fixtures.iterdir():
        require(path.is_file() and path.suffix in {".js", ".json"}, "unexpected workload fixture member")
        evidence.add(path)
    return {"complete": True, "balanced_observations": actual, "table": rows, "table_statistic": "median of14 measured samples per product, pooled from two fresh process rounds of7 measured samples after10 warmups each; per-round medians and adjacent comparisons retained", "policy": "unchanged default Fast P and optimized Portable R, 16-MiB initial GC capacity; one CPU, fresh Store/Realm or V8 context; execution+completion includes construction and checksums", "interpretation": "descriptive paired measurements, not a statistical significance test or a universal V8-parity claim", "ambient_load_limit": "unrelated CPU-active processes and desktop activity were observed on the shared host; loadavg start/end is retained for every round; this is not an otherwise-idle or isolated causal measurement and cannot certify idle-machine repeatability", "historical_readme_graph_refreshed": False}


def performance_calls(evidence, product_report):
    """Keep callback-delimited calls separate from ordinary entry execution."""
    sys.path.insert(0, str(BASE))
    module_path = BASE / "analysis_calls.py"
    spec = importlib.util.spec_from_file_location("execution_performance_call_analysis", module_path)
    analysis = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(analysis)
    actual = analysis.build_report()
    path = BASE / "analysis_calls.json"
    require(read_json(path) == actual, "existing-Realm comparison differs from actual checked sessions")
    require(actual.get("schema") == "scriptw-execution-same-realm-comparison-v1" and actual.get("complete") is True and actual.get("round_order") == CALL_ROUNDS, "existing-Realm ABBA cohort is partial, reordered or mislabeled")
    require(actual.get("case_count") == 17 and actual.get("samples_per_session") == 7 and actual.get("guest_warmups") == 10 and actual.get("sessions_per_product") == 2 and actual.get("pooled_samples_per_product") == 14, "existing-Realm session/call/warmup denominator changed")
    fixtures = REPO / "crates/scriptw-cli/tests/fixtures/v8_execution_hotpaths"
    expected_cases = read_json(fixtures / "manifest.json")["execution"]
    require([case["file"] for case in actual["cases"]] == [case["file"] for case in expected_cases], "existing-Realm cohort does not preserve the exact17 original workloads")
    for index, label in enumerate(CALL_ROUNDS):
        product = "baseline" if index in [0, 3] else "candidate"
        round_report = read_json(BASE / label / "report.json")
        require(round_report.get("compiler_identity") == product_report[product]["compiler_identity"] and round_report.get("runtime_boundaries_sha256") == product_report[product]["runtime_boundaries_sha256"], f"{label}: callback observer product/source differs from frozen authority")
        receipt, _ = evidence.receipt(label.removesuffix("-data"))
        command = receipt["command"]
        require(any(Path(part).name == "measure_calls.py" for part in command) and product in command and label in command, f"{label}: actual call measurement command differs")
    rows = []
    for case in actual["cases"]:
        require(case["original_source_sha256"] == digest(fixtures / case["file"]), "existing-Realm original workload source changed")
        before = case["pooled"]["baseline"]["wasmtime"]["median_ns"]
        after = case["pooled"]["candidate"]["wasmtime"]["median_ns"]
        v8 = case["pooled"]["candidate"]["v8"]["median_ns"]
        rows.append({"file": case["file"], "baseline_ms": before / 1e6, "candidate_ms": after / 1e6, "change_percent": 100 * (after / before - 1), "paired_candidate_v8_ms": v8 / 1e6, "candidate_over_paired_v8": after / v8})
    evidence.add(path)
    for extra in analysis.evidence_files():
        evidence.add(extra)
    return {"complete": True, "balanced_observations": actual, "table": rows, "table_statistic": "median of14 elapsed callback intervals per product, pooled from two existing-Realm sessions of7 calls after10 guest warmups each", "measurement": "elapsed wall time between actual callback exit/entry timestamps; not a measured CPU clock; includes workload construction/checksum and marker overhead; excludes setup/bootstrap, warmups, checksum printing, bundle/cache admission and native compilation; no empty subtraction", "source_cohort": "separate generated wrapper: original workload IIFE body becomes batch(seed), sole final print expression becomes return expression; original inputs and explicit String(checksum) conversions retained; exact result checked outside every interval", "archive_exclusions": "session Portable P/R bundles, V8 cachedData, executables and native caches excluded; actual payload hashes/framing, regeneration commands, transformed sources and harness snapshots retained", "ambient_load_limit": "shared-host CPU/desktop activity and raw load averages retained; descriptive observations cannot certify idle-machine repeatability, causal significance or universal V8 parity"}


def markdown(report):
    q = chr(96)
    performance_rows = "\n".join(f'| {q}{row["file"]}{q} | {row["baseline_ms"]:.3f} | {row["candidate_ms"]:.3f} | {row["change_percent"]:+.1f}% | {row["paired_candidate_v8_ms"]:.3f} | {row["candidate_over_paired_v8"]:.2f}x |' for row in report["performance"]["table"])
    call_rows = "\n".join(f'| {q}{row["file"]}{q} | {row["baseline_ms"]:.3f} | {row["candidate_ms"]:.3f} | {row["change_percent"]:+.1f}% | {row["paired_candidate_v8_ms"]:.3f} | {row["candidate_over_paired_v8"]:.2f}x |' for row in report["same_realm_performance"]["table"])
    native_rows = "\n".join(f'| {q}{row["package"]}{q} {row["name"] or "library"} | {row["passed"]:,} |' for row in report["native"]["targets"])
    return f"""# JavaScript execution performance, 2026-10-25

Source [{q}{SOURCE[:9]}{q}](https://github.com/mewhhaha/scriptw/commit/{SOURCE}) changes emitted execution: stable merging for private Array sorting, geometric unpublished UTF-16 buffers for join/locale assembly, scalar Number predicates and local reads, explicit initialized-local lifecycles, and bounded literal/string addition work. [The contract](contracts/execution-hotpaths.md) records the semantic boundaries.

The comparison uses the actual frozen {q}{BASELINE_SOURCE[:9]}{q} release plus its exact archived test/documentation patch, rather than relabeling it as the later checkout. The candidate is the clean product source above. CLI/runner hashes, compiler fingerprints, P/R artifact hashes and actual launcher checkout observations remain separate in the evidence.

All four observations run serially in **baseline–candidate–candidate–baseline** order. Each product has two fresh process rounds per workload, each with seven measured fresh Store/Realm or V8 contexts after ten warmups. The table pools the 14 measured samples per product and reports their median; V8 is the paired candidate observations. Separate round medians and both adjacent comparisons remain in the machine-readable results. Values include construction/checksums and completion; setup and compilation are recorded separately.

Unrelated CPU-active processes and desktop activity were observed on the shared host. Each round retains load average at start/end. These are descriptive measurements under observed ambient load, not an otherwise-idle or isolated causal comparison; they do not certify idle-machine repeatability, statistical significance or universal V8 parity. Every workload and regression is retained.

| Workload | Before ms | After ms | Change | V8 ms | After / V8 |
| --- | ---: | ---: | ---: | ---: | ---: |
{performance_rows}

The separate **existing-Realm call cohort** runs the same 17 workload bodies through a generated batch wrapper: the sole final print expression becomes the return expression, while original inputs and explicit String(checksum) conversions remain. Each process initializes one Realm, executes ten guest warmups and records seven actual callback-exit-to-callback-entry intervals; each product has two sessions in ABBA order. The table pools their 14 elapsed intervals. Construction and checksum calculation remain inside each call; setup/bootstrap, warmups, checksum printing, bundle/cache admission and native compilation are outside. There is no empty-program subtraction. These are elapsed wall intervals with marker overhead, not isolated CPU clocks, and remain distinct from the fresh-Realm table above.

| Existing-Realm workload | Before ms | After ms | Change | V8 ms | After / V8 |
| --- | ---: | ---: | ---: | ---: | ---: |
{call_rows}

All call results, transformed-source/original-source hashes, actual callback timestamps, session medians, adjacent comparisons, whole-child RSS and whole-program GC capacity are retained. Memory observations include setup and warmups and cannot establish per-call peak/live/allocation bytes. Raw Portable P/R bundles and V8 cachedData are excluded from the archive; their actual hashes, framing metadata, sources and regeneration commands remain.

The initial {q}{DIAGNOSTIC_SOURCE[:9]}{q} diagnostic exposed a missing ordinary-source path: the encoded artifact guard failed **0 passed / 1 failed**, while 15 independent focused checks passed. Ordinary source relations use general comparison IR; the corrected source consumes its actual predicate without Boolean boxing and bypasses runtime classification only for certified emitted Number results. The original artifact guard is unchanged. All 22 original focused/build receipt files and the 17-case three-sample diagnostic probe remain archived under their actual original source identities, excluded from accepted native totals and final balanced measurements.

Native verification passed **{report["native"]["passed"]:,} checks across {report["native"]["target_count"]} complete affected targets**, with no failures or ignored tests. The engine library uses an exact disjoint union of fresh bounded processes, preserving every inventoried identity. Focused checks overlap this denominator and are not added.

The selected pinned Test262 replay completed **2,417 exact executions: 2,413 successes and the same four known runtime bugs**, with zero crashes, unsupported cases or timeouts and actual exit **1**. Eighteen complete affected families plus four explicit controls reconcile against the final CLI's complete 102,994-ID inventory. This selected checkpoint does not refresh the historical full-suite or V8 README graphs.

Every accepted native, build, benchmark and replay receipt records one CPU, a kernel-enforced **4-GiB cap**, zero swap, grouped OOM termination, serial pools and a one-entry/64-MiB retained module cache. No accepted receipt records an OOM. Process RSS and GC capacity remain distinct from live JavaScript bytes/allocation counts; the raw observations retain unavailable-counter labels.

| Native target | Passed |
| --- | ---: |
{native_rows}

[Machine-readable results]({STEM}.json) retain exact commands, inventories, pins, source/binary identities, warmups, all measured observations, code sizes and memory reports. [Raw evidence and reproduction scripts]({STEM}.tar.gz) have SHA-256 {q}{report["archive"]["sha256"]}{q}; binaries, caches and build outputs are excluded.

To refresh, check out the source commit, run serial builds and the archived {q}focus.py{q}, {q}engine_batches.py{q} and {q}native_final.py{q} under {q}python3 -B scripts/limited_verification.py --{q}, then build the ordinary CLI/runtime_baseline/runtime_boundaries products. Preserve separate immutable baseline/candidate products and run the archived {q}measure.py{q} in the balanced order above. Run {q}measure_calls.py{q} separately in its four-round ABBA order to regenerate the existing-Realm sources, Portable bundles, V8 cachedData and exact callback observations. Replay the exact archived {q}selected.ids{q} with {q}scripts/replay-test262-executions.py --workers 1 --reuse-case-workers{q} under the same limiter, retaining the original 60-second case deadlines and nonzero known-failure exit. Re-derive {q}analysis.json{q} with {q}analyze.py{q} and {q}analysis_calls.json{q} with {q}analysis_calls.py{q}; the default {q}publish_evidence.py{q} validates only and {q}--publish{q} requires every closed input. Existing receipts are audit evidence, not new executions.
"""


def pinned_fixtures(summary, controls):
    """Bind observed fixture SHA-256s to blobs in the exact pinned Git tree."""
    pins_path = REPO / "crates/scriptw-test262/src/source-pins.json"
    pins = read_json(pins_path)
    tree = subprocess.check_output(["git", "rev-parse", SOURCE + ":test262/vendor/test262"], cwd=REPO, text=True).strip()
    require(tree == pins["test262_tree"], "source commit does not contain the pinned Test262 tree")
    paths = {execution.split(":", 1)[1] for execution in controls}
    require(set(summary.get("fixture_sha256", {})) == paths, "fixture digest inventory does not cover exactly the requested paths")
    tree_entries = subprocess.check_output(["git", "ls-tree", "-r", "-z", SOURCE + ":test262/vendor/test262/test"], cwd=REPO)
    blobs = {}
    for entry in tree_entries.split(b"\0"):
        if not entry: continue
        header, name = entry.split(b"\t", 1)
        name = name.decode()
        if name in paths:
            _, kind, oid = header.split()
            require(kind == b"blob", "requested fixture is not a pinned Git blob")
            blobs[name] = oid.decode()
    require(set(blobs) == paths, "requested fixture is missing from the pinned tree")
    ordered = sorted(blobs)
    process = subprocess.run(["git", "cat-file", "--batch"], input=("\n".join(blobs[name] for name in ordered) + "\n").encode(), stdout=subprocess.PIPE, stderr=subprocess.PIPE, cwd=REPO, check=True)
    content, offset = process.stdout, 0
    for name in ordered:
        end = content.index(b"\n", offset)
        oid, kind, length = content[offset:end].split()
        require(oid.decode() == blobs[name] and kind == b"blob", "Git returned another fixture object")
        start, size = end + 1, int(length)
        data = content[start:start + size]
        require(len(data) == size and content[start + size:start + size + 1] == b"\n", "pinned fixture batch is truncated")
        require(hashlib.sha256(data).hexdigest() == summary["fixture_sha256"][name], f"observed fixture differs from pinned Git bytes: {name}")
        offset = start + size + 1
    require(offset == len(content), "unexpected trailing Git fixture data")
    return {"source_tree": tree, "fixture_count": len(paths), "fixture_hashes": summary["fixture_sha256"]}

def archive(evidence, output):
    rows = [{"path": name, "bytes": path.stat().st_size, "sha256": digest(path)} for name, path in sorted(evidence.paths.items())]
    manifest = {"schema": "scriptw-execution-performance-archive-v1", "source_commit": SOURCE, "members": rows, "excluded": "Compiler/test/example binaries, caches and temporary files are excluded. Binary hashes are retained in command receipts and the native snapshot. Git commit reproduces the exact product source."}
    manifest_bytes = (json.dumps(manifest, indent=2) + "\n").encode()
    temporary = output.with_suffix(output.suffix + ".pending")
    with temporary.open("wb") as raw, gzip.GzipFile(fileobj=raw, mode="wb", filename="", mtime=0, compresslevel=6) as compressed, tarfile.open(fileobj=compressed, mode="w") as bundle:
        for row in rows:
            path = evidence.paths[row["path"]]
            require(path.stat().st_size == row["bytes"] and digest(path) == row["sha256"], f"evidence changed during publication: {path}")
            info = tarfile.TarInfo(row["path"])
            info.size, info.mode = row["bytes"], 0o644
            with path.open("rb") as stream:
                bundle.addfile(info, stream)
        info = tarfile.TarInfo(PREFIX + "archive-members.json")
        info.size, info.mode = len(manifest_bytes), 0o644
        bundle.addfile(info, io.BytesIO(manifest_bytes))
    expected = {row["path"]: row for row in rows}
    seen = set()
    with tarfile.open(temporary, "r:gz") as bundle:
        for member in bundle:
            require(member.isfile() and member.name not in seen, "archive contains a nonfile or duplicate")
            seen.add(member.name)
            stream = bundle.extractfile(member)
            if member.name == PREFIX + "archive-members.json":
                require(stream.read() == manifest_bytes, "archive manifest changed")
            else:
                row = expected[member.name]
                require(member.size == row["bytes"] and hashlib.file_digest(stream, "sha256").hexdigest() == row["sha256"], "archive round-trip hash mismatch")
    require(seen == set(expected) | {PREFIX + "archive-members.json"}, "archive inventory is incomplete")
    temporary.replace(output)
    return {"file": output.name, "sha256": digest(output), "bytes": output.stat().st_size, "member_count": len(seen), "manifest_sha256": hashlib.sha256(manifest_bytes).hexdigest(), "expanded_bytes": sum(row["bytes"] for row in rows) + len(manifest_bytes)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--publish", action="store_true")
    args = parser.parse_args()
    os.sched_setaffinity(0, {min(os.sched_getaffinity(0))})
    current_source()
    evidence = Evidence()
    diagnostics_report = original_diagnostics(evidence)
    native_report = native(evidence)
    product_report = products(evidence)
    conformance_report = conformance(evidence)
    performance_report = performance(evidence, product_report)
    calls_report = performance_calls(evidence, product_report)
    for name in ["publish_evidence.py", "native_final.py", "engine_batches.py", "build_native.py", "build_product.py", "focus.py", "measure.py", "run_check.py", "preflight.py", "validate_inventory.py"]:
        evidence.add(BASE / name)
    for name in ["limited_verification.py", "resource_numbers.py", "replay-test262-executions.py", "test262_execution_batches.py"]:
        evidence.add(REPO / "scripts" / name)
    report = {"schema": "scriptw-execution-performance-checkpoint-v1", "refresh_date": "2026-10-25", "complete": True, "source_commit": SOURCE, "excluded_initial_diagnostics": diagnostics_report, "native": native_report, "products": product_report, "test262": conformance_report, "performance": performance_report, "same_realm_performance": calls_report, "resources": {"cpus": 1, "memory_limit_bytes": BUDGET, "swap_limit_bytes": 0, "accepted_oom_events": 0, "maximum_cgroup_peak_bytes": max(row["memory_peak_bytes"] for row in evidence.resources), "field_provenance": evidence.resources}}
    if not args.publish:
        print(json.dumps({"validated": True, "native_passed": native_report["passed"], "native_targets": native_report["target_count"], "selected_test262": conformance_report["total"], "performance_cases": len(performance_report["table"]), "separate_existing_realm_cases": len(calls_report["table"]), "archive_members": len(evidence.paths) + 1, "publication": "not requested"}, indent=2))
        return
    output = REPO / "docs/rust-rewrite"
    paths = [output / (STEM + extension) for extension in [".md", ".json", ".tar.gz"]]
    require(not any(path.exists() for path in paths), "refusing to overwrite published evidence")
    report["archive"] = archive(evidence, paths[2])
    paths[1].write_text(json.dumps(report, indent=2) + "\n")
    paths[0].write_text(markdown(report))
    print(json.dumps({"published": [str(path.relative_to(REPO)) for path in paths], "native_passed": native_report["passed"], "archive": report["archive"]}, indent=2))


if __name__ == "__main__":
    try:
        main()
    except (KeyError, ValueError, OSError, TypeError, StopIteration) as error:
        print(f"Evidence publication refused: {error}", file=sys.stderr)
        raise SystemExit(1)
