"""Assemble a rejection report from sealed, inert receipts; never runs products."""
from pathlib import Path
import datetime
import hashlib
import json
import re
import statistics
import tarfile

ROOT = Path('/workspace/scriptw')
WORK = ROOT / 'target/performance-dense-numbers-20261030'
STAGE = WORK / 'evidence-staging'
HEAD = '28bbffe0c7e930fab457d2e4dc69b75fa90d5f60'
NAMES = {'v1': 'array-storage-v1-20261030-inert.tar.xz',
         'v2': 'array-publication-v2-20261030-inert.tar.xz'}


def digest(data):
    return hashlib.sha256(data).hexdigest()


class Evidence:
    def __init__(self, key, relative):
        self.key = key
        self.path = WORK / relative
        self.tar = tarfile.open(self.path, 'r:xz')
        self.index = json.load(self.tar.extractfile('evidence-index.json'))
        self.members = {x['path']: x for x in self.index['members']}

    def data(self, path):
        data = self.tar.extractfile('raw/' + path).read()
        assert digest(data) == self.members[path]['sha256']
        return data

    def json(self, path):
        return json.loads(self.data(path))

    def ref(self, path):
        assert path in self.members, path
        return {'archive': NAMES[self.key], 'member': 'raw/' + path,
                'sha256': self.members[path]['sha256']}


def native_coverage(e):
    d = e.json('native/receipt.json')
    assert d['source_unchanged'] and d['shared_runtime_linker_unchanged']
    rows = []
    for c in d['cases']:
        assert c['state'] == 'passed' and c['exit_code'] == 0 and c['inventory_matches']
        passed = sum(o['passed'] for o in c['outcomes'])
        assert passed == c['inventoried_tests']
        assert all(o['failed'] == o['ignored'] == 0 for o in c['outcomes'])
        rows.append([c['package'], c['target'], passed, c['executable_sha256']])
    return {'scope': 'Selected default-feature release native targets on the measured candidate source. This does not validate the final restored source.',
            'passed': sum(r[2] for r in rows), 'source_unchanged': True,
            'source_map_sha256': d['source_map_sha256'],
            'columns': ['package', 'target', 'passed', 'executable_sha256'], 'targets': rows,
            'receipt': e.ref('native/receipt.json'),
            'source_map': e.ref('native/source-start.json'),
            'immutable_watcher_map': e.ref('v1-native-transcript-map.json' if e.key == 'v1' else 'native-transcript-map.json'),
            'source_guards': {'passed': 359, 'scope': 'Separate source-only checks; overlap with native targets, so do not add these to native totals.',
                              'receipt': e.ref('source-guards/receipt.json')}}


def brief_timing(boundary):
    return [boundary['median_ns']['baseline'], boundary['median_ns']['candidate'],
            round(boundary['change_percent'], 3),
            *[round(g['change_percent'], 3) for g in boundary['balanced_orders']]]


def timing(e):
    first = e.json('analysis.json')
    repeat = e.json('confirmation/analysis.json')
    assert first['order'] == ['baseline', 'candidate', 'candidate', 'baseline', 'candidate', 'baseline', 'baseline', 'candidate']
    assert repeat['order'] == ['candidate', 'baseline', 'baseline', 'candidate', 'baseline', 'candidate', 'candidate', 'baseline']
    assert first['samples_per_round'] == repeat['samples_per_round'] == 21
    assert first['warmups_per_round'] == repeat['warmups_per_round'] == 10
    rows = []
    for a, b in zip(first['workloads'], repeat['workloads'], strict=True):
        assert a['file'] == b['file']
        assert a['original_source_sha256'] == b['original_source_sha256']
        for boundary in ['ordinary', 'retained']:
            if boundary not in a:
                continue
            rows.append([a['file'], boundary, *brief_timing(a[boundary]), *brief_timing(b[boundary])])
    assert len(rows) == 35
    return {'scope': first['scope'],
            'columns': ['workload', 'boundary', 'initial_baseline_median_ns', 'initial_candidate_median_ns',
                        'initial_change_percent', 'initial_ABBA_change_percent', 'initial_BAAB_change_percent',
                        'confirmation_baseline_median_ns', 'confirmation_candidate_median_ns',
                        'confirmation_change_percent', 'confirmation_BAAB_change_percent', 'confirmation_ABBA_change_percent'],
            'rows': rows,
            'startup_columns': ['initial_baseline_median_ns', 'initial_candidate_median_ns', 'initial_change_percent',
                                'initial_ABBA_change_percent', 'initial_BAAB_change_percent',
                                'confirmation_baseline_median_ns', 'confirmation_candidate_median_ns',
                                'confirmation_change_percent', 'confirmation_BAAB_change_percent', 'confirmation_ABBA_change_percent'],
            'startup': brief_timing(first['startup']) + brief_timing(repeat['startup']),
            'initial_raw_analysis': e.ref('analysis.json'), 'confirmation_raw_analysis': e.ref('confirmation/analysis.json'),
            'round_raw_paths': 'Each analysis products[].raw points to the full samples and original command receipt in its own archive directory. Confirmation raw paths are relative to raw/confirmation/.',
            'rounds_per_repetition': 8, 'measured_samples_per_round': 21, 'warmups_per_round': 10,
            'aggregation': 'For each product, take the median of all 84 measured samples in a repetition; each balanced group uses 42 samples. Percent is (candidate/baseline - 1)*100. Rounded summary values only; full samples and precision remain in the archive.'}


def primary_memory(e):
    result = {'scope': 'Sampled process RSS and whole-child high-water RSS include different lifetimes; GC capacity is reserved capacity. None measures live JavaScript bytes or per-call allocation bytes.'}
    for prefix, label in [('', 'initial'), ('confirmation/', 'confirmation')]:
        phases = e.json(prefix + 'boundary-phases.json')
        primary = next(x for x in phases['workloads'] if x['file'] == 'retained-objects.js')
        a = e.json(prefix + 'analysis.json')
        w = next(x for x in a['workloads'] if x['file'] == 'retained-objects.js')
        values = {}
        for product in ['baseline', 'candidate']:
            phases_for_product = primary['products'][product]
            values[product] = {k: phases_for_product[k] for k in [
                'ordinary_gc_capacity_median_bytes', 'ordinary_sampled_rss_median_bytes',
                'ordinary_compilation_median_ns', 'ordinary_nonwarmup_phase_median_ns',
                'retained_per_process_phase_median_ns']}
            values[product]['ordinary_process_lifetime_peak_rss_median_bytes'] = statistics.median(x['process_lifetime_peak_rss_bytes'] for x in w['ordinary']['products'][product])
            values[product]['retained_process_lifetime_peak_rss_median_bytes'] = statistics.median(x['process_lifetime_peak_rss_bytes'] for x in w['retained']['products'][product])
        result[label] = values
    result['raw_phase_receipts'] = [e.ref('boundary-phases.json'), e.ref('confirmation/boundary-phases.json')]
    return result


def products(e, prefix):
    identity = e.json(prefix + '/identity.json')
    product_rows = [[name, p['bytes'], p['sha256']] for name, p in e.json(prefix + '/products.json').items()]
    return {'source_commit': identity['source_commit'], 'source_fingerprint': identity['source_fingerprint'],
            'artifact_columns': ['name', 'bytes', 'sha256'], 'artifacts': product_rows,
            'identity': e.ref(prefix + '/identity.json'), 'cargo_producers': e.ref(prefix + '/products.json')}


def native_comparison(e):
    d = e.json('native-cause/report.json')
    path = e.json('native-cause/packed-values-dispatch-path.json')
    return {'scope': 'Inert inspection of exact frozen NativeR bytes. Static partial-path counts and disassembly size do not establish retired instructions, cycles, or a timing cause.',
            'native_products': {name: {k: p[k] for k in ['host_sha256', 'source_fingerprint', 'layout', 'runtime_key', 'packed_sha256', 'native_bytes', 'native_sha256']} for name, p in d['products'].items()},
            'function_columns': ['function', 'baseline_bytes', 'candidate_bytes', 'baseline_entry_stack_bytes', 'candidate_entry_stack_bytes'],
            'functions': [[x['function'], x['baseline_bytes'], x['candidate_bytes'], x['baseline_stack_bytes'], x['candidate_stack_bytes']] for x in d['comparison']],
            'already_values_partial_dispatch': {name: {k: p[k] for k in ['instructions', 'stack_referencing_instructions', 'branches', 'storage_mode_loads'] if k in p} for name, p in path['products'].items()},
            'exact_extraction': e.ref('native-cause/report.json'), 'exact_dispatch_path': e.ref('native-cause/packed-values-dispatch-path.json')}


def normalized_join(e):
    report = e.json('native-cause/report.json')
    result = {'scope': 'Address-normalized disassembly identity only; instruction-fetch or placement effects have not been measured.',
              'normalization': 'Select objdump lines beginning with a hexadecimal address and colon; remove the leading instruction address; replace numeric addresses immediately before symbolic <targets> with the unchanged symbol. Register operands, constants, offsets, mnemonics and symbolic target offsets remain unchanged.',
              'functions': []}
    for name in ['helper::array_packed_join', 'builtin::Array.prototype.join']:
        pair = {}
        for product in ['baseline', 'candidate']:
            info = report['products'][product]['functions'][name]
            member = 'native-cause/' + product + '/' + info['assembly']
            stream = []
            for line in e.data(member).decode().splitlines():
                m = re.match(r'^\s*[0-9a-f]+:\s*(.+)$', line)
                if m:
                    stream.append(re.sub(r'\b[0-9a-f]+\s+(<[^>]+>)', r'\1', m.group(1)))
            normalized = ('\n'.join(stream) + '\n').encode()
            pair[product] = {'assembly': e.ref(member), 'normalized_sha256': digest(normalized),
                             'addressed_disassembly_lines': len(stream), 'symbol_value': info['value'],
                             'symbol_value_modulo_64': info['value'] % 64}
        assert pair['baseline']['normalized_sha256'] == pair['candidate']['normalized_sha256']
        result['functions'].append({'function': name, 'equal_after_normalization': True, 'products': pair})
    return result


def compact_json(value, level=0):
    indent = '  ' * level
    if isinstance(value, dict):
        return '{\n' + ',\n'.join('  ' * (level + 1) + json.dumps(k) + ': ' + compact_json(v, level + 1) for k, v in value.items()) + '\n' + indent + '}' if value else '{}'
    if isinstance(value, list):
        if all(not isinstance(x, (list, dict)) for x in value):
            return json.dumps(value, ensure_ascii=False)
        return '[\n' + ',\n'.join('  ' * (level + 1) + compact_json(v, level + 1) for v in value) + '\n' + indent + ']' if value else '[]'
    return json.dumps(value, ensure_ascii=False)


v1 = Evidence('v1', 'v1-inert.tar.xz')
v2 = Evidence('v2', 'v2/v2-inert.tar.xz')
baseline = products(v1, 'baseline')
assert baseline['source_commit'] == HEAD
assert baseline['source_fingerprint'] == 'cf48836cd6550acc4e8450bc1194d4a9416f07123fa97ccd6c5752e783667070'
original_cases = v1.json('test262-baseline-summary.json')
assert sum(x['total'] for x in original_cases['runs']) == sum(x['passed'] for x in original_cases['runs']) == 713
workloads = []
for w in v1.json('artifact-metadata.json'):
    workloads.append([w['file'], w['products']['baseline']['source_sha256'], w['products']['baseline']['derived_source_sha256']])
native_v1 = native_coverage(v1)
native_v2 = native_coverage(v2)
assert native_v1['passed'] == 2494 and native_v2['passed'] == 2493
code_v2 = normalized_join(v2)
(STAGE / 'v2-normalized-join-comparison.json').write_text(compact_json(code_v2) + '\n')
isolation = v1.json('stage-isolation/analysis.json')
baseline_build = v1.json('baseline-build.json')
candidate_v1_build = v1.json('candidate-build.json')
candidate_v2_build = v2.json('candidate-build.json')
assert baseline_build['exit_code'] == candidate_v1_build['exit_code'] == candidate_v2_build['exit_code'] == 0
image_v2 = v2.json('ordinary-image-comparison.json')
assert len(image_v2) == 18 and all(x['all_code_sections_identical'] and not x['different_standard_sections'] for x in image_v2)
report = {
    'schema': 'scriptw-array-performance-experiment-disposition-v1',
    'disposition': {
        'status': 'BOTH_CANDIDATES_REJECTED',
        'summary': 'Dense-number storage v1 and Values-first publication v2 both fail the predeclared performance gate. Production is restored to the original baseline. Only baseline-compatible semantic and snapshot regressions are retained; neither runtime candidate ships.',
        'production_baseline_commit': HEAD,
        'accepted_speedup': False,
        'acceptance_boundary': 'Candidate native coverage, baseline selected Test262 replays, and final restored-source checks are separate evidence. None constitutes full release acceptance or a new full-suite Test262 publication.'
    },
    'dates': {'measurements_utc': '2026-10-30', 'archive_verification_utc': '2026-10-31',
              'assembled_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'date_policy': 'The 20261030 filenames name the experiment cohort. Final validation and durable evidence assembly cross UTC midnight; their receipts retain actual dates.'},
    'measurement_contract': {
        'gate': 'Declared before measurement: above 5% slowdown in both balanced orders triggers an opposite-order confirmation; reproducible material regression rejects, regardless of allocation savings or other wins.',
        'original_17': 'The original ordinary scripts and separately derived strict retained-call modules are distinct boundaries. The eighteenth ordinary numeric-join-fallback diagnostic is outside the original 17; it has no retained-call result.',
        'ordinary_boundary': 'Unchanged ordinary script execution through runtime_baseline; setup and compilation phase diagnostics are reported separately from measured invocation execution.',
        'retained_boundary': 'Derived strict module exported calls through compiler_precompiled_baseline, with native admission, setup and module initialization outside the call timer. This is a diagnostic excluded from ordinary cohorts.',
        'startup_boundary': 'Fresh runtime_baseline startup processes, measured separately from ordinary invocations and retained calls.',
        'initial_order': 'ABBA then BAAB', 'confirmation_order': 'BAAB then ABBA',
        'samples': 'Each repetition uses eight product rounds, ten warmups and 21 measured samples per round. Original raw samples, per-process command receipts, output digests, resources and exact artifact identities are archived.',
        'no_external_parity_claim': 'No V8/Scriptc parity, global chart update, full conformance claim, or published speed score.'
    },
    'resources': {'machine': v1.json('machine.json'),
                  'measurement_affinity': v1.json('measurement-resources.json')['affinity'],
                  'native_scheduling': v1.json('native/receipt.json')['scheduling'],
                  'policy': 'Managed cloud verification and measurement retain the inherited finite 32 GiB cgroup and four-CPU quota; measured processes and native tests pin to one CPU, Cargo and libtest remain serial. Actual memory.swap.max=max and memory.oom.group=0; this is not the local 4 GiB/no-swap/grouped-OOM policy.',
                  'exact_resources': [v1.ref('measurement-resources.json'), v1.ref('confirmation/measurement-resources.json'), v2.ref('measurement-resources.json'), v2.ref('confirmation/measurement-resources.json')]},
    'baseline': {**baseline, 'runtime_semantic_abi': 40, 'build': v1.ref('baseline-build.json')},
    'workload_source_identity_columns': ['workload', 'original_sha256', 'strict_derived_sha256'],
    'workload_source_identities': workloads,
    'workload_provenance': 'Original/derived bytes are raw/baseline-images/<workload>.original.js and <workload>.retained.mjs in v1. Candidate bytes, retained image/native/Wasm hashes and preparation phases are in each archive artifact-metadata.json. Numeric fallback bytes/manifest are under raw/numeric-fallback-fixture/. Frozen native, executable, and Wasm payloads are deliberately excluded; their identities remain recorded.',
    'candidates': [
        {'id': 'v1-dense-number-prefix', 'status': 'REJECTED',
         'reason': 'Ordinary mixed joins slow in all four balanced groups (+8.685%, +13.266%, +11.967%, +4.986%). Retained-object calls also slow (+3.308%, +5.779%, +11.998%, +4.916%). Faster ordinary retained-object runs and fewer private buffers do not satisfy the control gate.',
         'production_change': 'Explicit DenseNumbers mode 4 and semantic ABI 41; COUNT is the occupied numeric prefix. Presence storage stays shared empty until an admitted interior hole requires a bitmap. Numeric/descriptor fallback and GC roots remain correctness obligations.',
         'products': products(v1, 'candidate'), 'runtime_semantic_abi': 41,
         'source_provenance': {'build': v1.ref('candidate-build.json'), 'compile_patch': v1.ref('compile-inputs.patch'), 'compiled_input_hashes': v1.ref('compiled-crate-inputs.json'), 'candidate_source': 'raw/implementation-v1/ retains the experimental source and tests as inert text.'},
         'mechanism': {'result': 'Encoded-Wasm/source proof removes 8,192 private presence-array allocations and 65,536 payload bytes per original retained-objects invocation, excluding GC headers. This is allocation/liveness reasoning, not live-heap or RSS telemetry.',
                       'plan': v1.ref('plan.json'), 'emitted_wasm_assertions': v1.ref('implementation-v1/crates/scriptw-aot-wasm/tests/emission/packed_array_storage.rs'),
                       'memory_result': 'Sampled ordinary retained-object RSS is essentially flat; both products retain 16 MiB GC capacity. No RSS reduction is claimed.'},
         'candidate_native_validation': native_v1,
         'candidate_original_test262': 'NOT_RUN: failed performance gate first. The 713 passing selected original cases below belong to the frozen baseline only.',
         'timing': timing(v1), 'primary_phase_and_memory': primary_memory(v1),
         'native_inspection': native_comparison(v1),
         'construction_isolation': {'scope': isolation['scope'],
                                    'interpretation': 'Construction-heavy whole lifetimes slow by 3.666%/6.242%, while 128-join lifetimes change by -1.974%/-5.673%. These diagnostics identify construction/publication as a refinement target; subtracting totals would not isolate a causal per-operation cost.',
                                    'workloads': [{k: v for k, v in x.items() if k != 'products'} for x in isolation['workloads']], 'raw': v1.ref('stage-isolation/analysis.json')},
         'predeclared_plan': v1.ref('plan.json'), 'disposition_receipt': v1.ref('v1-disposition.json')},
        {'id': 'v2-values-first-publication', 'status': 'REJECTED',
         'reason': 'Retained joins remain slower after opposite-order confirmation: 1,024 joins +9.4/+11.1/+4.7/+24.0%, singleton +9.4/+12.8/+15.4/+1.0%, empty +3.4/+12.6/+10.4/+7.8%. The initial ordinary mixed-array gain (-2.2/-1.9%) does not reproduce (+8.1/+1.0%).',
         'production_change': 'Baseline ABI 40 with only objects/packed_array_index/values.rs changed: classify Values readiness once, skip numeric attempts for existing Values, and join successful promotion into one common Values writer.',
         'products': products(v2, 'candidate'), 'runtime_semantic_abi': 40,
         'source_provenance': {'build': v2.ref('candidate-build.json'), 'compile_patch': v2.ref('compile-inputs.patch'), 'compiled_input_hashes': v2.ref('compiled-crate-inputs.json'), 'candidate_source': 'raw/implementation/ retains the experimental source and tests as inert text.'},
         'candidate_native_validation': native_v2,
         'candidate_original_test262': 'NOT_RUN: failed performance gate first. Prepared mutation controls were not run and are not acceptance evidence.',
         'timing': timing(v2), 'primary_phase_and_memory': primary_memory(v2),
         'native_inspection': native_comparison(v2),
         'native_interpretation': 'The valid already-Values static partial dispatch shrinks from 65 to 15 listed instructions, ten to three branches and three to one classification dereference stages. Default-data publication shrinks 9,950→9,780 bytes with a 272-byte entry frame; descriptor publication grows 21,632→21,688 bytes and 256→272 entry-stack bytes. NativeR grows 4,080 bytes. These counts establish emitted structure, not cycles or speed.',
         'program_and_join_identity': {'all_18_ordinary_program_standard_sections_identical': True, 'program_comparison': v2.ref('ordinary-image-comparison.json'),
                                       'normalized_join_comparison': code_v2,
                                       'placement_observation': 'array_packed_join moves from address modulo 64 = 0 to 32. The observed cache-line position shift is not causal proof; instruction-fetch, placement and dynamic execution remain unmeasured.'},
         'predeclared_plan': v2.ref('plan.json'), 'disposition_receipt': v2.ref('disposition.json')}
    ],
    'baseline_selected_original_test262': {
        'scope': 'Frozen baseline only: eleven original pinned families, 713/713 executions. Selected replay is not the full suite or a status publication.',
        'executable_sha256': original_cases['runs'][0]['executable_sha256'],
        'policy': {'suite_root': 'test262/vendor/test262', 'execution_backend': 'wasm-aot', 'jobs': 1, 'threads': 1, 'timeout_ms': 60000, 'reuse_case_workers': True},
        'columns': ['family', 'passed', 'total', 'raw_log_member'],
        'families': [[x['scope'], x['passed'], x['total'], 'raw/' + x['raw']] for x in original_cases['runs']],
        'summary': v1.ref('test262-baseline-summary.json'),
        'snapshots': 'v1 raw/test262-baseline/ contains all original per-case snapshot results and progress; raw/test262-baseline-*.receipt.json records original argv, deadlines and executable digest.'},
    'formatting_and_source_checks': {'result': 'Both candidate formatting comparisons retain the same eighteen pre-existing full-format failures and zero newly failing files. Source guards pass separately; product-graph and source ownership checks are archived.',
                                     'receipts': [v1.ref('format-comparison.json'), v2.ref('format-comparison.json'), v1.ref('conformance-owners.log'), v1.ref('intl-source-identities.log'), v1.ref('product-graph.log'), v2.ref('conformance-owners.log'), v2.ref('intl-source-identities.log'), v2.ref('product-graph.log')]},
    'final_restored_source_validation': {'status': 'PENDING_FINAL_NATIVE_RECEIPT', 'scope': 'Only the retained baseline-compatible semantic and snapshot regressions will be reported here; candidate native totals must not be transferred to this source.'},
    'raw_archives': [],
    'open_acceptance': ['Full default/all-feature, ignored, documentation, differential, robustness and complete pinned conformance acceptance remain open.',
                        'No candidate original Test262 comparison or mutation-control execution is claimed.',
                        'Further runtime work needs a measured dynamic cause and a fresh gate; neither rejected runtime candidate is retained in production.']
}
for key in ['v1', 'v2']:
    validation = json.loads((STAGE / (key + '-validation.json')).read_text())
    report['raw_archives'].append({'path': NAMES[key], **{k: v for k, v in validation.items() if k not in ['archive', 'executable_mode_text_files']},
                                   'payload_policy': 'Inert source, patches, disassembly, commands, hashes, receipts, logs and samples only. No native executable, Wasm module or retained-image payload.'})
out = STAGE / 'array-storage-experiments-20261030.json'
out.write_text(compact_json(report) + '\n')
assert json.loads(out.read_text()) == report
print(json.dumps({'path': str(out), 'bytes': out.stat().st_size, 'candidate_native': [native_v1['passed'], native_v2['passed']], 'timing_rows': [len(c['timing']['rows']) for c in report['candidates']]}, indent=2))
