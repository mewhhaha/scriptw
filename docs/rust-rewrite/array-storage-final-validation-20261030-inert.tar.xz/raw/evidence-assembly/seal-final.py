"""Preserve final restored-source verification as inert, hashed regular members."""
from pathlib import Path
import datetime
import gzip
import hashlib
import io
import json
import subprocess
import tarfile

ROOT = Path('/workspace/scriptw')
WORK = ROOT / 'target/performance-dense-numbers-20261030'
STAGE = WORK / 'evidence-staging'
HEAD = '28bbffe0c7e930fab457d2e4dc69b75fa90d5f60'
OUT = STAGE / 'array-storage-final-validation-20261030-inert.tar.xz'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    assert path.is_file() and not path.is_symlink(), path
    return path.read_bytes()


def git(*args):
    p = subprocess.run(['git', *args], cwd=ROOT, capture_output=True)
    return p


head = git('rev-parse', 'HEAD')
assert head.returncode == 0 and head.stdout.decode().strip() == HEAD
production_paths = ':(glob)crates/*/src/**'
tracked_diff = git('diff', '--quiet', HEAD, '--', production_paths)
assert tracked_diff.returncode == 0, tracked_diff.stderr.decode()
untracked = git('ls-files', '--others', '--exclude-standard', '--', production_paths)
assert untracked.returncode == 0 and not untracked.stdout
source_list = git('ls-files', '--', production_paths)
assert source_list.returncode == 0 and source_list.stdout
production_match = {
    'checked_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'baseline_commit': HEAD,
    'tracked_production_source_pathspec': production_paths,
    'tracked_production_files': len(source_list.stdout.splitlines()),
    'tracked_production_file_list_sha256': sha(source_list.stdout),
    'git_diff_HEAD_exit_code': tracked_diff.returncode,
    'untracked_production_files': 0,
    'result': 'Every tracked crates/*/src file matches the baseline Git tree; no untracked production source file exists.',
    'fingerprint_binding': 'The frozen baseline artifact receipts bind this baseline commit to compiler source fingerprint cf48836cd6550acc4e8450bc1194d4a9416f07123fa97ccd6c5752e783667070. No new production artifact execution is claimed.'
}
(STAGE / 'production-baseline-match.json').write_text(json.dumps(production_match, indent=2) + '\n')
receipt = json.loads(read(WORK / 'final-native/receipt.json'))
validation = json.loads(read(WORK / 'final-source-validation.json'))
assert receipt['source_unchanged'] and receipt['shared_runtime_linker_unchanged']
assert validation['passed'] == 2 and validation['source_unchanged']
assert validation['production_matches_baseline_commit'] == HEAD
files = {}
for path in sorted((WORK / 'final-native').iterdir()):
    if path.is_file():
        assert path.suffix in ['.json', '.log', '.gz']
        files['raw/final-native/' + path.name] = read(path)
files['raw/final-native.log'] = read(WORK / 'final-native.log')
files['raw/final-source-validation.json'] = read(WORK / 'final-source-validation.json')
files['raw/production-baseline-match.json'] = read(STAGE / 'production-baseline-match.json')
files['raw/production-baseline-file-list.txt'] = source_list.stdout
source_copy_verification = []
for archive_path, prefix, key in [
    (WORK / 'v1-inert.tar.xz', 'implementation-v1/', 'v1'),
    (WORK / 'v2/v2-inert.tar.xz', 'implementation/', 'v2'),
]:
    with tarfile.open(archive_path, 'r:xz') as candidate_tar:
        inputs = json.load(candidate_tar.extractfile('raw/compiled-crate-inputs.json'))
        for source_path, expected in inputs.items():
            archived_name = 'raw/' + prefix + source_path
            try:
                data = candidate_tar.extractfile(archived_name).read()
                location = archived_name
            except KeyError:
                assert key == 'v1' and source_path == 'crates/scriptw-aot-wasm/src/runtime_artifact/cache/tests.rs'
                data = read(WORK / prefix / source_path)
                location = 'raw/supplemental-v1-source/' + source_path
                files[location] = data
            assert sha(data) == expected
            source_copy_verification.append({'candidate': key, 'source': source_path,
                                             'preserved_member': location, 'sha256': expected})
files['raw/evidence-assembly/compiled-source-copy-verification.json'] = (json.dumps({
    'result': 'All seventeen v1 and five v2 compiled-input source digests match their preserved text.',
    'supplement': 'The v1 packager excludes every directory named cache, omitting one source copy under src/runtime_artifact/cache. Its full change already exists in the sealed v1 compile-inputs.patch. This final archive additionally preserves its exact source bytes from the immutable implementation-v1 copy, checked against the original compiled-input SHA-256. The sealed v1 archive is unchanged.',
    'files': source_copy_verification}, indent=2) + '\n').encode()
for name in ['v1-validation.json', 'v2-validation.json', 'v2-normalized-join-comparison.json', 'assemble.py', 'seal-final.py']:
    files['raw/evidence-assembly/' + name] = read(STAGE / name)
for name in ['final-format-comparison.json', 'final-format.log']:
    path = WORK / name
    if path.exists():
        files['raw/' + name] = read(path)
for name, expected in validation['files'].items():
    data = read(ROOT / name)
    assert sha(data) == expected
    files['raw/final-tests/' + name] = data
patch = git('diff', '--binary', HEAD, '--', 'crates')
assert patch.returncode == 0
files['raw/final-tests/tracked-tests.patch'] = patch.stdout
watchers = []
for case in receipt['cases']:
    assert case['state'] == 'passed' and case['exit_code'] == 0 and case['inventory_matches']
    assert case['inventoried_tests'] == 1
    assert case['outcomes'] == [{'passed': 1, 'failed': 0, 'ignored': 0}]
    data = read(ROOT / case['transcript_log'])
    assert sha(data) == case['transcript_sha256']
    archived = 'raw/immutable-final-native/' + Path(case['transcript_log']).name
    files[archived] = data
    watchers.append({'original': case['transcript_log'], 'immutable_copy': archived, 'sha256': sha(data), 'target': case['target']})
    inv = read(ROOT / case['inventory_log'])
    assert sha(inv) == case['inventory_sha256']
    for log in case.get('sealed_build_logs', []):
        compressed = read(ROOT / log['path'])
        assert sha(compressed) == log['gzip_sha256']
        uncompressed = gzip.decompress(compressed)
        assert sha(uncompressed) == log['uncompressed_sha256']
        assert len(uncompressed) == log['uncompressed_bytes']
files['raw/final-native-transcript-map.json'] = (json.dumps(watchers, indent=2) + '\n').encode()
for name, data in files.items():
    assert not data.startswith((b'\x7fELF', b'\x00asm', b'SCRWEP')), name
index = {'scope': 'Restored production baseline with two retained regression tests; not the wide native candidate cohorts or full release acceptance.',
         'packaged_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
         'mapping': 'raw/final-native maps to the completed final-native driver output. raw/immutable-final-native contains exact immutable watcher copies bound by final-native-transcript-map.json. raw/final-tests contains the retained test bytes at their original relative paths. No executable, native, retained-image or Wasm payload is included.',
         'members': [{'path': name.removeprefix('raw/'), 'bytes': len(data), 'sha256': sha(data)} for name, data in sorted(files.items())]}
index_data = (json.dumps(index, indent=2) + '\n').encode()
with tarfile.open(OUT, 'w:xz', preset=6) as tf:
    for name, data in [*sorted(files.items()), ('evidence-index.json', index_data)]:
        entry = tarfile.TarInfo(name)
        entry.size = len(data)
        entry.mode = 0o644
        entry.mtime = int(datetime.datetime.now(datetime.timezone.utc).timestamp())
        tf.addfile(entry, io.BytesIO(data))
seen = {}
with tarfile.open(OUT, 'r|xz') as tf:
    for member in tf:
        assert member.isfile() and member.name not in seen
        data = tf.extractfile(member).read()
        assert len(data) == member.size
        seen[member.name] = {'bytes': len(data), 'sha256': sha(data)}
expected = {'raw/' + x['path']: {'bytes': x['bytes'], 'sha256': x['sha256']} for x in index['members']}
assert set(seen) == set(expected) | {'evidence-index.json'}
assert all(seen[name] == item for name, item in expected.items())
result = {'archive': OUT.name, 'sha256': sha(OUT.read_bytes()), 'bytes': OUT.stat().st_size,
          'members': len(seen), 'expanded_member_bytes': sum(x['bytes'] for x in seen.values()),
          'index_sha256': sha(index_data), 'regular_files_only': True,
          'all_indexed_member_sizes_and_sha256_match': True, 'native_payloads_archived': False,
          'verified_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
(STAGE / 'final-archive-validation.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
