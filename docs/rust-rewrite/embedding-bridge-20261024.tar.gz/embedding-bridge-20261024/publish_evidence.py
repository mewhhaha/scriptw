#!/usr/bin/env python3
"""Validate closed embedding evidence; publish only with an explicit --publish.

No test, compiler or example executes here. All verdicts come from immutable
native logs, inventories and snapshots. Configure final paths/labels using
publication-inputs.json in this directory (or --inputs PATH).
"""
from __future__ import annotations

import argparse
import collections
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tarfile
import types

BASE = Path(__file__).resolve().parent
REPO = BASE.parent.parent
SOURCE = "4ad59d1ebbc64c9e3384aee9cefd19e3c8b8e92d"
EMPTY_PATCH = hashlib.sha256(b"").hexdigest()
STRUCTURAL_PATCH = "2d1030a5e3c45e10d81cd8b6a170c2703e58865a501d57bb9b43702a1940fc2c"
UTF16_PATCH = "76082799887d24e2782063f02283633ba6bd7d4737ea495dfa10f64c7685d465"
EXPORTS_PATCH = "bf447e9e2a2c237fe1aeae54a4e7fb454f22cf3e55a98bd05f968d9434d19d2d"
FIXTURE_PATCH = "6af747d35ab196853d7d8218b2a3a62da4ada2e7a11047432a262d1ef055a2d4"
ALL_PATCHES = {EMPTY_PATCH, STRUCTURAL_PATCH, UTF16_PATCH, EXPORTS_PATCH, FIXTURE_PATCH}
FIXTURE_FILE = "crates/scriptw-aot-wasm/tests/modules_realms/compiled_module_package_structure.rs"
FIXTURE_TARGET = "broad-02-scriptw-aot-wasm-modules_realms"
FIXTURE_FAILURE = "compiled_module_package_structure::emitter_consumes_the_package_through_the_reviewed_lifecycle"
TRANSFER_FIXTURE = "crates/scriptw-engine/src/embedding/tests/transfer_retained.rs"
DOCUMENTATION_FILE = "crates/scriptw-engine/src/embedding/operations.rs"
EXECUTION_FIXTURE = "crates/scriptw-engine/src/tests/execution.rs"
NAMESPACE_FIXTURE = "crates/scriptw-ir/src/modules/namespace.rs"
IR_TARGET = "broad-20-scriptw-ir-lib"
IR_FAILURE = "modules::namespace::tests::the_prelude_is_empty_when_no_namespace_is_observed"
FIXTURE_FILES = sorted([FIXTURE_FILE, TRANSFER_FIXTURE, DOCUMENTATION_FILE, EXECUTION_FIXTURE, NAMESPACE_FIXTURE])
ENGINE_SURFACE_FAILURE = "tests::execution::wasm_backend_characterization_matrix_locks_public_surface_and_outcomes"
ENGINE_TRANSFER_FAILURE = "embedding::tests::transfer_retained::retained_exports_preserve_live_bindings_receivers_proxies_throws_and_gc_roots"
PREFIX = "embedding-bridge-20261024/"
STEM = "embedding-bridge-20261024"
BUDGET = 4 * 1024**3
LEGACY_RESOURCE_LABELS = {
    "broad-00-scriptw-aot-wasm-lib-inventory", "broad-00-scriptw-aot-wasm-lib",
    "frozen-build-final-scriptw-aot-wasm", "frozen-build-scriptw-cli",
    "frozen-build-scriptw-engine", "frozen-build-scriptw-ir", "frozen-build-scriptw-runtime-image",
}
LAUNCHER_SHA256 = "3e69a0d1651f865dc611f7fccb71f819d341f70425e02145af37e70832606f57"
CACHE = {"SCRIPTW_MODULE_MEMORY_CACHE_ENTRIES": "1", "SCRIPTW_MODULE_MEMORY_CACHE_LIMIT_BYTES": str(64 * 1024**2)}
KNOWN = {
    "sloppy-script:annexB/language/function-code/block-decl-func-skip-arguments.js",
    "sloppy-script:intl402/Temporal/ZonedDateTime/links.js",
    "strict-script:intl402/Temporal/ZonedDateTime/links.js",
    "sloppy-script:staging/sm/lexical-environment/block-scoped-functions-annex-b-label.js",
}
SUMMARY_RE = re.compile(r"test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def read_json(path):
    path = Path(path)
    require(path.is_file() and not path.is_symlink(), f"missing or symlinked evidence: {path}")
    return json.loads(path.read_text())


def member_path(path):
    path = Path(path)
    require(path.is_file() and not path.is_symlink(), f"missing or symlinked archive input: {path}")
    resolved = path.resolve()
    require(resolved.is_relative_to(REPO), f"archive input escaped repository: {path}")
    require(path.stat().st_size < 64 * 1024**2, f"oversized evidence member: {path}")
    with path.open("rb") as stream:
        require(stream.read(4) != b"\x7fELF", f"executables are excluded: {path}")
    relative = resolved.relative_to(BASE) if resolved.is_relative_to(BASE) else Path("reproduction") / resolved.relative_to(REPO)
    require(not any(part in {"cache", "execution-cache", "hot-cache", "tmp", "__pycache__", ".git"} for part in relative.parts), f"cache/temporary input excluded: {path}")
    return PREFIX + relative.as_posix()


class Evidence:
    def __init__(self):
        self.paths = {}
        self.resources = []

    def add(self, path):
        path = Path(path)
        name = member_path(path)
        if name in self.paths:
            require(self.paths[name].resolve() == path.resolve(), f"duplicate archive name: {name}")
        self.paths[name] = path
        return name

    def resource(self, receipt, label, *, boundary=False):
        require(str(receipt.get("memory.max")) == str(BUDGET), f"{label}: missing exact 4-GiB cap")
        require(str(receipt.get("memory.swap.max")) == "0", f"{label}: swap must be zero")
        affinity = receipt.get("cpu_affinity")
        require(isinstance(affinity, list) and len(affinity) == 1 and type(affinity[0]) is int, f"{label}: one CPU not established")
        events = dict(line.split() for line in receipt.get("memory.events", "").splitlines())
        require(all(events.get(key) == "0" for key in ["oom", "oom_kill", "oom_group_kill"]), f"{label}: OOM counters are absent or nonzero")
        peak = int(receipt.get("memory.peak", -1))
        require(0 <= peak <= BUDGET, f"{label}: invalid cgroup peak")
        environment = receipt.get("resource_environment", receipt.get("environment", receipt.get("payload_cache_environment", {})))
        if "memory.oom.group" in receipt and environment:
            require(str(receipt["memory.oom.group"]) == "1", f"{label}: grouped OOM termination not established")
            require(all(str(environment.get(k)) == v for k, v in CACHE.items()), f"{label}: bounded cache environment not established")
            for name in ["CARGO_BUILD_JOBS", "SCRIPTW_JOBS", "RUST_TEST_THREADS", "RAYON_NUM_THREADS"]:
                require(environment.get(name) == "1", f"{label}: serial worker defaults not established")
            provenance = "observed kernel group and inherited environment fields"
        else:
            require(not boundary and label in LEGACY_RESOURCE_LABELS, f"{label}: group/cache observations missing outside the explicit legacy receipt inventory")
            launcher = REPO / "scripts/limited_verification.py"
            require(digest(launcher) == LAUNCHER_SHA256, "archived launcher policy source changed")
            provenance = "archived verified launcher policy; group/cache fields were not observed in this early receipt"
        self.resources.append({"label": label, "cpu_affinity": affinity, "memory_peak": peak, "events": events, "group_and_cache_provenance": provenance})

    def receipt(self, label, *, exit_code=0):
        require(re.fullmatch(r"[A-Za-z0-9_-]+", label) is not None, f"invalid receipt label: {label}")
        path = BASE / f"{label}.json"
        receipt = read_json(path)
        require(receipt.get("label") == label, f"{label}: receipt label mismatch")
        require(receipt.get("source_head") == SOURCE, f"{label}: receipt source is not final {SOURCE}")
        require(receipt.get("source_patch_sha256") in ALL_PATCHES, f"{label}: source differs beyond the exact authorized test-fixture patch")
        require(receipt.get("exit_code") == exit_code, f"{label}: actual command exit is not {exit_code}")
        require(isinstance(receipt.get("command"), list) and receipt["command"], f"{label}: missing exact command")
        require(receipt.get("log") == f"{label}.log", f"{label}: unexpected log path")
        log = BASE / receipt["log"]
        require(log.is_file() and digest(log) == receipt.get("log_sha256"), f"{label}: actual log hash mismatch")
        self.resource(receipt, label)
        self.add(path)
        self.add(log)
        return receipt, log.read_text(errors="replace")



def verification_fixture(evidence):
    patch_path = BASE / "verification-fixture.patch"
    require(digest(patch_path) == FIXTURE_PATCH, "exact verification fixture patch is missing or changed")
    difference = subprocess.check_output(["git", "diff", "--binary", SOURCE, "--", "crates", "Cargo.toml", "Cargo.lock"], cwd=REPO)
    require(difference == patch_path.read_bytes(), "production/source inputs differ beyond the exact test-only fixture patch")
    names = subprocess.check_output(["git", "diff", "--name-only", SOURCE, "--", "crates", "Cargo.toml", "Cargo.lock"], cwd=REPO, text=True).splitlines()
    require(names == FIXTURE_FILES, "source tree changed outside the exact test fixtures and API documentation")
    documentation_before = subprocess.check_output(["git", "show", SOURCE + ":" + DOCUMENTATION_FILE], cwd=REPO)
    documentation_after = (REPO / DOCUMENTATION_FILE).read_bytes()
    require(documentation_before.replace(b"    /// Read an export whose name may contain isolated UTF-16 surrogates.\n", b"    /// Look up a live module export using a UTF-16 key.\n", 1) == documentation_after, "API implementation changed beyond its exact doc-comment correction")
    structural_path = BASE / "verification-fixture-structural-only.patch"
    require(digest(structural_path) == STRUCTURAL_PATCH, "original structural-only patch changed")
    require(subprocess.check_output(["git", "diff", "--binary", SOURCE, "--", FIXTURE_FILE], cwd=REPO) == structural_path.read_bytes(), "structural fixture correction differs from the retained original patch")
    evidence.add(structural_path)
    utf16_path = BASE / "verification-fixture-utf16.patch"
    require(digest(utf16_path) == UTF16_PATCH, "intermediate UTF-16 fixture patch changed")
    require(subprocess.check_output(["git", "diff", "--binary", SOURCE, "--", FIXTURE_FILE, TRANSFER_FIXTURE, DOCUMENTATION_FILE], cwd=REPO) == utf16_path.read_bytes(), "intermediate fixture/doc correction differs from retained patch")
    evidence.add(utf16_path)
    exports_path = BASE / "verification-fixture-exports.patch"
    require(digest(exports_path) == EXPORTS_PATCH, "intermediate export-surface fixture patch changed")
    require(subprocess.check_output(["git", "diff", "--binary", SOURCE, "--", FIXTURE_FILE, TRANSFER_FIXTURE, DOCUMENTATION_FILE, EXECUTION_FIXTURE], cwd=REPO) == exports_path.read_bytes(), "intermediate export-surface correction differs from retained patch")
    evidence.add(exports_path)
    namespace_before = subprocess.check_output(["git", "show", SOURCE + ":" + NAMESPACE_FIXTURE], cwd=REPO)
    namespace_after = (REPO / NAMESPACE_FIXTURE).read_bytes()
    test_marker = b"#[cfg(test)]\nmod tests {"
    require(namespace_before.count(test_marker) == namespace_after.count(test_marker) == 1 and namespace_before.split(test_marker)[0] == namespace_after.split(test_marker)[0], "namespace production prefix changed outside cfg(test) module")
    untracked = subprocess.check_output(["git", "ls-files", "--others", "--exclude-standard", "--", "crates", "Cargo.toml", "Cargo.lock"], cwd=REPO)
    require(untracked == b"", "untracked product files are outside the tested source authority")
    label = FIXTURE_TARGET + "-failed-original"
    original, log = evidence.receipt(label, exit_code=101)
    require(original.get("source_patch_sha256") == EMPTY_PATCH, "original structural failure did not run against the unpatched fixture")
    require(SUMMARY_RE.findall(log) == [("FAILED", "73", "1", "0", "0", "0")], "original structural failure is not the exact73-pass/1-failure attempt")
    observed = [(name.removesuffix(" - should panic"), status) for name, status in re.findall(r"^test (.+) \.\.\. (ok|FAILED|ignored)$", log, re.M)]
    inventory_log = BASE / (FIXTURE_TARGET + "-inventory.log")
    inventory = sorted(re.findall(r"^([^\s]+): test$", inventory_log.read_text(), re.M))
    require(original.get("executables") == read_json(BASE / (FIXTURE_TARGET + "-inventory.json")).get("executables"), "original failed executable differs from the original exact inventory binary")
    require(len(inventory) == 74 and sorted(name for name, _ in observed) == inventory, "original failed attempt did not cover the same exact74 identities")
    require([(name, status) for name, status in observed if status != "ok"] == [(FIXTURE_FAILURE, "FAILED")], "original failure differs from the known stale structural assertion")
    ir_original, ir_log = evidence.receipt(IR_TARGET + "-failed-original", exit_code=101)
    require(ir_original.get("source_patch_sha256") == EXPORTS_PATCH and SUMMARY_RE.findall(ir_log) == [("FAILED", "1625", "1", "0", "0", "0")], "original IR failure is not the exact1625/1 stale Script-entry fixture attempt")
    ir_observed = [(name.removesuffix(" - should panic"), status) for name, status in re.findall(r"^test (.+) \.\.\. (ok|FAILED|ignored)$", ir_log, re.M)]
    ir_inventory = sorted(re.findall(r"^([^\s]+): test$", (BASE / (IR_TARGET + "-inventory.log")).read_text(), re.M))
    require(len(ir_inventory) == 1626 and sorted(name for name, _ in ir_observed) == ir_inventory and [name for name, status in ir_observed if status != "ok"] == [IR_FAILURE], "original IR fixture failure used another identity inventory")
    require(ir_original.get("executables") == read_json(BASE / (IR_TARGET + "-inventory.json")).get("executables"), "original IR failure binary differs from its exact inventory")
    evidence.add(patch_path)
    return {"file": patch_path.name, "sha256": FIXTURE_PATCH, "changed_files": FIXTURE_FILES, "source_tree_completely_clean": False, "runtime_compiler_implementation_changed": False, "production_source_documentation_change": DOCUMENTATION_FILE, "reason": "fix structural helper-call assertion, use a valid astral export name while checking lone-surrogate object keys, update exact expected embedding exports, use an unobserved Script-entry namespace fixture, and correct API documentation without changing implementation", "earlier_patches": [{"file": structural_path.name, "sha256": STRUCTURAL_PATCH}, {"file": utf16_path.name, "sha256": UTF16_PATCH}, {"file": exports_path.name, "sha256": EXPORTS_PATCH}], "namespace_cfg_test_production_prefix_unchanged": True, "additional_failed_attempts": [{"receipt": IR_TARGET + "-failed-original.json", "exit_code": 101, "passed": 1625, "failed": 1, "failure": IR_FAILURE, "excluded_from_accepted_total": True, "required_rerun_passed": 1626}], "original_failed_attempt": {"receipt": label + ".json", "exit_code": 101, "passed": 73, "failed": 1, "ignored": 0, "failure": FIXTURE_FAILURE, "executables": original.get("executables", []), "excluded_from_accepted_total": True}, "accepted_rerun": {"receipt": FIXTURE_TARGET + ".json", "required_passed": 74, "required_failed": 0, "inventory_unchanged": True}}


def engine_native(evidence, recorded, scope):
    aggregate_path = BASE / "engine-accepted.json"
    aggregate = read_json(aggregate_path)
    require(aggregate == recorded, "engine aggregate row differs from native-closed")
    require(aggregate.get("source_head") == SOURCE and aggregate.get("source_patch_sha256") in ALL_PATCHES, "engine aggregate source/patch is not admitted")
    require(aggregate.get("complete") is True and aggregate.get("exit_code") == 0 and aggregate.get("passed") == 1029 and aggregate.get("batch_manifest") == "engine-batches.json", "engine aggregate is not complete")
    require("log" not in aggregate and "test_results" not in aggregate and "disjoint" in aggregate.get("aggregation", "") and "no synthetic single-process transcript" in aggregate.get("aggregation", ""), "engine aggregation must not invent a single-process result")
    manifest_path = BASE / "engine-batches.json"
    manifest = read_json(manifest_path)
    require(manifest.get("source_head") == SOURCE and manifest.get("complete") is True, "engine batch manifest is incomplete or stale")
    inventory = manifest.get("inventory", [])
    require(len(inventory) == len(set(inventory)) == 1029 and sorted(inventory) == inventory and aggregate.get("inventory") == inventory, "engine aggregate/manifest denominator differs")
    original_inventory, original_inventory_log = evidence.receipt("broad-07-scriptw-engine-lib-inventory")
    fresh_inventory, fresh_inventory_log = evidence.receipt("engine-batches-inventory")
    for label, transcript in [("original", original_inventory_log), ("fresh", fresh_inventory_log)]:
        actual = sorted(re.findall(r"^([^\s]+): test$", transcript, re.M))
        require(actual == inventory, f"engine {label} inventory differs from the exact1029 denominator")
    require(fresh_inventory["command"][1:] == ["--list", "--include-ignored"], "fresh engine inventory command differs")
    require(Path(fresh_inventory["command"][0]).resolve() == Path(manifest["binary"]).resolve(), "engine batch binary path differs from its fresh inventory")
    observed_names = []
    labels = []
    batches = []
    executable_states = {}
    for index, selected in enumerate(manifest.get("batches", [])):
        label = selected.get("label")
        require(label == f"engine-batch-{index:03d}" and set(selected) == {"label", "inventory"}, "engine batch labels/fields are not exact")
        names = selected["inventory"]
        require(isinstance(names, list) and 1 <= len(names) <= 32 and len(set(names)) == len(names), f"{label}: invalid bounded inventory")
        require(set(names).issubset(inventory), f"{label}: case outside original engine inventory")
        if any(name.startswith("runtime_profile::") or "capacity" in name or "inlining" in name for name in names):
            require(len(names) == 1, f"{label}: high-retention profile/capacity test was not isolated")
        receipt, log = evidence.receipt(label)
        command = receipt["command"]
        require(Path(command[0]).resolve() == Path(manifest["binary"]).resolve() and command[1:] == names + ["--exact", "--test-threads=1", "--include-ignored"], f"{label}: actual exact-name invocation differs")
        actual = [(name.removesuffix(" - should panic"), status) for name, status in re.findall(r"^test (.+) \.\.\. (ok|FAILED|ignored)$", log, re.M)]
        require(sorted(name for name, _ in actual) == sorted(names) and all(status == "ok" for _, status in actual), f"{label}: exact selected identities did not all pass")
        expected_summary = ("ok", str(len(names)), "0", "0", "0", str(1029 - len(names)))
        require(SUMMARY_RE.findall(log) == [expected_summary] and receipt.get("test_results") == [list(expected_summary)], f"{label}: native counts/filtered complement do not reconcile")
        executables = receipt.get("executables", [])
        require(len(executables) == 1 and Path(executables[0]["path"]).resolve() == Path(manifest["binary"]).resolve() and re.fullmatch(r"[0-9a-f]{64}", executables[0]["sha256"]) is not None, f"{label}: actual native binary hash is missing")
        if ENGINE_SURFACE_FAILURE in names:
            require(receipt.get("source_patch_sha256") in {EXPORTS_PATCH, FIXTURE_PATCH}, "engine surface characterization did not rerun the corrected exact export list")
        if ENGINE_TRANSFER_FAILURE in names:
            require(receipt.get("source_patch_sha256") in {UTF16_PATCH, EXPORTS_PATCH, FIXTURE_PATCH}, "retained export test did not use the valid Unicode fixture")
        key = (executables[0]["sha256"], receipt["source_patch_sha256"])
        state = executable_states.setdefault(key, {"binary": executables[0], "source_patch_sha256": receipt["source_patch_sha256"], "batch_labels": []})
        state["batch_labels"].append(label)
        observed_names.extend(name for name, _ in actual)
        labels.append(label)
        batches.append({"label": label, "passed": len(names), "filtered_complement": 1029 - len(names), "source_patch_sha256": receipt["source_patch_sha256"], "binary_sha256": executables[0]["sha256"], "inventory_sha256": hashlib.sha256(("\n".join(sorted(names)) + "\n").encode()).hexdigest()})
    require(sorted(observed_names) == inventory and len(observed_names) == len(set(observed_names)) == 1029, "actual passing engine batch union omitted/repeated identities")
    require(aggregate.get("source_patch_sha256") in {EXPORTS_PATCH, FIXTURE_PATCH} and aggregate.get("source_patch_states") == sorted({state["source_patch_sha256"] for state in executable_states.values()}), "aggregate final patch/per-batch patch-state inventory differs from actual receipts")
    for path in sorted(BASE.glob("engine-batches-*build*.json")):
        build, _ = evidence.receipt(path.stem)
        command = build["command"]
        require(command[:2] == ["cargo", "test"] and "--no-run" in command and "scriptw-engine" in command and "--lib" in command and command[command.index("--jobs") + 1] == "1", "engine batch build is not an actual serial engine-lib build")
    require((BASE / "engine-batches-build.json").is_file(), "original fresh-engine build receipt is absent")
    # The original process was killed before run_check could write its normal
    # post-exit receipt. Preserve the explicit terminal receipt and real journal.
    cap_path = BASE / "broad-07-scriptw-engine-lib-cap-terminated-original.json"
    cap = read_json(cap_path)
    require(cap.get("source_head") == SOURCE and cap.get("exit_code") == 137 and cap.get("complete") is False, "original engine cap termination authority differs")
    require(cap.get("command") == ["cargo", "test", "--locked", "--release", "--jobs", "1", "-p", "scriptw-engine", "--lib", "--", "--test-threads=1", "--include-ignored"], "original capped engine command differs from the full original target")
    cap_log_path = BASE / cap["log"]
    require(Path(cap["log"]).name == cap["log"] and digest(cap_log_path) == cap.get("log_sha256"), "original cap-terminated transcript changed")
    cap_log = cap_log_path.read_text(errors="replace")
    partial = [(name.removesuffix(" - should panic"), status) for name, status in re.findall(r"^test (.+) \.\.\. (ok|FAILED|ignored)$", cap_log, re.M)]
    require(not SUMMARY_RE.findall(cap_log) and len({name for name, _ in partial}) == len(partial) and all(name in inventory for name, _ in partial), "cap-terminated attempt masquerades as a closed or different inventory")
    require([name for name, status in partial if status != "ok"] == [ENGINE_TRANSFER_FAILURE], "original partial engine attempt contains an unaccounted failure")
    journal_path = BASE / "oom-journal.log"
    journal = journal_path.read_text()
    require("run-p3741438-i3745811.scope" in journal and "Oct 24 23:36:16" in journal and "kernel OOM killer killed" in journal and "Europe/Warsaw" in journal, "original engine OOM is not supported by its actual scope journal")
    for path in [cap_path, cap_log_path, journal_path, aggregate_path, manifest_path]:
        evidence.add(path)
    failed, failed_log = evidence.receipt("engine-batch-042-failed-original", exit_code=101)
    require(failed.get("source_patch_sha256") == UTF16_PATCH and SUMMARY_RE.findall(failed_log) == [("FAILED", "31", "1", "0", "0", "997")], "original surface characterization failure is not the known31/1 attempt")
    failing_names = [(name.removesuffix(" - should panic"), status) for name, status in re.findall(r"^test (.+) \.\.\. (ok|FAILED|ignored)$", failed_log, re.M)]
    require(sorted(name for name, _ in failing_names) == sorted(manifest["batches"][42]["inventory"]) and [name for name, status in failing_names if status != "ok"] == [ENGINE_SURFACE_FAILURE], "original surface failure did not use the corrected batch's exact 32 IDs")
    return {**scope, "passed": 1029, "inventory_sha256": hashlib.sha256(("\n".join(inventory) + "\n").encode()).hexdigest(), "verification": "disjoint exact native batch observations", "aggregate_receipt": aggregate_path.name, "batch_manifest": manifest_path.name, "batch_count": len(batches), "batches": batches, "binary_patch_states": list(executable_states.values()), "aggregate_final_verification_patch_sha256": aggregate["source_patch_sha256"], "source_patch_authority": "each actual batch receipt; aggregate field describes the final verification tree", "original_inventory_receipt": "broad-07-scriptw-engine-lib-inventory.json", "fresh_inventory_receipt": "engine-batches-inventory.json", "historical_unaccepted_attempts": [{"receipt": cap_path.name, "exit_code": 137, "complete": False, "partial_passed": sum(status == "ok" for _, status in partial), "partial_failures": [name for name, status in partial if status != "ok"], "oom_journal": journal_path.name, "oom_scope": "run-p3741438-i3745811.scope", "excluded_from_accepted_total": True, "binary_identity_provenance": "original full inventory receipt; no post-exit run_check receipt survived the grouped termination", "inventory_binary": original_inventory.get("executables", [])}, {"receipt": failed["label"] + ".json", "exit_code": 101, "passed": 31, "failed": 1, "failure": ENGINE_SURFACE_FAILURE, "excluded_from_accepted_total": True}]}


def native(evidence):
    scopes = read_json(BASE / "native-scopes.json")
    closed = read_json(BASE / "native-closed.json")
    require(len(scopes) == 23 and len({(s["package"], s["kind"], s["name"]) for s in scopes}) == 23, "native scopes must contain exactly 23 unique targets")
    require(closed.get("source") == SOURCE and closed.get("complete") is True, "native evidence is not complete on final source")
    require(len(closed.get("targets", [])) == len(scopes), "native target manifest is incomplete")
    total = 0
    identities = []
    targets = []
    for index, (scope, recorded) in enumerate(zip(scopes, closed["targets"])):
        label = f'broad-{index:02d}-{scope["package"]}-{scope["name"] or "lib"}'
        if scope["package"] == "scriptw-engine" and scope["kind"] == "--lib":
            target = engine_native(evidence, recorded, scope)
            total += target["passed"]
            identities.extend(f'scriptw-engine:--lib:lib:{name}' for name in recorded["inventory"])
            targets.append(target)
            continue
        result, log = evidence.receipt(label)
        if label == FIXTURE_TARGET:
            require(result.get("source_patch_sha256") in {STRUCTURAL_PATCH, UTF16_PATCH, EXPORTS_PATCH, FIXTURE_PATCH}, "accepted74-test rerun did not use the corrected structural assertion")
        if label == IR_TARGET:
            require(result.get("source_patch_sha256") == FIXTURE_PATCH, "accepted IR rerun did not use the corrected Script-entry fixture")
        inventory_result, inventory_log = evidence.receipt(label + "-inventory")
        base = ["cargo", "test", "--locked", "--release", "--jobs", "1", "-p", scope["package"], scope["kind"]]
        if scope["name"] is not None:
            base.append(scope["name"])
        require(result["command"] == base + ["--", "--test-threads=1", "--include-ignored"], f"{label}: broad invocation contains filters or differs from the selected target")
        require(inventory_result["command"] == base + ["--", "--list", "--include-ignored"], f"{label}: inventory invocation differs")
        inventory = sorted(re.findall(r"^([^\s]+): test$", inventory_log, re.M))
        require(len(set(inventory)) == len(inventory), f"{label}: duplicate inventory identities")
        observed = [(name.removesuffix(" - should panic"), status) for name, status in re.findall(r"^test (.+) \.\.\. (ok|FAILED|ignored)$", log, re.M)]
        require(sorted(name for name, _ in observed) == inventory and all(status == "ok" for _, status in observed), f"{label}: native log does not pass every exact inventory identity")
        summaries = SUMMARY_RE.findall(log)
        require(len(summaries) == 1, f"{label}: expected exactly one closed target summary")
        outcome, passed, failed, ignored, measured, filtered = summaries[0]
        require(outcome == "ok" and int(passed) == len(inventory) and (failed, ignored, measured, filtered) == ("0", "0", "0", "0"), f"{label}: failed, ignored, measured or filtered inventory gaps")
        require(result.get("test_results") == [list(summaries[0])], f"{label}: recorded terminal summary differs from actual log")
        inventory_hash = hashlib.sha256(("\n".join(inventory) + "\n").encode()).hexdigest()
        expected_record = dict(result, **scope, inventory=inventory, inventory_sha256=inventory_hash)
        require(recorded == expected_record, f"{label}: native-closed target does not exactly reconcile with its receipt/inventory")
        if inventory_result.get("executables") != result.get("executables"):
            if label == FIXTURE_TARGET:
                require(inventory_result.get("source_patch_sha256") == EMPTY_PATCH and result.get("source_patch_sha256") in {STRUCTURAL_PATCH, UTF16_PATCH, EXPORTS_PATCH, FIXTURE_PATCH} and len(inventory) == 74, "structural fixture-corrected binary/inventory differs")
            elif label == IR_TARGET:
                require(inventory_result.get("source_patch_sha256") == EXPORTS_PATCH and result.get("source_patch_sha256") == FIXTURE_PATCH and len(inventory) == 1626, "IR fixture-corrected binary/inventory differs")
            else:
                require(False, f"{label}: inventoried and executed binary identities differ outside the exact fixture corrections")
        total += len(inventory)
        qualified = [f'{scope["package"]}:{scope["kind"]}:{scope["name"] or "lib"}:{name}' for name in inventory]
        identities.extend(qualified)
        targets.append({**scope, "passed": len(inventory), "inventory_sha256": inventory_hash, "run_receipt": label + ".json", "inventory_receipt": label + "-inventory.json", "source_patch_sha256": result["source_patch_sha256"], "executables": result.get("executables", []), "inventory_executables": inventory_result.get("executables", [])})
    require(total == closed.get("total"), "native aggregate total disagrees with exact inventories")
    require(len(set(identities)) == len(identities), "native inventory target identities overlap unexpectedly")
    for package in sorted({scope["package"] for scope in scopes}):
        choices = [f"frozen-build-final-{package}", f"frozen-build-{package}"]
        label = next((label for label in choices if (BASE / (label + ".json")).is_file() and read_json(BASE / (label + ".json")).get("source_head") == SOURCE), None)
        require(label is not None, f"missing final native build receipt: {package}")
        receipt, _ = evidence.receipt(label)
        require("--no-run" in receipt["command"] and receipt["command"][:2] == ["cargo", "test"] and "--jobs" in receipt["command"] and receipt["command"][receipt["command"].index("--jobs") + 1] == "1", f"{label}: invalid serial native build")
    evidence.add(BASE / "native-closed.json")
    evidence.add(BASE / "native-scopes.json")
    focus_count = 0
    focus_receipts = []
    for path in sorted(BASE.glob("focus-*.json")):
        preliminary = read_json(path)
        log = BASE / preliminary["log"]
        require(preliminary.get("exit_code") == 0 and digest(log) == preliminary.get("log_sha256"), "preliminary focused log is invalid")
        summaries = SUMMARY_RE.findall(log.read_text(errors="replace"))
        require(summaries and all(row[0] == "ok" and row[2:5] == ("0", "0", "0") for row in summaries), "preliminary focused counts contain failures/ignores")
        focus_count += sum(int(row[1]) for row in summaries)
        focus_receipts.append(path.name)
        evidence.add(path)
        evidence.add(log)
    require(focus_count == 45, "preliminary overlapping focus count does not reconcile to45")
    return {"complete": True, "target_count": 23, "passed": total, "failed": 0, "ignored": 0, "filtered": 0, "inventory_sha256": hashlib.sha256(("\n".join(sorted(identities)) + "\n").encode()).hexdigest(), "targets": targets, "preliminary_focus": {"passed": focus_count, "included_in_broad_targets": True, "added_to_total": False, "accepted_final_source_evidence": False, "receipts": focus_receipts, "scope": "preliminary debugging checks; not final-source acceptance evidence"}}


def product_examples(evidence, config):
    release, _ = evidence.receipt(config["release_label"])
    require(release["command"][:2] == ["cargo", "build"] and "--release" in release["command"] and "--locked" in release["command"] and "--examples" in release["command"], "final release receipt does not build the product and examples")
    require("--jobs" in release["command"] and release["command"][release["command"].index("--jobs") + 1] == "1", "release build must be serial")
    examples = []
    require(len(config["example_labels"]) == 2, "both product examples require final receipts")
    for label in config["example_labels"]:
        receipt, log = evidence.receipt(label)
        name = Path(receipt["command"][0]).name
        require(name in {"foreign_modules", "retained_embedding"}, f"{label}: not an expected product example")
        require(len(receipt.get("executables", [])) == 1, f"{label}: example binary identity missing")
        executable = receipt["executables"][0]
        require(Path(executable["path"]).name == name and re.fullmatch(r"[0-9a-f]{64}", executable["sha256"]) is not None, f"{label}: example hash is invalid")
        require((name == "foreign_modules" and log.strip() == "42") or (name == "retained_embedding" and "UTF-16 preserved; retained async request returned [42, 127, 128, 255]" in log), f"{label}: example did not report its checked output")
        examples.append({"name": name, "receipt": label + ".json", "binary": executable, "output": log.strip()})
    require({item["name"] for item in examples} == {"foreign_modules", "retained_embedding"}, "product example coverage is incomplete")
    return {"release_receipt": config["release_label"] + ".json", "examples": examples}



def pinned_fixtures(summary, controls):
    """Bind observed fixture SHA-256s to blobs in the exact pinned Git tree."""
    pins_path = REPO / "crates/scriptw-test262/src/source-pins.json"
    pins = read_json(pins_path)
    tree = subprocess.check_output(["git", "rev-parse", SOURCE + ":test262/vendor/test262"], cwd=REPO, text=True).strip()
    require(tree == pins["test262_tree"], "source commit does not contain the pinned Test262 tree")
    paths = {execution.split(":", 1)[1] for execution in controls}
    require(set(summary.get("fixture_sha256", {})) == paths, "fixture digest inventory does not cover exactly the requested paths")
    tree_entries = subprocess.check_output(["git", "ls-tree", "-r", "-z", SOURCE + ":test262/vendor/test262/test"], cwd=REPO)
    blobs = {}
    for entry in tree_entries.split(b"\0"):
        if not entry: continue
        header, name = entry.split(b"\t", 1)
        name = name.decode()
        if name in paths:
            _, kind, oid = header.split()
            require(kind == b"blob", "requested fixture is not a pinned Git blob")
            blobs[name] = oid.decode()
    require(set(blobs) == paths, "requested fixture is missing from the pinned tree")
    ordered = sorted(blobs)
    process = subprocess.run(["git", "cat-file", "--batch"], input=("\n".join(blobs[name] for name in ordered) + "\n").encode(), stdout=subprocess.PIPE, stderr=subprocess.PIPE, cwd=REPO, check=True)
    content, offset = process.stdout, 0
    for name in ordered:
        end = content.index(b"\n", offset)
        oid, kind, length = content[offset:end].split()
        require(oid.decode() == blobs[name] and kind == b"blob", "Git returned another fixture object")
        start, size = end + 1, int(length)
        data = content[start:start + size]
        require(len(data) == size and content[start + size:start + size + 1] == b"\n", "pinned fixture batch is truncated")
        require(hashlib.sha256(data).hexdigest() == summary["fixture_sha256"][name], f"observed fixture differs from pinned Git bytes: {name}")
        offset = start + size + 1
    require(offset == len(content), "unexpected trailing Git fixture data")
    return {"source_tree": tree, "fixture_count": len(paths), "fixture_hashes": summary["fixture_sha256"]}


def conformance(evidence, config):
    sys.path.insert(0, str(REPO / "scripts"))
    import test262_execution_batches as batches
    summary_path = Path(config["conformance_summary"])
    if not summary_path.is_absolute():
        summary_path = BASE / summary_path
    require(summary_path.resolve().is_relative_to(BASE), "replay evidence must live in this batch directory")
    replay = summary_path.parent.resolve()
    summary = read_json(summary_path)
    receipt, _ = evidence.receipt(config["conformance_label"], exit_code=1)
    controls_path = BASE / "module-function-controls.ids"
    controls = [line.strip() for line in controls_path.read_text().splitlines() if line.strip() and not line.startswith("#")]
    require(len(controls) == len(set(controls)) == 984, "control denominator is not exactly984 unique identities")
    require(summary.get("total") == 984 and summary.get("replay_mode") == "native-execution-list-v1", "conformance replay is incomplete or uses another protocol")
    fixtures = pinned_fixtures(summary, controls)
    identity = summary.get("compiler_identity", {})
    require(identity.get("source_revision") == {"kind": "git-commit", "commit": SOURCE}, "actual final CLI snapshot was built from another source")
    require(identity.get("source_fingerprint_scheme") == "scriptw-program-cache-compiler-v3" and re.fullmatch(r"[0-9a-f]{64}", identity.get("source_fingerprint", "")) is not None, "actual compiler source fingerprint is missing or invalid")
    require(identity.get("executable_sha256") == summary.get("binary_sha256") and re.fullmatch(r"[0-9a-f]{64}", summary["binary_sha256"]) is not None, "CLI executable hashes do not reconcile")
    binary = Path(summary["binary"])
    require(binary.resolve().is_relative_to(replay) and binary.is_file() and digest(binary) == summary["binary_sha256"], "frozen replay compiler hash differs")
    frozen = replay / "executions"
    require(frozen.read_bytes() == controls_path.read_bytes() and digest(frozen) == summary.get("execution_list_sha256"), "exact984 requested identities changed")
    require(set(summary.get("batch_executions", [])) == set(controls) and len(summary["batch_executions"]) == 984 and summary.get("absent_executions") == [] and summary.get("batch_threads") == 1, "native execution inventory has missing, duplicate or parallel cases")
    require(summary.get("outcomes") == {"Success": 980, "Bug": 4, "Crash": 0, "NotImplemented": 0}, "selected outcomes are not980 successes and the four known bugs")
    results = summary.get("results", [])
    require(len(results) == 984 and {row["execution_id"] for row in results} == set(controls), "actual replay results do not exactly cover the denominator")
    require({row["execution_id"] for row in results if row.get("outcome") == "Bug"} == KNOWN, "selected failures differ from the four known controls")
    options = types.SimpleNamespace(output_dir=replay)
    snapshots = {}
    invocations = {}
    for result in results:
        require(result.get("protocol") == "native-execution-list-v1" and "infrastructure_error" not in result, "result lacks actual native snapshot evidence")
        batches.verify_saved_result(result, summary, options, snapshots)
        require(result.get("exit_code") == (0 if result["outcome"] == "Success" else 1), "case outcome and actual exit disagree")
        case_path = replay / (hashlib.sha256(result["execution_id"].encode()).hexdigest() + ".json")
        require(read_json(case_path) == result, "saved per-execution result differs from summary")
        evidence.add(case_path)
        for name in [result["transcript"], result["native_snapshot"]["path"], result["invocation"]]:
            require(Path(name).name == name, "replay file path escaped its directory")
            evidence.add(replay / name)
        invocation_path = replay / result["invocation"]
        if invocation_path not in invocations:
            invocation = read_json(invocation_path)
            require(invocation.get("exit_code") == 1, "native suite exit1 was not retained")
            command = invocation.get("command", [])
            require("run-list" in command and "--threads" in command and command[command.index("--threads") + 1] == "1" and "--timeout-ms" in command and command[command.index("--timeout-ms") + 1] == "60000", "native batch command lost its serial worker/deadline policy")
            for stream in ["stdout", "stderr"]:
                stream_path = batches.owned_file(options, invocation[stream])
                require(digest(stream_path) == invocation[stream + "_sha256"], "native invocation stream hash differs")
                evidence.add(stream_path)
            invocations[invocation_path] = invocation
    baseline_path = REPO / "docs/rust-rewrite/foreign-modules-20261024.json"
    baseline = read_json(baseline_path)["conformance"]["native_snapshot"]
    failure_signature = lambda rows: sorted((row["test_id"], row["kind"], row["outcome"], row["detail_hash"]) for row in rows)
    baseline_failures = failure_signature(baseline["failures"])
    require({row[0] for row in baseline_failures} == KNOWN, "historical known-failure authority changed")
    for path, (_, verdicts) in snapshots.items():
        snapshot = read_json(path)
        require(failure_signature(snapshot["failures"]) == baseline_failures, "selected known bugs changed failure kind or diagnostic signature")
        require(snapshot.get("timeout_test_ids") == [], "selected replay contains timeouts")
        pins = read_json(REPO / "crates/scriptw-test262/src/source-pins.json")
        require(snapshot.get("pinned_revisions") == {"ecma262": pins["ecma262"], "test262": pins["test262_tree"]}, "native replay uses another pinned spec/suite tree")
        require({key for key, outcome in verdicts.items() if outcome == "Bug"} == KNOWN, "native failure identities differ from known controls")
        batches.snapshot_verdicts(snapshot, controls, identity, exit_code=1)
    inventory = summary["native_inventory"]
    inventory_path = batches.owned_file(options, inventory["stdout"])
    require(digest(inventory_path) == inventory["stdout_sha256"], "native inventory hash differs")
    require(set(controls).issubset(batches.native_inventory(inventory_path.read_text())), "requested controls are absent from native suite inventory")
    evidence.add(inventory_path)
    for name in ["summary.json", "run.json", "executions", "batch-executions"]:
        evidence.add(replay / name)
    require(digest(replay / "batch-executions") == summary["batch_execution_list_sha256"], "native batch identities changed")
    require(read_json(replay / "run.json").get("compiler_identity") == identity, "replay manifest compiler differs")
    evidence.add(controls_path)
    return {"complete": True, "scope": "selected module-code and Function apply/bind/call controls plus four known failures", "total": 984, "passed": 980, "known_bugs": sorted(KNOWN), "crash": 0, "not_implemented": 0, "timeout": 0, "actual_command_exit": 1, "known_failure_reference": {"path": str(baseline_path.relative_to(REPO)), "sha256": digest(baseline_path), "signatures": baseline_failures}, "compiler_identity": identity, "binary_sha256": summary["binary_sha256"], "execution_list_sha256": summary["execution_list_sha256"], "execution_ids": sorted(controls), "pinned_fixtures": fixtures, "receipt": config["conformance_label"] + ".json", "native_snapshots": [{"path": str(path.relative_to(BASE)), "sha256": digest(path)} for path in sorted(snapshots)], "invocations": list(invocations.values()), "counts_are_a_selected_checkpoint": True, "full_test262_chart_refreshed": False, "performance_remeasured": False}


def archive(evidence, output):
    rows = [{"path": name, "bytes": path.stat().st_size, "sha256": digest(path)} for name, path in sorted(evidence.paths.items())]
    manifest = {"schema": "scriptw-embedding-bridge-archive-v1", "source_commit": SOURCE, "members": rows, "excluded": "Compiler/test/example binaries, caches and temporary files are excluded. Binary hashes are retained in command receipts and the native snapshot. Git commit reproduces the exact product source."}
    manifest_bytes = (json.dumps(manifest, indent=2) + "\n").encode()
    temporary = output.with_suffix(output.suffix + ".pending")
    with temporary.open("wb") as raw, gzip.GzipFile(fileobj=raw, mode="wb", filename="", mtime=0, compresslevel=6) as compressed, tarfile.open(fileobj=compressed, mode="w") as bundle:
        for row in rows:
            path = evidence.paths[row["path"]]
            require(path.stat().st_size == row["bytes"] and digest(path) == row["sha256"], f"evidence changed during publication: {path}")
            info = tarfile.TarInfo(row["path"])
            info.size, info.mode = row["bytes"], 0o644
            with path.open("rb") as stream:
                bundle.addfile(info, stream)
        info = tarfile.TarInfo(PREFIX + "archive-members.json")
        info.size, info.mode = len(manifest_bytes), 0o644
        bundle.addfile(info, io.BytesIO(manifest_bytes))
    expected = {row["path"]: row for row in rows}
    seen = set()
    with tarfile.open(temporary, "r:gz") as bundle:
        for member in bundle:
            require(member.isfile() and member.name not in seen, "archive contains a nonfile or duplicate")
            seen.add(member.name)
            stream = bundle.extractfile(member)
            if member.name == PREFIX + "archive-members.json":
                require(stream.read() == manifest_bytes, "archive manifest changed")
            else:
                row = expected[member.name]
                require(member.size == row["bytes"] and hashlib.file_digest(stream, "sha256").hexdigest() == row["sha256"], "archive round-trip hash mismatch")
    require(seen == set(expected) | {PREFIX + "archive-members.json"}, "archive inventory is incomplete")
    temporary.replace(output)
    return {"file": output.name, "sha256": digest(output), "bytes": output.stat().st_size, "member_count": len(seen), "manifest_sha256": hashlib.sha256(manifest_bytes).hexdigest(), "expanded_bytes": sum(row["bytes"] for row in rows) + len(manifest_bytes)}


def markdown(report):
    target_rows = "\n".join(f'| `{row["package"]}` {row["name"] or "library"} | {row["passed"]:,} |' for row in report["native"]["targets"])
    return f'''# Retained embedding verification, 2026-10-25

Product source [`{SOURCE[:9]}`](https://github.com/mewhhaha/scriptw/commit/{SOURCE}), with the archived test-fixture correction below, passed **{report["native"]["passed"]:,} native checks across 23 complete targets**. Every accepted final inventory ran in full, with no failures, ignores or filtered cases. The preliminary 45 focused checks overlap these targets and are not added to the total.

The first `modules_realms` attempt passed 73 of 74 tests: one structural guard still expected the former `ProgramExports.append` argument list. Its assertion was corrected to include `runtime_helper_base`, after which the same complete 74-test inventory passed. A retained-export fixture was also corrected: module export names must be well-formed Unicode, so its export name now uses an astral pair while a separate object-property assertion checks a lone-surrogate key. The API doc comment was corrected accordingly. A third fixture updated the exact expected Wasm export list to include the intended private embedding bridges after its original 32-test batch passed 31 and failed that one stale assertion. The IR namespace fixture then passed 1,625 of 1,626 checks before its unobserved-entry assertion was corrected to use a Script entry; Module entries now have a host observer by design. The same complete 1,626-test inventory was required to pass after that cfg(test)-only correction. These four fixture changes and one documentation-only source edit leave runtime/compiler implementation unchanged from `{SOURCE[:9]}`; the verification source tree is not described as completely clean. All four patch versions and original failed evidence are archived. Final `verification-fixture.patch` SHA-256: `{FIXTURE_PATCH}`. Earlier failed/partial attempts are excluded from accepted totals.

The source-free Portable examples passed: the scalar example printed `42`; the retained example preserved NUL, lone UTF-16 surrogates and an astral pair, then called a retained default object's async method with its receiver and returned bytes `[42, 127, 128, 255]` after host settlement.

The selected pinned Test262 replay completed **984 exact execution IDs: 980 successes and the same four known runtime bugs**, with zero crashes, unsupported cases or timeouts. The actual suite exit remains **1**. This selected checkpoint leaves the full Test262 chart and historical V8 performance measurements unchanged.

The original whole-engine scope reached its 4-GiB cap and was terminated by the OOM policy; its exit137 transcript and systemd journal lines remain archived. It is not an accepted target result. The complete 1,029-test engine inventory was instead verified by a disjoint union of fresh bounded native batches, with no identities omitted or duplicated. This is explicitly an aggregate of actual process observations, not a synthetic single-process transcript.

Every accepted native/product/replay receipt establishes one CPU, the kernel-enforced 4-GiB cap and zero swap. Later receipts also observe grouped OOM termination and the one-entry/64-MiB retained module cache directly. The explicitly listed early receipts predate those fields: their group/cache provenance is the archived verified launcher policy, rather than invented kernel observations. No accepted run records an OOM event. The largest recorded cumulative cgroup peak was **{report["resources"]["maximum_cgroup_peak_bytes"]:,} bytes**; reaching the cap through reclaim is not counted as an OOM kill.

| Native target | Passed |
| --- | ---: |
{target_rows}

[Machine-readable verification]({STEM}.json) records exact commands, target inventory hashes, executable identities, the selected execution IDs and the unchanged known failures. [The evidence archive]({STEM}.tar.gz) retains inventories, actual transcripts, resource receipts, native snapshots and runner scripts. Its SHA-256 is `{report["archive"]["sha256"]}`. Executables and caches are excluded; the source commit above reproduces product code.

For reproduction, check out the source commit and apply the archived `verification-fixture.patch` for native verification. The implementation remains the source commit plus these exact fixture/documentation changes; the actual compiler source fingerprint and executable hash are retained rather than described as a clean-tree build. Build serially with `python3 -B scripts/limited_verification.py -- ...`, then use the archived `native_final.py` target inventory and replay commands. Copy `engine_batches.py`, `native_final.py` and `run_check.py` into a fresh target directory before rerunning: archived closed receipts are audit evidence, not a new execution. Run `engine_batches.py` first to create the exact engine union, then `native_final.py` for the complete target batch. The archive publisher validates every accepted target against its complete `--list --include-ignored` inventory before publishing; failed, stale and partial artifacts cannot produce a complete checkpoint. Run the examples with `cargo run --locked --release --jobs 1 -p scriptw-engine --example retained_embedding` and `--example foreign_modules` inside the same resource wrapper.
'''


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--inputs", type=Path, default=BASE / "publication-inputs.json")
    parser.add_argument("--publish", action="store_true", help="write docs only after all closed evidence passes validation")
    args = parser.parse_args()
    os.sched_setaffinity(0, {min(os.sched_getaffinity(0))})
    config = read_json(args.inputs)
    required = {"source_commit", "release_label", "example_labels", "conformance_summary", "conformance_label", "resource_boundaries"}
    require(set(config) == required, "publication inputs have missing/unknown fields")
    require(config["source_commit"] == SOURCE, "publication input source differs from the frozen final source")
    require(subprocess.check_output(["git", "rev-parse", SOURCE + "^{commit}"], cwd=REPO, text=True).strip() == SOURCE, "final source commit is unavailable")
    evidence = Evidence()
    fixture = verification_fixture(evidence)
    native_report = native(evidence)
    products = product_examples(evidence, config)
    conformance_report = conformance(evidence, config)
    for boundary_path in config["resource_boundaries"]:
        path = Path(boundary_path)
        if not path.is_absolute(): path = BASE / path
        boundary = read_json(path)
        require(boundary.get("source_head") == SOURCE, "resource boundary is not bound to final source")
        evidence.resource(boundary, str(path.name), boundary=True)
        evidence.add(path)
    for name in ["publish_evidence.py", "run_check.py", "native_final.py", "engine_batches.py", "focused.py"]:
        evidence.add(BASE / name)
    for name in ["limited_verification.py", "resource_numbers.py", "replay-test262-executions.py", "test262_execution_batches.py"]:
        evidence.add(REPO / "scripts" / name)
    evidence.add(args.inputs)
    report = {"schema": "scriptw-embedding-bridge-checkpoint-v1", "refresh_date": "2026-10-25", "complete": True, "source_commit": SOURCE, "verification_fixture_patch": fixture, "foreign_abi_version": 2, "native": native_report, "products": products, "test262": conformance_report, "resources": {"memory_limit_bytes": BUDGET, "swap_limit_bytes": 0, "cpus": 1, "grouped_oom": True, "payload_cache_environment": CACHE, "accepted_oom_events": 0, "maximum_cgroup_peak_bytes": max(row["memory_peak"] for row in evidence.resources), "boundary_receipts": config["resource_boundaries"], "field_provenance": evidence.resources, "legacy_launcher_policy": {"source_commit": SOURCE, "path": "scripts/limited_verification.py", "sha256": LAUNCHER_SHA256, "invocation_prefix": ["python3", "-B", "scripts/limited_verification.py", "--"], "provenance": "launcher validates memory.oom.group==1 and establishes cache/serial defaults before invoking its payload; early command receipts did not capture these fields directly", "applies_to": [row["label"] for row in evidence.resources if row["group_and_cache_provenance"].startswith("archived")]}}}
    if not args.publish:
        print(json.dumps({"validated": True, "source_commit": SOURCE, "native_passed": native_report["passed"], "targets": 23, "selected_test262": conformance_report["total"], "archive_members": len(evidence.paths) + 1, "publication": "not requested"}, indent=2))
        return
    directory = REPO / "docs/rust-rewrite"
    outputs = [directory / (STEM + suffix) for suffix in [".md", ".json", ".tar.gz"]]
    require(not any(path.exists() for path in outputs), "refusing to replace existing published evidence")
    report["archive"] = archive(evidence, outputs[2])
    outputs[1].write_text(json.dumps(report, indent=2) + "\n")
    outputs[0].write_text(markdown(report))
    print(json.dumps({"published": [str(path.relative_to(REPO)) for path in outputs], "native_passed": native_report["passed"], "archive": report["archive"]}, indent=2))


if __name__ == "__main__":
    try:
        main()
    except (KeyError, ValueError, OSError, TypeError) as error:
        print(f"Evidence publication refused: {error}", file=sys.stderr)
        raise SystemExit(1)
