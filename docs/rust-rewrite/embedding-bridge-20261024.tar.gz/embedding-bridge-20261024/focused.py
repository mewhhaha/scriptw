import pathlib, subprocess, sys
root=pathlib.Path(__file__).resolve().parent
base=pathlib.Path('/tmp/scriptw-v8-target-20261024/release/deps')
checks=[
 ('focus-ir-foreign','scriptw_ir-e871dd08c19eaf7d','foreign::tests::'),
 ('focus-ir-namespace','scriptw_ir-e871dd08c19eaf7d','host_observes_only_the_actual_module_entry_namespace'),
 ('focus-aot-foreign','scriptw_aot_wasm-804c3bd6c21a96dc','foreign::tests::'),
 ('focus-emission-foreign','emission-85659e0b5fbdc61a','foreign_functions::'),
 ('focus-emission-embedding','emission-85659e0b5fbdc61a','embedding::'),
 ('focus-engine-embedding','scriptw_engine-ea29bf18172d69bc','embedding::'),
 ('focus-engine-loader','scriptw_engine-ea29bf18172d69bc','module_loader::foreign_tests::'),
 ('focus-engine-capabilities','scriptw_engine-ea29bf18172d69bc','tests::foreign_capabilities::'),
]
for label,binary,pattern in checks:
 code=subprocess.call([sys.executable,'-B',str(root/'run_check.py'),label,str(base/binary),pattern,'--test-threads=1'])
 if code: sys.exit(code)
