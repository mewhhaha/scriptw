import importlib.util,json,statistics
from pathlib import Path
p=Path(__file__).with_name('cohort.py');spec=importlib.util.spec_from_file_location('cohort',p);c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
report=dict(schema='scriptw-scriptc-local-current-host-v1',complete=False,source='Candidate source and frozen host identity retained in candidate/identity.json',samples=21,warmups=10,resources_before=c.resources(),attempts=[],scope='Same compiler-disabled host/settings, original sources/checksums. Native images freshly prepared locally; Scriptc raw Wasm is pinned archived producer output. Separate local cohort; no before/after or V8-memory parity claim.')
c.save(c.OUT/'scriptc-comparison.json',report)
for r in range(2):
 cases=c.PLAN['execution'] if r==0 else list(reversed(c.PLAN['execution']))
 for i,case in enumerate(cases):
  runtimes=['scriptw','scriptc'] if (r+i)%2==0 else ['scriptc','scriptw']
  for runtime in runtimes:
   name=case['file'];stem=f'scriptc-comparison-r{r}-{runtime}-{name}'
   image=(c.OUT/'candidate-original'/(name+'.swpc') if runtime=='scriptw' else c.OUT/'scriptc-native'/(name+'.cwasm'))
   value=c.invoke(stem,[c.host('candidate'),'execute-scriptw' if runtime=='scriptw' else 'execute-wasi',image,case['stdout'],'21','10'])
   assert value['compiler_enabled'] is False and value['samples']==21 and value['warmups']==10
   assert value['executable_sha256']==json.loads((c.OUT/'candidate/products.json').read_text())['compiler_precompiled_baseline']['sha256']
   assert value['image_sha256']==c.digest(image)
   observations=value['observations'];assert len(observations)==31 and all(v['stdout']==case['stdout'] for v in observations)
   report['attempts'].append(dict(round=r,runtime=runtime,file=name,raw=stem+'.stdout',image_sha256=c.digest(image)))
   c.save(c.OUT/'scriptc-comparison.json',report)
rows=[]
for case in c.PLAN['execution']:
 products={}
 for runtime in ('scriptw','scriptc'):
  times=[];rss=[];pss=[];dirty=[]
  for a in report['attempts']:
   if a['runtime']!=runtime or a['file']!=case['file']:continue
   v=json.loads((c.OUT/a['raw']).read_text())
   for o in v['observations']:
    if o['warmup']:continue
    times.append(o['phases_ns']['execution']);m=o['process_snapshots']['after_execution']
    rss.append(m['rss_bytes']);pss.append(m['pss_bytes']);dirty.append(m['private_dirty_bytes'])
  assert len(times)==42
  products[runtime]=dict(median_ns=statistics.median(times),rss_bytes=statistics.median(rss),pss_bytes=statistics.median(pss),private_dirty_bytes=statistics.median(dirty))
 rows.append(dict(file=case['file'],products=products,time_ratio=products['scriptw']['median_ns']/products['scriptc']['median_ns'],rss_ratio=products['scriptw']['rss_bytes']/products['scriptc']['rss_bytes']))
report.update(complete=True,resources_after=c.resources(),workloads=rows)
c.save(c.OUT/'scriptc-comparison.json',report)
for r in rows:print(r['file'],'time',round(r['time_ratio'],3),'RSS',round(r['rss_ratio'],3),flush=True)
