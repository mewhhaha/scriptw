from pathlib import Path
import importlib.util,json,statistics
p=Path(__file__).with_name('cohort.py');spec=importlib.util.spec_from_file_location('cohort',p);c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
wanted={'sort-reverse-512.js','join-4096.js'}
c.PLAN=dict(c.PLAN);c.PLAN['execution']=[v for v in c.PLAN['execution'] if v['file'] in wanted]
assert {v['file'] for v in c.PLAN['execution']}==wanted
prefix='controls-extra';order=['baseline','candidate','candidate','baseline','candidate','baseline','baseline','candidate']
c.measure(prefix,order)
path=c.OUT/(prefix+'-analysis.json');report=json.loads(path.read_text())
for row in report['workloads']:
 for boundary in ('original','retained','ordinary'):
  for label,product in row[boundary]['products'].items():
   values=[];rss=[]
   for entry in product['rounds']:
    raw=json.loads((c.OUT/entry['raw']).read_text())
    observations=raw['cases'][0]['observations'] if boundary=='ordinary' else raw['observations']
    sample=[o for o in observations if not o['warmup']];assert len(sample)==21
    times=[o['execution_ns'] if boundary=='ordinary' else o['call_ns'] if boundary=='retained' else o['phases_ns']['execution'] for o in sample]
    entry['mean_ns']=statistics.mean(times);values.extend(times)
    if boundary=='original':rss.extend(o['process_snapshots']['after_execution']['rss_bytes'] for o in sample)
   assert len(values)==84 and statistics.median(values)==product['median_ns']
   product['mean_ns']=statistics.mean(values);product['samples']=len(values)
   if rss:assert statistics.median(rss)==product['rss_bytes']
  base=row[boundary]['products']['baseline'];candidate=row[boundary]['products']['candidate']
  row[boundary]['mean_change_percent']=100*(candidate['mean_ns']/base['mean_ns']-1)
report.update(complete=True,scope='Two additional unchanged targeted controls;8 balanced ABBA+BAAB rounds;21 measured/10 checkedwarmups perchild; all boundaries and slow/outlier observations retained. Separate from full17 groups.')
c.save(path,report)
for row in report['workloads']:
 print(row['file'],{b:{'median':round(row[b]['change_percent'],3),'mean':round(row[b]['mean_change_percent'],3)} for b in ('original','retained','ordinary')},flush=True)
