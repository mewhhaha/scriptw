Scratch scaling/admission controls for whole-trip affine composition. These
sources and driver are prepared for parent review; no JavaScript, Node, native
product, build or benchmark was executed while drafting them. Expected values
come only from sequential Python modular arithmetic and remain independently
Node/native-unverified. The generator does not use binary affine composition.

`sources/manifest.json` uses the existing `scriptw-v8-workloads-v1` shape. Its five
execution entries are ordinary strict `run(state)` functions called with seed 7,
returning live final state/counter for two print calls. The first four have a
positive literal `var counter=3`, strict literal upper bound and unit increment.
The fifth uses private `var stop=10003` and `counter<stop`, which must reject the
new literal whole-trip shape while retaining eligibility for old chunks.

| Source | Map | Bodies | Expected stdout (state, counter) | Independent verification |
| --- | --- | ---: | --- | --- |
| unsigned-19.js | unsigned 3*x+1 | 19 | 127026410, 22 | Node/native pending |
| unsigned-10000.js | unsigned 3*x+1 | 10000 | 303929447, 10003 | Node/native pending |
| unsigned-1000000.js | unsigned 3*x+1 | 1000000 | 3203159431, 1000003 | Node/native pending |
| signed-1000000.js | signed 5*x-7 | 1000000 | -667223865, 1000003 | Node/native pending |
| dynamic-limit-10000.js | unsigned 3*x+1 | 10000 | 303929447, 10003 | Node/native pending |

The existing startup source is copied byte-for-byte with stdout
`scriptw-startup-ok\n`; its independent verification is also marked pending.
`source-hashes.json` binds the exact sources/manifest, and
`expected-reference.json` retains each recurrence, seed, trip count, result and
pending status. External verification receipts do not rewrite the source manifest.

`cohort.py` follows the existing `cohort.py` / `benchmark_metrics.measure_process`
pattern. Baseline is the accepted FIRST product under
`target/performance-memory-parity-20261031/candidate`, source fingerprint
`6764a3510a89a7830e6277cd91df09c9fc2769da901bcf578d87e9289d7050c5`.
Candidate is the future frozen AFFINE product under this experiment's `candidate/`.
It must be explicitly bound by its exact fingerprint after the parent's native
jobs and semantic checks finish. `product-plan.json` records this pending boundary;
the executable digests currently copied there are metadata facts, not fresh
large-binary verification performed by this draft.

The driver reads these frozen products in place. It never copies, symlinks or
hardlinks executables, and rejects linked product/image paths. Binding verifies
actual product bytes against frozen metadata and matching runtime configuration,
then records the exact source/harness/product lock. Both labels compile fresh
original `.swpc` images from these own sources plus startup, retaining producer
receipts, raw Wasm and source/image identities. No archived native image or
retained-call adapter enters this cohort.

After review and semantic acceptance, use the repository's bounded serial wrapper
for each command. Replace the fingerprint placeholder with the parent's actual
AFFINE identity; the draft deliberately supplies no candidate identity.

```sh
python3 -B scripts/limited_verification.py --cloud -- python3 -B target/performance-whole-trip-affine-20261031/scaling-controls/cohort.py bind --candidate-fingerprint <AFFINE_64_HEX_FINGERPRINT>
python3 -B scripts/limited_verification.py --cloud -- python3 -B target/performance-whole-trip-affine-20261031/scaling-controls/cohort.py prepare baseline
python3 -B scripts/limited_verification.py --cloud -- python3 -B target/performance-whole-trip-affine-20261031/scaling-controls/cohort.py prepare candidate
python3 -B scripts/limited_verification.py --cloud -- python3 -B target/performance-whole-trip-affine-20261031/scaling-controls/cohort.py measure scaling --order eight
```

Optional independent Node verification uses the existing vm.Script harness:

```sh
python3 -B scripts/limited_verification.py --cloud -- python3 -B target/performance-whole-trip-affine-20261031/scaling-controls/cohort.py verify-node reference
```

`eight` runs ABBA followed by BAAB: baseline, candidate, candidate, baseline,
candidate, baseline, baseline, candidate. Separate `--order ABBA` and
`--order BAAB` invocations with fresh prefixes are also supported. Each case and
startup run only original compiler-free `execute-scriptw` and ordinary
`runtime_baseline`, with 21 measured fresh invocations and 10 checked warmups.
No explicit native policy, phase trace or extra Engine feature is requested.
Source order reverses on alternating rounds. Node is optional and separate
from the native timing runs.

Every command retains argv, executable identity, stdout/stderr, process accounting
and bounded cgroup/affinity/cache policy observations. Analysis checks exact
labels, schemas, source/product/image hashes, sample counts, warmup flags and
outputs; ordinary policy must remain default and original consumers must have
their compiler disabled. Per-round, per-four-round-group and pooled timing
medians/means retain raw samples. Original post-execution RSS has its own raw
samples, per-round/group/pooled medians/means and change ratios. Full child
observations and phase/RSS endpoints remain in the raw receipts.

The driver creates receipts exclusively, preserving failed/incomplete attempts.
Use a new prefix rather than overwriting evidence. Standalone `analyze PREFIX
--order ORDER` is available only when that prefix has no analysis yet. Timing
runs must be serial after other native jobs stop. These smaller/larger controls
measure scaling and admission; they cannot replace the unchanged original-source
acceptance gate or refresh published benchmark/conformance identities.
