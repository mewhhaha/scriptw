#!/usr/bin/env python3
"""Write scratch sources and integer-only expected results; execute no JS/native code."""
from pathlib import Path
import hashlib
import json

ROOT = Path('/workspace/scriptw')
OUT = Path(__file__).resolve().parent
SOURCES = OUT / 'sources'
SOURCES.mkdir(exist_ok=True)
MASK = (1 << 32) - 1


def reference(multiplier, addend, trips, signed):
    # Sequential modular steps, independent of compiler affine composition.
    state = 7
    for _ in range(trips):
        state = (multiplier * state + addend) & MASK
    if signed and state >= (1 << 31):
        state -= 1 << 32
    return state


specifications = [
    ('unsigned-19.js', 3, 1, 19, False, False),
    ('unsigned-10000.js', 3, 1, 10000, False, False),
    ('unsigned-1000000.js', 3, 1, 1000000, False, False),
    ('signed-1000000.js', 5, -7, 1000000, True, False),
    ('dynamic-limit-10000.js', 3, 1, 10000, False, True),
]
cases = []
references = []
for name, multiplier, addend, trips, signed, dynamic in specifications:
    limit = 3 + trips
    stop = 'stop' if dynamic else str(limit)
    setup = f'  var stop={limit};\n' if dynamic else ''
    body = '(Math.imul(state,5)-7)|0' if signed else '(Math.imul(state,3)+1)>>>0'
    source = f'''function run(state) {{
  "use strict";
{setup}  for(var counter=3;counter<{stop};counter++) state={body};
  return [state,counter];
}}
var result=run(7);
print(result[0]);
print(result[1]);
'''
    state = reference(multiplier, addend, trips, signed)
    stdout = f'{state}\n{limit}\n'
    (SOURCES / name).write_text(source)
    pending = dict(reference='sequential Python integer arithmetic modulo 2^32',
                   independent_node='pending', native='pending')
    cases.append(dict(file=name, stdout=stdout,
                      work=f'strict ordinary run(state), seed 7, C=3, N={trips}, '
                           f'T(x)={multiplier}*x{addend:+d}, '
                           f'{"signed" if signed else "unsigned"} residue; '
                           f'{"private dynamic limit rejects whole-trip shape" if dynamic else "literal trip boundary"}',
                      expected_verification=pending))
    references.append(dict(file=name, source_sha256=hashlib.sha256(source.encode()).hexdigest(),
                           seed=7, initial_counter=3, final_counter=limit, trips=trips,
                           multiplier=multiplier, addend=addend, signed=signed,
                           final_state=state, stdout=stdout, verification=pending))

canonical = ROOT / 'crates/scriptw-cli/tests/fixtures/v8_execution_hotpaths'
canonical_manifest = json.loads((canonical / 'manifest.json').read_text())
startup = dict(canonical_manifest['startup'])
startup['expected_verification'] = dict(reference='copied canonical startup expectation',
                                        independent_node='pending', native='pending')
startup_source = (canonical / startup['file']).read_bytes()
(SOURCES / startup['file']).write_bytes(startup_source)
manifest = dict(schema='scriptw-v8-workloads-v1', startup=startup, execution=cases)
(SOURCES / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
record = dict(schema='scriptw-affine-scaling-reference-v1',
              status='expected values derived only; independent Node and native verification pending',
              recurrence='sequential (a*state+b) & 0xffffffff; final signed conversion when requested',
              cases=references,
              startup=dict(file=startup['file'], stdout=startup['stdout'],
                           source_sha256=hashlib.sha256(startup_source).hexdigest(),
                           canonical_source=str(canonical / startup['file']),
                           verification=startup['expected_verification']))
(OUT / 'expected-reference.json').write_text(json.dumps(record, indent=2) + '\n')
source_hashes = {path.name: hashlib.sha256(path.read_bytes()).hexdigest()
                 for path in sorted(SOURCES.iterdir()) if path.is_file()}
(OUT / 'source-hashes.json').write_text(json.dumps(source_hashes, indent=2) + '\n')
print(json.dumps({row['file']: row['stdout'] for row in references}))
