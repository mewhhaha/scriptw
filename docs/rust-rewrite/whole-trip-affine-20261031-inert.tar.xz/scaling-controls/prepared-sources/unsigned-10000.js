function run(state) {
  "use strict";
  for(var counter=3;counter<10003;counter++) state=(Math.imul(state,3)+1)>>>0;
  return [state,counter];
}
var result=run(7);
print(result[0]);
print(result[1]);
