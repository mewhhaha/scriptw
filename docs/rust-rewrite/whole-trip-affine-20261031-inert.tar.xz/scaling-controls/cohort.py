#!/usr/bin/env python3
"""Bounded same-source controls; execution is opt-in after parent semantic checks."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import shutil
import statistics
import sys

ROOT = Path('/workspace/scriptw')
OUT = Path(__file__).resolve().parent
SOURCES = OUT / 'sources'
PREPARED_SOURCES = OUT / 'prepared-sources'
BASELINE = ROOT / 'target/performance-memory-parity-20261031/candidate'
CANDIDATE = OUT.parent / 'candidate'
FIRST = '6764a3510a89a7830e6277cd91df09c9fc2769da901bcf578d87e9289d7050c5'
TIME = Path('/workspace/toolchains/system/usr/bin/time')
NODE_HARNESS = ROOT / 'crates/scriptw-cli/tests/fixtures/v8_baseline/node-runtime.cjs'
SAMPLES, WARMUPS = 21, 10
ORDERS = {
    'ABBA': ['baseline', 'candidate', 'candidate', 'baseline'],
    'BAAB': ['candidate', 'baseline', 'baseline', 'candidate'],
    'eight': ['baseline', 'candidate', 'candidate', 'baseline',
              'candidate', 'baseline', 'baseline', 'candidate'],
}
sys.path.insert(0, str(ROOT / 'scripts'))
from benchmark_metrics import measure_process
from limited_verification import kernel_group, require_cloud_budget


def require(value, message):
    if not value:
        raise ValueError(message)


def load(path):
    return json.loads(Path(path).read_text())


def save(path, value):
    # Failed/incomplete receipts are never overwritten by a retry.
    with Path(path).open('x') as stream:
        stream.write(json.dumps(value, indent=2) + '\n')


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def plain_file(path):
    path = Path(path)
    require(path.is_absolute() and path.resolve() == path,
            f'canonical nonsymlink path required: {path}')
    stat = path.stat()
    require(path.is_file() and stat.st_nlink == 1,
            f'plain independently owned file required: {path}')
    return stat


def inputs():
    expected = load(OUT / 'source-hashes.json')
    require(set(expected) == {path.name for path in SOURCES.iterdir()}, 'source inventory changed')
    for name, sha in expected.items():
        plain_file(SOURCES / name)
        require(digest(SOURCES / name) == sha, f'source identity changed: {name}')
    plan = load(SOURCES / 'manifest.json')
    require(plan['schema'] == 'scriptw-v8-workloads-v1' and len(plan['execution']) == 5,
            'unexpected scaling manifest')
    canonical = ROOT / 'crates/scriptw-cli/tests/fixtures/v8_execution_hotpaths'
    startup = load(canonical / 'manifest.json')['startup']
    require(all(plan['startup'][key] == startup[key] for key in ['file', 'stdout']) and
            digest(SOURCES / startup['file']) == digest(canonical / startup['file']),
            'canonical startup control changed')
    cases = [*plan['execution'], plan['startup']]
    require(len({case['file'] for case in cases}) == 6, 'duplicate case label')
    for case in cases:
        require(Path(case['file']).name == case['file'], 'case must be a basename')
    return plan, cases, expected


def support_identities():
    return {str(path.relative_to(ROOT)): digest(path) for path in [
        Path(__file__).resolve(), ROOT / 'scripts/benchmark_metrics.py',
        ROOT / 'scripts/limited_verification.py', NODE_HARNESS,
        ROOT / 'crates/scriptw-cli/tests/fixtures/v8_execution_hotpaths/startup.js',
    ]}


def products(directory, expected_fingerprint):
    identity_path, products_path = directory / 'identity.json', directory / 'products.json'
    plain_file(identity_path); plain_file(products_path)
    identity, metadata = load(identity_path), load(products_path)
    require(identity['schema'] == 'scriptw-precompiled-shared-host-v1', 'wrong identity schema')
    require(identity['source_fingerprint'] == expected_fingerprint, 'wrong frozen product source')
    rows = {}
    for tool in ['compiler_precompiled_baseline', 'runtime_baseline']:
        path = directory / tool
        stat = plain_file(path)
        require(stat.st_size == metadata[tool]['bytes'], f'product size changed: {path}')
        require(digest(path) == metadata[tool]['sha256'], f'product bytes changed: {path}')
        rows[tool] = dict(path=str(path), sha256=metadata[tool]['sha256'], bytes=stat.st_size)
    require(identity['executable_sha256'] == rows['compiler_precompiled_baseline']['sha256'],
            'host identity/product mismatch')
    return dict(directory=str(directory), identity=identity, products=rows,
                identity_metadata_sha256=digest(identity_path),
                products_metadata_sha256=digest(products_path))


def bind(candidate_fingerprint):
    _, _, source_hashes = inputs()
    require(len(candidate_fingerprint) == 64 and
            all(char in '0123456789abcdef' for char in candidate_fingerprint) and
            candidate_fingerprint != FIRST, 'explicit future AFFINE fingerprint required')
    baseline = products(BASELINE, FIRST)
    candidate = products(CANDIDATE, candidate_fingerprint)
    require(baseline['identity']['shared_configuration'] == candidate['identity']['shared_configuration'],
            'runtime configuration differs')
    baseline['cohort'], candidate['cohort'] = 'FIRST', 'AFFINE'
    save(OUT / 'product-lock.json', dict(schema='scriptw-affine-scaling-product-lock-v1',
         source_hashes=source_hashes, support=support_identities(),
         baseline=baseline, candidate=candidate,
         authority='Current local frozen products only; fresh images from these sources; no archived native code.'))


def checked_lock():
    _, _, expected = inputs()
    lock = load(OUT / 'product-lock.json')
    require(lock['source_hashes'] == expected and lock['support'] == support_identities(),
            'bound sources or harness changed')
    for label in ['baseline', 'candidate']:
        row = lock[label]
        actual = products(Path(row['directory']), row['identity']['source_fingerprint'])
        require(actual == {key: value for key, value in row.items() if key != 'cohort'},
                f'frozen product metadata changed: {label}')
    require(lock['baseline']['cohort'] == 'FIRST' and
            lock['baseline']['identity']['source_fingerprint'] == FIRST and
            lock['candidate']['cohort'] == 'AFFINE', 'incorrect cohort labels')
    return lock


def resources():
    budget = require_cloud_budget()
    affinity = sorted(os.sched_getaffinity(0))
    require(len(affinity) == 1, 'serial measurement affinity required; use limited_verification --cloud')
    group = kernel_group()
    fields = ['memory.max', 'memory.swap.max', 'memory.oom.group', 'cpu.max',
              'memory.current', 'memory.peak', 'memory.events', 'pids.current']
    return dict(cloud_budget_bytes=budget, affinity=affinity,
                cgroup={name: (group / name).read_text().strip() for name in fields},
                environment={name: os.environ.get(name) for name in [
                    'CARGO_BUILD_JOBS', 'SCRIPTW_JOBS', 'RAYON_NUM_THREADS', 'RUST_TEST_THREADS',
                    'SCRIPTW_MODULE_MEMORY_CACHE_ENTRIES', 'SCRIPTW_MODULE_MEMORY_CACHE_LIMIT_BYTES']})


def invoke(stem, argv, executable_sha256, node=False):
    require(Path(stem).name == stem, 'invalid raw command label')
    print(stem, flush=True)
    env = dict(os.environ)
    if node:
        require(not env.get('NODE_OPTIONS'), 'NODE_OPTIONS would change the reference cohort')
        env.pop('NODE_COMPILE_CACHE', None)
        env['NODE_DISABLE_COMPILE_CACHE'] = '1'
    before = resources()
    with (OUT / (stem + '.stdout')).open('xb') as stdout, (OUT / (stem + '.stderr')).open('xb') as stderr:
        result = measure_process(list(map(str, argv)), cwd=ROOT, env=env,
                                 stdout=stdout, stderr=stderr, timeout=900, time_binary=TIME)
    after = resources()
    policy_stable = (before['cloud_budget_bytes'] == after['cloud_budget_bytes'] and
            before['affinity'] == after['affinity'] and before['environment'] == after['environment'] and
            all(before['cgroup'][key] == after['cgroup'][key] for key in
                ['memory.max', 'memory.swap.max', 'memory.oom.group', 'cpu.max']))
    result.update(argv=list(map(str, argv)), executable_sha256=executable_sha256,
                  cwd=str(ROOT), resources_before=before, resources_after=after,
                  resource_policy_unchanged=policy_stable)
    save(OUT / (stem + '.command.json'), result)
    require(policy_stable, 'resource policy changed during measured child; raw receipt retained')
    require(result['exit_code'] == 0 and not result['timed_out'], f'command failed; retained receipt: {stem}')
    return load(OUT / (stem + '.stdout'))


def prepared_sources():
    plan, cases, hashes = inputs()
    expected_plan = dict(plan, execution=cases)
    if not PREPARED_SOURCES.exists():
        PREPARED_SOURCES.mkdir()
        for case in cases:
            shutil.copyfile(SOURCES / case['file'], PREPARED_SOURCES / case['file'])
        save(PREPARED_SOURCES / 'manifest.json', expected_plan)
    require(load(PREPARED_SOURCES / 'manifest.json') == expected_plan, 'prepared manifest changed')
    for case in cases:
        plain_file(PREPARED_SOURCES / case['file'])
        require(digest(PREPARED_SOURCES / case['file']) == hashes[case['file']], 'prepared source changed')
    return cases


def check_report_identity(report, label, lock, tool, schema):
    require(report['schema'] == schema, f'wrong {tool} report schema')
    require(report['source_fingerprint'] == lock[label]['identity']['source_fingerprint'], 'source label mismatch')
    require(report['source_commit'] == lock[label]['identity']['source_commit'], 'source commit mismatch')
    require(report['executable_sha256'] == lock[label]['products'][tool]['sha256'], 'executable label mismatch')


def producer(label, lock):
    report = load(OUT / ('images-' + label) / 'producer.json')
    check_report_identity(report, label, lock, 'compiler_precompiled_baseline', 'scriptw-precompiled-producer-v1')
    require(report['compiler_enabled'] is True and report['adapter'] == 'scriptw', 'fresh compiler producer required')
    require(report['shared_configuration'] == lock[label]['identity']['shared_configuration'], 'producer policy mismatch')
    require(report['manifest_sha256'] == digest(PREPARED_SOURCES / 'manifest.json'), 'producer manifest mismatch')
    cases = prepared_sources()
    require([case['file'] for case in report['cases']] == [case['file'] for case in cases], 'producer inventory mismatch')
    hashes = lock['source_hashes']
    for expected, case in zip(cases, report['cases']):
        require(case['stdout'] == expected['stdout'] and case['source_sha256'] == hashes[case['file']], 'producer source/output mismatch')
        require(case['image'] == case['file'] + '.swpc', 'unexpected image path')
        image = OUT / ('images-' + label) / case['image']
        plain_file(image)
        require(digest(image) == case['image_sha256'], 'fresh producer image changed')
        require(case['wasm'] == case['file'] + '.wasm', 'unexpected raw Wasm path')
        wasm = OUT / ('images-' + label) / case['wasm']
        plain_file(wasm)
        require(digest(wasm) == case['program_wasm_sha256'], 'fresh producer raw Wasm changed')
        require(case['source_compilation_profile'] == 'portable' and case['intl_profile'] == 'Minimal', 'producer feature profile mismatch')
    return report


def prepare(label):
    lock = checked_lock()
    prepared_sources()
    tool = lock[label]['products']['compiler_precompiled_baseline']
    invoke(label + '-prepare-original', [tool['path'], 'prepare-scriptw', PREPARED_SOURCES,
           OUT / ('images-' + label)], tool['sha256'])
    producer(label, lock)


def observations(report, boundary, case, label, lock):
    ordinary = boundary == 'ordinary'
    tool = 'runtime_baseline' if ordinary else 'compiler_precompiled_baseline'
    check_report_identity(report, label, lock, tool,
                          'scriptw-wasmtime-baseline-v2' if ordinary else 'scriptw-precompiled-execution-v1')
    require(report['samples'] == SAMPLES and report['warmups'] == WARMUPS, 'sample policy mismatch')
    if ordinary:
        require(report['requested_native_policy'] is None and len(report['cases']) == 1, 'ordinary policy/inventory changed')
        actual = report['cases'][0]
        require(actual['file'] == case['file'] and actual['source_sha256'] == lock['source_hashes'][case['file']], 'ordinary source mismatch')
        values = actual['observations']
    else:
        require(report['compiler_enabled'] is False and report['adapter'] == 'scriptw', 'original consumer boundary changed')
        require(report['shared_configuration'] == lock[label]['identity']['shared_configuration'], 'original runtime policy mismatch')
        prepared = producer(label, lock)
        image = next(row for row in prepared['cases'] if row['file'] == case['file'])
        require(report['image_sha256'] == image['image_sha256'] and
                report['program_wasm_sha256'] == image['program_wasm_sha256'] and
                report['runtime_key'] == image['runtime_key'], 'original source/image mismatch')
        values = report['observations']
    require(len(values) == SAMPLES + WARMUPS, 'incomplete observation inventory')
    for index, value in enumerate(values):
        require(value['warmup'] is (index < WARMUPS), 'warmup order mismatch')
        require(value['stdout'] == case['stdout'] and value.get('stderr', '') == '' and
                value.get('matched', True) is True and value.get('completion', 'normal') == 'normal', 'unchecked or failing output')
    return values[WARMUPS:]


def statistics_row(values):
    require(len(values) >= 3 and all(type(value) is int and value >= 0 for value in values), 'invalid samples')
    return dict(samples=values, count=len(values), median=statistics.median(values),
                mean=statistics.mean(values), minimum=min(values), maximum=max(values))


def analyze(prefix, order, lock=None):
    lock = checked_lock() if lock is None else lock
    _, cases, _ = inputs()
    plan = load(OUT / (prefix + '-plan.json'))
    completion = load(OUT / (prefix + '-complete.json'))
    require(plan['order'] == order and completion['order'] == order and
            completion['cases'] == [case['file'] for case in cases] and
            plan['product_lock_sha256'] == digest(OUT / 'product-lock.json') and
            plan['source_hashes'] == lock['source_hashes'], 'incomplete or relabeled cohort')
    rows = []
    for case in cases:
        row = dict(file=case['file'], role='startup' if case['file'] == 'startup.js' else 'scaling',
                   stdout=case['stdout'], source_sha256=lock['source_hashes'][case['file']])
        for boundary in ['original', 'ordinary']:
            sides = {}
            for label in ['baseline', 'candidate']:
                times, rss, rounds = [], [], []
                for index, side in enumerate(order):
                    if side != label:
                        continue
                    stem = f'{prefix}-r{index}-{label}-{boundary}-{case["file"]}'
                    command = load(OUT / (stem + '.command.json'))
                    tool = lock[label]['products']['runtime_baseline' if boundary == 'ordinary' else 'compiler_precompiled_baseline']
                    if boundary == 'original':
                        expected_argv = [tool['path'], 'execute-scriptw',
                            str(OUT / ('images-' + label) / (case['file'] + '.swpc')),
                            case['stdout'], str(SAMPLES), str(WARMUPS)]
                    else:
                        expected_argv = [tool['path'], str(PREPARED_SOURCES), str(SAMPLES),
                            str(WARMUPS), case['file'],
                            str(OUT / f'{prefix}-r{index}-{label}-ordinary-artifacts')]
                    require(command['argv'] == expected_argv and command['cwd'] == str(ROOT) and
                            command['executable_sha256'] == tool['sha256'] and
                            command['exit_code'] == 0 and not command['timed_out'] and
                            command['resource_policy_unchanged'] is True, 'raw process/product mismatch')
                    samples = observations(load(OUT / (stem + '.stdout')), boundary, case, label, lock)
                    values = [sample['execution_ns'] if boundary == 'ordinary' else sample['phases_ns']['execution'] for sample in samples]
                    times.extend(values)
                    round_row = dict(index=index, group=index // 4, timing_ns=statistics_row(values),
                                     raw_stdout=stem + '.stdout', raw_process=stem + '.command.json')
                    if boundary == 'original':
                        memory = [sample['process_snapshots']['after_execution']['rss_bytes'] for sample in samples]
                        rss.extend(memory)
                        round_row['post_execution_rss_bytes'] = statistics_row(memory)
                    rounds.append(round_row)
                side_row = dict(cohort=lock[label]['cohort'], timing_ns=statistics_row(times), rounds=rounds)
                if rss:
                    side_row['post_execution_rss_bytes'] = statistics_row(rss)
                sides[label] = side_row
            summary = dict(products=sides)
            for metric in ['median', 'mean']:
                summary[metric + '_change_percent'] = 100 * (sides['candidate']['timing_ns'][metric] / sides['baseline']['timing_ns'][metric] - 1)
            if boundary == 'original':
                summary['post_execution_rss_change_percent'] = {
                    metric: 100 * (sides['candidate']['post_execution_rss_bytes'][metric] /
                                   sides['baseline']['post_execution_rss_bytes'][metric] - 1)
                    for metric in ['median', 'mean']}
            summary['groups'] = []
            for group in range((len(order) + 3) // 4):
                group_row = dict(index=group)
                for label in ['baseline', 'candidate']:
                    group_values = [value for round_row in sides[label]['rounds'] if round_row['group'] == group for value in round_row['timing_ns']['samples']]
                    group_row[label] = statistics_row(group_values)
                for metric in ['median', 'mean']:
                    group_row[metric + '_change_percent'] = 100 * (group_row['candidate'][metric] / group_row['baseline'][metric] - 1)
                if boundary == 'original':
                    group_row['post_execution_rss_bytes'] = {
                        label: statistics_row([value
                            for round_row in sides[label]['rounds'] if round_row['group'] == group
                            for value in round_row['post_execution_rss_bytes']['samples']])
                        for label in ['baseline', 'candidate']}
                summary['groups'].append(group_row)
            row[boundary] = summary
        rows.append(row)
    save(OUT / (prefix + '-analysis.json'), dict(schema='scriptw-affine-scaling-analysis-v1',
         order=order, samples=SAMPLES, warmups_checked=WARMUPS, workloads=rows,
         scope='Derived scaling/admission controls only; original compiler-free fresh Store and ordinary invocation separate; startup preserved; cannot replace unchanged original-source gate.'))


def node_reference(prefix):
    prepared_sources()
    node = shutil.which('node')
    require(node is not None, 'optional Node reference executable unavailable')
    node = str(Path(node).resolve())
    sha = digest(node)
    _, cases, source_hashes = inputs()
    versions = None
    for case in cases:
        report = invoke(prefix + '-node-' + case['file'],
                        [node, NODE_HARNESS, PREPARED_SOURCES, str(SAMPLES), str(WARMUPS), case['file']], sha, node=True)
        require(report['schema'] == 'scriptw-v8-baseline-v2' and report['samples'] == SAMPLES and
                report['warmups'] == WARMUPS and len(report['cases']) == 1, 'Node policy mismatch')
        reported_versions = dict(node=report['node'], v8=report['v8'])
        require(versions is None or versions == reported_versions, 'Node reference version changed')
        versions = reported_versions
        actual = report['cases'][0]
        require(actual['file'] == case['file'] and actual['source_sha256'] == digest(SOURCES / case['file']), 'Node source mismatch')
        require(len(actual['observations']) == SAMPLES + WARMUPS and all(
            value['warmup'] is (index < WARMUPS) and value['stdout'] == case['stdout']
            for index, value in enumerate(actual['observations'])), 'Node expected-value mismatch')
    save(OUT / (prefix + '-node-verification.json'), dict(status='independently verified',
         node=node, versions=versions, executable_sha256=sha, harness_sha256=digest(NODE_HARNESS),
         cases=[case['file'] for case in cases], source_hashes=source_hashes,
         samples=SAMPLES, warmups_checked=WARMUPS))


def measure(prefix, order):
    require(Path(prefix).name == prefix and prefix, 'invalid cohort prefix')
    lock = checked_lock()
    prepared_sources()
    for label in ['baseline', 'candidate']:
        producer(label, lock)
    save(OUT / (prefix + '-plan.json'), dict(order=order, samples=SAMPLES, warmups_checked=WARMUPS,
         product_lock_sha256=digest(OUT / 'product-lock.json'), source_hashes=lock['source_hashes'],
         resources_before=resources(), node_reference='optional separate invocation; not part of native timing'))
    _, cases, _ = inputs()
    for index, label in enumerate(order):
        artifacts = OUT / f'{prefix}-r{index}-{label}-ordinary-artifacts'
        artifacts.mkdir()
        selected = cases if index % 2 == 0 else list(reversed(cases))
        for case in selected:
            base = f'{prefix}-r{index}-{label}-'
            tool = lock[label]['products']['compiler_precompiled_baseline']
            report = invoke(base + 'original-' + case['file'], [tool['path'], 'execute-scriptw',
                     OUT / ('images-' + label) / (case['file'] + '.swpc'), case['stdout'],
                     str(SAMPLES), str(WARMUPS)], tool['sha256'])
            observations(report, 'original', case, label, lock)
            tool = lock[label]['products']['runtime_baseline']
            report = invoke(base + 'ordinary-' + case['file'], [tool['path'], PREPARED_SOURCES,
                     str(SAMPLES), str(WARMUPS), case['file'], artifacts], tool['sha256'])
            observations(report, 'ordinary', case, label, lock)
    save(OUT / (prefix + '-complete.json'), dict(status='all selected scaling/startup observations matched',
         order=order, cases=[case['file'] for case in cases], resources_after=resources(),
         independent_node_verification='see optional separate receipt; not inferred'))
    analyze(prefix, order, lock)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest='command', required=True)
    binding = commands.add_parser('bind')
    binding.add_argument('--candidate-fingerprint', required=True)
    preparing = commands.add_parser('prepare')
    preparing.add_argument('label', choices=['baseline', 'candidate'])
    for name in ['measure', 'analyze']:
        command = commands.add_parser(name)
        command.add_argument('prefix')
        command.add_argument('--order', choices=list(ORDERS), default='eight')
    reference = commands.add_parser('verify-node')
    reference.add_argument('prefix')
    args = parser.parse_args()
    if args.command == 'bind':
        bind(args.candidate_fingerprint)
    elif args.command == 'prepare':
        prepare(args.label)
    elif args.command == 'measure':
        measure(args.prefix, ORDERS[args.order])
    elif args.command == 'analyze':
        analyze(args.prefix, ORDERS[args.order])
    elif args.command == 'verify-node':
        node_reference(args.prefix)


if __name__ == '__main__':
    main()
