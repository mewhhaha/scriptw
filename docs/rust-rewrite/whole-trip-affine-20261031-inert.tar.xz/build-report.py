"""Assemble report-core.json after the whole-trip affine cohorts complete; never publish."""
from pathlib import Path
import datetime
import hashlib
import json
import math
import re
import statistics

ROOT = Path('/workspace/scriptw')
OUT = Path(__file__).resolve().parent
PARENT = 'e15843397c217c0e113c50e2164c0d1fa5552112'
BASELINE = '6764a3510a89a7830e6277cd91df09c9fc2769da901bcf578d87e9289d7050c5'
COMBINED = '6cd1e0d045b9f6a1b131fdaf8353a16a93e204a1ce3c3690887552631fadfd52'



def read(name):
    path = OUT / name
    assert path.stat().st_size <= 16 * 1024**2, path
    return json.loads(path.read_text())


def digest(path):
    # Only source/patch inputs are hashed here; product identities come from receipts.
    assert path.stat().st_size <= 4 * 1024**2, path
    return hashlib.sha256(path.read_bytes()).hexdigest()


def outcome(case, passed, failed=0):
    assert case['outcomes'] == [dict(passed=passed, failed=failed, ignored=0)]
    assert case['state'] == ('failed' if failed else 'passed')
    assert case['exit_code'] == (101 if failed else 0)


def raw_files(stdout):
    assert stdout.endswith('.stdout') and Path(stdout).name == stdout, stdout
    stem = stdout.removesuffix('.stdout')
    paths = dict(stdout=stdout, stderr=stem + '.stderr', command=stem + '.command.json')
    assert all((OUT / name).is_file() and not (OUT / name).is_symlink() for name in paths.values()), paths
    return paths


def validate_analysis(name, order, expected, identities, product_records, node_identity, require_means=False):
    report = read(name)
    assert report['order'] == order
    assert report['samples'] == 21 and report['warmups'] == 10
    rows = report['workloads']
    assert len(rows) == len(expected) > 0
    assert len({row['file'] for row in rows}) == len(expected)
    assert {row['file'] for row in rows} == set(expected)
    raw = []
    prefix = name.removesuffix('-analysis.json')
    for row in rows:
        assert row['source_sha256'] == digest(OUT / 'sources' / row['file'])
        for boundary in ('original', 'retained', 'ordinary'):
            products = row[boundary]['products']
            assert set(products) == {'baseline', 'candidate'}
            for label, values in products.items():
                assert math.isfinite(values['median_ns']) and values['median_ns'] > 0
                rounds = values['rounds']
                assert [r['index'] for r in rounds] == [i for i, actual in enumerate(order) if actual == label]
                assert all(r['raw'] == f"{prefix}-r{r['index']}-{label}-{boundary}-{row['file']}.stdout" for r in rounds)
                paths = [raw_files(r['raw']) for r in rounds]
                raw.extend(paths)
                scores, rss = [], []
                for round_row, files in zip(rounds, paths):
                    record = read(files['stdout'])
                    command = read(files['command'])
                    tool = 'runtime_baseline' if boundary == 'ordinary' else 'compiler_precompiled_baseline'
                    identity = product_records[label][tool]['sha256']
                    assert command['exit_code'] == 0 and not command['timed_out']
                    assert command['executable_sha256'] == identity
                    assert command['cwd'] == str(ROOT)
                    assert record['source_fingerprint'] == identities[label]['source_fingerprint']
                    assert record['source_commit'] == identities[label]['source_commit']
                    assert record['executable_sha256'] == identity
                    assert record['samples'] == 21 and record['warmups'] == 10
                    if boundary != 'ordinary':
                        assert record['compiler_enabled'] is False
                        assert record['shared_configuration'] == identities[label]['shared_configuration']
                        if boundary == 'retained':
                            producer = record['producer']
                            assert producer['source_fingerprint'] == identities[label]['source_fingerprint']
                            assert producer['executable_sha256'] == identity and producer['compiler_enabled'] is True
                            assert producer['original_source_sha256'] == row['source_sha256']
                    else:
                        assert len(record['cases']) == 1 and record['cases'][0]['file'] == row['file']
                        assert record['cases'][0]['source_sha256'] == row['source_sha256']
                    observations = record['cases'][0]['observations'] if boundary == 'ordinary' else record['observations']
                    assert len(observations) == 31
                    assert all(o['warmup'] is (i < 10) and o.get('matched', True) is True
                               and o.get('completion', 'normal') == 'normal' and o.get('stderr', '') == ''
                               and o['stdout'] == expected[row['file']]['stdout']
                               for i, o in enumerate(observations))
                    samples = [o for o in observations if not o['warmup']]
                    assert len(samples) == 21
                    times = [o['call_ns'] if boundary == 'retained' else o['phases_ns']['execution'] if boundary == 'original' else o['execution_ns'] for o in samples]
                    assert statistics.median(times) == round_row['median_ns']
                    scores.extend(times)
                    if boundary == 'original':
                        rss.extend(o['process_snapshots']['after_execution']['rss_bytes'] for o in samples)
                    if require_means:
                        assert statistics.mean(times) == round_row['mean_ns']
                assert statistics.median(scores) == values['median_ns']
                if require_means:
                    assert values['samples'] == len(scores) == 21 * order.count(label)
                    assert math.isfinite(values['mean_ns']) and values['mean_ns'] > 0
                    assert statistics.mean(scores) == values['mean_ns']
                    if boundary == 'original':
                        assert statistics.median(rss) == values['rss_bytes']
            calculated = 100 * (products['candidate']['median_ns'] / products['baseline']['median_ns'] - 1)
            assert math.isclose(row[boundary]['change_percent'], calculated, abs_tol=1e-9)
            if require_means:
                calculated_mean = 100 * (products['candidate']['mean_ns'] / products['baseline']['mean_ns'] - 1)
                assert math.isclose(row[boundary]['mean_change_percent'], calculated_mean, abs_tol=1e-9)
        reference = row['v8_reference']
        assert reference['median_ns'] > 0 and math.isfinite(reference['median_ns'])
        assert [r['index'] for r in reference['rounds']] == list(range(len(order)))
        v8_scores = []
        for round_row in reference['rounds']:
            index = round_row['index']
            assert round_row['raw'] == f"{prefix}-r{index}-{order[index]}-v8-{row['file']}.stdout"
            paths = raw_files(round_row['raw'])
            raw.append(paths)
            command, record = read(paths['command']), read(paths['stdout'])
            assert command['exit_code'] == 0 and not command['timed_out']
            assert command['executable_sha256'] == node_identity['sha256']
            assert command['cwd'] == str(ROOT)
            assert command['argv'][1] == str(ROOT / 'crates/scriptw-cli/tests/fixtures/v8_baseline/node-runtime.cjs')
            assert record['schema'] == 'scriptw-v8-baseline-v2'
            assert record['node'].removeprefix('v') == node_identity['versions']['node']
            assert record['v8'] == node_identity['versions']['v8']
            assert record['samples'] == 21 and record['warmups'] == 10
            assert len(record['cases']) == 1
            case = record['cases'][0]
            assert case['file'] == row['file'] and case['source_sha256'] == row['source_sha256']
            assert len(case['observations']) == 31
            assert all(o['warmup'] is (i < 10) and o['stdout'] == expected[row['file']]['stdout']
                       for i, o in enumerate(case['observations']))
            samples = [o for o in case['observations'] if not o['warmup']]
            assert len(samples) == 21
            v8_scores.extend(o['execution_ns'] for o in samples)
        assert statistics.median(v8_scores) == reference['median_ns']
    return report, raw


def startup_rows(prefix, order, expected_stdout, identities, products):
    rows = []
    for index, label in enumerate(order):
        stem = f'{prefix}-r{index}-{label}-startup'
        paths = raw_files(stem + '.stdout')
        command = read(paths['command'])
        assert command['exit_code'] == 0 and not command['timed_out']
        assert command['cwd'] == str(ROOT)
        record = read(paths['stdout'])
        assert record['source_fingerprint'] == identities[label]['source_fingerprint']
        assert record['source_commit'] == identities[label]['source_commit']
        product = products[label]['compiler_precompiled_baseline']['sha256']
        assert command['executable_sha256'] == record['executable_sha256'] == product
        assert record['compiler_enabled'] is False
        assert record['shared_configuration'] == identities[label]['shared_configuration']
        assert record['samples'] == 21 and record['warmups'] == 10
        observations = record['observations']
        assert len(observations) == 31
        assert all(o['warmup'] is (i < 10) and o['matched'] and o['stdout'] == expected_stdout
                   and o['completion'] == 'normal' and o['stderr'] == ''
                   for i, o in enumerate(observations))
        samples = [o for o in observations if not o['warmup']]
        assert len(samples) == 21
        rows.append(dict(
            index=index, product=label, raw=paths,
            median_execution_ns=statistics.median(o['phases_ns']['execution'] for o in samples),
            mean_execution_ns=statistics.mean(o['phases_ns']['execution'] for o in samples),
            median_post_execution_rss_bytes=statistics.median(o['process_snapshots']['after_execution']['rss_bytes'] for o in samples),
            mean_post_execution_rss_bytes=statistics.mean(o['process_snapshots']['after_execution']['rss_bytes'] for o in samples),
        ))
    return rows


def validate_resources(resources):
    before, after = resources['before'], resources['after']
    assert before['affinity'] == after['affinity'] == [0]
    assert before['cloud_budget_bytes'] == after['cloud_budget_bytes'] == 32 * 1024**3
    for key in ('memory.max', 'memory.swap.max', 'memory.oom.group', 'cpu.max'):
        assert before['cgroup'][key] == after['cgroup'][key]
    assert int(before['cgroup']['memory.max']) == before['cloud_budget_bytes']


def scaling_control_evidence(name, identities, products):
    """Keep extra source-generic scaling outside the unchanged-original table."""
    report = read(name)
    assert isinstance(report, dict) and report
    if 'complete' in report:
        assert report['complete'] is True
    raw_names = set()

    def collect(value):
        if isinstance(value, dict):
            for child in value.values():
                collect(child)
        elif isinstance(value, list):
            for child in value:
                collect(child)
        elif isinstance(value, str) and value.endswith('.stdout'):
            raw_names.add(value)

    collect(report)
    assert raw_names, name
    streams = []
    for raw in sorted(raw_names):
        files = raw_files(raw)
        command, record = read(files['command']), read(files['stdout'])
        assert command['exit_code'] == 0 and not command['timed_out']
        labels = [label for label, identity in identities.items()
                  if identity['source_fingerprint'] == record['source_fingerprint']]
        assert len(labels) == 1
        label = labels[0]
        if 'cases' in record:
            boundary, tool = 'ordinary', 'runtime_baseline'
            assert len(record['cases']) == 1
            case = record['cases'][0]
            fixture_root = Path(command['argv'][1])
            if not fixture_root.is_absolute():
                fixture_root = ROOT / fixture_root
            assert fixture_root.is_relative_to(ROOT)
            fixture = fixture_root / case['file']
            assert digest(fixture) == case['source_sha256']
            manifest = read(fixture_root / 'manifest.json')
            expected = next(row['stdout'] for row in manifest['execution'] if row['file'] == case['file'])
            observations = case['observations']
        else:
            boundary, tool = 'original', 'compiler_precompiled_baseline'
            assert record['compiler_enabled'] is False
            offset = command['argv'].index('execute-scriptw')
            expected = command['argv'][offset + 2]
            observations = record['observations']
        identity = products[label][tool]['sha256']
        assert command['executable_sha256'] == record['executable_sha256'] == identity
        assert len(observations) == 31
        assert all(o.get('matched', True) and o['stdout'] == expected for o in observations)
        assert sum(not o['warmup'] for o in observations) == 21
        assert all('call_ns' not in o for o in observations)
        streams.append(dict(product=label, boundary=boundary, raw=files,
                            source_fingerprint=record['source_fingerprint'], executable_sha256=identity))
    return dict(report=report, checked_raw_streams=streams,
                scope='Additional source-generic scaling/admission controls only; original precompiled and ordinary boundaries remain separate. These fixtures do not replace any unchanged original, add correctness coverage, or become fresh-Realm/V8 parity evidence.')


def nested_scaling_evidence(identities, products, reference_node):
    directory = OUT / 'scaling-controls'
    lock = read(directory / 'product-lock.json')
    hashes = read(directory / 'source-hashes.json')
    assert lock['schema'] == 'scriptw-affine-scaling-product-lock-v1'
    assert lock['source_hashes'] == hashes
    sources, prepared = directory / 'sources', directory / 'prepared-sources'
    assert {path.name for path in sources.iterdir()} == set(hashes)
    for name, sha in hashes.items():
        assert Path(name).name == name and digest(sources / name) == sha
    source_plan = read(sources / 'manifest.json')
    cases = [*source_plan['execution'], source_plan['startup']]
    names = [case['file'] for case in cases]
    assert len(cases) == len(set(names)) == 6
    assert names[-1] == source_plan['startup']['file'] == 'startup.js'
    assert read(prepared / 'manifest.json') == dict(source_plan, execution=cases)
    for name in names:
        assert digest(prepared / name) == hashes[name]
    for name, sha in lock['support'].items():
        assert digest(ROOT / name) == sha
    for label in ('baseline', 'candidate'):
        bound = lock[label]
        assert bound['identity'] == identities[label]
        assert bound['cohort'] == ('FIRST' if label == 'baseline' else 'AFFINE')
        assert digest(Path(bound['directory']) / 'identity.json') == bound['identity_metadata_sha256']
        assert digest(Path(bound['directory']) / 'products.json') == bound['products_metadata_sha256']
        for tool in ('compiler_precompiled_baseline', 'runtime_baseline'):
            assert bound['products'][tool]['sha256'] == products[label][tool]['sha256']
            assert bound['products'][tool]['bytes'] == products[label][tool]['bytes']
    order = ['baseline', 'candidate', 'candidate', 'baseline',
             'candidate', 'baseline', 'baseline', 'candidate']
    plan = read(directory / 'scaling-plan.json')
    completion = read(directory / 'scaling-complete.json')
    report = read(directory / 'scaling-analysis.json')
    assert plan['order'] == completion['order'] == report['order'] == order
    assert plan['product_lock_sha256'] == digest(directory / 'product-lock.json')
    assert plan['source_hashes'] == hashes and completion['cases'] == names
    assert completion['status'] == 'all selected scaling/startup observations matched'
    assert plan['samples'] == report['samples'] == 21
    assert plan['warmups_checked'] == report['warmups_checked'] == 10
    validate_resources(dict(before=plan['resources_before'], after=completion['resources_after']))
    assert [row['file'] for row in report['workloads']] == names
    assert report['schema'] == 'scriptw-affine-scaling-analysis-v1'
    raw_index = []

    def files(stem):
        assert Path(stem).name == stem
        result = {key: str((directory / (stem + suffix)).relative_to(OUT)) for key, suffix in
                  [('stdout', '.stdout'), ('stderr', '.stderr'), ('command', '.command.json')]}
        assert all((OUT / name).is_file() and not (OUT / name).is_symlink() for name in result.values())
        raw_index.append(result)
        return result

    def process(raw, expected_argv, executable_sha256):
        command = read(raw['command'])
        assert command['argv'] == expected_argv and command['cwd'] == str(ROOT)
        assert command['executable_sha256'] == executable_sha256
        assert command['exit_code'] == 0 and not command['timed_out']
        assert command['resource_policy_unchanged'] is True
        validate_resources(dict(before=command['resources_before'], after=command['resources_after']))
        before, after = command['resources_before']['environment'], command['resources_after']['environment']
        assert before == after
        assert all(before[key] == value for key, value in {
            'CARGO_BUILD_JOBS': '1', 'SCRIPTW_JOBS': '1', 'RAYON_NUM_THREADS': '1',
            'RUST_TEST_THREADS': '1', 'SCRIPTW_MODULE_MEMORY_CACHE_ENTRIES': '512',
            'SCRIPTW_MODULE_MEMORY_CACHE_LIMIT_BYTES': str(2 * 1024**3),
        }.items())

    def stats(actual, values):
        assert len(values) >= 3 and all(type(value) is int and value >= 0 for value in values)
        assert actual == dict(samples=values, count=len(values), median=statistics.median(values),
                              mean=statistics.mean(values), minimum=min(values), maximum=max(values))

    def change(actual, baseline, candidate):
        for metric in ('median', 'mean'):
            value = 100 * (candidate[metric] / baseline[metric] - 1)
            assert math.isclose(actual[metric + '_change_percent'], value, abs_tol=1e-9)

    producers = {}
    for label in ('baseline', 'candidate'):
        producer = read(directory / ('images-' + label) / 'producer.json')
        host = lock[label]['products']['compiler_precompiled_baseline']
        assert producer['schema'] == 'scriptw-precompiled-producer-v1'
        assert producer['source_fingerprint'] == identities[label]['source_fingerprint']
        assert producer['source_commit'] == identities[label]['source_commit']
        assert producer['executable_sha256'] == host['sha256'] and producer['compiler_enabled'] is True
        assert producer['shared_configuration'] == identities[label]['shared_configuration']
        assert producer['manifest_sha256'] == digest(prepared / 'manifest.json')
        assert [case['file'] for case in producer['cases']] == names
        for expected, case in zip(cases, producer['cases']):
            assert case['stdout'] == expected['stdout'] and case['source_sha256'] == hashes[case['file']]
            assert case['image'] == case['file'] + '.swpc' and case['wasm'] == case['file'] + '.wasm'
            assert case['source_compilation_profile'] == 'portable' and case['intl_profile'] == 'Minimal'
        preparation = files(label + '-prepare-original')
        process(preparation, [host['path'], 'prepare-scriptw', str(prepared),
                              str(directory / ('images-' + label))], host['sha256'])
        assert read(preparation['stdout']) == producer
        producers[label] = producer

    node_receipt = read(directory / 'reference-node-verification.json')
    assert node_receipt['status'] == 'independently verified' and node_receipt['cases'] == names
    assert node_receipt['source_hashes'] == hashes
    assert node_receipt['samples'] == 21 and node_receipt['warmups_checked'] == 10
    assert node_receipt['executable_sha256'] == reference_node['sha256']
    assert node_receipt['harness_sha256'] == reference_node['harness_sha256']
    assert node_receipt['versions']['node'].removeprefix('v') == reference_node['versions']['node']
    assert node_receipt['versions']['v8'] == reference_node['versions']['v8']
    harness = ROOT / 'crates/scriptw-cli/tests/fixtures/v8_baseline/node-runtime.cjs'
    assert node_receipt['harness_sha256'] == digest(harness)
    for case in cases:
        raw = files('reference-node-' + case['file'])
        process(raw, [node_receipt['node'], str(harness), str(prepared), '21', '10', case['file']],
                node_receipt['executable_sha256'])
        record = read(raw['stdout'])
        assert record['schema'] == 'scriptw-v8-baseline-v2'
        assert dict(node=record['node'], v8=record['v8']) == node_receipt['versions']
        assert record['samples'] == 21 and record['warmups'] == 10 and len(record['cases']) == 1
        actual = record['cases'][0]
        assert actual['file'] == case['file'] and actual['source_sha256'] == hashes[case['file']]
        assert len(actual['observations']) == 31
        assert all(o['warmup'] is (i < 10) and o['stdout'] == case['stdout']
                   for i, o in enumerate(actual['observations']))

    for expected, row in zip(cases, report['workloads']):
        assert row['file'] == expected['file'] and row['stdout'] == expected['stdout']
        assert row['source_sha256'] == hashes[row['file']]
        assert row['role'] == ('startup' if row['file'] == 'startup.js' else 'scaling')
        for boundary in ('original', 'ordinary'):
            summary = row[boundary]
            assert set(summary['products']) == {'baseline', 'candidate'}
            for label, side in summary['products'].items():
                assert side['cohort'] == lock[label]['cohort']
                rounds = side['rounds']
                assert [r['index'] for r in rounds] == [i for i, actual in enumerate(order) if actual == label]
                pooled, pooled_rss = [], []
                for round_row in rounds:
                    index = round_row['index']
                    assert round_row['group'] == index // 4
                    stem = f'scaling-r{index}-{label}-{boundary}-{row["file"]}'
                    assert round_row['raw_stdout'] == stem + '.stdout'
                    assert round_row['raw_process'] == stem + '.command.json'
                    raw = files(stem)
                    tool = lock[label]['products']['runtime_baseline' if boundary == 'ordinary' else 'compiler_precompiled_baseline']
                    argv = ([tool['path'], str(prepared), '21', '10', row['file'],
                             str(directory / f'scaling-r{index}-{label}-ordinary-artifacts')]
                            if boundary == 'ordinary' else
                            [tool['path'], 'execute-scriptw', str(directory / ('images-' + label) / (row['file'] + '.swpc')),
                             row['stdout'], '21', '10'])
                    process(raw, argv, tool['sha256'])
                    record = read(raw['stdout'])
                    assert record['source_fingerprint'] == identities[label]['source_fingerprint']
                    assert record['source_commit'] == identities[label]['source_commit']
                    assert record['executable_sha256'] == tool['sha256']
                    assert record['samples'] == 21 and record['warmups'] == 10
                    if boundary == 'ordinary':
                        assert record['schema'] == 'scriptw-wasmtime-baseline-v2'
                        assert record['requested_native_policy'] is None and len(record['cases']) == 1
                        actual = record['cases'][0]
                        assert actual['file'] == row['file'] and actual['source_sha256'] == hashes[row['file']]
                        observations = actual['observations']
                    else:
                        assert record['schema'] == 'scriptw-precompiled-execution-v1'
                        assert record['compiler_enabled'] is False and record['adapter'] == 'scriptw'
                        assert record['shared_configuration'] == identities[label]['shared_configuration']
                        image = next(case for case in producers[label]['cases'] if case['file'] == row['file'])
                        assert all(record[key] == image[key] for key in ('image_sha256', 'program_wasm_sha256', 'runtime_key'))
                        observations = record['observations']
                    assert len(observations) == 31
                    assert all(o['warmup'] is (i < 10) and o['stdout'] == row['stdout']
                               and o.get('stderr', '') == '' and o.get('matched', True) is True
                               and o.get('completion', 'normal') == 'normal'
                               for i, o in enumerate(observations))
                    samples = observations[10:]
                    values = [o['execution_ns'] if boundary == 'ordinary' else o['phases_ns']['execution'] for o in samples]
                    stats(round_row['timing_ns'], values)
                    pooled.extend(values)
                    if boundary == 'original':
                        rss = [o['process_snapshots']['after_execution']['rss_bytes'] for o in samples]
                        stats(round_row['post_execution_rss_bytes'], rss)
                        pooled_rss.extend(rss)
                assert len(pooled) == 84
                stats(side['timing_ns'], pooled)
                if boundary == 'original':
                    stats(side['post_execution_rss_bytes'], pooled_rss)
            sides = summary['products']
            change(summary, sides['baseline']['timing_ns'], sides['candidate']['timing_ns'])
            if boundary == 'original':
                for metric in ('median', 'mean'):
                    value = 100 * (sides['candidate']['post_execution_rss_bytes'][metric] /
                                   sides['baseline']['post_execution_rss_bytes'][metric] - 1)
                    assert math.isclose(summary['post_execution_rss_change_percent'][metric], value, abs_tol=1e-9)
            assert [group['index'] for group in summary['groups']] == [0, 1]
            for group in summary['groups']:
                for label in ('baseline', 'candidate'):
                    rounds = [r for r in sides[label]['rounds'] if r['group'] == group['index']]
                    values = [value for r in rounds for value in r['timing_ns']['samples']]
                    assert len(values) == 42
                    stats(group[label], values)
                    if boundary == 'original':
                        stats(group['post_execution_rss_bytes'][label],
                              [value for r in rounds for value in r['post_execution_rss_bytes']['samples']])
                change(group, group['baseline'], group['candidate'])
    assert len(raw_index) == 104  # 96 measured children, six Node checks, two producers.
    return dict(product_lock=lock, source_hashes=hashes, source_manifest=source_plan,
                prepared_manifest=read(prepared / 'manifest.json'), plan=plan, completion=completion,
                independent_node_verification=node_receipt, producer_identities=producers,
                report=report, raw_stream_index=raw_index,
                metadata_files=[str((directory / name).relative_to(OUT)) for name in (
                    'scaling-analysis.json', 'product-lock.json', 'source-hashes.json',
                    'sources/manifest.json', 'prepared-sources/manifest.json',
                    'scaling-plan.json', 'scaling-complete.json', 'reference-node-verification.json',
                    'images-baseline/producer.json', 'images-candidate/producer.json')],
                scope='Six derived rows, including the canonical startup row, in their original nested schema. Eight ABBA+BAAB rounds retain per-round, per-group and pooled medians/means and original post-execution RSS. Only original precompiled and ordinary invocation are measured; Node verifies goldens separately. No full-17 row is replaced or combined with this scaling/admission evidence.')


def main():
    sentinel = 'runtime_import_reachability::observable_intrinsics_keep_callable_bodies_and_provider_imports'
    expected_native = {
        ('scriptw-aot-wasm', 'scriptw_aot_wasm', 'tests::scalar_'): 12,
        ('scriptw-aot-wasm', 'runtime_link', sentinel): 1,
        ('scriptw-engine', 'aot_language', 'aot_scalar_execution::'): 22,
    }
    native_name = 'native-affine/receipt.json'
    native = read(native_name)
    assert native['head'] == PARENT and native['source_unchanged']
    assert native['shared_runtime_linker_unchanged']
    cases = {(case['package'], case['target'], case.get('native_filter')): case for case in native['cases']}
    assert len(cases) == len(native['cases']) == 3 and set(cases) == set(expected_native)
    native_rows, selected_tests, native_groups = [], set(), {}
    initial_passes = 0
    engine_key = ('scriptw-engine', 'aot_language', 'aot_scalar_execution::')
    repair_proof = read('test-repair-reuse-proof.json')
    repaired_test = repair_proof['repaired_test']
    for key, case in cases.items():
        count = case['outcomes'][0]['passed']
        failed = 1 if key == engine_key else 0
        outcome(case, count, failed)
        assert count + failed == expected_native[key] == case['inventoried_tests']
        assert case['inventory_matches'] is (not failed)
        inventory = ROOT / case['inventory_log']
        assert inventory.is_relative_to(OUT) and digest(inventory) == case['inventory_sha256']
        names = re.findall(r'^(.+): test$', inventory.read_text(), re.M)
        assert len(names) == count + failed
        for test_name in names:
            test_key = (case['package'], case['target'], test_name)
            assert test_key not in selected_tests, test_key
            selected_tests.add(test_key)
        native_rows.append(dict(receipt=native_name, package=key[0], target=key[1], filter=key[2],
                                passed=count, failed=failed, canonical_selected=count + failed,
                                inventory=case['inventory_log'],
                                inventory_sha256=case['inventory_sha256'], executable_sha256=case['executable_sha256']))
        native_groups[(native_name, key[1], key[2])] = (case, set(names))
        initial_passes += count
    assert initial_passes == 34 and len(selected_tests) == 35
    assert ('scriptw-aot-wasm', 'scriptw_aot_wasm',
            'tests::scalar_restricted_global_declarations_link_the_intrinsic_error_runtime') in selected_tests
    repair_name = 'native-affine-repair/receipt.json'
    repair = read(repair_name)
    assert repair['head'] == PARENT and repair['source_unchanged']
    assert repair['shared_runtime_linker_unchanged']
    for key in ('selected_workspace_packages', 'all_features', 'include_ignored', 'selected_feature_roots'):
        assert repair[key] == native[key]
    assert set(repair['selected_workspace_packages']) == {'scriptw-aot-wasm', 'scriptw-engine'}
    assert len(repair['cases']) == 1
    repaired_case = repair['cases'][0]
    outcome(repaired_case, 1)
    assert repaired_case['package'] == 'scriptw-engine' and repaired_case['target'] == 'aot_language'
    assert repaired_case['native_filter'] == repaired_test and repaired_test in repaired_case['command']
    assert repaired_case['inventoried_tests'] == 1 and repaired_case['inventory_matches']
    repaired_inventory = ROOT / repaired_case['inventory_log']
    assert repaired_inventory.is_relative_to(OUT)
    assert digest(repaired_inventory) == repaired_case['inventory_sha256']
    assert re.findall(r'^(.+): test$', repaired_inventory.read_text(), re.M) == [repaired_test]
    assert ('scriptw-engine', 'aot_language', repaired_test) in selected_tests
    native_groups[(repair_name, 'aot_language', repaired_test)] = (repaired_case, {repaired_test})
    native_rows.append(dict(receipt=repair_name, package='scriptw-engine', target='aot_language',
                            filter=repaired_test, passed=1, failed=0, canonical_selected=1,
                            inventory=repaired_case['inventory_log'],
                            inventory_sha256=repaired_case['inventory_sha256'],
                            executable_sha256=repaired_case['executable_sha256'],
                            scope='Exact repaired execution of the same initially failing canonical test; not an additional inventory case.'))
    native_passes = initial_passes + repaired_case['outcomes'][0]['passed']
    assert native_passes == len(selected_tests) == 35
    native_streams = read('native-stream-index.json')
    assert len(native_streams) == len(native_groups) == 4
    assert {(row['receipt'], row['scope'], row['filter']) for row in native_streams} == set(native_groups)
    for row in native_streams:
        case, names = native_groups[(row['receipt'], row['scope'], row['filter'])]
        path = OUT / row['path']
        assert path.is_file() and digest(path) == row['sha256']
        text = path.read_text()
        observed = re.findall(r'^test (.+) \.\.\. (ok|FAILED|ignored)$', text, re.M)
        assert len(observed) == len(names) and {name for name, _ in observed} == names
        actual = case['outcomes'][0]
        summaries = re.findall(r'^test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', text, re.M)
        assert summaries == [(str(actual['passed']), str(actual['failed']), str(actual['ignored']))]
        expected_failures = {repaired_test} if row['receipt'] == native_name and row['scope'] == 'aot_language' else set()
        assert {name for name, status in observed if status == 'FAILED'} == expected_failures
        assert all(status != 'ignored' for _, status in observed)

    original_inputs = read('compiled-inputs.json')
    inputs = read('compiled-inputs-v2.json')
    assert len(original_inputs) == len(inputs) == 12 and set(original_inputs) == set(inputs)
    repaired_source = 'crates/scriptw-engine/tests/aot_language/aot_scalar_execution.rs'
    assert repair_proof['changed_file'] == repaired_source and repair_proof['production_unchanged']
    assert repair_proof['initial_receipt'] == native_name
    assert repair_proof['before'] == original_inputs[repaired_source]
    assert repair_proof['after'] == inputs[repaired_source]
    assert {name for name in inputs if inputs[name] != original_inputs[name]} == {repaired_source}
    assert set(repair_proof['unchanged_inputs']) == set(inputs) - {repaired_source}
    before = OUT / 'implementation' / repaired_source
    after = OUT / 'implementation-v2' / repaired_source
    assert digest(before) == repair_proof['before']['sha256']
    assert digest(after) == repair_proof['after']['sha256']
    old = repair_proof['exact_replacement']['before'].encode()
    new = repair_proof['exact_replacement']['after'].encode()
    assert old == b'$262.createRealm().global' and new == b'__scriptwCreateRealm().global'
    assert before.read_bytes().count(old) == 1
    assert before.read_bytes().replace(old, new, 1) == after.read_bytes()
    production_paths = {
        'crates/scriptw-aot-wasm/src/control_flow.rs',
        'crates/scriptw-aot-wasm/src/control_flow/scalar_number_loop.rs',
        'crates/scriptw-aot-wasm/src/control_flow/scalar_number_loop/chunked.rs',
    }
    assert all(inputs[name] == original_inputs[name] for name in production_paths)
    for name in production_paths:
        assert digest(OUT / 'implementation' / name) == original_inputs[name]['sha256']
        assert digest(OUT / 'implementation-v2' / name) == inputs[name]['sha256']
    checked_inputs = {}
    for name, record in inputs.items():
        if name.startswith('crates/'):
            assert not Path(name).is_absolute() and '..' not in Path(name).parts
            assert digest(ROOT / name) == record['sha256'], name
            checked_inputs[name] = record
    assert set(checked_inputs) == {
        'crates/scriptw-aot-wasm/src/control_flow.rs',
        'crates/scriptw-aot-wasm/src/control_flow/scalar_number_loop.rs',
        'crates/scriptw-aot-wasm/src/control_flow/scalar_number_loop/chunked.rs',
        'crates/scriptw-aot-wasm/src/tests/scalar_regions.rs',
        'crates/scriptw-engine/tests/aot_language/aot_scalar_execution.rs',
    }
    restored = read('restored-runtime-source-proof.json')
    assert restored['parent_commit'] == PARENT
    assert set(restored['files']) == {
        'crates/scriptw-aot-wasm/src/intrinsics/deferred_methods/materialization.rs',
        'crates/scriptw-aot-wasm/src/intrinsics/deferred_methods/materialization/tests.rs',
    }
    for name, record in restored['files'].items():
        assert record['matches_parent_blob'] and digest(ROOT / name) == record['sha256']
    failed_binary = read('failed-native/frozen.json')
    assert failed_binary['sha256'] == cases[engine_key]['executable_sha256']
    failed_binary_path = Path(failed_binary['path'])
    assert failed_binary_path.is_relative_to(OUT / 'failed-native')
    assert failed_binary_path.is_file() and not failed_binary_path.is_symlink()
    assert failed_binary_path.stat().st_size == failed_binary['bytes']
    absent_modules = [
        'crates/scriptw-aot-wasm/src/gc_types/value/deferred_builtin_code.rs',
        'crates/scriptw-aot-wasm/src/gc_types/empty_array_properties.rs',
        'crates/scriptw-aot-wasm/src/gc_types/type_registration_tests/empty_array_properties.rs',
        'crates/scriptw-engine/tests/fixtures/array_private_buffers/shared_empty_named_storage.js',
    ]
    assert all(not (ROOT / name).exists() for name in absent_modules)
    value_source = ROOT / 'crates/scriptw-aot-wasm/src/gc_types/value.rs'
    assert 'deferred_builtin_code' not in value_source.read_text()
    runtime_source = ROOT / 'crates/scriptw-aot-wasm/src/runtime_artifact.rs'
    assert re.search(r'const\s+LAYOUT_VERSION\s*:\s*u32\s*=\s*41\s*;', runtime_source.read_text())
    assert not re.search(r'\bmod\s+empty_array_properties\s*;', (ROOT / 'crates/scriptw-aot-wasm/src/gc_types.rs').read_text())

    candidate_identity = read('candidate/identity.json')
    candidate_products = read('candidate/products.json')
    candidate_fingerprint = candidate_identity['source_fingerprint']
    assert re.fullmatch(r'[0-9a-f]{64}', candidate_fingerprint)
    assert candidate_fingerprint != BASELINE and candidate_identity['source_commit'] == PARENT
    accepted_identity = read('baseline-identity.json')
    accepted_products = read('baseline-products.json')
    assert accepted_identity['source_fingerprint'] == BASELINE
    assert accepted_identity['source_commit'] == '69ce371b964cc3af8da79750507ba5018eb2aef2'
    identities = dict(baseline=accepted_identity, candidate=candidate_identity)
    products = dict(baseline=accepted_products, candidate=candidate_products)
    for label in products:
        assert set(products[label]) == {'compiler_precompiled_baseline', 'runtime_baseline', 'scriptw'}
        assert products[label]['compiler_precompiled_baseline']['sha256'] == identities[label]['executable_sha256']
        assert identities[label]['shared_configuration'] == candidate_identity['shared_configuration']
    baseline_reuse = read('baseline-reuse-proof.json')
    assert baseline_reuse['parent_commit'] == PARENT
    assert baseline_reuse['baseline_original_identity'] == accepted_identity
    assert baseline_reuse['baseline_products'] == accepted_products
    build = read('candidate-build.json')
    assert build['head'] == PARENT and build['exit_code'] == 0

    selection_name = 'next-test262-selection/manifest.json'
    selection = read(selection_name)
    entries = selection['files']
    selected_paths = {row['path'] for row in entries}
    assert len(entries) == len(selected_paths) == selection['total_original_js'] == 40
    for_paths = {path for path in selected_paths if path.startswith('language/statements/for/')}
    imul_paths = {path for path in selected_paths if path.startswith('built-ins/Math/imul/')}
    assert len(for_paths) == selection['for_inventory']['selected_original_js'] == 35
    assert len(imul_paths) == selection['math_imul_inventory']['selected_original_js'] == 5
    assert selected_paths == for_paths | imul_paths
    suite_root = ROOT / selection['suite_root'] / 'test'
    assert suite_root.is_relative_to(ROOT)
    assert {str(path.relative_to(suite_root)) for path in (suite_root / 'built-ins/Math/imul').rglob('*.js')} == imul_paths
    for entry in entries:
        path = Path(entry['path'])
        assert not path.is_absolute() and '..' not in path.parts
        actual = suite_root / path
        assert actual.is_file() and not actual.is_symlink()
        assert actual.stat().st_size == entry['bytes'] and digest(actual) == entry['sha256']
    suite = read('test262-candidate-summary.json')
    assert len(suite['runs']) == 40
    actual_paths = []
    for run in suite['runs']:
        possible = [run[key] for key in ('file', 'path', 'scope') if run.get(key) in selected_paths]
        assert possible and len(set(possible)) == 1
        path = possible[0]
        actual_paths.append(path)
        assert run.get('product', 'candidate') == 'candidate' and run['exit_code'] == 0
        assert run['passed'] == run['total'] and run['total'] > 0
        assert run['executable_sha256'] == candidate_products['scriptw']['sha256']
        if 'source_fingerprint' in run:
            assert run['source_fingerprint'] == candidate_fingerprint
        index = run['argv'].index('run')
        assert run['argv'][index + 1] in {path, str(suite_root / path)}
        assert Path(run['raw']).name == run['raw'] and (OUT / run['raw']).is_file()
    assert len(set(actual_paths)) == 40 and set(actual_paths) == selected_paths
    test262_executions = sum(run['passed'] for run in suite['runs'])

    guards = (OUT / 'source-guards.log').read_text()
    assert sum(map(int, re.findall(r'test result: ok\. (\d+) passed; 0 failed;', guards))) == 359
    assert 'ok (30 permanent areas)' in (OUT / 'ownership.log').read_text()
    assert len(re.findall(r'^PASS ', (OUT / 'intl-source.log').read_text(), re.M)) == 15
    audit = dict(status='not separately recorded for this cohort')
    if (OUT / 'product-graph.log').exists():
        assert 'check-no-interpreter-in-product-graph: ok' in (OUT / 'product-graph.log').read_text()
        audit = dict(status='passed', raw='product-graph.log')

    manifest = read('sources/manifest.json')
    startup = manifest['startup']
    expected = {row['file']: row for row in manifest['execution'] if row['file'] != startup['file']}
    assert len(expected) == 17
    definitions = dict(initial=['baseline', 'candidate', 'candidate', 'baseline'],
                       confirmation=['candidate', 'baseline', 'baseline', 'candidate'])
    cohorts, contexts, raw_index, startup_controls, resources = {}, {}, {}, {}, {}
    reference_node = None
    harness = ROOT / 'crates/scriptw-cli/tests/fixtures/v8_baseline/node-runtime.cjs'
    for prefix, order in definitions.items():
        resources[prefix] = dict(before=read(prefix + '-resources-before.json'),
                                 after=read(prefix + '-resources-after.json'),
                                 node_identity=read(prefix + '-node-identity.json'))
        validate_resources(resources[prefix])
        node = resources[prefix]['node_identity']
        assert node['harness_sha256'] == digest(harness)
        if reference_node is None:
            reference_node = node
        assert all(node[key] == reference_node[key] for key in ('sha256', 'harness_sha256', 'versions'))
        contexts[prefix] = dict(baseline_kind='accepted-fusion', identities=identities, products=products,
                                order=order, scope='Accepted fusion 6764 versus this frozen whole-trip affine candidate.')
        cohorts[prefix], raw_index[prefix] = validate_analysis(
            prefix + '-analysis.json', order, expected, identities, products, node,
        )
        startup_controls[prefix] = startup_rows(prefix, order, startup['stdout'], identities, products)
    table = []
    for name in expected:
        row = dict(file=name, source_sha256=None, cohorts={})
        for prefix, analysis in cohorts.items():
            actual = next(value for value in analysis['workloads'] if value['file'] == name)
            if row['source_sha256'] is None:
                row['source_sha256'] = actual['source_sha256']
            assert actual['source_sha256'] == row['source_sha256']
            row['cohorts'][prefix] = {key: actual[key] for key in ('original', 'retained', 'ordinary', 'v8_reference')}
        table.append(row)

    targeted_controls = None
    if (OUT / 'control-plan.json').exists() or (OUT / 'controls-analysis.json').exists():
        control_plan = read('control-plan.json')
        fixtures = control_plan['fixtures']
        assert len(fixtures) == len(set(fixtures)) == 5
        assert set(fixtures) == {'join-singleton-1024.js', 'join-small-1024.js', 'integer.js',
                                 'objects.js', 'retained-objects.js'}
        assert set(fixtures).issubset(expected)
        control_order = ['baseline', 'candidate', 'candidate', 'baseline',
                         'candidate', 'baseline', 'baseline', 'candidate']
        assert control_plan['order'] == control_order
        assert control_plan['samples'] == 21 and control_plan['warmups'] == 10
        assert control_plan['baseline'] == 'accepted' + BASELINE[:4]
        assert control_plan['candidate'] == 'affine' + candidate_fingerprint[:4]
        assert read('controls-analysis.json')['complete'] is True
        control_resources = dict(before=read('controls-resources-before.json'),
                                 after=read('controls-resources-after.json'),
                                 node_identity=read('controls-node-identity.json'))
        validate_resources(control_resources)
        control_node = control_resources['node_identity']
        assert control_node['harness_sha256'] == digest(harness)
        assert all(control_node[key] == reference_node[key] for key in ('sha256', 'harness_sha256', 'versions'))
        control_report, control_raw = validate_analysis(
            'controls-analysis.json', control_order, {name: expected[name] for name in fixtures},
            identities, products, control_node, require_means=True,
        )
        targeted_controls = dict(
            plan=control_plan, report=control_report, raw_stream_index=control_raw,
            cohort_context=dict(baseline_kind='accepted-fusion', identities=identities,
                                products=products, order=control_order), resources=control_resources,
            startup_controls=startup_rows('controls', control_order, startup['stdout'], identities, products),
            scope='Five unchanged fixtures, eight balanced ABBA+BAAB rounds. All 84 measured observations per product/boundary, raw rounds, pooled medians/means and original RSS are validated. Startup and Node references are retained. This experiment remains separate from the full-17 cohorts and the six-row derived scaling experiment.',
        )

    targeted_extra_controls = None
    if (OUT / 'control-extra-plan.json').exists() or (OUT / 'controls-extra-analysis.json').exists():
        extra_plan = read('control-extra-plan.json')
        fixtures = extra_plan['fixtures']
        assert len(fixtures) == len(set(fixtures)) == 2
        assert set(fixtures) == {'sort-reverse-512.js', 'join-4096.js'}
        assert set(fixtures).issubset(expected)
        extra_order = ['baseline', 'candidate', 'candidate', 'baseline',
                       'candidate', 'baseline', 'baseline', 'candidate']
        assert extra_plan['order'] == extra_order
        assert extra_plan['samples'] == 21 and extra_plan['warmups'] == 10
        assert extra_plan['baseline'] == 'accepted' + BASELINE[:4]
        assert extra_plan['candidate'] == 'affine' + candidate_fingerprint[:4]
        assert read('controls-extra-analysis.json')['complete'] is True
        extra_resources = dict(before=read('controls-extra-resources-before.json'),
                               after=read('controls-extra-resources-after.json'),
                               node_identity=read('controls-extra-node-identity.json'))
        validate_resources(extra_resources)
        extra_node = extra_resources['node_identity']
        assert extra_node['harness_sha256'] == digest(harness)
        assert all(extra_node[key] == reference_node[key] for key in ('sha256', 'harness_sha256', 'versions'))
        extra_report, extra_raw = validate_analysis(
            'controls-extra-analysis.json', extra_order, {name: expected[name] for name in fixtures},
            identities, products, extra_node, require_means=True,
        )
        targeted_extra_controls = dict(
            plan=extra_plan, report=extra_report, raw_stream_index=extra_raw,
            cohort_context=dict(baseline_kind='accepted-fusion', identities=identities,
                                products=products, order=extra_order), resources=extra_resources,
            startup_controls=startup_rows('controls-extra', extra_order, startup['stdout'], identities, products),
            scope='Two additional unchanged fixtures, eight balanced ABBA+BAAB rounds. All three boundaries retain 84 measured observations per product, checked raw rounds, pooled medians/means and original RSS; startup, Node and resource identities are validated separately. This evidence does not replace the five-fixture control or either full-17 cohort.',
        )

    # Read actual P producer metadata; serialized-image lengths are not native
    # text lengths or process residency, and R keys are observations, not assumptions.
    producer_paths = dict(baseline=ROOT / 'target/performance-memory-parity-20261031/candidate-original/producer.json',
                          candidate=OUT / 'candidate-original/producer.json')
    program_records = {}
    all_originals = {**expected, startup['file']: startup}
    for label, path in producer_paths.items():
        producer = read(path)
        assert producer['source_fingerprint'] == identities[label]['source_fingerprint']
        assert producer['executable_sha256'] == products[label]['compiler_precompiled_baseline']['sha256']
        cases_by_file = {row['file']: row for row in producer['cases']}
        assert len(cases_by_file) == len(producer['cases'])
        assert set(all_originals).issubset(cases_by_file)
        program_records[label] = {}
        for name in all_originals:
            record = cases_by_file[name]
            assert record['source_sha256'] == digest(OUT / 'sources' / name)
            assert record['stdout'] == all_originals[name]['stdout']
            assert record['program_wasm_bytes'] > 0 and record['native_serialized_bytes'] > 0
            program_records[label][name] = {key: record[key] for key in (
                'source_sha256', 'program_wasm_bytes', 'program_wasm_sha256',
                'native_serialized_bytes', 'image_bytes', 'image_sha256', 'runtime_key',
            )}
    program_diagnostics = dict(
        producer_files={label: str(path) for label, path in producer_paths.items()}, records=program_records,
        deltas=[dict(file=name,
                     wasm_bytes=program_records['candidate'][name]['program_wasm_bytes'] - program_records['baseline'][name]['program_wasm_bytes'],
                     serialized_program_bytes=program_records['candidate'][name]['native_serialized_bytes'] - program_records['baseline'][name]['native_serialized_bytes'],
                     runtime_keys_equal=program_records['candidate'][name]['runtime_key'] == program_records['baseline'][name]['runtime_key'])
                for name in all_originals],
        scope='Actual frozen P producer metadata for unchanged originals/startup. Serialized program-module image bytes include code/metadata/data and are distinct from exclusive native function bytes, text residency and RSS. Runtime-key equality is recorded per fixture; it is not assumed from restored source.',
    )
    diagnostics = dict(program_products=program_diagnostics,
                       runtime_code_ownership_status='Not established by source restoration; inspect actual R diagnostics.')
    if (OUT / 'runtime-code-size.json').exists():
        size = read('runtime-code-size.json')
        assert size['scored'] is False
        for label in ('baseline', 'candidate'):
            assert size['products'][label]['source_fingerprint'] == identities[label]['source_fingerprint']
            assert size['products'][label]['host_sha256'] == identities[label]['executable_sha256']
            assert size['products'][label]['runtime_layout'] == 41
        diagnostics['runtime_code_size'] = size
        diagnostics['runtime_code_ownership_status'] = 'Recorded from actual inert frozen R products; see runtime_code_size, without a source-based equality assumption.'
    artifact_comparison = read('program-artifact-comparison.json')
    artifact_rows = {row['file']: row for row in artifact_comparison['workloads']}
    assert len(artifact_rows) == len(artifact_comparison['workloads']) == len(all_originals) == 18
    assert set(artifact_rows) == set(all_originals)
    for name, comparison in artifact_rows.items():
        before, after = program_records['baseline'][name], program_records['candidate'][name]
        assert comparison['source_sha256'] == before['source_sha256'] == after['source_sha256']
        assert comparison['runtime_key_equal'] is (before['runtime_key'] == after['runtime_key'])
        assert comparison['program_wasm_equal'] is (before['program_wasm_sha256'] == after['program_wasm_sha256'])
        assert comparison['wasm_bytes_before'] == before['program_wasm_bytes']
        assert comparison['wasm_bytes_after'] == after['program_wasm_bytes']
        assert comparison['native_serialized_bytes_before'] == before['native_serialized_bytes']
        assert comparison['native_serialized_bytes_after'] == after['native_serialized_bytes']
    runtime_products = diagnostics['runtime_code_size']['products']
    same_runtime_native = runtime_products['baseline']['native_sha256'] == runtime_products['candidate']['native_sha256']
    assert artifact_comparison['runtime_native_sha_equal'] is same_runtime_native is True
    assert all(row['runtime_key_equal'] for row in artifact_rows.values())
    assert all(program_records[label][name]['runtime_key'] == runtime_products[label]['runtime_key']
               for label in ('baseline', 'candidate') for name in all_originals)
    changed_originals = [name for name in expected if not artifact_rows[name]['program_wasm_equal']]
    assert changed_originals == ['integer.js']
    assert artifact_rows[startup['file']]['program_wasm_equal'] is True
    diagnostics['program_artifact_comparison'] = dict(
        raw='program-artifact-comparison.json', report=artifact_comparison,
        identical_original_program_wasm_hashes=len(expected) - len(changed_originals),
        changed_originals=changed_originals,
        integer_delta=dict(raw_wasm_bytes=artifact_rows['integer.js']['wasm_bytes_after'] - artifact_rows['integer.js']['wasm_bytes_before'],
                           serialized_program_native_bytes=artifact_rows['integer.js']['native_serialized_bytes_after'] - artifact_rows['integer.js']['native_serialized_bytes_before']),
        scope='Actual producer hashes and inert R metadata establish equal runtime keys/native SHA and 16 unchanged original P raw-Wasm hashes; startup is separately unchanged. Integer P grows in raw Wasm and serialized native-module bytes. Serialized module length is not native text size, page residency, allocation count or RSS.',
    )
    diagnostics['runtime_code_ownership_status'] = 'Actual inert R metadata establishes identical runtime keys/native SHA; 16 original P raw-Wasm hashes and startup are unchanged. Integer serialized-module growth is recorded separately from native text and memory.'
    for name in ('program-code-size.json', 'code-ownership.json', 'affine-code-ownership.json'):
        if (OUT / name).exists():
            diagnostic = read(name)
            assert isinstance(diagnostic, dict) and diagnostic
            if 'source_fingerprint' in diagnostic:
                assert diagnostic['source_fingerprint'] == candidate_fingerprint
            diagnostics[name] = diagnostic
    if (OUT / 'scriptc-comparison.json').exists():
        comparison = read('scriptc-comparison.json')
        if comparison.get('complete') is True:
            assert comparison['samples'] == 21 and comparison['warmups'] == 10
            validate_resources(dict(before=comparison['resources_before'], after=comparison['resources_after']))
            assert len(comparison['workloads']) == 17
            assert {row['file'] for row in comparison['workloads']} == set(expected)
            assert len(comparison['attempts']) == 68
            seen, scriptc_raw, scriptc_observations = set(), [], {}
            for attempt in comparison['attempts']:
                key = (attempt['round'], attempt['runtime'], attempt['file'])
                assert key not in seen and key[0] in (0, 1) and key[1] in ('scriptw', 'scriptc') and key[2] in expected
                seen.add(key)
                paths = raw_files(attempt['raw'])
                command, record = read(paths['command']), read(paths['stdout'])
                assert command['exit_code'] == 0 and not command['timed_out']
                assert command['cwd'] == str(ROOT)
                assert command['executable_sha256'] == record['executable_sha256'] == candidate_identity['executable_sha256']
                assert record['source_fingerprint'] == candidate_fingerprint and record['compiler_enabled'] is False
                assert record['source_commit'] == candidate_identity['source_commit']
                assert record['samples'] == 21 and record['warmups'] == 10
                assert record['image_sha256'] == attempt['image_sha256']
                assert len(record['observations']) == 31
                assert all(o['warmup'] is (i < 10) and o.get('matched', True) is True
                           and o.get('completion', 'normal') == 'normal' and o.get('stderr', '') == ''
                           and o['stdout'] == expected[key[2]]['stdout']
                           for i, o in enumerate(record['observations']))
                scriptc_observations.setdefault((key[1], key[2]), []).extend(record['observations'][10:])
                scriptc_raw.append(paths)
            for row in comparison['workloads']:
                assert set(row['products']) == {'scriptw', 'scriptc'}
                for runtime, metrics in row['products'].items():
                    observations = scriptc_observations[(runtime, row['file'])]
                    assert len(observations) == 42
                    assert metrics['median_ns'] == statistics.median(o['phases_ns']['execution'] for o in observations)
                    for key in ('rss_bytes', 'pss_bytes', 'private_dirty_bytes'):
                        assert metrics[key] == statistics.median(o['process_snapshots']['after_execution'][key] for o in observations)
                assert math.isclose(row['time_ratio'], row['products']['scriptw']['median_ns'] / row['products']['scriptc']['median_ns'], abs_tol=1e-9)
                assert math.isclose(row['rss_ratio'], row['products']['scriptw']['rss_bytes'] / row['products']['scriptc']['rss_bytes'], abs_tol=1e-9)
            diagnostics['scriptc_comparison'] = comparison
            diagnostics['scriptc_raw_stream_index'] = scriptc_raw
        else:
            diagnostics['scriptc_comparison_pending'] = dict(raw='scriptc-comparison.json',
                                                            scope='Incomplete optional comparison; excluded from measured claims.')
    scaling_controls = nested_scaling_evidence(identities, products, reference_node)
    scaling = {}
    scaling_paths = set(OUT.glob('*scaling*-analysis.json')) | set(OUT.glob('*affine*control*-analysis.json'))
    for path in sorted(scaling_paths):
        scaling[path.name] = scaling_control_evidence(path.name, identities, products)

    report = dict(
        schema='scriptw-whole-trip-affine-v1',
        recorded_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        status='measured-review-pending',
        source=dict(parent_commit=PARENT, candidate_fingerprint=candidate_fingerprint,
                    candidate_identity=candidate_identity, candidate_products=candidate_products,
                    candidate_build=build, accepted_baseline_reuse_proof=baseline_reuse,
                    patch_sha256=digest(OUT / 'compile-inputs-v2.patch'),
                    original_patch_sha256=digest(OUT / 'compile-inputs.patch'), inputs=inputs,
                    snapshot_manifests=dict(initial='compiled-inputs.json', repaired='compiled-inputs-v2.json'),
                    verified_current_crate_inputs=checked_inputs, restored_runtime_source_proof=restored,
                    runtime_source=dict(path=str(runtime_source.relative_to(ROOT)), sha256=digest(runtime_source), layout_version=41),
                    identity_note='Candidate is frozen e15843397 plus the exact twelve-file repaired v2 snapshot/patch. Five current Rust hashes must match; seven README/docs snapshots may receive measured prose. Initial and v2 snapshots prove the sole change is the one-line Engine host-hook fixture repair; all three production Rust inputs remain byte-identical. Both deferred-method files are separately checked against their exact parent-blob restoration proof. The actual frozen candidate fingerprint is read dynamically; rejected runtime products are not baselines or correctness evidence.'),
        change=dict(
            runtime_layout_version=41, abi_layout_changed=False, default_policy_changed=False,
            behavior='Inside the existing Number/private-binding/native-callee proof, a literal single-var seed C, bare-counter strict < literal L, upward recognized unit update, exact32 independent one-assignment body and 0<=C<L<=i32::MAX admit bounded compile-time affine T^(L-C). A runtime exact-counter-bit guard selects one live-state transform and branches to common writeback. Misses retain the eight-step chunk, scalar tail and full classic fallback.',
            bounds='Negative-zero seed, zero/negative/fractional/nonfinite trips, nonliteral or nonprivate heads/tests, inclusive/reversed/descending forms and observed intermediate state retain old paths. Host composition is bounded to 31 steps; the 1e12 epoch-timeout fixture remains outside admission.',
            allocation_memory_claim='None. Existing admitted iterations already allocate no GC objects; this CPU experiment reuses state/counter/body-value/iterated locals, retains fallbacks and may grow P code. Actual R/P ownership and byte effects are diagnostics, not inferred from source boundaries.',
        ),
        validation=dict(
            native_passing_cases=native_passes, native_unique_canonical_cases=35,
            native_selected_case_groups=3, native_execution_groups=4, native_groups=native_rows,
            native_initial_passes=initial_passes, native_repair_passes=1,
            native_receipt=native_name, native_repair_receipt=repair_name, native_streams=native_streams,
            source_bound_continuation=repair_proof,
            native_count_note='35 unique canonical passing checks: library tests::scalar_ actually selects 12, including the pre-existing restricted-global-declarations linkage case; the exact runtime-link sentinel selects 1; Engine selects 22. Initial execution passed 12+1+21 and failed only the new foreign-callee fixture. The same canonical failing test passed once after its exact one-line host-hook correction under the unchanged two-package feature union. Initial passing inventories are reused with all three production files and all other inputs unchanged. No fresh full 22-case Engine run on the final fixture is claimed; the repair is not a new inventory case. All four sealed streams and the original failure remain preserved.',
            test262_selected_original_files=40, test262_for_subset_files=35, test262_complete_math_imul_files=5,
            test262_passing_executions=test262_executions,
            test262_selection_manifest=selection, test262_selection_sha256=digest(OUT / selection_name),
            test262_original_file_runs=suite,
            coverage_note='Forty exact original files: an explicit 35-file for-statement subset and all five pinned Math.imul files. Actual passing variants come only from the completed forty-run candidate summary; no 80-variant assumption, complete-for-family claim, or claim that these originals enter the new route. Engine and structural owners establish new-route/common-exit behavior.',
            source_only_guards=359, conformance_owners=30, intl_recipes=15, product_interpreter_audit=audit,
            formatting=dict(changed_rust='Five changed Rust files; exact source hashes are recorded. Native/source-guard evidence does not replace formatting evidence.',
                            full_workspace='Inherited 17 pre-existing file failures remain unresolved; no full-workspace formatting or release acceptance claim.'),
        ),
        failures_preserved=[dict(
            kind='foreign-realm-host-hook-fixture', receipt=native_name, repair_receipt=repair_name,
            failing_test=repaired_test, failed_binary=failed_binary,
            before_source=repair_proof['before'], after_source=repair_proof['after'],
            reason='The direct Engine fixture referenced $262.createRealm, but this Test262 host surface installs __scriptwCreateRealm; the separate Test262 harness owns the $262 wrapper. Only that call is corrected. Original failure, binary identity and all build/test streams remain evidence; failed native payload is excluded from the inert archive.',
        )],
        measurement=dict(
            plan=read('measurement-plan.json'), cohort_contexts=contexts, cohorts=table,
            complete_cohort_reports=cohorts, raw_stream_index=raw_index,
            startup_controls=startup_controls, resources=resources,
            targeted_controls=targeted_controls, targeted_extra_controls=targeted_extra_controls,
            scaling_controls=scaling_controls,
            optional_scaling_controls=scaling,
            boundaries='Unchanged17 initial ABBA and confirmation BAAB compare affine against accepted6764. Original compiler-disabled fresh Store/Realm, ordinary runtime_baseline, strict-derived retained invocation and Node fresh-context references remain distinct. Every original raw identity/output/harness/resource/startup check is retained. Additional source-generic scaling/admission controls remain separate original/ordinary diagnostics and cannot replace the original gate.',
            memory='Process smaps RSS with Store alive is not live JavaScript bytes, peak memory or per-owner attribution. Whole-child peaks include setup/loading/compiler and identity hashing. A smaller recurrence/backedge count establishes neither a bootstrap-floor reduction nor GC allocation saving; retained ~ms and original ~us boundaries cannot be subtracted.',
            resource_policy='Inherited 32GiB; CPU0 serial measurements/tests, quota-bound build CPUs, cache512/2GiB. Swap/group-OOM flags are inherited, not local4GiB guarantees.',
        ),
        diagnostics=diagnostics,
        limits=[
            'Only 35 unique selected native checks through the documented exact-test continuation and the forty original Test262 files are this source coverage; no fresh full final-fixture Engine or rejected-source checks are adopted.',
            'The selected for files are a subset; full pinned Test262 status and published benchmark graphs remain unchanged.',
            'Every-case V8/Scriptc time and RSS parity and full release acceptance remain open.',
            'All unchanged original/retained/ordinary/V8 controls, startup and slower observations remain visible; extra scaling fixtures do not replace them.',
            'R/P code ownership is read from actual frozen metadata/diagnostics. Restoring parent runtime source alone does not prove identical emitted R/native bytes.',
            'This is a bounded CPU experiment with no intended ABI/global/GC layout change or allocation-count reduction; actual P native size may grow.',
        ],
    )
    (OUT / 'report-core.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(dict(native_selected_passes=native_passes, test262_original_files=40,
                          test262_actual_variants=test262_executions, candidate_fingerprint=candidate_fingerprint,
                          workloads=len(table), cohorts=list(cohorts), output='report-core.json'), indent=2), flush=True)


if __name__ == '__main__':
    main()


