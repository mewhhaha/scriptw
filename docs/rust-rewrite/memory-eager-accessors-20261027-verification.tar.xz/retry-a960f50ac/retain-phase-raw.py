"""Retain inert diagnostic-v2 raw data losslessly; no component analysis."""
import argparse,hashlib,json,shutil
from pathlib import Path
BASE=Path(__file__).resolve().parent
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('run')
parser.add_argument('--source',required=True)
parser.add_argument('--diagnostic',type=Path)
parser.add_argument('--scored-report',type=Path)
args=parser.parse_args()
RUN=args.run;SOURCE=args.source
assert RUN=='40552965169' and SOURCE=='a960f50acea8bd3a1de0a2c391bbb09b88f2ee4d'
source=args.diagnostic or BASE.parent/f'github-{RUN}/precompiled-mapping-diagnostic-unscored'
report=json.loads((source/'report.json').read_text())
assert report['schema']=='scriptw-precompiled-mapping-diagnostic-v2' and report['scored'] is False
assert report['source_commit']==SOURCE
bindings=json.loads((BASE/'source-bindings-computed.json').read_text())
assert report['source_fingerprint']==next(r['source_fingerprint'] for r in bindings if r['revision']==SOURCE and not r['extra_ignored_regress_lock'])
scored=args.scored_report or BASE.parent/f'github-{RUN}/precompiled-measurements/precompiled-evidence/report.json'
def sha(path):
 with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
assert sha(scored)==report['scored_report_sha256']
# Retain failures as well as successful captures; status is reported separately.
target=BASE/f'ci-unscored-{RUN}';target.mkdir(exist_ok=False)
files=[];total=0
for path in sorted(source.rglob('*')):
 assert not path.is_symlink()
 if not path.is_file():continue
 rel=path.relative_to(source);assert '..' not in rel.parts
 size=path.stat().st_size;total+=size;assert size<=16*1024**2 and total<=128*1024**2
 with path.open('rb') as stream:assert not stream.read(8).startswith((b'\x7fELF',b'MZ',b'SCRWEP01',b'SCRWEP02',b'SCRWWA01'))
 dest=target/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(path,dest)
 assert sha(path)==sha(dest)
 files.append(dict(path=rel.as_posix(),bytes=size,sha256=sha(dest)))
phases=['after_transport_drop','after_instantiate','after_execution','after_store_drop']
cases=report['cases'];valid=report['status']=='captured' and len(cases)==4
valid=valid and {(r['runtime'],r['file']) for r in cases}=={(rt,name) for rt in ('scriptw','scriptc') for name in ('integer.js','retained-objects.js')}
for case in cases:
 valid=valid and case.get('status')=='captured' and case.get('phase_attribution_validated') is True and case.get('endpoint_stdout_validated') is True
 snaps=case.get('snapshots',[]);valid=valid and [s['phase'] for s in snaps]==phases
 for index,snapshot in enumerate(snaps,1):
  assert snapshot['sequence']==index and snapshot['observation_index']==16 and snapshot['nonce']==case['nonce']
  folder=source/(case['runtime']+'-'+case['file']);name=snapshot['path'];assert Path(name).name==name
  raw=folder/name;assert raw.stat().st_size==snapshot['bytes']<=2*1024**2 and sha(raw)==snapshot['sha256']
record=dict(source_commit=SOURCE,run=RUN,scored=False,status=report['status'],phase_attribution_complete=valid,files=files,total_bytes=total,
 cases=[dict(runtime=c['runtime'],file=c['file'],status=c['status'],phase_attribution_validated=c.get('phase_attribution_validated'),snapshots=len(c.get('snapshots',[])),error=c.get('error')) for c in cases],
 interpretation='Unscored acknowledged phase captures; barriers alter diagnostic history and total timings. Component analysis is separate; no canonical report mutation.')
(BASE/f'ci-unscored-retention-{RUN}.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:v for k,v in record.items() if k!='files'},indent=2))
if not valid:raise SystemExit('Diagnostic phase captures unavailable/incomplete; raw retained')
