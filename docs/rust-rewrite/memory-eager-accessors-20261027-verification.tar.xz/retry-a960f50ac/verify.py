from datetime import datetime,timezone
import hashlib,json,os,subprocess,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'scripts'))
from limited_verification import require_kernel_budget,kernel_group
import argparse
arguments=argparse.ArgumentParser(description='Verify the complete eager-accessor batch; preserve failures and exact e7 inventories.')
arguments.add_argument('--expected-source',required=True)
arguments.add_argument('--required-repair-source',required=True)
options=arguments.parse_args()
assert options.expected_source=='a960f50acea8bd3a1de0a2c391bbb09b88f2ee4d'
assert options.required_repair_source=='54231ef4d3eb1fa6e1a39f34698d3d0f3668d1b1'
os.environ['SCRIPTW_EXPECTED_SOURCE']=options.expected_source
os.environ['SCRIPTW_REQUIRED_REPAIR_SOURCE']=options.required_repair_source
os.environ['CARGO_BUILD_JOBS']='1'
os.environ['RUST_TEST_THREADS']='1'

require_kernel_budget(4*1024**3);assert sorted(os.sched_getaffinity(0))==[0]
SOURCE=os.environ['SCRIPTW_EXPECTED_SOURCE']
assert SOURCE=='a960f50acea8bd3a1de0a2c391bbb09b88f2ee4d'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==SOURCE
assert os.environ['SCRIPTW_REQUIRED_REPAIR_SOURCE']=='54231ef4d3eb1fa6e1a39f34698d3d0f3668d1b1'
assert subprocess.run(['git','merge-base','--is-ancestor',os.environ['SCRIPTW_REQUIRED_REPAIR_SOURCE'],SOURCE],cwd=ROOT).returncode==0
assert subprocess.run(['git','merge-base','--is-ancestor','4de65ce640845e82fbde912a5c71025ab9d583c1',SOURCE],cwd=ROOT).returncode==0
assert os.environ['SCRIPTW_MODULE_MEMORY_CACHE_ENTRIES']=='1'
assert os.environ['SCRIPTW_MODULE_MEMORY_CACHE_LIMIT_BYTES']==str(64*1024**2)

group=kernel_group()
def budget():return {k:(group/k).read_text().strip() for k in ['memory.max','memory.swap.max','memory.oom.group','memory.peak','memory.events']}
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
assert not (BASE/'verification.json').exists(), 'fresh evidence directory required'
predecessor=BASE.parent
prior_check=json.loads((predecessor/'check.json').read_text())
prior_batch=json.loads((predecessor/'verification.json').read_text())
assert prior_check['source_commit']==prior_batch['source_commit']=='4de65ce640845e82fbde912a5c71025ab9d583c1'
assert not prior_check['complete'] and prior_check['exit_code']==101
assert not prior_batch['complete'] and 'after' not in prior_batch
assert [(r['label'],r['exit_code'])for r in prior_batch['commands']]==[('cheap-main-driver',0),('cargo-check-driver',101)]
assert not (predecessor/'native').exists() and not (predecessor/'conformance').exists()
for row in prior_batch['commands']:
 for key in ('stdout','stderr'):assert sha(predecessor/row[key])==row[key+'_sha256']
assert sha(predecessor/'cargo-check.jsonl')==prior_check['stdout_sha256']
assert sha(predecessor/'cargo-check.stderr')==prior_check['stderr_sha256']
predecessor_record=dict(source_commit=prior_check['source_commit'],verification='../verification.json',verification_sha256=sha(predecessor/'verification.json'),check='../check.json',check_sha256=sha(predecessor/'check.json'),native_executed=False,test262_executed=False,after_counters_available=False)

report=dict(predecessor_failed_attempt=predecessor_record,required_repair_source=options.required_repair_source,source_commit=SOURCE,complete=False,started_at=datetime.now(timezone.utc).isoformat(),before=budget(),cpu_affinity=sorted(os.sched_getaffinity(0)),commands=[])
def save():(BASE/'verification.json').write_text(json.dumps(report,indent=2)+'\n')
build=ROOT/'target/performance-work-20261024/build'
plan=[('cheap-main-driver',[sys.executable,'-B',str(BASE/'cheap-main-current.py')]),('cargo-check-driver',[sys.executable,'-B',str(BASE/'check.py')]),('native-driver',[sys.executable,'-B',str(BASE/'native.py')]),('cargo-products',['cargo','build','--locked','--offline','--release','--jobs','1','--target-dir',str(build),'-p','scriptw-cli','--bin','scriptw','--example','compiler_precompiled_baseline','--message-format=json']),('test262-driver',[sys.executable,'-B',str(BASE/'test262.py')]),('test262-unicode-driver',[sys.executable,'-B',str(BASE/'test262.py'),'--unicode'])]
save()
for label,args in plan:
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==SOURCE
 assert not subprocess.check_output(['git','diff','--binary','HEAD','--','crates','vendor','scripts','Cargo.toml','Cargo.lock'],cwd=ROOT)
 print(label,'started',flush=True);out=BASE/(label+('.jsonl' if label=='cargo-products' else '.stdout'));err=BASE/(label+'.stderr');row=dict(label=label,command=args,stdout=out.name,stderr=err.name);report['commands'].append(row);save();start=time.monotonic()
 with out.open('xb') as stdout,err.open('xb') as stderr:r=subprocess.run(args,cwd=ROOT,stdout=stdout,stderr=stderr,timeout=10800)
 row.update(exit_code=r.returncode,seconds=time.monotonic()-start,stdout_sha256=sha(out),stderr_sha256=sha(err));save();print(label,'finished',r.returncode,flush=True)
 if r.returncode:
  print(err.read_text()[-12000:],flush=True);raise SystemExit(r.returncode)
report.update(complete=True,finished_at=datetime.now(timezone.utc).isoformat(),after=budget());save();print('verification complete',flush=True)
