"""Private post-gate prose publisher; canonical paired report must already be published."""
import hashlib,json,sys
from pathlib import Path
BASE=Path(__file__).resolve().parent;ROOT=BASE.parents[1];DEST=ROOT/'docs/rust-rewrite';STEM='memory-eager-accessors-20261027'
sys.path.insert(0,str(ROOT/'scripts'))
import precompiled_comparison as p

def sha(path):
 with path.open('rb')as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
record=json.loads((DEST/(STEM+'.json')).read_text());source=record['verified_source_commit'];measured_source=record['measured_source_commit']
assert source=='00fcf97fbffde8137a67d6ed7ed4803e86384ef1' and record['native']['passed_disjoint_scopes']==4881
assert record['test262']['total']==2365 and record['supplemental_unicode']['total']==16
assert sha(DEST/record['archive']['file'])==record['archive']['sha256']
report,rows=p.load_report(DEST/'precompiled-comparison.json',DEST/'precompiled-comparison.tar.gz')
assert report['source_commit']==measured_source and len(rows)==17
clean=next(row for row in record['source_binding_equivalence']['rows']if row['revision']==measured_source and not row['extra_ignored_regress_lock'])
assert report['source_fingerprint']==clean['source_fingerprint']
for metric,chart in p.CHARTS.items():assert p.render(report,rows,metric,BASE/f'preview-publication-{metric}.png')==(DEST/'assets'/chart['filename']).read_bytes()
ratios=[r['runtimes']['scriptw']['rss_mib']/r['runtimes']['scriptc']['rss_mib']for r in rows];selected={r['file']:r for r in rows};run=record['measurement']['run']
lines=[f'**Measured 2026-10-27 on one GitHub Actions runner**, compiler `{measured_source[:9]}`.',
'The [precompiled benchmark workflow](docs/rust-rewrite/contracts/precompiled-comparison.md)',
'compares Scriptw and Scriptc in the same Wasmtime executable. Compilation runs',
'in separate producer processes; measured consumers disable compilation and use',
'identical native optimization and runtime settings. Both passed the original',
'checksums on **17/17 workloads** across two rounds.',
f"Scriptw's median post-execution process RSS remains **{min(ratios):.3f}–{max(ratios):.3f}× Scriptc's**:",'',
'| Workload | Scriptw RSS | Scriptc RSS |','| --- | ---: | ---: |']
for file,label in [('integer.js','Integer'),('objects.js','Objects'),('retained-objects.js','Retained objects')]:
 r=selected[file];lines.append(f"| {label} | {r['runtimes']['scriptw']['rss_mib']:.1f} MiB | {r['runtimes']['scriptc']['rss_mib']:.1f} MiB |")
lines+=['','These are medians of 14 measured samples per runtime and workload after ten',
'checked warmups per round, with each Store still alive. RSS includes code,',
'runtime and allocator history; it is neither live JS heap nor peak memory.',
'Scriptc parity remains open. Eager native accessors now share a typed allocation',
'tail while retaining fresh function identity, defining Realm and source-string',
'materialization order. Cross-runner comparisons do not establish causal savings.','',
f'[Verification](docs/rust-rewrite/{STEM}.md): **4,881 native cases, 2,365 original',
'pinned Test262 executions and 16 separate Unicode executions passed**. The',
'supplemental IDs are disjoint. The initial test-only compilation error, later inspection-test failure and',
'repair are retained; measured and verified compiler-input closures are bound.',
'Verification used one CPU, a 4-GiB process-tree cap, no swap and bounded module',
'retention. Original Test262 executions ran in fresh batches of at most 16.','',
'[Prior phase-aligned method checkpoint](docs/rust-rewrite/memory-phase-boundaries-20261027.md):',
'paused maps remain unscored and separate from every canonical graph. They do',
'not establish heap ownership, peak memory or causal function attribution.','',
'[Execution timing](docs/rust-rewrite/assets/precompiled-execution.svg) ·',
f'[CI run](https://github.com/mewhhaha/scriptw/actions/runs/{run}).','']
readme=ROOT/'README.md';old=readme.read_text();start=old.index('**Measured 2026-10-27 on one GitHub Actions runner**, compiler `38c25942b`.');end=old.index('\n## Benchmarks',start)
new=old[:start]+'\n'.join(lines)+old[end:];assert new[:start]==old[:start] and new[new.index('\n## Benchmarks'):]==old[end:]
checkpoint=DEST/(STEM+'.md');assert not checkpoint.exists()
static=record['static_code']
assert static['source_commit']==measured_source and static['scored'] is False
text=f'''# Eager accessor construction checkpoint

Verified compiler `{source}`; matched CI compiler `{measured_source}`, [run {run}](https://github.com/mewhhaha/scriptw/actions/runs/{run}). Runtime layout 28.

Strict ordinary noncanonical standard accessors retain eager fresh function construction. A checked plan proves entry identity, metadata defaults and runtime-owned source ordinal. Header and ExecutableCode allocation precede the shared tail; Context allocation still precedes source-string resolution, FunctionObject allocation and cycle closure. Existing metadata publication remains after construction. Canonical, captured and nonuniform factories retain their existing paths.

The [verification record]({STEM}.json) retains exact inventories: 4,881 native cases across 19 targets, 2,365 original pinned executions and 16 disjoint Unicode executions passed. This is a selected conformance checkpoint, not a full pinned-suite refresh. Original failed test-only compilation and the subsequent 503-pass/1-fail inspection-test attempt remain retained. Eighteen unchanged native binaries were reused with frozen hashes; the repaired AOT target was rebuilt. No missing after counters are synthesized. The excluded inspection-test repair and clean/local compiler-input fingerprints bind the verified and measured sources. Local verification used one CPU, a 4-GiB process-tree cap, no swap and bounded caches; selected cases ran in fresh batches of at most 16.

The canonical paired cohort passes original checksums on all 17 workloads, with two rounds, ten warmups and seven measured samples per round. Both consumers disable compilation and use the same Wasmtime executable and settings. Exact scored values are in [the paired report](precompiled-comparison.json) and canonical graphs. Comparing runs on different machines cannot establish causal memory savings. Scriptc parity remains open.

Static inspection of the owned Cargo Portable R artifacts ([source-bound facts and retained symbol streams]({STEM}.json)) records RealmInitializeIntrinsics at 888,703 → 765,194 native bytes (−123,509), with the new shared helper at 783 bytes. The raw package decreased by 32,919 bytes and the native ELF by 157,152 bytes. These are static artifact/code extents, not RSS, execution costs or evidence of causal resident-memory savings.

Any paused lifecycle captures retained with this batch are unscored; the [phase methodology](memory-phase-boundaries-20261027.md) remains separate from canonical graphs. Code/path mapping groups do not prove heap ownership, peak memory or causes.

The bounded lossless verification archive excludes executables and serialized native images. Its exact member inventory, byte lengths, SHA-256 hashes and roundtrip limits are recorded beside the source-bound reports.
'''
pending_intro="order. Verification and measurements for this pass are pending; see the\n[allocation contract](docs/rust-rewrite/contracts/eager-intrinsic-accessors.md)."
assert pending_intro in new
new=new.replace(pending_intro,"order. The selected verification and matched measurements are recorded in the\n[checkpoint](docs/rust-rewrite/"+STEM+".md) and the\n[allocation contract](docs/rust-rewrite/contracts/eager-intrinsic-accessors.md).",1)
contract=DEST/'contracts/eager-intrinsic-accessors.md';contract_text=contract.read_text()
pending_contract="Whole-batch compilation, semantic verification and matched memory measurements\nremain pending. Sharing code does not establish resident-memory or timing savings."
assert pending_contract in contract_text
contract_text=contract_text.replace(pending_contract,"The [source-bound checkpoint](../"+STEM+".md) records successful whole-batch compilation, 4,881 native cases, 2,365 original selected Test262 executions and 16 disjoint Unicode executions, plus a matched 17-workload CI cohort. This is not a full pinned-suite refresh. Cross-runner comparisons do not establish causal resident-memory or timing savings.",1)
checkpoint.write_text(text);readme.write_text(new);contract.write_text(contract_text);print(json.dumps(dict(source=source,measured_source=measured_source,checkpoint=checkpoint.name)))
