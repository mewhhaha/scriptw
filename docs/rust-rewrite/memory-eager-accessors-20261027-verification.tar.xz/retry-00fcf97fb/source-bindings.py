"""Compare exact Git-tree compiler inputs with captured CI/local identities."""
import hashlib,json,re,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
ROOTS=['Cargo.toml','Cargo.lock','crates/scriptw-front','crates/scriptw-ir','crates/scriptw-aot-wasm','crates/scriptw-runtime','crates/scriptw-runtime-image','crates/scriptw-intl','crates/scriptw-intl-build-data','crates/scriptw-engine/Cargo.toml','crates/scriptw-engine/src','crates/scriptw-engine/build.rs','crates/scriptw-engine/compiler_fingerprint.rs','vendor']
def one(args):return subprocess.check_output(args,cwd=ROOT)
def fingerprint(revision,extra=False):
 source=one(['git','show',revision+':crates/scriptw-engine/compiler_fingerprint.rs']).decode()
 block=source.split('const TEST_ONLY_INPUTS: &[&str] = &[',1)[1].split('];',1)[0]
 excluded=re.findall(r'^\s*"([^"]+)",',block,re.M)
 items=[]
 for raw in one(['git','ls-tree','-r','-z',revision,'--',*ROOTS]).split(b'\0'):
  if not raw:continue
  fields,path=raw.split(b'\t',1);mode,kind,oid=fields.decode().split();path=path.decode()
  if any(path==x or path.startswith(x+'/') for x in excluded):continue
  assert kind=='blob' and mode=='100644',(mode,kind,path)
  items.append((path,oid))
 if extra:items.append(('vendor/regress-0.10.5/Cargo.lock',None))
 digest=hashlib.sha256(b'scriptw-program-cache-compiler-v3');total=0
 child=subprocess.Popen(['git','cat-file','--batch'],cwd=ROOT,stdin=subprocess.PIPE,stdout=subprocess.PIPE)
 try:
  for path,oid in sorted(items,key=lambda x:tuple(x[0].split('/'))):
   if oid is None:data=(ROOT/path).read_bytes()
   else:
    child.stdin.write((oid+'\n').encode());child.stdin.flush();header=child.stdout.readline().split();assert header[:2]==[oid.encode(),b'blob'];length=int(header[2]);data=child.stdout.read(length);assert len(data)==length and child.stdout.read(1)==b'\n'
   label=path.encode();digest.update(len(label).to_bytes(8,'little'));digest.update(label);digest.update(len(data).to_bytes(8,'little'));digest.update(data);total+=len(data)
 finally:child.stdin.close();child.stdout.close();assert child.wait()==0
 return dict(revision=one(['git','rev-parse',revision]).decode().strip(),extra_ignored_regress_lock=extra,source_fingerprint=digest.hexdigest(),files=len(items),bytes=total)
assert one(['git','rev-parse','HEAD']).decode().strip()=='00fcf97fbffde8137a67d6ed7ed4803e86384ef1'
assert (ROOT/'vendor/regress-0.10.5/Cargo.lock').is_file()
import argparse
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--source',required=True)
args=parser.parse_args()
assert args.source=='00fcf97fbffde8137a67d6ed7ed4803e86384ef1'
rows=[fingerprint(rev,extra) for rev in ['4de65ce640845e82fbde912a5c71025ab9d583c1','a960f50acea8bd3a1de0a2c391bbb09b88f2ee4d',args.source] for extra in [False,True]]
for extra in (False,True):
 selected=[r for r in rows if r['extra_ignored_regress_lock']==extra]
 assert len({(r['source_fingerprint'],r['files'],r['bytes'])for r in selected})==1
(OUT/'source-bindings-closure-equivalence.json').write_text(json.dumps(dict(test_only_repair=True,rows=rows),indent=2)+'\n')
current=[r for r in rows if r['revision']==args.source]
(OUT/'source-bindings-computed.json').write_text(json.dumps(current,indent=2)+'\n')
print(json.dumps(dict(test_only_repair=True,rows=rows),indent=2))
