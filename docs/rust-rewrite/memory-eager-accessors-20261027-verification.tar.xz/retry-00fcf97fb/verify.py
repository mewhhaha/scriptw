from datetime import datetime,timezone
import hashlib,json,os,re,subprocess,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'scripts'))
from limited_verification import require_kernel_budget,kernel_group
from native_test_protocol import result_summaries
import argparse
arguments=argparse.ArgumentParser(description='Verify the complete eager-accessor batch; preserve failures and exact e7 inventories.')
arguments.add_argument('--expected-source',required=True)
arguments.add_argument('--required-repair-source',required=True)
options=arguments.parse_args()
assert options.expected_source=='00fcf97fbffde8137a67d6ed7ed4803e86384ef1'
assert options.required_repair_source=='54231ef4d3eb1fa6e1a39f34698d3d0f3668d1b1'
os.environ['SCRIPTW_EXPECTED_SOURCE']=options.expected_source
os.environ['SCRIPTW_REQUIRED_REPAIR_SOURCE']=options.required_repair_source
os.environ['CARGO_BUILD_JOBS']='1'
os.environ['RUST_TEST_THREADS']='1'

require_kernel_budget(4*1024**3);assert sorted(os.sched_getaffinity(0))==[0]
SOURCE=os.environ['SCRIPTW_EXPECTED_SOURCE']
assert SOURCE=='00fcf97fbffde8137a67d6ed7ed4803e86384ef1'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==SOURCE
assert os.environ['SCRIPTW_REQUIRED_REPAIR_SOURCE']=='54231ef4d3eb1fa6e1a39f34698d3d0f3668d1b1'
assert subprocess.run(['git','merge-base','--is-ancestor',os.environ['SCRIPTW_REQUIRED_REPAIR_SOURCE'],SOURCE],cwd=ROOT).returncode==0
assert subprocess.run(['git','merge-base','--is-ancestor','4de65ce640845e82fbde912a5c71025ab9d583c1',SOURCE],cwd=ROOT).returncode==0
assert subprocess.run(['git','merge-base','--is-ancestor','a960f50acea8bd3a1de0a2c391bbb09b88f2ee4d',SOURCE],cwd=ROOT).returncode==0
assert os.environ['SCRIPTW_MODULE_MEMORY_CACHE_ENTRIES']=='1'
assert os.environ['SCRIPTW_MODULE_MEMORY_CACHE_LIMIT_BYTES']==str(64*1024**2)

group=kernel_group()
def budget():return {k:(group/k).read_text().strip() for k in ['memory.max','memory.swap.max','memory.oom.group','memory.peak','memory.events']}
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
assert not (BASE/'verification.json').exists(), 'fresh evidence directory required'
predecessor=BASE.parent/'retry-a960f50ac'
prior_check=json.loads((predecessor/'check.json').read_text())
prior_batch=json.loads((predecessor/'verification.json').read_text())
prior_native=json.loads((predecessor/'native/report.json').read_text())
assert prior_check['source_commit']==prior_batch['source_commit']==prior_native['source_commit']=='a960f50acea8bd3a1de0a2c391bbb09b88f2ee4d'
assert prior_check['complete'] and prior_check['exit_code']==0
assert not prior_batch['complete'] and 'after' not in prior_batch
assert not prior_native['complete'] and 'after' not in prior_native
assert not (predecessor/'conformance').exists() and not (predecessor/'conformance-unicode').exists()
assert [(r['label'],r['exit_code'])for r in prior_batch['commands']]==[('cheap-main-driver',0),('cargo-check-driver',0),('native-driver',1)]
for row in prior_batch['commands']:
 for key in ('stdout','stderr'):assert sha(predecessor/row[key])==row[key+'_sha256']
for row in prior_native['commands']:
 for key in ('stdout','stderr'):assert sha(predecessor/'native'/row[key])==row[key+'_sha256']
assert sha(predecessor/'cargo-check.jsonl')==prior_check['stdout_sha256']
assert sha(predecessor/'cargo-check.stderr')==prior_check['stderr_sha256']
completed=[row for row in prior_native['scopes'] if row['complete']]
assert len(completed)==4 and sum(row['passed']for row in completed)==423
failures=[row for row in prior_native['commands']if row.get('exit_code')!=0]
assert len(failures)==1 and failures[0]['label']=='scriptw-aot-wasm-scriptw_aot_wasm-part-000' and failures[0]['exit_code']==101
failure_text=(predecessor/'native'/failures[0]['stdout']).read_text()
assert result_summaries(failure_text)==[('FAILED','503','1','0','0','0')]
assert re.findall(r'^test (.*?) \.\.\. FAILED$',failure_text,re.M)==['tests::bootstrap_compact_metadata::native_bootstrap_allocates_compact_metadata_without_eager_property_records']
first=BASE.parent
first_check=json.loads((first/'check.json').read_text())
first_batch=json.loads((first/'verification.json').read_text())
assert first_check['source_commit']==first_batch['source_commit']=='4de65ce640845e82fbde912a5c71025ab9d583c1'
assert not first_check['complete'] and first_check['exit_code']==101
assert not first_batch['complete'] and 'after' not in first_batch
assert not(first/'native').exists() and not(first/'conformance').exists()
assert prior_batch['predecessor_failed_attempt']['verification_sha256']==sha(first/'verification.json')
assert prior_batch['predecessor_failed_attempt']['check_sha256']==sha(first/'check.json')
closure=json.loads((BASE/'source-bindings-closure-equivalence.json').read_text())
assert closure['test_only_repair'] and len(closure['rows'])==6
for lock in (False,True):
 rows=[row for row in closure['rows']if row['extra_ignored_regress_lock'] is lock]
 assert {row['revision']for row in rows}=={'4de65ce640845e82fbde912a5c71025ab9d583c1','a960f50acea8bd3a1de0a2c391bbb09b88f2ee4d',SOURCE}
 assert len({(row['source_fingerprint'],row['files'],row['bytes'])for row in rows})==1
predecessor_record=dict(source_commit=prior_check['source_commit'],verification='../retry-a960f50ac/verification.json',verification_sha256=sha(predecessor/'verification.json'),check='../retry-a960f50ac/check.json',check_sha256=sha(predecessor/'check.json'),native='../retry-a960f50ac/native/report.json',native_sha256=sha(predecessor/'native/report.json'),native_executed=True,completed_native_scopes=4,completed_native_passes=423,failed_aot_passes=503,failed_aot_failures=1,test262_executed=False,after_counters_available=False,first_failed_attempt=prior_batch['predecessor_failed_attempt'])

report=dict(source_closure_equivalence_sha256=sha(BASE/'source-bindings-closure-equivalence.json'),measured_source_commit='a960f50acea8bd3a1de0a2c391bbb09b88f2ee4d',predecessor_failed_attempt=predecessor_record,required_repair_source=options.required_repair_source,source_commit=SOURCE,complete=False,started_at=datetime.now(timezone.utc).isoformat(),before=budget(),cpu_affinity=sorted(os.sched_getaffinity(0)),commands=[])
def save():(BASE/'verification.json').write_text(json.dumps(report,indent=2)+'\n')
build=ROOT/'target/performance-work-20261024/build'
plan=[('cheap-main-driver',[sys.executable,'-B',str(BASE/'cheap-main-current.py')]),('cargo-check-driver',[sys.executable,'-B',str(BASE/'check.py')]),('native-driver',[sys.executable,'-B',str(BASE/'native.py')]),('cargo-products',['cargo','build','--locked','--offline','--release','--jobs','1','--target-dir',str(build),'-p','scriptw-cli','--bin','scriptw','--example','compiler_precompiled_baseline','--message-format=json']),('test262-driver',[sys.executable,'-B',str(BASE/'test262.py')]),('test262-unicode-driver',[sys.executable,'-B',str(BASE/'test262.py'),'--unicode'])]
save()
for label,args in plan:
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==SOURCE
 assert not subprocess.check_output(['git','diff','--binary','HEAD','--','crates','vendor','scripts','Cargo.toml','Cargo.lock'],cwd=ROOT)
 print(label,'started',flush=True);out=BASE/(label+('.jsonl' if label=='cargo-products' else '.stdout'));err=BASE/(label+'.stderr');row=dict(label=label,command=args,stdout=out.name,stderr=err.name);report['commands'].append(row);save();start=time.monotonic()
 with out.open('xb') as stdout,err.open('xb') as stderr:r=subprocess.run(args,cwd=ROOT,stdout=stdout,stderr=stderr,timeout=10800)
 row.update(exit_code=r.returncode,seconds=time.monotonic()-start,stdout_sha256=sha(out),stderr_sha256=sha(err));save();print(label,'finished',r.returncode,flush=True)
 if r.returncode:
  print(err.read_text()[-12000:],flush=True);raise SystemExit(r.returncode)
report.update(complete=True,finished_at=datetime.now(timezone.utc).isoformat(),after=budget());save();print('verification complete',flush=True)
