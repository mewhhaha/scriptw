"""Repeat exact 2365 pinned executions in fresh batches of at most 16; no status publish."""
from datetime import datetime,timezone
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parents[2]
BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'scripts'))
from limited_verification import require_kernel_budget,kernel_group
from precompiled_comparison import digest
require_kernel_budget(4*1024**3)
assert sorted(os.sched_getaffinity(0))==[0]
SOURCE=os.environ['SCRIPTW_EXPECTED_SOURCE']
assert SOURCE=='4de65ce640845e82fbde912a5c71025ab9d583c1'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==SOURCE
assert os.environ['SCRIPTW_REQUIRED_REPAIR_SOURCE']=='54231ef4d3eb1fa6e1a39f34698d3d0f3668d1b1'
assert subprocess.run(['git','merge-base','--is-ancestor',os.environ['SCRIPTW_REQUIRED_REPAIR_SOURCE'],SOURCE],cwd=ROOT).returncode==0
assert os.environ['SCRIPTW_MODULE_MEMORY_CACHE_ENTRIES']=='1'
assert os.environ['SCRIPTW_MODULE_MEMORY_CACHE_LIMIT_BYTES']==str(64*1024**2)

assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==SOURCE
build=[json.loads(x) for x in (BASE/'cargo-products.jsonl').read_text().splitlines()]
assert build[-1]==dict(reason='build-finished',success=True)
records=[x for x in build if x.get('reason')=='compiler-artifact' and x.get('executable')
         and x['target']['name']=='scriptw' and x['target']['kind']==['bin'] and not x['profile']['test']]
assert len(records)==1
unicode_only=sys.argv[1:]==['--unicode']
assert not sys.argv[1:] or unicode_only, 'only --unicode is supported'
output=BASE/('conformance-unicode' if unicode_only else 'conformance')
output.mkdir(exist_ok=False)
compiler=output/'compiler'
shutil.copy2(records[0]['executable'],compiler)
assert digest(compiler)==digest(records[0]['executable']) and compiler.stat().st_nlink==1
group=kernel_group()
def budget():
 return {k:(group/k).read_text().strip() for k in ('memory.max','memory.swap.max','memory.oom.group','memory.peak','memory.events')}
def stamp():return datetime.now(timezone.utc).isoformat()
report=dict(source_commit=SOURCE,complete=False,started_at=stamp(),commands=[],before=budget(),
 compiler=dict(path=str(compiler),sha256=digest(compiler),cargo_producer=records[0]),
 scope='Exact original pinned Function/AsyncFunction/GeneratorFunction/AsyncGeneratorFunction, eval/ShadowRealm, Array length/push/sort/join, Proxy and Object/Reflect descriptor executions. Not a full-suite status refresh.')
def save():(output/'report.json').write_text(json.dumps(report,indent=2)+'\n')
def invoke(label,args,timeout=3600):
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==SOURCE
 assert not subprocess.check_output(['git','diff','--binary','HEAD','--','crates','vendor','scripts','Cargo.toml','Cargo.lock'],cwd=ROOT)
 event=dict(label=label,command=[str(compiler),'--jobs','1',*map(str,args)],started_at=stamp(),
            stdout=label+'.stdout',stderr=label+'.stderr')
 report['commands'].append(event);save()
 started=time.monotonic()
 with (output/event['stdout']).open('xb') as out,(output/event['stderr']).open('xb') as err:
  process=subprocess.Popen(event['command'],cwd=ROOT,stdout=out,stderr=err,start_new_session=True)
  try:code=process.wait(timeout=timeout)
  except BaseException:
   if process.poll() is None:os.killpg(process.pid,signal.SIGKILL)
   process.wait();raise
 event.update(returncode=code,finished_at=stamp(),seconds=time.monotonic()-started,
  stdout_sha256=digest(output/event['stdout']),stderr_sha256=digest(output/event['stderr']))
 save()
 assert code==0,label+' failed; original streams retained'
 return (output/event['stdout']).read_text()
identity=json.loads(invoke('identity',['compiler-identity']))
assert identity['source_revision']==dict(kind='git-commit',commit=SOURCE)
assert identity['executable_sha256']==report['compiler']['sha256']
report['compiler']['identity']=identity;save()
suite=ROOT/'test262/vendor/test262'
filters=[
 'built-ins/Function/',
 'built-ins/AsyncFunction/',
 'built-ins/GeneratorFunction/',
 'built-ins/AsyncGeneratorFunction/',
 'built-ins/eval/',
 'built-ins/ShadowRealm/',
 'built-ins/Array/prototype/push/',
 'built-ins/Array/length/',
 'built-ins/Proxy/defineProperty/',
 'built-ins/Array/prototype/sort/',
 'built-ins/Array/prototype/join/',
 'built-ins/Proxy/getOwnPropertyDescriptor/',
 'built-ins/Proxy/get/',
 'built-ins/Proxy/set/',
 'built-ins/Proxy/has/',
 'built-ins/Proxy/deleteProperty/',
 'built-ins/Reflect/set/',
 'built-ins/Object/getOwnPropertyDescriptor/',
 'built-ins/Reflect/getOwnPropertyDescriptor/',
]
if unicode_only:
 filters=['built-ins/RegExp/property-escapes/generated/ASCII.js', 'built-ins/RegExp/property-escapes/generated/Script_-_Greek.js', 'built-ins/RegExp/property-escapes/loose-matching-01.js', 'built-ins/RegExp/property-escapes/non-existent-property-value-Script.js', 'built-ins/RegExp/unicodeSets/generated/character-property-escape-difference-property-of-strings-escape.js', 'built-ins/RegExp/unicodeSets/generated/character-class-intersection-character-property-escape.js', 'built-ins/RegExp/unicodeSets/generated/property-of-strings-escape-difference-character-property-escape.js', 'built-ins/RegExp/unicodeSets/generated/character-class-union-property-of-strings-escape.js']
 report['scope']='Separate bounded original Unicode property-escape selection; code-point properties, Script, invalid property spellings, and v-mode code-point/string-property set operations. No overlap with original 2365.'
 selected_paths=[suite/'test'/pattern for pattern in filters]
 assert all(path.is_file() for path in selected_paths)
 report['selected_source_files']=[dict(path=str(path.relative_to(suite)),sha256=digest(path),bytes=path.stat().st_size) for path in selected_paths]
selected=[]
for index,pattern in enumerate(filters):
 text=invoke(f'inventory-{index:02d}',['test262','list-all',pattern,'--suite-root',suite],180)
 lines=text.splitlines()
 assert lines and lines[0].startswith('count: ')
 ids=lines[1:]
 assert ids and len(ids)==int(lines[0].removeprefix('count: ')),pattern
 assert all(re.fullmatch(r'(?:sloppy-script|strict-script|module):[^\r\n]+',s) for s in ids)
 selected.extend(ids)
original_ids=set((ROOT/'target/memory-regexp-unicode-data-20261027-evidence/conformance/executions').read_text().splitlines())
if unicode_only:
 assert selected and len(selected)==len(set(selected)) and not set(selected).intersection(original_ids)
 assert len(selected)==16, 'retain the exact separate Unicode selection'
 assert set(selected)==set((ROOT/'target/memory-regexp-unicode-data-20261027-evidence/conformance-unicode/executions').read_text().splitlines())
 report['separate_from_original_executions']=2365
else:
 assert len(selected)==len(set(selected))==2365 and set(selected)==original_ids,'retain all original pinned execution IDs'
execution_list=output/'executions'
execution_list.write_text('\n'.join(sorted(selected))+'\n')
report.update(selected_executions=len(selected),execution_list_sha256=digest(execution_list))
save();print('selected',len(selected),'original executions',flush=True)
selected = sorted(selected)
report['batch_limit'] = 16
report['batches'] = []
for offset in range(0,len(selected),16):
 ids=selected[offset:offset+16];label=f'execute-{offset//16:03d}'
 listing=output/(label+'.executions');listing.write_text('\n'.join(ids)+'\n')
 text=invoke(label,['test262','run-list',listing,'--execution-backend','wasm-aot',
  '--suite-root',suite,'--snapshot-dir',output/'snapshots'/label,'--snapshot-name',label,
  '--threads','1','--timeout-ms','60000','--reuse-case-workers'])
 assert re.findall(r'^total: (\d+)$',text,re.M)==re.findall(r'^passed: (\d+)$',text,re.M)==[str(len(ids))]
 snapshot,=(output/'snapshots'/label).glob('*.json');snap=json.loads(snapshot.read_text())
 assert snap['total']==snap['passed']==len(ids) and set(snap['completed_test_ids'])==set(ids)
 assert snap['compiler_identity']==identity and not snap['failures'] and not snap['timeout_test_ids']
 assert snap['counts_per_outcome']==dict(Bug=0,Crash=0,NotImplemented=0,Success=len(ids))
 report['batches'].append(dict(list_file=listing.name,list_sha256=digest(listing),snapshot_file=str(snapshot.relative_to(output)),snapshot_sha256=digest(snapshot),passed=len(ids)))
 save();print('passed',offset+len(ids),'/',len(selected),'original executions',flush=True)
assert digest(compiler)==report['compiler']['sha256']
report.update(complete=True,finished_at=stamp(),after=budget(),total=len(selected),passed=len(selected),
 snapshots=[dict(file=str(p.relative_to(output)),sha256=digest(p),bytes=p.stat().st_size)
            for p in sorted((output/'snapshots').rglob('*.json'))])
save();print('passed',len(selected),'original executions',flush=True)
