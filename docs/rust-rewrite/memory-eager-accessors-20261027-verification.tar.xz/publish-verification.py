"""Private post-verification publisher; no execution or automatic publication."""
import argparse,hashlib,json,lzma,re,subprocess,sys,tarfile
from datetime import datetime,timezone
from pathlib import Path,PurePosixPath
BASE=Path(__file__).resolve().parent;ROOT=BASE.parents[1];DEST=ROOT/'docs/rust-rewrite';STEM='memory-eager-accessors-20261027'
sys.path.insert(0,str(ROOT/'scripts'))
import precompiled_comparison as p
from native_test_protocol import result_summaries
def read(path):
    return json.loads(path.read_text())

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def streams(directory, commands):
    for row in commands:
        assert row.get('exit_code', row.get('returncode')) == 0
        for key in ('stdout', 'stderr'):
            assert sha(directory/row[key]) == row[key+'_sha256']

def resource(report):
    # Nested conformance reports inherit the driver scope and omit affinity.
    if 'cpu_affinity' in report:
        assert report['cpu_affinity'] == [0]
    for moment in ('before', 'after'):
        values = report[moment]
        assert values['memory.max'] == '4294967296'
        assert values['memory.swap.max'] == '0' and values['memory.oom.group'] == '1'
    before = dict(line.split() for line in report['before']['memory.events'].splitlines())
    after = dict(line.split() for line in report['after']['memory.events'].splitlines())
    assert all(before[key] == after[key] for key in ('oom', 'oom_kill', 'oom_group_kill'))

def conformance(directory, source):
    report = read(directory/'report.json')
    assert report['complete'] and report['source_commit'] == source and report['batch_limit'] == 16
    resource(report)
    streams(directory, report['commands'])
    listing = directory/'executions'
    assert sha(listing) == report['execution_list_sha256']
    selected = listing.read_text().splitlines()
    assert selected and len(selected) == len(set(selected)) == report['selected_executions']
    actual = []
    for part in report['batches']:
        ids_file, snapshot_file = directory/part['list_file'], directory/part['snapshot_file']
        assert sha(ids_file) == part['list_sha256'] and sha(snapshot_file) == part['snapshot_sha256']
        ids = ids_file.read_text().splitlines()
        snapshot = read(snapshot_file)
        assert 0 < len(ids) <= 16 and len(ids) == len(set(ids)) == part['passed'] == snapshot['total'] == snapshot['passed']
        assert snapshot['compiler_identity'] == report['compiler']['identity']
        assert set(snapshot['completed_test_ids']) == set(ids)
        assert not snapshot['failures'] and not snapshot['timeout_test_ids']
        assert snapshot['counts_per_outcome'] == dict(Bug=0, Crash=0, NotImplemented=0, Success=len(ids))
        actual.extend(ids)
    assert len(actual) == len(set(actual)) == report['total'] == report['passed'] == len(selected)
    assert set(actual) == set(selected)
    assert report['compiler']['identity']['source_revision'] == dict(kind='git-commit', commit=source)
    assert report['compiler']['identity']['executable_sha256'] == report['compiler']['sha256']
    return report, set(selected)

parser=argparse.ArgumentParser()
parser.add_argument('source');parser.add_argument('run');parser.add_argument('--measured-source')
parser.add_argument('--verification-dir',type=Path,default=BASE)
parser.add_argument('--failed-check',type=Path,required=True)
args=parser.parse_args();source=args.source;measured_source=args.measured_source or source;work=args.verification_dir.resolve()
assert source=='00fcf97fbffde8137a67d6ed7ed4803e86384ef1'
assert re.fullmatch('[0-9a-f]{40}',source) and re.fullmatch('[0-9a-f]{40}',measured_source)
assert work.is_relative_to(BASE.resolve()) and args.failed_check.resolve().is_relative_to(BASE.resolve())
check=read(work/'check.json');verification=read(work/'verification.json');native=read(work/'native/report.json');cheap=read(work/'cheap-verified/cheap-main.json')
for report in [check,verification,native]:assert report['complete'] and report['source_commit']==source;resource(report)
assert check['exit_code']==0
assert 'const LAYOUT_VERSION: u32 = 28;' in subprocess.check_output(['git','show',source+':crates/scriptw-aot-wasm/src/runtime_artifact.rs'],cwd=ROOT,text=True)
for key,name in [('stdout','cargo-check.jsonl'),('stderr','cargo-check.stderr')]:assert sha(work/name)==check[key+'_sha256']
streams(work,verification['commands']);streams(work/'native',native['commands']);streams(work/'cheap-verified',cheap['commands'])
assert cheap['complete'] and cheap['base_commit']==source
failed=read(args.failed_check);assert not failed['complete'] and failed['exit_code']!=0
for key,name in [('stdout','cargo-check.jsonl'),('stderr','cargo-check.stderr')]:assert sha(args.failed_check.parent/name)==failed[key+'_sha256']
assert failed['source_commit']=='4de65ce640845e82fbde912a5c71025ab9d583c1'
diagnostics=[json.loads(line)for line in (args.failed_check.parent/'cargo-check.jsonl').read_text().splitlines()]
assert diagnostics[-1]==dict(reason='build-finished',success=False)
errors=[row['message']for row in diagnostics if row.get('reason')=='compiler-message' and row['message']['level']=='error']
assert len(errors)==1 and errors[0]['code']['code']=='E0599'
assert errors[0]['message']=="no method named `map` found for struct `SectionLimited<'_, u32>` in the current scope"
primary=[span for span in errors[0]['spans']if span['is_primary']]
assert len(primary)==1 and primary[0]['file_name']=='crates/scriptw-aot-wasm/src/tests/intrinsic_accessor_allocation.rs'
assert primary[0]['line_start']==primary[0]['line_end']==163
assert any('declarations.extend(functions.map(Result::unwrap))' in line['text']for line in primary[0]['text'])
assert len(native['scopes'])==19 and native['passed_disjoint_scopes']==4881
predecessor=BASE/'retry-a960f50ac'
stopped=read(predecessor/'native/report.json');stopped_batch=read(predecessor/'verification.json')
assert stopped['source_commit']==measured_source and not stopped['complete'] and 'after' not in stopped
assert not stopped_batch['complete'] and 'after' not in stopped_batch
completed=[row for row in stopped['scopes']if row['complete']];assert len(completed)==4 and sum(row['passed']for row in completed)==423
failed_scope=[row for row in stopped['scopes']if not row['complete']];assert len(failed_scope)==1 and failed_scope[0]['target']=='scriptw_aot_wasm' and len(failed_scope[0]['inventory'])==504
failed_commands=[row for row in stopped['commands']if row.get('exit_code')!=0];assert len(failed_commands)==1
failure_raw=(predecessor/'native'/failed_commands[0]['stdout']).read_text()
assert result_summaries(failure_raw)==[('FAILED','503','1','0','0','0')]
assert 'tests::bootstrap_compact_metadata::' in failure_raw
for command in stopped['commands']:
 for key in ['stdout','stderr']:assert sha(predecessor/'native'/command[key])==command[key+'_sha256']
frozen=read(work/'prior-native-binaries.json');assert frozen['source_commit']==measured_source and len(frozen['binaries'])==19
assert frozen['native_report_sha256']==sha(predecessor/'native/report.json') and frozen['cargo_stdout_sha256']==sha(predecessor/'native/cargo-native.stdout')
assert native['unchanged_predecessor_binaries']==18
for scope in native['scopes']:
 if scope['target']=='scriptw_aot_wasm':assert scope['inventory']==failed_scope[0]['inventory'];continue
 old_binary=[row for row in frozen['binaries']if row['target']==scope['target']and row['kind']==[scope['kind']]];assert len(old_binary)==1
 assert scope['reused_from_source']==measured_source and scope['executable_sha256']==scope['predecessor_executable_sha256']==old_binary[0]['sha256']

prior_base=ROOT/'target/memory-regexp-unicode-data-20261027-evidence';prior_path=DEST/'memory-regexp-unicode-data-20261027.json';prior=read(prior_path)
previous=read(prior_base/'native-final/report.json');assert previous['complete'] and previous['passed_disjoint_scopes']==4876
expected_prior=next(row for row in prior['retained_files']if row['path']=='native-final/report.json');assert sha(prior_base/'native-final/report.json')==expected_prior['sha256']
old={(row['package'],row['target']):set(row['inventory'])for row in previous['scopes']}
for scope in native['scopes']:
 inventory=scope['inventory'];assert scope['complete'] and len(inventory)==len(set(inventory))==scope['passed'] and old[(scope['package'],scope['target'])]<=set(inventory)
 prefix=scope['package']+'-'+scope['target']+'-part-';actual=[]
 for command in native['commands']:
  if not command['label'].startswith(prefix):continue
  raw=(work/'native'/command['stdout']).read_text();names=[n.removesuffix(' - should panic')for n in re.findall(r'^test ([^\r\n]+) \.\.\. ok$',raw,re.M)]
  assert result_summaries(raw)==[('ok',str(len(names)),'0','0','0',str(len(inventory)-len(names)))];actual+=names
 assert len(actual)==len(set(actual))==len(inventory) and set(actual)==set(inventory)
original,ids=conformance(work/'conformance',source);supplemental,extra=conformance(work/'conformance-unicode',source)
assert original['total']==2365 and supplemental['total']==16 and not ids&extra
assert ids==set((prior_base/'conformance/executions').read_text().splitlines()) and extra==set((prior_base/'conformance-unicode/executions').read_text().splitlines())
bindings=read(work/'source-bindings-computed.json')
assert len(bindings)==2 and all(row['revision']==source for row in bindings)
equivalence=read(work/'source-bindings-closure-equivalence.json')
assert equivalence['test_only_repair'] is True and len(equivalence['rows'])==6
for local in [False,True]:
 pair=[row for row in equivalence['rows']if row['extra_ignored_regress_lock']==local]
 assert {row['revision']for row in pair}=={source,failed['source_commit'],'a960f50acea8bd3a1de0a2c391bbb09b88f2ee4d'} and len(pair)==3
 assert all(row[key]==pair[0][key]for row in pair for key in ['source_fingerprint','files','bytes'])
 current=next(row for row in bindings if row['extra_ignored_regress_lock']==local)
 assert all(current[key]==pair[0][key]for key in ['source_fingerprint','files','bytes'])
def binding(revision,local):
 rows=[r for r in (bindings if revision==source else equivalence['rows']) if r['revision']==revision and r['extra_ignored_regress_lock']==local];assert len(rows)==1;return rows[0]
assert original['compiler']['identity']['source_fingerprint']==binding(source,True)['source_fingerprint']
assert supplemental['compiler']['identity']==original['compiler']['identity']
assert binding(source,False)['source_fingerprint']==binding(measured_source,False)['source_fingerprint']
assert measured_source=='a960f50acea8bd3a1de0a2c391bbb09b88f2ee4d' and args.run=='40552965169', 'this checkpoint binds measured a960 to test-only repaired 00fc'
assert subprocess.run(['git','merge-base','--is-ancestor',failed['source_commit'],source],cwd=ROOT).returncode==0
measured,rows=p.load_report(BASE/('github-'+args.run)/'precompiled-measurements/precompiled-evidence/report.json')
assert measured['source_commit']==measured_source and measured['source_fingerprint']==binding(measured_source,False)['source_fingerprint'] and len(rows)==17
processing=read(BASE/'ci-processing.json')
assert processing['complete'] and processing['source_commit']==measured_source and processing['run']==args.run and processing['scored_mutations'] is False
assert processing['cpu_affinity']==[0] and processing['closure_proof_sha256']==sha(work/'source-bindings-closure-equivalence.json')
assert [row['label']for row in processing['commands']]==['validate-measured','retain-phase-raw','analyze-phase-maps','render-previews','canonical-p-check']
streams(BASE,processing['commands'])
for moment in ['before','after']:
 values=processing[moment];assert 0<int(values['memory.max'])<=4*1024**3
 assert values['memory.swap.max']=='0' and values['memory.oom.group']=='1'
events=[dict(line.split()for line in processing[moment]['memory.events'].splitlines())for moment in ['before','after']]
assert all(events[0][key]==events[1][key]for key in ['oom','oom_kill','oom_group_kill'])
run=read(BASE/('github-run-'+args.run+'.json'))
assert run['databaseId']==int(args.run) and run['headSha']==measured_source and run['status']=='completed' and run['conclusion']=='success'
assert run['jobs'] and all(job['status']=='completed' and job['conclusion']=='success'for job in run['jobs'])
visual=read(BASE/'visual-review.json')
assert visual['source_commit']==measured_source and visual['run']==args.run and visual['png_images_viewed'] is True
visual_files={row['path']for row in visual['files']}
assert visual_files=={'preview-memory.svg','preview-memory.png','preview-execution.svg','preview-execution.png'} and len(visual['files'])==4
for row in visual['files']:
 assert (BASE/row['path']).stat().st_size==row['bytes'] and sha(BASE/row['path'])==row['sha256']
static=read(BASE/'owned-r-static.json')
assert static['source_commit']==measured_source and static['prior_source_commit']=='38c25942b63a752ce5db46b6cb42b46ed98f9a57' and static['scored'] is False
assert static['current_check']['sha256']==sha(BASE/'retry-a960f50ac/check.json') and static['current_check']['stdout_sha256']==sha(BASE/'retry-a960f50ac/cargo-check.jsonl')
assert static['source_bindings']['sha256']==sha(BASE/'retry-a960f50ac/source-bindings-closure-equivalence.json')
assert static['current']['package']['layout']==28 and static['prior']['package']['layout']==27
assert static['current']['package']['source_fingerprint']==binding(source,True)['source_fingerprint']
assert static['prior']['helper_native_bytes']['realm_initialize_intrinsics']==888703
assert static['current']['helper_native_bytes']==dict(realm_initialize_intrinsics=765194,intrinsic_accessor_allocate=783)
for family in ['prior','current']:
 command=static[family]['symbol_command'];assert command['returncode']==0
 for stream in ['stdout','stderr']:assert sha(BASE/command[stream])==command[stream+'_sha256']
for key,family in [('package_bytes','package'),('native_image_bytes','native')]:
 assert static['deltas'][key]==static['current'][family]['bytes']-static['prior'][family]['bytes']
assert static['deltas']['realm_initialize_native_bytes']==765194-888703
proof=static['prior_checkpoint_proof'];assert sha(Path(proof['path']))==proof['sha256']
phase_record=read(DEST/'memory-phase-boundaries-20261027.json')
assert next(row for row in phase_record['retained_files']if row['path']=='runtime-packages-unchanged.json')['sha256']==proof['sha256']
files=[]
for path in sorted(BASE.rglob('*')):
 if not path.is_file():continue
 rel=path.relative_to(BASE).as_posix();parts=PurePosixPath(rel).parts
 if parts[0].startswith('github-') or 'images'in parts or 'mplconfig'in parts or (path.name.startswith(('preview-','publication.')) and rel not in visual_files):continue
 if path.suffix not in ['.py','.json','.jsonl','.stdout','.stderr','.txt','.smaps','.md','.patch','.lock','.png','.svg'] and path.name not in ['executions','stdout','stderr','control']:continue
 assert not path.is_symlink() and '..'not in parts and path.stat().st_size<=128*1024**2
 with path.open('rb')as stream:assert not stream.read(8).startswith((b'\x7fELF',b'MZ',b'SCRWEP',b'SCRWWA'))
 files.append(dict(path=rel,bytes=path.stat().st_size,sha256=sha(path)))
assert visual_files<={row['path']for row in files}
expanded=sum(row['bytes']for row in files);assert expanded<=2*1024**3
archive=DEST/(STEM+'-verification.tar.xz');target=DEST/(STEM+'.json');assert not archive.exists() and not target.exists()
with archive.open('xb')as output,lzma.LZMAFile(output,'w',filters=[dict(id=lzma.FILTER_LZMA2,preset=1,dict_size=64*1024**2)])as compressed:
 with tarfile.open(fileobj=compressed,mode='w|')as tar:
  for row in files:
   member=tarfile.TarInfo(row['path']);member.size=row['bytes'];member.mode=0o644
   with (BASE/row['path']).open('rb')as stream:tar.addfile(member,stream)
assert archive.stat().st_size<=32*1024**2
expected={row['path']:row for row in files};seen=set();total=0
with tarfile.open(archive,'r|xz')as tar:
 for member in tar:
  assert member.isfile() and member.name in expected and member.name not in seen
  row=expected[member.name];assert member.size==row['bytes']<=128*1024**2
  assert hashlib.file_digest(tar.extractfile(member),'sha256').hexdigest()==row['sha256'];seen.add(member.name);total+=member.size;assert total<=2*1024**3
assert seen==set(expected) and total==expanded
record=dict(schema='scriptw-eager-accessors-verification-v1',recorded_at=datetime.now(timezone.utc).isoformat(),verified_source_commit=source,measured_source_commit=measured_source,runtime_layout=28,source_bindings=bindings,source_binding_equivalence=equivalence,ci_processing=processing,github_run=run,visual_review=visual,static_code=static,native=native,test262=original,supplemental_unicode=supplemental,checkpoints=dict(check=check,verification=verification,cheap=cheap),original_failed_native=dict(raw_report='retry-a960f50ac/native/report.json',report=stopped,stopped_driver=stopped_batch,frozen_binary_provenance=frozen,after_counters_available=False),original_failed_check=dict(path=str(args.failed_check.resolve().relative_to(BASE.resolve())),report=failed),prior_checkpoint=dict(file=prior_path.name,sha256=sha(prior_path)),measurement=dict(run=args.run,report_sha256=sha(BASE/('github-'+args.run)/'precompiled-measurements/precompiled-evidence/report.json')),archive=dict(file=archive.name,sha256=sha(archive),bytes=archive.stat().st_size,expanded_bytes=expanded,member_count=len(files),max_member_bytes=128*1024**2,max_expanded_bytes=2*1024**3),retained_files=files,interpretation='Fresh eager accessor functions share one typed construction tail; defining Realm, identity, strictness and source allocation order remain unchanged. Exact native inventories and original selected conformance passed; not a full-suite refresh. Initial test-only compilation failure and subsequent 503-pass/1-fail inspection-test attempt are retained; no after counters are synthesized for stopped scopes. Cross-runner memory changes are descriptive, not causal savings; Scriptc parity remains open. Paused mapping captures, if retained, remain unscored.')
target.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record['archive']))
