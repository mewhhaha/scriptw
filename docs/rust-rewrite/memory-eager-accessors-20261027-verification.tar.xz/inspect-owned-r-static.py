"""Static inspection of owned Cargo outputs; no compilation/deserialization/execution."""
import hashlib
import json
from pathlib import Path
import stat
import struct
import subprocess
import os

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
SOURCE = 'a960f50acea8bd3a1de0a2c391bbb09b88f2ee4d'
PRIOR = '38c25942b63a752ce5db46b6cb42b46ed98f9a57'
OLD = ROOT/'target/memory-phase-boundaries-20261027-evidence'
RETRY = BASE/'retry-a960f50ac'


def read(path):
    return json.loads(path.read_text())


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def owned(path, maximum):
    info = path.lstat()
    assert stat.S_ISREG(info.st_mode) and info.st_uid == os.getuid() and info.st_size <= maximum
    return info


def package(path, fingerprint, layout):
    owned(path, 128*1024**2)
    raw = path.read_bytes()
    assert raw[:8] == b'SCRWRB01' and struct.unpack_from('<I', raw, 8)[0] == layout
    assert raw[12:44].hex() == fingerprint
    assert hashlib.sha256(raw[:-32]).digest() == raw[-32:]
    static, utf16, strings, wasm = struct.unpack_from('<QQIQ', raw, 108)
    assert wasm == len(raw)-168 and raw[136:144] == b'\0asm\1\0\0\0'
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest(),
                wasm_bytes=wasm, static_bytes=static, pooled_utf16_bytes=utf16, strings=strings, layout=layout,
                source_fingerprint=fingerprint)


def inspect(label, directory, fingerprint, layout):
    path = directory/'scriptw-runtime-portable-package.bin'
    result = package(path, fingerprint, layout)
    native = directory/'scriptw-runtime-portable-native.bin'
    manifest = directory/'scriptw-runtime-portable-manifest.bin'
    owned(native, 256*1024**2)
    owned(manifest, 4096)
    raw = manifest.read_bytes()
    assert raw[:8] == b'SCRWNR01' and struct.unpack_from('<I', raw, 8)[0] == 5
    target_length = struct.unpack_from('<H', raw, 19)[0]
    assert 0 < target_length <= 256 and len(raw) == 21+target_length+128
    target = raw[21:21+target_length].decode('ascii')
    offset = 21+target_length
    source, key, package_digest, native_digest = [raw[offset+i*32:offset+(i+1)*32].hex() for i in range(4)]
    assert source == fingerprint and package_digest == result['sha256'] and native_digest == sha(native)
    with native.open('rb') as stream:
        assert stream.read(4) == b'\x7fELF'
    argv = ['nm', '--print-size', '--size-sort', '--defined-only', str(native)]
    completed = subprocess.run(argv, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False, timeout=30)
    assert completed.returncode == 0 and len(completed.stdout) < 4*1024**2 and len(completed.stderr) < 4096
    (BASE/(label+'-r-symbols.stdout')).write_bytes(completed.stdout)
    (BASE/(label+'-r-symbols.stderr')).write_bytes(completed.stderr)
    helpers = {}
    for name in ('realm_initialize_intrinsics', 'intrinsic_accessor_allocate'):
        rows = [line.split() for line in completed.stdout.decode().splitlines() if line.split() and line.split()[-1].endswith('::helper::'+name)]
        assert len(rows) == (0 if label == 'prior' and name == 'intrinsic_accessor_allocate' else 1), (label, name, rows)
        helpers[name] = None if not rows else int(rows[0][1], 16)
    assert sha(native) == native_digest and sha(path) == result['sha256']
    return dict(package=result, manifest=dict(path=str(manifest), sha256=sha(manifest), source_fingerprint=source,
        target=target, configuration=struct.unpack_from('<I',raw,12)[0], modes=list(raw[16:19]), runtime_key=key,
        package_digest=package_digest,native_digest=native_digest),
        native=dict(path=str(native), bytes=native.stat().st_size,sha256=native_digest),
        symbol_command=dict(argv=argv,returncode=0,stdout=label+'-r-symbols.stdout',stderr=label+'-r-symbols.stderr',
            stdout_sha256=hashlib.sha256(completed.stdout).hexdigest(),stderr_sha256=hashlib.sha256(completed.stderr).hexdigest()),
        helper_native_bytes=helpers)


def main():
    check = read(RETRY/'check.json')
    assert check['complete'] and check['exit_code'] == 0 and check['source_commit'] == SOURCE
    raw = (RETRY/'cargo-check.jsonl').read_bytes()
    assert hashlib.sha256(raw).hexdigest() == check['stdout_sha256']
    producer = [row for line in raw.splitlines() if line.startswith(b'{')
                for row in [json.loads(line)] if row.get('reason') == 'build-script-executed'
                and row.get('package_id') == 'path+file:///home/mewhhaha/src/porffor/crates/scriptw-runtime-image#0.1.0']
    assert len(producer) == 1
    bindings_path = RETRY/'source-bindings-closure-equivalence.json'
    bindings = read(bindings_path)
    local = [row for row in bindings['rows'] if row['revision'] == SOURCE and row['extra_ignored_regress_lock']]
    assert bindings['test_only_repair'] and len(local) == 1
    prior_path = OLD/'runtime-packages-unchanged.json'
    prior = read(prior_path)
    prior_record = read(ROOT/'docs/rust-rewrite/memory-phase-boundaries-20261027.json')
    retained = {row['path']:row for row in prior_record['retained_files']}
    assert prior_record['verified_source_commit'] == PRIOR and prior['source_commit'] == PRIOR
    assert sha(prior_path) == retained['runtime-packages-unchanged.json']['sha256']
    prior_package = next(row for row in prior['packages'] if Path(row['path']).name == 'scriptw-runtime-portable-package.bin')
    assert prior_package['byte_identical'] and prior_package['prior_source'] == 'e7e51222101533e421ffae41bb0ccad78ba638ba'
    old_fp = 'f95991e5a2af12a901c2986c0b0f98ac72200cc6d70627f178e8b80bf68fbb7e'
    old = inspect('prior', Path(prior_package['path']).parent, old_fp, 27)
    assert old['package']['sha256'] == prior_package['sha256'] and old['package']['bytes'] == prior_package['bytes']
    current = inspect('current', Path(producer[0]['out_dir']), local[0]['source_fingerprint'], 28)
    assert current['manifest']['target'] == old['manifest']['target']
    assert current['manifest']['configuration'] == old['manifest']['configuration']
    assert current['manifest']['modes'] == old['manifest']['modes']
    result = dict(source_commit=SOURCE, prior_source_commit=PRIOR, scored=False,
        scope='Static owned Cargo raw-package/native-ELF bytes only; no compilation, Wasmtime deserialization or execution. Not RSS or causal memory savings.',
        current_check=dict(path=str(RETRY/'check.json'),sha256=sha(RETRY/'check.json'),stdout_sha256=hashlib.sha256(raw).hexdigest()),
        source_bindings=dict(path=str(bindings_path),sha256=sha(bindings_path)),cargo_producer=producer[0],
        prior_checkpoint_proof=dict(path=str(prior_path),sha256=sha(prior_path)),prior=old,current=current,
        deltas=dict(package_bytes=current['package']['bytes']-old['package']['bytes'],
            raw_wasm_bytes=current['package']['wasm_bytes']-old['package']['wasm_bytes'],
            native_image_bytes=current['native']['bytes']-old['native']['bytes'],
            realm_initialize_native_bytes=current['helper_native_bytes']['realm_initialize_intrinsics']-old['helper_native_bytes']['realm_initialize_intrinsics']))
    (BASE/'owned-r-static.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(dict(source=SOURCE,prior=old['helper_native_bytes'],current=current['helper_native_bytes'],deltas=result['deltas']),indent=2))


if __name__ == '__main__':
    main()
