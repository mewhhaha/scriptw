"""Private, bounded inert CI processing. Never execute downloaded consumers."""
import os,sys,subprocess,json,hashlib,time,shutil
from pathlib import Path
BASE=Path(__file__).resolve().parent;ROOT=BASE.parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from limited_verification import require_kernel_budget,kernel_group
require_kernel_budget(4*1024**3);assert sorted(os.sched_getaffinity(0))==[0]
import precompiled_comparison as p
RUN='40552965169';SOURCE='a960f50acea8bd3a1de0a2c391bbb09b88f2ee4d'
group=kernel_group()
def counters():return {k:(group/k).read_text().strip() for k in ['memory.max','memory.swap.max','memory.oom.group','memory.peak','memory.events']}
def sha(path):
 with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
closure=BASE/'retry-00fcf97fb/source-bindings-closure-equivalence.json'
proof=json.loads(closure.read_text());assert proof['test_only_repair'] is True and len(proof['rows'])==6
for mode in (False,True):
 rows=[r for r in proof['rows'] if r['extra_ignored_regress_lock']==mode]
 assert len(rows)==3 and {r['revision'] for r in rows}=={'4de65ce640845e82fbde912a5c71025ab9d583c1',SOURCE,'00fcf97fbffde8137a67d6ed7ed4803e86384ef1'}
 assert len({(r['source_fingerprint'],r['files'],r['bytes']) for r in rows})==1
record=dict(source_commit=SOURCE,run=RUN,complete=False,scored_mutations=False,closure_proof_sha256=sha(closure),cpu_affinity=sorted(os.sched_getaffinity(0)),before=counters(),commands=[])
out=BASE/'ci-processing.json';assert not out.exists()
def save():out.write_text(json.dumps(record,indent=2)+'\n')
def run(label,args,required=True):
 stdout=BASE/(label+'.stdout');stderr=BASE/(label+'.stderr');start=time.monotonic()
 with stdout.open('xb') as a,stderr.open('xb') as b:r=subprocess.run(args,cwd=ROOT,stdout=a,stderr=b,timeout=300)
 record['commands'].append(dict(label=label,args=[str(x) for x in args],exit_code=r.returncode,seconds=time.monotonic()-start,stdout=stdout.name,stdout_sha256=sha(stdout),stderr=stderr.name,stderr_sha256=sha(stderr)));record['after']=counters();save()
 if required and r.returncode:raise SystemExit(r.returncode)
 return r.returncode
save();os.environ['MPLCONFIGDIR']=str(BASE/'mplconfig')
report=BASE/f'github-{RUN}/precompiled-measurements/precompiled-evidence/report.json'
# Exact raw copy survives exclusion of the downloaded github-* artifact tree.
raw=BASE/f'ci-scored-{RUN}-raw-report.json';assert not raw.exists()
shutil.copyfile(report,raw);assert sha(raw)==sha(report)
record['raw_scored_report']=dict(path=raw.name,sha256=sha(raw),bytes=raw.stat().st_size);save()
run('validate-measured',[sys.executable,'-B',str(BASE/'retry-a960f50ac/validate-measured.py'),RUN,'--source',SOURCE,'--report',str(report),'--output',str(BASE/'measured-summary.json')])
validated,_=p.load_report(report)
retained=run('retain-phase-raw',[sys.executable,'-B',str(BASE/'retain-phase-raw.py')],required=False)==0
if retained:
 run('analyze-phase-maps',[sys.executable,'-B',str(BASE/'analyze-phase-maps.py'),'--diagnostic',str(BASE/f'ci-unscored-{RUN}'),'--scored-report',str(report),'--run',RUN,'--expected-source',SOURCE,'--expected-fingerprint',validated['source_fingerprint'],'--expected-executable-sha256',validated['tools']['consumer']['sha256'],'--output',str(BASE/'phase-map-analysis.json')])
else:record['mapping_status']='unavailable-validation-failed';save()
run('render-previews',[sys.executable,'-B',str(BASE/'render-previews.py')])
# Validate the existing canonical publication without replacing it with this CI run.
run('canonical-p-check',[sys.executable,'-B',str(ROOT/'scripts/precompiled_comparison.py'),'check',str(ROOT/'docs/rust-rewrite/precompiled-comparison.json')])
record['complete']=True;record['after']=counters();save()
