"""Build a small inert wasmparser observer from already-built dependencies."""
import json,os,subprocess,sys
from pathlib import Path
BASE=Path(__file__).resolve().parent;ROOT=BASE.parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from limited_verification import require_kernel_budget
require_kernel_budget(4*1024**3);assert len(os.sched_getaffinity(0))==1
rows=[json.loads(x) for x in (BASE/'native/cargo-native.stdout').read_text().splitlines()]
libs=[p for r in rows if r.get('reason')=='compiler-artifact' and '#wasmparser@0.245.1' in r['package_id'] for p in r['filenames'] if p.endswith('.rlib')]
assert libs
command=['rustc','--edition=2021','--crate-name','inspect_imports','-C','panic=abort',str(BASE/'inspect-imports.rs'),'--extern','wasmparser='+libs[0],'-L','dependency='+str(Path(libs[0]).parent),'-o',str(BASE/'inspect-imports')]
with (BASE/'inspect-imports-build.stdout').open('xb') as out,(BASE/'inspect-imports-build.stderr').open('xb') as err:subprocess.run(command,cwd=ROOT,stdout=out,stderr=err,timeout=120,check=True)
evidence=BASE/'github-40449574274/precompiled-evidence'
report=json.loads((evidence/'report.json').read_text())
paths=sorted({str(evidence/r['wasm']) for r in report['attempts'] if r['runtime']=='scriptw'})
assert len(paths)==17
with (BASE/'inspect-imports.stdout').open('xb') as out,(BASE/'inspect-imports.stderr').open('xb') as err:subprocess.run([str(BASE/'inspect-imports'),*paths],cwd=ROOT,stdout=out,stderr=err,timeout=60,check=True)
print((BASE/'inspect-imports.stdout').read_text())
print('Body/export refs omit constant expressions and metadata, and are NOT a safe pruning plan.')
