import json,os,sys
from pathlib import Path
BASE=Path(__file__).resolve().parent;ROOT=BASE.parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
import precompiled_comparison as p
from limited_verification import require_kernel_budget
require_kernel_budget(4*1024**3);assert len(os.sched_getaffinity(0))==1
report,rows=p.load_report(BASE/'github-40449574274/precompiled-evidence/report.json')
bindings=json.loads((BASE/'source-bindings-computed.json').read_text());assert report['source_commit']==bindings[0]['revision'] and report['source_fingerprint']==bindings[0]['source_fingerprint']
assert len(rows)==17 and all(r['runtimes'][rt]['status']=='ok' for r in rows for rt in p.RUNTIMES)
result=dict(complete=True,source_commit=report['source_commit'],source_fingerprint=report['source_fingerprint'],table=rows)
(BASE/'ci-validated.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(source=report['source_commit'],all_workloads=17,range_rss_ratio=[min(r['runtimes']['scriptw']['rss_mib']/r['runtimes']['scriptc']['rss_mib'] for r in rows),max(r['runtimes']['scriptw']['rss_mib']/r['runtimes']['scriptc']['rss_mib'] for r in rows)])))
