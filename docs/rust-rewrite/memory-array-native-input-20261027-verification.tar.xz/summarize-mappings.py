"""Describe unscored source selection, packed-page presence and endpoint RSS."""
import hashlib,json,statistics,struct,subprocess
from pathlib import Path
BASE=Path(__file__).resolve().parent
reports=[BASE.parent/'memory-fixed-floor-20261027-evidence/mapping-diagnostic-current',BASE/'mapping-diagnostic-current']
rows=[]
for directory in reports:
 report=json.loads((directory/'report.json').read_text());assert report['complete']
 executable=directory/'consumer'
 with executable.open('rb') as f:assert hashlib.file_digest(f,'sha256').hexdigest()==report['executable_sha256']
 nm=subprocess.run(['nm','-S','--defined-only','--format=posix',str(executable)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True,timeout=60)
 symbols=[]
 for line in nm.stdout.decode().splitlines():
  words=line.split()
  if words[0] in ('SCRIPTW_RUNTIME_PORTABLE_NATIVE','SCRIPTW_RUNTIME_NATIVE'):
   assert len(words)==4;symbols.append(dict(name=words[0],address=int(words[2],16),length=int(words[3],16)))
 assert len(symbols)==2
 with executable.open('rb') as f:
  header=f.read(64);assert header[:6]==b'\x7fELF\x02\x01'
  _,_,_,_,phoff,_,_,_,phsize,phnum,*_=struct.unpack('<HHIQQQIHHHHHH',header[16:]);assert phsize==56 and 0<phnum<=1024
  f.seek(phoff);raw=f.read(phnum*phsize);assert len(raw)==phnum*phsize
  loads=[h for h in struct.iter_unpack('<IIQQQQQQ',raw) if h[0]==1]
  for symbol in symbols:
   owners=[h for h in loads if h[3]<=symbol['address'] and symbol['address']+symbol['length']<=h[3]+h[5]]
   assert len(owners)==1 and owners[0][1]==4
   symbol['file_offset']=owners[0][2]+symbol['address']-owners[0][3]
 entry=dict(source_commit=report['source_commit'],executable_sha256=report['executable_sha256'],symbols=symbols,cases=[])
 for case in report['cases']:
  stdout=directory/case['file']/'stdout';value=json.loads(stdout.read_text())
  assert value['source_commit']==report['source_commit'] and value['compiler_enabled'] is False
  assert all(o['matched'] and o['completion']=='normal' for o in value['observations'])
  source_kinds=case.get('source_kinds')
  if source_kinds is None:
   import re
   source_kinds=re.findall(r'runtime-native packed source: ([a-z-]+)',(directory/case['file']/'stderr').read_text())
  summary=dict(file=case['file'],source_kinds=sorted(set(source_kinds)),snapshots=len(case['snapshots']),sampled_max_rss_mib=case['maximum_sample']['rss_bytes']/2**20,
   after_execution_median_mib=statistics.median(o['process_snapshots']['after_execution']['rss_bytes'] for o in value['observations'][10:])/2**20,
   after_store_drop_median_mib=statistics.median(o['process_snapshots']['after_store_drop']['rss_bytes'] for o in value['observations'][10:])/2**20,packed_present=[])
  for symbol in symbols:
   counts=[];page_counts=set()
   for snap in case['snapshots']:
    presence=snap['executable_presence']
    if presence['status']!='present-bits-only-no-PFNs':continue
    mappings=presence['mappings'];pages={m['page_bytes'] for m in mappings};assert len(pages)==1
    page=pages.pop();start=symbol['file_offset']//page*page;end=(symbol['file_offset']+symbol['length']+page-1)//page*page
    offsets={p for m in mappings for p in m['present_page_file_offsets'] if start<=p<end}
    counts.append(len(offsets));page_counts.add((end-start)//page)
   assert counts and len(page_counts)==1
   summary['packed_present'].append(dict(symbol=symbol['name'],maximum_present_pages=max(counts),total_symbol_pages=page_counts.pop(),scope='maximum across asynchronous samples, present bits only'))
  entry['cases'].append(summary)
 rows.append(entry)
result=dict(scope='unscored different local runs, not causal CI attribution; sampled maxima and endpoint medians are distinct',rows=rows)
(BASE/'mapping-summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
