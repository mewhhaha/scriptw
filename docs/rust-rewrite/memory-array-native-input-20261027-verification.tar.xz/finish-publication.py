"""Publish source-bound Array/native-input checkpoint after all verification."""
import json,re,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'scripts'))
import precompiled_comparison as p
STEM='memory-array-native-input-20261027'
batch=json.loads((BASE/'verification.json').read_text());assert batch['complete']
subprocess.run([sys.executable,'-B',str(BASE/'publish-verification.py')],cwd=ROOT,check=True)
report,rows=p.publish(BASE/'github-40449574274/precompiled-evidence/report.json',ROOT,replace=True)
record=json.loads((ROOT/'docs/rust-rewrite'/f'{STEM}.json').read_text())
assert report['source_commit']==record['verified_source_commit']
ratios=[r['runtimes']['scriptw']['rss_mib']/r['runtimes']['scriptc']['rss_mib'] for r in rows]
ratio=f'{min(ratios):.1f}–{max(ratios):.1f}'
native=record['native']['passed_disjoint_scopes'];conformance=record['test262']['total']
names={'integer.js':'Integer','objects.js':'Objects','retained-objects.js':'Retained objects'}
readme=ROOT/'README.md';text=readme.read_text()
text=text.replace('compiler `9b423b63c`',f"compiler `{report['source_commit'][:9]}`",1)
text=text.replace("**1.4–2.0× Scriptc's**",f"**{ratio}× Scriptc's**",1)
for row in rows:
 if row['file'] in names:
  line='| '+names[row['file']]+' | '+f"{row['runtimes']['scriptw']['rss_mib']:.1f} MiB | {row['runtimes']['scriptc']['rss_mib']:.1f} MiB |"
  text=re.sub(r'^\| '+names[row['file']]+r' \|.*$',line,text,flags=re.M)
start=text.index('The current pass defers normalization tables');end=text.index('\n\n[All measurements',start)
text=text[:start]+f"""The current pass removes public descriptor-call allocations from internal Array
queries and adds a kernel-proven executable-file source for packed native data.
[Verification](docs/rust-rewrite/{STEM}.md):
**{native:,} native cases and {conformance:,} original pinned Test262 executions
passed**, under one CPU and a 4-GiB process-tree limit.
The matched measurements and verification use the same source revision."""+text[end:]
text=text.replace('actions/runs/40439597289','actions/runs/40449574274');readme.write_text(text)
lines=['# Array and native-input memory checkpoint','',f"Measured and verified source `{report['source_commit']}`; refreshed {report['finished_at'][:10]}.",'',f"The [matched comparison](precompiled-comparison.md) records Scriptw at **{ratio} times Scriptc’s post-execution RSS** across all 17 workloads. Scriptc parity remains open.",'','| Workload | Scriptw RSS | Scriptc RSS |','| --- | ---: | ---: |']
for row in rows:
 if row['file'] in names:lines.append('| '+names[row['file']]+' | '+f"{row['runtimes']['scriptw']['rss_mib']:.1f} MiB | {row['runtimes']['scriptc']['rss_mib']:.1f} MiB |")
lines += ['','Three Sol reviews guided source provenance, GC layout and transient allocation work. Internal own-descriptor queries for actual Array objects now use the existing non-Proxy storage kernel and copy a fresh mutable descriptor record. Immutable value/getter/setter edges remain shared. Proxies and other exotic targets retain their existing dispatch. No public builtin function, argument array or JavaScript descriptor transport object is allocated for these Array queries. See the [descriptor contract](contracts/proxy-target-descriptor-completion.md).','',
"The native-image reader retains strict mapped device/inode admission first. When device aliases prevent that proof, a private file-owning kernel-main-ELF constructor can prove the exact immutable static range against /proc/self/exe, bounded kernel auxiliary-vector facts, the loaded program-header table, entry/load bias, inode and exact file offsets. Header and payload spans must each have exactly one read-only file-backed load; all overlapping load types reject. Proc denial, unsupported layouts and ambiguity keep the embedded source. Existing decoded digest, manifest and destination-Engine admission remain mandatory. See the [packed-input contract](contracts/immutable-runtime-build-package.md#packed-native-image-source).",'',
f"Workspace release/all-targets type checking passed. Sixteen complete affected native inventories passed **{native:,} cases**, with zero failures or ignored cases. The 1,047-case engine library ran in fresh groups of at most eight. Runtime-image controls include malformed ELF/auxv facts, overlapping RO/RW/RX headers, offset/range failures and an independently gated actual-source test. The Array controls cover both packed-number and mutable descriptor storage, reentry after descriptor capture, inherited setters, accessor and Symbol properties, length/index boundaries, Proxy invariants, foreign realms and public-intrinsic poisoning.",'',
f"The pinned selection passed **{conformance:,} original Test262 executions**, covering Array push/sort/join, Proxy descriptor/get/set/has/delete invariants, Reflect.set and Object/Reflect own-descriptors. This is selected verification, not a full pinned-suite refresh; the full-suite README status is unchanged. The preceding [fixed-floor checkpoint](memory-fixed-floor-runtime-20261027.md) retains its separate 662-case Intl library, four output-publication cases and seven collector controls; those unchanged scopes were not repeated in this batch.",'',
"Source-only guards and focused Python tooling controls passed. Verification used one CPU, a 4-GiB process-tree cap, no swap, grouped OOM and bounded retained-module caches. The clean Git-tree fingerprint matches CI. Local verification also fingerprints the retained ignored standalone regress Cargo.lock; both exact identities and its bytes are retained. Local binaries are not relabelled as CI binaries.",'',
"The [matched CI run](https://github.com/mewhhaha/scriptw/actions/runs/40449574274) uses compiler-disabled consumers, identical host settings, two rounds, ten checked warmups and seven samples per round. Every original checksum passed. Both RSS and execution-time graphs are regenerated from this exact run. RSS includes code, data, runtime and warmup history; it is neither peak memory nor live JavaScript heap. Differences from earlier runner campaigns do not establish causal gains or regressions.",'',
"Fresh local mapping observations use kernel-main-elf and retain source-kind traces, raw smaps and present bits without PFNs. The current Portable packed range has at most 49 of 5,070 pages present across samples, while the preceding source had all 4,912 pages present. Local integer post-execution median RSS is 24.34 MiB (earlier run: 41.50 MiB), and retained objects 32.12 MiB (earlier: 49.31 MiB). These are separate unscored local runs, not a controlled before/after campaign or physical-RAM savings. Asynchronous sampling competes on the same CPU and may miss transients. This source-selection evidence does not explain the CI gap or enter scored outputs; exact observations and boundaries are retained in mapping-summary.json in the raw archive. The packed Portable native payload also grew by about 0.6 MiB between these local builds. Factoring the Array-only lookup and pruning unused program imports are follow-up candidates, with no RSS saving established yet.",'',
f"[Verification record]({STEM}.json) · [Lossless raw archive]({STEM}-verification.tar.xz) · [Matched measurements](precompiled-comparison.md)."]
a=record['archive'];lines+=['',f"The archive contains {a['member_count']:,} regular files and {a['expanded_bytes']:,} expanded bytes, with a SHA-256 per member. Streaming round-trip verification bounds expansion to 2 GiB, members to 128 MiB and compressed size to 32 MiB. Executables and serialized native images are excluded."]
(ROOT/'docs/rust-rewrite'/f'{STEM}.md').write_text('\n'.join(lines)+'\n')
contract=ROOT/'docs/rust-rewrite/contracts/immutable-runtime-build-package.md';text=contract.read_text();old='The 2026-10-27 source-reader extension and its malformed-header, mapping, range\nand actual-source controls are implemented; whole-batch verification is pending.'
assert old in text;text=text.replace(old,f'The 2026-10-27 source-reader extension passed all 18 runtime-image cases within\nthe [{native:,}-case native checkpoint](../{STEM}.md), followed by {conformance:,}\noriginal selected Test262 executions. The record retains exact source identities\nand fresh unscored file-source observations.');contract.write_text(text)
contract=ROOT/'docs/rust-rewrite/contracts/proxy-target-descriptor-completion.md';text=contract.read_text();old='These controls\nare authored and unexecuted.';assert old in text;text=text.replace(old,f'These controls\npassed within the [{native:,}-case native checkpoint](../{STEM}.md), including\nall 209 GC-entry cases and {conformance:,} original selected Test262 executions.');contract.write_text(text)
subprocess.run([sys.executable,'-B',str(BASE/'check-publication.py')],cwd=ROOT,check=True)
