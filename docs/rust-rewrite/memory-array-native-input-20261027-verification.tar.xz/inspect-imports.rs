//! Inert structural observations, not a reachability proof or rewriting pass.
use std::{collections::BTreeSet, error::Error, fs};
use wasmparser::{ElementItems, ElementKind, ExternalKind, Operator, Parser, Payload, TypeRef};
fn main() -> Result<(), Box<dyn Error>> {
    println!("file\tfunction_imports\tglobal_imports\tbody_function_import_refs\tbody_global_import_refs\tdeclared_function_imports\ttypes\tbodies\tcustom_sections");
    for file in std::env::args().skip(1) {
        let bytes = fs::read(&file)?;
        assert!(bytes.len() <= 16 * 1024 * 1024);
        let (mut funcs, mut globals, mut types, mut bodies) = (0, 0, 0, 0);
        let (mut function_refs, mut global_refs, mut declared) = (BTreeSet::new(), BTreeSet::new(), BTreeSet::new());
        let mut custom = Vec::new();
        for payload in Parser::new(0).parse_all(&bytes) {
            match payload? {
                Payload::ImportSection(reader) => for import in reader.into_imports() {
                    match import?.ty { TypeRef::Func(_) => funcs += 1, TypeRef::Global(_) => globals += 1, _ => {} }
                },
                Payload::TypeSection(reader) => for group in reader { types += group?.into_types().count(); },
                Payload::CodeSectionEntry(body) => {
                    bodies += 1;
                    let mut ops = body.get_operators_reader()?;
                    while !ops.eof() { match ops.read()? {
                        Operator::Call { function_index } | Operator::ReturnCall { function_index } | Operator::RefFunc { function_index } => { function_refs.insert(function_index); },
                        Operator::GlobalGet { global_index } | Operator::GlobalSet { global_index } => { global_refs.insert(global_index); },
                        _ => {}
                    }}
                },
                Payload::ExportSection(reader) => for entry in reader {
                    let export = entry?;
                    // Report exported imported functions/globals among body references conservatively.
                    match export.kind { ExternalKind::Func => { function_refs.insert(export.index); }, ExternalKind::Global => { global_refs.insert(export.index); }, _ => {} }
                },
                Payload::ElementSection(reader) => for entry in reader {
                    let element = entry?;
                    if matches!(element.kind, ElementKind::Declared) {
                        if let ElementItems::Functions(indices) = element.items { for index in indices { declared.insert(index?); } }
                    }
                },
                Payload::CustomSection(reader) => custom.push(reader.name().to_owned()),
                _ => {}
            }
        }
        println!("{file}\t{funcs}\t{globals}\t{}\t{}\t{}\t{types}\t{bodies}\t{}", function_refs.range(..funcs).count(), global_refs.range(..globals).count(), declared.range(..funcs).count(), custom.join(","));
    }
    Ok(())
}
