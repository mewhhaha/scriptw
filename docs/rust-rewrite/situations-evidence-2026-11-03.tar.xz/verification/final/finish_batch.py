import hashlib,json,pathlib,re,subprocess,sys,time
root=pathlib.Path.cwd();base=root/'target/performance-climb-env-20261103'
records=[]
def run(label,argv,timeout=1800,allowed=(0,)):
 print('START',label,flush=True);start=time.monotonic_ns()
 with (base/(label+'.stdout')).open('xb') as out,(base/(label+'.stderr')).open('xb') as err:
  p=subprocess.run(argv,cwd=root,stdout=out,stderr=err,timeout=timeout)
 records.append(dict(label=label,argv=argv,exit_code=p.returncode,elapsed_ns=time.monotonic_ns()-start));(base/'pipeline.json').write_text(json.dumps(records,indent=2)+'\n')
 print('END',label,p.returncode,flush=True);assert p.returncode in allowed,label
 return p.returncode
# The existing Cargo producer is serial; its final event certifies all selected
# target artifacts before another build begins. No work is run while waiting.
deadline=time.monotonic()+1800
while True:
 rows=[]
 for line in (base/'native-build.stdout').read_text().splitlines():
  try:rows.append(json.loads(line))
  except ValueError:pass
 finished=[r for r in rows if r.get('reason')=='build-finished']
 if finished:
  assert finished[-1]['success'];break
 assert time.monotonic()<deadline,'native producer deadline'
 time.sleep(2)
run('aot-build',['cargo','test','--release','--locked','-p','scriptw-aot-wasm','--lib','--no-run','--message-format=json-render-diagnostics'])
rows=[json.loads(s) for s in (base/'aot-build.stdout').read_text().splitlines()]
a=next(r for r in rows if r.get('reason')=='compiler-artifact' and r.get('target',{}).get('name')=='scriptw_aot_wasm' and r.get('executable'))
binary=a['executable'];digest=hashlib.sha256(pathlib.Path(binary).read_bytes()).hexdigest()
for label,selector in [('storage','tests::module_synthetic_storage::'),('activation','arguments_protocol::'),('tables','tests::dense_switch::')]:
 run(label,[binary,selector,'--test-threads=1'])
 s=(base/(label+'.stdout')).read_text();summary=re.findall(r'test result: ok\. (\d+) passed; 0 failed',s);assert len(summary)==1 and int(summary[0])>0
run('aot-full',[binary,'--test-threads=1'],allowed=(0,101))
s=(base/'aot-full.stdout').read_text();failed=re.findall(r'^    (\S+)\s*$',s.split('failures:\n')[-1],re.M)
expected={
 'tests::bootstrap_compact_metadata::native_bootstrap_uses_complete_constructor_layouts_and_compact_remaining_native_metadata',
 'tests::error_demand_initialization::canonical_runtime_defers_the_complete_error_graph_with_a_void_realm_abi',
 'tests::intrinsic_property_layout_allocation::fresh_intrinsic_bootstrap_allocates_layout_records_not_per_property_records',
 'tests::ordered_bootstrap_allocation::eager_layout_births_keep_demand_recipe_and_constructor_allocation_owners'}
assert set(failed)==expected,failed
(base/'aot-summary.json').write_text(json.dumps(dict(executable=binary,executable_sha256=digest,failures=failed,classification='Four preexisting bootstrap assertions, independently reproduced on frozen prior test executable; not a passing full scope.'),indent=2)+'\n')
run('native',[sys.executable,'-B',str(base/'verify_native.py')])
run('build',['cargo','build','--release','--locked','-p','scriptw-cli','--example','compiler_precompiled_baseline','--example','rsc_baseline','--message-format=json-render-diagnostics'])
run('measure',[sys.executable,'-B',str(base/'measure_batch.py')])
