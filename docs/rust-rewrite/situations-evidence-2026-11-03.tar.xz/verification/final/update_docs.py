import json,pathlib,statistics
root=pathlib.Path.cwd();base=root/'target/performance-climb-env-20261103';docs=root/'docs/rust-rewrite'
r=json.loads((base/'campaign/report.json').read_text());assert r['complete'] and len(r['rows'])==312
cases={c['file']:c for c in r['cases']}
def score(name,actor):return cases[name]['runtimes'][actor]['median_ns']/1e6
def fast(name):return score(name,'scriptw-fast')
def speed(name):return score(name,'scriptw-speed')
a=json.loads((base/'fast-comparison-campaign/aggregate.json').read_text())
engines=a['engines'];candidate=engines['candidate'];v8=engines['v8']
def request(engine,mode):return statistics.median(engine['cases']['rsc-'+mode])/1e6
def phase(name):return statistics.median(p[name] for p in candidate['phase_processes'])
size=json.loads((base/'size/attribution.json').read_text());assert size['program_wasm_sha256']==candidate['identity']['program_wasm_sha256']
code=next(s['total_bytes'] for s in size['sections'] if s['id']==10)
data=next(s['total_bytes'] for s in size['sections'] if s['id']==11)
pbytes=size['program_wasm_bytes'];rbytes=candidate['identity']['runtime']['wasm_bytes'];mi=1048576
native=[p for p in r['preparations'] if p['actor']=='scriptw-fast']
if not native:
 print('Preparation keys',r['preparations'][0].keys());raise ValueError('missing Fast preparation')
fp=r['source_identity']['source_fingerprint']
rows='\n'.join(f"| `{c['file']}` | {score(c['file'],'scriptw-fast'):.3f} | {score(c['file'],'scriptw-speed'):.3f} | {score(c['file'],'v8'):.3f} |" for c in r['cases'])
p512={p['actor'].removeprefix('scriptw-'):next(c for c in p['cases'] if c['file']=='frame-branches512.js') for p in r['preparations']}
text=f'''## React Server Components

Measured **2026-11-03** with pinned React 19.3.1 and compiler `{fp[:12]}`.
Both sync and async Flight outputs match Node exactly.

| Engine | Sync · ms | Async · ms |
| --- | ---: | ---: |
| Scriptw | {request(candidate,'sync'):.3f} | {request(candidate,'async'):.3f} |
| Node 24.12.0 / V8 | {request(v8,'sync'):.3f} | {request(v8,'async'):.3f} |

![Matched retained RSC request timings](assets/rsc-current/runtime.svg)

Each engine uses eight fresh processes across two balanced blocks, with three
checked warmups and seven measured requests per mode. Each process retains one
Module/Realm and runs sync then async. Requests include full Flight serialization
and consumption; JSON encoding and exact-output checks follow timing. Values are
medians of process medians. Scriptc's React build failures remain unqualified;
client React/DOM is a separate open scope.

Cold Scriptw setup is **{phase('source_to_wasm')/1e9:.3f} s JavaScript → Wasm**,
**{phase('native_preparation')/1e9:.3f} s native preparation** and
**{phase('module_initialization')/1e6:.3f} ms module initialization**.
Program Wasm is **{pbytes:,} B** ({code:,} B code; {data:,} B data);
shared runtime Wasm is **{rbytes:,} B**. Native preparation, initialization and
input preparation precede request timing. Child peak RSS includes compilation
and process history; it is not the live guest heap.

![RSC cold compilation phases](assets/rsc-current/compilation.svg)

Scriptw uses Wasmtime 47 **Fast / OptLevel::None / SinglePass**, a generic target,
one CPU, 16-MiB copying GC and the recorded stack/deadline/cache settings.
The [earlier CPU/caller diagnosis](react-attribution-current.json) belongs to its
recorded compiler, before global-start selection and activation pruning. Its
instruction counts, resolver shares and stack-frame sizes have not been
re-measured for this build. They are hypotheses for a new profile, not current
cost percentages. Total allocations remain unmeasured.

Runtime ABI 47 supplies bounded UTF-8 codecs, byte streams with default readers,
events, abort signals and tasks for these fixtures. Fetch/Request/URL integration,
DOM nodes and full WHATWG conformance remain unsupported or unverified.

[Current report and process receipts](rsc-current.json) ·
[Size attribution](rsc-wasm-size-current.json) ·
[Inert evidence archive](situations-evidence-2026-11-03.tar.xz).

## Focused performance situations

Measured **2026-11-03**: 13 standalone Module programs, compiler `{fp[:12]}`
(base `6d5820654` plus the archived performance patch),
Node **24.12.0 / V8 13.6.233.17-node.37**, Rust **1.97.1**.
Each program has its own score, separate from RSC and fresh-entry kernels.
No aggregate score combines their arbitrary operation counts.

| Program · retained call | Scriptw Fast · ms | Scriptw Speed · ms | V8 · ms |
| --- | ---: | ---: | ---: |
{rows}

Each value is the median of eight fresh-process medians across two balanced
blocks. Every process initializes one Module/Realm, then runs three checked
warmups and seven measured calls. Four inputs rotate identically in every actor;
every call checks an independently computed integer checksum. Bars show current
configurations; whiskers span the eight process medians. Block medians and
process summaries remain in the [data](situations-current.json).

Scriptw uses Wasmtime 47: **Fast = None / SinglePass**, **Speed = Speed /
Backtracking**, generic target, 16-MiB copying GC, one CPU, 4-GiB cap and no swap.
JavaScript/Wasm/native compilation, module initialization and `prepare(input)`
precede the public `run()` clock. Every Wasmtime consumer has its compiler disabled.
Node uses the same source bytes in `vm.SourceTextModule`, with normal JIT and
natural GC; three warmups do not establish optimized steady state. Timings include
each runtime's public-call bridge and `print` conversion/capture; output draining
and validation follow timing. The empty control is shown without subtraction.
Excluded setup can influence timed GC, feedback and JIT invalidation.

### Global lookup

The four programs read six constructor values across 1,024 passes. Deep lookup
retains eight nested padding captures; the bound control captures constructor
references beside the worker. Proven unbound references in eligible ordinary
Module functions now start at the defining Realm's Global Environment Record,
retaining live lexicals, mutable properties and getters.

![Global lookup situations](assets/situations-current/global-lookup.svg)

Shallow/deep also differ in padding reads and arithmetic; their difference is not
pure lexical-depth cost. Bound aliases may fold and V8 may hoist global reads.
The V8 bound control varies with JIT history; retain process ranges and both
block medians rather than treating one ratio as stable. The getter score includes
getter calls and counter increments. Source counts are not executed lookup counts.

### Control-flow and call-site scaling

All four programs make **8,192** entries into a function with one, 32, 128 or 512
selected call sites, exercising every site with identical checksums. Eligible
dense integer switches use guarded Wasm `br_table` dispatch. Fast ranges from
**{fast('frame-compact.js'):.3f} to {fast('frame-branches512.js'):.3f} ms**;
Speed from **{speed('frame-compact.js'):.3f} to {speed('frame-branches512.js'):.3f} ms**.

![Control-flow and call-site scaling](assets/situations-current/frame-size.svg)

![Native program image growth](assets/situations-current/frame-native-image.svg)

The 512-site native P image is **{p512['fast']['native_serialized_bytes']/mi:.2f} MiB Fast /
{p512['speed']['native_serialized_bytes']/mi:.2f} MiB Speed**; portable P is
**{p512['fast']['program_wasm_bytes']/mi:.2f} MiB**. Serialized native images include
metadata and data. Compact dispatch uses a dynamic key and one polymorphic site;
switch arms use constant keys and separate sites. This does not isolate stack
frame growth or stack-probe cost. Call transport remains a separate hill.

### Arguments observation

Both programs make 1,024 strict ordinary calls with captured state, reassign a
formal parameter and compute the same result. The observed program also reads
the original `arguments[0]` and `arguments.length`. Eligible strict functions
omit unobservable arguments objects; Module planning removes unused synthetic
cells before capture hops finalize. Real captures and observers retain storage.
The observed case also loses unused `this`/`new.target` cells, so it is not an
untouched control for that change. Its arguments object remains observable.
The extra observation is timed work; the difference is not an allocation count.

![Arguments observation situations](assets/situations-current/arguments-observation.svg)

### Property mutation history

Both programs perform 8,192 variable-key reads over 64 records. Mutation setup
adds an accessor, deletes properties and restores the values before timing.
Both remain far slower than V8. Process ranges are wide; median shifts do not
establish a property-kernel improvement. The emitted path still performs object and key
conversions around packed-array indexing and record reads; that is a separate
optimization target. No compact/dictionary representation is assumed, and equal
string recipes do not establish distinct backing storage.

![Property mutation history situations](assets/situations-current/property-mutation-history.svg)

### Public-call control and verification

![Retained public-call control](assets/situations-current/control.svg)

[Generate/run selected programs](../../CONTRIBUTING.md#focused-performance-situations)
with `--case <file.js>`; choose `--policies fast` or `speed`.
Scriptc has no matched retained-Module consumer here. These programs expose
separate hills, not each mechanism's share of RSC time.

All **312** situation processes and **3,120** calls passed exact-output checks.
The balanced RSC campaign adds 24 processes, including a frozen prior-build
control; chart bars contain only the latest compiler and V8. Compiler changes
cover global-start selection, strict arguments omission, dense integer dispatch
and early synthetic Module storage pruning. Encoded-Wasm and semantic regressions
cover live globals/getters, Realm boundaries, captures, eval refusal, constructors,
arguments observers, switch fallthrough, TDZ, labels and abrupt completion.

Full workspace CI and pinned Test262 were not rerun. Detailed native/source
verification receipts and the four reproduced pre-existing AOT bootstrap failures
remain in the evidence. Workspace formatting fails on 13 unchanged files;
14 stale Intl identity recipes remain [owned](current-inventory.md).

[Report, identities and process summaries](situations-current.json) ·
[Checksummed UTF-8 evidence](situations-evidence-2026-11-03.tar.xz).

'''
p=docs/'benchmarks.md';old=p.read_text();start=old.index('## React Server Components');end=old.index('<!-- runtime-comparison-details:start -->');p.write_text(old[:start]+text+old[end:])
verification=json.loads((base/'native-verification.json').read_text())
verified={r['label']:int(r['summaries'][0][1]) for r in verification}
engine_total=verified['language']+verified['realm-modules']+6+837
assert engine_total==1724
p=root/'README.md';s=p.read_text()
start=s.index('| Sync |');end=s.index('\n\n![Retained RSC requests]',start)
s=s[:start]+f"| Sync | {request(candidate,'sync'):.2f} ms | {request(v8,'sync'):.3f} ms |\n| Async | {request(candidate,'async'):.2f} ms | {request(v8,'async'):.3f} ms |"+s[end:]
start=s.index('Cold Scriptw setup:');end=s.index('\n\n**Focused performance situations',start)
s=s[:start]+f'''Cold Scriptw setup: **{phase('source_to_wasm')/1e9:.2f} s JavaScript → Wasm**, **{phase('native_preparation')/1e9:.2f} s native preparation**,
and **{phase('module_initialization')/1e6:.2f} ms module initialization**. Program Wasm is **{pbytes/mi:.2f} MiB** ({code/mi:.2f} MiB
code, {data/mi:.2f} MiB data); shared runtime Wasm is **{rbytes/mi:.2f} MiB**.
[Size breakdown](docs/rust-rewrite/rsc-wasm-size-current.json) ·
[Benchmark details and caveats](docs/rust-rewrite/benchmarks.md) ·
[Recorded RSC build](docs/rust-rewrite/rsc-current.json).'''+s[end:]
start=s.index('Latest scoped verification');end=s.index('\n\n## Caveats',start)
s=s[:start]+f'''Latest scoped verification (**2026-11-03**): {engine_total:,} Engine cases covered
(837 unchanged Script cases reused), plus {verified['emission']} Wasm-emission, {verified['structure']} typed structural,
{verified['ir']} IR and 361 source-guard checks. AOT unit checks passed 628 cases;
four pre-existing bootstrap assertions still fail on both this and the prior build.
The focused benchmarks passed 3,120 checked calls; React RSC also passed exact
Flight checks. These scopes do not replace the published full Test262 run.
Full workspace CI was not rerun; formatting failures and 14 stale Intl recipes
remain [owned](docs/rust-rewrite/current-inventory.md).'''+s[end:]
p.write_text(s)
print('README and benchmark detail updated from final reports')
