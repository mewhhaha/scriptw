import hashlib,json,pathlib,re,subprocess,time
root=pathlib.Path.cwd();base=root/'target/performance-climb-env-20261103'
artifacts={}
for line in (base/'native-build.stdout').read_text().splitlines():
 row=json.loads(line)
 if row.get('reason')=='compiler-artifact' and row.get('executable') and row['profile']['test']:
  artifacts[row['target']['name']]=row
scopes=[('ir','scriptw_ir_integration',None),('emission','emission',None),('structure','structure_language',None),
 ('module-cells','aot_realm_modules','aot_module_captured_cells::'),
 ('module-realm','aot_realm_modules','pruned_module_entry_values_and_retained_context_captures_cross_realms'),
 ('language','aot_language',None),('realm-modules','aot_realm_modules',None),
 ('namespace-descriptors','aot_builtins','aot_from_property_descriptor_fields::module_namespace_descriptors_publish_enumerable_fields'),
 ('embedded-comparator','aot_builtins','aot_typed_array_numeric_callback::retained_embedding_comparator_survives_export_replacement_and_store_gc'),
 ('module-rejection','aot_builtins','aot_promise_rejection_policy::retained_async_module_completion_cannot_be_discarded_by_host_policy'),
 ('module-sync-policy','aot_builtins','aot_promise_rejection_policy::synchronous_modules_keep_the_selected_rejection_policy'),
 ('module-resource','aot_async','aot_async_resource_loops::async_module_resource_loops_retain_their_canonical_activation_owner'),
 ('module-imports','aot_async','aot_async_for_of_continuations::original_module_loop_catches_both_concurrent_import_rejections')]
records=[]
for label,target,selector in scopes:
 artifact=artifacts[target];binary=pathlib.Path(artifact['executable']);argv=[str(binary)]
 if selector:argv.append(selector)
 if selector and label not in ('module-cells','module-realm'):argv.append('--exact')
 argv+=['--test-threads=1'];start=time.monotonic_ns();print('START',label,flush=True)
 with (base/(label+'.stdout')).open('xb') as out,(base/(label+'.stderr')).open('xb') as err:
  result=subprocess.run(argv,cwd=root,stdout=out,stderr=err,timeout=1800)
 text=(base/(label+'.stdout')).read_text();summaries=re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;',text)
 row=dict(label=label,target=target,argv=argv,exit_code=result.returncode,elapsed_ns=time.monotonic_ns()-start,
          executable_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),summaries=summaries)
 records.append(row);(base/'native-verification.json').write_text(json.dumps(records,indent=2)+'\n')
 print('END',label,result.returncode,summaries,flush=True)
 assert result.returncode==0 and len(summaries)==1 and summaries[0][0]=='ok' and int(summaries[0][1])>0 and summaries[0][2]=='0'
print('All final native scopes passed; unchanged Script-only builtin/async scopes retained from first batch.',flush=True)
