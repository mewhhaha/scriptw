import hashlib,json,pathlib,subprocess,sys,time
root=pathlib.Path.cwd();base=root/'target/performance-climb-env-20261103';size=base/'size';records=[]
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def run(label,argv):
 print('START',label,flush=True);start=time.monotonic_ns()
 with (size/(label+'.stdout')).open('xb') as out,(size/(label+'.stderr')).open('xb') as err:
  p=subprocess.run(argv,cwd=root,stdout=out,stderr=err,timeout=900)
 records.append(dict(label=label,argv=argv,exit_code=p.returncode,elapsed_ns=time.monotonic_ns()-start));(size/'receipt.json').write_text(json.dumps(records,indent=2)+'\n')
 print('END',label,p.returncode,flush=True);assert p.returncode==0,label
end=time.monotonic()+3600
while True:
 p=base/'pipeline.json'
 if p.exists():
  rows=json.loads(p.read_text())
  if rows[-1]['label']=='measure':
   assert rows[-1]['exit_code']==0;break
 assert time.monotonic()<end,'final pipeline deadline';time.sleep(2)
rows=[json.loads(line) for line in (base/'build.stdout').read_text().splitlines()]
assert any(r.get('reason')=='build-finished' and r['success'] for r in rows)
engines=[r for r in rows if r.get('reason')=='compiler-artifact' and r.get('target',{}).get('name')=='scriptw_engine']
assert len(engines)==1, len(engines)
engine=engines[0];rlibs=[pathlib.Path(p) for p in engine['filenames'] if p.endswith('.rlib')];assert len(rlibs)==1
rlib=rlibs[0]
argv=['rustc','--edition=2021',str(size/'dump_rsc.rs'),'-L','dependency=target/release/deps','--extern','scriptw_engine='+str(rlib),'-C','link-arg=-fuse-ld=lld','-o',str(size/'dump-rsc')]
paths=sorted({p for r in rows if r.get('reason')=='build-script-executed' for p in r.get('linked_paths',[])})
for path in paths:argv+=['-L',path]
(size/'producer.json').write_text(json.dumps(dict(cargo_artifact=engine,cargo_log_sha256=digest(base/'build.stdout'),rlib_sha256=digest(rlib),diagnostic_source_sha256=digest(size/'dump_rsc.rs'),argv=argv),indent=2)+'\n')
run('dump-build',argv)
run('dump',[str(size/'dump-rsc'),str(size/'rsc-program.wasm'),str(size/'functions.txt')])
run('analysis',[sys.executable,'-B',str(size/'analyze.py'),'--program',str(size/'rsc-program.wasm'),'--aggregate',str(base/'fast-comparison-campaign/aggregate.json'),'--output',str(size/'attribution.json')])
# Publication stdout lives outside the additional-evidence directory. The archive
# sees only closed diagnostic logs and their completed receipt.
argv=[sys.executable,'-B',str(base/'publish.py'),'--output-dir',str(base/'publication-ready'),'--extra-text-evidence',str(size)]
with (base/'publication.stdout').open('xb') as out,(base/'publication.stderr').open('xb') as err:
 p=subprocess.run(argv,cwd=root,stdout=out,stderr=err,timeout=900)
print('END publication',p.returncode,flush=True);assert p.returncode==0
