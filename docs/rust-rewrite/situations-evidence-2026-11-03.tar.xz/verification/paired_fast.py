"""Unscored interleaved prior/current Fast consumers; no compilation in these processes."""
import hashlib,json,pathlib,statistics,subprocess,time,os,sys
root=pathlib.Path.cwd();sys.path.insert(0,str(root/'scripts'))
from limited_verification import require_kernel_budget
require_kernel_budget(4*1024**3);assert len(os.sched_getaffinity(0))==1
base=root/'target/performance-own-keys-20261103';prior=root/'target/performance-specialize-20261103';out=base/'paired-fast';out.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
reports={a:json.loads((d/'campaign/report.json').read_text()) for a,d in [('baseline',prior),('candidate',base)]};commands={a:{r['id']:r for r in report['commands']} for a,report in reports.items()};sources={a:{r['file']:r for r in report['rows'] if r['actor']=='scriptw-fast' and r['block']==r['round']==0} for a,report in reports.items()};names=[c['file'] for c in reports['candidate']['cases']];rows=[]
for name in names:
 for a in ['baseline','candidate']:
  raw=sources[a][name]['raw'];argv=commands[a][sources[a][name]['command']]['argv'];assert sha(pathlib.Path(argv[0]))==raw['executable_sha256'];assert sha(pathlib.Path(argv[2]))==raw['producer']['image_sha256'];assert raw['compiler_enabled'] is False
 assert sources['baseline'][name]['raw']['producer']['invocations']==sources['candidate'][name]['raw']['producer']['invocations']
 assert sources['baseline'][name]['raw']['producer']['original_source_sha256']==sources['candidate'][name]['raw']['producer']['original_source_sha256']
plan=dict(schema='scriptw-paired-fast-v1',unscored=True,source_reports={a:dict(path=str(d/'campaign/report.json'),sha256=sha(d/'campaign/report.json')) for a,d in [('baseline',prior),('candidate',base)]},cases=names,processes=208,limits='Eight fresh processes per build and case across two balanced blocks. Same pinned input rotation; three checked warmups and seven measured calls; native compiler disabled. Original producer/image/executable identities retained. This diagnoses inter-cohort drift; main V8/Fast/Speed charts remain the separately completed scored situation cohort.')
(out/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
for block in range(2):
 for rep in range(4):
  for i,name in enumerate(names):
   actors=['baseline','candidate']
   if (block+rep+i)%2:actors.reverse()
   for a in actors:
    label=f'b{block}-r{rep}-{a}-{name}';argv=commands[a][sources[a][name]['command']]['argv'];start=time.monotonic_ns()
    with (out/(label+'.stdout')).open('xb') as stdout,(out/(label+'.stderr')).open('xb') as stderr:p=subprocess.run(argv,stdout=stdout,stderr=stderr,timeout=120)
    assert p.returncode==0
    raw=json.loads((out/(label+'.stdout')).read_text());expected=sources[a][name]['raw']
    for field in ['source_fingerprint','executable_sha256','producer','shared_configuration']:assert raw[field]==expected[field],field
    obs=raw['observations'];assert len(obs)==10 and all(o['matched'] and o['completion']=='normal' for o in obs);values=[o['call_ns'] for o in obs if not o['warmup']];assert len(values)==7
    rows.append(dict(block=block,round=rep,actor=a,file=name,argv=argv,exit_code=0,elapsed_ns=time.monotonic_ns()-start,stdout=label+'.stdout',stderr=label+'.stderr',stdout_sha256=sha(out/(label+'.stdout')),median_ns=statistics.median(values)))
  print('COMPLETE',block,rep,flush=True)
  (out/'receipt.json').write_text(json.dumps(dict(complete=False,rows=rows),indent=2)+'\n')
summary={name:{a:dict(median_ns=statistics.median(r['median_ns'] for r in rows if r['file']==name and r['actor']==a),blocks=[statistics.median(r['median_ns'] for r in rows if r['file']==name and r['actor']==a and r['block']==block) for block in [0,1]]) for a in ['baseline','candidate']} for name in names}
(out/'receipt.json').write_text(json.dumps(dict(complete=True,rows=rows,summary=summary),indent=2)+'\n');print(json.dumps(summary),flush=True)
