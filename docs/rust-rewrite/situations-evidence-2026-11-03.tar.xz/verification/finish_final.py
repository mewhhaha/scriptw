import copy,hashlib,json,pathlib,re,subprocess,time
root=pathlib.Path.cwd();base=root/'target/performance-specialize-20261103';logs=base/'verification'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
finalsha=sha(base/'measured-source/manifest.json');records=[]
def run(label,argv,package=None,target=None):
 location=logs
 if label in ('build','source-guards-final'):location=base
 print('START',label,flush=True);start=time.monotonic_ns()
 with (location/(label+'.stdout')).open('xb') as out,(location/(label+'.stderr')).open('xb') as err:p=subprocess.run(argv,cwd=root,stdout=out,stderr=err,timeout=1800)
 row=dict(label=label,argv=argv,exit_code=p.returncode,elapsed_ns=time.monotonic_ns()-start,source_manifest_sha256=finalsha,stdout=(location/(label+'.stdout')).relative_to(base).as_posix(),stderr=(location/(label+'.stderr')).relative_to(base).as_posix())
 if package:
  summaries=re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;', (location/(label+'.stdout')).read_text());assert len(summaries)==1
  state,passed,failed,ignored=summaries[0];row.update(package=package,target=target,executable_sha256=sha(pathlib.Path(argv[0])),outcomes=dict(state=state,passed=int(passed),failed=int(failed),ignored=int(ignored)))
 records.append(row);(base/'corrected-native-verification.json').write_text(json.dumps(records,indent=2)+'\n');print('END',label,p.returncode,flush=True);assert p.returncode==0,label
 return row
end=time.monotonic()+3600
while True:
 path=base/'remaining-native-verification.json'
 if path.exists() and len(read(path))==8:break
 assert time.monotonic()<end;time.sleep(2)
remaining=read(path)
assert all(r['exit_code']==0 for r in remaining if r['target'] not in ('runtime_link','structure_async')),[(r['target'],r['outcomes']) for r in remaining]
assert subprocess.check_output(['git','diff','--binary','HEAD','--','crates','docs/rust-rewrite/contracts'])==(base/'measured-source/tracked.patch').read_bytes()
run('source-guards-final',['python3','-B','scripts/check-source-guards.py','--output',str(base/'source-guards-final')])
run('corrected-native-build',['cargo','test','--release','--locked','-p','scriptw-aot-wasm','--test','modules_realms','--test','runtime_link','--test','structure_async','--no-run','--message-format=json-render-diagnostics'])
events=[json.loads(line) for line in (logs/'corrected-native-build.stdout').read_text().splitlines()];assert any(r.get('reason')=='build-finished' and r['success'] for r in events)
artifacts={r['target']['name']:r['executable'] for r in events if r.get('reason')=='compiler-artifact' and r.get('executable') and r['profile']['test']}
for target in ('modules_realms','runtime_link','structure_async'):run(target+'-corrected',[artifacts[target],'--test-threads=1'],'scriptw-aot-wasm',target)
run('build',['cargo','build','--release','--locked','-p','scriptw-cli','--example','compiler_precompiled_baseline','--example','rsc_baseline','--message-format=json-render-diagnostics'])
report=copy.deepcopy(read(base/'native-verification-resumed.json'));report['source_manifest_sha256']=finalsha;report['complete']=True;report['structural_test_source_equivalence']=read(base/'structural-test-source-equivalence.json');report['ir_source_equivalence']=read(base/'ir-source-equivalence.json')
allrows=report['scopes']+remaining+[r for r in records if r.get('package')];report['scopes']=[]
for row in allrows:
 row['qualified_final_source_manifest_sha256']=finalsha
 if row['exit_code'] and row['target']!='scriptw_aot_wasm':report['superseded_scopes'].append(row)
 else:report['scopes'].append(row)
report['producer_commands'] += [r for r in records if r['label'] in ('corrected-native-build','build')]
report['source_guard_command']=next(r for r in records if r['label']=='source-guards-final');report['limits']='Fresh native Engine/IR scopes; unchanged relevant source qualification preserves earlier passing scopes. Four preexisting AOT failures remain counted. No full workspace CI or pinned Test262 rerun.'
(base/'native-verification-final.json').write_text(json.dumps(report,indent=2)+'\n');print('FINAL NATIVE COMPLETE',flush=True)
for name,script in [('measure','measure_batch.py'),('pmu','profile_candidate.py')]:
 print('START',name,flush=True)
 with (base/(name+'-pipeline.stdout')).open('xb') as out,(base/(name+'-pipeline.stderr')).open('xb') as err:p=subprocess.run(['python3','-B',str(base/script)],stdout=out,stderr=err,cwd=root,timeout=3600)
 print('END',name,p.returncode,flush=True);assert p.returncode==0,name
