import hashlib,json,pathlib,re,subprocess,time
root=pathlib.Path.cwd();base=root/'target/performance-specialize-20261103';logs=base/'verification'
report=json.loads((base/'native-verification-resumed.json').read_text());records=[]
events=[json.loads(line) for line in (logs/'native-build.stdout').read_text().splitlines()]
native={r['target']['name']:r['executable'] for r in events if r.get('reason')=='compiler-artifact' and r.get('executable') and r['profile']['test']}
for target in ('runtime_link','structure_builtins','structure_async','intl_temporal','aot_language','aot_builtins','aot_async','aot_realm_modules'):
 binary=pathlib.Path(native[target]);argv=[str(binary),'--test-threads=1'];start=time.monotonic_ns();print('START',target,flush=True)
 with (logs/(target+'.stdout')).open('xb') as out,(logs/(target+'.stderr')).open('xb') as err:p=subprocess.run(argv,cwd=root,stdout=out,stderr=err,timeout=1800)
 summaries=re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;', (logs/(target+'.stdout')).read_text());assert len(summaries)==1
 state,passed,failed,ignored=summaries[0];package='scriptw-aot-wasm'
 if target.startswith('aot_'):package='scriptw-engine'
 row=dict(label=target,package=package,target=target,argv=argv,executable_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),source_manifest_sha256=report['source_phase_manifest_sha256'],exit_code=p.returncode,elapsed_ns=time.monotonic_ns()-start,stdout='verification/'+target+'.stdout',stderr='verification/'+target+'.stderr',outcomes=dict(state=state,passed=int(passed),failed=int(failed),ignored=int(ignored)))
 records.append(row);(base/'remaining-native-verification.json').write_text(json.dumps(records,indent=2)+'\n');print('END',target,p.returncode,summaries,flush=True)
print('All remaining scopes collected; failures remain failures.',flush=True)
