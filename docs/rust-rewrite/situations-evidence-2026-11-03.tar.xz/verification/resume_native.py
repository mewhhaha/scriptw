"""Resume the preserved native batch after one independent structural-test fix.

Run inside scripts/limited_verification.py after structure-language-rebuild ends.
Original reports and logs are never overwritten. No prior passing scope reruns.
"""
import copy
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
BASE = Path(__file__).resolve().parent
LOGS = BASE / 'verification'
PROGRESS = BASE / 'native-verification-resumed.json'
FINAL = BASE / 'native-verification-final.json'
SUMMARY = re.compile(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;')
REMAINING = ('modules_realms', 'runtime_link', 'structure_builtins', 'structure_async',
             'intl_temporal', 'aot_language', 'aot_builtins', 'aot_async', 'aot_realm_modules')
sys.path.insert(0, str(ROOT / 'scripts'))
from limited_verification import require_kernel_budget


def need(condition, reason):
    if not condition:
        raise RuntimeError(reason)


def digest(path):
    result = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for value in iter(lambda: stream.read(1024 * 1024), b''):
            result.update(value)
    return result.hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def encoded(value):
    return (json.dumps(value, indent=2) + '\n').encode()


def save(report):
    temporary = PROGRESS.with_suffix('.json.tmp')
    temporary.write_bytes(encoded(report))
    os.replace(temporary, PROGRESS)


def unchanged_source():
    snapshot = BASE / 'measured-source'
    manifest = read(snapshot / 'manifest.json')
    patch = subprocess.check_output(['git', 'diff', '--binary', 'HEAD', '--', 'crates', 'docs/rust-rewrite/contracts'], cwd=ROOT)
    need(patch == (snapshot / 'tracked.patch').read_bytes(), 'final tracked source changed')
    for name, expected in manifest['files'].items():
        need(digest(ROOT / name) == expected, 'final new source changed: ' + name)


def artifacts(path):
    events = [json.loads(line) for line in path.read_text().splitlines()]
    finished = [row for row in events if row.get('reason') == 'build-finished']
    need(len(finished) == 1 and finished[0]['success'], 'Cargo producer is not successfully complete: ' + str(path))
    return {row['target']['name']: row for row in events
            if row.get('reason') == 'compiler-artifact' and row.get('executable') and row['profile']['test']}


def run_scope(report, label, target, binary, source_sha):
    argv = [str(binary), '--test-threads=1']
    package = 'scriptw-aot-wasm'
    if target.startswith('aot_'):
        package = 'scriptw-engine'
    print('START', label, flush=True)
    executable_sha = digest(binary)
    identity = binary.stat()
    start = time.monotonic_ns()
    out, err = LOGS / (label + '.stdout'), LOGS / (label + '.stderr')
    with out.open('xb') as stdout, err.open('xb') as stderr:
        process = subprocess.run(argv, cwd=ROOT, stdout=stdout, stderr=stderr, timeout=1800)
    summaries = SUMMARY.findall(out.read_text())
    need(len(summaries) == 1, 'missing native summary: ' + label)
    state, passed, failed, ignored = summaries[0]
    after = binary.stat()
    need((identity.st_ino, identity.st_size, identity.st_mtime_ns) == (after.st_ino, after.st_size, after.st_mtime_ns), 'test executable changed while running')
    row = dict(label=label, package=package, target=target, argv=argv,
        executable_sha256=executable_sha, executable_bytes=identity.st_size,
        source_manifest_sha256=source_sha,
        qualified_final_source_manifest_sha256=report['source_manifest_sha256'],
        exit_code=process.returncode, elapsed_ns=time.monotonic_ns() - start,
        stdout=out.relative_to(BASE).as_posix(), stderr=err.relative_to(BASE).as_posix(),
        outcomes=dict(state=state, passed=int(passed), failed=int(failed), ignored=int(ignored)))
    report['scopes'].append(row)
    save(report)
    print('END', label, process.returncode, summaries, flush=True)
    need(process.returncode == 0 and state == 'ok' and int(passed) > 0 and failed == ignored == '0', 'native scope failed: ' + label)
    return row


def main():
    require_kernel_budget(4 * 1024**3)
    need(len(os.sched_getaffinity(0)) == 1, 'resume requires one inherited CPU')
    need(not FINAL.exists(), 'final native report already exists')
    unchanged_source()
    correction = read(BASE / 'structural-test-source-equivalence.json')
    phase_sha, final_sha = correction['phase_manifest_sha256'], correction['final_manifest_sha256']
    need(digest(BASE / 'measured-source/manifest.json') == final_sha, 'final snapshot differs')
    raw_path = BASE / 'native-verification-attempt4.json'
    original = read(raw_path)
    need(original['source_manifest_sha256'] == phase_sha, 'original native phase differs')
    if PROGRESS.exists():
        report = read(PROGRESS)
        need(report['source_manifest_sha256'] == final_sha, 'resume report belongs to another source')
    else:
        scopes, commands, superseded = [], [], []
        for original_row in original['scopes']:
            row = copy.deepcopy(original_row)
            row.setdefault('source_manifest_sha256', phase_sha)
            row['qualified_final_source_manifest_sha256'] = final_sha
            if row.get('package') is None:
                commands.append(row)
                continue
            if row['target'] == 'structure_language' and row['exit_code'] != 0:
                need(row['outcomes'] == dict(state='FAILED', passed=152, failed=1, ignored=0), 'original structural failure differs')
                row['superseded_reason'] = 'One stale Operation::Call destructuring marker; corrected independent structural test rebuild replaces this scope. Original failure remains retained.'
                superseded.append(row)
                continue
            need(row['exit_code'] == 0 or (row['target'] == 'scriptw_aot_wasm' and row['exit_code'] == 101 and row['outcomes']['failed'] == 4), 'unexpected prior failure; do not silently drop it')
            scopes.append(row)
        need(len(superseded) == 1, 'missing original structural failure')
        report = dict(complete=False, source_manifest_sha256=final_sha,
            source_phase_manifest_sha256=phase_sha, original_raw_report=dict(path=raw_path.relative_to(ROOT).as_posix(), sha256=digest(raw_path)),
            ir_source_equivalence=read(BASE / 'ir-source-equivalence.json'),
            structural_test_source_equivalence=correction,
            scopes=scopes, producer_commands=commands, superseded_scopes=superseded,
            metadata_repairs=[dict(action='Move non-test Cargo records out of scopes into producer_commands; preserve original rows and logs. No test verdict is changed.')],
            limits='Passing scopes are preserved with original source/binary identities and qualified unchanged inputs. Corrected structure_language reruns alone; remaining scopes run once. Four AOT failures stay failures. No full workspace CI or pinned Test262 rerun.')
        save(report)
    corrected = [row for row in report['scopes'] if row['target'] == 'structure_language']
    if not corrected:
        rebuild_path = LOGS / 'structure-language-rebuild.stdout'
        artifact = artifacts(rebuild_path)['structure_language']
        row = run_scope(report, 'structure-language-corrected', 'structure_language', Path(artifact['executable']), final_sha)
        need(row['outcomes']['passed'] == 153, 'corrected structural target count differs')
        report['structural_rebuild_producer'] = dict(stdout=rebuild_path.relative_to(BASE).as_posix(),
            stderr=(LOGS / 'structure-language-rebuild.stderr').relative_to(BASE).as_posix(),
            stdout_sha256=digest(rebuild_path), cargo_build_finished_success=True,
            source_manifest_sha256=final_sha, selected_artifact=artifact,
            process_exit_code_not_recorded_by_external_producer=True)
        save(report)
    else:
        need(len(corrected) == 1 and corrected[0]['exit_code'] == 0 and corrected[0]['outcomes']['passed'] == 153, 'corrected structural scope is not passing')
    native = artifacts(LOGS / 'native-build.stdout')
    for target in REMAINING:
        completed = [row for row in report['scopes'] if row['label'] == target and row['target'] == target]
        if completed:
            need(len(completed) == 1 and completed[0]['exit_code'] == 0, 'previous resumed scope failed: ' + target)
            continue
        run_scope(report, target, target, Path(native[target]['executable']), phase_sha)
    unchanged_source()
    builds = [row for row in report['producer_commands'] if row['label'] == 'build']
    if not builds:
        argv = ['cargo', 'build', '--release', '--locked', '-p', 'scriptw-cli', '--example', 'compiler_precompiled_baseline', '--example', 'rsc_baseline', '--message-format=json-render-diagnostics']
        print('START build', flush=True)
        start = time.monotonic_ns()
        out, err = BASE / 'build.stdout', BASE / 'build.stderr'
        with out.open('xb') as stdout, err.open('xb') as stderr:
            process = subprocess.run(argv, cwd=ROOT, stdout=stdout, stderr=stderr, timeout=1800)
        report['producer_commands'].append(dict(label='build', argv=argv, exit_code=process.returncode,
            elapsed_ns=time.monotonic_ns() - start, source_manifest_sha256=final_sha,
            stdout=out.relative_to(BASE).as_posix(), stderr=err.relative_to(BASE).as_posix()))
        save(report)
        print('END build', process.returncode, flush=True)
        need(process.returncode == 0, 'final benchmark producer build failed')
        events = [json.loads(line) for line in out.read_text().splitlines()]
        need(any(row.get('reason') == 'build-finished' and row['success'] for row in events), 'final benchmark producer is incomplete')
    else:
        need(len(builds) == 1 and builds[0]['exit_code'] == 0, 'previous final producer build failed')
    unchanged_source()
    report['complete'] = True
    save(report)
    with FINAL.open('xb') as output:
        output.write(encoded(report))
    print('Native scopes and final benchmark producers complete:', FINAL, flush=True)


if __name__ == '__main__':
    main()
