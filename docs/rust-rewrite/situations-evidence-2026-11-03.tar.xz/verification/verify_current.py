import hashlib,json,pathlib,re,subprocess,time
root=pathlib.Path.cwd();base=root/'target/performance-specialize-20261103';logs=base/'verification-final';logs.mkdir(exist_ok=True);records=[];commands=[]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
manifest=sha(base/'measured-source/manifest.json')
for label in ('ir-candidates','ir-full'):
 row=json.loads((base/(label+'.json')).read_text());state,passed,failed,ignored=row.pop('summaries')[0];row['outcomes']=dict(state=state,passed=int(passed),failed=int(failed),ignored=int(ignored));row['original_source_manifest_sha256']=row['source_manifest_sha256'];row['qualified_final_source_manifest_sha256']=manifest;records.append(row)
def save(complete=False):
 (base/'native-verification-current.json').write_text(json.dumps(dict(complete=complete,source_manifest_sha256=manifest,scopes=records,producer_commands=commands,ir_source_equivalence=json.loads((base/'ir-source-equivalence.json').read_text()),limits='Fresh native scopes; IR relevant inputs unchanged with original tested source and binary identities preserved. Four preexisting AOT failures stay failures. No full workspace CI or pinned Test262 rerun.'),indent=2)+'\n')
def run(label,argv,package=None,target=None,allowed=(0,)):
 print('START',label,flush=True);start=time.monotonic_ns();location=logs
 if label in ('build','source-guards-final'):location=base
 with (location/(label+'.stdout')).open('xb') as out,(location/(label+'.stderr')).open('xb') as err:p=subprocess.run(argv,cwd=root,stdout=out,stderr=err,timeout=1800)
 row=dict(label=label,argv=argv,source_manifest_sha256=manifest,exit_code=p.returncode,elapsed_ns=time.monotonic_ns()-start,stdout=(location/(label+'.stdout')).relative_to(base).as_posix(),stderr=(location/(label+'.stderr')).relative_to(base).as_posix())
 if package:
  summaries=re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;',(location/(label+'.stdout')).read_text());assert len(summaries)==1
  state,passed,failed,ignored=summaries[0];row.update(package=package,target=target,executable_sha256=sha(pathlib.Path(argv[0])),outcomes=dict(state=state,passed=int(passed),failed=int(failed),ignored=int(ignored)));assert int(passed)+int(failed)>0 and int(ignored)==0;records.append(row)
 else:commands.append(row)
 save();print('END',label,p.returncode,flush=True);assert p.returncode in allowed,label
 return row
def artifacts(path):
 rows=[json.loads(line) for line in path.read_text().splitlines()];assert any(r.get('reason')=='build-finished' and r['success'] for r in rows)
 return {r['target']['name']:r for r in rows if r.get('reason')=='compiler-artifact' and r.get('executable') and r['profile']['test']}
assert subprocess.check_output(['git','diff','--binary','HEAD','--','crates','docs/rust-rewrite/contracts'])==(base/'measured-source/tracked.patch').read_bytes()
run('source-guards-final',['python3','-B','scripts/check-source-guards.py','--output',str(base/'source-guards-final')])
# Compile early to resolve the measured source-size boundary before broad checks.
run('language-build',['cargo','test','--release','--locked','-p','scriptw-engine','--test','aot_language','--no-run','--message-format=json-render-diagnostics'])
language=artifacts(logs/'language-build.stdout')['aot_language']['executable']
for label,selector in [('size-for-in','aot_for_in_codegen::'),('size-dense-read','aot_numeric_call_rows::dense_number_array_region_misses_preserve_getters_proxies_and_abrupt_order'),('local-call-semantics','aot_local_argument_calls::'),('raw-property-semantics','aot_raw_key_own_data::')]:run(label,[language,selector,'--test-threads=1'],'scriptw-engine','aot_language')
run('aot-build',['cargo','test','--release','--locked','-p','scriptw-aot-wasm','--lib','--no-run','--message-format=json-render-diagnostics'])
aot=artifacts(logs/'aot-build.stdout')['scriptw_aot_wasm']['executable']
for label,selector in [('local-calls','tests::local_argument_calls::'),('raw-properties','tests::raw_key_own_data::'),('local-plan','function_entry::local_arguments::tests::')]:run(label,[aot,selector,'--test-threads=1'],'scriptw-aot-wasm','scriptw_aot_wasm')
run('aot-full',[aot,'--test-threads=1'],'scriptw-aot-wasm','scriptw_aot_wasm',allowed=(101,))
expected={'tests::bootstrap_compact_metadata::native_bootstrap_uses_complete_constructor_layouts_and_compact_remaining_native_metadata','tests::error_demand_initialization::canonical_runtime_defers_the_complete_error_graph_with_a_void_realm_abi','tests::intrinsic_property_layout_allocation::fresh_intrinsic_bootstrap_allocates_layout_records_not_per_property_records','tests::ordered_bootstrap_allocation::eager_layout_births_keep_demand_recipe_and_constructor_allocation_owners'}
failures=set(re.findall(r'^    (\S+)\s*$',(logs/'aot-full.stdout').read_text().split('failures:\n')[-1],re.M));assert failures==expected
names=['emission','structure_language','modules_realms','runtime_link','structure_builtins','structure_async','intl_temporal','aot_language','aot_builtins','aot_async','aot_realm_modules'];argv=['cargo','test','--release','--locked','-p','scriptw-aot-wasm','-p','scriptw-engine']
for name in names:argv+=['--test',name]
run('native-build',argv+['--no-run','--message-format=json-render-diagnostics']);native=artifacts(logs/'native-build.stdout')
for name in names:
 package='scriptw-aot-wasm'
 if name.startswith('aot_'):package='scriptw-engine'
 run(name,[native[name]['executable'],'--test-threads=1'],package,name)
run('build',['cargo','build','--release','--locked','-p','scriptw-cli','--example','compiler_precompiled_baseline','--example','rsc_baseline','--message-format=json-render-diagnostics'])
save(True);print('CURRENT NATIVE COMPLETE',flush=True)
for label,script in [('measure','measure_batch.py'),('pmu','profile_candidate.py'),('size','size/static_and_publish.py')]:
 print('START',label,flush=True)
 with (base/(label+'-pipeline.stdout')).open('xb') as out,(base/(label+'-pipeline.stderr')).open('xb') as err:p=subprocess.run(['python3','-B',str(base/script)],cwd=root,stdout=out,stderr=err,timeout=3600)
 print('END',label,p.returncode,flush=True);assert p.returncode==0,label
