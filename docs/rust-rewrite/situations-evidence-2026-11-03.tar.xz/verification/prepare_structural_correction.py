"""Freeze the one-line structural-test correction without changing product source."""
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess

ROOT = Path(__file__).resolve().parents[2]
BASE = Path(__file__).resolve().parent
TEST = 'crates/scriptw-aot-wasm/tests/structure_language/object_environment_logical_assignment_structure.rs'
OLD = b'Operation::Call { args, direct_eval } => {'
NEW = b'Operation::Call {'


def sha(value):
    return hashlib.sha256(value).hexdigest()


def encoded(value):
    return (json.dumps(value, indent=2) + '\n').encode()


def read(path):
    return json.loads(path.read_text())


def need(ok, reason):
    if not ok:
        raise RuntimeError(reason)


def chunks(value):
    return {m.group(1): m.group(0) for m in re.finditer(
        r'^diff --git a/(.*?) b/.*?(?=^diff --git |\Z)', value.decode(), re.M | re.S)}


def preserve(source, destination):
    if destination.exists():
        need(destination.read_bytes() == source.read_bytes(), 'preserved receipt differs: ' + str(destination))
    else:
        shutil.copyfile(source, destination)


def main():
    current = BASE / 'measured-source'
    prior_manifest_bytes = (current / 'manifest.json').read_bytes()
    prior_manifest = json.loads(prior_manifest_bytes)
    native_report = read(BASE / 'native-verification.json')
    phase_sha = native_report['source_manifest_sha256']
    need(sha(prior_manifest_bytes) == phase_sha, 'current snapshot differs from executed native phase')
    prior_patch = (current / 'tracked.patch').read_bytes()
    need(sha(prior_patch) == prior_manifest['tracked_patch_sha256'], 'native-phase patch differs')
    final_patch = subprocess.check_output(['git', 'diff', '--binary', 'HEAD', '--', 'crates', 'docs/rust-rewrite/contracts'], cwd=ROOT)
    old_chunks, new_chunks = chunks(prior_patch), chunks(final_patch)
    changed = {name for name in old_chunks.keys() | new_chunks.keys() if old_chunks.get(name) != new_chunks.get(name)}
    need(changed == {TEST} and TEST not in old_chunks, 'correction must change only the previously unmodified structural test')
    original = subprocess.check_output(['git', 'show', prior_manifest['base_commit'] + ':' + TEST], cwd=ROOT)
    final_test = (ROOT / TEST).read_bytes()
    need(original.count(OLD) == 1 and final_test == original.replace(OLD, NEW, 1), 'correction is not the exact one-line marker change')
    for name, digest in prior_manifest['files'].items():
        need(sha((current / name).read_bytes()) == digest == sha((ROOT / name).read_bytes()), 'new-file source changed: ' + name)
    phase = BASE / 'measured-source-native-phase'
    need(not phase.exists(), 'native-phase snapshot already exists; do not prepare twice')
    shutil.copytree(current, phase)
    preserve(BASE / 'native-verification.json', BASE / 'native-verification-attempt4.json')
    preserve(BASE / 'ir-source-equivalence.json', BASE / 'ir-source-equivalence-before-structural-correction.json')
    final_manifest = dict(prior_manifest, tracked_patch_sha256=sha(final_patch))
    final_manifest_bytes = encoded(final_manifest)
    final_sha = sha(final_manifest_bytes)
    (current / 'tracked.patch').write_bytes(final_patch)
    (current / 'manifest.json').write_bytes(final_manifest_bytes)
    ir_receipt = read(BASE / 'ir-full.json')
    ir_phase_sha = ir_receipt['source_manifest_sha256']
    ir_phase = BASE / 'measured-source-ir-phase'
    need(sha((ir_phase / 'manifest.json').read_bytes()) == ir_phase_sha, 'preserved IR phase differs')
    prefixes = ('crates/scriptw-ir/', 'crates/scriptw-front/')
    ir_chunks = {name: value for name, value in chunks((ir_phase / 'tracked.patch').read_bytes()).items() if name.startswith(prefixes)}
    final_ir_chunks = {name: value for name, value in new_chunks.items() if name.startswith(prefixes)}
    ir_files = {name: digest for name, digest in read(ir_phase / 'manifest.json')['files'].items() if name.startswith(prefixes)}
    final_ir_files = {name: digest for name, digest in final_manifest['files'].items() if name.startswith(prefixes)}
    need(ir_chunks == final_ir_chunks and ir_files == final_ir_files, 'IR/front-end inputs changed')
    (BASE / 'ir-source-equivalence.json').write_bytes(encoded(dict(
        phase_manifest_sha256=ir_phase_sha, final_manifest_sha256=final_sha, unchanged=True,
        phase_snapshot=ir_phase.name,
        scope='All IR/front-end tracked patch chunks and new-file hashes match the tested IR phase.')))
    equivalence = dict(schema='scriptw-structural-test-source-equivalence-v1',
        phase_manifest_sha256=phase_sha, final_manifest_sha256=final_sha,
        phase_snapshot=phase.name, changed_test_file=TEST,
        old_test_sha256=sha(original), final_test_sha256=sha(final_test),
        unchanged_product_and_other_test_inputs=True,
        unchanged_copied_new_file_hashes=True,
        old_marker=OLD.decode(), new_marker=NEW.decode(),
        scope='Only the structure_language test marker changed. All other native targets keep their original passing scopes and source/binary identities. The corrected structure_language target must rebuild and pass on the final snapshot.')
    (BASE / 'structural-test-source-equivalence.json').write_bytes(encoded(equivalence))
    need(sha((phase / 'manifest.json').read_bytes()) == phase_sha, 'preserved native phase changed')
    print(json.dumps(equivalence, indent=2))


if __name__ == '__main__':
    main()
