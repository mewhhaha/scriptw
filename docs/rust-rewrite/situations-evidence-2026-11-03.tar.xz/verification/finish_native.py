import hashlib,json,pathlib,re,subprocess,sys,time
root=pathlib.Path.cwd();base=root/'target/performance-specialize-20261103';records=[];logs=base/'verification';logs.mkdir(exist_ok=True)
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
manifest=sha(base/'measured-source/manifest.json')
for label in ('ir-candidates','ir-full'):
 row=json.loads((base/(label+'.json')).read_text());state,passed,failed,ignored=row.pop('summaries')[0];row['outcomes']=dict(state=state,passed=int(passed),failed=int(failed),ignored=int(ignored));row['original_source_manifest_sha256']=row['source_manifest_sha256'];row['source_manifest_sha256']=manifest;records.append(row)

def save():
 (base/'native-verification.json').write_text(json.dumps(dict(source_manifest_sha256=manifest,ir_source_equivalence=json.loads((base/'ir-source-equivalence.json').read_text()),scopes=records,limits='Focused scopes overlap full scopes; retain every AOT failure. No full workspace CI or pinned Test262 rerun.'),indent=2)+'\n')
def run(label,argv,package=None,target=None,allowed=(0,)):
 print('START',label,flush=True);start=time.monotonic_ns()
 location=logs
 if label=='build':location=base
 with (location/(label+'.stdout')).open('xb') as out,(location/(label+'.stderr')).open('xb') as err:p=subprocess.run(argv,cwd=root,stdout=out,stderr=err,timeout=1800)
 text=(location/(label+'.stdout')).read_text();summaries=re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;',text)
 row=dict(label=label,package=package,target=target,argv=argv,exit_code=p.returncode,elapsed_ns=time.monotonic_ns()-start,stdout='verification/'+label+'.stdout',stderr='verification/'+label+'.stderr')
 if package:
  assert len(summaries)==1,(label,summaries);state,passed,failed,ignored=summaries[0];row['outcomes']=dict(state=state,passed=int(passed),failed=int(failed),ignored=int(ignored));row['executable_sha256']=sha(pathlib.Path(argv[0]));assert int(passed)+int(failed)>0
 records.append(row);save();print('END',label,p.returncode,summaries,flush=True);assert p.returncode in allowed,label
 return row
def artifacts(path):
 rows=[json.loads(line) for line in path.read_text().splitlines()];assert any(r.get('reason')=='build-finished' and r['success'] for r in rows)
 return {r['target']['name']:r for r in rows if r.get('reason')=='compiler-artifact' and r.get('executable') and r['profile']['test']}
end=time.monotonic()+1800
while True:
 path=base/'aot-build-v4.stdout'
 if path.exists():
  try:rows=[json.loads(line) for line in path.read_text().splitlines()]
  except ValueError:rows=[]
  finished=[r for r in rows if r.get('reason')=='build-finished']
  if finished:assert finished[-1]['success'];break
 assert time.monotonic()<end,'AOT build deadline';time.sleep(2)
aot=artifacts(path)['scriptw_aot_wasm']['executable']
for label,selector in [('local-calls','tests::local_argument_calls::'),('raw-properties','tests::raw_key_own_data::'),('local-plan','function_entry::local_arguments::tests::')]:run(label,[aot,selector,'--test-threads=1'],'scriptw-aot-wasm','scriptw_aot_wasm')
run('aot-full',[aot,'--test-threads=1'],'scriptw-aot-wasm','scriptw_aot_wasm',allowed=(0,101))
failures=set(re.findall(r'^    (\S+)\s*$',(logs/'aot-full.stdout').read_text().split('failures:\n')[-1],re.M))
expected={
 'tests::bootstrap_compact_metadata::native_bootstrap_uses_complete_constructor_layouts_and_compact_remaining_native_metadata',
 'tests::error_demand_initialization::canonical_runtime_defers_the_complete_error_graph_with_a_void_realm_abi',
 'tests::intrinsic_property_layout_allocation::fresh_intrinsic_bootstrap_allocates_layout_records_not_per_property_records',
 'tests::ordered_bootstrap_allocation::eager_layout_births_keep_demand_recipe_and_constructor_allocation_owners'}
assert failures==expected,sorted(failures)
targets=['emission','structure_language','modules_realms','runtime_link','structure_builtins','structure_async','intl_temporal','aot_language','aot_builtins','aot_async','aot_realm_modules']
argv=['cargo','test','--release','--locked','-p','scriptw-aot-wasm','-p','scriptw-engine']
for target in targets:argv+=['--test',target]
argv+=['--no-run','--message-format=json-render-diagnostics'];run('native-build',argv)
native=artifacts(logs/'native-build.stdout')
for label,selector in [('local-call-semantics','aot_local_argument_calls::'),('raw-property-semantics','aot_raw_key_own_data::')]:run(label,[native['aot_language']['executable'],selector,'--test-threads=1'],'scriptw-engine','aot_language')
for target in targets:
 package='scriptw-aot-wasm'
 if target.startswith('aot_'):package='scriptw-engine'
 run(target,[native[target]['executable'],'--test-threads=1'],package,target)
print('Native verification complete, including fresh IR checks with unchanged relevant inputs.',flush=True)
run('build',['cargo','build','--release','--locked','-p','scriptw-cli','--example','compiler_precompiled_baseline','--example','rsc_baseline','--message-format=json-render-diagnostics'])
print('Frozen benchmark producer build complete.',flush=True)
