from pathlib import Path
root=Path.cwd();p=root/'README.md';s=p.read_text();start=s.index('<table>\n<tr>\n<td><img src="docs/rust-rewrite/assets/situations-current/');end=s.index('[Individual scores and caveats]',start);s=s[:start]+s[end:];p.write_text(s)
p=root/'docs/rust-rewrite/current-inventory.md';s=p.read_text();start=s.index('- Reduce call transport');end=s.index('- Bound native code',start);s=s[:start]+'''- Measure remaining call transport after canonical local-argument entries and
  guarded direct calls. Attribute executed entry coverage, argument vectors and
  activation allocation before widening the two-formal admission or inlining
  larger source bodies. React's five-formal `vn`/`ft` helpers are outside that
  transport bound; exclusion alone does not establish their cost. Preserve
  callee identity, Realm, captures, receiver, depth and abrupt completion.
  Owner: IR/AOT source-call planning and dispatch.
- Reduce repeated property selection after the raw Number-array and computed
  String own-data probes. Measure name-to-slot lookup and representation checks
  within the [property scores](situations-current.json); retain live mutation,
  accessors, prototypes, proxies and coercion/exception order on misses.
  Owner: AOT operations and the existing object model.
- Attribute current RSC semantic work. The [fresh instruction counts](react-attribution-current.json)
  use 100 checked requests in three fresh processes per engine/mode; they are
  unscored user-thread counters, not causal cost percentages. Re-sample the name
  resolver and remaining call/property paths on the [recorded compiler](rsc-current.json)
  before adding caches, changing environment addressing or broadening inlining.
  Earlier sampled caller profiles remain in their Git-bound archive.
  Owner: IR/AOT lowering and runtime lookup/property machinery; retain one heap.
''' +s[end:];p.write_text(s)
print('README full panels stay in benchmark details; unresolved hills refreshed')
