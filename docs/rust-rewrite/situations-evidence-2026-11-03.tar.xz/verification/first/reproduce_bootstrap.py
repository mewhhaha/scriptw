import hashlib,json,pathlib,re,subprocess,time
base=pathlib.Path('target/performance-climb-20261103')
old=pathlib.Path('target/release/deps/scriptw_aot_wasm-89ab076d86dcfef9')
old_sha='6d2189d1ad259be250fc9ad02616162b5332ea0f6dfc9c9e16d65a4a0dda3e89'
assert hashlib.sha256(old.read_bytes()).hexdigest()==old_sha
receipt=json.loads((base/'native/receipt.json').read_text())['cases'][0]
new=pathlib.Path(receipt['command'][0]);assert hashlib.sha256(new.read_bytes()).hexdigest()==receipt['executable_sha256']
tests=[
 'tests::bootstrap_compact_metadata::native_bootstrap_uses_complete_constructor_layouts_and_compact_remaining_native_metadata',
 'tests::error_demand_initialization::canonical_runtime_defers_the_complete_error_graph_with_a_void_realm_abi',
 'tests::intrinsic_property_layout_allocation::fresh_intrinsic_bootstrap_allocates_layout_records_not_per_property_records',
 'tests::ordered_bootstrap_allocation::eager_layout_births_keep_demand_recipe_and_constructor_allocation_owners',
]
rows=[]
for actor,binary in [('baseline',old),('candidate',new)]:
 for index,test in enumerate(tests):
  argv=[str(binary),test,'--exact','--test-threads=1'];start=time.monotonic_ns()
  result=subprocess.run(argv,capture_output=True,timeout=60)
  out=base/f'bootstrap-{actor}-{index}.stdout';err=base/f'bootstrap-{actor}-{index}.stderr';out.write_bytes(result.stdout);err.write_bytes(result.stderr)
  output=result.stdout.decode();values=re.findall(r'left: (\d+)\n\s*right: (\d+)',output)
  rows.append(dict(actor=actor,test=test,argv=argv,exit_code=result.returncode,elapsed_ns=time.monotonic_ns()-start,
                   executable_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),values=values,
                   stdout=str(out),stderr=str(err),summary=re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed',output)))
  (base/'baseline-bootstrap-check.json').write_text(json.dumps(rows,indent=2)+'\n')
  print(actor,index,result.returncode,values,flush=True)
for index in range(4):
 a,b=rows[index],rows[index+4]
 assert a['exit_code']==b['exit_code']==101 and a['values']==b['values'] and a['summary']==b['summary']==[('FAILED','0','1')],(a,b)
print('All four bootstrap failures reproduce on the frozen prior test executable and current executable.')
