"""Publish this measured compiler batch using the existing inert archive format."""
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import tarfile

ROOT = Path.cwd()
BASE = ROOT / 'target/performance-climb-20261103'
DOCS = ROOT / 'docs/rust-rewrite'
CAMPAIGN = BASE / 'campaign'
spec = importlib.util.spec_from_file_location('inert_archive', ROOT / 'target/react-performance-20261103/archive_final.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


def encoded(value):
    return (json.dumps(value, indent=2, allow_nan=False) + '\n').encode()


def sha(value):
    return hashlib.sha256(value).hexdigest()


def read(path):
    return json.loads(path.read_text())


report = read(CAMPAIGN / 'report.json')
assert report['complete'] and report['status'] == 'complete' and len(report['rows']) == 312
assert all(row['status'] == 'ok' for row in report['rows'])
assert len(report['cases']) == 13 and len(report['preparations']) == 2
for case in report['cases']:
    assert all(row['status'] == 'complete' and len(row['process_medians_ns']) == 8
               for row in case['runtimes'].values())
    receipts = [c for p in report['preparations'] for c in p['cases'] if c['file'] == case['file']]
    assert len(receipts) == 2 and receipts[0]['program_wasm_sha256'] == receipts[1]['program_wasm_sha256']

archive = module.Archive()
archive.add_file('tools/publish.py', Path(__file__))
archive.add_file('tools/inert_archive.py', ROOT / 'target/react-performance-20261103/archive_final.py')
for directory in ('sources', 'tooling', 'logs', 'build', 'manifests'):
    archive.add_tree(CAMPAIGN / directory, 'campaign/' + directory)
archive.add_file('campaign/report.json', CAMPAIGN / 'report.json')
for path in sorted((CAMPAIGN / 'images').rglob('*')):
    if path.is_file() and path.suffix in ('.js', '.mjs', '.json'):
        archive.add_file('campaign/' + path.relative_to(CAMPAIGN).as_posix(), path)
archive.add_tree(BASE / 'measured-source', 'measured-source')
archive.add_file('baseline/prior-current.json', BASE / 'baseline-current.json')
sealed = []
for path in sorted((BASE / 'native').rglob('*')):
    if not path.is_file():
        continue
    name = 'verification/native/' + path.relative_to(BASE / 'native').as_posix()
    data = path.read_bytes()
    if path.suffix == '.gz':
        unpacked = gzip.decompress(data)
        sealed.append(dict(original=name, compressed_sha256=sha(data),
                           expanded=name[:-3], expanded_sha256=sha(unpacked)))
        name, data = name[:-3], unpacked
    archive.add_bytes(name, data)
archive.add_bytes('verification/sealed-log-mapping.json', encoded(sealed))
native = read(BASE / 'native/receipt.json')
for index, case in enumerate(native['cases']):
    if case.get('transcript_log'):
        archive.add_file(f'verification/transcripts/{index:02d}-{case["target"]}.log', ROOT / case['transcript_log'])
for path in sorted(BASE.iterdir()):
    if path.is_file() and path.suffix in ('.json', '.stdout', '.stderr') and path.name not in ('baseline-current.json',):
        archive.add_file('verification/' + path.name, path)

if (BASE / 'baseline-refresh/report.json').exists():
    old = read(BASE / 'baseline-refresh/report.json')
    assert old['complete'] and all(row['status'] == 'ok' for row in old['rows'])
    archive.add_tree(BASE / 'baseline-refresh/logs', 'baseline/refresh-logs')
    archive.add_file('baseline/refresh-report.json', BASE / 'baseline-refresh/report.json')
    previous = {case['file']: case for case in old['cases']}
    report['comparison'] = dict(scope='descriptive same-host frozen baseline refresh; selected cases only; current chart bars use candidate and V8 only',
        baseline_identity=old['source_identity'], baseline_report_sha256=sha((BASE / 'baseline-refresh/report.json').read_bytes()),
        cases=[dict(file=case['file'], ratios={actor: case['runtimes'][actor]['median_ns'] / previous[case['file']]['runtimes'][actor]['median_ns']
               for actor in report['policy']['actors']}) for case in report['cases'] if case['file'] in previous])

report['publication'] = dict(date='2026-11-03',
    measured_source=read(BASE / 'measured-source/manifest.json'),
    coverage=dict(cases=13, actors=3, fresh_execution_processes=312, checked_invocations=3120,
        warmup_invocations=936, measured_invocations=2184,
        native=[dict(package=c['package'], target=c['target'], state=c['state'], outcomes=c.get('outcomes'),
                     executable_sha256=c.get('executable_sha256')) for c in native['cases']],
        source_guards_passed=361, limits='No full workspace CI or pinned Test262 rerun. Every failure stays counted.'),
    implementation=[
        'Proven unbound references in static ordinary Module functions start at the defining Realm Global Environment Record; values, lexicals, getters and evaluation order remain live.',
        'Strict ordinary functions with a fully inspected observer-free body omit only the implicit arguments object; all owned storage, caller barriers and normal entry/epilogue remain.',
        'Bounded dense integer literal switches use guarded Wasm br_table dispatch, retaining exact Number equality, default, duplicates, lexical scope and fallthrough.'
    ],
    baseline=dict(git_commit='6d5820654208656e7b0038d313b2b0737cb61ae9', report='docs/rust-rewrite/situations-current.json',
        report_sha256=sha((BASE / 'baseline-current.json').read_bytes()),
        evidence_archive='docs/rust-rewrite/situations-evidence-2026-11-03.tar.xz',
        evidence_sha256=sha((BASE / 'baseline-evidence.tar.xz').read_bytes())),
    caveats=read(BASE / 'baseline-current.json')['publication']['caveats'])

rsc_path = BASE / 'rsc-public.json'
rsc = None
if rsc_path.exists():
    rsc = read(rsc_path)
    archive.add_bytes('reports/rsc-current.json', encoded(rsc))
    archive.add_campaign(BASE / 'fast-comparison-campaign')
    archive.add_file('tools/measure_rsc.py', BASE / 'measure_rsc.py')

full = encoded(report)
archive.add_bytes('reports/full-report.json', full)
for key in ('rows', 'commands', 'retained_files'):
    report.pop(key)
report['publication']['full_report'] = dict(path='reports/full-report.json', sha256=sha(full), bytes=len(full))
for case in report['cases']:
    for runtime in case['runtimes'].values():
        for process in runtime['processes']:
            process.pop('samples_ns')
preparations = report.pop('preparations')
report['preparations'] = []
fields = ('file', 'program_wasm_sha256', 'program_wasm_bytes', 'native_serialized_bytes', 'image_sha256',
          'image_bytes', 'phases_ns', 'runtime_key', 'image_path', 'wasm_path')
for preparation in preparations:
    configuration = preparation['cases'][0]['native_configuration']
    assert all(c['native_configuration'] == configuration for c in preparation['cases'])
    compact = {key: value for key, value in preparation.items() if key != 'cases'}
    compact['native_configuration'] = configuration
    compact['cases'] = [{key: c[key] for key in fields} for c in preparation['cases']]
    report['preparations'].append(compact)
archive.add_bytes('reports/situations-current.json', encoded(report))
archive_path = DOCS / 'situations-evidence-2026-11-03.tar.xz'
assert archive_path.read_bytes() == (BASE / 'baseline-evidence.tar.xz').read_bytes()
archive_path.unlink()
metadata = archive.write(archive_path)
report['evidence_archive'] = metadata
(DOCS / 'situations-current.json').write_bytes(encoded(report))
if rsc is not None:
    rsc['evidence_archive'] = metadata
    (DOCS / 'rsc-current.json').write_bytes(encoded(rsc))
with tarfile.open(archive_path, 'r:xz') as tar:
    data = tar.extractfile('INDEX.json').read()
    assert tar.extractfile('INDEX.json.sha256').read().decode().strip() == sha(data) + '  INDEX.json'
    index = json.loads(data)
    assert {m.name for m in tar.getmembers()} == {r['path'] for r in index['members']} | {'INDEX.json', 'INDEX.json.sha256'}
    assert all(m.isfile() and m.mode == 0o644 for m in tar.getmembers())
    for row in index['members']:
        value = tar.extractfile(row['path']).read()
        assert sha(value) == row['sha256'] and len(value) == row['bytes'] and b'\0' not in value
        value.decode('utf-8', errors='strict')
    assert json.loads(tar.extractfile('reports/situations-current.json').read()) == {k:v for k,v in report.items() if k != 'evidence_archive'}
print(json.dumps(metadata, indent=2))
