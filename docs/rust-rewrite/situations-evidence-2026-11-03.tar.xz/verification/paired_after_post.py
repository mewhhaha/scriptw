import pathlib,subprocess,time
b=pathlib.Path('target/performance-own-keys-20261103');end=time.monotonic()+1800
while 'POST MEASUREMENT COMPLETE' not in (b/'post-pipeline.stdout').read_text():
 assert time.monotonic()<end;time.sleep(2)
raise SystemExit(subprocess.run(['python3','-B',str(b/'paired_fast.py')]).returncode)
