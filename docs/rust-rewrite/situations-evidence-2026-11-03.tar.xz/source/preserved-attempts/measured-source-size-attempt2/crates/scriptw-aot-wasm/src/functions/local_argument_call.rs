//! The actual callable's published source entry is the guard, including across P.
use super::*;
use crate::function_entry::LocalArgumentCallInputs;
use crate::gc_types::{
    ExecutableCodeKind, ExecutableCodeSchema, FunctionContextSchema, FunctionObject,
    FunctionObjectSchema, GcI32Constant, GcNullability, LocalArgumentsCallable, Nullable,
    ValueLocals,
};

impl FunctionBuilder<'_> {
    pub(super) fn try_emit_local_argument_call(
        &mut self,
        callee: &ValueLocals,
        receiver: &ValueLocals,
        arguments: &[TypedExpr],
        known_target: Option<&WasmFunctionMeta>,
        continuation: &CallContinuation,
        output: &ValueLocals,
        function: &mut Function,
    ) -> Result<bool, EmitError> {
        // An ineligible source hint does not justify another inline guard.
        // Full dispatch still handles an eligible replacement correctly.
        if known_target.is_some_and(|meta| meta.entry.local_arguments().is_none()) {
            return Ok(false);
        }
        if arguments.len() > 2
            || arguments.iter().any(|argument| {
                matches!(
                    argument.expr,
                    ExprIr::SpreadArgument(_) | ExprIr::CapturedArgumentList(_)
                )
            })
        {
            return Ok(false);
        }
        let schema = self.runtime_schema();
        let mut values = Vec::with_capacity(arguments.len());
        for argument in arguments {
            let value = schema.reserve_value_local(function);
            self.compile_expr_to_value(argument, &value, function)?;
            self.emit_propagate_current_throw_if_needed(function);
            // A later operand can call, allocate, or replace the source binding.
            // Keep both the actual callee and all preceding arguments rooted.
            values.push(value);
        }
        let result = schema.reserve_completion(function);
        let handled = schema.reserve_i32_local(function);
        handled.set_constant(0, function);
        callee.tag().load(function);
        function.instruction(&Instruction::I32Const(WasmRuntimeValueTag::Function.tag()));
        function.instruction(&Instruction::I32Eq);
        callee.reference().load(function);
        function.instruction(&Instruction::RefTestNonNull(
            schema
                .reference_type::<FunctionObject>(GcNullability::NonNullable)
                .heap_type,
        ));
        function.instruction(&Instruction::I32And);
        self.open_frame(ControlFrameKind::If, function);
        let callable = schema.reserve_gc_local(function).initialize(
            callee.cast_reference::<FunctionObject>(schema, function),
            function,
        );
        let code = schema.reserve_gc_local(function).initialize(
            schema
                .field(FunctionObjectSchema::CODE)
                .read(&callable, schema, function)
                .reference(),
            function,
        );
        let optional = schema
            .reserve_function_local::<LocalArgumentsCallable, Nullable>(function)
            .initialize(
                schema
                    .field(ExecutableCodeSchema::LOCAL_ARGUMENTS_ENTRY)
                    .read(&code, schema, function)
                    .callable(),
                function,
            );
        optional.load(function).is_null(function);
        function.instruction(&Instruction::I32Eqz);
        self.open_frame(ControlFrameKind::If, function);
        let entry = schema
            .reserve_function_local::<LocalArgumentsCallable, _>(function)
            .initialize(optional.load(function).require_non_null(function), function);
        let context = schema.reserve_gc_local(function).initialize(
            schema
                .field(FunctionObjectSchema::CONTEXT)
                .read(&callable, schema, function)
                .reference(),
            function,
        );
        let realm = schema.reserve_gc_local(function).initialize(
            schema
                .field(FunctionContextSchema::REALM)
                .read(&context, schema, function)
                .reference(),
            function,
        );
        let caller_realm = self.load_current_realm(function);
        // Cross-P source IDs can collide. The actual code and its defining
        // program must both agree before a source hint becomes a direct call.
        let direct = if let Some(meta) =
            known_target.filter(|meta| meta.entry.local_arguments().is_some())
        {
            let owner = schema.reserve_gc_local(function).initialize(
                schema
                    .field(FunctionContextSchema::DEFINING_PROGRAM)
                    .read(&context, schema, function)
                    .reference(),
                function,
            );
            let source = schema.reserve_i64_local(function);
            let kind = schema.reserve_i32_local(function);
            let matches = schema.reserve_i32_local(function);
            schema
                .field(ExecutableCodeSchema::SOURCE_ID)
                .read(&code, schema, function)
                .store_i64(source, function);
            schema
                .field(ExecutableCodeSchema::KIND)
                .read(&code, schema, function)
                .store(kind, function);
            source.load(function);
            function.instruction(&Instruction::I64Const(meta.entry.source_id()));
            function.instruction(&Instruction::I64Eq);
            kind.load(function);
            function.instruction(&Instruction::I32Const(
                ExecutableCodeKind::JavaScript.encode(),
            ));
            function.instruction(&Instruction::I32Eq);
            function.instruction(&Instruction::I32And);
            owner.load(schema, function);
            self.current_program().reference(schema, function);
            function.instruction(&Instruction::RefEq);
            function.instruction(&Instruction::I32And);
            matches.store(function);
            schema.release_i32_local(kind, function);
            schema.release_i64_local(source, function);
            owner.clear(function);
            Some((
                matches,
                meta.entry
                    .local_arguments()
                    .expect("selected canonical entry"),
            ))
        } else {
            None
        };
        let undefined = schema.reserve_value_local(function);
        undefined.set_undefined(function);
        let operands = [
            values.first().unwrap_or(&undefined),
            values.get(1).unwrap_or(&undefined),
        ];
        match continuation {
            CallContinuation::Continue => {
                self.replace_current_realm(&realm, function);
                match direct {
                    Some((guard, planned)) => {
                        guard.load(function);
                        self.open_frame(ControlFrameKind::If, function);
                        result.store_call(
                            LocalArgumentCallInputs::call(
                                receiver,
                                operands,
                                &caller_realm,
                                self.current_program(),
                            )
                            .emit_planned_call(&callable, planned, schema, function),
                            function,
                        );
                        function.instruction(&Instruction::Else);
                        result.store_call(
                            LocalArgumentCallInputs::call(
                                receiver,
                                operands,
                                &caller_realm,
                                self.current_program(),
                            )
                            .emit_call(&callable, &entry, schema, function),
                            function,
                        );
                        self.pop_control(ControlFrameKind::If);
                        function.instruction(&Instruction::End);
                    }
                    None => result.store_call(
                        LocalArgumentCallInputs::call(
                            receiver,
                            operands,
                            &caller_realm,
                            self.current_program(),
                        )
                        .emit_call(&callable, &entry, schema, function),
                        function,
                    ),
                }
                self.replace_current_realm(&caller_realm, function);
            }
            CallContinuation::Return => {
                // The P owner and Realm survive lexical unwind. Operand work
                // and the actual typed-entry guard precede caller retirement.
                let calling_program = self.capture_current_program(function);
                self.emit_retire_tail_call_activation(function);
                self.replace_current_realm(&realm, function);
                let inputs = LocalArgumentCallInputs::call(
                    receiver,
                    operands,
                    &caller_realm,
                    &calling_program,
                );
                match direct {
                    Some((guard, planned)) => {
                        guard.load(function);
                        self.open_frame(ControlFrameKind::If, function);
                        inputs.emit_planned_return_call(&callable, planned, schema, function);
                        function.instruction(&Instruction::Else);
                        inputs.emit_return_call(&callable, &entry, schema, function);
                        self.pop_control(ControlFrameKind::If);
                        function.instruction(&Instruction::End);
                    }
                    None => inputs.emit_return_call(&callable, &entry, schema, function),
                }
                calling_program.clear(function);
            }
        }
        // Ordinary Call owns Return normalization; Throw remains a completion
        // until the caller's active catch/finally boundary receives it below.
        result.kind().load(function);
        function.instruction(&Instruction::I32Const(CompletionKind::Return as i32));
        function.instruction(&Instruction::I32Eq);
        self.open_frame(ControlFrameKind::If, function);
        result.set_normal(result.value(), function);
        self.pop_control(ControlFrameKind::If);
        function.instruction(&Instruction::End);
        handled.set_constant(1, function);
        if let Some((guard, _)) = direct {
            schema.release_i32_local(guard, function);
        }
        undefined.clear(function);
        caller_realm.clear(function);
        realm.clear(function);
        context.clear(function);
        entry.clear(function);
        self.pop_control(ControlFrameKind::If);
        function.instruction(&Instruction::End);
        optional.clear(function);
        code.clear(function);
        callable.clear(function);
        self.pop_control(ControlFrameKind::If);
        function.instruction(&Instruction::End);

        handled.load(function);
        self.open_frame(ControlFrameKind::If, function);
        result.kind().load(function);
        function.instruction(&Instruction::I32Const(CompletionKind::Throw as i32));
        function.instruction(&Instruction::I32Eq);
        self.open_frame(ControlFrameKind::If, function);
        self.completion().copy_from(&result, function);
        self.pop_control(ControlFrameKind::If);
        function.instruction(&Instruction::End);
        self.emit_propagate_current_throw_if_needed(function);
        output.copy_from(result.value(), function);
        function.instruction(&Instruction::Else);
        let references: Vec<_> = values.iter().collect();
        let list = self.emit_pre_evaluated_arg_vector(&references, function);
        self.emit_indirect_call_with_argv_to_value(
            callee,
            receiver,
            &list,
            continuation,
            output,
            function,
        )?;
        list.clear(function);
        self.pop_control(ControlFrameKind::If);
        function.instruction(&Instruction::End);
        schema.release_i32_local(handled, function);
        result.clear(function);
        for value in values.into_iter().rev() {
            value.clear(function);
        }
        Ok(true)
    }
}
