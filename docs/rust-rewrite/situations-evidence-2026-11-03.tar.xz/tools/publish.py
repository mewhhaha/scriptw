#!/usr/bin/env python3
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import tarfile

ROOT = Path.cwd()
BASE = ROOT / 'target/performance-situations-20261103'
CAMPAIGN = BASE / 'campaign-v2'
DOCS = ROOT / 'docs/rust-rewrite'
spec = importlib.util.spec_from_file_location('inert_archive', ROOT / 'target/react-performance-20261103/archive_final.py')
archive_module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(archive_module)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def encoded(value):
    return (json.dumps(value, indent=2, allow_nan=False) + '\n').encode()


def command(*args):
    return subprocess.check_output(args, cwd=ROOT)


report = json.loads((CAMPAIGN / 'report.json').read_text())
assert report['complete'] is True and report['status'] == 'complete'
assert len(report['rows']) == 312 and all(row['status'] == 'ok' for row in report['rows'])
assert len(report['preparations']) == 2 and all(item['status'] == 'ok' for item in report['preparations'])
assert len(report['cases']) == 13
for case in report['cases']:
    assert set(case['runtimes']) == {'scriptw-fast', 'scriptw-speed', 'v8'}
    assert all(runtime['status'] == 'complete' and len(runtime['process_medians_ns']) == 8
               for runtime in case['runtimes'].values())
    receipts = [row for preparation in report['preparations'] for row in preparation['cases']
                if row['file'] == case['file']]
    assert len(receipts) == 2
    assert receipts[0]['program_wasm_sha256'] == receipts[1]['program_wasm_sha256']

archive = archive_module.Archive()
archive.add_file('tools/publish.py', Path(__file__))
archive.add_file('verification/toolchain.json', BASE / 'toolchain.json')
archive.add_file('tools/inert_archive.py', ROOT / 'target/react-performance-20261103/archive_final.py')
for directory in ('sources', 'tooling', 'logs', 'build', 'manifests'):
    archive.add_tree(CAMPAIGN / directory, 'campaign/' + directory)
for path in sorted((CAMPAIGN / 'images').rglob('*')):
    if path.is_file() and path.suffix in ('.json', '.js', '.mjs'):
        archive.add_file('campaign/' + path.relative_to(CAMPAIGN).as_posix(), path)
archive.add_file('campaign/report.json', CAMPAIGN / 'report.json')
# Keep the failed first attempt separate, including its original source snapshot.
old = BASE / 'campaign'
for directory in ('sources', 'tooling', 'logs', 'build', 'manifests'):
    archive.add_tree(old / directory, 'failed-harness-attempt/' + directory)
archive.add_file('failed-harness-attempt/report.json', old / 'report.json')
for name in ('build.stdout', 'build.stderr', 'build-v2.stdout', 'build-v2.stderr',
             'build-v3.stdout', 'build-v3.stderr', 'native-tests.stdout', 'native-tests.stderr',
             'native-tests-v2.stdout', 'native-tests-v2.stderr', 'native-tests-v3.stdout', 'native-tests-v3.stderr',
             'fixture-tests.stdout', 'fixture-tests.stderr', 'runner-tests.stdout', 'runner-tests.stderr',
             'runner-tests-v2.stdout', 'runner-tests-v2.stderr', 'campaign.stdout', 'campaign.stderr',
             'campaign-v2.stdout', 'campaign-v2.stderr', 'workspace-format.stdout', 'workspace-format.stderr',
             'owners.stdout', 'owners.stderr', 'intl-identities.stdout', 'intl-identities.stderr',
             'source-checks.json'):
    archive.add_file('verification/' + name, BASE / name)

base_commit = command('git', 'rev-parse', 'HEAD').decode().strip()
assert base_commit == report['source_identity']['source_commit']
patch = command('git', 'diff', '--binary', base_commit, '--',
                'crates/scriptw-cli/examples/compiler_precompiled_baseline.rs',
                'crates/scriptw-cli/examples/runtime_precompiled/callable.rs')
archive.add_bytes('measured-source/compiler.patch', patch)
extra_names = ['scripts/benchmark-situations.py', 'scripts/performance_situations.py',
               'scripts/render-situation-benchmarks.py', 'scripts/tests/test_benchmark_situations.py',
               'scripts/tests/test_performance_situations.py',
               'crates/scriptw-cli/tests/fixtures/v8_baseline/node-situations.cjs']
files = {}
for name in extra_names:
    data = (ROOT / name).read_bytes()
    archive.add_bytes('measured-source/' + name, data)
    files[name] = sha(data)
manifest = dict(schema='scriptw-situation-measured-source-v1', base_commit=base_commit,
    compiler_patch_sha256=sha(patch), added_files_sha256=files,
    source_identity=report['source_identity'],
    note='Apply compiler.patch to base_commit and add these files; campaign/tooling separately retains every benchmark host source read by the runner. Native images and executable binaries are excluded from this inert archive; their hashes and sizes remain in receipts.')
archive.add_bytes('measured-source/manifest.json', encoded(manifest))
report['publication'] = dict(date='2026-11-03',
    toolchain=json.loads((BASE / 'toolchain.json').read_text()),
    repository_checks=json.loads((BASE / 'source-checks.json').read_text()),
    measured_source=dict(base_commit=base_commit, manifest_path='measured-source/manifest.json',
                         manifest_sha256=sha(encoded(manifest))),
    coverage=dict(cases=13, actors=3, native_preparations=26, fresh_execution_processes=312,
                  checked_invocations=3120, warmup_invocations=936, measured_invocations=2184,
                  python_fixture_tests=7, python_runner_tests=11, rust_example_tests=16,
                  broader_scope='No product compiler/runtime sources changed; previous Engine/IR/CLI acceptance is not rerun. Full workspace CI and pinned Test262 remain separate.'),
    prior_attempt=dict(status='aborted', scored=False, archive_prefix='failed-harness-attempt/',
                       reason='Stopped the first campaign after consumers panicked while configuring compiler settings after compiler disablement. Fixed configuration order and actual disabled-compiler target reporting; final run uses a new host and fresh images. The intermediate native policy test failed on expecting a target from a compiler-disabled Engine; corrected to the actual None value.'),
    caveats=[
        'Same exact module bytes and seed schedule; each actor includes its public call bridge and print conversion/capture. Empty control is shown without subtraction.',
        'Preparation, source/native compilation, module initialization and result validation are outside call timing. Preparation can still affect later natural GC, feedback and JIT invalidation.',
        'Three warmups and seven samples describe this schedule; V8 is allowed normal JIT/GC and is not claimed to have reached optimized steady state.',
        'Operations count logical source work, not retired lookups or allocations; optimizations and folding are allowed.',
        'Shallow/deep also vary padding captures/arithmetic. Deep/bound-deep is the closer resolution contrast; bound aliases may fold. Getter row includes live getter calls and counter increments.',
        'Branch cases vary control-flow, static/dynamic step keys and call-site polymorphism. Native image growth is measured; individual stack frame sizes and probe cost are not isolated.',
        'Observed arguments adds arguments property reads; differences are not allocations. Property mutation occurs in preparation; no compact/dictionary representation is asserted.',
        'Native serialized P image includes metadata and data; portable Wasm P is separate. Child peak RSS includes host, code and process history, not just guest heap.',
        'Scriptc has no compatible retained-module prepare/run ABI in this workflow, so its fresh WASI entry is not substituted.',
        'These focused programs complement the separate RSC and fresh-entry kernel cohorts; no aggregate workload score or current-source requalification of those cohorts is implied.'
    ])
full_report = encoded(report)
archive.add_bytes('reports/full-report.json', full_report)
# Publish compact process summaries; retain every call and command in the archive.
report = dict(report)
for key in ('rows', 'commands', 'retained_files'):
    report.pop(key)
report['publication']['full_report'] = dict(path='reports/full-report.json',
    sha256=sha(full_report), bytes=len(full_report))
report['cases'] = json.loads(json.dumps(report['cases']))
for case in report['cases']:
    for runtime in case['runtimes'].values():
        for process in runtime['processes']:
            process.pop('samples_ns')
report['preparations'] = []
receipt_fields = ('file', 'program_wasm_sha256', 'program_wasm_bytes', 'native_serialized_bytes',
                  'image_sha256', 'image_bytes', 'phases_ns', 'runtime_key', 'image_path', 'wasm_path')
for preparation in json.loads(full_report)['preparations']:
    native = preparation['cases'][0]['native_configuration']
    assert all(case['native_configuration'] == native for case in preparation['cases'])
    summary = {key: value for key, value in preparation.items() if key != 'cases'}
    summary['native_configuration'] = native
    summary['cases'] = [{key: case[key] for key in receipt_fields} for case in preparation['cases']]
    report['preparations'].append(summary)
archive.add_bytes('reports/situations-current.json', encoded(report))
archive_path = DOCS / 'situations-evidence-2026-11-03.tar.xz'
meta = archive.write(archive_path)
report['evidence_archive'] = meta
output = DOCS / 'situations-current.json'
output.write_bytes(encoded(report))
# Verify the actual archive inventory and the public-to-archived report binding.
with tarfile.open(archive_path, 'r:xz') as tar:
    entries = tar.getmembers()
    assert all(member.isfile() and member.mode == 0o644 for member in entries)
    index_data = tar.extractfile('INDEX.json').read()
    assert tar.extractfile('INDEX.json.sha256').read().decode().strip() == sha(index_data) + '  INDEX.json'
    index = json.loads(index_data)
    actual = {member.name for member in entries} - {'INDEX.json', 'INDEX.json.sha256'}
    assert actual == {row['path'] for row in index['members']}
    for row in index['members']:
        data = tar.extractfile(row['path']).read()
        assert sha(data) == row['sha256'] and len(data) == row['bytes']
        data.decode('utf-8', errors='strict')
        assert b'\0' not in data
    assert json.loads(tar.extractfile('reports/situations-current.json').read()) == {
        key: value for key, value in report.items() if key != 'evidence_archive'}
print(json.dumps(dict(report=str(output), evidence=meta, processes=report['publication']['coverage']['fresh_execution_processes']), indent=2))
