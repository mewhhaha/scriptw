#!/usr/bin/env python3
"""Stage one completed compiler batch as inert evidence; never change docs/."""
import argparse
import copy
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import statistics
import subprocess
import tarfile

ROOT = Path(__file__).resolve().parents[2]
BASE = Path(__file__).resolve().parent
PRIOR = 'a7a44759ce392a48e7c9885e8ab00bd25195a5d4'
ARCHIVE_NAME = 'situations-evidence-2026-11-03.tar.xz'
PRIOR_REPORTS = ('situations-current.json', 'rsc-current.json', 'rsc-wasm-size-current.json', 'react-attribution-current.json')
REQUIRED_TARGETS = {'scriptw_aot_wasm', 'emission', 'structure_language', 'modules_realms',
                    'runtime_link', 'structure_builtins', 'structure_async', 'intl_temporal',
                    'aot_language', 'aot_builtins', 'aot_async', 'aot_realm_modules', 'scriptw_ir_integration'}
KNOWN_FAILURES = {
    'tests::bootstrap_compact_metadata::native_bootstrap_uses_complete_constructor_layouts_and_compact_remaining_native_metadata',
    'tests::error_demand_initialization::canonical_runtime_defers_the_complete_error_graph_with_a_void_realm_abi',
    'tests::intrinsic_property_layout_allocation::fresh_intrinsic_bootstrap_allocates_layout_records_not_per_property_records',
    'tests::ordered_bootstrap_allocation::eager_layout_births_keep_demand_recipe_and_constructor_allocation_owners',
}
SUMMARY = re.compile(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;')
EVENTS = ('cycles:u', 'instructions:u', 'branches:u', 'branch-misses:u')


def need(condition, reason):
    if not condition:
        raise RuntimeError(reason)


def sha(value):
    return hashlib.sha256(value).hexdigest()


def file_digest(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def encoded(value):
    return (json.dumps(value, indent=2, allow_nan=False) + '\n').encode('utf-8')


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def resolve(path, relative_to=ROOT):
    path = Path(path)
    if not path.is_absolute():
        path = relative_to / path
    return path.resolve(strict=True)


def reference(path):
    path = resolve(path)
    value = path.read_bytes()
    return dict(path=path.relative_to(ROOT).as_posix(), sha256=sha(value), bytes=len(value))


def regular_text_tree(archive, folder, prefix):
    """Archive small evidence trees, expanding gzip text and retaining its hash."""
    folder = resolve(folder)
    mapping = []
    derived = []
    for path in sorted(folder.rglob('*')):
        need(not path.is_symlink(), 'symlink evidence rejected')
        if path.is_dir():
            continue
        relative = path.relative_to(folder)
        if any(part in module.EXCLUDED_NAMES for part in relative.parts):
            continue
        if path.suffix.lower() in module.EXCLUDED_SUFFIXES | {'.swpc', '.bin'} or path.name.startswith('perf.data'):
            continue
        with path.open('rb') as stream:
            magic = stream.read(4)
        if magic in (b'\x7fELF', b'\x00asm'):
            continue
        member = prefix + '/' + relative.as_posix()
        if path.name == 'callchains.json':
            original = read(path)
            need(isinstance(original.get('rows'), list), 'derived callchains rows missing')
            summary = {key: value for key, value in original.items() if key != 'rows'}
            summary['derived_rows_omitted'] = len(original['rows'])
            summary_member = member.removesuffix('.json') + '-summary.json'
            value = encoded(summary)
            archive.add_bytes(summary_member, value)
            derived.append(dict(original=reference(path), archived_summary_path=summary_member,
                archived_summary_sha256=sha(value), omitted_derived_rows=len(original['rows']),
                reconstruction='Full parsed rows duplicate retained samples.txt and maps; regenerate with the retained symbolize_fp.py. Original derived-file hash is preserved.'))
            continue
        if path.suffix == '.gz':
            value = path.read_bytes()
            expanded = gzip.decompress(value)
            mapping.append(dict(original=reference(path), expanded_path=member[:-3],
                                expanded_sha256=sha(expanded), expanded_bytes=len(expanded)))
            archive.add_bytes(member[:-3], expanded)
        else:
            archive.add_file(member, path)
    if mapping:
        archive.add_bytes(prefix + '/expanded-gzip-log-mapping.json', encoded(mapping))
    if derived:
        archive.add_bytes(prefix + '/derived-callchains-mapping.json', encoded(derived))


def add_source(archive, folder, prefix):
    manifest = read(folder / 'manifest.json')
    need(manifest['base_commit'] == PRIOR, 'source snapshot base differs')
    need(sha((folder / 'tracked.patch').read_bytes()) == manifest['tracked_patch_sha256'], 'source patch hash differs')
    expected = set(manifest['files']) | {'manifest.json', 'tracked.patch'}
    actual = {p.relative_to(folder).as_posix() for p in folder.rglob('*') if p.is_file()}
    need(actual == expected, 'source snapshot inventory differs')
    for name, digest in manifest['files'].items():
        need(sha((folder / name).read_bytes()) == digest, 'new source hash differs: ' + name)
    regular_text_tree(archive, folder, prefix)
    return dict(archive_prefix=prefix + '/', base_commit=PRIOR,
                manifest_sha256=sha((folder / 'manifest.json').read_bytes()),
                tracked_patch_sha256=manifest['tracked_patch_sha256'], new_files=len(manifest['files']))


def unchanged_source():
    folder = BASE / 'measured-source'
    manifest = read(folder / 'manifest.json')
    patch = subprocess.check_output(['git', 'diff', '--binary', 'HEAD', '--', 'crates', 'docs/rust-rewrite/contracts'], cwd=ROOT)
    need(patch == (folder / 'tracked.patch').read_bytes(), 'measured tracked source changed')
    for name, digest in manifest['files'].items():
        need(sha((ROOT / name).read_bytes()) == digest, 'measured new source changed: ' + name)


def add_baseline(archive):
    reports, bindings = {}, {}
    for name in PRIOR_REPORTS:
        path = BASE / ('baseline-' + name)
        value = path.read_bytes()
        original = subprocess.check_output(['git', 'show', PRIOR + ':docs/rust-rewrite/' + name], cwd=ROOT)
        need(value == original, 'baseline public report differs from Git ' + PRIOR + ': ' + name)
        archive.add_bytes('baseline/reports/' + name, value)
        reports[name] = json.loads(value)
        bindings[name] = dict(git_commit=PRIOR, path='docs/rust-rewrite/' + name, sha256=sha(value), bytes=len(value))
    old = BASE / ('baseline-' + ARCHIVE_NAME)
    metadata = reports['situations-current.json']['evidence_archive']
    need(old.stat().st_size == metadata['bytes'] and sha(old.read_bytes()) == metadata['sha256'], 'baseline evidence hash/size differs')
    source = reports['rsc-current.json']['source_identity']['candidate_measured_source']
    need(reports['rsc-current.json']['evidence_archive']['sha256'] == metadata['sha256'], 'RSC/situations prior evidence differs')
    with tarfile.open(old, 'r:xz') as previous:
        index = previous.extractfile('INDEX.json').read()
        need(previous.extractfile('INDEX.json.sha256').read().decode().strip() == sha(index) + '  INDEX.json', 'baseline index sidecar differs')
        members = {r['path']: r for r in json.loads(index)['members']}
        source_manifest = source['archive_prefix'] + 'manifest.json'
        need(members[source_manifest]['sha256'] == source['manifest_sha256'], 'baseline source reconstruction differs')
    binding = dict(public_reports=bindings, evidence_archive=metadata, measured_source=source,
                   preservation='Hash-verified prior source reconstruction in the prior published archive; old histories are not nested.')
    archive.add_bytes('baseline/identity.json', encoded(binding))
    return reports, binding


def qualify_ir_source(archive, final_source):
    receipt_path = BASE / 'ir-full.json'
    receipt = read(receipt_path)
    phase_sha = receipt['source_manifest_sha256']
    snapshots = [path for path in BASE.glob('measured-source*') if path.is_dir()
                 and (path / 'manifest.json').exists()
                 and sha((path / 'manifest.json').read_bytes()) == phase_sha]
    need(snapshots, 'preserve the exact tested IR phase snapshot before replacing measured-source; missing manifest ' + phase_sha)
    phase = snapshots[0]
    final = BASE / 'measured-source'
    prefixes = ('crates/scriptw-ir/', 'crates/scriptw-front/')
    def ir_inputs(folder):
        patch = (folder / 'tracked.patch').read_text()
        chunks = {match.group(1): match.group(0) for match in re.finditer(
            r'^diff --git a/(.*?) b/.*?(?=^diff --git |\Z)', patch, re.M | re.S)
            if match.group(1).startswith(prefixes)}
        manifest = read(folder / 'manifest.json')
        new_files = {name: digest for name, digest in manifest['files'].items() if name.startswith(prefixes)}
        return dict(tracked_patches=chunks, new_files=new_files)
    inputs = ir_inputs(phase)
    need(inputs == ir_inputs(final), 'IR/front-end source changed since fresh IR verification')
    out = resolve(receipt['stdout'], BASE)
    err = resolve(receipt['stderr'], BASE)
    outcome = test_summary(out)
    need(receipt['exit_code'] == 0 and outcome['state'] == 'ok'
         and outcome['passed'] > 0 and outcome['failed'] == outcome['ignored'] == 0,
         'fresh IR full verification failed')
    need(re.search(r'; 0 filtered out;', out.read_text()), 'fresh IR receipt is filtered')
    equivalence_path = BASE / 'ir-source-equivalence.json'
    equivalence = read(equivalence_path)
    need(equivalence['unchanged'] is True and equivalence['phase_manifest_sha256'] == phase_sha
         and equivalence['final_manifest_sha256'] == final_source['manifest_sha256'], 'root IR source-equivalence receipt differs')
    phase_archive_prefix = 'source/measured/'
    if phase.name != 'measured-source':
        phase_archive_prefix = 'source/preserved-attempts/' + phase.name + '/'
    qualification = dict(status='qualified', phase_manifest_sha256=phase_sha,
        final_manifest_sha256=final_source['manifest_sha256'],
        phase_snapshot=phase.relative_to(ROOT).as_posix(),
        phase_snapshot_archive_prefix=phase_archive_prefix,
        root_equivalence_receipt=reference(equivalence_path),
        verified_path_prefixes=list(prefixes), verified_inputs_sha256=sha(encoded(inputs)),
        executable_sha256=receipt['executable_sha256'], outcomes=outcome,
        receipt=reference(receipt_path), stdout=reference(out), stderr=reference(err),
        note='Fresh IR binary executed on this batch. Its original phase source identity is retained; IR and front-end patch/new-file inputs are identical in the final snapshot. Focused IR cases overlap the full scope.')
    archive.add_bytes('verification/ir-source-qualification.json', encoded(qualification))
    return qualification


def qualify_native_source(archive, final_source):
    return None


def test_summary(path):
    rows = SUMMARY.findall(path.read_text())
    need(len(rows) == 1, 'missing or ambiguous libtest summary: ' + str(path))
    state, passed, failed, ignored = rows[0]
    return dict(state=state, passed=int(passed), failed=int(failed), ignored=int(ignored))


def add_native(archive, path, source, ir_qualification, native_qualification):
    report = read(path)
    scopes = report
    if isinstance(report, dict):
        need(report.get('complete', True) is True, 'native report incomplete')
        scopes = report.get('scopes', report.get('cases'))
        need(report.get('source_manifest_sha256') == source['manifest_sha256'], 'native source manifest differs or missing')
    need(isinstance(report, dict) and isinstance(scopes, list) and scopes, 'native report requires source_manifest_sha256 plus scopes/cases')
    producer_commands = []
    for index, row in enumerate(report.get('producer_commands', [])):
        need(row['exit_code'] == 0, 'native producer command failed')
        label = row['label']
        def producer_output(field):
            candidate = Path(row[field])
            if not candidate.is_absolute() and not (ROOT / candidate).exists():
                return resolve(candidate, path.parent)
            return resolve(candidate)
        out, err = producer_output('stdout'), producer_output('stderr')
        if any(Path(arg).name == 'cargo' for arg in row['argv']):
            events = [json.loads(line) for line in out.read_text().splitlines()]
            finished = [event for event in events if event.get('reason') == 'build-finished']
            need(len(finished) == 1 and finished[0]['success'], 'Cargo producer stream incomplete: ' + label)
        prefix = f'verification/producers/{index:02d}-' + label
        archive.add_file(prefix + '.stdout', out)
        archive.add_file(prefix + '.stderr', err)
        producer_commands.append(dict(row, stdout=reference(out), stderr=reference(err)))
    normalized = []
    # Raw stdout remains authoritative for counts and failure names.
    for row in scopes:
        target = row['target']
        label = row.get('label', target)
        def output_path(field):
            value = row.get(field, str(BASE / (label + '.' + field)))
            candidate = Path(value)
            if not candidate.is_absolute() and not (ROOT / candidate).exists():
                return resolve(candidate, path.parent)
            return resolve(candidate)
        out = output_path('stdout')
        err = output_path('stderr')
        outcome = test_summary(out)
        need(outcome['ignored'] == 0, 'ignored native tests are not a pass')
        if 'outcomes' in row:
            need(row['outcomes'] == outcome, 'native receipt outcome differs from raw stdout')
        exit_code = row.get('exit_code', row.get('exit'))
        need(isinstance(row['executable_sha256'], str) and len(row['executable_sha256']) == 64, 'native executable identity missing')
        failures = []
        if outcome['failed']:
            failures = re.findall(r'^    (\S+)\s*$', out.read_text().split('failures:\n')[-1], re.M)
            need(target == 'scriptw_aot_wasm' and outcome['state'] == 'FAILED' and exit_code == 101
                 and outcome['failed'] == 4 and set(failures) == KNOWN_FAILURES and len(failures) == 4,
                 'unexpected native failures: ' + target)
        else:
            need(exit_code == 0 and outcome['state'] == 'ok' and outcome['passed'] > 0, 'native scope failed: ' + target)
        archive.add_file('verification/native/' + label + '.stdout', out)
        archive.add_file('verification/native/' + label + '.stderr', err)
        producer_source = row.get('source_manifest_sha256', source['manifest_sha256'])
        if target == 'scriptw_ir_integration':
            need(row['executable_sha256'] == ir_qualification['executable_sha256'], 'IR executable differs from fresh receipt')
            need(producer_source in (ir_qualification['phase_manifest_sha256'], source['manifest_sha256']), 'IR phase source identity differs')
            producer_source = ir_qualification['phase_manifest_sha256']
        else:
            allowed = {source['manifest_sha256']}
            if native_qualification is not None:
                for phase in native_qualification['phases']:
                    if target not in phase['excluded_targets']:
                        allowed.add(phase['manifest_sha256'])
            need(producer_source in allowed, 'native producer source differs from qualified inputs')
        normalized.append(dict(row, target=target, label=label,
            command=row.get('argv', row.get('command')), exit_code=exit_code,
            outcomes=outcome, failures=failures, stdout=reference(out), stderr=reference(err),
            source_manifest_sha256=row.get('source_manifest_sha256', source['manifest_sha256']),
            producer_source_manifest_sha256=producer_source,
            qualified_final_source_manifest_sha256=source['manifest_sha256']))
    for target in REQUIRED_TARGETS:
        rows = [row for row in normalized if row['target'] == target
                and re.search(r'; 0 filtered out;', (ROOT / row['stdout']['path']).read_text())]
        need(len(rows) == 1, 'missing or ambiguous full native target: ' + target)
    covered = {r['target'] for r in normalized}
    need(REQUIRED_TARGETS <= covered, 'missing fresh native targets: ' + ', '.join(sorted(REQUIRED_TARGETS - covered)))
    for target, expected in (('emission', 42), ('structure_language', 153)):
        rows = [r for r in normalized if r['target'] == target]
        need(any(r['outcomes']['passed'] == expected and r['outcomes']['failed'] == 0 for r in rows), 'broad scope count differs: ' + target)
    full = [r for r in normalized if r['target'] == 'scriptw_aot_wasm' and r['outcomes']['failed'] == 4]
    need(len(full) == 1, 'missing/ambiguous full AOT library scope')
    initial = read(BASE / 'verification-initial/native-verification-current.json')
    attempted = [row for row in initial['scopes'] if row['label'] == 'own-keys-helper']
    need(len(attempted) == 1 and attempted[0]['outcomes']['failed'] == 2, 'initial emission failure receipt missing')
    superseded = [dict(attempted[0], status='corrected-and-rerun',
        stdout=reference(BASE / 'verification-initial/focused/own-keys-helper.stdout'),
        stderr=reference(BASE / 'verification-initial/focused/own-keys-helper.stderr'),
        source_snapshot_archive_prefix='source/preserved-attempts/measured-source-initial/',
        raw_logs_archive_prefix='verification/raw/verification-initial/focused/',
        reason='Kernel target-validation error emission required a callable Realm inside a non-callable helper. Corrected to the explicit helper execution Realm; final focused and full scopes execute freshly.')]
    archive.add_file('verification/native-report.json', path)
    return dict(fresh_native=normalized, producer_commands=producer_commands, ir_source_qualification=ir_qualification,
                native_source_qualification=native_qualification, superseded_native_scopes=superseded,
                limits='No full workspace CI or pinned Test262 rerun. Focused scopes may overlap broader scopes and must not be summed. All Engine scopes ran on identical current product inputs with preserved source qualification; four preexisting AOT library failures remain failures.')


def add_situations(archive, folder):
    report = read(folder / 'report.json')
    need(report['complete'] and report['status'] == 'complete' and len(report['cases']) == 13
         and len(report['rows']) == 312 and all(r['status'] == 'ok' for r in report['rows']), 'situations campaign incomplete')
    need(report['policy']['actors'] == ['scriptw-fast', 'scriptw-speed', 'v8']
         and report['policy']['samples'] == 7 and report['policy']['warmups'] == 3
         and len(report['preparations']) == 2, 'situations policy differs')
    for case in report['cases']:
        for actor in report['policy']['actors']:
            runtime = case['runtimes'][actor]
            need(runtime['status'] == 'complete' and len(runtime['processes']) == len(runtime['process_medians_ns']) == 8
                 and all(len(p['samples_ns']) == 7 for p in runtime['processes']), 'situations process coverage incomplete')
        receipts = [c for p in report['preparations'] for c in p['cases'] if c['file'] == case['file']]
        need(len(receipts) == 2 and receipts[0]['program_wasm_sha256'] == receipts[1]['program_wasm_sha256'], 'Fast/Speed program differs')
    for name in ('sources', 'tooling', 'logs', 'build', 'manifests'):
        regular_text_tree(archive, folder / name, 'situations/' + name)
    archive.add_file('situations/report.json', folder / 'report.json')
    for path in sorted((folder / 'images').rglob('*')):
        if path.is_file() and path.suffix in ('.js', '.mjs', '.json'):
            archive.add_file('situations/' + path.relative_to(folder).as_posix(), path)
    for row in report['retained_files']:
        member = 'situations/' + row['path']
        if member in archive.files:
            value = archive.files[member]
            need(sha(value) == row['sha256'] and len(value) == row['bytes'], 'situations retained text changed')
    return report


def add_rsc(archive, folder, source, baseline, binding):
    campaign = read(folder / 'campaign.json')
    aggregate = read(folder / 'aggregate.json')
    need(campaign['schema'] == 'scriptw-rsc-fast-campaign-v1' and campaign['status'] == 'complete'
         and len(campaign['processes']) == 24 and aggregate['schema'] == 'scriptw-rsc-fast-comparison-v1', 'RSC campaign incomplete')
    need(aggregate['measurement']['campaign_sha256'] == sha((folder / 'campaign.json').read_bytes()), 'RSC campaign hash differs')
    identity = aggregate['engines']['baseline']['identity']
    old = baseline['rsc-current.json']['engines']['candidate']['identity']
    for field in ('executable_sha256', 'source_fingerprint', 'program_wasm_sha256', 'configuration', 'inputs', 'source_commit'):
        need(identity[field] == old[field], 'RSC baseline differs from Git ' + PRIOR + ' public candidate: ' + field)
    counts = {}
    for row in campaign['processes']:
        need(row['status'] == 'complete', 'RSC process incomplete')
        key = (row['block'], row['engine'])
        counts[key] = counts.get(key, 0) + 1
        for field in ('report', 'stdout', 'stderr'):
            value = (folder / row[field]).read_bytes()
            need(sha(value) == row[field + '_sha256'], 'RSC process text changed')
            archive.add_bytes('rsc/' + row[field], value)
        relative = Path(row['stdout']).parent / 'resources.json'
        archive.add_file('rsc/' + relative.as_posix(), folder / relative)
    need(set(counts) == {(b, e) for b in (0, 1) for e in ('baseline', 'candidate', 'v8')}
         and all(n == 4 for n in counts.values()), 'RSC process balance differs')
    for name in ('campaign.json', 'aggregate.json', 'measure_fast_comparison.py', 'react-driver.cjs', 'baseline-identity-report.json'):
        archive.add_file('rsc/' + name, folder / name)
    candidate_source = aggregate['source_identity']['candidate_measured_source']
    need(candidate_source['manifest_sha256'] == source['manifest_sha256'], 'RSC source snapshot differs')
    raw_baseline = read(folder / 'baseline-identity-report.json')
    for field in ('executable_sha256', 'source_fingerprint', 'program_wasm_sha256', 'configuration', 'inputs', 'source_commit'):
        need(raw_baseline[field] == identity[field], 'raw RSC baseline identity differs: ' + field)
    report = copy.deepcopy(aggregate)
    report['schema'] = 'scriptw-rsc-current-v1'
    report['source_identity']['baseline_source'] = binding
    report['source_identity']['candidate_measured_source'] = source
    report['source_identity'].pop('full_baseline_source_snapshot_preserved', None)
    report['source_identity']['baseline_source_preservation'] = binding['preservation']
    inputs = report['engines']['candidate']['identity']['inputs']
    for field in ('source', 'support'):
        path = Path(inputs[field])
        need(sha(path.read_bytes()) == inputs[field + '_sha256'], 'RSC fixture changed')
        archive.add_file('fixtures/' + path.name, path)
    return report


def add_pmu(archive, receipt_path, expected_identity, node_identity, prefix):
    runs = read(receipt_path)
    need(isinstance(runs, list) and len(runs) in (6, 12) and all(r['exit_code'] == 0 for r in runs), 'PMU driver receipt incomplete')
    processes = []
    for run in runs:
        folder = receipt_path.parent / run['name']
        receipt = read(folder / 'receipt.json')
        observations = read(folder / 'observations.json')
        need(receipt['schema'] == 'scriptw-rsc-pmu-v2' and receipt['status'] == 'captured'
             and receipt['excluded_from_scored_cohorts'] is True and receipt['host_exit_code'] == 0
             and receipt['samples'] == 100 and receipt['warmups'] == 3
             and receipt['native_mode'] == 'fast' and receipt['empty_window_calibration'] is False
             and len(receipt['windows']) == 100, 'PMU capture incomplete')
        need(len(observations['cases']) == 1 and observations['cases'][0]['case'] == 'rsc-' + receipt['mode']
             and observations['cases'][0]['exact_node_output_checked'] is True
             and len(observations['cases'][0]['observations']) == 103, 'PMU exact output coverage differs')
        if receipt['engine'] == 'scriptw':
            for key in ('executable_sha256', 'source_fingerprint', 'program_wasm_sha256', 'configuration', 'runtime', 'inputs'):
                need(observations[key] == expected_identity[key], 'PMU Scriptw build identity differs: ' + key)
        else:
            need(observations['node'] == node_identity['node'], 'PMU Node version identity differs')
        for field in ('source_sha256', 'support_sha256', 'adapted_source_sha256'):
            need(observations['inputs'][field] == expected_identity['inputs'][field], 'PMU fixture identity differs')
        windows = receipt['windows']
        need([w['index'] for w in windows] == list(range(3, 103))
             and all(w['time_enabled_ns'] == w['time_running_ns'] > 0 and w['running_fraction'] == 1 for w in windows), 'PMU counter admission differs')
        totals = {event: sum(w['raw_counts'][event] for w in windows) for event in EVENTS}
        need(totals == receipt['summary']['raw_counts'] and receipt['summary']['minimum_running_fraction'] == 1, 'PMU raw count summary differs')
        for name, row in receipt['raw_files'].items():
            value = (folder / name).read_bytes()
            need(sha(value) == row['sha256'] and len(value) == row['bytes'], 'PMU raw text changed')
        regular_text_tree(archive, folder, 'pmu/' + prefix + '/' + run['name'])
        processes.append(dict(name=run['name'], engine=receipt['engine'], mode=receipt['mode'],
            receipt=reference(folder / 'receipt.json'), observations=reference(folder / 'observations.json'),
            executable_sha256=receipt['executable_sha256'], adapter_sha256=receipt['adapter_sha256'],
            node_driver_sha256=receipt['node_driver_sha256'], raw_counts=totals,
            median_raw_counts_per_request={e: statistics.median(w['raw_counts'][e] for w in windows) for e in EVENTS},
            mean_raw_counts_per_request={e: totals[e] / 100 for e in EVENTS},
            ipc=totals['instructions:u'] / totals['cycles:u'],
            branch_miss_fraction=totals['branch-misses:u'] / totals['branches:u']))
    for engine in {p['engine'] for p in processes}:
        for mode in ('sync', 'async'):
            need(sum(p['engine'] == engine and p['mode'] == mode for p in processes) == 3, 'PMU requires three fresh processes per engine/mode')
    archive.add_file('pmu/' + prefix + '/driver-receipt.json', receipt_path)
    return processes


def pmu_report(archive, baseline_receipt, candidate_receipt, rsc):
    baseline = add_pmu(archive, baseline_receipt, rsc['engines']['baseline']['identity'], rsc['engines']['v8']['identity'], 'baseline')
    candidate = add_pmu(archive, candidate_receipt, rsc['engines']['candidate']['identity'], rsc['engines']['v8']['identity'], 'candidate')
    need({p['engine'] for p in baseline} == {'scriptw', 'node'}
         and 'scriptw' in {p['engine'] for p in candidate}, 'PMU baseline/control cohort missing')
    processes = baseline + candidate
    need(len({p['adapter_sha256'] for p in processes}) == len({p['node_driver_sha256'] for p in processes}) == 1, 'PMU adapter changed between cohorts')
    node_binaries = {p['executable_sha256'] for p in processes if p['engine'] == 'node'}
    need(len(node_binaries) == 1, 'PMU Node binary differs between cohorts')
    pmu_driver = ROOT / 'target/react-performance-20261103/diagnostics/count_request_pmu.py'
    node_driver = pmu_driver.with_name('node_request_profile.v2.cjs')
    need(sha(pmu_driver.read_bytes()) == processes[0]['adapter_sha256']
         and sha(node_driver.read_bytes()) == processes[0]['node_driver_sha256'], 'PMU retained driver source differs')
    archive.add_file('tools/count_request_pmu.py', pmu_driver)
    archive.add_file('tools/' + node_driver.name, node_driver)
    cohorts = {}
    for label, rows in (('baseline', baseline), ('candidate', candidate)):
        for engine in sorted({r['engine'] for r in rows}):
            for mode in ('sync', 'async'):
                selected = [r for r in rows if r['engine'] == engine and r['mode'] == mode]
                cohorts[label + '-' + engine + '-' + mode] = dict(
                    processes=selected,
                    median_of_process_median_raw_counts_per_request={e: statistics.median(r['median_raw_counts_per_request'][e] for r in selected) for e in EVENTS},
                    process_instruction_medians=[r['median_raw_counts_per_request']['instructions:u'] for r in selected],
                    median_process_ipc=statistics.median(r['ipc'] for r in selected),
                    median_process_branch_miss_fraction=statistics.median(r['branch_miss_fraction'] for r in selected))
    return dict(schema='scriptw-react-attribution-current-v2', date='2026-11-03', status='captured',
        timing_report_in_evidence=dict(path='reports/rsc-current.json', sha256=sha(encoded(rsc))),
        excluded_from_scored_cohorts=True, candidate_identity=rsc['engines']['candidate']['identity'],
        baseline_identity=rsc['engines']['baseline']['identity'], pmu=dict(fresh_processes=len(processes),
            measured_request_windows=100 * len(processes), warmup_requests=3 * len(processes), samples_per_process=100,
            warmups_per_process=3, minimum_running_fraction=1, cohorts=cohorts),
        limitations=['Unscored main-thread/worker-thread user hardware-counter diagnostic; initialization, warmups and output validation excluded.',
            'Node barrier and Promise-return edge instructions remain in counter bounds. Node background compilation/GC and other Scriptw threads are excluded.',
            'Counts are raw hardware events with full counter running time. They are not request timings, causal allocation shares, or a partition of the runtime gap.',
            'Current sampled callchains and the immediately preceding Module-cell component diagnostic are archived separately, with their own build and process identities. Sampling shares overlap and do not predict wall-time gains.'])


def compact(report):
    result = copy.deepcopy(report)
    for key in ('rows', 'commands', 'retained_files'):
        result.pop(key, None)
    for case in result['cases']:
        for runtime in case['runtimes'].values():
            for process in runtime['processes']:
                process.pop('samples_ns', None)
    fields = ('file', 'program_wasm_sha256', 'program_wasm_bytes', 'native_serialized_bytes',
              'image_sha256', 'image_bytes', 'phases_ns', 'runtime_key', 'image_path', 'wasm_path')
    for preparation in result['preparations']:
        cases = preparation['cases']
        config = cases[0]['native_configuration']
        need(all(c['native_configuration'] == config for c in cases), 'native policy configuration differs')
        preparation['native_configuration'] = config
        preparation['cases'] = [{key: c[key] for key in fields} for c in cases]
    return result


def verify_archive(path, reports):
    with tarfile.open(path, 'r:xz') as archive:
        value = archive.extractfile('INDEX.json').read()
        need(archive.extractfile('INDEX.json.sha256').read().decode().strip() == sha(value) + '  INDEX.json', 'archive index sidecar differs')
        index = json.loads(value)
        members = archive.getmembers()
        need(len(members) == len(index['members']) + 2
             and {m.name for m in members} == {r['path'] for r in index['members']} | {'INDEX.json', 'INDEX.json.sha256'}
             and all(m.isfile() and m.mode == 0o644 for m in members), 'archive inventory/type differs')
        for row in index['members']:
            data = archive.extractfile(row['path']).read()
            need(sha(data) == row['sha256'] and len(data) == row['bytes'] and b'\0' not in data, 'archive content differs')
            data.decode('utf-8', errors='strict')
        for name, report in reports.items():
            need(archive.extractfile('reports/' + name).read() == encoded(report), 'archived report differs')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-dir', type=Path, required=True)
    parser.add_argument('--native-report', type=Path, required=True, help='{source_manifest_sha256,scopes:[target,label,stdout,stderr,exit_code,executable_sha256,argv]}')
    parser.add_argument('--situations', type=Path, default=BASE / 'campaign')
    parser.add_argument('--rsc', type=Path, default=BASE / 'fast-comparison-campaign')
    parser.add_argument('--source-guards', type=Path, default=BASE / 'source-guards.stdout')
    parser.add_argument('--baseline-pmu-receipt', type=Path, default=BASE / 'baseline-pmu-receipt.json')
    parser.add_argument('--candidate-pmu-receipt', type=Path, help='6 Scriptw or12 Scriptw+Node completed runs; emits fresh attribution report')
    parser.add_argument('--extra-text-evidence', type=Path, action='append', default=[])
    args = parser.parse_args()
    destination = args.output_dir.resolve()
    need(destination.is_relative_to(ROOT / 'target') and not destination.exists(), 'output must be a new directory under target/')
    unchanged_source()
    archive = module.Archive()
    archive.add_file('tools/publish.py', Path(__file__))
    archive.add_file('tools/inert_archive.py', ARCHIVE_TOOL)
    baseline, binding = add_baseline(archive)
    source = add_source(archive, BASE / 'measured-source', 'source/measured')
    for snapshot in sorted(BASE.glob('measured-source-*')):
        if snapshot.is_dir():
            add_source(archive, snapshot, 'source/preserved-attempts/' + snapshot.name)
    ir_qualification = qualify_ir_source(archive, source)
    native_qualification = qualify_native_source(archive, source)
    coverage = add_native(archive, resolve(args.native_report), source, ir_qualification, native_qualification)
    situations = add_situations(archive, resolve(args.situations))
    rsc = add_rsc(archive, resolve(args.rsc), source, baseline, binding)
    guards_path = resolve(args.source_guards)
    guards = SUMMARY.findall(guards_path.read_text())
    need(guards and all(row[0] == 'ok' and row[2:] == ('0', '0') for row in guards)
         and sum(int(row[1]) for row in guards) == 361, 'final source guards incomplete')
    # Root-level source/build/measurement receipts and failed attempt logs are
    # text only; executables, raw Wasm, nested archives and perf.data stay out.
    for path in sorted(BASE.iterdir()):
        if path.is_file() and path.suffix in ('.json', '.stdout', '.stderr', '.py'):
            archive.add_file('verification/' + path.name, path)
    for directory in sorted(BASE.glob('verification*')):
        if directory.is_dir():
            regular_text_tree(archive, directory, 'verification/raw/' + directory.name)
    frozen = BASE / 'frozen'
    for path in sorted(frozen.glob('*.json')):
        archive.add_file('verification/frozen/' + path.name, path)
    for name, identity in (('compiler_precompiled_baseline', situations['source_identity']),
                           ('rsc_baseline', rsc['engines']['candidate']['identity'])):
        producer = read(frozen / (name + '-producer.json'))
        binary = frozen / name
        need(producer['frozen_executable_sha256'] == identity['executable_sha256'] == file_digest(binary), 'frozen producer identity differs: ' + name)
        archive.add_bytes('verification/frozen/' + name + '-identity.json', encoded(dict(
            path=binary.relative_to(ROOT).as_posix(), bytes=binary.stat().st_size,
            sha256=identity['executable_sha256'], source_manifest_sha256=source['manifest_sha256'])))
    for path in args.extra_text_evidence:
        path = resolve(path)
        need(path.is_relative_to(ROOT / 'target') and path.is_dir(), 'extra evidence must be an ignored directory')
        attribution = path / 'attribution.json'
        if attribution.exists():
            size = read(attribution)
            identity = rsc['engines']['candidate']['identity']
            need(size['schema'] == 'scriptw-rsc-wasm-size-current-v1'
                 and size['aggregate']['sha256'] == sha((resolve(args.rsc) / 'aggregate.json').read_bytes())
                 and size['program_wasm_sha256'] == identity['program_wasm_sha256']
                 and size['accounted_program_bytes'] == size['program_wasm_bytes']
                 and size['compiler']['executable_sha256'] == identity['executable_sha256']
                 and size['compiler']['source_fingerprint'] == identity['source_fingerprint'], 'static size report identity/accounting differs')
            rsc['static_program_size'] = dict(path='additional-evidence/' + attribution.relative_to(ROOT).as_posix(),
                sha256=sha(attribution.read_bytes()), program_wasm_bytes=size['program_wasm_bytes'],
                program_wasm_sha256=size['program_wasm_sha256'], limits=size['limits'])
        regular_text_tree(archive, path, 'additional-evidence/' + path.relative_to(ROOT).as_posix())
    coverage.update(source_guards_passed=361, source_guards=reference(guards_path),
                    source_guards_qualification='All 361 source-only guards pass on the frozen candidate.', cases=13, actors=3, fresh_execution_processes=312,
                    checked_invocations=3120, warmup_invocations=936, measured_invocations=2184,
                    rsc_fresh_processes=24, rsc_checked_invocations=480)
    situations['publication'] = dict(date='2026-11-03', measured_source=source, coverage=coverage,
        baseline=binding, caveats=baseline['situations-current.json']['publication']['caveats'],
        implementation=['Canonical Module activation captures reuse the existing direct-cell proof after graph, environment, slot and ancestry validation.',
                        'Existing cell reads, import TARGET forwarding, TDZ and checked writes retain runtime semantics without a new heap or cache.',
                        'One typed ObjectOwnKeys runtime helper shares the validated key table across internal consumers; public Reflect.ownKeys alone materializes its observable Array.',
                        'Runtime layout 49 rejects older cache entries and build packages before reuse.'])
    paired_folder = BASE / 'paired-fast'
    paired = read(paired_folder / 'receipt.json')
    need(paired['complete'] is True and len(paired['rows']) == 208
         and len(paired['summary']) == 13, 'paired Fast diagnostic incomplete')
    expected_identities = {'baseline': baseline['situations-current.json']['source_identity'],
                           'candidate': situations['source_identity']}
    for row in paired['rows']:
        out = paired_folder / row['stdout']
        need(row['exit_code'] == 0 and sha(out.read_bytes()) == row['stdout_sha256'], 'paired Fast raw output differs')
        raw = read(out)
        need(raw['source_fingerprint'] == expected_identities[row['actor']]['source_fingerprint']
             and raw['executable_sha256'] == expected_identities[row['actor']]['executable_sha256']
             and raw['compiler_enabled'] is False
             and len(raw['observations']) == 10
             and all(o['matched'] and o['completion'] == 'normal' for o in raw['observations']), 'paired Fast identity or output differs')
    situations['publication']['paired_fast_diagnostic'] = dict(
        excluded_from_scored_cohorts=True, fresh_processes=208, checked_invocations=2080,
        archive_prefix='additional-evidence/' + paired_folder.relative_to(ROOT).as_posix() + '/',
        receipt=reference(paired_folder / 'receipt.json'), summary=paired['summary'],
        limits=read(paired_folder / 'plan.json')['limits'])
    full = encoded(situations)
    archive.add_bytes('reports/full-situations-report.json', full)
    situations = compact(situations)
    situations['publication']['full_report'] = dict(path='reports/full-situations-report.json', sha256=sha(full), bytes=len(full))
    rsc['publication'] = dict(date='2026-11-03', measured_source=source,
                              coverage_reference='reports/full-situations-report.json', limits=coverage['limits'])
    reports = {'situations-current.json': situations, 'rsc-current.json': rsc}
    if args.candidate_pmu_receipt:
        reports['react-attribution-current.json'] = pmu_report(archive, resolve(args.baseline_pmu_receipt), resolve(args.candidate_pmu_receipt), rsc)
        profile = BASE / 'profile/sync-current'
        receipt = read(profile / 'receipt.json')
        observations = read(profile / 'observations.json')
        chains = read(profile / 'callchains.json')
        identity = rsc['engines']['candidate']['identity']
        need(receipt['status'] == 'captured' and receipt['unscored'] is True
             and receipt['samples'] == 100 and receipt['warmups'] == 3
             and receipt['mode'] == 'sync' and receipt['event'] == '0:0:u', 'current sampling receipt differs')
        for field in ('executable_sha256', 'program_wasm_sha256', 'runtime', 'inputs', 'configuration', 'source_fingerprint'):
            need(observations[field] == identity[field], 'current sampled build differs: ' + field)
        need(chains['unscored'] and chains['samples'] > 0 and chains['period_sum'] > 0, 'current sampled denominator missing')
        reports['react-attribution-current.json']['sampled_diagnostics'] = dict(
            scope='Current Fast sync worker only; 100 checked requests after three warmups; excluded from scored cohorts.',
            receipt=reference(profile / 'receipt.json'), callchains=reference(profile / 'callchains.json'),
            archive_prefix='additional-evidence/' + profile.relative_to(ROOT).as_posix() + '/',
            samples=chains['samples'], period_sum=chains['period_sum'], limits=chains['limits'],
            archived_callchains_summary='callchains-summary.json',
            derived_callchains_mapping='../derived-callchains-mapping.json',
            full_derived_rows='Regenerate from archived samples/maps using the retained symbolizer; original full-file hashes are preserved in derived-callchains-mapping.json.',
            leading_own_samples=chains['own'][:20],
            component_control=dict(source_snapshot_archive_prefix='source/preserved-attempts/measured-source-module-proof/',
                archive_prefix='additional-evidence/target/performance-module-cells-20261103/profile/',
                limits='Immediately preceding Module-cell-only component, before OwnKeys. Distinct retained process and build identities. Inclusive caller shares overlap.'))
        reports['react-attribution-current.json']['sampled_diagnostics']['diagnosis'] = read(BASE / 'profile/diagnosis.json')
        allocator = BASE / 'allocator-diagnostic/receipt.json'
        allocator_report = read(allocator)
        need(allocator_report['complete'] is True and len(allocator_report['runs']) == 8, 'allocator diagnostic incomplete')
        reports['react-attribution-current.json']['allocator_diagnostic'] = dict(
            archive_prefix='additional-evidence/target/performance-own-keys-20261103/allocator-diagnostic/',
            receipt=reference(allocator), summary=allocator_report['summary'],
            limits='Unscored allocator-only diagnostic; identical source/P/R and OptLevel::None; four fresh processes per arm. Product defaults and scored timing configuration unchanged.')

    else:
        add_pmu(archive, resolve(args.baseline_pmu_receipt), rsc['engines']['baseline']['identity'], rsc['engines']['v8']['identity'], 'baseline')
    for name, report in reports.items():
        archive.add_bytes('reports/' + name, encoded(report))
    archive.add_bytes('README.txt', (
        'One current compiler candidate, source reconstruction and failed initial emission checks, complete fresh native Engine/AOT scopes, '
        'fresh IR scope with preserved phase identity and final-source qualification, completed situations/RSC campaigns, frozen producer identities and Git-bound baseline reports. '
        'Optional PMU reports retain fresh raw user hardware-counter windows and exact output receipts separately from scored timings. '
        'Every member is inert UTF-8 text. Executables, native images, Wasm payloads, perf.data and nested old archives are excluded. '
        'Four preexisting AOT library failures stay failures. No full workspace CI or pinned Test262 conformance claim.\n').encode())
    unchanged_source()
    destination.mkdir(parents=True)
    path = destination / ARCHIVE_NAME
    metadata = archive.write(path)
    verify_archive(path, reports)
    metadata['file'] = 'docs/rust-rewrite/' + ARCHIVE_NAME
    metadata['over_5mb'] = metadata['bytes'] > 5 * 1024**2
    for name, report in reports.items():
        public = copy.deepcopy(report)
        public['evidence_archive'] = metadata
        (destination / name).write_bytes(encoded(public))
    print(json.dumps(dict(status='staged_only', output_directory=str(destination.relative_to(ROOT)),
                          evidence_archive=metadata, files=[ARCHIVE_NAME, *reports]), indent=2))


ARCHIVE_TOOL = ROOT / 'target/react-performance-20261103/archive_final.py'
spec = importlib.util.spec_from_file_location('inert_archive', ARCHIVE_TOOL)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
if __name__ == '__main__':
    main()
