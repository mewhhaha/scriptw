#!/usr/bin/env python3
"""Stage final compiler evidence; never writes or removes published docs.

Run only after the capped verification/measurement pipeline has completed.
The output directory must not exist. Review and copy its three files separately.
"""
import argparse
import copy
import difflib
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import subprocess
import tarfile

ROOT = Path(__file__).resolve().parents[2]
FIRST = ROOT / 'target/performance-climb-20261103'
FINAL = ROOT / 'target/performance-climb-env-20261103'
DOCS = ROOT / 'docs/rust-rewrite'
PRIOR = '6d5820654208656e7b0038d313b2b0737cb61ae9'
ARCHIVE_NAME = 'situations-evidence-2026-11-03.tar.xz'
EXPECTED_FAILURES = {
    'tests::bootstrap_compact_metadata::native_bootstrap_uses_complete_constructor_layouts_and_compact_remaining_native_metadata',
    'tests::error_demand_initialization::canonical_runtime_defers_the_complete_error_graph_with_a_void_realm_abi',
    'tests::intrinsic_property_layout_allocation::fresh_intrinsic_bootstrap_allocates_layout_records_not_per_property_records',
    'tests::ordered_bootstrap_allocation::eager_layout_births_keep_demand_recipe_and_constructor_allocation_owners',
}
FINAL_SCOPES = {'ir', 'emission', 'structure', 'module-cells', 'module-realm', 'language',
                'realm-modules', 'namespace-descriptors', 'embedded-comparator',
                'module-rejection', 'module-sync-policy', 'module-resource', 'module-imports'}
SUMMARY = re.compile(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;')


def need(ok, message):
    if not ok:
        raise RuntimeError(message)


def sha(value):
    return hashlib.sha256(value).hexdigest()


def encoded(value):
    return (json.dumps(value, indent=2, allow_nan=False) + '\n').encode('utf-8')


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def git_file(name):
    return subprocess.check_output(['git', 'show', PRIOR + ':docs/rust-rewrite/' + name], cwd=ROOT)


def summary(path):
    rows = SUMMARY.findall(path.read_text(encoding='utf-8'))
    need(len(rows) == 1, 'missing/ambiguous libtest summary: ' + str(path))
    state, passed, failed, ignored = rows[0]
    return dict(state=state, passed=int(passed), failed=int(failed), ignored=int(ignored))


def artifact_rows(path):
    rows = [json.loads(line) for line in path.read_text(encoding='utf-8').splitlines()]
    finishes = [r for r in rows if r.get('reason') == 'build-finished']
    need(len(finishes) == 1 and finishes[0]['success'], 'incomplete Cargo producer: ' + str(path))
    return rows


def check_campaign(folder, count=13):
    report = read(folder / 'report.json')
    actors = ['scriptw-fast', 'scriptw-speed', 'v8']
    need(report['complete'] and report['status'] == 'complete'
         and len(report['cases']) == count and len(report['rows']) == count * 24
         and report['policy']['actors'] == actors
         and report['policy']['samples'] == 7 and report['policy']['warmups'] == 3,
         'incomplete situations campaign: ' + str(folder))
    need(all(r['status'] == 'ok' for r in report['rows']), 'failed situations process')
    need(len(report['preparations']) == 2, 'missing native policy preparation')
    for case in report['cases']:
        need(set(case['runtimes']) == set(actors), 'missing actor')
        for runtime in case['runtimes'].values():
            need(runtime['status'] == 'complete' and len(runtime['process_medians_ns']) == 8
                 and len(runtime['processes']) == 8
                 and all(len(p['samples_ns']) == 7 for p in runtime['processes']),
                 'incomplete fresh-process cohort')
        receipts = [c for p in report['preparations'] for c in p['cases'] if c['file'] == case['file']]
        need(len(receipts) == 2 and receipts[0]['program_wasm_sha256'] == receipts[1]['program_wasm_sha256'],
             'Fast/Speed program bytes differ')
    return report


def add_campaign(archive, folder, prefix, report):
    for directory in ('sources', 'tooling', 'logs', 'build', 'manifests'):
        archive.add_tree(folder / directory, prefix + '/' + directory)
    archive.add_file(prefix + '/report.json', folder / 'report.json')
    for path in sorted((folder / 'images').rglob('*')):
        if path.is_file() and path.suffix in ('.js', '.mjs', '.json'):
            archive.add_file(prefix + '/' + path.relative_to(folder).as_posix(), path)
    # The producer logs and report retain binary/Wasm hashes and byte counts;
    # executable images and serialized native/Wasm payloads are intentionally absent.
    for row in report['retained_files']:
        relative = row['path']
        member = prefix + '/' + relative
        if member in archive.files:
            value = archive.files[member]
            need(sha(value) == row['sha256'] and len(value) == row['bytes'],
                 'campaign retained text changed: ' + relative)


def add_source(archive, folder, prefix):
    manifest = read(folder / 'manifest.json')
    need(manifest['base_commit'] == PRIOR, 'unexpected source base')
    patch = (folder / 'tracked.patch').read_bytes()
    need(sha(patch) == manifest['tracked_patch_sha256'], 'source patch hash differs')
    expected = set(manifest['files']) | {'manifest.json', 'tracked.patch'}
    actual = {p.relative_to(folder).as_posix() for p in folder.rglob('*') if p.is_file()}
    need(actual == expected, 'source snapshot inventory differs')
    for relative, digest in manifest['files'].items():
        need(sha((folder / relative).read_bytes()) == digest, 'source snapshot hash differs: ' + relative)
    archive.add_tree(folder, prefix)
    return dict(archive_prefix=prefix + '/', base_commit=PRIOR,
                manifest_sha256=sha((folder / 'manifest.json').read_bytes()),
                tracked_patch_sha256=sha(patch), new_files=len(manifest['files']))


def source_unchanged():
    manifest = read(FINAL / 'measured-source/manifest.json')
    patch = subprocess.check_output(['git', 'diff', '--binary', 'HEAD', '--', 'crates', 'docs/rust-rewrite/contracts'], cwd=ROOT)
    need(patch == (FINAL / 'measured-source/tracked.patch').read_bytes(), 'measured tracked source changed')
    for name, digest in manifest['files'].items():
        need(sha((ROOT / name).read_bytes()) == digest, 'measured new source changed: ' + name)


def add_root_evidence(archive, base, prefix):
    for path in sorted(base.iterdir()):
        if path.name in ('publication.stdout', 'publication.stderr', 'static-pipeline.stdout', 'static-pipeline.stderr'):
            continue
        if path.is_file() and path.suffix in ('.json', '.stdout', '.stderr', '.py'):
            archive.add_file(prefix + '/' + path.name, path)
    for path in sorted((base / 'frozen').glob('*.json')):
        archive.add_file(prefix + '/frozen/' + path.name, path)


def add_first_native(archive):
    native = read(FIRST / 'native/receipt.json')
    expected = {'scriptw_aot_wasm': (626, 4), 'scriptw_ir_integration': (758, 0),
                'emission': (42, 0), 'structure_language': (153, 0), 'aot_async': (254, 0),
                'aot_builtins': (589, 0), 'aot_language': (424, 0), 'aot_realm_modules': (453, 0)}
    need(native['source_unchanged'] and len(native['cases']) == len(expected), 'first native source/scope differs')
    seals = {}
    for group in native['build_groups'].values():
        for row in group.get('sealed_build_logs', []):
            seals[row['path']] = row
    expanded = []
    for path in sorted((FIRST / 'native').rglob('*')):
        if not path.is_file():
            continue
        member = 'verification/first/native/' + path.relative_to(FIRST / 'native').as_posix()
        if path.suffix != '.gz':
            archive.add_file(member, path)
            continue
        receipt = seals[path.relative_to(ROOT).as_posix()]
        compressed = path.read_bytes()
        need(len(compressed) == receipt['compressed_bytes'] and sha(compressed) == receipt['gzip_sha256'], 'sealed Cargo gzip changed')
        value = gzip.decompress(compressed)
        need(len(value) == receipt['uncompressed_bytes'] and sha(value) == receipt['uncompressed_sha256'], 'expanded Cargo log changed')
        archive.add_bytes(member[:-3], value)
        expanded.append(dict(receipt, expanded_archive_path=member[:-3]))
    archive.add_bytes('verification/first/expanded-cargo-log-mapping.json', encoded(expanded))
    for index, case in enumerate(native['cases']):
        outcome = case['outcomes'][0]
        need((outcome['passed'], outcome['failed']) == expected[case['target']] and outcome['ignored'] == 0,
             'first native outcomes differ')
        transcript = ROOT / case['transcript_log']
        need(sha(transcript.read_bytes()) == case['transcript_sha256'], 'watched transcript changed')
        archive.add_file(f'verification/first/watched/{index:02d}-{case["target"]}.log', transcript)
    validation = read(FIRST / 'bootstrap-validation.json')
    reproductions = read(FIRST / 'baseline-bootstrap-check.json')
    need(validation['status'] == 'passed' and validation['executions'] == 8
         and validation['raw_report_sha256'] == sha((FIRST / 'baseline-bootstrap-check.json').read_bytes()),
         'bootstrap reproduction verification differs')
    for actor in ('baseline', 'candidate'):
        rows = [r for r in reproductions if r['actor'] == actor]
        need({r['test'] for r in rows} == EXPECTED_FAILURES and len(rows) == 4
             and all(r['exit_code'] == 101 and r['summary'] == [['FAILED', '0', '1']] for r in rows),
             'preexisting bootstrap failures were lost')
    for test in EXPECTED_FAILURES:
        rows = [r for r in reproductions if r['test'] == test]
        need(rows[0]['values'] == rows[1]['values'], 'baseline/candidate failure assertion differs')
    return native


def final_coverage(native, sources):
    records = read(FINAL / 'native-verification.json')
    need({r['label'] for r in records} == FINAL_SCOPES and len(records) == len(FINAL_SCOPES), 'final native scope incomplete')
    build = artifact_rows(FINAL / 'native-build.stdout')
    binaries = {r['target']['name']: r['executable'] for r in build
                if r.get('reason') == 'compiler-artifact' and r.get('executable') and r['profile']['test']}
    fresh = []
    for row in records:
        result = summary(FINAL / (row['label'] + '.stdout'))
        need(row['exit_code'] == 0 and result['state'] == 'ok' and result['failed'] == result['ignored'] == 0
             and result['passed'] > 0 and row['summaries'] == [[result['state'], str(result['passed']), '0', '0']],
             'final native verification failed: ' + row['label'])
        need(row['argv'][0] == binaries[row['target']], 'native verification producer mismatch')
        fresh.append(dict(row, outcomes=result, source_manifest_sha256=sources['final']['manifest_sha256']))
    aot = read(FINAL / 'aot-summary.json')
    need(set(aot['failures']) == EXPECTED_FAILURES and len(aot['failures']) == 4, 'final AOT failure set changed')
    full = summary(FINAL / 'aot-full.stdout')
    need(full['state'] == 'FAILED' and full['failed'] == 4 and full['ignored'] == 0, 'final full AOT outcome differs')
    aot_build = artifact_rows(FINAL / 'aot-build.stdout')
    aot_producer = [r for r in aot_build if r.get('reason') == 'compiler-artifact'
                    and r.get('target', {}).get('name') == 'scriptw_aot_wasm' and r.get('executable')]
    need(len(aot_producer) == 1 and aot_producer[0]['executable'] == aot['executable'], 'final AOT producer differs')
    failed = set(re.findall(r'^    (\S+)\s*$', (FINAL / 'aot-full.stdout').read_text().split('failures:\n')[-1], re.M))
    need(failed == EXPECTED_FAILURES, 'final raw AOT failures differ')
    reused = []
    for target in ('aot_builtins', 'aot_async'):
        old = next(r for r in native['cases'] if r['target'] == target)
        inventory = set(re.findall(r'^(.*): test$', (ROOT / old['inventory_log']).read_text(), re.M))
        newly_checked = set()
        for row in records:
            if row['target'] == target:
                names = re.findall(r'^test (.*?) \.\.\. ok$', (FINAL / (row['label'] + '.stdout')).read_text(), re.M)
                need(len(names) == int(row['summaries'][0][1]), 'fresh Module test names unavailable')
                newly_checked.update(names)
        need(newly_checked <= inventory, 'fresh Module tests differ from first inventory')
        names = sorted(inventory - newly_checked)
        reused.append(dict(target=target, passed=len(names), failed=0, ignored=0,
                           source_manifest_sha256=sources['first']['manifest_sha256'],
                           executable_sha256=old['executable_sha256'],
                           names=names,
                           reason='Script-only tests reused from the first source/binary. The second source delta only prunes synthetic Module storage; selected Module cases reran on the final binary.'))
    need(sum(r['passed'] for r in reused) == 837, 'reused Script-only coverage differs')
    guards = SUMMARY.findall((FINAL / 'source-guards.stdout').read_text())
    need(guards and all(r[0] == 'ok' and r[2:] == ('0', '0') for r in guards), 'source guards failed')
    pipeline = read(FINAL / 'pipeline.json')
    need([r['label'] for r in pipeline] == ['aot-build', 'storage', 'activation', 'tables', 'aot-full', 'native', 'build', 'measure']
         and all(r['exit_code'] == 0 for r in pipeline if r['label'] != 'aot-full')
         and next(r for r in pipeline if r['label'] == 'aot-full')['exit_code'] == 101, 'final pipeline incomplete')
    for name in ('storage', 'activation', 'tables'):
        result = summary(FINAL / (name + '.stdout'))
        need(result['state'] == 'ok' and result['passed'] > 0 and result['failed'] == result['ignored'] == 0, 'focused AOT scope failed')
    return dict(fresh_native=fresh, final_aot_library=dict(aot, outcomes=full, status='failed_preexisting'),
                reused_first_source_script_only=reused,
                source_guards_passed=sum(int(r[1]) for r in guards),
                limits='No full workspace CI or pinned Test262 rerun. Focused scopes overlap broad scopes and must not be summed. Four failing AOT library tests remain failures, never counted as passes.')


def prior_reports(archive):
    reports = {}
    for name in ('situations-current.json', 'rsc-current.json'):
        value = git_file(name)
        archive.add_bytes('baseline/git-' + PRIOR + '/' + name, value)
        reports[name] = json.loads(value)
    need(git_file('situations-current.json') == (FIRST / 'baseline-current.json').read_bytes(), 'saved baseline report differs from Git')
    for name, report in reports.items():
        evidence = report['evidence_archive']
        path = ROOT / evidence['file']
        if name == 'situations-current.json':
            path = FIRST / 'baseline-evidence.tar.xz'
        data = path.read_bytes()
        need(sha(data) == evidence['sha256'] and len(data) == evidence['bytes'], 'prior evidence archive identity differs: ' + name)
    return reports


def rsc_campaign(archive, base, prefix, prior):
    folder = base / 'fast-comparison-campaign'
    campaign = read(folder / 'campaign.json')
    aggregate = read(folder / 'aggregate.json')
    need(campaign['schema'] == 'scriptw-rsc-fast-campaign-v1' and campaign['status'] == 'complete'
         and len(campaign['processes']) == 24 and all(r['status'] == 'complete' for r in campaign['processes'])
         and aggregate['schema'] == 'scriptw-rsc-fast-comparison-v1', 'RSC campaign incomplete')
    need(aggregate['measurement']['campaign_sha256'] == sha((folder / 'campaign.json').read_bytes()), 'RSC campaign hash differs')
    identity = aggregate['engines']['baseline']['identity']
    old_identity = prior['engines']['candidate']['identity']
    for field in ('executable_sha256', 'source_fingerprint', 'program_wasm_sha256', 'configuration', 'inputs', 'source_commit'):
        need(identity[field] == old_identity[field], 'RSC prior public candidate identity differs: ' + field)
    archive.add_file(prefix + '/campaign.json', folder / 'campaign.json')
    archive.add_file(prefix + '/aggregate.json', folder / 'aggregate.json')
    counts = {engine: 0 for engine in ('baseline', 'candidate', 'v8')}
    blocks = {}
    for row in campaign['processes']:
        engine = row['engine']
        counts[engine] += 1
        blocks[(row['block'], engine)] = blocks.get((row['block'], engine), 0) + 1
        for field in ('report', 'stdout', 'stderr'):
            relative = row[field]
            value = (folder / relative).read_bytes()
            need(sha(value) == row[field + '_sha256'], 'RSC process text changed: ' + relative)
            archive.add_bytes(prefix + '/' + relative, value)
        directory = Path(row['stdout']).parent
        archive.add_file(prefix + '/' + (directory / 'resources.json').as_posix(), folder / directory / 'resources.json')
    need(all(count == 8 for count in counts.values()) and len(blocks) == 6
         and all(count == 4 for count in blocks.values()), 'RSC balanced schedule differs')
    for name in ('measure_fast_comparison.py', 'react-driver.cjs', 'baseline-identity-report.json'):
        archive.add_file(prefix + '/' + name, folder / name)
    candidate_source = aggregate['source_identity']['candidate_measured_source']
    need(candidate_source['manifest_sha256'] == sha((base / 'measured-source/manifest.json').read_bytes()), 'RSC measured source manifest differs')
    candidate_producer = read(base / 'frozen/rsc_baseline-producer.json')
    need(candidate_producer['frozen_executable_sha256'] == aggregate['engines']['candidate']['identity']['executable_sha256'], 'RSC producer executable differs')
    # Correct the old raw generator's filename claim only in the public report;
    # the original aggregate stays byte-for-byte intact in the archive.
    result = copy.deepcopy(aggregate)
    result['schema'] = 'scriptw-rsc-current-v1'
    result['source_identity']['baseline_source'] = dict(
        public_report_git_commit=PRIOR, public_report='docs/rust-rewrite/rsc-current.json',
        public_report_sha256=sha(git_file('rsc-current.json')), evidence_archive=prior['evidence_archive'],
        measured_source=prior['source_identity']['candidate_measured_source'],
        note='Verified prior public candidate identity, archive hash/size and source manifest; raw aggregate retains its original stale filename string.')
    return result


def compact(report):
    result = copy.deepcopy(report)
    for key in ('rows', 'commands', 'retained_files'):
        result.pop(key, None)
    for case in result['cases']:
        for runtime in case['runtimes'].values():
            for process in runtime['processes']:
                process.pop('samples_ns', None)
    fields = ('file', 'program_wasm_sha256', 'program_wasm_bytes', 'native_serialized_bytes',
              'image_sha256', 'image_bytes', 'phases_ns', 'runtime_key', 'image_path', 'wasm_path')
    for preparation in result['preparations']:
        cases = preparation['cases']
        configuration = cases[0]['native_configuration']
        need(all(c['native_configuration'] == configuration for c in cases), 'native configuration differs')
        preparation['native_configuration'] = configuration
        preparation['cases'] = [{key: c[key] for key in fields} for c in cases]
    return result


def verify_archive(path, expected):
    with tarfile.open(path, 'r:xz') as archive:
        value = archive.extractfile('INDEX.json').read()
        need(archive.extractfile('INDEX.json.sha256').read().decode().strip() == sha(value) + '  INDEX.json', 'archive index sidecar differs')
        index = json.loads(value)
        members = archive.getmembers()
        need(len(members) == len(index['members']) + 2
             and {m.name for m in members} == {r['path'] for r in index['members']} | {'INDEX.json', 'INDEX.json.sha256'}
             and all(m.isfile() and m.mode == 0o644 for m in members), 'archive member inventory/type differs')
        for row in index['members']:
            data = archive.extractfile(row['path']).read()
            need(len(data) == row['bytes'] and sha(data) == row['sha256'] and b'\0' not in data, 'archive content differs')
            data.decode('utf-8', errors='strict')
        for name, report in expected.items():
            need(archive.extractfile('reports/' + name).read() == encoded(report), 'archived report differs')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-dir', type=Path, required=True, help='new ignored staging directory; never docs/')
    parser.add_argument('--without-rsc', action='store_true', help='explicitly omit public RSC replacement; situations evidence still retains existing RSC campaigns')
    parser.add_argument('--extra-text-evidence', type=Path, action='append', default=[], help='completed static size/profile text evidence directory; may repeat')
    args = parser.parse_args()
    destination = args.output_dir.resolve()
    need(destination.is_relative_to(ROOT / 'target') and not destination.exists(), 'staging must be a new directory under target/')
    source_unchanged()
    final_report = check_campaign(FINAL / 'campaign')
    first_report = check_campaign(FIRST / 'campaign')
    refresh = check_campaign(FIRST / 'baseline-refresh', count=5)
    for base in (FIRST, FINAL):
        receipts = read(base / 'measurement-receipt.json')
        need([r['name'] for r in receipts] == ['campaign', 'rsc-campaign'] and all(r['exit_code'] == 0 for r in receipts), 'measurement pipeline incomplete')
        artifact_rows(base / 'build.stdout')
        producer = read(base / 'frozen/compiler_precompiled_baseline-producer.json')
        campaign_report = read(base / 'campaign/report.json')
        need(producer['frozen_executable_sha256'] == campaign_report['source_identity']['executable_sha256'], 'situations producer executable differs')
    spec = importlib.util.spec_from_file_location('inert_archive', ROOT / 'target/react-performance-20261103/archive_final.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    archive = module.Archive()
    archive.add_file('tools/publish.py', Path(__file__))
    archive.add_file('tools/inert_archive.py', ROOT / 'target/react-performance-20261103/archive_final.py')
    prior = prior_reports(archive)
    sources = {label: add_source(archive, base / 'measured-source', 'source/' + label + '-measured')
               for label, base in (('first', FIRST), ('final', FINAL))}
    patch_first = (FIRST / 'measured-source/tracked.patch').read_text().splitlines(keepends=True)
    patch_final = (FINAL / 'measured-source/tracked.patch').read_text().splitlines(keepends=True)
    def patches(lines):
        return {m.group(1): m.group(0) for m in re.finditer(r'^diff --git a/(.*?) b/.*?(?=^diff --git |\Z)', ''.join(lines), re.M | re.S)}
    first_patches, final_patches = patches(patch_first), patches(patch_final)
    changed = sorted(name for name in first_patches.keys() | final_patches.keys()
                     if first_patches.get(name) != final_patches.get(name))
    need(set(changed) == {
        'crates/scriptw-ir/src/analysis.rs', 'crates/scriptw-ir/src/analysis/module_locals.rs',
        'crates/scriptw-ir/tests/module_captured_cells.rs', 'crates/scriptw-aot-wasm/src/tests.rs',
        'crates/scriptw-engine/tests/aot_realm_modules/aot_shadow_realm_import_value.rs',
        'crates/scriptw-engine/tests/aot_realm_modules/aot_module_captured_cells.rs',
        'docs/rust-rewrite/contracts/reference-records.md'}, 'unexpected second source delta; reevaluate Script-only reuse')
    first_new = read(FIRST / 'measured-source/manifest.json')['files']
    final_new = read(FINAL / 'measured-source/manifest.json')['files']
    need(all(final_new.get(k) == v for k, v in first_new.items())
         and set(final_new) - set(first_new) == {'crates/scriptw-aot-wasm/src/tests/module_synthetic_storage.rs'},
         'unexpected second new-source delta; reevaluate Script-only reuse')
    archive.add_bytes('source/second-batch-delta.json', encoded(dict(changed_tracked_files=changed,
        added_files=sorted(set(final_new) - set(first_new)),
        reuse_boundary='Only Module synthetic-storage pruning changes product behavior; Script-only builtin/async coverage reuses original source and executable identities.')))
    archive.add_bytes('source/first-to-final-patch-difference.diff', ''.join(difflib.unified_diff(patch_first, patch_final, fromfile='first/tracked.patch', tofile='final/tracked.patch')).encode())
    for base, prefix in ((FIRST, 'verification/first'), (FINAL, 'verification/final')):
        add_root_evidence(archive, base, prefix)
    native = add_first_native(archive)
    coverage = final_coverage(native, sources)
    for base, label, report in ((FIRST, 'first', first_report), (FINAL, 'final', final_report)):
        add_campaign(archive, base / 'campaign', 'situations/' + label, report)
    add_campaign(archive, FIRST / 'baseline-refresh', 'situations/baseline-refresh', refresh)
    rsc_campaign(archive, FIRST, 'rsc/first', prior['rsc-current.json'])
    rsc = rsc_campaign(archive, FINAL, 'rsc/final', prior['rsc-current.json'])
    rsc_inputs = rsc['engines']['candidate']['identity']['inputs']
    for field in ('source', 'support'):
        fixture = Path(rsc_inputs[field])
        value = fixture.read_bytes()
        need(sha(value) == rsc_inputs[field + '_sha256'], 'RSC fixture source changed')
        archive.add_bytes('fixtures/rsc/' + fixture.name, value)
    for name in ('benchmark_metrics.py', 'limited_verification.py'):
        path = ROOT / 'scripts' / name
        need(sha(path.read_bytes()) == rsc['inputs'][str(path)], 'RSC shared measurement tool changed')
        archive.add_file('tools/' + name, path)
    # Bind the baseline measured source to its actual prior archive member hash.
    old = prior['rsc-current.json']
    evidence_path = ROOT / old['evidence_archive']['file']
    source = old['source_identity']['candidate_measured_source']
    with tarfile.open(evidence_path, 'r:xz') as previous:
        index_bytes = previous.extractfile('INDEX.json').read()
        need(previous.extractfile('INDEX.json.sha256').read().decode().strip() == sha(index_bytes) + '  INDEX.json', 'prior RSC index changed')
        inventory = {r['path']: r for r in json.loads(index_bytes)['members']}
        manifest_name = source['archive_prefix'] + 'manifest.json'
        need(inventory[manifest_name]['sha256'] == source['manifest_sha256'], 'prior RSC source manifest identity differs')
        for name in sorted(n for n in inventory if n.startswith(source['archive_prefix'])):
            value = previous.extractfile(name).read()
            need(sha(value) == inventory[name]['sha256'] and len(value) == inventory[name]['bytes'], 'prior RSC source changed')
            archive.add_bytes('baseline/rsc-prior-source/' + name.removeprefix(source['archive_prefix']), value)
    for path in args.extra_text_evidence:
        path = path.resolve(strict=True)
        need(path.is_relative_to(ROOT / 'target') and path.is_dir(), 'extra evidence must be an ignored directory')
        attribution = path / 'attribution.json'
        if attribution.exists():
            size = read(attribution)
            identity = rsc['engines']['candidate']['identity']
            need(size['schema'] == 'scriptw-rsc-wasm-size-current-v1'
                 and size['aggregate']['sha256'] == sha((FINAL / 'fast-comparison-campaign/aggregate.json').read_bytes())
                 and size['program_wasm_sha256'] == identity['program_wasm_sha256']
                 and size['accounted_program_bytes'] == size['program_wasm_bytes']
                 and size['compiler']['executable_sha256'] == identity['executable_sha256']
                 and size['compiler']['source_fingerprint'] == identity['source_fingerprint']
                 and size['inputs'] == identity['inputs'], 'static size report identity/accounting incomplete')
            rsc['static_program_size'] = dict(path='additional-evidence/' + attribution.relative_to(ROOT).as_posix(),
                sha256=sha(attribution.read_bytes()), program_wasm_bytes=size['program_wasm_bytes'],
                program_wasm_sha256=size['program_wasm_sha256'],
                limits='Static encoded-byte accounting; not runtime cost shares or allocation counts.')
        archive.add_tree(path, 'additional-evidence/' + path.relative_to(ROOT).as_posix())
    # Before/after figures are Scriptw-only same-host descriptions. V8 controls
    # may be bimodal; the public report retains their own ranges without ratios.
    baseline_cases = {c['file']: c for c in refresh['cases']}
    final_report['comparison'] = dict(scope='descriptive same-host frozen baseline refresh; selected Scriptw cases only; no V8 baseline or compiler ratio claim',
        baseline_identity=refresh['source_identity'], baseline_report_sha256=sha((FIRST / 'baseline-refresh/report.json').read_bytes()),
        cases=[dict(file=c['file'], ratios={a: c['runtimes'][a]['median_ns'] / baseline_cases[c['file']]['runtimes'][a]['median_ns']
                                           for a in ('scriptw-fast', 'scriptw-speed')})
               for c in final_report['cases'] if c['file'] in baseline_cases])
    coverage.update(cases=13, actors=3, fresh_execution_processes=312, checked_invocations=3120,
                    warmup_invocations=936, measured_invocations=2184,
                    rsc_fresh_processes=24, rsc_cases_per_process=2, rsc_checked_invocations=480,
                    rsc_warmup_invocations=144, rsc_measured_invocations=336,
                    first_native=[{k: c[k] for k in ('package', 'target', 'state', 'outcomes', 'executable_sha256')}
                                  for c in native['cases']])
    final_report['publication'] = dict(date='2026-11-03', measured_source=sources['final'],
        first_measured_source=sources['first'], coverage=coverage,
        baseline=dict(git_commit=PRIOR, report='docs/rust-rewrite/situations-current.json',
                      report_sha256=sha(git_file('situations-current.json')),
                      evidence_archive=prior['situations-current.json']['evidence_archive']),
        caveats=prior['situations-current.json']['publication']['caveats'],
        implementation=[
            'Proven unbound references in static ordinary Module functions start at the defining Realm Global Environment Record; live values, lexicals, getters and evaluation order remain.',
            'Observer-free strict ordinary functions omit only the implicit arguments object.',
            'Bounded dense integer literal switches use guarded Wasm br_table dispatch.',
            'Module-only storage pruning removes proven synthetic entry values while preserving captured context owners.'])
    full = encoded(final_report)
    archive.add_bytes('reports/full-report.json', full)
    report = compact(final_report)
    report['publication']['full_report'] = dict(path='reports/full-report.json', sha256=sha(full), bytes=len(full))
    # Keep the complete reused-name inventory in full-report only.
    for row in report['publication']['coverage']['reused_first_source_script_only']:
        row.pop('names')
    rsc['source_identity']['candidate_measured_source'] = sources['final']
    rsc['publication'] = dict(date='2026-11-03', prior_public_report_git_commit=PRIOR,
                              coverage_reference='reports/full-report.json', limits=coverage['limits'])
    archived_reports = {'situations-current.json': report}
    if not args.without_rsc:
        archived_reports['rsc-current.json'] = rsc
    for name, value in archived_reports.items():
        archive.add_bytes('reports/' + name, encoded(value))
    archive.add_bytes('README.txt', (
        'Final compiler evidence. First and final source patches/new files, completed situations and RSC campaigns, '
        'frozen Cargo producer receipts, first native receipt with expanded sealed Cargo logs and watched transcripts, '
        'final native/AOT verification, baseline refresh, and Git-bound prior public reports are retained. '
        'Every archive member is inert UTF-8 text. Executables, Wasm/native images, gzip payloads and perf.data are excluded. '
        'Binary/Wasm identities and sizes remain in receipts. Four preexisting AOT library failures remain failures. '
        '837 Script-only builtin/async tests are reused from the first source/binary and are distinguished from fresh final scopes. '
        'Focused scopes overlap broader scopes; do not sum them. Not full workspace CI or pinned Test262 conformance.\n').encode())
    source_unchanged()
    destination.mkdir(parents=True)
    output = destination / ARCHIVE_NAME
    metadata = archive.write(output)
    verify_archive(output, archived_reports)
    metadata['file'] = 'docs/rust-rewrite/' + ARCHIVE_NAME
    metadata['over_5mb'] = metadata['bytes'] > 5 * 1024**2
    for name, value in archived_reports.items():
        public = copy.deepcopy(value)
        public['evidence_archive'] = metadata
        (destination / name).write_bytes(encoded(public))
    print(json.dumps(dict(status='staged_only', output_directory=str(destination.relative_to(ROOT)), evidence_archive=metadata,
                          files=[ARCHIVE_NAME, *archived_reports]), indent=2))


if __name__ == '__main__':
    main()
