(function memoryProbe() {
print("scriptw:rows:construction:start");

print("scriptw:rows:traversal:start");
print("scriptw-startup-ok");

print("scriptw:rows:traversal:end");
})();
