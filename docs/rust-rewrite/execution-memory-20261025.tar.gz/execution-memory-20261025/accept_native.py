import pathlib,subprocess,sys
root=pathlib.Path(__file__).resolve().parent
for name in ['engine_batches.py','native_final.py']:
 code=subprocess.call([sys.executable,'-B',str(root/name)])
 if code:sys.exit(code)
print('ALL COMPLETE NATIVE INVENTORIES CLOSED',flush=True)
