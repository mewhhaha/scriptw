#!/usr/bin/env python3
"""Link the ignored Intl allocation probe against actual opt3 Cargo artifacts.

Run only under scripts/limited_verification.py after native verification.
No Cargo build is invoked and unrelated Wasmtime/runtime-image native archives
are not linked into this Intl-only diagnostic. --run executes the linked probe.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time


BASE = Path(__file__).resolve().parent
ROOT = BASE.parent.parent
SOURCE = BASE / 'intl_allocation_diagnostic.rs'
sys.path.insert(0, str(ROOT / 'scripts'))
from limited_verification import require_kernel_budget


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def stamp():
    return datetime.now(timezone.utc).isoformat()


def cargo_producer(path):
    selected = {}
    native = []
    for line in path.open():
        event = json.loads(line)
        if event.get('reason') == 'build-script-executed' and (event.get('linked_paths') or event.get('linked_libs')):
            native.append({key: event.get(key, []) for key in ('package_id', 'linked_paths', 'linked_libs')})
        if event.get('reason') != 'compiler-artifact':
            continue
        target, profile = event.get('target', {}), event.get('profile', {})
        if target.get('name') != 'scriptw_intl' or target.get('kind') != ['lib']:
            continue
        if profile.get('opt_level') != '3' or profile.get('test') or event.get('features'):
            continue
        require(Path(event['manifest_path']).resolve() == ROOT / 'crates/scriptw-intl/Cargo.toml',
                'Cargo Intl producer belongs to another source tree')
        filenames = [Path(name) for name in event['filenames'] if name.endswith('.rlib')]
        require(len(filenames) == 1, 'Cargo Intl producer needs one actual rlib')
        selected[str(filenames[0].resolve())] = (event, filenames[0])
    require(len(selected) == 1, 'need exactly one actual opt3/default-feature Intl rlib')
    producer, rlib = next(iter(selected.values()))
    require(rlib.is_file() and rlib.parent.name == 'deps', 'actual Cargo Intl rlib is missing')
    # The current public Intl/runtime dependency surface is pure Rust. Its own
    # build producer declares no native libraries. Require that fact rather
    # than adding engine, Wasmtime, blake3 or runtime-image paths opportunistically.
    own_native = [row for row in native if row['package_id'] == producer['package_id']]
    require(not any(row['linked_paths'] or row['linked_libs'] for row in own_native),
            'Intl producer now declares native inputs; audit this probe before linking')
    return producer, rlib, native


def run(args):
    require_kernel_budget(4 * 1024**3)
    require(sorted(os.sched_getaffinity(0)) == [0], 'need inherited one-CPU affinity [0]')
    build_log = args.build_log.resolve()
    require(build_log.is_file(), 'actual final cargo-product.jsonl is required')
    producer, rlib, excluded_native = cargo_producer(build_log)
    # Preserve the rustc proxy's invocation name. Resolving a rustup symlink
    # before executing it would invoke `rustup` instead of the rustc proxy.
    rustc = Path(shutil.which(os.environ.get('RUSTC', 'rustc')) or '/missing-rustc')
    require(rustc.is_file(), 'rustc is required')
    output = args.output_dir.resolve()
    require(output.is_relative_to(BASE) and output != BASE, 'output must be a new directory in the ignored campaign')
    output.mkdir(exist_ok=False)
    binary = output / 'intl_allocation_diagnostic'
    report = {
        'schema': 'scriptw-intl-allocation-probe-link-v1', 'complete': False,
        'started_at': stamp(), 'launcher_checkout_head': subprocess.check_output(
            ['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
        'source': {'path': str(SOURCE), 'sha256': digest(SOURCE)},
        'driver': {'path': str(Path(__file__).resolve()), 'sha256': digest(__file__)},
        'cargo_build_log': {'path': str(build_log), 'sha256': digest(build_log)},
        'producer': producer,
        'rlib': {'path': str(rlib), 'resolved_path': str(rlib.resolve()), 'sha256': digest(rlib),
                 'bytes': rlib.stat().st_size},
        'rustc': {'invoker_path': str(rustc), 'resolved_invoker_path': str(rustc.resolve()),
                  'invoker_sha256': digest(rustc)},
        'dependency_directory': str(rlib.parent),
        'native_linked_paths': [],
        'unrelated_native_cargo_producers_excluded': excluded_native,
        'native_link_policy': 'Current Intl runtime dependencies are pure Rust; no Wasmtime/runtime-image/native engine archives are needed or admitted.',
        'input_metadata': {str(path.relative_to(ROOT)): digest(path) for path in (
            ROOT / 'Cargo.lock', ROOT / 'Cargo.toml', ROOT / 'crates/scriptw-intl/Cargo.toml')},
        'cpu_affinity': sorted(os.sched_getaffinity(0)), 'commands': [],
        'scope': 'Diagnostic requested Rust System allocations for public Minimal Intl selection; not JavaScript heap, RSS, allocator usable bytes or total OS allocation.',
    }

    def save():
        pending = output / 'report.pending'
        pending.write_text(json.dumps(report, indent=2) + '\n')
        pending.replace(output / 'report.json')

    def invoke(label, command, timeout):
        event = {'label': label, 'command': list(map(str, command)), 'cwd': str(ROOT),
                 'started_at': stamp(), 'state': 'running',
                 'stdout_file': label + '.stdout', 'stderr_file': label + '.stderr'}
        report['commands'].append(event)
        save()
        started = time.monotonic()
        with (output / event['stdout_file']).open('xb') as stdout, (output / event['stderr_file']).open('xb') as stderr:
            try:
                result = subprocess.run(command, cwd=ROOT, stdout=stdout, stderr=stderr, timeout=timeout)
                event.update(exit_code=result.returncode, state='closed', timed_out=False)
            except subprocess.TimeoutExpired:
                event.update(exit_code=None, state='closed', timed_out=True)
            event.update(seconds=time.monotonic() - started, finished_at=stamp())
        event['stdout_sha256'] = digest(output / event['stdout_file'])
        event['stderr_sha256'] = digest(output / event['stderr_file'])
        save()
        require(event['exit_code'] == 0 and not event['timed_out'], label + ' failed; original logs retained')
        return (output / event['stdout_file']).read_text()

    save()
    report['rustc']['verbose_version'] = invoke('rustc-version', [rustc, '-vV'], 30)
    command = [rustc, '--edition=2021', '--crate-name=scriptw_intl_allocation_diagnostic',
               '--crate-type=bin', '-Copt-level=3', '-Cdebuginfo=0', '-Ccodegen-units=1',
               '-Ldependency=' + str(rlib.parent), '--extern', 'scriptw_intl=' + str(rlib),
               str(SOURCE), '-o', str(binary)]
    invoke('compile', command, 600)
    require(digest(rlib) == report['rlib']['sha256'] and digest(SOURCE) == report['source']['sha256']
            and digest(build_log) == report['cargo_build_log']['sha256'], 'link inputs changed during compilation')
    report['binary'] = {'path': str(binary), 'sha256': digest(binary), 'bytes': binary.stat().st_size}
    if args.run:
        text = invoke('allocation', [binary], 180)
        observation = json.loads(text)
        require(observation['schema'] == 'scriptw-intl-requested-allocation-diagnostic-v1'
                and observation['component_count'] == len(observation['components']) == 12,
                'probe did not resolve the full public Minimal component set')
        expected = ['before_selection_constructor', 'after_selection_constructor',
                    'after_all_services_and_identity_resolution',
                    'after_dropping_local_selection_and_frame_leases']
        require([row['phase'] for row in observation['snapshots']] == expected,
                'probe snapshots are missing or reordered')
        require(sum(row['bytes'] for row in observation['components']) == observation['serialized_frame_bytes'],
                'serialized frame total differs')
        for row in observation['snapshots']:
            require(row['total_successful_request_bytes'] - row['total_released_request_bytes']
                    == row['requested_live_bytes'], 'counter allocation/release totals do not reconcile')
            require(row['peak_tracked_requested_live_bytes'] >= row['requested_live_bytes'],
                    'tracked logical peak is below current requested bytes')
        require(digest(binary) == report['binary']['sha256'], 'executed binary changed')
        report['observation'] = observation
    report.update(complete=True, finished_at=stamp(), executed=args.run)
    save()
    print(json.dumps({'complete': True, 'executed': args.run, 'report': str(output / 'report.json'),
                      'rlib_sha256': report['rlib']['sha256'], 'binary_sha256': report['binary']['sha256']}))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--build-log', type=Path, default=BASE / 'cargo-product.jsonl')
    parser.add_argument('--output-dir', type=Path, default=BASE / 'intl-allocation-probe')
    parser.add_argument('--run', action='store_true')
    try:
        run(parser.parse_args())
    except (ValueError, KeyError, OSError, TypeError, subprocess.SubprocessError) as error:
        print('Intl allocation diagnostic failed: ' + str(error), file=sys.stderr)
        raise SystemExit(1)
