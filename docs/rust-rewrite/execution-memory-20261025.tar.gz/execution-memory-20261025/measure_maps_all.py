import pathlib,subprocess,sys
root=pathlib.Path(__file__).resolve().parent
for product,label in [('baseline','baseline-maps-round-a'),('candidate','candidate-maps-round-b'),('candidate','candidate-maps-round-c'),('baseline','baseline-maps-round-d')]:
 command=[sys.executable,'-B','scripts/profile_memory_maps.py','--runner',str(root/product/'runtime_baseline'),'--output',str(root/(label+'-data'))]
 code=subprocess.call([sys.executable,'-B',str(root/'run_check.py'),label,*command])
 if code:sys.exit(code)
