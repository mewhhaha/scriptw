"""Read-only admission of the standalone requested-Rust-allocation diagnostic."""
from datetime import datetime, timedelta
import hashlib
import json
from pathlib import Path
import re

BASE = Path(__file__).resolve().parent
REPO = BASE.parent.parent
PHASES = ('before_selection_constructor', 'after_selection_constructor',
          'after_all_services_and_identity_resolution',
          'after_dropping_local_selection_and_frame_leases')
COUNTERS = ('requested_live_bytes', 'peak_tracked_requested_live_bytes',
            'total_successful_request_bytes', 'total_released_request_bytes',
            'alloc_calls', 'alloc_zeroed_calls', 'realloc_calls', 'dealloc_calls')
COMPONENTS = {
    'scriptw.intl-locale-data.v1', 'scriptw.intl-list-data.v1', 'scriptw.intl-collator-data.v1',
    'scriptw.intl-number-profiles.v1', 'scriptw.intl-segmenter-data.v1',
    'scriptw.intl-display-names-data.v1', 'scriptw.intl-relative-time.v1',
    'scriptw.intl-duration-data.v1', 'scriptw.intl-named-time-zone-data.v1',
    'scriptw.intl-datetime-data.v1', 'scriptw.intl-time-zone-names-data.v1',
    'scriptw.intl-locale-information.v1',
}


def require(condition, message):
    if not condition:
        raise ValueError('Intl allocation diagnostic: ' + message)


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def read(path):
    path = Path(path)
    require(path.is_file() and not path.is_symlink(), 'missing or symlinked metadata: ' + str(path))
    return json.loads(path.read_text())


def stamp(value):
    instant = datetime.fromisoformat(value.replace('Z', '+00:00'))
    require(instant.utcoffset() is not None, 'timestamp lacks timezone')
    return instant


def owned(directory, name):
    require(isinstance(name, str) and Path(name).name == name and name not in ('', '.', '..'),
            'command transcript escapes its directory')
    path = directory / name
    require(path.is_file() and not path.is_symlink(), 'missing or symlinked command transcript')
    return path


def finite_u64(value, role):
    require(type(value) is int and 0 <= value < 2**64, 'invalid unsigned byte/call counter: ' + role)
    return value


def build_report(evidence, source):
    receipt, outer_log = evidence.receipt('intl-allocation-diagnostic')
    source_path, driver_path = BASE / 'intl_allocation_diagnostic.rs', BASE / 'intl_allocation_diagnostic.py'
    require(len(receipt['command']) == 4 and receipt['command'][1] == '-B'
            and Path(receipt['command'][2]).resolve() == driver_path
            and receipt['command'][3] == '--run', 'outer diagnostic invocation differs')
    directory = BASE / 'intl-allocation-probe'
    path = directory / 'report.json'
    report = read(path)
    require(report.get('schema') == 'scriptw-intl-allocation-probe-link-v1'
            and report.get('complete') is True and report.get('executed') is True
            and report.get('launcher_checkout_head') == source and report.get('cpu_affinity') == [0],
            'diagnostic is incomplete, unexecuted or from another source')
    require(report['source'] == {'path': str(source_path), 'sha256': digest(source_path)}
            and report['driver'] == {'path': str(driver_path), 'sha256': digest(driver_path)},
            'diagnostic reproducer source/driver changed')
    cargo_path = BASE / 'cargo-product.jsonl'
    require(report['cargo_build_log'] == {'path': str(cargo_path), 'sha256': digest(cargo_path)},
            'diagnostic did not use the final actual Cargo producers')
    producer, candidates, native = report['producer'], {}, []
    for line in cargo_path.read_text().splitlines():
        item = json.loads(line)
        if item.get('reason') == 'build-script-executed' and (item.get('linked_paths') or item.get('linked_libs')):
            native.append({key: item.get(key, []) for key in ('package_id', 'linked_paths', 'linked_libs')})
        if item.get('reason') != 'compiler-artifact' or item.get('target', {}).get('name') != 'scriptw_intl':
            continue
        if item['target']['kind'] != ['lib'] or item['profile']['opt_level'] != '3' or item['profile']['test'] or item['features']:
            continue
        files = [name for name in item['filenames'] if name.endswith('.rlib')]
        require(len(files) == 1, 'actual Intl producer lacks exactly one rlib')
        candidates[str(Path(files[0]).resolve())] = item
    rlib = report['rlib']
    require(len(candidates) == 1 and candidates.get(rlib['resolved_path']) == producer
            and Path(producer['manifest_path']).resolve() == REPO / 'crates/scriptw-intl/Cargo.toml'
            and rlib['path'] in producer['filenames']
            and Path(rlib['path']).resolve() == Path(rlib['resolved_path']),
            'diagnostic Intl producer differs from the actual ordinary release artifact')
    rlib_path = Path(rlib['path'])
    require(rlib_path.is_file() and rlib_path.stat().st_size == rlib['bytes']
            and digest(rlib_path) == rlib['sha256'], 'actual diagnostic input rlib bytes changed')
    require(report['native_linked_paths'] == [] and report['unrelated_native_cargo_producers_excluded'] == native
            and not any(row['package_id'] == producer['package_id'] for row in native),
            'standalone Intl producer admitted unrelated native engine libraries')
    require(report['dependency_directory'] == str(rlib_path.parent), 'dependency search path differs')
    for name, value in report['input_metadata'].items():
        require(name in ('Cargo.lock', 'Cargo.toml', 'crates/scriptw-intl/Cargo.toml')
                and digest(REPO / name) == value, 'diagnostic source input metadata differs')
    require(set(report['input_metadata']) == {'Cargo.lock', 'Cargo.toml', 'crates/scriptw-intl/Cargo.toml'},
            'diagnostic source input metadata omitted an input')
    binary = report['binary']
    executable = directory / 'intl_allocation_diagnostic'
    require(binary['path'] == str(executable) and executable.is_file()
            and executable.stat().st_size == binary['bytes'] and digest(executable) == binary['sha256'],
            'executed standalone diagnostic bytes changed')
    commands = report['commands']
    require([row['label'] for row in commands] == ['rustc-version', 'compile', 'allocation'],
            'diagnostic compile/run command sequence changed')
    rustc = report['rustc']
    expected = [
        [rustc['invoker_path'], '-vV'],
        [rustc['invoker_path'], '--edition=2021', '--crate-name=scriptw_intl_allocation_diagnostic',
         '--crate-type=bin', '-Copt-level=3', '-Cdebuginfo=0', '-Ccodegen-units=1',
         '-Ldependency=' + str(rlib_path.parent), '--extern', 'scriptw_intl=' + str(rlib_path),
         str(source_path), '-o', str(executable)],
        [str(executable)],
    ]
    require(Path(rustc['invoker_path']).resolve() == Path(rustc['resolved_invoker_path'])
            and digest(rustc['invoker_path']) == rustc['invoker_sha256'], 'recorded compiler invoker changed')
    prior_end = stamp(report['started_at'])
    for command, argv in zip(commands, expected):
        require(command['command'] == argv and command['state'] == 'closed' and command['exit_code'] == 0
                and command['timed_out'] is False and Path(command['cwd']).resolve() == REPO,
                'diagnostic command failed, changed or timed out')
        start, end = stamp(command['started_at']), stamp(command['finished_at'])
        require(prior_end <= start <= end, 'diagnostic command timestamps overlap or reverse')
        prior_end = end
        for stream in ('stdout', 'stderr'):
            transcript = owned(directory, command[stream + '_file'])
            require(digest(transcript) == command[stream + '_sha256'], 'diagnostic transcript hash differs')
            evidence.add(transcript)
    require((directory / commands[0]['stdout_file']).read_text() == rustc['verbose_version'],
            'actual rustc version transcript differs')
    actual = read(directory / commands[2]['stdout_file'])
    require(actual == report['observation'], 'executed allocation observation differs from report')
    require(actual['schema'] == 'scriptw-intl-requested-allocation-diagnostic-v1'
            and actual['component_count'] == len(actual['components']) == len(COMPONENTS)
            and {row['section'] for row in actual['components']} == COMPONENTS,
            'diagnostic omitted/repeated a public Minimal Intl component')
    for row in actual['components']:
        require(finite_u64(row['bytes'], row['section']) > 0, 'empty Intl frame')
    frame_bytes = sum(row['bytes'] for row in actual['components'])
    require(frame_bytes == finite_u64(actual['serialized_frame_bytes'], 'serialized_frame_bytes')
            and finite_u64(actual['identity_wire_bytes'], 'identity_wire_bytes') > 0,
            'serialized Intl frame or identity byte total differs')
    snapshots = actual['snapshots']
    require([row['phase'] for row in snapshots] == list(PHASES), 'allocation snapshots are missing or reordered')
    prior = None
    for row in snapshots:
        require(set(row) == {'phase', *COUNTERS}, 'allocation snapshot fields changed')
        for name in COUNTERS:
            finite_u64(row[name], name)
        require(row['total_successful_request_bytes'] >= row['total_released_request_bytes']
                and row['total_successful_request_bytes'] - row['total_released_request_bytes'] == row['requested_live_bytes']
                and row['requested_live_bytes'] <= row['peak_tracked_requested_live_bytes'] <= row['total_successful_request_bytes'],
                'requested/released/live/peak byte accounting does not reconcile')
        if prior is not None:
            require(all(row[name] >= prior[name] for name in COUNTERS if name != 'requested_live_bytes'),
                    'cumulative byte/call accounting moved backwards')
        prior = row
    require({key: value for key, value in snapshots[2].items() if key != 'phase'}
            == {key: value for key, value in snapshots[3].items() if key != 'phase'}
            and snapshots[3]['requested_live_bytes'] > snapshots[0]['requested_live_bytes'],
            'dropping local selection/frame leases did not preserve the recorded retained-global allocation state')
    end = stamp(receipt['date'])
    start = end - timedelta(seconds=receipt['seconds'])
    require(start <= stamp(report['started_at']) <= prior_end <= stamp(report['finished_at']) <= end,
            'standalone diagnostic chronology escapes its outer receipt')
    printed = json.loads(outer_log.strip())
    require(printed == dict(complete=True, executed=True, report=str(path),
                           rlib_sha256=rlib['sha256'], binary_sha256=binary['sha256']),
            'outer diagnostic result identities differ')
    for extra in [path, source_path, driver_path]:
        evidence.add(extra)
    return {
        'complete': True, 'schema': 'scriptw-intl-requested-allocation-attribution-v1',
        'scope': 'Standalone public Minimal Intl services and identity resolution: successful Rust GlobalAlloc requests through System. Excludes Engine/Wasmtime/JavaScript execution, RSS, allocator usable/resident bytes, OS allocations and native allocations bypassing GlobalAlloc.',
        'interpretation': 'This identifies persistent requested Rust allocations, not ownership of an execution-process anonymous mapping. No claim that an entire 64-MiB range, or any particular smaps VMA, belongs to Intl.',
        'outer_receipt': 'intl-allocation-diagnostic.json', 'raw_report': report,
        'baseline_requested_live_bytes': snapshots[0]['requested_live_bytes'],
        'after_resolution_requested_live_bytes': snapshots[2]['requested_live_bytes'],
        'after_drop_requested_live_bytes': snapshots[3]['requested_live_bytes'],
        'retained_requested_byte_increase': snapshots[3]['requested_live_bytes'] - snapshots[0]['requested_live_bytes'],
        'logical_requested_live_peak_bytes': max(row['peak_tracked_requested_live_bytes'] for row in snapshots),
        'serialized_frame_bytes': frame_bytes, 'component_count': len(actual['components']),
        'local_drop_preserves_observed_global_state': True,
        'archive_exclusions': 'Diagnostic executable and input rlib are excluded. Actual bytes are checked at publication and their SHA-256/length/producers/commands remain recorded.',
    }
