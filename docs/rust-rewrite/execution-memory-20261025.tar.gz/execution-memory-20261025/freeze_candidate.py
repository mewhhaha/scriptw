import datetime,hashlib,json,pathlib,subprocess,sys
root=pathlib.Path(__file__).resolve().parent
source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
def sha(path):
 with pathlib.Path(path).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
rows=[json.loads(line) for line in (root/'cargo-product.jsonl').read_text().splitlines()]
assert rows[-1].get('reason')=='build-finished' and rows[-1].get('success') is True
names={'scriptw','runtime_baseline','runtime_boundaries'}
products={pathlib.Path(x['executable']).name:x for x in rows if x.get('reason')=='compiler-artifact' and x.get('executable') and pathlib.Path(x['executable']).name in names}
assert set(products)==names
out=root/'candidate';out.mkdir(exist_ok=False)
manifest={'source_commit':source,'frozen_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'products':{}}
for name,row in products.items():
 assert row['profile']['opt_level']=='3' and row['profile']['test'] is False and row['features']==[]
 original=pathlib.Path(row['executable']);target=out/name
 subprocess.run(['cp','--reflink=auto',str(original),str(target)],check=True)
 assert sha(target)==sha(original)
 manifest['products'][name]={'path':str(target),'actual_cargo_product':str(original),'sha256':sha(target),'bytes':target.stat().st_size,'cargo_producer':row}
identity=json.loads(subprocess.check_output([str(out/'scriptw'),'compiler-identity']))
assert identity['source_revision']=={'kind':'git-commit','commit':source}
assert identity['executable_sha256']==manifest['products']['scriptw']['sha256']
(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\n')
(root/'frozen-products.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('FROZEN ACTUAL DEFAULT RELEASE PRODUCTS',source,flush=True)
