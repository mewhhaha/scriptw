import json,pathlib,subprocess,sys
root=pathlib.Path(__file__).resolve().parent
for name,command in json.loads((root/'focus-plan.json').read_text()):
 code=subprocess.call([sys.executable,'-B',str(root/'run_check.py'),'focused-'+name,*command,'--','--test-threads=1','--include-ignored'])
 if code:sys.exit(code)
 row=json.loads((root/('focused-'+name+'.json')).read_text());counts=row['test_results']
 if not counts or sum(int(x[1]) for x in counts)==0 or any(x[0]!='ok' or x[2]!='0' or x[3]!='0' for x in counts):raise RuntimeError('focused checks were empty or failed')
