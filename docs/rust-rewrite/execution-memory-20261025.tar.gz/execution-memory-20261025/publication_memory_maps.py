"""Read-only admission of acknowledged live-process memory-map diagnostics."""
from datetime import datetime, timedelta
import hashlib
import json
from pathlib import Path
import re
import statistics
import subprocess
import sys

BASE = Path(__file__).resolve().parent
REPO = BASE.parent.parent
sys.path.insert(0, str(REPO / 'scripts'))
import profile_memory_maps as probe
from process_memory_maps import parse_smaps

ROUNDS = ('baseline-maps-round-a', 'candidate-maps-round-b',
          'candidate-maps-round-c', 'baseline-maps-round-d')
CASES = ('startup.js', 'integer.js', 'retained-objects.js')
PHASES = ('guest-start', 'guest-body-finished')


def require(condition, message):
    if not condition:
        raise ValueError('memory maps: ' + message)


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def read(path):
    path = Path(path)
    require(path.is_file() and not path.is_symlink(), 'missing or symlinked input: ' + str(path))
    return json.loads(path.read_text())


def stamp(value):
    result = datetime.fromisoformat(value.replace('Z', '+00:00'))
    require(result.utcoffset() is not None, 'timestamp lacks timezone')
    return result


def owned(directory, name):
    require(isinstance(name, str) and Path(name).name == name and name not in ('', '.', '..'),
            'unowned evidence path')
    path = directory / name
    require(path.is_file() and not path.is_symlink(), 'missing or symlinked evidence file')
    return path


def round_data(evidence, directory, product, products):
    path = directory / 'report.json'
    report = read(path)
    identity = products[product]['compiler_identity']
    runner = BASE / product / 'runtime_baseline'
    require(report.get('schema') == 'scriptw-process-memory-maps-v1' and report.get('complete') is True,
            'incomplete mapping diagnostic')
    require(report.get('samples') == 3 and report.get('warmups') == 1
            and report.get('cpu_affinity') == [0], 'mapping sample/warmup/CPU plan changed')
    require(Path(report['runner']).resolve() == runner.resolve()
            and report['runner_sha256'] == products[product]['runtime_runner_sha256'] == digest(runner),
            'mapping runner/source product differs')
    require([row['file'] for row in report['cases']] == list(CASES)
            and [row['file'] for row in report['sources']] == list(CASES), 'three complete mapping controls changed')
    fixtures = REPO / 'crates/scriptw-cli/tests/fixtures/v8_execution_hotpaths'
    plan = read(fixtures / 'manifest.json')
    expected_cases = {row['file']: row for row in [plan['startup'], *plan['execution']]}
    generated = []
    for source, case in zip(report['sources'], report['cases']):
        name = case['file']
        original = fixtures / name
        source_path = directory / 'fixtures' / name
        text, expected = probe.prepare_case(original.read_text(), expected_cases[name]['stdout'])
        require(Path(source['original_path']).resolve() == original.resolve()
                and source['original_sha256'] == digest(original)
                and source['source_sha256'] == digest(source_path)
                and source_path.read_text() == text, 'original/transformed mapping fixture changed')
        generated.append({'file': name, 'stdout': expected})
        case_dir = directory / name
        stdout_path, stderr_path = case_dir / 'stdout.json', case_dir / 'stderr.log'
        raw = read(stdout_path)
        require(digest(stdout_path) == case['stdout_sha256'] and digest(stderr_path) == case['stderr_sha256'],
                'mapping child transcripts changed')
        require(case['exit_code'] == 0 and case['compiler_source'] == raw['source_commit']
                == identity['source_revision']['commit']
                and case['source_fingerprint'] == raw['source_fingerprint'] == identity['source_fingerprint']
                and case['runner_sha256'] == raw['executable_sha256'] == report['runner_sha256'],
                'mapping child did not execute the admitted compiler/runner')
        require(raw['schema'] == 'scriptw-wasmtime-row-phases-v1' and raw['requested_native_policy'] is None
                and raw['samples'] == 3 and raw['warmups'] == 1 and len(raw['cases']) == 1,
                'mapping child used another policy/cohort')
        actual = raw['cases'][0]
        require(actual['file'] == name and actual['source_sha256'] == source['source_sha256']
                and actual['source_compilation_profile'] == 'portable', 'mapping source/profile differs')
        outputs = actual['observations']
        require(len(outputs) == 4 and [row['warmup'] for row in outputs] == [True, False, False, False]
                and all(row['stdout'] == expected for row in outputs), 'mapping workload outputs/observations differ')
        program = case_dir / 'artifacts' / (name + '.wasm')
        require(program.stat().st_size == actual['wasm_bytes'] and digest(program) == actual['wasm_sha256'],
                'mapping P bytes differ from the executed artifact')
        linked = actual['linked_runtime']
        require(isinstance(linked, dict) and linked['wasm_bytes'] > 0, 'mapping lacks linked runtime identity')
        native_lengths = [int(value) for value in re.findall(
            r'runtime-native-bundle hit: (\d+) bytes \(runtime: size-optimized, execution: fast, source: Portable\)',
            stderr_path.read_text())]
        require(native_lengths and all(value > 0 for value in native_lengths),
                'actual ordinary Portable native image admission not recorded')
        require(case['command'] == [str(runner.resolve()), str((directory / 'fixtures').resolve()),
                '3', '1', name, str((case_dir / 'artifacts').resolve()), '--row-phases'],
                'mapping child invocation changed')
        snapshots = case['observations']
        require([(row['sample'], row['phase']) for row in snapshots]
                == [(i, phase) for i in range(3) for phase in PHASES], 'mapping boundary ordering changed')
        pid = snapshots[0]['pid']
        require(type(pid) is int and pid > 0 and all(row['pid'] == pid for row in snapshots),
                'mapping boundaries came from different child processes')
        for row in snapshots:
            index, phase = row['sample'], row['phase']
            require(row['raw'] == f'{index:02}-{phase}.smaps', 'mapping raw snapshot label differs')
            raw_path = owned(case_dir, row['raw'])
            require(digest(raw_path) == row['raw_sha256'], 'raw smaps changed')
            parsed = parse_smaps(raw_path.read_text())
            require(all(row.get(key) == value for key, value in parsed.items()),
                    'reported mappings/counters differ from actual saved smaps')
            identity_path = owned(case_dir, f'{index:02}-{phase}.native-identity')
            native_identity = identity_path.read_text()
            require(native_identity.startswith(f'scriptw-perf-map-v1 pid={pid} boundary=serial-single-program-snapshot\n'),
                    'native identity belongs to another process/boundary')
            native_map = owned(case_dir, row['native_map'])
            native_sha = digest(native_map)
            require(row['native_map'] == 'native-map-' + native_sha + '.map'
                    and native_sha == row['native_map_sha256']
                    and native_identity.endswith('map_sha256=' + native_sha + '\n'),
                    'native-text map identity changed')
            ranges = probe.native_ranges(native_identity)
            require(ranges == row['native_ranges'], 'native-text ranges changed')
            require({r['module']: r['wasm_sha256'] for r in ranges}
                    == {'P': actual['wasm_sha256'], 'R': linked['wasm_sha256']}, 'native map R/P hashes differ')
            overlapping = [dict(module=region['module'], text_start=region['start'], text_end=region['end'],
                                mappings=[m for m in parsed['mappings']
                                          if m['start'] < region['end'] and m['end'] > region['start']])
                           for region in ranges]
            require(row['native_text_mappings'] == overlapping
                    and all(item['mappings'] for item in overlapping), 'native-text mapping intersections differ')
            by_module = {r['module']: r for r in ranges}
            functions = []
            for line in native_map.read_text().splitlines():
                match = re.fullmatch(r'([0-9a-f]+) ([0-9a-f]+) scriptw:([RP]):f\d+:\S+', line)
                require(match is not None, 'malformed loaded-function map')
                start, size, module = int(match[1], 16), int(match[2], 16), match[3]
                require(by_module[module]['start'] <= start <= start + size <= by_module[module]['end'],
                        'loaded function lies outside its declared native text')
                functions.append(module)
            require(set(functions) == {'P', 'R'}, 'loaded-function map omits an executed module')
            for extra in [raw_path, identity_path, native_map]:
                evidence.add(extra)
        for extra in [source_path, original, program, stdout_path, stderr_path]:
            evidence.add(extra)
        case['actual_portable_native_image_bytes'] = sorted(set(native_lengths))
        case['actual_runtime_wasm_bytes'] = linked['wasm_bytes']
    require(read(directory / 'fixtures/manifest.json') == {'execution': generated},
            'generated mapping fixture manifest differs')
    evidence.add(path)
    evidence.add(directory / 'fixtures/manifest.json')
    return report


def summarize(rounds):
    rows = []
    for name in CASES:
        for phase in PHASES:
            entry = {'file': name, 'phase': phase, 'products': {}}
            for product in ('baseline', 'candidate'):
                cases = [case for r in rounds if r['product'] == product
                         for case in r['report']['cases'] if case['file'] == name]
                values = [row for case in cases for row in case['observations'] if row['phase'] == phase]
                require(len(values) == 6, 'mapping pooled snapshot count differs')
                counters = {field: [row['totals'][field] for row in values]
                            for field in values[0]['totals']}
                entry['products'][product] = {
                    'samples': 6, 'totals': {field: {'values': samples, 'median': statistics.median(samples)}
                                           for field, samples in counters.items()},
                    'group_rss_bytes': {group: {'values': [row['groups'][group]['rss_bytes'] for row in values],
                                               'median': statistics.median(row['groups'][group]['rss_bytes'] for row in values)}
                                        for group in values[0]['groups']},
                    'native_text_bytes': {module: sorted({region['end'] - region['start']
                                              for row in values for region in row['native_ranges']
                                              if region['module'] == module}) for module in ('R', 'P')},
                    'runtime_wasm_bytes': sorted({case['actual_runtime_wasm_bytes'] for case in cases}),
                    'portable_native_image_bytes': sorted({size for case in cases
                                                          for size in case['actual_portable_native_image_bytes']}),
                }
            before = entry['products']['baseline']['totals']['rss_bytes']['median']
            after = entry['products']['candidate']['totals']['rss_bytes']['median']
            entry['rss_change_bytes'] = after - before
            entry['rss_change_percent'] = 100 * (after / before - 1)
            rows.append(entry)
    return rows


def build_report(evidence, products, source, baseline_source):
    for name in ('scripts/profile_memory_maps.py', 'scripts/process_memory_maps.py'):
        path = REPO / name
        expected = subprocess.check_output(['git', 'show', source + ':' + name], cwd=REPO)
        require(path.read_bytes() == expected, 'mapping reproducer differs from committed source')
        evidence.add(path)
    accepted, prior_end = [], None
    for index, label in enumerate(ROUNDS):
        product = 'baseline' if index in (0, 3) else 'candidate'
        receipt, _ = evidence.receipt(label)
        directory = BASE / (label + '-data')
        command = receipt['command']
        require(len(command) == 7 and command[1] == '-B'
                and Path(command[2]).resolve() == REPO / 'scripts/profile_memory_maps.py'
                and command[3] == '--runner' and Path(command[4]).resolve() == BASE / product / 'runtime_baseline'
                and command[5] == '--output' and Path(command[6]).resolve() == directory,
                'actual mapping invocation differs')
        report = round_data(evidence, directory, product, products)
        start, end = stamp(receipt['date']) - timedelta(seconds=receipt['seconds']), stamp(receipt['date'])
        require(start <= stamp(report['observed_at']) <= end
                and (prior_end is None or prior_end <= start), 'mapping ABBA round chronology differs')
        prior_end = end
        accepted.append({'label': label, 'product': product, 'start': start.isoformat(),
                         'end': end.isoformat(), 'receipt': label + '.json', 'report': report})
    preflight = round_data(evidence, BASE / 'baseline-maps', 'baseline', products)
    preflight_summaries = []
    for case in preflight['cases']:
        for phase in PHASES:
            values = [row for row in case['observations'] if row['phase'] == phase]
            require(len(values) == 3, 'preflight boundary count differs')
            preflight_summaries.append({
                'file': case['file'], 'phase': phase, 'samples': 3,
                'rss_bytes_median': statistics.median(row['totals']['rss_bytes'] for row in values),
                'group_rss_bytes_medians': {group: statistics.median(row['groups'][group]['rss_bytes'] for row in values)
                                            for group in values[0]['groups']},
            })
    return {
        'complete': True, 'schema': 'scriptw-acknowledged-process-memory-comparison-v1',
        'round_order': list(ROUNDS), 'cases_per_round': 3, 'boundaries': list(PHASES),
        'samples_per_case_boundary_per_round': 3, 'samples_per_product_case_boundary': 6,
        'accepted_snapshot_count': sum(len(case['observations']) for row in accepted for case in row['report']['cases']),
        'baseline_source': baseline_source, 'candidate_source': source,
        'boundary': 'Synchronous guest-start/body-finished callbacks after bootstrap; paused real Wasm child smaps.',
        'interpretation': 'Instrumented residency attribution, not accepted ordinary performance timings or live JS allocation bytes. Mapping groups follow kernel labels/perms. Native-text intersections retain whole mappings; no proportional RSS attribution.',
        'rounds': accepted, 'summaries': summarize(accepted),
        'excluded_unreceipted_preflight': {
            'report': preflight, 'summaries': preflight_summaries, 'accepted_snapshot_count': 0,
            'observed_snapshot_count': sum(len(case['observations']) for case in preflight['cases']),
            'limitation': 'Initial baseline diagnostic retains actual frozen ab97 runner identity, checksums, CPU self-report and smaps. No outer resource receipt was saved; no kernel memory/swap/OOM claim is retroactively made and it contributes no accepted mapping samples.',
        },
    }
