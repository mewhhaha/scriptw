//! Standalone allocation attribution: public Minimal Intl selection only.
//! No Engine, Wasmtime, JavaScript heap, compiler or timing benchmark is used.
use scriptw_intl::{IntlCompilationProfile, IntlDataSelection};
use std::alloc::{GlobalAlloc, Layout, System};
use std::sync::atomic::{AtomicUsize, Ordering::Relaxed};

struct CountingSystem;

static LIVE: AtomicUsize = AtomicUsize::new(0);
static PEAK: AtomicUsize = AtomicUsize::new(0);
static REQUESTED: AtomicUsize = AtomicUsize::new(0);
static RELEASED: AtomicUsize = AtomicUsize::new(0);
static ALLOC_CALLS: AtomicUsize = AtomicUsize::new(0);
static ZEROED_CALLS: AtomicUsize = AtomicUsize::new(0);
static REALLOC_CALLS: AtomicUsize = AtomicUsize::new(0);
static DEALLOC_CALLS: AtomicUsize = AtomicUsize::new(0);

fn peak(live: usize) {
    let mut observed = PEAK.load(Relaxed);
    while live > observed {
        match PEAK.compare_exchange_weak(observed, live, Relaxed, Relaxed) {
            Ok(_) => break,
            Err(actual) => observed = actual,
        }
    }
}

fn allocated(bytes: usize) {
    REQUESTED.fetch_add(bytes, Relaxed);
    peak(LIVE.fetch_add(bytes, Relaxed) + bytes);
}

// These hooks perform only System allocator calls and atomic arithmetic. They
// do not format, lock, allocate bookkeeping, call user code or enter Intl.
unsafe impl GlobalAlloc for CountingSystem {
    unsafe fn alloc(&self, layout: Layout) -> *mut u8 {
        let result = unsafe { System.alloc(layout) };
        if !result.is_null() {
            ALLOC_CALLS.fetch_add(1, Relaxed);
            allocated(layout.size());
        }
        result
    }

    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let result = unsafe { System.alloc_zeroed(layout) };
        if !result.is_null() {
            ZEROED_CALLS.fetch_add(1, Relaxed);
            allocated(layout.size());
        }
        result
    }

    unsafe fn realloc(&self, ptr: *mut u8, old: Layout, new_size: usize) -> *mut u8 {
        let result = unsafe { System.realloc(ptr, old, new_size) };
        if !result.is_null() {
            REALLOC_CALLS.fetch_add(1, Relaxed);
            REQUESTED.fetch_add(new_size, Relaxed);
            RELEASED.fetch_add(old.size(), Relaxed);
            if new_size >= old.size() {
                peak(LIVE.fetch_add(new_size - old.size(), Relaxed) + new_size - old.size());
            } else {
                LIVE.fetch_sub(old.size() - new_size, Relaxed);
            }
        }
        result
    }

    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout) {
        unsafe { System.dealloc(ptr, layout) };
        DEALLOC_CALLS.fetch_add(1, Relaxed);
        RELEASED.fetch_add(layout.size(), Relaxed);
        LIVE.fetch_sub(layout.size(), Relaxed);
    }
}

#[global_allocator]
static ALLOCATOR: CountingSystem = CountingSystem;

#[derive(Clone, Copy, Default)]
struct Snapshot {
    live: usize,
    peak: usize,
    requested: usize,
    released: usize,
    alloc_calls: usize,
    zeroed_calls: usize,
    realloc_calls: usize,
    dealloc_calls: usize,
}

impl Snapshot {
    fn capture() -> Self {
        Self {
            live: LIVE.load(Relaxed),
            peak: PEAK.load(Relaxed),
            requested: REQUESTED.load(Relaxed),
            released: RELEASED.load(Relaxed),
            alloc_calls: ALLOC_CALLS.load(Relaxed),
            zeroed_calls: ZEROED_CALLS.load(Relaxed),
            realloc_calls: REALLOC_CALLS.load(Relaxed),
            dealloc_calls: DEALLOC_CALLS.load(Relaxed),
        }
    }

    fn print(self, label: &str) {
        print!(
            "{{\"phase\":\"{}\",\"requested_live_bytes\":{},\"peak_tracked_requested_live_bytes\":{},\
             \"total_successful_request_bytes\":{},\"total_released_request_bytes\":{},\
             \"alloc_calls\":{},\"alloc_zeroed_calls\":{},\"realloc_calls\":{},\"dealloc_calls\":{}}}",
            label, self.live, self.peak, self.requested, self.released,
            self.alloc_calls, self.zeroed_calls, self.realloc_calls, self.dealloc_calls,
        );
    }
}

fn main() {
    // Fixed arrays and scalar metadata keep the diagnostic's own recording out
    // of the measured allocations. Printing begins after all snapshots exist.
    let mut snapshots = [Snapshot::default(); 4];
    let mut components = [("", 0usize); 12];
    snapshots[0] = Snapshot::capture();
    let identity_length;
    {
        let selection = IntlDataSelection::new(IntlCompilationProfile::Minimal);
        snapshots[1] = Snapshot::capture();
        let selected = selection
            .selected()
            .expect("current Minimal Intl selection admits");
        let identity = selected.identity().artifact_identity();
        std::hint::black_box(identity.as_bytes());
        identity_length = identity.as_bytes().len();
        drop(identity);
        let frames = selected.component_sections();
        assert_eq!(frames.len(), components.len());
        for (slot, (name, bytes)) in components.iter_mut().zip(frames) {
            *slot = (name, bytes.len());
        }
        std::hint::black_box(selected.identity());
        snapshots[2] = Snapshot::capture();
    }
    snapshots[3] = Snapshot::capture();
    let frame_bytes: usize = components.iter().map(|(_, bytes)| bytes).sum();

    print!("{{\"schema\":\"scriptw-intl-requested-allocation-diagnostic-v1\",\
            \"scope\":\"Standalone public Minimal Intl selection; no Engine, Wasmtime or JavaScript execution\",\
            \"counter_scope\":\"Successful Rust GlobalAlloc requests through System; not allocator resident/usable bytes, OS allocations, RSS or JavaScript heap\",\
            \"realloc_policy\":\"Total requests include full successful new sizes; releases include old sizes; tracked live bytes change by the size delta\",\
            \"peak_scope\":\"Cumulative logical requested-live high-water; excludes allocator-internal realloc overlap and native allocations bypassing GlobalAlloc\",\
            \"owner_scope\":\"Minimal component/provider OnceLocks persist after local selection and frame Arc leases drop\",\
            \"identity_wire_bytes\":{},\"serialized_frame_bytes\":{},\"component_count\":12,\"components\":[",
           identity_length, frame_bytes);
    for (index, (name, bytes)) in components.iter().enumerate() {
        if index != 0 {
            print!(",");
        }
        print!("{{\"section\":\"{}\",\"bytes\":{}}}", name, bytes);
    }
    print!("],\"snapshots\":[");
    for (index, label) in [
        "before_selection_constructor",
        "after_selection_constructor",
        "after_all_services_and_identity_resolution",
        "after_dropping_local_selection_and_frame_leases",
    ]
    .into_iter()
    .enumerate()
    {
        if index != 0 {
            print!(",");
        }
        snapshots[index].print(label);
    }
    println!("]}}");
}
