import importlib.util,pathlib,subprocess,sys
root=pathlib.Path(__file__).resolve().parent
native=__import__('json').loads((root/'native-closed.json').read_text())
if native.get('complete') is not True:raise RuntimeError('native scopes incomplete')
command=[sys.executable,'-B','scripts/replay-test262-executions.py',str(root/'selected.ids'),'--binary',str((root/'candidate/scriptw').resolve()),'--suite-root','test262/vendor/test262','--output-dir',str(root/'conformance'),'--workers','1','--reuse-case-workers']
code=subprocess.call([sys.executable,'-B',str(root/'run_check.py'),'conformance-final',*command])
if code!=1:raise RuntimeError('expected actual four-known-failure exit1, got '+str(code))
spec=importlib.util.spec_from_file_location('memory_publication',root/'publish_evidence.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
result=module.conformance(module.Evidence())
print('Selected conformance reconciled',result['passed'],'/',result['total'],'known failures',result['bug'],flush=True)
code=subprocess.call([sys.executable,'-B',str(root/'measure_all.py')])
if code:sys.exit(code)
print('ALL FINAL COMPARISON COHORTS CLOSED',flush=True)
