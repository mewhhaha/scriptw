#!/usr/bin/env python3
"""Validate closed native, selected Test262 and balanced runtime evidence.

Default mode reads only. --publish writes one new documentation checkpoint.
No product, test or compiler executable is invoked by this tool.
"""
from __future__ import annotations

import argparse
import gzip
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import re
import subprocess
import sys
sys.dont_write_bytecode = True
import tarfile
import types

BASE = Path(__file__).resolve().parent
REPO = BASE.parent.parent
SOURCE = "9b7746531c4b3bff0ecbb863d7d70dfead12455b"
BASELINE_SOURCE = "ab97459e54f9e0cd3ed983d098c46ccacac8fec6"
BASELINE_PATCH = hashlib.sha256(b"").hexdigest()
EMPTY_PATCH = hashlib.sha256(b"").hexdigest()
STEM = "execution-memory-20261025"
PREFIX = STEM + "/"
BUDGET = 4 * 1024**3
SUMMARY_RE = re.compile(r"test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out")
KNOWN = {
    "sloppy-script:annexB/language/function-code/block-decl-func-skip-arguments.js",
    "sloppy-script:intl402/Temporal/ZonedDateTime/links.js",
    "strict-script:intl402/Temporal/ZonedDateTime/links.js",
    "sloppy-script:staging/sm/lexical-environment/block-scoped-functions-annex-b-label.js",
}
ROUNDS = ["baseline-round-a-data", "candidate-round-b-data", "candidate-round-c-data", "baseline-round-d-data"]
CALL_ROUNDS = ["baseline-calls-round-a-data", "candidate-calls-round-b-data", "candidate-calls-round-c-data", "baseline-calls-round-d-data"]
EXPECTED_SCOPES = [
    ("scriptw-aot-wasm", "--lib", None),
    *[("scriptw-aot-wasm", "--test", name) for name in ["emission", "modules_realms", "runtime_link", "structure_async", "structure_builtins", "structure_language"]],
    ("scriptw-engine", "--lib", None),
    *[("scriptw-engine", "--test", name) for name in ["aot_async", "aot_async_generator_returns", "aot_builtins", "aot_gc_entries", "aot_generators", "aot_language", "aot_native_program_templates", "aot_realm_modules", "runtime_cache", "structure", "weak_gc_facility"]],
    ("scriptw-runtime-image", "--lib", None), ("scriptw-ir", "--lib", None),
    ("scriptw-cli", "--example", "runtime_baseline"), ("scriptw-cli", "--example", "runtime_boundaries"),
]


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def read_json(path):
    path = Path(path)
    require(path.is_file() and not path.is_symlink(), f"missing or symlinked evidence: {path}")
    return json.loads(path.read_text())


def member_path(path):
    path = Path(path)
    require(path.is_file() and not path.is_symlink(), f"missing or symlinked archive input: {path}")
    resolved = path.resolve()
    require(resolved.is_relative_to(REPO), f"archive input escaped repository: {path}")
    require(path.stat().st_size < 64 * 1024**2, f"oversized evidence input: {path}")
    require(path.suffix not in {".swbundle", ".v8cache"}, f"session bundle/cache payload excluded: {path}")
    with path.open("rb") as stream:
        require(stream.read(4) != b"\x7fELF", f"binaries excluded from evidence archive: {path}")
    relative = resolved.relative_to(BASE) if resolved.is_relative_to(BASE) else Path("reproduction") / resolved.relative_to(REPO)
    require(not any(part in {"cache", "execution-cache", "native-cache", "tmp", "__pycache__", ".git"} for part in relative.parts), f"temporary/cache input excluded: {path}")
    return PREFIX + relative.as_posix()


class Evidence:
    def __init__(self, base=BASE):
        self.base = Path(base)
        self.paths = {}
        self.resources = []

    def add(self, path):
        path = Path(path)
        name = member_path(path)
        require(name not in self.paths or self.paths[name].resolve() == path.resolve(), f"conflicting archive name: {name}")
        self.paths[name] = path
        return name

    def resource(self, row, label):
        require(row.get("cpu_affinity") == [0], f"{label}: expected observed one-CPU affinity")
        require(str(row.get("memory.max")) == str(BUDGET) and str(row.get("memory.swap.max")) == "0", f"{label}: missing exact 4-GiB/no-swap cap")
        require(str(row.get("memory.oom.group")) == "1", f"{label}: missing grouped OOM policy")
        events = dict(line.split() for line in row.get("memory.events", "").splitlines())
        require(all(events.get(name) == "0" for name in ["oom", "oom_kill", "oom_group_kill"]), f"{label}: accepted receipt records OOM or missing observations")
        peak = int(row.get("memory.peak", -1))
        require(0 <= peak <= BUDGET, f"{label}: invalid cumulative cgroup peak")
        env = row.get("resource_environment", {})
        for name in ["CARGO_BUILD_JOBS", "SCRIPTW_JOBS", "RUST_TEST_THREADS", "RAYON_NUM_THREADS", "SCRIPTW_MODULE_MEMORY_CACHE_ENTRIES"]:
            require(env.get(name) == "1", f"{label}: nonserial or unbounded retained-cache environment")
        require(env.get("SCRIPTW_MODULE_MEMORY_CACHE_LIMIT_BYTES") == str(64 * 1024**2), f"{label}: cache image limit differs")
        self.resources.append({"label": label, "memory_peak_bytes": peak, "memory_events": events, "cpu_affinity": row["cpu_affinity"]})

    def receipt(self, label, *, exit_code=0, checkout_source=SOURCE, clean_source=True):
        require(re.fullmatch(r"[A-Za-z0-9_-]+", label) is not None, "invalid receipt label")
        path = self.base / (label + ".json")
        row = read_json(path)
        require(row.get("label") == label and row.get("exit_code") == exit_code, f"{label}: actual receipt label/exit disagrees")
        require(row.get("source_head") == checkout_source, f"{label}: receipt checkout source differs")
        if clean_source:
            require(row.get("source_patch_sha256") == EMPTY_PATCH, f"{label}: product source was dirty")
        else:
            require(re.fullmatch(r"[0-9a-f]{64}", row.get("source_patch_sha256", "")) is not None, f"{label}: missing checkout patch observation")
        require(isinstance(row.get("command"), list) and row["command"], f"{label}: missing actual command")
        require(row.get("log") == label + ".log", f"{label}: log path differs")
        log = self.base / row["log"]
        require(digest(log) == row.get("log_sha256"), f"{label}: log hash differs")
        self.resource(row, label)
        self.add(path)
        self.add(log)
        return row, log.read_text(errors="replace")


def current_source():
    actual = subprocess.check_output(["git", "rev-parse", SOURCE + "^{commit}"], cwd=REPO, text=True).strip()
    require(actual == SOURCE, "candidate product source is unavailable")
    difference = subprocess.check_output(["git", "diff", "--binary", SOURCE, "--", "crates", "Cargo.toml", "Cargo.lock"], cwd=REPO)
    require(difference == b"", "product inputs differ from the measured source commit")
    require(subprocess.check_output(["git", "ls-files", "--others", "--exclude-standard", "--", "crates", "Cargo.toml", "Cargo.lock"], cwd=REPO) == b"", "untracked product files are outside measured authority")


def inventory_names(log):
    names = sorted(re.findall(r"^([^\s]+): test$", log, re.M))
    require(names and len(set(names)) == len(names), "native inventory is empty or repeated")
    return names


def observed_names(log):
    return [(name.removesuffix(" - should panic"), status) for name, status in re.findall(r"^test (.+) \.\.\. (ok|FAILED|ignored)$", log, re.M)]


def closed_native_log(row, log, inventory, *, filtered=0):
    observed = observed_names(log)
    require(sorted(name for name, _ in observed) == sorted(inventory) and all(status == "ok" for _, status in observed), f'{row["label"]}: native transcript lost, repeated, failed or ignored an identity')
    expected = [("ok", str(len(inventory)), "0", "0", "0", str(filtered))]
    require(SUMMARY_RE.findall(log) == expected and row.get("test_results") == [list(expected[0])], f'{row["label"]}: terminal counts do not reconcile to exact inventory')


def engine_native(evidence, scope, recorded):
    path = BASE / "engine-accepted.json"
    aggregate = read_json(path)
    manifest_path = BASE / "engine-batches.json"
    manifest = read_json(manifest_path)
    require(aggregate == recorded and aggregate.get("source_head") == SOURCE and aggregate.get("source_patch_sha256") == EMPTY_PATCH, "engine aggregate source differs")
    require(aggregate.get("complete") is True and aggregate.get("exit_code") == 0 and manifest.get("complete") is True and manifest.get("source_head") == SOURCE, "engine aggregate or exact batch manifest is incomplete")
    require("log" not in aggregate and "test_results" not in aggregate and "no synthetic single-process transcript" in aggregate.get("aggregation", ""), "engine observations must remain an explicit aggregate")
    inventory = manifest.get("inventory", [])
    require(inventory and sorted(set(inventory)) == inventory and aggregate.get("inventory") == inventory and aggregate.get("passed") == len(inventory), "engine denominator differs")
    enumerated, enumeration_log = evidence.receipt("engine-batches-inventory")
    require(enumerated["command"] == [manifest["binary"], "--list", "--include-ignored"] or Path(enumerated["command"][0]).resolve() == Path(manifest["binary"]).resolve() and enumerated["command"][1:] == ["--list", "--include-ignored"], "engine inventory invocation differs")
    require(inventory_names(enumeration_log) == inventory, "engine inventory does not match actual native enumeration")
    require(len(enumerated.get("executables", [])) == 1, "engine executable identity is missing")
    binary = enumerated["executables"]
    seen = []
    labels = []
    for index, batch in enumerate(manifest.get("batches", [])):
        label = f"engine-batch-{index:03d}"
        require(batch.get("label") == label and set(batch) == {"label", "inventory"}, "engine batch metadata differs")
        names = batch["inventory"]
        require(isinstance(names, list) and 1 <= len(names) <= 32 and len(set(names)) == len(names) and set(names).issubset(inventory), f"{label}: invalid bounded inventory")
        if any(name.startswith("runtime_profile::") or "capacity" in name or "inlining" in name for name in names):
            require(len(names) == 1, f"{label}: capacity/inlining/profile case was not isolated")
        row, log = evidence.receipt(label)
        require(Path(row["command"][0]).resolve() == Path(manifest["binary"]).resolve() and row["command"][1:] == names + ["--exact", "--test-threads=1", "--include-ignored"], f"{label}: exact-name invocation differs")
        require(row.get("executables") == binary, f"{label}: executed engine binary differs from complete enumeration")
        closed_native_log(row, log, names, filtered=len(inventory) - len(names))
        seen.extend(names)
        labels.append(label + ".json")
    require(sorted(seen) == inventory and len(set(seen)) == len(seen), "engine batch union omits or repeats native identities")
    require(aggregate.get("batch_manifest") == manifest_path.name, "engine aggregate names another manifest")
    require(len(labels) == 56, "complete engine batch partition differs")
    evidence.receipt("engine-batches-build")
    for extra in [path, manifest_path]:
        evidence.add(extra)
    return {**scope, "passed": len(inventory), "inventory_sha256": hashlib.sha256(("\n".join(inventory) + "\n").encode()).hexdigest(), "verification": "exact disjoint bounded native process observations", "aggregate_receipt": path.name, "manifest": manifest_path.name, "batch_count": len(labels), "receipts": labels, "executables": binary}


def native(evidence):
    scopes = read_json(BASE / "native-scopes.json")
    closed = read_json(BASE / "native-closed.json")
    require([(s["package"], s["kind"], s["name"]) for s in scopes] == EXPECTED_SCOPES, "complete affected 23-target inventory changed")
    require(closed.get("source") == SOURCE and closed.get("complete") is True and len(closed.get("targets", [])) == len(scopes), "native target manifest is incomplete or stale")
    total, qualified, targets = 0, [], []
    for index, (scope, recorded) in enumerate(zip(scopes, closed["targets"])):
        if scope["package"] == "scriptw-engine" and scope["kind"] == "--lib":
            result = engine_native(evidence, scope, recorded)
            names = recorded["inventory"]
        else:
            label = f'broad-{index:02d}-{scope["package"]}-{scope["name"] or "lib"}'
            row, log = evidence.receipt(label)
            enumerated, enumeration_log = evidence.receipt(label + "-inventory")
            command = ["cargo", "test", "--locked", "--release", "--jobs", "1", "-p", scope["package"], scope["kind"]]
            if scope["name"] is not None:
                command.append(scope["name"])
            require(row["command"] == command + ["--", "--test-threads=1", "--include-ignored"] and enumerated["command"] == command + ["--", "--list", "--include-ignored"], f"{label}: broad/inventory commands contain filters or changed policy")
            names = inventory_names(enumeration_log)
            closed_native_log(row, log, names)
            require(row.get("executables") and row["executables"] == enumerated.get("executables"), f"{label}: enumerated and executed native binaries differ")
            inventory_sha = hashlib.sha256(("\n".join(names) + "\n").encode()).hexdigest()
            require(recorded == dict(row, **scope, inventory=names, inventory_sha256=inventory_sha), f"{label}: closed manifest differs from actual native evidence")
            result = {**scope, "passed": len(names), "inventory_sha256": inventory_sha, "run_receipt": label + ".json", "inventory_receipt": label + "-inventory.json", "executables": row["executables"]}
        total += len(names)
        qualified.extend(f'{scope["package"]}:{scope["kind"]}:{scope["name"] or "lib"}:{name}' for name in names)
        targets.append(result)
    require(total == closed.get("total") and len(qualified) == len(set(qualified)), "native totals or qualified identity union differs")
    for package in sorted({scope["package"] for scope in scopes}):
        label = next((value for value in [f"frozen-build-final-{package}", f"frozen-build-{package}"] if (BASE / (value + ".json")).is_file()), None)
        require(label is not None, f"missing final serial native build: {package}")
        row, _ = evidence.receipt(label)
        expected = ["cargo", "test", "--locked", "--release", "--jobs", "1", "-p", package, "--no-run"]
        for scope in scopes:
            if scope["package"] == package:
                expected.append(scope["kind"])
                if scope["name"]:
                    expected.append(scope["name"])
        require(row["command"] == expected, f"{label}: native build omitted a selected target or changed policy")
    focused = []
    for path in sorted(BASE.glob("focused-*.json")):
        row, log = evidence.receipt(path.stem)
        names = [name for name, status in observed_names(log) if status == "ok"]
        command = row["command"]
        package = command[command.index("-p") + 1]
        kind = next(flag for flag in ["--lib", "--test", "--example"] if flag in command)
        name = None if kind == "--lib" else command[command.index(kind) + 1]
        selected = next(item for item in closed["targets"] if (item["package"], item["kind"], item["name"]) == (package, kind, name))
        require(names and set(names).issubset(selected["inventory"]), f'{row["label"]}: focused identities are absent from the complete target')
        closed_native_log(row, log, names, filtered=len(selected["inventory"]) - len(names))
        focused.append({"receipt": path.name, "passed": len(names), "overlaps_complete_targets": True, "added_to_total": False})
    require(focused, "focused regression receipts are missing")
    for path in [BASE / "native-scopes.json", BASE / "native-closed.json"]:
        evidence.add(path)
    return {"complete": True, "target_count": len(targets), "passed": total, "failed": 0, "ignored": 0, "inventory_sha256": hashlib.sha256(("\n".join(sorted(qualified)) + "\n").encode()).hexdigest(), "targets": targets, "focused": focused}


def selected_scopes(evidence, summary, batches):
    plan_path = BASE / 'selected-scopes.json'
    plan = read_json(plan_path)
    controls_path = BASE / 'selected.ids'
    controls = controls_path.read_text().splitlines()
    require(plan.get('complete') is True and plan.get('selected_total') == 984
            and plan.get('source_inventory_reused_for_scope_planning_only') is True
            and plan.get('require_current_compiler_inventory_exact_match_before_execution') is True,
            'scope plan lost its planning-only/current-admission boundary')
    require(len(controls) == len(set(controls)) == 984 and controls == sorted(controls),
            'exact sorted 984-execution input changed')
    replay = BASE / 'conformance'
    inventory = summary['native_inventory']
    require(inventory.get('command') == [summary['binary'], '--jobs', '1', 'test262', 'list-all',
                                       '--suite-root', summary['suite_root']], 'final inventory command differs')
    inventory_path = replay / inventory['stdout']
    require(Path(inventory['stdout']).name == inventory['stdout']
            and digest(inventory_path) == inventory.get('stdout_sha256'), 'final native inventory hash differs')
    current = batches.native_inventory(inventory_path.read_text())
    require(len(current) == plan.get('source_inventory_execution_count') == 102994
            and digest(inventory_path) == plan.get('source_inventory_sha256'),
            'final full pinned inventory differs from planning authority')
    precheck_path = BASE / 'conformance-inventory-validated.json'
    precheck = read_json(precheck_path)
    enumerated, enumeration_log = evidence.receipt('conformance-inventory-final')
    require(enumerated['command'] == [str(BASE / 'candidate/scriptw'), '--jobs', '1', 'test262',
            'list-all', '--suite-root', 'test262/vendor/test262'], 'pre-execution compiler inventory differs')
    require(digest(BASE / enumerated['log']) == digest(inventory_path)
            and batches.native_inventory(enumeration_log) == current, 'precheck/replay inventories disagree')
    expected_precheck = dict(complete=True, source_head=SOURCE, compiler_identity=summary['compiler_identity'],
        receipt='conformance-inventory-final.json', inventory_sha256=digest(inventory_path), total=len(current),
        selected_total=len(controls), selected_ids_sha256=digest(controls_path), scope_plan_sha256=digest(plan_path))
    require(precheck == expected_precheck, 'pre-execution inventory admission changed')
    required = {'language/module-code/': 602, 'built-ins/Function/prototype/apply/': 88,
                'built-ins/Function/prototype/bind/': 200, 'built-ins/Function/prototype/call/': 90}
    require({row['prefix']: row['count'] for row in plan['scopes']} == required
            and len(plan['scopes']) == len(required), 'complete selected family plan differs')
    union, scopes = set(), []
    for scope in plan['scopes']:
        prefix = scope['prefix']
        actual = sorted(value for value in current if value.split(':', 1)[1].startswith(prefix))
        require(actual == sorted(scope['execution_ids']) and len(actual) == scope['count']
                and not union.intersection(actual), 'final selected family omits, adds or overlaps cases: ' + prefix)
        union.update(actual)
        scopes.append({'prefix': prefix, 'count': len(actual)})
    require(set(plan['known_failure_controls']) == KNOWN and len(plan['known_failure_controls']) == 4,
            'known failure controls changed')
    union.update(KNOWN)
    require(union == set(controls), 'selected families/controls do not exactly form all requested IDs')
    for path in [plan_path, controls_path, inventory_path, precheck_path]:
        evidence.add(path)
    return controls, dict(complete=True, pre_execution_admission=precheck,
        final_full_inventory_sha256=digest(inventory_path), final_full_inventory_total=len(current),
        scopes=scopes, known_failure_controls=sorted(KNOWN), execution_ids_sha256=digest(controls_path))


def conformance(evidence):
    sys.path.insert(0, str(REPO / "scripts"))
    import test262_execution_batches as batches
    replay = BASE / "conformance"
    summary = read_json(replay / "summary.json")
    receipt, _ = evidence.receipt("conformance-final", exit_code=1)
    require("--workers" in receipt["command"] and receipt["command"][receipt["command"].index("--workers") + 1] == "1" and "--reuse-case-workers" in receipt["command"], "actual replay launcher lost serial workers or native batch evidence")
    command = receipt["command"]
    require(any(Path(part).name == "replay-test262-executions.py" for part in command) and any(Path(part).resolve() == (BASE / "selected.ids").resolve() for part in command), "actual replay launcher does not consume the exact selected input")
    controls, scopes = selected_scopes(evidence, summary, batches)
    identity = summary.get("compiler_identity", {})
    require(identity.get("source_revision") == {"kind": "git-commit", "commit": SOURCE} and identity.get("source_fingerprint_scheme") == "scriptw-program-cache-compiler-v3", "selected native snapshot comes from another compiler source")
    require(identity == read_json(BASE / "candidate/identity.json"), "frozen measured candidate and selected conformance compiler differ")
    require(summary.get("total") == len(controls) and summary.get("replay_mode") == "native-execution-list-v1" and summary.get("outcomes") == {"Success": len(controls) - len(KNOWN), "Bug": len(KNOWN), "Crash": 0, "NotImplemented": 0}, "selected replay is incomplete or has new failures")
    require(summary.get("absent_executions") == [] and summary.get("batch_threads") == 1 and sorted(summary.get("batch_executions", [])) == sorted(controls), "selected replay omits, repeats or parallelizes requested executions")
    frozen_binary = Path(summary["binary"])
    require(frozen_binary.resolve().is_relative_to(replay.resolve()) and digest(frozen_binary) == summary.get("binary_sha256") == identity.get("executable_sha256"), "frozen replay compiler bytes differ")
    require((replay / "executions").read_bytes() == (BASE / "selected.ids").read_bytes() and digest(replay / "executions") == summary.get("execution_list_sha256"), "frozen requested execution list changed")
    fixtures = pinned_fixtures(summary, controls)
    results = summary.get("results", [])
    require(len(results) == len(controls) and {row["execution_id"] for row in results} == set(controls), "actual per-execution result inventory differs")
    require({row["execution_id"] for row in results if row.get("outcome") == "Bug"} == KNOWN, "selected failures differ from the four known controls")
    options = types.SimpleNamespace(output_dir=replay)
    snapshots, invocations = {}, {}
    for row in results:
        require(row.get("protocol") == "native-execution-list-v1" and "infrastructure_error" not in row, "selected verdict lacks native execution evidence")
        batches.verify_saved_result(row, summary, options, snapshots)
        require(row.get("exit_code") == (0 if row["outcome"] == "Success" else 1), "per-execution exit disagrees with verdict")
        path = replay / (hashlib.sha256(row["execution_id"].encode()).hexdigest() + ".json")
        require(read_json(path) == row, "per-execution receipt differs from summary")
        evidence.add(path)
        for name in [row["transcript"], row["native_snapshot"]["path"], row["invocation"]]:
            require(Path(name).name == name, "native replay evidence escaped its directory")
            evidence.add(replay / name)
        invocation_path = replay / row["invocation"]
        if invocation_path not in invocations:
            invocation = read_json(invocation_path)
            require(invocation.get("exit_code") == 1, "native suite exit1 was not retained")
            command = invocation.get("command", [])
            require("run-list" in command and "--threads" in command and command[command.index("--threads") + 1] == "1" and "--timeout-ms" in command and command[command.index("--timeout-ms") + 1] == "60000", "native batch changed worker/deadline policy")
            for stream in ["stdout", "stderr"]:
                stream_path = batches.owned_file(options, invocation[stream])
                require(digest(stream_path) == invocation.get(stream + "_sha256"), "actual native invocation stream changed")
                evidence.add(stream_path)
            invocations[invocation_path] = invocation
    baseline_path = REPO / "docs/rust-rewrite/foreign-modules-20261024.json"
    baseline = read_json(baseline_path)["conformance"]["native_snapshot"]
    signature = lambda rows: sorted((row["test_id"], row["kind"], row["outcome"], row["detail_hash"]) for row in rows)
    failures = signature(baseline["failures"])
    require({row[0] for row in failures} == KNOWN, "historical known-failure reference differs")
    pins = read_json(REPO / "crates/scriptw-test262/src/source-pins.json")
    for path in snapshots:
        snapshot = read_json(path)
        require(signature(snapshot.get("failures", [])) == failures and snapshot.get("timeout_test_ids") == [], "selected failure kind/diagnostics changed or a timeout occurred")
        require(snapshot.get("pinned_revisions") == {"ecma262": pins["ecma262"], "test262": pins["test262_tree"]}, "selected native snapshot changed source pins")
        batches.snapshot_verdicts(snapshot, controls, identity, exit_code=1)
    for name in ["summary.json", "run.json", "executions", "batch-executions", "compiler-identity.stdout", "compiler-identity.stderr", "native-inventory.stderr"]:
        evidence.add(replay / name)
    require(read_json(replay / "run.json").get("compiler_identity") == identity and digest(replay / "batch-executions") == summary.get("batch_execution_list_sha256"), "native replay manifest/list changed")
    return {"complete": True, "total": len(controls), "passed": summary["outcomes"]["Success"], "bug": summary["outcomes"]["Bug"], "crash": 0, "not_implemented": 0, "timeout": 0, "actual_command_exit": 1, "scope": scopes, "execution_ids": sorted(controls), "compiler_identity": identity, "pinned_fixtures": fixtures, "known_failure_reference": {"path": str(baseline_path.relative_to(REPO)), "sha256": digest(baseline_path), "signatures": failures}, "native_snapshots": [{"path": str(path.relative_to(BASE)), "sha256": digest(path)} for path in snapshots], "invocations": list(invocations.values()), "full_test262_chart_refreshed": False}


def products(evidence):
    authority_path = BASE / 'baseline/source-authority.json'
    authority = read_json(authority_path)
    require(authority.get('compiler_source') == BASELINE_SOURCE, 'baseline compiler source changed')
    patch_path = REPO / authority['source_patch']
    release_path = REPO / authority['build_receipt']
    cargo_path = REPO / authority['cargo_products']
    old_report_path = REPO / authority['published_checkpoint']
    old_report = read_json(old_report_path)
    require(old_report.get('source_commit') == BASELINE_SOURCE and old_report.get('complete') is True,
            'baseline published checkpoint source differs')
    old_products = old_report['products']['candidate']
    old_release = read_json(release_path)
    require(patch_path.read_bytes() == b'' and digest(patch_path) == BASELINE_PATCH
            and old_release.get('source_head') == BASELINE_SOURCE
            and old_release.get('source_patch_sha256') == BASELINE_PATCH and old_release.get('exit_code') == 0,
            'baseline was not the actual clean ab97 product')
    old_archive = old_report_path.parent / old_report['archive']['file']
    require(digest(old_archive) == old_report['archive']['sha256'], 'original baseline publication archive changed')
    manifest_path = BASE / 'baseline/original-build-members.json'
    manifest = read_json(manifest_path)
    require(digest(manifest_path) == old_report['archive']['manifest_sha256']
            and manifest['schema'] == 'scriptw-execution-performance-archive-v1'
            and manifest['source_commit'] == BASELINE_SOURCE, 'original build-members authority changed')
    declared = {row['path']: row for row in manifest['members']}
    original_log = release_path.parent / old_release['log']
    for name, path in [('cargo-product.jsonl', cargo_path), ('release-final.json', release_path),
                       ('release-final.log', original_log)]:
        item = declared['execution-performance-20261025/' + name]
        require(path.stat().st_size == item['bytes'] and digest(path) == item['sha256'],
                'original baseline build bytes changed: ' + name)
    require(digest(original_log) == old_release['log_sha256'], 'original release transcript changed')
    evidence.resource(old_release, 'baseline-original-release')
    baseline = read_json(BASE / 'baseline/identity.json')
    require(baseline == old_products['compiler_identity']
            and baseline.get('source_revision') == {'kind': 'git-commit', 'commit': BASELINE_SOURCE},
            'frozen baseline CLI identity differs from the original clean product')
    baseline_hashes = {'scriptw': baseline['executable_sha256'],
        'runtime_baseline': old_products['runtime_runner_sha256'],
        'runtime_boundaries': old_products['runtime_boundaries_sha256']}
    old_cargo = cargo_products(cargo_path)
    for name, expected in baseline_hashes.items():
        require(digest(BASE / 'baseline' / name) == expected, 'frozen baseline executable changed: ' + name)
    candidate = read_json(BASE / 'candidate/identity.json')
    require(candidate.get('source_revision') == {'kind': 'git-commit', 'commit': SOURCE}
            and digest(BASE / 'candidate/scriptw') == candidate.get('executable_sha256')
            and candidate.get('source_fingerprint_scheme') == 'scriptw-program-cache-compiler-v3'
            and re.fullmatch('[0-9a-f]{64}', candidate.get('source_fingerprint', '')),
            'candidate frozen CLI source/fingerprint/bytes differ')
    final, _ = evidence.receipt('release-final')
    require(len(final['command']) == 3 and final['command'][1] == '-B'
            and Path(final['command'][2]).resolve() == BASE / 'build_product.py', 'final product build wrapper differs')
    candidate_cargo_path = BASE / 'cargo-product.jsonl'
    artifacts = cargo_products(candidate_cargo_path)
    for name, row in artifacts.items():
        require(digest(row['executable']) == digest(BASE / 'candidate' / name),
                'frozen candidate differs from actual Cargo product: ' + name)
    for path in [authority_path, release_path, original_log, patch_path, old_report_path, manifest_path,
                 cargo_path, BASE / 'baseline/identity.json', BASE / 'candidate/identity.json',
                 candidate_cargo_path, BASE / 'cargo-product.stderr']:
        evidence.add(path)
    return {
        'baseline': dict(compiler_identity=baseline, runtime_runner_sha256=baseline_hashes['runtime_baseline'],
            runtime_boundaries_sha256=baseline_hashes['runtime_boundaries'], actual_build_source=BASELINE_SOURCE,
            actual_source_patch_sha256=BASELINE_PATCH, measurement_launcher_checkout=SOURCE,
            original_release_receipt={'path': str(release_path.relative_to(REPO)), 'sha256': digest(release_path)},
            original_cargo_products={'path': str(cargo_path.relative_to(REPO)), 'sha256': digest(cargo_path),
                                     'producers': old_cargo},
            provenance='Actual clean ab97 release and published frozen product hashes; original Cargo paths may now hold later builds and are not relabelled as baseline executables.'),
        'candidate': dict(compiler_identity=candidate,
            runtime_runner_sha256=digest(BASE / 'candidate/runtime_baseline'),
            runtime_boundaries_sha256=digest(BASE / 'candidate/runtime_boundaries'),
            source_tree_clean=True, release_receipt='release-final.json', cargo_producers=artifacts),
    }


def performance(evidence, product_report):
    module_path = BASE / "analyze.py"
    spec = importlib.util.spec_from_file_location("execution_performance_analysis", module_path)
    analysis = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(analysis)
    require(callable(getattr(analysis, "build_report", None)), "analysis tool must expose read-only build_report()")
    actual = analysis.build_report()
    path = BASE / "analysis.json"
    require(read_json(path) == actual and actual.get("complete") is True and actual.get("round_order") == ROUNDS, "comparison summary differs from validated actual observations")
    require(len(actual.get("cases", [])) == 17, "balanced comparison did not finish all17 exact workloads")
    rows = []
    for index, label in enumerate(ROUNDS):
        product = "baseline" if index in [0, 3] else "candidate"
        report = read_json(BASE / label / "report.json")
        identity = product_report[product]["compiler_identity"]
        require(report.get("compiler_identity") == identity and report.get("runtime_runner_sha256") == product_report[product]["runtime_runner_sha256"], f"{label}: measured binary/source identity differs")
        receipt_label = label.removesuffix("-data")
        receipt, _ = evidence.receipt(receipt_label)
        require(report.get("samples") == 7 and report.get("warmups") == 10 and report.get("complete") is True, f"{label}: incomplete sample/warmup policy")
        for item in (BASE / label).iterdir():
            if item.is_file() and (item.name == "report.json" or item.suffix in {".stdout", ".stderr"}):
                evidence.add(item)
            elif item.is_dir() and item.name.endswith("-wasm"):
                for artifact in item.iterdir():
                    require(artifact.is_file() and artifact.suffix == ".wasm", "unexpected measured artifact member")
                    evidence.add(artifact)
    for case in actual["cases"]:
        before = case["pooled"]["baseline"]["wasmtime"]["median_execution_ns"]
        after = case["pooled"]["candidate"]["wasmtime"]["median_execution_ns"]
        v8 = case["pooled"]["candidate"]["v8"]["median_execution_ns"]
        rows.append({"file": case["file"], "baseline_ms": before / 1e6, "candidate_ms": after / 1e6, "change_percent": 100 * (after / before - 1), "paired_candidate_v8_ms": v8 / 1e6, "candidate_over_paired_v8": after / v8})
    for extra in [module_path, path, REPO / "crates/scriptw-cli/tests/fixtures/v8_baseline/node-runtime.cjs"]:
        evidence.add(extra)
    for extra in analysis.evidence_files():
        evidence.add(extra)
    fixtures = REPO / "crates/scriptw-cli/tests/fixtures/v8_execution_hotpaths"
    for path in fixtures.iterdir():
        require(path.is_file() and path.suffix in {".js", ".json"}, "unexpected workload fixture member")
        evidence.add(path)
    return {"complete": True, "balanced_observations": actual, "table": rows, "table_statistic": "median of14 measured samples per product, pooled from two fresh process rounds of7 measured samples after10 warmups each; per-round medians and adjacent comparisons retained", "policy": "unchanged default Fast P and optimized Portable R, 16-MiB initial GC capacity; one CPU, fresh Store/Realm or V8 context; execution+completion includes construction and checksums", "interpretation": "descriptive paired measurements, not a statistical significance test or a universal V8-parity claim", "ambient_load_limit": "unrelated CPU-active processes and desktop activity were observed on the shared host; loadavg start/end is retained for every round; this is not an otherwise-idle or isolated causal measurement and cannot certify idle-machine repeatability", "historical_readme_graph_refreshed": False}


def performance_calls(evidence, product_report):
    """Keep callback-delimited calls separate from ordinary entry execution."""
    sys.path.insert(0, str(BASE))
    module_path = BASE / "analysis_calls.py"
    spec = importlib.util.spec_from_file_location("execution_performance_call_analysis", module_path)
    analysis = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(analysis)
    actual = analysis.build_report()
    path = BASE / "analysis_calls.json"
    require(read_json(path) == actual, "existing-Realm comparison differs from actual checked sessions")
    require(actual.get("schema") == "scriptw-execution-same-realm-comparison-v1" and actual.get("complete") is True and actual.get("round_order") == CALL_ROUNDS, "existing-Realm ABBA cohort is partial, reordered or mislabeled")
    require(actual.get("case_count") == 17 and actual.get("samples_per_session") == 7 and actual.get("guest_warmups") == 10 and actual.get("sessions_per_product") == 2 and actual.get("pooled_samples_per_product") == 14, "existing-Realm session/call/warmup denominator changed")
    fixtures = REPO / "crates/scriptw-cli/tests/fixtures/v8_execution_hotpaths"
    expected_cases = read_json(fixtures / "manifest.json")["execution"]
    require([case["file"] for case in actual["cases"]] == [case["file"] for case in expected_cases], "existing-Realm cohort does not preserve the exact17 original workloads")
    for index, label in enumerate(CALL_ROUNDS):
        product = "baseline" if index in [0, 3] else "candidate"
        round_report = read_json(BASE / label / "report.json")
        require(round_report.get("compiler_identity") == product_report[product]["compiler_identity"] and round_report.get("runtime_boundaries_sha256") == product_report[product]["runtime_boundaries_sha256"], f"{label}: callback observer product/source differs from frozen authority")
        receipt, _ = evidence.receipt(label.removesuffix("-data"))
        command = receipt["command"]
        require(any(Path(part).name == "measure_calls.py" for part in command) and product in command and label in command, f"{label}: actual call measurement command differs")
    rows = []
    for case in actual["cases"]:
        require(case["original_source_sha256"] == digest(fixtures / case["file"]), "existing-Realm original workload source changed")
        before = case["pooled"]["baseline"]["wasmtime"]["median_ns"]
        after = case["pooled"]["candidate"]["wasmtime"]["median_ns"]
        v8 = case["pooled"]["candidate"]["v8"]["median_ns"]
        rows.append({"file": case["file"], "baseline_ms": before / 1e6, "candidate_ms": after / 1e6, "change_percent": 100 * (after / before - 1), "paired_candidate_v8_ms": v8 / 1e6, "candidate_over_paired_v8": after / v8})
    evidence.add(path)
    for extra in analysis.evidence_files():
        evidence.add(extra)
    return {"complete": True, "balanced_observations": actual, "table": rows, "table_statistic": "median of14 elapsed callback intervals per product, pooled from two existing-Realm sessions of7 calls after10 guest warmups each", "measurement": "elapsed wall time between actual callback exit/entry timestamps; not a measured CPU clock; includes workload construction/checksum and marker overhead; excludes setup/bootstrap, warmups, checksum printing, bundle/cache admission and native compilation; no empty subtraction", "source_cohort": "separate generated wrapper: original workload IIFE body becomes batch(seed), sole final print expression becomes return expression; original inputs and explicit String(checksum) conversions retained; exact result checked outside every interval", "archive_exclusions": "session Portable P/R bundles, V8 cachedData, executables and native caches excluded; actual payload hashes/framing, regeneration commands, transformed sources and harness snapshots retained", "ambient_load_limit": "shared-host CPU/desktop activity and raw load averages retained; descriptive observations cannot certify idle-machine repeatability, causal significance or universal V8 parity"}


def markdown(report):
    q = chr(96)
    call_controls = {row['file']: row for row in report['same_realm_performance']['balanced_observations']['cases']}
    reverse = call_controls['sort-reverse-512.js']
    retained = call_controls['retained-objects.js']
    integer = call_controls['integer.js']
    def table(rows):
        return '\n'.join(f'| {q}{r["file"]}{q} | {r["baseline_ms"]:.3f} | {r["candidate_ms"]:.3f} | {r["change_percent"]:+.1f}% | {r["paired_candidate_v8_ms"]:.3f} |' for r in rows)
    memory_rows = []
    for row in report['performance']['balanced_observations']['cases']:
        pooled = row['pooled']
        field = 'final_rss_bytes'
        before = pooled['baseline']['wasmtime']['memory_observations'][field]['median'] / 2**20
        after = pooled['candidate']['wasmtime']['memory_observations'][field]['median'] / 2**20
        v8 = pooled['candidate']['v8']['memory_observations']['rss_after_execution_bytes']['median'] / 2**20
        memory_rows.append(f'| {q}{row["file"]}{q} | {before:.2f} | {after:.2f} | {100*(after/before-1):+.1f}% | {v8:.2f} |')
    mapping_rows = []
    for row in report['memory_maps']['summaries']:
        before = row['products']['baseline']['totals']['rss_bytes']['median'] / 2**20
        after = row['products']['candidate']['totals']['rss_bytes']['median'] / 2**20
        mapping_rows.append(f'| {q}{row["file"]}{q} | {row["phase"]} | {before:.2f} | {after:.2f} | {row["rss_change_percent"]:+.1f}% |')
    context = next(row for row in report['memory_maps']['summaries']
                   if row['file'] == 'startup.js' and row['phase'] == 'guest-start')['products']['baseline']
    groups = context['group_rss_bytes']
    native_rows = '\n'.join(f'| {q}{r["package"]}{q} {r["name"] or "library"} | {r["passed"]:,} |' for r in report['native']['targets'])
    ownership = report['ownership_change']
    intl = report['intl_requested_allocation_diagnostic']
    preflight = report['memory_maps']['excluded_unreceipted_preflight']['summaries']
    first = next(row for row in preflight if row['file'] == 'startup.js' and row['phase'] == 'guest-start')
    preflight_rows = []
    for name in ('startup.js', 'integer.js', 'retained-objects.js'):
        values = {row['phase']: row['rss_bytes_median'] / 2**20 for row in preflight if row['file'] == name}
        preflight_rows.append(f'| {q}{name}{q} | {values["guest-start"]:.2f} | {values["guest-body-finished"]:.2f} |')
    return f'''# JavaScript execution memory, 2026-10-25

Source [{q}{SOURCE[:9]}{q}](https://github.com/mewhhaha/scriptw/commit/{SOURCE}) removes a redundant allocation of immutable raw runtime Wasm from Cargo-owned build packages. The runtime now borrows the validated static package payload under its existing build-output authority. External packages and source-free Portable bundles retain independently owned admitted bytes. The [runtime byte-ownership contract](contracts/runtime-byte-ownership.md) records that lifetime boundary.

The accepted baseline is the actual **clean {q}{BASELINE_SOURCE[:9]}{q} release**, with its original three frozen executable hashes and Cargo producer receipts. Candidate native tests, products, selected Test262 and measurements all identify the clean source above. Wasm layout, foreign ABI and the default Fast/16-MiB/SinglePass policy are unchanged.

The mapped runtime contains **{ownership["observed_raw_runtime_bytes"]:,} raw Wasm bytes ({ownership["observed_raw_runtime_bytes"]/2**20:.2f} MiB)**. Borrowing removes a second host allocation of those bytes where Cargo owns the package. It does not eliminate the native runtime image, the Wasmtime code mapping, Realm state or GC storage. The external-bundle call cohort remains owned; its costs are retained rather than relabelled as borrowed-Cargo measurements.

## What consumes memory before the workload

At the acknowledged {q}startup.js{q} guest-start boundary, after Realm bootstrap but before the body, the baseline's median process RSS is **{context["totals"]["rss_bytes"]["median"]/2**20:.2f} MiB**. Mapping groups show **{groups["anon"]["median"]/2**20:.2f} MiB** in other anonymous ranges, **{groups["file-backed"]["median"]/2**20:.2f} MiB** in file-backed ranges and **{groups["anon-exec"]["median"]/2**20:.2f} MiB** in anonymous executable ranges. Kernel {q}[heap]{q}/{q}[stack]{q} groups remain separate. These are process mappings, not a measured JS heap or precise component-allocation totals.

The mapped R text spans {', '.join(f'{value/2**20:.2f} MiB' for value in context['native_text_bytes']['R'])}; the admitted serialized Portable native image is {', '.join(f'{value/2**20:.2f} MiB' for value in context['portable_native_image_bytes'])}. R text and the serialized image are different extents. Intersections retain whole mappings without inventing proportional RSS per function. Virtual reservations, observed residency and GC capacity remain separate.

## A separately measured remaining cost: Intl data

A standalone helper linked the actual default-feature optimized {q}scriptw-intl{q} rlib, without an Engine, Wasmtime or JavaScript execution. A counting {q}System{q} GlobalAlloc wrapper records successful requested sizes and releases. Four snapshots bracket Minimal selection construction, resolution of all 12 services and their identity, and dropping local selection/frame leases. The final snapshot retains **{intl['after_drop_requested_live_bytes']/2**20:.3f} MiB of requested-live Rust bytes**, with a **{intl['logical_requested_live_peak_bytes']/2**20:.3f}-MiB cumulative logical requested-live high-water**. The 12 serialized frame lengths total **{intl['serialized_frame_bytes']/2**20:.3f} MiB**. The final allocation state is unchanged by dropping local leases, consistent with retained provider/component OnceLocks.

These are requested Rust allocation counters in a separate diagnostic process, not JavaScript bytes, allocator usable/resident size, RSS or OS allocation totals. Reallocation accounting includes each full successful new request and releases its old size; its logical high-water excludes allocator-internal overlap and native allocations bypassing GlobalAlloc. Frame lengths are serialized payload extents, not separately attributed resident allocations. This result does **not** assign any whole 64-MiB anonymous execution mapping to Intl. Actual Cargo producer metadata, rlib/executable SHA-256 values, source, commands and all transcripts remain archived; the executable and rlib payloads do not.

## Acknowledged mapping comparison

Four mapping rounds run serially in **baseline–candidate–candidate–baseline** order. Each round uses three checked controls, three measured invocations after one warmup, and guest-start/body-finished callbacks. The parent reads and saves {q}/proc/PID/smaps{q} while the real Wasm child awaits acknowledgement. Each product has six snapshots per case/boundary; the table uses their median RSS. Native R/P address/hash records, source transformations, original source bytes, checked outputs and every raw snapshot remain archived. Callback holds and snapshot reads make these attribution diagnostics, **not ordinary execution scores**.

| Workload | Boundary | Before RSS MiB | After RSS MiB | Change |
| --- | --- | ---: | ---: | ---: |
{chr(10).join(mapping_rows)}

The original unreceipted baseline preflight remains separately preserved: its actual runner, sources, checksums and mappings are checked, but it supplies no accepted mapping samples and no retrospective kernel cap/OOM claim. Its print control already has **{first['rss_bytes_median']/2**20:.2f} MiB** resident at guest-start, with anonymous/file-backed/anonymous-executable group medians **{first['group_rss_bytes_medians']['anon']/2**20:.2f} / {first['group_rss_bytes_medians']['file-backed']/2**20:.2f} / {first['group_rss_bytes_medians']['anon-exec']/2**20:.2f} MiB**. Those three-sample preflight medians are diagnostic context, separate from the accepted table above. All four accepted rounds have their own complete resource receipts.

| Original preflight control | Guest-start RSS MiB | Body-finished RSS MiB |
| --- | ---: | ---: |
{chr(10).join(preflight_rows)}

## Fresh-Realm performance and memory

All 17 ordinary workload bodies run in separate fresh-process rounds, again in baseline–candidate–candidate–baseline order. Each runtime has seven measured fresh Store/Realm or V8 contexts after ten warmups per round. Tables pool the 14 measured observations per product; V8 uses its paired candidate rounds. Construction, checksums and completion stay in execution; setup and native compilation are recorded separately. Every control and slowdown is retained. Shared-host activity/load averages remain recorded; this is descriptive evidence rather than statistical significance or universal V8 parity.

| Workload | Before ms | After ms | Change | Paired V8 ms |
| --- | ---: | ---: | ---: | ---: |
{table(report['performance']['table'])}

The next table reports medians of **post-execution process RSS endpoints**, the same values used by the current README bar chart. It includes runtime/setup and retained warmup effects, and is neither whole-child peak RSS nor live JavaScript bytes. Sampled maximum RSS and GC-capacity observations remain in the machine-readable evidence; they are distinct counters and are not silently substituted for endpoints.

| Workload | Before RSS MiB | After RSS MiB | Change | Paired V8 RSS MiB |
| --- | ---: | ---: | ---: | ---: |
{chr(10).join(memory_rows)}

## Separate existing-Realm calls

The second 17-case ABBA cohort loads an independently admitted source-free Portable bundle into each fresh process. Generated wrappers preserve the original workload bodies and inputs; their final print expression becomes the checked return. Ten guest warmups precede seven callback-exit-to-entry intervals per session; two sessions per product give 14 elapsed calls. Construction/checksum work remains inside each call. Setup/bootstrap, printing, source-free bundle/cache admission and native compilation stay outside; no empty-control subtraction is made. These wrappers and boundaries differ from the ordinary fresh-Realm corpus. External bundle payloads remain owned in this implementation.

| Workload | Before ms | After ms | Change | Paired V8 ms |
| --- | ---: | ---: | ---: | ---: |
{table(report['same_realm_performance']['table'])}

Several existing-Realm controls were slower: reverse-512 sort by **{reverse['median_change_percent']:+.1f}%**, retained objects by **{retained['median_change_percent']:+.1f}%**, and integer by **{integer['median_change_percent']:+.1f}%** in the pooled medians. Reverse-sort's adjacent round changes were {reverse['adjacent_pairs'][0]['change_percent']:+.1f}% and {reverse['adjacent_pairs'][1]['change_percent']:+.1f}%; retained objects were {retained['adjacent_pairs'][0]['change_percent']:+.1f}% and {retained['adjacent_pairs'][1]['change_percent']:+.1f}%. The shared host and round variation prevent a causal attribution to the ownership change. These observations do not establish unchanged call performance.

Whole-child RSS for this cohort includes setup/warmups and remains separate from invocation endpoints. Raw P/R bundles, V8 cachedData and executables are excluded from this archive; their actual hashes, framing metadata, original/transformed sources and regeneration commands remain.

## Verification and resources

The final source passed **{report['native']['passed']:,} native checks across {report['native']['target_count']} complete affected targets**, with no failures or ignored tests. The engine library uses an exact disjoint union of bounded fresh processes. Focused runtime ownership checks overlap those target totals and are not added again.

The selected original Test262 replay completed **{report['test262']['total']:,} executions: {report['test262']['passed']:,} Success / {report['test262']['bug']} known Bug / {report['test262']['crash']} Crash / {report['test262']['not_implemented']} NotImplemented**, with zero timeouts and actual exit **{report['test262']['actual_command_exit']}**. Complete module-code and Function apply/bind/call families plus four explicit failure controls reconcile to the final compiler's full **102,994-ID** inventory. The same four diagnostic hashes and pinned fixture bytes are retained. This is selected acceptance; it does not refresh the full Test262 chart.

Every accepted build, native run, replay, map round and benchmark receipt records one CPU, a kernel-enforced **4-GiB cap**, zero swap, grouped OOM policy, serial pools and a one-entry/64-MiB retained module cache. No accepted receipt reports OOM. Additional/partial observations, if any, are separately retained with their actual identities and outcomes.

| Native target | Passed |
| --- | ---: |
{native_rows}

[Machine-readable results]({STEM}.json) and [raw evidence/reproduction scripts]({STEM}.tar.gz) retain exact commands, complete inventories, pins, actual executable/source identities and all observations. The archive SHA-256 is {q}{report['archive']['sha256']}{q}; compiler/test executables, caches and unused raw bundle payloads are excluded.

To refresh, check out the measured source, perform the archived serial build/focus/native plan under {q}python3 -B scripts/limited_verification.py --{q}, freeze the three actual ordinary release products, validate the complete CLI inventory and replay {q}selected.ids{q} with one worker/reused native workers and the original 60-second deadlines. Run {q}measure_maps_all.py{q} for four acknowledged mapping rounds; run {q}measure_all.py{q} for separate fresh/call ABBA cohorts. Re-derive both analyses from raw observations. {q}publish_evidence.py{q} validates only by default; {q}--publish{q} requires every closed input and refuses to overwrite an existing checkpoint. The README graph can be reproduced with {q}scripts/render-execution-performance.py --report docs/rust-rewrite/{STEM}.json{q}. Existing receipts remain past observations, never new executions.
'''


def pinned_fixtures(summary, controls):
    """Bind observed fixture SHA-256s to blobs in the exact pinned Git tree."""
    pins_path = REPO / "crates/scriptw-test262/src/source-pins.json"
    pins = read_json(pins_path)
    tree = subprocess.check_output(["git", "rev-parse", SOURCE + ":test262/vendor/test262"], cwd=REPO, text=True).strip()
    require(tree == pins["test262_tree"], "source commit does not contain the pinned Test262 tree")
    paths = {execution.split(":", 1)[1] for execution in controls}
    require(set(summary.get("fixture_sha256", {})) == paths, "fixture digest inventory does not cover exactly the requested paths")
    tree_entries = subprocess.check_output(["git", "ls-tree", "-r", "-z", SOURCE + ":test262/vendor/test262/test"], cwd=REPO)
    blobs = {}
    for entry in tree_entries.split(b"\0"):
        if not entry: continue
        header, name = entry.split(b"\t", 1)
        name = name.decode()
        if name in paths:
            _, kind, oid = header.split()
            require(kind == b"blob", "requested fixture is not a pinned Git blob")
            blobs[name] = oid.decode()
    require(set(blobs) == paths, "requested fixture is missing from the pinned tree")
    ordered = sorted(blobs)
    process = subprocess.run(["git", "cat-file", "--batch"], input=("\n".join(blobs[name] for name in ordered) + "\n").encode(), stdout=subprocess.PIPE, stderr=subprocess.PIPE, cwd=REPO, check=True)
    content, offset = process.stdout, 0
    for name in ordered:
        end = content.index(b"\n", offset)
        oid, kind, length = content[offset:end].split()
        require(oid.decode() == blobs[name] and kind == b"blob", "Git returned another fixture object")
        start, size = end + 1, int(length)
        data = content[start:start + size]
        require(len(data) == size and content[start + size:start + size + 1] == b"\n", "pinned fixture batch is truncated")
        require(hashlib.sha256(data).hexdigest() == summary["fixture_sha256"][name], f"observed fixture differs from pinned Git bytes: {name}")
        offset = start + size + 1
    require(offset == len(content), "unexpected trailing Git fixture data")
    return {"source_tree": tree, "fixture_count": len(paths), "fixture_hashes": summary["fixture_sha256"]}

def archive(evidence, output):
    rows = [{"path": name, "bytes": path.stat().st_size, "sha256": digest(path)} for name, path in sorted(evidence.paths.items())]
    manifest = {"schema": "scriptw-execution-performance-archive-v1", "source_commit": SOURCE, "members": rows, "excluded": "Compiler/test/example binaries, caches and temporary files are excluded. Binary hashes are retained in command receipts and the native snapshot. Git commit reproduces the exact product source."}
    manifest_bytes = (json.dumps(manifest, indent=2) + "\n").encode()
    temporary = output.with_suffix(output.suffix + ".pending")
    with temporary.open("wb") as raw, gzip.GzipFile(fileobj=raw, mode="wb", filename="", mtime=0, compresslevel=6) as compressed, tarfile.open(fileobj=compressed, mode="w") as bundle:
        for row in rows:
            path = evidence.paths[row["path"]]
            require(path.stat().st_size == row["bytes"] and digest(path) == row["sha256"], f"evidence changed during publication: {path}")
            info = tarfile.TarInfo(row["path"])
            info.size, info.mode = row["bytes"], 0o644
            with path.open("rb") as stream:
                bundle.addfile(info, stream)
        info = tarfile.TarInfo(PREFIX + "archive-members.json")
        info.size, info.mode = len(manifest_bytes), 0o644
        bundle.addfile(info, io.BytesIO(manifest_bytes))
    expected = {row["path"]: row for row in rows}
    seen = set()
    with tarfile.open(temporary, "r:gz") as bundle:
        for member in bundle:
            require(member.isfile() and member.name not in seen, "archive contains a nonfile or duplicate")
            seen.add(member.name)
            stream = bundle.extractfile(member)
            if member.name == PREFIX + "archive-members.json":
                require(stream.read() == manifest_bytes, "archive manifest changed")
            else:
                row = expected[member.name]
                require(member.size == row["bytes"] and hashlib.file_digest(stream, "sha256").hexdigest() == row["sha256"], "archive round-trip hash mismatch")
    require(seen == set(expected) | {PREFIX + "archive-members.json"}, "archive inventory is incomplete")
    require(len(seen) <= 6000 and temporary.stat().st_size <= 32 * 1024**2
            and sum(row['bytes'] for row in rows) + len(manifest_bytes) <= 256 * 1024**2,
            'evidence archive exceeds offline graph-reader limits')
    temporary.replace(output)
    return {"file": output.name, "sha256": digest(output), "bytes": output.stat().st_size, "member_count": len(seen), "manifest_sha256": hashlib.sha256(manifest_bytes).hexdigest(), "expanded_bytes": sum(row["bytes"] for row in rows) + len(manifest_bytes)}


def cargo_products(path):
    rows, finished = {}, []
    names = {'scriptw', 'runtime_baseline', 'runtime_boundaries'}
    require(path.stat().st_size < 64 * 1024**2, 'Cargo product transcript exceeds publication budget')
    for line in path.read_text().splitlines():
        row = json.loads(line)
        if row.get('reason') == 'build-finished':
            finished.append(row.get('success'))
        if row.get('reason') != 'compiler-artifact' or not row.get('executable'):
            continue
        name = Path(row['executable']).name
        if name not in names:
            continue
        require(name not in rows, 'duplicate final Cargo executable: ' + name)
        kind = 'bin' if name == 'scriptw' else 'example'
        require(row.get('features') == [] and row['profile']['opt_level'] == '3'
                and row['profile']['test'] is False and row['target']['name'] == name
                and kind in row['target']['kind']
                and Path(row['manifest_path']).resolve() == REPO / 'crates/scriptw-cli/Cargo.toml',
                'Cargo executable lacks its actual ordinary default-feature release producer: ' + name)
        rows[name] = row
    require(finished == [True] and set(rows) == names, 'Cargo product build omitted/failed an ordinary executable')
    return rows

def focused_plan(evidence, native_report):
    path = BASE / 'focus-plan.json'
    plan = read_json(path)
    require([row[0] for row in plan] == ['runtime-artifact', 'runtime-link', 'embedded-runtime'],
            'complete runtime ownership focused plan changed')
    accepted = {item['receipt']: item for item in native_report['focused']}
    require(set(accepted) == {'focused-' + label + '.json' for label, _ in plan},
            'focused native receipt plan differs')
    for label, command in plan:
        row = read_json(BASE / ('focused-' + label + '.json'))
        require(row['command'] == command + ['--', '--test-threads=1', '--include-ignored'],
                'focused ownership filter/worker plan differs: ' + label)
    evidence.add(path)

def additional_observations(evidence):
    extra = []
    accepted = {path.resolve() for path in evidence.paths.values()}
    for log in sorted(BASE.glob('*.log')):
        if log.resolve() in accepted:
            continue
        receipt_path = log.with_suffix('.json')
        item = {'log': log.name, 'log_sha256': digest(log),
                'included_in_accepted_totals': False}
        if receipt_path.is_file():
            receipt = read_json(receipt_path)
            require(receipt.get('log') == log.name and receipt.get('log_sha256') == digest(log),
                    'extra diagnostic receipt/transcript differs: ' + log.name)
            item.update(status='terminal-observation-outside-accepted-inputs',
                        actual_receipt=receipt)
            evidence.add(receipt_path)
        else:
            item['status'] = 'partial-observation-without-terminal-receipt'
        evidence.add(log)
        extra.append(item)
    return {'observations': extra, 'interpretation': 'Actual additional/partial/failing observations are preserved under their original identities. They do not enter accepted native/performance totals or acquire retroactive kernel-resource claims.'}



def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--publish', action='store_true')
    args = parser.parse_args()
    os.sched_setaffinity(0, {min(os.sched_getaffinity(0))})
    current_source()
    evidence = Evidence()
    native_report = native(evidence)
    focused_plan(evidence, native_report)
    product_report = products(evidence)
    conformance_report = conformance(evidence)
    performance_report = performance(evidence, product_report)
    calls_report = performance_calls(evidence, product_report)
    sys.path.insert(0, str(BASE))
    from publication_memory_maps import build_report as map_report
    mapping_report = map_report(evidence, product_report, SOURCE, BASELINE_SOURCE)
    for name in ['publish_evidence.py', 'publication_memory_maps.py', 'native_final.py', 'engine_batches.py',
                 'accept_native.py', 'build_native.py', 'build_product.py', 'freeze_candidate.py', 'prepare_candidate.py', 'post_native.py', 'focus.py', 'focus-plan.json', 'measure.py',
                 'measure_all.py', 'measure_calls.py', 'measure_maps_all.py', 'run_check.py',
                 'validate_inventory.py', 'campaign.json']:
        evidence.add(BASE / name)
    for name in ['limited_verification.py', 'resource_numbers.py', 'replay-test262-executions.py',
                 'test262_execution_batches.py', 'profile_memory_maps.py', 'process_memory_maps.py']:
        evidence.add(REPO / 'scripts' / name)
    from publication_intl_allocation import build_report as intl_report
    intl_diagnostic = intl_report(evidence, SOURCE)
    evidence.add(BASE / 'publication_intl_allocation.py')
    diagnostics = additional_observations(evidence)
    raw_sizes = {value for row in mapping_report['summaries'] for product in row['products'].values()
                 for value in product['runtime_wasm_bytes']}
    require(len(raw_sizes) == 1, 'runtime raw extent changed across mapped source/corpus')
    report = dict(schema='scriptw-execution-performance-checkpoint-v1', refresh_date='2026-10-25', complete=True,
        source_commit=SOURCE, campaign=read_json(BASE / 'campaign.json'), native=native_report,
        products=product_report, test262=conformance_report, performance=performance_report,
        same_realm_performance=calls_report, memory_maps=mapping_report,
        intl_requested_allocation_diagnostic=intl_diagnostic, additional_observations=diagnostics,
        ownership_change={'contract': 'docs/rust-rewrite/contracts/runtime-byte-ownership.md',
            'observed_raw_runtime_bytes': next(iter(raw_sizes)),
            'change': 'Borrow validated immutable Cargo-owned static raw payload; emitted/external/bundle payloads remain owned.',
            'unchanged': 'Wasm GC/reference/EH lower bound, R/P layout and foreign ABI, copying GC and ordinary Fast/16MiB/SinglePass.'},
        resources=dict(cpus=1, memory_limit_bytes=BUDGET, swap_limit_bytes=0, accepted_oom_events=0,
            maximum_cgroup_peak_bytes=max(row['memory_peak_bytes'] for row in evidence.resources),
            field_provenance=evidence.resources))
    require(report['campaign'].get('source_commit') == SOURCE
            and report['campaign'].get('baseline_source') == BASELINE_SOURCE
            and report['campaign'].get('baseline_exact_patch_sha256') == BASELINE_PATCH,
            'campaign source authority differs')
    if not args.publish:
        print(json.dumps(dict(validated=True, native_passed=native_report['passed'],
            native_targets=native_report['target_count'], selected_test262=conformance_report['total'],
            performance_cases=len(performance_report['table']), separate_existing_realm_cases=len(calls_report['table']),
            accepted_mapping_snapshots=mapping_report['accepted_snapshot_count'],
            archive_members=len(evidence.paths) + 1, publication='not requested'), indent=2))
        return
    output = REPO / 'docs/rust-rewrite'
    paths = [output / (STEM + extension) for extension in ('.md', '.json', '.tar.gz')]
    require(not any(path.exists() for path in paths), 'refusing to overwrite published evidence')
    require(len((json.dumps(report, indent=2) + '\n').encode()) + 4096 <= 16 * 1024**2, 'checkpoint JSON exceeds graph-reader budget')
    report['archive'] = archive(evidence, paths[2])
    encoded = (json.dumps(report, indent=2) + '\n').encode()
    require(len(encoded) <= 16 * 1024**2, 'checkpoint JSON exceeds graph-reader budget')
    paths[1].write_bytes(encoded)
    paths[0].write_text(markdown(report))
    print(json.dumps(dict(published=[str(path.relative_to(REPO)) for path in paths],
        native_passed=native_report['passed'], archive=report['archive']), indent=2))


if __name__ == "__main__":
    try:
        main()
    except (KeyError, ValueError, OSError, TypeError, StopIteration) as error:
        print(f"Evidence publication refused: {error}", file=sys.stderr)
        raise SystemExit(1)
