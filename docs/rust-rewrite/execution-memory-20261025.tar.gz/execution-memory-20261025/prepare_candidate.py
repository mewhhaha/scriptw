import pathlib,subprocess,sys
root=pathlib.Path(__file__).resolve().parent
def run(command):
 code=subprocess.call(command)
 if code:sys.exit(code)
run([sys.executable,'-B',str(root/'focus.py')])
run([sys.executable,'-B',str(root/'run_check.py'),'release-final',sys.executable,'-B',str(root/'build_product.py')])
run([sys.executable,'-B',str(root/'freeze_candidate.py')])
run([sys.executable,'-B',str(root/'validate_inventory.py')])
