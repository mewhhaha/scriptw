"""Private publisher: run only after parent review; never execute retained artifacts."""
from datetime import datetime, timezone
import hashlib,json,lzma,re,sys,tarfile
from pathlib import Path,PurePosixPath
BASE=Path(__file__).resolve().parent;ROOT=BASE.parents[1];DEST=ROOT/'docs/rust-rewrite'
STEM='memory-phase-boundaries-20261027';SOURCE='38c25942b63a752ce5db46b6cb42b46ed98f9a57';RUN='40540496469'
sys.path.insert(0,str(ROOT/'scripts'))
import precompiled_comparison as p
from native_test_protocol import result_summaries

def read(path):return json.loads(path.read_text())
def sha(path):
 with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def validate_commands(report):
 assert report['source_commit']==SOURCE and report['complete']
 for command in report['commands']:
  assert command['exit_code']==0
  for stream in ['stdout','stderr']:assert sha(BASE/command[stream])==command[stream+'_sha256']
def budget(report):
 assert report['cpu_affinity']==[0]
 for moment in ['before','after']:
  b=report[moment];assert b['memory.max']=='4294967296' and b['memory.swap.max']=='0' and b['memory.oom.group']=='1'
 events=[dict(line.split() for line in report[m]['memory.events'].splitlines())for m in ['before','after']]
 assert all(events[0][k]==events[1][k] for k in ['oom','oom_kill','oom_group_kill'])

native=read(BASE/'native.json');cheap=read(BASE/'cheap.json');processing=read(BASE/'ci-processing.json')
for report in [native,cheap,processing]:validate_commands(report)
for report in [native,processing]:budget(report)
assert sum(scope['passed']for scope in native['scopes'])==13 and len(native['scopes'])==2
for scope in native['scopes']:
 inventory=scope['inventory'];assert len(inventory)==len(set(inventory))==scope['passed']
 raw=(BASE/(scope['target']+'-tests.stdout')).read_text()
 actual=[name.removesuffix(' - should panic')for name in re.findall(r'^test ([^\r\n]+) \.\.\. ok$',raw,re.M)]
 assert set(actual)==set(inventory) and len(actual)==len(inventory)
 assert result_summaries(raw)==[('ok',str(len(inventory)),'0','0','0','0')]
assert re.search(r'^Ran 49 tests in ',(BASE/'python-tooling.stderr').read_text(),re.M)
assert (BASE/'python-tooling.stderr').read_text().rstrip().endswith('OK')
assert processing['run']==RUN and processing['scored_mutations'] is False
bindings=read(BASE/'source-bindings-computed.json');assert len(bindings)==2
assert all(row['revision']==SOURCE for row in bindings)
assert [row['extra_ignored_regress_lock']for row in bindings]==[False,True]
prior_file=DEST/'memory-regexp-unicode-data-20261027.json';prior=read(prior_file)
assert prior['verified_source_commit']=='e7e51222101533e421ffae41bb0ccad78ba638ba'
assert [row['source_fingerprint']for row in bindings]==[row['source_fingerprint']for row in prior['source_bindings'][-2:]]
prior_base=ROOT/'target/memory-regexp-unicode-data-20261027-evidence'
segment_row=next(row for row in prior['retained_files']if row['path']=='data-segments.json')
assert sha(prior_base/'data-segments.json')==segment_row['sha256']
segments=read(prior_base/'data-segments.json');packages=read(BASE/'runtime-packages-unchanged.json')
assert packages['source_commit']==SOURCE and len(packages['packages'])==2
# Compare current package hashes to source-bound prior producer-owned evidence.
prior_packages={Path(row['path']).name:row for row in segments['packages']}
for row in packages['packages']:
 assert row['byte_identical'] is True and row['prior_source']==prior['verified_source_commit']
 previous=prior_packages[Path(row['path']).name]
 assert row['sha256']==previous['package_sha256'] and row['bytes']==previous['package_bytes']
phase=read(BASE/'phase-summary.json');retention=read(BASE/'ci-unscored-retention.json')
assert phase['source_commit']==SOURCE and phase['run']==RUN and phase['scored'] is False and phase['excluded_from_scored_cohorts'] is True and phase['observation_index']==16
assert len(phase['cases'])==4 and len(phase['phase_comparison'])==8
assert {(c['runtime'],c['file'])for c in phase['cases']}=={(rt,file)for rt in ['scriptw','scriptc']for file in ['integer.js','retained-objects.js']}
phases=['after_transport_drop','after_instantiate','after_execution','after_store_drop']
assert all([row['phase']for row in case['phases']]==phases for case in phase['cases'])
assert retention['source_commit']==SOURCE and retention['run']==RUN and retention['status']=='captured' and retention['phase_attribution_complete'] is True and len(retention['files'])==29
for row in retention['files']:
 path=BASE/'ci-unscored-40540496469'/row['path'];assert path.stat().st_size==row['bytes'] and sha(path)==row['sha256']
measured,rows=p.load_report(BASE/'github-40540496469/precompiled-measurements/precompiled-evidence/report.json')
assert measured['source_commit']==SOURCE and measured['source_fingerprint']==bindings[0]['source_fingerprint'] and len(rows)==17
assert phase['scored_report_sha256']==sha(BASE/'github-40540496469/precompiled-measurements/precompiled-evidence/report.json')
assert phase['diagnostic_report_sha256']==sha(BASE/'ci-unscored-40540496469/report.json')
provenance=BASE/'provenance';provenance.mkdir(exist_ok=True)
(provenance/'scored-report.json').write_bytes((BASE/'github-40540496469/precompiled-measurements/precompiled-evidence/report.json').read_bytes())
files=[]
for path in sorted(BASE.rglob('*')):
 if not path.is_file():continue
 rel=path.relative_to(BASE).as_posix();parts=PurePosixPath(rel).parts
 if parts[0].startswith('github-') or parts[0]=='mplconfig' or path.name.startswith(('preview-','publication.')):continue
 if path.suffix not in ['.py','.json','.jsonl','.stdout','.stderr','.txt','.smaps','.md','.svg'] and path.name not in ['stdout','stderr','control']:continue
 assert not path.is_symlink() and '..'not in parts and path.stat().st_size<=128*1024**2
 with path.open('rb')as stream:assert not stream.read(8).startswith((b'\x7fELF',b'MZ',b'SCRWEP',b'SCRWWA'))
 files.append(dict(path=rel,bytes=path.stat().st_size,sha256=sha(path)))
assert {('ci-unscored-40540496469/'+row['path'])for row in retention['files']}<={row['path']for row in files}
expanded=sum(row['bytes']for row in files);assert expanded<=2*1024**3
archive=DEST/(STEM+'-verification.tar.xz');target=DEST/(STEM+'.json');assert not archive.exists() and not target.exists()
with archive.open('xb')as output,lzma.LZMAFile(output,'w',filters=[dict(id=lzma.FILTER_LZMA2,preset=1,dict_size=64*1024**2)])as compressed:
 with tarfile.open(fileobj=compressed,mode='w|')as tar:
  for row in files:
   item=tarfile.TarInfo(row['path']);item.size=row['bytes'];item.mode=0o644
   with (BASE/row['path']).open('rb')as stream:tar.addfile(item,stream)
assert archive.stat().st_size<=32*1024**2
expected={row['path']:row for row in files};seen=set();total=0
with tarfile.open(archive,'r|xz')as tar:
 for member in tar:
  assert member.isfile() and member.name in expected and member.name not in seen
  row=expected[member.name];assert member.size==row['bytes']<=128*1024**2
  assert hashlib.file_digest(tar.extractfile(member),'sha256').hexdigest()==row['sha256']
  seen.add(member.name);total+=member.size;assert total<=2*1024**3
assert seen==set(expected) and total==expanded
record=dict(schema='scriptw-phase-boundaries-verification-v1',recorded_at=datetime.now(timezone.utc).isoformat(),verified_source_commit=SOURCE,measured_source_commit=SOURCE,source_bindings=dict(rows=bindings),native=native,tooling=cheap,ci_processing=processing,phase_summary=phase,runtime_packages=packages,prior_checkpoint=dict(file=prior_file.name,sha256=sha(prior_file),data_segments=segment_row,native=4876,test262_original=2365,test262_unicode=16,rerun=False),measurement=dict(run=RUN,report_sha256=phase['scored_report_sha256']),archive=dict(file=archive.name,sha256=sha(archive),bytes=archive.stat().st_size,expanded_bytes=expanded,member_count=len(files),max_member_bytes=128*1024**2,max_expanded_bytes=2*1024**3),retained_files=files,interpretation='13 Rust benchmark controls and 49 Python tooling tests passed for this method checkpoint. Prior e7 product verification is not rerun; identical compiler-input closures and both raw R packages bind it. Paused maps are unscored. This is not a memory optimization claim or a full-suite status refresh.')
target.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record['archive']))
