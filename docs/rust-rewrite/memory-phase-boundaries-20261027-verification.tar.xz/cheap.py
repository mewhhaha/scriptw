from pathlib import Path
import hashlib,json,subprocess,time
BASE=Path(__file__).resolve().parent;ROOT=BASE.parents[1];WORK=ROOT/'target/memory-phase-boundaries-20261027'
report=dict(source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=WORK,text=True).strip(),complete=False,commands=[])
plan=[('python-tooling',['python3','-B','-m','unittest','scripts.tests.test_precompiled_comparison','scripts.tests.test_tooling_benchmark_boundary','scripts.tests.test_precompiled_mapping_diagnostic','-v']),('rustfmt',['rustfmt','--edition','2021','--config','skip_children=true','--check',*subprocess.check_output(['git','diff','--name-only','54231ef4d','HEAD'],cwd=WORK,text=True).splitlines()]),('diff',['git','diff','--check'])]
plan[1]=('rustfmt',plan[1][1][:6]+[p for p in plan[1][1][6:]if p.endswith('.rs')])
def sha(p):
 with p.open('rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()
def save():(BASE/'cheap.json').write_text(json.dumps(report,indent=2)+'\n')
save()
for label,args in plan:
 print(label,'started',flush=True);row=dict(label=label,argv=args,stdout=label+'.stdout',stderr=label+'.stderr');report['commands'].append(row);save();start=time.monotonic()
 with(BASE/row['stdout']).open('xb')as out,(BASE/row['stderr']).open('xb')as err:r=subprocess.run(args,cwd=WORK,stdout=out,stderr=err,timeout=300)
 row.update(exit_code=r.returncode,seconds=time.monotonic()-start,stdout_sha256=sha(BASE/row['stdout']),stderr_sha256=sha(BASE/row['stderr']));save();print(label,'finished',r.returncode,flush=True)
 if r.returncode:print((BASE/row['stderr']).read_text()[-10000:],flush=True);raise SystemExit(r.returncode)
report['complete']=True;save()
