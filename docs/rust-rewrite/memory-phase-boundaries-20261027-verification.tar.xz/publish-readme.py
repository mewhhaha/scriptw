"""Private prose publisher; parent must publish/validate canonical scored cohort first."""
import hashlib,json,sys
from pathlib import Path
BASE=Path(__file__).resolve().parent;ROOT=BASE.parents[1];DEST=ROOT/'docs/rust-rewrite';STEM='memory-phase-boundaries-20261027'
SOURCE='38c25942b63a752ce5db46b6cb42b46ed98f9a57'
sys.path.insert(0,str(ROOT/'scripts'))
import precompiled_comparison as p

def sha(path):
 with path.open('rb')as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
record_path=DEST/(STEM+'.json');record=json.loads(record_path.read_text())
assert record['verified_source_commit']==record['measured_source_commit']==SOURCE
assert sha(DEST/record['archive']['file'])==record['archive']['sha256']
report,rows=p.load_report(DEST/'precompiled-comparison.json',DEST/'precompiled-comparison.tar.gz')
assert report['source_commit']==SOURCE and report['source_fingerprint']==record['source_bindings']['rows'][0]['source_fingerprint']
assert len(rows)==17
ratios=[row['runtimes']['scriptw']['rss_mib']/row['runtimes']['scriptc']['rss_mib']for row in rows]
selected={row['file']:row for row in rows}
lines=['**Measured 2026-10-27 on one GitHub Actions runner**, compiler `38c25942b`.',
'The [precompiled benchmark workflow](docs/rust-rewrite/contracts/precompiled-comparison.md)',
'compares Scriptw and Scriptc in the same Wasmtime executable. Compilation runs',
'in separate producer processes; measured consumers disable compilation and use',
'identical native optimization and runtime settings. Both passed the original',
'checksums on **17/17 workloads** across two rounds.',
f"Scriptw's median post-execution process RSS remains **{min(ratios):.3f}–{max(ratios):.3f}× Scriptc's**:",'',
'| Workload | Scriptw RSS | Scriptc RSS |','| --- | ---: | ---: |']
for name,label in [('integer.js','Integer'),('objects.js','Objects'),('retained-objects.js','Retained objects')]:
 row=selected[name];lines.append(f"| {label} | {row['runtimes']['scriptw']['rss_mib']:.1f} MiB | {row['runtimes']['scriptc']['rss_mib']:.1f} MiB |")
lines+=['','These are medians of 14 measured samples per runtime and workload after ten',
'checked warmups per round, with each Store still alive. RSS includes code,',
'runtime and allocator history; it is neither live JS heap nor peak memory.',
'Scriptc parity remains open. This is a measurement-method checkpoint: compiler',
'input fingerprints and both locally owned raw runtime packages match e7.',
'Cross-runner comparisons do not establish causal savings.','',
f'[Verification](docs/rust-rewrite/{STEM}.md): **13 Rust benchmark controls and',
'49 Python tooling tests passed**. The prior e7 checkpoint passed **4,876 native',
'cases and 2,381 selected original Test262 executions** (2,365 original selections',
'plus 16 disjoint Unicode executions); those suites were **not rerun** here.',
'Verification used one CPU, a 4-GiB process-tree cap, no swap and bounded module retention.','',
'The separate four-boundary map captures are **unscored**. Their warm host RX',
'gap is about 2.4–2.5 MiB, with roughly 1.5 MiB in other RX mappings; much of the',
'gap remains after Store drop. These permission/path groups do not identify',
'heap owners, peak memory or causes. Loading precedes all observations; the',
'later captures use observation 16 and include 16 prior invocations of history.','',
'[Method, source bindings and retained evidence](docs/rust-rewrite/'+STEM+'.md) ·',
'[Execution timing](docs/rust-rewrite/assets/precompiled-execution.svg) ·',
'[CI run](https://github.com/mewhhaha/scriptw/actions/runs/40540496469).','']
readme=ROOT/'README.md';old=readme.read_text();start=old.index('**Measured 2026-10-27 on one GitHub Actions runner**, compiler `e7e512221`.');end=old.index('\n## Benchmarks',start)
new=old[:start]+'\n'.join(lines)+old[end:]
assert new[:start]==old[:start] and new[new.index('\n## Benchmarks'):]==old[end:]
checkpoint=DEST/(STEM+'.md');assert not checkpoint.exists()
text=f'''# Phase-aligned memory method checkpoint

Compiler `{SOURCE}`, CI [40540496469](https://github.com/mewhhaha/scriptw/actions/runs/40540496469), 2026-10-27.

The canonical paired cohort validates all 17 workloads in two rounds with compilation in separate producers and disabled in both consumers. The companion phase captures never enter scored reports or graphs. This checkpoint adds observation controls, not a compiler memory optimization.

13 Rust benchmark-example controls and 49 Python tooling tests passed. Exact inventories, streams, hashes and local resource counters are in the [verification record]({STEM}.json) and its bounded lossless archive. Both clean/local compiler-input closures match e7, as do both locally owned raw runtime packages. The [e7 checkpoint](memory-regexp-unicode-data-20261027.md) passed 4,876 native cases, 2,365 original pinned executions and 16 disjoint Unicode executions; those product suites were not rerun here. No full pinned-suite status is updated.

Four cases (two adapters × integer/retained objects) each captured four strict nonce/sequence/index-bound phases: transport drop, instantiation, execution and Store drop. Raw map hashes, endpoint reports, executable admission checks and the analysis are retained. Observation 16 is selected after 16 earlier invocations; loading precedes all observations. The loading-to-warm difference therefore includes allocator and execution history. Diagnostic totals can include earlier barrier waits; no wait is subtracted and these timings are unscored.

Warm RX mapping differences are approximately 2.4–2.5 MiB for the exact host executable and roughly 1.5 MiB for other executable mappings. Much of the post-execution paired gap persists after Store drop. Permission/path grouping is descriptive: it does not prove heap ownership, a peak, allocation attribution or causal savings. Results from another runner are not a controlled causal comparison.

Local checks used one CPU, a 4-GiB process-tree cap, no swap and bounded retained-module caches. CI processing also records its actual resource counters. The archive excludes executables/native images and the duplicate GitHub download, preserving the 29 inert phase-evidence files and source-bound analysis.
'''
checkpoint.write_text(text);readme.write_text(new)
print(json.dumps(dict(readme_updated=True,checkpoint=checkpoint.name,source=SOURCE)))
