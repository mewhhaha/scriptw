from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,shutil,subprocess,sys,time
ROOT=Path(__file__).resolve().parents[2];BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'scripts'))
from limited_verification import require_kernel_budget,kernel_group
from native_test_protocol import parse_inventory,result_summaries
require_kernel_budget(4*1024**3);assert sorted(os.sched_getaffinity(0))==[0]
SOURCE='38c25942b63a752ce5db46b6cb42b46ed98f9a57';group=kernel_group()
def budget():return {k:(group/k).read_text().strip()for k in ['memory.max','memory.swap.max','memory.oom.group','memory.peak','memory.events']}
def sha(p):
 with p.open('rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()
def source():
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==SOURCE
 assert not subprocess.check_output(['git','diff','--binary','HEAD','--','crates','scripts','vendor','Cargo.toml','Cargo.lock'],cwd=ROOT)
source();assert not(BASE/'native.json').exists()
report=dict(source_commit=SOURCE,complete=False,started_at=datetime.now(timezone.utc).isoformat(),cpu_affinity=sorted(os.sched_getaffinity(0)),before=budget(),commands=[],scopes=[])
def save():(BASE/'native.json').write_text(json.dumps(report,indent=2)+'\n')
def run(label,args):
 source();row=dict(label=label,argv=list(map(str,args)),stdout=label+'.stdout',stderr=label+'.stderr');report['commands'].append(row);save();print(label,'started',flush=True);start=time.monotonic()
 with(BASE/row['stdout']).open('xb')as out,(BASE/row['stderr']).open('xb')as err:r=subprocess.run(row['argv'],cwd=ROOT,stdout=out,stderr=err,timeout=3600)
 row.update(exit_code=r.returncode,seconds=time.monotonic()-start,stdout_sha256=sha(BASE/row['stdout']),stderr_sha256=sha(BASE/row['stderr']));save();print(label,'finished',r.returncode,flush=True)
 if r.returncode:print((BASE/row['stderr']).read_text()[-10000:],flush=True);raise SystemExit(r.returncode)
 return(BASE/row['stdout']).read_text()
text=run('cargo-examples',['cargo','test','--locked','--offline','--release','--jobs','1','--target-dir',ROOT/'target/performance-work-20261024/build','-p','scriptw-cli','--example','compiler_precompiled_baseline','--example','runtime_precompiled','--no-run','--message-format=json'])
rows=[json.loads(line)for line in text.splitlines()];assert rows[-1]==dict(reason='build-finished',success=True)
for name in ['compiler_precompiled_baseline','runtime_precompiled']:
 producer,=[r for r in rows if r.get('reason')=='compiler-artifact'and r.get('executable')and r['target']['name']==name and r['target']['kind']==['example']and r['profile']['test']]
 folder=BASE/name;folder.mkdir();binary=folder/'tests';shutil.copy2(producer['executable'],binary);assert sha(binary)==sha(Path(producer['executable']))and binary.stat().st_nlink==1
 names=parse_inventory(run(name+'-inventory',[binary,'--list']));raw=run(name+'-tests',[binary,'--test-threads=1']);passed=[n.removesuffix(' - should panic')for n in __import__('re').findall(r'^test ([^\r\n]+) \.\.\. ok$',raw,__import__('re').M)]
 assert len(passed)==len(names)and set(passed)==set(names)and result_summaries(raw)==[('ok',str(len(names)),'0','0','0','0')]
 report['scopes'].append(dict(target=name,inventory=names,passed=len(names),executable_sha256=sha(binary),cargo_producer=producer));save()
report.update(complete=True,finished_at=datetime.now(timezone.utc).isoformat(),after=budget());save();print('native examples passed',sum(s['passed']for s in report['scopes']),flush=True)
