"""Fresh local baseline/candidate observations; separate from the Scriptc cohort."""
from datetime import datetime, timezone
import importlib.util
import json
import os
from pathlib import Path
import signal
import statistics
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parents[2]
BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'scripts'))
import precompiled_comparison as admission
from limited_verification import require_kernel_budget,kernel_group
require_kernel_budget(4*1024**3)
assert len(os.sched_getaffinity(0))==1
environment_helper=ROOT/'target/memory-packed-records-verified-20261026/campaign_identity.py'
spec=importlib.util.spec_from_file_location('ordinary_environment',environment_helper)
helper=importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
environment=helper.ordinary_environment()
products={}
for label,directory,source in [
 ('baseline',ROOT/'target/precompiled-comparison-20261026/local-smoke-integration','fc714e607c5bce6c017aa06d49dba2e3de7927d2'),
 ('candidate',BASE/'candidate-integration','b1ffc3ffd9f62d990c6f88058c4684018ba3a776')]:
 summary=admission._json((directory/'summary.json').read_bytes())
 assert summary['complete'] and summary['source_commit']==source
 product=summary['products']['compiler_precompiled_baseline']
 host=Path(product['path'])
 assert host.is_file() and not host.is_symlink() and host.stat().st_nlink==1
 assert admission.digest(host)==product['sha256']
 identity=summary['shared_identity']
 authority=dict(source_commit=source,source_fingerprint=identity['source_fingerprint'],
   source_fingerprint_scheme=identity['compiler_identity_scheme'],shared_configuration=identity['shared_configuration'],
   tools=dict(consumer=dict(sha256=product['sha256'])))
 admission._identity(identity,authority)
 producer=admission._json((directory/'shared-images/producer.json').read_bytes())
 admission._identity(producer,authority)
 products[label]=dict(source_commit=source,host=str(host),sha256=product['sha256'],authority=authority,
  integration_receipt=str(directory/'summary.json'),integration_sha256=admission.digest(directory/'summary.json'),
  producer_path=str(directory/'shared-images/producer.json'),producer_sha256=admission.digest(directory/'shared-images/producer.json'),
  images=str(directory/'shared-images'),producer=producer)
assert products['baseline']['authority']['shared_configuration']==products['candidate']['authority']['shared_configuration']
manifest_path=ROOT/'crates/scriptw-cli/tests/fixtures/v8_execution_hotpaths/manifest.json'
manifest=admission._json(manifest_path.read_bytes())
cases=manifest['execution']
assert len(cases)==17
output=BASE/'paired-local'
output.mkdir(exist_ok=False)
(output/'logs').mkdir()
group=kernel_group()
def budget():
 return {k:(group/k).read_text().strip() for k in ('memory.max','memory.swap.max','memory.oom.group','memory.peak','memory.events')}
def stamp(): return datetime.now(timezone.utc).isoformat()
report=dict(schema='scriptw-precompiled-local-paired-v1',complete=False,started_at=stamp(),
 samples=7,warmups=10,rounds=2,workloads=cases,manifest_sha256=admission.digest(manifest_path),
 products=products,observations=[],before=budget(),cpu_affinity=sorted(os.sched_getaffinity(0)),
 scope='Fresh same-machine before/after Scriptw consumers; not the two-runtime Scriptc publication; no instrumentation or compilation in consumers.')
def save(): (output/'report.json').write_text(json.dumps(report,indent=2)+'\n')
save()
for round_index in range(2):
 for case_index,case in enumerate(cases if round_index==0 else list(reversed(cases))):
  labels=('baseline','candidate') if (case_index+round_index)%2==0 else ('candidate','baseline')
  for label in labels:
   product=products[label]
   row=next(x for x in product['producer']['cases'] if x['file']==case['file'])
   image=Path(product['images'])/row['image']
   metadata=admission.image_metadata(image.read_bytes(),'scriptw',product['authority']['source_fingerprint'])
   assert row['image_sha256']==metadata['sha256'] and row['stdout']==case['stdout']
   assert row['source_sha256']==admission.digest(ROOT/'crates/scriptw-cli/tests/fixtures/v8_execution_hotpaths'/case['file'])
   name=f"{round_index}-{label}-{case['file']}"
   argv=[product['host'],'execute-scriptw',str(image),case['stdout'],'7','10']
   event=dict(round=round_index,file=case['file'],product=label,command=argv,
     executable_sha256=product['sha256'],image=metadata,started_at=stamp(),
     stdout='logs/'+name+'.stdout',stderr='logs/'+name+'.stderr')
   report['observations'].append(event);save()
   env=dict(environment,SCRIPTW_CACHE_DIR=str(output/(name+'-cache')))
   started=time.monotonic()
   with (output/event['stdout']).open('xb') as out,(output/event['stderr']).open('xb') as err:
    process=subprocess.Popen(argv,cwd=ROOT,env=env,stdout=out,stderr=err,start_new_session=True)
    try: code=process.wait(timeout=120)
    except BaseException:
     if process.poll() is None: os.killpg(process.pid,signal.SIGKILL)
     process.wait();raise
   event.update(returncode=code,finished_at=stamp(),seconds=time.monotonic()-started,
     stdout_sha256=admission.digest(output/event['stdout']),stderr_sha256=admission.digest(output/event['stderr']))
   save()
   assert code==0 and not (output/event['stderr']).read_bytes(),name+' failed; raw streams retained'
   raw=admission._json((output/event['stdout']).read_bytes())
   values,matched=admission._consumer(raw,product['authority'],metadata,case,'scriptw')
   assert matched and len(values)==17
   event['validated']=True;save()
   print(name,'checked',flush=True)
table=[]
for case in cases:
 item=dict(file=case['file'],products={})
 for label in products:
  events=[e for e in report['observations'] if e['file']==case['file'] and e['product']==label]
  assert len(events)==2 and all(e['validated'] for e in events)
  raw=[admission._json((output/e['stdout']).read_bytes()) for e in events]
  measured=[x for r in raw for x in r['observations'][10:]]
  item['products'][label]=dict(samples=len(measured),
   execution_ms=statistics.median(x['phases_ns']['execution'] for x in measured)/1e6,
   rss_mib=statistics.median(x['process_snapshots']['after_execution']['rss_bytes'] for x in measured)/2**20,
   pss_mib=statistics.median(x['process_snapshots']['after_execution']['pss_bytes'] for x in measured)/2**20,
   private_dirty_mib=statistics.median(x['process_snapshots']['after_execution']['private_dirty_bytes'] for x in measured)/2**20,
   native_load_sampled_max_rss_mib=[r['native_load_process_memory']['maximum_rss_bytes']/2**20 for r in raw])
 table.append(item)
for p in products.values(): assert admission.digest(p['host'])==p['sha256']
report.update(complete=True,finished_at=stamp(),after=budget(),table=table)
save()
print(json.dumps(table,indent=2),flush=True)
