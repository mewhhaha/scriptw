"""Instrumented attribution of our already-produced trusted local baseline.

No observation contributes to a benchmark or conformance total. Periodic smaps
reads are not synchronized with guest boundaries and invalidate timing scores.
"""
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'scripts'))
from limited_verification import require_kernel_budget
from process_memory_maps import parse_smaps, read_smaps

require_kernel_budget(4 * 1024**3)
assert len(os.sched_getaffinity(0)) == 1
previous = ROOT / 'target/precompiled-comparison-20261026/local-smoke-integration'
receipt = json.loads((previous / 'summary.json').read_text())
product = receipt['products']['compiler_precompiled_baseline']
host = Path(product['path'])
with host.open('rb') as stream:
    assert hashlib.file_digest(stream, 'sha256').hexdigest() == product['sha256']
assert receipt['complete'] and receipt['source_commit'] == 'fc714e607c5bce6c017aa06d49dba2e3de7927d2'
producer = json.loads((previous / 'shared-images/producer.json').read_text())
manifest = json.loads((ROOT / 'crates/scriptw-cli/tests/fixtures/v8_execution_hotpaths/manifest.json').read_text())
output = Path(__file__).resolve().parent / 'baseline-maps'
output.mkdir(exist_ok=False)
result = {'complete': False, 'source_commit': receipt['source_commit'], 'executable_sha256': product['sha256'],
          'instrumented': True, 'excluded_from_scored_cohorts': True,
          'scope': 'unsynchronized periodic process smaps; attribution only; no valid execution timing', 'cases': []}
for name in ('integer.js', 'retained-objects.js'):
    case = next(c for c in manifest['execution'] if c['file'] == name)
    source_image = next(c for c in producer['cases'] if c['file'] == name)
    image = previous / 'shared-images' / source_image['image']
    assert hashlib.sha256(image.read_bytes()).hexdigest() == source_image['image_sha256']
    directory = output / name
    directory.mkdir()
    command = [str(host), 'execute-scriptw', str(image), case['stdout'], '7', '10']
    observations = []
    retained_bytes = 0
    started = time.monotonic()
    with (directory / 'stdout.json').open('xb') as stdout, (directory / 'stderr').open('xb') as stderr:
        child = subprocess.Popen(command, cwd=ROOT, stdout=stdout, stderr=stderr, start_new_session=True)
        try:
            while child.poll() is None:
                assert time.monotonic() - started < 120
                if len(observations) < 128 and retained_bytes < 32 * 1024**2:
                    try:
                        executable = Path(f'/proc/{child.pid}/exe').stat()
                        expected = host.stat()
                        if (executable.st_dev, executable.st_ino) == (expected.st_dev, expected.st_ino):
                            raw = read_smaps(child.pid)
                            parsed = parse_smaps(raw)
                            path = directory / f'{len(observations):03}.smaps'
                            path.write_text(raw)
                            retained_bytes += len(raw.encode())
                            observations.append({'elapsed_seconds': time.monotonic() - started,
                                'raw': path.name, 'raw_sha256': hashlib.sha256(raw.encode()).hexdigest(), **parsed})
                    except (FileNotFoundError, ProcessLookupError):
                        pass
                time.sleep(.03)
            assert child.returncode == 0
        finally:
            if child.poll() is None:
                os.killpg(child.pid, signal.SIGKILL)
                child.wait()
    raw = json.loads((directory / 'stdout.json').read_text())
    assert not (directory / 'stderr').read_bytes() and raw['source_commit'] == receipt['source_commit']
    assert raw['compiler_enabled'] is False and len(raw['observations']) == 17
    assert all(x['stdout'] == case['stdout'] and x['completion'] == 'normal' for x in raw['observations'])
    result['cases'].append({'file': name, 'command': command, 'exit_code': child.returncode,
                            'observations': observations})
    print(name, 'snapshots', len(observations), flush=True)
result['complete'] = True
(output / 'report.json').write_text(json.dumps(result, indent=2) + '\n')
for case in result['cases']:
    peak = max(case['observations'], key=lambda x: x['totals']['rss_bytes'])
    latest = case['observations'][-1]
    print(case['file'], 'max_sampled_RSS_MiB', peak['totals']['rss_bytes']/2**20,
          'last_sample_RSS_MiB', latest['totals']['rss_bytes']/2**20)
    for mapping in sorted(latest['mappings'], key=lambda x: x['rss_bytes'], reverse=True)[:8]:
        print(mapping['permissions'], mapping['path'], 'offset', hex(mapping['offset']),
              'RSS_MiB', mapping['rss_bytes']/2**20, 'private_dirty_MiB', mapping['private_dirty_bytes']/2**20)
