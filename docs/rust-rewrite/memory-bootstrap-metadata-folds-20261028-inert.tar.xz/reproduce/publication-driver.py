"""Prepare an inert candidate only; never build, execute workloads, or publish.

Run under the reviewed 1 GiB/no-swap/CPU0 limited-verification wrapper after
both final receipt hashes have been inspected. Output is exclusive-create.
The earlier failed compilation is retained but contributes no native passes.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import lzma
import os
from pathlib import Path
import re
import stat
import subprocess
import sys
import tarfile

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
SOURCE = 'bd564df792204753db1636c787f450e7dd083a03'
FEATURE = '4bd3a1bbde2433ee2a3d76f6fccb4a223bec56f0'
MEASURED = '7f9bacff03c454dd505a0047c9439bee253028db'
FP = 'dd3b016c70aa592eb1792f9558a0fc825854aefaf5f7f36a7397212ff1eff69d'
LOCAL_FP = '851d76dd733ca8f43803fcecb4db8165359e6390582bd6bf0f5d6ebb75757cc3'
PROOF = BASE / 'source-bindings-repaired-local-probe.json'
PROOF_SHA = '94e6a682865629d7e98ab5c4ff82f97107fdd15f1a7b3e3c9ac70b42f3c27d73'
FAILED_SHA = 'd1d157aa62fb1606342c7c82d254a7f5d67d34735bf524b6d1b3e2841976c60d'
CHEAP_SHA = 'eb59e9fe2981de19a728e1eaf923bfa9fb2dc50574d2adddf3c8684c2e06de53'
DRIVER_SHA = 'dc1ba048c7d864a242a6efb3ab529b30050bc4b9db419d11cf72efbe44326d85'
BASELINE = ROOT / 'target/memory-ordered-bootstrap-20261027-evidence/native-main-a036f1144/report.json'
BASELINE_SHA = '747bad48ffabcf859ca25a2b6cb81069b3c08b7f53bf53d7c00bc56466f76d73'
BASELINE_SOURCE = 'a036f1144ea3d3cf502d888b8a07f442837a857f'
NATIVE = BASE / 'native-bd564df79'
FAILED = BASE / 'native-4bd3a1bbd'
CI = BASE / 'ci-40630427913-validated'
SCORED = BASE / 'github-40630427913-scored/precompiled-evidence'
OUT = BASE / 'publication-candidate-bd564df79'
STEM = 'memory-bootstrap-metadata-folds-20261028'
RUN = 40630427913
MIB = 1024**2
MAX_MEMBER, MAX_EXPANDED, MAX_COMPRESSED, MAX_FILES = 128*MIB, 512*MIB, 64*MIB, 4096
REPAIR = 'crates/scriptw-aot-wasm/src/tests/intrinsic_accessor_allocation.rs'
PLAN = [
    ('scriptw-aot-wasm', 'scriptw_aot_wasm', 'lib'),
    ('scriptw-engine', 'aot_realm_modules', 'test'),
    ('scriptw-engine', 'scriptw_engine', 'lib'),
    ('scriptw-aot-wasm', 'emission', 'test'),
    ('scriptw-engine', 'aot_regexp', 'test'),
    ('scriptw-engine', 'aot_gc_entries', 'test'),
    ('scriptw-aot-wasm', 'modules_realms', 'test'),
    ('scriptw-aot-wasm', 'intl_temporal', 'test'),
    ('scriptw-aot-wasm', 'runtime_link', 'test'),
    ('scriptw-aot-wasm', 'structure_builtins', 'test'),
    ('scriptw-engine', 'structure', 'test'),
    ('scriptw-engine', 'aot_language', 'test'),
    ('scriptw-engine', 'aot_generators', 'test'),
    ('scriptw-engine', 'aot_intl', 'test'),
    ('scriptw-engine', 'aot_builtins', 'test'),
    ('scriptw-engine', 'aot_temporal', 'test'),
    ('scriptw-engine', 'aot_async', 'test'),
    ('scriptw-aot-wasm', 'structure_language', 'test'),
    ('scriptw-aot-wasm', 'structure_async', 'test'),
]
FOCUS = {
    ('scriptw-aot-wasm', 'scriptw_aot_wasm', 'lib'): {
        'tests::bootstrap_compact_metadata::native_bootstrap_omits_empty_metadata_but_retains_thrower_and_source_publication',
        'tests::intrinsic_accessor_allocation::every_intl_getter_uses_the_checked_shared_accessor_allocation_tail',
        'tests::intrinsic_accessor_allocation::eager_accessor_allocation_shares_the_actual_typed_context_and_function_tail',
    },
    ('scriptw-engine', 'aot_intl', 'test'): {
        'aot_intl_bound_format_realm::eager_intl_getters_keep_descriptors_identity_and_defining_realm_across_gc',
    },
}
sys.path.insert(0, str(ROOT / 'scripts'))
import precompiled_comparison as p
from limited_verification import require_kernel_budget, kernel_group
from native_test_protocol import parse_inventory, result_summaries


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def regular(path, cap=MAX_MEMBER):
    path = Path(path)
    info = path.lstat()
    assert path.is_absolute() and path.resolve(strict=True) == path
    assert stat.S_ISREG(info.st_mode) and not path.is_symlink() and info.st_size <= cap
    return info


def read(path, cap=16*MIB):
    regular(path, cap)
    return p._json(Path(path).read_bytes())


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)


def root_state():
    assert not git('status', '--porcelain', '--untracked-files=no')
    return git('rev-parse', 'HEAD').decode().strip()


def budget():
    group = kernel_group()
    return {key: (group/key).read_text().strip() for key in
            ('memory.max', 'memory.swap.max', 'memory.oom.group', 'memory.peak', 'memory.events')}


def resources(value, maximum=4*1024**3):
    assert value['cpu_affinity'] == [0]
    events = []
    for row in (value['before'], value['after']):
        assert 0 < int(row['memory.max']) <= maximum
        assert row['memory.swap.max'] == '0' and row['memory.oom.group'] == '1'
        assert 0 <= int(row['memory.peak']) <= int(row['memory.max'])
        events.append(dict(line.split() for line in row['memory.events'].splitlines()))
    assert all(events[0][key] == events[1][key] == '0' for key in ('oom', 'oom_kill', 'oom_group_kill'))


def streams(directory, commands, failed=False):
    assert len({row['label'] for row in commands}) == len(commands)
    for row in commands:
        assert (row['exit_code'] == 101 if failed else row['exit_code'] == 0)
        assert not any(row.get(key, False) for key in ('timed_out', 'output_limit_exceeded', 'pipe_cleanup_incomplete'))
        for channel in ('stdout', 'stderr'):
            name = row.get(channel, row['label']+'.'+channel)
            assert p.safe_name(name) == row['label']+'.'+channel
            path = directory/name
            info = regular(path)
            assert sha(path) == row[channel+'_sha256']
            if channel+'_bytes' in row:
                assert info.st_size == row[channel+'_bytes']


def source_admission():
    assert sha(PROOF) == PROOF_SHA
    proof = read(PROOF)
    assert (proof['original'], proof['repaired'], proof['probe']) == (FEATURE, SOURCE, MEASURED)
    assert proof['test_only_repair'] == REPAIR and proof['computed_compiler_inputs_equal'] is True
    assert len(proof['rows']) == 6
    resources(proof, 256*MIB)
    for revision in (FEATURE, SOURCE, MEASURED):
        for ignored, expected in ((False, FP), (True, LOCAL_FP)):
            rows = [row for row in proof['rows'] if row['revision'] == revision and row['extra_ignored_regress_lock'] is ignored]
            assert len(rows) == 1 and rows[0]['source_fingerprint'] == expected
            assert (rows[0]['files'], rows[0]['bytes']) == ((2926, 161576665) if ignored else (2925, 161575434))
    assert git('diff', '--name-only', FEATURE, SOURCE).decode().splitlines() == [REPAIR]
    assert git('diff', '--numstat', FEATURE, SOURCE).decode().splitlines() == ['1\t1\t'+REPAIR]
    assert git('diff', '--name-only', FEATURE, MEASURED).decode().splitlines() == ['.github/workflows/precompiled-benchmarks.yaml']
    owner = git('show', SOURCE+':crates/scriptw-engine/compiler_fingerprint.rs').decode()
    excluded = re.findall(r'^\s*"([^"]+)",', owner.split('const TEST_ONLY_INPUTS: &[&str] = &[', 1)[1].split('];', 1)[0], re.M)
    assert any(REPAIR == item or REPAIR.startswith(item+'/') for item in excluded)
    for name in ('precompiled_comparison.py', 'benchmark_module_images.py', 'benchmark_module_sections.py',
                 'diagnose-precompiled-mappings.py', 'native_test_protocol.py', 'limited_verification.py'):
        path = ROOT/'scripts'/name
        regular(path)
        assert path.read_bytes() == git('show', FEATURE+':scripts/'+name) == git('show', MEASURED+':scripts/'+name)
    for revision in (FEATURE, SOURCE, MEASURED):
        assert re.findall(rb'const LAYOUT_VERSION: u32 = (\d+);', git('show', revision+':crates/scriptw-aot-wasm/src/runtime_artifact.rs')) == [b'30']
    return proof


def native_admission(native):
    assert native['schema'] == 'scriptw-bootstrap-metadata-folds-native-verification-v1'
    assert native['complete'] is True and native['source_commit'] == native['reviewed_source_commit'] == SOURCE
    assert native['features'] == [] and native['predecessor_binary_reuse'] is False
    assert [(row['package'], row['target'], row['kind']) for row in native['plan']] == PLAN
    assert [(row['package'], row['target'], row['kind']) for row in native['scopes']] == PLAN
    assert len(native['scopes']) == 19 and native['driver_sha256'] == DRIVER_SHA
    assert sha(BASE/'native-bootstrap-metadata-folds-r1.py') == DRIVER_SHA
    assert native['expected_native_inventory_total'] == native['observed_native_inventory_total'] == 4906
    assert native['expected_native_inventory_total_matches'] is True and native['added_native_ids'] == 12
    assert native['passed_disjoint_scopes'] == native['executed_disjoint_passes'] == 4906
    assert native['inherited_disjoint_passes'] == native['repeated_native_test_ids'] == 0
    assert native['focused_complete'] is True and native['focused_passed'] == native['focused_passes_included'] == 4
    assert native['broad_remainder_passes'] == 4902
    resources(native)
    streams(NATIVE, native['commands'])
    assert sha(BASELINE) == BASELINE_SHA
    baseline = read(BASELINE)
    assert baseline['complete'] is True and baseline['source_commit'] == BASELINE_SOURCE and baseline['passed_disjoint_scopes'] == 4894
    old = {(row['package'], row['target'], row['kind']): row for row in baseline['scopes']}
    assert set(old) == set(PLAN)
    assert native['baseline'] == dict(path=str(BASELINE), sha256=BASELINE_SHA, source_commit=BASELINE_SOURCE,
                                     complete=True, passed_disjoint_scopes=4894, inherited_passes=0)
    checkout = Path(native['source_checkout'])
    assert checkout == ROOT/'target/memory-calendar-rows-20261028'
    build = ROOT/'target/performance-work-20261024/build'
    assert native['build_directory'] == str(build)
    scopes = {str(NATIVE/row['binary']): row for row in native['scopes']}
    observed = {name: [] for name in scopes}
    command_focus = []
    expected_producers = [row['cargo_producer'] for row in native['scopes']]
    cargo_rows = []
    # Streaming the potentially large Cargo JSON log bounds parser retention.
    with (NATIVE/'cargo-native.stdout').open('rb') as stream:
        for line in stream:
            assert len(line) <= 16*MIB
            row = p._json(line)
            if row.get('reason') == 'build-finished':
                cargo_rows.append(row)
            elif row.get('reason') == 'compiler-artifact' and row.get('executable') and row['profile']['test']:
                if any(row['package_id'].startswith('path+file://'+str(checkout/'crates'/package)+'#') for package in ('scriptw-aot-wasm', 'scriptw-engine')):
                    cargo_rows.append(row)
    assert cargo_rows[-1] == dict(reason='build-finished', success=True)
    assert [row for row in cargo_rows if row.get('reason') == 'build-finished'] == [dict(reason='build-finished', success=True)]
    assert len(cargo_rows) == 20 and all(cargo_rows.count(row) == 1 for row in expected_producers)
    cargo_commands = [row for row in native['commands'] if row['label'] == 'cargo-native']
    assert len(cargo_commands) == 1 and native['commands'][0] is cargo_commands[0]
    cargo = cargo_commands[0]['command']
    assert cargo[:2] == ['cargo', 'test'] and cargo[-3:] == ['--no-default-features', '--no-run', '--message-format=json']
    assert '--locked' in cargo and '--offline' in cargo and '--release' in cargo
    assert cargo[cargo.index('--jobs')+1] == '1' and cargo[cargo.index('--target-dir')+1] == str(build)
    saw_broad = False
    for command in native['commands'][1:]:
        argv = command['command']
        assert argv[0] in scopes
        scope = scopes[argv[0]]
        key = scope['package'], scope['target'], scope['kind']
        assert command['cwd'] == str(checkout/'crates'/scope['package'])
        if 'expected_test_ids' not in command:
            assert command['label'] == scope['package']+'-'+scope['target']+'-inventory'
            assert argv[1:] == ['--list', '--color=never']
            assert parse_inventory((NATIVE/command['stdout']).read_text()) == scope['inventory']
            continue
        ids = command['expected_test_ids']
        assert argv[1:5] == ['--exact', '--include-ignored', '--test-threads=1', '--color=never'] and argv[5:] == ids
        assert ids and len(ids) == len(set(ids)) and set(ids) <= set(scope['inventory'])
        text = (NATIVE/command['stdout']).read_text()
        passed = [name.removesuffix(' - should panic') for name in re.findall(r'^test ([^\r\n]+) \.\.\. ok$', text, re.M)]
        assert len(passed) == len(set(passed)) == len(ids) and set(passed) == set(ids)
        summaries = [('ok', str(len(ids)), '0', '0', '0', str(len(scope['inventory'])-len(ids)))]
        assert result_summaries(text) == summaries
        assert command['reported_passing_test_ids'] == passed and command['reported_result_summaries'] == [list(row) for row in summaries]
        assert not set(ids).intersection(observed[argv[0]])
        observed[argv[0]] += ids
        if command['label'].endswith('-focused'):
            assert not saw_broad and set(ids) == FOCUS[key]
            command_focus += [(key, name) for name in ids]
        else:
            assert '-part-' in command['label']
            saw_broad = True
            if scope['target'] in ('scriptw_engine', 'aot_gc_entries'):
                assert len(ids) <= 8
    assert len(command_focus) == 4 and set(command_focus) == {(key, name) for key, names in FOCUS.items() for name in names}
    for scope in native['scopes']:
        key = scope['package'], scope['target'], scope['kind']
        assert scope['binary'] == scope['package']+'-'+scope['target']+'/tests'
        assert re.fullmatch('[0-9a-f]{64}', scope['executable_sha256'])
        producer = scope['cargo_producer']
        crate = checkout/'crates'/scope['package']
        assert producer['package_id'].startswith('path+file://'+str(crate)+'#')
        assert producer['manifest_path'] == str(crate/'Cargo.toml')
        assert producer['target']['name'] == scope['target'] and producer['target']['kind'] == [scope['kind']]
        expected_src = crate/Path(old[key]['cargo_producer']['target']['src_path']).relative_to(ROOT/'crates'/scope['package'])
        assert producer['target']['src_path'] == str(expected_src)
        assert producer['features'] == [] and producer['profile']['test'] is True and producer['profile']['opt_level'] == '3'
        assert Path(producer['executable']).is_relative_to(build)
        inventory = scope['inventory']
        assert scope['complete'] is True and len(inventory) == len(set(inventory)) == scope['passed']
        assert set(old[key]['inventory']) <= set(inventory) and scope['removed_test_ids'] == []
        assert scope['baseline_inventory_count'] == len(old[key]['inventory'])
        assert scope['added_test_ids'] == sorted(set(inventory)-set(old[key]['inventory']))
        assert len(observed[str(NATIVE/scope['binary'])]) == len(inventory)
        assert set(observed[str(NATIVE/scope['binary'])]) == set(inventory) == set(scope['passed_test_ids'])
        assert len(scope['passed_test_ids']) == len(set(scope['passed_test_ids']))
        assert set(scope['focused_test_ids']) == FOCUS.get(key, set())
        assert not set(scope['focused_test_ids']).intersection(scope['broad_test_ids'])
        assert set(scope['focused_test_ids']) | set(scope['broad_test_ids']) == set(inventory)
        inventories = [row for row in native['commands'] if row['label'] == scope['package']+'-'+scope['target']+'-inventory']
        assert len(inventories) == 1
    assert sum(row['passed'] for row in native['scopes']) == 4906
    assert next(row['passed'] for row in native['scopes'] if row['target'] == 'scriptw_engine') == 1056
    assert next(row['passed'] for row in native['scopes'] if row['target'] == 'scriptw_aot_wasm') == 514
    return dict(full_scopes=19,full_scope_passes=4906,fresh_executions=4906,inherited_passes=0,
                focused_included_once=4,broad_remainder=4902,full_engine_library=1056,aot_library=514,
                baseline_inventory=4894,added_ids=12,original_js_test262_executions=0)


def cheap_admission():
    assert sha(BASE/'cheap/report.json') == CHEAP_SHA
    cheap = read(BASE/'cheap/report.json')
    assert cheap['complete'] is True
    resources(cheap, 1024**3)
    streams(BASE/'cheap', cheap['commands'])
    assert [row['label'] for row in cheap['commands']] == ['guard-mutations','rustfmt','source-guards','immutable-pool','source-profile','identities','retired-js','diff']
    assert sha(BASE/'cheap.py') == cheap['driver_sha256']
    for name, expected in cheap['source_files'].items():
        assert hashlib.sha256(git('show', FEATURE+':'+name)).hexdigest() == expected
    summary = result_summaries((BASE/'cheap/source-guards.stdout').read_text())
    assert [row[:5] for row in summary] == [('ok','143','0','0','0'), ('ok','135','0','0','0')]
    mutation = (BASE/'cheap/guard-mutations.stderr').read_text()
    assert re.findall(r'Ran (\d+) tests?', mutation) == ['15'] and re.search(r'^OK$', mutation, re.M)
    identities = (BASE/'cheap/identities.stdout').read_text().splitlines()
    assert len(identities) == 15 and all(line.startswith('PASS ') for line in identities)
    return cheap


def failure_admission():
    assert sha(FAILED/'report.json') == FAILED_SHA
    failed = read(FAILED/'report.json')
    assert failed['complete'] is False and failed['source_commit'] == FEATURE
    assert failed['scopes'] == [] and len(failed['commands']) == 1 and failed['commands'][0]['label'] == 'cargo-native'
    assert failed['error'] == 'cargo-native failed; original streams retained'
    resources(failed)
    streams(FAILED, failed['commands'], failed=True)
    assert failed['driver_sha256'] == sha(BASE/'native-bootstrap-metadata-folds.py')
    assert not failed.get('passed_disjoint_scopes')
    return failed


def archive(files):
    expanded = sum(row['bytes'] for row in files.values())
    assert expanded <= MAX_EXPANDED and 0 < len(files) <= MAX_FILES
    path = OUT/(STEM+'-inert.tar.xz')
    with path.open('xb') as raw, lzma.LZMAFile(raw, 'w', filters=[dict(id=lzma.FILTER_LZMA2,preset=1,dict_size=16*MIB)]) as compressed:
        with tarfile.open(fileobj=compressed, mode='w|') as bundle:
            for name, row in sorted(files.items()):
                member = tarfile.TarInfo(name)
                member.size, member.mode = row['bytes'], 0o644
                with row['source'].open('rb') as stream:
                    bundle.addfile(member, stream)
    assert path.stat().st_size <= MAX_COMPRESSED
    seen, total = set(), 0
    with tarfile.open(path, 'r|xz') as bundle:
        for member in bundle:
            assert member.isfile() and member.name in files and member.name not in seen
            row = files[member.name]
            assert member.size == row['bytes'] <= MAX_MEMBER
            total += member.size
            assert total <= MAX_EXPANDED
            with bundle.extractfile(member) as stream:
                assert hashlib.file_digest(stream,'sha256').hexdigest() == row['sha256']
            seen.add(member.name)
    assert seen == set(files) and total == expanded
    return dict(file=path.name,sha256=sha(path),bytes=path.stat().st_size,expanded_bytes=expanded,
                member_count=len(files),max_member_bytes=MAX_MEMBER,max_expanded_bytes=MAX_EXPANDED,
                max_compressed_bytes=MAX_COMPRESSED,max_members=MAX_FILES,roundtrip_sha256_verified=True,
                native_payloads_retained=False,members=[dict(path=name,bytes=row['bytes'],sha256=row['sha256']) for name,row in sorted(files.items())])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--native-report-sha256', required=True)
    parser.add_argument('--ci-report-sha256', required=True)
    args = parser.parse_args()
    assert __debug__ and all(re.fullmatch('[0-9a-f]{64}', value) for value in vars(args).values())
    require_kernel_budget(1024**3)
    assert sorted(os.sched_getaffinity(0)) == [0] and not OUT.exists()
    # Admission of both completed immutable receipts precedes candidate writes.
    assert sha(NATIVE/'report.json') == args.native_report_sha256
    assert sha(CI/'report.json') == args.ci_report_sha256
    native, ci = read(NATIVE/'report.json'), read(CI/'report.json')
    assert native['complete'] is ci['complete'] is True
    initial = root_state()
    processing = dict(complete=False,started_at=datetime.now(timezone.utc).isoformat(),cpu_affinity=[0],before=budget(),
                      driver=dict(path=str(Path(__file__).resolve()),sha256=sha(__file__)),processing_checkout=initial,
                      scope='Private inert candidate only. No compilation, native loading, workloads, source edits, publication or status refresh.')
    OUT.mkdir()
    try:
        proof = source_admission()
        coverage = native_admission(native)
        cheap, failed = cheap_admission(), failure_admission()
        assert ci['schema'] == 'scriptw-bootstrap-metadata-folds-ci-validation-v1'
        assert ci['source_commit'] == MEASURED and ci['feature_source_commit'] == FEATURE
        assert ci['source_fingerprint'] == FP and ci['run'] == RUN
        assert ci['driver_sha256'] == sha(BASE/'validate-ci-40630427913-reviewed.py')
        resources(ci, 1024**3)
        assert ci['scored_admitted'] is ci['scored_all_attempts_ok'] is True
        assert ci['scored_attempts'] == 68 and ci['scored_workloads'] == 17
        assert ci['native_controls']['status'] == 'validated' and ci['native_controls']['passed'] == 6
        controls = {
            'embedding::benchmark_module_images::sections::tests::malformed_headers_extended_counts_and_table_extents_are_rejected',
            'embedding::benchmark_module_images::sections::tests::name_budget_is_aggregate_even_for_omitted_logical_sections',
            'embedding::benchmark_module_images::sections::tests::names_require_unique_bounded_terminated_utf8_and_in_table_offsets',
            'embedding::benchmark_module_images::sections::tests::relocatable_no_program_headers_yields_only_exact_file_backed_metadata',
            'embedding::benchmark_module_images::sections::tests::section_arithmetic_overlap_nobits_and_text_anchors_fail_closed',
            'embedding::tests::benchmark_module_images::diagnostic_images_match_actual_program_runtime_and_survive_store_drop',
        }
        assert len(ci['native_controls']['test_ids']) == 6 and set(ci['native_controls']['test_ids']) == controls
        control_out = BASE/'github-40630427913-scored/module-sections-native.stdout'
        control_err = BASE/'github-40630427913-scored/module-sections-native.stderr'
        regular(control_out,32*MIB); regular(control_err,32*MIB)
        assert sha(control_out) == ci['native_controls']['stdout_sha256'] and sha(control_err) == ci['native_controls']['stderr_sha256']
        control_text = control_out.read_text()
        actual_controls = re.findall(r'^test ([^\r\n]+) \.\.\. ok$',control_text,re.M)
        assert len(actual_controls) == len(set(actual_controls)) == 6 and set(actual_controls) == controls
        assert len(result_summaries(control_text)) == 1 and result_summaries(control_text)[0][:5] == ('ok','6','0','0','0')
        assert ci['diagnostic_complete'] is True and ci['diagnostic']['status'] == 'validated'
        cases = ci['diagnostic']['cases']
        assert len(cases) == 4 and {(row['runtime'],row['file']) for row in cases} == {(runtime,name) for runtime in ('scriptw','scriptc') for name in ('integer.js','retained-objects.js')}
        assert len(ci['runtime_sections']) == 2
        assert ci['runtime_identity']['layout'] == 30
        layout_source = CI/'runtime-artifact-layout-source.rs'
        regular(layout_source)
        assert sha(layout_source) == ci['runtime_identity']['layout_source_sha256']
        assert layout_source.read_bytes() == git('show', MEASURED+':crates/scriptw-aot-wasm/src/runtime_artifact.rs')
        campaign, table = p.load_report(SCORED/'report.json')
        assert campaign['source_commit'] == MEASURED and campaign['source_fingerprint'] == FP and table == ci['scored_table']
        assert campaign['tools']['consumer']['cargo_producer']['features'] == ['benchmark-module-images']
        assert len(campaign['attempts']) == 68 and len(table) == 17 and all(row['status'] == 'ok' for row in campaign['attempts'])
        keys = {row['image']['runtime_key'] for row in campaign['attempts'] if row['runtime'] == 'scriptw'}
        assert len(keys) == 1 and sorted(keys) == ci['runtime_identity']['runtime_keys']
        run = read(BASE/'github-run-40630427913-completed.json')
        assert run['databaseId'] == RUN and run['headSha'] == MEASURED and run['status'] == 'completed' and run['conclusion'] == 'success'
        assert len(run['jobs']) == 1 and run['jobs'][0]['name'] == 'measure' and run['jobs'][0]['conclusion'] == 'success'
        for name in ('Verify and build the shared host','Measure both compiler-free consumers','Observe unscored consumer mappings','Retain all raw observations and failures'):
            steps = [step for job in run['jobs'] for step in job['steps'] if step['name'] == name]
            assert len(steps) == 1 and steps[0]['conclusion'] == 'success'
        selected = {row['file']:{runtime:{key:values[key] for key in ('ms','rss_mib')} for runtime,values in row['runtimes'].items()} for row in table if row['file'] in ('integer.js','objects.js','retained-objects.js')}
        ratios = [row['runtimes']['scriptw']['rss_mib']/row['runtimes']['scriptc']['rss_mib'] for row in table]
        charts = {}
        for metric in p.CHARTS:
            svg = OUT/('preview-'+str(RUN)+'-'+metric+'.svg')
            png = OUT/('preview-'+str(RUN)+'-'+metric+'.png')
            assert not svg.exists() and not png.exists()
            raw = p.render(campaign, table, metric, png)
            with svg.open('xb') as stream:
                stream.write(raw)
            charts[metric] = dict(svg=svg.name,svg_sha256=sha(svg),png=png.name,png_sha256=sha(png))
        files, excluded = {}, []
        def add(name, path, expected=None):
            path = Path(path)
            assert name not in files and not name.startswith('/') and '..' not in Path(name).parts
            info = regular(path)
            with path.open('rb') as stream:
                magic = stream.read(8)
            if magic.startswith((b'\x7fELF',b'MZ',b'SWRTZ001',b'SCRWRB',b'SCRWEP',b'SCRWWA',b'SCRWNR')):
                excluded.append(dict(path=name,bytes=info.st_size,reason='native executable or runtime/native package'))
                return
            row = dict(source=path,bytes=info.st_size,sha256=sha(path))
            if expected is not None:
                assert (row['bytes'],row['sha256']) == (expected['bytes'],expected['sha256'])
            files[name] = row
            assert len(files) <= MAX_FILES and sum(item['bytes'] for item in files.values()) <= MAX_EXPANDED
        frozen_binaries = {str(NATIVE/scope['binary']) for scope in native['scopes']}
        for directory in (FAILED,NATIVE,BASE/'cheap'):
            for path in sorted(directory.rglob('*')):
                if path.is_symlink():
                    raise ValueError('symlink in evidence tree: '+str(path))
                if not path.is_file():
                    continue
                alias = directory.name+'/'+path.relative_to(directory).as_posix()
                # Do not read retained native executables, including large copies.
                if str(path) in frozen_binaries or path.name == 'source-guards':
                    excluded.append(dict(path=alias,bytes=path.stat().st_size,reason='native executable; metadata identity retained in report'))
                    continue
                add(alias,path)
        for name, expected in ci['inputs'].items():
            path = Path(name)
            if path.is_relative_to(BASE):
                alias = 'evidence/'+path.relative_to(BASE).as_posix()
            else:
                assert path.is_relative_to(ROOT/'scripts')
                alias = 'reproduce/'+path.relative_to(ROOT).as_posix()
            add(alias,path,expected)
        for name in ('ci-40630427913-validated/report.json','ci-40630427913-validated/summary.md',
                     'ci-40630427913-validated/runtime-artifact-layout-source.rs',
                     'validate-ci-40630427913-reviewed.py','source-bindings-repaired-local-probe.json',
                     'source-bindings-repaired-local-probe.py','source-bindings-repaired-local-probe.stdout',
                     'source-bindings-repaired-local-probe.stderr','source-bindings-feature-probe.json','source-bindings.py',
                     'native-bootstrap-metadata-folds.py','native-bootstrap-metadata-folds-r1.py',
                     'native-4bd3a1bbd-launch.json','native-bd564df79-launch.json','launch-native.py','launch-native-r1.py',
                     'cheap.py','github-run-40630427913-completed.json'):
            alias = 'evidence/'+name
            if alias not in files:
                add(alias,BASE/name)
        pattern = ROOT/'target/memory-module-ownership-20261027-evidence/validate-ci-40594118953.py'
        assert sha(pattern) == ci['reused_validator_sha256']
        add('reproduce/ownership-validator-pattern.py',pattern)
        add('reproduce/publication-driver.py',Path(__file__).resolve())
        add('reference/core-native-4894-report.json',BASELINE)
        for name in ('limited_verification.py','native_test_protocol.py','precompiled_comparison.py','benchmark_module_images.py','benchmark_module_sections.py','diagnose-precompiled-mappings.py'):
            alias = 'reproduce/scripts/'+name
            if alias not in files:
                add(alias,ROOT/'scripts'/name)
        previous = ROOT/'docs/rust-rewrite/memory-calendar-rows-20261028.json'
        add('reference/'+previous.name,previous)
        for name in ('crates/scriptw-aot-wasm/src/runtime_artifact.rs','docs/rust-rewrite/contracts/native-bootstrap-metadata-folds.md'):
            path = OUT/Path(name).name
            with path.open('xb') as stream:
                stream.write(git('show',SOURCE+':'+name))
            add('reproduce/source/'+name,path)
        for chart in charts.values():
            for kind in ('svg','png'):
                add('previews/'+chart[kind],OUT/chart[kind])
        retained = archive(files)
        assert all(sha(row['source']) == row['sha256'] for row in files.values())
        assert sha(NATIVE/'report.json') == args.native_report_sha256 and sha(CI/'report.json') == args.ci_report_sha256
        assert sha(PROOF) == PROOF_SHA and root_state() == initial
        after = budget()
        resources(dict(cpu_affinity=[0],before=processing['before'],after=after),1024**3)
        processing.update(complete=True,after=after,finished_at=datetime.now(timezone.utc).isoformat(),excluded_payloads=excluded)
        document = dict(schema='scriptw-bootstrap-metadata-folds-evidence-v1',recorded_at=datetime.now(timezone.utc).isoformat(),
            verified_source_commit=SOURCE,compiler_feature_source_commit=FEATURE,measured_source_commit=MEASURED,runtime_layout=30,
            compiler_change=dict(native_metadata='Omit publication only for proven empty native metadata; retain ThrowTypeError/source publication.',
                intl_accessors='Route15 eligible Intl getters through the existing checked typed accessor allocator.',
                evidence='Source-bound focused emission controls plus descriptor/identity/defining-Realm/GC regressions; no new helper or layout change.'),
            source_bindings=dict(proof_sha256=PROOF_SHA,clean_fingerprint=FP,local_fingerprint=LOCAL_FP,rows=proof['rows']),
            native=dict(report_sha256=args.native_report_sha256,coverage=coverage,
                interpretation='All19 affected full scopes ran freshly once. Four focused controls are included, with no inherited passes. This is no original-JS or pinned Test262 execution claim.'),
            cheap_checkpoint=dict(report_sha256=CHEAP_SHA,rust_source_controls=278,guard_mutation_tests=15,current_intl_identities=15,
                source=FEATURE,scope='Pre-build feature checkpoint; the later test-only registry-iteration repair is bound separately and freshly covered by AOT514.'),
            verification_only_repair=dict(source=SOURCE,file=REPAIR,reason='Test registry iteration uses StandardBuiltinId::all_functions(); compiler/runtime inputs are unchanged.'),
            failure_lineage=dict(first_compile=dict(report_sha256=FAILED_SHA,complete=False,native_tests_executed=0,error=failed['error'])),
            measurement=dict(run=RUN,validated_report_sha256=args.ci_report_sha256,scored_report_sha256=sha(SCORED/'report.json'),
                attempts=68,workloads=17,all_attempts_ok=True,rss_ratio_min=min(ratios),rss_ratio_max=max(ratios),selected=selected,table=table,charts=charts),
            ci_native_controls=ci['native_controls'],ci_cli_example_controls=ci['cli_example_controls'],
            runtime_identity=ci['runtime_identity'],runtime_sections=ci['runtime_sections'],next_measurement_targets=ci['next_measurement_targets'],
            resource_origins=dict(source_binding=dict(before=proof['before'],after=proof['after']),cheap=dict(before=cheap['before'],after=cheap['after']),
                failed_compile=dict(before=failed['before'],after=failed['after'],complete=False),native=dict(before=native['before'],after=native['after']),
                ci_validation=dict(before=ci['before'],after=ci['after']),candidate_processing=dict(before=processing['before'],after=after)),
            prior_checkpoint=dict(file=previous.name,sha256=sha(previous),inherited_executions=0),archive=retained,publication_processing=processing,
            interpretation='Metadata/accessor folds are a compiler code-size change, not a causal RSS/speed or parity claim. Current layout30/key is recorded independently; no cross-runner native-byte or prior-key equality is assumed. Warm diagnostic observation16 follows16 prior calls. Section/page overlaps are nonadditive and presence does not prove execution. Scored two-runtime results remain separate from V8/status and optional unscored ownership observations.')
        lines = ['# Native bootstrap metadata and accessor folds','',
            'Verified source `'+SOURCE+'`:4906 fresh native passes across19 full affected scopes, including AOT514 and full engine library1056. The four focused controls count once; no inherited passes or original JS/Test262 execution is credited.','',
            'The compiler omits proven empty native metadata publication and routes15 eligible Intl getters through the existing checked typed accessor allocator. ThrowTypeError and source callable publication remain covered by the focused controls. Runtime layout stays30.','',
            'The first `'+FEATURE+'` attempt failed during Rust test compilation and ran no native tests. Its raw report and command streams are retained. The sole repair changes an excluded test registry iterator; exact compiler-input equality binds feature, repaired local source and measured probe.','',
            'CI'+str(RUN)+' (`'+MEASURED+'`):68/68 scored attempts across17 workload checksums; six engine diagnostic controls admitted separately. Current Scriptw/Scriptc RSS ratio range: '+format(min(ratios),'.9f')+'–'+format(max(ratios),'.9f')+'. No causal memory or speed saving is inferred.','',
            '| Workload | Scriptw ms | Scriptc ms | Scriptw RSS MiB | Scriptc RSS MiB |','|---|---:|---:|---:|---:|']
        for row in table:
            lines.append('| '+row['file']+' | '+' | '.join(format(row['runtimes'][runtime][metric],'.6f') for metric in ('ms','rss_mib') for runtime in ('scriptw','scriptc'))+' |')
        lines += ['','The private previews use the admitted current absolute values. They are not published graphs. Warm diagnostic section tables remain unscored; observation16 follows16 earlier calls, and overlaps must not be added or prorated into RSS.','',
            'The bounded inert archive retains current inventories/results, the failed compile, source/CI proofs, validators and measurement metadata. Native executables and runtime/native packages are excluded. No source, README, status, graphs or external publication is changed.']
        with (OUT/(STEM+'.json')).open('x') as stream:
            stream.write(json.dumps(document,indent=2)+'\n')
        with (OUT/(STEM+'.md')).open('x') as stream:
            stream.write('\n'.join(lines)+'\n')
    except BaseException as error:
        processing.update(complete=False,error=repr(error),error_type=type(error).__name__,after=budget(),finished_at=datetime.now(timezone.utc).isoformat())
        raise
    finally:
        with (OUT/'processing.json').open('x') as stream:
            stream.write(json.dumps(processing,indent=2)+'\n')
    print(json.dumps(dict(complete=True,output=str(OUT),coverage=coverage,archive_sha256=retained['sha256'],expanded_bytes=retained['expanded_bytes'])))


if __name__ == '__main__':
    main()
