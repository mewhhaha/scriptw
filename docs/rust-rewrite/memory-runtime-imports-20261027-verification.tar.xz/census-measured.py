"""Bind a flat import census to fully validated inert matched17 evidence."""
import importlib.util,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'scripts'));import precompiled_comparison as p
spec=importlib.util.spec_from_file_location('import_census',BASE/'import-census.py');c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
run=sys.argv[1];scored=BASE/('github-'+run)/'precompiled-measurements/precompiled-evidence'
report,rows=p.load_report(scored/'report.json');bindings=json.loads((BASE/'source-bindings-computed.json').read_text());clean=next(b for b in bindings if not b['extra_ignored_regress_lock'])
assert report['source_commit']==clean['revision'] and report['source_fingerprint']==clean['source_fingerprint']
assert len(rows)==17 and all(row['runtimes'][rt]['status']=='ok' for row in rows for rt in p.RUNTIMES)
files=sorted((scored/'wasm/scriptw').glob('*.wasm'));assert len(files)==17
cases=[]
for path in files:
 case=c.census(path);expected={a['image']['program_wasm_sha256'] for a in report['attempts'] if a['runtime']=='scriptw' and path.name==a['file']+'.wasm'};assert expected=={case['wasm_sha256']};cases.append(case)
value=dict(source_commit=report['source_commit'],source_fingerprint=report['source_fingerprint'],scored_report_sha256=p.digest(scored/'report.json'),cases=cases,interpretation='Inert matched17 P import census only; not memory or native execution evidence.')
(BASE/'import-census-current.json').write_text(json.dumps(value,indent=2)+'\n')
print(json.dumps([dict(file=case['file'],wasm_bytes=case['bytes'],runtime_imports=[item for item in case['counts'] if item['namespace']=='scriptw_runtime']) for case in cases],indent=2))
