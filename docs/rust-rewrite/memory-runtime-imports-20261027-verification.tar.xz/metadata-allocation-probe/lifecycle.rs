//! Inert exact-schema postcard metadata decode. Never loads executable images.
use std::alloc::{GlobalAlloc, Layout, System};
use std::sync::atomic::{AtomicUsize, Ordering::Relaxed};
use std::sync::atomic::AtomicBool;

struct Counting;
static ACTIVE: AtomicBool = AtomicBool::new(false);
static LIVE: AtomicUsize = AtomicUsize::new(0);
static PEAK: AtomicUsize = AtomicUsize::new(0);
static TOTAL: AtomicUsize = AtomicUsize::new(0);
static CALLS: AtomicUsize = AtomicUsize::new(0);
fn add(size: usize) {
    let live = LIVE.fetch_add(size, Relaxed) + size;
    if ACTIVE.load(Relaxed) {
        PEAK.fetch_max(live, Relaxed);
        TOTAL.fetch_add(size, Relaxed);
        CALLS.fetch_add(1, Relaxed);
    }
}
unsafe impl GlobalAlloc for Counting {
    unsafe fn alloc(&self, layout: Layout) -> *mut u8 {
        let ptr = unsafe { System.alloc(layout) };
        if !ptr.is_null() { add(layout.size()); }
        ptr
    }
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let ptr = unsafe { System.alloc_zeroed(layout) };
        if !ptr.is_null() { add(layout.size()); }
        ptr
    }
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout) {
        unsafe { System.dealloc(ptr, layout) };
        LIVE.fetch_sub(layout.size(), Relaxed);
    }
    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, size: usize) -> *mut u8 {
        let out = unsafe { System.realloc(ptr, layout, size) };
        if !out.is_null() {
            LIVE.fetch_sub(layout.size(), Relaxed);
            add(size);
        }
        out
    }
}
#[global_allocator]
static ALLOCATOR: Counting = Counting;


#[derive(Clone, Copy)]
struct Stage { label: &'static str, before: usize, after: usize, peak: usize, cumulative: usize, calls: usize, rss: u64, groups: [[u64; 3]; 7] }
const GROUPS: [&str; 7] = ["host_rx", "host_ro", "host_rw", "private_native_R", "anonymous_rx", "anonymous_rw_heap", "other"];
fn memory(output: &std::path::Path, label: &str, executable: &str) -> (u64, [[u64; 3]; 7]) {
    assert!(!ACTIVE.load(Relaxed));
    let raw = std::fs::read_to_string("/proc/self/smaps").unwrap();
    assert!(raw.len() < 2 * 1024 * 1024);
    std::fs::write(output.join(format!("{label}.smaps")), &raw).unwrap();
    let mut groups = [[0; 3]; 7];
    let mut group = 6;
    for line in raw.lines() {
        let words: Vec<_> = line.split_whitespace().collect();
        if words.len() >= 5 && words[0].contains('-') {
            let path = words.get(5).copied().unwrap_or("");
            group = if path == executable {
                match words[1] { "r-xp" => 0, "r--p" => 1, _ => 2 }
            } else if path.contains("private-native-backing-v1") { 3 }
            else if path.is_empty() && words[1].contains('x') { 4 }
            else if (path.is_empty() || path == "[heap]") && words[1].starts_with("rw") { 5 }
            else { 6 };
        } else if words.len() == 3 {
            let field = match words[0] { "Rss:" => 0, "Pss:" => 1, "Private_Dirty:" => 2, _ => continue };
            assert_eq!(words[2], "kB");
            groups[group][field] += words[1].parse::<u64>().unwrap() * 1024;
        }
    }
    (groups.iter().map(|group| group[0]).sum(), groups)
}
fn phase<T>(label: &'static str, output: &std::path::Path, executable: &str, work: impl FnOnce() -> T) -> (T, Stage) {
    let before = LIVE.load(Relaxed);
    PEAK.store(before, Relaxed); TOTAL.store(0, Relaxed); CALLS.store(0, Relaxed);
    ACTIVE.store(true, Relaxed);
    let value = work();
    ACTIVE.store(false, Relaxed);
    let after = LIVE.load(Relaxed);
    let peak = PEAK.load(Relaxed).saturating_sub(before);
    let cumulative = TOTAL.load(Relaxed); let calls = CALLS.load(Relaxed);
    let (rss, groups) = memory(output, label, executable);
    (value, Stage { label, before, after, peak, cumulative, calls, rss, groups })
}
fn main() {
    use scriptw_engine::{CompilerIdentity, CompilerSourceRevision, EmbeddedRuntime, ExecutionBackend,
        HostOutputEvent, ObservedCompletion, PrecompiledEmbeddedProgram, RealmBuilder};
    let args: Vec<_> = std::env::args().skip(1).collect();
    assert_eq!(args.len(), 6);
    let path = &args[0]; let target = &args[1]; let output = std::path::Path::new(&args[2]);
    let expected_stdout = &args[3]; let expected_source = &args[4]; let expected_fp = &args[5];
    let identity = CompilerIdentity::current().unwrap();
    let CompilerSourceRevision::GitCommit(source) = identity.source_revision() else { panic!("owned Git source required") };
    assert_eq!(source.as_str(), expected_source);
    assert_eq!(identity.source_fingerprint().to_string(), *expected_fp);
    let executable = std::env::current_exe().unwrap(); let executable = executable.to_str().unwrap();
    let (baseline_rss, baseline_groups) = memory(output, "baseline", executable);
    let baseline_live = LIVE.load(Relaxed);
    let (config, s1) = phase("configuration", output, executable, || {
        let mut config = wasmtime::Config::new(); scriptw_engine::configure_wasm_runtime(&mut config);
        config.cranelift_opt_level(wasmtime::OptLevel::SpeedAndSize);
        config.cranelift_regalloc_algorithm(wasmtime::RegallocAlgorithm::Backtracking);
        config.wasm_backtrace_details(wasmtime::WasmBacktraceDetails::Disable);
        config.target(target).unwrap(); config.parallel_compilation(false); config.enable_compiler(false); config
    });
    let (engine, s2) = phase("engine_new", output, executable, || wasmtime::Engine::new(&config).unwrap());
    assert!(engine.get_cranelift_opt_level().is_none());
    let ((transport, image), s3) = phase("image_read_and_envelope_admission", output, executable, || {
        assert!(std::fs::metadata(path).unwrap().len() < 256 * 1024 * 1024);
        let bytes = std::fs::read(path).unwrap();
        // SAFETY: the private driver passes only the unchanged whole envelope
        // freshly emitted by its owned, recorded matching0bd producer. It is
        // never a downloaded native image or caller blob authorized by a hash.
        let image = unsafe { PrecompiledEmbeddedProgram::from_bytes(&bytes) }.unwrap();
        (bytes, image)
    });
    let (runtime, s4) = phase("from_precompiled", output, executable, || EmbeddedRuntime::from_precompiled(&engine, &image).unwrap());
    let (_, s5) = phase("transport_drop", output, executable, || {drop(image); drop(transport);});
    let ((mut store, mut linker), s6) = phase("realm_state_store", output, executable, || {
        let state = runtime.new_state(RealmBuilder::new().build(), ()).unwrap();
        let mut store = wasmtime::Store::new(&engine, state); store.limiter(|state| state.limits_mut());
        store.set_epoch_deadline(u64::MAX / 2);
        (store, wasmtime::Linker::new(&engine))
    });
    let (_, s7) = phase("register", output, executable, || runtime.register(&mut store, &mut linker).unwrap());
    let (instance, s8) = phase("instantiate", output, executable, || runtime.instantiate(&mut store, &mut linker).unwrap());
    let gc_before = store.gc_heap_capacity();
    let (outcome, s9) = phase("initialize_evaluate", output, executable, || instance.evaluate(&mut store).unwrap());
    let gc_after = store.gc_heap_capacity();
    assert_eq!(outcome.backend_used, ExecutionBackend::WasmAot);
    assert!(matches!(outcome.completion, ObservedCompletion::Normal(_)));
    let mut stdout = String::new();
    for event in &outcome.output_events {
        match event {
            HostOutputEvent::PrintLine(line) => {stdout.push_str(line); stdout.push('\n');}
            HostOutputEvent::ReportedException(error) => panic!("reported exception: {error}"),
        }
    }
    assert_eq!(&stdout, expected_stdout); drop(stdout);
    let (_, s10) = phase("outcome_linker_store_drop", output, executable, || {drop(outcome); drop(linker); drop(store);});
    let (_, s11) = phase("runtime_drop", output, executable, || drop(runtime));
    let (_, s12) = phase("engine_drop", output, executable, || drop(engine));
    let (_, s13) = phase("configuration_drop", output, executable, || drop(config));
    println!("{{\"schema\":\"owned-integer-public-lifecycle-v1\",\"compiler_enabled\":false,\"samples\":1,\"warmups\":0,\"checksum_validated\":true,\"normal_completion\":true,\"gc_capacity_before_bytes\":{},\"gc_capacity_after_bytes\":{},\"baseline_live_requested_bytes\":{},\"baseline_rss_bytes\":{},\"source_commit\":\"{}\",\"source_fingerprint\":\"{}\",\"executable_sha256\":\"{}\",\"stages\":[",gc_before,gc_after,baseline_live,baseline_rss,source.as_str(),identity.source_fingerprint(),identity.executable_sha256());
    let baseline = Stage {label:"baseline", before:baseline_live, after:baseline_live, peak:0,cumulative:0,calls:0,rss:baseline_rss,groups:baseline_groups};
    for (index,stage) in [baseline,s1,s2,s3,s4,s5,s6,s7,s8,s9,s10,s11,s12,s13].into_iter().enumerate() {
        print!("{}{{\"stage\":\"{}\",\"live_before_bytes\":{},\"live_after_bytes\":{},\"live_delta_bytes\":{},\"peak_additional_requested_bytes\":{},\"cumulative_requested_bytes\":{},\"allocation_calls_including_realloc\":{},\"rss_bytes\":{},\"memory_groups\":{{",if index==0{""}else{","},stage.label,stage.before,stage.after,stage.after as i64-stage.before as i64,stage.peak,stage.cumulative,stage.calls,stage.rss);
        for (index,(name,values)) in GROUPS.iter().zip(stage.groups).enumerate() {
            print!("{}\"{}\":{{\"rss_bytes\":{},\"pss_bytes\":{},\"private_dirty_bytes\":{}}}",if index==0{""}else{","},name,values[0],values[1],values[2]);
        }
        print!("}}}}");
    }
    println!("]}}");
}
