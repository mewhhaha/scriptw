//! Inert exact-schema postcard metadata decode. Never loads executable images.
use std::alloc::{GlobalAlloc, Layout, System};
use std::sync::atomic::{AtomicUsize, Ordering::Relaxed};
use std::sync::atomic::AtomicBool;

struct Counting;
static ACTIVE: AtomicBool = AtomicBool::new(false);
static LIVE: AtomicUsize = AtomicUsize::new(0);
static PEAK: AtomicUsize = AtomicUsize::new(0);
static TOTAL: AtomicUsize = AtomicUsize::new(0);
static CALLS: AtomicUsize = AtomicUsize::new(0);
fn add(size: usize) {
    let live = LIVE.fetch_add(size, Relaxed) + size;
    if ACTIVE.load(Relaxed) {
        PEAK.fetch_max(live, Relaxed);
        TOTAL.fetch_add(size, Relaxed);
        CALLS.fetch_add(1, Relaxed);
    }
}
unsafe impl GlobalAlloc for Counting {
    unsafe fn alloc(&self, layout: Layout) -> *mut u8 {
        let ptr = unsafe { System.alloc(layout) };
        if !ptr.is_null() { add(layout.size()); }
        ptr
    }
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let ptr = unsafe { System.alloc_zeroed(layout) };
        if !ptr.is_null() { add(layout.size()); }
        ptr
    }
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout) {
        unsafe { System.dealloc(ptr, layout) };
        LIVE.fetch_sub(layout.size(), Relaxed);
    }
    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, size: usize) -> *mut u8 {
        let out = unsafe { System.realloc(ptr, layout, size) };
        if !out.is_null() {
            LIVE.fetch_sub(layout.size(), Relaxed);
            add(size);
        }
        out
    }
}
#[global_allocator]
static ALLOCATOR: Counting = Counting;

#[derive(Clone, Copy)]
struct Stage { label: &'static str, before: usize, after: usize, peak: usize, cumulative: usize, calls: usize, memory: [u64; 3] }
fn memory() -> [u64; 3] {
    // Measurement I/O occurs only with ACTIVE=false and owns no retained buffer.
    assert!(!ACTIVE.load(Relaxed));
    let raw = std::fs::read_to_string("/proc/self/smaps_rollup").unwrap();
    let mut values = [0; 3];
    for line in raw.lines() {
        let words: Vec<_> = line.split_whitespace().collect();
        if words.len() != 3 { continue; }
        let field = match words[0] { "Rss:" => 0, "Pss:" => 1, "Private_Dirty:" => 2, _ => continue };
        assert_eq!(words[2], "kB");
        values[field] = words[1].parse::<u64>().unwrap() * 1024;
    }
    assert!(values[0] > 0 && values[1] > 0);
    values
}
fn phase<T>(label: &'static str, work: impl FnOnce() -> T) -> (T, Stage) {
    let before = LIVE.load(Relaxed);
    PEAK.store(before, Relaxed);
    TOTAL.store(0, Relaxed); CALLS.store(0, Relaxed);
    ACTIVE.store(true, Relaxed);
    let value = work();
    ACTIVE.store(false, Relaxed);
    let after = LIVE.load(Relaxed);
    let peak = PEAK.load(Relaxed).saturating_sub(before);
    let cumulative = TOTAL.load(Relaxed); let calls = CALLS.load(Relaxed);
    let memory = memory();
    (value, Stage { label, before, after, peak, cumulative, calls, memory })
}
fn main() {
    let mut args = std::env::args().skip(1);
    let path = args.next().expect("private runner's exact owned Cargo native ELF");
    let target = args.next().expect("actual recorded Cargo target");
    let file = std::fs::File::open(&path).unwrap();
    assert!(file.metadata().unwrap().len() < 256 * 1024 * 1024);
    let baseline_memory = memory(); // Prewarm the same proc-I/O parser before phases.
    let baseline_live = LIVE.load(Relaxed);
    let (config, configuration) = phase("configuration", || {
        let mut config = wasmtime::Config::new();
        scriptw_engine::configure_wasm_runtime(&mut config);
        config.cranelift_opt_level(wasmtime::OptLevel::SpeedAndSize);
        config.cranelift_regalloc_algorithm(wasmtime::RegallocAlgorithm::Backtracking);
        config.wasm_backtrace_details(wasmtime::WasmBacktraceDetails::Disable);
        config.target(&target).unwrap();
        config.parallel_compilation(false);
        config.enable_compiler(false);
        config
    });
    let (engine, engine_created) = phase("engine_new", || wasmtime::Engine::new(&config).unwrap());
    assert!(engine.get_cranelift_opt_level().is_none());
    let (module, module_created) = phase("deserialize_open_file", || {
        // SAFETY: private runner admits only unchanged own Cargo runtime-image
        // build output from the recorded0bd producer. No build mutates it during
        // this probe; before/after file+library hashes bind the record. Hashes
        // alone never grant authority, and no arbitrary/downloaded input is used.
        unsafe { wasmtime::Module::deserialize_open_file(&engine, file).unwrap() }
    });
    let (_, module_dropped) = phase("module_drop", || drop(module));
    let (_, engine_dropped) = phase("engine_drop", || drop(engine));
    let (_, config_dropped) = phase("configuration_drop", || drop(config));
    println!("{{\"schema\":\"wasmtime47-owned-R-public-admission-allocations-v1\",\"instantiated\":false,\"native_called\":false,\"compiler_enabled\":false,\"baseline_live_requested_bytes\":{},\"baseline_memory\":{{\"rss_bytes\":{},\"pss_bytes\":{},\"private_dirty_bytes\":{}}},\"stages\":[", baseline_live, baseline_memory[0], baseline_memory[1], baseline_memory[2]);
    for (index, stage) in [configuration, engine_created, module_created, module_dropped, engine_dropped, config_dropped].into_iter().enumerate() {
        println!("{}{{\"stage\":\"{}\",\"live_before_bytes\":{},\"live_after_bytes\":{},\"live_delta_bytes\":{},\"peak_additional_requested_bytes\":{},\"cumulative_requested_bytes\":{},\"allocation_calls_including_realloc\":{},\"memory\":{{\"rss_bytes\":{},\"pss_bytes\":{},\"private_dirty_bytes\":{}}}}}", if index == 0 { "" } else { "," }, stage.label, stage.before, stage.after, stage.after as i64-stage.before as i64, stage.peak, stage.cumulative, stage.calls, stage.memory[0], stage.memory[1], stage.memory[2]);
    }
    println!("]}}");
}
