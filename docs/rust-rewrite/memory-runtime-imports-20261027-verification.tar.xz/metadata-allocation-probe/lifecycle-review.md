# One owned integer lifecycle phase decomposition

This completed ONE fresh locally owned producer invocation and ONE compiler-disabled consumer invocation. Source revision0bd2c2ea7a4a98146d3dac5734afa0f3812de5c3; actual producer/consumer source fingerprint44b4da1e5c566933f3e650a9014869509a0b0ec17664c593f6c96ae1f04ae033. Unchanged canonical integer.js and its exact expected output were checked. No CI native bytes were used. Input authority is the actual owned matching producer; checksums alone confer none.

LOCAL limited_verification: CPU0,4GiB,no swap,grouped OOM. Private rustc using recorded cached release rlibs and Cargo native paths took2.277s; producer0.493s; consumer0.374s. Scope peak1295028224 bytes includes private linking and producer. No Cargo build or shared-target/product/vendor writes.

## Exact post-API phase endpoints

| Phase | Live Rust requested KiB | RSS MiB | Host RX KiB | Native R mappings KiB | Anonymous RW/heap KiB |
|---|---:|---:|---:|---:|---:|
| baseline | 1.2 | 5.391 | 732 | 0 | 52 |
| configuration | 1.3 | 6.305 | 1436 | 0 | 88 |
| engine_new | 3.3 | 6.711 | 1756 | 0 | 120 |
| image_read_and_envelope_admission | 904.1 | 9.031 | 3036 | 0 | 1024 |
| from_precompiled | 1541.8 | 14.176 | 5788 | 420 | 1816 |
| transport_drop | 640.9 | 13.363 | 5852 | 420 | 920 |
| realm_state_store | 644.2 | 13.613 | 6108 | 420 | 920 |
| register | 673.9 | 13.992 | 6492 | 420 | 924 |
| instantiate | 766.5 | 15.895 | 6620 | 1348 | 1816 |
| initialize_evaluate | 783.3 | 18.965 | 6684 | 3844 | 2336 |
| outcome_linker_store_drop | 640.9 | 17.711 | 6684 | 3844 | 1052 |
| runtime_drop | 41.0 | 13.641 | 6748 | 0 | 1052 |
| engine_drop | 3.2 | 13.641 | 6748 | 0 | 1052 |
| configuration_drop | 3.1 | 13.641 | 6748 | 0 | 1052 |

Store construction adds3400 requested bytes, registration30353, instantiation94876 and initialize/evaluate17179. Dropping outcome/linker/Store frees145808 requested bytes and returns to656283 live requested bytes, exactly the after-transport-drop allocation level. Wasm GC heap remains16MiB capacity during this execution; capacity is not resident memory or requested Rust allocation.

Native R resident mapping pages rise420KiB after admission to1348KiB after instantiation and3844KiB after initialization; all3844KiB remain after StoreDrop. R mappings disappear after runtime drop. Host RX grows5852→6684KiB between after-transport-drop and initialization, and remains6684KiB after StoreDrop. The direct source-backed implication is that small retained Rust Store allocations are not the main local post-Store floor; module-owned native R residency and host executable pages persist while the runtime remains owned. This is not a proof of which functions executed or of removable pages. The separate native-permissions JSON decomposes R RX/RO from these exact raw snapshots.

RuntimeDrop frees614279 requested bytes and removes R/P native mappings, while RSS stays13.641MiB; EngineDrop releases another38770 requested bytes without reducing this endpoint RSS. Requested allocations, allocator-retained anonymous pages, resident host code/data and native mappings are different quantities. No forced collection, eviction, allocator trim or reservation-size subtraction was used.

## Boundaries and limitations

The same public runtime configuration as the shared baseline is used. Each stage snapshots raw smaps immediately after the corresponding API returns, with measurement I/O outside allocator counting phases and the parser prewarmed before baseline. The public evaluate method calls initialize once, observes completion and drains output; that combined public boundary is explicitly named initialize_evaluate. Instance setup and entry execution are separate stages.

The diagnostic contains one cold invocation and no warmups. It is differently linked from the benchmark host and cannot be combined with CI values or used as a canonical performance result. Raw smaps snapshots include probe I/O overhead. Family labels are conservative: anonymous RX is not asserted to be exclusively P code; private native R uses its actual backing pathname; exact host executable path identifies host mappings. Global counters measure requested System allocator layouts, excluding mmap/FFI/allocator rounding. Phase bounds include any workers joined by the public APIs.

Provenance, original Cargo product receipt, producer/executable/image/source hashes, source fingerprint, raw command streams,14 raw phase smaps, allocation live/peak/cumulative counters, and resource counters are in lifecycle-report.json and adjacent private outputs. Native binaries/images are private and excluded from publication.
