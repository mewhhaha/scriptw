"""Private exact-schema inert decode; no Wasmtime engine/native loading APIs."""
import hashlib,json,os,stat,subprocess,sys,time,shutil
from pathlib import Path
BASE=Path(__file__).resolve().parent; EVIDENCE=BASE.parent; ROOT=EVIDENCE.parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from limited_verification import require_kernel_budget,kernel_group
import precompiled_comparison as p
import importlib.util
spec=importlib.util.spec_from_file_location('lifecycle_streams',ROOT/'scripts/diagnose-precompiled-mappings.py');streams=importlib.util.module_from_spec(spec);spec.loader.exec_module(streams)
SOURCE='0bd2c2ea7a4a98146d3dac5734afa0f3812de5c3'
def sha(path):
 with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
report=dict(schema='scriptw-private-owned-integer-lifecycle-v1',scored=False,complete=False,source_commit=SOURCE,commands=[],inputs=[],results=[],
 interpretation='One fresh owned integer image through compiler-disabled public lifecycle. Rust requested allocations separate from phase smaps/RSS groups; exact API-return endpoints, no warmed/cohort claim or savings estimate. initialize_evaluate includes initialize+public output observation. Measurement I/O excluded from allocation phase counters')
def save():
 tmp=BASE/'report.pending.json';tmp.write_text(json.dumps(report,indent=2)+'\n');tmp.replace(BASE/'lifecycle-report.json')
def budget():
 group=kernel_group();return {k:(group/k).read_text().strip() for k in ['memory.max','memory.swap.max','memory.oom.group','memory.current','memory.peak','memory.events']}
save()
environment=dict(os.environ)
for key in list(environment):
 if key.startswith(('SCRIPTW_WASM_TRACE','SCRIPTW_ROW_PERF_','SCRIPTW_BOUNDARY_READY_')) or key in ('SCRIPTW_PERF_MAP_DIR','SCRIPTW_EMIT_SIZE_REPORT','NODE_OPTIONS','NODE_COMPILE_CACHE'):
  environment.pop(key,None)
def run(label,args):
 row=dict(label=label,argv=list(map(str,args)),stdout=label+'.stdout',stderr=label+'.stderr');report['commands'].append(row);save();start=time.monotonic()
 with (BASE/row['stdout']).open('xb') as out,(BASE/row['stderr']).open('xb') as err:
  child=subprocess.Popen(row['argv'],cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True,env=environment)
  try:
   streams.drain_owned(child,{'stdout':out,'stderr':err},lambda:None,deadline=180)
   row['exit_code']=child.returncode
  except (ValueError,subprocess.SubprocessError) as error:
   row.update(exit_code=child.returncode,error=str(error))
 row.update(seconds=time.monotonic()-start,stdout_sha256=sha(BASE/row['stdout']),stderr_sha256=sha(BASE/row['stderr']));save()
 if row['exit_code']!=0:raise ValueError(label+' failed; raw attempt retained')
 return (BASE/row['stdout']).read_text()
try:
 require_kernel_budget(4*1024**3);assert len(os.sched_getaffinity(0))==1
 report.update(cpu_affinity=sorted(os.sched_getaffinity(0)),before=budget());save()
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==SOURCE
 verification=json.loads((EVIDENCE/'verification.json').read_text());assert verification['source_commit']==SOURCE
 cargo=EVIDENCE/'cargo-products.jsonl';records=[json.loads(l) for l in cargo.read_text().splitlines()]
 builds=[r for r in records if r.get('reason')=='build-script-executed' and 'scriptw-runtime-image#' in r.get('package_id','')];assert len(builds)==1
 owned=Path(builds[0]['out_dir']);assert owned.is_relative_to(ROOT/'target')
 report.update(cargo_products_sha256=sha(cargo),cargo_runtime_build=builds[0],probe_source_sha256=sha(BASE/'lifecycle.rs'))
 externs={}
 for name in ('scriptw_engine','wasmtime'):
  rows=[r for r in records if r.get('reason')=='compiler-artifact' and r['target']['name']==name and r['profile']['opt_level']=='3' and not r['profile']['test']]
  assert len(rows)==1,(name,len(rows))
  path=next(Path(p) for p in rows[0]['filenames'] if p.endswith('.rlib'));assert path.is_relative_to(ROOT/'target')
  externs[name]=path;report.setdefault('cached_libraries',{})[name]=dict(path=str(path),sha256=sha(path),cargo_producer=rows[0])
 for filename in ('scriptw-runtime-portable-native.bin','scriptw-runtime-native.bin','scriptw-runtime-portable-manifest.bin','scriptw-runtime-manifest.bin'):
  path=owned/filename;info=path.lstat();assert stat.S_ISREG(info.st_mode) and info.st_uid==os.getuid() and info.st_nlink==1 and info.st_size<256*1024**2
  report['inputs'].append(dict(path=str(path),bytes=info.st_size,sha256=sha(path)))
 save()
 schema=Path('/home/mewhhaha/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/wasmtime-environ-47.0.0/src')
 report['schema_sources']={str(path):sha(path) for path in [schema/'module_artifacts.rs',schema/'module_types.rs',schema/'module.rs',ROOT/'vendor/wasmtime-47.0.0/src/runtime/module.rs']};save()
 executable=BASE/'lifecycle-probe';assert not executable.exists()
 args=['rustc','--edition=2021','-C','opt-level=1','-C','debuginfo=0','-C','link-arg=-fuse-ld=lld',BASE/'lifecycle.rs','-o',executable,'-L','dependency='+str(externs['wasmtime'].parent)]
 for name,path in externs.items():args+=['--extern',name+'='+str(path)]
 native_paths=sorted({path for row in records if row.get('reason')=='build-script-executed' for path in row.get('linked_paths',[])})
 for path in native_paths:
  assert path.startswith('native=') and Path(path[7:]).is_relative_to(ROOT/'target')
  args+=['-L',path]
 cli=[row for row in records if row.get('reason')=='build-script-executed' and 'scriptw-cli#' in row.get('package_id','')]
 assert len(cli)==1
 target=dict(cli[0]['env'])['SCRIPTW_PERF_TARGET'];assert target=='x86_64-unknown-linux-gnu'
 report.update(native_link_paths=native_paths,shared_configuration=dict(public_initializer='scriptw_engine::configure_wasm_runtime',native_compilation_mode='size-optimized',register_allocation='backtracking',target_triple=target,wasm_backtrace_details='disable',compiler_enabled=False,parallel_compilation=False))
 save()
 run('lifecycle-rustc',args);report['probe_executable_sha256']=sha(executable);save()
 # Freeze exactly the normal original Cargo product before the one producer invocation.
 products=[row for row in records if row.get('reason')=='compiler-artifact' and row.get('executable') and row['target']['name']=='compiler_precompiled_baseline' and not row['profile']['test']]
 assert len(products)==1
 original=Path(products[0]['executable']);frozen=BASE/'lifecycle-original-producer';assert not frozen.exists()
 shutil.copy2(original,frozen);assert sha(original)==sha(frozen) and frozen.stat().st_nlink==1
 report['producer_binary']=dict(path=str(frozen),sha256=sha(frozen),cargo_producer=products[0]);save()
 fixtures=BASE/'lifecycle-sources';fixtures.mkdir()
 manifest=ROOT/p.FIXTURES/'manifest.json';plan=json.loads(manifest.read_text());case=next(row for row in plan['execution'] if row['file']=='integer.js')
 source=ROOT/p.FIXTURES/'integer.js';shutil.copyfile(source,fixtures/'integer.js')
 (fixtures/'manifest.json').write_text(json.dumps(dict(execution=[case]))+'\n')
 report['fixture']=dict(original_path=str(source),sha256=sha(source),manifest_sha256=sha(manifest),expected_stdout=case['stdout'],private_manifest_sha256=sha(fixtures/'manifest.json'))
 images=BASE/'lifecycle-images';assert not images.exists()
 producer=json.loads(run('lifecycle-prepare-scriptw',[frozen,'prepare-scriptw',fixtures,images]))
 assert producer['source_commit']==SOURCE and producer['compiler_identity_scheme']=='scriptw-program-cache-compiler-v3'
 assert producer['executable_sha256']==report['producer_binary']['sha256'] and producer['compiler_enabled'] is True
 fp=producer['source_fingerprint'];assert len(fp)==64
 assert producer['shared_configuration']==dict(p.SHARED_CONFIGURATION,target_triple=target)
 assert len(producer['cases'])==1 and producer['manifest_sha256']==sha(fixtures/'manifest.json')
 receipt=producer['cases'][0];assert receipt['file']=='integer.js' and receipt['source_sha256']==sha(source)==sha(fixtures/'integer.js')
 assert receipt['stdout']==case['stdout'] and receipt['source_compilation_profile']=='portable' and receipt['intl_profile']=='Minimal'
 image=images/receipt['image'];assert image.parent==images;streams.owned_file(image)
 metadata=p.image_metadata(image.read_bytes(),'scriptw',fp)
 assert receipt['image_sha256']==metadata['sha256'] and receipt['image_bytes']==metadata['bytes']
 for key in ('program_wasm_sha256','program_wasm_bytes','native_serialized_bytes','runtime_key','execution_facts_bytes','execution_facts_sha256'):
  assert receipt[key]==metadata[key],key
 report.update(actual_source_fingerprint=fp,producer_receipt=producer,image=dict(path=str(image),**metadata));save()
 snapshots=BASE/'lifecycle-smaps';snapshots.mkdir()
 decoded=json.loads(run('lifecycle-consumer',[executable,image,target,snapshots,case['stdout'],SOURCE,fp]))
 assert decoded['source_commit']==SOURCE and decoded['source_fingerprint']==fp and decoded['executable_sha256']==sha(executable)
 assert decoded['compiler_enabled'] is False and decoded['checksum_validated'] and decoded['normal_completion']
 assert decoded['samples']==1 and decoded['warmups']==0 and len(decoded['stages'])==14
 report['results'].append(decoded)
 report['raw_smaps']=[dict(path=str(path.relative_to(BASE)),bytes=path.stat().st_size,sha256=sha(path)) for path in sorted(snapshots.glob('*.smaps'))]
 assert len(report['raw_smaps'])==14
 assert sha(frozen)==report['producer_binary']['sha256'] and sha(image)==metadata['sha256']
 assert sha(source)==report['fixture']['sha256'] and sha(manifest)==report['fixture']['manifest_sha256']
 assert sha(cargo)==report['cargo_products_sha256']
 for row in report['inputs']:assert sha(row['path'])==row['sha256']
 for row in report['cached_libraries'].values():assert sha(row['path'])==row['sha256']
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==SOURCE
 report['complete']=True
except Exception as error:
 report['error']=str(error)
finally:
 try:report['after']=budget()
 except Exception as error:report['budget_error']=str(error)
 save()
print(json.dumps(dict(complete=report['complete'],results=report['results'],error=report.get('error'))))
raise SystemExit(0 if report['complete'] else 1)
