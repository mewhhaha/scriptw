# Owned Cargo R public admission allocation probe

Both Portable and NativeHost runs completed, serially in LOCAL limited_verification: one CPU,4GiB,no swap,grouped OOM. Exact0bd Cargo runtime-image native.bin outputs and recorded cached release libraries; all input/library hashes unchanged. No Cargo build, module instantiation, Store, guest call, JS parsing or native-image function call occurred.

The public shared baseline configuration was reproduced through cached `scriptw_engine::configure_wasm_runtime`, then SpeedAndSize/backtracking, recorded generic Cargo target, disabled backtrace details/parallel compilation, and compiler disabled. Native compatibility admission succeeded. Only unchanged owned Cargo output grants the unsafe deserialization authority; checksums record identity, not authority.

## Results

| Profile/stage | Rust live delta bytes | Peak additional requested bytes | RSS endpoint MiB |
|---|---:|---:|---:|
| portable/configuration | 82 | 408 | 3.719 |
| portable/engine_new | 2010 | 2092 | 3.973 |
| portable/deserialize_open_file | 521237 | 521237 | 5.652 |
| portable/module_drop | -483837 | 0 | 5.059 |
| portable/engine_drop | -38770 | 0 | 5.059 |
| portable/configuration_drop | -82 | 0 | 5.059 |
| native-host/configuration | 82 | 408 | 3.656 |
| native-host/engine_new | 2010 | 2092 | 4.035 |
| native-host/deserialize_open_file | 521439 | 521439 | 5.535 |
| native-host/module_drop | -484039 | 0 | 5.066 |
| native-host/engine_drop | -38770 | 0 | 5.066 |
| native-host/configuration_drop | -82 | 0 | 5.066 |

Portable Engine::new itself retains2010 requested bytes. Deserializing R adds521237 requested bytes, versus277361 for the earlier metadata-only decode. ModuleDrop releases483837; EngineDrop releases38770. ConfigDrop releases82. Final global requested live allocation differs from preconfiguration baseline by640 bytes. These are measured allocation deltas, not a proof of which internal subsystem owns each byte.

For Portable, RSS is3.266MiB before configuration,3.973MiB after Engine,5.652MiB after admission and5.059MiB after Module/EngineDrop. A freed requested allocation does not guarantee returned physical pages; resident host text/data and allocator retention remain. The probe is differently linked from the full consumer and never instantiates R, so its RSS cannot be assigned to the canonical warmed floor or subtracted from CI bars.

## Method and limits

A counting System allocator tracks live requested sizes for every Rust allocation. Only allocation counters/peak updates within each synchronous phase are enabled; prewarmed smaps_rollup read/parsing runs after disabling phase recording, and its temporary buffers are freed before the next phase. Native file opened before phases and mapped via the actual public Module::deserialize_open_file; no full native input Vec is introduced. Config is retained through EngineDrop and dropped in a final distinct phase. No parallel compilation or workloads, no unbounded runtime caches.

Requested sizes exclude allocator rounding, libc allocations, mmap mappings and executable/read-only pages. Engine canonicalization/registration is included in the actual admission phase, but no per-subsystem allocation attribution is claimed. No savings estimate is warranted. The metadata/canonicalization hypothesis is bounded here to roughly half a MiB of retained requested Rust allocations before any instantiation; multi-MiB warmed effects require a later Store/instance/execution measurement.

Raw command streams, schema/source hashes, actual Cargo build record, library fingerprints, native/manifest hashes, per-phase counters, resource counters and compiler-free policy are retained in `admission-report.json`. Previous metadata-only results remain in `report.json`; failed first scope-bus launch remains in `launch.stderr`.
