"""Private exact-schema inert decode; no Wasmtime engine/native loading APIs."""
import hashlib,json,os,stat,subprocess,sys,time
from pathlib import Path
BASE=Path(__file__).resolve().parent; EVIDENCE=BASE.parent; ROOT=EVIDENCE.parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from limited_verification import require_kernel_budget,kernel_group
SOURCE='0bd2c2ea7a4a98146d3dac5734afa0f3812de5c3'
def sha(path):
 with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
report=dict(schema='scriptw-private-runtime-admission-allocation-probe-v1',scored=False,complete=False,source_commit=SOURCE,commands=[],inputs=[],results=[],
 interpretation='Rust allocator requested bytes during exact public Engine/R admission; proc RSS endpoints separate and include code/data/mappings. No instantiation/native call, no savings estimate; snapshot I/O excluded from allocation phases')
def save():
 tmp=BASE/'report.pending.json';tmp.write_text(json.dumps(report,indent=2)+'\n');tmp.replace(BASE/'admission-report.json')
def budget():
 group=kernel_group();return {k:(group/k).read_text().strip() for k in ['memory.max','memory.swap.max','memory.oom.group','memory.current','memory.peak','memory.events']}
save()
def run(label,args):
 row=dict(label=label,argv=list(map(str,args)),stdout=label+'.stdout',stderr=label+'.stderr');report['commands'].append(row);save();start=time.monotonic()
 with (BASE/row['stdout']).open('xb') as out,(BASE/row['stderr']).open('xb') as err:
  child=subprocess.Popen(row['argv'],cwd=ROOT,stdout=out,stderr=err,start_new_session=True)
  try:row['exit_code']=child.wait(timeout=180)
  except subprocess.TimeoutExpired:
   os.killpg(child.pid,9);child.wait();row.update(exit_code=child.returncode,timed_out=True)
 row.update(seconds=time.monotonic()-start,stdout_sha256=sha(BASE/row['stdout']),stderr_sha256=sha(BASE/row['stderr']));save()
 if row['exit_code']!=0:raise ValueError(label+' failed; raw attempt retained')
 return (BASE/row['stdout']).read_text()
try:
 require_kernel_budget(4*1024**3);assert len(os.sched_getaffinity(0))==1
 report.update(cpu_affinity=sorted(os.sched_getaffinity(0)),before=budget());save()
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==SOURCE
 verification=json.loads((EVIDENCE/'verification.json').read_text());assert verification['source_commit']==SOURCE
 cargo=EVIDENCE/'cargo-products.jsonl';records=[json.loads(l) for l in cargo.read_text().splitlines()]
 builds=[r for r in records if r.get('reason')=='build-script-executed' and 'scriptw-runtime-image#' in r.get('package_id','')];assert len(builds)==1
 owned=Path(builds[0]['out_dir']);assert owned.is_relative_to(ROOT/'target')
 report.update(cargo_products_sha256=sha(cargo),cargo_runtime_build=builds[0],probe_source_sha256=sha(BASE/'admission.rs'))
 externs={}
 for name in ('scriptw_engine','wasmtime'):
  rows=[r for r in records if r.get('reason')=='compiler-artifact' and r['target']['name']==name and r['profile']['opt_level']=='3' and not r['profile']['test']]
  assert len(rows)==1,(name,len(rows))
  path=next(Path(p) for p in rows[0]['filenames'] if p.endswith('.rlib'));assert path.is_relative_to(ROOT/'target')
  externs[name]=path;report.setdefault('cached_libraries',{})[name]=dict(path=str(path),sha256=sha(path),cargo_producer=rows[0])
 for filename in ('scriptw-runtime-portable-native.bin','scriptw-runtime-native.bin','scriptw-runtime-portable-manifest.bin','scriptw-runtime-manifest.bin'):
  path=owned/filename;info=path.lstat();assert stat.S_ISREG(info.st_mode) and info.st_uid==os.getuid() and info.st_nlink==1 and info.st_size<256*1024**2
  report['inputs'].append(dict(path=str(path),bytes=info.st_size,sha256=sha(path)))
 save()
 schema=Path('/home/mewhhaha/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/wasmtime-environ-47.0.0/src')
 report['schema_sources']={str(path):sha(path) for path in [schema/'module_artifacts.rs',schema/'module_types.rs',schema/'module.rs',ROOT/'vendor/wasmtime-47.0.0/src/runtime/module.rs']};save()
 executable=BASE/'admission-probe';assert not executable.exists()
 args=['rustc','--edition=2021','-C','opt-level=1','-C','debuginfo=0','-C','link-arg=-fuse-ld=lld',BASE/'admission.rs','-o',executable,'-L','dependency='+str(externs['wasmtime'].parent)]
 for name,path in externs.items():args+=['--extern',name+'='+str(path)]
 native_paths=sorted({path for row in records if row.get('reason')=='build-script-executed' for path in row.get('linked_paths',[])})
 for path in native_paths:
  assert path.startswith('native=') and Path(path[7:]).is_relative_to(ROOT/'target')
  args+=['-L',path]
 cli=[row for row in records if row.get('reason')=='build-script-executed' and 'scriptw-cli#' in row.get('package_id','')]
 assert len(cli)==1
 target=dict(cli[0]['env'])['SCRIPTW_PERF_TARGET'];assert target=='x86_64-unknown-linux-gnu'
 report.update(native_link_paths=native_paths,shared_configuration=dict(public_initializer='scriptw_engine::configure_wasm_runtime',native_compilation_mode='size-optimized',register_allocation='backtracking',target_triple=target,wasm_backtrace_details='disable',compiler_enabled=False,parallel_compilation=False))
 save()
 run('admission-rustc',args);report['probe_executable_sha256']=sha(executable);save()
 for profile,filename in [('portable','scriptw-runtime-portable-native.bin'),('native-host','scriptw-runtime-native.bin')]:
  output=run('admission-'+profile,[executable,owned/filename,target]);decoded=json.loads(output)
  assert decoded['instantiated'] is False and decoded['native_called'] is False and decoded['compiler_enabled'] is False
  report['results'].append(dict(profile=profile,**decoded));save()
 assert sha(cargo)==report['cargo_products_sha256']
 for row in report['inputs']:assert sha(row['path'])==row['sha256']
 for row in report['cached_libraries'].values():assert sha(row['path'])==row['sha256']
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==SOURCE
 report['complete']=True
except Exception as error:
 report['error']=str(error)
finally:
 try:report['after']=budget()
 except Exception as error:report['budget_error']=str(error)
 save()
print(json.dumps(dict(complete=report['complete'],results=report['results'],error=report.get('error'))))
raise SystemExit(0 if report['complete'] else 1)
