//! Inert exact-schema postcard metadata decode. Never loads executable images.
use object::{Object, ObjectSection};
use std::alloc::{GlobalAlloc, Layout, System};
use std::sync::atomic::{AtomicUsize, Ordering::Relaxed};
use wasmtime_environ::{CompiledFunctionsTable, CompiledModuleInfo, ModuleTypes};

struct Counting;
static LIVE: AtomicUsize = AtomicUsize::new(0);
static PEAK: AtomicUsize = AtomicUsize::new(0);
static TOTAL: AtomicUsize = AtomicUsize::new(0);
static CALLS: AtomicUsize = AtomicUsize::new(0);
fn add(size: usize) {
    let live = LIVE.fetch_add(size, Relaxed) + size;
    PEAK.fetch_max(live, Relaxed);
    TOTAL.fetch_add(size, Relaxed);
    CALLS.fetch_add(1, Relaxed);
}
unsafe impl GlobalAlloc for Counting {
    unsafe fn alloc(&self, layout: Layout) -> *mut u8 {
        let ptr = unsafe { System.alloc(layout) };
        if !ptr.is_null() { add(layout.size()); }
        ptr
    }
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let ptr = unsafe { System.alloc_zeroed(layout) };
        if !ptr.is_null() { add(layout.size()); }
        ptr
    }
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout) {
        unsafe { System.dealloc(ptr, layout) };
        LIVE.fetch_sub(layout.size(), Relaxed);
    }
    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, size: usize) -> *mut u8 {
        let out = unsafe { System.realloc(ptr, layout, size) };
        if !out.is_null() {
            LIVE.fetch_sub(layout.size(), Relaxed);
            add(size);
        }
        out
    }
}
#[global_allocator]
static ALLOCATOR: Counting = Counting;
fn freed<T>(value: T) -> usize {
    let before = LIVE.load(Relaxed);
    drop(value);
    before - LIVE.load(Relaxed)
}
fn main() {
    let path = std::env::args().nth(1).expect("owned Cargo native ELF path");
    assert!(std::fs::metadata(&path).unwrap().len() <= 256 * 1024 * 1024);
    let bytes = std::fs::read(path).unwrap();
    let elf = object::File::parse(bytes.as_slice()).unwrap();
    assert_eq!(elf.format(), object::BinaryFormat::Elf);
    assert!(elf.is_64() && elf.is_little_endian());
    let section = elf.section_by_name(wasmtime_environ::obj::ELF_WASMTIME_INFO).unwrap();
    let data = section.data().unwrap();
    let section_bytes = data.len();
    let section_range = section.file_range().unwrap();
    // All input bytes and ELF views already exist. Only decode is measured.
    let baseline = LIVE.load(Relaxed);
    let calls_before = CALLS.load(Relaxed);
    let total_before = TOTAL.load(Relaxed);
    PEAK.store(baseline, Relaxed);
    let (info, index, types): (CompiledModuleInfo, CompiledFunctionsTable, ModuleTypes) =
        postcard::from_bytes(data).expect("exact Wasmtime47 metadata tuple");
    let retained = LIVE.load(Relaxed) - baseline;
    let peak = PEAK.load(Relaxed) - baseline;
    let total = TOTAL.load(Relaxed) - total_before;
    let calls = CALLS.load(Relaxed) - calls_before;
    // Public fields only; no assumptions about private Rust layouts/capacities.
    let counts = [
        info.module.functions.len(), info.module.exports.len(), info.module.globals.len(),
        info.module.types.len(), info.module.strings.len(), info.module.initializers.len(),
        info.module.runtime_data.len(), info.module.passive_elements.len(),
        info.module.num_imported_funcs, info.module.num_imported_globals,
        info.module.num_escaped_funcs, info.func_names.len(), info.func_names.capacity(),
        types.wasm_types().len(), types.rec_groups().len(),
        info.module.memories.len(), info.module.tables.len(), info.module.tags.len(),
    ];
    let CompiledModuleInfo { module, meta, func_names, checksum } = info;
    let module_freed = freed(module);
    let meta_freed = freed(meta);
    let names_freed = freed(func_names);
    let checksum_freed = freed(checksum);
    let index_freed = freed(index);
    let types_freed = freed(types);
    let remaining = LIVE.load(Relaxed) - baseline;
    println!("{{\"schema\":\"wasmtime47-inert-metadata-allocations-v1\",\"section_offset\":{},\"section_bytes\":{},\"retained_requested_bytes\":{},\"peak_additional_requested_bytes\":{},\"cumulative_requested_bytes\":{},\"allocation_calls_including_realloc\":{},\"remaining_after_drop_bytes\":{},\"freed_components\":{{\"module\":{},\"metadata\":{},\"function_names\":{},\"checksum\":{},\"compiled_functions_table\":{},\"module_types\":{}}},\"counts\":{{\"functions\":{},\"exports\":{},\"globals\":{},\"module_type_entries\":{},\"pooled_strings\":{},\"initializers\":{},\"runtime_data\":{},\"passive_elements\":{},\"imported_functions\":{},\"imported_globals\":{},\"escaped_functions\":{},\"function_names_len\":{},\"function_names_capacity\":{},\"wasm_types\":{},\"rec_groups\":{},\"memories\":{},\"tables\":{},\"tags\":{}}}}}",
        section_range.0, section_bytes, retained, peak, total, calls, remaining,
        module_freed, meta_freed, names_freed, checksum_freed, index_freed, types_freed,
        counts[0], counts[1], counts[2], counts[3], counts[4], counts[5], counts[6], counts[7], counts[8], counts[9], counts[10], counts[11], counts[12], counts[13], counts[14], counts[15], counts[16], counts[17]);
}
