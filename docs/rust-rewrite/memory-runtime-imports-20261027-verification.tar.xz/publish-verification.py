"""Publish completed exact-source verification, excluding executable/native payloads."""
from datetime import datetime,timezone
import hashlib,json,lzma,re,sys,tarfile
from pathlib import Path,PurePosixPath
BASE=Path(__file__).resolve().parent;ROOT=BASE.parents[1];DEST=ROOT/'docs/rust-rewrite'
sys.path.insert(0,str(ROOT/'scripts'))
import precompiled_comparison as p
from native_test_protocol import result_summaries
STEM='memory-runtime-imports-20261027'
SOURCE='0bd2c2ea7a4a98146d3dac5734afa0f3812de5c3'
def read(path):return json.loads(path.read_text())
def sha(path):
 with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def streams(directory,commands):
 for row in commands:
  assert row.get('exit_code',row.get('returncode'))==0
  for key in ('stdout','stderr'):assert sha(directory/row[key])==row[key+'_sha256']
def resource(report):
 for moment in ('before','after'):
  value=report[moment];assert value['memory.max']=='4294967296' and value['memory.swap.max']=='0' and value['memory.oom.group']=='1'
 before=dict(line.split() for line in report['before']['memory.events'].splitlines());after=dict(line.split() for line in report['after']['memory.events'].splitlines())
 assert all(before[key]==after[key] for key in ('oom','oom_kill','oom_group_kill'))
native=read(BASE/'native-final/report.json');batch=read(BASE/'verification-final.json');conf=read(BASE/'conformance-completed/report.json');check=read(BASE/'check.json');cheap=read(BASE/'cheap-main-fixtures/cheap-main.json')
assert all(row['complete'] and row['source_commit']==SOURCE for row in (native,conf,check))
assert batch['source_commit']==SOURCE and not batch['complete']
assert batch['commands'][-1]['label']=='test262-driver' and 'exit_code' not in batch['commands'][-1]
assert check['exit_code']==0 and cheap['complete'] and cheap['base_commit']==SOURCE
assert sha(BASE/'cargo-check.jsonl')==check['stdout_sha256'] and sha(BASE/'cargo-check.stderr')==check['stderr_sha256']
streams(BASE/'native-final',native['commands']);streams(BASE,batch['commands'][:-1]);streams(BASE/'conformance-completed',conf['commands']);streams(BASE/'cheap-main-fixtures',cheap['commands'])
for report in (conf,check):resource(report)
assert batch['before']['memory.max']=='4294967296' and batch['before']['memory.swap.max']=='0' and batch['before']['memory.oom.group']=='1'
assert conf['interruption']['result']=='oom-kill' and conf['interruption']['exit_code']==137
assert "Failed with result 'oom-kill'" in (BASE/conf['interruption']['evidence']).read_text()
original=read(BASE/'conformance/report.json');assert not original['complete'] and original['source_commit']==SOURCE
streams(BASE/'conformance',original['commands'][:-1])
assert original['commands'][-1]['label']=='execute' and 'returncode' not in original['commands'][-1]
checkpoint=read(BASE/conf['original_checkpoint']['file'])
assert sha(BASE/conf['original_checkpoint']['file'])==conf['original_checkpoint']['sha256']
assert checkpoint['compiler_identity']==conf['compiler']['identity']==original['compiler']['identity']
assert checkpoint['passed']==checkpoint['total']==2100 and not checkpoint['failures'] and not checkpoint['timeout_test_ids']
assert checkpoint['counts_per_outcome']==dict(Bug=0,Crash=0,NotImplemented=0,Success=2100)
selection=BASE/conf['original_selection']['file'];assert sha(selection)==conf['original_selection']['sha256']==original['execution_list_sha256']
selected=selection.read_text().splitlines();actual=list(checkpoint['completed_test_ids'])
for part in conf['batches']:
 directory=BASE/'conformance-completed';listing=directory/part['list_file'];snapshot=directory/part['snapshot_file']
 assert sha(listing)==part['list_sha256'] and sha(snapshot)==part['snapshot_sha256']
 ids=listing.read_text().splitlines();snap=read(snapshot)
 assert 0<len(ids)<=16 and len(ids)==len(set(ids))==part['passed']==snap['total']==snap['passed']
 assert snap['compiler_identity']==checkpoint['compiler_identity'] and set(snap['completed_test_ids'])==set(ids)
 assert not snap['failures'] and not snap['timeout_test_ids'] and snap['counts_per_outcome']==dict(Bug=0,Crash=0,NotImplemented=0,Success=len(ids))
 actual+=ids
assert len(actual)==len(set(actual))==len(selected)==len(set(selected))==2365 and set(actual)==set(selected)
resource(native['repair_resources'])
assert native['original_budget']['memory.max']=='4294967296' and native['original_budget']['memory.swap.max']=='0' and native['original_budget']['memory.oom.group']=='1'
fixture=read(BASE/'structure-fixture.json');assert native['test_fixture_patch']==batch['test_fixture_patch']==fixture
assert fixture['source_commit']==SOURCE and sha(BASE/fixture['patch'])==fixture['patch_sha256']
assert len(native['scopes'])==19 and len({(s['package'],s['target']) for s in native['scopes']})==19
assert {s['target'] for s in native['scopes'] if s['package']=='scriptw-aot-wasm'}=={'scriptw_aot_wasm','runtime_link','structure_builtins','structure_language','emission','modules_realms','intl_temporal','structure_async'}
scopes=[]
for scope in native['scopes']:
 inventory=scope['inventory'];assert scope['complete'] and len(inventory)==len(set(inventory))==scope['passed']
 prefix=scope['package']+'-'+scope['target']+'-part-'
 actual=[]
 for command in native['commands']:
  if not command['label'].startswith(prefix):continue
  raw=(BASE/'native-final'/command['stdout']).read_text();names=[n.removesuffix(' - should panic') for n in re.findall(r'^test ([^\r\n]+) \.\.\. ok$',raw,re.M)]
  assert result_summaries(raw)==[('ok',str(len(names)),'0','0','0',str(len(inventory)-len(names)))]
  if scope['target']=='scriptw_engine':assert 0<len(names)<=8
  actual+=names
 assert len(actual)==len(inventory) and set(actual)==set(inventory)
 scopes.append(dict(package=scope['package'],target=scope['target'],passed=scope['passed'],executable_sha256=scope['executable_sha256'],focused_overlap=scope.get('focused_overlap',[])))
assert sum(s['passed'] for s in scopes)==native['passed_disjoint_scopes']
assert conf['total']==conf['passed']>0
assert conf['compiler']['identity']['source_revision']==dict(kind='git-commit',commit=SOURCE)
bindings=read(BASE/'source-bindings-computed.json');assert len(bindings)==2 and all(b['revision']==SOURCE for b in bindings)
clean,local=bindings;assert not clean['extra_ignored_regress_lock'] and local['extra_ignored_regress_lock']
assert conf['compiler']['identity']['source_fingerprint']==local['source_fingerprint']
run=sys.argv[1];scored=BASE/('github-'+run)/'precompiled-measurements/precompiled-evidence'
measured,rows=p.load_report(scored/'report.json');assert measured['source_commit']==SOURCE and measured['source_fingerprint']==clean['source_fingerprint']
assert len(rows)==17 and all(row['runtimes'][rt]['status']=='ok' for row in rows for rt in p.RUNTIMES)
census=read(BASE/'import-census-current.json');assert census['source_commit']==SOURCE and census['source_fingerprint']==clean['source_fingerprint'] and census['scored_report_sha256']==sha(scored/'report.json')
assert len(census['cases'])==17
lock=ROOT/'vendor/regress-0.10.5/Cargo.lock';provenance=BASE/'provenance';provenance.mkdir(exist_ok=True);(provenance/'ignored-regress-Cargo.lock').write_bytes(lock.read_bytes())
files=[]
for path in sorted(BASE.rglob('*')):
 if not path.is_file():continue
 rel=path.relative_to(BASE).as_posix();parts=PurePosixPath(rel).parts
 if parts[0].startswith('github-') or 'images' in parts or path.name.startswith(('publication.','preview-')):continue
 if path.suffix not in ('.py','.json','.jsonl','.stdout','.stderr','.smaps','.txt','.lock','.md','.rs','.patch','.executions','.attempts') and path.name not in ('executions','stdout','stderr'):continue
 assert not path.is_symlink() and path.stat().st_size<=128*1024**2 and '..' not in parts and not PurePosixPath(rel).is_absolute()
 with path.open('rb') as f:assert not f.read(8).startswith((b'\x7fELF',b'MZ',b'SCRWEP01',b'SCRWEP02',b'SCRWWA01'))
 files.append(dict(path=rel,bytes=path.stat().st_size,sha256=sha(path)))
expanded=sum(row['bytes'] for row in files);assert expanded<=2*1024**3
archive=DEST/(STEM+'-verification.tar.xz');assert not archive.exists()
with archive.open('xb') as output,lzma.LZMAFile(output,'w',format=lzma.FORMAT_XZ,filters=[dict(id=lzma.FILTER_LZMA2,preset=1,dict_size=64*1024**2)]) as compressed:
 with tarfile.open(fileobj=compressed,mode='w|',format=tarfile.PAX_FORMAT) as tar:
  for row in files:
   member=tarfile.TarInfo(row['path']);member.size=row['bytes'];member.mode=0o644
   with (BASE/row['path']).open('rb') as stream:tar.addfile(member,stream)
assert archive.stat().st_size<=32*1024**2
inventory={row['path']:row for row in files};seen=set();roundtrip=0
with tarfile.open(archive,'r|xz') as tar:
 for member in tar:
  assert member.isfile() and member.name in inventory and member.name not in seen
  row=inventory[member.name];assert member.size==row['bytes']<=128*1024**2
  assert hashlib.file_digest(tar.extractfile(member),'sha256').hexdigest()==row['sha256']
  seen.add(member.name);roundtrip+=member.size;assert roundtrip<=2*1024**3
assert seen==set(inventory) and roundtrip==expanded
record=dict(schema='scriptw-runtime-import-memory-verification-v1',recorded_at=datetime.now(timezone.utc).isoformat(),verified_source_commit=SOURCE,measured_source_commit=measured['source_commit'],source_bindings=bindings,native=dict(passed=native['passed_disjoint_scopes'],scopes=scopes,raw_report='native-final/report.json',test_fixture_patch=fixture),test262=dict(passed=conf['passed'],total=conf['total'],compiler=conf['compiler'],raw_report='conformance-completed/report.json', original_interruption=conf['interruption'], checkpoint_passed=2100, fresh_batch_passed=265),measurement=dict(run=run,url=measured['github_run_url'],raw_report_sha256=sha(scored/'report.json')),interpretation='All19affected native inventories and exact original selected Test262 executions.18completed native scopes retain exact execution evidence; the37-case structural target is rebuilt with an explicitly recorded test-only census patch outside compiler inputs. Original structural failure and original counters are preserved separately. Focused checks overlap full inventories. No full pinned-suite refresh. Original failed attempts retained, including an OOM-killed original conformance process:2100 checkpointed successes plus265 exact remaining IDs in fresh batches of at most16. Original scope has no after counters; successful completion counters belong to the fresh scope. Local inputs additionally fingerprint retained ignored standalone dependency lock; CI uses clean Git inputs. Private next value-backing batch is excluded. No native executables/images are archived.',archive=dict(file=archive.name,sha256=sha(archive),bytes=archive.stat().st_size,expanded_bytes=expanded,member_count=len(files),max_expanded_bytes=2*1024**3,max_member_bytes=128*1024**2),retained_files=files)
target=DEST/(STEM+'.json');assert not target.exists();target.write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(dict(native=native['passed_disjoint_scopes'],test262=conf['total'],archive=record['archive']),indent=2))
