"""Complete exact original selection in short-lived batches after bounded OOM."""
from datetime import datetime, timezone
import hashlib, json, os, re, signal, subprocess, sys, time
from pathlib import Path
BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
from limited_verification import require_kernel_budget, kernel_group
require_kernel_budget(4 * 1024**3)
assert len(os.sched_getaffinity(0)) == 1
def sha(p):
    with p.open('rb') as f: return hashlib.file_digest(f, 'sha256').hexdigest()
def read(p): return json.loads(p.read_text())
def stamp(): return datetime.now(timezone.utc).isoformat()
group = kernel_group()
def budget():
    return {k: (group/k).read_text().strip() for k in ('memory.max','memory.swap.max','memory.oom.group','memory.peak','memory.events')}
original = read(BASE/'conformance/report.json')
source = original['source_commit']
assert source == subprocess.check_output(['git','rev-parse','HEAD'], cwd=ROOT, text=True).strip()
compiler = BASE/'conformance/compiler'
assert sha(compiler) == original['compiler']['sha256']
checkpoint_path, = (BASE/'conformance/snapshots').glob('*.json')
checkpoint = read(checkpoint_path)
selected_path = BASE/'conformance/executions'
assert sha(selected_path) == original['execution_list_sha256']
selected = selected_path.read_text().splitlines()
done = checkpoint['completed_test_ids']
assert len(selected) == len(set(selected)) == 2365
assert len(done) == len(set(done)) == checkpoint['passed'] == checkpoint['total'] == 2100
assert not checkpoint['failures'] and not checkpoint['timeout_test_ids']
assert checkpoint['counts_per_outcome'] == dict(Bug=0, Crash=0, NotImplemented=0, Success=2100)
assert checkpoint['compiler_identity'] == original['compiler']['identity']
assert set(done) <= set(selected)
remaining = sorted(set(selected)-set(done))
output = BASE/'conformance-completed'
output.mkdir(exist_ok=False)
report = dict(source_commit=source, complete=False, started_at=stamp(), before=budget(),
              commands=[], compiler=original['compiler'], total=len(selected), passed=0,
              original_checkpoint=dict(file=str(checkpoint_path.relative_to(BASE)), sha256=sha(checkpoint_path), passed=len(done)),
              original_selection=dict(file=str(selected_path.relative_to(BASE)), sha256=sha(selected_path)),
              interruption=dict(scope='run-p2165919-i6340357.scope', result='oom-kill', exit_code=137,
                  evidence='conformance-interruption-journal.txt', memory_limit_bytes=4*1024**3,
                  interpretation='Original checkpoint records 2100 successes; original process did not complete. Remaining exact IDs execute in fresh batches of at most16; no limit increase.'),
              batches=[])
def save(): (output/'report.json').write_text(json.dumps(report, indent=2)+'\n')
save()
for offset in range(0,len(remaining),16):
    ids = remaining[offset:offset+16]
    name = f'batch-{offset//16:03d}'
    execution_list = output/(name+'.executions')
    execution_list.write_text('\n'.join(ids)+'\n')
    args = [str(compiler),'--jobs','1','test262','run-list',str(execution_list),
            '--execution-backend','wasm-aot','--suite-root',str(ROOT/'test262/vendor/test262'),
            '--snapshot-dir',str(output/name),'--snapshot-name',name,'--threads','1',
            '--timeout-ms','60000','--reuse-case-workers']
    event = dict(label=name, command=args, stdout=name+'.stdout', stderr=name+'.stderr', started_at=stamp())
    report['commands'].append(event); save(); start=time.monotonic()
    with (output/event['stdout']).open('xb') as out, (output/event['stderr']).open('xb') as err:
        child=subprocess.Popen(args,cwd=ROOT,stdout=out,stderr=err,start_new_session=True)
        try: code=child.wait(timeout=1200)
        except BaseException:
            if child.poll() is None: os.killpg(child.pid,signal.SIGKILL)
            child.wait(); raise
    event.update(returncode=code, finished_at=stamp(), seconds=time.monotonic()-start,
                 stdout_sha256=sha(output/event['stdout']), stderr_sha256=sha(output/event['stderr']))
    save(); assert code == 0, name+' failed'
    text=(output/event['stdout']).read_text()
    assert re.findall(r'^total: (\d+)$',text,re.M) == re.findall(r'^passed: (\d+)$',text,re.M) == [str(len(ids))]
    snap_path, = (output/name).glob('*.json'); snap=read(snap_path)
    assert snap['compiler_identity']==original['compiler']['identity']
    assert snap['total']==snap['passed']==len(ids) and set(snap['completed_test_ids'])==set(ids)
    assert not snap['failures'] and not snap['timeout_test_ids']
    report['batches'].append(dict(list_file=execution_list.name,list_sha256=sha(execution_list),
                                 snapshot_file=str(snap_path.relative_to(output)), snapshot_sha256=sha(snap_path), passed=len(ids)))
    report['passed']=len(done)+sum(b['passed'] for b in report['batches']); save()
    print('completed',report['passed'],'/',len(selected),flush=True)
assert report['passed']==len(selected) and sha(compiler)==original['compiler']['sha256']
report.update(complete=True,finished_at=stamp(),after=budget());save()
