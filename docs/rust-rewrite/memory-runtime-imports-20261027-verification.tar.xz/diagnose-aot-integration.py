"""Execute the remaining frozen AOT integration targets before batching repairs."""
import hashlib,json,os,re,shutil,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];BASE=Path(__file__).resolve().parent;OUT=BASE/'aot-integration-diagnostic'
sys.path.insert(0,str(ROOT/'scripts'))
from limited_verification import require_kernel_budget,kernel_group
from native_test_protocol import parse_inventory,result_summaries
require_kernel_budget(4*1024**3);assert len(os.sched_getaffinity(0))==1
SOURCE=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip();assert SOURCE=='66a1d7f9b1149252a18193f166443ce1a9bbc3f5'
OUT.mkdir(exist_ok=False)
def sha(path):
 with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
cargo=[json.loads(l) for l in (BASE/'native/cargo-native.stdout').read_text().splitlines()];assert cargo[-1]==dict(reason='build-finished',success=True)
report=dict(source_commit=SOURCE,complete=False,scopes=[])
def save():(OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n')
for name in ('modules_realms','intl_temporal','structure_async'):
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==SOURCE
 producers=[r for r in cargo if r.get('reason')=='compiler-artifact' and r.get('executable') and r['target']['name']==name and r['target']['kind']==['test']];assert len(producers)==1
 source=Path(producers[0]['executable']);binary=OUT/name;shutil.copy2(source,binary);assert sha(binary)==sha(source)
 row=dict(target=name,executable_sha256=sha(binary),producer=producers[0]);report['scopes'].append(row);save()
 inventory=subprocess.check_output([binary,'--list'],cwd=ROOT/'crates/scriptw-aot-wasm',text=True);(OUT/(name+'-inventory.stdout')).write_text(inventory);ids=parse_inventory(inventory);row['inventory']=ids
 with (OUT/(name+'.stdout')).open('xb') as out,(OUT/(name+'.stderr')).open('xb') as err:child=subprocess.run([binary,'--exact','--include-ignored','--test-threads=1',*ids],cwd=ROOT/'crates/scriptw-aot-wasm',stdout=out,stderr=err,timeout=3600)
 raw=(OUT/(name+'.stdout')).read_text();row.update(exit_code=child.returncode,summaries=result_summaries(raw),stdout_sha256=sha(OUT/(name+'.stdout')),stderr_sha256=sha(OUT/(name+'.stderr')));save();print(name,child.returncode,row['summaries'],flush=True)
report['complete']=True;save()
