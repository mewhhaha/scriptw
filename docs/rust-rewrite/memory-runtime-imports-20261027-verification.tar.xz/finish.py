"""Repair one test-only structural census, retain completed product executions."""
from datetime import datetime,timezone
import copy,hashlib,json,os,re,shutil,subprocess,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'scripts'))
from limited_verification import require_kernel_budget,kernel_group
from native_test_protocol import parse_inventory,result_summaries
require_kernel_budget(4*1024**3);assert len(os.sched_getaffinity(0))==1
SOURCE='0bd2c2ea7a4a98146d3dac5734afa0f3812de5c3';patch=json.loads((BASE/'structure-fixture.json').read_text());original=json.loads((BASE/'native/report.json').read_text());group=kernel_group()
def budget():return {k:(group/k).read_text().strip() for k in ('memory.max','memory.swap.max','memory.oom.group','memory.peak','memory.events')}
def sha(path):
 with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def stamp():return datetime.now(timezone.utc).isoformat()
def frozen():
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==SOURCE
 changed=subprocess.check_output(['git','diff','--name-only','HEAD','--','crates','vendor','scripts','Cargo.toml','Cargo.lock'],cwd=ROOT,text=True).splitlines();assert changed==[patch['path']],changed
 assert sha(ROOT/patch['path'])==patch['after_sha256'] and sha(BASE/patch['patch'])==patch['patch_sha256']
 assert subprocess.check_output(['git','diff','--binary','HEAD','--',patch['path']],cwd=ROOT)==(BASE/patch['patch']).read_bytes()
report=dict(source_commit=SOURCE,complete=False,started_at=stamp(),before=budget(),cpu_affinity=sorted(os.sched_getaffinity(0)),test_fixture_patch=patch,commands=[])
def save():(BASE/'verification-final.json').write_text(json.dumps(report,indent=2)+'\n')
def run(label,args,*,cwd=ROOT,jsonl=False):
 frozen();out=BASE/(label+('.jsonl' if jsonl else '.stdout'));err=BASE/(label+'.stderr');row=dict(label=label,command=list(map(str,args)),cwd=str(cwd),stdout=out.name,stderr=err.name,started_at=stamp());report['commands'].append(row);save();print(label,'started',flush=True);start=time.monotonic()
 with out.open('xb') as stdout,err.open('xb') as stderr:child=subprocess.run(row['command'],cwd=cwd,stdout=stdout,stderr=stderr,timeout=10800)
 row.update(exit_code=child.returncode,seconds=time.monotonic()-start,stdout_sha256=sha(out),stderr_sha256=sha(err));save();print(label,'finished',child.returncode,flush=True)
 assert child.returncode==0,label+' failed; original streams retained'
 return out.read_text()
frozen();assert original['source_commit']==SOURCE and len(original['scopes'])==19
completed=[s for s in original['scopes'] if s['complete']];assert len(completed)==18 and sum(s['passed'] for s in completed)==4821
failed=[s for s in original['scopes'] if not s['complete']];assert len(failed)==1 and failed[0]['target']=='structure'
cargo_command=original['commands'][0]['command'];assert original['commands'][0]['label']=='cargo-native'
text=run('cargo-native-fixture',cargo_command,jsonl=True);cargo=[json.loads(line) for line in text.splitlines()];assert cargo[-1]==dict(reason='build-finished',success=True)
producers=[r for r in cargo if r.get('reason')=='compiler-artifact' and r.get('executable') and r['target']['name']=='structure' and r['target']['kind']==['test'] and r['profile']['test']];assert len(producers)==1
out=BASE/'native-final';out.mkdir(exist_ok=False);binary=out/'structure-tests';source=Path(producers[0]['executable']);shutil.copy2(source,binary);assert sha(binary)==sha(source)
inv_text=run('structure-inventory-final',[binary,'--list'],cwd=ROOT/'crates/scriptw-engine');ids=parse_inventory(inv_text);assert ids==failed[0]['inventory'] and len(ids)==37
text=run('structure-execute-final',[binary,'--exact','--include-ignored','--test-threads=1',*ids],cwd=ROOT/'crates/scriptw-engine');names=[n.removesuffix(' - should panic') for n in re.findall(r'^test ([^\r\n]+) \.\.\. ok$',text,re.M)];assert len(names)==len(ids) and set(names)==set(ids);assert result_summaries(text)==[('ok','37','0','0','0','0')]
# Preserve all successful scopes byte-for-byte. The original failed report and
# original structural stdout remain unchanged in native/ for the audit trail.
commands=[]
for row in original['commands']:
 if row['label'].startswith('scriptw-engine-structure'):continue
 assert row['exit_code']==0
 for stream in ('stdout','stderr'):
  src=BASE/'native'/row[stream];dst=out/row[stream];assert sha(src)==row[stream+'_sha256'];shutil.copyfile(src,dst);assert sha(dst)==row[stream+'_sha256']
 commands.append(copy.deepcopy(row))
for old_label,new_label in [('structure-inventory-final','scriptw-engine-structure-inventory'),('structure-execute-final','scriptw-engine-structure-part-000')]:
 row=copy.deepcopy(next(r for r in report['commands'] if r['label']==old_label));row['label']=new_label
 for stream in ('stdout','stderr'):
  src=BASE/row[stream];row[stream]=new_label+'.'+stream;shutil.copyfile(src,out/row[stream]);assert sha(out/row[stream])==row[stream+'_sha256']
 commands.append(row)
fixed=dict(package='scriptw-engine',target='structure',kind='test',executable_sha256=sha(binary),cargo_producer=producers[0],complete=True,inventory=ids,passed=37,test_fixture_patch=patch)
final=dict(source_commit=SOURCE,complete=True,scopes=copy.deepcopy(completed)+[fixed],commands=commands,passed_disjoint_scopes=4858,original_report='native/report.json',original_budget=original['before'],repair_resources=dict(before=report['before'],after=budget()),test_fixture_patch=patch,interpretation='18 complete scopes retain their exact original execution streams; the final37-case structural target is rebuilt with an explicitly recorded test-only census repair. Compiler/native inputs and all test IDs are unchanged. Original36pass/1fail structural attempt retained; not added to the pass total. Original terminated scope has no after-event counters; repair counters are separate.')
assert sum(s['passed'] for s in final['scopes'])==4858
(out/'report.json').write_text(json.dumps(final,indent=2)+'\n');print('complete4858 native cases; original failure retained',flush=True)
build=ROOT/'target/performance-work-20261024/build'
run('cargo-products',['cargo','build','--locked','--offline','--release','--jobs','1','--target-dir',build,'-p','scriptw-cli','--bin','scriptw','--example','compiler_precompiled_baseline','--message-format=json'],jsonl=True)
run('test262-driver',[sys.executable,'-B',BASE/'test262.py'])
frozen();report.update(complete=True,finished_at=stamp(),after=budget());save();print('final verification complete',flush=True)
