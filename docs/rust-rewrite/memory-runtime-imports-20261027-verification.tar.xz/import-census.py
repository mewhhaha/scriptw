"""Inspect inert owned/archived core P imports; never load native code."""
import hashlib,json,sys
from collections import Counter
from pathlib import Path
class Reader:
 def __init__(self,raw):self.raw=raw;self.at=0
 def byte(self):
  assert self.at<len(self.raw)
  value=self.raw[self.at];self.at+=1;return value
 def leb(self):
  value=0
  for n in range(10):
   b=self.byte();value|=(b&127)<<(7*n)
   if b<128:return value
  raise ValueError('oversized LEB')
 def take(self,n):
  assert n>=0 and self.at+n<=len(self.raw)
  value=self.raw[self.at:self.at+n];self.at+=n;return value
 def text(self):return self.take(self.leb()).decode('utf-8')
 def valtype(self):
  if self.byte() in (0x63,0x64):self.leb()
 def limits(self):
  flags=self.leb();self.leb()
  if flags&1:self.leb()
  if flags&8:self.leb()
def census(path):
 raw=path.read_bytes();assert len(raw)<=128*1024**2
 r=Reader(raw);assert r.take(8)==b'\0asm\x01\0\0\0'
 rows=[];counts=Counter();indices=Counter()
 while r.at<len(raw):
  section=r.byte();part=Reader(r.take(r.leb()))
  if section!=2:continue
  for _ in range(part.leb()):
   module,name,kind=part.text(),part.text(),part.byte()
   if kind in (0,0x20):ty='function';part.leb()
   elif kind==1:ty='table';part.valtype();part.limits()
   elif kind==2:ty='memory';part.limits()
   elif kind==3:ty='global';part.valtype();part.byte()
   elif kind==4:ty='tag';assert part.byte()==0;part.leb()
   else:raise ValueError(f'unsupported flat producer import kind {kind}')
   rows.append(dict(namespace=module,name=name,kind=ty,index=indices[ty]));indices[ty]+=1
   counts[(module,ty)]+=1
  assert part.at==len(part.raw),'import section has unexpected framing'
 return dict(file=path.name,wasm_sha256=hashlib.sha256(raw).hexdigest(),bytes=len(raw),counts=[dict(namespace=module,kind=kind,count=count) for (module,kind),count in sorted(counts.items())],imports=rows)
if __name__=='__main__':
 paths=sorted(Path(sys.argv[1]).glob('*.wasm'));assert len(paths)==17,'complete matched17 P corpus required'
 print(json.dumps([census(path) for path in paths],indent=2))
