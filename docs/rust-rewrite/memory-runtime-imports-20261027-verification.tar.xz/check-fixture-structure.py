"""Cheap compilation of the two repaired source-only fixture controls."""
import hashlib,json,os,subprocess,sys
from pathlib import Path
ROOT=Path('/home/mewhhaha/src/porffor/target/memory-array-internal-descriptors-20261027');BASE=Path(__file__).resolve().parent;OUT=BASE/'fixture-structure-diagnostic'
sys.path.insert(0,str(BASE.parents[1]/'scripts'))
from limited_verification import require_kernel_budget
require_kernel_budget(4*1024**3);assert len(os.sched_getaffinity(0))==1
OUT.mkdir(exist_ok=False);rows=[]
for name,source,case in [('package','tests/modules_realms/compiled_module_package_structure.rs','emitter_consumes_the_package_through_the_reviewed_lifecycle'),('intl','tests/intl_temporal/intl_supported_values_structure.rs','primitive_tables_check_producer_identity_before_host_image_emission')]:
 source=ROOT/'crates/scriptw-aot-wasm'/source;binary=OUT/name
 for label,args in [(name+'-compile',['rustc','--edition=2021','--test',str(source),'-o',str(binary)]),(name+'-execute',[str(binary),'--exact',case,'--test-threads=1'])]:
  with (OUT/(label+'.stdout')).open('xb') as out,(OUT/(label+'.stderr')).open('xb') as err:child=subprocess.run(args,cwd=ROOT,stdout=out,stderr=err,timeout=300)
  row=dict(label=label,args=args,exit_code=child.returncode,source_sha256=hashlib.sha256(source.read_bytes()).hexdigest());rows.append(row);(OUT/'report.json').write_text(json.dumps(dict(scopes=rows,interpretation='Two targeted structural diagnostics from isolated worktree; not native/compiler conformance count.'),indent=2)+'\n');print(label,child.returncode,flush=True)
  if child.returncode:raise SystemExit(child.returncode)
