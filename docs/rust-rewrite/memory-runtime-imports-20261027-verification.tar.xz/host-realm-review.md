# Read-only host Realm allocation review

Sol runtime reviewer inspected current main (0bd2c2ea7). No duplicate native JavaScript object graph or material memory candidate was found. `scriptw-runtime/src/lib.rs` Realm stores two IDs and four Arc host services: clock, configured timezone, randomness and hooks. RealmBuilder::build allocates these small owners. Intrinsic/global accessors return RealmId wrappers. Default timezone is UTC, random/hooks are zero-sized defaults, and the clock stores one Instant. The optional spec-exec dependency is disabled by default.

The services are used by Wasm host imports for Date/performance clocks, randomness, output, timezone, agents/wait deadlines and weak reporting. EmbeddedRuntime::new_state moves this Realm and clones admitted Intl kernel ownership. Weak/async containers start empty. Shared default services could avoid a handful of small allocations but are not a source-backed explanation for a multi-MiB floor and are not being changed.

No edits, builds or benchmarks were performed by this reviewer. No RSS saving is claimed.
