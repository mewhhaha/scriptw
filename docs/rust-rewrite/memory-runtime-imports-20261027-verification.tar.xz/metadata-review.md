# Import pruning metadata review

Read-only source review at base 787; no build or tests performed.

## Safe scope and integration

Prune unused function/global imports only for P (`ModuleKind::Program`); keep R, all type indices, defined bodies/globals, memories/tables/tags and their order unchanged. Final assembly in `emit/module_assembly.rs`, after custom sections are appended and before `WasmArtifact` construction, is the smallest complete-module seam. Finish the module once, plan live imported entities over the complete module, then reencode. Do not prune a function merely because no direct call uses it: `ref.func`, declarative element entries, exports and start are roots too. Preserve imported globals referenced by any initializer, offset, body or export. Names alone are not executable roots.

The existing `CallableFunctionTableSections::new` emits declarative element entries for every defined callable; these absolute function indices must shift when imported functions disappear. They do not require retaining unused function imports.

## Exact index census

Use `wasm_encoder::reencode::Reencode::{function_index,global_index}` for structural remapping, with removed referenced entities producing an error. Function indices occur in `call`, `return_call`, `ref.func`, exports, start, element function lists and reference expressions (including constant expressions). Global indices occur in `global.get`/`global.set` and any such operators within globals/element/data constant expressions, plus global exports. All retained defined function indices shift by the number of preceding deleted function imports; defined global indices similarly shift by deleted global imports. Filter removed imports while preserving independent index-space counters; type/table/memory/tag indices do not shift.

The standard name custom section needs function/global map remapping and local/label outer function-index remapping. Removed import names must be filtered instead of passed through a mapping that rejects removed indices. `reencode::utils::parse_custom_name_subsection` already handles every surviving name-map index domain; current producer `ModuleFunctionTable::name_section` emits only module name and defined-function names. Existing native-template `reencode/names.rs` demonstrates filtering function/local/label maps.

No other producer custom section found contains absolute function/global indices: compilation profile is one byte; foreign modules are normalized registry JSON; Intl sections are identity/service selection/data frames.

## Opaque metadata: do not remap ordinals

`native_program_contexts.rs`: `ModuleContext.body` is a code-body ordinal, assigned from `records.len()` in `ModuleCode::push`, not an absolute function index. `FunctionContext::Program.local` is a local index; **ready is an operator ordinal, not a global index**. `contexts.rs` checks `operators.take(ready)` and compares enumeration ordinals against it. Bootstrap `payload_operator` is also an operator ordinal. Schema program/payload types and payload field are type/field indices. All remain unchanged for import-only pruning.

`program_literal_operands.rs`: module body and operator are body/operator ordinals; expected Index/Count values are P string-table ordinals/counts, not function/global indices. Ordinary i32 constants are not relocation sites. Reencoding only immediates preserves instruction count/order, so these metadata sections can remain byte-identical even when LEB byte offsets change. Native-template planning decodes fresh operator byte offsets from the final bytes; it does not persist the old offsets. Native-template reencoder later consumes and removes both metadata sections deliberately.

## Concrete integration obligations

`ModuleFunctionTable` owns private records, literal/context sites and type indices; reuse its existing section constructors rather than synthesizing a second wire format. Its `summaries()` exposes absolute `EmittedFunctionSummary.wasm_index`; these must be remapped after pruning. Body sizes can also change when call/global/ref.func immediates cross LEB boundaries. Existing `append_function_attribution`, optional report sink and body-budget enforcement currently run before module.finish, so merely changing artifact bytes leaves reported indices/sizes/budgets stale. Recompute from final encoded bodies (using the existing FunctionBodySize/FunctionLocalCount constructors inside their owner) and publish attribution/budget/report once against that final table. Declared local counts and body order stay unchanged.

`RuntimeLayout::new` must remain based on unpruned R only. Do not modify R export names or its published function/global ranges to match P's compact local index space. P import field names continue referring to the same R exports even though P's imported indices shrink. `gc_host_imports` artifact metadata is the host-import set rather than a custom numeric relocation; if host imports are pruned as well, keep that public registration inventory consistent with retained imports.

No metadata blocker prevents import-only P pruning under these conditions. Required focused contracts: prune unused function+global imports before live defined references; retain a `ref.func`-only import and global initializer/offset-only import; preserve literal/context metadata byte-for-byte and successfully perform subsequent native-template extraction; verify final summary indices/body bytes match actual reencoded bodies at a LEB boundary; R bytes/layout and all type indices unchanged.

## Final numeric payload audit (isolated candidate, before compilation)

One physical-index-derived numeric value exists: `PlannedFunctionEntry::source_id()` in `function_entry/executable_code.rs:11` returns the original planned Wasm index as i64. `emit_executable_code` publishes it as immutable `ExecutableCode.SOURCE_ID` through `gc_types/value.rs` (metadata source_id, then `GcOperand::i64`). This is intentionally a stable P-local identity token, **not a physical dispatch operand**, so leave its numeric constants unchanged. Both consumers compare it against the same original planned token: `functions/numeric_leaf_call.rs:234` additionally checks JavaScript kind and defining-program reference identity; `functions/instance_elements_hook.rs:192` selects a retained constructor plan inside the defining P. Actual invocation uses the separately rooted typed function reference. There is no numeric-to-function-index conversion or table dispatch of SOURCE_ID. Existing native body sharing already changes physical indices while explicitly preserving SOURCE_ID (`native_program_template/share_bodies/mapping.rs:82`, corresponding tests). Import pruning needs no relocation or retain rule for these identities; selectively remapping their publication without their comparisons would be wrong.

`PlannedFunctionEntry`'s physical executable use is centralized in `function_entry.rs`: `emit_reference` emits `ref.func(self.wasm_index)` and direct invocation emits `call(self.wasm_index)`, both handled by structural remapping. ProgramHook fields retain typed function references, not numeric table slots. Runtime helper indices likewise become structural call/ref.func operands; exports retain names and remap their index fields.

Other inspected numeric constants are semantic domains: realm intrinsic-table slots; lexical/private/environment slots; template source IR IDs and cache slots; builtin/host IDs; P literal ordinals/counts; native payload offsets/domains and cache-page constants. TemplateSource SOURCE_ID in `emit/template_objects.rs` comes from semantic `source.id().index()`, distinct from the executable token above. No numeric physical global index payload, static-data function/global index table, or additional opaque physical index carrier was found. No `call_indirect`/numeric table-based dispatch was found in the inspected function/GC emitters.

Result: structural remapping plus already reviewed names/attribution is sufficient for the current producer. Preserve stable SOURCE_ID tokens unchanged. This is a source audit, not executed verification.
