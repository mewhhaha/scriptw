# Producer P import pruning review

Read-only source review at base 787; no builds or workloads.

## Minimal collector

Use wasm-encoder 0.245.1 Reencode::parse_core_module with function_index/global_index hooks that record references and return identity indices. Delegate the standard adapters instead of enumerating a subset of opcodes. Skip custom sections entirely during collection. Override parse_element only for ElementKind::Declared + ElementItems::Functions: those plain declaration lists do not make runtime roots. All other element forms retain default traversal, including declarative expressions (conservative), passive functions/expressions, active offset expressions and contents. Keep every defined body and type, even unreachable bodies: their references remain roots. Exported functions/globals and start functions are roots as well.

Default utils::instruction is generated from wasmparser::for_each_operator and dispatches function_index/global_index fields through the hooks. Global initializers, TableInit::Expr, active data offsets, active element offsets and expression elements use const_expr and therefore the same hooks. Keeping all sections and instruction counts avoids changing data/element/type/body ordinals. Inspect future encoder changes rather than introducing a second operator parser.

## Rewrite invariants

Prune only unused R function/global imports. Keep host and foreign imports unconditionally; preserve all memory/table/tag imports and all definitions. ImportSectionReader contains grouped Imports: flatten via into_imports or handle Single/Compact1/Compact2 explicitly. Exhaustively match TypeRef::{Func, FuncExact, Global, Memory, Table, Tag}; FuncExact occupies the function namespace. Maintain independent original function/global counters, checked u32 counts, and old-index -> Option<new-index> vectors spanning imports and definitions. A reference to a removed index is an error, never map to zero. Definitions shift by the removed import count in their own namespace.

For plain declarative function lists, retain the segment and its position, filtering removed function indices before remapping. Do not delete an empty segment: elem.drop/array.new_elem/table.init indices must remain stable. Retain/remap references in every other element form. Every remaining ref.func must still be declared by a retained declaration/export/other valid declaring use; filtering only removed functions preserves that invariant.

## Names and custom sections

Default name adapters call function_index for Function and the OUTER index of Local/Label indirect maps, and global_index for Global. They must not run during collection. During rewriting, filter removed Function/Global rows and removed Local/Label outer rows, then remap retained rows; inner local/label indices stay unchanged. Type/Field/Table/Memory/Element/Data/Tag indices stay unchanged. Reject unknown name subsections if the contract requires all index-bearing metadata understood; the default silently copies them raw.

Actual module assembly emits name, scriptw.native_program.literal_operands, scriptw.native_program.contexts, source-compilation-profile, foreign.v2, and conditional Intl identity/service-selection/component data customs. The two native-program relocation customs encode defined-body ordinals plus operator ordinals, not absolute function/global indices or byte offsets. Program.ready is an operator ordinal. Copy unchanged if body and operator order/count remain unchanged. Profile/foreign/Intl payloads are not Wasm function/global index maps. At the final producer-P seam prefer an explicit exact allowlist of these owned formats and reject unknown customs; default Reencode copies unknown customs byte-for-byte and cannot prove relocation safety. Intl customs are emitted only by owns_globals paths; do not add broad scriptw.* acceptance.

Existing native_program_template/reencode.rs and reencode/names.rs demonstrate filtered declarative function lists and Function/Local/Label filtering. Its default Global-name behavior is insufficient when globals are removed. Its template transformation also intentionally changes body instructions; do not reuse those semantic transformations for this final producer pass.

## Attribution

EmittedFunctionSummary.wasm_index is absolute and must be remapped. body_bytes is promised exact: shorter remapped LEBs can change encoded body lengths even though instruction count is unchanged. Recompute from final CodeSectionEntry ranges or run attribution after the rewrite. debug_dump and optional size-report-file output currently happen before final WasmArtifact assembly, so avoid publishing stale indices/sizes through those sinks. Native relocation ordinal metadata stays valid despite byte-size changes.

## Focused controls for parent

Cover ref.func-only imports with declarative lists, names-only removed imports (including Local/Label/Global), active/passive/expr elements, global/table initializers and data offsets, exported imports/start roots, FuncExact and mixed namespaces, retained host/foreign imports, unknown custom rejection, and unchanged context/literal ordinals. Include import-count boundaries crossing u32 LEB widths and verify final exact function summaries. Validate rewritten P with the existing full validator before facts/identity minting and native-template creation.
