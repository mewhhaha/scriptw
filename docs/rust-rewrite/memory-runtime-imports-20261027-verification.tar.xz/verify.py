from datetime import datetime,timezone
import hashlib,json,os,subprocess,sys,time
from pathlib import Path
ROOT=Path('/home/mewhhaha/src/porffor');BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'scripts'))
from limited_verification import require_kernel_budget,kernel_group
require_kernel_budget(4*1024**3);assert len(os.sched_getaffinity(0))==1
SOURCE=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip();group=kernel_group()
def budget():return {k:(group/k).read_text().strip() for k in ['memory.max','memory.swap.max','memory.oom.group','memory.peak','memory.events']}
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
report=dict(source_commit=SOURCE,complete=False,started_at=datetime.now(timezone.utc).isoformat(),before=budget(),cpu_affinity=sorted(os.sched_getaffinity(0)),commands=[])
def save():(BASE/'verification.json').write_text(json.dumps(report,indent=2)+'\n')
build=ROOT/'target/performance-work-20261024/build'
plan=[('cheap-main-driver',[sys.executable,'-B',str(BASE/'cheap-main-current.py')]),('native-driver',[sys.executable,'-B',str(BASE/'native.py')]),('cargo-products',['cargo','build','--locked','--offline','--release','--jobs','1','--target-dir',str(build),'-p','scriptw-cli','--bin','scriptw','--example','compiler_precompiled_baseline','--message-format=json']),('test262-driver',[sys.executable,'-B',str(BASE/'test262.py')])]
save()
for label,args in plan:
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==SOURCE
 assert not subprocess.check_output(['git','diff','--binary','HEAD','--','crates','vendor','scripts','Cargo.toml','Cargo.lock'],cwd=ROOT)
 print(label,'started',flush=True);out=BASE/(label+('.jsonl' if label=='cargo-products' else '.stdout'));err=BASE/(label+'.stderr');row=dict(label=label,command=args,stdout=out.name,stderr=err.name);report['commands'].append(row);save();start=time.monotonic()
 with out.open('xb') as stdout,err.open('xb') as stderr:r=subprocess.run(args,cwd=ROOT,stdout=stdout,stderr=stderr,timeout=10800)
 row.update(exit_code=r.returncode,seconds=time.monotonic()-start,stdout_sha256=sha(out),stderr_sha256=sha(err));save();print(label,'finished',r.returncode,flush=True)
 if r.returncode:
  print(err.read_text()[-12000:],flush=True);raise SystemExit(r.returncode)
report.update(complete=True,finished_at=datetime.now(timezone.utc).isoformat(),after=budget());save();print('verification complete',flush=True)
