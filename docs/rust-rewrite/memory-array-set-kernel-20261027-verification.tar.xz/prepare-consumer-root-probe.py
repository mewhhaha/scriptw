"""Prepare an unscored linking probe; do not build or execute it here.

The root source and all delegated execution/configuration code stay identical.
Only two source-producer command arms disappear in the consumer-only variant.
"""
from pathlib import Path
import hashlib,json
BASE=Path(__file__).resolve().parent;ROOT=BASE.parents[1]
original=ROOT/'crates/scriptw-cli/examples/compiler_precompiled_baseline.rs'
text=original.read_text()
paths=['runtime_precompiled/consume.rs','runtime_precompiled/produce.rs','runtime_precompiled/residency.rs','compiler_precompiled_baseline/wasi.rs']
for path in paths:
 old=f'#[path = "{path}"]';assert text.count(old)==1
 text=text.replace(old,f'#[path = "{original.parent/path}"]')
full='#![allow(dead_code)]\n'+text
minimal=full
for arm in [
 '        (Some("prepare-scriptw"), 3) => prepare_scriptw(Path::new(&args[1]), Path::new(&args[2])),\n',
 '        (Some("prepare-wasi"), 3) => wasi::prepare(Path::new(&args[1]), Path::new(&args[2])),\n',
]:
 assert minimal.count(arm)==1;minimal=minimal.replace(arm,'')
folder=BASE/'consumer-root-probe';folder.mkdir(exist_ok=False)
for name,value in [('full',full),('consumer',minimal)]:
 (folder/(name+'.rs')).write_text(value)
record=dict(scope='unscored command-root/link-layout probe; not canonical benchmark output',source_commit='eb9ff7b0552e2b57a8c6b393ee99540b664eb615',source=original.as_posix(),source_sha256=hashlib.sha256(original.read_bytes()).hexdigest(),variants={name:dict(path=name+'.rs',sha256=hashlib.sha256(value.encode()).hexdigest()) for name,value in [('full',full),('consumer',minimal)]},changes='Both variants use the exact original four modules, configuration, worker stack, identity, bindings, execution, observation and formatting code. Consumer variant removes only the two prepare command arms; producer functions may remain unreferenced for linker GC. Same executable serves Scriptw and Scriptc within each variant.',limits='This measures command-root/link-layout effects, not compiler execution or compiler memory alone. Wasmtime Engine constructors may retain compiler code despite disabled compiler. Missing symbols do not establish RSS savings. Keep all results unscored; do not rewrite image provenance or executable identities.')
(folder/'source-record.json').write_text(json.dumps(record,indent=2)+'\n')
print('Prepared two alternate roots; no compilation or guest execution ran.')
