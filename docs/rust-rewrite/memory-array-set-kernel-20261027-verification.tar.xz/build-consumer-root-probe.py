"""Build an unscored command-root pair only after product verification completes.

A transparent rustc wrapper records Cargo's actual dependency/native-link flags.
The repeated debuginfo option has the same value as the workspace profile and
forces only the example root to rebuild; dependency flags remain unchanged.
No downloaded native code is used or executed.
"""
import hashlib,json,os,shutil,subprocess,sys,time
from pathlib import Path
BASE=Path(__file__).resolve().parent;ROOT=BASE.parents[1];OUT=BASE/'consumer-root-probe'
sys.path.insert(0,str(ROOT/'scripts'))
from limited_verification import require_kernel_budget,kernel_group
from precompiled_comparison import digest
require_kernel_budget(4*1024**3);assert len(os.sched_getaffinity(0))==1
verification=json.loads((BASE/'verification.json').read_text());assert verification['complete'] and all(x['exit_code']==0 for x in verification['commands'])
SOURCE=verification['source_commit'];assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==SOURCE
assert SOURCE=='eb9ff7b0552e2b57a8c6b393ee99540b664eb615'
origin=json.loads((OUT/'source-record.json').read_text());assert origin['source_commit']==SOURCE and digest(Path(origin['source']))==origin['source_sha256']
for v in origin['variants'].values():assert digest(OUT/v['path'])==v['sha256']
subprocess.run(['git','diff','--exit-code',SOURCE,'HEAD','--','crates','vendor','Cargo.toml','Cargo.lock','.cargo','rust-toolchain.toml'],cwd=ROOT,check=True,stdout=subprocess.DEVNULL)
records=[json.loads(line) for line in (BASE/'cargo-products.jsonl').read_text().splitlines()]
products=[r for r in records if r.get('reason')=='compiler-artifact' and r.get('executable') and r['target']['name']=='compiler_precompiled_baseline' and not r['profile']['test']];assert len(products)==1
original=Path(products[0]['executable']);frozen=OUT/'original-consumer';assert not frozen.exists();shutil.copy2(original,frozen);assert digest(original)==digest(frozen) and frozen.stat().st_nlink==1
report=dict(scope='unscored command-root/link-layout experiment, not canonical benchmark',source_commit=SOURCE,complete=False,commands=[],binaries={'original':dict(path=str(frozen),sha256=digest(frozen),cargo_producer=products[0])})
def save():(OUT/'build-report.json').write_text(json.dumps(report,indent=2)+'\n')
def run(label,command,env=None,cwd=ROOT):
 row=dict(label=label,argv=list(map(str,command)),cwd=str(cwd));report['commands'].append(row);save();start=time.monotonic()
 with (OUT/(label+'.stdout')).open('xb') as out,(OUT/(label+'.stderr')).open('xb') as err:result=subprocess.run(row['argv'],cwd=cwd,env=env,stdout=out,stderr=err,timeout=600)
 row.update(exit_code=result.returncode,seconds=time.monotonic()-start,stdout_sha256=digest(OUT/(label+'.stdout')),stderr_sha256=digest(OUT/(label+'.stderr')));save();assert result.returncode==0,label
 return (OUT/(label+'.stdout')).read_text()
bindings=json.loads((BASE/'source-bindings-computed.json').read_text());expected_fp=next(r['source_fingerprint'] for r in bindings if r['revision']==SOURCE and r['extra_ignored_regress_lock'])
identity=json.loads(run('identity-original',[frozen,'identity']));assert identity['source_commit']==SOURCE and identity['source_fingerprint']==expected_fp and identity['executable_sha256']==digest(frozen)
report['binaries']['original']['identity']=identity
command=['cargo','rustc','--locked','--offline','--release','--jobs','1','--target-dir',ROOT/'target/performance-work-20261024/build','-p','scriptw-cli','--example','compiler_precompiled_baseline','--message-format=json','--','-C','debuginfo=line-tables-only']
environment=dict(os.environ,RUSTC_WRAPPER=str(BASE/'probe-rustc-capture'))
run('cargo-capture',command,env=environment)
captured=json.loads((OUT/'rustc-command.json').read_text());args=captured['argv']
assert args and args[args.index('--crate-name')+1]=='compiler_precompiled_baseline'
inputs=[(i,arg) for i,arg in enumerate(args) if arg.endswith('examples/compiler_precompiled_baseline.rs')];assert len(inputs)==1
source_index,original_input=inputs[0];assert (Path(captured['cwd'])/original_input).resolve()==Path(origin['source']).resolve()
for variant in ('full','consumer'):
 executable=OUT/(variant+'-consumer');assert not executable.exists()
 rewritten=[];index=0
 while index<len(args):
  arg=args[index]
  if index==source_index:rewritten.append(str(OUT/(variant+'.rs')));index+=1
  elif arg in ('--out-dir','-o'):
   index+=2
  elif arg=='-C' and args[index+1].startswith('extra-filename='):
   index+=2
  elif arg.startswith('-Cextra-filename='):
   index+=1
  elif arg.startswith('--emit='):
   rewritten.append('--emit=link');index+=1
  elif arg=='--emit':
   rewritten+=['--emit','link'];index+=2
  else:rewritten.append(arg);index+=1
 rewritten+=['-o',str(executable)]
 run('rustc-'+variant,rewritten,env=dict(os.environ,**captured['env']),cwd=Path(captured['cwd']))
 assert executable.stat().st_nlink==1
 actual=json.loads(run('identity-'+variant,[executable,'identity']));assert actual['source_commit']==SOURCE and actual['source_fingerprint']==expected_fp and actual['executable_sha256']==digest(executable)
 report['binaries'][variant]=dict(path=str(executable),sha256=digest(executable),bytes=executable.stat().st_size,identity=actual)
 save()
report.update(complete=True,interpretation='Only two producer dispatch arms differ between private roots. Same captured Cargo rustc dependencies, native link paths, policy, modules and effective flags. Original frozen host retained as a reconstruction control. No guest or native image was executed by this builder; identity commands only. Runtime/compiler code may still remain linked. Native provenance must come from a subsequent fresh owned producer, never a hash or download.')
save();print('Unscored consumer-root build complete.')
