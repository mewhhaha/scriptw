"""Private unscored command-root probe; run only after its owned builder completes.

Only fresh local producer outputs may reach native deserialization. Downloaded
inputs are inert Wasm validated by the historical reader and fresh Module::new.
No native image, executable, or this report belongs in canonical publication.
"""
import importlib.util
import json
import os
from pathlib import Path
import statistics
import subprocess
import sys
import time
from datetime import datetime, timezone

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
PAIR = BASE/'consumer-root-probe'
OUT = PAIR/'run'
CI = BASE/'github-40456976322/precompiled-measurements/precompiled-evidence'
SOURCE = 'eb9ff7b0552e2b57a8c6b393ee99540b664eb615'
FP = '36109b4e34386143b6c6ddc8a275c735ec541041b18f35ce9f87cdb37e790645'
VARIANTS = ('original', 'full', 'consumer')
NAMES = ('integer.js', 'retained-objects.js')
sys.path.insert(0, str(ROOT/'scripts'))
import precompiled_comparison as p
from limited_verification import require_kernel_budget

spec = importlib.util.spec_from_file_location('probe_mapping_helpers', ROOT/'scripts/diagnose-precompiled-mappings.py')
helpers = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helpers)


def stamp():
    return datetime.now(timezone.utc).isoformat()


def plan():
    first = []
    for case_index, name in enumerate(NAMES):
        shift = case_index % len(VARIANTS)
        variants = VARIANTS[shift:] + VARIANTS[:shift]
        for variant_index, variant in enumerate(variants):
            runtimes = ('scriptw', 'scriptc')
            if (case_index + variant_index) % 2:
                runtimes = tuple(reversed(runtimes))
            for runtime in runtimes:
                first.append(dict(round=0, file=name, variant=variant, runtime=runtime))
    # Exact reverse of case/variant/runtime order in the second round.
    return first + [dict(task, round=1) for task in reversed(first)]


def run():
    OUT.mkdir(exist_ok=False)
    (OUT/'logs').mkdir()
    report = dict(schema='scriptw-private-consumer-root-probe-v1', scored=False,
                  independent_probe=True, complete=False, source_commit=SOURCE, started_at=stamp(), commands=[], attempts=[],
                  expected_consumers=24, samples=7, warmups=10, rounds=2,
                  publication_excludes=['native images', 'executables', 'canonical score/graph mutations'],
                  scope='command-root/link-layout intervention; not compiler execution/memory isolation',
                  limitations='endpoint medians are descriptive; missing symbols do not establish RSS savings')
    def checkpoint():
        pending = OUT/'report.pending.json'
        pending.write_text(json.dumps(report, indent=2)+'\n')
        pending.replace(OUT/'report.json')
    checkpoint()
    environment = dict(os.environ)
    for key in list(environment):
        if key.startswith(('SCRIPTW_WASM_TRACE', 'SCRIPTW_ROW_PERF_', 'SCRIPTW_BOUNDARY_READY_')) or key in (
                'SCRIPTW_PERF_MAP_DIR', 'SCRIPTW_EMIT_SIZE_REPORT', 'NODE_OPTIONS', 'NODE_COMPILE_CACHE'):
            environment.pop(key, None)

    def invoke(identifier, argv, timeout=180):
        event = dict(id=identifier, argv=list(map(str, argv)), cwd=str(ROOT), started_at=stamp(),
                     stdout='logs/'+identifier+'.stdout', stderr='logs/'+identifier+'.stderr', status='running')
        report['commands'].append(event)
        checkpoint()
        process = None
        started = time.monotonic()
        try:
            with (OUT/event['stdout']).open('xb') as out, (OUT/event['stderr']).open('xb') as err:
                process = subprocess.Popen(event['argv'], cwd=ROOT, env=environment,
                    stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True)
                event['owned_pid'] = process.pid
                checkpoint()
                helpers.drain_owned(process, {'stdout':out, 'stderr':err}, lambda: None, deadline=timeout)
            event.update(returncode=process.returncode, status='ok' if process.returncode == 0 else 'failed')
        except (OSError, ValueError, subprocess.SubprocessError) as error:
            event.update(status='failed', error=str(error))
        finally:
            if process is not None:
                if process.poll() is None:
                    helpers.kill_owned_group(process)
                    process.wait(timeout=2)
                event['returncode'] = process.returncode
            for stream in ('stdout', 'stderr'):
                path = OUT/event[stream]
                if path.exists():
                    event[stream+'_bytes'] = path.stat().st_size
                    event[stream+'_sha256'] = p.digest(path)
            event.update(finished_at=stamp(), seconds=time.monotonic()-started)
            checkpoint()
        return event

    def value(event):
        p.require(event['status'] == 'ok' and (OUT/event['stderr']).stat().st_size == 0,
                  'failed command/diagnostics: '+event['id'])
        return helpers.unique_json(helpers.bounded_read(OUT/event['stdout']))

    try:
        require_kernel_budget(4*1024**3)
        p.require(len(os.sched_getaffinity(0)) == 1, 'one CPU required')
        report['resources'] = dict(before=helpers.kernel_budget())
        report['environment'] = {key:environment.get(key) for key in ('SCRIPTW_WASM_TRACE', 'SCRIPTW_WASM_TRACE_DUMP',
            'SCRIPTW_PERF_MAP_DIR', 'SCRIPTW_ROW_PERF_CONTROL', 'SCRIPTW_BOUNDARY_READY_FD', 'SCRIPTW_EMIT_SIZE_REPORT',
            'CARGO_BUILD_JOBS', 'SCRIPTW_JOBS', 'RUST_TEST_THREADS', 'RAYON_NUM_THREADS',
            'SCRIPTW_MODULE_MEMORY_CACHE_ENTRIES', 'SCRIPTW_MODULE_MEMORY_CACHE_LIMIT_BYTES')}
        checkpoint()
        verification = json.loads((BASE/'verification.json').read_text())
        p.require(verification['complete'] and verification['source_commit'] == SOURCE
                  and all(row['exit_code'] == 0 for row in verification['commands']), 'verification incomplete')
        build = json.loads((PAIR/'build-report.json').read_text())
        p.require(build['complete'] and build['source_commit'] == SOURCE
                  and set(build['binaries']) == set(VARIANTS)
                  and all(row['exit_code'] == 0 for row in build['commands']), 'probe builder incomplete')
        source_record = json.loads((PAIR/'source-record.json').read_text())
        p.require(source_record['source_commit'] == SOURCE, 'alternate source identity differs')
        p.require(p.digest(Path(source_record['source'])) == source_record['source_sha256'], 'original source changed')
        for variant, row in source_record['variants'].items():
            p.require(p.digest(PAIR/row['path']) == row['sha256'], 'alternate command root changed')
        binaries = {}
        for variant in VARIANTS:
            row = build['binaries'][variant]
            host = Path(row['path'])
            p.require(host == PAIR/(('original' if variant == 'original' else variant)+'-consumer')
                      and host.resolve() == host, 'not the owned frozen builder executable')
            helpers.owned_file(host)
            p.require(p.digest(host) == row['sha256'], 'builder executable changed')
            binaries[variant] = host
        report.update(source_commit=SOURCE, source_fingerprint=FP,
                      source_fingerprint_scheme='scriptw-program-cache-compiler-v3',
                      builder_report_sha256=p.digest(PAIR/'build-report.json'),
                      source_record_sha256=p.digest(PAIR/'source-record.json'),
                      binaries={name:dict(path=str(path), sha256=build['binaries'][name]['sha256'])
                                for name,path in binaries.items()}, plan=plan())
        p.require(len(report['plan']) == 24, 'unexpected probe plan')

        def check_inputs():
            p.require(subprocess.check_output(['git','rev-parse','HEAD'], cwd=ROOT, text=True).strip() == SOURCE,
                      'source HEAD changed')
            p.require(p.digest(PAIR/'build-report.json') == report['builder_report_sha256']
                      and p.digest(PAIR/'source-record.json') == report['source_record_sha256'], 'builder records changed')
            p.require(p.digest(Path(source_record['source'])) == source_record['source_sha256'], 'original source changed')
            for name, path in binaries.items():
                helpers.owned_file(path)
                p.require(p.digest(path) == report['binaries'][name]['sha256'], 'frozen executable changed')
            for row in source_record['variants'].values():
                p.require(p.digest(PAIR/row['path']) == row['sha256'], 'alternate root changed')

        def identity(variant, stage):
            raw = value(invoke('identity-'+stage+'-'+variant, [binaries[variant], 'identity']))
            p.require(raw['schema'] == 'scriptw-precompiled-shared-host-v1'
                      and raw['adapter'] == 'shared' and raw['source_commit'] == SOURCE
                      and raw['source_fingerprint'] == FP
                      and raw['compiler_identity_scheme'] == report['source_fingerprint_scheme']
                      and raw['executable_sha256'] == report['binaries'][variant]['sha256'], 'actual binary identity differs')
            if 'shared_configuration' not in report:
                config = raw['shared_configuration']
                p.require(set(config) == set(p.SHARED_CONFIGURATION) | {'target_triple'}
                          and all(type(config[key]) is type(val) and config[key] == val
                                  for key,val in p.SHARED_CONFIGURATION.items()), 'actual producer/consumer config differs')
                report['shared_configuration'] = config
            p.require(raw['shared_configuration'] == report['shared_configuration'], 'variant config differs')
            report['binaries'][variant]['identity_'+stage] = raw
            checkpoint()

        check_inputs()
        for variant in VARIANTS:
            identity(variant, 'before')
        evidence, _ = p.load_report(CI/'report.json')
        bindings = json.loads((BASE/'source-bindings-computed.json').read_text())
        clean_fp = next(row['source_fingerprint'] for row in bindings if row['revision'] == SOURCE and not row['extra_ignored_regress_lock'])
        p.require(evidence['source_commit'] == SOURCE and evidence['source_fingerprint'] == clean_fp
                  and evidence['shared_configuration'] == report['shared_configuration'],
                  'successful inert CI source identity differs')
        report['inert_ci_report'] = dict(path=str(CI/'report.json'), sha256=p.digest(CI/'report.json'), source_fingerprint=clean_fp, interpretation='Only validated inert SC Wasm is reused; fresh native images are produced by the local matching-library owner. CI and local ignored-lock fingerprints remain distinct.')
        cases = {name:next(row for row in evidence['workloads'] if row['file'] == name) for name in NAMES}
        fixtures = OUT/'sources'
        fixtures.mkdir()
        (OUT/'images').mkdir()
        for name in NAMES:
            source = ROOT/p.FIXTURES/name
            retained = CI/'sources'/name
            p.require(p.digest(source) == p.digest(retained), 'canonical source checksum differs')
            (fixtures/name).write_bytes(source.read_bytes())
        (fixtures/'manifest.json').write_text(json.dumps(dict(execution=list(cases.values())))+'\n')
        report['sources'] = {name:dict(sha256=p.digest(fixtures/name), expected_stdout=cases[name]['stdout']) for name in NAMES}
        original = binaries['original']
        pseudo = dict(source_commit=SOURCE, source_fingerprint=FP,
                      source_fingerprint_scheme=report['source_fingerprint_scheme'],
                      shared_configuration=report['shared_configuration'], tools=dict(consumer=dict(sha256=report['binaries']['original']['sha256'])))
        produced_event = invoke('prepare-scriptw', [original, 'prepare-scriptw', fixtures, OUT/'images/scriptw'], 900)
        produced = value(produced_event)
        p._identity(produced, pseudo)
        p.require(produced['compiler_enabled'] is True and produced['shared_configuration'] == report['shared_configuration']
                  and produced['manifest_sha256'] == p.digest(fixtures/'manifest.json')
                  and len(produced['cases']) == 2, 'fresh Scriptw producer receipt differs')
        images = {}
        for name in NAMES:
            row = next(row for row in produced['cases'] if row['file'] == name)
            image = OUT/'images/scriptw'/row['image']
            p.require(image.parent == OUT/'images/scriptw', 'unexpected producer path')
            helpers.owned_file(image)
            metadata = p.image_metadata(image.read_bytes(), 'scriptw', FP)
            p.require(row['source_sha256'] == report['sources'][name]['sha256']
                      and row['source_compilation_profile'] == 'portable' and row['intl_profile'] == 'Minimal'
                      and row['stdout'] == cases[name]['stdout'],
                      'Scriptw source/profile receipt differs')
            p.require(row['image_sha256'] == metadata['sha256'] and row['image_bytes'] == metadata['bytes']
                      and all(row[key] == metadata[key] for key in ('program_wasm_sha256','program_wasm_bytes',
                          'native_serialized_bytes','runtime_key','execution_facts_bytes','execution_facts_sha256')),
                      'fresh Scriptw image/receipt correspondence differs')
            images['scriptw',name] = dict(path=str(image), metadata=metadata, producer=produced_event['id'])
        for name in NAMES:
            item = next(row for row in evidence['attempts'] if row['file'] == name and row['runtime'] == 'scriptc' and row['round'] == 0)
            p.require(item['status'] == 'ok', 'no successful inert Scriptc source')
            raw = CI/item['wasm']
            p.require(raw.resolve().is_relative_to(CI.resolve()) and raw.read_bytes()[:8] == b'\0asm\x01\0\0\0'
                      and p.digest(raw) == item['image']['program_wasm_sha256'], 'inert raw Wasm identity differs')
            copy = OUT/(name+'.scriptc.wasm')
            copy.write_bytes(raw.read_bytes())
            image = OUT/'images'/(name+'.cwasm')
            event = invoke('prepare-wasi-'+name, [original, 'prepare-wasi', copy, image], 900)
            receipt = value(event)
            p._identity(receipt, pseudo)
            helpers.owned_file(image)
            metadata = p.image_metadata(image.read_bytes(), 'scriptc', FP)
            p.require(receipt['compiler_enabled'] is True and receipt['shared_configuration'] == report['shared_configuration']
                      and receipt['image_sha256'] == metadata['sha256'] and receipt['image_bytes'] == metadata['bytes']
                      and receipt['program_wasm_sha256'] == metadata['program_wasm_sha256'] == p.digest(copy)
                      and receipt['native_serialized_bytes'] == metadata['native_serialized_bytes'], 'fresh WASI producer receipt differs')
            images['scriptc',name] = dict(path=str(image), metadata=metadata, producer=event['id'],
                                        inert_wasm_path=str(raw), inert_wasm_sha256=p.digest(raw))
        report['images'] = [dict(runtime=runtime, file=name, **row) for (runtime,name),row in images.items()]
        checkpoint()
        check_inputs()
        for task in report['plan']:
            attempt = dict(task, status='running')
            report['attempts'].append(attempt)
            checkpoint()
            row = images[task['runtime'],task['file']]
            try:
                p.require(p.digest(Path(row['path'])) == row['metadata']['sha256'], 'owned producer image changed')
                identifier = 'r'+str(task['round'])+'-'+task['variant']+'-'+task['runtime']+'-'+task['file']
                event = invoke(identifier, [binaries[task['variant']],
                    'execute-scriptw' if task['runtime'] == 'scriptw' else 'execute-wasi',
                    row['path'], cases[task['file']]['stdout'], '7', '10'])
                attempt['command'] = event['id']
                raw = value(event)
                expected = dict(pseudo, tools=dict(consumer=dict(sha256=report['binaries'][task['variant']]['sha256'])))
                _, matched = p._consumer(raw, expected, row['metadata'], cases[task['file']], task['runtime'])
                p.require(matched, 'normal completion/output mismatch')
                attempt.update(status='ok', validated=True)
            except (OSError, ValueError, KeyError) as error:
                attempt.update(status='failed', error=str(error))
            checkpoint()
        check_inputs()
        for row in images.values():
            p.require(p.digest(Path(row['path'])) == row['metadata']['sha256'], 'owned native image changed')
        for variant in VARIANTS:
            identity(variant, 'after')
        report['summaries'] = []
        for name in NAMES:
            for variant in VARIANTS:
                for runtime in ('scriptw','scriptc'):
                    attempts = [row for row in report['attempts'] if row['file'] == name and row['variant'] == variant and row['runtime'] == runtime]
                    if len(attempts) != 2 or any(row['status'] != 'ok' for row in attempts):
                        continue
                    raw = [value(next(event for event in report['commands'] if event['id'] == row['command'])) for row in attempts]
                    measured = [o for run in raw for o in run['observations'][10:]]
                    report['summaries'].append(dict(file=name,variant=variant,runtime=runtime,measured_observations=len(measured),
                        execution_ns_median=statistics.median(o['phases_ns']['execution'] for o in measured),
                        endpoint_medians={phase:{field:statistics.median(o['process_snapshots'][phase][field] for o in measured)
                            for field in p.MEMORY_FIELDS} for phase in p.PROCESS_PHASES},
                        after_transport_drop=[run['process_snapshots']['after_transport_drop'] for run in raw]))
        report['complete'] = len(report['attempts']) == 24 and all(row['status'] == 'ok' for row in report['attempts'])
    except (OSError, ValueError, KeyError, StopIteration, subprocess.SubprocessError) as error:
        report['error'] = str(error)
    finally:
        try:
            report.setdefault('resources', {})['after'] = helpers.kernel_budget()
        except (OSError, ValueError) as error:
            report['resource_after_error'] = str(error)
        report['finished_at'] = stamp()
        checkpoint()
    print('Private unscored consumer-root probe complete:', report['complete'], OUT/'report.json')
    return 0 if report['complete'] else 1


if __name__ == '__main__':
    raise SystemExit(run())
