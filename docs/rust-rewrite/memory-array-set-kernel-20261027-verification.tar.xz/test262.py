"""Discover and execute original pinned Array/TypedArray cases, no status publish."""
from datetime import datetime,timezone
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parents[2]
BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'scripts'))
from limited_verification import require_kernel_budget,kernel_group
from precompiled_comparison import digest
require_kernel_budget(4*1024**3)
assert len(os.sched_getaffinity(0))==1
SOURCE=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
with (BASE/'mapping-diagnostic.stdout').open('xb') as out,(BASE/'mapping-diagnostic.stderr').open('xb') as err:
 subprocess.run([sys.executable,'-B',str(BASE/'mapping-diagnostic-current.py')],cwd=ROOT,stdout=out,stderr=err,timeout=1800,check=True)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==SOURCE
build=[json.loads(x) for x in (BASE/'cargo-products.jsonl').read_text().splitlines()]
assert build[-1]==dict(reason='build-finished',success=True)
records=[x for x in build if x.get('reason')=='compiler-artifact' and x.get('executable')
         and x['target']['name']=='scriptw' and x['target']['kind']==['bin'] and not x['profile']['test']]
assert len(records)==1
output=BASE/'conformance'
output.mkdir(exist_ok=False)
compiler=output/'compiler'
shutil.copy2(records[0]['executable'],compiler)
assert digest(compiler)==digest(records[0]['executable']) and compiler.stat().st_nlink==1
group=kernel_group()
def budget():
 return {k:(group/k).read_text().strip() for k in ('memory.max','memory.swap.max','memory.oom.group','memory.peak','memory.events')}
def stamp():return datetime.now(timezone.utc).isoformat()
report=dict(source_commit=SOURCE,complete=False,started_at=stamp(),commands=[],before=budget(),
 compiler=dict(path=str(compiler),sha256=digest(compiler),cargo_producer=records[0]),
 scope='Exact original pinned Array length/push/sort/join, Proxy define/descriptor/invariant and Object/Reflect own-descriptor executions. Not a full-suite status refresh.')
def save():(output/'report.json').write_text(json.dumps(report,indent=2)+'\n')
def invoke(label,args,timeout=3600):
 event=dict(label=label,command=[str(compiler),'--jobs','1',*map(str,args)],started_at=stamp(),
            stdout=label+'.stdout',stderr=label+'.stderr')
 report['commands'].append(event);save()
 started=time.monotonic()
 with (output/event['stdout']).open('xb') as out,(output/event['stderr']).open('xb') as err:
  process=subprocess.Popen(event['command'],cwd=ROOT,stdout=out,stderr=err,start_new_session=True)
  try:code=process.wait(timeout=timeout)
  except BaseException:
   if process.poll() is None:os.killpg(process.pid,signal.SIGKILL)
   process.wait();raise
 event.update(returncode=code,finished_at=stamp(),seconds=time.monotonic()-started,
  stdout_sha256=digest(output/event['stdout']),stderr_sha256=digest(output/event['stderr']))
 save()
 assert code==0,label+' failed; original streams retained'
 return (output/event['stdout']).read_text()
identity=json.loads(invoke('identity',['compiler-identity']))
assert identity['source_revision']==dict(kind='git-commit',commit=SOURCE)
assert identity['executable_sha256']==report['compiler']['sha256']
report['compiler']['identity']=identity;save()
suite=ROOT/'test262/vendor/test262'
filters=[
 'built-ins/Array/prototype/push/',
 'built-ins/Array/length/',
 'built-ins/Proxy/defineProperty/',
 'built-ins/Array/prototype/sort/',
 'built-ins/Array/prototype/join/',
 'built-ins/Proxy/getOwnPropertyDescriptor/',
 'built-ins/Proxy/get/',
 'built-ins/Proxy/set/',
 'built-ins/Proxy/has/',
 'built-ins/Proxy/deleteProperty/',
 'built-ins/Reflect/set/',
 'built-ins/Object/getOwnPropertyDescriptor/',
 'built-ins/Reflect/getOwnPropertyDescriptor/',
]
selected=[]
for index,pattern in enumerate(filters):
 text=invoke(f'inventory-{index:02d}',['test262','list-all',pattern,'--suite-root',suite],180)
 lines=text.splitlines()
 assert lines and lines[0].startswith('count: ')
 ids=lines[1:]
 assert ids and len(ids)==int(lines[0].removeprefix('count: ')),pattern
 assert all(re.fullmatch(r'(?:sloppy-script|strict-script|module):[^\r\n]+',s) for s in ids)
 selected.extend(ids)
assert selected and len(selected)==len(set(selected))
execution_list=output/'executions'
execution_list.write_text('\n'.join(sorted(selected))+'\n')
report.update(selected_executions=len(selected),execution_list_sha256=digest(execution_list))
save();print('selected',len(selected),'original executions',flush=True)
text=invoke('execute',['test262','run-list',execution_list,'--execution-backend','wasm-aot',
 '--suite-root',suite,'--snapshot-dir',output/'snapshots','--snapshot-name','array-set-kernel',
 '--threads','1','--timeout-ms','60000','--reuse-case-workers'])
total=re.findall(r'^total: (\d+)$',text,re.M)
passed=re.findall(r'^passed: (\d+)$',text,re.M)
assert total==passed==[str(len(selected))]
assert digest(compiler)==report['compiler']['sha256']
report.update(complete=True,finished_at=stamp(),after=budget(),total=len(selected),passed=len(selected),
 snapshots=[dict(file=str(p.relative_to(output)),sha256=digest(p),bytes=p.stat().st_size)
            for p in sorted((output/'snapshots').glob('*.json'))])
save();print('passed',len(selected),'original executions',flush=True)
