# Local frozen-host symbol/PTE attribution

Exact local consumer SHA256: `36887ae307d6688bc180f73278c941d159830e048a8e29383e5a7796e6193114`. Verified against its local report and ELF PT_LOAD segments. One `nm -C -n -S --defined-only --format=posix` invocation; all analysis pinned to CPU0. No builds, tests, guests or native images executed. Raw symbols, reproducible helper and detailed JSON are adjacent `local-host-symbols*` files.

This is the local a9 consumer only. No local symbol/file offset was applied to CI. Byte/page overlaps do not establish function execution. Families are substring groupings including generic Rust instantiations; their page coverage overlaps and cannot be added. Symbol aliases can also duplicate occupied-byte totals. First and sampled-maximum phases are asynchronous, not lifecycle endpoints.

## Local observations

### integer.js

First sample: 6.223 MiB RSS, 1.395 MiB executable RX present. Maximum sample: 24.355 MiB RSS, 9.406 MiB executable RX present. Last RX is 9.406 MiB.

| Symbol family | Present-page coverage KiB | Symbol bytes overlapping present pages KiB |
|---|---:|---:|
| wasmtime/all | 1472 | 787 |
| scriptw_intl | 1208 | 891 |
| scriptw_ir | 1048 | 626 |
| scriptw_engine/all | 952 | 599 |
| wasmtime_environ | 788 | 326 |
| wasmparser | 696 | 505 |
| boa_parser | 624 | 377 |
| serde_json | 400 | 118 |
| zstd/C | 296 | 283 |
| huffman/C | 100 | 83 |
| wasmtime/type_registry | 188 | 40 |
| wasmtime/linker | 148 | 24 |
| scriptw_runtime_image | 44 | 16 |
| scriptw_engine/embedded_runtime | 40 | 16 |

### retained-objects.js

First sample: 6.215 MiB RSS, 1.402 MiB executable RX present. Maximum sample: 38.199 MiB RSS, 9.520 MiB executable RX present. Last RX is 9.520 MiB.

| Symbol family | Present-page coverage KiB | Symbol bytes overlapping present pages KiB |
|---|---:|---:|
| wasmtime/all | 1476 | 791 |
| scriptw_intl | 1216 | 904 |
| scriptw_ir | 1016 | 608 |
| scriptw_engine/all | 952 | 599 |
| wasmtime_environ | 788 | 326 |
| wasmparser | 704 | 506 |
| boa_parser | 620 | 390 |
| serde_json | 352 | 85 |
| zstd/C | 296 | 283 |
| huffman/C | 100 | 83 |
| wasmtime/type_registry | 188 | 40 |
| wasmtime/linker | 148 | 24 |
| scriptw_runtime_image | 44 | 16 |
| scriptw_engine/embedded_runtime | 40 | 16 |

## Concrete source paths and next seam

The largest Scriptw-specific text family is Intl (integer:1208 KiB page coverage /891 KiB overlapping symbol bytes). Its largest resident symbols include `EmbeddedIntlProvider::with_selected_data_images` (~20 KiB), datetime plan selection (~15 KiB), checked collator image construction (~13 KiB), and number-profile decode (~12 KiB). This does not prove eager full-provider setup: current `intl_data_images/deferred.rs:75` only resolves the shared full provider on demand, and `wasm_gc_intl_host.rs` reaches that resolution from actual provider requests. Trusted Cargo admission already uses the minimal owner/identity seam. `intl_data_images::kernel_for_artifact` itself overlaps15 KiB of present pages even though that is the full raw-artifact admission path; overlap alone cannot justify deleting its validation or claiming it runs in the trusted path.

Compiler-only-looking symbols also occupy present pages: Boa parser family624 KiB, scriptw_ir1048 KiB, wasmparser696 KiB, Wasmtime-environ788 KiB. Examples include `ObjectLiteral::parse`21 KiB, `scriptw_ir::regexp_unicode17::unicode17_delta`30 KiB, module execution source19 KiB, and Wasmtime module translation27 KiB. Their coexistence with runtime pages makes instruction-fetch/fault-around/shared-page effects a material confound. No compiler execution inference is valid. A future hot/cold-layout or compile-time runtime-only product split would need its own controlled matched measurement; this table does not establish its savings.

There is direct source proof of eager runtime/link work, so the already-reviewed P-import-pruning + narrow-linker-definition batch is the cleanest actionable runtime seam. `wasm_runtime_link::instantiate` instantiates fixed R then `Linker::instance` enumerates every R export. Wasmtime47 `linker.rs:650` collects all exports, interns names and inserts typed definitions; `vm/instance.rs:853,877` initializes function references. Local symbol coverage for type registry188 KiB, linker148 KiB, GC/VM families is consistent with that eager path but cannot rank its allocation bytes or isolate CI RSS. Preserve full recursive-type identity while pruning P imports; deserialized native R still registers the fixed type set.

Native R loading has a separate bounded-code cost: ZSTD C296 KiB, HUF100 KiB and FSE20 KiB page coverage locally. Runtime-image leaf itself44 KiB and embedded-runtime40 KiB are comparatively small symbol-family coverage. Their algorithms are required for exact native image decode/digest admission; native source/backing ownership changes should not be justified by this symbol table alone.

## Actionable conclusion

Proceed with the independently proven per-P import/link metadata reduction, with exact final index/custom-metadata mappings. Do not implement eager-Intl removal or compiler-path deletion based on these present pages: the source path is already lazy and the evidence is not execution evidence. The next measurement should compare executable RX and anonymous retention before/after that coherent batch using the CI diagnostic, while preserving native R RX/RO as separately attributable components. This analysis supplies concrete local host text families; it does not explain the entire CI2.254 MiB Rust-RX delta causally.
