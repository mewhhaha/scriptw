"""Verify lossless retained bytes, exact native inventories and regenerated graphs."""
import hashlib,json,re,sys,tarfile
from pathlib import Path,PurePosixPath
ROOT=Path(__file__).resolve().parents[2];BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'scripts'))
import precompiled_comparison as p
DOCS=ROOT/'docs/rust-rewrite';record=json.loads((DOCS/'memory-array-set-kernel-20261027.json').read_text());a=record['archive'];archive=DOCS/a['file']
assert p.digest(archive)==a['sha256'] and archive.stat().st_size==a['bytes']<=32*1024**2
expected={x['path']:x for x in record['retained_files']};assert len(expected)==len(record['retained_files'])
seen=set();total=0;reports={};streams={}
with tarfile.open(archive,'r|xz') as tar:
 for member in tar:
  path=PurePosixPath(member.name);assert member.isfile() and member.name in expected and member.name not in seen and not path.is_absolute() and '..' not in path.parts
  assert member.size==expected[member.name]['bytes']<=128*1024**2;total+=member.size;assert total<=2*1024**3
  data=tar.extractfile(member);digest=hashlib.sha256();chunks=[]
  keep=member.name.endswith('/report.json') or member.name in ['source-bindings-computed.json','verification.json','check.json','cheap-main.json'] or member.name.startswith('native/') and member.name.endswith('.stdout')
  for chunk in iter(lambda:data.read(1024**2),b''):
   digest.update(chunk)
   if keep:chunks.append(chunk)
  assert digest.hexdigest()==expected[member.name]['sha256'];seen.add(member.name)
  if keep:
   raw=b''.join(chunks)
   if member.name.endswith('.json'):reports[member.name]=json.loads(raw)
   else:streams[member.name]=raw.decode()
assert seen==set(expected) and len(seen)==a['member_count'] and total==a['expanded_bytes']
native=reports['native/report.json'];assert native==record['native'] and native['complete'] and native['passed_disjoint_scopes']==sum(x['passed'] for x in native['scopes'])
assert reports['conformance/report.json']==record['test262'] and record['test262']['total']==record['test262']['passed']>0
assert reports['source-bindings-computed.json']==record['source_bindings']['rows']
assert len(record['source_bindings']['rows'])==4
assert all(r['revision']==record['verified_source_commit'] for r in record['source_bindings']['rows'][-2:])
assert len(native['scopes'])==15 and native['passed_disjoint_scopes']==4535
assert not any(scope['package']=='scriptw-runtime-image' for scope in native['scopes'])
assert [scope['passed'] for scope in native['scopes'] if scope['target']=='aot_gc_entries']==[213]
assert record['verified_source_commit']=='eb9ff7b0552e2b57a8c6b393ee99540b664eb615'
assert reports['verification.json']==record['checkpoints']['completed']
assert reports['check.json']==record['checkpoints']['typecheck']
assert reports['cheap-main.json']==record['checkpoints']['cheap']
assert reports['mapping-diagnostic-current/report.json']==record['mapping_diagnostic']
for scope in native['scopes']:
 inventory=scope['inventory'];assert len(inventory)==len(set(inventory))==scope['passed'] and scope['complete']
 assert 'inherited_evidence' not in scope
 prefix=scope['package']+'-'+scope['target']+'-part-';rows=[('native/'+c['stdout'],c) for c in native['commands'] if c['label'].startswith(prefix)]
 assert rows
 actual=[]
 for path,command in rows:
  assert command['exit_code']==0;raw=streams[path]
  actual += [s.removesuffix(' - should panic') for s in re.findall(r'^test ([^\r\n]+) \.\.\. ok$',raw,re.M)]
  summaries=re.findall(r'^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',raw,re.M)
  assert len(summaries)==1 and summaries[0][1:4]==('0','0','0')
  assert int(summaries[0][0])+int(summaries[0][4])==len(inventory)
 assert len(actual)==len(inventory) and set(actual)==set(inventory)
report,rows=p.load_report(DOCS/'precompiled-comparison.json',DOCS/'precompiled-comparison.tar.gz');assert report['source_commit']==record['measured_source_commit']==record['verified_source_commit']
assert report['source_fingerprint']==record['source_bindings']['rows'][-2]['source_fingerprint']
assert record['test262']['compiler']['identity']['source_fingerprint']==record['source_bindings']['rows'][-1]['source_fingerprint']
readme=(ROOT/'README.md').read_text()
ratios=[r['runtimes']['scriptw']['rss_mib']/r['runtimes']['scriptc']['rss_mib'] for r in rows]
assert f"**{min(ratios):.1f}–{max(ratios):.1f}× Scriptc's**" in readme
assert f"compiler `{record['verified_source_commit'][:9]}`" in readme
assert f"**{native['passed_disjoint_scopes']:,} native cases and {record['test262']['total']:,} original pinned Test262 executions\npassed**" in readme
for row in rows:
 if row['file'] in ('integer.js','objects.js','retained-objects.js'):
  for rt in p.RUNTIMES:assert f"{row['runtimes'][rt]['rss_mib']:.1f} MiB" in readme
for metric,chart in p.CHARTS.items():assert p.render(report,rows,metric,BASE/f'preview-{metric}.png')==(DOCS/'assets'/chart['filename']).read_bytes()
print(json.dumps(dict(verified=True,source=record['verified_source_commit'],measured_source=report['source_commit'],native=native['passed_disjoint_scopes'],test262=record['test262']['total'],members=len(seen),expanded_bytes=total)))
