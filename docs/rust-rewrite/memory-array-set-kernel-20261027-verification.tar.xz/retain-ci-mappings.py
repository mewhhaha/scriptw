"""Retain only validated inert CI data for the verification archive."""
import hashlib,json,os,shutil,stat,sys
from pathlib import Path
BASE=Path(__file__).resolve().parent;ROOT=BASE.parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
import precompiled_comparison as p
from limited_verification import require_kernel_budget
require_kernel_budget(4*1024**3);assert len(os.sched_getaffinity(0))==1
for run in ['40455594371','40456976322']:
 source=BASE/('github-'+run)/'precompiled-mapping-diagnostic-unscored'
 report=json.loads((source/'report.json').read_text());assert report['status']=='captured'
 target=BASE/('ci-unscored-'+run);target.mkdir(exist_ok=False)
 for path in source.rglob('*'):
  if not path.is_file():continue
  info=path.lstat();assert stat.S_ISREG(info.st_mode) and info.st_size<=32*1024**2
  assert path.name in ('stdout','stderr','report.json') or path.suffix=='.smaps'
  rel=path.relative_to(source);dest=target/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(path,dest);assert p.digest(path)==p.digest(dest)
source=BASE/'github-40455594371/precompiled-measurements/precompiled-evidence'
report,_=p.load_report(source/'report.json');retained=p._retained(source/'report.json',report,None)
target=BASE/'ci-baseline-40455594371';target.mkdir(exist_ok=False)
for name,data in retained.items():
 path=target/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data)
(target/'report.json').write_bytes((source/'report.json').read_bytes())
p.load_report(target/'report.json')
print(json.dumps(dict(retained_baseline_files=len(retained)+1,baseline_inert_bytes=sum(len(x) for x in retained.values())+(source/'report.json').stat().st_size,diagnostic_runs=[40455594371,40456976322])))
