"""Publish only completed source-bound evidence; no native binaries/images."""
from datetime import datetime,timezone
import hashlib,json,lzma,re,tarfile,sys
from pathlib import Path,PurePosixPath
BASE=Path(__file__).resolve().parent;ROOT=BASE.parents[1];DEST=ROOT/'docs/rust-rewrite'
sys.path.insert(0,str(ROOT/'scripts'))
import precompiled_comparison as p
STEM='memory-array-set-kernel-20261027'
def read(path):return json.loads(path.read_text())
def sha(path):
 with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
native=read(BASE/'native/report.json');batch=read(BASE/'verification.json');conf=read(BASE/'conformance/report.json');check=read(BASE/'check.json')
source=native['source_commit'];assert source=='eb9ff7b0552e2b57a8c6b393ee99540b664eb615';assert all(x['complete'] and x['source_commit']==source for x in [native,batch,conf,check])
assert native['passed_disjoint_scopes']==4535
assert len(native['scopes'])==15 and native['passed_disjoint_scopes']==sum(s['passed'] for s in native['scopes'])
assert not any(scope['package']=='scriptw-runtime-image' for scope in native['scopes'])
assert [scope['passed'] for scope in native['scopes'] if scope['target']=='aot_gc_entries']==[213]
assert all(s['complete'] and s['passed']==len(s['inventory']) for s in native['scopes'])
assert conf['passed']==conf['total']>0 and all(c['returncode']==0 for c in conf['commands'])
assert all(c['exit_code']==0 for c in batch['commands'])
cheap=read(BASE/'cheap-main.json');assert cheap['complete'] and cheap['base_commit']==source
assert all(c['returncode']==0 for c in cheap['commands'])
assert check['exit_code']==0
assert sha(BASE/'cargo-check.jsonl')==check['stdout_sha256']
assert sha(BASE/'cargo-check.stderr')==check['stderr_sha256']
mapping=read(BASE/'mapping-diagnostic-current/report.json');assert mapping['complete'] and mapping['source_commit']==source
assert {c['file'] for c in mapping['cases']}=={'integer.js','retained-objects.js'}
assert all(c['complete'] and c['returncode']==0 and c['snapshots'] for c in mapping['cases'])
assert all(c.get('returncode',c.get('exit_code'))==0 for c in mapping['commands'])
# Bind completed command reports to the retained raw streams before publication.
for directory,report in [(BASE/'native',native),(BASE,batch),(BASE,cheap),(BASE/'conformance',conf),(BASE/'mapping-diagnostic-current',mapping)]:
 for command in report['commands']:
  assert command.get('exit_code',command.get('returncode'))==0
  for stream in ['stdout','stderr']:
   assert sha(directory/command[stream])==command[stream+'_sha256']
for scope in native['scopes']:
 assert 'inherited_evidence' not in scope
 inventory=scope['inventory'];assert len(inventory)==len(set(inventory))==scope['passed']
 prefix=scope['package']+'-'+scope['target']+'-part-'
 commands=[c for c in native['commands'] if c['label'].startswith(prefix)];assert commands
 actual=[]
 for command in commands:
  raw=(BASE/'native'/command['stdout']).read_text()
  actual += [name.removesuffix(' - should panic') for name in re.findall(r'^test ([^\r\n]+) \.\.\. ok$',raw,re.M)]
  summaries=re.findall(r'^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',raw,re.M)
  assert len(summaries)==1 and summaries[0][1:4]==('0','0','0')
  assert int(summaries[0][0])+int(summaries[0][4])==len(inventory)
 assert len(actual)==len(inventory) and set(actual)==set(inventory)
for case in mapping['cases']:
 for stream in ['stdout','stderr']:
  assert sha(BASE/'mapping-diagnostic-current'/case['file']/stream)==case[stream+'_sha256']
 trace=(BASE/'mapping-diagnostic-current'/case['file']/'stderr').read_text()
 assert re.findall(r'runtime-native packed source: ([a-z-]+)',trace)==case['source_kinds']
 assert case['source_kinds'] and set(case['source_kinds'])<={'executable-inode','kernel-main-elf'}
 value=read(BASE/'mapping-diagnostic-current'/case['file']/'stdout')
 assert value['source_commit']==source and value['compiler_enabled'] is False
 assert len(value['observations'])==17 and all(o['matched'] and o['completion']=='normal' for o in value['observations'])
 for snapshot in case['snapshots']:
  path=Path(snapshot['path'])
  if not path.is_absolute():path=BASE/'mapping-diagnostic-current'/path
  assert path.resolve().is_relative_to((BASE/'mapping-diagnostic-current').resolve())
  assert path.stat().st_size==snapshot['bytes'] and sha(path)==snapshot['sha256']
bindings=read(BASE/'source-bindings-computed.json');assert len(bindings)==4;clean,local=bindings[-2:];assert clean['revision']==local['revision']==source
assert conf['compiler']['identity']['source_fingerprint']==local['source_fingerprint']
measured,rows=p.load_report(BASE/'github-40456976322/precompiled-measurements/precompiled-evidence/report.json');assert measured['source_commit']==source and measured['source_fingerprint']==clean['source_fingerprint']
for record in [native,batch,conf,check,mapping]:
 for moment in ['before','after']:
  budget=record[moment];assert budget['memory.max']=='4294967296' and budget['memory.swap.max']=='0' and budget['memory.oom.group']=='1'
 before=dict(line.split() for line in record['before']['memory.events'].splitlines());after=dict(line.split() for line in record['after']['memory.events'].splitlines())
 assert all(before[k]==after[k] for k in ['oom','oom_kill','oom_group_kill'])
lock=ROOT/'vendor/regress-0.10.5/Cargo.lock';provenance=BASE/'provenance';provenance.mkdir(exist_ok=True);(provenance/'ignored-regress-Cargo.lock').write_bytes(lock.read_bytes())
# Optional private experiments never gate verified product publication. Retain
# incomplete/failed metadata and raw streams as explicitly unscored evidence.
probe_dir=BASE/'consumer-root-probe';probe_metadata={}
for report_path in probe_dir.rglob('*report.json'):
 value=read(report_path);assert value.get('source_commit')==source
 probe_metadata[str(report_path.relative_to(BASE))]=dict(complete=value.get('complete') is True,sha256=sha(report_path))
files=[]
for path in sorted(BASE.rglob('*')):
 if not path.is_file():continue
 rel=path.relative_to(BASE).as_posix();parts=PurePosixPath(rel).parts
 if parts[0].startswith('github-') or 'images' in parts or path.name.startswith(('publication.','preview-')):continue
 if path.suffix not in ['.py','.json','.jsonl','.stdout','.stderr','.smaps','.txt','.lock','.presentbits','.rs','.md','.nm'] and path.name not in ['executions','stdout','stderr','probe-rustc-capture'] and parts[0]!='ci-baseline-40455594371':continue
 assert not path.is_symlink() and path.stat().st_size<=128*1024**2
 assert '..' not in parts and not PurePosixPath(rel).is_absolute()
 with path.open('rb') as f:assert not f.read(8).startswith((b'\x7fELF',b'MZ',b'SCRWEP01',b'SCRWEP02',b'SCRWWA01'))
 files.append(dict(path=rel,bytes=path.stat().st_size,sha256=sha(path)))
retained={row['path'] for row in files}
assert all('mapping-diagnostic-current/'+case['file']+'/'+stream in retained for case in mapping['cases'] for stream in ['stdout','stderr'])
expanded=sum(row['bytes'] for row in files);assert expanded<=2*1024**3
archive=DEST/(STEM+'-verification.tar.xz');assert not archive.exists()
with archive.open('xb') as output,lzma.LZMAFile(output,'w',format=lzma.FORMAT_XZ,filters=[dict(id=lzma.FILTER_LZMA2,preset=1,dict_size=64*1024**2)]) as compressed:
 with tarfile.open(fileobj=compressed,mode='w|',format=tarfile.PAX_FORMAT) as tar:
  for row in files:
   member=tarfile.TarInfo(row['path']);member.size=row['bytes'];member.mode=0o644
   with (BASE/row['path']).open('rb') as stream:tar.addfile(member,stream)
assert archive.stat().st_size<=32*1024**2
seen=set();roundtrip=0;inventory={row['path']:row for row in files}
with tarfile.open(archive,'r|xz') as tar:
 for member in tar:
  assert member.isfile() and member.name in inventory and member.name not in seen
  row=inventory[member.name];assert member.size==row['bytes']<=128*1024**2
  stream=tar.extractfile(member);assert hashlib.file_digest(stream,'sha256').hexdigest()==row['sha256']
  seen.add(member.name);roundtrip+=member.size;assert roundtrip<=2*1024**3
assert seen==set(inventory) and roundtrip==expanded
record=dict(schema='scriptw-array-set-kernel-memory-verification-v1',recorded_at=datetime.now(timezone.utc).isoformat(),verified_source_commit=source,measured_source_commit=measured['source_commit'],source_bindings=dict(rows=bindings,ignored_extra=dict(path=str(lock.relative_to(ROOT)),bytes=lock.stat().st_size,sha256=sha(lock))),native=native,test262=conf,mapping_diagnostic=mapping,optional_unscored_probes=probe_metadata,checkpoints=dict(typecheck=check,completed=batch,cheap=cheap),interpretation='Complete affected native inventories and exact original selected Test262 executions. This is not a full pinned-suite refresh. CI uses clean Git compiler inputs; local verification additionally fingerprints the retained ignored standalone dependency lock. No fresh collector controls or unchanged standalone Intl/output-publication/runtime-image suites are claimed. Mapping diagnostics are unscored. Failed attempts are retained. Native binaries and serialized native images are excluded.',archive=dict(file=archive.name,sha256=sha(archive),bytes=archive.stat().st_size,expanded_bytes=expanded,member_count=len(files),max_expanded_bytes=2*1024**3,max_member_bytes=128*1024**2),retained_files=files)
target=DEST/(STEM+'.json');assert not target.exists();target.write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(dict(native=native['passed_disjoint_scopes'],test262=conf['total'],archive=record['archive']),indent=2))
