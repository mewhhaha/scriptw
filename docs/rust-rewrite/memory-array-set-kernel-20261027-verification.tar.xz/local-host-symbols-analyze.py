"""Offline local executable symbol/PTE overlap, no native execution."""
import bisect,hashlib,json,struct
from pathlib import Path
ROOT=Path('/home/mewhhaha/src/porffor')
BASE=ROOT/'target/memory-array-internal-descriptors-20261027-evidence/mapping-diagnostic-current'
OUT=ROOT/'target/memory-array-set-kernel-20261027-evidence'
r=json.loads((BASE/'report.json').read_text())
with (BASE/'consumer').open('rb') as f:
 h=f.read(64); phoff=struct.unpack_from('<Q',h,32)[0]; phsize,phnum=struct.unpack_from('<HH',h,54)
 assert h[:6]==b'\x7fELF\x02\x01' and phsize==56 and phnum<1024
 f.seek(phoff);p=f.read(phsize*phnum)
 loads=[]
 for i in range(phnum):
  typ,flags,off,addr,_,size,_,_=struct.unpack_from('<IIQQQQQQ',p,i*phsize)
  if typ==1:loads.append((addr,addr+size,off,flags))
 f.seek(0); digest=hashlib.file_digest(f,'sha256').hexdigest()
assert digest==r['executable_sha256']=='36887ae307d6688bc180f73278c941d159830e048a8e29383e5a7796e6193114'
needles={
 'wasmtime/all':'wasmtime::','wasmtime/type_registry':'wasmtime::runtime::type_registry',
 'wasmtime/gc':'wasmtime::runtime::gc','wasmtime/vm_gc':'wasmtime::runtime::vm::gc',
 'wasmtime/serialization':'wasmtime::runtime::serialization','wasmtime/module':'wasmtime::runtime::module',
 'wasmtime/linker':'wasmtime::runtime::linker','wasmtime/instance':'wasmtime::runtime::instance',
 'wasmtime/types':'wasmtime::runtime::types','wasmtime/vm':'wasmtime::runtime::vm',
 'wasmtime_environ':'wasmtime_environ::','wasmparser':'wasmparser::',
 'boa_parser':'boa_parser::','object':'object::','serde_json':'serde_json::','icu':'icu_',
 'postcard':'postcard::','zstd/Rust':'zstd','zstd/C':'ZSTD_', 'huffman/C':'HUF_', 'finite_state_entropy/C':'FSE_',
 'scriptw_engine/all':'scriptw_engine::','scriptw_engine/embedded_runtime':'scriptw_engine::embedded_runtime',
 'scriptw_engine/precompiled':'scriptw_engine::embedding::precompiled','scriptw_engine/runtime_link':'scriptw_engine::wasm_runtime_link',
 'scriptw_engine/gc_host':'scriptw_engine::wasm_gc','scriptw_engine/intl':'scriptw_engine::wasm_gc_intl',
 'scriptw_runtime_image':'scriptw_runtime_image::','scriptw_intl':'scriptw_intl::',
 'scriptw_aot_wasm':'scriptw_aot_wasm::','scriptw_ir':'scriptw_ir::',
 'compiler/cranelift':'cranelift','regress':'regress::','serde':'serde',
 'std':'std::','alloc':'alloc::','core':'core::',
}
symbols=[]
with (OUT/'local-host-symbols.nm').open() as f:
 for line in f:
  fields=line.rstrip().rsplit(' ',3)
  if len(fields)!=4:continue
  name,kind,addr,size=fields
  if kind not in ('t','T','r','R'):continue
  try:addr=int(addr,16);size=int(size,16)
  except ValueError:continue
  if not size:continue
  owners=[s for s in loads if s[0]<=addr and addr+size<=s[1]]
  if len(owners)!=1:continue
  owner=owners[0];off=owner[2]+addr-owner[0]
  families=[key for key,needle in needles.items() if needle in name]
  symbols.append((off,off+size,name,kind,families))
result=dict(executable_sha256=digest,provenance='own local ELF PT_LOAD + own snapshot present file offsets; never CI addresses',
 limitations='Symbol byte/page overlap is not execution; families and aliases overlap and cannot be added; fault-around/page sharing apply.',cases=[])
for case in r['cases']:
 snapshots=case['snapshots']; mx=max(range(len(snapshots)),key=lambda i:snapshots[i]['rss_bytes'])
 entry=dict(file=case['file'],samples=[])
 for label,index in [('first',0),('maximum',mx),('last',len(snapshots)-1)]:
  snap=snapshots[index];mp=snap['executable_presence']['mappings']
  ps={perm:set(off for m in mp if m['permissions']==perm for off in m['present_page_file_offsets']) for perm in ['r-xp','r--p']}
  sets={};coverage={};tops=[]; family_top={}
  for lo,hi,name,kind,families in symbols:
   perm='r-xp' if kind in ('t','T') else 'r--p';present=ps[perm]
   pages={page for page in range(lo//4096*4096,hi,4096) if page in present}
   occupied=sum(max(0,min(hi,page+4096)-max(lo,page)) for page in pages)
   if not occupied:continue
   for family in families:
    key=perm+' '+family;sets.setdefault(key,set()).update(pages);coverage[key]=coverage.get(key,0)+occupied
    if perm=='r-xp':family_top.setdefault(key,[]).append(dict(name=name,bytes_in_present_pages=occupied,symbol_bytes=hi-lo))
   if perm=='r-xp':tops.append(dict(name=name,bytes_in_present_pages=occupied,symbol_bytes=hi-lo,pages=len(pages)))
  families=[dict(family=k,present_pages=len(v),page_coverage_bytes=len(v)*4096,symbol_byte_overlap=coverage[k]) for k,v in sets.items()]
  families.sort(key=lambda a:a['page_coverage_bytes'],reverse=True)
  entry['samples'].append(dict(label=label,index=index,path=snap['path'],rss_bytes=snap['rss_bytes'],
   executable_present_bytes={k:len(v)*4096 for k,v in ps.items()},families=families,
   family_top_symbols={k:sorted(v,key=lambda a:a['bytes_in_present_pages'],reverse=True)[:12] for k,v in family_top.items()},
   top_text_symbols=sorted(tops,key=lambda s:s['bytes_in_present_pages'],reverse=True)[:40]))
 result['cases'].append(entry)
(OUT/'local-host-symbols.json').write_text(json.dumps(result,indent=2)+'\n')
for case in result['cases']:
 print(case['file'])
 for snap in case['samples']:
  print(snap['label'],snap['index'],'total',round(snap['rss_bytes']/1048576,3),'RX',snap['executable_present_bytes']['r-xp']//1024,'KiB')
  if snap['label']=='maximum':
   for x in snap['families']:
    if x['family'].startswith('r-xp') and not any(x['family'].endswith(' '+y) for y in ['std','core','alloc']):print(x['family'],x['page_coverage_bytes']//1024,'KiB pages;',x['symbol_byte_overlap']//1024,'KiB symbol-overlap')
   print('top text symbols:')
   for x in snap['top_text_symbols'][:8]: print(x['bytes_in_present_pages']//1024,'KiB',x['name'][:190])
