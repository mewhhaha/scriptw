"""Assemble report-core.json after the isolated runtime-fold cohorts complete; never publish."""
from pathlib import Path
import datetime
import hashlib
import json
import math
import re
import statistics

ROOT = Path('/workspace/scriptw')
OUT = Path(__file__).resolve().parent
PARENT = 'e15843397c217c0e113c50e2164c0d1fa5552112'
BASELINE = '6764a3510a89a7830e6277cd91df09c9fc2769da901bcf578d87e9289d7050c5'
COMBINED = '6cd1e0d045b9f6a1b131fdaf8353a16a93e204a1ce3c3690887552631fadfd52'



def read(name):
    path = OUT / name
    assert path.stat().st_size <= 16 * 1024**2, path
    return json.loads(path.read_text())


def digest(path):
    # Only source/patch inputs are hashed here; product identities come from receipts.
    assert path.stat().st_size <= 4 * 1024**2, path
    return hashlib.sha256(path.read_bytes()).hexdigest()


def outcome(case, passed, failed=0):
    assert case['outcomes'] == [dict(passed=passed, failed=failed, ignored=0)]
    assert case['state'] == ('failed' if failed else 'passed')
    assert case['exit_code'] == (101 if failed else 0)


def raw_files(stdout):
    assert stdout.endswith('.stdout') and Path(stdout).name == stdout, stdout
    stem = stdout.removesuffix('.stdout')
    paths = dict(stdout=stdout, stderr=stem + '.stderr', command=stem + '.command.json')
    assert all((OUT / name).is_file() for name in paths.values()), paths
    return paths


def validate_analysis(name, order, expected, identities, product_records, node_identity, require_means=False):
    report = read(name)
    assert report['order'] == order
    assert report['samples'] == 21 and report['warmups'] == 10
    rows = report['workloads']
    assert len(rows) == len(expected) > 0
    assert len({row['file'] for row in rows}) == len(expected)
    assert {row['file'] for row in rows} == set(expected)
    raw = []
    prefix = name.removesuffix('-analysis.json')
    for row in rows:
        assert row['source_sha256'] == digest(OUT / 'sources' / row['file'])
        for boundary in ('original', 'retained', 'ordinary'):
            products = row[boundary]['products']
            assert set(products) == {'baseline', 'candidate'}
            for label, values in products.items():
                assert math.isfinite(values['median_ns']) and values['median_ns'] > 0
                rounds = values['rounds']
                assert [r['index'] for r in rounds] == [i for i, actual in enumerate(order) if actual == label]
                assert all(r['raw'] == f"{prefix}-r{r['index']}-{label}-{boundary}-{row['file']}.stdout" for r in rounds)
                paths = [raw_files(r['raw']) for r in rounds]
                raw.extend(paths)
                scores, rss = [], []
                for round_row, files in zip(rounds, paths):
                    record = read(files['stdout'])
                    command = read(files['command'])
                    tool = 'runtime_baseline' if boundary == 'ordinary' else 'compiler_precompiled_baseline'
                    identity = product_records[label][tool]['sha256']
                    assert command['exit_code'] == 0 and not command['timed_out']
                    assert command['executable_sha256'] == identity
                    assert record['source_fingerprint'] == identities[label]['source_fingerprint']
                    assert record['executable_sha256'] == identity
                    if boundary != 'ordinary':
                        assert record['compiler_enabled'] is False
                    else:
                        assert record['cases'][0]['source_sha256'] == row['source_sha256']
                    observations = record['cases'][0]['observations'] if boundary == 'ordinary' else record['observations']
                    assert len(observations) == 31
                    assert all(o.get('matched', True) and o['stdout'] == expected[row['file']]['stdout'] for o in observations)
                    samples = [o for o in observations if not o['warmup']]
                    assert len(samples) == 21
                    times = [o['call_ns'] if boundary == 'retained' else o['phases_ns']['execution'] if boundary == 'original' else o['execution_ns'] for o in samples]
                    assert statistics.median(times) == round_row['median_ns']
                    scores.extend(times)
                    if boundary == 'original':
                        rss.extend(o['process_snapshots']['after_execution']['rss_bytes'] for o in samples)
                    if require_means:
                        assert statistics.mean(times) == round_row['mean_ns']
                assert statistics.median(scores) == values['median_ns']
                if require_means:
                    assert values['samples'] == len(scores) == 21 * order.count(label)
                    assert math.isfinite(values['mean_ns']) and values['mean_ns'] > 0
                    assert statistics.mean(scores) == values['mean_ns']
                    if boundary == 'original':
                        assert statistics.median(rss) == values['rss_bytes']
            calculated = 100 * (products['candidate']['median_ns'] / products['baseline']['median_ns'] - 1)
            assert math.isclose(row[boundary]['change_percent'], calculated, abs_tol=1e-9)
            if require_means:
                calculated_mean = 100 * (products['candidate']['mean_ns'] / products['baseline']['mean_ns'] - 1)
                assert math.isclose(row[boundary]['mean_change_percent'], calculated_mean, abs_tol=1e-9)
        reference = row['v8_reference']
        assert reference['median_ns'] > 0 and math.isfinite(reference['median_ns'])
        assert [r['index'] for r in reference['rounds']] == list(range(len(order)))
        v8_scores = []
        for round_row in reference['rounds']:
            index = round_row['index']
            assert round_row['raw'] == f"{prefix}-r{index}-{order[index]}-v8-{row['file']}.stdout"
            paths = raw_files(round_row['raw'])
            raw.append(paths)
            command, record = read(paths['command']), read(paths['stdout'])
            assert command['exit_code'] == 0 and not command['timed_out']
            assert command['executable_sha256'] == node_identity['sha256']
            assert record['samples'] == 21 and record['warmups'] == 10
            case = record['cases'][0]
            assert case['file'] == row['file'] and case['source_sha256'] == row['source_sha256']
            assert len(case['observations']) == 31
            assert all(o['stdout'] == expected[row['file']]['stdout'] for o in case['observations'])
            samples = [o for o in case['observations'] if not o['warmup']]
            assert len(samples) == 21
            v8_scores.extend(o['execution_ns'] for o in samples)
        assert statistics.median(v8_scores) == reference['median_ns']
    return report, raw


def startup_rows(prefix, order, expected_stdout, identities, products):
    rows = []
    for index, label in enumerate(order):
        stem = f'{prefix}-r{index}-{label}-startup'
        paths = raw_files(stem + '.stdout')
        command = read(paths['command'])
        assert command['exit_code'] == 0 and not command['timed_out']
        record = read(paths['stdout'])
        assert record['source_fingerprint'] == identities[label]['source_fingerprint']
        product = products[label]['compiler_precompiled_baseline']['sha256']
        assert command['executable_sha256'] == record['executable_sha256'] == product
        assert record['compiler_enabled'] is False
        observations = record['observations']
        assert len(observations) == 31
        assert all(o['matched'] and o['stdout'] == expected_stdout for o in observations)
        samples = [o for o in observations if not o['warmup']]
        assert len(samples) == 21
        rows.append(dict(
            index=index, product=label, raw=paths,
            median_execution_ns=statistics.median(o['phases_ns']['execution'] for o in samples),
        ))
    return rows


def main():
    expected_native = {
        'native-fold-primary/receipt.json': {
            ('scriptw-aot-wasm', 'scriptw_aot_wasm', 'intrinsics::deferred_methods::'): 3,
            ('scriptw-aot-wasm', 'runtime_link', None): 31,
            ('scriptw-engine', 'aot_gc_entries', 'aot_gc_intrinsic_publication::'): 3,
            ('scriptw-engine', 'aot_language', 'aot_compact_native_metadata::'): 4,
            ('scriptw-engine', 'aot_realm_modules', 'aot_created_realm_array_iterator::'): 6,
        },
        'native-fold-secondary/receipt.json': {
            ('scriptw-aot-wasm', 'scriptw_aot_wasm', 'tests::bootstrap_compact_metadata::'): 4,
            ('scriptw-engine', 'aot_realm_modules', 'aot_native_function_source_syntax::'): 3,
        },
    }
    native_rows, selected_tests, receipt_totals = [], set(), {}
    for name, expected in expected_native.items():
        receipt = read(name)
        assert receipt['head'] == PARENT and receipt['source_unchanged']
        assert receipt['shared_runtime_linker_unchanged']
        cases = {(c['package'], c['target'], c.get('native_filter')): c for c in receipt['cases']}
        assert len(cases) == len(receipt['cases']) and set(cases) == set(expected)
        total = 0
        for key, case in cases.items():
            count = case['outcomes'][0]['passed']
            outcome(case, count)
            assert count == expected[key] == case['inventoried_tests'] and case['inventory_matches']
            inventory = ROOT / case['inventory_log']
            assert inventory.is_relative_to(OUT)
            assert digest(inventory) == case['inventory_sha256']
            names = re.findall(r'^(.+): test$', inventory.read_text(), re.M)
            assert len(names) == count
            for test_name in names:
                test_key = (case['package'], case['target'], test_name)
                assert test_key not in selected_tests, test_key
                selected_tests.add(test_key)
            native_rows.append(dict(receipt=name, package=key[0], target=key[1], filter=key[2],
                                    passed=count, inventory=case['inventory_log'],
                                    inventory_sha256=case['inventory_sha256'],
                                    executable_sha256=case['executable_sha256']))
            total += count
        receipt_totals[name] = total
    assert list(receipt_totals.values()) == [47, 7]
    native_passes = sum(receipt_totals.values())
    assert native_passes == len(selected_tests) == 54
    native_streams = read('native-stream-index.json')
    assert len(native_streams) == len(native_rows) == 7
    assert {(r['receipt'], r['scope'], r['filter']) for r in native_streams} == {
        (r['receipt'], r['target'], r['filter']) for r in native_rows
    }
    assert all((OUT / row['path']).is_file() for row in native_streams)

    inputs = read('compiled-inputs.json')
    isolation_plan = read('isolation-plan.json')
    assert len(inputs) == 10 and isolation_plan['parent'] == PARENT
    checked_inputs = {}
    for name, record in inputs.items():
        if name.startswith('crates/'):
            assert not Path(name).is_absolute() and '..' not in Path(name).parts
            assert digest(ROOT / name) == record['sha256'], name
            checked_inputs[name] = record
    assert len(checked_inputs) == 4
    assert set(checked_inputs) == set(isolation_plan['retained_fold_files'])
    assert all(not (ROOT / name).exists() for name in isolation_plan['deleted_new_memory_files'])
    assert isolation_plan['runtime_layout'] == 41
    runtime_source = ROOT / 'crates/scriptw-aot-wasm/src/runtime_artifact.rs'
    assert re.search(r'const\s+LAYOUT_VERSION\s*:\s*u32\s*=\s*41\s*;', runtime_source.read_text())
    assert not re.search(r'\bmod\s+empty_array_properties\s*;', (ROOT / 'crates/scriptw-aot-wasm/src/gc_types.rs').read_text())

    candidate_identity = read('candidate/identity.json')
    candidate_products = read('candidate/products.json')
    candidate_fingerprint = candidate_identity['source_fingerprint']
    assert re.fullmatch(r'[0-9a-f]{64}', candidate_fingerprint)
    assert candidate_fingerprint not in {BASELINE, COMBINED, 'c615b6e3b896f4aedc8a4292199a11e27114e914d1e6970fe67b3ea8790a03d1'}
    assert candidate_identity['source_commit'] == PARENT
    accepted_identity = read('baseline-identity.json')
    accepted_products = read('baseline-products.json')
    assert accepted_identity['source_fingerprint'] == BASELINE
    assert accepted_identity['source_commit'] == '69ce371b964cc3af8da79750507ba5018eb2aef2'
    combined_directory = ROOT / 'target/performance-runtime-ownership-20261031'
    combined_identity = read(combined_directory / 'candidate/identity.json')
    combined_products = read(combined_directory / 'candidate/products.json')
    assert combined_identity['source_fingerprint'] == COMBINED
    assert combined_identity['source_commit'] == PARENT
    assert isolation_plan['combined'].startswith(COMBINED)
    for identity, products in ((candidate_identity, candidate_products),
                               (accepted_identity, accepted_products),
                               (combined_identity, combined_products)):
        assert set(products) == {'compiler_precompiled_baseline', 'runtime_baseline', 'scriptw'}
        assert products['compiler_precompiled_baseline']['sha256'] == identity['executable_sha256']
        assert identity['shared_configuration'] == candidate_identity['shared_configuration']
    baseline_reuse = read('baseline-reuse-proof.json')
    assert baseline_reuse['parent_commit'] == PARENT
    assert baseline_reuse['baseline_original_identity'] == accepted_identity
    assert baseline_reuse['baseline_products'] == accepted_products
    build = read('candidate-build.json')
    assert build['head'] == PARENT and build['exit_code'] == 0

    test262_plan = read('test262-plan.json')
    families = test262_plan['families']
    assert len(families) == len({row['scope'] for row in families}) == 8
    assert test262_plan['expected_executions_from_combined_same_pins'] == 276
    suite = read('test262-candidate-summary.json')
    assert len(suite['runs']) == 8
    assert {row['scope'] for row in suite['runs']} == {row['scope'] for row in families}
    for run in suite['runs']:
        assert run['product'] == 'candidate' and run['exit_code'] == 0
        assert run['passed'] == run['total'] and run['total'] > 0
        assert run['executable_sha256'] == candidate_products['scriptw']['sha256']
        assert Path(run['raw']).name == run['raw'] and (OUT / run['raw']).is_file()
    test262_executions = sum(run['passed'] for run in suite['runs'])
    assert test262_executions == 276

    guards = (OUT / 'source-guards.log').read_text()
    assert sum(map(int, re.findall(r'test result: ok\. (\d+) passed; 0 failed;', guards))) == 359
    assert 'ok (30 permanent areas)' in (OUT / 'ownership.log').read_text()
    assert len(re.findall(r'^PASS ', (OUT / 'intl-source.log').read_text(), re.M)) == 15
    audit = dict(status='not separately recorded for this cohort')
    if (OUT / 'product-graph.log').exists():
        assert 'check-no-interpreter-in-product-graph: ok' in (OUT / 'product-graph.log').read_text()
        audit = dict(status='passed', raw='product-graph.log')

    manifest = read('sources/manifest.json')
    startup = manifest['startup']
    expected = {row['file']: row for row in manifest['execution'] if row['file'] != startup['file']}
    assert len(expected) == 17
    # The isolation driver's baseline label is explicitly the combined candidate.
    definitions = {
        'initial': (['baseline', 'candidate', 'candidate', 'baseline'], 'accepted-fusion', accepted_identity, accepted_products),
        'isolation': (['baseline', 'candidate', 'candidate', 'baseline'], 'combined-runtime-ownership', combined_identity, combined_products),
    }
    optional_cohorts = {
        'confirmation': (['candidate', 'baseline', 'baseline', 'candidate'], 'accepted-fusion', accepted_identity, accepted_products),
        'isolation-confirmation': (['candidate', 'baseline', 'baseline', 'candidate'], 'combined-runtime-ownership', combined_identity, combined_products),
    }
    for prefix, definition in optional_cohorts.items():
        if (OUT / (prefix + '-analysis.json')).exists():
            definitions[prefix] = definition
    cohorts, contexts, raw_index, startup_controls, resources = {}, {}, {}, {}, {}
    reference_node = None
    harness = ROOT / 'crates/scriptw-cli/tests/fixtures/v8_baseline/node-runtime.cjs'
    for prefix, (order, baseline_kind, baseline_identity, baseline_products) in definitions.items():
        identities = dict(baseline=baseline_identity, candidate=candidate_identity)
        products = dict(baseline=baseline_products, candidate=candidate_products)
        resources[prefix] = dict(before=read(prefix + '-resources-before.json'),
                                 after=read(prefix + '-resources-after.json'),
                                 node_identity=read(prefix + '-node-identity.json'))
        node = resources[prefix]['node_identity']
        assert node['harness_sha256'] == digest(harness)
        if reference_node is None:
            reference_node = node
        assert all(node[key] == reference_node[key] for key in ('sha256', 'harness_sha256', 'versions'))
        contexts[prefix] = dict(baseline_kind=baseline_kind, baseline_identity=baseline_identity,
                                candidate_identity=candidate_identity, baseline_products=baseline_products,
                                candidate_products=candidate_products, order=order,
                                scope='These identities apply to this cohort only; labels have no shared ambient baseline.')
        cohorts[prefix], raw_index[prefix] = validate_analysis(
            prefix + '-analysis.json', order, expected, identities, products, node,
        )
        startup_controls[prefix] = startup_rows(prefix, order, startup['stdout'], identities, products)
    table = []
    for name in expected:
        row = dict(file=name, source_sha256=None, cohorts={})
        for prefix, analysis in cohorts.items():
            actual = next(value for value in analysis['workloads'] if value['file'] == name)
            if row['source_sha256'] is None:
                row['source_sha256'] = actual['source_sha256']
            assert actual['source_sha256'] == row['source_sha256']
            row['cohorts'][prefix] = {key: actual[key] for key in ('original', 'retained', 'ordinary', 'v8_reference')}
        table.append(row)
    targeted_controls = None
    if (OUT / 'control-plan.json').exists() or (OUT / 'controls-analysis.json').exists():
        control_plan = read('control-plan.json')
        fixtures = control_plan['fixtures']
        assert len(fixtures) == len(set(fixtures)) == 5
        assert set(fixtures).issubset(expected)
        control_order = ['baseline', 'candidate', 'candidate', 'baseline',
                         'candidate', 'baseline', 'baseline', 'candidate']
        assert control_plan['order'] == control_order
        assert control_plan['samples'] == 21 and control_plan['warmups'] == 10
        assert control_plan['baseline'] == 'accepted' + BASELINE[:4]
        assert control_plan['candidate'] == 'fold' + candidate_fingerprint[:4]
        control_report = read('controls-analysis.json')
        assert control_report['complete'] is True
        control_resources = dict(before=read('controls-resources-before.json'),
                                 after=read('controls-resources-after.json'),
                                 node_identity=read('controls-node-identity.json'))
        control_node = control_resources['node_identity']
        assert control_node['harness_sha256'] == digest(harness)
        assert all(control_node[key] == reference_node[key] for key in ('sha256', 'harness_sha256', 'versions'))
        control_identities = dict(baseline=accepted_identity, candidate=candidate_identity)
        control_products = dict(baseline=accepted_products, candidate=candidate_products)
        control_report, control_raw = validate_analysis(
            'controls-analysis.json', control_order, {name: expected[name] for name in fixtures},
            control_identities, control_products, control_node, require_means=True,
        )
        targeted_controls = dict(
            plan=control_plan, report=control_report, raw_stream_index=control_raw,
            cohort_context=dict(baseline_kind='accepted-fusion', identities=control_identities,
                                products=control_products, order=control_order),
            resources=control_resources,
            startup_controls=startup_rows('controls', control_order, startup['stdout'],
                                          control_identities, control_products),
            scope='Five plan-selected unchanged fixtures, eight balanced ABBA+BAAB rounds. Every product has 84 measured observations per boundary, all checked raw medians/means and original RSS retained. This targeted decision evidence remains separate from the full-17 cohorts and isolated-source correctness inventory.',
        )
    optional_controls = {}
    paths = set(OUT.glob('*control*-analysis.json')) | set(OUT.glob('*targeted*-analysis.json'))
    for path in sorted(paths):
        if path.name == 'controls-analysis.json':
            continue  # Fully validated against control-plan.json above.
        control = read(path.name)
        assert isinstance(control, dict) and control
        if 'complete' in control:
            assert control['complete']
        optional_controls[path.name] = control

    diagnostics = {}
    if (OUT / 'runtime-code-size.json').exists():
        size = read('runtime-code-size.json')
        assert size['scored'] is False
        assert size['products']['baseline']['source_fingerprint'] == BASELINE
        assert size['products']['candidate']['source_fingerprint'] == candidate_fingerprint
        assert size['products']['baseline']['host_sha256'] == accepted_identity['executable_sha256']
        assert size['products']['candidate']['host_sha256'] == candidate_identity['executable_sha256']
        assert size['products']['baseline']['runtime_layout'] == size['products']['candidate']['runtime_layout'] == 41
        diagnostics['runtime_code_size'] = size
    if (OUT / 'scriptc-comparison.json').exists():
        comparison = read('scriptc-comparison.json')
        if comparison.get('complete') is True:
            assert comparison['samples'] == 21 and comparison['warmups'] == 10
            assert len(comparison['workloads']) == 17
            assert {row['file'] for row in comparison['workloads']} == set(expected)
            assert len(comparison['attempts']) == 68
            seen, scriptc_raw = set(), []
            for attempt in comparison['attempts']:
                key = (attempt['round'], attempt['runtime'], attempt['file'])
                assert key not in seen and key[0] in (0, 1) and key[1] in ('scriptw', 'scriptc') and key[2] in expected
                seen.add(key)
                paths = raw_files(attempt['raw'])
                command, record = read(paths['command']), read(paths['stdout'])
                assert command['exit_code'] == 0 and not command['timed_out']
                assert command['executable_sha256'] == record['executable_sha256'] == candidate_identity['executable_sha256']
                assert record['source_fingerprint'] == candidate_fingerprint and record['compiler_enabled'] is False
                assert record['image_sha256'] == attempt['image_sha256']
                assert len(record['observations']) == 31
                assert all(o['stdout'] == expected[key[2]]['stdout'] for o in record['observations'])
                assert sum(not o['warmup'] for o in record['observations']) == 21
                scriptc_raw.append(paths)
            diagnostics['scriptc_comparison'] = comparison
            diagnostics['scriptc_raw_stream_index'] = scriptc_raw
        else:
            diagnostics['scriptc_comparison_pending'] = dict(raw='scriptc-comparison.json',
                                                            scope='Incomplete optional comparison; excluded from measured claims.')

    report = dict(
        schema='scriptw-runtime-fold-v1',
        recorded_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        status='rejected',
        decision=dict(
            outcome='rejected',
            reason='The final eight-round five-fixture controls retain ordinary singleton, ordinary objects and original integer regressions. The fold-only change fails the control gate and is not promoted, despite static resolver code-size reduction.',
            evidence='measurement.targeted_controls; accepted fusion 6764 versus fold candidate',
            regressing_controls=[dict(file=name, boundary=boundary,
                                       median_change_percent=next(row for row in targeted_controls['report']['workloads'] if row['file']==name)[boundary]['change_percent'],
                                       mean_change_percent=next(row for row in targeted_controls['report']['workloads'] if row['file']==name)[boundary]['mean_change_percent'])
                                  for name,boundary in [('join-singleton-1024.js','ordinary'),
                                                        ('objects.js','ordinary'),('integer.js','original')]],
        ),
        source=dict(
            parent_commit=PARENT, candidate_fingerprint=candidate_fingerprint,
            candidate_identity=candidate_identity, candidate_products=candidate_products,
            candidate_build=build, accepted_baseline_reuse_proof=baseline_reuse,
            patch_sha256=digest(OUT / 'compile-inputs.patch'), inputs=inputs,
            verified_current_crate_inputs=checked_inputs, isolation_plan=isolation_plan,
            runtime_source=dict(path=str(runtime_source.relative_to(ROOT)), sha256=digest(runtime_source), layout_version=41),
            identity_note='Candidate is frozen parent e15843397 plus the exact ten-file fold-only snapshot/patch, with its actual fingerprint read from candidate/identity.json. Four Rust input hashes are checked against current files; six README/docs snapshots may receive measured prose. Accepted fusion 6764 and combined 6cd are distinct frozen baseline experiments, bound separately to each cohort below.',
        ),
        change=dict(
            runtime_layout_version=41, abi_layout_changed=False, default_policy_changed=False,
            shared_empty_array_graph=False, new_runtime_global=False,
            resolver=dict(code_allocation_sites_before=823, code_allocation_sites_after=1,
                          string_resolution_call_sites_before=1646, string_resolution_call_sites_after=2,
                          behavior='Selected deferred-method metadata uses one code-allocation tail and two ordered string-resolution sites. Dynamic allocation/string counts, evaluation order, defining Realm and GC rooting remain unchanged; no eager table is introduced.',
                          scope='Static emitted resolver code-site counts, not dynamic allocation or process memory savings.'),
            claims='No shared-empty Array graph, allocation reduction or conditional graph-byte saving belongs to this isolated source. Native bytes, text pages, RSS and elapsed time are reported only from their own measured or inert diagnostic evidence.',
        ),
        validation=dict(
            native_passing_cases=native_passes, native_selected_case_groups=len(native_rows),
            native_receipt_totals=receipt_totals, native_groups=native_rows, native_streams=native_streams,
            native_count_note='54 source-bound selected native checks derive from the two complete passing receipts: primary 47 plus secondary 7. AOT filters select 3+4, runtime_link selects 31, engine GC selects 3, language selects 4, and Realm filters select 6+3. Inventory names are disjoint across receipt groups. This is focused validation, not a full workspace or full library run.',
            test262_selected_family_count=8, test262_passing_executions=test262_executions,
            test262_plan=test262_plan, test262_original_families=suite,
            coverage_note='The eight original families were replayed by this isolated source CLI and completed 276 actual variants. The combined source experiment has separate native/Test262 evidence; its broader inventories are not counted as this source coverage.',
            source_only_guards=359, conformance_owners=30, intl_recipes=15, product_interpreter_audit=audit,
            formatting=dict(changed_rust='Four changed Rust files formatted with edition 2021 per cohort record.',
                            full_workspace='Inherited 17 pre-existing file failures remain unresolved; no fresh full-workspace formatting or release acceptance claim.'),
        ),
        separate_experiments=dict(
            accepted_fusion=dict(source_fingerprint=BASELINE, identity=accepted_identity,
                                 products=accepted_products, scope='Accepted comparison baseline for initial/confirmation only.'),
            combined_runtime_ownership=dict(source_fingerprint=COMBINED, identity=combined_identity,
                                             products=combined_products, evidence_directory=str(combined_directory),
                                             runtime_layout=42, source_coverage_reused=False,
                                             scope='Separate combined fold-plus-shared-empty experiment; baseline for isolation cohorts only. Its broader correctness and measurement results remain in its own report.'),
        ),
        measurement=dict(
            plan=read('measurement-plan.json'), cohort_contexts=contexts, cohorts=table,
            complete_cohort_reports=cohorts, raw_stream_index=raw_index,
            startup_controls=startup_controls, resources=resources,
            targeted_controls=targeted_controls,
            optional_targeted_control_reports=optional_controls,
            optional_control_scope='The planned five-fixture controls above explicitly bind accepted fusion 6764 versus the fold candidate. Other optional saved reports preserve their own labels/raw identities and do not inherit an ambient baseline or enlarge isolated-source correctness coverage.',
            boundaries='Initial full-17 ABBA compares fold-only against accepted fusion 6764. Isolation full-17 ABBA compares the same fold-only candidate against frozen combined 6cd, as measure-isolation.py explicitly overrides its baseline bindings. Original compiler-disabled fresh Store/Realm execution, strict-derived retained calls, ordinary runtime_baseline and Node fresh-context references remain separate boundaries. Source/harness/checksums, all startup controls and raw identities are checked.',
            memory='Post-execution smaps process RSS with Store alive is not live JavaScript bytes, peak memory or per-owner attribution. Whole-child GNU time peaks include loading/compiler and identity hashing. Isolation comparison is a separate experiment, not causal subtraction across differing baseline/source cohorts.',
            resource_policy='Inherited managed-cloud 32 GiB cap; CPU 0 for measurements/tests, quota-bound build CPUs; serial Cargo/libtest and retained module cache 512 entries/2 GiB. Swap/group OOM settings are inherited, not local 4 GiB guarantees.',
        ),
        diagnostics=diagnostics,
        limits=[
            'Only 54 selected native checks and eight complete original Test262 families are isolated-source correctness coverage; no combined-source inventory is adopted.',
            'Selected replays are not full pinned-suite publication or full release acceptance; published benchmark graphs and full Test262 status remain unchanged.',
            'Every-case V8/Scriptc execution-time and RSS parity remains open; optional comparisons do not establish universal parity.',
            'Initial/confirmation accepted-baseline results and isolation combined-baseline results have explicit separate identities and must not be merged as one before/after cohort.',
            'All 17 original, retained, ordinary and V8 controls and startup raw results remain visible, including slower controls.',
            'Static code-site folding preserves dynamic counts/order; inert native byte diagnostics alone establish no executed-page, RSS or time benefit.',
        ],
    )
    (OUT / 'report-core.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(dict(native_selected_passes=native_passes, native_case_groups=len(native_rows),
                          test262_executions=test262_executions, candidate_fingerprint=candidate_fingerprint,
                          workloads=len(table), cohorts=list(cohorts), output='report-core.json'), indent=2), flush=True)


if __name__ == '__main__':
    main()


