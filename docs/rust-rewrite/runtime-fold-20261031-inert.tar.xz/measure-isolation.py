from pathlib import Path
import importlib.util
p=Path(__file__).with_name('cohort.py');spec=importlib.util.spec_from_file_location('cohort',p);c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
# Here baseline means the frozen combined candidate, not the accepted fusion.
# Every raw child and analyze() reads these exact overwritten label bindings.
c.OLD=c.ROOT/'target/performance-runtime-ownership-20261031'
c.BASELINE=c.OLD/'candidate'
c.measure('isolation',['baseline','candidate','candidate','baseline'])
