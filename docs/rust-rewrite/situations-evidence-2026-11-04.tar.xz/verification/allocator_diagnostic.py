"""Unscored allocator-only experiment linked to the actual candidate Cargo artifacts."""
import hashlib,json,os,pathlib,statistics,subprocess,time
root=pathlib.Path.cwd();base=root/'target/performance-own-property-20261104';out=base/'allocator-diagnostic';out.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
original=root/'crates/scriptw-cli/examples/rsc_baseline.rs';source=original.read_text()
source=source.replace('    Fast,\n    Speed,','    Fast,\n    NoneBacktracking,\n    Speed,')
source=source.replace('            Some("speed") => Ok(Self::Speed),','            Some("none-backtracking") => Ok(Self::NoneBacktracking),\n            Some("speed") => Ok(Self::Speed),')
source=source.replace('            Self::Fast => "fast",','            Self::Fast => "fast",\n            Self::NoneBacktracking => "none-backtracking",')
needle='    config.target(env!("SCRIPTW_PERF_TARGET"))?;'
source=source.replace(needle,'    if let NativeMode::NoneBacktracking = native_mode {\n        config.cranelift_regalloc_algorithm(wasmtime::RegallocAlgorithm::Backtracking);\n    }\n'+needle)
source=source.replace('        NativeMode::Fast => "matched Fast cohort",','        NativeMode::Fast => "unscored allocator diagnostic control",\n        NativeMode::NoneBacktracking => "unscored allocator-only diagnostic",')
rs=out/'rsc_allocator.rs';rs.write_text(source)
rows=[json.loads(l) for l in (base/'build.stdout').read_text().splitlines()];assert any(r.get('reason')=='build-finished' and r['success'] for r in rows)
env=os.environ.copy()
for r in rows:
 if r.get('reason')=='build-script-executed' and 'scriptw-cli#' in r['package_id']:
  env.update(dict(r['env']))
argv=['rustc','--edition=2021','--crate-name','rsc_allocator',str(rs),'-C','opt-level=3','-C','debuginfo=1','-C','link-arg=-fuse-ld=lld','-L','dependency=target/release/deps','-o',str(out/'rsc-allocator')]
artifacts={r['target']['name']:r for r in rows if r.get('reason')=='compiler-artifact' and 'lib' in r['target']['kind']}
for name in ['scriptw_engine','wasmtime','serde_json','sha2']:
 paths=[p for p in artifacts[name]['filenames'] if p.endswith('.rlib')];assert len(paths)==1
 argv+=['--extern',name+'='+paths[0]]
for p in sorted({p for r in rows if r.get('reason')=='build-script-executed' for p in r['linked_paths']}):argv+=['-L',p]
with (out/'build.stdout').open('xb') as a,(out/'build.stderr').open('xb') as b:r=subprocess.run(argv,env=env,stdout=a,stderr=b,timeout=300)
assert r.returncode==0
baseline=json.loads((base/'fast-comparison-campaign/block-0-0-candidate/report.json').read_text());binary=out/'rsc-allocator'
plan=dict(schema='scriptw-rsc-allocator-diagnostic-v1',unscored=True,original_example_sha256=sha(original),diagnostic_source_sha256=sha(rs),diagnostic_executable_sha256=sha(binary),candidate_identity=baseline,build_argv=argv,cargo_producer_log_sha256=sha(base/'build.stdout'),linked_rlibs={name:{'path':next(p for p in artifacts[name]['filenames'] if p.endswith('.rlib')),'sha256':sha(pathlib.Path(next(p for p in artifacts[name]['filenames'] if p.endswith('.rlib'))))} for name in ['scriptw_engine','wasmtime','serde_json','sha2']},build_environment={k:v for k,v in env.items() if k.startswith('SCRIPTW_PERF_')},limits='Allocator-only diagnostic; same OptLevel::None, source/P/R bytes and host in both arms. Every output checked. Not promoted into scored Fast cohort or product defaults. Compile and initialization precede request clock. Four fresh processes per arm across two balanced blocks; three warmups and seven measured requests per mode.')
(out/'plan.json').write_text(json.dumps(plan,indent=2)+'\n');runs=[]
for block in range(2):
 for rep in range(2):
  modes=['fast','none-backtracking']
  if (block+rep)%2:modes.reverse()
  for mode in modes:
   label=f'block-{block}-{rep}-{mode}';report=out/(label+'.json');argv=[str(binary),baseline['inputs']['source'],baseline['inputs']['support'],str(report),'7','3',mode];start=time.monotonic_ns()
   print('START',label,flush=True)
   with (out/(label+'.stdout')).open('xb') as a,(out/(label+'.stderr')).open('xb') as b:p=subprocess.run(argv,stdout=a,stderr=b,timeout=180)
   assert p.returncode==0
   row=json.loads(report.read_text())
   for field in ['program_wasm_sha256','runtime','inputs','source_fingerprint']:assert row[field]==baseline[field],field
   assert row['configuration']['cranelift_opt_level']=='None'
   assert row['configuration']['register_allocation']=={'fast':'SinglePass','none-backtracking':'Backtracking'}[mode]
   assert len(row['cases'])==2 and all(c['exact_node_output_checked'] and len(c['observations'])==10 for c in row['cases'])
   runs.append(dict(block=block,rep=rep,mode=mode,argv=argv,exit_code=p.returncode,elapsed_ns=time.monotonic_ns()-start,report=report.name,report_sha256=sha(report)))
   (out/'receipt.json').write_text(json.dumps(dict(complete=False,runs=runs),indent=2)+'\n');print('END',label,flush=True)
summary={}
for mode in ['fast','none-backtracking']:
 reports=[json.loads((out/r['report']).read_text()) for r in runs if r['mode']==mode]
 summary[mode]=dict(native_preparation_ms=statistics.median(r['phases_ns']['native_preparation'] for r in reports)/1e6,requests_ms={m:statistics.median(statistics.median(o['elapsed_ns'] for o in next(c for c in r['cases'] if c['case']=='rsc-'+m)['observations'] if not o['warmup']) for r in reports)/1e6 for m in ['sync','async']})
(out/'receipt.json').write_text(json.dumps(dict(complete=True,runs=runs,summary=summary),indent=2)+'\n');print(json.dumps(summary),flush=True)
