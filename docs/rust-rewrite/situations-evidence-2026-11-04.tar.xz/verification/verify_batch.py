import hashlib,json,pathlib,re,subprocess,time
root=pathlib.Path.cwd();base=root/'target/performance-own-property-20261104';logs=base/'verification';logs.mkdir(exist_ok=True);scopes=[];commands=[]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
manifest=sha(base/'measured-source/manifest.json')
def save(complete=False):
 (base/'native-verification-current.json').write_text(json.dumps(dict(complete=complete,source_manifest_sha256=manifest,scopes=scopes,producer_commands=commands,limits='Fresh scoped native validation on frozen source. Four preexisting AOT bootstrap failures stay failures; no full workspace CI or pinned Test262 rerun. Focused cases overlap broader scopes.'),indent=2)+'\n')
def run(label,argv,package=None,target=None,allowed=(0,),location=logs,timeout=1800):
 print('START',label,flush=True);start=time.monotonic_ns()
 with (location/(label+'.stdout')).open('xb') as out,(location/(label+'.stderr')).open('xb') as err:p=subprocess.run(argv,cwd=root,stdout=out,stderr=err,timeout=timeout)
 row=dict(label=label,argv=argv,exit_code=p.returncode,elapsed_ns=time.monotonic_ns()-start,source_manifest_sha256=manifest,stdout=(location/(label+'.stdout')).relative_to(base).as_posix(),stderr=(location/(label+'.stderr')).relative_to(base).as_posix())
 if package:
  matches=re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;',(location/(label+'.stdout')).read_text());assert len(matches)==1
  state,passed,failed,ignored=matches[0];row.update(package=package,target=target,executable_sha256=sha(pathlib.Path(argv[0])),outcomes=dict(state=state,passed=int(passed),failed=int(failed),ignored=int(ignored)));assert int(passed)+int(failed)>0 and int(ignored)==0;scopes.append(row)
 else:commands.append(row)
 save();print('END',label,p.returncode,flush=True);assert p.returncode in allowed,label
 return row
def artifacts(path):
 events=[json.loads(line) for line in path.read_text().splitlines()];assert any(r.get('reason')=='build-finished' and r['success'] for r in events)
 return {r['target']['name']:r for r in events if r.get('reason')=='compiler-artifact' and r.get('executable') and r['profile']['test']}
assert subprocess.check_output(['git','diff','--binary','HEAD','--','crates','docs/rust-rewrite/contracts'])==(base/'measured-source/tracked.patch').read_bytes()
assert (base/'source-guards-final.stdout').is_file(), 'reuse final source-guard preflight'
assert not (base/'source-guards-final.stderr').read_text().count('FAILED')
run('focused-build',['cargo','test','--release','--locked','-p','scriptw-aot-wasm','-p','scriptw-ir','--test','emission','--test','scriptw_ir_integration','--no-run','--message-format=json-render-diagnostics'],location=base)
focused=artifacts(base/'focused-build.stdout');emission=focused['emission']['executable'];ir=focused['scriptw_ir_integration']['executable']
run('own-property-emission',[emission,'own_property_helper::','--test-threads=1'],'scriptw-aot-wasm','emission')
run('emission',[emission,'--test-threads=1'],'scriptw-aot-wasm','emission')
row=run('ir-full',[ir,'--test-threads=1'],'scriptw-ir','scriptw_ir_integration');(base/'ir-full.json').write_text(json.dumps(row,indent=2)+'\n')
(base/'ir-source-equivalence.json').write_text(json.dumps(dict(unchanged=True,phase_manifest_sha256=manifest,final_manifest_sha256=manifest,scope='IR full scope ran on frozen final source; selected executable and Cargo producer retained.'),indent=2)+'\n')
run('aot-build',['cargo','test','--release','--locked','-p','scriptw-aot-wasm','--lib','--no-run','--message-format=json-render-diagnostics']);aot=artifacts(logs/'aot-build.stdout')['scriptw_aot_wasm']['executable']
run('stale-cache',[aot,'abi50_runtime_cache_is_replaced','--test-threads=1'],'scriptw-aot-wasm','scriptw_aot_wasm')
run('stale-package',[aot,'abi50_package_is_replaced','--test-threads=1'],'scriptw-aot-wasm','scriptw_aot_wasm')
run('aot-full',[aot,'--test-threads=1'],'scriptw-aot-wasm','scriptw_aot_wasm',allowed=(101,))
expected={'tests::bootstrap_compact_metadata::native_bootstrap_uses_complete_constructor_layouts_and_compact_remaining_native_metadata','tests::error_demand_initialization::canonical_runtime_defers_the_complete_error_graph_with_a_void_realm_abi','tests::intrinsic_property_layout_allocation::fresh_intrinsic_bootstrap_allocates_layout_records_not_per_property_records','tests::ordered_bootstrap_allocation::eager_layout_births_keep_demand_recipe_and_constructor_allocation_owners'}
failures=set(re.findall(r'^    (\S+)\s*$',(logs/'aot-full.stdout').read_text().split('failures:\n')[-1],re.M));assert failures==expected
names=['structure_language','modules_realms','runtime_link','structure_builtins','structure_async','intl_temporal','aot_language','aot_builtins','aot_async','aot_realm_modules'];argv=['cargo','test','--release','--locked','-p','scriptw-aot-wasm','-p','scriptw-engine']
for name in names:argv+=['--test',name]
run('native-build',argv+['--no-run','--message-format=json-render-diagnostics']);native=artifacts(logs/'native-build.stdout')
for label,target,pattern in [('descriptor-semantics','aot_builtins','aot_proxy_target_descriptors::'),('descriptor-public','aot_builtins','aot_proxy_get_own_property::'),('descriptor-realms','aot_realm_modules','aot_proxy_helper_realms::')]:run(label,[native[target]['executable'],pattern,'--test-threads=1'],'scriptw-engine',target)
for name in names:
 package='scriptw-aot-wasm'
 if name.startswith('aot_'):package='scriptw-engine'
 run(name,[native[name]['executable'],'--test-threads=1'],package,name)
save(True);print('NATIVE QUALIFICATION COMPLETE',flush=True)
run('build',['cargo','build','--release','--locked','-p','scriptw-cli','--example','compiler_precompiled_baseline','--example','rsc_baseline','--message-format=json-render-diagnostics'],location=base)
run('freeze',['python3','-B',str(base/'freeze_hosts.py')])
run('rsc-campaign',['python3','-B',str(base/'measure_rsc.py'),'--candidate',str(base/'frozen/rsc_baseline'),'--candidate-source-snapshot',str(base/'measured-source'),'--output',str(base/'fast-comparison-campaign'),'--node','/home/jacobt/.local/share/fnm/node-versions/v24.12.0/installation/bin/node','--time',str(root/'target/performance-worker-cpu/tools/time')])
for label,script in [('situations','measure_situations.py'),('pmu','profile_candidate.py'),('size','size/static_and_publish.py')]:run(label,['python3','-B',str(base/script)])
run('metadata-control',['python3','-B',str(base/'compare_metadata.py')])
save(True);print('BATCH COMPLETE',flush=True)
