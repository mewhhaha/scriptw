"""Unscored balanced frozen-image control, using the situation runner's validators."""
import hashlib,importlib.util,json,os,pathlib,statistics,sys
root=pathlib.Path.cwd();base=root/'target/performance-own-property-20261104';sys.path.insert(0,str(root/'scripts'))
spec=importlib.util.spec_from_file_location('situations',root/'scripts/benchmark-situations.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
m.require_kernel_budget(4*1024**3);assert len(os.sched_getaffinity(0))==1
out=base/'metadata-comparison';out.mkdir();logs=out/'logs';logs.mkdir()
folders={'baseline':base/'metadata-baseline','candidate':base/'campaign'}
reports={a:json.loads((p/'report.json').read_text()) for a,p in folders.items()};assert all(r['complete'] for r in reports.values())
cases=[c for c in reports['candidate']['cases'] if c['category']=='function properties'];actors=['baseline','candidate','v8'];rows=[]
binaries={'baseline':root/'target/performance-has-instance-20261104/frozen/compiler_precompiled_baseline','candidate':base/'frozen/compiler_precompiled_baseline'}
identities={a:reports[a]['source_identity'] for a in binaries};validation_identities={a:reports[a]['tools']['host']['identity'] for a in binaries};images={}
for a in binaries:
 assert m.digest(binaries[a])==identities[a]['executable_sha256']
 prep=next(p for p in reports[a]['preparations'] if p['actor']=='scriptw-fast')
 for c in cases:
  receipt=next(r for r in prep['cases'] if r['file']==c['file']);image=folders[a]/receipt['image_path'];assert m.digest(image)==receipt['image_sha256'];images[a,c['file']]=(image,json.loads(image.with_suffix('.json').read_text()),m.digest(image))
plan=dict(schema='scriptw-metadata-frozen-control-v1',unscored=True,complete=False,identities=identities,rows=rows,limits='Balanced two-block control; eight fresh processes per actor/case, three warmups and seven measured calls; same prepared source and checksums; cold native preparation and input preparation excluded. Separate from latest Fast/Speed/V8 chart cohort. No allocation count or pure descriptor-cost attribution.')
for task in m.measurement_plan(cases,actors):
 c=next(c for c in cases if c['file']==task['file']);a=task['actor'];label=f"{task['block']}-{task['round']}-{a}-{c['file']}";source=folders['candidate']/'sources'/c['file']
 if a=='v8':
  argv=[root/'/home/jacobt/.local/share/fnm/node-versions/v24.12.0/installation/bin/node','--experimental-vm-modules','--no-warnings',root/m.ADAPTER,source.parent,c['file'],'7','3'];identity=validation_identities['candidate'];receipt=None;actor='v8'
 else:
  image,receipt,hashed=images[a,c['file']];assert m.digest(image)==hashed
  assert (folders[a]/'sources'/c['file']).read_bytes()==source.read_bytes()
  argv=[binaries[a],'execute-retained',image,c['stdout'],'7','3'];identity=validation_identities[a];actor='scriptw-fast'
 scratch=out/label;scratch.mkdir();env=m.limited_environment();env.update(TMPDIR=str(scratch.resolve()),SCRIPTW_CACHE_DIR=str((scratch/'cache').resolve()),NODE_DISABLE_COMPILE_CACHE='1');env.pop('NODE_COMPILE_CACHE',None)
 with (logs/(label+'.stdout')).open('xb') as stdout,(logs/(label+'.stderr')).open('xb') as stderr:
  accounting=m.measure_process(argv,cwd=root,env=env,stdout=stdout,stderr=stderr,timeout=60,time_binary=root/'target/performance-worker-cpu/tools/time')
 assert accounting['exit_code']==0 and not accounting['timed_out']
 assert not (logs/(label+'.stderr')).read_bytes()
 raw=json.loads((logs/(label+'.stdout')).read_text());samples=m.validate_execution(raw,c,actor,m.digest(source),identity,receipt)
 rows.append(dict(task,command=label,argv=list(map(str,argv)),accounting=accounting,raw=raw,samples_ns=samples,median_ns=statistics.median(samples),status='ok'))
 (out/'report.json').write_text(json.dumps(plan,indent=2)+'\n')
plan['complete']=True;plan['cases']=[dict(file=c['file'],runtimes={a:m.reduce_runtime([r for r in rows if r['file']==c['file'] and r['actor']==a],c['operations']) for a in actors}) for c in cases]
(out/'report.json').write_text(json.dumps(plan,indent=2)+'\n');print(json.dumps({c['file']:{a:r['median_ns']/1e6 for a,r in c['runtimes'].items()} for c in plan['cases']},indent=2))
