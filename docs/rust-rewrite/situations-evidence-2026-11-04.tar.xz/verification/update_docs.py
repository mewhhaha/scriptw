import json,pathlib,statistics
root=pathlib.Path.cwd();base=root/'target/performance-own-property-20261104';docs=root/'docs/rust-rewrite'
r=json.loads((base/'campaign/report.json').read_text());assert r['complete'] and len(r['rows'])==384
cases={c['file']:c for c in r['cases']}
def score(name,actor):return cases[name]['runtimes'][actor]['median_ns']/1e6
def fast(name):return score(name,'scriptw-fast')
def speed(name):return score(name,'scriptw-speed')
a=json.loads((base/'fast-comparison-campaign/aggregate.json').read_text())
engines=a['engines'];candidate=engines['candidate'];v8=engines['v8']
def request(engine,mode):return statistics.median(engine['cases']['rsc-'+mode])/1e6
def phase(name):return statistics.median(p[name] for p in candidate['phase_processes'])
size=json.loads((base/'size/attribution.json').read_text());assert size['program_wasm_sha256']==candidate['identity']['program_wasm_sha256']
code=next(s['total_bytes'] for s in size['sections'] if s['id']==10)
data=next(s['total_bytes'] for s in size['sections'] if s['id']==11)
pbytes=size['program_wasm_bytes'];rbytes=candidate['identity']['runtime']['wasm_bytes'];mi=1048576
pmu=json.loads((base/'publication-reviewed/react-attribution-current.json').read_text())['pmu']['cohorts']
def instructions(engine,mode):return pmu['candidate-'+engine+'-'+mode]['median_of_process_median_raw_counts_per_request']['instructions:u']/1e6
allocator=json.loads((base/'allocator-diagnostic/receipt.json').read_text())['summary']
diagnosis=json.loads((base/'profile/diagnosis.json').read_text())['profiles']
probe=diagnosis['sync-current'];btprobe=diagnosis['none-backtracking']
native=[p for p in r['preparations'] if p['actor']=='scriptw-fast']
if not native:
 print('Preparation keys',r['preparations'][0].keys());raise ValueError('missing Fast preparation')
fp=r['source_identity']['source_fingerprint']
rows='\n'.join(f"| `{c['file']}` | {score(c['file'],'scriptw-fast'):.3f} | {score(c['file'],'scriptw-speed'):.3f} | {score(c['file'],'v8'):.3f} |" for c in r['cases'])
p512={p['actor'].removeprefix('scriptw-'):next(c for c in p['cases'] if c['file']=='frame-branches512.js') for p in r['preparations']}
text=f'''## React Server Components

Measured **2026-11-04** with pinned React 19.3.1 and compiler `{fp[:12]}`.
Both sync and async Flight outputs match Node exactly.

| Engine | Sync · ms | Async · ms |
| --- | ---: | ---: |
| Scriptw | {request(candidate,'sync'):.3f} | {request(candidate,'async'):.3f} |
| Node 24.12.0 / V8 | {request(v8,'sync'):.3f} | {request(v8,'async'):.3f} |

![Matched retained RSC request timings](assets/rsc-current/runtime.svg)

Each engine uses eight fresh processes across two balanced blocks, with three
checked warmups and seven measured requests per mode. Each process retains one
Module/Realm and runs sync then async. Requests include full Flight serialization
and consumption; JSON encoding and exact-output checks follow timing. Values are
medians of process medians. Scriptc's React build failures remain unqualified;
client React/DOM is a separate open scope.

Cold Scriptw setup is **{phase('source_to_wasm')/1e9:.3f} s JavaScript → Wasm**,
**{phase('native_preparation')/1e9:.3f} s native preparation** and
**{phase('module_initialization')/1e6:.3f} ms module initialization**.
Program Wasm is **{pbytes:,} B** ({code:,} B code; {data:,} B data);
shared runtime Wasm is **{rbytes:,} B**. Native preparation, initialization and
input preparation precede request timing. Child peak RSS includes compilation
and process history; it is not the live guest heap.

![RSC cold compilation phases](assets/rsc-current/compilation.svg)

Scriptw uses Wasmtime 47 **Fast / OptLevel::None / SinglePass**, a generic target,
one CPU, 16-MiB copying GC and the recorded stack/deadline/cache settings.
The [fresh hardware-counter diagnosis](react-attribution-current.json) captures
100 checked requests after three warmups in each of three fresh processes per
engine/mode. Scriptw retires **{instructions('scriptw','sync'):.2f} million sync /
{instructions('scriptw','async'):.2f} million async user instructions per request**;
Node retires **{instructions('node','sync'):.2f} / {instructions('node','async'):.2f} million**.
Counters run for their complete windows without multiplexing. This counts the
Scriptw execution worker and Node main thread; Node barrier/Promise-return edges
remain included, while background compilation/GC threads are excluded. These are
unscored instruction counts, not timing ratios or an allocation breakdown.
Current sampled caller paths and exact native prefixes are retained in the
evidence archive, separately from these hardware counts. Inclusive sample
owners overlap; no sampled share predicts a wall-time gain.

Current user-cycle sampling places **{probe["probe_sample_share"]*100:.2f}%** of samples in the stack-probe
regions of `vn` and `ft`. Their entry stack-check budgets are **{probe["entry_stack_check_budget_bytes"]["js::vn#f133"]:,} B /
{probe["entry_stack_check_budget_bytes"]["js::ft#f123"]:,} B**. An allocator-only diagnostic keeps the same Wasm and
`OptLevel::None`: Backtracking reduces these budgets to **{btprobe["entry_stack_check_budget_bytes"]["js::vn#f133"]:,} B / {btprobe["entry_stack_check_budget_bytes"]["js::ft#f123"]:,} B**
and probe samples to **{btprobe["probe_sample_share"]*100:.3f}%**. In four fresh processes per arm, sync/async
requests take **{allocator['none-backtracking']['requests_ms']['sync']:.3f} /
{allocator['none-backtracking']['requests_ms']['async']:.3f} ms**, versus
**{allocator['fast']['requests_ms']['sync']:.3f} /
{allocator['fast']['requests_ms']['async']:.3f} ms** with SinglePass;
native preparation rises from **{allocator['fast']['native_preparation_ms']/1000:.2f} s**
to **{allocator['none-backtracking']['native_preparation_ms']/1000:.2f} s**.
This diagnostic is separate from the scored chart and changes no default.
Allocator choice also changes spill traffic and native code size; probe sample
shares do not account for the complete timing difference.

One typed runtime helper now owns both `instanceof` entry algorithms. Source
operators evaluate their operands once and hold them across the call; the native
method supplies its actual execution Realm. Hooks, bound-target transitions,
prototype walking and whole Throws retain the existing state machine. The
scored comparison keeps Fast's optimization and allocator settings unchanged.
Total executed allocation and each mechanism's causal share remain unmeasured.

Eligible strict ordinary functions pass up to two arguments in Wasm locals to
one canonical source body. Saved actual callable and defining-program guards
permit direct calls; bounded constant/numeric leaves can inline at source level.
Canonical Module root captures use validated direct cells with live import
forwarding and TDZ checks. Internal OwnKeys consumers share a typed key table;
public Reflect.ownKeys still creates the required JavaScript Array.
Arguments observers and unsupported protocols retain ordinary dispatch. Fast and
Speed both disable general native inlining; larger functions still pay for
runtime value tags, environments and dynamic property semantics.

Internal `[[GetOwnProperty]]` reads now return a private descriptor through one
typed runtime boundary. Public Object/Reflect reflection alone materializes
JavaScript descriptor objects. Ordinary/Array direct snapshots remain; Proxy
validation, exotic storage dispatch and execution Realm retain their existing
owners. The helper removes callable/argument-vector creation and six-field
JavaScript descriptor reconstruction from internal reads. Snapshot records still
allocate; total executed allocation remains unmeasured.

Runtime ABI 51 supplies bounded UTF-8 codecs, byte streams with default readers,
events, abort signals and tasks for these fixtures. Fetch/Request/URL integration,
DOM nodes and full WHATWG conformance remain unsupported or unverified.

[Current report and process receipts](rsc-current.json) ·
[Size attribution](rsc-wasm-size-current.json) ·
[Inert evidence archive](situations-evidence-2026-11-04.tar.xz).

## Focused performance situations

Measured **2026-11-04**: 16 standalone Module programs, compiler `{fp[:12]}`
(base `90131a951` plus the archived performance patch),
Node **24.12.0 / V8 13.6.233.17-node.37**, Rust **1.97.1**.
Each program has its own score, separate from RSC and fresh-entry kernels.
No aggregate score combines their arbitrary operation counts.

| Program · retained call | Scriptw Fast · ms | Scriptw Speed · ms | V8 · ms |
| --- | ---: | ---: | ---: |
{rows}

Each value is the median of eight fresh-process medians across two balanced
blocks. Every process initializes one Module/Realm, then runs three checked
warmups and seven measured calls. Four inputs rotate identically in every actor;
every call checks an independently computed integer checksum. Bars show current
configurations; whiskers span the eight process medians. Block medians and
process summaries remain in the [data](situations-current.json).

Scriptw uses Wasmtime 47: **Fast = None / SinglePass**, **Speed = Speed /
Backtracking**, generic target, 16-MiB copying GC, one CPU, 4-GiB cap and no swap.
JavaScript/Wasm/native compilation, module initialization and `prepare(input)`
precede the public `run()` clock. Every Wasmtime consumer has its compiler disabled.
Node uses the same source bytes in `vm.SourceTextModule`, with normal JIT and
natural GC; three warmups do not establish optimized steady state. Timings include
each runtime's public-call bridge and `print` conversion/capture; output draining
and validation follow timing. The empty control is shown without subtraction.
Excluded setup can influence timed GC, feedback and JIT invalidation.

The balanced RSC control compares the frozen prior compiler and current
candidate in both blocks. Additional allocator diagnostics stay separate from
the V8/Fast/Speed chart cohort. Older and current situation cohorts are separate
runs; their process ranges and compiler identities must be retained when
assessing small differences.

### Global lookup

The four programs read six constructor values across 1,024 passes. Deep lookup
retains eight nested padding captures; the bound control captures constructor
references beside the worker. Proven unbound references in eligible ordinary
Module functions now start at the defining Realm's Global Environment Record,
retaining live lexicals, mutable properties and getters.

![Global lookup situations](assets/situations-current/global-lookup.svg)

Shallow/deep also differ in padding reads and arithmetic; their difference is not
pure lexical-depth cost. Bound aliases may fold and V8 may hoist global reads.
The V8 bound control varies with JIT history; retain process ranges and both
block medians rather than treating one ratio as stable. The getter score includes
getter calls and counter increments. Source counts are not executed lookup counts.

### Control-flow and call-site scaling

All four programs make **8,192** entries into a function with one, 32, 128 or 512
selected call sites, exercising every site with identical checksums. Eligible
dense integer switches use guarded Wasm `br_table` dispatch. Fast ranges from
**{fast('frame-compact.js'):.3f} to {fast('frame-branches512.js'):.3f} ms**;
Speed from **{speed('frame-compact.js'):.3f} to {speed('frame-branches512.js'):.3f} ms**.

![Control-flow and call-site scaling](assets/situations-current/frame-size.svg)

![Native program image growth](assets/situations-current/frame-native-image.svg)

The 512-site native P image is **{p512['fast']['native_serialized_bytes']/mi:.2f} MiB Fast /
{p512['speed']['native_serialized_bytes']/mi:.2f} MiB Speed**; portable P is
**{p512['fast']['program_wasm_bytes']/mi:.2f} MiB**. Serialized native images include
metadata and data. Compact dispatch uses a dynamic key and one polymorphic site;
switch arms use constant keys and separate sites. This does not isolate stack
frame growth or stack-probe cost. Eligible call sites now use local argument transport and guarded direct calls.
Compact polymorphic dispatch still requires runtime selection.

### Arguments observation

Both programs make 1,024 strict ordinary calls with captured state, reassign a
formal parameter and compute the same result. The observed program also reads
the original `arguments[0]` and `arguments.length`. Eligible strict functions
omit unobservable arguments objects; Module planning removes unused synthetic
cells before capture hops finalize. Real captures and observers retain storage.
The observed case also loses unused `this`/`new.target` cells, so it is not an
untouched control for that change. Its arguments object remains observable.
The extra observation is timed work; the difference is not an allocation count.

![Arguments observation situations](assets/situations-current/arguments-observation.svg)

### Property mutation history

Both programs perform 8,192 variable-key reads over 64 records. Mutation setup
adds an accessor, deletes properties and restores the values before timing.
Current guarded Number array hits and computed-String own-data hits bypass
object/key conversion and generic lookup. Misses preserve full conversion,
accessors, prototype traversal and proxy dispatch. Each read still inspects live
storage; no new heap or property cache is introduced. These timings combine
indexing, key production and record reads and do not isolate one operation's
cost or allocation count.

![Property mutation history situations](assets/situations-current/property-mutation-history.svg)

### Function property reads

Three programs read own `length`, own `name` and the name string's `length`
over 8,192 passes and eight prepared targets. Ordinary records, JavaScript
functions and native constructors expose identical values and checksums, with
24,576 metadata reads per call; row-array indexing is also timed. Target
construction precedes timing. This makes
function/intrinsic descriptor transport visible beside an ordinary control;
object-kind dispatch, string reads and V8 feedback remain part of each score.

![Function property read situations](assets/situations-current/function-properties.svg)

An unscored layout control keeps eight distinct objects but creates them through
one factory site. Its timed body differs only at four captured-binding slot
constants: the same 8,428 bytes, 157 locals, 3,787 operators and three cached-read
fallback sites. Fast takes **4.574 / 3.665 ms** for eight literal sites / one factory;
Speed takes **2.827 / 1.667 ms**, while V8 stays near **0.020 ms**. This supports
sharing equivalent immutable birth layouts as the next source experiment.
Dynamic miss counts, native-body and GC-state equivalence remain unmeasured;
no RSC gain follows from this control. Preparation differs, and these scores are
separate from the chart cohort; receipts and encoded-body comparison are in the
[report](situations-current.json) and evidence archive.

### Public-call control and verification

![Retained public-call control](assets/situations-current/control.svg)

[Generate/run selected programs](../../CONTRIBUTING.md#focused-performance-situations)
with `--case <file.js>`; choose `--policies fast` or `speed`.
Scriptc has no matched retained-Module consumer here. These programs expose
separate hills, not each mechanism's share of RSC time.

All **384** situation processes and **3,840** calls passed exact-output checks.
The balanced RSC campaign adds 24 processes, including a frozen prior-build
control; chart bars contain only the latest compiler and V8. Encoded-Wasm checks enforce
the private descriptor signature and call boundary. Semantic controls cover
recursive traps, descriptor snapshots across conversion effects, callable,
integer-indexed, string and arguments storage, fresh public descriptor objects
and the executing operation's Realm.

Full workspace CI and pinned Test262 were not rerun. Detailed native/source
verification receipts and the four reproduced pre-existing AOT bootstrap failures
remain in the evidence. Workspace formatting fails on 12 unchanged files;
14 stale Intl identity recipes remain [owned](current-inventory.md).

[Report, identities and process summaries](situations-current.json) ·
[Checksummed UTF-8 evidence](situations-evidence-2026-11-04.tar.xz).

'''
p=docs/'benchmarks.md';old=p.read_text();start=old.index('## React Server Components');end=old.index('<!-- runtime-comparison-details:start -->');p.write_text(old[:start]+text+old[end:])
verification=json.loads((base/'native-verification-current.json').read_text())
verified={r['label']:r['outcomes']['passed'] for r in verification['scopes']}
engine_total=sum(verified[k] for k in ('aot_language','aot_builtins','aot_async','aot_realm_modules'))
structural_total=sum(verified[k] for k in ('structure_language','modules_realms','runtime_link','structure_builtins','structure_async','intl_temporal'))
p=root/'README.md';s=p.read_text()
s=s.replace('13 checked programs compare', '16 checked programs compare').replace('arguments and property mutation history', 'arguments, property mutation history and function metadata')
s=s.replace('**React 19.3.1 RSC · 2026-11-03:**','**React 19.3.1 RSC · 2026-11-04:**').replace('**Focused performance situations · 2026-11-03:**','**Focused performance situations · 2026-11-04:**')
start=s.index('| Sync |');end=s.index('\n\n![Retained RSC requests]',start)
s=s[:start]+f"| Sync | {request(candidate,'sync'):.2f} ms | {request(v8,'sync'):.3f} ms |\n| Async | {request(candidate,'async'):.2f} ms | {request(v8,'async'):.3f} ms |"+s[end:]
start=s.index('Cold Scriptw setup:');end=s.index('\n\n**Focused performance situations',start)
s=s[:start]+f'''Cold Scriptw setup: **{phase('source_to_wasm')/1e9:.2f} s JavaScript → Wasm**, **{phase('native_preparation')/1e9:.2f} s native preparation**,
and **{phase('module_initialization')/1e6:.2f} ms module initialization**. Program Wasm is **{pbytes/mi:.2f} MiB** ({code/mi:.2f} MiB
code, {data/mi:.2f} MiB data); shared runtime Wasm is **{rbytes/mi:.2f} MiB**.
[Size breakdown](docs/rust-rewrite/rsc-wasm-size-current.json) ·
[Benchmark details and caveats](docs/rust-rewrite/benchmarks.md) ·
[Recorded RSC build](docs/rust-rewrite/rsc-current.json).'''+s[end:]
start=s.index('Latest scoped verification');end=s.index('\n\n## Caveats',start)
s=s[:start]+f'''Latest scoped verification (**2026-11-04**): {engine_total:,} Engine cases,
{verified['emission']} Wasm-emission, {structural_total} structural, {verified['ir-full']} IR and
361 source-guard checks pass. AOT units pass {verified['aot-full']} cases; four known
bootstrap assertions still fail.
The focused benchmarks passed 3,840 checked calls; React RSC also passed exact
Flight checks. These scopes do not replace the published full Test262 run.
Full workspace CI was not rerun; formatting failures and 14 stale Intl recipes
remain [owned](docs/rust-rewrite/current-inventory.md).'''+s[end:]
s=s.replace('**Runtime ABI 50:**','**Runtime ABI 51:**')
p.write_text(s)
print('README and benchmark detail updated from final reports')
