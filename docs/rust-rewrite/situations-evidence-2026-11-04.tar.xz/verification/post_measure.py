import hashlib,json,pathlib,subprocess,time
root=pathlib.Path.cwd();base=root/'target/performance-has-instance-20261104';records=[]
def run(label,argv):
 print('START',label,flush=True);start=time.monotonic_ns()
 with (base/(label+'.stdout')).open('xb') as out,(base/(label+'.stderr')).open('xb') as err:p=subprocess.run(argv,cwd=root,stdout=out,stderr=err,timeout=600)
 records.append(dict(label=label,argv=argv,exit_code=p.returncode,elapsed_ns=time.monotonic_ns()-start,source_manifest_sha256=hashlib.sha256((base/'measured-source/manifest.json').read_bytes()).hexdigest()))
 (base/'post-measure-receipt.json').write_text(json.dumps(records,indent=2)+'\n');print('END',label,p.returncode,flush=True);assert p.returncode==0,label
end=time.monotonic()+7200
while True:
 text=(base/'pipeline.stdout').read_text()
 if 'BATCH COMPLETE' in text:
  report=json.loads((base/'native-verification-current.json').read_text())
  if report['complete']:break
 assert time.monotonic()<end,'preceding campaign deadline';time.sleep(2)
run('allocator',['python3','-B',str(base/'allocator_diagnostic.py')])
run('sample-current',['python3','-B',str(base/'profile/profile_rsc_prefix.py'),str(base/'frozen/rsc_baseline'),str(base/'profile/sync-current'),'--mode','sync','--samples','100','--warmups','3','--baseline-json',str(base/'fast-comparison-campaign/block-0-0-candidate/report.json')])
run('sample-allocator',['python3','-B',str(base/'profile/profile_rsc_allocator.py'),str(base/'allocator-diagnostic/rsc-allocator'),str(base/'profile/none-backtracking'),'--mode','sync','--samples','100','--warmups','3','--baseline-json',str(base/'allocator-diagnostic/block-0-0-none-backtracking.json')])
for folder in ['sync-current','none-backtracking']:
 for name in ['vn','ft']:
  binary=base/'profile'/folder/(name+'-prefix.bin')
  with binary.with_suffix('.asm').open('xb') as out:p=subprocess.run(['objdump','-D','-b','binary','-m','i386:x86-64',str(binary)],stdout=out,timeout=30)
  assert p.returncode==0
print('POST MEASUREMENT COMPLETE',flush=True)
