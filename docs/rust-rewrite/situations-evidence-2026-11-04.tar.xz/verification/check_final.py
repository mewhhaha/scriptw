import hashlib,json,pathlib,re,subprocess,time
root=pathlib.Path.cwd();base=root/'target/performance-v8-climb-20261104/scalar-loop';records=[]
assert subprocess.check_output(['git','diff','--binary','HEAD','--','crates','docs/rust-rewrite/contracts'])==(base/'source/tracked.patch').read_bytes()
changed=subprocess.check_output(['git','diff','--name-only','HEAD','--','crates']).decode().splitlines()+subprocess.check_output(['git','ls-files','--others','--exclude-standard','--','crates']).decode().splitlines();rust=sorted({p for p in changed if p.endswith('.rs') and (root/p).exists()})
def run(label,argv,allowed):
 start=time.monotonic_ns()
 with (base/(label+'.stdout')).open('xb') as a,(base/(label+'.stderr')).open('xb') as b:p=subprocess.run(argv,stdout=a,stderr=b,timeout=120)
 records.append(dict(label=label,argv=argv,exit_code=p.returncode,elapsed_ns=time.monotonic_ns()-start));assert p.returncode in allowed,label
run('format-changed',['rustfmt','--check','--edition','2021','--config','skip_children=true',*rust],{0})
run('format-workspace',['cargo','fmt','--all','--','--check'],{1})
text=(base/'format-workspace.stdout').read_text()+(base/'format-workspace.stderr').read_text();files=sorted(set(re.findall(r'^Diff in (.*?):\d+:',text,re.M)));relative=[str(pathlib.Path(p).relative_to(root)) for p in files];expected=set(json.loads((root/'target/performance-v8-climb-20261104/shape/final-checks.json').read_text())['workspace_format_failures'])-{'crates/scriptw-aot-wasm/src/gc_types/value/program_instance.rs'};assert set(relative)==expected and len(files)==11 and not(set(relative)&set(rust)),relative
run('ownership-final',['python3','-B','scripts/conformance_owners.py'],{0})
run('product-graph-final',['./scripts/check-no-interpreter-in-product-graph.sh'],{0})
run('intl-identities-final',['python3','-B','scripts/intl_source_identities.py'],{1});failed=[l for l in (base/'intl-identities-final.stdout').read_text().splitlines() if l.startswith('FAIL ')];assert len(failed)==14,failed
run('diff-final',['git','diff','--check'],{0})
(base/'final-checks.json').write_text(json.dumps(dict(source_manifest_sha256=hashlib.sha256((base/'source/manifest.json').read_bytes()).hexdigest(),changed_rust_files=rust,workspace_format_failures=relative,stale_intl_recipes=failed,commands=records,limits='Changed Rust files format cleanly. Eleven unchanged workspace format failures and14stale Intl recipes remain counted; legacy module-boundary logs remain separate. No full workspace CI or pinned Test262 rerun.'),indent=2)+'\n');print('Changed Rust formatting, ownership, product graph and diff checks pass; existing11format/14identity failures retained')
