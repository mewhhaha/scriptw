import hashlib,json,pathlib,subprocess,time
root=pathlib.Path.cwd();base=root/'target/performance-v8-climb-20261104/for-in-copy';prior=root/'target/performance-own-property-20261104'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
manifest=sha(base/'source/manifest.json')
assert subprocess.check_output(['git','diff','--binary','HEAD','--','crates','docs/rust-rewrite/contracts'])==(base/'source/tracked.patch').read_bytes()
assert (base/'frozen/rsc_baseline').is_file()
records=[]
def run(label,argv):
 print('START',label,flush=True);start=time.monotonic_ns()
 with (base/(label+'.stdout')).open('xb') as out,(base/(label+'.stderr')).open('xb') as err:p=subprocess.run(argv,stdout=out,stderr=err,timeout=1800)
 row=dict(label=label,argv=argv,exit_code=p.returncode,elapsed_ns=time.monotonic_ns()-start,source_manifest_sha256=manifest);records.append(row);(base/'post-qualification-receipt.json').write_text(json.dumps(records,indent=2)+'\n');print('END',label,p.returncode,flush=True);assert p.returncode==0,label
 return row
run('rsc-campaign',['python3','-B',str(base/'measure_rsc.py'),'--candidate',str(base/'frozen/rsc_baseline'),'--candidate-source-snapshot',str(base/'source'),'--output',str(base/'fast-comparison-campaign'),'--time',str(root/'target/performance-worker-cpu/tools/time')])
run('pmu',['python3','-B',str(base/'profile_candidate.py')])
run('size',['python3','-B',str(base/'size/static_and_publish.py')])
print('FORMAL CURRENT-SOURCE MEASUREMENT COMPLETE',flush=True)
