import json,pathlib,subprocess,time
b=pathlib.Path(__file__).resolve().parent;rows=[]
def run(name,argv,timeout=900):
 print('START',name,flush=True);start=time.monotonic_ns()
 with (b/(name+'.stdout')).open('xb') as out,(b/(name+'.stderr')).open('xb') as err:r=subprocess.run(argv,stdout=out,stderr=err,timeout=timeout)
 rows.append(dict(label=name,argv=argv,exit_code=r.returncode,elapsed_ns=time.monotonic_ns()-start));(b/'finish-measurement-receipt.json').write_text(json.dumps(rows,indent=2)+'\n');print('END',name,r.returncode,flush=True);assert r.returncode==0,name
run('pmu',['python3','-B',str(b/'profile_candidate.py')])
run('size',['python3','-B',str(b/'size/static_and_publish.py')])
run('prefix',['python3','-B',str(b/'capture_current_prefix.py')],300)
records=[]
for row in json.loads((b/'profile/commands.json').read_text()):
 print('START profile-'+row['name'],flush=True);start=time.monotonic_ns()
 with pathlib.Path(row['stdout']).open('xb') as out,pathlib.Path(row['stderr']).open('xb') as err:r=subprocess.run(row['argv'],stdout=out,stderr=err,timeout=300)
 records.append(dict(row,exit_code=r.returncode,elapsed_ns=time.monotonic_ns()-start));(b/'profile/run-receipt.json').write_text(json.dumps(records,indent=2)+'\n');assert r.returncode==0,row['name'];print('END profile-'+row['name'],r.returncode,flush=True)
for suffix in ('stdout','stderr'):
 p=b/('format-changed.'+suffix)
 p.rename(b/('format-preflight.'+suffix))
run('final-source-checks',['python3','-B',str(b/'check_final.py')],300)
print('CURRENT MEASUREMENT COMPLETE; READY TO QUALIFY',flush=True)
