import pathlib,subprocess,time,json
b=pathlib.Path(__file__).resolve().parent;rows=[]
for name,argv,timeout in [('formal-measurement',['python3','-B',str(b/'measure_current.py')],1800),('prefix',['python3','-B',str(b/'capture_current_prefix.py')],300),('final-source-checks',['python3','-B',str(b/'check_final.py')],300)]:
 print('START',name,flush=True);start=time.monotonic_ns()
 with (b/(name+'.stdout')).open('xb') as out,(b/(name+'.stderr')).open('xb') as err:r=subprocess.run(argv,stdout=out,stderr=err,timeout=timeout)
 rows.append(dict(label=name,argv=argv,exit_code=r.returncode,elapsed_ns=time.monotonic_ns()-start));(b/'finish-measurement-receipt.json').write_text(json.dumps(rows,indent=2)+'\n');print('END',name,r.returncode,flush=True);assert r.returncode==0,name
print('CURRENT MEASUREMENT COMPLETE; PROFILE THEN QUALIFY',flush=True)
