import hashlib,json,pathlib,re,subprocess,time
root=pathlib.Path.cwd();base=root/'target/performance-v8-climb-20261104/for-in-copy';logs=base/'verification';logs.mkdir(exist_ok=True);scopes=[];commands=[]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
manifest=sha(base/'source/manifest.json')
def save(complete=False):
 (base/'native-verification-current.json').write_text(json.dumps(dict(complete=complete,source_manifest_sha256=manifest,scopes=scopes,producer_commands=commands,superseded_producer_commands=superseded,limits='Fresh scoped native validation on frozen source. Four preexisting AOT bootstrap failures stay failures; no full workspace CI or pinned Test262 rerun. Focused cases overlap broader scopes.'),indent=2)+'\n')
def run(label,argv,package=None,target=None,allowed=(0,),location=logs,timeout=1800):
 print('START',label,flush=True);start=time.monotonic_ns()
 with (location/(label+'.stdout')).open('xb') as out,(location/(label+'.stderr')).open('xb') as err:p=subprocess.run(argv,cwd=root,stdout=out,stderr=err,timeout=timeout)
 row=dict(label=label,argv=argv,exit_code=p.returncode,elapsed_ns=time.monotonic_ns()-start,source_manifest_sha256=manifest,stdout=(location/(label+'.stdout')).relative_to(base).as_posix(),stderr=(location/(label+'.stderr')).relative_to(base).as_posix())
 if package:
  matches=re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;',(location/(label+'.stdout')).read_text());assert len(matches)==1
  state,passed,failed,ignored=matches[0];row.update(package=package,target=target,executable_sha256=sha(pathlib.Path(argv[0])),outcomes=dict(state=state,passed=int(passed),failed=int(failed),ignored=int(ignored)));assert int(passed)+int(failed)>0 and int(ignored)==0;scopes.append(row)
 else:commands.append(row)
 save();print('END',label,p.returncode,flush=True);assert p.returncode in allowed,label
 return row
def artifacts(path):
 events=[json.loads(line) for line in path.read_text().splitlines()];assert any(r.get('reason')=='build-finished' and r['success'] for r in events)
 return {r['target']['name']:r for r in events if r.get('reason')=='compiler-artifact' and r.get('executable') and r['profile']['test']}

initial=json.loads((base/'native-verification-current.json').read_text())
assert initial['source_manifest_sha256']==manifest and not initial['complete']
(base/'native-verification-before-space-retry.json').write_text(json.dumps(initial,indent=2)+'\n')
scopes=initial['scopes'];commands=[row for row in initial['producer_commands'] if row['exit_code']==0]
superseded=[dict(row,reason='Filesystem ENOSPC during atomic Cargo runtime-image output publication; old outputs retained and failed output directory rotated. Product/test inputs unchanged.',category='filesystem-ENOSPC') for row in initial['producer_commands'] if row['exit_code']!=0]
assert len(superseded)==1 and superseded[0]['label']=='native-build' and superseded[0]['exit_code']==101
assert subprocess.check_output(['git','diff','--binary','HEAD','--','crates','docs/rust-rewrite/contracts'])==(base/'source/tracked.patch').read_bytes()
for name,value in json.loads((base/'source/manifest.json').read_text())['files'].items():assert sha(root/name)==value,name
native=artifacts(logs/'native-build-space-retry.stdout')
commands.append(dict(label='native-build-space-retry',argv=superseded[0]['argv'],exit_code=0,source_manifest_sha256=manifest,stdout='verification/native-build-space-retry.stdout',stderr='verification/native-build-space-retry.stderr'))
for label,target,pattern in [('for-in-copy-semantics','aot_builtins','aot_for_in_prefix_copy::'),('typeof-semantics','aot_language','aot_typeof_comparisons::'),('arguments-semantics','aot_language','ordinary_observer_walks_preserve_reentry_nested_arguments_and_captures'),('completion-semantics','aot_language','aot_completion_guard_continuations::')]:
 run(label,[native[target]['executable'],pattern,'--test-threads=1'],'scriptw-engine',target)
names=['structure_language','modules_realms','runtime_link','structure_builtins','structure_async','intl_temporal','aot_language','aot_builtins','aot_async','aot_realm_modules']
for name in names:
 package='scriptw-aot-wasm'
 if name.startswith('aot_'):package='scriptw-engine'
 run(name,[native[name]['executable'],'--test-threads=1'],package,name)
save(True);print('FINAL NATIVE QUALIFICATION COMPLETE',flush=True)
