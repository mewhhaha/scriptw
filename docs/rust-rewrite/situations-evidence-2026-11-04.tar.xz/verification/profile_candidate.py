import pathlib,subprocess,time,json,sys
root=pathlib.Path.cwd();base=root/'target/performance-own-property-20261104';baseline=base/'fast-comparison-campaign/block-0-0-candidate/report.json';binary=base/'frozen/rsc_baseline';driver=root/'target/react-performance-20261103/diagnostics/count_request_pmu.py';node='/home/jacobt/.local/share/fnm/node-versions/v24.12.0/installation/bin/node';rows=[]
for rep in range(3):
 for mode in ('sync','async'):
  for actor in ('scriptw','node'):
   name=f'candidate-{actor}-{mode}-{rep}';argv=[sys.executable,'-B',str(driver),str(base/name),'--engine',actor,'--mode',mode,'--binary',str(binary),'--node',node,'--baseline-json',str(baseline),'--samples','100','--warmups','3'];start=time.monotonic_ns();print('START',name,flush=True)
   with (base/(name+'.stdout')).open('xb') as out,(base/(name+'.stderr')).open('xb') as err:p=subprocess.run(argv,stdout=out,stderr=err,timeout=240)
   rows.append(dict(name=name,argv=argv,exit_code=p.returncode,elapsed_ns=time.monotonic_ns()-start));(base/'candidate-pmu-receipt.json').write_text(json.dumps(rows,indent=2)+'\n');print('END',name,p.returncode,flush=True);assert p.returncode==0
