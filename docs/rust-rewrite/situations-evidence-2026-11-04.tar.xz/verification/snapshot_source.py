"""Freeze reconstruction of the exact measured Rust/contracts inputs before building."""
import hashlib,json,pathlib,subprocess
root=pathlib.Path.cwd();base=root/'target/performance-own-property-20261104';out=base/'measured-source';out.mkdir(exist_ok=True)
def sha(data):return hashlib.sha256(data).hexdigest()
patch=subprocess.check_output(['git','diff','--binary','HEAD','--','crates','docs/rust-rewrite/contracts']);(out/'tracked.patch').write_bytes(patch)
new=subprocess.check_output(['git','ls-files','--others','--exclude-standard','--','crates','docs/rust-rewrite/contracts']).decode().splitlines();files={}
for name in new:
 original=root/name;target=out/name;target.parent.mkdir(parents=True,exist_ok=True);value=original.read_bytes();target.write_bytes(value);files[name]=sha(value)
manifest=dict(base_commit=subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),tracked_patch_sha256=sha(patch),files=files)
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print('frozen',sha((out/'manifest.json').read_bytes()),len(files),'new files')
