import hashlib,json,pathlib,shutil,subprocess,sys,time
root=pathlib.Path.cwd();base=root/'target/performance-has-instance-20261104';frozen=base/'frozen';frozen.mkdir()
source_patch=subprocess.check_output(['git','diff','--binary','HEAD','--','crates','docs/rust-rewrite/contracts'])
assert source_patch==(base/'measured-source/tracked.patch').read_bytes()
for name,sha in json.loads((base/'measured-source/manifest.json').read_text())['files'].items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==sha
rows=[json.loads(line) for line in (base/'build.stdout').read_text().splitlines()]
assert any(r.get('reason')=='build-finished' and r['success'] for r in rows)
for name in ('compiler_precompiled_baseline','rsc_baseline'):
 found=[r for r in rows if r.get('reason')=='compiler-artifact' and r.get('target',{}).get('name')==name and r.get('executable')]
 assert len(found)==1
 artifact=found[0];assert artifact['profile']['opt_level']=='3' and not artifact['profile']['test'] and artifact['features']==[]
 original=pathlib.Path(artifact['executable']);target=frozen/name;shutil.copy2(original,target)
 producer=dict(artifact,source_executable=str(original),executable=str(target),frozen_executable_sha256=hashlib.sha256(target.read_bytes()).hexdigest())
 (frozen/(name+'-producer.json')).write_text(json.dumps(producer,indent=2)+'\n')
