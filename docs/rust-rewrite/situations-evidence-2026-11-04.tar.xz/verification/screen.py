import hashlib,json,pathlib,shutil,subprocess,time
root=pathlib.Path.cwd();base=root/'target/performance-v8-climb-20261104/for-in-copy';commands=[]
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
manifest=sha(base/'source/manifest.json')
def check_source():
 assert subprocess.check_output(['git','diff','--binary','HEAD','--','crates','docs/rust-rewrite/contracts'])==(base/'source/tracked.patch').read_bytes()
 for name,value in json.loads((base/'source/manifest.json').read_text())['files'].items():assert sha(root/name)==value,name
def run(label,argv,timeout=1800):
 check_source();print('START',label,flush=True);start=time.monotonic_ns()
 with (base/(label+'.stdout')).open('xb') as out,(base/(label+'.stderr')).open('xb') as err:p=subprocess.run(argv,stdout=out,stderr=err,timeout=timeout)
 commands.append(dict(label=label,argv=argv,source_manifest_sha256=manifest,exit=p.returncode,elapsed_ns=time.monotonic_ns()-start));(base/'screen-receipt.json').write_text(json.dumps(commands,indent=2)+'\n');print('END',label,p.returncode,flush=True);assert p.returncode==0,label
 return p
def artifacts(path):
 rows=[json.loads(line) for line in path.read_text().splitlines()]
 assert any(r.get('reason')=='build-finished' and r['success'] for r in rows)
 return rows
run('source-guards-final',['python3','-B','scripts/check-source-guards.py','--output',str(base/'source-guards-final')])
run('emission-build',['cargo','test','--release','--locked','-p','scriptw-aot-wasm','--test','emission','--no-run','--message-format=json-render-diagnostics'])
rows=artifacts(base/'emission-build.stdout');selected=[r for r in rows if r.get('reason')=='compiler-artifact' and r['target']['name']=='emission' and r.get('executable')];assert len(selected)==1
binary=selected[0]['executable'];(base/'emission-producer.json').write_text(json.dumps(dict(artifact=selected[0],sha256=sha(pathlib.Path(binary)),source_manifest_sha256=manifest),indent=2)+'\n')
run('emission',[binary,'--test-threads=1'])
run('build',['cargo','build','--release','--locked','-p','scriptw-cli','--example','compiler_precompiled_baseline','--example','rsc_baseline','--message-format=json-render-diagnostics'])
rows=artifacts(base/'build.stdout');engines=[r for r in rows if r.get('reason')=='compiler-artifact' and r['target']['name']=='scriptw_engine'];assert len(engines)==1
rlibs=[pathlib.Path(p) for p in engines[0]['filenames'] if p.endswith('.rlib')];assert len(rlibs)==1
linked=sorted({p for r in rows if r.get('reason')=='build-script-executed' for p in r.get('linked_paths',[])})
for name,pattern,fixtures in [('aot_for_in_prefix_copy',None,['for_in_prefix_copy.js']),('aot_strict_singleton_comparisons',None,['strict_singleton_comparisons.js','strict_singleton_html_dda.js']),('aot_typeof_comparisons',None,['typeof_literal_comparisons.js','typeof_html_dda_comparisons.js']),('aot_unobserved_arguments','ordinary_observer_walks_preserve_reentry_nested_arguments_and_captures',['unobserved_argument_forms.js']),('aot_completion_guard_continuations',None,['completion_guard_continuations.js'])]:
 test_dir='aot_language'
 if name=='aot_for_in_prefix_copy':test_dir='aot_builtins'
 test=root/'crates/scriptw-engine/tests'/test_dir/(name+'.rs');output=base/name
 argv=['rustc','--edition=2021','--test',str(test),'-L','dependency=target/release/deps','--extern','scriptw_engine='+str(rlibs[0]),'-C','link-arg=-fuse-ld=lld','-o',str(output)]
 for path in linked:argv+=['-L',path]
 fixture_hashes={name:sha(root/'crates/scriptw-engine/tests/fixtures'/name) for name in fixtures}
 (base/(name+'-producer.json')).write_text(json.dumps(dict(artifact=engines[0],rlib_sha256=sha(rlibs[0]),test_sha256=sha(test),fixture_sha256=fixture_hashes,linked_paths=linked,source_manifest_sha256=manifest,argv=argv),indent=2)+'\n')
 run(name+'-build',argv)
 test_argv=[str(output)]
 if pattern:test_argv+=[pattern]
 run(name,test_argv+['--test-threads=1'])
f=base/'frozen';f.mkdir()
for name in ('rsc_baseline','compiler_precompiled_baseline'):
 selected=[r for r in rows if r.get('reason')=='compiler-artifact' and r['target']['name']==name and r.get('executable')];assert len(selected)==1
 a=selected[0];p=pathlib.Path(a['executable']);shutil.copy2(p,f/name);(f/(name+'-producer.json')).write_text(json.dumps(dict(artifact=a,sha256=sha(p),source_manifest_sha256=manifest),indent=2)+'\n')
for rep in range(2):
 for actor in (['baseline','candidate'] if rep==0 else ['candidate','baseline']):
  binary=root/'target/performance-v8-climb-20261104/singletons/frozen/rsc_baseline'
  if actor=='candidate':binary=f/'rsc_baseline'
  run(f'rsc-{rep}-{actor}',[str(binary),'target/application-benchmarks-20261102/generated-v2/rsc.js','target/application-benchmarks-20261102/generated-v2/support.json',str(base/f'rsc-{rep}-{actor}.json'),'7','3','fast'])
run('situations',['python3','-B','scripts/benchmark-situations.py','--host',str(f/'compiler_precompiled_baseline'),'--producer-log',str(base/'build.stdout'),'--fixtures','target/performance-v8-climb-20261104/for-in-copy-staged/fixtures','--output',str(base/'campaign'),'--node','/home/jacobt/.local/share/fnm/node-versions/v24.12.0/installation/bin/node','--time',str(root/'target/performance-worker-cpu/tools/time')])
check_source();print('UNOBSERVABLE WORK SCREEN COMPLETE',flush=True)
