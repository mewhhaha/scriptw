import hashlib,json,pathlib,subprocess,time
root=pathlib.Path.cwd();base=root/'target/performance-own-property-20261104';path=base/'native-verification-current.json';r=json.loads(path.read_text());label='metadata-control-corrected';argv=['python3','-B',str(base/'compare_metadata.py')];start=time.monotonic_ns()
with (base/'verification'/(label+'.stdout')).open('xb') as out,(base/'verification'/(label+'.stderr')).open('xb') as err:p=subprocess.run(argv,stdout=out,stderr=err,timeout=600)
row=dict(label=label,argv=argv,exit_code=p.returncode,elapsed_ns=time.monotonic_ns()-start,source_manifest_sha256=r['source_manifest_sha256'],stdout='verification/'+label+'.stdout',stderr='verification/'+label+'.stderr');assert p.returncode==0
failed=[x for x in r['producer_commands'] if x['exit_code']!=0];assert len(failed)==1 and failed[0]['label']=='metadata-control'
r['superseded_producer_commands']=[dict(failed[0],reason='Diagnostic passed the compact public source identity to the existing native validator; that validator also requires shared_configuration from the actual host identity. One baseline consumer completed; no candidate comparison was summarized. Production/qualification/RSC/situations/PMU/size inputs unchanged. Corrected validator argument and reran all72 control processes.')]
r['producer_commands']=[x for x in r['producer_commands'] if x['exit_code']==0]+[row];r['complete']=True;path.write_text(json.dumps(r,indent=2)+'\n')
with (base/'pipeline.stdout').open('a') as out:out.write('END metadata-control-corrected 0\nBATCH COMPLETE\n')
print('Corrected diagnostic complete; all passing scopes and original failure retained',flush=True)
