#!/usr/bin/env python3
"""Unpublished, serial Fast-mode comparison of the prior and current RSC candidates."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import statistics
import sys

ROOT = Path(__file__).resolve().parents[2]
WORK = ROOT / 'target/performance-own-property-20261104'
DRIVER = ROOT / 'crates/scriptw-cli/tests/fixtures/edge_rendering/react-driver.cjs'
sys.path.insert(0, str(ROOT / 'scripts'))
from benchmark_metrics import digest, measure_process
from limited_verification import kernel_group, limited_environment, require_kernel_budget

CASES = ('rsc-sync', 'rsc-async')
ENGINES = ('baseline', 'candidate', 'v8')
FIELDS = ('memory.max', 'memory.swap.max', 'memory.oom.group', 'cpu.max', 'memory.events')
PHASES = ('front_and_lower', 'wasm_emission', 'source_to_wasm', 'engine_setup',
          'native_preparation', 'realm_and_instantiation', 'module_initialization')


def require(condition, message):
    if not condition:
        raise ValueError(message)


def load(path):
    return json.loads(path.read_text())


def save(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')


def sha(value):
    return hashlib.sha256(value).hexdigest()


def executable(value):
    path = Path(shutil.which(str(value)) or value).resolve(strict=True)
    require(path.is_file() and os.access(path, os.X_OK), 'not executable: ' + str(path))
    return path


def resources():
    return {name: (kernel_group() / name).read_text().strip() for name in FIELDS}


def unchanged(left, right):
    require(all(left[name] == right[name] for name in FIELDS if name != 'memory.events'),
            'cgroup policy changed')
    before, after = [dict(line.split() for line in row['memory.events'].splitlines())
                     for row in (left, right)]
    require(all(before.get(key) == after.get(key) for key in ('oom', 'oom_kill', 'oom_group_kill')),
            'cgroup OOM event changed')


def observations(rows):
    require(isinstance(rows, list) and len(rows) == 10, 'require 3 warmups plus 7 observations')
    for index, row in enumerate(rows):
        require(row['index'] == index and type(row['warmup']) is bool
                and row['warmup'] == (index < 3)
                and type(row['elapsed_ns']) is int and row['elapsed_ns'] > 0,
                'invalid measured request observation')
    return int(statistics.median(row['elapsed_ns'] for row in rows if not row['warmup']))


def checked_inputs(report, inputs):
    actual = report['inputs']
    for name in ('source_sha256', 'support_sha256', 'adapted_source_sha256', 'wrapper'):
        require(actual[name] == inputs[name], 'different request input: ' + name)


def checked_scriptw(report, binary, inputs, goldens):
    require(report['schema'] == 'scriptw-react-retained-baseline-v1'
            and report['status'] == 'complete' and 'profiling' not in report,
            'require an ordinary complete Fast-mode Scriptw retained report')
    require(report['executable_sha256'] == digest(binary), 'reported Scriptw executable differs')
    require(report.get('native_mode', 'fast') == 'fast', 'Fast comparison cannot include the Speed diagnostic')
    checked_inputs(report, inputs)
    require([case['case'] for case in report['cases']] == list(CASES), 'Scriptw case order differs')
    medians = {}
    for case in report['cases']:
        expected = goldens[case['case']].removesuffix('\n').encode()
        require(case['samples'] == 7 and case['warmups'] == 3
                and case['exact_node_output_checked'] is True
                and case['expected_json_sha256'] == sha(expected)
                and case['expected_json_bytes'] == len(expected), 'Scriptw golden check differs')
        median = observations(case['observations'])
        require(case['median_ns'] == median, 'Scriptw process median differs')
        medians[case['case']] = median
    phases = report['phases_ns']
    require(all(type(phases.get(name)) is int and phases[name] > 0 for name in PHASES),
            'missing positive Scriptw phase timings')
    require(phases['source_to_wasm'] == phases['front_and_lower'] + phases['wasm_emission'],
            'source-to-Wasm phase sum differs')
    require(report['configuration']['compilation_jobs'] == 1
            and report['configuration']['native_parallel_compilation'] is False
            and report['configuration']['cranelift_opt_level'] == 'None'
            and report['configuration']['register_allocation'] == 'SinglePass',
            'Scriptw comparison requires actual Fast/SinglePass settings and serial compilation')
    return medians


def checked_node(report, inputs, goldens):
    require(report['schema'] == 'scriptw-react-retained-module-reference-v1'
            and report['node']['node'].startswith('24.')
            and report['case_order'] == list(CASES)
            and report['samples'] == 7 and report['warmups'] == 3, 'different Node retained cohort')
    checked_inputs(report, inputs)
    rows = report['observations']
    require([row['case'] for row in rows] == [case for case in CASES for _ in range(10)],
            'Node request case ordering differs')
    medians = {}
    for case in CASES:
        selected = [row for row in rows if row['case'] == case]
        require(all(row['stdout'] == goldens[case] for row in selected), 'Node exact Flight differs')
        medians[case] = observations(selected)
    for name in ('realm_creation_ns', 'source_module_parse_ns', 'module_link_and_initialization_ns'):
        require(type(report[name]) is int and report[name] > 0, 'invalid Node setup phase')
    return medians


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=WORK / 'fast-comparison-campaign')
    parser.add_argument('--baseline', type=Path,
                        default=ROOT / 'target/performance-has-instance-20261104/frozen/rsc_baseline')
    parser.add_argument('--candidate', type=Path, required=True)
    parser.add_argument('--candidate-source-snapshot', type=Path,
                        default=WORK / 'measured-source')
    parser.add_argument('--baseline-json', type=Path,
                        default=ROOT / 'target/performance-has-instance-20261104/fast-comparison-campaign/block-0-0-candidate/report.json')
    parser.add_argument('--fixtures', type=Path,
                        default=ROOT / 'target/application-benchmarks-20261102/generated-v2')
    parser.add_argument('--node', default='/home/jacobt/.local/share/fnm/node-versions/v24.12.0/installation/bin/node')
    parser.add_argument('--time', default='/usr/bin/time')
    args = parser.parse_args()
    # This refuses uncapped execution, swap, non-grouped OOM and parallel affinity.
    require_kernel_budget(4 * 1024**3)
    require(len(os.sched_getaffinity(0)) == 1, 'require one inherited CPU')
    binaries = {name: executable(getattr(args, name)) for name in ('baseline', 'candidate')}
    require(digest(binaries['baseline']) ==
            'b468ae49f51608cdac1999ad235bb1a3928fddd78aaba499682e7222d3bcb8d8',
            'prior candidate baseline executable differs from the frozen comparison identity')
    require(digest(binaries['baseline']) != digest(binaries['candidate']), 'baseline and candidate binaries are identical')
    source_snapshot = args.candidate_source_snapshot.resolve(strict=True)
    require(source_snapshot.is_dir(), 'candidate measured-source snapshot must be a directory')
    node, timer = executable(args.node), executable(args.time)
    baseline_path = args.baseline_json.resolve(strict=True)
    baseline = load(baseline_path)
    fixtures = args.fixtures.resolve(strict=True)
    source, support = fixtures / 'rsc.js', fixtures / 'support.json'
    support_report = load(support)
    require(support_report['versions']['react'] == '19.3.1'
            and support_report['versions']['react-server-dom-webpack'] == '19.3.1', 'React pins differ')
    inputs = {name: baseline['inputs'][name] for name in
              ('source_sha256', 'support_sha256', 'adapted_source_sha256', 'wrapper')}
    require(digest(source) == inputs['source_sha256'] and digest(support) == inputs['support_sha256'],
            'frozen baseline source/support differ')
    require(sha(source.read_bytes() + inputs['wrapper'].encode()) == inputs['adapted_source_sha256'],
            'frozen wrapper/source adaptation differs')
    require(baseline['executable_sha256'] == digest(binaries['baseline']), 'frozen baseline binary differs')
    goldens = {case: support_report['expected'][case] for case in CASES}
    require(all(isinstance(value, str) and value.endswith('\n') for value in goldens.values()),
            'require exact newline-terminated Node goldens')
    tracked = {source, support, DRIVER, Path(__file__).resolve(), baseline_path, node, timer,
               ROOT / 'scripts/benchmark_metrics.py', ROOT / 'scripts/limited_verification.py',
               *binaries.values()}
    snapshot_files = []
    for path in sorted(source_snapshot.rglob('*')):
        if path.is_dir():
            require(not path.is_symlink(), 'candidate source snapshot contains a symlink directory')
            continue
        require(path.is_file() and not path.is_symlink(), 'candidate source snapshot contains a non-regular file')
        snapshot_files.append(path)
    require(snapshot_files, 'candidate measured-source snapshot is empty')
    tracked.update(snapshot_files)
    source_inventory = WORK / 'source-ready.json'
    if source_inventory.exists():
        tracked.add(source_inventory)
    producer_receipts = {}
    for name, binary in binaries.items():
        receipts = sorted(binary.parent.glob('*producer*.json'))
        require(receipts, 'missing frozen build producer receipt: ' + name)
        tracked.update(receipts)
        producer_receipts[name] = {str(path.relative_to(ROOT)): load(path) for path in receipts}
    fingerprints = {str(path): digest(path) for path in sorted(tracked)}
    output = args.output.resolve()
    require(output.is_relative_to(ROOT), 'evidence output must stay within the checkout')
    output.mkdir(parents=True, exist_ok=False)
    shutil.copyfile(Path(__file__).resolve(), output / 'measure_fast_comparison.py')
    shutil.copyfile(DRIVER, output / 'react-driver.cjs')
    shutil.copyfile(baseline_path, output / 'baseline-identity-report.json')
    if source_inventory.exists():
        shutil.copyfile(source_inventory, output / 'preliminary-source-ready.json')
    report = dict(schema='scriptw-rsc-fast-campaign-v1', status='incomplete',
                  started_at=datetime.now(timezone.utc).isoformat(), processes=[],
                  resources_before=resources(), affinity=sorted(os.sched_getaffinity(0)),
                  inputs=fingerprints, producer_receipts=producer_receipts,
                  policy=dict(blocks=2, processes_per_engine_per_block=4, samples=7, warmups=3,
                              timeout_seconds=60, case_order=list(CASES),
                              process_order=[list(ENGINES), list(reversed(ENGINES))],
                              memory='GNU time child lifetime peak RSS, including preparation; not live guest heap',
                              clock='retained applicationRun through complete Flight; JSON and exact validation outside timer'))
    save(output / 'campaign.json', report)
    configuration = None
    stable = {}
    try:
        for block in range(2):
            order = ENGINES
            if block == 1:
                order = tuple(reversed(order))
            for process in range(4):
                for engine in order:
                    folder = output / f'block-{block}-{process}-{engine}'
                    folder.mkdir()
                    for name in ('tmp', 'cache'):
                        (folder / name).mkdir()
                    env = limited_environment()
                    require(not any(env.get(key) for key in ('NODE_OPTIONS', 'LD_PRELOAD', 'LD_AUDIT')),
                            'forbidden inherited runtime options')
                    for key in list(env):
                        if key.startswith(('SCRIPTW_', 'SCRIPTC_', 'ZIG_')) or key == 'NODE_COMPILE_CACHE':
                            del env[key]
                    env.update(TMPDIR=str(folder / 'tmp'), NODE_DISABLE_COMPILE_CACHE='1',
                               SCRIPTW_CACHE_DIR=str(folder / 'cache'), SCRIPTW_JOBS='1',
                               SCRIPTW_MODULE_MEMORY_CACHE_ENTRIES='1',
                               SCRIPTW_MODULE_MEMORY_CACHE_LIMIT_BYTES=str(64 * 1024**2))
                    raw = folder / 'report.json'
                    argv = [str(node), '--experimental-vm-modules', '--no-warnings', str(DRIVER),
                            'retained-module', str(fixtures)]
                    if engine != 'v8':
                        argv = [str(binaries[engine]), str(source), str(support), str(raw), '7', '3']
                    row = dict(block=block, process=process, engine=engine, argv=argv,
                               environment={key: value for key, value in env.items()
                                            if key.startswith(('NODE_', 'SCRIPTW_')) or key == 'TMPDIR'},
                               resources_before=resources(), report=str(raw.relative_to(output)),
                               stdout=str((folder / 'stdout').relative_to(output)),
                               stderr=str((folder / 'stderr').relative_to(output)), status='incomplete')
                    report['processes'].append(row)
                    save(output / 'campaign.json', report)
                    with (folder / 'stdout').open('xb') as stdout, (folder / 'stderr').open('xb') as stderr:
                        row['resources'] = measure_process(argv, cwd=ROOT, env=env, stdout=stdout,
                                                           stderr=stderr, timeout=60, time_binary=timer)
                    row['resources_after'] = resources()
                    row['stdout_sha256'], row['stderr_sha256'] = digest(folder / 'stdout'), digest(folder / 'stderr')
                    save(folder / 'resources.json', row)
                    save(output / 'campaign.json', report)
                    unchanged(row['resources_before'], row['resources_after'])
                    require(row['resources']['exit_code'] == 0 and row['resources']['timed_out'] is False,
                            'failed child: ' + str(folder))
                    require(not (folder / 'stderr').read_bytes(), 'unexpected child stderr: ' + str(folder))
                    child = load(folder / 'stdout')
                    if engine == 'v8':
                        save(raw, child)
                        row['process_medians_ns'] = checked_node(child, inputs, goldens)
                        identity = {'node': child['node']}
                    else:
                        require(load(raw) == child, 'Scriptw stdout and saved report differ')
                        row['process_medians_ns'] = checked_scriptw(child, binaries[engine], inputs, goldens)
                        if configuration is None:
                            configuration = child['configuration']
                        require(child['configuration'] == configuration, 'Scriptw configuration cohort differs')
                        identity = {name: child[name] for name in ('source_fingerprint', 'source_commit',
                                    'executable_sha256', 'compiler_identity_scheme', 'toolchain',
                                    'configuration', 'program_wasm_sha256', 'runtime', 'inputs')}
                    require(stable.setdefault(engine, identity) == identity, 'engine identity changed: ' + engine)
                    require(all(digest(Path(path)) == expected for path, expected in fingerprints.items()),
                            'tracked campaign input changed')
                    row['report_sha256'] = digest(raw)
                    row['status'] = 'complete'
                    save(folder / 'resources.json', row)
                    save(output / 'campaign.json', report)
                    print(f'block {block + 1}, process {process + 1}, {engine}: checked', flush=True)
        require(len(report['processes']) == 24, 'incomplete process inventory')
        engines = {}
        for engine in ENGINES:
            rows = [row for row in report['processes'] if row['engine'] == engine]
            require(len(rows) == 8 and all(row['status'] == 'complete' for row in rows), 'incomplete engine cohort')
            result = dict(label={'baseline': 'Scriptw prior candidate (Fast)', 'candidate': 'Scriptw current candidate (Fast)', 'v8': 'Node 24 / V8'}[engine],
                          identity=stable[engine], cases={case: [row['process_medians_ns'][case] for row in rows] for case in CASES},
                          process_receipts=rows,
                          block_medians=[dict(block=block, cases={case: statistics.median(
                              row['process_medians_ns'][case] for row in rows if row['block'] == block) for case in CASES})
                                         for block in range(2)])
            if engine != 'v8':
                result['phase_processes'] = [load(output / row['report'])['phases_ns'] for row in rows]
            else:
                result['phase_processes'] = [{name: load(output / row['report'])[name] for name in
                    ('realm_creation_ns', 'source_module_parse_ns', 'module_link_and_initialization_ns')} for row in rows]
            engines[engine] = result
        report['resources_after'] = resources()
        unchanged(report['resources_before'], report['resources_after'])
        report['finished_at'] = datetime.now(timezone.utc).isoformat()
        report['status'] = 'complete'
        save(output / 'campaign.json', report)
        aggregate = dict(schema='scriptw-rsc-fast-comparison-v1', date=report['finished_at'][:10], inputs=fingerprints,
                         measurement=dict(blocks=2, processes_per_engine=8, processes_per_engine_per_block=4,
                                          warmups=3, samples=7, clock=report['policy']['clock'],
                                          case_order=list(CASES), process_order=report['policy']['process_order'],
                                          campaign=str((output / 'campaign.json').relative_to(ROOT)),
                                          campaign_sha256=digest(output / 'campaign.json')),
                         caveat='Prior and current candidate binaries are compared under the same actual Fast/SinglePass Wasmtime settings against one retained Node 24 module. The source revision and binary identities bind each build; the difference is descriptive and is not isolated causal evidence for any single source change. Process medians are units; no significance claim.',
                         source_identity=dict(
                             git_revision_role='base commit only; compiler fingerprint and executable/program/runtime hashes identify measured builds',
                             full_baseline_source_snapshot_preserved=True,
                             baseline_source='Git 19b59f9536cc4a3df102d7e06bce24a9407a70d0 published candidate; exact prior archive identity retained in baseline-rsc-current.json',
                             candidate_measured_source=dict(
                                 path=str(source_snapshot.relative_to(ROOT)),
                                 manifest_sha256=digest(source_snapshot / 'manifest.json'),
                                 files=len(snapshot_files)),
                             evidence_script='measure_fast_comparison.py',
                             evidence_driver='react-driver.cjs'),
                         engines=engines, producer_receipts=producer_receipts)
        save(output / 'aggregate.json', aggregate)
        print('validated Fast comparison retained without publication: ' + str(output / 'aggregate.json'), flush=True)
    except BaseException as error:
        report['status'] = 'failed'
        report['failure'] = str(error)
        save(output / 'campaign.json', report)
        raise


if __name__ == '__main__':
    main()
