"""Replay selected original pinned property-read families on the candidate; no publication."""
from pathlib import Path
import hashlib,json,re,subprocess,sys
ROOT=Path('/workspace/scriptw'); WORK=ROOT/'target/performance-numeric-probe-20261031'
SCOPES=[('array-literal','language/expressions/array'),('property-accessors','language/expressions/property-accessors'),('proxy-get','built-ins/Proxy/get'),('reflect-get','built-ins/Reflect/get')]
rows=[]
for label in sys.argv[1:]:
    cli=WORK/label/'scriptw'
    for name,scope in SCOPES:
        argv=[str(cli),'--jobs','1','test262','run',scope,'--execution-backend','wasm-aot','--suite-root','test262/vendor/test262','--snapshot-dir',str(WORK/('test262-'+label)),'--snapshot-name','numeric-probe-'+label+'-'+name,'--threads','1','--timeout-ms','60000','--reuse-case-workers']
        print('START',label,name,flush=True)
        log=WORK/('test262-'+label+'-'+name+'.log')
        with log.open('xb') as output:
            result=subprocess.run(argv,cwd=ROOT,stdout=output,stderr=subprocess.STDOUT)
        text=log.read_text(); total=re.search(r'^total: (\d+)$',text,re.M); passed=re.search(r'^passed: (\d+)$',text,re.M)
        assert total and int(total[1])>0 and passed
        row={'product':label,'scope':scope,'argv':argv,'exit_code':result.returncode,'total':int(total[1]),'passed':int(passed[1]),'raw':log.name,'executable_sha256':hashlib.sha256(cli.read_bytes()).hexdigest()}
        (WORK/('test262-'+label+'-'+name+'.receipt.json')).write_text(json.dumps(row,indent=2)+'\n')
        rows.append(row); (WORK/('test262-'+label+'-summary.json')).write_text(json.dumps({'scope':'Four selected original pinned families; not full-suite or publication','runs':rows},indent=2)+'\n')
        print('END',label,name,row['passed'],'/',row['total'],'exit',result.returncode,flush=True)
