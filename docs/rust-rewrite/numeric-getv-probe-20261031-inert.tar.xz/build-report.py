"""Assemble report-core.json after the numeric cohort completes; never publish."""
from pathlib import Path
import datetime
import hashlib
import json
import math
import re
import statistics

ROOT = Path('/workspace/scriptw')
OUT = Path(__file__).resolve().parent
PARENT = '658d61568f82b088fcff8783a3fc5073be1fc3f3'
CANDIDATE = 'c615b6e3b896f4aedc8a4292199a11e27114e914d1e6970fe67b3ea8790a03d1'
BASELINE = '6764a3510a89a7830e6277cd91df09c9fc2769da901bcf578d87e9289d7050c5'
REPAIRED_TEST = 'property_read_plans::own_data_cache_and_numeric_array_reads_keep_guarded_loads_and_get_fallbacks'
SCOPES = {
    ('scriptw-aot-wasm', 'scriptw_aot_wasm'): 565,
    ('scriptw-aot-wasm', 'emission'): 41,
    ('scriptw-aot-wasm', 'runtime_link'): 31,
    ('scriptw-aot-wasm', 'structure_builtins'): 172,
    ('scriptw-aot-wasm', 'structure_language'): 152,
    ('scriptw-engine', 'scriptw_engine'): 34,
    ('scriptw-engine', 'aot_builtins'): 569,
    ('scriptw-engine', 'aot_gc_entries'): 256,
    ('scriptw-engine', 'aot_language'): 386,
    ('scriptw-engine', 'aot_realm_modules'): 438,
    ('scriptw-engine', 'runtime_cache'): 4,
}
TEST262_SCOPES = {
    'language/expressions/array',
    'language/expressions/property-accessors',
    'built-ins/Proxy/get',
    'built-ins/Reflect/get',
}


def read(name):
    return json.loads((OUT / name).read_text())


def digest(path):
    # Only source/patch inputs are hashed here; product identities come from receipts.
    assert path.stat().st_size <= 4 * 1024**2, path
    return hashlib.sha256(path.read_bytes()).hexdigest()


def outcome(case, passed, failed=0):
    assert case['outcomes'] == [dict(passed=passed, failed=failed, ignored=0)]
    assert case['state'] == ('failed' if failed else 'passed')
    assert case['exit_code'] == (101 if failed else 0)


def raw_files(stdout):
    assert stdout.endswith('.stdout') and Path(stdout).name == stdout, stdout
    stem = stdout.removesuffix('.stdout')
    paths = dict(stdout=stdout, stderr=stem + '.stderr', command=stem + '.command.json')
    assert all((OUT / name).is_file() for name in paths.values()), paths
    return paths


def validate_analysis(name, order, expected):
    report = read(name)
    assert report['order'] == order
    assert report['samples'] == 21 and report['warmups'] == 10
    rows = report['workloads']
    assert len(rows) == len(expected) == 17
    assert len({row['file'] for row in rows}) == 17
    assert {row['file'] for row in rows} == set(expected)
    raw = []
    for row in rows:
        assert row['source_sha256'] == digest(OUT / 'sources' / row['file'])
        for boundary in ('original', 'retained', 'ordinary'):
            products = row[boundary]['products']
            assert set(products) == {'baseline', 'candidate'}
            for label, values in products.items():
                assert math.isfinite(values['median_ns']) and values['median_ns'] > 0
                rounds = values['rounds']
                assert [r['index'] for r in rounds] == [i for i, actual in enumerate(order) if actual == label]
                raw.extend(raw_files(r['raw']) for r in rounds)
            calculated = 100 * (products['candidate']['median_ns'] / products['baseline']['median_ns'] - 1)
            assert math.isclose(row[boundary]['change_percent'], calculated, abs_tol=1e-9)
        reference = row['v8_reference']
        assert reference['median_ns'] > 0 and math.isfinite(reference['median_ns'])
        assert [r['index'] for r in reference['rounds']] == list(range(4))
        raw.extend(raw_files(r['raw']) for r in reference['rounds'])
    return report, raw


def startup_rows(prefix, order, expected_stdout, identities):
    rows = []
    for index, label in enumerate(order):
        stem = f'{prefix}-r{index}-{label}-startup'
        paths = raw_files(stem + '.stdout')
        command = read(paths['command'])
        assert command['exit_code'] == 0 and not command['timed_out']
        record = read(paths['stdout'])
        assert record['source_fingerprint'] == identities[label]['source_fingerprint']
        observations = record['observations']
        assert len(observations) == 31
        assert all(o['matched'] and o['stdout'] == expected_stdout for o in observations)
        samples = [o for o in observations if not o['warmup']]
        assert len(samples) == 21
        rows.append(dict(
            index=index, product=label, raw=paths,
            median_execution_ns=statistics.median(o['phases_ns']['execution'] for o in samples),
        ))
    return rows


def main():
    initial = read('native-numeric-probe/receipt.json')
    failed = read('native-probe-final/receipt.json')
    final = read('native-probe-final-v2/receipt.json')
    for receipt in (initial, failed, final):
        assert receipt['head'] == PARENT and receipt['source_unchanged']
        assert receipt['shared_runtime_linker_unchanged']
    cases = {(c['package'], c['target']): c for c in initial['cases']}
    assert len(initial['cases']) == len(cases) == len(SCOPES) == 11
    assert set(cases) == set(SCOPES)
    for key, retained_count in SCOPES.items():
        if key == ('scriptw-aot-wasm', 'scriptw_aot_wasm'):
            outcome(cases[key], 566)  # Includes the subsequently removed draft test.
        elif key == ('scriptw-aot-wasm', 'emission'):
            outcome(cases[key], 40, 1)
        else:
            outcome(cases[key], retained_count)
    assert len(failed['cases']) == len(final['cases']) == 1
    outcome(failed['cases'][0], 0, 1)
    outcome(final['cases'][0], 1)
    for case in (failed['cases'][0], final['cases'][0]):
        assert (case['package'], case['target']) == ('scriptw-aot-wasm', 'emission')
        assert case['native_filter'] == REPAIRED_TEST
        assert REPAIRED_TEST in case['command']
    assert sum(SCOPES.values()) == 2648

    reuse = read('test-repair-reuse-proof.json')
    assert reuse['test_registration_restored_to_parent'] and reuse['no_runtime_abi_change']
    assert reuse['final_receipt'] == 'native-probe-final-v2/receipt.json'
    inputs = read('candidate-compile-inputs.json')
    assert len(inputs) == 5
    checked_inputs = {}
    for name, record in inputs.items():
        if name.startswith('crates/'):
            assert not Path(name).is_absolute() and '..' not in Path(name).parts
            assert digest(ROOT / name) == record['sha256'], name
            checked_inputs[name] = record
    assert set(checked_inputs) == {
        'crates/scriptw-aot-wasm/src/operations.rs',
        'crates/scriptw-aot-wasm/tests/emission/property_read_plans.rs',
    }
    for name, record in reuse['production_unchanged'].items():
        assert checked_inputs[name] == record

    identities = dict(baseline=read('baseline-identity.json'), candidate=read('candidate/identity.json'))
    assert identities['candidate']['source_commit'] == PARENT
    assert identities['candidate']['source_fingerprint'] == CANDIDATE
    assert identities['baseline']['source_fingerprint'] == BASELINE
    assert identities['baseline']['source_commit'] == '69ce371b964cc3af8da79750507ba5018eb2aef2'
    assert identities['baseline']['shared_configuration'] == identities['candidate']['shared_configuration']
    baseline_reuse = read('baseline-reuse-proof.json')
    assert baseline_reuse['accepted_commit'] == PARENT
    assert baseline_reuse['baseline_original_identity'] == identities['baseline']
    build = read('candidate-build.json')
    assert build['head'] == PARENT and build['exit_code'] == 0

    suite = read('test262-candidate-summary.json')
    assert len(suite['runs']) == 4
    assert {r['scope'] for r in suite['runs']} == TEST262_SCOPES
    candidate_products = read('candidate/products.json')
    for run in suite['runs']:
        assert run['product'] == 'candidate' and run['exit_code'] == 0
        assert run['passed'] == run['total'] and run['total'] > 0
        assert run['executable_sha256'] == candidate_products['scriptw']['sha256']
        assert (OUT / run['raw']).is_file()

    guards = (OUT / 'source-guards.log').read_text()
    guard_counts = re.findall(r'test result: ok\. (\d+) passed; 0 failed;', guards)
    assert sum(map(int, guard_counts)) == 359
    assert 'ok (30 permanent areas)' in (OUT / 'ownership.log').read_text()
    assert len(re.findall(r'^PASS ', (OUT / 'intl-source.log').read_text(), re.M)) == 15
    assert 'check-no-interpreter-in-product-graph: ok' in (OUT / 'product-graph.log').read_text()

    manifest = read('sources/manifest.json')
    startup = manifest['startup']
    expected = {row['file']: row for row in manifest['execution'] if row['file'] != startup['file']}
    assert len(expected) == 17
    cohorts, raw_index, startup_controls = {}, {}, {}
    orders = dict(initial=['baseline', 'candidate', 'candidate', 'baseline'])
    if (OUT / 'confirmation-analysis.json').exists():
        orders['confirmation'] = ['candidate', 'baseline', 'baseline', 'candidate']
    for prefix, order in orders.items():
        cohorts[prefix], raw_index[prefix] = validate_analysis(prefix + '-analysis.json', order, expected)
        startup_controls[prefix] = startup_rows(prefix, order, startup['stdout'], identities)
    table = []
    for name in expected:
        row = dict(file=name, source_sha256=None, cohorts={})
        for prefix, analysis in cohorts.items():
            actual = next(value for value in analysis['workloads'] if value['file'] == name)
            if row['source_sha256'] is None:
                row['source_sha256'] = actual['source_sha256']
            assert actual['source_sha256'] == row['source_sha256']
            row['cohorts'][prefix] = {key: actual[key] for key in ('original', 'retained', 'ordinary', 'v8_reference')}
        table.append(row)
    optional_controls = {}
    for path in sorted(OUT.glob('*control*-analysis.json')):
        control = read(path.name)
        assert isinstance(control, dict) and control
        if 'complete' in control:
            assert control['complete']
        optional_controls[path.name] = control

    report = dict(
        schema='scriptw-getv-numeric-probe-v1',
        recorded_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        status='measured; retention decision remains with reviewer',
        source=dict(
            parent_commit=PARENT, candidate_fingerprint=CANDIDATE, baseline_fingerprint=BASELINE,
            candidate_identity=identities['candidate'], baseline_identity=identities['baseline'],
            candidate_build=build, baseline_reuse_proof=baseline_reuse,
            patch_sha256=digest(OUT / 'candidate-inputs.patch'),
            build_patch_sha256=digest(OUT / 'compile-inputs.patch'),
            inputs=inputs, verified_current_crate_inputs=checked_inputs,
            identity_note='Candidate is frozen 658d61568 plus its exact recorded patch/snapshots, fingerprint c615b6e3; not a clean-parent build. Baseline reuses accepted fusion products originally built from 69ce371b plus its exact patch, fingerprint 6764a351, with source-bound reuse proof. README/docs snapshot hashes describe build inputs; subsequent measurement prose is intentionally not required to remain byte-identical.',
        ),
        change=dict(
            behavior='Move the existing canonical GetV raw Number/concrete Array/present packed own-data probe before identity ToObject, using the saved original receiver and the same property exit. Every miss retains original conversion, abrupt completion, property lookup and receiver behavior.',
            runtime_layout_version=41, abi_layout_changed=False, default_policy_changed=False,
            source_counts=dict(objects_js=1000, retained_objects_js=65536,
                               scope='Source-level numeric Array reads; potential helper calls avoided only on admitted concrete packed-present hits, not sampled hit/call counts, allocation counts or memory savings.'),
            allocation_memory_claim='None. ToObject of an Array already returns the same object without allocation; this change removes helper-call overhead.',
        ),
        products=dict(baseline=read('baseline-products.json'), candidate=candidate_products),
        validation=dict(
            native_passing_cases=2648, native_unique_scopes=11,
            retained_native_scopes=[dict(package=p, target=t, passed=n) for (p, t), n in SCOPES.items()],
            native_initial='native-numeric-probe/receipt.json',
            native_failed_consolidation='native-probe-final/receipt.json',
            native_final='native-probe-final-v2/receipt.json',
            native_streams=read('native-stream-index.json'), source_bound_continuation=reuse,
            native_count_note='2648 unique retained cases = 565+41+31+172+152+34+569+256+386+438+4. The original library run passed 566 including one draft test later consolidated and removed. Its 565 unchanged retained cases are reused with unchanged production source. Emission combines 40 unchanged original passes with the final repaired exact-one pass. No fresh full 565-case run on the final test topology is claimed; no duplicate draft test or rerun is counted twice.',
            test262_passing_executions=sum(r['passed'] for r in suite['runs']),
            test262_original_families=suite,
            source_only_guards=359, conformance_owners=30, intl_recipes=15,
            product_interpreter_audit='passed',
            formatting=dict(changed_rust='Edition 2021 formatting passed; changed-format-final.log',
                            full_workspace='17 pre-existing file failures retained in workspace-format.log; no full-release formatting acceptance claimed.'),
        ),
        failures_preserved=[
            dict(kind='initial-emission-region', receipt='native-numeric-probe/receipt.json',
                 reason='40 emission cases passed and one outdated structural region expectation failed; other nine scopes and the 566-case library scope passed.'),
            dict(kind='test-consolidation-v1', receipt='native-probe-final/receipt.json',
                 reason='The exact-one conversion assertion incorrectly included the existing R DynamicPropertyRead helper with two key-conversion calls. Final consolidation retains exact-one on computed GetV and preserves the meaningful guard/backing/no-call/ordered-fallback proof in the existing emission owner.'),
            dict(kind='preserved-failed-native', original_binary=read('failed-native/identity.json'),
                 consolidation_binary_sha256=failed['cases'][0]['executable_sha256'],
                 scope='Failed binaries in failed-native are excluded from the inert archive; original failed receipts, executable identities and sealed full streams remain evidence.'),
        ],
        measurement=dict(
            plan=read('measurement-plan.json'), cohorts=table,
            complete_cohort_reports=cohorts, raw_stream_index=raw_index,
            startup_controls=startup_controls, optional_targeted_controls=optional_controls,
            resources={prefix: dict(before=read(prefix + '-resources-before.json'),
                                    after=read(prefix + '-resources-after.json'),
                                    node_identity=read(prefix + '-node-identity.json')) for prefix in cohorts},
            boundaries='All 17 unchanged originals use compiler-disabled precompiled fresh Store/Realm execution. Strict-derived retained calls, ordinary runtime_baseline compile/setup/execute and the existing Node fresh-context reference are separate boundaries; all raw results, startup controls and slower controls are retained.',
            memory='Post-execution smaps process RSS with Store alive is not live JavaScript bytes, peak memory or causal per-owner attribution. Whole-child GNU time peaks include loading/compiler and identity hashing.',
            resource_policy='Inherited managed-cloud 32 GiB cap; CPU 0 for measurements/tests, quota-bound build CPUs; serial Cargo/libtest and retained module cache 512 entries/2 GiB. Swap/group OOM settings are inherited, not local 4 GiB guarantees.',
        ),
        limits=[
            'Selected original Test262 families are not a full pinned-suite publication or full release acceptance.',
            'Published benchmark graphs and full Test262 status remain unchanged.',
            'Every-case V8/Scriptc execution-time and RSS parity remains open; this cohort does not establish parity.',
            'All 17 original, retained, ordinary and V8 controls and startup raw results remain visible; no universal speedup claim.',
            'The helper-call source counts establish neither allocations removed nor memory saved.',
        ],
    )
    (OUT / 'report-core.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(dict(native_retained_cases=2648, native_scopes=11,
                          test262_executions=report['validation']['test262_passing_executions'],
                          workloads=len(table), cohorts=list(cohorts), output='report-core.json'), indent=2), flush=True)


if __name__ == '__main__':
    main()
