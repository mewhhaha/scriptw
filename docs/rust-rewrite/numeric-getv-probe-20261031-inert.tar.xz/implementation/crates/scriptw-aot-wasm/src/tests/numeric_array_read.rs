//! Inspect the generic GetV consumer and the complete fallback its hit bypasses.
use super::*;
use crate::gc_types::{
    ArrayObject, GcHeapType, GcNullability, GlobalLedger, NumberBitsI64Array,
    NumberPresenceU64Array, PackedValueTable, RuntimeModuleTypes, RuntimeSchema,
};

fn source_body<'a>(artifact: &'a WasmArtifact, name: &str) -> Vec<Operator<'a>> {
    let index = function_names(artifact)
        .into_iter()
        .find_map(|(index, actual)| actual.starts_with(&format!("js::{name}#")).then_some(index))
        .expect("actual named source function");
    let mut next = imported_function_count(artifact);
    for payload in Parser::new(0).parse_all(&artifact.bytes) {
        if let Payload::CodeSectionEntry(body) = payload.unwrap() {
            if next == index {
                return body
                    .get_operators_reader()
                    .unwrap()
                    .into_iter()
                    .map(Result::unwrap)
                    .collect();
            }
            next += 1;
        }
    }
    panic!("named source body exists");
}

fn imported_helper(artifact: &WasmArtifact, requested: &str) -> u32 {
    let runtime = artifact.runtime().expect("generic property read links R");
    let definition = function_names_in_bytes(runtime.bytes())
        .into_iter()
        .find_map(|(index, actual)| (actual == requested).then_some(index))
        .expect("registered runtime helper has a name");
    let mut export_name = None;
    for payload in Parser::new(0).parse_all(runtime.bytes()) {
        if let Payload::ExportSection(exports) = payload.unwrap() {
            for export in exports {
                let export = export.unwrap();
                if export.kind == wasmparser::ExternalKind::Func && export.index == definition {
                    export_name = Some(export.name);
                }
            }
        }
    }
    let export_name = export_name.expect("registered helper is exported");
    let mut index = 0;
    for payload in Parser::new(0).parse_all(&artifact.bytes) {
        if let Payload::ImportSection(imports) = payload.unwrap() {
            for import in imports.into_imports() {
                let import = import.unwrap();
                if matches!(
                    import.ty,
                    wasmparser::TypeRef::Func(_) | wasmparser::TypeRef::FuncExact(_)
                ) {
                    if import.module == crate::RUNTIME_IMPORT_NAMESPACE
                        && import.name == export_name
                    {
                        return index;
                    }
                    index += 1;
                }
            }
        }
    }
    panic!("P retains the complete {requested} fallback import");
}

fn type_index<T: GcHeapType>(schema: &RuntimeSchema) -> u32 {
    let wasm_encoder::HeapType::Concrete(index) = schema
        .reference_type::<T>(GcNullability::NonNullable)
        .heap_type
    else {
        panic!("registered GC type has a concrete index");
    };
    index
}

fn frame_end(operators: &[Operator<'_>], start: usize) -> usize {
    let mut depth = 0;
    for (index, op) in operators.iter().enumerate().skip(start + 1) {
        match op {
            Operator::Block { .. }
            | Operator::If { .. }
            | Operator::Loop { .. }
            | Operator::TryTable { .. } => depth += 1,
            Operator::End if depth == 0 => return index,
            Operator::End => depth -= 1,
            _ => {}
        }
    }
    panic!("structured frame has a closing End");
}

fn branch_target_frame(
    operators: &[Operator<'_>],
    branch: usize,
    relative_depth: u32,
) -> (usize, usize) {
    let mut frames = Vec::new();
    for (index, op) in operators[..branch].iter().enumerate() {
        match op {
            Operator::Block { .. }
            | Operator::If { .. }
            | Operator::Loop { .. }
            | Operator::TryTable { .. } => frames.push(index),
            Operator::End => {
                frames.pop().expect("branch is inside the source body");
            }
            _ => {}
        }
    }
    let target = frames[frames.len() - 1 - relative_depth as usize];
    assert!(
        matches!(operators[target], Operator::Block { .. }),
        "a numeric hit exits the property operation"
    );
    (target, frame_end(operators, target))
}

#[test]
fn generic_numeric_get_v_hit_exits_before_to_object_without_calls_or_allocation() {
    let artifact = emit_script(
        "function read(value,key) { return value[key]; } read(globalThis.value,globalThis.key);",
    )
    .expect("unspecialized property read emits");
    Validator::new_with_features(crate::runtime_artifact::program_validation_features())
        .validate_all(&artifact.bytes)
        .expect("generic consumer has valid typed GC roots and operands");
    let operators = source_body(&artifact, "read");
    let registered = RuntimeModuleTypes::register(crate::runtime_artifact::ModuleKind::Program(
        artifact.runtime().unwrap(),
    ))
    .finalize_globals(GlobalLedger::new(), false, 0);
    let schema = registered.globals().schema();
    let array_type = type_index::<ArrayObject>(schema);
    let array = wasmparser::HeapType::Concrete(wasmparser::UnpackedIndex::Module(array_type));
    let candidates: Vec<_> = operators
        .windows(4)
        .enumerate()
        .filter_map(|(start, ops)| {
            if !matches!(ops,
                [Operator::LocalGet { .. }, Operator::I32Const { value }, Operator::I32Eq,
                 Operator::If { .. }] if *value == WasmRuntimeValueTag::Number as i32
            ) {
                return None;
            }
            let end = frame_end(&operators, start + 3);
            operators[start + 4..end]
                .windows(2)
                .any(|ops| {
                    matches!(ops,
                        [Operator::RefTestNonNull { hty }, Operator::If { .. }] if *hty == array
                    )
                })
                .then_some((start, end))
        })
        .collect();
    assert_eq!(
        candidates.len(),
        1,
        "one primitive Number/concrete Array probe in the actual generic consumer"
    );
    let (_, end) = candidates[0];
    let [
        Operator::LocalGet { .. },
        Operator::BrIf { relative_depth },
        ..,
    ] = &operators[end + 1..]
    else {
        panic!("the probe's handled result controls the property exit");
    };
    let branch = end + 2;
    let (property, exit) = branch_target_frame(&operators, branch, *relative_depth);
    // Operand evaluation precedes this block and can have arbitrary effects.
    // The property operation itself must reach a hit without calls or allocation.
    let probe = &operators[property + 1..=branch];
    assert!(
        probe.iter().all(|op| !matches!(
            op,
            Operator::Call { .. }
                | Operator::CallRef { .. }
                | Operator::CallIndirect { .. }
                | Operator::ReturnCall { .. }
                | Operator::ReturnCallRef { .. }
                | Operator::ReturnCallIndirect { .. }
                | Operator::StructNew { .. }
                | Operator::StructNewDefault { .. }
                | Operator::ArrayNew { .. }
                | Operator::ArrayNewDefault { .. }
                | Operator::ArrayNewFixed { .. }
                | Operator::ArrayNewData { .. }
                | Operator::ArrayNewElem { .. }
        )),
        "the entire numeric probe and successful exit make no calls or GC allocations"
    );
    for backing in [
        type_index::<PackedValueTable>(schema),
        type_index::<NumberBitsI64Array>(schema),
        type_index::<NumberPresenceU64Array>(schema),
    ] {
        assert!(
            probe.iter().any(|op| matches!(op,
                Operator::ArrayGet { array_type_index } if *array_type_index == backing
            )),
            "the probe reads live packed payloads and Number presence"
        );
    }
    let mut previous = branch;
    for name in [
        "helper::value_to_object",
        "helper::value_to_property_key",
        "helper::object_read",
    ] {
        let imported = imported_helper(&artifact, name);
        let calls: Vec<_> = operators
            .iter()
            .enumerate()
            .filter_map(|(index, op)| {
                matches!(op, Operator::Call { function_index } if *function_index == imported)
                    .then_some(index)
            })
            .collect();
        assert_eq!(calls.len(), 1, "one saved-operand {name} fallback");
        assert!(
            previous < calls[0] && calls[0] < exit,
            "a numeric hit bypasses the complete ordered ToObject/ToPropertyKey/Get fallback"
        );
        previous = calls[0];
    }
}
