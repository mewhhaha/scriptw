"""Validate complete matched evidence and summarize actual post-execution RSS."""
import json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'scripts'))
import precompiled_comparison as p
run=sys.argv[1]
scored=BASE/('github-'+run)/'precompiled-measurements/precompiled-evidence'
report,rows=p.load_report(scored/'report.json')
bindings=json.loads((BASE/'source-bindings-computed.json').read_text())
clean=next(b for b in bindings if not b['extra_ignored_regress_lock'])
assert report['source_commit']==clean['revision']=='fa204ae2bdccd798b98439d4c347b576c2ee4508'
assert report['source_fingerprint']==clean['source_fingerprint']
assert len(rows)==17 and all(row['runtimes'][rt]['status']=='ok' for row in rows for rt in p.RUNTIMES)
table=[]
for row in rows:
 sw,sc=row['runtimes']['scriptw'],row['runtimes']['scriptc']
 table.append(dict(file=row['file'],scriptw_rss_mib=sw['rss_mib'],scriptc_rss_mib=sc['rss_mib'],
                   ratio=sw['rss_mib']/sc['rss_mib'],scriptw_ms=sw['ms'],scriptc_ms=sc['ms']))
summary=dict(source=report['source_commit'],report_sha256=p.digest(scored/'report.json'),
             ratio_min=min(r['ratio'] for r in table),ratio_max=max(r['ratio'] for r in table),table=table)
(BASE/'measured-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(dict(source=summary['source'],ratio_min=summary['ratio_min'],ratio_max=summary['ratio_max'],
                     representative=[r for r in table if r['file'] in ('integer.js','objects.js','retained-objects.js')]),indent=2))
