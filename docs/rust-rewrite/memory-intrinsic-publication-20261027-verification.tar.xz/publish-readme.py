"""Prepare public prose only after complete source-bound verification publication.

Never run against pending gates. This does not execute archived artifacts or
publish benchmark scores; the paired reader must already admit the new assets.
"""
import hashlib
import json
from pathlib import Path
import sys

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
DEST = ROOT/'docs/rust-rewrite'
STEM = 'memory-intrinsic-publication-20261027'
SOURCE = 'fa204ae2bdccd798b98439d4c347b576c2ee4508'
PREVIOUS = 'f3df68beb76f18506f070fe54b95e80fe2db22be'
CLEAN = 'e695e77969a6816908d7cb992aa5262a7b9b6e8b1422488d4e411c5ad4cf676d'
LOCAL = '6451a26dbc5bfa83b60d1781c8c6d3620b96da646d16452a5142e5072201b72d'
sys.path.insert(0, str(ROOT/'scripts'))
import precompiled_comparison as p
from native_test_protocol import result_summaries


def read(path):
    return json.loads(path.read_text())


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def symbol_size(path, helper):
    found = []
    for line in path.read_text().splitlines():
        words = line.split()
        if len(words) >= 4 and words[-1].endswith('::helper::'+helper):
            found.append(int(words[1], 16))
    assert len(found) == 1, (path, helper, found)
    return found[0]


def main():
    # Every gate and every resulting document is prepared before any doc write.
    record = read(DEST/(STEM+'.json'))
    assert record['schema'] == 'scriptw-intrinsic-initialization-memory-verification-v1'
    assert record['verified_source_commit'] == record['measured_source_commit'] == SOURCE
    assert record['measurement']['run'] == '40504623872'
    assert record['measurement']['url'] == 'https://github.com/mewhhaha/scriptw/actions/runs/40504623872'
    assert record['native']['passed'] == 4874
    scopes = record['native']['scopes']
    assert len(scopes) == len({(row['package'], row['target']) for row in scopes}) == 19
    assert sum(row['passed'] for row in scopes) == record['native']['passed']
    aot = [row for row in scopes if row['package'] == 'scriptw-aot-wasm' and row['target'] == 'scriptw_aot_wasm']
    assert len(aot) == 1 and aot[0]['passed'] == 502
    assert record['test262']['passed'] == record['test262']['total'] == 2365
    assert record['test262']['batch_limit'] == 16
    assert record['test262']['compiler']['identity']['source_revision'] == dict(kind='git-commit', commit=SOURCE)
    assert record['test262']['compiler']['identity']['source_fingerprint'] == LOCAL
    bindings = {row['extra_ignored_regress_lock']:row for row in record['source_bindings']}
    assert len(record['source_bindings']) == 2 and set(bindings) == {False, True}
    assert all(row['revision'] == SOURCE for row in bindings.values())
    assert bindings[False]['source_fingerprint'] == CLEAN and bindings[True]['source_fingerprint'] == LOCAL
    assert bindings[True]['files'] == bindings[False]['files']+1

    native = read(BASE/'native-final/report.json')
    repaired = read(BASE/'verification-repaired.json')
    conformance = read(BASE/'conformance/report.json')
    check = read(BASE/'check.json')
    cheap = read(BASE/'cheap-after-repair/cheap-main.json')
    for gate in (native, repaired, conformance, check):
        assert gate['complete'] and gate['source_commit'] == SOURCE
    assert check['exit_code'] == 0 and cheap['complete'] and cheap['base_commit'] == SOURCE
    assert all(row.get('exit_code', row.get('returncode')) == 0 for row in repaired['commands'])
    assert native['passed_disjoint_scopes'] == 4874 and conformance['passed'] == conformance['total'] == 2365
    retained = {row['path']:row for row in record['retained_files']}
    for name in ('native-final/report.json', 'verification-repaired.json', 'conformance/report.json',
                 'check.json', 'cheap-after-repair/cheap-main.json', 'activation-fixture.json'):
        assert name in retained and sha(BASE/name) == retained[name]['sha256']
    archive = DEST/record['archive']['file']
    assert archive.name == STEM+'-verification.tar.xz' and archive.stat().st_size == record['archive']['bytes']
    assert sha(archive) == record['archive']['sha256']

    fixture = read(BASE/'activation-fixture.json')
    assert record['native']['test_fixture_patch'] == native['test_fixture_patch'] == repaired['test_fixture_patch'] == fixture
    assert fixture['source_commit'] == SOURCE
    assert fixture['path'] == 'crates/scriptw-aot-wasm/src/tests/unobserved_arguments.rs'
    assert fixture['compiler_input_exclusion'] == 'crates/scriptw-aot-wasm/src/tests'
    assert fixture['before_sha256'] != fixture['after_sha256']
    assert sha(BASE/fixture['patch']) == fixture['patch_sha256']
    assert sha(ROOT/fixture['path']) == fixture['after_sha256']
    patch = (BASE/fixture['patch']).read_text()
    assert [line for line in patch.splitlines() if line.startswith('diff --git ')] == [
        'diff --git a/'+fixture['path']+' b/'+fixture['path']]
    original = read(BASE/'native/report.json')
    assert original['source_commit'] == SOURCE and not original['complete'] and 'after' not in original
    completed = [row for row in original['scopes'] if row['complete']]
    assert len(completed) == 4 and sum(row['passed'] for row in completed) == 420
    assert native['original_budget_before'] == original['before']
    failure = BASE/'native/scriptw-aot-wasm-scriptw_aot_wasm-part-000.stdout'
    outcomes = result_summaries(failure.read_text())
    assert len(outcomes) == 1 and outcomes[0][1:3] == ('501', '1')
    before_binaries = read(BASE/'native-original-binaries.json')
    assert len(before_binaries) == 19
    unchanged = 0
    for scope in native['scopes']:
        if scope['target'] == 'scriptw_aot_wasm':
            continue
        old = next(row for row in before_binaries if row['target'] == scope['target'] and row['kind'] == [scope['kind']])
        assert scope['executable_sha256'] == old['sha256']
        unchanged += 1
    assert unchanged == 18

    measured, rows = p.load_report(DEST/'precompiled-comparison.json', DEST/'precompiled-comparison.tar.gz')
    assert measured['source_commit'] == SOURCE and measured['source_fingerprint'] == CLEAN
    assert measured['samples'] == 7 and measured['warmups'] == 10 and measured['rounds'] == 2
    assert len(rows) == 17 and all(row['runtimes'][rt]['status'] == 'ok' for row in rows for rt in p.RUNTIMES)
    summary = read(BASE/'measured-summary.json')
    assert summary['source'] == SOURCE and summary['report_sha256'] == record['measurement']['raw_report_sha256']
    actual = [dict(file=row['file'], scriptw_rss_mib=row['runtimes']['scriptw']['rss_mib'],
                   scriptc_rss_mib=row['runtimes']['scriptc']['rss_mib'],
                   ratio=row['runtimes']['scriptw']['rss_mib']/row['runtimes']['scriptc']['rss_mib'],
                   scriptw_ms=row['runtimes']['scriptw']['ms'], scriptc_ms=row['runtimes']['scriptc']['ms']) for row in rows]
    assert summary['table'] == actual
    assert summary['ratio_min'] == min(row['ratio'] for row in actual)
    assert summary['ratio_max'] == max(row['ratio'] for row in actual) and summary['ratio_max'] > 1
    table = {row['file']:row for row in actual}
    ratio = f"{summary['ratio_min']:.1f}–{summary['ratio_max']:.1f}"
    native_count = f"{record['native']['passed']:,}"
    for graph in ('precompiled-memory.svg', 'precompiled-execution.svg'):
        assert (DEST/'assets'/graph).is_file()

    # Static owned-image inspection is separate from measured residency.
    static = read(BASE/'owned-r-static.json')
    assert static['source_commit'] == SOURCE and static['scored'] is False
    assert sha(BASE/'owned-r-symbols.stdout') == static['commands']['symbols']['stdout_sha256']
    assert sha(BASE/'owned-r-sections.stdout') == static['commands']['sections']['stdout_sha256']
    previous = ROOT/'target/memory-value-backings-20261027-evidence'
    old_static = read(previous/'owned-r-symbols.json')
    assert old_static['source_commit'] == PREVIOUS
    old_record = read(DEST/'memory-value-backings-20261027.json')
    assert old_record['verified_source_commit'] == PREVIOUS
    old_files = {row['path']:row for row in old_record['retained_files']}
    assert sha(previous/'owned-r-symbols.stdout') == old_files['owned-r-symbols.stdout']['sha256']
    assert sha(previous/'owned-r-symbols.json') == old_files['owned-r-symbols.json']['sha256']
    resolver_before = symbol_size(previous/'owned-r-symbols.stdout', 'property_value_resolve')
    resolver_after = symbol_size(BASE/'owned-r-symbols.stdout', 'property_value_resolve')
    realm_before = symbol_size(previous/'owned-r-symbols.stdout', 'realm_initialize_intrinsics')
    realm_after = symbol_size(BASE/'owned-r-symbols.stdout', 'realm_initialize_intrinsics')
    assert (resolver_before, resolver_after, realm_before, realm_after) == (1172086, 320556, 1002573, 888703)

    readme = ROOT/'README.md'
    old_readme = readme.read_text()
    start = old_readme.index('**Measured 2026-10-27 on one GitHub Actions runner**, compiler `f3df68beb`.')
    end = old_readme.index('\n## Benchmarks', start)
    lines = [f'**Measured 2026-10-27 on one GitHub Actions runner**, compiler `{SOURCE[:9]}`.',
        'The [precompiled benchmark workflow](docs/rust-rewrite/contracts/precompiled-comparison.md)',
        'compares Scriptw and Scriptc in the same Wasmtime executable. JavaScript and',
        'Wasm compilation run in separate producer processes; both measured consumers',
        'disable compilation and use identical native optimization and runtime settings.',
        'Both passed the original checksums on **17/17 workloads** across two rounds.',
        f"Scriptw's median post-execution process RSS remains **{ratio}× Scriptc's**:", '',
        '| Workload | Scriptw RSS | Scriptc RSS |', '| --- | ---: | ---: |']
    for label, filename in [('Integer','integer.js'),('Objects','objects.js'),('Retained objects','retained-objects.js')]:
        row = table[filename]
        lines.append(f"| {label} | {row['scriptw_rss_mib']:.1f} MiB | {row['scriptc_rss_mib']:.1f} MiB |")
    lines += ['', 'These are medians of 14 measured samples per runtime and workload, after ten',
        'checked warmups per round, with each Store still alive. RSS includes code,',
        'runtime and allocator history; it is neither live JS heap nor peak memory.',
        'Scriptc parity remains open under the same workloads, checksums and boundaries.',
        'This pass shares intrinsic data/accessor publication and factors deferred',
        'native-method construction into one validated, defining-Realm tail. Aliases',
        'keep shared function identity and independent mutable property descriptors.',
        f'[Verification](docs/rust-rewrite/{STEM}.md):',
        f'**{native_count} native cases and 2,365 original pinned Test262 executions passed**.',
        'One excluded AOT test fixture was repaired for optional compacted imports;',
        'the original failed attempt and exact repair are retained. Product compiler',
        'inputs match the measured source; verification fixtures are explicitly recorded.',
        'Verification used one CPU, a 4-GiB process-tree cap, no swap and bounded module',
        'retention. Original Test262 executions ran in fresh batches of at most 16.',
        'This selected verification leaves the ordinary V8 comparison and full pinned',
        'Test262 status below unchanged.', '',
        '[All measurements and complete evidence](docs/rust-rewrite/precompiled-comparison.md) ·',
        '[Precompiled process-memory graph](docs/rust-rewrite/assets/precompiled-memory.svg) ·',
        '[Precompiled execution-time graph](docs/rust-rewrite/assets/precompiled-execution.svg) ·',
        f"[CI run]({record['measurement']['url']}).", '']
    readme_text = old_readme[:start]+'\n'.join(lines)+old_readme[end:]
    assert readme_text[:start] == old_readme[:start] and readme_text[readme_text.index('\n## Benchmarks'):] == old_readme[end:]

    contract = DEST/'contracts/intrinsic-property-publication.md'
    contract_text = contract.read_text()
    footer = ('Whole-batch compilation, semantic verification and matched memory measurements\n'
              'remain pending. Source review and prepared controls do not establish code-size,\n'
              'execution-time or RSS savings.\n')
    assert contract_text.count(footer) == 1
    contract_text = contract_text.replace(footer, f'''The completed source-bound batch passed {native_count} native cases across 19 targets
and 2,365 exact original pinned Test262 executions. One excluded optional-import
inspection fixture was repaired; the original failed attempt is retained.
The matched 17-workload comparison remains {ratio}× Scriptc process RSS, so parity
is still open. Static owned-image helper sizes confirm smaller code bodies;
these measurements do not isolate execution or RSS effects of individual changes.
See [verification and measurements](../{STEM}.md).
''')
    checkpoint = DEST/(STEM+'.md')
    assert not checkpoint.exists(), 'Inspect an existing checkpoint before replacing it'
    doc = f'''# Intrinsic publication memory checkpoint

Measured and verified product source `{SOURCE}`; refreshed 2026-10-27.
The [matched comparison](precompiled-comparison.md) remains **{ratio}× Scriptc
process RSS**. Scriptc parity is still open. The [CI run]({record['measurement']['url']})
passed all 17 unchanged workloads and original checksums in both runtimes.

Shared Wasm helpers now publish intrinsic data and accessor descriptors through
the existing storage algorithm. These are storage-only operations: publication
neither invokes an accessor nor resolves a deferred method. Every installed
property owns its mutable descriptor; aliases share their immutable function
recipe. Attribute domains, insertion order, reflection, overwrite, deletion,
freeze and defining-Realm identity retain their required semantics.

Deferred method lookup retains its balanced exact-ID dispatch. A private metadata
witness admits only strict, ordinary, nonconstructable standard methods with the
uniform context. Leaves keep the existing typed ExecutableCode construction and
select rooted code, name, native source and length. SelectedMethod can be created
only after the complete dispatch; the shared construction tail requires that
witness. The tail closes the FunctionContext ACTIVE_FUNCTION cycle and publishes
metadata before the recipe caches its completed immutable value. Actual entry,
source ID, name, source text, length, defining Realm and alias identity remain
bound together. No accessor function is made lazy. There is one Wasm GC object
model, no fallback representation and runtime layout 26.
See the [publication contract](contracts/intrinsic-property-publication.md).

Static inspection of owned Cargo R images measured property_value_resolve at
{resolver_before:,} → {resolver_after:,} native bytes and realm_initialize_intrinsics
at {realm_before:,} → {realm_after:,} bytes. This is a source-bound code-size
observation, not proof of which functions ran, resident-memory savings or a
causal explanation of the paired RSS results. Existing physical local reuse is
unchanged; declaration counts do not establish native frame costs.

The release workspace/all-target check and complete source/identity/profile,
retired-JS and formatting guards passed. All **{native_count} native cases across
19 disjoint target inventories** passed, retaining prior test IDs. Focused checks
overlap these totals. All **2,365 exact original pinned Test262 executions** passed
in fresh disjoint batches of at most 16 IDs. This is selected verification;
the ordinary V8 comparison and full pinned-suite status remain unchanged.

Verification includes an explicitly recorded excluded test-fixture repair in
`crates/scriptw-aot-wasm/src/tests/unobserved_arguments.rs`. An absent compacted
P import now means zero calls; actual R resolution and the positive observer
controls requiring at least three retained calls remain. No product input or
test ID was changed by the repair. The original 501-pass/1-fail AOT library
attempt remains archived and is not added to the successful totals. The rebuilt
AOT library passed all 502 cases. All 18 other native binaries are byte-identical.
Four completed original scopes, totaling 420 passes, retain their execution
streams. The stopped original scope has no after-resource counters; successful
repair/resume counters describe the new bounded scope, not that earlier run.

Both runtimes use the same compiler-disabled Wasmtime host/configuration, with
two rounds, ten checked warmups per round and seven measured samples per round.
The checked report owns exact RSS/timing values and both regenerated graphs.
Asynchronous unscored mapping maxima are not phase-aligned endpoints and cannot
establish execution or causal savings. No cost was subtracted from either runtime.

Verification retained one CPU, a 4-GiB process-tree cap, no swap, grouped OOM and
a one-entry/64-MiB module cache. The clean CI source fingerprint is `{CLEAN}`;
local inputs retain the ignored standalone regress lock and fingerprint `{LOCAL}`.
Both input closures and that lock are recorded explicitly; their identities are
not rewritten to appear equal.

[Verification record]({STEM}.json) · [Lossless raw archive]({STEM}-verification.tar.xz).
Native executables and serialized images are excluded from publication. Exact
raw failures, repair patch, resource limits and evidence hashes are retained.
'''
    # The sole mutation boundary follows every gate and prepared-text assertion.
    assert ratio and '**' in readme_text and 'remain pending' not in contract_text
    readme.write_text(readme_text)
    contract.write_text(contract_text)
    checkpoint.write_text(doc)


if __name__ == '__main__':
    main()
