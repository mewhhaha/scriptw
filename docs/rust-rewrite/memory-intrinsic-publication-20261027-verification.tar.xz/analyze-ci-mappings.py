"""Validate inert CI evidence, then describe asynchronous mapping components."""
import hashlib,importlib.util,json,os,stat,sys
from pathlib import Path
BASE=Path(__file__).resolve().parent;ROOT=BASE.parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
import precompiled_comparison as p
from limited_verification import require_kernel_budget
require_kernel_budget(4*1024**3);assert len(os.sched_getaffinity(0))==1
spec=importlib.util.spec_from_file_location('diagnostic',ROOT/'scripts/diagnose-precompiled-mappings.py');d=importlib.util.module_from_spec(spec);spec.loader.exec_module(d)
RUN=sys.argv[1] if len(sys.argv)>1 else '40504623872'
EXPECTED={'40504623872':'fa204ae2bdccd798b98439d4c347b576c2ee4508'}[RUN]
base=BASE/('github-'+RUN);scored=base/'precompiled-measurements/precompiled-evidence';maps=base/'precompiled-mapping-diagnostic-unscored'
report,rows=p.load_report(scored/'report.json');r=json.loads((maps/'report.json').read_text())
assert r['status']=='captured' and r['scored'] is False and r['schema']=='scriptw-precompiled-mapping-diagnostic-v1'
assert r['source_commit']==report['source_commit']==EXPECTED
bindings=json.loads((BASE/'source-bindings-computed.json').read_text());assert r['source_fingerprint']==report['source_fingerprint']==next(x['source_fingerprint'] for x in bindings if x['revision']==EXPECTED and not x['extra_ignored_regress_lock'])
assert p.digest(scored/'report.json')==r['scored_report_sha256']
assert r['executable_sha256']==report['tools']['consumer']['sha256'] and r['shared_configuration']==report['shared_configuration']
expected={(rt,name) for rt in p.RUNTIMES for name in ('integer.js','retained-objects.js')};assert len(r['cases'])==4 and {(c['runtime'],c['file']) for c in r['cases']}==expected
for moment in ('before','after'):
 budget=r['resources'][moment];assert len(budget['cpu_affinity'])==1
 counters=budget['counters'];assert counters['memory.max']=='4294967296' and counters['memory.swap.max']=='0' and counters['memory.oom.group']=='1'
 assert all(int(dict(line.split() for line in counters['memory.events'].splitlines())[k])==0 for k in ('oom','oom_kill','oom_group_kill'))
def safe_bytes(folder,name,limit):
 assert Path(name).name==name
 path=folder/name;info=path.lstat();assert stat.S_ISREG(info.st_mode) and info.st_size<=limit
 value=path.read_bytes();assert len(value)==info.st_size;return value

def groups(snapshot,host):
 result={}
 for m in snapshot['mappings']:
  path=m['path'];perms=m['permissions']
  if path==host:group='host_'+perms
  elif '/private-native-backing-v1/' in path:group='native_file_'+perms
  elif path in ('','[heap]','[stack]'):group='anonymous_'+perms
  else:group='system_'+perms
  row=result.setdefault(group,dict(rss_bytes=0,private_dirty_bytes=0,anonymous_bytes=0,anon_huge_bytes=0))
  for target,field in [('rss_bytes','Rss'),('private_dirty_bytes','Private_Dirty'),('anonymous_bytes','Anonymous'),('anon_huge_bytes','AnonHugePages')]:row[target]+=m.get(field,0)
 assert sum(x['rss_bytes'] for x in result.values())==snapshot['rss_bytes']
 return result

result=dict(scope='validated CI'+RUN+' unscored asynchronous mapping components; maxima are not aligned endpoint phases or live JS bytes',source_commit=r['source_commit'],source_fingerprint=r['source_fingerprint'],scored_report_sha256=r['scored_report_sha256'],mapping_report_sha256=p.digest(maps/'report.json'),cases=[],scored_table=rows)
retained_total=0
for c in r['cases']:
 assert c['status']=='captured' and c['returncode']==0 and c['endpoint_stdout_validated'] is True and 0<len(c['snapshots'])<=128
 folder=maps/(c['runtime']+'-'+c['file'])
 attempt=next(x for x in report['attempts'] if x['runtime']==c['runtime'] and x['file']==c['file'] and x['round']==0)
 command=next(x for x in report['commands'] if x['id']==attempt['consumer_id']);assert c['argv']==command['argv'] and c['image_sha256']==attempt['image']['sha256']
 streams={}
 for name in ('stdout','stderr'):
  value=safe_bytes(folder,c[name]['path'],2*1024**2);assert len(value)==c[name]['bytes'] and hashlib.sha256(value).hexdigest()==c[name]['sha256'];streams[name]=value
 case=next(x for x in report['workloads'] if x['file']==c['file']);endpoint=d.unique_json(streams['stdout']);observations,matched=p._consumer(endpoint,report,attempt['image'],case,c['runtime']);assert matched
 for snap in c['snapshots']:
  raw=safe_bytes(folder,snap['path'],2*1024**2);assert len(raw)==snap['bytes'] and hashlib.sha256(raw).hexdigest()==snap['sha256'];retained_total+=len(raw);assert retained_total<=64*1024**2
  parsed=d.mappings(raw);assert parsed==snap['mappings'] and sum(m['Rss'] for m in parsed)==snap['rss_bytes']
  assert any(m['path']==c['argv'][0] and m['permissions']=='r-xp' and m['inode']==snap['proc_exe']['inode'] for m in parsed)
  presence=snap.get('executable_presence')
  if presence and presence['status']=='present-bits-only-no-PFNs':
   assert set(presence)=={'status','mappings'}
   for m in presence['mappings']:
    assert set(m)=={'file_offset','permissions','page_bytes','pages','present_bits_lsb_hex'} and m['permissions'] in ('r--p','r-xp')
    bits=bytes.fromhex(m['present_bits_lsb_hex']);assert len(bits)==(m['pages']+7)//8
    assert any(x['path']==c['argv'][0] and x['file_offset']==m['file_offset'] and x['permissions']==m['permissions'] and x['end']-x['start']==m['page_bytes']*m['pages'] for x in parsed)
 maximum=max(c['snapshots'],key=lambda x:x['rss_bytes']);assert maximum['path']==c['sampled_maximum']
 entry=dict(runtime=c['runtime'],file=c['file'],samples=len(c['snapshots']),sampled_max_rss_mib=maximum['rss_bytes']/2**20,
  maximum=dict(path=maximum['path'],seconds=maximum['seconds'],groups=groups(maximum,c['argv'][0])),
  final_sample=dict(path=c['snapshots'][-1]['path'],seconds=c['snapshots'][-1]['seconds'],groups=groups(c['snapshots'][-1],c['argv'][0])),
  endpoint_after_execution_rss_mib=p.statistics.median(x['process_snapshots']['after_execution']['rss_bytes'] for x in observations[10:])/2**20,
  endpoint_after_store_drop_rss_mib=p.statistics.median(x['process_snapshots']['after_store_drop']['rss_bytes'] for x in observations[10:])/2**20,
  source_kinds=sorted(set(__import__('re').findall(r'runtime-native packed source: ([a-z-]+)',streams['stderr'].decode()))))
 result['cases'].append(entry)
result['validated_raw_smaps_bytes']=retained_total
(BASE/('ci-mapping-components-'+RUN+'.json')).write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(source=report['source_commit'],all17_scored_workloads=all(x['runtimes'][rt]['status']=='ok' for x in rows for rt in p.RUNTIMES),raw_smaps_bytes=retained_total,cases=[{k:v for k,v in c.items() if k not in ('maximum','final_sample')} for c in result['cases']]),indent=2))
