# Intrinsic initialization batch reviews

Two Sol source reviews guided storage-only Data/Accessor publication. Exact-diff crossreview found no GC, alias, Realm, attribute/order or registration blocker. Present Undefined accessors remain legal; absent slots canonical Undefined; pointer-equal role operands share one immutable snapshot.

Separate source audit disproved physical Wasm local accumulation: exact ValType free-list reuse already exists. No local allocator or native-frame claim is added. Static ownedf3 symbols measure PropertyValueResolve0x11e276bytes and RealmInitializeIntrinsics0xf4c4dbytes; these are function bytes, not residency or execution.

Source review established uniform strict ordinary nonconstructor native fields for eligible deferred methods. Solruntime owner implemented metadata selection plus one common construction tail; Solallocation crossreview matched all context/record/metadata fields against the original factory and found no blocker. Selected refs, defining Realm and recipe stay rooted across allocation; cache follows closed ACTIVE_FUNCTION cycle and metadata. Selection witness added afterward prevents tail-before-selection at compiletime. Entry code/name/source/length remain exact; no new runtimeABI or per-builtin helper.

No builds, probes or semantic tests ran in the agents. Parent owns full bounded verification and measurement. No RSS savings claimed by review.
