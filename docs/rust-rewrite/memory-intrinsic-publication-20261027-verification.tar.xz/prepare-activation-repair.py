"""Record the original artifacts and repair a test-only import assumption."""
import hashlib,json,re,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'scripts'))
from limited_verification import require_kernel_budget
require_kernel_budget(4*1024**3)
SOURCE='fa204ae2bdccd798b98439d4c347b576c2ee4508'
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==SOURCE
assert not subprocess.check_output(['git','diff','HEAD','--','crates','scripts','vendor','Cargo.toml','Cargo.lock'],cwd=ROOT)
rows=[json.loads(s) for s in (BASE/'native/cargo-native.stdout').read_text().splitlines()]
assert rows[-1]==dict(reason='build-finished',success=True)
artifacts=[r for r in rows if r.get('reason')=='compiler-artifact' and r.get('executable') and r['profile']['test']]
assert len(artifacts)==19
manifest=[dict(target=r['target']['name'],kind=r['target']['kind'],path=r['executable'],sha256=sha(Path(r['executable'])),cargo_producer=r) for r in artifacts]
(BASE/'native-original-binaries.json').write_text(json.dumps(manifest,indent=2)+'\n')
relative='crates/scriptw-aot-wasm/src/tests/unobserved_arguments.rs';path=ROOT/relative
source=path.read_text();before=sha(path)
fingerprint=(ROOT/'crates/scriptw-engine/compiler_fingerprint.rs').read_text()
exclusions=re.findall(r'^\s*"([^"]+)",',fingerprint.split('const TEST_ONLY_INPUTS: &[&str] = &[',1)[1].split('];',1)[0],re.M)
excluded=[p for p in exclusions if relative==p or relative.startswith(p+'/')]
assert excluded==['crates/scriptw-aot-wasm/src/tests']
old='    let append_import = append_import.expect("P imports actual R append");\n';assert source.count(old)==1
source=source.replace(old,'    // An unused R import can be absent from the final compacted P.\n')
old='traffic.metadata_appends += usize::from(function_index == append_import)';assert source.count(old)==1
source=source.replace(old,'traffic.metadata_appends += usize::from(append_import == Some(function_index))')
path.write_text(source)
subprocess.run(['rustfmt','--edition','2021','--config','skip_children=true','--check',str(path)],cwd=ROOT,check=True)
patch=subprocess.check_output(['git','diff','--binary','HEAD','--',relative],cwd=ROOT)
(BASE/'activation-fixture.patch').write_bytes(patch)
record=dict(source_commit=SOURCE,path=relative,before_sha256=before,after_sha256=sha(path),patch='activation-fixture.patch',patch_sha256=sha(BASE/'activation-fixture.patch'),compiler_input_exclusion=excluded[0],
 reason='Absent final P import means zero calls. Actual R definition/export resolution, all allocation/depth assertions and observer controls requiring at least three actual append calls are retained. Test IDs unchanged; product compiler inputs unchanged.')
(BASE/'activation-fixture.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
