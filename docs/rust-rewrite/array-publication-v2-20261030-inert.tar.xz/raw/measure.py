"""Run existing benchmark hosts; preserve every command and raw observation."""
from pathlib import Path
import hashlib
import json
import os
import statistics
import sys

ROOT = Path('/workspace/scriptw')
WORK = ROOT / 'target/performance-dense-numbers-20261030/v2'
sys.path.insert(0, str(ROOT / 'scripts'))
from benchmark_metrics import measure_process

FIXTURES = ROOT / 'crates/scriptw-cli/tests/fixtures/v8_execution_hotpaths'
PLAN = json.loads((FIXTURES / 'manifest.json').read_text())
TIME = Path('/workspace/toolchains/system/usr/bin/time')

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def invoke(name, argv, timeout=900, expected=None):
    print(name, flush=True)
    receipt = WORK / (name + '.command.json')
    assert not receipt.exists(), name
    with (WORK / (name + '.stdout')).open('xb') as out, (WORK / (name + '.stderr')).open('xb') as err:
        result = measure_process(argv, cwd=ROOT, env=dict(os.environ), stdout=out,
                                 stderr=err, timeout=timeout, time_binary=TIME)
    result.update(argv=list(map(str, argv)), cwd=str(ROOT), executable_sha256=digest(Path(argv[0])))
    receipt.write_text(json.dumps(result, indent=2) + '\n')
    assert result['exit_code'] == 0 and not result['timed_out'], result
    if expected is not None:
        assert (WORK / (name + '.stdout')).read_text() == expected
        return result
    return json.loads((WORK / (name + '.stdout')).read_text())

def prepare(label):
    host = WORK / label / 'compiler_precompiled_baseline'
    invoke(label + '-prepare-retained', [host, 'prepare-retained', FIXTURES, WORK / (label + '-images')])

def measure():
    resources = dict(affinity=sorted(os.sched_getaffinity(0)),
                     cgroup={name: (Path('/sys/fs/cgroup') / name).read_text().strip()
                             for name in ('memory.max', 'memory.swap.max', 'memory.oom.group', 'cpu.max')},
                     cache_dir=os.environ.get('SCRIPTW_CACHE_DIR'),
                     rounds=[])
    for round_index, label in enumerate(('baseline', 'candidate', 'candidate', 'baseline')):
        round_resource = dict(index=round_index, product=label, load_average_before=os.getloadavg())
        host = WORK / label / 'compiler_precompiled_baseline'
        runner = WORK / label / 'runtime_baseline'
        artifact_dir = WORK / f'round-{round_index}-ordinary-wasm'
        artifact_dir.mkdir()
        for index in range(17):
            invoke(f'round-{round_index}-{label}-startup-{index}',
                   [WORK / label / 'scriptw', 'run', FIXTURES / PLAN['startup']['file']],
                   timeout=60, expected=PLAN['startup']['stdout'] +
                   'run outcome: RunOutcome { backend_used: WasmAot, note: "wasm-aot completion: undefined(undefined)" }\n')
        for case in PLAN['execution']:
            name = case['file']
            invoke(f'round-{round_index}-{label}-retained-{name}',
                   [host, 'execute-retained', WORK / (label + '-images') / (name + '.retained.swpc'),
                    case['stdout'], '7', '10'])
            invoke(f'round-{round_index}-{label}-ordinary-{name}',
                   [runner, FIXTURES, '7', '10', name, artifact_dir])
        round_resource['load_average_after'] = os.getloadavg()
        resources['rounds'].append(round_resource)
        (WORK / 'measurement-resources.json').write_text(json.dumps(resources, indent=2) + '\n')
    analyze()

def analyze():
    producers = {}
    identities = {}
    artifacts = {}
    for label in ('baseline', 'candidate'):
        producers[label] = json.loads((WORK / (label + '-images') / 'producer.json').read_text())
        identities[label] = json.loads((WORK / label / 'identity.json').read_text())
        artifacts[label] = json.loads((WORK / label / 'products.json').read_text())
    before = {case['file']: case for case in producers['baseline']['cases']}
    after = {case['file']: case for case in producers['candidate']['cases']}
    assert set(before) == set(after) == {case['file'] for case in PLAN['execution']}
    assert identities['baseline']['shared_configuration'] == identities['candidate']['shared_configuration']
    for name in before:
        for field in ('original_source_sha256', 'derived_source_sha256', 'stdout'):
            assert before[name][field] == after[name][field], (name, field)
    rows = []
    for case in PLAN['execution']:
        name = case['file']
        row = dict(file=name, original_source_sha256=digest(FIXTURES / name))
        for boundary in ('retained', 'ordinary'):
            products = {}
            for label, rounds in (('baseline', (0, 3)), ('candidate', (1, 2))):
                observations = []
                round_medians = []
                raw = []
                peaks = []
                for round_index in rounds:
                    stem = f'round-{round_index}-{label}-{boundary}-{name}'
                    value = json.loads((WORK / (stem + '.stdout')).read_text())
                    tool = 'compiler_precompiled_baseline' if boundary == 'retained' else 'runtime_baseline'
                    assert value['executable_sha256'] == artifacts[label][tool]['sha256']
                    assert value['source_fingerprint'] == identities[label]['source_fingerprint']
                    values = value['observations'] if boundary == 'retained' else value['cases'][0]['observations']
                    samples = [v['call_ns' if boundary == 'retained' else 'execution_ns'] for v in values if not v['warmup']]
                    assert len(values) == 17 and len(samples) == 7
                    assert all(v.get('matched', True) and v.get('stdout') == case['stdout'] for v in values)
                    observations.extend(samples)
                    round_medians.append(statistics.median(samples))
                    raw.append(stem + '.stdout')
                    peaks.append(json.loads((WORK / (stem + '.command.json')).read_text())['peak_rss_bytes'])
                products[label] = dict(median_ns=statistics.median(observations), round_median_ns=round_medians,
                                       process_lifetime_peak_rss_bytes=peaks, raw=raw)
            row[boundary] = dict(products=products, change_percent=100 * (
                products['candidate']['median_ns'] / products['baseline']['median_ns'] - 1))
        rows.append(row)
    startup = {}
    for label, rounds in (('baseline', (0, 3)), ('candidate', (1, 2))):
        values = [json.loads((WORK / f'round-{r}-{label}-startup-{i}.command.json').read_text())
                  for r in rounds for i in range(10, 17)]
        startup[label] = dict(median_whole_cli_ns=statistics.median(v['elapsed_ns'] for v in values),
                              process_lifetime_peak_rss_bytes=[v['peak_rss_bytes'] for v in values])
    summary = dict(order=['baseline', 'candidate', 'candidate', 'baseline'], samples_per_round=7,
                   warmups_per_round=10, workloads=rows,
                   startup_after_ten_checked_process_warmups=startup,
                   scope='same-machine diagnostic; retained strict derived modules and ordinary fresh Store/Realm are separate boundaries; no V8 or parity claim',
                   memory_scope='GNU time whole-child high-water RSS includes loading, setup and warmups; not live JS bytes or per-call memory')
    (WORK / 'analysis.json').write_text(json.dumps(summary, indent=2) + '\n')
    for row in rows:
        print(row['file'], 'retained', round(row['retained']['change_percent'], 1),
              'ordinary', round(row['ordinary']['change_percent'], 1), flush=True)

if __name__ == '__main__':
    if sys.argv[1] == 'prepare':
        prepare(sys.argv[2])
    elif sys.argv[1] == 'measure':
        measure()
    elif sys.argv[1] == 'analyze':
        analyze()
