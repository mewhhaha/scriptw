"""Inert inspection of the exact frozen hosts' embedded portable runtime ELFs.

Never loads or executes native payloads. Host ELF validation uses the repository
reader; the small ET_REL reader below follows its bounded section/symbol format.
"""
from pathlib import Path
import hashlib
import json
import mmap
import re
import struct
import subprocess
import sys
import zstandard

ROOT = Path(__file__).resolve().parents[4]
WORK = ROOT / 'target/performance-dense-numbers-20261030/v2'
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'scripts'))
import benchmark_module_images as elf

NAMES = [
    'helper::array_packed_join',
    'helper::array_indexed_publish_default_data',
    'helper::array_packed_push1',
    'helper::array_indexed_publish',
    'helper::array_indexed_delete',
    'helper::object_read',
    'helper::object_write',
    'builtin::Array.prototype.push',
    'builtin::Array.prototype.join',
]

def digest(data):
    return hashlib.sha256(data).hexdigest()

def symbols(data):
    header = struct.unpack_from('<16sHHIQQQIHHHHHH', data)
    assert data[:4] == b'\x7fELF' and header[0][4:6] == b'\x02\x01'
    assert header[1] in (1, 2, 3) and header[2] == 62
    assert header[11] == 64 and 0 < header[12] <= 4096
    elf._extent(data, header[6], header[11] * header[12])
    sections = [struct.unpack_from('<IIQQQQIIQQ', data, header[6] + i * 64)
                for i in range(header[12])]
    result = {}
    for table in sections:
        if table[1] != 2:
            continue
        assert table[9] == 24 and table[5] // 24 <= 200000
        elf._extent(data, table[4], table[5])
        strings = sections[table[6]]
        assert strings[1] == 3 and strings[5] <= elf.MAX_NAME_BYTES
        names = bytes(elf._extent(data, strings[4], strings[5]))
        for offset in range(table[4], table[4] + table[5], 24):
            name, info, other, index, value, size = struct.unpack_from('<IBBHQQ', data, offset)
            if not name or not size or index == 0 or index >= len(sections) or info & 15 not in (1, 2):
                continue
            assert name < len(names)
            end = names.index(b'\0', name)
            assert end - name <= elf.MAX_SYMBOL_NAME_BYTES
            name = names[name:end].decode()
            owner = sections[index]
            if owner[1] == 8:
                continue
            start = owner[4] + value - owner[3]
            elf._extent(data, start, size)
            if name in result:
                continue
            result[name] = dict(value=value, bytes=size, file_offset=start,
                                type=info & 15, section=index)
    return result

report = {'scope': 'Static paired native code, not sampled execution or a timing attribution.',
          'script_sha256': digest(Path(__file__).read_bytes()), 'products': {}, 'comparison': []}
for label in ('baseline', 'candidate'):
    folder = OUT / label
    folder.mkdir(exist_ok=True)
    host = WORK / label / 'compiler_precompiled_baseline'
    products = json.loads((WORK / label / 'products.json').read_text())
    identity = json.loads((WORK / label / 'identity.json').read_text())
    with host.open('rb') as stream, mmap.mmap(stream.fileno(), 0, access=mmap.ACCESS_READ) as data:
        host_sha = digest(data)
        assert host_sha == products['compiler_precompiled_baseline']['sha256']
        assert host_sha == identity['executable_sha256']
        elf.parse_elf(data)
        syms = symbols(data)
        native = syms['SCRIPTW_RUNTIME_PORTABLE_NATIVE']
        assert native['type'] == 1
        packed = bytes(elf._extent(data, native['file_offset'], native['bytes']))
        execution = syms['SCRIPTW_RUNTIME_PORTABLE_EXECUTION']
        receipt = bytes(elf._extent(data, execution['file_offset'], execution['bytes']))
        manifest_symbol = syms['SCRIPTW_RUNTIME_PORTABLE_MANIFEST']
        manifest = bytes(elf._extent(data, manifest_symbol['file_offset'], manifest_symbol['bytes']))
    assert receipt[:8] == b'SCRWEX01' and digest(receipt[:-32]) == receipt[-32:].hex()
    assert receipt[13:45].hex() == identity['source_fingerprint']
    assert struct.unpack_from('<I', receipt, 8)[0] == 40
    assert manifest[:8] == b'SCRWNR01' and struct.unpack_from('<I', manifest, 8)[0] == 5
    target_length = struct.unpack_from('<H', manifest, 19)[0]
    assert target_length <= 256 and len(manifest) == 21 + target_length + 128
    manifest_start = 21 + target_length
    assert manifest[21:manifest_start].decode() == identity['shared_configuration']['target_triple']
    assert manifest[manifest_start:manifest_start+32] == receipt[13:45]
    assert manifest[manifest_start+32:manifest_start+64] == receipt[45:77]
    assert manifest[manifest_start+64:manifest_start+96] == receipt[101:133]
    assert manifest[-32:] == packed[16:48]
    assert packed[:8] == b'SWRTZ001' and len(packed) > 48
    length = struct.unpack_from('<Q', packed, 8)[0]
    assert 0 < length <= 256 * 1024 * 1024
    raw = zstandard.ZstdDecompressor(max_window_size=8*1024*1024).decompress(
        packed[48:], max_output_size=length, allow_extra_data=False)
    assert len(raw) == length and digest(raw) == packed[16:48].hex()
    path = folder / 'runtime-portable.elf'
    path.write_bytes(raw)
    native_syms = symbols(raw)
    record = dict(host=str(host), host_sha256=host_sha,
                  source_fingerprint=identity['source_fingerprint'],
                  layout=struct.unpack_from('<I', receipt, 8)[0],
                  runtime_key=receipt[45:77].hex(), packed_symbol=native,
                  manifest_sha256=digest(manifest), manifest_configuration=struct.unpack_from('<I', manifest, 12)[0],
                  manifest_modes=list(manifest[16:19]),
                  packed_sha256=digest(packed), native_bytes=length,
                  native_sha256=digest(raw), functions={})
    for short in NAMES:
        matches = [(name, row) for name, row in native_syms.items()
                   if name.endswith('::' + short)]
        assert len(matches) == 1
        name, row = matches[0]
        assert row['type'] == 2
        assembly = subprocess.check_output([
            'objdump', '-d', '--no-show-raw-insn', '--disassemble=' + name, str(path)], text=True)
        filename = short.replace(':', '_').replace('.', '_') + '.asm'
        (folder / filename).write_text(assembly)
        instructions = [line.split('\t', 1)[1].strip() for line in assembly.splitlines()
                        if '\t' in line]
        stack = next((int(match.group(1), 16) for line in instructions[:40]
                      if (match := re.search(r'sub\s+\$0x([0-9a-f]+),%rsp', line))), 0)
        record['functions'][short] = dict(row, symbol=name, assembly=filename,
            code_sha256=digest(raw[row['file_offset']:row['file_offset'] + row['bytes']]),
            entry_stack_bytes=stack, instruction_count=len(instructions),
            prologue=instructions[:22])
    report['products'][label] = record
for name in NAMES:
    b, c = (report['products'][label]['functions'][name] for label in ('baseline', 'candidate'))
    report['comparison'].append(dict(function=name, baseline_bytes=b['bytes'],
        candidate_bytes=c['bytes'], size_change_percent=100*(c['bytes']/b['bytes']-1),
        baseline_stack_bytes=b['entry_stack_bytes'], candidate_stack_bytes=c['entry_stack_bytes'],
        baseline_instructions=b['instruction_count'], candidate_instructions=c['instruction_count']))
(OUT / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report['comparison'], indent=2))
