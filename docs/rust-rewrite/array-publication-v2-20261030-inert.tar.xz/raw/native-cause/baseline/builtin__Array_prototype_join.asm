
/workspace/scriptw/target/performance-dense-numbers-20261030/v2/native-cause/baseline/runtime-portable.elf:     file format elf64-x86-64


Disassembly of section .text:

000000000040e820 <wasm[0]::function[131]::builtin::Array.prototype.join>:
  40e820:	push   %rbp
  40e821:	mov    %rsp,%rbp
  40e824:	mov    0x8(%rdi),%r10
  40e828:	mov    0x18(%r10),%r10
  40e82c:	add    $0x190,%r10
  40e833:	cmp    %rsp,%r10
  40e836:	ja     4112a9 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2a89>
  40e83c:	sub    $0x180,%rsp
  40e843:	mov    %rbx,0x150(%rsp)
  40e84b:	mov    %r12,0x158(%rsp)
  40e853:	mov    %r13,0x160(%rsp)
  40e85b:	mov    %r14,0x168(%rsp)
  40e863:	mov    %r15,0x170(%rsp)
  40e86b:	mov    %r8,%r13
  40e86e:	mov    %rcx,%r14
  40e871:	mov    0x28(%rbp),%r12
  40e875:	mov    0x30(%rbp),%r8
  40e879:	mov    0x40(%rbp),%r10
  40e87d:	mov    %edx,0x48(%rsp)
  40e881:	mov    %r9d,0x40(%rsp)
  40e886:	mov    %r8d,0xb0(%rsp)
  40e88e:	mov    %r10d,0x58(%rsp)
  40e893:	movl   $0x0,0x80(%rsp)
  40e89e:	mov    0x18(%rdi),%rax
  40e8a2:	mov    (%rax),%rcx
  40e8a5:	mov    %rax,0x140(%rsp)
  40e8ad:	mov    0x8(%rdi),%rdx
  40e8b1:	mov    %rdi,0xb8(%rsp)
  40e8b9:	mov    0x8(%rdx),%rax
  40e8bd:	mov    %rdx,0x138(%rsp)
  40e8c5:	cmp    %rax,%rcx
  40e8c8:	jae    410c04 <wasm[0]::function[131]::builtin::Array.prototype.join+0x23e4>
  40e8ce:	mov    %rax,0xe0(%rsp)
  40e8d6:	mov    0x48(%rsp),%edx
  40e8da:	test   %edx,%edx
  40e8dc:	je     4112ab <wasm[0]::function[131]::builtin::Array.prototype.join+0x2a8b>
  40e8e2:	test   %edx,%edx
  40e8e4:	je     4112ad <wasm[0]::function[131]::builtin::Array.prototype.join+0x2a8d>
  40e8ea:	mov    0x138(%rsp),%r10
  40e8f2:	mov    0x28(%r10),%rcx
  40e8f6:	mov    0x20(%r10),%rsi
  40e8fa:	mov    %edx,%eax
  40e8fc:	xor    %rdx,%rdx
  40e8ff:	lea    (%rsi,%rax,1),%rdi
  40e903:	cmp    %rcx,%rax
  40e906:	cmova  %rdx,%rdi
  40e90a:	mov    0x18(%rdi),%r8d
  40e90e:	mov    %r8d,0x48(%rsp)
  40e913:	mov    0x58(%rsp),%edi
  40e917:	test   %edi,%edi
  40e919:	je     4112af <wasm[0]::function[131]::builtin::Array.prototype.join+0x2a8f>
  40e91f:	test   %r8d,%r8d
  40e922:	je     4112b1 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2a91>
  40e928:	test   %r8d,%r8d
  40e92b:	je     4112b3 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2a93>
  40e931:	mov    %r8d,%r8d
  40e934:	lea    (%rsi,%r8,1),%rax
  40e938:	cmp    %rcx,%r8
  40e93b:	cmova  %rdx,%rax
  40e93f:	mov    0x34(%rax),%ecx
  40e942:	test   %ecx,%ecx
  40e944:	jne    40e952 <wasm[0]::function[131]::builtin::Array.prototype.join+0x132>
  40e94a:	mov    %rdi,%rcx
  40e94d:	jmp    40e95a <wasm[0]::function[131]::builtin::Array.prototype.join+0x13a>
  40e952:	test   %ecx,%ecx
  40e954:	je     4112b5 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2a95>
  40e95a:	mov    %ecx,0x58(%rsp)
  40e95e:	mov    0xb0(%rsp),%esi
  40e965:	test   %esi,%esi
  40e967:	je     40e9b6 <wasm[0]::function[131]::builtin::Array.prototype.join+0x196>
  40e96d:	mov    0xb0(%rsp),%edi
  40e974:	test   %edi,%edi
  40e976:	je     4112b7 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2a97>
  40e97c:	mov    0x28(%r10),%r9
  40e980:	mov    0x20(%r10),%r11
  40e984:	mov    %r10,0x138(%rsp)
  40e98c:	mov    %edi,%r10d
  40e98f:	lea    0x10(%r11,%r10,1),%rsi
  40e994:	xor    %r11,%r11
  40e997:	cmp    %r9,%r10
  40e99a:	cmova  %r11,%rsi
  40e99e:	mov    (%rsi),%r10d
  40e9a1:	cmp    %r12,%r10
  40e9a4:	jne    4112b9 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2a99>
  40e9aa:	mov    0xb0(%rsp),%eax
  40e9b1:	jmp    40ea29 <wasm[0]::function[131]::builtin::Array.prototype.join+0x209>
  40e9b6:	mov    %r10,0x138(%rsp)
  40e9be:	test   %r12,%r12
  40e9c1:	jne    4112bb <wasm[0]::function[131]::builtin::Array.prototype.join+0x2a9b>
  40e9c7:	mov    0xb8(%rsp),%rdi
  40e9cf:	mov    0x20(%rdi),%rdx
  40e9d3:	mov    (%rdx),%eax
  40e9d5:	mov    %eax,%ecx
  40e9d7:	lea    0x20(%rcx),%rsi
  40e9db:	mov    0x4(%rdx),%edi
  40e9de:	cmp    %rdi,%rsi
  40e9e1:	ja     410c1e <wasm[0]::function[131]::builtin::Array.prototype.join+0x23fe>
  40e9e7:	lea    0x20(%rax),%esi
  40e9ea:	mov    %esi,(%rdx)
  40e9ec:	mov    0x138(%rsp),%r9
  40e9f4:	mov    0x20(%r9),%rsi
  40e9f8:	lea    (%rsi,%rcx,1),%rdx
  40e9fc:	movl   $0xa800000e,(%rsi,%rcx,1)
  40ea03:	mov    0xb8(%rsp),%rdi
  40ea0b:	mov    0x28(%rdi),%rdi
  40ea0f:	mov    0x1b4(%rdi),%edi
  40ea15:	mov    %edi,0x4(%rsi,%rcx,1)
  40ea19:	mov    $0x20,%edi
  40ea1e:	mov    %edi,0x8(%rsi,%rcx,1)
  40ea22:	movl   $0x0,0x10(%rdx)
  40ea29:	mov    %eax,0xb0(%rsp)
  40ea30:	test   %eax,%eax
  40ea32:	je     4112bd <wasm[0]::function[131]::builtin::Array.prototype.join+0x2a9d>
  40ea38:	test   %eax,%eax
  40ea3a:	je     4112bf <wasm[0]::function[131]::builtin::Array.prototype.join+0x2a9f>
  40ea40:	mov    0x138(%rsp),%r9
  40ea48:	mov    0x28(%r9),%rcx
  40ea4c:	mov    0x20(%r9),%rdx
  40ea50:	mov    %eax,%edi
  40ea52:	lea    0x10(%rdx,%rdi,1),%rsi
  40ea57:	xor    %rax,%rax
  40ea5a:	cmp    %rcx,%rdi
  40ea5d:	cmova  %rax,%rsi
  40ea61:	mov    (%rsi),%esi
  40ea63:	mov    0x48(%rsp),%esi
  40ea67:	test   %esi,%esi
  40ea69:	je     4112c1 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2aa1>
  40ea6f:	test   %esi,%esi
  40ea71:	je     4112c3 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2aa3>
  40ea77:	mov    %esi,%esi
  40ea79:	add    %rsi,%rdx
  40ea7c:	cmp    %rcx,%rsi
  40ea7f:	cmova  %rax,%rdx
  40ea83:	mov    0x14(%rdx),%eax
  40ea86:	mov    %eax,0x50(%rsp)
  40ea8a:	mov    0x18(%rdx),%eax
  40ea8d:	mov    0xb8(%rsp),%rdi
  40ea95:	mov    0x8c0(%rdi),%edx
  40ea9b:	test   %edx,%edx
  40ea9d:	je     4112c5 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2aa5>
  40eaa3:	mov    0x40(%rsp),%r9d
  40eaa8:	mov    %r14,%rcx
  40eaab:	mov    %r13,%r8
  40eaae:	mov    0xb8(%rsp),%rsi
  40eab6:	call   2a631a0 <wasm[0]::function[1041]::helper::value_to_object>
  40eabb:	mov    %rax,0x128(%rsp)
  40eac3:	mov    %rcx,0x130(%rsp)
  40eacb:	mov    %edx,0x40(%rsp)
  40eacf:	cmp    $0x1,%esi
  40ead2:	je     410bbe <wasm[0]::function[131]::builtin::Array.prototype.join+0x239e>
  40ead8:	mov    $0x8c,%edx
  40eadd:	mov    0xb8(%rsp),%rsi
  40eae5:	mov    0xb8(%rsp),%rdi
  40eaed:	call   2f30600 <wasm[0]::function[1102]::helper::pooled_string_resolve>
  40eaf2:	test   %eax,%eax
  40eaf4:	je     4112c7 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2aa7>
  40eafa:	mov    0x58(%rsp),%ecx
  40eafe:	test   %ecx,%ecx
  40eb00:	je     4112c9 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2aa9>
  40eb06:	mov    0x40(%rsp),%r8d
  40eb0b:	mov    0x50(%rsp),%edx
  40eb0f:	mov    $0x4,%esi
  40eb14:	xor    %rdi,%rdi
  40eb17:	mov    0x130(%rsp),%r9
  40eb1f:	mov    %r9,(%rsp)
  40eb23:	mov    %r8d,0x8(%rsp)
  40eb28:	mov    %esi,0x10(%rsp)
  40eb2c:	mov    %rdi,0x18(%rsp)
  40eb31:	mov    %eax,0x20(%rsp)
  40eb35:	mov    %edx,0x28(%rsp)
  40eb39:	mov    %ecx,0x30(%rsp)
  40eb3d:	mov    0x130(%rsp),%rcx
  40eb45:	mov    0x128(%rsp),%rdx
  40eb4d:	mov    0xb8(%rsp),%rsi
  40eb55:	mov    0xb8(%rsp),%rdi
  40eb5d:	mov    0x128(%rsp),%r9
  40eb65:	call   29e0f80 <wasm[0]::function[1015]::helper::object_read>
  40eb6a:	sub    $0x40,%rsp
  40eb6e:	mov    %rdx,%r8
  40eb71:	mov    %rax,%rdx
  40eb74:	cmp    $0x1,%esi
  40eb77:	je     410b82 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2362>
  40eb7d:	mov    0x58(%rsp),%eax
  40eb81:	test   %eax,%eax
  40eb83:	je     4112cb <wasm[0]::function[131]::builtin::Array.prototype.join+0x2aab>
  40eb89:	mov    0x50(%rsp),%r9d
  40eb8e:	mov    %eax,(%rsp)
  40eb91:	mov    0xb8(%rsp),%rsi
  40eb99:	mov    0xb8(%rsp),%rdi
  40eba1:	call   2aef760 <wasm[0]::function[1062]::helper::value_to_number>
  40eba6:	sub    $0x10,%rsp
  40ebaa:	mov    %rdi,%rbx
  40ebad:	mov    %rax,%r15
  40ebb0:	mov    %edx,0x48(%rsp)
  40ebb4:	xor    %r13,%r13
  40ebb7:	test   %esi,%esi
  40ebb9:	mov    %rsi,%r12
  40ebbc:	je     40ebcd <wasm[0]::function[131]::builtin::Array.prototype.join+0x3ad>
  40ebc2:	mov    %r12,%rsi
  40ebc5:	mov    %rcx,%r14
  40ebc8:	jmp    40ec7e <wasm[0]::function[131]::builtin::Array.prototype.join+0x45e>
  40ebcd:	movq   %rcx,%xmm0
  40ebd2:	mov    %rcx,%r14
  40ebd5:	ucomisd %xmm0,%xmm0
  40ebd9:	setp   %al
  40ebdc:	setne  %cl
  40ebdf:	or     %ecx,%eax
  40ebe1:	xorpd  %xmm1,%xmm1
  40ebe5:	ucomisd %xmm0,%xmm1
  40ebe9:	setae  %cl
  40ebec:	or     %ecx,%eax
  40ebee:	test   %al,%al
  40ebf0:	jne    40ec78 <wasm[0]::function[131]::builtin::Array.prototype.join+0x458>
  40ebf6:	ucomisd 0x27b2(%rip),%xmm0        # 4113b0 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b90>
  40ebfe:	ja     40ec69 <wasm[0]::function[131]::builtin::Array.prototype.join+0x449>
  40ec04:	mov    0xb8(%rsp),%rdi
  40ec0c:	call   3018d5f <wasmtime_builtin_trunc_f64>
  40ec11:	movabs $0x43e0000000000000,%rax
  40ec1b:	movq   %rax,%xmm2
  40ec20:	ucomisd %xmm2,%xmm0
  40ec24:	jae    40ec41 <wasm[0]::function[131]::builtin::Array.prototype.join+0x421>
  40ec2a:	jp     4112cd <wasm[0]::function[131]::builtin::Array.prototype.join+0x2aad>
  40ec30:	cvttsd2si %xmm0,%r13
  40ec35:	cmp    $0x0,%r13
  40ec39:	jge    40ec7b <wasm[0]::function[131]::builtin::Array.prototype.join+0x45b>
  40ec3f:	ud2
  40ec41:	movaps %xmm0,%xmm1
  40ec44:	subsd  %xmm2,%xmm1
  40ec48:	cvttsd2si %xmm1,%r13
  40ec4d:	cmp    $0x0,%r13
  40ec51:	jl     4112cf <wasm[0]::function[131]::builtin::Array.prototype.join+0x2aaf>
  40ec57:	movabs $0x8000000000000000,%rax
  40ec61:	add    %rax,%r13
  40ec64:	jmp    40ec7b <wasm[0]::function[131]::builtin::Array.prototype.join+0x45b>
  40ec69:	movabs $0x1fffffffffffff,%r13
  40ec73:	jmp    40ec7b <wasm[0]::function[131]::builtin::Array.prototype.join+0x45b>
  40ec78:	xor    %r13,%r13
  40ec7b:	mov    %r12,%rsi
  40ec7e:	cmp    $0x1,%esi
  40ec81:	je     410b3f <wasm[0]::function[131]::builtin::Array.prototype.join+0x231f>
  40ec87:	mov    $0x5,%edx
  40ec8c:	mov    0xb8(%rsp),%rsi
  40ec94:	mov    0xb8(%rsp),%rdi
  40ec9c:	call   2f30600 <wasm[0]::function[1102]::helper::pooled_string_resolve>
  40eca1:	mov    %rax,%r10
  40eca4:	mov    0xb0(%rsp),%eax
  40ecab:	test   %eax,%eax
  40ecad:	je     4112d1 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2ab1>
  40ecb3:	test   %eax,%eax
  40ecb5:	je     4112d3 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2ab3>
  40ecbb:	mov    0x138(%rsp),%r9
  40ecc3:	mov    0x28(%r9),%rsi
  40ecc7:	mov    0x20(%r9),%r8
  40eccb:	mov    %eax,%edi
  40eccd:	lea    0x10(%r8,%rdi,1),%rax
  40ecd2:	xor    %r8,%r8
  40ecd5:	cmp    %rsi,%rdi
  40ecd8:	cmova  %r8,%rax
  40ecdc:	mov    (%rax),%esi
  40ecde:	test   %esi,%esi
  40ece0:	jne    40ecf3 <wasm[0]::function[131]::builtin::Array.prototype.join+0x4d3>
  40ece6:	xor    %edx,%edx
  40ece8:	xor    %rcx,%rcx
  40eceb:	mov    %rdx,%r8
  40ecee:	jmp    40ed9a <wasm[0]::function[131]::builtin::Array.prototype.join+0x57a>
  40ecf3:	mov    0xb0(%rsp),%esi
  40ecfa:	test   %esi,%esi
  40ecfc:	je     4112d5 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2ab5>
  40ed02:	test   %esi,%esi
  40ed04:	je     4112d7 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2ab7>
  40ed0a:	mov    0x138(%rsp),%r9
  40ed12:	mov    0x28(%r9),%r11
  40ed16:	mov    0x20(%r9),%rcx
  40ed1a:	mov    %esi,%eax
  40ed1c:	lea    0x10(%rcx,%rax,1),%r8
  40ed21:	xor    %rdx,%rdx
  40ed24:	cmp    %r11,%rax
  40ed27:	cmova  %rdx,%r8
  40ed2b:	mov    (%r8),%edi
  40ed2e:	test   %edi,%edi
  40ed30:	je     4112d9 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2ab9>
  40ed36:	mov    %edi,%eax
  40ed38:	shl    $0x2,%rax
  40ed3c:	shr    $0x20,%rax
  40ed40:	test   %rax,%rax
  40ed43:	jne    4112db <wasm[0]::function[131]::builtin::Array.prototype.join+0x2abb>
  40ed49:	shl    $0x2,%edi
  40ed4c:	add    $0x14,%edi
  40ed4f:	jb     4112dd <wasm[0]::function[131]::builtin::Array.prototype.join+0x2abd>
  40ed55:	add    %edi,%esi
  40ed57:	jb     4112df <wasm[0]::function[131]::builtin::Array.prototype.join+0x2abf>
  40ed5d:	mov    %esi,%esi
  40ed5f:	lea    (%rcx,%rsi,1),%rax
  40ed63:	cmp    %r11,%rsi
  40ed66:	cmova  %rdx,%rax
  40ed6a:	sub    $0x14,%edi
  40ed6d:	sub    %rdi,%rax
  40ed70:	mov    (%rax),%eax
  40ed72:	test   %eax,%eax
  40ed74:	je     4112e1 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2ac1>
  40ed7a:	test   %eax,%eax
  40ed7c:	je     4112e3 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2ac3>
  40ed82:	mov    %eax,%esi
  40ed84:	lea    (%rcx,%rsi,1),%rax
  40ed88:	cmp    %r11,%rsi
  40ed8b:	cmova  %rdx,%rax
  40ed8f:	mov    0x18(%rax),%edx
  40ed92:	mov    0x10(%rax),%rcx
  40ed96:	mov    0x1c(%rax),%r8d
  40ed9a:	test   %edx,%edx
  40ed9c:	jne    40edaa <wasm[0]::function[131]::builtin::Array.prototype.join+0x58a>
  40eda2:	mov    %r10,%rdx
  40eda5:	jmp    40ee3b <wasm[0]::function[131]::builtin::Array.prototype.join+0x61b>
  40edaa:	mov    0x58(%rsp),%eax
  40edae:	test   %eax,%eax
  40edb0:	je     4112e5 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2ac5>
  40edb6:	mov    0x50(%rsp),%r9d
  40edbb:	mov    %eax,(%rsp)
  40edbe:	mov    0xb8(%rsp),%rsi
  40edc6:	mov    0xb8(%rsp),%rdi
  40edce:	call   2aee200 <wasm[0]::function[1061]::helper::value_to_string>
  40edd3:	sub    $0x10,%rsp
  40edd7:	cmp    $0x1,%esi
  40edda:	je     410b09 <wasm[0]::function[131]::builtin::Array.prototype.join+0x22e9>
  40ede0:	xor    %eax,%eax
  40ede2:	test   %edx,%edx
  40ede4:	je     40ee33 <wasm[0]::function[131]::builtin::Array.prototype.join+0x613>
  40edea:	xor    %eax,%eax
  40edec:	test   $0x1,%edx
  40edf2:	jne    40ee33 <wasm[0]::function[131]::builtin::Array.prototype.join+0x613>
  40edf8:	mov    0x138(%rsp),%r9
  40ee00:	mov    0x28(%r9),%rax
  40ee04:	mov    0x20(%r9),%rcx
  40ee08:	mov    %edx,%esi
  40ee0a:	lea    0x4(%rcx,%rsi,1),%rcx
  40ee0f:	xor    %rdi,%rdi
  40ee12:	cmp    %rax,%rsi
  40ee15:	cmova  %rdi,%rcx
  40ee19:	mov    (%rcx),%eax
  40ee1b:	mov    0xb8(%rsp),%rdi
  40ee23:	mov    0x28(%rdi),%rcx
  40ee27:	cmp    0x234(%rcx),%eax
  40ee2d:	sete   %al
  40ee30:	movzbl %al,%eax
  40ee33:	test   %eax,%eax
  40ee35:	je     4112e7 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2ac7>
  40ee3b:	mov    %edx,0xb0(%rsp)
  40ee42:	xor    %eax,%eax
  40ee44:	mov    %rax,%rbx
  40ee47:	test   %edx,%edx
  40ee49:	je     4112e9 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2ac9>
  40ee4f:	mov    0x40(%rsp),%r8d
  40ee54:	mov    %edx,(%rsp)
  40ee57:	mov    0x130(%rsp),%rcx
  40ee5f:	mov    0x128(%rsp),%rdx
  40ee67:	mov    0xb8(%rsp),%rsi
  40ee6f:	mov    0xb8(%rsp),%rdi
  40ee77:	mov    %r13,%r9
  40ee7a:	call   29d6e40 <wasm[0]::function[1009]::helper::array_packed_join>
  40ee7f:	sub    $0x10,%rsp
  40ee83:	mov    %r13,0xd0(%rsp)
  40ee8b:	mov    0x80(%rsp),%edx
  40ee92:	xor    %rcx,%rcx
  40ee95:	test   %eax,%eax
  40ee97:	je     40eeb3 <wasm[0]::function[131]::builtin::Array.prototype.join+0x693>
  40ee9d:	test   %eax,%eax
  40ee9f:	je     4112eb <wasm[0]::function[131]::builtin::Array.prototype.join+0x2acb>
  40eea5:	mov    $0x4,%ecx
  40eeaa:	mov    %rcx,%rbx
  40eead:	xor    %rcx,%rcx
  40eeb0:	mov    %rax,%rdx
  40eeb3:	test   %eax,%eax
  40eeb5:	je     40eec3 <wasm[0]::function[131]::builtin::Array.prototype.join+0x6a3>
  40eebb:	mov    %rbx,%rax
  40eebe:	jmp    410ace <wasm[0]::function[131]::builtin::Array.prototype.join+0x22ae>
  40eec3:	mov    0xb8(%rsp),%rdi
  40eecb:	mov    0x20(%rdi),%r14
  40eecf:	mov    (%r14),%eax
  40eed2:	mov    %eax,%ecx
  40eed4:	mov    $0x20,%r13d
  40eeda:	lea    0x20(%rcx),%rdx
  40eede:	mov    0x4(%r14),%esi
  40eee2:	cmp    %rsi,%rdx
  40eee5:	ja     410c58 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2438>
  40eeeb:	lea    0x20(%rax),%edx
  40eeee:	mov    %edx,(%r14)
  40eef1:	mov    0x138(%rsp),%r9
  40eef9:	mov    %r14,0x120(%rsp)
  40ef01:	mov    0x20(%r9),%rsi
  40ef05:	lea    (%rsi,%rcx,1),%rdx
  40ef09:	movl   $0xa8000006,(%rsi,%rcx,1)
  40ef10:	mov    0xb8(%rsp),%rdi
  40ef18:	mov    0x28(%rdi),%rdi
  40ef1c:	mov    0x238(%rdi),%edi
  40ef22:	mov    %edi,0x4(%rsi,%rcx,1)
  40ef26:	mov    %r13d,0x8(%rsi,%rcx,1)
  40ef2b:	mov    %r13,0x118(%rsp)
  40ef33:	mov    %eax,0x80(%rsp)
  40ef3a:	movl   $0x0,0x10(%rdx)
  40ef41:	test   %eax,%eax
  40ef43:	je     4112ed <wasm[0]::function[131]::builtin::Array.prototype.join+0x2acd>
  40ef49:	mov    0x138(%rsp),%r9
  40ef51:	mov    0x28(%r9),%rsi
  40ef55:	mov    0x20(%r9),%rdi
  40ef59:	mov    %eax,%r8d
  40ef5c:	lea    0x10(%rdi,%r8,1),%rax
  40ef61:	xor    %rcx,%rcx
  40ef64:	cmp    %rsi,%r8
  40ef67:	cmova  %rcx,%rax
  40ef6b:	mov    %rcx,%r12
  40ef6e:	mov    (%rax),%r9d
  40ef71:	lea    0x14(%rdi,%r8,1),%rax
  40ef76:	mov    %rax,%r8
  40ef79:	add    $0x0,%r8
  40ef7d:	mov    %rax,%r13
  40ef80:	jb     4112ef <wasm[0]::function[131]::builtin::Array.prototype.join+0x2acf>
  40ef86:	add    %rdi,%rsi
  40ef89:	cmp    %rsi,%r8
  40ef8c:	ja     4112f1 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2ad1>
  40ef92:	mov    0xb0(%rsp),%esi
  40ef99:	mov    0x40(%rsp),%edx
  40ef9d:	mov    0x50(%rsp),%ecx
  40efa1:	mov    0x58(%rsp),%eax
  40efa5:	mov    %esi,0xb0(%rsp)
  40efac:	mov    %edx,0x50(%rsp)
  40efb0:	mov    %ecx,0x58(%rsp)
  40efb4:	mov    %eax,0x68(%rsp)
  40efb8:	mov    0x140(%rsp),%rax
  40efc0:	mov    (%rax),%rcx
  40efc3:	mov    0xe0(%rsp),%rax
  40efcb:	cmp    %rax,%rcx
  40efce:	jae    410ca2 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2482>
  40efd4:	mov    %rax,0xe0(%rsp)
  40efdc:	jmp    40efe9 <wasm[0]::function[131]::builtin::Array.prototype.join+0x7c9>
  40efe1:	mov    %rax,0xe0(%rsp)
  40efe9:	xor    %ebx,%ebx
  40efeb:	mov    %r12,%rcx
  40efee:	mov    %r13,%rsi
  40eff1:	mov    %rbx,%rdx
  40eff4:	mov    0xb8(%rsp),%rdi
  40effc:	call   3018b23 <wasmtime_builtin_memory_fill>
  40f001:	mov    %rbx,0xc0(%rsp)
  40f009:	mov    0xb0(%rsp),%r8d
  40f011:	mov    0x80(%rsp),%edi
  40f018:	mov    0x50(%rsp),%edx
  40f01c:	mov    0x58(%rsp),%r9d
  40f021:	mov    0x68(%rsp),%esi
  40f025:	xor    %r14,%r14
  40f028:	mov    %r14,0xc8(%rsp)
  40f030:	mov    $0x10,%eax
  40f035:	mov    %rax,0x110(%rsp)
  40f03d:	mov    $0xa8000006,%eax
  40f042:	mov    %rax,0x108(%rsp)
  40f04a:	mov    0xb8(%rsp),%rax
  40f052:	mov    0x28(%rax),%r13
  40f056:	mov    0x238(%r13),%eax
  40f05d:	mov    %rax,0xf8(%rsp)
  40f065:	mov    %r13,0x100(%rsp)
  40f06d:	mov    0xc0(%rsp),%rax
  40f075:	mov    %rax,0xd8(%rsp)
  40f07d:	mov    %r8d,0x68(%rsp)
  40f082:	mov    %edi,0x58(%rsp)
  40f086:	mov    %edx,0x50(%rsp)
  40f08a:	mov    %r9d,0x80(%rsp)
  40f092:	mov    %esi,0xb0(%rsp)
  40f099:	mov    0x140(%rsp),%rcx
  40f0a1:	mov    (%rcx),%rax
  40f0a4:	mov    0xe0(%rsp),%rcx
  40f0ac:	cmp    %rcx,%rax
  40f0af:	jae    410cd1 <wasm[0]::function[131]::builtin::Array.prototype.join+0x24b1>
  40f0b5:	mov    0xc8(%rsp),%rcx
  40f0bd:	mov    0xd0(%rsp),%r11
  40f0c5:	jmp    40f0da <wasm[0]::function[131]::builtin::Array.prototype.join+0x8ba>
  40f0ca:	mov    0xc8(%rsp),%rcx
  40f0d2:	mov    0xd0(%rsp),%r11
  40f0da:	cmp    %r11,%rcx
  40f0dd:	mov    %r11,0xd0(%rsp)
  40f0e5:	jae    4105d7 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1db7>
  40f0eb:	mov    0x50(%rsp),%r8d
  40f0f0:	mov    0x80(%rsp),%eax
  40f0f7:	mov    0xb0(%rsp),%ecx
  40f0fe:	mov    0x58(%rsp),%esi
  40f102:	mov    0x68(%rsp),%edi
  40f106:	mov    0xc8(%rsp),%rdx
  40f10e:	mov    0xc8(%rsp),%r9
  40f116:	test   %r9,%rdx
  40f119:	je     40fa8d <wasm[0]::function[131]::builtin::Array.prototype.join+0x126d>
  40f11f:	mov    0x68(%rsp),%edx
  40f123:	test   %edx,%edx
  40f125:	je     4112f3 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2ad3>
  40f12b:	test   %edx,%edx
  40f12d:	je     4112f5 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2ad5>
  40f133:	mov    0x138(%rsp),%r9
  40f13b:	mov    0x28(%r9),%rax
  40f13f:	mov    0x20(%r9),%rcx
  40f143:	mov    %edx,%edi
  40f145:	lea    (%rcx,%rdi,1),%rsi
  40f149:	xor    %rdx,%rdx
  40f14c:	cmp    %rax,%rdi
  40f14f:	cmova  %rdx,%rsi
  40f153:	mov    0x10(%rsi),%esi
  40f156:	mov    %esi,0x88(%rsp)
  40f15d:	test   %esi,%esi
  40f15f:	je     4112f7 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2ad7>
  40f165:	test   %esi,%esi
  40f167:	je     4112f9 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2ad9>
  40f16d:	mov    %esi,%esi
  40f16f:	lea    0x10(%rcx,%rsi,1),%rcx
  40f174:	cmp    %rax,%rsi
  40f177:	cmova  %rdx,%rcx
  40f17b:	mov    (%rcx),%eax
  40f17d:	mov    0xc0(%rsp),%r11
  40f185:	lea    (%r11,%rax,1),%r9d
  40f189:	mov    %rax,0xe8(%rsp)
  40f191:	cmp    %r11d,%r9d
  40f194:	jb     4112fb <wasm[0]::function[131]::builtin::Array.prototype.join+0x2adb>
  40f19a:	mov    0x58(%rsp),%eax
  40f19e:	mov    0x88(%rsp),%r8d
  40f1a6:	mov    0x50(%rsp),%ecx
  40f1aa:	mov    0x80(%rsp),%edx
  40f1b1:	mov    0xb0(%rsp),%esi
  40f1b8:	mov    0x68(%rsp),%edi
  40f1bc:	mov    0xd8(%rsp),%r10
  40f1c4:	cmp    %r10d,%r9d
  40f1c7:	ja     40f1e2 <wasm[0]::function[131]::builtin::Array.prototype.join+0x9c2>
  40f1cd:	mov    %r10,0xd8(%rsp)
  40f1d5:	mov    %r9,0xf0(%rsp)
  40f1dd:	jmp    40f794 <wasm[0]::function[131]::builtin::Array.prototype.join+0xf74>
  40f1e2:	lea    (%r10,%r10,1),%eax
  40f1e6:	cmp    %r10d,%eax
  40f1e9:	jb     40f1f7 <wasm[0]::function[131]::builtin::Array.prototype.join+0x9d7>
  40f1ef:	mov    %rax,%r10
  40f1f2:	jmp    40f1fa <wasm[0]::function[131]::builtin::Array.prototype.join+0x9da>
  40f1f7:	mov    %r9,%r10
  40f1fa:	cmp    $0x10,%r10d
  40f1fe:	jae    40f20c <wasm[0]::function[131]::builtin::Array.prototype.join+0x9ec>
  40f204:	mov    0x110(%rsp),%r10
  40f20c:	cmp    %r9d,%r10d
  40f20f:	mov    %r9,0xf0(%rsp)
  40f217:	jae    40f225 <wasm[0]::function[131]::builtin::Array.prototype.join+0xa05>
  40f21d:	mov    0xf0(%rsp),%r10
  40f225:	mov    %r10d,%r14d
  40f228:	mov    %r14,%rcx
  40f22b:	shl    $1,%rcx
  40f22e:	mov    %rcx,%rsi
  40f231:	shr    $0x20,%rsi
  40f235:	mov    %rcx,%rbx
  40f238:	test   %rsi,%rsi
  40f23b:	jne    4112fd <wasm[0]::function[131]::builtin::Array.prototype.join+0x2add>
  40f241:	lea    (%r10,%r10,1),%ecx
  40f245:	mov    %r10,0xd8(%rsp)
  40f24d:	add    $0x14,%ecx
  40f250:	jb     4112ff <wasm[0]::function[131]::builtin::Array.prototype.join+0x2adf>
  40f256:	mov    0x120(%rsp),%rdx
  40f25e:	mov    (%rdx),%eax
  40f260:	mov    %eax,%edi
  40f262:	mov    %ecx,%r8d
  40f265:	lea    0xf(%r8),%rsi
  40f269:	and    $0xfffffffffffffff0,%rsi
  40f26d:	lea    (%rdi,%rsi,1),%r8
  40f271:	mov    0x4(%rdx),%r9d
  40f275:	cmp    %r9,%r8
  40f278:	ja     410d18 <wasm[0]::function[131]::builtin::Array.prototype.join+0x24f8>
  40f27e:	lea    0xf(%rcx),%r9d
  40f282:	and    $0xfffffff0,%r9d
  40f286:	lea    (%rax,%r9,1),%r10d
  40f28a:	mov    0x120(%rsp),%rcx
  40f292:	mov    %r10d,(%rcx)
  40f295:	mov    0x138(%rsp),%r9
  40f29d:	mov    0x20(%r9),%r11
  40f2a1:	lea    (%r11,%rdi,1),%rcx
  40f2a5:	movl   $0xa8000006,(%r11,%rdi,1)
  40f2ad:	mov    0xf8(%rsp),%rdx
  40f2b5:	mov    %edx,0x4(%r11,%rdi,1)
  40f2ba:	mov    %esi,0x8(%r11,%rdi,1)
  40f2bf:	mov    %eax,0x60(%rsp)
  40f2c3:	mov    0xd8(%rsp),%r12
  40f2cb:	mov    %r12d,0x10(%rcx)
  40f2cf:	test   %eax,%eax
  40f2d1:	je     411301 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2ae1>
  40f2d7:	mov    0x138(%rsp),%r9
  40f2df:	mov    0x28(%r9),%rcx
  40f2e3:	mov    0x20(%r9),%rdx
  40f2e7:	mov    %eax,%eax
  40f2e9:	lea    0x10(%rdx,%rax,1),%rsi
  40f2ee:	xor    %rdi,%rdi
  40f2f1:	cmp    %rcx,%rax
  40f2f4:	cmova  %rdi,%rsi
  40f2f8:	mov    (%rsi),%esi
  40f2fa:	cmp    %rsi,%r14
  40f2fd:	ja     411303 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2ae3>
  40f303:	lea    0x14(%rdx,%rax,1),%rsi
  40f308:	mov    %rbx,%r9
  40f30b:	mov    %rsi,%rax
  40f30e:	add    %r9,%rax
  40f311:	mov    %rsi,%r15
  40f314:	jb     411305 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2ae5>
  40f31a:	add    %rdx,%rcx
  40f31d:	cmp    %rcx,%rax
  40f320:	ja     411307 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2ae7>
  40f326:	mov    0x58(%rsp),%r8d
  40f32b:	mov    0x88(%rsp),%edi
  40f332:	mov    0x50(%rsp),%esi
  40f336:	mov    0x80(%rsp),%edx
  40f33d:	mov    0xb0(%rsp),%ecx
  40f344:	mov    0x68(%rsp),%eax
  40f348:	cmp    $0x8000000,%r9
  40f34f:	jbe    40f3f6 <wasm[0]::function[131]::builtin::Array.prototype.join+0xbd6>
  40f355:	mov    %r8d,0x70(%rsp)
  40f35a:	mov    %edi,0x68(%rsp)
  40f35e:	mov    %esi,0xb0(%rsp)
  40f365:	mov    %edx,0x80(%rsp)
  40f36c:	mov    %ecx,0x50(%rsp)
  40f370:	mov    %eax,0x88(%rsp)
  40f377:	mov    0x140(%rsp),%rcx
  40f37f:	mov    (%rcx),%rax
  40f382:	mov    0xe0(%rsp),%rcx
  40f38a:	cmp    %rcx,%rax
  40f38d:	jae    410d50 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2530>
  40f393:	xor    %edx,%edx
  40f395:	mov    $0x8000000,%ecx
  40f39a:	mov    %r15,%rsi
  40f39d:	mov    0xb8(%rsp),%rdi
  40f3a5:	call   3018b23 <wasmtime_builtin_memory_fill>
  40f3aa:	mov    0x70(%rsp),%r8d
  40f3af:	mov    0x68(%rsp),%edi
  40f3b3:	mov    0xb0(%rsp),%esi
  40f3ba:	mov    0x80(%rsp),%edx
  40f3c1:	mov    0x50(%rsp),%ecx
  40f3c5:	mov    0x88(%rsp),%eax
  40f3cc:	mov    %rbx,%r9
  40f3cf:	sub    $0x8000000,%r9
  40f3d6:	mov    %r9,%rbx
  40f3d9:	mov    %r15,%r9
  40f3dc:	add    $0x8000000,%r9
  40f3e3:	mov    %r9,%r15
  40f3e6:	mov    %rbx,%r9
  40f3e9:	cmp    $0x8000000,%r9
  40f3f0:	ja     40f355 <wasm[0]::function[131]::builtin::Array.prototype.join+0xb35>
  40f3f6:	mov    %r8d,0x88(%rsp)
  40f3fe:	mov    %edi,0x50(%rsp)
  40f402:	mov    %esi,0x80(%rsp)
  40f409:	mov    %edx,0xb0(%rsp)
  40f410:	mov    %ecx,0x68(%rsp)
  40f414:	mov    %eax,0x70(%rsp)
  40f418:	mov    0x140(%rsp),%rcx
  40f420:	mov    (%rcx),%rax
  40f423:	mov    0xe0(%rsp),%rcx
  40f42b:	cmp    %rcx,%rax
  40f42e:	jae    410d87 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2567>
  40f434:	xor    %edx,%edx
  40f436:	mov    %rbx,%rcx
  40f439:	mov    %r15,%rsi
  40f43c:	mov    0xb8(%rsp),%rdi
  40f444:	call   3018b23 <wasmtime_builtin_memory_fill>
  40f449:	mov    0x60(%rsp),%ecx
  40f44d:	test   %ecx,%ecx
  40f44f:	je     411309 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2ae9>
  40f455:	mov    0x88(%rsp),%eax
  40f45c:	test   %eax,%eax
  40f45e:	je     41130b <wasm[0]::function[131]::builtin::Array.prototype.join+0x2aeb>
  40f464:	test   %ecx,%ecx
  40f466:	je     41130d <wasm[0]::function[131]::builtin::Array.prototype.join+0x2aed>
  40f46c:	mov    0x138(%rsp),%r9
  40f474:	mov    0x28(%r9),%rdi
  40f478:	mov    0x20(%r9),%rsi
  40f47c:	mov    %ecx,%r8d
  40f47f:	lea    (%rsi,%r8,1),%r9
  40f483:	lea    0x10(%rsi,%r8,1),%rdx
  40f488:	xor    %rcx,%rcx
  40f48b:	cmp    %rdi,%r8
  40f48e:	cmova  %rcx,%rdx
  40f492:	mov    0xc0(%rsp),%r12
  40f49a:	mov    %r12d,%r10d
  40f49d:	mov    (%rdx),%r11d
  40f4a0:	cmp    %r11,%r10
  40f4a3:	ja     41130f <wasm[0]::function[131]::builtin::Array.prototype.join+0x2aef>
  40f4a9:	test   %eax,%eax
  40f4ab:	je     411311 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2af1>
  40f4b1:	mov    %eax,%eax
  40f4b3:	lea    (%rsi,%rax,1),%r11
  40f4b7:	lea    0x10(%rsi,%rax,1),%rdx
  40f4bc:	cmp    %rdi,%rax
  40f4bf:	cmova  %rcx,%rdx
  40f4c3:	mov    (%rdx),%ecx
  40f4c5:	cmp    %rcx,%r10
  40f4c8:	ja     411313 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2af3>
  40f4ce:	lea    0x14(%rsi,%r8,1),%r12
  40f4d3:	mov    %r10,%r14
  40f4d6:	shl    $1,%r14
  40f4d9:	mov    %r12,%rdx
  40f4dc:	add    %r14,%rdx
  40f4df:	jb     411315 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2af5>
  40f4e5:	lea    (%rsi,%rdi,1),%rcx
  40f4e9:	cmp    %rcx,%rdx
  40f4ec:	ja     411317 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2af7>
  40f4f2:	lea    0x14(%rsi,%rax,1),%r13
  40f4f7:	mov    %r13,%rax
  40f4fa:	add    %r14,%rax
  40f4fd:	jb     411319 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2af9>
  40f503:	cmp    %rcx,%rax
  40f506:	ja     41131b <wasm[0]::function[131]::builtin::Array.prototype.join+0x2afb>
  40f50c:	cmp    %r12,%r13
  40f50f:	ja     40f62a <wasm[0]::function[131]::builtin::Array.prototype.join+0xe0a>
  40f515:	mov    0x60(%rsp),%eax
  40f519:	mov    0x50(%rsp),%ecx
  40f51d:	mov    0x80(%rsp),%edx
  40f524:	mov    0xb0(%rsp),%esi
  40f52b:	mov    0x68(%rsp),%edi
  40f52f:	mov    0x70(%rsp),%r8d
  40f534:	lea    0x14(%r9,%r10,2),%r12
  40f539:	lea    0x14(%r11,%r10,2),%r13
  40f53e:	cmp    $0x8000000,%r14
  40f545:	mov    %r14,%rbx
  40f548:	ja     40f559 <wasm[0]::function[131]::builtin::Array.prototype.join+0xd39>
  40f54e:	mov    %rbx,%r9
  40f551:	mov    %r12,%r10
  40f554:	jmp    40f613 <wasm[0]::function[131]::builtin::Array.prototype.join+0xdf3>
  40f559:	mov    %eax,0x78(%rsp)
  40f55d:	mov    %ecx,0xa8(%rsp)
  40f564:	mov    %edx,0xa0(%rsp)
  40f56b:	mov    %esi,0x98(%rsp)
  40f572:	mov    %edi,0x90(%rsp)
  40f579:	mov    %r8d,0x88(%rsp)
  40f581:	mov    0x140(%rsp),%rcx
  40f589:	mov    (%rcx),%rax
  40f58c:	mov    0xe0(%rsp),%rcx
  40f594:	cmp    %rcx,%rax
  40f597:	jae    410dbe <wasm[0]::function[131]::builtin::Array.prototype.join+0x259e>
  40f59d:	mov    $0x8000000,%ecx
  40f5a2:	mov    %r12,%rsi
  40f5a5:	sub    $0x8000000,%rsi
  40f5ac:	mov    %r13,%rdx
  40f5af:	mov    %rsi,%r12
  40f5b2:	sub    $0x8000000,%rdx
  40f5b9:	mov    %rdx,%r13
  40f5bc:	mov    0xb8(%rsp),%rdi
  40f5c4:	call   3018afa <wasmtime_builtin_memory_copy>
  40f5c9:	mov    0x78(%rsp),%eax
  40f5cd:	mov    0xa8(%rsp),%ecx
  40f5d4:	mov    0xa0(%rsp),%edx
  40f5db:	mov    0x98(%rsp),%esi
  40f5e2:	mov    0x90(%rsp),%edi
  40f5e9:	mov    0x88(%rsp),%r8d
  40f5f1:	mov    %rbx,%r9
  40f5f4:	sub    $0x8000000,%r9
  40f5fb:	cmp    $0x8000000,%r9
  40f602:	jbe    40f610 <wasm[0]::function[131]::builtin::Array.prototype.join+0xdf0>
  40f608:	mov    %r9,%rbx
  40f60b:	jmp    40f559 <wasm[0]::function[131]::builtin::Array.prototype.join+0xd39>
  40f610:	mov    %r12,%r10
  40f613:	sub    %r9,%r10
  40f616:	mov    %r10,%r12
  40f619:	mov    %r13,%r10
  40f61c:	sub    %r9,%r10
  40f61f:	mov    %r10,%r13
  40f622:	mov    %r9,%rbx
  40f625:	jmp    40f705 <wasm[0]::function[131]::builtin::Array.prototype.join+0xee5>
  40f62a:	mov    %r14,%r9
  40f62d:	mov    0x60(%rsp),%eax
  40f631:	mov    0x50(%rsp),%ecx
  40f635:	mov    0x80(%rsp),%edx
  40f63c:	mov    0xb0(%rsp),%esi
  40f643:	mov    0x68(%rsp),%edi
  40f647:	mov    0x70(%rsp),%r8d
  40f64c:	cmp    $0x8000000,%r9
  40f653:	mov    %r9,%rbx
  40f656:	jbe    40f705 <wasm[0]::function[131]::builtin::Array.prototype.join+0xee5>
  40f65c:	mov    %eax,0x70(%rsp)
  40f660:	mov    %ecx,0x68(%rsp)
  40f664:	mov    %edx,0xb0(%rsp)
  40f66b:	mov    %esi,0x80(%rsp)
  40f672:	mov    %edi,0x50(%rsp)
  40f676:	mov    %r8d,0x60(%rsp)
  40f67b:	mov    0x140(%rsp),%rcx
  40f683:	mov    (%rcx),%rax
  40f686:	mov    0xe0(%rsp),%rcx
  40f68e:	cmp    %rcx,%rax
  40f691:	jae    410df5 <wasm[0]::function[131]::builtin::Array.prototype.join+0x25d5>
  40f697:	mov    $0x8000000,%ecx
  40f69c:	mov    %r13,%rdx
  40f69f:	mov    %r12,%rsi
  40f6a2:	mov    0xb8(%rsp),%rdi
  40f6aa:	call   3018afa <wasmtime_builtin_memory_copy>
  40f6af:	mov    0x70(%rsp),%eax
  40f6b3:	mov    0x68(%rsp),%ecx
  40f6b7:	mov    0xb0(%rsp),%edx
  40f6be:	mov    0x80(%rsp),%esi
  40f6c5:	mov    0x50(%rsp),%edi
  40f6c9:	mov    0x60(%rsp),%r8d
  40f6ce:	mov    %rbx,%r9
  40f6d1:	sub    $0x8000000,%r9
  40f6d8:	mov    %r9,%rbx
  40f6db:	mov    %r12,%r9
  40f6de:	add    $0x8000000,%r9
  40f6e5:	mov    %r9,%r12
  40f6e8:	mov    %r13,%r9
  40f6eb:	add    $0x8000000,%r9
  40f6f2:	mov    %r9,%r13
  40f6f5:	mov    %rbx,%r9
  40f6f8:	cmp    $0x8000000,%r9
  40f6ff:	ja     40f65c <wasm[0]::function[131]::builtin::Array.prototype.join+0xe3c>
  40f705:	mov    %eax,0x60(%rsp)
  40f709:	mov    %ecx,0x50(%rsp)
  40f70d:	mov    %edx,0x80(%rsp)
  40f714:	mov    %esi,0xb0(%rsp)
  40f71b:	mov    %edi,0x68(%rsp)
  40f71f:	mov    %r8d,0x70(%rsp)
  40f724:	mov    0x140(%rsp),%rcx
  40f72c:	mov    (%rcx),%r8
  40f72f:	mov    0xe0(%rsp),%rax
  40f737:	cmp    %rax,%r8
  40f73a:	jae    410e2c <wasm[0]::function[131]::builtin::Array.prototype.join+0x260c>
  40f740:	mov    %rbx,%rcx
  40f743:	mov    %r13,%rdx
  40f746:	mov    %r12,%rsi
  40f749:	jmp    40f757 <wasm[0]::function[131]::builtin::Array.prototype.join+0xf37>
  40f74e:	mov    %rbx,%rcx
  40f751:	mov    %r13,%rdx
  40f754:	mov    %r12,%rsi
  40f757:	mov    %rbx,%rcx
  40f75a:	mov    %r13,%rdx
  40f75d:	mov    %r12,%rsi
  40f760:	mov    0xb8(%rsp),%rdi
  40f768:	call   3018afa <wasmtime_builtin_memory_copy>
  40f76d:	mov    0x60(%rsp),%eax
  40f771:	test   %eax,%eax
  40f773:	je     41131d <wasm[0]::function[131]::builtin::Array.prototype.join+0x2afd>
  40f779:	mov    0x50(%rsp),%r8d
  40f77e:	mov    0x80(%rsp),%ecx
  40f785:	mov    0xb0(%rsp),%edx
  40f78c:	mov    0x68(%rsp),%esi
  40f790:	mov    0x70(%rsp),%edi
  40f794:	test   %eax,%eax
  40f796:	je     41131f <wasm[0]::function[131]::builtin::Array.prototype.join+0x2aff>
  40f79c:	test   %r8d,%r8d
  40f79f:	je     411321 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b01>
  40f7a5:	test   %eax,%eax
  40f7a7:	je     411323 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b03>
  40f7ad:	mov    0x138(%rsp),%r9
  40f7b5:	mov    0x28(%r9),%r11
  40f7b9:	mov    0x20(%r9),%r9
  40f7bd:	mov    %eax,%r10d
  40f7c0:	lea    (%r9,%r10,1),%r14
  40f7c4:	lea    0x10(%r9,%r10,1),%r12
  40f7c9:	xor    %r15,%r15
  40f7cc:	cmp    %r11,%r10
  40f7cf:	cmova  %r15,%r12
  40f7d3:	mov    0xc0(%rsp),%r10
  40f7db:	mov    %r10d,%r13d
  40f7de:	mov    0xe8(%rsp),%r10
  40f7e6:	mov    %r10d,%r10d
  40f7e9:	lea    0x0(%r13,%r10,1),%rbx
  40f7ee:	mov    (%r12),%r12d
  40f7f2:	cmp    %r12,%rbx
  40f7f5:	ja     411325 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b05>
  40f7fb:	test   %r8d,%r8d
  40f7fe:	je     411327 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b07>
  40f804:	mov    %r8d,%r12d
  40f807:	lea    (%r9,%r12,1),%r8
  40f80b:	lea    0x10(%r9,%r12,1),%rbx
  40f810:	cmp    %r11,%r12
  40f813:	cmova  %r15,%rbx
  40f817:	mov    (%rbx),%ebx
  40f819:	cmp    %rbx,%r10
  40f81c:	ja     411329 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b09>
  40f822:	lea    0x14(%r14,%r13,2),%r14
  40f827:	mov    %r10,%r13
  40f82a:	shl    $1,%r13
  40f82d:	mov    %r14,%rbx
  40f830:	add    %r13,%rbx
  40f833:	jb     41132b <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b0b>
  40f839:	add    %r9,%r11
  40f83c:	cmp    %r11,%rbx
  40f83f:	ja     41132d <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b0d>
  40f845:	lea    0x14(%r9,%r12,1),%r9
  40f84a:	mov    %r9,%rbx
  40f84d:	add    %r13,%rbx
  40f850:	jb     41132f <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b0f>
  40f856:	cmp    %r11,%rbx
  40f859:	ja     411331 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b11>
  40f85f:	cmp    %r14,%r9
  40f862:	ja     40f947 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1127>
  40f868:	lea    (%r14,%r10,2),%r14
  40f86c:	mov    %r14,%rbx
  40f86f:	lea    0x14(%r8,%r10,2),%r9
  40f874:	mov    %r9,%r14
  40f877:	cmp    $0x8000000,%r13
  40f87e:	mov    %r13,%r12
  40f881:	ja     40f892 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1072>
  40f887:	mov    %r12,%r8
  40f88a:	mov    %rbx,%r9
  40f88d:	jmp    40f930 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1110>
  40f892:	mov    %ecx,0x68(%rsp)
  40f896:	mov    %edx,0xb0(%rsp)
  40f89d:	mov    %esi,0x80(%rsp)
  40f8a4:	mov    %eax,0x50(%rsp)
  40f8a8:	mov    %edi,0x60(%rsp)
  40f8ac:	mov    0x140(%rsp),%rcx
  40f8b4:	mov    (%rcx),%rax
  40f8b7:	mov    0xe0(%rsp),%rcx
  40f8bf:	cmp    %rcx,%rax
  40f8c2:	jae    410e6c <wasm[0]::function[131]::builtin::Array.prototype.join+0x264c>
  40f8c8:	mov    $0x8000000,%ecx
  40f8cd:	mov    %rbx,%rsi
  40f8d0:	sub    $0x8000000,%rsi
  40f8d7:	mov    %r14,%rdx
  40f8da:	mov    %rsi,%rbx
  40f8dd:	sub    $0x8000000,%rdx
  40f8e4:	mov    %rdx,%r14
  40f8e7:	mov    0xb8(%rsp),%rdi
  40f8ef:	call   3018afa <wasmtime_builtin_memory_copy>
  40f8f4:	mov    0x68(%rsp),%ecx
  40f8f8:	mov    0xb0(%rsp),%edx
  40f8ff:	mov    0x80(%rsp),%esi
  40f906:	mov    0x50(%rsp),%eax
  40f90a:	mov    0x60(%rsp),%edi
  40f90e:	mov    %r12,%r8
  40f911:	sub    $0x8000000,%r8
  40f918:	cmp    $0x8000000,%r8
  40f91f:	jbe    40f92d <wasm[0]::function[131]::builtin::Array.prototype.join+0x110d>
  40f925:	mov    %r8,%r12
  40f928:	jmp    40f892 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1072>
  40f92d:	mov    %rbx,%r9
  40f930:	sub    %r8,%r9
  40f933:	mov    %r9,%rbx
  40f936:	mov    %r14,%r9
  40f939:	sub    %r8,%r9
  40f93c:	mov    %r9,%r14
  40f93f:	mov    %r8,%r12
  40f942:	jmp    40f9ff <wasm[0]::function[131]::builtin::Array.prototype.join+0x11df>
  40f947:	mov    %r13,%r8
  40f94a:	mov    %r14,%rbx
  40f94d:	mov    %r9,%r14
  40f950:	cmp    $0x8000000,%r8
  40f957:	mov    %r8,%r12
  40f95a:	jbe    40f9ff <wasm[0]::function[131]::builtin::Array.prototype.join+0x11df>
  40f960:	mov    %ecx,0x60(%rsp)
  40f964:	mov    %edx,0x50(%rsp)
  40f968:	mov    %esi,0x80(%rsp)
  40f96f:	mov    %eax,0xb0(%rsp)
  40f976:	mov    %edi,0x68(%rsp)
  40f97a:	mov    0x140(%rsp),%rcx
  40f982:	mov    (%rcx),%r9
  40f985:	mov    0xe0(%rsp),%rax
  40f98d:	cmp    %rax,%r9
  40f990:	jae    410ea3 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2683>
  40f996:	mov    $0x8000000,%ecx
  40f99b:	mov    %r14,%rdx
  40f99e:	mov    %rbx,%rsi
  40f9a1:	mov    0xb8(%rsp),%rdi
  40f9a9:	call   3018afa <wasmtime_builtin_memory_copy>
  40f9ae:	mov    0x60(%rsp),%ecx
  40f9b2:	mov    0x50(%rsp),%edx
  40f9b6:	mov    0x80(%rsp),%esi
  40f9bd:	mov    0xb0(%rsp),%eax
  40f9c4:	mov    0x68(%rsp),%edi
  40f9c8:	mov    %r12,%r8
  40f9cb:	sub    $0x8000000,%r8
  40f9d2:	mov    %r8,%r12
  40f9d5:	mov    %rbx,%r8
  40f9d8:	add    $0x8000000,%r8
  40f9df:	mov    %r8,%rbx
  40f9e2:	mov    %r14,%r8
  40f9e5:	add    $0x8000000,%r8
  40f9ec:	mov    %r8,%r14
  40f9ef:	mov    %r12,%r8
  40f9f2:	cmp    $0x8000000,%r8
  40f9f9:	ja     40f960 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1140>
  40f9ff:	mov    %ecx,0x68(%rsp)
  40fa03:	mov    %edx,0xb0(%rsp)
  40fa0a:	mov    %esi,0x80(%rsp)
  40fa11:	mov    %eax,0x50(%rsp)
  40fa15:	mov    %edi,0x60(%rsp)
  40fa19:	mov    0x140(%rsp),%rcx
  40fa21:	mov    (%rcx),%rax
  40fa24:	mov    0xe0(%rsp),%rcx
  40fa2c:	cmp    %rcx,%rax
  40fa2f:	jae    410eda <wasm[0]::function[131]::builtin::Array.prototype.join+0x26ba>
  40fa35:	mov    %r12,%rcx
  40fa38:	mov    %r14,%rdx
  40fa3b:	mov    %rbx,%rsi
  40fa3e:	jmp    40fa4c <wasm[0]::function[131]::builtin::Array.prototype.join+0x122c>
  40fa43:	mov    %r12,%rcx
  40fa46:	mov    %r14,%rdx
  40fa49:	mov    %rbx,%rsi
  40fa4c:	mov    %r12,%rcx
  40fa4f:	mov    %r14,%rdx
  40fa52:	mov    %rbx,%rsi
  40fa55:	mov    0xb8(%rsp),%rdi
  40fa5d:	call   3018afa <wasmtime_builtin_memory_copy>
  40fa62:	mov    0x68(%rsp),%r8d
  40fa67:	mov    0xb0(%rsp),%eax
  40fa6e:	mov    0x80(%rsp),%ecx
  40fa75:	mov    0x50(%rsp),%esi
  40fa79:	mov    0x60(%rsp),%edi
  40fa7d:	mov    0xf0(%rsp),%rdx
  40fa85:	mov    %rdx,0xc0(%rsp)
  40fa8d:	mov    %r8d,0x60(%rsp)
  40fa92:	mov    %eax,0x50(%rsp)
  40fa96:	mov    %ecx,0x80(%rsp)
  40fa9d:	mov    %esi,0xb0(%rsp)
  40faa4:	mov    %edi,0x68(%rsp)
  40faa8:	test   %ecx,%ecx
  40faaa:	je     411333 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b13>
  40fab0:	mov    %eax,(%rsp)
  40fab3:	mov    %ecx,0x8(%rsp)
  40fab7:	mov    0x130(%rsp),%rcx
  40fabf:	mov    0x128(%rsp),%rdx
  40fac7:	mov    0xb8(%rsp),%rsi
  40facf:	mov    0xb8(%rsp),%rdi
  40fad7:	mov    0xc8(%rsp),%r9
  40fadf:	call   2deb360 <wasm[0]::function[1089]::helper::indexed_element_read>
  40fae4:	sub    $0x10,%rsp
  40fae8:	mov    %rdx,%r11
  40faeb:	cmp    $0x1,%esi
  40faee:	je     41059e <wasm[0]::function[131]::builtin::Array.prototype.join+0x1d7e>
  40faf4:	mov    0x68(%rsp),%r8d
  40faf9:	mov    0xb0(%rsp),%edi
  40fb00:	mov    0x60(%rsp),%edx
  40fb04:	mov    0x50(%rsp),%r9d
  40fb09:	mov    0x80(%rsp),%esi
  40fb10:	test   %eax,%eax
  40fb12:	setne  %r10b
  40fb16:	cmp    $0x1,%eax
  40fb19:	mov    %rax,%r14
  40fb1c:	setne  %al
  40fb1f:	test   %r10b,%al
  40fb22:	jne    40fb35 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1315>
  40fb28:	mov    0xc8(%rsp),%rcx
  40fb30:	jmp    410554 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1d34>
  40fb35:	test   %esi,%esi
  40fb37:	je     411335 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b15>
  40fb3d:	mov    %esi,(%rsp)
  40fb40:	mov    %r14,%rdx
  40fb43:	mov    %r11,%r8
  40fb46:	mov    0xb8(%rsp),%rsi
  40fb4e:	mov    0xb8(%rsp),%rdi
  40fb56:	call   2aee200 <wasm[0]::function[1061]::helper::value_to_string>
  40fb5b:	sub    $0x10,%rsp
  40fb5f:	cmp    $0x1,%esi
  40fb62:	je     410568 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1d48>
  40fb68:	xor    %eax,%eax
  40fb6a:	test   %edx,%edx
  40fb6c:	je     40fbb7 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1397>
  40fb72:	xor    %eax,%eax
  40fb74:	test   $0x1,%edx
  40fb7a:	jne    40fbb7 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1397>
  40fb80:	mov    0x138(%rsp),%r9
  40fb88:	mov    0x28(%r9),%rax
  40fb8c:	mov    0x20(%r9),%rcx
  40fb90:	mov    %edx,%esi
  40fb92:	lea    0x4(%rcx,%rsi,1),%rcx
  40fb97:	xor    %rdi,%rdi
  40fb9a:	cmp    %rax,%rsi
  40fb9d:	cmova  %rdi,%rcx
  40fba1:	mov    (%rcx),%eax
  40fba3:	mov    0x100(%rsp),%rcx
  40fbab:	cmp    0x234(%rcx),%eax
  40fbb1:	sete   %al
  40fbb4:	movzbl %al,%eax
  40fbb7:	test   %eax,%eax
  40fbb9:	je     411337 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b17>
  40fbbf:	test   %edx,%edx
  40fbc1:	je     411339 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b19>
  40fbc7:	test   %edx,%edx
  40fbc9:	je     41133b <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b1b>
  40fbcf:	mov    0x138(%rsp),%r9
  40fbd7:	mov    0x28(%r9),%rax
  40fbdb:	mov    0x20(%r9),%rcx
  40fbdf:	mov    %edx,%edi
  40fbe1:	lea    (%rcx,%rdi,1),%rsi
  40fbe5:	xor    %rdx,%rdx
  40fbe8:	cmp    %rax,%rdi
  40fbeb:	cmova  %rdx,%rsi
  40fbef:	mov    0x10(%rsi),%esi
  40fbf2:	mov    %esi,0x70(%rsp)
  40fbf6:	test   %esi,%esi
  40fbf8:	je     41133d <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b1d>
  40fbfe:	test   %esi,%esi
  40fc00:	je     41133f <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b1f>
  40fc06:	mov    %esi,%edi
  40fc08:	lea    0x10(%rcx,%rdi,1),%rsi
  40fc0d:	cmp    %rax,%rdi
  40fc10:	cmova  %rdx,%rsi
  40fc14:	mov    (%rsi),%edi
  40fc16:	mov    0xc0(%rsp),%r12
  40fc1e:	lea    (%r12,%rdi,1),%r9d
  40fc22:	mov    %rdi,0xf0(%rsp)
  40fc2a:	cmp    %r12d,%r9d
  40fc2d:	jb     411341 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b21>
  40fc33:	mov    0xb0(%rsp),%eax
  40fc3a:	mov    0x70(%rsp),%r8d
  40fc3f:	mov    0x68(%rsp),%edx
  40fc43:	mov    0x60(%rsp),%ecx
  40fc47:	mov    0x50(%rsp),%esi
  40fc4b:	mov    0x80(%rsp),%edi
  40fc52:	mov    0xd8(%rsp),%r12
  40fc5a:	cmp    %r12d,%r9d
  40fc5d:	ja     40fc70 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1450>
  40fc63:	mov    %r9,0xe8(%rsp)
  40fc6b:	jmp    410276 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1a56>
  40fc70:	mov    0xd8(%rsp),%rax
  40fc78:	mov    0xd8(%rsp),%r12
  40fc80:	add    %r12d,%eax
  40fc83:	cmp    %r12d,%eax
  40fc86:	jb     40fc9c <wasm[0]::function[131]::builtin::Array.prototype.join+0x147c>
  40fc8c:	mov    %rax,%r12
  40fc8f:	mov    %rax,0xd8(%rsp)
  40fc97:	jmp    40fca7 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1487>
  40fc9c:	mov    %r9,%r12
  40fc9f:	mov    %r9,0xd8(%rsp)
  40fca7:	cmp    $0x10,%r12d
  40fcab:	jb     40fcbe <wasm[0]::function[131]::builtin::Array.prototype.join+0x149e>
  40fcb1:	mov    0xd8(%rsp),%r12
  40fcb9:	jmp    40fcd6 <wasm[0]::function[131]::builtin::Array.prototype.join+0x14b6>
  40fcbe:	mov    0x110(%rsp),%r12
  40fcc6:	mov    0x110(%rsp),%rax
  40fcce:	mov    %rax,0xd8(%rsp)
  40fcd6:	cmp    %r9d,%r12d
  40fcd9:	mov    %r9,0xe8(%rsp)
  40fce1:	jb     40fcf4 <wasm[0]::function[131]::builtin::Array.prototype.join+0x14d4>
  40fce7:	mov    0xd8(%rsp),%r12
  40fcef:	jmp    40fd0c <wasm[0]::function[131]::builtin::Array.prototype.join+0x14ec>
  40fcf4:	mov    0xe8(%rsp),%r12
  40fcfc:	mov    0xe8(%rsp),%rax
  40fd04:	mov    %rax,0xd8(%rsp)
  40fd0c:	mov    %r12d,%r14d
  40fd0f:	mov    %r14,%rcx
  40fd12:	shl    $1,%rcx
  40fd15:	mov    %rcx,%rax
  40fd18:	shr    $0x20,%rax
  40fd1c:	mov    %rcx,%rbx
  40fd1f:	test   %rax,%rax
  40fd22:	jne    411343 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b23>
  40fd28:	mov    0xd8(%rsp),%rax
  40fd30:	mov    0xd8(%rsp),%r12
  40fd38:	lea    (%r12,%rax,1),%ecx
  40fd3c:	add    $0x14,%ecx
  40fd3f:	jb     411345 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b25>
  40fd45:	mov    0x120(%rsp),%rax
  40fd4d:	mov    (%rax),%eax
  40fd4f:	mov    %eax,%esi
  40fd51:	mov    %ecx,%edx
  40fd53:	add    $0xf,%rdx
  40fd5a:	and    $0xfffffffffffffff0,%rdx
  40fd5e:	lea    (%rsi,%rdx,1),%rdi
  40fd62:	mov    0x120(%rsp),%r8
  40fd6a:	mov    0x4(%r8),%r8d
  40fd6e:	cmp    %r8,%rdi
  40fd71:	ja     410f1a <wasm[0]::function[131]::builtin::Array.prototype.join+0x26fa>
  40fd77:	add    $0xf,%ecx
  40fd7d:	and    $0xfffffff0,%ecx
  40fd80:	add    %eax,%ecx
  40fd82:	mov    0x120(%rsp),%rdi
  40fd8a:	mov    %ecx,(%rdi)
  40fd8c:	mov    0x138(%rsp),%r9
  40fd94:	mov    0x20(%r9),%rdi
  40fd98:	lea    (%rdi,%rsi,1),%rcx
  40fd9c:	movl   $0xa8000006,(%rdi,%rsi,1)
  40fda3:	mov    0xf8(%rsp),%r8
  40fdab:	mov    %r8d,0x4(%rdi,%rsi,1)
  40fdb0:	mov    %edx,0x8(%rdi,%rsi,1)
  40fdb4:	mov    %eax,0x78(%rsp)
  40fdb8:	mov    0xd8(%rsp),%r12
  40fdc0:	mov    %r12d,0x10(%rcx)
  40fdc4:	test   %eax,%eax
  40fdc6:	je     411347 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b27>
  40fdcc:	mov    0x138(%rsp),%r9
  40fdd4:	mov    0x28(%r9),%rcx
  40fdd8:	mov    0x20(%r9),%rdx
  40fddc:	mov    %eax,%eax
  40fdde:	lea    0x10(%rdx,%rax,1),%rsi
  40fde3:	xor    %rdi,%rdi
  40fde6:	cmp    %rcx,%rax
  40fde9:	cmova  %rdi,%rsi
  40fded:	mov    (%rsi),%esi
  40fdef:	cmp    %rsi,%r14
  40fdf2:	ja     411349 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b29>
  40fdf8:	lea    0x14(%rdx,%rax,1),%rsi
  40fdfd:	mov    %rbx,%r9
  40fe00:	mov    %rsi,%rax
  40fe03:	add    %r9,%rax
  40fe06:	mov    %rsi,%r13
  40fe09:	jb     41134b <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b2b>
  40fe0f:	add    %rdx,%rcx
  40fe12:	cmp    %rcx,%rax
  40fe15:	ja     41134d <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b2d>
  40fe1b:	mov    0xb0(%rsp),%r8d
  40fe23:	mov    0x70(%rsp),%edi
  40fe27:	mov    0x68(%rsp),%esi
  40fe2b:	mov    0x60(%rsp),%edx
  40fe2f:	mov    0x50(%rsp),%ecx
  40fe33:	mov    0x80(%rsp),%eax
  40fe3a:	cmp    $0x8000000,%r9
  40fe41:	jbe    40fee2 <wasm[0]::function[131]::builtin::Array.prototype.join+0x16c2>
  40fe47:	mov    %r8d,0x80(%rsp)
  40fe4f:	mov    %edi,0x50(%rsp)
  40fe53:	mov    %esi,0x60(%rsp)
  40fe57:	mov    %edx,0x68(%rsp)
  40fe5b:	mov    %ecx,0x70(%rsp)
  40fe5f:	mov    %eax,0xb0(%rsp)
  40fe66:	mov    0x140(%rsp),%rcx
  40fe6e:	mov    (%rcx),%rax
  40fe71:	mov    0xe0(%rsp),%rcx
  40fe79:	cmp    %rcx,%rax
  40fe7c:	jae    410f52 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2732>
  40fe82:	xor    %edx,%edx
  40fe84:	mov    $0x8000000,%ecx
  40fe89:	mov    %r13,%rsi
  40fe8c:	mov    0xb8(%rsp),%rdi
  40fe94:	call   3018b23 <wasmtime_builtin_memory_fill>
  40fe99:	mov    0x80(%rsp),%r8d
  40fea1:	mov    0x50(%rsp),%edi
  40fea5:	mov    0x60(%rsp),%esi
  40fea9:	mov    0x68(%rsp),%edx
  40fead:	mov    0x70(%rsp),%ecx
  40feb1:	mov    0xb0(%rsp),%eax
  40feb8:	mov    %rbx,%r9
  40febb:	sub    $0x8000000,%r9
  40fec2:	mov    %r9,%rbx
  40fec5:	mov    %r13,%r9
  40fec8:	add    $0x8000000,%r9
  40fecf:	mov    %r9,%r13
  40fed2:	mov    %rbx,%r9
  40fed5:	cmp    $0x8000000,%r9
  40fedc:	ja     40fe47 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1627>
  40fee2:	mov    %r8d,0xb0(%rsp)
  40feea:	mov    %edi,0x70(%rsp)
  40feee:	mov    %esi,0x68(%rsp)
  40fef2:	mov    %edx,0x60(%rsp)
  40fef6:	mov    %ecx,0x50(%rsp)
  40fefa:	mov    %eax,0x80(%rsp)
  40ff01:	mov    0x140(%rsp),%rcx
  40ff09:	mov    (%rcx),%r11
  40ff0c:	mov    0xe0(%rsp),%rax
  40ff14:	cmp    %rax,%r11
  40ff17:	jae    410f89 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2769>
  40ff1d:	xor    %edx,%edx
  40ff1f:	mov    %rbx,%rcx
  40ff22:	mov    %r13,%rsi
  40ff25:	mov    0xb8(%rsp),%rdi
  40ff2d:	call   3018b23 <wasmtime_builtin_memory_fill>
  40ff32:	mov    0x78(%rsp),%edx
  40ff36:	test   %edx,%edx
  40ff38:	je     41134f <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b2f>
  40ff3e:	mov    0xb0(%rsp),%esi
  40ff45:	test   %esi,%esi
  40ff47:	je     411351 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b31>
  40ff4d:	test   %edx,%edx
  40ff4f:	je     411353 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b33>
  40ff55:	mov    0x138(%rsp),%r9
  40ff5d:	mov    0x28(%r9),%rcx
  40ff61:	mov    0x20(%r9),%rax
  40ff65:	mov    %edx,%edx
  40ff67:	lea    (%rax,%rdx,1),%r9
  40ff6b:	lea    0x10(%rax,%rdx,1),%r8
  40ff70:	xor    %rdi,%rdi
  40ff73:	cmp    %rcx,%rdx
  40ff76:	cmova  %rdi,%r8
  40ff7a:	mov    0xc0(%rsp),%r12
  40ff82:	mov    %r12d,%r10d
  40ff85:	mov    (%r8),%r8d
  40ff88:	cmp    %r8,%r10
  40ff8b:	ja     411355 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b35>
  40ff91:	test   %esi,%esi
  40ff93:	je     411357 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b37>
  40ff99:	mov    %esi,%esi
  40ff9b:	lea    (%rax,%rsi,1),%r11
  40ff9f:	lea    0x10(%rax,%rsi,1),%r8
  40ffa4:	cmp    %rcx,%rsi
  40ffa7:	cmova  %rdi,%r8
  40ffab:	mov    (%r8),%edi
  40ffae:	cmp    %rdi,%r10
  40ffb1:	ja     411359 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b39>
  40ffb7:	lea    0x14(%rax,%rdx,1),%r12
  40ffbc:	mov    %r10,%r14
  40ffbf:	shl    $1,%r14
  40ffc2:	mov    %r12,%rdx
  40ffc5:	add    %r14,%rdx
  40ffc8:	jb     41135b <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b3b>
  40ffce:	add    %rax,%rcx
  40ffd1:	cmp    %rcx,%rdx
  40ffd4:	ja     41135d <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b3d>
  40ffda:	lea    0x14(%rax,%rsi,1),%r13
  40ffdf:	mov    %r13,%rax
  40ffe2:	add    %r14,%rax
  40ffe5:	jb     41135f <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b3f>
  40ffeb:	cmp    %rcx,%rax
  40ffee:	ja     411361 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b41>
  40fff4:	cmp    %r12,%r13
  40fff7:	ja     410118 <wasm[0]::function[131]::builtin::Array.prototype.join+0x18f8>
  40fffd:	mov    0x78(%rsp),%eax
  410001:	mov    0x70(%rsp),%ecx
  410005:	mov    0x68(%rsp),%edx
  410009:	mov    0x60(%rsp),%esi
  41000d:	mov    0x50(%rsp),%edi
  410011:	mov    0x80(%rsp),%r8d
  410019:	lea    0x14(%r9,%r10,2),%r12
  41001e:	mov    %r12,%rbx
  410021:	lea    0x14(%r11,%r10,2),%r13
  410026:	mov    %r13,%r12
  410029:	cmp    $0x8000000,%r14
  410030:	ja     410041 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1821>
  410036:	mov    %r14,%r9
  410039:	mov    %rbx,%r10
  41003c:	jmp    410101 <wasm[0]::function[131]::builtin::Array.prototype.join+0x18e1>
  410041:	mov    %eax,0x88(%rsp)
  410048:	mov    %ecx,0x90(%rsp)
  41004f:	mov    %edx,0x98(%rsp)
  410056:	mov    %esi,0xa0(%rsp)
  41005d:	mov    %edi,0xa8(%rsp)
  410064:	mov    %r8d,0xb0(%rsp)
  41006c:	mov    0x140(%rsp),%rcx
  410074:	mov    (%rcx),%rax
  410077:	mov    0xe0(%rsp),%rcx
  41007f:	cmp    %rcx,%rax
  410082:	jae    410fc0 <wasm[0]::function[131]::builtin::Array.prototype.join+0x27a0>
  410088:	mov    $0x8000000,%ecx
  41008d:	mov    %rbx,%rsi
  410090:	sub    $0x8000000,%rsi
  410097:	mov    %r12,%rdx
  41009a:	mov    %rsi,%rbx
  41009d:	sub    $0x8000000,%rdx
  4100a4:	mov    %rdx,%r12
  4100a7:	mov    0xb8(%rsp),%rdi
  4100af:	call   3018afa <wasmtime_builtin_memory_copy>
  4100b4:	mov    0x88(%rsp),%eax
  4100bb:	mov    0x90(%rsp),%ecx
  4100c2:	mov    0x98(%rsp),%edx
  4100c9:	mov    0xa0(%rsp),%esi
  4100d0:	mov    0xa8(%rsp),%edi
  4100d7:	mov    0xb0(%rsp),%r8d
  4100df:	mov    %r14,%r9
  4100e2:	sub    $0x8000000,%r9
  4100e9:	cmp    $0x8000000,%r9
  4100f0:	jbe    4100fe <wasm[0]::function[131]::builtin::Array.prototype.join+0x18de>
  4100f6:	mov    %r9,%r14
  4100f9:	jmp    410041 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1821>
  4100fe:	mov    %rbx,%r10
  410101:	sub    %r9,%r10
  410104:	mov    %r10,%rbx
  410107:	mov    %r12,%r10
  41010a:	sub    %r9,%r10
  41010d:	mov    %r10,%r12
  410110:	mov    %r9,%r14
  410113:	jmp    4101ed <wasm[0]::function[131]::builtin::Array.prototype.join+0x19cd>
  410118:	mov    %r14,%r9
  41011b:	mov    %r12,%rbx
  41011e:	mov    %r13,%r12
  410121:	mov    0x78(%rsp),%eax
  410125:	mov    0x70(%rsp),%ecx
  410129:	mov    0x68(%rsp),%edx
  41012d:	mov    0x60(%rsp),%esi
  410131:	mov    0x50(%rsp),%edi
  410135:	mov    0x80(%rsp),%r8d
  41013d:	cmp    $0x8000000,%r9
  410144:	jbe    4101ed <wasm[0]::function[131]::builtin::Array.prototype.join+0x19cd>
  41014a:	mov    %eax,0x80(%rsp)
  410151:	mov    %ecx,0x50(%rsp)
  410155:	mov    %edx,0x60(%rsp)
  410159:	mov    %esi,0x68(%rsp)
  41015d:	mov    %edi,0x70(%rsp)
  410161:	mov    %r8d,0x78(%rsp)
  410166:	mov    0x140(%rsp),%rcx
  41016e:	mov    (%rcx),%r11
  410171:	mov    0xe0(%rsp),%rax
  410179:	cmp    %rax,%r11
  41017c:	jae    410ff7 <wasm[0]::function[131]::builtin::Array.prototype.join+0x27d7>
  410182:	mov    $0x8000000,%ecx
  410187:	mov    %r12,%rdx
  41018a:	mov    %rbx,%rsi
  41018d:	mov    0xb8(%rsp),%rdi
  410195:	call   3018afa <wasmtime_builtin_memory_copy>
  41019a:	mov    0x80(%rsp),%eax
  4101a1:	mov    0x50(%rsp),%ecx
  4101a5:	mov    0x60(%rsp),%edx
  4101a9:	mov    0x68(%rsp),%esi
  4101ad:	mov    0x70(%rsp),%edi
  4101b1:	mov    0x78(%rsp),%r8d
  4101b6:	mov    %r14,%r9
  4101b9:	sub    $0x8000000,%r9
  4101c0:	mov    %r9,%r14
  4101c3:	mov    %rbx,%r9
  4101c6:	add    $0x8000000,%r9
  4101cd:	mov    %r9,%rbx
  4101d0:	mov    %r12,%r9
  4101d3:	add    $0x8000000,%r9
  4101da:	mov    %r9,%r12
  4101dd:	mov    %r14,%r9
  4101e0:	cmp    $0x8000000,%r9
  4101e7:	ja     41014a <wasm[0]::function[131]::builtin::Array.prototype.join+0x192a>
  4101ed:	mov    %eax,0x78(%rsp)
  4101f1:	mov    %ecx,0x70(%rsp)
  4101f5:	mov    %edx,0x68(%rsp)
  4101f9:	mov    %esi,0x60(%rsp)
  4101fd:	mov    %edi,0x50(%rsp)
  410201:	mov    %r8d,0x80(%rsp)
  410209:	mov    0x140(%rsp),%rcx
  410211:	mov    (%rcx),%rax
  410214:	mov    0xe0(%rsp),%rcx
  41021c:	cmp    %rcx,%rax
  41021f:	jae    41102e <wasm[0]::function[131]::builtin::Array.prototype.join+0x280e>
  410225:	mov    %r14,%rcx
  410228:	mov    %r12,%rdx
  41022b:	mov    %rbx,%rsi
  41022e:	jmp    41023c <wasm[0]::function[131]::builtin::Array.prototype.join+0x1a1c>
  410233:	mov    %r14,%rcx
  410236:	mov    %r12,%rdx
  410239:	mov    %rbx,%rsi
  41023c:	mov    %r14,%rcx
  41023f:	mov    %r12,%rdx
  410242:	mov    %rbx,%rsi
  410245:	mov    0xb8(%rsp),%rdi
  41024d:	call   3018afa <wasmtime_builtin_memory_copy>
  410252:	mov    0x78(%rsp),%eax
  410256:	test   %eax,%eax
  410258:	je     411363 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b43>
  41025e:	mov    0x70(%rsp),%r8d
  410263:	mov    0x68(%rsp),%edx
  410267:	mov    0x60(%rsp),%ecx
  41026b:	mov    0x50(%rsp),%esi
  41026f:	mov    0x80(%rsp),%edi
  410276:	test   %eax,%eax
  410278:	je     411365 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b45>
  41027e:	test   %r8d,%r8d
  410281:	je     411367 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b47>
  410287:	test   %eax,%eax
  410289:	je     411369 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b49>
  41028f:	mov    0x138(%rsp),%r9
  410297:	mov    0x28(%r9),%r11
  41029b:	mov    0x20(%r9),%r9
  41029f:	mov    %eax,%r10d
  4102a2:	lea    (%r9,%r10,1),%r14
  4102a6:	lea    0x10(%r9,%r10,1),%r12
  4102ab:	xor    %r15,%r15
  4102ae:	cmp    %r11,%r10
  4102b1:	cmova  %r15,%r12
  4102b5:	mov    0xc0(%rsp),%r10
  4102bd:	mov    %r10d,%r13d
  4102c0:	mov    0xf0(%rsp),%r10
  4102c8:	mov    %r10d,%r10d
  4102cb:	lea    0x0(%r13,%r10,1),%rbx
  4102d0:	mov    (%r12),%r12d
  4102d4:	cmp    %r12,%rbx
  4102d7:	ja     41136b <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b4b>
  4102dd:	test   %r8d,%r8d
  4102e0:	je     41136d <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b4d>
  4102e6:	mov    %r8d,%r12d
  4102e9:	lea    (%r9,%r12,1),%r8
  4102ed:	lea    0x10(%r9,%r12,1),%rbx
  4102f2:	cmp    %r11,%r12
  4102f5:	cmova  %r15,%rbx
  4102f9:	mov    (%rbx),%ebx
  4102fb:	cmp    %rbx,%r10
  4102fe:	ja     41136f <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b4f>
  410304:	lea    0x14(%r14,%r13,2),%r14
  410309:	mov    %r10,%r13
  41030c:	shl    $1,%r13
  41030f:	mov    %r14,%rbx
  410312:	add    %r13,%rbx
  410315:	jb     411371 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b51>
  41031b:	add    %r9,%r11
  41031e:	cmp    %r11,%rbx
  410321:	ja     411373 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b53>
  410327:	lea    0x14(%r9,%r12,1),%r9
  41032c:	mov    %r9,%rbx
  41032f:	add    %r13,%rbx
  410332:	jb     411375 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b55>
  410338:	cmp    %r11,%rbx
  41033b:	ja     411377 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b57>
  410341:	cmp    %r14,%r9
  410344:	ja     41041d <wasm[0]::function[131]::builtin::Array.prototype.join+0x1bfd>
  41034a:	lea    (%r14,%r10,2),%r14
  41034e:	mov    %r14,%rbx
  410351:	lea    0x14(%r8,%r10,2),%r9
  410356:	mov    %r9,%r14
  410359:	cmp    $0x8000000,%r13
  410360:	mov    %r13,%r12
  410363:	ja     410374 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1b54>
  410369:	mov    %r12,%r8
  41036c:	mov    %rbx,%r9
  41036f:	jmp    410406 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1be6>
  410374:	mov    %edx,0x50(%rsp)
  410378:	mov    %eax,0x60(%rsp)
  41037c:	mov    %ecx,0x68(%rsp)
  410380:	mov    %esi,0x70(%rsp)
  410384:	mov    %edi,0x78(%rsp)
  410388:	mov    0x140(%rsp),%rcx
  410390:	mov    (%rcx),%r8
  410393:	mov    0xe0(%rsp),%rax
  41039b:	cmp    %rax,%r8
  41039e:	jae    41106e <wasm[0]::function[131]::builtin::Array.prototype.join+0x284e>
  4103a4:	mov    $0x8000000,%ecx
  4103a9:	mov    %rbx,%rsi
  4103ac:	sub    $0x8000000,%rsi
  4103b3:	mov    %r14,%rdx
  4103b6:	mov    %rsi,%rbx
  4103b9:	sub    $0x8000000,%rdx
  4103c0:	mov    %rdx,%r14
  4103c3:	mov    0xb8(%rsp),%rdi
  4103cb:	call   3018afa <wasmtime_builtin_memory_copy>
  4103d0:	mov    0x50(%rsp),%edx
  4103d4:	mov    0x60(%rsp),%eax
  4103d8:	mov    0x68(%rsp),%ecx
  4103dc:	mov    0x70(%rsp),%esi
  4103e0:	mov    0x78(%rsp),%edi
  4103e4:	mov    %r12,%r8
  4103e7:	sub    $0x8000000,%r8
  4103ee:	cmp    $0x8000000,%r8
  4103f5:	jbe    410403 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1be3>
  4103fb:	mov    %r8,%r12
  4103fe:	jmp    410374 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1b54>
  410403:	mov    %rbx,%r9
  410406:	sub    %r8,%r9
  410409:	mov    %r9,%rbx
  41040c:	mov    %r14,%r9
  41040f:	sub    %r8,%r9
  410412:	mov    %r9,%r14
  410415:	mov    %r8,%r12
  410418:	jmp    4104c9 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1ca9>
  41041d:	mov    %r13,%r8
  410420:	mov    %r14,%rbx
  410423:	mov    %r9,%r14
  410426:	cmp    $0x8000000,%r8
  41042d:	mov    %r8,%r12
  410430:	jbe    4104c9 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1ca9>
  410436:	mov    %edx,0x78(%rsp)
  41043a:	mov    %eax,0x70(%rsp)
  41043e:	mov    %ecx,0x68(%rsp)
  410442:	mov    %esi,0x60(%rsp)
  410446:	mov    %edi,0x50(%rsp)
  41044a:	mov    0x140(%rsp),%rcx
  410452:	mov    (%rcx),%rax
  410455:	mov    0xe0(%rsp),%rcx
  41045d:	cmp    %rcx,%rax
  410460:	jae    4110a5 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2885>
  410466:	mov    $0x8000000,%ecx
  41046b:	mov    %r14,%rdx
  41046e:	mov    %rbx,%rsi
  410471:	mov    0xb8(%rsp),%rdi
  410479:	call   3018afa <wasmtime_builtin_memory_copy>
  41047e:	mov    0x78(%rsp),%edx
  410482:	mov    0x70(%rsp),%eax
  410486:	mov    0x68(%rsp),%ecx
  41048a:	mov    0x60(%rsp),%esi
  41048e:	mov    0x50(%rsp),%edi
  410492:	mov    %r12,%r8
  410495:	sub    $0x8000000,%r8
  41049c:	mov    %r8,%r12
  41049f:	mov    %rbx,%r8
  4104a2:	add    $0x8000000,%r8
  4104a9:	mov    %r8,%rbx
  4104ac:	mov    %r14,%r8
  4104af:	add    $0x8000000,%r8
  4104b6:	mov    %r8,%r14
  4104b9:	mov    %r12,%r8
  4104bc:	cmp    $0x8000000,%r8
  4104c3:	ja     410436 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1c16>
  4104c9:	mov    %edx,0x50(%rsp)
  4104cd:	mov    %eax,0x60(%rsp)
  4104d1:	mov    %ecx,0x68(%rsp)
  4104d5:	mov    %esi,0x70(%rsp)
  4104d9:	mov    %edi,0x78(%rsp)
  4104dd:	mov    0x140(%rsp),%rcx
  4104e5:	mov    (%rcx),%rax
  4104e8:	mov    0xe0(%rsp),%rdx
  4104f0:	cmp    %rdx,%rax
  4104f3:	jae    4110dc <wasm[0]::function[131]::builtin::Array.prototype.join+0x28bc>
  4104f9:	mov    %r12,%rcx
  4104fc:	mov    %r14,%rdx
  4104ff:	mov    %rbx,%rsi
  410502:	jmp    410510 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1cf0>
  410507:	mov    %r12,%rcx
  41050a:	mov    %r14,%rdx
  41050d:	mov    %rbx,%rsi
  410510:	mov    %r12,%rcx
  410513:	mov    %r14,%rdx
  410516:	mov    %rbx,%rsi
  410519:	mov    0xb8(%rsp),%rdi
  410521:	call   3018afa <wasmtime_builtin_memory_copy>
  410526:	mov    0x50(%rsp),%r8d
  41052b:	mov    0x60(%rsp),%edi
  41052f:	mov    0x68(%rsp),%edx
  410533:	mov    0x70(%rsp),%r9d
  410538:	mov    0x78(%rsp),%esi
  41053c:	mov    0xc8(%rsp),%rcx
  410544:	mov    0xe8(%rsp),%rax
  41054c:	mov    %rax,0xc0(%rsp)
  410554:	add    $0x1,%rcx
  41055b:	mov    %rcx,0xc8(%rsp)
  410563:	jmp    40f07d <wasm[0]::function[131]::builtin::Array.prototype.join+0x85d>
  410568:	mov    0x150(%rsp),%rbx
  410570:	mov    0x158(%rsp),%r12
  410578:	mov    0x160(%rsp),%r13
  410580:	mov    0x168(%rsp),%r14
  410588:	mov    0x170(%rsp),%r15
  410590:	add    $0x180,%rsp
  410597:	mov    %rbp,%rsp
  41059a:	pop    %rbp
  41059b:	ret    $0x40
  41059e:	mov    %r11,%rdx
  4105a1:	mov    0x150(%rsp),%rbx
  4105a9:	mov    0x158(%rsp),%r12
  4105b1:	mov    0x160(%rsp),%r13
  4105b9:	mov    0x168(%rsp),%r14
  4105c1:	mov    0x170(%rsp),%r15
  4105c9:	add    $0x180,%rsp
  4105d0:	mov    %rbp,%rsp
  4105d3:	pop    %rbp
  4105d4:	ret    $0x40
  4105d7:	mov    0x58(%rsp),%eax
  4105db:	test   %eax,%eax
  4105dd:	je     411379 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b59>
  4105e3:	test   %eax,%eax
  4105e5:	je     41137b <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b5b>
  4105eb:	mov    0x138(%rsp),%r9
  4105f3:	mov    0x28(%r9),%rcx
  4105f7:	mov    0x20(%r9),%rdx
  4105fb:	mov    %eax,%esi
  4105fd:	lea    0x10(%rdx,%rsi,1),%rdx
  410602:	xor    %rdi,%rdi
  410605:	cmp    %rcx,%rsi
  410608:	cmova  %rdi,%rdx
  41060c:	mov    (%rdx),%ecx
  41060e:	mov    0xc0(%rsp),%r12
  410616:	cmp    %r12d,%ecx
  410619:	je     410a40 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2220>
  41061f:	mov    0xc0(%rsp),%r12
  410627:	mov    %r12d,%r13d
  41062a:	mov    %r13,%rcx
  41062d:	shl    $1,%rcx
  410630:	mov    %rcx,%rsi
  410633:	shr    $0x20,%rsi
  410637:	mov    %rcx,%rbx
  41063a:	test   %rsi,%rsi
  41063d:	jne    41137d <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b5d>
  410643:	mov    0xc0(%rsp),%rax
  41064b:	lea    (%r12,%rax,1),%ecx
  41064f:	add    $0x14,%ecx
  410652:	jb     41137f <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b5f>
  410658:	mov    0x120(%rsp),%r14
  410660:	mov    (%r14),%eax
  410663:	mov    %eax,%edi
  410665:	mov    %ecx,%r8d
  410668:	lea    0xf(%r8),%rsi
  41066c:	and    $0xfffffffffffffff0,%rsi
  410670:	lea    (%rdi,%rsi,1),%r8
  410674:	mov    0x4(%r14),%r9d
  410678:	cmp    %r9,%r8
  41067b:	ja     41111f <wasm[0]::function[131]::builtin::Array.prototype.join+0x28ff>
  410681:	lea    0xf(%rcx),%r9d
  410685:	and    $0xfffffff0,%r9d
  410689:	lea    (%rax,%r9,1),%r10d
  41068d:	mov    0x120(%rsp),%r14
  410695:	mov    %r10d,(%r14)
  410698:	mov    0x138(%rsp),%r9
  4106a0:	mov    0x20(%r9),%r11
  4106a4:	lea    (%r11,%rdi,1),%rcx
  4106a8:	movl   $0xa8000006,(%r11,%rdi,1)
  4106b0:	mov    0xf8(%rsp),%rdx
  4106b8:	mov    %edx,0x4(%r11,%rdi,1)
  4106bd:	mov    %esi,0x8(%r11,%rdi,1)
  4106c2:	mov    %eax,0x50(%rsp)
  4106c6:	mov    0xc0(%rsp),%r12
  4106ce:	mov    %r12d,0x10(%rcx)
  4106d2:	test   %eax,%eax
  4106d4:	je     411381 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b61>
  4106da:	mov    0x138(%rsp),%r9
  4106e2:	mov    0x28(%r9),%rcx
  4106e6:	mov    0x20(%r9),%rdx
  4106ea:	mov    %eax,%eax
  4106ec:	lea    0x10(%rdx,%rax,1),%rsi
  4106f1:	xor    %rdi,%rdi
  4106f4:	cmp    %rcx,%rax
  4106f7:	cmova  %rdi,%rsi
  4106fb:	mov    (%rsi),%esi
  4106fd:	cmp    %rsi,%r13
  410700:	ja     411383 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b63>
  410706:	lea    0x14(%rdx,%rax,1),%rdi
  41070b:	mov    %rbx,%rsi
  41070e:	mov    %rdi,%rax
  410711:	add    %rsi,%rax
  410714:	mov    %rdi,%r12
  410717:	jb     411385 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b65>
  41071d:	add    %rdx,%rcx
  410720:	cmp    %rcx,%rax
  410723:	ja     411387 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b67>
  410729:	mov    0x58(%rsp),%eax
  41072d:	cmp    $0x8000000,%rsi
  410734:	jbe    41079c <wasm[0]::function[131]::builtin::Array.prototype.join+0x1f7c>
  41073a:	mov    %eax,0x58(%rsp)
  41073e:	mov    0x140(%rsp),%rcx
  410746:	mov    (%rcx),%rax
  410749:	mov    0xe0(%rsp),%rcx
  410751:	cmp    %rcx,%rax
  410754:	jae    411157 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2937>
  41075a:	xor    %edx,%edx
  41075c:	mov    $0x8000000,%ecx
  410761:	mov    %r12,%rsi
  410764:	mov    0xb8(%rsp),%rdi
  41076c:	call   3018b23 <wasmtime_builtin_memory_fill>
  410771:	mov    0x58(%rsp),%eax
  410775:	mov    %rbx,%rcx
  410778:	sub    $0x8000000,%rcx
  41077f:	mov    %rcx,%rbx
  410782:	mov    %r12,%rsi
  410785:	add    $0x8000000,%rsi
  41078c:	mov    %rsi,%r12
  41078f:	cmp    $0x8000000,%rcx
  410796:	ja     41073a <wasm[0]::function[131]::builtin::Array.prototype.join+0x1f1a>
  41079c:	mov    %eax,0x58(%rsp)
  4107a0:	mov    0x140(%rsp),%rcx
  4107a8:	mov    (%rcx),%rax
  4107ab:	mov    0xe0(%rsp),%rdx
  4107b3:	cmp    %rdx,%rax
  4107b6:	jae    41118e <wasm[0]::function[131]::builtin::Array.prototype.join+0x296e>
  4107bc:	xor    %edx,%edx
  4107be:	mov    %rbx,%rcx
  4107c1:	mov    %r12,%rsi
  4107c4:	mov    0xb8(%rsp),%rdi
  4107cc:	call   3018b23 <wasmtime_builtin_memory_fill>
  4107d1:	mov    0x50(%rsp),%eax
  4107d5:	test   %eax,%eax
  4107d7:	je     411389 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b69>
  4107dd:	mov    0x58(%rsp),%edi
  4107e1:	test   %edi,%edi
  4107e3:	je     41138b <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b6b>
  4107e9:	test   %eax,%eax
  4107eb:	je     41138d <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b6d>
  4107f1:	mov    0x138(%rsp),%r9
  4107f9:	mov    0x28(%r9),%rsi
  4107fd:	mov    0x20(%r9),%rdx
  410801:	mov    %eax,%r8d
  410804:	lea    (%rdx,%r8,1),%rax
  410808:	lea    0x10(%rdx,%r8,1),%r10
  41080d:	xor    %r9,%r9
  410810:	cmp    %rsi,%r8
  410813:	cmova  %r9,%r10
  410817:	mov    0xc0(%rsp),%r12
  41081f:	mov    %r12d,%ecx
  410822:	mov    (%r10),%r10d
  410825:	cmp    %r10,%rcx
  410828:	ja     41138f <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b6f>
  41082e:	test   %edi,%edi
  410830:	je     411391 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b71>
  410836:	mov    %edi,%r10d
  410839:	lea    (%rdx,%r10,1),%rdi
  41083d:	lea    0x10(%rdx,%r10,1),%r11
  410842:	cmp    %rsi,%r10
  410845:	cmova  %r9,%r11
  410849:	mov    (%r11),%r9d
  41084c:	cmp    %r9,%rcx
  41084f:	ja     411393 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b73>
  410855:	lea    0x14(%rdx,%r8,1),%r11
  41085a:	mov    %rcx,%r9
  41085d:	shl    $1,%r9
  410860:	mov    %r11,%r8
  410863:	add    %r9,%r8
  410866:	jb     411395 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b75>
  41086c:	add    %rdx,%rsi
  41086f:	cmp    %rsi,%r8
  410872:	ja     411397 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b77>
  410878:	lea    0x14(%rdx,%r10,1),%rdx
  41087d:	mov    %rdx,%r8
  410880:	add    %r9,%r8
  410883:	jb     411399 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b79>
  410889:	cmp    %rsi,%r8
  41088c:	ja     41139b <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b7b>
  410892:	cmp    %r11,%rdx
  410895:	ja     410956 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2136>
  41089b:	mov    0x50(%rsp),%r8d
  4108a0:	lea    0x14(%rax,%rcx,2),%r11
  4108a5:	mov    %r11,%r12
  4108a8:	lea    0x14(%rdi,%rcx,2),%rdx
  4108ad:	mov    %rdx,%r13
  4108b0:	cmp    $0x8000000,%r9
  4108b7:	mov    %r9,%rbx
  4108ba:	ja     4108cb <wasm[0]::function[131]::builtin::Array.prototype.join+0x20ab>
  4108c0:	mov    %rbx,%rcx
  4108c3:	mov    %r12,%rsi
  4108c6:	jmp    41093f <wasm[0]::function[131]::builtin::Array.prototype.join+0x211f>
  4108cb:	mov    %r8d,0x58(%rsp)
  4108d0:	mov    0x140(%rsp),%rcx
  4108d8:	mov    (%rcx),%rax
  4108db:	mov    0xe0(%rsp),%r9
  4108e3:	cmp    %r9,%rax
  4108e6:	jae    4111c8 <wasm[0]::function[131]::builtin::Array.prototype.join+0x29a8>
  4108ec:	mov    $0x8000000,%ecx
  4108f1:	mov    %r12,%rsi
  4108f4:	sub    $0x8000000,%rsi
  4108fb:	mov    %r13,%rdx
  4108fe:	mov    %rsi,%r12
  410901:	sub    $0x8000000,%rdx
  410908:	mov    %rdx,%r13
  41090b:	mov    0xb8(%rsp),%rdi
  410913:	call   3018afa <wasmtime_builtin_memory_copy>
  410918:	mov    0x58(%rsp),%r8d
  41091d:	mov    %rbx,%rcx
  410920:	sub    $0x8000000,%rcx
  410927:	cmp    $0x8000000,%rcx
  41092e:	jbe    41093c <wasm[0]::function[131]::builtin::Array.prototype.join+0x211c>
  410934:	mov    %rcx,%rbx
  410937:	jmp    4108cb <wasm[0]::function[131]::builtin::Array.prototype.join+0x20ab>
  41093c:	mov    %r12,%rsi
  41093f:	sub    %rcx,%rsi
  410942:	mov    %r13,%rdx
  410945:	mov    %rsi,%r12
  410948:	sub    %rcx,%rdx
  41094b:	mov    %rdx,%r13
  41094e:	mov    %rcx,%rbx
  410951:	jmp    4109e6 <wasm[0]::function[131]::builtin::Array.prototype.join+0x21c6>
  410956:	mov    %r9,%rcx
  410959:	mov    %r11,%r12
  41095c:	mov    %rdx,%r13
  41095f:	mov    0x50(%rsp),%r8d
  410964:	cmp    $0x8000000,%rcx
  41096b:	mov    %rcx,%rbx
  41096e:	jbe    4109e6 <wasm[0]::function[131]::builtin::Array.prototype.join+0x21c6>
  410974:	mov    %r8d,0x50(%rsp)
  410979:	mov    0x140(%rsp),%rcx
  410981:	mov    (%rcx),%rax
  410984:	mov    0xe0(%rsp),%rcx
  41098c:	cmp    %rcx,%rax
  41098f:	jae    4111ff <wasm[0]::function[131]::builtin::Array.prototype.join+0x29df>
  410995:	mov    $0x8000000,%ecx
  41099a:	mov    %r13,%rdx
  41099d:	mov    %r12,%rsi
  4109a0:	mov    0xb8(%rsp),%rdi
  4109a8:	call   3018afa <wasmtime_builtin_memory_copy>
  4109ad:	mov    0x50(%rsp),%r8d
  4109b2:	mov    %rbx,%rcx
  4109b5:	sub    $0x8000000,%rcx
  4109bc:	mov    %rcx,%rbx
  4109bf:	mov    %r12,%rsi
  4109c2:	add    $0x8000000,%rsi
  4109c9:	mov    %r13,%rdx
  4109cc:	mov    %rsi,%r12
  4109cf:	add    $0x8000000,%rdx
  4109d6:	mov    %rdx,%r13
  4109d9:	cmp    $0x8000000,%rcx
  4109e0:	ja     410974 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2154>
  4109e6:	mov    %r8d,0x50(%rsp)
  4109eb:	mov    0x140(%rsp),%rcx
  4109f3:	mov    (%rcx),%rax
  4109f6:	mov    0xe0(%rsp),%rsi
  4109fe:	cmp    %rsi,%rax
  410a01:	jae    411236 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2a16>
  410a07:	mov    %rbx,%rcx
  410a0a:	mov    %r13,%rdx
  410a0d:	mov    %r12,%rsi
  410a10:	jmp    410a1e <wasm[0]::function[131]::builtin::Array.prototype.join+0x21fe>
  410a15:	mov    %rbx,%rcx
  410a18:	mov    %r13,%rdx
  410a1b:	mov    %r12,%rsi
  410a1e:	mov    %rbx,%rcx
  410a21:	mov    %r13,%rdx
  410a24:	mov    %r12,%rsi
  410a27:	mov    0xb8(%rsp),%rdi
  410a2f:	call   3018afa <wasmtime_builtin_memory_copy>
  410a34:	mov    0x50(%rsp),%eax
  410a38:	test   %eax,%eax
  410a3a:	je     41139d <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b7d>
  410a40:	mov    %eax,0x50(%rsp)
  410a44:	test   %eax,%eax
  410a46:	je     41139f <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b7f>
  410a4c:	mov    0x120(%rsp),%r14
  410a54:	mov    (%r14),%edx
  410a57:	mov    %edx,%ecx
  410a59:	lea    0x20(%rcx),%rax
  410a5d:	mov    0x4(%r14),%esi
  410a61:	cmp    %rsi,%rax
  410a64:	ja     411266 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2a46>
  410a6a:	lea    0x20(%rdx),%eax
  410a6d:	mov    0x120(%rsp),%r14
  410a75:	mov    %eax,(%r14)
  410a78:	mov    0x138(%rsp),%r9
  410a80:	mov    0x20(%r9),%rsi
  410a84:	lea    (%rsi,%rcx,1),%rdi
  410a88:	movl   $0xb000000a,(%rsi,%rcx,1)
  410a8f:	mov    0x100(%rsp),%r8
  410a97:	mov    0x234(%r8),%r8d
  410a9e:	mov    %r8d,0x4(%rsi,%rcx,1)
  410aa3:	mov    0x118(%rsp),%rax
  410aab:	mov    %eax,0x8(%rsi,%rcx,1)
  410aaf:	mov    0x50(%rsp),%esi
  410ab3:	mov    %esi,0x10(%rdi)
  410ab6:	xor    %rcx,%rcx
  410ab9:	movq   $0x0,0x18(%rdi)
  410ac1:	test   %edx,%edx
  410ac3:	je     4113a1 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b81>
  410ac9:	mov    $0x4,%eax
  410ace:	xor    %edi,%edi
  410ad0:	mov    %rdi,%rsi
  410ad3:	mov    0x150(%rsp),%rbx
  410adb:	mov    0x158(%rsp),%r12
  410ae3:	mov    0x160(%rsp),%r13
  410aeb:	mov    0x168(%rsp),%r14
  410af3:	mov    0x170(%rsp),%r15
  410afb:	add    $0x180,%rsp
  410b02:	mov    %rbp,%rsp
  410b05:	pop    %rbp
  410b06:	ret    $0x40
  410b09:	mov    0x150(%rsp),%rbx
  410b11:	mov    0x158(%rsp),%r12
  410b19:	mov    0x160(%rsp),%r13
  410b21:	mov    0x168(%rsp),%r14
  410b29:	mov    0x170(%rsp),%r15
  410b31:	add    $0x180,%rsp
  410b38:	mov    %rbp,%rsp
  410b3b:	pop    %rbp
  410b3c:	ret    $0x40
  410b3f:	mov    0x48(%rsp),%edx
  410b43:	mov    %r15,%rax
  410b46:	mov    %r14,%rcx
  410b49:	mov    %rbx,%rdi
  410b4c:	mov    0x150(%rsp),%rbx
  410b54:	mov    0x158(%rsp),%r12
  410b5c:	mov    0x160(%rsp),%r13
  410b64:	mov    0x168(%rsp),%r14
  410b6c:	mov    0x170(%rsp),%r15
  410b74:	add    $0x180,%rsp
  410b7b:	mov    %rbp,%rsp
  410b7e:	pop    %rbp
  410b7f:	ret    $0x40
  410b82:	mov    %rdx,%rax
  410b85:	mov    %r8,%rdx
  410b88:	mov    0x150(%rsp),%rbx
  410b90:	mov    0x158(%rsp),%r12
  410b98:	mov    0x160(%rsp),%r13
  410ba0:	mov    0x168(%rsp),%r14
  410ba8:	mov    0x170(%rsp),%r15
  410bb0:	add    $0x180,%rsp
  410bb7:	mov    %rbp,%rsp
  410bba:	pop    %rbp
  410bbb:	ret    $0x40
  410bbe:	mov    0x128(%rsp),%rax
  410bc6:	mov    0x130(%rsp),%rcx
  410bce:	mov    0x150(%rsp),%rbx
  410bd6:	mov    0x158(%rsp),%r12
  410bde:	mov    0x160(%rsp),%r13
  410be6:	mov    0x168(%rsp),%r14
  410bee:	mov    0x170(%rsp),%r15
  410bf6:	add    $0x180,%rsp
  410bfd:	mov    %rbp,%rsp
  410c00:	pop    %rbp
  410c01:	ret    $0x40
  410c04:	mov    0xb8(%rsp),%rdi
  410c0c:	call   3018b79 <wasmtime_builtin_new_epoch>
  410c11:	mov    %rax,0xe0(%rsp)
  410c19:	jmp    40e8d6 <wasm[0]::function[131]::builtin::Array.prototype.join+0xb6>
  410c1e:	mov    $0xa800000e,%esi
  410c23:	mov    0xb8(%rsp),%rdi
  410c2b:	mov    0x28(%rdi),%rax
  410c2f:	mov    0x1b4(%rax),%edx
  410c35:	mov    $0x14,%ecx
  410c3a:	mov    $0x10,%r8d
  410c40:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
  410c45:	mov    %eax,%edx
  410c47:	mov    0x138(%rsp),%r9
  410c4f:	add    0x20(%r9),%rdx
  410c53:	jmp    40ea22 <wasm[0]::function[131]::builtin::Array.prototype.join+0x202>
  410c58:	mov    $0xa8000006,%esi
  410c5d:	mov    0xb8(%rsp),%rdi
  410c65:	mov    0x28(%rdi),%rax
  410c69:	mov    0x238(%rax),%edx
  410c6f:	mov    $0x14,%ecx
  410c74:	mov    $0x10,%r8d
  410c7a:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
  410c7f:	mov    %eax,%edx
  410c81:	mov    0x138(%rsp),%r9
  410c89:	add    0x20(%r9),%rdx
  410c8d:	mov    %r13,0x118(%rsp)
  410c95:	mov    %r14,0x120(%rsp)
  410c9d:	jmp    40ef33 <wasm[0]::function[131]::builtin::Array.prototype.join+0x713>
  410ca2:	mov    0x138(%rsp),%r9
  410caa:	mov    0x8(%r9),%rax
  410cae:	cmp    %rax,%rcx
  410cb1:	jb     40efe1 <wasm[0]::function[131]::builtin::Array.prototype.join+0x7c1>
  410cb7:	mov    0xb8(%rsp),%rdi
  410cbf:	call   3018b79 <wasmtime_builtin_new_epoch>
  410cc4:	mov    %rax,0xe0(%rsp)
  410ccc:	jmp    40efe9 <wasm[0]::function[131]::builtin::Array.prototype.join+0x7c9>
  410cd1:	mov    0x138(%rsp),%r9
  410cd9:	mov    0x8(%r9),%rcx
  410cdd:	mov    %rcx,0xe0(%rsp)
  410ce5:	cmp    %rcx,%rax
  410ce8:	jb     40f0ca <wasm[0]::function[131]::builtin::Array.prototype.join+0x8aa>
  410cee:	mov    0xb8(%rsp),%rdi
  410cf6:	call   3018b79 <wasmtime_builtin_new_epoch>
  410cfb:	mov    %rax,0xe0(%rsp)
  410d03:	mov    0xc8(%rsp),%rcx
  410d0b:	mov    0xd0(%rsp),%r11
  410d13:	jmp    40f0da <wasm[0]::function[131]::builtin::Array.prototype.join+0x8ba>
  410d18:	mov    0xf8(%rsp),%rdx
  410d20:	mov    0x108(%rsp),%rsi
  410d28:	mov    0xb8(%rsp),%rdi
  410d30:	mov    0x110(%rsp),%r8
  410d38:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
  410d3d:	mov    %eax,%ecx
  410d3f:	mov    0x138(%rsp),%r9
  410d47:	add    0x20(%r9),%rcx
  410d4b:	jmp    40f2bf <wasm[0]::function[131]::builtin::Array.prototype.join+0xa9f>
  410d50:	mov    0x138(%rsp),%r9
  410d58:	mov    0x8(%r9),%rcx
  410d5c:	mov    %rcx,0xe0(%rsp)
  410d64:	cmp    %rcx,%rax
  410d67:	jb     40f393 <wasm[0]::function[131]::builtin::Array.prototype.join+0xb73>
  410d6d:	mov    0xb8(%rsp),%rdi
  410d75:	call   3018b79 <wasmtime_builtin_new_epoch>
  410d7a:	mov    %rax,0xe0(%rsp)
  410d82:	jmp    40f393 <wasm[0]::function[131]::builtin::Array.prototype.join+0xb73>
  410d87:	mov    0x138(%rsp),%r9
  410d8f:	mov    0x8(%r9),%rcx
  410d93:	mov    %rcx,0xe0(%rsp)
  410d9b:	cmp    %rcx,%rax
  410d9e:	jb     40f434 <wasm[0]::function[131]::builtin::Array.prototype.join+0xc14>
  410da4:	mov    0xb8(%rsp),%rdi
  410dac:	call   3018b79 <wasmtime_builtin_new_epoch>
  410db1:	mov    %rax,0xe0(%rsp)
  410db9:	jmp    40f434 <wasm[0]::function[131]::builtin::Array.prototype.join+0xc14>
  410dbe:	mov    0x138(%rsp),%r9
  410dc6:	mov    0x8(%r9),%rcx
  410dca:	mov    %rcx,0xe0(%rsp)
  410dd2:	cmp    %rcx,%rax
  410dd5:	jb     40f59d <wasm[0]::function[131]::builtin::Array.prototype.join+0xd7d>
  410ddb:	mov    0xb8(%rsp),%rdi
  410de3:	call   3018b79 <wasmtime_builtin_new_epoch>
  410de8:	mov    %rax,0xe0(%rsp)
  410df0:	jmp    40f59d <wasm[0]::function[131]::builtin::Array.prototype.join+0xd7d>
  410df5:	mov    0x138(%rsp),%r9
  410dfd:	mov    0x8(%r9),%rcx
  410e01:	mov    %rcx,0xe0(%rsp)
  410e09:	cmp    %rcx,%rax
  410e0c:	jb     40f697 <wasm[0]::function[131]::builtin::Array.prototype.join+0xe77>
  410e12:	mov    0xb8(%rsp),%rdi
  410e1a:	call   3018b79 <wasmtime_builtin_new_epoch>
  410e1f:	mov    %rax,0xe0(%rsp)
  410e27:	jmp    40f697 <wasm[0]::function[131]::builtin::Array.prototype.join+0xe77>
  410e2c:	mov    0x138(%rsp),%r9
  410e34:	mov    0x8(%r9),%rax
  410e38:	mov    %rax,0xe0(%rsp)
  410e40:	cmp    %rax,%r8
  410e43:	jb     40f74e <wasm[0]::function[131]::builtin::Array.prototype.join+0xf2e>
  410e49:	mov    0xb8(%rsp),%rdi
  410e51:	call   3018b79 <wasmtime_builtin_new_epoch>
  410e56:	mov    %rax,0xe0(%rsp)
  410e5e:	mov    %rbx,%rcx
  410e61:	mov    %r13,%rdx
  410e64:	mov    %r12,%rsi
  410e67:	jmp    40f757 <wasm[0]::function[131]::builtin::Array.prototype.join+0xf37>
  410e6c:	mov    0x138(%rsp),%r9
  410e74:	mov    0x8(%r9),%rcx
  410e78:	mov    %rcx,0xe0(%rsp)
  410e80:	cmp    %rcx,%rax
  410e83:	jb     40f8c8 <wasm[0]::function[131]::builtin::Array.prototype.join+0x10a8>
  410e89:	mov    0xb8(%rsp),%rdi
  410e91:	call   3018b79 <wasmtime_builtin_new_epoch>
  410e96:	mov    %rax,0xe0(%rsp)
  410e9e:	jmp    40f8c8 <wasm[0]::function[131]::builtin::Array.prototype.join+0x10a8>
  410ea3:	mov    0x138(%rsp),%rcx
  410eab:	mov    0x8(%rcx),%rax
  410eaf:	mov    %rax,0xe0(%rsp)
  410eb7:	cmp    %rax,%r9
  410eba:	jb     40f996 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1176>
  410ec0:	mov    0xb8(%rsp),%rdi
  410ec8:	call   3018b79 <wasmtime_builtin_new_epoch>
  410ecd:	mov    %rax,0xe0(%rsp)
  410ed5:	jmp    40f996 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1176>
  410eda:	mov    0x138(%rsp),%r9
  410ee2:	mov    0x8(%r9),%rcx
  410ee6:	mov    %rcx,0xe0(%rsp)
  410eee:	cmp    %rcx,%rax
  410ef1:	jb     40fa43 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1223>
  410ef7:	mov    0xb8(%rsp),%rdi
  410eff:	call   3018b79 <wasmtime_builtin_new_epoch>
  410f04:	mov    %rax,0xe0(%rsp)
  410f0c:	mov    %r12,%rcx
  410f0f:	mov    %r14,%rdx
  410f12:	mov    %rbx,%rsi
  410f15:	jmp    40fa4c <wasm[0]::function[131]::builtin::Array.prototype.join+0x122c>
  410f1a:	mov    0xf8(%rsp),%rdx
  410f22:	mov    0x108(%rsp),%rsi
  410f2a:	mov    0xb8(%rsp),%rdi
  410f32:	mov    0x110(%rsp),%r8
  410f3a:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
  410f3f:	mov    %eax,%ecx
  410f41:	mov    0x138(%rsp),%r9
  410f49:	add    0x20(%r9),%rcx
  410f4d:	jmp    40fdb4 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1594>
  410f52:	mov    0x138(%rsp),%r9
  410f5a:	mov    0x8(%r9),%rcx
  410f5e:	mov    %rcx,0xe0(%rsp)
  410f66:	cmp    %rcx,%rax
  410f69:	jb     40fe82 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1662>
  410f6f:	mov    0xb8(%rsp),%rdi
  410f77:	call   3018b79 <wasmtime_builtin_new_epoch>
  410f7c:	mov    %rax,0xe0(%rsp)
  410f84:	jmp    40fe82 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1662>
  410f89:	mov    0x138(%rsp),%r9
  410f91:	mov    0x8(%r9),%rax
  410f95:	mov    %rax,0xe0(%rsp)
  410f9d:	cmp    %rax,%r11
  410fa0:	jb     40ff1d <wasm[0]::function[131]::builtin::Array.prototype.join+0x16fd>
  410fa6:	mov    0xb8(%rsp),%rdi
  410fae:	call   3018b79 <wasmtime_builtin_new_epoch>
  410fb3:	mov    %rax,0xe0(%rsp)
  410fbb:	jmp    40ff1d <wasm[0]::function[131]::builtin::Array.prototype.join+0x16fd>
  410fc0:	mov    0x138(%rsp),%r9
  410fc8:	mov    0x8(%r9),%rcx
  410fcc:	mov    %rcx,0xe0(%rsp)
  410fd4:	cmp    %rcx,%rax
  410fd7:	jb     410088 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1868>
  410fdd:	mov    0xb8(%rsp),%rdi
  410fe5:	call   3018b79 <wasmtime_builtin_new_epoch>
  410fea:	mov    %rax,0xe0(%rsp)
  410ff2:	jmp    410088 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1868>
  410ff7:	mov    0x138(%rsp),%r9
  410fff:	mov    0x8(%r9),%rax
  411003:	mov    %rax,0xe0(%rsp)
  41100b:	cmp    %rax,%r11
  41100e:	jb     410182 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1962>
  411014:	mov    0xb8(%rsp),%rdi
  41101c:	call   3018b79 <wasmtime_builtin_new_epoch>
  411021:	mov    %rax,0xe0(%rsp)
  411029:	jmp    410182 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1962>
  41102e:	mov    0x138(%rsp),%r9
  411036:	mov    0x8(%r9),%rcx
  41103a:	mov    %rcx,0xe0(%rsp)
  411042:	cmp    %rcx,%rax
  411045:	jb     410233 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1a13>
  41104b:	mov    0xb8(%rsp),%rdi
  411053:	call   3018b79 <wasmtime_builtin_new_epoch>
  411058:	mov    %rax,0xe0(%rsp)
  411060:	mov    %r14,%rcx
  411063:	mov    %r12,%rdx
  411066:	mov    %rbx,%rsi
  411069:	jmp    41023c <wasm[0]::function[131]::builtin::Array.prototype.join+0x1a1c>
  41106e:	mov    0x138(%rsp),%r9
  411076:	mov    0x8(%r9),%rax
  41107a:	mov    %rax,0xe0(%rsp)
  411082:	cmp    %rax,%r8
  411085:	jb     4103a4 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1b84>
  41108b:	mov    0xb8(%rsp),%rdi
  411093:	call   3018b79 <wasmtime_builtin_new_epoch>
  411098:	mov    %rax,0xe0(%rsp)
  4110a0:	jmp    4103a4 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1b84>
  4110a5:	mov    0x138(%rsp),%r9
  4110ad:	mov    0x8(%r9),%rcx
  4110b1:	mov    %rcx,0xe0(%rsp)
  4110b9:	cmp    %rcx,%rax
  4110bc:	jb     410466 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1c46>
  4110c2:	mov    0xb8(%rsp),%rdi
  4110ca:	call   3018b79 <wasmtime_builtin_new_epoch>
  4110cf:	mov    %rax,0xe0(%rsp)
  4110d7:	jmp    410466 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1c46>
  4110dc:	mov    0x138(%rsp),%r9
  4110e4:	mov    0x8(%r9),%rsi
  4110e8:	mov    %rsi,%r8
  4110eb:	mov    %rsi,0xe0(%rsp)
  4110f3:	cmp    %r8,%rax
  4110f6:	jb     410507 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1ce7>
  4110fc:	mov    0xb8(%rsp),%rdi
  411104:	call   3018b79 <wasmtime_builtin_new_epoch>
  411109:	mov    %rax,0xe0(%rsp)
  411111:	mov    %r12,%rcx
  411114:	mov    %r14,%rdx
  411117:	mov    %rbx,%rsi
  41111a:	jmp    410510 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1cf0>
  41111f:	mov    0xf8(%rsp),%rdx
  411127:	mov    0x108(%rsp),%rsi
  41112f:	mov    0xb8(%rsp),%rdi
  411137:	mov    0x110(%rsp),%r8
  41113f:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
  411144:	mov    %eax,%ecx
  411146:	mov    0x138(%rsp),%r9
  41114e:	add    0x20(%r9),%rcx
  411152:	jmp    4106c2 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1ea2>
  411157:	mov    0x138(%rsp),%r9
  41115f:	mov    0x8(%r9),%rcx
  411163:	mov    %rcx,0xe0(%rsp)
  41116b:	cmp    %rcx,%rax
  41116e:	jb     41075a <wasm[0]::function[131]::builtin::Array.prototype.join+0x1f3a>
  411174:	mov    0xb8(%rsp),%rdi
  41117c:	call   3018b79 <wasmtime_builtin_new_epoch>
  411181:	mov    %rax,0xe0(%rsp)
  411189:	jmp    41075a <wasm[0]::function[131]::builtin::Array.prototype.join+0x1f3a>
  41118e:	mov    0x138(%rsp),%r9
  411196:	mov    0x8(%r9),%rsi
  41119a:	mov    %rsi,%r8
  41119d:	mov    %rsi,0xe0(%rsp)
  4111a5:	cmp    %r8,%rax
  4111a8:	jb     4107bc <wasm[0]::function[131]::builtin::Array.prototype.join+0x1f9c>
  4111ae:	mov    0xb8(%rsp),%rdi
  4111b6:	call   3018b79 <wasmtime_builtin_new_epoch>
  4111bb:	mov    %rax,0xe0(%rsp)
  4111c3:	jmp    4107bc <wasm[0]::function[131]::builtin::Array.prototype.join+0x1f9c>
  4111c8:	mov    0x138(%rsp),%r9
  4111d0:	mov    0x8(%r9),%rcx
  4111d4:	mov    %rcx,0xe0(%rsp)
  4111dc:	cmp    %rcx,%rax
  4111df:	jb     4108ec <wasm[0]::function[131]::builtin::Array.prototype.join+0x20cc>
  4111e5:	mov    0xb8(%rsp),%rdi
  4111ed:	call   3018b79 <wasmtime_builtin_new_epoch>
  4111f2:	mov    %rax,0xe0(%rsp)
  4111fa:	jmp    4108ec <wasm[0]::function[131]::builtin::Array.prototype.join+0x20cc>
  4111ff:	mov    0x138(%rsp),%r9
  411207:	mov    0x8(%r9),%rcx
  41120b:	mov    %rcx,0xe0(%rsp)
  411213:	cmp    %rcx,%rax
  411216:	jb     410995 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2175>
  41121c:	mov    0xb8(%rsp),%rdi
  411224:	call   3018b79 <wasmtime_builtin_new_epoch>
  411229:	mov    %rax,0xe0(%rsp)
  411231:	jmp    410995 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2175>
  411236:	mov    0x138(%rsp),%r9
  41123e:	mov    0x8(%r9),%rcx
  411242:	cmp    %rcx,%rax
  411245:	jb     410a15 <wasm[0]::function[131]::builtin::Array.prototype.join+0x21f5>
  41124b:	mov    0xb8(%rsp),%rdi
  411253:	call   3018b79 <wasmtime_builtin_new_epoch>
  411258:	mov    %rbx,%rcx
  41125b:	mov    %r13,%rdx
  41125e:	mov    %r12,%rsi
  411261:	jmp    410a1e <wasm[0]::function[131]::builtin::Array.prototype.join+0x21fe>
  411266:	mov    $0xb000000a,%esi
  41126b:	mov    0x100(%rsp),%rcx
  411273:	mov    0x234(%rcx),%edx
  411279:	mov    $0x20,%ecx
  41127e:	mov    0xb8(%rsp),%rdi
  411286:	mov    0x110(%rsp),%r8
  41128e:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
  411293:	mov    %eax,%edi
  411295:	mov    0x138(%rsp),%r9
  41129d:	add    0x20(%r9),%rdi
  4112a1:	mov    %rax,%rdx
  4112a4:	jmp    410aaf <wasm[0]::function[131]::builtin::Array.prototype.join+0x228f>
  4112a9:	ud2
  4112ab:	ud2
  4112ad:	ud2
  4112af:	ud2
  4112b1:	ud2
  4112b3:	ud2
  4112b5:	ud2
  4112b7:	ud2
  4112b9:	ud2
  4112bb:	ud2
  4112bd:	ud2
  4112bf:	ud2
  4112c1:	ud2
  4112c3:	ud2
  4112c5:	ud2
  4112c7:	ud2
  4112c9:	ud2
  4112cb:	ud2
  4112cd:	ud2
  4112cf:	ud2
  4112d1:	ud2
  4112d3:	ud2
  4112d5:	ud2
  4112d7:	ud2
  4112d9:	ud2
  4112db:	ud2
  4112dd:	ud2
  4112df:	ud2
  4112e1:	ud2
  4112e3:	ud2
  4112e5:	ud2
  4112e7:	ud2
  4112e9:	ud2
  4112eb:	ud2
  4112ed:	ud2
  4112ef:	ud2
  4112f1:	ud2
  4112f3:	ud2
  4112f5:	ud2
  4112f7:	ud2
  4112f9:	ud2
  4112fb:	ud2
  4112fd:	ud2
  4112ff:	ud2
  411301:	ud2
  411303:	ud2
  411305:	ud2
  411307:	ud2
  411309:	ud2
  41130b:	ud2
  41130d:	ud2
  41130f:	ud2
  411311:	ud2
  411313:	ud2
  411315:	ud2
  411317:	ud2
  411319:	ud2
  41131b:	ud2
  41131d:	ud2
  41131f:	ud2
  411321:	ud2
  411323:	ud2
  411325:	ud2
  411327:	ud2
  411329:	ud2
  41132b:	ud2
  41132d:	ud2
  41132f:	ud2
  411331:	ud2
  411333:	ud2
  411335:	ud2
  411337:	ud2
  411339:	ud2
  41133b:	ud2
  41133d:	ud2
  41133f:	ud2
  411341:	ud2
  411343:	ud2
  411345:	ud2
  411347:	ud2
  411349:	ud2
  41134b:	ud2
  41134d:	ud2
  41134f:	ud2
  411351:	ud2
  411353:	ud2
  411355:	ud2
  411357:	ud2
  411359:	ud2
  41135b:	ud2
  41135d:	ud2
  41135f:	ud2
  411361:	ud2
  411363:	ud2
  411365:	ud2
  411367:	ud2
  411369:	ud2
  41136b:	ud2
  41136d:	ud2
  41136f:	ud2
  411371:	ud2
  411373:	ud2
  411375:	ud2
  411377:	ud2
  411379:	ud2
  41137b:	ud2
  41137d:	ud2
  41137f:	ud2
  411381:	ud2
  411383:	ud2
  411385:	ud2
  411387:	ud2
  411389:	ud2
  41138b:	ud2
  41138d:	ud2
  41138f:	ud2
  411391:	ud2
  411393:	ud2
  411395:	ud2
  411397:	ud2
  411399:	ud2
  41139b:	ud2
  41139d:	ud2
  41139f:	ud2
  4113a1:	ud2
	...
  4113af:	add    %bh,%bh
  4113b1:	(bad)
  4113b2:	(bad)
  4113b3:	(bad)
  4113b4:	(bad)
  4113b5:	(bad)
  4113b6:	(bad)
  4113b7:	rex.XB add %al,(%r8)
  4113ba:	add    %al,(%rax)
  4113bc:	add    %al,(%rax)
	...
