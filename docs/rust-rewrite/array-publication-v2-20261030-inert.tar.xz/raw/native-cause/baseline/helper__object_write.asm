
/workspace/scriptw/target/performance-dense-numbers-20261030/v2/native-cause/baseline/runtime-portable.elf:     file format elf64-x86-64


Disassembly of section .text:

00000000029fc980 <wasm[0]::function[1016]::helper::object_write>:
 29fc980:	push   %rbp
 29fc981:	mov    %rsp,%rbp
 29fc984:	mov    0x8(%rdi),%r10
 29fc988:	mov    0x18(%r10),%r10
 29fc98c:	add    $0xf0,%r10
 29fc993:	cmp    %rsp,%r10
 29fc996:	ja     29fd047 <wasm[0]::function[1016]::helper::object_write+0x6c7>
 29fc99c:	sub    $0xe0,%rsp
 29fc9a3:	mov    %rbx,0xb0(%rsp)
 29fc9ab:	mov    %r12,0xb8(%rsp)
 29fc9b3:	mov    %r13,0xc0(%rsp)
 29fc9bb:	mov    %r14,0xc8(%rsp)
 29fc9c3:	mov    %r15,0xd0(%rsp)
 29fc9cb:	mov    %rdx,0x78(%rsp)
 29fc9d0:	mov    %rcx,0x80(%rsp)
 29fc9d8:	mov    %r9,0x88(%rsp)
 29fc9e0:	mov    0x10(%rbp),%r13
 29fc9e4:	mov    0x18(%rbp),%r9
 29fc9e8:	mov    0x20(%rbp),%r14
 29fc9ec:	mov    0x28(%rbp),%r15
 29fc9f0:	mov    0x30(%rbp),%rax
 29fc9f4:	mov    0x38(%rbp),%rcx
 29fc9f8:	mov    %rcx,0x90(%rsp)
 29fca00:	mov    0x40(%rbp),%rdx
 29fca04:	mov    0x48(%rbp),%rcx
 29fca08:	mov    %r8d,0x50(%rsp)
 29fca0d:	mov    %r9d,0x60(%rsp)
 29fca12:	mov    %eax,0x68(%rsp)
 29fca16:	mov    %edx,0x58(%rsp)
 29fca1a:	mov    %ecx,0x70(%rsp)
 29fca1e:	mov    0x18(%rdi),%r10
 29fca22:	mov    (%r10),%r9
 29fca25:	mov    %r10,0xa0(%rsp)
 29fca2d:	mov    0x8(%rdi),%r12
 29fca31:	mov    %rdi,%rsi
 29fca34:	mov    0x8(%r12),%rax
 29fca39:	cmp    %rax,%r9
 29fca3c:	jae    29fd014 <wasm[0]::function[1016]::helper::object_write+0x694>
 29fca42:	mov    %rsi,%rbx
 29fca45:	mov    %rax,0x98(%rsp)
 29fca4d:	mov    0x70(%rsp),%eax
 29fca51:	test   %eax,%eax
 29fca53:	je     29fd049 <wasm[0]::function[1016]::helper::object_write+0x6c9>
 29fca59:	mov    0x50(%rsp),%r8d
 29fca5e:	mov    0x60(%rsp),%edi
 29fca62:	mov    0x68(%rsp),%edx
 29fca66:	mov    0x58(%rsp),%esi
 29fca6a:	mov    0x80(%rsp),%rcx
 29fca72:	mov    %rcx,(%rsp)
 29fca76:	mov    %r8d,0x8(%rsp)
 29fca7b:	mov    0x88(%rsp),%r9
 29fca83:	mov    %r9d,0x10(%rsp)
 29fca88:	mov    %r13,0x18(%rsp)
 29fca8d:	mov    %edi,0x20(%rsp)
 29fca91:	mov    %r14d,0x28(%rsp)
 29fca96:	mov    %r15,0x30(%rsp)
 29fca9b:	mov    %edx,0x38(%rsp)
 29fca9f:	mov    %esi,0x40(%rsp)
 29fcaa3:	mov    %eax,0x48(%rsp)
 29fcaa7:	mov    0x78(%rsp),%r9
 29fcaac:	mov    %rbx,%rsi
 29fcaaf:	mov    %rbx,%rdi
 29fcab2:	mov    %r9,%rdx
 29fcab5:	call   2c56da0 <wasm[0]::function[1073]::helper::ordinary_set>
 29fcaba:	sub    $0x50,%rsp
 29fcabe:	test   %esi,%esi
 29fcac0:	je     29fcad1 <wasm[0]::function[1016]::helper::object_write+0x151>
 29fcac6:	mov    %rdi,%rbx
 29fcac9:	mov    %rcx,%r14
 29fcacc:	jmp    29fcfd8 <wasm[0]::function[1016]::helper::object_write+0x658>
 29fcad1:	cmp    $0x2,%eax
 29fcad4:	je     29fcd6f <wasm[0]::function[1016]::helper::object_write+0x3ef>
 29fcada:	cmp    $0x4,%eax
 29fcadd:	je     29fccc8 <wasm[0]::function[1016]::helper::object_write+0x348>
 29fcae3:	cmp    $0x3,%eax
 29fcae6:	je     29fcc95 <wasm[0]::function[1016]::helper::object_write+0x315>
 29fcaec:	cmp    $0xa,%eax
 29fcaef:	je     29fcbed <wasm[0]::function[1016]::helper::object_write+0x26d>
 29fcaf5:	test   %eax,%eax
 29fcaf7:	sete   %cl
 29fcafa:	cmp    $0x1,%eax
 29fcafd:	sete   %al
 29fcb00:	or     %eax,%ecx
 29fcb02:	test   %cl,%cl
 29fcb04:	jne    29fcbe6 <wasm[0]::function[1016]::helper::object_write+0x266>
 29fcb0a:	xor    %eax,%eax
 29fcb0c:	test   %edx,%edx
 29fcb0e:	je     29fcb4f <wasm[0]::function[1016]::helper::object_write+0x1cf>
 29fcb14:	xor    %eax,%eax
 29fcb16:	test   $0x1,%edx
 29fcb1c:	jne    29fcb4f <wasm[0]::function[1016]::helper::object_write+0x1cf>
 29fcb22:	mov    0x28(%r12),%rax
 29fcb27:	mov    0x20(%r12),%rsi
 29fcb2c:	mov    %edx,%edi
 29fcb2e:	xor    %rcx,%rcx
 29fcb31:	lea    0x4(%rsi,%rdi,1),%rsi
 29fcb36:	cmp    %rax,%rdi
 29fcb39:	cmova  %rcx,%rsi
 29fcb3d:	mov    (%rsi),%eax
 29fcb3f:	mov    0x28(%rbx),%rcx
 29fcb43:	cmp    0x1d4(%rcx),%eax
 29fcb49:	sete   %al
 29fcb4c:	movzbl %al,%eax
 29fcb4f:	test   %eax,%eax
 29fcb51:	jne    29fcb5e <wasm[0]::function[1016]::helper::object_write+0x1de>
 29fcb57:	xor    %eax,%eax
 29fcb59:	jmp    29fcbd7 <wasm[0]::function[1016]::helper::object_write+0x257>
 29fcb5e:	xor    %eax,%eax
 29fcb60:	test   %edx,%edx
 29fcb62:	je     29fcba3 <wasm[0]::function[1016]::helper::object_write+0x223>
 29fcb68:	xor    %eax,%eax
 29fcb6a:	test   $0x1,%edx
 29fcb70:	jne    29fcba3 <wasm[0]::function[1016]::helper::object_write+0x223>
 29fcb76:	mov    0x28(%r12),%rax
 29fcb7b:	mov    0x20(%r12),%rsi
 29fcb80:	mov    %edx,%edi
 29fcb82:	xor    %rcx,%rcx
 29fcb85:	lea    0x4(%rsi,%rdi,1),%rsi
 29fcb8a:	cmp    %rax,%rdi
 29fcb8d:	cmova  %rcx,%rsi
 29fcb91:	mov    (%rsi),%eax
 29fcb93:	mov    0x28(%rbx),%rcx
 29fcb97:	cmp    0x1d4(%rcx),%eax
 29fcb9d:	sete   %al
 29fcba0:	movzbl %al,%eax
 29fcba3:	test   %eax,%eax
 29fcba5:	je     29fd04b <wasm[0]::function[1016]::helper::object_write+0x6cb>
 29fcbab:	test   %edx,%edx
 29fcbad:	je     29fd04d <wasm[0]::function[1016]::helper::object_write+0x6cd>
 29fcbb3:	test   %edx,%edx
 29fcbb5:	je     29fd04f <wasm[0]::function[1016]::helper::object_write+0x6cf>
 29fcbbb:	mov    0x28(%r12),%rax
 29fcbc0:	mov    %edx,%edx
 29fcbc2:	xor    %rcx,%rcx
 29fcbc5:	mov    %rdx,%rsi
 29fcbc8:	add    0x20(%r12),%rsi
 29fcbcd:	cmp    %rax,%rdx
 29fcbd0:	cmova  %rcx,%rsi
 29fcbd4:	mov    0x3c(%rsi),%eax
 29fcbd7:	test   %eax,%eax
 29fcbd9:	sete   %sil
 29fcbdd:	movzbl %sil,%eax
 29fcbe1:	jmp    29fcd78 <wasm[0]::function[1016]::helper::object_write+0x3f8>
 29fcbe6:	xor    %eax,%eax
 29fcbe8:	jmp    29fcd78 <wasm[0]::function[1016]::helper::object_write+0x3f8>
 29fcbed:	xor    %eax,%eax
 29fcbef:	test   %edx,%edx
 29fcbf1:	je     29fcc33 <wasm[0]::function[1016]::helper::object_write+0x2b3>
 29fcbf7:	xor    %eax,%eax
 29fcbf9:	test   $0x1,%edx
 29fcbff:	jne    29fcc33 <wasm[0]::function[1016]::helper::object_write+0x2b3>
 29fcc05:	mov    0x28(%r12),%rax
 29fcc0a:	mov    0x20(%r12),%rsi
 29fcc0f:	mov    %edx,%edi
 29fcc11:	xor    %rcx,%rcx
 29fcc14:	lea    0x4(%rsi,%rdi,1),%r11
 29fcc19:	cmp    %rax,%rdi
 29fcc1c:	cmova  %rcx,%r11
 29fcc20:	mov    (%r11),%eax
 29fcc23:	mov    0x28(%rbx),%rcx
 29fcc27:	cmp    0x23c(%rcx),%eax
 29fcc2d:	sete   %al
 29fcc30:	movzbl %al,%eax
 29fcc33:	test   %eax,%eax
 29fcc35:	je     29fd051 <wasm[0]::function[1016]::helper::object_write+0x6d1>
 29fcc3b:	test   %edx,%edx
 29fcc3d:	je     29fd053 <wasm[0]::function[1016]::helper::object_write+0x6d3>
 29fcc43:	test   %edx,%edx
 29fcc45:	je     29fd055 <wasm[0]::function[1016]::helper::object_write+0x6d5>
 29fcc4b:	mov    0x28(%r12),%rax
 29fcc50:	mov    0x20(%r12),%rsi
 29fcc55:	mov    %edx,%edx
 29fcc57:	xor    %rcx,%rcx
 29fcc5a:	lea    (%rsi,%rdx,1),%rdi
 29fcc5e:	cmp    %rax,%rdx
 29fcc61:	cmova  %rcx,%rdi
 29fcc65:	mov    0x14(%rdi),%edx
 29fcc68:	test   %edx,%edx
 29fcc6a:	je     29fd057 <wasm[0]::function[1016]::helper::object_write+0x6d7>
 29fcc70:	test   %edx,%edx
 29fcc72:	je     29fd059 <wasm[0]::function[1016]::helper::object_write+0x6d9>
 29fcc78:	mov    %edx,%edi
 29fcc7a:	lea    0x10(%rsi,%rdi,1),%rdx
 29fcc7f:	cmp    %rax,%rdi
 29fcc82:	cmova  %rcx,%rdx
 29fcc86:	mov    (%rdx),%eax
 29fcc88:	test   %eax,%eax
 29fcc8a:	setne  %al
 29fcc8d:	movzbl %al,%eax
 29fcc90:	jmp    29fcd78 <wasm[0]::function[1016]::helper::object_write+0x3f8>
 29fcc95:	movq   %rcx,%xmm0
 29fcc9a:	ucomisd 0x3ee(%rip),%xmm0        # 29fd090 <wasm[0]::function[1016]::helper::object_write+0x710>
 29fcca2:	setnp  %al
 29fcca5:	sete   %cl
 29fcca8:	and    %ecx,%eax
 29fccaa:	ucomisd %xmm0,%xmm0
 29fccae:	setp   %cl
 29fccb1:	setne  %dl
 29fccb4:	or     %edx,%ecx
 29fccb6:	or     %ecx,%eax
 29fccb8:	movzbl %al,%eax
 29fccbb:	test   %eax,%eax
 29fccbd:	sete   %al
 29fccc0:	movzbl %al,%eax
 29fccc3:	jmp    29fcd78 <wasm[0]::function[1016]::helper::object_write+0x3f8>
 29fccc8:	xor    %eax,%eax
 29fccca:	test   %edx,%edx
 29fcccc:	je     29fcd0d <wasm[0]::function[1016]::helper::object_write+0x38d>
 29fccd2:	xor    %eax,%eax
 29fccd4:	test   $0x1,%edx
 29fccda:	jne    29fcd0d <wasm[0]::function[1016]::helper::object_write+0x38d>
 29fcce0:	mov    0x28(%r12),%rax
 29fcce5:	mov    0x20(%r12),%rsi
 29fccea:	mov    %edx,%edi
 29fccec:	xor    %rcx,%rcx
 29fccef:	lea    0x4(%rsi,%rdi,1),%rsi
 29fccf4:	cmp    %rax,%rdi
 29fccf7:	cmova  %rcx,%rsi
 29fccfb:	mov    (%rsi),%eax
 29fccfd:	mov    0x28(%rbx),%rcx
 29fcd01:	cmp    0x234(%rcx),%eax
 29fcd07:	sete   %al
 29fcd0a:	movzbl %al,%eax
 29fcd0d:	test   %eax,%eax
 29fcd0f:	je     29fd05b <wasm[0]::function[1016]::helper::object_write+0x6db>
 29fcd15:	test   %edx,%edx
 29fcd17:	je     29fd05d <wasm[0]::function[1016]::helper::object_write+0x6dd>
 29fcd1d:	test   %edx,%edx
 29fcd1f:	je     29fd05f <wasm[0]::function[1016]::helper::object_write+0x6df>
 29fcd25:	mov    0x28(%r12),%rax
 29fcd2a:	mov    0x20(%r12),%rsi
 29fcd2f:	mov    %edx,%edx
 29fcd31:	xor    %rcx,%rcx
 29fcd34:	lea    (%rsi,%rdx,1),%rdi
 29fcd38:	cmp    %rax,%rdx
 29fcd3b:	cmova  %rcx,%rdi
 29fcd3f:	mov    0x10(%rdi),%edx
 29fcd42:	test   %edx,%edx
 29fcd44:	je     29fd061 <wasm[0]::function[1016]::helper::object_write+0x6e1>
 29fcd4a:	test   %edx,%edx
 29fcd4c:	je     29fd063 <wasm[0]::function[1016]::helper::object_write+0x6e3>
 29fcd52:	mov    %edx,%edi
 29fcd54:	lea    0x10(%rsi,%rdi,1),%rdx
 29fcd59:	cmp    %rax,%rdi
 29fcd5c:	cmova  %rcx,%rdx
 29fcd60:	mov    (%rdx),%eax
 29fcd62:	test   %eax,%eax
 29fcd64:	setne  %al
 29fcd67:	movzbl %al,%eax
 29fcd6a:	jmp    29fcd78 <wasm[0]::function[1016]::helper::object_write+0x3f8>
 29fcd6f:	test   %rcx,%rcx
 29fcd72:	setne  %al
 29fcd75:	movzbl %al,%eax
 29fcd78:	test   %eax,%eax
 29fcd7a:	sete   %al
 29fcd7d:	movzbl %al,%eax
 29fcd80:	mov    0x90(%rsp),%rcx
 29fcd88:	test   %eax,%ecx
 29fcd8a:	jne    29fcda6 <wasm[0]::function[1016]::helper::object_write+0x426>
 29fcd90:	xor    %eax,%eax
 29fcd92:	xor    %rcx,%rcx
 29fcd95:	mov    %rax,%rdx
 29fcd98:	mov    %rax,%rbx
 29fcd9b:	mov    %rax,%rsi
 29fcd9e:	mov    %rcx,%r14
 29fcda1:	jmp    29fcfd8 <wasm[0]::function[1016]::helper::object_write+0x658>
 29fcda6:	mov    0x58(%rsp),%esi
 29fcdaa:	xor    %edx,%edx
 29fcdac:	xor    %rcx,%rcx
 29fcdaf:	mov    %rcx,%r14
 29fcdb2:	mov    %esi,0x50(%rsp)
 29fcdb6:	mov    %edx,0x58(%rsp)
 29fcdba:	mov    0xa0(%rsp),%r13
 29fcdc2:	mov    0x0(%r13),%rsi
 29fcdc6:	mov    0x98(%rsp),%rax
 29fcdce:	cmp    %rax,%rsi
 29fcdd1:	jae    29fd02c <wasm[0]::function[1016]::helper::object_write+0x6ac>
 29fcdd7:	mov    0x50(%rsp),%ecx
 29fcddb:	mov    0x58(%rsp),%edx
 29fcddf:	test   %ecx,%ecx
 29fcde1:	je     29fce5d <wasm[0]::function[1016]::helper::object_write+0x4dd>
 29fcde7:	mov    0x50(%rsp),%ecx
 29fcdeb:	test   %ecx,%ecx
 29fcded:	je     29fd065 <wasm[0]::function[1016]::helper::object_write+0x6e5>
 29fcdf3:	mov    0x28(%r12),%rdx
 29fcdf8:	mov    0x20(%r12),%rsi
 29fcdfd:	mov    %ecx,%ecx
 29fcdff:	add    %rcx,%rsi
 29fce02:	cmp    %rdx,%rcx
 29fce05:	mov    %r14,%rcx
 29fce08:	cmova  %rcx,%rsi
 29fce0c:	mov    0x10(%rsi),%edx
 29fce0f:	test   %edx,%edx
 29fce11:	je     29fce1f <wasm[0]::function[1016]::helper::object_write+0x49f>
 29fce17:	mov    %rcx,%r14
 29fce1a:	jmp    29fce5d <wasm[0]::function[1016]::helper::object_write+0x4dd>
 29fce1f:	mov    0x50(%rsp),%esi
 29fce23:	test   %esi,%esi
 29fce25:	je     29fd067 <wasm[0]::function[1016]::helper::object_write+0x6e7>
 29fce2b:	mov    0x28(%r12),%rdi
 29fce30:	mov    %esi,%r8d
 29fce33:	mov    %r8,%rsi
 29fce36:	add    0x20(%r12),%rsi
 29fce3b:	cmp    %rdi,%r8
 29fce3e:	cmova  %rcx,%rsi
 29fce42:	mov    %rcx,%r14
 29fce45:	mov    0x1c(%rsi),%esi
 29fce48:	mov    %rax,0x98(%rsp)
 29fce50:	mov    %r13,0xa0(%rsp)
 29fce58:	jmp    29fcdb2 <wasm[0]::function[1016]::helper::object_write+0x432>
 29fce5d:	test   %edx,%edx
 29fce5f:	jne    29fce73 <wasm[0]::function[1016]::helper::object_write+0x4f3>
 29fce65:	mov    0x8c0(%rbx),%edx
 29fce6b:	test   %edx,%edx
 29fce6d:	je     29fd069 <wasm[0]::function[1016]::helper::object_write+0x6e9>
 29fce73:	mov    %edx,0x50(%rsp)
 29fce77:	test   %edx,%edx
 29fce79:	je     29fd06b <wasm[0]::function[1016]::helper::object_write+0x6eb>
 29fce7f:	mov    %rbx,%rsi
 29fce82:	mov    %rbx,%rdi
 29fce85:	call   2ac60a0 <wasm[0]::function[1049]::helper::realm_ensure_errors>
 29fce8a:	mov    0x50(%rsp),%edx
 29fce8e:	test   %edx,%edx
 29fce90:	je     29fd06d <wasm[0]::function[1016]::helper::object_write+0x6ed>
 29fce96:	test   %edx,%edx
 29fce98:	je     29fd06f <wasm[0]::function[1016]::helper::object_write+0x6ef>
 29fce9e:	mov    0x28(%r12),%rax
 29fcea3:	mov    0x20(%r12),%rcx
 29fcea8:	mov    %edx,%esi
 29fceaa:	lea    (%rcx,%rsi,1),%rdx
 29fceae:	cmp    %rax,%rsi
 29fceb1:	mov    %r14,%rsi
 29fceb4:	cmova  %rsi,%rdx
 29fceb8:	mov    0x2c(%rdx),%edx
 29fcebb:	test   %edx,%edx
 29fcebd:	je     29fd071 <wasm[0]::function[1016]::helper::object_write+0x6f1>
 29fcec3:	test   %edx,%edx
 29fcec5:	je     29fd073 <wasm[0]::function[1016]::helper::object_write+0x6f3>
 29fcecb:	mov    %edx,%edi
 29fcecd:	lea    0x10(%rcx,%rdi,1),%rsi
 29fced2:	cmp    %rax,%rdi
 29fced5:	mov    %r14,%rdi
 29fced8:	cmova  %rdi,%rsi
 29fcedc:	mov    (%rsi),%esi
 29fcede:	cmp    $0x3,%esi
 29fcee1:	jbe    29fd075 <wasm[0]::function[1016]::helper::object_write+0x6f5>
 29fcee7:	mov    %esi,%edi
 29fcee9:	shl    $0x2,%rdi
 29fceed:	shr    $0x20,%rdi
 29fcef1:	test   %rdi,%rdi
 29fcef4:	jne    29fd077 <wasm[0]::function[1016]::helper::object_write+0x6f7>
 29fcefa:	shl    $0x2,%esi
 29fcefd:	add    $0x14,%esi
 29fcf00:	jb     29fd079 <wasm[0]::function[1016]::helper::object_write+0x6f9>
 29fcf06:	add    %esi,%edx
 29fcf08:	jb     29fd07b <wasm[0]::function[1016]::helper::object_write+0x6fb>
 29fcf0e:	mov    %edx,%edi
 29fcf10:	lea    (%rcx,%rdi,1),%rdx
 29fcf14:	cmp    %rax,%rdi
 29fcf17:	mov    %r14,%rdi
 29fcf1a:	cmova  %rdi,%rdx
 29fcf1e:	sub    $0x20,%esi
 29fcf21:	sub    %rsi,%rdx
 29fcf24:	mov    (%rdx),%edx
 29fcf26:	test   %edx,%edx
 29fcf28:	je     29fd07d <wasm[0]::function[1016]::helper::object_write+0x6fd>
 29fcf2e:	test   %edx,%edx
 29fcf30:	je     29fd07f <wasm[0]::function[1016]::helper::object_write+0x6ff>
 29fcf36:	mov    %edx,%edx
 29fcf38:	add    %rdx,%rcx
 29fcf3b:	cmp    %rax,%rdx
 29fcf3e:	mov    %r14,%rdx
 29fcf41:	cmova  %rdx,%rcx
 29fcf45:	mov    0x18(%rcx),%r13d
 29fcf49:	mov    0x10(%rcx),%r12
 29fcf4d:	mov    0x1c(%rcx),%eax
 29fcf50:	mov    %eax,0x50(%rsp)
 29fcf54:	cmp    $0x6,%r13d
 29fcf58:	sete   %cl
 29fcf5b:	cmp    $0x7,%r13d
 29fcf5f:	sete   %al
 29fcf62:	or     %eax,%ecx
 29fcf64:	cmp    $0x8,%r13d
 29fcf68:	sete   %al
 29fcf6b:	or     %eax,%ecx
 29fcf6d:	cmp    $0x9,%r13d
 29fcf71:	sete   %al
 29fcf74:	or     %eax,%ecx
 29fcf76:	movzbl %cl,%eax
 29fcf79:	test   %eax,%eax
 29fcf7b:	je     29fd081 <wasm[0]::function[1016]::helper::object_write+0x701>
 29fcf81:	mov    $0x795,%edx
 29fcf86:	mov    %rbx,%rsi
 29fcf89:	mov    %rbx,%rdi
 29fcf8c:	call   2f30600 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 29fcf91:	mov    %rbx,%rsi
 29fcf94:	xor    %edi,%edi
 29fcf96:	mov    %rdi,%rbx
 29fcf99:	test   %eax,%eax
 29fcf9b:	je     29fd083 <wasm[0]::function[1016]::helper::object_write+0x703>
 29fcfa1:	mov    0x50(%rsp),%r9d
 29fcfa6:	mov    $0x5,%edx
 29fcfab:	mov    %eax,(%rsp)
 29fcfae:	mov    %r13,%rcx
 29fcfb1:	mov    %r12,%r8
 29fcfb4:	mov    %rsi,%rdi
 29fcfb7:	call   2f30360 <wasm[0]::function[1101]::helper::runtime_error_for_throw>
 29fcfbc:	sub    $0x10,%rsp
 29fcfc0:	test   %eax,%eax
 29fcfc2:	mov    %rax,%rcx
 29fcfc5:	je     29fd085 <wasm[0]::function[1016]::helper::object_write+0x705>
 29fcfcb:	mov    $0x6,%eax
 29fcfd0:	mov    $0x1,%esi
 29fcfd5:	mov    %rcx,%rdx
 29fcfd8:	mov    %r14,%rcx
 29fcfdb:	mov    %rbx,%rdi
 29fcfde:	mov    0xb0(%rsp),%rbx
 29fcfe6:	mov    0xb8(%rsp),%r12
 29fcfee:	mov    0xc0(%rsp),%r13
 29fcff6:	mov    0xc8(%rsp),%r14
 29fcffe:	mov    0xd0(%rsp),%r15
 29fd006:	add    $0xe0,%rsp
 29fd00d:	mov    %rbp,%rsp
 29fd010:	pop    %rbp
 29fd011:	ret    $0x40
 29fd014:	mov    %rsi,%rbx
 29fd017:	mov    %rbx,%rdi
 29fd01a:	call   3018b79 <wasmtime_builtin_new_epoch>
 29fd01f:	mov    %rax,0x98(%rsp)
 29fd027:	jmp    29fca4d <wasm[0]::function[1016]::helper::object_write+0xcd>
 29fd02c:	mov    0x8(%r12),%rax
 29fd031:	cmp    %rax,%rsi
 29fd034:	jb     29fcdd7 <wasm[0]::function[1016]::helper::object_write+0x457>
 29fd03a:	mov    %rbx,%rdi
 29fd03d:	call   3018b79 <wasmtime_builtin_new_epoch>
 29fd042:	jmp    29fcdd7 <wasm[0]::function[1016]::helper::object_write+0x457>
 29fd047:	ud2
 29fd049:	ud2
 29fd04b:	ud2
 29fd04d:	ud2
 29fd04f:	ud2
 29fd051:	ud2
 29fd053:	ud2
 29fd055:	ud2
 29fd057:	ud2
 29fd059:	ud2
 29fd05b:	ud2
 29fd05d:	ud2
 29fd05f:	ud2
 29fd061:	ud2
 29fd063:	ud2
 29fd065:	ud2
 29fd067:	ud2
 29fd069:	ud2
 29fd06b:	ud2
 29fd06d:	ud2
 29fd06f:	ud2
 29fd071:	ud2
 29fd073:	ud2
 29fd075:	ud2
 29fd077:	ud2
 29fd079:	ud2
 29fd07b:	ud2
 29fd07d:	ud2
 29fd07f:	ud2
 29fd081:	ud2
 29fd083:	ud2
 29fd085:	ud2
	...
