
/workspace/scriptw/target/performance-dense-numbers-20261030/v2/native-cause/baseline/runtime-portable.elf:     file format elf64-x86-64


Disassembly of section .text:

00000000029d8760 <wasm[0]::function[1010]::helper::array_packed_push1>:
 29d8760:	push   %rbp
 29d8761:	mov    %rsp,%rbp
 29d8764:	mov    0x8(%rdi),%r10
 29d8768:	mov    0x18(%r10),%r10
 29d876c:	add    $0xe0,%r10
 29d8773:	cmp    %rsp,%r10
 29d8776:	ja     29d917d <wasm[0]::function[1010]::helper::array_packed_push1+0xa1d>
 29d877c:	sub    $0xd0,%rsp
 29d8783:	mov    %rbx,0xa0(%rsp)
 29d878b:	mov    %r12,0xa8(%rsp)
 29d8793:	mov    %r13,0xb0(%rsp)
 29d879b:	mov    %r14,0xb8(%rsp)
 29d87a3:	mov    %r15,0xc0(%rsp)
 29d87ab:	mov    %r9,0x48(%rsp)
 29d87b0:	mov    0x10(%rbp),%r9
 29d87b4:	mov    %r9,0x50(%rsp)
 29d87b9:	mov    0x18(%rbp),%rsi
 29d87bd:	mov    %r8d,0x20(%rsp)
 29d87c2:	mov    %esi,0x18(%rsp)
 29d87c6:	mov    0x18(%rdi),%rax
 29d87ca:	mov    (%rax),%rcx
 29d87cd:	mov    %rax,0x90(%rsp)
 29d87d5:	mov    0x8(%rdi),%rbx
 29d87d9:	mov    %rdi,%r10
 29d87dc:	mov    0x8(%rbx),%rax
 29d87e0:	cmp    %rax,%rcx
 29d87e3:	jae    29d911d <wasm[0]::function[1010]::helper::array_packed_push1+0x9bd>
 29d87e9:	mov    %r10,%r14
 29d87ec:	mov    %rax,0x58(%rsp)
 29d87f1:	mov    0x20(%rsp),%eax
 29d87f5:	xor    %edx,%edx
 29d87f7:	test   %eax,%eax
 29d87f9:	je     29d883f <wasm[0]::function[1010]::helper::array_packed_push1+0xdf>
 29d87ff:	mov    0x20(%rsp),%eax
 29d8803:	xor    %edx,%edx
 29d8805:	test   $0x1,%eax
 29d880a:	jne    29d883f <wasm[0]::function[1010]::helper::array_packed_push1+0xdf>
 29d8810:	mov    0x20(%rsp),%ecx
 29d8814:	mov    0x28(%rbx),%rax
 29d8818:	mov    0x20(%rbx),%rdx
 29d881c:	mov    %ecx,%esi
 29d881e:	xor    %rcx,%rcx
 29d8821:	lea    0x4(%rdx,%rsi,1),%rdx
 29d8826:	cmp    %rax,%rsi
 29d8829:	cmova  %rcx,%rdx
 29d882d:	mov    (%rdx),%eax
 29d882f:	mov    0x28(%r14),%rcx
 29d8833:	cmp    0x254(%rcx),%eax
 29d8839:	sete   %al
 29d883c:	movzbl %al,%edx
 29d883f:	xor    %eax,%eax
 29d8841:	xor    %rcx,%rcx
 29d8844:	test   %edx,%edx
 29d8846:	jne    29d885f <wasm[0]::function[1010]::helper::array_packed_push1+0xff>
 29d884c:	mov    %rax,%rdx
 29d884f:	mov    %rax,%rsi
 29d8852:	mov    %rax,%rdi
 29d8855:	mov    %rcx,0x68(%rsp)
 29d885a:	jmp    29d90e2 <wasm[0]::function[1010]::helper::array_packed_push1+0x982>
 29d885f:	mov    0x20(%rsp),%edx
 29d8863:	xor    %eax,%eax
 29d8865:	test   %edx,%edx
 29d8867:	je     29d88ab <wasm[0]::function[1010]::helper::array_packed_push1+0x14b>
 29d886d:	mov    0x20(%rsp),%edx
 29d8871:	xor    %eax,%eax
 29d8873:	test   $0x1,%edx
 29d8879:	jne    29d88ab <wasm[0]::function[1010]::helper::array_packed_push1+0x14b>
 29d887f:	mov    0x20(%rsp),%edx
 29d8883:	mov    0x28(%rbx),%rax
 29d8887:	mov    0x20(%rbx),%rsi
 29d888b:	mov    %edx,%edi
 29d888d:	lea    0x4(%rsi,%rdi,1),%rdx
 29d8892:	cmp    %rax,%rdi
 29d8895:	cmova  %rcx,%rdx
 29d8899:	mov    (%rdx),%eax
 29d889b:	mov    0x28(%r14),%rdx
 29d889f:	cmp    0x254(%rdx),%eax
 29d88a5:	sete   %al
 29d88a8:	movzbl %al,%eax
 29d88ab:	test   %eax,%eax
 29d88ad:	je     29d917f <wasm[0]::function[1010]::helper::array_packed_push1+0xa1f>
 29d88b3:	mov    0x20(%rsp),%eax
 29d88b7:	xor    %edx,%edx
 29d88b9:	test   %eax,%eax
 29d88bb:	je     29d9181 <wasm[0]::function[1010]::helper::array_packed_push1+0xa21>
 29d88c1:	test   %eax,%eax
 29d88c3:	je     29d9183 <wasm[0]::function[1010]::helper::array_packed_push1+0xa23>
 29d88c9:	mov    0x28(%rbx),%rsi
 29d88cd:	mov    0x20(%rbx),%rdi
 29d88d1:	mov    %eax,%r8d
 29d88d4:	add    %r8,%rdi
 29d88d7:	cmp    %rsi,%r8
 29d88da:	cmova  %rcx,%rdi
 29d88de:	mov    0x18(%rdi),%r15
 29d88e2:	test   %eax,%eax
 29d88e4:	je     29d8929 <wasm[0]::function[1010]::helper::array_packed_push1+0x1c9>
 29d88ea:	mov    0x20(%rsp),%esi
 29d88ee:	xor    %edx,%edx
 29d88f0:	test   $0x1,%esi
 29d88f6:	jne    29d8929 <wasm[0]::function[1010]::helper::array_packed_push1+0x1c9>
 29d88fc:	mov    0x28(%rbx),%r8
 29d8900:	mov    0x20(%rbx),%r9
 29d8904:	mov    %esi,%r10d
 29d8907:	lea    0x4(%r9,%r10,1),%rdi
 29d890c:	cmp    %r8,%r10
 29d890f:	cmova  %rcx,%rdi
 29d8913:	mov    (%rdi),%r9d
 29d8916:	mov    0x28(%r14),%r10
 29d891a:	cmp    0x254(%r10),%r9d
 29d8921:	sete   %r10b
 29d8925:	movzbl %r10b,%edx
 29d8929:	xor    %edi,%edi
 29d892b:	test   %edx,%edx
 29d892d:	jne    29d8943 <wasm[0]::function[1010]::helper::array_packed_push1+0x1e3>
 29d8933:	mov    %rdi,%rdx
 29d8936:	mov    %r15,%r12
 29d8939:	mov    %rcx,0x68(%rsp)
 29d893e:	jmp    29d9083 <wasm[0]::function[1010]::helper::array_packed_push1+0x923>
 29d8943:	mov    0x20(%rsp),%edx
 29d8947:	xor    %eax,%eax
 29d8949:	test   %edx,%edx
 29d894b:	je     29d8987 <wasm[0]::function[1010]::helper::array_packed_push1+0x227>
 29d8951:	xor    %eax,%eax
 29d8953:	test   $0x1,%edx
 29d8959:	jne    29d8987 <wasm[0]::function[1010]::helper::array_packed_push1+0x227>
 29d895f:	mov    0x28(%rbx),%rax
 29d8963:	mov    0x20(%rbx),%rsi
 29d8967:	mov    %edx,%edi
 29d8969:	lea    0x4(%rsi,%rdi,1),%rsi
 29d896e:	cmp    %rax,%rdi
 29d8971:	cmova  %rcx,%rsi
 29d8975:	mov    (%rsi),%eax
 29d8977:	mov    0x28(%r14),%rsi
 29d897b:	cmp    0x254(%rsi),%eax
 29d8981:	sete   %al
 29d8984:	movzbl %al,%eax
 29d8987:	test   %eax,%eax
 29d8989:	je     29d9185 <wasm[0]::function[1010]::helper::array_packed_push1+0xa25>
 29d898f:	test   %edx,%edx
 29d8991:	je     29d9187 <wasm[0]::function[1010]::helper::array_packed_push1+0xa27>
 29d8997:	test   %edx,%edx
 29d8999:	je     29d9189 <wasm[0]::function[1010]::helper::array_packed_push1+0xa29>
 29d899f:	mov    0x28(%rbx),%rax
 29d89a3:	mov    0x20(%rbx),%rsi
 29d89a7:	mov    %edx,%edi
 29d89a9:	lea    (%rsi,%rdi,1),%rdx
 29d89ad:	cmp    %rax,%rdi
 29d89b0:	cmova  %rcx,%rdx
 29d89b4:	mov    0x14(%rdx),%eax
 29d89b7:	mov    0x18(%rdx),%rdx
 29d89bb:	xor    %edi,%edi
 29d89bd:	cmp    %r15,%rdx
 29d89c0:	je     29d89d6 <wasm[0]::function[1010]::helper::array_packed_push1+0x276>
 29d89c6:	mov    %rdi,%rdx
 29d89c9:	mov    %r15,%r12
 29d89cc:	mov    %rcx,0x68(%rsp)
 29d89d1:	jmp    29d9083 <wasm[0]::function[1010]::helper::array_packed_push1+0x923>
 29d89d6:	xor    %edi,%edi
 29d89d8:	test   %eax,%eax
 29d89da:	je     29d918b <wasm[0]::function[1010]::helper::array_packed_push1+0xa2b>
 29d89e0:	test   %eax,%eax
 29d89e2:	je     29d918d <wasm[0]::function[1010]::helper::array_packed_push1+0xa2d>
 29d89e8:	mov    0x28(%rbx),%rdx
 29d89ec:	mov    0x20(%rbx),%r8
 29d89f0:	mov    %eax,%esi
 29d89f2:	lea    (%r8,%rsi,1),%rax
 29d89f6:	cmp    %rdx,%rsi
 29d89f9:	cmova  %rcx,%rax
 29d89fd:	mov    0x24(%rax),%edx
 29d8a00:	cmp    $0x2,%edx
 29d8a03:	sete   %al
 29d8a06:	cmp    $0x3,%edx
 29d8a09:	sete   %dl
 29d8a0c:	or     %edx,%eax
 29d8a0e:	movzbl %al,%eax
 29d8a11:	test   %eax,%eax
 29d8a13:	jne    29d8a29 <wasm[0]::function[1010]::helper::array_packed_push1+0x2c9>
 29d8a19:	mov    %rdi,%rdx
 29d8a1c:	mov    %r15,%r12
 29d8a1f:	mov    %rcx,0x68(%rsp)
 29d8a24:	jmp    29d9083 <wasm[0]::function[1010]::helper::array_packed_push1+0x923>
 29d8a29:	lea    0x1(%r15),%rax
 29d8a2d:	xor    %edi,%edi
 29d8a2f:	cmp    0x78a(%rip),%rax        # 29d91c0 <wasm[0]::function[1010]::helper::array_packed_push1+0xa60>
 29d8a36:	jbe    29d8a4c <wasm[0]::function[1010]::helper::array_packed_push1+0x2ec>
 29d8a3c:	mov    %rdi,%rdx
 29d8a3f:	mov    %r15,%r12
 29d8a42:	mov    %rcx,0x68(%rsp)
 29d8a47:	jmp    29d9083 <wasm[0]::function[1010]::helper::array_packed_push1+0x923>
 29d8a4c:	mov    0x20(%rsp),%eax
 29d8a50:	xor    %edi,%edi
 29d8a52:	test   %eax,%eax
 29d8a54:	je     29d918f <wasm[0]::function[1010]::helper::array_packed_push1+0xa2f>
 29d8a5a:	test   %eax,%eax
 29d8a5c:	je     29d9191 <wasm[0]::function[1010]::helper::array_packed_push1+0xa31>
 29d8a62:	mov    0x28(%rbx),%rdx
 29d8a66:	mov    %eax,%r8d
 29d8a69:	mov    %r8,%rax
 29d8a6c:	add    0x20(%rbx),%rax
 29d8a70:	cmp    %rdx,%r8
 29d8a73:	cmova  %rcx,%rax
 29d8a77:	mov    0x20(%rax),%eax
 29d8a7a:	test   %eax,%eax
 29d8a7c:	jne    29d8a92 <wasm[0]::function[1010]::helper::array_packed_push1+0x332>
 29d8a82:	mov    %rdi,%rdx
 29d8a85:	mov    %r15,%r12
 29d8a88:	mov    %rcx,0x68(%rsp)
 29d8a8d:	jmp    29d9083 <wasm[0]::function[1010]::helper::array_packed_push1+0x923>
 29d8a92:	mov    0x20(%rsp),%r8d
 29d8a97:	xor    %edi,%edi
 29d8a99:	test   %r8d,%r8d
 29d8a9c:	je     29d9193 <wasm[0]::function[1010]::helper::array_packed_push1+0xa33>
 29d8aa2:	test   %r8d,%r8d
 29d8aa5:	je     29d9195 <wasm[0]::function[1010]::helper::array_packed_push1+0xa35>
 29d8aab:	mov    0x28(%rbx),%rax
 29d8aaf:	mov    0x20(%rbx),%rdx
 29d8ab3:	mov    %r8d,%r9d
 29d8ab6:	lea    (%rdx,%r9,1),%r8
 29d8aba:	cmp    %rax,%r9
 29d8abd:	cmova  %rcx,%r8
 29d8ac1:	mov    0x10(%r8),%r8d
 29d8ac5:	test   %r8d,%r8d
 29d8ac8:	je     29d9197 <wasm[0]::function[1010]::helper::array_packed_push1+0xa37>
 29d8ace:	test   %r8d,%r8d
 29d8ad1:	je     29d9199 <wasm[0]::function[1010]::helper::array_packed_push1+0xa39>
 29d8ad7:	mov    %r8d,%r8d
 29d8ada:	add    %r8,%rdx
 29d8add:	cmp    %rax,%r8
 29d8ae0:	cmova  %rcx,%rdx
 29d8ae4:	mov    0x1c(%rdx),%edx
 29d8ae7:	test   %edx,%edx
 29d8ae9:	jne    29d8aff <wasm[0]::function[1010]::helper::array_packed_push1+0x39f>
 29d8aef:	mov    %rdi,%rdx
 29d8af2:	mov    %r15,%r12
 29d8af5:	mov    %rcx,0x68(%rsp)
 29d8afa:	jmp    29d9083 <wasm[0]::function[1010]::helper::array_packed_push1+0x923>
 29d8aff:	mov    0x28(%rbx),%r8
 29d8b03:	mov    %rsi,%rdi
 29d8b06:	add    0x20(%rbx),%rdi
 29d8b0a:	cmp    %r8,%rsi
 29d8b0d:	cmova  %rcx,%rdi
 29d8b11:	mov    0x18(%rdi),%rsi
 29d8b15:	xor    %edi,%edi
 29d8b17:	cmp    %r15,%rsi
 29d8b1a:	mov    %r15,0x88(%rsp)
 29d8b22:	je     29d8b3d <wasm[0]::function[1010]::helper::array_packed_push1+0x3dd>
 29d8b28:	mov    %rdi,%rdx
 29d8b2b:	mov    0x88(%rsp),%r12
 29d8b33:	mov    %rcx,0x68(%rsp)
 29d8b38:	jmp    29d9083 <wasm[0]::function[1010]::helper::array_packed_push1+0x923>
 29d8b3d:	mov    0x20(%rsp),%edx
 29d8b41:	xor    %eax,%eax
 29d8b43:	mov    %rax,0x60(%rsp)
 29d8b48:	test   %edx,%edx
 29d8b4a:	je     29d919b <wasm[0]::function[1010]::helper::array_packed_push1+0xa3b>
 29d8b50:	test   %edx,%edx
 29d8b52:	je     29d919d <wasm[0]::function[1010]::helper::array_packed_push1+0xa3d>
 29d8b58:	mov    0x28(%rbx),%rax
 29d8b5c:	mov    0x20(%rbx),%rsi
 29d8b60:	mov    %edx,%r8d
 29d8b63:	lea    (%rsi,%r8,1),%rdi
 29d8b67:	cmp    %rax,%r8
 29d8b6a:	cmova  %rcx,%rdi
 29d8b6e:	mov    0x10(%rdi),%edi
 29d8b71:	test   %edi,%edi
 29d8b73:	je     29d919f <wasm[0]::function[1010]::helper::array_packed_push1+0xa3f>
 29d8b79:	mov    %edi,%edi
 29d8b7b:	add    %rdi,%rsi
 29d8b7e:	cmp    %rax,%rdi
 29d8b81:	cmova  %rcx,%rsi
 29d8b85:	mov    %rcx,0x68(%rsp)
 29d8b8a:	mov    0x10(%rsi),%edi
 29d8b8d:	mov    0x18(%rsp),%esi
 29d8b91:	mov    $0x1,%r12d
 29d8b97:	mov    %r12,0x80(%rsp)
 29d8b9f:	mov    0x28(%r14),%rax
 29d8ba3:	mov    0x254(%rax),%r12d
 29d8baa:	mov    %r12,0x78(%rsp)
 29d8baf:	mov    0x138(%rax),%r13d
 29d8bb6:	mov    %r13,0x70(%rsp)
 29d8bbb:	mov    0x60(%rsp),%r8
 29d8bc0:	mov    %edi,0x28(%rsp)
 29d8bc4:	mov    %edx,0x10(%rsp)
 29d8bc8:	mov    %esi,0x18(%rsp)
 29d8bcc:	mov    %r8d,0x20(%rsp)
 29d8bd1:	mov    0x90(%rsp),%rax
 29d8bd9:	mov    (%rax),%rcx
 29d8bdc:	mov    0x58(%rsp),%rax
 29d8be1:	cmp    %rax,%rcx
 29d8be4:	jae    29d9132 <wasm[0]::function[1010]::helper::array_packed_push1+0x9d2>
 29d8bea:	mov    %rax,0x58(%rsp)
 29d8bef:	jmp    29d8bf9 <wasm[0]::function[1010]::helper::array_packed_push1+0x499>
 29d8bf4:	mov    %rax,0x58(%rsp)
 29d8bf9:	mov    0x28(%rsp),%eax
 29d8bfd:	test   %eax,%eax
 29d8bff:	je     29d8fda <wasm[0]::function[1010]::helper::array_packed_push1+0x87a>
 29d8c05:	mov    0x10(%rsp),%edx
 29d8c09:	mov    %rdx,%r11
 29d8c0c:	mov    0x18(%rsp),%esi
 29d8c10:	mov    0x20(%rsp),%edi
 29d8c14:	xor    %r13d,%r13d
 29d8c17:	mov    0x60(%rsp),%rax
 29d8c1c:	cmp    $0x8,%eax
 29d8c1f:	jb     29d8c3b <wasm[0]::function[1010]::helper::array_packed_push1+0x4db>
 29d8c25:	mov    %r11,%rcx
 29d8c28:	mov    %rdi,%rdx
 29d8c2b:	mov    %r14,%r10
 29d8c2e:	mov    0x88(%rsp),%r12
 29d8c36:	jmp    29d8fff <wasm[0]::function[1010]::helper::array_packed_push1+0x89f>
 29d8c3b:	mov    0x28(%rsp),%eax
 29d8c3f:	xor    %edx,%edx
 29d8c41:	test   %eax,%eax
 29d8c43:	jne    29d8c53 <wasm[0]::function[1010]::helper::array_packed_push1+0x4f3>
 29d8c49:	mov    0x68(%rsp),%rcx
 29d8c4e:	jmp    29d8c9d <wasm[0]::function[1010]::helper::array_packed_push1+0x53d>
 29d8c53:	mov    0x28(%rsp),%eax
 29d8c57:	xor    %edx,%edx
 29d8c59:	test   $0x1,%eax
 29d8c5e:	je     29d8c6e <wasm[0]::function[1010]::helper::array_packed_push1+0x50e>
 29d8c64:	mov    0x68(%rsp),%rcx
 29d8c69:	jmp    29d8c9d <wasm[0]::function[1010]::helper::array_packed_push1+0x53d>
 29d8c6e:	mov    0x28(%rsp),%ecx
 29d8c72:	mov    0x28(%rbx),%rax
 29d8c76:	mov    0x20(%rbx),%rdx
 29d8c7a:	mov    %ecx,%ecx
 29d8c7c:	lea    0x4(%rdx,%rcx,1),%rdx
 29d8c81:	cmp    %rax,%rcx
 29d8c84:	mov    0x68(%rsp),%rcx
 29d8c89:	cmova  %rcx,%rdx
 29d8c8d:	mov    (%rdx),%eax
 29d8c8f:	mov    0x78(%rsp),%r13
 29d8c94:	cmp    %r13d,%eax
 29d8c97:	sete   %al
 29d8c9a:	movzbl %al,%edx
 29d8c9d:	test   %edx,%edx
 29d8c9f:	jne    29d8e8c <wasm[0]::function[1010]::helper::array_packed_push1+0x72c>
 29d8ca5:	mov    0x28(%rsp),%eax
 29d8ca9:	xor    %edx,%edx
 29d8cab:	test   %eax,%eax
 29d8cad:	je     29d8cee <wasm[0]::function[1010]::helper::array_packed_push1+0x58e>
 29d8cb3:	mov    0x28(%rsp),%eax
 29d8cb7:	xor    %edx,%edx
 29d8cb9:	test   $0x1,%eax
 29d8cbe:	jne    29d8cee <wasm[0]::function[1010]::helper::array_packed_push1+0x58e>
 29d8cc4:	mov    0x28(%rsp),%edx
 29d8cc8:	mov    0x28(%rbx),%rax
 29d8ccc:	mov    0x20(%rbx),%rsi
 29d8cd0:	mov    %edx,%edi
 29d8cd2:	lea    0x4(%rsi,%rdi,1),%rdx
 29d8cd7:	cmp    %rax,%rdi
 29d8cda:	cmova  %rcx,%rdx
 29d8cde:	mov    (%rdx),%eax
 29d8ce0:	mov    0x70(%rsp),%r13
 29d8ce5:	cmp    %r13d,%eax
 29d8ce8:	sete   %al
 29d8ceb:	movzbl %al,%edx
 29d8cee:	mov    0x10(%rsp),%eax
 29d8cf2:	mov    %rax,%r11
 29d8cf5:	mov    0x18(%rsp),%esi
 29d8cf9:	mov    0x20(%rsp),%edi
 29d8cfd:	xor    %r13d,%r13d
 29d8d00:	test   %edx,%edx
 29d8d02:	jne    29d8d23 <wasm[0]::function[1010]::helper::array_packed_push1+0x5c3>
 29d8d08:	mov    %rcx,0x68(%rsp)
 29d8d0d:	mov    0x88(%rsp),%r12
 29d8d15:	mov    %r14,%r10
 29d8d18:	mov    %rdi,%rdx
 29d8d1b:	mov    %r11,%rcx
 29d8d1e:	jmp    29d8fff <wasm[0]::function[1010]::helper::array_packed_push1+0x89f>
 29d8d23:	mov    0x28(%rsp),%eax
 29d8d27:	xor    %edx,%edx
 29d8d29:	test   %eax,%eax
 29d8d2b:	jne    29d8d3b <wasm[0]::function[1010]::helper::array_packed_push1+0x5db>
 29d8d31:	mov    %rcx,0x68(%rsp)
 29d8d36:	jmp    29d8d85 <wasm[0]::function[1010]::helper::array_packed_push1+0x625>
 29d8d3b:	mov    0x28(%rsp),%eax
 29d8d3f:	xor    %edx,%edx
 29d8d41:	test   $0x1,%eax
 29d8d46:	je     29d8d56 <wasm[0]::function[1010]::helper::array_packed_push1+0x5f6>
 29d8d4c:	mov    %rcx,0x68(%rsp)
 29d8d51:	jmp    29d8d85 <wasm[0]::function[1010]::helper::array_packed_push1+0x625>
 29d8d56:	mov    0x28(%rsp),%edx
 29d8d5a:	mov    0x28(%rbx),%rax
 29d8d5e:	mov    0x20(%rbx),%rsi
 29d8d62:	mov    %edx,%edi
 29d8d64:	lea    0x4(%rsi,%rdi,1),%rdx
 29d8d69:	cmp    %rax,%rdi
 29d8d6c:	cmova  %rcx,%rdx
 29d8d70:	mov    %rcx,0x68(%rsp)
 29d8d75:	mov    (%rdx),%ecx
 29d8d77:	mov    0x70(%rsp),%r13
 29d8d7c:	cmp    %r13d,%ecx
 29d8d7f:	sete   %dl
 29d8d82:	movzbl %dl,%edx
 29d8d85:	test   %edx,%edx
 29d8d87:	je     29d91a1 <wasm[0]::function[1010]::helper::array_packed_push1+0xa41>
 29d8d8d:	mov    0x10(%rsp),%edx
 29d8d91:	mov    %rdx,%r11
 29d8d94:	mov    0x18(%rsp),%esi
 29d8d98:	mov    0x20(%rsp),%edi
 29d8d9c:	mov    0x88(%rsp),%r15
 29d8da4:	mov    %edx,0x30(%rsp)
 29d8da8:	mov    %esi,0x38(%rsp)
 29d8dac:	mov    %rdi,%rdx
 29d8daf:	mov    %edx,0x40(%rsp)
 29d8db3:	mov    0x90(%rsp),%rcx
 29d8dbb:	mov    (%rcx),%r9
 29d8dbe:	mov    0x58(%rsp),%rax
 29d8dc3:	cmp    %rax,%r9
 29d8dc6:	jae    29d9151 <wasm[0]::function[1010]::helper::array_packed_push1+0x9f1>
 29d8dcc:	mov    0x88(%rsp),%r12
 29d8dd4:	jmp    29d8de1 <wasm[0]::function[1010]::helper::array_packed_push1+0x681>
 29d8dd9:	mov    0x88(%rsp),%r12
 29d8de1:	lea    0x1(%r12),%rax
 29d8de6:	cmp    %rax,%r15
 29d8de9:	jae    29d8e6e <wasm[0]::function[1010]::helper::array_packed_push1+0x70e>
 29d8def:	xor    %r13d,%r13d
 29d8df2:	mov    %r13,%rcx
 29d8df5:	mov    %r15,%rdx
 29d8df8:	mov    %r14,%rsi
 29d8dfb:	mov    %r14,%rdi
 29d8dfe:	call   2ae5860 <wasm[0]::function[1058]::helper::integer_decimal_string>
 29d8e03:	test   %eax,%eax
 29d8e05:	je     29d91a3 <wasm[0]::function[1010]::helper::array_packed_push1+0xa43>
 29d8e0b:	mov    0x28(%rsp),%edx
 29d8e0f:	test   %edx,%edx
 29d8e11:	je     29d91a5 <wasm[0]::function[1010]::helper::array_packed_push1+0xa45>
 29d8e17:	mov    $0x4,%ecx
 29d8e1c:	mov    %rax,%r9
 29d8e1f:	mov    %r14,%rsi
 29d8e22:	mov    %r14,%rdi
 29d8e25:	mov    0x68(%rsp),%r8
 29d8e2a:	call   29ffc60 <wasm[0]::function[1019]::helper::ordinary_own_descriptor>
 29d8e2f:	mov    %r14,%r10
 29d8e32:	mov    0x30(%rsp),%edx
 29d8e36:	mov    %rdx,%r11
 29d8e39:	mov    0x38(%rsp),%esi
 29d8e3d:	mov    0x40(%rsp),%edx
 29d8e41:	test   %eax,%eax
 29d8e43:	je     29d8e51 <wasm[0]::function[1010]::helper::array_packed_push1+0x6f1>
 29d8e49:	mov    %r11,%rcx
 29d8e4c:	jmp    29d8fff <wasm[0]::function[1010]::helper::array_packed_push1+0x89f>
 29d8e51:	add    $0x1,%r15
 29d8e58:	mov    %r12,0x88(%rsp)
 29d8e60:	mov    %r10,%r14
 29d8e63:	mov    %rdx,%rdi
 29d8e66:	mov    %r11,%rdx
 29d8e69:	jmp    29d8da4 <wasm[0]::function[1010]::helper::array_packed_push1+0x644>
 29d8e6e:	mov    %r14,%r10
 29d8e71:	mov    0x28(%rsp),%edi
 29d8e75:	mov    0x30(%rsp),%edx
 29d8e79:	mov    0x38(%rsp),%esi
 29d8e7d:	mov    0x40(%rsp),%r8d
 29d8e82:	mov    0x78(%rsp),%rcx
 29d8e87:	jmp    29d8f90 <wasm[0]::function[1010]::helper::array_packed_push1+0x830>
 29d8e8c:	mov    %r14,%r10
 29d8e8f:	mov    0x88(%rsp),%r12
 29d8e97:	mov    %rcx,0x68(%rsp)
 29d8e9c:	mov    0x28(%rsp),%eax
 29d8ea0:	xor    %edx,%edx
 29d8ea2:	test   %eax,%eax
 29d8ea4:	jne    29d8eb4 <wasm[0]::function[1010]::helper::array_packed_push1+0x754>
 29d8eaa:	mov    0x78(%rsp),%rcx
 29d8eaf:	jmp    29d8efd <wasm[0]::function[1010]::helper::array_packed_push1+0x79d>
 29d8eb4:	mov    0x28(%rsp),%eax
 29d8eb8:	xor    %edx,%edx
 29d8eba:	test   $0x1,%eax
 29d8ebf:	je     29d8ecf <wasm[0]::function[1010]::helper::array_packed_push1+0x76f>
 29d8ec5:	mov    0x78(%rsp),%rcx
 29d8eca:	jmp    29d8efd <wasm[0]::function[1010]::helper::array_packed_push1+0x79d>
 29d8ecf:	mov    0x28(%rsp),%ecx
 29d8ed3:	mov    0x28(%rbx),%rax
 29d8ed7:	mov    0x20(%rbx),%rdx
 29d8edb:	mov    %ecx,%esi
 29d8edd:	lea    0x4(%rdx,%rsi,1),%rcx
 29d8ee2:	cmp    %rax,%rsi
 29d8ee5:	mov    0x68(%rsp),%rax
 29d8eea:	cmova  %rax,%rcx
 29d8eee:	mov    (%rcx),%eax
 29d8ef0:	mov    0x78(%rsp),%rcx
 29d8ef5:	cmp    %ecx,%eax
 29d8ef7:	sete   %al
 29d8efa:	movzbl %al,%edx
 29d8efd:	test   %edx,%edx
 29d8eff:	je     29d91a7 <wasm[0]::function[1010]::helper::array_packed_push1+0xa47>
 29d8f05:	mov    0x28(%rsp),%esi
 29d8f09:	xor    %r13d,%r13d
 29d8f0c:	test   %esi,%esi
 29d8f0e:	je     29d91a9 <wasm[0]::function[1010]::helper::array_packed_push1+0xa49>
 29d8f14:	test   %esi,%esi
 29d8f16:	je     29d91ab <wasm[0]::function[1010]::helper::array_packed_push1+0xa4b>
 29d8f1c:	mov    0x28(%rbx),%rdx
 29d8f20:	mov    0x20(%rbx),%rdi
 29d8f24:	mov    %esi,%eax
 29d8f26:	lea    (%rdi,%rax,1),%rsi
 29d8f2a:	cmp    %rdx,%rax
 29d8f2d:	mov    0x68(%rsp),%r8
 29d8f32:	cmova  %r8,%rsi
 29d8f36:	mov    0x14(%rsi),%eax
 29d8f39:	test   %eax,%eax
 29d8f3b:	je     29d91ad <wasm[0]::function[1010]::helper::array_packed_push1+0xa4d>
 29d8f41:	test   %eax,%eax
 29d8f43:	je     29d91af <wasm[0]::function[1010]::helper::array_packed_push1+0xa4f>
 29d8f49:	mov    %eax,%r8d
 29d8f4c:	lea    (%rdi,%r8,1),%rax
 29d8f50:	cmp    %rdx,%r8
 29d8f53:	mov    0x68(%rsp),%r11
 29d8f58:	cmova  %r11,%rax
 29d8f5c:	mov    0x18(%rax),%rax
 29d8f60:	mov    0x10(%rsi),%edi
 29d8f63:	mov    0x10(%rsp),%edx
 29d8f67:	mov    %rdx,%r11
 29d8f6a:	mov    0x18(%rsp),%esi
 29d8f6e:	mov    0x20(%rsp),%edx
 29d8f72:	test   %rax,%rax
 29d8f75:	je     29d8f83 <wasm[0]::function[1010]::helper::array_packed_push1+0x823>
 29d8f7b:	mov    %r11,%rcx
 29d8f7e:	jmp    29d8fff <wasm[0]::function[1010]::helper::array_packed_push1+0x89f>
 29d8f83:	mov    0x10(%rsp),%edx
 29d8f87:	mov    0x18(%rsp),%esi
 29d8f8b:	mov    0x20(%rsp),%r8d
 29d8f90:	test   %edi,%edi
 29d8f92:	je     29d91b1 <wasm[0]::function[1010]::helper::array_packed_push1+0xa51>
 29d8f98:	mov    0x28(%rbx),%rax
 29d8f9c:	mov    %edi,%r9d
 29d8f9f:	mov    %r9,%rdi
 29d8fa2:	add    0x20(%rbx),%rdi
 29d8fa6:	cmp    %rax,%r9
 29d8fa9:	mov    0x68(%rsp),%rax
 29d8fae:	cmova  %rax,%rdi
 29d8fb2:	mov    0x10(%rdi),%edi
 29d8fb5:	mov    0x60(%rsp),%rax
 29d8fba:	add    $0x1,%eax
 29d8fc0:	mov    %rax,0x60(%rsp)
 29d8fc5:	mov    %r10,%r14
 29d8fc8:	mov    %rcx,0x78(%rsp)
 29d8fcd:	mov    %r12,0x88(%rsp)
 29d8fd5:	jmp    29d8bc0 <wasm[0]::function[1010]::helper::array_packed_push1+0x460>
 29d8fda:	mov    %r14,%r10
 29d8fdd:	mov    0x88(%rsp),%r12
 29d8fe5:	mov    0x10(%rsp),%edx
 29d8fe9:	mov    %rdx,%r11
 29d8fec:	mov    0x18(%rsp),%esi
 29d8ff0:	mov    0x20(%rsp),%edx
 29d8ff4:	mov    %r11,%rcx
 29d8ff7:	mov    0x80(%rsp),%r13
 29d8fff:	mov    %ecx,0x18(%rsp)
 29d9003:	mov    %edx,0x10(%rsp)
 29d9007:	xor    %edi,%edi
 29d9009:	test   %r13d,%r13d
 29d900c:	je     29d9083 <wasm[0]::function[1010]::helper::array_packed_push1+0x923>
 29d9012:	mov    %r11,%rdx
 29d9015:	mov    %r11,%r9
 29d9018:	test   %r9d,%edx
 29d901b:	je     29d91b3 <wasm[0]::function[1010]::helper::array_packed_push1+0xa53>
 29d9021:	mov    %esi,(%rsp)
 29d9024:	mov    %r10,%rsi
 29d9027:	mov    0x48(%rsp),%r8
 29d902c:	mov    0x50(%rsp),%r9
 29d9031:	mov    %r12,%rcx
 29d9034:	mov    %rsi,%rdi
 29d9037:	call   29d4760 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data>
 29d903c:	sub    $0x10,%rsp
 29d9040:	mov    0x18(%rsp),%esi
 29d9044:	test   %esi,%esi
 29d9046:	je     29d91b5 <wasm[0]::function[1010]::helper::array_packed_push1+0xa55>
 29d904c:	test   %esi,%esi
 29d904e:	je     29d91b7 <wasm[0]::function[1010]::helper::array_packed_push1+0xa57>
 29d9054:	mov    0x28(%rbx),%r8
 29d9058:	lea    0x1(%r12),%rdi
 29d905d:	mov    %esi,%r9d
 29d9060:	mov    %r9,%rsi
 29d9063:	add    0x20(%rbx),%rsi
 29d9067:	cmp    %r8,%r9
 29d906a:	mov    0x68(%rsp),%rcx
 29d906f:	cmova  %rcx,%rsi
 29d9073:	mov    %rdi,0x18(%rsi)
 29d9077:	mov    0x10(%rsp),%edx
 29d907b:	mov    0x80(%rsp),%rdi
 29d9083:	xor    %eax,%eax
 29d9085:	test   %edi,%edi
 29d9087:	jne    29d9098 <wasm[0]::function[1010]::helper::array_packed_push1+0x938>
 29d908d:	mov    %rax,%rsi
 29d9090:	mov    %rax,%rdi
 29d9093:	jmp    29d90e2 <wasm[0]::function[1010]::helper::array_packed_push1+0x982>
 29d9098:	mov    $0x3,%eax
 29d909d:	lea    0x1(%r12),%rcx
 29d90a2:	cmp    $0x0,%rcx
 29d90a6:	jl     29d90b6 <wasm[0]::function[1010]::helper::array_packed_push1+0x956>
 29d90ac:	cvtsi2sd %rcx,%xmm0
 29d90b1:	jmp    29d90d0 <wasm[0]::function[1010]::helper::array_packed_push1+0x970>
 29d90b6:	mov    %rcx,%rsi
 29d90b9:	shr    $0x1,%rsi
 29d90bd:	mov    %rcx,%rdx
 29d90c0:	and    $0x1,%rdx
 29d90c4:	or     %rsi,%rdx
 29d90c7:	cvtsi2sd %rdx,%xmm0
 29d90cc:	addsd  %xmm0,%xmm0
 29d90d0:	movq   %xmm0,%rcx
 29d90d5:	mov    %rcx,0x68(%rsp)
 29d90da:	xor    %edx,%edx
 29d90dc:	mov    %rdx,%rsi
 29d90df:	mov    %rdx,%rdi
 29d90e2:	mov    0x68(%rsp),%rcx
 29d90e7:	mov    0xa0(%rsp),%rbx
 29d90ef:	mov    0xa8(%rsp),%r12
 29d90f7:	mov    0xb0(%rsp),%r13
 29d90ff:	mov    0xb8(%rsp),%r14
 29d9107:	mov    0xc0(%rsp),%r15
 29d910f:	add    $0xd0,%rsp
 29d9116:	mov    %rbp,%rsp
 29d9119:	pop    %rbp
 29d911a:	ret    $0x10
 29d911d:	mov    %r10,%r14
 29d9120:	mov    %r14,%rdi
 29d9123:	call   3018b79 <wasmtime_builtin_new_epoch>
 29d9128:	mov    %rax,0x58(%rsp)
 29d912d:	jmp    29d87f1 <wasm[0]::function[1010]::helper::array_packed_push1+0x91>
 29d9132:	mov    0x8(%rbx),%rax
 29d9136:	cmp    %rax,%rcx
 29d9139:	jb     29d8bf4 <wasm[0]::function[1010]::helper::array_packed_push1+0x494>
 29d913f:	mov    %r14,%rdi
 29d9142:	call   3018b79 <wasmtime_builtin_new_epoch>
 29d9147:	mov    %rax,0x58(%rsp)
 29d914c:	jmp    29d8bf9 <wasm[0]::function[1010]::helper::array_packed_push1+0x499>
 29d9151:	mov    0x8(%rbx),%rax
 29d9155:	mov    %rax,0x58(%rsp)
 29d915a:	cmp    %rax,%r9
 29d915d:	jb     29d8dd9 <wasm[0]::function[1010]::helper::array_packed_push1+0x679>
 29d9163:	mov    %r14,%rdi
 29d9166:	call   3018b79 <wasmtime_builtin_new_epoch>
 29d916b:	mov    %rax,0x58(%rsp)
 29d9170:	mov    0x88(%rsp),%r12
 29d9178:	jmp    29d8de1 <wasm[0]::function[1010]::helper::array_packed_push1+0x681>
 29d917d:	ud2
 29d917f:	ud2
 29d9181:	ud2
 29d9183:	ud2
 29d9185:	ud2
 29d9187:	ud2
 29d9189:	ud2
 29d918b:	ud2
 29d918d:	ud2
 29d918f:	ud2
 29d9191:	ud2
 29d9193:	ud2
 29d9195:	ud2
 29d9197:	ud2
 29d9199:	ud2
 29d919b:	ud2
 29d919d:	ud2
 29d919f:	ud2
 29d91a1:	ud2
 29d91a3:	ud2
 29d91a5:	ud2
 29d91a7:	ud2
 29d91a9:	ud2
 29d91ab:	ud2
 29d91ad:	ud2
 29d91af:	ud2
 29d91b1:	ud2
 29d91b3:	ud2
 29d91b5:	ud2
 29d91b7:	ud2
 29d91b9:	add    %al,(%rax)
 29d91bb:	add    %al,(%rax)
 29d91bd:	add    %al,(%rax)
 29d91bf:	add    %bh,%bh
 29d91c1:	(bad)
 29d91c2:	(bad)
 29d91c3:	incl   (%rax)
 29d91c5:	add    %al,(%rax)
	...
