
/workspace/scriptw/target/performance-dense-numbers-20261030/v2/native-cause/baseline/runtime-portable.elf:     file format elf64-x86-64


Disassembly of section .text:

00000000029d4760 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data>:
 29d4760:	push   %rbp
 29d4761:	mov    %rsp,%rbp
 29d4764:	mov    0x8(%rdi),%r10
 29d4768:	mov    0x18(%r10),%r10
 29d476c:	add    $0x120,%r10
 29d4773:	cmp    %rsp,%r10
 29d4776:	ja     29d6d1a <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25ba>
 29d477c:	sub    $0x110,%rsp
 29d4783:	mov    %rbx,0xe0(%rsp)
 29d478b:	mov    %r12,0xe8(%rsp)
 29d4793:	mov    %r13,0xf0(%rsp)
 29d479b:	mov    %r14,0xf8(%rsp)
 29d47a3:	mov    %r15,0x100(%rsp)
 29d47ab:	mov    %rcx,0x68(%rsp)
 29d47b0:	mov    %r8,0x70(%rsp)
 29d47b5:	mov    %r9,0x78(%rsp)
 29d47ba:	mov    0x10(%rbp),%rsi
 29d47be:	mov    %edx,0x8(%rsp)
 29d47c2:	mov    %esi,0x20(%rsp)
 29d47c6:	movl   $0x0,0x28(%rsp)
 29d47ce:	mov    0x18(%rdi),%r8
 29d47d2:	mov    (%r8),%rsi
 29d47d5:	mov    %r8,0xd8(%rsp)
 29d47dd:	mov    0x8(%rdi),%r8
 29d47e1:	mov    %rdi,0x60(%rsp)
 29d47e6:	mov    0x8(%r8),%rax
 29d47ea:	mov    %r8,0xd0(%rsp)
 29d47f2:	cmp    %rax,%rsi
 29d47f5:	jae    29d6782 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2022>
 29d47fb:	mov    %rax,0x90(%rsp)
 29d4803:	mov    0x8(%rsp),%edx
 29d4807:	xor    %r10d,%r10d
 29d480a:	test   %edx,%edx
 29d480c:	je     29d6d1c <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25bc>
 29d4812:	test   %edx,%edx
 29d4814:	je     29d6d1e <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25be>
 29d481a:	mov    0xd0(%rsp),%r14
 29d4822:	mov    0x28(%r14),%rsi
 29d4826:	mov    0x20(%r14),%rdi
 29d482a:	mov    %edx,%eax
 29d482c:	xor    %rcx,%rcx
 29d482f:	mov    %rcx,0x88(%rsp)
 29d4837:	lea    (%rdi,%rax,1),%rcx
 29d483b:	cmp    %rsi,%rax
 29d483e:	mov    0x88(%rsp),%rax
 29d4846:	cmova  %rax,%rcx
 29d484a:	mov    0x14(%rcx),%eax
 29d484d:	test   %eax,%eax
 29d484f:	mov    %rax,0x80(%rsp)
 29d4857:	je     29d6d20 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25c0>
 29d485d:	mov    0x80(%rsp),%rcx
 29d4865:	test   %ecx,%eax
 29d4867:	je     29d6d22 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25c2>
 29d486d:	mov    %eax,%eax
 29d486f:	add    %rax,%rdi
 29d4872:	cmp    %rsi,%rax
 29d4875:	mov    0x88(%rsp),%r9
 29d487d:	cmova  %r9,%rdi
 29d4881:	mov    0x24(%rdi),%edi
 29d4884:	mov    0x28(%rsp),%r9d
 29d4889:	mov    0x20(%rsp),%esi
 29d488d:	cmp    $0x2,%edi
 29d4890:	sete   %dil
 29d4894:	mov    0x70(%rsp),%r15
 29d4899:	cmp    $0x3,%r15d
 29d489d:	sete   %cl
 29d48a0:	test   %dil,%cl
 29d48a3:	jne    29d48be <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x15e>
 29d48a9:	mov    0x80(%rsp),%rax
 29d48b1:	mov    %r14,0xd0(%rsp)
 29d48b9:	jmp    29d5666 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0xf06>
 29d48be:	mov    0x28(%r14),%rsi
 29d48c2:	mov    0x20(%r14),%r11
 29d48c6:	mov    %r14,0xd0(%rsp)
 29d48ce:	lea    (%r11,%rax,1),%rdx
 29d48d2:	xor    %r9,%r9
 29d48d5:	cmp    %rsi,%rax
 29d48d8:	cmova  %r9,%rdx
 29d48dc:	mov    0x28(%rdx),%r8d
 29d48e0:	mov    0x2c(%rdx),%edi
 29d48e3:	xor    %r10d,%r10d
 29d48e6:	test   %r8d,%r8d
 29d48e9:	je     29d6d24 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25c4>
 29d48ef:	test   %r8d,%r8d
 29d48f2:	je     29d6d26 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25c6>
 29d48f8:	mov    %r8d,%ebx
 29d48fb:	lea    0x10(%r11,%rbx,1),%rax
 29d4900:	cmp    %rsi,%rbx
 29d4903:	cmova  %r9,%rax
 29d4907:	mov    (%rax),%r15d
 29d490a:	mov    0x18(%rdx),%r14
 29d490e:	mov    %r14,0x88(%rsp)
 29d4916:	mov    0x28(%rsp),%r9d
 29d491b:	mov    0x20(%rsp),%esi
 29d491f:	mov    0x8(%rsp),%edx
 29d4923:	mov    %r15d,%r14d
 29d4926:	mov    0x68(%rsp),%r11
 29d492b:	cmp    %r14,%r11
 29d492e:	setb   %al
 29d4931:	cmp    $0x100000,%r11
 29d4938:	setb   %bl
 29d493b:	mov    0x88(%rsp),%rcx
 29d4943:	mov    0x88(%rsp),%r12
 29d494b:	lea    0x8(%rcx,%r12,1),%rcx
 29d4950:	cmp    %rcx,%r11
 29d4953:	setbe  %r12b
 29d4957:	and    %r12d,%ebx
 29d495a:	or     %ebx,%eax
 29d495c:	test   %al,%al
 29d495e:	jne    29d496e <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x20e>
 29d4964:	mov    %r11,0x68(%rsp)
 29d4969:	jmp    29d565e <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0xefe>
 29d496e:	mov    0x28(%rsp),%r9d
 29d4973:	mov    0x20(%rsp),%esi
 29d4977:	mov    0x8(%rsp),%edx
 29d497b:	cmp    %r14,%r11
 29d497e:	mov    %r11,0x68(%rsp)
 29d4983:	jb     29d541a <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0xcba>
 29d4989:	test   %r15d,%r15d
 29d498c:	jne    29d4998 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x238>
 29d4992:	mov    $0x4,%r15d
 29d4998:	mov    %r8d,0x30(%rsp)
 29d499d:	mov    %edi,0x58(%rsp)
 29d49a1:	mov    0x80(%rsp),%rax
 29d49a9:	mov    %eax,(%rsp)
 29d49ac:	mov    %r9d,0x8(%rsp)
 29d49b1:	mov    %esi,0x20(%rsp)
 29d49b5:	mov    %edx,0x28(%rsp)
 29d49b9:	mov    0xd8(%rsp),%r13
 29d49c1:	mov    0x0(%r13),%rax
 29d49c5:	mov    0x90(%rsp),%rcx
 29d49cd:	cmp    %rcx,%rax
 29d49d0:	jae    29d6799 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2039>
 29d49d6:	mov    %r15d,%ebx
 29d49d9:	mov    0x68(%rsp),%rcx
 29d49de:	cmp    %rbx,%rcx
 29d49e1:	jb     29d4a10 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2b0>
 29d49e7:	mov    0x30(%rsp),%r8d
 29d49ec:	mov    0x58(%rsp),%edi
 29d49f0:	mov    (%rsp),%edx
 29d49f3:	mov    %rdx,0x80(%rsp)
 29d49fb:	mov    0x8(%rsp),%r9d
 29d4a00:	mov    0x20(%rsp),%esi
 29d4a04:	mov    0x28(%rsp),%edx
 29d4a08:	shl    $1,%r15d
 29d4a0b:	jmp    29d4998 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x238>
 29d4a10:	mov    %rbx,%rcx
 29d4a13:	shl    $0x3,%rcx
 29d4a17:	mov    %rcx,%rax
 29d4a1a:	shr    $0x20,%rax
 29d4a1e:	mov    %rcx,%r12
 29d4a21:	test   %rax,%rax
 29d4a24:	jne    29d6d28 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25c8>
 29d4a2a:	mov    %r15,%rcx
 29d4a2d:	shl    $0x3,%ecx
 29d4a30:	add    $0x18,%ecx
 29d4a33:	jb     29d6d2a <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25ca>
 29d4a39:	mov    0x60(%rsp),%rax
 29d4a3e:	mov    0x20(%rax),%rdi
 29d4a42:	mov    (%rdi),%eax
 29d4a44:	mov    %eax,%edx
 29d4a46:	mov    %ecx,%esi
 29d4a48:	add    $0xf,%rsi
 29d4a4f:	mov    %rsi,%r8
 29d4a52:	and    $0xfffffffffffffff0,%r8
 29d4a56:	add    %rdx,%r8
 29d4a59:	mov    0x4(%rdi),%r9d
 29d4a5d:	mov    %rdi,0xa0(%rsp)
 29d4a65:	cmp    %r9,%r8
 29d4a68:	ja     29d67cd <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x206d>
 29d4a6e:	lea    0xf(%rcx),%edi
 29d4a71:	and    $0xfffffff0,%edi
 29d4a74:	add    %eax,%edi
 29d4a76:	mov    0xa0(%rsp),%rcx
 29d4a7e:	mov    %edi,(%rcx)
 29d4a80:	mov    0xd0(%rsp),%r13
 29d4a88:	mov    0x20(%r13),%rdi
 29d4a8c:	lea    (%rdi,%rdx,1),%rcx
 29d4a90:	movl   $0xa8000006,(%rdi,%rdx,1)
 29d4a97:	mov    0x60(%rsp),%r8
 29d4a9c:	mov    0x28(%r8),%r8
 29d4aa0:	mov    0x1a0(%r8),%r8d
 29d4aa7:	mov    %r8d,0x4(%rdi,%rdx,1)
 29d4aac:	and    $0xfffffffffffffff0,%rsi
 29d4ab0:	mov    %esi,0x8(%rdi,%rdx,1)
 29d4ab4:	mov    %eax,0x10(%rsp)
 29d4ab8:	mov    %r15d,0x10(%rcx)
 29d4abc:	test   %eax,%eax
 29d4abe:	je     29d6d2c <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25cc>
 29d4ac4:	mov    0xd0(%rsp),%r13
 29d4acc:	mov    0x28(%r13),%rcx
 29d4ad0:	mov    0x20(%r13),%rdx
 29d4ad4:	mov    %eax,%eax
 29d4ad6:	lea    0x10(%rdx,%rax,1),%r9
 29d4adb:	xor    %rsi,%rsi
 29d4ade:	cmp    %rcx,%rax
 29d4ae1:	cmova  %rsi,%r9
 29d4ae5:	mov    (%r9),%esi
 29d4ae8:	cmp    %rsi,%rbx
 29d4aeb:	ja     29d6d2e <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25ce>
 29d4af1:	lea    0x18(%rdx,%rax,1),%rsi
 29d4af6:	mov    %r12,%r9
 29d4af9:	mov    %rsi,%rax
 29d4afc:	add    %r9,%rax
 29d4aff:	mov    %rsi,%rbx
 29d4b02:	jb     29d6d30 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25d0>
 29d4b08:	add    %rdx,%rcx
 29d4b0b:	cmp    %rcx,%rax
 29d4b0e:	ja     29d6d32 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25d2>
 29d4b14:	mov    0x30(%rsp),%r8d
 29d4b19:	mov    0x58(%rsp),%edi
 29d4b1d:	mov    (%rsp),%esi
 29d4b20:	mov    0x8(%rsp),%edx
 29d4b24:	mov    0x20(%rsp),%ecx
 29d4b28:	mov    0x28(%rsp),%eax
 29d4b2c:	cmp    $0x8000000,%r9
 29d4b33:	jbe    29d4bc3 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x463>
 29d4b39:	mov    %r8d,0x28(%rsp)
 29d4b3e:	mov    %edi,0x20(%rsp)
 29d4b42:	mov    %esi,0x8(%rsp)
 29d4b46:	mov    %edx,(%rsp)
 29d4b49:	mov    %ecx,0x58(%rsp)
 29d4b4d:	mov    %eax,0x30(%rsp)
 29d4b51:	mov    0xd8(%rsp),%rax
 29d4b59:	mov    (%rax),%rax
 29d4b5c:	mov    0x90(%rsp),%rcx
 29d4b64:	cmp    %rcx,%rax
 29d4b67:	jae    29d6804 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x20a4>
 29d4b6d:	xor    %edx,%edx
 29d4b6f:	mov    $0x8000000,%ecx
 29d4b74:	mov    %rbx,%rsi
 29d4b77:	mov    0x60(%rsp),%rdi
 29d4b7c:	call   3018b23 <wasmtime_builtin_memory_fill>
 29d4b81:	mov    0x28(%rsp),%r8d
 29d4b86:	mov    0x20(%rsp),%edi
 29d4b8a:	mov    0x8(%rsp),%esi
 29d4b8e:	mov    (%rsp),%edx
 29d4b91:	mov    0x58(%rsp),%ecx
 29d4b95:	mov    0x30(%rsp),%eax
 29d4b99:	mov    %r12,%r9
 29d4b9c:	sub    $0x8000000,%r9
 29d4ba3:	mov    %r9,%r12
 29d4ba6:	mov    %rbx,%r9
 29d4ba9:	add    $0x8000000,%r9
 29d4bb0:	mov    %r9,%rbx
 29d4bb3:	mov    %r12,%r9
 29d4bb6:	cmp    $0x8000000,%r9
 29d4bbd:	ja     29d4b39 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x3d9>
 29d4bc3:	mov    %r8d,0x30(%rsp)
 29d4bc8:	mov    %edi,0x58(%rsp)
 29d4bcc:	mov    %esi,(%rsp)
 29d4bcf:	mov    %edx,0x8(%rsp)
 29d4bd3:	mov    %ecx,0x20(%rsp)
 29d4bd7:	mov    %eax,0x28(%rsp)
 29d4bdb:	mov    0xd8(%rsp),%rax
 29d4be3:	mov    (%rax),%rax
 29d4be6:	mov    0x90(%rsp),%rcx
 29d4bee:	cmp    %rcx,%rax
 29d4bf1:	jae    29d683b <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x20db>
 29d4bf7:	xor    %edx,%edx
 29d4bf9:	mov    %r12,%rcx
 29d4bfc:	mov    %rbx,%rsi
 29d4bff:	mov    0x60(%rsp),%rdi
 29d4c04:	call   3018b23 <wasmtime_builtin_memory_fill>
 29d4c09:	mov    0x10(%rsp),%edx
 29d4c0d:	test   %edx,%edx
 29d4c0f:	je     29d6d34 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25d4>
 29d4c15:	mov    0x30(%rsp),%esi
 29d4c19:	test   %esi,%esi
 29d4c1b:	je     29d6d36 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25d6>
 29d4c21:	test   %edx,%edx
 29d4c23:	je     29d6d38 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25d8>
 29d4c29:	mov    0xd0(%rsp),%r13
 29d4c31:	mov    0x28(%r13),%rcx
 29d4c35:	mov    0x20(%r13),%rax
 29d4c39:	mov    %edx,%edx
 29d4c3b:	lea    (%rax,%rdx,1),%r9
 29d4c3f:	lea    0x10(%rax,%rdx,1),%r8
 29d4c44:	xor    %rdi,%rdi
 29d4c47:	cmp    %rcx,%rdx
 29d4c4a:	cmova  %rdi,%r8
 29d4c4e:	mov    (%r8),%r8d
 29d4c51:	cmp    %r8,%r14
 29d4c54:	ja     29d6d3a <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25da>
 29d4c5a:	test   %esi,%esi
 29d4c5c:	je     29d6d3c <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25dc>
 29d4c62:	mov    %esi,%esi
 29d4c64:	lea    (%rax,%rsi,1),%r10
 29d4c68:	lea    0x10(%rax,%rsi,1),%r8
 29d4c6d:	cmp    %rcx,%rsi
 29d4c70:	cmova  %rdi,%r8
 29d4c74:	mov    (%r8),%edi
 29d4c77:	cmp    %rdi,%r14
 29d4c7a:	ja     29d6d3e <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25de>
 29d4c80:	lea    0x18(%rax,%rdx,1),%rbx
 29d4c85:	mov    %r14,%r11
 29d4c88:	shl    $0x3,%r11
 29d4c8c:	mov    %rbx,%r8
 29d4c8f:	add    %r11,%r8
 29d4c92:	jb     29d6d40 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25e0>
 29d4c98:	lea    (%rax,%rcx,1),%rdi
 29d4c9c:	cmp    %rdi,%r8
 29d4c9f:	ja     29d6d42 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25e2>
 29d4ca5:	lea    0x18(%rax,%rsi,1),%r13
 29d4caa:	mov    %r13,%r8
 29d4cad:	add    %r11,%r8
 29d4cb0:	jb     29d6d44 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25e4>
 29d4cb6:	cmp    %rdi,%r8
 29d4cb9:	ja     29d6d46 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25e6>
 29d4cbf:	cmp    %rbx,%r13
 29d4cc2:	ja     29d4dbb <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x65b>
 29d4cc8:	mov    0x58(%rsp),%eax
 29d4ccc:	mov    (%rsp),%ecx
 29d4ccf:	mov    0x10(%rsp),%edx
 29d4cd3:	mov    0x8(%rsp),%esi
 29d4cd7:	mov    0x20(%rsp),%edi
 29d4cdb:	mov    0x28(%rsp),%r8d
 29d4ce0:	lea    0x18(%r9,%r14,8),%rbx
 29d4ce5:	mov    %rbx,%r12
 29d4ce8:	lea    0x18(%r10,%r14,8),%r13
 29d4ced:	mov    %r13,%r14
 29d4cf0:	cmp    $0x8000000,%r11
 29d4cf7:	mov    %r11,%rbx
 29d4cfa:	ja     29d4d0b <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x5ab>
 29d4d00:	mov    %rbx,%r9
 29d4d03:	mov    %r12,%r10
 29d4d06:	jmp    29d4da4 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x644>
 29d4d0b:	mov    %eax,0x18(%rsp)
 29d4d0f:	mov    %ecx,0x50(%rsp)
 29d4d13:	mov    %edx,0x48(%rsp)
 29d4d17:	mov    %esi,0x40(%rsp)
 29d4d1b:	mov    %edi,0x38(%rsp)
 29d4d1f:	mov    %r8d,0x30(%rsp)
 29d4d24:	mov    0xd8(%rsp),%rax
 29d4d2c:	mov    (%rax),%rax
 29d4d2f:	mov    0x90(%rsp),%rcx
 29d4d37:	cmp    %rcx,%rax
 29d4d3a:	jae    29d686f <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x210f>
 29d4d40:	mov    $0x8000000,%ecx
 29d4d45:	mov    %r12,%rsi
 29d4d48:	sub    $0x8000000,%rsi
 29d4d4f:	mov    %r14,%rdx
 29d4d52:	mov    %rsi,%r12
 29d4d55:	sub    $0x8000000,%rdx
 29d4d5c:	mov    %rdx,%r14
 29d4d5f:	mov    0x60(%rsp),%rdi
 29d4d64:	call   3018afa <wasmtime_builtin_memory_copy>
 29d4d69:	mov    0x18(%rsp),%eax
 29d4d6d:	mov    0x50(%rsp),%ecx
 29d4d71:	mov    0x48(%rsp),%edx
 29d4d75:	mov    0x40(%rsp),%esi
 29d4d79:	mov    0x38(%rsp),%edi
 29d4d7d:	mov    0x30(%rsp),%r8d
 29d4d82:	mov    %rbx,%r9
 29d4d85:	sub    $0x8000000,%r9
 29d4d8c:	cmp    $0x8000000,%r9
 29d4d93:	jbe    29d4da1 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x641>
 29d4d99:	mov    %r9,%rbx
 29d4d9c:	jmp    29d4d0b <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x5ab>
 29d4da1:	mov    %r12,%r10
 29d4da4:	sub    %r9,%r10
 29d4da7:	mov    %r10,%r12
 29d4daa:	mov    %r14,%r10
 29d4dad:	sub    %r9,%r10
 29d4db0:	mov    %r10,%r14
 29d4db3:	mov    %r9,%rbx
 29d4db6:	jmp    29d4e84 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x724>
 29d4dbb:	mov    %r11,%r9
 29d4dbe:	mov    %rbx,%r12
 29d4dc1:	mov    %r13,%r14
 29d4dc4:	mov    0x58(%rsp),%eax
 29d4dc8:	mov    (%rsp),%ecx
 29d4dcb:	mov    0x10(%rsp),%edx
 29d4dcf:	mov    0x8(%rsp),%esi
 29d4dd3:	mov    0x20(%rsp),%edi
 29d4dd7:	mov    0x28(%rsp),%r8d
 29d4ddc:	cmp    $0x8000000,%r9
 29d4de3:	mov    %r9,%rbx
 29d4de6:	jbe    29d4e84 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x724>
 29d4dec:	mov    %eax,0x28(%rsp)
 29d4df0:	mov    %ecx,0x20(%rsp)
 29d4df4:	mov    %edx,0x8(%rsp)
 29d4df8:	mov    %esi,0x10(%rsp)
 29d4dfc:	mov    %edi,(%rsp)
 29d4dff:	mov    %r8d,0x58(%rsp)
 29d4e04:	mov    0xd8(%rsp),%rax
 29d4e0c:	mov    (%rax),%rax
 29d4e0f:	mov    0x90(%rsp),%rcx
 29d4e17:	cmp    %rcx,%rax
 29d4e1a:	jae    29d68a3 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2143>
 29d4e20:	mov    $0x8000000,%ecx
 29d4e25:	mov    %r14,%rdx
 29d4e28:	mov    %r12,%rsi
 29d4e2b:	mov    0x60(%rsp),%rdi
 29d4e30:	call   3018afa <wasmtime_builtin_memory_copy>
 29d4e35:	mov    0x28(%rsp),%eax
 29d4e39:	mov    0x20(%rsp),%ecx
 29d4e3d:	mov    0x8(%rsp),%edx
 29d4e41:	mov    0x10(%rsp),%esi
 29d4e45:	mov    (%rsp),%edi
 29d4e48:	mov    0x58(%rsp),%r8d
 29d4e4d:	mov    %rbx,%r9
 29d4e50:	sub    $0x8000000,%r9
 29d4e57:	mov    %r9,%rbx
 29d4e5a:	mov    %r12,%r9
 29d4e5d:	add    $0x8000000,%r9
 29d4e64:	mov    %r9,%r12
 29d4e67:	mov    %r14,%r9
 29d4e6a:	add    $0x8000000,%r9
 29d4e71:	mov    %r9,%r14
 29d4e74:	mov    %rbx,%r9
 29d4e77:	cmp    $0x8000000,%r9
 29d4e7e:	ja     29d4dec <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x68c>
 29d4e84:	mov    %eax,0x58(%rsp)
 29d4e88:	mov    %ecx,(%rsp)
 29d4e8b:	mov    %edx,0x10(%rsp)
 29d4e8f:	mov    %esi,0x8(%rsp)
 29d4e93:	mov    %edi,0x20(%rsp)
 29d4e97:	mov    %r8d,0x28(%rsp)
 29d4e9c:	mov    0xd8(%rsp),%rax
 29d4ea4:	mov    (%rax),%rcx
 29d4ea7:	mov    0x90(%rsp),%rax
 29d4eaf:	cmp    %rax,%rcx
 29d4eb2:	jae    29d68d7 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2177>
 29d4eb8:	mov    %rbx,%rcx
 29d4ebb:	mov    %r14,%rdx
 29d4ebe:	mov    %r12,%rsi
 29d4ec1:	jmp    29d4ecf <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x76f>
 29d4ec6:	mov    %rbx,%rcx
 29d4ec9:	mov    %r14,%rdx
 29d4ecc:	mov    %r12,%rsi
 29d4ecf:	mov    %rbx,%rcx
 29d4ed2:	mov    %r14,%rdx
 29d4ed5:	mov    %r12,%rsi
 29d4ed8:	mov    0x60(%rsp),%rdi
 29d4edd:	call   3018afa <wasmtime_builtin_memory_copy>
 29d4ee2:	lea    0x3f(%r15),%r14d
 29d4ee6:	shr    $0x6,%r14d
 29d4eea:	mov    %r14,%rcx
 29d4eed:	shl    $0x3,%rcx
 29d4ef1:	mov    %rcx,%r9
 29d4ef4:	shr    $0x20,%r9
 29d4ef8:	mov    %rcx,%rbx
 29d4efb:	test   %r9,%r9
 29d4efe:	jne    29d6d48 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25e8>
 29d4f04:	mov    %r14,%rcx
 29d4f07:	shl    $0x3,%ecx
 29d4f0a:	add    $0x18,%ecx
 29d4f0d:	jb     29d6d4a <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25ea>
 29d4f13:	mov    0xa0(%rsp),%r15
 29d4f1b:	mov    (%r15),%eax
 29d4f1e:	mov    %eax,%edx
 29d4f20:	mov    %ecx,%esi
 29d4f22:	lea    0xf(%rsi),%r11
 29d4f26:	and    $0xfffffffffffffff0,%r11
 29d4f2a:	lea    (%rdx,%r11,1),%rsi
 29d4f2e:	mov    0x4(%r15),%edi
 29d4f32:	cmp    %rdi,%rsi
 29d4f35:	ja     29d6914 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x21b4>
 29d4f3b:	add    $0xf,%ecx
 29d4f41:	and    $0xfffffff0,%ecx
 29d4f44:	add    %eax,%ecx
 29d4f46:	mov    %ecx,(%r15)
 29d4f49:	mov    0xd0(%rsp),%r13
 29d4f51:	mov    0x20(%r13),%rsi
 29d4f55:	lea    (%rsi,%rdx,1),%rcx
 29d4f59:	movl   $0xa8000006,(%rsi,%rdx,1)
 29d4f60:	mov    0x60(%rsp),%rdi
 29d4f65:	mov    0x28(%rdi),%rdi
 29d4f69:	mov    0x1a4(%rdi),%edi
 29d4f6f:	mov    %edi,0x4(%rsi,%rdx,1)
 29d4f73:	mov    %r11d,0x8(%rsi,%rdx,1)
 29d4f78:	mov    %eax,0x18(%rsp)
 29d4f7c:	mov    %r14d,0x10(%rcx)
 29d4f80:	test   %eax,%eax
 29d4f82:	je     29d6d4c <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25ec>
 29d4f88:	mov    0xd0(%rsp),%r13
 29d4f90:	mov    0x28(%r13),%rcx
 29d4f94:	mov    0x20(%r13),%rdx
 29d4f98:	mov    %eax,%eax
 29d4f9a:	lea    0x10(%rdx,%rax,1),%rsi
 29d4f9f:	xor    %rdi,%rdi
 29d4fa2:	cmp    %rcx,%rax
 29d4fa5:	cmova  %rdi,%rsi
 29d4fa9:	mov    (%rsi),%esi
 29d4fab:	cmp    %rsi,%r14
 29d4fae:	ja     29d6d4e <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25ee>
 29d4fb4:	lea    0x18(%rdx,%rax,1),%rsi
 29d4fb9:	mov    %rbx,%r9
 29d4fbc:	mov    %rsi,%rax
 29d4fbf:	add    %r9,%rax
 29d4fc2:	mov    %rsi,%r12
 29d4fc5:	jb     29d6d50 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25f0>
 29d4fcb:	add    %rdx,%rcx
 29d4fce:	cmp    %rcx,%rax
 29d4fd1:	ja     29d6d52 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25f2>
 29d4fd7:	mov    0x58(%rsp),%r8d
 29d4fdc:	mov    (%rsp),%edi
 29d4fdf:	mov    0x10(%rsp),%esi
 29d4fe3:	mov    0x8(%rsp),%edx
 29d4fe7:	mov    0x20(%rsp),%ecx
 29d4feb:	mov    0x28(%rsp),%eax
 29d4fef:	cmp    $0x8000000,%r9
 29d4ff6:	jbe    29d5086 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x926>
 29d4ffc:	mov    %r8d,0x28(%rsp)
 29d5001:	mov    %edi,0x20(%rsp)
 29d5005:	mov    %esi,0x8(%rsp)
 29d5009:	mov    %edx,0x10(%rsp)
 29d500d:	mov    %ecx,(%rsp)
 29d5010:	mov    %eax,0x58(%rsp)
 29d5014:	mov    0xd8(%rsp),%rax
 29d501c:	mov    (%rax),%rax
 29d501f:	mov    0x90(%rsp),%rcx
 29d5027:	cmp    %rcx,%rax
 29d502a:	jae    29d694b <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x21eb>
 29d5030:	xor    %edx,%edx
 29d5032:	mov    $0x8000000,%ecx
 29d5037:	mov    %r12,%rsi
 29d503a:	mov    0x60(%rsp),%rdi
 29d503f:	call   3018b23 <wasmtime_builtin_memory_fill>
 29d5044:	mov    0x28(%rsp),%r8d
 29d5049:	mov    0x20(%rsp),%edi
 29d504d:	mov    0x8(%rsp),%esi
 29d5051:	mov    0x10(%rsp),%edx
 29d5055:	mov    (%rsp),%ecx
 29d5058:	mov    0x58(%rsp),%eax
 29d505c:	mov    %rbx,%r9
 29d505f:	sub    $0x8000000,%r9
 29d5066:	mov    %r9,%rbx
 29d5069:	mov    %r12,%r9
 29d506c:	add    $0x8000000,%r9
 29d5073:	mov    %r9,%r12
 29d5076:	mov    %rbx,%r9
 29d5079:	cmp    $0x8000000,%r9
 29d5080:	ja     29d4ffc <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x89c>
 29d5086:	mov    %r8d,0x58(%rsp)
 29d508b:	mov    %edi,(%rsp)
 29d508e:	mov    %esi,0x10(%rsp)
 29d5092:	mov    %edx,0x8(%rsp)
 29d5096:	mov    %ecx,0x20(%rsp)
 29d509a:	mov    %eax,0x28(%rsp)
 29d509e:	mov    0xd8(%rsp),%rax
 29d50a6:	mov    (%rax),%rax
 29d50a9:	mov    0x90(%rsp),%rcx
 29d50b1:	cmp    %rcx,%rax
 29d50b4:	jae    29d697f <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x221f>
 29d50ba:	xor    %edx,%edx
 29d50bc:	mov    %rbx,%rcx
 29d50bf:	mov    %r12,%rsi
 29d50c2:	mov    0x60(%rsp),%rdi
 29d50c7:	call   3018b23 <wasmtime_builtin_memory_fill>
 29d50cc:	mov    0x58(%rsp),%esi
 29d50d0:	test   %esi,%esi
 29d50d2:	je     29d6d54 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25f4>
 29d50d8:	test   %esi,%esi
 29d50da:	je     29d6d56 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25f6>
 29d50e0:	mov    0xd0(%rsp),%r13
 29d50e8:	mov    0x28(%r13),%r10
 29d50ec:	mov    0x20(%r13),%rdi
 29d50f0:	mov    %esi,%r8d
 29d50f3:	lea    (%rdi,%r8,1),%r9
 29d50f7:	lea    0x10(%rdi,%r8,1),%rsi
 29d50fc:	xor    %rax,%rax
 29d50ff:	cmp    %r10,%r8
 29d5102:	cmova  %rax,%rsi
 29d5106:	mov    (%rsi),%ecx
 29d5108:	mov    0x18(%rsp),%r11d
 29d510d:	test   %r11d,%r11d
 29d5110:	je     29d6d58 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25f8>
 29d5116:	test   %r11d,%r11d
 29d5119:	je     29d6d5a <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25fa>
 29d511f:	mov    %r11d,%edx
 29d5122:	lea    (%rdi,%rdx,1),%r11
 29d5126:	lea    0x10(%rdi,%rdx,1),%rsi
 29d512b:	cmp    %r10,%rdx
 29d512e:	cmova  %rax,%rsi
 29d5132:	mov    %ecx,%r13d
 29d5135:	mov    (%rsi),%eax
 29d5137:	cmp    %rax,%r13
 29d513a:	ja     29d6d5c <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25fc>
 29d5140:	lea    0x18(%rdi,%rdx,1),%r14
 29d5145:	mov    %r13,%rbx
 29d5148:	shl    $0x3,%rbx
 29d514c:	mov    %r14,%rcx
 29d514f:	add    %rbx,%rcx
 29d5152:	jb     29d6d5e <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25fe>
 29d5158:	lea    (%rdi,%r10,1),%rax
 29d515c:	cmp    %rax,%rcx
 29d515f:	ja     29d6d60 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2600>
 29d5165:	lea    0x18(%rdi,%r8,1),%r10
 29d516a:	mov    %r10,%rcx
 29d516d:	add    %rbx,%rcx
 29d5170:	jb     29d6d62 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2602>
 29d5176:	cmp    %rax,%rcx
 29d5179:	ja     29d6d64 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2604>
 29d517f:	cmp    %r14,%r10
 29d5182:	ja     29d5278 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0xb18>
 29d5188:	mov    (%rsp),%eax
 29d518b:	mov    0x10(%rsp),%ecx
 29d518f:	mov    0x18(%rsp),%edx
 29d5193:	mov    0x8(%rsp),%esi
 29d5197:	mov    0x20(%rsp),%edi
 29d519b:	mov    0x28(%rsp),%r8d
 29d51a0:	lea    0x18(%r11,%r13,8),%r14
 29d51a5:	mov    %r14,%r12
 29d51a8:	lea    0x18(%r9,%r13,8),%r10
 29d51ad:	mov    %r10,%r14
 29d51b0:	cmp    $0x8000000,%rbx
 29d51b7:	ja     29d51c8 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0xa68>
 29d51bd:	mov    %rbx,%r9
 29d51c0:	mov    %r12,%r10
 29d51c3:	jmp    29d5261 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0xb01>
 29d51c8:	mov    %eax,0x30(%rsp)
 29d51cc:	mov    %ecx,0x38(%rsp)
 29d51d0:	mov    %edx,0x40(%rsp)
 29d51d4:	mov    %esi,0x48(%rsp)
 29d51d8:	mov    %edi,0x50(%rsp)
 29d51dc:	mov    %r8d,0x58(%rsp)
 29d51e1:	mov    0xd8(%rsp),%rax
 29d51e9:	mov    (%rax),%rax
 29d51ec:	mov    0x90(%rsp),%rcx
 29d51f4:	cmp    %rcx,%rax
 29d51f7:	jae    29d69b3 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2253>
 29d51fd:	mov    $0x8000000,%ecx
 29d5202:	mov    %r12,%rsi
 29d5205:	sub    $0x8000000,%rsi
 29d520c:	mov    %r14,%rdx
 29d520f:	mov    %rsi,%r12
 29d5212:	sub    $0x8000000,%rdx
 29d5219:	mov    %rdx,%r14
 29d521c:	mov    0x60(%rsp),%rdi
 29d5221:	call   3018afa <wasmtime_builtin_memory_copy>
 29d5226:	mov    0x30(%rsp),%eax
 29d522a:	mov    0x38(%rsp),%ecx
 29d522e:	mov    0x40(%rsp),%edx
 29d5232:	mov    0x48(%rsp),%esi
 29d5236:	mov    0x50(%rsp),%edi
 29d523a:	mov    0x58(%rsp),%r8d
 29d523f:	mov    %rbx,%r9
 29d5242:	sub    $0x8000000,%r9
 29d5249:	cmp    $0x8000000,%r9
 29d5250:	jbe    29d525e <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0xafe>
 29d5256:	mov    %r9,%rbx
 29d5259:	jmp    29d51c8 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0xa68>
 29d525e:	mov    %r12,%r10
 29d5261:	sub    %r9,%r10
 29d5264:	mov    %r10,%r12
 29d5267:	mov    %r14,%r10
 29d526a:	sub    %r9,%r10
 29d526d:	mov    %r10,%r14
 29d5270:	mov    %r9,%rbx
 29d5273:	jmp    29d5341 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0xbe1>
 29d5278:	mov    %r14,%r12
 29d527b:	mov    %r10,%r14
 29d527e:	mov    %rbx,%r9
 29d5281:	mov    (%rsp),%eax
 29d5284:	mov    0x10(%rsp),%ecx
 29d5288:	mov    0x18(%rsp),%edx
 29d528c:	mov    0x8(%rsp),%esi
 29d5290:	mov    0x20(%rsp),%edi
 29d5294:	mov    0x28(%rsp),%r8d
 29d5299:	cmp    $0x8000000,%r9
 29d52a0:	jbe    29d5341 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0xbe1>
 29d52a6:	mov    %eax,0x28(%rsp)
 29d52aa:	mov    %ecx,0x20(%rsp)
 29d52ae:	mov    %edx,0x8(%rsp)
 29d52b2:	mov    %esi,0x18(%rsp)
 29d52b6:	mov    %edi,0x10(%rsp)
 29d52ba:	mov    %r8d,(%rsp)
 29d52be:	mov    0xd8(%rsp),%rax
 29d52c6:	mov    (%rax),%rax
 29d52c9:	mov    0x90(%rsp),%rcx
 29d52d1:	cmp    %rcx,%rax
 29d52d4:	jae    29d69e7 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2287>
 29d52da:	mov    $0x8000000,%ecx
 29d52df:	mov    %r14,%rdx
 29d52e2:	mov    %r12,%rsi
 29d52e5:	mov    0x60(%rsp),%rdi
 29d52ea:	call   3018afa <wasmtime_builtin_memory_copy>
 29d52ef:	mov    0x28(%rsp),%eax
 29d52f3:	mov    0x20(%rsp),%ecx
 29d52f7:	mov    0x8(%rsp),%edx
 29d52fb:	mov    0x18(%rsp),%esi
 29d52ff:	mov    0x10(%rsp),%edi
 29d5303:	mov    (%rsp),%r8d
 29d5307:	mov    %rbx,%r11
 29d530a:	mov    %r11,%r9
 29d530d:	sub    $0x8000000,%r9
 29d5314:	mov    %r9,%rbx
 29d5317:	mov    %r12,%r9
 29d531a:	add    $0x8000000,%r9
 29d5321:	mov    %r9,%r12
 29d5324:	mov    %r14,%r9
 29d5327:	add    $0x8000000,%r9
 29d532e:	mov    %r9,%r14
 29d5331:	mov    %rbx,%r9
 29d5334:	cmp    $0x8000000,%r9
 29d533b:	ja     29d52a6 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0xb46>
 29d5341:	mov    %eax,(%rsp)
 29d5344:	mov    %ecx,0x10(%rsp)
 29d5348:	mov    %edx,0x18(%rsp)
 29d534c:	mov    %esi,0x8(%rsp)
 29d5350:	mov    %edi,0x20(%rsp)
 29d5354:	mov    %r8d,0x28(%rsp)
 29d5359:	mov    0xd8(%rsp),%rax
 29d5361:	mov    (%rax),%r11
 29d5364:	mov    0x90(%rsp),%rax
 29d536c:	cmp    %rax,%r11
 29d536f:	jae    29d6a1b <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x22bb>
 29d5375:	mov    %rbx,%rcx
 29d5378:	mov    %r14,%rdx
 29d537b:	mov    %r12,%rsi
 29d537e:	jmp    29d538c <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0xc2c>
 29d5383:	mov    %rbx,%rcx
 29d5386:	mov    %r14,%rdx
 29d5389:	mov    %r12,%rsi
 29d538c:	mov    %rbx,%rcx
 29d538f:	mov    %r14,%rdx
 29d5392:	mov    %r12,%rsi
 29d5395:	mov    0x60(%rsp),%rdi
 29d539a:	call   3018afa <wasmtime_builtin_memory_copy>
 29d539f:	mov    (%rsp),%edx
 29d53a2:	mov    %rdx,%rax
 29d53a5:	mov    %rdx,0x80(%rsp)
 29d53ad:	test   %eax,%edx
 29d53af:	je     29d6d66 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2606>
 29d53b5:	mov    0x10(%rsp),%r8d
 29d53ba:	test   %r8d,%r8d
 29d53bd:	je     29d6d68 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2608>
 29d53c3:	mov    0x80(%rsp),%rax
 29d53cb:	test   %eax,%edx
 29d53cd:	je     29d6d6a <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x260a>
 29d53d3:	mov    0xd0(%rsp),%r13
 29d53db:	mov    0x28(%r13),%rdx
 29d53df:	mov    0x20(%r13),%rax
 29d53e3:	mov    0x80(%rsp),%rcx
 29d53eb:	mov    %ecx,%esi
 29d53ed:	add    %rsi,%rax
 29d53f0:	xor    %rdi,%rdi
 29d53f3:	cmp    %rdx,%rsi
 29d53f6:	cmova  %rdi,%rax
 29d53fa:	mov    %r8d,0x28(%rax)
 29d53fe:	mov    0x18(%rsp),%edi
 29d5402:	test   %edi,%edi
 29d5404:	je     29d6d6c <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x260c>
 29d540a:	mov    %edi,0x2c(%rax)
 29d540d:	mov    0x8(%rsp),%r9d
 29d5412:	mov    0x20(%rsp),%esi
 29d5416:	mov    0x28(%rsp),%edx
 29d541a:	test   %edi,%edi
 29d541c:	je     29d6d6e <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x260e>
 29d5422:	test   %edi,%edi
 29d5424:	je     29d6d70 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2610>
 29d542a:	mov    0xd0(%rsp),%r13
 29d5432:	mov    0x28(%r13),%r11
 29d5436:	mov    0x20(%r13),%rbx
 29d543a:	mov    %edi,%eax
 29d543c:	lea    0x10(%rbx,%rax,1),%r10
 29d5441:	xor    %r13,%r13
 29d5444:	cmp    %r11,%rax
 29d5447:	cmova  %r13,%r10
 29d544b:	mov    (%r10),%r14d
 29d544e:	mov    0x68(%rsp),%rcx
 29d5453:	mov    %rcx,%r12
 29d5456:	shr    $0x6,%r12d
 29d545a:	cmp    %r14d,%r12d
 29d545d:	mov    %r12,0xa0(%rsp)
 29d5465:	jae    29d6d72 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2612>
 29d546b:	mov    %r14d,%r10d
 29d546e:	shl    $0x3,%r10
 29d5472:	shr    $0x20,%r10
 29d5476:	test   %r10,%r10
 29d5479:	jne    29d6d74 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2614>
 29d547f:	shl    $0x3,%r14d
 29d5483:	add    $0x18,%r14d
 29d5487:	jb     29d6d76 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2616>
 29d548d:	mov    %rdi,%r10
 29d5490:	add    %r14d,%r10d
 29d5493:	jb     29d6d78 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2618>
 29d5499:	mov    %r10d,%r12d
 29d549c:	lea    (%rbx,%r12,1),%r10
 29d54a0:	cmp    %r11,%r12
 29d54a3:	cmova  %r13,%r10
 29d54a7:	mov    0xa0(%rsp),%r12
 29d54af:	mov    %r12,%rcx
 29d54b2:	shl    $0x3,%ecx
 29d54b5:	mov    %rcx,%rbx
 29d54b8:	lea    0x18(%rbx),%r11d
 29d54bc:	mov    %rbx,0xc8(%rsp)
 29d54c4:	sub    %r11d,%r14d
 29d54c7:	sub    %r14,%r10
 29d54ca:	mov    (%r10),%r13
 29d54cd:	mov    $0x1,%r14d
 29d54d3:	mov    0x68(%rsp),%rcx
 29d54d8:	shl    %cl,%r14
 29d54db:	bt     %rcx,%r13
 29d54df:	jb     29d5557 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0xdf7>
 29d54e5:	mov    0x80(%rsp),%rcx
 29d54ed:	mov    0x80(%rsp),%r10
 29d54f5:	test   %r10d,%ecx
 29d54f8:	je     29d6d7a <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x261a>
 29d54fe:	test   %r10d,%ecx
 29d5501:	je     29d6d7c <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x261c>
 29d5507:	mov    0xd0(%rsp),%rcx
 29d550f:	mov    0x28(%rcx),%r10
 29d5513:	mov    0x88(%rsp),%rcx
 29d551b:	lea    0x1(%rcx),%r11
 29d551f:	mov    0x80(%rsp),%rcx
 29d5527:	mov    %r11,0x88(%rsp)
 29d552f:	mov    %ecx,%ebx
 29d5531:	mov    0xd0(%rsp),%r12
 29d5539:	mov    %rbx,%r11
 29d553c:	add    0x20(%r12),%r11
 29d5541:	xor    %r15,%r15
 29d5544:	cmp    %r10,%rbx
 29d5547:	cmova  %r15,%r11
 29d554b:	mov    0x88(%rsp),%rcx
 29d5553:	mov    %rcx,0x18(%r11)
 29d5557:	test   %r8d,%r8d
 29d555a:	je     29d6d7e <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x261e>
 29d5560:	test   %r8d,%r8d
 29d5563:	je     29d6d80 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2620>
 29d5569:	mov    0xd0(%rsp),%rcx
 29d5571:	mov    0x28(%rcx),%rbx
 29d5575:	mov    0x20(%rcx),%r15
 29d5579:	mov    %r8d,%r12d
 29d557c:	lea    0x10(%r15,%r12,1),%r10
 29d5581:	xor    %r11,%r11
 29d5584:	cmp    %rbx,%r12
 29d5587:	cmova  %r11,%r10
 29d558b:	mov    (%r10),%r10d
 29d558e:	mov    0x68(%rsp),%rcx
 29d5593:	cmp    %r10d,%ecx
 29d5596:	jae    29d6d82 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2622>
 29d559c:	mov    %r10d,%r12d
 29d559f:	shl    $0x3,%r12
 29d55a3:	shr    $0x20,%r12
 29d55a7:	test   %r12,%r12
 29d55aa:	jne    29d6d84 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2624>
 29d55b0:	shl    $0x3,%r10d
 29d55b4:	add    $0x18,%r10d
 29d55b8:	jb     29d6d86 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2626>
 29d55be:	add    %r10d,%r8d
 29d55c1:	jb     29d6d88 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2628>
 29d55c7:	mov    %r8d,%r12d
 29d55ca:	lea    (%r15,%r12,1),%r8
 29d55ce:	cmp    %rbx,%r12
 29d55d1:	cmova  %r11,%r8
 29d55d5:	shl    $0x3,%ecx
 29d55d8:	lea    0x18(%rcx),%r12d
 29d55dc:	sub    %r12d,%r10d
 29d55df:	sub    %r10,%r8
 29d55e2:	mov    0x78(%rsp),%rcx
 29d55e7:	mov    %rcx,(%r8)
 29d55ea:	lea    0x10(%r15,%rax,1),%r8
 29d55ef:	cmp    %rbx,%rax
 29d55f2:	cmova  %r11,%r8
 29d55f6:	mov    (%r8),%eax
 29d55f9:	mov    0xa0(%rsp),%r12
 29d5601:	cmp    %eax,%r12d
 29d5604:	jae    29d6d8a <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x262a>
 29d560a:	mov    %eax,%r8d
 29d560d:	shl    $0x3,%r8
 29d5611:	shr    $0x20,%r8
 29d5615:	test   %r8,%r8
 29d5618:	jne    29d6d8c <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x262c>
 29d561e:	shl    $0x3,%eax
 29d5621:	add    $0x18,%eax
 29d5624:	jb     29d6d8e <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x262e>
 29d562a:	add    %eax,%edi
 29d562c:	jb     29d6d90 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2630>
 29d5632:	or     %r14,%r13
 29d5635:	mov    %edi,%r10d
 29d5638:	lea    (%r15,%r10,1),%rdi
 29d563c:	cmp    %rbx,%r10
 29d563f:	cmova  %r11,%rdi
 29d5643:	mov    0xc8(%rsp),%r10
 29d564b:	lea    0x18(%r10),%r11d
 29d564f:	sub    %r11d,%eax
 29d5652:	sub    %rax,%rdi
 29d5655:	mov    %r13,(%rdi)
 29d5658:	mov    $0x1,%r10d
 29d565e:	mov    0x80(%rsp),%rax
 29d5666:	mov    %eax,0x8(%rsp)
 29d566a:	mov    %r9d,0x10(%rsp)
 29d566f:	mov    %esi,(%rsp)
 29d5672:	mov    %edx,0x18(%rsp)
 29d5676:	test   %r10d,%r10d
 29d5679:	mov    %r10,0x98(%rsp)
 29d5681:	je     29d5699 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0xf39>
 29d5687:	mov    0x98(%rsp),%r10
 29d568f:	mov    0x78(%rsp),%r14
 29d5694:	jmp    29d65f2 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1e92>
 29d5699:	mov    0x80(%rsp),%rdi
 29d56a1:	mov    0x80(%rsp),%r8
 29d56a9:	test   %r8d,%edi
 29d56ac:	je     29d6d92 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2632>
 29d56b2:	mov    0x80(%rsp),%r10
 29d56ba:	mov    0x80(%rsp),%r11
 29d56c2:	test   %r10d,%r11d
 29d56c5:	je     29d6d94 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2634>
 29d56cb:	mov    0xd0(%rsp),%r13
 29d56d3:	mov    0x28(%r13),%rax
 29d56d7:	mov    0x80(%rsp),%rcx
 29d56df:	mov    %ecx,%r8d
 29d56e2:	mov    %r8,%rdi
 29d56e5:	add    0x20(%r13),%rdi
 29d56e9:	xor    %r9,%r9
 29d56ec:	cmp    %rax,%r8
 29d56ef:	cmova  %r9,%rdi
 29d56f3:	mov    0x24(%rdi),%eax
 29d56f6:	cmp    $0x2,%eax
 29d56f9:	sete   %al
 29d56fc:	mov    0x70(%rsp),%rdi
 29d5701:	cmp    $0x3,%edi
 29d5704:	setne  %cl
 29d5707:	test   %al,%cl
 29d5709:	jne    29d5724 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0xfc4>
 29d570f:	mov    0x80(%rsp),%rax
 29d5717:	mov    0x80(%rsp),%rcx
 29d571f:	jmp    29d5de9 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1689>
 29d5724:	mov    0x8(%rsp),%edx
 29d5728:	mov    %rdx,%rax
 29d572b:	mov    %rdx,0x80(%rsp)
 29d5733:	test   %eax,%edx
 29d5735:	je     29d6d96 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2636>
 29d573b:	mov    0x80(%rsp),%rax
 29d5743:	test   %eax,%edx
 29d5745:	je     29d6d98 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2638>
 29d574b:	mov    0xd0(%rsp),%r13
 29d5753:	mov    0x28(%r13),%rax
 29d5757:	mov    0x20(%r13),%rsi
 29d575b:	mov    %edx,%r8d
 29d575e:	lea    (%rsi,%r8,1),%rdx
 29d5762:	xor    %rdi,%rdi
 29d5765:	cmp    %rax,%r8
 29d5768:	cmova  %rdi,%rdx
 29d576c:	mov    0x28(%rdx),%r8d
 29d5770:	mov    0x2c(%rdx),%ecx
 29d5773:	test   %r8d,%r8d
 29d5776:	je     29d6d9a <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x263a>
 29d577c:	test   %r8d,%r8d
 29d577f:	je     29d6d9c <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x263c>
 29d5785:	mov    %r8d,%r8d
 29d5788:	lea    0x10(%rsi,%r8,1),%rsi
 29d578d:	cmp    %rax,%r8
 29d5790:	cmova  %rdi,%rsi
 29d5794:	mov    (%rsi),%edi
 29d5796:	mov    0x18(%rdx),%rax
 29d579a:	mov    (%rsp),%esi
 29d579d:	mov    0x18(%rsp),%edx
 29d57a1:	mov    %edi,%ecx
 29d57a3:	mov    0x68(%rsp),%rdi
 29d57a8:	cmp    %rcx,%rdi
 29d57ab:	setb   %dil
 29d57af:	mov    0x68(%rsp),%rcx
 29d57b4:	cmp    $0x100000,%rcx
 29d57bb:	setb   %r8b
 29d57bf:	lea    0x8(%rax,%rax,1),%rax
 29d57c4:	cmp    %rax,%rcx
 29d57c7:	setbe  %al
 29d57ca:	and    %eax,%r8d
 29d57cd:	or     %r8d,%edi
 29d57d0:	test   %dil,%dil
 29d57d3:	je     29d5dd9 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1679>
 29d57d9:	mov    0x8(%rsp),%edx
 29d57dd:	test   %edx,%edx
 29d57df:	je     29d6d9e <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x263e>
 29d57e5:	test   %edx,%edx
 29d57e7:	je     29d6da0 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2640>
 29d57ed:	mov    0xd0(%rsp),%r13
 29d57f5:	mov    0x28(%r13),%rax
 29d57f9:	mov    0x20(%r13),%rcx
 29d57fd:	mov    %edx,%edi
 29d57ff:	lea    (%rcx,%rdi,1),%rsi
 29d5803:	xor    %rdx,%rdx
 29d5806:	cmp    %rax,%rdi
 29d5809:	cmova  %rdx,%rsi
 29d580d:	mov    0x28(%rsi),%edi
 29d5810:	mov    0x2c(%rsi),%esi
 29d5813:	test   %edi,%edi
 29d5815:	je     29d6da2 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2642>
 29d581b:	test   %edi,%edi
 29d581d:	je     29d6da4 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2644>
 29d5823:	mov    %edi,%esi
 29d5825:	lea    0x10(%rcx,%rsi,1),%rcx
 29d582a:	cmp    %rax,%rsi
 29d582d:	cmova  %rdx,%rcx
 29d5831:	mov    (%rcx),%eax
 29d5833:	mov    %eax,%r14d
 29d5836:	mov    %r14,%r13
 29d5839:	shl    $0x2,%r13
 29d583d:	mov    $0x20,%ecx
 29d5842:	mov    %rcx,0xc0(%rsp)
 29d584a:	mov    %r13,%rcx
 29d584d:	shr    $0x20,%rcx
 29d5851:	test   %rcx,%rcx
 29d5854:	jne    29d6da6 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2646>
 29d585a:	mov    %rax,%rcx
 29d585d:	shl    $0x2,%ecx
 29d5860:	mov    %rax,0xc8(%rsp)
 29d5868:	add    $0x14,%ecx
 29d586b:	jb     29d6da8 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2648>
 29d5871:	mov    0x60(%rsp),%rax
 29d5876:	mov    0x20(%rax),%rdi
 29d587a:	mov    (%rdi),%eax
 29d587c:	mov    %eax,%edx
 29d587e:	mov    %ecx,%esi
 29d5880:	add    $0xf,%rsi
 29d5887:	mov    %rsi,%r8
 29d588a:	and    $0xfffffffffffffff0,%r8
 29d588e:	add    %rdx,%r8
 29d5891:	mov    0x4(%rdi),%r9d
 29d5895:	mov    %rdi,0xb8(%rsp)
 29d589d:	cmp    %r9,%r8
 29d58a0:	ja     29d6a58 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x22f8>
 29d58a6:	add    $0xf,%ecx
 29d58ac:	and    $0xfffffff0,%ecx
 29d58af:	add    %eax,%ecx
 29d58b1:	mov    0xb8(%rsp),%rbx
 29d58b9:	mov    %ecx,(%rbx)
 29d58bb:	mov    0xd0(%rsp),%rcx
 29d58c3:	mov    0x20(%rcx),%rdi
 29d58c7:	lea    (%rdi,%rdx,1),%rcx
 29d58cb:	movl   $0xa800000e,(%rdi,%rdx,1)
 29d58d2:	mov    0x60(%rsp),%r8
 29d58d7:	mov    0x28(%r8),%r8
 29d58db:	mov    0x19c(%r8),%r8d
 29d58e2:	mov    %r8d,0x4(%rdi,%rdx,1)
 29d58e7:	and    $0xfffffffffffffff0,%rsi
 29d58eb:	mov    %esi,0x8(%rdi,%rdx,1)
 29d58ef:	mov    %eax,0x20(%rsp)
 29d58f3:	mov    0xc8(%rsp),%r15
 29d58fb:	mov    %r15d,0x10(%rcx)
 29d58ff:	test   %eax,%eax
 29d5901:	je     29d6daa <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x264a>
 29d5907:	mov    0xd0(%rsp),%rcx
 29d590f:	mov    0x28(%rcx),%r10
 29d5913:	mov    0x20(%rcx),%r11
 29d5917:	mov    %eax,%eax
 29d5919:	lea    (%r11,%rax,1),%r9
 29d591d:	lea    0x10(%r11,%rax,1),%rsi
 29d5922:	xor    %rcx,%rcx
 29d5925:	cmp    %r10,%rax
 29d5928:	cmova  %rcx,%rsi
 29d592c:	mov    (%rsi),%ecx
 29d592e:	cmp    %rcx,%r14
 29d5931:	ja     29d6dac <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x264c>
 29d5937:	lea    0x14(%r11,%rax,1),%rbx
 29d593c:	mov    %rbx,%rax
 29d593f:	add    %r13,%rax
 29d5942:	jb     29d6dae <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x264e>
 29d5948:	lea    (%r11,%r10,1),%rcx
 29d594c:	cmp    %rcx,%rax
 29d594f:	ja     29d6db0 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2650>
 29d5955:	mov    0x8(%rsp),%ecx
 29d5959:	mov    0x10(%rsp),%eax
 29d595d:	mov    (%rsp),%edx
 29d5960:	mov    0x18(%rsp),%esi
 29d5964:	lea    0x14(%r9,%r14,4),%r15
 29d5969:	test   %r14,%r14
 29d596c:	je     29d59c2 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1262>
 29d5972:	mov    %ecx,0x18(%rsp)
 29d5976:	mov    %eax,(%rsp)
 29d5979:	mov    %edx,0x10(%rsp)
 29d597d:	mov    %esi,0x8(%rsp)
 29d5981:	mov    0xd8(%rsp),%rax
 29d5989:	mov    (%rax),%rax
 29d598c:	mov    0x90(%rsp),%rcx
 29d5994:	cmp    %rcx,%rax
 29d5997:	jae    29d6a8f <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x232f>
 29d599d:	movl   $0x0,(%rbx)
 29d59a3:	mov    0x18(%rsp),%ecx
 29d59a7:	mov    (%rsp),%eax
 29d59aa:	mov    0x10(%rsp),%edx
 29d59ae:	mov    0x8(%rsp),%esi
 29d59b2:	add    $0x4,%rbx
 29d59b9:	cmp    %r15,%rbx
 29d59bc:	jne    29d5972 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1212>
 29d59c2:	mov    %ecx,0x18(%rsp)
 29d59c6:	xor    %r14d,%r14d
 29d59c9:	mov    $0x1,%r15d
 29d59cf:	mov    0x60(%rsp),%rcx
 29d59d4:	mov    %r15,0xb0(%rsp)
 29d59dc:	mov    0x28(%rcx),%rcx
 29d59e0:	mov    0x120(%rcx),%r13d
 29d59e7:	mov    %r13,0xa0(%rsp)
 29d59ef:	mov    $0x10,%r15d
 29d59f5:	mov    %r15,0xa8(%rsp)
 29d59fd:	mov    %r14,%r15
 29d5a00:	mov    %eax,0x8(%rsp)
 29d5a04:	mov    %edx,0x10(%rsp)
 29d5a08:	mov    %esi,(%rsp)
 29d5a0b:	mov    0xd8(%rsp),%rax
 29d5a13:	mov    (%rax),%rax
 29d5a16:	mov    0x90(%rsp),%rcx
 29d5a1e:	cmp    %rcx,%rax
 29d5a21:	jae    29d6ac3 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2363>
 29d5a27:	mov    0xc8(%rsp),%rdi
 29d5a2f:	jmp    29d5a3c <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x12dc>
 29d5a34:	mov    0xc8(%rsp),%rdi
 29d5a3c:	cmp    %edi,%r14d
 29d5a3f:	jae    29d5d47 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x15e7>
 29d5a45:	mov    0x18(%rsp),%eax
 29d5a49:	xor    %ecx,%ecx
 29d5a4b:	test   %eax,%eax
 29d5a4d:	je     29d6db2 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2652>
 29d5a53:	test   %eax,%eax
 29d5a55:	je     29d6db4 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2654>
 29d5a5b:	mov    0xd0(%rsp),%r13
 29d5a63:	mov    0x28(%r13),%rdi
 29d5a67:	mov    0x20(%r13),%r8
 29d5a6b:	mov    %eax,%edx
 29d5a6d:	lea    (%r8,%rdx,1),%rax
 29d5a71:	xor    %r9,%r9
 29d5a74:	cmp    %rdi,%rdx
 29d5a77:	cmova  %r9,%rax
 29d5a7b:	mov    0x28(%rax),%esi
 29d5a7e:	mov    0x2c(%rax),%edx
 29d5a81:	test   %esi,%esi
 29d5a83:	je     29d6db6 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2656>
 29d5a89:	test   %esi,%esi
 29d5a8b:	je     29d6db8 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2658>
 29d5a91:	mov    %esi,%eax
 29d5a93:	lea    0x10(%r8,%rax,1),%r8
 29d5a98:	cmp    %rdi,%rax
 29d5a9b:	cmova  %r9,%r8
 29d5a9f:	mov    (%r8),%r8d
 29d5aa2:	mov    0x8(%rsp),%edi
 29d5aa6:	mov    %r14d,%r9d
 29d5aa9:	mov    %r8d,%r8d
 29d5aac:	cmp    %r8,%r9
 29d5aaf:	jae    29d5be0 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1480>
 29d5ab5:	xor    %ecx,%ecx
 29d5ab7:	test   %edx,%edx
 29d5ab9:	je     29d6dba <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x265a>
 29d5abf:	test   %edx,%edx
 29d5ac1:	je     29d6dbc <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x265c>
 29d5ac7:	mov    0xd0(%rsp),%r13
 29d5acf:	mov    0x28(%r13),%rdi
 29d5ad3:	mov    0x20(%r13),%r8
 29d5ad7:	mov    %edx,%r11d
 29d5ada:	lea    0x10(%r8,%r11,1),%r10
 29d5adf:	xor    %r9,%r9
 29d5ae2:	cmp    %rdi,%r11
 29d5ae5:	cmova  %r9,%r10
 29d5ae9:	mov    (%r10),%r10d
 29d5aec:	mov    %r14,%r11
 29d5aef:	shr    $0x6,%r11d
 29d5af3:	cmp    %r10d,%r11d
 29d5af6:	jae    29d6dbe <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x265e>
 29d5afc:	mov    %r10d,%r12d
 29d5aff:	shl    $0x3,%r12
 29d5b03:	shr    $0x20,%r12
 29d5b07:	test   %r12,%r12
 29d5b0a:	jne    29d6dc0 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2660>
 29d5b10:	shl    $0x3,%r10d
 29d5b14:	add    $0x18,%r10d
 29d5b18:	jb     29d6dc2 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2662>
 29d5b1e:	add    %r10d,%edx
 29d5b21:	jb     29d6dc4 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2664>
 29d5b27:	mov    %edx,%edx
 29d5b29:	add    %rdx,%r8
 29d5b2c:	cmp    %rdi,%rdx
 29d5b2f:	cmova  %r9,%r8
 29d5b33:	shl    $0x3,%r11d
 29d5b37:	add    $0x18,%r11d
 29d5b3e:	sub    %r11d,%r10d
 29d5b41:	sub    %r10,%r8
 29d5b44:	mov    (%r8),%r11
 29d5b47:	mov    0x8(%rsp),%edi
 29d5b4b:	bt     %r14,%r11
 29d5b4f:	jae    29d5be0 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1480>
 29d5b55:	mov    0xd0(%rsp),%r13
 29d5b5d:	mov    0x28(%r13),%rcx
 29d5b61:	mov    0x20(%r13),%r8
 29d5b65:	lea    0x10(%r8,%rax,1),%r11
 29d5b6a:	xor    %rdx,%rdx
 29d5b6d:	cmp    %rcx,%rax
 29d5b70:	cmova  %rdx,%r11
 29d5b74:	mov    (%r11),%edi
 29d5b77:	cmp    %edi,%r14d
 29d5b7a:	jae    29d6dc6 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2666>
 29d5b80:	mov    %edi,%eax
 29d5b82:	shl    $0x3,%rax
 29d5b86:	shr    $0x20,%rax
 29d5b8a:	test   %rax,%rax
 29d5b8d:	jne    29d6dc8 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2668>
 29d5b93:	mov    $0x3,%r15d
 29d5b99:	shl    $0x3,%edi
 29d5b9c:	add    $0x18,%edi
 29d5b9f:	jb     29d6dca <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x266a>
 29d5ba5:	add    %edi,%esi
 29d5ba7:	jb     29d6dcc <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x266c>
 29d5bad:	mov    %esi,%esi
 29d5baf:	lea    (%r8,%rsi,1),%rax
 29d5bb3:	cmp    %rcx,%rsi
 29d5bb6:	cmova  %rdx,%rax
 29d5bba:	mov    %r14,%rcx
 29d5bbd:	shl    $0x3,%ecx
 29d5bc0:	add    $0x18,%ecx
 29d5bc6:	sub    %ecx,%edi
 29d5bc8:	sub    %rdi,%rax
 29d5bcb:	mov    (%rax),%rax
 29d5bce:	mov    %rax,0x88(%rsp)
 29d5bd6:	xor    %edi,%edi
 29d5bd8:	mov    0xb0(%rsp),%rcx
 29d5be0:	mov    %edi,0x8(%rsp)
 29d5be4:	test   %ecx,%ecx
 29d5be6:	jne    29d5c09 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x14a9>
 29d5bec:	mov    0xc0(%rsp),%rcx
 29d5bf4:	mov    0xb8(%rsp),%rbx
 29d5bfc:	mov    0xa0(%rsp),%r13
 29d5c04:	jmp    29d5d18 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x15b8>
 29d5c09:	mov    0xb8(%rsp),%rbx
 29d5c11:	mov    (%rbx),%eax
 29d5c13:	mov    %eax,%edx
 29d5c15:	lea    0x20(%rdx),%rcx
 29d5c19:	mov    0x4(%rbx),%esi
 29d5c1c:	cmp    %rsi,%rcx
 29d5c1f:	ja     29d6b02 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x23a2>
 29d5c25:	mov    0xa0(%rsp),%r13
 29d5c2d:	lea    0x20(%rax),%ecx
 29d5c30:	mov    %ecx,(%rbx)
 29d5c32:	mov    0xd0(%rsp),%r11
 29d5c3a:	mov    0x20(%r11),%rdi
 29d5c3e:	lea    (%rdi,%rdx,1),%rsi
 29d5c42:	movl   $0xb0000042,(%rdi,%rdx,1)
 29d5c49:	mov    %r13d,0x4(%rdi,%rdx,1)
 29d5c4e:	mov    0xc0(%rsp),%rcx
 29d5c56:	mov    %ecx,0x8(%rdi,%rdx,1)
 29d5c5a:	mov    0x88(%rsp),%rdx
 29d5c62:	mov    0x88(%rsp),%rdx
 29d5c6a:	mov    %rdx,0x10(%rsi)
 29d5c6e:	mov    %r15d,0x18(%rsi)
 29d5c72:	mov    0x8(%rsp),%edx
 29d5c76:	mov    %edx,0x1c(%rsi)
 29d5c79:	mov    0x20(%rsp),%edx
 29d5c7d:	test   %edx,%edx
 29d5c7f:	je     29d6dce <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x266e>
 29d5c85:	test   %eax,%eax
 29d5c87:	je     29d6dd0 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2670>
 29d5c8d:	test   %edx,%edx
 29d5c8f:	je     29d6dd2 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2672>
 29d5c95:	mov    0xd0(%rsp),%rsi
 29d5c9d:	mov    0x28(%rsi),%rsi
 29d5ca1:	mov    0xd0(%rsp),%rdi
 29d5ca9:	mov    0x20(%rdi),%rdi
 29d5cad:	mov    %edx,%r10d
 29d5cb0:	lea    0x10(%rdi,%r10,1),%r9
 29d5cb5:	xor    %r8,%r8
 29d5cb8:	cmp    %rsi,%r10
 29d5cbb:	cmova  %r8,%r9
 29d5cbf:	mov    (%r9),%r9d
 29d5cc2:	cmp    %r9d,%r14d
 29d5cc5:	jae    29d6dd4 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2674>
 29d5ccb:	mov    %r9d,%r10d
 29d5cce:	shl    $0x2,%r10
 29d5cd2:	shr    $0x20,%r10
 29d5cd6:	test   %r10,%r10
 29d5cd9:	jne    29d6dd6 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2676>
 29d5cdf:	shl    $0x2,%r9d
 29d5ce3:	add    $0x14,%r9d
 29d5ce7:	jb     29d6dd8 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2678>
 29d5ced:	add    %r9d,%edx
 29d5cf0:	jb     29d6dda <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x267a>
 29d5cf6:	mov    %edx,%r10d
 29d5cf9:	lea    (%rdi,%r10,1),%rdx
 29d5cfd:	cmp    %rsi,%r10
 29d5d00:	cmova  %r8,%rdx
 29d5d04:	mov    %r14,%rsi
 29d5d07:	shl    $0x2,%esi
 29d5d0a:	add    $0x14,%esi
 29d5d10:	sub    %esi,%r9d
 29d5d13:	sub    %r9,%rdx
 29d5d16:	mov    %eax,(%rdx)
 29d5d18:	mov    0x8(%rsp),%eax
 29d5d1c:	mov    0x10(%rsp),%edx
 29d5d20:	mov    (%rsp),%esi
 29d5d23:	add    $0x1,%r14d
 29d5d2a:	mov    %r13,0xa0(%rsp)
 29d5d32:	mov    %rbx,0xb8(%rsp)
 29d5d3a:	mov    %rcx,0xc0(%rsp)
 29d5d42:	jmp    29d5a00 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x12a0>
 29d5d47:	mov    0x60(%rsp),%rcx
 29d5d4c:	mov    0xa00(%rcx),%edx
 29d5d52:	mov    0xa10(%rcx),%eax
 29d5d58:	mov    0x18(%rsp),%ecx
 29d5d5c:	mov    %rcx,%rsi
 29d5d5f:	mov    %rcx,0x80(%rsp)
 29d5d67:	test   %esi,%ecx
 29d5d69:	je     29d6ddc <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x267c>
 29d5d6f:	test   %edx,%edx
 29d5d71:	je     29d6dde <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x267e>
 29d5d77:	mov    0x80(%rsp),%rsi
 29d5d7f:	test   %esi,%ecx
 29d5d81:	je     29d6de0 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2680>
 29d5d87:	mov    0xd0(%rsp),%r13
 29d5d8f:	mov    0x28(%r13),%rdi
 29d5d93:	mov    0x20(%r13),%rsi
 29d5d97:	mov    %ecx,%r8d
 29d5d9a:	add    %r8,%rsi
 29d5d9d:	xor    %r9,%r9
 29d5da0:	cmp    %rdi,%r8
 29d5da3:	cmova  %r9,%rsi
 29d5da7:	mov    %edx,0x28(%rsi)
 29d5daa:	test   %eax,%eax
 29d5dac:	je     29d6de2 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2682>
 29d5db2:	mov    %eax,0x2c(%rsi)
 29d5db5:	movl   $0x0,0x30(%rsi)
 29d5dbc:	mov    0x20(%rsp),%edi
 29d5dc0:	test   %edi,%edi
 29d5dc2:	je     29d6de4 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2684>
 29d5dc8:	mov    %edi,0x30(%rsi)
 29d5dcb:	movl   $0x3,0x24(%rsi)
 29d5dd2:	mov    0x10(%rsp),%esi
 29d5dd6:	mov    (%rsp),%edx
 29d5dd9:	mov    0x80(%rsp),%rax
 29d5de1:	mov    0x80(%rsp),%rcx
 29d5de9:	test   %ecx,%eax
 29d5deb:	je     29d6de6 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2686>
 29d5df1:	mov    0x80(%rsp),%rax
 29d5df9:	mov    0x80(%rsp),%rcx
 29d5e01:	test   %ecx,%eax
 29d5e03:	je     29d6de8 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2688>
 29d5e09:	mov    0xd0(%rsp),%r13
 29d5e11:	mov    0x28(%r13),%rax
 29d5e15:	mov    %ecx,%edi
 29d5e17:	mov    %rdi,%r8
 29d5e1a:	add    0x20(%r13),%r8
 29d5e1e:	xor    %r9,%r9
 29d5e21:	cmp    %rax,%rdi
 29d5e24:	cmova  %r9,%r8
 29d5e28:	mov    0x24(%r8),%eax
 29d5e2c:	cmp    $0x3,%eax
 29d5e2f:	je     29d5e47 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x16e7>
 29d5e35:	mov    0x98(%rsp),%r10
 29d5e3d:	mov    0x78(%rsp),%r14
 29d5e42:	jmp    29d65f2 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1e92>
 29d5e47:	mov    0xd0(%rsp),%r13
 29d5e4f:	mov    0x28(%r13),%r8
 29d5e53:	mov    0x20(%r13),%r10
 29d5e57:	lea    (%r10,%rdi,1),%rax
 29d5e5b:	xor    %r9,%r9
 29d5e5e:	cmp    %r8,%rdi
 29d5e61:	cmova  %r9,%rax
 29d5e65:	mov    0x30(%rax),%edi
 29d5e68:	test   %edi,%edi
 29d5e6a:	je     29d6dea <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x268a>
 29d5e70:	test   %edi,%edi
 29d5e72:	je     29d6dec <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x268c>
 29d5e78:	mov    %edi,%r11d
 29d5e7b:	lea    0x10(%r10,%r11,1),%r10
 29d5e80:	cmp    %r8,%r11
 29d5e83:	cmova  %r9,%r10
 29d5e87:	mov    (%r10),%r12d
 29d5e8a:	mov    %r12,0xa0(%rsp)
 29d5e92:	mov    0x18(%rax),%rbx
 29d5e96:	mov    %rbx,0xa8(%rsp)
 29d5e9e:	mov    %r12d,%r14d
 29d5ea1:	mov    0x68(%rsp),%rcx
 29d5ea6:	cmp    %r14,%rcx
 29d5ea9:	setb   %al
 29d5eac:	cmp    $0x100000,%rcx
 29d5eb3:	setb   %r8b
 29d5eb7:	lea    0x8(%rbx,%rbx,1),%rcx
 29d5ebc:	mov    0x68(%rsp),%r9
 29d5ec1:	cmp    %rcx,%r9
 29d5ec4:	setbe  %r9b
 29d5ec8:	and    %r9d,%r8d
 29d5ecb:	or     %r8d,%eax
 29d5ece:	test   %al,%al
 29d5ed0:	jne    29d5ee8 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1788>
 29d5ed6:	mov    0x98(%rsp),%r10
 29d5ede:	mov    0x78(%rsp),%r14
 29d5ee3:	jmp    29d65f2 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1e92>
 29d5ee8:	mov    0x68(%rsp),%rcx
 29d5eed:	cmp    %r14,%rcx
 29d5ef0:	jb     29d63eb <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1c8b>
 29d5ef6:	mov    0xa0(%rsp),%rax
 29d5efe:	mov    0xa0(%rsp),%r12
 29d5f06:	test   %eax,%r12d
 29d5f09:	je     29d5f1c <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x17bc>
 29d5f0f:	mov    0xa0(%rsp),%r15
 29d5f17:	jmp    29d5f22 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x17c2>
 29d5f1c:	mov    $0x4,%r15d
 29d5f22:	mov    %edi,0x20(%rsp)
 29d5f26:	mov    0x80(%rsp),%rax
 29d5f2e:	mov    %eax,(%rsp)
 29d5f31:	mov    %esi,0x10(%rsp)
 29d5f35:	mov    %edx,0x18(%rsp)
 29d5f39:	mov    0xd8(%rsp),%rax
 29d5f41:	mov    (%rax),%rax
 29d5f44:	mov    0x90(%rsp),%rcx
 29d5f4c:	cmp    %rcx,%rax
 29d5f4f:	jae    29d6b4c <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x23ec>
 29d5f55:	mov    %r15d,%r13d
 29d5f58:	mov    0x68(%rsp),%rcx
 29d5f5d:	cmp    %r13,%rcx
 29d5f60:	jb     29d5f85 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1825>
 29d5f66:	mov    0x20(%rsp),%edi
 29d5f6a:	mov    (%rsp),%edx
 29d5f6d:	mov    %rdx,0x80(%rsp)
 29d5f75:	mov    0x10(%rsp),%esi
 29d5f79:	mov    0x18(%rsp),%edx
 29d5f7d:	shl    $1,%r15d
 29d5f80:	jmp    29d5f22 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x17c2>
 29d5f85:	mov    %r13,%rbx
 29d5f88:	shl    $0x2,%rbx
 29d5f8c:	mov    %rbx,%rax
 29d5f8f:	shr    $0x20,%rax
 29d5f93:	test   %rax,%rax
 29d5f96:	jne    29d6dee <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x268e>
 29d5f9c:	mov    %r15,%rcx
 29d5f9f:	shl    $0x2,%ecx
 29d5fa2:	add    $0x14,%ecx
 29d5fa5:	jb     29d6df0 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2690>
 29d5fab:	mov    0x60(%rsp),%rax
 29d5fb0:	mov    0x20(%rax),%rdi
 29d5fb4:	mov    (%rdi),%eax
 29d5fb6:	mov    %eax,%edx
 29d5fb8:	mov    %ecx,%esi
 29d5fba:	add    $0xf,%rsi
 29d5fc1:	mov    %rsi,%r8
 29d5fc4:	and    $0xfffffffffffffff0,%r8
 29d5fc8:	add    %rdx,%r8
 29d5fcb:	mov    0x4(%rdi),%r9d
 29d5fcf:	cmp    %r9,%r8
 29d5fd2:	ja     29d6b80 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2420>
 29d5fd8:	add    $0xf,%ecx
 29d5fde:	and    $0xfffffff0,%ecx
 29d5fe1:	add    %eax,%ecx
 29d5fe3:	mov    %ecx,(%rdi)
 29d5fe5:	mov    0xd0(%rsp),%rcx
 29d5fed:	mov    0x20(%rcx),%rdi
 29d5ff1:	lea    (%rdi,%rdx,1),%rcx
 29d5ff5:	movl   $0xa800000e,(%rdi,%rdx,1)
 29d5ffc:	mov    0x60(%rsp),%r8
 29d6001:	mov    0x28(%r8),%r8
 29d6005:	mov    0x19c(%r8),%r8d
 29d600c:	mov    %r8d,0x4(%rdi,%rdx,1)
 29d6011:	and    $0xfffffffffffffff0,%rsi
 29d6015:	mov    %esi,0x8(%rdi,%rdx,1)
 29d6019:	mov    %eax,0x8(%rsp)
 29d601d:	mov    %r15d,0x10(%rcx)
 29d6021:	test   %eax,%eax
 29d6023:	je     29d6df2 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2692>
 29d6029:	mov    0xd0(%rsp),%rcx
 29d6031:	mov    0x28(%rcx),%rsi
 29d6035:	mov    0x20(%rcx),%r8
 29d6039:	mov    %eax,%r9d
 29d603c:	lea    (%r8,%r9,1),%rdi
 29d6040:	lea    0x10(%r8,%r9,1),%rdx
 29d6045:	xor    %r10,%r10
 29d6048:	cmp    %rsi,%r9
 29d604b:	cmova  %r10,%rdx
 29d604f:	mov    (%rdx),%r10d
 29d6052:	cmp    %r10,%r13
 29d6055:	ja     29d6df4 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2694>
 29d605b:	lea    0x14(%r8,%r9,1),%r15
 29d6060:	mov    %r15,%r9
 29d6063:	add    %rbx,%r9
 29d6066:	jb     29d6df6 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2696>
 29d606c:	lea    (%r8,%rsi,1),%r10
 29d6070:	cmp    %r10,%r9
 29d6073:	ja     29d6df8 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2698>
 29d6079:	mov    0x20(%rsp),%r8d
 29d607e:	mov    (%rsp),%edx
 29d6081:	mov    %rdx,0x80(%rsp)
 29d6089:	mov    0x10(%rsp),%esi
 29d608d:	mov    0x18(%rsp),%edx
 29d6091:	lea    0x14(%rdi,%r13,4),%r12
 29d6096:	test   %r13,%r13
 29d6099:	je     29d6102 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x19a2>
 29d609f:	mov    %r8d,0x18(%rsp)
 29d60a4:	mov    0x80(%rsp),%rax
 29d60ac:	mov    %eax,0x10(%rsp)
 29d60b0:	mov    %esi,(%rsp)
 29d60b3:	mov    %edx,0x20(%rsp)
 29d60b7:	mov    0xd8(%rsp),%rax
 29d60bf:	mov    (%rax),%rcx
 29d60c2:	mov    0x90(%rsp),%rax
 29d60ca:	cmp    %rax,%rcx
 29d60cd:	jae    29d6bb7 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2457>
 29d60d3:	movl   $0x0,(%r15)
 29d60da:	mov    0x18(%rsp),%r8d
 29d60df:	mov    0x10(%rsp),%edx
 29d60e3:	mov    %rdx,0x80(%rsp)
 29d60eb:	mov    (%rsp),%esi
 29d60ee:	mov    0x20(%rsp),%edx
 29d60f2:	add    $0x4,%r15
 29d60f9:	cmp    %r12,%r15
 29d60fc:	jne    29d609f <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x193f>
 29d6102:	mov    0x8(%rsp),%edi
 29d6106:	test   %edi,%edi
 29d6108:	je     29d6dfa <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x269a>
 29d610e:	test   %r8d,%r8d
 29d6111:	je     29d6dfc <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x269c>
 29d6117:	test   %edi,%edi
 29d6119:	je     29d6dfe <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x269e>
 29d611f:	mov    0xd0(%rsp),%r13
 29d6127:	mov    0x28(%r13),%r10
 29d612b:	mov    0x20(%r13),%rax
 29d612f:	mov    %edi,%ebx
 29d6131:	lea    (%rax,%rbx,1),%r9
 29d6135:	lea    0x10(%rax,%rbx,1),%r11
 29d613a:	xor    %r15,%r15
 29d613d:	cmp    %r10,%rbx
 29d6140:	cmova  %r15,%r11
 29d6144:	mov    (%r11),%ecx
 29d6147:	cmp    %rcx,%r14
 29d614a:	ja     29d6e00 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x26a0>
 29d6150:	test   %r8d,%r8d
 29d6153:	je     29d6e02 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x26a2>
 29d6159:	mov    %r8d,%r13d
 29d615c:	lea    (%rax,%r13,1),%r11
 29d6160:	lea    0x10(%rax,%r13,1),%r12
 29d6165:	cmp    %r10,%r13
 29d6168:	cmova  %r15,%r12
 29d616c:	mov    (%r12),%ecx
 29d6170:	cmp    %rcx,%r14
 29d6173:	ja     29d6e04 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x26a4>
 29d6179:	lea    0x14(%rax,%rbx,1),%rbx
 29d617e:	mov    %r14,%r15
 29d6181:	shl    $0x2,%r15
 29d6185:	mov    %r14,%rcx
 29d6188:	mov    %rbx,%r12
 29d618b:	add    %r15,%r12
 29d618e:	jb     29d6e06 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x26a6>
 29d6194:	add    %rax,%r10
 29d6197:	cmp    %r10,%r12
 29d619a:	ja     29d6e08 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x26a8>
 29d61a0:	lea    0x14(%rax,%r13,1),%rax
 29d61a5:	mov    %rax,%r12
 29d61a8:	add    %r15,%rax
 29d61ab:	mov    %r12,0x88(%rsp)
 29d61b3:	jb     29d6e0a <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x26aa>
 29d61b9:	cmp    %r10,%rax
 29d61bc:	ja     29d6e0c <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x26ac>
 29d61c2:	mov    0xa0(%rsp),%rax
 29d61ca:	mov    0xa0(%rsp),%r12
 29d61d2:	test   %eax,%r12d
 29d61d5:	jne    29d61f0 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1a90>
 29d61db:	mov    0x80(%rsp),%rax
 29d61e3:	mov    0x80(%rsp),%rcx
 29d61eb:	jmp    29d639f <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1c3f>
 29d61f0:	mov    0x8(%rsp),%r10d
 29d61f5:	xor    %r15d,%r15d
 29d61f8:	mov    %rcx,%rax
 29d61fb:	lea    0x14(%r9,%rax,4),%r14
 29d6200:	lea    0x14(%r11,%rax,4),%r13
 29d6205:	mov    0x88(%rsp),%rax
 29d620d:	mov    %r13,%r12
 29d6210:	cmp    %rax,%rbx
 29d6213:	jae    29d6224 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1ac4>
 29d6219:	mov    %r10,%rdi
 29d621c:	mov    %r12,%r13
 29d621f:	jmp    29d62e1 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1b81>
 29d6224:	mov    %r10,%rdi
 29d6227:	mov    %r10d,0x28(%rsp)
 29d622c:	mov    %r8d,0x20(%rsp)
 29d6231:	mov    0x80(%rsp),%rax
 29d6239:	mov    %eax,(%rsp)
 29d623c:	mov    %edi,0x10(%rsp)
 29d6240:	mov    %esi,0x18(%rsp)
 29d6244:	mov    %edx,0x8(%rsp)
 29d6248:	mov    0xd8(%rsp),%rax
 29d6250:	mov    (%rax),%rcx
 29d6253:	mov    0x90(%rsp),%rax
 29d625b:	cmp    %rax,%rcx
 29d625e:	jae    29d6beb <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x248b>
 29d6264:	mov    %r12,%r13
 29d6267:	jmp    29d626f <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1b0f>
 29d626c:	mov    %r12,%r13
 29d626f:	sub    $0x4,%r13
 29d6273:	mov    0x0(%r13),%r8d
 29d6277:	sub    $0x4,%r14
 29d627b:	mov    %r8d,(%r14)
 29d627e:	mov    (%rsp),%edx
 29d6281:	mov    %rdx,0x80(%rsp)
 29d6289:	mov    0x10(%rsp),%edi
 29d628d:	mov    0x18(%rsp),%esi
 29d6291:	mov    0x8(%rsp),%edx
 29d6295:	mov    0x28(%rsp),%r10d
 29d629a:	mov    0x20(%rsp),%r8d
 29d629f:	mov    0xa0(%rsp),%r12
 29d62a7:	sub    $0x1,%r12d
 29d62ab:	mov    0x88(%rsp),%rbx
 29d62b3:	mov    %r12,0xa0(%rsp)
 29d62bb:	cmp    %rbx,%r13
 29d62be:	jne    29d62d9 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1b79>
 29d62c4:	mov    0x80(%rsp),%rax
 29d62cc:	mov    0x80(%rsp),%rcx
 29d62d4:	jmp    29d639f <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1c3f>
 29d62d9:	mov    %r13,%r12
 29d62dc:	jmp    29d6227 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1ac7>
 29d62e1:	mov    %r10d,0x20(%rsp)
 29d62e6:	mov    %r8d,0x28(%rsp)
 29d62eb:	mov    0x80(%rsp),%r9
 29d62f3:	mov    %r9d,0x8(%rsp)
 29d62f8:	mov    %edi,0x18(%rsp)
 29d62fc:	mov    %esi,0x10(%rsp)
 29d6300:	mov    %edx,(%rsp)
 29d6303:	mov    0xd8(%rsp),%rax
 29d630b:	mov    (%rax),%rax
 29d630e:	mov    0x90(%rsp),%rcx
 29d6316:	cmp    %rcx,%rax
 29d6319:	jae    29d6c22 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x24c2>
 29d631f:	mov    0x88(%rsp),%rax
 29d6327:	jmp    29d6334 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1bd4>
 29d632c:	mov    0x88(%rsp),%rax
 29d6334:	mov    0x88(%rsp),%rax
 29d633c:	mov    (%rax),%eax
 29d633e:	mov    %eax,(%rbx)
 29d6340:	mov    0x8(%rsp),%edx
 29d6344:	mov    %rdx,0x80(%rsp)
 29d634c:	mov    0x18(%rsp),%edi
 29d6350:	mov    0x10(%rsp),%esi
 29d6354:	mov    (%rsp),%edx
 29d6357:	mov    0x20(%rsp),%r10d
 29d635c:	mov    0x28(%rsp),%r8d
 29d6361:	mov    0x88(%rsp),%rax
 29d6369:	add    $0x4,%rax
 29d6370:	mov    %rax,0x88(%rsp)
 29d6378:	add    $0x4,%rbx
 29d637f:	add    $0x1,%r15d
 29d6386:	cmp    %r13,%rax
 29d6389:	jne    29d62e1 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1b81>
 29d638f:	mov    0x80(%rsp),%rax
 29d6397:	mov    0x80(%rsp),%rcx
 29d639f:	test   %ecx,%eax
 29d63a1:	je     29d6e0e <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x26ae>
 29d63a7:	test   %edi,%edi
 29d63a9:	je     29d6e10 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x26b0>
 29d63af:	mov    0x80(%rsp),%rax
 29d63b7:	mov    0x80(%rsp),%rcx
 29d63bf:	test   %ecx,%eax
 29d63c1:	je     29d6e12 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x26b2>
 29d63c7:	mov    0xd0(%rsp),%r13
 29d63cf:	mov    0x28(%r13),%rax
 29d63d3:	mov    %ecx,%r9d
 29d63d6:	mov    %r9,%r8
 29d63d9:	add    0x20(%r13),%r8
 29d63dd:	xor    %r10,%r10
 29d63e0:	cmp    %rax,%r9
 29d63e3:	cmova  %r10,%r8
 29d63e7:	mov    %edi,0x30(%r8)
 29d63eb:	mov    %esi,(%rsp)
 29d63ee:	mov    %edi,0x10(%rsp)
 29d63f2:	mov    0x80(%rsp),%rax
 29d63fa:	mov    %eax,0x18(%rsp)
 29d63fe:	mov    %edx,0x8(%rsp)
 29d6402:	mov    0x60(%rsp),%rcx
 29d6407:	mov    0x20(%rcx),%rsi
 29d640b:	mov    (%rsi),%eax
 29d640d:	mov    %eax,%ecx
 29d640f:	mov    $0x20,%edx
 29d6414:	lea    0x20(%rcx),%rdi
 29d6418:	mov    0x4(%rsi),%r8d
 29d641c:	cmp    %r8,%rdi
 29d641f:	ja     29d6c5e <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x24fe>
 29d6425:	lea    0x20(%rax),%edi
 29d6428:	mov    %edi,(%rsi)
 29d642a:	mov    0xd0(%rsp),%r13
 29d6432:	mov    0x20(%r13),%rdi
 29d6436:	lea    (%rdi,%rcx,1),%rsi
 29d643a:	movl   $0xb0000042,(%rdi,%rcx,1)
 29d6441:	mov    0x60(%rsp),%r8
 29d6446:	mov    0x28(%r8),%r8
 29d644a:	mov    0x120(%r8),%r8d
 29d6451:	mov    %r8d,0x4(%rdi,%rcx,1)
 29d6456:	mov    %edx,0x8(%rdi,%rcx,1)
 29d645a:	mov    0x78(%rsp),%r14
 29d645f:	mov    %r14,0x10(%rsi)
 29d6463:	mov    0x70(%rsp),%rdi
 29d6468:	mov    %edi,0x18(%rsi)
 29d646b:	mov    (%rsp),%ecx
 29d646e:	mov    %ecx,0x1c(%rsi)
 29d6471:	mov    0x10(%rsp),%ecx
 29d6475:	test   %ecx,%ecx
 29d6477:	je     29d6e14 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x26b4>
 29d647d:	test   %ecx,%ecx
 29d647f:	je     29d6e16 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x26b6>
 29d6485:	mov    0xd0(%rsp),%r13
 29d648d:	mov    0x28(%r13),%rdx
 29d6491:	mov    0x20(%r13),%rsi
 29d6495:	mov    %ecx,%r9d
 29d6498:	lea    0x10(%rsi,%r9,1),%r8
 29d649d:	xor    %rdi,%rdi
 29d64a0:	cmp    %rdx,%r9
 29d64a3:	cmova  %rdi,%r8
 29d64a7:	mov    (%r8),%r8d
 29d64aa:	mov    0x68(%rsp),%r9
 29d64af:	cmp    %r8d,%r9d
 29d64b2:	jae    29d6e18 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x26b8>
 29d64b8:	mov    %r8d,%r9d
 29d64bb:	shl    $0x2,%r9
 29d64bf:	shr    $0x20,%r9
 29d64c3:	test   %r9,%r9
 29d64c6:	jne    29d6e1a <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x26ba>
 29d64cc:	shl    $0x2,%r8d
 29d64d0:	add    $0x14,%r8d
 29d64d4:	jb     29d6e1c <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x26bc>
 29d64da:	add    %r8d,%ecx
 29d64dd:	jb     29d6e1e <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x26be>
 29d64e3:	mov    %ecx,%r9d
 29d64e6:	lea    (%rsi,%r9,1),%rcx
 29d64ea:	cmp    %rdx,%r9
 29d64ed:	cmova  %rdi,%rcx
 29d64f1:	mov    0x68(%rsp),%rdx
 29d64f6:	mov    %rdx,%rsi
 29d64f9:	shl    $0x2,%esi
 29d64fc:	lea    0x14(%rsi),%edi
 29d64ff:	sub    %edi,%r8d
 29d6502:	sub    %r8,%rcx
 29d6505:	mov    (%rcx),%edi
 29d6507:	test   %edi,%edi
 29d6509:	jne    29d6552 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1df2>
 29d650f:	mov    0x18(%rsp),%edi
 29d6513:	test   %edi,%edi
 29d6515:	je     29d6e20 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x26c0>
 29d651b:	test   %edi,%edi
 29d651d:	je     29d6e22 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x26c2>
 29d6523:	mov    0xd0(%rsp),%r13
 29d652b:	mov    0x28(%r13),%rcx
 29d652f:	mov    0xa8(%rsp),%rbx
 29d6537:	lea    0x1(%rbx),%r11
 29d653b:	mov    %edi,%edx
 29d653d:	mov    %rdx,%r8
 29d6540:	add    0x20(%r13),%r8
 29d6544:	xor    %rdi,%rdi
 29d6547:	cmp    %rcx,%rdx
 29d654a:	cmova  %rdi,%r8
 29d654e:	mov    %r11,0x18(%r8)
 29d6552:	mov    0x10(%rsp),%ecx
 29d6556:	test   %ecx,%ecx
 29d6558:	je     29d6e24 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x26c4>
 29d655e:	test   %eax,%eax
 29d6560:	je     29d6e26 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x26c6>
 29d6566:	test   %ecx,%ecx
 29d6568:	je     29d6e28 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x26c8>
 29d656e:	mov    0xd0(%rsp),%r13
 29d6576:	mov    0x28(%r13),%rdx
 29d657a:	mov    0x20(%r13),%rdi
 29d657e:	mov    %ecx,%r10d
 29d6581:	lea    0x10(%rdi,%r10,1),%r9
 29d6586:	xor    %r8,%r8
 29d6589:	cmp    %rdx,%r10
 29d658c:	cmova  %r8,%r9
 29d6590:	mov    (%r9),%r10d
 29d6593:	mov    0x68(%rsp),%r11
 29d6598:	cmp    %r10d,%r11d
 29d659b:	jae    29d6e2a <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x26ca>
 29d65a1:	mov    %r10d,%r9d
 29d65a4:	shl    $0x2,%r9
 29d65a8:	shr    $0x20,%r9
 29d65ac:	test   %r9,%r9
 29d65af:	jne    29d6e2c <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x26cc>
 29d65b5:	shl    $0x2,%r10d
 29d65b9:	add    $0x14,%r10d
 29d65bd:	jb     29d6e2e <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x26ce>
 29d65c3:	add    %r10d,%ecx
 29d65c6:	jb     29d6e30 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x26d0>
 29d65cc:	mov    %ecx,%r9d
 29d65cf:	lea    (%rdi,%r9,1),%rcx
 29d65d3:	cmp    %rdx,%r9
 29d65d6:	cmova  %r8,%rcx
 29d65da:	lea    0x14(%rsi),%edx
 29d65dd:	sub    %edx,%r10d
 29d65e0:	sub    %r10,%rcx
 29d65e3:	mov    %eax,(%rcx)
 29d65e5:	mov    (%rsp),%esi
 29d65e8:	mov    0x8(%rsp),%edx
 29d65ec:	mov    $0x1,%r10d
 29d65f2:	mov    %esi,0x8(%rsp)
 29d65f6:	mov    %edx,(%rsp)
 29d65f9:	test   %r10d,%r10d
 29d65fc:	jne    29d674c <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1fec>
 29d6602:	mov    0x60(%rsp),%rcx
 29d6607:	mov    0x20(%rcx),%rbx
 29d660b:	mov    (%rbx),%eax
 29d660d:	mov    %eax,%ecx
 29d660f:	mov    $0x20,%r13d
 29d6615:	lea    0x20(%rcx),%rdx
 29d6619:	mov    0x4(%rbx),%esi
 29d661c:	cmp    %rsi,%rdx
 29d661f:	ja     29d6c9f <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x253f>
 29d6625:	lea    0x20(%rax),%edx
 29d6628:	mov    %edx,(%rbx)
 29d662a:	mov    0xd0(%rsp),%rdx
 29d6632:	mov    0x20(%rdx),%rsi
 29d6636:	lea    (%rsi,%rcx,1),%rdx
 29d663a:	movl   $0xb0000042,(%rsi,%rcx,1)
 29d6641:	mov    0x60(%rsp),%rdi
 29d6646:	mov    0x28(%rdi),%rdi
 29d664a:	mov    0x120(%rdi),%edi
 29d6650:	mov    %edi,0x4(%rsi,%rcx,1)
 29d6654:	mov    %r13d,0x8(%rsi,%rcx,1)
 29d6659:	mov    %eax,0x10(%rsp)
 29d665d:	mov    %r14,0x10(%rdx)
 29d6661:	mov    0x70(%rsp),%rdi
 29d6666:	mov    %edi,0x18(%rdx)
 29d6669:	mov    0x8(%rsp),%ecx
 29d666d:	mov    %ecx,0x1c(%rdx)
 29d6670:	mov    0x60(%rsp),%rcx
 29d6675:	mov    0xa20(%rcx),%ecx
 29d667b:	mov    %ecx,0x8(%rsp)
 29d667f:	test   %eax,%eax
 29d6681:	je     29d6e32 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x26d2>
 29d6687:	test   %ecx,%ecx
 29d6689:	je     29d6e34 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x26d4>
 29d668f:	mov    (%rbx),%r8d
 29d6692:	mov    %r8d,%ecx
 29d6695:	lea    0x20(%rcx),%rax
 29d6699:	mov    0x4(%rbx),%edx
 29d669c:	cmp    %rdx,%rax
 29d669f:	ja     29d6cdb <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x257b>
 29d66a5:	lea    0x20(%r8),%eax
 29d66a9:	mov    %eax,(%rbx)
 29d66ab:	mov    0xd0(%rsp),%rax
 29d66b3:	mov    0x20(%rax),%rdx
 29d66b7:	lea    (%rdx,%rcx,1),%rsi
 29d66bb:	movl   $0xb0000072,(%rdx,%rcx,1)
 29d66c2:	mov    0x60(%rsp),%rax
 29d66c7:	mov    0x28(%rax),%rax
 29d66cb:	mov    0x13c(%rax),%eax
 29d66d1:	mov    %eax,0x4(%rdx,%rcx,1)
 29d66d5:	mov    %r13d,0x8(%rdx,%rcx,1)
 29d66da:	movl   $0xe,0x10(%rsi)
 29d66e1:	mov    0x10(%rsp),%eax
 29d66e5:	mov    %eax,0x14(%rsi)
 29d66e8:	mov    0x8(%rsp),%ecx
 29d66ec:	mov    %ecx,0x18(%rsi)
 29d66ef:	mov    %ecx,0x1c(%rsi)
 29d66f2:	mov    (%rsp),%esi
 29d66f5:	test   %esi,%esi
 29d66f7:	je     29d6e36 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x26d6>
 29d66fd:	test   %esi,%esi
 29d66ff:	je     29d6e38 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x26d8>
 29d6705:	mov    0xd0(%rsp),%r13
 29d670d:	mov    0x28(%r13),%rdi
 29d6711:	mov    0x20(%r13),%r10
 29d6715:	mov    %esi,%r9d
 29d6718:	lea    (%r10,%r9,1),%rsi
 29d671c:	xor    %r10,%r10
 29d671f:	cmp    %rdi,%r9
 29d6722:	cmova  %r10,%rsi
 29d6726:	mov    0x14(%rsi),%edx
 29d6729:	test   %edx,%edx
 29d672b:	je     29d6e3a <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x26da>
 29d6731:	test   %r8d,%r8d
 29d6734:	je     29d6e3c <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x26dc>
 29d673a:	mov    0x68(%rsp),%rcx
 29d673f:	mov    0x60(%rsp),%rsi
 29d6744:	mov    %rsi,%rdi
 29d6747:	call   29da9c0 <wasm[0]::function[1013]::helper::array_indexed_publish>
 29d674c:	mov    0xe0(%rsp),%rbx
 29d6754:	mov    0xe8(%rsp),%r12
 29d675c:	mov    0xf0(%rsp),%r13
 29d6764:	mov    0xf8(%rsp),%r14
 29d676c:	mov    0x100(%rsp),%r15
 29d6774:	add    $0x110,%rsp
 29d677b:	mov    %rbp,%rsp
 29d677e:	pop    %rbp
 29d677f:	ret    $0x10
 29d6782:	mov    0x60(%rsp),%rdi
 29d6787:	call   3018b79 <wasmtime_builtin_new_epoch>
 29d678c:	mov    %rax,0x90(%rsp)
 29d6794:	jmp    29d4803 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0xa3>
 29d6799:	mov    0xd0(%rsp),%r13
 29d67a1:	mov    0x8(%r13),%rcx
 29d67a5:	mov    %rcx,0x90(%rsp)
 29d67ad:	cmp    %rcx,%rax
 29d67b0:	jb     29d49d6 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x276>
 29d67b6:	mov    0x60(%rsp),%rdi
 29d67bb:	call   3018b79 <wasmtime_builtin_new_epoch>
 29d67c0:	mov    %rax,0x90(%rsp)
 29d67c8:	jmp    29d49d6 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x276>
 29d67cd:	mov    $0xa8000006,%esi
 29d67d2:	mov    0x60(%rsp),%rax
 29d67d7:	mov    0x28(%rax),%rdx
 29d67db:	mov    0x1a0(%rdx),%edx
 29d67e1:	mov    $0x10,%r8d
 29d67e7:	mov    0x60(%rsp),%rdi
 29d67ec:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
 29d67f1:	mov    %eax,%ecx
 29d67f3:	mov    0xd0(%rsp),%r13
 29d67fb:	add    0x20(%r13),%rcx
 29d67ff:	jmp    29d4ab4 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x354>
 29d6804:	mov    0xd0(%rsp),%r13
 29d680c:	mov    0x8(%r13),%rcx
 29d6810:	mov    %rcx,%rsi
 29d6813:	mov    %rcx,0x90(%rsp)
 29d681b:	cmp    %rsi,%rax
 29d681e:	jb     29d4b6d <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x40d>
 29d6824:	mov    0x60(%rsp),%rdi
 29d6829:	call   3018b79 <wasmtime_builtin_new_epoch>
 29d682e:	mov    %rax,0x90(%rsp)
 29d6836:	jmp    29d4b6d <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x40d>
 29d683b:	mov    0xd0(%rsp),%r13
 29d6843:	mov    0x8(%r13),%rcx
 29d6847:	mov    %rcx,0x90(%rsp)
 29d684f:	cmp    %rcx,%rax
 29d6852:	jb     29d4bf7 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x497>
 29d6858:	mov    0x60(%rsp),%rdi
 29d685d:	call   3018b79 <wasmtime_builtin_new_epoch>
 29d6862:	mov    %rax,0x90(%rsp)
 29d686a:	jmp    29d4bf7 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x497>
 29d686f:	mov    0xd0(%rsp),%r13
 29d6877:	mov    0x8(%r13),%rcx
 29d687b:	mov    %rcx,0x90(%rsp)
 29d6883:	cmp    %rcx,%rax
 29d6886:	jb     29d4d40 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x5e0>
 29d688c:	mov    0x60(%rsp),%rdi
 29d6891:	call   3018b79 <wasmtime_builtin_new_epoch>
 29d6896:	mov    %rax,0x90(%rsp)
 29d689e:	jmp    29d4d40 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x5e0>
 29d68a3:	mov    0xd0(%rsp),%r13
 29d68ab:	mov    0x8(%r13),%rcx
 29d68af:	mov    %rcx,0x90(%rsp)
 29d68b7:	cmp    %rcx,%rax
 29d68ba:	jb     29d4e20 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x6c0>
 29d68c0:	mov    0x60(%rsp),%rdi
 29d68c5:	call   3018b79 <wasmtime_builtin_new_epoch>
 29d68ca:	mov    %rax,0x90(%rsp)
 29d68d2:	jmp    29d4e20 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x6c0>
 29d68d7:	mov    0xd0(%rsp),%r13
 29d68df:	mov    0x8(%r13),%rax
 29d68e3:	mov    %rax,0x90(%rsp)
 29d68eb:	cmp    %rax,%rcx
 29d68ee:	jb     29d4ec6 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x766>
 29d68f4:	mov    0x60(%rsp),%rdi
 29d68f9:	call   3018b79 <wasmtime_builtin_new_epoch>
 29d68fe:	mov    %rax,0x90(%rsp)
 29d6906:	mov    %rbx,%rcx
 29d6909:	mov    %r14,%rdx
 29d690c:	mov    %r12,%rsi
 29d690f:	jmp    29d4ecf <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x76f>
 29d6914:	mov    $0xa8000006,%esi
 29d6919:	mov    0x60(%rsp),%rax
 29d691e:	mov    0x28(%rax),%rax
 29d6922:	mov    0x1a4(%rax),%edx
 29d6928:	mov    $0x10,%r8d
 29d692e:	mov    0x60(%rsp),%rdi
 29d6933:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
 29d6938:	mov    %eax,%ecx
 29d693a:	mov    0xd0(%rsp),%r13
 29d6942:	add    0x20(%r13),%rcx
 29d6946:	jmp    29d4f78 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x818>
 29d694b:	mov    0xd0(%rsp),%r13
 29d6953:	mov    0x8(%r13),%rcx
 29d6957:	mov    %rcx,0x90(%rsp)
 29d695f:	cmp    %rcx,%rax
 29d6962:	jb     29d5030 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x8d0>
 29d6968:	mov    0x60(%rsp),%rdi
 29d696d:	call   3018b79 <wasmtime_builtin_new_epoch>
 29d6972:	mov    %rax,0x90(%rsp)
 29d697a:	jmp    29d5030 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x8d0>
 29d697f:	mov    0xd0(%rsp),%r13
 29d6987:	mov    0x8(%r13),%rcx
 29d698b:	mov    %rcx,0x90(%rsp)
 29d6993:	cmp    %rcx,%rax
 29d6996:	jb     29d50ba <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x95a>
 29d699c:	mov    0x60(%rsp),%rdi
 29d69a1:	call   3018b79 <wasmtime_builtin_new_epoch>
 29d69a6:	mov    %rax,0x90(%rsp)
 29d69ae:	jmp    29d50ba <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x95a>
 29d69b3:	mov    0xd0(%rsp),%r13
 29d69bb:	mov    0x8(%r13),%rsi
 29d69bf:	mov    %rsi,0x90(%rsp)
 29d69c7:	cmp    %rsi,%rax
 29d69ca:	jb     29d51fd <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0xa9d>
 29d69d0:	mov    0x60(%rsp),%rdi
 29d69d5:	call   3018b79 <wasmtime_builtin_new_epoch>
 29d69da:	mov    %rax,0x90(%rsp)
 29d69e2:	jmp    29d51fd <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0xa9d>
 29d69e7:	mov    0xd0(%rsp),%r13
 29d69ef:	mov    0x8(%r13),%rcx
 29d69f3:	mov    %rcx,0x90(%rsp)
 29d69fb:	cmp    %rcx,%rax
 29d69fe:	jb     29d52da <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0xb7a>
 29d6a04:	mov    0x60(%rsp),%rdi
 29d6a09:	call   3018b79 <wasmtime_builtin_new_epoch>
 29d6a0e:	mov    %rax,0x90(%rsp)
 29d6a16:	jmp    29d52da <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0xb7a>
 29d6a1b:	mov    0xd0(%rsp),%r13
 29d6a23:	mov    0x8(%r13),%rax
 29d6a27:	mov    %rax,0x90(%rsp)
 29d6a2f:	cmp    %rax,%r11
 29d6a32:	jb     29d5383 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0xc23>
 29d6a38:	mov    0x60(%rsp),%rdi
 29d6a3d:	call   3018b79 <wasmtime_builtin_new_epoch>
 29d6a42:	mov    %rax,0x90(%rsp)
 29d6a4a:	mov    %rbx,%rcx
 29d6a4d:	mov    %r14,%rdx
 29d6a50:	mov    %r12,%rsi
 29d6a53:	jmp    29d538c <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0xc2c>
 29d6a58:	mov    $0xa800000e,%esi
 29d6a5d:	mov    0x60(%rsp),%rax
 29d6a62:	mov    0x28(%rax),%rax
 29d6a66:	mov    0x19c(%rax),%edx
 29d6a6c:	mov    $0x10,%r8d
 29d6a72:	mov    0x60(%rsp),%rdi
 29d6a77:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
 29d6a7c:	mov    %eax,%ecx
 29d6a7e:	mov    0xd0(%rsp),%rdx
 29d6a86:	add    0x20(%rdx),%rcx
 29d6a8a:	jmp    29d58ef <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x118f>
 29d6a8f:	mov    0xd0(%rsp),%r13
 29d6a97:	mov    0x8(%r13),%rcx
 29d6a9b:	mov    %rcx,0x90(%rsp)
 29d6aa3:	cmp    %rcx,%rax
 29d6aa6:	jb     29d599d <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x123d>
 29d6aac:	mov    0x60(%rsp),%rdi
 29d6ab1:	call   3018b79 <wasmtime_builtin_new_epoch>
 29d6ab6:	mov    %rax,0x90(%rsp)
 29d6abe:	jmp    29d599d <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x123d>
 29d6ac3:	mov    0xd0(%rsp),%r13
 29d6acb:	mov    0x8(%r13),%rdx
 29d6acf:	mov    %rdx,%rsi
 29d6ad2:	mov    %rdx,0x90(%rsp)
 29d6ada:	cmp    %rsi,%rax
 29d6add:	jb     29d5a34 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x12d4>
 29d6ae3:	mov    0x60(%rsp),%rdi
 29d6ae8:	call   3018b79 <wasmtime_builtin_new_epoch>
 29d6aed:	mov    %rax,0x90(%rsp)
 29d6af5:	mov    0xc8(%rsp),%rdi
 29d6afd:	jmp    29d5a3c <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x12dc>
 29d6b02:	mov    $0xb0000042,%esi
 29d6b07:	mov    $0x20,%ecx
 29d6b0c:	mov    0xa0(%rsp),%r13
 29d6b14:	mov    %r13,%rdx
 29d6b17:	mov    0x60(%rsp),%rdi
 29d6b1c:	mov    0xa8(%rsp),%r8
 29d6b24:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
 29d6b29:	mov    %eax,%esi
 29d6b2b:	mov    0xd0(%rsp),%rdi
 29d6b33:	add    0x20(%rdi),%rsi
 29d6b37:	mov    0xc0(%rsp),%rcx
 29d6b3f:	mov    0x88(%rsp),%rdx
 29d6b47:	jmp    29d5c62 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1502>
 29d6b4c:	mov    0xd0(%rsp),%r13
 29d6b54:	mov    0x8(%r13),%rcx
 29d6b58:	mov    %rcx,0x90(%rsp)
 29d6b60:	cmp    %rcx,%rax
 29d6b63:	jb     29d5f55 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x17f5>
 29d6b69:	mov    0x60(%rsp),%rdi
 29d6b6e:	call   3018b79 <wasmtime_builtin_new_epoch>
 29d6b73:	mov    %rax,0x90(%rsp)
 29d6b7b:	jmp    29d5f55 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x17f5>
 29d6b80:	mov    $0xa800000e,%esi
 29d6b85:	mov    0x60(%rsp),%rax
 29d6b8a:	mov    0x28(%rax),%rax
 29d6b8e:	mov    0x19c(%rax),%edx
 29d6b94:	mov    $0x10,%r8d
 29d6b9a:	mov    0x60(%rsp),%rdi
 29d6b9f:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
 29d6ba4:	mov    %eax,%ecx
 29d6ba6:	mov    0xd0(%rsp),%rdx
 29d6bae:	add    0x20(%rdx),%rcx
 29d6bb2:	jmp    29d6019 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x18b9>
 29d6bb7:	mov    0xd0(%rsp),%r13
 29d6bbf:	mov    0x8(%r13),%rax
 29d6bc3:	mov    %rax,0x90(%rsp)
 29d6bcb:	cmp    %rax,%rcx
 29d6bce:	jb     29d60d3 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1973>
 29d6bd4:	mov    0x60(%rsp),%rdi
 29d6bd9:	call   3018b79 <wasmtime_builtin_new_epoch>
 29d6bde:	mov    %rax,0x90(%rsp)
 29d6be6:	jmp    29d60d3 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1973>
 29d6beb:	mov    0xd0(%rsp),%r13
 29d6bf3:	mov    0x8(%r13),%rax
 29d6bf7:	mov    %rax,0x90(%rsp)
 29d6bff:	cmp    %rax,%rcx
 29d6c02:	jb     29d626c <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1b0c>
 29d6c08:	mov    0x60(%rsp),%rdi
 29d6c0d:	call   3018b79 <wasmtime_builtin_new_epoch>
 29d6c12:	mov    %rax,0x90(%rsp)
 29d6c1a:	mov    %r12,%r13
 29d6c1d:	jmp    29d626f <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1b0f>
 29d6c22:	mov    0xd0(%rsp),%rcx
 29d6c2a:	mov    0x8(%rcx),%rcx
 29d6c2e:	mov    %rcx,0x90(%rsp)
 29d6c36:	cmp    %rcx,%rax
 29d6c39:	jb     29d632c <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1bcc>
 29d6c3f:	mov    0x60(%rsp),%rdi
 29d6c44:	call   3018b79 <wasmtime_builtin_new_epoch>
 29d6c49:	mov    %rax,0x90(%rsp)
 29d6c51:	mov    0x88(%rsp),%rax
 29d6c59:	jmp    29d6334 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1bd4>
 29d6c5e:	mov    $0xb0000042,%esi
 29d6c63:	mov    0x60(%rsp),%rcx
 29d6c68:	mov    0x28(%rcx),%rax
 29d6c6c:	mov    0x120(%rax),%edx
 29d6c72:	mov    $0x20,%ecx
 29d6c77:	mov    $0x10,%r8d
 29d6c7d:	mov    0x60(%rsp),%rdi
 29d6c82:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
 29d6c87:	mov    %eax,%esi
 29d6c89:	mov    0xd0(%rsp),%r13
 29d6c91:	add    0x20(%r13),%rsi
 29d6c95:	mov    0x78(%rsp),%r14
 29d6c9a:	jmp    29d645f <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1cff>
 29d6c9f:	mov    $0xb0000042,%esi
 29d6ca4:	mov    0x60(%rsp),%rcx
 29d6ca9:	mov    0x28(%rcx),%rax
 29d6cad:	mov    0x120(%rax),%edx
 29d6cb3:	mov    $0x20,%ecx
 29d6cb8:	mov    $0x10,%r8d
 29d6cbe:	mov    0x60(%rsp),%rdi
 29d6cc3:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
 29d6cc8:	mov    %eax,%edx
 29d6cca:	mov    0xd0(%rsp),%r8
 29d6cd2:	add    0x20(%r8),%rdx
 29d6cd6:	jmp    29d6659 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1ef9>
 29d6cdb:	mov    $0xb0000072,%esi
 29d6ce0:	mov    0x60(%rsp),%rcx
 29d6ce5:	mov    0x28(%rcx),%rax
 29d6ce9:	mov    0x13c(%rax),%edx
 29d6cef:	mov    $0x20,%ecx
 29d6cf4:	mov    $0x10,%r8d
 29d6cfa:	mov    0x60(%rsp),%rdi
 29d6cff:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
 29d6d04:	mov    %eax,%esi
 29d6d06:	mov    0xd0(%rsp),%r13
 29d6d0e:	add    0x20(%r13),%rsi
 29d6d12:	mov    %rax,%r8
 29d6d15:	jmp    29d66da <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1f7a>
 29d6d1a:	ud2
 29d6d1c:	ud2
 29d6d1e:	ud2
 29d6d20:	ud2
 29d6d22:	ud2
 29d6d24:	ud2
 29d6d26:	ud2
 29d6d28:	ud2
 29d6d2a:	ud2
 29d6d2c:	ud2
 29d6d2e:	ud2
 29d6d30:	ud2
 29d6d32:	ud2
 29d6d34:	ud2
 29d6d36:	ud2
 29d6d38:	ud2
 29d6d3a:	ud2
 29d6d3c:	ud2
 29d6d3e:	ud2
 29d6d40:	ud2
 29d6d42:	ud2
 29d6d44:	ud2
 29d6d46:	ud2
 29d6d48:	ud2
 29d6d4a:	ud2
 29d6d4c:	ud2
 29d6d4e:	ud2
 29d6d50:	ud2
 29d6d52:	ud2
 29d6d54:	ud2
 29d6d56:	ud2
 29d6d58:	ud2
 29d6d5a:	ud2
 29d6d5c:	ud2
 29d6d5e:	ud2
 29d6d60:	ud2
 29d6d62:	ud2
 29d6d64:	ud2
 29d6d66:	ud2
 29d6d68:	ud2
 29d6d6a:	ud2
 29d6d6c:	ud2
 29d6d6e:	ud2
 29d6d70:	ud2
 29d6d72:	ud2
 29d6d74:	ud2
 29d6d76:	ud2
 29d6d78:	ud2
 29d6d7a:	ud2
 29d6d7c:	ud2
 29d6d7e:	ud2
 29d6d80:	ud2
 29d6d82:	ud2
 29d6d84:	ud2
 29d6d86:	ud2
 29d6d88:	ud2
 29d6d8a:	ud2
 29d6d8c:	ud2
 29d6d8e:	ud2
 29d6d90:	ud2
 29d6d92:	ud2
 29d6d94:	ud2
 29d6d96:	ud2
 29d6d98:	ud2
 29d6d9a:	ud2
 29d6d9c:	ud2
 29d6d9e:	ud2
 29d6da0:	ud2
 29d6da2:	ud2
 29d6da4:	ud2
 29d6da6:	ud2
 29d6da8:	ud2
 29d6daa:	ud2
 29d6dac:	ud2
 29d6dae:	ud2
 29d6db0:	ud2
 29d6db2:	ud2
 29d6db4:	ud2
 29d6db6:	ud2
 29d6db8:	ud2
 29d6dba:	ud2
 29d6dbc:	ud2
 29d6dbe:	ud2
 29d6dc0:	ud2
 29d6dc2:	ud2
 29d6dc4:	ud2
 29d6dc6:	ud2
 29d6dc8:	ud2
 29d6dca:	ud2
 29d6dcc:	ud2
 29d6dce:	ud2
 29d6dd0:	ud2
 29d6dd2:	ud2
 29d6dd4:	ud2
 29d6dd6:	ud2
 29d6dd8:	ud2
 29d6dda:	ud2
 29d6ddc:	ud2
 29d6dde:	ud2
 29d6de0:	ud2
 29d6de2:	ud2
 29d6de4:	ud2
 29d6de6:	ud2
 29d6de8:	ud2
 29d6dea:	ud2
 29d6dec:	ud2
 29d6dee:	ud2
 29d6df0:	ud2
 29d6df2:	ud2
 29d6df4:	ud2
 29d6df6:	ud2
 29d6df8:	ud2
 29d6dfa:	ud2
 29d6dfc:	ud2
 29d6dfe:	ud2
 29d6e00:	ud2
 29d6e02:	ud2
 29d6e04:	ud2
 29d6e06:	ud2
 29d6e08:	ud2
 29d6e0a:	ud2
 29d6e0c:	ud2
 29d6e0e:	ud2
 29d6e10:	ud2
 29d6e12:	ud2
 29d6e14:	ud2
 29d6e16:	ud2
 29d6e18:	ud2
 29d6e1a:	ud2
 29d6e1c:	ud2
 29d6e1e:	ud2
 29d6e20:	ud2
 29d6e22:	ud2
 29d6e24:	ud2
 29d6e26:	ud2
 29d6e28:	ud2
 29d6e2a:	ud2
 29d6e2c:	ud2
 29d6e2e:	ud2
 29d6e30:	ud2
 29d6e32:	ud2
 29d6e34:	ud2
 29d6e36:	ud2
 29d6e38:	ud2
 29d6e3a:	ud2
 29d6e3c:	ud2
