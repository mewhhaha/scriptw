
/workspace/scriptw/target/performance-dense-numbers-20261030/v2/native-cause/candidate/runtime-portable.elf:     file format elf64-x86-64


Disassembly of section .text:

000000000048a880 <wasm[0]::function[160]::builtin::Array.prototype.push>:
  48a880:	push   %rbp
  48a881:	mov    %rsp,%rbp
  48a884:	mov    0x8(%rdi),%r10
  48a888:	mov    0x18(%r10),%r10
  48a88c:	add    $0x140,%r10
  48a893:	cmp    %rsp,%r10
  48a896:	ja     48bd8e <wasm[0]::function[160]::builtin::Array.prototype.push+0x150e>
  48a89c:	sub    $0x130,%rsp
  48a8a3:	mov    %rbx,0x100(%rsp)
  48a8ab:	mov    %r12,0x108(%rsp)
  48a8b3:	mov    %r13,0x110(%rsp)
  48a8bb:	mov    %r14,0x118(%rsp)
  48a8c3:	mov    %r15,0x120(%rsp)
  48a8cb:	mov    %r8,%r13
  48a8ce:	mov    %rcx,%r14
  48a8d1:	mov    0x28(%rbp),%r12
  48a8d5:	mov    0x30(%rbp),%r8
  48a8d9:	mov    0x40(%rbp),%r10
  48a8dd:	mov    %edx,0x50(%rsp)
  48a8e1:	mov    %r9d,0x40(%rsp)
  48a8e6:	mov    %r8d,0x68(%rsp)
  48a8eb:	mov    %r10d,0x60(%rsp)
  48a8f0:	mov    0x18(%rdi),%rax
  48a8f4:	mov    (%rax),%rcx
  48a8f7:	mov    %rax,0xf8(%rsp)
  48a8ff:	mov    0x8(%rdi),%rbx
  48a903:	mov    %rdi,0xb0(%rsp)
  48a90b:	mov    0x8(%rbx),%rax
  48a90f:	cmp    %rax,%rcx
  48a912:	jae    48bc65 <wasm[0]::function[160]::builtin::Array.prototype.push+0x13e5>
  48a918:	mov    %rax,0xc0(%rsp)
  48a920:	mov    0x50(%rsp),%edx
  48a924:	test   %edx,%edx
  48a926:	je     48bd90 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1510>
  48a92c:	test   %edx,%edx
  48a92e:	je     48bd92 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1512>
  48a934:	mov    0x28(%rbx),%rcx
  48a938:	mov    0x20(%rbx),%rsi
  48a93c:	mov    %edx,%eax
  48a93e:	xor    %rdx,%rdx
  48a941:	lea    (%rsi,%rax,1),%rdi
  48a945:	cmp    %rcx,%rax
  48a948:	cmova  %rdx,%rdi
  48a94c:	mov    0x18(%rdi),%r8d
  48a950:	mov    %r8d,0x50(%rsp)
  48a955:	mov    0x60(%rsp),%edi
  48a959:	test   %edi,%edi
  48a95b:	je     48bd94 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1514>
  48a961:	test   %r8d,%r8d
  48a964:	je     48bd96 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1516>
  48a96a:	test   %r8d,%r8d
  48a96d:	je     48bd98 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1518>
  48a973:	mov    %r8d,%r8d
  48a976:	lea    (%rsi,%r8,1),%rax
  48a97a:	cmp    %rcx,%r8
  48a97d:	cmova  %rdx,%rax
  48a981:	mov    0x34(%rax),%ecx
  48a984:	test   %ecx,%ecx
  48a986:	jne    48a994 <wasm[0]::function[160]::builtin::Array.prototype.push+0x114>
  48a98c:	mov    %rdi,%rcx
  48a98f:	jmp    48a99c <wasm[0]::function[160]::builtin::Array.prototype.push+0x11c>
  48a994:	test   %ecx,%ecx
  48a996:	je     48bd9a <wasm[0]::function[160]::builtin::Array.prototype.push+0x151a>
  48a99c:	mov    %ecx,0x60(%rsp)
  48a9a0:	mov    0x68(%rsp),%eax
  48a9a4:	test   %eax,%eax
  48a9a6:	je     48a9e5 <wasm[0]::function[160]::builtin::Array.prototype.push+0x165>
  48a9ac:	mov    0x68(%rsp),%edx
  48a9b0:	test   %edx,%edx
  48a9b2:	je     48bd9c <wasm[0]::function[160]::builtin::Array.prototype.push+0x151c>
  48a9b8:	mov    0x28(%rbx),%rcx
  48a9bc:	mov    0x20(%rbx),%rsi
  48a9c0:	mov    %edx,%eax
  48a9c2:	lea    0x10(%rsi,%rax,1),%rdx
  48a9c7:	xor    %rsi,%rsi
  48a9ca:	cmp    %rcx,%rax
  48a9cd:	cmova  %rsi,%rdx
  48a9d1:	mov    (%rdx),%ecx
  48a9d3:	cmp    %r12,%rcx
  48a9d6:	jne    48bd9e <wasm[0]::function[160]::builtin::Array.prototype.push+0x151e>
  48a9dc:	mov    0x68(%rsp),%eax
  48a9e0:	jmp    48aa50 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1d0>
  48a9e5:	test   %r12,%r12
  48a9e8:	jne    48bda0 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1520>
  48a9ee:	mov    0xb0(%rsp),%rcx
  48a9f6:	mov    0x20(%rcx),%r9
  48a9fa:	mov    (%r9),%eax
  48a9fd:	mov    %eax,%r8d
  48aa00:	lea    0x20(%r8),%r10
  48aa04:	mov    0x4(%r9),%r11d
  48aa08:	cmp    %r11,%r10
  48aa0b:	ja     48bc7f <wasm[0]::function[160]::builtin::Array.prototype.push+0x13ff>
  48aa11:	lea    0x20(%rax),%r11d
  48aa15:	mov    %r11d,(%r9)
  48aa18:	mov    0x20(%rbx),%rdx
  48aa1c:	lea    (%rdx,%r8,1),%rcx
  48aa20:	movl   $0xa800000e,(%rdx,%r8,1)
  48aa28:	mov    0xb0(%rsp),%rsi
  48aa30:	mov    0x28(%rsi),%rsi
  48aa34:	mov    0x1b4(%rsi),%esi
  48aa3a:	mov    %esi,0x4(%rdx,%r8,1)
  48aa3f:	mov    $0x20,%esi
  48aa44:	mov    %esi,0x8(%rdx,%r8,1)
  48aa49:	movl   $0x0,0x10(%rcx)
  48aa50:	mov    %eax,0x68(%rsp)
  48aa54:	test   %eax,%eax
  48aa56:	je     48bda2 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1522>
  48aa5c:	test   %eax,%eax
  48aa5e:	je     48bda4 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1524>
  48aa64:	mov    0x28(%rbx),%rcx
  48aa68:	mov    0x20(%rbx),%rdx
  48aa6c:	mov    %eax,%edi
  48aa6e:	lea    0x10(%rdx,%rdi,1),%rsi
  48aa73:	xor    %rax,%rax
  48aa76:	cmp    %rcx,%rdi
  48aa79:	cmova  %rax,%rsi
  48aa7d:	mov    (%rsi),%esi
  48aa7f:	mov    0x50(%rsp),%esi
  48aa83:	test   %esi,%esi
  48aa85:	je     48bda6 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1526>
  48aa8b:	test   %esi,%esi
  48aa8d:	je     48bda8 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1528>
  48aa93:	mov    %esi,%esi
  48aa95:	add    %rsi,%rdx
  48aa98:	cmp    %rcx,%rsi
  48aa9b:	cmova  %rax,%rdx
  48aa9f:	mov    0x14(%rdx),%eax
  48aaa2:	mov    %eax,0x58(%rsp)
  48aaa6:	mov    0x18(%rdx),%eax
  48aaa9:	mov    0xb0(%rsp),%rcx
  48aab1:	mov    0x8c0(%rcx),%edx
  48aab7:	test   %edx,%edx
  48aab9:	je     48bdaa <wasm[0]::function[160]::builtin::Array.prototype.push+0x152a>
  48aabf:	mov    0x40(%rsp),%r9d
  48aac4:	mov    %r14,%rcx
  48aac7:	mov    %r13,%r8
  48aaca:	mov    0xb0(%rsp),%rsi
  48aad2:	mov    0xb0(%rsp),%rdi
  48aada:	call   2a63140 <wasm[0]::function[1041]::helper::value_to_object>
  48aadf:	mov    %rax,0xe8(%rsp)
  48aae7:	mov    %rcx,0xf0(%rsp)
  48aaef:	mov    %edx,0x40(%rsp)
  48aaf3:	cmp    $0x1,%esi
  48aaf6:	je     48bc1f <wasm[0]::function[160]::builtin::Array.prototype.push+0x139f>
  48aafc:	mov    $0x8c,%edx
  48ab01:	mov    0xb0(%rsp),%rsi
  48ab09:	mov    0xb0(%rsp),%rdi
  48ab11:	call   2f307a0 <wasm[0]::function[1102]::helper::pooled_string_resolve>
  48ab16:	test   %eax,%eax
  48ab18:	je     48bdac <wasm[0]::function[160]::builtin::Array.prototype.push+0x152c>
  48ab1e:	mov    0x60(%rsp),%ecx
  48ab22:	test   %ecx,%ecx
  48ab24:	je     48bdae <wasm[0]::function[160]::builtin::Array.prototype.push+0x152e>
  48ab2a:	mov    0x40(%rsp),%r8d
  48ab2f:	mov    0x58(%rsp),%edx
  48ab33:	mov    $0x4,%esi
  48ab38:	xor    %rdi,%rdi
  48ab3b:	mov    0xf0(%rsp),%r9
  48ab43:	mov    %r9,(%rsp)
  48ab47:	mov    %r8d,0x8(%rsp)
  48ab4c:	mov    %esi,0x10(%rsp)
  48ab50:	mov    %rdi,0x18(%rsp)
  48ab55:	mov    %eax,0x20(%rsp)
  48ab59:	mov    %edx,0x28(%rsp)
  48ab5d:	mov    %ecx,0x30(%rsp)
  48ab61:	mov    0xf0(%rsp),%rcx
  48ab69:	mov    0xe8(%rsp),%rdx
  48ab71:	mov    0xb0(%rsp),%rsi
  48ab79:	mov    0xb0(%rsp),%rdi
  48ab81:	mov    0xe8(%rsp),%r9
  48ab89:	call   29e0f20 <wasm[0]::function[1015]::helper::object_read>
  48ab8e:	sub    $0x40,%rsp
  48ab92:	mov    %rdx,%r8
  48ab95:	mov    %rax,%rdx
  48ab98:	cmp    $0x1,%esi
  48ab9b:	je     48bbe3 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1363>
  48aba1:	mov    0x60(%rsp),%eax
  48aba5:	test   %eax,%eax
  48aba7:	je     48bdb0 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1530>
  48abad:	mov    0x58(%rsp),%r9d
  48abb2:	mov    %eax,(%rsp)
  48abb5:	mov    0xb0(%rsp),%rsi
  48abbd:	mov    0xb0(%rsp),%rdi
  48abc5:	call   2aef700 <wasm[0]::function[1062]::helper::value_to_number>
  48abca:	sub    $0x10,%rsp
  48abce:	mov    %rdi,%r15
  48abd1:	mov    %rax,0xe0(%rsp)
  48abd9:	mov    %edx,0x48(%rsp)
  48abdd:	xor    %r14,%r14
  48abe0:	test   %esi,%esi
  48abe2:	mov    %rsi,%r12
  48abe5:	je     48abf6 <wasm[0]::function[160]::builtin::Array.prototype.push+0x376>
  48abeb:	mov    %r12,%rsi
  48abee:	mov    %rcx,%r13
  48abf1:	jmp    48aca7 <wasm[0]::function[160]::builtin::Array.prototype.push+0x427>
  48abf6:	movq   %rcx,%xmm0
  48abfb:	mov    %rcx,%r13
  48abfe:	ucomisd %xmm0,%xmm0
  48ac02:	setp   %al
  48ac05:	setne  %cl
  48ac08:	or     %ecx,%eax
  48ac0a:	xorpd  %xmm1,%xmm1
  48ac0e:	ucomisd %xmm0,%xmm1
  48ac12:	setae  %cl
  48ac15:	or     %ecx,%eax
  48ac17:	test   %al,%al
  48ac19:	jne    48aca1 <wasm[0]::function[160]::builtin::Array.prototype.push+0x421>
  48ac1f:	ucomisd 0x1219(%rip),%xmm0        # 48be40 <wasm[0]::function[160]::builtin::Array.prototype.push+0x15c0>
  48ac27:	ja     48ac92 <wasm[0]::function[160]::builtin::Array.prototype.push+0x412>
  48ac2d:	mov    0xb0(%rsp),%rdi
  48ac35:	call   3018eff <wasmtime_builtin_trunc_f64>
  48ac3a:	movabs $0x43e0000000000000,%rax
  48ac44:	movq   %rax,%xmm2
  48ac49:	ucomisd %xmm2,%xmm0
  48ac4d:	jae    48ac6a <wasm[0]::function[160]::builtin::Array.prototype.push+0x3ea>
  48ac53:	jp     48bdb2 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1532>
  48ac59:	cvttsd2si %xmm0,%r14
  48ac5e:	cmp    $0x0,%r14
  48ac62:	jge    48aca4 <wasm[0]::function[160]::builtin::Array.prototype.push+0x424>
  48ac68:	ud2
  48ac6a:	movaps %xmm0,%xmm1
  48ac6d:	subsd  %xmm2,%xmm1
  48ac71:	cvttsd2si %xmm1,%r14
  48ac76:	cmp    $0x0,%r14
  48ac7a:	jl     48bdb4 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1534>
  48ac80:	movabs $0x8000000000000000,%rax
  48ac8a:	add    %rax,%r14
  48ac8d:	jmp    48aca4 <wasm[0]::function[160]::builtin::Array.prototype.push+0x424>
  48ac92:	movabs $0x1fffffffffffff,%r14
  48ac9c:	jmp    48aca4 <wasm[0]::function[160]::builtin::Array.prototype.push+0x424>
  48aca1:	xor    %r14,%r14
  48aca4:	mov    %r12,%rsi
  48aca7:	cmp    $0x1,%esi
  48acaa:	je     48bb9b <wasm[0]::function[160]::builtin::Array.prototype.push+0x131b>
  48acb0:	mov    0x68(%rsp),%eax
  48acb4:	test   %eax,%eax
  48acb6:	je     48bdb6 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1536>
  48acbc:	test   %eax,%eax
  48acbe:	je     48bdb8 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1538>
  48acc4:	mov    0x28(%rbx),%rcx
  48acc8:	mov    0x20(%rbx),%rsi
  48accc:	mov    %eax,%edx
  48acce:	lea    0x10(%rsi,%rdx,1),%rax
  48acd3:	xor    %rsi,%rsi
  48acd6:	cmp    %rcx,%rdx
  48acd9:	cmova  %rsi,%rax
  48acdd:	mov    (%rax),%r12d
  48ace0:	mov    %r12d,%eax
  48ace3:	mov    %r12,0xd8(%rsp)
  48aceb:	lea    (%r14,%rax,1),%r12
  48acef:	cmp    0x115a(%rip),%r12        # 48be50 <wasm[0]::function[160]::builtin::Array.prototype.push+0x15d0>
  48acf6:	ja     48b9bd <wasm[0]::function[160]::builtin::Array.prototype.push+0x113d>
  48acfc:	mov    0x40(%rsp),%ecx
  48ad00:	xor    %eax,%eax
  48ad02:	test   %ecx,%ecx
  48ad04:	je     48ad4d <wasm[0]::function[160]::builtin::Array.prototype.push+0x4cd>
  48ad0a:	xor    %eax,%eax
  48ad0c:	test   $0x1,%ecx
  48ad12:	jne    48ad4d <wasm[0]::function[160]::builtin::Array.prototype.push+0x4cd>
  48ad18:	mov    0x28(%rbx),%rsi
  48ad1c:	mov    0x20(%rbx),%r8
  48ad20:	mov    %ecx,%edi
  48ad22:	lea    0x4(%r8,%rdi,1),%rax
  48ad27:	xor    %r8,%r8
  48ad2a:	cmp    %rsi,%rdi
  48ad2d:	cmova  %r8,%rax
  48ad31:	mov    (%rax),%esi
  48ad33:	mov    0xb0(%rsp),%rax
  48ad3b:	mov    0x28(%rax),%rdi
  48ad3f:	cmp    0x254(%rdi),%esi
  48ad45:	sete   %sil
  48ad49:	movzbl %sil,%eax
  48ad4d:	mov    0x68(%rsp),%edx
  48ad51:	mov    0x58(%rsp),%esi
  48ad55:	mov    0x60(%rsp),%edi
  48ad59:	xor    %r8d,%r8d
  48ad5c:	test   %eax,%eax
  48ad5e:	jne    48ad71 <wasm[0]::function[160]::builtin::Array.prototype.push+0x4f1>
  48ad64:	mov    %r12,0xd0(%rsp)
  48ad6c:	jmp    48b652 <wasm[0]::function[160]::builtin::Array.prototype.push+0xdd2>
  48ad71:	xor    %eax,%eax
  48ad73:	test   %ecx,%ecx
  48ad75:	je     48adbf <wasm[0]::function[160]::builtin::Array.prototype.push+0x53f>
  48ad7b:	xor    %eax,%eax
  48ad7d:	test   $0x1,%ecx
  48ad83:	jne    48adbf <wasm[0]::function[160]::builtin::Array.prototype.push+0x53f>
  48ad89:	mov    0x28(%rbx),%rax
  48ad8d:	mov    0x20(%rbx),%r8
  48ad91:	mov    %ecx,%r9d
  48ad94:	lea    0x4(%r8,%r9,1),%r8
  48ad99:	xor    %r10,%r10
  48ad9c:	cmp    %rax,%r9
  48ad9f:	cmova  %r10,%r8
  48ada3:	mov    (%r8),%eax
  48ada6:	mov    0xb0(%rsp),%r8
  48adae:	mov    0x28(%r8),%r8
  48adb2:	cmp    0x254(%r8),%eax
  48adb9:	sete   %al
  48adbc:	movzbl %al,%eax
  48adbf:	test   %eax,%eax
  48adc1:	je     48bdba <wasm[0]::function[160]::builtin::Array.prototype.push+0x153a>
  48adc7:	test   %ecx,%ecx
  48adc9:	je     48bdbc <wasm[0]::function[160]::builtin::Array.prototype.push+0x153c>
  48adcf:	test   %ecx,%ecx
  48add1:	je     48bdbe <wasm[0]::function[160]::builtin::Array.prototype.push+0x153e>
  48add7:	mov    0x28(%rbx),%rax
  48addb:	mov    0x20(%rbx),%r8
  48addf:	mov    %ecx,%r9d
  48ade2:	add    %r9,%r8
  48ade5:	xor    %r10,%r10
  48ade8:	cmp    %rax,%r9
  48adeb:	cmova  %r10,%r8
  48adef:	mov    0x14(%r8),%eax
  48adf3:	mov    0x18(%r8),%r9
  48adf7:	xor    %r8d,%r8d
  48adfa:	cmp    %r14,%r9
  48adfd:	je     48ae10 <wasm[0]::function[160]::builtin::Array.prototype.push+0x590>
  48ae03:	mov    %r12,0xd0(%rsp)
  48ae0b:	jmp    48b652 <wasm[0]::function[160]::builtin::Array.prototype.push+0xdd2>
  48ae10:	xor    %r8d,%r8d
  48ae13:	test   %eax,%eax
  48ae15:	je     48bdc0 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1540>
  48ae1b:	test   %eax,%eax
  48ae1d:	je     48bdc2 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1542>
  48ae23:	mov    0x28(%rbx),%rcx
  48ae27:	mov    0x20(%rbx),%rdx
  48ae2b:	mov    %eax,%eax
  48ae2d:	add    %rax,%rdx
  48ae30:	xor    %rsi,%rsi
  48ae33:	cmp    %rcx,%rax
  48ae36:	cmova  %rsi,%rdx
  48ae3a:	mov    0x24(%rdx),%r9d
  48ae3e:	mov    0x68(%rsp),%edx
  48ae42:	mov    0x40(%rsp),%ecx
  48ae46:	mov    0x58(%rsp),%esi
  48ae4a:	mov    0x60(%rsp),%edi
  48ae4e:	cmp    $0x2,%r9d
  48ae52:	sete   %r10b
  48ae56:	cmp    $0x3,%r9d
  48ae5a:	sete   %r9b
  48ae5e:	or     %r9d,%r10d
  48ae61:	movzbl %r10b,%r9d
  48ae65:	test   %r9d,%r9d
  48ae68:	jne    48ae7b <wasm[0]::function[160]::builtin::Array.prototype.push+0x5fb>
  48ae6e:	mov    %r12,0xd0(%rsp)
  48ae76:	jmp    48b652 <wasm[0]::function[160]::builtin::Array.prototype.push+0xdd2>
  48ae7b:	mov    0x68(%rsp),%edx
  48ae7f:	mov    0x40(%rsp),%ecx
  48ae83:	mov    0x58(%rsp),%esi
  48ae87:	mov    0x60(%rsp),%edi
  48ae8b:	xor    %r8d,%r8d
  48ae8e:	mov    0xd8(%rsp),%r9
  48ae96:	mov    0xd8(%rsp),%r10
  48ae9e:	test   %r10d,%r9d
  48aea1:	jne    48aeb4 <wasm[0]::function[160]::builtin::Array.prototype.push+0x634>
  48aea7:	mov    %r12,0xd0(%rsp)
  48aeaf:	jmp    48b652 <wasm[0]::function[160]::builtin::Array.prototype.push+0xdd2>
  48aeb4:	xor    %r8d,%r8d
  48aeb7:	cmp    0xf9a(%rip),%r12        # 48be58 <wasm[0]::function[160]::builtin::Array.prototype.push+0x15d8>
  48aebe:	mov    %r12,0xd0(%rsp)
  48aec6:	ja     48b652 <wasm[0]::function[160]::builtin::Array.prototype.push+0xdd2>
  48aecc:	xor    %r8d,%r8d
  48aecf:	test   %ecx,%ecx
  48aed1:	je     48bdc4 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1544>
  48aed7:	test   %ecx,%ecx
  48aed9:	je     48bdc6 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1546>
  48aedf:	mov    0x28(%rbx),%r9
  48aee3:	mov    %ecx,%r11d
  48aee6:	mov    %r11,%r10
  48aee9:	add    0x20(%rbx),%r10
  48aeed:	xor    %r12,%r12
  48aef0:	cmp    %r9,%r11
  48aef3:	cmova  %r12,%r10
  48aef7:	mov    0x20(%r10),%r9d
  48aefb:	test   %r9d,%r9d
  48aefe:	je     48b652 <wasm[0]::function[160]::builtin::Array.prototype.push+0xdd2>
  48af04:	mov    0x40(%rsp),%ecx
  48af08:	xor    %r8d,%r8d
  48af0b:	test   %ecx,%ecx
  48af0d:	je     48bdc8 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1548>
  48af13:	test   %ecx,%ecx
  48af15:	je     48bdca <wasm[0]::function[160]::builtin::Array.prototype.push+0x154a>
  48af1b:	mov    0x28(%rbx),%rdx
  48af1f:	mov    0x20(%rbx),%rsi
  48af23:	mov    %ecx,%r10d
  48af26:	lea    (%rsi,%r10,1),%r9
  48af2a:	xor    %rdi,%rdi
  48af2d:	cmp    %rdx,%r10
  48af30:	cmova  %rdi,%r9
  48af34:	mov    0x10(%r9),%r9d
  48af38:	test   %r9d,%r9d
  48af3b:	je     48bdcc <wasm[0]::function[160]::builtin::Array.prototype.push+0x154c>
  48af41:	test   %r9d,%r9d
  48af44:	je     48bdce <wasm[0]::function[160]::builtin::Array.prototype.push+0x154e>
  48af4a:	mov    %r9d,%r9d
  48af4d:	add    %r9,%rsi
  48af50:	cmp    %rdx,%r9
  48af53:	cmova  %rdi,%rsi
  48af57:	mov    0x1c(%rsi),%r9d
  48af5b:	mov    0x68(%rsp),%edx
  48af5f:	mov    0x58(%rsp),%esi
  48af63:	mov    0x60(%rsp),%edi
  48af67:	test   %r9d,%r9d
  48af6a:	je     48b652 <wasm[0]::function[160]::builtin::Array.prototype.push+0xdd2>
  48af70:	mov    0x28(%rbx),%rdx
  48af74:	mov    %rax,%rcx
  48af77:	add    0x20(%rbx),%rcx
  48af7b:	xor    %rsi,%rsi
  48af7e:	cmp    %rdx,%rax
  48af81:	cmova  %rsi,%rcx
  48af85:	mov    0x18(%rcx),%r9
  48af89:	mov    0x68(%rsp),%edx
  48af8d:	mov    0x40(%rsp),%ecx
  48af91:	mov    0x58(%rsp),%esi
  48af95:	mov    0x60(%rsp),%edi
  48af99:	xor    %r8d,%r8d
  48af9c:	cmp    %r14,%r9
  48af9f:	jne    48b652 <wasm[0]::function[160]::builtin::Array.prototype.push+0xdd2>
  48afa5:	mov    0x40(%rsp),%ecx
  48afa9:	xor    %r12d,%r12d
  48afac:	test   %ecx,%ecx
  48afae:	je     48bdd0 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1550>
  48afb4:	test   %ecx,%ecx
  48afb6:	je     48bdd2 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1552>
  48afbc:	mov    0x28(%rbx),%r10
  48afc0:	mov    0x20(%rbx),%r11
  48afc4:	mov    %ecx,%edx
  48afc6:	lea    (%r11,%rdx,1),%rdi
  48afca:	xor    %rax,%rax
  48afcd:	cmp    %r10,%rdx
  48afd0:	cmova  %rax,%rdi
  48afd4:	mov    0x10(%rdi),%edx
  48afd7:	test   %edx,%edx
  48afd9:	je     48bdd4 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1554>
  48afdf:	mov    %edx,%esi
  48afe1:	lea    (%r11,%rsi,1),%rdx
  48afe5:	cmp    %r10,%rsi
  48afe8:	cmova  %rax,%rdx
  48afec:	mov    0x10(%rdx),%r10d
  48aff0:	mov    0x68(%rsp),%esi
  48aff4:	mov    0x58(%rsp),%edi
  48aff8:	mov    0x60(%rsp),%r9d
  48affd:	mov    0xb0(%rsp),%rax
  48b005:	mov    0x28(%rax),%rax
  48b009:	mov    0x254(%rax),%edx
  48b00f:	mov    %rdx,%r13
  48b012:	mov    0x138(%rax),%eax
  48b018:	mov    %rax,0xc8(%rsp)
  48b020:	mov    %rcx,%rdx
  48b023:	mov    %r10d,0x80(%rsp)
  48b02b:	mov    %esi,0x78(%rsp)
  48b02f:	mov    %ecx,0x70(%rsp)
  48b033:	mov    %edx,0x60(%rsp)
  48b037:	mov    %edi,0x58(%rsp)
  48b03b:	mov    %r9d,0x68(%rsp)
  48b040:	mov    0xf8(%rsp),%rcx
  48b048:	mov    (%rcx),%rax
  48b04b:	mov    0xc0(%rsp),%rcx
  48b053:	cmp    %rcx,%rax
  48b056:	jae    48bcba <wasm[0]::function[160]::builtin::Array.prototype.push+0x143a>
  48b05c:	mov    0x80(%rsp),%eax
  48b063:	test   %eax,%eax
  48b065:	je     48b44a <wasm[0]::function[160]::builtin::Array.prototype.push+0xbca>
  48b06b:	mov    0x78(%rsp),%edx
  48b06f:	mov    0x70(%rsp),%r9d
  48b074:	mov    0x60(%rsp),%ecx
  48b078:	mov    0x58(%rsp),%esi
  48b07c:	mov    0x68(%rsp),%edi
  48b080:	xor    %r15d,%r15d
  48b083:	cmp    $0x8,%r12d
  48b087:	jae    48b465 <wasm[0]::function[160]::builtin::Array.prototype.push+0xbe5>
  48b08d:	mov    0x80(%rsp),%eax
  48b094:	xor    %ecx,%ecx
  48b096:	test   %eax,%eax
  48b098:	je     48b0e0 <wasm[0]::function[160]::builtin::Array.prototype.push+0x860>
  48b09e:	mov    0x80(%rsp),%eax
  48b0a5:	xor    %ecx,%ecx
  48b0a7:	test   $0x1,%eax
  48b0ac:	jne    48b0e0 <wasm[0]::function[160]::builtin::Array.prototype.push+0x860>
  48b0b2:	mov    0x80(%rsp),%ecx
  48b0b9:	mov    0x28(%rbx),%rax
  48b0bd:	mov    0x20(%rbx),%rsi
  48b0c1:	mov    %ecx,%edx
  48b0c3:	lea    0x4(%rsi,%rdx,1),%rcx
  48b0c8:	xor    %rsi,%rsi
  48b0cb:	cmp    %rax,%rdx
  48b0ce:	cmova  %rsi,%rcx
  48b0d2:	mov    (%rcx),%eax
  48b0d4:	mov    %r13,%r15
  48b0d7:	cmp    %r15d,%eax
  48b0da:	sete   %al
  48b0dd:	movzbl %al,%ecx
  48b0e0:	test   %ecx,%ecx
  48b0e2:	jne    48b31d <wasm[0]::function[160]::builtin::Array.prototype.push+0xa9d>
  48b0e8:	mov    0x80(%rsp),%eax
  48b0ef:	xor    %r8d,%r8d
  48b0f2:	test   %eax,%eax
  48b0f4:	je     48b143 <wasm[0]::function[160]::builtin::Array.prototype.push+0x8c3>
  48b0fa:	mov    0x80(%rsp),%eax
  48b101:	xor    %r8d,%r8d
  48b104:	test   $0x1,%eax
  48b109:	jne    48b143 <wasm[0]::function[160]::builtin::Array.prototype.push+0x8c3>
  48b10f:	mov    0x80(%rsp),%ecx
  48b116:	mov    0x28(%rbx),%rax
  48b11a:	mov    0x20(%rbx),%rsi
  48b11e:	mov    %ecx,%edx
  48b120:	lea    0x4(%rsi,%rdx,1),%rcx
  48b125:	xor    %rsi,%rsi
  48b128:	cmp    %rax,%rdx
  48b12b:	cmova  %rsi,%rcx
  48b12f:	mov    (%rcx),%eax
  48b131:	mov    0xc8(%rsp),%r15
  48b139:	cmp    %r15d,%eax
  48b13c:	sete   %al
  48b13f:	movzbl %al,%r8d
  48b143:	mov    0x78(%rsp),%edx
  48b147:	mov    0x70(%rsp),%r9d
  48b14c:	mov    0x60(%rsp),%ecx
  48b150:	mov    0x58(%rsp),%esi
  48b154:	mov    0x68(%rsp),%edi
  48b158:	xor    %r15d,%r15d
  48b15b:	test   %r8d,%r8d
  48b15e:	je     48b465 <wasm[0]::function[160]::builtin::Array.prototype.push+0xbe5>
  48b164:	mov    0x80(%rsp),%eax
  48b16b:	xor    %ecx,%ecx
  48b16d:	test   %eax,%eax
  48b16f:	je     48b1bc <wasm[0]::function[160]::builtin::Array.prototype.push+0x93c>
  48b175:	mov    0x80(%rsp),%eax
  48b17c:	xor    %ecx,%ecx
  48b17e:	test   $0x1,%eax
  48b183:	jne    48b1bc <wasm[0]::function[160]::builtin::Array.prototype.push+0x93c>
  48b189:	mov    0x80(%rsp),%ecx
  48b190:	mov    0x28(%rbx),%rax
  48b194:	mov    0x20(%rbx),%rsi
  48b198:	mov    %ecx,%edx
  48b19a:	lea    0x4(%rsi,%rdx,1),%rcx
  48b19f:	xor    %rsi,%rsi
  48b1a2:	cmp    %rax,%rdx
  48b1a5:	cmova  %rsi,%rcx
  48b1a9:	mov    (%rcx),%eax
  48b1ab:	mov    0xc8(%rsp),%r15
  48b1b3:	cmp    %r15d,%eax
  48b1b6:	sete   %cl
  48b1b9:	movzbl %cl,%ecx
  48b1bc:	test   %ecx,%ecx
  48b1be:	je     48bdd6 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1556>
  48b1c4:	mov    0x78(%rsp),%edx
  48b1c8:	mov    0x70(%rsp),%r9d
  48b1cd:	mov    0x60(%rsp),%ecx
  48b1d1:	mov    0x58(%rsp),%esi
  48b1d5:	mov    0x68(%rsp),%edi
  48b1d9:	mov    %r14,0xb8(%rsp)
  48b1e1:	mov    %edx,0x88(%rsp)
  48b1e8:	mov    %r9d,0x90(%rsp)
  48b1f0:	mov    %ecx,0x98(%rsp)
  48b1f7:	mov    %esi,0xa0(%rsp)
  48b1fe:	mov    %edi,0xa8(%rsp)
  48b205:	mov    0xf8(%rsp),%rax
  48b20d:	mov    (%rax),%r10
  48b210:	mov    0xc0(%rsp),%rax
  48b218:	cmp    %rax,%r10
  48b21b:	jae    48bce9 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1469>
  48b221:	mov    0xd0(%rsp),%rax
  48b229:	jmp    48b236 <wasm[0]::function[160]::builtin::Array.prototype.push+0x9b6>
  48b22e:	mov    0xd0(%rsp),%rax
  48b236:	cmp    %rax,%r14
  48b239:	mov    %rax,0xd0(%rsp)
  48b241:	jae    48b2e1 <wasm[0]::function[160]::builtin::Array.prototype.push+0xa61>
  48b247:	xor    %r15d,%r15d
  48b24a:	mov    %r15,%rcx
  48b24d:	mov    %r14,%rdx
  48b250:	mov    0xb0(%rsp),%rsi
  48b258:	mov    0xb0(%rsp),%rdi
  48b260:	call   2ae5800 <wasm[0]::function[1058]::helper::integer_decimal_string>
  48b265:	test   %eax,%eax
  48b267:	je     48bdd8 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1558>
  48b26d:	mov    0x80(%rsp),%edx
  48b274:	test   %edx,%edx
  48b276:	je     48bdda <wasm[0]::function[160]::builtin::Array.prototype.push+0x155a>
  48b27c:	mov    $0x4,%ecx
  48b281:	xor    %r8,%r8
  48b284:	mov    %rax,%r9
  48b287:	mov    0xb0(%rsp),%rsi
  48b28f:	mov    0xb0(%rsp),%rdi
  48b297:	call   29ffc00 <wasm[0]::function[1019]::helper::ordinary_own_descriptor>
  48b29c:	mov    0x88(%rsp),%edx
  48b2a3:	mov    0x90(%rsp),%r9d
  48b2ab:	mov    0x98(%rsp),%ecx
  48b2b2:	mov    0xa0(%rsp),%esi
  48b2b9:	mov    0xa8(%rsp),%edi
  48b2c0:	test   %eax,%eax
  48b2c2:	je     48b2d5 <wasm[0]::function[160]::builtin::Array.prototype.push+0xa55>
  48b2c8:	mov    0xb8(%rsp),%r14
  48b2d0:	jmp    48b465 <wasm[0]::function[160]::builtin::Array.prototype.push+0xbe5>
  48b2d5:	add    $0x1,%r14
  48b2dc:	jmp    48b1e1 <wasm[0]::function[160]::builtin::Array.prototype.push+0x961>
  48b2e1:	mov    0x80(%rsp),%r10d
  48b2e9:	mov    0x88(%rsp),%esi
  48b2f0:	mov    0x90(%rsp),%ecx
  48b2f7:	mov    0x98(%rsp),%edx
  48b2fe:	mov    0xa0(%rsp),%edi
  48b305:	mov    0xa8(%rsp),%r9d
  48b30d:	mov    %r13,%r8
  48b310:	mov    0xb8(%rsp),%r14
  48b318:	jmp    48b416 <wasm[0]::function[160]::builtin::Array.prototype.push+0xb96>
  48b31d:	mov    0x80(%rsp),%eax
  48b324:	xor    %edx,%edx
  48b326:	test   %eax,%eax
  48b328:	jne    48b336 <wasm[0]::function[160]::builtin::Array.prototype.push+0xab6>
  48b32e:	mov    %r13,%r8
  48b331:	jmp    48b380 <wasm[0]::function[160]::builtin::Array.prototype.push+0xb00>
  48b336:	mov    0x80(%rsp),%eax
  48b33d:	xor    %edx,%edx
  48b33f:	test   $0x1,%eax
  48b344:	je     48b352 <wasm[0]::function[160]::builtin::Array.prototype.push+0xad2>
  48b34a:	mov    %r13,%r8
  48b34d:	jmp    48b380 <wasm[0]::function[160]::builtin::Array.prototype.push+0xb00>
  48b352:	mov    0x80(%rsp),%ecx
  48b359:	mov    0x28(%rbx),%rax
  48b35d:	mov    0x20(%rbx),%rsi
  48b361:	mov    %ecx,%edx
  48b363:	lea    0x4(%rsi,%rdx,1),%rcx
  48b368:	xor    %rsi,%rsi
  48b36b:	cmp    %rax,%rdx
  48b36e:	cmova  %rsi,%rcx
  48b372:	mov    (%rcx),%eax
  48b374:	mov    %r13,%r8
  48b377:	cmp    %r8d,%eax
  48b37a:	sete   %al
  48b37d:	movzbl %al,%edx
  48b380:	test   %edx,%edx
  48b382:	je     48bddc <wasm[0]::function[160]::builtin::Array.prototype.push+0x155c>
  48b388:	mov    0x80(%rsp),%eax
  48b38f:	xor    %r15d,%r15d
  48b392:	test   %eax,%eax
  48b394:	je     48bdde <wasm[0]::function[160]::builtin::Array.prototype.push+0x155e>
  48b39a:	test   %eax,%eax
  48b39c:	je     48bde0 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1560>
  48b3a2:	mov    0x28(%rbx),%rcx
  48b3a6:	mov    0x20(%rbx),%rsi
  48b3aa:	mov    %eax,%eax
  48b3ac:	lea    (%rsi,%rax,1),%rdx
  48b3b0:	xor    %rdi,%rdi
  48b3b3:	cmp    %rcx,%rax
  48b3b6:	cmova  %rdi,%rdx
  48b3ba:	mov    0x14(%rdx),%eax
  48b3bd:	test   %eax,%eax
  48b3bf:	je     48bde2 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1562>
  48b3c5:	test   %eax,%eax
  48b3c7:	je     48bde4 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1564>
  48b3cd:	mov    %eax,%r9d
  48b3d0:	lea    (%rsi,%r9,1),%rax
  48b3d4:	cmp    %rcx,%r9
  48b3d7:	cmova  %rdi,%rax
  48b3db:	mov    0x18(%rax),%rax
  48b3df:	mov    0x10(%rdx),%r10d
  48b3e3:	mov    0x78(%rsp),%edx
  48b3e7:	mov    0x70(%rsp),%r9d
  48b3ec:	mov    0x60(%rsp),%ecx
  48b3f0:	mov    0x58(%rsp),%esi
  48b3f4:	mov    0x68(%rsp),%edi
  48b3f8:	test   %rax,%rax
  48b3fb:	jne    48b465 <wasm[0]::function[160]::builtin::Array.prototype.push+0xbe5>
  48b401:	mov    0x78(%rsp),%esi
  48b405:	mov    0x70(%rsp),%ecx
  48b409:	mov    0x60(%rsp),%edx
  48b40d:	mov    0x58(%rsp),%edi
  48b411:	mov    0x68(%rsp),%r9d
  48b416:	test   %r10d,%r10d
  48b419:	je     48bde6 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1566>
  48b41f:	mov    0x28(%rbx),%rax
  48b423:	mov    %r10d,%r11d
  48b426:	mov    %r11,%r10
  48b429:	add    0x20(%rbx),%r10
  48b42d:	xor    %r13,%r13
  48b430:	cmp    %rax,%r11
  48b433:	cmova  %r13,%r10
  48b437:	mov    0x10(%r10),%r10d
  48b43b:	add    $0x1,%r12d
  48b442:	mov    %r8,%r13
  48b445:	jmp    48b023 <wasm[0]::function[160]::builtin::Array.prototype.push+0x7a3>
  48b44a:	mov    0x78(%rsp),%edx
  48b44e:	mov    0x70(%rsp),%r9d
  48b453:	mov    0x60(%rsp),%ecx
  48b457:	mov    0x58(%rsp),%esi
  48b45b:	mov    0x68(%rsp),%edi
  48b45f:	mov    $0x1,%r15d
  48b465:	mov    %edx,0x70(%rsp)
  48b469:	mov    %r9d,0x78(%rsp)
  48b46e:	xor    %r8d,%r8d
  48b471:	test   %r15d,%r15d
  48b474:	je     48b652 <wasm[0]::function[160]::builtin::Array.prototype.push+0xdd2>
  48b47a:	xor    %r12d,%r12d
  48b47d:	mov    %r14,%r13
  48b480:	mov    %ecx,0x68(%rsp)
  48b484:	mov    %esi,0x58(%rsp)
  48b488:	mov    %edi,0x60(%rsp)
  48b48c:	mov    0xf8(%rsp),%rax
  48b494:	mov    (%rax),%rsi
  48b497:	mov    0xc0(%rsp),%rax
  48b49f:	cmp    %rax,%rsi
  48b4a2:	jae    48bd20 <wasm[0]::function[160]::builtin::Array.prototype.push+0x14a0>
  48b4a8:	mov    0xd8(%rsp),%rdx
  48b4b0:	jmp    48b4bd <wasm[0]::function[160]::builtin::Array.prototype.push+0xc3d>
  48b4b5:	mov    0xd8(%rsp),%rdx
  48b4bd:	mov    0xd8(%rsp),%rdx
  48b4c5:	cmp    %edx,%r12d
  48b4c8:	jae    48b639 <wasm[0]::function[160]::builtin::Array.prototype.push+0xdb9>
  48b4ce:	mov    0x70(%rsp),%eax
  48b4d2:	test   %eax,%eax
  48b4d4:	je     48bde8 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1568>
  48b4da:	test   %eax,%eax
  48b4dc:	je     48bdea <wasm[0]::function[160]::builtin::Array.prototype.push+0x156a>
  48b4e2:	mov    0x28(%rbx),%rcx
  48b4e6:	mov    0x20(%rbx),%rsi
  48b4ea:	mov    %eax,%edx
  48b4ec:	lea    0x10(%rsi,%rdx,1),%rax
  48b4f1:	xor    %rsi,%rsi
  48b4f4:	cmp    %rcx,%rdx
  48b4f7:	cmova  %rsi,%rax
  48b4fb:	mov    (%rax),%eax
  48b4fd:	cmp    %eax,%r12d
  48b500:	jb     48b514 <wasm[0]::function[160]::builtin::Array.prototype.push+0xc94>
  48b506:	xor    %r8d,%r8d
  48b509:	xor    %r9,%r9
  48b50c:	mov    %r8,%rax
  48b50f:	jmp    48b5c0 <wasm[0]::function[160]::builtin::Array.prototype.push+0xd40>
  48b514:	mov    0x70(%rsp),%edi
  48b518:	test   %edi,%edi
  48b51a:	je     48bdec <wasm[0]::function[160]::builtin::Array.prototype.push+0x156c>
  48b520:	test   %edi,%edi
  48b522:	je     48bdee <wasm[0]::function[160]::builtin::Array.prototype.push+0x156e>
  48b528:	mov    0x28(%rbx),%rax
  48b52c:	mov    0x20(%rbx),%rcx
  48b530:	mov    %edi,%r8d
  48b533:	lea    0x10(%rcx,%r8,1),%rsi
  48b538:	xor    %rdx,%rdx
  48b53b:	cmp    %rax,%r8
  48b53e:	cmova  %rdx,%rsi
  48b542:	mov    (%rsi),%esi
  48b544:	cmp    %esi,%r12d
  48b547:	jae    48bdf0 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1570>
  48b54d:	mov    %esi,%r8d
  48b550:	shl    $0x2,%r8
  48b554:	shr    $0x20,%r8
  48b558:	test   %r8,%r8
  48b55b:	jne    48bdf2 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1572>
  48b561:	shl    $0x2,%esi
  48b564:	add    $0x14,%esi
  48b567:	jb     48bdf4 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1574>
  48b56d:	add    %esi,%edi
  48b56f:	jb     48bdf6 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1576>
  48b575:	mov    %edi,%r8d
  48b578:	lea    (%rcx,%r8,1),%rdi
  48b57c:	cmp    %rax,%r8
  48b57f:	cmova  %rdx,%rdi
  48b583:	mov    %r12,%r8
  48b586:	shl    $0x2,%r8d
  48b58a:	add    $0x14,%r8d
  48b591:	sub    %r8d,%esi
  48b594:	sub    %rsi,%rdi
  48b597:	mov    (%rdi),%esi
  48b599:	test   %esi,%esi
  48b59b:	je     48bdf8 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1578>
  48b5a1:	test   %esi,%esi
  48b5a3:	je     48bdfa <wasm[0]::function[160]::builtin::Array.prototype.push+0x157a>
  48b5a9:	mov    %esi,%esi
  48b5ab:	add    %rsi,%rcx
  48b5ae:	cmp    %rax,%rsi
  48b5b1:	cmova  %rdx,%rcx
  48b5b5:	mov    0x18(%rcx),%r8d
  48b5b9:	mov    0x10(%rcx),%r9
  48b5bd:	mov    0x1c(%rcx),%eax
  48b5c0:	mov    0x78(%rsp),%edx
  48b5c4:	test   %edx,%edx
  48b5c6:	je     48bdfc <wasm[0]::function[160]::builtin::Array.prototype.push+0x157c>
  48b5cc:	mov    %eax,(%rsp)
  48b5cf:	mov    %r14,%rcx
  48b5d2:	mov    0xb0(%rsp),%rsi
  48b5da:	mov    0xb0(%rsp),%rdi
  48b5e2:	call   29d4760 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data>
  48b5e7:	sub    $0x10,%rsp
  48b5eb:	mov    0x78(%rsp),%eax
  48b5ef:	test   %eax,%eax
  48b5f1:	je     48bdfe <wasm[0]::function[160]::builtin::Array.prototype.push+0x157e>
  48b5f7:	test   %eax,%eax
  48b5f9:	je     48be00 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1580>
  48b5ff:	mov    0x28(%rbx),%rcx
  48b603:	add    $0x1,%r14
  48b60a:	mov    %eax,%edx
  48b60c:	mov    %rdx,%rax
  48b60f:	add    0x20(%rbx),%rax
  48b613:	xor    %rsi,%rsi
  48b616:	cmp    %rcx,%rdx
  48b619:	cmova  %rsi,%rax
  48b61d:	mov    %r14,0x18(%rax)
  48b621:	mov    0x68(%rsp),%ecx
  48b625:	mov    0x58(%rsp),%esi
  48b629:	mov    0x60(%rsp),%edi
  48b62d:	add    $0x1,%r12d
  48b634:	jmp    48b480 <wasm[0]::function[160]::builtin::Array.prototype.push+0xc00>
  48b639:	mov    0x70(%rsp),%edx
  48b63d:	mov    0x68(%rsp),%ecx
  48b641:	mov    0x58(%rsp),%esi
  48b645:	mov    0x60(%rsp),%edi
  48b649:	mov    $0x1,%r8d
  48b64f:	mov    %r13,%r14
  48b652:	mov    %edx,0x60(%rsp)
  48b656:	mov    %ecx,0x58(%rsp)
  48b65a:	mov    %esi,0x68(%rsp)
  48b65e:	mov    %edi,0x70(%rsp)
  48b662:	test   %r8d,%r8d
  48b665:	jne    48b970 <wasm[0]::function[160]::builtin::Array.prototype.push+0x10f0>
  48b66b:	xor    %r13d,%r13d
  48b66e:	mov    0xf8(%rsp),%rax
  48b676:	mov    0xf8(%rsp),%rax
  48b67e:	mov    (%rax),%rax
  48b681:	mov    0xc0(%rsp),%r8
  48b689:	cmp    %r8,%rax
  48b68c:	jae    48bd57 <wasm[0]::function[160]::builtin::Array.prototype.push+0x14d7>
  48b692:	mov    0xd8(%rsp),%r12
  48b69a:	jmp    48b6a7 <wasm[0]::function[160]::builtin::Array.prototype.push+0xe27>
  48b69f:	mov    0xd8(%rsp),%r12
  48b6a7:	mov    0xd8(%rsp),%r12
  48b6af:	cmp    %r12d,%r13d
  48b6b2:	jae    48b872 <wasm[0]::function[160]::builtin::Array.prototype.push+0xff2>
  48b6b8:	mov    0x60(%rsp),%esi
  48b6bc:	test   %esi,%esi
  48b6be:	je     48be02 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1582>
  48b6c4:	test   %esi,%esi
  48b6c6:	je     48be04 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1584>
  48b6cc:	mov    0x28(%rbx),%r9
  48b6d0:	mov    0x20(%rbx),%r11
  48b6d4:	mov    %esi,%r10d
  48b6d7:	lea    0x10(%r11,%r10,1),%rsi
  48b6dc:	xor    %r11,%r11
  48b6df:	cmp    %r9,%r10
  48b6e2:	cmova  %r11,%rsi
  48b6e6:	mov    (%rsi),%r10d
  48b6e9:	cmp    %r10d,%r13d
  48b6ec:	jb     48b700 <wasm[0]::function[160]::builtin::Array.prototype.push+0xe80>
  48b6f2:	xor    %r12d,%r12d
  48b6f5:	xor    %r15,%r15
  48b6f8:	mov    %r12,%rax
  48b6fb:	jmp    48b7ae <wasm[0]::function[160]::builtin::Array.prototype.push+0xf2e>
  48b700:	mov    0x60(%rsp),%edi
  48b704:	test   %edi,%edi
  48b706:	je     48be06 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1586>
  48b70c:	test   %edi,%edi
  48b70e:	je     48be08 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1588>
  48b714:	mov    0x28(%rbx),%rcx
  48b718:	mov    0x20(%rbx),%rdx
  48b71c:	mov    %edi,%r8d
  48b71f:	lea    0x10(%rdx,%r8,1),%rax
  48b724:	xor    %rsi,%rsi
  48b727:	cmp    %rcx,%r8
  48b72a:	cmova  %rsi,%rax
  48b72e:	mov    (%rax),%r8d
  48b731:	cmp    %r8d,%r13d
  48b734:	jae    48be0a <wasm[0]::function[160]::builtin::Array.prototype.push+0x158a>
  48b73a:	mov    %r8d,%eax
  48b73d:	shl    $0x2,%rax
  48b741:	shr    $0x20,%rax
  48b745:	test   %rax,%rax
  48b748:	jne    48be0c <wasm[0]::function[160]::builtin::Array.prototype.push+0x158c>
  48b74e:	shl    $0x2,%r8d
  48b752:	add    $0x14,%r8d
  48b756:	jb     48be0e <wasm[0]::function[160]::builtin::Array.prototype.push+0x158e>
  48b75c:	add    %r8d,%edi
  48b75f:	jb     48be10 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1590>
  48b765:	mov    %edi,%edi
  48b767:	lea    (%rdx,%rdi,1),%rax
  48b76b:	cmp    %rcx,%rdi
  48b76e:	cmova  %rsi,%rax
  48b772:	mov    %r13,%rdi
  48b775:	shl    $0x2,%edi
  48b778:	add    $0x14,%edi
  48b77e:	sub    %edi,%r8d
  48b781:	sub    %r8,%rax
  48b784:	mov    (%rax),%eax
  48b786:	test   %eax,%eax
  48b788:	je     48be12 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1592>
  48b78e:	test   %eax,%eax
  48b790:	je     48be14 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1594>
  48b796:	mov    %eax,%edi
  48b798:	lea    (%rdx,%rdi,1),%rax
  48b79c:	cmp    %rcx,%rdi
  48b79f:	cmova  %rsi,%rax
  48b7a3:	mov    0x18(%rax),%r12d
  48b7a7:	mov    0x10(%rax),%r15
  48b7ab:	mov    0x1c(%rax),%eax
  48b7ae:	mov    %eax,0x78(%rsp)
  48b7b2:	xor    %ecx,%ecx
  48b7b4:	mov    %r14,%rdx
  48b7b7:	mov    0xb0(%rsp),%rsi
  48b7bf:	mov    0xb0(%rsp),%rdi
  48b7c7:	call   2ae5800 <wasm[0]::function[1058]::helper::integer_decimal_string>
  48b7cc:	test   %eax,%eax
  48b7ce:	je     48be16 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1596>
  48b7d4:	mov    0x70(%rsp),%ecx
  48b7d8:	test   %ecx,%ecx
  48b7da:	je     48be18 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1598>
  48b7e0:	mov    0x58(%rsp),%r8d
  48b7e5:	mov    0x78(%rsp),%esi
  48b7e9:	mov    0x68(%rsp),%edx
  48b7ed:	mov    $0x4,%r9d
  48b7f3:	xor    %r10,%r10
  48b7f6:	mov    $0x1,%edi
  48b7fb:	mov    %r10,(%rsp)
  48b7ff:	mov    %eax,0x8(%rsp)
  48b803:	mov    %r12d,0x10(%rsp)
  48b808:	mov    %r15,0x18(%rsp)
  48b80d:	mov    %esi,0x20(%rsp)
  48b811:	mov    %edi,0x28(%rsp)
  48b815:	mov    %edx,0x30(%rsp)
  48b819:	mov    %ecx,0x38(%rsp)
  48b81d:	mov    0xf0(%rsp),%rcx
  48b825:	mov    0xe8(%rsp),%rdx
  48b82d:	mov    0xb0(%rsp),%rsi
  48b835:	mov    0xb0(%rsp),%rdi
  48b83d:	call   29fc920 <wasm[0]::function[1016]::helper::object_write>
  48b842:	sub    $0x40,%rsp
  48b846:	cmp    $0x1,%esi
  48b849:	je     48b86a <wasm[0]::function[160]::builtin::Array.prototype.push+0xfea>
  48b84f:	add    $0x1,%r13d
  48b856:	add    $0x1,%r14
  48b85d:	mov    0xf8(%rsp),%rax
  48b865:	jmp    48b676 <wasm[0]::function[160]::builtin::Array.prototype.push+0xdf6>
  48b86a:	mov    %rdi,%r13
  48b86d:	jmp    48bb62 <wasm[0]::function[160]::builtin::Array.prototype.push+0x12e2>
  48b872:	movl   $0x0,0x60(%rsp)
  48b87a:	mov    $0x8c,%edx
  48b87f:	mov    0xb0(%rsp),%rsi
  48b887:	mov    0xb0(%rsp),%rdi
  48b88f:	call   2f307a0 <wasm[0]::function[1102]::helper::pooled_string_resolve>
  48b894:	test   %eax,%eax
  48b896:	je     48be1a <wasm[0]::function[160]::builtin::Array.prototype.push+0x159a>
  48b89c:	mov    0x70(%rsp),%edx
  48b8a0:	test   %edx,%edx
  48b8a2:	je     48be1c <wasm[0]::function[160]::builtin::Array.prototype.push+0x159c>
  48b8a8:	mov    0x58(%rsp),%r8d
  48b8ad:	mov    0x60(%rsp),%edi
  48b8b1:	mov    0x68(%rsp),%ecx
  48b8b5:	mov    $0x4,%r9d
  48b8bb:	xor    %rsi,%rsi
  48b8be:	mov    $0x3,%r12d
  48b8c4:	mov    0xd0(%rsp),%r10
  48b8cc:	cmp    $0x0,%r10
  48b8d0:	jl     48b8e0 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1060>
  48b8d6:	cvtsi2sd %r10,%xmm0
  48b8db:	jmp    48b8fa <wasm[0]::function[160]::builtin::Array.prototype.push+0x107a>
  48b8e0:	mov    %r10,%rbx
  48b8e3:	shr    $0x1,%rbx
  48b8e7:	mov    %r10,%r11
  48b8ea:	and    $0x1,%r11
  48b8ee:	or     %rbx,%r11
  48b8f1:	cvtsi2sd %r11,%xmm0
  48b8f6:	addsd  %xmm0,%xmm0
  48b8fa:	movq   %xmm0,%rbx
  48b8ff:	mov    $0x1,%r10d
  48b905:	mov    %rsi,(%rsp)
  48b909:	mov    %eax,0x8(%rsp)
  48b90d:	mov    %r12d,0x10(%rsp)
  48b912:	mov    %rbx,0x18(%rsp)
  48b917:	mov    %edi,0x20(%rsp)
  48b91b:	mov    %r10d,0x28(%rsp)
  48b920:	mov    %ecx,0x30(%rsp)
  48b924:	mov    %edx,0x38(%rsp)
  48b928:	mov    0xf0(%rsp),%rcx
  48b930:	mov    0xe8(%rsp),%rdx
  48b938:	mov    0xb0(%rsp),%rsi
  48b940:	mov    %rsi,%rdi
  48b943:	call   29fc920 <wasm[0]::function[1016]::helper::object_write>
  48b948:	sub    $0x40,%rsp
  48b94c:	cmp    $0x1,%esi
  48b94f:	je     48b968 <wasm[0]::function[160]::builtin::Array.prototype.push+0x10e8>
  48b955:	xor    %edx,%edx
  48b957:	mov    %r12,%rax
  48b95a:	mov    %rbx,%rcx
  48b95d:	mov    %rdx,%rsi
  48b960:	mov    %rdx,%r13
  48b963:	jmp    48bb62 <wasm[0]::function[160]::builtin::Array.prototype.push+0x12e2>
  48b968:	mov    %rdi,%r13
  48b96b:	jmp    48bb62 <wasm[0]::function[160]::builtin::Array.prototype.push+0x12e2>
  48b970:	mov    0xd0(%rsp),%r10
  48b978:	mov    $0x3,%eax
  48b97d:	cmp    $0x0,%r10
  48b981:	jl     48b991 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1111>
  48b987:	cvtsi2sd %r10,%xmm0
  48b98c:	jmp    48b9ab <wasm[0]::function[160]::builtin::Array.prototype.push+0x112b>
  48b991:	mov    %r10,%rdx
  48b994:	shr    $0x1,%rdx
  48b998:	mov    %r10,%rcx
  48b99b:	and    $0x1,%rcx
  48b99f:	or     %rdx,%rcx
  48b9a2:	cvtsi2sd %rcx,%xmm0
  48b9a7:	addsd  %xmm0,%xmm0
  48b9ab:	movq   %xmm0,%rcx
  48b9b0:	xor    %edx,%edx
  48b9b2:	mov    %rdx,%rsi
  48b9b5:	mov    %rdx,%r13
  48b9b8:	jmp    48bb62 <wasm[0]::function[160]::builtin::Array.prototype.push+0x12e2>
  48b9bd:	mov    0x50(%rsp),%eax
  48b9c1:	test   %eax,%eax
  48b9c3:	je     48be1e <wasm[0]::function[160]::builtin::Array.prototype.push+0x159e>
  48b9c9:	test   %eax,%eax
  48b9cb:	je     48be20 <wasm[0]::function[160]::builtin::Array.prototype.push+0x15a0>
  48b9d1:	mov    0x28(%rbx),%rcx
  48b9d5:	mov    0x20(%rbx),%rsi
  48b9d9:	mov    %eax,%edx
  48b9db:	lea    (%rsi,%rdx,1),%rax
  48b9df:	xor    %r12,%r12
  48b9e2:	cmp    %rcx,%rdx
  48b9e5:	cmova  %r12,%rax
  48b9e9:	mov    0x10(%rax),%edx
  48b9ec:	mov    %edx,0x50(%rsp)
  48b9f0:	test   %edx,%edx
  48b9f2:	je     48be22 <wasm[0]::function[160]::builtin::Array.prototype.push+0x15a2>
  48b9f8:	mov    0xb0(%rsp),%rsi
  48ba00:	mov    0xb0(%rsp),%rdi
  48ba08:	call   2ac6040 <wasm[0]::function[1049]::helper::realm_ensure_errors>
  48ba0d:	mov    0x50(%rsp),%eax
  48ba11:	test   %eax,%eax
  48ba13:	je     48be24 <wasm[0]::function[160]::builtin::Array.prototype.push+0x15a4>
  48ba19:	test   %eax,%eax
  48ba1b:	je     48be26 <wasm[0]::function[160]::builtin::Array.prototype.push+0x15a6>
  48ba21:	mov    0x28(%rbx),%rsi
  48ba25:	mov    0x20(%rbx),%rdi
  48ba29:	mov    %eax,%r9d
  48ba2c:	lea    (%rdi,%r9,1),%r8
  48ba30:	cmp    %rsi,%r9
  48ba33:	cmova  %r12,%r8
  48ba37:	mov    0x2c(%r8),%eax
  48ba3b:	test   %eax,%eax
  48ba3d:	je     48be28 <wasm[0]::function[160]::builtin::Array.prototype.push+0x15a8>
  48ba43:	test   %eax,%eax
  48ba45:	je     48be2a <wasm[0]::function[160]::builtin::Array.prototype.push+0x15aa>
  48ba4b:	mov    %eax,%r9d
  48ba4e:	lea    0x10(%rdi,%r9,1),%r8
  48ba53:	cmp    %rsi,%r9
  48ba56:	cmova  %r12,%r8
  48ba5a:	mov    (%r8),%ecx
  48ba5d:	cmp    $0x3,%ecx
  48ba60:	jbe    48be2c <wasm[0]::function[160]::builtin::Array.prototype.push+0x15ac>
  48ba66:	mov    %ecx,%r10d
  48ba69:	shl    $0x2,%r10
  48ba6d:	shr    $0x20,%r10
  48ba71:	test   %r10,%r10
  48ba74:	jne    48be2e <wasm[0]::function[160]::builtin::Array.prototype.push+0x15ae>
  48ba7a:	shl    $0x2,%ecx
  48ba7d:	add    $0x14,%ecx
  48ba80:	jb     48be30 <wasm[0]::function[160]::builtin::Array.prototype.push+0x15b0>
  48ba86:	add    %ecx,%eax
  48ba88:	jb     48be32 <wasm[0]::function[160]::builtin::Array.prototype.push+0x15b2>
  48ba8e:	mov    %eax,%edx
  48ba90:	lea    (%rdi,%rdx,1),%rax
  48ba94:	cmp    %rsi,%rdx
  48ba97:	cmova  %r12,%rax
  48ba9b:	sub    $0x20,%ecx
  48ba9e:	sub    %rcx,%rax
  48baa1:	mov    (%rax),%eax
  48baa3:	test   %eax,%eax
  48baa5:	je     48be34 <wasm[0]::function[160]::builtin::Array.prototype.push+0x15b4>
  48baab:	test   %eax,%eax
  48baad:	je     48be36 <wasm[0]::function[160]::builtin::Array.prototype.push+0x15b6>
  48bab3:	mov    %eax,%ecx
  48bab5:	lea    (%rdi,%rcx,1),%rax
  48bab9:	cmp    %rsi,%rcx
  48babc:	cmova  %r12,%rax
  48bac0:	mov    0x18(%rax),%r12d
  48bac4:	mov    0x10(%rax),%rbx
  48bac8:	mov    0x1c(%rax),%eax
  48bacb:	mov    %eax,0x50(%rsp)
  48bacf:	cmp    $0x6,%r12d
  48bad3:	sete   %cl
  48bad6:	cmp    $0x7,%r12d
  48bada:	sete   %al
  48badd:	or     %eax,%ecx
  48badf:	cmp    $0x8,%r12d
  48bae3:	sete   %al
  48bae6:	or     %eax,%ecx
  48bae8:	cmp    $0x9,%r12d
  48baec:	sete   %al
  48baef:	or     %eax,%ecx
  48baf1:	movzbl %cl,%eax
  48baf4:	test   %eax,%eax
  48baf6:	je     48be38 <wasm[0]::function[160]::builtin::Array.prototype.push+0x15b8>
  48bafc:	mov    $0x736,%edx
  48bb01:	mov    0xb0(%rsp),%rsi
  48bb09:	mov    0xb0(%rsp),%rdi
  48bb11:	call   2f307a0 <wasm[0]::function[1102]::helper::pooled_string_resolve>
  48bb16:	xor    %edi,%edi
  48bb18:	mov    %rdi,%r13
  48bb1b:	test   %eax,%eax
  48bb1d:	je     48be3a <wasm[0]::function[160]::builtin::Array.prototype.push+0x15ba>
  48bb23:	mov    0x50(%rsp),%r9d
  48bb28:	mov    $0x5,%edx
  48bb2d:	mov    %eax,(%rsp)
  48bb30:	mov    %r12,%rcx
  48bb33:	mov    0xb0(%rsp),%rsi
  48bb3b:	mov    %rbx,%r8
  48bb3e:	mov    %rsi,%rdi
  48bb41:	call   2f30500 <wasm[0]::function[1101]::helper::runtime_error_for_throw>
  48bb46:	sub    $0x10,%rsp
  48bb4a:	test   %eax,%eax
  48bb4c:	mov    %rax,%rdx
  48bb4f:	je     48be3c <wasm[0]::function[160]::builtin::Array.prototype.push+0x15bc>
  48bb55:	mov    $0x6,%eax
  48bb5a:	xor    %rcx,%rcx
  48bb5d:	mov    $0x1,%esi
  48bb62:	mov    %r13,%rdi
  48bb65:	mov    0x100(%rsp),%rbx
  48bb6d:	mov    0x108(%rsp),%r12
  48bb75:	mov    0x110(%rsp),%r13
  48bb7d:	mov    0x118(%rsp),%r14
  48bb85:	mov    0x120(%rsp),%r15
  48bb8d:	add    $0x130,%rsp
  48bb94:	mov    %rbp,%rsp
  48bb97:	pop    %rbp
  48bb98:	ret    $0x40
  48bb9b:	mov    0x48(%rsp),%edx
  48bb9f:	mov    0xe0(%rsp),%rax
  48bba7:	mov    %r13,%rcx
  48bbaa:	mov    %r15,%rdi
  48bbad:	mov    0x100(%rsp),%rbx
  48bbb5:	mov    0x108(%rsp),%r12
  48bbbd:	mov    0x110(%rsp),%r13
  48bbc5:	mov    0x118(%rsp),%r14
  48bbcd:	mov    0x120(%rsp),%r15
  48bbd5:	add    $0x130,%rsp
  48bbdc:	mov    %rbp,%rsp
  48bbdf:	pop    %rbp
  48bbe0:	ret    $0x40
  48bbe3:	mov    %rdx,%rax
  48bbe6:	mov    %r8,%rdx
  48bbe9:	mov    0x100(%rsp),%rbx
  48bbf1:	mov    0x108(%rsp),%r12
  48bbf9:	mov    0x110(%rsp),%r13
  48bc01:	mov    0x118(%rsp),%r14
  48bc09:	mov    0x120(%rsp),%r15
  48bc11:	add    $0x130,%rsp
  48bc18:	mov    %rbp,%rsp
  48bc1b:	pop    %rbp
  48bc1c:	ret    $0x40
  48bc1f:	mov    0xe8(%rsp),%rax
  48bc27:	mov    0xf0(%rsp),%rcx
  48bc2f:	mov    0x100(%rsp),%rbx
  48bc37:	mov    0x108(%rsp),%r12
  48bc3f:	mov    0x110(%rsp),%r13
  48bc47:	mov    0x118(%rsp),%r14
  48bc4f:	mov    0x120(%rsp),%r15
  48bc57:	add    $0x130,%rsp
  48bc5e:	mov    %rbp,%rsp
  48bc61:	pop    %rbp
  48bc62:	ret    $0x40
  48bc65:	mov    0xb0(%rsp),%rdi
  48bc6d:	call   3018d19 <wasmtime_builtin_new_epoch>
  48bc72:	mov    %rax,0xc0(%rsp)
  48bc7a:	jmp    48a920 <wasm[0]::function[160]::builtin::Array.prototype.push+0xa0>
  48bc7f:	mov    $0xa800000e,%esi
  48bc84:	mov    0xb0(%rsp),%rcx
  48bc8c:	mov    0x28(%rcx),%r10
  48bc90:	mov    0x1b4(%r10),%edx
  48bc97:	mov    $0x14,%ecx
  48bc9c:	mov    $0x10,%r8d
  48bca2:	mov    0xb0(%rsp),%rdi
  48bcaa:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
  48bcaf:	mov    %eax,%ecx
  48bcb1:	add    0x20(%rbx),%rcx
  48bcb5:	jmp    48aa49 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1c9>
  48bcba:	mov    0x8(%rbx),%rcx
  48bcbe:	mov    %rcx,0xc0(%rsp)
  48bcc6:	cmp    %rcx,%rax
  48bcc9:	jb     48b05c <wasm[0]::function[160]::builtin::Array.prototype.push+0x7dc>
  48bccf:	mov    0xb0(%rsp),%rdi
  48bcd7:	call   3018d19 <wasmtime_builtin_new_epoch>
  48bcdc:	mov    %rax,0xc0(%rsp)
  48bce4:	jmp    48b05c <wasm[0]::function[160]::builtin::Array.prototype.push+0x7dc>
  48bce9:	mov    0x8(%rbx),%rax
  48bced:	mov    %rax,0xc0(%rsp)
  48bcf5:	cmp    %rax,%r10
  48bcf8:	jb     48b22e <wasm[0]::function[160]::builtin::Array.prototype.push+0x9ae>
  48bcfe:	mov    0xb0(%rsp),%rdi
  48bd06:	call   3018d19 <wasmtime_builtin_new_epoch>
  48bd0b:	mov    %rax,0xc0(%rsp)
  48bd13:	mov    0xd0(%rsp),%rax
  48bd1b:	jmp    48b236 <wasm[0]::function[160]::builtin::Array.prototype.push+0x9b6>
  48bd20:	mov    0x8(%rbx),%rax
  48bd24:	mov    %rax,0xc0(%rsp)
  48bd2c:	cmp    %rax,%rsi
  48bd2f:	jb     48b4b5 <wasm[0]::function[160]::builtin::Array.prototype.push+0xc35>
  48bd35:	mov    0xb0(%rsp),%rdi
  48bd3d:	call   3018d19 <wasmtime_builtin_new_epoch>
  48bd42:	mov    %rax,0xc0(%rsp)
  48bd4a:	mov    0xd8(%rsp),%rdx
  48bd52:	jmp    48b4bd <wasm[0]::function[160]::builtin::Array.prototype.push+0xc3d>
  48bd57:	mov    0x8(%rbx),%rcx
  48bd5b:	mov    %rcx,0xc0(%rsp)
  48bd63:	cmp    %rcx,%rax
  48bd66:	jb     48b69f <wasm[0]::function[160]::builtin::Array.prototype.push+0xe1f>
  48bd6c:	mov    0xb0(%rsp),%rdi
  48bd74:	call   3018d19 <wasmtime_builtin_new_epoch>
  48bd79:	mov    %rax,0xc0(%rsp)
  48bd81:	mov    0xd8(%rsp),%r12
  48bd89:	jmp    48b6a7 <wasm[0]::function[160]::builtin::Array.prototype.push+0xe27>
  48bd8e:	ud2
  48bd90:	ud2
  48bd92:	ud2
  48bd94:	ud2
  48bd96:	ud2
  48bd98:	ud2
  48bd9a:	ud2
  48bd9c:	ud2
  48bd9e:	ud2
  48bda0:	ud2
  48bda2:	ud2
  48bda4:	ud2
  48bda6:	ud2
  48bda8:	ud2
  48bdaa:	ud2
  48bdac:	ud2
  48bdae:	ud2
  48bdb0:	ud2
  48bdb2:	ud2
  48bdb4:	ud2
  48bdb6:	ud2
  48bdb8:	ud2
  48bdba:	ud2
  48bdbc:	ud2
  48bdbe:	ud2
  48bdc0:	ud2
  48bdc2:	ud2
  48bdc4:	ud2
  48bdc6:	ud2
  48bdc8:	ud2
  48bdca:	ud2
  48bdcc:	ud2
  48bdce:	ud2
  48bdd0:	ud2
  48bdd2:	ud2
  48bdd4:	ud2
  48bdd6:	ud2
  48bdd8:	ud2
  48bdda:	ud2
  48bddc:	ud2
  48bdde:	ud2
  48bde0:	ud2
  48bde2:	ud2
  48bde4:	ud2
  48bde6:	ud2
  48bde8:	ud2
  48bdea:	ud2
  48bdec:	ud2
  48bdee:	ud2
  48bdf0:	ud2
  48bdf2:	ud2
  48bdf4:	ud2
  48bdf6:	ud2
  48bdf8:	ud2
  48bdfa:	ud2
  48bdfc:	ud2
  48bdfe:	ud2
  48be00:	ud2
  48be02:	ud2
  48be04:	ud2
  48be06:	ud2
  48be08:	ud2
  48be0a:	ud2
  48be0c:	ud2
  48be0e:	ud2
  48be10:	ud2
  48be12:	ud2
  48be14:	ud2
  48be16:	ud2
  48be18:	ud2
  48be1a:	ud2
  48be1c:	ud2
  48be1e:	ud2
  48be20:	ud2
  48be22:	ud2
  48be24:	ud2
  48be26:	ud2
  48be28:	ud2
  48be2a:	ud2
  48be2c:	ud2
  48be2e:	ud2
  48be30:	ud2
  48be32:	ud2
  48be34:	ud2
  48be36:	ud2
  48be38:	ud2
  48be3a:	ud2
  48be3c:	ud2
  48be3e:	add    %al,(%rax)
  48be40:	(bad)
  48be41:	(bad)
  48be42:	(bad)
  48be43:	(bad)
  48be44:	(bad)
  48be45:	(bad)
  48be46:	(bad)
  48be47:	rex.XB add %al,(%r8)
  48be4a:	add    %al,(%rax)
  48be4c:	add    %al,(%rax)
  48be4e:	add    %al,(%rax)
  48be50:	(bad)
  48be51:	(bad)
  48be52:	(bad)
  48be53:	(bad)
  48be54:	(bad)
  48be55:	lcall  *(%rdi)
  48be57:	add    %bh,%bh
  48be59:	(bad)
  48be5a:	(bad)
  48be5b:	incl   (%rax)
  48be5d:	add    %al,(%rax)
	...
