
/workspace/scriptw/target/performance-dense-numbers-20261030/v2/native-cause/candidate/runtime-portable.elf:     file format elf64-x86-64


Disassembly of section .text:

00000000029e0f20 <wasm[0]::function[1015]::helper::object_read>:
 29e0f20:	push   %rbp
 29e0f21:	mov    %rsp,%rbp
 29e0f24:	mov    0x8(%rdi),%r10
 29e0f28:	mov    0x18(%r10),%r10
 29e0f2c:	add    $0x330,%r10
 29e0f33:	cmp    %rsp,%r10
 29e0f36:	ja     29fbb39 <wasm[0]::function[1015]::helper::object_read+0x1ac19>
 29e0f3c:	sub    $0x320,%rsp
 29e0f43:	mov    %rbx,0x2f0(%rsp)
 29e0f4b:	mov    %r12,0x2f8(%rsp)
 29e0f53:	mov    %r13,0x300(%rsp)
 29e0f5b:	mov    %r14,0x308(%rsp)
 29e0f63:	mov    %r15,0x310(%rsp)
 29e0f6b:	mov    %rdx,0x198(%rsp)
 29e0f73:	mov    %rcx,0x1a0(%rsp)
 29e0f7b:	mov    %r9,0x1a8(%rsp)
 29e0f83:	mov    0x10(%rbp),%rsi
 29e0f87:	mov    %rsi,0x1b0(%rsp)
 29e0f8f:	mov    0x18(%rbp),%r9
 29e0f93:	mov    0x20(%rbp),%rcx
 29e0f97:	mov    %rcx,0x1b8(%rsp)
 29e0f9f:	mov    0x28(%rbp),%rax
 29e0fa3:	mov    %rax,0x1c0(%rsp)
 29e0fab:	mov    0x30(%rbp),%rdx
 29e0faf:	mov    0x38(%rbp),%rcx
 29e0fb3:	mov    0x40(%rbp),%rax
 29e0fb7:	mov    %r8d,0xe8(%rsp)
 29e0fbf:	mov    %r9d,0x68(%rsp)
 29e0fc4:	mov    %edx,0x60(%rsp)
 29e0fc8:	mov    %ecx,0xd0(%rsp)
 29e0fcf:	mov    %eax,0x140(%rsp)
 29e0fd6:	movl   $0x0,0x40(%rsp)
 29e0fde:	movl   $0x0,0x70(%rsp)
 29e0fe6:	movl   $0x0,0x50(%rsp)
 29e0fee:	mov    0x18(%rdi),%rcx
 29e0ff2:	mov    (%rcx),%rax
 29e0ff5:	mov    %rcx,0x2e8(%rsp)
 29e0ffd:	mov    0x8(%rdi),%rcx
 29e1001:	mov    %rdi,0x190(%rsp)
 29e1009:	mov    0x8(%rcx),%rdx
 29e100d:	mov    %rcx,0x2e0(%rsp)
 29e1015:	mov    %rdx,0x228(%rsp)
 29e101d:	mov    %rdx,%rcx
 29e1020:	cmp    %rcx,%rax
 29e1023:	jae    29fa48b <wasm[0]::function[1015]::helper::object_read+0x1956b>
 29e1029:	mov    0x140(%rsp),%ecx
 29e1030:	xor    %ebx,%ebx
 29e1032:	test   %ecx,%ecx
 29e1034:	je     29fbb3b <wasm[0]::function[1015]::helper::object_read+0x1ac1b>
 29e103a:	mov    0xe8(%rsp),%r9d
 29e1042:	mov    0xd0(%rsp),%esi
 29e1049:	mov    0x68(%rsp),%edi
 29e104d:	mov    0x60(%rsp),%r11d
 29e1052:	mov    0x70(%rsp),%r8d
 29e1057:	mov    0x50(%rsp),%r10d
 29e105c:	mov    0x40(%rsp),%edx
 29e1060:	xor    %r13,%r13
 29e1063:	mov    0x198(%rsp),%rax
 29e106b:	cmp    $0x4,%eax
 29e106e:	je     29e10a9 <wasm[0]::function[1015]::helper::object_read+0x189>
 29e1074:	mov    %rbx,0x1d0(%rsp)
 29e107c:	mov    %rbx,0x240(%rsp)
 29e1084:	mov    %rbx,0x280(%rsp)
 29e108c:	mov    %r13,0x288(%rsp)
 29e1094:	mov    %rbx,0x290(%rsp)
 29e109c:	mov    %rbx,0x298(%rsp)
 29e10a4:	jmp    29e1aa7 <wasm[0]::function[1015]::helper::object_read+0xb87>
 29e10a9:	mov    0xe8(%rsp),%r9d
 29e10b1:	mov    0xd0(%rsp),%esi
 29e10b8:	mov    0x140(%rsp),%ecx
 29e10bf:	mov    0x68(%rsp),%edi
 29e10c3:	mov    0x60(%rsp),%r11d
 29e10c8:	mov    0x70(%rsp),%r8d
 29e10cd:	mov    0x50(%rsp),%r10d
 29e10d2:	mov    0x40(%rsp),%edx
 29e10d6:	xor    %eax,%eax
 29e10d8:	xor    %r13,%r13
 29e10db:	mov    0x1b8(%rsp),%rbx
 29e10e3:	cmp    $0x4,%ebx
 29e10e6:	je     29e1101 <wasm[0]::function[1015]::helper::object_read+0x1e1>
 29e10ec:	mov    %rax,0x1d0(%rsp)
 29e10f4:	mov    %rax,0x240(%rsp)
 29e10fc:	jmp    29e197e <wasm[0]::function[1015]::helper::object_read+0xa5e>
 29e1101:	xor    %r12d,%r12d
 29e1104:	test   %r11d,%r11d
 29e1107:	jne    29e111a <wasm[0]::function[1015]::helper::object_read+0x1fa>
 29e110d:	mov    0x2e0(%rsp),%rax
 29e1115:	jmp    29e1179 <wasm[0]::function[1015]::helper::object_read+0x259>
 29e111a:	xor    %r12d,%r12d
 29e111d:	test   $0x1,%r11d
 29e1124:	je     29e1137 <wasm[0]::function[1015]::helper::object_read+0x217>
 29e112a:	mov    0x2e0(%rsp),%rax
 29e1132:	jmp    29e1179 <wasm[0]::function[1015]::helper::object_read+0x259>
 29e1137:	mov    0x2e0(%rsp),%rax
 29e113f:	mov    0x28(%rax),%rbx
 29e1143:	mov    0x20(%rax),%r12
 29e1147:	mov    %r11d,%r13d
 29e114a:	lea    0x4(%r12,%r13,1),%r12
 29e114f:	xor    %r14,%r14
 29e1152:	cmp    %rbx,%r13
 29e1155:	cmova  %r14,%r12
 29e1159:	mov    (%r12),%ebx
 29e115d:	mov    0x190(%rsp),%r12
 29e1165:	mov    0x28(%r12),%r12
 29e116a:	cmp    0x234(%r12),%ebx
 29e1172:	sete   %bl
 29e1175:	movzbl %bl,%r12d
 29e1179:	test   %r12d,%r12d
 29e117c:	je     29fbb3d <wasm[0]::function[1015]::helper::object_read+0x1ac1d>
 29e1182:	test   %r11d,%r11d
 29e1185:	je     29fbb3f <wasm[0]::function[1015]::helper::object_read+0x1ac1f>
 29e118b:	test   %r11d,%r11d
 29e118e:	je     29fbb41 <wasm[0]::function[1015]::helper::object_read+0x1ac21>
 29e1194:	mov    0x28(%rax),%rbx
 29e1198:	mov    0x20(%rax),%r12
 29e119c:	mov    %rax,0x2e0(%rsp)
 29e11a4:	mov    %r11d,%r14d
 29e11a7:	lea    (%r12,%r14,1),%rax
 29e11ab:	xor    %r13,%r13
 29e11ae:	cmp    %rbx,%r14
 29e11b1:	cmova  %r13,%rax
 29e11b5:	mov    0x10(%rax),%r14d
 29e11b9:	xor    %eax,%eax
 29e11bb:	test   %r14d,%r14d
 29e11be:	je     29fbb43 <wasm[0]::function[1015]::helper::object_read+0x1ac23>
 29e11c4:	test   %r14d,%r14d
 29e11c7:	je     29fbb45 <wasm[0]::function[1015]::helper::object_read+0x1ac25>
 29e11cd:	mov    %r14d,%r14d
 29e11d0:	lea    0x10(%r12,%r14,1),%r12
 29e11d5:	cmp    %rbx,%r14
 29e11d8:	cmova  %r13,%r12
 29e11dc:	mov    (%r12),%ebx
 29e11e0:	cmp    $0x6,%ebx
 29e11e3:	je     29e11fe <wasm[0]::function[1015]::helper::object_read+0x2de>
 29e11e9:	mov    %rax,0x1d0(%rsp)
 29e11f1:	mov    %rax,0x240(%rsp)
 29e11f9:	jmp    29e197e <wasm[0]::function[1015]::helper::object_read+0xa5e>
 29e11fe:	mov    $0x8c,%edx
 29e1203:	mov    0x190(%rsp),%rsi
 29e120b:	mov    0x190(%rsp),%rdi
 29e1213:	call   2f307a0 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 29e1218:	test   %eax,%eax
 29e121a:	mov    %rax,%rdi
 29e121d:	je     29fbb47 <wasm[0]::function[1015]::helper::object_read+0x1ac27>
 29e1223:	mov    0x1b8(%rsp),%rcx
 29e122b:	cmp    $0x4,%ecx
 29e122e:	je     29e1278 <wasm[0]::function[1015]::helper::object_read+0x358>
 29e1234:	mov    0xe8(%rsp),%r9d
 29e123c:	mov    0xd0(%rsp),%esi
 29e1243:	mov    0x140(%rsp),%ecx
 29e124a:	mov    0x68(%rsp),%edi
 29e124e:	mov    0x60(%rsp),%r11d
 29e1253:	mov    0x70(%rsp),%r8d
 29e1258:	mov    0x50(%rsp),%r10d
 29e125d:	mov    0x40(%rsp),%edx
 29e1261:	xor    %eax,%eax
 29e1263:	mov    %rax,0x1d0(%rsp)
 29e126b:	mov    %rax,0x240(%rsp)
 29e1273:	jmp    29e197b <wasm[0]::function[1015]::helper::object_read+0xa5b>
 29e1278:	mov    0x1b8(%rsp),%rcx
 29e1280:	cmp    $0x3,%ecx
 29e1283:	je     29e18e9 <wasm[0]::function[1015]::helper::object_read+0x9c9>
 29e1289:	mov    0x1b8(%rsp),%rcx
 29e1291:	cmp    $0x4,%ecx
 29e1294:	je     29e1797 <wasm[0]::function[1015]::helper::object_read+0x877>
 29e129a:	mov    0x1b8(%rsp),%rcx
 29e12a2:	cmp    $0xa,%ecx
 29e12a5:	je     29e1354 <wasm[0]::function[1015]::helper::object_read+0x434>
 29e12ab:	mov    0x1b8(%rsp),%rax
 29e12b3:	mov    0x1b8(%rsp),%rcx
 29e12bb:	test   %eax,%ecx
 29e12bd:	sete   %cl
 29e12c0:	mov    $0x1,%eax
 29e12c5:	mov    0x1b8(%rsp),%rdx
 29e12cd:	cmp    $0x1,%edx
 29e12d0:	sete   %dl
 29e12d3:	or     %edx,%ecx
 29e12d5:	test   %cl,%cl
 29e12d7:	jne    29e1317 <wasm[0]::function[1015]::helper::object_read+0x3f7>
 29e12dd:	mov    0x1b8(%rsp),%rcx
 29e12e5:	cmp    $0x2,%ecx
 29e12e8:	je     29e1304 <wasm[0]::function[1015]::helper::object_read+0x3e4>
 29e12ee:	mov    0x60(%rsp),%edx
 29e12f2:	mov    %rdi,%rax
 29e12f5:	cmp    %eax,%edx
 29e12f7:	sete   %sil
 29e12fb:	movzbl %sil,%eax
 29e12ff:	jmp    29e1317 <wasm[0]::function[1015]::helper::object_read+0x3f7>
 29e1304:	mov    0x1c0(%rsp),%r8
 29e130c:	test   %r8,%r8
 29e130f:	sete   %sil
 29e1313:	movzbl %sil,%eax
 29e1317:	mov    0xe8(%rsp),%r9d
 29e131f:	mov    0xd0(%rsp),%esi
 29e1326:	mov    0x140(%rsp),%ecx
 29e132d:	mov    0x68(%rsp),%edi
 29e1331:	mov    0x60(%rsp),%r11d
 29e1336:	mov    0x70(%rsp),%r8d
 29e133b:	mov    0x50(%rsp),%r10d
 29e1340:	mov    0x40(%rsp),%edx
 29e1344:	xor    %r13d,%r13d
 29e1347:	mov    %r13,0x1d0(%rsp)
 29e134f:	jmp    29e18dc <wasm[0]::function[1015]::helper::object_read+0x9bc>
 29e1354:	mov    %rdi,%rax
 29e1357:	mov    0x60(%rsp),%r9d
 29e135c:	xor    %ecx,%ecx
 29e135e:	test   %r9d,%r9d
 29e1361:	je     29e13b4 <wasm[0]::function[1015]::helper::object_read+0x494>
 29e1367:	xor    %ecx,%ecx
 29e1369:	test   $0x1,%r9d
 29e1370:	jne    29e13b4 <wasm[0]::function[1015]::helper::object_read+0x494>
 29e1376:	mov    0x2e0(%rsp),%r12
 29e137e:	mov    0x28(%r12),%rcx
 29e1383:	mov    0x20(%r12),%rdx
 29e1388:	mov    %r9d,%esi
 29e138b:	lea    0x4(%rdx,%rsi,1),%rdx
 29e1390:	xor    %rdi,%rdi
 29e1393:	cmp    %rcx,%rsi
 29e1396:	cmova  %rdi,%rdx
 29e139a:	mov    (%rdx),%ecx
 29e139c:	mov    0x190(%rsp),%rdx
 29e13a4:	mov    0x28(%rdx),%rdx
 29e13a8:	cmp    0x23c(%rdx),%ecx
 29e13ae:	sete   %cl
 29e13b1:	movzbl %cl,%ecx
 29e13b4:	test   %ecx,%ecx
 29e13b6:	je     29fbb49 <wasm[0]::function[1015]::helper::object_read+0x1ac29>
 29e13bc:	xor    %ecx,%ecx
 29e13be:	test   %eax,%eax
 29e13c0:	je     29e1410 <wasm[0]::function[1015]::helper::object_read+0x4f0>
 29e13c6:	xor    %ecx,%ecx
 29e13c8:	test   $0x1,%eax
 29e13cd:	jne    29e1410 <wasm[0]::function[1015]::helper::object_read+0x4f0>
 29e13d3:	mov    0x2e0(%rsp),%r12
 29e13db:	mov    0x28(%r12),%rcx
 29e13e0:	mov    0x20(%r12),%rdx
 29e13e5:	mov    %eax,%esi
 29e13e7:	lea    0x4(%rdx,%rsi,1),%rdx
 29e13ec:	xor    %rdi,%rdi
 29e13ef:	cmp    %rcx,%rsi
 29e13f2:	cmova  %rdi,%rdx
 29e13f6:	mov    (%rdx),%ecx
 29e13f8:	mov    0x190(%rsp),%rdx
 29e1400:	mov    0x28(%rdx),%rdx
 29e1404:	cmp    0x23c(%rdx),%ecx
 29e140a:	sete   %cl
 29e140d:	movzbl %cl,%ecx
 29e1410:	test   %ecx,%ecx
 29e1412:	je     29fbb4b <wasm[0]::function[1015]::helper::object_read+0x1ac2b>
 29e1418:	mov    0x60(%rsp),%r11d
 29e141d:	xor    %r13d,%r13d
 29e1420:	test   %r11d,%r11d
 29e1423:	je     29fbb4d <wasm[0]::function[1015]::helper::object_read+0x1ac2d>
 29e1429:	test   %r11d,%r11d
 29e142c:	je     29fbb4f <wasm[0]::function[1015]::helper::object_read+0x1ac2f>
 29e1432:	mov    0x2e0(%rsp),%r12
 29e143a:	mov    0x28(%r12),%rcx
 29e143f:	mov    0x20(%r12),%rdx
 29e1444:	mov    %r11d,%r8d
 29e1447:	lea    (%rdx,%r8,1),%rdi
 29e144b:	xor    %rsi,%rsi
 29e144e:	cmp    %rcx,%r8
 29e1451:	cmova  %rsi,%rdi
 29e1455:	mov    0x10(%rdi),%r14d
 29e1459:	test   %eax,%eax
 29e145b:	je     29fbb51 <wasm[0]::function[1015]::helper::object_read+0x1ac31>
 29e1461:	mov    %eax,%eax
 29e1463:	lea    (%rdx,%rax,1),%r9
 29e1467:	cmp    %rcx,%rax
 29e146a:	cmova  %rsi,%r9
 29e146e:	mov    0x10(%r9),%eax
 29e1472:	mov    0x14(%rdi),%r8d
 29e1476:	mov    %r8d,0xf0(%rsp)
 29e147e:	mov    0x14(%r9),%edi
 29e1482:	mov    %edi,0x148(%rsp)
 29e1489:	test   %r8d,%r8d
 29e148c:	je     29fbb53 <wasm[0]::function[1015]::helper::object_read+0x1ac33>
 29e1492:	test   %r8d,%r8d
 29e1495:	je     29fbb55 <wasm[0]::function[1015]::helper::object_read+0x1ac35>
 29e149b:	mov    %r8d,%r9d
 29e149e:	lea    0x10(%rdx,%r9,1),%r8
 29e14a3:	cmp    %rcx,%r9
 29e14a6:	cmova  %rsi,%r8
 29e14aa:	mov    (%r8),%ebx
 29e14ad:	test   %edi,%edi
 29e14af:	je     29fbb57 <wasm[0]::function[1015]::helper::object_read+0x1ac37>
 29e14b5:	test   %edi,%edi
 29e14b7:	je     29fbb59 <wasm[0]::function[1015]::helper::object_read+0x1ac39>
 29e14bd:	mov    %edi,%edi
 29e14bf:	lea    0x10(%rdx,%rdi,1),%rdx
 29e14c4:	cmp    %rcx,%rdi
 29e14c7:	cmova  %rsi,%rdx
 29e14cb:	mov    (%rdx),%ecx
 29e14cd:	mov    %rcx,0x1d0(%rsp)
 29e14d5:	mov    0xe8(%rsp),%r9d
 29e14dd:	mov    0xd0(%rsp),%esi
 29e14e4:	mov    0x140(%rsp),%ecx
 29e14eb:	mov    0x68(%rsp),%edi
 29e14ef:	mov    0x70(%rsp),%r8d
 29e14f4:	mov    0x50(%rsp),%r10d
 29e14f9:	mov    0x40(%rsp),%edx
 29e14fd:	cmp    %eax,%r14d
 29e1500:	sete   %r12b
 29e1504:	mov    0x1d0(%rsp),%rax
 29e150c:	cmp    %eax,%ebx
 29e150e:	sete   %r14b
 29e1512:	mov    %r12,%rax
 29e1515:	and    %r14d,%eax
 29e1518:	movzbl %al,%eax
 29e151b:	mov    %rax,0x1c8(%rsp)
 29e1523:	test   %r12b,%r14b
 29e1526:	jne    29e1539 <wasm[0]::function[1015]::helper::object_read+0x619>
 29e152c:	mov    0x1c8(%rsp),%rax
 29e1534:	jmp    29e18dc <wasm[0]::function[1015]::helper::object_read+0x9bc>
 29e1539:	mov    0xe8(%rsp),%ecx
 29e1540:	mov    0xd0(%rsp),%edx
 29e1547:	mov    0x140(%rsp),%esi
 29e154e:	mov    0x68(%rsp),%edi
 29e1552:	mov    0x60(%rsp),%r8d
 29e1557:	mov    0x70(%rsp),%r9d
 29e155c:	mov    0x50(%rsp),%r10d
 29e1561:	mov    0x40(%rsp),%r11d
 29e1566:	xor    %r13d,%r13d
 29e1569:	mov    %r13,0x240(%rsp)
 29e1571:	mov    %ecx,0x100(%rsp)
 29e1578:	mov    %edx,0x78(%rsp)
 29e157c:	mov    %esi,0xa0(%rsp)
 29e1583:	mov    %edi,0xa8(%rsp)
 29e158a:	mov    %r8d,0x48(%rsp)
 29e158f:	mov    %r9d,0x80(%rsp)
 29e1597:	mov    %r10d,0xb8(%rsp)
 29e159f:	mov    %r11d,0x130(%rsp)
 29e15a7:	mov    0x2e8(%rsp),%r15
 29e15af:	mov    (%r15),%rdx
 29e15b2:	mov    0x228(%rsp),%rax
 29e15ba:	cmp    %rax,%rdx
 29e15bd:	jae    29fa4a5 <wasm[0]::function[1015]::helper::object_read+0x19585>
 29e15c3:	mov    0x240(%rsp),%r13
 29e15cb:	jmp    29e15d8 <wasm[0]::function[1015]::helper::object_read+0x6b8>
 29e15d0:	mov    0x240(%rsp),%r13
 29e15d8:	cmp    %ebx,%r13d
 29e15db:	jb     29e15ee <wasm[0]::function[1015]::helper::object_read+0x6ce>
 29e15e1:	mov    0x1c8(%rsp),%rax
 29e15e9:	jmp    29e175c <wasm[0]::function[1015]::helper::object_read+0x83c>
 29e15ee:	mov    0xf0(%rsp),%esi
 29e15f5:	test   %esi,%esi
 29e15f7:	je     29fbb5b <wasm[0]::function[1015]::helper::object_read+0x1ac3b>
 29e15fd:	test   %esi,%esi
 29e15ff:	je     29fbb5d <wasm[0]::function[1015]::helper::object_read+0x1ac3d>
 29e1605:	mov    0x2e0(%rsp),%r12
 29e160d:	mov    0x28(%r12),%rax
 29e1612:	mov    0x20(%r12),%rcx
 29e1617:	mov    %esi,%r8d
 29e161a:	lea    0x10(%rcx,%r8,1),%rdi
 29e161f:	xor    %rdx,%rdx
 29e1622:	cmp    %rax,%r8
 29e1625:	cmova  %rdx,%rdi
 29e1629:	mov    (%rdi),%r8d
 29e162c:	cmp    %r8d,%r13d
 29e162f:	jae    29fbb5f <wasm[0]::function[1015]::helper::object_read+0x1ac3f>
 29e1635:	mov    %r8d,%edi
 29e1638:	shl    $0x3,%rdi
 29e163c:	shr    $0x20,%rdi
 29e1640:	test   %rdi,%rdi
 29e1643:	jne    29fbb61 <wasm[0]::function[1015]::helper::object_read+0x1ac41>
 29e1649:	shl    $0x3,%r8d
 29e164d:	add    $0x18,%r8d
 29e1651:	jb     29fbb63 <wasm[0]::function[1015]::helper::object_read+0x1ac43>
 29e1657:	add    %r8d,%esi
 29e165a:	jb     29fbb65 <wasm[0]::function[1015]::helper::object_read+0x1ac45>
 29e1660:	mov    %esi,%edi
 29e1662:	lea    (%rcx,%rdi,1),%rsi
 29e1666:	cmp    %rax,%rdi
 29e1669:	cmova  %rdx,%rsi
 29e166d:	mov    %r13,%rdi
 29e1670:	shl    $0x3,%edi
 29e1673:	add    $0x18,%edi
 29e1679:	sub    %edi,%r8d
 29e167c:	sub    %r8,%rsi
 29e167f:	mov    (%rsi),%rsi
 29e1682:	mov    0x148(%rsp),%r8d
 29e168a:	test   %r8d,%r8d
 29e168d:	je     29fbb67 <wasm[0]::function[1015]::helper::object_read+0x1ac47>
 29e1693:	test   %r8d,%r8d
 29e1696:	je     29fbb69 <wasm[0]::function[1015]::helper::object_read+0x1ac49>
 29e169c:	mov    %r8d,%r10d
 29e169f:	lea    0x10(%rcx,%r10,1),%r9
 29e16a4:	cmp    %rax,%r10
 29e16a7:	cmova  %rdx,%r9
 29e16ab:	mov    (%r9),%r9d
 29e16ae:	cmp    %r9d,%r13d
 29e16b1:	jae    29fbb6b <wasm[0]::function[1015]::helper::object_read+0x1ac4b>
 29e16b7:	mov    %r9d,%r10d
 29e16ba:	shl    $0x3,%r10
 29e16be:	shr    $0x20,%r10
 29e16c2:	test   %r10,%r10
 29e16c5:	jne    29fbb6d <wasm[0]::function[1015]::helper::object_read+0x1ac4d>
 29e16cb:	shl    $0x3,%r9d
 29e16cf:	add    $0x18,%r9d
 29e16d3:	jb     29fbb6f <wasm[0]::function[1015]::helper::object_read+0x1ac4f>
 29e16d9:	add    %r9d,%r8d
 29e16dc:	jb     29fbb71 <wasm[0]::function[1015]::helper::object_read+0x1ac51>
 29e16e2:	mov    %r8d,%r8d
 29e16e5:	add    %r8,%rcx
 29e16e8:	cmp    %rax,%r8
 29e16eb:	cmova  %rdx,%rcx
 29e16ef:	sub    %edi,%r9d
 29e16f2:	sub    %r9,%rcx
 29e16f5:	mov    (%rcx),%rcx
 29e16f8:	cmp    %rcx,%rsi
 29e16fb:	sete   %al
 29e16fe:	movzbl %al,%eax
 29e1701:	cmp    %rcx,%rsi
 29e1704:	jne    29e175c <wasm[0]::function[1015]::helper::object_read+0x83c>
 29e170a:	mov    0x100(%rsp),%ecx
 29e1711:	mov    0x78(%rsp),%edx
 29e1715:	mov    0xa0(%rsp),%esi
 29e171c:	mov    0xa8(%rsp),%edi
 29e1723:	mov    0x48(%rsp),%r8d
 29e1728:	mov    0x80(%rsp),%r9d
 29e1730:	mov    0xb8(%rsp),%r10d
 29e1738:	mov    0x130(%rsp),%r11d
 29e1740:	add    $0x1,%r13d
 29e1747:	mov    %rax,0x1c8(%rsp)
 29e174f:	mov    %r13,0x240(%rsp)
 29e1757:	jmp    29e1571 <wasm[0]::function[1015]::helper::object_read+0x651>
 29e175c:	mov    0x100(%rsp),%r9d
 29e1764:	mov    0x78(%rsp),%esi
 29e1768:	mov    0xa0(%rsp),%ecx
 29e176f:	mov    0xa8(%rsp),%edi
 29e1776:	mov    0x48(%rsp),%r11d
 29e177b:	mov    0x80(%rsp),%r8d
 29e1783:	mov    0xb8(%rsp),%r10d
 29e178b:	mov    0x130(%rsp),%edx
 29e1792:	jmp    29e18dc <wasm[0]::function[1015]::helper::object_read+0x9bc>
 29e1797:	mov    %rdi,%rax
 29e179a:	mov    0x60(%rsp),%ecx
 29e179e:	cmp    %eax,%ecx
 29e17a0:	je     29e189f <wasm[0]::function[1015]::helper::object_read+0x97f>
 29e17a6:	xor    %edx,%edx
 29e17a8:	test   %ecx,%ecx
 29e17aa:	je     29e17fb <wasm[0]::function[1015]::helper::object_read+0x8db>
 29e17b0:	xor    %edx,%edx
 29e17b2:	test   $0x1,%ecx
 29e17b8:	jne    29e17fb <wasm[0]::function[1015]::helper::object_read+0x8db>
 29e17be:	mov    0x2e0(%rsp),%r12
 29e17c6:	mov    0x28(%r12),%rdx
 29e17cb:	mov    0x20(%r12),%rdi
 29e17d0:	mov    %ecx,%esi
 29e17d2:	lea    0x4(%rdi,%rsi,1),%rcx
 29e17d7:	xor    %rdi,%rdi
 29e17da:	cmp    %rdx,%rsi
 29e17dd:	cmova  %rdi,%rcx
 29e17e1:	mov    (%rcx),%ecx
 29e17e3:	mov    0x190(%rsp),%rdx
 29e17eb:	mov    0x28(%rdx),%rdx
 29e17ef:	cmp    0x234(%rdx),%ecx
 29e17f5:	sete   %cl
 29e17f8:	movzbl %cl,%edx
 29e17fb:	test   %edx,%edx
 29e17fd:	je     29fbb73 <wasm[0]::function[1015]::helper::object_read+0x1ac53>
 29e1803:	xor    %esi,%esi
 29e1805:	test   %eax,%eax
 29e1807:	jne    29e1815 <wasm[0]::function[1015]::helper::object_read+0x8f5>
 29e180d:	mov    %rax,%rdi
 29e1810:	jmp    29e186b <wasm[0]::function[1015]::helper::object_read+0x94b>
 29e1815:	xor    %esi,%esi
 29e1817:	test   $0x1,%eax
 29e181c:	je     29e182a <wasm[0]::function[1015]::helper::object_read+0x90a>
 29e1822:	mov    %rax,%rdi
 29e1825:	jmp    29e186b <wasm[0]::function[1015]::helper::object_read+0x94b>
 29e182a:	mov    0x2e0(%rsp),%r12
 29e1832:	mov    0x28(%r12),%rcx
 29e1837:	mov    0x20(%r12),%rsi
 29e183c:	mov    %eax,%edx
 29e183e:	mov    %rax,%rdi
 29e1841:	lea    0x4(%rsi,%rdx,1),%rax
 29e1846:	xor    %rsi,%rsi
 29e1849:	cmp    %rcx,%rdx
 29e184c:	cmova  %rsi,%rax
 29e1850:	mov    (%rax),%ecx
 29e1852:	mov    0x190(%rsp),%rdx
 29e185a:	mov    0x28(%rdx),%rdx
 29e185e:	cmp    0x234(%rdx),%ecx
 29e1864:	sete   %dl
 29e1867:	rex movzbl %dl,%esi
 29e186b:	test   %esi,%esi
 29e186d:	je     29fbb75 <wasm[0]::function[1015]::helper::object_read+0x1ac55>
 29e1873:	mov    0x60(%rsp),%edx
 29e1877:	xor    %r8d,%r8d
 29e187a:	test   %edx,%edx
 29e187c:	je     29fbb77 <wasm[0]::function[1015]::helper::object_read+0x1ac57>
 29e1882:	mov    %rdi,%rcx
 29e1885:	mov    0x190(%rsp),%rsi
 29e188d:	mov    0x190(%rsp),%rdi
 29e1895:	call   2ae54e0 <wasm[0]::function[1057]::helper::string_equality>
 29e189a:	jmp    29e18a4 <wasm[0]::function[1015]::helper::object_read+0x984>
 29e189f:	mov    $0x1,%eax
 29e18a4:	mov    0xe8(%rsp),%r9d
 29e18ac:	mov    0xd0(%rsp),%esi
 29e18b3:	mov    0x140(%rsp),%ecx
 29e18ba:	mov    0x68(%rsp),%edi
 29e18be:	mov    0x60(%rsp),%r11d
 29e18c3:	mov    0x70(%rsp),%r8d
 29e18c8:	mov    0x50(%rsp),%r10d
 29e18cd:	mov    0x40(%rsp),%edx
 29e18d1:	xor    %r13d,%r13d
 29e18d4:	mov    %r13,0x1d0(%rsp)
 29e18dc:	mov    %r13,0x240(%rsp)
 29e18e4:	jmp    29e197b <wasm[0]::function[1015]::helper::object_read+0xa5b>
 29e18e9:	mov    0xe8(%rsp),%r9d
 29e18f1:	mov    0xd0(%rsp),%esi
 29e18f8:	mov    0x140(%rsp),%ecx
 29e18ff:	mov    0x68(%rsp),%edi
 29e1903:	mov    0x60(%rsp),%r11d
 29e1908:	mov    0x70(%rsp),%r8d
 29e190d:	mov    0x50(%rsp),%r10d
 29e1912:	mov    0x40(%rsp),%edx
 29e1916:	xor    %r13,%r13
 29e1919:	mov    0x1c0(%rsp),%rax
 29e1921:	mov    0x1c0(%rsp),%rbx
 29e1929:	test   %rbx,%rax
 29e192c:	sete   %al
 29e192f:	movq   %rbx,%xmm0
 29e1934:	ucomisd %xmm0,%xmm0
 29e1938:	setp   %r12b
 29e193c:	setne  %r14b
 29e1940:	or     %r14d,%r12d
 29e1943:	movq   %r13,%xmm0
 29e1948:	ucomisd %xmm0,%xmm0
 29e194c:	setp   %r14b
 29e1950:	setne  %r15b
 29e1954:	or     %r15d,%r14d
 29e1957:	and    %r14d,%r12d
 29e195a:	or     %r12d,%eax
 29e195d:	movzbl %al,%eax
 29e1960:	xor    %r13d,%r13d
 29e1963:	mov    %r13,0x240(%rsp)
 29e196b:	mov    0x240(%rsp),%rbx
 29e1973:	mov    %rbx,0x1d0(%rsp)
 29e197b:	xor    %r13,%r13
 29e197e:	xor    %ebx,%ebx
 29e1980:	xor    %r12,%r12
 29e1983:	test   %eax,%eax
 29e1985:	jne    29e19b0 <wasm[0]::function[1015]::helper::object_read+0xa90>
 29e198b:	mov    %rbx,0x280(%rsp)
 29e1993:	mov    %r12,0x288(%rsp)
 29e199b:	mov    %rbx,0x290(%rsp)
 29e19a3:	mov    %rbx,0x298(%rsp)
 29e19ab:	jmp    29e1aa7 <wasm[0]::function[1015]::helper::object_read+0xb87>
 29e19b0:	xor    %eax,%eax
 29e19b2:	test   %r9d,%r9d
 29e19b5:	je     29e1a08 <wasm[0]::function[1015]::helper::object_read+0xae8>
 29e19bb:	xor    %eax,%eax
 29e19bd:	test   $0x1,%r9d
 29e19c4:	jne    29e1a08 <wasm[0]::function[1015]::helper::object_read+0xae8>
 29e19ca:	mov    0x2e0(%rsp),%r12
 29e19d2:	mov    0x28(%r12),%rax
 29e19d7:	mov    0x20(%r12),%rdx
 29e19dc:	mov    %r9d,%ebx
 29e19df:	lea    0x4(%rdx,%rbx,1),%rdx
 29e19e4:	xor    %r12,%r12
 29e19e7:	cmp    %rax,%rbx
 29e19ea:	cmova  %r12,%rdx
 29e19ee:	mov    (%rdx),%eax
 29e19f0:	mov    0x190(%rsp),%rdx
 29e19f8:	mov    0x28(%rdx),%rdx
 29e19fc:	cmp    0x234(%rdx),%eax
 29e1a02:	sete   %al
 29e1a05:	movzbl %al,%eax
 29e1a08:	test   %eax,%eax
 29e1a0a:	je     29fbb79 <wasm[0]::function[1015]::helper::object_read+0x1ac59>
 29e1a10:	test   %r9d,%r9d
 29e1a13:	je     29fbb7b <wasm[0]::function[1015]::helper::object_read+0x1ac5b>
 29e1a19:	test   %r9d,%r9d
 29e1a1c:	je     29fbb7d <wasm[0]::function[1015]::helper::object_read+0x1ac5d>
 29e1a22:	mov    0x2e0(%rsp),%r12
 29e1a2a:	mov    0x28(%r12),%rax
 29e1a2f:	mov    0x20(%r12),%rbx
 29e1a34:	mov    %r9d,%r14d
 29e1a37:	lea    (%rbx,%r14,1),%rdx
 29e1a3b:	xor    %r12,%r12
 29e1a3e:	cmp    %rax,%r14
 29e1a41:	cmova  %r12,%rdx
 29e1a45:	mov    0x10(%rdx),%r14d
 29e1a49:	xor    %edx,%edx
 29e1a4b:	test   %r14d,%r14d
 29e1a4e:	je     29fbb7f <wasm[0]::function[1015]::helper::object_read+0x1ac5f>
 29e1a54:	test   %r14d,%r14d
 29e1a57:	je     29fbb81 <wasm[0]::function[1015]::helper::object_read+0x1ac61>
 29e1a5d:	mov    %r14d,%r15d
 29e1a60:	lea    0x10(%rbx,%r15,1),%r14
 29e1a65:	cmp    %rax,%r15
 29e1a68:	cmova  %r12,%r14
 29e1a6c:	mov    $0x1,%ebx
 29e1a71:	mov    $0x3,%eax
 29e1a76:	mov    %rax,0x280(%rsp)
 29e1a7e:	xorpd  %xmm0,%xmm0
 29e1a82:	mov    (%r14),%eax
 29e1a85:	cvtsi2sd %rax,%xmm0
 29e1a8a:	movq   %xmm0,%r12
 29e1a8f:	mov    %r12,0x288(%rsp)
 29e1a97:	mov    %rdx,0x290(%rsp)
 29e1a9f:	mov    %rdx,0x298(%rsp)
 29e1aa7:	mov    %esi,0x50(%rsp)
 29e1aab:	mov    %ecx,0x70(%rsp)
 29e1aaf:	mov    %edi,0x60(%rsp)
 29e1ab3:	mov    %r11d,0x68(%rsp)
 29e1ab8:	mov    %r8d,0x140(%rsp)
 29e1ac0:	mov    %r10d,0xd0(%rsp)
 29e1ac8:	mov    %edx,0xe8(%rsp)
 29e1acf:	test   %ebx,%ebx
 29e1ad1:	je     29e1ae7 <wasm[0]::function[1015]::helper::object_read+0xbc7>
 29e1ad7:	mov    %rdx,%rax
 29e1ada:	mov    0x290(%rsp),%rsi
 29e1ae2:	jmp    29fa43a <wasm[0]::function[1015]::helper::object_read+0x1951a>
 29e1ae7:	mov    0x190(%rsp),%rcx
 29e1aef:	mov    0x8c0(%rcx),%edx
 29e1af5:	test   %edx,%edx
 29e1af7:	je     29fbb83 <wasm[0]::function[1015]::helper::object_read+0x1ac63>
 29e1afd:	mov    0x198(%rsp),%rcx
 29e1b05:	mov    0x1a0(%rsp),%r8
 29e1b0d:	mov    0x190(%rsp),%rsi
 29e1b15:	mov    0x190(%rsp),%rdi
 29e1b1d:	call   2a63140 <wasm[0]::function[1041]::helper::value_to_object>
 29e1b22:	mov    %rax,0x2d0(%rsp)
 29e1b2a:	mov    %rcx,0x2d8(%rsp)
 29e1b32:	mov    %edx,0x40(%rsp)
 29e1b36:	mov    $0x1,%eax
 29e1b3b:	mov    %rax,0x278(%rsp)
 29e1b43:	cmp    $0x1,%esi
 29e1b46:	je     29fa40f <wasm[0]::function[1015]::helper::object_read+0x194ef>
 29e1b4c:	xor    %eax,%eax
 29e1b4e:	test   %edx,%edx
 29e1b50:	je     29e1ba1 <wasm[0]::function[1015]::helper::object_read+0xc81>
 29e1b56:	xor    %eax,%eax
 29e1b58:	test   $0x1,%edx
 29e1b5e:	jne    29e1ba1 <wasm[0]::function[1015]::helper::object_read+0xc81>
 29e1b64:	mov    0x2e0(%rsp),%r12
 29e1b6c:	mov    0x28(%r12),%rax
 29e1b71:	mov    0x20(%r12),%rcx
 29e1b76:	mov    %edx,%esi
 29e1b78:	lea    0x4(%rcx,%rsi,1),%rcx
 29e1b7d:	xor    %rdi,%rdi
 29e1b80:	cmp    %rax,%rsi
 29e1b83:	cmova  %rdi,%rcx
 29e1b87:	mov    (%rcx),%eax
 29e1b89:	mov    0x190(%rsp),%rcx
 29e1b91:	mov    0x28(%rcx),%rcx
 29e1b95:	cmp    0x1e8(%rcx),%eax
 29e1b9b:	sete   %al
 29e1b9e:	movzbl %al,%eax
 29e1ba1:	test   %eax,%eax
 29e1ba3:	jne    29efbb2 <wasm[0]::function[1015]::helper::object_read+0xec92>
 29e1ba9:	xor    %eax,%eax
 29e1bab:	movl   $0x0,0x100(%rsp)
 29e1bb6:	test   %edx,%edx
 29e1bb8:	je     29e1c0c <wasm[0]::function[1015]::helper::object_read+0xcec>
 29e1bbe:	xor    %eax,%eax
 29e1bc0:	test   $0x1,%edx
 29e1bc6:	jne    29e1c0c <wasm[0]::function[1015]::helper::object_read+0xcec>
 29e1bcc:	mov    0x2e0(%rsp),%r12
 29e1bd4:	mov    0x28(%r12),%r10
 29e1bd9:	mov    0x20(%r12),%rax
 29e1bde:	mov    %edx,%r11d
 29e1be1:	lea    0x4(%rax,%r11,1),%rdi
 29e1be6:	xor    %rax,%rax
 29e1be9:	cmp    %r10,%r11
 29e1bec:	cmova  %rax,%rdi
 29e1bf0:	mov    (%rdi),%r11d
 29e1bf3:	mov    0x190(%rsp),%rcx
 29e1bfb:	mov    0x28(%rcx),%rax
 29e1bff:	cmp    0x138(%rax),%r11d
 29e1c06:	sete   %al
 29e1c09:	movzbl %al,%eax
 29e1c0c:	test   %eax,%eax
 29e1c0e:	jne    29e1db6 <wasm[0]::function[1015]::helper::object_read+0xe96>
 29e1c14:	xor    %r9d,%r9d
 29e1c17:	test   %edx,%edx
 29e1c19:	je     29e1c6c <wasm[0]::function[1015]::helper::object_read+0xd4c>
 29e1c1f:	xor    %r9d,%r9d
 29e1c22:	test   $0x1,%edx
 29e1c28:	jne    29e1c6c <wasm[0]::function[1015]::helper::object_read+0xd4c>
 29e1c2e:	mov    0x2e0(%rsp),%r12
 29e1c36:	mov    0x28(%r12),%rax
 29e1c3b:	mov    0x20(%r12),%rcx
 29e1c40:	mov    %edx,%esi
 29e1c42:	lea    0x4(%rcx,%rsi,1),%rcx
 29e1c47:	xor    %rdi,%rdi
 29e1c4a:	cmp    %rax,%rsi
 29e1c4d:	cmova  %rdi,%rcx
 29e1c51:	mov    (%rcx),%eax
 29e1c53:	mov    0x190(%rsp),%rcx
 29e1c5b:	mov    0x28(%rcx),%rcx
 29e1c5f:	cmp    0x1d4(%rcx),%eax
 29e1c65:	sete   %al
 29e1c68:	movzbl %al,%r9d
 29e1c6c:	xor    %esi,%esi
 29e1c6e:	test   %r9d,%r9d
 29e1c71:	je     29e1e17 <wasm[0]::function[1015]::helper::object_read+0xef7>
 29e1c77:	xor    %eax,%eax
 29e1c79:	test   %edx,%edx
 29e1c7b:	je     29e1ccc <wasm[0]::function[1015]::helper::object_read+0xdac>
 29e1c81:	xor    %eax,%eax
 29e1c83:	test   $0x1,%edx
 29e1c89:	jne    29e1ccc <wasm[0]::function[1015]::helper::object_read+0xdac>
 29e1c8f:	mov    0x2e0(%rsp),%r12
 29e1c97:	mov    0x28(%r12),%rax
 29e1c9c:	mov    0x20(%r12),%rcx
 29e1ca1:	mov    %edx,%esi
 29e1ca3:	lea    0x4(%rcx,%rsi,1),%rcx
 29e1ca8:	xor    %rdi,%rdi
 29e1cab:	cmp    %rax,%rsi
 29e1cae:	cmova  %rdi,%rcx
 29e1cb2:	mov    (%rcx),%eax
 29e1cb4:	mov    0x190(%rsp),%rcx
 29e1cbc:	mov    0x28(%rcx),%rcx
 29e1cc0:	cmp    0x1d4(%rcx),%eax
 29e1cc6:	sete   %al
 29e1cc9:	movzbl %al,%eax
 29e1ccc:	test   %eax,%eax
 29e1cce:	je     29fbb85 <wasm[0]::function[1015]::helper::object_read+0x1ac65>
 29e1cd4:	test   %edx,%edx
 29e1cd6:	je     29fbb87 <wasm[0]::function[1015]::helper::object_read+0x1ac67>
 29e1cdc:	test   %edx,%edx
 29e1cde:	je     29fbb89 <wasm[0]::function[1015]::helper::object_read+0x1ac69>
 29e1ce4:	mov    0x2e0(%rsp),%r12
 29e1cec:	mov    0x28(%r12),%rax
 29e1cf1:	mov    0x20(%r12),%rcx
 29e1cf6:	mov    %edx,%edi
 29e1cf8:	lea    (%rcx,%rdi,1),%rsi
 29e1cfc:	xor    %rdx,%rdx
 29e1cff:	cmp    %rax,%rdi
 29e1d02:	cmova  %rdx,%rsi
 29e1d06:	mov    0x10(%rsi),%esi
 29e1d09:	mov    %esi,0x78(%rsp)
 29e1d0d:	test   %esi,%esi
 29e1d0f:	je     29fbb8b <wasm[0]::function[1015]::helper::object_read+0x1ac6b>
 29e1d15:	test   %esi,%esi
 29e1d17:	je     29fbb8d <wasm[0]::function[1015]::helper::object_read+0x1ac6d>
 29e1d1d:	mov    %esi,%esi
 29e1d1f:	add    %rsi,%rcx
 29e1d22:	cmp    %rax,%rsi
 29e1d25:	cmova  %rdx,%rcx
 29e1d29:	mov    0x14(%rcx),%ecx
 29e1d2c:	test   %ecx,%ecx
 29e1d2e:	je     29fbb8f <wasm[0]::function[1015]::helper::object_read+0x1ac6f>
 29e1d34:	xor    %eax,%eax
 29e1d36:	test   $0x1,%ecx
 29e1d3c:	jne    29e1d96 <wasm[0]::function[1015]::helper::object_read+0xe76>
 29e1d42:	mov    0x2e0(%rsp),%r12
 29e1d4a:	mov    0x28(%r12),%rax
 29e1d4f:	mov    0x20(%r12),%rsi
 29e1d54:	mov    %ecx,%edx
 29e1d56:	lea    0x4(%rsi,%rdx,1),%rcx
 29e1d5b:	xor    %rsi,%rsi
 29e1d5e:	cmp    %rax,%rdx
 29e1d61:	cmova  %rsi,%rcx
 29e1d65:	mov    (%rcx),%esi
 29e1d67:	mov    0x190(%rsp),%rcx
 29e1d6f:	mov    0x28(%rcx),%rax
 29e1d73:	mov    0x158(%rax),%edx
 29e1d79:	cmp    %edx,%esi
 29e1d7b:	sete   %al
 29e1d7e:	movzbl %al,%eax
 29e1d81:	cmp    %edx,%esi
 29e1d83:	je     29e1d96 <wasm[0]::function[1015]::helper::object_read+0xe76>
 29e1d89:	mov    0x190(%rsp),%rdi
 29e1d91:	call   3018e75 <wasmtime_builtin_is_subtype>
 29e1d96:	mov    0x100(%rsp),%esi
 29e1d9d:	test   %eax,%eax
 29e1d9f:	je     29e1e17 <wasm[0]::function[1015]::helper::object_read+0xef7>
 29e1da5:	mov    0x78(%rsp),%esi
 29e1da9:	test   %esi,%esi
 29e1dab:	je     29fbb91 <wasm[0]::function[1015]::helper::object_read+0x1ac71>
 29e1db1:	jmp    29e1e17 <wasm[0]::function[1015]::helper::object_read+0xef7>
 29e1db6:	xor    %eax,%eax
 29e1db8:	test   %edx,%edx
 29e1dba:	je     29e1e0c <wasm[0]::function[1015]::helper::object_read+0xeec>
 29e1dc0:	xor    %eax,%eax
 29e1dc2:	test   $0x1,%edx
 29e1dc8:	jne    29e1e0c <wasm[0]::function[1015]::helper::object_read+0xeec>
 29e1dce:	mov    0x2e0(%rsp),%r12
 29e1dd6:	mov    0x28(%r12),%rax
 29e1ddb:	mov    0x20(%r12),%rsi
 29e1de0:	mov    %edx,%ecx
 29e1de2:	lea    0x4(%rsi,%rcx,1),%r10
 29e1de7:	xor    %rsi,%rsi
 29e1dea:	cmp    %rax,%rcx
 29e1ded:	cmova  %rsi,%r10
 29e1df1:	mov    (%r10),%eax
 29e1df4:	mov    0x190(%rsp),%rcx
 29e1dfc:	mov    0x28(%rcx),%rcx
 29e1e00:	cmp    0x138(%rcx),%eax
 29e1e06:	sete   %al
 29e1e09:	movzbl %al,%eax
 29e1e0c:	test   %eax,%eax
 29e1e0e:	je     29fbb93 <wasm[0]::function[1015]::helper::object_read+0x1ac73>
 29e1e14:	mov    %rdx,%rsi
 29e1e17:	mov    %esi,0x78(%rsp)
 29e1e1b:	mov    0x40(%rsp),%edx
 29e1e1f:	mov    %rdx,0x210(%rsp)
 29e1e27:	mov    0x68(%rsp),%r9d
 29e1e2c:	mov    0xd0(%rsp),%r8d
 29e1e34:	mov    0x50(%rsp),%r14d
 29e1e39:	mov    %r14,0x208(%rsp)
 29e1e41:	mov    0x70(%rsp),%r14d
 29e1e46:	mov    0x60(%rsp),%edi
 29e1e4a:	mov    0xe8(%rsp),%edx
 29e1e51:	xor    %eax,%eax
 29e1e53:	test   %esi,%esi
 29e1e55:	jne    29e1e78 <wasm[0]::function[1015]::helper::object_read+0xf58>
 29e1e5b:	mov    0x210(%rsp),%rcx
 29e1e63:	mov    %rax,0x1e0(%rsp)
 29e1e6b:	mov    %rax,0x200(%rsp)
 29e1e73:	jmp    29e2bdd <wasm[0]::function[1015]::helper::object_read+0x1cbd>
 29e1e78:	test   %esi,%esi
 29e1e7a:	je     29fbb95 <wasm[0]::function[1015]::helper::object_read+0x1ac75>
 29e1e80:	test   %esi,%esi
 29e1e82:	je     29fbb97 <wasm[0]::function[1015]::helper::object_read+0x1ac77>
 29e1e88:	mov    0x2e0(%rsp),%r12
 29e1e90:	mov    0x28(%r12),%rax
 29e1e95:	mov    0x20(%r12),%rcx
 29e1e9a:	mov    %esi,%edx
 29e1e9c:	add    %rdx,%rcx
 29e1e9f:	xor    %rsi,%rsi
 29e1ea2:	cmp    %rax,%rdx
 29e1ea5:	cmova  %rsi,%rcx
 29e1ea9:	mov    0x14(%rcx),%eax
 29e1eac:	mov    %eax,0x100(%rsp)
 29e1eb3:	test   %eax,%eax
 29e1eb5:	je     29fbb99 <wasm[0]::function[1015]::helper::object_read+0x1ac79>
 29e1ebb:	mov    0x100(%rsp),%ecx
 29e1ec2:	xor    %eax,%eax
 29e1ec4:	test   $0x1,%ecx
 29e1eca:	jne    29e1f24 <wasm[0]::function[1015]::helper::object_read+0x1004>
 29e1ed0:	mov    0x2e0(%rsp),%r12
 29e1ed8:	mov    0x28(%r12),%rax
 29e1edd:	mov    0x20(%r12),%rsi
 29e1ee2:	mov    %ecx,%edx
 29e1ee4:	lea    0x4(%rsi,%rdx,1),%rcx
 29e1ee9:	xor    %rsi,%rsi
 29e1eec:	cmp    %rax,%rdx
 29e1eef:	cmova  %rsi,%rcx
 29e1ef3:	mov    (%rcx),%esi
 29e1ef5:	mov    0x190(%rsp),%rcx
 29e1efd:	mov    0x28(%rcx),%rax
 29e1f01:	mov    0x158(%rax),%edx
 29e1f07:	cmp    %edx,%esi
 29e1f09:	sete   %al
 29e1f0c:	movzbl %al,%eax
 29e1f0f:	cmp    %edx,%esi
 29e1f11:	je     29e1f24 <wasm[0]::function[1015]::helper::object_read+0x1004>
 29e1f17:	mov    0x190(%rsp),%rdi
 29e1f1f:	call   3018e75 <wasmtime_builtin_is_subtype>
 29e1f24:	test   %eax,%eax
 29e1f26:	jne    29e21bb <wasm[0]::function[1015]::helper::object_read+0x129b>
 29e1f2c:	mov    0x78(%rsp),%edx
 29e1f30:	xor    %ebx,%ebx
 29e1f32:	test   %edx,%edx
 29e1f34:	je     29fbb9b <wasm[0]::function[1015]::helper::object_read+0x1ac7b>
 29e1f3a:	mov    0x68(%rsp),%r9d
 29e1f3f:	mov    0x1b8(%rsp),%rcx
 29e1f47:	mov    0x190(%rsp),%rsi
 29e1f4f:	mov    0x190(%rsp),%rdi
 29e1f57:	mov    0x1c0(%rsp),%r8
 29e1f5f:	call   2a58e20 <wasm[0]::function[1032]::helper::ordinary_property_find>
 29e1f64:	test   %eax,%eax
 29e1f66:	je     29e1fa0 <wasm[0]::function[1015]::helper::object_read+0x1080>
 29e1f6c:	test   %eax,%eax
 29e1f6e:	je     29fbb9d <wasm[0]::function[1015]::helper::object_read+0x1ac7d>
 29e1f74:	test   %eax,%eax
 29e1f76:	je     29fbb9f <wasm[0]::function[1015]::helper::object_read+0x1ac7f>
 29e1f7c:	mov    0x2e0(%rsp),%r12
 29e1f84:	mov    0x28(%r12),%rcx
 29e1f89:	mov    %eax,%edx
 29e1f8b:	mov    %rdx,%rax
 29e1f8e:	add    0x20(%r12),%rax
 29e1f93:	xor    %rsi,%rsi
 29e1f96:	cmp    %rcx,%rdx
 29e1f99:	cmova  %rsi,%rax
 29e1f9d:	mov    0x14(%rax),%ebx
 29e1fa0:	mov    0x140(%rsp),%edx
 29e1fa7:	xor    %eax,%eax
 29e1fa9:	test   %ebx,%ebx
 29e1fab:	je     29e214b <wasm[0]::function[1015]::helper::object_read+0x122b>
 29e1fb1:	test   %ebx,%ebx
 29e1fb3:	je     29fbba1 <wasm[0]::function[1015]::helper::object_read+0x1ac81>
 29e1fb9:	mov    0x2e0(%rsp),%r12
 29e1fc1:	mov    0x28(%r12),%rax
 29e1fc6:	mov    0x20(%r12),%rcx
 29e1fcb:	mov    %ebx,%edx
 29e1fcd:	add    %rdx,%rcx
 29e1fd0:	xor    %rsi,%rsi
 29e1fd3:	cmp    %rax,%rdx
 29e1fd6:	cmova  %rsi,%rcx
 29e1fda:	mov    0x10(%rcx),%esi
 29e1fdd:	mov    0x140(%rsp),%edx
 29e1fe4:	xor    %eax,%eax
 29e1fe6:	test   $0x1,%esi
 29e1fec:	jne    29e214b <wasm[0]::function[1015]::helper::object_read+0x122b>
 29e1ff2:	mov    0x14(%rcx),%edx
 29e1ff5:	test   %edx,%edx
 29e1ff7:	je     29fbba3 <wasm[0]::function[1015]::helper::object_read+0x1ac83>
 29e1ffd:	xor    %eax,%eax
 29e1fff:	test   $0x1,%edx
 29e2005:	jne    29e204d <wasm[0]::function[1015]::helper::object_read+0x112d>
 29e200b:	mov    0x2e0(%rsp),%r12
 29e2013:	mov    0x28(%r12),%rdi
 29e2018:	mov    0x20(%r12),%r9
 29e201d:	mov    %edx,%r8d
 29e2020:	lea    0x4(%r9,%r8,1),%rsi
 29e2025:	xor    %r9,%r9
 29e2028:	cmp    %rdi,%r8
 29e202b:	cmova  %r9,%rsi
 29e202f:	mov    (%rsi),%r8d
 29e2032:	mov    0x190(%rsp),%rcx
 29e203a:	mov    0x28(%rcx),%r9
 29e203e:	cmp    0x120(%r9),%r8d
 29e2045:	sete   %r9b
 29e2049:	movzbl %r9b,%eax
 29e204d:	test   %eax,%eax
 29e204f:	jne    29e20b4 <wasm[0]::function[1015]::helper::object_read+0x1194>
 29e2055:	mov    0x190(%rsp),%rsi
 29e205d:	mov    0x190(%rsp),%rdi
 29e2065:	call   2a01ba0 <wasm[0]::function[1024]::helper::property_value_resolve>
 29e206a:	test   %eax,%eax
 29e206c:	je     29fbba5 <wasm[0]::function[1015]::helper::object_read+0x1ac85>
 29e2072:	test   %eax,%eax
 29e2074:	je     29fbba7 <wasm[0]::function[1015]::helper::object_read+0x1ac87>
 29e207a:	mov    0x2e0(%rsp),%r12
 29e2082:	mov    0x28(%r12),%rcx
 29e2087:	mov    0x20(%r12),%rsi
 29e208c:	mov    %eax,%edx
 29e208e:	lea    (%rsi,%rdx,1),%rax
 29e2092:	xor    %rsi,%rsi
 29e2095:	cmp    %rcx,%rdx
 29e2098:	cmova  %rsi,%rax
 29e209c:	mov    0x18(%rax),%r13d
 29e20a0:	mov    %r13,0x1d0(%rsp)
 29e20a8:	mov    0x10(%rax),%r13
 29e20ac:	mov    0x1c(%rax),%edx
 29e20af:	jmp    29e2143 <wasm[0]::function[1015]::helper::object_read+0x1223>
 29e20b4:	xor    %eax,%eax
 29e20b6:	test   $0x1,%edx
 29e20bc:	jne    29e20ff <wasm[0]::function[1015]::helper::object_read+0x11df>
 29e20c2:	mov    0x2e0(%rsp),%r12
 29e20ca:	mov    0x28(%r12),%rax
 29e20cf:	mov    0x20(%r12),%rcx
 29e20d4:	mov    %edx,%esi
 29e20d6:	lea    0x4(%rcx,%rsi,1),%rcx
 29e20db:	xor    %rdi,%rdi
 29e20de:	cmp    %rax,%rsi
 29e20e1:	cmova  %rdi,%rcx
 29e20e5:	mov    (%rcx),%eax
 29e20e7:	mov    0x190(%rsp),%rcx
 29e20ef:	mov    0x28(%rcx),%rcx
 29e20f3:	cmp    0x120(%rcx),%eax
 29e20f9:	sete   %al
 29e20fc:	movzbl %al,%eax
 29e20ff:	test   %eax,%eax
 29e2101:	je     29fbba9 <wasm[0]::function[1015]::helper::object_read+0x1ac89>
 29e2107:	test   %edx,%edx
 29e2109:	je     29fbbab <wasm[0]::function[1015]::helper::object_read+0x1ac8b>
 29e210f:	mov    0x2e0(%rsp),%r12
 29e2117:	mov    0x28(%r12),%rcx
 29e211c:	mov    0x20(%r12),%rax
 29e2121:	mov    %edx,%edx
 29e2123:	add    %rdx,%rax
 29e2126:	xor    %rsi,%rsi
 29e2129:	cmp    %rcx,%rdx
 29e212c:	cmova  %rsi,%rax
 29e2130:	mov    0x18(%rax),%r13d
 29e2134:	mov    %r13,0x1d0(%rsp)
 29e213c:	mov    0x10(%rax),%r13
 29e2140:	mov    0x1c(%rax),%edx
 29e2143:	mov    0x278(%rsp),%rax
 29e214b:	mov    0x40(%rsp),%ecx
 29e214f:	mov    %rcx,0x210(%rsp)
 29e2157:	mov    0x68(%rsp),%r9d
 29e215c:	mov    0xd0(%rsp),%r8d
 29e2164:	mov    0x50(%rsp),%r14d
 29e2169:	mov    %r14,0x208(%rsp)
 29e2171:	mov    0x70(%rsp),%r14d
 29e2176:	mov    0x60(%rsp),%edi
 29e217a:	mov    0xe8(%rsp),%ecx
 29e2181:	mov    %rcx,0x1a0(%rsp)
 29e2189:	mov    %rcx,%rsi
 29e218c:	mov    %rcx,0x1e0(%rsp)
 29e2194:	xor    %esi,%esi
 29e2196:	mov    %rsi,0x1e0(%rsp)
 29e219e:	mov    0x1d0(%rsp),%r15
 29e21a6:	mov    0x1e0(%rsp),%rcx
 29e21ae:	mov    %rcx,0x200(%rsp)
 29e21b6:	jmp    29e2b86 <wasm[0]::function[1015]::helper::object_read+0x1c66>
 29e21bb:	mov    0x100(%rsp),%eax
 29e21c2:	test   %eax,%eax
 29e21c4:	je     29fbbad <wasm[0]::function[1015]::helper::object_read+0x1ac8d>
 29e21ca:	mov    0x100(%rsp),%ecx
 29e21d1:	xor    %eax,%eax
 29e21d3:	test   $0x1,%ecx
 29e21d9:	jne    29e2233 <wasm[0]::function[1015]::helper::object_read+0x1313>
 29e21df:	mov    0x2e0(%rsp),%r12
 29e21e7:	mov    0x28(%r12),%rax
 29e21ec:	mov    0x20(%r12),%rsi
 29e21f1:	mov    %ecx,%edx
 29e21f3:	lea    0x4(%rsi,%rdx,1),%rcx
 29e21f8:	xor    %rsi,%rsi
 29e21fb:	cmp    %rax,%rdx
 29e21fe:	cmova  %rsi,%rcx
 29e2202:	mov    (%rcx),%esi
 29e2204:	mov    0x190(%rsp),%rcx
 29e220c:	mov    0x28(%rcx),%rax
 29e2210:	mov    0x158(%rax),%edx
 29e2216:	cmp    %edx,%esi
 29e2218:	sete   %al
 29e221b:	movzbl %al,%eax
 29e221e:	cmp    %edx,%esi
 29e2220:	je     29e2233 <wasm[0]::function[1015]::helper::object_read+0x1313>
 29e2226:	mov    0x190(%rsp),%rdi
 29e222e:	call   3018e75 <wasmtime_builtin_is_subtype>
 29e2233:	test   %eax,%eax
 29e2235:	je     29fbbaf <wasm[0]::function[1015]::helper::object_read+0x1ac8f>
 29e223b:	mov    0x100(%rsp),%r11d
 29e2243:	mov    0x140(%rsp),%edx
 29e224a:	mov    0x40(%rsp),%eax
 29e224e:	mov    %rax,0x210(%rsp)
 29e2256:	mov    0x68(%rsp),%r9d
 29e225b:	mov    0xd0(%rsp),%r8d
 29e2263:	mov    0x50(%rsp),%r14d
 29e2268:	mov    %r14,0x208(%rsp)
 29e2270:	mov    0x70(%rsp),%r14d
 29e2275:	mov    0x60(%rsp),%edi
 29e2279:	mov    0xe8(%rsp),%eax
 29e2280:	mov    %rax,0x1a0(%rsp)
 29e2288:	xor    %eax,%eax
 29e228a:	mov    0x1b8(%rsp),%rcx
 29e2292:	mov    %rax,0x1d8(%rsp)
 29e229a:	cmp    $0x4,%ecx
 29e229d:	je     29e22c8 <wasm[0]::function[1015]::helper::object_read+0x13a8>
 29e22a3:	mov    0x1d8(%rsp),%rax
 29e22ab:	mov    0x1d8(%rsp),%rcx
 29e22b3:	mov    %rcx,0x1e0(%rsp)
 29e22bb:	mov    %rcx,0x200(%rsp)
 29e22c3:	jmp    29e2704 <wasm[0]::function[1015]::helper::object_read+0x17e4>
 29e22c8:	mov    %rcx,%rax
 29e22cb:	mov    %rcx,0x240(%rsp)
 29e22d3:	xor    %eax,%ecx
 29e22d5:	mov    %rcx,0x240(%rsp)
 29e22dd:	test   %r11d,%r11d
 29e22e0:	je     29fbbb1 <wasm[0]::function[1015]::helper::object_read+0x1ac91>
 29e22e6:	test   %r11d,%r11d
 29e22e9:	je     29fbbb3 <wasm[0]::function[1015]::helper::object_read+0x1ac93>
 29e22ef:	mov    0x2e0(%rsp),%r12
 29e22f7:	mov    0x28(%r12),%rax
 29e22fc:	mov    0x20(%r12),%rbx
 29e2301:	mov    %r11d,%r15d
 29e2304:	lea    (%rbx,%r15,1),%rsi
 29e2308:	xor    %r12,%r12
 29e230b:	cmp    %rax,%r15
 29e230e:	cmova  %r12,%rsi
 29e2312:	mov    0x10(%rsi),%esi
 29e2315:	test   %esi,%esi
 29e2317:	je     29fbbb5 <wasm[0]::function[1015]::helper::object_read+0x1ac95>
 29e231d:	test   %esi,%esi
 29e231f:	je     29fbbb7 <wasm[0]::function[1015]::helper::object_read+0x1ac97>
 29e2325:	mov    %esi,%r15d
 29e2328:	lea    (%rbx,%r15,1),%rsi
 29e232c:	cmp    %rax,%r15
 29e232f:	cmova  %r12,%rsi
 29e2333:	mov    0x10(%rsi),%esi
 29e2336:	test   %esi,%esi
 29e2338:	je     29fbbb9 <wasm[0]::function[1015]::helper::object_read+0x1ac99>
 29e233e:	test   %esi,%esi
 29e2340:	je     29fbbbb <wasm[0]::function[1015]::helper::object_read+0x1ac9b>
 29e2346:	mov    %esi,%r15d
 29e2349:	lea    0x10(%rbx,%r15,1),%rbx
 29e234e:	cmp    %rax,%r15
 29e2351:	cmova  %r12,%rbx
 29e2355:	mov    (%rbx),%ebx
 29e2357:	mov    0x190(%rsp),%rcx
 29e235f:	mov    0x28(%rcx),%r10
 29e2363:	mov    0x234(%r10),%r15d
 29e236a:	mov    0x240(%rsp),%rax
 29e2372:	mov    %rax,0x1d8(%rsp)
 29e237a:	mov    %rax,0x1e0(%rsp)
 29e2382:	mov    %rax,0x200(%rsp)
 29e238a:	mov    %esi,0xb8(%rsp)
 29e2391:	mov    %r9d,0x80(%rsp)
 29e2399:	mov    %r11d,0x48(%rsp)
 29e239e:	mov    %edx,0xa8(%rsp)
 29e23a5:	mov    0x210(%rsp),%rdx
 29e23ad:	mov    %edx,0xa0(%rsp)
 29e23b4:	mov    %r8d,0x78(%rsp)
 29e23b9:	mov    0x208(%rsp),%rax
 29e23c1:	mov    %eax,0xe8(%rsp)
 29e23c8:	mov    %r14d,0xd0(%rsp)
 29e23d0:	mov    %edi,0x140(%rsp)
 29e23d7:	mov    0x1a0(%rsp),%r8
 29e23df:	mov    %r8d,0x100(%rsp)
 29e23e7:	mov    0x2e8(%rsp),%rax
 29e23ef:	mov    (%rax),%rcx
 29e23f2:	mov    0x228(%rsp),%rax
 29e23fa:	cmp    %rax,%rcx
 29e23fd:	jae    29fa4e5 <wasm[0]::function[1015]::helper::object_read+0x195c5>
 29e2403:	mov    0x48(%rsp),%r11d
 29e2408:	mov    0xa8(%rsp),%edx
 29e240f:	mov    0xa0(%rsp),%eax
 29e2416:	mov    %rax,0x210(%rsp)
 29e241e:	mov    0x80(%rsp),%r9d
 29e2426:	mov    0x78(%rsp),%r8d
 29e242b:	mov    0xe8(%rsp),%r14d
 29e2433:	mov    %r14,0x208(%rsp)
 29e243b:	mov    0xd0(%rsp),%r14d
 29e2443:	mov    0x140(%rsp),%edi
 29e244a:	mov    0x100(%rsp),%r10d
 29e2452:	mov    0x240(%rsp),%rcx
 29e245a:	mov    %r10,0x1a0(%rsp)
 29e2462:	cmp    %ebx,%ecx
 29e2464:	jb     29e2477 <wasm[0]::function[1015]::helper::object_read+0x1557>
 29e246a:	mov    0x1d8(%rsp),%rax
 29e2472:	jmp    29e2704 <wasm[0]::function[1015]::helper::object_read+0x17e4>
 29e2477:	mov    0xb8(%rsp),%r11d
 29e247f:	test   %r11d,%r11d
 29e2482:	je     29fbbbd <wasm[0]::function[1015]::helper::object_read+0x1ac9d>
 29e2488:	test   %r11d,%r11d
 29e248b:	je     29fbbbf <wasm[0]::function[1015]::helper::object_read+0x1ac9f>
 29e2491:	mov    0x2e0(%rsp),%r12
 29e2499:	mov    0x28(%r12),%rax
 29e249e:	mov    0x20(%r12),%rcx
 29e24a3:	mov    %r11d,%edi
 29e24a6:	lea    0x10(%rcx,%rdi,1),%rsi
 29e24ab:	xor    %rdx,%rdx
 29e24ae:	cmp    %rax,%rdi
 29e24b1:	cmova  %rdx,%rsi
 29e24b5:	mov    (%rsi),%esi
 29e24b7:	mov    0x240(%rsp),%rdi
 29e24bf:	cmp    %esi,%edi
 29e24c1:	jae    29fbbc1 <wasm[0]::function[1015]::helper::object_read+0x1aca1>
 29e24c7:	mov    %esi,%edi
 29e24c9:	shl    $0x2,%rdi
 29e24cd:	shr    $0x20,%rdi
 29e24d1:	test   %rdi,%rdi
 29e24d4:	jne    29fbbc3 <wasm[0]::function[1015]::helper::object_read+0x1aca3>
 29e24da:	shl    $0x2,%esi
 29e24dd:	add    $0x14,%esi
 29e24e0:	jb     29fbbc5 <wasm[0]::function[1015]::helper::object_read+0x1aca5>
 29e24e6:	add    %esi,%r11d
 29e24e9:	jb     29fbbc7 <wasm[0]::function[1015]::helper::object_read+0x1aca7>
 29e24ef:	mov    %r11d,%edi
 29e24f2:	add    %rdi,%rcx
 29e24f5:	cmp    %rax,%rdi
 29e24f8:	cmova  %rdx,%rcx
 29e24fc:	mov    0x240(%rsp),%rax
 29e2504:	shl    $0x2,%eax
 29e2507:	add    $0x14,%eax
 29e250d:	sub    %eax,%esi
 29e250f:	sub    %rsi,%rcx
 29e2512:	mov    (%rcx),%edx
 29e2514:	test   %edx,%edx
 29e2516:	je     29fbbc9 <wasm[0]::function[1015]::helper::object_read+0x1aca9>
 29e251c:	mov    0x1b8(%rsp),%rcx
 29e2524:	cmp    $0x4,%ecx
 29e2527:	je     29e2591 <wasm[0]::function[1015]::helper::object_read+0x1671>
 29e252d:	mov    0xb8(%rsp),%esi
 29e2534:	mov    0x80(%rsp),%r9d
 29e253c:	mov    0x48(%rsp),%r11d
 29e2541:	mov    0xa8(%rsp),%edx
 29e2548:	mov    0xa0(%rsp),%eax
 29e254f:	mov    %rax,0x210(%rsp)
 29e2557:	mov    0x78(%rsp),%r8d
 29e255c:	mov    0xe8(%rsp),%r14d
 29e2564:	mov    %r14,0x208(%rsp)
 29e256c:	mov    0xd0(%rsp),%r14d
 29e2574:	mov    0x140(%rsp),%edi
 29e257b:	mov    0x100(%rsp),%eax
 29e2582:	mov    %rax,0x1a0(%rsp)
 29e258a:	xor    %eax,%eax
 29e258c:	jmp    29e26d9 <wasm[0]::function[1015]::helper::object_read+0x17b9>
 29e2591:	mov    0x80(%rsp),%eax
 29e2598:	cmp    %eax,%edx
 29e259a:	je     29e2673 <wasm[0]::function[1015]::helper::object_read+0x1753>
 29e25a0:	xor    %ecx,%ecx
 29e25a2:	test   %edx,%edx
 29e25a4:	je     29e25e6 <wasm[0]::function[1015]::helper::object_read+0x16c6>
 29e25aa:	xor    %ecx,%ecx
 29e25ac:	test   $0x1,%edx
 29e25b2:	jne    29e25e6 <wasm[0]::function[1015]::helper::object_read+0x16c6>
 29e25b8:	mov    0x2e0(%rsp),%r12
 29e25c0:	mov    0x28(%r12),%rcx
 29e25c5:	mov    0x20(%r12),%rsi
 29e25ca:	mov    %edx,%edi
 29e25cc:	lea    0x4(%rsi,%rdi,1),%rsi
 29e25d1:	xor    %r8,%r8
 29e25d4:	cmp    %rcx,%rdi
 29e25d7:	cmova  %r8,%rsi
 29e25db:	mov    (%rsi),%ecx
 29e25dd:	cmp    %r15d,%ecx
 29e25e0:	sete   %cl
 29e25e3:	movzbl %cl,%ecx
 29e25e6:	test   %ecx,%ecx
 29e25e8:	je     29fbbcb <wasm[0]::function[1015]::helper::object_read+0x1acab>
 29e25ee:	xor    %r9d,%r9d
 29e25f1:	test   %eax,%eax
 29e25f3:	je     29e263e <wasm[0]::function[1015]::helper::object_read+0x171e>
 29e25f9:	mov    0x80(%rsp),%eax
 29e2600:	xor    %r9d,%r9d
 29e2603:	test   $0x1,%eax
 29e2608:	jne    29e263e <wasm[0]::function[1015]::helper::object_read+0x171e>
 29e260e:	mov    0x2e0(%rsp),%r12
 29e2616:	mov    0x28(%r12),%rcx
 29e261b:	mov    0x20(%r12),%rdi
 29e2620:	mov    %eax,%esi
 29e2622:	lea    0x4(%rdi,%rsi,1),%rax
 29e2627:	xor    %rdi,%rdi
 29e262a:	cmp    %rcx,%rsi
 29e262d:	cmova  %rdi,%rax
 29e2631:	mov    (%rax),%ecx
 29e2633:	cmp    %r15d,%ecx
 29e2636:	sete   %sil
 29e263a:	movzbl %sil,%r9d
 29e263e:	test   %r9d,%r9d
 29e2641:	je     29fbbcd <wasm[0]::function[1015]::helper::object_read+0x1acad>
 29e2647:	mov    0x80(%rsp),%ecx
 29e264e:	xor    %r8d,%r8d
 29e2651:	test   %ecx,%ecx
 29e2653:	je     29fbbcf <wasm[0]::function[1015]::helper::object_read+0x1acaf>
 29e2659:	mov    0x190(%rsp),%rsi
 29e2661:	mov    0x190(%rsp),%rdi
 29e2669:	call   2ae54e0 <wasm[0]::function[1057]::helper::string_equality>
 29e266e:	jmp    29e267b <wasm[0]::function[1015]::helper::object_read+0x175b>
 29e2673:	mov    0x278(%rsp),%rax
 29e267b:	mov    0xb8(%rsp),%esi
 29e2682:	mov    0x80(%rsp),%r9d
 29e268a:	mov    0x48(%rsp),%r11d
 29e268f:	mov    0xa8(%rsp),%edx
 29e2696:	mov    0xa0(%rsp),%ecx
 29e269d:	mov    %rcx,0x210(%rsp)
 29e26a5:	mov    0x78(%rsp),%r8d
 29e26aa:	mov    0xe8(%rsp),%r14d
 29e26b2:	mov    %r14,0x208(%rsp)
 29e26ba:	mov    0xd0(%rsp),%r14d
 29e26c2:	mov    0x140(%rsp),%edi
 29e26c9:	mov    0x100(%rsp),%r10d
 29e26d1:	mov    %r10,0x1a0(%rsp)
 29e26d9:	test   %eax,%eax
 29e26db:	jne    29e2704 <wasm[0]::function[1015]::helper::object_read+0x17e4>
 29e26e1:	mov    0x240(%rsp),%rcx
 29e26e9:	add    $0x1,%ecx
 29e26ef:	mov    %rcx,0x240(%rsp)
 29e26f7:	mov    %rax,0x1d8(%rsp)
 29e26ff:	jmp    29e238a <wasm[0]::function[1015]::helper::object_read+0x146a>
 29e2704:	test   %eax,%eax
 29e2706:	jne    29e2719 <wasm[0]::function[1015]::helper::object_read+0x17f9>
 29e270c:	mov    0x1d0(%rsp),%r15
 29e2714:	jmp    29e2b86 <wasm[0]::function[1015]::helper::object_read+0x1c66>
 29e2719:	test   %r11d,%r11d
 29e271c:	je     29fbbd1 <wasm[0]::function[1015]::helper::object_read+0x1acb1>
 29e2722:	xor    %edx,%edx
 29e2724:	test   $0x1,%r11d
 29e272b:	jne    29e276f <wasm[0]::function[1015]::helper::object_read+0x184f>
 29e2731:	mov    0x2e0(%rsp),%r12
 29e2739:	mov    0x28(%r12),%rdx
 29e273e:	mov    0x20(%r12),%rsi
 29e2743:	mov    %r11d,%ebx
 29e2746:	lea    0x4(%rsi,%rbx,1),%rsi
 29e274b:	xor    %r12,%r12
 29e274e:	cmp    %rdx,%rbx
 29e2751:	cmova  %r12,%rsi
 29e2755:	mov    (%rsi),%edx
 29e2757:	mov    0x190(%rsp),%rcx
 29e275f:	mov    0x28(%rcx),%rcx
 29e2763:	cmp    0x160(%rcx),%edx
 29e2769:	sete   %cl
 29e276c:	movzbl %cl,%edx
 29e276f:	test   %edx,%edx
 29e2771:	jne    29e29de <wasm[0]::function[1015]::helper::object_read+0x1abe>
 29e2777:	xor    %edx,%edx
 29e2779:	test   $0x1,%r11d
 29e2780:	jne    29e27c4 <wasm[0]::function[1015]::helper::object_read+0x18a4>
 29e2786:	mov    0x2e0(%rsp),%r12
 29e278e:	mov    0x28(%r12),%rdx
 29e2793:	mov    0x20(%r12),%rsi
 29e2798:	mov    %r11d,%ebx
 29e279b:	lea    0x4(%rsi,%rbx,1),%rsi
 29e27a0:	xor    %r12,%r12
 29e27a3:	cmp    %rdx,%rbx
 29e27a6:	cmova  %r12,%rsi
 29e27aa:	mov    (%rsi),%edx
 29e27ac:	mov    0x190(%rsp),%rcx
 29e27b4:	mov    0x28(%rcx),%rcx
 29e27b8:	cmp    0x15c(%rcx),%edx
 29e27be:	sete   %cl
 29e27c1:	movzbl %cl,%edx
 29e27c4:	test   %edx,%edx
 29e27c6:	je     29fbbd3 <wasm[0]::function[1015]::helper::object_read+0x1acb3>
 29e27cc:	test   %r11d,%r11d
 29e27cf:	je     29fbbd5 <wasm[0]::function[1015]::helper::object_read+0x1acb5>
 29e27d5:	mov    0x2e0(%rsp),%r12
 29e27dd:	mov    0x28(%r12),%rbx
 29e27e2:	mov    0x20(%r12),%r12
 29e27e7:	mov    %r11d,%edx
 29e27ea:	lea    (%r12,%rdx,1),%rsi
 29e27ee:	xor    %r13,%r13
 29e27f1:	cmp    %rbx,%rdx
 29e27f4:	cmova  %r13,%rsi
 29e27f8:	mov    0x14(%rsi),%r11d
 29e27fc:	mov    0x18(%rsi),%edx
 29e27ff:	mov    0x1c(%rsi),%esi
 29e2802:	test   %r11d,%r11d
 29e2805:	je     29fbbd7 <wasm[0]::function[1015]::helper::object_read+0x1acb7>
 29e280b:	test   %r11d,%r11d
 29e280e:	je     29fbbd9 <wasm[0]::function[1015]::helper::object_read+0x1acb9>
 29e2814:	mov    %r11d,%r10d
 29e2817:	lea    0x10(%r12,%r10,1),%r15
 29e281c:	cmp    %rbx,%r10
 29e281f:	cmova  %r13,%r15
 29e2823:	mov    (%r15),%r15d
 29e2826:	mov    0x240(%rsp),%rcx
 29e282e:	cmp    %r15d,%ecx
 29e2831:	jae    29fbbdb <wasm[0]::function[1015]::helper::object_read+0x1acbb>
 29e2837:	mov    %r15d,%r10d
 29e283a:	shr    $0x20,%r10
 29e283e:	test   %r10,%r10
 29e2841:	jne    29fbbdd <wasm[0]::function[1015]::helper::object_read+0x1acbd>
 29e2847:	add    $0x14,%r15d
 29e284b:	jb     29fbbdf <wasm[0]::function[1015]::helper::object_read+0x1acbf>
 29e2851:	add    %r15d,%r11d
 29e2854:	jb     29fbbe1 <wasm[0]::function[1015]::helper::object_read+0x1acc1>
 29e285a:	mov    %r11d,%r10d
 29e285d:	lea    (%r12,%r10,1),%r11
 29e2861:	cmp    %rbx,%r10
 29e2864:	cmova  %r13,%r11
 29e2868:	lea    0x14(%rcx),%r10d
 29e286c:	sub    %r10d,%r15d
 29e286f:	sub    %r15,%r11
 29e2872:	movzbq (%r11),%r10
 29e2876:	mov    %r10,0x248(%rsp)
 29e287e:	test   %edx,%edx
 29e2880:	je     29e291e <wasm[0]::function[1015]::helper::object_read+0x19fe>
 29e2886:	test   %edx,%edx
 29e2888:	je     29fbbe3 <wasm[0]::function[1015]::helper::object_read+0x1acc3>
 29e288e:	test   %edx,%edx
 29e2890:	je     29fbbe5 <wasm[0]::function[1015]::helper::object_read+0x1acc5>
 29e2896:	mov    0x2e0(%rsp),%r12
 29e289e:	mov    0x28(%r12),%rbx
 29e28a3:	mov    0x20(%r12),%r12
 29e28a8:	mov    %edx,%r11d
 29e28ab:	lea    0x10(%r12,%r11,1),%r15
 29e28b0:	xor    %r13,%r13
 29e28b3:	cmp    %rbx,%r11
 29e28b6:	cmova  %r13,%r15
 29e28ba:	mov    (%r15),%r15d
 29e28bd:	mov    0x240(%rsp),%rcx
 29e28c5:	cmp    %r15d,%ecx
 29e28c8:	jae    29fbbe7 <wasm[0]::function[1015]::helper::object_read+0x1acc7>
 29e28ce:	mov    %r15d,%r11d
 29e28d1:	shl    $0x3,%r11
 29e28d5:	shr    $0x20,%r11
 29e28d9:	test   %r11,%r11
 29e28dc:	jne    29fbbe9 <wasm[0]::function[1015]::helper::object_read+0x1acc9>
 29e28e2:	shl    $0x3,%r15d
 29e28e6:	add    $0x18,%r15d
 29e28ea:	jb     29fbbeb <wasm[0]::function[1015]::helper::object_read+0x1accb>
 29e28f0:	add    %r15d,%edx
 29e28f3:	jb     29fbbed <wasm[0]::function[1015]::helper::object_read+0x1accd>
 29e28f9:	mov    %edx,%r10d
 29e28fc:	lea    (%r12,%r10,1),%rdx
 29e2900:	cmp    %rbx,%r10
 29e2903:	cmova  %r13,%rdx
 29e2907:	mov    %rcx,%r10
 29e290a:	shl    $0x3,%r10d
 29e290e:	add    $0x18,%r10d
 29e2915:	sub    %r10d,%r15d
 29e2918:	sub    %r15,%rdx
 29e291b:	mov    (%rdx),%r13
 29e291e:	xor    %edx,%edx
 29e2920:	test   %esi,%esi
 29e2922:	jne    29e2935 <wasm[0]::function[1015]::helper::object_read+0x1a15>
 29e2928:	mov    0x248(%rsp),%r10
 29e2930:	jmp    29e29d5 <wasm[0]::function[1015]::helper::object_read+0x1ab5>
 29e2935:	test   %esi,%esi
 29e2937:	je     29fbbef <wasm[0]::function[1015]::helper::object_read+0x1accf>
 29e293d:	test   %esi,%esi
 29e293f:	je     29fbbf1 <wasm[0]::function[1015]::helper::object_read+0x1acd1>
 29e2945:	mov    0x2e0(%rsp),%r12
 29e294d:	mov    0x28(%r12),%rdx
 29e2952:	mov    0x20(%r12),%r15
 29e2957:	mov    %esi,%r11d
 29e295a:	lea    0x10(%r15,%r11,1),%r12
 29e295f:	xor    %rbx,%rbx
 29e2962:	cmp    %rdx,%r11
 29e2965:	cmova  %rbx,%r12
 29e2969:	mov    (%r12),%r12d
 29e296d:	mov    0x240(%rsp),%rcx
 29e2975:	cmp    %r12d,%ecx
 29e2978:	jae    29fbbf3 <wasm[0]::function[1015]::helper::object_read+0x1acd3>
 29e297e:	mov    %r12d,%r11d
 29e2981:	shl    $0x2,%r11
 29e2985:	shr    $0x20,%r11
 29e2989:	test   %r11,%r11
 29e298c:	jne    29fbbf5 <wasm[0]::function[1015]::helper::object_read+0x1acd5>
 29e2992:	shl    $0x2,%r12d
 29e2996:	add    $0x14,%r12d
 29e299a:	jb     29fbbf7 <wasm[0]::function[1015]::helper::object_read+0x1acd7>
 29e29a0:	add    %r12d,%esi
 29e29a3:	jb     29fbbf9 <wasm[0]::function[1015]::helper::object_read+0x1acd9>
 29e29a9:	mov    %esi,%r10d
 29e29ac:	lea    (%r15,%r10,1),%rsi
 29e29b0:	cmp    %rdx,%r10
 29e29b3:	cmova  %rbx,%rsi
 29e29b7:	shl    $0x2,%ecx
 29e29ba:	mov    %rcx,0x240(%rsp)
 29e29c2:	lea    0x14(%rcx),%edx
 29e29c5:	sub    %edx,%r12d
 29e29c8:	sub    %r12,%rsi
 29e29cb:	mov    (%rsi),%edx
 29e29cd:	mov    0x248(%rsp),%r10
 29e29d5:	movzbl %r10b,%r15d
 29e29d9:	jmp    29e2b86 <wasm[0]::function[1015]::helper::object_read+0x1c66>
 29e29de:	xor    %edx,%edx
 29e29e0:	test   $0x1,%r11d
 29e29e7:	jne    29e2a2b <wasm[0]::function[1015]::helper::object_read+0x1b0b>
 29e29ed:	mov    0x2e0(%rsp),%r12
 29e29f5:	mov    0x28(%r12),%rdx
 29e29fa:	mov    0x20(%r12),%rsi
 29e29ff:	mov    %r11d,%ebx
 29e2a02:	lea    0x4(%rsi,%rbx,1),%rsi
 29e2a07:	xor    %r12,%r12
 29e2a0a:	cmp    %rdx,%rbx
 29e2a0d:	cmova  %r12,%rsi
 29e2a11:	mov    (%rsi),%edx
 29e2a13:	mov    0x190(%rsp),%rcx
 29e2a1b:	mov    0x28(%rcx),%rcx
 29e2a1f:	cmp    0x160(%rcx),%edx
 29e2a25:	sete   %cl
 29e2a28:	movzbl %cl,%edx
 29e2a2b:	test   %edx,%edx
 29e2a2d:	je     29fbbfb <wasm[0]::function[1015]::helper::object_read+0x1acdb>
 29e2a33:	test   %r11d,%r11d
 29e2a36:	je     29fbbfd <wasm[0]::function[1015]::helper::object_read+0x1acdd>
 29e2a3c:	mov    0x2e0(%rsp),%r12
 29e2a44:	mov    0x28(%r12),%rsi
 29e2a49:	mov    0x20(%r12),%rbx
 29e2a4e:	mov    %r11d,%edx
 29e2a51:	lea    (%rbx,%rdx,1),%r12
 29e2a55:	xor    %r11,%r11
 29e2a58:	cmp    %rsi,%rdx
 29e2a5b:	cmova  %r11,%r12
 29e2a5f:	mov    0x10(%r12),%r12d
 29e2a64:	test   %r12d,%r12d
 29e2a67:	je     29fbbff <wasm[0]::function[1015]::helper::object_read+0x1acdf>
 29e2a6d:	test   %r12d,%r12d
 29e2a70:	je     29fbc01 <wasm[0]::function[1015]::helper::object_read+0x1ace1>
 29e2a76:	mov    %r12d,%r10d
 29e2a79:	lea    (%rbx,%r10,1),%r12
 29e2a7d:	cmp    %rsi,%r10
 29e2a80:	cmova  %r11,%r12
 29e2a84:	mov    0x10(%r12),%r12d
 29e2a89:	test   %r12d,%r12d
 29e2a8c:	je     29fbc03 <wasm[0]::function[1015]::helper::object_read+0x1ace3>
 29e2a92:	test   %r12d,%r12d
 29e2a95:	je     29fbc05 <wasm[0]::function[1015]::helper::object_read+0x1ace5>
 29e2a9b:	mov    %r12d,%r10d
 29e2a9e:	lea    0x10(%rbx,%r10,1),%rbx
 29e2aa3:	cmp    %rsi,%r10
 29e2aa6:	cmova  %r11,%rbx
 29e2aaa:	mov    0x240(%rsp),%rcx
 29e2ab2:	cmp    (%rbx),%ecx
 29e2ab4:	setae  %sil
 29e2ab8:	cmp    $0x2,%ecx
 29e2abb:	setae  %r10b
 29e2abf:	or     %r10d,%esi
 29e2ac2:	test   %sil,%sil
 29e2ac5:	jne    29fbc07 <wasm[0]::function[1015]::helper::object_read+0x1ace7>
 29e2acb:	mov    0x2e0(%rsp),%r12
 29e2ad3:	mov    0x28(%r12),%r11
 29e2ad8:	mov    %rdx,%rsi
 29e2adb:	add    0x20(%r12),%rsi
 29e2ae0:	xor    %rbx,%rbx
 29e2ae3:	cmp    %r11,%rdx
 29e2ae6:	cmova  %rbx,%rsi
 29e2aea:	mov    0x14(%rsi),%r15d
 29e2aee:	mov    0x240(%rsp),%rcx
 29e2af6:	mov    0x240(%rsp),%rsi
 29e2afe:	test   %esi,%ecx
 29e2b00:	je     29e2b3a <wasm[0]::function[1015]::helper::object_read+0x1c1a>
 29e2b06:	mov    0x2e0(%rsp),%r12
 29e2b0e:	mov    0x28(%r12),%r11
 29e2b13:	mov    0x20(%r12),%rcx
 29e2b18:	lea    (%rcx,%rdx,1),%rsi
 29e2b1c:	xor    %rbx,%rbx
 29e2b1f:	cmp    %r11,%rdx
 29e2b22:	cmova  %rbx,%rsi
 29e2b26:	mov    0x20(%rsi),%r13
 29e2b2a:	mov    0x2c(%rsi),%edx
 29e2b2d:	mov    0x240(%rsp),%rcx
 29e2b35:	jmp    29e2b69 <wasm[0]::function[1015]::helper::object_read+0x1c49>
 29e2b3a:	mov    0x2e0(%rsp),%r12
 29e2b42:	mov    0x28(%r12),%r11
 29e2b47:	mov    0x20(%r12),%rcx
 29e2b4c:	lea    (%rcx,%rdx,1),%rsi
 29e2b50:	xor    %rbx,%rbx
 29e2b53:	cmp    %r11,%rdx
 29e2b56:	cmova  %rbx,%rsi
 29e2b5a:	mov    0x18(%rsi),%r13
 29e2b5e:	mov    0x28(%rsi),%edx
 29e2b61:	mov    0x240(%rsp),%rcx
 29e2b69:	mov    0x240(%rsp),%rcx
 29e2b71:	shl    $0x3,%ecx
 29e2b74:	mov    %rcx,0x240(%rsp)
 29e2b7c:	shr    %cl,%r15d
 29e2b7f:	and    $0xff,%r15d
 29e2b86:	test   %eax,%eax
 29e2b88:	jne    29e2bab <wasm[0]::function[1015]::helper::object_read+0x1c8b>
 29e2b8e:	mov    0x1a0(%rsp),%rdx
 29e2b96:	mov    0x288(%rsp),%r13
 29e2b9e:	mov    0x280(%rsp),%r15
 29e2ba6:	jmp    29e2bc5 <wasm[0]::function[1015]::helper::object_read+0x1ca5>
 29e2bab:	xor    %esi,%esi
 29e2bad:	mov    %rsi,0x290(%rsp)
 29e2bb5:	mov    0x290(%rsp),%rcx
 29e2bbd:	mov    %rcx,0x298(%rsp)
 29e2bc5:	mov    0x210(%rsp),%rcx
 29e2bcd:	mov    %r15,0x280(%rsp)
 29e2bd5:	mov    %r13,0x288(%rsp)
 29e2bdd:	mov    %ecx,0xe8(%rsp)
 29e2be4:	mov    %r9d,0x78(%rsp)
 29e2be9:	mov    %r8d,0xa0(%rsp)
 29e2bf1:	mov    0x208(%rsp),%rcx
 29e2bf9:	mov    %ecx,0xa8(%rsp)
 29e2c00:	mov    %r14d,0x48(%rsp)
 29e2c05:	mov    %edi,0x80(%rsp)
 29e2c0c:	mov    %edx,0xb8(%rsp)
 29e2c13:	test   %eax,%eax
 29e2c15:	je     29e2c30 <wasm[0]::function[1015]::helper::object_read+0x1d10>
 29e2c1b:	mov    0x290(%rsp),%rsi
 29e2c23:	mov    0x298(%rsp),%rdi
 29e2c2b:	jmp    29efba2 <wasm[0]::function[1015]::helper::object_read+0xec82>
 29e2c30:	xor    %r10d,%r10d
 29e2c33:	mov    0x210(%rsp),%rax
 29e2c3b:	mov    0x210(%rsp),%rcx
 29e2c43:	test   %ecx,%eax
 29e2c45:	je     29e2ca8 <wasm[0]::function[1015]::helper::object_read+0x1d88>
 29e2c4b:	xor    %r10d,%r10d
 29e2c4e:	mov    0x210(%rsp),%rax
 29e2c56:	test   $0x1,%eax
 29e2c5b:	jne    29e2ca8 <wasm[0]::function[1015]::helper::object_read+0x1d88>
 29e2c61:	mov    0x2e0(%rsp),%r12
 29e2c69:	mov    0x28(%r12),%rax
 29e2c6e:	mov    0x20(%r12),%rsi
 29e2c73:	mov    0x210(%rsp),%rcx
 29e2c7b:	mov    %ecx,%r10d
 29e2c7e:	lea    0x4(%rsi,%r10,1),%rsi
 29e2c83:	xor    %r11,%r11
 29e2c86:	cmp    %rax,%r10
 29e2c89:	cmova  %r11,%rsi
 29e2c8d:	mov    (%rsi),%eax
 29e2c8f:	mov    0x190(%rsp),%rcx
 29e2c97:	mov    0x28(%rcx),%rcx
 29e2c9b:	cmp    0x254(%rcx),%eax
 29e2ca1:	sete   %al
 29e2ca4:	movzbl %al,%r10d
 29e2ca8:	xor    %ebx,%ebx
 29e2caa:	test   %r10d,%r10d
 29e2cad:	jne    29e2cc8 <wasm[0]::function[1015]::helper::object_read+0x1da8>
 29e2cb3:	mov    0x210(%rsp),%rax
 29e2cbb:	mov    0x290(%rsp),%rsi
 29e2cc3:	jmp    29e5a5e <wasm[0]::function[1015]::helper::object_read+0x4b3e>
 29e2cc8:	xor    %eax,%eax
 29e2cca:	mov    0x210(%rsp),%r10
 29e2cd2:	mov    0x210(%rsp),%r11
 29e2cda:	test   %r11d,%r10d
 29e2cdd:	je     29e2d3f <wasm[0]::function[1015]::helper::object_read+0x1e1f>
 29e2ce3:	xor    %eax,%eax
 29e2ce5:	mov    0x210(%rsp),%rcx
 29e2ced:	test   $0x1,%ecx
 29e2cf3:	jne    29e2d3f <wasm[0]::function[1015]::helper::object_read+0x1e1f>
 29e2cf9:	mov    0x2e0(%rsp),%r12
 29e2d01:	mov    0x28(%r12),%rax
 29e2d06:	mov    0x20(%r12),%rsi
 29e2d0b:	mov    0x210(%rsp),%rcx
 29e2d13:	mov    %ecx,%r10d
 29e2d16:	lea    0x4(%rsi,%r10,1),%rsi
 29e2d1b:	xor    %r11,%r11
 29e2d1e:	cmp    %rax,%r10
 29e2d21:	cmova  %r11,%rsi
 29e2d25:	mov    (%rsi),%eax
 29e2d27:	mov    0x190(%rsp),%rcx
 29e2d2f:	mov    0x28(%rcx),%rcx
 29e2d33:	cmp    0x254(%rcx),%eax
 29e2d39:	sete   %al
 29e2d3c:	movzbl %al,%eax
 29e2d3f:	test   %eax,%eax
 29e2d41:	je     29fbc09 <wasm[0]::function[1015]::helper::object_read+0x1ace9>
 29e2d47:	xor    %eax,%eax
 29e2d49:	mov    0x1b8(%rsp),%rcx
 29e2d51:	cmp    $0x4,%ecx
 29e2d54:	je     29e2d67 <wasm[0]::function[1015]::helper::object_read+0x1e47>
 29e2d5a:	mov    0x210(%rsp),%r10
 29e2d62:	jmp    29e3613 <wasm[0]::function[1015]::helper::object_read+0x26f3>
 29e2d67:	mov    0x78(%rsp),%r9d
 29e2d6c:	xor    %edi,%edi
 29e2d6e:	test   %r9d,%r9d
 29e2d71:	je     29e2dc5 <wasm[0]::function[1015]::helper::object_read+0x1ea5>
 29e2d77:	xor    %edi,%edi
 29e2d79:	test   $0x1,%r9d
 29e2d80:	jne    29e2dc5 <wasm[0]::function[1015]::helper::object_read+0x1ea5>
 29e2d86:	mov    0x2e0(%rsp),%r12
 29e2d8e:	mov    0x28(%r12),%rax
 29e2d93:	mov    0x20(%r12),%rcx
 29e2d98:	mov    %r9d,%edx
 29e2d9b:	lea    0x4(%rcx,%rdx,1),%rcx
 29e2da0:	xor    %rsi,%rsi
 29e2da3:	cmp    %rax,%rdx
 29e2da6:	cmova  %rsi,%rcx
 29e2daa:	mov    (%rcx),%eax
 29e2dac:	mov    0x190(%rsp),%rcx
 29e2db4:	mov    0x28(%rcx),%rcx
 29e2db8:	cmp    0x234(%rcx),%eax
 29e2dbe:	sete   %al
 29e2dc1:	rex movzbl %al,%edi
 29e2dc5:	test   %edi,%edi
 29e2dc7:	je     29fbc0b <wasm[0]::function[1015]::helper::object_read+0x1aceb>
 29e2dcd:	test   %r9d,%r9d
 29e2dd0:	je     29fbc0d <wasm[0]::function[1015]::helper::object_read+0x1aced>
 29e2dd6:	test   %r9d,%r9d
 29e2dd9:	je     29fbc0f <wasm[0]::function[1015]::helper::object_read+0x1acef>
 29e2ddf:	mov    0x2e0(%rsp),%r12
 29e2de7:	mov    0x28(%r12),%rcx
 29e2dec:	mov    0x20(%r12),%rdx
 29e2df1:	mov    %r9d,%edi
 29e2df4:	lea    (%rdx,%rdi,1),%rax
 29e2df8:	xor    %rsi,%rsi
 29e2dfb:	cmp    %rcx,%rdi
 29e2dfe:	cmova  %rsi,%rax
 29e2e02:	mov    0x10(%rax),%edi
 29e2e05:	xor    %eax,%eax
 29e2e07:	test   %edi,%edi
 29e2e09:	je     29fbc11 <wasm[0]::function[1015]::helper::object_read+0x1acf1>
 29e2e0f:	test   %edi,%edi
 29e2e11:	je     29fbc13 <wasm[0]::function[1015]::helper::object_read+0x1acf3>
 29e2e17:	mov    %edi,%edi
 29e2e19:	lea    0x10(%rdx,%rdi,1),%rdx
 29e2e1e:	cmp    %rcx,%rdi
 29e2e21:	cmova  %rsi,%rdx
 29e2e25:	mov    (%rdx),%esi
 29e2e27:	mov    0xe8(%rsp),%edx
 29e2e2e:	mov    %rdx,0x210(%rsp)
 29e2e36:	mov    0xa0(%rsp),%r8d
 29e2e3e:	mov    0xa8(%rsp),%r14d
 29e2e46:	mov    %r14,0x208(%rsp)
 29e2e4e:	mov    0x48(%rsp),%r14d
 29e2e53:	mov    0x80(%rsp),%edi
 29e2e5a:	mov    0xb8(%rsp),%edx
 29e2e61:	cmp    $0x6,%esi
 29e2e64:	je     29e2e77 <wasm[0]::function[1015]::helper::object_read+0x1f57>
 29e2e6a:	mov    0x210(%rsp),%r10
 29e2e72:	jmp    29e3613 <wasm[0]::function[1015]::helper::object_read+0x26f3>
 29e2e77:	mov    $0x8c,%edx
 29e2e7c:	mov    0x190(%rsp),%rsi
 29e2e84:	mov    0x190(%rsp),%rdi
 29e2e8c:	call   2f307a0 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 29e2e91:	test   %eax,%eax
 29e2e93:	je     29fbc15 <wasm[0]::function[1015]::helper::object_read+0x1acf5>
 29e2e99:	mov    0x1b8(%rsp),%rcx
 29e2ea1:	cmp    $0x4,%ecx
 29e2ea4:	je     29e2ef8 <wasm[0]::function[1015]::helper::object_read+0x1fd8>
 29e2eaa:	mov    0xe8(%rsp),%edx
 29e2eb1:	mov    %rdx,0x210(%rsp)
 29e2eb9:	mov    0x78(%rsp),%r9d
 29e2ebe:	mov    0xa0(%rsp),%r8d
 29e2ec6:	mov    0xa8(%rsp),%r14d
 29e2ece:	mov    %r14,0x208(%rsp)
 29e2ed6:	mov    0x48(%rsp),%r14d
 29e2edb:	mov    0x80(%rsp),%edi
 29e2ee2:	mov    0xb8(%rsp),%edx
 29e2ee9:	xor    %eax,%eax
 29e2eeb:	mov    0x210(%rsp),%r10
 29e2ef3:	jmp    29e3613 <wasm[0]::function[1015]::helper::object_read+0x26f3>
 29e2ef8:	mov    0x1b8(%rsp),%rcx
 29e2f00:	cmp    $0x3,%ecx
 29e2f03:	je     29e3583 <wasm[0]::function[1015]::helper::object_read+0x2663>
 29e2f09:	mov    0x1b8(%rsp),%rcx
 29e2f11:	cmp    $0x4,%ecx
 29e2f14:	je     29e3429 <wasm[0]::function[1015]::helper::object_read+0x2509>
 29e2f1a:	mov    0x1b8(%rsp),%rcx
 29e2f22:	cmp    $0xa,%ecx
 29e2f25:	je     29e2fe7 <wasm[0]::function[1015]::helper::object_read+0x20c7>
 29e2f2b:	mov    0x1b8(%rsp),%rcx
 29e2f33:	mov    0x1b8(%rsp),%rdx
 29e2f3b:	test   %edx,%ecx
 29e2f3d:	sete   %r11b
 29e2f41:	cmp    $0x1,%ecx
 29e2f44:	sete   %cl
 29e2f47:	or     %ecx,%r11d
 29e2f4a:	test   %r11b,%r11b
 29e2f4d:	jne    29e2f93 <wasm[0]::function[1015]::helper::object_read+0x2073>
 29e2f53:	mov    0x1b8(%rsp),%rcx
 29e2f5b:	cmp    $0x2,%ecx
 29e2f5e:	je     29e2f75 <wasm[0]::function[1015]::helper::object_read+0x2055>
 29e2f64:	mov    0x78(%rsp),%ecx
 29e2f68:	cmp    %eax,%ecx
 29e2f6a:	sete   %al
 29e2f6d:	movzbl %al,%eax
 29e2f70:	jmp    29e2f9b <wasm[0]::function[1015]::helper::object_read+0x207b>
 29e2f75:	mov    0x1c0(%rsp),%rax
 29e2f7d:	mov    0x1c0(%rsp),%r8
 29e2f85:	test   %rax,%r8
 29e2f88:	sete   %al
 29e2f8b:	movzbl %al,%eax
 29e2f8e:	jmp    29e2f9b <wasm[0]::function[1015]::helper::object_read+0x207b>
 29e2f93:	mov    0x278(%rsp),%rax
 29e2f9b:	mov    0xe8(%rsp),%edx
 29e2fa2:	mov    %rdx,0x210(%rsp)
 29e2faa:	mov    0x78(%rsp),%r9d
 29e2faf:	mov    0xa0(%rsp),%r8d
 29e2fb7:	mov    0xa8(%rsp),%r14d
 29e2fbf:	mov    %r14,0x208(%rsp)
 29e2fc7:	mov    0x48(%rsp),%r14d
 29e2fcc:	mov    0x80(%rsp),%edi
 29e2fd3:	mov    0xb8(%rsp),%edx
 29e2fda:	mov    0x210(%rsp),%r10
 29e2fe2:	jmp    29e3613 <wasm[0]::function[1015]::helper::object_read+0x26f3>
 29e2fe7:	mov    0x78(%rsp),%edx
 29e2feb:	xor    %ecx,%ecx
 29e2fed:	test   %edx,%edx
 29e2fef:	je     29e3040 <wasm[0]::function[1015]::helper::object_read+0x2120>
 29e2ff5:	xor    %ecx,%ecx
 29e2ff7:	test   $0x1,%edx
 29e2ffd:	jne    29e3040 <wasm[0]::function[1015]::helper::object_read+0x2120>
 29e3003:	mov    0x2e0(%rsp),%r12
 29e300b:	mov    0x28(%r12),%rcx
 29e3010:	mov    0x20(%r12),%rdi
 29e3015:	mov    %edx,%esi
 29e3017:	lea    0x4(%rdi,%rsi,1),%rdx
 29e301c:	xor    %rdi,%rdi
 29e301f:	cmp    %rcx,%rsi
 29e3022:	cmova  %rdi,%rdx
 29e3026:	mov    (%rdx),%ecx
 29e3028:	mov    0x190(%rsp),%rdx
 29e3030:	mov    0x28(%rdx),%rdx
 29e3034:	cmp    0x23c(%rdx),%ecx
 29e303a:	sete   %cl
 29e303d:	movzbl %cl,%ecx
 29e3040:	test   %ecx,%ecx
 29e3042:	je     29fbc17 <wasm[0]::function[1015]::helper::object_read+0x1acf7>
 29e3048:	xor    %ecx,%ecx
 29e304a:	test   %eax,%eax
 29e304c:	je     29e309c <wasm[0]::function[1015]::helper::object_read+0x217c>
 29e3052:	xor    %ecx,%ecx
 29e3054:	test   $0x1,%eax
 29e3059:	jne    29e309c <wasm[0]::function[1015]::helper::object_read+0x217c>
 29e305f:	mov    0x2e0(%rsp),%r12
 29e3067:	mov    0x28(%r12),%rcx
 29e306c:	mov    0x20(%r12),%rdx
 29e3071:	mov    %eax,%esi
 29e3073:	lea    0x4(%rdx,%rsi,1),%rdx
 29e3078:	xor    %rdi,%rdi
 29e307b:	cmp    %rcx,%rsi
 29e307e:	cmova  %rdi,%rdx
 29e3082:	mov    (%rdx),%ecx
 29e3084:	mov    0x190(%rsp),%rdx
 29e308c:	mov    0x28(%rdx),%rdx
 29e3090:	cmp    0x23c(%rdx),%ecx
 29e3096:	sete   %cl
 29e3099:	movzbl %cl,%ecx
 29e309c:	test   %ecx,%ecx
 29e309e:	je     29fbc19 <wasm[0]::function[1015]::helper::object_read+0x1acf9>
 29e30a4:	mov    0x78(%rsp),%r9d
 29e30a9:	test   %r9d,%r9d
 29e30ac:	je     29fbc1b <wasm[0]::function[1015]::helper::object_read+0x1acfb>
 29e30b2:	test   %r9d,%r9d
 29e30b5:	je     29fbc1d <wasm[0]::function[1015]::helper::object_read+0x1acfd>
 29e30bb:	mov    0x2e0(%rsp),%r12
 29e30c3:	mov    0x28(%r12),%rcx
 29e30c8:	mov    0x20(%r12),%rdx
 29e30cd:	mov    %r9d,%esi
 29e30d0:	lea    (%rdx,%rsi,1),%r8
 29e30d4:	xor    %rdi,%rdi
 29e30d7:	cmp    %rcx,%rsi
 29e30da:	cmova  %rdi,%r8
 29e30de:	mov    0x10(%r8),%esi
 29e30e2:	test   %eax,%eax
 29e30e4:	je     29fbc1f <wasm[0]::function[1015]::helper::object_read+0x1acff>
 29e30ea:	mov    %eax,%eax
 29e30ec:	lea    (%rdx,%rax,1),%r11
 29e30f0:	cmp    %rcx,%rax
 29e30f3:	cmova  %rdi,%r11
 29e30f7:	mov    0x10(%r11),%eax
 29e30fb:	mov    0x14(%r8),%r10d
 29e30ff:	mov    %r10d,0xd0(%rsp)
 29e3107:	mov    0x14(%r11),%r8d
 29e310b:	mov    %r8d,0x140(%rsp)
 29e3113:	test   %r10d,%r10d
 29e3116:	je     29fbc21 <wasm[0]::function[1015]::helper::object_read+0x1ad01>
 29e311c:	test   %r10d,%r10d
 29e311f:	je     29fbc23 <wasm[0]::function[1015]::helper::object_read+0x1ad03>
 29e3125:	mov    %r10d,%r11d
 29e3128:	lea    0x10(%rdx,%r11,1),%r10
 29e312d:	cmp    %rcx,%r11
 29e3130:	cmova  %rdi,%r10
 29e3134:	mov    (%r10),%ebx
 29e3137:	test   %r8d,%r8d
 29e313a:	je     29fbc25 <wasm[0]::function[1015]::helper::object_read+0x1ad05>
 29e3140:	test   %r8d,%r8d
 29e3143:	je     29fbc27 <wasm[0]::function[1015]::helper::object_read+0x1ad07>
 29e3149:	mov    %r8d,%r8d
 29e314c:	lea    0x10(%rdx,%r8,1),%rdx
 29e3151:	cmp    %rcx,%r8
 29e3154:	cmova  %rdi,%rdx
 29e3158:	mov    (%rdx),%r10d
 29e315b:	mov    0xe8(%rsp),%edx
 29e3162:	mov    %rdx,0x210(%rsp)
 29e316a:	mov    0xa0(%rsp),%r8d
 29e3172:	mov    0xa8(%rsp),%r14d
 29e317a:	mov    %r14,0x208(%rsp)
 29e3182:	mov    0x48(%rsp),%r14d
 29e3187:	mov    0x80(%rsp),%edi
 29e318e:	mov    0xb8(%rsp),%edx
 29e3195:	cmp    %eax,%esi
 29e3197:	sete   %sil
 29e319b:	cmp    %r10d,%ebx
 29e319e:	sete   %r10b
 29e31a2:	mov    %rsi,%r11
 29e31a5:	and    %r10d,%r11d
 29e31a8:	movzbl %r11b,%eax
 29e31ac:	mov    %rax,0x1d8(%rsp)
 29e31b4:	test   %sil,%r10b
 29e31b7:	jne    29e31d2 <wasm[0]::function[1015]::helper::object_read+0x22b2>
 29e31bd:	mov    0x1d8(%rsp),%rax
 29e31c5:	mov    0x210(%rsp),%r10
 29e31cd:	jmp    29e3613 <wasm[0]::function[1015]::helper::object_read+0x26f3>
 29e31d2:	mov    0xe8(%rsp),%ecx
 29e31d9:	mov    0x78(%rsp),%edx
 29e31dd:	mov    0xa0(%rsp),%esi
 29e31e4:	mov    0xa8(%rsp),%edi
 29e31eb:	mov    0x48(%rsp),%r8d
 29e31f0:	mov    0x80(%rsp),%r9d
 29e31f8:	mov    0xb8(%rsp),%r10d
 29e3200:	xor    %r13d,%r13d
 29e3203:	mov    %rcx,%r11
 29e3206:	mov    %ecx,0x58(%rsp)
 29e320a:	mov    %edx,0xc0(%rsp)
 29e3211:	mov    %esi,0xe0(%rsp)
 29e3218:	mov    %r11d,0x88(%rsp)
 29e3220:	mov    %edi,0xb0(%rsp)
 29e3227:	mov    %r8d,0x110(%rsp)
 29e322f:	mov    %r9d,0x120(%rsp)
 29e3237:	mov    %r10d,0x100(%rsp)
 29e323f:	mov    0x2e8(%rsp),%r15
 29e3247:	mov    (%r15),%rcx
 29e324a:	mov    0x228(%rsp),%rax
 29e3252:	cmp    %rax,%rcx
 29e3255:	jae    29fa51d <wasm[0]::function[1015]::helper::object_read+0x195fd>
 29e325b:	cmp    %ebx,%r13d
 29e325e:	jb     29e3271 <wasm[0]::function[1015]::helper::object_read+0x2351>
 29e3264:	mov    0x1d8(%rsp),%rax
 29e326c:	jmp    29e33da <wasm[0]::function[1015]::helper::object_read+0x24ba>
 29e3271:	mov    0xd0(%rsp),%esi
 29e3278:	test   %esi,%esi
 29e327a:	je     29fbc29 <wasm[0]::function[1015]::helper::object_read+0x1ad09>
 29e3280:	test   %esi,%esi
 29e3282:	je     29fbc2b <wasm[0]::function[1015]::helper::object_read+0x1ad0b>
 29e3288:	mov    0x2e0(%rsp),%r12
 29e3290:	mov    0x28(%r12),%rax
 29e3295:	mov    0x20(%r12),%rcx
 29e329a:	mov    %esi,%r8d
 29e329d:	lea    0x10(%rcx,%r8,1),%rdi
 29e32a2:	xor    %rdx,%rdx
 29e32a5:	cmp    %rax,%r8
 29e32a8:	cmova  %rdx,%rdi
 29e32ac:	mov    (%rdi),%r8d
 29e32af:	cmp    %r8d,%r13d
 29e32b2:	jae    29fbc2d <wasm[0]::function[1015]::helper::object_read+0x1ad0d>
 29e32b8:	mov    %r8d,%edi
 29e32bb:	shl    $0x3,%rdi
 29e32bf:	shr    $0x20,%rdi
 29e32c3:	test   %rdi,%rdi
 29e32c6:	jne    29fbc2f <wasm[0]::function[1015]::helper::object_read+0x1ad0f>
 29e32cc:	shl    $0x3,%r8d
 29e32d0:	add    $0x18,%r8d
 29e32d4:	jb     29fbc31 <wasm[0]::function[1015]::helper::object_read+0x1ad11>
 29e32da:	add    %r8d,%esi
 29e32dd:	jb     29fbc33 <wasm[0]::function[1015]::helper::object_read+0x1ad13>
 29e32e3:	mov    %esi,%edi
 29e32e5:	lea    (%rcx,%rdi,1),%rsi
 29e32e9:	cmp    %rax,%rdi
 29e32ec:	cmova  %rdx,%rsi
 29e32f0:	mov    %r13,%rdi
 29e32f3:	shl    $0x3,%edi
 29e32f6:	add    $0x18,%edi
 29e32fc:	sub    %edi,%r8d
 29e32ff:	sub    %r8,%rsi
 29e3302:	mov    (%rsi),%rsi
 29e3305:	mov    0x140(%rsp),%r8d
 29e330d:	test   %r8d,%r8d
 29e3310:	je     29fbc35 <wasm[0]::function[1015]::helper::object_read+0x1ad15>
 29e3316:	test   %r8d,%r8d
 29e3319:	je     29fbc37 <wasm[0]::function[1015]::helper::object_read+0x1ad17>
 29e331f:	mov    %r8d,%r10d
 29e3322:	lea    0x10(%rcx,%r10,1),%r9
 29e3327:	cmp    %rax,%r10
 29e332a:	cmova  %rdx,%r9
 29e332e:	mov    (%r9),%r9d
 29e3331:	cmp    %r9d,%r13d
 29e3334:	jae    29fbc39 <wasm[0]::function[1015]::helper::object_read+0x1ad19>
 29e333a:	mov    %r9d,%r10d
 29e333d:	shl    $0x3,%r10
 29e3341:	shr    $0x20,%r10
 29e3345:	test   %r10,%r10
 29e3348:	jne    29fbc3b <wasm[0]::function[1015]::helper::object_read+0x1ad1b>
 29e334e:	shl    $0x3,%r9d
 29e3352:	add    $0x18,%r9d
 29e3356:	jb     29fbc3d <wasm[0]::function[1015]::helper::object_read+0x1ad1d>
 29e335c:	add    %r9d,%r8d
 29e335f:	jb     29fbc3f <wasm[0]::function[1015]::helper::object_read+0x1ad1f>
 29e3365:	mov    %r8d,%r8d
 29e3368:	add    %r8,%rcx
 29e336b:	cmp    %rax,%r8
 29e336e:	cmova  %rdx,%rcx
 29e3372:	sub    %edi,%r9d
 29e3375:	sub    %r9,%rcx
 29e3378:	mov    (%rcx),%rcx
 29e337b:	cmp    %rcx,%rsi
 29e337e:	sete   %al
 29e3381:	movzbl %al,%eax
 29e3384:	cmp    %rcx,%rsi
 29e3387:	jne    29e33da <wasm[0]::function[1015]::helper::object_read+0x24ba>
 29e338d:	mov    0x58(%rsp),%ecx
 29e3391:	mov    0xc0(%rsp),%edx
 29e3398:	mov    0xe0(%rsp),%esi
 29e339f:	mov    0x88(%rsp),%r11d
 29e33a7:	mov    0xb0(%rsp),%edi
 29e33ae:	mov    0x110(%rsp),%r8d
 29e33b6:	mov    0x120(%rsp),%r9d
 29e33be:	mov    0x100(%rsp),%r10d
 29e33c6:	add    $0x1,%r13d
 29e33cd:	mov    %rax,0x1d8(%rsp)
 29e33d5:	jmp    29e3206 <wasm[0]::function[1015]::helper::object_read+0x22e6>
 29e33da:	mov    0x58(%rsp),%edx
 29e33de:	mov    %rdx,0x210(%rsp)
 29e33e6:	mov    0xc0(%rsp),%r9d
 29e33ee:	mov    0xe0(%rsp),%r8d
 29e33f6:	mov    0x88(%rsp),%r10d
 29e33fe:	mov    0xb0(%rsp),%r14d
 29e3406:	mov    %r14,0x208(%rsp)
 29e340e:	mov    0x110(%rsp),%r14d
 29e3416:	mov    0x120(%rsp),%edi
 29e341d:	mov    0x100(%rsp),%edx
 29e3424:	jmp    29e3613 <wasm[0]::function[1015]::helper::object_read+0x26f3>
 29e3429:	mov    0x78(%rsp),%ecx
 29e342d:	cmp    %eax,%ecx
 29e342f:	je     29e352f <wasm[0]::function[1015]::helper::object_read+0x260f>
 29e3435:	xor    %edx,%edx
 29e3437:	test   %ecx,%ecx
 29e3439:	je     29e348c <wasm[0]::function[1015]::helper::object_read+0x256c>
 29e343f:	xor    %edx,%edx
 29e3441:	test   $0x1,%ecx
 29e3447:	jne    29e348c <wasm[0]::function[1015]::helper::object_read+0x256c>
 29e344d:	mov    0x2e0(%rsp),%r12
 29e3455:	mov    0x28(%r12),%rsi
 29e345a:	mov    0x20(%r12),%r8
 29e345f:	mov    %ecx,%edi
 29e3461:	lea    0x4(%r8,%rdi,1),%rdx
 29e3466:	xor    %r8,%r8
 29e3469:	cmp    %rsi,%rdi
 29e346c:	cmova  %r8,%rdx
 29e3470:	mov    (%rdx),%esi
 29e3472:	mov    0x190(%rsp),%rcx
 29e347a:	mov    0x28(%rcx),%rdi
 29e347e:	cmp    0x234(%rdi),%esi
 29e3484:	sete   %dil
 29e3488:	movzbl %dil,%edx
 29e348c:	test   %edx,%edx
 29e348e:	je     29fbc41 <wasm[0]::function[1015]::helper::object_read+0x1ad21>
 29e3494:	xor    %edx,%edx
 29e3496:	test   %eax,%eax
 29e3498:	jne    29e34a6 <wasm[0]::function[1015]::helper::object_read+0x2586>
 29e349e:	mov    %rax,%rdi
 29e34a1:	jmp    29e34fb <wasm[0]::function[1015]::helper::object_read+0x25db>
 29e34a6:	xor    %edx,%edx
 29e34a8:	test   $0x1,%eax
 29e34ad:	je     29e34bb <wasm[0]::function[1015]::helper::object_read+0x259b>
 29e34b3:	mov    %rax,%rdi
 29e34b6:	jmp    29e34fb <wasm[0]::function[1015]::helper::object_read+0x25db>
 29e34bb:	mov    0x2e0(%rsp),%r12
 29e34c3:	mov    0x28(%r12),%rcx
 29e34c8:	mov    0x20(%r12),%rsi
 29e34cd:	mov    %eax,%edx
 29e34cf:	mov    %rax,%rdi
 29e34d2:	lea    0x4(%rsi,%rdx,1),%rax
 29e34d7:	xor    %rsi,%rsi
 29e34da:	cmp    %rcx,%rdx
 29e34dd:	cmova  %rsi,%rax
 29e34e1:	mov    (%rax),%eax
 29e34e3:	mov    0x190(%rsp),%rcx
 29e34eb:	mov    0x28(%rcx),%rcx
 29e34ef:	cmp    0x234(%rcx),%eax
 29e34f5:	sete   %al
 29e34f8:	movzbl %al,%edx
 29e34fb:	test   %edx,%edx
 29e34fd:	je     29fbc43 <wasm[0]::function[1015]::helper::object_read+0x1ad23>
 29e3503:	mov    0x78(%rsp),%edx
 29e3507:	xor    %r8d,%r8d
 29e350a:	test   %edx,%edx
 29e350c:	je     29fbc45 <wasm[0]::function[1015]::helper::object_read+0x1ad25>
 29e3512:	mov    %rdi,%rcx
 29e3515:	mov    0x190(%rsp),%rsi
 29e351d:	mov    0x190(%rsp),%rdi
 29e3525:	call   2ae54e0 <wasm[0]::function[1057]::helper::string_equality>
 29e352a:	jmp    29e3537 <wasm[0]::function[1015]::helper::object_read+0x2617>
 29e352f:	mov    0x278(%rsp),%rax
 29e3537:	mov    0xe8(%rsp),%edx
 29e353e:	mov    %rdx,0x210(%rsp)
 29e3546:	mov    0x78(%rsp),%r9d
 29e354b:	mov    0xa0(%rsp),%r8d
 29e3553:	mov    0xa8(%rsp),%r14d
 29e355b:	mov    %r14,0x208(%rsp)
 29e3563:	mov    0x48(%rsp),%r14d
 29e3568:	mov    0x80(%rsp),%edi
 29e356f:	mov    0xb8(%rsp),%edx
 29e3576:	mov    0x210(%rsp),%r10
 29e357e:	jmp    29e3613 <wasm[0]::function[1015]::helper::object_read+0x26f3>
 29e3583:	mov    0xe8(%rsp),%edx
 29e358a:	mov    %rdx,0x210(%rsp)
 29e3592:	mov    0x78(%rsp),%r9d
 29e3597:	mov    0xa0(%rsp),%r8d
 29e359f:	mov    0xa8(%rsp),%r14d
 29e35a7:	mov    %r14,0x208(%rsp)
 29e35af:	mov    0x48(%rsp),%r14d
 29e35b4:	mov    0x80(%rsp),%edi
 29e35bb:	mov    0xb8(%rsp),%edx
 29e35c2:	xor    %r10,%r10
 29e35c5:	mov    0x1c0(%rsp),%rax
 29e35cd:	mov    0x1c0(%rsp),%rcx
 29e35d5:	test   %rcx,%rax
 29e35d8:	sete   %al
 29e35db:	movq   %rcx,%xmm0
 29e35e0:	ucomisd %xmm0,%xmm0
 29e35e4:	setp   %sil
 29e35e8:	setne  %r11b
 29e35ec:	or     %r11d,%esi
 29e35ef:	movq   %r10,%xmm0
 29e35f4:	ucomisd %xmm0,%xmm0
 29e35f8:	setp   %r10b
 29e35fc:	setne  %r11b
 29e3600:	or     %r11d,%r10d
 29e3603:	and    %r10d,%esi
 29e3606:	or     %esi,%eax
 29e3608:	movzbl %al,%eax
 29e360b:	mov    0x210(%rsp),%r10
 29e3613:	test   %eax,%eax
 29e3615:	jne    29e59a8 <wasm[0]::function[1015]::helper::object_read+0x4a88>
 29e361b:	xor    %eax,%eax
 29e361d:	mov    0x1b8(%rsp),%rcx
 29e3625:	cmp    $0x4,%ecx
 29e3628:	je     29e3636 <wasm[0]::function[1015]::helper::object_read+0x2716>
 29e362e:	mov    %rax,%rsi
 29e3631:	jmp    29e39c7 <wasm[0]::function[1015]::helper::object_read+0x2aa7>
 29e3636:	xor    %eax,%eax
 29e3638:	test   %r9d,%r9d
 29e363b:	je     29e368e <wasm[0]::function[1015]::helper::object_read+0x276e>
 29e3641:	xor    %eax,%eax
 29e3643:	test   $0x1,%r9d
 29e364a:	jne    29e368e <wasm[0]::function[1015]::helper::object_read+0x276e>
 29e3650:	mov    0x2e0(%rsp),%r12
 29e3658:	mov    0x28(%r12),%rax
 29e365d:	mov    0x20(%r12),%rsi
 29e3662:	mov    %r9d,%r11d
 29e3665:	lea    0x4(%rsi,%r11,1),%rsi
 29e366a:	xor    %rbx,%rbx
 29e366d:	cmp    %rax,%r11
 29e3670:	cmova  %rbx,%rsi
 29e3674:	mov    (%rsi),%eax
 29e3676:	mov    0x190(%rsp),%rcx
 29e367e:	mov    0x28(%rcx),%rcx
 29e3682:	cmp    0x234(%rcx),%eax
 29e3688:	sete   %al
 29e368b:	movzbl %al,%eax
 29e368e:	test   %eax,%eax
 29e3690:	je     29fbc47 <wasm[0]::function[1015]::helper::object_read+0x1ad27>
 29e3696:	test   %r9d,%r9d
 29e3699:	je     29fbc49 <wasm[0]::function[1015]::helper::object_read+0x1ad29>
 29e369f:	test   %r9d,%r9d
 29e36a2:	je     29fbc4b <wasm[0]::function[1015]::helper::object_read+0x1ad2b>
 29e36a8:	mov    0x2e0(%rsp),%r12
 29e36b0:	mov    0x28(%r12),%rsi
 29e36b5:	mov    0x20(%r12),%r11
 29e36ba:	mov    %r9d,%r12d
 29e36bd:	lea    (%r11,%r12,1),%rax
 29e36c1:	xor    %rbx,%rbx
 29e36c4:	cmp    %rsi,%r12
 29e36c7:	cmova  %rbx,%rax
 29e36cb:	mov    0x10(%rax),%r12d
 29e36cf:	mov    %r12d,0xe8(%rsp)
 29e36d7:	xor    %eax,%eax
 29e36d9:	test   %r12d,%r12d
 29e36dc:	je     29fbc4d <wasm[0]::function[1015]::helper::object_read+0x1ad2d>
 29e36e2:	test   %r12d,%r12d
 29e36e5:	je     29fbc4f <wasm[0]::function[1015]::helper::object_read+0x1ad2f>
 29e36eb:	mov    %r12d,%r12d
 29e36ee:	lea    0x10(%r11,%r12,1),%r11
 29e36f3:	cmp    %rsi,%r12
 29e36f6:	cmova  %rbx,%r11
 29e36fa:	mov    (%r11),%ebx
 29e36fd:	test   %ebx,%ebx
 29e36ff:	sete   %sil
 29e3703:	cmp    $0xa,%ebx
 29e3706:	seta   %r11b
 29e370a:	or     %r11d,%esi
 29e370d:	test   %sil,%sil
 29e3710:	je     29e371e <wasm[0]::function[1015]::helper::object_read+0x27fe>
 29e3716:	mov    %rax,%rsi
 29e3719:	jmp    29e39c7 <wasm[0]::function[1015]::helper::object_read+0x2aa7>
 29e371e:	mov    0xe8(%rsp),%eax
 29e3725:	test   %eax,%eax
 29e3727:	je     29fbc51 <wasm[0]::function[1015]::helper::object_read+0x1ad31>
 29e372d:	test   %eax,%eax
 29e372f:	je     29fbc53 <wasm[0]::function[1015]::helper::object_read+0x1ad33>
 29e3735:	mov    0x2e0(%rsp),%r12
 29e373d:	mov    0x28(%r12),%r11
 29e3742:	mov    0x20(%r12),%rsi
 29e3747:	mov    %eax,%r15d
 29e374a:	lea    0x10(%rsi,%r15,1),%r13
 29e374f:	xor    %r12,%r12
 29e3752:	cmp    %r11,%r15
 29e3755:	cmova  %r12,%r13
 29e3759:	mov    0x0(%r13),%r13d
 29e375d:	test   %r13d,%r13d
 29e3760:	je     29fbc55 <wasm[0]::function[1015]::helper::object_read+0x1ad35>
 29e3766:	mov    %r13d,%r15d
 29e3769:	shl    $1,%r15
 29e376c:	shr    $0x20,%r15
 29e3770:	test   %r15,%r15
 29e3773:	jne    29fbc57 <wasm[0]::function[1015]::helper::object_read+0x1ad37>
 29e3779:	add    %r13d,%r13d
 29e377c:	add    $0x14,%r13d
 29e3780:	jb     29fbc59 <wasm[0]::function[1015]::helper::object_read+0x1ad39>
 29e3786:	add    %r13d,%eax
 29e3789:	jb     29fbc5b <wasm[0]::function[1015]::helper::object_read+0x1ad3b>
 29e378f:	mov    %eax,%r15d
 29e3792:	lea    (%rsi,%r15,1),%rax
 29e3796:	cmp    %r11,%r15
 29e3799:	cmova  %r12,%rax
 29e379d:	sub    $0x14,%r13d
 29e37a1:	sub    %r13,%rax
 29e37a4:	movzwl (%rax),%eax
 29e37a7:	cmp    $0x30,%eax
 29e37aa:	je     29e39a9 <wasm[0]::function[1015]::helper::object_read+0x2a89>
 29e37b0:	xor    %r15d,%r15d
 29e37b3:	xor    %r13,%r13
 29e37b6:	mov    0x210(%rsp),%rax
 29e37be:	mov    %r15,%rsi
 29e37c1:	mov    %eax,0xe0(%rsp)
 29e37c8:	mov    %r8d,0xc0(%rsp)
 29e37d0:	mov    %r9d,0x58(%rsp)
 29e37d5:	mov    %esi,0xb8(%rsp)
 29e37dc:	mov    %r10d,0x80(%rsp)
 29e37e4:	mov    0x208(%rsp),%rax
 29e37ec:	mov    %eax,0x48(%rsp)
 29e37f0:	mov    %r14d,0xa8(%rsp)
 29e37f8:	mov    %edi,0xa0(%rsp)
 29e37ff:	mov    %edx,0x78(%rsp)
 29e3803:	mov    0x2e8(%rsp),%r11
 29e380b:	mov    (%r11),%rax
 29e380e:	mov    0x228(%rsp),%rcx
 29e3816:	cmp    %rcx,%rax
 29e3819:	jae    29fa555 <wasm[0]::function[1015]::helper::object_read+0x19635>
 29e381f:	mov    0xe8(%rsp),%ecx
 29e3826:	xor    %eax,%eax
 29e3828:	test   %ecx,%ecx
 29e382a:	je     29fbc5d <wasm[0]::function[1015]::helper::object_read+0x1ad3d>
 29e3830:	test   %ecx,%ecx
 29e3832:	je     29fbc5f <wasm[0]::function[1015]::helper::object_read+0x1ad3f>
 29e3838:	mov    0x2e0(%rsp),%r12
 29e3840:	mov    0x28(%r12),%rdx
 29e3845:	mov    0x20(%r12),%rsi
 29e384a:	mov    %ecx,%r9d
 29e384d:	lea    0x10(%rsi,%r9,1),%r8
 29e3852:	xor    %rdi,%rdi
 29e3855:	cmp    %rdx,%r9
 29e3858:	cmova  %rdi,%r8
 29e385c:	mov    (%r8),%r8d
 29e385f:	cmp    %r8d,%r15d
 29e3862:	jae    29fbc61 <wasm[0]::function[1015]::helper::object_read+0x1ad41>
 29e3868:	mov    %r8d,%r9d
 29e386b:	shl    $1,%r9
 29e386e:	shr    $0x20,%r9
 29e3872:	test   %r9,%r9
 29e3875:	jne    29fbc63 <wasm[0]::function[1015]::helper::object_read+0x1ad43>
 29e387b:	add    %r8d,%r8d
 29e387e:	add    $0x14,%r8d
 29e3882:	jb     29fbc65 <wasm[0]::function[1015]::helper::object_read+0x1ad45>
 29e3888:	add    %r8d,%ecx
 29e388b:	jb     29fbc67 <wasm[0]::function[1015]::helper::object_read+0x1ad47>
 29e3891:	mov    %ecx,%r9d
 29e3894:	lea    (%rsi,%r9,1),%rcx
 29e3898:	cmp    %rdx,%r9
 29e389b:	cmova  %rdi,%rcx
 29e389f:	lea    0x14(%r15,%r15,1),%edx
 29e38a4:	sub    %edx,%r8d
 29e38a7:	sub    %r8,%rcx
 29e38aa:	movzwq (%rcx),%r11
 29e38ae:	mov    0xe0(%rsp),%edx
 29e38b5:	mov    %rdx,0x210(%rsp)
 29e38bd:	mov    0xc0(%rsp),%r8d
 29e38c5:	mov    0x58(%rsp),%r9d
 29e38ca:	mov    0xb8(%rsp),%esi
 29e38d1:	mov    0x80(%rsp),%r10d
 29e38d9:	mov    0x48(%rsp),%r14d
 29e38de:	mov    %r14,0x208(%rsp)
 29e38e6:	mov    0xa8(%rsp),%r14d
 29e38ee:	mov    0xa0(%rsp),%edi
 29e38f5:	mov    0x78(%rsp),%edx
 29e38f9:	movzwl %r11w,%r11d
 29e38fd:	sub    $0x30,%r11d
 29e3901:	cmp    $0x9,%r11d
 29e3905:	ja     29e39c7 <wasm[0]::function[1015]::helper::object_read+0x2aa7>
 29e390b:	mov    0xe0(%rsp),%edx
 29e3912:	mov    %rdx,0x210(%rsp)
 29e391a:	mov    0xc0(%rsp),%r8d
 29e3922:	mov    0x58(%rsp),%r9d
 29e3927:	mov    0xb8(%rsp),%esi
 29e392e:	mov    0x80(%rsp),%r10d
 29e3936:	mov    0x48(%rsp),%r14d
 29e393b:	mov    %r14,0x208(%rsp)
 29e3943:	mov    0xa8(%rsp),%r14d
 29e394b:	mov    0xa0(%rsp),%edi
 29e3952:	mov    0x78(%rsp),%edx
 29e3956:	add    $0x1,%r15d
 29e395d:	imul   $0xa,%r13,%rax
 29e3961:	lea    (%rax,%r11,1),%r12
 29e3965:	cmp    %ebx,%r15d
 29e3968:	jae    29e397e <wasm[0]::function[1015]::helper::object_read+0x2a5e>
 29e396e:	mov    0x210(%rsp),%rax
 29e3976:	mov    %r12,%r13
 29e3979:	jmp    29e37c1 <wasm[0]::function[1015]::helper::object_read+0x28a1>
 29e397e:	xor    %eax,%eax
 29e3980:	cmp    0x18f21(%rip),%r12        # 29fc8a8 <wasm[0]::function[1015]::helper::object_read+0x1b988>
 29e3987:	jae    29e39c7 <wasm[0]::function[1015]::helper::object_read+0x2aa7>
 29e398d:	imul   $0xa,%r13d,%eax
 29e3991:	add    %r11d,%eax
 29e3994:	mov    %rax,0x1e0(%rsp)
 29e399c:	mov    0x278(%rsp),%rax
 29e39a4:	jmp    29e39c7 <wasm[0]::function[1015]::helper::object_read+0x2aa7>
 29e39a9:	cmp    $0x1,%ebx
 29e39ac:	sete   %al
 29e39af:	movzbl %al,%eax
 29e39b2:	mov    %rsi,%rcx
 29e39b5:	mov    %rsi,0x1e0(%rsp)
 29e39bd:	xor    %esi,%esi
 29e39bf:	mov    %rsi,0x1e0(%rsp)
 29e39c7:	mov    %r8d,0xa0(%rsp)
 29e39cf:	mov    %r9d,0xa8(%rsp)
 29e39d7:	mov    %esi,0x48(%rsp)
 29e39db:	mov    %r10d,0x80(%rsp)
 29e39e3:	mov    0x208(%rsp),%r8
 29e39eb:	mov    %r8d,0xb8(%rsp)
 29e39f3:	mov    %r14d,0x58(%rsp)
 29e39f8:	mov    %edi,0xc0(%rsp)
 29e39ff:	mov    %edx,0xe0(%rsp)
 29e3a06:	test   %eax,%eax
 29e3a08:	mov    %rax,0x200(%rsp)
 29e3a10:	jne    29e3acb <wasm[0]::function[1015]::helper::object_read+0x2bab>
 29e3a16:	xor    %ebx,%ebx
 29e3a18:	mov    0x210(%rsp),%rax
 29e3a20:	mov    0x210(%rsp),%rdx
 29e3a28:	test   %eax,%edx
 29e3a2a:	je     29fbc69 <wasm[0]::function[1015]::helper::object_read+0x1ad49>
 29e3a30:	test   %eax,%edx
 29e3a32:	je     29fbc6b <wasm[0]::function[1015]::helper::object_read+0x1ad4b>
 29e3a38:	mov    0x2e0(%rsp),%r12
 29e3a40:	mov    0x28(%r12),%rax
 29e3a45:	mov    0x20(%r12),%rdx
 29e3a4a:	mov    0x210(%rsp),%rcx
 29e3a52:	mov    %ecx,%ecx
 29e3a54:	lea    (%rdx,%rcx,1),%r10
 29e3a58:	xor    %rdx,%rdx
 29e3a5b:	cmp    %rax,%rcx
 29e3a5e:	cmova  %rdx,%r10
 29e3a62:	mov    0x10(%r10),%edx
 29e3a66:	test   %edx,%edx
 29e3a68:	je     29fbc6d <wasm[0]::function[1015]::helper::object_read+0x1ad4d>
 29e3a6e:	mov    0x1b8(%rsp),%rcx
 29e3a76:	mov    0x190(%rsp),%rsi
 29e3a7e:	mov    0x190(%rsp),%rdi
 29e3a86:	mov    0x1c0(%rsp),%r8
 29e3a8e:	call   29ffc00 <wasm[0]::function[1019]::helper::ordinary_own_descriptor>
 29e3a93:	mov    0x80(%rsp),%edi
 29e3a9a:	mov    0xa8(%rsp),%r8d
 29e3aa2:	mov    0xb8(%rsp),%r11d
 29e3aaa:	mov    0x58(%rsp),%r12d
 29e3aaf:	mov    0xc0(%rsp),%r13d
 29e3ab7:	mov    0xe0(%rsp),%edx
 29e3abe:	mov    0x290(%rsp),%rsi
 29e3ac6:	jmp    29e5774 <wasm[0]::function[1015]::helper::object_read+0x4854>
 29e3acb:	mov    0x210(%rsp),%rax
 29e3ad3:	mov    0x210(%rsp),%rdx
 29e3adb:	test   %eax,%edx
 29e3add:	je     29fbc6f <wasm[0]::function[1015]::helper::object_read+0x1ad4f>
 29e3ae3:	test   %eax,%edx
 29e3ae5:	je     29fbc71 <wasm[0]::function[1015]::helper::object_read+0x1ad51>
 29e3aeb:	mov    0x2e0(%rsp),%r12
 29e3af3:	mov    0x28(%r12),%rcx
 29e3af8:	mov    0x20(%r12),%rsi
 29e3afd:	mov    %edx,%edx
 29e3aff:	lea    (%rsi,%rdx,1),%rax
 29e3b03:	xor    %rdi,%rdi
 29e3b06:	cmp    %rcx,%rdx
 29e3b09:	cmova  %rdi,%rax
 29e3b0d:	mov    0x14(%rax),%eax
 29e3b10:	test   %eax,%eax
 29e3b12:	je     29fbc73 <wasm[0]::function[1015]::helper::object_read+0x1ad53>
 29e3b18:	test   %eax,%eax
 29e3b1a:	je     29fbc75 <wasm[0]::function[1015]::helper::object_read+0x1ad55>
 29e3b20:	mov    %eax,%eax
 29e3b22:	add    %rax,%rsi
 29e3b25:	cmp    %rcx,%rax
 29e3b28:	cmova  %rdi,%rsi
 29e3b2c:	mov    0x24(%rsi),%edi
 29e3b2f:	cmp    $0x2,%edi
 29e3b32:	sete   %sil
 29e3b36:	mov    $0x3,%ecx
 29e3b3b:	cmp    $0x3,%edi
 29e3b3e:	sete   %dil
 29e3b42:	or     %edi,%esi
 29e3b44:	test   %sil,%sil
 29e3b47:	jne    29e53fd <wasm[0]::function[1015]::helper::object_read+0x44dd>
 29e3b4d:	mov    0x2e0(%rsp),%r12
 29e3b55:	mov    0x28(%r12),%rax
 29e3b5a:	mov    0x20(%r12),%rsi
 29e3b5f:	lea    (%rsi,%rdx,1),%rdi
 29e3b63:	xor    %rcx,%rcx
 29e3b66:	cmp    %rax,%rdx
 29e3b69:	cmova  %rcx,%rdi
 29e3b6d:	mov    0x14(%rdi),%r11d
 29e3b71:	mov    %r11d,0x78(%rsp)
 29e3b76:	test   %r11d,%r11d
 29e3b79:	je     29fbc77 <wasm[0]::function[1015]::helper::object_read+0x1ad57>
 29e3b7f:	test   %r11d,%r11d
 29e3b82:	je     29fbc79 <wasm[0]::function[1015]::helper::object_read+0x1ad59>
 29e3b88:	mov    %r11d,%edi
 29e3b8b:	lea    (%rsi,%rdi,1),%rdx
 29e3b8f:	cmp    %rax,%rdi
 29e3b92:	cmova  %rcx,%rdx
 29e3b96:	mov    0x24(%rdx),%eax
 29e3b99:	mov    0xa0(%rsp),%edx
 29e3ba0:	mov    0x48(%rsp),%ecx
 29e3ba4:	mov    %rcx,0x1e8(%rsp)
 29e3bac:	mov    0x80(%rsp),%esi
 29e3bb3:	mov    %rsi,0x1f0(%rsp)
 29e3bbb:	mov    0xa8(%rsp),%edi
 29e3bc2:	mov    %rdi,0x1f8(%rsp)
 29e3bca:	mov    0xb8(%rsp),%edi
 29e3bd1:	mov    0x58(%rsp),%r8d
 29e3bd6:	mov    0xc0(%rsp),%r9d
 29e3bde:	mov    0xe0(%rsp),%r10d
 29e3be6:	cmp    $0x2,%eax
 29e3be9:	sete   %cl
 29e3bec:	cmp    $0x3,%eax
 29e3bef:	sete   %al
 29e3bf2:	or     %eax,%ecx
 29e3bf4:	test   %cl,%cl
 29e3bf6:	je     29e4dd2 <wasm[0]::function[1015]::helper::object_read+0x3eb2>
 29e3bfc:	mov    0x78(%rsp),%eax
 29e3c00:	test   %eax,%eax
 29e3c02:	je     29fbc7b <wasm[0]::function[1015]::helper::object_read+0x1ad5b>
 29e3c08:	test   %eax,%eax
 29e3c0a:	je     29fbc7d <wasm[0]::function[1015]::helper::object_read+0x1ad5d>
 29e3c10:	mov    0x2e0(%rsp),%r12
 29e3c18:	mov    0x28(%r12),%rcx
 29e3c1d:	mov    %eax,%edx
 29e3c1f:	mov    %rdx,%rax
 29e3c22:	add    0x20(%r12),%rax
 29e3c27:	xor    %rsi,%rsi
 29e3c2a:	cmp    %rcx,%rdx
 29e3c2d:	cmova  %rsi,%rax
 29e3c31:	mov    0x24(%rax),%eax
 29e3c34:	cmp    $0x3,%eax
 29e3c37:	je     29e3d59 <wasm[0]::function[1015]::helper::object_read+0x2e39>
 29e3c3d:	mov    0x78(%rsp),%eax
 29e3c41:	xor    %ebx,%ebx
 29e3c43:	test   %eax,%eax
 29e3c45:	je     29fbc7f <wasm[0]::function[1015]::helper::object_read+0x1ad5f>
 29e3c4b:	test   %eax,%eax
 29e3c4d:	je     29fbc81 <wasm[0]::function[1015]::helper::object_read+0x1ad61>
 29e3c53:	mov    0x2e0(%rsp),%r12
 29e3c5b:	mov    0x28(%r12),%rcx
 29e3c60:	mov    0x20(%r12),%rdx
 29e3c65:	mov    %eax,%edi
 29e3c67:	lea    (%rdx,%rdi,1),%rax
 29e3c6b:	xor    %rsi,%rsi
 29e3c6e:	cmp    %rcx,%rdi
 29e3c71:	cmova  %rsi,%rax
 29e3c75:	mov    0x28(%rax),%edi
 29e3c78:	mov    0x2c(%rax),%eax
 29e3c7b:	test   %edi,%edi
 29e3c7d:	je     29fbc83 <wasm[0]::function[1015]::helper::object_read+0x1ad63>
 29e3c83:	test   %edi,%edi
 29e3c85:	je     29fbc85 <wasm[0]::function[1015]::helper::object_read+0x1ad65>
 29e3c8b:	mov    %edi,%edi
 29e3c8d:	lea    0x10(%rdx,%rdi,1),%rdx
 29e3c92:	cmp    %rcx,%rdi
 29e3c95:	cmova  %rsi,%rdx
 29e3c99:	mov    0x1e0(%rsp),%r14
 29e3ca1:	mov    %r14d,%ecx
 29e3ca4:	mov    (%rdx),%edx
 29e3ca6:	cmp    %rdx,%rcx
 29e3ca9:	jae    29e3e58 <wasm[0]::function[1015]::helper::object_read+0x2f38>
 29e3caf:	xor    %ebx,%ebx
 29e3cb1:	test   %eax,%eax
 29e3cb3:	je     29fbc87 <wasm[0]::function[1015]::helper::object_read+0x1ad67>
 29e3cb9:	test   %eax,%eax
 29e3cbb:	je     29fbc89 <wasm[0]::function[1015]::helper::object_read+0x1ad69>
 29e3cc1:	mov    0x2e0(%rsp),%r12
 29e3cc9:	mov    0x28(%r12),%rsi
 29e3cce:	mov    0x20(%r12),%rdi
 29e3cd3:	mov    %eax,%r9d
 29e3cd6:	lea    0x10(%rdi,%r9,1),%rcx
 29e3cdb:	xor    %r8,%r8
 29e3cde:	cmp    %rsi,%r9
 29e3ce1:	cmova  %r8,%rcx
 29e3ce5:	mov    (%rcx),%ecx
 29e3ce7:	mov    0x1e0(%rsp),%r14
 29e3cef:	mov    %r14,%rdx
 29e3cf2:	shr    $0x6,%edx
 29e3cf5:	cmp    %ecx,%edx
 29e3cf7:	jae    29fbc8b <wasm[0]::function[1015]::helper::object_read+0x1ad6b>
 29e3cfd:	mov    %ecx,%r9d
 29e3d00:	shl    $0x3,%r9
 29e3d04:	shr    $0x20,%r9
 29e3d08:	test   %r9,%r9
 29e3d0b:	jne    29fbc8d <wasm[0]::function[1015]::helper::object_read+0x1ad6d>
 29e3d11:	shl    $0x3,%ecx
 29e3d14:	add    $0x18,%ecx
 29e3d17:	jb     29fbc8f <wasm[0]::function[1015]::helper::object_read+0x1ad6f>
 29e3d1d:	add    %ecx,%eax
 29e3d1f:	jb     29fbc91 <wasm[0]::function[1015]::helper::object_read+0x1ad71>
 29e3d25:	mov    %eax,%r10d
 29e3d28:	add    %r10,%rdi
 29e3d2b:	cmp    %rsi,%r10
 29e3d2e:	cmova  %r8,%rdi
 29e3d32:	shl    $0x3,%edx
 29e3d35:	lea    0x18(%rdx),%r11d
 29e3d39:	sub    %r11d,%ecx
 29e3d3c:	sub    %rcx,%rdi
 29e3d3f:	mov    (%rdi),%r11
 29e3d42:	bt     %r14,%r11
 29e3d46:	jae    29e3e58 <wasm[0]::function[1015]::helper::object_read+0x2f38>
 29e3d4c:	mov    0x278(%rsp),%rbx
 29e3d54:	jmp    29e3e58 <wasm[0]::function[1015]::helper::object_read+0x2f38>
 29e3d59:	mov    0x78(%rsp),%edx
 29e3d5d:	xor    %ebx,%ebx
 29e3d5f:	test   %edx,%edx
 29e3d61:	je     29fbc93 <wasm[0]::function[1015]::helper::object_read+0x1ad73>
 29e3d67:	test   %edx,%edx
 29e3d69:	je     29fbc95 <wasm[0]::function[1015]::helper::object_read+0x1ad75>
 29e3d6f:	mov    0x2e0(%rsp),%r12
 29e3d77:	mov    0x28(%r12),%rax
 29e3d7c:	mov    0x20(%r12),%rcx
 29e3d81:	mov    %edx,%edi
 29e3d83:	lea    (%rcx,%rdi,1),%rsi
 29e3d87:	xor    %rdx,%rdx
 29e3d8a:	cmp    %rax,%rdi
 29e3d8d:	cmova  %rdx,%rsi
 29e3d91:	mov    0x30(%rsi),%esi
 29e3d94:	test   %esi,%esi
 29e3d96:	je     29fbc97 <wasm[0]::function[1015]::helper::object_read+0x1ad77>
 29e3d9c:	test   %esi,%esi
 29e3d9e:	je     29fbc99 <wasm[0]::function[1015]::helper::object_read+0x1ad79>
 29e3da4:	mov    %esi,%r8d
 29e3da7:	lea    0x10(%rcx,%r8,1),%rcx
 29e3dac:	cmp    %rax,%r8
 29e3daf:	cmova  %rdx,%rcx
 29e3db3:	mov    0x1e0(%rsp),%r14
 29e3dbb:	mov    %r14d,%eax
 29e3dbe:	mov    (%rcx),%ecx
 29e3dc0:	cmp    %rcx,%rax
 29e3dc3:	jae    29e3e58 <wasm[0]::function[1015]::helper::object_read+0x2f38>
 29e3dc9:	mov    0x2e0(%rsp),%r12
 29e3dd1:	mov    0x28(%r12),%rax
 29e3dd6:	mov    0x20(%r12),%rdi
 29e3ddb:	lea    0x10(%rdi,%r8,1),%rdx
 29e3de0:	xor    %rcx,%rcx
 29e3de3:	cmp    %rax,%r8
 29e3de6:	cmova  %rcx,%rdx
 29e3dea:	mov    (%rdx),%edx
 29e3dec:	mov    0x1e0(%rsp),%r14
 29e3df4:	cmp    %edx,%r14d
 29e3df7:	jae    29fbc9b <wasm[0]::function[1015]::helper::object_read+0x1ad7b>
 29e3dfd:	mov    %edx,%r8d
 29e3e00:	shl    $0x2,%r8
 29e3e04:	shr    $0x20,%r8
 29e3e08:	test   %r8,%r8
 29e3e0b:	jne    29fbc9d <wasm[0]::function[1015]::helper::object_read+0x1ad7d>
 29e3e11:	shl    $0x2,%edx
 29e3e14:	add    $0x14,%edx
 29e3e17:	jb     29fbc9f <wasm[0]::function[1015]::helper::object_read+0x1ad7f>
 29e3e1d:	add    %edx,%esi
 29e3e1f:	jb     29fbca1 <wasm[0]::function[1015]::helper::object_read+0x1ad81>
 29e3e25:	mov    %esi,%r8d
 29e3e28:	lea    (%rdi,%r8,1),%rsi
 29e3e2c:	cmp    %rax,%r8
 29e3e2f:	cmova  %rcx,%rsi
 29e3e33:	mov    %r14,%rax
 29e3e36:	shl    $0x2,%eax
 29e3e39:	add    $0x14,%eax
 29e3e3f:	sub    %eax,%edx
 29e3e41:	sub    %rdx,%rsi
 29e3e44:	mov    (%rsi),%eax
 29e3e46:	xor    %ebx,%ebx
 29e3e48:	test   %eax,%eax
 29e3e4a:	je     29e3e58 <wasm[0]::function[1015]::helper::object_read+0x2f38>
 29e3e50:	mov    0x278(%rsp),%rbx
 29e3e58:	mov    0x78(%rsp),%r11d
 29e3e5d:	mov    0xa0(%rsp),%edx
 29e3e64:	mov    0x48(%rsp),%ecx
 29e3e68:	mov    %rcx,0x1e8(%rsp)
 29e3e70:	mov    0x80(%rsp),%esi
 29e3e77:	mov    %rsi,0x1f0(%rsp)
 29e3e7f:	mov    0xa8(%rsp),%edi
 29e3e86:	mov    %rdi,0x1f8(%rsp)
 29e3e8e:	mov    0xb8(%rsp),%edi
 29e3e95:	mov    0x58(%rsp),%r8d
 29e3e9a:	mov    0xc0(%rsp),%r9d
 29e3ea2:	mov    0xe0(%rsp),%r10d
 29e3eaa:	test   %ebx,%ebx
 29e3eac:	je     29e4dd2 <wasm[0]::function[1015]::helper::object_read+0x3eb2>
 29e3eb2:	mov    0x78(%rsp),%eax
 29e3eb6:	test   %eax,%eax
 29e3eb8:	je     29fbca3 <wasm[0]::function[1015]::helper::object_read+0x1ad83>
 29e3ebe:	test   %eax,%eax
 29e3ec0:	je     29fbca5 <wasm[0]::function[1015]::helper::object_read+0x1ad85>
 29e3ec6:	mov    0x2e0(%rsp),%r12
 29e3ece:	mov    0x28(%r12),%rcx
 29e3ed3:	mov    %eax,%edx
 29e3ed5:	mov    %rdx,%rax
 29e3ed8:	add    0x20(%r12),%rax
 29e3edd:	xor    %rsi,%rsi
 29e3ee0:	cmp    %rcx,%rdx
 29e3ee3:	cmova  %rsi,%rax
 29e3ee7:	mov    0x24(%rax),%eax
 29e3eea:	cmp    $0x3,%eax
 29e3eed:	je     29e4761 <wasm[0]::function[1015]::helper::object_read+0x3841>
 29e3ef3:	mov    0x78(%rsp),%r11d
 29e3ef8:	test   %r11d,%r11d
 29e3efb:	je     29fbca7 <wasm[0]::function[1015]::helper::object_read+0x1ad87>
 29e3f01:	test   %r11d,%r11d
 29e3f04:	je     29fbca9 <wasm[0]::function[1015]::helper::object_read+0x1ad89>
 29e3f0a:	mov    0x2e0(%rsp),%r12
 29e3f12:	mov    0x28(%r12),%rax
 29e3f17:	mov    %r11d,%edx
 29e3f1a:	mov    %rdx,%rcx
 29e3f1d:	add    0x20(%r12),%rcx
 29e3f22:	xor    %rsi,%rsi
 29e3f25:	cmp    %rax,%rdx
 29e3f28:	cmova  %rsi,%rcx
 29e3f2c:	mov    0x24(%rcx),%eax
 29e3f2f:	mov    0xa0(%rsp),%edx
 29e3f36:	mov    0x48(%rsp),%ecx
 29e3f3a:	mov    %rcx,0x1e8(%rsp)
 29e3f42:	mov    0x80(%rsp),%esi
 29e3f49:	mov    %rsi,0x1f0(%rsp)
 29e3f51:	mov    0xa8(%rsp),%edi
 29e3f58:	mov    %rdi,0x1f8(%rsp)
 29e3f60:	mov    0xb8(%rsp),%edi
 29e3f67:	mov    0x58(%rsp),%r8d
 29e3f6c:	mov    0xc0(%rsp),%r9d
 29e3f74:	mov    0xe0(%rsp),%r10d
 29e3f7c:	cmp    $0x2,%eax
 29e3f7f:	jne    29e4dd2 <wasm[0]::function[1015]::helper::object_read+0x3eb2>
 29e3f85:	mov    0x78(%rsp),%eax
 29e3f89:	test   %eax,%eax
 29e3f8b:	je     29fbcab <wasm[0]::function[1015]::helper::object_read+0x1ad8b>
 29e3f91:	test   %eax,%eax
 29e3f93:	je     29fbcad <wasm[0]::function[1015]::helper::object_read+0x1ad8d>
 29e3f99:	mov    0x2e0(%rsp),%r12
 29e3fa1:	mov    0x28(%r12),%rsi
 29e3fa6:	mov    0x20(%r12),%rdi
 29e3fab:	mov    %eax,%r9d
 29e3fae:	lea    (%rdi,%r9,1),%rax
 29e3fb2:	xor    %r8,%r8
 29e3fb5:	cmp    %rsi,%r9
 29e3fb8:	cmova  %r8,%rax
 29e3fbc:	mov    0x28(%rax),%r9d
 29e3fc0:	mov    %r9d,0xe8(%rsp)
 29e3fc8:	mov    0x2c(%rax),%r10d
 29e3fcc:	mov    %r10d,0x88(%rsp)
 29e3fd4:	test   %r9d,%r9d
 29e3fd7:	je     29fbcaf <wasm[0]::function[1015]::helper::object_read+0x1ad8f>
 29e3fdd:	test   %r9d,%r9d
 29e3fe0:	je     29fbcb1 <wasm[0]::function[1015]::helper::object_read+0x1ad91>
 29e3fe6:	mov    %r9d,%r10d
 29e3fe9:	lea    0x10(%rdi,%r10,1),%r9
 29e3fee:	cmp    %rsi,%r10
 29e3ff1:	cmova  %r8,%r9
 29e3ff5:	mov    (%r9),%r11d
 29e3ff8:	mov    %r11d,%r15d
 29e3ffb:	mov    %r15,%r14
 29e3ffe:	shl    $0x2,%r14
 29e4002:	mov    $0x20,%eax
 29e4007:	mov    %rax,0x238(%rsp)
 29e400f:	mov    %r14,%rax
 29e4012:	shr    $0x20,%rax
 29e4016:	test   %rax,%rax
 29e4019:	jne    29fbcb3 <wasm[0]::function[1015]::helper::object_read+0x1ad93>
 29e401f:	mov    %r11,%rcx
 29e4022:	shl    $0x2,%ecx
 29e4025:	mov    %r11,0x240(%rsp)
 29e402d:	add    $0x14,%ecx
 29e4030:	jb     29fbcb5 <wasm[0]::function[1015]::helper::object_read+0x1ad95>
 29e4036:	mov    0x190(%rsp),%rax
 29e403e:	mov    0x20(%rax),%rdi
 29e4042:	mov    (%rdi),%eax
 29e4044:	mov    %eax,%edx
 29e4046:	mov    %ecx,%esi
 29e4048:	add    $0xf,%rsi
 29e404f:	mov    %rsi,%r8
 29e4052:	and    $0xfffffffffffffff0,%r8
 29e4056:	add    %rdx,%r8
 29e4059:	mov    0x4(%rdi),%r9d
 29e405d:	mov    %rdi,0x230(%rsp)
 29e4065:	cmp    %r9,%r8
 29e4068:	ja     29fa58d <wasm[0]::function[1015]::helper::object_read+0x1966d>
 29e406e:	add    $0xf,%ecx
 29e4074:	and    $0xfffffff0,%ecx
 29e4077:	add    %eax,%ecx
 29e4079:	mov    0x230(%rsp),%r12
 29e4081:	mov    %ecx,(%r12)
 29e4085:	mov    0x2e0(%rsp),%r12
 29e408d:	mov    0x20(%r12),%rdi
 29e4092:	lea    (%rdi,%rdx,1),%rcx
 29e4096:	movl   $0xa800000e,(%rdi,%rdx,1)
 29e409d:	mov    0x190(%rsp),%r8
 29e40a5:	mov    0x28(%r8),%r8
 29e40a9:	mov    0x194(%r8),%r8d
 29e40b0:	mov    %r8d,0x4(%rdi,%rdx,1)
 29e40b5:	and    $0xfffffffffffffff0,%rsi
 29e40b9:	mov    %esi,0x8(%rdi,%rdx,1)
 29e40bd:	mov    %eax,0xb0(%rsp)
 29e40c4:	mov    0x240(%rsp),%rdx
 29e40cc:	mov    %edx,0x10(%rcx)
 29e40cf:	test   %eax,%eax
 29e40d1:	je     29fbcb7 <wasm[0]::function[1015]::helper::object_read+0x1ad97>
 29e40d7:	mov    0x2e0(%rsp),%r12
 29e40df:	mov    0x28(%r12),%rcx
 29e40e4:	mov    0x20(%r12),%rdx
 29e40e9:	mov    %eax,%esi
 29e40eb:	lea    (%rdx,%rsi,1),%rax
 29e40ef:	lea    0x10(%rdx,%rsi,1),%rdi
 29e40f4:	xor    %r8,%r8
 29e40f7:	cmp    %rcx,%rsi
 29e40fa:	cmova  %r8,%rdi
 29e40fe:	mov    (%rdi),%edi
 29e4100:	cmp    %rdi,%r15
 29e4103:	ja     29fbcb9 <wasm[0]::function[1015]::helper::object_read+0x1ad99>
 29e4109:	lea    0x14(%rdx,%rsi,1),%r13
 29e410e:	mov    %r13,%rsi
 29e4111:	add    %r14,%rsi
 29e4114:	jb     29fbcbb <wasm[0]::function[1015]::helper::object_read+0x1ad9b>
 29e411a:	add    %rdx,%rcx
 29e411d:	cmp    %rcx,%rsi
 29e4120:	ja     29fbcbd <wasm[0]::function[1015]::helper::object_read+0x1ad9d>
 29e4126:	mov    0x88(%rsp),%r12d
 29e412e:	mov    0xe8(%rsp),%ebx
 29e4135:	mov    0x78(%rsp),%esi
 29e4139:	mov    0xa0(%rsp),%edi
 29e4140:	mov    0x48(%rsp),%r9d
 29e4145:	mov    0x80(%rsp),%r11d
 29e414d:	mov    0xa8(%rsp),%ecx
 29e4154:	mov    0xb8(%rsp),%edx
 29e415b:	mov    0x58(%rsp),%r8d
 29e4160:	mov    0xc0(%rsp),%r10d
 29e4168:	mov    0xe0(%rsp),%r14d
 29e4170:	lea    0x14(%rax,%r15,4),%rax
 29e4175:	mov    %rax,0x220(%rsp)
 29e417d:	test   %r15,%r15
 29e4180:	je     29e4275 <wasm[0]::function[1015]::helper::object_read+0x3355>
 29e4186:	mov    %r12d,0x130(%rsp)
 29e418e:	mov    %ebx,0x148(%rsp)
 29e4195:	mov    %esi,0x118(%rsp)
 29e419c:	mov    %edi,0x98(%rsp)
 29e41a3:	mov    %r9d,0x140(%rsp)
 29e41ab:	mov    %r11d,0xd0(%rsp)
 29e41b3:	mov    %ecx,0x100(%rsp)
 29e41ba:	mov    %edx,0x120(%rsp)
 29e41c1:	mov    %r8d,0x110(%rsp)
 29e41c9:	mov    %r10d,0xe8(%rsp)
 29e41d1:	mov    %r14d,0x88(%rsp)
 29e41d9:	mov    0x2e8(%rsp),%r15
 29e41e1:	mov    (%r15),%rcx
 29e41e4:	mov    0x228(%rsp),%rax
 29e41ec:	cmp    %rax,%rcx
 29e41ef:	jae    29fa5c3 <wasm[0]::function[1015]::helper::object_read+0x196a3>
 29e41f5:	movl   $0x0,0x0(%r13)
 29e41fd:	mov    0x130(%rsp),%r12d
 29e4205:	mov    0x148(%rsp),%ebx
 29e420c:	mov    0x118(%rsp),%esi
 29e4213:	mov    0x98(%rsp),%edi
 29e421a:	mov    0x140(%rsp),%r9d
 29e4222:	mov    0xd0(%rsp),%r11d
 29e422a:	mov    0x100(%rsp),%ecx
 29e4231:	mov    0x120(%rsp),%edx
 29e4238:	mov    0x110(%rsp),%r8d
 29e4240:	mov    0xe8(%rsp),%r10d
 29e4248:	mov    0x88(%rsp),%r14d
 29e4250:	add    $0x4,%r13
 29e4257:	mov    0x220(%rsp),%r15
 29e425f:	cmp    %r15,%r13
 29e4262:	je     29e4275 <wasm[0]::function[1015]::helper::object_read+0x3355>
 29e4268:	mov    %r15,0x220(%rsp)
 29e4270:	jmp    29e4186 <wasm[0]::function[1015]::helper::object_read+0x3266>
 29e4275:	mov    %r12d,0x148(%rsp)
 29e427d:	mov    %ebx,0x130(%rsp)
 29e4284:	xor    %r13d,%r13d
 29e4287:	mov    0x190(%rsp),%rax
 29e428f:	mov    0x28(%rax),%rax
 29e4293:	mov    0x120(%rax),%r15d
 29e429a:	mov    %r15,0x220(%rsp)
 29e42a2:	mov    $0x10,%r15d
 29e42a8:	mov    %r15,0x218(%rsp)
 29e42b0:	mov    0x13c(%rax),%ebx
 29e42b6:	mov    %rbx,0x1d8(%rsp)
 29e42be:	mov    %esi,0x88(%rsp)
 29e42c5:	mov    %edi,0xe8(%rsp)
 29e42cc:	mov    %r9d,0x110(%rsp)
 29e42d4:	mov    %r11d,0x120(%rsp)
 29e42dc:	mov    %ecx,0x100(%rsp)
 29e42e3:	mov    %edx,0xd0(%rsp)
 29e42ea:	mov    %r8d,0x140(%rsp)
 29e42f2:	mov    %r10d,0x98(%rsp)
 29e42fa:	mov    %r14d,0x118(%rsp)
 29e4302:	mov    0x2e8(%rsp),%r15
 29e430a:	mov    (%r15),%r8
 29e430d:	mov    0x228(%rsp),%rax
 29e4315:	cmp    %rax,%r8
 29e4318:	jae    29fa5fb <wasm[0]::function[1015]::helper::object_read+0x196db>
 29e431e:	mov    0x240(%rsp),%rcx
 29e4326:	jmp    29e4333 <wasm[0]::function[1015]::helper::object_read+0x3413>
 29e432b:	mov    0x240(%rsp),%rcx
 29e4333:	cmp    %ecx,%r13d
 29e4336:	jae    29e4683 <wasm[0]::function[1015]::helper::object_read+0x3763>
 29e433c:	mov    0x148(%rsp),%edx
 29e4343:	test   %edx,%edx
 29e4345:	je     29fbcbf <wasm[0]::function[1015]::helper::object_read+0x1ad9f>
 29e434b:	test   %edx,%edx
 29e434d:	je     29fbcc1 <wasm[0]::function[1015]::helper::object_read+0x1ada1>
 29e4353:	mov    0x2e0(%rsp),%r12
 29e435b:	mov    0x28(%r12),%rax
 29e4360:	mov    0x20(%r12),%rcx
 29e4365:	mov    %edx,%r8d
 29e4368:	lea    0x10(%rcx,%r8,1),%rdi
 29e436d:	xor    %rsi,%rsi
 29e4370:	cmp    %rax,%r8
 29e4373:	cmova  %rsi,%rdi
 29e4377:	mov    (%rdi),%r9d
 29e437a:	mov    %r13,%rdi
 29e437d:	shr    $0x6,%edi
 29e4380:	cmp    %r9d,%edi
 29e4383:	jae    29fbcc3 <wasm[0]::function[1015]::helper::object_read+0x1ada3>
 29e4389:	mov    %r9d,%r8d
 29e438c:	shl    $0x3,%r8
 29e4390:	shr    $0x20,%r8
 29e4394:	test   %r8,%r8
 29e4397:	jne    29fbcc5 <wasm[0]::function[1015]::helper::object_read+0x1ada5>
 29e439d:	shl    $0x3,%r9d
 29e43a1:	add    $0x18,%r9d
 29e43a5:	jb     29fbcc7 <wasm[0]::function[1015]::helper::object_read+0x1ada7>
 29e43ab:	add    %r9d,%edx
 29e43ae:	jb     29fbcc9 <wasm[0]::function[1015]::helper::object_read+0x1ada9>
 29e43b4:	mov    %edx,%edx
 29e43b6:	add    %rdx,%rcx
 29e43b9:	cmp    %rax,%rdx
 29e43bc:	cmova  %rsi,%rcx
 29e43c0:	shl    $0x3,%edi
 29e43c3:	lea    0x18(%rdi),%eax
 29e43c6:	sub    %eax,%r9d
 29e43c9:	sub    %r9,%rcx
 29e43cc:	mov    (%rcx),%rax
 29e43cf:	bt     %r13,%rax
 29e43d3:	jb     29e43ee <wasm[0]::function[1015]::helper::object_read+0x34ce>
 29e43d9:	mov    0x230(%rsp),%rbx
 29e43e1:	mov    0x1d8(%rsp),%r15
 29e43e9:	jmp    29e4623 <wasm[0]::function[1015]::helper::object_read+0x3703>
 29e43ee:	mov    0x130(%rsp),%eax
 29e43f5:	test   %eax,%eax
 29e43f7:	je     29fbccb <wasm[0]::function[1015]::helper::object_read+0x1adab>
 29e43fd:	test   %eax,%eax
 29e43ff:	je     29fbccd <wasm[0]::function[1015]::helper::object_read+0x1adad>
 29e4405:	mov    0x2e0(%rsp),%r12
 29e440d:	mov    0x28(%r12),%rcx
 29e4412:	mov    0x20(%r12),%rdx
 29e4417:	mov    %eax,%r8d
 29e441a:	lea    0x10(%rdx,%r8,1),%rdi
 29e441f:	xor    %rsi,%rsi
 29e4422:	cmp    %rcx,%r8
 29e4425:	cmova  %rsi,%rdi
 29e4429:	mov    (%rdi),%edi
 29e442b:	cmp    %edi,%r13d
 29e442e:	jae    29fbccf <wasm[0]::function[1015]::helper::object_read+0x1adaf>
 29e4434:	mov    %edi,%r8d
 29e4437:	shl    $0x3,%r8
 29e443b:	shr    $0x20,%r8
 29e443f:	test   %r8,%r8
 29e4442:	jne    29fbcd1 <wasm[0]::function[1015]::helper::object_read+0x1adb1>
 29e4448:	shl    $0x3,%edi
 29e444b:	add    $0x18,%edi
 29e444e:	jb     29fbcd3 <wasm[0]::function[1015]::helper::object_read+0x1adb3>
 29e4454:	add    %edi,%eax
 29e4456:	jb     29fbcd5 <wasm[0]::function[1015]::helper::object_read+0x1adb5>
 29e445c:	mov    %eax,%r8d
 29e445f:	lea    (%rdx,%r8,1),%rax
 29e4463:	cmp    %rcx,%r8
 29e4466:	cmova  %rsi,%rax
 29e446a:	mov    %r13,%rcx
 29e446d:	shl    $0x3,%ecx
 29e4470:	add    $0x18,%ecx
 29e4476:	sub    %ecx,%edi
 29e4478:	sub    %rdi,%rax
 29e447b:	mov    (%rax),%r12
 29e447e:	movl   $0x0,0xf0(%rsp)
 29e4489:	mov    0x230(%rsp),%rbx
 29e4491:	mov    (%rbx),%eax
 29e4493:	mov    %eax,%edx
 29e4495:	lea    0x20(%rdx),%rcx
 29e4499:	mov    0x4(%rbx),%esi
 29e449c:	cmp    %rsi,%rcx
 29e449f:	ja     29fa63b <wasm[0]::function[1015]::helper::object_read+0x1971b>
 29e44a5:	lea    0x20(%rax),%ecx
 29e44a8:	mov    %ecx,(%rbx)
 29e44aa:	mov    0x2e0(%rsp),%rcx
 29e44b2:	mov    0x20(%rcx),%rsi
 29e44b6:	lea    (%rsi,%rdx,1),%rcx
 29e44ba:	movl   $0xb0000042,(%rsi,%rdx,1)
 29e44c1:	mov    0x220(%rsp),%rdi
 29e44c9:	mov    %edi,0x4(%rsi,%rdx,1)
 29e44cd:	mov    0x238(%rsp),%rdi
 29e44d5:	mov    %edi,0x8(%rsi,%rdx,1)
 29e44d9:	mov    %eax,0xd8(%rsp)
 29e44e0:	mov    %r12,0x10(%rcx)
 29e44e4:	movl   $0x3,0x18(%rcx)
 29e44eb:	mov    0xf0(%rsp),%edx
 29e44f2:	mov    %edx,0x1c(%rcx)
 29e44f5:	mov    0x190(%rsp),%rcx
 29e44fd:	mov    0xa20(%rcx),%ecx
 29e4503:	mov    %ecx,0xf0(%rsp)
 29e450a:	test   %eax,%eax
 29e450c:	je     29fbcd7 <wasm[0]::function[1015]::helper::object_read+0x1adb7>
 29e4512:	test   %ecx,%ecx
 29e4514:	je     29fbcd9 <wasm[0]::function[1015]::helper::object_read+0x1adb9>
 29e451a:	mov    (%rbx),%eax
 29e451c:	mov    %eax,%ecx
 29e451e:	lea    0x20(%rcx),%rdx
 29e4522:	mov    0x4(%rbx),%esi
 29e4525:	cmp    %rsi,%rdx
 29e4528:	ja     29fa675 <wasm[0]::function[1015]::helper::object_read+0x19755>
 29e452e:	mov    0x1d8(%rsp),%r15
 29e4536:	lea    0x20(%rax),%edx
 29e4539:	mov    %edx,(%rbx)
 29e453b:	mov    0x2e0(%rsp),%r12
 29e4543:	mov    0x20(%r12),%rsi
 29e4548:	lea    (%rsi,%rcx,1),%rdx
 29e454c:	movl   $0xb0000072,(%rsi,%rcx,1)
 29e4553:	mov    %r15d,0x4(%rsi,%rcx,1)
 29e4558:	mov    0x238(%rsp),%rdi
 29e4560:	mov    %edi,0x8(%rsi,%rcx,1)
 29e4564:	movl   $0xe,0x10(%rdx)
 29e456b:	mov    0xd8(%rsp),%r8d
 29e4573:	mov    %r8d,0x14(%rdx)
 29e4577:	mov    0xf0(%rsp),%r9d
 29e457f:	mov    %r9d,0x18(%rdx)
 29e4583:	mov    %r9d,0x1c(%rdx)
 29e4587:	mov    0xb0(%rsp),%ecx
 29e458e:	test   %ecx,%ecx
 29e4590:	je     29fbcdb <wasm[0]::function[1015]::helper::object_read+0x1adbb>
 29e4596:	test   %eax,%eax
 29e4598:	je     29fbcdd <wasm[0]::function[1015]::helper::object_read+0x1adbd>
 29e459e:	test   %ecx,%ecx
 29e45a0:	je     29fbcdf <wasm[0]::function[1015]::helper::object_read+0x1adbf>
 29e45a6:	mov    0x2e0(%rsp),%r12
 29e45ae:	mov    0x28(%r12),%rdx
 29e45b3:	mov    0x20(%r12),%rsi
 29e45b8:	mov    %ecx,%r9d
 29e45bb:	lea    0x10(%rsi,%r9,1),%r8
 29e45c0:	xor    %rdi,%rdi
 29e45c3:	cmp    %rdx,%r9
 29e45c6:	cmova  %rdi,%r8
 29e45ca:	mov    (%r8),%r8d
 29e45cd:	cmp    %r8d,%r13d
 29e45d0:	jae    29fbce1 <wasm[0]::function[1015]::helper::object_read+0x1adc1>
 29e45d6:	mov    %r8d,%r9d
 29e45d9:	shl    $0x2,%r9
 29e45dd:	shr    $0x20,%r9
 29e45e1:	test   %r9,%r9
 29e45e4:	jne    29fbce3 <wasm[0]::function[1015]::helper::object_read+0x1adc3>
 29e45ea:	shl    $0x2,%r8d
 29e45ee:	add    $0x14,%r8d
 29e45f2:	jb     29fbce5 <wasm[0]::function[1015]::helper::object_read+0x1adc5>
 29e45f8:	add    %r8d,%ecx
 29e45fb:	jb     29fbce7 <wasm[0]::function[1015]::helper::object_read+0x1adc7>
 29e4601:	mov    %ecx,%r9d
 29e4604:	lea    (%rsi,%r9,1),%rcx
 29e4608:	cmp    %rdx,%r9
 29e460b:	cmova  %rdi,%rcx
 29e460f:	mov    %r13,%rdx
 29e4612:	shl    $0x2,%edx
 29e4615:	add    $0x14,%edx
 29e461b:	sub    %edx,%r8d
 29e461e:	sub    %r8,%rcx
 29e4621:	mov    %eax,(%rcx)
 29e4623:	mov    0x88(%rsp),%esi
 29e462a:	mov    0xe8(%rsp),%edi
 29e4631:	mov    0x110(%rsp),%r9d
 29e4639:	mov    0x120(%rsp),%r11d
 29e4641:	mov    0x100(%rsp),%ecx
 29e4648:	mov    0xd0(%rsp),%edx
 29e464f:	mov    0x140(%rsp),%r8d
 29e4657:	mov    0x98(%rsp),%r10d
 29e465f:	mov    0x118(%rsp),%r14d
 29e4667:	add    $0x1,%r13d
 29e466e:	mov    %r15,0x1d8(%rsp)
 29e4676:	mov    %rbx,0x230(%rsp)
 29e467e:	jmp    29e42be <wasm[0]::function[1015]::helper::object_read+0x339e>
 29e4683:	mov    0x88(%rsp),%r11d
 29e468b:	test   %r11d,%r11d
 29e468e:	je     29fbce9 <wasm[0]::function[1015]::helper::object_read+0x1adc9>
 29e4694:	mov    0xb0(%rsp),%ecx
 29e469b:	test   %ecx,%ecx
 29e469d:	je     29fbceb <wasm[0]::function[1015]::helper::object_read+0x1adcb>
 29e46a3:	test   %r11d,%r11d
 29e46a6:	je     29fbced <wasm[0]::function[1015]::helper::object_read+0x1adcd>
 29e46ac:	mov    0x2e0(%rsp),%r12
 29e46b4:	mov    0x28(%r12),%rdx
 29e46b9:	mov    0x20(%r12),%rax
 29e46be:	mov    %r11d,%esi
 29e46c1:	add    %rsi,%rax
 29e46c4:	xor    %rdi,%rdi
 29e46c7:	cmp    %rdx,%rsi
 29e46ca:	cmova  %rdi,%rax
 29e46ce:	mov    %ecx,0x20(%rax)
 29e46d1:	mov    0x190(%rsp),%rcx
 29e46d9:	mov    0xa00(%rcx),%edx
 29e46df:	mov    0xa10(%rcx),%ecx
 29e46e5:	test   %edx,%edx
 29e46e7:	je     29fbcef <wasm[0]::function[1015]::helper::object_read+0x1adcf>
 29e46ed:	mov    %edx,0x28(%rax)
 29e46f0:	test   %ecx,%ecx
 29e46f2:	je     29fbcf1 <wasm[0]::function[1015]::helper::object_read+0x1add1>
 29e46f8:	mov    %ecx,0x2c(%rax)
 29e46fb:	movl   $0x0,0x30(%rax)
 29e4702:	movl   $0x0,0x24(%rax)
 29e4709:	mov    0xe8(%rsp),%edx
 29e4710:	mov    0x110(%rsp),%ecx
 29e4717:	mov    %rcx,0x1e8(%rsp)
 29e471f:	mov    0x120(%rsp),%esi
 29e4726:	mov    %rsi,0x1f0(%rsp)
 29e472e:	mov    0x100(%rsp),%edi
 29e4735:	mov    %rdi,0x1f8(%rsp)
 29e473d:	mov    0xd0(%rsp),%edi
 29e4744:	mov    0x140(%rsp),%r8d
 29e474c:	mov    0x98(%rsp),%r9d
 29e4754:	mov    0x118(%rsp),%r10d
 29e475c:	jmp    29e4dd2 <wasm[0]::function[1015]::helper::object_read+0x3eb2>
 29e4761:	mov    0x78(%rsp),%edx
 29e4765:	test   %edx,%edx
 29e4767:	je     29fbcf3 <wasm[0]::function[1015]::helper::object_read+0x1add3>
 29e476d:	test   %edx,%edx
 29e476f:	je     29fbcf5 <wasm[0]::function[1015]::helper::object_read+0x1add5>
 29e4775:	mov    0x2e0(%rsp),%r12
 29e477d:	mov    0x28(%r12),%rax
 29e4782:	mov    0x20(%r12),%rcx
 29e4787:	mov    %edx,%edi
 29e4789:	lea    (%rcx,%rdi,1),%rsi
 29e478d:	xor    %rdx,%rdx
 29e4790:	cmp    %rax,%rdi
 29e4793:	cmova  %rdx,%rsi
 29e4797:	mov    0x30(%rsi),%esi
 29e479a:	mov    %esi,0x88(%rsp)
 29e47a1:	test   %esi,%esi
 29e47a3:	je     29fbcf7 <wasm[0]::function[1015]::helper::object_read+0x1add7>
 29e47a9:	test   %esi,%esi
 29e47ab:	je     29fbcf9 <wasm[0]::function[1015]::helper::object_read+0x1add9>
 29e47b1:	mov    %esi,%esi
 29e47b3:	lea    0x10(%rcx,%rsi,1),%rcx
 29e47b8:	cmp    %rax,%rsi
 29e47bb:	cmova  %rdx,%rcx
 29e47bf:	mov    (%rcx),%eax
 29e47c1:	mov    %eax,%ebx
 29e47c3:	mov    %rbx,%r12
 29e47c6:	shl    $0x2,%r12
 29e47ca:	mov    $0x20,%ecx
 29e47cf:	mov    %rcx,0x1d0(%rsp)
 29e47d7:	mov    %r12,%rcx
 29e47da:	shr    $0x20,%rcx
 29e47de:	test   %rcx,%rcx
 29e47e1:	jne    29fbcfb <wasm[0]::function[1015]::helper::object_read+0x1addb>
 29e47e7:	mov    %rax,%rcx
 29e47ea:	shl    $0x2,%ecx
 29e47ed:	mov    %rax,0x1d8(%rsp)
 29e47f5:	add    $0x14,%ecx
 29e47f8:	jb     29fbcfd <wasm[0]::function[1015]::helper::object_read+0x1addd>
 29e47fe:	mov    0x190(%rsp),%rax
 29e4806:	mov    0x20(%rax),%rdi
 29e480a:	mov    (%rdi),%eax
 29e480c:	mov    %eax,%edx
 29e480e:	mov    %ecx,%esi
 29e4810:	add    $0xf,%rsi
 29e4817:	mov    %rsi,%r8
 29e481a:	and    $0xfffffffffffffff0,%r8
 29e481e:	add    %rdx,%r8
 29e4821:	mov    0x4(%rdi),%r9d
 29e4825:	mov    %rdi,0x1c8(%rsp)
 29e482d:	cmp    %r9,%r8
 29e4830:	ja     29fa6b3 <wasm[0]::function[1015]::helper::object_read+0x19793>
 29e4836:	add    $0xf,%ecx
 29e483c:	and    $0xfffffff0,%ecx
 29e483f:	lea    (%rax,%rcx,1),%edi
 29e4842:	mov    0x1c8(%rsp),%rcx
 29e484a:	mov    %edi,(%rcx)
 29e484c:	mov    0x2e0(%rsp),%rcx
 29e4854:	mov    0x20(%rcx),%rdi
 29e4858:	lea    (%rdi,%rdx,1),%rcx
 29e485c:	movl   $0xa800000e,(%rdi,%rdx,1)
 29e4863:	mov    0x190(%rsp),%r8
 29e486b:	mov    0x28(%r8),%r8
 29e486f:	mov    0x194(%r8),%r8d
 29e4876:	mov    %r8d,0x4(%rdi,%rdx,1)
 29e487b:	and    $0xfffffffffffffff0,%rsi
 29e487f:	mov    %esi,0x8(%rdi,%rdx,1)
 29e4883:	mov    %eax,0xe8(%rsp)
 29e488a:	mov    0x1d8(%rsp),%r14
 29e4892:	mov    %r14d,0x10(%rcx)
 29e4896:	test   %eax,%eax
 29e4898:	je     29fbcff <wasm[0]::function[1015]::helper::object_read+0x1addf>
 29e489e:	mov    0x2e0(%rsp),%rcx
 29e48a6:	mov    0x28(%rcx),%r9
 29e48aa:	mov    0x20(%rcx),%r10
 29e48ae:	mov    %eax,%r11d
 29e48b1:	lea    (%r10,%r11,1),%r14
 29e48b5:	lea    0x10(%r10,%r11,1),%rsi
 29e48ba:	xor    %rax,%rax
 29e48bd:	cmp    %r9,%r11
 29e48c0:	cmova  %rax,%rsi
 29e48c4:	mov    (%rsi),%eax
 29e48c6:	cmp    %rax,%rbx
 29e48c9:	ja     29fbd01 <wasm[0]::function[1015]::helper::object_read+0x1ade1>
 29e48cf:	lea    0x14(%r10,%r11,1),%r13
 29e48d4:	mov    %r13,%rax
 29e48d7:	add    %r12,%rax
 29e48da:	jb     29fbd03 <wasm[0]::function[1015]::helper::object_read+0x1ade3>
 29e48e0:	lea    (%r10,%r9,1),%rcx
 29e48e4:	cmp    %rcx,%rax
 29e48e7:	ja     29fbd05 <wasm[0]::function[1015]::helper::object_read+0x1ade5>
 29e48ed:	mov    0x88(%rsp),%ecx
 29e48f4:	mov    0x78(%rsp),%eax
 29e48f8:	mov    0xa0(%rsp),%edx
 29e48ff:	mov    0x48(%rsp),%esi
 29e4903:	mov    0x80(%rsp),%edi
 29e490a:	mov    0xa8(%rsp),%r8d
 29e4912:	mov    0xb8(%rsp),%r9d
 29e491a:	mov    0x58(%rsp),%r10d
 29e491f:	mov    0xc0(%rsp),%r11d
 29e4927:	mov    0xe0(%rsp),%r15d
 29e492f:	lea    0x14(%r14,%rbx,4),%r14
 29e4934:	test   %rbx,%rbx
 29e4937:	je     29e4a01 <wasm[0]::function[1015]::helper::object_read+0x3ae1>
 29e493d:	mov    %ecx,0xb0(%rsp)
 29e4944:	mov    %eax,0x118(%rsp)
 29e494b:	mov    %edx,0x98(%rsp)
 29e4952:	mov    %esi,0x140(%rsp)
 29e4959:	mov    %edi,0xd0(%rsp)
 29e4960:	mov    %r8d,0x100(%rsp)
 29e4968:	mov    %r9d,0x120(%rsp)
 29e4970:	mov    %r10d,0x110(%rsp)
 29e4978:	mov    %r11d,0x78(%rsp)
 29e497d:	mov    %r15d,0x88(%rsp)
 29e4985:	mov    0x2e8(%rsp),%r15
 29e498d:	mov    (%r15),%rax
 29e4990:	mov    0x228(%rsp),%r11
 29e4998:	cmp    %r11,%rax
 29e499b:	jae    29fa6f0 <wasm[0]::function[1015]::helper::object_read+0x197d0>
 29e49a1:	movl   $0x0,0x0(%r13)
 29e49a9:	mov    0xb0(%rsp),%ecx
 29e49b0:	mov    0x118(%rsp),%eax
 29e49b7:	mov    0x98(%rsp),%edx
 29e49be:	mov    0x140(%rsp),%esi
 29e49c5:	mov    0xd0(%rsp),%edi
 29e49cc:	mov    0x100(%rsp),%r8d
 29e49d4:	mov    0x120(%rsp),%r9d
 29e49dc:	mov    0x110(%rsp),%r10d
 29e49e4:	mov    0x78(%rsp),%r11d
 29e49e9:	mov    0x88(%rsp),%r15d
 29e49f1:	add    $0x4,%r13
 29e49f8:	cmp    %r14,%r13
 29e49fb:	jne    29e493d <wasm[0]::function[1015]::helper::object_read+0x3a1d>
 29e4a01:	mov    %ecx,0xb0(%rsp)
 29e4a08:	mov    0x190(%rsp),%rcx
 29e4a10:	mov    0xa20(%rcx),%ecx
 29e4a16:	mov    %ecx,0x118(%rsp)
 29e4a1d:	xor    %r13d,%r13d
 29e4a20:	mov    $0xb0000072,%ecx
 29e4a25:	mov    %rcx,0x1a0(%rsp)
 29e4a2d:	mov    0x190(%rsp),%rcx
 29e4a35:	mov    0x28(%rcx),%rcx
 29e4a39:	mov    0x13c(%rcx),%ebx
 29e4a3f:	mov    $0x20,%ecx
 29e4a44:	mov    %rcx,0x198(%rsp)
 29e4a4c:	mov    $0x10,%ecx
 29e4a51:	mov    %rcx,0x2c8(%rsp)
 29e4a59:	mov    %eax,0x148(%rsp)
 29e4a60:	mov    %edx,0x88(%rsp)
 29e4a67:	mov    %esi,0x78(%rsp)
 29e4a6b:	mov    %edi,0x110(%rsp)
 29e4a72:	mov    %r8d,0x120(%rsp)
 29e4a7a:	mov    %r9d,0x100(%rsp)
 29e4a82:	mov    %r10d,0xd0(%rsp)
 29e4a8a:	mov    %r11d,0x140(%rsp)
 29e4a92:	mov    %r15d,0x98(%rsp)
 29e4a9a:	mov    0x2e8(%rsp),%r15
 29e4aa2:	mov    (%r15),%rax
 29e4aa5:	mov    0x228(%rsp),%rcx
 29e4aad:	cmp    %rcx,%rax
 29e4ab0:	jae    29fa728 <wasm[0]::function[1015]::helper::object_read+0x19808>
 29e4ab6:	mov    0x1d8(%rsp),%rcx
 29e4abe:	jmp    29e4acb <wasm[0]::function[1015]::helper::object_read+0x3bab>
 29e4ac3:	mov    0x1d8(%rsp),%rcx
 29e4acb:	cmp    %ecx,%r13d
 29e4ace:	jae    29e4cfc <wasm[0]::function[1015]::helper::object_read+0x3ddc>
 29e4ad4:	mov    0xb0(%rsp),%eax
 29e4adb:	test   %eax,%eax
 29e4add:	je     29fbd07 <wasm[0]::function[1015]::helper::object_read+0x1ade7>
 29e4ae3:	test   %eax,%eax
 29e4ae5:	je     29fbd09 <wasm[0]::function[1015]::helper::object_read+0x1ade9>
 29e4aeb:	mov    0x2e0(%rsp),%r12
 29e4af3:	mov    0x28(%r12),%rsi
 29e4af8:	mov    0x20(%r12),%rdi
 29e4afd:	mov    %eax,%r9d
 29e4b00:	lea    0x10(%rdi,%r9,1),%rcx
 29e4b05:	xor    %r8,%r8
 29e4b08:	cmp    %rsi,%r9
 29e4b0b:	cmova  %r8,%rcx
 29e4b0f:	mov    (%rcx),%ecx
 29e4b11:	cmp    %ecx,%r13d
 29e4b14:	jae    29fbd0b <wasm[0]::function[1015]::helper::object_read+0x1adeb>
 29e4b1a:	mov    %ecx,%r9d
 29e4b1d:	shl    $0x2,%r9
 29e4b21:	shr    $0x20,%r9
 29e4b25:	test   %r9,%r9
 29e4b28:	jne    29fbd0d <wasm[0]::function[1015]::helper::object_read+0x1aded>
 29e4b2e:	shl    $0x2,%ecx
 29e4b31:	add    $0x14,%ecx
 29e4b34:	jb     29fbd0f <wasm[0]::function[1015]::helper::object_read+0x1adef>
 29e4b3a:	add    %ecx,%eax
 29e4b3c:	jb     29fbd11 <wasm[0]::function[1015]::helper::object_read+0x1adf1>
 29e4b42:	mov    %eax,%r10d
 29e4b45:	add    %r10,%rdi
 29e4b48:	cmp    %rsi,%r10
 29e4b4b:	cmova  %r8,%rdi
 29e4b4f:	mov    %r13,%r15
 29e4b52:	shl    $0x2,%r15d
 29e4b56:	lea    0x14(%r15),%r11d
 29e4b5a:	sub    %r11d,%ecx
 29e4b5d:	sub    %rcx,%rdi
 29e4b60:	mov    (%rdi),%r11d
 29e4b63:	mov    %r11d,0x130(%rsp)
 29e4b6b:	test   %r11d,%r11d
 29e4b6e:	jne    29e4b89 <wasm[0]::function[1015]::helper::object_read+0x3c69>
 29e4b74:	mov    0x1d0(%rsp),%rcx
 29e4b7c:	mov    0x1c8(%rsp),%r14
 29e4b84:	jmp    29e4c9f <wasm[0]::function[1015]::helper::object_read+0x3d7f>
 29e4b89:	test   %r11d,%r11d
 29e4b8c:	je     29fbd13 <wasm[0]::function[1015]::helper::object_read+0x1adf3>
 29e4b92:	mov    0x118(%rsp),%eax
 29e4b99:	test   %eax,%eax
 29e4b9b:	je     29fbd15 <wasm[0]::function[1015]::helper::object_read+0x1adf5>
 29e4ba1:	mov    0x1c8(%rsp),%r14
 29e4ba9:	mov    (%r14),%eax
 29e4bac:	mov    %eax,%esi
 29e4bae:	lea    0x20(%rsi),%rcx
 29e4bb2:	mov    0x4(%r14),%edx
 29e4bb6:	cmp    %rdx,%rcx
 29e4bb9:	ja     29fa76b <wasm[0]::function[1015]::helper::object_read+0x1984b>
 29e4bbf:	lea    0x20(%rax),%ecx
 29e4bc2:	mov    %ecx,(%r14)
 29e4bc5:	mov    0x2e0(%rsp),%r12
 29e4bcd:	mov    0x20(%r12),%rdi
 29e4bd2:	lea    (%rdi,%rsi,1),%rdx
 29e4bd6:	movl   $0xb0000072,(%rdi,%rsi,1)
 29e4bdd:	mov    %ebx,0x4(%rdi,%rsi,1)
 29e4be1:	mov    0x1d0(%rsp),%rcx
 29e4be9:	mov    %ecx,0x8(%rdi,%rsi,1)
 29e4bed:	movl   $0xe,0x10(%rdx)
 29e4bf4:	mov    0x130(%rsp),%esi
 29e4bfb:	mov    %esi,0x14(%rdx)
 29e4bfe:	mov    0x118(%rsp),%esi
 29e4c05:	mov    %esi,0x18(%rdx)
 29e4c08:	mov    %esi,0x1c(%rdx)
 29e4c0b:	mov    0xe8(%rsp),%edx
 29e4c12:	test   %edx,%edx
 29e4c14:	je     29fbd17 <wasm[0]::function[1015]::helper::object_read+0x1adf7>
 29e4c1a:	test   %eax,%eax
 29e4c1c:	je     29fbd19 <wasm[0]::function[1015]::helper::object_read+0x1adf9>
 29e4c22:	test   %edx,%edx
 29e4c24:	je     29fbd1b <wasm[0]::function[1015]::helper::object_read+0x1adfb>
 29e4c2a:	mov    0x2e0(%rsp),%r12
 29e4c32:	mov    0x28(%r12),%rsi
 29e4c37:	mov    0x20(%r12),%rdi
 29e4c3c:	mov    %edx,%r10d
 29e4c3f:	lea    0x10(%rdi,%r10,1),%r9
 29e4c44:	xor    %r8,%r8
 29e4c47:	cmp    %rsi,%r10
 29e4c4a:	cmova  %r8,%r9
 29e4c4e:	mov    (%r9),%r9d
 29e4c51:	cmp    %r9d,%r13d
 29e4c54:	jae    29fbd1d <wasm[0]::function[1015]::helper::object_read+0x1adfd>
 29e4c5a:	mov    %r9d,%r10d
 29e4c5d:	shl    $0x2,%r10
 29e4c61:	shr    $0x20,%r10
 29e4c65:	test   %r10,%r10
 29e4c68:	jne    29fbd1f <wasm[0]::function[1015]::helper::object_read+0x1adff>
 29e4c6e:	shl    $0x2,%r9d
 29e4c72:	add    $0x14,%r9d
 29e4c76:	jb     29fbd21 <wasm[0]::function[1015]::helper::object_read+0x1ae01>
 29e4c7c:	add    %r9d,%edx
 29e4c7f:	jb     29fbd23 <wasm[0]::function[1015]::helper::object_read+0x1ae03>
 29e4c85:	mov    %edx,%r10d
 29e4c88:	lea    (%rdi,%r10,1),%rdx
 29e4c8c:	cmp    %rsi,%r10
 29e4c8f:	cmova  %r8,%rdx
 29e4c93:	lea    0x14(%r15),%esi
 29e4c97:	sub    %esi,%r9d
 29e4c9a:	sub    %r9,%rdx
 29e4c9d:	mov    %eax,(%rdx)
 29e4c9f:	mov    0x148(%rsp),%eax
 29e4ca6:	mov    0x88(%rsp),%edx
 29e4cad:	mov    0x78(%rsp),%esi
 29e4cb1:	mov    0x110(%rsp),%edi
 29e4cb8:	mov    0x120(%rsp),%r8d
 29e4cc0:	mov    0x100(%rsp),%r9d
 29e4cc8:	mov    0xd0(%rsp),%r10d
 29e4cd0:	mov    0x140(%rsp),%r11d
 29e4cd8:	mov    0x98(%rsp),%r15d
 29e4ce0:	add    $0x1,%r13d
 29e4ce7:	mov    %r14,0x1c8(%rsp)
 29e4cef:	mov    %rcx,0x1d0(%rsp)
 29e4cf7:	jmp    29e4a59 <wasm[0]::function[1015]::helper::object_read+0x3b39>
 29e4cfc:	mov    0x148(%rsp),%r11d
 29e4d04:	test   %r11d,%r11d
 29e4d07:	je     29fbd25 <wasm[0]::function[1015]::helper::object_read+0x1ae05>
 29e4d0d:	mov    0xe8(%rsp),%ecx
 29e4d14:	test   %ecx,%ecx
 29e4d16:	je     29fbd27 <wasm[0]::function[1015]::helper::object_read+0x1ae07>
 29e4d1c:	test   %r11d,%r11d
 29e4d1f:	je     29fbd29 <wasm[0]::function[1015]::helper::object_read+0x1ae09>
 29e4d25:	mov    0x2e0(%rsp),%r12
 29e4d2d:	mov    0x28(%r12),%rdx
 29e4d32:	mov    0x20(%r12),%rax
 29e4d37:	mov    %r11d,%esi
 29e4d3a:	add    %rsi,%rax
 29e4d3d:	xor    %rdi,%rdi
 29e4d40:	cmp    %rdx,%rsi
 29e4d43:	cmova  %rdi,%rax
 29e4d47:	mov    %ecx,0x20(%rax)
 29e4d4a:	mov    0x190(%rsp),%rcx
 29e4d52:	mov    0xa00(%rcx),%edx
 29e4d58:	mov    0xa10(%rcx),%ecx
 29e4d5e:	test   %edx,%edx
 29e4d60:	je     29fbd2b <wasm[0]::function[1015]::helper::object_read+0x1ae0b>
 29e4d66:	mov    %edx,0x28(%rax)
 29e4d69:	test   %ecx,%ecx
 29e4d6b:	je     29fbd2d <wasm[0]::function[1015]::helper::object_read+0x1ae0d>
 29e4d71:	mov    %ecx,0x2c(%rax)
 29e4d74:	movl   $0x0,0x30(%rax)
 29e4d7b:	movl   $0x0,0x24(%rax)
 29e4d82:	mov    0x88(%rsp),%edx
 29e4d89:	mov    0x78(%rsp),%ecx
 29e4d8d:	mov    %rcx,0x1e8(%rsp)
 29e4d95:	mov    0x110(%rsp),%esi
 29e4d9c:	mov    %rsi,0x1f0(%rsp)
 29e4da4:	mov    0x120(%rsp),%edi
 29e4dab:	mov    %rdi,0x1f8(%rsp)
 29e4db3:	mov    0x100(%rsp),%edi
 29e4dba:	mov    0xd0(%rsp),%r8d
 29e4dc2:	mov    0x140(%rsp),%r9d
 29e4dca:	mov    0x98(%rsp),%r10d
 29e4dd2:	test   %r11d,%r11d
 29e4dd5:	je     29fbd2f <wasm[0]::function[1015]::helper::object_read+0x1ae0f>
 29e4ddb:	test   %r11d,%r11d
 29e4dde:	je     29fbd31 <wasm[0]::function[1015]::helper::object_read+0x1ae11>
 29e4de4:	mov    0x2e0(%rsp),%r12
 29e4dec:	mov    0x28(%r12),%rax
 29e4df1:	mov    0x20(%r12),%r13
 29e4df6:	mov    %r11d,%r11d
 29e4df9:	lea    0x0(%r13,%r11,1),%r12
 29e4dfe:	xor    %r14,%r14
 29e4e01:	cmp    %rax,%r11
 29e4e04:	cmova  %r14,%r12
 29e4e08:	mov    0x10(%r12),%ebx
 29e4e0d:	test   %ebx,%ebx
 29e4e0f:	je     29fbd33 <wasm[0]::function[1015]::helper::object_read+0x1ae13>
 29e4e15:	test   %ebx,%ebx
 29e4e17:	je     29fbd35 <wasm[0]::function[1015]::helper::object_read+0x1ae15>
 29e4e1d:	mov    %ebx,%ecx
 29e4e1f:	lea    0x10(%r13,%rcx,1),%r13
 29e4e24:	cmp    %rax,%rcx
 29e4e27:	cmova  %r14,%r13
 29e4e2b:	mov    0x0(%r13),%eax
 29e4e2f:	mov    0x24(%r12),%esi
 29e4e34:	test   %esi,%esi
 29e4e36:	je     29e50e5 <wasm[0]::function[1015]::helper::object_read+0x41c5>
 29e4e3c:	xor    %r11d,%r11d
 29e4e3f:	test   %eax,%eax
 29e4e41:	je     29e50d8 <wasm[0]::function[1015]::helper::object_read+0x41b8>
 29e4e47:	mov    0x2e0(%rsp),%r12
 29e4e4f:	mov    0x28(%r12),%r11
 29e4e54:	mov    0x20(%r12),%r14
 29e4e59:	lea    0x10(%r14,%rcx,1),%r13
 29e4e5e:	xor    %r12,%r12
 29e4e61:	cmp    %r11,%rcx
 29e4e64:	cmova  %r12,%r13
 29e4e68:	mov    0x0(%r13),%r13d
 29e4e6c:	mov    0x1e0(%rsp),%r15
 29e4e74:	mov    %r15,%rcx
 29e4e77:	shr    $0x10,%ecx
 29e4e7a:	mov    %r15,%rsi
 29e4e7d:	xor    %ecx,%esi
 29e4e7f:	imul   $0x7feb352d,%esi,%ecx
 29e4e85:	mov    %rcx,%rsi
 29e4e88:	shr    $0xf,%esi
 29e4e8b:	xor    %esi,%ecx
 29e4e8d:	imul   $0x846ca68b,%ecx,%ecx
 29e4e93:	mov    %rcx,%rsi
 29e4e96:	shr    $0x10,%esi
 29e4e99:	xor    %esi,%ecx
 29e4e9b:	sub    $0x1,%eax
 29e4e9e:	and    %eax,%ecx
 29e4ea0:	cmp    %r13d,%ecx
 29e4ea3:	jae    29fbd37 <wasm[0]::function[1015]::helper::object_read+0x1ae17>
 29e4ea9:	mov    %r13d,%eax
 29e4eac:	shl    $0x2,%rax
 29e4eb0:	shr    $0x20,%rax
 29e4eb4:	test   %rax,%rax
 29e4eb7:	jne    29fbd39 <wasm[0]::function[1015]::helper::object_read+0x1ae19>
 29e4ebd:	shl    $0x2,%r13d
 29e4ec1:	add    $0x14,%r13d
 29e4ec5:	jb     29fbd3b <wasm[0]::function[1015]::helper::object_read+0x1ae1b>
 29e4ecb:	add    %r13d,%ebx
 29e4ece:	jb     29fbd3d <wasm[0]::function[1015]::helper::object_read+0x1ae1d>
 29e4ed4:	mov    %ebx,%esi
 29e4ed6:	lea    (%r14,%rsi,1),%rax
 29e4eda:	cmp    %r11,%rsi
 29e4edd:	cmova  %r12,%rax
 29e4ee1:	shl    $0x2,%ecx
 29e4ee4:	add    $0x14,%ecx
 29e4eea:	sub    %ecx,%r13d
 29e4eed:	sub    %r13,%rax
 29e4ef0:	mov    (%rax),%eax
 29e4ef2:	xor    %ecx,%ecx
 29e4ef4:	mov    %r15d,%ebx
 29e4ef7:	mov    %eax,0xe8(%rsp)
 29e4efe:	mov    %ecx,0x98(%rsp)
 29e4f05:	mov    %edx,0x140(%rsp)
 29e4f0c:	mov    0x1e8(%rsp),%rcx
 29e4f14:	mov    %ecx,0xd0(%rsp)
 29e4f1b:	mov    0x1f0(%rsp),%rsi
 29e4f23:	mov    %esi,0x100(%rsp)
 29e4f2a:	mov    0x1f8(%rsp),%rax
 29e4f32:	mov    %eax,0x120(%rsp)
 29e4f39:	mov    %edi,0x110(%rsp)
 29e4f40:	mov    %r8d,0x78(%rsp)
 29e4f45:	mov    %r9d,0x88(%rsp)
 29e4f4d:	mov    %r10d,0x148(%rsp)
 29e4f55:	mov    0x2e8(%rsp),%r15
 29e4f5d:	mov    (%r15),%rax
 29e4f60:	mov    0x228(%rsp),%rcx
 29e4f68:	cmp    %rcx,%rax
 29e4f6b:	jae    29fa7af <wasm[0]::function[1015]::helper::object_read+0x1988f>
 29e4f71:	mov    0xe8(%rsp),%eax
 29e4f78:	mov    0x98(%rsp),%r11d
 29e4f80:	test   %eax,%eax
 29e4f82:	je     29e5088 <wasm[0]::function[1015]::helper::object_read+0x4168>
 29e4f88:	mov    0xe8(%rsp),%ecx
 29e4f8f:	test   %ecx,%ecx
 29e4f91:	je     29fbd3f <wasm[0]::function[1015]::helper::object_read+0x1ae1f>
 29e4f97:	mov    0x2e0(%rsp),%r12
 29e4f9f:	mov    0x28(%r12),%rax
 29e4fa4:	mov    %ecx,%edx
 29e4fa6:	mov    %rdx,%rcx
 29e4fa9:	add    0x20(%r12),%rcx
 29e4fae:	xor    %rsi,%rsi
 29e4fb1:	cmp    %rax,%rdx
 29e4fb4:	cmova  %rsi,%rcx
 29e4fb8:	mov    0x10(%rcx),%rax
 29e4fbc:	cmp    %rbx,%rax
 29e4fbf:	je     29e5054 <wasm[0]::function[1015]::helper::object_read+0x4134>
 29e4fc5:	mov    0xe8(%rsp),%ecx
 29e4fcc:	test   %ecx,%ecx
 29e4fce:	je     29fbd41 <wasm[0]::function[1015]::helper::object_read+0x1ae21>
 29e4fd4:	mov    0x2e0(%rsp),%r12
 29e4fdc:	mov    0x28(%r12),%rax
 29e4fe1:	mov    %ecx,%edx
 29e4fe3:	mov    %rdx,%rcx
 29e4fe6:	add    0x20(%r12),%rcx
 29e4feb:	xor    %rsi,%rsi
 29e4fee:	cmp    %rax,%rdx
 29e4ff1:	cmova  %rsi,%rcx
 29e4ff5:	mov    0x1c(%rcx),%eax
 29e4ff8:	mov    0x98(%rsp),%ecx
 29e4fff:	mov    0x140(%rsp),%edx
 29e5006:	mov    0xd0(%rsp),%esi
 29e500d:	mov    %rsi,0x1e8(%rsp)
 29e5015:	mov    0x100(%rsp),%esi
 29e501c:	mov    %rsi,0x1f0(%rsp)
 29e5024:	mov    0x120(%rsp),%edi
 29e502b:	mov    %rdi,0x1f8(%rsp)
 29e5033:	mov    0x110(%rsp),%edi
 29e503a:	mov    0x78(%rsp),%r8d
 29e503f:	mov    0x88(%rsp),%r9d
 29e5047:	mov    0x148(%rsp),%r10d
 29e504f:	jmp    29e4ef7 <wasm[0]::function[1015]::helper::object_read+0x3fd7>
 29e5054:	mov    0xe8(%rsp),%ecx
 29e505b:	test   %ecx,%ecx
 29e505d:	je     29fbd43 <wasm[0]::function[1015]::helper::object_read+0x1ae23>
 29e5063:	mov    0x2e0(%rsp),%r12
 29e506b:	mov    0x28(%r12),%rax
 29e5070:	mov    %ecx,%edx
 29e5072:	mov    %rdx,%rcx
 29e5075:	add    0x20(%r12),%rcx
 29e507a:	xor    %rsi,%rsi
 29e507d:	cmp    %rax,%rdx
 29e5080:	cmova  %rsi,%rcx
 29e5084:	mov    0x18(%rcx),%r11d
 29e5088:	mov    0x140(%rsp),%edx
 29e508f:	mov    0xd0(%rsp),%ecx
 29e5096:	mov    %rcx,0x1e8(%rsp)
 29e509e:	mov    0x100(%rsp),%esi
 29e50a5:	mov    %rsi,0x1f0(%rsp)
 29e50ad:	mov    0x120(%rsp),%edi
 29e50b4:	mov    %rdi,0x1f8(%rsp)
 29e50bc:	mov    0x110(%rsp),%edi
 29e50c3:	mov    0x78(%rsp),%r8d
 29e50c8:	mov    0x88(%rsp),%r9d
 29e50d0:	mov    0x148(%rsp),%r10d
 29e50d8:	mov    0x1e8(%rsp),%rcx
 29e50e0:	jmp    29e51bb <wasm[0]::function[1015]::helper::object_read+0x429b>
 29e50e5:	mov    0x2e0(%rsp),%r12
 29e50ed:	mov    0x1e0(%rsp),%r15
 29e50f5:	mov    0x28(%r12),%rax
 29e50fa:	mov    0x20(%r12),%r12
 29e50ff:	lea    (%r12,%r11,1),%rbx
 29e5103:	xor    %rcx,%rcx
 29e5106:	cmp    %rax,%r11
 29e5109:	cmova  %rcx,%rbx
 29e510d:	mov    0x20(%rbx),%ebx
 29e5110:	xor    %r11d,%r11d
 29e5113:	test   %ebx,%ebx
 29e5115:	je     29fbd45 <wasm[0]::function[1015]::helper::object_read+0x1ae25>
 29e511b:	test   %ebx,%ebx
 29e511d:	je     29fbd47 <wasm[0]::function[1015]::helper::object_read+0x1ae27>
 29e5123:	mov    %ebx,%r13d
 29e5126:	lea    0x10(%r12,%r13,1),%r12
 29e512b:	cmp    %rax,%r13
 29e512e:	cmova  %rcx,%r12
 29e5132:	mov    %r15d,%esi
 29e5135:	mov    (%r12),%eax
 29e5139:	cmp    %rax,%rsi
 29e513c:	jae    29e51b3 <wasm[0]::function[1015]::helper::object_read+0x4293>
 29e5142:	mov    0x2e0(%rsp),%r12
 29e514a:	mov    0x28(%r12),%r11
 29e514f:	mov    0x20(%r12),%r12
 29e5154:	lea    0x10(%r12,%r13,1),%rcx
 29e5159:	xor    %rax,%rax
 29e515c:	cmp    %r11,%r13
 29e515f:	cmova  %rax,%rcx
 29e5163:	mov    (%rcx),%ecx
 29e5165:	cmp    %ecx,%r15d
 29e5168:	jae    29fbd49 <wasm[0]::function[1015]::helper::object_read+0x1ae29>
 29e516e:	mov    %ecx,%r13d
 29e5171:	shl    $0x2,%r13
 29e5175:	shr    $0x20,%r13
 29e5179:	test   %r13,%r13
 29e517c:	jne    29fbd4b <wasm[0]::function[1015]::helper::object_read+0x1ae2b>
 29e5182:	shl    $0x2,%ecx
 29e5185:	add    $0x14,%ecx
 29e5188:	jb     29fbd4d <wasm[0]::function[1015]::helper::object_read+0x1ae2d>
 29e518e:	add    %ecx,%ebx
 29e5190:	jb     29fbd4f <wasm[0]::function[1015]::helper::object_read+0x1ae2f>
 29e5196:	mov    %ebx,%esi
 29e5198:	add    %rsi,%r12
 29e519b:	cmp    %r11,%rsi
 29e519e:	cmova  %rax,%r12
 29e51a2:	shl    $0x2,%r15d
 29e51a6:	lea    0x14(%r15),%eax
 29e51aa:	sub    %eax,%ecx
 29e51ac:	sub    %rcx,%r12
 29e51af:	mov    (%r12),%r11d
 29e51b3:	mov    0x1e8(%rsp),%rcx
 29e51bb:	mov    %ecx,0x88(%rsp)
 29e51c2:	mov    0x1f0(%rsp),%rsi
 29e51ca:	mov    %esi,0x78(%rsp)
 29e51ce:	mov    0x1f8(%rsp),%rax
 29e51d6:	mov    %eax,0x110(%rsp)
 29e51dd:	mov    %edi,0x120(%rsp)
 29e51e4:	mov    %r8d,0x100(%rsp)
 29e51ec:	mov    %r9d,0xd0(%rsp)
 29e51f4:	mov    %r10d,0x140(%rsp)
 29e51fc:	xor    %r10d,%r10d
 29e51ff:	xor    %r9,%r9
 29e5202:	test   %r11d,%r11d
 29e5205:	jne    29e5213 <wasm[0]::function[1015]::helper::object_read+0x42f3>
 29e520b:	mov    %r10,%rcx
 29e520e:	jmp    29e53c6 <wasm[0]::function[1015]::helper::object_read+0x44a6>
 29e5213:	xor    %r10d,%r10d
 29e5216:	test   %r11d,%r11d
 29e5219:	je     29fbd51 <wasm[0]::function[1015]::helper::object_read+0x1ae31>
 29e521f:	test   %r11d,%r11d
 29e5222:	je     29fbd53 <wasm[0]::function[1015]::helper::object_read+0x1ae33>
 29e5228:	mov    0x2e0(%rsp),%r12
 29e5230:	mov    0x28(%r12),%rcx
 29e5235:	mov    %r11d,%eax
 29e5238:	mov    %rax,%rsi
 29e523b:	add    0x20(%r12),%rsi
 29e5240:	xor    %r9,%r9
 29e5243:	cmp    %rcx,%rax
 29e5246:	cmova  %r9,%rsi
 29e524a:	mov    0x10(%rsi),%ecx
 29e524d:	test   $0x1,%ecx
 29e5253:	je     29e5261 <wasm[0]::function[1015]::helper::object_read+0x4341>
 29e5259:	mov    %r10,%rcx
 29e525c:	jmp    29e53c6 <wasm[0]::function[1015]::helper::object_read+0x44a6>
 29e5261:	mov    0x2e0(%rsp),%r12
 29e5269:	mov    0x28(%r12),%rcx
 29e526e:	mov    0x20(%r12),%rdx
 29e5273:	add    %rax,%rdx
 29e5276:	xor    %rsi,%rsi
 29e5279:	cmp    %rcx,%rax
 29e527c:	cmova  %rsi,%rdx
 29e5280:	mov    0x14(%rdx),%edx
 29e5283:	test   %edx,%edx
 29e5285:	je     29fbd55 <wasm[0]::function[1015]::helper::object_read+0x1ae35>
 29e528b:	xor    %eax,%eax
 29e528d:	test   $0x1,%edx
 29e5293:	jne    29e52d6 <wasm[0]::function[1015]::helper::object_read+0x43b6>
 29e5299:	mov    0x2e0(%rsp),%r12
 29e52a1:	mov    0x28(%r12),%rax
 29e52a6:	mov    0x20(%r12),%rcx
 29e52ab:	mov    %edx,%esi
 29e52ad:	lea    0x4(%rcx,%rsi,1),%rcx
 29e52b2:	xor    %rdi,%rdi
 29e52b5:	cmp    %rax,%rsi
 29e52b8:	cmova  %rdi,%rcx
 29e52bc:	mov    (%rcx),%eax
 29e52be:	mov    0x190(%rsp),%rcx
 29e52c6:	mov    0x28(%rcx),%rcx
 29e52ca:	cmp    0x120(%rcx),%eax
 29e52d0:	sete   %al
 29e52d3:	movzbl %al,%eax
 29e52d6:	test   %eax,%eax
 29e52d8:	jne    29e5334 <wasm[0]::function[1015]::helper::object_read+0x4414>
 29e52de:	mov    0x190(%rsp),%rsi
 29e52e6:	mov    0x190(%rsp),%rdi
 29e52ee:	call   2a01ba0 <wasm[0]::function[1024]::helper::property_value_resolve>
 29e52f3:	test   %eax,%eax
 29e52f5:	je     29fbd57 <wasm[0]::function[1015]::helper::object_read+0x1ae37>
 29e52fb:	test   %eax,%eax
 29e52fd:	je     29fbd59 <wasm[0]::function[1015]::helper::object_read+0x1ae39>
 29e5303:	mov    0x2e0(%rsp),%r12
 29e530b:	mov    0x28(%r12),%rcx
 29e5310:	mov    0x20(%r12),%rsi
 29e5315:	mov    %eax,%edx
 29e5317:	lea    (%rsi,%rdx,1),%rax
 29e531b:	xor    %rsi,%rsi
 29e531e:	cmp    %rcx,%rdx
 29e5321:	cmova  %rsi,%rax
 29e5325:	mov    0x18(%rax),%ecx
 29e5328:	mov    0x10(%rax),%r9
 29e532c:	mov    0x1c(%rax),%edx
 29e532f:	jmp    29e53be <wasm[0]::function[1015]::helper::object_read+0x449e>
 29e5334:	xor    %r9d,%r9d
 29e5337:	test   $0x1,%edx
 29e533d:	jne    29e5381 <wasm[0]::function[1015]::helper::object_read+0x4461>
 29e5343:	mov    0x2e0(%rsp),%r12
 29e534b:	mov    0x28(%r12),%rax
 29e5350:	mov    0x20(%r12),%rcx
 29e5355:	mov    %edx,%esi
 29e5357:	lea    0x4(%rcx,%rsi,1),%rcx
 29e535c:	xor    %rdi,%rdi
 29e535f:	cmp    %rax,%rsi
 29e5362:	cmova  %rdi,%rcx
 29e5366:	mov    (%rcx),%eax
 29e5368:	mov    0x190(%rsp),%rcx
 29e5370:	mov    0x28(%rcx),%rcx
 29e5374:	cmp    0x120(%rcx),%eax
 29e537a:	sete   %al
 29e537d:	movzbl %al,%r9d
 29e5381:	test   %r9d,%r9d
 29e5384:	je     29fbd5b <wasm[0]::function[1015]::helper::object_read+0x1ae3b>
 29e538a:	test   %edx,%edx
 29e538c:	je     29fbd5d <wasm[0]::function[1015]::helper::object_read+0x1ae3d>
 29e5392:	mov    0x2e0(%rsp),%r12
 29e539a:	mov    0x28(%r12),%rsi
 29e539f:	mov    0x20(%r12),%r8
 29e53a4:	mov    %edx,%edi
 29e53a6:	lea    (%r8,%rdi,1),%rax
 29e53aa:	xor    %r8,%r8
 29e53ad:	cmp    %rsi,%rdi
 29e53b0:	cmova  %r8,%rax
 29e53b4:	mov    0x18(%rax),%ecx
 29e53b7:	mov    0x10(%rax),%r9
 29e53bb:	mov    0x1c(%rax),%edx
 29e53be:	mov    0x278(%rsp),%r10
 29e53c6:	mov    0x88(%rsp),%eax
 29e53cd:	mov    0x78(%rsp),%edi
 29e53d1:	mov    0x110(%rsp),%r8d
 29e53d9:	mov    0x120(%rsp),%r11d
 29e53e1:	mov    0x100(%rsp),%r12d
 29e53e9:	mov    0xd0(%rsp),%r13d
 29e53f1:	mov    0x140(%rsp),%esi
 29e53f8:	jmp    29e5727 <wasm[0]::function[1015]::helper::object_read+0x4807>
 29e53fd:	mov    0x2e0(%rsp),%r12
 29e5405:	mov    0x1e0(%rsp),%r15
 29e540d:	mov    0x28(%r12),%r8
 29e5412:	mov    %rax,%rsi
 29e5415:	add    0x20(%r12),%rsi
 29e541a:	xor    %r9,%r9
 29e541d:	cmp    %r8,%rax
 29e5420:	cmova  %r9,%rsi
 29e5424:	mov    0x24(%rsi),%r9d
 29e5428:	cmp    $0x3,%r9d
 29e542c:	je     29e55c7 <wasm[0]::function[1015]::helper::object_read+0x46a7>
 29e5432:	mov    0x2e0(%rsp),%r12
 29e543a:	mov    0x28(%r12),%r11
 29e543f:	mov    0x20(%r12),%rdx
 29e5444:	lea    (%rdx,%rax,1),%r8
 29e5448:	xor    %r9,%r9
 29e544b:	cmp    %r11,%rax
 29e544e:	cmova  %r9,%r8
 29e5452:	mov    0x28(%r8),%esi
 29e5456:	mov    0x2c(%r8),%r8d
 29e545a:	xor    %r10d,%r10d
 29e545d:	test   %esi,%esi
 29e545f:	je     29fbd5f <wasm[0]::function[1015]::helper::object_read+0x1ae3f>
 29e5465:	test   %esi,%esi
 29e5467:	je     29fbd61 <wasm[0]::function[1015]::helper::object_read+0x1ae41>
 29e546d:	mov    %esi,%edi
 29e546f:	lea    0x10(%rdx,%rdi,1),%rax
 29e5474:	cmp    %r11,%rdi
 29e5477:	cmova  %r9,%rax
 29e547b:	mov    (%rax),%eax
 29e547d:	mov    0xa0(%rsp),%edx
 29e5484:	mov    %r15d,%r11d
 29e5487:	mov    %eax,%eax
 29e5489:	cmp    %rax,%r11
 29e548c:	jb     29e549a <wasm[0]::function[1015]::helper::object_read+0x457a>
 29e5492:	mov    %r10,%rcx
 29e5495:	jmp    29e56f8 <wasm[0]::function[1015]::helper::object_read+0x47d8>
 29e549a:	xor    %r10d,%r10d
 29e549d:	test   %r8d,%r8d
 29e54a0:	je     29fbd63 <wasm[0]::function[1015]::helper::object_read+0x1ae43>
 29e54a6:	test   %r8d,%r8d
 29e54a9:	je     29fbd65 <wasm[0]::function[1015]::helper::object_read+0x1ae45>
 29e54af:	mov    0x2e0(%rsp),%r12
 29e54b7:	mov    0x28(%r12),%rax
 29e54bc:	mov    0x20(%r12),%rdx
 29e54c1:	mov    %r8d,%ebx
 29e54c4:	lea    0x10(%rdx,%rbx,1),%r11
 29e54c9:	xor    %r9,%r9
 29e54cc:	cmp    %rax,%rbx
 29e54cf:	cmova  %r9,%r11
 29e54d3:	mov    (%r11),%r11d
 29e54d6:	mov    %r15,%rbx
 29e54d9:	shr    $0x6,%ebx
 29e54dc:	cmp    %r11d,%ebx
 29e54df:	jae    29fbd67 <wasm[0]::function[1015]::helper::object_read+0x1ae47>
 29e54e5:	mov    %r11d,%r12d
 29e54e8:	shl    $0x3,%r12
 29e54ec:	shr    $0x20,%r12
 29e54f0:	test   %r12,%r12
 29e54f3:	jne    29fbd69 <wasm[0]::function[1015]::helper::object_read+0x1ae49>
 29e54f9:	shl    $0x3,%r11d
 29e54fd:	add    $0x18,%r11d
 29e5501:	jb     29fbd6b <wasm[0]::function[1015]::helper::object_read+0x1ae4b>
 29e5507:	add    %r11d,%r8d
 29e550a:	jb     29fbd6d <wasm[0]::function[1015]::helper::object_read+0x1ae4d>
 29e5510:	mov    %r8d,%r8d
 29e5513:	add    %r8,%rdx
 29e5516:	cmp    %rax,%r8
 29e5519:	cmova  %r9,%rdx
 29e551d:	shl    $0x3,%ebx
 29e5520:	lea    0x18(%rbx),%eax
 29e5523:	sub    %eax,%r11d
 29e5526:	sub    %r11,%rdx
 29e5529:	mov    (%rdx),%rax
 29e552c:	mov    0xa0(%rsp),%edx
 29e5533:	bt     %r15,%rax
 29e5537:	jb     29e5545 <wasm[0]::function[1015]::helper::object_read+0x4625>
 29e553d:	mov    %r10,%rcx
 29e5540:	jmp    29e56f8 <wasm[0]::function[1015]::helper::object_read+0x47d8>
 29e5545:	mov    0x2e0(%rsp),%r12
 29e554d:	mov    0x28(%r12),%rax
 29e5552:	mov    0x20(%r12),%r8
 29e5557:	lea    0x10(%r8,%rdi,1),%r9
 29e555c:	xor    %rdx,%rdx
 29e555f:	cmp    %rax,%rdi
 29e5562:	cmova  %rdx,%r9
 29e5566:	mov    (%r9),%edi
 29e5569:	cmp    %edi,%r15d
 29e556c:	jae    29fbd6f <wasm[0]::function[1015]::helper::object_read+0x1ae4f>
 29e5572:	mov    %edi,%r9d
 29e5575:	shl    $0x3,%r9
 29e5579:	shr    $0x20,%r9
 29e557d:	test   %r9,%r9
 29e5580:	jne    29fbd71 <wasm[0]::function[1015]::helper::object_read+0x1ae51>
 29e5586:	shl    $0x3,%edi
 29e5589:	add    $0x18,%edi
 29e558c:	jb     29fbd73 <wasm[0]::function[1015]::helper::object_read+0x1ae53>
 29e5592:	add    %edi,%esi
 29e5594:	jb     29fbd75 <wasm[0]::function[1015]::helper::object_read+0x1ae55>
 29e559a:	mov    %esi,%r9d
 29e559d:	lea    (%r8,%r9,1),%rsi
 29e55a1:	cmp    %rax,%r9
 29e55a4:	cmova  %rdx,%rsi
 29e55a8:	shl    $0x3,%r15d
 29e55ac:	lea    0x18(%r15),%eax
 29e55b0:	sub    %eax,%edi
 29e55b2:	sub    %rdi,%rsi
 29e55b5:	mov    (%rsi),%r9
 29e55b8:	xor    %edx,%edx
 29e55ba:	mov    0x278(%rsp),%r10
 29e55c2:	jmp    29e56f8 <wasm[0]::function[1015]::helper::object_read+0x47d8>
 29e55c7:	mov    0x2e0(%rsp),%r12
 29e55cf:	mov    0x28(%r12),%rcx
 29e55d4:	mov    0x20(%r12),%rdx
 29e55d9:	lea    (%rdx,%rax,1),%rsi
 29e55dd:	xor    %r9,%r9
 29e55e0:	cmp    %rcx,%rax
 29e55e3:	cmova  %r9,%rsi
 29e55e7:	mov    0x30(%rsi),%eax
 29e55ea:	xor    %r10d,%r10d
 29e55ed:	test   %eax,%eax
 29e55ef:	je     29fbd77 <wasm[0]::function[1015]::helper::object_read+0x1ae57>
 29e55f5:	test   %eax,%eax
 29e55f7:	je     29fbd79 <wasm[0]::function[1015]::helper::object_read+0x1ae59>
 29e55fd:	mov    %eax,%edi
 29e55ff:	lea    0x10(%rdx,%rdi,1),%rdx
 29e5604:	cmp    %rcx,%rdi
 29e5607:	cmova  %r9,%rdx
 29e560b:	mov    (%rdx),%ecx
 29e560d:	mov    0xa0(%rsp),%edx
 29e5614:	mov    %r15d,%esi
 29e5617:	mov    %ecx,%ecx
 29e5619:	cmp    %rcx,%rsi
 29e561c:	jb     29e562a <wasm[0]::function[1015]::helper::object_read+0x470a>
 29e5622:	mov    %r10,%rcx
 29e5625:	jmp    29e56f8 <wasm[0]::function[1015]::helper::object_read+0x47d8>
 29e562a:	mov    0x2e0(%rsp),%r12
 29e5632:	mov    0x28(%r12),%rcx
 29e5637:	mov    0x20(%r12),%rsi
 29e563c:	lea    0x10(%rsi,%rdi,1),%rdx
 29e5641:	xor    %r9,%r9
 29e5644:	cmp    %rcx,%rdi
 29e5647:	cmova  %r9,%rdx
 29e564b:	mov    (%rdx),%edx
 29e564d:	cmp    %edx,%r15d
 29e5650:	jae    29fbd7b <wasm[0]::function[1015]::helper::object_read+0x1ae5b>
 29e5656:	mov    %edx,%edi
 29e5658:	shl    $0x2,%rdi
 29e565c:	shr    $0x20,%rdi
 29e5660:	test   %rdi,%rdi
 29e5663:	jne    29fbd7d <wasm[0]::function[1015]::helper::object_read+0x1ae5d>
 29e5669:	shl    $0x2,%edx
 29e566c:	add    $0x14,%edx
 29e566f:	jb     29fbd7f <wasm[0]::function[1015]::helper::object_read+0x1ae5f>
 29e5675:	add    %edx,%eax
 29e5677:	jb     29fbd81 <wasm[0]::function[1015]::helper::object_read+0x1ae61>
 29e567d:	mov    %eax,%edi
 29e567f:	lea    (%rsi,%rdi,1),%rax
 29e5683:	cmp    %rcx,%rdi
 29e5686:	cmova  %r9,%rax
 29e568a:	shl    $0x2,%r15d
 29e568e:	lea    0x14(%r15),%ecx
 29e5692:	sub    %ecx,%edx
 29e5694:	sub    %rdx,%rax
 29e5697:	mov    (%rax),%eax
 29e5699:	mov    0xa0(%rsp),%edx
 29e56a0:	xor    %r10d,%r10d
 29e56a3:	test   %eax,%eax
 29e56a5:	jne    29e56b3 <wasm[0]::function[1015]::helper::object_read+0x4793>
 29e56ab:	mov    %r10,%rcx
 29e56ae:	jmp    29e56f8 <wasm[0]::function[1015]::helper::object_read+0x47d8>
 29e56b3:	test   %eax,%eax
 29e56b5:	je     29fbd83 <wasm[0]::function[1015]::helper::object_read+0x1ae63>
 29e56bb:	test   %eax,%eax
 29e56bd:	je     29fbd85 <wasm[0]::function[1015]::helper::object_read+0x1ae65>
 29e56c3:	mov    0x2e0(%rsp),%r12
 29e56cb:	mov    0x28(%r12),%rdi
 29e56d0:	mov    0x20(%r12),%r9
 29e56d5:	mov    %eax,%r8d
 29e56d8:	lea    (%r9,%r8,1),%rsi
 29e56dc:	xor    %r9,%r9
 29e56df:	cmp    %rdi,%r8
 29e56e2:	cmova  %r9,%rsi
 29e56e6:	mov    0x18(%rsi),%ecx
 29e56e9:	mov    0x10(%rsi),%r9
 29e56ed:	mov    0x1c(%rsi),%edx
 29e56f0:	mov    0x278(%rsp),%r10
 29e56f8:	mov    0x48(%rsp),%eax
 29e56fc:	mov    0x80(%rsp),%edi
 29e5703:	mov    0xa8(%rsp),%r8d
 29e570b:	mov    0xb8(%rsp),%r11d
 29e5713:	mov    0x58(%rsp),%r12d
 29e5718:	mov    0xc0(%rsp),%r13d
 29e5720:	mov    0xe0(%rsp),%esi
 29e5727:	xor    %ebx,%ebx
 29e5729:	test   %r10d,%r10d
 29e572c:	jne    29e5752 <wasm[0]::function[1015]::helper::object_read+0x4832>
 29e5732:	mov    0x288(%rsp),%r9
 29e573a:	mov    %rsi,%rdx
 29e573d:	mov    0x290(%rsp),%rsi
 29e5745:	mov    0x280(%rsp),%rcx
 29e574d:	jmp    29e5764 <wasm[0]::function[1015]::helper::object_read+0x4844>
 29e5752:	xor    %esi,%esi
 29e5754:	mov    0x278(%rsp),%rbx
 29e575c:	mov    %rsi,0x298(%rsp)
 29e5764:	mov    %rcx,0x280(%rsp)
 29e576c:	mov    %r9,0x288(%rsp)
 29e5774:	mov    %edi,0x58(%rsp)
 29e5778:	mov    %r8d,0xb8(%rsp)
 29e5780:	mov    %r11d,0xa8(%rsp)
 29e5788:	mov    %r12d,0x80(%rsp)
 29e5790:	mov    %r13d,0x48(%rsp)
 29e5795:	test   %eax,%eax
 29e5797:	jne    29e57aa <wasm[0]::function[1015]::helper::object_read+0x488a>
 29e579d:	mov    0x288(%rsp),%rax
 29e57a5:	jmp    29e5972 <wasm[0]::function[1015]::helper::object_read+0x4a52>
 29e57aa:	test   %eax,%eax
 29e57ac:	je     29fbd87 <wasm[0]::function[1015]::helper::object_read+0x1ae67>
 29e57b2:	test   %eax,%eax
 29e57b4:	je     29fbd89 <wasm[0]::function[1015]::helper::object_read+0x1ae69>
 29e57ba:	mov    0x2e0(%rsp),%r12
 29e57c2:	mov    0x28(%r12),%rcx
 29e57c7:	mov    %eax,%eax
 29e57c9:	mov    %rax,%rdi
 29e57cc:	add    0x20(%r12),%rdi
 29e57d1:	xor    %r8,%r8
 29e57d4:	cmp    %rcx,%rax
 29e57d7:	cmova  %r8,%rdi
 29e57db:	mov    0x10(%rdi),%ecx
 29e57de:	test   $0x1,%ecx
 29e57e4:	je     29e57f7 <wasm[0]::function[1015]::helper::object_read+0x48d7>
 29e57ea:	mov    0x288(%rsp),%rax
 29e57f2:	jmp    29e5972 <wasm[0]::function[1015]::helper::object_read+0x4a52>
 29e57f7:	mov    0x2e0(%rsp),%r12
 29e57ff:	mov    0x28(%r12),%rcx
 29e5804:	mov    0x20(%r12),%rdx
 29e5809:	add    %rax,%rdx
 29e580c:	xor    %rsi,%rsi
 29e580f:	cmp    %rcx,%rax
 29e5812:	cmova  %rsi,%rdx
 29e5816:	mov    0x14(%rdx),%edx
 29e5819:	test   %edx,%edx
 29e581b:	je     29fbd8b <wasm[0]::function[1015]::helper::object_read+0x1ae6b>
 29e5821:	xor    %eax,%eax
 29e5823:	test   $0x1,%edx
 29e5829:	jne    29e586c <wasm[0]::function[1015]::helper::object_read+0x494c>
 29e582f:	mov    0x2e0(%rsp),%r12
 29e5837:	mov    0x28(%r12),%rax
 29e583c:	mov    0x20(%r12),%rcx
 29e5841:	mov    %edx,%esi
 29e5843:	lea    0x4(%rcx,%rsi,1),%rcx
 29e5848:	xor    %rdi,%rdi
 29e584b:	cmp    %rax,%rsi
 29e584e:	cmova  %rdi,%rcx
 29e5852:	mov    (%rcx),%eax
 29e5854:	mov    0x190(%rsp),%rcx
 29e585c:	mov    0x28(%rcx),%rcx
 29e5860:	cmp    0x120(%rcx),%eax
 29e5866:	sete   %al
 29e5869:	movzbl %al,%eax
 29e586c:	test   %eax,%eax
 29e586e:	jne    29e58d1 <wasm[0]::function[1015]::helper::object_read+0x49b1>
 29e5874:	mov    0x190(%rsp),%rsi
 29e587c:	mov    0x190(%rsp),%rdi
 29e5884:	call   2a01ba0 <wasm[0]::function[1024]::helper::property_value_resolve>
 29e5889:	test   %eax,%eax
 29e588b:	je     29fbd8d <wasm[0]::function[1015]::helper::object_read+0x1ae6d>
 29e5891:	test   %eax,%eax
 29e5893:	je     29fbd8f <wasm[0]::function[1015]::helper::object_read+0x1ae6f>
 29e5899:	mov    0x2e0(%rsp),%r12
 29e58a1:	mov    0x28(%r12),%rdx
 29e58a6:	mov    0x20(%r12),%rcx
 29e58ab:	mov    %eax,%eax
 29e58ad:	add    %rax,%rcx
 29e58b0:	xor    %rsi,%rsi
 29e58b3:	cmp    %rdx,%rax
 29e58b6:	cmova  %rsi,%rcx
 29e58ba:	mov    0x18(%rcx),%eax
 29e58bd:	mov    %rax,0x280(%rsp)
 29e58c5:	mov    0x10(%rcx),%rax
 29e58c9:	mov    0x1c(%rcx),%edx
 29e58cc:	jmp    29e5960 <wasm[0]::function[1015]::helper::object_read+0x4a40>
 29e58d1:	xor    %esi,%esi
 29e58d3:	test   $0x1,%edx
 29e58d9:	jne    29e591d <wasm[0]::function[1015]::helper::object_read+0x49fd>
 29e58df:	mov    0x2e0(%rsp),%r12
 29e58e7:	mov    0x28(%r12),%rax
 29e58ec:	mov    0x20(%r12),%rcx
 29e58f1:	mov    %edx,%esi
 29e58f3:	lea    0x4(%rcx,%rsi,1),%rcx
 29e58f8:	xor    %rdi,%rdi
 29e58fb:	cmp    %rax,%rsi
 29e58fe:	cmova  %rdi,%rcx
 29e5902:	mov    (%rcx),%eax
 29e5904:	mov    0x190(%rsp),%rcx
 29e590c:	mov    0x28(%rcx),%rcx
 29e5910:	cmp    0x120(%rcx),%eax
 29e5916:	sete   %al
 29e5919:	rex movzbl %al,%esi
 29e591d:	test   %esi,%esi
 29e591f:	je     29fbd91 <wasm[0]::function[1015]::helper::object_read+0x1ae71>
 29e5925:	test   %edx,%edx
 29e5927:	je     29fbd93 <wasm[0]::function[1015]::helper::object_read+0x1ae73>
 29e592d:	mov    0x2e0(%rsp),%r12
 29e5935:	mov    0x28(%r12),%rax
 29e593a:	mov    0x20(%r12),%rcx
 29e593f:	mov    %edx,%edx
 29e5941:	add    %rdx,%rcx
 29e5944:	xor    %rsi,%rsi
 29e5947:	cmp    %rax,%rdx
 29e594a:	cmova  %rsi,%rcx
 29e594e:	mov    0x18(%rcx),%eax
 29e5951:	mov    %rax,0x280(%rsp)
 29e5959:	mov    0x10(%rcx),%rax
 29e595d:	mov    0x1c(%rcx),%edx
 29e5960:	xor    %esi,%esi
 29e5962:	mov    0x278(%rsp),%rbx
 29e596a:	mov    %rsi,0x298(%rsp)
 29e5972:	mov    0x58(%rsp),%r10d
 29e5977:	mov    0xb8(%rsp),%r9d
 29e597f:	mov    0xa8(%rsp),%r14d
 29e5987:	mov    %r14,0x208(%rsp)
 29e598f:	mov    0x80(%rsp),%r14d
 29e5997:	mov    0x48(%rsp),%edi
 29e599b:	mov    %rax,0x288(%rsp)
 29e59a3:	jmp    29e5a53 <wasm[0]::function[1015]::helper::object_read+0x4b33>
 29e59a8:	xor    %edx,%edx
 29e59aa:	mov    0x210(%rsp),%rax
 29e59b2:	mov    0x210(%rsp),%rcx
 29e59ba:	test   %ecx,%eax
 29e59bc:	je     29fbd95 <wasm[0]::function[1015]::helper::object_read+0x1ae75>
 29e59c2:	test   %ecx,%eax
 29e59c4:	je     29fbd97 <wasm[0]::function[1015]::helper::object_read+0x1ae77>
 29e59ca:	mov    0x2e0(%rsp),%r12
 29e59d2:	mov    0x28(%r12),%r8
 29e59d7:	mov    0x210(%rsp),%rsi
 29e59df:	mov    %esi,%r11d
 29e59e2:	mov    %r11,%rsi
 29e59e5:	add    0x20(%r12),%rsi
 29e59ea:	xor    %rax,%rax
 29e59ed:	cmp    %r8,%r11
 29e59f0:	cmova  %rax,%rsi
 29e59f4:	mov    0x18(%rsi),%r11
 29e59f8:	mov    $0x3,%eax
 29e59fd:	mov    %rax,0x280(%rsp)
 29e5a05:	cmp    $0x0,%r11
 29e5a09:	jl     29e5a19 <wasm[0]::function[1015]::helper::object_read+0x4af9>
 29e5a0f:	cvtsi2sd %r11,%xmm7
 29e5a14:	jmp    29e5a33 <wasm[0]::function[1015]::helper::object_read+0x4b13>
 29e5a19:	mov    %r11,%r8
 29e5a1c:	shr    $0x1,%r8
 29e5a20:	mov    %r11,%rax
 29e5a23:	and    $0x1,%rax
 29e5a27:	or     %r8,%rax
 29e5a2a:	cvtsi2sd %rax,%xmm7
 29e5a2f:	addsd  %xmm7,%xmm7
 29e5a33:	movq   %xmm7,%rax
 29e5a38:	mov    %rax,0x288(%rsp)
 29e5a40:	mov    0x278(%rsp),%rbx
 29e5a48:	mov    %rdx,%rsi
 29e5a4b:	mov    %rdx,0x298(%rsp)
 29e5a53:	mov    %r10,%rax
 29e5a56:	mov    %r10,0x210(%rsp)
 29e5a5e:	mov    %eax,0x48(%rsp)
 29e5a62:	mov    %r9d,0x80(%rsp)
 29e5a6a:	mov    0x208(%rsp),%rax
 29e5a72:	mov    %eax,0xa8(%rsp)
 29e5a79:	mov    %r14d,0xb8(%rsp)
 29e5a81:	mov    %edi,0x58(%rsp)
 29e5a85:	test   %ebx,%ebx
 29e5a87:	je     29e5a9a <wasm[0]::function[1015]::helper::object_read+0x4b7a>
 29e5a8d:	mov    0x298(%rsp),%rdi
 29e5a95:	jmp    29efba2 <wasm[0]::function[1015]::helper::object_read+0xec82>
 29e5a9a:	xor    %eax,%eax
 29e5a9c:	movl   $0x0,0xc0(%rsp)
 29e5aa7:	mov    0x210(%rsp),%rcx
 29e5aaf:	mov    0x210(%rsp),%rdx
 29e5ab7:	test   %ecx,%edx
 29e5ab9:	je     29e5b1a <wasm[0]::function[1015]::helper::object_read+0x4bfa>
 29e5abf:	xor    %eax,%eax
 29e5ac1:	mov    0x210(%rsp),%rdx
 29e5ac9:	test   $0x1,%edx
 29e5acf:	jne    29e5b1a <wasm[0]::function[1015]::helper::object_read+0x4bfa>
 29e5ad5:	mov    0x2e0(%rsp),%r12
 29e5add:	mov    0x28(%r12),%rax
 29e5ae2:	mov    0x20(%r12),%rdx
 29e5ae7:	mov    0x210(%rsp),%rcx
 29e5aef:	mov    %ecx,%esi
 29e5af1:	lea    0x4(%rdx,%rsi,1),%rdx
 29e5af6:	xor    %r8,%r8
 29e5af9:	cmp    %rax,%rsi
 29e5afc:	cmova  %r8,%rdx
 29e5b00:	mov    (%rdx),%eax
 29e5b02:	mov    0x190(%rsp),%rcx
 29e5b0a:	mov    0x28(%rcx),%rcx
 29e5b0e:	cmp    0x138(%rcx),%eax
 29e5b14:	sete   %al
 29e5b17:	movzbl %al,%eax
 29e5b1a:	test   %eax,%eax
 29e5b1c:	jne    29eee83 <wasm[0]::function[1015]::helper::object_read+0xdf63>
 29e5b22:	xor    %eax,%eax
 29e5b24:	mov    0x210(%rsp),%rcx
 29e5b2c:	mov    0x210(%rsp),%rdx
 29e5b34:	test   %ecx,%edx
 29e5b36:	je     29e5b98 <wasm[0]::function[1015]::helper::object_read+0x4c78>
 29e5b3c:	xor    %eax,%eax
 29e5b3e:	mov    0x210(%rsp),%rdx
 29e5b46:	test   $0x1,%edx
 29e5b4c:	jne    29e5b98 <wasm[0]::function[1015]::helper::object_read+0x4c78>
 29e5b52:	mov    0x2e0(%rsp),%r12
 29e5b5a:	mov    0x28(%r12),%rax
 29e5b5f:	mov    0x20(%r12),%rdx
 29e5b64:	mov    0x210(%rsp),%r8
 29e5b6c:	mov    %r8d,%esi
 29e5b6f:	lea    0x4(%rdx,%rsi,1),%rdx
 29e5b74:	xor    %r8,%r8
 29e5b77:	cmp    %rax,%rsi
 29e5b7a:	cmova  %r8,%rdx
 29e5b7e:	mov    (%rdx),%eax
 29e5b80:	mov    0x190(%rsp),%rcx
 29e5b88:	mov    0x28(%rcx),%rcx
 29e5b8c:	cmp    0x254(%rcx),%eax
 29e5b92:	sete   %al
 29e5b95:	movzbl %al,%eax
 29e5b98:	test   %eax,%eax
 29e5b9a:	jne    29ec7d4 <wasm[0]::function[1015]::helper::object_read+0xb8b4>
 29e5ba0:	xor    %eax,%eax
 29e5ba2:	mov    0x208(%rsp),%rcx
 29e5baa:	mov    %rax,%rdx
 29e5bad:	mov    0x208(%rsp),%rsi
 29e5bb5:	mov    %rax,%r8
 29e5bb8:	mov    %ecx,0x140(%rsp)
 29e5bbf:	mov    %eax,0xd0(%rsp)
 29e5bc6:	mov    %r8d,0x100(%rsp)
 29e5bce:	mov    0x210(%rsp),%rax
 29e5bd6:	mov    %eax,0x120(%rsp)
 29e5bdd:	mov    %r9d,0x110(%rsp)
 29e5be5:	mov    %esi,0x78(%rsp)
 29e5be9:	mov    %r14d,0x88(%rsp)
 29e5bf1:	mov    %edx,0xa0(%rsp)
 29e5bf8:	mov    %edi,0xe0(%rsp)
 29e5bff:	mov    0x2e8(%rsp),%r15
 29e5c07:	mov    (%r15),%rax
 29e5c0a:	mov    0x228(%rsp),%rcx
 29e5c12:	cmp    %rcx,%rax
 29e5c15:	jae    29fa7e7 <wasm[0]::function[1015]::helper::object_read+0x198c7>
 29e5c1b:	mov    0x140(%rsp),%ecx
 29e5c22:	mov    0xd0(%rsp),%eax
 29e5c29:	test   %ecx,%ecx
 29e5c2b:	je     29e5cef <wasm[0]::function[1015]::helper::object_read+0x4dcf>
 29e5c31:	mov    0x140(%rsp),%ecx
 29e5c38:	test   %ecx,%ecx
 29e5c3a:	je     29fbd99 <wasm[0]::function[1015]::helper::object_read+0x1ae79>
 29e5c40:	mov    0x2e0(%rsp),%r12
 29e5c48:	mov    0x28(%r12),%rax
 29e5c4d:	mov    0x20(%r12),%rsi
 29e5c52:	mov    %ecx,%edx
 29e5c54:	lea    (%rsi,%rdx,1),%rcx
 29e5c58:	xor    %rsi,%rsi
 29e5c5b:	cmp    %rax,%rdx
 29e5c5e:	cmova  %rsi,%rcx
 29e5c62:	mov    0x10(%rcx),%eax
 29e5c65:	test   %eax,%eax
 29e5c67:	jne    29e5cef <wasm[0]::function[1015]::helper::object_read+0x4dcf>
 29e5c6d:	mov    0x140(%rsp),%edi
 29e5c74:	test   %edi,%edi
 29e5c76:	je     29fbd9b <wasm[0]::function[1015]::helper::object_read+0x1ae7b>
 29e5c7c:	mov    0x2e0(%rsp),%r12
 29e5c84:	mov    0x28(%r12),%rsi
 29e5c89:	mov    %edi,%edi
 29e5c8b:	mov    %rdi,%rdx
 29e5c8e:	add    0x20(%r12),%rdx
 29e5c93:	xor    %r8,%r8
 29e5c96:	cmp    %rsi,%rdi
 29e5c99:	cmova  %r8,%rdx
 29e5c9d:	mov    0x1c(%rdx),%r14d
 29e5ca1:	mov    %r14,0x208(%rsp)
 29e5ca9:	mov    0x100(%rsp),%r8d
 29e5cb1:	mov    0x120(%rsp),%edx
 29e5cb8:	mov    %rdx,0x210(%rsp)
 29e5cc0:	mov    0x110(%rsp),%r9d
 29e5cc8:	mov    0x78(%rsp),%esi
 29e5ccc:	mov    0x88(%rsp),%r14d
 29e5cd4:	mov    0xa0(%rsp),%edx
 29e5cdb:	mov    0xe0(%rsp),%edi
 29e5ce2:	mov    0x208(%rsp),%rcx
 29e5cea:	jmp    29e5bb8 <wasm[0]::function[1015]::helper::object_read+0x4c98>
 29e5cef:	test   %eax,%eax
 29e5cf1:	jne    29e5d0d <wasm[0]::function[1015]::helper::object_read+0x4ded>
 29e5cf7:	mov    0x190(%rsp),%rcx
 29e5cff:	mov    0x8c0(%rcx),%eax
 29e5d05:	test   %eax,%eax
 29e5d07:	je     29fbd9d <wasm[0]::function[1015]::helper::object_read+0x1ae7d>
 29e5d0d:	mov    %eax,0x140(%rsp)
 29e5d14:	test   %eax,%eax
 29e5d16:	je     29fbd9f <wasm[0]::function[1015]::helper::object_read+0x1ae7f>
 29e5d1c:	test   %eax,%eax
 29e5d1e:	je     29fbda1 <wasm[0]::function[1015]::helper::object_read+0x1ae81>
 29e5d24:	mov    0x2e0(%rsp),%r12
 29e5d2c:	mov    0x28(%r12),%rcx
 29e5d31:	mov    0x20(%r12),%rdx
 29e5d36:	mov    %eax,%edi
 29e5d38:	lea    (%rdx,%rdi,1),%rsi
 29e5d3c:	xor    %rax,%rax
 29e5d3f:	cmp    %rcx,%rdi
 29e5d42:	cmova  %rax,%rsi
 29e5d46:	mov    0x2c(%rsi),%r8d
 29e5d4a:	test   %r8d,%r8d
 29e5d4d:	je     29fbda3 <wasm[0]::function[1015]::helper::object_read+0x1ae83>
 29e5d53:	test   %r8d,%r8d
 29e5d56:	je     29fbda5 <wasm[0]::function[1015]::helper::object_read+0x1ae85>
 29e5d5c:	mov    %r8d,%edi
 29e5d5f:	lea    0x10(%rdx,%rdi,1),%rsi
 29e5d64:	cmp    %rcx,%rdi
 29e5d67:	cmova  %rax,%rsi
 29e5d6b:	mov    (%rsi),%esi
 29e5d6d:	cmp    $0xd,%esi
 29e5d70:	jbe    29fbda7 <wasm[0]::function[1015]::helper::object_read+0x1ae87>
 29e5d76:	mov    %esi,%edi
 29e5d78:	shl    $0x2,%rdi
 29e5d7c:	mov    $0x20,%r9d
 29e5d82:	mov    %r9,0x2c8(%rsp)
 29e5d8a:	shr    $0x20,%rdi
 29e5d8e:	test   %rdi,%rdi
 29e5d91:	jne    29fbda9 <wasm[0]::function[1015]::helper::object_read+0x1ae89>
 29e5d97:	shl    $0x2,%esi
 29e5d9a:	add    $0x14,%esi
 29e5d9d:	jb     29fbdab <wasm[0]::function[1015]::helper::object_read+0x1ae8b>
 29e5da3:	add    %esi,%r8d
 29e5da6:	jb     29fbdad <wasm[0]::function[1015]::helper::object_read+0x1ae8d>
 29e5dac:	mov    %r8d,%r8d
 29e5daf:	lea    (%rdx,%r8,1),%rdi
 29e5db3:	cmp    %rcx,%r8
 29e5db6:	cmova  %rax,%rdi
 29e5dba:	sub    $0x48,%esi
 29e5dbd:	sub    %rsi,%rdi
 29e5dc0:	mov    (%rdi),%esi
 29e5dc2:	test   %esi,%esi
 29e5dc4:	je     29fbdaf <wasm[0]::function[1015]::helper::object_read+0x1ae8f>
 29e5dca:	test   %esi,%esi
 29e5dcc:	je     29fbdb1 <wasm[0]::function[1015]::helper::object_read+0x1ae91>
 29e5dd2:	mov    %esi,%esi
 29e5dd4:	add    %rsi,%rdx
 29e5dd7:	cmp    %rcx,%rsi
 29e5dda:	cmova  %rax,%rdx
 29e5dde:	mov    0x18(%rdx),%ecx
 29e5de1:	mov    0x10(%rdx),%rax
 29e5de5:	mov    0x1c(%rdx),%eax
 29e5de8:	mov    %eax,0xd0(%rsp)
 29e5def:	cmp    $0x6,%ecx
 29e5df2:	sete   %dl
 29e5df5:	cmp    $0x7,%ecx
 29e5df8:	sete   %sil
 29e5dfc:	or     %esi,%edx
 29e5dfe:	cmp    $0x8,%ecx
 29e5e01:	sete   %sil
 29e5e05:	or     %esi,%edx
 29e5e07:	cmp    $0x9,%ecx
 29e5e0a:	sete   %cl
 29e5e0d:	or     %ecx,%edx
 29e5e0f:	movzbl %dl,%ecx
 29e5e12:	test   %ecx,%ecx
 29e5e14:	je     29fbdb3 <wasm[0]::function[1015]::helper::object_read+0x1ae93>
 29e5e1a:	xor    %ecx,%ecx
 29e5e1c:	test   %eax,%eax
 29e5e1e:	je     29e5e6e <wasm[0]::function[1015]::helper::object_read+0x4f4e>
 29e5e24:	xor    %ecx,%ecx
 29e5e26:	test   $0x1,%eax
 29e5e2b:	jne    29e5e6e <wasm[0]::function[1015]::helper::object_read+0x4f4e>
 29e5e31:	mov    0x2e0(%rsp),%r12
 29e5e39:	mov    0x28(%r12),%rcx
 29e5e3e:	mov    0x20(%r12),%rdx
 29e5e43:	mov    %eax,%esi
 29e5e45:	lea    0x4(%rdx,%rsi,1),%rdx
 29e5e4a:	xor    %rdi,%rdi
 29e5e4d:	cmp    %rcx,%rsi
 29e5e50:	cmova  %rdi,%rdx
 29e5e54:	mov    (%rdx),%ecx
 29e5e56:	mov    0x190(%rsp),%rdx
 29e5e5e:	mov    0x28(%rdx),%rdx
 29e5e62:	cmp    0x1d4(%rdx),%ecx
 29e5e68:	sete   %cl
 29e5e6b:	movzbl %cl,%ecx
 29e5e6e:	test   %ecx,%ecx
 29e5e70:	je     29fbdb5 <wasm[0]::function[1015]::helper::object_read+0x1ae95>
 29e5e76:	test   %eax,%eax
 29e5e78:	je     29fbdb7 <wasm[0]::function[1015]::helper::object_read+0x1ae97>
 29e5e7e:	movl   $0x0,0x148(%rsp)
 29e5e89:	movl   $0x0,0xe8(%rsp)
 29e5e94:	movl   $0x0,0x98(%rsp)
 29e5e9f:	movl   $0x0,0x118(%rsp)
 29e5eaa:	movl   $0x0,0xb0(%rsp)
 29e5eb5:	mov    $0x105,%edx
 29e5eba:	mov    0x190(%rsp),%rsi
 29e5ec2:	mov    0x190(%rsp),%rdi
 29e5eca:	call   2f307a0 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 29e5ecf:	test   %eax,%eax
 29e5ed1:	je     29fbdb9 <wasm[0]::function[1015]::helper::object_read+0x1ae99>
 29e5ed7:	mov    0xd0(%rsp),%r8d
 29e5edf:	mov    $0x8,%edx
 29e5ee4:	xor    %rcx,%rcx
 29e5ee7:	movabs $0x4000000000000000,%rsi
 29e5ef1:	mov    %rsi,(%rsp)
 29e5ef5:	mov    0x278(%rsp),%rsi
 29e5efd:	mov    %esi,0x8(%rsp)
 29e5f01:	mov    %rax,%r9
 29e5f04:	mov    0x190(%rsp),%rsi
 29e5f0c:	mov    0x190(%rsp),%rdi
 29e5f14:	call   2a56060 <wasm[0]::function[1029]::helper::native_function_allocate>
 29e5f19:	sub    $0x10,%rsp
 29e5f1d:	mov    %eax,0xd0(%rsp)
 29e5f24:	mov    $0x51,%esi
 29e5f29:	mov    0x190(%rsp),%rdi
 29e5f31:	call   3018cee <wasmtime_builtin_ref_func>
 29e5f36:	mov    0x190(%rsp),%rcx
 29e5f3e:	mov    %rax,%r13
 29e5f41:	mov    0x20(%rcx),%rdi
 29e5f45:	mov    (%rdi),%eax
 29e5f47:	mov    %eax,%esi
 29e5f49:	lea    0x40(%rsi),%r8
 29e5f4d:	mov    0x4(%rdi),%r9d
 29e5f51:	mov    %rdi,0x2c0(%rsp)
 29e5f59:	cmp    %r9,%r8
 29e5f5c:	ja     29fa81f <wasm[0]::function[1015]::helper::object_read+0x198ff>
 29e5f62:	lea    0x40(%rax),%edi
 29e5f65:	mov    0x2c0(%rsp),%rcx
 29e5f6d:	mov    %edi,(%rcx)
 29e5f6f:	mov    0x2e0(%rsp),%r12
 29e5f77:	mov    0x20(%r12),%r8
 29e5f7c:	lea    (%r8,%rsi,1),%rbx
 29e5f80:	movl   $0xb0000002,(%r8,%rsi,1)
 29e5f88:	mov    0x190(%rsp),%rcx
 29e5f90:	mov    0x28(%rcx),%r9
 29e5f94:	mov    0x1d0(%r9),%r9d
 29e5f9b:	mov    %r9d,0x4(%r8,%rsi,1)
 29e5fa0:	mov    $0x40,%r10d
 29e5fa6:	mov    %r10d,0x8(%r8,%rsi,1)
 29e5fab:	mov    %eax,0x130(%rsp)
 29e5fb2:	movq   $0x51,0x10(%rbx)
 29e5fba:	movl   $0x1,0x18(%rbx)
 29e5fc1:	movl   $0xf,0x1c(%rbx)
 29e5fc8:	movl   $0xffffffff,0x20(%rbx)
 29e5fcf:	movl   $0x0,0x24(%rbx)
 29e5fd6:	movl   $0x0,0x28(%rbx)
 29e5fdd:	mov    %r13,%rsi
 29e5fe0:	mov    0x190(%rsp),%rdi
 29e5fe8:	call   3018de3 <wasmtime_builtin_intern_func_ref_for_gc_heap>
 29e5fed:	mov    %eax,0x2c(%rbx)
 29e5ff0:	xor    %rsi,%rsi
 29e5ff3:	mov    %rsi,%r12
 29e5ff6:	mov    0x190(%rsp),%rdi
 29e5ffe:	call   3018de3 <wasmtime_builtin_intern_func_ref_for_gc_heap>
 29e6003:	mov    %eax,0x30(%rbx)
 29e6006:	mov    %r12,%rsi
 29e6009:	mov    0x190(%rsp),%rdi
 29e6011:	call   3018de3 <wasmtime_builtin_intern_func_ref_for_gc_heap>
 29e6016:	mov    %eax,0x34(%rbx)
 29e6019:	mov    %r12,%rsi
 29e601c:	mov    0x190(%rsp),%rdi
 29e6024:	call   3018de3 <wasmtime_builtin_intern_func_ref_for_gc_heap>
 29e6029:	mov    %eax,0x38(%rbx)
 29e602c:	mov    %r12,%rsi
 29e602f:	mov    0x190(%rsp),%rdi
 29e6037:	call   3018de3 <wasmtime_builtin_intern_func_ref_for_gc_heap>
 29e603c:	mov    %eax,0x3c(%rbx)
 29e603f:	mov    0x190(%rsp),%rcx
 29e6047:	mov    0xa20(%rcx),%eax
 29e604d:	mov    %eax,0xf0(%rsp)
 29e6054:	mov    0x140(%rsp),%ecx
 29e605b:	test   %ecx,%ecx
 29e605d:	je     29fbdbb <wasm[0]::function[1015]::helper::object_read+0x1ae9b>
 29e6063:	test   %eax,%eax
 29e6065:	je     29fbdbd <wasm[0]::function[1015]::helper::object_read+0x1ae9d>
 29e606b:	mov    0x2c0(%rsp),%rsi
 29e6073:	mov    (%rsi),%eax
 29e6075:	mov    %eax,%ecx
 29e6077:	lea    0x40(%rcx),%rdx
 29e607b:	mov    0x4(%rsi),%esi
 29e607e:	cmp    %rsi,%rdx
 29e6081:	ja     29fa862 <wasm[0]::function[1015]::helper::object_read+0x19942>
 29e6087:	mov    %rax,%rdx
 29e608a:	lea    0x40(%rdx),%eax
 29e608d:	mov    0x2c0(%rsp),%rsi
 29e6095:	mov    %eax,(%rsi)
 29e6097:	mov    0x2e0(%rsp),%r12
 29e609f:	mov    0x20(%r12),%rax
 29e60a4:	lea    (%rax,%rcx,1),%rbx
 29e60a8:	movl   $0xb0001ffa,(%rax,%rcx,1)
 29e60af:	mov    0x190(%rsp),%rsi
 29e60b7:	mov    0x28(%rsi),%rsi
 29e60bb:	mov    0x1e0(%rsi),%esi
 29e60c1:	mov    %esi,0x4(%rax,%rcx,1)
 29e60c5:	mov    $0x40,%esi
 29e60ca:	mov    %esi,0x8(%rax,%rcx,1)
 29e60ce:	mov    %edx,0xd8(%rsp)
 29e60d5:	mov    0x140(%rsp),%eax
 29e60dc:	mov    %eax,0x10(%rbx)
 29e60df:	mov    0x148(%rsp),%eax
 29e60e6:	mov    %eax,0x14(%rbx)
 29e60e9:	mov    0xe8(%rsp),%eax
 29e60f0:	mov    %eax,0x18(%rbx)
 29e60f3:	movl   $0x0,0x1c(%rbx)
 29e60fa:	mov    0xf0(%rsp),%eax
 29e6101:	mov    %eax,0x20(%rbx)
 29e6104:	mov    0x98(%rsp),%eax
 29e610b:	mov    %eax,0x24(%rbx)
 29e610e:	mov    0xb0(%rsp),%eax
 29e6115:	mov    %eax,0x28(%rbx)
 29e6118:	mov    0x100(%rsp),%eax
 29e611f:	mov    %eax,0x2c(%rbx)
 29e6122:	mov    0x118(%rsp),%eax
 29e6129:	mov    %eax,0x30(%rbx)
 29e612c:	movl   $0x0,0x34(%rbx)
 29e6133:	xor    %rsi,%rsi
 29e6136:	mov    0x190(%rsp),%rdi
 29e613e:	call   3018de3 <wasmtime_builtin_intern_func_ref_for_gc_heap>
 29e6143:	mov    %eax,0x38(%rbx)
 29e6146:	mov    $0xea5,%edx
 29e614b:	mov    0x190(%rsp),%rsi
 29e6153:	mov    0x190(%rsp),%rdi
 29e615b:	call   2f307a0 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 29e6160:	mov    %eax,0x118(%rsp)
 29e6167:	mov    0x190(%rsp),%rcx
 29e616f:	mov    0xa20(%rcx),%ecx
 29e6175:	mov    %ecx,0x100(%rsp)
 29e617c:	mov    0xd0(%rsp),%edx
 29e6183:	test   %edx,%edx
 29e6185:	je     29fbdbf <wasm[0]::function[1015]::helper::object_read+0x1ae9f>
 29e618b:	mov    0x130(%rsp),%edx
 29e6192:	test   %edx,%edx
 29e6194:	je     29fbdc1 <wasm[0]::function[1015]::helper::object_read+0x1aea1>
 29e619a:	mov    0xd8(%rsp),%edx
 29e61a1:	test   %edx,%edx
 29e61a3:	je     29fbdc3 <wasm[0]::function[1015]::helper::object_read+0x1aea3>
 29e61a9:	test   %eax,%eax
 29e61ab:	je     29fbdc5 <wasm[0]::function[1015]::helper::object_read+0x1aea5>
 29e61b1:	test   %ecx,%ecx
 29e61b3:	je     29fbdc7 <wasm[0]::function[1015]::helper::object_read+0x1aea7>
 29e61b9:	mov    0x2c0(%rsp),%rsi
 29e61c1:	mov    (%rsi),%eax
 29e61c3:	mov    %eax,%edx
 29e61c5:	lea    0x50(%rdx),%rcx
 29e61c9:	mov    0x4(%rsi),%esi
 29e61cc:	cmp    %rsi,%rcx
 29e61cf:	ja     29fa8a8 <wasm[0]::function[1015]::helper::object_read+0x19988>
 29e61d5:	lea    0x50(%rax),%ecx
 29e61d8:	mov    0x2c0(%rsp),%rsi
 29e61e0:	mov    %ecx,(%rsi)
 29e61e2:	mov    0x2e0(%rsp),%r12
 29e61ea:	mov    0x20(%r12),%rsi
 29e61ef:	lea    (%rsi,%rdx,1),%rcx
 29e61f3:	movl   $0xb00300fa,(%rsi,%rdx,1)
 29e61fa:	mov    0x190(%rsp),%rdi
 29e6202:	mov    0x28(%rdi),%rdi
 29e6206:	mov    0x1d4(%rdi),%edi
 29e620c:	mov    %edi,0x4(%rsi,%rdx,1)
 29e6210:	mov    $0x50,%edi
 29e6215:	mov    %edi,0x8(%rsi,%rdx,1)
 29e6219:	mov    %eax,0xb0(%rsp)
 29e6220:	mov    0xd0(%rsp),%edi
 29e6227:	mov    %edi,0x10(%rcx)
 29e622a:	mov    0x130(%rsp),%r8d
 29e6232:	mov    %r8d,0x14(%rcx)
 29e6236:	mov    0xd8(%rsp),%r9d
 29e623e:	mov    %r9d,0x18(%rcx)
 29e6242:	mov    0x118(%rsp),%r10d
 29e624a:	mov    %r10d,0x1c(%rcx)
 29e624e:	mov    0x100(%rsp),%r11d
 29e6256:	mov    %r11d,0x20(%rcx)
 29e625a:	movl   $0x1,0x24(%rcx)
 29e6261:	movl   $0x0,0x28(%rcx)
 29e6268:	movl   $0x0,0x2c(%rcx)
 29e626f:	movl   $0x0,0x30(%rcx)
 29e6276:	movl   $0x0,0x34(%rcx)
 29e627d:	movl   $0x0,0x38(%rcx)
 29e6284:	movl   $0x0,0x3c(%rcx)
 29e628b:	movl   $0xffffffff,0x40(%rcx)
 29e6292:	movl   $0x0,0x44(%rcx)
 29e6299:	movl   $0x0,0x48(%rcx)
 29e62a0:	test   %r9d,%r9d
 29e62a3:	je     29fbdc9 <wasm[0]::function[1015]::helper::object_read+0x1aea9>
 29e62a9:	test   %eax,%eax
 29e62ab:	je     29fbdcb <wasm[0]::function[1015]::helper::object_read+0x1aeab>
 29e62b1:	test   %r9d,%r9d
 29e62b4:	je     29fbdcd <wasm[0]::function[1015]::helper::object_read+0x1aead>
 29e62ba:	mov    0x2e0(%rsp),%r12
 29e62c2:	mov    0x28(%r12),%rcx
 29e62c7:	mov    %r9d,%esi
 29e62ca:	mov    %rsi,%rdx
 29e62cd:	add    0x20(%r12),%rdx
 29e62d2:	xor    %rdi,%rdi
 29e62d5:	cmp    %rcx,%rsi
 29e62d8:	cmova  %rdi,%rdx
 29e62dc:	mov    %eax,0x1c(%rdx)
 29e62df:	movl   $0x0,0xd8(%rsp)
 29e62ea:	mov    0x2c0(%rsp),%rsi
 29e62f2:	mov    (%rsi),%eax
 29e62f4:	mov    %eax,%edx
 29e62f6:	lea    0x20(%rdx),%rcx
 29e62fa:	mov    0x4(%rsi),%esi
 29e62fd:	cmp    %rsi,%rcx
 29e6300:	ja     29fa8eb <wasm[0]::function[1015]::helper::object_read+0x199cb>
 29e6306:	lea    0x20(%rax),%ecx
 29e6309:	mov    0x2c0(%rsp),%rsi
 29e6311:	mov    %ecx,(%rsi)
 29e6313:	mov    0x2e0(%rsp),%r12
 29e631b:	mov    0x20(%r12),%rsi
 29e6320:	lea    (%rsi,%rdx,1),%rcx
 29e6324:	movl   $0xb0000042,(%rsi,%rdx,1)
 29e632b:	mov    0x190(%rsp),%rdi
 29e6333:	mov    0x28(%rdi),%rdi
 29e6337:	mov    0x120(%rdi),%edi
 29e633d:	mov    %edi,0x4(%rsi,%rdx,1)
 29e6341:	mov    0x2c8(%rsp),%rdi
 29e6349:	mov    %edi,0x8(%rsi,%rdx,1)
 29e634d:	mov    %eax,0x100(%rsp)
 29e6354:	mov    0x2d8(%rsp),%rax
 29e635c:	mov    %rax,0x10(%rcx)
 29e6360:	mov    0x2d0(%rsp),%rax
 29e6368:	mov    %eax,0x18(%rcx)
 29e636b:	mov    0x120(%rsp),%eax
 29e6372:	mov    %eax,0x1c(%rcx)
 29e6375:	mov    0x2c0(%rsp),%rsi
 29e637d:	mov    (%rsi),%eax
 29e637f:	mov    %eax,%ecx
 29e6381:	lea    0x20(%rcx),%rdx
 29e6385:	mov    0x4(%rsi),%esi
 29e6388:	cmp    %rsi,%rdx
 29e638b:	ja     29fa92e <wasm[0]::function[1015]::helper::object_read+0x19a0e>
 29e6391:	lea    0x20(%rax),%edx
 29e6394:	mov    0x2c0(%rsp),%rsi
 29e639c:	mov    %edx,(%rsi)
 29e639e:	mov    0x2e0(%rsp),%r12
 29e63a6:	mov    0x20(%r12),%rdx
 29e63ab:	lea    (%rdx,%rcx,1),%rsi
 29e63af:	movl   $0xb0000042,(%rdx,%rcx,1)
 29e63b6:	mov    0x190(%rsp),%rdi
 29e63be:	mov    0x28(%rdi),%rdi
 29e63c2:	mov    0x120(%rdi),%edi
 29e63c8:	mov    %edi,0x4(%rdx,%rcx,1)
 29e63cc:	mov    0x2c8(%rsp),%rdi
 29e63d4:	mov    %edi,0x8(%rdx,%rcx,1)
 29e63d8:	mov    %eax,0x118(%rsp)
 29e63df:	mov    0x1c0(%rsp),%r8
 29e63e7:	mov    %r8,0x10(%rsi)
 29e63eb:	mov    0x1b8(%rsp),%rcx
 29e63f3:	mov    %ecx,0x18(%rsi)
 29e63f6:	mov    0x110(%rsp),%ecx
 29e63fd:	mov    %ecx,0x1c(%rsi)
 29e6400:	mov    0x100(%rsp),%ecx
 29e6407:	test   %ecx,%ecx
 29e6409:	je     29fbdcf <wasm[0]::function[1015]::helper::object_read+0x1aeaf>
 29e640f:	test   %eax,%eax
 29e6411:	je     29fbdd1 <wasm[0]::function[1015]::helper::object_read+0x1aeb1>
 29e6417:	mov    0x2c0(%rsp),%rsi
 29e641f:	mov    (%rsi),%eax
 29e6421:	mov    %eax,%ecx
 29e6423:	lea    0x20(%rcx),%rdx
 29e6427:	mov    0x4(%rsi),%esi
 29e642a:	cmp    %rsi,%rdx
 29e642d:	ja     29fa971 <wasm[0]::function[1015]::helper::object_read+0x19a51>
 29e6433:	lea    0x20(%rax),%edx
 29e6436:	mov    0x2c0(%rsp),%rsi
 29e643e:	mov    %edx,(%rsi)
 29e6440:	mov    0x2e0(%rsp),%r12
 29e6448:	mov    0x20(%r12),%rsi
 29e644d:	lea    (%rsi,%rcx,1),%rdx
 29e6451:	movl   $0xa800000e,(%rsi,%rcx,1)
 29e6458:	mov    0x190(%rsp),%r9
 29e6460:	mov    0x28(%r9),%rdi
 29e6464:	mov    0x1b4(%rdi),%edi
 29e646a:	mov    %edi,0x4(%rsi,%rcx,1)
 29e646e:	mov    0x2c8(%rsp),%rdi
 29e6476:	mov    %edi,0x8(%rsi,%rcx,1)
 29e647a:	movl   $0x2,0x10(%rdx)
 29e6481:	test   %eax,%eax
 29e6483:	je     29fbdd3 <wasm[0]::function[1015]::helper::object_read+0x1aeb3>
 29e6489:	mov    0x2e0(%rsp),%r12
 29e6491:	mov    0x28(%r12),%rdi
 29e6496:	mov    0x20(%r12),%r8
 29e649b:	mov    %eax,%r9d
 29e649e:	lea    0x10(%r8,%r9,1),%rsi
 29e64a3:	xor    %rcx,%rcx
 29e64a6:	cmp    %rdi,%r9
 29e64a9:	cmova  %rcx,%rsi
 29e64ad:	mov    (%rsi),%edx
 29e64af:	test   %edx,%edx
 29e64b1:	je     29fbdd5 <wasm[0]::function[1015]::helper::object_read+0x1aeb5>
 29e64b7:	mov    %edx,%r9d
 29e64ba:	shl    $0x2,%r9
 29e64be:	shr    $0x20,%r9
 29e64c2:	test   %r9,%r9
 29e64c5:	jne    29fbdd7 <wasm[0]::function[1015]::helper::object_read+0x1aeb7>
 29e64cb:	shl    $0x2,%edx
 29e64ce:	add    $0x14,%edx
 29e64d1:	jb     29fbdd9 <wasm[0]::function[1015]::helper::object_read+0x1aeb9>
 29e64d7:	mov    %rax,%r10
 29e64da:	add    %edx,%r10d
 29e64dd:	jb     29fbddb <wasm[0]::function[1015]::helper::object_read+0x1aebb>
 29e64e3:	mov    0x100(%rsp),%r9d
 29e64eb:	mov    %r10d,%r10d
 29e64ee:	lea    (%r8,%r10,1),%r11
 29e64f2:	cmp    %rdi,%r10
 29e64f5:	cmova  %rcx,%r11
 29e64f9:	sub    $0x14,%edx
 29e64fc:	sub    %rdx,%r11
 29e64ff:	mov    %r9d,(%r11)
 29e6502:	mov    (%rsi),%esi
 29e6504:	cmp    $0x1,%esi
 29e6507:	jbe    29fbddd <wasm[0]::function[1015]::helper::object_read+0x1aebd>
 29e650d:	mov    %esi,%edx
 29e650f:	shl    $0x2,%rdx
 29e6513:	shr    $0x20,%rdx
 29e6517:	test   %rdx,%rdx
 29e651a:	jne    29fbddf <wasm[0]::function[1015]::helper::object_read+0x1aebf>
 29e6520:	shl    $0x2,%esi
 29e6523:	add    $0x14,%esi
 29e6526:	jb     29fbde1 <wasm[0]::function[1015]::helper::object_read+0x1aec1>
 29e652c:	mov    %rax,%r9
 29e652f:	add    %esi,%r9d
 29e6532:	jb     29fbde3 <wasm[0]::function[1015]::helper::object_read+0x1aec3>
 29e6538:	mov    0x118(%rsp),%edx
 29e653f:	mov    %r9d,%r9d
 29e6542:	add    %r9,%r8
 29e6545:	cmp    %rdi,%r9
 29e6548:	cmova  %rcx,%r8
 29e654c:	sub    $0x18,%esi
 29e654f:	sub    %rsi,%r8
 29e6552:	mov    %edx,(%r8)
 29e6555:	mov    0x190(%rsp),%rsi
 29e655d:	mov    0x8c0(%rsi),%edi
 29e6563:	mov    %edi,0x118(%rsp)
 29e656a:	xor    %r9d,%r9d
 29e656d:	test   %edi,%edi
 29e656f:	je     29fbde5 <wasm[0]::function[1015]::helper::object_read+0x1aec5>
 29e6575:	test   %eax,%eax
 29e6577:	je     29fbde7 <wasm[0]::function[1015]::helper::object_read+0x1aec7>
 29e657d:	mov    0x88(%rsp),%esi
 29e6584:	test   %esi,%esi
 29e6586:	je     29fbde9 <wasm[0]::function[1015]::helper::object_read+0x1aec9>
 29e658c:	mov    0xb0(%rsp),%r8d
 29e6594:	mov    0xd8(%rsp),%r11d
 29e659c:	mov    0x78(%rsp),%r10d
 29e65a1:	mov    $0x8,%edx
 29e65a6:	mov    %rcx,(%rsp)
 29e65aa:	mov    %r11d,0x8(%rsp)
 29e65af:	mov    %eax,0x10(%rsp)
 29e65b3:	mov    %edi,0x18(%rsp)
 29e65b7:	mov    %r10d,0x20(%rsp)
 29e65bc:	mov    %esi,0x28(%rsp)
 29e65c0:	mov    0x190(%rsp),%rsi
 29e65c8:	mov    0x190(%rsp),%rdi
 29e65d0:	call   2adef00 <wasm[0]::function[1055]::helper::proxy_call>
 29e65d5:	sub    $0x30,%rsp
 29e65d9:	mov    %rax,0x2a8(%rsp)
 29e65e1:	mov    %rcx,0x2b0(%rsp)
 29e65e9:	mov    %edx,0xb0(%rsp)
 29e65f0:	mov    0x118(%rsp),%eax
 29e65f7:	test   %eax,%eax
 29e65f9:	je     29fbdeb <wasm[0]::function[1015]::helper::object_read+0x1aecb>
 29e65ff:	mov    0x190(%rsp),%rcx
 29e6607:	mov    %eax,0x8c0(%rcx)
 29e660d:	cmp    $0x2,%esi
 29e6610:	jne    29e661b <wasm[0]::function[1015]::helper::object_read+0x56fb>
 29e6616:	xor    %esi,%esi
 29e6618:	mov    %rsi,%rdi
 29e661b:	cmp    $0x1,%esi
 29e661e:	je     29ec787 <wasm[0]::function[1015]::helper::object_read+0xb867>
 29e6624:	mov    0xa0(%rsp),%eax
 29e662b:	mov    0xe0(%rsp),%esi
 29e6632:	mov    0x78(%rsp),%edi
 29e6636:	mov    0x88(%rsp),%r8d
 29e663e:	mov    0x120(%rsp),%edx
 29e6645:	mov    0x110(%rsp),%ecx
 29e664c:	mov    0x2a8(%rsp),%r9
 29e6654:	mov    0x2a8(%rsp),%r10
 29e665c:	test   %r10d,%r9d
 29e665f:	je     29ec77f <wasm[0]::function[1015]::helper::object_read+0xb85f>
 29e6665:	mov    $0x12b,%edx
 29e666a:	mov    0x190(%rsp),%rsi
 29e6672:	mov    0x190(%rsp),%rdi
 29e667a:	call   2f307a0 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 29e667f:	mov    %eax,0xa0(%rsp)
 29e6686:	xor    %r13d,%r13d
 29e6689:	test   %eax,%eax
 29e668b:	je     29fbded <wasm[0]::function[1015]::helper::object_read+0x1aecd>
 29e6691:	movl   $0x0,0x118(%rsp)
 29e669c:	mov    0xb0(%rsp),%edx
 29e66a3:	mov    %rdx,0x220(%rsp)
 29e66ab:	mov    0xe0(%rsp),%edx
 29e66b2:	mov    0x78(%rsp),%esi
 29e66b6:	mov    0x88(%rsp),%edi
 29e66bd:	mov    0x120(%rsp),%r15d
 29e66c5:	mov    0x110(%rsp),%r8d
 29e66cd:	mov    0x2a8(%rsp),%rcx
 29e66d5:	cmp    $0x6,%ecx
 29e66d8:	sete   %cl
 29e66db:	mov    0x2a8(%rsp),%rax
 29e66e3:	cmp    $0x7,%eax
 29e66e6:	sete   %al
 29e66e9:	or     %eax,%ecx
 29e66eb:	mov    0x2a8(%rsp),%rax
 29e66f3:	cmp    $0x8,%eax
 29e66f6:	sete   %al
 29e66f9:	or     %eax,%ecx
 29e66fb:	mov    0x2a8(%rsp),%rax
 29e6703:	cmp    $0x9,%eax
 29e6706:	sete   %al
 29e6709:	or     %eax,%ecx
 29e670b:	xor    %r11,%r11
 29e670e:	test   %cl,%cl
 29e6710:	mov    %rcx,0x2a0(%rsp)
 29e6718:	jne    29e673e <wasm[0]::function[1015]::helper::object_read+0x581e>
 29e671e:	mov    0x220(%rsp),%rax
 29e6726:	mov    %r13,%r14
 29e6729:	mov    %r11,0x240(%rsp)
 29e6731:	mov    %r13,0x248(%rsp)
 29e6739:	jmp    29e7344 <wasm[0]::function[1015]::helper::object_read+0x6424>
 29e673e:	mov    0xb0(%rsp),%r8d
 29e6746:	mov    0x2b0(%rsp),%rcx
 29e674e:	mov    0x2a8(%rsp),%rdx
 29e6756:	mov    0x190(%rsp),%rsi
 29e675e:	mov    0x190(%rsp),%rdi
 29e6766:	call   2a5f620 <wasm[0]::function[1039]::helper::object_header_projection>
 29e676b:	mov    %eax,0xd8(%rsp)
 29e6772:	test   %eax,%eax
 29e6774:	je     29fbdef <wasm[0]::function[1015]::helper::object_read+0x1aecf>
 29e677a:	test   %eax,%eax
 29e677c:	je     29fbdf1 <wasm[0]::function[1015]::helper::object_read+0x1aed1>
 29e6782:	mov    0x2e0(%rsp),%r12
 29e678a:	mov    0x28(%r12),%rcx
 29e678f:	mov    0x20(%r12),%rsi
 29e6794:	mov    %eax,%edx
 29e6796:	lea    (%rsi,%rdx,1),%rax
 29e679a:	xor    %rsi,%rsi
 29e679d:	cmp    %rcx,%rdx
 29e67a0:	cmova  %rsi,%rax
 29e67a4:	mov    0x14(%rax),%eax
 29e67a7:	mov    %eax,0x100(%rsp)
 29e67ae:	test   %eax,%eax
 29e67b0:	je     29fbdf3 <wasm[0]::function[1015]::helper::object_read+0x1aed3>
 29e67b6:	mov    0x100(%rsp),%esi
 29e67bd:	xor    %eax,%eax
 29e67bf:	test   $0x1,%esi
 29e67c5:	jne    29e6823 <wasm[0]::function[1015]::helper::object_read+0x5903>
 29e67cb:	mov    0x2e0(%rsp),%r12
 29e67d3:	mov    0x28(%r12),%rdi
 29e67d8:	mov    0x20(%r12),%r9
 29e67dd:	mov    %esi,%r8d
 29e67e0:	lea    0x4(%r9,%r8,1),%rsi
 29e67e5:	xor    %r9,%r9
 29e67e8:	cmp    %rdi,%r8
 29e67eb:	cmova  %r9,%rsi
 29e67ef:	mov    (%rsi),%esi
 29e67f1:	mov    0x190(%rsp),%rcx
 29e67f9:	mov    0x28(%rcx),%r8
 29e67fd:	mov    0x158(%r8),%edx
 29e6804:	cmp    %edx,%esi
 29e6806:	sete   %r9b
 29e680a:	movzbl %r9b,%eax
 29e680e:	cmp    %edx,%esi
 29e6810:	je     29e6823 <wasm[0]::function[1015]::helper::object_read+0x5903>
 29e6816:	mov    0x190(%rsp),%rdi
 29e681e:	call   3018e75 <wasmtime_builtin_is_subtype>
 29e6823:	test   %eax,%eax
 29e6825:	jne    29e6a7f <wasm[0]::function[1015]::helper::object_read+0x5b5f>
 29e682b:	mov    0xd8(%rsp),%edx
 29e6832:	xor    %r12d,%r12d
 29e6835:	test   %edx,%edx
 29e6837:	je     29fbdf5 <wasm[0]::function[1015]::helper::object_read+0x1aed5>
 29e683d:	mov    0xa0(%rsp),%r9d
 29e6845:	mov    $0x4,%ecx
 29e684a:	xor    %r8,%r8
 29e684d:	mov    0x190(%rsp),%rsi
 29e6855:	mov    0x190(%rsp),%rdi
 29e685d:	call   2a58e20 <wasm[0]::function[1032]::helper::ordinary_property_find>
 29e6862:	test   %eax,%eax
 29e6864:	je     29e689f <wasm[0]::function[1015]::helper::object_read+0x597f>
 29e686a:	test   %eax,%eax
 29e686c:	je     29fbdf7 <wasm[0]::function[1015]::helper::object_read+0x1aed7>
 29e6872:	test   %eax,%eax
 29e6874:	je     29fbdf9 <wasm[0]::function[1015]::helper::object_read+0x1aed9>
 29e687a:	mov    0x2e0(%rsp),%r12
 29e6882:	mov    0x28(%r12),%rcx
 29e6887:	mov    %eax,%edx
 29e6889:	mov    %rdx,%rax
 29e688c:	add    0x20(%r12),%rax
 29e6891:	xor    %rsi,%rsi
 29e6894:	cmp    %rcx,%rdx
 29e6897:	cmova  %rsi,%rax
 29e689b:	mov    0x14(%rax),%r12d
 29e689f:	mov    0x118(%rsp),%r14d
 29e68a7:	xor    %r11,%r11
 29e68aa:	xor    %r13d,%r13d
 29e68ad:	test   %r12d,%r12d
 29e68b0:	je     29e6a39 <wasm[0]::function[1015]::helper::object_read+0x5b19>
 29e68b6:	test   %r12d,%r12d
 29e68b9:	je     29fbdfb <wasm[0]::function[1015]::helper::object_read+0x1aedb>
 29e68bf:	mov    0x2e0(%rsp),%rax
 29e68c7:	mov    0x28(%rax),%rcx
 29e68cb:	mov    0x20(%rax),%rax
 29e68cf:	mov    %r12d,%edx
 29e68d2:	add    %rdx,%rax
 29e68d5:	xor    %r11,%r11
 29e68d8:	cmp    %rcx,%rdx
 29e68db:	cmova  %r11,%rax
 29e68df:	mov    0x10(%rax),%ecx
 29e68e2:	mov    0x118(%rsp),%r14d
 29e68ea:	xor    %r13d,%r13d
 29e68ed:	test   $0x1,%ecx
 29e68f3:	jne    29e6a39 <wasm[0]::function[1015]::helper::object_read+0x5b19>
 29e68f9:	mov    0x14(%rax),%edx
 29e68fc:	test   %edx,%edx
 29e68fe:	je     29fbdfd <wasm[0]::function[1015]::helper::object_read+0x1aedd>
 29e6904:	xor    %esi,%esi
 29e6906:	test   $0x1,%edx
 29e690c:	jne    29e6950 <wasm[0]::function[1015]::helper::object_read+0x5a30>
 29e6912:	mov    0x2e0(%rsp),%r12
 29e691a:	mov    0x28(%r12),%rax
 29e691f:	mov    0x20(%r12),%rcx
 29e6924:	mov    %edx,%esi
 29e6926:	lea    0x4(%rcx,%rsi,1),%rcx
 29e692b:	xor    %rdi,%rdi
 29e692e:	cmp    %rax,%rsi
 29e6931:	cmova  %rdi,%rcx
 29e6935:	mov    (%rcx),%eax
 29e6937:	mov    0x190(%rsp),%rcx
 29e693f:	mov    0x28(%rcx),%rcx
 29e6943:	cmp    0x120(%rcx),%eax
 29e6949:	sete   %al
 29e694c:	rex movzbl %al,%esi
 29e6950:	test   %esi,%esi
 29e6952:	jne    29e69b0 <wasm[0]::function[1015]::helper::object_read+0x5a90>
 29e6958:	mov    0x190(%rsp),%rsi
 29e6960:	mov    0x190(%rsp),%rdi
 29e6968:	call   2a01ba0 <wasm[0]::function[1024]::helper::property_value_resolve>
 29e696d:	test   %eax,%eax
 29e696f:	je     29fbdff <wasm[0]::function[1015]::helper::object_read+0x1aedf>
 29e6975:	test   %eax,%eax
 29e6977:	je     29fbe01 <wasm[0]::function[1015]::helper::object_read+0x1aee1>
 29e697d:	mov    0x2e0(%rsp),%r12
 29e6985:	mov    0x28(%r12),%rcx
 29e698a:	mov    0x20(%r12),%rsi
 29e698f:	mov    %eax,%edx
 29e6991:	lea    (%rsi,%rdx,1),%rax
 29e6995:	xor    %rsi,%rsi
 29e6998:	cmp    %rcx,%rdx
 29e699b:	cmova  %rsi,%rax
 29e699f:	mov    0x18(%rax),%r13d
 29e69a3:	mov    0x10(%rax),%r11
 29e69a7:	mov    0x1c(%rax),%r14d
 29e69ab:	jmp    29e6a39 <wasm[0]::function[1015]::helper::object_read+0x5b19>
 29e69b0:	xor    %eax,%eax
 29e69b2:	test   $0x1,%edx
 29e69b8:	jne    29e69fb <wasm[0]::function[1015]::helper::object_read+0x5adb>
 29e69be:	mov    0x2e0(%rsp),%r12
 29e69c6:	mov    0x28(%r12),%rax
 29e69cb:	mov    0x20(%r12),%rcx
 29e69d0:	mov    %edx,%esi
 29e69d2:	lea    0x4(%rcx,%rsi,1),%rcx
 29e69d7:	xor    %rdi,%rdi
 29e69da:	cmp    %rax,%rsi
 29e69dd:	cmova  %rdi,%rcx
 29e69e1:	mov    (%rcx),%eax
 29e69e3:	mov    0x190(%rsp),%rcx
 29e69eb:	mov    0x28(%rcx),%rcx
 29e69ef:	cmp    0x120(%rcx),%eax
 29e69f5:	sete   %al
 29e69f8:	movzbl %al,%eax
 29e69fb:	test   %eax,%eax
 29e69fd:	je     29fbe03 <wasm[0]::function[1015]::helper::object_read+0x1aee3>
 29e6a03:	test   %edx,%edx
 29e6a05:	je     29fbe05 <wasm[0]::function[1015]::helper::object_read+0x1aee5>
 29e6a0b:	mov    0x2e0(%rsp),%r12
 29e6a13:	mov    0x28(%r12),%rcx
 29e6a18:	mov    0x20(%r12),%rsi
 29e6a1d:	mov    %edx,%edx
 29e6a1f:	lea    (%rsi,%rdx,1),%rax
 29e6a23:	xor    %rsi,%rsi
 29e6a26:	cmp    %rcx,%rdx
 29e6a29:	cmova  %rsi,%rax
 29e6a2d:	mov    0x18(%rax),%r13d
 29e6a31:	mov    0x10(%rax),%r11
 29e6a35:	mov    0x1c(%rax),%r14d
 29e6a39:	mov    0xb0(%rsp),%edx
 29e6a40:	mov    %rdx,0x220(%rsp)
 29e6a48:	mov    0xe0(%rsp),%edx
 29e6a4f:	mov    0x78(%rsp),%esi
 29e6a53:	mov    0x88(%rsp),%edi
 29e6a5a:	mov    0x120(%rsp),%r15d
 29e6a62:	mov    0x110(%rsp),%r8d
 29e6a6a:	mov    %r11,0x240(%rsp)
 29e6a72:	mov    %r13,0x248(%rsp)
 29e6a7a:	jmp    29e733c <wasm[0]::function[1015]::helper::object_read+0x641c>
 29e6a7f:	mov    0x100(%rsp),%esi
 29e6a86:	test   %esi,%esi
 29e6a88:	je     29fbe07 <wasm[0]::function[1015]::helper::object_read+0x1aee7>
 29e6a8e:	mov    0x100(%rsp),%r9d
 29e6a96:	xor    %eax,%eax
 29e6a98:	test   $0x1,%r9d
 29e6a9f:	jne    29e6afb <wasm[0]::function[1015]::helper::object_read+0x5bdb>
 29e6aa5:	mov    0x2e0(%rsp),%r12
 29e6aad:	mov    0x28(%r12),%rax
 29e6ab2:	mov    0x20(%r12),%rdx
 29e6ab7:	mov    %r9d,%ecx
 29e6aba:	lea    0x4(%rdx,%rcx,1),%r9
 29e6abf:	xor    %rdx,%rdx
 29e6ac2:	cmp    %rax,%rcx
 29e6ac5:	cmova  %rdx,%r9
 29e6ac9:	mov    (%r9),%esi
 29e6acc:	mov    0x190(%rsp),%rcx
 29e6ad4:	mov    0x28(%rcx),%rax
 29e6ad8:	mov    0x158(%rax),%edx
 29e6ade:	cmp    %edx,%esi
 29e6ae0:	sete   %al
 29e6ae3:	movzbl %al,%eax
 29e6ae6:	cmp    %edx,%esi
 29e6ae8:	je     29e6afb <wasm[0]::function[1015]::helper::object_read+0x5bdb>
 29e6aee:	mov    0x190(%rsp),%rdi
 29e6af6:	call   3018e75 <wasmtime_builtin_is_subtype>
 29e6afb:	test   %eax,%eax
 29e6afd:	je     29fbe09 <wasm[0]::function[1015]::helper::object_read+0x1aee9>
 29e6b03:	mov    0x100(%rsp),%r10d
 29e6b0b:	mov    0xb0(%rsp),%edx
 29e6b12:	mov    %rdx,0x220(%rsp)
 29e6b1a:	mov    0x118(%rsp),%r14d
 29e6b22:	mov    0xe0(%rsp),%edx
 29e6b29:	mov    0x78(%rsp),%esi
 29e6b2d:	mov    0x88(%rsp),%edi
 29e6b34:	mov    0x120(%rsp),%r15d
 29e6b3c:	mov    0x110(%rsp),%r8d
 29e6b44:	xor    %ecx,%ecx
 29e6b46:	mov    %rcx,0x250(%rsp)
 29e6b4e:	test   %r10d,%r10d
 29e6b51:	je     29fbe0b <wasm[0]::function[1015]::helper::object_read+0x1aeeb>
 29e6b57:	test   %r10d,%r10d
 29e6b5a:	je     29fbe0d <wasm[0]::function[1015]::helper::object_read+0x1aeed>
 29e6b60:	mov    0x2e0(%rsp),%r12
 29e6b68:	mov    0x28(%r12),%rax
 29e6b6d:	mov    0x20(%r12),%rcx
 29e6b72:	mov    %r10d,%r12d
 29e6b75:	lea    (%rcx,%r12,1),%r11
 29e6b79:	xor    %rbx,%rbx
 29e6b7c:	cmp    %rax,%r12
 29e6b7f:	cmova  %rbx,%r11
 29e6b83:	mov    0x10(%r11),%r11d
 29e6b87:	test   %r11d,%r11d
 29e6b8a:	je     29fbe0f <wasm[0]::function[1015]::helper::object_read+0x1aeef>
 29e6b90:	test   %r11d,%r11d
 29e6b93:	je     29fbe11 <wasm[0]::function[1015]::helper::object_read+0x1aef1>
 29e6b99:	mov    %r11d,%r12d
 29e6b9c:	lea    (%rcx,%r12,1),%r11
 29e6ba0:	cmp    %rax,%r12
 29e6ba3:	cmova  %rbx,%r11
 29e6ba7:	mov    0x10(%r11),%r11d
 29e6bab:	test   %r11d,%r11d
 29e6bae:	je     29fbe13 <wasm[0]::function[1015]::helper::object_read+0x1aef3>
 29e6bb4:	test   %r11d,%r11d
 29e6bb7:	je     29fbe15 <wasm[0]::function[1015]::helper::object_read+0x1aef5>
 29e6bbd:	mov    %r11d,%r12d
 29e6bc0:	lea    0x10(%rcx,%r12,1),%rcx
 29e6bc5:	cmp    %rax,%r12
 29e6bc8:	cmova  %rbx,%rcx
 29e6bcc:	mov    (%rcx),%ebx
 29e6bce:	mov    0xa0(%rsp),%r12d
 29e6bd6:	mov    0x190(%rsp),%rcx
 29e6bde:	mov    0x28(%rcx),%rax
 29e6be2:	mov    0x234(%rax),%r13d
 29e6be9:	mov    0x250(%rsp),%rax
 29e6bf1:	mov    %rax,0x218(%rsp)
 29e6bf9:	mov    %r11d,0x130(%rsp)
 29e6c01:	mov    %r12d,0xd8(%rsp)
 29e6c09:	mov    %r10d,0x110(%rsp)
 29e6c11:	mov    0x220(%rsp),%rax
 29e6c19:	mov    %eax,0x120(%rsp)
 29e6c20:	mov    %r14d,0x88(%rsp)
 29e6c28:	mov    %edx,0x78(%rsp)
 29e6c2c:	mov    %esi,0xe0(%rsp)
 29e6c33:	mov    %edi,0x118(%rsp)
 29e6c3a:	mov    %r15d,0x100(%rsp)
 29e6c42:	mov    %r8d,0xa0(%rsp)
 29e6c4a:	mov    0x2e8(%rsp),%rax
 29e6c52:	mov    (%rax),%rcx
 29e6c55:	mov    0x228(%rsp),%rax
 29e6c5d:	cmp    %rax,%rcx
 29e6c60:	jae    29fa9b4 <wasm[0]::function[1015]::helper::object_read+0x19a94>
 29e6c66:	mov    0x110(%rsp),%r10d
 29e6c6e:	mov    0x120(%rsp),%edx
 29e6c75:	mov    %rdx,0x220(%rsp)
 29e6c7d:	mov    0x88(%rsp),%r14d
 29e6c85:	mov    0x78(%rsp),%edx
 29e6c89:	mov    0xe0(%rsp),%esi
 29e6c90:	mov    0x118(%rsp),%edi
 29e6c97:	mov    0x100(%rsp),%r15d
 29e6c9f:	mov    0xa0(%rsp),%r8d
 29e6ca7:	mov    0x250(%rsp),%rcx
 29e6caf:	cmp    %ebx,%ecx
 29e6cb1:	jb     29e6cc4 <wasm[0]::function[1015]::helper::object_read+0x5da4>
 29e6cb7:	mov    0x218(%rsp),%rax
 29e6cbf:	jmp    29e6ed5 <wasm[0]::function[1015]::helper::object_read+0x5fb5>
 29e6cc4:	mov    0x130(%rsp),%eax
 29e6ccb:	test   %eax,%eax
 29e6ccd:	je     29fbe17 <wasm[0]::function[1015]::helper::object_read+0x1aef7>
 29e6cd3:	test   %eax,%eax
 29e6cd5:	je     29fbe19 <wasm[0]::function[1015]::helper::object_read+0x1aef9>
 29e6cdb:	mov    0x2e0(%rsp),%r12
 29e6ce3:	mov    0x28(%r12),%rdx
 29e6ce8:	mov    0x20(%r12),%rsi
 29e6ced:	mov    %eax,%r9d
 29e6cf0:	lea    0x10(%rsi,%r9,1),%r8
 29e6cf5:	xor    %rdi,%rdi
 29e6cf8:	cmp    %rdx,%r9
 29e6cfb:	cmova  %rdi,%r8
 29e6cff:	mov    (%r8),%r8d
 29e6d02:	cmp    %r8d,%ecx
 29e6d05:	jae    29fbe1b <wasm[0]::function[1015]::helper::object_read+0x1aefb>
 29e6d0b:	mov    %r8d,%r9d
 29e6d0e:	shl    $0x2,%r9
 29e6d12:	shr    $0x20,%r9
 29e6d16:	test   %r9,%r9
 29e6d19:	jne    29fbe1d <wasm[0]::function[1015]::helper::object_read+0x1aefd>
 29e6d1f:	shl    $0x2,%r8d
 29e6d23:	add    $0x14,%r8d
 29e6d27:	jb     29fbe1f <wasm[0]::function[1015]::helper::object_read+0x1aeff>
 29e6d2d:	add    %r8d,%eax
 29e6d30:	jb     29fbe21 <wasm[0]::function[1015]::helper::object_read+0x1af01>
 29e6d36:	mov    %eax,%r9d
 29e6d39:	add    %r9,%rsi
 29e6d3c:	cmp    %rdx,%r9
 29e6d3f:	cmova  %rdi,%rsi
 29e6d43:	mov    %rcx,%rdi
 29e6d46:	shl    $0x2,%edi
 29e6d49:	mov    %rcx,0x250(%rsp)
 29e6d51:	add    $0x14,%edi
 29e6d57:	sub    %edi,%r8d
 29e6d5a:	sub    %r8,%rsi
 29e6d5d:	mov    (%rsi),%edx
 29e6d5f:	test   %edx,%edx
 29e6d61:	je     29fbe23 <wasm[0]::function[1015]::helper::object_read+0x1af03>
 29e6d67:	mov    0xd8(%rsp),%eax
 29e6d6e:	cmp    %eax,%edx
 29e6d70:	je     29e6e44 <wasm[0]::function[1015]::helper::object_read+0x5f24>
 29e6d76:	xor    %ecx,%ecx
 29e6d78:	test   %edx,%edx
 29e6d7a:	je     29e6dbc <wasm[0]::function[1015]::helper::object_read+0x5e9c>
 29e6d80:	xor    %ecx,%ecx
 29e6d82:	test   $0x1,%edx
 29e6d88:	jne    29e6dbc <wasm[0]::function[1015]::helper::object_read+0x5e9c>
 29e6d8e:	mov    0x2e0(%rsp),%r12
 29e6d96:	mov    0x28(%r12),%rcx
 29e6d9b:	mov    0x20(%r12),%rsi
 29e6da0:	mov    %edx,%edi
 29e6da2:	lea    0x4(%rsi,%rdi,1),%rsi
 29e6da7:	xor    %r8,%r8
 29e6daa:	cmp    %rcx,%rdi
 29e6dad:	cmova  %r8,%rsi
 29e6db1:	mov    (%rsi),%ecx
 29e6db3:	cmp    %r13d,%ecx
 29e6db6:	sete   %cl
 29e6db9:	movzbl %cl,%ecx
 29e6dbc:	test   %ecx,%ecx
 29e6dbe:	je     29fbe25 <wasm[0]::function[1015]::helper::object_read+0x1af05>
 29e6dc4:	xor    %ecx,%ecx
 29e6dc6:	test   %eax,%eax
 29e6dc8:	je     29e6e10 <wasm[0]::function[1015]::helper::object_read+0x5ef0>
 29e6dce:	mov    0xd8(%rsp),%eax
 29e6dd5:	xor    %ecx,%ecx
 29e6dd7:	test   $0x1,%eax
 29e6ddc:	jne    29e6e10 <wasm[0]::function[1015]::helper::object_read+0x5ef0>
 29e6de2:	mov    0x2e0(%rsp),%r12
 29e6dea:	mov    0x28(%r12),%rcx
 29e6def:	mov    0x20(%r12),%rdi
 29e6df4:	mov    %eax,%esi
 29e6df6:	lea    0x4(%rdi,%rsi,1),%rax
 29e6dfb:	xor    %rdi,%rdi
 29e6dfe:	cmp    %rcx,%rsi
 29e6e01:	cmova  %rdi,%rax
 29e6e05:	mov    (%rax),%eax
 29e6e07:	cmp    %r13d,%eax
 29e6e0a:	sete   %al
 29e6e0d:	movzbl %al,%ecx
 29e6e10:	test   %ecx,%ecx
 29e6e12:	je     29fbe27 <wasm[0]::function[1015]::helper::object_read+0x1af07>
 29e6e18:	mov    0xd8(%rsp),%ecx
 29e6e1f:	xor    %r8d,%r8d
 29e6e22:	test   %ecx,%ecx
 29e6e24:	je     29fbe29 <wasm[0]::function[1015]::helper::object_read+0x1af09>
 29e6e2a:	mov    0x190(%rsp),%rsi
 29e6e32:	mov    0x190(%rsp),%rdi
 29e6e3a:	call   2ae54e0 <wasm[0]::function[1057]::helper::string_equality>
 29e6e3f:	jmp    29e6e4c <wasm[0]::function[1015]::helper::object_read+0x5f2c>
 29e6e44:	mov    0x278(%rsp),%rax
 29e6e4c:	mov    0x130(%rsp),%r11d
 29e6e54:	mov    0xd8(%rsp),%r12d
 29e6e5c:	mov    0x110(%rsp),%r10d
 29e6e64:	mov    0x120(%rsp),%edx
 29e6e6b:	mov    %rdx,0x220(%rsp)
 29e6e73:	mov    0x88(%rsp),%r14d
 29e6e7b:	mov    0x78(%rsp),%edx
 29e6e7f:	mov    0xe0(%rsp),%esi
 29e6e86:	mov    0x118(%rsp),%edi
 29e6e8d:	mov    0x100(%rsp),%r15d
 29e6e95:	mov    0xa0(%rsp),%r8d
 29e6e9d:	test   %eax,%eax
 29e6e9f:	je     29e6eb2 <wasm[0]::function[1015]::helper::object_read+0x5f92>
 29e6ea5:	mov    0x250(%rsp),%rcx
 29e6ead:	jmp    29e6ed5 <wasm[0]::function[1015]::helper::object_read+0x5fb5>
 29e6eb2:	mov    0x250(%rsp),%rcx
 29e6eba:	add    $0x1,%ecx
 29e6ec0:	mov    %rax,0x218(%rsp)
 29e6ec8:	mov    %rcx,0x250(%rsp)
 29e6ed0:	jmp    29e6bf9 <wasm[0]::function[1015]::helper::object_read+0x5cd9>
 29e6ed5:	xor    %r11,%r11
 29e6ed8:	xor    %r13d,%r13d
 29e6edb:	test   %eax,%eax
 29e6edd:	jne    29e6ef8 <wasm[0]::function[1015]::helper::object_read+0x5fd8>
 29e6ee3:	mov    %r11,0x240(%rsp)
 29e6eeb:	mov    %r13,0x248(%rsp)
 29e6ef3:	jmp    29e733c <wasm[0]::function[1015]::helper::object_read+0x641c>
 29e6ef8:	test   %r10d,%r10d
 29e6efb:	je     29fbe2b <wasm[0]::function[1015]::helper::object_read+0x1af0b>
 29e6f01:	xor    %eax,%eax
 29e6f03:	test   $0x1,%r10d
 29e6f0a:	jne    29e6f50 <wasm[0]::function[1015]::helper::object_read+0x6030>
 29e6f10:	mov    0x2e0(%rsp),%r12
 29e6f18:	mov    0x28(%r12),%rax
 29e6f1d:	mov    0x20(%r12),%r11
 29e6f22:	mov    %r10d,%ebx
 29e6f25:	lea    0x4(%r11,%rbx,1),%r11
 29e6f2a:	xor    %r12,%r12
 29e6f2d:	cmp    %rax,%rbx
 29e6f30:	cmova  %r12,%r11
 29e6f34:	mov    (%r11),%eax
 29e6f37:	mov    0x190(%rsp),%r9
 29e6f3f:	mov    0x28(%r9),%r9
 29e6f43:	cmp    0x160(%r9),%eax
 29e6f4a:	sete   %al
 29e6f4d:	movzbl %al,%eax
 29e6f50:	test   %eax,%eax
 29e6f52:	jne    29e71b6 <wasm[0]::function[1015]::helper::object_read+0x6296>
 29e6f58:	xor    %eax,%eax
 29e6f5a:	test   $0x1,%r10d
 29e6f61:	jne    29e6fa9 <wasm[0]::function[1015]::helper::object_read+0x6089>
 29e6f67:	mov    0x2e0(%rsp),%r12
 29e6f6f:	mov    0x28(%r12),%r11
 29e6f74:	mov    0x20(%r12),%rax
 29e6f79:	mov    %r10d,%ebx
 29e6f7c:	lea    0x4(%rax,%rbx,1),%rax
 29e6f81:	xor    %r12,%r12
 29e6f84:	cmp    %r11,%rbx
 29e6f87:	cmova  %r12,%rax
 29e6f8b:	mov    (%rax),%r11d
 29e6f8e:	mov    0x190(%rsp),%rax
 29e6f96:	mov    0x28(%rax),%r9
 29e6f9a:	cmp    0x15c(%r9),%r11d
 29e6fa1:	sete   %r9b
 29e6fa5:	movzbl %r9b,%eax
 29e6fa9:	test   %eax,%eax
 29e6fab:	je     29fbe2d <wasm[0]::function[1015]::helper::object_read+0x1af0d>
 29e6fb1:	test   %r10d,%r10d
 29e6fb4:	je     29fbe2f <wasm[0]::function[1015]::helper::object_read+0x1af0f>
 29e6fba:	mov    0x2e0(%rsp),%r12
 29e6fc2:	mov    0x28(%r12),%rax
 29e6fc7:	mov    0x20(%r12),%r12
 29e6fcc:	mov    %r10d,%r13d
 29e6fcf:	lea    (%r12,%r13,1),%r10
 29e6fd3:	xor    %r11,%r11
 29e6fd6:	cmp    %rax,%r13
 29e6fd9:	cmova  %r11,%r10
 29e6fdd:	mov    0x14(%r10),%ebx
 29e6fe1:	mov    0x18(%r10),%r13d
 29e6fe5:	mov    0x1c(%r10),%r10d
 29e6fe9:	test   %ebx,%ebx
 29e6feb:	je     29fbe31 <wasm[0]::function[1015]::helper::object_read+0x1af11>
 29e6ff1:	test   %ebx,%ebx
 29e6ff3:	je     29fbe33 <wasm[0]::function[1015]::helper::object_read+0x1af13>
 29e6ff9:	mov    %ebx,%r9d
 29e6ffc:	lea    0x10(%r12,%r9,1),%r14
 29e7001:	cmp    %rax,%r9
 29e7004:	cmova  %r11,%r14
 29e7008:	mov    (%r14),%r14d
 29e700b:	cmp    %r14d,%ecx
 29e700e:	jae    29fbe35 <wasm[0]::function[1015]::helper::object_read+0x1af15>
 29e7014:	mov    %r14d,%r9d
 29e7017:	shr    $0x20,%r9
 29e701b:	test   %r9,%r9
 29e701e:	jne    29fbe37 <wasm[0]::function[1015]::helper::object_read+0x1af17>
 29e7024:	add    $0x14,%r14d
 29e7028:	jb     29fbe39 <wasm[0]::function[1015]::helper::object_read+0x1af19>
 29e702e:	add    %r14d,%ebx
 29e7031:	jb     29fbe3b <wasm[0]::function[1015]::helper::object_read+0x1af1b>
 29e7037:	mov    %ebx,%r9d
 29e703a:	lea    (%r12,%r9,1),%rbx
 29e703e:	cmp    %rax,%r9
 29e7041:	cmova  %r11,%rbx
 29e7045:	lea    0x14(%rcx),%eax
 29e7048:	sub    %eax,%r14d
 29e704b:	sub    %r14,%rbx
 29e704e:	movzbq (%rbx),%r9
 29e7052:	mov    %r9,0x258(%rsp)
 29e705a:	test   %r13d,%r13d
 29e705d:	je     29e70f2 <wasm[0]::function[1015]::helper::object_read+0x61d2>
 29e7063:	test   %r13d,%r13d
 29e7066:	je     29fbe3d <wasm[0]::function[1015]::helper::object_read+0x1af1d>
 29e706c:	test   %r13d,%r13d
 29e706f:	je     29fbe3f <wasm[0]::function[1015]::helper::object_read+0x1af1f>
 29e7075:	mov    0x2e0(%rsp),%r12
 29e707d:	mov    0x28(%r12),%rax
 29e7082:	mov    0x20(%r12),%r11
 29e7087:	mov    %r13d,%ebx
 29e708a:	lea    0x10(%r11,%rbx,1),%r14
 29e708f:	xor    %r12,%r12
 29e7092:	cmp    %rax,%rbx
 29e7095:	cmova  %r12,%r14
 29e7099:	mov    (%r14),%r14d
 29e709c:	cmp    %r14d,%ecx
 29e709f:	jae    29fbe41 <wasm[0]::function[1015]::helper::object_read+0x1af21>
 29e70a5:	mov    %r14d,%ebx
 29e70a8:	shl    $0x3,%rbx
 29e70ac:	shr    $0x20,%rbx
 29e70b0:	test   %rbx,%rbx
 29e70b3:	jne    29fbe43 <wasm[0]::function[1015]::helper::object_read+0x1af23>
 29e70b9:	shl    $0x3,%r14d
 29e70bd:	add    $0x18,%r14d
 29e70c1:	jb     29fbe45 <wasm[0]::function[1015]::helper::object_read+0x1af25>
 29e70c7:	add    %r14d,%r13d
 29e70ca:	jb     29fbe47 <wasm[0]::function[1015]::helper::object_read+0x1af27>
 29e70d0:	mov    %r13d,%r9d
 29e70d3:	add    %r9,%r11
 29e70d6:	cmp    %rax,%r9
 29e70d9:	cmova  %r12,%r11
 29e70dd:	mov    %rcx,%rax
 29e70e0:	shl    $0x3,%eax
 29e70e3:	add    $0x18,%eax
 29e70e9:	sub    %eax,%r14d
 29e70ec:	sub    %r14,%r11
 29e70ef:	mov    (%r11),%r11
 29e70f2:	xor    %r14d,%r14d
 29e70f5:	test   %r10d,%r10d
 29e70f8:	jne    29e710b <wasm[0]::function[1015]::helper::object_read+0x61eb>
 29e70fe:	mov    0x258(%rsp),%r9
 29e7106:	jmp    29e719d <wasm[0]::function[1015]::helper::object_read+0x627d>
 29e710b:	test   %r10d,%r10d
 29e710e:	je     29fbe49 <wasm[0]::function[1015]::helper::object_read+0x1af29>
 29e7114:	test   %r10d,%r10d
 29e7117:	je     29fbe4b <wasm[0]::function[1015]::helper::object_read+0x1af2b>
 29e711d:	mov    0x2e0(%rsp),%r12
 29e7125:	mov    0x28(%r12),%rax
 29e712a:	mov    0x20(%r12),%r12
 29e712f:	mov    %r10d,%ebx
 29e7132:	lea    0x10(%r12,%rbx,1),%r14
 29e7137:	xor    %r13,%r13
 29e713a:	cmp    %rax,%rbx
 29e713d:	cmova  %r13,%r14
 29e7141:	mov    (%r14),%r14d
 29e7144:	cmp    %r14d,%ecx
 29e7147:	jae    29fbe4d <wasm[0]::function[1015]::helper::object_read+0x1af2d>
 29e714d:	mov    %r14d,%ebx
 29e7150:	shl    $0x2,%rbx
 29e7154:	shr    $0x20,%rbx
 29e7158:	test   %rbx,%rbx
 29e715b:	jne    29fbe4f <wasm[0]::function[1015]::helper::object_read+0x1af2f>
 29e7161:	shl    $0x2,%r14d
 29e7165:	add    $0x14,%r14d
 29e7169:	jb     29fbe51 <wasm[0]::function[1015]::helper::object_read+0x1af31>
 29e716f:	add    %r14d,%r10d
 29e7172:	jb     29fbe53 <wasm[0]::function[1015]::helper::object_read+0x1af33>
 29e7178:	mov    %r10d,%r9d
 29e717b:	lea    (%r12,%r9,1),%r10
 29e717f:	cmp    %rax,%r9
 29e7182:	cmova  %r13,%r10
 29e7186:	shl    $0x2,%ecx
 29e7189:	lea    0x14(%rcx),%eax
 29e718c:	sub    %eax,%r14d
 29e718f:	sub    %r14,%r10
 29e7192:	mov    (%r10),%r14d
 29e7195:	mov    0x258(%rsp),%r9
 29e719d:	movzbl %r9b,%r13d
 29e71a1:	mov    %r11,0x240(%rsp)
 29e71a9:	mov    %r13,0x248(%rsp)
 29e71b1:	jmp    29e733c <wasm[0]::function[1015]::helper::object_read+0x641c>
 29e71b6:	xor    %eax,%eax
 29e71b8:	test   $0x1,%r10d
 29e71bf:	jne    29e7205 <wasm[0]::function[1015]::helper::object_read+0x62e5>
 29e71c5:	mov    0x2e0(%rsp),%r12
 29e71cd:	mov    0x28(%r12),%rax
 29e71d2:	mov    0x20(%r12),%r9
 29e71d7:	mov    %r10d,%ebx
 29e71da:	lea    0x4(%r9,%rbx,1),%r11
 29e71df:	xor    %r12,%r12
 29e71e2:	cmp    %rax,%rbx
 29e71e5:	cmova  %r12,%r11
 29e71e9:	mov    (%r11),%eax
 29e71ec:	mov    0x190(%rsp),%r9
 29e71f4:	mov    0x28(%r9),%r9
 29e71f8:	cmp    0x160(%r9),%eax
 29e71ff:	sete   %al
 29e7202:	movzbl %al,%eax
 29e7205:	test   %eax,%eax
 29e7207:	je     29fbe55 <wasm[0]::function[1015]::helper::object_read+0x1af35>
 29e720d:	test   %r10d,%r10d
 29e7210:	je     29fbe57 <wasm[0]::function[1015]::helper::object_read+0x1af37>
 29e7216:	mov    0x2e0(%rsp),%r12
 29e721e:	mov    0x28(%r12),%r11
 29e7223:	mov    0x20(%r12),%rax
 29e7228:	mov    %r10d,%r10d
 29e722b:	lea    (%rax,%r10,1),%rbx
 29e722f:	xor    %r12,%r12
 29e7232:	cmp    %r11,%r10
 29e7235:	cmova  %r12,%rbx
 29e7239:	mov    0x10(%rbx),%r13d
 29e723d:	test   %r13d,%r13d
 29e7240:	je     29fbe59 <wasm[0]::function[1015]::helper::object_read+0x1af39>
 29e7246:	test   %r13d,%r13d
 29e7249:	je     29fbe5b <wasm[0]::function[1015]::helper::object_read+0x1af3b>
 29e724f:	mov    %r13d,%r9d
 29e7252:	lea    (%rax,%r9,1),%r13
 29e7256:	cmp    %r11,%r9
 29e7259:	cmova  %r12,%r13
 29e725d:	mov    0x10(%r13),%r13d
 29e7261:	test   %r13d,%r13d
 29e7264:	je     29fbe5d <wasm[0]::function[1015]::helper::object_read+0x1af3d>
 29e726a:	test   %r13d,%r13d
 29e726d:	je     29fbe5f <wasm[0]::function[1015]::helper::object_read+0x1af3f>
 29e7273:	mov    %r13d,%r9d
 29e7276:	lea    0x10(%rax,%r9,1),%rax
 29e727b:	cmp    %r11,%r9
 29e727e:	cmova  %r12,%rax
 29e7282:	cmp    (%rax),%ecx
 29e7284:	setae  %al
 29e7287:	cmp    $0x2,%ecx
 29e728a:	setae  %r9b
 29e728e:	or     %r9d,%eax
 29e7291:	test   %al,%al
 29e7293:	jne    29fbe61 <wasm[0]::function[1015]::helper::object_read+0x1af41>
 29e7299:	mov    0x2e0(%rsp),%r12
 29e72a1:	mov    0x28(%r12),%r11
 29e72a6:	mov    %r10,%rax
 29e72a9:	add    0x20(%r12),%rax
 29e72ae:	xor    %rbx,%rbx
 29e72b1:	cmp    %r11,%r10
 29e72b4:	cmova  %rbx,%rax
 29e72b8:	mov    0x14(%rax),%r13d
 29e72bc:	test   %ecx,%ecx
 29e72be:	je     29e72f8 <wasm[0]::function[1015]::helper::object_read+0x63d8>
 29e72c4:	mov    0x2e0(%rsp),%r12
 29e72cc:	mov    0x28(%r12),%r11
 29e72d1:	mov    0x20(%r12),%rax
 29e72d6:	add    %r10,%rax
 29e72d9:	xor    %rbx,%rbx
 29e72dc:	cmp    %r11,%r10
 29e72df:	cmova  %rbx,%rax
 29e72e3:	mov    0x20(%rax),%r11
 29e72e7:	mov    0x2c(%rax),%r14d
 29e72eb:	mov    %r11,0x240(%rsp)
 29e72f3:	jmp    29e7327 <wasm[0]::function[1015]::helper::object_read+0x6407>
 29e72f8:	mov    0x2e0(%rsp),%r12
 29e7300:	mov    0x28(%r12),%r11
 29e7305:	mov    0x20(%r12),%rax
 29e730a:	add    %r10,%rax
 29e730d:	xor    %rbx,%rbx
 29e7310:	cmp    %r11,%r10
 29e7313:	cmova  %rbx,%rax
 29e7317:	mov    0x18(%rax),%r11
 29e731b:	mov    %r11,0x240(%rsp)
 29e7323:	mov    0x28(%rax),%r14d
 29e7327:	shl    $0x3,%ecx
 29e732a:	shr    %cl,%r13d
 29e732d:	and    $0xff,%r13d
 29e7334:	mov    %r13,0x248(%rsp)
 29e733c:	mov    0x220(%rsp),%rax
 29e7344:	mov    %eax,0xe0(%rsp)
 29e734b:	mov    %r14d,0x78(%rsp)
 29e7350:	mov    %edx,0x88(%rsp)
 29e7357:	mov    %esi,0x120(%rsp)
 29e735e:	mov    %edi,0x110(%rsp)
 29e7365:	mov    %r15d,0xd8(%rsp)
 29e736d:	mov    %r8d,0x130(%rsp)
 29e7375:	mov    $0x285,%edx
 29e737a:	mov    0x190(%rsp),%rsi
 29e7382:	mov    0x190(%rsp),%rdi
 29e738a:	call   2f307a0 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 29e738f:	mov    %eax,0x118(%rsp)
 29e7396:	xor    %r13d,%r13d
 29e7399:	test   %eax,%eax
 29e739b:	je     29fbe63 <wasm[0]::function[1015]::helper::object_read+0x1af43>
 29e73a1:	movl   $0x0,0x100(%rsp)
 29e73ac:	mov    0xe0(%rsp),%edx
 29e73b3:	mov    %rdx,0x198(%rsp)
 29e73bb:	mov    0x78(%rsp),%esi
 29e73bf:	mov    %rsi,0x1a0(%rsp)
 29e73c7:	mov    0x88(%rsp),%r15d
 29e73cf:	mov    0x120(%rsp),%esi
 29e73d6:	mov    0x110(%rsp),%edi
 29e73dd:	mov    0xd8(%rsp),%r8d
 29e73e5:	mov    0x130(%rsp),%r9d
 29e73ed:	xor    %rbx,%rbx
 29e73f0:	mov    0x2a0(%rsp),%rcx
 29e73f8:	test   %cl,%cl
 29e73fa:	jne    29e7420 <wasm[0]::function[1015]::helper::object_read+0x6500>
 29e7400:	mov    0x198(%rsp),%rdx
 29e7408:	mov    %r13,%r14
 29e740b:	mov    %r13,0x230(%rsp)
 29e7413:	mov    %rbx,0x238(%rsp)
 29e741b:	jmp    29e8082 <wasm[0]::function[1015]::helper::object_read+0x7162>
 29e7420:	mov    0xe0(%rsp),%r8d
 29e7428:	mov    0x2b0(%rsp),%rcx
 29e7430:	mov    0x2a8(%rsp),%rdx
 29e7438:	mov    0x190(%rsp),%rsi
 29e7440:	mov    0x190(%rsp),%rdi
 29e7448:	call   2a5f620 <wasm[0]::function[1039]::helper::object_header_projection>
 29e744d:	mov    %eax,0xa0(%rsp)
 29e7454:	test   %eax,%eax
 29e7456:	je     29fbe65 <wasm[0]::function[1015]::helper::object_read+0x1af45>
 29e745c:	test   %eax,%eax
 29e745e:	je     29fbe67 <wasm[0]::function[1015]::helper::object_read+0x1af47>
 29e7464:	mov    0x2e0(%rsp),%r12
 29e746c:	mov    0x28(%r12),%rcx
 29e7471:	mov    0x20(%r12),%rsi
 29e7476:	mov    %eax,%edx
 29e7478:	lea    (%rsi,%rdx,1),%rax
 29e747c:	xor    %rsi,%rsi
 29e747f:	cmp    %rcx,%rdx
 29e7482:	cmova  %rsi,%rax
 29e7486:	mov    0x14(%rax),%eax
 29e7489:	mov    %eax,0xc8(%rsp)
 29e7490:	test   %eax,%eax
 29e7492:	je     29fbe69 <wasm[0]::function[1015]::helper::object_read+0x1af49>
 29e7498:	mov    0xc8(%rsp),%ecx
 29e749f:	xor    %eax,%eax
 29e74a1:	test   $0x1,%ecx
 29e74a7:	jne    29e7501 <wasm[0]::function[1015]::helper::object_read+0x65e1>
 29e74ad:	mov    0x2e0(%rsp),%r12
 29e74b5:	mov    0x28(%r12),%rax
 29e74ba:	mov    0x20(%r12),%rsi
 29e74bf:	mov    %ecx,%edx
 29e74c1:	lea    0x4(%rsi,%rdx,1),%rcx
 29e74c6:	xor    %rsi,%rsi
 29e74c9:	cmp    %rax,%rdx
 29e74cc:	cmova  %rsi,%rcx
 29e74d0:	mov    (%rcx),%esi
 29e74d2:	mov    0x190(%rsp),%rcx
 29e74da:	mov    0x28(%rcx),%rax
 29e74de:	mov    0x158(%rax),%edx
 29e74e4:	cmp    %edx,%esi
 29e74e6:	sete   %al
 29e74e9:	movzbl %al,%eax
 29e74ec:	cmp    %edx,%esi
 29e74ee:	je     29e7501 <wasm[0]::function[1015]::helper::object_read+0x65e1>
 29e74f4:	mov    0x190(%rsp),%rdi
 29e74fc:	call   3018e75 <wasmtime_builtin_is_subtype>
 29e7501:	test   %eax,%eax
 29e7503:	jne    29e776b <wasm[0]::function[1015]::helper::object_read+0x684b>
 29e7509:	mov    0xa0(%rsp),%edx
 29e7510:	xor    %r12d,%r12d
 29e7513:	test   %edx,%edx
 29e7515:	je     29fbe6b <wasm[0]::function[1015]::helper::object_read+0x1af4b>
 29e751b:	mov    0x118(%rsp),%r9d
 29e7523:	mov    $0x4,%ecx
 29e7528:	xor    %r8,%r8
 29e752b:	mov    0x190(%rsp),%rsi
 29e7533:	mov    0x190(%rsp),%rdi
 29e753b:	call   2a58e20 <wasm[0]::function[1032]::helper::ordinary_property_find>
 29e7540:	test   %eax,%eax
 29e7542:	je     29e757d <wasm[0]::function[1015]::helper::object_read+0x665d>
 29e7548:	test   %eax,%eax
 29e754a:	je     29fbe6d <wasm[0]::function[1015]::helper::object_read+0x1af4d>
 29e7550:	test   %eax,%eax
 29e7552:	je     29fbe6f <wasm[0]::function[1015]::helper::object_read+0x1af4f>
 29e7558:	mov    0x2e0(%rsp),%r12
 29e7560:	mov    0x28(%r12),%rcx
 29e7565:	mov    %eax,%eax
 29e7567:	mov    %rax,%r10
 29e756a:	add    0x20(%r12),%r10
 29e756f:	xor    %rdx,%rdx
 29e7572:	cmp    %rcx,%rax
 29e7575:	cmova  %rdx,%r10
 29e7579:	mov    0x14(%r10),%r12d
 29e757d:	mov    0x100(%rsp),%r14d
 29e7585:	xor    %r13d,%r13d
 29e7588:	xor    %rbx,%rbx
 29e758b:	test   %r12d,%r12d
 29e758e:	je     29e7715 <wasm[0]::function[1015]::helper::object_read+0x67f5>
 29e7594:	test   %r12d,%r12d
 29e7597:	je     29fbe71 <wasm[0]::function[1015]::helper::object_read+0x1af51>
 29e759d:	mov    0x2e0(%rsp),%rax
 29e75a5:	mov    0x28(%rax),%rcx
 29e75a9:	mov    0x20(%rax),%rax
 29e75ad:	mov    %r12d,%edx
 29e75b0:	add    %rdx,%rax
 29e75b3:	xor    %rbx,%rbx
 29e75b6:	cmp    %rcx,%rdx
 29e75b9:	cmova  %rbx,%rax
 29e75bd:	mov    0x10(%rax),%ecx
 29e75c0:	mov    0x100(%rsp),%r14d
 29e75c8:	xor    %r13d,%r13d
 29e75cb:	test   $0x1,%ecx
 29e75d1:	jne    29e7715 <wasm[0]::function[1015]::helper::object_read+0x67f5>
 29e75d7:	mov    0x14(%rax),%edx
 29e75da:	test   %edx,%edx
 29e75dc:	je     29fbe73 <wasm[0]::function[1015]::helper::object_read+0x1af53>
 29e75e2:	xor    %eax,%eax
 29e75e4:	test   $0x1,%edx
 29e75ea:	jne    29e762d <wasm[0]::function[1015]::helper::object_read+0x670d>
 29e75f0:	mov    0x2e0(%rsp),%r12
 29e75f8:	mov    0x28(%r12),%rax
 29e75fd:	mov    0x20(%r12),%rcx
 29e7602:	mov    %edx,%esi
 29e7604:	lea    0x4(%rcx,%rsi,1),%rcx
 29e7609:	xor    %rdi,%rdi
 29e760c:	cmp    %rax,%rsi
 29e760f:	cmova  %rdi,%rcx
 29e7613:	mov    (%rcx),%eax
 29e7615:	mov    0x190(%rsp),%rcx
 29e761d:	mov    0x28(%rcx),%rcx
 29e7621:	cmp    0x120(%rcx),%eax
 29e7627:	sete   %al
 29e762a:	movzbl %al,%eax
 29e762d:	test   %eax,%eax
 29e762f:	jne    29e768d <wasm[0]::function[1015]::helper::object_read+0x676d>
 29e7635:	mov    0x190(%rsp),%rsi
 29e763d:	mov    0x190(%rsp),%rdi
 29e7645:	call   2a01ba0 <wasm[0]::function[1024]::helper::property_value_resolve>
 29e764a:	test   %eax,%eax
 29e764c:	je     29fbe75 <wasm[0]::function[1015]::helper::object_read+0x1af55>
 29e7652:	test   %eax,%eax
 29e7654:	je     29fbe77 <wasm[0]::function[1015]::helper::object_read+0x1af57>
 29e765a:	mov    0x2e0(%rsp),%r12
 29e7662:	mov    0x28(%r12),%rcx
 29e7667:	mov    0x20(%r12),%rsi
 29e766c:	mov    %eax,%edx
 29e766e:	lea    (%rsi,%rdx,1),%rax
 29e7672:	xor    %rsi,%rsi
 29e7675:	cmp    %rcx,%rdx
 29e7678:	cmova  %rsi,%rax
 29e767c:	mov    0x18(%rax),%r13d
 29e7680:	mov    0x10(%rax),%rbx
 29e7684:	mov    0x1c(%rax),%r14d
 29e7688:	jmp    29e7715 <wasm[0]::function[1015]::helper::object_read+0x67f5>
 29e768d:	xor    %eax,%eax
 29e768f:	test   $0x1,%edx
 29e7695:	jne    29e76d8 <wasm[0]::function[1015]::helper::object_read+0x67b8>
 29e769b:	mov    0x2e0(%rsp),%r12
 29e76a3:	mov    0x28(%r12),%rax
 29e76a8:	mov    0x20(%r12),%rcx
 29e76ad:	mov    %edx,%esi
 29e76af:	lea    0x4(%rcx,%rsi,1),%rcx
 29e76b4:	xor    %rdi,%rdi
 29e76b7:	cmp    %rax,%rsi
 29e76ba:	cmova  %rdi,%rcx
 29e76be:	mov    (%rcx),%eax
 29e76c0:	mov    0x190(%rsp),%rcx
 29e76c8:	mov    0x28(%rcx),%rcx
 29e76cc:	cmp    0x120(%rcx),%eax
 29e76d2:	sete   %al
 29e76d5:	movzbl %al,%eax
 29e76d8:	test   %eax,%eax
 29e76da:	je     29fbe79 <wasm[0]::function[1015]::helper::object_read+0x1af59>
 29e76e0:	test   %edx,%edx
 29e76e2:	je     29fbe7b <wasm[0]::function[1015]::helper::object_read+0x1af5b>
 29e76e8:	mov    0x2e0(%rsp),%r12
 29e76f0:	mov    0x28(%r12),%rcx
 29e76f5:	mov    0x20(%r12),%rax
 29e76fa:	mov    %edx,%edx
 29e76fc:	add    %rdx,%rax
 29e76ff:	xor    %rsi,%rsi
 29e7702:	cmp    %rcx,%rdx
 29e7705:	cmova  %rsi,%rax
 29e7709:	mov    0x18(%rax),%r13d
 29e770d:	mov    0x10(%rax),%rbx
 29e7711:	mov    0x1c(%rax),%r14d
 29e7715:	mov    0xe0(%rsp),%edx
 29e771c:	mov    %rdx,0x198(%rsp)
 29e7724:	mov    0x78(%rsp),%esi
 29e7728:	mov    %rsi,0x1a0(%rsp)
 29e7730:	mov    0x88(%rsp),%r15d
 29e7738:	mov    0x120(%rsp),%esi
 29e773f:	mov    0x110(%rsp),%edi
 29e7746:	mov    0xd8(%rsp),%r8d
 29e774e:	mov    0x130(%rsp),%r9d
 29e7756:	mov    %r13,0x230(%rsp)
 29e775e:	mov    %rbx,0x238(%rsp)
 29e7766:	jmp    29e807a <wasm[0]::function[1015]::helper::object_read+0x715a>
 29e776b:	mov    0xc8(%rsp),%eax
 29e7772:	test   %eax,%eax
 29e7774:	je     29fbe7d <wasm[0]::function[1015]::helper::object_read+0x1af5d>
 29e777a:	mov    0xc8(%rsp),%ecx
 29e7781:	xor    %eax,%eax
 29e7783:	test   $0x1,%ecx
 29e7789:	jne    29e77e5 <wasm[0]::function[1015]::helper::object_read+0x68c5>
 29e778f:	mov    0x2e0(%rsp),%r12
 29e7797:	mov    0x28(%r12),%rax
 29e779c:	mov    0x20(%r12),%rsi
 29e77a1:	mov    %ecx,%edx
 29e77a3:	lea    0x4(%rsi,%rdx,1),%rcx
 29e77a8:	xor    %rsi,%rsi
 29e77ab:	cmp    %rax,%rdx
 29e77ae:	cmova  %rsi,%rcx
 29e77b2:	mov    (%rcx),%esi
 29e77b4:	mov    0x190(%rsp),%rcx
 29e77bc:	mov    0x28(%rcx),%rcx
 29e77c0:	mov    0x158(%rcx),%edx
 29e77c6:	cmp    %edx,%esi
 29e77c8:	sete   %dil
 29e77cc:	movzbl %dil,%eax
 29e77d0:	cmp    %edx,%esi
 29e77d2:	je     29e77e5 <wasm[0]::function[1015]::helper::object_read+0x68c5>
 29e77d8:	mov    0x190(%rsp),%rdi
 29e77e0:	call   3018e75 <wasmtime_builtin_is_subtype>
 29e77e5:	test   %eax,%eax
 29e77e7:	je     29fbe7f <wasm[0]::function[1015]::helper::object_read+0x1af5f>
 29e77ed:	mov    0xc8(%rsp),%r11d
 29e77f5:	mov    0xe0(%rsp),%edx
 29e77fc:	mov    %rdx,0x198(%rsp)
 29e7804:	mov    0x100(%rsp),%r14d
 29e780c:	mov    0x78(%rsp),%esi
 29e7810:	mov    %rsi,0x1a0(%rsp)
 29e7818:	mov    0x88(%rsp),%r15d
 29e7820:	mov    0x120(%rsp),%esi
 29e7827:	mov    0x110(%rsp),%edi
 29e782e:	mov    0xd8(%rsp),%r8d
 29e7836:	mov    0x130(%rsp),%r9d
 29e783e:	xor    %ecx,%ecx
 29e7840:	mov    %rcx,0x218(%rsp)
 29e7848:	test   %r11d,%r11d
 29e784b:	je     29fbe81 <wasm[0]::function[1015]::helper::object_read+0x1af61>
 29e7851:	test   %r11d,%r11d
 29e7854:	je     29fbe83 <wasm[0]::function[1015]::helper::object_read+0x1af63>
 29e785a:	mov    0x2e0(%rsp),%r12
 29e7862:	mov    0x28(%r12),%rax
 29e7867:	mov    0x20(%r12),%rcx
 29e786c:	mov    %r11d,%ebx
 29e786f:	lea    (%rcx,%rbx,1),%r10
 29e7873:	xor    %r12,%r12
 29e7876:	cmp    %rax,%rbx
 29e7879:	cmova  %r12,%r10
 29e787d:	mov    0x10(%r10),%r10d
 29e7881:	test   %r10d,%r10d
 29e7884:	je     29fbe85 <wasm[0]::function[1015]::helper::object_read+0x1af65>
 29e788a:	test   %r10d,%r10d
 29e788d:	je     29fbe87 <wasm[0]::function[1015]::helper::object_read+0x1af67>
 29e7893:	mov    %r10d,%ebx
 29e7896:	lea    (%rcx,%rbx,1),%r10
 29e789a:	cmp    %rax,%rbx
 29e789d:	cmova  %r12,%r10
 29e78a1:	mov    0x10(%r10),%ebx
 29e78a5:	test   %ebx,%ebx
 29e78a7:	je     29fbe89 <wasm[0]::function[1015]::helper::object_read+0x1af69>
 29e78ad:	test   %ebx,%ebx
 29e78af:	je     29fbe8b <wasm[0]::function[1015]::helper::object_read+0x1af6b>
 29e78b5:	mov    %ebx,%r10d
 29e78b8:	lea    0x10(%rcx,%r10,1),%rcx
 29e78bd:	cmp    %rax,%r10
 29e78c0:	cmova  %r12,%rcx
 29e78c4:	mov    (%rcx),%r13d
 29e78c7:	mov    %r13,0x250(%rsp)
 29e78cf:	mov    0x118(%rsp),%r12d
 29e78d7:	mov    0x190(%rsp),%rcx
 29e78df:	mov    0x28(%rcx),%rax
 29e78e3:	mov    0x234(%rax),%r13d
 29e78ea:	mov    0x218(%rsp),%rax
 29e78f2:	mov    %rax,0x220(%rsp)
 29e78fa:	mov    %ebx,0xa0(%rsp)
 29e7901:	mov    %r12d,0x130(%rsp)
 29e7909:	mov    %r11d,0xd8(%rsp)
 29e7911:	mov    0x198(%rsp),%rdx
 29e7919:	mov    %edx,0x110(%rsp)
 29e7920:	mov    %r14d,0x120(%rsp)
 29e7928:	mov    0x1a0(%rsp),%r10
 29e7930:	mov    %r10d,0x88(%rsp)
 29e7938:	mov    %r15d,0x78(%rsp)
 29e793d:	mov    %esi,0x100(%rsp)
 29e7944:	mov    %edi,0xe0(%rsp)
 29e794b:	mov    %r8d,0xc8(%rsp)
 29e7953:	mov    %r9d,0x118(%rsp)
 29e795b:	mov    0x2e8(%rsp),%rax
 29e7963:	mov    (%rax),%rcx
 29e7966:	mov    0x228(%rsp),%rax
 29e796e:	cmp    %rax,%rcx
 29e7971:	jae    29fa9ec <wasm[0]::function[1015]::helper::object_read+0x19acc>
 29e7977:	mov    0xd8(%rsp),%r11d
 29e797f:	mov    0x110(%rsp),%edx
 29e7986:	mov    %rdx,0x198(%rsp)
 29e798e:	mov    0x120(%rsp),%r14d
 29e7996:	mov    0x88(%rsp),%esi
 29e799d:	mov    %rsi,0x1a0(%rsp)
 29e79a5:	mov    0x78(%rsp),%r15d
 29e79aa:	mov    0x100(%rsp),%esi
 29e79b1:	mov    0xe0(%rsp),%edi
 29e79b8:	mov    0xc8(%rsp),%r8d
 29e79c0:	mov    0x118(%rsp),%r9d
 29e79c8:	mov    0x218(%rsp),%rcx
 29e79d0:	mov    0x250(%rsp),%r10
 29e79d8:	cmp    %r10d,%ecx
 29e79db:	jb     29e79ee <wasm[0]::function[1015]::helper::object_read+0x6ace>
 29e79e1:	mov    0x220(%rsp),%rax
 29e79e9:	jmp    29e7c11 <wasm[0]::function[1015]::helper::object_read+0x6cf1>
 29e79ee:	mov    0xa0(%rsp),%eax
 29e79f5:	test   %eax,%eax
 29e79f7:	je     29fbe8d <wasm[0]::function[1015]::helper::object_read+0x1af6d>
 29e79fd:	test   %eax,%eax
 29e79ff:	je     29fbe8f <wasm[0]::function[1015]::helper::object_read+0x1af6f>
 29e7a05:	mov    0x2e0(%rsp),%r12
 29e7a0d:	mov    0x28(%r12),%rdx
 29e7a12:	mov    0x20(%r12),%rsi
 29e7a17:	mov    %eax,%r9d
 29e7a1a:	lea    0x10(%rsi,%r9,1),%r8
 29e7a1f:	xor    %rdi,%rdi
 29e7a22:	cmp    %rdx,%r9
 29e7a25:	cmova  %rdi,%r8
 29e7a29:	mov    (%r8),%r8d
 29e7a2c:	cmp    %r8d,%ecx
 29e7a2f:	jae    29fbe91 <wasm[0]::function[1015]::helper::object_read+0x1af71>
 29e7a35:	mov    %r8d,%r9d
 29e7a38:	shl    $0x2,%r9
 29e7a3c:	shr    $0x20,%r9
 29e7a40:	test   %r9,%r9
 29e7a43:	jne    29fbe93 <wasm[0]::function[1015]::helper::object_read+0x1af73>
 29e7a49:	shl    $0x2,%r8d
 29e7a4d:	add    $0x14,%r8d
 29e7a51:	jb     29fbe95 <wasm[0]::function[1015]::helper::object_read+0x1af75>
 29e7a57:	add    %r8d,%eax
 29e7a5a:	jb     29fbe97 <wasm[0]::function[1015]::helper::object_read+0x1af77>
 29e7a60:	mov    %eax,%r9d
 29e7a63:	lea    (%rsi,%r9,1),%rax
 29e7a67:	cmp    %rdx,%r9
 29e7a6a:	cmova  %rdi,%rax
 29e7a6e:	mov    %rcx,%rdx
 29e7a71:	shl    $0x2,%edx
 29e7a74:	mov    %rcx,0x218(%rsp)
 29e7a7c:	lea    0x14(%rdx),%ecx
 29e7a7f:	sub    %ecx,%r8d
 29e7a82:	sub    %r8,%rax
 29e7a85:	mov    (%rax),%edx
 29e7a87:	test   %edx,%edx
 29e7a89:	je     29fbe99 <wasm[0]::function[1015]::helper::object_read+0x1af79>
 29e7a8f:	mov    0x130(%rsp),%ecx
 29e7a96:	cmp    %ecx,%edx
 29e7a98:	je     29e7b71 <wasm[0]::function[1015]::helper::object_read+0x6c51>
 29e7a9e:	xor    %eax,%eax
 29e7aa0:	test   %edx,%edx
 29e7aa2:	je     29e7ae8 <wasm[0]::function[1015]::helper::object_read+0x6bc8>
 29e7aa8:	xor    %eax,%eax
 29e7aaa:	test   $0x1,%edx
 29e7ab0:	jne    29e7ae8 <wasm[0]::function[1015]::helper::object_read+0x6bc8>
 29e7ab6:	mov    0x2e0(%rsp),%r12
 29e7abe:	mov    0x28(%r12),%r9
 29e7ac3:	mov    0x20(%r12),%r11
 29e7ac8:	mov    %edx,%r10d
 29e7acb:	lea    0x4(%r11,%r10,1),%rsi
 29e7ad0:	xor    %r11,%r11
 29e7ad3:	cmp    %r9,%r10
 29e7ad6:	cmova  %r11,%rsi
 29e7ada:	mov    (%rsi),%r10d
 29e7add:	cmp    %r13d,%r10d
 29e7ae0:	sete   %r11b
 29e7ae4:	movzbl %r11b,%eax
 29e7ae8:	test   %eax,%eax
 29e7aea:	je     29fbe9b <wasm[0]::function[1015]::helper::object_read+0x1af7b>
 29e7af0:	xor    %eax,%eax
 29e7af2:	test   %ecx,%ecx
 29e7af4:	je     29e7b3d <wasm[0]::function[1015]::helper::object_read+0x6c1d>
 29e7afa:	mov    0x130(%rsp),%ecx
 29e7b01:	xor    %eax,%eax
 29e7b03:	test   $0x1,%ecx
 29e7b09:	jne    29e7b3d <wasm[0]::function[1015]::helper::object_read+0x6c1d>
 29e7b0f:	mov    0x2e0(%rsp),%r12
 29e7b17:	mov    0x28(%r12),%rax
 29e7b1c:	mov    0x20(%r12),%rdi
 29e7b21:	mov    %ecx,%esi
 29e7b23:	lea    0x4(%rdi,%rsi,1),%rcx
 29e7b28:	xor    %rdi,%rdi
 29e7b2b:	cmp    %rax,%rsi
 29e7b2e:	cmova  %rdi,%rcx
 29e7b32:	mov    (%rcx),%eax
 29e7b34:	cmp    %r13d,%eax
 29e7b37:	sete   %al
 29e7b3a:	movzbl %al,%eax
 29e7b3d:	test   %eax,%eax
 29e7b3f:	je     29fbe9d <wasm[0]::function[1015]::helper::object_read+0x1af7d>
 29e7b45:	mov    0x130(%rsp),%ecx
 29e7b4c:	xor    %r8d,%r8d
 29e7b4f:	test   %ecx,%ecx
 29e7b51:	je     29fbe9f <wasm[0]::function[1015]::helper::object_read+0x1af7f>
 29e7b57:	mov    0x190(%rsp),%rsi
 29e7b5f:	mov    0x190(%rsp),%rdi
 29e7b67:	call   2ae54e0 <wasm[0]::function[1057]::helper::string_equality>
 29e7b6c:	jmp    29e7b79 <wasm[0]::function[1015]::helper::object_read+0x6c59>
 29e7b71:	mov    0x278(%rsp),%rax
 29e7b79:	mov    0xa0(%rsp),%ebx
 29e7b80:	mov    0x130(%rsp),%r12d
 29e7b88:	mov    0xd8(%rsp),%r11d
 29e7b90:	mov    0x110(%rsp),%edx
 29e7b97:	mov    %rdx,0x198(%rsp)
 29e7b9f:	mov    0x120(%rsp),%r14d
 29e7ba7:	mov    0x88(%rsp),%esi
 29e7bae:	mov    %rsi,0x1a0(%rsp)
 29e7bb6:	mov    0x78(%rsp),%r15d
 29e7bbb:	mov    0x100(%rsp),%esi
 29e7bc2:	mov    0xe0(%rsp),%edi
 29e7bc9:	mov    0xc8(%rsp),%r8d
 29e7bd1:	mov    0x118(%rsp),%r9d
 29e7bd9:	test   %eax,%eax
 29e7bdb:	je     29e7bee <wasm[0]::function[1015]::helper::object_read+0x6cce>
 29e7be1:	mov    0x218(%rsp),%rcx
 29e7be9:	jmp    29e7c11 <wasm[0]::function[1015]::helper::object_read+0x6cf1>
 29e7bee:	mov    0x218(%rsp),%rcx
 29e7bf6:	add    $0x1,%ecx
 29e7bfc:	mov    %rcx,0x218(%rsp)
 29e7c04:	mov    %rax,0x220(%rsp)
 29e7c0c:	jmp    29e78fa <wasm[0]::function[1015]::helper::object_read+0x69da>
 29e7c11:	xor    %r13d,%r13d
 29e7c14:	xor    %rbx,%rbx
 29e7c17:	test   %eax,%eax
 29e7c19:	jne    29e7c34 <wasm[0]::function[1015]::helper::object_read+0x6d14>
 29e7c1f:	mov    %r13,0x230(%rsp)
 29e7c27:	mov    %rbx,0x238(%rsp)
 29e7c2f:	jmp    29e807a <wasm[0]::function[1015]::helper::object_read+0x715a>
 29e7c34:	test   %r11d,%r11d
 29e7c37:	je     29fbea1 <wasm[0]::function[1015]::helper::object_read+0x1af81>
 29e7c3d:	xor    %eax,%eax
 29e7c3f:	test   $0x1,%r11d
 29e7c46:	jne    29e7c8b <wasm[0]::function[1015]::helper::object_read+0x6d6b>
 29e7c4c:	mov    0x2e0(%rsp),%r12
 29e7c54:	mov    0x28(%r12),%rax
 29e7c59:	mov    0x20(%r12),%r10
 29e7c5e:	mov    %r11d,%ebx
 29e7c61:	lea    0x4(%r10,%rbx,1),%r10
 29e7c66:	xor    %r12,%r12
 29e7c69:	cmp    %rax,%rbx
 29e7c6c:	cmova  %r12,%r10
 29e7c70:	mov    (%r10),%eax
 29e7c73:	mov    0x190(%rsp),%rdx
 29e7c7b:	mov    0x28(%rdx),%rdx
 29e7c7f:	cmp    0x160(%rdx),%eax
 29e7c85:	sete   %al
 29e7c88:	movzbl %al,%eax
 29e7c8b:	test   %eax,%eax
 29e7c8d:	jne    29e7ef0 <wasm[0]::function[1015]::helper::object_read+0x6fd0>
 29e7c93:	xor    %r10d,%r10d
 29e7c96:	test   $0x1,%r11d
 29e7c9d:	jne    29e7ce3 <wasm[0]::function[1015]::helper::object_read+0x6dc3>
 29e7ca3:	mov    0x2e0(%rsp),%r12
 29e7cab:	mov    0x28(%r12),%rax
 29e7cb0:	mov    0x20(%r12),%r10
 29e7cb5:	mov    %r11d,%ebx
 29e7cb8:	lea    0x4(%r10,%rbx,1),%r10
 29e7cbd:	xor    %r12,%r12
 29e7cc0:	cmp    %rax,%rbx
 29e7cc3:	cmova  %r12,%r10
 29e7cc7:	mov    (%r10),%eax
 29e7cca:	mov    0x190(%rsp),%rdx
 29e7cd2:	mov    0x28(%rdx),%rdx
 29e7cd6:	cmp    0x15c(%rdx),%eax
 29e7cdc:	sete   %al
 29e7cdf:	movzbl %al,%r10d
 29e7ce3:	test   %r10d,%r10d
 29e7ce6:	je     29fbea3 <wasm[0]::function[1015]::helper::object_read+0x1af83>
 29e7cec:	test   %r11d,%r11d
 29e7cef:	je     29fbea5 <wasm[0]::function[1015]::helper::object_read+0x1af85>
 29e7cf5:	mov    0x2e0(%rsp),%r12
 29e7cfd:	mov    0x28(%r12),%r13
 29e7d02:	mov    0x20(%r12),%r12
 29e7d07:	mov    %r11d,%eax
 29e7d0a:	lea    (%r12,%rax,1),%r10
 29e7d0e:	xor    %rbx,%rbx
 29e7d11:	cmp    %r13,%rax
 29e7d14:	cmova  %rbx,%r10
 29e7d18:	mov    0x14(%r10),%r14d
 29e7d1c:	mov    0x18(%r10),%eax
 29e7d20:	mov    0x1c(%r10),%r11d
 29e7d24:	test   %r14d,%r14d
 29e7d27:	je     29fbea7 <wasm[0]::function[1015]::helper::object_read+0x1af87>
 29e7d2d:	test   %r14d,%r14d
 29e7d30:	je     29fbea9 <wasm[0]::function[1015]::helper::object_read+0x1af89>
 29e7d36:	mov    %r14d,%edx
 29e7d39:	lea    0x10(%r12,%rdx,1),%r10
 29e7d3e:	cmp    %r13,%rdx
 29e7d41:	cmova  %rbx,%r10
 29e7d45:	mov    (%r10),%r10d
 29e7d48:	cmp    %r10d,%ecx
 29e7d4b:	jae    29fbeab <wasm[0]::function[1015]::helper::object_read+0x1af8b>
 29e7d51:	mov    %r10d,%edx
 29e7d54:	shr    $0x20,%rdx
 29e7d58:	test   %rdx,%rdx
 29e7d5b:	jne    29fbead <wasm[0]::function[1015]::helper::object_read+0x1af8d>
 29e7d61:	add    $0x14,%r10d
 29e7d65:	jb     29fbeaf <wasm[0]::function[1015]::helper::object_read+0x1af8f>
 29e7d6b:	add    %r10d,%r14d
 29e7d6e:	jb     29fbeb1 <wasm[0]::function[1015]::helper::object_read+0x1af91>
 29e7d74:	mov    %r14d,%edx
 29e7d77:	add    %rdx,%r12
 29e7d7a:	cmp    %r13,%rdx
 29e7d7d:	cmova  %rbx,%r12
 29e7d81:	lea    0x14(%rcx),%edx
 29e7d84:	sub    %edx,%r10d
 29e7d87:	sub    %r10,%r12
 29e7d8a:	movzbq (%r12),%r10
 29e7d8f:	mov    %r10,0x220(%rsp)
 29e7d97:	test   %eax,%eax
 29e7d99:	je     29e7e2c <wasm[0]::function[1015]::helper::object_read+0x6f0c>
 29e7d9f:	test   %eax,%eax
 29e7da1:	je     29fbeb3 <wasm[0]::function[1015]::helper::object_read+0x1af93>
 29e7da7:	test   %eax,%eax
 29e7da9:	je     29fbeb5 <wasm[0]::function[1015]::helper::object_read+0x1af95>
 29e7daf:	mov    0x2e0(%rsp),%r12
 29e7db7:	mov    0x28(%r12),%rbx
 29e7dbc:	mov    0x20(%r12),%r12
 29e7dc1:	mov    %eax,%r13d
 29e7dc4:	lea    0x10(%r12,%r13,1),%r10
 29e7dc9:	xor    %r14,%r14
 29e7dcc:	cmp    %rbx,%r13
 29e7dcf:	cmova  %r14,%r10
 29e7dd3:	mov    (%r10),%r13d
 29e7dd6:	cmp    %r13d,%ecx
 29e7dd9:	jae    29fbeb7 <wasm[0]::function[1015]::helper::object_read+0x1af97>
 29e7ddf:	mov    %r13d,%r10d
 29e7de2:	shl    $0x3,%r10
 29e7de6:	shr    $0x20,%r10
 29e7dea:	test   %r10,%r10
 29e7ded:	jne    29fbeb9 <wasm[0]::function[1015]::helper::object_read+0x1af99>
 29e7df3:	shl    $0x3,%r13d
 29e7df7:	add    $0x18,%r13d
 29e7dfb:	jb     29fbebb <wasm[0]::function[1015]::helper::object_read+0x1af9b>
 29e7e01:	add    %r13d,%eax
 29e7e04:	jb     29fbebd <wasm[0]::function[1015]::helper::object_read+0x1af9d>
 29e7e0a:	mov    %eax,%edx
 29e7e0c:	lea    (%r12,%rdx,1),%rax
 29e7e10:	cmp    %rbx,%rdx
 29e7e13:	cmova  %r14,%rax
 29e7e17:	mov    %rcx,%rdx
 29e7e1a:	shl    $0x3,%edx
 29e7e1d:	add    $0x18,%edx
 29e7e23:	sub    %edx,%r13d
 29e7e26:	sub    %r13,%rax
 29e7e29:	mov    (%rax),%rbx
 29e7e2c:	xor    %r14d,%r14d
 29e7e2f:	test   %r11d,%r11d
 29e7e32:	jne    29e7e45 <wasm[0]::function[1015]::helper::object_read+0x6f25>
 29e7e38:	mov    0x220(%rsp),%r10
 29e7e40:	jmp    29e7ed7 <wasm[0]::function[1015]::helper::object_read+0x6fb7>
 29e7e45:	test   %r11d,%r11d
 29e7e48:	je     29fbebf <wasm[0]::function[1015]::helper::object_read+0x1af9f>
 29e7e4e:	test   %r11d,%r11d
 29e7e51:	je     29fbec1 <wasm[0]::function[1015]::helper::object_read+0x1afa1>
 29e7e57:	mov    0x2e0(%rsp),%r12
 29e7e5f:	mov    0x28(%r12),%rax
 29e7e64:	mov    0x20(%r12),%r12
 29e7e69:	mov    %r11d,%r14d
 29e7e6c:	lea    0x10(%r12,%r14,1),%r10
 29e7e71:	xor    %r13,%r13
 29e7e74:	cmp    %rax,%r14
 29e7e77:	cmova  %r13,%r10
 29e7e7b:	mov    (%r10),%r14d
 29e7e7e:	cmp    %r14d,%ecx
 29e7e81:	jae    29fbec3 <wasm[0]::function[1015]::helper::object_read+0x1afa3>
 29e7e87:	mov    %r14d,%r10d
 29e7e8a:	shl    $0x2,%r10
 29e7e8e:	shr    $0x20,%r10
 29e7e92:	test   %r10,%r10
 29e7e95:	jne    29fbec5 <wasm[0]::function[1015]::helper::object_read+0x1afa5>
 29e7e9b:	shl    $0x2,%r14d
 29e7e9f:	add    $0x14,%r14d
 29e7ea3:	jb     29fbec7 <wasm[0]::function[1015]::helper::object_read+0x1afa7>
 29e7ea9:	add    %r14d,%r11d
 29e7eac:	jb     29fbec9 <wasm[0]::function[1015]::helper::object_read+0x1afa9>
 29e7eb2:	mov    %r11d,%edx
 29e7eb5:	lea    (%r12,%rdx,1),%r10
 29e7eb9:	cmp    %rax,%rdx
 29e7ebc:	cmova  %r13,%r10
 29e7ec0:	shl    $0x2,%ecx
 29e7ec3:	lea    0x14(%rcx),%eax
 29e7ec6:	sub    %eax,%r14d
 29e7ec9:	sub    %r14,%r10
 29e7ecc:	mov    (%r10),%r14d
 29e7ecf:	mov    0x220(%rsp),%r10
 29e7ed7:	movzbl %r10b,%r13d
 29e7edb:	mov    %r13,0x230(%rsp)
 29e7ee3:	mov    %rbx,0x238(%rsp)
 29e7eeb:	jmp    29e807a <wasm[0]::function[1015]::helper::object_read+0x715a>
 29e7ef0:	xor    %eax,%eax
 29e7ef2:	test   $0x1,%r11d
 29e7ef9:	jne    29e7f3e <wasm[0]::function[1015]::helper::object_read+0x701e>
 29e7eff:	mov    0x2e0(%rsp),%r12
 29e7f07:	mov    0x28(%r12),%rax
 29e7f0c:	mov    0x20(%r12),%rdx
 29e7f11:	mov    %r11d,%ebx
 29e7f14:	lea    0x4(%rdx,%rbx,1),%r10
 29e7f19:	xor    %r12,%r12
 29e7f1c:	cmp    %rax,%rbx
 29e7f1f:	cmova  %r12,%r10
 29e7f23:	mov    (%r10),%eax
 29e7f26:	mov    0x190(%rsp),%rdx
 29e7f2e:	mov    0x28(%rdx),%rdx
 29e7f32:	cmp    0x160(%rdx),%eax
 29e7f38:	sete   %al
 29e7f3b:	movzbl %al,%eax
 29e7f3e:	test   %eax,%eax
 29e7f40:	je     29fbecb <wasm[0]::function[1015]::helper::object_read+0x1afab>
 29e7f46:	test   %r11d,%r11d
 29e7f49:	je     29fbecd <wasm[0]::function[1015]::helper::object_read+0x1afad>
 29e7f4f:	mov    0x2e0(%rsp),%r12
 29e7f57:	mov    0x28(%r12),%rbx
 29e7f5c:	mov    0x20(%r12),%r12
 29e7f61:	mov    %r11d,%eax
 29e7f64:	lea    (%r12,%rax,1),%r10
 29e7f68:	xor    %r11,%r11
 29e7f6b:	cmp    %rbx,%rax
 29e7f6e:	cmova  %r11,%r10
 29e7f72:	mov    0x10(%r10),%r10d
 29e7f76:	test   %r10d,%r10d
 29e7f79:	je     29fbecf <wasm[0]::function[1015]::helper::object_read+0x1afaf>
 29e7f7f:	test   %r10d,%r10d
 29e7f82:	je     29fbed1 <wasm[0]::function[1015]::helper::object_read+0x1afb1>
 29e7f88:	mov    %r10d,%edx
 29e7f8b:	lea    (%r12,%rdx,1),%r10
 29e7f8f:	cmp    %rbx,%rdx
 29e7f92:	cmova  %r11,%r10
 29e7f96:	mov    0x10(%r10),%r10d
 29e7f9a:	test   %r10d,%r10d
 29e7f9d:	je     29fbed3 <wasm[0]::function[1015]::helper::object_read+0x1afb3>
 29e7fa3:	test   %r10d,%r10d
 29e7fa6:	je     29fbed5 <wasm[0]::function[1015]::helper::object_read+0x1afb5>
 29e7fac:	mov    %r10d,%edx
 29e7faf:	lea    0x10(%r12,%rdx,1),%r10
 29e7fb4:	cmp    %rbx,%rdx
 29e7fb7:	cmova  %r11,%r10
 29e7fbb:	cmp    (%r10),%ecx
 29e7fbe:	setae  %r10b
 29e7fc2:	cmp    $0x2,%ecx
 29e7fc5:	setae  %r11b
 29e7fc9:	or     %r11d,%r10d
 29e7fcc:	test   %r10b,%r10b
 29e7fcf:	jne    29fbed7 <wasm[0]::function[1015]::helper::object_read+0x1afb7>
 29e7fd5:	mov    0x2e0(%rsp),%r12
 29e7fdd:	mov    0x28(%r12),%r11
 29e7fe2:	mov    %rax,%r10
 29e7fe5:	add    0x20(%r12),%r10
 29e7fea:	xor    %r12,%r12
 29e7fed:	cmp    %r11,%rax
 29e7ff0:	cmova  %r12,%r10
 29e7ff4:	mov    0x14(%r10),%r13d
 29e7ff8:	test   %ecx,%ecx
 29e7ffa:	je     29e8035 <wasm[0]::function[1015]::helper::object_read+0x7115>
 29e8000:	mov    0x2e0(%rsp),%r12
 29e8008:	mov    0x28(%r12),%r11
 29e800d:	mov    0x20(%r12),%rdx
 29e8012:	lea    (%rdx,%rax,1),%r10
 29e8016:	xor    %r12,%r12
 29e8019:	cmp    %r11,%rax
 29e801c:	cmova  %r12,%r10
 29e8020:	mov    0x20(%r10),%rbx
 29e8024:	mov    0x2c(%r10),%r14d
 29e8028:	mov    %rbx,0x238(%rsp)
 29e8030:	jmp    29e8065 <wasm[0]::function[1015]::helper::object_read+0x7145>
 29e8035:	mov    0x2e0(%rsp),%r12
 29e803d:	mov    0x28(%r12),%r10
 29e8042:	mov    0x20(%r12),%rdx
 29e8047:	lea    (%rdx,%rax,1),%r11
 29e804b:	xor    %r14,%r14
 29e804e:	cmp    %r10,%rax
 29e8051:	cmova  %r14,%r11
 29e8055:	mov    0x18(%r11),%rbx
 29e8059:	mov    %rbx,0x238(%rsp)
 29e8061:	mov    0x28(%r11),%r14d
 29e8065:	shl    $0x3,%ecx
 29e8068:	shr    %cl,%r13d
 29e806b:	and    $0xff,%r13d
 29e8072:	mov    %r13,0x230(%rsp)
 29e807a:	mov    0x198(%rsp),%rdx
 29e8082:	mov    %edx,0x100(%rsp)
 29e8089:	mov    %r14d,0x78(%rsp)
 29e808e:	mov    0x1a0(%rsp),%rax
 29e8096:	mov    %eax,0x88(%rsp)
 29e809d:	mov    %r15d,0x120(%rsp)
 29e80a5:	mov    %esi,0x110(%rsp)
 29e80ac:	mov    %edi,0xd8(%rsp)
 29e80b3:	mov    %r8d,0x130(%rsp)
 29e80bb:	mov    %r9d,0xa0(%rsp)
 29e80c3:	mov    $0x27b,%edx
 29e80c8:	mov    0x190(%rsp),%rsi
 29e80d0:	mov    0x190(%rsp),%rdi
 29e80d8:	call   2f307a0 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 29e80dd:	mov    %eax,0xe0(%rsp)
 29e80e4:	mov    %rsi,%rcx
 29e80e7:	xor    %ecx,%ecx
 29e80e9:	mov    %rcx,0x270(%rsp)
 29e80f1:	test   %eax,%eax
 29e80f3:	je     29fbed9 <wasm[0]::function[1015]::helper::object_read+0x1afb9>
 29e80f9:	movl   $0x0,0xc8(%rsp)
 29e8104:	mov    0x100(%rsp),%edx
 29e810b:	mov    %rdx,0x1a0(%rsp)
 29e8113:	mov    0x78(%rsp),%esi
 29e8117:	mov    %rsi,0x1c8(%rsp)
 29e811f:	mov    0x88(%rsp),%edi
 29e8126:	mov    %rdi,0x1d0(%rsp)
 29e812e:	mov    0x120(%rsp),%edi
 29e8135:	mov    0x110(%rsp),%eax
 29e813c:	mov    0xd8(%rsp),%r8d
 29e8144:	mov    0x130(%rsp),%r9d
 29e814c:	mov    0xa0(%rsp),%r10d
 29e8154:	xor    %r15,%r15
 29e8157:	mov    0x2a0(%rsp),%rcx
 29e815f:	mov    0x2a0(%rsp),%rdx
 29e8167:	test   %dl,%cl
 29e8169:	jne    29e819c <wasm[0]::function[1015]::helper::object_read+0x727c>
 29e816f:	mov    0x1a0(%rsp),%rdx
 29e8177:	mov    0x270(%rsp),%r14
 29e817f:	mov    %r15,0x250(%rsp)
 29e8187:	mov    0x270(%rsp),%rcx
 29e818f:	mov    %rcx,0x258(%rsp)
 29e8197:	jmp    29e8e99 <wasm[0]::function[1015]::helper::object_read+0x7f79>
 29e819c:	mov    0x100(%rsp),%r8d
 29e81a4:	mov    0x2b0(%rsp),%rcx
 29e81ac:	mov    0x2a8(%rsp),%rdx
 29e81b4:	mov    0x190(%rsp),%rsi
 29e81bc:	mov    0x190(%rsp),%rdi
 29e81c4:	call   2a5f620 <wasm[0]::function[1039]::helper::object_header_projection>
 29e81c9:	mov    %eax,0x118(%rsp)
 29e81d0:	test   %eax,%eax
 29e81d2:	je     29fbedb <wasm[0]::function[1015]::helper::object_read+0x1afbb>
 29e81d8:	test   %eax,%eax
 29e81da:	je     29fbedd <wasm[0]::function[1015]::helper::object_read+0x1afbd>
 29e81e0:	mov    0x2e0(%rsp),%r12
 29e81e8:	mov    0x28(%r12),%rcx
 29e81ed:	mov    0x20(%r12),%rsi
 29e81f2:	mov    %eax,%edx
 29e81f4:	lea    (%rsi,%rdx,1),%rax
 29e81f8:	xor    %rsi,%rsi
 29e81fb:	cmp    %rcx,%rdx
 29e81fe:	cmova  %rsi,%rax
 29e8202:	mov    0x14(%rax),%eax
 29e8205:	mov    %eax,0x138(%rsp)
 29e820c:	test   %eax,%eax
 29e820e:	je     29fbedf <wasm[0]::function[1015]::helper::object_read+0x1afbf>
 29e8214:	mov    0x138(%rsp),%ecx
 29e821b:	xor    %eax,%eax
 29e821d:	test   $0x1,%ecx
 29e8223:	jne    29e827d <wasm[0]::function[1015]::helper::object_read+0x735d>
 29e8229:	mov    0x2e0(%rsp),%r12
 29e8231:	mov    0x28(%r12),%rax
 29e8236:	mov    0x20(%r12),%rsi
 29e823b:	mov    %ecx,%edx
 29e823d:	lea    0x4(%rsi,%rdx,1),%rcx
 29e8242:	xor    %rsi,%rsi
 29e8245:	cmp    %rax,%rdx
 29e8248:	cmova  %rsi,%rcx
 29e824c:	mov    (%rcx),%esi
 29e824e:	mov    0x190(%rsp),%rcx
 29e8256:	mov    0x28(%rcx),%rax
 29e825a:	mov    0x158(%rax),%edx
 29e8260:	cmp    %edx,%esi
 29e8262:	sete   %al
 29e8265:	movzbl %al,%eax
 29e8268:	cmp    %edx,%esi
 29e826a:	je     29e827d <wasm[0]::function[1015]::helper::object_read+0x735d>
 29e8270:	mov    0x190(%rsp),%rdi
 29e8278:	call   3018e75 <wasmtime_builtin_is_subtype>
 29e827d:	test   %eax,%eax
 29e827f:	jne    29e8543 <wasm[0]::function[1015]::helper::object_read+0x7623>
 29e8285:	mov    0x118(%rsp),%edx
 29e828c:	xor    %ebx,%ebx
 29e828e:	test   %edx,%edx
 29e8290:	je     29fbee1 <wasm[0]::function[1015]::helper::object_read+0x1afc1>
 29e8296:	mov    0xe0(%rsp),%r9d
 29e829e:	mov    $0x4,%ecx
 29e82a3:	xor    %r8,%r8
 29e82a6:	mov    0x190(%rsp),%rsi
 29e82ae:	mov    0x190(%rsp),%rdi
 29e82b6:	call   2a58e20 <wasm[0]::function[1032]::helper::ordinary_property_find>
 29e82bb:	test   %eax,%eax
 29e82bd:	je     29e82f7 <wasm[0]::function[1015]::helper::object_read+0x73d7>
 29e82c3:	test   %eax,%eax
 29e82c5:	je     29fbee3 <wasm[0]::function[1015]::helper::object_read+0x1afc3>
 29e82cb:	test   %eax,%eax
 29e82cd:	je     29fbee5 <wasm[0]::function[1015]::helper::object_read+0x1afc5>
 29e82d3:	mov    0x2e0(%rsp),%r12
 29e82db:	mov    0x28(%r12),%rsi
 29e82e0:	mov    %eax,%edi
 29e82e2:	mov    %rdi,%rax
 29e82e5:	add    0x20(%r12),%rax
 29e82ea:	xor    %r8,%r8
 29e82ed:	cmp    %rsi,%rdi
 29e82f0:	cmova  %r8,%rax
 29e82f4:	mov    0x14(%rax),%ebx
 29e82f7:	mov    0xc8(%rsp),%r14d
 29e82ff:	mov    %rax,%rsi
 29e8302:	mov    %rax,0x270(%rsp)
 29e830a:	xor    %esi,%eax
 29e830c:	mov    %rax,0x270(%rsp)
 29e8314:	xor    %r15,%r15
 29e8317:	test   %ebx,%ebx
 29e8319:	jne    29e832c <wasm[0]::function[1015]::helper::object_read+0x740c>
 29e831f:	mov    0x270(%rsp),%rbx
 29e8327:	jmp    29e84de <wasm[0]::function[1015]::helper::object_read+0x75be>
 29e832c:	test   %ebx,%ebx
 29e832e:	je     29fbee7 <wasm[0]::function[1015]::helper::object_read+0x1afc7>
 29e8334:	mov    0x2e0(%rsp),%r12
 29e833c:	mov    0x28(%r12),%r10
 29e8341:	mov    0x20(%r12),%rax
 29e8346:	mov    %ebx,%r11d
 29e8349:	lea    (%rax,%r11,1),%rdi
 29e834d:	xor    %r15,%r15
 29e8350:	cmp    %r10,%r11
 29e8353:	cmova  %r15,%rdi
 29e8357:	mov    0x10(%rdi),%r11d
 29e835b:	mov    0xc8(%rsp),%r14d
 29e8363:	mov    %rax,%rcx
 29e8366:	mov    %rax,0x270(%rsp)
 29e836e:	xor    %ecx,%eax
 29e8370:	mov    %rax,0x270(%rsp)
 29e8378:	test   $0x1,%r11d
 29e837f:	je     29e8392 <wasm[0]::function[1015]::helper::object_read+0x7472>
 29e8385:	mov    0x270(%rsp),%rbx
 29e838d:	jmp    29e84de <wasm[0]::function[1015]::helper::object_read+0x75be>
 29e8392:	mov    0x14(%rdi),%edx
 29e8395:	test   %edx,%edx
 29e8397:	je     29fbee9 <wasm[0]::function[1015]::helper::object_read+0x1afc9>
 29e839d:	xor    %eax,%eax
 29e839f:	test   $0x1,%edx
 29e83a5:	jne    29e83e8 <wasm[0]::function[1015]::helper::object_read+0x74c8>
 29e83ab:	mov    0x2e0(%rsp),%r12
 29e83b3:	mov    0x28(%r12),%rax
 29e83b8:	mov    0x20(%r12),%rcx
 29e83bd:	mov    %edx,%esi
 29e83bf:	lea    0x4(%rcx,%rsi,1),%rcx
 29e83c4:	xor    %rdi,%rdi
 29e83c7:	cmp    %rax,%rsi
 29e83ca:	cmova  %rdi,%rcx
 29e83ce:	mov    (%rcx),%eax
 29e83d0:	mov    0x190(%rsp),%rcx
 29e83d8:	mov    0x28(%rcx),%rcx
 29e83dc:	cmp    0x120(%rcx),%eax
 29e83e2:	sete   %al
 29e83e5:	movzbl %al,%eax
 29e83e8:	test   %eax,%eax
 29e83ea:	jne    29e8447 <wasm[0]::function[1015]::helper::object_read+0x7527>
 29e83f0:	mov    0x190(%rsp),%rsi
 29e83f8:	mov    0x190(%rsp),%rdi
 29e8400:	call   2a01ba0 <wasm[0]::function[1024]::helper::property_value_resolve>
 29e8405:	test   %eax,%eax
 29e8407:	je     29fbeeb <wasm[0]::function[1015]::helper::object_read+0x1afcb>
 29e840d:	test   %eax,%eax
 29e840f:	je     29fbeed <wasm[0]::function[1015]::helper::object_read+0x1afcd>
 29e8415:	mov    0x2e0(%rsp),%r12
 29e841d:	mov    0x28(%r12),%rcx
 29e8422:	mov    0x20(%r12),%rsi
 29e8427:	mov    %eax,%edx
 29e8429:	lea    (%rsi,%rdx,1),%rax
 29e842d:	xor    %rsi,%rsi
 29e8430:	cmp    %rcx,%rdx
 29e8433:	cmova  %rsi,%rax
 29e8437:	mov    0x18(%rax),%ebx
 29e843a:	mov    0x10(%rax),%r15
 29e843e:	mov    0x1c(%rax),%r14d
 29e8442:	jmp    29e84ce <wasm[0]::function[1015]::helper::object_read+0x75ae>
 29e8447:	xor    %eax,%eax
 29e8449:	test   $0x1,%edx
 29e844f:	jne    29e8492 <wasm[0]::function[1015]::helper::object_read+0x7572>
 29e8455:	mov    0x2e0(%rsp),%r12
 29e845d:	mov    0x28(%r12),%rax
 29e8462:	mov    0x20(%r12),%rcx
 29e8467:	mov    %edx,%esi
 29e8469:	lea    0x4(%rcx,%rsi,1),%rcx
 29e846e:	xor    %rdi,%rdi
 29e8471:	cmp    %rax,%rsi
 29e8474:	cmova  %rdi,%rcx
 29e8478:	mov    (%rcx),%eax
 29e847a:	mov    0x190(%rsp),%rcx
 29e8482:	mov    0x28(%rcx),%rcx
 29e8486:	cmp    0x120(%rcx),%eax
 29e848c:	sete   %al
 29e848f:	movzbl %al,%eax
 29e8492:	test   %eax,%eax
 29e8494:	je     29fbeef <wasm[0]::function[1015]::helper::object_read+0x1afcf>
 29e849a:	test   %edx,%edx
 29e849c:	je     29fbef1 <wasm[0]::function[1015]::helper::object_read+0x1afd1>
 29e84a2:	mov    0x2e0(%rsp),%r12
 29e84aa:	mov    0x28(%r12),%rcx
 29e84af:	mov    0x20(%r12),%rax
 29e84b4:	mov    %edx,%edx
 29e84b6:	add    %rdx,%rax
 29e84b9:	xor    %rsi,%rsi
 29e84bc:	cmp    %rcx,%rdx
 29e84bf:	cmova  %rsi,%rax
 29e84c3:	mov    0x18(%rax),%ebx
 29e84c6:	mov    0x10(%rax),%r15
 29e84ca:	mov    0x1c(%rax),%r14d
 29e84ce:	mov    0x278(%rsp),%rax
 29e84d6:	mov    %rax,0x270(%rsp)
 29e84de:	mov    0x100(%rsp),%edx
 29e84e5:	mov    %rdx,0x1a0(%rsp)
 29e84ed:	mov    0x78(%rsp),%esi
 29e84f1:	mov    %rsi,0x1c8(%rsp)
 29e84f9:	mov    0x88(%rsp),%edi
 29e8500:	mov    %rdi,0x1d0(%rsp)
 29e8508:	mov    0x120(%rsp),%edi
 29e850f:	mov    0x110(%rsp),%eax
 29e8516:	mov    0xd8(%rsp),%r8d
 29e851e:	mov    0x130(%rsp),%r9d
 29e8526:	mov    0xa0(%rsp),%r10d
 29e852e:	mov    %r15,0x250(%rsp)
 29e8536:	mov    %rbx,0x258(%rsp)
 29e853e:	jmp    29e8e91 <wasm[0]::function[1015]::helper::object_read+0x7f71>
 29e8543:	mov    0x138(%rsp),%eax
 29e854a:	test   %eax,%eax
 29e854c:	je     29fbef3 <wasm[0]::function[1015]::helper::object_read+0x1afd3>
 29e8552:	mov    0x138(%rsp),%ecx
 29e8559:	xor    %eax,%eax
 29e855b:	test   $0x1,%ecx
 29e8561:	jne    29e85bb <wasm[0]::function[1015]::helper::object_read+0x769b>
 29e8567:	mov    0x2e0(%rsp),%r12
 29e856f:	mov    0x28(%r12),%rax
 29e8574:	mov    0x20(%r12),%rsi
 29e8579:	mov    %ecx,%edx
 29e857b:	lea    0x4(%rsi,%rdx,1),%rcx
 29e8580:	xor    %rsi,%rsi
 29e8583:	cmp    %rax,%rdx
 29e8586:	cmova  %rsi,%rcx
 29e858a:	mov    (%rcx),%esi
 29e858c:	mov    0x190(%rsp),%rcx
 29e8594:	mov    0x28(%rcx),%rax
 29e8598:	mov    0x158(%rax),%edx
 29e859e:	cmp    %edx,%esi
 29e85a0:	sete   %al
 29e85a3:	movzbl %al,%eax
 29e85a6:	cmp    %edx,%esi
 29e85a8:	je     29e85bb <wasm[0]::function[1015]::helper::object_read+0x769b>
 29e85ae:	mov    0x190(%rsp),%rdi
 29e85b6:	call   3018e75 <wasmtime_builtin_is_subtype>
 29e85bb:	test   %eax,%eax
 29e85bd:	je     29fbef5 <wasm[0]::function[1015]::helper::object_read+0x1afd5>
 29e85c3:	mov    0x138(%rsp),%r13d
 29e85cb:	mov    0x100(%rsp),%edx
 29e85d2:	mov    %rdx,0x1a0(%rsp)
 29e85da:	mov    0x78(%rsp),%esi
 29e85de:	mov    %rsi,0x1c8(%rsp)
 29e85e6:	mov    0x88(%rsp),%edi
 29e85ed:	mov    %rdi,0x1d0(%rsp)
 29e85f5:	mov    0xc8(%rsp),%r14d
 29e85fd:	mov    0x120(%rsp),%edi
 29e8604:	mov    0x110(%rsp),%eax
 29e860b:	mov    0xd8(%rsp),%r8d
 29e8613:	mov    0x130(%rsp),%r9d
 29e861b:	mov    0xa0(%rsp),%r10d
 29e8623:	xor    %ecx,%ecx
 29e8625:	mov    %rcx,0x208(%rsp)
 29e862d:	test   %r13d,%r13d
 29e8630:	je     29fbef7 <wasm[0]::function[1015]::helper::object_read+0x1afd7>
 29e8636:	test   %r13d,%r13d
 29e8639:	je     29fbef9 <wasm[0]::function[1015]::helper::object_read+0x1afd9>
 29e863f:	mov    0x2e0(%rsp),%r12
 29e8647:	mov    0x28(%r12),%r11
 29e864c:	mov    0x20(%r12),%rcx
 29e8651:	mov    %r13d,%r15d
 29e8654:	lea    (%rcx,%r15,1),%rdx
 29e8658:	xor    %r12,%r12
 29e865b:	cmp    %r11,%r15
 29e865e:	cmova  %r12,%rdx
 29e8662:	mov    0x10(%rdx),%edx
 29e8665:	test   %edx,%edx
 29e8667:	je     29fbefb <wasm[0]::function[1015]::helper::object_read+0x1afdb>
 29e866d:	test   %edx,%edx
 29e866f:	je     29fbefd <wasm[0]::function[1015]::helper::object_read+0x1afdd>
 29e8675:	mov    %edx,%r15d
 29e8678:	lea    (%rcx,%r15,1),%rdx
 29e867c:	cmp    %r11,%r15
 29e867f:	cmova  %r12,%rdx
 29e8683:	mov    0x10(%rdx),%r15d
 29e8687:	test   %r15d,%r15d
 29e868a:	je     29fbeff <wasm[0]::function[1015]::helper::object_read+0x1afdf>
 29e8690:	test   %r15d,%r15d
 29e8693:	je     29fbf01 <wasm[0]::function[1015]::helper::object_read+0x1afe1>
 29e8699:	mov    %r15d,%edx
 29e869c:	lea    0x10(%rcx,%rdx,1),%rcx
 29e86a1:	cmp    %r11,%rdx
 29e86a4:	cmova  %r12,%rcx
 29e86a8:	mov    (%rcx),%ebx
 29e86aa:	mov    %rbx,0x218(%rsp)
 29e86b2:	mov    0xe0(%rsp),%r11d
 29e86ba:	mov    0x190(%rsp),%rcx
 29e86c2:	mov    0x28(%rcx),%rcx
 29e86c6:	mov    0x234(%rcx),%ebx
 29e86cc:	mov    0x208(%rsp),%rcx
 29e86d4:	mov    %rcx,0x270(%rsp)
 29e86dc:	mov    %r15d,0x118(%rsp)
 29e86e4:	mov    %r11d,0xa0(%rsp)
 29e86ec:	mov    %r13d,0x130(%rsp)
 29e86f4:	mov    0x1a0(%rsp),%rdx
 29e86fc:	mov    %edx,0xd8(%rsp)
 29e8703:	mov    0x1c8(%rsp),%rsi
 29e870b:	mov    %esi,0x110(%rsp)
 29e8712:	mov    0x1d0(%rsp),%rcx
 29e871a:	mov    %ecx,0x120(%rsp)
 29e8721:	mov    %r14d,0xc8(%rsp)
 29e8729:	mov    %edi,0x88(%rsp)
 29e8730:	mov    %eax,0x78(%rsp)
 29e8734:	mov    %r8d,0x100(%rsp)
 29e873c:	mov    %r9d,0x138(%rsp)
 29e8744:	mov    %r10d,0xe0(%rsp)
 29e874c:	mov    0x2e8(%rsp),%r13
 29e8754:	mov    0x0(%r13),%rax
 29e8758:	mov    0x228(%rsp),%rcx
 29e8760:	cmp    %rcx,%rax
 29e8763:	jae    29faa24 <wasm[0]::function[1015]::helper::object_read+0x19b04>
 29e8769:	mov    0x130(%rsp),%r13d
 29e8771:	mov    0xd8(%rsp),%edx
 29e8778:	mov    %rdx,0x1a0(%rsp)
 29e8780:	mov    0x110(%rsp),%esi
 29e8787:	mov    %rsi,0x1c8(%rsp)
 29e878f:	mov    0x120(%rsp),%edi
 29e8796:	mov    %rdi,0x1d0(%rsp)
 29e879e:	mov    0xc8(%rsp),%r14d
 29e87a6:	mov    0x88(%rsp),%edi
 29e87ad:	mov    0x78(%rsp),%eax
 29e87b1:	mov    0x100(%rsp),%r8d
 29e87b9:	mov    0x138(%rsp),%r9d
 29e87c1:	mov    0xe0(%rsp),%r10d
 29e87c9:	mov    0x208(%rsp),%rcx
 29e87d1:	mov    0x218(%rsp),%rdx
 29e87d9:	cmp    %edx,%ecx
 29e87db:	jae    29e8a2c <wasm[0]::function[1015]::helper::object_read+0x7b0c>
 29e87e1:	mov    0x118(%rsp),%eax
 29e87e8:	test   %eax,%eax
 29e87ea:	je     29fbf03 <wasm[0]::function[1015]::helper::object_read+0x1afe3>
 29e87f0:	test   %eax,%eax
 29e87f2:	je     29fbf05 <wasm[0]::function[1015]::helper::object_read+0x1afe5>
 29e87f8:	mov    0x2e0(%rsp),%r12
 29e8800:	mov    0x28(%r12),%rdx
 29e8805:	mov    0x20(%r12),%rsi
 29e880a:	mov    %eax,%r9d
 29e880d:	lea    0x10(%rsi,%r9,1),%r8
 29e8812:	xor    %rdi,%rdi
 29e8815:	cmp    %rdx,%r9
 29e8818:	cmova  %rdi,%r8
 29e881c:	mov    (%r8),%r8d
 29e881f:	cmp    %r8d,%ecx
 29e8822:	jae    29fbf07 <wasm[0]::function[1015]::helper::object_read+0x1afe7>
 29e8828:	mov    %r8d,%r9d
 29e882b:	shl    $0x2,%r9
 29e882f:	shr    $0x20,%r9
 29e8833:	test   %r9,%r9
 29e8836:	jne    29fbf09 <wasm[0]::function[1015]::helper::object_read+0x1afe9>
 29e883c:	shl    $0x2,%r8d
 29e8840:	add    $0x14,%r8d
 29e8844:	jb     29fbf0b <wasm[0]::function[1015]::helper::object_read+0x1afeb>
 29e884a:	add    %r8d,%eax
 29e884d:	jb     29fbf0d <wasm[0]::function[1015]::helper::object_read+0x1afed>
 29e8853:	mov    %eax,%r9d
 29e8856:	lea    (%rsi,%r9,1),%rax
 29e885a:	cmp    %rdx,%r9
 29e885d:	cmova  %rdi,%rax
 29e8861:	mov    %rcx,%rdx
 29e8864:	shl    $0x2,%edx
 29e8867:	mov    %rcx,0x208(%rsp)
 29e886f:	lea    0x14(%rdx),%ecx
 29e8872:	sub    %ecx,%r8d
 29e8875:	sub    %r8,%rax
 29e8878:	mov    (%rax),%edx
 29e887a:	test   %edx,%edx
 29e887c:	je     29fbf0f <wasm[0]::function[1015]::helper::object_read+0x1afef>
 29e8882:	mov    0xa0(%rsp),%eax
 29e8889:	cmp    %eax,%edx
 29e888b:	je     29e896c <wasm[0]::function[1015]::helper::object_read+0x7a4c>
 29e8891:	xor    %ecx,%ecx
 29e8893:	test   %edx,%edx
 29e8895:	je     29e88d8 <wasm[0]::function[1015]::helper::object_read+0x79b8>
 29e889b:	xor    %ecx,%ecx
 29e889d:	test   $0x1,%edx
 29e88a3:	jne    29e88d8 <wasm[0]::function[1015]::helper::object_read+0x79b8>
 29e88a9:	mov    0x2e0(%rsp),%r12
 29e88b1:	mov    0x28(%r12),%rcx
 29e88b6:	mov    0x20(%r12),%rsi
 29e88bb:	mov    %edx,%edi
 29e88bd:	lea    0x4(%rsi,%rdi,1),%rsi
 29e88c2:	xor    %r8,%r8
 29e88c5:	cmp    %rcx,%rdi
 29e88c8:	cmova  %r8,%rsi
 29e88cc:	mov    (%rsi),%ecx
 29e88ce:	cmp    %ebx,%ecx
 29e88d0:	sete   %sil
 29e88d4:	movzbl %sil,%ecx
 29e88d8:	test   %ecx,%ecx
 29e88da:	je     29fbf11 <wasm[0]::function[1015]::helper::object_read+0x1aff1>
 29e88e0:	xor    %ecx,%ecx
 29e88e2:	test   %eax,%eax
 29e88e4:	je     29e8930 <wasm[0]::function[1015]::helper::object_read+0x7a10>
 29e88ea:	mov    0xa0(%rsp),%r8d
 29e88f2:	xor    %ecx,%ecx
 29e88f4:	test   $0x1,%r8d
 29e88fb:	jne    29e8930 <wasm[0]::function[1015]::helper::object_read+0x7a10>
 29e8901:	mov    0x2e0(%rsp),%r12
 29e8909:	mov    0x28(%r12),%r11
 29e890e:	mov    0x20(%r12),%rcx
 29e8913:	mov    %r8d,%eax
 29e8916:	lea    0x4(%rcx,%rax,1),%r8
 29e891b:	xor    %rcx,%rcx
 29e891e:	cmp    %r11,%rax
 29e8921:	cmova  %rcx,%r8
 29e8925:	mov    (%r8),%eax
 29e8928:	cmp    %ebx,%eax
 29e892a:	sete   %al
 29e892d:	movzbl %al,%ecx
 29e8930:	test   %ecx,%ecx
 29e8932:	je     29fbf13 <wasm[0]::function[1015]::helper::object_read+0x1aff3>
 29e8938:	mov    0xa0(%rsp),%ecx
 29e893f:	xor    %r8d,%r8d
 29e8942:	test   %ecx,%ecx
 29e8944:	je     29fbf15 <wasm[0]::function[1015]::helper::object_read+0x1aff5>
 29e894a:	mov    0x190(%rsp),%rsi
 29e8952:	mov    0x190(%rsp),%rdi
 29e895a:	call   2ae54e0 <wasm[0]::function[1057]::helper::string_equality>
 29e895f:	mov    %rax,0x270(%rsp)
 29e8967:	jmp    29e897c <wasm[0]::function[1015]::helper::object_read+0x7a5c>
 29e896c:	mov    0x278(%rsp),%rax
 29e8974:	mov    %rax,0x270(%rsp)
 29e897c:	mov    0x118(%rsp),%r15d
 29e8984:	mov    0xa0(%rsp),%r11d
 29e898c:	mov    0x130(%rsp),%r13d
 29e8994:	mov    0xd8(%rsp),%edx
 29e899b:	mov    %rdx,0x1a0(%rsp)
 29e89a3:	mov    0x110(%rsp),%esi
 29e89aa:	mov    %rsi,0x1c8(%rsp)
 29e89b2:	mov    0x120(%rsp),%edi
 29e89b9:	mov    %rdi,0x1d0(%rsp)
 29e89c1:	mov    0xc8(%rsp),%r14d
 29e89c9:	mov    0x88(%rsp),%edi
 29e89d0:	mov    0x78(%rsp),%eax
 29e89d4:	mov    0x100(%rsp),%r8d
 29e89dc:	mov    0x138(%rsp),%r9d
 29e89e4:	mov    0xe0(%rsp),%r10d
 29e89ec:	mov    0x270(%rsp),%rcx
 29e89f4:	mov    0x270(%rsp),%rdx
 29e89fc:	test   %edx,%ecx
 29e89fe:	je     29e8a11 <wasm[0]::function[1015]::helper::object_read+0x7af1>
 29e8a04:	mov    0x208(%rsp),%rcx
 29e8a0c:	jmp    29e8a2c <wasm[0]::function[1015]::helper::object_read+0x7b0c>
 29e8a11:	mov    0x208(%rsp),%rcx
 29e8a19:	add    $0x1,%ecx
 29e8a1f:	mov    %rcx,0x208(%rsp)
 29e8a27:	jmp    29e86dc <wasm[0]::function[1015]::helper::object_read+0x77bc>
 29e8a2c:	xor    %r15,%r15
 29e8a2f:	xor    %ebx,%ebx
 29e8a31:	mov    0x270(%rsp),%rdx
 29e8a39:	mov    0x270(%rsp),%rsi
 29e8a41:	test   %esi,%edx
 29e8a43:	jne    29e8a5e <wasm[0]::function[1015]::helper::object_read+0x7b3e>
 29e8a49:	mov    %r15,0x250(%rsp)
 29e8a51:	mov    %rbx,0x258(%rsp)
 29e8a59:	jmp    29e8e91 <wasm[0]::function[1015]::helper::object_read+0x7f71>
 29e8a5e:	test   %r13d,%r13d
 29e8a61:	je     29fbf17 <wasm[0]::function[1015]::helper::object_read+0x1aff7>
 29e8a67:	xor    %edx,%edx
 29e8a69:	test   $0x1,%r13d
 29e8a70:	jne    29e8ab5 <wasm[0]::function[1015]::helper::object_read+0x7b95>
 29e8a76:	mov    0x2e0(%rsp),%r12
 29e8a7e:	mov    0x28(%r12),%rdx
 29e8a83:	mov    0x20(%r12),%r11
 29e8a88:	mov    %r13d,%ebx
 29e8a8b:	lea    0x4(%r11,%rbx,1),%r11
 29e8a90:	xor    %r12,%r12
 29e8a93:	cmp    %rdx,%rbx
 29e8a96:	cmova  %r12,%r11
 29e8a9a:	mov    (%r11),%edx
 29e8a9d:	mov    0x190(%rsp),%rsi
 29e8aa5:	mov    0x28(%rsi),%rsi
 29e8aa9:	cmp    0x160(%rsi),%edx
 29e8aaf:	sete   %dl
 29e8ab2:	movzbl %dl,%edx
 29e8ab5:	test   %edx,%edx
 29e8ab7:	jne    29e8d16 <wasm[0]::function[1015]::helper::object_read+0x7df6>
 29e8abd:	xor    %r11d,%r11d
 29e8ac0:	test   $0x1,%r13d
 29e8ac7:	jne    29e8b0d <wasm[0]::function[1015]::helper::object_read+0x7bed>
 29e8acd:	mov    0x2e0(%rsp),%r12
 29e8ad5:	mov    0x28(%r12),%rdx
 29e8ada:	mov    0x20(%r12),%r11
 29e8adf:	mov    %r13d,%ebx
 29e8ae2:	lea    0x4(%r11,%rbx,1),%r11
 29e8ae7:	xor    %r12,%r12
 29e8aea:	cmp    %rdx,%rbx
 29e8aed:	cmova  %r12,%r11
 29e8af1:	mov    (%r11),%edx
 29e8af4:	mov    0x190(%rsp),%rsi
 29e8afc:	mov    0x28(%rsi),%rsi
 29e8b00:	cmp    0x15c(%rsi),%edx
 29e8b06:	sete   %dl
 29e8b09:	movzbl %dl,%r11d
 29e8b0d:	test   %r11d,%r11d
 29e8b10:	je     29fbf19 <wasm[0]::function[1015]::helper::object_read+0x1aff9>
 29e8b16:	test   %r13d,%r13d
 29e8b19:	je     29fbf1b <wasm[0]::function[1015]::helper::object_read+0x1affb>
 29e8b1f:	mov    0x2e0(%rsp),%r12
 29e8b27:	mov    0x28(%r12),%r11
 29e8b2c:	mov    0x20(%r12),%r12
 29e8b31:	mov    %r13d,%ebx
 29e8b34:	lea    (%r12,%rbx,1),%rdx
 29e8b38:	xor    %r15,%r15
 29e8b3b:	cmp    %r11,%rbx
 29e8b3e:	cmova  %r15,%rdx
 29e8b42:	mov    0x14(%rdx),%r13d
 29e8b46:	mov    0x18(%rdx),%r14d
 29e8b4a:	mov    0x1c(%rdx),%ebx
 29e8b4d:	test   %r13d,%r13d
 29e8b50:	je     29fbf1d <wasm[0]::function[1015]::helper::object_read+0x1affd>
 29e8b56:	test   %r13d,%r13d
 29e8b59:	je     29fbf1f <wasm[0]::function[1015]::helper::object_read+0x1afff>
 29e8b5f:	mov    %r13d,%esi
 29e8b62:	lea    0x10(%r12,%rsi,1),%rdx
 29e8b67:	cmp    %r11,%rsi
 29e8b6a:	cmova  %r15,%rdx
 29e8b6e:	mov    (%rdx),%edx
 29e8b70:	cmp    %edx,%ecx
 29e8b72:	jae    29fbf21 <wasm[0]::function[1015]::helper::object_read+0x1b001>
 29e8b78:	mov    %edx,%esi
 29e8b7a:	shr    $0x20,%rsi
 29e8b7e:	test   %rsi,%rsi
 29e8b81:	jne    29fbf23 <wasm[0]::function[1015]::helper::object_read+0x1b003>
 29e8b87:	add    $0x14,%edx
 29e8b8a:	jb     29fbf25 <wasm[0]::function[1015]::helper::object_read+0x1b005>
 29e8b90:	add    %edx,%r13d
 29e8b93:	jb     29fbf27 <wasm[0]::function[1015]::helper::object_read+0x1b007>
 29e8b99:	mov    %r13d,%esi
 29e8b9c:	add    %rsi,%r12
 29e8b9f:	cmp    %r11,%rsi
 29e8ba2:	cmova  %r15,%r12
 29e8ba6:	lea    0x14(%rcx),%esi
 29e8ba9:	sub    %esi,%edx
 29e8bab:	sub    %rdx,%r12
 29e8bae:	movzbq (%r12),%rdx
 29e8bb3:	mov    %rdx,0x218(%rsp)
 29e8bbb:	test   %r14d,%r14d
 29e8bbe:	je     29e8c54 <wasm[0]::function[1015]::helper::object_read+0x7d34>
 29e8bc4:	test   %r14d,%r14d
 29e8bc7:	je     29fbf29 <wasm[0]::function[1015]::helper::object_read+0x1b009>
 29e8bcd:	test   %r14d,%r14d
 29e8bd0:	je     29fbf2b <wasm[0]::function[1015]::helper::object_read+0x1b00b>
 29e8bd6:	mov    0x2e0(%rsp),%r12
 29e8bde:	mov    0x28(%r12),%r11
 29e8be3:	mov    0x20(%r12),%r12
 29e8be8:	mov    %r14d,%r13d
 29e8beb:	lea    0x10(%r12,%r13,1),%rdx
 29e8bf0:	xor    %r15,%r15
 29e8bf3:	cmp    %r11,%r13
 29e8bf6:	cmova  %r15,%rdx
 29e8bfa:	mov    (%rdx),%r13d
 29e8bfd:	cmp    %r13d,%ecx
 29e8c00:	jae    29fbf2d <wasm[0]::function[1015]::helper::object_read+0x1b00d>
 29e8c06:	mov    %r13d,%edx
 29e8c09:	shl    $0x3,%rdx
 29e8c0d:	shr    $0x20,%rdx
 29e8c11:	test   %rdx,%rdx
 29e8c14:	jne    29fbf2f <wasm[0]::function[1015]::helper::object_read+0x1b00f>
 29e8c1a:	shl    $0x3,%r13d
 29e8c1e:	add    $0x18,%r13d
 29e8c22:	jb     29fbf31 <wasm[0]::function[1015]::helper::object_read+0x1b011>
 29e8c28:	add    %r13d,%r14d
 29e8c2b:	jb     29fbf33 <wasm[0]::function[1015]::helper::object_read+0x1b013>
 29e8c31:	mov    %r14d,%esi
 29e8c34:	lea    (%r12,%rsi,1),%rdx
 29e8c38:	cmp    %r11,%rsi
 29e8c3b:	cmova  %r15,%rdx
 29e8c3f:	mov    %rcx,%rsi
 29e8c42:	shl    $0x3,%esi
 29e8c45:	add    $0x18,%esi
 29e8c4b:	sub    %esi,%r13d
 29e8c4e:	sub    %r13,%rdx
 29e8c51:	mov    (%rdx),%r15
 29e8c54:	xor    %r14d,%r14d
 29e8c57:	test   %ebx,%ebx
 29e8c59:	jne    29e8c6c <wasm[0]::function[1015]::helper::object_read+0x7d4c>
 29e8c5f:	mov    0x218(%rsp),%rdx
 29e8c67:	jmp    29e8cfe <wasm[0]::function[1015]::helper::object_read+0x7dde>
 29e8c6c:	test   %ebx,%ebx
 29e8c6e:	je     29fbf35 <wasm[0]::function[1015]::helper::object_read+0x1b015>
 29e8c74:	test   %ebx,%ebx
 29e8c76:	je     29fbf37 <wasm[0]::function[1015]::helper::object_read+0x1b017>
 29e8c7c:	mov    0x2e0(%rsp),%r12
 29e8c84:	mov    0x28(%r12),%r11
 29e8c89:	mov    0x20(%r12),%r12
 29e8c8e:	mov    %ebx,%r14d
 29e8c91:	lea    0x10(%r12,%r14,1),%rdx
 29e8c96:	xor    %r13,%r13
 29e8c99:	cmp    %r11,%r14
 29e8c9c:	cmova  %r13,%rdx
 29e8ca0:	mov    (%rdx),%r14d
 29e8ca3:	cmp    %r14d,%ecx
 29e8ca6:	jae    29fbf39 <wasm[0]::function[1015]::helper::object_read+0x1b019>
 29e8cac:	mov    %r14d,%edx
 29e8caf:	shl    $0x2,%rdx
 29e8cb3:	shr    $0x20,%rdx
 29e8cb7:	test   %rdx,%rdx
 29e8cba:	jne    29fbf3b <wasm[0]::function[1015]::helper::object_read+0x1b01b>
 29e8cc0:	shl    $0x2,%r14d
 29e8cc4:	add    $0x14,%r14d
 29e8cc8:	jb     29fbf3d <wasm[0]::function[1015]::helper::object_read+0x1b01d>
 29e8cce:	add    %r14d,%ebx
 29e8cd1:	jb     29fbf3f <wasm[0]::function[1015]::helper::object_read+0x1b01f>
 29e8cd7:	mov    %ebx,%esi
 29e8cd9:	lea    (%r12,%rsi,1),%rdx
 29e8cdd:	cmp    %r11,%rsi
 29e8ce0:	cmova  %r13,%rdx
 29e8ce4:	shl    $0x2,%ecx
 29e8ce7:	add    $0x14,%ecx
 29e8ced:	sub    %ecx,%r14d
 29e8cf0:	sub    %r14,%rdx
 29e8cf3:	mov    (%rdx),%r14d
 29e8cf6:	mov    0x218(%rsp),%rdx
 29e8cfe:	movzbl %dl,%ebx
 29e8d01:	mov    %r15,0x250(%rsp)
 29e8d09:	mov    %rbx,0x258(%rsp)
 29e8d11:	jmp    29e8e91 <wasm[0]::function[1015]::helper::object_read+0x7f71>
 29e8d16:	xor    %edx,%edx
 29e8d18:	test   $0x1,%r13d
 29e8d1f:	jne    29e8d64 <wasm[0]::function[1015]::helper::object_read+0x7e44>
 29e8d25:	mov    0x2e0(%rsp),%r12
 29e8d2d:	mov    0x28(%r12),%rdx
 29e8d32:	mov    0x20(%r12),%rsi
 29e8d37:	mov    %r13d,%ebx
 29e8d3a:	lea    0x4(%rsi,%rbx,1),%r11
 29e8d3f:	xor    %r12,%r12
 29e8d42:	cmp    %rdx,%rbx
 29e8d45:	cmova  %r12,%r11
 29e8d49:	mov    (%r11),%edx
 29e8d4c:	mov    0x190(%rsp),%rsi
 29e8d54:	mov    0x28(%rsi),%rsi
 29e8d58:	cmp    0x160(%rsi),%edx
 29e8d5e:	sete   %dl
 29e8d61:	movzbl %dl,%edx
 29e8d64:	test   %edx,%edx
 29e8d66:	je     29fbf41 <wasm[0]::function[1015]::helper::object_read+0x1b021>
 29e8d6c:	test   %r13d,%r13d
 29e8d6f:	je     29fbf43 <wasm[0]::function[1015]::helper::object_read+0x1b023>
 29e8d75:	mov    0x2e0(%rsp),%r12
 29e8d7d:	mov    0x28(%r12),%r11
 29e8d82:	mov    0x20(%r12),%rbx
 29e8d87:	mov    %r13d,%r13d
 29e8d8a:	lea    (%rbx,%r13,1),%rdx
 29e8d8e:	xor    %r12,%r12
 29e8d91:	cmp    %r11,%r13
 29e8d94:	cmova  %r12,%rdx
 29e8d98:	mov    0x10(%rdx),%edx
 29e8d9b:	test   %edx,%edx
 29e8d9d:	je     29fbf45 <wasm[0]::function[1015]::helper::object_read+0x1b025>
 29e8da3:	test   %edx,%edx
 29e8da5:	je     29fbf47 <wasm[0]::function[1015]::helper::object_read+0x1b027>
 29e8dab:	mov    %edx,%esi
 29e8dad:	lea    (%rbx,%rsi,1),%rdx
 29e8db1:	cmp    %r11,%rsi
 29e8db4:	cmova  %r12,%rdx
 29e8db8:	mov    0x10(%rdx),%edx
 29e8dbb:	test   %edx,%edx
 29e8dbd:	je     29fbf49 <wasm[0]::function[1015]::helper::object_read+0x1b029>
 29e8dc3:	test   %edx,%edx
 29e8dc5:	je     29fbf4b <wasm[0]::function[1015]::helper::object_read+0x1b02b>
 29e8dcb:	mov    %edx,%esi
 29e8dcd:	lea    0x10(%rbx,%rsi,1),%rdx
 29e8dd2:	cmp    %r11,%rsi
 29e8dd5:	cmova  %r12,%rdx
 29e8dd9:	cmp    (%rdx),%ecx
 29e8ddb:	setae  %dl
 29e8dde:	cmp    $0x2,%ecx
 29e8de1:	setae  %sil
 29e8de5:	or     %esi,%edx
 29e8de7:	test   %dl,%dl
 29e8de9:	jne    29fbf4d <wasm[0]::function[1015]::helper::object_read+0x1b02d>
 29e8def:	mov    0x2e0(%rsp),%r12
 29e8df7:	mov    0x28(%r12),%r11
 29e8dfc:	mov    %r13,%rdx
 29e8dff:	add    0x20(%r12),%rdx
 29e8e04:	xor    %rbx,%rbx
 29e8e07:	cmp    %r11,%r13
 29e8e0a:	cmova  %rbx,%rdx
 29e8e0e:	mov    0x14(%rdx),%ebx
 29e8e11:	test   %ecx,%ecx
 29e8e13:	je     29e8e4e <wasm[0]::function[1015]::helper::object_read+0x7f2e>
 29e8e19:	mov    0x2e0(%rsp),%r12
 29e8e21:	mov    0x28(%r12),%r11
 29e8e26:	mov    0x20(%r12),%rsi
 29e8e2b:	lea    (%rsi,%r13,1),%rdx
 29e8e2f:	xor    %r12,%r12
 29e8e32:	cmp    %r11,%r13
 29e8e35:	cmova  %r12,%rdx
 29e8e39:	mov    0x20(%rdx),%r15
 29e8e3d:	mov    0x2c(%rdx),%r14d
 29e8e41:	mov    %r15,0x250(%rsp)
 29e8e49:	jmp    29e8e7e <wasm[0]::function[1015]::helper::object_read+0x7f5e>
 29e8e4e:	mov    0x2e0(%rsp),%r12
 29e8e56:	mov    0x28(%r12),%r11
 29e8e5b:	mov    0x20(%r12),%rsi
 29e8e60:	lea    (%rsi,%r13,1),%rdx
 29e8e64:	xor    %r12,%r12
 29e8e67:	cmp    %r11,%r13
 29e8e6a:	cmova  %r12,%rdx
 29e8e6e:	mov    0x18(%rdx),%r15
 29e8e72:	mov    %r15,0x250(%rsp)
 29e8e7a:	mov    0x28(%rdx),%r14d
 29e8e7e:	shl    $0x3,%ecx
 29e8e81:	shr    %cl,%ebx
 29e8e83:	and    $0xff,%ebx
 29e8e89:	mov    %rbx,0x258(%rsp)
 29e8e91:	mov    0x1a0(%rsp),%rdx
 29e8e99:	mov    %edx,0x78(%rsp)
 29e8e9d:	mov    0x1c8(%rsp),%rsi
 29e8ea5:	mov    %esi,0x88(%rsp)
 29e8eac:	mov    0x1d0(%rsp),%rcx
 29e8eb4:	mov    %ecx,0xc8(%rsp)
 29e8ebb:	mov    %r14d,0x120(%rsp)
 29e8ec3:	mov    %edi,0x110(%rsp)
 29e8eca:	mov    %eax,0xd8(%rsp)
 29e8ed1:	mov    %r8d,0x130(%rsp)
 29e8ed9:	mov    %r9d,0xa0(%rsp)
 29e8ee1:	mov    %r10d,0x118(%rsp)
 29e8ee9:	mov    $0x27c,%edx
 29e8eee:	mov    0x190(%rsp),%rsi
 29e8ef6:	mov    0x190(%rsp),%rdi
 29e8efe:	call   2f307a0 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 29e8f03:	mov    %eax,0x100(%rsp)
 29e8f0a:	xor    %esi,%esi
 29e8f0c:	test   %eax,%eax
 29e8f0e:	je     29fbf4f <wasm[0]::function[1015]::helper::object_read+0x1b02f>
 29e8f14:	movl   $0x0,0x138(%rsp)
 29e8f1f:	mov    0x78(%rsp),%r8d
 29e8f24:	mov    %r8,0x1d8(%rsp)
 29e8f2c:	mov    0x88(%rsp),%r13d
 29e8f34:	mov    %r13,0x1e0(%rsp)
 29e8f3c:	mov    0xc8(%rsp),%edx
 29e8f43:	mov    %rdx,0x1e8(%rsp)
 29e8f4b:	mov    0x120(%rsp),%edi
 29e8f52:	mov    %rdi,0x1f0(%rsp)
 29e8f5a:	mov    0x110(%rsp),%edi
 29e8f61:	mov    0xd8(%rsp),%r9d
 29e8f69:	mov    0x130(%rsp),%r8d
 29e8f71:	mov    0xa0(%rsp),%r10d
 29e8f79:	mov    0x118(%rsp),%r11d
 29e8f81:	xor    %r15,%r15
 29e8f84:	mov    0x2a0(%rsp),%rax
 29e8f8c:	mov    0x2a0(%rsp),%rcx
 29e8f94:	test   %al,%cl
 29e8f96:	jne    29e8fbc <wasm[0]::function[1015]::helper::object_read+0x809c>
 29e8f9c:	mov    0x1d8(%rsp),%rax
 29e8fa4:	mov    %rsi,%r14
 29e8fa7:	mov    %r15,0x260(%rsp)
 29e8faf:	mov    %rsi,0x268(%rsp)
 29e8fb7:	jmp    29e9ca3 <wasm[0]::function[1015]::helper::object_read+0x8d83>
 29e8fbc:	mov    0x78(%rsp),%r8d
 29e8fc1:	mov    0x2b0(%rsp),%rcx
 29e8fc9:	mov    0x2a8(%rsp),%rdx
 29e8fd1:	mov    0x190(%rsp),%rsi
 29e8fd9:	mov    0x190(%rsp),%rdi
 29e8fe1:	call   2a5f620 <wasm[0]::function[1039]::helper::object_header_projection>
 29e8fe6:	mov    %eax,0xe0(%rsp)
 29e8fed:	test   %eax,%eax
 29e8fef:	je     29fbf51 <wasm[0]::function[1015]::helper::object_read+0x1b031>
 29e8ff5:	test   %eax,%eax
 29e8ff7:	je     29fbf53 <wasm[0]::function[1015]::helper::object_read+0x1b033>
 29e8ffd:	mov    0x2e0(%rsp),%r12
 29e9005:	mov    0x28(%r12),%rcx
 29e900a:	mov    0x20(%r12),%rsi
 29e900f:	mov    %eax,%edx
 29e9011:	lea    (%rsi,%rdx,1),%rax
 29e9015:	xor    %rsi,%rsi
 29e9018:	cmp    %rcx,%rdx
 29e901b:	cmova  %rsi,%rax
 29e901f:	mov    0x14(%rax),%eax
 29e9022:	mov    %eax,0x108(%rsp)
 29e9029:	test   %eax,%eax
 29e902b:	je     29fbf55 <wasm[0]::function[1015]::helper::object_read+0x1b035>
 29e9031:	mov    0x108(%rsp),%ecx
 29e9038:	xor    %eax,%eax
 29e903a:	test   $0x1,%ecx
 29e9040:	jne    29e909a <wasm[0]::function[1015]::helper::object_read+0x817a>
 29e9046:	mov    0x2e0(%rsp),%r12
 29e904e:	mov    0x28(%r12),%rax
 29e9053:	mov    0x20(%r12),%rsi
 29e9058:	mov    %ecx,%edx
 29e905a:	lea    0x4(%rsi,%rdx,1),%rcx
 29e905f:	xor    %rsi,%rsi
 29e9062:	cmp    %rax,%rdx
 29e9065:	cmova  %rsi,%rcx
 29e9069:	mov    (%rcx),%esi
 29e906b:	mov    0x190(%rsp),%rcx
 29e9073:	mov    0x28(%rcx),%rax
 29e9077:	mov    0x158(%rax),%edx
 29e907d:	cmp    %edx,%esi
 29e907f:	sete   %al
 29e9082:	movzbl %al,%eax
 29e9085:	cmp    %edx,%esi
 29e9087:	je     29e909a <wasm[0]::function[1015]::helper::object_read+0x817a>
 29e908d:	mov    0x190(%rsp),%rdi
 29e9095:	call   3018e75 <wasmtime_builtin_is_subtype>
 29e909a:	test   %eax,%eax
 29e909c:	jne    29e9321 <wasm[0]::function[1015]::helper::object_read+0x8401>
 29e90a2:	mov    0xe0(%rsp),%edx
 29e90a9:	xor    %ebx,%ebx
 29e90ab:	test   %edx,%edx
 29e90ad:	je     29fbf57 <wasm[0]::function[1015]::helper::object_read+0x1b037>
 29e90b3:	mov    0x100(%rsp),%r9d
 29e90bb:	mov    $0x4,%ecx
 29e90c0:	xor    %r8,%r8
 29e90c3:	mov    0x190(%rsp),%rsi
 29e90cb:	mov    0x190(%rsp),%rdi
 29e90d3:	call   2a58e20 <wasm[0]::function[1032]::helper::ordinary_property_find>
 29e90d8:	test   %eax,%eax
 29e90da:	je     29e9114 <wasm[0]::function[1015]::helper::object_read+0x81f4>
 29e90e0:	test   %eax,%eax
 29e90e2:	je     29fbf59 <wasm[0]::function[1015]::helper::object_read+0x1b039>
 29e90e8:	test   %eax,%eax
 29e90ea:	je     29fbf5b <wasm[0]::function[1015]::helper::object_read+0x1b03b>
 29e90f0:	mov    0x2e0(%rsp),%r12
 29e90f8:	mov    0x28(%r12),%rcx
 29e90fd:	mov    %eax,%edx
 29e90ff:	mov    %rdx,%rax
 29e9102:	add    0x20(%r12),%rax
 29e9107:	xor    %rsi,%rsi
 29e910a:	cmp    %rcx,%rdx
 29e910d:	cmova  %rsi,%rax
 29e9111:	mov    0x14(%rax),%ebx
 29e9114:	mov    0x138(%rsp),%r14d
 29e911c:	xor    %r15,%r15
 29e911f:	xor    %esi,%esi
 29e9121:	test   %ebx,%ebx
 29e9123:	je     29e92aa <wasm[0]::function[1015]::helper::object_read+0x838a>
 29e9129:	test   %ebx,%ebx
 29e912b:	je     29fbf5d <wasm[0]::function[1015]::helper::object_read+0x1b03d>
 29e9131:	mov    0x2e0(%rsp),%r12
 29e9139:	mov    0x28(%r12),%rdx
 29e913e:	mov    0x20(%r12),%rdi
 29e9143:	mov    %ebx,%esi
 29e9145:	lea    (%rdi,%rsi,1),%rax
 29e9149:	xor    %r15,%r15
 29e914c:	cmp    %rdx,%rsi
 29e914f:	cmova  %r15,%rax
 29e9153:	mov    0x10(%rax),%edi
 29e9156:	mov    0x138(%rsp),%r14d
 29e915e:	xor    %esi,%esi
 29e9160:	test   $0x1,%edi
 29e9166:	jne    29e92aa <wasm[0]::function[1015]::helper::object_read+0x838a>
 29e916c:	mov    0x14(%rax),%edx
 29e916f:	test   %edx,%edx
 29e9171:	je     29fbf5f <wasm[0]::function[1015]::helper::object_read+0x1b03f>
 29e9177:	xor    %eax,%eax
 29e9179:	test   $0x1,%edx
 29e917f:	jne    29e91c3 <wasm[0]::function[1015]::helper::object_read+0x82a3>
 29e9185:	mov    0x2e0(%rsp),%r12
 29e918d:	mov    0x28(%r12),%rax
 29e9192:	mov    0x20(%r12),%rsi
 29e9197:	mov    %edx,%ecx
 29e9199:	lea    0x4(%rsi,%rcx,1),%r9
 29e919e:	xor    %rsi,%rsi
 29e91a1:	cmp    %rax,%rcx
 29e91a4:	cmova  %rsi,%r9
 29e91a8:	mov    (%r9),%eax
 29e91ab:	mov    0x190(%rsp),%rcx
 29e91b3:	mov    0x28(%rcx),%rcx
 29e91b7:	cmp    0x120(%rcx),%eax
 29e91bd:	sete   %al
 29e91c0:	movzbl %al,%eax
 29e91c3:	test   %eax,%eax
 29e91c5:	jne    29e9222 <wasm[0]::function[1015]::helper::object_read+0x8302>
 29e91cb:	mov    0x190(%rsp),%rsi
 29e91d3:	mov    0x190(%rsp),%rdi
 29e91db:	call   2a01ba0 <wasm[0]::function[1024]::helper::property_value_resolve>
 29e91e0:	test   %eax,%eax
 29e91e2:	je     29fbf61 <wasm[0]::function[1015]::helper::object_read+0x1b041>
 29e91e8:	test   %eax,%eax
 29e91ea:	je     29fbf63 <wasm[0]::function[1015]::helper::object_read+0x1b043>
 29e91f0:	mov    0x2e0(%rsp),%r12
 29e91f8:	mov    0x28(%r12),%rcx
 29e91fd:	mov    0x20(%r12),%rsi
 29e9202:	mov    %eax,%edx
 29e9204:	lea    (%rsi,%rdx,1),%rax
 29e9208:	xor    %rsi,%rsi
 29e920b:	cmp    %rcx,%rdx
 29e920e:	cmova  %rsi,%rax
 29e9212:	mov    0x18(%rax),%esi
 29e9215:	mov    0x10(%rax),%r15
 29e9219:	mov    0x1c(%rax),%r14d
 29e921d:	jmp    29e92aa <wasm[0]::function[1015]::helper::object_read+0x838a>
 29e9222:	xor    %esi,%esi
 29e9224:	test   $0x1,%edx
 29e922a:	jne    29e926e <wasm[0]::function[1015]::helper::object_read+0x834e>
 29e9230:	mov    0x2e0(%rsp),%r12
 29e9238:	mov    0x28(%r12),%rax
 29e923d:	mov    0x20(%r12),%rcx
 29e9242:	mov    %edx,%esi
 29e9244:	lea    0x4(%rcx,%rsi,1),%rcx
 29e9249:	xor    %rdi,%rdi
 29e924c:	cmp    %rax,%rsi
 29e924f:	cmova  %rdi,%rcx
 29e9253:	mov    (%rcx),%eax
 29e9255:	mov    0x190(%rsp),%rcx
 29e925d:	mov    0x28(%rcx),%rcx
 29e9261:	cmp    0x120(%rcx),%eax
 29e9267:	sete   %al
 29e926a:	rex movzbl %al,%esi
 29e926e:	test   %esi,%esi
 29e9270:	je     29fbf65 <wasm[0]::function[1015]::helper::object_read+0x1b045>
 29e9276:	test   %edx,%edx
 29e9278:	je     29fbf67 <wasm[0]::function[1015]::helper::object_read+0x1b047>
 29e927e:	mov    0x2e0(%rsp),%r12
 29e9286:	mov    0x28(%r12),%rcx
 29e928b:	mov    0x20(%r12),%rax
 29e9290:	mov    %edx,%edx
 29e9292:	add    %rdx,%rax
 29e9295:	xor    %rsi,%rsi
 29e9298:	cmp    %rcx,%rdx
 29e929b:	cmova  %rsi,%rax
 29e929f:	mov    0x18(%rax),%esi
 29e92a2:	mov    0x10(%rax),%r15
 29e92a6:	mov    0x1c(%rax),%r14d
 29e92aa:	mov    0x78(%rsp),%r8d
 29e92af:	mov    %r8,0x1d8(%rsp)
 29e92b7:	mov    0x88(%rsp),%r13d
 29e92bf:	mov    %r13,0x1e0(%rsp)
 29e92c7:	mov    0xc8(%rsp),%edx
 29e92ce:	mov    %rdx,0x1e8(%rsp)
 29e92d6:	mov    0x120(%rsp),%edi
 29e92dd:	mov    %rdi,0x1f0(%rsp)
 29e92e5:	mov    0x110(%rsp),%edi
 29e92ec:	mov    0xd8(%rsp),%r9d
 29e92f4:	mov    0x130(%rsp),%r8d
 29e92fc:	mov    0xa0(%rsp),%r10d
 29e9304:	mov    0x118(%rsp),%r11d
 29e930c:	mov    %r15,0x260(%rsp)
 29e9314:	mov    %rsi,0x268(%rsp)
 29e931c:	jmp    29e9c9b <wasm[0]::function[1015]::helper::object_read+0x8d7b>
 29e9321:	mov    0x108(%rsp),%eax
 29e9328:	test   %eax,%eax
 29e932a:	je     29fbf69 <wasm[0]::function[1015]::helper::object_read+0x1b049>
 29e9330:	mov    0x108(%rsp),%ecx
 29e9337:	xor    %eax,%eax
 29e9339:	test   $0x1,%ecx
 29e933f:	jne    29e9399 <wasm[0]::function[1015]::helper::object_read+0x8479>
 29e9345:	mov    0x2e0(%rsp),%r12
 29e934d:	mov    0x28(%r12),%rax
 29e9352:	mov    0x20(%r12),%rsi
 29e9357:	mov    %ecx,%edx
 29e9359:	lea    0x4(%rsi,%rdx,1),%rcx
 29e935e:	xor    %rsi,%rsi
 29e9361:	cmp    %rax,%rdx
 29e9364:	cmova  %rsi,%rcx
 29e9368:	mov    (%rcx),%esi
 29e936a:	mov    0x190(%rsp),%rcx
 29e9372:	mov    0x28(%rcx),%rax
 29e9376:	mov    0x158(%rax),%edx
 29e937c:	cmp    %edx,%esi
 29e937e:	sete   %al
 29e9381:	movzbl %al,%eax
 29e9384:	cmp    %edx,%esi
 29e9386:	je     29e9399 <wasm[0]::function[1015]::helper::object_read+0x8479>
 29e938c:	mov    0x190(%rsp),%rdi
 29e9394:	call   3018e75 <wasmtime_builtin_is_subtype>
 29e9399:	test   %eax,%eax
 29e939b:	je     29fbf6b <wasm[0]::function[1015]::helper::object_read+0x1b04b>
 29e93a1:	mov    0x108(%rsp),%ebx
 29e93a8:	mov    0x78(%rsp),%r8d
 29e93ad:	mov    %r8,0x1d8(%rsp)
 29e93b5:	mov    0x88(%rsp),%r13d
 29e93bd:	mov    %r13,0x1e0(%rsp)
 29e93c5:	mov    0xc8(%rsp),%edx
 29e93cc:	mov    %rdx,0x1e8(%rsp)
 29e93d4:	mov    0x120(%rsp),%edi
 29e93db:	mov    %rdi,0x1f0(%rsp)
 29e93e3:	mov    0x138(%rsp),%r14d
 29e93eb:	mov    0x110(%rsp),%edi
 29e93f2:	mov    0xd8(%rsp),%r9d
 29e93fa:	mov    0x130(%rsp),%r8d
 29e9402:	mov    0xa0(%rsp),%r10d
 29e940a:	mov    0x118(%rsp),%r11d
 29e9412:	xor    %ecx,%ecx
 29e9414:	mov    %rcx,0x1f8(%rsp)
 29e941c:	test   %ebx,%ebx
 29e941e:	je     29fbf6d <wasm[0]::function[1015]::helper::object_read+0x1b04d>
 29e9424:	test   %ebx,%ebx
 29e9426:	je     29fbf6f <wasm[0]::function[1015]::helper::object_read+0x1b04f>
 29e942c:	mov    0x2e0(%rsp),%r12
 29e9434:	mov    0x28(%r12),%rax
 29e9439:	mov    0x20(%r12),%rcx
 29e943e:	mov    %ebx,%r13d
 29e9441:	lea    (%rcx,%r13,1),%rsi
 29e9445:	xor    %r12,%r12
 29e9448:	cmp    %rax,%r13
 29e944b:	cmova  %r12,%rsi
 29e944f:	mov    0x10(%rsi),%esi
 29e9452:	test   %esi,%esi
 29e9454:	je     29fbf71 <wasm[0]::function[1015]::helper::object_read+0x1b051>
 29e945a:	test   %esi,%esi
 29e945c:	je     29fbf73 <wasm[0]::function[1015]::helper::object_read+0x1b053>
 29e9462:	mov    %esi,%r13d
 29e9465:	lea    (%rcx,%r13,1),%rsi
 29e9469:	cmp    %rax,%r13
 29e946c:	cmova  %r12,%rsi
 29e9470:	mov    0x10(%rsi),%esi
 29e9473:	test   %esi,%esi
 29e9475:	je     29fbf75 <wasm[0]::function[1015]::helper::object_read+0x1b055>
 29e947b:	test   %esi,%esi
 29e947d:	je     29fbf77 <wasm[0]::function[1015]::helper::object_read+0x1b057>
 29e9483:	mov    %esi,%r13d
 29e9486:	lea    0x10(%rcx,%r13,1),%rcx
 29e948b:	cmp    %rax,%r13
 29e948e:	cmova  %r12,%rcx
 29e9492:	mov    (%rcx),%r15d
 29e9495:	mov    %r15,0x208(%rsp)
 29e949d:	mov    0x100(%rsp),%r12d
 29e94a5:	mov    0x190(%rsp),%rcx
 29e94ad:	mov    0x28(%rcx),%rax
 29e94b1:	mov    0x234(%rax),%r15d
 29e94b8:	mov    0x1f8(%rsp),%rax
 29e94c0:	mov    %rax,0x1d0(%rsp)
 29e94c8:	mov    %esi,0xe0(%rsp)
 29e94cf:	mov    %r12d,0x118(%rsp)
 29e94d7:	mov    %ebx,0xa0(%rsp)
 29e94de:	mov    0x1d8(%rsp),%rax
 29e94e6:	mov    %eax,0x130(%rsp)
 29e94ed:	mov    0x1e0(%rsp),%r13
 29e94f5:	mov    %r13d,0xd8(%rsp)
 29e94fd:	mov    0x1e8(%rsp),%rdx
 29e9505:	mov    %edx,0x110(%rsp)
 29e950c:	mov    0x1f0(%rsp),%rax
 29e9514:	mov    %eax,0x138(%rsp)
 29e951b:	mov    %r14d,0x120(%rsp)
 29e9523:	mov    %edi,0xc8(%rsp)
 29e952a:	mov    %r9d,0x88(%rsp)
 29e9532:	mov    %r8d,0x78(%rsp)
 29e9537:	mov    %r10d,0x108(%rsp)
 29e953f:	mov    %r11d,0x100(%rsp)
 29e9547:	mov    0x2e8(%rsp),%r13
 29e954f:	mov    0x0(%r13),%rcx
 29e9553:	mov    0x228(%rsp),%rax
 29e955b:	cmp    %rax,%rcx
 29e955e:	jae    29faa5c <wasm[0]::function[1015]::helper::object_read+0x19b3c>
 29e9564:	mov    0xa0(%rsp),%ebx
 29e956b:	mov    0x130(%rsp),%r8d
 29e9573:	mov    %r8,0x1d8(%rsp)
 29e957b:	mov    0xd8(%rsp),%r13d
 29e9583:	mov    %r13,0x1e0(%rsp)
 29e958b:	mov    0x110(%rsp),%edx
 29e9592:	mov    %rdx,0x1e8(%rsp)
 29e959a:	mov    0x138(%rsp),%edi
 29e95a1:	mov    %rdi,0x1f0(%rsp)
 29e95a9:	mov    0x120(%rsp),%r14d
 29e95b1:	mov    0xc8(%rsp),%edi
 29e95b8:	mov    0x88(%rsp),%r9d
 29e95c0:	mov    0x78(%rsp),%r8d
 29e95c5:	mov    0x108(%rsp),%r10d
 29e95cd:	mov    0x100(%rsp),%r11d
 29e95d5:	mov    0x1f8(%rsp),%rcx
 29e95dd:	mov    0x208(%rsp),%rdx
 29e95e5:	cmp    %edx,%ecx
 29e95e7:	jb     29e95fa <wasm[0]::function[1015]::helper::object_read+0x86da>
 29e95ed:	mov    0x1d0(%rsp),%rax
 29e95f5:	jmp    29e983b <wasm[0]::function[1015]::helper::object_read+0x891b>
 29e95fa:	mov    0xe0(%rsp),%eax
 29e9601:	test   %eax,%eax
 29e9603:	je     29fbf79 <wasm[0]::function[1015]::helper::object_read+0x1b059>
 29e9609:	test   %eax,%eax
 29e960b:	je     29fbf7b <wasm[0]::function[1015]::helper::object_read+0x1b05b>
 29e9611:	mov    0x2e0(%rsp),%r12
 29e9619:	mov    0x28(%r12),%rdx
 29e961e:	mov    0x20(%r12),%rsi
 29e9623:	mov    %eax,%r9d
 29e9626:	lea    0x10(%rsi,%r9,1),%r8
 29e962b:	xor    %rdi,%rdi
 29e962e:	cmp    %rdx,%r9
 29e9631:	cmova  %rdi,%r8
 29e9635:	mov    (%r8),%r8d
 29e9638:	cmp    %r8d,%ecx
 29e963b:	jae    29fbf7d <wasm[0]::function[1015]::helper::object_read+0x1b05d>
 29e9641:	mov    %r8d,%r9d
 29e9644:	shl    $0x2,%r9
 29e9648:	shr    $0x20,%r9
 29e964c:	test   %r9,%r9
 29e964f:	jne    29fbf7f <wasm[0]::function[1015]::helper::object_read+0x1b05f>
 29e9655:	shl    $0x2,%r8d
 29e9659:	add    $0x14,%r8d
 29e965d:	jb     29fbf81 <wasm[0]::function[1015]::helper::object_read+0x1b061>
 29e9663:	add    %r8d,%eax
 29e9666:	jb     29fbf83 <wasm[0]::function[1015]::helper::object_read+0x1b063>
 29e966c:	mov    %eax,%r9d
 29e966f:	lea    (%rsi,%r9,1),%rax
 29e9673:	cmp    %rdx,%r9
 29e9676:	cmova  %rdi,%rax
 29e967a:	mov    %rcx,%rdx
 29e967d:	shl    $0x2,%edx
 29e9680:	mov    %rcx,0x1f8(%rsp)
 29e9688:	lea    0x14(%rdx),%ecx
 29e968b:	sub    %ecx,%r8d
 29e968e:	sub    %r8,%rax
 29e9691:	mov    (%rax),%edx
 29e9693:	test   %edx,%edx
 29e9695:	je     29fbf85 <wasm[0]::function[1015]::helper::object_read+0x1b065>
 29e969b:	mov    0x118(%rsp),%eax
 29e96a2:	cmp    %eax,%edx
 29e96a4:	je     29e977b <wasm[0]::function[1015]::helper::object_read+0x885b>
 29e96aa:	xor    %ecx,%ecx
 29e96ac:	test   %edx,%edx
 29e96ae:	je     29e96f0 <wasm[0]::function[1015]::helper::object_read+0x87d0>
 29e96b4:	xor    %ecx,%ecx
 29e96b6:	test   $0x1,%edx
 29e96bc:	jne    29e96f0 <wasm[0]::function[1015]::helper::object_read+0x87d0>
 29e96c2:	mov    0x2e0(%rsp),%r12
 29e96ca:	mov    0x28(%r12),%rcx
 29e96cf:	mov    0x20(%r12),%rsi
 29e96d4:	mov    %edx,%edi
 29e96d6:	lea    0x4(%rsi,%rdi,1),%rsi
 29e96db:	xor    %r8,%r8
 29e96de:	cmp    %rcx,%rdi
 29e96e1:	cmova  %r8,%rsi
 29e96e5:	mov    (%rsi),%ecx
 29e96e7:	cmp    %r15d,%ecx
 29e96ea:	sete   %cl
 29e96ed:	movzbl %cl,%ecx
 29e96f0:	test   %ecx,%ecx
 29e96f2:	je     29fbf87 <wasm[0]::function[1015]::helper::object_read+0x1b067>
 29e96f8:	xor    %ecx,%ecx
 29e96fa:	test   %eax,%eax
 29e96fc:	je     29e9747 <wasm[0]::function[1015]::helper::object_read+0x8827>
 29e9702:	mov    0x118(%rsp),%esi
 29e9709:	xor    %ecx,%ecx
 29e970b:	test   $0x1,%esi
 29e9711:	jne    29e9747 <wasm[0]::function[1015]::helper::object_read+0x8827>
 29e9717:	mov    0x2e0(%rsp),%r12
 29e971f:	mov    0x28(%r12),%rdi
 29e9724:	mov    0x20(%r12),%r8
 29e9729:	mov    %esi,%esi
 29e972b:	lea    0x4(%r8,%rsi,1),%rcx
 29e9730:	xor    %r8,%r8
 29e9733:	cmp    %rdi,%rsi
 29e9736:	cmova  %r8,%rcx
 29e973a:	mov    (%rcx),%esi
 29e973c:	cmp    %r15d,%esi
 29e973f:	sete   %sil
 29e9743:	movzbl %sil,%ecx
 29e9747:	test   %ecx,%ecx
 29e9749:	je     29fbf89 <wasm[0]::function[1015]::helper::object_read+0x1b069>
 29e974f:	mov    0x118(%rsp),%ecx
 29e9756:	xor    %r8d,%r8d
 29e9759:	test   %ecx,%ecx
 29e975b:	je     29fbf8b <wasm[0]::function[1015]::helper::object_read+0x1b06b>
 29e9761:	mov    0x190(%rsp),%rsi
 29e9769:	mov    0x190(%rsp),%rdi
 29e9771:	call   2ae54e0 <wasm[0]::function[1057]::helper::string_equality>
 29e9776:	jmp    29e9783 <wasm[0]::function[1015]::helper::object_read+0x8863>
 29e977b:	mov    0x278(%rsp),%rax
 29e9783:	mov    0xe0(%rsp),%esi
 29e978a:	mov    0x118(%rsp),%r12d
 29e9792:	mov    0xa0(%rsp),%ebx
 29e9799:	mov    0x130(%rsp),%r8d
 29e97a1:	mov    %r8,0x1d8(%rsp)
 29e97a9:	mov    0xd8(%rsp),%r13d
 29e97b1:	mov    %r13,0x1e0(%rsp)
 29e97b9:	mov    0x110(%rsp),%edx
 29e97c0:	mov    %rdx,0x1e8(%rsp)
 29e97c8:	mov    0x138(%rsp),%edi
 29e97cf:	mov    %rdi,0x1f0(%rsp)
 29e97d7:	mov    0x120(%rsp),%r14d
 29e97df:	mov    0xc8(%rsp),%edi
 29e97e6:	mov    0x88(%rsp),%r9d
 29e97ee:	mov    0x78(%rsp),%r8d
 29e97f3:	mov    0x108(%rsp),%r10d
 29e97fb:	mov    0x100(%rsp),%r11d
 29e9803:	test   %eax,%eax
 29e9805:	je     29e9818 <wasm[0]::function[1015]::helper::object_read+0x88f8>
 29e980b:	mov    0x1f8(%rsp),%rcx
 29e9813:	jmp    29e983b <wasm[0]::function[1015]::helper::object_read+0x891b>
 29e9818:	mov    0x1f8(%rsp),%rcx
 29e9820:	add    $0x1,%ecx
 29e9826:	mov    %rax,0x1d0(%rsp)
 29e982e:	mov    %rcx,0x1f8(%rsp)
 29e9836:	jmp    29e94c8 <wasm[0]::function[1015]::helper::object_read+0x85a8>
 29e983b:	xor    %r15,%r15
 29e983e:	xor    %esi,%esi
 29e9840:	test   %eax,%eax
 29e9842:	jne    29e985d <wasm[0]::function[1015]::helper::object_read+0x893d>
 29e9848:	mov    %r15,0x260(%rsp)
 29e9850:	mov    %rsi,0x268(%rsp)
 29e9858:	jmp    29e9c9b <wasm[0]::function[1015]::helper::object_read+0x8d7b>
 29e985d:	test   %ebx,%ebx
 29e985f:	je     29fbf8d <wasm[0]::function[1015]::helper::object_read+0x1b06d>
 29e9865:	xor    %eax,%eax
 29e9867:	test   $0x1,%ebx
 29e986d:	jne    29e98b1 <wasm[0]::function[1015]::helper::object_read+0x8991>
 29e9873:	mov    0x2e0(%rsp),%r12
 29e987b:	mov    0x28(%r12),%rax
 29e9880:	mov    0x20(%r12),%rsi
 29e9885:	mov    %ebx,%r12d
 29e9888:	lea    0x4(%rsi,%r12,1),%rsi
 29e988d:	xor    %r13,%r13
 29e9890:	cmp    %rax,%r12
 29e9893:	cmova  %r13,%rsi
 29e9897:	mov    (%rsi),%eax
 29e9899:	mov    0x190(%rsp),%rdx
 29e98a1:	mov    0x28(%rdx),%rdx
 29e98a5:	cmp    0x160(%rdx),%eax
 29e98ab:	sete   %al
 29e98ae:	movzbl %al,%eax
 29e98b1:	test   %eax,%eax
 29e98b3:	jne    29e9b0b <wasm[0]::function[1015]::helper::object_read+0x8beb>
 29e98b9:	xor    %eax,%eax
 29e98bb:	test   $0x1,%ebx
 29e98c1:	jne    29e9905 <wasm[0]::function[1015]::helper::object_read+0x89e5>
 29e98c7:	mov    0x2e0(%rsp),%r12
 29e98cf:	mov    0x28(%r12),%rax
 29e98d4:	mov    0x20(%r12),%rsi
 29e98d9:	mov    %ebx,%r12d
 29e98dc:	lea    0x4(%rsi,%r12,1),%rsi
 29e98e1:	xor    %r13,%r13
 29e98e4:	cmp    %rax,%r12
 29e98e7:	cmova  %r13,%rsi
 29e98eb:	mov    (%rsi),%eax
 29e98ed:	mov    0x190(%rsp),%rdx
 29e98f5:	mov    0x28(%rdx),%rdx
 29e98f9:	cmp    0x15c(%rdx),%eax
 29e98ff:	sete   %al
 29e9902:	movzbl %al,%eax
 29e9905:	test   %eax,%eax
 29e9907:	je     29fbf8f <wasm[0]::function[1015]::helper::object_read+0x1b06f>
 29e990d:	test   %ebx,%ebx
 29e990f:	je     29fbf91 <wasm[0]::function[1015]::helper::object_read+0x1b071>
 29e9915:	mov    0x2e0(%rsp),%r12
 29e991d:	mov    0x28(%r12),%rsi
 29e9922:	mov    0x20(%r12),%r12
 29e9927:	mov    %ebx,%eax
 29e9929:	lea    (%r12,%rax,1),%rbx
 29e992d:	xor    %r15,%r15
 29e9930:	cmp    %rsi,%rax
 29e9933:	cmova  %r15,%rbx
 29e9937:	mov    0x14(%rbx),%r14d
 29e993b:	mov    0x18(%rbx),%eax
 29e993e:	mov    0x1c(%rbx),%ebx
 29e9941:	test   %r14d,%r14d
 29e9944:	je     29fbf93 <wasm[0]::function[1015]::helper::object_read+0x1b073>
 29e994a:	test   %r14d,%r14d
 29e994d:	je     29fbf95 <wasm[0]::function[1015]::helper::object_read+0x1b075>
 29e9953:	mov    %r14d,%edx
 29e9956:	lea    0x10(%r12,%rdx,1),%r13
 29e995b:	cmp    %rsi,%rdx
 29e995e:	cmova  %r15,%r13
 29e9962:	mov    0x0(%r13),%r13d
 29e9966:	cmp    %r13d,%ecx
 29e9969:	jae    29fbf97 <wasm[0]::function[1015]::helper::object_read+0x1b077>
 29e996f:	mov    %r13d,%edx
 29e9972:	shr    $0x20,%rdx
 29e9976:	test   %rdx,%rdx
 29e9979:	jne    29fbf99 <wasm[0]::function[1015]::helper::object_read+0x1b079>
 29e997f:	add    $0x14,%r13d
 29e9983:	jb     29fbf9b <wasm[0]::function[1015]::helper::object_read+0x1b07b>
 29e9989:	add    %r13d,%r14d
 29e998c:	jb     29fbf9d <wasm[0]::function[1015]::helper::object_read+0x1b07d>
 29e9992:	mov    %r14d,%edx
 29e9995:	add    %rdx,%r12
 29e9998:	cmp    %rsi,%rdx
 29e999b:	cmova  %r15,%r12
 29e999f:	lea    0x14(%rcx),%edx
 29e99a2:	sub    %edx,%r13d
 29e99a5:	sub    %r13,%r12
 29e99a8:	movzbq (%r12),%r13
 29e99ad:	mov    %r13,0x208(%rsp)
 29e99b5:	test   %eax,%eax
 29e99b7:	je     29e9a4b <wasm[0]::function[1015]::helper::object_read+0x8b2b>
 29e99bd:	test   %eax,%eax
 29e99bf:	je     29fbf9f <wasm[0]::function[1015]::helper::object_read+0x1b07f>
 29e99c5:	test   %eax,%eax
 29e99c7:	je     29fbfa1 <wasm[0]::function[1015]::helper::object_read+0x1b081>
 29e99cd:	mov    0x2e0(%rsp),%r12
 29e99d5:	mov    0x28(%r12),%r12
 29e99da:	mov    0x2e0(%rsp),%rdx
 29e99e2:	mov    0x20(%rdx),%r14
 29e99e6:	mov    %eax,%r13d
 29e99e9:	lea    0x10(%r14,%r13,1),%rsi
 29e99ee:	xor    %r15,%r15
 29e99f1:	cmp    %r12,%r13
 29e99f4:	cmova  %r15,%rsi
 29e99f8:	mov    (%rsi),%esi
 29e99fa:	cmp    %esi,%ecx
 29e99fc:	jae    29fbfa3 <wasm[0]::function[1015]::helper::object_read+0x1b083>
 29e9a02:	mov    %esi,%r13d
 29e9a05:	shl    $0x3,%r13
 29e9a09:	shr    $0x20,%r13
 29e9a0d:	test   %r13,%r13
 29e9a10:	jne    29fbfa5 <wasm[0]::function[1015]::helper::object_read+0x1b085>
 29e9a16:	shl    $0x3,%esi
 29e9a19:	add    $0x18,%esi
 29e9a1c:	jb     29fbfa7 <wasm[0]::function[1015]::helper::object_read+0x1b087>
 29e9a22:	add    %esi,%eax
 29e9a24:	jb     29fbfa9 <wasm[0]::function[1015]::helper::object_read+0x1b089>
 29e9a2a:	mov    %eax,%edx
 29e9a2c:	lea    (%r14,%rdx,1),%rax
 29e9a30:	cmp    %r12,%rdx
 29e9a33:	cmova  %r15,%rax
 29e9a37:	mov    %rcx,%rdx
 29e9a3a:	shl    $0x3,%edx
 29e9a3d:	add    $0x18,%edx
 29e9a43:	sub    %edx,%esi
 29e9a45:	sub    %rsi,%rax
 29e9a48:	mov    (%rax),%r15
 29e9a4b:	xor    %r14d,%r14d
 29e9a4e:	test   %ebx,%ebx
 29e9a50:	jne    29e9a63 <wasm[0]::function[1015]::helper::object_read+0x8b43>
 29e9a56:	mov    0x208(%rsp),%r13
 29e9a5e:	jmp    29e9af2 <wasm[0]::function[1015]::helper::object_read+0x8bd2>
 29e9a63:	test   %ebx,%ebx
 29e9a65:	je     29fbfab <wasm[0]::function[1015]::helper::object_read+0x1b08b>
 29e9a6b:	test   %ebx,%ebx
 29e9a6d:	je     29fbfad <wasm[0]::function[1015]::helper::object_read+0x1b08d>
 29e9a73:	mov    0x2e0(%rsp),%r12
 29e9a7b:	mov    0x28(%r12),%rax
 29e9a80:	mov    0x20(%r12),%rsi
 29e9a85:	mov    %ebx,%r14d
 29e9a88:	lea    0x10(%rsi,%r14,1),%r13
 29e9a8d:	xor    %r12,%r12
 29e9a90:	cmp    %rax,%r14
 29e9a93:	cmova  %r12,%r13
 29e9a97:	mov    0x0(%r13),%r14d
 29e9a9b:	cmp    %r14d,%ecx
 29e9a9e:	jae    29fbfaf <wasm[0]::function[1015]::helper::object_read+0x1b08f>
 29e9aa4:	mov    %r14d,%r13d
 29e9aa7:	shl    $0x2,%r13
 29e9aab:	shr    $0x20,%r13
 29e9aaf:	test   %r13,%r13
 29e9ab2:	jne    29fbfb1 <wasm[0]::function[1015]::helper::object_read+0x1b091>
 29e9ab8:	shl    $0x2,%r14d
 29e9abc:	add    $0x14,%r14d
 29e9ac0:	jb     29fbfb3 <wasm[0]::function[1015]::helper::object_read+0x1b093>
 29e9ac6:	add    %r14d,%ebx
 29e9ac9:	jb     29fbfb5 <wasm[0]::function[1015]::helper::object_read+0x1b095>
 29e9acf:	mov    %ebx,%edx
 29e9ad1:	add    %rdx,%rsi
 29e9ad4:	cmp    %rax,%rdx
 29e9ad7:	cmova  %r12,%rsi
 29e9adb:	shl    $0x2,%ecx
 29e9ade:	lea    0x14(%rcx),%eax
 29e9ae1:	sub    %eax,%r14d
 29e9ae4:	sub    %r14,%rsi
 29e9ae7:	mov    (%rsi),%r14d
 29e9aea:	mov    0x208(%rsp),%r13
 29e9af2:	movzbl %r13b,%esi
 29e9af6:	mov    %r15,0x260(%rsp)
 29e9afe:	mov    %rsi,0x268(%rsp)
 29e9b06:	jmp    29e9c9b <wasm[0]::function[1015]::helper::object_read+0x8d7b>
 29e9b0b:	xor    %eax,%eax
 29e9b0d:	test   $0x1,%ebx
 29e9b13:	jne    29e9b57 <wasm[0]::function[1015]::helper::object_read+0x8c37>
 29e9b19:	mov    0x2e0(%rsp),%r12
 29e9b21:	mov    0x28(%r12),%rax
 29e9b26:	mov    0x20(%r12),%rdx
 29e9b2b:	mov    %ebx,%r12d
 29e9b2e:	lea    0x4(%rdx,%r12,1),%rsi
 29e9b33:	xor    %r13,%r13
 29e9b36:	cmp    %rax,%r12
 29e9b39:	cmova  %r13,%rsi
 29e9b3d:	mov    (%rsi),%eax
 29e9b3f:	mov    0x190(%rsp),%rdx
 29e9b47:	mov    0x28(%rdx),%rdx
 29e9b4b:	cmp    0x160(%rdx),%eax
 29e9b51:	sete   %al
 29e9b54:	movzbl %al,%eax
 29e9b57:	test   %eax,%eax
 29e9b59:	je     29fbfb7 <wasm[0]::function[1015]::helper::object_read+0x1b097>
 29e9b5f:	test   %ebx,%ebx
 29e9b61:	je     29fbfb9 <wasm[0]::function[1015]::helper::object_read+0x1b099>
 29e9b67:	mov    0x2e0(%rsp),%r12
 29e9b6f:	mov    0x28(%r12),%rsi
 29e9b74:	mov    0x20(%r12),%r12
 29e9b79:	mov    %ebx,%eax
 29e9b7b:	lea    (%r12,%rax,1),%r13
 29e9b7f:	xor    %rbx,%rbx
 29e9b82:	cmp    %rsi,%rax
 29e9b85:	cmova  %rbx,%r13
 29e9b89:	mov    0x10(%r13),%r13d
 29e9b8d:	test   %r13d,%r13d
 29e9b90:	je     29fbfbb <wasm[0]::function[1015]::helper::object_read+0x1b09b>
 29e9b96:	test   %r13d,%r13d
 29e9b99:	je     29fbfbd <wasm[0]::function[1015]::helper::object_read+0x1b09d>
 29e9b9f:	mov    %r13d,%edx
 29e9ba2:	lea    (%r12,%rdx,1),%r13
 29e9ba6:	cmp    %rsi,%rdx
 29e9ba9:	cmova  %rbx,%r13
 29e9bad:	mov    0x10(%r13),%r13d
 29e9bb1:	test   %r13d,%r13d
 29e9bb4:	je     29fbfbf <wasm[0]::function[1015]::helper::object_read+0x1b09f>
 29e9bba:	test   %r13d,%r13d
 29e9bbd:	je     29fbfc1 <wasm[0]::function[1015]::helper::object_read+0x1b0a1>
 29e9bc3:	mov    %r13d,%edx
 29e9bc6:	lea    0x10(%r12,%rdx,1),%r12
 29e9bcb:	cmp    %rsi,%rdx
 29e9bce:	cmova  %rbx,%r12
 29e9bd2:	cmp    (%r12),%ecx
 29e9bd6:	setae  %sil
 29e9bda:	cmp    $0x2,%ecx
 29e9bdd:	setae  %dl
 29e9be0:	or     %edx,%esi
 29e9be2:	test   %sil,%sil
 29e9be5:	jne    29fbfc3 <wasm[0]::function[1015]::helper::object_read+0x1b0a3>
 29e9beb:	mov    0x2e0(%rsp),%r12
 29e9bf3:	mov    0x28(%r12),%rbx
 29e9bf8:	mov    %rax,%rsi
 29e9bfb:	add    0x20(%r12),%rsi
 29e9c00:	xor    %r12,%r12
 29e9c03:	cmp    %rbx,%rax
 29e9c06:	cmova  %r12,%rsi
 29e9c0a:	mov    0x14(%rsi),%esi
 29e9c0d:	test   %ecx,%ecx
 29e9c0f:	je     29e9c51 <wasm[0]::function[1015]::helper::object_read+0x8d31>
 29e9c15:	mov    0x2e0(%rsp),%r12
 29e9c1d:	mov    0x28(%r12),%r12
 29e9c22:	mov    0x2e0(%rsp),%rdx
 29e9c2a:	mov    0x20(%rdx),%rdx
 29e9c2e:	lea    (%rdx,%rax,1),%rbx
 29e9c32:	xor    %r13,%r13
 29e9c35:	cmp    %r12,%rax
 29e9c38:	cmova  %r13,%rbx
 29e9c3c:	mov    0x20(%rbx),%r15
 29e9c40:	mov    0x2c(%rbx),%r14d
 29e9c44:	mov    %r15,0x260(%rsp)
 29e9c4c:	jmp    29e9c88 <wasm[0]::function[1015]::helper::object_read+0x8d68>
 29e9c51:	mov    0x2e0(%rsp),%r12
 29e9c59:	mov    0x28(%r12),%r12
 29e9c5e:	mov    0x2e0(%rsp),%rdx
 29e9c66:	mov    0x20(%rdx),%rdx
 29e9c6a:	lea    (%rdx,%rax,1),%rbx
 29e9c6e:	xor    %r13,%r13
 29e9c71:	cmp    %r12,%rax
 29e9c74:	cmova  %r13,%rbx
 29e9c78:	mov    0x18(%rbx),%r15
 29e9c7c:	mov    %r15,0x260(%rsp)
 29e9c84:	mov    0x28(%rbx),%r14d
 29e9c88:	shl    $0x3,%ecx
 29e9c8b:	shr    %cl,%esi
 29e9c8d:	and    $0xff,%esi
 29e9c93:	mov    %rsi,0x268(%rsp)
 29e9c9b:	mov    0x1d8(%rsp),%rax
 29e9ca3:	mov    %eax,0x88(%rsp)
 29e9caa:	mov    0x1e0(%rsp),%r13
 29e9cb2:	mov    %r13d,0xc8(%rsp)
 29e9cba:	mov    0x1e8(%rsp),%rdx
 29e9cc2:	mov    %edx,0x120(%rsp)
 29e9cc9:	mov    0x1f0(%rsp),%rax
 29e9cd1:	mov    %eax,0x138(%rsp)
 29e9cd8:	mov    %r14d,0x110(%rsp)
 29e9ce0:	mov    %edi,0xd8(%rsp)
 29e9ce7:	mov    %r9d,0x130(%rsp)
 29e9cef:	mov    %r8d,0xa0(%rsp)
 29e9cf7:	mov    %r10d,0x118(%rsp)
 29e9cff:	mov    %r11d,0xe0(%rsp)
 29e9d07:	mov    $0x286,%edx
 29e9d0c:	mov    0x190(%rsp),%rsi
 29e9d14:	mov    0x190(%rsp),%rdi
 29e9d1c:	call   2f307a0 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 29e9d21:	mov    %eax,0x78(%rsp)
 29e9d25:	xor    %r14d,%r14d
 29e9d28:	mov    %r14,0x1a0(%rsp)
 29e9d30:	test   %eax,%eax
 29e9d32:	je     29fbfc5 <wasm[0]::function[1015]::helper::object_read+0x1b0a5>
 29e9d38:	movl   $0x0,0x108(%rsp)
 29e9d43:	mov    0x88(%rsp),%edx
 29e9d4a:	mov    %rdx,0x1f8(%rsp)
 29e9d52:	mov    0xc8(%rsp),%esi
 29e9d59:	mov    %rsi,0x208(%rsp)
 29e9d61:	mov    0x120(%rsp),%edi
 29e9d68:	mov    %rdi,0x218(%rsp)
 29e9d70:	mov    0x138(%rsp),%r8d
 29e9d78:	mov    %r8,0x220(%rsp)
 29e9d80:	mov    0x110(%rsp),%r9d
 29e9d88:	mov    %r9,0x198(%rsp)
 29e9d90:	mov    0xd8(%rsp),%r9d
 29e9d98:	mov    0x130(%rsp),%r10d
 29e9da0:	mov    0xa0(%rsp),%edx
 29e9da7:	mov    0x118(%rsp),%r11d
 29e9daf:	mov    0xe0(%rsp),%ebx
 29e9db6:	xor    %r13,%r13
 29e9db9:	mov    0x2a0(%rsp),%rax
 29e9dc1:	mov    0x2a0(%rsp),%rcx
 29e9dc9:	test   %al,%cl
 29e9dcb:	jne    29e9dee <wasm[0]::function[1015]::helper::object_read+0x8ece>
 29e9dd1:	mov    0x1f8(%rsp),%rax
 29e9dd9:	mov    0x1a0(%rsp),%r15
 29e9de1:	mov    %r13,0x1c8(%rsp)
 29e9de9:	jmp    29eab87 <wasm[0]::function[1015]::helper::object_read+0x9c67>
 29e9dee:	mov    0x88(%rsp),%r8d
 29e9df6:	mov    0x2b0(%rsp),%rcx
 29e9dfe:	mov    0x2a8(%rsp),%rdx
 29e9e06:	mov    0x190(%rsp),%rsi
 29e9e0e:	mov    0x190(%rsp),%rdi
 29e9e16:	call   2a5f620 <wasm[0]::function[1039]::helper::object_header_projection>
 29e9e1b:	mov    %eax,0x100(%rsp)
 29e9e22:	test   %eax,%eax
 29e9e24:	je     29fbfc7 <wasm[0]::function[1015]::helper::object_read+0x1b0a7>
 29e9e2a:	test   %eax,%eax
 29e9e2c:	je     29fbfc9 <wasm[0]::function[1015]::helper::object_read+0x1b0a9>
 29e9e32:	mov    0x2e0(%rsp),%r12
 29e9e3a:	mov    0x28(%r12),%rcx
 29e9e3f:	mov    0x20(%r12),%rsi
 29e9e44:	mov    %eax,%edx
 29e9e46:	lea    (%rsi,%rdx,1),%rax
 29e9e4a:	xor    %rsi,%rsi
 29e9e4d:	cmp    %rcx,%rdx
 29e9e50:	cmova  %rsi,%rax
 29e9e54:	mov    0x14(%rax),%eax
 29e9e57:	mov    %eax,0xf8(%rsp)
 29e9e5e:	test   %eax,%eax
 29e9e60:	je     29fbfcb <wasm[0]::function[1015]::helper::object_read+0x1b0ab>
 29e9e66:	mov    0xf8(%rsp),%ecx
 29e9e6d:	xor    %eax,%eax
 29e9e6f:	test   $0x1,%ecx
 29e9e75:	jne    29e9ecf <wasm[0]::function[1015]::helper::object_read+0x8faf>
 29e9e7b:	mov    0x2e0(%rsp),%r12
 29e9e83:	mov    0x28(%r12),%rax
 29e9e88:	mov    0x20(%r12),%rsi
 29e9e8d:	mov    %ecx,%edx
 29e9e8f:	lea    0x4(%rsi,%rdx,1),%rcx
 29e9e94:	xor    %rsi,%rsi
 29e9e97:	cmp    %rax,%rdx
 29e9e9a:	cmova  %rsi,%rcx
 29e9e9e:	mov    (%rcx),%esi
 29e9ea0:	mov    0x190(%rsp),%rcx
 29e9ea8:	mov    0x28(%rcx),%rax
 29e9eac:	mov    0x158(%rax),%edx
 29e9eb2:	cmp    %edx,%esi
 29e9eb4:	sete   %al
 29e9eb7:	movzbl %al,%eax
 29e9eba:	cmp    %edx,%esi
 29e9ebc:	je     29e9ecf <wasm[0]::function[1015]::helper::object_read+0x8faf>
 29e9ec2:	mov    0x190(%rsp),%rdi
 29e9eca:	call   3018e75 <wasmtime_builtin_is_subtype>
 29e9ecf:	test   %eax,%eax
 29e9ed1:	jne    29ea18c <wasm[0]::function[1015]::helper::object_read+0x926c>
 29e9ed7:	mov    0x100(%rsp),%edx
 29e9ede:	xor    %ebx,%ebx
 29e9ee0:	test   %edx,%edx
 29e9ee2:	je     29fbfcd <wasm[0]::function[1015]::helper::object_read+0x1b0ad>
 29e9ee8:	mov    0x78(%rsp),%r9d
 29e9eed:	mov    $0x4,%ecx
 29e9ef2:	xor    %r8,%r8
 29e9ef5:	mov    0x190(%rsp),%rsi
 29e9efd:	mov    0x190(%rsp),%rdi
 29e9f05:	call   2a58e20 <wasm[0]::function[1032]::helper::ordinary_property_find>
 29e9f0a:	test   %eax,%eax
 29e9f0c:	je     29e9f46 <wasm[0]::function[1015]::helper::object_read+0x9026>
 29e9f12:	test   %eax,%eax
 29e9f14:	je     29fbfcf <wasm[0]::function[1015]::helper::object_read+0x1b0af>
 29e9f1a:	test   %eax,%eax
 29e9f1c:	je     29fbfd1 <wasm[0]::function[1015]::helper::object_read+0x1b0b1>
 29e9f22:	mov    0x2e0(%rsp),%r12
 29e9f2a:	mov    0x28(%r12),%rcx
 29e9f2f:	mov    %eax,%edx
 29e9f31:	mov    %rdx,%rax
 29e9f34:	add    0x20(%r12),%rax
 29e9f39:	xor    %rsi,%rsi
 29e9f3c:	cmp    %rcx,%rdx
 29e9f3f:	cmova  %rsi,%rax
 29e9f43:	mov    0x14(%rax),%ebx
 29e9f46:	mov    0x108(%rsp),%r15d
 29e9f4e:	xor    %r14d,%r14d
 29e9f51:	mov    %r14,0x1a0(%rsp)
 29e9f59:	xor    %r13,%r13
 29e9f5c:	test   %ebx,%ebx
 29e9f5e:	je     29ea10c <wasm[0]::function[1015]::helper::object_read+0x91ec>
 29e9f64:	test   %ebx,%ebx
 29e9f66:	je     29fbfd3 <wasm[0]::function[1015]::helper::object_read+0x1b0b3>
 29e9f6c:	mov    0x2e0(%rsp),%r12
 29e9f74:	mov    0x28(%r12),%rcx
 29e9f79:	mov    0x20(%r12),%rax
 29e9f7e:	mov    %ebx,%edx
 29e9f80:	add    %rdx,%rax
 29e9f83:	xor    %r13,%r13
 29e9f86:	cmp    %rcx,%rdx
 29e9f89:	cmova  %r13,%rax
 29e9f8d:	mov    0x10(%rax),%ecx
 29e9f90:	mov    0x108(%rsp),%r15d
 29e9f98:	mov    %r14,%rdx
 29e9f9b:	mov    %r14,0x1a0(%rsp)
 29e9fa3:	xor    %edx,%r14d
 29e9fa6:	mov    %r14,0x1a0(%rsp)
 29e9fae:	test   $0x1,%ecx
 29e9fb4:	jne    29ea10c <wasm[0]::function[1015]::helper::object_read+0x91ec>
 29e9fba:	mov    0x14(%rax),%edx
 29e9fbd:	test   %edx,%edx
 29e9fbf:	je     29fbfd5 <wasm[0]::function[1015]::helper::object_read+0x1b0b5>
 29e9fc5:	xor    %eax,%eax
 29e9fc7:	test   $0x1,%edx
 29e9fcd:	jne    29ea014 <wasm[0]::function[1015]::helper::object_read+0x90f4>
 29e9fd3:	mov    0x2e0(%rsp),%r12
 29e9fdb:	mov    0x28(%r12),%rsi
 29e9fe0:	mov    0x20(%r12),%rdi
 29e9fe5:	mov    %edx,%r8d
 29e9fe8:	lea    0x4(%rdi,%r8,1),%rdi
 29e9fed:	xor    %r9,%r9
 29e9ff0:	cmp    %rsi,%r8
 29e9ff3:	cmova  %r9,%rdi
 29e9ff7:	mov    (%rdi),%edi
 29e9ff9:	mov    0x190(%rsp),%rcx
 29ea001:	mov    0x28(%rcx),%r8
 29ea005:	cmp    0x120(%r8),%edi
 29ea00c:	sete   %r8b
 29ea010:	movzbl %r8b,%eax
 29ea014:	test   %eax,%eax
 29ea016:	jne    29ea07c <wasm[0]::function[1015]::helper::object_read+0x915c>
 29ea01c:	mov    0x190(%rsp),%rsi
 29ea024:	mov    0x190(%rsp),%rdi
 29ea02c:	call   2a01ba0 <wasm[0]::function[1024]::helper::property_value_resolve>
 29ea031:	test   %eax,%eax
 29ea033:	je     29fbfd7 <wasm[0]::function[1015]::helper::object_read+0x1b0b7>
 29ea039:	test   %eax,%eax
 29ea03b:	je     29fbfd9 <wasm[0]::function[1015]::helper::object_read+0x1b0b9>
 29ea041:	mov    0x2e0(%rsp),%r12
 29ea049:	mov    0x28(%r12),%rcx
 29ea04e:	mov    0x20(%r12),%rsi
 29ea053:	mov    %eax,%edx
 29ea055:	lea    (%rsi,%rdx,1),%rax
 29ea059:	xor    %rsi,%rsi
 29ea05c:	cmp    %rcx,%rdx
 29ea05f:	cmova  %rsi,%rax
 29ea063:	mov    0x18(%rax),%r14d
 29ea067:	mov    %r14,0x1a0(%rsp)
 29ea06f:	mov    0x10(%rax),%r13
 29ea073:	mov    0x1c(%rax),%r15d
 29ea077:	jmp    29ea10c <wasm[0]::function[1015]::helper::object_read+0x91ec>
 29ea07c:	xor    %eax,%eax
 29ea07e:	test   $0x1,%edx
 29ea084:	jne    29ea0c7 <wasm[0]::function[1015]::helper::object_read+0x91a7>
 29ea08a:	mov    0x2e0(%rsp),%r12
 29ea092:	mov    0x28(%r12),%rax
 29ea097:	mov    0x20(%r12),%rcx
 29ea09c:	mov    %edx,%esi
 29ea09e:	lea    0x4(%rcx,%rsi,1),%rcx
 29ea0a3:	xor    %rdi,%rdi
 29ea0a6:	cmp    %rax,%rsi
 29ea0a9:	cmova  %rdi,%rcx
 29ea0ad:	mov    (%rcx),%eax
 29ea0af:	mov    0x190(%rsp),%rcx
 29ea0b7:	mov    0x28(%rcx),%rcx
 29ea0bb:	cmp    0x120(%rcx),%eax
 29ea0c1:	sete   %al
 29ea0c4:	movzbl %al,%eax
 29ea0c7:	test   %eax,%eax
 29ea0c9:	je     29fbfdb <wasm[0]::function[1015]::helper::object_read+0x1b0bb>
 29ea0cf:	test   %edx,%edx
 29ea0d1:	je     29fbfdd <wasm[0]::function[1015]::helper::object_read+0x1b0bd>
 29ea0d7:	mov    0x2e0(%rsp),%r12
 29ea0df:	mov    0x28(%r12),%rcx
 29ea0e4:	mov    0x20(%r12),%rax
 29ea0e9:	mov    %edx,%edx
 29ea0eb:	add    %rdx,%rax
 29ea0ee:	xor    %rsi,%rsi
 29ea0f1:	cmp    %rcx,%rdx
 29ea0f4:	cmova  %rsi,%rax
 29ea0f8:	mov    0x18(%rax),%r14d
 29ea0fc:	mov    %r14,0x1a0(%rsp)
 29ea104:	mov    0x10(%rax),%r13
 29ea108:	mov    0x1c(%rax),%r15d
 29ea10c:	mov    0x88(%rsp),%edx
 29ea113:	mov    %rdx,0x1f8(%rsp)
 29ea11b:	mov    0xc8(%rsp),%esi
 29ea122:	mov    %rsi,0x208(%rsp)
 29ea12a:	mov    0x120(%rsp),%edi
 29ea131:	mov    %rdi,0x218(%rsp)
 29ea139:	mov    0x138(%rsp),%r8d
 29ea141:	mov    %r8,0x220(%rsp)
 29ea149:	mov    0x110(%rsp),%r9d
 29ea151:	mov    %r9,0x198(%rsp)
 29ea159:	mov    0xd8(%rsp),%r9d
 29ea161:	mov    0x130(%rsp),%r10d
 29ea169:	mov    0xa0(%rsp),%edx
 29ea170:	mov    0x118(%rsp),%r11d
 29ea178:	mov    0xe0(%rsp),%ebx
 29ea17f:	mov    %r13,0x1c8(%rsp)
 29ea187:	jmp    29eab7f <wasm[0]::function[1015]::helper::object_read+0x9c5f>
 29ea18c:	mov    0xf8(%rsp),%eax
 29ea193:	test   %eax,%eax
 29ea195:	je     29fbfdf <wasm[0]::function[1015]::helper::object_read+0x1b0bf>
 29ea19b:	mov    0xf8(%rsp),%ecx
 29ea1a2:	xor    %eax,%eax
 29ea1a4:	test   $0x1,%ecx
 29ea1aa:	jne    29ea204 <wasm[0]::function[1015]::helper::object_read+0x92e4>
 29ea1b0:	mov    0x2e0(%rsp),%r12
 29ea1b8:	mov    0x28(%r12),%rax
 29ea1bd:	mov    0x20(%r12),%rsi
 29ea1c2:	mov    %ecx,%edx
 29ea1c4:	lea    0x4(%rsi,%rdx,1),%rcx
 29ea1c9:	xor    %rsi,%rsi
 29ea1cc:	cmp    %rax,%rdx
 29ea1cf:	cmova  %rsi,%rcx
 29ea1d3:	mov    (%rcx),%esi
 29ea1d5:	mov    0x190(%rsp),%rcx
 29ea1dd:	mov    0x28(%rcx),%rax
 29ea1e1:	mov    0x158(%rax),%edx
 29ea1e7:	cmp    %edx,%esi
 29ea1e9:	sete   %al
 29ea1ec:	movzbl %al,%eax
 29ea1ef:	cmp    %edx,%esi
 29ea1f1:	je     29ea204 <wasm[0]::function[1015]::helper::object_read+0x92e4>
 29ea1f7:	mov    0x190(%rsp),%rdi
 29ea1ff:	call   3018e75 <wasmtime_builtin_is_subtype>
 29ea204:	test   %eax,%eax
 29ea206:	je     29fbfe1 <wasm[0]::function[1015]::helper::object_read+0x1b0c1>
 29ea20c:	mov    0xf8(%rsp),%r14d
 29ea214:	mov    0x88(%rsp),%edx
 29ea21b:	mov    %rdx,0x1f8(%rsp)
 29ea223:	mov    0xc8(%rsp),%esi
 29ea22a:	mov    %rsi,0x208(%rsp)
 29ea232:	mov    0x108(%rsp),%r15d
 29ea23a:	mov    0x120(%rsp),%edi
 29ea241:	mov    %rdi,0x218(%rsp)
 29ea249:	mov    0x138(%rsp),%r8d
 29ea251:	mov    %r8,0x220(%rsp)
 29ea259:	mov    0x110(%rsp),%r9d
 29ea261:	mov    %r9,0x198(%rsp)
 29ea269:	mov    0xd8(%rsp),%r9d
 29ea271:	mov    0x130(%rsp),%r10d
 29ea279:	mov    0xa0(%rsp),%edx
 29ea280:	mov    0x118(%rsp),%r11d
 29ea288:	mov    0xe0(%rsp),%ebx
 29ea28f:	xor    %ecx,%ecx
 29ea291:	mov    %rcx,0x2b8(%rsp)
 29ea299:	test   %r14d,%r14d
 29ea29c:	je     29fbfe3 <wasm[0]::function[1015]::helper::object_read+0x1b0c3>
 29ea2a2:	test   %r14d,%r14d
 29ea2a5:	je     29fbfe5 <wasm[0]::function[1015]::helper::object_read+0x1b0c5>
 29ea2ab:	mov    0x2e0(%rsp),%r12
 29ea2b3:	mov    0x28(%r12),%rax
 29ea2b8:	mov    0x20(%r12),%rcx
 29ea2bd:	mov    %r14d,%edi
 29ea2c0:	lea    (%rcx,%rdi,1),%rsi
 29ea2c4:	xor    %r12,%r12
 29ea2c7:	cmp    %rax,%rdi
 29ea2ca:	cmova  %r12,%rsi
 29ea2ce:	mov    0x10(%rsi),%esi
 29ea2d1:	test   %esi,%esi
 29ea2d3:	je     29fbfe7 <wasm[0]::function[1015]::helper::object_read+0x1b0c7>
 29ea2d9:	test   %esi,%esi
 29ea2db:	je     29fbfe9 <wasm[0]::function[1015]::helper::object_read+0x1b0c9>
 29ea2e1:	mov    %esi,%edi
 29ea2e3:	lea    (%rcx,%rdi,1),%rsi
 29ea2e7:	cmp    %rax,%rdi
 29ea2ea:	cmova  %r12,%rsi
 29ea2ee:	mov    0x10(%rsi),%esi
 29ea2f1:	test   %esi,%esi
 29ea2f3:	je     29fbfeb <wasm[0]::function[1015]::helper::object_read+0x1b0cb>
 29ea2f9:	test   %esi,%esi
 29ea2fb:	je     29fbfed <wasm[0]::function[1015]::helper::object_read+0x1b0cd>
 29ea301:	mov    %esi,%edi
 29ea303:	lea    0x10(%rcx,%rdi,1),%rcx
 29ea308:	cmp    %rax,%rdi
 29ea30b:	cmova  %r12,%rcx
 29ea30f:	mov    (%rcx),%ecx
 29ea311:	mov    %rcx,0x1d8(%rsp)
 29ea319:	mov    0x78(%rsp),%r12d
 29ea31e:	mov    0x190(%rsp),%rcx
 29ea326:	mov    0x28(%rcx),%rcx
 29ea32a:	mov    0x234(%rcx),%r13d
 29ea331:	mov    %r13,0x1d0(%rsp)
 29ea339:	mov    0x2b8(%rsp),%rax
 29ea341:	mov    %rax,0x1f0(%rsp)
 29ea349:	mov    %esi,0x100(%rsp)
 29ea350:	mov    %r12d,0xe0(%rsp)
 29ea358:	mov    %r14d,0x118(%rsp)
 29ea360:	mov    0x1f8(%rsp),%rax
 29ea368:	mov    %eax,0xa0(%rsp)
 29ea36f:	mov    0x208(%rsp),%rsi
 29ea377:	mov    %esi,0x130(%rsp)
 29ea37e:	mov    %r15d,0xd8(%rsp)
 29ea386:	mov    0x218(%rsp),%rdi
 29ea38e:	mov    %edi,0x110(%rsp)
 29ea395:	mov    0x220(%rsp),%r8
 29ea39d:	mov    %r8d,0x138(%rsp)
 29ea3a5:	mov    0x198(%rsp),%r8
 29ea3ad:	mov    %r8d,0x120(%rsp)
 29ea3b5:	mov    %r9d,0x108(%rsp)
 29ea3bd:	mov    %r10d,0xc8(%rsp)
 29ea3c5:	mov    %edx,0x88(%rsp)
 29ea3cc:	mov    %r11d,0xf8(%rsp)
 29ea3d4:	mov    %ebx,0x78(%rsp)
 29ea3d8:	mov    0x2e8(%rsp),%r13
 29ea3e0:	mov    0x0(%r13),%rcx
 29ea3e4:	mov    0x228(%rsp),%rax
 29ea3ec:	cmp    %rax,%rcx
 29ea3ef:	jae    29faa94 <wasm[0]::function[1015]::helper::object_read+0x19b74>
 29ea3f5:	mov    0x118(%rsp),%r14d
 29ea3fd:	mov    0xa0(%rsp),%edx
 29ea404:	mov    %rdx,0x1f8(%rsp)
 29ea40c:	mov    0x130(%rsp),%esi
 29ea413:	mov    %rsi,0x208(%rsp)
 29ea41b:	mov    0xd8(%rsp),%r15d
 29ea423:	mov    0x110(%rsp),%edi
 29ea42a:	mov    %rdi,0x218(%rsp)
 29ea432:	mov    0x138(%rsp),%r8d
 29ea43a:	mov    %r8,0x220(%rsp)
 29ea442:	mov    0x120(%rsp),%r9d
 29ea44a:	mov    %r9,0x198(%rsp)
 29ea452:	mov    0x108(%rsp),%r9d
 29ea45a:	mov    0xc8(%rsp),%r10d
 29ea462:	mov    0x88(%rsp),%edx
 29ea469:	mov    0xf8(%rsp),%r11d
 29ea471:	mov    0x78(%rsp),%ebx
 29ea475:	mov    0x2b8(%rsp),%rcx
 29ea47d:	mov    0x1d8(%rsp),%rsi
 29ea485:	cmp    %esi,%ecx
 29ea487:	jb     29ea49a <wasm[0]::function[1015]::helper::object_read+0x957a>
 29ea48d:	mov    0x1f0(%rsp),%rax
 29ea495:	jmp    29ea719 <wasm[0]::function[1015]::helper::object_read+0x97f9>
 29ea49a:	mov    0x100(%rsp),%eax
 29ea4a1:	test   %eax,%eax
 29ea4a3:	je     29fbfef <wasm[0]::function[1015]::helper::object_read+0x1b0cf>
 29ea4a9:	test   %eax,%eax
 29ea4ab:	je     29fbff1 <wasm[0]::function[1015]::helper::object_read+0x1b0d1>
 29ea4b1:	mov    0x2e0(%rsp),%r12
 29ea4b9:	mov    0x28(%r12),%rdx
 29ea4be:	mov    0x20(%r12),%rsi
 29ea4c3:	mov    %eax,%r9d
 29ea4c6:	lea    0x10(%rsi,%r9,1),%r8
 29ea4cb:	xor    %rdi,%rdi
 29ea4ce:	cmp    %rdx,%r9
 29ea4d1:	cmova  %rdi,%r8
 29ea4d5:	mov    (%r8),%r8d
 29ea4d8:	cmp    %r8d,%ecx
 29ea4db:	jae    29fbff3 <wasm[0]::function[1015]::helper::object_read+0x1b0d3>
 29ea4e1:	mov    %r8d,%r9d
 29ea4e4:	shl    $0x2,%r9
 29ea4e8:	shr    $0x20,%r9
 29ea4ec:	test   %r9,%r9
 29ea4ef:	jne    29fbff5 <wasm[0]::function[1015]::helper::object_read+0x1b0d5>
 29ea4f5:	shl    $0x2,%r8d
 29ea4f9:	add    $0x14,%r8d
 29ea4fd:	jb     29fbff7 <wasm[0]::function[1015]::helper::object_read+0x1b0d7>
 29ea503:	add    %r8d,%eax
 29ea506:	jb     29fbff9 <wasm[0]::function[1015]::helper::object_read+0x1b0d9>
 29ea50c:	mov    %eax,%r9d
 29ea50f:	lea    (%rsi,%r9,1),%rax
 29ea513:	cmp    %rdx,%r9
 29ea516:	cmova  %rdi,%rax
 29ea51a:	mov    %rcx,%rdx
 29ea51d:	shl    $0x2,%edx
 29ea520:	mov    %rcx,0x2b8(%rsp)
 29ea528:	lea    0x14(%rdx),%ecx
 29ea52b:	sub    %ecx,%r8d
 29ea52e:	sub    %r8,%rax
 29ea531:	mov    (%rax),%edx
 29ea533:	test   %edx,%edx
 29ea535:	je     29fbffb <wasm[0]::function[1015]::helper::object_read+0x1b0db>
 29ea53b:	mov    0xe0(%rsp),%eax
 29ea542:	cmp    %eax,%edx
 29ea544:	je     29ea63a <wasm[0]::function[1015]::helper::object_read+0x971a>
 29ea54a:	xor    %ecx,%ecx
 29ea54c:	test   %edx,%edx
 29ea54e:	jne    29ea561 <wasm[0]::function[1015]::helper::object_read+0x9641>
 29ea554:	mov    0x1d0(%rsp),%r13
 29ea55c:	jmp    29ea5b2 <wasm[0]::function[1015]::helper::object_read+0x9692>
 29ea561:	xor    %ecx,%ecx
 29ea563:	test   $0x1,%edx
 29ea569:	je     29ea57c <wasm[0]::function[1015]::helper::object_read+0x965c>
 29ea56f:	mov    0x1d0(%rsp),%r13
 29ea577:	jmp    29ea5b2 <wasm[0]::function[1015]::helper::object_read+0x9692>
 29ea57c:	mov    0x2e0(%rsp),%r12
 29ea584:	mov    0x28(%r12),%rcx
 29ea589:	mov    0x20(%r12),%rsi
 29ea58e:	mov    %edx,%edi
 29ea590:	lea    0x4(%rsi,%rdi,1),%rsi
 29ea595:	xor    %r8,%r8
 29ea598:	cmp    %rcx,%rdi
 29ea59b:	cmova  %r8,%rsi
 29ea59f:	mov    (%rsi),%ecx
 29ea5a1:	mov    0x1d0(%rsp),%r13
 29ea5a9:	cmp    %r13d,%ecx
 29ea5ac:	sete   %cl
 29ea5af:	movzbl %cl,%ecx
 29ea5b2:	test   %ecx,%ecx
 29ea5b4:	je     29fbffd <wasm[0]::function[1015]::helper::object_read+0x1b0dd>
 29ea5ba:	xor    %ecx,%ecx
 29ea5bc:	test   %eax,%eax
 29ea5be:	je     29ea606 <wasm[0]::function[1015]::helper::object_read+0x96e6>
 29ea5c4:	mov    0xe0(%rsp),%eax
 29ea5cb:	xor    %ecx,%ecx
 29ea5cd:	test   $0x1,%eax
 29ea5d2:	jne    29ea606 <wasm[0]::function[1015]::helper::object_read+0x96e6>
 29ea5d8:	mov    0x2e0(%rsp),%r12
 29ea5e0:	mov    0x28(%r12),%rcx
 29ea5e5:	mov    0x20(%r12),%rdi
 29ea5ea:	mov    %eax,%esi
 29ea5ec:	lea    0x4(%rdi,%rsi,1),%rax
 29ea5f1:	xor    %rdi,%rdi
 29ea5f4:	cmp    %rcx,%rsi
 29ea5f7:	cmova  %rdi,%rax
 29ea5fb:	mov    (%rax),%eax
 29ea5fd:	cmp    %r13d,%eax
 29ea600:	sete   %cl
 29ea603:	movzbl %cl,%ecx
 29ea606:	test   %ecx,%ecx
 29ea608:	je     29fbfff <wasm[0]::function[1015]::helper::object_read+0x1b0df>
 29ea60e:	mov    0xe0(%rsp),%ecx
 29ea615:	xor    %r8d,%r8d
 29ea618:	test   %ecx,%ecx
 29ea61a:	je     29fc001 <wasm[0]::function[1015]::helper::object_read+0x1b0e1>
 29ea620:	mov    0x190(%rsp),%rsi
 29ea628:	mov    0x190(%rsp),%rdi
 29ea630:	call   2ae54e0 <wasm[0]::function[1057]::helper::string_equality>
 29ea635:	jmp    29ea64a <wasm[0]::function[1015]::helper::object_read+0x972a>
 29ea63a:	mov    0x1d0(%rsp),%r13
 29ea642:	mov    0x278(%rsp),%rax
 29ea64a:	mov    0x100(%rsp),%esi
 29ea651:	mov    0xe0(%rsp),%r12d
 29ea659:	mov    0x118(%rsp),%r14d
 29ea661:	mov    0xa0(%rsp),%edx
 29ea668:	mov    %rdx,0x1f8(%rsp)
 29ea670:	mov    0x130(%rsp),%ecx
 29ea677:	mov    %rcx,0x208(%rsp)
 29ea67f:	mov    0xd8(%rsp),%r15d
 29ea687:	mov    0x110(%rsp),%edi
 29ea68e:	mov    %rdi,0x218(%rsp)
 29ea696:	mov    0x138(%rsp),%r8d
 29ea69e:	mov    %r8,0x220(%rsp)
 29ea6a6:	mov    0x120(%rsp),%r9d
 29ea6ae:	mov    %r9,0x198(%rsp)
 29ea6b6:	mov    0x108(%rsp),%r9d
 29ea6be:	mov    0xc8(%rsp),%r10d
 29ea6c6:	mov    0x88(%rsp),%edx
 29ea6cd:	mov    0xf8(%rsp),%r11d
 29ea6d5:	mov    0x78(%rsp),%ebx
 29ea6d9:	test   %eax,%eax
 29ea6db:	je     29ea6ee <wasm[0]::function[1015]::helper::object_read+0x97ce>
 29ea6e1:	mov    0x2b8(%rsp),%rcx
 29ea6e9:	jmp    29ea719 <wasm[0]::function[1015]::helper::object_read+0x97f9>
 29ea6ee:	mov    0x2b8(%rsp),%rcx
 29ea6f6:	add    $0x1,%ecx
 29ea6fc:	mov    %r13,0x1d0(%rsp)
 29ea704:	mov    %rax,0x1f0(%rsp)
 29ea70c:	mov    %rcx,0x2b8(%rsp)
 29ea714:	jmp    29ea349 <wasm[0]::function[1015]::helper::object_read+0x9429>
 29ea719:	mov    %rsi,%rdi
 29ea71c:	mov    %rsi,0x1a0(%rsp)
 29ea724:	xor    %edi,%esi
 29ea726:	mov    %rsi,0x1a0(%rsp)
 29ea72e:	xor    %r13,%r13
 29ea731:	test   %eax,%eax
 29ea733:	jne    29ea746 <wasm[0]::function[1015]::helper::object_read+0x9826>
 29ea739:	mov    %r13,0x1c8(%rsp)
 29ea741:	jmp    29eab7f <wasm[0]::function[1015]::helper::object_read+0x9c5f>
 29ea746:	test   %r14d,%r14d
 29ea749:	je     29fc003 <wasm[0]::function[1015]::helper::object_read+0x1b0e3>
 29ea74f:	xor    %eax,%eax
 29ea751:	test   $0x1,%r14d
 29ea758:	jne    29ea79c <wasm[0]::function[1015]::helper::object_read+0x987c>
 29ea75e:	mov    0x2e0(%rsp),%r12
 29ea766:	mov    0x28(%r12),%rax
 29ea76b:	mov    0x20(%r12),%rsi
 29ea770:	mov    %r14d,%edi
 29ea773:	lea    0x4(%rsi,%rdi,1),%rsi
 29ea778:	xor    %r12,%r12
 29ea77b:	cmp    %rax,%rdi
 29ea77e:	cmova  %r12,%rsi
 29ea782:	mov    (%rsi),%eax
 29ea784:	mov    0x190(%rsp),%rsi
 29ea78c:	mov    0x28(%rsi),%rsi
 29ea790:	cmp    0x160(%rsi),%eax
 29ea796:	sete   %al
 29ea799:	movzbl %al,%eax
 29ea79c:	test   %eax,%eax
 29ea79e:	jne    29ea9e8 <wasm[0]::function[1015]::helper::object_read+0x9ac8>
 29ea7a4:	xor    %eax,%eax
 29ea7a6:	test   $0x1,%r14d
 29ea7ad:	jne    29ea7f1 <wasm[0]::function[1015]::helper::object_read+0x98d1>
 29ea7b3:	mov    0x2e0(%rsp),%r12
 29ea7bb:	mov    0x28(%r12),%rax
 29ea7c0:	mov    0x20(%r12),%rsi
 29ea7c5:	mov    %r14d,%edi
 29ea7c8:	lea    0x4(%rsi,%rdi,1),%rsi
 29ea7cd:	xor    %r12,%r12
 29ea7d0:	cmp    %rax,%rdi
 29ea7d3:	cmova  %r12,%rsi
 29ea7d7:	mov    (%rsi),%eax
 29ea7d9:	mov    0x190(%rsp),%rsi
 29ea7e1:	mov    0x28(%rsi),%rsi
 29ea7e5:	cmp    0x15c(%rsi),%eax
 29ea7eb:	sete   %al
 29ea7ee:	movzbl %al,%eax
 29ea7f1:	test   %eax,%eax
 29ea7f3:	je     29fc005 <wasm[0]::function[1015]::helper::object_read+0x1b0e5>
 29ea7f9:	test   %r14d,%r14d
 29ea7fc:	je     29fc007 <wasm[0]::function[1015]::helper::object_read+0x1b0e7>
 29ea802:	mov    0x2e0(%rsp),%r12
 29ea80a:	mov    0x28(%r12),%rsi
 29ea80f:	mov    0x20(%r12),%r12
 29ea814:	mov    %r14d,%eax
 29ea817:	lea    (%r12,%rax,1),%rdi
 29ea81b:	xor    %r13,%r13
 29ea81e:	cmp    %rsi,%rax
 29ea821:	cmova  %r13,%rdi
 29ea825:	mov    0x14(%rdi),%r15d
 29ea829:	mov    0x18(%rdi),%eax
 29ea82c:	mov    0x1c(%rdi),%r14d
 29ea830:	test   %r15d,%r15d
 29ea833:	je     29fc009 <wasm[0]::function[1015]::helper::object_read+0x1b0e9>
 29ea839:	test   %r15d,%r15d
 29ea83c:	je     29fc00b <wasm[0]::function[1015]::helper::object_read+0x1b0eb>
 29ea842:	mov    %r15d,%r8d
 29ea845:	lea    0x10(%r12,%r8,1),%rdi
 29ea84a:	cmp    %rsi,%r8
 29ea84d:	cmova  %r13,%rdi
 29ea851:	mov    (%rdi),%edi
 29ea853:	cmp    %edi,%ecx
 29ea855:	jae    29fc00d <wasm[0]::function[1015]::helper::object_read+0x1b0ed>
 29ea85b:	mov    %edi,%r8d
 29ea85e:	shr    $0x20,%r8
 29ea862:	test   %r8,%r8
 29ea865:	jne    29fc00f <wasm[0]::function[1015]::helper::object_read+0x1b0ef>
 29ea86b:	add    $0x14,%edi
 29ea86e:	jb     29fc011 <wasm[0]::function[1015]::helper::object_read+0x1b0f1>
 29ea874:	add    %edi,%r15d
 29ea877:	jb     29fc013 <wasm[0]::function[1015]::helper::object_read+0x1b0f3>
 29ea87d:	mov    %r15d,%r8d
 29ea880:	add    %r8,%r12
 29ea883:	cmp    %rsi,%r8
 29ea886:	cmova  %r13,%r12
 29ea88a:	lea    0x14(%rcx),%esi
 29ea88d:	sub    %esi,%edi
 29ea88f:	sub    %rdi,%r12
 29ea892:	movzbq (%r12),%rsi
 29ea897:	mov    %rsi,%r8
 29ea89a:	test   %eax,%eax
 29ea89c:	je     29ea92f <wasm[0]::function[1015]::helper::object_read+0x9a0f>
 29ea8a2:	test   %eax,%eax
 29ea8a4:	je     29fc015 <wasm[0]::function[1015]::helper::object_read+0x1b0f5>
 29ea8aa:	test   %eax,%eax
 29ea8ac:	je     29fc017 <wasm[0]::function[1015]::helper::object_read+0x1b0f7>
 29ea8b2:	mov    0x2e0(%rsp),%r12
 29ea8ba:	mov    0x28(%r12),%rsi
 29ea8bf:	mov    0x20(%r12),%r12
 29ea8c4:	mov    %eax,%r15d
 29ea8c7:	lea    0x10(%r12,%r15,1),%rdi
 29ea8cc:	xor    %r13,%r13
 29ea8cf:	cmp    %rsi,%r15
 29ea8d2:	cmova  %r13,%rdi
 29ea8d6:	mov    (%rdi),%r15d
 29ea8d9:	cmp    %r15d,%ecx
 29ea8dc:	jae    29fc019 <wasm[0]::function[1015]::helper::object_read+0x1b0f9>
 29ea8e2:	mov    %r15d,%edi
 29ea8e5:	shl    $0x3,%rdi
 29ea8e9:	shr    $0x20,%rdi
 29ea8ed:	test   %rdi,%rdi
 29ea8f0:	jne    29fc01b <wasm[0]::function[1015]::helper::object_read+0x1b0fb>
 29ea8f6:	shl    $0x3,%r15d
 29ea8fa:	add    $0x18,%r15d
 29ea8fe:	jb     29fc01d <wasm[0]::function[1015]::helper::object_read+0x1b0fd>
 29ea904:	add    %r15d,%eax
 29ea907:	jb     29fc01f <wasm[0]::function[1015]::helper::object_read+0x1b0ff>
 29ea90d:	mov    %eax,%edi
 29ea90f:	lea    (%r12,%rdi,1),%rax
 29ea913:	cmp    %rsi,%rdi
 29ea916:	cmova  %r13,%rax
 29ea91a:	mov    %rcx,%rsi
 29ea91d:	shl    $0x3,%esi
 29ea920:	add    $0x18,%esi
 29ea926:	sub    %esi,%r15d
 29ea929:	sub    %r15,%rax
 29ea92c:	mov    (%rax),%r13
 29ea92f:	xor    %r15d,%r15d
 29ea932:	test   %r14d,%r14d
 29ea935:	jne    29ea943 <wasm[0]::function[1015]::helper::object_read+0x9a23>
 29ea93b:	mov    %r8,%rax
 29ea93e:	jmp    29ea9cf <wasm[0]::function[1015]::helper::object_read+0x9aaf>
 29ea943:	test   %r14d,%r14d
 29ea946:	je     29fc021 <wasm[0]::function[1015]::helper::object_read+0x1b101>
 29ea94c:	test   %r14d,%r14d
 29ea94f:	je     29fc023 <wasm[0]::function[1015]::helper::object_read+0x1b103>
 29ea955:	mov    0x2e0(%rsp),%r12
 29ea95d:	mov    0x28(%r12),%rax
 29ea962:	mov    0x20(%r12),%rsi
 29ea967:	mov    %r14d,%r12d
 29ea96a:	lea    0x10(%rsi,%r12,1),%rdi
 29ea96f:	xor    %r15,%r15
 29ea972:	cmp    %rax,%r12
 29ea975:	cmova  %r15,%rdi
 29ea979:	mov    (%rdi),%r12d
 29ea97c:	cmp    %r12d,%ecx
 29ea97f:	jae    29fc025 <wasm[0]::function[1015]::helper::object_read+0x1b105>
 29ea985:	mov    %r12d,%edi
 29ea988:	shl    $0x2,%rdi
 29ea98c:	shr    $0x20,%rdi
 29ea990:	test   %rdi,%rdi
 29ea993:	jne    29fc027 <wasm[0]::function[1015]::helper::object_read+0x1b107>
 29ea999:	shl    $0x2,%r12d
 29ea99d:	add    $0x14,%r12d
 29ea9a1:	jb     29fc029 <wasm[0]::function[1015]::helper::object_read+0x1b109>
 29ea9a7:	add    %r12d,%r14d
 29ea9aa:	jb     29fc02b <wasm[0]::function[1015]::helper::object_read+0x1b10b>
 29ea9b0:	mov    %r14d,%edi
 29ea9b3:	add    %rdi,%rsi
 29ea9b6:	cmp    %rax,%rdi
 29ea9b9:	cmova  %r15,%rsi
 29ea9bd:	shl    $0x2,%ecx
 29ea9c0:	lea    0x14(%rcx),%eax
 29ea9c3:	sub    %eax,%r12d
 29ea9c6:	sub    %r12,%rsi
 29ea9c9:	mov    (%rsi),%r15d
 29ea9cc:	mov    %r8,%rax
 29ea9cf:	movzbl %al,%r14d
 29ea9d3:	mov    %r14,0x1a0(%rsp)
 29ea9db:	mov    %r13,0x1c8(%rsp)
 29ea9e3:	jmp    29eab7f <wasm[0]::function[1015]::helper::object_read+0x9c5f>
 29ea9e8:	xor    %eax,%eax
 29ea9ea:	test   $0x1,%r14d
 29ea9f1:	jne    29eaa35 <wasm[0]::function[1015]::helper::object_read+0x9b15>
 29ea9f7:	mov    0x2e0(%rsp),%r12
 29ea9ff:	mov    0x28(%r12),%rax
 29eaa04:	mov    0x20(%r12),%rsi
 29eaa09:	mov    %r14d,%edi
 29eaa0c:	lea    0x4(%rsi,%rdi,1),%rsi
 29eaa11:	xor    %r12,%r12
 29eaa14:	cmp    %rax,%rdi
 29eaa17:	cmova  %r12,%rsi
 29eaa1b:	mov    (%rsi),%eax
 29eaa1d:	mov    0x190(%rsp),%rsi
 29eaa25:	mov    0x28(%rsi),%rsi
 29eaa29:	cmp    0x160(%rsi),%eax
 29eaa2f:	sete   %al
 29eaa32:	movzbl %al,%eax
 29eaa35:	test   %eax,%eax
 29eaa37:	je     29fc02d <wasm[0]::function[1015]::helper::object_read+0x1b10d>
 29eaa3d:	test   %r14d,%r14d
 29eaa40:	je     29fc02f <wasm[0]::function[1015]::helper::object_read+0x1b10f>
 29eaa46:	mov    0x2e0(%rsp),%r12
 29eaa4e:	mov    0x28(%r12),%rsi
 29eaa53:	mov    0x20(%r12),%r12
 29eaa58:	mov    %r14d,%eax
 29eaa5b:	lea    (%r12,%rax,1),%rdi
 29eaa5f:	xor    %r13,%r13
 29eaa62:	cmp    %rsi,%rax
 29eaa65:	cmova  %r13,%rdi
 29eaa69:	mov    0x10(%rdi),%edi
 29eaa6c:	test   %edi,%edi
 29eaa6e:	je     29fc031 <wasm[0]::function[1015]::helper::object_read+0x1b111>
 29eaa74:	test   %edi,%edi
 29eaa76:	je     29fc033 <wasm[0]::function[1015]::helper::object_read+0x1b113>
 29eaa7c:	mov    %edi,%r8d
 29eaa7f:	lea    (%r12,%r8,1),%rdi
 29eaa83:	cmp    %rsi,%r8
 29eaa86:	cmova  %r13,%rdi
 29eaa8a:	mov    0x10(%rdi),%edi
 29eaa8d:	test   %edi,%edi
 29eaa8f:	je     29fc035 <wasm[0]::function[1015]::helper::object_read+0x1b115>
 29eaa95:	test   %edi,%edi
 29eaa97:	je     29fc037 <wasm[0]::function[1015]::helper::object_read+0x1b117>
 29eaa9d:	mov    %edi,%r8d
 29eaaa0:	lea    0x10(%r12,%r8,1),%rdi
 29eaaa5:	cmp    %rsi,%r8
 29eaaa8:	cmova  %r13,%rdi
 29eaaac:	cmp    (%rdi),%ecx
 29eaaae:	setae  %sil
 29eaab2:	cmp    $0x2,%ecx
 29eaab5:	setae  %dil
 29eaab9:	or     %edi,%esi
 29eaabb:	test   %sil,%sil
 29eaabe:	jne    29fc039 <wasm[0]::function[1015]::helper::object_read+0x1b119>
 29eaac4:	mov    0x2e0(%rsp),%r12
 29eaacc:	mov    0x28(%r12),%rdi
 29eaad1:	mov    %rax,%rsi
 29eaad4:	add    0x20(%r12),%rsi
 29eaad9:	xor    %r12,%r12
 29eaadc:	cmp    %rdi,%rax
 29eaadf:	cmova  %r12,%rsi
 29eaae3:	mov    0x14(%rsi),%r14d
 29eaae7:	mov    %r14,0x1a0(%rsp)
 29eaaef:	test   %ecx,%ecx
 29eaaf1:	je     29eab2b <wasm[0]::function[1015]::helper::object_read+0x9c0b>
 29eaaf7:	mov    0x2e0(%rsp),%r12
 29eaaff:	mov    0x28(%r12),%rdi
 29eab04:	mov    0x20(%r12),%rsi
 29eab09:	add    %rax,%rsi
 29eab0c:	xor    %r12,%r12
 29eab0f:	cmp    %rdi,%rax
 29eab12:	cmova  %r12,%rsi
 29eab16:	mov    0x20(%rsi),%r13
 29eab1a:	mov    0x2c(%rsi),%r15d
 29eab1e:	mov    %r13,0x1c8(%rsp)
 29eab26:	jmp    29eab5a <wasm[0]::function[1015]::helper::object_read+0x9c3a>
 29eab2b:	mov    0x2e0(%rsp),%r12
 29eab33:	mov    0x28(%r12),%rdi
 29eab38:	mov    0x20(%r12),%rsi
 29eab3d:	add    %rax,%rsi
 29eab40:	xor    %r12,%r12
 29eab43:	cmp    %rdi,%rax
 29eab46:	cmova  %r12,%rsi
 29eab4a:	mov    0x18(%rsi),%r13
 29eab4e:	mov    %r13,0x1c8(%rsp)
 29eab56:	mov    0x28(%rsi),%r15d
 29eab5a:	shl    $0x3,%ecx
 29eab5d:	mov    0x1a0(%rsp),%r14
 29eab65:	shr    %cl,%r14d
 29eab68:	mov    %r14,0x1a0(%rsp)
 29eab70:	and    $0xff,%r14d
 29eab77:	mov    %r14,0x1a0(%rsp)
 29eab7f:	mov    0x1f8(%rsp),%rax
 29eab87:	mov    %eax,0xc8(%rsp)
 29eab8e:	mov    0x208(%rsp),%rsi
 29eab96:	mov    %esi,0x108(%rsp)
 29eab9d:	mov    %r15d,0x120(%rsp)
 29eaba5:	mov    0x218(%rsp),%rdi
 29eabad:	mov    %edi,0x138(%rsp)
 29eabb4:	mov    0x220(%rsp),%r8
 29eabbc:	mov    %r8d,0x110(%rsp)
 29eabc4:	mov    0x198(%rsp),%rax
 29eabcc:	mov    %eax,0xd8(%rsp)
 29eabd3:	mov    %r9d,0x130(%rsp)
 29eabdb:	mov    %r10d,0xa0(%rsp)
 29eabe3:	mov    %edx,0x118(%rsp)
 29eabea:	mov    %r11d,0xe0(%rsp)
 29eabf2:	mov    %ebx,0x100(%rsp)
 29eabf9:	mov    $0x287,%edx
 29eabfe:	mov    0x190(%rsp),%rsi
 29eac06:	mov    0x190(%rsp),%rdi
 29eac0e:	call   2f307a0 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 29eac13:	mov    %eax,0x88(%rsp)
 29eac1a:	xor    %edi,%edi
 29eac1c:	test   %eax,%eax
 29eac1e:	je     29fc03b <wasm[0]::function[1015]::helper::object_read+0x1b11b>
 29eac24:	movl   $0x0,0xf8(%rsp)
 29eac2f:	mov    0x108(%rsp),%r8d
 29eac37:	mov    0x120(%rsp),%r9d
 29eac3f:	mov    0x138(%rsp),%r10d
 29eac47:	mov    %r10,0x1d0(%rsp)
 29eac4f:	mov    0x110(%rsp),%r11d
 29eac57:	mov    %r11,0x1d8(%rsp)
 29eac5f:	mov    0xd8(%rsp),%r13d
 29eac67:	mov    %r13,0x1e0(%rsp)
 29eac6f:	mov    0x130(%rsp),%r11d
 29eac77:	mov    %r11,0x1e8(%rsp)
 29eac7f:	mov    0xa0(%rsp),%ebx
 29eac86:	mov    %rbx,0x1f0(%rsp)
 29eac8e:	mov    0x118(%rsp),%ebx
 29eac95:	mov    0xe0(%rsp),%r15d
 29eac9d:	mov    0x100(%rsp),%r14d
 29eaca5:	xor    %rsi,%rsi
 29eaca8:	mov    0x2a0(%rsp),%rax
 29eacb0:	mov    0x2a0(%rsp),%rcx
 29eacb8:	test   %al,%cl
 29eacba:	jne    29eacd0 <wasm[0]::function[1015]::helper::object_read+0x9db0>
 29eacc0:	mov    %rdi,%rdx
 29eacc3:	mov    0x1d0(%rsp),%r10
 29eaccb:	jmp    29eb9c4 <wasm[0]::function[1015]::helper::object_read+0xaaa4>
 29eacd0:	mov    0xc8(%rsp),%r8d
 29eacd8:	mov    0x2b0(%rsp),%rcx
 29eace0:	mov    0x2a8(%rsp),%rdx
 29eace8:	mov    0x190(%rsp),%rsi
 29eacf0:	mov    0x190(%rsp),%rdi
 29eacf8:	call   2a5f620 <wasm[0]::function[1039]::helper::object_header_projection>
 29eacfd:	mov    %eax,0xc8(%rsp)
 29ead04:	test   %eax,%eax
 29ead06:	je     29fc03d <wasm[0]::function[1015]::helper::object_read+0x1b11d>
 29ead0c:	test   %eax,%eax
 29ead0e:	je     29fc03f <wasm[0]::function[1015]::helper::object_read+0x1b11f>
 29ead14:	mov    0x2e0(%rsp),%r12
 29ead1c:	mov    0x28(%r12),%rcx
 29ead21:	mov    0x20(%r12),%rsi
 29ead26:	mov    %eax,%edx
 29ead28:	lea    (%rsi,%rdx,1),%rax
 29ead2c:	xor    %rsi,%rsi
 29ead2f:	cmp    %rcx,%rdx
 29ead32:	cmova  %rsi,%rax
 29ead36:	mov    0x14(%rax),%eax
 29ead39:	mov    %eax,0x78(%rsp)
 29ead3d:	test   %eax,%eax
 29ead3f:	je     29fc041 <wasm[0]::function[1015]::helper::object_read+0x1b121>
 29ead45:	mov    0x78(%rsp),%ecx
 29ead49:	xor    %eax,%eax
 29ead4b:	test   $0x1,%ecx
 29ead51:	jne    29eadab <wasm[0]::function[1015]::helper::object_read+0x9e8b>
 29ead57:	mov    0x2e0(%rsp),%r12
 29ead5f:	mov    0x28(%r12),%rax
 29ead64:	mov    0x20(%r12),%rsi
 29ead69:	mov    %ecx,%edx
 29ead6b:	lea    0x4(%rsi,%rdx,1),%rcx
 29ead70:	xor    %rsi,%rsi
 29ead73:	cmp    %rax,%rdx
 29ead76:	cmova  %rsi,%rcx
 29ead7a:	mov    (%rcx),%esi
 29ead7c:	mov    0x190(%rsp),%rcx
 29ead84:	mov    0x28(%rcx),%rax
 29ead88:	mov    0x158(%rax),%edx
 29ead8e:	cmp    %edx,%esi
 29ead90:	sete   %al
 29ead93:	movzbl %al,%eax
 29ead96:	cmp    %edx,%esi
 29ead98:	je     29eadab <wasm[0]::function[1015]::helper::object_read+0x9e8b>
 29ead9e:	mov    0x190(%rsp),%rdi
 29eada6:	call   3018e75 <wasmtime_builtin_is_subtype>
 29eadab:	test   %eax,%eax
 29eadad:	jne    29eb038 <wasm[0]::function[1015]::helper::object_read+0xa118>
 29eadb3:	mov    0xc8(%rsp),%edx
 29eadba:	xor    %r15d,%r15d
 29eadbd:	test   %edx,%edx
 29eadbf:	je     29fc043 <wasm[0]::function[1015]::helper::object_read+0x1b123>
 29eadc5:	mov    0x88(%rsp),%r9d
 29eadcd:	mov    $0x4,%ecx
 29eadd2:	xor    %r8,%r8
 29eadd5:	mov    0x190(%rsp),%rsi
 29eaddd:	mov    0x190(%rsp),%rdi
 29eade5:	call   2a58e20 <wasm[0]::function[1032]::helper::ordinary_property_find>
 29eadea:	test   %eax,%eax
 29eadec:	je     29eae27 <wasm[0]::function[1015]::helper::object_read+0x9f07>
 29eadf2:	test   %eax,%eax
 29eadf4:	je     29fc045 <wasm[0]::function[1015]::helper::object_read+0x1b125>
 29eadfa:	test   %eax,%eax
 29eadfc:	je     29fc047 <wasm[0]::function[1015]::helper::object_read+0x1b127>
 29eae02:	mov    0x2e0(%rsp),%r12
 29eae0a:	mov    0x28(%r12),%rcx
 29eae0f:	mov    %eax,%edx
 29eae11:	mov    %rdx,%rax
 29eae14:	add    0x20(%r12),%rax
 29eae19:	xor    %rsi,%rsi
 29eae1c:	cmp    %rcx,%rdx
 29eae1f:	cmova  %rsi,%rax
 29eae23:	mov    0x14(%rax),%r15d
 29eae27:	mov    0xf8(%rsp),%edx
 29eae2e:	xor    %edi,%edi
 29eae30:	xor    %rsi,%rsi
 29eae33:	test   %r15d,%r15d
 29eae36:	je     29eafbd <wasm[0]::function[1015]::helper::object_read+0xa09d>
 29eae3c:	test   %r15d,%r15d
 29eae3f:	je     29fc049 <wasm[0]::function[1015]::helper::object_read+0x1b129>
 29eae45:	mov    0x2e0(%rsp),%r12
 29eae4d:	mov    0x28(%r12),%rcx
 29eae52:	mov    0x20(%r12),%rax
 29eae57:	mov    %r15d,%edx
 29eae5a:	add    %rdx,%rax
 29eae5d:	xor    %rsi,%rsi
 29eae60:	cmp    %rcx,%rdx
 29eae63:	cmova  %rsi,%rax
 29eae67:	mov    0x10(%rax),%ecx
 29eae6a:	mov    0xf8(%rsp),%edx
 29eae71:	xor    %edi,%edi
 29eae73:	test   $0x1,%ecx
 29eae79:	jne    29eafbd <wasm[0]::function[1015]::helper::object_read+0xa09d>
 29eae7f:	mov    0x14(%rax),%edx
 29eae82:	test   %edx,%edx
 29eae84:	je     29fc04b <wasm[0]::function[1015]::helper::object_read+0x1b12b>
 29eae8a:	xor    %edi,%edi
 29eae8c:	test   $0x1,%edx
 29eae92:	jne    29eaed7 <wasm[0]::function[1015]::helper::object_read+0x9fb7>
 29eae98:	mov    0x2e0(%rsp),%r12
 29eaea0:	mov    0x28(%r12),%rsi
 29eaea5:	mov    0x20(%r12),%r8
 29eaeaa:	mov    %edx,%edi
 29eaeac:	lea    0x4(%r8,%rdi,1),%rax
 29eaeb1:	xor    %r8,%r8
 29eaeb4:	cmp    %rsi,%rdi
 29eaeb7:	cmova  %r8,%rax
 29eaebb:	mov    (%rax),%esi
 29eaebd:	mov    0x190(%rsp),%rcx
 29eaec5:	mov    0x28(%rcx),%rdi
 29eaec9:	cmp    0x120(%rdi),%esi
 29eaecf:	sete   %sil
 29eaed3:	movzbl %sil,%edi
 29eaed7:	test   %edi,%edi
 29eaed9:	jne    29eaf37 <wasm[0]::function[1015]::helper::object_read+0xa017>
 29eaedf:	mov    0x190(%rsp),%rsi
 29eaee7:	mov    0x190(%rsp),%rdi
 29eaeef:	call   2a01ba0 <wasm[0]::function[1024]::helper::property_value_resolve>
 29eaef4:	test   %eax,%eax
 29eaef6:	je     29fc04d <wasm[0]::function[1015]::helper::object_read+0x1b12d>
 29eaefc:	test   %eax,%eax
 29eaefe:	je     29fc04f <wasm[0]::function[1015]::helper::object_read+0x1b12f>
 29eaf04:	mov    0x2e0(%rsp),%r12
 29eaf0c:	mov    0x28(%r12),%r11
 29eaf11:	mov    0x20(%r12),%rcx
 29eaf16:	mov    %eax,%eax
 29eaf18:	lea    (%rcx,%rax,1),%r8
 29eaf1c:	xor    %rcx,%rcx
 29eaf1f:	cmp    %r11,%rax
 29eaf22:	cmova  %rcx,%r8
 29eaf26:	mov    0x18(%r8),%edi
 29eaf2a:	mov    0x10(%r8),%rsi
 29eaf2e:	mov    0x1c(%r8),%edx
 29eaf32:	jmp    29eafbd <wasm[0]::function[1015]::helper::object_read+0xa09d>
 29eaf37:	xor    %eax,%eax
 29eaf39:	test   $0x1,%edx
 29eaf3f:	jne    29eaf82 <wasm[0]::function[1015]::helper::object_read+0xa062>
 29eaf45:	mov    0x2e0(%rsp),%r12
 29eaf4d:	mov    0x28(%r12),%rax
 29eaf52:	mov    0x20(%r12),%rcx
 29eaf57:	mov    %edx,%esi
 29eaf59:	lea    0x4(%rcx,%rsi,1),%rcx
 29eaf5e:	xor    %rdi,%rdi
 29eaf61:	cmp    %rax,%rsi
 29eaf64:	cmova  %rdi,%rcx
 29eaf68:	mov    (%rcx),%eax
 29eaf6a:	mov    0x190(%rsp),%rcx
 29eaf72:	mov    0x28(%rcx),%rcx
 29eaf76:	cmp    0x120(%rcx),%eax
 29eaf7c:	sete   %al
 29eaf7f:	movzbl %al,%eax
 29eaf82:	test   %eax,%eax
 29eaf84:	je     29fc051 <wasm[0]::function[1015]::helper::object_read+0x1b131>
 29eaf8a:	test   %edx,%edx
 29eaf8c:	je     29fc053 <wasm[0]::function[1015]::helper::object_read+0x1b133>
 29eaf92:	mov    0x2e0(%rsp),%r12
 29eaf9a:	mov    0x28(%r12),%rcx
 29eaf9f:	mov    0x20(%r12),%rax
 29eafa4:	mov    %edx,%edx
 29eafa6:	add    %rdx,%rax
 29eafa9:	xor    %rsi,%rsi
 29eafac:	cmp    %rcx,%rdx
 29eafaf:	cmova  %rsi,%rax
 29eafb3:	mov    0x18(%rax),%edi
 29eafb6:	mov    0x10(%rax),%rsi
 29eafba:	mov    0x1c(%rax),%edx
 29eafbd:	mov    0x108(%rsp),%r8d
 29eafc5:	mov    0x120(%rsp),%r9d
 29eafcd:	mov    0x138(%rsp),%r10d
 29eafd5:	mov    %r10,0x1d0(%rsp)
 29eafdd:	mov    0x110(%rsp),%r11d
 29eafe5:	mov    %r11,0x1d8(%rsp)
 29eafed:	mov    0xd8(%rsp),%r13d
 29eaff5:	mov    %r13,0x1e0(%rsp)
 29eaffd:	mov    0x130(%rsp),%r11d
 29eb005:	mov    %r11,0x1e8(%rsp)
 29eb00d:	mov    0xa0(%rsp),%ebx
 29eb014:	mov    %rbx,0x1f0(%rsp)
 29eb01c:	mov    0x118(%rsp),%ebx
 29eb023:	mov    0xe0(%rsp),%r15d
 29eb02b:	mov    0x100(%rsp),%r14d
 29eb033:	jmp    29eb9bc <wasm[0]::function[1015]::helper::object_read+0xaa9c>
 29eb038:	mov    0x78(%rsp),%eax
 29eb03c:	test   %eax,%eax
 29eb03e:	je     29fc055 <wasm[0]::function[1015]::helper::object_read+0x1b135>
 29eb044:	mov    0x78(%rsp),%ecx
 29eb048:	xor    %eax,%eax
 29eb04a:	test   $0x1,%ecx
 29eb050:	jne    29eb0aa <wasm[0]::function[1015]::helper::object_read+0xa18a>
 29eb056:	mov    0x2e0(%rsp),%r12
 29eb05e:	mov    0x28(%r12),%rax
 29eb063:	mov    0x20(%r12),%rsi
 29eb068:	mov    %ecx,%edx
 29eb06a:	lea    0x4(%rsi,%rdx,1),%rcx
 29eb06f:	xor    %rsi,%rsi
 29eb072:	cmp    %rax,%rdx
 29eb075:	cmova  %rsi,%rcx
 29eb079:	mov    (%rcx),%esi
 29eb07b:	mov    0x190(%rsp),%rcx
 29eb083:	mov    0x28(%rcx),%rax
 29eb087:	mov    0x158(%rax),%edx
 29eb08d:	cmp    %edx,%esi
 29eb08f:	sete   %al
 29eb092:	movzbl %al,%eax
 29eb095:	cmp    %edx,%esi
 29eb097:	je     29eb0aa <wasm[0]::function[1015]::helper::object_read+0xa18a>
 29eb09d:	mov    0x190(%rsp),%rdi
 29eb0a5:	call   3018e75 <wasmtime_builtin_is_subtype>
 29eb0aa:	test   %eax,%eax
 29eb0ac:	je     29fc057 <wasm[0]::function[1015]::helper::object_read+0x1b137>
 29eb0b2:	mov    0x78(%rsp),%r10d
 29eb0b7:	mov    0x108(%rsp),%r8d
 29eb0bf:	mov    0x120(%rsp),%r9d
 29eb0c7:	mov    0xf8(%rsp),%edx
 29eb0ce:	mov    0x138(%rsp),%eax
 29eb0d5:	mov    %rax,0x1d0(%rsp)
 29eb0dd:	mov    0x110(%rsp),%r11d
 29eb0e5:	mov    %r11,0x1d8(%rsp)
 29eb0ed:	mov    0xd8(%rsp),%r13d
 29eb0f5:	mov    %r13,0x1e0(%rsp)
 29eb0fd:	mov    0x130(%rsp),%r11d
 29eb105:	mov    %r11,0x1e8(%rsp)
 29eb10d:	mov    0xa0(%rsp),%ebx
 29eb114:	mov    %rbx,0x1f0(%rsp)
 29eb11c:	mov    0x118(%rsp),%ebx
 29eb123:	mov    0xe0(%rsp),%r15d
 29eb12b:	mov    0x100(%rsp),%r14d
 29eb133:	xor    %ecx,%ecx
 29eb135:	mov    %rcx,0x208(%rsp)
 29eb13d:	test   %r10d,%r10d
 29eb140:	je     29fc059 <wasm[0]::function[1015]::helper::object_read+0x1b139>
 29eb146:	test   %r10d,%r10d
 29eb149:	je     29fc05b <wasm[0]::function[1015]::helper::object_read+0x1b13b>
 29eb14f:	mov    0x2e0(%rsp),%r12
 29eb157:	mov    0x28(%r12),%rax
 29eb15c:	mov    0x20(%r12),%rcx
 29eb161:	mov    %r10d,%r12d
 29eb164:	lea    (%rcx,%r12,1),%rsi
 29eb168:	xor    %rdi,%rdi
 29eb16b:	cmp    %rax,%r12
 29eb16e:	cmova  %rdi,%rsi
 29eb172:	mov    0x10(%rsi),%esi
 29eb175:	test   %esi,%esi
 29eb177:	je     29fc05d <wasm[0]::function[1015]::helper::object_read+0x1b13d>
 29eb17d:	test   %esi,%esi
 29eb17f:	je     29fc05f <wasm[0]::function[1015]::helper::object_read+0x1b13f>
 29eb185:	mov    %esi,%r12d
 29eb188:	lea    (%rcx,%r12,1),%rsi
 29eb18c:	cmp    %rax,%r12
 29eb18f:	cmova  %rdi,%rsi
 29eb193:	mov    0x10(%rsi),%esi
 29eb196:	test   %esi,%esi
 29eb198:	je     29fc061 <wasm[0]::function[1015]::helper::object_read+0x1b141>
 29eb19e:	test   %esi,%esi
 29eb1a0:	je     29fc063 <wasm[0]::function[1015]::helper::object_read+0x1b143>
 29eb1a6:	mov    %esi,%r12d
 29eb1a9:	lea    0x10(%rcx,%r12,1),%rcx
 29eb1ae:	cmp    %rax,%r12
 29eb1b1:	cmova  %rdi,%rcx
 29eb1b5:	mov    (%rcx),%r13d
 29eb1b8:	mov    %r13,0x220(%rsp)
 29eb1c0:	mov    0x88(%rsp),%edi
 29eb1c7:	mov    0x190(%rsp),%rcx
 29eb1cf:	mov    0x28(%rcx),%rax
 29eb1d3:	mov    0x234(%rax),%r13d
 29eb1da:	mov    %r13,0x218(%rsp)
 29eb1e2:	mov    0x208(%rsp),%rax
 29eb1ea:	mov    %rax,0x198(%rsp)
 29eb1f2:	mov    %esi,0xc8(%rsp)
 29eb1f9:	mov    %edi,0x100(%rsp)
 29eb200:	mov    %r10d,0xe0(%rsp)
 29eb208:	mov    %r8d,0x118(%rsp)
 29eb210:	mov    %r9d,0xa0(%rsp)
 29eb218:	mov    %edx,0x130(%rsp)
 29eb21f:	mov    0x1d0(%rsp),%r10
 29eb227:	mov    %r10d,0xd8(%rsp)
 29eb22f:	mov    0x1d8(%rsp),%r11
 29eb237:	mov    %r11d,0x110(%rsp)
 29eb23f:	mov    0x1e0(%rsp),%r13
 29eb247:	mov    %r13d,0x138(%rsp)
 29eb24f:	mov    0x1e8(%rsp),%r11
 29eb257:	mov    %r11d,0xf8(%rsp)
 29eb25f:	mov    0x1f0(%rsp),%rax
 29eb267:	mov    %eax,0x120(%rsp)
 29eb26e:	mov    %ebx,0x108(%rsp)
 29eb275:	mov    %r15d,0x78(%rsp)
 29eb27a:	mov    %r14d,0x88(%rsp)
 29eb282:	mov    0x2e8(%rsp),%r13
 29eb28a:	mov    0x0(%r13),%rcx
 29eb28e:	mov    0x228(%rsp),%rax
 29eb296:	cmp    %rax,%rcx
 29eb299:	jae    29faacc <wasm[0]::function[1015]::helper::object_read+0x19bac>
 29eb29f:	mov    0xe0(%rsp),%r10d
 29eb2a7:	mov    0x118(%rsp),%r8d
 29eb2af:	mov    0xa0(%rsp),%r9d
 29eb2b7:	mov    0x130(%rsp),%edx
 29eb2be:	mov    0xd8(%rsp),%ecx
 29eb2c5:	mov    %rcx,0x1d0(%rsp)
 29eb2cd:	mov    0x110(%rsp),%r11d
 29eb2d5:	mov    %r11,0x1d8(%rsp)
 29eb2dd:	mov    0x138(%rsp),%r13d
 29eb2e5:	mov    %r13,0x1e0(%rsp)
 29eb2ed:	mov    0xf8(%rsp),%r11d
 29eb2f5:	mov    %r11,0x1e8(%rsp)
 29eb2fd:	mov    0x120(%rsp),%ebx
 29eb304:	mov    %rbx,0x1f0(%rsp)
 29eb30c:	mov    0x108(%rsp),%ebx
 29eb313:	mov    0x78(%rsp),%r15d
 29eb318:	mov    0x88(%rsp),%r14d
 29eb320:	mov    0x208(%rsp),%rcx
 29eb328:	mov    0x220(%rsp),%rsi
 29eb330:	cmp    %esi,%ecx
 29eb332:	jb     29eb345 <wasm[0]::function[1015]::helper::object_read+0xa425>
 29eb338:	mov    0x198(%rsp),%rax
 29eb340:	jmp    29eb5c4 <wasm[0]::function[1015]::helper::object_read+0xa6a4>
 29eb345:	mov    0xc8(%rsp),%r8d
 29eb34d:	test   %r8d,%r8d
 29eb350:	je     29fc065 <wasm[0]::function[1015]::helper::object_read+0x1b145>
 29eb356:	test   %r8d,%r8d
 29eb359:	je     29fc067 <wasm[0]::function[1015]::helper::object_read+0x1b147>
 29eb35f:	mov    0x2e0(%rsp),%r12
 29eb367:	mov    0x28(%r12),%rax
 29eb36c:	mov    0x20(%r12),%rdx
 29eb371:	mov    %r8d,%r9d
 29eb374:	lea    0x10(%rdx,%r9,1),%rdi
 29eb379:	xor    %rsi,%rsi
 29eb37c:	cmp    %rax,%r9
 29eb37f:	cmova  %rsi,%rdi
 29eb383:	mov    (%rdi),%edi
 29eb385:	cmp    %edi,%ecx
 29eb387:	jae    29fc069 <wasm[0]::function[1015]::helper::object_read+0x1b149>
 29eb38d:	mov    %edi,%r9d
 29eb390:	shl    $0x2,%r9
 29eb394:	shr    $0x20,%r9
 29eb398:	test   %r9,%r9
 29eb39b:	jne    29fc06b <wasm[0]::function[1015]::helper::object_read+0x1b14b>
 29eb3a1:	shl    $0x2,%edi
 29eb3a4:	add    $0x14,%edi
 29eb3a7:	jb     29fc06d <wasm[0]::function[1015]::helper::object_read+0x1b14d>
 29eb3ad:	add    %edi,%r8d
 29eb3b0:	jb     29fc06f <wasm[0]::function[1015]::helper::object_read+0x1b14f>
 29eb3b6:	mov    %r8d,%r8d
 29eb3b9:	add    %r8,%rdx
 29eb3bc:	cmp    %rax,%r8
 29eb3bf:	cmova  %rsi,%rdx
 29eb3c3:	mov    %rcx,%rax
 29eb3c6:	shl    $0x2,%eax
 29eb3c9:	mov    %rcx,0x208(%rsp)
 29eb3d1:	add    $0x14,%eax
 29eb3d7:	sub    %eax,%edi
 29eb3d9:	sub    %rdi,%rdx
 29eb3dc:	mov    (%rdx),%edx
 29eb3de:	test   %edx,%edx
 29eb3e0:	je     29fc071 <wasm[0]::function[1015]::helper::object_read+0x1b151>
 29eb3e6:	mov    0x100(%rsp),%eax
 29eb3ed:	cmp    %eax,%edx
 29eb3ef:	je     29eb4e6 <wasm[0]::function[1015]::helper::object_read+0xa5c6>
 29eb3f5:	xor    %ecx,%ecx
 29eb3f7:	test   %edx,%edx
 29eb3f9:	jne    29eb40c <wasm[0]::function[1015]::helper::object_read+0xa4ec>
 29eb3ff:	mov    0x218(%rsp),%r13
 29eb407:	jmp    29eb45d <wasm[0]::function[1015]::helper::object_read+0xa53d>
 29eb40c:	xor    %ecx,%ecx
 29eb40e:	test   $0x1,%edx
 29eb414:	je     29eb427 <wasm[0]::function[1015]::helper::object_read+0xa507>
 29eb41a:	mov    0x218(%rsp),%r13
 29eb422:	jmp    29eb45d <wasm[0]::function[1015]::helper::object_read+0xa53d>
 29eb427:	mov    0x2e0(%rsp),%r12
 29eb42f:	mov    0x28(%r12),%rcx
 29eb434:	mov    0x20(%r12),%rsi
 29eb439:	mov    %edx,%edi
 29eb43b:	lea    0x4(%rsi,%rdi,1),%rsi
 29eb440:	xor    %r8,%r8
 29eb443:	cmp    %rcx,%rdi
 29eb446:	cmova  %r8,%rsi
 29eb44a:	mov    (%rsi),%ecx
 29eb44c:	mov    0x218(%rsp),%r13
 29eb454:	cmp    %r13d,%ecx
 29eb457:	sete   %cl
 29eb45a:	movzbl %cl,%ecx
 29eb45d:	test   %ecx,%ecx
 29eb45f:	je     29fc073 <wasm[0]::function[1015]::helper::object_read+0x1b153>
 29eb465:	xor    %edi,%edi
 29eb467:	test   %eax,%eax
 29eb469:	je     29eb4b2 <wasm[0]::function[1015]::helper::object_read+0xa592>
 29eb46f:	mov    0x100(%rsp),%eax
 29eb476:	xor    %edi,%edi
 29eb478:	test   $0x1,%eax
 29eb47d:	jne    29eb4b2 <wasm[0]::function[1015]::helper::object_read+0xa592>
 29eb483:	mov    0x2e0(%rsp),%r12
 29eb48b:	mov    0x28(%r12),%rcx
 29eb490:	mov    0x20(%r12),%rdi
 29eb495:	mov    %eax,%esi
 29eb497:	lea    0x4(%rdi,%rsi,1),%rax
 29eb49c:	xor    %rdi,%rdi
 29eb49f:	cmp    %rcx,%rsi
 29eb4a2:	cmova  %rdi,%rax
 29eb4a6:	mov    (%rax),%eax
 29eb4a8:	cmp    %r13d,%eax
 29eb4ab:	sete   %al
 29eb4ae:	rex movzbl %al,%edi
 29eb4b2:	test   %edi,%edi
 29eb4b4:	je     29fc075 <wasm[0]::function[1015]::helper::object_read+0x1b155>
 29eb4ba:	mov    0x100(%rsp),%ecx
 29eb4c1:	xor    %r8d,%r8d
 29eb4c4:	test   %ecx,%ecx
 29eb4c6:	je     29fc077 <wasm[0]::function[1015]::helper::object_read+0x1b157>
 29eb4cc:	mov    0x190(%rsp),%rsi
 29eb4d4:	mov    0x190(%rsp),%rdi
 29eb4dc:	call   2ae54e0 <wasm[0]::function[1057]::helper::string_equality>
 29eb4e1:	jmp    29eb4f6 <wasm[0]::function[1015]::helper::object_read+0xa5d6>
 29eb4e6:	mov    0x218(%rsp),%r13
 29eb4ee:	mov    0x278(%rsp),%rax
 29eb4f6:	mov    0xc8(%rsp),%esi
 29eb4fd:	mov    0x100(%rsp),%edi
 29eb504:	mov    0xe0(%rsp),%r10d
 29eb50c:	mov    0x118(%rsp),%r8d
 29eb514:	mov    0xa0(%rsp),%r9d
 29eb51c:	mov    0x130(%rsp),%edx
 29eb523:	mov    0xd8(%rsp),%ecx
 29eb52a:	mov    %rcx,0x1d0(%rsp)
 29eb532:	mov    0x110(%rsp),%r11d
 29eb53a:	mov    %r11,0x1d8(%rsp)
 29eb542:	mov    0x138(%rsp),%ecx
 29eb549:	mov    %rcx,0x1e0(%rsp)
 29eb551:	mov    0xf8(%rsp),%r11d
 29eb559:	mov    %r11,0x1e8(%rsp)
 29eb561:	mov    0x120(%rsp),%ebx
 29eb568:	mov    %rbx,0x1f0(%rsp)
 29eb570:	mov    0x108(%rsp),%ebx
 29eb577:	mov    0x78(%rsp),%r15d
 29eb57c:	mov    0x88(%rsp),%r14d
 29eb584:	test   %eax,%eax
 29eb586:	je     29eb599 <wasm[0]::function[1015]::helper::object_read+0xa679>
 29eb58c:	mov    0x208(%rsp),%rcx
 29eb594:	jmp    29eb5c4 <wasm[0]::function[1015]::helper::object_read+0xa6a4>
 29eb599:	mov    0x208(%rsp),%rcx
 29eb5a1:	add    $0x1,%ecx
 29eb5a7:	mov    %rax,0x198(%rsp)
 29eb5af:	mov    %rcx,0x208(%rsp)
 29eb5b7:	mov    %r13,0x218(%rsp)
 29eb5bf:	jmp    29eb1f2 <wasm[0]::function[1015]::helper::object_read+0xa2d2>
 29eb5c4:	xor    %edi,%edi
 29eb5c6:	xor    %rsi,%rsi
 29eb5c9:	test   %eax,%eax
 29eb5cb:	je     29eb9bc <wasm[0]::function[1015]::helper::object_read+0xaa9c>
 29eb5d1:	test   %r10d,%r10d
 29eb5d4:	je     29fc079 <wasm[0]::function[1015]::helper::object_read+0x1b159>
 29eb5da:	xor    %eax,%eax
 29eb5dc:	test   $0x1,%r10d
 29eb5e3:	jne    29eb627 <wasm[0]::function[1015]::helper::object_read+0xa707>
 29eb5e9:	mov    0x2e0(%rsp),%r12
 29eb5f1:	mov    0x28(%r12),%rax
 29eb5f6:	mov    0x20(%r12),%rdx
 29eb5fb:	mov    %r10d,%esi
 29eb5fe:	lea    0x4(%rdx,%rsi,1),%rdx
 29eb603:	xor    %rdi,%rdi
 29eb606:	cmp    %rax,%rsi
 29eb609:	cmova  %rdi,%rdx
 29eb60d:	mov    (%rdx),%eax
 29eb60f:	mov    0x190(%rsp),%rdx
 29eb617:	mov    0x28(%rdx),%rdx
 29eb61b:	cmp    0x160(%rdx),%eax
 29eb621:	sete   %al
 29eb624:	movzbl %al,%eax
 29eb627:	test   %eax,%eax
 29eb629:	jne    29eb856 <wasm[0]::function[1015]::helper::object_read+0xa936>
 29eb62f:	xor    %eax,%eax
 29eb631:	test   $0x1,%r10d
 29eb638:	jne    29eb67c <wasm[0]::function[1015]::helper::object_read+0xa75c>
 29eb63e:	mov    0x2e0(%rsp),%r12
 29eb646:	mov    0x28(%r12),%rax
 29eb64b:	mov    0x20(%r12),%rdx
 29eb650:	mov    %r10d,%esi
 29eb653:	lea    0x4(%rdx,%rsi,1),%rdx
 29eb658:	xor    %rdi,%rdi
 29eb65b:	cmp    %rax,%rsi
 29eb65e:	cmova  %rdi,%rdx
 29eb662:	mov    (%rdx),%eax
 29eb664:	mov    0x190(%rsp),%rdi
 29eb66c:	mov    0x28(%rdi),%rdx
 29eb670:	cmp    0x15c(%rdx),%eax
 29eb676:	sete   %al
 29eb679:	movzbl %al,%eax
 29eb67c:	test   %eax,%eax
 29eb67e:	je     29fc07b <wasm[0]::function[1015]::helper::object_read+0x1b15b>
 29eb684:	test   %r10d,%r10d
 29eb687:	je     29fc07d <wasm[0]::function[1015]::helper::object_read+0x1b15d>
 29eb68d:	mov    0x2e0(%rsp),%r12
 29eb695:	mov    0x28(%r12),%rdx
 29eb69a:	mov    0x20(%r12),%r12
 29eb69f:	mov    %r10d,%eax
 29eb6a2:	lea    (%r12,%rax,1),%rdi
 29eb6a6:	xor    %rsi,%rsi
 29eb6a9:	cmp    %rdx,%rax
 29eb6ac:	cmova  %rsi,%rdi
 29eb6b0:	mov    0x14(%rdi),%r10d
 29eb6b4:	mov    0x18(%rdi),%eax
 29eb6b7:	mov    0x1c(%rdi),%edi
 29eb6ba:	test   %r10d,%r10d
 29eb6bd:	je     29fc07f <wasm[0]::function[1015]::helper::object_read+0x1b15f>
 29eb6c3:	test   %r10d,%r10d
 29eb6c6:	je     29fc081 <wasm[0]::function[1015]::helper::object_read+0x1b161>
 29eb6cc:	mov    %r10d,%r11d
 29eb6cf:	lea    0x10(%r12,%r11,1),%r13
 29eb6d4:	cmp    %rdx,%r11
 29eb6d7:	cmova  %rsi,%r13
 29eb6db:	mov    0x0(%r13),%r13d
 29eb6df:	cmp    %r13d,%ecx
 29eb6e2:	jae    29fc083 <wasm[0]::function[1015]::helper::object_read+0x1b163>
 29eb6e8:	mov    %r13d,%r11d
 29eb6eb:	shr    $0x20,%r11
 29eb6ef:	test   %r11,%r11
 29eb6f2:	jne    29fc085 <wasm[0]::function[1015]::helper::object_read+0x1b165>
 29eb6f8:	add    $0x14,%r13d
 29eb6fc:	jb     29fc087 <wasm[0]::function[1015]::helper::object_read+0x1b167>
 29eb702:	add    %r13d,%r10d
 29eb705:	jb     29fc089 <wasm[0]::function[1015]::helper::object_read+0x1b169>
 29eb70b:	mov    %r10d,%r11d
 29eb70e:	lea    (%r12,%r11,1),%r10
 29eb712:	cmp    %rdx,%r11
 29eb715:	cmova  %rsi,%r10
 29eb719:	lea    0x14(%rcx),%edx
 29eb71c:	sub    %edx,%r13d
 29eb71f:	sub    %r13,%r10
 29eb722:	movzbq (%r10),%r11
 29eb726:	test   %eax,%eax
 29eb728:	je     29eb7bd <wasm[0]::function[1015]::helper::object_read+0xa89d>
 29eb72e:	test   %eax,%eax
 29eb730:	je     29fc08b <wasm[0]::function[1015]::helper::object_read+0x1b16b>
 29eb736:	test   %eax,%eax
 29eb738:	je     29fc08d <wasm[0]::function[1015]::helper::object_read+0x1b16d>
 29eb73e:	mov    0x2e0(%rsp),%r12
 29eb746:	mov    0x28(%r12),%rdx
 29eb74b:	mov    0x20(%r12),%rsi
 29eb750:	mov    %eax,%r10d
 29eb753:	lea    0x10(%rsi,%r10,1),%r13
 29eb758:	xor    %r12,%r12
 29eb75b:	cmp    %rdx,%r10
 29eb75e:	cmova  %r12,%r13
 29eb762:	mov    0x0(%r13),%r13d
 29eb766:	cmp    %r13d,%ecx
 29eb769:	jae    29fc08f <wasm[0]::function[1015]::helper::object_read+0x1b16f>
 29eb76f:	mov    %r13d,%r10d
 29eb772:	shl    $0x3,%r10
 29eb776:	shr    $0x20,%r10
 29eb77a:	test   %r10,%r10
 29eb77d:	jne    29fc091 <wasm[0]::function[1015]::helper::object_read+0x1b171>
 29eb783:	shl    $0x3,%r13d
 29eb787:	add    $0x18,%r13d
 29eb78b:	jb     29fc093 <wasm[0]::function[1015]::helper::object_read+0x1b173>
 29eb791:	add    %r13d,%eax
 29eb794:	jb     29fc095 <wasm[0]::function[1015]::helper::object_read+0x1b175>
 29eb79a:	mov    %eax,%r10d
 29eb79d:	lea    (%rsi,%r10,1),%rax
 29eb7a1:	cmp    %rdx,%r10
 29eb7a4:	cmova  %r12,%rax
 29eb7a8:	mov    %rcx,%rdx
 29eb7ab:	shl    $0x3,%edx
 29eb7ae:	add    $0x18,%edx
 29eb7b4:	sub    %edx,%r13d
 29eb7b7:	sub    %r13,%rax
 29eb7ba:	mov    (%rax),%rsi
 29eb7bd:	xor    %edx,%edx
 29eb7bf:	test   %edi,%edi
 29eb7c1:	je     29eb84d <wasm[0]::function[1015]::helper::object_read+0xa92d>
 29eb7c7:	test   %edi,%edi
 29eb7c9:	je     29fc097 <wasm[0]::function[1015]::helper::object_read+0x1b177>
 29eb7cf:	test   %edi,%edi
 29eb7d1:	je     29fc099 <wasm[0]::function[1015]::helper::object_read+0x1b179>
 29eb7d7:	mov    0x2e0(%rsp),%r12
 29eb7df:	mov    0x28(%r12),%rax
 29eb7e4:	mov    0x20(%r12),%rdx
 29eb7e9:	mov    %edi,%r10d
 29eb7ec:	lea    0x10(%rdx,%r10,1),%r13
 29eb7f1:	xor    %r12,%r12
 29eb7f4:	cmp    %rax,%r10
 29eb7f7:	cmova  %r12,%r13
 29eb7fb:	mov    0x0(%r13),%r13d
 29eb7ff:	cmp    %r13d,%ecx
 29eb802:	jae    29fc09b <wasm[0]::function[1015]::helper::object_read+0x1b17b>
 29eb808:	mov    %r13d,%r10d
 29eb80b:	shl    $0x2,%r10
 29eb80f:	shr    $0x20,%r10
 29eb813:	test   %r10,%r10
 29eb816:	jne    29fc09d <wasm[0]::function[1015]::helper::object_read+0x1b17d>
 29eb81c:	shl    $0x2,%r13d
 29eb820:	add    $0x14,%r13d
 29eb824:	jb     29fc09f <wasm[0]::function[1015]::helper::object_read+0x1b17f>
 29eb82a:	add    %r13d,%edi
 29eb82d:	jb     29fc0a1 <wasm[0]::function[1015]::helper::object_read+0x1b181>
 29eb833:	mov    %edi,%edi
 29eb835:	add    %rdi,%rdx
 29eb838:	cmp    %rax,%rdi
 29eb83b:	cmova  %r12,%rdx
 29eb83f:	shl    $0x2,%ecx
 29eb842:	lea    0x14(%rcx),%eax
 29eb845:	sub    %eax,%r13d
 29eb848:	sub    %r13,%rdx
 29eb84b:	mov    (%rdx),%edx
 29eb84d:	movzbl %r11b,%edi
 29eb851:	jmp    29eb9bc <wasm[0]::function[1015]::helper::object_read+0xaa9c>
 29eb856:	xor    %eax,%eax
 29eb858:	test   $0x1,%r10d
 29eb85f:	jne    29eb8a3 <wasm[0]::function[1015]::helper::object_read+0xa983>
 29eb865:	mov    0x2e0(%rsp),%r12
 29eb86d:	mov    0x28(%r12),%rax
 29eb872:	mov    0x20(%r12),%rdx
 29eb877:	mov    %r10d,%esi
 29eb87a:	lea    0x4(%rdx,%rsi,1),%rdx
 29eb87f:	xor    %rdi,%rdi
 29eb882:	cmp    %rax,%rsi
 29eb885:	cmova  %rdi,%rdx
 29eb889:	mov    (%rdx),%eax
 29eb88b:	mov    0x190(%rsp),%rdx
 29eb893:	mov    0x28(%rdx),%rdx
 29eb897:	cmp    0x160(%rdx),%eax
 29eb89d:	sete   %al
 29eb8a0:	movzbl %al,%eax
 29eb8a3:	test   %eax,%eax
 29eb8a5:	je     29fc0a3 <wasm[0]::function[1015]::helper::object_read+0x1b183>
 29eb8ab:	test   %r10d,%r10d
 29eb8ae:	je     29fc0a5 <wasm[0]::function[1015]::helper::object_read+0x1b185>
 29eb8b4:	mov    0x2e0(%rsp),%r12
 29eb8bc:	mov    0x28(%r12),%rdx
 29eb8c1:	mov    0x20(%r12),%rsi
 29eb8c6:	mov    %r10d,%eax
 29eb8c9:	lea    (%rsi,%rax,1),%r10
 29eb8cd:	xor    %rdi,%rdi
 29eb8d0:	cmp    %rdx,%rax
 29eb8d3:	cmova  %rdi,%r10
 29eb8d7:	mov    0x10(%r10),%r10d
 29eb8db:	test   %r10d,%r10d
 29eb8de:	je     29fc0a7 <wasm[0]::function[1015]::helper::object_read+0x1b187>
 29eb8e4:	test   %r10d,%r10d
 29eb8e7:	je     29fc0a9 <wasm[0]::function[1015]::helper::object_read+0x1b189>
 29eb8ed:	mov    %r10d,%r11d
 29eb8f0:	lea    (%rsi,%r11,1),%r10
 29eb8f4:	cmp    %rdx,%r11
 29eb8f7:	cmova  %rdi,%r10
 29eb8fb:	mov    0x10(%r10),%r10d
 29eb8ff:	test   %r10d,%r10d
 29eb902:	je     29fc0ab <wasm[0]::function[1015]::helper::object_read+0x1b18b>
 29eb908:	test   %r10d,%r10d
 29eb90b:	je     29fc0ad <wasm[0]::function[1015]::helper::object_read+0x1b18d>
 29eb911:	mov    %r10d,%r10d
 29eb914:	lea    0x10(%rsi,%r10,1),%rsi
 29eb919:	cmp    %rdx,%r10
 29eb91c:	cmova  %rdi,%rsi
 29eb920:	cmp    (%rsi),%ecx
 29eb922:	setae  %dl
 29eb925:	cmp    $0x2,%ecx
 29eb928:	setae  %sil
 29eb92c:	or     %esi,%edx
 29eb92e:	test   %dl,%dl
 29eb930:	jne    29fc0af <wasm[0]::function[1015]::helper::object_read+0x1b18f>
 29eb936:	mov    0x2e0(%rsp),%r12
 29eb93e:	mov    0x28(%r12),%rsi
 29eb943:	mov    %rax,%rdx
 29eb946:	add    0x20(%r12),%rdx
 29eb94b:	xor    %rdi,%rdi
 29eb94e:	cmp    %rsi,%rax
 29eb951:	cmova  %rdi,%rdx
 29eb955:	mov    0x14(%rdx),%edi
 29eb958:	test   %ecx,%ecx
 29eb95a:	je     29eb98b <wasm[0]::function[1015]::helper::object_read+0xaa6b>
 29eb960:	mov    0x2e0(%rsp),%r12
 29eb968:	mov    0x28(%r12),%rsi
 29eb96d:	mov    0x20(%r12),%rdx
 29eb972:	add    %rax,%rdx
 29eb975:	xor    %r10,%r10
 29eb978:	cmp    %rsi,%rax
 29eb97b:	cmova  %r10,%rdx
 29eb97f:	mov    0x20(%rdx),%rsi
 29eb983:	mov    0x2c(%rdx),%edx
 29eb986:	jmp    29eb9b1 <wasm[0]::function[1015]::helper::object_read+0xaa91>
 29eb98b:	mov    0x2e0(%rsp),%r12
 29eb993:	mov    0x28(%r12),%rsi
 29eb998:	mov    0x20(%r12),%rdx
 29eb99d:	add    %rax,%rdx
 29eb9a0:	xor    %r10,%r10
 29eb9a3:	cmp    %rsi,%rax
 29eb9a6:	cmova  %r10,%rdx
 29eb9aa:	mov    0x18(%rdx),%rsi
 29eb9ae:	mov    0x28(%rdx),%edx
 29eb9b1:	shl    $0x3,%ecx
 29eb9b4:	shr    %cl,%edi
 29eb9b6:	and    $0xff,%edi
 29eb9bc:	mov    0x1d0(%rsp),%r10
 29eb9c4:	mov    %r10d,0x110(%rsp)
 29eb9cc:	mov    0x1d8(%rsp),%r11
 29eb9d4:	mov    %r11d,0xd8(%rsp)
 29eb9dc:	mov    0x1e0(%rsp),%r13
 29eb9e4:	mov    %r13d,0x130(%rsp)
 29eb9ec:	mov    0x1e8(%rsp),%r11
 29eb9f4:	mov    %r11d,0xa0(%rsp)
 29eb9fc:	mov    0x1f0(%rsp),%rax
 29eba04:	mov    %eax,0x118(%rsp)
 29eba0b:	mov    %ebx,0xe0(%rsp)
 29eba12:	mov    %r15d,0x100(%rsp)
 29eba1a:	mov    %r14d,0xc8(%rsp)
 29eba22:	mov    0x230(%rsp),%rcx
 29eba2a:	cmp    $0x2,%ecx
 29eba2d:	je     29ebd61 <wasm[0]::function[1015]::helper::object_read+0xae41>
 29eba33:	cmp    $0x4,%ecx
 29eba36:	je     29ebc8f <wasm[0]::function[1015]::helper::object_read+0xad6f>
 29eba3c:	cmp    $0x3,%ecx
 29eba3f:	je     29ebc4b <wasm[0]::function[1015]::helper::object_read+0xad2b>
 29eba45:	cmp    $0xa,%ecx
 29eba48:	je     29ebb7a <wasm[0]::function[1015]::helper::object_read+0xac5a>
 29eba4e:	test   %ecx,%ecx
 29eba50:	sete   %r10b
 29eba54:	cmp    $0x1,%ecx
 29eba57:	sete   %al
 29eba5a:	or     %eax,%r10d
 29eba5d:	test   %r10b,%r10b
 29eba60:	jne    29ebb72 <wasm[0]::function[1015]::helper::object_read+0xac52>
 29eba66:	xor    %eax,%eax
 29eba68:	test   %r8d,%r8d
 29eba6b:	je     29ebabe <wasm[0]::function[1015]::helper::object_read+0xab9e>
 29eba71:	xor    %eax,%eax
 29eba73:	test   $0x1,%r8d
 29eba7a:	jne    29ebabe <wasm[0]::function[1015]::helper::object_read+0xab9e>
 29eba80:	mov    0x2e0(%rsp),%r12
 29eba88:	mov    0x28(%r12),%rax
 29eba8d:	mov    0x20(%r12),%rcx
 29eba92:	mov    %r8d,%r10d
 29eba95:	lea    0x4(%rcx,%r10,1),%rcx
 29eba9a:	xor    %r11,%r11
 29eba9d:	cmp    %rax,%r10
 29ebaa0:	cmova  %r11,%rcx
 29ebaa4:	mov    (%rcx),%eax
 29ebaa6:	mov    0x190(%rsp),%rcx
 29ebaae:	mov    0x28(%rcx),%rcx
 29ebab2:	cmp    0x1d4(%rcx),%eax
 29ebab8:	sete   %al
 29ebabb:	movzbl %al,%eax
 29ebabe:	test   %eax,%eax
 29ebac0:	jne    29ebacd <wasm[0]::function[1015]::helper::object_read+0xabad>
 29ebac6:	xor    %eax,%eax
 29ebac8:	jmp    29ebb64 <wasm[0]::function[1015]::helper::object_read+0xac44>
 29ebacd:	xor    %eax,%eax
 29ebacf:	test   %r8d,%r8d
 29ebad2:	je     29ebb25 <wasm[0]::function[1015]::helper::object_read+0xac05>
 29ebad8:	xor    %eax,%eax
 29ebada:	test   $0x1,%r8d
 29ebae1:	jne    29ebb25 <wasm[0]::function[1015]::helper::object_read+0xac05>
 29ebae7:	mov    0x2e0(%rsp),%r12
 29ebaef:	mov    0x28(%r12),%rax
 29ebaf4:	mov    0x20(%r12),%rcx
 29ebaf9:	mov    %r8d,%r10d
 29ebafc:	lea    0x4(%rcx,%r10,1),%rcx
 29ebb01:	xor    %r11,%r11
 29ebb04:	cmp    %rax,%r10
 29ebb07:	cmova  %r11,%rcx
 29ebb0b:	mov    (%rcx),%eax
 29ebb0d:	mov    0x190(%rsp),%rcx
 29ebb15:	mov    0x28(%rcx),%rcx
 29ebb19:	cmp    0x1d4(%rcx),%eax
 29ebb1f:	sete   %al
 29ebb22:	movzbl %al,%eax
 29ebb25:	test   %eax,%eax
 29ebb27:	je     29fc0b1 <wasm[0]::function[1015]::helper::object_read+0x1b191>
 29ebb2d:	test   %r8d,%r8d
 29ebb30:	je     29fc0b3 <wasm[0]::function[1015]::helper::object_read+0x1b193>
 29ebb36:	test   %r8d,%r8d
 29ebb39:	je     29fc0b5 <wasm[0]::function[1015]::helper::object_read+0x1b195>
 29ebb3f:	mov    0x2e0(%rsp),%r12
 29ebb47:	mov    0x28(%r12),%rax
 29ebb4c:	mov    %r8d,%r8d
 29ebb4f:	mov    %r8,%rcx
 29ebb52:	add    0x20(%r12),%rcx
 29ebb57:	xor    %r10,%r10
 29ebb5a:	cmp    %rax,%r8
 29ebb5d:	cmova  %r10,%rcx
 29ebb61:	mov    0x3c(%rcx),%eax
 29ebb64:	test   %eax,%eax
 29ebb66:	sete   %al
 29ebb69:	movzbl %al,%r13d
 29ebb6d:	jmp    29ebd54 <wasm[0]::function[1015]::helper::object_read+0xae34>
 29ebb72:	xor    %r13d,%r13d
 29ebb75:	jmp    29ebd54 <wasm[0]::function[1015]::helper::object_read+0xae34>
 29ebb7a:	xor    %r10d,%r10d
 29ebb7d:	test   %r8d,%r8d
 29ebb80:	je     29ebbd5 <wasm[0]::function[1015]::helper::object_read+0xacb5>
 29ebb86:	xor    %r10d,%r10d
 29ebb89:	test   $0x1,%r8d
 29ebb90:	jne    29ebbd5 <wasm[0]::function[1015]::helper::object_read+0xacb5>
 29ebb96:	mov    0x2e0(%rsp),%r12
 29ebb9e:	mov    0x28(%r12),%rax
 29ebba3:	mov    0x20(%r12),%rcx
 29ebba8:	mov    %r8d,%r10d
 29ebbab:	lea    0x4(%rcx,%r10,1),%rcx
 29ebbb0:	xor    %r11,%r11
 29ebbb3:	cmp    %rax,%r10
 29ebbb6:	cmova  %r11,%rcx
 29ebbba:	mov    (%rcx),%eax
 29ebbbc:	mov    0x190(%rsp),%rcx
 29ebbc4:	mov    0x28(%rcx),%rcx
 29ebbc8:	cmp    0x23c(%rcx),%eax
 29ebbce:	sete   %al
 29ebbd1:	movzbl %al,%r10d
 29ebbd5:	test   %r10d,%r10d
 29ebbd8:	je     29fc0b7 <wasm[0]::function[1015]::helper::object_read+0x1b197>
 29ebbde:	test   %r8d,%r8d
 29ebbe1:	je     29fc0b9 <wasm[0]::function[1015]::helper::object_read+0x1b199>
 29ebbe7:	test   %r8d,%r8d
 29ebbea:	je     29fc0bb <wasm[0]::function[1015]::helper::object_read+0x1b19b>
 29ebbf0:	mov    0x2e0(%rsp),%r12
 29ebbf8:	mov    0x28(%r12),%rax
 29ebbfd:	mov    0x20(%r12),%rcx
 29ebc02:	mov    %r8d,%r11d
 29ebc05:	lea    (%rcx,%r11,1),%r10
 29ebc09:	xor    %r8,%r8
 29ebc0c:	cmp    %rax,%r11
 29ebc0f:	cmova  %r8,%r10
 29ebc13:	mov    0x14(%r10),%r10d
 29ebc17:	test   %r10d,%r10d
 29ebc1a:	je     29fc0bd <wasm[0]::function[1015]::helper::object_read+0x1b19d>
 29ebc20:	test   %r10d,%r10d
 29ebc23:	je     29fc0bf <wasm[0]::function[1015]::helper::object_read+0x1b19f>
 29ebc29:	mov    %r10d,%r11d
 29ebc2c:	lea    0x10(%rcx,%r11,1),%r10
 29ebc31:	cmp    %rax,%r11
 29ebc34:	cmova  %r8,%r10
 29ebc38:	mov    (%r10),%r8d
 29ebc3b:	test   %r8d,%r8d
 29ebc3e:	setne  %r8b
 29ebc42:	movzbl %r8b,%r13d
 29ebc46:	jmp    29ebd54 <wasm[0]::function[1015]::helper::object_read+0xae34>
 29ebc4b:	mov    0x238(%rsp),%rcx
 29ebc53:	movq   %rcx,%xmm0
 29ebc58:	ucomisd 0x10c50(%rip),%xmm0        # 29fc8b0 <wasm[0]::function[1015]::helper::object_read+0x1b990>
 29ebc60:	setnp  %r8b
 29ebc64:	sete   %r10b
 29ebc68:	and    %r10d,%r8d
 29ebc6b:	ucomisd %xmm0,%xmm0
 29ebc6f:	setp   %r11b
 29ebc73:	setne  %al
 29ebc76:	or     %eax,%r11d
 29ebc79:	or     %r11d,%r8d
 29ebc7c:	movzbl %r8b,%r11d
 29ebc80:	test   %r11d,%r11d
 29ebc83:	sete   %al
 29ebc86:	movzbl %al,%r13d
 29ebc8a:	jmp    29ebd54 <wasm[0]::function[1015]::helper::object_read+0xae34>
 29ebc8f:	xor    %eax,%eax
 29ebc91:	test   %r8d,%r8d
 29ebc94:	je     29ebce7 <wasm[0]::function[1015]::helper::object_read+0xadc7>
 29ebc9a:	xor    %eax,%eax
 29ebc9c:	test   $0x1,%r8d
 29ebca3:	jne    29ebce7 <wasm[0]::function[1015]::helper::object_read+0xadc7>
 29ebca9:	mov    0x2e0(%rsp),%r12
 29ebcb1:	mov    0x28(%r12),%rax
 29ebcb6:	mov    0x20(%r12),%rcx
 29ebcbb:	mov    %r8d,%r10d
 29ebcbe:	lea    0x4(%rcx,%r10,1),%rcx
 29ebcc3:	xor    %r11,%r11
 29ebcc6:	cmp    %rax,%r10
 29ebcc9:	cmova  %r11,%rcx
 29ebccd:	mov    (%rcx),%eax
 29ebccf:	mov    0x190(%rsp),%rcx
 29ebcd7:	mov    0x28(%rcx),%rcx
 29ebcdb:	cmp    0x234(%rcx),%eax
 29ebce1:	sete   %al
 29ebce4:	movzbl %al,%eax
 29ebce7:	test   %eax,%eax
 29ebce9:	je     29fc0c1 <wasm[0]::function[1015]::helper::object_read+0x1b1a1>
 29ebcef:	test   %r8d,%r8d
 29ebcf2:	je     29fc0c3 <wasm[0]::function[1015]::helper::object_read+0x1b1a3>
 29ebcf8:	test   %r8d,%r8d
 29ebcfb:	je     29fc0c5 <wasm[0]::function[1015]::helper::object_read+0x1b1a5>
 29ebd01:	mov    0x2e0(%rsp),%r12
 29ebd09:	mov    0x28(%r12),%rax
 29ebd0e:	mov    0x20(%r12),%rcx
 29ebd13:	mov    %r8d,%r11d
 29ebd16:	lea    (%rcx,%r11,1),%r10
 29ebd1a:	xor    %r8,%r8
 29ebd1d:	cmp    %rax,%r11
 29ebd20:	cmova  %r8,%r10
 29ebd24:	mov    0x10(%r10),%r10d
 29ebd28:	test   %r10d,%r10d
 29ebd2b:	je     29fc0c7 <wasm[0]::function[1015]::helper::object_read+0x1b1a7>
 29ebd31:	test   %r10d,%r10d
 29ebd34:	je     29fc0c9 <wasm[0]::function[1015]::helper::object_read+0x1b1a9>
 29ebd3a:	mov    %r10d,%r10d
 29ebd3d:	lea    0x10(%rcx,%r10,1),%rcx
 29ebd42:	cmp    %rax,%r10
 29ebd45:	cmova  %r8,%rcx
 29ebd49:	mov    (%rcx),%eax
 29ebd4b:	test   %eax,%eax
 29ebd4d:	setne  %al
 29ebd50:	movzbl %al,%r13d
 29ebd54:	mov    0x1a0(%rsp),%r14
 29ebd5c:	jmp    29ebd7b <wasm[0]::function[1015]::helper::object_read+0xae5b>
 29ebd61:	mov    0x238(%rsp),%rcx
 29ebd69:	test   %rcx,%rcx
 29ebd6c:	setne  %al
 29ebd6f:	movzbl %al,%r13d
 29ebd73:	mov    0x1a0(%rsp),%r14
 29ebd7b:	mov    0x1a0(%rsp),%r14
 29ebd83:	cmp    $0x2,%r14d
 29ebd87:	je     29ec0da <wasm[0]::function[1015]::helper::object_read+0xb1ba>
 29ebd8d:	mov    0x1a0(%rsp),%r14
 29ebd95:	cmp    $0x4,%r14d
 29ebd99:	je     29ec00d <wasm[0]::function[1015]::helper::object_read+0xb0ed>
 29ebd9f:	mov    0x1a0(%rsp),%r14
 29ebda7:	cmp    $0x3,%r14d
 29ebdab:	je     29ebfcf <wasm[0]::function[1015]::helper::object_read+0xb0af>
 29ebdb1:	mov    0x1a0(%rsp),%r14
 29ebdb9:	cmp    $0xa,%r14d
 29ebdbd:	je     29ebf05 <wasm[0]::function[1015]::helper::object_read+0xafe5>
 29ebdc3:	mov    0x1a0(%rsp),%rax
 29ebdcb:	mov    0x1a0(%rsp),%r14
 29ebdd3:	test   %eax,%r14d
 29ebdd6:	sete   %al
 29ebdd9:	cmp    $0x1,%r14d
 29ebddd:	sete   %cl
 29ebde0:	or     %ecx,%eax
 29ebde2:	test   %al,%al
 29ebde4:	jne    29ebefd <wasm[0]::function[1015]::helper::object_read+0xafdd>
 29ebdea:	xor    %eax,%eax
 29ebdec:	test   %r9d,%r9d
 29ebdef:	je     29ebe42 <wasm[0]::function[1015]::helper::object_read+0xaf22>
 29ebdf5:	xor    %eax,%eax
 29ebdf7:	test   $0x1,%r9d
 29ebdfe:	jne    29ebe42 <wasm[0]::function[1015]::helper::object_read+0xaf22>
 29ebe04:	mov    0x2e0(%rsp),%r12
 29ebe0c:	mov    0x28(%r12),%rax
 29ebe11:	mov    0x20(%r12),%rcx
 29ebe16:	mov    %r9d,%r8d
 29ebe19:	lea    0x4(%rcx,%r8,1),%rcx
 29ebe1e:	xor    %r10,%r10
 29ebe21:	cmp    %rax,%r8
 29ebe24:	cmova  %r10,%rcx
 29ebe28:	mov    (%rcx),%eax
 29ebe2a:	mov    0x190(%rsp),%rcx
 29ebe32:	mov    0x28(%rcx),%rcx
 29ebe36:	cmp    0x1d4(%rcx),%eax
 29ebe3c:	sete   %al
 29ebe3f:	movzbl %al,%eax
 29ebe42:	test   %eax,%eax
 29ebe44:	jne    29ebe51 <wasm[0]::function[1015]::helper::object_read+0xaf31>
 29ebe4a:	xor    %ecx,%ecx
 29ebe4c:	jmp    29ebeef <wasm[0]::function[1015]::helper::object_read+0xafcf>
 29ebe51:	xor    %r8d,%r8d
 29ebe54:	test   %r9d,%r9d
 29ebe57:	je     29ebeaf <wasm[0]::function[1015]::helper::object_read+0xaf8f>
 29ebe5d:	xor    %r8d,%r8d
 29ebe60:	test   $0x1,%r9d
 29ebe67:	jne    29ebeaf <wasm[0]::function[1015]::helper::object_read+0xaf8f>
 29ebe6d:	mov    0x2e0(%rsp),%r12
 29ebe75:	mov    0x28(%r12),%r8
 29ebe7a:	mov    0x20(%r12),%r10
 29ebe7f:	mov    %r9d,%r11d
 29ebe82:	lea    0x4(%r10,%r11,1),%r10
 29ebe87:	xor    %rax,%rax
 29ebe8a:	cmp    %r8,%r11
 29ebe8d:	cmova  %rax,%r10
 29ebe91:	mov    (%r10),%r8d
 29ebe94:	mov    0x190(%rsp),%rcx
 29ebe9c:	mov    0x28(%rcx),%r10
 29ebea0:	cmp    0x1d4(%r10),%r8d
 29ebea7:	sete   %r10b
 29ebeab:	movzbl %r10b,%r8d
 29ebeaf:	test   %r8d,%r8d
 29ebeb2:	je     29fc0cb <wasm[0]::function[1015]::helper::object_read+0x1b1ab>
 29ebeb8:	test   %r9d,%r9d
 29ebebb:	je     29fc0cd <wasm[0]::function[1015]::helper::object_read+0x1b1ad>
 29ebec1:	test   %r9d,%r9d
 29ebec4:	je     29fc0cf <wasm[0]::function[1015]::helper::object_read+0x1b1af>
 29ebeca:	mov    0x2e0(%rsp),%r12
 29ebed2:	mov    0x28(%r12),%rax
 29ebed7:	mov    %r9d,%r8d
 29ebeda:	mov    %r8,%rcx
 29ebedd:	add    0x20(%r12),%rcx
 29ebee2:	xor    %r9,%r9
 29ebee5:	cmp    %rax,%r8
 29ebee8:	cmova  %r9,%rcx
 29ebeec:	mov    0x3c(%rcx),%ecx
 29ebeef:	test   %ecx,%ecx
 29ebef1:	sete   %al
 29ebef4:	movzbl %al,%r14d
 29ebef8:	jmp    29ec0ec <wasm[0]::function[1015]::helper::object_read+0xb1cc>
 29ebefd:	xor    %r14d,%r14d
 29ebf00:	jmp    29ec0ec <wasm[0]::function[1015]::helper::object_read+0xb1cc>
 29ebf05:	xor    %eax,%eax
 29ebf07:	test   %r9d,%r9d
 29ebf0a:	je     29ebf5d <wasm[0]::function[1015]::helper::object_read+0xb03d>
 29ebf10:	xor    %eax,%eax
 29ebf12:	test   $0x1,%r9d
 29ebf19:	jne    29ebf5d <wasm[0]::function[1015]::helper::object_read+0xb03d>
 29ebf1f:	mov    0x2e0(%rsp),%r12
 29ebf27:	mov    0x28(%r12),%rax
 29ebf2c:	mov    0x20(%r12),%rcx
 29ebf31:	mov    %r9d,%r8d
 29ebf34:	lea    0x4(%rcx,%r8,1),%rcx
 29ebf39:	xor    %r10,%r10
 29ebf3c:	cmp    %rax,%r8
 29ebf3f:	cmova  %r10,%rcx
 29ebf43:	mov    (%rcx),%eax
 29ebf45:	mov    0x190(%rsp),%rcx
 29ebf4d:	mov    0x28(%rcx),%rcx
 29ebf51:	cmp    0x23c(%rcx),%eax
 29ebf57:	sete   %al
 29ebf5a:	movzbl %al,%eax
 29ebf5d:	test   %eax,%eax
 29ebf5f:	je     29fc0d1 <wasm[0]::function[1015]::helper::object_read+0x1b1b1>
 29ebf65:	test   %r9d,%r9d
 29ebf68:	je     29fc0d3 <wasm[0]::function[1015]::helper::object_read+0x1b1b3>
 29ebf6e:	test   %r9d,%r9d
 29ebf71:	je     29fc0d5 <wasm[0]::function[1015]::helper::object_read+0x1b1b5>
 29ebf77:	mov    0x2e0(%rsp),%r12
 29ebf7f:	mov    0x28(%r12),%rax
 29ebf84:	mov    0x20(%r12),%rcx
 29ebf89:	mov    %r9d,%r10d
 29ebf8c:	lea    (%rcx,%r10,1),%r9
 29ebf90:	xor    %r8,%r8
 29ebf93:	cmp    %rax,%r10
 29ebf96:	cmova  %r8,%r9
 29ebf9a:	mov    0x14(%r9),%r9d
 29ebf9e:	test   %r9d,%r9d
 29ebfa1:	je     29fc0d7 <wasm[0]::function[1015]::helper::object_read+0x1b1b7>
 29ebfa7:	test   %r9d,%r9d
 29ebfaa:	je     29fc0d9 <wasm[0]::function[1015]::helper::object_read+0x1b1b9>
 29ebfb0:	mov    %r9d,%r9d
 29ebfb3:	lea    0x10(%rcx,%r9,1),%rcx
 29ebfb8:	cmp    %rax,%r9
 29ebfbb:	cmova  %r8,%rcx
 29ebfbf:	mov    (%rcx),%eax
 29ebfc1:	test   %eax,%eax
 29ebfc3:	setne  %al
 29ebfc6:	movzbl %al,%r14d
 29ebfca:	jmp    29ec0ec <wasm[0]::function[1015]::helper::object_read+0xb1cc>
 29ebfcf:	mov    0x1c8(%rsp),%rcx
 29ebfd7:	movq   %rcx,%xmm0
 29ebfdc:	ucomisd 0x108dc(%rip),%xmm0        # 29fc8c0 <wasm[0]::function[1015]::helper::object_read+0x1b9a0>
 29ebfe4:	setnp  %al
 29ebfe7:	sete   %cl
 29ebfea:	and    %ecx,%eax
 29ebfec:	ucomisd %xmm0,%xmm0
 29ebff0:	setp   %cl
 29ebff3:	setne  %r8b
 29ebff7:	or     %r8d,%ecx
 29ebffa:	or     %ecx,%eax
 29ebffc:	movzbl %al,%eax
 29ebfff:	test   %eax,%eax
 29ec001:	sete   %al
 29ec004:	movzbl %al,%r14d
 29ec008:	jmp    29ec0ec <wasm[0]::function[1015]::helper::object_read+0xb1cc>
 29ec00d:	xor    %eax,%eax
 29ec00f:	test   %r9d,%r9d
 29ec012:	je     29ec065 <wasm[0]::function[1015]::helper::object_read+0xb145>
 29ec018:	xor    %eax,%eax
 29ec01a:	test   $0x1,%r9d
 29ec021:	jne    29ec065 <wasm[0]::function[1015]::helper::object_read+0xb145>
 29ec027:	mov    0x2e0(%rsp),%r12
 29ec02f:	mov    0x28(%r12),%rax
 29ec034:	mov    0x20(%r12),%rcx
 29ec039:	mov    %r9d,%r8d
 29ec03c:	lea    0x4(%rcx,%r8,1),%rcx
 29ec041:	xor    %r10,%r10
 29ec044:	cmp    %rax,%r8
 29ec047:	cmova  %r10,%rcx
 29ec04b:	mov    (%rcx),%eax
 29ec04d:	mov    0x190(%rsp),%rcx
 29ec055:	mov    0x28(%rcx),%rcx
 29ec059:	cmp    0x234(%rcx),%eax
 29ec05f:	sete   %al
 29ec062:	movzbl %al,%eax
 29ec065:	test   %eax,%eax
 29ec067:	je     29fc0db <wasm[0]::function[1015]::helper::object_read+0x1b1bb>
 29ec06d:	test   %r9d,%r9d
 29ec070:	je     29fc0dd <wasm[0]::function[1015]::helper::object_read+0x1b1bd>
 29ec076:	test   %r9d,%r9d
 29ec079:	je     29fc0df <wasm[0]::function[1015]::helper::object_read+0x1b1bf>
 29ec07f:	mov    0x2e0(%rsp),%r12
 29ec087:	mov    0x28(%r12),%r8
 29ec08c:	mov    0x20(%r12),%r10
 29ec091:	mov    %r9d,%r11d
 29ec094:	lea    (%r10,%r11,1),%rax
 29ec098:	xor    %r9,%r9
 29ec09b:	cmp    %r8,%r11
 29ec09e:	cmova  %r9,%rax
 29ec0a2:	mov    0x10(%rax),%r11d
 29ec0a6:	test   %r11d,%r11d
 29ec0a9:	je     29fc0e1 <wasm[0]::function[1015]::helper::object_read+0x1b1c1>
 29ec0af:	test   %r11d,%r11d
 29ec0b2:	je     29fc0e3 <wasm[0]::function[1015]::helper::object_read+0x1b1c3>
 29ec0b8:	mov    %r11d,%r11d
 29ec0bb:	lea    0x10(%r10,%r11,1),%r10
 29ec0c0:	cmp    %r8,%r11
 29ec0c3:	cmova  %r9,%r10
 29ec0c7:	mov    (%r10),%r9d
 29ec0ca:	test   %r9d,%r9d
 29ec0cd:	setne  %r10b
 29ec0d1:	movzbl %r10b,%r14d
 29ec0d5:	jmp    29ec0ec <wasm[0]::function[1015]::helper::object_read+0xb1cc>
 29ec0da:	mov    0x1c8(%rsp),%rcx
 29ec0e2:	test   %rcx,%rcx
 29ec0e5:	setne  %al
 29ec0e8:	movzbl %al,%r14d
 29ec0ec:	cmp    $0x2,%edi
 29ec0ef:	je     29ec3ee <wasm[0]::function[1015]::helper::object_read+0xb4ce>
 29ec0f5:	cmp    $0x4,%edi
 29ec0f8:	je     29ec327 <wasm[0]::function[1015]::helper::object_read+0xb407>
 29ec0fe:	cmp    $0x3,%edi
 29ec101:	je     29ec2f4 <wasm[0]::function[1015]::helper::object_read+0xb3d4>
 29ec107:	cmp    $0xa,%edi
 29ec10a:	je     29ec232 <wasm[0]::function[1015]::helper::object_read+0xb312>
 29ec110:	test   %edi,%edi
 29ec112:	sete   %al
 29ec115:	cmp    $0x1,%edi
 29ec118:	sete   %cl
 29ec11b:	or     %ecx,%eax
 29ec11d:	test   %al,%al
 29ec11f:	jne    29ec22b <wasm[0]::function[1015]::helper::object_read+0xb30b>
 29ec125:	xor    %r11d,%r11d
 29ec128:	test   %edx,%edx
 29ec12a:	je     29ec17d <wasm[0]::function[1015]::helper::object_read+0xb25d>
 29ec130:	xor    %r11d,%r11d
 29ec133:	test   $0x1,%edx
 29ec139:	jne    29ec17d <wasm[0]::function[1015]::helper::object_read+0xb25d>
 29ec13f:	mov    0x2e0(%rsp),%r12
 29ec147:	mov    0x28(%r12),%rax
 29ec14c:	mov    0x20(%r12),%rcx
 29ec151:	mov    %edx,%esi
 29ec153:	lea    0x4(%rcx,%rsi,1),%rcx
 29ec158:	xor    %rdi,%rdi
 29ec15b:	cmp    %rax,%rsi
 29ec15e:	cmova  %rdi,%rcx
 29ec162:	mov    (%rcx),%eax
 29ec164:	mov    0x190(%rsp),%rcx
 29ec16c:	mov    0x28(%rcx),%rcx
 29ec170:	cmp    0x1d4(%rcx),%eax
 29ec176:	sete   %al
 29ec179:	movzbl %al,%r11d
 29ec17d:	test   %r11d,%r11d
 29ec180:	jne    29ec18d <wasm[0]::function[1015]::helper::object_read+0xb26d>
 29ec186:	xor    %eax,%eax
 29ec188:	jmp    29ec21e <wasm[0]::function[1015]::helper::object_read+0xb2fe>
 29ec18d:	xor    %eax,%eax
 29ec18f:	test   %edx,%edx
 29ec191:	je     29ec1e2 <wasm[0]::function[1015]::helper::object_read+0xb2c2>
 29ec197:	xor    %eax,%eax
 29ec199:	test   $0x1,%edx
 29ec19f:	jne    29ec1e2 <wasm[0]::function[1015]::helper::object_read+0xb2c2>
 29ec1a5:	mov    0x2e0(%rsp),%r12
 29ec1ad:	mov    0x28(%r12),%rax
 29ec1b2:	mov    0x20(%r12),%rcx
 29ec1b7:	mov    %edx,%esi
 29ec1b9:	lea    0x4(%rcx,%rsi,1),%rcx
 29ec1be:	xor    %rdi,%rdi
 29ec1c1:	cmp    %rax,%rsi
 29ec1c4:	cmova  %rdi,%rcx
 29ec1c8:	mov    (%rcx),%eax
 29ec1ca:	mov    0x190(%rsp),%rcx
 29ec1d2:	mov    0x28(%rcx),%rcx
 29ec1d6:	cmp    0x1d4(%rcx),%eax
 29ec1dc:	sete   %al
 29ec1df:	movzbl %al,%eax
 29ec1e2:	test   %eax,%eax
 29ec1e4:	je     29fc0e5 <wasm[0]::function[1015]::helper::object_read+0x1b1c5>
 29ec1ea:	test   %edx,%edx
 29ec1ec:	je     29fc0e7 <wasm[0]::function[1015]::helper::object_read+0x1b1c7>
 29ec1f2:	test   %edx,%edx
 29ec1f4:	je     29fc0e9 <wasm[0]::function[1015]::helper::object_read+0x1b1c9>
 29ec1fa:	mov    0x2e0(%rsp),%r12
 29ec202:	mov    0x28(%r12),%rax
 29ec207:	mov    %edx,%edx
 29ec209:	mov    %rdx,%rcx
 29ec20c:	add    0x20(%r12),%rcx
 29ec211:	xor    %rsi,%rsi
 29ec214:	cmp    %rax,%rdx
 29ec217:	cmova  %rsi,%rcx
 29ec21b:	mov    0x3c(%rcx),%eax
 29ec21e:	test   %eax,%eax
 29ec220:	sete   %al
 29ec223:	movzbl %al,%ebx
 29ec226:	jmp    29ec3e1 <wasm[0]::function[1015]::helper::object_read+0xb4c1>
 29ec22b:	xor    %ebx,%ebx
 29ec22d:	jmp    29ec3e1 <wasm[0]::function[1015]::helper::object_read+0xb4c1>
 29ec232:	xor    %eax,%eax
 29ec234:	test   %edx,%edx
 29ec236:	je     29ec289 <wasm[0]::function[1015]::helper::object_read+0xb369>
 29ec23c:	xor    %eax,%eax
 29ec23e:	test   $0x1,%edx
 29ec244:	jne    29ec289 <wasm[0]::function[1015]::helper::object_read+0xb369>
 29ec24a:	mov    0x2e0(%rsp),%r12
 29ec252:	mov    0x28(%r12),%rsi
 29ec257:	mov    0x20(%r12),%r8
 29ec25c:	mov    %edx,%edi
 29ec25e:	lea    0x4(%r8,%rdi,1),%rax
 29ec263:	xor    %r8,%r8
 29ec266:	cmp    %rsi,%rdi
 29ec269:	cmova  %r8,%rax
 29ec26d:	mov    (%rax),%esi
 29ec26f:	mov    0x190(%rsp),%rcx
 29ec277:	mov    0x28(%rcx),%rdi
 29ec27b:	cmp    0x23c(%rdi),%esi
 29ec281:	sete   %sil
 29ec285:	movzbl %sil,%eax
 29ec289:	test   %eax,%eax
 29ec28b:	je     29fc0eb <wasm[0]::function[1015]::helper::object_read+0x1b1cb>
 29ec291:	test   %edx,%edx
 29ec293:	je     29fc0ed <wasm[0]::function[1015]::helper::object_read+0x1b1cd>
 29ec299:	test   %edx,%edx
 29ec29b:	je     29fc0ef <wasm[0]::function[1015]::helper::object_read+0x1b1cf>
 29ec2a1:	mov    0x2e0(%rsp),%r12
 29ec2a9:	mov    0x28(%r12),%r11
 29ec2ae:	mov    0x20(%r12),%rax
 29ec2b3:	mov    %edx,%edx
 29ec2b5:	lea    (%rax,%rdx,1),%r8
 29ec2b9:	xor    %rcx,%rcx
 29ec2bc:	cmp    %r11,%rdx
 29ec2bf:	cmova  %rcx,%r8
 29ec2c3:	mov    0x14(%r8),%edx
 29ec2c7:	test   %edx,%edx
 29ec2c9:	je     29fc0f1 <wasm[0]::function[1015]::helper::object_read+0x1b1d1>
 29ec2cf:	test   %edx,%edx
 29ec2d1:	je     29fc0f3 <wasm[0]::function[1015]::helper::object_read+0x1b1d3>
 29ec2d7:	mov    %edx,%edx
 29ec2d9:	lea    0x10(%rax,%rdx,1),%rax
 29ec2de:	cmp    %r11,%rdx
 29ec2e1:	cmova  %rcx,%rax
 29ec2e5:	mov    (%rax),%eax
 29ec2e7:	test   %eax,%eax
 29ec2e9:	setne  %al
 29ec2ec:	movzbl %al,%ebx
 29ec2ef:	jmp    29ec3e1 <wasm[0]::function[1015]::helper::object_read+0xb4c1>
 29ec2f4:	movq   %rsi,%xmm0
 29ec2f9:	ucomisd 0x105cf(%rip),%xmm0        # 29fc8d0 <wasm[0]::function[1015]::helper::object_read+0x1b9b0>
 29ec301:	setnp  %al
 29ec304:	sete   %cl
 29ec307:	and    %ecx,%eax
 29ec309:	ucomisd %xmm0,%xmm0
 29ec30d:	setp   %cl
 29ec310:	setne  %dl
 29ec313:	or     %edx,%ecx
 29ec315:	or     %ecx,%eax
 29ec317:	movzbl %al,%eax
 29ec31a:	test   %eax,%eax
 29ec31c:	sete   %al
 29ec31f:	movzbl %al,%ebx
 29ec322:	jmp    29ec3e1 <wasm[0]::function[1015]::helper::object_read+0xb4c1>
 29ec327:	xor    %eax,%eax
 29ec329:	test   %edx,%edx
 29ec32b:	je     29ec37c <wasm[0]::function[1015]::helper::object_read+0xb45c>
 29ec331:	xor    %eax,%eax
 29ec333:	test   $0x1,%edx
 29ec339:	jne    29ec37c <wasm[0]::function[1015]::helper::object_read+0xb45c>
 29ec33f:	mov    0x2e0(%rsp),%r12
 29ec347:	mov    0x28(%r12),%rax
 29ec34c:	mov    0x20(%r12),%rcx
 29ec351:	mov    %edx,%esi
 29ec353:	lea    0x4(%rcx,%rsi,1),%rcx
 29ec358:	xor    %rdi,%rdi
 29ec35b:	cmp    %rax,%rsi
 29ec35e:	cmova  %rdi,%rcx
 29ec362:	mov    (%rcx),%eax
 29ec364:	mov    0x190(%rsp),%rcx
 29ec36c:	mov    0x28(%rcx),%rcx
 29ec370:	cmp    0x234(%rcx),%eax
 29ec376:	sete   %al
 29ec379:	movzbl %al,%eax
 29ec37c:	test   %eax,%eax
 29ec37e:	je     29fc0f5 <wasm[0]::function[1015]::helper::object_read+0x1b1d5>
 29ec384:	test   %edx,%edx
 29ec386:	je     29fc0f7 <wasm[0]::function[1015]::helper::object_read+0x1b1d7>
 29ec38c:	test   %edx,%edx
 29ec38e:	je     29fc0f9 <wasm[0]::function[1015]::helper::object_read+0x1b1d9>
 29ec394:	mov    0x2e0(%rsp),%r12
 29ec39c:	mov    0x28(%r12),%rax
 29ec3a1:	mov    0x20(%r12),%rcx
 29ec3a6:	mov    %edx,%edi
 29ec3a8:	lea    (%rcx,%rdi,1),%rsi
 29ec3ac:	xor    %rdx,%rdx
 29ec3af:	cmp    %rax,%rdi
 29ec3b2:	cmova  %rdx,%rsi
 29ec3b6:	mov    0x10(%rsi),%esi
 29ec3b9:	test   %esi,%esi
 29ec3bb:	je     29fc0fb <wasm[0]::function[1015]::helper::object_read+0x1b1db>
 29ec3c1:	test   %esi,%esi
 29ec3c3:	je     29fc0fd <wasm[0]::function[1015]::helper::object_read+0x1b1dd>
 29ec3c9:	mov    %esi,%esi
 29ec3cb:	lea    0x10(%rcx,%rsi,1),%rcx
 29ec3d0:	cmp    %rax,%rsi
 29ec3d3:	cmova  %rdx,%rcx
 29ec3d7:	mov    (%rcx),%eax
 29ec3d9:	test   %eax,%eax
 29ec3db:	setne  %al
 29ec3de:	movzbl %al,%ebx
 29ec3e1:	mov    0x2c0(%rsp),%rsi
 29ec3e9:	jmp    29ec3ff <wasm[0]::function[1015]::helper::object_read+0xb4df>
 29ec3ee:	test   %rsi,%rsi
 29ec3f1:	setne  %al
 29ec3f4:	movzbl %al,%ebx
 29ec3f7:	mov    0x2c0(%rsp),%rsi
 29ec3ff:	mov    0x2c0(%rsp),%rsi
 29ec407:	mov    (%rsi),%eax
 29ec409:	mov    %eax,%edx
 29ec40b:	lea    0x20(%rdx),%rcx
 29ec40f:	mov    0x4(%rsi),%esi
 29ec412:	cmp    %rsi,%rcx
 29ec415:	ja     29fab04 <wasm[0]::function[1015]::helper::object_read+0x19be4>
 29ec41b:	lea    0x20(%rax),%ecx
 29ec41e:	mov    0x2c0(%rsp),%rsi
 29ec426:	mov    %ecx,(%rsi)
 29ec428:	mov    0x2e0(%rsp),%r12
 29ec430:	mov    0x20(%r12),%rsi
 29ec435:	lea    (%rsi,%rdx,1),%rcx
 29ec439:	movl   $0xb0000042,(%rsi,%rdx,1)
 29ec440:	mov    0x190(%rsp),%rdi
 29ec448:	mov    0x28(%rdi),%rdi
 29ec44c:	mov    0x120(%rdi),%edi
 29ec452:	mov    %edi,0x4(%rsi,%rdx,1)
 29ec456:	mov    0x2c8(%rsp),%rdi
 29ec45e:	mov    %edi,0x8(%rsi,%rdx,1)
 29ec462:	mov    %eax,0x138(%rsp)
 29ec469:	mov    0x240(%rsp),%rax
 29ec471:	mov    %rax,0x10(%rcx)
 29ec475:	mov    0x248(%rsp),%r10
 29ec47d:	mov    %r10d,0x18(%rcx)
 29ec481:	mov    0x110(%rsp),%eax
 29ec488:	mov    %eax,0x1c(%rcx)
 29ec48b:	mov    0x2c0(%rsp),%rsi
 29ec493:	mov    (%rsi),%eax
 29ec495:	mov    %eax,%edx
 29ec497:	lea    0x20(%rdx),%rcx
 29ec49b:	mov    0x4(%rsi),%esi
 29ec49e:	cmp    %rsi,%rcx
 29ec4a1:	ja     29fab47 <wasm[0]::function[1015]::helper::object_read+0x19c27>
 29ec4a7:	lea    0x20(%rax),%esi
 29ec4aa:	mov    0x2c0(%rsp),%rcx
 29ec4b2:	mov    %esi,(%rcx)
 29ec4b4:	mov    0x2e0(%rsp),%r12
 29ec4bc:	mov    0x20(%r12),%rsi
 29ec4c1:	lea    (%rsi,%rdx,1),%rcx
 29ec4c5:	movl   $0xb0000042,(%rsi,%rdx,1)
 29ec4cc:	mov    0x190(%rsp),%r9
 29ec4d4:	mov    0x28(%r9),%rdi
 29ec4d8:	mov    0x120(%rdi),%edi
 29ec4de:	mov    %edi,0x4(%rsi,%rdx,1)
 29ec4e2:	mov    0x2c8(%rsp),%rdi
 29ec4ea:	mov    %edi,0x8(%rsi,%rdx,1)
 29ec4ee:	mov    %eax,0x110(%rsp)
 29ec4f5:	mov    0x250(%rsp),%rax
 29ec4fd:	mov    %rax,0x10(%rcx)
 29ec501:	mov    0x258(%rsp),%rax
 29ec509:	mov    %eax,0x18(%rcx)
 29ec50c:	mov    0xd8(%rsp),%r11d
 29ec514:	mov    %r11d,0x1c(%rcx)
 29ec518:	mov    0x2c0(%rsp),%rsi
 29ec520:	mov    (%rsi),%eax
 29ec522:	mov    %eax,%edx
 29ec524:	lea    0x20(%rdx),%rcx
 29ec528:	mov    0x4(%rsi),%esi
 29ec52b:	cmp    %rsi,%rcx
 29ec52e:	ja     29fab8a <wasm[0]::function[1015]::helper::object_read+0x19c6a>
 29ec534:	lea    0x20(%rax),%ecx
 29ec537:	mov    0x2c0(%rsp),%rsi
 29ec53f:	mov    %ecx,(%rsi)
 29ec541:	mov    0x2e0(%rsp),%r12
 29ec549:	mov    0x20(%r12),%rsi
 29ec54e:	lea    (%rsi,%rdx,1),%rcx
 29ec552:	movl   $0xb0000042,(%rsi,%rdx,1)
 29ec559:	mov    0x190(%rsp),%rdi
 29ec561:	mov    0x28(%rdi),%rdi
 29ec565:	mov    0x120(%rdi),%edi
 29ec56b:	mov    %edi,0x4(%rsi,%rdx,1)
 29ec56f:	mov    0x2c8(%rsp),%rdi
 29ec577:	mov    %edi,0x8(%rsi,%rdx,1)
 29ec57b:	mov    %eax,0xd8(%rsp)
 29ec582:	mov    0x260(%rsp),%rdx
 29ec58a:	mov    %rdx,0x10(%rcx)
 29ec58e:	mov    0x268(%rsp),%rdx
 29ec596:	mov    %edx,0x18(%rcx)
 29ec599:	mov    0x130(%rsp),%edx
 29ec5a0:	mov    %edx,0x1c(%rcx)
 29ec5a3:	mov    0x270(%rsp),%rcx
 29ec5ab:	mov    0x270(%rsp),%rdx
 29ec5b3:	test   %edx,%ecx
 29ec5b5:	jne    29ec694 <wasm[0]::function[1015]::helper::object_read+0xb774>
 29ec5bb:	mov    0x138(%rsp),%ecx
 29ec5c2:	test   %ecx,%ecx
 29ec5c4:	je     29fc0ff <wasm[0]::function[1015]::helper::object_read+0x1b1df>
 29ec5ca:	mov    0x110(%rsp),%ecx
 29ec5d1:	test   %ecx,%ecx
 29ec5d3:	je     29fc101 <wasm[0]::function[1015]::helper::object_read+0x1b1e1>
 29ec5d9:	test   %eax,%eax
 29ec5db:	je     29fc103 <wasm[0]::function[1015]::helper::object_read+0x1b1e3>
 29ec5e1:	mov    0x2c0(%rsp),%rsi
 29ec5e9:	mov    (%rsi),%eax
 29ec5eb:	mov    %eax,%edx
 29ec5ed:	lea    0x20(%rdx),%rcx
 29ec5f1:	mov    0x4(%rsi),%esi
 29ec5f4:	cmp    %rsi,%rcx
 29ec5f7:	ja     29fabcd <wasm[0]::function[1015]::helper::object_read+0x19cad>
 29ec5fd:	lea    0x20(%rax),%ecx
 29ec600:	mov    0x2c0(%rsp),%rsi
 29ec608:	mov    %ecx,(%rsi)
 29ec60a:	mov    0x2e0(%rsp),%r12
 29ec612:	mov    0x20(%r12),%rsi
 29ec617:	lea    (%rsi,%rdx,1),%rcx
 29ec61b:	movl   $0xb0000072,(%rsi,%rdx,1)
 29ec622:	mov    0x190(%rsp),%rdi
 29ec62a:	mov    0x28(%rdi),%rdi
 29ec62e:	mov    0x13c(%rdi),%edi
 29ec634:	mov    %edi,0x4(%rsi,%rdx,1)
 29ec638:	mov    0x2c8(%rsp),%rdi
 29ec640:	mov    %edi,0x8(%rsi,%rdx,1)
 29ec644:	test   %r13d,%r13d
 29ec647:	setne  %dl
 29ec64a:	movzbl %dl,%edx
 29ec64d:	shl    $0x2,%edx
 29ec650:	test   %r14d,%r14d
 29ec653:	setne  %sil
 29ec657:	movzbl %sil,%esi
 29ec65b:	shl    $0x3,%esi
 29ec65e:	or     %esi,%edx
 29ec660:	test   %ebx,%ebx
 29ec662:	setne  %sil
 29ec666:	movzbl %sil,%esi
 29ec66a:	shl    $1,%esi
 29ec66c:	or     %esi,%edx
 29ec66e:	mov    %edx,0x10(%rcx)
 29ec671:	mov    0x138(%rsp),%edx
 29ec678:	mov    %edx,0x14(%rcx)
 29ec67b:	mov    0x110(%rsp),%edx
 29ec682:	mov    %edx,0x18(%rcx)
 29ec685:	mov    0xd8(%rsp),%edx
 29ec68c:	mov    %edx,0x1c(%rcx)
 29ec68f:	jmp    29ec75b <wasm[0]::function[1015]::helper::object_read+0xb83b>
 29ec694:	mov    0x138(%rsp),%ecx
 29ec69b:	test   %ecx,%ecx
 29ec69d:	je     29fc105 <wasm[0]::function[1015]::helper::object_read+0x1b1e5>
 29ec6a3:	mov    0x110(%rsp),%ecx
 29ec6aa:	test   %ecx,%ecx
 29ec6ac:	je     29fc107 <wasm[0]::function[1015]::helper::object_read+0x1b1e7>
 29ec6b2:	test   %eax,%eax
 29ec6b4:	je     29fc109 <wasm[0]::function[1015]::helper::object_read+0x1b1e9>
 29ec6ba:	mov    0x2c0(%rsp),%rsi
 29ec6c2:	mov    (%rsi),%eax
 29ec6c4:	mov    %eax,%edx
 29ec6c6:	lea    0x20(%rdx),%rcx
 29ec6ca:	mov    0x4(%rsi),%esi
 29ec6cd:	cmp    %rsi,%rcx
 29ec6d0:	ja     29fac10 <wasm[0]::function[1015]::helper::object_read+0x19cf0>
 29ec6d6:	lea    0x20(%rax),%ecx
 29ec6d9:	mov    0x2c0(%rsp),%rsi
 29ec6e1:	mov    %ecx,(%rsi)
 29ec6e3:	mov    0x2e0(%rsp),%r12
 29ec6eb:	mov    0x20(%r12),%rsi
 29ec6f0:	lea    (%rsi,%rdx,1),%rcx
 29ec6f4:	movl   $0xb0000072,(%rsi,%rdx,1)
 29ec6fb:	mov    0x190(%rsp),%rdi
 29ec703:	mov    0x28(%rdi),%rdi
 29ec707:	mov    0x13c(%rdi),%edi
 29ec70d:	mov    %edi,0x4(%rsi,%rdx,1)
 29ec711:	mov    0x2c8(%rsp),%rdi
 29ec719:	mov    %edi,0x8(%rsi,%rdx,1)
 29ec71d:	test   %r14d,%r14d
 29ec720:	setne  %dl
 29ec723:	movzbl %dl,%edx
 29ec726:	shl    $0x3,%edx
 29ec729:	or     $0x1,%edx
 29ec72c:	test   %ebx,%ebx
 29ec72e:	setne  %sil
 29ec732:	movzbl %sil,%esi
 29ec736:	shl    $1,%esi
 29ec738:	or     %esi,%edx
 29ec73a:	mov    %edx,0x10(%rcx)
 29ec73d:	mov    0x138(%rsp),%edx
 29ec744:	mov    %edx,0x14(%rcx)
 29ec747:	mov    0x110(%rsp),%esi
 29ec74e:	mov    %esi,0x18(%rcx)
 29ec751:	mov    0xd8(%rsp),%esi
 29ec758:	mov    %esi,0x1c(%rcx)
 29ec75b:	mov    0xa0(%rsp),%esi
 29ec762:	mov    0x118(%rsp),%edi
 29ec769:	mov    0xe0(%rsp),%r8d
 29ec771:	mov    0x100(%rsp),%edx
 29ec778:	mov    0xc8(%rsp),%ecx
 29ec77f:	mov    %rax,%r15
 29ec782:	jmp    29ef287 <wasm[0]::function[1015]::helper::object_read+0xe367>
 29ec787:	mov    0xb0(%rsp),%edx
 29ec78e:	mov    0x2a8(%rsp),%rax
 29ec796:	mov    0x2b0(%rsp),%rcx
 29ec79e:	mov    0x2f0(%rsp),%rbx
 29ec7a6:	mov    0x2f8(%rsp),%r12
 29ec7ae:	mov    0x300(%rsp),%r13
 29ec7b6:	mov    0x308(%rsp),%r14
 29ec7be:	mov    0x310(%rsp),%r15
 29ec7c6:	add    $0x320,%rsp
 29ec7cd:	mov    %rbp,%rsp
 29ec7d0:	pop    %rbp
 29ec7d1:	ret    $0x40
 29ec7d4:	xor    %eax,%eax
 29ec7d6:	mov    0x210(%rsp),%rdx
 29ec7de:	mov    0x210(%rsp),%rsi
 29ec7e6:	test   %esi,%edx
 29ec7e8:	je     29ec849 <wasm[0]::function[1015]::helper::object_read+0xb929>
 29ec7ee:	xor    %eax,%eax
 29ec7f0:	mov    0x210(%rsp),%rdx
 29ec7f8:	test   $0x1,%edx
 29ec7fe:	jne    29ec849 <wasm[0]::function[1015]::helper::object_read+0xb929>
 29ec804:	mov    0x2e0(%rsp),%r12
 29ec80c:	mov    0x28(%r12),%rax
 29ec811:	mov    0x20(%r12),%rcx
 29ec816:	mov    0x210(%rsp),%rdx
 29ec81e:	mov    %edx,%edx
 29ec820:	lea    0x4(%rcx,%rdx,1),%rcx
 29ec825:	xor    %rsi,%rsi
 29ec828:	cmp    %rax,%rdx
 29ec82b:	cmova  %rsi,%rcx
 29ec82f:	mov    (%rcx),%eax
 29ec831:	mov    0x190(%rsp),%rcx
 29ec839:	mov    0x28(%rcx),%rcx
 29ec83d:	cmp    0x254(%rcx),%eax
 29ec843:	sete   %al
 29ec846:	movzbl %al,%eax
 29ec849:	test   %eax,%eax
 29ec84b:	je     29fc10b <wasm[0]::function[1015]::helper::object_read+0x1b1eb>
 29ec851:	mov    0x210(%rsp),%rax
 29ec859:	mov    0x210(%rsp),%rdx
 29ec861:	test   %eax,%edx
 29ec863:	je     29fc10d <wasm[0]::function[1015]::helper::object_read+0x1b1ed>
 29ec869:	test   %eax,%edx
 29ec86b:	je     29fc10f <wasm[0]::function[1015]::helper::object_read+0x1b1ef>
 29ec871:	mov    0x2e0(%rsp),%r12
 29ec879:	mov    0x28(%r12),%rax
 29ec87e:	mov    0x20(%r12),%rcx
 29ec883:	mov    %edx,%edx
 29ec885:	add    %rdx,%rcx
 29ec888:	xor    %rsi,%rsi
 29ec88b:	cmp    %rax,%rdx
 29ec88e:	cmova  %rsi,%rcx
 29ec892:	mov    0x10(%rcx),%edx
 29ec895:	test   %edx,%edx
 29ec897:	je     29fc111 <wasm[0]::function[1015]::helper::object_read+0x1b1f1>
 29ec89d:	mov    0x1b8(%rsp),%rcx
 29ec8a5:	mov    0x190(%rsp),%rsi
 29ec8ad:	mov    0x190(%rsp),%rdi
 29ec8b5:	mov    0x1c0(%rsp),%r8
 29ec8bd:	call   29ffc00 <wasm[0]::function[1019]::helper::ordinary_own_descriptor>
 29ec8c2:	mov    %rax,%r11
 29ec8c5:	mov    0xc0(%rsp),%eax
 29ec8cc:	mov    %rax,%r15
 29ec8cf:	mov    0x58(%rsp),%ecx
 29ec8d3:	mov    0xa8(%rsp),%edx
 29ec8da:	mov    0xb8(%rsp),%edi
 29ec8e1:	mov    0x48(%rsp),%r8d
 29ec8e6:	mov    0x80(%rsp),%esi
 29ec8ed:	mov    %r11,%rax
 29ec8f0:	test   %eax,%eax
 29ec8f2:	jne    29eeb23 <wasm[0]::function[1015]::helper::object_read+0xdc03>
 29ec8f8:	xor    %r9d,%r9d
 29ec8fb:	mov    0x1b8(%rsp),%r10
 29ec903:	cmp    $0x4,%r10d
 29ec907:	je     29ec915 <wasm[0]::function[1015]::helper::object_read+0xb9f5>
 29ec90d:	mov    %r8,%r10
 29ec910:	jmp    29eccdb <wasm[0]::function[1015]::helper::object_read+0xbdbb>
 29ec915:	xor    %r9d,%r9d
 29ec918:	test   %esi,%esi
 29ec91a:	je     29ec971 <wasm[0]::function[1015]::helper::object_read+0xba51>
 29ec920:	xor    %r9d,%r9d
 29ec923:	test   $0x1,%esi
 29ec929:	jne    29ec971 <wasm[0]::function[1015]::helper::object_read+0xba51>
 29ec92f:	mov    0x2e0(%rsp),%r12
 29ec937:	mov    0x28(%r12),%r9
 29ec93c:	mov    0x20(%r12),%r10
 29ec941:	mov    %esi,%r11d
 29ec944:	lea    0x4(%r10,%r11,1),%r10
 29ec949:	xor    %rbx,%rbx
 29ec94c:	cmp    %r9,%r11
 29ec94f:	cmova  %rbx,%r10
 29ec953:	mov    (%r10),%r9d
 29ec956:	mov    0x190(%rsp),%r10
 29ec95e:	mov    0x28(%r10),%r10
 29ec962:	cmp    0x234(%r10),%r9d
 29ec969:	sete   %r9b
 29ec96d:	movzbl %r9b,%r9d
 29ec971:	test   %r9d,%r9d
 29ec974:	je     29fc113 <wasm[0]::function[1015]::helper::object_read+0x1b1f3>
 29ec97a:	test   %esi,%esi
 29ec97c:	je     29fc115 <wasm[0]::function[1015]::helper::object_read+0x1b1f5>
 29ec982:	test   %esi,%esi
 29ec984:	je     29fc117 <wasm[0]::function[1015]::helper::object_read+0x1b1f7>
 29ec98a:	mov    0x2e0(%rsp),%r12
 29ec992:	mov    0x28(%r12),%r10
 29ec997:	mov    0x20(%r12),%r11
 29ec99c:	mov    %esi,%r12d
 29ec99f:	lea    (%r11,%r12,1),%r9
 29ec9a3:	xor    %rbx,%rbx
 29ec9a6:	cmp    %r10,%r12
 29ec9a9:	cmova  %rbx,%r9
 29ec9ad:	mov    0x10(%r9),%r12d
 29ec9b1:	mov    %r12d,0xb0(%rsp)
 29ec9b9:	xor    %r9d,%r9d
 29ec9bc:	test   %r12d,%r12d
 29ec9bf:	je     29fc119 <wasm[0]::function[1015]::helper::object_read+0x1b1f9>
 29ec9c5:	test   %r12d,%r12d
 29ec9c8:	je     29fc11b <wasm[0]::function[1015]::helper::object_read+0x1b1fb>
 29ec9ce:	mov    %r12d,%r12d
 29ec9d1:	lea    0x10(%r11,%r12,1),%r11
 29ec9d6:	cmp    %r10,%r12
 29ec9d9:	cmova  %rbx,%r11
 29ec9dd:	mov    (%r11),%ebx
 29ec9e0:	test   %ebx,%ebx
 29ec9e2:	sete   %r10b
 29ec9e6:	cmp    $0xa,%ebx
 29ec9e9:	seta   %r11b
 29ec9ed:	or     %r11d,%r10d
 29ec9f0:	test   %r10b,%r10b
 29ec9f3:	je     29eca01 <wasm[0]::function[1015]::helper::object_read+0xbae1>
 29ec9f9:	mov    %r8,%r10
 29ec9fc:	jmp    29eccdb <wasm[0]::function[1015]::helper::object_read+0xbdbb>
 29eca01:	mov    0xb0(%rsp),%ecx
 29eca08:	test   %ecx,%ecx
 29eca0a:	je     29fc11d <wasm[0]::function[1015]::helper::object_read+0x1b1fd>
 29eca10:	test   %ecx,%ecx
 29eca12:	je     29fc11f <wasm[0]::function[1015]::helper::object_read+0x1b1ff>
 29eca18:	mov    0x2e0(%rsp),%r12
 29eca20:	mov    0x28(%r12),%rdx
 29eca25:	mov    0x20(%r12),%rsi
 29eca2a:	mov    %ecx,%r9d
 29eca2d:	lea    0x10(%rsi,%r9,1),%r8
 29eca32:	xor    %rdi,%rdi
 29eca35:	cmp    %rdx,%r9
 29eca38:	cmova  %rdi,%r8
 29eca3c:	mov    (%r8),%r8d
 29eca3f:	test   %r8d,%r8d
 29eca42:	je     29fc121 <wasm[0]::function[1015]::helper::object_read+0x1b201>
 29eca48:	mov    %r8d,%r9d
 29eca4b:	shl    $1,%r9
 29eca4e:	shr    $0x20,%r9
 29eca52:	test   %r9,%r9
 29eca55:	jne    29fc123 <wasm[0]::function[1015]::helper::object_read+0x1b203>
 29eca5b:	add    %r8d,%r8d
 29eca5e:	add    $0x14,%r8d
 29eca62:	jb     29fc125 <wasm[0]::function[1015]::helper::object_read+0x1b205>
 29eca68:	add    %r8d,%ecx
 29eca6b:	jb     29fc127 <wasm[0]::function[1015]::helper::object_read+0x1b207>
 29eca71:	mov    %ecx,%r9d
 29eca74:	add    %r9,%rsi
 29eca77:	cmp    %rdx,%r9
 29eca7a:	cmova  %rdi,%rsi
 29eca7e:	sub    $0x14,%r8d
 29eca82:	sub    %r8,%rsi
 29eca85:	movzwl (%rsi),%r9d
 29eca89:	cmp    $0x30,%r9d
 29eca8d:	je     29ecc8f <wasm[0]::function[1015]::helper::object_read+0xbd6f>
 29eca93:	mov    0x48(%rsp),%r10d
 29eca98:	mov    0x80(%rsp),%esi
 29eca9f:	mov    0xc0(%rsp),%ecx
 29ecaa6:	mov    %rcx,%r15
 29ecaa9:	mov    0x58(%rsp),%ecx
 29ecaad:	mov    0xa8(%rsp),%edx
 29ecab4:	mov    0xb8(%rsp),%edi
 29ecabb:	xor    %r14d,%r14d
 29ecabe:	xor    %r13,%r13
 29ecac1:	mov    %r10,%r8
 29ecac4:	mov    %r10d,0x138(%rsp)
 29ecacc:	mov    %esi,0x110(%rsp)
 29ecad3:	mov    %eax,0xd8(%rsp)
 29ecada:	mov    %r15,%rax
 29ecadd:	mov    %eax,0xc8(%rsp)
 29ecae4:	mov    %ecx,0x100(%rsp)
 29ecaeb:	mov    %edx,0xe0(%rsp)
 29ecaf2:	mov    %edi,0x118(%rsp)
 29ecaf9:	mov    %r8d,0xa0(%rsp)
 29ecb01:	mov    0x2e8(%rsp),%r10
 29ecb09:	mov    (%r10),%rax
 29ecb0c:	mov    0x228(%rsp),%rsi
 29ecb14:	cmp    %rsi,%rax
 29ecb17:	jae    29fac53 <wasm[0]::function[1015]::helper::object_read+0x19d33>
 29ecb1d:	mov    0xb0(%rsp),%r11d
 29ecb25:	xor    %r9d,%r9d
 29ecb28:	test   %r11d,%r11d
 29ecb2b:	je     29fc129 <wasm[0]::function[1015]::helper::object_read+0x1b209>
 29ecb31:	test   %r11d,%r11d
 29ecb34:	je     29fc12b <wasm[0]::function[1015]::helper::object_read+0x1b20b>
 29ecb3a:	mov    0x2e0(%rsp),%r12
 29ecb42:	mov    0x28(%r12),%rax
 29ecb47:	mov    0x20(%r12),%rcx
 29ecb4c:	mov    %r11d,%edi
 29ecb4f:	lea    0x10(%rcx,%rdi,1),%rsi
 29ecb54:	xor    %rdx,%rdx
 29ecb57:	cmp    %rax,%rdi
 29ecb5a:	cmova  %rdx,%rsi
 29ecb5e:	mov    (%rsi),%esi
 29ecb60:	cmp    %esi,%r14d
 29ecb63:	jae    29fc12d <wasm[0]::function[1015]::helper::object_read+0x1b20d>
 29ecb69:	mov    %esi,%edi
 29ecb6b:	shl    $1,%rdi
 29ecb6e:	shr    $0x20,%rdi
 29ecb72:	test   %rdi,%rdi
 29ecb75:	jne    29fc12f <wasm[0]::function[1015]::helper::object_read+0x1b20f>
 29ecb7b:	add    %esi,%esi
 29ecb7d:	add    $0x14,%esi
 29ecb80:	jb     29fc131 <wasm[0]::function[1015]::helper::object_read+0x1b211>
 29ecb86:	add    %esi,%r11d
 29ecb89:	jb     29fc133 <wasm[0]::function[1015]::helper::object_read+0x1b213>
 29ecb8f:	mov    %r11d,%edi
 29ecb92:	add    %rdi,%rcx
 29ecb95:	cmp    %rax,%rdi
 29ecb98:	cmova  %rdx,%rcx
 29ecb9c:	lea    0x14(%r14,%r14,1),%eax
 29ecba1:	sub    %eax,%esi
 29ecba3:	sub    %rsi,%rcx
 29ecba6:	movzwq (%rcx),%r11
 29ecbaa:	mov    0x138(%rsp),%r10d
 29ecbb2:	mov    0x110(%rsp),%esi
 29ecbb9:	mov    0xd8(%rsp),%eax
 29ecbc0:	mov    0xc8(%rsp),%ecx
 29ecbc7:	mov    %rcx,%r15
 29ecbca:	mov    0x100(%rsp),%ecx
 29ecbd1:	mov    0xe0(%rsp),%edx
 29ecbd8:	mov    0x118(%rsp),%edi
 29ecbdf:	mov    0xa0(%rsp),%r8d
 29ecbe7:	movzwl %r11w,%r11d
 29ecbeb:	mov    %r11,%r12
 29ecbee:	sub    $0x30,%r12d
 29ecbf2:	cmp    $0x9,%r12d
 29ecbf6:	ja     29eccdb <wasm[0]::function[1015]::helper::object_read+0xbdbb>
 29ecbfc:	mov    0x138(%rsp),%r10d
 29ecc04:	mov    0x110(%rsp),%esi
 29ecc0b:	mov    0xd8(%rsp),%eax
 29ecc12:	mov    0xc8(%rsp),%edi
 29ecc19:	mov    %rdi,%r15
 29ecc1c:	mov    0x100(%rsp),%ecx
 29ecc23:	mov    0xe0(%rsp),%edx
 29ecc2a:	mov    0x118(%rsp),%edi
 29ecc31:	mov    0xa0(%rsp),%r8d
 29ecc39:	add    $0x1,%r14d
 29ecc40:	imul   $0xa,%r13,%r9
 29ecc44:	mov    %r11,%r12
 29ecc47:	sub    $0x30,%r12d
 29ecc4b:	add    %r9,%r12
 29ecc4e:	cmp    %ebx,%r14d
 29ecc51:	jae    29ecc5f <wasm[0]::function[1015]::helper::object_read+0xbd3f>
 29ecc57:	mov    %r12,%r13
 29ecc5a:	jmp    29ecac4 <wasm[0]::function[1015]::helper::object_read+0xbba4>
 29ecc5f:	xor    %r9d,%r9d
 29ecc62:	cmp    0xfc3f(%rip),%r12        # 29fc8a8 <wasm[0]::function[1015]::helper::object_read+0x1b988>
 29ecc69:	jae    29eccdb <wasm[0]::function[1015]::helper::object_read+0xbdbb>
 29ecc6f:	imul   $0xa,%r13d,%r9d
 29ecc73:	sub    $0x30,%r11d
 29ecc77:	add    %r11d,%r9d
 29ecc7a:	mov    %r9,0x200(%rsp)
 29ecc82:	mov    0x278(%rsp),%r9
 29ecc8a:	jmp    29eccdb <wasm[0]::function[1015]::helper::object_read+0xbdbb>
 29ecc8f:	mov    0x48(%rsp),%r10d
 29ecc94:	mov    0x80(%rsp),%esi
 29ecc9b:	mov    0xc0(%rsp),%ecx
 29ecca2:	mov    %rcx,%r15
 29ecca5:	mov    0x58(%rsp),%ecx
 29ecca9:	mov    0xa8(%rsp),%edx
 29eccb0:	mov    0xb8(%rsp),%edi
 29eccb7:	cmp    $0x1,%ebx
 29eccba:	sete   %r8b
 29eccbe:	movzbl %r8b,%r9d
 29eccc2:	mov    %r8,%r11
 29eccc5:	mov    %r8,0x200(%rsp)
 29ecccd:	xor    %r11d,%r8d
 29eccd0:	mov    %r8,0x200(%rsp)
 29eccd8:	mov    %r10,%r8
 29eccdb:	mov    %r10d,0xa0(%rsp)
 29ecce3:	mov    %esi,0x118(%rsp)
 29eccea:	mov    %eax,0xe0(%rsp)
 29eccf1:	mov    %r15,%rax
 29eccf4:	mov    %eax,0x100(%rsp)
 29eccfb:	mov    %ecx,0xc8(%rsp)
 29ecd02:	mov    %edx,0xd8(%rsp)
 29ecd09:	mov    %edi,0x110(%rsp)
 29ecd10:	mov    %r8d,0x138(%rsp)
 29ecd18:	test   %r9d,%r9d
 29ecd1b:	jne    29ed6ac <wasm[0]::function[1015]::helper::object_read+0xc78c>
 29ecd21:	mov    $0x8c,%edx
 29ecd26:	mov    0x190(%rsp),%rsi
 29ecd2e:	mov    0x190(%rsp),%rdi
 29ecd36:	call   2f307a0 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 29ecd3b:	test   %eax,%eax
 29ecd3d:	je     29fc135 <wasm[0]::function[1015]::helper::object_read+0x1b215>
 29ecd43:	mov    0x1b8(%rsp),%rcx
 29ecd4b:	cmp    $0x4,%ecx
 29ecd4e:	je     29ecd9f <wasm[0]::function[1015]::helper::object_read+0xbe7f>
 29ecd54:	mov    0xa0(%rsp),%ecx
 29ecd5b:	mov    0xe0(%rsp),%eax
 29ecd62:	mov    %rax,%r11
 29ecd65:	mov    0x100(%rsp),%esi
 29ecd6c:	mov    0xc8(%rsp),%edi
 29ecd73:	mov    0xd8(%rsp),%r8d
 29ecd7b:	mov    0x110(%rsp),%r9d
 29ecd83:	mov    0x138(%rsp),%r10d
 29ecd8b:	mov    0x118(%rsp),%edx
 29ecd92:	xor    %eax,%eax
 29ecd94:	mov    %rax,%r14
 29ecd97:	mov    %r11,%rax
 29ecd9a:	jmp    29ed47b <wasm[0]::function[1015]::helper::object_read+0xc55b>
 29ecd9f:	mov    0x1b8(%rsp),%rcx
 29ecda7:	cmp    $0x3,%ecx
 29ecdaa:	je     29ed3ea <wasm[0]::function[1015]::helper::object_read+0xc4ca>
 29ecdb0:	mov    0x1b8(%rsp),%rcx
 29ecdb8:	cmp    $0x4,%ecx
 29ecdbb:	je     29ed293 <wasm[0]::function[1015]::helper::object_read+0xc373>
 29ecdc1:	mov    0x1b8(%rsp),%rcx
 29ecdc9:	cmp    $0xa,%ecx
 29ecdcc:	je     29ece8b <wasm[0]::function[1015]::helper::object_read+0xbf6b>
 29ecdd2:	mov    0x1b8(%rsp),%rcx
 29ecdda:	mov    0x1b8(%rsp),%rdx
 29ecde2:	test   %edx,%ecx
 29ecde4:	sete   %r11b
 29ecde8:	cmp    $0x1,%ecx
 29ecdeb:	sete   %cl
 29ecdee:	or     %ecx,%r11d
 29ecdf1:	test   %r11b,%r11b
 29ecdf4:	jne    29ece43 <wasm[0]::function[1015]::helper::object_read+0xbf23>
 29ecdfa:	mov    0x1b8(%rsp),%rcx
 29ece02:	cmp    $0x2,%ecx
 29ece05:	je     29ece22 <wasm[0]::function[1015]::helper::object_read+0xbf02>
 29ece0b:	mov    0x118(%rsp),%ecx
 29ece12:	cmp    %eax,%ecx
 29ece14:	sete   %al
 29ece17:	movzbl %al,%eax
 29ece1a:	mov    %rax,%r14
 29ece1d:	jmp    29ece4b <wasm[0]::function[1015]::helper::object_read+0xbf2b>
 29ece22:	mov    0x1c0(%rsp),%rax
 29ece2a:	mov    0x1c0(%rsp),%r8
 29ece32:	test   %rax,%r8
 29ece35:	sete   %al
 29ece38:	movzbl %al,%eax
 29ece3b:	mov    %rax,%r14
 29ece3e:	jmp    29ece4b <wasm[0]::function[1015]::helper::object_read+0xbf2b>
 29ece43:	mov    0x278(%rsp),%r14
 29ece4b:	mov    0xa0(%rsp),%ecx
 29ece52:	mov    0xe0(%rsp),%eax
 29ece59:	mov    0x100(%rsp),%esi
 29ece60:	mov    0xc8(%rsp),%edi
 29ece67:	mov    0xd8(%rsp),%r8d
 29ece6f:	mov    0x110(%rsp),%r9d
 29ece77:	mov    0x138(%rsp),%r10d
 29ece7f:	mov    0x118(%rsp),%edx
 29ece86:	jmp    29ed47b <wasm[0]::function[1015]::helper::object_read+0xc55b>
 29ece8b:	mov    0x118(%rsp),%edx
 29ece92:	xor    %ecx,%ecx
 29ece94:	test   %edx,%edx
 29ece96:	je     29ecee7 <wasm[0]::function[1015]::helper::object_read+0xbfc7>
 29ece9c:	xor    %ecx,%ecx
 29ece9e:	test   $0x1,%edx
 29ecea4:	jne    29ecee7 <wasm[0]::function[1015]::helper::object_read+0xbfc7>
 29eceaa:	mov    0x2e0(%rsp),%r12
 29eceb2:	mov    0x28(%r12),%rcx
 29eceb7:	mov    0x20(%r12),%rdi
 29ecebc:	mov    %edx,%esi
 29ecebe:	lea    0x4(%rdi,%rsi,1),%rdx
 29ecec3:	xor    %rdi,%rdi
 29ecec6:	cmp    %rcx,%rsi
 29ecec9:	cmova  %rdi,%rdx
 29ececd:	mov    (%rdx),%ecx
 29ececf:	mov    0x190(%rsp),%rdx
 29eced7:	mov    0x28(%rdx),%rdx
 29ecedb:	cmp    0x23c(%rdx),%ecx
 29ecee1:	sete   %cl
 29ecee4:	movzbl %cl,%ecx
 29ecee7:	test   %ecx,%ecx
 29ecee9:	je     29fc137 <wasm[0]::function[1015]::helper::object_read+0x1b217>
 29eceef:	xor    %edx,%edx
 29ecef1:	test   %eax,%eax
 29ecef3:	je     29ecf43 <wasm[0]::function[1015]::helper::object_read+0xc023>
 29ecef9:	xor    %edx,%edx
 29ecefb:	test   $0x1,%eax
 29ecf00:	jne    29ecf43 <wasm[0]::function[1015]::helper::object_read+0xc023>
 29ecf06:	mov    0x2e0(%rsp),%r12
 29ecf0e:	mov    0x28(%r12),%rcx
 29ecf13:	mov    0x20(%r12),%rdx
 29ecf18:	mov    %eax,%esi
 29ecf1a:	lea    0x4(%rdx,%rsi,1),%rdx
 29ecf1f:	xor    %rdi,%rdi
 29ecf22:	cmp    %rcx,%rsi
 29ecf25:	cmova  %rdi,%rdx
 29ecf29:	mov    (%rdx),%ecx
 29ecf2b:	mov    0x190(%rsp),%rdx
 29ecf33:	mov    0x28(%rdx),%rdx
 29ecf37:	cmp    0x23c(%rdx),%ecx
 29ecf3d:	sete   %cl
 29ecf40:	movzbl %cl,%edx
 29ecf43:	test   %edx,%edx
 29ecf45:	je     29fc139 <wasm[0]::function[1015]::helper::object_read+0x1b219>
 29ecf4b:	mov    0x118(%rsp),%edx
 29ecf52:	test   %edx,%edx
 29ecf54:	je     29fc13b <wasm[0]::function[1015]::helper::object_read+0x1b21b>
 29ecf5a:	test   %edx,%edx
 29ecf5c:	je     29fc13d <wasm[0]::function[1015]::helper::object_read+0x1b21d>
 29ecf62:	mov    0x2e0(%rsp),%r12
 29ecf6a:	mov    0x28(%r12),%rcx
 29ecf6f:	mov    0x20(%r12),%rsi
 29ecf74:	mov    %edx,%r9d
 29ecf77:	lea    (%rsi,%r9,1),%r8
 29ecf7b:	xor    %rdi,%rdi
 29ecf7e:	cmp    %rcx,%r9
 29ecf81:	cmova  %rdi,%r8
 29ecf85:	mov    0x10(%r8),%r11d
 29ecf89:	test   %eax,%eax
 29ecf8b:	je     29fc13f <wasm[0]::function[1015]::helper::object_read+0x1b21f>
 29ecf91:	mov    %eax,%r9d
 29ecf94:	lea    (%rsi,%r9,1),%rax
 29ecf98:	cmp    %rcx,%r9
 29ecf9b:	cmova  %rdi,%rax
 29ecf9f:	mov    0x10(%rax),%r12d
 29ecfa3:	mov    0x14(%r8),%r8d
 29ecfa7:	mov    %r8d,0xb0(%rsp)
 29ecfaf:	mov    0x14(%rax),%eax
 29ecfb2:	mov    %eax,0x130(%rsp)
 29ecfb9:	test   %r8d,%r8d
 29ecfbc:	je     29fc141 <wasm[0]::function[1015]::helper::object_read+0x1b221>
 29ecfc2:	test   %r8d,%r8d
 29ecfc5:	je     29fc143 <wasm[0]::function[1015]::helper::object_read+0x1b223>
 29ecfcb:	mov    %r8d,%r9d
 29ecfce:	lea    0x10(%rsi,%r9,1),%r8
 29ecfd3:	cmp    %rcx,%r9
 29ecfd6:	cmova  %rdi,%r8
 29ecfda:	mov    (%r8),%ebx
 29ecfdd:	test   %eax,%eax
 29ecfdf:	je     29fc145 <wasm[0]::function[1015]::helper::object_read+0x1b225>
 29ecfe5:	test   %eax,%eax
 29ecfe7:	je     29fc147 <wasm[0]::function[1015]::helper::object_read+0x1b227>
 29ecfed:	mov    %eax,%r8d
 29ecff0:	lea    0x10(%rsi,%r8,1),%rsi
 29ecff5:	cmp    %rcx,%r8
 29ecff8:	cmova  %rdi,%rsi
 29ecffc:	mov    (%rsi),%r13d
 29ecfff:	mov    0xa0(%rsp),%ecx
 29ed006:	mov    0xe0(%rsp),%eax
 29ed00d:	mov    0x100(%rsp),%esi
 29ed014:	mov    0xc8(%rsp),%edi
 29ed01b:	mov    0xd8(%rsp),%r8d
 29ed023:	mov    0x110(%rsp),%r9d
 29ed02b:	mov    0x138(%rsp),%r10d
 29ed033:	cmp    %r12d,%r11d
 29ed036:	sete   %r11b
 29ed03a:	cmp    %r13d,%ebx
 29ed03d:	sete   %r12b
 29ed041:	mov    %r11,%r13
 29ed044:	and    %r12d,%r13d
 29ed047:	movzbl %r13b,%r13d
 29ed04b:	mov    %r13,%r14
 29ed04e:	test   %r11b,%r12b
 29ed051:	je     29ed47b <wasm[0]::function[1015]::helper::object_read+0xc55b>
 29ed057:	mov    0xa0(%rsp),%ecx
 29ed05e:	mov    0xe0(%rsp),%edx
 29ed065:	mov    0x100(%rsp),%esi
 29ed06c:	mov    0xc8(%rsp),%edi
 29ed073:	mov    0xd8(%rsp),%r8d
 29ed07b:	mov    0x110(%rsp),%r9d
 29ed083:	mov    0x138(%rsp),%r10d
 29ed08b:	mov    0x118(%rsp),%r11d
 29ed093:	xor    %r12d,%r12d
 29ed096:	mov    %ecx,0x90(%rsp)
 29ed09d:	mov    %edx,0x128(%rsp)
 29ed0a4:	mov    %esi,0x98(%rsp)
 29ed0ab:	mov    %edi,0x88(%rsp)
 29ed0b2:	mov    %r8d,0x78(%rsp)
 29ed0b7:	mov    %r9d,0x108(%rsp)
 29ed0bf:	mov    %r10d,0x120(%rsp)
 29ed0c7:	mov    %r11d,0xf8(%rsp)
 29ed0cf:	mov    0x2e8(%rsp),%r13
 29ed0d7:	mov    0x0(%r13),%rcx
 29ed0db:	mov    0x228(%rsp),%rax
 29ed0e3:	cmp    %rax,%rcx
 29ed0e6:	jae    29fac8e <wasm[0]::function[1015]::helper::object_read+0x19d6e>
 29ed0ec:	cmp    %ebx,%r12d
 29ed0ef:	jae    29ed256 <wasm[0]::function[1015]::helper::object_read+0xc336>
 29ed0f5:	mov    0xb0(%rsp),%edi
 29ed0fc:	test   %edi,%edi
 29ed0fe:	je     29fc149 <wasm[0]::function[1015]::helper::object_read+0x1b229>
 29ed104:	test   %edi,%edi
 29ed106:	je     29fc14b <wasm[0]::function[1015]::helper::object_read+0x1b22b>
 29ed10c:	mov    0x2e0(%rsp),%rax
 29ed114:	mov    0x28(%rax),%rcx
 29ed118:	mov    0x20(%rax),%rdx
 29ed11c:	mov    %edi,%r9d
 29ed11f:	lea    0x10(%rdx,%r9,1),%r8
 29ed124:	xor    %rsi,%rsi
 29ed127:	cmp    %rcx,%r9
 29ed12a:	cmova  %rsi,%r8
 29ed12e:	mov    (%r8),%r9d
 29ed131:	cmp    %r9d,%r12d
 29ed134:	jae    29fc14d <wasm[0]::function[1015]::helper::object_read+0x1b22d>
 29ed13a:	mov    %r9d,%r8d
 29ed13d:	shl    $0x3,%r8
 29ed141:	shr    $0x20,%r8
 29ed145:	test   %r8,%r8
 29ed148:	jne    29fc14f <wasm[0]::function[1015]::helper::object_read+0x1b22f>
 29ed14e:	shl    $0x3,%r9d
 29ed152:	add    $0x18,%r9d
 29ed156:	jb     29fc151 <wasm[0]::function[1015]::helper::object_read+0x1b231>
 29ed15c:	add    %r9d,%edi
 29ed15f:	jb     29fc153 <wasm[0]::function[1015]::helper::object_read+0x1b233>
 29ed165:	mov    %edi,%r8d
 29ed168:	lea    (%rdx,%r8,1),%rdi
 29ed16c:	cmp    %rcx,%r8
 29ed16f:	cmova  %rsi,%rdi
 29ed173:	mov    %r12,%rax
 29ed176:	shl    $0x3,%eax
 29ed179:	lea    0x18(%rax),%r8d
 29ed17d:	sub    %r8d,%r9d
 29ed180:	sub    %r9,%rdi
 29ed183:	mov    (%rdi),%rdi
 29ed186:	mov    0x130(%rsp),%r9d
 29ed18e:	test   %r9d,%r9d
 29ed191:	je     29fc155 <wasm[0]::function[1015]::helper::object_read+0x1b235>
 29ed197:	test   %r9d,%r9d
 29ed19a:	je     29fc157 <wasm[0]::function[1015]::helper::object_read+0x1b237>
 29ed1a0:	mov    %r9d,%r11d
 29ed1a3:	lea    0x10(%rdx,%r11,1),%r10
 29ed1a8:	cmp    %rcx,%r11
 29ed1ab:	cmova  %rsi,%r10
 29ed1af:	mov    (%r10),%r10d
 29ed1b2:	cmp    %r10d,%r12d
 29ed1b5:	jae    29fc159 <wasm[0]::function[1015]::helper::object_read+0x1b239>
 29ed1bb:	mov    %r10d,%r11d
 29ed1be:	shl    $0x3,%r11
 29ed1c2:	shr    $0x20,%r11
 29ed1c6:	test   %r11,%r11
 29ed1c9:	jne    29fc15b <wasm[0]::function[1015]::helper::object_read+0x1b23b>
 29ed1cf:	shl    $0x3,%r10d
 29ed1d3:	add    $0x18,%r10d
 29ed1d7:	jb     29fc15d <wasm[0]::function[1015]::helper::object_read+0x1b23d>
 29ed1dd:	add    %r10d,%r9d
 29ed1e0:	jb     29fc15f <wasm[0]::function[1015]::helper::object_read+0x1b23f>
 29ed1e6:	mov    %r9d,%r9d
 29ed1e9:	add    %r9,%rdx
 29ed1ec:	cmp    %rcx,%r9
 29ed1ef:	cmova  %rsi,%rdx
 29ed1f3:	sub    %r8d,%r10d
 29ed1f6:	sub    %r10,%rdx
 29ed1f9:	mov    (%rdx),%rcx
 29ed1fc:	cmp    %rcx,%rdi
 29ed1ff:	sete   %al
 29ed202:	movzbl %al,%edx
 29ed205:	mov    %rdx,%r14
 29ed208:	cmp    %rcx,%rdi
 29ed20b:	jne    29ed256 <wasm[0]::function[1015]::helper::object_read+0xc336>
 29ed211:	mov    0x90(%rsp),%ecx
 29ed218:	mov    0x128(%rsp),%edx
 29ed21f:	mov    0x98(%rsp),%esi
 29ed226:	mov    0x88(%rsp),%edi
 29ed22d:	mov    0x78(%rsp),%r8d
 29ed232:	mov    0x108(%rsp),%r9d
 29ed23a:	mov    0x120(%rsp),%r10d
 29ed242:	mov    0xf8(%rsp),%r11d
 29ed24a:	add    $0x1,%r12d
 29ed251:	jmp    29ed096 <wasm[0]::function[1015]::helper::object_read+0xc176>
 29ed256:	mov    0x90(%rsp),%ecx
 29ed25d:	mov    0x128(%rsp),%eax
 29ed264:	mov    0x98(%rsp),%esi
 29ed26b:	mov    0x88(%rsp),%edi
 29ed272:	mov    0x78(%rsp),%r8d
 29ed277:	mov    0x108(%rsp),%r9d
 29ed27f:	mov    0x120(%rsp),%r10d
 29ed287:	mov    0xf8(%rsp),%edx
 29ed28e:	jmp    29ed47b <wasm[0]::function[1015]::helper::object_read+0xc55b>
 29ed293:	mov    0x118(%rsp),%ecx
 29ed29a:	cmp    %eax,%ecx
 29ed29c:	je     29ed3a2 <wasm[0]::function[1015]::helper::object_read+0xc482>
 29ed2a2:	xor    %edx,%edx
 29ed2a4:	test   %ecx,%ecx
 29ed2a6:	je     29ed2f9 <wasm[0]::function[1015]::helper::object_read+0xc3d9>
 29ed2ac:	xor    %edx,%edx
 29ed2ae:	test   $0x1,%ecx
 29ed2b4:	jne    29ed2f9 <wasm[0]::function[1015]::helper::object_read+0xc3d9>
 29ed2ba:	mov    0x2e0(%rsp),%r12
 29ed2c2:	mov    0x28(%r12),%rsi
 29ed2c7:	mov    0x20(%r12),%r8
 29ed2cc:	mov    %ecx,%edi
 29ed2ce:	lea    0x4(%r8,%rdi,1),%rdx
 29ed2d3:	xor    %r8,%r8
 29ed2d6:	cmp    %rsi,%rdi
 29ed2d9:	cmova  %r8,%rdx
 29ed2dd:	mov    (%rdx),%esi
 29ed2df:	mov    0x190(%rsp),%rcx
 29ed2e7:	mov    0x28(%rcx),%rdi
 29ed2eb:	cmp    0x234(%rdi),%esi
 29ed2f1:	sete   %dil
 29ed2f5:	movzbl %dil,%edx
 29ed2f9:	test   %edx,%edx
 29ed2fb:	je     29fc161 <wasm[0]::function[1015]::helper::object_read+0x1b241>
 29ed301:	xor    %ecx,%ecx
 29ed303:	test   %eax,%eax
 29ed305:	jne    29ed313 <wasm[0]::function[1015]::helper::object_read+0xc3f3>
 29ed30b:	mov    %rax,%rdi
 29ed30e:	jmp    29ed368 <wasm[0]::function[1015]::helper::object_read+0xc448>
 29ed313:	xor    %ecx,%ecx
 29ed315:	test   $0x1,%eax
 29ed31a:	je     29ed328 <wasm[0]::function[1015]::helper::object_read+0xc408>
 29ed320:	mov    %rax,%rdi
 29ed323:	jmp    29ed368 <wasm[0]::function[1015]::helper::object_read+0xc448>
 29ed328:	mov    0x2e0(%rsp),%r12
 29ed330:	mov    0x28(%r12),%rcx
 29ed335:	mov    0x20(%r12),%rsi
 29ed33a:	mov    %eax,%edx
 29ed33c:	mov    %rax,%rdi
 29ed33f:	lea    0x4(%rsi,%rdx,1),%rax
 29ed344:	xor    %rsi,%rsi
 29ed347:	cmp    %rcx,%rdx
 29ed34a:	cmova  %rsi,%rax
 29ed34e:	mov    (%rax),%eax
 29ed350:	mov    0x190(%rsp),%rcx
 29ed358:	mov    0x28(%rcx),%rcx
 29ed35c:	cmp    0x234(%rcx),%eax
 29ed362:	sete   %al
 29ed365:	movzbl %al,%ecx
 29ed368:	test   %ecx,%ecx
 29ed36a:	je     29fc163 <wasm[0]::function[1015]::helper::object_read+0x1b243>
 29ed370:	mov    0x118(%rsp),%edx
 29ed377:	xor    %r8d,%r8d
 29ed37a:	test   %edx,%edx
 29ed37c:	je     29fc165 <wasm[0]::function[1015]::helper::object_read+0x1b245>
 29ed382:	mov    %rdi,%rcx
 29ed385:	mov    0x190(%rsp),%rsi
 29ed38d:	mov    0x190(%rsp),%rdi
 29ed395:	call   2ae54e0 <wasm[0]::function[1057]::helper::string_equality>
 29ed39a:	mov    %rax,%r14
 29ed39d:	jmp    29ed3aa <wasm[0]::function[1015]::helper::object_read+0xc48a>
 29ed3a2:	mov    0x278(%rsp),%r14
 29ed3aa:	mov    0xa0(%rsp),%ecx
 29ed3b1:	mov    0xe0(%rsp),%eax
 29ed3b8:	mov    0x100(%rsp),%esi
 29ed3bf:	mov    0xc8(%rsp),%edi
 29ed3c6:	mov    0xd8(%rsp),%r8d
 29ed3ce:	mov    0x110(%rsp),%r9d
 29ed3d6:	mov    0x138(%rsp),%r10d
 29ed3de:	mov    0x118(%rsp),%edx
 29ed3e5:	jmp    29ed47b <wasm[0]::function[1015]::helper::object_read+0xc55b>
 29ed3ea:	mov    0xa0(%rsp),%ecx
 29ed3f1:	mov    0xe0(%rsp),%eax
 29ed3f8:	mov    0x100(%rsp),%esi
 29ed3ff:	mov    0xc8(%rsp),%edi
 29ed406:	mov    0xd8(%rsp),%r8d
 29ed40e:	mov    0x110(%rsp),%r9d
 29ed416:	mov    0x138(%rsp),%r10d
 29ed41e:	mov    0x118(%rsp),%edx
 29ed425:	xor    %r12,%r12
 29ed428:	mov    0x1c0(%rsp),%rbx
 29ed430:	mov    0x1c0(%rsp),%r11
 29ed438:	test   %rbx,%r11
 29ed43b:	sete   %r11b
 29ed43f:	mov    0x1c0(%rsp),%r13
 29ed447:	movq   %r13,%xmm0
 29ed44c:	ucomisd %xmm0,%xmm0
 29ed450:	setp   %bl
 29ed453:	setne  %r13b
 29ed457:	or     %r13d,%ebx
 29ed45a:	movq   %r12,%xmm0
 29ed45f:	ucomisd %xmm0,%xmm0
 29ed463:	setp   %r12b
 29ed467:	setne  %r13b
 29ed46b:	or     %r13d,%r12d
 29ed46e:	and    %r12d,%ebx
 29ed471:	or     %ebx,%r11d
 29ed474:	movzbl %r11b,%r11d
 29ed478:	mov    %r11,%r14
 29ed47b:	mov    %esi,0x78(%rsp)
 29ed47f:	mov    %edi,0x88(%rsp)
 29ed486:	mov    %r8d,0x98(%rsp)
 29ed48e:	mov    %r9d,0x128(%rsp)
 29ed496:	mov    %r10d,0x90(%rsp)
 29ed49e:	mov    %edx,0xe0(%rsp)
 29ed4a5:	mov    %r14,%rdx
 29ed4a8:	mov    %r14,%rsi
 29ed4ab:	test   %esi,%edx
 29ed4ad:	je     29ed67c <wasm[0]::function[1015]::helper::object_read+0xc75c>
 29ed4b3:	test   %ecx,%ecx
 29ed4b5:	je     29fc167 <wasm[0]::function[1015]::helper::object_read+0x1b247>
 29ed4bb:	test   %ecx,%ecx
 29ed4bd:	je     29fc169 <wasm[0]::function[1015]::helper::object_read+0x1b249>
 29ed4c3:	mov    0x2e0(%rsp),%r12
 29ed4cb:	mov    0x28(%r12),%rdx
 29ed4d0:	mov    0x20(%r12),%rax
 29ed4d5:	mov    %ecx,%ecx
 29ed4d7:	add    %rcx,%rax
 29ed4da:	xor    %rsi,%rsi
 29ed4dd:	cmp    %rdx,%rcx
 29ed4e0:	cmova  %rsi,%rax
 29ed4e4:	mov    0x18(%rax),%r12
 29ed4e8:	movl   $0x0,0x108(%rsp)
 29ed4f3:	mov    $0x20,%r13d
 29ed4f9:	mov    0x20(%rax),%ebx
 29ed4fc:	mov    0x190(%rsp),%rcx
 29ed504:	mov    0x20(%rcx),%r14
 29ed508:	mov    (%r14),%eax
 29ed50b:	mov    %eax,%edx
 29ed50d:	lea    0x20(%rdx),%rcx
 29ed511:	mov    0x4(%r14),%esi
 29ed515:	cmp    %rsi,%rcx
 29ed518:	ja     29facc5 <wasm[0]::function[1015]::helper::object_read+0x19da5>
 29ed51e:	lea    0x20(%rax),%ecx
 29ed521:	mov    %ecx,(%r14)
 29ed524:	mov    0x2e0(%rsp),%rcx
 29ed52c:	mov    0x20(%rcx),%rsi
 29ed530:	lea    (%rsi,%rdx,1),%rcx
 29ed534:	movl   $0xb0000042,(%rsi,%rdx,1)
 29ed53b:	mov    0x190(%rsp),%r9
 29ed543:	mov    0x28(%r9),%rdi
 29ed547:	mov    0x120(%rdi),%edi
 29ed54d:	mov    %edi,0x4(%rsi,%rdx,1)
 29ed551:	mov    %r13d,0x8(%rsi,%rdx,1)
 29ed556:	mov    %eax,0x120(%rsp)
 29ed55d:	cmp    $0x0,%r12
 29ed561:	jl     29ed571 <wasm[0]::function[1015]::helper::object_read+0xc651>
 29ed567:	cvtsi2sd %r12,%xmm0
 29ed56c:	jmp    29ed58b <wasm[0]::function[1015]::helper::object_read+0xc66b>
 29ed571:	mov    %r12,%rsi
 29ed574:	shr    $0x1,%rsi
 29ed578:	mov    %r12,%rdx
 29ed57b:	and    $0x1,%rdx
 29ed57f:	or     %rsi,%rdx
 29ed582:	cvtsi2sd %rdx,%xmm0
 29ed587:	addsd  %xmm0,%xmm0
 29ed58b:	movq   %xmm0,%rdx
 29ed590:	mov    %rdx,0x10(%rcx)
 29ed594:	movl   $0x3,0x18(%rcx)
 29ed59b:	mov    0x108(%rsp),%edx
 29ed5a2:	mov    %edx,0x1c(%rcx)
 29ed5a5:	mov    0x190(%rsp),%rcx
 29ed5ad:	mov    0xa20(%rcx),%ecx
 29ed5b3:	mov    %ecx,0x108(%rsp)
 29ed5ba:	test   %eax,%eax
 29ed5bc:	je     29fc16b <wasm[0]::function[1015]::helper::object_read+0x1b24b>
 29ed5c2:	test   %ecx,%ecx
 29ed5c4:	je     29fc16d <wasm[0]::function[1015]::helper::object_read+0x1b24d>
 29ed5ca:	mov    (%r14),%eax
 29ed5cd:	mov    %eax,%ecx
 29ed5cf:	lea    0x20(%rcx),%rdx
 29ed5d3:	mov    0x4(%r14),%esi
 29ed5d7:	cmp    %rsi,%rdx
 29ed5da:	ja     29fad07 <wasm[0]::function[1015]::helper::object_read+0x19de7>
 29ed5e0:	lea    0x20(%rax),%edx
 29ed5e3:	mov    %edx,(%r14)
 29ed5e6:	mov    0x2e0(%rsp),%r12
 29ed5ee:	mov    0x20(%r12),%rsi
 29ed5f3:	lea    (%rsi,%rcx,1),%r9
 29ed5f7:	movl   $0xb0000072,(%rsi,%rcx,1)
 29ed5fe:	mov    0x190(%rsp),%rdx
 29ed606:	mov    0x28(%rdx),%rdi
 29ed60a:	mov    0x13c(%rdi),%edi
 29ed610:	mov    %edi,0x4(%rsi,%rcx,1)
 29ed614:	mov    %r13d,0x8(%rsi,%rcx,1)
 29ed619:	movl   $0x4,0x10(%r9)
 29ed621:	mov    0x120(%rsp),%r8d
 29ed629:	mov    %r8d,0x14(%r9)
 29ed62d:	mov    0x108(%rsp),%r10d
 29ed635:	mov    %r10d,0x18(%r9)
 29ed639:	mov    %r10d,0x1c(%r9)
 29ed63d:	test   %eax,%eax
 29ed63f:	je     29fc16f <wasm[0]::function[1015]::helper::object_read+0x1b24f>
 29ed645:	test   %eax,%eax
 29ed647:	je     29fc171 <wasm[0]::function[1015]::helper::object_read+0x1b251>
 29ed64d:	mov    0x2e0(%rsp),%r12
 29ed655:	mov    0x28(%r12),%rcx
 29ed65a:	test   %ebx,%ebx
 29ed65c:	setne  %dl
 29ed65f:	movzbl %dl,%edx
 29ed662:	shl    $0x2,%edx
 29ed665:	mov    %eax,%edi
 29ed667:	mov    %rdi,%rsi
 29ed66a:	add    0x20(%r12),%rsi
 29ed66f:	xor    %r8,%r8
 29ed672:	cmp    %rcx,%rdi
 29ed675:	cmova  %r8,%rsi
 29ed679:	mov    %edx,0x10(%rsi)
 29ed67c:	mov    0x78(%rsp),%ecx
 29ed680:	mov    %rcx,%r15
 29ed683:	mov    0x88(%rsp),%ecx
 29ed68a:	mov    0x98(%rsp),%edx
 29ed691:	mov    0x128(%rsp),%edi
 29ed698:	mov    0x90(%rsp),%r8d
 29ed6a0:	mov    0xe0(%rsp),%esi
 29ed6a7:	jmp    29eeb23 <wasm[0]::function[1015]::helper::object_read+0xdc03>
 29ed6ac:	test   %r10d,%r10d
 29ed6af:	je     29fc173 <wasm[0]::function[1015]::helper::object_read+0x1b253>
 29ed6b5:	test   %r10d,%r10d
 29ed6b8:	je     29fc175 <wasm[0]::function[1015]::helper::object_read+0x1b255>
 29ed6be:	mov    0x2e0(%rsp),%r12
 29ed6c6:	mov    0x28(%r12),%r9
 29ed6cb:	mov    0x20(%r12),%r11
 29ed6d0:	mov    %r10d,%ebx
 29ed6d3:	lea    (%r11,%rbx,1),%rax
 29ed6d7:	xor    %r10,%r10
 29ed6da:	cmp    %r9,%rbx
 29ed6dd:	cmova  %r10,%rax
 29ed6e1:	mov    0x14(%rax),%eax
 29ed6e4:	mov    %eax,0xa0(%rsp)
 29ed6eb:	test   %eax,%eax
 29ed6ed:	je     29fc177 <wasm[0]::function[1015]::helper::object_read+0x1b257>
 29ed6f3:	test   %eax,%eax
 29ed6f5:	je     29fc179 <wasm[0]::function[1015]::helper::object_read+0x1b259>
 29ed6fb:	mov    %eax,%ebx
 29ed6fd:	add    %rbx,%r11
 29ed700:	cmp    %r9,%rbx
 29ed703:	cmova  %r10,%r11
 29ed707:	mov    0x24(%r11),%r10d
 29ed70b:	cmp    $0x2,%r10d
 29ed70f:	sete   %r9b
 29ed713:	cmp    $0x3,%r10d
 29ed717:	sete   %r10b
 29ed71b:	or     %r10d,%r9d
 29ed71e:	test   %r9b,%r9b
 29ed721:	je     29ee78d <wasm[0]::function[1015]::helper::object_read+0xd86d>
 29ed727:	mov    0xa0(%rsp),%eax
 29ed72e:	test   %eax,%eax
 29ed730:	je     29fc17b <wasm[0]::function[1015]::helper::object_read+0x1b25b>
 29ed736:	test   %eax,%eax
 29ed738:	je     29fc17d <wasm[0]::function[1015]::helper::object_read+0x1b25d>
 29ed73e:	mov    0x2e0(%rsp),%r12
 29ed746:	mov    0x28(%r12),%rcx
 29ed74b:	mov    %eax,%edx
 29ed74d:	mov    %rdx,%rax
 29ed750:	add    0x20(%r12),%rax
 29ed755:	xor    %rsi,%rsi
 29ed758:	cmp    %rcx,%rdx
 29ed75b:	cmova  %rsi,%rax
 29ed75f:	mov    0x24(%rax),%eax
 29ed762:	cmp    $0x3,%eax
 29ed765:	je     29ed893 <wasm[0]::function[1015]::helper::object_read+0xc973>
 29ed76b:	mov    0xa0(%rsp),%eax
 29ed772:	xor    %r9d,%r9d
 29ed775:	test   %eax,%eax
 29ed777:	je     29fc17f <wasm[0]::function[1015]::helper::object_read+0x1b25f>
 29ed77d:	test   %eax,%eax
 29ed77f:	je     29fc181 <wasm[0]::function[1015]::helper::object_read+0x1b261>
 29ed785:	mov    0x2e0(%rsp),%r12
 29ed78d:	mov    0x28(%r12),%rcx
 29ed792:	mov    0x20(%r12),%rdx
 29ed797:	mov    %eax,%edi
 29ed799:	lea    (%rdx,%rdi,1),%rax
 29ed79d:	xor    %rsi,%rsi
 29ed7a0:	cmp    %rcx,%rdi
 29ed7a3:	cmova  %rsi,%rax
 29ed7a7:	mov    0x28(%rax),%edi
 29ed7aa:	mov    0x2c(%rax),%eax
 29ed7ad:	test   %edi,%edi
 29ed7af:	je     29fc183 <wasm[0]::function[1015]::helper::object_read+0x1b263>
 29ed7b5:	test   %edi,%edi
 29ed7b7:	je     29fc185 <wasm[0]::function[1015]::helper::object_read+0x1b265>
 29ed7bd:	mov    %edi,%edi
 29ed7bf:	lea    0x10(%rdx,%rdi,1),%rdx
 29ed7c4:	cmp    %rcx,%rdi
 29ed7c7:	cmova  %rsi,%rdx
 29ed7cb:	mov    0x200(%rsp),%rcx
 29ed7d3:	mov    %ecx,%ecx
 29ed7d5:	mov    (%rdx),%edx
 29ed7d7:	cmp    %rdx,%rcx
 29ed7da:	jae    29ed99a <wasm[0]::function[1015]::helper::object_read+0xca7a>
 29ed7e0:	xor    %r9d,%r9d
 29ed7e3:	test   %eax,%eax
 29ed7e5:	je     29fc187 <wasm[0]::function[1015]::helper::object_read+0x1b267>
 29ed7eb:	test   %eax,%eax
 29ed7ed:	je     29fc189 <wasm[0]::function[1015]::helper::object_read+0x1b269>
 29ed7f3:	mov    0x2e0(%rsp),%r12
 29ed7fb:	mov    0x28(%r12),%rcx
 29ed800:	mov    0x20(%r12),%rdx
 29ed805:	mov    %eax,%r8d
 29ed808:	lea    0x10(%rdx,%r8,1),%rdi
 29ed80d:	xor    %rsi,%rsi
 29ed810:	cmp    %rcx,%r8
 29ed813:	cmova  %rsi,%rdi
 29ed817:	mov    (%rdi),%edi
 29ed819:	mov    0x200(%rsp),%r8
 29ed821:	shr    $0x6,%r8d
 29ed825:	cmp    %edi,%r8d
 29ed828:	jae    29fc18b <wasm[0]::function[1015]::helper::object_read+0x1b26b>
 29ed82e:	mov    %edi,%r10d
 29ed831:	shl    $0x3,%r10
 29ed835:	shr    $0x20,%r10
 29ed839:	test   %r10,%r10
 29ed83c:	jne    29fc18d <wasm[0]::function[1015]::helper::object_read+0x1b26d>
 29ed842:	shl    $0x3,%edi
 29ed845:	add    $0x18,%edi
 29ed848:	jb     29fc18f <wasm[0]::function[1015]::helper::object_read+0x1b26f>
 29ed84e:	add    %edi,%eax
 29ed850:	jb     29fc191 <wasm[0]::function[1015]::helper::object_read+0x1b271>
 29ed856:	mov    %eax,%r10d
 29ed859:	lea    (%rdx,%r10,1),%rax
 29ed85d:	cmp    %rcx,%r10
 29ed860:	cmova  %rsi,%rax
 29ed864:	shl    $0x3,%r8d
 29ed868:	lea    0x18(%r8),%esi
 29ed86c:	sub    %esi,%edi
 29ed86e:	sub    %rdi,%rax
 29ed871:	mov    (%rax),%rsi
 29ed874:	mov    0x200(%rsp),%rax
 29ed87c:	bt     %rax,%rsi
 29ed880:	jae    29ed99a <wasm[0]::function[1015]::helper::object_read+0xca7a>
 29ed886:	mov    0x278(%rsp),%r9
 29ed88e:	jmp    29ed99a <wasm[0]::function[1015]::helper::object_read+0xca7a>
 29ed893:	mov    0xa0(%rsp),%r11d
 29ed89b:	xor    %r9d,%r9d
 29ed89e:	test   %r11d,%r11d
 29ed8a1:	je     29fc193 <wasm[0]::function[1015]::helper::object_read+0x1b273>
 29ed8a7:	test   %r11d,%r11d
 29ed8aa:	je     29fc195 <wasm[0]::function[1015]::helper::object_read+0x1b275>
 29ed8b0:	mov    0x2e0(%rsp),%r12
 29ed8b8:	mov    0x28(%r12),%rcx
 29ed8bd:	mov    0x20(%r12),%rdx
 29ed8c2:	mov    %r11d,%edi
 29ed8c5:	lea    (%rdx,%rdi,1),%rax
 29ed8c9:	xor    %rsi,%rsi
 29ed8cc:	cmp    %rcx,%rdi
 29ed8cf:	cmova  %rsi,%rax
 29ed8d3:	mov    0x30(%rax),%eax
 29ed8d6:	test   %eax,%eax
 29ed8d8:	je     29fc197 <wasm[0]::function[1015]::helper::object_read+0x1b277>
 29ed8de:	test   %eax,%eax
 29ed8e0:	je     29fc199 <wasm[0]::function[1015]::helper::object_read+0x1b279>
 29ed8e6:	mov    %eax,%r8d
 29ed8e9:	lea    0x10(%rdx,%r8,1),%rdx
 29ed8ee:	cmp    %rcx,%r8
 29ed8f1:	cmova  %rsi,%rdx
 29ed8f5:	mov    0x200(%rsp),%rsi
 29ed8fd:	mov    %esi,%ecx
 29ed8ff:	mov    (%rdx),%edx
 29ed901:	cmp    %rdx,%rcx
 29ed904:	jae    29ed99a <wasm[0]::function[1015]::helper::object_read+0xca7a>
 29ed90a:	mov    0x2e0(%rsp),%r12
 29ed912:	mov    0x28(%r12),%rcx
 29ed917:	mov    0x20(%r12),%rdi
 29ed91c:	lea    0x10(%rdi,%r8,1),%rsi
 29ed921:	xor    %rdx,%rdx
 29ed924:	cmp    %rcx,%r8
 29ed927:	cmova  %rdx,%rsi
 29ed92b:	mov    (%rsi),%esi
 29ed92d:	mov    0x200(%rsp),%r9
 29ed935:	cmp    %esi,%r9d
 29ed938:	jae    29fc19b <wasm[0]::function[1015]::helper::object_read+0x1b27b>
 29ed93e:	mov    %esi,%r8d
 29ed941:	shl    $0x2,%r8
 29ed945:	shr    $0x20,%r8
 29ed949:	test   %r8,%r8
 29ed94c:	jne    29fc19d <wasm[0]::function[1015]::helper::object_read+0x1b27d>
 29ed952:	shl    $0x2,%esi
 29ed955:	add    $0x14,%esi
 29ed958:	jb     29fc19f <wasm[0]::function[1015]::helper::object_read+0x1b27f>
 29ed95e:	add    %esi,%eax
 29ed960:	jb     29fc1a1 <wasm[0]::function[1015]::helper::object_read+0x1b281>
 29ed966:	mov    %eax,%r8d
 29ed969:	lea    (%rdi,%r8,1),%rax
 29ed96d:	cmp    %rcx,%r8
 29ed970:	cmova  %rdx,%rax
 29ed974:	mov    %r9,%rcx
 29ed977:	shl    $0x2,%ecx
 29ed97a:	add    $0x14,%ecx
 29ed980:	sub    %ecx,%esi
 29ed982:	sub    %rsi,%rax
 29ed985:	mov    (%rax),%eax
 29ed987:	xor    %r9d,%r9d
 29ed98a:	test   %eax,%eax
 29ed98c:	je     29ed99a <wasm[0]::function[1015]::helper::object_read+0xca7a>
 29ed992:	mov    0x278(%rsp),%r9
 29ed99a:	mov    0xa0(%rsp),%eax
 29ed9a1:	mov    0x100(%rsp),%ecx
 29ed9a8:	mov    %rcx,%r15
 29ed9ab:	mov    0xc8(%rsp),%ecx
 29ed9b2:	mov    0xd8(%rsp),%edx
 29ed9b9:	mov    0x110(%rsp),%edi
 29ed9c0:	mov    0x138(%rsp),%r8d
 29ed9c8:	mov    0x118(%rsp),%esi
 29ed9cf:	test   %r9d,%r9d
 29ed9d2:	je     29ee78d <wasm[0]::function[1015]::helper::object_read+0xd86d>
 29ed9d8:	mov    0xa0(%rsp),%eax
 29ed9df:	test   %eax,%eax
 29ed9e1:	je     29fc1a3 <wasm[0]::function[1015]::helper::object_read+0x1b283>
 29ed9e7:	test   %eax,%eax
 29ed9e9:	je     29fc1a5 <wasm[0]::function[1015]::helper::object_read+0x1b285>
 29ed9ef:	mov    0x2e0(%rsp),%r12
 29ed9f7:	mov    0x28(%r12),%rcx
 29ed9fc:	mov    %eax,%edx
 29ed9fe:	mov    %rdx,%rax
 29eda01:	add    0x20(%r12),%rax
 29eda06:	xor    %rsi,%rsi
 29eda09:	cmp    %rcx,%rdx
 29eda0c:	cmova  %rsi,%rax
 29eda10:	mov    0x24(%rax),%eax
 29eda13:	cmp    $0x3,%eax
 29eda16:	je     29ee1a8 <wasm[0]::function[1015]::helper::object_read+0xd288>
 29eda1c:	mov    0xa0(%rsp),%eax
 29eda23:	test   %eax,%eax
 29eda25:	je     29fc1a7 <wasm[0]::function[1015]::helper::object_read+0x1b287>
 29eda2b:	test   %eax,%eax
 29eda2d:	je     29fc1a9 <wasm[0]::function[1015]::helper::object_read+0x1b289>
 29eda33:	mov    0x2e0(%rsp),%r12
 29eda3b:	mov    0x28(%r12),%rcx
 29eda40:	mov    %eax,%esi
 29eda42:	mov    %rsi,%rdx
 29eda45:	add    0x20(%r12),%rdx
 29eda4a:	xor    %rdi,%rdi
 29eda4d:	cmp    %rcx,%rsi
 29eda50:	cmova  %rdi,%rdx
 29eda54:	mov    0x24(%rdx),%r9d
 29eda58:	mov    0x100(%rsp),%ecx
 29eda5f:	mov    %rcx,%r15
 29eda62:	mov    0xc8(%rsp),%ecx
 29eda69:	mov    0xd8(%rsp),%edx
 29eda70:	mov    0x110(%rsp),%edi
 29eda77:	mov    0x138(%rsp),%r8d
 29eda7f:	mov    0x118(%rsp),%esi
 29eda86:	cmp    $0x2,%r9d
 29eda8a:	jne    29ee78d <wasm[0]::function[1015]::helper::object_read+0xd86d>
 29eda90:	mov    0xa0(%rsp),%edx
 29eda97:	test   %edx,%edx
 29eda99:	je     29fc1ab <wasm[0]::function[1015]::helper::object_read+0x1b28b>
 29eda9f:	test   %edx,%edx
 29edaa1:	je     29fc1ad <wasm[0]::function[1015]::helper::object_read+0x1b28d>
 29edaa7:	mov    0x2e0(%rsp),%r12
 29edaaf:	mov    0x28(%r12),%rax
 29edab4:	mov    0x20(%r12),%rcx
 29edab9:	mov    %edx,%esi
 29edabb:	lea    (%rcx,%rsi,1),%rdi
 29edabf:	xor    %rdx,%rdx
 29edac2:	cmp    %rax,%rsi
 29edac5:	cmova  %rdx,%rdi
 29edac9:	mov    0x28(%rdi),%esi
 29edacc:	mov    %esi,0x78(%rsp)
 29edad0:	mov    0x2c(%rdi),%edi
 29edad3:	mov    %edi,0x88(%rsp)
 29edada:	test   %esi,%esi
 29edadc:	je     29fc1af <wasm[0]::function[1015]::helper::object_read+0x1b28f>
 29edae2:	test   %esi,%esi
 29edae4:	je     29fc1b1 <wasm[0]::function[1015]::helper::object_read+0x1b291>
 29edaea:	mov    %esi,%edi
 29edaec:	lea    0x10(%rcx,%rdi,1),%rsi
 29edaf1:	cmp    %rax,%rdi
 29edaf4:	cmova  %rdx,%rsi
 29edaf8:	mov    (%rsi),%esi
 29edafa:	mov    %esi,%r14d
 29edafd:	mov    %r14,%r13
 29edb00:	shl    $0x2,%r13
 29edb04:	mov    $0x20,%edi
 29edb09:	mov    %rdi,0x1f8(%rsp)
 29edb11:	mov    %r13,%rdi
 29edb14:	shr    $0x20,%rdi
 29edb18:	test   %rdi,%rdi
 29edb1b:	jne    29fc1b3 <wasm[0]::function[1015]::helper::object_read+0x1b293>
 29edb21:	mov    %rsi,%rcx
 29edb24:	shl    $0x2,%ecx
 29edb27:	mov    %rsi,0x208(%rsp)
 29edb2f:	add    $0x14,%ecx
 29edb32:	jb     29fc1b5 <wasm[0]::function[1015]::helper::object_read+0x1b295>
 29edb38:	mov    0x190(%rsp),%rax
 29edb40:	mov    0x20(%rax),%r15
 29edb44:	mov    (%r15),%eax
 29edb47:	mov    %eax,%r8d
 29edb4a:	mov    %ecx,%r9d
 29edb4d:	lea    0xf(%r9),%rdx
 29edb51:	mov    %rdx,%r9
 29edb54:	and    $0xfffffffffffffff0,%r9
 29edb58:	add    %r8,%r9
 29edb5b:	mov    0x4(%r15),%r10d
 29edb5f:	cmp    %r10,%r9
 29edb62:	ja     29fad4b <wasm[0]::function[1015]::helper::object_read+0x19e2b>
 29edb68:	lea    0xf(%rcx),%r10d
 29edb6c:	and    $0xfffffff0,%r10d
 29edb70:	lea    (%rax,%r10,1),%r11d
 29edb74:	mov    %r11d,(%r15)
 29edb77:	mov    0x2e0(%rsp),%r12
 29edb7f:	mov    0x20(%r12),%rsi
 29edb84:	lea    (%rsi,%r8,1),%rcx
 29edb88:	movl   $0xa800000e,(%rsi,%r8,1)
 29edb90:	mov    0x190(%rsp),%rdi
 29edb98:	mov    0x28(%rdi),%rdi
 29edb9c:	mov    0x194(%rdi),%edi
 29edba2:	mov    %edi,0x4(%rsi,%r8,1)
 29edba7:	and    $0xfffffffffffffff0,%rdx
 29edbab:	mov    %edx,0x8(%rsi,%r8,1)
 29edbb0:	mov    %eax,0x98(%rsp)
 29edbb7:	mov    0x208(%rsp),%rdx
 29edbbf:	mov    %edx,0x10(%rcx)
 29edbc2:	test   %eax,%eax
 29edbc4:	je     29fc1b7 <wasm[0]::function[1015]::helper::object_read+0x1b297>
 29edbca:	mov    0x2e0(%rsp),%r12
 29edbd2:	mov    0x28(%r12),%rcx
 29edbd7:	mov    0x20(%r12),%rdx
 29edbdc:	mov    %eax,%eax
 29edbde:	lea    (%rdx,%rax,1),%r12
 29edbe2:	lea    0x10(%rdx,%rax,1),%rsi
 29edbe7:	xor    %rdi,%rdi
 29edbea:	cmp    %rcx,%rax
 29edbed:	cmova  %rdi,%rsi
 29edbf1:	mov    (%rsi),%esi
 29edbf3:	cmp    %rsi,%r14
 29edbf6:	ja     29fc1b9 <wasm[0]::function[1015]::helper::object_read+0x1b299>
 29edbfc:	lea    0x14(%rdx,%rax,1),%rbx
 29edc01:	mov    %rbx,%rax
 29edc04:	add    %r13,%rax
 29edc07:	jb     29fc1bb <wasm[0]::function[1015]::helper::object_read+0x1b29b>
 29edc0d:	add    %rdx,%rcx
 29edc10:	cmp    %rcx,%rax
 29edc13:	ja     29fc1bd <wasm[0]::function[1015]::helper::object_read+0x1b29d>
 29edc19:	mov    0x88(%rsp),%r11d
 29edc21:	mov    0x78(%rsp),%eax
 29edc25:	mov    0xa0(%rsp),%ecx
 29edc2c:	mov    0x100(%rsp),%edx
 29edc33:	mov    0xc8(%rsp),%esi
 29edc3a:	mov    0xd8(%rsp),%edi
 29edc41:	mov    0x110(%rsp),%r8d
 29edc49:	mov    0x138(%rsp),%r9d
 29edc51:	mov    0x118(%rsp),%r10d
 29edc59:	lea    0x14(%r12,%r14,4),%r13
 29edc5e:	test   %r14,%r14
 29edc61:	je     29edd19 <wasm[0]::function[1015]::helper::object_read+0xcdf9>
 29edc67:	mov    %r11d,0xb0(%rsp)
 29edc6f:	mov    %eax,0xf8(%rsp)
 29edc76:	mov    %ecx,0x120(%rsp)
 29edc7d:	mov    %edx,0x108(%rsp)
 29edc84:	mov    %esi,0xe0(%rsp)
 29edc8b:	mov    %edi,0x90(%rsp)
 29edc92:	mov    %r8d,0x128(%rsp)
 29edc9a:	mov    %r9d,0x78(%rsp)
 29edc9f:	mov    %r10d,0x88(%rsp)
 29edca7:	mov    0x2e8(%rsp),%rax
 29edcaf:	mov    (%rax),%rax
 29edcb2:	mov    0x228(%rsp),%rcx
 29edcba:	cmp    %rcx,%rax
 29edcbd:	jae    29fad8a <wasm[0]::function[1015]::helper::object_read+0x19e6a>
 29edcc3:	movl   $0x0,(%rbx)
 29edcc9:	mov    0xb0(%rsp),%r11d
 29edcd1:	mov    0xf8(%rsp),%eax
 29edcd8:	mov    0x120(%rsp),%ecx
 29edcdf:	mov    0x108(%rsp),%edx
 29edce6:	mov    0xe0(%rsp),%esi
 29edced:	mov    0x90(%rsp),%edi
 29edcf4:	mov    0x128(%rsp),%r8d
 29edcfc:	mov    0x78(%rsp),%r9d
 29edd01:	mov    0x88(%rsp),%r10d
 29edd09:	add    $0x4,%rbx
 29edd10:	cmp    %r13,%rbx
 29edd13:	jne    29edc67 <wasm[0]::function[1015]::helper::object_read+0xcd47>
 29edd19:	mov    %r11d,0xf8(%rsp)
 29edd21:	mov    %eax,0xb0(%rsp)
 29edd28:	xor    %ebx,%ebx
 29edd2a:	mov    $0xb0000042,%r14d
 29edd30:	mov    0x190(%rsp),%rax
 29edd38:	mov    %r14,0x1f0(%rsp)
 29edd40:	mov    0x28(%rax),%rax
 29edd44:	mov    0x120(%rax),%r14d
 29edd4b:	mov    %r14,0x1e8(%rsp)
 29edd53:	mov    $0x20,%r14d
 29edd59:	mov    %r14,0x1e0(%rsp)
 29edd61:	mov    $0x10,%r13d
 29edd67:	mov    %r13,0x1d8(%rsp)
 29edd6f:	mov    $0xb0000072,%r11d
 29edd75:	mov    %r11,0x1d0(%rsp)
 29edd7d:	mov    0x13c(%rax),%eax
 29edd83:	mov    %rax,%r14
 29edd86:	mov    %ecx,0x88(%rsp)
 29edd8d:	mov    %edx,0x78(%rsp)
 29edd91:	mov    %esi,0x128(%rsp)
 29edd98:	mov    %edi,0x90(%rsp)
 29edd9f:	mov    %r8d,0xe0(%rsp)
 29edda7:	mov    %r9d,0x108(%rsp)
 29eddaf:	mov    %r10d,0x120(%rsp)
 29eddb7:	mov    0x2e8(%rsp),%r13
 29eddbf:	mov    0x0(%r13),%rax
 29eddc3:	mov    0x228(%rsp),%r8
 29eddcb:	cmp    %r8,%rax
 29eddce:	jae    29fadc2 <wasm[0]::function[1015]::helper::object_read+0x19ea2>
 29eddd4:	mov    0x208(%rsp),%rcx
 29edddc:	jmp    29edde9 <wasm[0]::function[1015]::helper::object_read+0xcec9>
 29edde1:	mov    0x208(%rsp),%rcx
 29edde9:	cmp    %ecx,%ebx
 29eddeb:	jae    29ee0f6 <wasm[0]::function[1015]::helper::object_read+0xd1d6>
 29eddf1:	mov    0xf8(%rsp),%eax
 29eddf8:	test   %eax,%eax
 29eddfa:	je     29fc1bf <wasm[0]::function[1015]::helper::object_read+0x1b29f>
 29ede00:	test   %eax,%eax
 29ede02:	je     29fc1c1 <wasm[0]::function[1015]::helper::object_read+0x1b2a1>
 29ede08:	mov    0x2e0(%rsp),%r12
 29ede10:	mov    0x28(%r12),%r11
 29ede15:	mov    0x20(%r12),%rcx
 29ede1a:	mov    %eax,%esi
 29ede1c:	lea    0x10(%rcx,%rsi,1),%r8
 29ede21:	xor    %rdx,%rdx
 29ede24:	cmp    %r11,%rsi
 29ede27:	cmova  %rdx,%r8
 29ede2b:	mov    (%r8),%esi
 29ede2e:	mov    %rbx,%rdi
 29ede31:	shr    $0x6,%edi
 29ede34:	cmp    %esi,%edi
 29ede36:	jae    29fc1c3 <wasm[0]::function[1015]::helper::object_read+0x1b2a3>
 29ede3c:	mov    %esi,%r8d
 29ede3f:	shl    $0x3,%r8
 29ede43:	shr    $0x20,%r8
 29ede47:	test   %r8,%r8
 29ede4a:	jne    29fc1c5 <wasm[0]::function[1015]::helper::object_read+0x1b2a5>
 29ede50:	shl    $0x3,%esi
 29ede53:	add    $0x18,%esi
 29ede56:	jb     29fc1c7 <wasm[0]::function[1015]::helper::object_read+0x1b2a7>
 29ede5c:	add    %esi,%eax
 29ede5e:	jb     29fc1c9 <wasm[0]::function[1015]::helper::object_read+0x1b2a9>
 29ede64:	mov    %eax,%r8d
 29ede67:	lea    (%rcx,%r8,1),%rax
 29ede6b:	cmp    %r11,%r8
 29ede6e:	cmova  %rdx,%rax
 29ede72:	shl    $0x3,%edi
 29ede75:	lea    0x18(%rdi),%ecx
 29ede78:	sub    %ecx,%esi
 29ede7a:	sub    %rsi,%rax
 29ede7d:	mov    (%rax),%rax
 29ede80:	bt     %rbx,%rax
 29ede84:	jb     29ede97 <wasm[0]::function[1015]::helper::object_read+0xcf77>
 29ede8a:	mov    0x1f8(%rsp),%r13
 29ede92:	jmp    29ee0b2 <wasm[0]::function[1015]::helper::object_read+0xd192>
 29ede97:	mov    0xb0(%rsp),%r8d
 29ede9f:	test   %r8d,%r8d
 29edea2:	je     29fc1cb <wasm[0]::function[1015]::helper::object_read+0x1b2ab>
 29edea8:	test   %r8d,%r8d
 29edeab:	je     29fc1cd <wasm[0]::function[1015]::helper::object_read+0x1b2ad>
 29edeb1:	mov    0x2e0(%rsp),%r12
 29edeb9:	mov    0x28(%r12),%rax
 29edebe:	mov    0x20(%r12),%rcx
 29edec3:	mov    %r8d,%edi
 29edec6:	lea    0x10(%rcx,%rdi,1),%rsi
 29edecb:	xor    %rdx,%rdx
 29edece:	cmp    %rax,%rdi
 29eded1:	cmova  %rdx,%rsi
 29eded5:	mov    (%rsi),%esi
 29eded7:	cmp    %esi,%ebx
 29eded9:	jae    29fc1cf <wasm[0]::function[1015]::helper::object_read+0x1b2af>
 29ededf:	mov    %esi,%edi
 29edee1:	shl    $0x3,%rdi
 29edee5:	shr    $0x20,%rdi
 29edee9:	test   %rdi,%rdi
 29edeec:	jne    29fc1d1 <wasm[0]::function[1015]::helper::object_read+0x1b2b1>
 29edef2:	shl    $0x3,%esi
 29edef5:	add    $0x18,%esi
 29edef8:	jb     29fc1d3 <wasm[0]::function[1015]::helper::object_read+0x1b2b3>
 29edefe:	add    %esi,%r8d
 29edf01:	jb     29fc1d5 <wasm[0]::function[1015]::helper::object_read+0x1b2b5>
 29edf07:	mov    %r8d,%edi
 29edf0a:	add    %rdi,%rcx
 29edf0d:	cmp    %rax,%rdi
 29edf10:	cmova  %rdx,%rcx
 29edf14:	mov    %rbx,%rax
 29edf17:	shl    $0x3,%eax
 29edf1a:	add    $0x18,%eax
 29edf20:	sub    %eax,%esi
 29edf22:	sub    %rsi,%rcx
 29edf25:	mov    (%rcx),%r12
 29edf28:	movl   $0x0,0x130(%rsp)
 29edf33:	mov    (%r15),%eax
 29edf36:	mov    %eax,%edx
 29edf38:	lea    0x20(%rdx),%rcx
 29edf3c:	mov    0x4(%r15),%esi
 29edf40:	cmp    %rsi,%rcx
 29edf43:	ja     29fae02 <wasm[0]::function[1015]::helper::object_read+0x19ee2>
 29edf49:	lea    0x20(%rax),%ecx
 29edf4c:	mov    %ecx,(%r15)
 29edf4f:	mov    0x2e0(%rsp),%rcx
 29edf57:	mov    0x20(%rcx),%rsi
 29edf5b:	lea    (%rsi,%rdx,1),%rcx
 29edf5f:	movl   $0xb0000042,(%rsi,%rdx,1)
 29edf66:	mov    0x1e8(%rsp),%rdi
 29edf6e:	mov    %edi,0x4(%rsi,%rdx,1)
 29edf72:	mov    0x1f8(%rsp),%r13
 29edf7a:	mov    %r13d,0x8(%rsi,%rdx,1)
 29edf7f:	mov    %eax,0xd0(%rsp)
 29edf86:	mov    %r12,0x10(%rcx)
 29edf8a:	movl   $0x3,0x18(%rcx)
 29edf91:	mov    0x130(%rsp),%edx
 29edf98:	mov    %edx,0x1c(%rcx)
 29edf9b:	mov    0x190(%rsp),%rcx
 29edfa3:	mov    0xa20(%rcx),%ecx
 29edfa9:	mov    %ecx,0x130(%rsp)
 29edfb0:	test   %eax,%eax
 29edfb2:	je     29fc1d7 <wasm[0]::function[1015]::helper::object_read+0x1b2b7>
 29edfb8:	test   %ecx,%ecx
 29edfba:	je     29fc1d9 <wasm[0]::function[1015]::helper::object_read+0x1b2b9>
 29edfc0:	mov    (%r15),%eax
 29edfc3:	mov    %eax,%edx
 29edfc5:	lea    0x20(%rdx),%rcx
 29edfc9:	mov    0x4(%r15),%esi
 29edfcd:	cmp    %rsi,%rcx
 29edfd0:	ja     29fae4a <wasm[0]::function[1015]::helper::object_read+0x19f2a>
 29edfd6:	lea    0x20(%rax),%ecx
 29edfd9:	mov    %ecx,(%r15)
 29edfdc:	mov    0x2e0(%rsp),%r12
 29edfe4:	mov    0x20(%r12),%rsi
 29edfe9:	lea    (%rsi,%rdx,1),%rcx
 29edfed:	movl   $0xb0000072,(%rsi,%rdx,1)
 29edff4:	mov    %r14d,0x4(%rsi,%rdx,1)
 29edff9:	mov    %r13d,0x8(%rsi,%rdx,1)
 29edffe:	movl   $0xe,0x10(%rcx)
 29ee005:	mov    0xd0(%rsp),%edx
 29ee00c:	mov    %edx,0x14(%rcx)
 29ee00f:	mov    0x130(%rsp),%edx
 29ee016:	mov    %edx,0x18(%rcx)
 29ee019:	mov    %edx,0x1c(%rcx)
 29ee01c:	mov    0x98(%rsp),%ecx
 29ee023:	test   %ecx,%ecx
 29ee025:	je     29fc1db <wasm[0]::function[1015]::helper::object_read+0x1b2bb>
 29ee02b:	test   %eax,%eax
 29ee02d:	je     29fc1dd <wasm[0]::function[1015]::helper::object_read+0x1b2bd>
 29ee033:	test   %ecx,%ecx
 29ee035:	je     29fc1df <wasm[0]::function[1015]::helper::object_read+0x1b2bf>
 29ee03b:	mov    0x2e0(%rsp),%r12
 29ee043:	mov    0x28(%r12),%rdi
 29ee048:	mov    0x20(%r12),%r8
 29ee04d:	mov    %ecx,%r10d
 29ee050:	lea    0x10(%r8,%r10,1),%rsi
 29ee055:	xor    %r9,%r9
 29ee058:	cmp    %rdi,%r10
 29ee05b:	cmova  %r9,%rsi
 29ee05f:	mov    (%rsi),%edx
 29ee061:	cmp    %edx,%ebx
 29ee063:	jae    29fc1e1 <wasm[0]::function[1015]::helper::object_read+0x1b2c1>
 29ee069:	mov    %edx,%r10d
 29ee06c:	shl    $0x2,%r10
 29ee070:	shr    $0x20,%r10
 29ee074:	test   %r10,%r10
 29ee077:	jne    29fc1e3 <wasm[0]::function[1015]::helper::object_read+0x1b2c3>
 29ee07d:	shl    $0x2,%edx
 29ee080:	add    $0x14,%edx
 29ee083:	jb     29fc1e5 <wasm[0]::function[1015]::helper::object_read+0x1b2c5>
 29ee089:	add    %edx,%ecx
 29ee08b:	jb     29fc1e7 <wasm[0]::function[1015]::helper::object_read+0x1b2c7>
 29ee091:	mov    %ecx,%ecx
 29ee093:	lea    (%r8,%rcx,1),%r10
 29ee097:	cmp    %rdi,%rcx
 29ee09a:	cmova  %r9,%r10
 29ee09e:	mov    %rbx,%rcx
 29ee0a1:	shl    $0x2,%ecx
 29ee0a4:	add    $0x14,%ecx
 29ee0aa:	sub    %ecx,%edx
 29ee0ac:	sub    %rdx,%r10
 29ee0af:	mov    %eax,(%r10)
 29ee0b2:	mov    0x88(%rsp),%ecx
 29ee0b9:	mov    0x78(%rsp),%edx
 29ee0bd:	mov    0x128(%rsp),%esi
 29ee0c4:	mov    0x90(%rsp),%edi
 29ee0cb:	mov    0xe0(%rsp),%r8d
 29ee0d3:	mov    0x108(%rsp),%r9d
 29ee0db:	mov    0x120(%rsp),%r10d
 29ee0e3:	add    $0x1,%ebx
 29ee0e9:	mov    %r13,0x1f8(%rsp)
 29ee0f1:	jmp    29edd86 <wasm[0]::function[1015]::helper::object_read+0xce66>
 29ee0f6:	mov    0x88(%rsp),%eax
 29ee0fd:	test   %eax,%eax
 29ee0ff:	je     29fc1e9 <wasm[0]::function[1015]::helper::object_read+0x1b2c9>
 29ee105:	mov    0x98(%rsp),%edx
 29ee10c:	test   %edx,%edx
 29ee10e:	je     29fc1eb <wasm[0]::function[1015]::helper::object_read+0x1b2cb>
 29ee114:	test   %eax,%eax
 29ee116:	je     29fc1ed <wasm[0]::function[1015]::helper::object_read+0x1b2cd>
 29ee11c:	mov    0x2e0(%rsp),%r12
 29ee124:	mov    0x28(%r12),%rsi
 29ee129:	mov    0x20(%r12),%rcx
 29ee12e:	mov    %eax,%edi
 29ee130:	add    %rdi,%rcx
 29ee133:	xor    %r8,%r8
 29ee136:	cmp    %rsi,%rdi
 29ee139:	cmova  %r8,%rcx
 29ee13d:	mov    %edx,0x20(%rcx)
 29ee140:	mov    0x190(%rsp),%rdx
 29ee148:	mov    0xa00(%rdx),%esi
 29ee14e:	mov    0xa10(%rdx),%edx
 29ee154:	test   %esi,%esi
 29ee156:	je     29fc1ef <wasm[0]::function[1015]::helper::object_read+0x1b2cf>
 29ee15c:	mov    %esi,0x28(%rcx)
 29ee15f:	test   %edx,%edx
 29ee161:	je     29fc1f1 <wasm[0]::function[1015]::helper::object_read+0x1b2d1>
 29ee167:	mov    %edx,0x2c(%rcx)
 29ee16a:	movl   $0x0,0x30(%rcx)
 29ee171:	movl   $0x0,0x24(%rcx)
 29ee178:	mov    0x78(%rsp),%ecx
 29ee17c:	mov    %rcx,%r15
 29ee17f:	mov    0x128(%rsp),%ecx
 29ee186:	mov    0x90(%rsp),%edx
 29ee18d:	mov    0xe0(%rsp),%edi
 29ee194:	mov    0x108(%rsp),%r8d
 29ee19c:	mov    0x120(%rsp),%esi
 29ee1a3:	jmp    29ee78d <wasm[0]::function[1015]::helper::object_read+0xd86d>
 29ee1a8:	mov    0xa0(%rsp),%edx
 29ee1af:	test   %edx,%edx
 29ee1b1:	je     29fc1f3 <wasm[0]::function[1015]::helper::object_read+0x1b2d3>
 29ee1b7:	test   %edx,%edx
 29ee1b9:	je     29fc1f5 <wasm[0]::function[1015]::helper::object_read+0x1b2d5>
 29ee1bf:	mov    0x2e0(%rsp),%r12
 29ee1c7:	mov    0x28(%r12),%rax
 29ee1cc:	mov    0x20(%r12),%rcx
 29ee1d1:	mov    %edx,%edi
 29ee1d3:	lea    (%rcx,%rdi,1),%rsi
 29ee1d7:	xor    %rdx,%rdx
 29ee1da:	cmp    %rax,%rdi
 29ee1dd:	cmova  %rdx,%rsi
 29ee1e1:	mov    0x30(%rsi),%esi
 29ee1e4:	mov    %esi,0x88(%rsp)
 29ee1eb:	test   %esi,%esi
 29ee1ed:	je     29fc1f7 <wasm[0]::function[1015]::helper::object_read+0x1b2d7>
 29ee1f3:	test   %esi,%esi
 29ee1f5:	je     29fc1f9 <wasm[0]::function[1015]::helper::object_read+0x1b2d9>
 29ee1fb:	mov    %esi,%esi
 29ee1fd:	lea    0x10(%rcx,%rsi,1),%rcx
 29ee202:	cmp    %rax,%rsi
 29ee205:	cmova  %rdx,%rcx
 29ee209:	mov    (%rcx),%eax
 29ee20b:	mov    %eax,%ebx
 29ee20d:	mov    %rbx,%r15
 29ee210:	shl    $0x2,%r15
 29ee214:	mov    $0x20,%ecx
 29ee219:	mov    %rcx,0x1c8(%rsp)
 29ee221:	mov    %r15,%rcx
 29ee224:	shr    $0x20,%rcx
 29ee228:	test   %rcx,%rcx
 29ee22b:	jne    29fc1fb <wasm[0]::function[1015]::helper::object_read+0x1b2db>
 29ee231:	mov    %rax,%rcx
 29ee234:	shl    $0x2,%ecx
 29ee237:	mov    %rax,0x1d0(%rsp)
 29ee23f:	add    $0x14,%ecx
 29ee242:	jb     29fc1fd <wasm[0]::function[1015]::helper::object_read+0x1b2dd>
 29ee248:	mov    0x190(%rsp),%rax
 29ee250:	mov    0x20(%rax),%r14
 29ee254:	mov    (%r14),%eax
 29ee257:	mov    %eax,%edx
 29ee259:	mov    %ecx,%esi
 29ee25b:	add    $0xf,%rsi
 29ee262:	mov    %rsi,%rdi
 29ee265:	and    $0xfffffffffffffff0,%rdi
 29ee269:	add    %rdx,%rdi
 29ee26c:	mov    0x4(%r14),%r8d
 29ee270:	cmp    %r8,%rdi
 29ee273:	ja     29fae86 <wasm[0]::function[1015]::helper::object_read+0x19f66>
 29ee279:	add    $0xf,%ecx
 29ee27f:	and    $0xfffffff0,%ecx
 29ee282:	add    %eax,%ecx
 29ee284:	mov    %ecx,(%r14)
 29ee287:	mov    0x2e0(%rsp),%r12
 29ee28f:	mov    0x20(%r12),%rcx
 29ee294:	lea    (%rcx,%rdx,1),%r8
 29ee298:	movl   $0xa800000e,(%rcx,%rdx,1)
 29ee29f:	mov    0x190(%rsp),%rdi
 29ee2a7:	mov    0x28(%rdi),%rdi
 29ee2ab:	mov    0x194(%rdi),%edi
 29ee2b1:	mov    %edi,0x4(%rcx,%rdx,1)
 29ee2b5:	and    $0xfffffffffffffff0,%rsi
 29ee2b9:	mov    %esi,0x8(%rcx,%rdx,1)
 29ee2bd:	mov    %eax,0x78(%rsp)
 29ee2c1:	mov    0x1d0(%rsp),%rcx
 29ee2c9:	mov    %ecx,0x10(%r8)
 29ee2cd:	test   %eax,%eax
 29ee2cf:	je     29fc1ff <wasm[0]::function[1015]::helper::object_read+0x1b2df>
 29ee2d5:	mov    0x2e0(%rsp),%r12
 29ee2dd:	mov    0x28(%r12),%rcx
 29ee2e2:	mov    0x20(%r12),%rdx
 29ee2e7:	mov    %eax,%eax
 29ee2e9:	lea    (%rdx,%rax,1),%r11
 29ee2ed:	lea    0x10(%rdx,%rax,1),%rsi
 29ee2f2:	xor    %rdi,%rdi
 29ee2f5:	cmp    %rcx,%rax
 29ee2f8:	cmova  %rdi,%rsi
 29ee2fc:	mov    (%rsi),%esi
 29ee2fe:	cmp    %rsi,%rbx
 29ee301:	ja     29fc201 <wasm[0]::function[1015]::helper::object_read+0x1b2e1>
 29ee307:	lea    0x14(%rdx,%rax,1),%r13
 29ee30c:	mov    %r13,%rsi
 29ee30f:	add    %r15,%rsi
 29ee312:	jb     29fc203 <wasm[0]::function[1015]::helper::object_read+0x1b2e3>
 29ee318:	lea    (%rdx,%rcx,1),%rdi
 29ee31c:	cmp    %rdi,%rsi
 29ee31f:	ja     29fc205 <wasm[0]::function[1015]::helper::object_read+0x1b2e5>
 29ee325:	mov    0x88(%rsp),%ecx
 29ee32c:	mov    0xa0(%rsp),%eax
 29ee333:	mov    0x100(%rsp),%edx
 29ee33a:	mov    0xc8(%rsp),%esi
 29ee341:	mov    0xd8(%rsp),%edi
 29ee348:	mov    0x110(%rsp),%r8d
 29ee350:	mov    0x138(%rsp),%r9d
 29ee358:	mov    0x118(%rsp),%r10d
 29ee360:	lea    0x14(%r11,%rbx,4),%r15
 29ee365:	test   %rbx,%rbx
 29ee368:	je     29ee418 <wasm[0]::function[1015]::helper::object_read+0xd4f8>
 29ee36e:	mov    %ecx,0x118(%rsp)
 29ee375:	mov    %eax,0x138(%rsp)
 29ee37c:	mov    %edx,0x110(%rsp)
 29ee383:	mov    %esi,0xd8(%rsp)
 29ee38a:	mov    %edi,0xc8(%rsp)
 29ee391:	mov    %r8d,0x100(%rsp)
 29ee399:	mov    %r9d,0xa0(%rsp)
 29ee3a1:	mov    %r10d,0x88(%rsp)
 29ee3a9:	mov    0x2e8(%rsp),%rax
 29ee3b1:	mov    (%rax),%rax
 29ee3b4:	mov    0x228(%rsp),%rcx
 29ee3bc:	cmp    %rcx,%rax
 29ee3bf:	jae    29faec5 <wasm[0]::function[1015]::helper::object_read+0x19fa5>
 29ee3c5:	movl   $0x0,0x0(%r13)
 29ee3cd:	mov    0x118(%rsp),%ecx
 29ee3d4:	mov    0x138(%rsp),%eax
 29ee3db:	mov    0x110(%rsp),%edx
 29ee3e2:	mov    0xd8(%rsp),%esi
 29ee3e9:	mov    0xc8(%rsp),%edi
 29ee3f0:	mov    0x100(%rsp),%r8d
 29ee3f8:	mov    0xa0(%rsp),%r9d
 29ee400:	mov    0x88(%rsp),%r10d
 29ee408:	add    $0x4,%r13
 29ee40f:	cmp    %r15,%r13
 29ee412:	jne    29ee36e <wasm[0]::function[1015]::helper::object_read+0xd44e>
 29ee418:	mov    %ecx,0x118(%rsp)
 29ee41f:	mov    0x190(%rsp),%rcx
 29ee427:	mov    0xa20(%rcx),%ecx
 29ee42d:	mov    %ecx,0x138(%rsp)
 29ee434:	xor    %r13d,%r13d
 29ee437:	mov    $0xb0000072,%r15d
 29ee43d:	mov    0x190(%rsp),%rcx
 29ee445:	mov    %r15,0x1a0(%rsp)
 29ee44d:	mov    0x28(%rcx),%rcx
 29ee451:	mov    0x13c(%rcx),%ebx
 29ee457:	mov    $0x20,%r15d
 29ee45d:	mov    %r15,0x198(%rsp)
 29ee465:	mov    $0x10,%ecx
 29ee46a:	mov    %rcx,0x2b0(%rsp)
 29ee472:	mov    %eax,0x128(%rsp)
 29ee479:	mov    %edx,0x88(%rsp)
 29ee480:	mov    %esi,0xa0(%rsp)
 29ee487:	mov    %edi,0x100(%rsp)
 29ee48e:	mov    %r8d,0xc8(%rsp)
 29ee496:	mov    %r9d,0xd8(%rsp)
 29ee49e:	mov    %r10d,0x110(%rsp)
 29ee4a6:	mov    0x2e8(%rsp),%rcx
 29ee4ae:	mov    (%rcx),%rax
 29ee4b1:	mov    0x228(%rsp),%r9
 29ee4b9:	cmp    %r9,%rax
 29ee4bc:	jae    29faefd <wasm[0]::function[1015]::helper::object_read+0x19fdd>
 29ee4c2:	mov    0x1d0(%rsp),%rdi
 29ee4ca:	jmp    29ee4d7 <wasm[0]::function[1015]::helper::object_read+0xd5b7>
 29ee4cf:	mov    0x1d0(%rsp),%rdi
 29ee4d7:	cmp    %edi,%r13d
 29ee4da:	jae    29ee6e0 <wasm[0]::function[1015]::helper::object_read+0xd7c0>
 29ee4e0:	mov    0x118(%rsp),%eax
 29ee4e7:	test   %eax,%eax
 29ee4e9:	je     29fc207 <wasm[0]::function[1015]::helper::object_read+0x1b2e7>
 29ee4ef:	test   %eax,%eax
 29ee4f1:	je     29fc209 <wasm[0]::function[1015]::helper::object_read+0x1b2e9>
 29ee4f7:	mov    0x2e0(%rsp),%r12
 29ee4ff:	mov    0x28(%r12),%rcx
 29ee504:	mov    0x20(%r12),%rdx
 29ee509:	mov    %eax,%r8d
 29ee50c:	lea    0x10(%rdx,%r8,1),%rdi
 29ee511:	xor    %rsi,%rsi
 29ee514:	cmp    %rcx,%r8
 29ee517:	cmova  %rsi,%rdi
 29ee51b:	mov    (%rdi),%edi
 29ee51d:	cmp    %edi,%r13d
 29ee520:	jae    29fc20b <wasm[0]::function[1015]::helper::object_read+0x1b2eb>
 29ee526:	mov    %edi,%r8d
 29ee529:	shl    $0x2,%r8
 29ee52d:	shr    $0x20,%r8
 29ee531:	test   %r8,%r8
 29ee534:	jne    29fc20d <wasm[0]::function[1015]::helper::object_read+0x1b2ed>
 29ee53a:	shl    $0x2,%edi
 29ee53d:	add    $0x14,%edi
 29ee540:	jb     29fc20f <wasm[0]::function[1015]::helper::object_read+0x1b2ef>
 29ee546:	add    %edi,%eax
 29ee548:	jb     29fc211 <wasm[0]::function[1015]::helper::object_read+0x1b2f1>
 29ee54e:	mov    %eax,%r8d
 29ee551:	lea    (%rdx,%r8,1),%rax
 29ee555:	cmp    %rcx,%r8
 29ee558:	cmova  %rsi,%rax
 29ee55c:	mov    %r13,%r15
 29ee55f:	shl    $0x2,%r15d
 29ee563:	lea    0x14(%r15),%ecx
 29ee567:	sub    %ecx,%edi
 29ee569:	sub    %rdi,%rax
 29ee56c:	mov    (%rax),%eax
 29ee56e:	mov    %eax,0x90(%rsp)
 29ee575:	test   %eax,%eax
 29ee577:	jne    29ee58a <wasm[0]::function[1015]::helper::object_read+0xd66a>
 29ee57d:	mov    0x1c8(%rsp),%rcx
 29ee585:	jmp    29ee698 <wasm[0]::function[1015]::helper::object_read+0xd778>
 29ee58a:	test   %eax,%eax
 29ee58c:	je     29fc213 <wasm[0]::function[1015]::helper::object_read+0x1b2f3>
 29ee592:	mov    0x138(%rsp),%esi
 29ee599:	test   %esi,%esi
 29ee59b:	je     29fc215 <wasm[0]::function[1015]::helper::object_read+0x1b2f5>
 29ee5a1:	mov    (%r14),%eax
 29ee5a4:	mov    %eax,%esi
 29ee5a6:	lea    0x20(%rsi),%rdi
 29ee5aa:	mov    0x4(%r14),%r8d
 29ee5ae:	cmp    %r8,%rdi
 29ee5b1:	ja     29faf3d <wasm[0]::function[1015]::helper::object_read+0x1a01d>
 29ee5b7:	lea    0x20(%rax),%r8d
 29ee5bb:	mov    %r8d,(%r14)
 29ee5be:	mov    0x2e0(%rsp),%r12
 29ee5c6:	mov    0x20(%r12),%r9
 29ee5cb:	lea    (%r9,%rsi,1),%rdx
 29ee5cf:	movl   $0xb0000072,(%r9,%rsi,1)
 29ee5d7:	mov    %ebx,0x4(%r9,%rsi,1)
 29ee5dc:	mov    0x1c8(%rsp),%rcx
 29ee5e4:	mov    %ecx,0x8(%r9,%rsi,1)
 29ee5e9:	movl   $0xe,0x10(%rdx)
 29ee5f0:	mov    0x90(%rsp),%esi
 29ee5f7:	mov    %esi,0x14(%rdx)
 29ee5fa:	mov    0x138(%rsp),%esi
 29ee601:	mov    %esi,0x18(%rdx)
 29ee604:	mov    %esi,0x1c(%rdx)
 29ee607:	mov    0x78(%rsp),%esi
 29ee60b:	test   %esi,%esi
 29ee60d:	je     29fc217 <wasm[0]::function[1015]::helper::object_read+0x1b2f7>
 29ee613:	test   %eax,%eax
 29ee615:	je     29fc219 <wasm[0]::function[1015]::helper::object_read+0x1b2f9>
 29ee61b:	test   %esi,%esi
 29ee61d:	je     29fc21b <wasm[0]::function[1015]::helper::object_read+0x1b2fb>
 29ee623:	mov    0x2e0(%rsp),%r12
 29ee62b:	mov    0x28(%r12),%rdx
 29ee630:	mov    0x20(%r12),%rdi
 29ee635:	mov    %esi,%r10d
 29ee638:	lea    0x10(%rdi,%r10,1),%r9
 29ee63d:	xor    %r8,%r8
 29ee640:	cmp    %rdx,%r10
 29ee643:	cmova  %r8,%r9
 29ee647:	mov    (%r9),%r9d
 29ee64a:	cmp    %r9d,%r13d
 29ee64d:	jae    29fc21d <wasm[0]::function[1015]::helper::object_read+0x1b2fd>
 29ee653:	mov    %r9d,%r10d
 29ee656:	shl    $0x2,%r10
 29ee65a:	shr    $0x20,%r10
 29ee65e:	test   %r10,%r10
 29ee661:	jne    29fc21f <wasm[0]::function[1015]::helper::object_read+0x1b2ff>
 29ee667:	shl    $0x2,%r9d
 29ee66b:	add    $0x14,%r9d
 29ee66f:	jb     29fc221 <wasm[0]::function[1015]::helper::object_read+0x1b301>
 29ee675:	add    %r9d,%esi
 29ee678:	jb     29fc223 <wasm[0]::function[1015]::helper::object_read+0x1b303>
 29ee67e:	mov    %esi,%r10d
 29ee681:	lea    (%rdi,%r10,1),%rsi
 29ee685:	cmp    %rdx,%r10
 29ee688:	cmova  %r8,%rsi
 29ee68c:	lea    0x14(%r15),%edx
 29ee690:	sub    %edx,%r9d
 29ee693:	sub    %r9,%rsi
 29ee696:	mov    %eax,(%rsi)
 29ee698:	mov    0x128(%rsp),%eax
 29ee69f:	mov    0x88(%rsp),%edx
 29ee6a6:	mov    0xa0(%rsp),%esi
 29ee6ad:	mov    0x100(%rsp),%edi
 29ee6b4:	mov    0xc8(%rsp),%r8d
 29ee6bc:	mov    0xd8(%rsp),%r9d
 29ee6c4:	mov    0x110(%rsp),%r10d
 29ee6cc:	add    $0x1,%r13d
 29ee6d3:	mov    %rcx,0x1c8(%rsp)
 29ee6db:	jmp    29ee472 <wasm[0]::function[1015]::helper::object_read+0xd552>
 29ee6e0:	mov    0x128(%rsp),%eax
 29ee6e7:	test   %eax,%eax
 29ee6e9:	je     29fc225 <wasm[0]::function[1015]::helper::object_read+0x1b305>
 29ee6ef:	mov    0x78(%rsp),%edx
 29ee6f3:	test   %edx,%edx
 29ee6f5:	je     29fc227 <wasm[0]::function[1015]::helper::object_read+0x1b307>
 29ee6fb:	test   %eax,%eax
 29ee6fd:	je     29fc229 <wasm[0]::function[1015]::helper::object_read+0x1b309>
 29ee703:	mov    0x2e0(%rsp),%r12
 29ee70b:	mov    0x28(%r12),%rsi
 29ee710:	mov    0x20(%r12),%rcx
 29ee715:	mov    %eax,%edi
 29ee717:	add    %rdi,%rcx
 29ee71a:	xor    %r8,%r8
 29ee71d:	cmp    %rsi,%rdi
 29ee720:	cmova  %r8,%rcx
 29ee724:	mov    %edx,0x20(%rcx)
 29ee727:	mov    0x190(%rsp),%rdx
 29ee72f:	mov    0xa00(%rdx),%esi
 29ee735:	mov    0xa10(%rdx),%edx
 29ee73b:	test   %esi,%esi
 29ee73d:	je     29fc22b <wasm[0]::function[1015]::helper::object_read+0x1b30b>
 29ee743:	mov    %esi,0x28(%rcx)
 29ee746:	test   %edx,%edx
 29ee748:	je     29fc22d <wasm[0]::function[1015]::helper::object_read+0x1b30d>
 29ee74e:	mov    %edx,0x2c(%rcx)
 29ee751:	movl   $0x0,0x30(%rcx)
 29ee758:	movl   $0x0,0x24(%rcx)
 29ee75f:	mov    0x88(%rsp),%ecx
 29ee766:	mov    %rcx,%r15
 29ee769:	mov    0xa0(%rsp),%ecx
 29ee770:	mov    0x100(%rsp),%edx
 29ee777:	mov    0xc8(%rsp),%edi
 29ee77e:	mov    0xd8(%rsp),%r8d
 29ee786:	mov    0x110(%rsp),%esi
 29ee78d:	test   %eax,%eax
 29ee78f:	je     29fc22f <wasm[0]::function[1015]::helper::object_read+0x1b30f>
 29ee795:	test   %eax,%eax
 29ee797:	je     29fc231 <wasm[0]::function[1015]::helper::object_read+0x1b311>
 29ee79d:	mov    0x2e0(%rsp),%r12
 29ee7a5:	mov    0x28(%r12),%r10
 29ee7aa:	mov    0x20(%r12),%rbx
 29ee7af:	mov    %eax,%eax
 29ee7b1:	lea    (%rbx,%rax,1),%r11
 29ee7b5:	xor    %r12,%r12
 29ee7b8:	cmp    %r10,%rax
 29ee7bb:	cmova  %r12,%r11
 29ee7bf:	mov    0x10(%r11),%r9d
 29ee7c3:	test   %r9d,%r9d
 29ee7c6:	je     29fc233 <wasm[0]::function[1015]::helper::object_read+0x1b313>
 29ee7cc:	test   %r9d,%r9d
 29ee7cf:	je     29fc235 <wasm[0]::function[1015]::helper::object_read+0x1b315>
 29ee7d5:	mov    %r9d,%r13d
 29ee7d8:	lea    0x10(%rbx,%r13,1),%rbx
 29ee7dd:	cmp    %r10,%r13
 29ee7e0:	cmova  %r12,%rbx
 29ee7e4:	mov    (%rbx),%ebx
 29ee7e6:	mov    0x24(%r11),%r10d
 29ee7ea:	test   %r10d,%r10d
 29ee7ed:	je     29eea31 <wasm[0]::function[1015]::helper::object_read+0xdb11>
 29ee7f3:	xor    %eax,%eax
 29ee7f5:	test   %ebx,%ebx
 29ee7f7:	je     29eeb23 <wasm[0]::function[1015]::helper::object_read+0xdc03>
 29ee7fd:	mov    0x2e0(%rsp),%r12
 29ee805:	mov    0x28(%r12),%r10
 29ee80a:	mov    0x20(%r12),%r12
 29ee80f:	lea    0x10(%r12,%r13,1),%rax
 29ee814:	xor    %r11,%r11
 29ee817:	cmp    %r10,%r13
 29ee81a:	cmova  %r11,%rax
 29ee81e:	mov    (%rax),%eax
 29ee820:	mov    0x200(%rsp),%r13
 29ee828:	shr    $0x10,%r13d
 29ee82c:	mov    0x200(%rsp),%r14
 29ee834:	xor    %r13d,%r14d
 29ee837:	imul   $0x7feb352d,%r14d,%r13d
 29ee83e:	mov    %r13,%r14
 29ee841:	shr    $0xf,%r14d
 29ee845:	xor    %r14d,%r13d
 29ee848:	imul   $0x846ca68b,%r13d,%r13d
 29ee84f:	mov    %r13,%r14
 29ee852:	shr    $0x10,%r14d
 29ee856:	xor    %r14d,%r13d
 29ee859:	sub    $0x1,%ebx
 29ee85c:	and    %ebx,%r13d
 29ee85f:	cmp    %eax,%r13d
 29ee862:	jae    29fc237 <wasm[0]::function[1015]::helper::object_read+0x1b317>
 29ee868:	mov    %eax,%r14d
 29ee86b:	shl    $0x2,%r14
 29ee86f:	shr    $0x20,%r14
 29ee873:	test   %r14,%r14
 29ee876:	jne    29fc239 <wasm[0]::function[1015]::helper::object_read+0x1b319>
 29ee87c:	shl    $0x2,%eax
 29ee87f:	add    $0x14,%eax
 29ee882:	jb     29fc23b <wasm[0]::function[1015]::helper::object_read+0x1b31b>
 29ee888:	add    %eax,%r9d
 29ee88b:	jb     29fc23d <wasm[0]::function[1015]::helper::object_read+0x1b31d>
 29ee891:	mov    %r9d,%r14d
 29ee894:	lea    (%r12,%r14,1),%r9
 29ee898:	cmp    %r10,%r14
 29ee89b:	cmova  %r11,%r9
 29ee89f:	shl    $0x2,%r13d
 29ee8a3:	lea    0x14(%r13),%r10d
 29ee8a7:	sub    %r10d,%eax
 29ee8aa:	sub    %rax,%r9
 29ee8ad:	mov    (%r9),%r9d
 29ee8b0:	xor    %r10d,%r10d
 29ee8b3:	mov    0x200(%rsp),%rax
 29ee8bb:	mov    %eax,%r13d
 29ee8be:	mov    %r9d,0x78(%rsp)
 29ee8c3:	mov    %r10d,0x110(%rsp)
 29ee8cb:	mov    %r15,%rax
 29ee8ce:	mov    %eax,0xd8(%rsp)
 29ee8d5:	mov    %ecx,0xc8(%rsp)
 29ee8dc:	mov    %edx,0x100(%rsp)
 29ee8e3:	mov    %edi,0xa0(%rsp)
 29ee8ea:	mov    %r8d,0x88(%rsp)
 29ee8f2:	mov    %esi,0x128(%rsp)
 29ee8f9:	mov    0x2e8(%rsp),%rax
 29ee901:	mov    (%rax),%rax
 29ee904:	mov    0x228(%rsp),%rsi
 29ee90c:	cmp    %rsi,%rax
 29ee90f:	jae    29faf81 <wasm[0]::function[1015]::helper::object_read+0x1a061>
 29ee915:	mov    0x78(%rsp),%ecx
 29ee919:	mov    0x110(%rsp),%eax
 29ee920:	test   %ecx,%ecx
 29ee922:	je     29ee9fe <wasm[0]::function[1015]::helper::object_read+0xdade>
 29ee928:	mov    0x78(%rsp),%ecx
 29ee92c:	test   %ecx,%ecx
 29ee92e:	je     29fc23f <wasm[0]::function[1015]::helper::object_read+0x1b31f>
 29ee934:	mov    0x2e0(%rsp),%r12
 29ee93c:	mov    0x28(%r12),%rax
 29ee941:	mov    %ecx,%edx
 29ee943:	mov    %rdx,%rcx
 29ee946:	add    0x20(%r12),%rcx
 29ee94b:	xor    %rsi,%rsi
 29ee94e:	cmp    %rax,%rdx
 29ee951:	cmova  %rsi,%rcx
 29ee955:	mov    0x10(%rcx),%rax
 29ee959:	cmp    %r13,%rax
 29ee95c:	je     29ee9ce <wasm[0]::function[1015]::helper::object_read+0xdaae>
 29ee962:	mov    0x78(%rsp),%ecx
 29ee966:	test   %ecx,%ecx
 29ee968:	je     29fc241 <wasm[0]::function[1015]::helper::object_read+0x1b321>
 29ee96e:	mov    0x2e0(%rsp),%r12
 29ee976:	mov    0x28(%r12),%rax
 29ee97b:	mov    %ecx,%edx
 29ee97d:	mov    %rdx,%rcx
 29ee980:	add    0x20(%r12),%rcx
 29ee985:	xor    %rsi,%rsi
 29ee988:	cmp    %rax,%rdx
 29ee98b:	cmova  %rsi,%rcx
 29ee98f:	mov    0x1c(%rcx),%r9d
 29ee993:	mov    0x110(%rsp),%r10d
 29ee99b:	mov    0xd8(%rsp),%eax
 29ee9a2:	mov    %rax,%r15
 29ee9a5:	mov    0xc8(%rsp),%ecx
 29ee9ac:	mov    0x100(%rsp),%edx
 29ee9b3:	mov    0xa0(%rsp),%edi
 29ee9ba:	mov    0x88(%rsp),%r8d
 29ee9c2:	mov    0x128(%rsp),%esi
 29ee9c9:	jmp    29ee8be <wasm[0]::function[1015]::helper::object_read+0xd99e>
 29ee9ce:	mov    0x78(%rsp),%ecx
 29ee9d2:	test   %ecx,%ecx
 29ee9d4:	je     29fc243 <wasm[0]::function[1015]::helper::object_read+0x1b323>
 29ee9da:	mov    0x2e0(%rsp),%r12
 29ee9e2:	mov    0x28(%r12),%rax
 29ee9e7:	mov    %ecx,%edx
 29ee9e9:	mov    %rdx,%rcx
 29ee9ec:	add    0x20(%r12),%rcx
 29ee9f1:	xor    %rsi,%rsi
 29ee9f4:	cmp    %rax,%rdx
 29ee9f7:	cmova  %rsi,%rcx
 29ee9fb:	mov    0x18(%rcx),%eax
 29ee9fe:	mov    0xd8(%rsp),%ecx
 29eea05:	mov    %rcx,%r15
 29eea08:	mov    0xc8(%rsp),%ecx
 29eea0f:	mov    0x100(%rsp),%edx
 29eea16:	mov    0xa0(%rsp),%edi
 29eea1d:	mov    0x88(%rsp),%r8d
 29eea25:	mov    0x128(%rsp),%esi
 29eea2c:	jmp    29eeb23 <wasm[0]::function[1015]::helper::object_read+0xdc03>
 29eea31:	mov    0x2e0(%rsp),%r12
 29eea39:	mov    0x28(%r12),%r10
 29eea3e:	mov    0x20(%r12),%rbx
 29eea43:	lea    (%rbx,%rax,1),%r9
 29eea47:	xor    %r11,%r11
 29eea4a:	cmp    %r10,%rax
 29eea4d:	cmova  %r11,%r9
 29eea51:	mov    0x20(%r9),%r9d
 29eea55:	xor    %eax,%eax
 29eea57:	test   %r9d,%r9d
 29eea5a:	je     29fc245 <wasm[0]::function[1015]::helper::object_read+0x1b325>
 29eea60:	test   %r9d,%r9d
 29eea63:	je     29fc247 <wasm[0]::function[1015]::helper::object_read+0x1b327>
 29eea69:	mov    %r9d,%r12d
 29eea6c:	lea    0x10(%rbx,%r12,1),%rbx
 29eea71:	cmp    %r10,%r12
 29eea74:	cmova  %r11,%rbx
 29eea78:	mov    0x200(%rsp),%r10
 29eea80:	mov    %r10d,%r10d
 29eea83:	mov    (%rbx),%r11d
 29eea86:	cmp    %r11,%r10
 29eea89:	jae    29eeb23 <wasm[0]::function[1015]::helper::object_read+0xdc03>
 29eea8f:	mov    0x2e0(%rsp),%rax
 29eea97:	mov    0x28(%rax),%rax
 29eea9b:	mov    0x2e0(%rsp),%r10
 29eeaa3:	mov    0x20(%r10),%rbx
 29eeaa7:	lea    0x10(%rbx,%r12,1),%r11
 29eeaac:	xor    %r10,%r10
 29eeaaf:	cmp    %rax,%r12
 29eeab2:	cmova  %r10,%r11
 29eeab6:	mov    (%r11),%r11d
 29eeab9:	mov    0x200(%rsp),%r12
 29eeac1:	cmp    %r11d,%r12d
 29eeac4:	jae    29fc249 <wasm[0]::function[1015]::helper::object_read+0x1b329>
 29eeaca:	mov    %r11d,%r12d
 29eeacd:	shl    $0x2,%r12
 29eead1:	shr    $0x20,%r12
 29eead5:	test   %r12,%r12
 29eead8:	jne    29fc24b <wasm[0]::function[1015]::helper::object_read+0x1b32b>
 29eeade:	shl    $0x2,%r11d
 29eeae2:	add    $0x14,%r11d
 29eeae6:	jb     29fc24d <wasm[0]::function[1015]::helper::object_read+0x1b32d>
 29eeaec:	add    %r11d,%r9d
 29eeaef:	jb     29fc24f <wasm[0]::function[1015]::helper::object_read+0x1b32f>
 29eeaf5:	mov    %r9d,%r12d
 29eeaf8:	lea    (%rbx,%r12,1),%r9
 29eeafc:	cmp    %rax,%r12
 29eeaff:	cmova  %r10,%r9
 29eeb03:	mov    0x200(%rsp),%rax
 29eeb0b:	shl    $0x2,%eax
 29eeb0e:	mov    %rax,0x200(%rsp)
 29eeb16:	lea    0x14(%rax),%r10d
 29eeb1a:	sub    %r10d,%r11d
 29eeb1d:	sub    %r11,%r9
 29eeb20:	mov    (%r9),%eax
 29eeb23:	mov    %ecx,0x88(%rsp)
 29eeb2a:	mov    %edx,0xa0(%rsp)
 29eeb31:	mov    %edi,0x100(%rsp)
 29eeb38:	mov    %r8d,0xc8(%rsp)
 29eeb40:	mov    %esi,0xd8(%rsp)
 29eeb47:	test   %eax,%eax
 29eeb49:	je     29eee5a <wasm[0]::function[1015]::helper::object_read+0xdf3a>
 29eeb4f:	test   %eax,%eax
 29eeb51:	jne    29eeb5f <wasm[0]::function[1015]::helper::object_read+0xdc3f>
 29eeb57:	xor    %r14d,%r14d
 29eeb5a:	jmp    29eeb98 <wasm[0]::function[1015]::helper::object_read+0xdc78>
 29eeb5f:	test   %eax,%eax
 29eeb61:	je     29fc251 <wasm[0]::function[1015]::helper::object_read+0x1b331>
 29eeb67:	mov    0x2e0(%rsp),%r12
 29eeb6f:	mov    0x28(%r12),%rcx
 29eeb74:	mov    %eax,%esi
 29eeb76:	mov    %rsi,%rdx
 29eeb79:	add    0x20(%r12),%rdx
 29eeb7e:	xor    %rdi,%rdi
 29eeb81:	cmp    %rcx,%rsi
 29eeb84:	cmova  %rdi,%rdx
 29eeb88:	mov    0x10(%rdx),%ecx
 29eeb8b:	test   $0x4,%ecx
 29eeb91:	setne  %cl
 29eeb94:	movzbl %cl,%r14d
 29eeb98:	test   %eax,%eax
 29eeb9a:	jne    29eeba7 <wasm[0]::function[1015]::helper::object_read+0xdc87>
 29eeba0:	xor    %ebx,%ebx
 29eeba2:	jmp    29eebdf <wasm[0]::function[1015]::helper::object_read+0xdcbf>
 29eeba7:	test   %eax,%eax
 29eeba9:	je     29fc253 <wasm[0]::function[1015]::helper::object_read+0x1b333>
 29eebaf:	mov    0x2e0(%rsp),%r12
 29eebb7:	mov    0x28(%r12),%rcx
 29eebbc:	mov    %eax,%esi
 29eebbe:	mov    %rsi,%rdx
 29eebc1:	add    0x20(%r12),%rdx
 29eebc6:	xor    %rdi,%rdi
 29eebc9:	cmp    %rcx,%rsi
 29eebcc:	cmova  %rdi,%rdx
 29eebd0:	mov    0x10(%rdx),%ecx
 29eebd3:	test   $0x8,%ecx
 29eebd9:	setne  %cl
 29eebdc:	movzbl %cl,%ebx
 29eebdf:	test   %eax,%eax
 29eebe1:	jne    29eebef <wasm[0]::function[1015]::helper::object_read+0xdccf>
 29eebe7:	xor    %r13d,%r13d
 29eebea:	jmp    29eec28 <wasm[0]::function[1015]::helper::object_read+0xdd08>
 29eebef:	test   %eax,%eax
 29eebf1:	je     29fc255 <wasm[0]::function[1015]::helper::object_read+0x1b335>
 29eebf7:	mov    0x2e0(%rsp),%r12
 29eebff:	mov    0x28(%r12),%rcx
 29eec04:	mov    %eax,%esi
 29eec06:	mov    %rsi,%rdx
 29eec09:	add    0x20(%r12),%rdx
 29eec0e:	xor    %rdi,%rdi
 29eec11:	cmp    %rcx,%rsi
 29eec14:	cmova  %rdi,%rdx
 29eec18:	mov    0x10(%rdx),%ecx
 29eec1b:	test   $0x2,%ecx
 29eec21:	setne  %cl
 29eec24:	movzbl %cl,%r13d
 29eec28:	test   %eax,%eax
 29eec2a:	je     29fc257 <wasm[0]::function[1015]::helper::object_read+0x1b337>
 29eec30:	mov    0x2e0(%rsp),%r12
 29eec38:	mov    0x28(%r12),%rsi
 29eec3d:	mov    0x20(%r12),%rdx
 29eec42:	mov    %eax,%ecx
 29eec44:	add    %rcx,%rdx
 29eec47:	xor    %rdi,%rdi
 29eec4a:	cmp    %rsi,%rcx
 29eec4d:	cmova  %rdi,%rdx
 29eec51:	mov    0x14(%rdx),%esi
 29eec54:	mov    %esi,0x128(%rsp)
 29eec5b:	mov    0x18(%rdx),%esi
 29eec5e:	mov    %esi,0x78(%rsp)
 29eec62:	mov    0x1c(%rdx),%edx
 29eec65:	mov    %edx,0x110(%rsp)
 29eec6c:	test   %eax,%eax
 29eec6e:	jne    29eec7b <wasm[0]::function[1015]::helper::object_read+0xdd5b>
 29eec74:	xor    %eax,%eax
 29eec76:	jmp    29eeca8 <wasm[0]::function[1015]::helper::object_read+0xdd88>
 29eec7b:	mov    0x2e0(%rsp),%r12
 29eec83:	mov    0x28(%r12),%rdx
 29eec88:	mov    %rcx,%rax
 29eec8b:	add    0x20(%r12),%rax
 29eec90:	xor    %rsi,%rsi
 29eec93:	cmp    %rdx,%rcx
 29eec96:	cmova  %rsi,%rax
 29eec9a:	mov    0x10(%rax),%eax
 29eec9d:	test   $0x1,%eax
 29eeca2:	setne  %al
 29eeca5:	movzbl %al,%eax
 29eeca8:	test   %eax,%eax
 29eecaa:	jne    29eed90 <wasm[0]::function[1015]::helper::object_read+0xde70>
 29eecb0:	mov    0x128(%rsp),%eax
 29eecb7:	test   %eax,%eax
 29eecb9:	je     29fc259 <wasm[0]::function[1015]::helper::object_read+0x1b339>
 29eecbf:	mov    0x78(%rsp),%eax
 29eecc3:	test   %eax,%eax
 29eecc5:	je     29fc25b <wasm[0]::function[1015]::helper::object_read+0x1b33b>
 29eeccb:	mov    0x110(%rsp),%eax
 29eecd2:	test   %eax,%eax
 29eecd4:	je     29fc25d <wasm[0]::function[1015]::helper::object_read+0x1b33d>
 29eecda:	mov    0x190(%rsp),%rcx
 29eece2:	mov    0x20(%rcx),%rax
 29eece6:	mov    (%rax),%ecx
 29eece8:	mov    %rcx,%r15
 29eeceb:	mov    %ecx,%ecx
 29eeced:	mov    $0x20,%edx
 29eecf2:	lea    0x20(%rcx),%rsi
 29eecf6:	mov    0x4(%rax),%edi
 29eecf9:	cmp    %rdi,%rsi
 29eecfc:	ja     29fafbc <wasm[0]::function[1015]::helper::object_read+0x1a09c>
 29eed02:	mov    %r15,%rsi
 29eed05:	add    $0x20,%esi
 29eed0b:	mov    %esi,(%rax)
 29eed0d:	mov    0x2e0(%rsp),%r12
 29eed15:	mov    0x20(%r12),%rsi
 29eed1a:	lea    (%rsi,%rcx,1),%rax
 29eed1e:	movl   $0xb0000072,(%rsi,%rcx,1)
 29eed25:	mov    0x190(%rsp),%rdi
 29eed2d:	mov    0x28(%rdi),%rdi
 29eed31:	mov    0x13c(%rdi),%edi
 29eed37:	mov    %edi,0x4(%rsi,%rcx,1)
 29eed3b:	mov    %edx,0x8(%rsi,%rcx,1)
 29eed3f:	test   %r14d,%r14d
 29eed42:	setne  %sil
 29eed46:	movzbl %sil,%ecx
 29eed4a:	shl    $0x2,%ecx
 29eed4d:	test   %ebx,%ebx
 29eed4f:	setne  %sil
 29eed53:	movzbl %sil,%esi
 29eed57:	shl    $0x3,%esi
 29eed5a:	or     %esi,%ecx
 29eed5c:	test   %r13d,%r13d
 29eed5f:	setne  %sil
 29eed63:	movzbl %sil,%esi
 29eed67:	shl    $1,%esi
 29eed69:	or     %esi,%ecx
 29eed6b:	mov    %ecx,0x10(%rax)
 29eed6e:	mov    0x128(%rsp),%esi
 29eed75:	mov    %esi,0x14(%rax)
 29eed78:	mov    0x78(%rsp),%edi
 29eed7c:	mov    %edi,0x18(%rax)
 29eed7f:	mov    0x110(%rsp),%r8d
 29eed87:	mov    %r8d,0x1c(%rax)
 29eed8b:	jmp    29eee5a <wasm[0]::function[1015]::helper::object_read+0xdf3a>
 29eed90:	mov    0x128(%rsp),%r10d
 29eed98:	test   %r10d,%r10d
 29eed9b:	je     29fc25f <wasm[0]::function[1015]::helper::object_read+0x1b33f>
 29eeda1:	mov    0x78(%rsp),%eax
 29eeda5:	test   %eax,%eax
 29eeda7:	je     29fc261 <wasm[0]::function[1015]::helper::object_read+0x1b341>
 29eedad:	mov    0x110(%rsp),%eax
 29eedb4:	test   %eax,%eax
 29eedb6:	je     29fc263 <wasm[0]::function[1015]::helper::object_read+0x1b343>
 29eedbc:	mov    0x190(%rsp),%rcx
 29eedc4:	mov    0x20(%rcx),%rax
 29eedc8:	mov    (%rax),%ecx
 29eedca:	mov    %rcx,%r15
 29eedcd:	mov    %ecx,%ecx
 29eedcf:	mov    $0x20,%edx
 29eedd4:	lea    0x20(%rcx),%rsi
 29eedd8:	mov    0x4(%rax),%edi
 29eeddb:	cmp    %rdi,%rsi
 29eedde:	ja     29fb002 <wasm[0]::function[1015]::helper::object_read+0x1a0e2>
 29eede4:	mov    %r15,%rsi
 29eede7:	add    $0x20,%esi
 29eeded:	mov    %esi,(%rax)
 29eedef:	mov    0x2e0(%rsp),%r12
 29eedf7:	mov    0x20(%r12),%rsi
 29eedfc:	lea    (%rsi,%rcx,1),%rax
 29eee00:	movl   $0xb0000072,(%rsi,%rcx,1)
 29eee07:	mov    0x190(%rsp),%rdi
 29eee0f:	mov    0x28(%rdi),%rdi
 29eee13:	mov    0x13c(%rdi),%edi
 29eee19:	mov    %edi,0x4(%rsi,%rcx,1)
 29eee1d:	mov    %edx,0x8(%rsi,%rcx,1)
 29eee21:	test   %ebx,%ebx
 29eee23:	setne  %cl
 29eee26:	movzbl %cl,%ecx
 29eee29:	shl    $0x3,%ecx
 29eee2c:	or     $0x1,%ecx
 29eee2f:	test   %r13d,%r13d
 29eee32:	setne  %dl
 29eee35:	movzbl %dl,%edx
 29eee38:	shl    $1,%edx
 29eee3a:	or     %edx,%ecx
 29eee3c:	mov    %ecx,0x10(%rax)
 29eee3f:	mov    0x128(%rsp),%ecx
 29eee46:	mov    %ecx,0x14(%rax)
 29eee49:	mov    0x78(%rsp),%ecx
 29eee4d:	mov    %ecx,0x18(%rax)
 29eee50:	mov    0x110(%rsp),%ecx
 29eee57:	mov    %ecx,0x1c(%rax)
 29eee5a:	mov    0x88(%rsp),%esi
 29eee61:	mov    0xa0(%rsp),%edi
 29eee68:	mov    0x100(%rsp),%r8d
 29eee70:	mov    0xc8(%rsp),%edx
 29eee77:	mov    0xd8(%rsp),%ecx
 29eee7e:	jmp    29ef287 <wasm[0]::function[1015]::helper::object_read+0xe367>
 29eee83:	xor    %edi,%edi
 29eee85:	mov    0x210(%rsp),%rax
 29eee8d:	mov    0x210(%rsp),%rdx
 29eee95:	test   %eax,%edx
 29eee97:	je     29eeef9 <wasm[0]::function[1015]::helper::object_read+0xdfd9>
 29eee9d:	xor    %edi,%edi
 29eee9f:	mov    0x210(%rsp),%rdx
 29eeea7:	test   $0x1,%edx
 29eeead:	jne    29eeef9 <wasm[0]::function[1015]::helper::object_read+0xdfd9>
 29eeeb3:	mov    0x2e0(%rsp),%r12
 29eeebb:	mov    0x28(%r12),%rax
 29eeec0:	mov    0x20(%r12),%rcx
 29eeec5:	mov    0x210(%rsp),%rdx
 29eeecd:	mov    %edx,%edx
 29eeecf:	lea    0x4(%rcx,%rdx,1),%rcx
 29eeed4:	xor    %rsi,%rsi
 29eeed7:	cmp    %rax,%rdx
 29eeeda:	cmova  %rsi,%rcx
 29eeede:	mov    (%rcx),%eax
 29eeee0:	mov    0x190(%rsp),%rcx
 29eeee8:	mov    0x28(%rcx),%rcx
 29eeeec:	cmp    0x138(%rcx),%eax
 29eeef2:	sete   %al
 29eeef5:	rex movzbl %al,%edi
 29eeef9:	test   %edi,%edi
 29eeefb:	je     29fc265 <wasm[0]::function[1015]::helper::object_read+0x1b345>
 29eef01:	mov    0x210(%rsp),%rax
 29eef09:	mov    0x210(%rsp),%rdx
 29eef11:	test   %eax,%edx
 29eef13:	je     29fc267 <wasm[0]::function[1015]::helper::object_read+0x1b347>
 29eef19:	mov    0x1b8(%rsp),%rcx
 29eef21:	mov    0x190(%rsp),%rsi
 29eef29:	mov    0x190(%rsp),%rdi
 29eef31:	mov    0x1c0(%rsp),%r8
 29eef39:	call   29ffc00 <wasm[0]::function[1019]::helper::ordinary_own_descriptor>
 29eef3e:	mov    0xc0(%rsp),%ecx
 29eef45:	mov    %rcx,%r15
 29eef48:	test   %eax,%eax
 29eef4a:	je     29ef269 <wasm[0]::function[1015]::helper::object_read+0xe349>
 29eef50:	test   %eax,%eax
 29eef52:	jne    29eef60 <wasm[0]::function[1015]::helper::object_read+0xe040>
 29eef58:	xor    %r13d,%r13d
 29eef5b:	jmp    29eef99 <wasm[0]::function[1015]::helper::object_read+0xe079>
 29eef60:	test   %eax,%eax
 29eef62:	je     29fc269 <wasm[0]::function[1015]::helper::object_read+0x1b349>
 29eef68:	mov    0x2e0(%rsp),%r12
 29eef70:	mov    0x28(%r12),%rcx
 29eef75:	mov    %eax,%esi
 29eef77:	mov    %rsi,%rdx
 29eef7a:	add    0x20(%r12),%rdx
 29eef7f:	xor    %rdi,%rdi
 29eef82:	cmp    %rcx,%rsi
 29eef85:	cmova  %rdi,%rdx
 29eef89:	mov    0x10(%rdx),%ecx
 29eef8c:	test   $0x4,%ecx
 29eef92:	setne  %cl
 29eef95:	movzbl %cl,%r13d
 29eef99:	test   %eax,%eax
 29eef9b:	jne    29eefa9 <wasm[0]::function[1015]::helper::object_read+0xe089>
 29eefa1:	xor    %r14d,%r14d
 29eefa4:	jmp    29eefe2 <wasm[0]::function[1015]::helper::object_read+0xe0c2>
 29eefa9:	test   %eax,%eax
 29eefab:	je     29fc26b <wasm[0]::function[1015]::helper::object_read+0x1b34b>
 29eefb1:	mov    0x2e0(%rsp),%r12
 29eefb9:	mov    0x28(%r12),%rcx
 29eefbe:	mov    %eax,%esi
 29eefc0:	mov    %rsi,%rdx
 29eefc3:	add    0x20(%r12),%rdx
 29eefc8:	xor    %rdi,%rdi
 29eefcb:	cmp    %rcx,%rsi
 29eefce:	cmova  %rdi,%rdx
 29eefd2:	mov    0x10(%rdx),%ecx
 29eefd5:	test   $0x8,%ecx
 29eefdb:	setne  %dl
 29eefde:	movzbl %dl,%r14d
 29eefe2:	test   %eax,%eax
 29eefe4:	jne    29eeff1 <wasm[0]::function[1015]::helper::object_read+0xe0d1>
 29eefea:	xor    %ebx,%ebx
 29eefec:	jmp    29ef02e <wasm[0]::function[1015]::helper::object_read+0xe10e>
 29eeff1:	test   %eax,%eax
 29eeff3:	je     29fc26d <wasm[0]::function[1015]::helper::object_read+0x1b34d>
 29eeff9:	mov    0x2e0(%rsp),%r12
 29ef001:	mov    0x28(%r12),%r8
 29ef006:	mov    %eax,%r9d
 29ef009:	mov    %r9,%rsi
 29ef00c:	add    0x20(%r12),%rsi
 29ef011:	xor    %r10,%r10
 29ef014:	cmp    %r8,%r9
 29ef017:	cmova  %r10,%rsi
 29ef01b:	mov    0x10(%rsi),%r9d
 29ef01f:	test   $0x2,%r9d
 29ef026:	setne  %r10b
 29ef02a:	movzbl %r10b,%ebx
 29ef02e:	test   %eax,%eax
 29ef030:	je     29fc26f <wasm[0]::function[1015]::helper::object_read+0x1b34f>
 29ef036:	mov    0x2e0(%rsp),%r12
 29ef03e:	mov    0x28(%r12),%rdx
 29ef043:	mov    0x20(%r12),%rsi
 29ef048:	mov    %eax,%ecx
 29ef04a:	lea    (%rsi,%rcx,1),%r10
 29ef04e:	xor    %rsi,%rsi
 29ef051:	cmp    %rdx,%rcx
 29ef054:	cmova  %rsi,%r10
 29ef058:	mov    0x14(%r10),%edx
 29ef05c:	mov    %edx,0xc0(%rsp)
 29ef063:	mov    0x18(%r10),%edx
 29ef067:	mov    %edx,0x88(%rsp)
 29ef06e:	mov    0x1c(%r10),%edx
 29ef072:	mov    %edx,0xa0(%rsp)
 29ef079:	test   %eax,%eax
 29ef07b:	jne    29ef088 <wasm[0]::function[1015]::helper::object_read+0xe168>
 29ef081:	xor    %eax,%eax
 29ef083:	jmp    29ef0b5 <wasm[0]::function[1015]::helper::object_read+0xe195>
 29ef088:	mov    0x2e0(%rsp),%r12
 29ef090:	mov    0x28(%r12),%rdx
 29ef095:	mov    %rcx,%rax
 29ef098:	add    0x20(%r12),%rax
 29ef09d:	xor    %rsi,%rsi
 29ef0a0:	cmp    %rdx,%rcx
 29ef0a3:	cmova  %rsi,%rax
 29ef0a7:	mov    0x10(%rax),%eax
 29ef0aa:	test   $0x1,%eax
 29ef0af:	setne  %al
 29ef0b2:	movzbl %al,%eax
 29ef0b5:	test   %eax,%eax
 29ef0b7:	jne    29ef19b <wasm[0]::function[1015]::helper::object_read+0xe27b>
 29ef0bd:	mov    0xc0(%rsp),%eax
 29ef0c4:	test   %eax,%eax
 29ef0c6:	je     29fc271 <wasm[0]::function[1015]::helper::object_read+0x1b351>
 29ef0cc:	mov    0x88(%rsp),%eax
 29ef0d3:	test   %eax,%eax
 29ef0d5:	je     29fc273 <wasm[0]::function[1015]::helper::object_read+0x1b353>
 29ef0db:	mov    0xa0(%rsp),%eax
 29ef0e2:	test   %eax,%eax
 29ef0e4:	je     29fc275 <wasm[0]::function[1015]::helper::object_read+0x1b355>
 29ef0ea:	mov    0x190(%rsp),%rcx
 29ef0f2:	mov    0x20(%rcx),%rax
 29ef0f6:	mov    (%rax),%ecx
 29ef0f8:	mov    %rcx,%r15
 29ef0fb:	mov    %ecx,%ecx
 29ef0fd:	mov    $0x20,%edx
 29ef102:	lea    0x20(%rcx),%rsi
 29ef106:	mov    0x4(%rax),%edi
 29ef109:	cmp    %rdi,%rsi
 29ef10c:	ja     29fb048 <wasm[0]::function[1015]::helper::object_read+0x1a128>
 29ef112:	mov    %r15,%rsi
 29ef115:	add    $0x20,%esi
 29ef11b:	mov    %esi,(%rax)
 29ef11d:	mov    0x2e0(%rsp),%r12
 29ef125:	mov    0x20(%r12),%rsi
 29ef12a:	lea    (%rsi,%rcx,1),%rax
 29ef12e:	movl   $0xb0000072,(%rsi,%rcx,1)
 29ef135:	mov    0x190(%rsp),%rdi
 29ef13d:	mov    0x28(%rdi),%rdi
 29ef141:	mov    0x13c(%rdi),%edi
 29ef147:	mov    %edi,0x4(%rsi,%rcx,1)
 29ef14b:	mov    %edx,0x8(%rsi,%rcx,1)
 29ef14f:	test   %r13d,%r13d
 29ef152:	setne  %cl
 29ef155:	movzbl %cl,%ecx
 29ef158:	shl    $0x2,%ecx
 29ef15b:	test   %r14d,%r14d
 29ef15e:	setne  %dl
 29ef161:	movzbl %dl,%edx
 29ef164:	shl    $0x3,%edx
 29ef167:	or     %edx,%ecx
 29ef169:	test   %ebx,%ebx
 29ef16b:	setne  %dl
 29ef16e:	movzbl %dl,%edx
 29ef171:	shl    $1,%edx
 29ef173:	or     %edx,%ecx
 29ef175:	mov    %ecx,0x10(%rax)
 29ef178:	mov    0xc0(%rsp),%ecx
 29ef17f:	mov    %ecx,0x14(%rax)
 29ef182:	mov    0x88(%rsp),%ecx
 29ef189:	mov    %ecx,0x18(%rax)
 29ef18c:	mov    0xa0(%rsp),%ecx
 29ef193:	mov    %ecx,0x1c(%rax)
 29ef196:	jmp    29ef269 <wasm[0]::function[1015]::helper::object_read+0xe349>
 29ef19b:	mov    0xc0(%rsp),%eax
 29ef1a2:	test   %eax,%eax
 29ef1a4:	je     29fc277 <wasm[0]::function[1015]::helper::object_read+0x1b357>
 29ef1aa:	mov    0x88(%rsp),%eax
 29ef1b1:	test   %eax,%eax
 29ef1b3:	je     29fc279 <wasm[0]::function[1015]::helper::object_read+0x1b359>
 29ef1b9:	mov    0xa0(%rsp),%eax
 29ef1c0:	test   %eax,%eax
 29ef1c2:	je     29fc27b <wasm[0]::function[1015]::helper::object_read+0x1b35b>
 29ef1c8:	mov    0x190(%rsp),%rcx
 29ef1d0:	mov    0x20(%rcx),%rax
 29ef1d4:	mov    (%rax),%ecx
 29ef1d6:	mov    %rcx,%r15
 29ef1d9:	mov    %ecx,%ecx
 29ef1db:	mov    $0x20,%edx
 29ef1e0:	lea    0x20(%rcx),%rsi
 29ef1e4:	mov    0x4(%rax),%edi
 29ef1e7:	cmp    %rdi,%rsi
 29ef1ea:	ja     29fb08e <wasm[0]::function[1015]::helper::object_read+0x1a16e>
 29ef1f0:	mov    %r15,%rsi
 29ef1f3:	add    $0x20,%esi
 29ef1f9:	mov    %esi,(%rax)
 29ef1fb:	mov    0x2e0(%rsp),%r12
 29ef203:	mov    0x20(%r12),%rsi
 29ef208:	lea    (%rsi,%rcx,1),%rax
 29ef20c:	movl   $0xb0000072,(%rsi,%rcx,1)
 29ef213:	mov    0x190(%rsp),%rdi
 29ef21b:	mov    0x28(%rdi),%rdi
 29ef21f:	mov    0x13c(%rdi),%edi
 29ef225:	mov    %edi,0x4(%rsi,%rcx,1)
 29ef229:	mov    %edx,0x8(%rsi,%rcx,1)
 29ef22d:	test   %r14d,%r14d
 29ef230:	setne  %cl
 29ef233:	movzbl %cl,%ecx
 29ef236:	shl    $0x3,%ecx
 29ef239:	or     $0x1,%ecx
 29ef23c:	test   %ebx,%ebx
 29ef23e:	setne  %dl
 29ef241:	movzbl %dl,%edx
 29ef244:	shl    $1,%edx
 29ef246:	or     %edx,%ecx
 29ef248:	mov    %ecx,0x10(%rax)
 29ef24b:	mov    0xc0(%rsp),%ecx
 29ef252:	mov    %ecx,0x14(%rax)
 29ef255:	mov    0x88(%rsp),%edx
 29ef25c:	mov    %edx,0x18(%rax)
 29ef25f:	mov    0xa0(%rsp),%esi
 29ef266:	mov    %esi,0x1c(%rax)
 29ef269:	mov    0x58(%rsp),%esi
 29ef26d:	mov    0xa8(%rsp),%edi
 29ef274:	mov    0xb8(%rsp),%r8d
 29ef27c:	mov    0x48(%rsp),%edx
 29ef280:	mov    0x80(%rsp),%ecx
 29ef287:	mov    %esi,0x80(%rsp)
 29ef28e:	mov    %edi,0x48(%rsp)
 29ef292:	mov    %r8d,0xb8(%rsp)
 29ef29a:	mov    %edx,0xa8(%rsp)
 29ef2a1:	mov    %ecx,0x58(%rsp)
 29ef2a5:	mov    %r15,%rax
 29ef2a8:	mov    %r15,%rsi
 29ef2ab:	test   %esi,%eax
 29ef2ad:	jne    29ef7ca <wasm[0]::function[1015]::helper::object_read+0xe8aa>
 29ef2b3:	xor    %esi,%esi
 29ef2b5:	test   %edx,%edx
 29ef2b7:	je     29ef309 <wasm[0]::function[1015]::helper::object_read+0xe3e9>
 29ef2bd:	xor    %esi,%esi
 29ef2bf:	test   $0x1,%edx
 29ef2c5:	jne    29ef309 <wasm[0]::function[1015]::helper::object_read+0xe3e9>
 29ef2cb:	mov    0x2e0(%rsp),%r12
 29ef2d3:	mov    0x28(%r12),%rax
 29ef2d8:	mov    0x20(%r12),%rdi
 29ef2dd:	mov    %edx,%esi
 29ef2df:	lea    0x4(%rdi,%rsi,1),%rdx
 29ef2e4:	xor    %rdi,%rdi
 29ef2e7:	cmp    %rax,%rsi
 29ef2ea:	cmova  %rdi,%rdx
 29ef2ee:	mov    (%rdx),%eax
 29ef2f0:	mov    0x190(%rsp),%rdx
 29ef2f8:	mov    0x28(%rdx),%rdx
 29ef2fc:	cmp    0x26c(%rdx),%eax
 29ef302:	sete   %al
 29ef305:	rex movzbl %al,%esi
 29ef309:	xor    %eax,%eax
 29ef30b:	test   %esi,%esi
 29ef30d:	je     29ef44f <wasm[0]::function[1015]::helper::object_read+0xe52f>
 29ef313:	xor    %eax,%eax
 29ef315:	mov    0x1b8(%rsp),%rdx
 29ef31d:	cmp    $0x4,%edx
 29ef320:	jne    29ef44f <wasm[0]::function[1015]::helper::object_read+0xe52f>
 29ef326:	xor    %eax,%eax
 29ef328:	test   %ecx,%ecx
 29ef32a:	je     29ef37b <wasm[0]::function[1015]::helper::object_read+0xe45b>
 29ef330:	xor    %eax,%eax
 29ef332:	test   $0x1,%ecx
 29ef338:	jne    29ef37b <wasm[0]::function[1015]::helper::object_read+0xe45b>
 29ef33e:	mov    0x2e0(%rsp),%r12
 29ef346:	mov    0x28(%r12),%rax
 29ef34b:	mov    0x20(%r12),%rsi
 29ef350:	mov    %ecx,%edx
 29ef352:	lea    0x4(%rsi,%rdx,1),%rcx
 29ef357:	xor    %rsi,%rsi
 29ef35a:	cmp    %rax,%rdx
 29ef35d:	cmova  %rsi,%rcx
 29ef361:	mov    (%rcx),%eax
 29ef363:	mov    0x190(%rsp),%rcx
 29ef36b:	mov    0x28(%rcx),%rcx
 29ef36f:	cmp    0x234(%rcx),%eax
 29ef375:	sete   %al
 29ef378:	movzbl %al,%eax
 29ef37b:	test   %eax,%eax
 29ef37d:	je     29fc27d <wasm[0]::function[1015]::helper::object_read+0x1b35d>
 29ef383:	mov    $0xb,%edx
 29ef388:	mov    0x190(%rsp),%rsi
 29ef390:	mov    0x190(%rsp),%rdi
 29ef398:	call   2f307a0 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 29ef39d:	mov    0x58(%rsp),%edx
 29ef3a1:	xor    %r8d,%r8d
 29ef3a4:	test   %edx,%edx
 29ef3a6:	je     29fc27f <wasm[0]::function[1015]::helper::object_read+0x1b35f>
 29ef3ac:	test   %eax,%eax
 29ef3ae:	je     29fc281 <wasm[0]::function[1015]::helper::object_read+0x1b361>
 29ef3b4:	mov    %rax,%rcx
 29ef3b7:	mov    0x190(%rsp),%rsi
 29ef3bf:	mov    0x190(%rsp),%rdi
 29ef3c7:	call   2ae54e0 <wasm[0]::function[1057]::helper::string_equality>
 29ef3cc:	test   %eax,%eax
 29ef3ce:	jne    29ef447 <wasm[0]::function[1015]::helper::object_read+0xe527>
 29ef3d4:	mov    0x58(%rsp),%edx
 29ef3d8:	xor    %r8d,%r8d
 29ef3db:	mov    %r8,%rbx
 29ef3de:	test   %edx,%edx
 29ef3e0:	je     29fc283 <wasm[0]::function[1015]::helper::object_read+0x1b363>
 29ef3e6:	mov    0x190(%rsp),%rsi
 29ef3ee:	mov    0x190(%rsp),%rdi
 29ef3f6:	call   2aec940 <wasm[0]::function[1060]::helper::string_to_number>
 29ef3fb:	mov    %rax,%rdx
 29ef3fe:	mov    0x190(%rsp),%rsi
 29ef406:	mov    0x190(%rsp),%rdi
 29ef40e:	call   2ae5d60 <wasm[0]::function[1059]::helper::number_to_string>
 29ef413:	mov    0x58(%rsp),%edx
 29ef417:	test   %edx,%edx
 29ef419:	je     29fc285 <wasm[0]::function[1015]::helper::object_read+0x1b365>
 29ef41f:	test   %eax,%eax
 29ef421:	je     29fc287 <wasm[0]::function[1015]::helper::object_read+0x1b367>
 29ef427:	mov    %rax,%rcx
 29ef42a:	mov    %rbx,%r8
 29ef42d:	mov    0x190(%rsp),%rsi
 29ef435:	mov    0x190(%rsp),%rdi
 29ef43d:	call   2ae54e0 <wasm[0]::function[1057]::helper::string_equality>
 29ef442:	jmp    29ef44f <wasm[0]::function[1015]::helper::object_read+0xe52f>
 29ef447:	mov    0x278(%rsp),%rax
 29ef44f:	test   %eax,%eax
 29ef451:	jne    29ef782 <wasm[0]::function[1015]::helper::object_read+0xe862>
 29ef457:	mov    0xa8(%rsp),%r8d
 29ef45f:	mov    0x2d8(%rsp),%rcx
 29ef467:	mov    0x2d0(%rsp),%rdx
 29ef46f:	mov    0x190(%rsp),%rsi
 29ef477:	mov    0x190(%rsp),%rdi
 29ef47f:	call   2a5f620 <wasm[0]::function[1039]::helper::object_header_projection>
 29ef484:	xor    %ecx,%ecx
 29ef486:	test   %eax,%eax
 29ef488:	je     29fc289 <wasm[0]::function[1015]::helper::object_read+0x1b369>
 29ef48e:	test   %eax,%eax
 29ef490:	je     29fc28b <wasm[0]::function[1015]::helper::object_read+0x1b36b>
 29ef496:	mov    0x2e0(%rsp),%r12
 29ef49e:	mov    0x28(%r12),%rdx
 29ef4a3:	mov    0x20(%r12),%rdi
 29ef4a8:	mov    %eax,%esi
 29ef4aa:	lea    (%rdi,%rsi,1),%rax
 29ef4ae:	xor    %rdi,%rdi
 29ef4b1:	cmp    %rdx,%rsi
 29ef4b4:	cmova  %rdi,%rax
 29ef4b8:	mov    0x10(%rax),%r8d
 29ef4bc:	test   %r8d,%r8d
 29ef4bf:	jne    29ef4d5 <wasm[0]::function[1015]::helper::object_read+0xe5b5>
 29ef4c5:	mov    0x278(%rsp),%rdx
 29ef4cd:	mov    %rcx,%r8
 29ef4d0:	jmp    29ef6a2 <wasm[0]::function[1015]::helper::object_read+0xe782>
 29ef4d5:	xor    %eax,%eax
 29ef4d7:	test   %r8d,%r8d
 29ef4da:	je     29ef531 <wasm[0]::function[1015]::helper::object_read+0xe611>
 29ef4e0:	xor    %eax,%eax
 29ef4e2:	test   $0x1,%r8d
 29ef4e9:	jne    29ef531 <wasm[0]::function[1015]::helper::object_read+0xe611>
 29ef4ef:	mov    0x2e0(%rsp),%r12
 29ef4f7:	mov    0x28(%r12),%r9
 29ef4fc:	mov    0x20(%r12),%r11
 29ef501:	mov    %r8d,%r10d
 29ef504:	lea    0x4(%r11,%r10,1),%rsi
 29ef509:	xor    %r11,%r11
 29ef50c:	cmp    %r9,%r10
 29ef50f:	cmova  %r11,%rsi
 29ef513:	mov    (%rsi),%r10d
 29ef516:	mov    0x190(%rsp),%rcx
 29ef51e:	mov    0x28(%rcx),%r11
 29ef522:	cmp    0x1d4(%r11),%r10d
 29ef529:	sete   %r11b
 29ef52d:	movzbl %r11b,%eax
 29ef531:	mov    $0x6,%edx
 29ef536:	mov    %rdx,0x278(%rsp)
 29ef53e:	test   %eax,%eax
 29ef540:	je     29ef553 <wasm[0]::function[1015]::helper::object_read+0xe633>
 29ef546:	mov    $0x8,%edx
 29ef54b:	mov    %rdx,0x278(%rsp)
 29ef553:	xor    %eax,%eax
 29ef555:	test   %r8d,%r8d
 29ef558:	je     29ef5ab <wasm[0]::function[1015]::helper::object_read+0xe68b>
 29ef55e:	xor    %eax,%eax
 29ef560:	test   $0x1,%r8d
 29ef567:	jne    29ef5ab <wasm[0]::function[1015]::helper::object_read+0xe68b>
 29ef56d:	mov    0x2e0(%rsp),%r12
 29ef575:	mov    0x28(%r12),%rax
 29ef57a:	mov    0x20(%r12),%rcx
 29ef57f:	mov    %r8d,%edx
 29ef582:	lea    0x4(%rcx,%rdx,1),%rcx
 29ef587:	xor    %rsi,%rsi
 29ef58a:	cmp    %rax,%rdx
 29ef58d:	cmova  %rsi,%rcx
 29ef591:	mov    (%rcx),%eax
 29ef593:	mov    0x190(%rsp),%rcx
 29ef59b:	mov    0x28(%rcx),%rcx
 29ef59f:	cmp    0x1e4(%rcx),%eax
 29ef5a5:	sete   %al
 29ef5a8:	movzbl %al,%eax
 29ef5ab:	test   %eax,%eax
 29ef5ad:	je     29ef5c0 <wasm[0]::function[1015]::helper::object_read+0xe6a0>
 29ef5b3:	mov    $0x8,%edx
 29ef5b8:	mov    %rdx,0x278(%rsp)
 29ef5c0:	xor    %eax,%eax
 29ef5c2:	test   %r8d,%r8d
 29ef5c5:	je     29ef618 <wasm[0]::function[1015]::helper::object_read+0xe6f8>
 29ef5cb:	xor    %eax,%eax
 29ef5cd:	test   $0x1,%r8d
 29ef5d4:	jne    29ef618 <wasm[0]::function[1015]::helper::object_read+0xe6f8>
 29ef5da:	mov    0x2e0(%rsp),%r12
 29ef5e2:	mov    0x28(%r12),%rax
 29ef5e7:	mov    0x20(%r12),%rcx
 29ef5ec:	mov    %r8d,%edx
 29ef5ef:	lea    0x4(%rcx,%rdx,1),%rcx
 29ef5f4:	xor    %rsi,%rsi
 29ef5f7:	cmp    %rax,%rdx
 29ef5fa:	cmova  %rsi,%rcx
 29ef5fe:	mov    (%rcx),%eax
 29ef600:	mov    0x190(%rsp),%rcx
 29ef608:	mov    0x28(%rcx),%rcx
 29ef60c:	cmp    0x1f0(%rcx),%eax
 29ef612:	sete   %al
 29ef615:	movzbl %al,%eax
 29ef618:	test   %eax,%eax
 29ef61a:	je     29ef62d <wasm[0]::function[1015]::helper::object_read+0xe70d>
 29ef620:	mov    $0x9,%edx
 29ef625:	mov    %rdx,0x278(%rsp)
 29ef62d:	xor    %eax,%eax
 29ef62f:	test   %r8d,%r8d
 29ef632:	je     29ef685 <wasm[0]::function[1015]::helper::object_read+0xe765>
 29ef638:	xor    %eax,%eax
 29ef63a:	test   $0x1,%r8d
 29ef641:	jne    29ef685 <wasm[0]::function[1015]::helper::object_read+0xe765>
 29ef647:	mov    0x2e0(%rsp),%r12
 29ef64f:	mov    0x28(%r12),%rax
 29ef654:	mov    0x20(%r12),%rcx
 29ef659:	mov    %r8d,%edx
 29ef65c:	lea    0x4(%rcx,%rdx,1),%rcx
 29ef661:	xor    %rsi,%rsi
 29ef664:	cmp    %rax,%rdx
 29ef667:	cmova  %rsi,%rcx
 29ef66b:	mov    (%rcx),%eax
 29ef66d:	mov    0x190(%rsp),%rcx
 29ef675:	mov    0x28(%rcx),%rcx
 29ef679:	cmp    0x254(%rcx),%eax
 29ef67f:	sete   %al
 29ef682:	movzbl %al,%eax
 29ef685:	test   %eax,%eax
 29ef687:	je     29ef69a <wasm[0]::function[1015]::helper::object_read+0xe77a>
 29ef68d:	mov    $0x7,%edx
 29ef692:	mov    %rdx,0x278(%rsp)
 29ef69a:	mov    0x278(%rsp),%rdx
 29ef6a2:	cmp    $0x1,%edx
 29ef6a5:	je     29ef73a <wasm[0]::function[1015]::helper::object_read+0xe81a>
 29ef6ab:	mov    0xb8(%rsp),%eax
 29ef6b2:	test   %eax,%eax
 29ef6b4:	je     29fc28d <wasm[0]::function[1015]::helper::object_read+0x1b36d>
 29ef6ba:	mov    0x80(%rsp),%edi
 29ef6c1:	mov    0x58(%rsp),%edx
 29ef6c5:	mov    0x48(%rsp),%esi
 29ef6c9:	xor    %rcx,%rcx
 29ef6cc:	mov    0x1b0(%rsp),%r12
 29ef6d4:	mov    %r12,(%rsp)
 29ef6d8:	mov    %edi,0x8(%rsp)
 29ef6dc:	mov    0x1b8(%rsp),%rdi
 29ef6e4:	mov    %edi,0x10(%rsp)
 29ef6e8:	mov    0x1c0(%rsp),%rdi
 29ef6f0:	mov    %rdi,0x18(%rsp)
 29ef6f5:	mov    %edx,0x20(%rsp)
 29ef6f9:	mov    %esi,0x28(%rsp)
 29ef6fd:	mov    %eax,0x30(%rsp)
 29ef701:	mov    0x278(%rsp),%rdx
 29ef709:	mov    0x190(%rsp),%rsi
 29ef711:	mov    0x1a8(%rsp),%r9
 29ef719:	mov    %rsi,%rdi
 29ef71c:	call   29e0f20 <wasm[0]::function[1015]::helper::object_read>
 29ef721:	sub    $0x40,%rsp
 29ef725:	mov    %rax,0x280(%rsp)
 29ef72d:	mov    %rcx,0x288(%rsp)
 29ef735:	jmp    29efba2 <wasm[0]::function[1015]::helper::object_read+0xec82>
 29ef73a:	mov    %rax,%rcx
 29ef73d:	mov    %rax,0x280(%rsp)
 29ef745:	xor    %ecx,%eax
 29ef747:	mov    %rax,0x280(%rsp)
 29ef74f:	mov    %rcx,%rax
 29ef752:	mov    %rcx,0x288(%rsp)
 29ef75a:	xor    %rax,%rcx
 29ef75d:	mov    %rcx,0x288(%rsp)
 29ef765:	mov    0x280(%rsp),%rdx
 29ef76d:	mov    0x280(%rsp),%rsi
 29ef775:	mov    0x280(%rsp),%rdi
 29ef77d:	jmp    29efba2 <wasm[0]::function[1015]::helper::object_read+0xec82>
 29ef782:	mov    %rax,%rcx
 29ef785:	mov    %rax,0x280(%rsp)
 29ef78d:	xor    %ecx,%eax
 29ef78f:	mov    %rax,0x280(%rsp)
 29ef797:	mov    %rcx,%rax
 29ef79a:	mov    %rcx,0x288(%rsp)
 29ef7a2:	xor    %rax,%rcx
 29ef7a5:	mov    %rcx,0x288(%rsp)
 29ef7ad:	mov    0x280(%rsp),%rdx
 29ef7b5:	mov    0x280(%rsp),%rsi
 29ef7bd:	mov    0x280(%rsp),%rdi
 29ef7c5:	jmp    29efba2 <wasm[0]::function[1015]::helper::object_read+0xec82>
 29ef7ca:	mov    %r15,%rax
 29ef7cd:	mov    %r15,%rcx
 29ef7d0:	mov    0x1a8(%rsp),%r9
 29ef7d8:	mov    0x1b0(%rsp),%r12
 29ef7e0:	test   %ecx,%eax
 29ef7e2:	jne    29ef7f0 <wasm[0]::function[1015]::helper::object_read+0xe8d0>
 29ef7e8:	xor    %r8d,%r8d
 29ef7eb:	jmp    29ef83b <wasm[0]::function[1015]::helper::object_read+0xe91b>
 29ef7f0:	mov    %r15,%rax
 29ef7f3:	mov    %r15,%rcx
 29ef7f6:	test   %ecx,%eax
 29ef7f8:	je     29fc28f <wasm[0]::function[1015]::helper::object_read+0x1b36f>
 29ef7fe:	mov    0x2e0(%rsp),%rax
 29ef806:	mov    0x28(%rax),%r10
 29ef80a:	mov    %r15,%rax
 29ef80d:	mov    %eax,%r11d
 29ef810:	mov    0x2e0(%rsp),%rax
 29ef818:	mov    %r11,%rdi
 29ef81b:	add    0x20(%rax),%rdi
 29ef81f:	xor    %rax,%rax
 29ef822:	cmp    %r10,%r11
 29ef825:	cmova  %rax,%rdi
 29ef829:	mov    0x10(%rdi),%r11d
 29ef82d:	test   $0x1,%r11d
 29ef834:	setne  %al
 29ef837:	movzbl %al,%r8d
 29ef83b:	test   %r8d,%r8d
 29ef83e:	jne    29efa1b <wasm[0]::function[1015]::helper::object_read+0xeafb>
 29ef844:	mov    %rax,%rcx
 29ef847:	mov    %rax,0x280(%rsp)
 29ef84f:	xor    %ecx,%eax
 29ef851:	mov    %rax,0x280(%rsp)
 29ef859:	mov    %rcx,%rax
 29ef85c:	mov    %rcx,0x288(%rsp)
 29ef864:	xor    %rax,%rcx
 29ef867:	mov    %rcx,0x288(%rsp)
 29ef86f:	mov    %r15,%rcx
 29ef872:	mov    %r15,%rax
 29ef875:	test   %ecx,%eax
 29ef877:	jne    29ef88a <wasm[0]::function[1015]::helper::object_read+0xe96a>
 29ef87d:	mov    0x280(%rsp),%rdx
 29ef885:	jmp    29efa11 <wasm[0]::function[1015]::helper::object_read+0xeaf1>
 29ef88a:	mov    %r15,%rax
 29ef88d:	mov    %r15,%rcx
 29ef890:	test   %ecx,%eax
 29ef892:	je     29fc291 <wasm[0]::function[1015]::helper::object_read+0x1b371>
 29ef898:	mov    0x2e0(%rsp),%r12
 29ef8a0:	mov    0x28(%r12),%rax
 29ef8a5:	mov    0x20(%r12),%rcx
 29ef8aa:	mov    %r15,%rdx
 29ef8ad:	mov    %edx,%edx
 29ef8af:	add    %rdx,%rcx
 29ef8b2:	xor    %rsi,%rsi
 29ef8b5:	cmp    %rax,%rdx
 29ef8b8:	cmova  %rsi,%rcx
 29ef8bc:	mov    0x14(%rcx),%edx
 29ef8bf:	test   %edx,%edx
 29ef8c1:	je     29fc293 <wasm[0]::function[1015]::helper::object_read+0x1b373>
 29ef8c7:	xor    %eax,%eax
 29ef8c9:	test   $0x1,%edx
 29ef8cf:	jne    29ef912 <wasm[0]::function[1015]::helper::object_read+0xe9f2>
 29ef8d5:	mov    0x2e0(%rsp),%r12
 29ef8dd:	mov    0x28(%r12),%rax
 29ef8e2:	mov    0x20(%r12),%rcx
 29ef8e7:	mov    %edx,%esi
 29ef8e9:	lea    0x4(%rcx,%rsi,1),%rcx
 29ef8ee:	xor    %rdi,%rdi
 29ef8f1:	cmp    %rax,%rsi
 29ef8f4:	cmova  %rdi,%rcx
 29ef8f8:	mov    (%rcx),%eax
 29ef8fa:	mov    0x190(%rsp),%rsi
 29ef902:	mov    0x28(%rsi),%rcx
 29ef906:	cmp    0x120(%rcx),%eax
 29ef90c:	sete   %al
 29ef90f:	movzbl %al,%eax
 29ef912:	test   %eax,%eax
 29ef914:	jne    29ef97b <wasm[0]::function[1015]::helper::object_read+0xea5b>
 29ef91a:	mov    0x190(%rsp),%rsi
 29ef922:	mov    %rsi,%rdi
 29ef925:	call   2a01ba0 <wasm[0]::function[1024]::helper::property_value_resolve>
 29ef92a:	test   %eax,%eax
 29ef92c:	je     29fc295 <wasm[0]::function[1015]::helper::object_read+0x1b375>
 29ef932:	test   %eax,%eax
 29ef934:	je     29fc297 <wasm[0]::function[1015]::helper::object_read+0x1b377>
 29ef93a:	mov    0x2e0(%rsp),%r12
 29ef942:	mov    0x28(%r12),%rcx
 29ef947:	mov    0x20(%r12),%rsi
 29ef94c:	mov    %eax,%edx
 29ef94e:	lea    (%rsi,%rdx,1),%rax
 29ef952:	xor    %rsi,%rsi
 29ef955:	cmp    %rcx,%rdx
 29ef958:	cmova  %rsi,%rax
 29ef95c:	mov    0x18(%rax),%edi
 29ef95f:	mov    %rdi,0x280(%rsp)
 29ef967:	mov    0x10(%rax),%rcx
 29ef96b:	mov    %rcx,0x288(%rsp)
 29ef973:	mov    0x1c(%rax),%edx
 29ef976:	jmp    29efa11 <wasm[0]::function[1015]::helper::object_read+0xeaf1>
 29ef97b:	xor    %eax,%eax
 29ef97d:	test   $0x1,%edx
 29ef983:	jne    29ef9c6 <wasm[0]::function[1015]::helper::object_read+0xeaa6>
 29ef989:	mov    0x2e0(%rsp),%r12
 29ef991:	mov    0x28(%r12),%rax
 29ef996:	mov    0x20(%r12),%rcx
 29ef99b:	mov    %edx,%esi
 29ef99d:	lea    0x4(%rcx,%rsi,1),%rcx
 29ef9a2:	xor    %rdi,%rdi
 29ef9a5:	cmp    %rax,%rsi
 29ef9a8:	cmova  %rdi,%rcx
 29ef9ac:	mov    (%rcx),%eax
 29ef9ae:	mov    0x190(%rsp),%rsi
 29ef9b6:	mov    0x28(%rsi),%rcx
 29ef9ba:	cmp    0x120(%rcx),%eax
 29ef9c0:	sete   %al
 29ef9c3:	movzbl %al,%eax
 29ef9c6:	test   %eax,%eax
 29ef9c8:	je     29fc299 <wasm[0]::function[1015]::helper::object_read+0x1b379>
 29ef9ce:	test   %edx,%edx
 29ef9d0:	je     29fc29b <wasm[0]::function[1015]::helper::object_read+0x1b37b>
 29ef9d6:	mov    0x2e0(%rsp),%r12
 29ef9de:	mov    0x28(%r12),%rcx
 29ef9e3:	mov    0x20(%r12),%rax
 29ef9e8:	mov    %edx,%edx
 29ef9ea:	add    %rdx,%rax
 29ef9ed:	xor    %rsi,%rsi
 29ef9f0:	cmp    %rcx,%rdx
 29ef9f3:	cmova  %rsi,%rax
 29ef9f7:	mov    0x18(%rax),%ecx
 29ef9fa:	mov    %rcx,0x280(%rsp)
 29efa02:	mov    0x10(%rax),%rcx
 29efa06:	mov    %rcx,0x288(%rsp)
 29efa0e:	mov    0x1c(%rax),%edx
 29efa11:	xor    %esi,%esi
 29efa13:	mov    %rsi,%rdi
 29efa16:	jmp    29efba2 <wasm[0]::function[1015]::helper::object_read+0xec82>
 29efa1b:	xor    %edx,%edx
 29efa1d:	xor    %rcx,%rcx
 29efa20:	mov    %r15,%rax
 29efa23:	mov    %r15,%rsi
 29efa26:	test   %esi,%eax
 29efa28:	jne    29efa36 <wasm[0]::function[1015]::helper::object_read+0xeb16>
 29efa2e:	mov    %rdx,%r8
 29efa31:	jmp    29efa9a <wasm[0]::function[1015]::helper::object_read+0xeb7a>
 29efa36:	mov    %r15,%rax
 29efa39:	mov    %r15,%rcx
 29efa3c:	test   %ecx,%eax
 29efa3e:	je     29fc29d <wasm[0]::function[1015]::helper::object_read+0x1b37d>
 29efa44:	mov    0x2e0(%rsp),%rax
 29efa4c:	mov    0x28(%rax),%rax
 29efa50:	mov    0x2e0(%rsp),%rcx
 29efa58:	mov    0x20(%rcx),%rcx
 29efa5c:	mov    %r15,%rsi
 29efa5f:	mov    %esi,%edi
 29efa61:	lea    (%rcx,%rdi,1),%rsi
 29efa65:	xor    %rdx,%rdx
 29efa68:	cmp    %rax,%rdi
 29efa6b:	cmova  %rdx,%rsi
 29efa6f:	mov    0x18(%rsi),%esi
 29efa72:	test   %esi,%esi
 29efa74:	je     29fc29f <wasm[0]::function[1015]::helper::object_read+0x1b37f>
 29efa7a:	test   %esi,%esi
 29efa7c:	je     29fc2a1 <wasm[0]::function[1015]::helper::object_read+0x1b381>
 29efa82:	mov    %esi,%edi
 29efa84:	lea    (%rcx,%rdi,1),%rsi
 29efa88:	cmp    %rax,%rdi
 29efa8b:	cmova  %rdx,%rsi
 29efa8f:	mov    0x18(%rsi),%edx
 29efa92:	mov    0x10(%rsi),%rcx
 29efa96:	mov    0x1c(%rsi),%r8d
 29efa9a:	test   %edx,%edx
 29efa9c:	je     29efb5f <wasm[0]::function[1015]::helper::object_read+0xec3f>
 29efaa2:	mov    0x190(%rsp),%rsi
 29efaaa:	mov    0x9a0(%rsi),%esi
 29efab0:	mov    0x190(%rsp),%rax
 29efab8:	mov    0x8c0(%rax),%edi
 29efabe:	mov    %edi,0x58(%rsp)
 29efac2:	test   %edi,%edi
 29efac4:	je     29fc2a3 <wasm[0]::function[1015]::helper::object_read+0x1b383>
 29efaca:	test   %esi,%esi
 29efacc:	je     29fc2a5 <wasm[0]::function[1015]::helper::object_read+0x1b385>
 29efad2:	mov    0xb8(%rsp),%r10d
 29efada:	test   %r10d,%r10d
 29efadd:	je     29fc2a7 <wasm[0]::function[1015]::helper::object_read+0x1b387>
 29efae3:	mov    0x80(%rsp),%eax
 29efaea:	mov    0x48(%rsp),%r11d
 29efaef:	mov    %r12,(%rsp)
 29efaf3:	mov    %eax,0x8(%rsp)
 29efaf7:	mov    %esi,0x10(%rsp)
 29efafb:	mov    %edi,0x18(%rsp)
 29efaff:	mov    %r11d,0x20(%rsp)
 29efb04:	mov    %r10d,0x28(%rsp)
 29efb09:	mov    0x190(%rsp),%rsi
 29efb11:	mov    0x190(%rsp),%rdi
 29efb19:	call   2adef00 <wasm[0]::function[1055]::helper::proxy_call>
 29efb1e:	sub    $0x30,%rsp
 29efb22:	mov    %rax,0x280(%rsp)
 29efb2a:	mov    %rcx,0x288(%rsp)
 29efb32:	mov    0x58(%rsp),%eax
 29efb36:	test   %eax,%eax
 29efb38:	je     29fc2a9 <wasm[0]::function[1015]::helper::object_read+0x1b389>
 29efb3e:	mov    0x190(%rsp),%rcx
 29efb46:	mov    %eax,0x8c0(%rcx)
 29efb4c:	cmp    $0x2,%esi
 29efb4f:	jne    29efba2 <wasm[0]::function[1015]::helper::object_read+0xec82>
 29efb55:	xor    %esi,%esi
 29efb57:	mov    %rsi,%rdi
 29efb5a:	jmp    29efba2 <wasm[0]::function[1015]::helper::object_read+0xec82>
 29efb5f:	mov    %rax,%rcx
 29efb62:	mov    %rax,0x280(%rsp)
 29efb6a:	xor    %ecx,%eax
 29efb6c:	mov    %rax,0x280(%rsp)
 29efb74:	mov    %rcx,%rax
 29efb77:	mov    %rcx,0x288(%rsp)
 29efb7f:	xor    %rax,%rcx
 29efb82:	mov    %rcx,0x288(%rsp)
 29efb8a:	mov    0x280(%rsp),%rdx
 29efb92:	mov    0x280(%rsp),%rsi
 29efb9a:	mov    0x280(%rsp),%rdi
 29efba2:	mov    %rdx,%rax
 29efba5:	mov    %rdi,0x298(%rsp)
 29efbad:	jmp    29fa43a <wasm[0]::function[1015]::helper::object_read+0x1951a>
 29efbb2:	mov    0x1b0(%rsp),%r12
 29efbba:	xor    %eax,%eax
 29efbbc:	test   %edx,%edx
 29efbbe:	je     29efc15 <wasm[0]::function[1015]::helper::object_read+0xecf5>
 29efbc4:	xor    %eax,%eax
 29efbc6:	test   $0x1,%edx
 29efbcc:	jne    29efc15 <wasm[0]::function[1015]::helper::object_read+0xecf5>
 29efbd2:	mov    0x2e0(%rsp),%rax
 29efbda:	mov    0x28(%rax),%rax
 29efbde:	mov    0x2e0(%rsp),%rcx
 29efbe6:	mov    0x20(%rcx),%rcx
 29efbea:	mov    %edx,%esi
 29efbec:	lea    0x4(%rcx,%rsi,1),%rcx
 29efbf1:	xor    %rdi,%rdi
 29efbf4:	cmp    %rax,%rsi
 29efbf7:	cmova  %rdi,%rcx
 29efbfb:	mov    (%rcx),%eax
 29efbfd:	mov    0x190(%rsp),%rsi
 29efc05:	mov    0x28(%rsi),%rcx
 29efc09:	cmp    0x1e8(%rcx),%eax
 29efc0f:	sete   %al
 29efc12:	movzbl %al,%eax
 29efc15:	test   %eax,%eax
 29efc17:	je     29fc2ab <wasm[0]::function[1015]::helper::object_read+0x1b38b>
 29efc1d:	test   %edx,%edx
 29efc1f:	je     29fc2ad <wasm[0]::function[1015]::helper::object_read+0x1b38d>
 29efc25:	test   %edx,%edx
 29efc27:	je     29fc2af <wasm[0]::function[1015]::helper::object_read+0x1b38f>
 29efc2d:	mov    0x2e0(%rsp),%rax
 29efc35:	mov    0x28(%rax),%rax
 29efc39:	mov    0x2e0(%rsp),%rcx
 29efc41:	mov    0x20(%rcx),%rcx
 29efc45:	mov    %edx,%edi
 29efc47:	lea    (%rcx,%rdi,1),%rsi
 29efc4b:	xor    %rdx,%rdx
 29efc4e:	cmp    %rax,%rdi
 29efc51:	cmova  %rdx,%rsi
 29efc55:	mov    0x14(%rsi),%edi
 29efc58:	test   %edi,%edi
 29efc5a:	je     29fc2b1 <wasm[0]::function[1015]::helper::object_read+0x1b391>
 29efc60:	test   %edi,%edi
 29efc62:	je     29fc2b3 <wasm[0]::function[1015]::helper::object_read+0x1b393>
 29efc68:	mov    %edi,%r8d
 29efc6b:	lea    (%rcx,%r8,1),%rdi
 29efc6f:	cmp    %rax,%r8
 29efc72:	cmova  %rdx,%rdi
 29efc76:	mov    0x18(%rdi),%r8d
 29efc7a:	mov    %r8,0x2b0(%rsp)
 29efc82:	mov    0x10(%rdi),%r8
 29efc86:	mov    %r8,0x2a8(%rsp)
 29efc8e:	mov    0x1c(%rdi),%edi
 29efc91:	mov    %edi,0x58(%rsp)
 29efc95:	mov    0x18(%rsi),%esi
 29efc98:	test   %esi,%esi
 29efc9a:	je     29fc2b5 <wasm[0]::function[1015]::helper::object_read+0x1b395>
 29efca0:	test   %esi,%esi
 29efca2:	je     29fc2b7 <wasm[0]::function[1015]::helper::object_read+0x1b397>
 29efca8:	mov    %esi,%esi
 29efcaa:	add    %rsi,%rcx
 29efcad:	cmp    %rax,%rsi
 29efcb0:	cmova  %rdx,%rcx
 29efcb4:	mov    0x18(%rcx),%ebx
 29efcb7:	mov    0x10(%rcx),%r13
 29efcbb:	mov    0x1c(%rcx),%eax
 29efcbe:	mov    %eax,0x80(%rsp)
 29efcc5:	cmp    $0x1,%ebx
 29efcc8:	je     29fa18a <wasm[0]::function[1015]::helper::object_read+0x1926a>
 29efcce:	mov    $0x27b,%edx
 29efcd3:	mov    %rdx,0x198(%rsp)
 29efcdb:	mov    0x190(%rsp),%rsi
 29efce3:	mov    0x190(%rsp),%rdi
 29efceb:	call   2f307a0 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 29efcf0:	test   %eax,%eax
 29efcf2:	je     29fc2b9 <wasm[0]::function[1015]::helper::object_read+0x1b399>
 29efcf8:	mov    0x70(%rsp),%ecx
 29efcfc:	test   %ecx,%ecx
 29efcfe:	je     29fc2bb <wasm[0]::function[1015]::helper::object_read+0x1b39b>
 29efd04:	mov    0x80(%rsp),%r8d
 29efd0c:	mov    0x50(%rsp),%edx
 29efd10:	mov    $0x4,%esi
 29efd15:	xor    %rdi,%rdi
 29efd18:	mov    %r13,(%rsp)
 29efd1c:	mov    %r8d,0x8(%rsp)
 29efd21:	mov    %esi,0x10(%rsp)
 29efd25:	mov    %rdi,0x18(%rsp)
 29efd2a:	mov    %eax,0x20(%rsp)
 29efd2e:	mov    %edx,0x28(%rsp)
 29efd32:	mov    %ecx,0x30(%rsp)
 29efd36:	mov    %r13,%rcx
 29efd39:	mov    %rbx,%rdx
 29efd3c:	mov    0x190(%rsp),%rsi
 29efd44:	mov    0x190(%rsp),%rdi
 29efd4c:	mov    %rbx,%r9
 29efd4f:	call   29e0f20 <wasm[0]::function[1015]::helper::object_read>
 29efd54:	sub    $0x40,%rsp
 29efd58:	mov    %rcx,%r15
 29efd5b:	mov    %edx,0x48(%rsp)
 29efd5f:	cmp    $0x1,%esi
 29efd62:	je     29fa161 <wasm[0]::function[1015]::helper::object_read+0x19241>
 29efd68:	test   %eax,%eax
 29efd6a:	sete   %sil
 29efd6e:	cmp    $0x1,%eax
 29efd71:	mov    %rax,0x2a0(%rsp)
 29efd79:	sete   %dil
 29efd7d:	or     %edi,%esi
 29efd7f:	test   %sil,%sil
 29efd82:	jne    29fa0c8 <wasm[0]::function[1015]::helper::object_read+0x191a8>
 29efd88:	xor    %ecx,%ecx
 29efd8a:	test   %edx,%edx
 29efd8c:	je     29efde4 <wasm[0]::function[1015]::helper::object_read+0xeec4>
 29efd92:	xor    %ecx,%ecx
 29efd94:	test   $0x1,%edx
 29efd9a:	jne    29efde4 <wasm[0]::function[1015]::helper::object_read+0xeec4>
 29efda0:	mov    0x2e0(%rsp),%rax
 29efda8:	mov    0x28(%rax),%rax
 29efdac:	mov    0x2e0(%rsp),%rcx
 29efdb4:	mov    0x20(%rcx),%rsi
 29efdb8:	mov    %edx,%ecx
 29efdba:	lea    0x4(%rsi,%rcx,1),%r10
 29efdbf:	xor    %rsi,%rsi
 29efdc2:	cmp    %rax,%rcx
 29efdc5:	cmova  %rsi,%r10
 29efdc9:	mov    (%r10),%eax
 29efdcc:	mov    0x190(%rsp),%rsi
 29efdd4:	mov    0x28(%rsi),%rcx
 29efdd8:	cmp    0x1d4(%rcx),%eax
 29efdde:	sete   %al
 29efde1:	movzbl %al,%ecx
 29efde4:	xor    %eax,%eax
 29efde6:	test   %edx,%edx
 29efde8:	je     29efe3f <wasm[0]::function[1015]::helper::object_read+0xef1f>
 29efdee:	xor    %eax,%eax
 29efdf0:	test   $0x1,%edx
 29efdf6:	jne    29efe3f <wasm[0]::function[1015]::helper::object_read+0xef1f>
 29efdfc:	mov    0x2e0(%rsp),%rax
 29efe04:	mov    0x28(%rax),%rax
 29efe08:	mov    0x2e0(%rsp),%rsi
 29efe10:	mov    0x20(%rsi),%rsi
 29efe14:	mov    %edx,%edi
 29efe16:	lea    0x4(%rsi,%rdi,1),%rsi
 29efe1b:	xor    %r8,%r8
 29efe1e:	cmp    %rax,%rdi
 29efe21:	cmova  %r8,%rsi
 29efe25:	mov    (%rsi),%eax
 29efe27:	mov    0x190(%rsp),%rsi
 29efe2f:	mov    0x28(%rsi),%rsi
 29efe33:	cmp    0x1e4(%rsi),%eax
 29efe39:	sete   %al
 29efe3c:	movzbl %al,%eax
 29efe3f:	or     %eax,%ecx
 29efe41:	test   %ecx,%ecx
 29efe43:	jne    29eff5d <wasm[0]::function[1015]::helper::object_read+0xf03d>
 29efe49:	xor    %eax,%eax
 29efe4b:	test   %edx,%edx
 29efe4d:	je     29efea4 <wasm[0]::function[1015]::helper::object_read+0xef84>
 29efe53:	xor    %eax,%eax
 29efe55:	test   $0x1,%edx
 29efe5b:	jne    29efea4 <wasm[0]::function[1015]::helper::object_read+0xef84>
 29efe61:	mov    0x2e0(%rsp),%rsi
 29efe69:	mov    0x28(%rsi),%rax
 29efe6d:	mov    0x2e0(%rsp),%rdi
 29efe75:	mov    0x20(%rdi),%rcx
 29efe79:	mov    %edx,%esi
 29efe7b:	lea    0x4(%rcx,%rsi,1),%rcx
 29efe80:	xor    %rdi,%rdi
 29efe83:	cmp    %rax,%rsi
 29efe86:	cmova  %rdi,%rcx
 29efe8a:	mov    (%rcx),%eax
 29efe8c:	mov    0x190(%rsp),%rsi
 29efe94:	mov    0x28(%rsi),%rcx
 29efe98:	cmp    0x1e8(%rcx),%eax
 29efe9e:	sete   %al
 29efea1:	movzbl %al,%eax
 29efea4:	test   %eax,%eax
 29efea6:	jne    29efeb3 <wasm[0]::function[1015]::helper::object_read+0xef93>
 29efeac:	xor    %eax,%eax
 29efeae:	jmp    29eff65 <wasm[0]::function[1015]::helper::object_read+0xf045>
 29efeb3:	xor    %eax,%eax
 29efeb5:	test   %edx,%edx
 29efeb7:	je     29eff0e <wasm[0]::function[1015]::helper::object_read+0xefee>
 29efebd:	xor    %eax,%eax
 29efebf:	test   $0x1,%edx
 29efec5:	jne    29eff0e <wasm[0]::function[1015]::helper::object_read+0xefee>
 29efecb:	mov    0x2e0(%rsp),%rax
 29efed3:	mov    0x28(%rax),%rax
 29efed7:	mov    0x2e0(%rsp),%rcx
 29efedf:	mov    0x20(%rcx),%rcx
 29efee3:	mov    %edx,%esi
 29efee5:	lea    0x4(%rcx,%rsi,1),%rcx
 29efeea:	xor    %rdi,%rdi
 29efeed:	cmp    %rax,%rsi
 29efef0:	cmova  %rdi,%rcx
 29efef4:	mov    (%rcx),%eax
 29efef6:	mov    0x190(%rsp),%rsi
 29efefe:	mov    0x28(%rsi),%rcx
 29eff02:	cmp    0x1e8(%rcx),%eax
 29eff08:	sete   %al
 29eff0b:	movzbl %al,%eax
 29eff0e:	test   %eax,%eax
 29eff10:	je     29fc2bd <wasm[0]::function[1015]::helper::object_read+0x1b39d>
 29eff16:	test   %edx,%edx
 29eff18:	je     29fc2bf <wasm[0]::function[1015]::helper::object_read+0x1b39f>
 29eff1e:	test   %edx,%edx
 29eff20:	je     29fc2c1 <wasm[0]::function[1015]::helper::object_read+0x1b3a1>
 29eff26:	mov    0x2e0(%rsp),%rax
 29eff2e:	mov    0x28(%rax),%rax
 29eff32:	mov    %edx,%edx
 29eff34:	mov    0x2e0(%rsp),%rsi
 29eff3c:	mov    %rdx,%rcx
 29eff3f:	add    0x20(%rsi),%rcx
 29eff43:	xor    %rsi,%rsi
 29eff46:	cmp    %rax,%rdx
 29eff49:	cmova  %rsi,%rcx
 29eff4d:	mov    0x1c(%rcx),%eax
 29eff50:	test   %eax,%eax
 29eff52:	setne  %al
 29eff55:	movzbl %al,%eax
 29eff58:	jmp    29eff65 <wasm[0]::function[1015]::helper::object_read+0xf045>
 29eff5d:	mov    0x278(%rsp),%rax
 29eff65:	test   %eax,%eax
 29eff67:	je     29f9e3e <wasm[0]::function[1015]::helper::object_read+0x18f1e>
 29eff6d:	mov    0x190(%rsp),%rsi
 29eff75:	mov    0x20(%rsi),%rcx
 29eff79:	mov    (%rcx),%eax
 29eff7b:	mov    %eax,%edx
 29eff7d:	mov    $0x20,%esi
 29eff82:	mov    %rsi,0x268(%rsp)
 29eff8a:	lea    0x20(%rdx),%rsi
 29eff8e:	mov    0x4(%rcx),%edi
 29eff91:	mov    %rcx,0x270(%rsp)
 29eff99:	cmp    %rdi,%rsi
 29eff9c:	ja     29fb0d4 <wasm[0]::function[1015]::helper::object_read+0x1a1b4>
 29effa2:	lea    0x20(%rax),%esi
 29effa5:	mov    0x270(%rsp),%rcx
 29effad:	mov    %esi,(%rcx)
 29effaf:	mov    0x2e0(%rsp),%rsi
 29effb7:	mov    0x20(%rsi),%rdi
 29effbb:	lea    (%rdi,%rdx,1),%rsi
 29effbf:	movl   $0xb0000042,(%rdi,%rdx,1)
 29effc6:	mov    0x190(%rsp),%r8
 29effce:	mov    0x28(%r8),%r8
 29effd2:	mov    0x120(%r8),%r8d
 29effd9:	mov    %r8d,0x4(%rdi,%rdx,1)
 29effde:	mov    0x268(%rsp),%r8
 29effe6:	mov    %r8d,0x8(%rdi,%rdx,1)
 29effeb:	mov    %eax,0xb8(%rsp)
 29efff2:	mov    0x2a8(%rsp),%rax
 29efffa:	mov    %rax,0x10(%rsi)
 29efffe:	mov    0x2b0(%rsp),%rdx
 29f0006:	mov    %edx,0x18(%rsi)
 29f0009:	mov    0x58(%rsp),%r9d
 29f000e:	mov    %r9d,0x1c(%rsi)
 29f0012:	mov    (%rcx),%eax
 29f0014:	mov    %eax,%r10d
 29f0017:	lea    0x20(%r10),%r11
 29f001b:	mov    0x4(%rcx),%edx
 29f001e:	mov    %rcx,0x270(%rsp)
 29f0026:	cmp    %rdx,%r11
 29f0029:	ja     29fb11e <wasm[0]::function[1015]::helper::object_read+0x1a1fe>
 29f002f:	lea    0x20(%rax),%ecx
 29f0032:	mov    0x270(%rsp),%rdx
 29f003a:	mov    %ecx,(%rdx)
 29f003c:	mov    0x2e0(%rsp),%rdx
 29f0044:	mov    0x20(%rdx),%rdx
 29f0048:	lea    (%rdx,%r10,1),%rcx
 29f004c:	movl   $0xb0000042,(%rdx,%r10,1)
 29f0054:	mov    0x190(%rsp),%rsi
 29f005c:	mov    0x28(%rsi),%rsi
 29f0060:	mov    0x120(%rsi),%esi
 29f0066:	mov    %esi,0x4(%rdx,%r10,1)
 29f006b:	mov    0x268(%rsp),%rsi
 29f0073:	mov    %esi,0x8(%rdx,%r10,1)
 29f0078:	mov    %eax,0xa8(%rsp)
 29f007f:	mov    0x1c0(%rsp),%r8
 29f0087:	mov    %r8,0x10(%rcx)
 29f008b:	mov    0x1b8(%rsp),%rax
 29f0093:	mov    %eax,0x18(%rcx)
 29f0096:	mov    0x68(%rsp),%eax
 29f009a:	mov    %eax,0x1c(%rcx)
 29f009d:	mov    0x270(%rsp),%rcx
 29f00a5:	mov    (%rcx),%eax
 29f00a7:	mov    %eax,%edx
 29f00a9:	lea    0x20(%rdx),%rcx
 29f00ad:	mov    0x270(%rsp),%rsi
 29f00b5:	mov    0x4(%rsi),%esi
 29f00b8:	cmp    %rsi,%rcx
 29f00bb:	ja     29fb160 <wasm[0]::function[1015]::helper::object_read+0x1a240>
 29f00c1:	lea    0x20(%rax),%ecx
 29f00c4:	mov    0x270(%rsp),%rsi
 29f00cc:	mov    %ecx,(%rsi)
 29f00ce:	mov    0x2e0(%rsp),%rcx
 29f00d6:	mov    0x20(%rcx),%rsi
 29f00da:	lea    (%rsi,%rdx,1),%rcx
 29f00de:	movl   $0xb0000042,(%rsi,%rdx,1)
 29f00e5:	mov    0x190(%rsp),%r8
 29f00ed:	mov    0x28(%r8),%rdi
 29f00f1:	mov    0x120(%rdi),%edi
 29f00f7:	mov    %edi,0x4(%rsi,%rdx,1)
 29f00fb:	mov    0x268(%rsp),%rdi
 29f0103:	mov    %edi,0x8(%rsi,%rdx,1)
 29f0107:	mov    %eax,0xa0(%rsp)
 29f010e:	mov    %r12,0x10(%rcx)
 29f0112:	mov    0x1a8(%rsp),%r9
 29f011a:	mov    %r9d,0x18(%rcx)
 29f011e:	mov    0x60(%rsp),%edx
 29f0122:	mov    %edx,0x1c(%rcx)
 29f0125:	mov    0xb8(%rsp),%ecx
 29f012c:	test   %ecx,%ecx
 29f012e:	je     29fc2c3 <wasm[0]::function[1015]::helper::object_read+0x1b3a3>
 29f0134:	mov    0xa8(%rsp),%ecx
 29f013b:	test   %ecx,%ecx
 29f013d:	je     29fc2c5 <wasm[0]::function[1015]::helper::object_read+0x1b3a5>
 29f0143:	test   %eax,%eax
 29f0145:	je     29fc2c7 <wasm[0]::function[1015]::helper::object_read+0x1b3a7>
 29f014b:	mov    0x270(%rsp),%rcx
 29f0153:	mov    (%rcx),%eax
 29f0155:	mov    %eax,%ecx
 29f0157:	lea    0x20(%rcx),%rdx
 29f015b:	mov    0x270(%rsp),%rsi
 29f0163:	mov    0x4(%rsi),%esi
 29f0166:	cmp    %rsi,%rdx
 29f0169:	ja     29fb1a2 <wasm[0]::function[1015]::helper::object_read+0x1a282>
 29f016f:	lea    0x20(%rax),%edx
 29f0172:	mov    0x270(%rsp),%rsi
 29f017a:	mov    %edx,(%rsi)
 29f017c:	mov    0x2e0(%rsp),%r12
 29f0184:	mov    0x20(%r12),%rsi
 29f0189:	lea    (%rsi,%rcx,1),%rdx
 29f018d:	movl   $0xa800000e,(%rsi,%rcx,1)
 29f0194:	mov    0x190(%rsp),%rdi
 29f019c:	mov    0x28(%rdi),%rdi
 29f01a0:	mov    0x1b4(%rdi),%edi
 29f01a6:	mov    %edi,0x4(%rsi,%rcx,1)
 29f01aa:	mov    0x268(%rsp),%rdi
 29f01b2:	mov    %edi,0x8(%rsi,%rcx,1)
 29f01b6:	movl   $0x3,0x10(%rdx)
 29f01bd:	test   %eax,%eax
 29f01bf:	je     29fc2c9 <wasm[0]::function[1015]::helper::object_read+0x1b3a9>
 29f01c5:	mov    0x2e0(%rsp),%r12
 29f01cd:	mov    0x28(%r12),%rcx
 29f01d2:	mov    0x20(%r12),%rdx
 29f01d7:	mov    %eax,%r8d
 29f01da:	lea    0x10(%rdx,%r8,1),%rdi
 29f01df:	xor    %rsi,%rsi
 29f01e2:	cmp    %rcx,%r8
 29f01e5:	cmova  %rsi,%rdi
 29f01e9:	mov    (%rdi),%r8d
 29f01ec:	test   %r8d,%r8d
 29f01ef:	je     29fc2cb <wasm[0]::function[1015]::helper::object_read+0x1b3ab>
 29f01f5:	mov    %r8d,%r9d
 29f01f8:	shl    $0x2,%r9
 29f01fc:	shr    $0x20,%r9
 29f0200:	test   %r9,%r9
 29f0203:	jne    29fc2cd <wasm[0]::function[1015]::helper::object_read+0x1b3ad>
 29f0209:	shl    $0x2,%r8d
 29f020d:	add    $0x14,%r8d
 29f0211:	jb     29fc2cf <wasm[0]::function[1015]::helper::object_read+0x1b3af>
 29f0217:	mov    %rax,%r10
 29f021a:	add    %r8d,%r10d
 29f021d:	jb     29fc2d1 <wasm[0]::function[1015]::helper::object_read+0x1b3b1>
 29f0223:	mov    0xb8(%rsp),%r9d
 29f022b:	mov    %r10d,%r11d
 29f022e:	lea    (%rdx,%r11,1),%r10
 29f0232:	cmp    %rcx,%r11
 29f0235:	cmova  %rsi,%r10
 29f0239:	sub    $0x14,%r8d
 29f023d:	sub    %r8,%r10
 29f0240:	mov    %r9d,(%r10)
 29f0243:	mov    (%rdi),%r8d
 29f0246:	cmp    $0x1,%r8d
 29f024a:	jbe    29fc2d3 <wasm[0]::function[1015]::helper::object_read+0x1b3b3>
 29f0250:	mov    %r8d,%r9d
 29f0253:	shl    $0x2,%r9
 29f0257:	shr    $0x20,%r9
 29f025b:	test   %r9,%r9
 29f025e:	jne    29fc2d5 <wasm[0]::function[1015]::helper::object_read+0x1b3b5>
 29f0264:	shl    $0x2,%r8d
 29f0268:	add    $0x14,%r8d
 29f026c:	jb     29fc2d7 <wasm[0]::function[1015]::helper::object_read+0x1b3b7>
 29f0272:	mov    %rax,%r10
 29f0275:	add    %r8d,%r10d
 29f0278:	jb     29fc2d9 <wasm[0]::function[1015]::helper::object_read+0x1b3b9>
 29f027e:	mov    0xa8(%rsp),%r9d
 29f0286:	mov    %r10d,%r11d
 29f0289:	lea    (%rdx,%r11,1),%r10
 29f028d:	cmp    %rcx,%r11
 29f0290:	cmova  %rsi,%r10
 29f0294:	sub    $0x18,%r8d
 29f0298:	sub    %r8,%r10
 29f029b:	mov    %r9d,(%r10)
 29f029e:	mov    (%rdi),%edi
 29f02a0:	cmp    $0x2,%edi
 29f02a3:	jbe    29fc2db <wasm[0]::function[1015]::helper::object_read+0x1b3bb>
 29f02a9:	mov    %edi,%r8d
 29f02ac:	shl    $0x2,%r8
 29f02b0:	shr    $0x20,%r8
 29f02b4:	test   %r8,%r8
 29f02b7:	jne    29fc2dd <wasm[0]::function[1015]::helper::object_read+0x1b3bd>
 29f02bd:	shl    $0x2,%edi
 29f02c0:	add    $0x14,%edi
 29f02c3:	jb     29fc2df <wasm[0]::function[1015]::helper::object_read+0x1b3bf>
 29f02c9:	mov    %rax,%r10
 29f02cc:	add    %edi,%r10d
 29f02cf:	jb     29fc2e1 <wasm[0]::function[1015]::helper::object_read+0x1b3c1>
 29f02d5:	mov    0xa0(%rsp),%r11d
 29f02dd:	mov    %r10d,%r9d
 29f02e0:	lea    (%rdx,%r9,1),%r8
 29f02e4:	cmp    %rcx,%r9
 29f02e7:	cmova  %rsi,%r8
 29f02eb:	mov    $0x1c,%r14d
 29f02f1:	sub    $0x1c,%edi
 29f02f4:	sub    %rdi,%r8
 29f02f7:	mov    %r11d,(%r8)
 29f02fa:	mov    0x190(%rsp),%rsi
 29f0302:	mov    0x8c0(%rsi),%ecx
 29f0308:	mov    %ecx,0xa0(%rsp)
 29f030f:	test   %ecx,%ecx
 29f0311:	je     29fc2e3 <wasm[0]::function[1015]::helper::object_read+0x1b3c3>
 29f0317:	test   %eax,%eax
 29f0319:	je     29fc2e5 <wasm[0]::function[1015]::helper::object_read+0x1b3c5>
 29f031f:	mov    0x70(%rsp),%edx
 29f0323:	test   %edx,%edx
 29f0325:	je     29fc2e7 <wasm[0]::function[1015]::helper::object_read+0x1b3c7>
 29f032b:	mov    0x48(%rsp),%r8d
 29f0330:	mov    0x80(%rsp),%edi
 29f0337:	mov    0x50(%rsp),%esi
 29f033b:	mov    %r13,(%rsp)
 29f033f:	mov    %edi,0x8(%rsp)
 29f0343:	mov    %eax,0x10(%rsp)
 29f0347:	mov    %ecx,0x18(%rsp)
 29f034b:	mov    %esi,0x20(%rsp)
 29f034f:	mov    %edx,0x28(%rsp)
 29f0353:	mov    %r15,%rcx
 29f0356:	mov    0x2a0(%rsp),%rdx
 29f035e:	mov    %rbx,%r9
 29f0361:	mov    0x190(%rsp),%rsi
 29f0369:	mov    0x190(%rsp),%rdi
 29f0371:	call   2adef00 <wasm[0]::function[1055]::helper::proxy_call>
 29f0376:	sub    $0x30,%rsp
 29f037a:	mov    %rax,0x280(%rsp)
 29f0382:	mov    %rcx,0x288(%rsp)
 29f038a:	mov    %edx,0x80(%rsp)
 29f0391:	mov    0xa0(%rsp),%eax
 29f0398:	test   %eax,%eax
 29f039a:	je     29fc2e9 <wasm[0]::function[1015]::helper::object_read+0x1b3c9>
 29f03a0:	mov    0x190(%rsp),%rcx
 29f03a8:	mov    %eax,0x8c0(%rcx)
 29f03ae:	cmp    $0x2,%esi
 29f03b1:	jne    29f03bc <wasm[0]::function[1015]::helper::object_read+0xf49c>
 29f03b7:	xor    %esi,%esi
 29f03b9:	mov    %rsi,%rdi
 29f03bc:	cmp    $0x1,%esi
 29f03bf:	je     29f9e27 <wasm[0]::function[1015]::helper::object_read+0x18f07>
 29f03c5:	xor    %eax,%eax
 29f03c7:	movl   $0x0,0xa0(%rsp)
 29f03d2:	mov    0x58(%rsp),%edx
 29f03d6:	test   %edx,%edx
 29f03d8:	je     29f0429 <wasm[0]::function[1015]::helper::object_read+0xf509>
 29f03de:	xor    %eax,%eax
 29f03e0:	test   $0x1,%edx
 29f03e6:	jne    29f0429 <wasm[0]::function[1015]::helper::object_read+0xf509>
 29f03ec:	mov    0x2e0(%rsp),%r12
 29f03f4:	mov    0x28(%r12),%rax
 29f03f9:	mov    0x20(%r12),%rcx
 29f03fe:	mov    %edx,%esi
 29f0400:	lea    0x4(%rcx,%rsi,1),%rcx
 29f0405:	xor    %rdi,%rdi
 29f0408:	cmp    %rax,%rsi
 29f040b:	cmova  %rdi,%rcx
 29f040f:	mov    (%rcx),%eax
 29f0411:	mov    0x190(%rsp),%rsi
 29f0419:	mov    0x28(%rsi),%rcx
 29f041d:	cmp    0x138(%rcx),%eax
 29f0423:	sete   %al
 29f0426:	movzbl %al,%eax
 29f0429:	test   %eax,%eax
 29f042b:	jne    29f8bef <wasm[0]::function[1015]::helper::object_read+0x17ccf>
 29f0431:	xor    %eax,%eax
 29f0433:	test   %edx,%edx
 29f0435:	je     29f0486 <wasm[0]::function[1015]::helper::object_read+0xf566>
 29f043b:	xor    %eax,%eax
 29f043d:	test   $0x1,%edx
 29f0443:	jne    29f0486 <wasm[0]::function[1015]::helper::object_read+0xf566>
 29f0449:	mov    0x2e0(%rsp),%r12
 29f0451:	mov    0x28(%r12),%rax
 29f0456:	mov    0x20(%r12),%rcx
 29f045b:	mov    %edx,%esi
 29f045d:	lea    0x4(%rcx,%rsi,1),%rcx
 29f0462:	xor    %rdi,%rdi
 29f0465:	cmp    %rax,%rsi
 29f0468:	cmova  %rdi,%rcx
 29f046c:	mov    (%rcx),%eax
 29f046e:	mov    0x190(%rsp),%rsi
 29f0476:	mov    0x28(%rsi),%rcx
 29f047a:	cmp    0x254(%rcx),%eax
 29f0480:	sete   %al
 29f0483:	movzbl %al,%eax
 29f0486:	test   %eax,%eax
 29f0488:	jne    29f6824 <wasm[0]::function[1015]::helper::object_read+0x15904>
 29f048e:	mov    0x50(%rsp),%eax
 29f0492:	mov    0x68(%rsp),%esi
 29f0496:	mov    0x70(%rsp),%edi
 29f049a:	mov    0x80(%rsp),%r8d
 29f04a2:	xor    %ecx,%ecx
 29f04a4:	mov    %rax,%r9
 29f04a7:	mov    %rcx,%r10
 29f04aa:	mov    %rcx,%r11
 29f04ad:	mov    %eax,0x78(%rsp)
 29f04b1:	mov    %ecx,0x110(%rsp)
 29f04b8:	mov    %r10d,0xd8(%rsp)
 29f04c0:	mov    %edx,0xc8(%rsp)
 29f04c7:	mov    %esi,0x100(%rsp)
 29f04ce:	mov    %r9d,0xc0(%rsp)
 29f04d6:	mov    %edi,0x88(%rsp)
 29f04dd:	mov    %r8d,0xb8(%rsp)
 29f04e5:	mov    %r11d,0xa8(%rsp)
 29f04ed:	mov    0x2e8(%rsp),%r13
 29f04f5:	mov    0x0(%r13),%rdx
 29f04f9:	mov    0x228(%rsp),%rax
 29f0501:	cmp    %rax,%rdx
 29f0504:	jae    29fb1e5 <wasm[0]::function[1015]::helper::object_read+0x1a2c5>
 29f050a:	mov    0x78(%rsp),%r9d
 29f050f:	mov    0x110(%rsp),%ecx
 29f0516:	test   %r9d,%r9d
 29f0519:	je     29f05c3 <wasm[0]::function[1015]::helper::object_read+0xf6a3>
 29f051f:	mov    0x78(%rsp),%ecx
 29f0523:	test   %ecx,%ecx
 29f0525:	je     29fc2eb <wasm[0]::function[1015]::helper::object_read+0x1b3cb>
 29f052b:	mov    0x2e0(%rsp),%r12
 29f0533:	mov    0x28(%r12),%rax
 29f0538:	mov    0x20(%r12),%rdx
 29f053d:	mov    %ecx,%ecx
 29f053f:	lea    (%rdx,%rcx,1),%r11
 29f0543:	xor    %rdx,%rdx
 29f0546:	cmp    %rax,%rcx
 29f0549:	cmova  %rdx,%r11
 29f054d:	mov    0x10(%r11),%ecx
 29f0551:	test   %ecx,%ecx
 29f0553:	jne    29f05c3 <wasm[0]::function[1015]::helper::object_read+0xf6a3>
 29f0559:	mov    0x78(%rsp),%edx
 29f055d:	test   %edx,%edx
 29f055f:	je     29fc2ed <wasm[0]::function[1015]::helper::object_read+0x1b3cd>
 29f0565:	mov    0x2e0(%rsp),%r12
 29f056d:	mov    0x28(%r12),%rax
 29f0572:	mov    %edx,%esi
 29f0574:	mov    %rsi,%rdx
 29f0577:	add    0x20(%r12),%rdx
 29f057c:	xor    %rdi,%rdi
 29f057f:	cmp    %rax,%rsi
 29f0582:	cmova  %rdi,%rdx
 29f0586:	mov    0x1c(%rdx),%eax
 29f0589:	mov    0xd8(%rsp),%r10d
 29f0591:	mov    0xc8(%rsp),%edx
 29f0598:	mov    0x100(%rsp),%esi
 29f059f:	mov    0xc0(%rsp),%r9d
 29f05a7:	mov    0x88(%rsp),%edi
 29f05ae:	mov    0xb8(%rsp),%r8d
 29f05b6:	mov    0xa8(%rsp),%r11d
 29f05be:	jmp    29f04ad <wasm[0]::function[1015]::helper::object_read+0xf58d>
 29f05c3:	test   %ecx,%ecx
 29f05c5:	jne    29f05e1 <wasm[0]::function[1015]::helper::object_read+0xf6c1>
 29f05cb:	mov    0x190(%rsp),%rsi
 29f05d3:	mov    0x8c0(%rsi),%ecx
 29f05d9:	test   %ecx,%ecx
 29f05db:	je     29fc2ef <wasm[0]::function[1015]::helper::object_read+0x1b3cf>
 29f05e1:	mov    %ecx,0x78(%rsp)
 29f05e5:	test   %ecx,%ecx
 29f05e7:	je     29fc2f1 <wasm[0]::function[1015]::helper::object_read+0x1b3d1>
 29f05ed:	test   %ecx,%ecx
 29f05ef:	je     29fc2f3 <wasm[0]::function[1015]::helper::object_read+0x1b3d3>
 29f05f5:	mov    0x2e0(%rsp),%r12
 29f05fd:	mov    0x28(%r12),%rax
 29f0602:	mov    0x20(%r12),%rdx
 29f0607:	mov    %ecx,%edi
 29f0609:	lea    (%rdx,%rdi,1),%rsi
 29f060d:	xor    %rcx,%rcx
 29f0610:	cmp    %rax,%rdi
 29f0613:	cmova  %rcx,%rsi
 29f0617:	mov    0x2c(%rsi),%esi
 29f061a:	test   %esi,%esi
 29f061c:	je     29fc2f5 <wasm[0]::function[1015]::helper::object_read+0x1b3d5>
 29f0622:	test   %esi,%esi
 29f0624:	je     29fc2f7 <wasm[0]::function[1015]::helper::object_read+0x1b3d7>
 29f062a:	mov    %esi,%r8d
 29f062d:	lea    0x10(%rdx,%r8,1),%rdi
 29f0632:	cmp    %rax,%r8
 29f0635:	cmova  %rcx,%rdi
 29f0639:	mov    (%rdi),%edi
 29f063b:	cmp    $0xd,%edi
 29f063e:	jbe    29fc2f9 <wasm[0]::function[1015]::helper::object_read+0x1b3d9>
 29f0644:	mov    %edi,%r8d
 29f0647:	shl    $0x2,%r8
 29f064b:	shr    $0x20,%r8
 29f064f:	test   %r8,%r8
 29f0652:	jne    29fc2fb <wasm[0]::function[1015]::helper::object_read+0x1b3db>
 29f0658:	shl    $0x2,%edi
 29f065b:	add    $0x14,%edi
 29f065e:	jb     29fc2fd <wasm[0]::function[1015]::helper::object_read+0x1b3dd>
 29f0664:	add    %edi,%esi
 29f0666:	jb     29fc2ff <wasm[0]::function[1015]::helper::object_read+0x1b3df>
 29f066c:	mov    %esi,%r8d
 29f066f:	lea    (%rdx,%r8,1),%rsi
 29f0673:	cmp    %rax,%r8
 29f0676:	cmova  %rcx,%rsi
 29f067a:	sub    $0x48,%edi
 29f067d:	sub    %rdi,%rsi
 29f0680:	mov    (%rsi),%esi
 29f0682:	test   %esi,%esi
 29f0684:	je     29fc301 <wasm[0]::function[1015]::helper::object_read+0x1b3e1>
 29f068a:	test   %esi,%esi
 29f068c:	je     29fc303 <wasm[0]::function[1015]::helper::object_read+0x1b3e3>
 29f0692:	mov    %esi,%esi
 29f0694:	add    %rsi,%rdx
 29f0697:	cmp    %rax,%rsi
 29f069a:	cmova  %rcx,%rdx
 29f069e:	mov    0x18(%rdx),%ecx
 29f06a1:	mov    0x10(%rdx),%rax
 29f06a5:	mov    0x1c(%rdx),%eax
 29f06a8:	mov    %eax,0x110(%rsp)
 29f06af:	cmp    $0x6,%ecx
 29f06b2:	sete   %dl
 29f06b5:	cmp    $0x7,%ecx
 29f06b8:	sete   %sil
 29f06bc:	or     %esi,%edx
 29f06be:	mov    $0x8,%ebx
 29f06c3:	cmp    $0x8,%ecx
 29f06c6:	sete   %sil
 29f06ca:	or     %esi,%edx
 29f06cc:	cmp    $0x9,%ecx
 29f06cf:	sete   %cl
 29f06d2:	or     %ecx,%edx
 29f06d4:	movzbl %dl,%ecx
 29f06d7:	test   %ecx,%ecx
 29f06d9:	je     29fc305 <wasm[0]::function[1015]::helper::object_read+0x1b3e5>
 29f06df:	xor    %ecx,%ecx
 29f06e1:	test   %eax,%eax
 29f06e3:	je     29f0735 <wasm[0]::function[1015]::helper::object_read+0xf815>
 29f06e9:	xor    %ecx,%ecx
 29f06eb:	test   $0x1,%eax
 29f06f0:	jne    29f0735 <wasm[0]::function[1015]::helper::object_read+0xf815>
 29f06f6:	mov    0x2e0(%rsp),%r12
 29f06fe:	mov    0x28(%r12),%rdx
 29f0703:	mov    0x20(%r12),%rdi
 29f0708:	mov    %eax,%esi
 29f070a:	lea    0x4(%rdi,%rsi,1),%rcx
 29f070f:	xor    %rdi,%rdi
 29f0712:	cmp    %rdx,%rsi
 29f0715:	cmova  %rdi,%rcx
 29f0719:	mov    (%rcx),%esi
 29f071b:	mov    0x190(%rsp),%rdi
 29f0723:	mov    0x28(%rdi),%rdi
 29f0727:	cmp    0x1d4(%rdi),%esi
 29f072d:	sete   %sil
 29f0731:	movzbl %sil,%ecx
 29f0735:	test   %ecx,%ecx
 29f0737:	je     29fc307 <wasm[0]::function[1015]::helper::object_read+0x1b3e7>
 29f073d:	test   %eax,%eax
 29f073f:	je     29fc309 <wasm[0]::function[1015]::helper::object_read+0x1b3e9>
 29f0745:	movl   $0x0,0x128(%rsp)
 29f0750:	movl   $0x0,0x138(%rsp)
 29f075b:	movl   $0x0,0x118(%rsp)
 29f0766:	movl   $0x0,0x90(%rsp)
 29f0771:	movl   $0x0,0xe0(%rsp)
 29f077c:	mov    $0x105,%edx
 29f0781:	mov    0x190(%rsp),%rsi
 29f0789:	mov    0x190(%rsp),%rdi
 29f0791:	call   2f307a0 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 29f0796:	test   %eax,%eax
 29f0798:	je     29fc30b <wasm[0]::function[1015]::helper::object_read+0x1b3eb>
 29f079e:	mov    0x110(%rsp),%r8d
 29f07a6:	xor    %rcx,%rcx
 29f07a9:	movabs $0x4000000000000000,%rdx
 29f07b3:	mov    %rdx,(%rsp)
 29f07b7:	mov    0x278(%rsp),%rdx
 29f07bf:	mov    %edx,0x8(%rsp)
 29f07c3:	mov    %rax,%r9
 29f07c6:	mov    %rbx,%rdx
 29f07c9:	mov    0x190(%rsp),%rsi
 29f07d1:	mov    0x190(%rsp),%rdi
 29f07d9:	call   2a56060 <wasm[0]::function[1029]::helper::native_function_allocate>
 29f07de:	sub    $0x10,%rsp
 29f07e2:	mov    %eax,0x110(%rsp)
 29f07e9:	mov    $0x51,%esi
 29f07ee:	mov    0x190(%rsp),%rdi
 29f07f6:	call   3018cee <wasmtime_builtin_ref_func>
 29f07fb:	mov    0x270(%rsp),%rcx
 29f0803:	mov    %rax,%r13
 29f0806:	mov    (%rcx),%eax
 29f0808:	mov    %eax,%ecx
 29f080a:	mov    $0x40,%r15d
 29f0810:	lea    0x40(%rcx),%rdx
 29f0814:	mov    0x270(%rsp),%rsi
 29f081c:	mov    0x4(%rsi),%esi
 29f081f:	cmp    %rsi,%rdx
 29f0822:	ja     29fb21d <wasm[0]::function[1015]::helper::object_read+0x1a2fd>
 29f0828:	lea    0x40(%rax),%edx
 29f082b:	mov    0x270(%rsp),%rsi
 29f0833:	mov    %edx,(%rsi)
 29f0835:	mov    0x2e0(%rsp),%r12
 29f083d:	mov    0x20(%r12),%rdx
 29f0842:	lea    (%rdx,%rcx,1),%r12
 29f0846:	movl   $0xb0000002,(%rdx,%rcx,1)
 29f084d:	mov    0x190(%rsp),%rsi
 29f0855:	mov    0x28(%rsi),%rsi
 29f0859:	mov    0x1d0(%rsi),%esi
 29f085f:	mov    %esi,0x4(%rdx,%rcx,1)
 29f0863:	mov    %r15d,0x8(%rdx,%rcx,1)
 29f0868:	mov    %eax,0x108(%rsp)
 29f086f:	movq   $0x51,0x10(%r12)
 29f0878:	movl   $0x1,0x18(%r12)
 29f0881:	movl   $0xf,0x1c(%r12)
 29f088a:	movl   $0xffffffff,0x20(%r12)
 29f0893:	movl   $0x0,0x24(%r12)
 29f089c:	movl   $0x0,0x28(%r12)
 29f08a5:	mov    %r13,%rsi
 29f08a8:	mov    0x190(%rsp),%rdi
 29f08b0:	call   3018de3 <wasmtime_builtin_intern_func_ref_for_gc_heap>
 29f08b5:	mov    %eax,0x2c(%r12)
 29f08ba:	xor    %rsi,%rsi
 29f08bd:	mov    %rsi,%r13
 29f08c0:	mov    0x190(%rsp),%rdi
 29f08c8:	call   3018de3 <wasmtime_builtin_intern_func_ref_for_gc_heap>
 29f08cd:	mov    %eax,0x30(%r12)
 29f08d2:	mov    %r13,%rsi
 29f08d5:	mov    0x190(%rsp),%rdi
 29f08dd:	call   3018de3 <wasmtime_builtin_intern_func_ref_for_gc_heap>
 29f08e2:	mov    %eax,0x34(%r12)
 29f08e7:	mov    %r13,%rsi
 29f08ea:	mov    0x190(%rsp),%rdi
 29f08f2:	call   3018de3 <wasmtime_builtin_intern_func_ref_for_gc_heap>
 29f08f7:	mov    %eax,0x38(%r12)
 29f08fc:	mov    %r13,%rsi
 29f08ff:	mov    0x190(%rsp),%rdi
 29f0907:	call   3018de3 <wasmtime_builtin_intern_func_ref_for_gc_heap>
 29f090c:	mov    %eax,0x3c(%r12)
 29f0911:	mov    0x190(%rsp),%rsi
 29f0919:	mov    0xa20(%rsi),%eax
 29f091f:	mov    %eax,0x120(%rsp)
 29f0926:	mov    0x78(%rsp),%ecx
 29f092a:	test   %ecx,%ecx
 29f092c:	je     29fc30d <wasm[0]::function[1015]::helper::object_read+0x1b3ed>
 29f0932:	test   %eax,%eax
 29f0934:	je     29fc30f <wasm[0]::function[1015]::helper::object_read+0x1b3ef>
 29f093a:	mov    0x270(%rsp),%rcx
 29f0942:	mov    (%rcx),%eax
 29f0944:	mov    %eax,%ecx
 29f0946:	lea    0x40(%rcx),%rdx
 29f094a:	mov    0x270(%rsp),%rsi
 29f0952:	mov    0x4(%rsi),%esi
 29f0955:	cmp    %rsi,%rdx
 29f0958:	ja     29fb260 <wasm[0]::function[1015]::helper::object_read+0x1a340>
 29f095e:	lea    0x40(%rax),%edx
 29f0961:	mov    0x270(%rsp),%rsi
 29f0969:	mov    %edx,(%rsi)
 29f096b:	mov    0x2e0(%rsp),%r12
 29f0973:	mov    0x20(%r12),%rdx
 29f0978:	lea    (%rdx,%rcx,1),%r13
 29f097c:	movl   $0xb0001ffa,(%rdx,%rcx,1)
 29f0983:	mov    0x190(%rsp),%rsi
 29f098b:	mov    0x28(%rsi),%rsi
 29f098f:	mov    0x1e0(%rsi),%esi
 29f0995:	mov    %esi,0x4(%rdx,%rcx,1)
 29f0999:	mov    %r15d,0x8(%rdx,%rcx,1)
 29f099e:	mov    %eax,0x98(%rsp)
 29f09a5:	mov    0x78(%rsp),%eax
 29f09a9:	mov    %eax,0x10(%r13)
 29f09ad:	mov    0x128(%rsp),%eax
 29f09b4:	mov    %eax,0x14(%r13)
 29f09b8:	mov    0x138(%rsp),%eax
 29f09bf:	mov    %eax,0x18(%r13)
 29f09c3:	movl   $0x0,0x1c(%r13)
 29f09cb:	mov    0x120(%rsp),%eax
 29f09d2:	mov    %eax,0x20(%r13)
 29f09d6:	mov    0x118(%rsp),%eax
 29f09dd:	mov    %eax,0x24(%r13)
 29f09e1:	mov    0xe0(%rsp),%eax
 29f09e8:	mov    %eax,0x28(%r13)
 29f09ec:	mov    0xd8(%rsp),%eax
 29f09f3:	mov    %eax,0x2c(%r13)
 29f09f7:	mov    0x90(%rsp),%eax
 29f09fe:	mov    %eax,0x30(%r13)
 29f0a02:	movl   $0x0,0x34(%r13)
 29f0a0a:	xor    %rsi,%rsi
 29f0a0d:	mov    0x190(%rsp),%rdi
 29f0a15:	call   3018de3 <wasmtime_builtin_intern_func_ref_for_gc_heap>
 29f0a1a:	mov    %eax,0x38(%r13)
 29f0a1e:	mov    $0xea5,%edx
 29f0a23:	mov    0x190(%rsp),%rsi
 29f0a2b:	mov    0x190(%rsp),%rdi
 29f0a33:	call   2f307a0 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 29f0a38:	mov    %eax,0x90(%rsp)
 29f0a3f:	mov    0x190(%rsp),%rsi
 29f0a47:	mov    0xa20(%rsi),%edx
 29f0a4d:	mov    %edx,0xd8(%rsp)
 29f0a54:	mov    0x110(%rsp),%esi
 29f0a5b:	test   %esi,%esi
 29f0a5d:	je     29fc311 <wasm[0]::function[1015]::helper::object_read+0x1b3f1>
 29f0a63:	mov    0x108(%rsp),%esi
 29f0a6a:	test   %esi,%esi
 29f0a6c:	je     29fc313 <wasm[0]::function[1015]::helper::object_read+0x1b3f3>
 29f0a72:	mov    0x98(%rsp),%edi
 29f0a79:	test   %edi,%edi
 29f0a7b:	je     29fc315 <wasm[0]::function[1015]::helper::object_read+0x1b3f5>
 29f0a81:	test   %eax,%eax
 29f0a83:	je     29fc317 <wasm[0]::function[1015]::helper::object_read+0x1b3f7>
 29f0a89:	test   %edx,%edx
 29f0a8b:	je     29fc319 <wasm[0]::function[1015]::helper::object_read+0x1b3f9>
 29f0a91:	mov    0x270(%rsp),%rcx
 29f0a99:	mov    (%rcx),%eax
 29f0a9b:	mov    %eax,%edx
 29f0a9d:	mov    $0x50,%esi
 29f0aa2:	lea    0x50(%rdx),%rcx
 29f0aa6:	mov    0x270(%rsp),%rdi
 29f0aae:	mov    0x4(%rdi),%edi
 29f0ab1:	cmp    %rdi,%rcx
 29f0ab4:	ja     29fb2a4 <wasm[0]::function[1015]::helper::object_read+0x1a384>
 29f0aba:	lea    0x50(%rax),%ecx
 29f0abd:	mov    0x270(%rsp),%rdi
 29f0ac5:	mov    %ecx,(%rdi)
 29f0ac7:	mov    0x2e0(%rsp),%r12
 29f0acf:	mov    0x20(%r12),%rdi
 29f0ad4:	lea    (%rdi,%rdx,1),%rcx
 29f0ad8:	movl   $0xb00300fa,(%rdi,%rdx,1)
 29f0adf:	mov    0x190(%rsp),%r8
 29f0ae7:	mov    0x28(%r8),%r8
 29f0aeb:	mov    0x1d4(%r8),%r8d
 29f0af2:	mov    %r8d,0x4(%rdi,%rdx,1)
 29f0af7:	mov    %esi,0x8(%rdi,%rdx,1)
 29f0afb:	mov    %eax,0xe0(%rsp)
 29f0b02:	mov    0x110(%rsp),%edx
 29f0b09:	mov    %edx,0x10(%rcx)
 29f0b0c:	mov    0x108(%rsp),%edx
 29f0b13:	mov    %edx,0x14(%rcx)
 29f0b16:	mov    0x98(%rsp),%edx
 29f0b1d:	mov    %edx,0x18(%rcx)
 29f0b20:	mov    0x90(%rsp),%esi
 29f0b27:	mov    %esi,0x1c(%rcx)
 29f0b2a:	mov    0xd8(%rsp),%esi
 29f0b31:	mov    %esi,0x20(%rcx)
 29f0b34:	movl   $0x1,0x24(%rcx)
 29f0b3b:	movl   $0x0,0x28(%rcx)
 29f0b42:	movl   $0x0,0x2c(%rcx)
 29f0b49:	movl   $0x0,0x30(%rcx)
 29f0b50:	movl   $0x0,0x34(%rcx)
 29f0b57:	movl   $0x0,0x38(%rcx)
 29f0b5e:	movl   $0x0,0x3c(%rcx)
 29f0b65:	movl   $0xffffffff,0x40(%rcx)
 29f0b6c:	movl   $0x0,0x44(%rcx)
 29f0b73:	movl   $0x0,0x48(%rcx)
 29f0b7a:	test   %edx,%edx
 29f0b7c:	je     29fc31b <wasm[0]::function[1015]::helper::object_read+0x1b3fb>
 29f0b82:	test   %eax,%eax
 29f0b84:	je     29fc31d <wasm[0]::function[1015]::helper::object_read+0x1b3fd>
 29f0b8a:	test   %edx,%edx
 29f0b8c:	je     29fc31f <wasm[0]::function[1015]::helper::object_read+0x1b3ff>
 29f0b92:	mov    0x2e0(%rsp),%r12
 29f0b9a:	mov    0x28(%r12),%rcx
 29f0b9f:	mov    %edx,%esi
 29f0ba1:	mov    %rsi,%rdx
 29f0ba4:	add    0x20(%r12),%rdx
 29f0ba9:	xor    %rdi,%rdi
 29f0bac:	cmp    %rcx,%rsi
 29f0baf:	cmova  %rdi,%rdx
 29f0bb3:	mov    %eax,0x1c(%rdx)
 29f0bb6:	movl   $0x0,0x98(%rsp)
 29f0bc1:	mov    0x270(%rsp),%rcx
 29f0bc9:	mov    (%rcx),%eax
 29f0bcb:	mov    %eax,%ecx
 29f0bcd:	lea    0x20(%rcx),%rdx
 29f0bd1:	mov    0x270(%rsp),%rsi
 29f0bd9:	mov    0x4(%rsi),%esi
 29f0bdc:	cmp    %rsi,%rdx
 29f0bdf:	ja     29fb2e7 <wasm[0]::function[1015]::helper::object_read+0x1a3c7>
 29f0be5:	lea    0x20(%rax),%edx
 29f0be8:	mov    0x270(%rsp),%rsi
 29f0bf0:	mov    %edx,(%rsi)
 29f0bf2:	mov    0x2e0(%rsp),%r12
 29f0bfa:	mov    0x20(%r12),%rdx
 29f0bff:	lea    (%rdx,%rcx,1),%rsi
 29f0c03:	movl   $0xb0000042,(%rdx,%rcx,1)
 29f0c0a:	mov    0x190(%rsp),%rdi
 29f0c12:	mov    0x28(%rdi),%rdi
 29f0c16:	mov    0x120(%rdi),%edi
 29f0c1c:	mov    %edi,0x4(%rdx,%rcx,1)
 29f0c20:	mov    0x268(%rsp),%rdi
 29f0c28:	mov    %edi,0x8(%rdx,%rcx,1)
 29f0c2c:	mov    %eax,0xd8(%rsp)
 29f0c33:	mov    0x2a8(%rsp),%rcx
 29f0c3b:	mov    %rcx,0x10(%rsi)
 29f0c3f:	mov    0x2b0(%rsp),%rdx
 29f0c47:	mov    %edx,0x18(%rsi)
 29f0c4a:	mov    0xc8(%rsp),%eax
 29f0c51:	mov    %eax,0x1c(%rsi)
 29f0c54:	mov    0x270(%rsp),%rcx
 29f0c5c:	mov    (%rcx),%eax
 29f0c5e:	mov    %eax,%edx
 29f0c60:	lea    0x20(%rdx),%rcx
 29f0c64:	mov    0x270(%rsp),%rsi
 29f0c6c:	mov    0x4(%rsi),%esi
 29f0c6f:	cmp    %rsi,%rcx
 29f0c72:	ja     29fb32a <wasm[0]::function[1015]::helper::object_read+0x1a40a>
 29f0c78:	lea    0x20(%rax),%ecx
 29f0c7b:	mov    0x270(%rsp),%r10
 29f0c83:	mov    %ecx,(%r10)
 29f0c86:	mov    0x2e0(%rsp),%r12
 29f0c8e:	mov    0x20(%r12),%rsi
 29f0c93:	lea    (%rsi,%rdx,1),%rcx
 29f0c97:	movl   $0xb0000042,(%rsi,%rdx,1)
 29f0c9e:	mov    0x190(%rsp),%rdi
 29f0ca6:	mov    0x28(%rdi),%rdi
 29f0caa:	mov    0x120(%rdi),%edi
 29f0cb0:	mov    %edi,0x4(%rsi,%rdx,1)
 29f0cb4:	mov    0x268(%rsp),%rdi
 29f0cbc:	mov    %edi,0x8(%rsi,%rdx,1)
 29f0cc0:	mov    %eax,0xc8(%rsp)
 29f0cc7:	mov    0x1c0(%rsp),%r8
 29f0ccf:	mov    %r8,0x10(%rcx)
 29f0cd3:	mov    0x1b8(%rsp),%rsi
 29f0cdb:	mov    %esi,0x18(%rcx)
 29f0cde:	mov    0x100(%rsp),%esi
 29f0ce5:	mov    %esi,0x1c(%rcx)
 29f0ce8:	mov    0xd8(%rsp),%edi
 29f0cef:	test   %edi,%edi
 29f0cf1:	je     29fc321 <wasm[0]::function[1015]::helper::object_read+0x1b401>
 29f0cf7:	test   %eax,%eax
 29f0cf9:	je     29fc323 <wasm[0]::function[1015]::helper::object_read+0x1b403>
 29f0cff:	mov    0x270(%rsp),%rcx
 29f0d07:	mov    (%rcx),%eax
 29f0d09:	mov    %eax,%r11d
 29f0d0c:	lea    0x20(%r11),%rcx
 29f0d10:	mov    0x270(%rsp),%rdx
 29f0d18:	mov    0x4(%rdx),%edx
 29f0d1b:	cmp    %rdx,%rcx
 29f0d1e:	ja     29fb365 <wasm[0]::function[1015]::helper::object_read+0x1a445>
 29f0d24:	lea    0x20(%rax),%ecx
 29f0d27:	mov    0x270(%rsp),%rdx
 29f0d2f:	mov    %ecx,(%rdx)
 29f0d31:	mov    0x2e0(%rsp),%r12
 29f0d39:	mov    0x20(%r12),%rdx
 29f0d3e:	lea    (%rdx,%r11,1),%rcx
 29f0d42:	movl   $0xa800000e,(%rdx,%r11,1)
 29f0d4a:	mov    0x190(%rsp),%rsi
 29f0d52:	mov    0x28(%rsi),%rsi
 29f0d56:	mov    0x1b4(%rsi),%esi
 29f0d5c:	mov    %esi,0x4(%rdx,%r11,1)
 29f0d61:	mov    0x268(%rsp),%rsi
 29f0d69:	mov    %esi,0x8(%rdx,%r11,1)
 29f0d6e:	movl   $0x2,0x10(%rcx)
 29f0d75:	test   %eax,%eax
 29f0d77:	je     29fc325 <wasm[0]::function[1015]::helper::object_read+0x1b405>
 29f0d7d:	mov    0x2e0(%rsp),%r12
 29f0d85:	mov    0x28(%r12),%rdx
 29f0d8a:	mov    0x20(%r12),%rsi
 29f0d8f:	mov    %eax,%r8d
 29f0d92:	lea    0x10(%rsi,%r8,1),%rdi
 29f0d97:	xor    %rcx,%rcx
 29f0d9a:	cmp    %rdx,%r8
 29f0d9d:	cmova  %rcx,%rdi
 29f0da1:	mov    (%rdi),%r8d
 29f0da4:	test   %r8d,%r8d
 29f0da7:	je     29fc327 <wasm[0]::function[1015]::helper::object_read+0x1b407>
 29f0dad:	mov    %r8d,%r9d
 29f0db0:	shl    $0x2,%r9
 29f0db4:	shr    $0x20,%r9
 29f0db8:	test   %r9,%r9
 29f0dbb:	jne    29fc329 <wasm[0]::function[1015]::helper::object_read+0x1b409>
 29f0dc1:	shl    $0x2,%r8d
 29f0dc5:	add    $0x14,%r8d
 29f0dc9:	jb     29fc32b <wasm[0]::function[1015]::helper::object_read+0x1b40b>
 29f0dcf:	mov    %rax,%r10
 29f0dd2:	add    %r8d,%r10d
 29f0dd5:	jb     29fc32d <wasm[0]::function[1015]::helper::object_read+0x1b40d>
 29f0ddb:	mov    0xd8(%rsp),%r9d
 29f0de3:	mov    %r10d,%r11d
 29f0de6:	lea    (%rsi,%r11,1),%r10
 29f0dea:	cmp    %rdx,%r11
 29f0ded:	cmova  %rcx,%r10
 29f0df1:	sub    $0x14,%r8d
 29f0df5:	sub    %r8,%r10
 29f0df8:	mov    %r9d,(%r10)
 29f0dfb:	mov    (%rdi),%edi
 29f0dfd:	cmp    $0x1,%edi
 29f0e00:	jbe    29fc32f <wasm[0]::function[1015]::helper::object_read+0x1b40f>
 29f0e06:	mov    %edi,%r8d
 29f0e09:	shl    $0x2,%r8
 29f0e0d:	shr    $0x20,%r8
 29f0e11:	test   %r8,%r8
 29f0e14:	jne    29fc331 <wasm[0]::function[1015]::helper::object_read+0x1b411>
 29f0e1a:	shl    $0x2,%edi
 29f0e1d:	add    $0x14,%edi
 29f0e20:	jb     29fc333 <wasm[0]::function[1015]::helper::object_read+0x1b413>
 29f0e26:	mov    %rax,%r9
 29f0e29:	add    %edi,%r9d
 29f0e2c:	jb     29fc335 <wasm[0]::function[1015]::helper::object_read+0x1b415>
 29f0e32:	mov    0xc8(%rsp),%r8d
 29f0e3a:	mov    %r9d,%r9d
 29f0e3d:	add    %r9,%rsi
 29f0e40:	cmp    %rdx,%r9
 29f0e43:	cmova  %rcx,%rsi
 29f0e47:	sub    $0x18,%edi
 29f0e4a:	sub    %rdi,%rsi
 29f0e4d:	mov    %r8d,(%rsi)
 29f0e50:	mov    0x190(%rsp),%rsi
 29f0e58:	mov    0x8c0(%rsi),%edx
 29f0e5e:	mov    %edx,0xc8(%rsp)
 29f0e65:	xor    %r9d,%r9d
 29f0e68:	test   %edx,%edx
 29f0e6a:	je     29fc337 <wasm[0]::function[1015]::helper::object_read+0x1b417>
 29f0e70:	test   %eax,%eax
 29f0e72:	je     29fc339 <wasm[0]::function[1015]::helper::object_read+0x1b419>
 29f0e78:	mov    0x88(%rsp),%esi
 29f0e7f:	test   %esi,%esi
 29f0e81:	je     29fc33b <wasm[0]::function[1015]::helper::object_read+0x1b41b>
 29f0e87:	mov    0xe0(%rsp),%r8d
 29f0e8f:	mov    0x98(%rsp),%r10d
 29f0e97:	mov    0xc0(%rsp),%edi
 29f0e9e:	mov    %rcx,(%rsp)
 29f0ea2:	mov    %r10d,0x8(%rsp)
 29f0ea7:	mov    %eax,0x10(%rsp)
 29f0eab:	mov    %edx,0x18(%rsp)
 29f0eaf:	mov    %edi,0x20(%rsp)
 29f0eb3:	mov    %esi,0x28(%rsp)
 29f0eb7:	mov    %rbx,%rdx
 29f0eba:	mov    0x190(%rsp),%rsi
 29f0ec2:	mov    0x190(%rsp),%rdi
 29f0eca:	call   2adef00 <wasm[0]::function[1055]::helper::proxy_call>
 29f0ecf:	sub    $0x30,%rsp
 29f0ed3:	mov    %rax,0x258(%rsp)
 29f0edb:	mov    %rcx,0x260(%rsp)
 29f0ee3:	mov    %edx,0xe0(%rsp)
 29f0eea:	mov    0xc8(%rsp),%eax
 29f0ef1:	test   %eax,%eax
 29f0ef3:	je     29fc33d <wasm[0]::function[1015]::helper::object_read+0x1b41d>
 29f0ef9:	mov    0x190(%rsp),%rcx
 29f0f01:	mov    %eax,0x8c0(%rcx)
 29f0f07:	cmp    $0x2,%esi
 29f0f0a:	jne    29f0f15 <wasm[0]::function[1015]::helper::object_read+0xfff5>
 29f0f10:	xor    %esi,%esi
 29f0f12:	mov    %rsi,%rdi
 29f0f15:	cmp    $0x1,%esi
 29f0f18:	je     29f67d7 <wasm[0]::function[1015]::helper::object_read+0x158b7>
 29f0f1e:	mov    0xb8(%rsp),%eax
 29f0f25:	mov    0xa8(%rsp),%ecx
 29f0f2c:	mov    %rcx,%r15
 29f0f2f:	mov    0xc0(%rsp),%ecx
 29f0f36:	mov    0x258(%rsp),%rdx
 29f0f3e:	mov    0x258(%rsp),%rsi
 29f0f46:	test   %esi,%edx
 29f0f48:	je     29f8fba <wasm[0]::function[1015]::helper::object_read+0x1809a>
 29f0f4e:	mov    $0x12b,%edx
 29f0f53:	mov    0x190(%rsp),%rsi
 29f0f5b:	mov    0x190(%rsp),%rdi
 29f0f63:	call   2f307a0 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 29f0f68:	mov    %eax,0xa8(%rsp)
 29f0f6f:	xor    %r10d,%r10d
 29f0f72:	test   %eax,%eax
 29f0f74:	je     29fc33f <wasm[0]::function[1015]::helper::object_read+0x1b41f>
 29f0f7a:	movl   $0x0,0xc8(%rsp)
 29f0f85:	mov    0xe0(%rsp),%r11d
 29f0f8d:	mov    0xb8(%rsp),%esi
 29f0f94:	mov    0xc0(%rsp),%edx
 29f0f9b:	mov    0x258(%rsp),%rcx
 29f0fa3:	cmp    $0x6,%ecx
 29f0fa6:	sete   %cl
 29f0fa9:	mov    0x258(%rsp),%rax
 29f0fb1:	cmp    $0x7,%eax
 29f0fb4:	sete   %dil
 29f0fb8:	or     %edi,%ecx
 29f0fba:	mov    0x258(%rsp),%rdi
 29f0fc2:	cmp    $0x8,%edi
 29f0fc5:	sete   %dil
 29f0fc9:	or     %edi,%ecx
 29f0fcb:	mov    0x258(%rsp),%rdi
 29f0fd3:	cmp    $0x9,%edi
 29f0fd6:	sete   %dil
 29f0fda:	or     %edi,%ecx
 29f0fdc:	xor    %r8,%r8
 29f0fdf:	test   %cl,%cl
 29f0fe1:	mov    %rcx,0x250(%rsp)
 29f0fe9:	jne    29f1007 <wasm[0]::function[1015]::helper::object_read+0x100e7>
 29f0fef:	mov    %r10,%r9
 29f0ff2:	mov    %r8,0x1f0(%rsp)
 29f0ffa:	mov    %r10,0x1f8(%rsp)
 29f1002:	jmp    29f1b0e <wasm[0]::function[1015]::helper::object_read+0x10bee>
 29f1007:	mov    0xe0(%rsp),%r8d
 29f100f:	mov    0x260(%rsp),%rcx
 29f1017:	mov    0x258(%rsp),%rdx
 29f101f:	mov    0x190(%rsp),%rsi
 29f1027:	mov    0x190(%rsp),%rdi
 29f102f:	call   2a5f620 <wasm[0]::function[1039]::helper::object_header_projection>
 29f1034:	mov    %eax,0x98(%rsp)
 29f103b:	test   %eax,%eax
 29f103d:	je     29fc341 <wasm[0]::function[1015]::helper::object_read+0x1b421>
 29f1043:	test   %eax,%eax
 29f1045:	je     29fc343 <wasm[0]::function[1015]::helper::object_read+0x1b423>
 29f104b:	mov    0x2e0(%rsp),%r12
 29f1053:	mov    0x28(%r12),%rcx
 29f1058:	mov    0x20(%r12),%rdx
 29f105d:	mov    %eax,%eax
 29f105f:	lea    (%rdx,%rax,1),%r11
 29f1063:	xor    %rdx,%rdx
 29f1066:	cmp    %rcx,%rax
 29f1069:	cmova  %rdx,%r11
 29f106d:	mov    0x14(%r11),%eax
 29f1071:	mov    %eax,0x88(%rsp)
 29f1078:	test   %eax,%eax
 29f107a:	je     29fc345 <wasm[0]::function[1015]::helper::object_read+0x1b425>
 29f1080:	mov    0x88(%rsp),%ecx
 29f1087:	xor    %eax,%eax
 29f1089:	test   $0x1,%ecx
 29f108f:	jne    29f10e9 <wasm[0]::function[1015]::helper::object_read+0x101c9>
 29f1095:	mov    0x2e0(%rsp),%r12
 29f109d:	mov    0x28(%r12),%rax
 29f10a2:	mov    0x20(%r12),%rsi
 29f10a7:	mov    %ecx,%edx
 29f10a9:	lea    0x4(%rsi,%rdx,1),%rcx
 29f10ae:	xor    %rsi,%rsi
 29f10b1:	cmp    %rax,%rdx
 29f10b4:	cmova  %rsi,%rcx
 29f10b8:	mov    (%rcx),%esi
 29f10ba:	mov    0x190(%rsp),%rax
 29f10c2:	mov    0x28(%rax),%rax
 29f10c6:	mov    0x158(%rax),%edx
 29f10cc:	cmp    %edx,%esi
 29f10ce:	sete   %al
 29f10d1:	movzbl %al,%eax
 29f10d4:	cmp    %edx,%esi
 29f10d6:	je     29f10e9 <wasm[0]::function[1015]::helper::object_read+0x101c9>
 29f10dc:	mov    0x190(%rsp),%rdi
 29f10e4:	call   3018e75 <wasmtime_builtin_is_subtype>
 29f10e9:	test   %eax,%eax
 29f10eb:	jne    29f132a <wasm[0]::function[1015]::helper::object_read+0x1040a>
 29f10f1:	mov    0x98(%rsp),%edx
 29f10f8:	xor    %ebx,%ebx
 29f10fa:	test   %edx,%edx
 29f10fc:	je     29fc347 <wasm[0]::function[1015]::helper::object_read+0x1b427>
 29f1102:	mov    0xa8(%rsp),%r9d
 29f110a:	mov    $0x4,%ecx
 29f110f:	xor    %r8,%r8
 29f1112:	mov    0x190(%rsp),%rsi
 29f111a:	mov    0x190(%rsp),%rdi
 29f1122:	call   2a58e20 <wasm[0]::function[1032]::helper::ordinary_property_find>
 29f1127:	test   %eax,%eax
 29f1129:	je     29f1163 <wasm[0]::function[1015]::helper::object_read+0x10243>
 29f112f:	test   %eax,%eax
 29f1131:	je     29fc349 <wasm[0]::function[1015]::helper::object_read+0x1b429>
 29f1137:	test   %eax,%eax
 29f1139:	je     29fc34b <wasm[0]::function[1015]::helper::object_read+0x1b42b>
 29f113f:	mov    0x2e0(%rsp),%r12
 29f1147:	mov    0x28(%r12),%rcx
 29f114c:	mov    %eax,%edx
 29f114e:	mov    %rdx,%rax
 29f1151:	add    0x20(%r12),%rax
 29f1156:	xor    %rsi,%rsi
 29f1159:	cmp    %rcx,%rdx
 29f115c:	cmova  %rsi,%rax
 29f1160:	mov    0x14(%rax),%ebx
 29f1163:	mov    0xc8(%rsp),%r9d
 29f116b:	xor    %r8,%r8
 29f116e:	xor    %r10d,%r10d
 29f1171:	test   %ebx,%ebx
 29f1173:	je     29f12ff <wasm[0]::function[1015]::helper::object_read+0x103df>
 29f1179:	test   %ebx,%ebx
 29f117b:	je     29fc34d <wasm[0]::function[1015]::helper::object_read+0x1b42d>
 29f1181:	mov    0x2e0(%rsp),%r12
 29f1189:	mov    0x28(%r12),%rcx
 29f118e:	mov    0x20(%r12),%rax
 29f1193:	mov    %ebx,%edx
 29f1195:	add    %rdx,%rax
 29f1198:	xor    %r8,%r8
 29f119b:	cmp    %rcx,%rdx
 29f119e:	cmova  %r8,%rax
 29f11a2:	mov    0x10(%rax),%ecx
 29f11a5:	mov    0xc8(%rsp),%r9d
 29f11ad:	xor    %r10d,%r10d
 29f11b0:	test   $0x1,%ecx
 29f11b6:	jne    29f12ff <wasm[0]::function[1015]::helper::object_read+0x103df>
 29f11bc:	mov    0x14(%rax),%edx
 29f11bf:	test   %edx,%edx
 29f11c1:	je     29fc34f <wasm[0]::function[1015]::helper::object_read+0x1b42f>
 29f11c7:	xor    %eax,%eax
 29f11c9:	test   $0x1,%edx
 29f11cf:	jne    29f1212 <wasm[0]::function[1015]::helper::object_read+0x102f2>
 29f11d5:	mov    0x2e0(%rsp),%r12
 29f11dd:	mov    0x28(%r12),%rax
 29f11e2:	mov    0x20(%r12),%rcx
 29f11e7:	mov    %edx,%esi
 29f11e9:	lea    0x4(%rcx,%rsi,1),%rcx
 29f11ee:	xor    %rdi,%rdi
 29f11f1:	cmp    %rax,%rsi
 29f11f4:	cmova  %rdi,%rcx
 29f11f8:	mov    (%rcx),%eax
 29f11fa:	mov    0x190(%rsp),%rsi
 29f1202:	mov    0x28(%rsi),%rcx
 29f1206:	cmp    0x120(%rcx),%eax
 29f120c:	sete   %al
 29f120f:	movzbl %al,%eax
 29f1212:	test   %eax,%eax
 29f1214:	jne    29f1272 <wasm[0]::function[1015]::helper::object_read+0x10352>
 29f121a:	mov    0x190(%rsp),%rsi
 29f1222:	mov    0x190(%rsp),%rdi
 29f122a:	call   2a01ba0 <wasm[0]::function[1024]::helper::property_value_resolve>
 29f122f:	test   %eax,%eax
 29f1231:	je     29fc351 <wasm[0]::function[1015]::helper::object_read+0x1b431>
 29f1237:	test   %eax,%eax
 29f1239:	je     29fc353 <wasm[0]::function[1015]::helper::object_read+0x1b433>
 29f123f:	mov    0x2e0(%rsp),%r12
 29f1247:	mov    0x28(%r12),%rsi
 29f124c:	mov    0x20(%r12),%r8
 29f1251:	mov    %eax,%edi
 29f1253:	lea    (%r8,%rdi,1),%rax
 29f1257:	xor    %r8,%r8
 29f125a:	cmp    %rsi,%rdi
 29f125d:	cmova  %r8,%rax
 29f1261:	mov    0x18(%rax),%r10d
 29f1265:	mov    0x10(%rax),%r8
 29f1269:	mov    0x1c(%rax),%r9d
 29f126d:	jmp    29f12ff <wasm[0]::function[1015]::helper::object_read+0x103df>
 29f1272:	xor    %esi,%esi
 29f1274:	test   $0x1,%edx
 29f127a:	jne    29f12c2 <wasm[0]::function[1015]::helper::object_read+0x103a2>
 29f1280:	mov    0x2e0(%rsp),%r12
 29f1288:	mov    0x28(%r12),%r9
 29f128d:	mov    0x20(%r12),%r11
 29f1292:	mov    %edx,%r10d
 29f1295:	lea    0x4(%r11,%r10,1),%rsi
 29f129a:	xor    %r11,%r11
 29f129d:	cmp    %r9,%r10
 29f12a0:	cmova  %r11,%rsi
 29f12a4:	mov    (%rsi),%r10d
 29f12a7:	mov    0x190(%rsp),%rsi
 29f12af:	mov    0x28(%rsi),%r11
 29f12b3:	cmp    0x120(%r11),%r10d
 29f12ba:	sete   %r11b
 29f12be:	movzbl %r11b,%esi
 29f12c2:	test   %esi,%esi
 29f12c4:	je     29fc355 <wasm[0]::function[1015]::helper::object_read+0x1b435>
 29f12ca:	test   %edx,%edx
 29f12cc:	je     29fc357 <wasm[0]::function[1015]::helper::object_read+0x1b437>
 29f12d2:	mov    0x2e0(%rsp),%r12
 29f12da:	mov    0x28(%r12),%rcx
 29f12df:	mov    0x20(%r12),%rax
 29f12e4:	mov    %edx,%edx
 29f12e6:	add    %rdx,%rax
 29f12e9:	xor    %rsi,%rsi
 29f12ec:	cmp    %rcx,%rdx
 29f12ef:	cmova  %rsi,%rax
 29f12f3:	mov    0x18(%rax),%r10d
 29f12f7:	mov    0x10(%rax),%r8
 29f12fb:	mov    0x1c(%rax),%r9d
 29f12ff:	mov    0xe0(%rsp),%r11d
 29f1307:	mov    0xb8(%rsp),%esi
 29f130e:	mov    0xc0(%rsp),%edx
 29f1315:	mov    %r8,0x1f0(%rsp)
 29f131d:	mov    %r10,0x1f8(%rsp)
 29f1325:	jmp    29f1b0e <wasm[0]::function[1015]::helper::object_read+0x10bee>
 29f132a:	mov    0x88(%rsp),%eax
 29f1331:	test   %eax,%eax
 29f1333:	je     29fc359 <wasm[0]::function[1015]::helper::object_read+0x1b439>
 29f1339:	mov    0x88(%rsp),%ecx
 29f1340:	xor    %eax,%eax
 29f1342:	test   $0x1,%ecx
 29f1348:	jne    29f13a2 <wasm[0]::function[1015]::helper::object_read+0x10482>
 29f134e:	mov    0x2e0(%rsp),%r12
 29f1356:	mov    0x28(%r12),%rax
 29f135b:	mov    0x20(%r12),%rsi
 29f1360:	mov    %ecx,%edx
 29f1362:	lea    0x4(%rsi,%rdx,1),%rcx
 29f1367:	xor    %rsi,%rsi
 29f136a:	cmp    %rax,%rdx
 29f136d:	cmova  %rsi,%rcx
 29f1371:	mov    (%rcx),%esi
 29f1373:	mov    0x190(%rsp),%rax
 29f137b:	mov    0x28(%rax),%rax
 29f137f:	mov    0x158(%rax),%edx
 29f1385:	cmp    %edx,%esi
 29f1387:	sete   %al
 29f138a:	movzbl %al,%eax
 29f138d:	cmp    %edx,%esi
 29f138f:	je     29f13a2 <wasm[0]::function[1015]::helper::object_read+0x10482>
 29f1395:	mov    0x190(%rsp),%rdi
 29f139d:	call   3018e75 <wasmtime_builtin_is_subtype>
 29f13a2:	test   %eax,%eax
 29f13a4:	je     29fc35b <wasm[0]::function[1015]::helper::object_read+0x1b43b>
 29f13aa:	mov    0x88(%rsp),%edi
 29f13b1:	mov    0xe0(%rsp),%r11d
 29f13b9:	mov    0xc8(%rsp),%r9d
 29f13c1:	mov    0xb8(%rsp),%esi
 29f13c8:	mov    0xc0(%rsp),%edx
 29f13cf:	xor    %ecx,%ecx
 29f13d1:	mov    %rcx,%r14
 29f13d4:	test   %edi,%edi
 29f13d6:	je     29fc35d <wasm[0]::function[1015]::helper::object_read+0x1b43d>
 29f13dc:	test   %edi,%edi
 29f13de:	je     29fc35f <wasm[0]::function[1015]::helper::object_read+0x1b43f>
 29f13e4:	mov    0x2e0(%rsp),%r12
 29f13ec:	mov    0x28(%r12),%rax
 29f13f1:	mov    0x20(%r12),%rcx
 29f13f6:	mov    %edi,%ebx
 29f13f8:	lea    (%rcx,%rbx,1),%r8
 29f13fc:	xor    %r10,%r10
 29f13ff:	cmp    %rax,%rbx
 29f1402:	cmova  %r10,%r8
 29f1406:	mov    0x10(%r8),%r8d
 29f140a:	test   %r8d,%r8d
 29f140d:	je     29fc361 <wasm[0]::function[1015]::helper::object_read+0x1b441>
 29f1413:	test   %r8d,%r8d
 29f1416:	je     29fc363 <wasm[0]::function[1015]::helper::object_read+0x1b443>
 29f141c:	mov    %r8d,%ebx
 29f141f:	lea    (%rcx,%rbx,1),%r8
 29f1423:	cmp    %rax,%rbx
 29f1426:	cmova  %r10,%r8
 29f142a:	mov    0x10(%r8),%r8d
 29f142e:	test   %r8d,%r8d
 29f1431:	je     29fc365 <wasm[0]::function[1015]::helper::object_read+0x1b445>
 29f1437:	test   %r8d,%r8d
 29f143a:	je     29fc367 <wasm[0]::function[1015]::helper::object_read+0x1b447>
 29f1440:	mov    %r8d,%ebx
 29f1443:	lea    0x10(%rcx,%rbx,1),%rcx
 29f1448:	cmp    %rax,%rbx
 29f144b:	cmova  %r10,%rcx
 29f144f:	mov    (%rcx),%ebx
 29f1451:	mov    0xa8(%rsp),%r10d
 29f1459:	mov    0x190(%rsp),%rax
 29f1461:	mov    0x28(%rax),%rax
 29f1465:	mov    0x234(%rax),%r13d
 29f146c:	mov    %r14,%r15
 29f146f:	mov    %r8d,0xd8(%rsp)
 29f1477:	mov    %r10d,0x98(%rsp)
 29f147f:	mov    %edi,0xc0(%rsp)
 29f1486:	mov    %r11d,0xb8(%rsp)
 29f148e:	mov    %r9d,0xc8(%rsp)
 29f1496:	mov    %esi,0x88(%rsp)
 29f149d:	mov    %edx,0xa8(%rsp)
 29f14a4:	mov    0x2e8(%rsp),%rax
 29f14ac:	mov    (%rax),%rcx
 29f14af:	mov    0x228(%rsp),%rax
 29f14b7:	cmp    %rax,%rcx
 29f14ba:	jae    29fb3a6 <wasm[0]::function[1015]::helper::object_read+0x1a486>
 29f14c0:	mov    0xc0(%rsp),%edi
 29f14c7:	mov    0xb8(%rsp),%r11d
 29f14cf:	mov    0xc8(%rsp),%r9d
 29f14d7:	mov    0x88(%rsp),%esi
 29f14de:	mov    0xa8(%rsp),%edx
 29f14e5:	mov    %r14,%rcx
 29f14e8:	cmp    %ebx,%ecx
 29f14ea:	jb     29f14f8 <wasm[0]::function[1015]::helper::object_read+0x105d8>
 29f14f0:	mov    %r15,%rax
 29f14f3:	jmp    29f16cc <wasm[0]::function[1015]::helper::object_read+0x107ac>
 29f14f8:	mov    0xd8(%rsp),%eax
 29f14ff:	test   %eax,%eax
 29f1501:	je     29fc369 <wasm[0]::function[1015]::helper::object_read+0x1b449>
 29f1507:	test   %eax,%eax
 29f1509:	je     29fc36b <wasm[0]::function[1015]::helper::object_read+0x1b44b>
 29f150f:	mov    0x2e0(%rsp),%r12
 29f1517:	mov    0x28(%r12),%r11
 29f151c:	mov    0x20(%r12),%rdx
 29f1521:	mov    %eax,%edi
 29f1523:	lea    0x10(%rdx,%rdi,1),%r8
 29f1528:	xor    %rsi,%rsi
 29f152b:	cmp    %r11,%rdi
 29f152e:	cmova  %rsi,%r8
 29f1532:	mov    (%r8),%edi
 29f1535:	cmp    %edi,%ecx
 29f1537:	jae    29fc36d <wasm[0]::function[1015]::helper::object_read+0x1b44d>
 29f153d:	mov    %edi,%r8d
 29f1540:	shl    $0x2,%r8
 29f1544:	shr    $0x20,%r8
 29f1548:	test   %r8,%r8
 29f154b:	jne    29fc36f <wasm[0]::function[1015]::helper::object_read+0x1b44f>
 29f1551:	shl    $0x2,%edi
 29f1554:	add    $0x14,%edi
 29f1557:	jb     29fc371 <wasm[0]::function[1015]::helper::object_read+0x1b451>
 29f155d:	add    %edi,%eax
 29f155f:	jb     29fc373 <wasm[0]::function[1015]::helper::object_read+0x1b453>
 29f1565:	mov    %eax,%r8d
 29f1568:	lea    (%rdx,%r8,1),%rax
 29f156c:	cmp    %r11,%r8
 29f156f:	cmova  %rsi,%rax
 29f1573:	mov    %rcx,%rdx
 29f1576:	shl    $0x2,%edx
 29f1579:	mov    %rcx,%r14
 29f157c:	lea    0x14(%rdx),%ecx
 29f157f:	sub    %ecx,%edi
 29f1581:	sub    %rdi,%rax
 29f1584:	mov    (%rax),%edx
 29f1586:	test   %edx,%edx
 29f1588:	je     29fc375 <wasm[0]::function[1015]::helper::object_read+0x1b455>
 29f158e:	mov    0x98(%rsp),%eax
 29f1595:	cmp    %eax,%edx
 29f1597:	je     29f166b <wasm[0]::function[1015]::helper::object_read+0x1074b>
 29f159d:	xor    %ecx,%ecx
 29f159f:	test   %edx,%edx
 29f15a1:	je     29f15e3 <wasm[0]::function[1015]::helper::object_read+0x106c3>
 29f15a7:	xor    %ecx,%ecx
 29f15a9:	test   $0x1,%edx
 29f15af:	jne    29f15e3 <wasm[0]::function[1015]::helper::object_read+0x106c3>
 29f15b5:	mov    0x2e0(%rsp),%r12
 29f15bd:	mov    0x28(%r12),%rcx
 29f15c2:	mov    0x20(%r12),%rsi
 29f15c7:	mov    %edx,%edi
 29f15c9:	lea    0x4(%rsi,%rdi,1),%rsi
 29f15ce:	xor    %r8,%r8
 29f15d1:	cmp    %rcx,%rdi
 29f15d4:	cmova  %r8,%rsi
 29f15d8:	mov    (%rsi),%ecx
 29f15da:	cmp    %r13d,%ecx
 29f15dd:	sete   %cl
 29f15e0:	movzbl %cl,%ecx
 29f15e3:	test   %ecx,%ecx
 29f15e5:	je     29fc377 <wasm[0]::function[1015]::helper::object_read+0x1b457>
 29f15eb:	xor    %ecx,%ecx
 29f15ed:	test   %eax,%eax
 29f15ef:	je     29f1637 <wasm[0]::function[1015]::helper::object_read+0x10717>
 29f15f5:	mov    0x98(%rsp),%eax
 29f15fc:	xor    %ecx,%ecx
 29f15fe:	test   $0x1,%eax
 29f1603:	jne    29f1637 <wasm[0]::function[1015]::helper::object_read+0x10717>
 29f1609:	mov    0x2e0(%rsp),%r12
 29f1611:	mov    0x28(%r12),%rcx
 29f1616:	mov    0x20(%r12),%rdi
 29f161b:	mov    %eax,%esi
 29f161d:	lea    0x4(%rdi,%rsi,1),%rax
 29f1622:	xor    %rdi,%rdi
 29f1625:	cmp    %rcx,%rsi
 29f1628:	cmova  %rdi,%rax
 29f162c:	mov    (%rax),%eax
 29f162e:	cmp    %r13d,%eax
 29f1631:	sete   %al
 29f1634:	movzbl %al,%ecx
 29f1637:	test   %ecx,%ecx
 29f1639:	je     29fc379 <wasm[0]::function[1015]::helper::object_read+0x1b459>
 29f163f:	mov    0x98(%rsp),%ecx
 29f1646:	xor    %r8d,%r8d
 29f1649:	test   %ecx,%ecx
 29f164b:	je     29fc37b <wasm[0]::function[1015]::helper::object_read+0x1b45b>
 29f1651:	mov    0x190(%rsp),%rsi
 29f1659:	mov    0x190(%rsp),%rdi
 29f1661:	call   2ae54e0 <wasm[0]::function[1057]::helper::string_equality>
 29f1666:	jmp    29f1673 <wasm[0]::function[1015]::helper::object_read+0x10753>
 29f166b:	mov    0x278(%rsp),%rax
 29f1673:	mov    0xd8(%rsp),%r8d
 29f167b:	mov    0x98(%rsp),%r10d
 29f1683:	mov    0xc0(%rsp),%edi
 29f168a:	mov    0xb8(%rsp),%r11d
 29f1692:	mov    0xc8(%rsp),%r9d
 29f169a:	mov    0x88(%rsp),%esi
 29f16a1:	mov    0xa8(%rsp),%edx
 29f16a8:	test   %eax,%eax
 29f16aa:	je     29f16b8 <wasm[0]::function[1015]::helper::object_read+0x10798>
 29f16b0:	mov    %r14,%rcx
 29f16b3:	jmp    29f16cc <wasm[0]::function[1015]::helper::object_read+0x107ac>
 29f16b8:	mov    %r14,%rcx
 29f16bb:	add    $0x1,%ecx
 29f16c1:	mov    %rcx,%r14
 29f16c4:	mov    %rax,%r15
 29f16c7:	jmp    29f146f <wasm[0]::function[1015]::helper::object_read+0x1054f>
 29f16cc:	xor    %r8,%r8
 29f16cf:	xor    %r10d,%r10d
 29f16d2:	test   %eax,%eax
 29f16d4:	jne    29f16ef <wasm[0]::function[1015]::helper::object_read+0x107cf>
 29f16da:	mov    %r8,0x1f0(%rsp)
 29f16e2:	mov    %r10,0x1f8(%rsp)
 29f16ea:	jmp    29f1b0e <wasm[0]::function[1015]::helper::object_read+0x10bee>
 29f16ef:	test   %edi,%edi
 29f16f1:	je     29fc37d <wasm[0]::function[1015]::helper::object_read+0x1b45d>
 29f16f7:	xor    %r8d,%r8d
 29f16fa:	test   $0x1,%edi
 29f1700:	jne    29f1748 <wasm[0]::function[1015]::helper::object_read+0x10828>
 29f1706:	mov    0x2e0(%rsp),%r12
 29f170e:	mov    0x28(%r12),%r8
 29f1713:	mov    0x20(%r12),%r9
 29f1718:	mov    %edi,%r10d
 29f171b:	lea    0x4(%r9,%r10,1),%r9
 29f1720:	xor    %rax,%rax
 29f1723:	cmp    %r8,%r10
 29f1726:	cmova  %rax,%r9
 29f172a:	mov    (%r9),%r8d
 29f172d:	mov    0x190(%rsp),%rax
 29f1735:	mov    0x28(%rax),%r9
 29f1739:	cmp    0x160(%r9),%r8d
 29f1740:	sete   %r8b
 29f1744:	movzbl %r8b,%r8d
 29f1748:	test   %r8d,%r8d
 29f174b:	jne    29f198a <wasm[0]::function[1015]::helper::object_read+0x10a6a>
 29f1751:	xor    %eax,%eax
 29f1753:	test   $0x1,%edi
 29f1759:	jne    29f179f <wasm[0]::function[1015]::helper::object_read+0x1087f>
 29f175f:	mov    0x2e0(%rsp),%r12
 29f1767:	mov    0x28(%r12),%rax
 29f176c:	mov    0x20(%r12),%r8
 29f1771:	mov    %edi,%r9d
 29f1774:	lea    0x4(%r8,%r9,1),%r8
 29f1779:	xor    %r10,%r10
 29f177c:	cmp    %rax,%r9
 29f177f:	cmova  %r10,%r8
 29f1783:	mov    (%r8),%eax
 29f1786:	mov    0x190(%rsp),%r8
 29f178e:	mov    0x28(%r8),%r8
 29f1792:	cmp    0x15c(%r8),%eax
 29f1799:	sete   %al
 29f179c:	movzbl %al,%eax
 29f179f:	test   %eax,%eax
 29f17a1:	je     29fc37f <wasm[0]::function[1015]::helper::object_read+0x1b45f>
 29f17a7:	test   %edi,%edi
 29f17a9:	je     29fc381 <wasm[0]::function[1015]::helper::object_read+0x1b461>
 29f17af:	mov    0x2e0(%rsp),%r12
 29f17b7:	mov    0x28(%r12),%rax
 29f17bc:	mov    0x20(%r12),%r10
 29f17c1:	mov    %edi,%r9d
 29f17c4:	lea    (%r10,%r9,1),%rdi
 29f17c8:	xor    %r8,%r8
 29f17cb:	cmp    %rax,%r9
 29f17ce:	cmova  %r8,%rdi
 29f17d2:	mov    0x14(%rdi),%r13d
 29f17d6:	mov    0x18(%rdi),%r9d
 29f17da:	mov    0x1c(%rdi),%edi
 29f17dd:	test   %r13d,%r13d
 29f17e0:	je     29fc383 <wasm[0]::function[1015]::helper::object_read+0x1b463>
 29f17e6:	test   %r13d,%r13d
 29f17e9:	je     29fc385 <wasm[0]::function[1015]::helper::object_read+0x1b465>
 29f17ef:	mov    %r13d,%r12d
 29f17f2:	lea    0x10(%r10,%r12,1),%rbx
 29f17f7:	cmp    %rax,%r12
 29f17fa:	cmova  %r8,%rbx
 29f17fe:	mov    (%rbx),%ebx
 29f1800:	cmp    %ebx,%ecx
 29f1802:	jae    29fc387 <wasm[0]::function[1015]::helper::object_read+0x1b467>
 29f1808:	mov    %ebx,%r12d
 29f180b:	shr    $0x20,%r12
 29f180f:	test   %r12,%r12
 29f1812:	jne    29fc389 <wasm[0]::function[1015]::helper::object_read+0x1b469>
 29f1818:	add    $0x14,%ebx
 29f181b:	jb     29fc38b <wasm[0]::function[1015]::helper::object_read+0x1b46b>
 29f1821:	add    %ebx,%r13d
 29f1824:	jb     29fc38d <wasm[0]::function[1015]::helper::object_read+0x1b46d>
 29f182a:	mov    %r13d,%r12d
 29f182d:	add    %r12,%r10
 29f1830:	cmp    %rax,%r12
 29f1833:	cmova  %r8,%r10
 29f1837:	lea    0x14(%rcx),%eax
 29f183a:	sub    %eax,%ebx
 29f183c:	sub    %rbx,%r10
 29f183f:	movzbq (%r10),%r10
 29f1843:	test   %r9d,%r9d
 29f1846:	je     29f18dc <wasm[0]::function[1015]::helper::object_read+0x109bc>
 29f184c:	test   %r9d,%r9d
 29f184f:	je     29fc38f <wasm[0]::function[1015]::helper::object_read+0x1b46f>
 29f1855:	test   %r9d,%r9d
 29f1858:	je     29fc391 <wasm[0]::function[1015]::helper::object_read+0x1b471>
 29f185e:	mov    0x2e0(%rsp),%r12
 29f1866:	mov    0x28(%r12),%rax
 29f186b:	mov    0x20(%r12),%r8
 29f1870:	mov    %r9d,%r13d
 29f1873:	lea    0x10(%r8,%r13,1),%r12
 29f1878:	xor    %rbx,%rbx
 29f187b:	cmp    %rax,%r13
 29f187e:	cmova  %rbx,%r12
 29f1882:	mov    (%r12),%r12d
 29f1886:	cmp    %r12d,%ecx
 29f1889:	jae    29fc393 <wasm[0]::function[1015]::helper::object_read+0x1b473>
 29f188f:	mov    %r12d,%r13d
 29f1892:	shl    $0x3,%r13
 29f1896:	shr    $0x20,%r13
 29f189a:	test   %r13,%r13
 29f189d:	jne    29fc395 <wasm[0]::function[1015]::helper::object_read+0x1b475>
 29f18a3:	shl    $0x3,%r12d
 29f18a7:	add    $0x18,%r12d
 29f18ab:	jb     29fc397 <wasm[0]::function[1015]::helper::object_read+0x1b477>
 29f18b1:	add    %r12d,%r9d
 29f18b4:	jb     29fc399 <wasm[0]::function[1015]::helper::object_read+0x1b479>
 29f18ba:	mov    %r9d,%r9d
 29f18bd:	add    %r9,%r8
 29f18c0:	cmp    %rax,%r9
 29f18c3:	cmova  %rbx,%r8
 29f18c7:	mov    %rcx,%rax
 29f18ca:	shl    $0x3,%eax
 29f18cd:	add    $0x18,%eax
 29f18d3:	sub    %eax,%r12d
 29f18d6:	sub    %r12,%r8
 29f18d9:	mov    (%r8),%r8
 29f18dc:	xor    %r9d,%r9d
 29f18df:	test   %edi,%edi
 29f18e1:	je     29f1971 <wasm[0]::function[1015]::helper::object_read+0x10a51>
 29f18e7:	test   %edi,%edi
 29f18e9:	je     29fc39b <wasm[0]::function[1015]::helper::object_read+0x1b47b>
 29f18ef:	test   %edi,%edi
 29f18f1:	je     29fc39d <wasm[0]::function[1015]::helper::object_read+0x1b47d>
 29f18f7:	mov    0x2e0(%rsp),%r12
 29f18ff:	mov    0x28(%r12),%rax
 29f1904:	mov    0x20(%r12),%r9
 29f1909:	mov    %edi,%r13d
 29f190c:	lea    0x10(%r9,%r13,1),%r12
 29f1911:	xor    %rbx,%rbx
 29f1914:	cmp    %rax,%r13
 29f1917:	cmova  %rbx,%r12
 29f191b:	mov    (%r12),%r12d
 29f191f:	cmp    %r12d,%ecx
 29f1922:	jae    29fc39f <wasm[0]::function[1015]::helper::object_read+0x1b47f>
 29f1928:	mov    %r12d,%r13d
 29f192b:	shl    $0x2,%r13
 29f192f:	shr    $0x20,%r13
 29f1933:	test   %r13,%r13
 29f1936:	jne    29fc3a1 <wasm[0]::function[1015]::helper::object_read+0x1b481>
 29f193c:	shl    $0x2,%r12d
 29f1940:	add    $0x14,%r12d
 29f1944:	jb     29fc3a3 <wasm[0]::function[1015]::helper::object_read+0x1b483>
 29f194a:	add    %r12d,%edi
 29f194d:	jb     29fc3a5 <wasm[0]::function[1015]::helper::object_read+0x1b485>
 29f1953:	mov    %edi,%r13d
 29f1956:	lea    (%r9,%r13,1),%rdi
 29f195a:	cmp    %rax,%r13
 29f195d:	cmova  %rbx,%rdi
 29f1961:	shl    $0x2,%ecx
 29f1964:	lea    0x14(%rcx),%r9d
 29f1968:	sub    %r9d,%r12d
 29f196b:	sub    %r12,%rdi
 29f196e:	mov    (%rdi),%r9d
 29f1971:	movzbl %r10b,%r10d
 29f1975:	mov    %r8,0x1f0(%rsp)
 29f197d:	mov    %r10,0x1f8(%rsp)
 29f1985:	jmp    29f1b0e <wasm[0]::function[1015]::helper::object_read+0x10bee>
 29f198a:	xor    %eax,%eax
 29f198c:	test   $0x1,%edi
 29f1992:	jne    29f19d8 <wasm[0]::function[1015]::helper::object_read+0x10ab8>
 29f1998:	mov    0x2e0(%rsp),%r12
 29f19a0:	mov    0x28(%r12),%r9
 29f19a5:	mov    0x20(%r12),%rax
 29f19aa:	mov    %edi,%r10d
 29f19ad:	lea    0x4(%rax,%r10,1),%r8
 29f19b2:	xor    %rax,%rax
 29f19b5:	cmp    %r9,%r10
 29f19b8:	cmova  %rax,%r8
 29f19bc:	mov    (%r8),%r10d
 29f19bf:	mov    0x190(%rsp),%rax
 29f19c7:	mov    0x28(%rax),%rax
 29f19cb:	cmp    0x160(%rax),%r10d
 29f19d2:	sete   %al
 29f19d5:	movzbl %al,%eax
 29f19d8:	test   %eax,%eax
 29f19da:	je     29fc3a7 <wasm[0]::function[1015]::helper::object_read+0x1b487>
 29f19e0:	test   %edi,%edi
 29f19e2:	je     29fc3a9 <wasm[0]::function[1015]::helper::object_read+0x1b489>
 29f19e8:	mov    0x2e0(%rsp),%r12
 29f19f0:	mov    0x28(%r12),%rax
 29f19f5:	mov    0x20(%r12),%r8
 29f19fa:	mov    %edi,%edi
 29f19fc:	lea    (%r8,%rdi,1),%r10
 29f1a00:	xor    %r9,%r9
 29f1a03:	cmp    %rax,%rdi
 29f1a06:	cmova  %r9,%r10
 29f1a0a:	mov    0x10(%r10),%r10d
 29f1a0e:	test   %r10d,%r10d
 29f1a11:	je     29fc3ab <wasm[0]::function[1015]::helper::object_read+0x1b48b>
 29f1a17:	test   %r10d,%r10d
 29f1a1a:	je     29fc3ad <wasm[0]::function[1015]::helper::object_read+0x1b48d>
 29f1a20:	mov    %r10d,%ebx
 29f1a23:	lea    (%r8,%rbx,1),%r10
 29f1a27:	cmp    %rax,%rbx
 29f1a2a:	cmova  %r9,%r10
 29f1a2e:	mov    0x10(%r10),%r10d
 29f1a32:	test   %r10d,%r10d
 29f1a35:	je     29fc3af <wasm[0]::function[1015]::helper::object_read+0x1b48f>
 29f1a3b:	test   %r10d,%r10d
 29f1a3e:	je     29fc3b1 <wasm[0]::function[1015]::helper::object_read+0x1b491>
 29f1a44:	mov    %r10d,%r10d
 29f1a47:	lea    0x10(%r8,%r10,1),%r8
 29f1a4c:	cmp    %rax,%r10
 29f1a4f:	cmova  %r9,%r8
 29f1a53:	cmp    (%r8),%ecx
 29f1a56:	setae  %al
 29f1a59:	cmp    $0x2,%ecx
 29f1a5c:	setae  %r8b
 29f1a60:	or     %r8d,%eax
 29f1a63:	test   %al,%al
 29f1a65:	jne    29fc3b3 <wasm[0]::function[1015]::helper::object_read+0x1b493>
 29f1a6b:	mov    0x2e0(%rsp),%r12
 29f1a73:	mov    0x28(%r12),%r8
 29f1a78:	mov    %rdi,%rax
 29f1a7b:	add    0x20(%r12),%rax
 29f1a80:	xor    %r9,%r9
 29f1a83:	cmp    %r8,%rdi
 29f1a86:	cmova  %r9,%rax
 29f1a8a:	mov    0x14(%rax),%r10d
 29f1a8e:	test   %ecx,%ecx
 29f1a90:	je     29f1aca <wasm[0]::function[1015]::helper::object_read+0x10baa>
 29f1a96:	mov    0x2e0(%rsp),%r12
 29f1a9e:	mov    0x28(%r12),%r8
 29f1aa3:	mov    0x20(%r12),%rax
 29f1aa8:	add    %rdi,%rax
 29f1aab:	xor    %r9,%r9
 29f1aae:	cmp    %r8,%rdi
 29f1ab1:	cmova  %r9,%rax
 29f1ab5:	mov    0x20(%rax),%r8
 29f1ab9:	mov    0x2c(%rax),%r9d
 29f1abd:	mov    %r8,0x1f0(%rsp)
 29f1ac5:	jmp    29f1af9 <wasm[0]::function[1015]::helper::object_read+0x10bd9>
 29f1aca:	mov    0x2e0(%rsp),%r12
 29f1ad2:	mov    0x28(%r12),%r8
 29f1ad7:	mov    0x20(%r12),%rax
 29f1adc:	add    %rdi,%rax
 29f1adf:	xor    %r9,%r9
 29f1ae2:	cmp    %r8,%rdi
 29f1ae5:	cmova  %r9,%rax
 29f1ae9:	mov    0x18(%rax),%r8
 29f1aed:	mov    %r8,0x1f0(%rsp)
 29f1af5:	mov    0x28(%rax),%r9d
 29f1af9:	shl    $0x3,%ecx
 29f1afc:	shr    %cl,%r10d
 29f1aff:	and    $0xff,%r10d
 29f1b06:	mov    %r10,0x1f8(%rsp)
 29f1b0e:	mov    %r11d,0xb8(%rsp)
 29f1b16:	mov    %r9d,0xc0(%rsp)
 29f1b1e:	mov    %esi,0x98(%rsp)
 29f1b25:	mov    %edx,0xd8(%rsp)
 29f1b2c:	mov    $0x285,%edx
 29f1b31:	mov    0x190(%rsp),%rsi
 29f1b39:	mov    0x190(%rsp),%rdi
 29f1b41:	call   2f307a0 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 29f1b46:	mov    %eax,0xc8(%rsp)
 29f1b4d:	xor    %r11d,%r11d
 29f1b50:	test   %eax,%eax
 29f1b52:	je     29fc3b5 <wasm[0]::function[1015]::helper::object_read+0x1b495>
 29f1b58:	movl   $0x0,0x88(%rsp)
 29f1b63:	mov    0xb8(%rsp),%r14d
 29f1b6b:	mov    0xc0(%rsp),%edi
 29f1b72:	mov    0x98(%rsp),%edx
 29f1b79:	mov    0xd8(%rsp),%esi
 29f1b80:	xor    %r9,%r9
 29f1b83:	mov    0x250(%rsp),%rcx
 29f1b8b:	test   %cl,%cl
 29f1b8d:	jne    29f1bab <wasm[0]::function[1015]::helper::object_read+0x10c8b>
 29f1b93:	mov    %r11,%r10
 29f1b96:	mov    %r11,0x1d0(%rsp)
 29f1b9e:	mov    %r9,0x1d8(%rsp)
 29f1ba6:	jmp    29f26ea <wasm[0]::function[1015]::helper::object_read+0x117ca>
 29f1bab:	mov    0xb8(%rsp),%r8d
 29f1bb3:	mov    0x260(%rsp),%rcx
 29f1bbb:	mov    0x258(%rsp),%rdx
 29f1bc3:	mov    0x190(%rsp),%rsi
 29f1bcb:	mov    0x190(%rsp),%rdi
 29f1bd3:	call   2a5f620 <wasm[0]::function[1039]::helper::object_header_projection>
 29f1bd8:	mov    %eax,0xa8(%rsp)
 29f1bdf:	test   %eax,%eax
 29f1be1:	je     29fc3b7 <wasm[0]::function[1015]::helper::object_read+0x1b497>
 29f1be7:	test   %eax,%eax
 29f1be9:	je     29fc3b9 <wasm[0]::function[1015]::helper::object_read+0x1b499>
 29f1bef:	mov    0x2e0(%rsp),%r12
 29f1bf7:	mov    0x28(%r12),%rcx
 29f1bfc:	mov    0x20(%r12),%rsi
 29f1c01:	mov    %eax,%edx
 29f1c03:	lea    (%rsi,%rdx,1),%rax
 29f1c07:	xor    %rsi,%rsi
 29f1c0a:	cmp    %rcx,%rdx
 29f1c0d:	cmova  %rsi,%rax
 29f1c11:	mov    0x14(%rax),%eax
 29f1c14:	mov    %eax,0x78(%rsp)
 29f1c18:	test   %eax,%eax
 29f1c1a:	je     29fc3bb <wasm[0]::function[1015]::helper::object_read+0x1b49b>
 29f1c20:	mov    0x78(%rsp),%ecx
 29f1c24:	xor    %eax,%eax
 29f1c26:	test   $0x1,%ecx
 29f1c2c:	jne    29f1c88 <wasm[0]::function[1015]::helper::object_read+0x10d68>
 29f1c32:	mov    0x2e0(%rsp),%r12
 29f1c3a:	mov    0x28(%r12),%rsi
 29f1c3f:	mov    0x20(%r12),%r8
 29f1c44:	mov    %ecx,%edi
 29f1c46:	lea    0x4(%r8,%rdi,1),%rcx
 29f1c4b:	xor    %r8,%r8
 29f1c4e:	cmp    %rsi,%rdi
 29f1c51:	cmova  %r8,%rcx
 29f1c55:	mov    (%rcx),%esi
 29f1c57:	mov    0x190(%rsp),%rax
 29f1c5f:	mov    0x28(%rax),%rdi
 29f1c63:	mov    0x158(%rdi),%edx
 29f1c69:	cmp    %edx,%esi
 29f1c6b:	sete   %dil
 29f1c6f:	movzbl %dil,%eax
 29f1c73:	cmp    %edx,%esi
 29f1c75:	je     29f1c88 <wasm[0]::function[1015]::helper::object_read+0x10d68>
 29f1c7b:	mov    0x190(%rsp),%rdi
 29f1c83:	call   3018e75 <wasmtime_builtin_is_subtype>
 29f1c88:	test   %eax,%eax
 29f1c8a:	jne    29f1ecb <wasm[0]::function[1015]::helper::object_read+0x10fab>
 29f1c90:	mov    0xa8(%rsp),%edx
 29f1c97:	xor    %ebx,%ebx
 29f1c99:	test   %edx,%edx
 29f1c9b:	je     29fc3bd <wasm[0]::function[1015]::helper::object_read+0x1b49d>
 29f1ca1:	mov    0xc8(%rsp),%r9d
 29f1ca9:	mov    $0x4,%ecx
 29f1cae:	xor    %r8,%r8
 29f1cb1:	mov    0x190(%rsp),%rsi
 29f1cb9:	mov    0x190(%rsp),%rdi
 29f1cc1:	call   2a58e20 <wasm[0]::function[1032]::helper::ordinary_property_find>
 29f1cc6:	test   %eax,%eax
 29f1cc8:	je     29f1d02 <wasm[0]::function[1015]::helper::object_read+0x10de2>
 29f1cce:	test   %eax,%eax
 29f1cd0:	je     29fc3bf <wasm[0]::function[1015]::helper::object_read+0x1b49f>
 29f1cd6:	test   %eax,%eax
 29f1cd8:	je     29fc3c1 <wasm[0]::function[1015]::helper::object_read+0x1b4a1>
 29f1cde:	mov    0x2e0(%rsp),%r12
 29f1ce6:	mov    0x28(%r12),%rcx
 29f1ceb:	mov    %eax,%edx
 29f1ced:	mov    %rdx,%rax
 29f1cf0:	add    0x20(%r12),%rax
 29f1cf5:	xor    %rsi,%rsi
 29f1cf8:	cmp    %rcx,%rdx
 29f1cfb:	cmova  %rsi,%rax
 29f1cff:	mov    0x14(%rax),%ebx
 29f1d02:	mov    0x88(%rsp),%r10d
 29f1d0a:	xor    %r11d,%r11d
 29f1d0d:	xor    %r9,%r9
 29f1d10:	test   %ebx,%ebx
 29f1d12:	je     29f1e99 <wasm[0]::function[1015]::helper::object_read+0x10f79>
 29f1d18:	test   %ebx,%ebx
 29f1d1a:	je     29fc3c3 <wasm[0]::function[1015]::helper::object_read+0x1b4a3>
 29f1d20:	mov    0x2e0(%rsp),%r12
 29f1d28:	mov    0x28(%r12),%rcx
 29f1d2d:	mov    0x20(%r12),%rax
 29f1d32:	mov    %ebx,%edx
 29f1d34:	add    %rdx,%rax
 29f1d37:	xor    %r9,%r9
 29f1d3a:	cmp    %rcx,%rdx
 29f1d3d:	cmova  %r9,%rax
 29f1d41:	mov    0x10(%rax),%ecx
 29f1d44:	mov    0x88(%rsp),%r10d
 29f1d4c:	xor    %r11d,%r11d
 29f1d4f:	test   $0x1,%ecx
 29f1d55:	jne    29f1e99 <wasm[0]::function[1015]::helper::object_read+0x10f79>
 29f1d5b:	mov    0x14(%rax),%edx
 29f1d5e:	test   %edx,%edx
 29f1d60:	je     29fc3c5 <wasm[0]::function[1015]::helper::object_read+0x1b4a5>
 29f1d66:	xor    %eax,%eax
 29f1d68:	test   $0x1,%edx
 29f1d6e:	jne    29f1db1 <wasm[0]::function[1015]::helper::object_read+0x10e91>
 29f1d74:	mov    0x2e0(%rsp),%r12
 29f1d7c:	mov    0x28(%r12),%rax
 29f1d81:	mov    0x20(%r12),%rcx
 29f1d86:	mov    %edx,%esi
 29f1d88:	lea    0x4(%rcx,%rsi,1),%rcx
 29f1d8d:	xor    %rdi,%rdi
 29f1d90:	cmp    %rax,%rsi
 29f1d93:	cmova  %rdi,%rcx
 29f1d97:	mov    (%rcx),%eax
 29f1d99:	mov    0x190(%rsp),%rsi
 29f1da1:	mov    0x28(%rsi),%rcx
 29f1da5:	cmp    0x120(%rcx),%eax
 29f1dab:	sete   %al
 29f1dae:	movzbl %al,%eax
 29f1db1:	test   %eax,%eax
 29f1db3:	jne    29f1e11 <wasm[0]::function[1015]::helper::object_read+0x10ef1>
 29f1db9:	mov    0x190(%rsp),%rsi
 29f1dc1:	mov    0x190(%rsp),%rdi
 29f1dc9:	call   2a01ba0 <wasm[0]::function[1024]::helper::property_value_resolve>
 29f1dce:	test   %eax,%eax
 29f1dd0:	je     29fc3c7 <wasm[0]::function[1015]::helper::object_read+0x1b4a7>
 29f1dd6:	test   %eax,%eax
 29f1dd8:	je     29fc3c9 <wasm[0]::function[1015]::helper::object_read+0x1b4a9>
 29f1dde:	mov    0x2e0(%rsp),%r12
 29f1de6:	mov    0x28(%r12),%rcx
 29f1deb:	mov    0x20(%r12),%rsi
 29f1df0:	mov    %eax,%edx
 29f1df2:	lea    (%rsi,%rdx,1),%rax
 29f1df6:	xor    %rsi,%rsi
 29f1df9:	cmp    %rcx,%rdx
 29f1dfc:	cmova  %rsi,%rax
 29f1e00:	mov    0x18(%rax),%r11d
 29f1e04:	mov    0x10(%rax),%r9
 29f1e08:	mov    0x1c(%rax),%r10d
 29f1e0c:	jmp    29f1e99 <wasm[0]::function[1015]::helper::object_read+0x10f79>
 29f1e11:	xor    %eax,%eax
 29f1e13:	test   $0x1,%edx
 29f1e19:	jne    29f1e5c <wasm[0]::function[1015]::helper::object_read+0x10f3c>
 29f1e1f:	mov    0x2e0(%rsp),%r12
 29f1e27:	mov    0x28(%r12),%rax
 29f1e2c:	mov    0x20(%r12),%rcx
 29f1e31:	mov    %edx,%esi
 29f1e33:	lea    0x4(%rcx,%rsi,1),%rcx
 29f1e38:	xor    %rdi,%rdi
 29f1e3b:	cmp    %rax,%rsi
 29f1e3e:	cmova  %rdi,%rcx
 29f1e42:	mov    (%rcx),%eax
 29f1e44:	mov    0x190(%rsp),%rsi
 29f1e4c:	mov    0x28(%rsi),%rcx
 29f1e50:	cmp    0x120(%rcx),%eax
 29f1e56:	sete   %al
 29f1e59:	movzbl %al,%eax
 29f1e5c:	test   %eax,%eax
 29f1e5e:	je     29fc3cb <wasm[0]::function[1015]::helper::object_read+0x1b4ab>
 29f1e64:	test   %edx,%edx
 29f1e66:	je     29fc3cd <wasm[0]::function[1015]::helper::object_read+0x1b4ad>
 29f1e6c:	mov    0x2e0(%rsp),%r12
 29f1e74:	mov    0x28(%r12),%rcx
 29f1e79:	mov    0x20(%r12),%rax
 29f1e7e:	mov    %edx,%edx
 29f1e80:	add    %rdx,%rax
 29f1e83:	xor    %rsi,%rsi
 29f1e86:	cmp    %rcx,%rdx
 29f1e89:	cmova  %rsi,%rax
 29f1e8d:	mov    0x18(%rax),%r11d
 29f1e91:	mov    0x10(%rax),%r9
 29f1e95:	mov    0x1c(%rax),%r10d
 29f1e99:	mov    0xb8(%rsp),%r14d
 29f1ea1:	mov    0xc0(%rsp),%edi
 29f1ea8:	mov    0x98(%rsp),%edx
 29f1eaf:	mov    0xd8(%rsp),%esi
 29f1eb6:	mov    %r11,0x1d0(%rsp)
 29f1ebe:	mov    %r9,0x1d8(%rsp)
 29f1ec6:	jmp    29f26ea <wasm[0]::function[1015]::helper::object_read+0x117ca>
 29f1ecb:	mov    0x78(%rsp),%esi
 29f1ecf:	test   %esi,%esi
 29f1ed1:	je     29fc3cf <wasm[0]::function[1015]::helper::object_read+0x1b4af>
 29f1ed7:	mov    0x78(%rsp),%esi
 29f1edb:	xor    %eax,%eax
 29f1edd:	test   $0x1,%esi
 29f1ee3:	jne    29f1f41 <wasm[0]::function[1015]::helper::object_read+0x11021>
 29f1ee9:	mov    0x2e0(%rsp),%r12
 29f1ef1:	mov    0x28(%r12),%r9
 29f1ef6:	mov    0x20(%r12),%r11
 29f1efb:	mov    %esi,%r10d
 29f1efe:	lea    0x4(%r11,%r10,1),%rsi
 29f1f03:	xor    %r11,%r11
 29f1f06:	cmp    %r9,%r10
 29f1f09:	cmova  %r11,%rsi
 29f1f0d:	mov    (%rsi),%esi
 29f1f0f:	mov    0x190(%rsp),%rax
 29f1f17:	mov    0x28(%rax),%r10
 29f1f1b:	mov    0x158(%r10),%edx
 29f1f22:	cmp    %edx,%esi
 29f1f24:	sete   %r11b
 29f1f28:	movzbl %r11b,%eax
 29f1f2c:	cmp    %edx,%esi
 29f1f2e:	je     29f1f41 <wasm[0]::function[1015]::helper::object_read+0x11021>
 29f1f34:	mov    0x190(%rsp),%rdi
 29f1f3c:	call   3018e75 <wasmtime_builtin_is_subtype>
 29f1f41:	test   %eax,%eax
 29f1f43:	je     29fc3d1 <wasm[0]::function[1015]::helper::object_read+0x1b4b1>
 29f1f49:	mov    0x78(%rsp),%r8d
 29f1f4e:	mov    0xb8(%rsp),%r14d
 29f1f56:	mov    0x88(%rsp),%r10d
 29f1f5e:	mov    0xc0(%rsp),%edi
 29f1f65:	mov    0x98(%rsp),%edx
 29f1f6c:	mov    0xd8(%rsp),%esi
 29f1f73:	xor    %ecx,%ecx
 29f1f75:	mov    %rcx,%r15
 29f1f78:	test   %r8d,%r8d
 29f1f7b:	je     29fc3d3 <wasm[0]::function[1015]::helper::object_read+0x1b4b3>
 29f1f81:	test   %r8d,%r8d
 29f1f84:	je     29fc3d5 <wasm[0]::function[1015]::helper::object_read+0x1b4b5>
 29f1f8a:	mov    0x2e0(%rsp),%r12
 29f1f92:	mov    0x28(%r12),%rax
 29f1f97:	mov    0x20(%r12),%rcx
 29f1f9c:	mov    %r8d,%ebx
 29f1f9f:	lea    (%rcx,%rbx,1),%r9
 29f1fa3:	xor    %r11,%r11
 29f1fa6:	cmp    %rax,%rbx
 29f1fa9:	cmova  %r11,%r9
 29f1fad:	mov    0x10(%r9),%r9d
 29f1fb1:	test   %r9d,%r9d
 29f1fb4:	je     29fc3d7 <wasm[0]::function[1015]::helper::object_read+0x1b4b7>
 29f1fba:	test   %r9d,%r9d
 29f1fbd:	je     29fc3d9 <wasm[0]::function[1015]::helper::object_read+0x1b4b9>
 29f1fc3:	mov    %r9d,%ebx
 29f1fc6:	lea    (%rcx,%rbx,1),%r9
 29f1fca:	cmp    %rax,%rbx
 29f1fcd:	cmova  %r11,%r9
 29f1fd1:	mov    0x10(%r9),%r9d
 29f1fd5:	test   %r9d,%r9d
 29f1fd8:	je     29fc3db <wasm[0]::function[1015]::helper::object_read+0x1b4bb>
 29f1fde:	test   %r9d,%r9d
 29f1fe1:	je     29fc3dd <wasm[0]::function[1015]::helper::object_read+0x1b4bd>
 29f1fe7:	mov    %r9d,%ebx
 29f1fea:	lea    0x10(%rcx,%rbx,1),%rcx
 29f1fef:	cmp    %rax,%rbx
 29f1ff2:	cmova  %r11,%rcx
 29f1ff6:	mov    (%rcx),%ebx
 29f1ff8:	mov    0xc8(%rsp),%r11d
 29f2000:	mov    0x190(%rsp),%rax
 29f2008:	mov    0x28(%rax),%rax
 29f200c:	mov    0x234(%rax),%r13d
 29f2013:	mov    %r15,0x1c8(%rsp)
 29f201b:	mov    %r9d,0xa8(%rsp)
 29f2023:	mov    %r11d,0xd8(%rsp)
 29f202b:	mov    %r8d,0x98(%rsp)
 29f2033:	mov    %r14d,0xc0(%rsp)
 29f203b:	mov    %r10d,0x88(%rsp)
 29f2043:	mov    %edi,0xb8(%rsp)
 29f204a:	mov    %edx,0x78(%rsp)
 29f204e:	mov    %esi,0xc8(%rsp)
 29f2055:	mov    0x2e8(%rsp),%rax
 29f205d:	mov    (%rax),%rcx
 29f2060:	mov    0x228(%rsp),%rax
 29f2068:	cmp    %rax,%rcx
 29f206b:	jae    29fb3de <wasm[0]::function[1015]::helper::object_read+0x1a4be>
 29f2071:	mov    0x98(%rsp),%r8d
 29f2079:	mov    0xc0(%rsp),%r14d
 29f2081:	mov    0x88(%rsp),%r10d
 29f2089:	mov    0xb8(%rsp),%edi
 29f2090:	mov    0x78(%rsp),%edx
 29f2094:	mov    0xc8(%rsp),%esi
 29f209b:	mov    %r15,%rcx
 29f209e:	cmp    %ebx,%ecx
 29f20a0:	jb     29f20b3 <wasm[0]::function[1015]::helper::object_read+0x11193>
 29f20a6:	mov    0x1c8(%rsp),%rax
 29f20ae:	jmp    29f229b <wasm[0]::function[1015]::helper::object_read+0x1137b>
 29f20b3:	mov    0xa8(%rsp),%eax
 29f20ba:	test   %eax,%eax
 29f20bc:	je     29fc3df <wasm[0]::function[1015]::helper::object_read+0x1b4bf>
 29f20c2:	test   %eax,%eax
 29f20c4:	je     29fc3e1 <wasm[0]::function[1015]::helper::object_read+0x1b4c1>
 29f20ca:	mov    0x2e0(%rsp),%r12
 29f20d2:	mov    0x28(%r12),%rdx
 29f20d7:	mov    0x20(%r12),%rsi
 29f20dc:	mov    %eax,%r9d
 29f20df:	lea    0x10(%rsi,%r9,1),%r8
 29f20e4:	xor    %rdi,%rdi
 29f20e7:	cmp    %rdx,%r9
 29f20ea:	cmova  %rdi,%r8
 29f20ee:	mov    (%r8),%r8d
 29f20f1:	cmp    %r8d,%ecx
 29f20f4:	jae    29fc3e3 <wasm[0]::function[1015]::helper::object_read+0x1b4c3>
 29f20fa:	mov    %r8d,%r9d
 29f20fd:	shl    $0x2,%r9
 29f2101:	shr    $0x20,%r9
 29f2105:	test   %r9,%r9
 29f2108:	jne    29fc3e5 <wasm[0]::function[1015]::helper::object_read+0x1b4c5>
 29f210e:	shl    $0x2,%r8d
 29f2112:	add    $0x14,%r8d
 29f2116:	jb     29fc3e7 <wasm[0]::function[1015]::helper::object_read+0x1b4c7>
 29f211c:	add    %r8d,%eax
 29f211f:	jb     29fc3e9 <wasm[0]::function[1015]::helper::object_read+0x1b4c9>
 29f2125:	mov    %eax,%r9d
 29f2128:	lea    (%rsi,%r9,1),%rax
 29f212c:	cmp    %rdx,%r9
 29f212f:	cmova  %rdi,%rax
 29f2133:	mov    %rcx,%rdx
 29f2136:	shl    $0x2,%edx
 29f2139:	mov    %rcx,%r15
 29f213c:	add    $0x14,%edx
 29f2142:	sub    %edx,%r8d
 29f2145:	sub    %r8,%rax
 29f2148:	mov    (%rax),%edx
 29f214a:	test   %edx,%edx
 29f214c:	je     29fc3eb <wasm[0]::function[1015]::helper::object_read+0x1b4cb>
 29f2152:	mov    0xd8(%rsp),%edi
 29f2159:	cmp    %edi,%edx
 29f215b:	je     29f2230 <wasm[0]::function[1015]::helper::object_read+0x11310>
 29f2161:	xor    %eax,%eax
 29f2163:	test   %edx,%edx
 29f2165:	je     29f21a7 <wasm[0]::function[1015]::helper::object_read+0x11287>
 29f216b:	xor    %eax,%eax
 29f216d:	test   $0x1,%edx
 29f2173:	jne    29f21a7 <wasm[0]::function[1015]::helper::object_read+0x11287>
 29f2179:	mov    0x2e0(%rsp),%r12
 29f2181:	mov    0x28(%r12),%rax
 29f2186:	mov    0x20(%r12),%rcx
 29f218b:	mov    %edx,%esi
 29f218d:	lea    0x4(%rcx,%rsi,1),%rcx
 29f2192:	xor    %r8,%r8
 29f2195:	cmp    %rax,%rsi
 29f2198:	cmova  %r8,%rcx
 29f219c:	mov    (%rcx),%eax
 29f219e:	cmp    %r13d,%eax
 29f21a1:	sete   %al
 29f21a4:	movzbl %al,%eax
 29f21a7:	test   %eax,%eax
 29f21a9:	je     29fc3ed <wasm[0]::function[1015]::helper::object_read+0x1b4cd>
 29f21af:	xor    %esi,%esi
 29f21b1:	test   %edi,%edi
 29f21b3:	je     29f21fc <wasm[0]::function[1015]::helper::object_read+0x112dc>
 29f21b9:	mov    0xd8(%rsp),%eax
 29f21c0:	xor    %esi,%esi
 29f21c2:	test   $0x1,%eax
 29f21c7:	jne    29f21fc <wasm[0]::function[1015]::helper::object_read+0x112dc>
 29f21cd:	mov    0x2e0(%rsp),%r12
 29f21d5:	mov    0x28(%r12),%rcx
 29f21da:	mov    0x20(%r12),%rdi
 29f21df:	mov    %eax,%esi
 29f21e1:	lea    0x4(%rdi,%rsi,1),%rax
 29f21e6:	xor    %rdi,%rdi
 29f21e9:	cmp    %rcx,%rsi
 29f21ec:	cmova  %rdi,%rax
 29f21f0:	mov    (%rax),%eax
 29f21f2:	cmp    %r13d,%eax
 29f21f5:	sete   %al
 29f21f8:	rex movzbl %al,%esi
 29f21fc:	test   %esi,%esi
 29f21fe:	je     29fc3ef <wasm[0]::function[1015]::helper::object_read+0x1b4cf>
 29f2204:	mov    0xd8(%rsp),%ecx
 29f220b:	xor    %r8d,%r8d
 29f220e:	test   %ecx,%ecx
 29f2210:	je     29fc3f1 <wasm[0]::function[1015]::helper::object_read+0x1b4d1>
 29f2216:	mov    0x190(%rsp),%rsi
 29f221e:	mov    0x190(%rsp),%rdi
 29f2226:	call   2ae54e0 <wasm[0]::function[1057]::helper::string_equality>
 29f222b:	jmp    29f2238 <wasm[0]::function[1015]::helper::object_read+0x11318>
 29f2230:	mov    0x278(%rsp),%rax
 29f2238:	mov    0xa8(%rsp),%r9d
 29f2240:	mov    0xd8(%rsp),%r11d
 29f2248:	mov    0x98(%rsp),%r8d
 29f2250:	mov    0xc0(%rsp),%r14d
 29f2258:	mov    0x88(%rsp),%r10d
 29f2260:	mov    0xb8(%rsp),%edi
 29f2267:	mov    0x78(%rsp),%edx
 29f226b:	mov    0xc8(%rsp),%esi
 29f2272:	test   %eax,%eax
 29f2274:	je     29f2282 <wasm[0]::function[1015]::helper::object_read+0x11362>
 29f227a:	mov    %r15,%rcx
 29f227d:	jmp    29f229b <wasm[0]::function[1015]::helper::object_read+0x1137b>
 29f2282:	mov    %r15,%rcx
 29f2285:	add    $0x1,%ecx
 29f228b:	mov    %rcx,%r15
 29f228e:	mov    %rax,0x1c8(%rsp)
 29f2296:	jmp    29f201b <wasm[0]::function[1015]::helper::object_read+0x110fb>
 29f229b:	xor    %r11d,%r11d
 29f229e:	xor    %r9,%r9
 29f22a1:	test   %eax,%eax
 29f22a3:	jne    29f22be <wasm[0]::function[1015]::helper::object_read+0x1139e>
 29f22a9:	mov    %r11,0x1d0(%rsp)
 29f22b1:	mov    %r9,0x1d8(%rsp)
 29f22b9:	jmp    29f26ea <wasm[0]::function[1015]::helper::object_read+0x117ca>
 29f22be:	test   %r8d,%r8d
 29f22c1:	je     29fc3f3 <wasm[0]::function[1015]::helper::object_read+0x1b4d3>
 29f22c7:	xor    %r9d,%r9d
 29f22ca:	test   $0x1,%r8d
 29f22d1:	jne    29f2318 <wasm[0]::function[1015]::helper::object_read+0x113f8>
 29f22d7:	mov    0x2e0(%rsp),%r12
 29f22df:	mov    0x28(%r12),%rax
 29f22e4:	mov    0x20(%r12),%r9
 29f22e9:	mov    %r8d,%r10d
 29f22ec:	lea    0x4(%r9,%r10,1),%r9
 29f22f1:	xor    %r11,%r11
 29f22f4:	cmp    %rax,%r10
 29f22f7:	cmova  %r11,%r9
 29f22fb:	mov    (%r9),%eax
 29f22fe:	mov    0x190(%rsp),%r9
 29f2306:	mov    0x28(%r9),%r9
 29f230a:	cmp    0x160(%r9),%eax
 29f2311:	sete   %al
 29f2314:	movzbl %al,%r9d
 29f2318:	test   %r9d,%r9d
 29f231b:	jne    29f2562 <wasm[0]::function[1015]::helper::object_read+0x11642>
 29f2321:	xor    %eax,%eax
 29f2323:	test   $0x1,%r8d
 29f232a:	jne    29f2370 <wasm[0]::function[1015]::helper::object_read+0x11450>
 29f2330:	mov    0x2e0(%rsp),%r12
 29f2338:	mov    0x28(%r12),%rax
 29f233d:	mov    0x20(%r12),%r9
 29f2342:	mov    %r8d,%r10d
 29f2345:	lea    0x4(%r9,%r10,1),%r9
 29f234a:	xor    %r11,%r11
 29f234d:	cmp    %rax,%r10
 29f2350:	cmova  %r11,%r9
 29f2354:	mov    (%r9),%eax
 29f2357:	mov    0x190(%rsp),%r9
 29f235f:	mov    0x28(%r9),%r9
 29f2363:	cmp    0x15c(%r9),%eax
 29f236a:	sete   %al
 29f236d:	movzbl %al,%eax
 29f2370:	test   %eax,%eax
 29f2372:	je     29fc3f5 <wasm[0]::function[1015]::helper::object_read+0x1b4d5>
 29f2378:	test   %r8d,%r8d
 29f237b:	je     29fc3f7 <wasm[0]::function[1015]::helper::object_read+0x1b4d7>
 29f2381:	mov    0x2e0(%rsp),%r12
 29f2389:	mov    0x28(%r12),%r11
 29f238e:	mov    0x20(%r12),%rax
 29f2393:	mov    %r8d,%r10d
 29f2396:	lea    (%rax,%r10,1),%r8
 29f239a:	xor    %r9,%r9
 29f239d:	cmp    %r11,%r10
 29f23a0:	cmova  %r9,%r8
 29f23a4:	mov    0x14(%r8),%ebx
 29f23a8:	mov    0x18(%r8),%r10d
 29f23ac:	mov    0x1c(%r8),%r8d
 29f23b0:	test   %ebx,%ebx
 29f23b2:	je     29fc3f9 <wasm[0]::function[1015]::helper::object_read+0x1b4d9>
 29f23b8:	test   %ebx,%ebx
 29f23ba:	je     29fc3fb <wasm[0]::function[1015]::helper::object_read+0x1b4db>
 29f23c0:	mov    %ebx,%r13d
 29f23c3:	lea    0x10(%rax,%r13,1),%r12
 29f23c8:	cmp    %r11,%r13
 29f23cb:	cmova  %r9,%r12
 29f23cf:	mov    (%r12),%r12d
 29f23d3:	cmp    %r12d,%ecx
 29f23d6:	jae    29fc3fd <wasm[0]::function[1015]::helper::object_read+0x1b4dd>
 29f23dc:	mov    %r12d,%r13d
 29f23df:	shr    $0x20,%r13
 29f23e3:	test   %r13,%r13
 29f23e6:	jne    29fc3ff <wasm[0]::function[1015]::helper::object_read+0x1b4df>
 29f23ec:	add    $0x14,%r12d
 29f23f0:	jb     29fc401 <wasm[0]::function[1015]::helper::object_read+0x1b4e1>
 29f23f6:	add    %r12d,%ebx
 29f23f9:	jb     29fc403 <wasm[0]::function[1015]::helper::object_read+0x1b4e3>
 29f23ff:	mov    %ebx,%ebx
 29f2401:	add    %rbx,%rax
 29f2404:	cmp    %r11,%rbx
 29f2407:	cmova  %r9,%rax
 29f240b:	lea    0x14(%rcx),%r11d
 29f240f:	sub    %r11d,%r12d
 29f2412:	sub    %r12,%rax
 29f2415:	movzbq (%rax),%r11
 29f2419:	test   %r10d,%r10d
 29f241c:	je     29f24b2 <wasm[0]::function[1015]::helper::object_read+0x11592>
 29f2422:	test   %r10d,%r10d
 29f2425:	je     29fc405 <wasm[0]::function[1015]::helper::object_read+0x1b4e5>
 29f242b:	test   %r10d,%r10d
 29f242e:	je     29fc407 <wasm[0]::function[1015]::helper::object_read+0x1b4e7>
 29f2434:	mov    0x2e0(%rsp),%r12
 29f243c:	mov    0x28(%r12),%rax
 29f2441:	mov    0x20(%r12),%r9
 29f2446:	mov    %r10d,%r13d
 29f2449:	lea    0x10(%r9,%r13,1),%r12
 29f244e:	xor    %rbx,%rbx
 29f2451:	cmp    %rax,%r13
 29f2454:	cmova  %rbx,%r12
 29f2458:	mov    (%r12),%r15d
 29f245c:	cmp    %r15d,%ecx
 29f245f:	jae    29fc409 <wasm[0]::function[1015]::helper::object_read+0x1b4e9>
 29f2465:	mov    %r15d,%r12d
 29f2468:	shl    $0x3,%r12
 29f246c:	shr    $0x20,%r12
 29f2470:	test   %r12,%r12
 29f2473:	jne    29fc40b <wasm[0]::function[1015]::helper::object_read+0x1b4eb>
 29f2479:	shl    $0x3,%r15d
 29f247d:	add    $0x18,%r15d
 29f2481:	jb     29fc40d <wasm[0]::function[1015]::helper::object_read+0x1b4ed>
 29f2487:	add    %r15d,%r10d
 29f248a:	jb     29fc40f <wasm[0]::function[1015]::helper::object_read+0x1b4ef>
 29f2490:	mov    %r10d,%r10d
 29f2493:	add    %r10,%r9
 29f2496:	cmp    %rax,%r10
 29f2499:	cmova  %rbx,%r9
 29f249d:	mov    %rcx,%rax
 29f24a0:	shl    $0x3,%eax
 29f24a3:	add    $0x18,%eax
 29f24a9:	sub    %eax,%r15d
 29f24ac:	sub    %r15,%r9
 29f24af:	mov    (%r9),%r9
 29f24b2:	xor    %r10d,%r10d
 29f24b5:	test   %r8d,%r8d
 29f24b8:	je     29f2549 <wasm[0]::function[1015]::helper::object_read+0x11629>
 29f24be:	test   %r8d,%r8d
 29f24c1:	je     29fc411 <wasm[0]::function[1015]::helper::object_read+0x1b4f1>
 29f24c7:	test   %r8d,%r8d
 29f24ca:	je     29fc413 <wasm[0]::function[1015]::helper::object_read+0x1b4f3>
 29f24d0:	mov    0x2e0(%rsp),%r12
 29f24d8:	mov    0x28(%r12),%rax
 29f24dd:	mov    0x20(%r12),%r10
 29f24e2:	mov    %r8d,%r13d
 29f24e5:	lea    0x10(%r10,%r13,1),%r12
 29f24ea:	xor    %rbx,%rbx
 29f24ed:	cmp    %rax,%r13
 29f24f0:	cmova  %rbx,%r12
 29f24f4:	mov    (%r12),%r12d
 29f24f8:	cmp    %r12d,%ecx
 29f24fb:	jae    29fc415 <wasm[0]::function[1015]::helper::object_read+0x1b4f5>
 29f2501:	mov    %r12d,%r13d
 29f2504:	shl    $0x2,%r13
 29f2508:	shr    $0x20,%r13
 29f250c:	test   %r13,%r13
 29f250f:	jne    29fc417 <wasm[0]::function[1015]::helper::object_read+0x1b4f7>
 29f2515:	shl    $0x2,%r12d
 29f2519:	add    $0x14,%r12d
 29f251d:	jb     29fc419 <wasm[0]::function[1015]::helper::object_read+0x1b4f9>
 29f2523:	add    %r12d,%r8d
 29f2526:	jb     29fc41b <wasm[0]::function[1015]::helper::object_read+0x1b4fb>
 29f252c:	mov    %r8d,%r13d
 29f252f:	lea    (%r10,%r13,1),%r8
 29f2533:	cmp    %rax,%r13
 29f2536:	cmova  %rbx,%r8
 29f253a:	shl    $0x2,%ecx
 29f253d:	lea    0x14(%rcx),%eax
 29f2540:	sub    %eax,%r12d
 29f2543:	sub    %r12,%r8
 29f2546:	mov    (%r8),%r10d
 29f2549:	movzbl %r11b,%r11d
 29f254d:	mov    %r11,0x1d0(%rsp)
 29f2555:	mov    %r9,0x1d8(%rsp)
 29f255d:	jmp    29f26ea <wasm[0]::function[1015]::helper::object_read+0x117ca>
 29f2562:	xor    %eax,%eax
 29f2564:	test   $0x1,%r8d
 29f256b:	jne    29f25b1 <wasm[0]::function[1015]::helper::object_read+0x11691>
 29f2571:	mov    0x2e0(%rsp),%r12
 29f2579:	mov    0x28(%r12),%rax
 29f257e:	mov    0x20(%r12),%r9
 29f2583:	mov    %r8d,%r10d
 29f2586:	lea    0x4(%r9,%r10,1),%r9
 29f258b:	xor    %r11,%r11
 29f258e:	cmp    %rax,%r10
 29f2591:	cmova  %r11,%r9
 29f2595:	mov    (%r9),%eax
 29f2598:	mov    0x190(%rsp),%r9
 29f25a0:	mov    0x28(%r9),%r9
 29f25a4:	cmp    0x160(%r9),%eax
 29f25ab:	sete   %al
 29f25ae:	movzbl %al,%eax
 29f25b1:	test   %eax,%eax
 29f25b3:	je     29fc41d <wasm[0]::function[1015]::helper::object_read+0x1b4fd>
 29f25b9:	test   %r8d,%r8d
 29f25bc:	je     29fc41f <wasm[0]::function[1015]::helper::object_read+0x1b4ff>
 29f25c2:	mov    0x2e0(%rsp),%r12
 29f25ca:	mov    0x28(%r12),%rax
 29f25cf:	mov    0x20(%r12),%r9
 29f25d4:	mov    %r8d,%r8d
 29f25d7:	lea    (%r9,%r8,1),%r11
 29f25db:	xor    %r10,%r10
 29f25de:	cmp    %rax,%r8
 29f25e1:	cmova  %r10,%r11
 29f25e5:	mov    0x10(%r11),%r11d
 29f25e9:	test   %r11d,%r11d
 29f25ec:	je     29fc421 <wasm[0]::function[1015]::helper::object_read+0x1b501>
 29f25f2:	test   %r11d,%r11d
 29f25f5:	je     29fc423 <wasm[0]::function[1015]::helper::object_read+0x1b503>
 29f25fb:	mov    %r11d,%r12d
 29f25fe:	lea    (%r9,%r12,1),%r11
 29f2602:	cmp    %rax,%r12
 29f2605:	cmova  %r10,%r11
 29f2609:	mov    0x10(%r11),%r11d
 29f260d:	test   %r11d,%r11d
 29f2610:	je     29fc425 <wasm[0]::function[1015]::helper::object_read+0x1b505>
 29f2616:	test   %r11d,%r11d
 29f2619:	je     29fc427 <wasm[0]::function[1015]::helper::object_read+0x1b507>
 29f261f:	mov    %r11d,%r11d
 29f2622:	lea    0x10(%r9,%r11,1),%r9
 29f2627:	cmp    %rax,%r11
 29f262a:	cmova  %r10,%r9
 29f262e:	cmp    (%r9),%ecx
 29f2631:	setae  %r9b
 29f2635:	cmp    $0x2,%ecx
 29f2638:	setae  %al
 29f263b:	or     %eax,%r9d
 29f263e:	test   %r9b,%r9b
 29f2641:	jne    29fc429 <wasm[0]::function[1015]::helper::object_read+0x1b509>
 29f2647:	mov    0x2e0(%rsp),%r12
 29f264f:	mov    0x28(%r12),%r9
 29f2654:	mov    %r8,%rax
 29f2657:	add    0x20(%r12),%rax
 29f265c:	xor    %r10,%r10
 29f265f:	cmp    %r9,%r8
 29f2662:	cmova  %r10,%rax
 29f2666:	mov    0x14(%rax),%r11d
 29f266a:	test   %ecx,%ecx
 29f266c:	je     29f26a6 <wasm[0]::function[1015]::helper::object_read+0x11786>
 29f2672:	mov    0x2e0(%rsp),%r12
 29f267a:	mov    0x28(%r12),%r9
 29f267f:	mov    0x20(%r12),%rax
 29f2684:	add    %r8,%rax
 29f2687:	xor    %r10,%r10
 29f268a:	cmp    %r9,%r8
 29f268d:	cmova  %r10,%rax
 29f2691:	mov    0x20(%rax),%r9
 29f2695:	mov    0x2c(%rax),%r10d
 29f2699:	mov    %r9,0x1d8(%rsp)
 29f26a1:	jmp    29f26d5 <wasm[0]::function[1015]::helper::object_read+0x117b5>
 29f26a6:	mov    0x2e0(%rsp),%r12
 29f26ae:	mov    0x28(%r12),%r9
 29f26b3:	mov    0x20(%r12),%rax
 29f26b8:	add    %r8,%rax
 29f26bb:	xor    %r10,%r10
 29f26be:	cmp    %r9,%r8
 29f26c1:	cmova  %r10,%rax
 29f26c5:	mov    0x18(%rax),%r9
 29f26c9:	mov    %r9,0x1d8(%rsp)
 29f26d1:	mov    0x28(%rax),%r10d
 29f26d5:	shl    $0x3,%ecx
 29f26d8:	shr    %cl,%r11d
 29f26db:	and    $0xff,%r11d
 29f26e2:	mov    %r11,0x1d0(%rsp)
 29f26ea:	mov    %r14d,0x88(%rsp)
 29f26f2:	mov    %r10d,0xc0(%rsp)
 29f26fa:	mov    %edi,0x98(%rsp)
 29f2701:	mov    %edx,0xd8(%rsp)
 29f2708:	mov    %esi,0xa8(%rsp)
 29f270f:	mov    0x198(%rsp),%rdx
 29f2717:	mov    0x190(%rsp),%rsi
 29f271f:	mov    0x190(%rsp),%rdi
 29f2727:	call   2f307a0 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 29f272c:	mov    %eax,0xb8(%rsp)
 29f2733:	xor    %ecx,%ecx
 29f2735:	mov    %rcx,0x220(%rsp)
 29f273d:	test   %eax,%eax
 29f273f:	je     29fc42b <wasm[0]::function[1015]::helper::object_read+0x1b50b>
 29f2745:	movl   $0x0,0x78(%rsp)
 29f274d:	mov    0x88(%rsp),%eax
 29f2754:	mov    0xc0(%rsp),%r8d
 29f275c:	mov    0x98(%rsp),%edx
 29f2763:	mov    0xd8(%rsp),%esi
 29f276a:	mov    0xa8(%rsp),%edi
 29f2771:	xor    %r10,%r10
 29f2774:	mov    0x250(%rsp),%rcx
 29f277c:	mov    0x250(%rsp),%r9
 29f2784:	test   %r9b,%cl
 29f2787:	jne    29f27b2 <wasm[0]::function[1015]::helper::object_read+0x11892>
 29f278d:	mov    0x220(%rsp),%r11
 29f2795:	mov    %r10,0x200(%rsp)
 29f279d:	mov    0x220(%rsp),%rcx
 29f27a5:	mov    %rcx,0x208(%rsp)
 29f27ad:	jmp    29f3390 <wasm[0]::function[1015]::helper::object_read+0x12470>
 29f27b2:	mov    0x88(%rsp),%r8d
 29f27ba:	mov    0x260(%rsp),%rcx
 29f27c2:	mov    0x258(%rsp),%rdx
 29f27ca:	mov    0x190(%rsp),%rsi
 29f27d2:	mov    0x190(%rsp),%rdi
 29f27da:	call   2a5f620 <wasm[0]::function[1039]::helper::object_header_projection>
 29f27df:	mov    %eax,0xc8(%rsp)
 29f27e6:	test   %eax,%eax
 29f27e8:	je     29fc42d <wasm[0]::function[1015]::helper::object_read+0x1b50d>
 29f27ee:	test   %eax,%eax
 29f27f0:	je     29fc42f <wasm[0]::function[1015]::helper::object_read+0x1b50f>
 29f27f6:	mov    0x2e0(%rsp),%r12
 29f27fe:	mov    0x28(%r12),%rcx
 29f2803:	mov    0x20(%r12),%rsi
 29f2808:	mov    %eax,%edx
 29f280a:	lea    (%rsi,%rdx,1),%rax
 29f280e:	xor    %rsi,%rsi
 29f2811:	cmp    %rcx,%rdx
 29f2814:	cmova  %rsi,%rax
 29f2818:	mov    0x14(%rax),%eax
 29f281b:	mov    %eax,0xb0(%rsp)
 29f2822:	test   %eax,%eax
 29f2824:	je     29fc431 <wasm[0]::function[1015]::helper::object_read+0x1b511>
 29f282a:	mov    0xb0(%rsp),%ecx
 29f2831:	xor    %eax,%eax
 29f2833:	test   $0x1,%ecx
 29f2839:	jne    29f2893 <wasm[0]::function[1015]::helper::object_read+0x11973>
 29f283f:	mov    0x2e0(%rsp),%r12
 29f2847:	mov    0x28(%r12),%rax
 29f284c:	mov    0x20(%r12),%rsi
 29f2851:	mov    %ecx,%edx
 29f2853:	lea    0x4(%rsi,%rdx,1),%rcx
 29f2858:	xor    %rsi,%rsi
 29f285b:	cmp    %rax,%rdx
 29f285e:	cmova  %rsi,%rcx
 29f2862:	mov    (%rcx),%esi
 29f2864:	mov    0x190(%rsp),%rax
 29f286c:	mov    0x28(%rax),%rax
 29f2870:	mov    0x158(%rax),%edx
 29f2876:	cmp    %edx,%esi
 29f2878:	sete   %al
 29f287b:	movzbl %al,%eax
 29f287e:	cmp    %edx,%esi
 29f2880:	je     29f2893 <wasm[0]::function[1015]::helper::object_read+0x11973>
 29f2886:	mov    0x190(%rsp),%rdi
 29f288e:	call   3018e75 <wasmtime_builtin_is_subtype>
 29f2893:	test   %eax,%eax
 29f2895:	jne    29f2b25 <wasm[0]::function[1015]::helper::object_read+0x11c05>
 29f289b:	mov    0xc8(%rsp),%edx
 29f28a2:	xor    %ebx,%ebx
 29f28a4:	test   %edx,%edx
 29f28a6:	je     29fc433 <wasm[0]::function[1015]::helper::object_read+0x1b513>
 29f28ac:	mov    0xb8(%rsp),%r9d
 29f28b4:	mov    $0x4,%ecx
 29f28b9:	xor    %r8,%r8
 29f28bc:	mov    0x190(%rsp),%rsi
 29f28c4:	mov    0x190(%rsp),%rdi
 29f28cc:	call   2a58e20 <wasm[0]::function[1032]::helper::ordinary_property_find>
 29f28d1:	test   %eax,%eax
 29f28d3:	je     29f290e <wasm[0]::function[1015]::helper::object_read+0x119ee>
 29f28d9:	test   %eax,%eax
 29f28db:	je     29fc435 <wasm[0]::function[1015]::helper::object_read+0x1b515>
 29f28e1:	test   %eax,%eax
 29f28e3:	je     29fc437 <wasm[0]::function[1015]::helper::object_read+0x1b517>
 29f28e9:	mov    0x2e0(%rsp),%r12
 29f28f1:	mov    0x28(%r12),%rsi
 29f28f6:	mov    %eax,%r8d
 29f28f9:	mov    %r8,%rdi
 29f28fc:	add    0x20(%r12),%rdi
 29f2901:	xor    %r9,%r9
 29f2904:	cmp    %rsi,%r8
 29f2907:	cmova  %r9,%rdi
 29f290b:	mov    0x14(%rdi),%ebx
 29f290e:	mov    0x78(%rsp),%r11d
 29f2913:	mov    %rax,%r10
 29f2916:	mov    %rax,0x220(%rsp)
 29f291e:	xor    %r10d,%eax
 29f2921:	mov    %rax,0x220(%rsp)
 29f2929:	xor    %r10,%r10
 29f292c:	test   %ebx,%ebx
 29f292e:	jne    29f2941 <wasm[0]::function[1015]::helper::object_read+0x11a21>
 29f2934:	mov    0x220(%rsp),%rbx
 29f293c:	jmp    29f2aec <wasm[0]::function[1015]::helper::object_read+0x11bcc>
 29f2941:	test   %ebx,%ebx
 29f2943:	je     29fc439 <wasm[0]::function[1015]::helper::object_read+0x1b519>
 29f2949:	mov    0x2e0(%rsp),%r12
 29f2951:	mov    0x28(%r12),%rcx
 29f2956:	mov    0x20(%r12),%rax
 29f295b:	mov    %ebx,%edx
 29f295d:	add    %rdx,%rax
 29f2960:	xor    %r10,%r10
 29f2963:	cmp    %rcx,%rdx
 29f2966:	cmova  %r10,%rax
 29f296a:	mov    0x10(%rax),%ecx
 29f296d:	mov    0x78(%rsp),%r11d
 29f2972:	mov    %rdx,%rsi
 29f2975:	mov    %rdx,0x220(%rsp)
 29f297d:	xor    %esi,%edx
 29f297f:	mov    %rdx,0x220(%rsp)
 29f2987:	test   $0x1,%ecx
 29f298d:	je     29f29a0 <wasm[0]::function[1015]::helper::object_read+0x11a80>
 29f2993:	mov    0x220(%rsp),%rbx
 29f299b:	jmp    29f2aec <wasm[0]::function[1015]::helper::object_read+0x11bcc>
 29f29a0:	mov    0x14(%rax),%edx
 29f29a3:	test   %edx,%edx
 29f29a5:	je     29fc43b <wasm[0]::function[1015]::helper::object_read+0x1b51b>
 29f29ab:	xor    %eax,%eax
 29f29ad:	test   $0x1,%edx
 29f29b3:	jne    29f29f6 <wasm[0]::function[1015]::helper::object_read+0x11ad6>
 29f29b9:	mov    0x2e0(%rsp),%r12
 29f29c1:	mov    0x28(%r12),%rax
 29f29c6:	mov    0x20(%r12),%rcx
 29f29cb:	mov    %edx,%esi
 29f29cd:	lea    0x4(%rcx,%rsi,1),%rcx
 29f29d2:	xor    %rdi,%rdi
 29f29d5:	cmp    %rax,%rsi
 29f29d8:	cmova  %rdi,%rcx
 29f29dc:	mov    (%rcx),%eax
 29f29de:	mov    0x190(%rsp),%rsi
 29f29e6:	mov    0x28(%rsi),%rcx
 29f29ea:	cmp    0x120(%rcx),%eax
 29f29f0:	sete   %al
 29f29f3:	movzbl %al,%eax
 29f29f6:	test   %eax,%eax
 29f29f8:	jne    29f2a55 <wasm[0]::function[1015]::helper::object_read+0x11b35>
 29f29fe:	mov    0x190(%rsp),%rsi
 29f2a06:	mov    0x190(%rsp),%rdi
 29f2a0e:	call   2a01ba0 <wasm[0]::function[1024]::helper::property_value_resolve>
 29f2a13:	test   %eax,%eax
 29f2a15:	je     29fc43d <wasm[0]::function[1015]::helper::object_read+0x1b51d>
 29f2a1b:	test   %eax,%eax
 29f2a1d:	je     29fc43f <wasm[0]::function[1015]::helper::object_read+0x1b51f>
 29f2a23:	mov    0x2e0(%rsp),%r12
 29f2a2b:	mov    0x28(%r12),%rcx
 29f2a30:	mov    0x20(%r12),%rsi
 29f2a35:	mov    %eax,%edx
 29f2a37:	lea    (%rsi,%rdx,1),%rax
 29f2a3b:	xor    %rsi,%rsi
 29f2a3e:	cmp    %rcx,%rdx
 29f2a41:	cmova  %rsi,%rax
 29f2a45:	mov    0x18(%rax),%ebx
 29f2a48:	mov    0x10(%rax),%r10
 29f2a4c:	mov    0x1c(%rax),%r11d
 29f2a50:	jmp    29f2adc <wasm[0]::function[1015]::helper::object_read+0x11bbc>
 29f2a55:	xor    %eax,%eax
 29f2a57:	test   $0x1,%edx
 29f2a5d:	jne    29f2aa0 <wasm[0]::function[1015]::helper::object_read+0x11b80>
 29f2a63:	mov    0x2e0(%rsp),%r12
 29f2a6b:	mov    0x28(%r12),%rax
 29f2a70:	mov    0x20(%r12),%rcx
 29f2a75:	mov    %edx,%esi
 29f2a77:	lea    0x4(%rcx,%rsi,1),%rcx
 29f2a7c:	xor    %rdi,%rdi
 29f2a7f:	cmp    %rax,%rsi
 29f2a82:	cmova  %rdi,%rcx
 29f2a86:	mov    (%rcx),%eax
 29f2a88:	mov    0x190(%rsp),%rsi
 29f2a90:	mov    0x28(%rsi),%rcx
 29f2a94:	cmp    0x120(%rcx),%eax
 29f2a9a:	sete   %al
 29f2a9d:	movzbl %al,%eax
 29f2aa0:	test   %eax,%eax
 29f2aa2:	je     29fc441 <wasm[0]::function[1015]::helper::object_read+0x1b521>
 29f2aa8:	test   %edx,%edx
 29f2aaa:	je     29fc443 <wasm[0]::function[1015]::helper::object_read+0x1b523>
 29f2ab0:	mov    0x2e0(%rsp),%r12
 29f2ab8:	mov    0x28(%r12),%rcx
 29f2abd:	mov    0x20(%r12),%rax
 29f2ac2:	mov    %edx,%edx
 29f2ac4:	add    %rdx,%rax
 29f2ac7:	xor    %rsi,%rsi
 29f2aca:	cmp    %rcx,%rdx
 29f2acd:	cmova  %rsi,%rax
 29f2ad1:	mov    0x18(%rax),%ebx
 29f2ad4:	mov    0x10(%rax),%r10
 29f2ad8:	mov    0x1c(%rax),%r11d
 29f2adc:	mov    0x278(%rsp),%rax
 29f2ae4:	mov    %rax,0x220(%rsp)
 29f2aec:	mov    0x88(%rsp),%eax
 29f2af3:	mov    0xc0(%rsp),%r8d
 29f2afb:	mov    0x98(%rsp),%edx
 29f2b02:	mov    0xd8(%rsp),%esi
 29f2b09:	mov    0xa8(%rsp),%edi
 29f2b10:	mov    %r10,0x200(%rsp)
 29f2b18:	mov    %rbx,0x208(%rsp)
 29f2b20:	jmp    29f3390 <wasm[0]::function[1015]::helper::object_read+0x12470>
 29f2b25:	mov    0xb0(%rsp),%eax
 29f2b2c:	test   %eax,%eax
 29f2b2e:	je     29fc445 <wasm[0]::function[1015]::helper::object_read+0x1b525>
 29f2b34:	mov    0xb0(%rsp),%ecx
 29f2b3b:	xor    %eax,%eax
 29f2b3d:	test   $0x1,%ecx
 29f2b43:	jne    29f2b9d <wasm[0]::function[1015]::helper::object_read+0x11c7d>
 29f2b49:	mov    0x2e0(%rsp),%r12
 29f2b51:	mov    0x28(%r12),%rax
 29f2b56:	mov    0x20(%r12),%rsi
 29f2b5b:	mov    %ecx,%edx
 29f2b5d:	lea    0x4(%rsi,%rdx,1),%rcx
 29f2b62:	xor    %rsi,%rsi
 29f2b65:	cmp    %rax,%rdx
 29f2b68:	cmova  %rsi,%rcx
 29f2b6c:	mov    (%rcx),%esi
 29f2b6e:	mov    0x190(%rsp),%rax
 29f2b76:	mov    0x28(%rax),%rax
 29f2b7a:	mov    0x158(%rax),%edx
 29f2b80:	cmp    %edx,%esi
 29f2b82:	sete   %al
 29f2b85:	movzbl %al,%eax
 29f2b88:	cmp    %edx,%esi
 29f2b8a:	je     29f2b9d <wasm[0]::function[1015]::helper::object_read+0x11c7d>
 29f2b90:	mov    0x190(%rsp),%rdi
 29f2b98:	call   3018e75 <wasmtime_builtin_is_subtype>
 29f2b9d:	test   %eax,%eax
 29f2b9f:	je     29fc447 <wasm[0]::function[1015]::helper::object_read+0x1b527>
 29f2ba5:	mov    0xb0(%rsp),%r9d
 29f2bad:	mov    0x88(%rsp),%eax
 29f2bb4:	mov    0xc0(%rsp),%r8d
 29f2bbc:	mov    0x98(%rsp),%edx
 29f2bc3:	mov    0x78(%rsp),%r11d
 29f2bc8:	mov    0xd8(%rsp),%esi
 29f2bcf:	mov    0xa8(%rsp),%edi
 29f2bd6:	xor    %ecx,%ecx
 29f2bd8:	mov    %rcx,%r15
 29f2bdb:	test   %r9d,%r9d
 29f2bde:	je     29fc449 <wasm[0]::function[1015]::helper::object_read+0x1b529>
 29f2be4:	test   %r9d,%r9d
 29f2be7:	je     29fc44b <wasm[0]::function[1015]::helper::object_read+0x1b52b>
 29f2bed:	mov    0x2e0(%rsp),%r12
 29f2bf5:	mov    0x28(%r12),%rcx
 29f2bfa:	mov    0x20(%r12),%r12
 29f2bff:	mov    %r9d,%r14d
 29f2c02:	lea    (%r12,%r14,1),%r10
 29f2c06:	xor    %r13,%r13
 29f2c09:	cmp    %rcx,%r14
 29f2c0c:	cmova  %r13,%r10
 29f2c10:	mov    0x10(%r10),%r10d
 29f2c14:	test   %r10d,%r10d
 29f2c17:	je     29fc44d <wasm[0]::function[1015]::helper::object_read+0x1b52d>
 29f2c1d:	test   %r10d,%r10d
 29f2c20:	je     29fc44f <wasm[0]::function[1015]::helper::object_read+0x1b52f>
 29f2c26:	mov    %r10d,%r14d
 29f2c29:	lea    (%r12,%r14,1),%r10
 29f2c2d:	cmp    %rcx,%r14
 29f2c30:	cmova  %r13,%r10
 29f2c34:	mov    0x10(%r10),%r10d
 29f2c38:	test   %r10d,%r10d
 29f2c3b:	je     29fc451 <wasm[0]::function[1015]::helper::object_read+0x1b531>
 29f2c41:	test   %r10d,%r10d
 29f2c44:	je     29fc453 <wasm[0]::function[1015]::helper::object_read+0x1b533>
 29f2c4a:	mov    %r10d,%r14d
 29f2c4d:	lea    0x10(%r12,%r14,1),%rbx
 29f2c52:	cmp    %rcx,%r14
 29f2c55:	cmova  %r13,%rbx
 29f2c59:	mov    (%rbx),%ebx
 29f2c5b:	mov    0xb8(%rsp),%r12d
 29f2c63:	mov    0x190(%rsp),%rcx
 29f2c6b:	mov    0x28(%rcx),%rcx
 29f2c6f:	mov    0x234(%rcx),%r13d
 29f2c76:	mov    %r15,0x220(%rsp)
 29f2c7e:	mov    %r10d,0xc8(%rsp)
 29f2c86:	mov    %r12d,0xa8(%rsp)
 29f2c8e:	mov    %r9d,0xd8(%rsp)
 29f2c96:	mov    %eax,0x78(%rsp)
 29f2c9a:	mov    %r8d,0x98(%rsp)
 29f2ca2:	mov    %edx,0xc0(%rsp)
 29f2ca9:	mov    %r11d,0x88(%rsp)
 29f2cb1:	mov    %esi,0xb0(%rsp)
 29f2cb8:	mov    %edi,0xb8(%rsp)
 29f2cbf:	mov    0x2e8(%rsp),%rcx
 29f2cc7:	mov    (%rcx),%rax
 29f2cca:	mov    0x228(%rsp),%rcx
 29f2cd2:	cmp    %rcx,%rax
 29f2cd5:	jae    29fb416 <wasm[0]::function[1015]::helper::object_read+0x1a4f6>
 29f2cdb:	mov    0xd8(%rsp),%r9d
 29f2ce3:	mov    0x78(%rsp),%eax
 29f2ce7:	mov    0x98(%rsp),%r8d
 29f2cef:	mov    0xc0(%rsp),%edx
 29f2cf6:	mov    0x88(%rsp),%r11d
 29f2cfe:	mov    0xb0(%rsp),%esi
 29f2d05:	mov    0xb8(%rsp),%edi
 29f2d0c:	mov    %r15,%rcx
 29f2d0f:	cmp    %ebx,%ecx
 29f2d11:	jae    29f2f22 <wasm[0]::function[1015]::helper::object_read+0x12002>
 29f2d17:	mov    0xc8(%rsp),%eax
 29f2d1e:	test   %eax,%eax
 29f2d20:	je     29fc455 <wasm[0]::function[1015]::helper::object_read+0x1b535>
 29f2d26:	test   %eax,%eax
 29f2d28:	je     29fc457 <wasm[0]::function[1015]::helper::object_read+0x1b537>
 29f2d2e:	mov    0x2e0(%rsp),%r12
 29f2d36:	mov    0x28(%r12),%rdx
 29f2d3b:	mov    0x20(%r12),%rsi
 29f2d40:	mov    %eax,%r9d
 29f2d43:	lea    0x10(%rsi,%r9,1),%r8
 29f2d48:	xor    %rdi,%rdi
 29f2d4b:	cmp    %rdx,%r9
 29f2d4e:	cmova  %rdi,%r8
 29f2d52:	mov    (%r8),%r8d
 29f2d55:	cmp    %r8d,%ecx
 29f2d58:	jae    29fc459 <wasm[0]::function[1015]::helper::object_read+0x1b539>
 29f2d5e:	mov    %r8d,%r9d
 29f2d61:	shl    $0x2,%r9
 29f2d65:	shr    $0x20,%r9
 29f2d69:	test   %r9,%r9
 29f2d6c:	jne    29fc45b <wasm[0]::function[1015]::helper::object_read+0x1b53b>
 29f2d72:	shl    $0x2,%r8d
 29f2d76:	add    $0x14,%r8d
 29f2d7a:	jb     29fc45d <wasm[0]::function[1015]::helper::object_read+0x1b53d>
 29f2d80:	add    %r8d,%eax
 29f2d83:	jb     29fc45f <wasm[0]::function[1015]::helper::object_read+0x1b53f>
 29f2d89:	mov    %eax,%r9d
 29f2d8c:	lea    (%rsi,%r9,1),%rax
 29f2d90:	cmp    %rdx,%r9
 29f2d93:	cmova  %rdi,%rax
 29f2d97:	mov    %rcx,%rdx
 29f2d9a:	shl    $0x2,%edx
 29f2d9d:	mov    %rcx,%r15
 29f2da0:	lea    0x14(%rdx),%ecx
 29f2da3:	sub    %ecx,%r8d
 29f2da6:	sub    %r8,%rax
 29f2da9:	mov    (%rax),%edx
 29f2dab:	test   %edx,%edx
 29f2dad:	je     29fc461 <wasm[0]::function[1015]::helper::object_read+0x1b541>
 29f2db3:	mov    0xa8(%rsp),%eax
 29f2dba:	cmp    %eax,%edx
 29f2dbc:	je     29f2e9f <wasm[0]::function[1015]::helper::object_read+0x11f7f>
 29f2dc2:	xor    %ecx,%ecx
 29f2dc4:	test   %edx,%edx
 29f2dc6:	je     29f2e0a <wasm[0]::function[1015]::helper::object_read+0x11eea>
 29f2dcc:	xor    %ecx,%ecx
 29f2dce:	test   $0x1,%edx
 29f2dd4:	jne    29f2e0a <wasm[0]::function[1015]::helper::object_read+0x11eea>
 29f2dda:	mov    0x2e0(%rsp),%r12
 29f2de2:	mov    0x28(%r12),%rcx
 29f2de7:	mov    0x20(%r12),%rsi
 29f2dec:	mov    %edx,%edi
 29f2dee:	lea    0x4(%rsi,%rdi,1),%rsi
 29f2df3:	xor    %r8,%r8
 29f2df6:	cmp    %rcx,%rdi
 29f2df9:	cmova  %r8,%rsi
 29f2dfd:	mov    (%rsi),%ecx
 29f2dff:	cmp    %r13d,%ecx
 29f2e02:	sete   %sil
 29f2e06:	movzbl %sil,%ecx
 29f2e0a:	test   %ecx,%ecx
 29f2e0c:	je     29fc463 <wasm[0]::function[1015]::helper::object_read+0x1b543>
 29f2e12:	xor    %ecx,%ecx
 29f2e14:	test   %eax,%eax
 29f2e16:	je     29f2e63 <wasm[0]::function[1015]::helper::object_read+0x11f43>
 29f2e1c:	mov    0xa8(%rsp),%r8d
 29f2e24:	xor    %ecx,%ecx
 29f2e26:	test   $0x1,%r8d
 29f2e2d:	jne    29f2e63 <wasm[0]::function[1015]::helper::object_read+0x11f43>
 29f2e33:	mov    0x2e0(%rsp),%r12
 29f2e3b:	mov    0x28(%r12),%r11
 29f2e40:	mov    0x20(%r12),%rcx
 29f2e45:	mov    %r8d,%eax
 29f2e48:	lea    0x4(%rcx,%rax,1),%r8
 29f2e4d:	xor    %rcx,%rcx
 29f2e50:	cmp    %r11,%rax
 29f2e53:	cmova  %rcx,%r8
 29f2e57:	mov    (%r8),%eax
 29f2e5a:	cmp    %r13d,%eax
 29f2e5d:	sete   %al
 29f2e60:	movzbl %al,%ecx
 29f2e63:	test   %ecx,%ecx
 29f2e65:	je     29fc465 <wasm[0]::function[1015]::helper::object_read+0x1b545>
 29f2e6b:	mov    0xa8(%rsp),%ecx
 29f2e72:	xor    %r8d,%r8d
 29f2e75:	test   %ecx,%ecx
 29f2e77:	je     29fc467 <wasm[0]::function[1015]::helper::object_read+0x1b547>
 29f2e7d:	mov    0x190(%rsp),%rsi
 29f2e85:	mov    0x190(%rsp),%rdi
 29f2e8d:	call   2ae54e0 <wasm[0]::function[1057]::helper::string_equality>
 29f2e92:	mov    %rax,0x220(%rsp)
 29f2e9a:	jmp    29f2eaf <wasm[0]::function[1015]::helper::object_read+0x11f8f>
 29f2e9f:	mov    0x278(%rsp),%rax
 29f2ea7:	mov    %rax,0x220(%rsp)
 29f2eaf:	mov    0xc8(%rsp),%r10d
 29f2eb7:	mov    0xa8(%rsp),%r12d
 29f2ebf:	mov    0xd8(%rsp),%r9d
 29f2ec7:	mov    0x78(%rsp),%eax
 29f2ecb:	mov    0x98(%rsp),%r8d
 29f2ed3:	mov    0xc0(%rsp),%edx
 29f2eda:	mov    0x88(%rsp),%r11d
 29f2ee2:	mov    0xb0(%rsp),%esi
 29f2ee9:	mov    0xb8(%rsp),%edi
 29f2ef0:	mov    0x220(%rsp),%rcx
 29f2ef8:	mov    0x220(%rsp),%r14
 29f2f00:	test   %r14d,%ecx
 29f2f03:	je     29f2f11 <wasm[0]::function[1015]::helper::object_read+0x11ff1>
 29f2f09:	mov    %r15,%rcx
 29f2f0c:	jmp    29f2f22 <wasm[0]::function[1015]::helper::object_read+0x12002>
 29f2f11:	mov    %r15,%rcx
 29f2f14:	add    $0x1,%ecx
 29f2f1a:	mov    %rcx,%r15
 29f2f1d:	jmp    29f2c7e <wasm[0]::function[1015]::helper::object_read+0x11d5e>
 29f2f22:	xor    %r10,%r10
 29f2f25:	xor    %ebx,%ebx
 29f2f27:	mov    0x220(%rsp),%r12
 29f2f2f:	mov    0x220(%rsp),%r13
 29f2f37:	test   %r13d,%r12d
 29f2f3a:	jne    29f2f55 <wasm[0]::function[1015]::helper::object_read+0x12035>
 29f2f40:	mov    %r10,0x200(%rsp)
 29f2f48:	mov    %rbx,0x208(%rsp)
 29f2f50:	jmp    29f3390 <wasm[0]::function[1015]::helper::object_read+0x12470>
 29f2f55:	test   %r9d,%r9d
 29f2f58:	je     29fc469 <wasm[0]::function[1015]::helper::object_read+0x1b549>
 29f2f5e:	xor    %r10d,%r10d
 29f2f61:	test   $0x1,%r9d
 29f2f68:	jne    29f2fb0 <wasm[0]::function[1015]::helper::object_read+0x12090>
 29f2f6e:	mov    0x2e0(%rsp),%r12
 29f2f76:	mov    0x28(%r12),%r10
 29f2f7b:	mov    0x20(%r12),%r11
 29f2f80:	mov    %r9d,%ebx
 29f2f83:	lea    0x4(%r11,%rbx,1),%r11
 29f2f88:	xor    %r12,%r12
 29f2f8b:	cmp    %r10,%rbx
 29f2f8e:	cmova  %r12,%r11
 29f2f92:	mov    (%r11),%r10d
 29f2f95:	mov    0x190(%rsp),%r11
 29f2f9d:	mov    0x28(%r11),%r11
 29f2fa1:	cmp    0x160(%r11),%r10d
 29f2fa8:	sete   %r10b
 29f2fac:	movzbl %r10b,%r10d
 29f2fb0:	test   %r10d,%r10d
 29f2fb3:	jne    29f3203 <wasm[0]::function[1015]::helper::object_read+0x122e3>
 29f2fb9:	xor    %r10d,%r10d
 29f2fbc:	test   $0x1,%r9d
 29f2fc3:	jne    29f300b <wasm[0]::function[1015]::helper::object_read+0x120eb>
 29f2fc9:	mov    0x2e0(%rsp),%r12
 29f2fd1:	mov    0x28(%r12),%r10
 29f2fd6:	mov    0x20(%r12),%r11
 29f2fdb:	mov    %r9d,%ebx
 29f2fde:	lea    0x4(%r11,%rbx,1),%r11
 29f2fe3:	xor    %r12,%r12
 29f2fe6:	cmp    %r10,%rbx
 29f2fe9:	cmova  %r12,%r11
 29f2fed:	mov    (%r11),%r10d
 29f2ff0:	mov    0x190(%rsp),%r11
 29f2ff8:	mov    0x28(%r11),%r11
 29f2ffc:	cmp    0x15c(%r11),%r10d
 29f3003:	sete   %r10b
 29f3007:	movzbl %r10b,%r10d
 29f300b:	test   %r10d,%r10d
 29f300e:	je     29fc46b <wasm[0]::function[1015]::helper::object_read+0x1b54b>
 29f3014:	test   %r9d,%r9d
 29f3017:	je     29fc46d <wasm[0]::function[1015]::helper::object_read+0x1b54d>
 29f301d:	mov    0x2e0(%rsp),%r12
 29f3025:	mov    0x28(%r12),%rbx
 29f302a:	mov    0x20(%r12),%r12
 29f302f:	mov    %r9d,%r11d
 29f3032:	lea    (%r12,%r11,1),%r9
 29f3036:	xor    %r10,%r10
 29f3039:	cmp    %rbx,%r11
 29f303c:	cmova  %r10,%r9
 29f3040:	mov    0x14(%r9),%r13d
 29f3044:	mov    0x18(%r9),%r11d
 29f3048:	mov    0x1c(%r9),%r9d
 29f304c:	test   %r13d,%r13d
 29f304f:	je     29fc46f <wasm[0]::function[1015]::helper::object_read+0x1b54f>
 29f3055:	test   %r13d,%r13d
 29f3058:	je     29fc471 <wasm[0]::function[1015]::helper::object_read+0x1b551>
 29f305e:	mov    %r13d,%r15d
 29f3061:	lea    0x10(%r12,%r15,1),%r14
 29f3066:	cmp    %rbx,%r15
 29f3069:	cmova  %r10,%r14
 29f306d:	mov    (%r14),%r14d
 29f3070:	cmp    %r14d,%ecx
 29f3073:	jae    29fc473 <wasm[0]::function[1015]::helper::object_read+0x1b553>
 29f3079:	mov    %r14d,%r15d
 29f307c:	shr    $0x20,%r15
 29f3080:	test   %r15,%r15
 29f3083:	jne    29fc475 <wasm[0]::function[1015]::helper::object_read+0x1b555>
 29f3089:	add    $0x14,%r14d
 29f308d:	jb     29fc477 <wasm[0]::function[1015]::helper::object_read+0x1b557>
 29f3093:	add    %r14d,%r13d
 29f3096:	jb     29fc479 <wasm[0]::function[1015]::helper::object_read+0x1b559>
 29f309c:	mov    %r13d,%r13d
 29f309f:	add    %r13,%r12
 29f30a2:	cmp    %rbx,%r13
 29f30a5:	cmova  %r10,%r12
 29f30a9:	lea    0x14(%rcx),%ebx
 29f30ac:	sub    %ebx,%r14d
 29f30af:	sub    %r14,%r12
 29f30b2:	movzbq (%r12),%rbx
 29f30b7:	test   %r11d,%r11d
 29f30ba:	je     29f3152 <wasm[0]::function[1015]::helper::object_read+0x12232>
 29f30c0:	test   %r11d,%r11d
 29f30c3:	je     29fc47b <wasm[0]::function[1015]::helper::object_read+0x1b55b>
 29f30c9:	test   %r11d,%r11d
 29f30cc:	je     29fc47d <wasm[0]::function[1015]::helper::object_read+0x1b55d>
 29f30d2:	mov    0x2e0(%rsp),%r12
 29f30da:	mov    0x28(%r12),%r10
 29f30df:	mov    0x20(%r12),%r12
 29f30e4:	mov    %r11d,%r15d
 29f30e7:	lea    0x10(%r12,%r15,1),%r14
 29f30ec:	xor    %r13,%r13
 29f30ef:	cmp    %r10,%r15
 29f30f2:	cmova  %r13,%r14
 29f30f6:	mov    (%r14),%r14d
 29f30f9:	cmp    %r14d,%ecx
 29f30fc:	jae    29fc47f <wasm[0]::function[1015]::helper::object_read+0x1b55f>
 29f3102:	mov    %r14d,%r15d
 29f3105:	shl    $0x3,%r15
 29f3109:	shr    $0x20,%r15
 29f310d:	test   %r15,%r15
 29f3110:	jne    29fc481 <wasm[0]::function[1015]::helper::object_read+0x1b561>
 29f3116:	shl    $0x3,%r14d
 29f311a:	add    $0x18,%r14d
 29f311e:	jb     29fc483 <wasm[0]::function[1015]::helper::object_read+0x1b563>
 29f3124:	add    %r14d,%r11d
 29f3127:	jb     29fc485 <wasm[0]::function[1015]::helper::object_read+0x1b565>
 29f312d:	mov    %r11d,%r15d
 29f3130:	lea    (%r12,%r15,1),%r11
 29f3134:	cmp    %r10,%r15
 29f3137:	cmova  %r13,%r11
 29f313b:	mov    %rcx,%r10
 29f313e:	shl    $0x3,%r10d
 29f3142:	add    $0x18,%r10d
 29f3149:	sub    %r10d,%r14d
 29f314c:	sub    %r14,%r11
 29f314f:	mov    (%r11),%r10
 29f3152:	xor    %r11d,%r11d
 29f3155:	test   %r9d,%r9d
 29f3158:	je     29f31eb <wasm[0]::function[1015]::helper::object_read+0x122cb>
 29f315e:	test   %r9d,%r9d
 29f3161:	je     29fc487 <wasm[0]::function[1015]::helper::object_read+0x1b567>
 29f3167:	test   %r9d,%r9d
 29f316a:	je     29fc489 <wasm[0]::function[1015]::helper::object_read+0x1b569>
 29f3170:	mov    0x2e0(%rsp),%r12
 29f3178:	mov    0x28(%r12),%r11
 29f317d:	mov    0x20(%r12),%r12
 29f3182:	mov    %r9d,%r15d
 29f3185:	lea    0x10(%r12,%r15,1),%r14
 29f318a:	xor    %r13,%r13
 29f318d:	cmp    %r11,%r15
 29f3190:	cmova  %r13,%r14
 29f3194:	mov    (%r14),%r15d
 29f3197:	cmp    %r15d,%ecx
 29f319a:	jae    29fc48b <wasm[0]::function[1015]::helper::object_read+0x1b56b>
 29f31a0:	mov    %r15d,%r14d
 29f31a3:	shl    $0x2,%r14
 29f31a7:	shr    $0x20,%r14
 29f31ab:	test   %r14,%r14
 29f31ae:	jne    29fc48d <wasm[0]::function[1015]::helper::object_read+0x1b56d>
 29f31b4:	shl    $0x2,%r15d
 29f31b8:	add    $0x14,%r15d
 29f31bc:	jb     29fc48f <wasm[0]::function[1015]::helper::object_read+0x1b56f>
 29f31c2:	add    %r15d,%r9d
 29f31c5:	jb     29fc491 <wasm[0]::function[1015]::helper::object_read+0x1b571>
 29f31cb:	mov    %r9d,%r14d
 29f31ce:	lea    (%r12,%r14,1),%r9
 29f31d2:	cmp    %r11,%r14
 29f31d5:	cmova  %r13,%r9
 29f31d9:	shl    $0x2,%ecx
 29f31dc:	add    $0x14,%ecx
 29f31e2:	sub    %ecx,%r15d
 29f31e5:	sub    %r15,%r9
 29f31e8:	mov    (%r9),%r11d
 29f31eb:	movzbl %bl,%ebx
 29f31ee:	mov    %r10,0x200(%rsp)
 29f31f6:	mov    %rbx,0x208(%rsp)
 29f31fe:	jmp    29f3390 <wasm[0]::function[1015]::helper::object_read+0x12470>
 29f3203:	xor    %r10d,%r10d
 29f3206:	test   $0x1,%r9d
 29f320d:	jne    29f3255 <wasm[0]::function[1015]::helper::object_read+0x12335>
 29f3213:	mov    0x2e0(%rsp),%r12
 29f321b:	mov    0x28(%r12),%r10
 29f3220:	mov    0x20(%r12),%r11
 29f3225:	mov    %r9d,%ebx
 29f3228:	lea    0x4(%r11,%rbx,1),%r11
 29f322d:	xor    %r12,%r12
 29f3230:	cmp    %r10,%rbx
 29f3233:	cmova  %r12,%r11
 29f3237:	mov    (%r11),%r10d
 29f323a:	mov    0x190(%rsp),%r11
 29f3242:	mov    0x28(%r11),%r11
 29f3246:	cmp    0x160(%r11),%r10d
 29f324d:	sete   %r10b
 29f3251:	movzbl %r10b,%r10d
 29f3255:	test   %r10d,%r10d
 29f3258:	je     29fc493 <wasm[0]::function[1015]::helper::object_read+0x1b573>
 29f325e:	test   %r9d,%r9d
 29f3261:	je     29fc495 <wasm[0]::function[1015]::helper::object_read+0x1b575>
 29f3267:	mov    0x2e0(%rsp),%r12
 29f326f:	mov    0x28(%r12),%r10
 29f3274:	mov    0x20(%r12),%r11
 29f3279:	mov    %r9d,%r9d
 29f327c:	lea    (%r11,%r9,1),%r12
 29f3280:	xor    %rbx,%rbx
 29f3283:	cmp    %r10,%r9
 29f3286:	cmova  %rbx,%r12
 29f328a:	mov    0x10(%r12),%r12d
 29f328f:	test   %r12d,%r12d
 29f3292:	je     29fc497 <wasm[0]::function[1015]::helper::object_read+0x1b577>
 29f3298:	test   %r12d,%r12d
 29f329b:	je     29fc499 <wasm[0]::function[1015]::helper::object_read+0x1b579>
 29f32a1:	mov    %r12d,%r13d
 29f32a4:	lea    (%r11,%r13,1),%r12
 29f32a8:	cmp    %r10,%r13
 29f32ab:	cmova  %rbx,%r12
 29f32af:	mov    0x10(%r12),%r12d
 29f32b4:	test   %r12d,%r12d
 29f32b7:	je     29fc49b <wasm[0]::function[1015]::helper::object_read+0x1b57b>
 29f32bd:	test   %r12d,%r12d
 29f32c0:	je     29fc49d <wasm[0]::function[1015]::helper::object_read+0x1b57d>
 29f32c6:	mov    %r12d,%r12d
 29f32c9:	lea    0x10(%r11,%r12,1),%r11
 29f32ce:	cmp    %r10,%r12
 29f32d1:	cmova  %rbx,%r11
 29f32d5:	cmp    (%r11),%ecx
 29f32d8:	setae  %r10b
 29f32dc:	cmp    $0x2,%ecx
 29f32df:	setae  %r11b
 29f32e3:	or     %r11d,%r10d
 29f32e6:	test   %r10b,%r10b
 29f32e9:	jne    29fc49f <wasm[0]::function[1015]::helper::object_read+0x1b57f>
 29f32ef:	mov    0x2e0(%rsp),%r12
 29f32f7:	mov    0x28(%r12),%r11
 29f32fc:	mov    %r9,%r10
 29f32ff:	add    0x20(%r12),%r10
 29f3304:	xor    %rbx,%rbx
 29f3307:	cmp    %r11,%r9
 29f330a:	cmova  %rbx,%r10
 29f330e:	mov    0x14(%r10),%ebx
 29f3312:	test   %ecx,%ecx
 29f3314:	je     29f334e <wasm[0]::function[1015]::helper::object_read+0x1242e>
 29f331a:	mov    0x2e0(%rsp),%r12
 29f3322:	mov    0x28(%r12),%r10
 29f3327:	mov    0x20(%r12),%r11
 29f332c:	add    %r9,%r11
 29f332f:	xor    %r12,%r12
 29f3332:	cmp    %r10,%r9
 29f3335:	cmova  %r12,%r11
 29f3339:	mov    0x20(%r11),%r10
 29f333d:	mov    0x2c(%r11),%r11d
 29f3341:	mov    %r10,0x200(%rsp)
 29f3349:	jmp    29f337d <wasm[0]::function[1015]::helper::object_read+0x1245d>
 29f334e:	mov    0x2e0(%rsp),%r12
 29f3356:	mov    0x28(%r12),%r10
 29f335b:	mov    0x20(%r12),%r11
 29f3360:	add    %r9,%r11
 29f3363:	xor    %r12,%r12
 29f3366:	cmp    %r10,%r9
 29f3369:	cmova  %r12,%r11
 29f336d:	mov    0x18(%r11),%r10
 29f3371:	mov    %r10,0x200(%rsp)
 29f3379:	mov    0x28(%r11),%r11d
 29f337d:	shl    $0x3,%ecx
 29f3380:	shr    %cl,%ebx
 29f3382:	and    $0xff,%ebx
 29f3388:	mov    %rbx,0x208(%rsp)
 29f3390:	mov    %eax,0xc0(%rsp)
 29f3397:	mov    %r8d,0x98(%rsp)
 29f339f:	mov    %edx,0x78(%rsp)
 29f33a3:	mov    %r11d,0xd8(%rsp)
 29f33ab:	mov    %esi,0xa8(%rsp)
 29f33b2:	mov    %edi,0xc8(%rsp)
 29f33b9:	mov    $0x27c,%edx
 29f33be:	mov    0x190(%rsp),%rsi
 29f33c6:	mov    0x190(%rsp),%rdi
 29f33ce:	call   2f307a0 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 29f33d3:	mov    %eax,0x88(%rsp)
 29f33da:	xor    %r13d,%r13d
 29f33dd:	test   %eax,%eax
 29f33df:	je     29fc4a1 <wasm[0]::function[1015]::helper::object_read+0x1b581>
 29f33e5:	movl   $0x0,0xb0(%rsp)
 29f33f0:	mov    0xc0(%rsp),%r9d
 29f33f8:	mov    %r9,0x198(%rsp)
 29f3400:	mov    0x98(%rsp),%r9d
 29f3408:	mov    0x78(%rsp),%edx
 29f340c:	mov    0xd8(%rsp),%esi
 29f3413:	mov    0xa8(%rsp),%edi
 29f341a:	mov    0xc8(%rsp),%r8d
 29f3422:	xor    %r11,%r11
 29f3425:	mov    0x250(%rsp),%rax
 29f342d:	mov    0x250(%rsp),%rcx
 29f3435:	test   %al,%cl
 29f3437:	jne    29f345d <wasm[0]::function[1015]::helper::object_read+0x1253d>
 29f343d:	mov    0x198(%rsp),%rax
 29f3445:	mov    %r13,%rbx
 29f3448:	mov    %r11,0x210(%rsp)
 29f3450:	mov    %r13,0x218(%rsp)
 29f3458:	jmp    29f401f <wasm[0]::function[1015]::helper::object_read+0x130ff>
 29f345d:	mov    0xc0(%rsp),%r8d
 29f3465:	mov    0x260(%rsp),%rcx
 29f346d:	mov    0x258(%rsp),%rdx
 29f3475:	mov    0x190(%rsp),%rsi
 29f347d:	mov    0x190(%rsp),%rdi
 29f3485:	call   2a5f620 <wasm[0]::function[1039]::helper::object_header_projection>
 29f348a:	mov    %eax,0xb8(%rsp)
 29f3491:	test   %eax,%eax
 29f3493:	je     29fc4a3 <wasm[0]::function[1015]::helper::object_read+0x1b583>
 29f3499:	test   %eax,%eax
 29f349b:	je     29fc4a5 <wasm[0]::function[1015]::helper::object_read+0x1b585>
 29f34a1:	mov    0x2e0(%rsp),%r12
 29f34a9:	mov    0x28(%r12),%rcx
 29f34ae:	mov    0x20(%r12),%rsi
 29f34b3:	mov    %eax,%edx
 29f34b5:	lea    (%rsi,%rdx,1),%rax
 29f34b9:	xor    %rsi,%rsi
 29f34bc:	cmp    %rcx,%rdx
 29f34bf:	cmova  %rsi,%rax
 29f34c3:	mov    0x14(%rax),%eax
 29f34c6:	mov    %eax,0xd0(%rsp)
 29f34cd:	test   %eax,%eax
 29f34cf:	je     29fc4a7 <wasm[0]::function[1015]::helper::object_read+0x1b587>
 29f34d5:	mov    0xd0(%rsp),%ecx
 29f34dc:	xor    %eax,%eax
 29f34de:	test   $0x1,%ecx
 29f34e4:	jne    29f353e <wasm[0]::function[1015]::helper::object_read+0x1261e>
 29f34ea:	mov    0x2e0(%rsp),%r12
 29f34f2:	mov    0x28(%r12),%rax
 29f34f7:	mov    0x20(%r12),%rsi
 29f34fc:	mov    %ecx,%edx
 29f34fe:	lea    0x4(%rsi,%rdx,1),%rcx
 29f3503:	xor    %rsi,%rsi
 29f3506:	cmp    %rax,%rdx
 29f3509:	cmova  %rsi,%rcx
 29f350d:	mov    (%rcx),%esi
 29f350f:	mov    0x190(%rsp),%rax
 29f3517:	mov    0x28(%rax),%rax
 29f351b:	mov    0x158(%rax),%edx
 29f3521:	cmp    %edx,%esi
 29f3523:	sete   %al
 29f3526:	movzbl %al,%eax
 29f3529:	cmp    %edx,%esi
 29f352b:	je     29f353e <wasm[0]::function[1015]::helper::object_read+0x1261e>
 29f3531:	mov    0x190(%rsp),%rdi
 29f3539:	call   3018e75 <wasmtime_builtin_is_subtype>
 29f353e:	test   %eax,%eax
 29f3540:	jne    29f379a <wasm[0]::function[1015]::helper::object_read+0x1287a>
 29f3546:	mov    0xb8(%rsp),%edx
 29f354d:	xor    %r12d,%r12d
 29f3550:	test   %edx,%edx
 29f3552:	je     29fc4a9 <wasm[0]::function[1015]::helper::object_read+0x1b589>
 29f3558:	mov    0x88(%rsp),%r9d
 29f3560:	mov    $0x4,%ecx
 29f3565:	xor    %r8,%r8
 29f3568:	mov    0x190(%rsp),%rsi
 29f3570:	mov    0x190(%rsp),%rdi
 29f3578:	call   2a58e20 <wasm[0]::function[1032]::helper::ordinary_property_find>
 29f357d:	test   %eax,%eax
 29f357f:	je     29f35ba <wasm[0]::function[1015]::helper::object_read+0x1269a>
 29f3585:	test   %eax,%eax
 29f3587:	je     29fc4ab <wasm[0]::function[1015]::helper::object_read+0x1b58b>
 29f358d:	test   %eax,%eax
 29f358f:	je     29fc4ad <wasm[0]::function[1015]::helper::object_read+0x1b58d>
 29f3595:	mov    0x2e0(%rsp),%r12
 29f359d:	mov    0x28(%r12),%rcx
 29f35a2:	mov    %eax,%edx
 29f35a4:	mov    %rdx,%rax
 29f35a7:	add    0x20(%r12),%rax
 29f35ac:	xor    %rsi,%rsi
 29f35af:	cmp    %rcx,%rdx
 29f35b2:	cmova  %rsi,%rax
 29f35b6:	mov    0x14(%rax),%r12d
 29f35ba:	mov    0xb0(%rsp),%ebx
 29f35c1:	xor    %r11,%r11
 29f35c4:	xor    %r13d,%r13d
 29f35c7:	test   %r12d,%r12d
 29f35ca:	je     29f3753 <wasm[0]::function[1015]::helper::object_read+0x12833>
 29f35d0:	test   %r12d,%r12d
 29f35d3:	je     29fc4af <wasm[0]::function[1015]::helper::object_read+0x1b58f>
 29f35d9:	mov    0x2e0(%rsp),%rax
 29f35e1:	mov    0x28(%rax),%rcx
 29f35e5:	mov    0x20(%rax),%rax
 29f35e9:	mov    %r12d,%edx
 29f35ec:	add    %rdx,%rax
 29f35ef:	xor    %r11,%r11
 29f35f2:	cmp    %rcx,%rdx
 29f35f5:	cmova  %r11,%rax
 29f35f9:	mov    0x10(%rax),%ecx
 29f35fc:	mov    0xb0(%rsp),%ebx
 29f3603:	xor    %r13d,%r13d
 29f3606:	test   $0x1,%ecx
 29f360c:	jne    29f3753 <wasm[0]::function[1015]::helper::object_read+0x12833>
 29f3612:	mov    0x14(%rax),%edx
 29f3615:	test   %edx,%edx
 29f3617:	je     29fc4b1 <wasm[0]::function[1015]::helper::object_read+0x1b591>
 29f361d:	xor    %eax,%eax
 29f361f:	test   $0x1,%edx
 29f3625:	jne    29f366d <wasm[0]::function[1015]::helper::object_read+0x1274d>
 29f362b:	mov    0x2e0(%rsp),%r12
 29f3633:	mov    0x28(%r12),%r9
 29f3638:	mov    0x20(%r12),%r11
 29f363d:	mov    %edx,%r10d
 29f3640:	lea    0x4(%r11,%r10,1),%rsi
 29f3645:	xor    %r11,%r11
 29f3648:	cmp    %r9,%r10
 29f364b:	cmova  %r11,%rsi
 29f364f:	mov    (%rsi),%r10d
 29f3652:	mov    0x190(%rsp),%rsi
 29f365a:	mov    0x28(%rsi),%r11
 29f365e:	cmp    0x120(%r11),%r10d
 29f3665:	sete   %r11b
 29f3669:	movzbl %r11b,%eax
 29f366d:	test   %eax,%eax
 29f366f:	jne    29f36cc <wasm[0]::function[1015]::helper::object_read+0x127ac>
 29f3675:	mov    0x190(%rsp),%rsi
 29f367d:	mov    0x190(%rsp),%rdi
 29f3685:	call   2a01ba0 <wasm[0]::function[1024]::helper::property_value_resolve>
 29f368a:	test   %eax,%eax
 29f368c:	je     29fc4b3 <wasm[0]::function[1015]::helper::object_read+0x1b593>
 29f3692:	test   %eax,%eax
 29f3694:	je     29fc4b5 <wasm[0]::function[1015]::helper::object_read+0x1b595>
 29f369a:	mov    0x2e0(%rsp),%r12
 29f36a2:	mov    0x28(%r12),%rcx
 29f36a7:	mov    0x20(%r12),%rsi
 29f36ac:	mov    %eax,%edx
 29f36ae:	lea    (%rsi,%rdx,1),%rax
 29f36b2:	xor    %rsi,%rsi
 29f36b5:	cmp    %rcx,%rdx
 29f36b8:	cmova  %rsi,%rax
 29f36bc:	mov    0x18(%rax),%r13d
 29f36c0:	mov    0x10(%rax),%r11
 29f36c4:	mov    0x1c(%rax),%ebx
 29f36c7:	jmp    29f3753 <wasm[0]::function[1015]::helper::object_read+0x12833>
 29f36cc:	xor    %eax,%eax
 29f36ce:	test   $0x1,%edx
 29f36d4:	jne    29f3717 <wasm[0]::function[1015]::helper::object_read+0x127f7>
 29f36da:	mov    0x2e0(%rsp),%r12
 29f36e2:	mov    0x28(%r12),%rax
 29f36e7:	mov    0x20(%r12),%rcx
 29f36ec:	mov    %edx,%esi
 29f36ee:	lea    0x4(%rcx,%rsi,1),%rcx
 29f36f3:	xor    %rdi,%rdi
 29f36f6:	cmp    %rax,%rsi
 29f36f9:	cmova  %rdi,%rcx
 29f36fd:	mov    (%rcx),%eax
 29f36ff:	mov    0x190(%rsp),%rsi
 29f3707:	mov    0x28(%rsi),%rcx
 29f370b:	cmp    0x120(%rcx),%eax
 29f3711:	sete   %al
 29f3714:	movzbl %al,%eax
 29f3717:	test   %eax,%eax
 29f3719:	je     29fc4b7 <wasm[0]::function[1015]::helper::object_read+0x1b597>
 29f371f:	test   %edx,%edx
 29f3721:	je     29fc4b9 <wasm[0]::function[1015]::helper::object_read+0x1b599>
 29f3727:	mov    0x2e0(%rsp),%r12
 29f372f:	mov    0x28(%r12),%rcx
 29f3734:	mov    0x20(%r12),%rax
 29f3739:	mov    %edx,%edx
 29f373b:	add    %rdx,%rax
 29f373e:	xor    %rsi,%rsi
 29f3741:	cmp    %rcx,%rdx
 29f3744:	cmova  %rsi,%rax
 29f3748:	mov    0x18(%rax),%r13d
 29f374c:	mov    0x10(%rax),%r11
 29f3750:	mov    0x1c(%rax),%ebx
 29f3753:	mov    0xc0(%rsp),%r9d
 29f375b:	mov    %r9,0x198(%rsp)
 29f3763:	mov    0x98(%rsp),%r9d
 29f376b:	mov    0x78(%rsp),%edx
 29f376f:	mov    0xd8(%rsp),%esi
 29f3776:	mov    0xa8(%rsp),%edi
 29f377d:	mov    0xc8(%rsp),%r8d
 29f3785:	mov    %r11,0x210(%rsp)
 29f378d:	mov    %r13,0x218(%rsp)
 29f3795:	jmp    29f4017 <wasm[0]::function[1015]::helper::object_read+0x130f7>
 29f379a:	mov    0xd0(%rsp),%eax
 29f37a1:	test   %eax,%eax
 29f37a3:	je     29fc4bb <wasm[0]::function[1015]::helper::object_read+0x1b59b>
 29f37a9:	mov    0xd0(%rsp),%ecx
 29f37b0:	xor    %eax,%eax
 29f37b2:	test   $0x1,%ecx
 29f37b8:	jne    29f3812 <wasm[0]::function[1015]::helper::object_read+0x128f2>
 29f37be:	mov    0x2e0(%rsp),%r12
 29f37c6:	mov    0x28(%r12),%rax
 29f37cb:	mov    0x20(%r12),%rsi
 29f37d0:	mov    %ecx,%edx
 29f37d2:	lea    0x4(%rsi,%rdx,1),%rcx
 29f37d7:	xor    %rsi,%rsi
 29f37da:	cmp    %rax,%rdx
 29f37dd:	cmova  %rsi,%rcx
 29f37e1:	mov    (%rcx),%esi
 29f37e3:	mov    0x190(%rsp),%rax
 29f37eb:	mov    0x28(%rax),%rax
 29f37ef:	mov    0x158(%rax),%edx
 29f37f5:	cmp    %edx,%esi
 29f37f7:	sete   %al
 29f37fa:	movzbl %al,%eax
 29f37fd:	cmp    %edx,%esi
 29f37ff:	je     29f3812 <wasm[0]::function[1015]::helper::object_read+0x128f2>
 29f3805:	mov    0x190(%rsp),%rdi
 29f380d:	call   3018e75 <wasmtime_builtin_is_subtype>
 29f3812:	test   %eax,%eax
 29f3814:	je     29fc4bd <wasm[0]::function[1015]::helper::object_read+0x1b59d>
 29f381a:	mov    0xd0(%rsp),%r10d
 29f3822:	mov    0xc0(%rsp),%r9d
 29f382a:	mov    %r9,0x198(%rsp)
 29f3832:	mov    0x98(%rsp),%r9d
 29f383a:	mov    0x78(%rsp),%edx
 29f383e:	mov    0xd8(%rsp),%esi
 29f3845:	mov    0xb0(%rsp),%ebx
 29f384c:	mov    0xa8(%rsp),%edi
 29f3853:	mov    0xc8(%rsp),%r8d
 29f385b:	xor    %ecx,%ecx
 29f385d:	mov    %rcx,%r15
 29f3860:	test   %r10d,%r10d
 29f3863:	je     29fc4bf <wasm[0]::function[1015]::helper::object_read+0x1b59f>
 29f3869:	test   %r10d,%r10d
 29f386c:	je     29fc4c1 <wasm[0]::function[1015]::helper::object_read+0x1b5a1>
 29f3872:	mov    0x2e0(%rsp),%r12
 29f387a:	mov    0x28(%r12),%rax
 29f387f:	mov    0x20(%r12),%rcx
 29f3884:	mov    %r10d,%r13d
 29f3887:	lea    (%rcx,%r13,1),%r11
 29f388b:	xor    %r12,%r12
 29f388e:	cmp    %rax,%r13
 29f3891:	cmova  %r12,%r11
 29f3895:	mov    0x10(%r11),%r11d
 29f3899:	test   %r11d,%r11d
 29f389c:	je     29fc4c3 <wasm[0]::function[1015]::helper::object_read+0x1b5a3>
 29f38a2:	test   %r11d,%r11d
 29f38a5:	je     29fc4c5 <wasm[0]::function[1015]::helper::object_read+0x1b5a5>
 29f38ab:	mov    %r11d,%r13d
 29f38ae:	lea    (%rcx,%r13,1),%r11
 29f38b2:	cmp    %rax,%r13
 29f38b5:	cmova  %r12,%r11
 29f38b9:	mov    0x10(%r11),%r11d
 29f38bd:	test   %r11d,%r11d
 29f38c0:	je     29fc4c7 <wasm[0]::function[1015]::helper::object_read+0x1b5a7>
 29f38c6:	test   %r11d,%r11d
 29f38c9:	je     29fc4c9 <wasm[0]::function[1015]::helper::object_read+0x1b5a9>
 29f38cf:	mov    %r11d,%r13d
 29f38d2:	lea    0x10(%rcx,%r13,1),%rcx
 29f38d7:	cmp    %rax,%r13
 29f38da:	cmova  %r12,%rcx
 29f38de:	mov    (%rcx),%r13d
 29f38e1:	mov    0x88(%rsp),%r12d
 29f38e9:	mov    0x190(%rsp),%rax
 29f38f1:	mov    0x28(%rax),%rax
 29f38f5:	mov    0x234(%rax),%r14d
 29f38fc:	mov    %r15,0x1c8(%rsp)
 29f3904:	mov    %r11d,0xb8(%rsp)
 29f390c:	mov    %r12d,0xc8(%rsp)
 29f3914:	mov    %r10d,0xa8(%rsp)
 29f391c:	mov    0x198(%rsp),%rcx
 29f3924:	mov    %ecx,0xb0(%rsp)
 29f392b:	mov    %r9d,0xd8(%rsp)
 29f3933:	mov    %edx,0x78(%rsp)
 29f3937:	mov    %esi,0x98(%rsp)
 29f393e:	mov    %ebx,0xc0(%rsp)
 29f3945:	mov    %edi,0xd0(%rsp)
 29f394c:	mov    %r8d,0x88(%rsp)
 29f3954:	mov    0x2e8(%rsp),%rax
 29f395c:	mov    (%rax),%rcx
 29f395f:	mov    0x228(%rsp),%rax
 29f3967:	cmp    %rax,%rcx
 29f396a:	jae    29fb44e <wasm[0]::function[1015]::helper::object_read+0x1a52e>
 29f3970:	mov    0xa8(%rsp),%r10d
 29f3978:	mov    0xb0(%rsp),%r9d
 29f3980:	mov    %r9,0x198(%rsp)
 29f3988:	mov    0xd8(%rsp),%r9d
 29f3990:	mov    0x78(%rsp),%edx
 29f3994:	mov    0x98(%rsp),%esi
 29f399b:	mov    0xc0(%rsp),%ebx
 29f39a2:	mov    0xd0(%rsp),%edi
 29f39a9:	mov    0x88(%rsp),%r8d
 29f39b1:	mov    %r15,%rcx
 29f39b4:	cmp    %r13d,%ecx
 29f39b7:	jb     29f39ca <wasm[0]::function[1015]::helper::object_read+0x12aaa>
 29f39bd:	mov    0x1c8(%rsp),%rax
 29f39c5:	jmp    29f3bc5 <wasm[0]::function[1015]::helper::object_read+0x12ca5>
 29f39ca:	mov    0xb8(%rsp),%r11d
 29f39d2:	test   %r11d,%r11d
 29f39d5:	je     29fc4cb <wasm[0]::function[1015]::helper::object_read+0x1b5ab>
 29f39db:	test   %r11d,%r11d
 29f39de:	je     29fc4cd <wasm[0]::function[1015]::helper::object_read+0x1b5ad>
 29f39e4:	mov    0x2e0(%rsp),%r12
 29f39ec:	mov    0x28(%r12),%rax
 29f39f1:	mov    0x20(%r12),%rdx
 29f39f6:	mov    %r11d,%r8d
 29f39f9:	lea    0x10(%rdx,%r8,1),%rdi
 29f39fe:	xor    %rsi,%rsi
 29f3a01:	cmp    %rax,%r8
 29f3a04:	cmova  %rsi,%rdi
 29f3a08:	mov    (%rdi),%edi
 29f3a0a:	cmp    %edi,%ecx
 29f3a0c:	jae    29fc4cf <wasm[0]::function[1015]::helper::object_read+0x1b5af>
 29f3a12:	mov    %edi,%r8d
 29f3a15:	shl    $0x2,%r8
 29f3a19:	shr    $0x20,%r8
 29f3a1d:	test   %r8,%r8
 29f3a20:	jne    29fc4d1 <wasm[0]::function[1015]::helper::object_read+0x1b5b1>
 29f3a26:	shl    $0x2,%edi
 29f3a29:	add    $0x14,%edi
 29f3a2c:	jb     29fc4d3 <wasm[0]::function[1015]::helper::object_read+0x1b5b3>
 29f3a32:	add    %edi,%r11d
 29f3a35:	jb     29fc4d5 <wasm[0]::function[1015]::helper::object_read+0x1b5b5>
 29f3a3b:	mov    %r11d,%r8d
 29f3a3e:	add    %r8,%rdx
 29f3a41:	cmp    %rax,%r8
 29f3a44:	cmova  %rsi,%rdx
 29f3a48:	mov    %rcx,%rax
 29f3a4b:	shl    $0x2,%eax
 29f3a4e:	mov    %rcx,%r15
 29f3a51:	add    $0x14,%eax
 29f3a57:	sub    %eax,%edi
 29f3a59:	sub    %rdi,%rdx
 29f3a5c:	mov    (%rdx),%edx
 29f3a5e:	test   %edx,%edx
 29f3a60:	je     29fc4d7 <wasm[0]::function[1015]::helper::object_read+0x1b5b7>
 29f3a66:	mov    0xc8(%rsp),%eax
 29f3a6d:	cmp    %eax,%edx
 29f3a6f:	je     29f3b43 <wasm[0]::function[1015]::helper::object_read+0x12c23>
 29f3a75:	xor    %ecx,%ecx
 29f3a77:	test   %edx,%edx
 29f3a79:	je     29f3abb <wasm[0]::function[1015]::helper::object_read+0x12b9b>
 29f3a7f:	xor    %ecx,%ecx
 29f3a81:	test   $0x1,%edx
 29f3a87:	jne    29f3abb <wasm[0]::function[1015]::helper::object_read+0x12b9b>
 29f3a8d:	mov    0x2e0(%rsp),%r12
 29f3a95:	mov    0x28(%r12),%rcx
 29f3a9a:	mov    0x20(%r12),%rsi
 29f3a9f:	mov    %edx,%edi
 29f3aa1:	lea    0x4(%rsi,%rdi,1),%rsi
 29f3aa6:	xor    %r8,%r8
 29f3aa9:	cmp    %rcx,%rdi
 29f3aac:	cmova  %r8,%rsi
 29f3ab0:	mov    (%rsi),%ecx
 29f3ab2:	cmp    %r14d,%ecx
 29f3ab5:	sete   %cl
 29f3ab8:	movzbl %cl,%ecx
 29f3abb:	test   %ecx,%ecx
 29f3abd:	je     29fc4d9 <wasm[0]::function[1015]::helper::object_read+0x1b5b9>
 29f3ac3:	xor    %ecx,%ecx
 29f3ac5:	test   %eax,%eax
 29f3ac7:	je     29f3b0f <wasm[0]::function[1015]::helper::object_read+0x12bef>
 29f3acd:	mov    0xc8(%rsp),%eax
 29f3ad4:	xor    %ecx,%ecx
 29f3ad6:	test   $0x1,%eax
 29f3adb:	jne    29f3b0f <wasm[0]::function[1015]::helper::object_read+0x12bef>
 29f3ae1:	mov    0x2e0(%rsp),%r12
 29f3ae9:	mov    0x28(%r12),%rcx
 29f3aee:	mov    0x20(%r12),%rdi
 29f3af3:	mov    %eax,%esi
 29f3af5:	lea    0x4(%rdi,%rsi,1),%rax
 29f3afa:	xor    %rdi,%rdi
 29f3afd:	cmp    %rcx,%rsi
 29f3b00:	cmova  %rdi,%rax
 29f3b04:	mov    (%rax),%eax
 29f3b06:	cmp    %r14d,%eax
 29f3b09:	sete   %al
 29f3b0c:	movzbl %al,%ecx
 29f3b0f:	test   %ecx,%ecx
 29f3b11:	je     29fc4db <wasm[0]::function[1015]::helper::object_read+0x1b5bb>
 29f3b17:	mov    0xc8(%rsp),%ecx
 29f3b1e:	xor    %r8d,%r8d
 29f3b21:	test   %ecx,%ecx
 29f3b23:	je     29fc4dd <wasm[0]::function[1015]::helper::object_read+0x1b5bd>
 29f3b29:	mov    0x190(%rsp),%rsi
 29f3b31:	mov    0x190(%rsp),%rdi
 29f3b39:	call   2ae54e0 <wasm[0]::function[1057]::helper::string_equality>
 29f3b3e:	jmp    29f3b4b <wasm[0]::function[1015]::helper::object_read+0x12c2b>
 29f3b43:	mov    0x278(%rsp),%rax
 29f3b4b:	mov    0xb8(%rsp),%r11d
 29f3b53:	mov    0xc8(%rsp),%r12d
 29f3b5b:	mov    0xa8(%rsp),%r10d
 29f3b63:	mov    0xb0(%rsp),%r9d
 29f3b6b:	mov    %r9,0x198(%rsp)
 29f3b73:	mov    0xd8(%rsp),%r9d
 29f3b7b:	mov    0x78(%rsp),%edx
 29f3b7f:	mov    0x98(%rsp),%esi
 29f3b86:	mov    0xc0(%rsp),%ebx
 29f3b8d:	mov    0xd0(%rsp),%edi
 29f3b94:	mov    0x88(%rsp),%r8d
 29f3b9c:	test   %eax,%eax
 29f3b9e:	je     29f3bac <wasm[0]::function[1015]::helper::object_read+0x12c8c>
 29f3ba4:	mov    %r15,%rcx
 29f3ba7:	jmp    29f3bc5 <wasm[0]::function[1015]::helper::object_read+0x12ca5>
 29f3bac:	mov    %r15,%rcx
 29f3baf:	add    $0x1,%ecx
 29f3bb5:	mov    %rcx,%r15
 29f3bb8:	mov    %rax,0x1c8(%rsp)
 29f3bc0:	jmp    29f3904 <wasm[0]::function[1015]::helper::object_read+0x129e4>
 29f3bc5:	xor    %r11,%r11
 29f3bc8:	xor    %r13d,%r13d
 29f3bcb:	test   %eax,%eax
 29f3bcd:	jne    29f3be8 <wasm[0]::function[1015]::helper::object_read+0x12cc8>
 29f3bd3:	mov    %r11,0x210(%rsp)
 29f3bdb:	mov    %r13,0x218(%rsp)
 29f3be3:	jmp    29f4017 <wasm[0]::function[1015]::helper::object_read+0x130f7>
 29f3be8:	test   %r10d,%r10d
 29f3beb:	je     29fc4df <wasm[0]::function[1015]::helper::object_read+0x1b5bf>
 29f3bf1:	xor    %eax,%eax
 29f3bf3:	test   $0x1,%r10d
 29f3bfa:	jne    29f3c40 <wasm[0]::function[1015]::helper::object_read+0x12d20>
 29f3c00:	mov    0x2e0(%rsp),%r12
 29f3c08:	mov    0x28(%r12),%rax
 29f3c0d:	mov    0x20(%r12),%r11
 29f3c12:	mov    %r10d,%ebx
 29f3c15:	lea    0x4(%r11,%rbx,1),%r11
 29f3c1a:	xor    %r12,%r12
 29f3c1d:	cmp    %rax,%rbx
 29f3c20:	cmova  %r12,%r11
 29f3c24:	mov    (%r11),%eax
 29f3c27:	mov    0x190(%rsp),%r11
 29f3c2f:	mov    0x28(%r11),%r11
 29f3c33:	cmp    0x160(%r11),%eax
 29f3c3a:	sete   %al
 29f3c3d:	movzbl %al,%eax
 29f3c40:	test   %eax,%eax
 29f3c42:	jne    29f3e8a <wasm[0]::function[1015]::helper::object_read+0x12f6a>
 29f3c48:	xor    %eax,%eax
 29f3c4a:	test   $0x1,%r10d
 29f3c51:	jne    29f3c97 <wasm[0]::function[1015]::helper::object_read+0x12d77>
 29f3c57:	mov    0x2e0(%rsp),%r12
 29f3c5f:	mov    0x28(%r12),%rax
 29f3c64:	mov    0x20(%r12),%r11
 29f3c69:	mov    %r10d,%ebx
 29f3c6c:	lea    0x4(%r11,%rbx,1),%r11
 29f3c71:	xor    %r12,%r12
 29f3c74:	cmp    %rax,%rbx
 29f3c77:	cmova  %r12,%r11
 29f3c7b:	mov    (%r11),%eax
 29f3c7e:	mov    0x190(%rsp),%r11
 29f3c86:	mov    0x28(%r11),%r11
 29f3c8a:	cmp    0x15c(%r11),%eax
 29f3c91:	sete   %al
 29f3c94:	movzbl %al,%eax
 29f3c97:	test   %eax,%eax
 29f3c99:	je     29fc4e1 <wasm[0]::function[1015]::helper::object_read+0x1b5c1>
 29f3c9f:	test   %r10d,%r10d
 29f3ca2:	je     29fc4e3 <wasm[0]::function[1015]::helper::object_read+0x1b5c3>
 29f3ca8:	mov    0x2e0(%rsp),%r12
 29f3cb0:	mov    0x28(%r12),%rax
 29f3cb5:	mov    0x20(%r12),%rbx
 29f3cba:	mov    %r10d,%r12d
 29f3cbd:	lea    (%rbx,%r12,1),%r10
 29f3cc1:	xor    %r11,%r11
 29f3cc4:	cmp    %rax,%r12
 29f3cc7:	cmova  %r11,%r10
 29f3ccb:	mov    0x14(%r10),%r12d
 29f3ccf:	mov    0x18(%r10),%r14d
 29f3cd3:	mov    0x1c(%r10),%r10d
 29f3cd7:	test   %r12d,%r12d
 29f3cda:	je     29fc4e5 <wasm[0]::function[1015]::helper::object_read+0x1b5c5>
 29f3ce0:	test   %r12d,%r12d
 29f3ce3:	je     29fc4e7 <wasm[0]::function[1015]::helper::object_read+0x1b5c7>
 29f3ce9:	mov    %r12d,%r15d
 29f3cec:	lea    0x10(%rbx,%r15,1),%r13
 29f3cf1:	cmp    %rax,%r15
 29f3cf4:	cmova  %r11,%r13
 29f3cf8:	mov    0x0(%r13),%r13d
 29f3cfc:	cmp    %r13d,%ecx
 29f3cff:	jae    29fc4e9 <wasm[0]::function[1015]::helper::object_read+0x1b5c9>
 29f3d05:	mov    %r13d,%r15d
 29f3d08:	shr    $0x20,%r15
 29f3d0c:	test   %r15,%r15
 29f3d0f:	jne    29fc4eb <wasm[0]::function[1015]::helper::object_read+0x1b5cb>
 29f3d15:	add    $0x14,%r13d
 29f3d19:	jb     29fc4ed <wasm[0]::function[1015]::helper::object_read+0x1b5cd>
 29f3d1f:	add    %r13d,%r12d
 29f3d22:	jb     29fc4ef <wasm[0]::function[1015]::helper::object_read+0x1b5cf>
 29f3d28:	mov    %r12d,%r12d
 29f3d2b:	add    %r12,%rbx
 29f3d2e:	cmp    %rax,%r12
 29f3d31:	cmova  %r11,%rbx
 29f3d35:	lea    0x14(%rcx),%eax
 29f3d38:	sub    %eax,%r13d
 29f3d3b:	sub    %r13,%rbx
 29f3d3e:	movzbq (%rbx),%r15
 29f3d42:	test   %r14d,%r14d
 29f3d45:	je     29f3ddb <wasm[0]::function[1015]::helper::object_read+0x12ebb>
 29f3d4b:	test   %r14d,%r14d
 29f3d4e:	je     29fc4f1 <wasm[0]::function[1015]::helper::object_read+0x1b5d1>
 29f3d54:	test   %r14d,%r14d
 29f3d57:	je     29fc4f3 <wasm[0]::function[1015]::helper::object_read+0x1b5d3>
 29f3d5d:	mov    0x2e0(%rsp),%r12
 29f3d65:	mov    0x28(%r12),%rax
 29f3d6a:	mov    0x20(%r12),%r11
 29f3d6f:	mov    %r14d,%r13d
 29f3d72:	lea    0x10(%r11,%r13,1),%r12
 29f3d77:	xor    %rbx,%rbx
 29f3d7a:	cmp    %rax,%r13
 29f3d7d:	cmova  %rbx,%r12
 29f3d81:	mov    (%r12),%r12d
 29f3d85:	cmp    %r12d,%ecx
 29f3d88:	jae    29fc4f5 <wasm[0]::function[1015]::helper::object_read+0x1b5d5>
 29f3d8e:	mov    %r12d,%r13d
 29f3d91:	shl    $0x3,%r13
 29f3d95:	shr    $0x20,%r13
 29f3d99:	test   %r13,%r13
 29f3d9c:	jne    29fc4f7 <wasm[0]::function[1015]::helper::object_read+0x1b5d7>
 29f3da2:	shl    $0x3,%r12d
 29f3da6:	add    $0x18,%r12d
 29f3daa:	jb     29fc4f9 <wasm[0]::function[1015]::helper::object_read+0x1b5d9>
 29f3db0:	add    %r12d,%r14d
 29f3db3:	jb     29fc4fb <wasm[0]::function[1015]::helper::object_read+0x1b5db>
 29f3db9:	mov    %r14d,%r13d
 29f3dbc:	add    %r13,%r11
 29f3dbf:	cmp    %rax,%r13
 29f3dc2:	cmova  %rbx,%r11
 29f3dc6:	mov    %rcx,%rax
 29f3dc9:	shl    $0x3,%eax
 29f3dcc:	add    $0x18,%eax
 29f3dd2:	sub    %eax,%r12d
 29f3dd5:	sub    %r12,%r11
 29f3dd8:	mov    (%r11),%r11
 29f3ddb:	xor    %ebx,%ebx
 29f3ddd:	test   %r10d,%r10d
 29f3de0:	je     29f3e71 <wasm[0]::function[1015]::helper::object_read+0x12f51>
 29f3de6:	test   %r10d,%r10d
 29f3de9:	je     29fc4fd <wasm[0]::function[1015]::helper::object_read+0x1b5dd>
 29f3def:	test   %r10d,%r10d
 29f3df2:	je     29fc4ff <wasm[0]::function[1015]::helper::object_read+0x1b5df>
 29f3df8:	mov    0x2e0(%rsp),%r12
 29f3e00:	mov    0x28(%r12),%rax
 29f3e05:	mov    0x20(%r12),%r14
 29f3e0a:	mov    %r10d,%r13d
 29f3e0d:	lea    0x10(%r14,%r13,1),%r12
 29f3e12:	xor    %rbx,%rbx
 29f3e15:	cmp    %rax,%r13
 29f3e18:	cmova  %rbx,%r12
 29f3e1c:	mov    (%r12),%r12d
 29f3e20:	cmp    %r12d,%ecx
 29f3e23:	jae    29fc501 <wasm[0]::function[1015]::helper::object_read+0x1b5e1>
 29f3e29:	mov    %r12d,%r13d
 29f3e2c:	shl    $0x2,%r13
 29f3e30:	shr    $0x20,%r13
 29f3e34:	test   %r13,%r13
 29f3e37:	jne    29fc503 <wasm[0]::function[1015]::helper::object_read+0x1b5e3>
 29f3e3d:	shl    $0x2,%r12d
 29f3e41:	add    $0x14,%r12d
 29f3e45:	jb     29fc505 <wasm[0]::function[1015]::helper::object_read+0x1b5e5>
 29f3e4b:	add    %r12d,%r10d
 29f3e4e:	jb     29fc507 <wasm[0]::function[1015]::helper::object_read+0x1b5e7>
 29f3e54:	mov    %r10d,%r13d
 29f3e57:	lea    (%r14,%r13,1),%r10
 29f3e5b:	cmp    %rax,%r13
 29f3e5e:	cmova  %rbx,%r10
 29f3e62:	shl    $0x2,%ecx
 29f3e65:	lea    0x14(%rcx),%eax
 29f3e68:	sub    %eax,%r12d
 29f3e6b:	sub    %r12,%r10
 29f3e6e:	mov    (%r10),%ebx
 29f3e71:	movzbl %r15b,%r13d
 29f3e75:	mov    %r11,0x210(%rsp)
 29f3e7d:	mov    %r13,0x218(%rsp)
 29f3e85:	jmp    29f4017 <wasm[0]::function[1015]::helper::object_read+0x130f7>
 29f3e8a:	xor    %r11d,%r11d
 29f3e8d:	test   $0x1,%r10d
 29f3e94:	jne    29f3edb <wasm[0]::function[1015]::helper::object_read+0x12fbb>
 29f3e9a:	mov    0x2e0(%rsp),%r12
 29f3ea2:	mov    0x28(%r12),%rax
 29f3ea7:	mov    0x20(%r12),%r11
 29f3eac:	mov    %r10d,%ebx
 29f3eaf:	lea    0x4(%r11,%rbx,1),%r11
 29f3eb4:	xor    %r12,%r12
 29f3eb7:	cmp    %rax,%rbx
 29f3eba:	cmova  %r12,%r11
 29f3ebe:	mov    (%r11),%eax
 29f3ec1:	mov    0x190(%rsp),%r11
 29f3ec9:	mov    0x28(%r11),%r11
 29f3ecd:	cmp    0x160(%r11),%eax
 29f3ed4:	sete   %al
 29f3ed7:	movzbl %al,%r11d
 29f3edb:	test   %r11d,%r11d
 29f3ede:	je     29fc509 <wasm[0]::function[1015]::helper::object_read+0x1b5e9>
 29f3ee4:	test   %r10d,%r10d
 29f3ee7:	je     29fc50b <wasm[0]::function[1015]::helper::object_read+0x1b5eb>
 29f3eed:	mov    0x2e0(%rsp),%r12
 29f3ef5:	mov    0x28(%r12),%r11
 29f3efa:	mov    0x20(%r12),%rbx
 29f3eff:	mov    %r10d,%eax
 29f3f02:	lea    (%rbx,%rax,1),%r12
 29f3f06:	xor    %r10,%r10
 29f3f09:	cmp    %r11,%rax
 29f3f0c:	cmova  %r10,%r12
 29f3f10:	mov    0x10(%r12),%r12d
 29f3f15:	test   %r12d,%r12d
 29f3f18:	je     29fc50d <wasm[0]::function[1015]::helper::object_read+0x1b5ed>
 29f3f1e:	test   %r12d,%r12d
 29f3f21:	je     29fc50f <wasm[0]::function[1015]::helper::object_read+0x1b5ef>
 29f3f27:	mov    %r12d,%r13d
 29f3f2a:	lea    (%rbx,%r13,1),%r12
 29f3f2e:	cmp    %r11,%r13
 29f3f31:	cmova  %r10,%r12
 29f3f35:	mov    0x10(%r12),%r12d
 29f3f3a:	test   %r12d,%r12d
 29f3f3d:	je     29fc511 <wasm[0]::function[1015]::helper::object_read+0x1b5f1>
 29f3f43:	test   %r12d,%r12d
 29f3f46:	je     29fc513 <wasm[0]::function[1015]::helper::object_read+0x1b5f3>
 29f3f4c:	mov    %r12d,%r12d
 29f3f4f:	lea    0x10(%rbx,%r12,1),%rbx
 29f3f54:	cmp    %r11,%r12
 29f3f57:	cmova  %r10,%rbx
 29f3f5b:	cmp    (%rbx),%ecx
 29f3f5d:	setae  %r10b
 29f3f61:	cmp    $0x2,%ecx
 29f3f64:	setae  %r11b
 29f3f68:	or     %r11d,%r10d
 29f3f6b:	test   %r10b,%r10b
 29f3f6e:	jne    29fc515 <wasm[0]::function[1015]::helper::object_read+0x1b5f5>
 29f3f74:	mov    0x2e0(%rsp),%r12
 29f3f7c:	mov    0x28(%r12),%r11
 29f3f81:	mov    %rax,%r10
 29f3f84:	add    0x20(%r12),%r10
 29f3f89:	xor    %rbx,%rbx
 29f3f8c:	cmp    %r11,%rax
 29f3f8f:	cmova  %rbx,%r10
 29f3f93:	mov    0x14(%r10),%r13d
 29f3f97:	test   %ecx,%ecx
 29f3f99:	je     29f3fd3 <wasm[0]::function[1015]::helper::object_read+0x130b3>
 29f3f9f:	mov    0x2e0(%rsp),%r12
 29f3fa7:	mov    0x28(%r12),%r11
 29f3fac:	mov    0x20(%r12),%r10
 29f3fb1:	add    %rax,%r10
 29f3fb4:	xor    %rbx,%rbx
 29f3fb7:	cmp    %r11,%rax
 29f3fba:	cmova  %rbx,%r10
 29f3fbe:	mov    0x20(%r10),%r11
 29f3fc2:	mov    0x2c(%r10),%ebx
 29f3fc6:	mov    %r11,0x210(%rsp)
 29f3fce:	jmp    29f4002 <wasm[0]::function[1015]::helper::object_read+0x130e2>
 29f3fd3:	mov    0x2e0(%rsp),%r12
 29f3fdb:	mov    0x28(%r12),%r11
 29f3fe0:	mov    0x20(%r12),%r10
 29f3fe5:	add    %rax,%r10
 29f3fe8:	xor    %rbx,%rbx
 29f3feb:	cmp    %r11,%rax
 29f3fee:	cmova  %rbx,%r10
 29f3ff2:	mov    0x18(%r10),%r11
 29f3ff6:	mov    %r11,0x210(%rsp)
 29f3ffe:	mov    0x28(%r10),%ebx
 29f4002:	shl    $0x3,%ecx
 29f4005:	shr    %cl,%r13d
 29f4008:	and    $0xff,%r13d
 29f400f:	mov    %r13,0x218(%rsp)
 29f4017:	mov    0x198(%rsp),%rax
 29f401f:	mov    %eax,0x98(%rsp)
 29f4026:	mov    %r9d,0x78(%rsp)
 29f402b:	mov    %edx,0xd8(%rsp)
 29f4032:	mov    %esi,0xb0(%rsp)
 29f4039:	mov    %ebx,0xa8(%rsp)
 29f4040:	mov    %edi,0xc8(%rsp)
 29f4047:	mov    %r8d,0xb8(%rsp)
 29f404f:	mov    $0x286,%edx
 29f4054:	mov    0x190(%rsp),%rsi
 29f405c:	mov    0x190(%rsp),%rdi
 29f4064:	call   2f307a0 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 29f4069:	mov    %eax,0xc0(%rsp)
 29f4070:	xor    %r15d,%r15d
 29f4073:	test   %eax,%eax
 29f4075:	je     29fc517 <wasm[0]::function[1015]::helper::object_read+0x1b5f7>
 29f407b:	movl   $0x0,0xd0(%rsp)
 29f4086:	mov    0x98(%rsp),%r10d
 29f408e:	mov    %r10,0x1a0(%rsp)
 29f4096:	mov    0x78(%rsp),%edx
 29f409a:	mov    %rdx,0x1c8(%rsp)
 29f40a2:	mov    0xd8(%rsp),%edx
 29f40a9:	mov    0xb0(%rsp),%esi
 29f40b0:	mov    0xa8(%rsp),%edi
 29f40b7:	mov    0xc8(%rsp),%r8d
 29f40bf:	mov    0xb8(%rsp),%r9d
 29f40c7:	xor    %r13,%r13
 29f40ca:	mov    0x250(%rsp),%rcx
 29f40d2:	mov    0x250(%rsp),%r11
 29f40da:	test   %r11b,%cl
 29f40dd:	jne    29f4103 <wasm[0]::function[1015]::helper::object_read+0x131e3>
 29f40e3:	mov    0x1a0(%rsp),%r10
 29f40eb:	mov    %r15,%r14
 29f40ee:	mov    %r15,0x1e0(%rsp)
 29f40f6:	mov    %r13,0x1e8(%rsp)
 29f40fe:	jmp    29f4d5e <wasm[0]::function[1015]::helper::object_read+0x13e3e>
 29f4103:	mov    0x98(%rsp),%r8d
 29f410b:	mov    0x260(%rsp),%rcx
 29f4113:	mov    0x258(%rsp),%rdx
 29f411b:	mov    0x190(%rsp),%rsi
 29f4123:	mov    0x190(%rsp),%rdi
 29f412b:	call   2a5f620 <wasm[0]::function[1039]::helper::object_header_projection>
 29f4130:	mov    %eax,0x88(%rsp)
 29f4137:	test   %eax,%eax
 29f4139:	je     29fc519 <wasm[0]::function[1015]::helper::object_read+0x1b5f9>
 29f413f:	test   %eax,%eax
 29f4141:	je     29fc51b <wasm[0]::function[1015]::helper::object_read+0x1b5fb>
 29f4147:	mov    0x2e0(%rsp),%r12
 29f414f:	mov    0x28(%r12),%rcx
 29f4154:	mov    0x20(%r12),%rsi
 29f4159:	mov    %eax,%edx
 29f415b:	lea    (%rsi,%rdx,1),%rax
 29f415f:	xor    %rsi,%rsi
 29f4162:	cmp    %rcx,%rdx
 29f4165:	cmova  %rsi,%rax
 29f4169:	mov    0x14(%rax),%eax
 29f416c:	mov    %eax,0xe8(%rsp)
 29f4173:	test   %eax,%eax
 29f4175:	je     29fc51d <wasm[0]::function[1015]::helper::object_read+0x1b5fd>
 29f417b:	mov    0xe8(%rsp),%ecx
 29f4182:	xor    %eax,%eax
 29f4184:	test   $0x1,%ecx
 29f418a:	jne    29f41e4 <wasm[0]::function[1015]::helper::object_read+0x132c4>
 29f4190:	mov    0x2e0(%rsp),%r12
 29f4198:	mov    0x28(%r12),%rax
 29f419d:	mov    0x20(%r12),%rsi
 29f41a2:	mov    %ecx,%edx
 29f41a4:	lea    0x4(%rsi,%rdx,1),%rcx
 29f41a9:	xor    %rsi,%rsi
 29f41ac:	cmp    %rax,%rdx
 29f41af:	cmova  %rsi,%rcx
 29f41b3:	mov    (%rcx),%esi
 29f41b5:	mov    0x190(%rsp),%rax
 29f41bd:	mov    0x28(%rax),%rax
 29f41c1:	mov    0x158(%rax),%edx
 29f41c7:	cmp    %edx,%esi
 29f41c9:	sete   %al
 29f41cc:	movzbl %al,%eax
 29f41cf:	cmp    %edx,%esi
 29f41d1:	je     29f41e4 <wasm[0]::function[1015]::helper::object_read+0x132c4>
 29f41d7:	mov    0x190(%rsp),%rdi
 29f41df:	call   3018e75 <wasmtime_builtin_is_subtype>
 29f41e4:	test   %eax,%eax
 29f41e6:	jne    29f4450 <wasm[0]::function[1015]::helper::object_read+0x13530>
 29f41ec:	mov    0x88(%rsp),%edx
 29f41f3:	xor    %r12d,%r12d
 29f41f6:	test   %edx,%edx
 29f41f8:	je     29fc51f <wasm[0]::function[1015]::helper::object_read+0x1b5ff>
 29f41fe:	mov    0xc0(%rsp),%r9d
 29f4206:	mov    $0x4,%ecx
 29f420b:	xor    %r8,%r8
 29f420e:	mov    0x190(%rsp),%rsi
 29f4216:	mov    0x190(%rsp),%rdi
 29f421e:	call   2a58e20 <wasm[0]::function[1032]::helper::ordinary_property_find>
 29f4223:	test   %eax,%eax
 29f4225:	je     29f4260 <wasm[0]::function[1015]::helper::object_read+0x13340>
 29f422b:	test   %eax,%eax
 29f422d:	je     29fc521 <wasm[0]::function[1015]::helper::object_read+0x1b601>
 29f4233:	test   %eax,%eax
 29f4235:	je     29fc523 <wasm[0]::function[1015]::helper::object_read+0x1b603>
 29f423b:	mov    0x2e0(%rsp),%r12
 29f4243:	mov    0x28(%r12),%rcx
 29f4248:	mov    %eax,%edx
 29f424a:	mov    %rdx,%rax
 29f424d:	add    0x20(%r12),%rax
 29f4252:	xor    %rsi,%rsi
 29f4255:	cmp    %rcx,%rdx
 29f4258:	cmova  %rsi,%rax
 29f425c:	mov    0x14(%rax),%r12d
 29f4260:	mov    0xd0(%rsp),%r14d
 29f4268:	xor    %r15d,%r15d
 29f426b:	xor    %r13,%r13
 29f426e:	test   %r12d,%r12d
 29f4271:	je     29f43fa <wasm[0]::function[1015]::helper::object_read+0x134da>
 29f4277:	test   %r12d,%r12d
 29f427a:	je     29fc525 <wasm[0]::function[1015]::helper::object_read+0x1b605>
 29f4280:	mov    0x2e0(%rsp),%rax
 29f4288:	mov    0x28(%rax),%rcx
 29f428c:	mov    0x20(%rax),%rax
 29f4290:	mov    %r12d,%edx
 29f4293:	add    %rdx,%rax
 29f4296:	xor    %r13,%r13
 29f4299:	cmp    %rcx,%rdx
 29f429c:	cmova  %r13,%rax
 29f42a0:	mov    0x10(%rax),%ecx
 29f42a3:	mov    0xd0(%rsp),%r14d
 29f42ab:	xor    %r15d,%r15d
 29f42ae:	test   $0x1,%ecx
 29f42b4:	jne    29f43fa <wasm[0]::function[1015]::helper::object_read+0x134da>
 29f42ba:	mov    0x14(%rax),%edx
 29f42bd:	test   %edx,%edx
 29f42bf:	je     29fc527 <wasm[0]::function[1015]::helper::object_read+0x1b607>
 29f42c5:	xor    %esi,%esi
 29f42c7:	test   $0x1,%edx
 29f42cd:	jne    29f4311 <wasm[0]::function[1015]::helper::object_read+0x133f1>
 29f42d3:	mov    0x2e0(%rsp),%r12
 29f42db:	mov    0x28(%r12),%rax
 29f42e0:	mov    0x20(%r12),%rcx
 29f42e5:	mov    %edx,%esi
 29f42e7:	lea    0x4(%rcx,%rsi,1),%rcx
 29f42ec:	xor    %rdi,%rdi
 29f42ef:	cmp    %rax,%rsi
 29f42f2:	cmova  %rdi,%rcx
 29f42f6:	mov    (%rcx),%eax
 29f42f8:	mov    0x190(%rsp),%rsi
 29f4300:	mov    0x28(%rsi),%rcx
 29f4304:	cmp    0x120(%rcx),%eax
 29f430a:	sete   %al
 29f430d:	rex movzbl %al,%esi
 29f4311:	test   %esi,%esi
 29f4313:	jne    29f4371 <wasm[0]::function[1015]::helper::object_read+0x13451>
 29f4319:	mov    0x190(%rsp),%rsi
 29f4321:	mov    0x190(%rsp),%rdi
 29f4329:	call   2a01ba0 <wasm[0]::function[1024]::helper::property_value_resolve>
 29f432e:	test   %eax,%eax
 29f4330:	je     29fc529 <wasm[0]::function[1015]::helper::object_read+0x1b609>
 29f4336:	test   %eax,%eax
 29f4338:	je     29fc52b <wasm[0]::function[1015]::helper::object_read+0x1b60b>
 29f433e:	mov    0x2e0(%rsp),%r12
 29f4346:	mov    0x28(%r12),%rdi
 29f434b:	mov    0x20(%r12),%rsi
 29f4350:	mov    %eax,%r8d
 29f4353:	add    %r8,%rsi
 29f4356:	xor    %r9,%r9
 29f4359:	cmp    %rdi,%r8
 29f435c:	cmova  %r9,%rsi
 29f4360:	mov    0x18(%rsi),%r15d
 29f4364:	mov    0x10(%rsi),%r13
 29f4368:	mov    0x1c(%rsi),%r14d
 29f436c:	jmp    29f43fa <wasm[0]::function[1015]::helper::object_read+0x134da>
 29f4371:	xor    %eax,%eax
 29f4373:	test   $0x1,%edx
 29f4379:	jne    29f43bd <wasm[0]::function[1015]::helper::object_read+0x1349d>
 29f437f:	mov    0x2e0(%rsp),%r12
 29f4387:	mov    0x28(%r12),%rax
 29f438c:	mov    0x20(%r12),%rsi
 29f4391:	mov    %edx,%ecx
 29f4393:	lea    0x4(%rsi,%rcx,1),%r9
 29f4398:	xor    %rsi,%rsi
 29f439b:	cmp    %rax,%rcx
 29f439e:	cmova  %rsi,%r9
 29f43a2:	mov    (%r9),%eax
 29f43a5:	mov    0x190(%rsp),%rsi
 29f43ad:	mov    0x28(%rsi),%rcx
 29f43b1:	cmp    0x120(%rcx),%eax
 29f43b7:	sete   %al
 29f43ba:	movzbl %al,%eax
 29f43bd:	test   %eax,%eax
 29f43bf:	je     29fc52d <wasm[0]::function[1015]::helper::object_read+0x1b60d>
 29f43c5:	test   %edx,%edx
 29f43c7:	je     29fc52f <wasm[0]::function[1015]::helper::object_read+0x1b60f>
 29f43cd:	mov    0x2e0(%rsp),%r12
 29f43d5:	mov    0x28(%r12),%rcx
 29f43da:	mov    0x20(%r12),%rax
 29f43df:	mov    %edx,%edx
 29f43e1:	add    %rdx,%rax
 29f43e4:	xor    %rsi,%rsi
 29f43e7:	cmp    %rcx,%rdx
 29f43ea:	cmova  %rsi,%rax
 29f43ee:	mov    0x18(%rax),%r15d
 29f43f2:	mov    0x10(%rax),%r13
 29f43f6:	mov    0x1c(%rax),%r14d
 29f43fa:	mov    0x98(%rsp),%r10d
 29f4402:	mov    %r10,0x1a0(%rsp)
 29f440a:	mov    0x78(%rsp),%edx
 29f440e:	mov    %rdx,0x1c8(%rsp)
 29f4416:	mov    0xd8(%rsp),%edx
 29f441d:	mov    0xb0(%rsp),%esi
 29f4424:	mov    0xa8(%rsp),%edi
 29f442b:	mov    0xc8(%rsp),%r8d
 29f4433:	mov    0xb8(%rsp),%r9d
 29f443b:	mov    %r15,0x1e0(%rsp)
 29f4443:	mov    %r13,0x1e8(%rsp)
 29f444b:	jmp    29f4d56 <wasm[0]::function[1015]::helper::object_read+0x13e36>
 29f4450:	mov    0xe8(%rsp),%eax
 29f4457:	test   %eax,%eax
 29f4459:	je     29fc531 <wasm[0]::function[1015]::helper::object_read+0x1b611>
 29f445f:	mov    0xe8(%rsp),%ecx
 29f4466:	xor    %eax,%eax
 29f4468:	test   $0x1,%ecx
 29f446e:	jne    29f44c8 <wasm[0]::function[1015]::helper::object_read+0x135a8>
 29f4474:	mov    0x2e0(%rsp),%r12
 29f447c:	mov    0x28(%r12),%rax
 29f4481:	mov    0x20(%r12),%rsi
 29f4486:	mov    %ecx,%edx
 29f4488:	lea    0x4(%rsi,%rdx,1),%rcx
 29f448d:	xor    %rsi,%rsi
 29f4490:	cmp    %rax,%rdx
 29f4493:	cmova  %rsi,%rcx
 29f4497:	mov    (%rcx),%esi
 29f4499:	mov    0x190(%rsp),%r10
 29f44a1:	mov    0x28(%r10),%rax
 29f44a5:	mov    0x158(%rax),%edx
 29f44ab:	cmp    %edx,%esi
 29f44ad:	sete   %al
 29f44b0:	movzbl %al,%eax
 29f44b3:	cmp    %edx,%esi
 29f44b5:	je     29f44c8 <wasm[0]::function[1015]::helper::object_read+0x135a8>
 29f44bb:	mov    0x190(%rsp),%rdi
 29f44c3:	call   3018e75 <wasmtime_builtin_is_subtype>
 29f44c8:	test   %eax,%eax
 29f44ca:	je     29fc533 <wasm[0]::function[1015]::helper::object_read+0x1b613>
 29f44d0:	mov    0xe8(%rsp),%r11d
 29f44d8:	mov    0x98(%rsp),%r10d
 29f44e0:	mov    %r10,0x1a0(%rsp)
 29f44e8:	mov    0x78(%rsp),%edx
 29f44ec:	mov    %rdx,0x1c8(%rsp)
 29f44f4:	mov    0xd0(%rsp),%r14d
 29f44fc:	mov    0xd8(%rsp),%edx
 29f4503:	mov    0xb0(%rsp),%esi
 29f450a:	mov    0xa8(%rsp),%edi
 29f4511:	mov    0xc8(%rsp),%r8d
 29f4519:	mov    0xb8(%rsp),%r9d
 29f4521:	xor    %ecx,%ecx
 29f4523:	mov    %rcx,0x240(%rsp)
 29f452b:	test   %r11d,%r11d
 29f452e:	je     29fc535 <wasm[0]::function[1015]::helper::object_read+0x1b615>
 29f4534:	test   %r11d,%r11d
 29f4537:	je     29fc537 <wasm[0]::function[1015]::helper::object_read+0x1b617>
 29f453d:	mov    0x2e0(%rsp),%r12
 29f4545:	mov    0x28(%r12),%rax
 29f454a:	mov    0x20(%r12),%rcx
 29f454f:	mov    %r11d,%r12d
 29f4552:	lea    (%rcx,%r12,1),%rbx
 29f4556:	xor    %r13,%r13
 29f4559:	cmp    %rax,%r12
 29f455c:	cmova  %r13,%rbx
 29f4560:	mov    0x10(%rbx),%ebx
 29f4563:	test   %ebx,%ebx
 29f4565:	je     29fc539 <wasm[0]::function[1015]::helper::object_read+0x1b619>
 29f456b:	test   %ebx,%ebx
 29f456d:	je     29fc53b <wasm[0]::function[1015]::helper::object_read+0x1b61b>
 29f4573:	mov    %ebx,%r12d
 29f4576:	lea    (%rcx,%r12,1),%rbx
 29f457a:	cmp    %rax,%r12
 29f457d:	cmova  %r13,%rbx
 29f4581:	mov    0x10(%rbx),%r12d
 29f4585:	test   %r12d,%r12d
 29f4588:	je     29fc53d <wasm[0]::function[1015]::helper::object_read+0x1b61d>
 29f458e:	test   %r12d,%r12d
 29f4591:	je     29fc53f <wasm[0]::function[1015]::helper::object_read+0x1b61f>
 29f4597:	mov    %r12d,%ebx
 29f459a:	lea    0x10(%rcx,%rbx,1),%rcx
 29f459f:	cmp    %rax,%rbx
 29f45a2:	cmova  %r13,%rcx
 29f45a6:	mov    (%rcx),%ebx
 29f45a8:	mov    0xc0(%rsp),%r15d
 29f45b0:	mov    0x190(%rsp),%r10
 29f45b8:	mov    0x28(%r10),%rax
 29f45bc:	mov    0x234(%rax),%r13d
 29f45c3:	mov    0x240(%rsp),%rax
 29f45cb:	mov    %rax,0x198(%rsp)
 29f45d3:	mov    %r12d,0x88(%rsp)
 29f45db:	mov    %r15d,0xb8(%rsp)
 29f45e3:	mov    %r11d,0xc8(%rsp)
 29f45eb:	mov    0x1a0(%rsp),%r10
 29f45f3:	mov    %r10d,0xa8(%rsp)
 29f45fb:	mov    0x1c8(%rsp),%rax
 29f4603:	mov    %eax,0xb0(%rsp)
 29f460a:	mov    %r14d,0xd8(%rsp)
 29f4612:	mov    %edx,0xd0(%rsp)
 29f4619:	mov    %esi,0x78(%rsp)
 29f461d:	mov    %edi,0x98(%rsp)
 29f4624:	mov    %r8d,0xe8(%rsp)
 29f462c:	mov    %r9d,0xc0(%rsp)
 29f4634:	mov    0x2e8(%rsp),%rax
 29f463c:	mov    (%rax),%rsi
 29f463f:	mov    0x228(%rsp),%rax
 29f4647:	cmp    %rax,%rsi
 29f464a:	jae    29fb486 <wasm[0]::function[1015]::helper::object_read+0x1a566>
 29f4650:	mov    0xc8(%rsp),%r11d
 29f4658:	mov    0xa8(%rsp),%r10d
 29f4660:	mov    %r10,0x1a0(%rsp)
 29f4668:	mov    0xb0(%rsp),%edx
 29f466f:	mov    %rdx,0x1c8(%rsp)
 29f4677:	mov    0xd8(%rsp),%r14d
 29f467f:	mov    0xd0(%rsp),%edx
 29f4686:	mov    0x78(%rsp),%esi
 29f468a:	mov    0x98(%rsp),%edi
 29f4691:	mov    0xe8(%rsp),%r8d
 29f4699:	mov    0xc0(%rsp),%r9d
 29f46a1:	mov    0x240(%rsp),%rcx
 29f46a9:	cmp    %ebx,%ecx
 29f46ab:	jb     29f46be <wasm[0]::function[1015]::helper::object_read+0x1379e>
 29f46b1:	mov    0x198(%rsp),%rax
 29f46b9:	jmp    29f48dd <wasm[0]::function[1015]::helper::object_read+0x139bd>
 29f46be:	mov    0x88(%rsp),%eax
 29f46c5:	test   %eax,%eax
 29f46c7:	je     29fc541 <wasm[0]::function[1015]::helper::object_read+0x1b621>
 29f46cd:	test   %eax,%eax
 29f46cf:	je     29fc543 <wasm[0]::function[1015]::helper::object_read+0x1b623>
 29f46d5:	mov    0x2e0(%rsp),%r12
 29f46dd:	mov    0x28(%r12),%rdx
 29f46e2:	mov    0x20(%r12),%rsi
 29f46e7:	mov    %eax,%r9d
 29f46ea:	lea    0x10(%rsi,%r9,1),%r8
 29f46ef:	xor    %rdi,%rdi
 29f46f2:	cmp    %rdx,%r9
 29f46f5:	cmova  %rdi,%r8
 29f46f9:	mov    (%r8),%r8d
 29f46fc:	cmp    %r8d,%ecx
 29f46ff:	jae    29fc545 <wasm[0]::function[1015]::helper::object_read+0x1b625>
 29f4705:	mov    %r8d,%r9d
 29f4708:	shl    $0x2,%r9
 29f470c:	shr    $0x20,%r9
 29f4710:	test   %r9,%r9
 29f4713:	jne    29fc547 <wasm[0]::function[1015]::helper::object_read+0x1b627>
 29f4719:	shl    $0x2,%r8d
 29f471d:	add    $0x14,%r8d
 29f4721:	jb     29fc549 <wasm[0]::function[1015]::helper::object_read+0x1b629>
 29f4727:	add    %r8d,%eax
 29f472a:	jb     29fc54b <wasm[0]::function[1015]::helper::object_read+0x1b62b>
 29f4730:	mov    %eax,%r9d
 29f4733:	lea    (%rsi,%r9,1),%rax
 29f4737:	cmp    %rdx,%r9
 29f473a:	cmova  %rdi,%rax
 29f473e:	mov    %rcx,%rdx
 29f4741:	shl    $0x2,%edx
 29f4744:	mov    %rcx,0x240(%rsp)
 29f474c:	lea    0x14(%rdx),%ecx
 29f474f:	sub    %ecx,%r8d
 29f4752:	sub    %r8,%rax
 29f4755:	mov    (%rax),%edx
 29f4757:	test   %edx,%edx
 29f4759:	je     29fc54d <wasm[0]::function[1015]::helper::object_read+0x1b62d>
 29f475f:	mov    0xb8(%rsp),%eax
 29f4766:	cmp    %eax,%edx
 29f4768:	je     29f483c <wasm[0]::function[1015]::helper::object_read+0x1391c>
 29f476e:	xor    %ecx,%ecx
 29f4770:	test   %edx,%edx
 29f4772:	je     29f47b4 <wasm[0]::function[1015]::helper::object_read+0x13894>
 29f4778:	xor    %ecx,%ecx
 29f477a:	test   $0x1,%edx
 29f4780:	jne    29f47b4 <wasm[0]::function[1015]::helper::object_read+0x13894>
 29f4786:	mov    0x2e0(%rsp),%r12
 29f478e:	mov    0x28(%r12),%rcx
 29f4793:	mov    0x20(%r12),%rsi
 29f4798:	mov    %edx,%edi
 29f479a:	lea    0x4(%rsi,%rdi,1),%rsi
 29f479f:	xor    %r8,%r8
 29f47a2:	cmp    %rcx,%rdi
 29f47a5:	cmova  %r8,%rsi
 29f47a9:	mov    (%rsi),%ecx
 29f47ab:	cmp    %r13d,%ecx
 29f47ae:	sete   %cl
 29f47b1:	movzbl %cl,%ecx
 29f47b4:	test   %ecx,%ecx
 29f47b6:	je     29fc54f <wasm[0]::function[1015]::helper::object_read+0x1b62f>
 29f47bc:	xor    %ecx,%ecx
 29f47be:	test   %eax,%eax
 29f47c0:	je     29f4808 <wasm[0]::function[1015]::helper::object_read+0x138e8>
 29f47c6:	mov    0xb8(%rsp),%eax
 29f47cd:	xor    %ecx,%ecx
 29f47cf:	test   $0x1,%eax
 29f47d4:	jne    29f4808 <wasm[0]::function[1015]::helper::object_read+0x138e8>
 29f47da:	mov    0x2e0(%rsp),%r12
 29f47e2:	mov    0x28(%r12),%rcx
 29f47e7:	mov    0x20(%r12),%rdi
 29f47ec:	mov    %eax,%esi
 29f47ee:	lea    0x4(%rdi,%rsi,1),%rax
 29f47f3:	xor    %rdi,%rdi
 29f47f6:	cmp    %rcx,%rsi
 29f47f9:	cmova  %rdi,%rax
 29f47fd:	mov    (%rax),%eax
 29f47ff:	cmp    %r13d,%eax
 29f4802:	sete   %al
 29f4805:	movzbl %al,%ecx
 29f4808:	test   %ecx,%ecx
 29f480a:	je     29fc551 <wasm[0]::function[1015]::helper::object_read+0x1b631>
 29f4810:	mov    0xb8(%rsp),%ecx
 29f4817:	xor    %r8d,%r8d
 29f481a:	test   %ecx,%ecx
 29f481c:	je     29fc553 <wasm[0]::function[1015]::helper::object_read+0x1b633>
 29f4822:	mov    0x190(%rsp),%rsi
 29f482a:	mov    0x190(%rsp),%rdi
 29f4832:	call   2ae54e0 <wasm[0]::function[1057]::helper::string_equality>
 29f4837:	jmp    29f4844 <wasm[0]::function[1015]::helper::object_read+0x13924>
 29f483c:	mov    0x278(%rsp),%rax
 29f4844:	mov    0x88(%rsp),%r12d
 29f484c:	mov    0xb8(%rsp),%r15d
 29f4854:	mov    0xc8(%rsp),%r11d
 29f485c:	mov    0xa8(%rsp),%r10d
 29f4864:	mov    %r10,0x1a0(%rsp)
 29f486c:	mov    0xb0(%rsp),%edx
 29f4873:	mov    %rdx,0x1c8(%rsp)
 29f487b:	mov    0xd8(%rsp),%r14d
 29f4883:	mov    0xd0(%rsp),%edx
 29f488a:	mov    0x78(%rsp),%esi
 29f488e:	mov    0x98(%rsp),%edi
 29f4895:	mov    0xe8(%rsp),%r8d
 29f489d:	mov    0xc0(%rsp),%r9d
 29f48a5:	test   %eax,%eax
 29f48a7:	je     29f48ba <wasm[0]::function[1015]::helper::object_read+0x1399a>
 29f48ad:	mov    0x240(%rsp),%rcx
 29f48b5:	jmp    29f48dd <wasm[0]::function[1015]::helper::object_read+0x139bd>
 29f48ba:	mov    0x240(%rsp),%rcx
 29f48c2:	add    $0x1,%ecx
 29f48c8:	mov    %rax,0x198(%rsp)
 29f48d0:	mov    %rcx,0x240(%rsp)
 29f48d8:	jmp    29f45d3 <wasm[0]::function[1015]::helper::object_read+0x136b3>
 29f48dd:	xor    %r15d,%r15d
 29f48e0:	xor    %r13,%r13
 29f48e3:	test   %eax,%eax
 29f48e5:	jne    29f4900 <wasm[0]::function[1015]::helper::object_read+0x139e0>
 29f48eb:	mov    %r15,0x1e0(%rsp)
 29f48f3:	mov    %r13,0x1e8(%rsp)
 29f48fb:	jmp    29f4d56 <wasm[0]::function[1015]::helper::object_read+0x13e36>
 29f4900:	test   %r11d,%r11d
 29f4903:	je     29fc555 <wasm[0]::function[1015]::helper::object_read+0x1b635>
 29f4909:	xor    %eax,%eax
 29f490b:	test   $0x1,%r11d
 29f4912:	jne    29f4959 <wasm[0]::function[1015]::helper::object_read+0x13a39>
 29f4918:	mov    0x2e0(%rsp),%r12
 29f4920:	mov    0x28(%r12),%rax
 29f4925:	mov    0x20(%r12),%r14
 29f492a:	mov    %r11d,%r13d
 29f492d:	lea    0x4(%r14,%r13,1),%r12
 29f4932:	xor    %r14,%r14
 29f4935:	cmp    %rax,%r13
 29f4938:	cmova  %r14,%r12
 29f493c:	mov    (%r12),%eax
 29f4940:	mov    0x190(%rsp),%r10
 29f4948:	mov    0x28(%r10),%r10
 29f494c:	cmp    0x160(%r10),%eax
 29f4953:	sete   %al
 29f4956:	movzbl %al,%eax
 29f4959:	test   %eax,%eax
 29f495b:	jne    29f4bc8 <wasm[0]::function[1015]::helper::object_read+0x13ca8>
 29f4961:	xor    %eax,%eax
 29f4963:	test   $0x1,%r11d
 29f496a:	jne    29f49af <wasm[0]::function[1015]::helper::object_read+0x13a8f>
 29f4970:	mov    0x2e0(%rsp),%r12
 29f4978:	mov    0x28(%r12),%rax
 29f497d:	mov    0x20(%r12),%rbx
 29f4982:	mov    %r11d,%r12d
 29f4985:	lea    0x4(%rbx,%r12,1),%rbx
 29f498a:	xor    %r13,%r13
 29f498d:	cmp    %rax,%r12
 29f4990:	cmova  %r13,%rbx
 29f4994:	mov    (%rbx),%eax
 29f4996:	mov    0x190(%rsp),%r10
 29f499e:	mov    0x28(%r10),%r10
 29f49a2:	cmp    0x15c(%r10),%eax
 29f49a9:	sete   %al
 29f49ac:	movzbl %al,%eax
 29f49af:	test   %eax,%eax
 29f49b1:	je     29fc557 <wasm[0]::function[1015]::helper::object_read+0x1b637>
 29f49b7:	test   %r11d,%r11d
 29f49ba:	je     29fc559 <wasm[0]::function[1015]::helper::object_read+0x1b639>
 29f49c0:	mov    0x2e0(%rsp),%r12
 29f49c8:	mov    0x28(%r12),%rax
 29f49cd:	mov    0x20(%r12),%r12
 29f49d2:	mov    %r11d,%ebx
 29f49d5:	lea    (%r12,%rbx,1),%r11
 29f49d9:	xor    %r13,%r13
 29f49dc:	cmp    %rax,%rbx
 29f49df:	cmova  %r13,%r11
 29f49e3:	mov    0x14(%r11),%r15d
 29f49e7:	mov    0x18(%r11),%r14d
 29f49eb:	mov    0x1c(%r11),%r11d
 29f49ef:	test   %r15d,%r15d
 29f49f2:	je     29fc55b <wasm[0]::function[1015]::helper::object_read+0x1b63b>
 29f49f8:	test   %r15d,%r15d
 29f49fb:	je     29fc55d <wasm[0]::function[1015]::helper::object_read+0x1b63d>
 29f4a01:	mov    %r15d,%r10d
 29f4a04:	lea    0x10(%r12,%r10,1),%rbx
 29f4a09:	cmp    %rax,%r10
 29f4a0c:	cmova  %r13,%rbx
 29f4a10:	mov    (%rbx),%ebx
 29f4a12:	cmp    %ebx,%ecx
 29f4a14:	jae    29fc55f <wasm[0]::function[1015]::helper::object_read+0x1b63f>
 29f4a1a:	mov    %ebx,%r10d
 29f4a1d:	shr    $0x20,%r10
 29f4a21:	test   %r10,%r10
 29f4a24:	jne    29fc561 <wasm[0]::function[1015]::helper::object_read+0x1b641>
 29f4a2a:	add    $0x14,%ebx
 29f4a2d:	jb     29fc563 <wasm[0]::function[1015]::helper::object_read+0x1b643>
 29f4a33:	add    %ebx,%r15d
 29f4a36:	jb     29fc565 <wasm[0]::function[1015]::helper::object_read+0x1b645>
 29f4a3c:	mov    %r15d,%r10d
 29f4a3f:	add    %r10,%r12
 29f4a42:	cmp    %rax,%r10
 29f4a45:	cmova  %r13,%r12
 29f4a49:	lea    0x14(%rcx),%eax
 29f4a4c:	sub    %eax,%ebx
 29f4a4e:	sub    %rbx,%r12
 29f4a51:	movzbq (%r12),%rbx
 29f4a56:	mov    %rbx,0x248(%rsp)
 29f4a5e:	test   %r14d,%r14d
 29f4a61:	je     29f4afc <wasm[0]::function[1015]::helper::object_read+0x13bdc>
 29f4a67:	test   %r14d,%r14d
 29f4a6a:	je     29fc567 <wasm[0]::function[1015]::helper::object_read+0x1b647>
 29f4a70:	test   %r14d,%r14d
 29f4a73:	je     29fc569 <wasm[0]::function[1015]::helper::object_read+0x1b649>
 29f4a79:	mov    0x2e0(%rsp),%r12
 29f4a81:	mov    0x28(%r12),%r12
 29f4a86:	mov    0x2e0(%rsp),%rax
 29f4a8e:	mov    0x20(%rax),%r13
 29f4a92:	mov    %r14d,%ebx
 29f4a95:	lea    0x10(%r13,%rbx,1),%rax
 29f4a9a:	xor    %r15,%r15
 29f4a9d:	cmp    %r12,%rbx
 29f4aa0:	cmova  %r15,%rax
 29f4aa4:	mov    (%rax),%eax
 29f4aa6:	cmp    %eax,%ecx
 29f4aa8:	jae    29fc56b <wasm[0]::function[1015]::helper::object_read+0x1b64b>
 29f4aae:	mov    %eax,%ebx
 29f4ab0:	shl    $0x3,%rbx
 29f4ab4:	shr    $0x20,%rbx
 29f4ab8:	test   %rbx,%rbx
 29f4abb:	jne    29fc56d <wasm[0]::function[1015]::helper::object_read+0x1b64d>
 29f4ac1:	shl    $0x3,%eax
 29f4ac4:	add    $0x18,%eax
 29f4ac7:	jb     29fc56f <wasm[0]::function[1015]::helper::object_read+0x1b64f>
 29f4acd:	add    %eax,%r14d
 29f4ad0:	jb     29fc571 <wasm[0]::function[1015]::helper::object_read+0x1b651>
 29f4ad6:	mov    %r14d,%r10d
 29f4ad9:	lea    0x0(%r13,%r10,1),%rbx
 29f4ade:	cmp    %r12,%r10
 29f4ae1:	cmova  %r15,%rbx
 29f4ae5:	mov    %rcx,%r10
 29f4ae8:	shl    $0x3,%r10d
 29f4aec:	add    $0x18,%r10d
 29f4af3:	sub    %r10d,%eax
 29f4af6:	sub    %rax,%rbx
 29f4af9:	mov    (%rbx),%r13
 29f4afc:	xor    %r14d,%r14d
 29f4aff:	test   %r11d,%r11d
 29f4b02:	jne    29f4b15 <wasm[0]::function[1015]::helper::object_read+0x13bf5>
 29f4b08:	mov    0x248(%rsp),%rbx
 29f4b10:	jmp    29f4baf <wasm[0]::function[1015]::helper::object_read+0x13c8f>
 29f4b15:	test   %r11d,%r11d
 29f4b18:	je     29fc573 <wasm[0]::function[1015]::helper::object_read+0x1b653>
 29f4b1e:	test   %r11d,%r11d
 29f4b21:	je     29fc575 <wasm[0]::function[1015]::helper::object_read+0x1b655>
 29f4b27:	mov    0x2e0(%rsp),%r12
 29f4b2f:	mov    0x28(%r12),%r12
 29f4b34:	mov    0x2e0(%rsp),%rax
 29f4b3c:	mov    0x20(%rax),%rax
 29f4b40:	mov    %r11d,%r15d
 29f4b43:	lea    0x10(%rax,%r15,1),%rbx
 29f4b48:	xor    %r14,%r14
 29f4b4b:	cmp    %r12,%r15
 29f4b4e:	cmova  %r14,%rbx
 29f4b52:	mov    (%rbx),%r15d
 29f4b55:	cmp    %r15d,%ecx
 29f4b58:	jae    29fc577 <wasm[0]::function[1015]::helper::object_read+0x1b657>
 29f4b5e:	mov    %r15d,%ebx
 29f4b61:	shl    $0x2,%rbx
 29f4b65:	shr    $0x20,%rbx
 29f4b69:	test   %rbx,%rbx
 29f4b6c:	jne    29fc579 <wasm[0]::function[1015]::helper::object_read+0x1b659>
 29f4b72:	shl    $0x2,%r15d
 29f4b76:	add    $0x14,%r15d
 29f4b7a:	jb     29fc57b <wasm[0]::function[1015]::helper::object_read+0x1b65b>
 29f4b80:	add    %r15d,%r11d
 29f4b83:	jb     29fc57d <wasm[0]::function[1015]::helper::object_read+0x1b65d>
 29f4b89:	mov    %r11d,%r10d
 29f4b8c:	lea    (%rax,%r10,1),%r11
 29f4b90:	cmp    %r12,%r10
 29f4b93:	cmova  %r14,%r11
 29f4b97:	shl    $0x2,%ecx
 29f4b9a:	lea    0x14(%rcx),%r10d
 29f4b9e:	sub    %r10d,%r15d
 29f4ba1:	sub    %r15,%r11
 29f4ba4:	mov    (%r11),%r14d
 29f4ba7:	mov    0x248(%rsp),%rbx
 29f4baf:	movzbl %bl,%r15d
 29f4bb3:	mov    %r15,0x1e0(%rsp)
 29f4bbb:	mov    %r13,0x1e8(%rsp)
 29f4bc3:	jmp    29f4d56 <wasm[0]::function[1015]::helper::object_read+0x13e36>
 29f4bc8:	xor    %eax,%eax
 29f4bca:	test   $0x1,%r11d
 29f4bd1:	jne    29f4c18 <wasm[0]::function[1015]::helper::object_read+0x13cf8>
 29f4bd7:	mov    0x2e0(%rsp),%r12
 29f4bdf:	mov    0x28(%r12),%rax
 29f4be4:	mov    0x20(%r12),%r10
 29f4be9:	mov    %r11d,%ebx
 29f4bec:	lea    0x4(%r10,%rbx,1),%r13
 29f4bf1:	xor    %r12,%r12
 29f4bf4:	cmp    %rax,%rbx
 29f4bf7:	cmova  %r12,%r13
 29f4bfb:	mov    0x0(%r13),%eax
 29f4bff:	mov    0x190(%rsp),%r10
 29f4c07:	mov    0x28(%r10),%r10
 29f4c0b:	cmp    0x160(%r10),%eax
 29f4c12:	sete   %al
 29f4c15:	movzbl %al,%eax
 29f4c18:	test   %eax,%eax
 29f4c1a:	je     29fc57f <wasm[0]::function[1015]::helper::object_read+0x1b65f>
 29f4c20:	test   %r11d,%r11d
 29f4c23:	je     29fc581 <wasm[0]::function[1015]::helper::object_read+0x1b661>
 29f4c29:	mov    0x2e0(%rsp),%r12
 29f4c31:	mov    0x28(%r12),%r12
 29f4c36:	mov    0x2e0(%rsp),%rax
 29f4c3e:	mov    0x20(%rax),%r13
 29f4c42:	mov    %r11d,%eax
 29f4c45:	lea    0x0(%r13,%rax,1),%rbx
 29f4c4a:	xor    %r11,%r11
 29f4c4d:	cmp    %r12,%rax
 29f4c50:	cmova  %r11,%rbx
 29f4c54:	mov    0x10(%rbx),%ebx
 29f4c57:	test   %ebx,%ebx
 29f4c59:	je     29fc583 <wasm[0]::function[1015]::helper::object_read+0x1b663>
 29f4c5f:	test   %ebx,%ebx
 29f4c61:	je     29fc585 <wasm[0]::function[1015]::helper::object_read+0x1b665>
 29f4c67:	mov    %ebx,%r10d
 29f4c6a:	lea    0x0(%r13,%r10,1),%rbx
 29f4c6f:	cmp    %r12,%r10
 29f4c72:	cmova  %r11,%rbx
 29f4c76:	mov    0x10(%rbx),%ebx
 29f4c79:	test   %ebx,%ebx
 29f4c7b:	je     29fc587 <wasm[0]::function[1015]::helper::object_read+0x1b667>
 29f4c81:	test   %ebx,%ebx
 29f4c83:	je     29fc589 <wasm[0]::function[1015]::helper::object_read+0x1b669>
 29f4c89:	mov    %ebx,%r10d
 29f4c8c:	lea    0x10(%r13,%r10,1),%rbx
 29f4c91:	cmp    %r12,%r10
 29f4c94:	cmova  %r11,%rbx
 29f4c98:	cmp    (%rbx),%ecx
 29f4c9a:	setae  %r11b
 29f4c9e:	cmp    $0x2,%ecx
 29f4ca1:	setae  %r10b
 29f4ca5:	or     %r10d,%r11d
 29f4ca8:	test   %r11b,%r11b
 29f4cab:	jne    29fc58b <wasm[0]::function[1015]::helper::object_read+0x1b66b>
 29f4cb1:	mov    0x2e0(%rsp),%r12
 29f4cb9:	mov    0x28(%r12),%rbx
 29f4cbe:	mov    %rax,%r11
 29f4cc1:	add    0x20(%r12),%r11
 29f4cc6:	xor    %r12,%r12
 29f4cc9:	cmp    %rbx,%rax
 29f4ccc:	cmova  %r12,%r11
 29f4cd0:	mov    0x14(%r11),%r15d
 29f4cd4:	test   %ecx,%ecx
 29f4cd6:	je     29f4d11 <wasm[0]::function[1015]::helper::object_read+0x13df1>
 29f4cdc:	mov    0x2e0(%rsp),%r12
 29f4ce4:	mov    0x28(%r12),%rbx
 29f4ce9:	mov    0x20(%r12),%r10
 29f4cee:	lea    (%r10,%rax,1),%r11
 29f4cf2:	xor    %r12,%r12
 29f4cf5:	cmp    %rbx,%rax
 29f4cf8:	cmova  %r12,%r11
 29f4cfc:	mov    0x20(%r11),%r13
 29f4d00:	mov    0x2c(%r11),%r14d
 29f4d04:	mov    %r13,0x1e8(%rsp)
 29f4d0c:	jmp    29f4d41 <wasm[0]::function[1015]::helper::object_read+0x13e21>
 29f4d11:	mov    0x2e0(%rsp),%r12
 29f4d19:	mov    0x28(%r12),%rbx
 29f4d1e:	mov    0x20(%r12),%r10
 29f4d23:	lea    (%r10,%rax,1),%r11
 29f4d27:	xor    %r12,%r12
 29f4d2a:	cmp    %rbx,%rax
 29f4d2d:	cmova  %r12,%r11
 29f4d31:	mov    0x18(%r11),%r13
 29f4d35:	mov    %r13,0x1e8(%rsp)
 29f4d3d:	mov    0x28(%r11),%r14d
 29f4d41:	shl    $0x3,%ecx
 29f4d44:	shr    %cl,%r15d
 29f4d47:	and    $0xff,%r15d
 29f4d4e:	mov    %r15,0x1e0(%rsp)
 29f4d56:	mov    0x1a0(%rsp),%r10
 29f4d5e:	mov    %r10d,0x78(%rsp)
 29f4d63:	mov    0x1c8(%rsp),%r10
 29f4d6b:	mov    %r10d,0xd0(%rsp)
 29f4d73:	mov    %r14d,0xd8(%rsp)
 29f4d7b:	mov    %edx,0xb0(%rsp)
 29f4d82:	mov    %esi,0xa8(%rsp)
 29f4d89:	mov    %edi,0xc8(%rsp)
 29f4d90:	mov    %r8d,0xb8(%rsp)
 29f4d98:	mov    %r9d,0x88(%rsp)
 29f4da0:	mov    $0x287,%edx
 29f4da5:	mov    0x190(%rsp),%rsi
 29f4dad:	mov    0x190(%rsp),%rdi
 29f4db5:	call   2f307a0 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 29f4dba:	mov    %eax,0x98(%rsp)
 29f4dc1:	xor    %edx,%edx
 29f4dc3:	test   %eax,%eax
 29f4dc5:	je     29fc58d <wasm[0]::function[1015]::helper::object_read+0x1b66d>
 29f4dcb:	movl   $0x0,0xe8(%rsp)
 29f4dd6:	mov    0xd0(%rsp),%edi
 29f4ddd:	mov    0xd8(%rsp),%r15d
 29f4de5:	mov    0xb0(%rsp),%r9d
 29f4ded:	mov    %r9,0x198(%rsp)
 29f4df5:	mov    0xa8(%rsp),%r10d
 29f4dfd:	mov    %r10,0x1a0(%rsp)
 29f4e05:	mov    0xc8(%rsp),%r10d
 29f4e0d:	mov    0xb8(%rsp),%r11d
 29f4e15:	mov    0x88(%rsp),%ebx
 29f4e1c:	xor    %r8,%r8
 29f4e1f:	mov    0x250(%rsp),%rax
 29f4e27:	mov    0x250(%rsp),%rcx
 29f4e2f:	test   %al,%cl
 29f4e31:	jne    29f4e47 <wasm[0]::function[1015]::helper::object_read+0x13f27>
 29f4e37:	mov    %rdx,%rsi
 29f4e3a:	mov    0x198(%rsp),%r9
 29f4e42:	jmp    29f5a86 <wasm[0]::function[1015]::helper::object_read+0x14b66>
 29f4e47:	mov    0x78(%rsp),%r8d
 29f4e4c:	mov    0x260(%rsp),%rcx
 29f4e54:	mov    0x258(%rsp),%rdx
 29f4e5c:	mov    0x190(%rsp),%rsi
 29f4e64:	mov    0x190(%rsp),%rdi
 29f4e6c:	call   2a5f620 <wasm[0]::function[1039]::helper::object_header_projection>
 29f4e71:	mov    %eax,0x78(%rsp)
 29f4e75:	test   %eax,%eax
 29f4e77:	je     29fc58f <wasm[0]::function[1015]::helper::object_read+0x1b66f>
 29f4e7d:	test   %eax,%eax
 29f4e7f:	je     29fc591 <wasm[0]::function[1015]::helper::object_read+0x1b671>
 29f4e85:	mov    0x2e0(%rsp),%r12
 29f4e8d:	mov    0x28(%r12),%rdi
 29f4e92:	mov    0x20(%r12),%r9
 29f4e97:	mov    %eax,%r8d
 29f4e9a:	lea    (%r9,%r8,1),%rsi
 29f4e9e:	xor    %r9,%r9
 29f4ea1:	cmp    %rdi,%r8
 29f4ea4:	cmova  %r9,%rsi
 29f4ea8:	mov    0x14(%rsi),%r8d
 29f4eac:	mov    %r8d,0xc0(%rsp)
 29f4eb4:	test   %r8d,%r8d
 29f4eb7:	je     29fc593 <wasm[0]::function[1015]::helper::object_read+0x1b673>
 29f4ebd:	mov    0xc0(%rsp),%ecx
 29f4ec4:	xor    %eax,%eax
 29f4ec6:	test   $0x1,%ecx
 29f4ecc:	jne    29f4f26 <wasm[0]::function[1015]::helper::object_read+0x14006>
 29f4ed2:	mov    0x2e0(%rsp),%r12
 29f4eda:	mov    0x28(%r12),%rax
 29f4edf:	mov    0x20(%r12),%rsi
 29f4ee4:	mov    %ecx,%edx
 29f4ee6:	lea    0x4(%rsi,%rdx,1),%rcx
 29f4eeb:	xor    %rsi,%rsi
 29f4eee:	cmp    %rax,%rdx
 29f4ef1:	cmova  %rsi,%rcx
 29f4ef5:	mov    (%rcx),%esi
 29f4ef7:	mov    0x190(%rsp),%rax
 29f4eff:	mov    0x28(%rax),%rax
 29f4f03:	mov    0x158(%rax),%edx
 29f4f09:	cmp    %edx,%esi
 29f4f0b:	sete   %al
 29f4f0e:	movzbl %al,%eax
 29f4f11:	cmp    %edx,%esi
 29f4f13:	je     29f4f26 <wasm[0]::function[1015]::helper::object_read+0x14006>
 29f4f19:	mov    0x190(%rsp),%rdi
 29f4f21:	call   3018e75 <wasmtime_builtin_is_subtype>
 29f4f26:	test   %eax,%eax
 29f4f28:	jne    29f517b <wasm[0]::function[1015]::helper::object_read+0x1425b>
 29f4f2e:	mov    0x78(%rsp),%edx
 29f4f32:	xor    %ebx,%ebx
 29f4f34:	test   %edx,%edx
 29f4f36:	je     29fc595 <wasm[0]::function[1015]::helper::object_read+0x1b675>
 29f4f3c:	mov    0x98(%rsp),%r9d
 29f4f44:	mov    $0x4,%ecx
 29f4f49:	xor    %r8,%r8
 29f4f4c:	mov    0x190(%rsp),%rsi
 29f4f54:	mov    0x190(%rsp),%rdi
 29f4f5c:	call   2a58e20 <wasm[0]::function[1032]::helper::ordinary_property_find>
 29f4f61:	test   %eax,%eax
 29f4f63:	je     29f4f9d <wasm[0]::function[1015]::helper::object_read+0x1407d>
 29f4f69:	test   %eax,%eax
 29f4f6b:	je     29fc597 <wasm[0]::function[1015]::helper::object_read+0x1b677>
 29f4f71:	test   %eax,%eax
 29f4f73:	je     29fc599 <wasm[0]::function[1015]::helper::object_read+0x1b679>
 29f4f79:	mov    0x2e0(%rsp),%r12
 29f4f81:	mov    0x28(%r12),%rcx
 29f4f86:	mov    %eax,%edx
 29f4f88:	mov    %rdx,%rax
 29f4f8b:	add    0x20(%r12),%rax
 29f4f90:	xor    %rsi,%rsi
 29f4f93:	cmp    %rcx,%rdx
 29f4f96:	cmova  %rsi,%rax
 29f4f9a:	mov    0x14(%rax),%ebx
 29f4f9d:	mov    0xe8(%rsp),%esi
 29f4fa4:	xor    %edx,%edx
 29f4fa6:	xor    %r8,%r8
 29f4fa9:	test   %ebx,%ebx
 29f4fab:	je     29f5130 <wasm[0]::function[1015]::helper::object_read+0x14210>
 29f4fb1:	test   %ebx,%ebx
 29f4fb3:	je     29fc59b <wasm[0]::function[1015]::helper::object_read+0x1b67b>
 29f4fb9:	mov    0x2e0(%rsp),%r12
 29f4fc1:	mov    0x28(%r12),%rcx
 29f4fc6:	mov    0x20(%r12),%rax
 29f4fcb:	mov    %ebx,%edx
 29f4fcd:	add    %rdx,%rax
 29f4fd0:	xor    %r8,%r8
 29f4fd3:	cmp    %rcx,%rdx
 29f4fd6:	cmova  %r8,%rax
 29f4fda:	mov    0x10(%rax),%ecx
 29f4fdd:	mov    0xe8(%rsp),%esi
 29f4fe4:	xor    %edx,%edx
 29f4fe6:	test   $0x1,%ecx
 29f4fec:	jne    29f5130 <wasm[0]::function[1015]::helper::object_read+0x14210>
 29f4ff2:	mov    0x14(%rax),%edx
 29f4ff5:	test   %edx,%edx
 29f4ff7:	je     29fc59d <wasm[0]::function[1015]::helper::object_read+0x1b67d>
 29f4ffd:	xor    %eax,%eax
 29f4fff:	test   $0x1,%edx
 29f5005:	jne    29f5048 <wasm[0]::function[1015]::helper::object_read+0x14128>
 29f500b:	mov    0x2e0(%rsp),%r12
 29f5013:	mov    0x28(%r12),%rax
 29f5018:	mov    0x20(%r12),%rcx
 29f501d:	mov    %edx,%esi
 29f501f:	lea    0x4(%rcx,%rsi,1),%rcx
 29f5024:	xor    %rdi,%rdi
 29f5027:	cmp    %rax,%rsi
 29f502a:	cmova  %rdi,%rcx
 29f502e:	mov    (%rcx),%eax
 29f5030:	mov    0x190(%rsp),%rsi
 29f5038:	mov    0x28(%rsi),%rcx
 29f503c:	cmp    0x120(%rcx),%eax
 29f5042:	sete   %al
 29f5045:	movzbl %al,%eax
 29f5048:	test   %eax,%eax
 29f504a:	jne    29f50a6 <wasm[0]::function[1015]::helper::object_read+0x14186>
 29f5050:	mov    0x190(%rsp),%rsi
 29f5058:	mov    0x190(%rsp),%rdi
 29f5060:	call   2a01ba0 <wasm[0]::function[1024]::helper::property_value_resolve>
 29f5065:	test   %eax,%eax
 29f5067:	je     29fc59f <wasm[0]::function[1015]::helper::object_read+0x1b67f>
 29f506d:	test   %eax,%eax
 29f506f:	je     29fc5a1 <wasm[0]::function[1015]::helper::object_read+0x1b681>
 29f5075:	mov    0x2e0(%rsp),%r12
 29f507d:	mov    0x28(%r12),%rcx
 29f5082:	mov    0x20(%r12),%rsi
 29f5087:	mov    %eax,%edx
 29f5089:	lea    (%rsi,%rdx,1),%rax
 29f508d:	xor    %rsi,%rsi
 29f5090:	cmp    %rcx,%rdx
 29f5093:	cmova  %rsi,%rax
 29f5097:	mov    0x18(%rax),%edx
 29f509a:	mov    0x10(%rax),%r8
 29f509e:	mov    0x1c(%rax),%esi
 29f50a1:	jmp    29f5130 <wasm[0]::function[1015]::helper::object_read+0x14210>
 29f50a6:	xor    %eax,%eax
 29f50a8:	test   $0x1,%edx
 29f50ae:	jne    29f50f3 <wasm[0]::function[1015]::helper::object_read+0x141d3>
 29f50b4:	mov    0x2e0(%rsp),%r12
 29f50bc:	mov    0x28(%r12),%rsi
 29f50c1:	mov    0x20(%r12),%r8
 29f50c6:	mov    %edx,%edi
 29f50c8:	lea    0x4(%r8,%rdi,1),%rax
 29f50cd:	xor    %r8,%r8
 29f50d0:	cmp    %rsi,%rdi
 29f50d3:	cmova  %r8,%rax
 29f50d7:	mov    (%rax),%esi
 29f50d9:	mov    0x190(%rsp),%rax
 29f50e1:	mov    0x28(%rax),%rdi
 29f50e5:	cmp    0x120(%rdi),%esi
 29f50eb:	sete   %sil
 29f50ef:	movzbl %sil,%eax
 29f50f3:	test   %eax,%eax
 29f50f5:	je     29fc5a3 <wasm[0]::function[1015]::helper::object_read+0x1b683>
 29f50fb:	test   %edx,%edx
 29f50fd:	je     29fc5a5 <wasm[0]::function[1015]::helper::object_read+0x1b685>
 29f5103:	mov    0x2e0(%rsp),%r12
 29f510b:	mov    0x28(%r12),%r9
 29f5110:	mov    0x20(%r12),%r11
 29f5115:	mov    %edx,%r10d
 29f5118:	lea    (%r11,%r10,1),%rsi
 29f511c:	xor    %r11,%r11
 29f511f:	cmp    %r9,%r10
 29f5122:	cmova  %r11,%rsi
 29f5126:	mov    0x18(%rsi),%edx
 29f5129:	mov    0x10(%rsi),%r8
 29f512d:	mov    0x1c(%rsi),%esi
 29f5130:	mov    0xd0(%rsp),%edi
 29f5137:	mov    0xd8(%rsp),%r15d
 29f513f:	mov    0xb0(%rsp),%r9d
 29f5147:	mov    %r9,0x198(%rsp)
 29f514f:	mov    0xa8(%rsp),%r10d
 29f5157:	mov    %r10,0x1a0(%rsp)
 29f515f:	mov    0xc8(%rsp),%r10d
 29f5167:	mov    0xb8(%rsp),%r11d
 29f516f:	mov    0x88(%rsp),%ebx
 29f5176:	jmp    29f5a7e <wasm[0]::function[1015]::helper::object_read+0x14b5e>
 29f517b:	mov    0xc0(%rsp),%eax
 29f5182:	test   %eax,%eax
 29f5184:	je     29fc5a7 <wasm[0]::function[1015]::helper::object_read+0x1b687>
 29f518a:	mov    0xc0(%rsp),%ecx
 29f5191:	xor    %eax,%eax
 29f5193:	test   $0x1,%ecx
 29f5199:	jne    29f51f3 <wasm[0]::function[1015]::helper::object_read+0x142d3>
 29f519f:	mov    0x2e0(%rsp),%r12
 29f51a7:	mov    0x28(%r12),%rax
 29f51ac:	mov    0x20(%r12),%rsi
 29f51b1:	mov    %ecx,%edx
 29f51b3:	lea    0x4(%rsi,%rdx,1),%rcx
 29f51b8:	xor    %rsi,%rsi
 29f51bb:	cmp    %rax,%rdx
 29f51be:	cmova  %rsi,%rcx
 29f51c2:	mov    (%rcx),%esi
 29f51c4:	mov    0x190(%rsp),%rax
 29f51cc:	mov    0x28(%rax),%rax
 29f51d0:	mov    0x158(%rax),%edx
 29f51d6:	cmp    %edx,%esi
 29f51d8:	sete   %al
 29f51db:	movzbl %al,%eax
 29f51de:	cmp    %edx,%esi
 29f51e0:	je     29f51f3 <wasm[0]::function[1015]::helper::object_read+0x142d3>
 29f51e6:	mov    0x190(%rsp),%rdi
 29f51ee:	call   3018e75 <wasmtime_builtin_is_subtype>
 29f51f3:	test   %eax,%eax
 29f51f5:	je     29fc5a9 <wasm[0]::function[1015]::helper::object_read+0x1b689>
 29f51fb:	mov    0xc0(%rsp),%r14d
 29f5203:	mov    0xd0(%rsp),%edi
 29f520a:	mov    0xd8(%rsp),%r15d
 29f5212:	mov    0xe8(%rsp),%esi
 29f5219:	mov    0xb0(%rsp),%r9d
 29f5221:	mov    %r9,0x198(%rsp)
 29f5229:	mov    0xa8(%rsp),%r10d
 29f5231:	mov    %r10,0x1a0(%rsp)
 29f5239:	mov    0xc8(%rsp),%r10d
 29f5241:	mov    0xb8(%rsp),%r11d
 29f5249:	mov    0x88(%rsp),%ebx
 29f5250:	xor    %ecx,%ecx
 29f5252:	mov    %rcx,0x230(%rsp)
 29f525a:	test   %r14d,%r14d
 29f525d:	je     29fc5ab <wasm[0]::function[1015]::helper::object_read+0x1b68b>
 29f5263:	test   %r14d,%r14d
 29f5266:	je     29fc5ad <wasm[0]::function[1015]::helper::object_read+0x1b68d>
 29f526c:	mov    0x2e0(%rsp),%r12
 29f5274:	mov    0x28(%r12),%rax
 29f5279:	mov    0x20(%r12),%rcx
 29f527e:	mov    %r14d,%r12d
 29f5281:	lea    (%rcx,%r12,1),%rdx
 29f5285:	xor    %r8,%r8
 29f5288:	cmp    %rax,%r12
 29f528b:	cmova  %r8,%rdx
 29f528f:	mov    0x10(%rdx),%edx
 29f5292:	test   %edx,%edx
 29f5294:	je     29fc5af <wasm[0]::function[1015]::helper::object_read+0x1b68f>
 29f529a:	test   %edx,%edx
 29f529c:	je     29fc5b1 <wasm[0]::function[1015]::helper::object_read+0x1b691>
 29f52a2:	mov    %edx,%r12d
 29f52a5:	lea    (%rcx,%r12,1),%rdx
 29f52a9:	cmp    %rax,%r12
 29f52ac:	cmova  %r8,%rdx
 29f52b0:	mov    0x10(%rdx),%edx
 29f52b3:	test   %edx,%edx
 29f52b5:	je     29fc5b3 <wasm[0]::function[1015]::helper::object_read+0x1b693>
 29f52bb:	test   %edx,%edx
 29f52bd:	je     29fc5b5 <wasm[0]::function[1015]::helper::object_read+0x1b695>
 29f52c3:	mov    %edx,%r12d
 29f52c6:	lea    0x10(%rcx,%r12,1),%rcx
 29f52cb:	cmp    %rax,%r12
 29f52ce:	cmova  %r8,%rcx
 29f52d2:	mov    (%rcx),%r13d
 29f52d5:	mov    %r13,0x240(%rsp)
 29f52dd:	mov    0x98(%rsp),%r8d
 29f52e5:	mov    0x190(%rsp),%rax
 29f52ed:	mov    0x28(%rax),%rax
 29f52f1:	mov    0x234(%rax),%r13d
 29f52f8:	mov    %r13,0x238(%rsp)
 29f5300:	mov    0x230(%rsp),%rax
 29f5308:	mov    %rax,0x1c8(%rsp)
 29f5310:	mov    %edx,0x78(%rsp)
 29f5314:	mov    %r8d,0x88(%rsp)
 29f531c:	mov    %r14d,0xb8(%rsp)
 29f5324:	mov    %edi,0xc8(%rsp)
 29f532b:	mov    %r15d,0xa8(%rsp)
 29f5333:	mov    %esi,0xb0(%rsp)
 29f533a:	mov    0x198(%rsp),%r9
 29f5342:	mov    %r9d,0xe8(%rsp)
 29f534a:	mov    0x1a0(%rsp),%rdx
 29f5352:	mov    %edx,0xd8(%rsp)
 29f5359:	mov    %r10d,0xd0(%rsp)
 29f5361:	mov    %r11d,0xc0(%rsp)
 29f5369:	mov    %ebx,0x98(%rsp)
 29f5370:	mov    0x2e8(%rsp),%r13
 29f5378:	mov    0x0(%r13),%rcx
 29f537c:	mov    0x228(%rsp),%rax
 29f5384:	cmp    %rax,%rcx
 29f5387:	jae    29fb4be <wasm[0]::function[1015]::helper::object_read+0x1a59e>
 29f538d:	jmp    29f539a <wasm[0]::function[1015]::helper::object_read+0x1447a>
 29f5392:	mov    %rdx,0x228(%rsp)
 29f539a:	mov    0xb8(%rsp),%r14d
 29f53a2:	mov    0xc8(%rsp),%edi
 29f53a9:	mov    0xa8(%rsp),%r15d
 29f53b1:	mov    0xb0(%rsp),%esi
 29f53b8:	mov    0xe8(%rsp),%r9d
 29f53c0:	mov    %r9,0x198(%rsp)
 29f53c8:	mov    0xd8(%rsp),%r10d
 29f53d0:	mov    %r10,0x1a0(%rsp)
 29f53d8:	mov    0xd0(%rsp),%r10d
 29f53e0:	mov    0xc0(%rsp),%r11d
 29f53e8:	mov    0x98(%rsp),%ebx
 29f53ef:	mov    0x240(%rsp),%rax
 29f53f7:	mov    0x230(%rsp),%rcx
 29f53ff:	cmp    %eax,%ecx
 29f5401:	jb     29f5414 <wasm[0]::function[1015]::helper::object_read+0x144f4>
 29f5407:	mov    0x1c8(%rsp),%rax
 29f540f:	jmp    29f565f <wasm[0]::function[1015]::helper::object_read+0x1473f>
 29f5414:	mov    0x78(%rsp),%eax
 29f5418:	test   %eax,%eax
 29f541a:	je     29fc5b7 <wasm[0]::function[1015]::helper::object_read+0x1b697>
 29f5420:	test   %eax,%eax
 29f5422:	je     29fc5b9 <wasm[0]::function[1015]::helper::object_read+0x1b699>
 29f5428:	mov    0x2e0(%rsp),%r12
 29f5430:	mov    0x28(%r12),%r8
 29f5435:	mov    0x20(%r12),%r9
 29f543a:	mov    %eax,%r11d
 29f543d:	lea    0x10(%r9,%r11,1),%rsi
 29f5442:	xor    %r10,%r10
 29f5445:	cmp    %r8,%r11
 29f5448:	cmova  %r10,%rsi
 29f544c:	mov    (%rsi),%edx
 29f544e:	cmp    %edx,%ecx
 29f5450:	jae    29fc5bb <wasm[0]::function[1015]::helper::object_read+0x1b69b>
 29f5456:	mov    %edx,%r11d
 29f5459:	shl    $0x2,%r11
 29f545d:	shr    $0x20,%r11
 29f5461:	test   %r11,%r11
 29f5464:	jne    29fc5bd <wasm[0]::function[1015]::helper::object_read+0x1b69d>
 29f546a:	shl    $0x2,%edx
 29f546d:	add    $0x14,%edx
 29f5470:	jb     29fc5bf <wasm[0]::function[1015]::helper::object_read+0x1b69f>
 29f5476:	add    %edx,%eax
 29f5478:	jb     29fc5c1 <wasm[0]::function[1015]::helper::object_read+0x1b6a1>
 29f547e:	mov    %eax,%eax
 29f5480:	lea    (%r9,%rax,1),%r11
 29f5484:	cmp    %r8,%rax
 29f5487:	cmova  %r10,%r11
 29f548b:	mov    %rcx,%rax
 29f548e:	shl    $0x2,%eax
 29f5491:	mov    %rcx,0x230(%rsp)
 29f5499:	add    $0x14,%eax
 29f549f:	sub    %eax,%edx
 29f54a1:	sub    %rdx,%r11
 29f54a4:	mov    (%r11),%edx
 29f54a7:	test   %edx,%edx
 29f54a9:	je     29fc5c3 <wasm[0]::function[1015]::helper::object_read+0x1b6a3>
 29f54af:	mov    0x88(%rsp),%eax
 29f54b6:	cmp    %eax,%edx
 29f54b8:	je     29f55ae <wasm[0]::function[1015]::helper::object_read+0x1468e>
 29f54be:	xor    %ecx,%ecx
 29f54c0:	test   %edx,%edx
 29f54c2:	jne    29f54d5 <wasm[0]::function[1015]::helper::object_read+0x145b5>
 29f54c8:	mov    0x238(%rsp),%r13
 29f54d0:	jmp    29f5526 <wasm[0]::function[1015]::helper::object_read+0x14606>
 29f54d5:	xor    %ecx,%ecx
 29f54d7:	test   $0x1,%edx
 29f54dd:	je     29f54f0 <wasm[0]::function[1015]::helper::object_read+0x145d0>
 29f54e3:	mov    0x238(%rsp),%r13
 29f54eb:	jmp    29f5526 <wasm[0]::function[1015]::helper::object_read+0x14606>
 29f54f0:	mov    0x2e0(%rsp),%r12
 29f54f8:	mov    0x28(%r12),%rcx
 29f54fd:	mov    0x20(%r12),%rsi
 29f5502:	mov    %edx,%edi
 29f5504:	lea    0x4(%rsi,%rdi,1),%rsi
 29f5509:	xor    %r8,%r8
 29f550c:	cmp    %rcx,%rdi
 29f550f:	cmova  %r8,%rsi
 29f5513:	mov    (%rsi),%ecx
 29f5515:	mov    0x238(%rsp),%r13
 29f551d:	cmp    %r13d,%ecx
 29f5520:	sete   %cl
 29f5523:	movzbl %cl,%ecx
 29f5526:	test   %ecx,%ecx
 29f5528:	je     29fc5c5 <wasm[0]::function[1015]::helper::object_read+0x1b6a5>
 29f552e:	xor    %ecx,%ecx
 29f5530:	test   %eax,%eax
 29f5532:	je     29f557a <wasm[0]::function[1015]::helper::object_read+0x1465a>
 29f5538:	mov    0x88(%rsp),%eax
 29f553f:	xor    %ecx,%ecx
 29f5541:	test   $0x1,%eax
 29f5546:	jne    29f557a <wasm[0]::function[1015]::helper::object_read+0x1465a>
 29f554c:	mov    0x2e0(%rsp),%r12
 29f5554:	mov    0x28(%r12),%rcx
 29f5559:	mov    0x20(%r12),%rdi
 29f555e:	mov    %eax,%esi
 29f5560:	lea    0x4(%rdi,%rsi,1),%rax
 29f5565:	xor    %rdi,%rdi
 29f5568:	cmp    %rcx,%rsi
 29f556b:	cmova  %rdi,%rax
 29f556f:	mov    (%rax),%eax
 29f5571:	cmp    %r13d,%eax
 29f5574:	sete   %al
 29f5577:	movzbl %al,%ecx
 29f557a:	test   %ecx,%ecx
 29f557c:	je     29fc5c7 <wasm[0]::function[1015]::helper::object_read+0x1b6a7>
 29f5582:	mov    0x88(%rsp),%ecx
 29f5589:	xor    %r8d,%r8d
 29f558c:	test   %ecx,%ecx
 29f558e:	je     29fc5c9 <wasm[0]::function[1015]::helper::object_read+0x1b6a9>
 29f5594:	mov    0x190(%rsp),%rsi
 29f559c:	mov    0x190(%rsp),%rdi
 29f55a4:	call   2ae54e0 <wasm[0]::function[1057]::helper::string_equality>
 29f55a9:	jmp    29f55be <wasm[0]::function[1015]::helper::object_read+0x1469e>
 29f55ae:	mov    0x238(%rsp),%r13
 29f55b6:	mov    0x278(%rsp),%rax
 29f55be:	mov    0x78(%rsp),%edx
 29f55c2:	mov    0x88(%rsp),%r8d
 29f55ca:	mov    0xb8(%rsp),%r14d
 29f55d2:	mov    0xc8(%rsp),%edi
 29f55d9:	mov    0xa8(%rsp),%r15d
 29f55e1:	mov    0xb0(%rsp),%esi
 29f55e8:	mov    0xe8(%rsp),%r9d
 29f55f0:	mov    %r9,0x198(%rsp)
 29f55f8:	mov    0xd8(%rsp),%r10d
 29f5600:	mov    %r10,0x1a0(%rsp)
 29f5608:	mov    0xd0(%rsp),%r10d
 29f5610:	mov    0xc0(%rsp),%r11d
 29f5618:	mov    0x98(%rsp),%ebx
 29f561f:	test   %eax,%eax
 29f5621:	je     29f5634 <wasm[0]::function[1015]::helper::object_read+0x14714>
 29f5627:	mov    0x230(%rsp),%rcx
 29f562f:	jmp    29f565f <wasm[0]::function[1015]::helper::object_read+0x1473f>
 29f5634:	mov    0x230(%rsp),%rcx
 29f563c:	add    $0x1,%ecx
 29f5642:	mov    %rax,0x1c8(%rsp)
 29f564a:	mov    %rcx,0x230(%rsp)
 29f5652:	mov    %r13,0x238(%rsp)
 29f565a:	jmp    29f5310 <wasm[0]::function[1015]::helper::object_read+0x143f0>
 29f565f:	xor    %edx,%edx
 29f5661:	xor    %r8,%r8
 29f5664:	test   %eax,%eax
 29f5666:	je     29f5a7e <wasm[0]::function[1015]::helper::object_read+0x14b5e>
 29f566c:	test   %r14d,%r14d
 29f566f:	je     29fc5cb <wasm[0]::function[1015]::helper::object_read+0x1b6ab>
 29f5675:	xor    %eax,%eax
 29f5677:	test   $0x1,%r14d
 29f567e:	jne    29f56c5 <wasm[0]::function[1015]::helper::object_read+0x147a5>
 29f5684:	mov    0x2e0(%rsp),%r12
 29f568c:	mov    0x28(%r12),%rsi
 29f5691:	mov    0x20(%r12),%rax
 29f5696:	mov    %r14d,%r8d
 29f5699:	lea    0x4(%rax,%r8,1),%rax
 29f569e:	xor    %rdx,%rdx
 29f56a1:	cmp    %rsi,%r8
 29f56a4:	cmova  %rdx,%rax
 29f56a8:	mov    (%rax),%esi
 29f56aa:	mov    0x190(%rsp),%rax
 29f56b2:	mov    0x28(%rax),%r8
 29f56b6:	cmp    0x160(%r8),%esi
 29f56bd:	sete   %sil
 29f56c1:	movzbl %sil,%eax
 29f56c5:	test   %eax,%eax
 29f56c7:	jne    29f5912 <wasm[0]::function[1015]::helper::object_read+0x149f2>
 29f56cd:	xor    %eax,%eax
 29f56cf:	test   $0x1,%r14d
 29f56d6:	jne    29f571a <wasm[0]::function[1015]::helper::object_read+0x147fa>
 29f56dc:	mov    0x2e0(%rsp),%r12
 29f56e4:	mov    0x28(%r12),%rax
 29f56e9:	mov    0x20(%r12),%rdx
 29f56ee:	mov    %r14d,%esi
 29f56f1:	lea    0x4(%rdx,%rsi,1),%rdx
 29f56f6:	xor    %r8,%r8
 29f56f9:	cmp    %rax,%rsi
 29f56fc:	cmova  %r8,%rdx
 29f5700:	mov    (%rdx),%eax
 29f5702:	mov    0x190(%rsp),%rsi
 29f570a:	mov    0x28(%rsi),%rdx
 29f570e:	cmp    0x15c(%rdx),%eax
 29f5714:	sete   %al
 29f5717:	movzbl %al,%eax
 29f571a:	test   %eax,%eax
 29f571c:	je     29fc5cd <wasm[0]::function[1015]::helper::object_read+0x1b6ad>
 29f5722:	test   %r14d,%r14d
 29f5725:	je     29fc5cf <wasm[0]::function[1015]::helper::object_read+0x1b6af>
 29f572b:	mov    0x2e0(%rsp),%r12
 29f5733:	mov    0x28(%r12),%rsi
 29f5738:	mov    0x20(%r12),%r12
 29f573d:	mov    %r14d,%eax
 29f5740:	lea    (%r12,%rax,1),%rdx
 29f5744:	xor    %r8,%r8
 29f5747:	cmp    %rsi,%rax
 29f574a:	cmova  %r8,%rdx
 29f574e:	mov    0x14(%rdx),%r13d
 29f5752:	mov    0x18(%rdx),%eax
 29f5755:	mov    0x1c(%rdx),%edx
 29f5758:	test   %r13d,%r13d
 29f575b:	je     29fc5d1 <wasm[0]::function[1015]::helper::object_read+0x1b6b1>
 29f5761:	test   %r13d,%r13d
 29f5764:	je     29fc5d3 <wasm[0]::function[1015]::helper::object_read+0x1b6b3>
 29f576a:	mov    %r13d,%r9d
 29f576d:	lea    0x10(%r12,%r9,1),%r14
 29f5772:	cmp    %rsi,%r9
 29f5775:	cmova  %r8,%r14
 29f5779:	mov    (%r14),%r14d
 29f577c:	cmp    %r14d,%ecx
 29f577f:	jae    29fc5d5 <wasm[0]::function[1015]::helper::object_read+0x1b6b5>
 29f5785:	mov    %r14d,%r9d
 29f5788:	shr    $0x20,%r9
 29f578c:	test   %r9,%r9
 29f578f:	jne    29fc5d7 <wasm[0]::function[1015]::helper::object_read+0x1b6b7>
 29f5795:	add    $0x14,%r14d
 29f5799:	jb     29fc5d9 <wasm[0]::function[1015]::helper::object_read+0x1b6b9>
 29f579f:	add    %r14d,%r13d
 29f57a2:	jb     29fc5db <wasm[0]::function[1015]::helper::object_read+0x1b6bb>
 29f57a8:	mov    %r13d,%r9d
 29f57ab:	add    %r9,%r12
 29f57ae:	cmp    %rsi,%r9
 29f57b1:	cmova  %r8,%r12
 29f57b5:	lea    0x14(%rcx),%esi
 29f57b8:	sub    %esi,%r14d
 29f57bb:	sub    %r14,%r12
 29f57be:	movzbq (%r12),%r9
 29f57c3:	mov    %r9,0x238(%rsp)
 29f57cb:	test   %eax,%eax
 29f57cd:	je     29f5862 <wasm[0]::function[1015]::helper::object_read+0x14942>
 29f57d3:	test   %eax,%eax
 29f57d5:	je     29fc5dd <wasm[0]::function[1015]::helper::object_read+0x1b6bd>
 29f57db:	test   %eax,%eax
 29f57dd:	je     29fc5df <wasm[0]::function[1015]::helper::object_read+0x1b6bf>
 29f57e3:	mov    0x2e0(%rsp),%r12
 29f57eb:	mov    0x28(%r12),%rsi
 29f57f0:	mov    0x20(%r12),%r8
 29f57f5:	mov    %eax,%r14d
 29f57f8:	lea    0x10(%r8,%r14,1),%r13
 29f57fd:	xor    %r12,%r12
 29f5800:	cmp    %rsi,%r14
 29f5803:	cmova  %r12,%r13
 29f5807:	mov    0x0(%r13),%r13d
 29f580b:	cmp    %r13d,%ecx
 29f580e:	jae    29fc5e1 <wasm[0]::function[1015]::helper::object_read+0x1b6c1>
 29f5814:	mov    %r13d,%r14d
 29f5817:	shl    $0x3,%r14
 29f581b:	shr    $0x20,%r14
 29f581f:	test   %r14,%r14
 29f5822:	jne    29fc5e3 <wasm[0]::function[1015]::helper::object_read+0x1b6c3>
 29f5828:	shl    $0x3,%r13d
 29f582c:	add    $0x18,%r13d
 29f5830:	jb     29fc5e5 <wasm[0]::function[1015]::helper::object_read+0x1b6c5>
 29f5836:	add    %r13d,%eax
 29f5839:	jb     29fc5e7 <wasm[0]::function[1015]::helper::object_read+0x1b6c7>
 29f583f:	mov    %eax,%r9d
 29f5842:	lea    (%r8,%r9,1),%rax
 29f5846:	cmp    %rsi,%r9
 29f5849:	cmova  %r12,%rax
 29f584d:	mov    %rcx,%rsi
 29f5850:	shl    $0x3,%esi
 29f5853:	add    $0x18,%esi
 29f5859:	sub    %esi,%r13d
 29f585c:	sub    %r13,%rax
 29f585f:	mov    (%rax),%r8
 29f5862:	xor    %esi,%esi
 29f5864:	test   %edx,%edx
 29f5866:	jne    29f5879 <wasm[0]::function[1015]::helper::object_read+0x14959>
 29f586c:	mov    0x238(%rsp),%r9
 29f5874:	jmp    29f5909 <wasm[0]::function[1015]::helper::object_read+0x149e9>
 29f5879:	test   %edx,%edx
 29f587b:	je     29fc5e9 <wasm[0]::function[1015]::helper::object_read+0x1b6c9>
 29f5881:	test   %edx,%edx
 29f5883:	je     29fc5eb <wasm[0]::function[1015]::helper::object_read+0x1b6cb>
 29f5889:	mov    0x2e0(%rsp),%r12
 29f5891:	mov    0x28(%r12),%rax
 29f5896:	mov    0x20(%r12),%rsi
 29f589b:	mov    %edx,%r14d
 29f589e:	lea    0x10(%rsi,%r14,1),%r13
 29f58a3:	xor    %r12,%r12
 29f58a6:	cmp    %rax,%r14
 29f58a9:	cmova  %r12,%r13
 29f58ad:	mov    0x0(%r13),%r13d
 29f58b1:	cmp    %r13d,%ecx
 29f58b4:	jae    29fc5ed <wasm[0]::function[1015]::helper::object_read+0x1b6cd>
 29f58ba:	mov    %r13d,%r14d
 29f58bd:	shl    $0x2,%r14
 29f58c1:	shr    $0x20,%r14
 29f58c5:	test   %r14,%r14
 29f58c8:	jne    29fc5ef <wasm[0]::function[1015]::helper::object_read+0x1b6cf>
 29f58ce:	shl    $0x2,%r13d
 29f58d2:	add    $0x14,%r13d
 29f58d6:	jb     29fc5f1 <wasm[0]::function[1015]::helper::object_read+0x1b6d1>
 29f58dc:	add    %r13d,%edx
 29f58df:	jb     29fc5f3 <wasm[0]::function[1015]::helper::object_read+0x1b6d3>
 29f58e5:	mov    %edx,%r9d
 29f58e8:	lea    (%rsi,%r9,1),%rdx
 29f58ec:	cmp    %rax,%r9
 29f58ef:	cmova  %r12,%rdx
 29f58f3:	shl    $0x2,%ecx
 29f58f6:	lea    0x14(%rcx),%eax
 29f58f9:	sub    %eax,%r13d
 29f58fc:	sub    %r13,%rdx
 29f58ff:	mov    (%rdx),%esi
 29f5901:	mov    0x238(%rsp),%r9
 29f5909:	movzbl %r9b,%edx
 29f590d:	jmp    29f5a7e <wasm[0]::function[1015]::helper::object_read+0x14b5e>
 29f5912:	xor    %eax,%eax
 29f5914:	test   $0x1,%r14d
 29f591b:	jne    29f5963 <wasm[0]::function[1015]::helper::object_read+0x14a43>
 29f5921:	mov    0x2e0(%rsp),%r12
 29f5929:	mov    0x28(%r12),%rsi
 29f592e:	mov    0x20(%r12),%r8
 29f5933:	mov    %r14d,%eax
 29f5936:	lea    0x4(%r8,%rax,1),%r8
 29f593b:	xor    %rdx,%rdx
 29f593e:	cmp    %rsi,%rax
 29f5941:	cmova  %rdx,%r8
 29f5945:	mov    (%r8),%r8d
 29f5948:	mov    0x190(%rsp),%rsi
 29f5950:	mov    0x28(%rsi),%r9
 29f5954:	cmp    0x160(%r9),%r8d
 29f595b:	sete   %r8b
 29f595f:	movzbl %r8b,%eax
 29f5963:	test   %eax,%eax
 29f5965:	je     29fc5f5 <wasm[0]::function[1015]::helper::object_read+0x1b6d5>
 29f596b:	test   %r14d,%r14d
 29f596e:	je     29fc5f7 <wasm[0]::function[1015]::helper::object_read+0x1b6d7>
 29f5974:	mov    0x2e0(%rsp),%r12
 29f597c:	mov    0x28(%r12),%rdx
 29f5981:	mov    0x20(%r12),%rsi
 29f5986:	mov    %r14d,%eax
 29f5989:	lea    (%rsi,%rax,1),%r12
 29f598d:	xor    %r8,%r8
 29f5990:	cmp    %rdx,%rax
 29f5993:	cmova  %r8,%r12
 29f5997:	mov    0x10(%r12),%r14d
 29f599c:	test   %r14d,%r14d
 29f599f:	je     29fc5f9 <wasm[0]::function[1015]::helper::object_read+0x1b6d9>
 29f59a5:	test   %r14d,%r14d
 29f59a8:	je     29fc5fb <wasm[0]::function[1015]::helper::object_read+0x1b6db>
 29f59ae:	mov    %r14d,%r9d
 29f59b1:	lea    (%rsi,%r9,1),%r12
 29f59b5:	cmp    %rdx,%r9
 29f59b8:	cmova  %r8,%r12
 29f59bc:	mov    0x10(%r12),%r12d
 29f59c1:	test   %r12d,%r12d
 29f59c4:	je     29fc5fd <wasm[0]::function[1015]::helper::object_read+0x1b6dd>
 29f59ca:	test   %r12d,%r12d
 29f59cd:	je     29fc5ff <wasm[0]::function[1015]::helper::object_read+0x1b6df>
 29f59d3:	mov    %r12d,%r9d
 29f59d6:	lea    0x10(%rsi,%r9,1),%rsi
 29f59db:	cmp    %rdx,%r9
 29f59de:	cmova  %r8,%rsi
 29f59e2:	cmp    (%rsi),%ecx
 29f59e4:	setae  %dl
 29f59e7:	cmp    $0x2,%ecx
 29f59ea:	setae  %sil
 29f59ee:	or     %esi,%edx
 29f59f0:	test   %dl,%dl
 29f59f2:	jne    29fc601 <wasm[0]::function[1015]::helper::object_read+0x1b6e1>
 29f59f8:	mov    0x2e0(%rsp),%r12
 29f5a00:	mov    0x28(%r12),%rsi
 29f5a05:	mov    %rax,%rdx
 29f5a08:	add    0x20(%r12),%rdx
 29f5a0d:	xor    %r8,%r8
 29f5a10:	cmp    %rsi,%rax
 29f5a13:	cmova  %r8,%rdx
 29f5a17:	mov    0x14(%rdx),%edx
 29f5a1a:	test   %ecx,%ecx
 29f5a1c:	je     29f5a4d <wasm[0]::function[1015]::helper::object_read+0x14b2d>
 29f5a22:	mov    0x2e0(%rsp),%r12
 29f5a2a:	mov    0x28(%r12),%r8
 29f5a2f:	mov    0x20(%r12),%rsi
 29f5a34:	add    %rax,%rsi
 29f5a37:	xor    %r12,%r12
 29f5a3a:	cmp    %r8,%rax
 29f5a3d:	cmova  %r12,%rsi
 29f5a41:	mov    0x20(%rsi),%r8
 29f5a45:	mov    0x2c(%rsi),%esi
 29f5a48:	jmp    29f5a73 <wasm[0]::function[1015]::helper::object_read+0x14b53>
 29f5a4d:	mov    0x2e0(%rsp),%r12
 29f5a55:	mov    0x28(%r12),%r8
 29f5a5a:	mov    0x20(%r12),%rsi
 29f5a5f:	add    %rax,%rsi
 29f5a62:	xor    %r12,%r12
 29f5a65:	cmp    %r8,%rax
 29f5a68:	cmova  %r12,%rsi
 29f5a6c:	mov    0x18(%rsi),%r8
 29f5a70:	mov    0x28(%rsi),%esi
 29f5a73:	shl    $0x3,%ecx
 29f5a76:	shr    %cl,%edx
 29f5a78:	and    $0xff,%edx
 29f5a7e:	mov    0x198(%rsp),%r9
 29f5a86:	mov    %r9d,0xa8(%rsp)
 29f5a8e:	mov    0x1a0(%rsp),%rax
 29f5a96:	mov    %eax,0xc8(%rsp)
 29f5a9d:	mov    %r10d,0xb8(%rsp)
 29f5aa5:	mov    %r11d,0x88(%rsp)
 29f5aad:	mov    %ebx,0x78(%rsp)
 29f5ab1:	mov    0x1d0(%rsp),%rcx
 29f5ab9:	cmp    $0x2,%ecx
 29f5abc:	je     29f5dc9 <wasm[0]::function[1015]::helper::object_read+0x14ea9>
 29f5ac2:	cmp    $0x4,%ecx
 29f5ac5:	je     29f5d01 <wasm[0]::function[1015]::helper::object_read+0x14de1>
 29f5acb:	cmp    $0x3,%ecx
 29f5ace:	je     29f5cc5 <wasm[0]::function[1015]::helper::object_read+0x14da5>
 29f5ad4:	cmp    $0xa,%ecx
 29f5ad7:	je     29f5c00 <wasm[0]::function[1015]::helper::object_read+0x14ce0>
 29f5add:	test   %ecx,%ecx
 29f5adf:	sete   %al
 29f5ae2:	cmp    $0x1,%ecx
 29f5ae5:	sete   %cl
 29f5ae8:	or     %ecx,%eax
 29f5aea:	test   %al,%al
 29f5aec:	jne    29f5bf9 <wasm[0]::function[1015]::helper::object_read+0x14cd9>
 29f5af2:	xor    %eax,%eax
 29f5af4:	test   %edi,%edi
 29f5af6:	je     29f5b4b <wasm[0]::function[1015]::helper::object_read+0x14c2b>
 29f5afc:	xor    %eax,%eax
 29f5afe:	test   $0x1,%edi
 29f5b04:	jne    29f5b4b <wasm[0]::function[1015]::helper::object_read+0x14c2b>
 29f5b0a:	mov    0x2e0(%rsp),%r12
 29f5b12:	mov    0x28(%r12),%rax
 29f5b17:	mov    0x20(%r12),%rcx
 29f5b1c:	mov    %edi,%r9d
 29f5b1f:	lea    0x4(%rcx,%r9,1),%rcx
 29f5b24:	xor    %r10,%r10
 29f5b27:	cmp    %rax,%r9
 29f5b2a:	cmova  %r10,%rcx
 29f5b2e:	mov    (%rcx),%ecx
 29f5b30:	mov    0x190(%rsp),%rax
 29f5b38:	mov    0x28(%rax),%r9
 29f5b3c:	cmp    0x1d4(%r9),%ecx
 29f5b43:	sete   %r9b
 29f5b47:	movzbl %r9b,%eax
 29f5b4b:	test   %eax,%eax
 29f5b4d:	jne    29f5b5a <wasm[0]::function[1015]::helper::object_read+0x14c3a>
 29f5b53:	xor    %eax,%eax
 29f5b55:	jmp    29f5bec <wasm[0]::function[1015]::helper::object_read+0x14ccc>
 29f5b5a:	xor    %eax,%eax
 29f5b5c:	test   %edi,%edi
 29f5b5e:	je     29f5bb0 <wasm[0]::function[1015]::helper::object_read+0x14c90>
 29f5b64:	xor    %eax,%eax
 29f5b66:	test   $0x1,%edi
 29f5b6c:	jne    29f5bb0 <wasm[0]::function[1015]::helper::object_read+0x14c90>
 29f5b72:	mov    0x2e0(%rsp),%r12
 29f5b7a:	mov    0x28(%r12),%rax
 29f5b7f:	mov    0x20(%r12),%r9
 29f5b84:	mov    %edi,%ecx
 29f5b86:	lea    0x4(%r9,%rcx,1),%r9
 29f5b8b:	xor    %r10,%r10
 29f5b8e:	cmp    %rax,%rcx
 29f5b91:	cmova  %r10,%r9
 29f5b95:	mov    (%r9),%eax
 29f5b98:	mov    0x190(%rsp),%rcx
 29f5ba0:	mov    0x28(%rcx),%rcx
 29f5ba4:	cmp    0x1d4(%rcx),%eax
 29f5baa:	sete   %al
 29f5bad:	movzbl %al,%eax
 29f5bb0:	test   %eax,%eax
 29f5bb2:	je     29fc603 <wasm[0]::function[1015]::helper::object_read+0x1b6e3>
 29f5bb8:	test   %edi,%edi
 29f5bba:	je     29fc605 <wasm[0]::function[1015]::helper::object_read+0x1b6e5>
 29f5bc0:	test   %edi,%edi
 29f5bc2:	je     29fc607 <wasm[0]::function[1015]::helper::object_read+0x1b6e7>
 29f5bc8:	mov    0x2e0(%rsp),%r12
 29f5bd0:	mov    0x28(%r12),%rax
 29f5bd5:	mov    %edi,%edi
 29f5bd7:	mov    %rdi,%rcx
 29f5bda:	add    0x20(%r12),%rcx
 29f5bdf:	xor    %r9,%r9
 29f5be2:	cmp    %rax,%rdi
 29f5be5:	cmova  %r9,%rcx
 29f5be9:	mov    0x3c(%rcx),%eax
 29f5bec:	test   %eax,%eax
 29f5bee:	sete   %al
 29f5bf1:	movzbl %al,%ebx
 29f5bf4:	jmp    29f5dbc <wasm[0]::function[1015]::helper::object_read+0x14e9c>
 29f5bf9:	xor    %ebx,%ebx
 29f5bfb:	jmp    29f5dbc <wasm[0]::function[1015]::helper::object_read+0x14e9c>
 29f5c00:	xor    %eax,%eax
 29f5c02:	test   %edi,%edi
 29f5c04:	je     29f5c56 <wasm[0]::function[1015]::helper::object_read+0x14d36>
 29f5c0a:	xor    %eax,%eax
 29f5c0c:	test   $0x1,%edi
 29f5c12:	jne    29f5c56 <wasm[0]::function[1015]::helper::object_read+0x14d36>
 29f5c18:	mov    0x2e0(%rsp),%r12
 29f5c20:	mov    0x28(%r12),%rax
 29f5c25:	mov    0x20(%r12),%rcx
 29f5c2a:	mov    %edi,%r9d
 29f5c2d:	lea    0x4(%rcx,%r9,1),%rcx
 29f5c32:	xor    %r10,%r10
 29f5c35:	cmp    %rax,%r9
 29f5c38:	cmova  %r10,%rcx
 29f5c3c:	mov    (%rcx),%eax
 29f5c3e:	mov    0x190(%rsp),%rcx
 29f5c46:	mov    0x28(%rcx),%rcx
 29f5c4a:	cmp    0x23c(%rcx),%eax
 29f5c50:	sete   %al
 29f5c53:	movzbl %al,%eax
 29f5c56:	test   %eax,%eax
 29f5c58:	je     29fc609 <wasm[0]::function[1015]::helper::object_read+0x1b6e9>
 29f5c5e:	test   %edi,%edi
 29f5c60:	je     29fc60b <wasm[0]::function[1015]::helper::object_read+0x1b6eb>
 29f5c66:	test   %edi,%edi
 29f5c68:	je     29fc60d <wasm[0]::function[1015]::helper::object_read+0x1b6ed>
 29f5c6e:	mov    0x2e0(%rsp),%r12
 29f5c76:	mov    0x28(%r12),%rax
 29f5c7b:	mov    0x20(%r12),%rcx
 29f5c80:	mov    %edi,%r10d
 29f5c83:	lea    (%rcx,%r10,1),%r9
 29f5c87:	xor    %rdi,%rdi
 29f5c8a:	cmp    %rax,%r10
 29f5c8d:	cmova  %rdi,%r9
 29f5c91:	mov    0x14(%r9),%r9d
 29f5c95:	test   %r9d,%r9d
 29f5c98:	je     29fc60f <wasm[0]::function[1015]::helper::object_read+0x1b6ef>
 29f5c9e:	test   %r9d,%r9d
 29f5ca1:	je     29fc611 <wasm[0]::function[1015]::helper::object_read+0x1b6f1>
 29f5ca7:	mov    %r9d,%r9d
 29f5caa:	lea    0x10(%rcx,%r9,1),%rcx
 29f5caf:	cmp    %rax,%r9
 29f5cb2:	cmova  %rdi,%rcx
 29f5cb6:	mov    (%rcx),%eax
 29f5cb8:	test   %eax,%eax
 29f5cba:	setne  %al
 29f5cbd:	movzbl %al,%ebx
 29f5cc0:	jmp    29f5dbc <wasm[0]::function[1015]::helper::object_read+0x14e9c>
 29f5cc5:	mov    0x1d8(%rsp),%rcx
 29f5ccd:	movq   %rcx,%xmm0
 29f5cd2:	ucomisd 0x6c06(%rip),%xmm0        # 29fc8e0 <wasm[0]::function[1015]::helper::object_read+0x1b9c0>
 29f5cda:	setnp  %al
 29f5cdd:	sete   %cl
 29f5ce0:	and    %ecx,%eax
 29f5ce2:	ucomisd %xmm0,%xmm0
 29f5ce6:	setp   %cl
 29f5ce9:	setne  %dil
 29f5ced:	or     %edi,%ecx
 29f5cef:	or     %ecx,%eax
 29f5cf1:	movzbl %al,%eax
 29f5cf4:	test   %eax,%eax
 29f5cf6:	sete   %al
 29f5cf9:	movzbl %al,%ebx
 29f5cfc:	jmp    29f5dbc <wasm[0]::function[1015]::helper::object_read+0x14e9c>
 29f5d01:	xor    %eax,%eax
 29f5d03:	test   %edi,%edi
 29f5d05:	je     29f5d57 <wasm[0]::function[1015]::helper::object_read+0x14e37>
 29f5d0b:	xor    %eax,%eax
 29f5d0d:	test   $0x1,%edi
 29f5d13:	jne    29f5d57 <wasm[0]::function[1015]::helper::object_read+0x14e37>
 29f5d19:	mov    0x2e0(%rsp),%r12
 29f5d21:	mov    0x28(%r12),%rax
 29f5d26:	mov    0x20(%r12),%rcx
 29f5d2b:	mov    %edi,%r9d
 29f5d2e:	lea    0x4(%rcx,%r9,1),%rcx
 29f5d33:	xor    %r10,%r10
 29f5d36:	cmp    %rax,%r9
 29f5d39:	cmova  %r10,%rcx
 29f5d3d:	mov    (%rcx),%eax
 29f5d3f:	mov    0x190(%rsp),%rcx
 29f5d47:	mov    0x28(%rcx),%rcx
 29f5d4b:	cmp    0x234(%rcx),%eax
 29f5d51:	sete   %cl
 29f5d54:	movzbl %cl,%eax
 29f5d57:	test   %eax,%eax
 29f5d59:	je     29fc613 <wasm[0]::function[1015]::helper::object_read+0x1b6f3>
 29f5d5f:	test   %edi,%edi
 29f5d61:	je     29fc615 <wasm[0]::function[1015]::helper::object_read+0x1b6f5>
 29f5d67:	test   %edi,%edi
 29f5d69:	je     29fc617 <wasm[0]::function[1015]::helper::object_read+0x1b6f7>
 29f5d6f:	mov    0x2e0(%rsp),%r12
 29f5d77:	mov    0x28(%r12),%r9
 29f5d7c:	mov    0x20(%r12),%r10
 29f5d81:	mov    %edi,%eax
 29f5d83:	lea    (%r10,%rax,1),%rdi
 29f5d87:	xor    %r11,%r11
 29f5d8a:	cmp    %r9,%rax
 29f5d8d:	cmova  %r11,%rdi
 29f5d91:	mov    0x10(%rdi),%eax
 29f5d94:	test   %eax,%eax
 29f5d96:	je     29fc619 <wasm[0]::function[1015]::helper::object_read+0x1b6f9>
 29f5d9c:	test   %eax,%eax
 29f5d9e:	je     29fc61b <wasm[0]::function[1015]::helper::object_read+0x1b6fb>
 29f5da4:	mov    %eax,%ecx
 29f5da6:	lea    0x10(%r10,%rcx,1),%rax
 29f5dab:	cmp    %r9,%rcx
 29f5dae:	cmova  %r11,%rax
 29f5db2:	mov    (%rax),%eax
 29f5db4:	test   %eax,%eax
 29f5db6:	setne  %al
 29f5db9:	movzbl %al,%ebx
 29f5dbc:	mov    0x1e0(%rsp),%r11
 29f5dc4:	jmp    29f5de2 <wasm[0]::function[1015]::helper::object_read+0x14ec2>
 29f5dc9:	mov    0x1d8(%rsp),%rcx
 29f5dd1:	test   %rcx,%rcx
 29f5dd4:	setne  %al
 29f5dd7:	movzbl %al,%ebx
 29f5dda:	mov    0x1e0(%rsp),%r11
 29f5de2:	cmp    $0x2,%r11d
 29f5de6:	je     29f610a <wasm[0]::function[1015]::helper::object_read+0x151ea>
 29f5dec:	cmp    $0x4,%r11d
 29f5df0:	je     29f6040 <wasm[0]::function[1015]::helper::object_read+0x15120>
 29f5df6:	cmp    $0x3,%r11d
 29f5dfa:	je     29f6003 <wasm[0]::function[1015]::helper::object_read+0x150e3>
 29f5e00:	cmp    $0xa,%r11d
 29f5e04:	je     29f5f35 <wasm[0]::function[1015]::helper::object_read+0x15015>
 29f5e0a:	test   %r11d,%r11d
 29f5e0d:	sete   %al
 29f5e10:	cmp    $0x1,%r11d
 29f5e14:	sete   %cl
 29f5e17:	or     %ecx,%eax
 29f5e19:	test   %al,%al
 29f5e1b:	jne    29f5f2d <wasm[0]::function[1015]::helper::object_read+0x1500d>
 29f5e21:	xor    %ecx,%ecx
 29f5e23:	test   %r15d,%r15d
 29f5e26:	je     29f5e79 <wasm[0]::function[1015]::helper::object_read+0x14f59>
 29f5e2c:	xor    %ecx,%ecx
 29f5e2e:	test   $0x1,%r15d
 29f5e35:	jne    29f5e79 <wasm[0]::function[1015]::helper::object_read+0x14f59>
 29f5e3b:	mov    0x2e0(%rsp),%r12
 29f5e43:	mov    0x28(%r12),%rax
 29f5e48:	mov    0x20(%r12),%rcx
 29f5e4d:	mov    %r15d,%edi
 29f5e50:	lea    0x4(%rcx,%rdi,1),%rcx
 29f5e55:	xor    %r9,%r9
 29f5e58:	cmp    %rax,%rdi
 29f5e5b:	cmova  %r9,%rcx
 29f5e5f:	mov    (%rcx),%eax
 29f5e61:	mov    0x190(%rsp),%rcx
 29f5e69:	mov    0x28(%rcx),%rcx
 29f5e6d:	cmp    0x1d4(%rcx),%eax
 29f5e73:	sete   %al
 29f5e76:	movzbl %al,%ecx
 29f5e79:	test   %ecx,%ecx
 29f5e7b:	jne    29f5e88 <wasm[0]::function[1015]::helper::object_read+0x14f68>
 29f5e81:	xor    %eax,%eax
 29f5e83:	jmp    29f5f1f <wasm[0]::function[1015]::helper::object_read+0x14fff>
 29f5e88:	xor    %eax,%eax
 29f5e8a:	test   %r15d,%r15d
 29f5e8d:	je     29f5ee0 <wasm[0]::function[1015]::helper::object_read+0x14fc0>
 29f5e93:	xor    %eax,%eax
 29f5e95:	test   $0x1,%r15d
 29f5e9c:	jne    29f5ee0 <wasm[0]::function[1015]::helper::object_read+0x14fc0>
 29f5ea2:	mov    0x2e0(%rsp),%r12
 29f5eaa:	mov    0x28(%r12),%rax
 29f5eaf:	mov    0x20(%r12),%rcx
 29f5eb4:	mov    %r15d,%edi
 29f5eb7:	lea    0x4(%rcx,%rdi,1),%rcx
 29f5ebc:	xor    %r9,%r9
 29f5ebf:	cmp    %rax,%rdi
 29f5ec2:	cmova  %r9,%rcx
 29f5ec6:	mov    (%rcx),%eax
 29f5ec8:	mov    0x190(%rsp),%rcx
 29f5ed0:	mov    0x28(%rcx),%rcx
 29f5ed4:	cmp    0x1d4(%rcx),%eax
 29f5eda:	sete   %al
 29f5edd:	movzbl %al,%eax
 29f5ee0:	test   %eax,%eax
 29f5ee2:	je     29fc61d <wasm[0]::function[1015]::helper::object_read+0x1b6fd>
 29f5ee8:	test   %r15d,%r15d
 29f5eeb:	je     29fc61f <wasm[0]::function[1015]::helper::object_read+0x1b6ff>
 29f5ef1:	test   %r15d,%r15d
 29f5ef4:	je     29fc621 <wasm[0]::function[1015]::helper::object_read+0x1b701>
 29f5efa:	mov    0x2e0(%rsp),%r12
 29f5f02:	mov    0x28(%r12),%rax
 29f5f07:	mov    %r15d,%edi
 29f5f0a:	mov    %rdi,%rcx
 29f5f0d:	add    0x20(%r12),%rcx
 29f5f12:	xor    %r9,%r9
 29f5f15:	cmp    %rax,%rdi
 29f5f18:	cmova  %r9,%rcx
 29f5f1c:	mov    0x3c(%rcx),%eax
 29f5f1f:	test   %eax,%eax
 29f5f21:	sete   %al
 29f5f24:	movzbl %al,%r13d
 29f5f28:	jmp    29f611c <wasm[0]::function[1015]::helper::object_read+0x151fc>
 29f5f2d:	xor    %r13d,%r13d
 29f5f30:	jmp    29f611c <wasm[0]::function[1015]::helper::object_read+0x151fc>
 29f5f35:	xor    %eax,%eax
 29f5f37:	test   %r15d,%r15d
 29f5f3a:	je     29f5f91 <wasm[0]::function[1015]::helper::object_read+0x15071>
 29f5f40:	xor    %eax,%eax
 29f5f42:	test   $0x1,%r15d
 29f5f49:	jne    29f5f91 <wasm[0]::function[1015]::helper::object_read+0x15071>
 29f5f4f:	mov    0x2e0(%rsp),%r12
 29f5f57:	mov    0x28(%r12),%rdi
 29f5f5c:	mov    0x20(%r12),%r9
 29f5f61:	mov    %r15d,%r10d
 29f5f64:	lea    0x4(%r9,%r10,1),%r9
 29f5f69:	xor    %r11,%r11
 29f5f6c:	cmp    %rdi,%r10
 29f5f6f:	cmova  %r11,%r9
 29f5f73:	mov    (%r9),%r9d
 29f5f76:	mov    0x190(%rsp),%rax
 29f5f7e:	mov    0x28(%rax),%r10
 29f5f82:	cmp    0x23c(%r10),%r9d
 29f5f89:	sete   %r9b
 29f5f8d:	movzbl %r9b,%eax
 29f5f91:	test   %eax,%eax
 29f5f93:	je     29fc623 <wasm[0]::function[1015]::helper::object_read+0x1b703>
 29f5f99:	test   %r15d,%r15d
 29f5f9c:	je     29fc625 <wasm[0]::function[1015]::helper::object_read+0x1b705>
 29f5fa2:	test   %r15d,%r15d
 29f5fa5:	je     29fc627 <wasm[0]::function[1015]::helper::object_read+0x1b707>
 29f5fab:	mov    0x2e0(%rsp),%r12
 29f5fb3:	mov    0x28(%r12),%rax
 29f5fb8:	mov    0x20(%r12),%rcx
 29f5fbd:	mov    %r15d,%r10d
 29f5fc0:	lea    (%rcx,%r10,1),%r9
 29f5fc4:	xor    %rdi,%rdi
 29f5fc7:	cmp    %rax,%r10
 29f5fca:	cmova  %rdi,%r9
 29f5fce:	mov    0x14(%r9),%r9d
 29f5fd2:	test   %r9d,%r9d
 29f5fd5:	je     29fc629 <wasm[0]::function[1015]::helper::object_read+0x1b709>
 29f5fdb:	test   %r9d,%r9d
 29f5fde:	je     29fc62b <wasm[0]::function[1015]::helper::object_read+0x1b70b>
 29f5fe4:	mov    %r9d,%r9d
 29f5fe7:	lea    0x10(%rcx,%r9,1),%rcx
 29f5fec:	cmp    %rax,%r9
 29f5fef:	cmova  %rdi,%rcx
 29f5ff3:	mov    (%rcx),%eax
 29f5ff5:	test   %eax,%eax
 29f5ff7:	setne  %al
 29f5ffa:	movzbl %al,%r13d
 29f5ffe:	jmp    29f611c <wasm[0]::function[1015]::helper::object_read+0x151fc>
 29f6003:	mov    0x1e8(%rsp),%r10
 29f600b:	movq   %r10,%xmm0
 29f6010:	ucomisd 0x68d8(%rip),%xmm0        # 29fc8f0 <wasm[0]::function[1015]::helper::object_read+0x1b9d0>
 29f6018:	setnp  %al
 29f601b:	sete   %cl
 29f601e:	and    %ecx,%eax
 29f6020:	ucomisd %xmm0,%xmm0
 29f6024:	setp   %cl
 29f6027:	setne  %dil
 29f602b:	or     %edi,%ecx
 29f602d:	or     %ecx,%eax
 29f602f:	movzbl %al,%eax
 29f6032:	test   %eax,%eax
 29f6034:	sete   %al
 29f6037:	movzbl %al,%r13d
 29f603b:	jmp    29f611c <wasm[0]::function[1015]::helper::object_read+0x151fc>
 29f6040:	xor    %eax,%eax
 29f6042:	test   %r15d,%r15d
 29f6045:	je     29f6098 <wasm[0]::function[1015]::helper::object_read+0x15178>
 29f604b:	xor    %eax,%eax
 29f604d:	test   $0x1,%r15d
 29f6054:	jne    29f6098 <wasm[0]::function[1015]::helper::object_read+0x15178>
 29f605a:	mov    0x2e0(%rsp),%r12
 29f6062:	mov    0x28(%r12),%rax
 29f6067:	mov    0x20(%r12),%rcx
 29f606c:	mov    %r15d,%edi
 29f606f:	lea    0x4(%rcx,%rdi,1),%rcx
 29f6074:	xor    %r9,%r9
 29f6077:	cmp    %rax,%rdi
 29f607a:	cmova  %r9,%rcx
 29f607e:	mov    (%rcx),%eax
 29f6080:	mov    0x190(%rsp),%rcx
 29f6088:	mov    0x28(%rcx),%rcx
 29f608c:	cmp    0x234(%rcx),%eax
 29f6092:	sete   %al
 29f6095:	movzbl %al,%eax
 29f6098:	test   %eax,%eax
 29f609a:	je     29fc62d <wasm[0]::function[1015]::helper::object_read+0x1b70d>
 29f60a0:	test   %r15d,%r15d
 29f60a3:	je     29fc62f <wasm[0]::function[1015]::helper::object_read+0x1b70f>
 29f60a9:	test   %r15d,%r15d
 29f60ac:	je     29fc631 <wasm[0]::function[1015]::helper::object_read+0x1b711>
 29f60b2:	mov    0x2e0(%rsp),%r12
 29f60ba:	mov    0x28(%r12),%rax
 29f60bf:	mov    0x20(%r12),%rcx
 29f60c4:	mov    %r15d,%r10d
 29f60c7:	lea    (%rcx,%r10,1),%r9
 29f60cb:	xor    %rdi,%rdi
 29f60ce:	cmp    %rax,%r10
 29f60d1:	cmova  %rdi,%r9
 29f60d5:	mov    0x10(%r9),%r9d
 29f60d9:	test   %r9d,%r9d
 29f60dc:	je     29fc633 <wasm[0]::function[1015]::helper::object_read+0x1b713>
 29f60e2:	test   %r9d,%r9d
 29f60e5:	je     29fc635 <wasm[0]::function[1015]::helper::object_read+0x1b715>
 29f60eb:	mov    %r9d,%r9d
 29f60ee:	lea    0x10(%rcx,%r9,1),%rcx
 29f60f3:	cmp    %rax,%r9
 29f60f6:	cmova  %rdi,%rcx
 29f60fa:	mov    (%rcx),%eax
 29f60fc:	test   %eax,%eax
 29f60fe:	setne  %al
 29f6101:	movzbl %al,%r13d
 29f6105:	jmp    29f611c <wasm[0]::function[1015]::helper::object_read+0x151fc>
 29f610a:	mov    0x1e8(%rsp),%r10
 29f6112:	test   %r10,%r10
 29f6115:	setne  %al
 29f6118:	movzbl %al,%r13d
 29f611c:	cmp    $0x2,%edx
 29f611f:	je     29f6422 <wasm[0]::function[1015]::helper::object_read+0x15502>
 29f6125:	cmp    $0x4,%edx
 29f6128:	je     29f6357 <wasm[0]::function[1015]::helper::object_read+0x15437>
 29f612e:	cmp    $0x3,%edx
 29f6131:	je     29f6323 <wasm[0]::function[1015]::helper::object_read+0x15403>
 29f6137:	cmp    $0xa,%edx
 29f613a:	je     29f6263 <wasm[0]::function[1015]::helper::object_read+0x15343>
 29f6140:	test   %edx,%edx
 29f6142:	sete   %al
 29f6145:	cmp    $0x1,%edx
 29f6148:	sete   %dil
 29f614c:	or     %edi,%eax
 29f614e:	test   %al,%al
 29f6150:	jne    29f625b <wasm[0]::function[1015]::helper::object_read+0x1533b>
 29f6156:	xor    %eax,%eax
 29f6158:	test   %esi,%esi
 29f615a:	je     29f61ac <wasm[0]::function[1015]::helper::object_read+0x1528c>
 29f6160:	xor    %eax,%eax
 29f6162:	test   $0x1,%esi
 29f6168:	jne    29f61ac <wasm[0]::function[1015]::helper::object_read+0x1528c>
 29f616e:	mov    0x2e0(%rsp),%r12
 29f6176:	mov    0x28(%r12),%r11
 29f617b:	mov    0x20(%r12),%rcx
 29f6180:	mov    %esi,%eax
 29f6182:	lea    0x4(%rcx,%rax,1),%r8
 29f6187:	xor    %rcx,%rcx
 29f618a:	cmp    %r11,%rax
 29f618d:	cmova  %rcx,%r8
 29f6191:	mov    (%r8),%eax
 29f6194:	mov    0x190(%rsp),%rcx
 29f619c:	mov    0x28(%rcx),%rcx
 29f61a0:	cmp    0x1d4(%rcx),%eax
 29f61a6:	sete   %al
 29f61a9:	movzbl %al,%eax
 29f61ac:	test   %eax,%eax
 29f61ae:	jne    29f61bb <wasm[0]::function[1015]::helper::object_read+0x1529b>
 29f61b4:	xor    %esi,%esi
 29f61b6:	jmp    29f624d <wasm[0]::function[1015]::helper::object_read+0x1532d>
 29f61bb:	xor    %edi,%edi
 29f61bd:	test   %esi,%esi
 29f61bf:	je     29f6211 <wasm[0]::function[1015]::helper::object_read+0x152f1>
 29f61c5:	xor    %edi,%edi
 29f61c7:	test   $0x1,%esi
 29f61cd:	jne    29f6211 <wasm[0]::function[1015]::helper::object_read+0x152f1>
 29f61d3:	mov    0x2e0(%rsp),%r12
 29f61db:	mov    0x28(%r12),%rax
 29f61e0:	mov    0x20(%r12),%rcx
 29f61e5:	mov    %esi,%edx
 29f61e7:	lea    0x4(%rcx,%rdx,1),%rcx
 29f61ec:	xor    %rdi,%rdi
 29f61ef:	cmp    %rax,%rdx
 29f61f2:	cmova  %rdi,%rcx
 29f61f6:	mov    (%rcx),%eax
 29f61f8:	mov    0x190(%rsp),%rcx
 29f6200:	mov    0x28(%rcx),%rcx
 29f6204:	cmp    0x1d4(%rcx),%eax
 29f620a:	sete   %al
 29f620d:	rex movzbl %al,%edi
 29f6211:	test   %edi,%edi
 29f6213:	je     29fc637 <wasm[0]::function[1015]::helper::object_read+0x1b717>
 29f6219:	test   %esi,%esi
 29f621b:	je     29fc639 <wasm[0]::function[1015]::helper::object_read+0x1b719>
 29f6221:	test   %esi,%esi
 29f6223:	je     29fc63b <wasm[0]::function[1015]::helper::object_read+0x1b71b>
 29f6229:	mov    0x2e0(%rsp),%r12
 29f6231:	mov    0x28(%r12),%rax
 29f6236:	mov    %esi,%edx
 29f6238:	mov    %rdx,%rcx
 29f623b:	add    0x20(%r12),%rcx
 29f6240:	xor    %rsi,%rsi
 29f6243:	cmp    %rax,%rdx
 29f6246:	cmova  %rsi,%rcx
 29f624a:	mov    0x3c(%rcx),%esi
 29f624d:	test   %esi,%esi
 29f624f:	sete   %al
 29f6252:	movzbl %al,%r14d
 29f6256:	jmp    29f6415 <wasm[0]::function[1015]::helper::object_read+0x154f5>
 29f625b:	xor    %r14d,%r14d
 29f625e:	jmp    29f6415 <wasm[0]::function[1015]::helper::object_read+0x154f5>
 29f6263:	xor    %eax,%eax
 29f6265:	test   %esi,%esi
 29f6267:	je     29f62b8 <wasm[0]::function[1015]::helper::object_read+0x15398>
 29f626d:	xor    %eax,%eax
 29f626f:	test   $0x1,%esi
 29f6275:	jne    29f62b8 <wasm[0]::function[1015]::helper::object_read+0x15398>
 29f627b:	mov    0x2e0(%rsp),%r12
 29f6283:	mov    0x28(%r12),%rax
 29f6288:	mov    0x20(%r12),%rcx
 29f628d:	mov    %esi,%edx
 29f628f:	lea    0x4(%rcx,%rdx,1),%rcx
 29f6294:	xor    %rdi,%rdi
 29f6297:	cmp    %rax,%rdx
 29f629a:	cmova  %rdi,%rcx
 29f629e:	mov    (%rcx),%eax
 29f62a0:	mov    0x190(%rsp),%rcx
 29f62a8:	mov    0x28(%rcx),%rcx
 29f62ac:	cmp    0x23c(%rcx),%eax
 29f62b2:	sete   %al
 29f62b5:	movzbl %al,%eax
 29f62b8:	test   %eax,%eax
 29f62ba:	je     29fc63d <wasm[0]::function[1015]::helper::object_read+0x1b71d>
 29f62c0:	test   %esi,%esi
 29f62c2:	je     29fc63f <wasm[0]::function[1015]::helper::object_read+0x1b71f>
 29f62c8:	test   %esi,%esi
 29f62ca:	je     29fc641 <wasm[0]::function[1015]::helper::object_read+0x1b721>
 29f62d0:	mov    0x2e0(%rsp),%r12
 29f62d8:	mov    0x28(%r12),%rax
 29f62dd:	mov    0x20(%r12),%rcx
 29f62e2:	mov    %esi,%edi
 29f62e4:	lea    (%rcx,%rdi,1),%rsi
 29f62e8:	xor    %rdx,%rdx
 29f62eb:	cmp    %rax,%rdi
 29f62ee:	cmova  %rdx,%rsi
 29f62f2:	mov    0x14(%rsi),%esi
 29f62f5:	test   %esi,%esi
 29f62f7:	je     29fc643 <wasm[0]::function[1015]::helper::object_read+0x1b723>
 29f62fd:	test   %esi,%esi
 29f62ff:	je     29fc645 <wasm[0]::function[1015]::helper::object_read+0x1b725>
 29f6305:	mov    %esi,%esi
 29f6307:	lea    0x10(%rcx,%rsi,1),%rcx
 29f630c:	cmp    %rax,%rsi
 29f630f:	cmova  %rdx,%rcx
 29f6313:	mov    (%rcx),%eax
 29f6315:	test   %eax,%eax
 29f6317:	setne  %al
 29f631a:	movzbl %al,%r14d
 29f631e:	jmp    29f6415 <wasm[0]::function[1015]::helper::object_read+0x154f5>
 29f6323:	movq   %r8,%xmm0
 29f6328:	ucomisd 0x65d0(%rip),%xmm0        # 29fc900 <wasm[0]::function[1015]::helper::object_read+0x1b9e0>
 29f6330:	setnp  %al
 29f6333:	sete   %cl
 29f6336:	and    %ecx,%eax
 29f6338:	ucomisd %xmm0,%xmm0
 29f633c:	setp   %cl
 29f633f:	setne  %dl
 29f6342:	or     %edx,%ecx
 29f6344:	or     %ecx,%eax
 29f6346:	movzbl %al,%ecx
 29f6349:	test   %ecx,%ecx
 29f634b:	sete   %dl
 29f634e:	movzbl %dl,%r14d
 29f6352:	jmp    29f6415 <wasm[0]::function[1015]::helper::object_read+0x154f5>
 29f6357:	xor    %eax,%eax
 29f6359:	test   %esi,%esi
 29f635b:	je     29f63af <wasm[0]::function[1015]::helper::object_read+0x1548f>
 29f6361:	xor    %eax,%eax
 29f6363:	test   $0x1,%esi
 29f6369:	jne    29f63af <wasm[0]::function[1015]::helper::object_read+0x1548f>
 29f636f:	mov    0x2e0(%rsp),%r12
 29f6377:	mov    0x28(%r12),%r10
 29f637c:	mov    0x20(%r12),%rax
 29f6381:	mov    %esi,%r11d
 29f6384:	lea    0x4(%rax,%r11,1),%rdi
 29f6389:	xor    %rax,%rax
 29f638c:	cmp    %r10,%r11
 29f638f:	cmova  %rax,%rdi
 29f6393:	mov    (%rdi),%r11d
 29f6396:	mov    0x190(%rsp),%rax
 29f639e:	mov    0x28(%rax),%rax
 29f63a2:	cmp    0x234(%rax),%r11d
 29f63a9:	sete   %al
 29f63ac:	movzbl %al,%eax
 29f63af:	test   %eax,%eax
 29f63b1:	je     29fc647 <wasm[0]::function[1015]::helper::object_read+0x1b727>
 29f63b7:	test   %esi,%esi
 29f63b9:	je     29fc649 <wasm[0]::function[1015]::helper::object_read+0x1b729>
 29f63bf:	test   %esi,%esi
 29f63c1:	je     29fc64b <wasm[0]::function[1015]::helper::object_read+0x1b72b>
 29f63c7:	mov    0x2e0(%rsp),%r12
 29f63cf:	mov    0x28(%r12),%rax
 29f63d4:	mov    0x20(%r12),%rcx
 29f63d9:	mov    %esi,%edi
 29f63db:	lea    (%rcx,%rdi,1),%rsi
 29f63df:	xor    %rdx,%rdx
 29f63e2:	cmp    %rax,%rdi
 29f63e5:	cmova  %rdx,%rsi
 29f63e9:	mov    0x10(%rsi),%esi
 29f63ec:	test   %esi,%esi
 29f63ee:	je     29fc64d <wasm[0]::function[1015]::helper::object_read+0x1b72d>
 29f63f4:	test   %esi,%esi
 29f63f6:	je     29fc64f <wasm[0]::function[1015]::helper::object_read+0x1b72f>
 29f63fc:	mov    %esi,%esi
 29f63fe:	lea    0x10(%rcx,%rsi,1),%rcx
 29f6403:	cmp    %rax,%rsi
 29f6406:	cmova  %rdx,%rcx
 29f640a:	mov    (%rcx),%eax
 29f640c:	test   %eax,%eax
 29f640e:	setne  %al
 29f6411:	movzbl %al,%r14d
 29f6415:	mov    0x270(%rsp),%rcx
 29f641d:	jmp    29f6434 <wasm[0]::function[1015]::helper::object_read+0x15514>
 29f6422:	test   %r8,%r8
 29f6425:	setne  %al
 29f6428:	movzbl %al,%r14d
 29f642c:	mov    0x270(%rsp),%rcx
 29f6434:	mov    0x270(%rsp),%rcx
 29f643c:	mov    (%rcx),%eax
 29f643e:	mov    %eax,%ecx
 29f6440:	lea    0x20(%rcx),%rdx
 29f6444:	mov    0x270(%rsp),%rsi
 29f644c:	mov    0x4(%rsi),%esi
 29f644f:	cmp    %rsi,%rdx
 29f6452:	ja     29fb4ee <wasm[0]::function[1015]::helper::object_read+0x1a5ce>
 29f6458:	lea    0x20(%rax),%edx
 29f645b:	mov    0x270(%rsp),%rsi
 29f6463:	mov    %edx,(%rsi)
 29f6465:	mov    0x2e0(%rsp),%r12
 29f646d:	mov    0x20(%r12),%rdx
 29f6472:	lea    (%rdx,%rcx,1),%r10
 29f6476:	movl   $0xb0000042,(%rdx,%rcx,1)
 29f647d:	mov    0x190(%rsp),%rsi
 29f6485:	mov    0x28(%rsi),%rsi
 29f6489:	mov    0x120(%rsi),%esi
 29f648f:	mov    %esi,0x4(%rdx,%rcx,1)
 29f6493:	mov    0x268(%rsp),%rsi
 29f649b:	mov    %esi,0x8(%rdx,%rcx,1)
 29f649f:	mov    %eax,0xb0(%rsp)
 29f64a6:	mov    0x1f0(%rsp),%rcx
 29f64ae:	mov    %rcx,0x10(%r10)
 29f64b2:	mov    0x1f8(%rsp),%rcx
 29f64ba:	mov    %ecx,0x18(%r10)
 29f64be:	mov    0xa8(%rsp),%eax
 29f64c5:	mov    %eax,0x1c(%r10)
 29f64c9:	mov    0x270(%rsp),%rcx
 29f64d1:	mov    (%rcx),%eax
 29f64d3:	mov    %eax,%edx
 29f64d5:	lea    0x20(%rdx),%rcx
 29f64d9:	mov    0x270(%rsp),%rsi
 29f64e1:	mov    0x4(%rsi),%esi
 29f64e4:	cmp    %rsi,%rcx
 29f64e7:	ja     29fb52a <wasm[0]::function[1015]::helper::object_read+0x1a60a>
 29f64ed:	lea    0x20(%rax),%ecx
 29f64f0:	mov    0x270(%rsp),%rsi
 29f64f8:	mov    %ecx,(%rsi)
 29f64fa:	mov    0x2e0(%rsp),%r12
 29f6502:	mov    0x20(%r12),%rsi
 29f6507:	lea    (%rsi,%rdx,1),%rcx
 29f650b:	movl   $0xb0000042,(%rsi,%rdx,1)
 29f6512:	mov    0x190(%rsp),%rdi
 29f651a:	mov    0x28(%rdi),%rdi
 29f651e:	mov    0x120(%rdi),%edi
 29f6524:	mov    %edi,0x4(%rsi,%rdx,1)
 29f6528:	mov    0x268(%rsp),%rdi
 29f6530:	mov    %edi,0x8(%rsi,%rdx,1)
 29f6534:	mov    %eax,0xa8(%rsp)
 29f653b:	mov    0x200(%rsp),%rax
 29f6543:	mov    %rax,0x10(%rcx)
 29f6547:	mov    0x208(%rsp),%rsi
 29f654f:	mov    %esi,0x18(%rcx)
 29f6552:	mov    0xc8(%rsp),%eax
 29f6559:	mov    %eax,0x1c(%rcx)
 29f655c:	mov    0x270(%rsp),%rcx
 29f6564:	mov    (%rcx),%eax
 29f6566:	mov    %eax,%ecx
 29f6568:	lea    0x20(%rcx),%rdx
 29f656c:	mov    0x270(%rsp),%rsi
 29f6574:	mov    0x4(%rsi),%esi
 29f6577:	cmp    %rsi,%rdx
 29f657a:	ja     29fb56d <wasm[0]::function[1015]::helper::object_read+0x1a64d>
 29f6580:	lea    0x20(%rax),%edx
 29f6583:	mov    0x270(%rsp),%rsi
 29f658b:	mov    %edx,(%rsi)
 29f658d:	mov    0x2e0(%rsp),%r12
 29f6595:	mov    0x20(%r12),%rdx
 29f659a:	lea    (%rdx,%rcx,1),%r11
 29f659e:	movl   $0xb0000042,(%rdx,%rcx,1)
 29f65a5:	mov    0x190(%rsp),%rsi
 29f65ad:	mov    0x28(%rsi),%rsi
 29f65b1:	mov    0x120(%rsi),%esi
 29f65b7:	mov    %esi,0x4(%rdx,%rcx,1)
 29f65bb:	mov    0x268(%rsp),%rsi
 29f65c3:	mov    %esi,0x8(%rdx,%rcx,1)
 29f65c7:	mov    %eax,0xc8(%rsp)
 29f65ce:	mov    0x210(%rsp),%r10
 29f65d6:	mov    %r10,0x10(%r11)
 29f65da:	mov    0x218(%rsp),%rsi
 29f65e2:	mov    %esi,0x18(%r11)
 29f65e6:	mov    0xb8(%rsp),%edx
 29f65ed:	mov    %edx,0x1c(%r11)
 29f65f1:	mov    0x220(%rsp),%rcx
 29f65f9:	mov    0x220(%rsp),%rdx
 29f6601:	test   %edx,%ecx
 29f6603:	jne    29f66f0 <wasm[0]::function[1015]::helper::object_read+0x157d0>
 29f6609:	mov    0xb0(%rsp),%esi
 29f6610:	test   %esi,%esi
 29f6612:	je     29fc651 <wasm[0]::function[1015]::helper::object_read+0x1b731>
 29f6618:	mov    0xa8(%rsp),%edi
 29f661f:	test   %edi,%edi
 29f6621:	je     29fc653 <wasm[0]::function[1015]::helper::object_read+0x1b733>
 29f6627:	test   %eax,%eax
 29f6629:	je     29fc655 <wasm[0]::function[1015]::helper::object_read+0x1b735>
 29f662f:	mov    0x270(%rsp),%rcx
 29f6637:	mov    (%rcx),%eax
 29f6639:	mov    %rax,%r15
 29f663c:	mov    %eax,%r11d
 29f663f:	lea    0x20(%r11),%rax
 29f6643:	mov    0x4(%rcx),%ecx
 29f6646:	cmp    %rcx,%rax
 29f6649:	ja     29fb5a9 <wasm[0]::function[1015]::helper::object_read+0x1a689>
 29f664f:	mov    %r15,%rax
 29f6652:	add    $0x20,%eax
 29f6658:	mov    0x270(%rsp),%rcx
 29f6660:	mov    %eax,(%rcx)
 29f6662:	mov    0x2e0(%rsp),%r12
 29f666a:	mov    0x20(%r12),%rcx
 29f666f:	lea    (%rcx,%r11,1),%rax
 29f6673:	movl   $0xb0000072,(%rcx,%r11,1)
 29f667b:	mov    0x190(%rsp),%rsi
 29f6683:	mov    0x28(%rsi),%rdx
 29f6687:	mov    0x13c(%rdx),%edx
 29f668d:	mov    %edx,0x4(%rcx,%r11,1)
 29f6692:	mov    0x268(%rsp),%rdx
 29f669a:	mov    %edx,0x8(%rcx,%r11,1)
 29f669f:	test   %ebx,%ebx
 29f66a1:	setne  %cl
 29f66a4:	movzbl %cl,%r11d
 29f66a8:	shl    $0x2,%r11d
 29f66ac:	test   %r13d,%r13d
 29f66af:	setne  %cl
 29f66b2:	movzbl %cl,%ecx
 29f66b5:	shl    $0x3,%ecx
 29f66b8:	or     %ecx,%r11d
 29f66bb:	test   %r14d,%r14d
 29f66be:	setne  %cl
 29f66c1:	movzbl %cl,%ecx
 29f66c4:	shl    $1,%ecx
 29f66c6:	or     %ecx,%r11d
 29f66c9:	mov    %r11d,0x10(%rax)
 29f66cd:	mov    0xb0(%rsp),%ecx
 29f66d4:	mov    %ecx,0x14(%rax)
 29f66d7:	mov    0xa8(%rsp),%ecx
 29f66de:	mov    %ecx,0x18(%rax)
 29f66e1:	mov    0xc8(%rsp),%ecx
 29f66e8:	mov    %ecx,0x1c(%rax)
 29f66eb:	jmp    29f67c7 <wasm[0]::function[1015]::helper::object_read+0x158a7>
 29f66f0:	mov    0xb0(%rsp),%ecx
 29f66f7:	test   %ecx,%ecx
 29f66f9:	je     29fc657 <wasm[0]::function[1015]::helper::object_read+0x1b737>
 29f66ff:	mov    0xa8(%rsp),%ecx
 29f6706:	test   %ecx,%ecx
 29f6708:	je     29fc659 <wasm[0]::function[1015]::helper::object_read+0x1b739>
 29f670e:	test   %eax,%eax
 29f6710:	je     29fc65b <wasm[0]::function[1015]::helper::object_read+0x1b73b>
 29f6716:	mov    0x270(%rsp),%rcx
 29f671e:	mov    (%rcx),%eax
 29f6720:	mov    %rax,%r15
 29f6723:	mov    %eax,%ecx
 29f6725:	lea    0x20(%rcx),%rax
 29f6729:	mov    0x270(%rsp),%rdx
 29f6731:	mov    0x4(%rdx),%edx
 29f6734:	cmp    %rdx,%rax
 29f6737:	ja     29fb5ef <wasm[0]::function[1015]::helper::object_read+0x1a6cf>
 29f673d:	mov    %r15,%rax
 29f6740:	add    $0x20,%eax
 29f6746:	mov    0x270(%rsp),%rdx
 29f674e:	mov    %eax,(%rdx)
 29f6750:	mov    0x2e0(%rsp),%r12
 29f6758:	mov    0x20(%r12),%rdx
 29f675d:	lea    (%rdx,%rcx,1),%rax
 29f6761:	movl   $0xb0000072,(%rdx,%rcx,1)
 29f6768:	mov    0x190(%rsp),%rsi
 29f6770:	mov    0x28(%rsi),%rsi
 29f6774:	mov    0x13c(%rsi),%esi
 29f677a:	mov    %esi,0x4(%rdx,%rcx,1)
 29f677e:	mov    0x268(%rsp),%rsi
 29f6786:	mov    %esi,0x8(%rdx,%rcx,1)
 29f678a:	test   %r13d,%r13d
 29f678d:	setne  %cl
 29f6790:	movzbl %cl,%ecx
 29f6793:	shl    $0x3,%ecx
 29f6796:	or     $0x1,%ecx
 29f6799:	test   %r14d,%r14d
 29f679c:	setne  %dl
 29f679f:	movzbl %dl,%edx
 29f67a2:	shl    $1,%edx
 29f67a4:	or     %edx,%ecx
 29f67a6:	mov    %ecx,0x10(%rax)
 29f67a9:	mov    0xb0(%rsp),%ecx
 29f67b0:	mov    %ecx,0x14(%rax)
 29f67b3:	mov    0xa8(%rsp),%ecx
 29f67ba:	mov    %ecx,0x18(%rax)
 29f67bd:	mov    0xc8(%rsp),%ecx
 29f67c4:	mov    %ecx,0x1c(%rax)
 29f67c7:	mov    0x88(%rsp),%eax
 29f67ce:	mov    0x78(%rsp),%ecx
 29f67d2:	jmp    29f8fba <wasm[0]::function[1015]::helper::object_read+0x1809a>
 29f67d7:	mov    0xe0(%rsp),%edx
 29f67de:	mov    0x258(%rsp),%rax
 29f67e6:	mov    0x260(%rsp),%rcx
 29f67ee:	mov    0x2f0(%rsp),%rbx
 29f67f6:	mov    0x2f8(%rsp),%r12
 29f67fe:	mov    0x300(%rsp),%r13
 29f6806:	mov    0x308(%rsp),%r14
 29f680e:	mov    0x310(%rsp),%r15
 29f6816:	add    $0x320,%rsp
 29f681d:	mov    %rbp,%rsp
 29f6820:	pop    %rbp
 29f6821:	ret    $0x40
 29f6824:	xor    %r9d,%r9d
 29f6827:	test   %edx,%edx
 29f6829:	je     29f687c <wasm[0]::function[1015]::helper::object_read+0x1595c>
 29f682f:	xor    %r9d,%r9d
 29f6832:	test   $0x1,%edx
 29f6838:	jne    29f687c <wasm[0]::function[1015]::helper::object_read+0x1595c>
 29f683e:	mov    0x2e0(%rsp),%r12
 29f6846:	mov    0x28(%r12),%rax
 29f684b:	mov    0x20(%r12),%rcx
 29f6850:	mov    %edx,%esi
 29f6852:	lea    0x4(%rcx,%rsi,1),%rcx
 29f6857:	xor    %rdi,%rdi
 29f685a:	cmp    %rax,%rsi
 29f685d:	cmova  %rdi,%rcx
 29f6861:	mov    (%rcx),%eax
 29f6863:	mov    0x190(%rsp),%rsi
 29f686b:	mov    0x28(%rsi),%rcx
 29f686f:	cmp    0x254(%rcx),%eax
 29f6875:	sete   %al
 29f6878:	movzbl %al,%r9d
 29f687c:	test   %r9d,%r9d
 29f687f:	je     29fc65d <wasm[0]::function[1015]::helper::object_read+0x1b73d>
 29f6885:	test   %edx,%edx
 29f6887:	je     29fc65f <wasm[0]::function[1015]::helper::object_read+0x1b73f>
 29f688d:	test   %edx,%edx
 29f688f:	je     29fc661 <wasm[0]::function[1015]::helper::object_read+0x1b741>
 29f6895:	mov    0x2e0(%rsp),%r12
 29f689d:	mov    0x28(%r12),%rsi
 29f68a2:	mov    0x20(%r12),%r8
 29f68a7:	mov    %edx,%edi
 29f68a9:	lea    (%r8,%rdi,1),%rax
 29f68ad:	xor    %r8,%r8
 29f68b0:	cmp    %rsi,%rdi
 29f68b3:	cmova  %r8,%rax
 29f68b7:	mov    0x10(%rax),%edx
 29f68ba:	test   %edx,%edx
 29f68bc:	je     29fc663 <wasm[0]::function[1015]::helper::object_read+0x1b743>
 29f68c2:	mov    0x68(%rsp),%r9d
 29f68c7:	mov    0x1b8(%rsp),%rcx
 29f68cf:	mov    0x190(%rsp),%rsi
 29f68d7:	mov    0x190(%rsp),%rdi
 29f68df:	mov    0x1c0(%rsp),%r8
 29f68e7:	call   29ffc00 <wasm[0]::function[1019]::helper::ordinary_own_descriptor>
 29f68ec:	mov    0x80(%rsp),%ecx
 29f68f3:	mov    0xa0(%rsp),%edx
 29f68fa:	mov    %rdx,%r15
 29f68fd:	mov    0x50(%rsp),%edx
 29f6901:	test   %eax,%eax
 29f6903:	jne    29f889d <wasm[0]::function[1015]::helper::object_read+0x1797d>
 29f6909:	mov    0x58(%rsp),%edi
 29f690d:	mov    0x68(%rsp),%r8d
 29f6912:	xor    %r9d,%r9d
 29f6915:	mov    0x1b8(%rsp),%rsi
 29f691d:	cmp    $0x4,%esi
 29f6920:	je     29f692e <wasm[0]::function[1015]::helper::object_read+0x15a0e>
 29f6926:	mov    %r9,%rsi
 29f6929:	jmp    29f6c9c <wasm[0]::function[1015]::helper::object_read+0x15d7c>
 29f692e:	xor    %esi,%esi
 29f6930:	test   %r8d,%r8d
 29f6933:	je     29f698a <wasm[0]::function[1015]::helper::object_read+0x15a6a>
 29f6939:	xor    %esi,%esi
 29f693b:	test   $0x1,%r8d
 29f6942:	jne    29f698a <wasm[0]::function[1015]::helper::object_read+0x15a6a>
 29f6948:	mov    0x2e0(%rsp),%r12
 29f6950:	mov    0x28(%r12),%rsi
 29f6955:	mov    0x20(%r12),%r9
 29f695a:	mov    %r8d,%r10d
 29f695d:	lea    0x4(%r9,%r10,1),%r9
 29f6962:	xor    %r11,%r11
 29f6965:	cmp    %rsi,%r10
 29f6968:	cmova  %r11,%r9
 29f696c:	mov    (%r9),%esi
 29f696f:	mov    0x190(%rsp),%r9
 29f6977:	mov    0x28(%r9),%r9
 29f697b:	cmp    0x234(%r9),%esi
 29f6982:	sete   %sil
 29f6986:	movzbl %sil,%esi
 29f698a:	test   %esi,%esi
 29f698c:	je     29fc665 <wasm[0]::function[1015]::helper::object_read+0x1b745>
 29f6992:	test   %r8d,%r8d
 29f6995:	je     29fc667 <wasm[0]::function[1015]::helper::object_read+0x1b747>
 29f699b:	test   %r8d,%r8d
 29f699e:	je     29fc669 <wasm[0]::function[1015]::helper::object_read+0x1b749>
 29f69a4:	mov    0x2e0(%rsp),%r12
 29f69ac:	mov    0x28(%r12),%rsi
 29f69b1:	mov    0x20(%r12),%r10
 29f69b6:	mov    %r8d,%ebx
 29f69b9:	lea    (%r10,%rbx,1),%r9
 29f69bd:	xor    %r11,%r11
 29f69c0:	cmp    %rsi,%rbx
 29f69c3:	cmova  %r11,%r9
 29f69c7:	mov    0x10(%r9),%ebx
 29f69cb:	mov    %ebx,0xe0(%rsp)
 29f69d2:	xor    %r9d,%r9d
 29f69d5:	test   %ebx,%ebx
 29f69d7:	je     29fc66b <wasm[0]::function[1015]::helper::object_read+0x1b74b>
 29f69dd:	test   %ebx,%ebx
 29f69df:	je     29fc66d <wasm[0]::function[1015]::helper::object_read+0x1b74d>
 29f69e5:	mov    %ebx,%ebx
 29f69e7:	lea    0x10(%r10,%rbx,1),%r10
 29f69ec:	cmp    %rsi,%rbx
 29f69ef:	cmova  %r11,%r10
 29f69f3:	mov    (%r10),%ebx
 29f69f6:	test   %ebx,%ebx
 29f69f8:	sete   %sil
 29f69fc:	cmp    $0xa,%ebx
 29f69ff:	seta   %r10b
 29f6a03:	or     %r10d,%esi
 29f6a06:	test   %sil,%sil
 29f6a09:	je     29f6a17 <wasm[0]::function[1015]::helper::object_read+0x15af7>
 29f6a0f:	mov    %r9,%rsi
 29f6a12:	jmp    29f6c9c <wasm[0]::function[1015]::helper::object_read+0x15d7c>
 29f6a17:	mov    0xe0(%rsp),%ecx
 29f6a1e:	test   %ecx,%ecx
 29f6a20:	je     29fc66f <wasm[0]::function[1015]::helper::object_read+0x1b74f>
 29f6a26:	test   %ecx,%ecx
 29f6a28:	je     29fc671 <wasm[0]::function[1015]::helper::object_read+0x1b751>
 29f6a2e:	mov    0x2e0(%rsp),%r12
 29f6a36:	mov    0x28(%r12),%rdx
 29f6a3b:	mov    0x20(%r12),%rsi
 29f6a40:	mov    %ecx,%r9d
 29f6a43:	lea    0x10(%rsi,%r9,1),%r8
 29f6a48:	xor    %rdi,%rdi
 29f6a4b:	cmp    %rdx,%r9
 29f6a4e:	cmova  %rdi,%r8
 29f6a52:	mov    (%r8),%r8d
 29f6a55:	test   %r8d,%r8d
 29f6a58:	je     29fc673 <wasm[0]::function[1015]::helper::object_read+0x1b753>
 29f6a5e:	mov    %r8d,%r9d
 29f6a61:	shl    $1,%r9
 29f6a64:	shr    $0x20,%r9
 29f6a68:	test   %r9,%r9
 29f6a6b:	jne    29fc675 <wasm[0]::function[1015]::helper::object_read+0x1b755>
 29f6a71:	add    %r8d,%r8d
 29f6a74:	add    $0x14,%r8d
 29f6a78:	jb     29fc677 <wasm[0]::function[1015]::helper::object_read+0x1b757>
 29f6a7e:	add    %r8d,%ecx
 29f6a81:	jb     29fc679 <wasm[0]::function[1015]::helper::object_read+0x1b759>
 29f6a87:	mov    %ecx,%r9d
 29f6a8a:	lea    (%rsi,%r9,1),%rcx
 29f6a8e:	cmp    %rdx,%r9
 29f6a91:	cmova  %rdi,%rcx
 29f6a95:	sub    $0x14,%r8d
 29f6a99:	sub    %r8,%rcx
 29f6a9c:	movzwl (%rcx),%ecx
 29f6a9f:	cmp    $0x30,%ecx
 29f6aa2:	je     29f6c71 <wasm[0]::function[1015]::helper::object_read+0x15d51>
 29f6aa8:	mov    0x58(%rsp),%edi
 29f6aac:	mov    0x68(%rsp),%r8d
 29f6ab1:	mov    0x80(%rsp),%ecx
 29f6ab8:	mov    0xa0(%rsp),%esi
 29f6abf:	mov    %rsi,%r15
 29f6ac2:	mov    0x50(%rsp),%edx
 29f6ac6:	xor    %r14d,%r14d
 29f6ac9:	xor    %r13,%r13
 29f6acc:	mov    %edi,0xb8(%rsp)
 29f6ad3:	mov    %r8d,0xb0(%rsp)
 29f6adb:	mov    %eax,0xa8(%rsp)
 29f6ae2:	mov    %ecx,0xc8(%rsp)
 29f6ae9:	mov    %r15,%rax
 29f6aec:	mov    %eax,0x78(%rsp)
 29f6af0:	mov    %edx,0x88(%rsp)
 29f6af7:	mov    0x2e8(%rsp),%rax
 29f6aff:	mov    (%rax),%rax
 29f6b02:	mov    0x228(%rsp),%rcx
 29f6b0a:	cmp    %rcx,%rax
 29f6b0d:	jae    29fb635 <wasm[0]::function[1015]::helper::object_read+0x1a715>
 29f6b13:	jmp    29f6b20 <wasm[0]::function[1015]::helper::object_read+0x15c00>
 29f6b18:	mov    %rcx,0x228(%rsp)
 29f6b20:	mov    0xe0(%rsp),%eax
 29f6b27:	xor    %r9d,%r9d
 29f6b2a:	test   %eax,%eax
 29f6b2c:	je     29fc67b <wasm[0]::function[1015]::helper::object_read+0x1b75b>
 29f6b32:	test   %eax,%eax
 29f6b34:	je     29fc67d <wasm[0]::function[1015]::helper::object_read+0x1b75d>
 29f6b3a:	mov    0x2e0(%rsp),%r12
 29f6b42:	mov    0x28(%r12),%r8
 29f6b47:	mov    0x20(%r12),%r10
 29f6b4c:	mov    %eax,%ecx
 29f6b4e:	lea    0x10(%r10,%rcx,1),%rsi
 29f6b53:	xor    %r11,%r11
 29f6b56:	cmp    %r8,%rcx
 29f6b59:	cmova  %r11,%rsi
 29f6b5d:	mov    (%rsi),%ecx
 29f6b5f:	cmp    %ecx,%r14d
 29f6b62:	jae    29fc67f <wasm[0]::function[1015]::helper::object_read+0x1b75f>
 29f6b68:	mov    %ecx,%edx
 29f6b6a:	shl    $1,%rdx
 29f6b6d:	shr    $0x20,%rdx
 29f6b71:	test   %rdx,%rdx
 29f6b74:	jne    29fc681 <wasm[0]::function[1015]::helper::object_read+0x1b761>
 29f6b7a:	lea    (%rcx,%rcx,1),%esi
 29f6b7d:	add    $0x14,%esi
 29f6b80:	jb     29fc683 <wasm[0]::function[1015]::helper::object_read+0x1b763>
 29f6b86:	add    %esi,%eax
 29f6b88:	jb     29fc685 <wasm[0]::function[1015]::helper::object_read+0x1b765>
 29f6b8e:	mov    %eax,%ecx
 29f6b90:	lea    (%r10,%rcx,1),%rax
 29f6b94:	cmp    %r8,%rcx
 29f6b97:	cmova  %r11,%rax
 29f6b9b:	lea    0x14(%r14,%r14,1),%ecx
 29f6ba0:	sub    %ecx,%esi
 29f6ba2:	sub    %rsi,%rax
 29f6ba5:	movzwq (%rax),%rsi
 29f6ba9:	mov    0xb8(%rsp),%edi
 29f6bb0:	mov    0xb0(%rsp),%r8d
 29f6bb8:	mov    0xa8(%rsp),%eax
 29f6bbf:	mov    0xc8(%rsp),%ecx
 29f6bc6:	mov    0x78(%rsp),%r10d
 29f6bcb:	mov    %r10,%r15
 29f6bce:	mov    0x88(%rsp),%edx
 29f6bd5:	movzwl %si,%esi
 29f6bd8:	mov    %rsi,%r10
 29f6bdb:	sub    $0x30,%r10d
 29f6bdf:	cmp    $0x9,%r10d
 29f6be3:	jbe    29f6bf1 <wasm[0]::function[1015]::helper::object_read+0x15cd1>
 29f6be9:	mov    %r9,%rsi
 29f6bec:	jmp    29f6c9c <wasm[0]::function[1015]::helper::object_read+0x15d7c>
 29f6bf1:	mov    0xb8(%rsp),%edi
 29f6bf8:	mov    0xb0(%rsp),%r8d
 29f6c00:	mov    0xa8(%rsp),%eax
 29f6c07:	mov    0xc8(%rsp),%ecx
 29f6c0e:	mov    0x78(%rsp),%edx
 29f6c12:	mov    %rdx,%r15
 29f6c15:	mov    0x88(%rsp),%edx
 29f6c1c:	add    $0x1,%r14d
 29f6c23:	imul   $0xa,%r13,%r9
 29f6c27:	mov    %rsi,%r10
 29f6c2a:	sub    $0x30,%r10d
 29f6c2e:	add    %r9,%r10
 29f6c31:	cmp    %ebx,%r14d
 29f6c34:	jae    29f6c42 <wasm[0]::function[1015]::helper::object_read+0x15d22>
 29f6c3a:	mov    %r10,%r13
 29f6c3d:	jmp    29f6acc <wasm[0]::function[1015]::helper::object_read+0x15bac>
 29f6c42:	xor    %r9d,%r9d
 29f6c45:	cmp    0x5c5c(%rip),%r10        # 29fc8a8 <wasm[0]::function[1015]::helper::object_read+0x1b988>
 29f6c4c:	jb     29f6c5a <wasm[0]::function[1015]::helper::object_read+0x15d3a>
 29f6c52:	mov    %r9,%rsi
 29f6c55:	jmp    29f6c9c <wasm[0]::function[1015]::helper::object_read+0x15d7c>
 29f6c5a:	imul   $0xa,%r13d,%r9d
 29f6c5e:	sub    $0x30,%esi
 29f6c61:	add    %r9d,%esi
 29f6c64:	mov    0x278(%rsp),%r9
 29f6c6c:	jmp    29f6c9c <wasm[0]::function[1015]::helper::object_read+0x15d7c>
 29f6c71:	mov    0x58(%rsp),%edi
 29f6c75:	mov    0x68(%rsp),%r8d
 29f6c7a:	mov    0x80(%rsp),%ecx
 29f6c81:	mov    0xa0(%rsp),%edx
 29f6c88:	mov    %rdx,%r15
 29f6c8b:	mov    0x50(%rsp),%edx
 29f6c8f:	cmp    $0x1,%ebx
 29f6c92:	sete   %sil
 29f6c96:	movzbl %sil,%r9d
 29f6c9a:	xor    %esi,%esi
 29f6c9c:	mov    %edi,0x88(%rsp)
 29f6ca3:	mov    %r8d,0x78(%rsp)
 29f6ca8:	mov    %eax,0xc8(%rsp)
 29f6caf:	mov    %ecx,0xa8(%rsp)
 29f6cb6:	mov    %r15,%rax
 29f6cb9:	mov    %eax,0xb0(%rsp)
 29f6cc0:	mov    %edx,0xb8(%rsp)
 29f6cc7:	test   %r9d,%r9d
 29f6cca:	jne    29f7585 <wasm[0]::function[1015]::helper::object_read+0x16665>
 29f6cd0:	mov    $0x8c,%edx
 29f6cd5:	mov    0x190(%rsp),%rsi
 29f6cdd:	mov    0x190(%rsp),%rdi
 29f6ce5:	call   2f307a0 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 29f6cea:	test   %eax,%eax
 29f6cec:	je     29fc687 <wasm[0]::function[1015]::helper::object_read+0x1b767>
 29f6cf2:	mov    0x1b8(%rsp),%rcx
 29f6cfa:	cmp    $0x4,%ecx
 29f6cfd:	je     29f6d36 <wasm[0]::function[1015]::helper::object_read+0x15e16>
 29f6d03:	mov    0x88(%rsp),%ecx
 29f6d0a:	mov    0xc8(%rsp),%eax
 29f6d11:	mov    %rax,%r8
 29f6d14:	mov    0xa8(%rsp),%edx
 29f6d1b:	mov    0xb0(%rsp),%esi
 29f6d22:	mov    0xb8(%rsp),%edi
 29f6d29:	xor    %eax,%eax
 29f6d2b:	mov    %rax,%r14
 29f6d2e:	mov    %r8,%rax
 29f6d31:	jmp    29f735b <wasm[0]::function[1015]::helper::object_read+0x1643b>
 29f6d36:	mov    0x1b8(%rsp),%rcx
 29f6d3e:	cmp    $0x3,%ecx
 29f6d41:	je     29f72e9 <wasm[0]::function[1015]::helper::object_read+0x163c9>
 29f6d47:	mov    0x1b8(%rsp),%rcx
 29f6d4f:	cmp    $0x4,%ecx
 29f6d52:	je     29f71ae <wasm[0]::function[1015]::helper::object_read+0x1628e>
 29f6d58:	mov    0x1b8(%rsp),%rcx
 29f6d60:	cmp    $0xa,%ecx
 29f6d63:	je     29f6e04 <wasm[0]::function[1015]::helper::object_read+0x15ee4>
 29f6d69:	mov    0x1b8(%rsp),%rcx
 29f6d71:	mov    0x1b8(%rsp),%rdx
 29f6d79:	test   %edx,%ecx
 29f6d7b:	sete   %cl
 29f6d7e:	cmp    $0x1,%edx
 29f6d81:	sete   %dl
 29f6d84:	or     %edx,%ecx
 29f6d86:	test   %cl,%cl
 29f6d88:	jne    29f6dd4 <wasm[0]::function[1015]::helper::object_read+0x15eb4>
 29f6d8e:	mov    0x1b8(%rsp),%rcx
 29f6d96:	cmp    $0x2,%ecx
 29f6d99:	je     29f6db3 <wasm[0]::function[1015]::helper::object_read+0x15e93>
 29f6d9f:	mov    0x78(%rsp),%ecx
 29f6da3:	cmp    %eax,%ecx
 29f6da5:	sete   %al
 29f6da8:	movzbl %al,%eax
 29f6dab:	mov    %rax,%r14
 29f6dae:	jmp    29f6ddc <wasm[0]::function[1015]::helper::object_read+0x15ebc>
 29f6db3:	mov    0x1c0(%rsp),%rsi
 29f6dbb:	mov    0x1c0(%rsp),%r8
 29f6dc3:	test   %rsi,%r8
 29f6dc6:	sete   %al
 29f6dc9:	movzbl %al,%eax
 29f6dcc:	mov    %rax,%r14
 29f6dcf:	jmp    29f6ddc <wasm[0]::function[1015]::helper::object_read+0x15ebc>
 29f6dd4:	mov    0x278(%rsp),%r14
 29f6ddc:	mov    0x88(%rsp),%ecx
 29f6de3:	mov    0xc8(%rsp),%eax
 29f6dea:	mov    0xa8(%rsp),%edx
 29f6df1:	mov    0xb0(%rsp),%esi
 29f6df8:	mov    0xb8(%rsp),%edi
 29f6dff:	jmp    29f735b <wasm[0]::function[1015]::helper::object_read+0x1643b>
 29f6e04:	mov    0x78(%rsp),%edx
 29f6e08:	xor    %ecx,%ecx
 29f6e0a:	test   %edx,%edx
 29f6e0c:	je     29f6e61 <wasm[0]::function[1015]::helper::object_read+0x15f41>
 29f6e12:	xor    %ecx,%ecx
 29f6e14:	test   $0x1,%edx
 29f6e1a:	jne    29f6e61 <wasm[0]::function[1015]::helper::object_read+0x15f41>
 29f6e20:	mov    0x2e0(%rsp),%r12
 29f6e28:	mov    0x28(%r12),%rsi
 29f6e2d:	mov    0x20(%r12),%rdi
 29f6e32:	mov    %edx,%r8d
 29f6e35:	lea    0x4(%rdi,%r8,1),%rdi
 29f6e3a:	xor    %r9,%r9
 29f6e3d:	cmp    %rsi,%r8
 29f6e40:	cmova  %r9,%rdi
 29f6e44:	mov    (%rdi),%edi
 29f6e46:	mov    0x190(%rsp),%rsi
 29f6e4e:	mov    0x28(%rsi),%r8
 29f6e52:	cmp    0x23c(%r8),%edi
 29f6e59:	sete   %r8b
 29f6e5d:	movzbl %r8b,%ecx
 29f6e61:	test   %ecx,%ecx
 29f6e63:	je     29fc689 <wasm[0]::function[1015]::helper::object_read+0x1b769>
 29f6e69:	xor    %ecx,%ecx
 29f6e6b:	test   %eax,%eax
 29f6e6d:	je     29f6ebd <wasm[0]::function[1015]::helper::object_read+0x15f9d>
 29f6e73:	xor    %ecx,%ecx
 29f6e75:	test   $0x1,%eax
 29f6e7a:	jne    29f6ebd <wasm[0]::function[1015]::helper::object_read+0x15f9d>
 29f6e80:	mov    0x2e0(%rsp),%r12
 29f6e88:	mov    0x28(%r12),%rcx
 29f6e8d:	mov    0x20(%r12),%rdx
 29f6e92:	mov    %eax,%esi
 29f6e94:	lea    0x4(%rdx,%rsi,1),%rdx
 29f6e99:	xor    %rdi,%rdi
 29f6e9c:	cmp    %rcx,%rsi
 29f6e9f:	cmova  %rdi,%rdx
 29f6ea3:	mov    (%rdx),%ecx
 29f6ea5:	mov    0x190(%rsp),%rsi
 29f6ead:	mov    0x28(%rsi),%rdx
 29f6eb1:	cmp    0x23c(%rdx),%ecx
 29f6eb7:	sete   %cl
 29f6eba:	movzbl %cl,%ecx
 29f6ebd:	test   %ecx,%ecx
 29f6ebf:	je     29fc68b <wasm[0]::function[1015]::helper::object_read+0x1b76b>
 29f6ec5:	mov    0x78(%rsp),%esi
 29f6ec9:	test   %esi,%esi
 29f6ecb:	je     29fc68d <wasm[0]::function[1015]::helper::object_read+0x1b76d>
 29f6ed1:	test   %esi,%esi
 29f6ed3:	je     29fc68f <wasm[0]::function[1015]::helper::object_read+0x1b76f>
 29f6ed9:	mov    0x2e0(%rsp),%r12
 29f6ee1:	mov    0x28(%r12),%rcx
 29f6ee6:	mov    0x20(%r12),%rdx
 29f6eeb:	mov    %esi,%r8d
 29f6eee:	lea    (%rdx,%r8,1),%rdi
 29f6ef2:	xor    %rsi,%rsi
 29f6ef5:	cmp    %rcx,%r8
 29f6ef8:	cmova  %rsi,%rdi
 29f6efc:	mov    0x10(%rdi),%r8d
 29f6f00:	test   %eax,%eax
 29f6f02:	je     29fc691 <wasm[0]::function[1015]::helper::object_read+0x1b771>
 29f6f08:	mov    %eax,%r9d
 29f6f0b:	lea    (%rdx,%r9,1),%rax
 29f6f0f:	cmp    %rcx,%r9
 29f6f12:	cmova  %rsi,%rax
 29f6f16:	mov    0x10(%rax),%r9d
 29f6f1a:	mov    0x14(%rdi),%edi
 29f6f1d:	mov    %edi,0xe0(%rsp)
 29f6f24:	mov    0x14(%rax),%eax
 29f6f27:	mov    %eax,0xe8(%rsp)
 29f6f2e:	test   %edi,%edi
 29f6f30:	je     29fc693 <wasm[0]::function[1015]::helper::object_read+0x1b773>
 29f6f36:	test   %edi,%edi
 29f6f38:	je     29fc695 <wasm[0]::function[1015]::helper::object_read+0x1b775>
 29f6f3e:	mov    %edi,%r10d
 29f6f41:	lea    0x10(%rdx,%r10,1),%rdi
 29f6f46:	cmp    %rcx,%r10
 29f6f49:	cmova  %rsi,%rdi
 29f6f4d:	mov    (%rdi),%ebx
 29f6f4f:	test   %eax,%eax
 29f6f51:	je     29fc697 <wasm[0]::function[1015]::helper::object_read+0x1b777>
 29f6f57:	test   %eax,%eax
 29f6f59:	je     29fc699 <wasm[0]::function[1015]::helper::object_read+0x1b779>
 29f6f5f:	mov    %eax,%edi
 29f6f61:	lea    0x10(%rdx,%rdi,1),%rax
 29f6f66:	cmp    %rcx,%rdi
 29f6f69:	cmova  %rsi,%rax
 29f6f6d:	mov    (%rax),%r10d
 29f6f70:	mov    0x88(%rsp),%ecx
 29f6f77:	mov    0xc8(%rsp),%eax
 29f6f7e:	mov    0xa8(%rsp),%edx
 29f6f85:	mov    0xb0(%rsp),%esi
 29f6f8c:	mov    0xb8(%rsp),%edi
 29f6f93:	cmp    %r9d,%r8d
 29f6f96:	sete   %r8b
 29f6f9a:	cmp    %r10d,%ebx
 29f6f9d:	sete   %r9b
 29f6fa1:	mov    %r8,%r10
 29f6fa4:	and    %r9d,%r10d
 29f6fa7:	movzbl %r10b,%r10d
 29f6fab:	mov    %r10,%r14
 29f6fae:	test   %r8b,%r9b
 29f6fb1:	je     29f735b <wasm[0]::function[1015]::helper::object_read+0x1643b>
 29f6fb7:	mov    0x88(%rsp),%esi
 29f6fbe:	mov    0xc8(%rsp),%edi
 29f6fc5:	mov    0xa8(%rsp),%r8d
 29f6fcd:	mov    0xb0(%rsp),%r9d
 29f6fd5:	mov    0xb8(%rsp),%r11d
 29f6fdd:	xor    %r12d,%r12d
 29f6fe0:	mov    %esi,0x90(%rsp)
 29f6fe7:	mov    %edi,0x98(%rsp)
 29f6fee:	mov    %r8d,0xc0(%rsp)
 29f6ff6:	mov    %r9d,0xd0(%rsp)
 29f6ffe:	mov    %r11d,0xd8(%rsp)
 29f7006:	mov    0x2e8(%rsp),%r13
 29f700e:	mov    0x0(%r13),%rcx
 29f7012:	mov    0x228(%rsp),%rax
 29f701a:	cmp    %rax,%rcx
 29f701d:	jae    29fb665 <wasm[0]::function[1015]::helper::object_read+0x1a745>
 29f7023:	jmp    29f7030 <wasm[0]::function[1015]::helper::object_read+0x16110>
 29f7028:	mov    %rdx,0x228(%rsp)
 29f7030:	cmp    %ebx,%r12d
 29f7033:	jae    29f7186 <wasm[0]::function[1015]::helper::object_read+0x16266>
 29f7039:	mov    0xe0(%rsp),%ecx
 29f7040:	test   %ecx,%ecx
 29f7042:	je     29fc69b <wasm[0]::function[1015]::helper::object_read+0x1b77b>
 29f7048:	test   %ecx,%ecx
 29f704a:	je     29fc69d <wasm[0]::function[1015]::helper::object_read+0x1b77d>
 29f7050:	mov    0x2e0(%rsp),%rax
 29f7058:	mov    0x28(%rax),%rsi
 29f705c:	mov    0x20(%rax),%rdi
 29f7060:	mov    %ecx,%r9d
 29f7063:	lea    0x10(%rdi,%r9,1),%rdx
 29f7068:	xor    %r8,%r8
 29f706b:	cmp    %rsi,%r9
 29f706e:	cmova  %r8,%rdx
 29f7072:	mov    (%rdx),%r9d
 29f7075:	cmp    %r9d,%r12d
 29f7078:	jae    29fc69f <wasm[0]::function[1015]::helper::object_read+0x1b77f>
 29f707e:	mov    %r9d,%r10d
 29f7081:	shl    $0x3,%r10
 29f7085:	shr    $0x20,%r10
 29f7089:	test   %r10,%r10
 29f708c:	jne    29fc6a1 <wasm[0]::function[1015]::helper::object_read+0x1b781>
 29f7092:	shl    $0x3,%r9d
 29f7096:	add    $0x18,%r9d
 29f709a:	jb     29fc6a3 <wasm[0]::function[1015]::helper::object_read+0x1b783>
 29f70a0:	add    %r9d,%ecx
 29f70a3:	jb     29fc6a5 <wasm[0]::function[1015]::helper::object_read+0x1b785>
 29f70a9:	mov    %ecx,%r11d
 29f70ac:	lea    (%rdi,%r11,1),%r10
 29f70b0:	cmp    %rsi,%r11
 29f70b3:	cmova  %r8,%r10
 29f70b7:	mov    %r12,%rax
 29f70ba:	shl    $0x3,%eax
 29f70bd:	lea    0x18(%rax),%edx
 29f70c0:	sub    %edx,%r9d
 29f70c3:	sub    %r9,%r10
 29f70c6:	mov    (%r10),%rcx
 29f70c9:	mov    0xe8(%rsp),%r9d
 29f70d1:	test   %r9d,%r9d
 29f70d4:	je     29fc6a7 <wasm[0]::function[1015]::helper::object_read+0x1b787>
 29f70da:	test   %r9d,%r9d
 29f70dd:	je     29fc6a9 <wasm[0]::function[1015]::helper::object_read+0x1b789>
 29f70e3:	mov    %r9d,%eax
 29f70e6:	lea    0x10(%rdi,%rax,1),%r10
 29f70eb:	cmp    %rsi,%rax
 29f70ee:	cmova  %r8,%r10
 29f70f2:	mov    (%r10),%r10d
 29f70f5:	cmp    %r10d,%r12d
 29f70f8:	jae    29fc6ab <wasm[0]::function[1015]::helper::object_read+0x1b78b>
 29f70fe:	mov    %r10d,%r11d
 29f7101:	shl    $0x3,%r11
 29f7105:	shr    $0x20,%r11
 29f7109:	test   %r11,%r11
 29f710c:	jne    29fc6ad <wasm[0]::function[1015]::helper::object_read+0x1b78d>
 29f7112:	shl    $0x3,%r10d
 29f7116:	add    $0x18,%r10d
 29f711a:	jb     29fc6af <wasm[0]::function[1015]::helper::object_read+0x1b78f>
 29f7120:	add    %r10d,%r9d
 29f7123:	jb     29fc6b1 <wasm[0]::function[1015]::helper::object_read+0x1b791>
 29f7129:	mov    %r9d,%eax
 29f712c:	add    %rax,%rdi
 29f712f:	cmp    %rsi,%rax
 29f7132:	cmova  %r8,%rdi
 29f7136:	sub    %edx,%r10d
 29f7139:	sub    %r10,%rdi
 29f713c:	mov    (%rdi),%rdx
 29f713f:	cmp    %rdx,%rcx
 29f7142:	sete   %al
 29f7145:	movzbl %al,%eax
 29f7148:	mov    %rax,%r14
 29f714b:	cmp    %rdx,%rcx
 29f714e:	jne    29f7186 <wasm[0]::function[1015]::helper::object_read+0x16266>
 29f7154:	mov    0x90(%rsp),%esi
 29f715b:	mov    0x98(%rsp),%edi
 29f7162:	mov    0xc0(%rsp),%r8d
 29f716a:	mov    0xd0(%rsp),%r9d
 29f7172:	mov    0xd8(%rsp),%r11d
 29f717a:	add    $0x1,%r12d
 29f7181:	jmp    29f6fe0 <wasm[0]::function[1015]::helper::object_read+0x160c0>
 29f7186:	mov    0x90(%rsp),%ecx
 29f718d:	mov    0x98(%rsp),%eax
 29f7194:	mov    0xc0(%rsp),%edx
 29f719b:	mov    0xd0(%rsp),%esi
 29f71a2:	mov    0xd8(%rsp),%edi
 29f71a9:	jmp    29f735b <wasm[0]::function[1015]::helper::object_read+0x1643b>
 29f71ae:	mov    0x78(%rsp),%ecx
 29f71b2:	cmp    %eax,%ecx
 29f71b4:	je     29f72b9 <wasm[0]::function[1015]::helper::object_read+0x16399>
 29f71ba:	xor    %edx,%edx
 29f71bc:	test   %ecx,%ecx
 29f71be:	je     29f720f <wasm[0]::function[1015]::helper::object_read+0x162ef>
 29f71c4:	xor    %edx,%edx
 29f71c6:	test   $0x1,%ecx
 29f71cc:	jne    29f720f <wasm[0]::function[1015]::helper::object_read+0x162ef>
 29f71d2:	mov    0x2e0(%rsp),%r12
 29f71da:	mov    0x28(%r12),%rdx
 29f71df:	mov    0x20(%r12),%rdi
 29f71e4:	mov    %ecx,%esi
 29f71e6:	lea    0x4(%rdi,%rsi,1),%rcx
 29f71eb:	xor    %rdi,%rdi
 29f71ee:	cmp    %rdx,%rsi
 29f71f1:	cmova  %rdi,%rcx
 29f71f5:	mov    (%rcx),%ecx
 29f71f7:	mov    0x190(%rsp),%rsi
 29f71ff:	mov    0x28(%rsi),%rdx
 29f7203:	cmp    0x234(%rdx),%ecx
 29f7209:	sete   %cl
 29f720c:	movzbl %cl,%edx
 29f720f:	test   %edx,%edx
 29f7211:	je     29fc6b3 <wasm[0]::function[1015]::helper::object_read+0x1b793>
 29f7217:	xor    %r10d,%r10d
 29f721a:	test   %eax,%eax
 29f721c:	jne    29f722a <wasm[0]::function[1015]::helper::object_read+0x1630a>
 29f7222:	mov    %rax,%rdi
 29f7225:	jmp    29f7281 <wasm[0]::function[1015]::helper::object_read+0x16361>
 29f722a:	xor    %r10d,%r10d
 29f722d:	test   $0x1,%eax
 29f7232:	je     29f7240 <wasm[0]::function[1015]::helper::object_read+0x16320>
 29f7238:	mov    %rax,%rdi
 29f723b:	jmp    29f7281 <wasm[0]::function[1015]::helper::object_read+0x16361>
 29f7240:	mov    0x2e0(%rsp),%r12
 29f7248:	mov    0x28(%r12),%rcx
 29f724d:	mov    0x20(%r12),%rsi
 29f7252:	mov    %eax,%edx
 29f7254:	mov    %rax,%rdi
 29f7257:	lea    0x4(%rsi,%rdx,1),%rax
 29f725c:	xor    %rsi,%rsi
 29f725f:	cmp    %rcx,%rdx
 29f7262:	cmova  %rsi,%rax
 29f7266:	mov    (%rax),%eax
 29f7268:	mov    0x190(%rsp),%rsi
 29f7270:	mov    0x28(%rsi),%rcx
 29f7274:	cmp    0x234(%rcx),%eax
 29f727a:	sete   %al
 29f727d:	movzbl %al,%r10d
 29f7281:	test   %r10d,%r10d
 29f7284:	je     29fc6b5 <wasm[0]::function[1015]::helper::object_read+0x1b795>
 29f728a:	mov    0x78(%rsp),%edx
 29f728e:	xor    %r8d,%r8d
 29f7291:	test   %edx,%edx
 29f7293:	je     29fc6b7 <wasm[0]::function[1015]::helper::object_read+0x1b797>
 29f7299:	mov    %rdi,%rcx
 29f729c:	mov    0x190(%rsp),%rsi
 29f72a4:	mov    0x190(%rsp),%rdi
 29f72ac:	call   2ae54e0 <wasm[0]::function[1057]::helper::string_equality>
 29f72b1:	mov    %rax,%r14
 29f72b4:	jmp    29f72c1 <wasm[0]::function[1015]::helper::object_read+0x163a1>
 29f72b9:	mov    0x278(%rsp),%r14
 29f72c1:	mov    0x88(%rsp),%ecx
 29f72c8:	mov    0xc8(%rsp),%eax
 29f72cf:	mov    0xa8(%rsp),%edx
 29f72d6:	mov    0xb0(%rsp),%esi
 29f72dd:	mov    0xb8(%rsp),%edi
 29f72e4:	jmp    29f735b <wasm[0]::function[1015]::helper::object_read+0x1643b>
 29f72e9:	mov    0x88(%rsp),%ecx
 29f72f0:	mov    0xc8(%rsp),%eax
 29f72f7:	mov    0xa8(%rsp),%edx
 29f72fe:	mov    0xb0(%rsp),%esi
 29f7305:	mov    0xb8(%rsp),%edi
 29f730c:	xor    %r10,%r10
 29f730f:	mov    0x1c0(%rsp),%r8
 29f7317:	mov    0x1c0(%rsp),%r9
 29f731f:	test   %r9,%r8
 29f7322:	sete   %r8b
 29f7326:	movq   %r9,%xmm0
 29f732b:	ucomisd %xmm0,%xmm0
 29f732f:	setp   %r9b
 29f7333:	setne  %r11b
 29f7337:	or     %r11d,%r9d
 29f733a:	movq   %r10,%xmm1
 29f733f:	ucomisd %xmm1,%xmm1
 29f7343:	setp   %r10b
 29f7347:	setne  %r11b
 29f734b:	or     %r11d,%r10d
 29f734e:	and    %r10d,%r9d
 29f7351:	or     %r9d,%r8d
 29f7354:	movzbl %r8b,%r8d
 29f7358:	mov    %r8,%r14
 29f735b:	mov    %edx,0x90(%rsp)
 29f7362:	mov    %esi,0x78(%rsp)
 29f7366:	mov    %edi,0xc8(%rsp)
 29f736d:	mov    %r14,%rdx
 29f7370:	mov    %r14,%rsi
 29f7373:	test   %esi,%edx
 29f7375:	je     29f756b <wasm[0]::function[1015]::helper::object_read+0x1664b>
 29f737b:	test   %ecx,%ecx
 29f737d:	je     29fc6b9 <wasm[0]::function[1015]::helper::object_read+0x1b799>
 29f7383:	test   %ecx,%ecx
 29f7385:	je     29fc6bb <wasm[0]::function[1015]::helper::object_read+0x1b79b>
 29f738b:	mov    0x2e0(%rsp),%r12
 29f7393:	mov    0x28(%r12),%rax
 29f7398:	mov    0x20(%r12),%rdx
 29f739d:	mov    %ecx,%ecx
 29f739f:	lea    (%rdx,%rcx,1),%r11
 29f73a3:	xor    %rdx,%rdx
 29f73a6:	cmp    %rax,%rcx
 29f73a9:	cmova  %rdx,%r11
 29f73ad:	mov    0x18(%r11),%r15
 29f73b1:	movl   $0x0,0x98(%rsp)
 29f73bc:	mov    0x20(%r11),%ebx
 29f73c0:	mov    0x270(%rsp),%rcx
 29f73c8:	mov    (%rcx),%eax
 29f73ca:	mov    %eax,%edx
 29f73cc:	lea    0x20(%rdx),%rcx
 29f73d0:	mov    0x270(%rsp),%rsi
 29f73d8:	mov    0x4(%rsi),%esi
 29f73db:	cmp    %rsi,%rcx
 29f73de:	ja     29fb694 <wasm[0]::function[1015]::helper::object_read+0x1a774>
 29f73e4:	lea    0x20(%rax),%ecx
 29f73e7:	mov    0x270(%rsp),%rsi
 29f73ef:	mov    %ecx,(%rsi)
 29f73f1:	mov    0x2e0(%rsp),%r12
 29f73f9:	mov    0x20(%r12),%rsi
 29f73fe:	lea    (%rsi,%rdx,1),%rcx
 29f7402:	movl   $0xb0000042,(%rsi,%rdx,1)
 29f7409:	mov    0x190(%rsp),%rdi
 29f7411:	mov    0x28(%rdi),%rdi
 29f7415:	mov    0x120(%rdi),%edi
 29f741b:	mov    %edi,0x4(%rsi,%rdx,1)
 29f741f:	mov    0x268(%rsp),%rdi
 29f7427:	mov    %edi,0x8(%rsi,%rdx,1)
 29f742b:	mov    %eax,0xc0(%rsp)
 29f7432:	cmp    $0x0,%r15
 29f7436:	jl     29f7446 <wasm[0]::function[1015]::helper::object_read+0x16526>
 29f743c:	cvtsi2sd %r15,%xmm0
 29f7441:	jmp    29f7460 <wasm[0]::function[1015]::helper::object_read+0x16540>
 29f7446:	mov    %r15,%rsi
 29f7449:	shr    $0x1,%rsi
 29f744d:	mov    %r15,%rdx
 29f7450:	and    $0x1,%rdx
 29f7454:	or     %rsi,%rdx
 29f7457:	cvtsi2sd %rdx,%xmm0
 29f745c:	addsd  %xmm0,%xmm0
 29f7460:	movq   %xmm0,%rdx
 29f7465:	mov    %rdx,0x10(%rcx)
 29f7469:	movl   $0x3,0x18(%rcx)
 29f7470:	mov    0x98(%rsp),%edx
 29f7477:	mov    %edx,0x1c(%rcx)
 29f747a:	mov    0x190(%rsp),%rsi
 29f7482:	mov    0xa20(%rsi),%ecx
 29f7488:	mov    %ecx,0x98(%rsp)
 29f748f:	test   %eax,%eax
 29f7491:	je     29fc6bd <wasm[0]::function[1015]::helper::object_read+0x1b79d>
 29f7497:	test   %ecx,%ecx
 29f7499:	je     29fc6bf <wasm[0]::function[1015]::helper::object_read+0x1b79f>
 29f749f:	mov    0x270(%rsp),%rcx
 29f74a7:	mov    (%rcx),%eax
 29f74a9:	mov    %eax,%ecx
 29f74ab:	lea    0x20(%rcx),%rdx
 29f74af:	mov    0x270(%rsp),%rsi
 29f74b7:	mov    0x4(%rsi),%esi
 29f74ba:	cmp    %rsi,%rdx
 29f74bd:	ja     29fb6d7 <wasm[0]::function[1015]::helper::object_read+0x1a7b7>
 29f74c3:	lea    0x20(%rax),%edx
 29f74c6:	mov    0x270(%rsp),%rsi
 29f74ce:	mov    %edx,(%rsi)
 29f74d0:	mov    0x2e0(%rsp),%r12
 29f74d8:	mov    0x20(%r12),%rdx
 29f74dd:	lea    (%rdx,%rcx,1),%r11
 29f74e1:	movl   $0xb0000072,(%rdx,%rcx,1)
 29f74e8:	mov    0x190(%rsp),%rsi
 29f74f0:	mov    0x28(%rsi),%rsi
 29f74f4:	mov    0x13c(%rsi),%esi
 29f74fa:	mov    %esi,0x4(%rdx,%rcx,1)
 29f74fe:	mov    0x268(%rsp),%rsi
 29f7506:	mov    %esi,0x8(%rdx,%rcx,1)
 29f750a:	movl   $0x4,0x10(%r11)
 29f7512:	mov    0xc0(%rsp),%ecx
 29f7519:	mov    %ecx,0x14(%r11)
 29f751d:	mov    0x98(%rsp),%ecx
 29f7524:	mov    %ecx,0x18(%r11)
 29f7528:	mov    %ecx,0x1c(%r11)
 29f752c:	test   %eax,%eax
 29f752e:	je     29fc6c1 <wasm[0]::function[1015]::helper::object_read+0x1b7a1>
 29f7534:	test   %eax,%eax
 29f7536:	je     29fc6c3 <wasm[0]::function[1015]::helper::object_read+0x1b7a3>
 29f753c:	mov    0x2e0(%rsp),%r12
 29f7544:	mov    0x28(%r12),%rcx
 29f7549:	test   %ebx,%ebx
 29f754b:	setne  %dl
 29f754e:	movzbl %dl,%edx
 29f7551:	shl    $0x2,%edx
 29f7554:	mov    %eax,%edi
 29f7556:	mov    %rdi,%rsi
 29f7559:	add    0x20(%r12),%rsi
 29f755e:	xor    %r8,%r8
 29f7561:	cmp    %rcx,%rdi
 29f7564:	cmova  %r8,%rsi
 29f7568:	mov    %edx,0x10(%rsi)
 29f756b:	mov    0x90(%rsp),%ecx
 29f7572:	mov    0x78(%rsp),%edx
 29f7576:	mov    %rdx,%r15
 29f7579:	mov    0xc8(%rsp),%edx
 29f7580:	jmp    29f889d <wasm[0]::function[1015]::helper::object_read+0x1797d>
 29f7585:	test   %edi,%edi
 29f7587:	je     29fc6c5 <wasm[0]::function[1015]::helper::object_read+0x1b7a5>
 29f758d:	test   %edi,%edi
 29f758f:	je     29fc6c7 <wasm[0]::function[1015]::helper::object_read+0x1b7a7>
 29f7595:	mov    0x2e0(%rsp),%r12
 29f759d:	mov    0x28(%r12),%r8
 29f75a2:	mov    0x20(%r12),%r9
 29f75a7:	mov    %edi,%r10d
 29f75aa:	lea    (%r9,%r10,1),%rax
 29f75ae:	xor    %rdi,%rdi
 29f75b1:	cmp    %r8,%r10
 29f75b4:	cmova  %rdi,%rax
 29f75b8:	mov    0x14(%rax),%eax
 29f75bb:	mov    %eax,0x88(%rsp)
 29f75c2:	test   %eax,%eax
 29f75c4:	je     29fc6c9 <wasm[0]::function[1015]::helper::object_read+0x1b7a9>
 29f75ca:	test   %eax,%eax
 29f75cc:	je     29fc6cb <wasm[0]::function[1015]::helper::object_read+0x1b7ab>
 29f75d2:	mov    %eax,%r10d
 29f75d5:	add    %r10,%r9
 29f75d8:	cmp    %r8,%r10
 29f75db:	cmova  %rdi,%r9
 29f75df:	mov    0x24(%r9),%r8d
 29f75e3:	cmp    $0x2,%r8d
 29f75e7:	sete   %dil
 29f75eb:	cmp    $0x3,%r8d
 29f75ef:	sete   %r8b
 29f75f3:	or     %r8d,%edi
 29f75f6:	test   %dil,%dil
 29f75f9:	jne    29f760c <wasm[0]::function[1015]::helper::object_read+0x166ec>
 29f75ff:	mov    %rsi,0x198(%rsp)
 29f7607:	jmp    29f856b <wasm[0]::function[1015]::helper::object_read+0x1764b>
 29f760c:	mov    0x88(%rsp),%edi
 29f7613:	test   %edi,%edi
 29f7615:	je     29fc6cd <wasm[0]::function[1015]::helper::object_read+0x1b7ad>
 29f761b:	test   %edi,%edi
 29f761d:	je     29fc6cf <wasm[0]::function[1015]::helper::object_read+0x1b7af>
 29f7623:	mov    0x2e0(%rsp),%r12
 29f762b:	mov    0x28(%r12),%r9
 29f7630:	mov    %edi,%r10d
 29f7633:	mov    %r10,%rdi
 29f7636:	add    0x20(%r12),%rdi
 29f763b:	xor    %r11,%r11
 29f763e:	cmp    %r9,%r10
 29f7641:	cmova  %r11,%rdi
 29f7645:	mov    0x24(%rdi),%r10d
 29f7649:	cmp    $0x3,%r10d
 29f764d:	je     29f7776 <wasm[0]::function[1015]::helper::object_read+0x16856>
 29f7653:	mov    0x88(%rsp),%eax
 29f765a:	xor    %edi,%edi
 29f765c:	test   %eax,%eax
 29f765e:	je     29fc6d1 <wasm[0]::function[1015]::helper::object_read+0x1b7b1>
 29f7664:	test   %eax,%eax
 29f7666:	je     29fc6d3 <wasm[0]::function[1015]::helper::object_read+0x1b7b3>
 29f766c:	mov    0x2e0(%rsp),%r12
 29f7674:	mov    0x28(%r12),%rcx
 29f7679:	mov    0x20(%r12),%rdx
 29f767e:	mov    %eax,%r9d
 29f7681:	lea    (%rdx,%r9,1),%rax
 29f7685:	xor    %r8,%r8
 29f7688:	cmp    %rcx,%r9
 29f768b:	cmova  %r8,%rax
 29f768f:	mov    0x28(%rax),%r9d
 29f7693:	mov    0x2c(%rax),%eax
 29f7696:	test   %r9d,%r9d
 29f7699:	je     29fc6d5 <wasm[0]::function[1015]::helper::object_read+0x1b7b5>
 29f769f:	test   %r9d,%r9d
 29f76a2:	je     29fc6d7 <wasm[0]::function[1015]::helper::object_read+0x1b7b7>
 29f76a8:	mov    %r9d,%r9d
 29f76ab:	lea    0x10(%rdx,%r9,1),%rdx
 29f76b0:	cmp    %rcx,%r9
 29f76b3:	cmova  %r8,%rdx
 29f76b7:	mov    %esi,%ecx
 29f76b9:	mov    (%rdx),%edx
 29f76bb:	cmp    %rdx,%rcx
 29f76be:	jae    29f7769 <wasm[0]::function[1015]::helper::object_read+0x16849>
 29f76c4:	xor    %edi,%edi
 29f76c6:	test   %eax,%eax
 29f76c8:	je     29fc6d9 <wasm[0]::function[1015]::helper::object_read+0x1b7b9>
 29f76ce:	test   %eax,%eax
 29f76d0:	je     29fc6db <wasm[0]::function[1015]::helper::object_read+0x1b7bb>
 29f76d6:	mov    0x2e0(%rsp),%r12
 29f76de:	mov    0x28(%r12),%rcx
 29f76e3:	mov    0x20(%r12),%rdx
 29f76e8:	mov    %eax,%r10d
 29f76eb:	lea    0x10(%rdx,%r10,1),%r9
 29f76f0:	xor    %r8,%r8
 29f76f3:	cmp    %rcx,%r10
 29f76f6:	cmova  %r8,%r9
 29f76fa:	mov    (%r9),%r9d
 29f76fd:	mov    %rsi,%r10
 29f7700:	shr    $0x6,%r10d
 29f7704:	cmp    %r9d,%r10d
 29f7707:	jae    29fc6dd <wasm[0]::function[1015]::helper::object_read+0x1b7bd>
 29f770d:	mov    %r9d,%r11d
 29f7710:	shl    $0x3,%r11
 29f7714:	shr    $0x20,%r11
 29f7718:	test   %r11,%r11
 29f771b:	jne    29fc6df <wasm[0]::function[1015]::helper::object_read+0x1b7bf>
 29f7721:	shl    $0x3,%r9d
 29f7725:	add    $0x18,%r9d
 29f7729:	jb     29fc6e1 <wasm[0]::function[1015]::helper::object_read+0x1b7c1>
 29f772f:	add    %r9d,%eax
 29f7732:	jb     29fc6e3 <wasm[0]::function[1015]::helper::object_read+0x1b7c3>
 29f7738:	mov    %eax,%r11d
 29f773b:	lea    (%rdx,%r11,1),%rax
 29f773f:	cmp    %rcx,%r11
 29f7742:	cmova  %r8,%rax
 29f7746:	shl    $0x3,%r10d
 29f774a:	lea    0x18(%r10),%ecx
 29f774e:	sub    %ecx,%r9d
 29f7751:	sub    %r9,%rax
 29f7754:	mov    (%rax),%rax
 29f7757:	bt     %rsi,%rax
 29f775b:	jae    29f7769 <wasm[0]::function[1015]::helper::object_read+0x16849>
 29f7761:	mov    0x278(%rsp),%rdi
 29f7769:	mov    %rsi,0x198(%rsp)
 29f7771:	jmp    29f787c <wasm[0]::function[1015]::helper::object_read+0x1695c>
 29f7776:	mov    0x88(%rsp),%eax
 29f777d:	xor    %edi,%edi
 29f777f:	test   %eax,%eax
 29f7781:	je     29fc6e5 <wasm[0]::function[1015]::helper::object_read+0x1b7c5>
 29f7787:	test   %eax,%eax
 29f7789:	je     29fc6e7 <wasm[0]::function[1015]::helper::object_read+0x1b7c7>
 29f778f:	mov    0x2e0(%rsp),%r12
 29f7797:	mov    0x28(%r12),%rcx
 29f779c:	mov    0x20(%r12),%rdx
 29f77a1:	mov    %eax,%r9d
 29f77a4:	lea    (%rdx,%r9,1),%rax
 29f77a8:	xor    %r8,%r8
 29f77ab:	cmp    %rcx,%r9
 29f77ae:	cmova  %r8,%rax
 29f77b2:	mov    0x30(%rax),%eax
 29f77b5:	test   %eax,%eax
 29f77b7:	je     29fc6e9 <wasm[0]::function[1015]::helper::object_read+0x1b7c9>
 29f77bd:	test   %eax,%eax
 29f77bf:	je     29fc6eb <wasm[0]::function[1015]::helper::object_read+0x1b7cb>
 29f77c5:	mov    %eax,%r9d
 29f77c8:	lea    0x10(%rdx,%r9,1),%rdx
 29f77cd:	cmp    %rcx,%r9
 29f77d0:	cmova  %r8,%rdx
 29f77d4:	mov    %esi,%ecx
 29f77d6:	mov    (%rdx),%edx
 29f77d8:	cmp    %rdx,%rcx
 29f77db:	jb     29f77ee <wasm[0]::function[1015]::helper::object_read+0x168ce>
 29f77e1:	mov    %rsi,0x198(%rsp)
 29f77e9:	jmp    29f787c <wasm[0]::function[1015]::helper::object_read+0x1695c>
 29f77ee:	mov    0x2e0(%rsp),%r12
 29f77f6:	mov    0x28(%r12),%rcx
 29f77fb:	mov    0x20(%r12),%r8
 29f7800:	lea    0x10(%r8,%r9,1),%rdi
 29f7805:	xor    %rdx,%rdx
 29f7808:	cmp    %rcx,%r9
 29f780b:	cmova  %rdx,%rdi
 29f780f:	mov    (%rdi),%edi
 29f7811:	cmp    %edi,%esi
 29f7813:	jae    29fc6ed <wasm[0]::function[1015]::helper::object_read+0x1b7cd>
 29f7819:	mov    %edi,%r9d
 29f781c:	shl    $0x2,%r9
 29f7820:	shr    $0x20,%r9
 29f7824:	test   %r9,%r9
 29f7827:	jne    29fc6ef <wasm[0]::function[1015]::helper::object_read+0x1b7cf>
 29f782d:	shl    $0x2,%edi
 29f7830:	add    $0x14,%edi
 29f7833:	jb     29fc6f1 <wasm[0]::function[1015]::helper::object_read+0x1b7d1>
 29f7839:	add    %edi,%eax
 29f783b:	jb     29fc6f3 <wasm[0]::function[1015]::helper::object_read+0x1b7d3>
 29f7841:	mov    %eax,%r9d
 29f7844:	lea    (%r8,%r9,1),%rax
 29f7848:	cmp    %rcx,%r9
 29f784b:	cmova  %rdx,%rax
 29f784f:	mov    %rsi,%rcx
 29f7852:	shl    $0x2,%ecx
 29f7855:	mov    %rsi,0x198(%rsp)
 29f785d:	add    $0x14,%ecx
 29f7863:	sub    %ecx,%edi
 29f7865:	sub    %rdi,%rax
 29f7868:	mov    (%rax),%ecx
 29f786a:	xor    %edi,%edi
 29f786c:	test   %ecx,%ecx
 29f786e:	je     29f787c <wasm[0]::function[1015]::helper::object_read+0x1695c>
 29f7874:	mov    0x278(%rsp),%rdi
 29f787c:	mov    0x88(%rsp),%eax
 29f7883:	mov    0xa8(%rsp),%ecx
 29f788a:	mov    0xb0(%rsp),%edx
 29f7891:	mov    %rdx,%r15
 29f7894:	mov    0xb8(%rsp),%edx
 29f789b:	test   %edi,%edi
 29f789d:	je     29f856b <wasm[0]::function[1015]::helper::object_read+0x1764b>
 29f78a3:	mov    0x88(%rsp),%r10d
 29f78ab:	test   %r10d,%r10d
 29f78ae:	je     29fc6f5 <wasm[0]::function[1015]::helper::object_read+0x1b7d5>
 29f78b4:	test   %r10d,%r10d
 29f78b7:	je     29fc6f7 <wasm[0]::function[1015]::helper::object_read+0x1b7d7>
 29f78bd:	mov    0x2e0(%rsp),%r12
 29f78c5:	mov    0x28(%r12),%rax
 29f78ca:	mov    %r10d,%ecx
 29f78cd:	mov    %rcx,%r11
 29f78d0:	add    0x20(%r12),%r11
 29f78d5:	xor    %rdx,%rdx
 29f78d8:	cmp    %rax,%rcx
 29f78db:	cmova  %rdx,%r11
 29f78df:	mov    0x24(%r11),%eax
 29f78e3:	cmp    $0x3,%eax
 29f78e6:	je     29f8007 <wasm[0]::function[1015]::helper::object_read+0x170e7>
 29f78ec:	mov    0x88(%rsp),%eax
 29f78f3:	test   %eax,%eax
 29f78f5:	je     29fc6f9 <wasm[0]::function[1015]::helper::object_read+0x1b7d9>
 29f78fb:	test   %eax,%eax
 29f78fd:	je     29fc6fb <wasm[0]::function[1015]::helper::object_read+0x1b7db>
 29f7903:	mov    0x2e0(%rsp),%r12
 29f790b:	mov    0x28(%r12),%rcx
 29f7910:	mov    %eax,%esi
 29f7912:	mov    %rsi,%rdx
 29f7915:	add    0x20(%r12),%rdx
 29f791a:	xor    %rdi,%rdi
 29f791d:	cmp    %rcx,%rsi
 29f7920:	cmova  %rdi,%rdx
 29f7924:	mov    0x24(%rdx),%esi
 29f7927:	mov    0xa8(%rsp),%ecx
 29f792e:	mov    0xb0(%rsp),%edi
 29f7935:	mov    %rdi,%r15
 29f7938:	mov    0xb8(%rsp),%edx
 29f793f:	cmp    $0x2,%esi
 29f7942:	jne    29f856b <wasm[0]::function[1015]::helper::object_read+0x1764b>
 29f7948:	mov    0x88(%rsp),%edx
 29f794f:	test   %edx,%edx
 29f7951:	je     29fc6fd <wasm[0]::function[1015]::helper::object_read+0x1b7dd>
 29f7957:	test   %edx,%edx
 29f7959:	je     29fc6ff <wasm[0]::function[1015]::helper::object_read+0x1b7df>
 29f795f:	mov    0x2e0(%rsp),%r12
 29f7967:	mov    0x28(%r12),%rax
 29f796c:	mov    0x20(%r12),%rcx
 29f7971:	mov    %edx,%esi
 29f7973:	lea    (%rcx,%rsi,1),%rdi
 29f7977:	xor    %rdx,%rdx
 29f797a:	cmp    %rax,%rsi
 29f797d:	cmova  %rdx,%rdi
 29f7981:	mov    0x28(%rdi),%esi
 29f7984:	mov    %esi,0x90(%rsp)
 29f798b:	mov    0x2c(%rdi),%edi
 29f798e:	mov    %edi,0x78(%rsp)
 29f7992:	test   %esi,%esi
 29f7994:	je     29fc701 <wasm[0]::function[1015]::helper::object_read+0x1b7e1>
 29f799a:	test   %esi,%esi
 29f799c:	je     29fc703 <wasm[0]::function[1015]::helper::object_read+0x1b7e3>
 29f79a2:	mov    %esi,%esi
 29f79a4:	lea    0x10(%rcx,%rsi,1),%rcx
 29f79a9:	cmp    %rax,%rsi
 29f79ac:	cmova  %rdx,%rcx
 29f79b0:	mov    (%rcx),%eax
 29f79b2:	mov    %eax,%r12d
 29f79b5:	mov    %r12,%rbx
 29f79b8:	shl    $0x2,%rbx
 29f79bc:	mov    %rbx,%rcx
 29f79bf:	shr    $0x20,%rcx
 29f79c3:	test   %rcx,%rcx
 29f79c6:	jne    29fc705 <wasm[0]::function[1015]::helper::object_read+0x1b7e5>
 29f79cc:	mov    %rax,%rcx
 29f79cf:	shl    $0x2,%ecx
 29f79d2:	mov    %rax,0x1e8(%rsp)
 29f79da:	add    $0x14,%ecx
 29f79dd:	jb     29fc707 <wasm[0]::function[1015]::helper::object_read+0x1b7e7>
 29f79e3:	mov    0x270(%rsp),%rax
 29f79eb:	mov    (%rax),%eax
 29f79ed:	mov    %eax,%esi
 29f79ef:	mov    %ecx,%edx
 29f79f1:	add    $0xf,%rdx
 29f79f8:	mov    %rdx,%rdi
 29f79fb:	and    $0xfffffffffffffff0,%rdi
 29f79ff:	add    %rsi,%rdi
 29f7a02:	mov    0x270(%rsp),%r8
 29f7a0a:	mov    0x4(%r8),%r8d
 29f7a0e:	cmp    %r8,%rdi
 29f7a11:	ja     29fb71b <wasm[0]::function[1015]::helper::object_read+0x1a7fb>
 29f7a17:	add    $0xf,%ecx
 29f7a1d:	and    $0xfffffff0,%ecx
 29f7a20:	add    %eax,%ecx
 29f7a22:	mov    0x270(%rsp),%rdi
 29f7a2a:	mov    %ecx,(%rdi)
 29f7a2c:	mov    0x2e0(%rsp),%rcx
 29f7a34:	mov    0x20(%rcx),%rdi
 29f7a38:	lea    (%rdi,%rsi,1),%rcx
 29f7a3c:	movl   $0xa800000e,(%rdi,%rsi,1)
 29f7a43:	mov    0x190(%rsp),%r8
 29f7a4b:	mov    0x28(%r8),%r8
 29f7a4f:	mov    0x194(%r8),%r8d
 29f7a56:	mov    %r8d,0x4(%rdi,%rsi,1)
 29f7a5b:	and    $0xfffffffffffffff0,%rdx
 29f7a5f:	mov    %edx,0x8(%rdi,%rsi,1)
 29f7a63:	mov    %eax,0xc8(%rsp)
 29f7a6a:	mov    0x1e8(%rsp),%r14
 29f7a72:	mov    %r14d,0x10(%rcx)
 29f7a76:	test   %eax,%eax
 29f7a78:	je     29fc709 <wasm[0]::function[1015]::helper::object_read+0x1b7e9>
 29f7a7e:	mov    0x2e0(%rsp),%rcx
 29f7a86:	mov    0x28(%rcx),%rcx
 29f7a8a:	mov    0x2e0(%rsp),%rdx
 29f7a92:	mov    0x20(%rdx),%rdx
 29f7a96:	mov    %eax,%esi
 29f7a98:	lea    (%rdx,%rsi,1),%rax
 29f7a9c:	lea    0x10(%rdx,%rsi,1),%rdi
 29f7aa1:	xor    %r8,%r8
 29f7aa4:	cmp    %rcx,%rsi
 29f7aa7:	cmova  %r8,%rdi
 29f7aab:	mov    (%rdi),%edi
 29f7aad:	cmp    %rdi,%r12
 29f7ab0:	ja     29fc70b <wasm[0]::function[1015]::helper::object_read+0x1b7eb>
 29f7ab6:	lea    0x14(%rdx,%rsi,1),%r13
 29f7abb:	mov    %r13,%rsi
 29f7abe:	add    %rbx,%rsi
 29f7ac1:	jb     29fc70d <wasm[0]::function[1015]::helper::object_read+0x1b7ed>
 29f7ac7:	add    %rdx,%rcx
 29f7aca:	cmp    %rcx,%rsi
 29f7acd:	ja     29fc70f <wasm[0]::function[1015]::helper::object_read+0x1b7ef>
 29f7ad3:	mov    0x78(%rsp),%r9d
 29f7ad8:	mov    0x90(%rsp),%r8d
 29f7ae0:	mov    0x88(%rsp),%ecx
 29f7ae7:	mov    0xa8(%rsp),%edx
 29f7aee:	mov    0xb0(%rsp),%esi
 29f7af5:	mov    0xb8(%rsp),%edi
 29f7afc:	lea    0x14(%rax,%r12,4),%rbx
 29f7b01:	test   %r12,%r12
 29f7b04:	je     29f7b9d <wasm[0]::function[1015]::helper::object_read+0x16c7d>
 29f7b0a:	mov    %r9d,0xd8(%rsp)
 29f7b12:	mov    %r8d,0xd0(%rsp)
 29f7b1a:	mov    %ecx,0xc0(%rsp)
 29f7b21:	mov    %edx,0x98(%rsp)
 29f7b28:	mov    %esi,0x90(%rsp)
 29f7b2f:	mov    %edi,0x78(%rsp)
 29f7b33:	mov    0x2e8(%rsp),%r8
 29f7b3b:	mov    (%r8),%rsi
 29f7b3e:	mov    0x228(%rsp),%rax
 29f7b46:	cmp    %rax,%rsi
 29f7b49:	jae    29fb758 <wasm[0]::function[1015]::helper::object_read+0x1a838>
 29f7b4f:	jmp    29f7b5c <wasm[0]::function[1015]::helper::object_read+0x16c3c>
 29f7b54:	mov    %r8,0x228(%rsp)
 29f7b5c:	movl   $0x0,0x0(%r13)
 29f7b64:	mov    0xd8(%rsp),%r9d
 29f7b6c:	mov    0xd0(%rsp),%r8d
 29f7b74:	mov    0xc0(%rsp),%ecx
 29f7b7b:	mov    0x98(%rsp),%edx
 29f7b82:	mov    0x90(%rsp),%esi
 29f7b89:	mov    0x78(%rsp),%edi
 29f7b8d:	add    $0x4,%r13
 29f7b94:	cmp    %rbx,%r13
 29f7b97:	jne    29f7b0a <wasm[0]::function[1015]::helper::object_read+0x16bea>
 29f7b9d:	mov    %r9d,0xd0(%rsp)
 29f7ba5:	mov    %r8d,0xd8(%rsp)
 29f7bad:	xor    %r13d,%r13d
 29f7bb0:	mov    $0xb0000042,%ebx
 29f7bb5:	mov    0x190(%rsp),%rax
 29f7bbd:	mov    %rbx,0x1e0(%rsp)
 29f7bc5:	mov    0x28(%rax),%rax
 29f7bc9:	mov    0x120(%rax),%r15d
 29f7bd0:	mov    $0x20,%ebx
 29f7bd5:	mov    %rbx,0x1d8(%rsp)
 29f7bdd:	mov    $0x10,%ebx
 29f7be2:	mov    $0xb0000072,%r8d
 29f7be8:	mov    %r8,0x1d0(%rsp)
 29f7bf0:	mov    0x13c(%rax),%r14d
 29f7bf7:	mov    %ecx,0x78(%rsp)
 29f7bfb:	mov    %edx,0x90(%rsp)
 29f7c02:	mov    %esi,0x98(%rsp)
 29f7c09:	mov    %edi,0xc0(%rsp)
 29f7c10:	mov    0x2e8(%rsp),%rax
 29f7c18:	mov    (%rax),%rax
 29f7c1b:	mov    0x228(%rsp),%rcx
 29f7c23:	cmp    %rcx,%rax
 29f7c26:	jae    29fb788 <wasm[0]::function[1015]::helper::object_read+0x1a868>
 29f7c2c:	mov    0x1e8(%rsp),%rcx
 29f7c34:	jmp    29f7c49 <wasm[0]::function[1015]::helper::object_read+0x16d29>
 29f7c39:	mov    %rcx,0x228(%rsp)
 29f7c41:	mov    0x1e8(%rsp),%rcx
 29f7c49:	cmp    %ecx,%r13d
 29f7c4c:	jae    29f7f63 <wasm[0]::function[1015]::helper::object_read+0x17043>
 29f7c52:	mov    0xd0(%rsp),%eax
 29f7c59:	test   %eax,%eax
 29f7c5b:	je     29fc711 <wasm[0]::function[1015]::helper::object_read+0x1b7f1>
 29f7c61:	test   %eax,%eax
 29f7c63:	je     29fc713 <wasm[0]::function[1015]::helper::object_read+0x1b7f3>
 29f7c69:	mov    0x2e0(%rsp),%r12
 29f7c71:	mov    0x28(%r12),%rcx
 29f7c76:	mov    0x20(%r12),%rdx
 29f7c7b:	mov    %eax,%r8d
 29f7c7e:	lea    0x10(%rdx,%r8,1),%rdi
 29f7c83:	xor    %rsi,%rsi
 29f7c86:	cmp    %rcx,%r8
 29f7c89:	cmova  %rsi,%rdi
 29f7c8d:	mov    (%rdi),%edi
 29f7c8f:	mov    %r13,%r8
 29f7c92:	shr    $0x6,%r8d
 29f7c96:	cmp    %edi,%r8d
 29f7c99:	jae    29fc715 <wasm[0]::function[1015]::helper::object_read+0x1b7f5>
 29f7c9f:	mov    %edi,%r9d
 29f7ca2:	shl    $0x3,%r9
 29f7ca6:	shr    $0x20,%r9
 29f7caa:	test   %r9,%r9
 29f7cad:	jne    29fc717 <wasm[0]::function[1015]::helper::object_read+0x1b7f7>
 29f7cb3:	shl    $0x3,%edi
 29f7cb6:	add    $0x18,%edi
 29f7cb9:	jb     29fc719 <wasm[0]::function[1015]::helper::object_read+0x1b7f9>
 29f7cbf:	add    %edi,%eax
 29f7cc1:	jb     29fc71b <wasm[0]::function[1015]::helper::object_read+0x1b7fb>
 29f7cc7:	mov    %eax,%r9d
 29f7cca:	lea    (%rdx,%r9,1),%rax
 29f7cce:	cmp    %rcx,%r9
 29f7cd1:	cmova  %rsi,%rax
 29f7cd5:	shl    $0x3,%r8d
 29f7cd9:	lea    0x18(%r8),%ecx
 29f7cdd:	sub    %ecx,%edi
 29f7cdf:	sub    %rdi,%rax
 29f7ce2:	mov    (%rax),%rax
 29f7ce5:	bt     %r13,%rax
 29f7ce9:	jae    29f7f3e <wasm[0]::function[1015]::helper::object_read+0x1701e>
 29f7cef:	mov    0xd8(%rsp),%eax
 29f7cf6:	test   %eax,%eax
 29f7cf8:	je     29fc71d <wasm[0]::function[1015]::helper::object_read+0x1b7fd>
 29f7cfe:	test   %eax,%eax
 29f7d00:	je     29fc71f <wasm[0]::function[1015]::helper::object_read+0x1b7ff>
 29f7d06:	mov    0x2e0(%rsp),%r12
 29f7d0e:	mov    0x28(%r12),%rcx
 29f7d13:	mov    0x20(%r12),%rdx
 29f7d18:	mov    %eax,%r8d
 29f7d1b:	lea    0x10(%rdx,%r8,1),%rdi
 29f7d20:	xor    %rsi,%rsi
 29f7d23:	cmp    %rcx,%r8
 29f7d26:	cmova  %rsi,%rdi
 29f7d2a:	mov    (%rdi),%edi
 29f7d2c:	cmp    %edi,%r13d
 29f7d2f:	jae    29fc721 <wasm[0]::function[1015]::helper::object_read+0x1b801>
 29f7d35:	mov    %edi,%r8d
 29f7d38:	shl    $0x3,%r8
 29f7d3c:	shr    $0x20,%r8
 29f7d40:	test   %r8,%r8
 29f7d43:	jne    29fc723 <wasm[0]::function[1015]::helper::object_read+0x1b803>
 29f7d49:	shl    $0x3,%edi
 29f7d4c:	add    $0x18,%edi
 29f7d4f:	jb     29fc725 <wasm[0]::function[1015]::helper::object_read+0x1b805>
 29f7d55:	add    %edi,%eax
 29f7d57:	jb     29fc727 <wasm[0]::function[1015]::helper::object_read+0x1b807>
 29f7d5d:	mov    %eax,%r8d
 29f7d60:	lea    (%rdx,%r8,1),%rax
 29f7d64:	cmp    %rcx,%r8
 29f7d67:	cmova  %rsi,%rax
 29f7d6b:	mov    %r13,%rcx
 29f7d6e:	shl    $0x3,%ecx
 29f7d71:	add    $0x18,%ecx
 29f7d77:	sub    %ecx,%edi
 29f7d79:	sub    %rdi,%rax
 29f7d7c:	mov    (%rax),%r12
 29f7d7f:	movl   $0x0,0xe0(%rsp)
 29f7d8a:	mov    0x270(%rsp),%rcx
 29f7d92:	mov    (%rcx),%eax
 29f7d94:	mov    %eax,%edx
 29f7d96:	lea    0x20(%rdx),%rcx
 29f7d9a:	mov    0x270(%rsp),%rsi
 29f7da2:	mov    0x4(%rsi),%esi
 29f7da5:	cmp    %rsi,%rcx
 29f7da8:	ja     29fb7c0 <wasm[0]::function[1015]::helper::object_read+0x1a8a0>
 29f7dae:	lea    0x20(%rax),%ecx
 29f7db1:	mov    0x270(%rsp),%rsi
 29f7db9:	mov    %ecx,(%rsi)
 29f7dbb:	mov    0x2e0(%rsp),%rcx
 29f7dc3:	mov    0x20(%rcx),%rsi
 29f7dc7:	lea    (%rsi,%rdx,1),%rcx
 29f7dcb:	movl   $0xb0000042,(%rsi,%rdx,1)
 29f7dd2:	mov    %r15d,0x4(%rsi,%rdx,1)
 29f7dd7:	mov    0x268(%rsp),%rdi
 29f7ddf:	mov    %edi,0x8(%rsi,%rdx,1)
 29f7de3:	mov    %eax,0xe8(%rsp)
 29f7dea:	mov    %r12,0x10(%rcx)
 29f7dee:	movl   $0x3,0x18(%rcx)
 29f7df5:	mov    0xe0(%rsp),%r9d
 29f7dfd:	mov    %r9d,0x1c(%rcx)
 29f7e01:	mov    0x190(%rsp),%rsi
 29f7e09:	mov    0xa20(%rsi),%r10d
 29f7e10:	mov    %r10d,0xe0(%rsp)
 29f7e18:	test   %eax,%eax
 29f7e1a:	je     29fc729 <wasm[0]::function[1015]::helper::object_read+0x1b809>
 29f7e20:	test   %r10d,%r10d
 29f7e23:	je     29fc72b <wasm[0]::function[1015]::helper::object_read+0x1b80b>
 29f7e29:	mov    0x270(%rsp),%rcx
 29f7e31:	mov    (%rcx),%eax
 29f7e33:	mov    %eax,%ecx
 29f7e35:	lea    0x20(%rcx),%rdx
 29f7e39:	mov    0x270(%rsp),%rsi
 29f7e41:	mov    0x4(%rsi),%esi
 29f7e44:	cmp    %rsi,%rdx
 29f7e47:	ja     29fb7f6 <wasm[0]::function[1015]::helper::object_read+0x1a8d6>
 29f7e4d:	lea    0x20(%rax),%edx
 29f7e50:	mov    0x270(%rsp),%r11
 29f7e58:	mov    %edx,(%r11)
 29f7e5b:	mov    0x2e0(%rsp),%r12
 29f7e63:	mov    0x20(%r12),%rdx
 29f7e68:	lea    (%rdx,%rcx,1),%rsi
 29f7e6c:	movl   $0xb0000072,(%rdx,%rcx,1)
 29f7e73:	mov    %r14d,0x4(%rdx,%rcx,1)
 29f7e78:	mov    0x268(%rsp),%rdi
 29f7e80:	mov    %edi,0x8(%rdx,%rcx,1)
 29f7e84:	movl   $0xe,0x10(%rsi)
 29f7e8b:	mov    0xe8(%rsp),%ecx
 29f7e92:	mov    %ecx,0x14(%rsi)
 29f7e95:	mov    0xe0(%rsp),%ecx
 29f7e9c:	mov    %ecx,0x18(%rsi)
 29f7e9f:	mov    %ecx,0x1c(%rsi)
 29f7ea2:	mov    0xc8(%rsp),%ecx
 29f7ea9:	test   %ecx,%ecx
 29f7eab:	je     29fc72d <wasm[0]::function[1015]::helper::object_read+0x1b80d>
 29f7eb1:	test   %eax,%eax
 29f7eb3:	je     29fc72f <wasm[0]::function[1015]::helper::object_read+0x1b80f>
 29f7eb9:	test   %ecx,%ecx
 29f7ebb:	je     29fc731 <wasm[0]::function[1015]::helper::object_read+0x1b811>
 29f7ec1:	mov    0x2e0(%rsp),%r12
 29f7ec9:	mov    0x28(%r12),%rdx
 29f7ece:	mov    0x20(%r12),%rsi
 29f7ed3:	mov    %ecx,%r9d
 29f7ed6:	lea    0x10(%rsi,%r9,1),%r8
 29f7edb:	xor    %rdi,%rdi
 29f7ede:	cmp    %rdx,%r9
 29f7ee1:	cmova  %rdi,%r8
 29f7ee5:	mov    (%r8),%r8d
 29f7ee8:	cmp    %r8d,%r13d
 29f7eeb:	jae    29fc733 <wasm[0]::function[1015]::helper::object_read+0x1b813>
 29f7ef1:	mov    %r8d,%r9d
 29f7ef4:	shl    $0x2,%r9
 29f7ef8:	shr    $0x20,%r9
 29f7efc:	test   %r9,%r9
 29f7eff:	jne    29fc735 <wasm[0]::function[1015]::helper::object_read+0x1b815>
 29f7f05:	shl    $0x2,%r8d
 29f7f09:	add    $0x14,%r8d
 29f7f0d:	jb     29fc737 <wasm[0]::function[1015]::helper::object_read+0x1b817>
 29f7f13:	add    %r8d,%ecx
 29f7f16:	jb     29fc739 <wasm[0]::function[1015]::helper::object_read+0x1b819>
 29f7f1c:	mov    %ecx,%r9d
 29f7f1f:	lea    (%rsi,%r9,1),%rcx
 29f7f23:	cmp    %rdx,%r9
 29f7f26:	cmova  %rdi,%rcx
 29f7f2a:	mov    %r13,%rdx
 29f7f2d:	shl    $0x2,%edx
 29f7f30:	add    $0x14,%edx
 29f7f36:	sub    %edx,%r8d
 29f7f39:	sub    %r8,%rcx
 29f7f3c:	mov    %eax,(%rcx)
 29f7f3e:	mov    0x78(%rsp),%ecx
 29f7f42:	mov    0x90(%rsp),%edx
 29f7f49:	mov    0x98(%rsp),%esi
 29f7f50:	mov    0xc0(%rsp),%edi
 29f7f57:	add    $0x1,%r13d
 29f7f5e:	jmp    29f7bf7 <wasm[0]::function[1015]::helper::object_read+0x16cd7>
 29f7f63:	mov    0x78(%rsp),%eax
 29f7f67:	test   %eax,%eax
 29f7f69:	je     29fc73b <wasm[0]::function[1015]::helper::object_read+0x1b81b>
 29f7f6f:	mov    0xc8(%rsp),%edx
 29f7f76:	test   %edx,%edx
 29f7f78:	je     29fc73d <wasm[0]::function[1015]::helper::object_read+0x1b81d>
 29f7f7e:	test   %eax,%eax
 29f7f80:	je     29fc73f <wasm[0]::function[1015]::helper::object_read+0x1b81f>
 29f7f86:	mov    0x2e0(%rsp),%r12
 29f7f8e:	mov    0x28(%r12),%rsi
 29f7f93:	mov    0x20(%r12),%rcx
 29f7f98:	mov    %eax,%edi
 29f7f9a:	add    %rdi,%rcx
 29f7f9d:	xor    %r8,%r8
 29f7fa0:	cmp    %rsi,%rdi
 29f7fa3:	cmova  %r8,%rcx
 29f7fa7:	mov    %edx,0x20(%rcx)
 29f7faa:	mov    0x190(%rsp),%rsi
 29f7fb2:	mov    0xa00(%rsi),%esi
 29f7fb8:	mov    0x190(%rsp),%rdx
 29f7fc0:	mov    0xa10(%rdx),%edx
 29f7fc6:	test   %esi,%esi
 29f7fc8:	je     29fc741 <wasm[0]::function[1015]::helper::object_read+0x1b821>
 29f7fce:	mov    %esi,0x28(%rcx)
 29f7fd1:	test   %edx,%edx
 29f7fd3:	je     29fc743 <wasm[0]::function[1015]::helper::object_read+0x1b823>
 29f7fd9:	mov    %edx,0x2c(%rcx)
 29f7fdc:	movl   $0x0,0x30(%rcx)
 29f7fe3:	movl   $0x0,0x24(%rcx)
 29f7fea:	mov    0x90(%rsp),%ecx
 29f7ff1:	mov    0x98(%rsp),%edx
 29f7ff8:	mov    %rdx,%r15
 29f7ffb:	mov    0xc0(%rsp),%edx
 29f8002:	jmp    29f856b <wasm[0]::function[1015]::helper::object_read+0x1764b>
 29f8007:	mov    0x88(%rsp),%eax
 29f800e:	test   %eax,%eax
 29f8010:	je     29fc745 <wasm[0]::function[1015]::helper::object_read+0x1b825>
 29f8016:	test   %eax,%eax
 29f8018:	je     29fc747 <wasm[0]::function[1015]::helper::object_read+0x1b827>
 29f801e:	mov    0x2e0(%rsp),%r12
 29f8026:	mov    0x28(%r12),%rsi
 29f802b:	mov    0x20(%r12),%rdi
 29f8030:	mov    %eax,%r9d
 29f8033:	lea    (%rdi,%r9,1),%rax
 29f8037:	xor    %r8,%r8
 29f803a:	cmp    %rsi,%r9
 29f803d:	cmova  %r8,%rax
 29f8041:	mov    0x30(%rax),%r9d
 29f8045:	mov    %r9d,0x78(%rsp)
 29f804a:	test   %r9d,%r9d
 29f804d:	je     29fc749 <wasm[0]::function[1015]::helper::object_read+0x1b829>
 29f8053:	test   %r9d,%r9d
 29f8056:	je     29fc74b <wasm[0]::function[1015]::helper::object_read+0x1b82b>
 29f805c:	mov    %r9d,%r10d
 29f805f:	lea    0x10(%rdi,%r10,1),%r9
 29f8064:	cmp    %rsi,%r10
 29f8067:	cmova  %r8,%r9
 29f806b:	mov    (%r9),%r10d
 29f806e:	mov    %r10d,%r13d
 29f8071:	mov    %r13,%r12
 29f8074:	shl    $0x2,%r12
 29f8078:	mov    %r12,%r11
 29f807b:	shr    $0x20,%r11
 29f807f:	test   %r11,%r11
 29f8082:	jne    29fc74d <wasm[0]::function[1015]::helper::object_read+0x1b82d>
 29f8088:	mov    %r10,%rcx
 29f808b:	shl    $0x2,%ecx
 29f808e:	mov    %r10,0x1d0(%rsp)
 29f8096:	add    $0x14,%ecx
 29f8099:	jb     29fc74f <wasm[0]::function[1015]::helper::object_read+0x1b82f>
 29f809f:	mov    0x270(%rsp),%rdi
 29f80a7:	mov    (%rdi),%eax
 29f80a9:	mov    %eax,%esi
 29f80ab:	mov    %ecx,%edx
 29f80ad:	add    $0xf,%rdx
 29f80b4:	mov    %rdx,%rdi
 29f80b7:	and    $0xfffffffffffffff0,%rdi
 29f80bb:	add    %rsi,%rdi
 29f80be:	mov    0x270(%rsp),%r8
 29f80c6:	mov    0x4(%r8),%r8d
 29f80ca:	cmp    %r8,%rdi
 29f80cd:	ja     29fb82d <wasm[0]::function[1015]::helper::object_read+0x1a90d>
 29f80d3:	add    $0xf,%ecx
 29f80d9:	and    $0xfffffff0,%ecx
 29f80dc:	add    %eax,%ecx
 29f80de:	mov    0x270(%rsp),%rdi
 29f80e6:	mov    %ecx,(%rdi)
 29f80e8:	mov    0x2e0(%rsp),%r10
 29f80f0:	mov    0x20(%r10),%rdi
 29f80f4:	lea    (%rdi,%rsi,1),%rcx
 29f80f8:	movl   $0xa800000e,(%rdi,%rsi,1)
 29f80ff:	mov    0x190(%rsp),%r8
 29f8107:	mov    0x28(%r8),%r8
 29f810b:	mov    0x194(%r8),%r8d
 29f8112:	mov    %r8d,0x4(%rdi,%rsi,1)
 29f8117:	and    $0xfffffffffffffff0,%rdx
 29f811b:	mov    %edx,0x8(%rdi,%rsi,1)
 29f811f:	mov    %eax,0x90(%rsp)
 29f8126:	mov    0x1d0(%rsp),%r14
 29f812e:	mov    %r14d,0x10(%rcx)
 29f8132:	test   %eax,%eax
 29f8134:	je     29fc751 <wasm[0]::function[1015]::helper::object_read+0x1b831>
 29f813a:	mov    0x2e0(%rsp),%rcx
 29f8142:	mov    0x28(%rcx),%rcx
 29f8146:	mov    0x2e0(%rsp),%rdx
 29f814e:	mov    0x20(%rdx),%rsi
 29f8152:	mov    %eax,%eax
 29f8154:	lea    (%rsi,%rax,1),%rdx
 29f8158:	lea    0x10(%rsi,%rax,1),%rdi
 29f815d:	xor    %r8,%r8
 29f8160:	cmp    %rcx,%rax
 29f8163:	cmova  %r8,%rdi
 29f8167:	mov    (%rdi),%edi
 29f8169:	cmp    %rdi,%r13
 29f816c:	ja     29fc753 <wasm[0]::function[1015]::helper::object_read+0x1b833>
 29f8172:	lea    0x14(%rsi,%rax,1),%rbx
 29f8177:	mov    %rbx,%rax
 29f817a:	add    %r12,%rax
 29f817d:	jb     29fc755 <wasm[0]::function[1015]::helper::object_read+0x1b835>
 29f8183:	add    %rsi,%rcx
 29f8186:	cmp    %rcx,%rax
 29f8189:	ja     29fc757 <wasm[0]::function[1015]::helper::object_read+0x1b837>
 29f818f:	mov    0x78(%rsp),%edi
 29f8193:	mov    0x88(%rsp),%r9d
 29f819b:	mov    0xa8(%rsp),%r11d
 29f81a3:	mov    0xb0(%rsp),%eax
 29f81aa:	mov    0xb8(%rsp),%ecx
 29f81b1:	lea    0x14(%rdx,%r13,4),%r12
 29f81b6:	test   %r13,%r13
 29f81b9:	je     29f8243 <wasm[0]::function[1015]::helper::object_read+0x17323>
 29f81bf:	mov    %edi,0xb8(%rsp)
 29f81c6:	mov    %r9d,0xb0(%rsp)
 29f81ce:	mov    %r11d,0xa8(%rsp)
 29f81d6:	mov    %eax,0x88(%rsp)
 29f81dd:	mov    %ecx,0x78(%rsp)
 29f81e1:	mov    0x2e8(%rsp),%r13
 29f81e9:	mov    0x0(%r13),%rax
 29f81ed:	mov    0x228(%rsp),%rcx
 29f81f5:	cmp    %rcx,%rax
 29f81f8:	jae    29fb86a <wasm[0]::function[1015]::helper::object_read+0x1a94a>
 29f81fe:	jmp    29f820b <wasm[0]::function[1015]::helper::object_read+0x172eb>
 29f8203:	mov    %rcx,0x228(%rsp)
 29f820b:	movl   $0x0,(%rbx)
 29f8211:	mov    0xb8(%rsp),%edi
 29f8218:	mov    0xb0(%rsp),%r9d
 29f8220:	mov    0xa8(%rsp),%r11d
 29f8228:	mov    0x88(%rsp),%eax
 29f822f:	mov    0x78(%rsp),%ecx
 29f8233:	add    $0x4,%rbx
 29f823a:	cmp    %r12,%rbx
 29f823d:	jne    29f81bf <wasm[0]::function[1015]::helper::object_read+0x1729f>
 29f8243:	mov    %edi,0xb8(%rsp)
 29f824a:	mov    0x190(%rsp),%rsi
 29f8252:	mov    0xa20(%rsi),%edx
 29f8258:	mov    %edx,0xb0(%rsp)
 29f825f:	xor    %ebx,%ebx
 29f8261:	mov    $0xb0000072,%r15d
 29f8267:	mov    %r15,0x1c8(%rsp)
 29f826f:	mov    0x28(%rsi),%rdx
 29f8273:	mov    0x13c(%rdx),%r14d
 29f827a:	mov    $0x20,%r13d
 29f8280:	mov    %r13,0x1a0(%rsp)
 29f8288:	mov    $0x10,%r13d
 29f828e:	mov    %r9d,0x98(%rsp)
 29f8296:	mov    %r11d,0x78(%rsp)
 29f829b:	mov    %eax,0x88(%rsp)
 29f82a2:	mov    %ecx,0xa8(%rsp)
 29f82a9:	mov    0x2e8(%rsp),%rax
 29f82b1:	mov    (%rax),%rax
 29f82b4:	mov    0x228(%rsp),%rcx
 29f82bc:	cmp    %rcx,%rax
 29f82bf:	jae    29fb899 <wasm[0]::function[1015]::helper::object_read+0x1a979>
 29f82c5:	mov    0x1d0(%rsp),%rcx
 29f82cd:	jmp    29f82e2 <wasm[0]::function[1015]::helper::object_read+0x173c2>
 29f82d2:	mov    %rcx,0x228(%rsp)
 29f82da:	mov    0x1d0(%rsp),%rcx
 29f82e2:	cmp    %ecx,%ebx
 29f82e4:	jae    29f84cc <wasm[0]::function[1015]::helper::object_read+0x175ac>
 29f82ea:	mov    0xb8(%rsp),%eax
 29f82f1:	test   %eax,%eax
 29f82f3:	je     29fc759 <wasm[0]::function[1015]::helper::object_read+0x1b839>
 29f82f9:	test   %eax,%eax
 29f82fb:	je     29fc75b <wasm[0]::function[1015]::helper::object_read+0x1b83b>
 29f8301:	mov    0x2e0(%rsp),%r12
 29f8309:	mov    0x28(%r12),%r9
 29f830e:	mov    0x20(%r12),%r10
 29f8313:	mov    %eax,%ecx
 29f8315:	lea    0x10(%r10,%rcx,1),%rsi
 29f831a:	xor    %r11,%r11
 29f831d:	cmp    %r9,%rcx
 29f8320:	cmova  %r11,%rsi
 29f8324:	mov    (%rsi),%ecx
 29f8326:	cmp    %ecx,%ebx
 29f8328:	jae    29fc75d <wasm[0]::function[1015]::helper::object_read+0x1b83d>
 29f832e:	mov    %ecx,%edx
 29f8330:	shl    $0x2,%rdx
 29f8334:	shr    $0x20,%rdx
 29f8338:	test   %rdx,%rdx
 29f833b:	jne    29fc75f <wasm[0]::function[1015]::helper::object_read+0x1b83f>
 29f8341:	shl    $0x2,%ecx
 29f8344:	add    $0x14,%ecx
 29f8347:	jb     29fc761 <wasm[0]::function[1015]::helper::object_read+0x1b841>
 29f834d:	add    %ecx,%eax
 29f834f:	jb     29fc763 <wasm[0]::function[1015]::helper::object_read+0x1b843>
 29f8355:	mov    %eax,%edx
 29f8357:	lea    (%r10,%rdx,1),%rax
 29f835b:	cmp    %r9,%rdx
 29f835e:	cmova  %r11,%rax
 29f8362:	mov    %rbx,%r15
 29f8365:	shl    $0x2,%r15d
 29f8369:	lea    0x14(%r15),%edx
 29f836d:	sub    %edx,%ecx
 29f836f:	sub    %rcx,%rax
 29f8372:	mov    (%rax),%eax
 29f8374:	mov    %eax,0xc0(%rsp)
 29f837b:	test   %eax,%eax
 29f837d:	je     29f84a6 <wasm[0]::function[1015]::helper::object_read+0x17586>
 29f8383:	test   %eax,%eax
 29f8385:	je     29fc765 <wasm[0]::function[1015]::helper::object_read+0x1b845>
 29f838b:	mov    0xb0(%rsp),%eax
 29f8392:	test   %eax,%eax
 29f8394:	je     29fc767 <wasm[0]::function[1015]::helper::object_read+0x1b847>
 29f839a:	mov    0x270(%rsp),%rcx
 29f83a2:	mov    (%rcx),%eax
 29f83a4:	mov    %eax,%edx
 29f83a6:	lea    0x20(%rdx),%rcx
 29f83aa:	mov    0x270(%rsp),%rsi
 29f83b2:	mov    0x4(%rsi),%esi
 29f83b5:	cmp    %rsi,%rcx
 29f83b8:	ja     29fb8d1 <wasm[0]::function[1015]::helper::object_read+0x1a9b1>
 29f83be:	lea    0x20(%rax),%ecx
 29f83c1:	mov    0x270(%rsp),%rsi
 29f83c9:	mov    %ecx,(%rsi)
 29f83cb:	mov    0x2e0(%rsp),%r12
 29f83d3:	mov    0x20(%r12),%rsi
 29f83d8:	lea    (%rsi,%rdx,1),%rcx
 29f83dc:	movl   $0xb0000072,(%rsi,%rdx,1)
 29f83e3:	mov    %r14d,0x4(%rsi,%rdx,1)
 29f83e8:	mov    0x268(%rsp),%rdi
 29f83f0:	mov    %edi,0x8(%rsi,%rdx,1)
 29f83f4:	movl   $0xe,0x10(%rcx)
 29f83fb:	mov    0xc0(%rsp),%edx
 29f8402:	mov    %edx,0x14(%rcx)
 29f8405:	mov    0xb0(%rsp),%edx
 29f840c:	mov    %edx,0x18(%rcx)
 29f840f:	mov    %edx,0x1c(%rcx)
 29f8412:	mov    0x90(%rsp),%ecx
 29f8419:	test   %ecx,%ecx
 29f841b:	je     29fc769 <wasm[0]::function[1015]::helper::object_read+0x1b849>
 29f8421:	test   %eax,%eax
 29f8423:	je     29fc76b <wasm[0]::function[1015]::helper::object_read+0x1b84b>
 29f8429:	test   %ecx,%ecx
 29f842b:	je     29fc76d <wasm[0]::function[1015]::helper::object_read+0x1b84d>
 29f8431:	mov    0x2e0(%rsp),%r12
 29f8439:	mov    0x28(%r12),%rdx
 29f843e:	mov    0x20(%r12),%rsi
 29f8443:	mov    %ecx,%r9d
 29f8446:	lea    0x10(%rsi,%r9,1),%r8
 29f844b:	xor    %rdi,%rdi
 29f844e:	cmp    %rdx,%r9
 29f8451:	cmova  %rdi,%r8
 29f8455:	mov    (%r8),%r8d
 29f8458:	cmp    %r8d,%ebx
 29f845b:	jae    29fc76f <wasm[0]::function[1015]::helper::object_read+0x1b84f>
 29f8461:	mov    %r8d,%r9d
 29f8464:	shl    $0x2,%r9
 29f8468:	shr    $0x20,%r9
 29f846c:	test   %r9,%r9
 29f846f:	jne    29fc771 <wasm[0]::function[1015]::helper::object_read+0x1b851>
 29f8475:	shl    $0x2,%r8d
 29f8479:	add    $0x14,%r8d
 29f847d:	jb     29fc773 <wasm[0]::function[1015]::helper::object_read+0x1b853>
 29f8483:	add    %r8d,%ecx
 29f8486:	jb     29fc775 <wasm[0]::function[1015]::helper::object_read+0x1b855>
 29f848c:	mov    %ecx,%r9d
 29f848f:	lea    (%rsi,%r9,1),%rcx
 29f8493:	cmp    %rdx,%r9
 29f8496:	cmova  %rdi,%rcx
 29f849a:	lea    0x14(%r15),%edx
 29f849e:	sub    %edx,%r8d
 29f84a1:	sub    %r8,%rcx
 29f84a4:	mov    %eax,(%rcx)
 29f84a6:	mov    0x98(%rsp),%r9d
 29f84ae:	mov    0x78(%rsp),%r11d
 29f84b3:	mov    0x88(%rsp),%eax
 29f84ba:	mov    0xa8(%rsp),%ecx
 29f84c1:	add    $0x1,%ebx
 29f84c7:	jmp    29f828e <wasm[0]::function[1015]::helper::object_read+0x1736e>
 29f84cc:	mov    0x98(%rsp),%eax
 29f84d3:	test   %eax,%eax
 29f84d5:	je     29fc777 <wasm[0]::function[1015]::helper::object_read+0x1b857>
 29f84db:	mov    0x90(%rsp),%edx
 29f84e2:	test   %edx,%edx
 29f84e4:	je     29fc779 <wasm[0]::function[1015]::helper::object_read+0x1b859>
 29f84ea:	test   %eax,%eax
 29f84ec:	je     29fc77b <wasm[0]::function[1015]::helper::object_read+0x1b85b>
 29f84f2:	mov    0x2e0(%rsp),%r12
 29f84fa:	mov    0x28(%r12),%rsi
 29f84ff:	mov    0x20(%r12),%rcx
 29f8504:	mov    %eax,%edi
 29f8506:	add    %rdi,%rcx
 29f8509:	xor    %r8,%r8
 29f850c:	cmp    %rsi,%rdi
 29f850f:	cmova  %r8,%rcx
 29f8513:	mov    %edx,0x20(%rcx)
 29f8516:	mov    0x190(%rsp),%rsi
 29f851e:	mov    0xa00(%rsi),%esi
 29f8524:	mov    0x190(%rsp),%rdi
 29f852c:	mov    0xa10(%rdi),%edx
 29f8532:	test   %esi,%esi
 29f8534:	je     29fc77d <wasm[0]::function[1015]::helper::object_read+0x1b85d>
 29f853a:	mov    %esi,0x28(%rcx)
 29f853d:	test   %edx,%edx
 29f853f:	je     29fc77f <wasm[0]::function[1015]::helper::object_read+0x1b85f>
 29f8545:	mov    %edx,0x2c(%rcx)
 29f8548:	movl   $0x0,0x30(%rcx)
 29f854f:	movl   $0x0,0x24(%rcx)
 29f8556:	mov    0x78(%rsp),%ecx
 29f855a:	mov    0x88(%rsp),%edx
 29f8561:	mov    %rdx,%r15
 29f8564:	mov    0xa8(%rsp),%edx
 29f856b:	test   %eax,%eax
 29f856d:	je     29fc781 <wasm[0]::function[1015]::helper::object_read+0x1b861>
 29f8573:	test   %eax,%eax
 29f8575:	je     29fc783 <wasm[0]::function[1015]::helper::object_read+0x1b863>
 29f857b:	mov    0x2e0(%rsp),%r12
 29f8583:	mov    0x28(%r12),%r8
 29f8588:	mov    0x20(%r12),%r10
 29f858d:	mov    %eax,%eax
 29f858f:	lea    (%r10,%rax,1),%r9
 29f8593:	xor    %r11,%r11
 29f8596:	cmp    %r8,%rax
 29f8599:	cmova  %r11,%r9
 29f859d:	mov    0x10(%r9),%edi
 29f85a1:	test   %edi,%edi
 29f85a3:	je     29fc785 <wasm[0]::function[1015]::helper::object_read+0x1b865>
 29f85a9:	test   %edi,%edi
 29f85ab:	je     29fc787 <wasm[0]::function[1015]::helper::object_read+0x1b867>
 29f85b1:	mov    %edi,%esi
 29f85b3:	lea    0x10(%r10,%rsi,1),%r10
 29f85b8:	cmp    %r8,%rsi
 29f85bb:	cmova  %r11,%r10
 29f85bf:	mov    (%r10),%r11d
 29f85c2:	mov    0x24(%r9),%r8d
 29f85c6:	test   %r8d,%r8d
 29f85c9:	je     29f87d2 <wasm[0]::function[1015]::helper::object_read+0x178b2>
 29f85cf:	xor    %eax,%eax
 29f85d1:	test   %r11d,%r11d
 29f85d4:	je     29f889d <wasm[0]::function[1015]::helper::object_read+0x1797d>
 29f85da:	mov    0x2e0(%rsp),%r12
 29f85e2:	mov    0x28(%r12),%rax
 29f85e7:	mov    0x20(%r12),%r10
 29f85ec:	lea    0x10(%r10,%rsi,1),%r9
 29f85f1:	xor    %r8,%r8
 29f85f4:	cmp    %rax,%rsi
 29f85f7:	cmova  %r8,%r9
 29f85fb:	mov    (%r9),%r9d
 29f85fe:	mov    0x198(%rsp),%rsi
 29f8606:	mov    %rsi,%rbx
 29f8609:	shr    $0x10,%ebx
 29f860c:	mov    %rsi,%r12
 29f860f:	xor    %ebx,%r12d
 29f8612:	imul   $0x7feb352d,%r12d,%ebx
 29f8619:	mov    %rbx,%r12
 29f861c:	shr    $0xf,%r12d
 29f8620:	xor    %r12d,%ebx
 29f8623:	imul   $0x846ca68b,%ebx,%r12d
 29f862a:	mov    %r12,%rbx
 29f862d:	shr    $0x10,%ebx
 29f8630:	xor    %ebx,%r12d
 29f8633:	sub    $0x1,%r11d
 29f8637:	and    %r11d,%r12d
 29f863a:	cmp    %r9d,%r12d
 29f863d:	jae    29fc789 <wasm[0]::function[1015]::helper::object_read+0x1b869>
 29f8643:	mov    %r9d,%r11d
 29f8646:	shl    $0x2,%r11
 29f864a:	shr    $0x20,%r11
 29f864e:	test   %r11,%r11
 29f8651:	jne    29fc78b <wasm[0]::function[1015]::helper::object_read+0x1b86b>
 29f8657:	shl    $0x2,%r9d
 29f865b:	add    $0x14,%r9d
 29f865f:	jb     29fc78d <wasm[0]::function[1015]::helper::object_read+0x1b86d>
 29f8665:	add    %r9d,%edi
 29f8668:	jb     29fc78f <wasm[0]::function[1015]::helper::object_read+0x1b86f>
 29f866e:	mov    %edi,%r11d
 29f8671:	lea    (%r10,%r11,1),%rdi
 29f8675:	cmp    %rax,%r11
 29f8678:	cmova  %r8,%rdi
 29f867c:	shl    $0x2,%r12d
 29f8680:	lea    0x14(%r12),%eax
 29f8685:	sub    %eax,%r9d
 29f8688:	sub    %r9,%rdi
 29f868b:	mov    (%rdi),%eax
 29f868d:	xor    %edi,%edi
 29f868f:	mov    %esi,%ebx
 29f8691:	mov    %eax,0x90(%rsp)
 29f8698:	mov    %edi,0xa8(%rsp)
 29f869f:	mov    %ecx,0x88(%rsp)
 29f86a6:	mov    %r15,%rax
 29f86a9:	mov    %eax,0x78(%rsp)
 29f86ad:	mov    %edx,0x98(%rsp)
 29f86b4:	mov    0x2e8(%rsp),%r13
 29f86bc:	mov    0x0(%r13),%rax
 29f86c0:	mov    0x228(%rsp),%rcx
 29f86c8:	cmp    %rcx,%rax
 29f86cb:	jae    29fb908 <wasm[0]::function[1015]::helper::object_read+0x1a9e8>
 29f86d1:	jmp    29f86de <wasm[0]::function[1015]::helper::object_read+0x177be>
 29f86d6:	mov    %rcx,0x228(%rsp)
 29f86de:	mov    0x90(%rsp),%ecx
 29f86e5:	mov    0xa8(%rsp),%eax
 29f86ec:	test   %ecx,%ecx
 29f86ee:	je     29f87b8 <wasm[0]::function[1015]::helper::object_read+0x17898>
 29f86f4:	mov    0x90(%rsp),%ecx
 29f86fb:	test   %ecx,%ecx
 29f86fd:	je     29fc791 <wasm[0]::function[1015]::helper::object_read+0x1b871>
 29f8703:	mov    0x2e0(%rsp),%r12
 29f870b:	mov    0x28(%r12),%rax
 29f8710:	mov    %ecx,%edx
 29f8712:	mov    %rdx,%rcx
 29f8715:	add    0x20(%r12),%rcx
 29f871a:	xor    %rsi,%rsi
 29f871d:	cmp    %rax,%rdx
 29f8720:	cmova  %rsi,%rcx
 29f8724:	mov    0x10(%rcx),%rax
 29f8728:	cmp    %rbx,%rax
 29f872b:	je     29f8785 <wasm[0]::function[1015]::helper::object_read+0x17865>
 29f8731:	mov    0x90(%rsp),%ecx
 29f8738:	test   %ecx,%ecx
 29f873a:	je     29fc793 <wasm[0]::function[1015]::helper::object_read+0x1b873>
 29f8740:	mov    0x2e0(%rsp),%r12
 29f8748:	mov    0x28(%r12),%rax
 29f874d:	mov    %ecx,%edx
 29f874f:	mov    %rdx,%rcx
 29f8752:	add    0x20(%r12),%rcx
 29f8757:	xor    %rsi,%rsi
 29f875a:	cmp    %rax,%rdx
 29f875d:	cmova  %rsi,%rcx
 29f8761:	mov    0x1c(%rcx),%eax
 29f8764:	mov    0xa8(%rsp),%edi
 29f876b:	mov    0x88(%rsp),%ecx
 29f8772:	mov    0x78(%rsp),%edx
 29f8776:	mov    %rdx,%r15
 29f8779:	mov    0x98(%rsp),%edx
 29f8780:	jmp    29f8691 <wasm[0]::function[1015]::helper::object_read+0x17771>
 29f8785:	mov    0x90(%rsp),%ecx
 29f878c:	test   %ecx,%ecx
 29f878e:	je     29fc795 <wasm[0]::function[1015]::helper::object_read+0x1b875>
 29f8794:	mov    0x2e0(%rsp),%r12
 29f879c:	mov    0x28(%r12),%rax
 29f87a1:	mov    %ecx,%edx
 29f87a3:	mov    %rdx,%rcx
 29f87a6:	add    0x20(%r12),%rcx
 29f87ab:	xor    %rsi,%rsi
 29f87ae:	cmp    %rax,%rdx
 29f87b1:	cmova  %rsi,%rcx
 29f87b5:	mov    0x18(%rcx),%eax
 29f87b8:	mov    0x88(%rsp),%ecx
 29f87bf:	mov    0x78(%rsp),%edx
 29f87c3:	mov    %rdx,%r15
 29f87c6:	mov    0x98(%rsp),%edx
 29f87cd:	jmp    29f889d <wasm[0]::function[1015]::helper::object_read+0x1797d>
 29f87d2:	mov    0x198(%rsp),%rsi
 29f87da:	mov    0x2e0(%rsp),%r12
 29f87e2:	mov    0x28(%r12),%r8
 29f87e7:	mov    0x20(%r12),%r10
 29f87ec:	lea    (%r10,%rax,1),%rdi
 29f87f0:	xor    %r9,%r9
 29f87f3:	cmp    %r8,%rax
 29f87f6:	cmova  %r9,%rdi
 29f87fa:	mov    0x20(%rdi),%edi
 29f87fd:	xor    %eax,%eax
 29f87ff:	test   %edi,%edi
 29f8801:	je     29fc797 <wasm[0]::function[1015]::helper::object_read+0x1b877>
 29f8807:	test   %edi,%edi
 29f8809:	je     29fc799 <wasm[0]::function[1015]::helper::object_read+0x1b879>
 29f880f:	mov    %edi,%r12d
 29f8812:	lea    0x10(%r10,%r12,1),%r10
 29f8817:	cmp    %r8,%r12
 29f881a:	cmova  %r9,%r10
 29f881e:	mov    %esi,%r8d
 29f8821:	mov    (%r10),%r9d
 29f8824:	cmp    %r9,%r8
 29f8827:	jae    29f889d <wasm[0]::function[1015]::helper::object_read+0x1797d>
 29f882d:	mov    0x2e0(%rsp),%rax
 29f8835:	mov    0x28(%rax),%r10
 29f8839:	mov    0x20(%rax),%r8
 29f883d:	lea    0x10(%r8,%r12,1),%r9
 29f8842:	xor    %r11,%r11
 29f8845:	cmp    %r10,%r12
 29f8848:	cmova  %r11,%r9
 29f884c:	mov    (%r9),%eax
 29f884f:	cmp    %eax,%esi
 29f8851:	jae    29fc79b <wasm[0]::function[1015]::helper::object_read+0x1b87b>
 29f8857:	mov    %eax,%r9d
 29f885a:	shl    $0x2,%r9
 29f885e:	shr    $0x20,%r9
 29f8862:	test   %r9,%r9
 29f8865:	jne    29fc79d <wasm[0]::function[1015]::helper::object_read+0x1b87d>
 29f886b:	shl    $0x2,%eax
 29f886e:	add    $0x14,%eax
 29f8871:	jb     29fc79f <wasm[0]::function[1015]::helper::object_read+0x1b87f>
 29f8877:	add    %eax,%edi
 29f8879:	jb     29fc7a1 <wasm[0]::function[1015]::helper::object_read+0x1b881>
 29f887f:	mov    %edi,%r9d
 29f8882:	lea    (%r8,%r9,1),%rdi
 29f8886:	cmp    %r10,%r9
 29f8889:	cmova  %r11,%rdi
 29f888d:	shl    $0x2,%esi
 29f8890:	add    $0x14,%esi
 29f8896:	sub    %esi,%eax
 29f8898:	sub    %rax,%rdi
 29f889b:	mov    (%rdi),%eax
 29f889d:	mov    %ecx,0x78(%rsp)
 29f88a1:	mov    %edx,0x88(%rsp)
 29f88a8:	test   %eax,%eax
 29f88aa:	je     29f8bdf <wasm[0]::function[1015]::helper::object_read+0x17cbf>
 29f88b0:	test   %eax,%eax
 29f88b2:	jne    29f88c0 <wasm[0]::function[1015]::helper::object_read+0x179a0>
 29f88b8:	xor    %r14d,%r14d
 29f88bb:	jmp    29f88f9 <wasm[0]::function[1015]::helper::object_read+0x179d9>
 29f88c0:	test   %eax,%eax
 29f88c2:	je     29fc7a3 <wasm[0]::function[1015]::helper::object_read+0x1b883>
 29f88c8:	mov    0x2e0(%rsp),%r12
 29f88d0:	mov    0x28(%r12),%rcx
 29f88d5:	mov    %eax,%esi
 29f88d7:	mov    %rsi,%rdx
 29f88da:	add    0x20(%r12),%rdx
 29f88df:	xor    %rdi,%rdi
 29f88e2:	cmp    %rcx,%rsi
 29f88e5:	cmova  %rdi,%rdx
 29f88e9:	mov    0x10(%rdx),%ecx
 29f88ec:	test   $0x4,%ecx
 29f88f2:	setne  %cl
 29f88f5:	movzbl %cl,%r14d
 29f88f9:	test   %eax,%eax
 29f88fb:	jne    29f8908 <wasm[0]::function[1015]::helper::object_read+0x179e8>
 29f8901:	xor    %ebx,%ebx
 29f8903:	jmp    29f8940 <wasm[0]::function[1015]::helper::object_read+0x17a20>
 29f8908:	test   %eax,%eax
 29f890a:	je     29fc7a5 <wasm[0]::function[1015]::helper::object_read+0x1b885>
 29f8910:	mov    0x2e0(%rsp),%r12
 29f8918:	mov    0x28(%r12),%rcx
 29f891d:	mov    %eax,%esi
 29f891f:	mov    %rsi,%rdx
 29f8922:	add    0x20(%r12),%rdx
 29f8927:	xor    %rdi,%rdi
 29f892a:	cmp    %rcx,%rsi
 29f892d:	cmova  %rdi,%rdx
 29f8931:	mov    0x10(%rdx),%ecx
 29f8934:	test   $0x8,%ecx
 29f893a:	setne  %cl
 29f893d:	movzbl %cl,%ebx
 29f8940:	test   %eax,%eax
 29f8942:	jne    29f8950 <wasm[0]::function[1015]::helper::object_read+0x17a30>
 29f8948:	xor    %r13d,%r13d
 29f894b:	jmp    29f8989 <wasm[0]::function[1015]::helper::object_read+0x17a69>
 29f8950:	test   %eax,%eax
 29f8952:	je     29fc7a7 <wasm[0]::function[1015]::helper::object_read+0x1b887>
 29f8958:	mov    0x2e0(%rsp),%r12
 29f8960:	mov    0x28(%r12),%rcx
 29f8965:	mov    %eax,%esi
 29f8967:	mov    %rsi,%rdx
 29f896a:	add    0x20(%r12),%rdx
 29f896f:	xor    %rdi,%rdi
 29f8972:	cmp    %rcx,%rsi
 29f8975:	cmova  %rdi,%rdx
 29f8979:	mov    0x10(%rdx),%ecx
 29f897c:	test   $0x2,%ecx
 29f8982:	setne  %cl
 29f8985:	movzbl %cl,%r13d
 29f8989:	test   %eax,%eax
 29f898b:	je     29fc7a9 <wasm[0]::function[1015]::helper::object_read+0x1b889>
 29f8991:	mov    0x2e0(%rsp),%r12
 29f8999:	mov    0x28(%r12),%rsi
 29f899e:	mov    0x20(%r12),%rdx
 29f89a3:	mov    %eax,%ecx
 29f89a5:	add    %rcx,%rdx
 29f89a8:	xor    %rdi,%rdi
 29f89ab:	cmp    %rsi,%rcx
 29f89ae:	cmova  %rdi,%rdx
 29f89b2:	mov    0x14(%rdx),%esi
 29f89b5:	mov    %esi,0x98(%rsp)
 29f89bc:	mov    0x18(%rdx),%esi
 29f89bf:	mov    %esi,0x90(%rsp)
 29f89c6:	mov    0x1c(%rdx),%edx
 29f89c9:	mov    %edx,0xa8(%rsp)
 29f89d0:	test   %eax,%eax
 29f89d2:	jne    29f89df <wasm[0]::function[1015]::helper::object_read+0x17abf>
 29f89d8:	xor    %eax,%eax
 29f89da:	jmp    29f8a0c <wasm[0]::function[1015]::helper::object_read+0x17aec>
 29f89df:	mov    0x2e0(%rsp),%r12
 29f89e7:	mov    0x28(%r12),%rdx
 29f89ec:	mov    %rcx,%rax
 29f89ef:	add    0x20(%r12),%rax
 29f89f4:	xor    %rsi,%rsi
 29f89f7:	cmp    %rdx,%rcx
 29f89fa:	cmova  %rsi,%rax
 29f89fe:	mov    0x10(%rax),%eax
 29f8a01:	test   $0x1,%eax
 29f8a06:	setne  %al
 29f8a09:	movzbl %al,%eax
 29f8a0c:	test   %eax,%eax
 29f8a0e:	jne    29f8b02 <wasm[0]::function[1015]::helper::object_read+0x17be2>
 29f8a14:	mov    0x98(%rsp),%edx
 29f8a1b:	test   %edx,%edx
 29f8a1d:	je     29fc7ab <wasm[0]::function[1015]::helper::object_read+0x1b88b>
 29f8a23:	mov    0x90(%rsp),%esi
 29f8a2a:	test   %esi,%esi
 29f8a2c:	je     29fc7ad <wasm[0]::function[1015]::helper::object_read+0x1b88d>
 29f8a32:	mov    0xa8(%rsp),%esi
 29f8a39:	test   %esi,%esi
 29f8a3b:	je     29fc7af <wasm[0]::function[1015]::helper::object_read+0x1b88f>
 29f8a41:	mov    0x270(%rsp),%rcx
 29f8a49:	mov    (%rcx),%eax
 29f8a4b:	mov    %rax,%r15
 29f8a4e:	mov    %eax,%r8d
 29f8a51:	lea    0x20(%r8),%r9
 29f8a55:	mov    0x4(%rcx),%r10d
 29f8a59:	cmp    %r10,%r9
 29f8a5c:	ja     29fb938 <wasm[0]::function[1015]::helper::object_read+0x1aa18>
 29f8a62:	mov    %r15,%rax
 29f8a65:	lea    0x20(%rax),%r11d
 29f8a69:	mov    0x270(%rsp),%rcx
 29f8a71:	mov    %r11d,(%rcx)
 29f8a74:	mov    0x2e0(%rsp),%r12
 29f8a7c:	mov    0x20(%r12),%rcx
 29f8a81:	lea    (%rcx,%r8,1),%rax
 29f8a85:	movl   $0xb0000072,(%rcx,%r8,1)
 29f8a8d:	mov    0x190(%rsp),%rsi
 29f8a95:	mov    0x28(%rsi),%rdx
 29f8a99:	mov    0x13c(%rdx),%edx
 29f8a9f:	mov    %edx,0x4(%rcx,%r8,1)
 29f8aa4:	mov    0x268(%rsp),%rdx
 29f8aac:	mov    %edx,0x8(%rcx,%r8,1)
 29f8ab1:	test   %r14d,%r14d
 29f8ab4:	setne  %cl
 29f8ab7:	movzbl %cl,%r8d
 29f8abb:	shl    $0x2,%r8d
 29f8abf:	test   %ebx,%ebx
 29f8ac1:	setne  %cl
 29f8ac4:	movzbl %cl,%ecx
 29f8ac7:	shl    $0x3,%ecx
 29f8aca:	or     %ecx,%r8d
 29f8acd:	test   %r13d,%r13d
 29f8ad0:	setne  %cl
 29f8ad3:	movzbl %cl,%ecx
 29f8ad6:	shl    $1,%ecx
 29f8ad8:	or     %ecx,%r8d
 29f8adb:	mov    %r8d,0x10(%rax)
 29f8adf:	mov    0x98(%rsp),%ecx
 29f8ae6:	mov    %ecx,0x14(%rax)
 29f8ae9:	mov    0x90(%rsp),%ecx
 29f8af0:	mov    %ecx,0x18(%rax)
 29f8af3:	mov    0xa8(%rsp),%ecx
 29f8afa:	mov    %ecx,0x1c(%rax)
 29f8afd:	jmp    29f8bdf <wasm[0]::function[1015]::helper::object_read+0x17cbf>
 29f8b02:	mov    0x98(%rsp),%eax
 29f8b09:	test   %eax,%eax
 29f8b0b:	je     29fc7b1 <wasm[0]::function[1015]::helper::object_read+0x1b891>
 29f8b11:	mov    0x90(%rsp),%eax
 29f8b18:	test   %eax,%eax
 29f8b1a:	je     29fc7b3 <wasm[0]::function[1015]::helper::object_read+0x1b893>
 29f8b20:	mov    0xa8(%rsp),%eax
 29f8b27:	test   %eax,%eax
 29f8b29:	je     29fc7b5 <wasm[0]::function[1015]::helper::object_read+0x1b895>
 29f8b2f:	mov    0x270(%rsp),%rcx
 29f8b37:	mov    (%rcx),%eax
 29f8b39:	mov    %rax,%r15
 29f8b3c:	mov    %eax,%ecx
 29f8b3e:	lea    0x20(%rcx),%rax
 29f8b42:	mov    0x270(%rsp),%rsi
 29f8b4a:	mov    0x4(%rsi),%edx
 29f8b4d:	cmp    %rdx,%rax
 29f8b50:	ja     29fb97f <wasm[0]::function[1015]::helper::object_read+0x1aa5f>
 29f8b56:	mov    %r15,%rax
 29f8b59:	add    $0x20,%eax
 29f8b5f:	mov    0x270(%rsp),%rdx
 29f8b67:	mov    %eax,(%rdx)
 29f8b69:	mov    0x2e0(%rsp),%r12
 29f8b71:	mov    0x20(%r12),%rdx
 29f8b76:	lea    (%rdx,%rcx,1),%rax
 29f8b7a:	movl   $0xb0000072,(%rdx,%rcx,1)
 29f8b81:	mov    0x190(%rsp),%rsi
 29f8b89:	mov    0x28(%rsi),%rsi
 29f8b8d:	mov    0x13c(%rsi),%esi
 29f8b93:	mov    %esi,0x4(%rdx,%rcx,1)
 29f8b97:	mov    0x268(%rsp),%rsi
 29f8b9f:	mov    %esi,0x8(%rdx,%rcx,1)
 29f8ba3:	test   %ebx,%ebx
 29f8ba5:	setne  %cl
 29f8ba8:	movzbl %cl,%ecx
 29f8bab:	shl    $0x3,%ecx
 29f8bae:	or     $0x1,%ecx
 29f8bb1:	test   %r13d,%r13d
 29f8bb4:	setne  %dl
 29f8bb7:	movzbl %dl,%edx
 29f8bba:	shl    $1,%edx
 29f8bbc:	or     %edx,%ecx
 29f8bbe:	mov    %ecx,0x10(%rax)
 29f8bc1:	mov    0x98(%rsp),%ecx
 29f8bc8:	mov    %ecx,0x14(%rax)
 29f8bcb:	mov    0x90(%rsp),%ecx
 29f8bd2:	mov    %ecx,0x18(%rax)
 29f8bd5:	mov    0xa8(%rsp),%ecx
 29f8bdc:	mov    %ecx,0x1c(%rax)
 29f8bdf:	mov    0x78(%rsp),%eax
 29f8be3:	mov    0x88(%rsp),%ecx
 29f8bea:	jmp    29f8fba <wasm[0]::function[1015]::helper::object_read+0x1809a>
 29f8bef:	xor    %eax,%eax
 29f8bf1:	test   %edx,%edx
 29f8bf3:	je     29f8c44 <wasm[0]::function[1015]::helper::object_read+0x17d24>
 29f8bf9:	xor    %eax,%eax
 29f8bfb:	test   $0x1,%edx
 29f8c01:	jne    29f8c44 <wasm[0]::function[1015]::helper::object_read+0x17d24>
 29f8c07:	mov    0x2e0(%rsp),%r12
 29f8c0f:	mov    0x28(%r12),%rax
 29f8c14:	mov    0x20(%r12),%rcx
 29f8c19:	mov    %edx,%esi
 29f8c1b:	lea    0x4(%rcx,%rsi,1),%rcx
 29f8c20:	xor    %rdi,%rdi
 29f8c23:	cmp    %rax,%rsi
 29f8c26:	cmova  %rdi,%rcx
 29f8c2a:	mov    (%rcx),%eax
 29f8c2c:	mov    0x190(%rsp),%rsi
 29f8c34:	mov    0x28(%rsi),%rcx
 29f8c38:	cmp    0x138(%rcx),%eax
 29f8c3e:	sete   %al
 29f8c41:	movzbl %al,%eax
 29f8c44:	test   %eax,%eax
 29f8c46:	je     29fc7b7 <wasm[0]::function[1015]::helper::object_read+0x1b897>
 29f8c4c:	test   %edx,%edx
 29f8c4e:	je     29fc7b9 <wasm[0]::function[1015]::helper::object_read+0x1b899>
 29f8c54:	mov    0x68(%rsp),%r9d
 29f8c59:	mov    0x1b8(%rsp),%rcx
 29f8c61:	mov    0x1c0(%rsp),%r8
 29f8c69:	mov    0x190(%rsp),%rsi
 29f8c71:	mov    0x190(%rsp),%rdi
 29f8c79:	call   29ffc00 <wasm[0]::function[1019]::helper::ordinary_own_descriptor>
 29f8c7e:	mov    0xa0(%rsp),%ecx
 29f8c85:	mov    %rcx,%r15
 29f8c88:	test   %eax,%eax
 29f8c8a:	je     29f8faf <wasm[0]::function[1015]::helper::object_read+0x1808f>
 29f8c90:	test   %eax,%eax
 29f8c92:	jne    29f8c9f <wasm[0]::function[1015]::helper::object_read+0x17d7f>
 29f8c98:	xor    %ebx,%ebx
 29f8c9a:	jmp    29f8cda <wasm[0]::function[1015]::helper::object_read+0x17dba>
 29f8c9f:	test   %eax,%eax
 29f8ca1:	je     29fc7bb <wasm[0]::function[1015]::helper::object_read+0x1b89b>
 29f8ca7:	mov    0x2e0(%rsp),%r12
 29f8caf:	mov    0x28(%r12),%rsi
 29f8cb4:	mov    %eax,%r8d
 29f8cb7:	mov    %r8,%rdi
 29f8cba:	add    0x20(%r12),%rdi
 29f8cbf:	xor    %r9,%r9
 29f8cc2:	cmp    %rsi,%r8
 29f8cc5:	cmova  %r9,%rdi
 29f8cc9:	mov    0x10(%rdi),%edi
 29f8ccc:	test   $0x4,%edi
 29f8cd2:	setne  %r8b
 29f8cd6:	movzbl %r8b,%ebx
 29f8cda:	test   %eax,%eax
 29f8cdc:	jne    29f8cea <wasm[0]::function[1015]::helper::object_read+0x17dca>
 29f8ce2:	xor    %r14d,%r14d
 29f8ce5:	jmp    29f8d24 <wasm[0]::function[1015]::helper::object_read+0x17e04>
 29f8cea:	test   %eax,%eax
 29f8cec:	je     29fc7bd <wasm[0]::function[1015]::helper::object_read+0x1b89d>
 29f8cf2:	mov    0x2e0(%rsp),%r12
 29f8cfa:	mov    0x28(%r12),%rcx
 29f8cff:	mov    %eax,%edx
 29f8d01:	mov    %rdx,%r11
 29f8d04:	add    0x20(%r12),%r11
 29f8d09:	xor    %rsi,%rsi
 29f8d0c:	cmp    %rcx,%rdx
 29f8d0f:	cmova  %rsi,%r11
 29f8d13:	mov    0x10(%r11),%ecx
 29f8d17:	test   $0x8,%ecx
 29f8d1d:	setne  %cl
 29f8d20:	movzbl %cl,%r14d
 29f8d24:	test   %eax,%eax
 29f8d26:	jne    29f8d34 <wasm[0]::function[1015]::helper::object_read+0x17e14>
 29f8d2c:	xor    %r13d,%r13d
 29f8d2f:	jmp    29f8d6d <wasm[0]::function[1015]::helper::object_read+0x17e4d>
 29f8d34:	test   %eax,%eax
 29f8d36:	je     29fc7bf <wasm[0]::function[1015]::helper::object_read+0x1b89f>
 29f8d3c:	mov    0x2e0(%rsp),%r12
 29f8d44:	mov    0x28(%r12),%rcx
 29f8d49:	mov    %eax,%esi
 29f8d4b:	mov    %rsi,%rdx
 29f8d4e:	add    0x20(%r12),%rdx
 29f8d53:	xor    %rdi,%rdi
 29f8d56:	cmp    %rcx,%rsi
 29f8d59:	cmova  %rdi,%rdx
 29f8d5d:	mov    0x10(%rdx),%ecx
 29f8d60:	test   $0x2,%ecx
 29f8d66:	setne  %cl
 29f8d69:	movzbl %cl,%r13d
 29f8d6d:	test   %eax,%eax
 29f8d6f:	je     29fc7c1 <wasm[0]::function[1015]::helper::object_read+0x1b8a1>
 29f8d75:	mov    0x2e0(%rsp),%r12
 29f8d7d:	mov    0x28(%r12),%rsi
 29f8d82:	mov    0x20(%r12),%rdx
 29f8d87:	mov    %eax,%ecx
 29f8d89:	add    %rcx,%rdx
 29f8d8c:	xor    %rdi,%rdi
 29f8d8f:	cmp    %rsi,%rcx
 29f8d92:	cmova  %rdi,%rdx
 29f8d96:	mov    0x14(%rdx),%esi
 29f8d99:	mov    %esi,0xa0(%rsp)
 29f8da0:	mov    0x18(%rdx),%esi
 29f8da3:	mov    %esi,0x78(%rsp)
 29f8da7:	mov    0x1c(%rdx),%edx
 29f8daa:	mov    %edx,0x88(%rsp)
 29f8db1:	test   %eax,%eax
 29f8db3:	jne    29f8dc0 <wasm[0]::function[1015]::helper::object_read+0x17ea0>
 29f8db9:	xor    %eax,%eax
 29f8dbb:	jmp    29f8ded <wasm[0]::function[1015]::helper::object_read+0x17ecd>
 29f8dc0:	mov    0x2e0(%rsp),%r12
 29f8dc8:	mov    0x28(%r12),%rdx
 29f8dcd:	mov    %rcx,%rax
 29f8dd0:	add    0x20(%r12),%rax
 29f8dd5:	xor    %rsi,%rsi
 29f8dd8:	cmp    %rdx,%rcx
 29f8ddb:	cmova  %rsi,%rax
 29f8ddf:	mov    0x10(%rax),%eax
 29f8de2:	test   $0x1,%eax
 29f8de7:	setne  %al
 29f8dea:	movzbl %al,%eax
 29f8ded:	test   %eax,%eax
 29f8def:	jne    29f8edc <wasm[0]::function[1015]::helper::object_read+0x17fbc>
 29f8df5:	mov    0xa0(%rsp),%eax
 29f8dfc:	test   %eax,%eax
 29f8dfe:	je     29fc7c3 <wasm[0]::function[1015]::helper::object_read+0x1b8a3>
 29f8e04:	mov    0x78(%rsp),%eax
 29f8e08:	test   %eax,%eax
 29f8e0a:	je     29fc7c5 <wasm[0]::function[1015]::helper::object_read+0x1b8a5>
 29f8e10:	mov    0x88(%rsp),%eax
 29f8e17:	test   %eax,%eax
 29f8e19:	je     29fc7c7 <wasm[0]::function[1015]::helper::object_read+0x1b8a7>
 29f8e1f:	mov    0x270(%rsp),%rcx
 29f8e27:	mov    (%rcx),%eax
 29f8e29:	mov    %rax,%r15
 29f8e2c:	mov    %eax,%ecx
 29f8e2e:	lea    0x20(%rcx),%rax
 29f8e32:	mov    0x270(%rsp),%rdx
 29f8e3a:	mov    0x4(%rdx),%edx
 29f8e3d:	cmp    %rdx,%rax
 29f8e40:	ja     29fb9c5 <wasm[0]::function[1015]::helper::object_read+0x1aaa5>
 29f8e46:	mov    %r15,%rax
 29f8e49:	add    $0x20,%eax
 29f8e4f:	mov    0x270(%rsp),%rdx
 29f8e57:	mov    %eax,(%rdx)
 29f8e59:	mov    0x2e0(%rsp),%r12
 29f8e61:	mov    0x20(%r12),%rdx
 29f8e66:	lea    (%rdx,%rcx,1),%rax
 29f8e6a:	movl   $0xb0000072,(%rdx,%rcx,1)
 29f8e71:	mov    0x190(%rsp),%rsi
 29f8e79:	mov    0x28(%rsi),%rsi
 29f8e7d:	mov    0x13c(%rsi),%esi
 29f8e83:	mov    %esi,0x4(%rdx,%rcx,1)
 29f8e87:	mov    0x268(%rsp),%rsi
 29f8e8f:	mov    %esi,0x8(%rdx,%rcx,1)
 29f8e93:	test   %ebx,%ebx
 29f8e95:	setne  %cl
 29f8e98:	movzbl %cl,%ecx
 29f8e9b:	shl    $0x2,%ecx
 29f8e9e:	test   %r14d,%r14d
 29f8ea1:	setne  %dl
 29f8ea4:	movzbl %dl,%edx
 29f8ea7:	shl    $0x3,%edx
 29f8eaa:	or     %edx,%ecx
 29f8eac:	test   %r13d,%r13d
 29f8eaf:	setne  %dl
 29f8eb2:	movzbl %dl,%edx
 29f8eb5:	shl    $1,%edx
 29f8eb7:	or     %edx,%ecx
 29f8eb9:	mov    %ecx,0x10(%rax)
 29f8ebc:	mov    0xa0(%rsp),%ecx
 29f8ec3:	mov    %ecx,0x14(%rax)
 29f8ec6:	mov    0x78(%rsp),%ecx
 29f8eca:	mov    %ecx,0x18(%rax)
 29f8ecd:	mov    0x88(%rsp),%ecx
 29f8ed4:	mov    %ecx,0x1c(%rax)
 29f8ed7:	jmp    29f8faf <wasm[0]::function[1015]::helper::object_read+0x1808f>
 29f8edc:	mov    0xa0(%rsp),%eax
 29f8ee3:	test   %eax,%eax
 29f8ee5:	je     29fc7c9 <wasm[0]::function[1015]::helper::object_read+0x1b8a9>
 29f8eeb:	mov    0x78(%rsp),%eax
 29f8eef:	test   %eax,%eax
 29f8ef1:	je     29fc7cb <wasm[0]::function[1015]::helper::object_read+0x1b8ab>
 29f8ef7:	mov    0x88(%rsp),%edx
 29f8efe:	test   %edx,%edx
 29f8f00:	je     29fc7cd <wasm[0]::function[1015]::helper::object_read+0x1b8ad>
 29f8f06:	mov    0x270(%rsp),%rcx
 29f8f0e:	mov    (%rcx),%eax
 29f8f10:	mov    %rax,%r15
 29f8f13:	mov    %eax,%esi
 29f8f15:	lea    0x20(%rsi),%rdi
 29f8f19:	mov    0x4(%rcx),%r8d
 29f8f1d:	cmp    %r8,%rdi
 29f8f20:	ja     29fba03 <wasm[0]::function[1015]::helper::object_read+0x1aae3>
 29f8f26:	mov    %r15,%rax
 29f8f29:	lea    0x20(%rax),%edi
 29f8f2c:	mov    0x270(%rsp),%rcx
 29f8f34:	mov    %edi,(%rcx)
 29f8f36:	mov    0x2e0(%rsp),%r12
 29f8f3e:	mov    0x20(%r12),%r8
 29f8f43:	lea    (%r8,%rsi,1),%rax
 29f8f47:	movl   $0xb0000072,(%r8,%rsi,1)
 29f8f4f:	mov    0x190(%rsp),%rcx
 29f8f57:	mov    0x28(%rcx),%r9
 29f8f5b:	mov    0x13c(%r9),%r9d
 29f8f62:	mov    %r9d,0x4(%r8,%rsi,1)
 29f8f67:	mov    0x268(%rsp),%rcx
 29f8f6f:	mov    %ecx,0x8(%r8,%rsi,1)
 29f8f74:	test   %r14d,%r14d
 29f8f77:	setne  %cl
 29f8f7a:	rex movzbl %cl,%edi
 29f8f7e:	shl    $0x3,%edi
 29f8f81:	or     $0x1,%edi
 29f8f84:	test   %r13d,%r13d
 29f8f87:	setne  %cl
 29f8f8a:	movzbl %cl,%ecx
 29f8f8d:	shl    $1,%ecx
 29f8f8f:	or     %ecx,%edi
 29f8f91:	mov    %edi,0x10(%rax)
 29f8f94:	mov    0xa0(%rsp),%ecx
 29f8f9b:	mov    %ecx,0x14(%rax)
 29f8f9e:	mov    0x78(%rsp),%ecx
 29f8fa2:	mov    %ecx,0x18(%rax)
 29f8fa5:	mov    0x88(%rsp),%ecx
 29f8fac:	mov    %ecx,0x1c(%rax)
 29f8faf:	mov    0x80(%rsp),%eax
 29f8fb6:	mov    0x50(%rsp),%ecx
 29f8fba:	mov    %eax,0x78(%rsp)
 29f8fbe:	mov    %ecx,0x88(%rsp)
 29f8fc5:	mov    %r15,%rax
 29f8fc8:	mov    %r15,%rsi
 29f8fcb:	test   %esi,%eax
 29f8fcd:	jne    29f8fda <wasm[0]::function[1015]::helper::object_read+0x180ba>
 29f8fd3:	xor    %eax,%eax
 29f8fd5:	jmp    29f901b <wasm[0]::function[1015]::helper::object_read+0x180fb>
 29f8fda:	mov    %r15,%rax
 29f8fdd:	mov    %r15,%r10
 29f8fe0:	test   %r10d,%eax
 29f8fe3:	je     29fc7cf <wasm[0]::function[1015]::helper::object_read+0x1b8af>
 29f8fe9:	mov    0x2e0(%rsp),%r12
 29f8ff1:	mov    0x28(%r12),%rax
 29f8ff6:	mov    %r15,%rcx
 29f8ff9:	mov    %ecx,%edx
 29f8ffb:	mov    %rdx,%rcx
 29f8ffe:	add    0x20(%r12),%rcx
 29f9003:	xor    %rsi,%rsi
 29f9006:	cmp    %rax,%rdx
 29f9009:	cmova  %rsi,%rcx
 29f900d:	mov    0x10(%rcx),%eax
 29f9010:	test   $0x2,%eax
 29f9015:	setne  %al
 29f9018:	movzbl %al,%eax
 29f901b:	mov    0x78(%rsp),%edx
 29f901f:	xor    %esi,%esi
 29f9021:	mov    %r15,%rcx
 29f9024:	mov    %r15,%rdi
 29f9027:	test   %edi,%ecx
 29f9029:	setne  %cl
 29f902c:	test   %eax,%eax
 29f902e:	sete   %al
 29f9031:	test   %cl,%al
 29f9033:	jne    29f9046 <wasm[0]::function[1015]::helper::object_read+0x18126>
 29f9039:	mov    %rsi,0x298(%rsp)
 29f9041:	jmp    29f9e1f <wasm[0]::function[1015]::helper::object_read+0x18eff>
 29f9046:	mov    %r15,%rax
 29f9049:	mov    %r15,%rcx
 29f904c:	test   %ecx,%eax
 29f904e:	jne    29f905b <wasm[0]::function[1015]::helper::object_read+0x1813b>
 29f9054:	xor    %eax,%eax
 29f9056:	jmp    29f9098 <wasm[0]::function[1015]::helper::object_read+0x18178>
 29f905b:	mov    %r15,%rax
 29f905e:	mov    %r15,%rcx
 29f9061:	test   %ecx,%eax
 29f9063:	je     29fc7d1 <wasm[0]::function[1015]::helper::object_read+0x1b8b1>
 29f9069:	mov    0x2e0(%rsp),%r12
 29f9071:	mov    0x28(%r12),%rax
 29f9076:	mov    %ecx,%edx
 29f9078:	mov    %rdx,%rcx
 29f907b:	add    0x20(%r12),%rcx
 29f9080:	xor    %rsi,%rsi
 29f9083:	cmp    %rax,%rdx
 29f9086:	cmova  %rsi,%rcx
 29f908a:	mov    0x10(%rcx),%eax
 29f908d:	test   $0x1,%eax
 29f9092:	setne  %al
 29f9095:	movzbl %al,%eax
 29f9098:	test   %eax,%eax
 29f909a:	jne    29f9aed <wasm[0]::function[1015]::helper::object_read+0x18bcd>
 29f90a0:	mov    %r15,%rax
 29f90a3:	mov    %r15,%rdx
 29f90a6:	test   %edx,%eax
 29f90a8:	jne    29f90b5 <wasm[0]::function[1015]::helper::object_read+0x18195>
 29f90ae:	xor    %eax,%eax
 29f90b0:	jmp    29f90f6 <wasm[0]::function[1015]::helper::object_read+0x181d6>
 29f90b5:	mov    %r15,%rax
 29f90b8:	mov    %r15,%r9
 29f90bb:	test   %r9d,%eax
 29f90be:	je     29fc7d3 <wasm[0]::function[1015]::helper::object_read+0x1b8b3>
 29f90c4:	mov    0x2e0(%rsp),%r12
 29f90cc:	mov    0x28(%r12),%rax
 29f90d1:	mov    %r15,%rcx
 29f90d4:	mov    %ecx,%edx
 29f90d6:	mov    %rdx,%rcx
 29f90d9:	add    0x20(%r12),%rcx
 29f90de:	xor    %rsi,%rsi
 29f90e1:	cmp    %rax,%rdx
 29f90e4:	cmova  %rsi,%rcx
 29f90e8:	mov    0x10(%rcx),%eax
 29f90eb:	test   $0x4,%eax
 29f90f0:	setne  %al
 29f90f3:	movzbl %al,%eax
 29f90f6:	mov    0x78(%rsp),%edx
 29f90fa:	xor    %esi,%esi
 29f90fc:	test   %eax,%eax
 29f90fe:	je     29f9111 <wasm[0]::function[1015]::helper::object_read+0x181f1>
 29f9104:	mov    %rsi,0x298(%rsp)
 29f910c:	jmp    29f9e1f <wasm[0]::function[1015]::helper::object_read+0x18eff>
 29f9111:	xor    %edx,%edx
 29f9113:	xor    %rax,%rax
 29f9116:	mov    %r15,%rcx
 29f9119:	mov    %r15,%rsi
 29f911c:	test   %esi,%ecx
 29f911e:	jne    29f9134 <wasm[0]::function[1015]::helper::object_read+0x18214>
 29f9124:	mov    %rdx,%rcx
 29f9127:	mov    0x280(%rsp),%r10
 29f912f:	jmp    29f92ad <wasm[0]::function[1015]::helper::object_read+0x1838d>
 29f9134:	mov    %r15,%rax
 29f9137:	mov    %r15,%rcx
 29f913a:	test   %ecx,%eax
 29f913c:	je     29fc7d5 <wasm[0]::function[1015]::helper::object_read+0x1b8b5>
 29f9142:	mov    0x2e0(%rsp),%r12
 29f914a:	mov    0x28(%r12),%rax
 29f914f:	mov    0x20(%r12),%rcx
 29f9154:	mov    %r15,%rdx
 29f9157:	mov    %edx,%edx
 29f9159:	add    %rdx,%rcx
 29f915c:	xor    %rsi,%rsi
 29f915f:	cmp    %rax,%rdx
 29f9162:	cmova  %rsi,%rcx
 29f9166:	mov    0x14(%rcx),%edx
 29f9169:	test   %edx,%edx
 29f916b:	je     29fc7d7 <wasm[0]::function[1015]::helper::object_read+0x1b8b7>
 29f9171:	xor    %r8d,%r8d
 29f9174:	test   $0x1,%edx
 29f917a:	jne    29f91c1 <wasm[0]::function[1015]::helper::object_read+0x182a1>
 29f9180:	mov    0x2e0(%rsp),%r12
 29f9188:	mov    0x28(%r12),%rsi
 29f918d:	mov    0x20(%r12),%rdi
 29f9192:	mov    %edx,%r8d
 29f9195:	lea    0x4(%rdi,%r8,1),%rdi
 29f919a:	xor    %r9,%r9
 29f919d:	cmp    %rsi,%r8
 29f91a0:	cmova  %r9,%rdi
 29f91a4:	mov    (%rdi),%edi
 29f91a6:	mov    0x190(%rsp),%rsi
 29f91ae:	mov    0x28(%rsi),%r8
 29f91b2:	cmp    0x120(%r8),%edi
 29f91b9:	sete   %r8b
 29f91bd:	movzbl %r8b,%r8d
 29f91c1:	test   %r8d,%r8d
 29f91c4:	jne    29f921f <wasm[0]::function[1015]::helper::object_read+0x182ff>
 29f91ca:	mov    0x190(%rsp),%rsi
 29f91d2:	mov    0x190(%rsp),%rdi
 29f91da:	call   2a01ba0 <wasm[0]::function[1024]::helper::property_value_resolve>
 29f91df:	test   %eax,%eax
 29f91e1:	je     29fc7d9 <wasm[0]::function[1015]::helper::object_read+0x1b8b9>
 29f91e7:	test   %eax,%eax
 29f91e9:	je     29fc7db <wasm[0]::function[1015]::helper::object_read+0x1b8bb>
 29f91ef:	mov    0x2e0(%rsp),%r12
 29f91f7:	mov    0x28(%r12),%rdx
 29f91fc:	mov    0x20(%r12),%rcx
 29f9201:	mov    %eax,%eax
 29f9203:	add    %rax,%rcx
 29f9206:	xor    %rsi,%rsi
 29f9209:	cmp    %rdx,%rax
 29f920c:	cmova  %rsi,%rcx
 29f9210:	mov    0x18(%rcx),%edx
 29f9213:	mov    0x10(%rcx),%rax
 29f9217:	mov    0x1c(%rcx),%ecx
 29f921a:	jmp    29f92a5 <wasm[0]::function[1015]::helper::object_read+0x18385>
 29f921f:	xor    %eax,%eax
 29f9221:	test   $0x1,%edx
 29f9227:	jne    29f926a <wasm[0]::function[1015]::helper::object_read+0x1834a>
 29f922d:	mov    0x2e0(%rsp),%r12
 29f9235:	mov    0x28(%r12),%rax
 29f923a:	mov    0x20(%r12),%rcx
 29f923f:	mov    %edx,%esi
 29f9241:	lea    0x4(%rcx,%rsi,1),%rcx
 29f9246:	xor    %rdi,%rdi
 29f9249:	cmp    %rax,%rsi
 29f924c:	cmova  %rdi,%rcx
 29f9250:	mov    (%rcx),%eax
 29f9252:	mov    0x190(%rsp),%rsi
 29f925a:	mov    0x28(%rsi),%rcx
 29f925e:	cmp    0x120(%rcx),%eax
 29f9264:	sete   %al
 29f9267:	movzbl %al,%eax
 29f926a:	test   %eax,%eax
 29f926c:	je     29fc7dd <wasm[0]::function[1015]::helper::object_read+0x1b8bd>
 29f9272:	test   %edx,%edx
 29f9274:	je     29fc7df <wasm[0]::function[1015]::helper::object_read+0x1b8bf>
 29f927a:	mov    0x2e0(%rsp),%r12
 29f9282:	mov    0x28(%r12),%rax
 29f9287:	mov    0x20(%r12),%rcx
 29f928c:	mov    %edx,%edx
 29f928e:	add    %rdx,%rcx
 29f9291:	xor    %rsi,%rsi
 29f9294:	cmp    %rax,%rdx
 29f9297:	cmova  %rsi,%rcx
 29f929b:	mov    0x18(%rcx),%edx
 29f929e:	mov    0x10(%rcx),%rax
 29f92a2:	mov    0x1c(%rcx),%ecx
 29f92a5:	mov    0x280(%rsp),%r10
 29f92ad:	mov    0x280(%rsp),%r10
 29f92b5:	cmp    %edx,%r10d
 29f92b8:	je     29f92d0 <wasm[0]::function[1015]::helper::object_read+0x183b0>
 29f92be:	mov    0x88(%rsp),%edi
 29f92c5:	mov    0x78(%rsp),%edx
 29f92c9:	xor    %eax,%eax
 29f92cb:	jmp    29f983a <wasm[0]::function[1015]::helper::object_read+0x1891a>
 29f92d0:	mov    0x280(%rsp),%rdx
 29f92d8:	cmp    $0x3,%edx
 29f92db:	je     29f97eb <wasm[0]::function[1015]::helper::object_read+0x188cb>
 29f92e1:	mov    0x280(%rsp),%rdx
 29f92e9:	cmp    $0x4,%edx
 29f92ec:	je     29f96d0 <wasm[0]::function[1015]::helper::object_read+0x187b0>
 29f92f2:	mov    0x280(%rsp),%rdx
 29f92fa:	cmp    $0xa,%edx
 29f92fd:	je     29f9379 <wasm[0]::function[1015]::helper::object_read+0x18459>
 29f9303:	mov    0x280(%rsp),%rdx
 29f930b:	mov    0x280(%rsp),%rsi
 29f9313:	test   %esi,%edx
 29f9315:	sete   %dl
 29f9318:	cmp    $0x1,%esi
 29f931b:	sete   %sil
 29f931f:	or     %esi,%edx
 29f9321:	test   %dl,%dl
 29f9323:	jne    29f9361 <wasm[0]::function[1015]::helper::object_read+0x18441>
 29f9329:	mov    0x280(%rsp),%rdx
 29f9331:	cmp    $0x2,%edx
 29f9334:	je     29f934b <wasm[0]::function[1015]::helper::object_read+0x1842b>
 29f933a:	mov    0x78(%rsp),%eax
 29f933e:	cmp    %ecx,%eax
 29f9340:	sete   %al
 29f9343:	movzbl %al,%eax
 29f9346:	jmp    29f9369 <wasm[0]::function[1015]::helper::object_read+0x18449>
 29f934b:	mov    0x288(%rsp),%rcx
 29f9353:	cmp    %rax,%rcx
 29f9356:	sete   %al
 29f9359:	movzbl %al,%eax
 29f935c:	jmp    29f9369 <wasm[0]::function[1015]::helper::object_read+0x18449>
 29f9361:	mov    0x278(%rsp),%rax
 29f9369:	mov    0x88(%rsp),%edi
 29f9370:	mov    0x78(%rsp),%edx
 29f9374:	jmp    29f983a <wasm[0]::function[1015]::helper::object_read+0x1891a>
 29f9379:	mov    0x78(%rsp),%eax
 29f937d:	xor    %esi,%esi
 29f937f:	test   %eax,%eax
 29f9381:	je     29f93da <wasm[0]::function[1015]::helper::object_read+0x184ba>
 29f9387:	mov    0x78(%rsp),%eax
 29f938b:	xor    %esi,%esi
 29f938d:	test   $0x1,%eax
 29f9392:	jne    29f93da <wasm[0]::function[1015]::helper::object_read+0x184ba>
 29f9398:	mov    0x78(%rsp),%edx
 29f939c:	mov    0x2e0(%rsp),%r12
 29f93a4:	mov    0x28(%r12),%rax
 29f93a9:	mov    0x20(%r12),%rdi
 29f93ae:	mov    %edx,%esi
 29f93b0:	lea    0x4(%rdi,%rsi,1),%rdx
 29f93b5:	xor    %rdi,%rdi
 29f93b8:	cmp    %rax,%rsi
 29f93bb:	cmova  %rdi,%rdx
 29f93bf:	mov    (%rdx),%eax
 29f93c1:	mov    0x190(%rsp),%rsi
 29f93c9:	mov    0x28(%rsi),%rdx
 29f93cd:	cmp    0x23c(%rdx),%eax
 29f93d3:	sete   %al
 29f93d6:	rex movzbl %al,%esi
 29f93da:	test   %esi,%esi
 29f93dc:	je     29fc7e1 <wasm[0]::function[1015]::helper::object_read+0x1b8c1>
 29f93e2:	xor    %eax,%eax
 29f93e4:	test   %ecx,%ecx
 29f93e6:	je     29f943c <wasm[0]::function[1015]::helper::object_read+0x1851c>
 29f93ec:	xor    %eax,%eax
 29f93ee:	test   $0x1,%ecx
 29f93f4:	jne    29f943c <wasm[0]::function[1015]::helper::object_read+0x1851c>
 29f93fa:	mov    0x2e0(%rsp),%r12
 29f9402:	mov    0x28(%r12),%rdi
 29f9407:	mov    0x20(%r12),%r9
 29f940c:	mov    %ecx,%r8d
 29f940f:	lea    0x4(%r9,%r8,1),%rsi
 29f9414:	xor    %r9,%r9
 29f9417:	cmp    %rdi,%r8
 29f941a:	cmova  %r9,%rsi
 29f941e:	mov    (%rsi),%r8d
 29f9421:	mov    0x190(%rsp),%rsi
 29f9429:	mov    0x28(%rsi),%r9
 29f942d:	cmp    0x23c(%r9),%r8d
 29f9434:	sete   %r9b
 29f9438:	movzbl %r9b,%eax
 29f943c:	test   %eax,%eax
 29f943e:	je     29fc7e3 <wasm[0]::function[1015]::helper::object_read+0x1b8c3>
 29f9444:	mov    0x78(%rsp),%edx
 29f9448:	test   %edx,%edx
 29f944a:	je     29fc7e5 <wasm[0]::function[1015]::helper::object_read+0x1b8c5>
 29f9450:	test   %edx,%edx
 29f9452:	je     29fc7e7 <wasm[0]::function[1015]::helper::object_read+0x1b8c7>
 29f9458:	mov    0x2e0(%rsp),%r12
 29f9460:	mov    0x28(%r12),%rax
 29f9465:	mov    0x20(%r12),%rsi
 29f946a:	mov    %edx,%r8d
 29f946d:	lea    (%rsi,%r8,1),%r9
 29f9471:	xor    %rdi,%rdi
 29f9474:	cmp    %rax,%r8
 29f9477:	cmova  %rdi,%r9
 29f947b:	mov    0x10(%r9),%r8d
 29f947f:	test   %ecx,%ecx
 29f9481:	je     29fc7e9 <wasm[0]::function[1015]::helper::object_read+0x1b8c9>
 29f9487:	test   %ecx,%ecx
 29f9489:	je     29fc7eb <wasm[0]::function[1015]::helper::object_read+0x1b8cb>
 29f948f:	mov    %ecx,%ecx
 29f9491:	lea    (%rsi,%rcx,1),%r11
 29f9495:	cmp    %rax,%rcx
 29f9498:	cmova  %rdi,%r11
 29f949c:	mov    0x10(%r11),%ecx
 29f94a0:	mov    0x14(%r9),%r10d
 29f94a4:	mov    %r10d,0xa0(%rsp)
 29f94ac:	mov    0x14(%r11),%r9d
 29f94b0:	mov    %r9d,0xa8(%rsp)
 29f94b8:	test   %r10d,%r10d
 29f94bb:	je     29fc7ed <wasm[0]::function[1015]::helper::object_read+0x1b8cd>
 29f94c1:	test   %r10d,%r10d
 29f94c4:	je     29fc7ef <wasm[0]::function[1015]::helper::object_read+0x1b8cf>
 29f94ca:	mov    %r10d,%r11d
 29f94cd:	lea    0x10(%rsi,%r11,1),%r10
 29f94d2:	cmp    %rax,%r11
 29f94d5:	cmova  %rdi,%r10
 29f94d9:	mov    (%r10),%r13d
 29f94dc:	test   %r9d,%r9d
 29f94df:	je     29fc7f1 <wasm[0]::function[1015]::helper::object_read+0x1b8d1>
 29f94e5:	test   %r9d,%r9d
 29f94e8:	je     29fc7f3 <wasm[0]::function[1015]::helper::object_read+0x1b8d3>
 29f94ee:	mov    %r9d,%r9d
 29f94f1:	lea    0x10(%rsi,%r9,1),%rsi
 29f94f6:	cmp    %rax,%r9
 29f94f9:	cmova  %rdi,%rsi
 29f94fd:	mov    (%rsi),%eax
 29f94ff:	mov    0x88(%rsp),%edi
 29f9506:	cmp    %ecx,%r8d
 29f9509:	sete   %cl
 29f950c:	cmp    %eax,%r13d
 29f950f:	sete   %sil
 29f9513:	mov    %rcx,%rax
 29f9516:	and    %esi,%eax
 29f9518:	movzbl %al,%eax
 29f951b:	mov    %rax,%r14
 29f951e:	test   %cl,%sil
 29f9521:	jne    29f952f <wasm[0]::function[1015]::helper::object_read+0x1860f>
 29f9527:	mov    %r14,%rax
 29f952a:	jmp    29f983a <wasm[0]::function[1015]::helper::object_read+0x1891a>
 29f952f:	mov    0x88(%rsp),%ecx
 29f9536:	mov    0x78(%rsp),%edx
 29f953a:	xor    %ebx,%ebx
 29f953c:	mov    %ecx,0x98(%rsp)
 29f9543:	mov    %edx,0x90(%rsp)
 29f954a:	mov    0x2e8(%rsp),%rax
 29f9552:	mov    (%rax),%rcx
 29f9555:	mov    0x228(%rsp),%rax
 29f955d:	cmp    %rax,%rcx
 29f9560:	jae    29fba49 <wasm[0]::function[1015]::helper::object_read+0x1ab29>
 29f9566:	jmp    29f9573 <wasm[0]::function[1015]::helper::object_read+0x18653>
 29f956b:	mov    %rdx,0x228(%rsp)
 29f9573:	cmp    %r13d,%ebx
 29f9576:	jb     29f9584 <wasm[0]::function[1015]::helper::object_read+0x18664>
 29f957c:	mov    %r14,%rax
 29f957f:	jmp    29f96bd <wasm[0]::function[1015]::helper::object_read+0x1879d>
 29f9584:	mov    0xa0(%rsp),%esi
 29f958b:	test   %esi,%esi
 29f958d:	je     29fc7f5 <wasm[0]::function[1015]::helper::object_read+0x1b8d5>
 29f9593:	test   %esi,%esi
 29f9595:	je     29fc7f7 <wasm[0]::function[1015]::helper::object_read+0x1b8d7>
 29f959b:	mov    0x2e0(%rsp),%r12
 29f95a3:	mov    0x28(%r12),%rax
 29f95a8:	mov    0x20(%r12),%rcx
 29f95ad:	mov    %esi,%r8d
 29f95b0:	lea    0x10(%rcx,%r8,1),%rdi
 29f95b5:	xor    %rdx,%rdx
 29f95b8:	cmp    %rax,%r8
 29f95bb:	cmova  %rdx,%rdi
 29f95bf:	mov    (%rdi),%r8d
 29f95c2:	cmp    %r8d,%ebx
 29f95c5:	jae    29fc7f9 <wasm[0]::function[1015]::helper::object_read+0x1b8d9>
 29f95cb:	mov    %r8d,%edi
 29f95ce:	shl    $0x3,%rdi
 29f95d2:	shr    $0x20,%rdi
 29f95d6:	test   %rdi,%rdi
 29f95d9:	jne    29fc7fb <wasm[0]::function[1015]::helper::object_read+0x1b8db>
 29f95df:	shl    $0x3,%r8d
 29f95e3:	add    $0x18,%r8d
 29f95e7:	jb     29fc7fd <wasm[0]::function[1015]::helper::object_read+0x1b8dd>
 29f95ed:	add    %r8d,%esi
 29f95f0:	jb     29fc7ff <wasm[0]::function[1015]::helper::object_read+0x1b8df>
 29f95f6:	mov    %esi,%edi
 29f95f8:	lea    (%rcx,%rdi,1),%rsi
 29f95fc:	cmp    %rax,%rdi
 29f95ff:	cmova  %rdx,%rsi
 29f9603:	mov    %rbx,%rdi
 29f9606:	shl    $0x3,%edi
 29f9609:	add    $0x18,%edi
 29f960f:	sub    %edi,%r8d
 29f9612:	sub    %r8,%rsi
 29f9615:	mov    (%rsi),%rsi
 29f9618:	mov    0xa8(%rsp),%r8d
 29f9620:	test   %r8d,%r8d
 29f9623:	je     29fc801 <wasm[0]::function[1015]::helper::object_read+0x1b8e1>
 29f9629:	test   %r8d,%r8d
 29f962c:	je     29fc803 <wasm[0]::function[1015]::helper::object_read+0x1b8e3>
 29f9632:	mov    %r8d,%r10d
 29f9635:	lea    0x10(%rcx,%r10,1),%r9
 29f963a:	cmp    %rax,%r10
 29f963d:	cmova  %rdx,%r9
 29f9641:	mov    (%r9),%r9d
 29f9644:	cmp    %r9d,%ebx
 29f9647:	jae    29fc805 <wasm[0]::function[1015]::helper::object_read+0x1b8e5>
 29f964d:	mov    %r9d,%r10d
 29f9650:	shl    $0x3,%r10
 29f9654:	shr    $0x20,%r10
 29f9658:	test   %r10,%r10
 29f965b:	jne    29fc807 <wasm[0]::function[1015]::helper::object_read+0x1b8e7>
 29f9661:	shl    $0x3,%r9d
 29f9665:	add    $0x18,%r9d
 29f9669:	jb     29fc809 <wasm[0]::function[1015]::helper::object_read+0x1b8e9>
 29f966f:	add    %r9d,%r8d
 29f9672:	jb     29fc80b <wasm[0]::function[1015]::helper::object_read+0x1b8eb>
 29f9678:	mov    %r8d,%r8d
 29f967b:	lea    (%rcx,%r8,1),%r10
 29f967f:	cmp    %rax,%r8
 29f9682:	cmova  %rdx,%r10
 29f9686:	sub    %edi,%r9d
 29f9689:	sub    %r9,%r10
 29f968c:	mov    (%r10),%rcx
 29f968f:	cmp    %rcx,%rsi
 29f9692:	sete   %al
 29f9695:	movzbl %al,%eax
 29f9698:	cmp    %rcx,%rsi
 29f969b:	jne    29f96bd <wasm[0]::function[1015]::helper::object_read+0x1879d>
 29f96a1:	mov    0x98(%rsp),%ecx
 29f96a8:	mov    0x90(%rsp),%edx
 29f96af:	add    $0x1,%ebx
 29f96b5:	mov    %rax,%r14
 29f96b8:	jmp    29f953c <wasm[0]::function[1015]::helper::object_read+0x1861c>
 29f96bd:	mov    0x98(%rsp),%edi
 29f96c4:	mov    0x90(%rsp),%edx
 29f96cb:	jmp    29f983a <wasm[0]::function[1015]::helper::object_read+0x1891a>
 29f96d0:	mov    0x78(%rsp),%eax
 29f96d4:	cmp    %ecx,%eax
 29f96d6:	je     29f97d3 <wasm[0]::function[1015]::helper::object_read+0x188b3>
 29f96dc:	mov    0x78(%rsp),%edx
 29f96e0:	xor    %eax,%eax
 29f96e2:	test   %edx,%edx
 29f96e4:	je     29f973d <wasm[0]::function[1015]::helper::object_read+0x1881d>
 29f96ea:	mov    0x78(%rsp),%edx
 29f96ee:	xor    %eax,%eax
 29f96f0:	test   $0x1,%edx
 29f96f6:	jne    29f973d <wasm[0]::function[1015]::helper::object_read+0x1881d>
 29f96fc:	mov    0x78(%rsp),%edx
 29f9700:	mov    0x2e0(%rsp),%r12
 29f9708:	mov    0x28(%r12),%rax
 29f970d:	mov    0x20(%r12),%rdi
 29f9712:	mov    %edx,%esi
 29f9714:	lea    0x4(%rdi,%rsi,1),%rdx
 29f9719:	xor    %rdi,%rdi
 29f971c:	cmp    %rax,%rsi
 29f971f:	cmova  %rdi,%rdx
 29f9723:	mov    (%rdx),%eax
 29f9725:	mov    0x190(%rsp),%rsi
 29f972d:	mov    0x28(%rsi),%rdx
 29f9731:	cmp    0x234(%rdx),%eax
 29f9737:	sete   %al
 29f973a:	movzbl %al,%eax
 29f973d:	test   %eax,%eax
 29f973f:	je     29fc80d <wasm[0]::function[1015]::helper::object_read+0x1b8ed>
 29f9745:	xor    %eax,%eax
 29f9747:	test   %ecx,%ecx
 29f9749:	je     29f979a <wasm[0]::function[1015]::helper::object_read+0x1887a>
 29f974f:	xor    %eax,%eax
 29f9751:	test   $0x1,%ecx
 29f9757:	jne    29f979a <wasm[0]::function[1015]::helper::object_read+0x1887a>
 29f975d:	mov    0x2e0(%rsp),%r12
 29f9765:	mov    0x28(%r12),%rax
 29f976a:	mov    0x20(%r12),%rdx
 29f976f:	mov    %ecx,%esi
 29f9771:	lea    0x4(%rdx,%rsi,1),%rdx
 29f9776:	xor    %rdi,%rdi
 29f9779:	cmp    %rax,%rsi
 29f977c:	cmova  %rdi,%rdx
 29f9780:	mov    (%rdx),%eax
 29f9782:	mov    0x190(%rsp),%rsi
 29f978a:	mov    0x28(%rsi),%rdx
 29f978e:	cmp    0x234(%rdx),%eax
 29f9794:	sete   %al
 29f9797:	movzbl %al,%eax
 29f979a:	test   %eax,%eax
 29f979c:	je     29fc80f <wasm[0]::function[1015]::helper::object_read+0x1b8ef>
 29f97a2:	mov    0x78(%rsp),%edx
 29f97a6:	xor    %r8d,%r8d
 29f97a9:	test   %edx,%edx
 29f97ab:	je     29fc811 <wasm[0]::function[1015]::helper::object_read+0x1b8f1>
 29f97b1:	test   %ecx,%ecx
 29f97b3:	je     29fc813 <wasm[0]::function[1015]::helper::object_read+0x1b8f3>
 29f97b9:	mov    0x190(%rsp),%rsi
 29f97c1:	mov    0x190(%rsp),%rdi
 29f97c9:	call   2ae54e0 <wasm[0]::function[1057]::helper::string_equality>
 29f97ce:	jmp    29f97db <wasm[0]::function[1015]::helper::object_read+0x188bb>
 29f97d3:	mov    0x278(%rsp),%rax
 29f97db:	mov    0x88(%rsp),%edi
 29f97e2:	mov    0x78(%rsp),%edx
 29f97e6:	jmp    29f983a <wasm[0]::function[1015]::helper::object_read+0x1891a>
 29f97eb:	mov    0x88(%rsp),%edi
 29f97f2:	mov    0x78(%rsp),%edx
 29f97f6:	mov    0x288(%rsp),%rcx
 29f97fe:	cmp    %rax,%rcx
 29f9801:	sete   %cl
 29f9804:	mov    0x288(%rsp),%rsi
 29f980c:	movq   %rsi,%xmm0
 29f9811:	ucomisd %xmm0,%xmm0
 29f9815:	setp   %sil
 29f9819:	setne  %r8b
 29f981d:	or     %r8d,%esi
 29f9820:	movq   %rax,%xmm0
 29f9825:	ucomisd %xmm0,%xmm0
 29f9829:	setp   %al
 29f982c:	setne  %r8b
 29f9830:	or     %r8d,%eax
 29f9833:	and    %eax,%esi
 29f9835:	or     %esi,%ecx
 29f9837:	movzbl %cl,%eax
 29f983a:	xor    %esi,%esi
 29f983c:	test   %eax,%eax
 29f983e:	je     29f9851 <wasm[0]::function[1015]::helper::object_read+0x18931>
 29f9844:	mov    %rsi,0x298(%rsp)
 29f984c:	jmp    29f9e1f <wasm[0]::function[1015]::helper::object_read+0x18eff>
 29f9851:	xor    %edx,%edx
 29f9853:	mov    %edi,0x90(%rsp)
 29f985a:	mov    %edx,0x98(%rsp)
 29f9861:	mov    0x2e8(%rsp),%r13
 29f9869:	mov    0x0(%r13),%rcx
 29f986d:	mov    0x228(%rsp),%rax
 29f9875:	cmp    %rax,%rcx
 29f9878:	jae    29fba79 <wasm[0]::function[1015]::helper::object_read+0x1ab59>
 29f987e:	jmp    29f988b <wasm[0]::function[1015]::helper::object_read+0x1896b>
 29f9883:	mov    %rsi,0x228(%rsp)
 29f988b:	mov    0x90(%rsp),%r8d
 29f9893:	mov    0x98(%rsp),%edx
 29f989a:	test   %r8d,%r8d
 29f989d:	je     29f991b <wasm[0]::function[1015]::helper::object_read+0x189fb>
 29f98a3:	mov    0x90(%rsp),%r11d
 29f98ab:	test   %r11d,%r11d
 29f98ae:	je     29fc815 <wasm[0]::function[1015]::helper::object_read+0x1b8f5>
 29f98b4:	mov    0x2e0(%rsp),%r12
 29f98bc:	mov    0x28(%r12),%rax
 29f98c1:	mov    0x20(%r12),%rdx
 29f98c6:	mov    %r11d,%ecx
 29f98c9:	lea    (%rdx,%rcx,1),%r10
 29f98cd:	xor    %rdx,%rdx
 29f98d0:	cmp    %rax,%rcx
 29f98d3:	cmova  %rdx,%r10
 29f98d7:	mov    0x10(%r10),%edx
 29f98db:	test   %edx,%edx
 29f98dd:	jne    29f991b <wasm[0]::function[1015]::helper::object_read+0x189fb>
 29f98e3:	mov    0x90(%rsp),%ecx
 29f98ea:	test   %ecx,%ecx
 29f98ec:	je     29fc817 <wasm[0]::function[1015]::helper::object_read+0x1b8f7>
 29f98f2:	mov    0x2e0(%rsp),%r12
 29f98fa:	mov    0x28(%r12),%rax
 29f98ff:	mov    %ecx,%esi
 29f9901:	mov    %rsi,%rcx
 29f9904:	add    0x20(%r12),%rcx
 29f9909:	xor    %rdi,%rdi
 29f990c:	cmp    %rax,%rsi
 29f990f:	cmova  %rdi,%rcx
 29f9913:	mov    0x1c(%rcx),%edi
 29f9916:	jmp    29f9853 <wasm[0]::function[1015]::helper::object_read+0x18933>
 29f991b:	test   %edx,%edx
 29f991d:	jne    29f9939 <wasm[0]::function[1015]::helper::object_read+0x18a19>
 29f9923:	mov    0x190(%rsp),%rsi
 29f992b:	mov    0x8c0(%rsi),%edx
 29f9931:	test   %edx,%edx
 29f9933:	je     29fc819 <wasm[0]::function[1015]::helper::object_read+0x1b8f9>
 29f9939:	mov    %edx,0x90(%rsp)
 29f9940:	test   %edx,%edx
 29f9942:	je     29fc81b <wasm[0]::function[1015]::helper::object_read+0x1b8fb>
 29f9948:	mov    0x190(%rsp),%rsi
 29f9950:	mov    0x190(%rsp),%rdi
 29f9958:	call   2ac6040 <wasm[0]::function[1049]::helper::realm_ensure_errors>
 29f995d:	mov    0x90(%rsp),%edx
 29f9964:	test   %edx,%edx
 29f9966:	je     29fc81d <wasm[0]::function[1015]::helper::object_read+0x1b8fd>
 29f996c:	test   %edx,%edx
 29f996e:	je     29fc81f <wasm[0]::function[1015]::helper::object_read+0x1b8ff>
 29f9974:	mov    0x2e0(%rsp),%r12
 29f997c:	mov    0x28(%r12),%rax
 29f9981:	mov    0x20(%r12),%rcx
 29f9986:	mov    %edx,%edi
 29f9988:	lea    (%rcx,%rdi,1),%rsi
 29f998c:	xor    %rdx,%rdx
 29f998f:	cmp    %rax,%rdi
 29f9992:	cmova  %rdx,%rsi
 29f9996:	mov    0x2c(%rsi),%esi
 29f9999:	test   %esi,%esi
 29f999b:	je     29fc821 <wasm[0]::function[1015]::helper::object_read+0x1b901>
 29f99a1:	test   %esi,%esi
 29f99a3:	je     29fc823 <wasm[0]::function[1015]::helper::object_read+0x1b903>
 29f99a9:	mov    %esi,%r8d
 29f99ac:	lea    0x10(%rcx,%r8,1),%rdi
 29f99b1:	cmp    %rax,%r8
 29f99b4:	cmova  %rdx,%rdi
 29f99b8:	mov    (%rdi),%edi
 29f99ba:	cmp    $0x3,%edi
 29f99bd:	jbe    29fc825 <wasm[0]::function[1015]::helper::object_read+0x1b905>
 29f99c3:	mov    %edi,%r8d
 29f99c6:	shl    $0x2,%r8
 29f99ca:	shr    $0x20,%r8
 29f99ce:	test   %r8,%r8
 29f99d1:	jne    29fc827 <wasm[0]::function[1015]::helper::object_read+0x1b907>
 29f99d7:	shl    $0x2,%edi
 29f99da:	add    $0x14,%edi
 29f99dd:	jb     29fc829 <wasm[0]::function[1015]::helper::object_read+0x1b909>
 29f99e3:	add    %edi,%esi
 29f99e5:	jb     29fc82b <wasm[0]::function[1015]::helper::object_read+0x1b90b>
 29f99eb:	mov    %esi,%r8d
 29f99ee:	lea    (%rcx,%r8,1),%rsi
 29f99f2:	cmp    %rax,%r8
 29f99f5:	cmova  %rdx,%rsi
 29f99f9:	sub    $0x20,%edi
 29f99fc:	sub    %rdi,%rsi
 29f99ff:	mov    (%rsi),%esi
 29f9a01:	test   %esi,%esi
 29f9a03:	je     29fc82d <wasm[0]::function[1015]::helper::object_read+0x1b90d>
 29f9a09:	test   %esi,%esi
 29f9a0b:	je     29fc82f <wasm[0]::function[1015]::helper::object_read+0x1b90f>
 29f9a11:	mov    %esi,%esi
 29f9a13:	add    %rsi,%rcx
 29f9a16:	cmp    %rax,%rsi
 29f9a19:	cmova  %rdx,%rcx
 29f9a1d:	mov    0x18(%rcx),%r12d
 29f9a21:	mov    0x10(%rcx),%rbx
 29f9a25:	mov    0x1c(%rcx),%eax
 29f9a28:	mov    %eax,0x90(%rsp)
 29f9a2f:	mov    $0x6,%eax
 29f9a34:	mov    %rax,0x280(%rsp)
 29f9a3c:	cmp    $0x6,%r12d
 29f9a40:	sete   %cl
 29f9a43:	cmp    $0x7,%r12d
 29f9a47:	sete   %al
 29f9a4a:	or     %eax,%ecx
 29f9a4c:	cmp    $0x8,%r12d
 29f9a50:	sete   %al
 29f9a53:	or     %eax,%ecx
 29f9a55:	cmp    $0x9,%r12d
 29f9a59:	sete   %al
 29f9a5c:	or     %eax,%ecx
 29f9a5e:	movzbl %cl,%eax
 29f9a61:	test   %eax,%eax
 29f9a63:	je     29fc831 <wasm[0]::function[1015]::helper::object_read+0x1b911>
 29f9a69:	mov    $0x998,%edx
 29f9a6e:	mov    0x190(%rsp),%rsi
 29f9a76:	mov    0x190(%rsp),%rdi
 29f9a7e:	call   2f307a0 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 29f9a83:	xor    %edi,%edi
 29f9a85:	mov    %rdi,0x298(%rsp)
 29f9a8d:	test   %eax,%eax
 29f9a8f:	je     29fc833 <wasm[0]::function[1015]::helper::object_read+0x1b913>
 29f9a95:	mov    0x90(%rsp),%r9d
 29f9a9d:	mov    $0x5,%edx
 29f9aa2:	mov    %eax,(%rsp)
 29f9aa5:	mov    %r12,%rcx
 29f9aa8:	mov    0x190(%rsp),%rsi
 29f9ab0:	mov    %rbx,%r8
 29f9ab3:	mov    %rsi,%rdi
 29f9ab6:	call   2f30500 <wasm[0]::function[1101]::helper::runtime_error_for_throw>
 29f9abb:	sub    $0x10,%rsp
 29f9abf:	test   %eax,%eax
 29f9ac1:	je     29fc835 <wasm[0]::function[1015]::helper::object_read+0x1b915>
 29f9ac7:	mov    %rcx,%rdx
 29f9aca:	mov    %rcx,0x288(%rsp)
 29f9ad2:	xor    %rdx,%rcx
 29f9ad5:	mov    %rcx,0x288(%rsp)
 29f9add:	mov    %rax,%rdx
 29f9ae0:	mov    0x278(%rsp),%rsi
 29f9ae8:	jmp    29f9e1f <wasm[0]::function[1015]::helper::object_read+0x18eff>
 29f9aed:	xor    %eax,%eax
 29f9aef:	mov    %r15,%rcx
 29f9af2:	mov    %r15,%rdx
 29f9af5:	test   %edx,%ecx
 29f9af7:	je     29f9b5b <wasm[0]::function[1015]::helper::object_read+0x18c3b>
 29f9afd:	mov    %r15,%rax
 29f9b00:	mov    %r15,%rcx
 29f9b03:	test   %ecx,%eax
 29f9b05:	je     29fc837 <wasm[0]::function[1015]::helper::object_read+0x1b917>
 29f9b0b:	mov    0x2e0(%rsp),%r12
 29f9b13:	mov    0x28(%r12),%r11
 29f9b18:	mov    0x20(%r12),%rax
 29f9b1d:	mov    %r15,%rdx
 29f9b20:	mov    %edx,%edx
 29f9b22:	lea    (%rax,%rdx,1),%r8
 29f9b26:	xor    %rcx,%rcx
 29f9b29:	cmp    %r11,%rdx
 29f9b2c:	cmova  %rcx,%r8
 29f9b30:	mov    0x18(%r8),%edx
 29f9b34:	test   %edx,%edx
 29f9b36:	je     29fc839 <wasm[0]::function[1015]::helper::object_read+0x1b919>
 29f9b3c:	test   %edx,%edx
 29f9b3e:	je     29fc83b <wasm[0]::function[1015]::helper::object_read+0x1b91b>
 29f9b44:	mov    %edx,%esi
 29f9b46:	lea    (%rax,%rsi,1),%rdx
 29f9b4a:	cmp    %r11,%rsi
 29f9b4d:	cmova  %rcx,%rdx
 29f9b51:	mov    0x18(%rdx),%eax
 29f9b54:	mov    0x10(%rdx),%rcx
 29f9b58:	mov    0x1c(%rdx),%ecx
 29f9b5b:	mov    0x78(%rsp),%edx
 29f9b5f:	xor    %esi,%esi
 29f9b61:	test   %eax,%eax
 29f9b63:	sete   %al
 29f9b66:	mov    0x280(%rsp),%rcx
 29f9b6e:	mov    0x280(%rsp),%rdi
 29f9b76:	test   %edi,%ecx
 29f9b78:	setne  %cl
 29f9b7b:	test   %al,%cl
 29f9b7d:	jne    29f9b90 <wasm[0]::function[1015]::helper::object_read+0x18c70>
 29f9b83:	mov    %rsi,0x298(%rsp)
 29f9b8b:	jmp    29f9e1f <wasm[0]::function[1015]::helper::object_read+0x18eff>
 29f9b90:	mov    0x88(%rsp),%eax
 29f9b97:	xor    %edx,%edx
 29f9b99:	mov    %eax,0x78(%rsp)
 29f9b9d:	mov    %edx,0x88(%rsp)
 29f9ba4:	mov    0x2e8(%rsp),%r13
 29f9bac:	mov    0x0(%r13),%rax
 29f9bb0:	mov    0x228(%rsp),%rcx
 29f9bb8:	cmp    %rcx,%rax
 29f9bbb:	jae    29fbaa9 <wasm[0]::function[1015]::helper::object_read+0x1ab89>
 29f9bc1:	jmp    29f9bce <wasm[0]::function[1015]::helper::object_read+0x18cae>
 29f9bc6:	mov    %rcx,0x228(%rsp)
 29f9bce:	mov    0x78(%rsp),%eax
 29f9bd2:	mov    0x88(%rsp),%edx
 29f9bd9:	test   %eax,%eax
 29f9bdb:	je     29f9c4f <wasm[0]::function[1015]::helper::object_read+0x18d2f>
 29f9be1:	mov    0x78(%rsp),%ecx
 29f9be5:	test   %ecx,%ecx
 29f9be7:	je     29fc83d <wasm[0]::function[1015]::helper::object_read+0x1b91d>
 29f9bed:	mov    0x2e0(%rsp),%r12
 29f9bf5:	mov    0x28(%r12),%rax
 29f9bfa:	mov    0x20(%r12),%rsi
 29f9bff:	mov    %ecx,%edx
 29f9c01:	lea    (%rsi,%rdx,1),%rcx
 29f9c05:	xor    %rsi,%rsi
 29f9c08:	cmp    %rax,%rdx
 29f9c0b:	cmova  %rsi,%rcx
 29f9c0f:	mov    0x10(%rcx),%edx
 29f9c12:	test   %edx,%edx
 29f9c14:	jne    29f9c4f <wasm[0]::function[1015]::helper::object_read+0x18d2f>
 29f9c1a:	mov    0x78(%rsp),%ecx
 29f9c1e:	test   %ecx,%ecx
 29f9c20:	je     29fc83f <wasm[0]::function[1015]::helper::object_read+0x1b91f>
 29f9c26:	mov    0x2e0(%rsp),%r12
 29f9c2e:	mov    0x28(%r12),%rax
 29f9c33:	mov    %ecx,%esi
 29f9c35:	mov    %rsi,%rcx
 29f9c38:	add    0x20(%r12),%rcx
 29f9c3d:	xor    %rdi,%rdi
 29f9c40:	cmp    %rax,%rsi
 29f9c43:	cmova  %rdi,%rcx
 29f9c47:	mov    0x1c(%rcx),%eax
 29f9c4a:	jmp    29f9b99 <wasm[0]::function[1015]::helper::object_read+0x18c79>
 29f9c4f:	test   %edx,%edx
 29f9c51:	jne    29f9c6d <wasm[0]::function[1015]::helper::object_read+0x18d4d>
 29f9c57:	mov    0x190(%rsp),%rsi
 29f9c5f:	mov    0x8c0(%rsi),%edx
 29f9c65:	test   %edx,%edx
 29f9c67:	je     29fc841 <wasm[0]::function[1015]::helper::object_read+0x1b921>
 29f9c6d:	mov    %edx,0x78(%rsp)
 29f9c71:	test   %edx,%edx
 29f9c73:	je     29fc843 <wasm[0]::function[1015]::helper::object_read+0x1b923>
 29f9c79:	mov    0x190(%rsp),%rsi
 29f9c81:	mov    0x190(%rsp),%rdi
 29f9c89:	call   2ac6040 <wasm[0]::function[1049]::helper::realm_ensure_errors>
 29f9c8e:	mov    0x78(%rsp),%edx
 29f9c92:	test   %edx,%edx
 29f9c94:	je     29fc845 <wasm[0]::function[1015]::helper::object_read+0x1b925>
 29f9c9a:	test   %edx,%edx
 29f9c9c:	je     29fc847 <wasm[0]::function[1015]::helper::object_read+0x1b927>
 29f9ca2:	mov    0x2e0(%rsp),%r12
 29f9caa:	mov    0x28(%r12),%rax
 29f9caf:	mov    0x20(%r12),%rcx
 29f9cb4:	mov    %edx,%edi
 29f9cb6:	lea    (%rcx,%rdi,1),%rsi
 29f9cba:	xor    %rdx,%rdx
 29f9cbd:	cmp    %rax,%rdi
 29f9cc0:	cmova  %rdx,%rsi
 29f9cc4:	mov    0x2c(%rsi),%esi
 29f9cc7:	test   %esi,%esi
 29f9cc9:	je     29fc849 <wasm[0]::function[1015]::helper::object_read+0x1b929>
 29f9ccf:	test   %esi,%esi
 29f9cd1:	je     29fc84b <wasm[0]::function[1015]::helper::object_read+0x1b92b>
 29f9cd7:	mov    %esi,%r8d
 29f9cda:	lea    0x10(%rcx,%r8,1),%rdi
 29f9cdf:	cmp    %rax,%r8
 29f9ce2:	cmova  %rdx,%rdi
 29f9ce6:	mov    (%rdi),%edi
 29f9ce8:	cmp    $0x3,%edi
 29f9ceb:	jbe    29fc84d <wasm[0]::function[1015]::helper::object_read+0x1b92d>
 29f9cf1:	mov    %edi,%r8d
 29f9cf4:	shl    $0x2,%r8
 29f9cf8:	shr    $0x20,%r8
 29f9cfc:	test   %r8,%r8
 29f9cff:	jne    29fc84f <wasm[0]::function[1015]::helper::object_read+0x1b92f>
 29f9d05:	shl    $0x2,%edi
 29f9d08:	add    $0x14,%edi
 29f9d0b:	jb     29fc851 <wasm[0]::function[1015]::helper::object_read+0x1b931>
 29f9d11:	add    %edi,%esi
 29f9d13:	jb     29fc853 <wasm[0]::function[1015]::helper::object_read+0x1b933>
 29f9d19:	mov    %esi,%r9d
 29f9d1c:	lea    (%rcx,%r9,1),%rsi
 29f9d20:	cmp    %rax,%r9
 29f9d23:	cmova  %rdx,%rsi
 29f9d27:	sub    $0x20,%edi
 29f9d2a:	sub    %rdi,%rsi
 29f9d2d:	mov    (%rsi),%r10d
 29f9d30:	test   %r10d,%r10d
 29f9d33:	je     29fc855 <wasm[0]::function[1015]::helper::object_read+0x1b935>
 29f9d39:	test   %r10d,%r10d
 29f9d3c:	je     29fc857 <wasm[0]::function[1015]::helper::object_read+0x1b937>
 29f9d42:	mov    %r10d,%esi
 29f9d45:	add    %rsi,%rcx
 29f9d48:	cmp    %rax,%rsi
 29f9d4b:	cmova  %rdx,%rcx
 29f9d4f:	mov    0x18(%rcx),%ebx
 29f9d52:	mov    0x10(%rcx),%r15
 29f9d56:	mov    0x1c(%rcx),%eax
 29f9d59:	mov    %eax,0x78(%rsp)
 29f9d5d:	mov    $0x6,%eax
 29f9d62:	mov    %rax,0x280(%rsp)
 29f9d6a:	cmp    $0x6,%ebx
 29f9d6d:	sete   %r11b
 29f9d71:	cmp    $0x7,%ebx
 29f9d74:	sete   %al
 29f9d77:	or     %eax,%r11d
 29f9d7a:	cmp    $0x8,%ebx
 29f9d7d:	sete   %al
 29f9d80:	or     %eax,%r11d
 29f9d83:	cmp    $0x9,%ebx
 29f9d86:	sete   %al
 29f9d89:	or     %eax,%r11d
 29f9d8c:	movzbl %r11b,%eax
 29f9d90:	test   %eax,%eax
 29f9d92:	je     29fc859 <wasm[0]::function[1015]::helper::object_read+0x1b939>
 29f9d98:	mov    $0x999,%edx
 29f9d9d:	mov    0x190(%rsp),%rsi
 29f9da5:	mov    0x190(%rsp),%rdi
 29f9dad:	call   2f307a0 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 29f9db2:	mov    %rdi,%rcx
 29f9db5:	mov    %rdi,0x298(%rsp)
 29f9dbd:	xor    %ecx,%edi
 29f9dbf:	mov    %rdi,0x298(%rsp)
 29f9dc7:	test   %eax,%eax
 29f9dc9:	je     29fc85b <wasm[0]::function[1015]::helper::object_read+0x1b93b>
 29f9dcf:	mov    0x78(%rsp),%r9d
 29f9dd4:	mov    $0x5,%edx
 29f9dd9:	mov    %eax,(%rsp)
 29f9ddc:	mov    %rbx,%rcx
 29f9ddf:	mov    0x190(%rsp),%rsi
 29f9de7:	mov    %r15,%r8
 29f9dea:	mov    %rsi,%rdi
 29f9ded:	call   2f30500 <wasm[0]::function[1101]::helper::runtime_error_for_throw>
 29f9df2:	sub    $0x10,%rsp
 29f9df6:	test   %eax,%eax
 29f9df8:	je     29fc85d <wasm[0]::function[1015]::helper::object_read+0x1b93d>
 29f9dfe:	mov    %rcx,%rdx
 29f9e01:	mov    %rcx,0x288(%rsp)
 29f9e09:	xor    %rdx,%rcx
 29f9e0c:	mov    %rcx,0x288(%rsp)
 29f9e14:	mov    %rax,%rdx
 29f9e17:	mov    0x278(%rsp),%rsi
 29f9e1f:	mov    %rdx,%rax
 29f9e22:	jmp    29fa43a <wasm[0]::function[1015]::helper::object_read+0x1951a>
 29f9e27:	mov    %rdi,0x298(%rsp)
 29f9e2f:	mov    0x80(%rsp),%edx
 29f9e36:	mov    %rdx,%rax
 29f9e39:	jmp    29fa43a <wasm[0]::function[1015]::helper::object_read+0x1951a>
 29f9e3e:	mov    0x50(%rsp),%eax
 29f9e42:	xor    %edx,%edx
 29f9e44:	mov    %eax,0x78(%rsp)
 29f9e48:	mov    %edx,0x80(%rsp)
 29f9e4f:	mov    0x2e8(%rsp),%r13
 29f9e57:	mov    0x0(%r13),%rax
 29f9e5b:	mov    0x228(%rsp),%rdi
 29f9e63:	cmp    %rdi,%rax
 29f9e66:	jae    29fbad9 <wasm[0]::function[1015]::helper::object_read+0x1abb9>
 29f9e6c:	jmp    29f9e79 <wasm[0]::function[1015]::helper::object_read+0x18f59>
 29f9e71:	mov    %rcx,0x228(%rsp)
 29f9e79:	mov    0x78(%rsp),%eax
 29f9e7d:	mov    0x80(%rsp),%edx
 29f9e84:	test   %eax,%eax
 29f9e86:	je     29f9efa <wasm[0]::function[1015]::helper::object_read+0x18fda>
 29f9e8c:	mov    0x78(%rsp),%ecx
 29f9e90:	test   %ecx,%ecx
 29f9e92:	je     29fc85f <wasm[0]::function[1015]::helper::object_read+0x1b93f>
 29f9e98:	mov    0x2e0(%rsp),%r12
 29f9ea0:	mov    0x28(%r12),%rax
 29f9ea5:	mov    0x20(%r12),%rsi
 29f9eaa:	mov    %ecx,%edx
 29f9eac:	lea    (%rsi,%rdx,1),%rcx
 29f9eb0:	xor    %rsi,%rsi
 29f9eb3:	cmp    %rax,%rdx
 29f9eb6:	cmova  %rsi,%rcx
 29f9eba:	mov    0x10(%rcx),%edx
 29f9ebd:	test   %edx,%edx
 29f9ebf:	jne    29f9efa <wasm[0]::function[1015]::helper::object_read+0x18fda>
 29f9ec5:	mov    0x78(%rsp),%ecx
 29f9ec9:	test   %ecx,%ecx
 29f9ecb:	je     29fc861 <wasm[0]::function[1015]::helper::object_read+0x1b941>
 29f9ed1:	mov    0x2e0(%rsp),%r12
 29f9ed9:	mov    0x28(%r12),%rax
 29f9ede:	mov    %ecx,%esi
 29f9ee0:	mov    %rsi,%rcx
 29f9ee3:	add    0x20(%r12),%rcx
 29f9ee8:	xor    %rdi,%rdi
 29f9eeb:	cmp    %rax,%rsi
 29f9eee:	cmova  %rdi,%rcx
 29f9ef2:	mov    0x1c(%rcx),%eax
 29f9ef5:	jmp    29f9e44 <wasm[0]::function[1015]::helper::object_read+0x18f24>
 29f9efa:	test   %edx,%edx
 29f9efc:	jne    29f9f18 <wasm[0]::function[1015]::helper::object_read+0x18ff8>
 29f9f02:	mov    0x190(%rsp),%rsi
 29f9f0a:	mov    0x8c0(%rsi),%edx
 29f9f10:	test   %edx,%edx
 29f9f12:	je     29fc863 <wasm[0]::function[1015]::helper::object_read+0x1b943>
 29f9f18:	mov    %edx,0x78(%rsp)
 29f9f1c:	test   %edx,%edx
 29f9f1e:	je     29fc865 <wasm[0]::function[1015]::helper::object_read+0x1b945>
 29f9f24:	mov    0x190(%rsp),%rsi
 29f9f2c:	mov    0x190(%rsp),%rdi
 29f9f34:	call   2ac6040 <wasm[0]::function[1049]::helper::realm_ensure_errors>
 29f9f39:	mov    0x78(%rsp),%esi
 29f9f3d:	test   %esi,%esi
 29f9f3f:	je     29fc867 <wasm[0]::function[1015]::helper::object_read+0x1b947>
 29f9f45:	test   %esi,%esi
 29f9f47:	je     29fc869 <wasm[0]::function[1015]::helper::object_read+0x1b949>
 29f9f4d:	mov    0x2e0(%rsp),%r12
 29f9f55:	mov    0x28(%r12),%rdi
 29f9f5a:	mov    0x20(%r12),%r8
 29f9f5f:	mov    %esi,%r10d
 29f9f62:	lea    (%r8,%r10,1),%rsi
 29f9f66:	xor    %r9,%r9
 29f9f69:	cmp    %rdi,%r10
 29f9f6c:	cmova  %r9,%rsi
 29f9f70:	mov    0x2c(%rsi),%eax
 29f9f73:	test   %eax,%eax
 29f9f75:	je     29fc86b <wasm[0]::function[1015]::helper::object_read+0x1b94b>
 29f9f7b:	test   %eax,%eax
 29f9f7d:	je     29fc86d <wasm[0]::function[1015]::helper::object_read+0x1b94d>
 29f9f83:	mov    %eax,%ecx
 29f9f85:	lea    0x10(%r8,%rcx,1),%r11
 29f9f8a:	cmp    %rdi,%rcx
 29f9f8d:	cmova  %r9,%r11
 29f9f91:	mov    (%r11),%esi
 29f9f94:	cmp    $0x3,%esi
 29f9f97:	jbe    29fc86f <wasm[0]::function[1015]::helper::object_read+0x1b94f>
 29f9f9d:	mov    %esi,%ecx
 29f9f9f:	shl    $0x2,%rcx
 29f9fa3:	shr    $0x20,%rcx
 29f9fa7:	test   %rcx,%rcx
 29f9faa:	jne    29fc871 <wasm[0]::function[1015]::helper::object_read+0x1b951>
 29f9fb0:	shl    $0x2,%esi
 29f9fb3:	add    $0x14,%esi
 29f9fb6:	jb     29fc873 <wasm[0]::function[1015]::helper::object_read+0x1b953>
 29f9fbc:	add    %esi,%eax
 29f9fbe:	jb     29fc875 <wasm[0]::function[1015]::helper::object_read+0x1b955>
 29f9fc4:	mov    %eax,%ecx
 29f9fc6:	lea    (%r8,%rcx,1),%rax
 29f9fca:	cmp    %rdi,%rcx
 29f9fcd:	cmova  %r9,%rax
 29f9fd1:	sub    $0x20,%esi
 29f9fd4:	sub    %rsi,%rax
 29f9fd7:	mov    (%rax),%eax
 29f9fd9:	test   %eax,%eax
 29f9fdb:	je     29fc877 <wasm[0]::function[1015]::helper::object_read+0x1b957>
 29f9fe1:	test   %eax,%eax
 29f9fe3:	je     29fc879 <wasm[0]::function[1015]::helper::object_read+0x1b959>
 29f9fe9:	mov    %eax,%ecx
 29f9feb:	lea    (%r8,%rcx,1),%rax
 29f9fef:	cmp    %rdi,%rcx
 29f9ff2:	cmova  %r9,%rax
 29f9ff6:	mov    0x18(%rax),%r12d
 29f9ffa:	mov    0x10(%rax),%rbx
 29f9ffe:	mov    0x1c(%rax),%eax
 29fa001:	mov    %eax,0x78(%rsp)
 29fa005:	mov    $0x6,%eax
 29fa00a:	mov    %rax,0x280(%rsp)
 29fa012:	cmp    $0x6,%r12d
 29fa016:	sete   %cl
 29fa019:	cmp    $0x7,%r12d
 29fa01d:	sete   %al
 29fa020:	or     %eax,%ecx
 29fa022:	cmp    $0x8,%r12d
 29fa026:	sete   %al
 29fa029:	or     %eax,%ecx
 29fa02b:	cmp    $0x9,%r12d
 29fa02f:	sete   %al
 29fa032:	or     %eax,%ecx
 29fa034:	movzbl %cl,%eax
 29fa037:	test   %eax,%eax
 29fa039:	je     29fc87b <wasm[0]::function[1015]::helper::object_read+0x1b95b>
 29fa03f:	mov    $0x997,%edx
 29fa044:	mov    0x190(%rsp),%rsi
 29fa04c:	mov    0x190(%rsp),%rdi
 29fa054:	call   2f307a0 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 29fa059:	mov    %rdi,%rcx
 29fa05c:	mov    %rdi,0x298(%rsp)
 29fa064:	xor    %ecx,%edi
 29fa066:	mov    %rdi,0x298(%rsp)
 29fa06e:	test   %eax,%eax
 29fa070:	je     29fc87d <wasm[0]::function[1015]::helper::object_read+0x1b95d>
 29fa076:	mov    0x78(%rsp),%r9d
 29fa07b:	mov    $0x5,%edx
 29fa080:	mov    %eax,(%rsp)
 29fa083:	mov    %r12,%rcx
 29fa086:	mov    0x190(%rsp),%rsi
 29fa08e:	mov    %rbx,%r8
 29fa091:	mov    %rsi,%rdi
 29fa094:	call   2f30500 <wasm[0]::function[1101]::helper::runtime_error_for_throw>
 29fa099:	sub    $0x10,%rsp
 29fa09d:	test   %eax,%eax
 29fa09f:	je     29fc87f <wasm[0]::function[1015]::helper::object_read+0x1b95f>
 29fa0a5:	mov    %rcx,%rdx
 29fa0a8:	mov    %rcx,0x288(%rsp)
 29fa0b0:	xor    %rdx,%rcx
 29fa0b3:	mov    %rcx,0x288(%rsp)
 29fa0bb:	mov    0x278(%rsp),%rsi
 29fa0c3:	jmp    29fa43a <wasm[0]::function[1015]::helper::object_read+0x1951a>
 29fa0c8:	mov    0x2a8(%rsp),%rcx
 29fa0d0:	mov    0x2b0(%rsp),%rdx
 29fa0d8:	mov    0x1a8(%rsp),%r9
 29fa0e0:	mov    0x70(%rsp),%eax
 29fa0e4:	test   %eax,%eax
 29fa0e6:	je     29fc881 <wasm[0]::function[1015]::helper::object_read+0x1b961>
 29fa0ec:	mov    0x58(%rsp),%r8d
 29fa0f1:	mov    0x60(%rsp),%r10d
 29fa0f6:	mov    0x68(%rsp),%esi
 29fa0fa:	mov    0x50(%rsp),%edi
 29fa0fe:	mov    %r12,(%rsp)
 29fa102:	mov    %r10d,0x8(%rsp)
 29fa107:	mov    0x1b8(%rsp),%r10
 29fa10f:	mov    %r10d,0x10(%rsp)
 29fa114:	mov    0x1c0(%rsp),%r10
 29fa11c:	mov    %r10,0x18(%rsp)
 29fa121:	mov    %esi,0x20(%rsp)
 29fa125:	mov    %edi,0x28(%rsp)
 29fa129:	mov    %eax,0x30(%rsp)
 29fa12d:	mov    0x190(%rsp),%rsi
 29fa135:	mov    %rsi,%rdi
 29fa138:	call   29e0f20 <wasm[0]::function[1015]::helper::object_read>
 29fa13d:	sub    $0x40,%rsp
 29fa141:	mov    %rdi,0x298(%rsp)
 29fa149:	mov    %rcx,0x288(%rsp)
 29fa151:	mov    %rax,0x280(%rsp)
 29fa159:	mov    %rdx,%rax
 29fa15c:	jmp    29fa43a <wasm[0]::function[1015]::helper::object_read+0x1951a>
 29fa161:	mov    %rdi,0x298(%rsp)
 29fa169:	mov    %r15,%rcx
 29fa16c:	mov    %rax,%r8
 29fa16f:	mov    %rdx,%rax
 29fa172:	mov    %r8,%rdx
 29fa175:	mov    %rdx,0x280(%rsp)
 29fa17d:	mov    %rcx,0x288(%rsp)
 29fa185:	jmp    29fa43a <wasm[0]::function[1015]::helper::object_read+0x1951a>
 29fa18a:	mov    0x50(%rsp),%eax
 29fa18e:	xor    %edx,%edx
 29fa190:	mov    %eax,0x48(%rsp)
 29fa194:	mov    %edx,0x50(%rsp)
 29fa198:	mov    0x2e8(%rsp),%r13
 29fa1a0:	mov    0x0(%r13),%rax
 29fa1a4:	mov    0x228(%rsp),%rcx
 29fa1ac:	cmp    %rcx,%rax
 29fa1af:	jae    29fbb09 <wasm[0]::function[1015]::helper::object_read+0x1abe9>
 29fa1b5:	jmp    29fa1c2 <wasm[0]::function[1015]::helper::object_read+0x192a2>
 29fa1ba:	mov    %rcx,0x228(%rsp)
 29fa1c2:	mov    0x48(%rsp),%eax
 29fa1c6:	mov    0x50(%rsp),%edx
 29fa1ca:	test   %eax,%eax
 29fa1cc:	je     29fa241 <wasm[0]::function[1015]::helper::object_read+0x19321>
 29fa1d2:	mov    0x48(%rsp),%ecx
 29fa1d6:	test   %ecx,%ecx
 29fa1d8:	je     29fc883 <wasm[0]::function[1015]::helper::object_read+0x1b963>
 29fa1de:	mov    0x2e0(%rsp),%r12
 29fa1e6:	mov    0x28(%r12),%rax
 29fa1eb:	mov    0x20(%r12),%rsi
 29fa1f0:	mov    %ecx,%edx
 29fa1f2:	lea    (%rsi,%rdx,1),%rcx
 29fa1f6:	xor    %rsi,%rsi
 29fa1f9:	cmp    %rax,%rdx
 29fa1fc:	cmova  %rsi,%rcx
 29fa200:	mov    0x10(%rcx),%edx
 29fa203:	test   %edx,%edx
 29fa205:	jne    29fa241 <wasm[0]::function[1015]::helper::object_read+0x19321>
 29fa20b:	mov    0x48(%rsp),%edi
 29fa20f:	test   %edi,%edi
 29fa211:	je     29fc885 <wasm[0]::function[1015]::helper::object_read+0x1b965>
 29fa217:	mov    0x2e0(%rsp),%r12
 29fa21f:	mov    0x28(%r12),%rsi
 29fa224:	mov    %edi,%r8d
 29fa227:	mov    %r8,%rdi
 29fa22a:	add    0x20(%r12),%rdi
 29fa22f:	xor    %r9,%r9
 29fa232:	cmp    %rsi,%r8
 29fa235:	cmova  %r9,%rdi
 29fa239:	mov    0x1c(%rdi),%eax
 29fa23c:	jmp    29fa190 <wasm[0]::function[1015]::helper::object_read+0x19270>
 29fa241:	test   %edx,%edx
 29fa243:	jne    29fa25f <wasm[0]::function[1015]::helper::object_read+0x1933f>
 29fa249:	mov    0x190(%rsp),%rsi
 29fa251:	mov    0x8c0(%rsi),%edx
 29fa257:	test   %edx,%edx
 29fa259:	je     29fc887 <wasm[0]::function[1015]::helper::object_read+0x1b967>
 29fa25f:	mov    %edx,0x48(%rsp)
 29fa263:	test   %edx,%edx
 29fa265:	je     29fc889 <wasm[0]::function[1015]::helper::object_read+0x1b969>
 29fa26b:	mov    0x190(%rsp),%rsi
 29fa273:	mov    0x190(%rsp),%rdi
 29fa27b:	call   2ac6040 <wasm[0]::function[1049]::helper::realm_ensure_errors>
 29fa280:	mov    0x48(%rsp),%edx
 29fa284:	test   %edx,%edx
 29fa286:	je     29fc88b <wasm[0]::function[1015]::helper::object_read+0x1b96b>
 29fa28c:	test   %edx,%edx
 29fa28e:	je     29fc88d <wasm[0]::function[1015]::helper::object_read+0x1b96d>
 29fa294:	mov    0x2e0(%rsp),%r12
 29fa29c:	mov    0x28(%r12),%rax
 29fa2a1:	mov    0x20(%r12),%rcx
 29fa2a6:	mov    %edx,%edi
 29fa2a8:	lea    (%rcx,%rdi,1),%rsi
 29fa2ac:	xor    %rdx,%rdx
 29fa2af:	cmp    %rax,%rdi
 29fa2b2:	cmova  %rdx,%rsi
 29fa2b6:	mov    0x2c(%rsi),%esi
 29fa2b9:	test   %esi,%esi
 29fa2bb:	je     29fc88f <wasm[0]::function[1015]::helper::object_read+0x1b96f>
 29fa2c1:	test   %esi,%esi
 29fa2c3:	je     29fc891 <wasm[0]::function[1015]::helper::object_read+0x1b971>
 29fa2c9:	mov    %esi,%r8d
 29fa2cc:	lea    0x10(%rcx,%r8,1),%rdi
 29fa2d1:	cmp    %rax,%r8
 29fa2d4:	cmova  %rdx,%rdi
 29fa2d8:	mov    (%rdi),%edi
 29fa2da:	cmp    $0x3,%edi
 29fa2dd:	jbe    29fc893 <wasm[0]::function[1015]::helper::object_read+0x1b973>
 29fa2e3:	mov    %edi,%r8d
 29fa2e6:	shl    $0x2,%r8
 29fa2ea:	shr    $0x20,%r8
 29fa2ee:	test   %r8,%r8
 29fa2f1:	jne    29fc895 <wasm[0]::function[1015]::helper::object_read+0x1b975>
 29fa2f7:	shl    $0x2,%edi
 29fa2fa:	add    $0x14,%edi
 29fa2fd:	jb     29fc897 <wasm[0]::function[1015]::helper::object_read+0x1b977>
 29fa303:	add    %edi,%esi
 29fa305:	jb     29fc899 <wasm[0]::function[1015]::helper::object_read+0x1b979>
 29fa30b:	mov    %esi,%r8d
 29fa30e:	lea    (%rcx,%r8,1),%rsi
 29fa312:	cmp    %rax,%r8
 29fa315:	cmova  %rdx,%rsi
 29fa319:	sub    $0x20,%edi
 29fa31c:	sub    %rdi,%rsi
 29fa31f:	mov    (%rsi),%esi
 29fa321:	test   %esi,%esi
 29fa323:	je     29fc89b <wasm[0]::function[1015]::helper::object_read+0x1b97b>
 29fa329:	test   %esi,%esi
 29fa32b:	je     29fc89d <wasm[0]::function[1015]::helper::object_read+0x1b97d>
 29fa331:	mov    %esi,%esi
 29fa333:	add    %rsi,%rcx
 29fa336:	cmp    %rax,%rsi
 29fa339:	cmova  %rdx,%rcx
 29fa33d:	mov    0x18(%rcx),%r12d
 29fa341:	mov    0x10(%rcx),%rbx
 29fa345:	mov    0x1c(%rcx),%eax
 29fa348:	mov    %eax,0x48(%rsp)
 29fa34c:	mov    $0x6,%eax
 29fa351:	mov    %rax,0x280(%rsp)
 29fa359:	cmp    $0x6,%r12d
 29fa35d:	sete   %cl
 29fa360:	cmp    $0x7,%r12d
 29fa364:	sete   %al
 29fa367:	or     %eax,%ecx
 29fa369:	cmp    $0x8,%r12d
 29fa36d:	sete   %al
 29fa370:	or     %eax,%ecx
 29fa372:	cmp    $0x9,%r12d
 29fa376:	sete   %al
 29fa379:	or     %eax,%ecx
 29fa37b:	movzbl %cl,%eax
 29fa37e:	test   %eax,%eax
 29fa380:	je     29fc89f <wasm[0]::function[1015]::helper::object_read+0x1b97f>
 29fa386:	mov    $0x9a6,%edx
 29fa38b:	mov    0x190(%rsp),%rsi
 29fa393:	mov    0x190(%rsp),%rdi
 29fa39b:	call   2f307a0 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 29fa3a0:	mov    %rdi,%rcx
 29fa3a3:	mov    %rdi,0x298(%rsp)
 29fa3ab:	xor    %ecx,%edi
 29fa3ad:	mov    %rdi,0x298(%rsp)
 29fa3b5:	test   %eax,%eax
 29fa3b7:	je     29fc8a1 <wasm[0]::function[1015]::helper::object_read+0x1b981>
 29fa3bd:	mov    0x48(%rsp),%r9d
 29fa3c2:	mov    $0x5,%edx
 29fa3c7:	mov    %eax,(%rsp)
 29fa3ca:	mov    %r12,%rcx
 29fa3cd:	mov    0x190(%rsp),%rsi
 29fa3d5:	mov    %rbx,%r8
 29fa3d8:	mov    %rsi,%rdi
 29fa3db:	call   2f30500 <wasm[0]::function[1101]::helper::runtime_error_for_throw>
 29fa3e0:	sub    $0x10,%rsp
 29fa3e4:	test   %eax,%eax
 29fa3e6:	je     29fc8a3 <wasm[0]::function[1015]::helper::object_read+0x1b983>
 29fa3ec:	mov    %rcx,%rdx
 29fa3ef:	mov    %rcx,0x288(%rsp)
 29fa3f7:	xor    %rdx,%rcx
 29fa3fa:	mov    %rcx,0x288(%rsp)
 29fa402:	mov    0x278(%rsp),%rsi
 29fa40a:	jmp    29fa43a <wasm[0]::function[1015]::helper::object_read+0x1951a>
 29fa40f:	mov    0x2d8(%rsp),%rcx
 29fa417:	mov    %rdx,%rax
 29fa41a:	mov    0x2d0(%rsp),%rdx
 29fa422:	mov    %rdx,0x280(%rsp)
 29fa42a:	mov    %rcx,0x288(%rsp)
 29fa432:	mov    %rdi,0x298(%rsp)
 29fa43a:	mov    0x298(%rsp),%rdi
 29fa442:	mov    %rax,%rdx
 29fa445:	mov    0x288(%rsp),%rcx
 29fa44d:	mov    0x280(%rsp),%rax
 29fa455:	mov    0x2f0(%rsp),%rbx
 29fa45d:	mov    0x2f8(%rsp),%r12
 29fa465:	mov    0x300(%rsp),%r13
 29fa46d:	mov    0x308(%rsp),%r14
 29fa475:	mov    0x310(%rsp),%r15
 29fa47d:	add    $0x320,%rsp
 29fa484:	mov    %rbp,%rsp
 29fa487:	pop    %rbp
 29fa488:	ret    $0x40
 29fa48b:	mov    0x190(%rsp),%rdi
 29fa493:	call   3018d19 <wasmtime_builtin_new_epoch>
 29fa498:	mov    %rax,0x228(%rsp)
 29fa4a0:	jmp    29e1029 <wasm[0]::function[1015]::helper::object_read+0x109>
 29fa4a5:	mov    0x2e0(%rsp),%r12
 29fa4ad:	mov    0x8(%r12),%rax
 29fa4b2:	mov    %rax,0x228(%rsp)
 29fa4ba:	cmp    %rax,%rdx
 29fa4bd:	jb     29e15d0 <wasm[0]::function[1015]::helper::object_read+0x6b0>
 29fa4c3:	mov    0x190(%rsp),%rdi
 29fa4cb:	call   3018d19 <wasmtime_builtin_new_epoch>
 29fa4d0:	mov    %rax,0x228(%rsp)
 29fa4d8:	mov    0x240(%rsp),%r13
 29fa4e0:	jmp    29e15d8 <wasm[0]::function[1015]::helper::object_read+0x6b8>
 29fa4e5:	mov    0x2e0(%rsp),%r12
 29fa4ed:	mov    0x8(%r12),%rax
 29fa4f2:	mov    %rax,0x228(%rsp)
 29fa4fa:	cmp    %rax,%rcx
 29fa4fd:	jb     29e2403 <wasm[0]::function[1015]::helper::object_read+0x14e3>
 29fa503:	mov    0x190(%rsp),%rdi
 29fa50b:	call   3018d19 <wasmtime_builtin_new_epoch>
 29fa510:	mov    %rax,0x228(%rsp)
 29fa518:	jmp    29e2403 <wasm[0]::function[1015]::helper::object_read+0x14e3>
 29fa51d:	mov    0x2e0(%rsp),%r12
 29fa525:	mov    0x8(%r12),%rax
 29fa52a:	mov    %rax,0x228(%rsp)
 29fa532:	cmp    %rax,%rcx
 29fa535:	jb     29e325b <wasm[0]::function[1015]::helper::object_read+0x233b>
 29fa53b:	mov    0x190(%rsp),%rdi
 29fa543:	call   3018d19 <wasmtime_builtin_new_epoch>
 29fa548:	mov    %rax,0x228(%rsp)
 29fa550:	jmp    29e325b <wasm[0]::function[1015]::helper::object_read+0x233b>
 29fa555:	mov    0x2e0(%rsp),%r12
 29fa55d:	mov    0x8(%r12),%rcx
 29fa562:	mov    %rcx,0x228(%rsp)
 29fa56a:	cmp    %rcx,%rax
 29fa56d:	jb     29e381f <wasm[0]::function[1015]::helper::object_read+0x28ff>
 29fa573:	mov    0x190(%rsp),%rdi
 29fa57b:	call   3018d19 <wasmtime_builtin_new_epoch>
 29fa580:	mov    %rax,0x228(%rsp)
 29fa588:	jmp    29e381f <wasm[0]::function[1015]::helper::object_read+0x28ff>
 29fa58d:	mov    $0xa800000e,%esi
 29fa592:	mov    0x190(%rsp),%rdi
 29fa59a:	mov    0x28(%rdi),%rax
 29fa59e:	mov    0x194(%rax),%edx
 29fa5a4:	mov    $0x10,%r8d
 29fa5aa:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
 29fa5af:	mov    %eax,%ecx
 29fa5b1:	mov    0x2e0(%rsp),%r12
 29fa5b9:	add    0x20(%r12),%rcx
 29fa5be:	jmp    29e40bd <wasm[0]::function[1015]::helper::object_read+0x319d>
 29fa5c3:	mov    0x2e0(%rsp),%r12
 29fa5cb:	mov    0x8(%r12),%rax
 29fa5d0:	mov    %rax,0x228(%rsp)
 29fa5d8:	cmp    %rax,%rcx
 29fa5db:	jb     29e41f5 <wasm[0]::function[1015]::helper::object_read+0x32d5>
 29fa5e1:	mov    0x190(%rsp),%rdi
 29fa5e9:	call   3018d19 <wasmtime_builtin_new_epoch>
 29fa5ee:	mov    %rax,0x228(%rsp)
 29fa5f6:	jmp    29e41f5 <wasm[0]::function[1015]::helper::object_read+0x32d5>
 29fa5fb:	mov    0x2e0(%rsp),%r12
 29fa603:	mov    0x8(%r12),%rax
 29fa608:	mov    %rax,0x228(%rsp)
 29fa610:	cmp    %rax,%r8
 29fa613:	jb     29e432b <wasm[0]::function[1015]::helper::object_read+0x340b>
 29fa619:	mov    0x190(%rsp),%rdi
 29fa621:	call   3018d19 <wasmtime_builtin_new_epoch>
 29fa626:	mov    %rax,0x228(%rsp)
 29fa62e:	mov    0x240(%rsp),%rcx
 29fa636:	jmp    29e4333 <wasm[0]::function[1015]::helper::object_read+0x3413>
 29fa63b:	mov    $0xb0000042,%esi
 29fa640:	mov    $0x20,%ecx
 29fa645:	mov    0x220(%rsp),%rdx
 29fa64d:	mov    0x190(%rsp),%rdi
 29fa655:	mov    0x218(%rsp),%r8
 29fa65d:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
 29fa662:	mov    %eax,%ecx
 29fa664:	mov    0x2e0(%rsp),%rdx
 29fa66c:	add    0x20(%rdx),%rcx
 29fa670:	jmp    29e44d9 <wasm[0]::function[1015]::helper::object_read+0x35b9>
 29fa675:	mov    $0xb0000072,%esi
 29fa67a:	mov    $0x20,%ecx
 29fa67f:	mov    0x1d8(%rsp),%r15
 29fa687:	mov    %r15,%rdx
 29fa68a:	mov    0x190(%rsp),%rdi
 29fa692:	mov    0x218(%rsp),%r8
 29fa69a:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
 29fa69f:	mov    %eax,%edx
 29fa6a1:	mov    0x2e0(%rsp),%r12
 29fa6a9:	add    0x20(%r12),%rdx
 29fa6ae:	jmp    29e4564 <wasm[0]::function[1015]::helper::object_read+0x3644>
 29fa6b3:	mov    $0xa800000e,%esi
 29fa6b8:	mov    0x190(%rsp),%rax
 29fa6c0:	mov    0x28(%rax),%rax
 29fa6c4:	mov    0x194(%rax),%edx
 29fa6ca:	mov    $0x10,%r8d
 29fa6d0:	mov    0x190(%rsp),%rdi
 29fa6d8:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
 29fa6dd:	mov    %eax,%ecx
 29fa6df:	mov    0x2e0(%rsp),%rdx
 29fa6e7:	add    0x20(%rdx),%rcx
 29fa6eb:	jmp    29e4883 <wasm[0]::function[1015]::helper::object_read+0x3963>
 29fa6f0:	mov    0x2e0(%rsp),%r12
 29fa6f8:	mov    0x8(%r12),%rcx
 29fa6fd:	mov    %rcx,0x228(%rsp)
 29fa705:	cmp    %rcx,%rax
 29fa708:	jb     29e49a1 <wasm[0]::function[1015]::helper::object_read+0x3a81>
 29fa70e:	mov    0x190(%rsp),%rdi
 29fa716:	call   3018d19 <wasmtime_builtin_new_epoch>
 29fa71b:	mov    %rax,0x228(%rsp)
 29fa723:	jmp    29e49a1 <wasm[0]::function[1015]::helper::object_read+0x3a81>
 29fa728:	mov    0x2e0(%rsp),%r12
 29fa730:	mov    0x8(%r12),%rdx
 29fa735:	mov    %rdx,%rsi
 29fa738:	mov    %rdx,0x228(%rsp)
 29fa740:	cmp    %rsi,%rax
 29fa743:	jb     29e4ac3 <wasm[0]::function[1015]::helper::object_read+0x3ba3>
 29fa749:	mov    0x190(%rsp),%rdi
 29fa751:	call   3018d19 <wasmtime_builtin_new_epoch>
 29fa756:	mov    %rax,0x228(%rsp)
 29fa75e:	mov    0x1d8(%rsp),%rcx
 29fa766:	jmp    29e4acb <wasm[0]::function[1015]::helper::object_read+0x3bab>
 29fa76b:	mov    0x198(%rsp),%rcx
 29fa773:	mov    %rbx,%rdx
 29fa776:	mov    0x1a0(%rsp),%rsi
 29fa77e:	mov    0x190(%rsp),%rdi
 29fa786:	mov    0x2c8(%rsp),%r8
 29fa78e:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
 29fa793:	mov    %eax,%edx
 29fa795:	mov    0x2e0(%rsp),%r12
 29fa79d:	add    0x20(%r12),%rdx
 29fa7a2:	mov    0x1d0(%rsp),%rcx
 29fa7aa:	jmp    29e4bed <wasm[0]::function[1015]::helper::object_read+0x3ccd>
 29fa7af:	mov    0x2e0(%rsp),%r12
 29fa7b7:	mov    0x8(%r12),%rsi
 29fa7bc:	mov    %rsi,0x228(%rsp)
 29fa7c4:	cmp    %rsi,%rax
 29fa7c7:	jb     29e4f71 <wasm[0]::function[1015]::helper::object_read+0x4051>
 29fa7cd:	mov    0x190(%rsp),%rdi
 29fa7d5:	call   3018d19 <wasmtime_builtin_new_epoch>
 29fa7da:	mov    %rax,0x228(%rsp)
 29fa7e2:	jmp    29e4f71 <wasm[0]::function[1015]::helper::object_read+0x4051>
 29fa7e7:	mov    0x2e0(%rsp),%r12
 29fa7ef:	mov    0x8(%r12),%rcx
 29fa7f4:	mov    %rcx,0x228(%rsp)
 29fa7fc:	cmp    %rcx,%rax
 29fa7ff:	jb     29e5c1b <wasm[0]::function[1015]::helper::object_read+0x4cfb>
 29fa805:	mov    0x190(%rsp),%rdi
 29fa80d:	call   3018d19 <wasmtime_builtin_new_epoch>
 29fa812:	mov    %rax,0x228(%rsp)
 29fa81a:	jmp    29e5c1b <wasm[0]::function[1015]::helper::object_read+0x4cfb>
 29fa81f:	mov    $0xb0000002,%esi
 29fa824:	mov    0x190(%rsp),%rcx
 29fa82c:	mov    0x28(%rcx),%rdi
 29fa830:	mov    0x1d0(%rdi),%edx
 29fa836:	mov    $0x40,%ecx
 29fa83b:	mov    $0x10,%r8d
 29fa841:	mov    0x190(%rsp),%rdi
 29fa849:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
 29fa84e:	mov    %eax,%ebx
 29fa850:	mov    0x2e0(%rsp),%r12
 29fa858:	add    0x20(%r12),%rbx
 29fa85d:	jmp    29e5fab <wasm[0]::function[1015]::helper::object_read+0x508b>
 29fa862:	mov    $0xb0001ffa,%esi
 29fa867:	mov    0x190(%rsp),%rcx
 29fa86f:	mov    0x28(%rcx),%rax
 29fa873:	mov    0x1e0(%rax),%edx
 29fa879:	mov    $0x40,%ecx
 29fa87e:	mov    $0x10,%r8d
 29fa884:	mov    0x190(%rsp),%rdi
 29fa88c:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
 29fa891:	mov    %eax,%ebx
 29fa893:	mov    0x2e0(%rsp),%r12
 29fa89b:	add    0x20(%r12),%rbx
 29fa8a0:	mov    %rax,%rdx
 29fa8a3:	jmp    29e60ce <wasm[0]::function[1015]::helper::object_read+0x51ae>
 29fa8a8:	mov    $0xb00300fa,%esi
 29fa8ad:	mov    0x190(%rsp),%rcx
 29fa8b5:	mov    0x28(%rcx),%rax
 29fa8b9:	mov    0x1d4(%rax),%edx
 29fa8bf:	mov    $0x50,%ecx
 29fa8c4:	mov    $0x10,%r8d
 29fa8ca:	mov    0x190(%rsp),%rdi
 29fa8d2:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
 29fa8d7:	mov    %eax,%ecx
 29fa8d9:	mov    0x2e0(%rsp),%r12
 29fa8e1:	add    0x20(%r12),%rcx
 29fa8e6:	jmp    29e6219 <wasm[0]::function[1015]::helper::object_read+0x52f9>
 29fa8eb:	mov    $0xb0000042,%esi
 29fa8f0:	mov    0x190(%rsp),%rcx
 29fa8f8:	mov    0x28(%rcx),%rax
 29fa8fc:	mov    0x120(%rax),%edx
 29fa902:	mov    $0x20,%ecx
 29fa907:	mov    $0x10,%r8d
 29fa90d:	mov    0x190(%rsp),%rdi
 29fa915:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
 29fa91a:	mov    %eax,%ecx
 29fa91c:	mov    0x2e0(%rsp),%r12
 29fa924:	add    0x20(%r12),%rcx
 29fa929:	jmp    29e634d <wasm[0]::function[1015]::helper::object_read+0x542d>
 29fa92e:	mov    $0xb0000042,%esi
 29fa933:	mov    0x190(%rsp),%rcx
 29fa93b:	mov    0x28(%rcx),%rax
 29fa93f:	mov    0x120(%rax),%edx
 29fa945:	mov    $0x20,%ecx
 29fa94a:	mov    $0x10,%r8d
 29fa950:	mov    0x190(%rsp),%rdi
 29fa958:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
 29fa95d:	mov    %eax,%esi
 29fa95f:	mov    0x2e0(%rsp),%r12
 29fa967:	add    0x20(%r12),%rsi
 29fa96c:	jmp    29e63d8 <wasm[0]::function[1015]::helper::object_read+0x54b8>
 29fa971:	mov    $0xa800000e,%esi
 29fa976:	mov    0x190(%rsp),%rcx
 29fa97e:	mov    0x28(%rcx),%rax
 29fa982:	mov    0x1b4(%rax),%edx
 29fa988:	mov    $0x1c,%ecx
 29fa98d:	mov    $0x10,%r8d
 29fa993:	mov    0x190(%rsp),%rdi
 29fa99b:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
 29fa9a0:	mov    %eax,%edx
 29fa9a2:	mov    0x2e0(%rsp),%r12
 29fa9aa:	add    0x20(%r12),%rdx
 29fa9af:	jmp    29e647a <wasm[0]::function[1015]::helper::object_read+0x555a>
 29fa9b4:	mov    0x2e0(%rsp),%r12
 29fa9bc:	mov    0x8(%r12),%rax
 29fa9c1:	mov    %rax,0x228(%rsp)
 29fa9c9:	cmp    %rax,%rcx
 29fa9cc:	jb     29e6c66 <wasm[0]::function[1015]::helper::object_read+0x5d46>
 29fa9d2:	mov    0x190(%rsp),%rdi
 29fa9da:	call   3018d19 <wasmtime_builtin_new_epoch>
 29fa9df:	mov    %rax,0x228(%rsp)
 29fa9e7:	jmp    29e6c66 <wasm[0]::function[1015]::helper::object_read+0x5d46>
 29fa9ec:	mov    0x2e0(%rsp),%r12
 29fa9f4:	mov    0x8(%r12),%rax
 29fa9f9:	mov    %rax,0x228(%rsp)
 29faa01:	cmp    %rax,%rcx
 29faa04:	jb     29e7977 <wasm[0]::function[1015]::helper::object_read+0x6a57>
 29faa0a:	mov    0x190(%rsp),%rdi
 29faa12:	call   3018d19 <wasmtime_builtin_new_epoch>
 29faa17:	mov    %rax,0x228(%rsp)
 29faa1f:	jmp    29e7977 <wasm[0]::function[1015]::helper::object_read+0x6a57>
 29faa24:	mov    0x2e0(%rsp),%r12
 29faa2c:	mov    0x8(%r12),%rsi
 29faa31:	mov    %rsi,0x228(%rsp)
 29faa39:	cmp    %rsi,%rax
 29faa3c:	jb     29e8769 <wasm[0]::function[1015]::helper::object_read+0x7849>
 29faa42:	mov    0x190(%rsp),%rdi
 29faa4a:	call   3018d19 <wasmtime_builtin_new_epoch>
 29faa4f:	mov    %rax,0x228(%rsp)
 29faa57:	jmp    29e8769 <wasm[0]::function[1015]::helper::object_read+0x7849>
 29faa5c:	mov    0x2e0(%rsp),%r12
 29faa64:	mov    0x8(%r12),%rax
 29faa69:	mov    %rax,0x228(%rsp)
 29faa71:	cmp    %rax,%rcx
 29faa74:	jb     29e9564 <wasm[0]::function[1015]::helper::object_read+0x8644>
 29faa7a:	mov    0x190(%rsp),%rdi
 29faa82:	call   3018d19 <wasmtime_builtin_new_epoch>
 29faa87:	mov    %rax,0x228(%rsp)
 29faa8f:	jmp    29e9564 <wasm[0]::function[1015]::helper::object_read+0x8644>
 29faa94:	mov    0x2e0(%rsp),%r12
 29faa9c:	mov    0x8(%r12),%rax
 29faaa1:	mov    %rax,0x228(%rsp)
 29faaa9:	cmp    %rax,%rcx
 29faaac:	jb     29ea3f5 <wasm[0]::function[1015]::helper::object_read+0x94d5>
 29faab2:	mov    0x190(%rsp),%rdi
 29faaba:	call   3018d19 <wasmtime_builtin_new_epoch>
 29faabf:	mov    %rax,0x228(%rsp)
 29faac7:	jmp    29ea3f5 <wasm[0]::function[1015]::helper::object_read+0x94d5>
 29faacc:	mov    0x2e0(%rsp),%r12
 29faad4:	mov    0x8(%r12),%rax
 29faad9:	mov    %rax,0x228(%rsp)
 29faae1:	cmp    %rax,%rcx
 29faae4:	jb     29eb29f <wasm[0]::function[1015]::helper::object_read+0xa37f>
 29faaea:	mov    0x190(%rsp),%rdi
 29faaf2:	call   3018d19 <wasmtime_builtin_new_epoch>
 29faaf7:	mov    %rax,0x228(%rsp)
 29faaff:	jmp    29eb29f <wasm[0]::function[1015]::helper::object_read+0xa37f>
 29fab04:	mov    $0xb0000042,%esi
 29fab09:	mov    0x190(%rsp),%rcx
 29fab11:	mov    0x28(%rcx),%rax
 29fab15:	mov    0x120(%rax),%edx
 29fab1b:	mov    $0x20,%ecx
 29fab20:	mov    $0x10,%r8d
 29fab26:	mov    0x190(%rsp),%rdi
 29fab2e:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
 29fab33:	mov    %eax,%ecx
 29fab35:	mov    0x2e0(%rsp),%r12
 29fab3d:	add    0x20(%r12),%rcx
 29fab42:	jmp    29ec462 <wasm[0]::function[1015]::helper::object_read+0xb542>
 29fab47:	mov    $0xb0000042,%esi
 29fab4c:	mov    0x190(%rsp),%rcx
 29fab54:	mov    0x28(%rcx),%rdx
 29fab58:	mov    0x120(%rdx),%edx
 29fab5e:	mov    $0x20,%ecx
 29fab63:	mov    $0x10,%r8d
 29fab69:	mov    0x190(%rsp),%rdi
 29fab71:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
 29fab76:	mov    %eax,%ecx
 29fab78:	mov    0x2e0(%rsp),%r12
 29fab80:	add    0x20(%r12),%rcx
 29fab85:	jmp    29ec4ee <wasm[0]::function[1015]::helper::object_read+0xb5ce>
 29fab8a:	mov    $0xb0000042,%esi
 29fab8f:	mov    0x190(%rsp),%rcx
 29fab97:	mov    0x28(%rcx),%rax
 29fab9b:	mov    0x120(%rax),%edx
 29faba1:	mov    $0x20,%ecx
 29faba6:	mov    $0x10,%r8d
 29fabac:	mov    0x190(%rsp),%rdi
 29fabb4:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
 29fabb9:	mov    %eax,%ecx
 29fabbb:	mov    0x2e0(%rsp),%r12
 29fabc3:	add    0x20(%r12),%rcx
 29fabc8:	jmp    29ec57b <wasm[0]::function[1015]::helper::object_read+0xb65b>
 29fabcd:	mov    $0xb0000072,%esi
 29fabd2:	mov    0x190(%rsp),%rcx
 29fabda:	mov    0x28(%rcx),%rax
 29fabde:	mov    0x13c(%rax),%edx
 29fabe4:	mov    $0x20,%ecx
 29fabe9:	mov    $0x10,%r8d
 29fabef:	mov    0x190(%rsp),%rdi
 29fabf7:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
 29fabfc:	mov    %eax,%ecx
 29fabfe:	mov    0x2e0(%rsp),%r12
 29fac06:	add    0x20(%r12),%rcx
 29fac0b:	jmp    29ec644 <wasm[0]::function[1015]::helper::object_read+0xb724>
 29fac10:	mov    $0xb0000072,%esi
 29fac15:	mov    0x190(%rsp),%rcx
 29fac1d:	mov    0x28(%rcx),%rax
 29fac21:	mov    0x13c(%rax),%edx
 29fac27:	mov    $0x20,%ecx
 29fac2c:	mov    $0x10,%r8d
 29fac32:	mov    0x190(%rsp),%rdi
 29fac3a:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
 29fac3f:	mov    %eax,%ecx
 29fac41:	mov    0x2e0(%rsp),%r12
 29fac49:	add    0x20(%r12),%rcx
 29fac4e:	jmp    29ec71d <wasm[0]::function[1015]::helper::object_read+0xb7fd>
 29fac53:	mov    0x2e0(%rsp),%r12
 29fac5b:	mov    0x8(%r12),%rdi
 29fac60:	mov    %rdi,%r9
 29fac63:	mov    %rdi,0x228(%rsp)
 29fac6b:	cmp    %r9,%rax
 29fac6e:	jb     29ecb1d <wasm[0]::function[1015]::helper::object_read+0xbbfd>
 29fac74:	mov    0x190(%rsp),%rdi
 29fac7c:	call   3018d19 <wasmtime_builtin_new_epoch>
 29fac81:	mov    %rax,0x228(%rsp)
 29fac89:	jmp    29ecb1d <wasm[0]::function[1015]::helper::object_read+0xbbfd>
 29fac8e:	mov    0x2e0(%rsp),%rax
 29fac96:	mov    0x8(%rax),%rax
 29fac9a:	mov    %rax,0x228(%rsp)
 29faca2:	cmp    %rax,%rcx
 29faca5:	jb     29ed0ec <wasm[0]::function[1015]::helper::object_read+0xc1cc>
 29facab:	mov    0x190(%rsp),%rdi
 29facb3:	call   3018d19 <wasmtime_builtin_new_epoch>
 29facb8:	mov    %rax,0x228(%rsp)
 29facc0:	jmp    29ed0ec <wasm[0]::function[1015]::helper::object_read+0xc1cc>
 29facc5:	mov    $0xb0000042,%esi
 29facca:	mov    0x190(%rsp),%rcx
 29facd2:	mov    0x28(%rcx),%rax
 29facd6:	mov    0x120(%rax),%edx
 29facdc:	mov    $0x20,%ecx
 29face1:	mov    $0x10,%r8d
 29face7:	mov    0x190(%rsp),%rdi
 29facef:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
 29facf4:	mov    %eax,%ecx
 29facf6:	mov    0x2e0(%rsp),%rdx
 29facfe:	add    0x20(%rdx),%rcx
 29fad02:	jmp    29ed556 <wasm[0]::function[1015]::helper::object_read+0xc636>
 29fad07:	mov    $0xb0000072,%esi
 29fad0c:	mov    0x190(%rsp),%rcx
 29fad14:	mov    0x28(%rcx),%rcx
 29fad18:	mov    0x13c(%rcx),%edx
 29fad1e:	mov    $0x20,%ecx
 29fad23:	mov    $0x10,%r8d
 29fad29:	mov    0x190(%rsp),%rdi
 29fad31:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
 29fad36:	mov    %eax,%r9d
 29fad39:	mov    0x2e0(%rsp),%r12
 29fad41:	add    0x20(%r12),%r9
 29fad46:	jmp    29ed619 <wasm[0]::function[1015]::helper::object_read+0xc6f9>
 29fad4b:	mov    $0xa800000e,%esi
 29fad50:	mov    0x190(%rsp),%rax
 29fad58:	mov    0x28(%rax),%r10
 29fad5c:	mov    0x194(%r10),%edx
 29fad63:	mov    $0x10,%r8d
 29fad69:	mov    0x190(%rsp),%rdi
 29fad71:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
 29fad76:	mov    %eax,%ecx
 29fad78:	mov    0x2e0(%rsp),%r12
 29fad80:	add    0x20(%r12),%rcx
 29fad85:	jmp    29edbb0 <wasm[0]::function[1015]::helper::object_read+0xcc90>
 29fad8a:	mov    0x2e0(%rsp),%r12
 29fad92:	mov    0x8(%r12),%rcx
 29fad97:	mov    %rcx,0x228(%rsp)
 29fad9f:	cmp    %rcx,%rax
 29fada2:	jb     29edcc3 <wasm[0]::function[1015]::helper::object_read+0xcda3>
 29fada8:	mov    0x190(%rsp),%rdi
 29fadb0:	call   3018d19 <wasmtime_builtin_new_epoch>
 29fadb5:	mov    %rax,0x228(%rsp)
 29fadbd:	jmp    29edcc3 <wasm[0]::function[1015]::helper::object_read+0xcda3>
 29fadc2:	mov    0x2e0(%rsp),%r12
 29fadca:	mov    0x8(%r12),%rcx
 29fadcf:	mov    %rcx,0x228(%rsp)
 29fadd7:	cmp    %rcx,%rax
 29fadda:	jb     29edde1 <wasm[0]::function[1015]::helper::object_read+0xcec1>
 29fade0:	mov    0x190(%rsp),%rdi
 29fade8:	call   3018d19 <wasmtime_builtin_new_epoch>
 29faded:	mov    %rax,0x228(%rsp)
 29fadf5:	mov    0x208(%rsp),%rcx
 29fadfd:	jmp    29edde9 <wasm[0]::function[1015]::helper::object_read+0xcec9>
 29fae02:	mov    0x1e0(%rsp),%rcx
 29fae0a:	mov    0x1e8(%rsp),%rdx
 29fae12:	mov    0x1f0(%rsp),%rsi
 29fae1a:	mov    0x190(%rsp),%rdi
 29fae22:	mov    0x1d8(%rsp),%r8
 29fae2a:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
 29fae2f:	mov    %eax,%ecx
 29fae31:	mov    0x2e0(%rsp),%r8
 29fae39:	add    0x20(%r8),%rcx
 29fae3d:	mov    0x1f8(%rsp),%r13
 29fae45:	jmp    29edf7f <wasm[0]::function[1015]::helper::object_read+0xd05f>
 29fae4a:	mov    0x1e0(%rsp),%rcx
 29fae52:	mov    %r14,%rdx
 29fae55:	mov    0x1d0(%rsp),%rsi
 29fae5d:	mov    0x190(%rsp),%rdi
 29fae65:	mov    0x1d8(%rsp),%r8
 29fae6d:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
 29fae72:	mov    %eax,%ecx
 29fae74:	mov    0x2e0(%rsp),%r12
 29fae7c:	add    0x20(%r12),%rcx
 29fae81:	jmp    29edffe <wasm[0]::function[1015]::helper::object_read+0xd0de>
 29fae86:	mov    $0xa800000e,%esi
 29fae8b:	mov    0x190(%rsp),%rax
 29fae93:	mov    0x28(%rax),%rax
 29fae97:	mov    0x194(%rax),%edx
 29fae9d:	mov    $0x10,%r8d
 29faea3:	mov    0x190(%rsp),%rdi
 29faeab:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
 29faeb0:	mov    %eax,%r8d
 29faeb3:	mov    0x2e0(%rsp),%r12
 29faebb:	add    0x20(%r12),%r8
 29faec0:	jmp    29ee2bd <wasm[0]::function[1015]::helper::object_read+0xd39d>
 29faec5:	mov    0x2e0(%rsp),%r12
 29faecd:	mov    0x8(%r12),%rcx
 29faed2:	mov    %rcx,0x228(%rsp)
 29faeda:	cmp    %rcx,%rax
 29faedd:	jb     29ee3c5 <wasm[0]::function[1015]::helper::object_read+0xd4a5>
 29faee3:	mov    0x190(%rsp),%rdi
 29faeeb:	call   3018d19 <wasmtime_builtin_new_epoch>
 29faef0:	mov    %rax,0x228(%rsp)
 29faef8:	jmp    29ee3c5 <wasm[0]::function[1015]::helper::object_read+0xd4a5>
 29faefd:	mov    0x2e0(%rsp),%r12
 29faf05:	mov    0x8(%r12),%rcx
 29faf0a:	mov    %rcx,0x228(%rsp)
 29faf12:	cmp    %rcx,%rax
 29faf15:	jb     29ee4cf <wasm[0]::function[1015]::helper::object_read+0xd5af>
 29faf1b:	mov    0x190(%rsp),%rdi
 29faf23:	call   3018d19 <wasmtime_builtin_new_epoch>
 29faf28:	mov    %rax,0x228(%rsp)
 29faf30:	mov    0x1d0(%rsp),%rdi
 29faf38:	jmp    29ee4d7 <wasm[0]::function[1015]::helper::object_read+0xd5b7>
 29faf3d:	mov    0x198(%rsp),%rcx
 29faf45:	mov    %rbx,%rdx
 29faf48:	mov    0x1a0(%rsp),%rsi
 29faf50:	mov    0x190(%rsp),%rdi
 29faf58:	mov    0x2b0(%rsp),%r8
 29faf60:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
 29faf65:	mov    %eax,%edx
 29faf67:	mov    0x2e0(%rsp),%r12
 29faf6f:	add    0x20(%r12),%rdx
 29faf74:	mov    0x1c8(%rsp),%rcx
 29faf7c:	jmp    29ee5e9 <wasm[0]::function[1015]::helper::object_read+0xd6c9>
 29faf81:	mov    0x2e0(%rsp),%r12
 29faf89:	mov    0x8(%r12),%r8
 29faf8e:	mov    %r8,%r10
 29faf91:	mov    %r8,0x228(%rsp)
 29faf99:	cmp    %r10,%rax
 29faf9c:	jb     29ee915 <wasm[0]::function[1015]::helper::object_read+0xd9f5>
 29fafa2:	mov    0x190(%rsp),%rdi
 29fafaa:	call   3018d19 <wasmtime_builtin_new_epoch>
 29fafaf:	mov    %rax,0x228(%rsp)
 29fafb7:	jmp    29ee915 <wasm[0]::function[1015]::helper::object_read+0xd9f5>
 29fafbc:	mov    $0xb0000072,%esi
 29fafc1:	mov    0x190(%rsp),%rcx
 29fafc9:	mov    0x28(%rcx),%rax
 29fafcd:	mov    0x13c(%rax),%edx
 29fafd3:	mov    $0x20,%ecx
 29fafd8:	mov    $0x10,%r8d
 29fafde:	mov    0x190(%rsp),%rdi
 29fafe6:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
 29fafeb:	mov    %rax,%r15
 29fafee:	mov    %eax,%eax
 29faff0:	mov    0x2e0(%rsp),%r12
 29faff8:	add    0x20(%r12),%rax
 29faffd:	jmp    29eed3f <wasm[0]::function[1015]::helper::object_read+0xde1f>
 29fb002:	mov    $0xb0000072,%esi
 29fb007:	mov    0x190(%rsp),%rcx
 29fb00f:	mov    0x28(%rcx),%rax
 29fb013:	mov    0x13c(%rax),%edx
 29fb019:	mov    $0x20,%ecx
 29fb01e:	mov    $0x10,%r8d
 29fb024:	mov    0x190(%rsp),%rdi
 29fb02c:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
 29fb031:	mov    %rax,%r15
 29fb034:	mov    %eax,%eax
 29fb036:	mov    0x2e0(%rsp),%r12
 29fb03e:	add    0x20(%r12),%rax
 29fb043:	jmp    29eee21 <wasm[0]::function[1015]::helper::object_read+0xdf01>
 29fb048:	mov    $0xb0000072,%esi
 29fb04d:	mov    0x190(%rsp),%rcx
 29fb055:	mov    0x28(%rcx),%rax
 29fb059:	mov    0x13c(%rax),%edx
 29fb05f:	mov    $0x20,%ecx
 29fb064:	mov    $0x10,%r8d
 29fb06a:	mov    0x190(%rsp),%rdi
 29fb072:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
 29fb077:	mov    %rax,%r15
 29fb07a:	mov    %eax,%eax
 29fb07c:	mov    0x2e0(%rsp),%r12
 29fb084:	add    0x20(%r12),%rax
 29fb089:	jmp    29ef14f <wasm[0]::function[1015]::helper::object_read+0xe22f>
 29fb08e:	mov    $0xb0000072,%esi
 29fb093:	mov    0x190(%rsp),%rcx
 29fb09b:	mov    0x28(%rcx),%rax
 29fb09f:	mov    0x13c(%rax),%edx
 29fb0a5:	mov    $0x20,%ecx
 29fb0aa:	mov    $0x10,%r8d
 29fb0b0:	mov    0x190(%rsp),%rdi
 29fb0b8:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
 29fb0bd:	mov    %rax,%r15
 29fb0c0:	mov    %eax,%eax
 29fb0c2:	mov    0x2e0(%rsp),%r12
 29fb0ca:	add    0x20(%r12),%rax
 29fb0cf:	jmp    29ef22d <wasm[0]::function[1015]::helper::object_read+0xe30d>
 29fb0d4:	mov    $0xb0000042,%esi
 29fb0d9:	mov    0x190(%rsp),%rax
 29fb0e1:	mov    0x28(%rax),%rax
 29fb0e5:	mov    0x120(%rax),%edx
 29fb0eb:	mov    $0x20,%ecx
 29fb0f0:	mov    $0x10,%r8d
 29fb0f6:	mov    0x190(%rsp),%rdi
 29fb0fe:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
 29fb103:	mov    %eax,%esi
 29fb105:	mov    0x2e0(%rsp),%rcx
 29fb10d:	add    0x20(%rcx),%rsi
 29fb111:	mov    0x270(%rsp),%rcx
 29fb119:	jmp    29effeb <wasm[0]::function[1015]::helper::object_read+0xf0cb>
 29fb11e:	mov    $0xb0000042,%esi
 29fb123:	mov    0x190(%rsp),%rax
 29fb12b:	mov    0x28(%rax),%rax
 29fb12f:	mov    0x120(%rax),%edx
 29fb135:	mov    $0x20,%ecx
 29fb13a:	mov    $0x10,%r8d
 29fb140:	mov    0x190(%rsp),%rdi
 29fb148:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
 29fb14d:	mov    %eax,%ecx
 29fb14f:	mov    0x2e0(%rsp),%rdx
 29fb157:	add    0x20(%rdx),%rcx
 29fb15b:	jmp    29f0078 <wasm[0]::function[1015]::helper::object_read+0xf158>
 29fb160:	mov    $0xb0000042,%esi
 29fb165:	mov    0x190(%rsp),%rax
 29fb16d:	mov    0x28(%rax),%rax
 29fb171:	mov    0x120(%rax),%edx
 29fb177:	mov    $0x20,%ecx
 29fb17c:	mov    $0x10,%r8d
 29fb182:	mov    0x190(%rsp),%rdi
 29fb18a:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
 29fb18f:	mov    %eax,%ecx
 29fb191:	mov    0x2e0(%rsp),%rdx
 29fb199:	add    0x20(%rdx),%rcx
 29fb19d:	jmp    29f0107 <wasm[0]::function[1015]::helper::object_read+0xf1e7>
 29fb1a2:	mov    $0xa800000e,%esi
 29fb1a7:	mov    0x190(%rsp),%rax
 29fb1af:	mov    0x28(%rax),%rax
 29fb1b3:	mov    0x1b4(%rax),%edx
 29fb1b9:	mov    $0x20,%ecx
 29fb1be:	mov    $0x10,%r8d
 29fb1c4:	mov    0x190(%rsp),%rdi
 29fb1cc:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
 29fb1d1:	mov    %eax,%edx
 29fb1d3:	mov    0x2e0(%rsp),%r12
 29fb1db:	add    0x20(%r12),%rdx
 29fb1e0:	jmp    29f01b6 <wasm[0]::function[1015]::helper::object_read+0xf296>
 29fb1e5:	mov    0x2e0(%rsp),%r12
 29fb1ed:	mov    0x8(%r12),%rax
 29fb1f2:	mov    %rax,0x228(%rsp)
 29fb1fa:	cmp    %rax,%rdx
 29fb1fd:	jb     29f050a <wasm[0]::function[1015]::helper::object_read+0xf5ea>
 29fb203:	mov    0x190(%rsp),%rdi
 29fb20b:	call   3018d19 <wasmtime_builtin_new_epoch>
 29fb210:	mov    %rax,0x228(%rsp)
 29fb218:	jmp    29f050a <wasm[0]::function[1015]::helper::object_read+0xf5ea>
 29fb21d:	mov    $0xb0000002,%esi
 29fb222:	mov    0x190(%rsp),%rax
 29fb22a:	mov    0x28(%rax),%rax
 29fb22e:	mov    0x1d0(%rax),%edx
 29fb234:	mov    $0x40,%ecx
 29fb239:	mov    $0x10,%r8d
 29fb23f:	mov    0x190(%rsp),%rdi
 29fb247:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
 29fb24c:	mov    %eax,%r12d
 29fb24f:	mov    0x2e0(%rsp),%rcx
 29fb257:	add    0x20(%rcx),%r12
 29fb25b:	jmp    29f0868 <wasm[0]::function[1015]::helper::object_read+0xf948>
 29fb260:	mov    $0xb0001ffa,%esi
 29fb265:	mov    0x190(%rsp),%rax
 29fb26d:	mov    0x28(%rax),%rax
 29fb271:	mov    0x1e0(%rax),%edx
 29fb277:	mov    $0x40,%ecx
 29fb27c:	mov    $0x10,%r8d
 29fb282:	mov    0x190(%rsp),%rdi
 29fb28a:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
 29fb28f:	mov    %eax,%r13d
 29fb292:	mov    0x2e0(%rsp),%r12
 29fb29a:	add    0x20(%r12),%r13
 29fb29f:	jmp    29f099e <wasm[0]::function[1015]::helper::object_read+0xfa7e>
 29fb2a4:	mov    $0xb00300fa,%esi
 29fb2a9:	mov    0x190(%rsp),%rax
 29fb2b1:	mov    0x28(%rax),%rax
 29fb2b5:	mov    0x1d4(%rax),%edx
 29fb2bb:	mov    $0x50,%ecx
 29fb2c0:	mov    $0x10,%r8d
 29fb2c6:	mov    0x190(%rsp),%rdi
 29fb2ce:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
 29fb2d3:	mov    %eax,%ecx
 29fb2d5:	mov    0x2e0(%rsp),%r12
 29fb2dd:	add    0x20(%r12),%rcx
 29fb2e2:	jmp    29f0afb <wasm[0]::function[1015]::helper::object_read+0xfbdb>
 29fb2e7:	mov    $0xb0000042,%esi
 29fb2ec:	mov    0x190(%rsp),%rax
 29fb2f4:	mov    0x28(%rax),%rax
 29fb2f8:	mov    0x120(%rax),%edx
 29fb2fe:	mov    $0x20,%ecx
 29fb303:	mov    $0x10,%r8d
 29fb309:	mov    0x190(%rsp),%rdi
 29fb311:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
 29fb316:	mov    %eax,%esi
 29fb318:	mov    0x2e0(%rsp),%r12
 29fb320:	add    0x20(%r12),%rsi
 29fb325:	jmp    29f0c2c <wasm[0]::function[1015]::helper::object_read+0xfd0c>
 29fb32a:	mov    $0xb0000042,%esi
 29fb32f:	mov    0x190(%rsp),%rdi
 29fb337:	mov    0x28(%rdi),%rax
 29fb33b:	mov    0x120(%rax),%edx
 29fb341:	mov    $0x20,%ecx
 29fb346:	mov    $0x10,%r8d
 29fb34c:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
 29fb351:	mov    %eax,%ecx
 29fb353:	mov    0x2e0(%rsp),%r12
 29fb35b:	add    0x20(%r12),%rcx
 29fb360:	jmp    29f0cc0 <wasm[0]::function[1015]::helper::object_read+0xfda0>
 29fb365:	mov    $0xa800000e,%esi
 29fb36a:	mov    0x190(%rsp),%rax
 29fb372:	mov    0x28(%rax),%rax
 29fb376:	mov    0x1b4(%rax),%edx
 29fb37c:	mov    $0x10,%r8d
 29fb382:	mov    %r14,%rcx
 29fb385:	mov    0x190(%rsp),%rdi
 29fb38d:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
 29fb392:	mov    %eax,%ecx
 29fb394:	mov    0x2e0(%rsp),%r12
 29fb39c:	add    0x20(%r12),%rcx
 29fb3a1:	jmp    29f0d6e <wasm[0]::function[1015]::helper::object_read+0xfe4e>
 29fb3a6:	mov    0x2e0(%rsp),%r12
 29fb3ae:	mov    0x8(%r12),%rax
 29fb3b3:	mov    %rax,0x228(%rsp)
 29fb3bb:	cmp    %rax,%rcx
 29fb3be:	jb     29f14c0 <wasm[0]::function[1015]::helper::object_read+0x105a0>
 29fb3c4:	mov    0x190(%rsp),%rdi
 29fb3cc:	call   3018d19 <wasmtime_builtin_new_epoch>
 29fb3d1:	mov    %rax,0x228(%rsp)
 29fb3d9:	jmp    29f14c0 <wasm[0]::function[1015]::helper::object_read+0x105a0>
 29fb3de:	mov    0x2e0(%rsp),%r12
 29fb3e6:	mov    0x8(%r12),%rax
 29fb3eb:	mov    %rax,0x228(%rsp)
 29fb3f3:	cmp    %rax,%rcx
 29fb3f6:	jb     29f2071 <wasm[0]::function[1015]::helper::object_read+0x11151>
 29fb3fc:	mov    0x190(%rsp),%rdi
 29fb404:	call   3018d19 <wasmtime_builtin_new_epoch>
 29fb409:	mov    %rax,0x228(%rsp)
 29fb411:	jmp    29f2071 <wasm[0]::function[1015]::helper::object_read+0x11151>
 29fb416:	mov    0x2e0(%rsp),%r12
 29fb41e:	mov    0x8(%r12),%rcx
 29fb423:	mov    %rcx,0x228(%rsp)
 29fb42b:	cmp    %rcx,%rax
 29fb42e:	jb     29f2cdb <wasm[0]::function[1015]::helper::object_read+0x11dbb>
 29fb434:	mov    0x190(%rsp),%rdi
 29fb43c:	call   3018d19 <wasmtime_builtin_new_epoch>
 29fb441:	mov    %rax,0x228(%rsp)
 29fb449:	jmp    29f2cdb <wasm[0]::function[1015]::helper::object_read+0x11dbb>
 29fb44e:	mov    0x2e0(%rsp),%r12
 29fb456:	mov    0x8(%r12),%rax
 29fb45b:	mov    %rax,0x228(%rsp)
 29fb463:	cmp    %rax,%rcx
 29fb466:	jb     29f3970 <wasm[0]::function[1015]::helper::object_read+0x12a50>
 29fb46c:	mov    0x190(%rsp),%rdi
 29fb474:	call   3018d19 <wasmtime_builtin_new_epoch>
 29fb479:	mov    %rax,0x228(%rsp)
 29fb481:	jmp    29f3970 <wasm[0]::function[1015]::helper::object_read+0x12a50>
 29fb486:	mov    0x2e0(%rsp),%r12
 29fb48e:	mov    0x8(%r12),%rax
 29fb493:	mov    %rax,0x228(%rsp)
 29fb49b:	cmp    %rax,%rsi
 29fb49e:	jb     29f4650 <wasm[0]::function[1015]::helper::object_read+0x13730>
 29fb4a4:	mov    0x190(%rsp),%rdi
 29fb4ac:	call   3018d19 <wasmtime_builtin_new_epoch>
 29fb4b1:	mov    %rax,0x228(%rsp)
 29fb4b9:	jmp    29f4650 <wasm[0]::function[1015]::helper::object_read+0x13730>
 29fb4be:	mov    0x2e0(%rsp),%r12
 29fb4c6:	mov    0x8(%r12),%rdx
 29fb4cb:	cmp    %rdx,%rcx
 29fb4ce:	jb     29f5392 <wasm[0]::function[1015]::helper::object_read+0x14472>
 29fb4d4:	mov    0x190(%rsp),%rdi
 29fb4dc:	call   3018d19 <wasmtime_builtin_new_epoch>
 29fb4e1:	mov    %rax,0x228(%rsp)
 29fb4e9:	jmp    29f539a <wasm[0]::function[1015]::helper::object_read+0x1447a>
 29fb4ee:	mov    $0xb0000042,%esi
 29fb4f3:	mov    0x190(%rsp),%rdi
 29fb4fb:	mov    0x28(%rdi),%rax
 29fb4ff:	mov    0x120(%rax),%edx
 29fb505:	mov    $0x20,%ecx
 29fb50a:	mov    $0x10,%r8d
 29fb510:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
 29fb515:	mov    %eax,%r10d
 29fb518:	mov    0x2e0(%rsp),%r12
 29fb520:	add    0x20(%r12),%r10
 29fb525:	jmp    29f649f <wasm[0]::function[1015]::helper::object_read+0x1557f>
 29fb52a:	mov    $0xb0000042,%esi
 29fb52f:	mov    0x190(%rsp),%rax
 29fb537:	mov    0x28(%rax),%rax
 29fb53b:	mov    0x120(%rax),%edx
 29fb541:	mov    $0x20,%ecx
 29fb546:	mov    $0x10,%r8d
 29fb54c:	mov    0x190(%rsp),%rdi
 29fb554:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
 29fb559:	mov    %eax,%ecx
 29fb55b:	mov    0x2e0(%rsp),%r12
 29fb563:	add    0x20(%r12),%rcx
 29fb568:	jmp    29f6534 <wasm[0]::function[1015]::helper::object_read+0x15614>
 29fb56d:	mov    $0xb0000042,%esi
 29fb572:	mov    0x190(%rsp),%rdi
 29fb57a:	mov    0x28(%rdi),%rax
 29fb57e:	mov    0x120(%rax),%edx
 29fb584:	mov    $0x20,%ecx
 29fb589:	mov    $0x10,%r8d
 29fb58f:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
 29fb594:	mov    %eax,%r11d
 29fb597:	mov    0x2e0(%rsp),%r12
 29fb59f:	add    0x20(%r12),%r11
 29fb5a4:	jmp    29f65c7 <wasm[0]::function[1015]::helper::object_read+0x156a7>
 29fb5a9:	mov    $0xb0000072,%esi
 29fb5ae:	mov    0x190(%rsp),%rax
 29fb5b6:	mov    0x28(%rax),%rax
 29fb5ba:	mov    0x13c(%rax),%edx
 29fb5c0:	mov    $0x20,%ecx
 29fb5c5:	mov    $0x10,%r8d
 29fb5cb:	mov    0x190(%rsp),%rdi
 29fb5d3:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
 29fb5d8:	mov    %rax,%r15
 29fb5db:	mov    %eax,%eax
 29fb5dd:	mov    0x2e0(%rsp),%r12
 29fb5e5:	add    0x20(%r12),%rax
 29fb5ea:	jmp    29f669f <wasm[0]::function[1015]::helper::object_read+0x1577f>
 29fb5ef:	mov    $0xb0000072,%esi
 29fb5f4:	mov    0x190(%rsp),%rax
 29fb5fc:	mov    0x28(%rax),%rax
 29fb600:	mov    0x13c(%rax),%edx
 29fb606:	mov    $0x20,%ecx
 29fb60b:	mov    $0x10,%r8d
 29fb611:	mov    0x190(%rsp),%rdi
 29fb619:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
 29fb61e:	mov    %rax,%r15
 29fb621:	mov    %eax,%eax
 29fb623:	mov    0x2e0(%rsp),%r12
 29fb62b:	add    0x20(%r12),%rax
 29fb630:	jmp    29f678a <wasm[0]::function[1015]::helper::object_read+0x1586a>
 29fb635:	mov    0x2e0(%rsp),%r12
 29fb63d:	mov    0x8(%r12),%rcx
 29fb642:	cmp    %rcx,%rax
 29fb645:	jb     29f6b18 <wasm[0]::function[1015]::helper::object_read+0x15bf8>
 29fb64b:	mov    0x190(%rsp),%rdi
 29fb653:	call   3018d19 <wasmtime_builtin_new_epoch>
 29fb658:	mov    %rax,0x228(%rsp)
 29fb660:	jmp    29f6b20 <wasm[0]::function[1015]::helper::object_read+0x15c00>
 29fb665:	mov    0x2e0(%rsp),%rax
 29fb66d:	mov    0x8(%rax),%rdx
 29fb671:	cmp    %rdx,%rcx
 29fb674:	jb     29f7028 <wasm[0]::function[1015]::helper::object_read+0x16108>
 29fb67a:	mov    0x190(%rsp),%rdi
 29fb682:	call   3018d19 <wasmtime_builtin_new_epoch>
 29fb687:	mov    %rax,0x228(%rsp)
 29fb68f:	jmp    29f7030 <wasm[0]::function[1015]::helper::object_read+0x16110>
 29fb694:	mov    $0xb0000042,%esi
 29fb699:	mov    0x190(%rsp),%rax
 29fb6a1:	mov    0x28(%rax),%rax
 29fb6a5:	mov    0x120(%rax),%edx
 29fb6ab:	mov    $0x20,%ecx
 29fb6b0:	mov    $0x10,%r8d
 29fb6b6:	mov    0x190(%rsp),%rdi
 29fb6be:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
 29fb6c3:	mov    %eax,%ecx
 29fb6c5:	mov    0x2e0(%rsp),%r12
 29fb6cd:	add    0x20(%r12),%rcx
 29fb6d2:	jmp    29f742b <wasm[0]::function[1015]::helper::object_read+0x1650b>
 29fb6d7:	mov    $0xb0000072,%esi
 29fb6dc:	mov    0x190(%rsp),%rax
 29fb6e4:	mov    0x28(%rax),%rax
 29fb6e8:	mov    0x13c(%rax),%edx
 29fb6ee:	mov    $0x20,%ecx
 29fb6f3:	mov    $0x10,%r8d
 29fb6f9:	mov    0x190(%rsp),%rdi
 29fb701:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
 29fb706:	mov    %eax,%r11d
 29fb709:	mov    0x2e0(%rsp),%r12
 29fb711:	add    0x20(%r12),%r11
 29fb716:	jmp    29f750a <wasm[0]::function[1015]::helper::object_read+0x165ea>
 29fb71b:	mov    $0xa800000e,%esi
 29fb720:	mov    0x190(%rsp),%rax
 29fb728:	mov    0x28(%rax),%rax
 29fb72c:	mov    0x194(%rax),%edx
 29fb732:	mov    $0x10,%r8d
 29fb738:	mov    0x190(%rsp),%rdi
 29fb740:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
 29fb745:	mov    %eax,%ecx
 29fb747:	mov    0x2e0(%rsp),%rsi
 29fb74f:	add    0x20(%rsi),%rcx
 29fb753:	jmp    29f7a63 <wasm[0]::function[1015]::helper::object_read+0x16b43>
 29fb758:	mov    0x2e0(%rsp),%r12
 29fb760:	mov    0x8(%r12),%r8
 29fb765:	cmp    %r8,%rsi
 29fb768:	jb     29f7b54 <wasm[0]::function[1015]::helper::object_read+0x16c34>
 29fb76e:	mov    0x190(%rsp),%rdi
 29fb776:	call   3018d19 <wasmtime_builtin_new_epoch>
 29fb77b:	mov    %rax,0x228(%rsp)
 29fb783:	jmp    29f7b5c <wasm[0]::function[1015]::helper::object_read+0x16c3c>
 29fb788:	mov    0x2e0(%rsp),%r12
 29fb790:	mov    0x8(%r12),%rcx
 29fb795:	cmp    %rcx,%rax
 29fb798:	jb     29f7c39 <wasm[0]::function[1015]::helper::object_read+0x16d19>
 29fb79e:	mov    0x190(%rsp),%rdi
 29fb7a6:	call   3018d19 <wasmtime_builtin_new_epoch>
 29fb7ab:	mov    0x1e8(%rsp),%rcx
 29fb7b3:	mov    %rax,0x228(%rsp)
 29fb7bb:	jmp    29f7c49 <wasm[0]::function[1015]::helper::object_read+0x16d29>
 29fb7c0:	mov    0x1d8(%rsp),%rcx
 29fb7c8:	mov    %r15,%rdx
 29fb7cb:	mov    0x1e0(%rsp),%rsi
 29fb7d3:	mov    0x190(%rsp),%rdi
 29fb7db:	mov    %rbx,%r8
 29fb7de:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
 29fb7e3:	mov    %eax,%ecx
 29fb7e5:	mov    0x2e0(%rsp),%rdx
 29fb7ed:	add    0x20(%rdx),%rcx
 29fb7f1:	jmp    29f7de3 <wasm[0]::function[1015]::helper::object_read+0x16ec3>
 29fb7f6:	mov    0x1d8(%rsp),%rcx
 29fb7fe:	mov    %r14,%rdx
 29fb801:	mov    0x1d0(%rsp),%rsi
 29fb809:	mov    0x190(%rsp),%rdi
 29fb811:	mov    %rbx,%r8
 29fb814:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
 29fb819:	mov    %eax,%esi
 29fb81b:	mov    0x2e0(%rsp),%r12
 29fb823:	add    0x20(%r12),%rsi
 29fb828:	jmp    29f7e84 <wasm[0]::function[1015]::helper::object_read+0x16f64>
 29fb82d:	mov    $0xa800000e,%esi
 29fb832:	mov    0x190(%rsp),%rax
 29fb83a:	mov    0x28(%rax),%rax
 29fb83e:	mov    0x194(%rax),%edx
 29fb844:	mov    $0x10,%r8d
 29fb84a:	mov    0x190(%rsp),%rdi
 29fb852:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
 29fb857:	mov    %eax,%ecx
 29fb859:	mov    0x2e0(%rsp),%rsi
 29fb861:	add    0x20(%rsi),%rcx
 29fb865:	jmp    29f811f <wasm[0]::function[1015]::helper::object_read+0x171ff>
 29fb86a:	mov    0x2e0(%rsp),%rcx
 29fb872:	mov    0x8(%rcx),%rcx
 29fb876:	cmp    %rcx,%rax
 29fb879:	jb     29f8203 <wasm[0]::function[1015]::helper::object_read+0x172e3>
 29fb87f:	mov    0x190(%rsp),%rdi
 29fb887:	call   3018d19 <wasmtime_builtin_new_epoch>
 29fb88c:	mov    %rax,0x228(%rsp)
 29fb894:	jmp    29f820b <wasm[0]::function[1015]::helper::object_read+0x172eb>
 29fb899:	mov    0x2e0(%rsp),%r12
 29fb8a1:	mov    0x8(%r12),%rcx
 29fb8a6:	cmp    %rcx,%rax
 29fb8a9:	jb     29f82d2 <wasm[0]::function[1015]::helper::object_read+0x173b2>
 29fb8af:	mov    0x190(%rsp),%rdi
 29fb8b7:	call   3018d19 <wasmtime_builtin_new_epoch>
 29fb8bc:	mov    0x1d0(%rsp),%rcx
 29fb8c4:	mov    %rax,0x228(%rsp)
 29fb8cc:	jmp    29f82e2 <wasm[0]::function[1015]::helper::object_read+0x173c2>
 29fb8d1:	mov    0x1a0(%rsp),%rcx
 29fb8d9:	mov    %r14,%rdx
 29fb8dc:	mov    0x1c8(%rsp),%rsi
 29fb8e4:	mov    0x190(%rsp),%rdi
 29fb8ec:	mov    %r13,%r8
 29fb8ef:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
 29fb8f4:	mov    %eax,%ecx
 29fb8f6:	mov    0x2e0(%rsp),%r12
 29fb8fe:	add    0x20(%r12),%rcx
 29fb903:	jmp    29f83f4 <wasm[0]::function[1015]::helper::object_read+0x174d4>
 29fb908:	mov    0x2e0(%rsp),%r12
 29fb910:	mov    0x8(%r12),%rcx
 29fb915:	cmp    %rcx,%rax
 29fb918:	jb     29f86d6 <wasm[0]::function[1015]::helper::object_read+0x177b6>
 29fb91e:	mov    0x190(%rsp),%rdi
 29fb926:	call   3018d19 <wasmtime_builtin_new_epoch>
 29fb92b:	mov    %rax,0x228(%rsp)
 29fb933:	jmp    29f86de <wasm[0]::function[1015]::helper::object_read+0x177be>
 29fb938:	mov    $0xb0000072,%esi
 29fb93d:	mov    0x190(%rsp),%rax
 29fb945:	mov    0x28(%rax),%r10
 29fb949:	mov    0x13c(%r10),%edx
 29fb950:	mov    $0x20,%ecx
 29fb955:	mov    $0x10,%r8d
 29fb95b:	mov    0x190(%rsp),%rdi
 29fb963:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
 29fb968:	mov    %rax,%r15
 29fb96b:	mov    %eax,%eax
 29fb96d:	mov    0x2e0(%rsp),%r12
 29fb975:	add    0x20(%r12),%rax
 29fb97a:	jmp    29f8ab1 <wasm[0]::function[1015]::helper::object_read+0x17b91>
 29fb97f:	mov    $0xb0000072,%esi
 29fb984:	mov    0x190(%rsp),%r9
 29fb98c:	mov    0x28(%r9),%rax
 29fb990:	mov    0x13c(%rax),%edx
 29fb996:	mov    $0x20,%ecx
 29fb99b:	mov    $0x10,%r8d
 29fb9a1:	mov    0x190(%rsp),%rdi
 29fb9a9:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
 29fb9ae:	mov    %rax,%r15
 29fb9b1:	mov    %eax,%eax
 29fb9b3:	mov    0x2e0(%rsp),%r12
 29fb9bb:	add    0x20(%r12),%rax
 29fb9c0:	jmp    29f8ba3 <wasm[0]::function[1015]::helper::object_read+0x17c83>
 29fb9c5:	mov    $0xb0000072,%esi
 29fb9ca:	mov    0x190(%rsp),%rdi
 29fb9d2:	mov    0x28(%rdi),%rax
 29fb9d6:	mov    0x13c(%rax),%edx
 29fb9dc:	mov    $0x20,%ecx
 29fb9e1:	mov    $0x10,%r8d
 29fb9e7:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
 29fb9ec:	mov    %rax,%r15
 29fb9ef:	mov    %eax,%eax
 29fb9f1:	mov    0x2e0(%rsp),%r12
 29fb9f9:	add    0x20(%r12),%rax
 29fb9fe:	jmp    29f8e93 <wasm[0]::function[1015]::helper::object_read+0x17f73>
 29fba03:	mov    $0xb0000072,%esi
 29fba08:	mov    0x190(%rsp),%rax
 29fba10:	mov    0x28(%rax),%rdi
 29fba14:	mov    0x13c(%rdi),%edx
 29fba1a:	mov    $0x20,%ecx
 29fba1f:	mov    $0x10,%r8d
 29fba25:	mov    0x190(%rsp),%rdi
 29fba2d:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
 29fba32:	mov    %rax,%r15
 29fba35:	mov    %eax,%eax
 29fba37:	mov    0x2e0(%rsp),%r12
 29fba3f:	add    0x20(%r12),%rax
 29fba44:	jmp    29f8f74 <wasm[0]::function[1015]::helper::object_read+0x18054>
 29fba49:	mov    0x2e0(%rsp),%r12
 29fba51:	mov    0x8(%r12),%rdx
 29fba56:	cmp    %rdx,%rcx
 29fba59:	jb     29f956b <wasm[0]::function[1015]::helper::object_read+0x1864b>
 29fba5f:	mov    0x190(%rsp),%rdi
 29fba67:	call   3018d19 <wasmtime_builtin_new_epoch>
 29fba6c:	mov    %rax,0x228(%rsp)
 29fba74:	jmp    29f9573 <wasm[0]::function[1015]::helper::object_read+0x18653>
 29fba79:	mov    0x2e0(%rsp),%r12
 29fba81:	mov    0x8(%r12),%rsi
 29fba86:	cmp    %rsi,%rcx
 29fba89:	jb     29f9883 <wasm[0]::function[1015]::helper::object_read+0x18963>
 29fba8f:	mov    0x190(%rsp),%rdi
 29fba97:	call   3018d19 <wasmtime_builtin_new_epoch>
 29fba9c:	mov    %rax,0x228(%rsp)
 29fbaa4:	jmp    29f988b <wasm[0]::function[1015]::helper::object_read+0x1896b>
 29fbaa9:	mov    0x2e0(%rsp),%r12
 29fbab1:	mov    0x8(%r12),%rcx
 29fbab6:	cmp    %rcx,%rax
 29fbab9:	jb     29f9bc6 <wasm[0]::function[1015]::helper::object_read+0x18ca6>
 29fbabf:	mov    0x190(%rsp),%rdi
 29fbac7:	call   3018d19 <wasmtime_builtin_new_epoch>
 29fbacc:	mov    %rax,0x228(%rsp)
 29fbad4:	jmp    29f9bce <wasm[0]::function[1015]::helper::object_read+0x18cae>
 29fbad9:	mov    0x2e0(%rsp),%r12
 29fbae1:	mov    0x8(%r12),%rcx
 29fbae6:	cmp    %rcx,%rax
 29fbae9:	jb     29f9e71 <wasm[0]::function[1015]::helper::object_read+0x18f51>
 29fbaef:	mov    0x190(%rsp),%rdi
 29fbaf7:	call   3018d19 <wasmtime_builtin_new_epoch>
 29fbafc:	mov    %rax,0x228(%rsp)
 29fbb04:	jmp    29f9e79 <wasm[0]::function[1015]::helper::object_read+0x18f59>
 29fbb09:	mov    0x2e0(%rsp),%r12
 29fbb11:	mov    0x8(%r12),%rcx
 29fbb16:	cmp    %rcx,%rax
 29fbb19:	jb     29fa1ba <wasm[0]::function[1015]::helper::object_read+0x1929a>
 29fbb1f:	mov    0x190(%rsp),%rdi
 29fbb27:	call   3018d19 <wasmtime_builtin_new_epoch>
 29fbb2c:	mov    %rax,0x228(%rsp)
 29fbb34:	jmp    29fa1c2 <wasm[0]::function[1015]::helper::object_read+0x192a2>
 29fbb39:	ud2
 29fbb3b:	ud2
 29fbb3d:	ud2
 29fbb3f:	ud2
 29fbb41:	ud2
 29fbb43:	ud2
 29fbb45:	ud2
 29fbb47:	ud2
 29fbb49:	ud2
 29fbb4b:	ud2
 29fbb4d:	ud2
 29fbb4f:	ud2
 29fbb51:	ud2
 29fbb53:	ud2
 29fbb55:	ud2
 29fbb57:	ud2
 29fbb59:	ud2
 29fbb5b:	ud2
 29fbb5d:	ud2
 29fbb5f:	ud2
 29fbb61:	ud2
 29fbb63:	ud2
 29fbb65:	ud2
 29fbb67:	ud2
 29fbb69:	ud2
 29fbb6b:	ud2
 29fbb6d:	ud2
 29fbb6f:	ud2
 29fbb71:	ud2
 29fbb73:	ud2
 29fbb75:	ud2
 29fbb77:	ud2
 29fbb79:	ud2
 29fbb7b:	ud2
 29fbb7d:	ud2
 29fbb7f:	ud2
 29fbb81:	ud2
 29fbb83:	ud2
 29fbb85:	ud2
 29fbb87:	ud2
 29fbb89:	ud2
 29fbb8b:	ud2
 29fbb8d:	ud2
 29fbb8f:	ud2
 29fbb91:	ud2
 29fbb93:	ud2
 29fbb95:	ud2
 29fbb97:	ud2
 29fbb99:	ud2
 29fbb9b:	ud2
 29fbb9d:	ud2
 29fbb9f:	ud2
 29fbba1:	ud2
 29fbba3:	ud2
 29fbba5:	ud2
 29fbba7:	ud2
 29fbba9:	ud2
 29fbbab:	ud2
 29fbbad:	ud2
 29fbbaf:	ud2
 29fbbb1:	ud2
 29fbbb3:	ud2
 29fbbb5:	ud2
 29fbbb7:	ud2
 29fbbb9:	ud2
 29fbbbb:	ud2
 29fbbbd:	ud2
 29fbbbf:	ud2
 29fbbc1:	ud2
 29fbbc3:	ud2
 29fbbc5:	ud2
 29fbbc7:	ud2
 29fbbc9:	ud2
 29fbbcb:	ud2
 29fbbcd:	ud2
 29fbbcf:	ud2
 29fbbd1:	ud2
 29fbbd3:	ud2
 29fbbd5:	ud2
 29fbbd7:	ud2
 29fbbd9:	ud2
 29fbbdb:	ud2
 29fbbdd:	ud2
 29fbbdf:	ud2
 29fbbe1:	ud2
 29fbbe3:	ud2
 29fbbe5:	ud2
 29fbbe7:	ud2
 29fbbe9:	ud2
 29fbbeb:	ud2
 29fbbed:	ud2
 29fbbef:	ud2
 29fbbf1:	ud2
 29fbbf3:	ud2
 29fbbf5:	ud2
 29fbbf7:	ud2
 29fbbf9:	ud2
 29fbbfb:	ud2
 29fbbfd:	ud2
 29fbbff:	ud2
 29fbc01:	ud2
 29fbc03:	ud2
 29fbc05:	ud2
 29fbc07:	ud2
 29fbc09:	ud2
 29fbc0b:	ud2
 29fbc0d:	ud2
 29fbc0f:	ud2
 29fbc11:	ud2
 29fbc13:	ud2
 29fbc15:	ud2
 29fbc17:	ud2
 29fbc19:	ud2
 29fbc1b:	ud2
 29fbc1d:	ud2
 29fbc1f:	ud2
 29fbc21:	ud2
 29fbc23:	ud2
 29fbc25:	ud2
 29fbc27:	ud2
 29fbc29:	ud2
 29fbc2b:	ud2
 29fbc2d:	ud2
 29fbc2f:	ud2
 29fbc31:	ud2
 29fbc33:	ud2
 29fbc35:	ud2
 29fbc37:	ud2
 29fbc39:	ud2
 29fbc3b:	ud2
 29fbc3d:	ud2
 29fbc3f:	ud2
 29fbc41:	ud2
 29fbc43:	ud2
 29fbc45:	ud2
 29fbc47:	ud2
 29fbc49:	ud2
 29fbc4b:	ud2
 29fbc4d:	ud2
 29fbc4f:	ud2
 29fbc51:	ud2
 29fbc53:	ud2
 29fbc55:	ud2
 29fbc57:	ud2
 29fbc59:	ud2
 29fbc5b:	ud2
 29fbc5d:	ud2
 29fbc5f:	ud2
 29fbc61:	ud2
 29fbc63:	ud2
 29fbc65:	ud2
 29fbc67:	ud2
 29fbc69:	ud2
 29fbc6b:	ud2
 29fbc6d:	ud2
 29fbc6f:	ud2
 29fbc71:	ud2
 29fbc73:	ud2
 29fbc75:	ud2
 29fbc77:	ud2
 29fbc79:	ud2
 29fbc7b:	ud2
 29fbc7d:	ud2
 29fbc7f:	ud2
 29fbc81:	ud2
 29fbc83:	ud2
 29fbc85:	ud2
 29fbc87:	ud2
 29fbc89:	ud2
 29fbc8b:	ud2
 29fbc8d:	ud2
 29fbc8f:	ud2
 29fbc91:	ud2
 29fbc93:	ud2
 29fbc95:	ud2
 29fbc97:	ud2
 29fbc99:	ud2
 29fbc9b:	ud2
 29fbc9d:	ud2
 29fbc9f:	ud2
 29fbca1:	ud2
 29fbca3:	ud2
 29fbca5:	ud2
 29fbca7:	ud2
 29fbca9:	ud2
 29fbcab:	ud2
 29fbcad:	ud2
 29fbcaf:	ud2
 29fbcb1:	ud2
 29fbcb3:	ud2
 29fbcb5:	ud2
 29fbcb7:	ud2
 29fbcb9:	ud2
 29fbcbb:	ud2
 29fbcbd:	ud2
 29fbcbf:	ud2
 29fbcc1:	ud2
 29fbcc3:	ud2
 29fbcc5:	ud2
 29fbcc7:	ud2
 29fbcc9:	ud2
 29fbccb:	ud2
 29fbccd:	ud2
 29fbccf:	ud2
 29fbcd1:	ud2
 29fbcd3:	ud2
 29fbcd5:	ud2
 29fbcd7:	ud2
 29fbcd9:	ud2
 29fbcdb:	ud2
 29fbcdd:	ud2
 29fbcdf:	ud2
 29fbce1:	ud2
 29fbce3:	ud2
 29fbce5:	ud2
 29fbce7:	ud2
 29fbce9:	ud2
 29fbceb:	ud2
 29fbced:	ud2
 29fbcef:	ud2
 29fbcf1:	ud2
 29fbcf3:	ud2
 29fbcf5:	ud2
 29fbcf7:	ud2
 29fbcf9:	ud2
 29fbcfb:	ud2
 29fbcfd:	ud2
 29fbcff:	ud2
 29fbd01:	ud2
 29fbd03:	ud2
 29fbd05:	ud2
 29fbd07:	ud2
 29fbd09:	ud2
 29fbd0b:	ud2
 29fbd0d:	ud2
 29fbd0f:	ud2
 29fbd11:	ud2
 29fbd13:	ud2
 29fbd15:	ud2
 29fbd17:	ud2
 29fbd19:	ud2
 29fbd1b:	ud2
 29fbd1d:	ud2
 29fbd1f:	ud2
 29fbd21:	ud2
 29fbd23:	ud2
 29fbd25:	ud2
 29fbd27:	ud2
 29fbd29:	ud2
 29fbd2b:	ud2
 29fbd2d:	ud2
 29fbd2f:	ud2
 29fbd31:	ud2
 29fbd33:	ud2
 29fbd35:	ud2
 29fbd37:	ud2
 29fbd39:	ud2
 29fbd3b:	ud2
 29fbd3d:	ud2
 29fbd3f:	ud2
 29fbd41:	ud2
 29fbd43:	ud2
 29fbd45:	ud2
 29fbd47:	ud2
 29fbd49:	ud2
 29fbd4b:	ud2
 29fbd4d:	ud2
 29fbd4f:	ud2
 29fbd51:	ud2
 29fbd53:	ud2
 29fbd55:	ud2
 29fbd57:	ud2
 29fbd59:	ud2
 29fbd5b:	ud2
 29fbd5d:	ud2
 29fbd5f:	ud2
 29fbd61:	ud2
 29fbd63:	ud2
 29fbd65:	ud2
 29fbd67:	ud2
 29fbd69:	ud2
 29fbd6b:	ud2
 29fbd6d:	ud2
 29fbd6f:	ud2
 29fbd71:	ud2
 29fbd73:	ud2
 29fbd75:	ud2
 29fbd77:	ud2
 29fbd79:	ud2
 29fbd7b:	ud2
 29fbd7d:	ud2
 29fbd7f:	ud2
 29fbd81:	ud2
 29fbd83:	ud2
 29fbd85:	ud2
 29fbd87:	ud2
 29fbd89:	ud2
 29fbd8b:	ud2
 29fbd8d:	ud2
 29fbd8f:	ud2
 29fbd91:	ud2
 29fbd93:	ud2
 29fbd95:	ud2
 29fbd97:	ud2
 29fbd99:	ud2
 29fbd9b:	ud2
 29fbd9d:	ud2
 29fbd9f:	ud2
 29fbda1:	ud2
 29fbda3:	ud2
 29fbda5:	ud2
 29fbda7:	ud2
 29fbda9:	ud2
 29fbdab:	ud2
 29fbdad:	ud2
 29fbdaf:	ud2
 29fbdb1:	ud2
 29fbdb3:	ud2
 29fbdb5:	ud2
 29fbdb7:	ud2
 29fbdb9:	ud2
 29fbdbb:	ud2
 29fbdbd:	ud2
 29fbdbf:	ud2
 29fbdc1:	ud2
 29fbdc3:	ud2
 29fbdc5:	ud2
 29fbdc7:	ud2
 29fbdc9:	ud2
 29fbdcb:	ud2
 29fbdcd:	ud2
 29fbdcf:	ud2
 29fbdd1:	ud2
 29fbdd3:	ud2
 29fbdd5:	ud2
 29fbdd7:	ud2
 29fbdd9:	ud2
 29fbddb:	ud2
 29fbddd:	ud2
 29fbddf:	ud2
 29fbde1:	ud2
 29fbde3:	ud2
 29fbde5:	ud2
 29fbde7:	ud2
 29fbde9:	ud2
 29fbdeb:	ud2
 29fbded:	ud2
 29fbdef:	ud2
 29fbdf1:	ud2
 29fbdf3:	ud2
 29fbdf5:	ud2
 29fbdf7:	ud2
 29fbdf9:	ud2
 29fbdfb:	ud2
 29fbdfd:	ud2
 29fbdff:	ud2
 29fbe01:	ud2
 29fbe03:	ud2
 29fbe05:	ud2
 29fbe07:	ud2
 29fbe09:	ud2
 29fbe0b:	ud2
 29fbe0d:	ud2
 29fbe0f:	ud2
 29fbe11:	ud2
 29fbe13:	ud2
 29fbe15:	ud2
 29fbe17:	ud2
 29fbe19:	ud2
 29fbe1b:	ud2
 29fbe1d:	ud2
 29fbe1f:	ud2
 29fbe21:	ud2
 29fbe23:	ud2
 29fbe25:	ud2
 29fbe27:	ud2
 29fbe29:	ud2
 29fbe2b:	ud2
 29fbe2d:	ud2
 29fbe2f:	ud2
 29fbe31:	ud2
 29fbe33:	ud2
 29fbe35:	ud2
 29fbe37:	ud2
 29fbe39:	ud2
 29fbe3b:	ud2
 29fbe3d:	ud2
 29fbe3f:	ud2
 29fbe41:	ud2
 29fbe43:	ud2
 29fbe45:	ud2
 29fbe47:	ud2
 29fbe49:	ud2
 29fbe4b:	ud2
 29fbe4d:	ud2
 29fbe4f:	ud2
 29fbe51:	ud2
 29fbe53:	ud2
 29fbe55:	ud2
 29fbe57:	ud2
 29fbe59:	ud2
 29fbe5b:	ud2
 29fbe5d:	ud2
 29fbe5f:	ud2
 29fbe61:	ud2
 29fbe63:	ud2
 29fbe65:	ud2
 29fbe67:	ud2
 29fbe69:	ud2
 29fbe6b:	ud2
 29fbe6d:	ud2
 29fbe6f:	ud2
 29fbe71:	ud2
 29fbe73:	ud2
 29fbe75:	ud2
 29fbe77:	ud2
 29fbe79:	ud2
 29fbe7b:	ud2
 29fbe7d:	ud2
 29fbe7f:	ud2
 29fbe81:	ud2
 29fbe83:	ud2
 29fbe85:	ud2
 29fbe87:	ud2
 29fbe89:	ud2
 29fbe8b:	ud2
 29fbe8d:	ud2
 29fbe8f:	ud2
 29fbe91:	ud2
 29fbe93:	ud2
 29fbe95:	ud2
 29fbe97:	ud2
 29fbe99:	ud2
 29fbe9b:	ud2
 29fbe9d:	ud2
 29fbe9f:	ud2
 29fbea1:	ud2
 29fbea3:	ud2
 29fbea5:	ud2
 29fbea7:	ud2
 29fbea9:	ud2
 29fbeab:	ud2
 29fbead:	ud2
 29fbeaf:	ud2
 29fbeb1:	ud2
 29fbeb3:	ud2
 29fbeb5:	ud2
 29fbeb7:	ud2
 29fbeb9:	ud2
 29fbebb:	ud2
 29fbebd:	ud2
 29fbebf:	ud2
 29fbec1:	ud2
 29fbec3:	ud2
 29fbec5:	ud2
 29fbec7:	ud2
 29fbec9:	ud2
 29fbecb:	ud2
 29fbecd:	ud2
 29fbecf:	ud2
 29fbed1:	ud2
 29fbed3:	ud2
 29fbed5:	ud2
 29fbed7:	ud2
 29fbed9:	ud2
 29fbedb:	ud2
 29fbedd:	ud2
 29fbedf:	ud2
 29fbee1:	ud2
 29fbee3:	ud2
 29fbee5:	ud2
 29fbee7:	ud2
 29fbee9:	ud2
 29fbeeb:	ud2
 29fbeed:	ud2
 29fbeef:	ud2
 29fbef1:	ud2
 29fbef3:	ud2
 29fbef5:	ud2
 29fbef7:	ud2
 29fbef9:	ud2
 29fbefb:	ud2
 29fbefd:	ud2
 29fbeff:	ud2
 29fbf01:	ud2
 29fbf03:	ud2
 29fbf05:	ud2
 29fbf07:	ud2
 29fbf09:	ud2
 29fbf0b:	ud2
 29fbf0d:	ud2
 29fbf0f:	ud2
 29fbf11:	ud2
 29fbf13:	ud2
 29fbf15:	ud2
 29fbf17:	ud2
 29fbf19:	ud2
 29fbf1b:	ud2
 29fbf1d:	ud2
 29fbf1f:	ud2
 29fbf21:	ud2
 29fbf23:	ud2
 29fbf25:	ud2
 29fbf27:	ud2
 29fbf29:	ud2
 29fbf2b:	ud2
 29fbf2d:	ud2
 29fbf2f:	ud2
 29fbf31:	ud2
 29fbf33:	ud2
 29fbf35:	ud2
 29fbf37:	ud2
 29fbf39:	ud2
 29fbf3b:	ud2
 29fbf3d:	ud2
 29fbf3f:	ud2
 29fbf41:	ud2
 29fbf43:	ud2
 29fbf45:	ud2
 29fbf47:	ud2
 29fbf49:	ud2
 29fbf4b:	ud2
 29fbf4d:	ud2
 29fbf4f:	ud2
 29fbf51:	ud2
 29fbf53:	ud2
 29fbf55:	ud2
 29fbf57:	ud2
 29fbf59:	ud2
 29fbf5b:	ud2
 29fbf5d:	ud2
 29fbf5f:	ud2
 29fbf61:	ud2
 29fbf63:	ud2
 29fbf65:	ud2
 29fbf67:	ud2
 29fbf69:	ud2
 29fbf6b:	ud2
 29fbf6d:	ud2
 29fbf6f:	ud2
 29fbf71:	ud2
 29fbf73:	ud2
 29fbf75:	ud2
 29fbf77:	ud2
 29fbf79:	ud2
 29fbf7b:	ud2
 29fbf7d:	ud2
 29fbf7f:	ud2
 29fbf81:	ud2
 29fbf83:	ud2
 29fbf85:	ud2
 29fbf87:	ud2
 29fbf89:	ud2
 29fbf8b:	ud2
 29fbf8d:	ud2
 29fbf8f:	ud2
 29fbf91:	ud2
 29fbf93:	ud2
 29fbf95:	ud2
 29fbf97:	ud2
 29fbf99:	ud2
 29fbf9b:	ud2
 29fbf9d:	ud2
 29fbf9f:	ud2
 29fbfa1:	ud2
 29fbfa3:	ud2
 29fbfa5:	ud2
 29fbfa7:	ud2
 29fbfa9:	ud2
 29fbfab:	ud2
 29fbfad:	ud2
 29fbfaf:	ud2
 29fbfb1:	ud2
 29fbfb3:	ud2
 29fbfb5:	ud2
 29fbfb7:	ud2
 29fbfb9:	ud2
 29fbfbb:	ud2
 29fbfbd:	ud2
 29fbfbf:	ud2
 29fbfc1:	ud2
 29fbfc3:	ud2
 29fbfc5:	ud2
 29fbfc7:	ud2
 29fbfc9:	ud2
 29fbfcb:	ud2
 29fbfcd:	ud2
 29fbfcf:	ud2
 29fbfd1:	ud2
 29fbfd3:	ud2
 29fbfd5:	ud2
 29fbfd7:	ud2
 29fbfd9:	ud2
 29fbfdb:	ud2
 29fbfdd:	ud2
 29fbfdf:	ud2
 29fbfe1:	ud2
 29fbfe3:	ud2
 29fbfe5:	ud2
 29fbfe7:	ud2
 29fbfe9:	ud2
 29fbfeb:	ud2
 29fbfed:	ud2
 29fbfef:	ud2
 29fbff1:	ud2
 29fbff3:	ud2
 29fbff5:	ud2
 29fbff7:	ud2
 29fbff9:	ud2
 29fbffb:	ud2
 29fbffd:	ud2
 29fbfff:	ud2
 29fc001:	ud2
 29fc003:	ud2
 29fc005:	ud2
 29fc007:	ud2
 29fc009:	ud2
 29fc00b:	ud2
 29fc00d:	ud2
 29fc00f:	ud2
 29fc011:	ud2
 29fc013:	ud2
 29fc015:	ud2
 29fc017:	ud2
 29fc019:	ud2
 29fc01b:	ud2
 29fc01d:	ud2
 29fc01f:	ud2
 29fc021:	ud2
 29fc023:	ud2
 29fc025:	ud2
 29fc027:	ud2
 29fc029:	ud2
 29fc02b:	ud2
 29fc02d:	ud2
 29fc02f:	ud2
 29fc031:	ud2
 29fc033:	ud2
 29fc035:	ud2
 29fc037:	ud2
 29fc039:	ud2
 29fc03b:	ud2
 29fc03d:	ud2
 29fc03f:	ud2
 29fc041:	ud2
 29fc043:	ud2
 29fc045:	ud2
 29fc047:	ud2
 29fc049:	ud2
 29fc04b:	ud2
 29fc04d:	ud2
 29fc04f:	ud2
 29fc051:	ud2
 29fc053:	ud2
 29fc055:	ud2
 29fc057:	ud2
 29fc059:	ud2
 29fc05b:	ud2
 29fc05d:	ud2
 29fc05f:	ud2
 29fc061:	ud2
 29fc063:	ud2
 29fc065:	ud2
 29fc067:	ud2
 29fc069:	ud2
 29fc06b:	ud2
 29fc06d:	ud2
 29fc06f:	ud2
 29fc071:	ud2
 29fc073:	ud2
 29fc075:	ud2
 29fc077:	ud2
 29fc079:	ud2
 29fc07b:	ud2
 29fc07d:	ud2
 29fc07f:	ud2
 29fc081:	ud2
 29fc083:	ud2
 29fc085:	ud2
 29fc087:	ud2
 29fc089:	ud2
 29fc08b:	ud2
 29fc08d:	ud2
 29fc08f:	ud2
 29fc091:	ud2
 29fc093:	ud2
 29fc095:	ud2
 29fc097:	ud2
 29fc099:	ud2
 29fc09b:	ud2
 29fc09d:	ud2
 29fc09f:	ud2
 29fc0a1:	ud2
 29fc0a3:	ud2
 29fc0a5:	ud2
 29fc0a7:	ud2
 29fc0a9:	ud2
 29fc0ab:	ud2
 29fc0ad:	ud2
 29fc0af:	ud2
 29fc0b1:	ud2
 29fc0b3:	ud2
 29fc0b5:	ud2
 29fc0b7:	ud2
 29fc0b9:	ud2
 29fc0bb:	ud2
 29fc0bd:	ud2
 29fc0bf:	ud2
 29fc0c1:	ud2
 29fc0c3:	ud2
 29fc0c5:	ud2
 29fc0c7:	ud2
 29fc0c9:	ud2
 29fc0cb:	ud2
 29fc0cd:	ud2
 29fc0cf:	ud2
 29fc0d1:	ud2
 29fc0d3:	ud2
 29fc0d5:	ud2
 29fc0d7:	ud2
 29fc0d9:	ud2
 29fc0db:	ud2
 29fc0dd:	ud2
 29fc0df:	ud2
 29fc0e1:	ud2
 29fc0e3:	ud2
 29fc0e5:	ud2
 29fc0e7:	ud2
 29fc0e9:	ud2
 29fc0eb:	ud2
 29fc0ed:	ud2
 29fc0ef:	ud2
 29fc0f1:	ud2
 29fc0f3:	ud2
 29fc0f5:	ud2
 29fc0f7:	ud2
 29fc0f9:	ud2
 29fc0fb:	ud2
 29fc0fd:	ud2
 29fc0ff:	ud2
 29fc101:	ud2
 29fc103:	ud2
 29fc105:	ud2
 29fc107:	ud2
 29fc109:	ud2
 29fc10b:	ud2
 29fc10d:	ud2
 29fc10f:	ud2
 29fc111:	ud2
 29fc113:	ud2
 29fc115:	ud2
 29fc117:	ud2
 29fc119:	ud2
 29fc11b:	ud2
 29fc11d:	ud2
 29fc11f:	ud2
 29fc121:	ud2
 29fc123:	ud2
 29fc125:	ud2
 29fc127:	ud2
 29fc129:	ud2
 29fc12b:	ud2
 29fc12d:	ud2
 29fc12f:	ud2
 29fc131:	ud2
 29fc133:	ud2
 29fc135:	ud2
 29fc137:	ud2
 29fc139:	ud2
 29fc13b:	ud2
 29fc13d:	ud2
 29fc13f:	ud2
 29fc141:	ud2
 29fc143:	ud2
 29fc145:	ud2
 29fc147:	ud2
 29fc149:	ud2
 29fc14b:	ud2
 29fc14d:	ud2
 29fc14f:	ud2
 29fc151:	ud2
 29fc153:	ud2
 29fc155:	ud2
 29fc157:	ud2
 29fc159:	ud2
 29fc15b:	ud2
 29fc15d:	ud2
 29fc15f:	ud2
 29fc161:	ud2
 29fc163:	ud2
 29fc165:	ud2
 29fc167:	ud2
 29fc169:	ud2
 29fc16b:	ud2
 29fc16d:	ud2
 29fc16f:	ud2
 29fc171:	ud2
 29fc173:	ud2
 29fc175:	ud2
 29fc177:	ud2
 29fc179:	ud2
 29fc17b:	ud2
 29fc17d:	ud2
 29fc17f:	ud2
 29fc181:	ud2
 29fc183:	ud2
 29fc185:	ud2
 29fc187:	ud2
 29fc189:	ud2
 29fc18b:	ud2
 29fc18d:	ud2
 29fc18f:	ud2
 29fc191:	ud2
 29fc193:	ud2
 29fc195:	ud2
 29fc197:	ud2
 29fc199:	ud2
 29fc19b:	ud2
 29fc19d:	ud2
 29fc19f:	ud2
 29fc1a1:	ud2
 29fc1a3:	ud2
 29fc1a5:	ud2
 29fc1a7:	ud2
 29fc1a9:	ud2
 29fc1ab:	ud2
 29fc1ad:	ud2
 29fc1af:	ud2
 29fc1b1:	ud2
 29fc1b3:	ud2
 29fc1b5:	ud2
 29fc1b7:	ud2
 29fc1b9:	ud2
 29fc1bb:	ud2
 29fc1bd:	ud2
 29fc1bf:	ud2
 29fc1c1:	ud2
 29fc1c3:	ud2
 29fc1c5:	ud2
 29fc1c7:	ud2
 29fc1c9:	ud2
 29fc1cb:	ud2
 29fc1cd:	ud2
 29fc1cf:	ud2
 29fc1d1:	ud2
 29fc1d3:	ud2
 29fc1d5:	ud2
 29fc1d7:	ud2
 29fc1d9:	ud2
 29fc1db:	ud2
 29fc1dd:	ud2
 29fc1df:	ud2
 29fc1e1:	ud2
 29fc1e3:	ud2
 29fc1e5:	ud2
 29fc1e7:	ud2
 29fc1e9:	ud2
 29fc1eb:	ud2
 29fc1ed:	ud2
 29fc1ef:	ud2
 29fc1f1:	ud2
 29fc1f3:	ud2
 29fc1f5:	ud2
 29fc1f7:	ud2
 29fc1f9:	ud2
 29fc1fb:	ud2
 29fc1fd:	ud2
 29fc1ff:	ud2
 29fc201:	ud2
 29fc203:	ud2
 29fc205:	ud2
 29fc207:	ud2
 29fc209:	ud2
 29fc20b:	ud2
 29fc20d:	ud2
 29fc20f:	ud2
 29fc211:	ud2
 29fc213:	ud2
 29fc215:	ud2
 29fc217:	ud2
 29fc219:	ud2
 29fc21b:	ud2
 29fc21d:	ud2
 29fc21f:	ud2
 29fc221:	ud2
 29fc223:	ud2
 29fc225:	ud2
 29fc227:	ud2
 29fc229:	ud2
 29fc22b:	ud2
 29fc22d:	ud2
 29fc22f:	ud2
 29fc231:	ud2
 29fc233:	ud2
 29fc235:	ud2
 29fc237:	ud2
 29fc239:	ud2
 29fc23b:	ud2
 29fc23d:	ud2
 29fc23f:	ud2
 29fc241:	ud2
 29fc243:	ud2
 29fc245:	ud2
 29fc247:	ud2
 29fc249:	ud2
 29fc24b:	ud2
 29fc24d:	ud2
 29fc24f:	ud2
 29fc251:	ud2
 29fc253:	ud2
 29fc255:	ud2
 29fc257:	ud2
 29fc259:	ud2
 29fc25b:	ud2
 29fc25d:	ud2
 29fc25f:	ud2
 29fc261:	ud2
 29fc263:	ud2
 29fc265:	ud2
 29fc267:	ud2
 29fc269:	ud2
 29fc26b:	ud2
 29fc26d:	ud2
 29fc26f:	ud2
 29fc271:	ud2
 29fc273:	ud2
 29fc275:	ud2
 29fc277:	ud2
 29fc279:	ud2
 29fc27b:	ud2
 29fc27d:	ud2
 29fc27f:	ud2
 29fc281:	ud2
 29fc283:	ud2
 29fc285:	ud2
 29fc287:	ud2
 29fc289:	ud2
 29fc28b:	ud2
 29fc28d:	ud2
 29fc28f:	ud2
 29fc291:	ud2
 29fc293:	ud2
 29fc295:	ud2
 29fc297:	ud2
 29fc299:	ud2
 29fc29b:	ud2
 29fc29d:	ud2
 29fc29f:	ud2
 29fc2a1:	ud2
 29fc2a3:	ud2
 29fc2a5:	ud2
 29fc2a7:	ud2
 29fc2a9:	ud2
 29fc2ab:	ud2
 29fc2ad:	ud2
 29fc2af:	ud2
 29fc2b1:	ud2
 29fc2b3:	ud2
 29fc2b5:	ud2
 29fc2b7:	ud2
 29fc2b9:	ud2
 29fc2bb:	ud2
 29fc2bd:	ud2
 29fc2bf:	ud2
 29fc2c1:	ud2
 29fc2c3:	ud2
 29fc2c5:	ud2
 29fc2c7:	ud2
 29fc2c9:	ud2
 29fc2cb:	ud2
 29fc2cd:	ud2
 29fc2cf:	ud2
 29fc2d1:	ud2
 29fc2d3:	ud2
 29fc2d5:	ud2
 29fc2d7:	ud2
 29fc2d9:	ud2
 29fc2db:	ud2
 29fc2dd:	ud2
 29fc2df:	ud2
 29fc2e1:	ud2
 29fc2e3:	ud2
 29fc2e5:	ud2
 29fc2e7:	ud2
 29fc2e9:	ud2
 29fc2eb:	ud2
 29fc2ed:	ud2
 29fc2ef:	ud2
 29fc2f1:	ud2
 29fc2f3:	ud2
 29fc2f5:	ud2
 29fc2f7:	ud2
 29fc2f9:	ud2
 29fc2fb:	ud2
 29fc2fd:	ud2
 29fc2ff:	ud2
 29fc301:	ud2
 29fc303:	ud2
 29fc305:	ud2
 29fc307:	ud2
 29fc309:	ud2
 29fc30b:	ud2
 29fc30d:	ud2
 29fc30f:	ud2
 29fc311:	ud2
 29fc313:	ud2
 29fc315:	ud2
 29fc317:	ud2
 29fc319:	ud2
 29fc31b:	ud2
 29fc31d:	ud2
 29fc31f:	ud2
 29fc321:	ud2
 29fc323:	ud2
 29fc325:	ud2
 29fc327:	ud2
 29fc329:	ud2
 29fc32b:	ud2
 29fc32d:	ud2
 29fc32f:	ud2
 29fc331:	ud2
 29fc333:	ud2
 29fc335:	ud2
 29fc337:	ud2
 29fc339:	ud2
 29fc33b:	ud2
 29fc33d:	ud2
 29fc33f:	ud2
 29fc341:	ud2
 29fc343:	ud2
 29fc345:	ud2
 29fc347:	ud2
 29fc349:	ud2
 29fc34b:	ud2
 29fc34d:	ud2
 29fc34f:	ud2
 29fc351:	ud2
 29fc353:	ud2
 29fc355:	ud2
 29fc357:	ud2
 29fc359:	ud2
 29fc35b:	ud2
 29fc35d:	ud2
 29fc35f:	ud2
 29fc361:	ud2
 29fc363:	ud2
 29fc365:	ud2
 29fc367:	ud2
 29fc369:	ud2
 29fc36b:	ud2
 29fc36d:	ud2
 29fc36f:	ud2
 29fc371:	ud2
 29fc373:	ud2
 29fc375:	ud2
 29fc377:	ud2
 29fc379:	ud2
 29fc37b:	ud2
 29fc37d:	ud2
 29fc37f:	ud2
 29fc381:	ud2
 29fc383:	ud2
 29fc385:	ud2
 29fc387:	ud2
 29fc389:	ud2
 29fc38b:	ud2
 29fc38d:	ud2
 29fc38f:	ud2
 29fc391:	ud2
 29fc393:	ud2
 29fc395:	ud2
 29fc397:	ud2
 29fc399:	ud2
 29fc39b:	ud2
 29fc39d:	ud2
 29fc39f:	ud2
 29fc3a1:	ud2
 29fc3a3:	ud2
 29fc3a5:	ud2
 29fc3a7:	ud2
 29fc3a9:	ud2
 29fc3ab:	ud2
 29fc3ad:	ud2
 29fc3af:	ud2
 29fc3b1:	ud2
 29fc3b3:	ud2
 29fc3b5:	ud2
 29fc3b7:	ud2
 29fc3b9:	ud2
 29fc3bb:	ud2
 29fc3bd:	ud2
 29fc3bf:	ud2
 29fc3c1:	ud2
 29fc3c3:	ud2
 29fc3c5:	ud2
 29fc3c7:	ud2
 29fc3c9:	ud2
 29fc3cb:	ud2
 29fc3cd:	ud2
 29fc3cf:	ud2
 29fc3d1:	ud2
 29fc3d3:	ud2
 29fc3d5:	ud2
 29fc3d7:	ud2
 29fc3d9:	ud2
 29fc3db:	ud2
 29fc3dd:	ud2
 29fc3df:	ud2
 29fc3e1:	ud2
 29fc3e3:	ud2
 29fc3e5:	ud2
 29fc3e7:	ud2
 29fc3e9:	ud2
 29fc3eb:	ud2
 29fc3ed:	ud2
 29fc3ef:	ud2
 29fc3f1:	ud2
 29fc3f3:	ud2
 29fc3f5:	ud2
 29fc3f7:	ud2
 29fc3f9:	ud2
 29fc3fb:	ud2
 29fc3fd:	ud2
 29fc3ff:	ud2
 29fc401:	ud2
 29fc403:	ud2
 29fc405:	ud2
 29fc407:	ud2
 29fc409:	ud2
 29fc40b:	ud2
 29fc40d:	ud2
 29fc40f:	ud2
 29fc411:	ud2
 29fc413:	ud2
 29fc415:	ud2
 29fc417:	ud2
 29fc419:	ud2
 29fc41b:	ud2
 29fc41d:	ud2
 29fc41f:	ud2
 29fc421:	ud2
 29fc423:	ud2
 29fc425:	ud2
 29fc427:	ud2
 29fc429:	ud2
 29fc42b:	ud2
 29fc42d:	ud2
 29fc42f:	ud2
 29fc431:	ud2
 29fc433:	ud2
 29fc435:	ud2
 29fc437:	ud2
 29fc439:	ud2
 29fc43b:	ud2
 29fc43d:	ud2
 29fc43f:	ud2
 29fc441:	ud2
 29fc443:	ud2
 29fc445:	ud2
 29fc447:	ud2
 29fc449:	ud2
 29fc44b:	ud2
 29fc44d:	ud2
 29fc44f:	ud2
 29fc451:	ud2
 29fc453:	ud2
 29fc455:	ud2
 29fc457:	ud2
 29fc459:	ud2
 29fc45b:	ud2
 29fc45d:	ud2
 29fc45f:	ud2
 29fc461:	ud2
 29fc463:	ud2
 29fc465:	ud2
 29fc467:	ud2
 29fc469:	ud2
 29fc46b:	ud2
 29fc46d:	ud2
 29fc46f:	ud2
 29fc471:	ud2
 29fc473:	ud2
 29fc475:	ud2
 29fc477:	ud2
 29fc479:	ud2
 29fc47b:	ud2
 29fc47d:	ud2
 29fc47f:	ud2
 29fc481:	ud2
 29fc483:	ud2
 29fc485:	ud2
 29fc487:	ud2
 29fc489:	ud2
 29fc48b:	ud2
 29fc48d:	ud2
 29fc48f:	ud2
 29fc491:	ud2
 29fc493:	ud2
 29fc495:	ud2
 29fc497:	ud2
 29fc499:	ud2
 29fc49b:	ud2
 29fc49d:	ud2
 29fc49f:	ud2
 29fc4a1:	ud2
 29fc4a3:	ud2
 29fc4a5:	ud2
 29fc4a7:	ud2
 29fc4a9:	ud2
 29fc4ab:	ud2
 29fc4ad:	ud2
 29fc4af:	ud2
 29fc4b1:	ud2
 29fc4b3:	ud2
 29fc4b5:	ud2
 29fc4b7:	ud2
 29fc4b9:	ud2
 29fc4bb:	ud2
 29fc4bd:	ud2
 29fc4bf:	ud2
 29fc4c1:	ud2
 29fc4c3:	ud2
 29fc4c5:	ud2
 29fc4c7:	ud2
 29fc4c9:	ud2
 29fc4cb:	ud2
 29fc4cd:	ud2
 29fc4cf:	ud2
 29fc4d1:	ud2
 29fc4d3:	ud2
 29fc4d5:	ud2
 29fc4d7:	ud2
 29fc4d9:	ud2
 29fc4db:	ud2
 29fc4dd:	ud2
 29fc4df:	ud2
 29fc4e1:	ud2
 29fc4e3:	ud2
 29fc4e5:	ud2
 29fc4e7:	ud2
 29fc4e9:	ud2
 29fc4eb:	ud2
 29fc4ed:	ud2
 29fc4ef:	ud2
 29fc4f1:	ud2
 29fc4f3:	ud2
 29fc4f5:	ud2
 29fc4f7:	ud2
 29fc4f9:	ud2
 29fc4fb:	ud2
 29fc4fd:	ud2
 29fc4ff:	ud2
 29fc501:	ud2
 29fc503:	ud2
 29fc505:	ud2
 29fc507:	ud2
 29fc509:	ud2
 29fc50b:	ud2
 29fc50d:	ud2
 29fc50f:	ud2
 29fc511:	ud2
 29fc513:	ud2
 29fc515:	ud2
 29fc517:	ud2
 29fc519:	ud2
 29fc51b:	ud2
 29fc51d:	ud2
 29fc51f:	ud2
 29fc521:	ud2
 29fc523:	ud2
 29fc525:	ud2
 29fc527:	ud2
 29fc529:	ud2
 29fc52b:	ud2
 29fc52d:	ud2
 29fc52f:	ud2
 29fc531:	ud2
 29fc533:	ud2
 29fc535:	ud2
 29fc537:	ud2
 29fc539:	ud2
 29fc53b:	ud2
 29fc53d:	ud2
 29fc53f:	ud2
 29fc541:	ud2
 29fc543:	ud2
 29fc545:	ud2
 29fc547:	ud2
 29fc549:	ud2
 29fc54b:	ud2
 29fc54d:	ud2
 29fc54f:	ud2
 29fc551:	ud2
 29fc553:	ud2
 29fc555:	ud2
 29fc557:	ud2
 29fc559:	ud2
 29fc55b:	ud2
 29fc55d:	ud2
 29fc55f:	ud2
 29fc561:	ud2
 29fc563:	ud2
 29fc565:	ud2
 29fc567:	ud2
 29fc569:	ud2
 29fc56b:	ud2
 29fc56d:	ud2
 29fc56f:	ud2
 29fc571:	ud2
 29fc573:	ud2
 29fc575:	ud2
 29fc577:	ud2
 29fc579:	ud2
 29fc57b:	ud2
 29fc57d:	ud2
 29fc57f:	ud2
 29fc581:	ud2
 29fc583:	ud2
 29fc585:	ud2
 29fc587:	ud2
 29fc589:	ud2
 29fc58b:	ud2
 29fc58d:	ud2
 29fc58f:	ud2
 29fc591:	ud2
 29fc593:	ud2
 29fc595:	ud2
 29fc597:	ud2
 29fc599:	ud2
 29fc59b:	ud2
 29fc59d:	ud2
 29fc59f:	ud2
 29fc5a1:	ud2
 29fc5a3:	ud2
 29fc5a5:	ud2
 29fc5a7:	ud2
 29fc5a9:	ud2
 29fc5ab:	ud2
 29fc5ad:	ud2
 29fc5af:	ud2
 29fc5b1:	ud2
 29fc5b3:	ud2
 29fc5b5:	ud2
 29fc5b7:	ud2
 29fc5b9:	ud2
 29fc5bb:	ud2
 29fc5bd:	ud2
 29fc5bf:	ud2
 29fc5c1:	ud2
 29fc5c3:	ud2
 29fc5c5:	ud2
 29fc5c7:	ud2
 29fc5c9:	ud2
 29fc5cb:	ud2
 29fc5cd:	ud2
 29fc5cf:	ud2
 29fc5d1:	ud2
 29fc5d3:	ud2
 29fc5d5:	ud2
 29fc5d7:	ud2
 29fc5d9:	ud2
 29fc5db:	ud2
 29fc5dd:	ud2
 29fc5df:	ud2
 29fc5e1:	ud2
 29fc5e3:	ud2
 29fc5e5:	ud2
 29fc5e7:	ud2
 29fc5e9:	ud2
 29fc5eb:	ud2
 29fc5ed:	ud2
 29fc5ef:	ud2
 29fc5f1:	ud2
 29fc5f3:	ud2
 29fc5f5:	ud2
 29fc5f7:	ud2
 29fc5f9:	ud2
 29fc5fb:	ud2
 29fc5fd:	ud2
 29fc5ff:	ud2
 29fc601:	ud2
 29fc603:	ud2
 29fc605:	ud2
 29fc607:	ud2
 29fc609:	ud2
 29fc60b:	ud2
 29fc60d:	ud2
 29fc60f:	ud2
 29fc611:	ud2
 29fc613:	ud2
 29fc615:	ud2
 29fc617:	ud2
 29fc619:	ud2
 29fc61b:	ud2
 29fc61d:	ud2
 29fc61f:	ud2
 29fc621:	ud2
 29fc623:	ud2
 29fc625:	ud2
 29fc627:	ud2
 29fc629:	ud2
 29fc62b:	ud2
 29fc62d:	ud2
 29fc62f:	ud2
 29fc631:	ud2
 29fc633:	ud2
 29fc635:	ud2
 29fc637:	ud2
 29fc639:	ud2
 29fc63b:	ud2
 29fc63d:	ud2
 29fc63f:	ud2
 29fc641:	ud2
 29fc643:	ud2
 29fc645:	ud2
 29fc647:	ud2
 29fc649:	ud2
 29fc64b:	ud2
 29fc64d:	ud2
 29fc64f:	ud2
 29fc651:	ud2
 29fc653:	ud2
 29fc655:	ud2
 29fc657:	ud2
 29fc659:	ud2
 29fc65b:	ud2
 29fc65d:	ud2
 29fc65f:	ud2
 29fc661:	ud2
 29fc663:	ud2
 29fc665:	ud2
 29fc667:	ud2
 29fc669:	ud2
 29fc66b:	ud2
 29fc66d:	ud2
 29fc66f:	ud2
 29fc671:	ud2
 29fc673:	ud2
 29fc675:	ud2
 29fc677:	ud2
 29fc679:	ud2
 29fc67b:	ud2
 29fc67d:	ud2
 29fc67f:	ud2
 29fc681:	ud2
 29fc683:	ud2
 29fc685:	ud2
 29fc687:	ud2
 29fc689:	ud2
 29fc68b:	ud2
 29fc68d:	ud2
 29fc68f:	ud2
 29fc691:	ud2
 29fc693:	ud2
 29fc695:	ud2
 29fc697:	ud2
 29fc699:	ud2
 29fc69b:	ud2
 29fc69d:	ud2
 29fc69f:	ud2
 29fc6a1:	ud2
 29fc6a3:	ud2
 29fc6a5:	ud2
 29fc6a7:	ud2
 29fc6a9:	ud2
 29fc6ab:	ud2
 29fc6ad:	ud2
 29fc6af:	ud2
 29fc6b1:	ud2
 29fc6b3:	ud2
 29fc6b5:	ud2
 29fc6b7:	ud2
 29fc6b9:	ud2
 29fc6bb:	ud2
 29fc6bd:	ud2
 29fc6bf:	ud2
 29fc6c1:	ud2
 29fc6c3:	ud2
 29fc6c5:	ud2
 29fc6c7:	ud2
 29fc6c9:	ud2
 29fc6cb:	ud2
 29fc6cd:	ud2
 29fc6cf:	ud2
 29fc6d1:	ud2
 29fc6d3:	ud2
 29fc6d5:	ud2
 29fc6d7:	ud2
 29fc6d9:	ud2
 29fc6db:	ud2
 29fc6dd:	ud2
 29fc6df:	ud2
 29fc6e1:	ud2
 29fc6e3:	ud2
 29fc6e5:	ud2
 29fc6e7:	ud2
 29fc6e9:	ud2
 29fc6eb:	ud2
 29fc6ed:	ud2
 29fc6ef:	ud2
 29fc6f1:	ud2
 29fc6f3:	ud2
 29fc6f5:	ud2
 29fc6f7:	ud2
 29fc6f9:	ud2
 29fc6fb:	ud2
 29fc6fd:	ud2
 29fc6ff:	ud2
 29fc701:	ud2
 29fc703:	ud2
 29fc705:	ud2
 29fc707:	ud2
 29fc709:	ud2
 29fc70b:	ud2
 29fc70d:	ud2
 29fc70f:	ud2
 29fc711:	ud2
 29fc713:	ud2
 29fc715:	ud2
 29fc717:	ud2
 29fc719:	ud2
 29fc71b:	ud2
 29fc71d:	ud2
 29fc71f:	ud2
 29fc721:	ud2
 29fc723:	ud2
 29fc725:	ud2
 29fc727:	ud2
 29fc729:	ud2
 29fc72b:	ud2
 29fc72d:	ud2
 29fc72f:	ud2
 29fc731:	ud2
 29fc733:	ud2
 29fc735:	ud2
 29fc737:	ud2
 29fc739:	ud2
 29fc73b:	ud2
 29fc73d:	ud2
 29fc73f:	ud2
 29fc741:	ud2
 29fc743:	ud2
 29fc745:	ud2
 29fc747:	ud2
 29fc749:	ud2
 29fc74b:	ud2
 29fc74d:	ud2
 29fc74f:	ud2
 29fc751:	ud2
 29fc753:	ud2
 29fc755:	ud2
 29fc757:	ud2
 29fc759:	ud2
 29fc75b:	ud2
 29fc75d:	ud2
 29fc75f:	ud2
 29fc761:	ud2
 29fc763:	ud2
 29fc765:	ud2
 29fc767:	ud2
 29fc769:	ud2
 29fc76b:	ud2
 29fc76d:	ud2
 29fc76f:	ud2
 29fc771:	ud2
 29fc773:	ud2
 29fc775:	ud2
 29fc777:	ud2
 29fc779:	ud2
 29fc77b:	ud2
 29fc77d:	ud2
 29fc77f:	ud2
 29fc781:	ud2
 29fc783:	ud2
 29fc785:	ud2
 29fc787:	ud2
 29fc789:	ud2
 29fc78b:	ud2
 29fc78d:	ud2
 29fc78f:	ud2
 29fc791:	ud2
 29fc793:	ud2
 29fc795:	ud2
 29fc797:	ud2
 29fc799:	ud2
 29fc79b:	ud2
 29fc79d:	ud2
 29fc79f:	ud2
 29fc7a1:	ud2
 29fc7a3:	ud2
 29fc7a5:	ud2
 29fc7a7:	ud2
 29fc7a9:	ud2
 29fc7ab:	ud2
 29fc7ad:	ud2
 29fc7af:	ud2
 29fc7b1:	ud2
 29fc7b3:	ud2
 29fc7b5:	ud2
 29fc7b7:	ud2
 29fc7b9:	ud2
 29fc7bb:	ud2
 29fc7bd:	ud2
 29fc7bf:	ud2
 29fc7c1:	ud2
 29fc7c3:	ud2
 29fc7c5:	ud2
 29fc7c7:	ud2
 29fc7c9:	ud2
 29fc7cb:	ud2
 29fc7cd:	ud2
 29fc7cf:	ud2
 29fc7d1:	ud2
 29fc7d3:	ud2
 29fc7d5:	ud2
 29fc7d7:	ud2
 29fc7d9:	ud2
 29fc7db:	ud2
 29fc7dd:	ud2
 29fc7df:	ud2
 29fc7e1:	ud2
 29fc7e3:	ud2
 29fc7e5:	ud2
 29fc7e7:	ud2
 29fc7e9:	ud2
 29fc7eb:	ud2
 29fc7ed:	ud2
 29fc7ef:	ud2
 29fc7f1:	ud2
 29fc7f3:	ud2
 29fc7f5:	ud2
 29fc7f7:	ud2
 29fc7f9:	ud2
 29fc7fb:	ud2
 29fc7fd:	ud2
 29fc7ff:	ud2
 29fc801:	ud2
 29fc803:	ud2
 29fc805:	ud2
 29fc807:	ud2
 29fc809:	ud2
 29fc80b:	ud2
 29fc80d:	ud2
 29fc80f:	ud2
 29fc811:	ud2
 29fc813:	ud2
 29fc815:	ud2
 29fc817:	ud2
 29fc819:	ud2
 29fc81b:	ud2
 29fc81d:	ud2
 29fc81f:	ud2
 29fc821:	ud2
 29fc823:	ud2
 29fc825:	ud2
 29fc827:	ud2
 29fc829:	ud2
 29fc82b:	ud2
 29fc82d:	ud2
 29fc82f:	ud2
 29fc831:	ud2
 29fc833:	ud2
 29fc835:	ud2
 29fc837:	ud2
 29fc839:	ud2
 29fc83b:	ud2
 29fc83d:	ud2
 29fc83f:	ud2
 29fc841:	ud2
 29fc843:	ud2
 29fc845:	ud2
 29fc847:	ud2
 29fc849:	ud2
 29fc84b:	ud2
 29fc84d:	ud2
 29fc84f:	ud2
 29fc851:	ud2
 29fc853:	ud2
 29fc855:	ud2
 29fc857:	ud2
 29fc859:	ud2
 29fc85b:	ud2
 29fc85d:	ud2
 29fc85f:	ud2
 29fc861:	ud2
 29fc863:	ud2
 29fc865:	ud2
 29fc867:	ud2
 29fc869:	ud2
 29fc86b:	ud2
 29fc86d:	ud2
 29fc86f:	ud2
 29fc871:	ud2
 29fc873:	ud2
 29fc875:	ud2
 29fc877:	ud2
 29fc879:	ud2
 29fc87b:	ud2
 29fc87d:	ud2
 29fc87f:	ud2
 29fc881:	ud2
 29fc883:	ud2
 29fc885:	ud2
 29fc887:	ud2
 29fc889:	ud2
 29fc88b:	ud2
 29fc88d:	ud2
 29fc88f:	ud2
 29fc891:	ud2
 29fc893:	ud2
 29fc895:	ud2
 29fc897:	ud2
 29fc899:	ud2
 29fc89b:	ud2
 29fc89d:	ud2
 29fc89f:	ud2
 29fc8a1:	ud2
 29fc8a3:	ud2
 29fc8a5:	add    %al,(%rax)
 29fc8a7:	add    %bh,%bh
 29fc8a9:	(bad)
 29fc8aa:	(bad)
 29fc8ab:	incl   (%rax)
	...
