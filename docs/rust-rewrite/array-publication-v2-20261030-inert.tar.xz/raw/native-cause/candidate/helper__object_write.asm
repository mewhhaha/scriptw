
/workspace/scriptw/target/performance-dense-numbers-20261030/v2/native-cause/candidate/runtime-portable.elf:     file format elf64-x86-64


Disassembly of section .text:

00000000029fc920 <wasm[0]::function[1016]::helper::object_write>:
 29fc920:	push   %rbp
 29fc921:	mov    %rsp,%rbp
 29fc924:	mov    0x8(%rdi),%r10
 29fc928:	mov    0x18(%r10),%r10
 29fc92c:	add    $0xf0,%r10
 29fc933:	cmp    %rsp,%r10
 29fc936:	ja     29fcfe7 <wasm[0]::function[1016]::helper::object_write+0x6c7>
 29fc93c:	sub    $0xe0,%rsp
 29fc943:	mov    %rbx,0xb0(%rsp)
 29fc94b:	mov    %r12,0xb8(%rsp)
 29fc953:	mov    %r13,0xc0(%rsp)
 29fc95b:	mov    %r14,0xc8(%rsp)
 29fc963:	mov    %r15,0xd0(%rsp)
 29fc96b:	mov    %rdx,0x78(%rsp)
 29fc970:	mov    %rcx,0x80(%rsp)
 29fc978:	mov    %r9,0x88(%rsp)
 29fc980:	mov    0x10(%rbp),%r13
 29fc984:	mov    0x18(%rbp),%r9
 29fc988:	mov    0x20(%rbp),%r14
 29fc98c:	mov    0x28(%rbp),%r15
 29fc990:	mov    0x30(%rbp),%rax
 29fc994:	mov    0x38(%rbp),%rcx
 29fc998:	mov    %rcx,0x90(%rsp)
 29fc9a0:	mov    0x40(%rbp),%rdx
 29fc9a4:	mov    0x48(%rbp),%rcx
 29fc9a8:	mov    %r8d,0x50(%rsp)
 29fc9ad:	mov    %r9d,0x60(%rsp)
 29fc9b2:	mov    %eax,0x68(%rsp)
 29fc9b6:	mov    %edx,0x58(%rsp)
 29fc9ba:	mov    %ecx,0x70(%rsp)
 29fc9be:	mov    0x18(%rdi),%r10
 29fc9c2:	mov    (%r10),%r9
 29fc9c5:	mov    %r10,0xa0(%rsp)
 29fc9cd:	mov    0x8(%rdi),%r12
 29fc9d1:	mov    %rdi,%rsi
 29fc9d4:	mov    0x8(%r12),%rax
 29fc9d9:	cmp    %rax,%r9
 29fc9dc:	jae    29fcfb4 <wasm[0]::function[1016]::helper::object_write+0x694>
 29fc9e2:	mov    %rsi,%rbx
 29fc9e5:	mov    %rax,0x98(%rsp)
 29fc9ed:	mov    0x70(%rsp),%eax
 29fc9f1:	test   %eax,%eax
 29fc9f3:	je     29fcfe9 <wasm[0]::function[1016]::helper::object_write+0x6c9>
 29fc9f9:	mov    0x50(%rsp),%r8d
 29fc9fe:	mov    0x60(%rsp),%edi
 29fca02:	mov    0x68(%rsp),%edx
 29fca06:	mov    0x58(%rsp),%esi
 29fca0a:	mov    0x80(%rsp),%rcx
 29fca12:	mov    %rcx,(%rsp)
 29fca16:	mov    %r8d,0x8(%rsp)
 29fca1b:	mov    0x88(%rsp),%r9
 29fca23:	mov    %r9d,0x10(%rsp)
 29fca28:	mov    %r13,0x18(%rsp)
 29fca2d:	mov    %edi,0x20(%rsp)
 29fca31:	mov    %r14d,0x28(%rsp)
 29fca36:	mov    %r15,0x30(%rsp)
 29fca3b:	mov    %edx,0x38(%rsp)
 29fca3f:	mov    %esi,0x40(%rsp)
 29fca43:	mov    %eax,0x48(%rsp)
 29fca47:	mov    0x78(%rsp),%r9
 29fca4c:	mov    %rbx,%rsi
 29fca4f:	mov    %rbx,%rdi
 29fca52:	mov    %r9,%rdx
 29fca55:	call   2c56d40 <wasm[0]::function[1073]::helper::ordinary_set>
 29fca5a:	sub    $0x50,%rsp
 29fca5e:	test   %esi,%esi
 29fca60:	je     29fca71 <wasm[0]::function[1016]::helper::object_write+0x151>
 29fca66:	mov    %rdi,%rbx
 29fca69:	mov    %rcx,%r14
 29fca6c:	jmp    29fcf78 <wasm[0]::function[1016]::helper::object_write+0x658>
 29fca71:	cmp    $0x2,%eax
 29fca74:	je     29fcd0f <wasm[0]::function[1016]::helper::object_write+0x3ef>
 29fca7a:	cmp    $0x4,%eax
 29fca7d:	je     29fcc68 <wasm[0]::function[1016]::helper::object_write+0x348>
 29fca83:	cmp    $0x3,%eax
 29fca86:	je     29fcc35 <wasm[0]::function[1016]::helper::object_write+0x315>
 29fca8c:	cmp    $0xa,%eax
 29fca8f:	je     29fcb8d <wasm[0]::function[1016]::helper::object_write+0x26d>
 29fca95:	test   %eax,%eax
 29fca97:	sete   %cl
 29fca9a:	cmp    $0x1,%eax
 29fca9d:	sete   %al
 29fcaa0:	or     %eax,%ecx
 29fcaa2:	test   %cl,%cl
 29fcaa4:	jne    29fcb86 <wasm[0]::function[1016]::helper::object_write+0x266>
 29fcaaa:	xor    %eax,%eax
 29fcaac:	test   %edx,%edx
 29fcaae:	je     29fcaef <wasm[0]::function[1016]::helper::object_write+0x1cf>
 29fcab4:	xor    %eax,%eax
 29fcab6:	test   $0x1,%edx
 29fcabc:	jne    29fcaef <wasm[0]::function[1016]::helper::object_write+0x1cf>
 29fcac2:	mov    0x28(%r12),%rax
 29fcac7:	mov    0x20(%r12),%rsi
 29fcacc:	mov    %edx,%edi
 29fcace:	xor    %rcx,%rcx
 29fcad1:	lea    0x4(%rsi,%rdi,1),%rsi
 29fcad6:	cmp    %rax,%rdi
 29fcad9:	cmova  %rcx,%rsi
 29fcadd:	mov    (%rsi),%eax
 29fcadf:	mov    0x28(%rbx),%rcx
 29fcae3:	cmp    0x1d4(%rcx),%eax
 29fcae9:	sete   %al
 29fcaec:	movzbl %al,%eax
 29fcaef:	test   %eax,%eax
 29fcaf1:	jne    29fcafe <wasm[0]::function[1016]::helper::object_write+0x1de>
 29fcaf7:	xor    %eax,%eax
 29fcaf9:	jmp    29fcb77 <wasm[0]::function[1016]::helper::object_write+0x257>
 29fcafe:	xor    %eax,%eax
 29fcb00:	test   %edx,%edx
 29fcb02:	je     29fcb43 <wasm[0]::function[1016]::helper::object_write+0x223>
 29fcb08:	xor    %eax,%eax
 29fcb0a:	test   $0x1,%edx
 29fcb10:	jne    29fcb43 <wasm[0]::function[1016]::helper::object_write+0x223>
 29fcb16:	mov    0x28(%r12),%rax
 29fcb1b:	mov    0x20(%r12),%rsi
 29fcb20:	mov    %edx,%edi
 29fcb22:	xor    %rcx,%rcx
 29fcb25:	lea    0x4(%rsi,%rdi,1),%rsi
 29fcb2a:	cmp    %rax,%rdi
 29fcb2d:	cmova  %rcx,%rsi
 29fcb31:	mov    (%rsi),%eax
 29fcb33:	mov    0x28(%rbx),%rcx
 29fcb37:	cmp    0x1d4(%rcx),%eax
 29fcb3d:	sete   %al
 29fcb40:	movzbl %al,%eax
 29fcb43:	test   %eax,%eax
 29fcb45:	je     29fcfeb <wasm[0]::function[1016]::helper::object_write+0x6cb>
 29fcb4b:	test   %edx,%edx
 29fcb4d:	je     29fcfed <wasm[0]::function[1016]::helper::object_write+0x6cd>
 29fcb53:	test   %edx,%edx
 29fcb55:	je     29fcfef <wasm[0]::function[1016]::helper::object_write+0x6cf>
 29fcb5b:	mov    0x28(%r12),%rax
 29fcb60:	mov    %edx,%edx
 29fcb62:	xor    %rcx,%rcx
 29fcb65:	mov    %rdx,%rsi
 29fcb68:	add    0x20(%r12),%rsi
 29fcb6d:	cmp    %rax,%rdx
 29fcb70:	cmova  %rcx,%rsi
 29fcb74:	mov    0x3c(%rsi),%eax
 29fcb77:	test   %eax,%eax
 29fcb79:	sete   %sil
 29fcb7d:	movzbl %sil,%eax
 29fcb81:	jmp    29fcd18 <wasm[0]::function[1016]::helper::object_write+0x3f8>
 29fcb86:	xor    %eax,%eax
 29fcb88:	jmp    29fcd18 <wasm[0]::function[1016]::helper::object_write+0x3f8>
 29fcb8d:	xor    %eax,%eax
 29fcb8f:	test   %edx,%edx
 29fcb91:	je     29fcbd3 <wasm[0]::function[1016]::helper::object_write+0x2b3>
 29fcb97:	xor    %eax,%eax
 29fcb99:	test   $0x1,%edx
 29fcb9f:	jne    29fcbd3 <wasm[0]::function[1016]::helper::object_write+0x2b3>
 29fcba5:	mov    0x28(%r12),%rax
 29fcbaa:	mov    0x20(%r12),%rsi
 29fcbaf:	mov    %edx,%edi
 29fcbb1:	xor    %rcx,%rcx
 29fcbb4:	lea    0x4(%rsi,%rdi,1),%r11
 29fcbb9:	cmp    %rax,%rdi
 29fcbbc:	cmova  %rcx,%r11
 29fcbc0:	mov    (%r11),%eax
 29fcbc3:	mov    0x28(%rbx),%rcx
 29fcbc7:	cmp    0x23c(%rcx),%eax
 29fcbcd:	sete   %al
 29fcbd0:	movzbl %al,%eax
 29fcbd3:	test   %eax,%eax
 29fcbd5:	je     29fcff1 <wasm[0]::function[1016]::helper::object_write+0x6d1>
 29fcbdb:	test   %edx,%edx
 29fcbdd:	je     29fcff3 <wasm[0]::function[1016]::helper::object_write+0x6d3>
 29fcbe3:	test   %edx,%edx
 29fcbe5:	je     29fcff5 <wasm[0]::function[1016]::helper::object_write+0x6d5>
 29fcbeb:	mov    0x28(%r12),%rax
 29fcbf0:	mov    0x20(%r12),%rsi
 29fcbf5:	mov    %edx,%edx
 29fcbf7:	xor    %rcx,%rcx
 29fcbfa:	lea    (%rsi,%rdx,1),%rdi
 29fcbfe:	cmp    %rax,%rdx
 29fcc01:	cmova  %rcx,%rdi
 29fcc05:	mov    0x14(%rdi),%edx
 29fcc08:	test   %edx,%edx
 29fcc0a:	je     29fcff7 <wasm[0]::function[1016]::helper::object_write+0x6d7>
 29fcc10:	test   %edx,%edx
 29fcc12:	je     29fcff9 <wasm[0]::function[1016]::helper::object_write+0x6d9>
 29fcc18:	mov    %edx,%edi
 29fcc1a:	lea    0x10(%rsi,%rdi,1),%rdx
 29fcc1f:	cmp    %rax,%rdi
 29fcc22:	cmova  %rcx,%rdx
 29fcc26:	mov    (%rdx),%eax
 29fcc28:	test   %eax,%eax
 29fcc2a:	setne  %al
 29fcc2d:	movzbl %al,%eax
 29fcc30:	jmp    29fcd18 <wasm[0]::function[1016]::helper::object_write+0x3f8>
 29fcc35:	movq   %rcx,%xmm0
 29fcc3a:	ucomisd 0x3ee(%rip),%xmm0        # 29fd030 <wasm[0]::function[1016]::helper::object_write+0x710>
 29fcc42:	setnp  %al
 29fcc45:	sete   %cl
 29fcc48:	and    %ecx,%eax
 29fcc4a:	ucomisd %xmm0,%xmm0
 29fcc4e:	setp   %cl
 29fcc51:	setne  %dl
 29fcc54:	or     %edx,%ecx
 29fcc56:	or     %ecx,%eax
 29fcc58:	movzbl %al,%eax
 29fcc5b:	test   %eax,%eax
 29fcc5d:	sete   %al
 29fcc60:	movzbl %al,%eax
 29fcc63:	jmp    29fcd18 <wasm[0]::function[1016]::helper::object_write+0x3f8>
 29fcc68:	xor    %eax,%eax
 29fcc6a:	test   %edx,%edx
 29fcc6c:	je     29fccad <wasm[0]::function[1016]::helper::object_write+0x38d>
 29fcc72:	xor    %eax,%eax
 29fcc74:	test   $0x1,%edx
 29fcc7a:	jne    29fccad <wasm[0]::function[1016]::helper::object_write+0x38d>
 29fcc80:	mov    0x28(%r12),%rax
 29fcc85:	mov    0x20(%r12),%rsi
 29fcc8a:	mov    %edx,%edi
 29fcc8c:	xor    %rcx,%rcx
 29fcc8f:	lea    0x4(%rsi,%rdi,1),%rsi
 29fcc94:	cmp    %rax,%rdi
 29fcc97:	cmova  %rcx,%rsi
 29fcc9b:	mov    (%rsi),%eax
 29fcc9d:	mov    0x28(%rbx),%rcx
 29fcca1:	cmp    0x234(%rcx),%eax
 29fcca7:	sete   %al
 29fccaa:	movzbl %al,%eax
 29fccad:	test   %eax,%eax
 29fccaf:	je     29fcffb <wasm[0]::function[1016]::helper::object_write+0x6db>
 29fccb5:	test   %edx,%edx
 29fccb7:	je     29fcffd <wasm[0]::function[1016]::helper::object_write+0x6dd>
 29fccbd:	test   %edx,%edx
 29fccbf:	je     29fcfff <wasm[0]::function[1016]::helper::object_write+0x6df>
 29fccc5:	mov    0x28(%r12),%rax
 29fccca:	mov    0x20(%r12),%rsi
 29fcccf:	mov    %edx,%edx
 29fccd1:	xor    %rcx,%rcx
 29fccd4:	lea    (%rsi,%rdx,1),%rdi
 29fccd8:	cmp    %rax,%rdx
 29fccdb:	cmova  %rcx,%rdi
 29fccdf:	mov    0x10(%rdi),%edx
 29fcce2:	test   %edx,%edx
 29fcce4:	je     29fd001 <wasm[0]::function[1016]::helper::object_write+0x6e1>
 29fccea:	test   %edx,%edx
 29fccec:	je     29fd003 <wasm[0]::function[1016]::helper::object_write+0x6e3>
 29fccf2:	mov    %edx,%edi
 29fccf4:	lea    0x10(%rsi,%rdi,1),%rdx
 29fccf9:	cmp    %rax,%rdi
 29fccfc:	cmova  %rcx,%rdx
 29fcd00:	mov    (%rdx),%eax
 29fcd02:	test   %eax,%eax
 29fcd04:	setne  %al
 29fcd07:	movzbl %al,%eax
 29fcd0a:	jmp    29fcd18 <wasm[0]::function[1016]::helper::object_write+0x3f8>
 29fcd0f:	test   %rcx,%rcx
 29fcd12:	setne  %al
 29fcd15:	movzbl %al,%eax
 29fcd18:	test   %eax,%eax
 29fcd1a:	sete   %al
 29fcd1d:	movzbl %al,%eax
 29fcd20:	mov    0x90(%rsp),%rcx
 29fcd28:	test   %eax,%ecx
 29fcd2a:	jne    29fcd46 <wasm[0]::function[1016]::helper::object_write+0x426>
 29fcd30:	xor    %eax,%eax
 29fcd32:	xor    %rcx,%rcx
 29fcd35:	mov    %rax,%rdx
 29fcd38:	mov    %rax,%rbx
 29fcd3b:	mov    %rax,%rsi
 29fcd3e:	mov    %rcx,%r14
 29fcd41:	jmp    29fcf78 <wasm[0]::function[1016]::helper::object_write+0x658>
 29fcd46:	mov    0x58(%rsp),%esi
 29fcd4a:	xor    %edx,%edx
 29fcd4c:	xor    %rcx,%rcx
 29fcd4f:	mov    %rcx,%r14
 29fcd52:	mov    %esi,0x50(%rsp)
 29fcd56:	mov    %edx,0x58(%rsp)
 29fcd5a:	mov    0xa0(%rsp),%r13
 29fcd62:	mov    0x0(%r13),%rsi
 29fcd66:	mov    0x98(%rsp),%rax
 29fcd6e:	cmp    %rax,%rsi
 29fcd71:	jae    29fcfcc <wasm[0]::function[1016]::helper::object_write+0x6ac>
 29fcd77:	mov    0x50(%rsp),%ecx
 29fcd7b:	mov    0x58(%rsp),%edx
 29fcd7f:	test   %ecx,%ecx
 29fcd81:	je     29fcdfd <wasm[0]::function[1016]::helper::object_write+0x4dd>
 29fcd87:	mov    0x50(%rsp),%ecx
 29fcd8b:	test   %ecx,%ecx
 29fcd8d:	je     29fd005 <wasm[0]::function[1016]::helper::object_write+0x6e5>
 29fcd93:	mov    0x28(%r12),%rdx
 29fcd98:	mov    0x20(%r12),%rsi
 29fcd9d:	mov    %ecx,%ecx
 29fcd9f:	add    %rcx,%rsi
 29fcda2:	cmp    %rdx,%rcx
 29fcda5:	mov    %r14,%rcx
 29fcda8:	cmova  %rcx,%rsi
 29fcdac:	mov    0x10(%rsi),%edx
 29fcdaf:	test   %edx,%edx
 29fcdb1:	je     29fcdbf <wasm[0]::function[1016]::helper::object_write+0x49f>
 29fcdb7:	mov    %rcx,%r14
 29fcdba:	jmp    29fcdfd <wasm[0]::function[1016]::helper::object_write+0x4dd>
 29fcdbf:	mov    0x50(%rsp),%esi
 29fcdc3:	test   %esi,%esi
 29fcdc5:	je     29fd007 <wasm[0]::function[1016]::helper::object_write+0x6e7>
 29fcdcb:	mov    0x28(%r12),%rdi
 29fcdd0:	mov    %esi,%r8d
 29fcdd3:	mov    %r8,%rsi
 29fcdd6:	add    0x20(%r12),%rsi
 29fcddb:	cmp    %rdi,%r8
 29fcdde:	cmova  %rcx,%rsi
 29fcde2:	mov    %rcx,%r14
 29fcde5:	mov    0x1c(%rsi),%esi
 29fcde8:	mov    %rax,0x98(%rsp)
 29fcdf0:	mov    %r13,0xa0(%rsp)
 29fcdf8:	jmp    29fcd52 <wasm[0]::function[1016]::helper::object_write+0x432>
 29fcdfd:	test   %edx,%edx
 29fcdff:	jne    29fce13 <wasm[0]::function[1016]::helper::object_write+0x4f3>
 29fce05:	mov    0x8c0(%rbx),%edx
 29fce0b:	test   %edx,%edx
 29fce0d:	je     29fd009 <wasm[0]::function[1016]::helper::object_write+0x6e9>
 29fce13:	mov    %edx,0x50(%rsp)
 29fce17:	test   %edx,%edx
 29fce19:	je     29fd00b <wasm[0]::function[1016]::helper::object_write+0x6eb>
 29fce1f:	mov    %rbx,%rsi
 29fce22:	mov    %rbx,%rdi
 29fce25:	call   2ac6040 <wasm[0]::function[1049]::helper::realm_ensure_errors>
 29fce2a:	mov    0x50(%rsp),%edx
 29fce2e:	test   %edx,%edx
 29fce30:	je     29fd00d <wasm[0]::function[1016]::helper::object_write+0x6ed>
 29fce36:	test   %edx,%edx
 29fce38:	je     29fd00f <wasm[0]::function[1016]::helper::object_write+0x6ef>
 29fce3e:	mov    0x28(%r12),%rax
 29fce43:	mov    0x20(%r12),%rcx
 29fce48:	mov    %edx,%esi
 29fce4a:	lea    (%rcx,%rsi,1),%rdx
 29fce4e:	cmp    %rax,%rsi
 29fce51:	mov    %r14,%rsi
 29fce54:	cmova  %rsi,%rdx
 29fce58:	mov    0x2c(%rdx),%edx
 29fce5b:	test   %edx,%edx
 29fce5d:	je     29fd011 <wasm[0]::function[1016]::helper::object_write+0x6f1>
 29fce63:	test   %edx,%edx
 29fce65:	je     29fd013 <wasm[0]::function[1016]::helper::object_write+0x6f3>
 29fce6b:	mov    %edx,%edi
 29fce6d:	lea    0x10(%rcx,%rdi,1),%rsi
 29fce72:	cmp    %rax,%rdi
 29fce75:	mov    %r14,%rdi
 29fce78:	cmova  %rdi,%rsi
 29fce7c:	mov    (%rsi),%esi
 29fce7e:	cmp    $0x3,%esi
 29fce81:	jbe    29fd015 <wasm[0]::function[1016]::helper::object_write+0x6f5>
 29fce87:	mov    %esi,%edi
 29fce89:	shl    $0x2,%rdi
 29fce8d:	shr    $0x20,%rdi
 29fce91:	test   %rdi,%rdi
 29fce94:	jne    29fd017 <wasm[0]::function[1016]::helper::object_write+0x6f7>
 29fce9a:	shl    $0x2,%esi
 29fce9d:	add    $0x14,%esi
 29fcea0:	jb     29fd019 <wasm[0]::function[1016]::helper::object_write+0x6f9>
 29fcea6:	add    %esi,%edx
 29fcea8:	jb     29fd01b <wasm[0]::function[1016]::helper::object_write+0x6fb>
 29fceae:	mov    %edx,%edi
 29fceb0:	lea    (%rcx,%rdi,1),%rdx
 29fceb4:	cmp    %rax,%rdi
 29fceb7:	mov    %r14,%rdi
 29fceba:	cmova  %rdi,%rdx
 29fcebe:	sub    $0x20,%esi
 29fcec1:	sub    %rsi,%rdx
 29fcec4:	mov    (%rdx),%edx
 29fcec6:	test   %edx,%edx
 29fcec8:	je     29fd01d <wasm[0]::function[1016]::helper::object_write+0x6fd>
 29fcece:	test   %edx,%edx
 29fced0:	je     29fd01f <wasm[0]::function[1016]::helper::object_write+0x6ff>
 29fced6:	mov    %edx,%edx
 29fced8:	add    %rdx,%rcx
 29fcedb:	cmp    %rax,%rdx
 29fcede:	mov    %r14,%rdx
 29fcee1:	cmova  %rdx,%rcx
 29fcee5:	mov    0x18(%rcx),%r13d
 29fcee9:	mov    0x10(%rcx),%r12
 29fceed:	mov    0x1c(%rcx),%eax
 29fcef0:	mov    %eax,0x50(%rsp)
 29fcef4:	cmp    $0x6,%r13d
 29fcef8:	sete   %cl
 29fcefb:	cmp    $0x7,%r13d
 29fceff:	sete   %al
 29fcf02:	or     %eax,%ecx
 29fcf04:	cmp    $0x8,%r13d
 29fcf08:	sete   %al
 29fcf0b:	or     %eax,%ecx
 29fcf0d:	cmp    $0x9,%r13d
 29fcf11:	sete   %al
 29fcf14:	or     %eax,%ecx
 29fcf16:	movzbl %cl,%eax
 29fcf19:	test   %eax,%eax
 29fcf1b:	je     29fd021 <wasm[0]::function[1016]::helper::object_write+0x701>
 29fcf21:	mov    $0x795,%edx
 29fcf26:	mov    %rbx,%rsi
 29fcf29:	mov    %rbx,%rdi
 29fcf2c:	call   2f307a0 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 29fcf31:	mov    %rbx,%rsi
 29fcf34:	xor    %edi,%edi
 29fcf36:	mov    %rdi,%rbx
 29fcf39:	test   %eax,%eax
 29fcf3b:	je     29fd023 <wasm[0]::function[1016]::helper::object_write+0x703>
 29fcf41:	mov    0x50(%rsp),%r9d
 29fcf46:	mov    $0x5,%edx
 29fcf4b:	mov    %eax,(%rsp)
 29fcf4e:	mov    %r13,%rcx
 29fcf51:	mov    %r12,%r8
 29fcf54:	mov    %rsi,%rdi
 29fcf57:	call   2f30500 <wasm[0]::function[1101]::helper::runtime_error_for_throw>
 29fcf5c:	sub    $0x10,%rsp
 29fcf60:	test   %eax,%eax
 29fcf62:	mov    %rax,%rcx
 29fcf65:	je     29fd025 <wasm[0]::function[1016]::helper::object_write+0x705>
 29fcf6b:	mov    $0x6,%eax
 29fcf70:	mov    $0x1,%esi
 29fcf75:	mov    %rcx,%rdx
 29fcf78:	mov    %r14,%rcx
 29fcf7b:	mov    %rbx,%rdi
 29fcf7e:	mov    0xb0(%rsp),%rbx
 29fcf86:	mov    0xb8(%rsp),%r12
 29fcf8e:	mov    0xc0(%rsp),%r13
 29fcf96:	mov    0xc8(%rsp),%r14
 29fcf9e:	mov    0xd0(%rsp),%r15
 29fcfa6:	add    $0xe0,%rsp
 29fcfad:	mov    %rbp,%rsp
 29fcfb0:	pop    %rbp
 29fcfb1:	ret    $0x40
 29fcfb4:	mov    %rsi,%rbx
 29fcfb7:	mov    %rbx,%rdi
 29fcfba:	call   3018d19 <wasmtime_builtin_new_epoch>
 29fcfbf:	mov    %rax,0x98(%rsp)
 29fcfc7:	jmp    29fc9ed <wasm[0]::function[1016]::helper::object_write+0xcd>
 29fcfcc:	mov    0x8(%r12),%rax
 29fcfd1:	cmp    %rax,%rsi
 29fcfd4:	jb     29fcd77 <wasm[0]::function[1016]::helper::object_write+0x457>
 29fcfda:	mov    %rbx,%rdi
 29fcfdd:	call   3018d19 <wasmtime_builtin_new_epoch>
 29fcfe2:	jmp    29fcd77 <wasm[0]::function[1016]::helper::object_write+0x457>
 29fcfe7:	ud2
 29fcfe9:	ud2
 29fcfeb:	ud2
 29fcfed:	ud2
 29fcfef:	ud2
 29fcff1:	ud2
 29fcff3:	ud2
 29fcff5:	ud2
 29fcff7:	ud2
 29fcff9:	ud2
 29fcffb:	ud2
 29fcffd:	ud2
 29fcfff:	ud2
 29fd001:	ud2
 29fd003:	ud2
 29fd005:	ud2
 29fd007:	ud2
 29fd009:	ud2
 29fd00b:	ud2
 29fd00d:	ud2
 29fd00f:	ud2
 29fd011:	ud2
 29fd013:	ud2
 29fd015:	ud2
 29fd017:	ud2
 29fd019:	ud2
 29fd01b:	ud2
 29fd01d:	ud2
 29fd01f:	ud2
 29fd021:	ud2
 29fd023:	ud2
 29fd025:	ud2
	...
