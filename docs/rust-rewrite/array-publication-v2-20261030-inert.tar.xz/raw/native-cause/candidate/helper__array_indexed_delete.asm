
/workspace/scriptw/target/performance-dense-numbers-20261030/v2/native-cause/candidate/runtime-portable.elf:     file format elf64-x86-64


Disassembly of section .text:

00000000029dfde0 <wasm[0]::function[1014]::helper::array_indexed_delete>:
 29dfde0:	push   %rbp
 29dfde1:	mov    %rsp,%rbp
 29dfde4:	mov    0x8(%rdi),%r10
 29dfde8:	mov    0x18(%r10),%r10
 29dfdec:	add    $0xa0,%r10
 29dfdf3:	cmp    %rsp,%r10
 29dfdf6:	ja     29e0e0b <wasm[0]::function[1014]::helper::array_indexed_delete+0x102b>
 29dfdfc:	sub    $0x90,%rsp
 29dfe03:	mov    %rbx,0x60(%rsp)
 29dfe08:	mov    %r12,0x68(%rsp)
 29dfe0d:	mov    %r13,0x70(%rsp)
 29dfe12:	mov    %r14,0x78(%rsp)
 29dfe17:	mov    %r15,0x80(%rsp)
 29dfe1f:	mov    %rcx,%rbx
 29dfe22:	mov    %edx,(%rsp)
 29dfe25:	mov    0x18(%rdi),%rcx
 29dfe29:	mov    (%rcx),%rax
 29dfe2c:	mov    %rcx,0x50(%rsp)
 29dfe31:	mov    0x8(%rdi),%r12
 29dfe35:	mov    %rdi,0x30(%rsp)
 29dfe3a:	mov    0x8(%r12),%rcx
 29dfe3f:	cmp    %rcx,%rax
 29dfe42:	mov    %rcx,0x38(%rsp)
 29dfe47:	jae    29e0d23 <wasm[0]::function[1014]::helper::array_indexed_delete+0xf43>
 29dfe4d:	mov    %rbx,%rcx
 29dfe50:	cmp    0x10a9(%rip),%rcx        # 29e0f00 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1120>
 29dfe57:	jae    29e0e0d <wasm[0]::function[1014]::helper::array_indexed_delete+0x102d>
 29dfe5d:	mov    (%rsp),%eax
 29dfe60:	test   %eax,%eax
 29dfe62:	je     29e0e0f <wasm[0]::function[1014]::helper::array_indexed_delete+0x102f>
 29dfe68:	test   %eax,%eax
 29dfe6a:	je     29e0e11 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1031>
 29dfe70:	mov    0x28(%r12),%rdx
 29dfe75:	mov    0x20(%r12),%rsi
 29dfe7a:	mov    %eax,%edi
 29dfe7c:	xor    %rax,%rax
 29dfe7f:	add    %rdi,%rsi
 29dfe82:	cmp    %rdx,%rdi
 29dfe85:	cmova  %rax,%rsi
 29dfe89:	mov    0x24(%rsi),%eax
 29dfe8c:	cmp    $0x3,%eax
 29dfe8f:	sete   %dl
 29dfe92:	cmp    $0x3,%eax
 29dfe95:	je     29e0164 <wasm[0]::function[1014]::helper::array_indexed_delete+0x384>
 29dfe9b:	mov    (%rsp),%eax
 29dfe9e:	test   %eax,%eax
 29dfea0:	je     29e0e13 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1033>
 29dfea6:	test   %eax,%eax
 29dfea8:	je     29e0e15 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1035>
 29dfeae:	mov    0x28(%r12),%rdx
 29dfeb3:	mov    0x20(%r12),%rdi
 29dfeb8:	mov    %eax,%esi
 29dfeba:	lea    (%rdi,%rsi,1),%rax
 29dfebe:	xor    %rdi,%rdi
 29dfec1:	cmp    %rdx,%rsi
 29dfec4:	cmova  %rdi,%rax
 29dfec8:	mov    0x24(%rax),%eax
 29dfecb:	cmp    $0x2,%eax
 29dfece:	sete   %dl
 29dfed1:	mov    %rdx,0x48(%rsp)
 29dfed6:	cmp    $0x2,%eax
 29dfed9:	je     29dfee9 <wasm[0]::function[1014]::helper::array_indexed_delete+0x109>
 29dfedf:	mov    0x48(%rsp),%rax
 29dfee4:	jmp    29e015c <wasm[0]::function[1014]::helper::array_indexed_delete+0x37c>
 29dfee9:	mov    (%rsp),%esi
 29dfeec:	test   %esi,%esi
 29dfeee:	je     29e0e17 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1037>
 29dfef4:	test   %esi,%esi
 29dfef6:	je     29e0e19 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1039>
 29dfefc:	mov    0x28(%r12),%rax
 29dff01:	mov    0x20(%r12),%r9
 29dff06:	mov    %esi,%edx
 29dff08:	lea    (%r9,%rdx,1),%rdi
 29dff0c:	xor    %r10,%r10
 29dff0f:	cmp    %rax,%rdx
 29dff12:	cmova  %r10,%rdi
 29dff16:	mov    0x28(%rdi),%esi
 29dff19:	mov    0x2c(%rdi),%r8d
 29dff1d:	test   %esi,%esi
 29dff1f:	je     29e0e1b <wasm[0]::function[1014]::helper::array_indexed_delete+0x103b>
 29dff25:	test   %esi,%esi
 29dff27:	je     29e0e1d <wasm[0]::function[1014]::helper::array_indexed_delete+0x103d>
 29dff2d:	mov    %esi,%edi
 29dff2f:	lea    0x10(%r9,%rdi,1),%rdx
 29dff34:	cmp    %rax,%rdi
 29dff37:	cmova  %r10,%rdx
 29dff3b:	mov    (%rdx),%eax
 29dff3d:	cmp    %rax,%rcx
 29dff40:	jae    29e0157 <wasm[0]::function[1014]::helper::array_indexed_delete+0x377>
 29dff46:	test   %r8d,%r8d
 29dff49:	je     29e0e1f <wasm[0]::function[1014]::helper::array_indexed_delete+0x103f>
 29dff4f:	test   %r8d,%r8d
 29dff52:	je     29e0e21 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1041>
 29dff58:	mov    0x28(%r12),%rax
 29dff5d:	mov    0x20(%r12),%r9
 29dff62:	mov    %r8d,%r13d
 29dff65:	lea    0x10(%r9,%r13,1),%r11
 29dff6a:	xor    %r10,%r10
 29dff6d:	cmp    %rax,%r13
 29dff70:	cmova  %r10,%r11
 29dff74:	mov    (%r11),%r11d
 29dff77:	mov    %rcx,%r15
 29dff7a:	shr    $0x6,%r15d
 29dff7e:	cmp    %r11d,%r15d
 29dff81:	jae    29e0e23 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1043>
 29dff87:	mov    %r11d,%edx
 29dff8a:	shl    $0x3,%rdx
 29dff8e:	shr    $0x20,%rdx
 29dff92:	test   %rdx,%rdx
 29dff95:	jne    29e0e25 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1045>
 29dff9b:	shl    $0x3,%r11d
 29dff9f:	add    $0x18,%r11d
 29dffa3:	jb     29e0e27 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1047>
 29dffa9:	mov    %r8,%rdx
 29dffac:	add    %r11d,%edx
 29dffaf:	jb     29e0e29 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1049>
 29dffb5:	mov    %edx,%edx
 29dffb7:	add    %rdx,%r9
 29dffba:	cmp    %rax,%rdx
 29dffbd:	cmova  %r10,%r9
 29dffc1:	mov    %r15,%r14
 29dffc4:	shl    $0x3,%r14d
 29dffc8:	lea    0x18(%r14),%r10d
 29dffcc:	sub    %r10d,%r11d
 29dffcf:	sub    %r11,%r9
 29dffd2:	mov    (%r9),%rbx
 29dffd5:	mov    $0x1,%eax
 29dffda:	shl    %cl,%rax
 29dffdd:	bt     %rcx,%rbx
 29dffe1:	jae    29e0157 <wasm[0]::function[1014]::helper::array_indexed_delete+0x377>
 29dffe7:	mov    0x28(%r12),%r10
 29dffec:	mov    0x20(%r12),%r9
 29dfff1:	lea    0x10(%r9,%r13,1),%rdx
 29dfff6:	xor    %r11,%r11
 29dfff9:	cmp    %r10,%r13
 29dfffc:	cmova  %r11,%rdx
 29e0000:	mov    (%rdx),%r13d
 29e0003:	cmp    %r13d,%r15d
 29e0006:	jae    29e0e2b <wasm[0]::function[1014]::helper::array_indexed_delete+0x104b>
 29e000c:	mov    %r13d,%edx
 29e000f:	shl    $0x3,%rdx
 29e0013:	shr    $0x20,%rdx
 29e0017:	test   %rdx,%rdx
 29e001a:	jne    29e0e2d <wasm[0]::function[1014]::helper::array_indexed_delete+0x104d>
 29e0020:	shl    $0x3,%r13d
 29e0024:	add    $0x18,%r13d
 29e0028:	jb     29e0e2f <wasm[0]::function[1014]::helper::array_indexed_delete+0x104f>
 29e002e:	add    %r13d,%r8d
 29e0031:	jb     29e0e31 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1051>
 29e0037:	not    %rax
 29e003a:	and    %rax,%rbx
 29e003d:	mov    %r8d,%edx
 29e0040:	lea    (%r9,%rdx,1),%rax
 29e0044:	cmp    %r10,%rdx
 29e0047:	cmova  %r11,%rax
 29e004b:	lea    0x18(%r14),%edx
 29e004f:	sub    %edx,%r13d
 29e0052:	sub    %r13,%rax
 29e0055:	mov    %rbx,(%rax)
 29e0058:	lea    0x10(%r9,%rdi,1),%rax
 29e005d:	cmp    %r10,%rdi
 29e0060:	cmova  %r11,%rax
 29e0064:	mov    (%rax),%r8d
 29e0067:	cmp    %r8d,%ecx
 29e006a:	jae    29e0e33 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1053>
 29e0070:	mov    %r8d,%eax
 29e0073:	shl    $0x3,%rax
 29e0077:	shr    $0x20,%rax
 29e007b:	test   %rax,%rax
 29e007e:	jne    29e0e35 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1055>
 29e0084:	shl    $0x3,%r8d
 29e0088:	add    $0x18,%r8d
 29e008c:	jb     29e0e37 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1057>
 29e0092:	add    %r8d,%esi
 29e0095:	jb     29e0e39 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1059>
 29e009b:	mov    %esi,%edx
 29e009d:	lea    (%r9,%rdx,1),%rax
 29e00a1:	cmp    %r10,%rdx
 29e00a4:	cmova  %r11,%rax
 29e00a8:	mov    %rcx,%rdx
 29e00ab:	shl    $0x3,%edx
 29e00ae:	add    $0x18,%edx
 29e00b4:	sub    %edx,%r8d
 29e00b7:	sub    %r8,%rax
 29e00ba:	movq   $0x0,(%rax)
 29e00c1:	mov    (%rsp),%eax
 29e00c4:	test   %eax,%eax
 29e00c6:	je     29e0e3b <wasm[0]::function[1014]::helper::array_indexed_delete+0x105b>
 29e00cc:	test   %eax,%eax
 29e00ce:	je     29e0e3d <wasm[0]::function[1014]::helper::array_indexed_delete+0x105d>
 29e00d4:	mov    %eax,%edx
 29e00d6:	lea    (%r9,%rdx,1),%rax
 29e00da:	cmp    %r10,%rdx
 29e00dd:	cmova  %r11,%rax
 29e00e1:	mov    0x18(%rax),%rdx
 29e00e5:	mov    %rdx,%rsi
 29e00e8:	sub    $0x1,%rsi
 29e00ec:	mov    %rsi,0x18(%rax)
 29e00f0:	cmp    $0x1,%rdx
 29e00f4:	jne    29e0157 <wasm[0]::function[1014]::helper::array_indexed_delete+0x377>
 29e00fa:	mov    0x30(%rsp),%r15
 29e00ff:	mov    0xa00(%r15),%esi
 29e0106:	mov    0xa10(%r15),%eax
 29e010d:	mov    (%rsp),%edi
 29e0110:	test   %edi,%edi
 29e0112:	je     29e0e3f <wasm[0]::function[1014]::helper::array_indexed_delete+0x105f>
 29e0118:	test   %esi,%esi
 29e011a:	je     29e0e41 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1061>
 29e0120:	test   %edi,%edi
 29e0122:	je     29e0e43 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1063>
 29e0128:	mov    0x28(%r12),%r8
 29e012d:	mov    0x20(%r12),%r9
 29e0132:	mov    %edi,%edx
 29e0134:	lea    (%r9,%rdx,1),%rdi
 29e0138:	xor    %r9,%r9
 29e013b:	cmp    %r8,%rdx
 29e013e:	cmova  %r9,%rdi
 29e0142:	mov    %esi,0x28(%rdi)
 29e0145:	test   %eax,%eax
 29e0147:	je     29e0e45 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1065>
 29e014d:	mov    %eax,0x2c(%rdi)
 29e0150:	movl   $0x0,0x30(%rdi)
 29e0157:	mov    0x48(%rsp),%rax
 29e015c:	movzbl %al,%eax
 29e015f:	jmp    29e0345 <wasm[0]::function[1014]::helper::array_indexed_delete+0x565>
 29e0164:	mov    (%rsp),%esi
 29e0167:	test   %esi,%esi
 29e0169:	je     29e0e47 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1067>
 29e016f:	test   %esi,%esi
 29e0171:	je     29e0e49 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1069>
 29e0177:	mov    0x28(%r12),%rax
 29e017c:	mov    0x20(%r12),%r8
 29e0181:	mov    %esi,%edi
 29e0183:	lea    (%r8,%rdi,1),%rsi
 29e0187:	xor    %r9,%r9
 29e018a:	cmp    %rax,%rdi
 29e018d:	cmova  %r9,%rsi
 29e0191:	mov    0x30(%rsi),%esi
 29e0194:	test   %esi,%esi
 29e0196:	je     29e0e4b <wasm[0]::function[1014]::helper::array_indexed_delete+0x106b>
 29e019c:	test   %esi,%esi
 29e019e:	je     29e0e4d <wasm[0]::function[1014]::helper::array_indexed_delete+0x106d>
 29e01a4:	mov    %esi,%edi
 29e01a6:	lea    0x10(%r8,%rdi,1),%r8
 29e01ab:	cmp    %rax,%rdi
 29e01ae:	cmova  %r9,%r8
 29e01b2:	mov    (%r8),%r8d
 29e01b5:	cmp    %r8,%rcx
 29e01b8:	jae    29e0342 <wasm[0]::function[1014]::helper::array_indexed_delete+0x562>
 29e01be:	mov    0x28(%r12),%r8
 29e01c3:	mov    0x20(%r12),%r11
 29e01c8:	lea    0x10(%r11,%rdi,1),%r10
 29e01cd:	xor    %r9,%r9
 29e01d0:	cmp    %r8,%rdi
 29e01d3:	cmova  %r9,%r10
 29e01d7:	mov    (%r10),%r10d
 29e01da:	cmp    %r10d,%ecx
 29e01dd:	jae    29e0e4f <wasm[0]::function[1014]::helper::array_indexed_delete+0x106f>
 29e01e3:	mov    %r10d,%eax
 29e01e6:	shl    $0x2,%rax
 29e01ea:	shr    $0x20,%rax
 29e01ee:	test   %rax,%rax
 29e01f1:	jne    29e0e51 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1071>
 29e01f7:	shl    $0x2,%r10d
 29e01fb:	add    $0x14,%r10d
 29e01ff:	jb     29e0e53 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1073>
 29e0205:	mov    %rsi,%rax
 29e0208:	add    %r10d,%eax
 29e020b:	jb     29e0e55 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1075>
 29e0211:	mov    %eax,%eax
 29e0213:	add    %rax,%r11
 29e0216:	cmp    %r8,%rax
 29e0219:	cmova  %r9,%r11
 29e021d:	mov    %rcx,%rax
 29e0220:	shl    $0x2,%eax
 29e0223:	lea    0x14(%rax),%r8d
 29e0227:	sub    %r8d,%r10d
 29e022a:	sub    %r10,%r11
 29e022d:	mov    (%r11),%r8d
 29e0230:	test   %r8d,%r8d
 29e0233:	je     29e0342 <wasm[0]::function[1014]::helper::array_indexed_delete+0x562>
 29e0239:	mov    0x28(%r12),%r8
 29e023e:	mov    0x20(%r12),%r10
 29e0243:	lea    0x10(%r10,%rdi,1),%r11
 29e0248:	xor    %r9,%r9
 29e024b:	cmp    %r8,%rdi
 29e024e:	cmova  %r9,%r11
 29e0252:	mov    (%r11),%edi
 29e0255:	cmp    %edi,%ecx
 29e0257:	jae    29e0e57 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1077>
 29e025d:	mov    %edi,%r11d
 29e0260:	shl    $0x2,%r11
 29e0264:	shr    $0x20,%r11
 29e0268:	test   %r11,%r11
 29e026b:	jne    29e0e59 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1079>
 29e0271:	shl    $0x2,%edi
 29e0274:	add    $0x14,%edi
 29e0277:	jb     29e0e5b <wasm[0]::function[1014]::helper::array_indexed_delete+0x107b>
 29e027d:	add    %edi,%esi
 29e027f:	jb     29e0e5d <wasm[0]::function[1014]::helper::array_indexed_delete+0x107d>
 29e0285:	mov    %esi,%r11d
 29e0288:	lea    (%r10,%r11,1),%rsi
 29e028c:	cmp    %r8,%r11
 29e028f:	cmova  %r9,%rsi
 29e0293:	add    $0x14,%eax
 29e0299:	sub    %eax,%edi
 29e029b:	sub    %rdi,%rsi
 29e029e:	movl   $0x0,(%rsi)
 29e02a4:	mov    (%rsp),%eax
 29e02a7:	test   %eax,%eax
 29e02a9:	je     29e0e5f <wasm[0]::function[1014]::helper::array_indexed_delete+0x107f>
 29e02af:	test   %eax,%eax
 29e02b1:	je     29e0e61 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1081>
 29e02b7:	mov    %eax,%esi
 29e02b9:	lea    (%r10,%rsi,1),%rax
 29e02bd:	cmp    %r8,%rsi
 29e02c0:	cmova  %r9,%rax
 29e02c4:	mov    0x18(%rax),%rsi
 29e02c8:	mov    %rsi,%rdi
 29e02cb:	sub    $0x1,%rdi
 29e02cf:	mov    %rdi,0x18(%rax)
 29e02d3:	cmp    $0x1,%rsi
 29e02d7:	jne    29e0342 <wasm[0]::function[1014]::helper::array_indexed_delete+0x562>
 29e02dd:	mov    0x30(%rsp),%r15
 29e02e2:	mov    0xa00(%r15),%esi
 29e02e9:	mov    0xa10(%r15),%eax
 29e02f0:	mov    (%rsp),%edi
 29e02f3:	test   %edi,%edi
 29e02f5:	je     29e0e63 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1083>
 29e02fb:	test   %esi,%esi
 29e02fd:	je     29e0e65 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1085>
 29e0303:	test   %edi,%edi
 29e0305:	je     29e0e67 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1087>
 29e030b:	mov    0x28(%r12),%r8
 29e0310:	mov    0x20(%r12),%r10
 29e0315:	mov    %edi,%r9d
 29e0318:	lea    (%r10,%r9,1),%rdi
 29e031c:	xor    %r10,%r10
 29e031f:	cmp    %r8,%r9
 29e0322:	cmova  %r10,%rdi
 29e0326:	mov    %esi,0x28(%rdi)
 29e0329:	test   %eax,%eax
 29e032b:	je     29e0e69 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1089>
 29e0331:	mov    %eax,0x2c(%rdi)
 29e0334:	movl   $0x0,0x30(%rdi)
 29e033b:	movl   $0x2,0x24(%rdi)
 29e0342:	movzbl %dl,%eax
 29e0345:	test   %eax,%eax
 29e0347:	jne    29e054c <wasm[0]::function[1014]::helper::array_indexed_delete+0x76c>
 29e034d:	mov    (%rsp),%eax
 29e0350:	test   %eax,%eax
 29e0352:	je     29e0e6b <wasm[0]::function[1014]::helper::array_indexed_delete+0x108b>
 29e0358:	test   %eax,%eax
 29e035a:	je     29e0e6d <wasm[0]::function[1014]::helper::array_indexed_delete+0x108d>
 29e0360:	mov    0x28(%r12),%rdx
 29e0365:	mov    0x20(%r12),%rdi
 29e036a:	mov    %eax,%esi
 29e036c:	lea    (%rdi,%rsi,1),%rax
 29e0370:	xor    %rdi,%rdi
 29e0373:	cmp    %rdx,%rsi
 29e0376:	cmova  %rdi,%rax
 29e037a:	mov    0x24(%rax),%eax
 29e037d:	test   %eax,%eax
 29e037f:	sete   %dl
 29e0382:	test   %eax,%eax
 29e0384:	jne    29e0549 <wasm[0]::function[1014]::helper::array_indexed_delete+0x769>
 29e038a:	mov    (%rsp),%eax
 29e038d:	test   %eax,%eax
 29e038f:	je     29e0e6f <wasm[0]::function[1014]::helper::array_indexed_delete+0x108f>
 29e0395:	test   %eax,%eax
 29e0397:	je     29e0e71 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1091>
 29e039d:	mov    0x28(%r12),%rdi
 29e03a2:	mov    0x20(%r12),%r9
 29e03a7:	mov    %eax,%esi
 29e03a9:	lea    (%r9,%rsi,1),%rax
 29e03ad:	xor    %r10,%r10
 29e03b0:	cmp    %rdi,%rsi
 29e03b3:	cmova  %r10,%rax
 29e03b7:	mov    0x20(%rax),%esi
 29e03ba:	test   %esi,%esi
 29e03bc:	je     29e0e73 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1093>
 29e03c2:	test   %esi,%esi
 29e03c4:	je     29e0e75 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1095>
 29e03ca:	mov    %esi,%r8d
 29e03cd:	lea    0x10(%r9,%r8,1),%r9
 29e03d2:	cmp    %rdi,%r8
 29e03d5:	cmova  %r10,%r9
 29e03d9:	mov    (%r9),%r9d
 29e03dc:	cmp    %r9,%rcx
 29e03df:	jae    29e0549 <wasm[0]::function[1014]::helper::array_indexed_delete+0x769>
 29e03e5:	mov    0x28(%r12),%rax
 29e03ea:	mov    0x20(%r12),%r10
 29e03ef:	lea    0x10(%r10,%r8,1),%r9
 29e03f4:	xor    %rdi,%rdi
 29e03f7:	cmp    %rax,%r8
 29e03fa:	cmova  %rdi,%r9
 29e03fe:	mov    (%r9),%r9d
 29e0401:	cmp    %r9d,%ecx
 29e0404:	jae    29e0e77 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1097>
 29e040a:	mov    %r9d,%r11d
 29e040d:	shl    $0x2,%r11
 29e0411:	shr    $0x20,%r11
 29e0415:	test   %r11,%r11
 29e0418:	jne    29e0e79 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1099>
 29e041e:	shl    $0x2,%r9d
 29e0422:	add    $0x14,%r9d
 29e0426:	jb     29e0e7b <wasm[0]::function[1014]::helper::array_indexed_delete+0x109b>
 29e042c:	mov    %rsi,%r11
 29e042f:	add    %r9d,%r11d
 29e0432:	jb     29e0e7d <wasm[0]::function[1014]::helper::array_indexed_delete+0x109d>
 29e0438:	mov    %r11d,%r11d
 29e043b:	add    %r11,%r10
 29e043e:	cmp    %rax,%r11
 29e0441:	cmova  %rdi,%r10
 29e0445:	mov    %rcx,%rax
 29e0448:	shl    $0x2,%eax
 29e044b:	add    $0x14,%eax
 29e0451:	sub    %eax,%r9d
 29e0454:	sub    %r9,%r10
 29e0457:	mov    (%r10),%edi
 29e045a:	test   %edi,%edi
 29e045c:	je     29e0549 <wasm[0]::function[1014]::helper::array_indexed_delete+0x769>
 29e0462:	mov    0x28(%r12),%rdi
 29e0467:	mov    0x20(%r12),%r10
 29e046c:	lea    0x10(%r10,%r8,1),%r11
 29e0471:	xor    %r9,%r9
 29e0474:	cmp    %rdi,%r8
 29e0477:	cmova  %r9,%r11
 29e047b:	mov    (%r11),%r8d
 29e047e:	cmp    %r8d,%ecx
 29e0481:	jae    29e0e7f <wasm[0]::function[1014]::helper::array_indexed_delete+0x109f>
 29e0487:	mov    %r8d,%r11d
 29e048a:	shl    $0x2,%r11
 29e048e:	shr    $0x20,%r11
 29e0492:	test   %r11,%r11
 29e0495:	jne    29e0e81 <wasm[0]::function[1014]::helper::array_indexed_delete+0x10a1>
 29e049b:	shl    $0x2,%r8d
 29e049f:	add    $0x14,%r8d
 29e04a3:	jb     29e0e83 <wasm[0]::function[1014]::helper::array_indexed_delete+0x10a3>
 29e04a9:	add    %r8d,%esi
 29e04ac:	jb     29e0e85 <wasm[0]::function[1014]::helper::array_indexed_delete+0x10a5>
 29e04b2:	mov    %esi,%r11d
 29e04b5:	lea    (%r10,%r11,1),%rsi
 29e04b9:	cmp    %rdi,%r11
 29e04bc:	cmova  %r9,%rsi
 29e04c0:	sub    %eax,%r8d
 29e04c3:	sub    %r8,%rsi
 29e04c6:	movl   $0x0,(%rsi)
 29e04cc:	mov    (%rsp),%eax
 29e04cf:	test   %eax,%eax
 29e04d1:	je     29e0e87 <wasm[0]::function[1014]::helper::array_indexed_delete+0x10a7>
 29e04d7:	test   %eax,%eax
 29e04d9:	je     29e0e89 <wasm[0]::function[1014]::helper::array_indexed_delete+0x10a9>
 29e04df:	mov    %eax,%esi
 29e04e1:	lea    (%r10,%rsi,1),%rax
 29e04e5:	cmp    %rdi,%rsi
 29e04e8:	cmova  %r9,%rax
 29e04ec:	mov    0x18(%rax),%rsi
 29e04f0:	mov    %rsi,%rdi
 29e04f3:	sub    $0x1,%rdi
 29e04f7:	mov    %rdi,0x18(%rax)
 29e04fb:	cmp    $0x1,%rsi
 29e04ff:	jne    29e0549 <wasm[0]::function[1014]::helper::array_indexed_delete+0x769>
 29e0505:	mov    0x30(%rsp),%r15
 29e050a:	mov    0x9f0(%r15),%eax
 29e0511:	mov    (%rsp),%esi
 29e0514:	test   %esi,%esi
 29e0516:	je     29e0e8b <wasm[0]::function[1014]::helper::array_indexed_delete+0x10ab>
 29e051c:	test   %eax,%eax
 29e051e:	je     29e0e8d <wasm[0]::function[1014]::helper::array_indexed_delete+0x10ad>
 29e0524:	test   %esi,%esi
 29e0526:	je     29e0e8f <wasm[0]::function[1014]::helper::array_indexed_delete+0x10af>
 29e052c:	mov    0x28(%r12),%rdi
 29e0531:	mov    %esi,%r8d
 29e0534:	mov    %r8,%rsi
 29e0537:	add    0x20(%r12),%rsi
 29e053c:	xor    %r9,%r9
 29e053f:	cmp    %rdi,%r8
 29e0542:	cmova  %r9,%rsi
 29e0546:	mov    %eax,0x20(%rsi)
 29e0549:	movzbl %dl,%eax
 29e054c:	test   %eax,%eax
 29e054e:	jne    29e0cfb <wasm[0]::function[1014]::helper::array_indexed_delete+0xf1b>
 29e0554:	mov    (%rsp),%esi
 29e0557:	test   %esi,%esi
 29e0559:	je     29e0e91 <wasm[0]::function[1014]::helper::array_indexed_delete+0x10b1>
 29e055f:	test   %esi,%esi
 29e0561:	je     29e0e93 <wasm[0]::function[1014]::helper::array_indexed_delete+0x10b3>
 29e0567:	mov    0x28(%r12),%rax
 29e056c:	mov    0x20(%r12),%rdx
 29e0571:	mov    %esi,%r8d
 29e0574:	lea    (%rdx,%r8,1),%rdi
 29e0578:	xor    %rsi,%rsi
 29e057b:	cmp    %rax,%r8
 29e057e:	cmova  %rsi,%rdi
 29e0582:	mov    0x10(%rdi),%edi
 29e0585:	mov    %edi,0x20(%rsp)
 29e0589:	test   %edi,%edi
 29e058b:	je     29e0e95 <wasm[0]::function[1014]::helper::array_indexed_delete+0x10b5>
 29e0591:	test   %edi,%edi
 29e0593:	je     29e0e97 <wasm[0]::function[1014]::helper::array_indexed_delete+0x10b7>
 29e0599:	mov    %edi,%r8d
 29e059c:	lea    0x10(%rdx,%r8,1),%rdi
 29e05a1:	cmp    %rax,%r8
 29e05a4:	cmova  %rsi,%rdi
 29e05a8:	mov    (%rdi),%eax
 29e05aa:	mov    %rax,%r10
 29e05ad:	test   %r10d,%r10d
 29e05b0:	mov    %r10,0x40(%rsp)
 29e05b5:	je     29e0cfb <wasm[0]::function[1014]::helper::array_indexed_delete+0xf1b>
 29e05bb:	mov    0x20(%rsp),%esi
 29e05bf:	xor    %edx,%edx
 29e05c1:	test   %esi,%esi
 29e05c3:	je     29e0e99 <wasm[0]::function[1014]::helper::array_indexed_delete+0x10b9>
 29e05c9:	test   %esi,%esi
 29e05cb:	je     29e0e9b <wasm[0]::function[1014]::helper::array_indexed_delete+0x10bb>
 29e05d1:	mov    0x28(%r12),%rdi
 29e05d6:	mov    0x20(%r12),%rax
 29e05db:	mov    %esi,%r10d
 29e05de:	lea    0x10(%rax,%r10,1),%r9
 29e05e3:	xor    %r8,%r8
 29e05e6:	cmp    %rdi,%r10
 29e05e9:	cmova  %r8,%r9
 29e05ed:	mov    (%r9),%r9d
 29e05f0:	mov    %rcx,%r10
 29e05f3:	shr    $0x10,%r10d
 29e05f7:	mov    %rcx,%r11
 29e05fa:	xor    %r10d,%r11d
 29e05fd:	mov    %rcx,%rbx
 29e0600:	imul   $0x7feb352d,%r11d,%r11d
 29e0607:	mov    %r11,%rcx
 29e060a:	shr    $0xf,%ecx
 29e060d:	xor    %ecx,%r11d
 29e0610:	imul   $0x846ca68b,%r11d,%r14d
 29e0617:	mov    %r14,%rcx
 29e061a:	shr    $0x10,%ecx
 29e061d:	xor    %ecx,%r14d
 29e0620:	mov    0x40(%rsp),%rcx
 29e0625:	sub    $0x1,%ecx
 29e0628:	and    %ecx,%r14d
 29e062b:	cmp    %r9d,%r14d
 29e062e:	jae    29e0e9d <wasm[0]::function[1014]::helper::array_indexed_delete+0x10bd>
 29e0634:	mov    %r9d,%ecx
 29e0637:	shl    $0x2,%rcx
 29e063b:	shr    $0x20,%rcx
 29e063f:	test   %rcx,%rcx
 29e0642:	jne    29e0e9f <wasm[0]::function[1014]::helper::array_indexed_delete+0x10bf>
 29e0648:	shl    $0x2,%r9d
 29e064c:	add    $0x14,%r9d
 29e0650:	jb     29e0ea1 <wasm[0]::function[1014]::helper::array_indexed_delete+0x10c1>
 29e0656:	add    %r9d,%esi
 29e0659:	jb     29e0ea3 <wasm[0]::function[1014]::helper::array_indexed_delete+0x10c3>
 29e065f:	mov    %esi,%ecx
 29e0661:	add    %rcx,%rax
 29e0664:	cmp    %rdi,%rcx
 29e0667:	cmova  %r8,%rax
 29e066b:	mov    %r14,%r15
 29e066e:	shl    $0x2,%r15d
 29e0672:	lea    0x14(%r15),%ecx
 29e0676:	sub    %ecx,%r9d
 29e0679:	sub    %r9,%rax
 29e067c:	mov    (%rax),%esi
 29e067e:	mov    %esi,0x10(%rsp)
 29e0682:	mov    %edx,0x8(%rsp)
 29e0686:	mov    0x50(%rsp),%rcx
 29e068b:	mov    (%rcx),%rax
 29e068e:	mov    0x38(%rsp),%rcx
 29e0693:	cmp    %rcx,%rax
 29e0696:	jae    29e0d3a <wasm[0]::function[1014]::helper::array_indexed_delete+0xf5a>
 29e069c:	mov    0x10(%rsp),%eax
 29e06a0:	test   %eax,%eax
 29e06a2:	je     29e0cfb <wasm[0]::function[1014]::helper::array_indexed_delete+0xf1b>
 29e06a8:	mov    0x10(%rsp),%ecx
 29e06ac:	test   %ecx,%ecx
 29e06ae:	je     29e0ea5 <wasm[0]::function[1014]::helper::array_indexed_delete+0x10c5>
 29e06b4:	mov    0x28(%r12),%rax
 29e06b9:	mov    %ecx,%edx
 29e06bb:	mov    %rdx,%rcx
 29e06be:	add    0x20(%r12),%rcx
 29e06c3:	xor    %rsi,%rsi
 29e06c6:	cmp    %rax,%rdx
 29e06c9:	cmova  %rsi,%rcx
 29e06cd:	mov    0x10(%rcx),%rax
 29e06d1:	mov    %rbx,%rcx
 29e06d4:	cmp    %rcx,%rax
 29e06d7:	je     29e070d <wasm[0]::function[1014]::helper::array_indexed_delete+0x92d>
 29e06dd:	mov    0x10(%rsp),%edx
 29e06e1:	test   %edx,%edx
 29e06e3:	je     29e0ea7 <wasm[0]::function[1014]::helper::array_indexed_delete+0x10c7>
 29e06e9:	mov    0x28(%r12),%rax
 29e06ee:	mov    %edx,%edi
 29e06f0:	mov    %rdi,%rsi
 29e06f3:	add    0x20(%r12),%rsi
 29e06f8:	xor    %r8,%r8
 29e06fb:	cmp    %rax,%rdi
 29e06fe:	cmova  %r8,%rsi
 29e0702:	mov    0x1c(%rsi),%esi
 29e0705:	mov    %rcx,%rbx
 29e0708:	jmp    29e067e <wasm[0]::function[1014]::helper::array_indexed_delete+0x89e>
 29e070d:	mov    0x10(%rsp),%ecx
 29e0711:	test   %ecx,%ecx
 29e0713:	je     29e0ea9 <wasm[0]::function[1014]::helper::array_indexed_delete+0x10c9>
 29e0719:	mov    0x28(%r12),%rax
 29e071e:	mov    0x20(%r12),%rsi
 29e0723:	mov    %ecx,%edx
 29e0725:	lea    (%rsi,%rdx,1),%rcx
 29e0729:	xor    %rsi,%rsi
 29e072c:	cmp    %rax,%rdx
 29e072f:	cmova  %rsi,%rcx
 29e0733:	mov    0x1c(%rcx),%ecx
 29e0736:	mov    0x8(%rsp),%eax
 29e073a:	test   %eax,%eax
 29e073c:	je     29e076f <wasm[0]::function[1014]::helper::array_indexed_delete+0x98f>
 29e0742:	mov    0x8(%rsp),%edx
 29e0746:	test   %edx,%edx
 29e0748:	je     29e0eab <wasm[0]::function[1014]::helper::array_indexed_delete+0x10cb>
 29e074e:	mov    0x28(%r12),%rax
 29e0753:	mov    %edx,%esi
 29e0755:	mov    %rsi,%rdx
 29e0758:	add    0x20(%r12),%rdx
 29e075d:	xor    %rdi,%rdi
 29e0760:	cmp    %rax,%rsi
 29e0763:	cmova  %rdi,%rdx
 29e0767:	mov    %ecx,0x1c(%rdx)
 29e076a:	jmp    29e07f0 <wasm[0]::function[1014]::helper::array_indexed_delete+0xa10>
 29e076f:	mov    0x20(%rsp),%eax
 29e0773:	test   %eax,%eax
 29e0775:	je     29e0ead <wasm[0]::function[1014]::helper::array_indexed_delete+0x10cd>
 29e077b:	test   %eax,%eax
 29e077d:	je     29e0eaf <wasm[0]::function[1014]::helper::array_indexed_delete+0x10cf>
 29e0783:	mov    0x28(%r12),%rdx
 29e0788:	mov    0x20(%r12),%rsi
 29e078d:	mov    %eax,%r9d
 29e0790:	lea    0x10(%rsi,%r9,1),%r8
 29e0795:	xor    %rdi,%rdi
 29e0798:	cmp    %rdx,%r9
 29e079b:	cmova  %rdi,%r8
 29e079f:	mov    (%r8),%r8d
 29e07a2:	cmp    %r8d,%r14d
 29e07a5:	jae    29e0eb1 <wasm[0]::function[1014]::helper::array_indexed_delete+0x10d1>
 29e07ab:	mov    %r8d,%r9d
 29e07ae:	shl    $0x2,%r9
 29e07b2:	shr    $0x20,%r9
 29e07b6:	test   %r9,%r9
 29e07b9:	jne    29e0eb3 <wasm[0]::function[1014]::helper::array_indexed_delete+0x10d3>
 29e07bf:	shl    $0x2,%r8d
 29e07c3:	add    $0x14,%r8d
 29e07c7:	jb     29e0eb5 <wasm[0]::function[1014]::helper::array_indexed_delete+0x10d5>
 29e07cd:	add    %r8d,%eax
 29e07d0:	jb     29e0eb7 <wasm[0]::function[1014]::helper::array_indexed_delete+0x10d7>
 29e07d6:	mov    %eax,%r9d
 29e07d9:	lea    (%rsi,%r9,1),%rax
 29e07dd:	cmp    %rdx,%r9
 29e07e0:	cmova  %rdi,%rax
 29e07e4:	lea    0x14(%r15),%edx
 29e07e8:	sub    %edx,%r8d
 29e07eb:	sub    %r8,%rax
 29e07ee:	mov    %ecx,(%rax)
 29e07f0:	mov    (%rsp),%esi
 29e07f3:	test   %esi,%esi
 29e07f5:	je     29e0eb9 <wasm[0]::function[1014]::helper::array_indexed_delete+0x10d9>
 29e07fb:	test   %esi,%esi
 29e07fd:	je     29e0ebb <wasm[0]::function[1014]::helper::array_indexed_delete+0x10db>
 29e0803:	mov    0x28(%r12),%r8
 29e0808:	mov    0x20(%r12),%rdi
 29e080d:	mov    %esi,%r9d
 29e0810:	add    %r9,%rdi
 29e0813:	xor    %r10,%r10
 29e0816:	cmp    %r8,%r9
 29e0819:	cmova  %r10,%rdi
 29e081d:	mov    0x18(%rdi),%rsi
 29e0821:	mov    %rsi,%r8
 29e0824:	sub    $0x1,%r8
 29e0828:	mov    %r8,0x18(%rdi)
 29e082c:	cmp    $0x1,%rsi
 29e0830:	je     29e0cb8 <wasm[0]::function[1014]::helper::array_indexed_delete+0xed8>
 29e0836:	mov    0x40(%rsp),%rax
 29e083b:	cmp    $0x8,%eax
 29e083e:	seta   %al
 29e0841:	sub    $0x1,%rsi
 29e0845:	shl    $0x2,%rsi
 29e0849:	mov    0x40(%rsp),%rdx
 29e084e:	mov    %edx,%ecx
 29e0850:	cmp    %rcx,%rsi
 29e0853:	setb   %cl
 29e0856:	test   %al,%cl
 29e0858:	je     29e0cfb <wasm[0]::function[1014]::helper::array_indexed_delete+0xf1b>
 29e085e:	mov    (%rsp),%eax
 29e0861:	test   %eax,%eax
 29e0863:	je     29e0ebd <wasm[0]::function[1014]::helper::array_indexed_delete+0x10dd>
 29e0869:	test   %eax,%eax
 29e086b:	je     29e0ebf <wasm[0]::function[1014]::helper::array_indexed_delete+0x10df>
 29e0871:	mov    0x28(%r12),%rcx
 29e0876:	mov    %eax,%edx
 29e0878:	mov    %rdx,%rax
 29e087b:	add    0x20(%r12),%rax
 29e0880:	xor    %rsi,%rsi
 29e0883:	cmp    %rcx,%rdx
 29e0886:	cmova  %rsi,%rax
 29e088a:	mov    0x10(%rax),%eax
 29e088d:	mov    %eax,0x20(%rsp)
 29e0891:	mov    0x40(%rsp),%rax
 29e0896:	shr    $1,%eax
 29e0898:	mov    %rax,0x40(%rsp)
 29e089d:	mov    %rax,%r14
 29e08a0:	shl    $0x2,%r14
 29e08a4:	mov    %r14,%rax
 29e08a7:	shr    $0x20,%rax
 29e08ab:	test   %rax,%rax
 29e08ae:	jne    29e0ec1 <wasm[0]::function[1014]::helper::array_indexed_delete+0x10e1>
 29e08b4:	mov    0x40(%rsp),%rax
 29e08b9:	mov    %rax,%rcx
 29e08bc:	shl    $0x2,%ecx
 29e08bf:	add    $0x14,%ecx
 29e08c2:	jb     29e0ec3 <wasm[0]::function[1014]::helper::array_indexed_delete+0x10e3>
 29e08c8:	mov    0x30(%rsp),%r15
 29e08cd:	mov    0x20(%r15),%rsi
 29e08d1:	mov    (%rsi),%eax
 29e08d3:	mov    %eax,%edx
 29e08d5:	mov    %ecx,%edi
 29e08d7:	add    $0xf,%rdi
 29e08de:	mov    %rdi,%r8
 29e08e1:	and    $0xfffffffffffffff0,%r8
 29e08e5:	add    %rdx,%r8
 29e08e8:	mov    0x4(%rsi),%r9d
 29e08ec:	cmp    %r9,%r8
 29e08ef:	ja     29e0d61 <wasm[0]::function[1014]::helper::array_indexed_delete+0xf81>
 29e08f5:	add    $0xf,%ecx
 29e08fb:	and    $0xfffffff0,%ecx
 29e08fe:	add    %eax,%ecx
 29e0900:	mov    %ecx,(%rsi)
 29e0902:	mov    0x20(%r12),%rsi
 29e0907:	lea    (%rsi,%rdx,1),%rcx
 29e090b:	movl   $0xa800000e,(%rsi,%rdx,1)
 29e0912:	mov    0x30(%rsp),%r15
 29e0917:	mov    0x28(%r15),%r8
 29e091b:	mov    0x1ac(%r8),%r8d
 29e0922:	mov    %r8d,0x4(%rsi,%rdx,1)
 29e0927:	and    $0xfffffffffffffff0,%rdi
 29e092b:	mov    %edi,0x8(%rsi,%rdx,1)
 29e092f:	mov    %eax,0x8(%rsp)
 29e0933:	mov    0x40(%rsp),%rsi
 29e0938:	mov    %esi,0x10(%rcx)
 29e093b:	test   %eax,%eax
 29e093d:	je     29e0ec5 <wasm[0]::function[1014]::helper::array_indexed_delete+0x10e5>
 29e0943:	mov    0x28(%r12),%rcx
 29e0948:	mov    0x20(%r12),%rdx
 29e094d:	mov    %eax,%eax
 29e094f:	lea    (%rdx,%rax,1),%rsi
 29e0953:	lea    0x10(%rdx,%rax,1),%rdi
 29e0958:	xor    %r8,%r8
 29e095b:	cmp    %rcx,%rax
 29e095e:	cmova  %r8,%rdi
 29e0962:	mov    (%rdi),%edi
 29e0964:	mov    0x40(%rsp),%r8
 29e0969:	cmp    %rdi,%r8
 29e096c:	ja     29e0ec7 <wasm[0]::function[1014]::helper::array_indexed_delete+0x10e7>
 29e0972:	lea    0x14(%rdx,%rax,1),%rbx
 29e0977:	mov    %rbx,%rdi
 29e097a:	add    %r14,%rdi
 29e097d:	jb     29e0ec9 <wasm[0]::function[1014]::helper::array_indexed_delete+0x10e9>
 29e0983:	lea    (%rdx,%rcx,1),%rax
 29e0987:	cmp    %rax,%rdi
 29e098a:	ja     29e0ecb <wasm[0]::function[1014]::helper::array_indexed_delete+0x10eb>
 29e0990:	mov    0x20(%rsp),%ecx
 29e0994:	mov    (%rsp),%edx
 29e0997:	mov    0x40(%rsp),%rax
 29e099c:	lea    0x14(%rsi,%rax,4),%r14
 29e09a1:	mov    0x40(%rsp),%rsi
 29e09a6:	test   %rsi,%rax
 29e09a9:	je     29e09eb <wasm[0]::function[1014]::helper::array_indexed_delete+0xc0b>
 29e09af:	mov    %ecx,0x10(%rsp)
 29e09b3:	mov    %edx,0x20(%rsp)
 29e09b7:	mov    0x50(%rsp),%rcx
 29e09bc:	mov    (%rcx),%rcx
 29e09bf:	mov    0x38(%rsp),%rax
 29e09c4:	cmp    %rax,%rcx
 29e09c7:	jae    29e0d91 <wasm[0]::function[1014]::helper::array_indexed_delete+0xfb1>
 29e09cd:	movl   $0x0,(%rbx)
 29e09d3:	mov    0x10(%rsp),%ecx
 29e09d7:	mov    0x20(%rsp),%edx
 29e09db:	add    $0x4,%rbx
 29e09e2:	cmp    %r14,%rbx
 29e09e5:	jne    29e09af <wasm[0]::function[1014]::helper::array_indexed_delete+0xbcf>
 29e09eb:	xor    %r14d,%r14d
 29e09ee:	test   %ecx,%ecx
 29e09f0:	je     29e0ecd <wasm[0]::function[1014]::helper::array_indexed_delete+0x10ed>
 29e09f6:	test   %ecx,%ecx
 29e09f8:	je     29e0ecf <wasm[0]::function[1014]::helper::array_indexed_delete+0x10ef>
 29e09fe:	mov    0x28(%r12),%rsi
 29e0a03:	mov    0x20(%r12),%r8
 29e0a08:	mov    %ecx,%edi
 29e0a0a:	lea    0x10(%r8,%rdi,1),%rax
 29e0a0f:	xor    %r8,%r8
 29e0a12:	cmp    %rsi,%rdi
 29e0a15:	cmova  %r8,%rax
 29e0a19:	mov    (%rax),%ebx
 29e0a1b:	mov    0x40(%rsp),%r9
 29e0a20:	mov    %rbx,0x48(%rsp)
 29e0a25:	mov    %r9,%r10
 29e0a28:	sub    $0x1,%r10d
 29e0a2c:	mov    %r10,0x40(%rsp)
 29e0a31:	mov    %ecx,0x20(%rsp)
 29e0a35:	mov    %edx,0x10(%rsp)
 29e0a39:	mov    0x50(%rsp),%rcx
 29e0a3e:	mov    (%rcx),%rsi
 29e0a41:	mov    0x38(%rsp),%rax
 29e0a46:	cmp    %rax,%rsi
 29e0a49:	jae    29e0db8 <wasm[0]::function[1014]::helper::array_indexed_delete+0xfd8>
 29e0a4f:	mov    0x48(%rsp),%rbx
 29e0a54:	jmp    29e0a5e <wasm[0]::function[1014]::helper::array_indexed_delete+0xc7e>
 29e0a59:	mov    0x48(%rsp),%rbx
 29e0a5e:	cmp    %ebx,%r14d
 29e0a61:	mov    %rbx,0x48(%rsp)
 29e0a66:	jae    29e0c76 <wasm[0]::function[1014]::helper::array_indexed_delete+0xe96>
 29e0a6c:	mov    0x20(%rsp),%ecx
 29e0a70:	test   %ecx,%ecx
 29e0a72:	je     29e0ed1 <wasm[0]::function[1014]::helper::array_indexed_delete+0x10f1>
 29e0a78:	test   %ecx,%ecx
 29e0a7a:	je     29e0ed3 <wasm[0]::function[1014]::helper::array_indexed_delete+0x10f3>
 29e0a80:	mov    0x28(%r12),%rax
 29e0a85:	mov    0x20(%r12),%rdx
 29e0a8a:	mov    %ecx,%r8d
 29e0a8d:	lea    0x10(%rdx,%r8,1),%rdi
 29e0a92:	xor    %rsi,%rsi
 29e0a95:	cmp    %rax,%r8
 29e0a98:	cmova  %rsi,%rdi
 29e0a9c:	mov    (%rdi),%r8d
 29e0a9f:	cmp    %r8d,%r14d
 29e0aa2:	jae    29e0ed5 <wasm[0]::function[1014]::helper::array_indexed_delete+0x10f5>
 29e0aa8:	mov    %r8d,%edi
 29e0aab:	shl    $0x2,%rdi
 29e0aaf:	shr    $0x20,%rdi
 29e0ab3:	test   %rdi,%rdi
 29e0ab6:	jne    29e0ed7 <wasm[0]::function[1014]::helper::array_indexed_delete+0x10f7>
 29e0abc:	shl    $0x2,%r8d
 29e0ac0:	add    $0x14,%r8d
 29e0ac4:	jb     29e0ed9 <wasm[0]::function[1014]::helper::array_indexed_delete+0x10f9>
 29e0aca:	mov    %rcx,%rdi
 29e0acd:	add    %r8d,%edi
 29e0ad0:	jb     29e0edb <wasm[0]::function[1014]::helper::array_indexed_delete+0x10fb>
 29e0ad6:	mov    %edi,%edi
 29e0ad8:	add    %rdi,%rdx
 29e0adb:	cmp    %rax,%rdi
 29e0ade:	cmova  %rsi,%rdx
 29e0ae2:	mov    %r14,%rax
 29e0ae5:	shl    $0x2,%eax
 29e0ae8:	add    $0x14,%eax
 29e0aee:	sub    %eax,%r8d
 29e0af1:	sub    %r8,%rdx
 29e0af4:	mov    (%rdx),%r9d
 29e0af7:	mov    0x10(%rsp),%eax
 29e0afb:	mov    %r9d,0x28(%rsp)
 29e0b00:	mov    %ecx,0x18(%rsp)
 29e0b04:	mov    %eax,0x20(%rsp)
 29e0b08:	mov    0x50(%rsp),%rcx
 29e0b0d:	mov    (%rcx),%rax
 29e0b10:	mov    0x38(%rsp),%rcx
 29e0b15:	cmp    %rcx,%rax
 29e0b18:	jae    29e0de4 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1004>
 29e0b1e:	mov    0x28(%rsp),%eax
 29e0b22:	test   %eax,%eax
 29e0b24:	je     29e0c62 <wasm[0]::function[1014]::helper::array_indexed_delete+0xe82>
 29e0b2a:	mov    0x28(%rsp),%ecx
 29e0b2e:	test   %ecx,%ecx
 29e0b30:	je     29e0edd <wasm[0]::function[1014]::helper::array_indexed_delete+0x10fd>
 29e0b36:	mov    0x28(%r12),%rdx
 29e0b3b:	mov    0x20(%r12),%rsi
 29e0b40:	mov    %ecx,%eax
 29e0b42:	lea    (%rsi,%rax,1),%r8
 29e0b46:	xor    %rdi,%rdi
 29e0b49:	cmp    %rdx,%rax
 29e0b4c:	cmova  %rdi,%r8
 29e0b50:	mov    0x1c(%r8),%r9d
 29e0b54:	mov    0x10(%r8),%rbx
 29e0b58:	mov    0x8(%rsp),%r10d
 29e0b5d:	test   %r10d,%r10d
 29e0b60:	je     29e0edf <wasm[0]::function[1014]::helper::array_indexed_delete+0x10ff>
 29e0b66:	test   %r10d,%r10d
 29e0b69:	je     29e0ee1 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1101>
 29e0b6f:	mov    %r10d,%eax
 29e0b72:	lea    0x10(%rsi,%rax,1),%r11
 29e0b77:	cmp    %rdx,%rax
 29e0b7a:	cmova  %rdi,%r11
 29e0b7e:	mov    (%r11),%eax
 29e0b81:	mov    %rbx,%r13
 29e0b84:	shr    $0x10,%r13d
 29e0b88:	xor    %r13d,%ebx
 29e0b8b:	imul   $0x7feb352d,%ebx,%ebx
 29e0b91:	mov    %rbx,%r13
 29e0b94:	shr    $0xf,%r13d
 29e0b98:	xor    %r13d,%ebx
 29e0b9b:	imul   $0x846ca68b,%ebx,%r15d
 29e0ba2:	mov    %r15,%rbx
 29e0ba5:	shr    $0x10,%ebx
 29e0ba8:	xor    %ebx,%r15d
 29e0bab:	mov    0x40(%rsp),%rbx
 29e0bb0:	and    %ebx,%r15d
 29e0bb3:	cmp    %eax,%r15d
 29e0bb6:	jae    29e0ee3 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1103>
 29e0bbc:	mov    %eax,%ebx
 29e0bbe:	shl    $0x2,%rbx
 29e0bc2:	shr    $0x20,%rbx
 29e0bc6:	test   %rbx,%rbx
 29e0bc9:	jne    29e0ee5 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1105>
 29e0bcf:	shl    $0x2,%eax
 29e0bd2:	add    $0x14,%eax
 29e0bd5:	jb     29e0ee7 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1107>
 29e0bdb:	mov    %r10,%rbx
 29e0bde:	add    %eax,%ebx
 29e0be0:	jb     29e0ee9 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1109>
 29e0be6:	mov    %ebx,%ebx
 29e0be8:	lea    (%rsi,%rbx,1),%r13
 29e0bec:	cmp    %rdx,%rbx
 29e0bef:	cmova  %rdi,%r13
 29e0bf3:	mov    %r15,%rbx
 29e0bf6:	shl    $0x2,%ebx
 29e0bf9:	add    $0x14,%ebx
 29e0bff:	sub    %ebx,%eax
 29e0c01:	sub    %rax,%r13
 29e0c04:	mov    0x0(%r13),%eax
 29e0c08:	mov    %eax,0x1c(%r8)
 29e0c0c:	mov    (%r11),%eax
 29e0c0f:	cmp    %eax,%r15d
 29e0c12:	jae    29e0eeb <wasm[0]::function[1014]::helper::array_indexed_delete+0x110b>
 29e0c18:	mov    %eax,%r8d
 29e0c1b:	shl    $0x2,%r8
 29e0c1f:	shr    $0x20,%r8
 29e0c23:	test   %r8,%r8
 29e0c26:	jne    29e0eed <wasm[0]::function[1014]::helper::array_indexed_delete+0x110d>
 29e0c2c:	shl    $0x2,%eax
 29e0c2f:	add    $0x14,%eax
 29e0c32:	jb     29e0eef <wasm[0]::function[1014]::helper::array_indexed_delete+0x110f>
 29e0c38:	add    %eax,%r10d
 29e0c3b:	jb     29e0ef1 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1111>
 29e0c41:	mov    %r10d,%r8d
 29e0c44:	add    %r8,%rsi
 29e0c47:	cmp    %rdx,%r8
 29e0c4a:	cmova  %rdi,%rsi
 29e0c4e:	sub    %ebx,%eax
 29e0c50:	sub    %rax,%rsi
 29e0c53:	mov    %ecx,(%rsi)
 29e0c55:	mov    0x18(%rsp),%ecx
 29e0c59:	mov    0x20(%rsp),%eax
 29e0c5d:	jmp    29e0afb <wasm[0]::function[1014]::helper::array_indexed_delete+0xd1b>
 29e0c62:	mov    0x18(%rsp),%ecx
 29e0c66:	mov    0x20(%rsp),%edx
 29e0c6a:	add    $0x1,%r14d
 29e0c71:	jmp    29e0a31 <wasm[0]::function[1014]::helper::array_indexed_delete+0xc51>
 29e0c76:	mov    0x10(%rsp),%edi
 29e0c7a:	test   %edi,%edi
 29e0c7c:	je     29e0ef3 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1113>
 29e0c82:	mov    0x8(%rsp),%esi
 29e0c86:	test   %esi,%esi
 29e0c88:	je     29e0ef5 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1115>
 29e0c8e:	test   %edi,%edi
 29e0c90:	je     29e0ef7 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1117>
 29e0c96:	mov    0x28(%r12),%r9
 29e0c9b:	mov    %edi,%r10d
 29e0c9e:	mov    %r10,%rdi
 29e0ca1:	add    0x20(%r12),%rdi
 29e0ca6:	xor    %r11,%r11
 29e0ca9:	cmp    %r9,%r10
 29e0cac:	cmova  %r11,%rdi
 29e0cb0:	mov    %esi,0x10(%rdi)
 29e0cb3:	jmp    29e0cfb <wasm[0]::function[1014]::helper::array_indexed_delete+0xf1b>
 29e0cb8:	mov    0x30(%rsp),%r15
 29e0cbd:	mov    0x9e0(%r15),%eax
 29e0cc4:	mov    (%rsp),%ecx
 29e0cc7:	test   %ecx,%ecx
 29e0cc9:	je     29e0ef9 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1119>
 29e0ccf:	test   %eax,%eax
 29e0cd1:	je     29e0efb <wasm[0]::function[1014]::helper::array_indexed_delete+0x111b>
 29e0cd7:	test   %ecx,%ecx
 29e0cd9:	je     29e0efd <wasm[0]::function[1014]::helper::array_indexed_delete+0x111d>
 29e0cdf:	mov    0x28(%r12),%rdx
 29e0ce4:	mov    %ecx,%esi
 29e0ce6:	mov    %rsi,%rcx
 29e0ce9:	add    0x20(%r12),%rcx
 29e0cee:	xor    %rdi,%rdi
 29e0cf1:	cmp    %rdx,%rsi
 29e0cf4:	cmova  %rdi,%rcx
 29e0cf8:	mov    %eax,0x10(%rcx)
 29e0cfb:	mov    0x60(%rsp),%rbx
 29e0d00:	mov    0x68(%rsp),%r12
 29e0d05:	mov    0x70(%rsp),%r13
 29e0d0a:	mov    0x78(%rsp),%r14
 29e0d0f:	mov    0x80(%rsp),%r15
 29e0d17:	add    $0x90,%rsp
 29e0d1e:	mov    %rbp,%rsp
 29e0d21:	pop    %rbp
 29e0d22:	ret
 29e0d23:	mov    0x30(%rsp),%rdi
 29e0d28:	call   3018d19 <wasmtime_builtin_new_epoch>
 29e0d2d:	mov    %rax,0x38(%rsp)
 29e0d32:	mov    %rbx,%rcx
 29e0d35:	jmp    29dfe50 <wasm[0]::function[1014]::helper::array_indexed_delete+0x70>
 29e0d3a:	mov    0x8(%r12),%rcx
 29e0d3f:	mov    %rcx,0x38(%rsp)
 29e0d44:	cmp    %rcx,%rax
 29e0d47:	jb     29e069c <wasm[0]::function[1014]::helper::array_indexed_delete+0x8bc>
 29e0d4d:	mov    0x30(%rsp),%rdi
 29e0d52:	call   3018d19 <wasmtime_builtin_new_epoch>
 29e0d57:	mov    %rax,0x38(%rsp)
 29e0d5c:	jmp    29e069c <wasm[0]::function[1014]::helper::array_indexed_delete+0x8bc>
 29e0d61:	mov    $0xa800000e,%esi
 29e0d66:	mov    0x30(%rsp),%r15
 29e0d6b:	mov    0x28(%r15),%rax
 29e0d6f:	mov    0x1ac(%rax),%edx
 29e0d75:	mov    $0x10,%r8d
 29e0d7b:	mov    0x30(%rsp),%rdi
 29e0d80:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
 29e0d85:	mov    %eax,%ecx
 29e0d87:	add    0x20(%r12),%rcx
 29e0d8c:	jmp    29e092f <wasm[0]::function[1014]::helper::array_indexed_delete+0xb4f>
 29e0d91:	mov    0x8(%r12),%rax
 29e0d96:	mov    %rax,0x38(%rsp)
 29e0d9b:	cmp    %rax,%rcx
 29e0d9e:	jb     29e09cd <wasm[0]::function[1014]::helper::array_indexed_delete+0xbed>
 29e0da4:	mov    0x30(%rsp),%rdi
 29e0da9:	call   3018d19 <wasmtime_builtin_new_epoch>
 29e0dae:	mov    %rax,0x38(%rsp)
 29e0db3:	jmp    29e09cd <wasm[0]::function[1014]::helper::array_indexed_delete+0xbed>
 29e0db8:	mov    0x8(%r12),%rax
 29e0dbd:	mov    %rax,0x38(%rsp)
 29e0dc2:	cmp    %rax,%rsi
 29e0dc5:	jb     29e0a59 <wasm[0]::function[1014]::helper::array_indexed_delete+0xc79>
 29e0dcb:	mov    0x30(%rsp),%rdi
 29e0dd0:	call   3018d19 <wasmtime_builtin_new_epoch>
 29e0dd5:	mov    %rax,0x38(%rsp)
 29e0dda:	mov    0x48(%rsp),%rbx
 29e0ddf:	jmp    29e0a5e <wasm[0]::function[1014]::helper::array_indexed_delete+0xc7e>
 29e0de4:	mov    0x8(%r12),%rcx
 29e0de9:	mov    %rcx,0x38(%rsp)
 29e0dee:	cmp    %rcx,%rax
 29e0df1:	jb     29e0b1e <wasm[0]::function[1014]::helper::array_indexed_delete+0xd3e>
 29e0df7:	mov    0x30(%rsp),%rdi
 29e0dfc:	call   3018d19 <wasmtime_builtin_new_epoch>
 29e0e01:	mov    %rax,0x38(%rsp)
 29e0e06:	jmp    29e0b1e <wasm[0]::function[1014]::helper::array_indexed_delete+0xd3e>
 29e0e0b:	ud2
 29e0e0d:	ud2
 29e0e0f:	ud2
 29e0e11:	ud2
 29e0e13:	ud2
 29e0e15:	ud2
 29e0e17:	ud2
 29e0e19:	ud2
 29e0e1b:	ud2
 29e0e1d:	ud2
 29e0e1f:	ud2
 29e0e21:	ud2
 29e0e23:	ud2
 29e0e25:	ud2
 29e0e27:	ud2
 29e0e29:	ud2
 29e0e2b:	ud2
 29e0e2d:	ud2
 29e0e2f:	ud2
 29e0e31:	ud2
 29e0e33:	ud2
 29e0e35:	ud2
 29e0e37:	ud2
 29e0e39:	ud2
 29e0e3b:	ud2
 29e0e3d:	ud2
 29e0e3f:	ud2
 29e0e41:	ud2
 29e0e43:	ud2
 29e0e45:	ud2
 29e0e47:	ud2
 29e0e49:	ud2
 29e0e4b:	ud2
 29e0e4d:	ud2
 29e0e4f:	ud2
 29e0e51:	ud2
 29e0e53:	ud2
 29e0e55:	ud2
 29e0e57:	ud2
 29e0e59:	ud2
 29e0e5b:	ud2
 29e0e5d:	ud2
 29e0e5f:	ud2
 29e0e61:	ud2
 29e0e63:	ud2
 29e0e65:	ud2
 29e0e67:	ud2
 29e0e69:	ud2
 29e0e6b:	ud2
 29e0e6d:	ud2
 29e0e6f:	ud2
 29e0e71:	ud2
 29e0e73:	ud2
 29e0e75:	ud2
 29e0e77:	ud2
 29e0e79:	ud2
 29e0e7b:	ud2
 29e0e7d:	ud2
 29e0e7f:	ud2
 29e0e81:	ud2
 29e0e83:	ud2
 29e0e85:	ud2
 29e0e87:	ud2
 29e0e89:	ud2
 29e0e8b:	ud2
 29e0e8d:	ud2
 29e0e8f:	ud2
 29e0e91:	ud2
 29e0e93:	ud2
 29e0e95:	ud2
 29e0e97:	ud2
 29e0e99:	ud2
 29e0e9b:	ud2
 29e0e9d:	ud2
 29e0e9f:	ud2
 29e0ea1:	ud2
 29e0ea3:	ud2
 29e0ea5:	ud2
 29e0ea7:	ud2
 29e0ea9:	ud2
 29e0eab:	ud2
 29e0ead:	ud2
 29e0eaf:	ud2
 29e0eb1:	ud2
 29e0eb3:	ud2
 29e0eb5:	ud2
 29e0eb7:	ud2
 29e0eb9:	ud2
 29e0ebb:	ud2
 29e0ebd:	ud2
 29e0ebf:	ud2
 29e0ec1:	ud2
 29e0ec3:	ud2
 29e0ec5:	ud2
 29e0ec7:	ud2
 29e0ec9:	ud2
 29e0ecb:	ud2
 29e0ecd:	ud2
 29e0ecf:	ud2
 29e0ed1:	ud2
 29e0ed3:	ud2
 29e0ed5:	ud2
 29e0ed7:	ud2
 29e0ed9:	ud2
 29e0edb:	ud2
 29e0edd:	ud2
 29e0edf:	ud2
 29e0ee1:	ud2
 29e0ee3:	ud2
 29e0ee5:	ud2
 29e0ee7:	ud2
 29e0ee9:	ud2
 29e0eeb:	ud2
 29e0eed:	ud2
 29e0eef:	ud2
 29e0ef1:	ud2
 29e0ef3:	ud2
 29e0ef5:	ud2
 29e0ef7:	ud2
 29e0ef9:	ud2
 29e0efb:	ud2
 29e0efd:	ud2
 29e0eff:	add    %bh,%bh
 29e0f01:	(bad)
 29e0f02:	(bad)
 29e0f03:	incl   (%rax)
 29e0f05:	add    %al,(%rax)
	...
