
/workspace/scriptw/target/performance-dense-numbers-20261030/v2/native-cause/candidate/runtime-portable.elf:     file format elf64-x86-64


Disassembly of section .text:

00000000029d4760 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data>:
 29d4760:	push   %rbp
 29d4761:	mov    %rsp,%rbp
 29d4764:	mov    0x8(%rdi),%r10
 29d4768:	mov    0x18(%r10),%r10
 29d476c:	add    $0x120,%r10
 29d4773:	cmp    %rsp,%r10
 29d4776:	ja     29d6c70 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2510>
 29d477c:	sub    $0x110,%rsp
 29d4783:	mov    %rbx,0xe0(%rsp)
 29d478b:	mov    %r12,0xe8(%rsp)
 29d4793:	mov    %r13,0xf0(%rsp)
 29d479b:	mov    %r14,0xf8(%rsp)
 29d47a3:	mov    %r15,0x100(%rsp)
 29d47ab:	mov    %rcx,0x68(%rsp)
 29d47b0:	mov    %r8,0x70(%rsp)
 29d47b5:	mov    %r9,0x78(%rsp)
 29d47ba:	mov    0x10(%rbp),%rsi
 29d47be:	mov    %edx,0x8(%rsp)
 29d47c2:	mov    %esi,0x20(%rsp)
 29d47c6:	movl   $0x0,0x28(%rsp)
 29d47ce:	mov    0x18(%rdi),%rax
 29d47d2:	mov    (%rax),%rcx
 29d47d5:	mov    %rax,0xd8(%rsp)
 29d47dd:	mov    0x8(%rdi),%rdx
 29d47e1:	mov    %rdi,0x60(%rsp)
 29d47e6:	mov    0x8(%rdx),%rax
 29d47ea:	mov    %rdx,0xd0(%rsp)
 29d47f2:	cmp    %rax,%rcx
 29d47f5:	jae    29d66db <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1f7b>
 29d47fb:	mov    %rax,0xa0(%rsp)
 29d4803:	mov    0x8(%rsp),%edx
 29d4807:	xor    %r10d,%r10d
 29d480a:	test   %edx,%edx
 29d480c:	je     29d6c72 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2512>
 29d4812:	test   %edx,%edx
 29d4814:	je     29d6c74 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2514>
 29d481a:	mov    0xd0(%rsp),%r12
 29d4822:	mov    0x28(%r12),%rsi
 29d4827:	mov    0x20(%r12),%r8
 29d482c:	mov    %edx,%eax
 29d482e:	xor    %rdi,%rdi
 29d4831:	lea    (%r8,%rax,1),%rcx
 29d4835:	cmp    %rsi,%rax
 29d4838:	cmova  %rdi,%rcx
 29d483c:	mov    0x14(%rcx),%r13d
 29d4840:	test   %r13d,%r13d
 29d4843:	je     29d6c76 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2516>
 29d4849:	test   %r13d,%r13d
 29d484c:	je     29d6c78 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2518>
 29d4852:	mov    %r13d,%eax
 29d4855:	mov    %r13,0x80(%rsp)
 29d485d:	add    %rax,%r8
 29d4860:	cmp    %rsi,%rax
 29d4863:	cmova  %rdi,%r8
 29d4867:	mov    0x24(%r8),%edi
 29d486b:	mov    0x20(%rsp),%esi
 29d486f:	cmp    $0x3,%edi
 29d4872:	sete   %cl
 29d4875:	movzbl %cl,%r13d
 29d4879:	mov    %r13,0x98(%rsp)
 29d4881:	cmp    $0x3,%edi
 29d4884:	jne    29d48af <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x14f>
 29d488a:	mov    0x80(%rsp),%rcx
 29d4892:	mov    0x98(%rsp),%r13
 29d489a:	mov    %r10,0xa8(%rsp)
 29d48a2:	mov    %r12,0xd0(%rsp)
 29d48aa:	jmp    29d5e1f <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x16bf>
 29d48af:	mov    0x28(%r12),%rsi
 29d48b4:	mov    %rax,%rdx
 29d48b7:	add    0x20(%r12),%rdx
 29d48bc:	mov    %r12,0xd0(%rsp)
 29d48c4:	xor    %r12,%r12
 29d48c7:	cmp    %rsi,%rax
 29d48ca:	cmova  %r12,%rdx
 29d48ce:	mov    0x24(%rdx),%r8d
 29d48d2:	mov    0x28(%rsp),%edi
 29d48d6:	mov    0x20(%rsp),%esi
 29d48da:	mov    0x8(%rsp),%edx
 29d48de:	cmp    $0x2,%r8d
 29d48e2:	sete   %r8b
 29d48e6:	mov    0x70(%rsp),%r15
 29d48eb:	cmp    $0x3,%r15d
 29d48ef:	sete   %r9b
 29d48f3:	xor    %r10d,%r10d
 29d48f6:	test   %r8b,%r9b
 29d48f9:	jne    29d4914 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1b4>
 29d48ff:	mov    0x80(%rsp),%rcx
 29d4907:	mov    %r12,0x90(%rsp)
 29d490f:	jmp    29d56ea <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0xf8a>
 29d4914:	mov    0xd0(%rsp),%r12
 29d491c:	mov    0x28(%r12),%rsi
 29d4921:	mov    0x20(%r12),%rdi
 29d4926:	lea    (%rdi,%rax,1),%rdx
 29d492a:	xor    %r12,%r12
 29d492d:	cmp    %rsi,%rax
 29d4930:	cmova  %r12,%rdx
 29d4934:	mov    0x28(%rdx),%r9d
 29d4938:	mov    0x2c(%rdx),%r8d
 29d493c:	xor    %r10d,%r10d
 29d493f:	test   %r9d,%r9d
 29d4942:	je     29d6c7a <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x251a>
 29d4948:	test   %r9d,%r9d
 29d494b:	je     29d6c7c <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x251c>
 29d4951:	mov    %r9d,%r11d
 29d4954:	lea    0x10(%rdi,%r11,1),%rax
 29d4959:	cmp    %rsi,%r11
 29d495c:	cmova  %r12,%rax
 29d4960:	mov    (%rax),%r13d
 29d4963:	mov    0x18(%rdx),%r14
 29d4967:	mov    %r14,0xb8(%rsp)
 29d496f:	mov    0x28(%rsp),%edi
 29d4973:	mov    0x20(%rsp),%esi
 29d4977:	mov    0x8(%rsp),%edx
 29d497b:	mov    %r13d,%r14d
 29d497e:	mov    0x68(%rsp),%rax
 29d4983:	cmp    %r14,%rax
 29d4986:	setb   %r11b
 29d498a:	cmp    $0x100000,%rax
 29d4990:	setb   %bl
 29d4993:	mov    0xb8(%rsp),%r15
 29d499b:	lea    0x8(%r15,%r15,1),%rcx
 29d49a0:	cmp    %rcx,%rax
 29d49a3:	setbe  %r15b
 29d49a7:	and    %r15d,%ebx
 29d49aa:	or     %ebx,%r11d
 29d49ad:	test   %r11b,%r11b
 29d49b0:	jne    29d49d0 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x270>
 29d49b6:	mov    0x80(%rsp),%rcx
 29d49be:	mov    %rax,0x68(%rsp)
 29d49c3:	mov    %r12,0x90(%rsp)
 29d49cb:	jmp    29d56ea <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0xf8a>
 29d49d0:	mov    0x28(%rsp),%edi
 29d49d4:	mov    0x20(%rsp),%esi
 29d49d8:	mov    0x8(%rsp),%edx
 29d49dc:	cmp    %r14,%rax
 29d49df:	mov    %rax,0x68(%rsp)
 29d49e4:	jb     29d54a9 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0xd49>
 29d49ea:	test   %r13d,%r13d
 29d49ed:	jne    29d49f9 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x299>
 29d49f3:	mov    $0x4,%r13d
 29d49f9:	mov    %r9d,0x30(%rsp)
 29d49fe:	mov    %r8d,0x58(%rsp)
 29d4a03:	mov    0x80(%rsp),%rbx
 29d4a0b:	mov    %ebx,(%rsp)
 29d4a0e:	mov    %edi,0x8(%rsp)
 29d4a12:	mov    %esi,0x20(%rsp)
 29d4a16:	mov    %edx,0x28(%rsp)
 29d4a1a:	mov    0xd8(%rsp),%r15
 29d4a22:	mov    (%r15),%r8
 29d4a25:	mov    0xa0(%rsp),%rax
 29d4a2d:	cmp    %rax,%r8
 29d4a30:	jae    29d66f2 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1f92>
 29d4a36:	mov    %r13d,%r12d
 29d4a39:	mov    0x68(%rsp),%rcx
 29d4a3e:	cmp    %r12,%rcx
 29d4a41:	jb     29d4a78 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x318>
 29d4a47:	mov    0x30(%rsp),%r9d
 29d4a4c:	mov    0x58(%rsp),%r8d
 29d4a51:	mov    (%rsp),%ebx
 29d4a54:	mov    0x8(%rsp),%edi
 29d4a58:	mov    0x20(%rsp),%esi
 29d4a5c:	mov    0x28(%rsp),%edx
 29d4a60:	shl    $1,%r13d
 29d4a63:	mov    %rbx,0x80(%rsp)
 29d4a6b:	mov    %r15,0xd8(%rsp)
 29d4a73:	jmp    29d49f9 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x299>
 29d4a78:	mov    %r12,%rcx
 29d4a7b:	shl    $0x3,%rcx
 29d4a7f:	mov    %rcx,%rax
 29d4a82:	shr    $0x20,%rax
 29d4a86:	mov    %rcx,%rbx
 29d4a89:	test   %rax,%rax
 29d4a8c:	jne    29d6c7e <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x251e>
 29d4a92:	mov    %r13,%rcx
 29d4a95:	shl    $0x3,%ecx
 29d4a98:	add    $0x18,%ecx
 29d4a9b:	jb     29d6c80 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2520>
 29d4aa1:	mov    0x60(%rsp),%rax
 29d4aa6:	mov    0x20(%rax),%rdi
 29d4aaa:	mov    (%rdi),%eax
 29d4aac:	mov    %eax,%edx
 29d4aae:	mov    %ecx,%esi
 29d4ab0:	add    $0xf,%rsi
 29d4ab7:	mov    %rsi,%r8
 29d4aba:	and    $0xfffffffffffffff0,%r8
 29d4abe:	add    %rdx,%r8
 29d4ac1:	mov    0x4(%rdi),%r9d
 29d4ac5:	mov    %rdi,0xb0(%rsp)
 29d4acd:	cmp    %r9,%r8
 29d4ad0:	ja     29d6727 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1fc7>
 29d4ad6:	add    $0xf,%ecx
 29d4adc:	and    $0xfffffff0,%ecx
 29d4adf:	lea    (%rax,%rcx,1),%edi
 29d4ae2:	mov    0xb0(%rsp),%rcx
 29d4aea:	mov    %edi,(%rcx)
 29d4aec:	mov    0xd0(%rsp),%rcx
 29d4af4:	mov    0x20(%rcx),%rdi
 29d4af8:	lea    (%rdi,%rdx,1),%rcx
 29d4afc:	movl   $0xa8000006,(%rdi,%rdx,1)
 29d4b03:	mov    0x60(%rsp),%r8
 29d4b08:	mov    0x28(%r8),%r8
 29d4b0c:	mov    0x1a0(%r8),%r8d
 29d4b13:	mov    %r8d,0x4(%rdi,%rdx,1)
 29d4b18:	and    $0xfffffffffffffff0,%rsi
 29d4b1c:	mov    %esi,0x8(%rdi,%rdx,1)
 29d4b20:	mov    %eax,0x10(%rsp)
 29d4b24:	mov    %r13d,0x10(%rcx)
 29d4b28:	test   %eax,%eax
 29d4b2a:	je     29d6c82 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2522>
 29d4b30:	mov    0xd0(%rsp),%rcx
 29d4b38:	mov    0x28(%rcx),%rcx
 29d4b3c:	mov    0xd0(%rsp),%rdx
 29d4b44:	mov    0x20(%rdx),%rdx
 29d4b48:	mov    %eax,%eax
 29d4b4a:	lea    0x10(%rdx,%rax,1),%rsi
 29d4b4f:	xor    %rdi,%rdi
 29d4b52:	cmp    %rcx,%rax
 29d4b55:	cmova  %rdi,%rsi
 29d4b59:	mov    (%rsi),%esi
 29d4b5b:	cmp    %rsi,%r12
 29d4b5e:	ja     29d6c84 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2524>
 29d4b64:	lea    0x18(%rdx,%rax,1),%rsi
 29d4b69:	mov    %rbx,%r9
 29d4b6c:	mov    %rsi,%rax
 29d4b6f:	add    %r9,%rax
 29d4b72:	mov    %rsi,0x88(%rsp)
 29d4b7a:	jb     29d6c86 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2526>
 29d4b80:	add    %rdx,%rcx
 29d4b83:	cmp    %rcx,%rax
 29d4b86:	ja     29d6c88 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2528>
 29d4b8c:	mov    0x30(%rsp),%r8d
 29d4b91:	mov    0x58(%rsp),%edi
 29d4b95:	mov    (%rsp),%esi
 29d4b98:	mov    0x8(%rsp),%edx
 29d4b9c:	mov    0x20(%rsp),%ecx
 29d4ba0:	mov    0x28(%rsp),%eax
 29d4ba4:	cmp    $0x8000000,%r9
 29d4bab:	jbe    29d4c42 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x4e2>
 29d4bb1:	mov    %r8d,0x28(%rsp)
 29d4bb6:	mov    %edi,0x20(%rsp)
 29d4bba:	mov    %esi,0x8(%rsp)
 29d4bbe:	mov    %edx,(%rsp)
 29d4bc1:	mov    %ecx,0x58(%rsp)
 29d4bc5:	mov    %eax,0x30(%rsp)
 29d4bc9:	mov    (%r15),%rax
 29d4bcc:	mov    0xa0(%rsp),%rcx
 29d4bd4:	cmp    %rcx,%rax
 29d4bd7:	jae    29d675e <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1ffe>
 29d4bdd:	xor    %edx,%edx
 29d4bdf:	mov    $0x8000000,%ecx
 29d4be4:	mov    0x88(%rsp),%rsi
 29d4bec:	mov    0x60(%rsp),%rdi
 29d4bf1:	call   3018cc3 <wasmtime_builtin_memory_fill>
 29d4bf6:	mov    0x28(%rsp),%r8d
 29d4bfb:	mov    0x20(%rsp),%edi
 29d4bff:	mov    0x8(%rsp),%esi
 29d4c03:	mov    (%rsp),%edx
 29d4c06:	mov    0x58(%rsp),%ecx
 29d4c0a:	mov    0x30(%rsp),%eax
 29d4c0e:	mov    %rbx,%r9
 29d4c11:	sub    $0x8000000,%r9
 29d4c18:	mov    %r9,%rbx
 29d4c1b:	mov    0x88(%rsp),%r9
 29d4c23:	add    $0x8000000,%r9
 29d4c2a:	mov    %r9,0x88(%rsp)
 29d4c32:	mov    %rbx,%r9
 29d4c35:	cmp    $0x8000000,%r9
 29d4c3c:	ja     29d4bb1 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x451>
 29d4c42:	mov    %r8d,0x30(%rsp)
 29d4c47:	mov    %edi,0x58(%rsp)
 29d4c4b:	mov    %esi,(%rsp)
 29d4c4e:	mov    %edx,0x8(%rsp)
 29d4c52:	mov    %ecx,0x20(%rsp)
 29d4c56:	mov    %eax,0x28(%rsp)
 29d4c5a:	mov    (%r15),%rsi
 29d4c5d:	mov    0xa0(%rsp),%rax
 29d4c65:	cmp    %rax,%rsi
 29d4c68:	jae    29d6793 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2033>
 29d4c6e:	xor    %edx,%edx
 29d4c70:	mov    %rbx,%rcx
 29d4c73:	mov    0x88(%rsp),%rsi
 29d4c7b:	mov    0x60(%rsp),%rdi
 29d4c80:	call   3018cc3 <wasmtime_builtin_memory_fill>
 29d4c85:	mov    0x10(%rsp),%edx
 29d4c89:	test   %edx,%edx
 29d4c8b:	je     29d6c8a <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x252a>
 29d4c91:	mov    0x30(%rsp),%esi
 29d4c95:	test   %esi,%esi
 29d4c97:	je     29d6c8c <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x252c>
 29d4c9d:	test   %edx,%edx
 29d4c9f:	je     29d6c8e <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x252e>
 29d4ca5:	mov    0xd0(%rsp),%r12
 29d4cad:	mov    0x28(%r12),%rcx
 29d4cb2:	mov    0x20(%r12),%rax
 29d4cb7:	mov    %edx,%edx
 29d4cb9:	lea    (%rax,%rdx,1),%r9
 29d4cbd:	lea    0x10(%rax,%rdx,1),%r8
 29d4cc2:	xor    %rdi,%rdi
 29d4cc5:	cmp    %rcx,%rdx
 29d4cc8:	cmova  %rdi,%r8
 29d4ccc:	mov    (%r8),%r8d
 29d4ccf:	cmp    %r8,%r14
 29d4cd2:	ja     29d6c90 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2530>
 29d4cd8:	test   %esi,%esi
 29d4cda:	je     29d6c92 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2532>
 29d4ce0:	mov    %esi,%esi
 29d4ce2:	lea    (%rax,%rsi,1),%r10
 29d4ce6:	lea    0x10(%rax,%rsi,1),%r8
 29d4ceb:	cmp    %rcx,%rsi
 29d4cee:	cmova  %rdi,%r8
 29d4cf2:	mov    (%r8),%edi
 29d4cf5:	cmp    %rdi,%r14
 29d4cf8:	ja     29d6c94 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2534>
 29d4cfe:	lea    0x18(%rax,%rdx,1),%rbx
 29d4d03:	mov    %r14,%r11
 29d4d06:	shl    $0x3,%r11
 29d4d0a:	mov    %rbx,%rdx
 29d4d0d:	add    %r11,%rdx
 29d4d10:	jb     29d6c96 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2536>
 29d4d16:	add    %rax,%rcx
 29d4d19:	cmp    %rcx,%rdx
 29d4d1c:	ja     29d6c98 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2538>
 29d4d22:	lea    0x18(%rax,%rsi,1),%r12
 29d4d27:	mov    %r12,%rax
 29d4d2a:	add    %r11,%rax
 29d4d2d:	jb     29d6c9a <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x253a>
 29d4d33:	cmp    %rcx,%rax
 29d4d36:	ja     29d6c9c <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x253c>
 29d4d3c:	cmp    %rbx,%r12
 29d4d3f:	ja     29d4e4e <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x6ee>
 29d4d45:	mov    0x58(%rsp),%eax
 29d4d49:	mov    (%rsp),%ecx
 29d4d4c:	mov    0x10(%rsp),%edx
 29d4d50:	mov    0x8(%rsp),%esi
 29d4d54:	mov    0x20(%rsp),%edi
 29d4d58:	mov    0x28(%rsp),%r8d
 29d4d5d:	lea    0x18(%r9,%r14,8),%rbx
 29d4d62:	mov    %rbx,0x88(%rsp)
 29d4d6a:	lea    0x18(%r10,%r14,8),%r12
 29d4d6f:	mov    %r12,%r14
 29d4d72:	cmp    $0x8000000,%r11
 29d4d79:	mov    %r11,%rbx
 29d4d7c:	ja     29d4d92 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x632>
 29d4d82:	mov    %rbx,%r9
 29d4d85:	mov    0x88(%rsp),%r10
 29d4d8d:	jmp    29d4e32 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x6d2>
 29d4d92:	mov    %eax,0x18(%rsp)
 29d4d96:	mov    %ecx,0x50(%rsp)
 29d4d9a:	mov    %edx,0x48(%rsp)
 29d4d9e:	mov    %esi,0x40(%rsp)
 29d4da2:	mov    %edi,0x38(%rsp)
 29d4da6:	mov    %r8d,0x30(%rsp)
 29d4dab:	mov    (%r15),%rax
 29d4dae:	mov    0xa0(%rsp),%rcx
 29d4db6:	cmp    %rcx,%rax
 29d4db9:	jae    29d67c8 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2068>
 29d4dbf:	mov    $0x8000000,%ecx
 29d4dc4:	mov    0x88(%rsp),%rsi
 29d4dcc:	sub    $0x8000000,%rsi
 29d4dd3:	mov    %r14,%rdx
 29d4dd6:	mov    %rsi,0x88(%rsp)
 29d4dde:	sub    $0x8000000,%rdx
 29d4de5:	mov    %rdx,%r14
 29d4de8:	mov    0x60(%rsp),%rdi
 29d4ded:	call   3018c9a <wasmtime_builtin_memory_copy>
 29d4df2:	mov    0x18(%rsp),%eax
 29d4df6:	mov    0x50(%rsp),%ecx
 29d4dfa:	mov    0x48(%rsp),%edx
 29d4dfe:	mov    0x40(%rsp),%esi
 29d4e02:	mov    0x38(%rsp),%edi
 29d4e06:	mov    0x30(%rsp),%r8d
 29d4e0b:	mov    %rbx,%r9
 29d4e0e:	sub    $0x8000000,%r9
 29d4e15:	cmp    $0x8000000,%r9
 29d4e1c:	jbe    29d4e2a <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x6ca>
 29d4e22:	mov    %r9,%rbx
 29d4e25:	jmp    29d4d92 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x632>
 29d4e2a:	mov    0x88(%rsp),%r10
 29d4e32:	sub    %r9,%r10
 29d4e35:	mov    %r10,0x88(%rsp)
 29d4e3d:	mov    %r14,%r10
 29d4e40:	sub    %r9,%r10
 29d4e43:	mov    %r10,%r14
 29d4e46:	mov    %r9,%rbx
 29d4e49:	jmp    29d4f23 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x7c3>
 29d4e4e:	mov    %r11,%r9
 29d4e51:	mov    %r12,%r14
 29d4e54:	mov    %rbx,0x88(%rsp)
 29d4e5c:	mov    0x58(%rsp),%eax
 29d4e60:	mov    (%rsp),%ecx
 29d4e63:	mov    0x10(%rsp),%edx
 29d4e67:	mov    0x8(%rsp),%esi
 29d4e6b:	mov    0x20(%rsp),%edi
 29d4e6f:	mov    0x28(%rsp),%r8d
 29d4e74:	cmp    $0x8000000,%r9
 29d4e7b:	mov    %r9,%rbx
 29d4e7e:	jbe    29d4f23 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x7c3>
 29d4e84:	mov    %eax,0x28(%rsp)
 29d4e88:	mov    %ecx,0x20(%rsp)
 29d4e8c:	mov    %edx,0x8(%rsp)
 29d4e90:	mov    %esi,0x10(%rsp)
 29d4e94:	mov    %edi,(%rsp)
 29d4e97:	mov    %r8d,0x58(%rsp)
 29d4e9c:	mov    (%r15),%rsi
 29d4e9f:	mov    0xa0(%rsp),%rax
 29d4ea7:	cmp    %rax,%rsi
 29d4eaa:	jae    29d6800 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x20a0>
 29d4eb0:	mov    $0x8000000,%ecx
 29d4eb5:	mov    %r14,%rdx
 29d4eb8:	mov    0x88(%rsp),%rsi
 29d4ec0:	mov    0x60(%rsp),%rdi
 29d4ec5:	call   3018c9a <wasmtime_builtin_memory_copy>
 29d4eca:	mov    0x28(%rsp),%eax
 29d4ece:	mov    0x20(%rsp),%ecx
 29d4ed2:	mov    0x8(%rsp),%edx
 29d4ed6:	mov    0x10(%rsp),%esi
 29d4eda:	mov    (%rsp),%edi
 29d4edd:	mov    0x58(%rsp),%r8d
 29d4ee2:	mov    %rbx,%r9
 29d4ee5:	sub    $0x8000000,%r9
 29d4eec:	mov    %r9,%rbx
 29d4eef:	mov    0x88(%rsp),%r9
 29d4ef7:	add    $0x8000000,%r9
 29d4efe:	mov    %r9,0x88(%rsp)
 29d4f06:	mov    %r14,%r9
 29d4f09:	add    $0x8000000,%r9
 29d4f10:	mov    %r9,%r14
 29d4f13:	mov    %rbx,%r9
 29d4f16:	cmp    $0x8000000,%r9
 29d4f1d:	ja     29d4e84 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x724>
 29d4f23:	mov    %eax,0x58(%rsp)
 29d4f27:	mov    %ecx,(%rsp)
 29d4f2a:	mov    %edx,0x10(%rsp)
 29d4f2e:	mov    %esi,0x8(%rsp)
 29d4f32:	mov    %edi,0x20(%rsp)
 29d4f36:	mov    %r8d,0x28(%rsp)
 29d4f3b:	mov    (%r15),%rax
 29d4f3e:	mov    0xa0(%rsp),%rcx
 29d4f46:	cmp    %rcx,%rax
 29d4f49:	jae    29d6835 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x20d5>
 29d4f4f:	mov    %rbx,%rcx
 29d4f52:	mov    %r14,%rdx
 29d4f55:	mov    0x88(%rsp),%rsi
 29d4f5d:	jmp    29d4f70 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x810>
 29d4f62:	mov    %rbx,%rcx
 29d4f65:	mov    %r14,%rdx
 29d4f68:	mov    0x88(%rsp),%rsi
 29d4f70:	mov    %rbx,%rcx
 29d4f73:	mov    %r14,%rdx
 29d4f76:	mov    0x88(%rsp),%rsi
 29d4f7e:	mov    0x60(%rsp),%rdi
 29d4f83:	call   3018c9a <wasmtime_builtin_memory_copy>
 29d4f88:	lea    0x3f(%r13),%ebx
 29d4f8c:	shr    $0x6,%ebx
 29d4f8f:	mov    %rbx,%rcx
 29d4f92:	shl    $0x3,%rcx
 29d4f96:	mov    %rcx,%rax
 29d4f99:	shr    $0x20,%rax
 29d4f9d:	mov    %rcx,%r13
 29d4fa0:	test   %rax,%rax
 29d4fa3:	jne    29d6c9e <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x253e>
 29d4fa9:	mov    %rbx,%rcx
 29d4fac:	shl    $0x3,%ecx
 29d4faf:	add    $0x18,%ecx
 29d4fb2:	jb     29d6ca0 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2540>
 29d4fb8:	mov    0xb0(%rsp),%rdi
 29d4fc0:	mov    (%rdi),%eax
 29d4fc2:	mov    %eax,%edx
 29d4fc4:	mov    %ecx,%esi
 29d4fc6:	add    $0xf,%rsi
 29d4fcd:	and    $0xfffffffffffffff0,%rsi
 29d4fd1:	lea    (%rdx,%rsi,1),%r8
 29d4fd5:	mov    0x4(%rdi),%r9d
 29d4fd9:	cmp    %r9,%r8
 29d4fdc:	ja     29d6878 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2118>
 29d4fe2:	add    $0xf,%ecx
 29d4fe8:	and    $0xfffffff0,%ecx
 29d4feb:	add    %eax,%ecx
 29d4fed:	mov    %ecx,(%rdi)
 29d4fef:	mov    0xd0(%rsp),%r12
 29d4ff7:	mov    0x20(%r12),%rdi
 29d4ffc:	lea    (%rdi,%rdx,1),%rcx
 29d5000:	movl   $0xa8000006,(%rdi,%rdx,1)
 29d5007:	mov    0x60(%rsp),%r8
 29d500c:	mov    0x28(%r8),%r8
 29d5010:	mov    0x1a4(%r8),%r8d
 29d5017:	mov    %r8d,0x4(%rdi,%rdx,1)
 29d501c:	mov    %esi,0x8(%rdi,%rdx,1)
 29d5020:	mov    %eax,0x18(%rsp)
 29d5024:	mov    %ebx,0x10(%rcx)
 29d5027:	test   %eax,%eax
 29d5029:	je     29d6ca2 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2542>
 29d502f:	mov    0xd0(%rsp),%r12
 29d5037:	mov    0x28(%r12),%rcx
 29d503c:	mov    0x20(%r12),%rdx
 29d5041:	mov    %eax,%eax
 29d5043:	lea    0x10(%rdx,%rax,1),%rsi
 29d5048:	xor    %rdi,%rdi
 29d504b:	cmp    %rcx,%rax
 29d504e:	cmova  %rdi,%rsi
 29d5052:	mov    (%rsi),%esi
 29d5054:	cmp    %rsi,%rbx
 29d5057:	ja     29d6ca4 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2544>
 29d505d:	lea    0x18(%rdx,%rax,1),%rsi
 29d5062:	mov    %r13,%r10
 29d5065:	mov    %rsi,%rax
 29d5068:	add    %r10,%rax
 29d506b:	mov    %rsi,%rbx
 29d506e:	jb     29d6ca6 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2546>
 29d5074:	add    %rdx,%rcx
 29d5077:	cmp    %rcx,%rax
 29d507a:	ja     29d6ca8 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2548>
 29d5080:	mov    0x58(%rsp),%r8d
 29d5085:	mov    (%rsp),%esi
 29d5088:	mov    0x10(%rsp),%edi
 29d508c:	mov    0x8(%rsp),%r9d
 29d5091:	mov    0x20(%rsp),%r11d
 29d5096:	mov    0x28(%rsp),%eax
 29d509a:	cmp    $0x8000000,%r10
 29d50a1:	jbe    29d512d <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x9cd>
 29d50a7:	mov    %r8d,0x28(%rsp)
 29d50ac:	mov    %esi,0x20(%rsp)
 29d50b0:	mov    %edi,0x8(%rsp)
 29d50b4:	mov    %r9d,0x10(%rsp)
 29d50b9:	mov    %r11d,(%rsp)
 29d50bd:	mov    %eax,0x58(%rsp)
 29d50c1:	mov    (%r15),%rax
 29d50c4:	mov    0xa0(%rsp),%rcx
 29d50cc:	cmp    %rcx,%rax
 29d50cf:	jae    29d68b0 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2150>
 29d50d5:	xor    %edx,%edx
 29d50d7:	mov    $0x8000000,%ecx
 29d50dc:	mov    %rbx,%rsi
 29d50df:	mov    0x60(%rsp),%rdi
 29d50e4:	call   3018cc3 <wasmtime_builtin_memory_fill>
 29d50e9:	mov    0x28(%rsp),%r8d
 29d50ee:	mov    0x20(%rsp),%esi
 29d50f2:	mov    0x8(%rsp),%edi
 29d50f6:	mov    0x10(%rsp),%r9d
 29d50fb:	mov    (%rsp),%r11d
 29d50ff:	mov    0x58(%rsp),%eax
 29d5103:	mov    %r13,%rcx
 29d5106:	sub    $0x8000000,%rcx
 29d510d:	mov    %rcx,%r13
 29d5110:	mov    %rbx,%rcx
 29d5113:	add    $0x8000000,%rcx
 29d511a:	mov    %rcx,%rbx
 29d511d:	mov    %r13,%rcx
 29d5120:	cmp    $0x8000000,%rcx
 29d5127:	ja     29d50a7 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x947>
 29d512d:	mov    %r8d,0x58(%rsp)
 29d5132:	mov    %esi,(%rsp)
 29d5135:	mov    %edi,0x10(%rsp)
 29d5139:	mov    %r9d,0x8(%rsp)
 29d513e:	mov    %r11d,0x20(%rsp)
 29d5143:	mov    %eax,0x28(%rsp)
 29d5147:	mov    (%r15),%rax
 29d514a:	mov    0xa0(%rsp),%rcx
 29d5152:	cmp    %rcx,%rax
 29d5155:	jae    29d68e5 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2185>
 29d515b:	xor    %edx,%edx
 29d515d:	mov    %r13,%rcx
 29d5160:	mov    %rbx,%rsi
 29d5163:	mov    0x60(%rsp),%rdi
 29d5168:	call   3018cc3 <wasmtime_builtin_memory_fill>
 29d516d:	mov    0x58(%rsp),%ecx
 29d5171:	test   %ecx,%ecx
 29d5173:	je     29d6caa <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x254a>
 29d5179:	test   %ecx,%ecx
 29d517b:	je     29d6cac <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x254c>
 29d5181:	mov    0xd0(%rsp),%r12
 29d5189:	mov    0x28(%r12),%rsi
 29d518e:	mov    0x20(%r12),%rax
 29d5193:	mov    %ecx,%edx
 29d5195:	lea    (%rax,%rdx,1),%rcx
 29d5199:	lea    0x10(%rax,%rdx,1),%r8
 29d519e:	xor    %rdi,%rdi
 29d51a1:	cmp    %rsi,%rdx
 29d51a4:	cmova  %rdi,%r8
 29d51a8:	mov    (%r8),%r8d
 29d51ab:	mov    0x18(%rsp),%r9d
 29d51b0:	test   %r9d,%r9d
 29d51b3:	je     29d6cae <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x254e>
 29d51b9:	test   %r9d,%r9d
 29d51bc:	je     29d6cb0 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2550>
 29d51c2:	mov    %r9d,%r9d
 29d51c5:	lea    (%rax,%r9,1),%r10
 29d51c9:	lea    0x10(%rax,%r9,1),%r11
 29d51ce:	cmp    %rsi,%r9
 29d51d1:	cmova  %rdi,%r11
 29d51d5:	mov    %r8d,%ebx
 29d51d8:	mov    (%r11),%edi
 29d51db:	cmp    %rdi,%rbx
 29d51de:	ja     29d6cb2 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2552>
 29d51e4:	lea    0x18(%rax,%r9,1),%r13
 29d51e9:	mov    %rbx,%r12
 29d51ec:	shl    $0x3,%r12
 29d51f0:	mov    %r13,%rdi
 29d51f3:	add    %r12,%rdi
 29d51f6:	jb     29d6cb4 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2554>
 29d51fc:	add    %rax,%rsi
 29d51ff:	cmp    %rsi,%rdi
 29d5202:	ja     29d6cb6 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2556>
 29d5208:	lea    0x18(%rax,%rdx,1),%rdx
 29d520d:	mov    %rdx,%rax
 29d5210:	add    %r12,%rax
 29d5213:	jb     29d6cb8 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2558>
 29d5219:	cmp    %rsi,%rax
 29d521c:	ja     29d6cba <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x255a>
 29d5222:	cmp    %r13,%rdx
 29d5225:	ja     29d5319 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0xbb9>
 29d522b:	mov    (%rsp),%esi
 29d522e:	mov    0x10(%rsp),%edi
 29d5232:	mov    0x18(%rsp),%r8d
 29d5237:	mov    0x8(%rsp),%r9d
 29d523c:	mov    0x20(%rsp),%r11d
 29d5241:	mov    0x28(%rsp),%eax
 29d5245:	lea    0x18(%r10,%rbx,8),%r13
 29d524a:	lea    0x18(%rcx,%rbx,8),%rdx
 29d524f:	mov    %rdx,%r14
 29d5252:	cmp    $0x8000000,%r12
 29d5259:	mov    %r12,%rbx
 29d525c:	ja     29d526d <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0xb0d>
 29d5262:	mov    %rbx,%rcx
 29d5265:	mov    %r13,%rdx
 29d5268:	jmp    29d5302 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0xba2>
 29d526d:	mov    %esi,0x30(%rsp)
 29d5271:	mov    %edi,0x38(%rsp)
 29d5275:	mov    %r8d,0x40(%rsp)
 29d527a:	mov    %r9d,0x48(%rsp)
 29d527f:	mov    %r11d,0x50(%rsp)
 29d5284:	mov    %eax,0x58(%rsp)
 29d5288:	mov    (%r15),%rax
 29d528b:	mov    0xa0(%rsp),%rcx
 29d5293:	cmp    %rcx,%rax
 29d5296:	jae    29d691a <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x21ba>
 29d529c:	mov    $0x8000000,%ecx
 29d52a1:	mov    %r13,%rsi
 29d52a4:	sub    $0x8000000,%rsi
 29d52ab:	mov    %r14,%rdx
 29d52ae:	mov    %rsi,%r13
 29d52b1:	sub    $0x8000000,%rdx
 29d52b8:	mov    %rdx,%r14
 29d52bb:	mov    0x60(%rsp),%rdi
 29d52c0:	call   3018c9a <wasmtime_builtin_memory_copy>
 29d52c5:	mov    0x30(%rsp),%esi
 29d52c9:	mov    0x38(%rsp),%edi
 29d52cd:	mov    0x40(%rsp),%r8d
 29d52d2:	mov    0x48(%rsp),%r9d
 29d52d7:	mov    0x50(%rsp),%r11d
 29d52dc:	mov    0x58(%rsp),%eax
 29d52e0:	mov    %rbx,%rcx
 29d52e3:	sub    $0x8000000,%rcx
 29d52ea:	cmp    $0x8000000,%rcx
 29d52f1:	jbe    29d52ff <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0xb9f>
 29d52f7:	mov    %rcx,%rbx
 29d52fa:	jmp    29d526d <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0xb0d>
 29d52ff:	mov    %r13,%rdx
 29d5302:	sub    %rcx,%rdx
 29d5305:	mov    %rdx,%r13
 29d5308:	mov    %r14,%rdx
 29d530b:	sub    %rcx,%rdx
 29d530e:	mov    %rdx,%r14
 29d5311:	mov    %rcx,%rbx
 29d5314:	jmp    29d53dd <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0xc7d>
 29d5319:	mov    %r12,%rcx
 29d531c:	mov    %rdx,%r14
 29d531f:	mov    (%rsp),%esi
 29d5322:	mov    0x10(%rsp),%edi
 29d5326:	mov    0x18(%rsp),%r8d
 29d532b:	mov    0x8(%rsp),%r9d
 29d5330:	mov    0x20(%rsp),%r11d
 29d5335:	mov    0x28(%rsp),%eax
 29d5339:	cmp    $0x8000000,%rcx
 29d5340:	mov    %rcx,%rbx
 29d5343:	jbe    29d53dd <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0xc7d>
 29d5349:	mov    %esi,0x28(%rsp)
 29d534d:	mov    %edi,0x20(%rsp)
 29d5351:	mov    %r8d,0x8(%rsp)
 29d5356:	mov    %r9d,0x18(%rsp)
 29d535b:	mov    %r11d,0x10(%rsp)
 29d5360:	mov    %eax,(%rsp)
 29d5363:	mov    (%r15),%rax
 29d5366:	mov    0xa0(%rsp),%rcx
 29d536e:	cmp    %rcx,%rax
 29d5371:	jae    29d694f <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x21ef>
 29d5377:	mov    $0x8000000,%ecx
 29d537c:	mov    %r14,%rdx
 29d537f:	mov    %r13,%rsi
 29d5382:	mov    0x60(%rsp),%rdi
 29d5387:	call   3018c9a <wasmtime_builtin_memory_copy>
 29d538c:	mov    0x28(%rsp),%esi
 29d5390:	mov    0x20(%rsp),%edi
 29d5394:	mov    0x8(%rsp),%r8d
 29d5399:	mov    0x18(%rsp),%r9d
 29d539e:	mov    0x10(%rsp),%r11d
 29d53a3:	mov    (%rsp),%eax
 29d53a6:	mov    %rbx,%rcx
 29d53a9:	sub    $0x8000000,%rcx
 29d53b0:	mov    %rcx,%rbx
 29d53b3:	mov    %r13,%rcx
 29d53b6:	add    $0x8000000,%rcx
 29d53bd:	mov    %r14,%rdx
 29d53c0:	mov    %rcx,%r13
 29d53c3:	add    $0x8000000,%rdx
 29d53ca:	mov    %rbx,%rcx
 29d53cd:	mov    %rdx,%r14
 29d53d0:	cmp    $0x8000000,%rcx
 29d53d7:	ja     29d5349 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0xbe9>
 29d53dd:	mov    %esi,(%rsp)
 29d53e0:	mov    %edi,0x10(%rsp)
 29d53e4:	mov    %r8d,0x18(%rsp)
 29d53e9:	mov    %r9d,0x8(%rsp)
 29d53ee:	mov    %r11d,0x20(%rsp)
 29d53f3:	mov    %eax,0x28(%rsp)
 29d53f7:	mov    (%r15),%rax
 29d53fa:	mov    0xa0(%rsp),%rcx
 29d5402:	mov    %r15,0xd8(%rsp)
 29d540a:	cmp    %rcx,%rax
 29d540d:	jae    29d6984 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2224>
 29d5413:	mov    %rbx,%rcx
 29d5416:	mov    %r14,%rdx
 29d5419:	mov    %r13,%rsi
 29d541c:	jmp    29d542a <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0xcca>
 29d5421:	mov    %rbx,%rcx
 29d5424:	mov    %r14,%rdx
 29d5427:	mov    %r13,%rsi
 29d542a:	mov    %rbx,%rcx
 29d542d:	mov    %r14,%rdx
 29d5430:	mov    %r13,%rsi
 29d5433:	mov    0x60(%rsp),%rdi
 29d5438:	call   3018c9a <wasmtime_builtin_memory_copy>
 29d543d:	mov    (%rsp),%ebx
 29d5440:	test   %ebx,%ebx
 29d5442:	je     29d6cbc <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x255c>
 29d5448:	mov    0x10(%rsp),%r9d
 29d544d:	test   %r9d,%r9d
 29d5450:	je     29d6cbe <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x255e>
 29d5456:	test   %ebx,%ebx
 29d5458:	je     29d6cc0 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2560>
 29d545e:	mov    0xd0(%rsp),%r12
 29d5466:	mov    0x28(%r12),%rdx
 29d546b:	mov    0x20(%r12),%rax
 29d5470:	mov    %ebx,%esi
 29d5472:	mov    %rbx,0x80(%rsp)
 29d547a:	add    %rsi,%rax
 29d547d:	xor    %rdi,%rdi
 29d5480:	cmp    %rdx,%rsi
 29d5483:	cmova  %rdi,%rax
 29d5487:	mov    %r9d,0x28(%rax)
 29d548b:	mov    0x18(%rsp),%r8d
 29d5490:	test   %r8d,%r8d
 29d5493:	je     29d6cc2 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2562>
 29d5499:	mov    %r8d,0x2c(%rax)
 29d549d:	mov    0x8(%rsp),%edi
 29d54a1:	mov    0x20(%rsp),%esi
 29d54a5:	mov    0x28(%rsp),%edx
 29d54a9:	test   %r8d,%r8d
 29d54ac:	je     29d6cc4 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2564>
 29d54b2:	test   %r8d,%r8d
 29d54b5:	je     29d6cc6 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2566>
 29d54bb:	mov    0xd0(%rsp),%r12
 29d54c3:	mov    0x28(%r12),%r11
 29d54c8:	mov    0x20(%r12),%rbx
 29d54cd:	mov    %r8d,%eax
 29d54d0:	lea    0x10(%rbx,%rax,1),%r10
 29d54d5:	xor    %r12,%r12
 29d54d8:	cmp    %r11,%rax
 29d54db:	cmova  %r12,%r10
 29d54df:	mov    (%r10),%r13d
 29d54e2:	mov    0x68(%rsp),%rcx
 29d54e7:	shr    $0x6,%ecx
 29d54ea:	mov    %rcx,%r10
 29d54ed:	cmp    %r13d,%r10d
 29d54f0:	mov    %r10,0x88(%rsp)
 29d54f8:	jae    29d6cc8 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2568>
 29d54fe:	mov    %r13d,%r10d
 29d5501:	shl    $0x3,%r10
 29d5505:	shr    $0x20,%r10
 29d5509:	test   %r10,%r10
 29d550c:	jne    29d6cca <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x256a>
 29d5512:	shl    $0x3,%r13d
 29d5516:	add    $0x18,%r13d
 29d551a:	jb     29d6ccc <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x256c>
 29d5520:	mov    %r8,%r10
 29d5523:	add    %r13d,%r10d
 29d5526:	jb     29d6cce <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x256e>
 29d552c:	mov    %r10d,%r10d
 29d552f:	add    %r10,%rbx
 29d5532:	cmp    %r11,%r10
 29d5535:	cmova  %r12,%rbx
 29d5539:	mov    0x88(%rsp),%rcx
 29d5541:	mov    %rcx,%r10
 29d5544:	shl    $0x3,%r10d
 29d5548:	mov    %r10,%r11
 29d554b:	lea    0x18(%r11),%r10d
 29d554f:	mov    %r11,0xc8(%rsp)
 29d5557:	sub    %r10d,%r13d
 29d555a:	sub    %r13,%rbx
 29d555d:	mov    (%rbx),%r13
 29d5560:	mov    $0x1,%r12d
 29d5566:	mov    0x68(%rsp),%rcx
 29d556b:	shl    %cl,%r12
 29d556e:	bt     %rcx,%r13
 29d5572:	jae    29d5585 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0xe25>
 29d5578:	mov    0x80(%rsp),%rcx
 29d5580:	jmp    29d55d4 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0xe74>
 29d5585:	mov    0x80(%rsp),%rcx
 29d558d:	test   %ecx,%ecx
 29d558f:	je     29d6cd0 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2570>
 29d5595:	test   %ecx,%ecx
 29d5597:	je     29d6cd2 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2572>
 29d559d:	mov    0xd0(%rsp),%r10
 29d55a5:	mov    0x28(%r10),%r14
 29d55a9:	mov    0xb8(%rsp),%r10
 29d55b1:	lea    0x1(%r10),%r11
 29d55b5:	mov    %ecx,%ebx
 29d55b7:	mov    0xd0(%rsp),%r10
 29d55bf:	mov    %rbx,%r15
 29d55c2:	add    0x20(%r10),%r15
 29d55c6:	xor    %r10,%r10
 29d55c9:	cmp    %r14,%rbx
 29d55cc:	cmova  %r10,%r15
 29d55d0:	mov    %r11,0x18(%r15)
 29d55d4:	test   %r9d,%r9d
 29d55d7:	je     29d6cd4 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2574>
 29d55dd:	test   %r9d,%r9d
 29d55e0:	je     29d6cd6 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2576>
 29d55e6:	mov    0xd0(%rsp),%r10
 29d55ee:	mov    0x28(%r10),%r15
 29d55f2:	mov    0x20(%r10),%r14
 29d55f6:	mov    %r9d,%r10d
 29d55f9:	lea    0x10(%r14,%r10,1),%rbx
 29d55fe:	xor    %r11,%r11
 29d5601:	cmp    %r15,%r10
 29d5604:	cmova  %r11,%rbx
 29d5608:	mov    (%rbx),%ebx
 29d560a:	mov    0x68(%rsp),%r10
 29d560f:	cmp    %ebx,%r10d
 29d5612:	jae    29d6cd8 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2578>
 29d5618:	mov    %ebx,%r10d
 29d561b:	shl    $0x3,%r10
 29d561f:	shr    $0x20,%r10
 29d5623:	test   %r10,%r10
 29d5626:	jne    29d6cda <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x257a>
 29d562c:	shl    $0x3,%ebx
 29d562f:	add    $0x18,%ebx
 29d5632:	jb     29d6cdc <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x257c>
 29d5638:	add    %ebx,%r9d
 29d563b:	jb     29d6cde <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x257e>
 29d5641:	mov    %r9d,%r10d
 29d5644:	lea    (%r14,%r10,1),%r9
 29d5648:	cmp    %r15,%r10
 29d564b:	cmova  %r11,%r9
 29d564f:	mov    0x68(%rsp),%r10
 29d5654:	shl    $0x3,%r10d
 29d5658:	add    $0x18,%r10d
 29d565f:	sub    %r10d,%ebx
 29d5662:	sub    %rbx,%r9
 29d5665:	mov    0x78(%rsp),%r10
 29d566a:	mov    %r10,(%r9)
 29d566d:	lea    0x10(%r14,%rax,1),%r9
 29d5672:	cmp    %r15,%rax
 29d5675:	cmova  %r11,%r9
 29d5679:	mov    (%r9),%eax
 29d567c:	mov    0x88(%rsp),%r9
 29d5684:	cmp    %eax,%r9d
 29d5687:	jae    29d6ce0 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2580>
 29d568d:	mov    %eax,%r9d
 29d5690:	shl    $0x3,%r9
 29d5694:	shr    $0x20,%r9
 29d5698:	test   %r9,%r9
 29d569b:	jne    29d6ce2 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2582>
 29d56a1:	shl    $0x3,%eax
 29d56a4:	add    $0x18,%eax
 29d56a7:	jb     29d6ce4 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2584>
 29d56ad:	add    %eax,%r8d
 29d56b0:	jb     29d6ce6 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2586>
 29d56b6:	or     %r12,%r13
 29d56b9:	mov    %r12,0x90(%rsp)
 29d56c1:	mov    %r8d,%r9d
 29d56c4:	lea    (%r14,%r9,1),%r8
 29d56c8:	cmp    %r15,%r9
 29d56cb:	cmova  %r11,%r8
 29d56cf:	mov    0xc8(%rsp),%r10
 29d56d7:	lea    0x18(%r10),%r9d
 29d56db:	sub    %r9d,%eax
 29d56de:	sub    %rax,%r8
 29d56e1:	mov    %r13,(%r8)
 29d56e4:	mov    $0x1,%r10d
 29d56ea:	mov    %ecx,0x8(%rsp)
 29d56ee:	mov    %edi,0x10(%rsp)
 29d56f2:	mov    %esi,(%rsp)
 29d56f5:	mov    %edx,0x18(%rsp)
 29d56f9:	test   %r10d,%r10d
 29d56fc:	mov    %r10,0xa8(%rsp)
 29d5704:	jne    29d5e17 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x16b7>
 29d570a:	test   %ecx,%ecx
 29d570c:	je     29d6ce8 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2588>
 29d5712:	test   %ecx,%ecx
 29d5714:	je     29d6cea <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x258a>
 29d571a:	mov    0xd0(%rsp),%r12
 29d5722:	mov    0x28(%r12),%rax
 29d5727:	mov    %ecx,%r8d
 29d572a:	mov    %r8,%rdi
 29d572d:	add    0x20(%r12),%rdi
 29d5732:	xor    %r9,%r9
 29d5735:	cmp    %rax,%r8
 29d5738:	cmova  %r9,%rdi
 29d573c:	mov    0x24(%rdi),%eax
 29d573f:	cmp    $0x2,%eax
 29d5742:	sete   %al
 29d5745:	mov    0x70(%rsp),%rdi
 29d574a:	cmp    $0x3,%edi
 29d574d:	setne  %dil
 29d5751:	test   %al,%dil
 29d5754:	je     29d5e17 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x16b7>
 29d575a:	mov    0x8(%rsp),%ecx
 29d575e:	test   %ecx,%ecx
 29d5760:	je     29d6cec <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x258c>
 29d5766:	test   %ecx,%ecx
 29d5768:	je     29d6cee <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x258e>
 29d576e:	mov    0xd0(%rsp),%r12
 29d5776:	mov    0x28(%r12),%rax
 29d577b:	mov    0x20(%r12),%rsi
 29d5780:	mov    %ecx,%r8d
 29d5783:	lea    (%rsi,%r8,1),%rdx
 29d5787:	xor    %rdi,%rdi
 29d578a:	cmp    %rax,%r8
 29d578d:	cmova  %rdi,%rdx
 29d5791:	mov    0x28(%rdx),%r8d
 29d5795:	mov    0x2c(%rdx),%r9d
 29d5799:	test   %r8d,%r8d
 29d579c:	je     29d6cf0 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2590>
 29d57a2:	test   %r8d,%r8d
 29d57a5:	je     29d6cf2 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2592>
 29d57ab:	mov    %r8d,%r8d
 29d57ae:	lea    0x10(%rsi,%r8,1),%rsi
 29d57b3:	cmp    %rax,%r8
 29d57b6:	cmova  %rdi,%rsi
 29d57ba:	mov    (%rsi),%edi
 29d57bc:	mov    0x18(%rdx),%rax
 29d57c0:	mov    (%rsp),%esi
 29d57c3:	mov    0x18(%rsp),%edx
 29d57c7:	mov    %edi,%edi
 29d57c9:	mov    0x68(%rsp),%r8
 29d57ce:	cmp    %rdi,%r8
 29d57d1:	setb   %dil
 29d57d5:	cmp    $0x100000,%r8
 29d57dc:	setb   %r8b
 29d57e0:	lea    0x8(%rax,%rax,1),%r9
 29d57e5:	mov    0x68(%rsp),%rax
 29d57ea:	cmp    %r9,%rax
 29d57ed:	setbe  %r9b
 29d57f1:	and    %r9d,%r8d
 29d57f4:	or     %r8d,%edi
 29d57f7:	test   %dil,%dil
 29d57fa:	je     29d5e17 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x16b7>
 29d5800:	mov    0x8(%rsp),%esi
 29d5804:	test   %esi,%esi
 29d5806:	je     29d6cf4 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2594>
 29d580c:	test   %esi,%esi
 29d580e:	je     29d6cf6 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2596>
 29d5814:	mov    0xd0(%rsp),%r12
 29d581c:	mov    0x28(%r12),%r9
 29d5821:	mov    0x20(%r12),%r10
 29d5826:	mov    %esi,%eax
 29d5828:	lea    (%r10,%rax,1),%rsi
 29d582c:	xor    %r11,%r11
 29d582f:	cmp    %r9,%rax
 29d5832:	cmova  %r11,%rsi
 29d5836:	mov    0x28(%rsi),%eax
 29d5839:	mov    0x2c(%rsi),%ecx
 29d583c:	test   %eax,%eax
 29d583e:	je     29d6cf8 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2598>
 29d5844:	test   %eax,%eax
 29d5846:	je     29d6cfa <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x259a>
 29d584c:	mov    %eax,%ecx
 29d584e:	lea    0x10(%r10,%rcx,1),%rax
 29d5853:	cmp    %r9,%rcx
 29d5856:	cmova  %r11,%rax
 29d585a:	mov    (%rax),%eax
 29d585c:	mov    %eax,%r12d
 29d585f:	mov    %r12,%r15
 29d5862:	shl    $0x2,%r15
 29d5866:	mov    $0x20,%ecx
 29d586b:	mov    %rcx,0xc0(%rsp)
 29d5873:	mov    %r15,%rcx
 29d5876:	shr    $0x20,%rcx
 29d587a:	test   %rcx,%rcx
 29d587d:	jne    29d6cfc <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x259c>
 29d5883:	mov    %rax,%rcx
 29d5886:	shl    $0x2,%ecx
 29d5889:	mov    %rax,0xc8(%rsp)
 29d5891:	add    $0x14,%ecx
 29d5894:	jb     29d6cfe <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x259e>
 29d589a:	mov    0x60(%rsp),%rax
 29d589f:	mov    0x20(%rax),%rdi
 29d58a3:	mov    (%rdi),%eax
 29d58a5:	mov    %eax,%edx
 29d58a7:	mov    %ecx,%esi
 29d58a9:	add    $0xf,%rsi
 29d58b0:	mov    %rsi,%r8
 29d58b3:	and    $0xfffffffffffffff0,%r8
 29d58b7:	add    %rdx,%r8
 29d58ba:	mov    0x4(%rdi),%r9d
 29d58be:	mov    %rdi,0xb8(%rsp)
 29d58c6:	cmp    %r9,%r8
 29d58c9:	ja     29d69c2 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2262>
 29d58cf:	add    $0xf,%ecx
 29d58d5:	and    $0xfffffff0,%ecx
 29d58d8:	lea    (%rax,%rcx,1),%edi
 29d58db:	mov    0xb8(%rsp),%rcx
 29d58e3:	mov    %edi,(%rcx)
 29d58e5:	mov    0xd0(%rsp),%rcx
 29d58ed:	mov    0x20(%rcx),%rdi
 29d58f1:	lea    (%rdi,%rdx,1),%rcx
 29d58f5:	movl   $0xa800000e,(%rdi,%rdx,1)
 29d58fc:	mov    0x60(%rsp),%r8
 29d5901:	mov    0x28(%r8),%r8
 29d5905:	mov    0x19c(%r8),%r8d
 29d590c:	mov    %r8d,0x4(%rdi,%rdx,1)
 29d5911:	and    $0xfffffffffffffff0,%rsi
 29d5915:	mov    %esi,0x8(%rdi,%rdx,1)
 29d5919:	mov    %eax,0x20(%rsp)
 29d591d:	mov    0xc8(%rsp),%r14
 29d5925:	mov    %r14d,0x10(%rcx)
 29d5929:	test   %eax,%eax
 29d592b:	je     29d6d00 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25a0>
 29d5931:	mov    0xd0(%rsp),%rcx
 29d5939:	mov    0x28(%rcx),%rdx
 29d593d:	mov    0x20(%rcx),%rsi
 29d5941:	mov    %eax,%eax
 29d5943:	lea    (%rsi,%rax,1),%rcx
 29d5947:	lea    0x10(%rsi,%rax,1),%rdi
 29d594c:	xor    %r8,%r8
 29d594f:	cmp    %rdx,%rax
 29d5952:	cmova  %r8,%rdi
 29d5956:	mov    (%rdi),%edi
 29d5958:	cmp    %rdi,%r12
 29d595b:	ja     29d6d02 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25a2>
 29d5961:	lea    0x14(%rsi,%rax,1),%r13
 29d5966:	mov    %r13,%rax
 29d5969:	add    %r15,%rax
 29d596c:	jb     29d6d04 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25a4>
 29d5972:	add    %rsi,%rdx
 29d5975:	cmp    %rdx,%rax
 29d5978:	ja     29d6d06 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25a6>
 29d597e:	mov    0x8(%rsp),%esi
 29d5982:	mov    0x10(%rsp),%eax
 29d5986:	mov    (%rsp),%edx
 29d5989:	mov    0x18(%rsp),%edi
 29d598d:	lea    0x14(%rcx,%r12,4),%rbx
 29d5992:	test   %r12,%r12
 29d5995:	je     29d59ed <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x128d>
 29d599b:	mov    %esi,0x18(%rsp)
 29d599f:	mov    %eax,(%rsp)
 29d59a2:	mov    %edx,0x10(%rsp)
 29d59a6:	mov    %edi,0x8(%rsp)
 29d59aa:	mov    0xd8(%rsp),%rax
 29d59b2:	mov    (%rax),%rax
 29d59b5:	mov    0xa0(%rsp),%rcx
 29d59bd:	cmp    %rcx,%rax
 29d59c0:	jae    29d69f9 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2299>
 29d59c6:	movl   $0x0,0x0(%r13)
 29d59ce:	mov    0x18(%rsp),%esi
 29d59d2:	mov    (%rsp),%eax
 29d59d5:	mov    0x10(%rsp),%edx
 29d59d9:	mov    0x8(%rsp),%edi
 29d59dd:	add    $0x4,%r13
 29d59e4:	cmp    %rbx,%r13
 29d59e7:	jne    29d599b <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x123b>
 29d59ed:	mov    %esi,0x18(%rsp)
 29d59f1:	xor    %r13d,%r13d
 29d59f4:	mov    $0x1,%ecx
 29d59f9:	mov    %rcx,0x98(%rsp)
 29d5a01:	mov    0x60(%rsp),%rcx
 29d5a06:	mov    0x28(%rcx),%rcx
 29d5a0a:	mov    0x120(%rcx),%r14d
 29d5a11:	mov    %r14,%r15
 29d5a14:	mov    $0x10,%r14d
 29d5a1a:	mov    %r14,0xb0(%rsp)
 29d5a22:	mov    %r13,0x88(%rsp)
 29d5a2a:	mov    %eax,0x8(%rsp)
 29d5a2e:	mov    %edx,0x10(%rsp)
 29d5a32:	mov    %edi,(%rsp)
 29d5a35:	mov    0xd8(%rsp),%r10
 29d5a3d:	mov    (%r10),%rax
 29d5a40:	mov    0xa0(%rsp),%rcx
 29d5a48:	cmp    %rcx,%rax
 29d5a4b:	jae    29d6a31 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x22d1>
 29d5a51:	mov    0xc8(%rsp),%rcx
 29d5a59:	jmp    29d5a66 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1306>
 29d5a5e:	mov    0xc8(%rsp),%rcx
 29d5a66:	cmp    %ecx,%r13d
 29d5a69:	jae    29d5d96 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1636>
 29d5a6f:	mov    0x18(%rsp),%r8d
 29d5a74:	xor    %edx,%edx
 29d5a76:	test   %r8d,%r8d
 29d5a79:	je     29d6d08 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25a8>
 29d5a7f:	test   %r8d,%r8d
 29d5a82:	je     29d6d0a <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25aa>
 29d5a88:	mov    0xd0(%rsp),%r12
 29d5a90:	mov    0x28(%r12),%r11
 29d5a95:	mov    0x20(%r12),%rdi
 29d5a9a:	mov    %r8d,%eax
 29d5a9d:	lea    (%rdi,%rax,1),%r9
 29d5aa1:	xor    %r8,%r8
 29d5aa4:	cmp    %r11,%rax
 29d5aa7:	cmova  %r8,%r9
 29d5aab:	mov    0x28(%r9),%ecx
 29d5aaf:	mov    0x2c(%r9),%esi
 29d5ab3:	test   %ecx,%ecx
 29d5ab5:	je     29d6d0c <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25ac>
 29d5abb:	test   %ecx,%ecx
 29d5abd:	je     29d6d0e <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25ae>
 29d5ac3:	mov    %ecx,%eax
 29d5ac5:	lea    0x10(%rdi,%rax,1),%rdi
 29d5aca:	cmp    %r11,%rax
 29d5acd:	cmova  %r8,%rdi
 29d5ad1:	mov    (%rdi),%r8d
 29d5ad4:	mov    0x8(%rsp),%edi
 29d5ad8:	mov    %r13d,%r9d
 29d5adb:	mov    %r8d,%r8d
 29d5ade:	cmp    %r8,%r9
 29d5ae1:	jb     29d5af4 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1394>
 29d5ae7:	mov    0x90(%rsp),%r14
 29d5aef:	jmp    29d5c30 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x14d0>
 29d5af4:	xor    %edx,%edx
 29d5af6:	test   %esi,%esi
 29d5af8:	je     29d6d10 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25b0>
 29d5afe:	test   %esi,%esi
 29d5b00:	je     29d6d12 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25b2>
 29d5b06:	mov    0xd0(%rsp),%r12
 29d5b0e:	mov    0x28(%r12),%rdi
 29d5b13:	mov    0x20(%r12),%r8
 29d5b18:	mov    %esi,%r11d
 29d5b1b:	lea    0x10(%r8,%r11,1),%r10
 29d5b20:	xor    %r9,%r9
 29d5b23:	cmp    %rdi,%r11
 29d5b26:	cmova  %r9,%r10
 29d5b2a:	mov    (%r10),%r10d
 29d5b2d:	mov    %r13,%r11
 29d5b30:	shr    $0x6,%r11d
 29d5b34:	cmp    %r10d,%r11d
 29d5b37:	jae    29d6d14 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25b4>
 29d5b3d:	mov    %r10d,%ebx
 29d5b40:	shl    $0x3,%rbx
 29d5b44:	shr    $0x20,%rbx
 29d5b48:	test   %rbx,%rbx
 29d5b4b:	jne    29d6d16 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25b6>
 29d5b51:	shl    $0x3,%r10d
 29d5b55:	add    $0x18,%r10d
 29d5b59:	jb     29d6d18 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25b8>
 29d5b5f:	add    %r10d,%esi
 29d5b62:	jb     29d6d1a <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25ba>
 29d5b68:	mov    %esi,%ebx
 29d5b6a:	lea    (%r8,%rbx,1),%rsi
 29d5b6e:	cmp    %rdi,%rbx
 29d5b71:	cmova  %r9,%rsi
 29d5b75:	shl    $0x3,%r11d
 29d5b79:	lea    0x18(%r11),%edi
 29d5b7d:	sub    %edi,%r10d
 29d5b80:	sub    %r10,%rsi
 29d5b83:	mov    (%rsi),%rsi
 29d5b86:	mov    0x8(%rsp),%edi
 29d5b8a:	bt     %r13,%rsi
 29d5b8e:	jb     29d5ba1 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1441>
 29d5b94:	mov    0x90(%rsp),%r14
 29d5b9c:	jmp    29d5c30 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x14d0>
 29d5ba1:	mov    0xd0(%rsp),%r12
 29d5ba9:	mov    0x28(%r12),%rdx
 29d5bae:	mov    0x20(%r12),%rdi
 29d5bb3:	lea    0x10(%rdi,%rax,1),%r8
 29d5bb8:	xor    %rsi,%rsi
 29d5bbb:	cmp    %rdx,%rax
 29d5bbe:	cmova  %rsi,%r8
 29d5bc2:	mov    (%r8),%eax
 29d5bc5:	cmp    %eax,%r13d
 29d5bc8:	jae    29d6d1c <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25bc>
 29d5bce:	mov    %eax,%r8d
 29d5bd1:	shl    $0x3,%r8
 29d5bd5:	shr    $0x20,%r8
 29d5bd9:	test   %r8,%r8
 29d5bdc:	jne    29d6d1e <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25be>
 29d5be2:	mov    $0x3,%r8d
 29d5be8:	mov    %r8,0x88(%rsp)
 29d5bf0:	shl    $0x3,%eax
 29d5bf3:	add    $0x18,%eax
 29d5bf6:	jb     29d6d20 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25c0>
 29d5bfc:	add    %eax,%ecx
 29d5bfe:	jb     29d6d22 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25c2>
 29d5c04:	mov    %ecx,%r8d
 29d5c07:	lea    (%rdi,%r8,1),%rcx
 29d5c0b:	cmp    %rdx,%r8
 29d5c0e:	cmova  %rsi,%rcx
 29d5c12:	mov    %r13,%rdx
 29d5c15:	shl    $0x3,%edx
 29d5c18:	add    $0x18,%edx
 29d5c1e:	sub    %edx,%eax
 29d5c20:	sub    %rax,%rcx
 29d5c23:	mov    (%rcx),%r14
 29d5c26:	xor    %edi,%edi
 29d5c28:	mov    0x98(%rsp),%rdx
 29d5c30:	mov    %edi,0x8(%rsp)
 29d5c34:	test   %edx,%edx
 29d5c36:	jne    29d5c59 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x14f9>
 29d5c3c:	mov    0xc0(%rsp),%rcx
 29d5c44:	mov    0x88(%rsp),%rsi
 29d5c4c:	mov    0xb8(%rsp),%r12
 29d5c54:	jmp    29d5d5f <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x15ff>
 29d5c59:	mov    0xb8(%rsp),%r12
 29d5c61:	mov    (%r12),%eax
 29d5c65:	mov    %eax,%edx
 29d5c67:	lea    0x20(%rdx),%rcx
 29d5c6b:	mov    0x4(%r12),%esi
 29d5c70:	cmp    %rsi,%rcx
 29d5c73:	ja     29d6a6e <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x230e>
 29d5c79:	lea    0x20(%rax),%ecx
 29d5c7c:	mov    %ecx,(%r12)
 29d5c80:	mov    0xd0(%rsp),%rsi
 29d5c88:	mov    0x20(%rsi),%rsi
 29d5c8c:	lea    (%rsi,%rdx,1),%rdi
 29d5c90:	movl   $0xb0000042,(%rsi,%rdx,1)
 29d5c97:	mov    %r15d,0x4(%rsi,%rdx,1)
 29d5c9c:	mov    0xc0(%rsp),%rcx
 29d5ca4:	mov    %ecx,0x8(%rsi,%rdx,1)
 29d5ca8:	mov    %r14,0x10(%rdi)
 29d5cac:	mov    0x88(%rsp),%rsi
 29d5cb4:	mov    %esi,0x18(%rdi)
 29d5cb7:	mov    0x8(%rsp),%edx
 29d5cbb:	mov    %edx,0x1c(%rdi)
 29d5cbe:	mov    0x20(%rsp),%edx
 29d5cc2:	test   %edx,%edx
 29d5cc4:	je     29d6d24 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25c4>
 29d5cca:	test   %eax,%eax
 29d5ccc:	je     29d6d26 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25c6>
 29d5cd2:	test   %edx,%edx
 29d5cd4:	je     29d6d28 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25c8>
 29d5cda:	mov    0xd0(%rsp),%rdi
 29d5ce2:	mov    0x28(%rdi),%rdi
 29d5ce6:	mov    0xd0(%rsp),%r8
 29d5cee:	mov    0x20(%r8),%r8
 29d5cf2:	mov    %edx,%r11d
 29d5cf5:	lea    0x10(%r8,%r11,1),%r10
 29d5cfa:	xor    %r9,%r9
 29d5cfd:	cmp    %rdi,%r11
 29d5d00:	cmova  %r9,%r10
 29d5d04:	mov    (%r10),%r10d
 29d5d07:	cmp    %r10d,%r13d
 29d5d0a:	jae    29d6d2a <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25ca>
 29d5d10:	mov    %r10d,%r11d
 29d5d13:	shl    $0x2,%r11
 29d5d17:	shr    $0x20,%r11
 29d5d1b:	test   %r11,%r11
 29d5d1e:	jne    29d6d2c <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25cc>
 29d5d24:	shl    $0x2,%r10d
 29d5d28:	add    $0x14,%r10d
 29d5d2c:	jb     29d6d2e <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25ce>
 29d5d32:	add    %r10d,%edx
 29d5d35:	jb     29d6d30 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25d0>
 29d5d3b:	mov    %edx,%r11d
 29d5d3e:	add    %r11,%r8
 29d5d41:	cmp    %rdi,%r11
 29d5d44:	cmova  %r9,%r8
 29d5d48:	mov    %r13,%r11
 29d5d4b:	shl    $0x2,%r11d
 29d5d4f:	add    $0x14,%r11d
 29d5d56:	sub    %r11d,%r10d
 29d5d59:	sub    %r10,%r8
 29d5d5c:	mov    %eax,(%r8)
 29d5d5f:	mov    0x8(%rsp),%eax
 29d5d63:	mov    0x10(%rsp),%edx
 29d5d67:	mov    (%rsp),%edi
 29d5d6a:	add    $0x1,%r13d
 29d5d71:	mov    %rsi,0x88(%rsp)
 29d5d79:	mov    %r14,0x90(%rsp)
 29d5d81:	mov    %r12,0xb8(%rsp)
 29d5d89:	mov    %rcx,0xc0(%rsp)
 29d5d91:	jmp    29d5a2a <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x12ca>
 29d5d96:	mov    0x60(%rsp),%rcx
 29d5d9b:	mov    0xa00(%rcx),%edx
 29d5da1:	mov    0xa10(%rcx),%eax
 29d5da7:	mov    0x18(%rsp),%ecx
 29d5dab:	test   %ecx,%ecx
 29d5dad:	je     29d6d32 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25d2>
 29d5db3:	test   %edx,%edx
 29d5db5:	je     29d6d34 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25d4>
 29d5dbb:	test   %ecx,%ecx
 29d5dbd:	je     29d6d36 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25d6>
 29d5dc3:	mov    0xd0(%rsp),%r12
 29d5dcb:	mov    0x28(%r12),%rdi
 29d5dd0:	mov    0x20(%r12),%rsi
 29d5dd5:	mov    %ecx,%r8d
 29d5dd8:	add    %r8,%rsi
 29d5ddb:	xor    %r9,%r9
 29d5dde:	cmp    %rdi,%r8
 29d5de1:	cmova  %r9,%rsi
 29d5de5:	mov    %edx,0x28(%rsi)
 29d5de8:	test   %eax,%eax
 29d5dea:	je     29d6d38 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25d8>
 29d5df0:	mov    %eax,0x2c(%rsi)
 29d5df3:	movl   $0x0,0x30(%rsi)
 29d5dfa:	mov    0x20(%rsp),%eax
 29d5dfe:	test   %eax,%eax
 29d5e00:	je     29d6d3a <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25da>
 29d5e06:	mov    %eax,0x30(%rsi)
 29d5e09:	movl   $0x3,0x24(%rsi)
 29d5e10:	mov    0x10(%rsp),%esi
 29d5e14:	mov    (%rsp),%edx
 29d5e17:	mov    0x98(%rsp),%r13
 29d5e1f:	test   %r13d,%r13d
 29d5e22:	jne    29d5e3a <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x16da>
 29d5e28:	mov    0xa8(%rsp),%r10
 29d5e30:	mov    0x78(%rsp),%r13
 29d5e35:	jmp    29d6541 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1de1>
 29d5e3a:	test   %ecx,%ecx
 29d5e3c:	je     29d6d3c <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25dc>
 29d5e42:	test   %ecx,%ecx
 29d5e44:	je     29d6d3e <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25de>
 29d5e4a:	mov    0xd0(%rsp),%r12
 29d5e52:	mov    0x28(%r12),%rax
 29d5e57:	mov    0x20(%r12),%r9
 29d5e5c:	mov    %ecx,%edi
 29d5e5e:	lea    (%r9,%rdi,1),%r8
 29d5e62:	xor    %r10,%r10
 29d5e65:	cmp    %rax,%rdi
 29d5e68:	cmova  %r10,%r8
 29d5e6c:	mov    0x30(%r8),%edi
 29d5e70:	test   %edi,%edi
 29d5e72:	je     29d6d40 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25e0>
 29d5e78:	test   %edi,%edi
 29d5e7a:	je     29d6d42 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25e2>
 29d5e80:	mov    %edi,%r11d
 29d5e83:	lea    0x10(%r9,%r11,1),%r9
 29d5e88:	cmp    %rax,%r11
 29d5e8b:	cmova  %r10,%r9
 29d5e8f:	mov    (%r9),%ebx
 29d5e92:	mov    %rbx,0x88(%rsp)
 29d5e9a:	mov    0x18(%r8),%r12
 29d5e9e:	mov    %r12,0x98(%rsp)
 29d5ea6:	mov    %ebx,%r14d
 29d5ea9:	mov    0x68(%rsp),%rax
 29d5eae:	cmp    %r14,%rax
 29d5eb1:	mov    %r14,0x90(%rsp)
 29d5eb9:	setb   %al
 29d5ebc:	mov    0x68(%rsp),%r8
 29d5ec1:	cmp    $0x100000,%r8
 29d5ec8:	setb   %r8b
 29d5ecc:	lea    0x8(%r12,%r12,1),%r9
 29d5ed1:	mov    0x68(%rsp),%r10
 29d5ed6:	cmp    %r9,%r10
 29d5ed9:	setbe  %r9b
 29d5edd:	and    %r9d,%r8d
 29d5ee0:	or     %r8d,%eax
 29d5ee3:	test   %al,%al
 29d5ee5:	jne    29d5efd <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x179d>
 29d5eeb:	mov    0xa8(%rsp),%r10
 29d5ef3:	mov    0x78(%rsp),%r13
 29d5ef8:	jmp    29d6541 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1de1>
 29d5efd:	mov    0x68(%rsp),%rax
 29d5f02:	mov    0x90(%rsp),%r14
 29d5f0a:	cmp    %r14,%rax
 29d5f0d:	jb     29d632c <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1bcc>
 29d5f13:	mov    0x88(%rsp),%rbx
 29d5f1b:	mov    0x88(%rsp),%r8
 29d5f23:	test   %r8d,%ebx
 29d5f26:	je     29d5f39 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x17d9>
 29d5f2c:	mov    0x88(%rsp),%rbx
 29d5f34:	jmp    29d5f3e <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x17de>
 29d5f39:	mov    $0x4,%ebx
 29d5f3e:	mov    %edi,0x20(%rsp)
 29d5f42:	mov    %ecx,(%rsp)
 29d5f45:	mov    %esi,0x10(%rsp)
 29d5f49:	mov    %edx,0x18(%rsp)
 29d5f4d:	mov    0xd8(%rsp),%r13
 29d5f55:	mov    0x0(%r13),%rdx
 29d5f59:	mov    0xa0(%rsp),%rax
 29d5f61:	cmp    %rax,%rdx
 29d5f64:	jae    29d6aa8 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2348>
 29d5f6a:	mov    %ebx,%r15d
 29d5f6d:	mov    0x68(%rsp),%rcx
 29d5f72:	cmp    %r15,%rcx
 29d5f75:	jb     29d5f91 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1831>
 29d5f7b:	mov    0x20(%rsp),%edi
 29d5f7f:	mov    (%rsp),%ecx
 29d5f82:	mov    0x10(%rsp),%esi
 29d5f86:	mov    0x18(%rsp),%edx
 29d5f8a:	shl    $1,%ebx
 29d5f8c:	jmp    29d5f3e <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x17de>
 29d5f91:	mov    %r15,%r12
 29d5f94:	shl    $0x2,%r12
 29d5f98:	mov    %r12,%rax
 29d5f9b:	shr    $0x20,%rax
 29d5f9f:	test   %rax,%rax
 29d5fa2:	jne    29d6d44 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25e4>
 29d5fa8:	mov    %rbx,%rcx
 29d5fab:	shl    $0x2,%ecx
 29d5fae:	add    $0x14,%ecx
 29d5fb1:	jb     29d6d46 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25e6>
 29d5fb7:	mov    0x60(%rsp),%rdx
 29d5fbc:	mov    0x20(%rdx),%rdi
 29d5fc0:	mov    (%rdi),%eax
 29d5fc2:	mov    %eax,%edx
 29d5fc4:	mov    %ecx,%esi
 29d5fc6:	add    $0xf,%rsi
 29d5fcd:	mov    %rsi,%r8
 29d5fd0:	and    $0xfffffffffffffff0,%r8
 29d5fd4:	add    %rdx,%r8
 29d5fd7:	mov    0x4(%rdi),%r9d
 29d5fdb:	cmp    %r9,%r8
 29d5fde:	ja     29d6add <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x237d>
 29d5fe4:	add    $0xf,%ecx
 29d5fea:	and    $0xfffffff0,%ecx
 29d5fed:	add    %eax,%ecx
 29d5fef:	mov    %ecx,(%rdi)
 29d5ff1:	mov    0xd0(%rsp),%r8
 29d5ff9:	mov    0x20(%r8),%rdi
 29d5ffd:	lea    (%rdi,%rdx,1),%rcx
 29d6001:	movl   $0xa800000e,(%rdi,%rdx,1)
 29d6008:	mov    0x60(%rsp),%r8
 29d600d:	mov    0x28(%r8),%r8
 29d6011:	mov    0x19c(%r8),%r8d
 29d6018:	mov    %r8d,0x4(%rdi,%rdx,1)
 29d601d:	and    $0xfffffffffffffff0,%rsi
 29d6021:	mov    %esi,0x8(%rdi,%rdx,1)
 29d6025:	mov    %eax,0x8(%rsp)
 29d6029:	mov    %ebx,0x10(%rcx)
 29d602c:	test   %eax,%eax
 29d602e:	je     29d6d48 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25e8>
 29d6034:	mov    0xd0(%rsp),%rcx
 29d603c:	mov    0x28(%rcx),%rcx
 29d6040:	mov    0xd0(%rsp),%rdx
 29d6048:	mov    0x20(%rdx),%rdx
 29d604c:	mov    %eax,%eax
 29d604e:	lea    (%rdx,%rax,1),%rdi
 29d6052:	lea    0x10(%rdx,%rax,1),%rsi
 29d6057:	xor    %r8,%r8
 29d605a:	cmp    %rcx,%rax
 29d605d:	cmova  %r8,%rsi
 29d6061:	mov    (%rsi),%esi
 29d6063:	cmp    %rsi,%r15
 29d6066:	ja     29d6d4a <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25ea>
 29d606c:	lea    0x14(%rdx,%rax,1),%r13
 29d6071:	mov    %r13,%rax
 29d6074:	add    %r12,%rax
 29d6077:	jb     29d6d4c <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25ec>
 29d607d:	add    %rdx,%rcx
 29d6080:	cmp    %rcx,%rax
 29d6083:	ja     29d6d4e <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25ee>
 29d6089:	mov    0x20(%rsp),%eax
 29d608d:	mov    (%rsp),%ecx
 29d6090:	mov    0x10(%rsp),%esi
 29d6094:	mov    0x18(%rsp),%edx
 29d6098:	lea    0x14(%rdi,%r15,4),%rbx
 29d609d:	test   %r15,%r15
 29d60a0:	je     29d60f8 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1998>
 29d60a6:	mov    %eax,0x18(%rsp)
 29d60aa:	mov    %ecx,0x10(%rsp)
 29d60ae:	mov    %esi,(%rsp)
 29d60b1:	mov    %edx,0x20(%rsp)
 29d60b5:	mov    0xd8(%rsp),%rcx
 29d60bd:	mov    (%rcx),%rax
 29d60c0:	mov    0xa0(%rsp),%rcx
 29d60c8:	cmp    %rcx,%rax
 29d60cb:	jae    29d6b14 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x23b4>
 29d60d1:	movl   $0x0,0x0(%r13)
 29d60d9:	mov    0x18(%rsp),%eax
 29d60dd:	mov    0x10(%rsp),%ecx
 29d60e1:	mov    (%rsp),%esi
 29d60e4:	mov    0x20(%rsp),%edx
 29d60e8:	add    $0x4,%r13
 29d60ef:	cmp    %rbx,%r13
 29d60f2:	jne    29d60a6 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1946>
 29d60f8:	mov    0x8(%rsp),%edi
 29d60fc:	test   %edi,%edi
 29d60fe:	je     29d6d50 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25f0>
 29d6104:	test   %eax,%eax
 29d6106:	je     29d6d52 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25f2>
 29d610c:	test   %edi,%edi
 29d610e:	je     29d6d54 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25f4>
 29d6114:	mov    0xd0(%rsp),%r12
 29d611c:	mov    0x28(%r12),%r10
 29d6121:	mov    0x20(%r12),%r9
 29d6126:	mov    %edi,%ebx
 29d6128:	lea    (%r9,%rbx,1),%r8
 29d612c:	lea    0x10(%r9,%rbx,1),%r11
 29d6131:	xor    %r13,%r13
 29d6134:	cmp    %r10,%rbx
 29d6137:	cmova  %r13,%r11
 29d613b:	mov    (%r11),%r11d
 29d613e:	mov    0x90(%rsp),%r14
 29d6146:	cmp    %r11,%r14
 29d6149:	ja     29d6d56 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25f6>
 29d614f:	test   %eax,%eax
 29d6151:	je     29d6d58 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25f8>
 29d6157:	mov    %eax,%r12d
 29d615a:	lea    (%r9,%r12,1),%r11
 29d615e:	lea    0x10(%r9,%r12,1),%r14
 29d6163:	cmp    %r10,%r12
 29d6166:	cmova  %r13,%r14
 29d616a:	mov    (%r14),%r13d
 29d616d:	mov    0x90(%rsp),%r14
 29d6175:	cmp    %r13,%r14
 29d6178:	ja     29d6d5a <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25fa>
 29d617e:	lea    0x14(%r9,%rbx,1),%r13
 29d6183:	shl    $0x2,%r14
 29d6187:	mov    %r13,%r15
 29d618a:	add    %r14,%r15
 29d618d:	jb     29d6d5c <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25fc>
 29d6193:	add    %r9,%r10
 29d6196:	cmp    %r10,%r15
 29d6199:	ja     29d6d5e <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x25fe>
 29d619f:	lea    0x14(%r9,%r12,1),%r15
 29d61a4:	mov    %r15,%r9
 29d61a7:	add    %r14,%r9
 29d61aa:	jb     29d6d60 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2600>
 29d61b0:	cmp    %r10,%r9
 29d61b3:	ja     29d6d62 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2602>
 29d61b9:	mov    0x88(%rsp),%rbx
 29d61c1:	mov    0x88(%rsp),%r9
 29d61c9:	test   %r9d,%ebx
 29d61cc:	je     29d62ee <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1b8e>
 29d61d2:	mov    0x8(%rsp),%r9d
 29d61d7:	xor    %r14d,%r14d
 29d61da:	mov    0x90(%rsp),%rdi
 29d61e2:	lea    0x14(%r8,%rdi,4),%rbx
 29d61e7:	lea    0x14(%r11,%rdi,4),%r12
 29d61ec:	cmp    %r15,%r13
 29d61ef:	jae    29d61fd <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1a9d>
 29d61f5:	mov    %r9,%rdi
 29d61f8:	jmp    29d627d <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1b1d>
 29d61fd:	mov    %r9,%rdi
 29d6200:	mov    %r9d,0x28(%rsp)
 29d6205:	mov    %eax,0x20(%rsp)
 29d6209:	mov    %ecx,(%rsp)
 29d620c:	mov    %edi,0x10(%rsp)
 29d6210:	mov    %esi,0x18(%rsp)
 29d6214:	mov    %edx,0x8(%rsp)
 29d6218:	mov    0xd8(%rsp),%r13
 29d6220:	mov    0x0(%r13),%rax
 29d6224:	mov    0xa0(%rsp),%rcx
 29d622c:	cmp    %rcx,%rax
 29d622f:	jae    29d6b49 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x23e9>
 29d6235:	sub    $0x4,%r12
 29d6239:	mov    (%r12),%eax
 29d623d:	sub    $0x4,%rbx
 29d6241:	mov    %eax,(%rbx)
 29d6243:	mov    (%rsp),%ecx
 29d6246:	mov    0x10(%rsp),%edi
 29d624a:	mov    0x18(%rsp),%esi
 29d624e:	mov    0x8(%rsp),%edx
 29d6252:	mov    0x28(%rsp),%r9d
 29d6257:	mov    0x20(%rsp),%eax
 29d625b:	mov    0x88(%rsp),%r8
 29d6263:	sub    $0x1,%r8d
 29d6267:	mov    %r8,0x88(%rsp)
 29d626f:	cmp    %r15,%r12
 29d6272:	je     29d62ee <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1b8e>
 29d6278:	jmp    29d6200 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1aa0>
 29d627d:	mov    %r9d,0x20(%rsp)
 29d6282:	mov    %eax,0x28(%rsp)
 29d6286:	mov    %ecx,0x8(%rsp)
 29d628a:	mov    %edi,0x18(%rsp)
 29d628e:	mov    %esi,0x10(%rsp)
 29d6292:	mov    %edx,(%rsp)
 29d6295:	mov    0xd8(%rsp),%rax
 29d629d:	mov    (%rax),%rax
 29d62a0:	mov    0xa0(%rsp),%rcx
 29d62a8:	cmp    %rcx,%rax
 29d62ab:	jae    29d6b7d <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x241d>
 29d62b1:	mov    (%r15),%eax
 29d62b4:	mov    %eax,0x0(%r13)
 29d62b8:	mov    0x8(%rsp),%ecx
 29d62bc:	mov    0x18(%rsp),%edi
 29d62c0:	mov    0x10(%rsp),%esi
 29d62c4:	mov    (%rsp),%edx
 29d62c7:	mov    0x20(%rsp),%r9d
 29d62cc:	mov    0x28(%rsp),%eax
 29d62d0:	add    $0x4,%r15
 29d62d7:	add    $0x4,%r13
 29d62de:	add    $0x1,%r14d
 29d62e5:	cmp    %r12,%r15
 29d62e8:	jne    29d627d <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1b1d>
 29d62ee:	test   %ecx,%ecx
 29d62f0:	je     29d6d64 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2604>
 29d62f6:	test   %edi,%edi
 29d62f8:	je     29d6d66 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2606>
 29d62fe:	test   %ecx,%ecx
 29d6300:	je     29d6d68 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2608>
 29d6306:	mov    0xd0(%rsp),%r12
 29d630e:	mov    0x28(%r12),%rax
 29d6313:	mov    %ecx,%r9d
 29d6316:	mov    %r9,%r8
 29d6319:	add    0x20(%r12),%r8
 29d631e:	xor    %r10,%r10
 29d6321:	cmp    %rax,%r9
 29d6324:	cmova  %r10,%r8
 29d6328:	mov    %edi,0x30(%r8)
 29d632c:	mov    %esi,(%rsp)
 29d632f:	mov    %edi,0x10(%rsp)
 29d6333:	mov    %ecx,0x18(%rsp)
 29d6337:	mov    %edx,0x8(%rsp)
 29d633b:	mov    0x60(%rsp),%rcx
 29d6340:	mov    0x20(%rcx),%r8
 29d6344:	mov    (%r8),%eax
 29d6347:	mov    %eax,%esi
 29d6349:	mov    $0x20,%edi
 29d634e:	lea    0x20(%rsi),%r9
 29d6352:	mov    0x4(%r8),%r10d
 29d6356:	cmp    %r10,%r9
 29d6359:	ja     29d6bb1 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2451>
 29d635f:	lea    0x20(%rax),%r9d
 29d6363:	mov    %r9d,(%r8)
 29d6366:	mov    0xd0(%rsp),%r12
 29d636e:	mov    0x20(%r12),%r8
 29d6373:	lea    (%r8,%rsi,1),%r9
 29d6377:	movl   $0xb0000042,(%r8,%rsi,1)
 29d637f:	mov    0x60(%rsp),%rcx
 29d6384:	mov    0x28(%rcx),%r10
 29d6388:	mov    0x120(%r10),%r10d
 29d638f:	mov    %r10d,0x4(%r8,%rsi,1)
 29d6394:	mov    %edi,0x8(%r8,%rsi,1)
 29d6399:	mov    0x78(%rsp),%r13
 29d639e:	mov    %r13,0x10(%r9)
 29d63a2:	mov    0x70(%rsp),%rdi
 29d63a7:	mov    %edi,0x18(%r9)
 29d63ab:	mov    (%rsp),%ecx
 29d63ae:	mov    %ecx,0x1c(%r9)
 29d63b2:	mov    0x10(%rsp),%ecx
 29d63b6:	test   %ecx,%ecx
 29d63b8:	je     29d6d6a <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x260a>
 29d63be:	test   %ecx,%ecx
 29d63c0:	je     29d6d6c <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x260c>
 29d63c6:	mov    0xd0(%rsp),%r12
 29d63ce:	mov    0x28(%r12),%rdx
 29d63d3:	mov    0x20(%r12),%rsi
 29d63d8:	mov    %ecx,%r9d
 29d63db:	lea    0x10(%rsi,%r9,1),%r8
 29d63e0:	xor    %rdi,%rdi
 29d63e3:	cmp    %rdx,%r9
 29d63e6:	cmova  %rdi,%r8
 29d63ea:	mov    (%r8),%r8d
 29d63ed:	mov    0x68(%rsp),%r9
 29d63f2:	cmp    %r8d,%r9d
 29d63f5:	jae    29d6d6e <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x260e>
 29d63fb:	mov    %r8d,%r9d
 29d63fe:	shl    $0x2,%r9
 29d6402:	shr    $0x20,%r9
 29d6406:	test   %r9,%r9
 29d6409:	jne    29d6d70 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2610>
 29d640f:	shl    $0x2,%r8d
 29d6413:	add    $0x14,%r8d
 29d6417:	jb     29d6d72 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2612>
 29d641d:	add    %r8d,%ecx
 29d6420:	jb     29d6d74 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2614>
 29d6426:	mov    %ecx,%ecx
 29d6428:	add    %rcx,%rsi
 29d642b:	cmp    %rdx,%rcx
 29d642e:	cmova  %rdi,%rsi
 29d6432:	mov    0x68(%rsp),%rcx
 29d6437:	shl    $0x2,%ecx
 29d643a:	lea    0x14(%rcx),%edx
 29d643d:	sub    %edx,%r8d
 29d6440:	sub    %r8,%rsi
 29d6443:	mov    (%rsi),%edx
 29d6445:	test   %edx,%edx
 29d6447:	jne    29d649c <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1d3c>
 29d644d:	mov    0x18(%rsp),%edx
 29d6451:	test   %edx,%edx
 29d6453:	je     29d6d76 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2616>
 29d6459:	test   %edx,%edx
 29d645b:	je     29d6d78 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2618>
 29d6461:	mov    0xd0(%rsp),%r12
 29d6469:	mov    0x28(%r12),%rdi
 29d646e:	mov    0x98(%rsp),%r12
 29d6476:	lea    0x1(%r12),%rsi
 29d647b:	mov    %edx,%r8d
 29d647e:	mov    0xd0(%rsp),%r12
 29d6486:	mov    %r8,%rdx
 29d6489:	add    0x20(%r12),%rdx
 29d648e:	xor    %r9,%r9
 29d6491:	cmp    %rdi,%r8
 29d6494:	cmova  %r9,%rdx
 29d6498:	mov    %rsi,0x18(%rdx)
 29d649c:	mov    0x10(%rsp),%edx
 29d64a0:	test   %edx,%edx
 29d64a2:	je     29d6d7a <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x261a>
 29d64a8:	test   %eax,%eax
 29d64aa:	je     29d6d7c <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x261c>
 29d64b0:	test   %edx,%edx
 29d64b2:	je     29d6d7e <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x261e>
 29d64b8:	mov    0xd0(%rsp),%r12
 29d64c0:	mov    0x28(%r12),%rsi
 29d64c5:	mov    0x20(%r12),%rdi
 29d64ca:	mov    %edx,%r10d
 29d64cd:	lea    0x10(%rdi,%r10,1),%r9
 29d64d2:	xor    %r8,%r8
 29d64d5:	cmp    %rsi,%r10
 29d64d8:	cmova  %r8,%r9
 29d64dc:	mov    (%r9),%r9d
 29d64df:	mov    0x68(%rsp),%r10
 29d64e4:	cmp    %r9d,%r10d
 29d64e7:	jae    29d6d80 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2620>
 29d64ed:	mov    %r9d,%r10d
 29d64f0:	shl    $0x2,%r10
 29d64f4:	shr    $0x20,%r10
 29d64f8:	test   %r10,%r10
 29d64fb:	jne    29d6d82 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2622>
 29d6501:	shl    $0x2,%r9d
 29d6505:	add    $0x14,%r9d
 29d6509:	jb     29d6d84 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2624>
 29d650f:	add    %r9d,%edx
 29d6512:	jb     29d6d86 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2626>
 29d6518:	mov    %edx,%r10d
 29d651b:	lea    (%rdi,%r10,1),%rdx
 29d651f:	cmp    %rsi,%r10
 29d6522:	cmova  %r8,%rdx
 29d6526:	add    $0x14,%ecx
 29d652c:	sub    %ecx,%r9d
 29d652f:	sub    %r9,%rdx
 29d6532:	mov    %eax,(%rdx)
 29d6534:	mov    (%rsp),%esi
 29d6537:	mov    0x8(%rsp),%edx
 29d653b:	mov    $0x1,%r10d
 29d6541:	mov    %esi,0x8(%rsp)
 29d6545:	mov    %edx,(%rsp)
 29d6548:	test   %r10d,%r10d
 29d654b:	jne    29d66a5 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1f45>
 29d6551:	mov    0x60(%rsp),%rcx
 29d6556:	mov    0x20(%rcx),%r12
 29d655a:	mov    (%r12),%eax
 29d655e:	mov    %eax,%ecx
 29d6560:	mov    $0x20,%ebx
 29d6565:	lea    0x20(%rcx),%rdx
 29d6569:	mov    0x4(%r12),%esi
 29d656e:	cmp    %rsi,%rdx
 29d6571:	ja     29d6bf4 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2494>
 29d6577:	lea    0x20(%rax),%edx
 29d657a:	mov    %edx,(%r12)
 29d657e:	mov    0xd0(%rsp),%rdx
 29d6586:	mov    0x20(%rdx),%rsi
 29d658a:	lea    (%rsi,%rcx,1),%rdx
 29d658e:	movl   $0xb0000042,(%rsi,%rcx,1)
 29d6595:	mov    0x60(%rsp),%rdi
 29d659a:	mov    0x28(%rdi),%rdi
 29d659e:	mov    0x120(%rdi),%edi
 29d65a4:	mov    %edi,0x4(%rsi,%rcx,1)
 29d65a8:	mov    %ebx,0x8(%rsi,%rcx,1)
 29d65ac:	mov    %eax,0x10(%rsp)
 29d65b0:	mov    %r13,0x10(%rdx)
 29d65b4:	mov    0x70(%rsp),%rdi
 29d65b9:	mov    %edi,0x18(%rdx)
 29d65bc:	mov    0x8(%rsp),%esi
 29d65c0:	mov    %esi,0x1c(%rdx)
 29d65c3:	mov    0x60(%rsp),%rcx
 29d65c8:	mov    0xa20(%rcx),%edi
 29d65ce:	mov    %edi,0x8(%rsp)
 29d65d2:	test   %eax,%eax
 29d65d4:	je     29d6d88 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2628>
 29d65da:	test   %edi,%edi
 29d65dc:	je     29d6d8a <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x262a>
 29d65e2:	mov    (%r12),%r8d
 29d65e6:	mov    %r8d,%ecx
 29d65e9:	lea    0x20(%rcx),%rax
 29d65ed:	mov    0x4(%r12),%edx
 29d65f2:	cmp    %rdx,%rax
 29d65f5:	ja     29d6c30 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x24d0>
 29d65fb:	lea    0x20(%r8),%eax
 29d65ff:	mov    %eax,(%r12)
 29d6603:	mov    0xd0(%rsp),%r12
 29d660b:	mov    0x20(%r12),%rdx
 29d6610:	lea    (%rdx,%rcx,1),%rsi
 29d6614:	movl   $0xb0000072,(%rdx,%rcx,1)
 29d661b:	mov    0x60(%rsp),%rax
 29d6620:	mov    0x28(%rax),%rax
 29d6624:	mov    0x13c(%rax),%eax
 29d662a:	mov    %eax,0x4(%rdx,%rcx,1)
 29d662e:	mov    %ebx,0x8(%rdx,%rcx,1)
 29d6632:	movl   $0xe,0x10(%rsi)
 29d6639:	mov    0x10(%rsp),%eax
 29d663d:	mov    %eax,0x14(%rsi)
 29d6640:	mov    0x8(%rsp),%eax
 29d6644:	mov    %eax,0x18(%rsi)
 29d6647:	mov    %eax,0x1c(%rsi)
 29d664a:	mov    (%rsp),%eax
 29d664d:	test   %eax,%eax
 29d664f:	je     29d6d8c <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x262c>
 29d6655:	test   %eax,%eax
 29d6657:	je     29d6d8e <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x262e>
 29d665d:	mov    0xd0(%rsp),%r12
 29d6665:	mov    0x28(%r12),%rcx
 29d666a:	mov    0x20(%r12),%rsi
 29d666f:	mov    %eax,%edx
 29d6671:	lea    (%rsi,%rdx,1),%rax
 29d6675:	xor    %rsi,%rsi
 29d6678:	cmp    %rcx,%rdx
 29d667b:	cmova  %rsi,%rax
 29d667f:	mov    0x14(%rax),%edx
 29d6682:	test   %edx,%edx
 29d6684:	je     29d6d90 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2630>
 29d668a:	test   %r8d,%r8d
 29d668d:	je     29d6d92 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2632>
 29d6693:	mov    0x68(%rsp),%rcx
 29d6698:	mov    0x60(%rsp),%rsi
 29d669d:	mov    %rsi,%rdi
 29d66a0:	call   29da920 <wasm[0]::function[1013]::helper::array_indexed_publish>
 29d66a5:	mov    0xe0(%rsp),%rbx
 29d66ad:	mov    0xe8(%rsp),%r12
 29d66b5:	mov    0xf0(%rsp),%r13
 29d66bd:	mov    0xf8(%rsp),%r14
 29d66c5:	mov    0x100(%rsp),%r15
 29d66cd:	add    $0x110,%rsp
 29d66d4:	mov    %rbp,%rsp
 29d66d7:	pop    %rbp
 29d66d8:	ret    $0x10
 29d66db:	mov    0x60(%rsp),%rdi
 29d66e0:	call   3018d19 <wasmtime_builtin_new_epoch>
 29d66e5:	mov    %rax,0xa0(%rsp)
 29d66ed:	jmp    29d4803 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0xa3>
 29d66f2:	mov    0xd0(%rsp),%r12
 29d66fa:	mov    0x8(%r12),%rax
 29d66ff:	mov    %rax,0xa0(%rsp)
 29d6707:	cmp    %rax,%r8
 29d670a:	jb     29d4a36 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2d6>
 29d6710:	mov    0x60(%rsp),%rdi
 29d6715:	call   3018d19 <wasmtime_builtin_new_epoch>
 29d671a:	mov    %rax,0xa0(%rsp)
 29d6722:	jmp    29d4a36 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2d6>
 29d6727:	mov    $0xa8000006,%esi
 29d672c:	mov    0x60(%rsp),%rax
 29d6731:	mov    0x28(%rax),%rax
 29d6735:	mov    0x1a0(%rax),%edx
 29d673b:	mov    $0x10,%r8d
 29d6741:	mov    0x60(%rsp),%rdi
 29d6746:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
 29d674b:	mov    %eax,%ecx
 29d674d:	mov    0xd0(%rsp),%rdx
 29d6755:	add    0x20(%rdx),%rcx
 29d6759:	jmp    29d4b20 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x3c0>
 29d675e:	mov    0xd0(%rsp),%r12
 29d6766:	mov    0x8(%r12),%rcx
 29d676b:	mov    %rcx,0xa0(%rsp)
 29d6773:	cmp    %rcx,%rax
 29d6776:	jb     29d4bdd <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x47d>
 29d677c:	mov    0x60(%rsp),%rdi
 29d6781:	call   3018d19 <wasmtime_builtin_new_epoch>
 29d6786:	mov    %rax,0xa0(%rsp)
 29d678e:	jmp    29d4bdd <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x47d>
 29d6793:	mov    0xd0(%rsp),%r12
 29d679b:	mov    0x8(%r12),%rax
 29d67a0:	mov    %rax,0xa0(%rsp)
 29d67a8:	cmp    %rax,%rsi
 29d67ab:	jb     29d4c6e <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x50e>
 29d67b1:	mov    0x60(%rsp),%rdi
 29d67b6:	call   3018d19 <wasmtime_builtin_new_epoch>
 29d67bb:	mov    %rax,0xa0(%rsp)
 29d67c3:	jmp    29d4c6e <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x50e>
 29d67c8:	mov    0xd0(%rsp),%r12
 29d67d0:	mov    0x8(%r12),%rdx
 29d67d5:	mov    %rdx,%rsi
 29d67d8:	mov    %rdx,0xa0(%rsp)
 29d67e0:	cmp    %rsi,%rax
 29d67e3:	jb     29d4dbf <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x65f>
 29d67e9:	mov    0x60(%rsp),%rdi
 29d67ee:	call   3018d19 <wasmtime_builtin_new_epoch>
 29d67f3:	mov    %rax,0xa0(%rsp)
 29d67fb:	jmp    29d4dbf <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x65f>
 29d6800:	mov    0xd0(%rsp),%r12
 29d6808:	mov    0x8(%r12),%rax
 29d680d:	mov    %rax,0xa0(%rsp)
 29d6815:	cmp    %rax,%rsi
 29d6818:	jb     29d4eb0 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x750>
 29d681e:	mov    0x60(%rsp),%rdi
 29d6823:	call   3018d19 <wasmtime_builtin_new_epoch>
 29d6828:	mov    %rax,0xa0(%rsp)
 29d6830:	jmp    29d4eb0 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x750>
 29d6835:	mov    0xd0(%rsp),%r12
 29d683d:	mov    0x8(%r12),%rcx
 29d6842:	mov    %rcx,0xa0(%rsp)
 29d684a:	cmp    %rcx,%rax
 29d684d:	jb     29d4f62 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x802>
 29d6853:	mov    0x60(%rsp),%rdi
 29d6858:	call   3018d19 <wasmtime_builtin_new_epoch>
 29d685d:	mov    %rax,0xa0(%rsp)
 29d6865:	mov    %rbx,%rcx
 29d6868:	mov    %r14,%rdx
 29d686b:	mov    0x88(%rsp),%rsi
 29d6873:	jmp    29d4f70 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x810>
 29d6878:	mov    $0xa8000006,%esi
 29d687d:	mov    0x60(%rsp),%rax
 29d6882:	mov    0x28(%rax),%rax
 29d6886:	mov    0x1a4(%rax),%edx
 29d688c:	mov    $0x10,%r8d
 29d6892:	mov    0x60(%rsp),%rdi
 29d6897:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
 29d689c:	mov    %eax,%ecx
 29d689e:	mov    0xd0(%rsp),%r12
 29d68a6:	add    0x20(%r12),%rcx
 29d68ab:	jmp    29d5020 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x8c0>
 29d68b0:	mov    0xd0(%rsp),%r12
 29d68b8:	mov    0x8(%r12),%rcx
 29d68bd:	mov    %rcx,0xa0(%rsp)
 29d68c5:	cmp    %rcx,%rax
 29d68c8:	jb     29d50d5 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x975>
 29d68ce:	mov    0x60(%rsp),%rdi
 29d68d3:	call   3018d19 <wasmtime_builtin_new_epoch>
 29d68d8:	mov    %rax,0xa0(%rsp)
 29d68e0:	jmp    29d50d5 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x975>
 29d68e5:	mov    0xd0(%rsp),%r12
 29d68ed:	mov    0x8(%r12),%rcx
 29d68f2:	mov    %rcx,0xa0(%rsp)
 29d68fa:	cmp    %rcx,%rax
 29d68fd:	jb     29d515b <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x9fb>
 29d6903:	mov    0x60(%rsp),%rdi
 29d6908:	call   3018d19 <wasmtime_builtin_new_epoch>
 29d690d:	mov    %rax,0xa0(%rsp)
 29d6915:	jmp    29d515b <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x9fb>
 29d691a:	mov    0xd0(%rsp),%r12
 29d6922:	mov    0x8(%r12),%rcx
 29d6927:	mov    %rcx,0xa0(%rsp)
 29d692f:	cmp    %rcx,%rax
 29d6932:	jb     29d529c <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0xb3c>
 29d6938:	mov    0x60(%rsp),%rdi
 29d693d:	call   3018d19 <wasmtime_builtin_new_epoch>
 29d6942:	mov    %rax,0xa0(%rsp)
 29d694a:	jmp    29d529c <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0xb3c>
 29d694f:	mov    0xd0(%rsp),%r12
 29d6957:	mov    0x8(%r12),%rcx
 29d695c:	mov    %rcx,0xa0(%rsp)
 29d6964:	cmp    %rcx,%rax
 29d6967:	jb     29d5377 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0xc17>
 29d696d:	mov    0x60(%rsp),%rdi
 29d6972:	call   3018d19 <wasmtime_builtin_new_epoch>
 29d6977:	mov    %rax,0xa0(%rsp)
 29d697f:	jmp    29d5377 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0xc17>
 29d6984:	mov    0xd0(%rsp),%r12
 29d698c:	mov    0x8(%r12),%rcx
 29d6991:	mov    %rcx,0xa0(%rsp)
 29d6999:	cmp    %rcx,%rax
 29d699c:	jb     29d5421 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0xcc1>
 29d69a2:	mov    0x60(%rsp),%rdi
 29d69a7:	call   3018d19 <wasmtime_builtin_new_epoch>
 29d69ac:	mov    %rax,0xa0(%rsp)
 29d69b4:	mov    %rbx,%rcx
 29d69b7:	mov    %r14,%rdx
 29d69ba:	mov    %r13,%rsi
 29d69bd:	jmp    29d542a <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0xcca>
 29d69c2:	mov    $0xa800000e,%esi
 29d69c7:	mov    0x60(%rsp),%rax
 29d69cc:	mov    0x28(%rax),%rax
 29d69d0:	mov    0x19c(%rax),%edx
 29d69d6:	mov    $0x10,%r8d
 29d69dc:	mov    0x60(%rsp),%rdi
 29d69e1:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
 29d69e6:	mov    %eax,%ecx
 29d69e8:	mov    0xd0(%rsp),%rdx
 29d69f0:	add    0x20(%rdx),%rcx
 29d69f4:	jmp    29d5919 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x11b9>
 29d69f9:	mov    0xd0(%rsp),%r12
 29d6a01:	mov    0x8(%r12),%rcx
 29d6a06:	mov    %rcx,%rdx
 29d6a09:	mov    %rcx,0xa0(%rsp)
 29d6a11:	cmp    %rdx,%rax
 29d6a14:	jb     29d59c6 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1266>
 29d6a1a:	mov    0x60(%rsp),%rdi
 29d6a1f:	call   3018d19 <wasmtime_builtin_new_epoch>
 29d6a24:	mov    %rax,0xa0(%rsp)
 29d6a2c:	jmp    29d59c6 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1266>
 29d6a31:	mov    0xd0(%rsp),%r12
 29d6a39:	mov    0x8(%r12),%rcx
 29d6a3e:	mov    %rcx,0xa0(%rsp)
 29d6a46:	cmp    %rcx,%rax
 29d6a49:	jb     29d5a5e <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x12fe>
 29d6a4f:	mov    0x60(%rsp),%rdi
 29d6a54:	call   3018d19 <wasmtime_builtin_new_epoch>
 29d6a59:	mov    %rax,0xa0(%rsp)
 29d6a61:	mov    0xc8(%rsp),%rcx
 29d6a69:	jmp    29d5a66 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1306>
 29d6a6e:	mov    $0xb0000042,%esi
 29d6a73:	mov    $0x20,%ecx
 29d6a78:	mov    %r15,%rdx
 29d6a7b:	mov    0x60(%rsp),%rdi
 29d6a80:	mov    0xb0(%rsp),%r8
 29d6a88:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
 29d6a8d:	mov    %eax,%edi
 29d6a8f:	mov    0xd0(%rsp),%rcx
 29d6a97:	add    0x20(%rcx),%rdi
 29d6a9b:	mov    0xc0(%rsp),%rcx
 29d6aa3:	jmp    29d5ca8 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1548>
 29d6aa8:	mov    0xd0(%rsp),%r12
 29d6ab0:	mov    0x8(%r12),%rax
 29d6ab5:	mov    %rax,0xa0(%rsp)
 29d6abd:	cmp    %rax,%rdx
 29d6ac0:	jb     29d5f6a <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x180a>
 29d6ac6:	mov    0x60(%rsp),%rdi
 29d6acb:	call   3018d19 <wasmtime_builtin_new_epoch>
 29d6ad0:	mov    %rax,0xa0(%rsp)
 29d6ad8:	jmp    29d5f6a <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x180a>
 29d6add:	mov    $0xa800000e,%esi
 29d6ae2:	mov    0x60(%rsp),%rax
 29d6ae7:	mov    0x28(%rax),%rax
 29d6aeb:	mov    0x19c(%rax),%edx
 29d6af1:	mov    $0x10,%r8d
 29d6af7:	mov    0x60(%rsp),%rdi
 29d6afc:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
 29d6b01:	mov    %eax,%ecx
 29d6b03:	mov    0xd0(%rsp),%rdx
 29d6b0b:	add    0x20(%rdx),%rcx
 29d6b0f:	jmp    29d6025 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x18c5>
 29d6b14:	mov    0xd0(%rsp),%r12
 29d6b1c:	mov    0x8(%r12),%rcx
 29d6b21:	mov    %rcx,0xa0(%rsp)
 29d6b29:	cmp    %rcx,%rax
 29d6b2c:	jb     29d60d1 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1971>
 29d6b32:	mov    0x60(%rsp),%rdi
 29d6b37:	call   3018d19 <wasmtime_builtin_new_epoch>
 29d6b3c:	mov    %rax,0xa0(%rsp)
 29d6b44:	jmp    29d60d1 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1971>
 29d6b49:	mov    0xd0(%rsp),%rcx
 29d6b51:	mov    0x8(%rcx),%rcx
 29d6b55:	mov    %rcx,0xa0(%rsp)
 29d6b5d:	cmp    %rcx,%rax
 29d6b60:	jb     29d6235 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1ad5>
 29d6b66:	mov    0x60(%rsp),%rdi
 29d6b6b:	call   3018d19 <wasmtime_builtin_new_epoch>
 29d6b70:	mov    %rax,0xa0(%rsp)
 29d6b78:	jmp    29d6235 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1ad5>
 29d6b7d:	mov    0xd0(%rsp),%rcx
 29d6b85:	mov    0x8(%rcx),%rcx
 29d6b89:	mov    %rcx,0xa0(%rsp)
 29d6b91:	cmp    %rcx,%rax
 29d6b94:	jb     29d62b1 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1b51>
 29d6b9a:	mov    0x60(%rsp),%rdi
 29d6b9f:	call   3018d19 <wasmtime_builtin_new_epoch>
 29d6ba4:	mov    %rax,0xa0(%rsp)
 29d6bac:	jmp    29d62b1 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1b51>
 29d6bb1:	mov    $0xb0000042,%esi
 29d6bb6:	mov    0x60(%rsp),%rcx
 29d6bbb:	mov    0x28(%rcx),%rdi
 29d6bbf:	mov    0x120(%rdi),%edx
 29d6bc5:	mov    $0x20,%ecx
 29d6bca:	mov    $0x10,%r8d
 29d6bd0:	mov    0x60(%rsp),%rdi
 29d6bd5:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
 29d6bda:	mov    %eax,%r9d
 29d6bdd:	mov    0xd0(%rsp),%r12
 29d6be5:	add    0x20(%r12),%r9
 29d6bea:	mov    0x78(%rsp),%r13
 29d6bef:	jmp    29d639e <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1c3e>
 29d6bf4:	mov    $0xb0000042,%esi
 29d6bf9:	mov    0x60(%rsp),%rcx
 29d6bfe:	mov    0x28(%rcx),%rax
 29d6c02:	mov    0x120(%rax),%edx
 29d6c08:	mov    $0x20,%ecx
 29d6c0d:	mov    $0x10,%r8d
 29d6c13:	mov    0x60(%rsp),%rdi
 29d6c18:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
 29d6c1d:	mov    %eax,%edx
 29d6c1f:	mov    0xd0(%rsp),%rcx
 29d6c27:	add    0x20(%rcx),%rdx
 29d6c2b:	jmp    29d65ac <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1e4c>
 29d6c30:	mov    $0xb0000072,%esi
 29d6c35:	mov    0x60(%rsp),%rcx
 29d6c3a:	mov    0x28(%rcx),%rax
 29d6c3e:	mov    0x13c(%rax),%edx
 29d6c44:	mov    $0x20,%ecx
 29d6c49:	mov    $0x10,%r8d
 29d6c4f:	mov    0x60(%rsp),%rdi
 29d6c54:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
 29d6c59:	mov    %eax,%esi
 29d6c5b:	mov    0xd0(%rsp),%r12
 29d6c63:	add    0x20(%r12),%rsi
 29d6c68:	mov    %rax,%r8
 29d6c6b:	jmp    29d6632 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1ed2>
 29d6c70:	ud2
 29d6c72:	ud2
 29d6c74:	ud2
 29d6c76:	ud2
 29d6c78:	ud2
 29d6c7a:	ud2
 29d6c7c:	ud2
 29d6c7e:	ud2
 29d6c80:	ud2
 29d6c82:	ud2
 29d6c84:	ud2
 29d6c86:	ud2
 29d6c88:	ud2
 29d6c8a:	ud2
 29d6c8c:	ud2
 29d6c8e:	ud2
 29d6c90:	ud2
 29d6c92:	ud2
 29d6c94:	ud2
 29d6c96:	ud2
 29d6c98:	ud2
 29d6c9a:	ud2
 29d6c9c:	ud2
 29d6c9e:	ud2
 29d6ca0:	ud2
 29d6ca2:	ud2
 29d6ca4:	ud2
 29d6ca6:	ud2
 29d6ca8:	ud2
 29d6caa:	ud2
 29d6cac:	ud2
 29d6cae:	ud2
 29d6cb0:	ud2
 29d6cb2:	ud2
 29d6cb4:	ud2
 29d6cb6:	ud2
 29d6cb8:	ud2
 29d6cba:	ud2
 29d6cbc:	ud2
 29d6cbe:	ud2
 29d6cc0:	ud2
 29d6cc2:	ud2
 29d6cc4:	ud2
 29d6cc6:	ud2
 29d6cc8:	ud2
 29d6cca:	ud2
 29d6ccc:	ud2
 29d6cce:	ud2
 29d6cd0:	ud2
 29d6cd2:	ud2
 29d6cd4:	ud2
 29d6cd6:	ud2
 29d6cd8:	ud2
 29d6cda:	ud2
 29d6cdc:	ud2
 29d6cde:	ud2
 29d6ce0:	ud2
 29d6ce2:	ud2
 29d6ce4:	ud2
 29d6ce6:	ud2
 29d6ce8:	ud2
 29d6cea:	ud2
 29d6cec:	ud2
 29d6cee:	ud2
 29d6cf0:	ud2
 29d6cf2:	ud2
 29d6cf4:	ud2
 29d6cf6:	ud2
 29d6cf8:	ud2
 29d6cfa:	ud2
 29d6cfc:	ud2
 29d6cfe:	ud2
 29d6d00:	ud2
 29d6d02:	ud2
 29d6d04:	ud2
 29d6d06:	ud2
 29d6d08:	ud2
 29d6d0a:	ud2
 29d6d0c:	ud2
 29d6d0e:	ud2
 29d6d10:	ud2
 29d6d12:	ud2
 29d6d14:	ud2
 29d6d16:	ud2
 29d6d18:	ud2
 29d6d1a:	ud2
 29d6d1c:	ud2
 29d6d1e:	ud2
 29d6d20:	ud2
 29d6d22:	ud2
 29d6d24:	ud2
 29d6d26:	ud2
 29d6d28:	ud2
 29d6d2a:	ud2
 29d6d2c:	ud2
 29d6d2e:	ud2
 29d6d30:	ud2
 29d6d32:	ud2
 29d6d34:	ud2
 29d6d36:	ud2
 29d6d38:	ud2
 29d6d3a:	ud2
 29d6d3c:	ud2
 29d6d3e:	ud2
 29d6d40:	ud2
 29d6d42:	ud2
 29d6d44:	ud2
 29d6d46:	ud2
 29d6d48:	ud2
 29d6d4a:	ud2
 29d6d4c:	ud2
 29d6d4e:	ud2
 29d6d50:	ud2
 29d6d52:	ud2
 29d6d54:	ud2
 29d6d56:	ud2
 29d6d58:	ud2
 29d6d5a:	ud2
 29d6d5c:	ud2
 29d6d5e:	ud2
 29d6d60:	ud2
 29d6d62:	ud2
 29d6d64:	ud2
 29d6d66:	ud2
 29d6d68:	ud2
 29d6d6a:	ud2
 29d6d6c:	ud2
 29d6d6e:	ud2
 29d6d70:	ud2
 29d6d72:	ud2
 29d6d74:	ud2
 29d6d76:	ud2
 29d6d78:	ud2
 29d6d7a:	ud2
 29d6d7c:	ud2
 29d6d7e:	ud2
 29d6d80:	ud2
 29d6d82:	ud2
 29d6d84:	ud2
 29d6d86:	ud2
 29d6d88:	ud2
 29d6d8a:	ud2
 29d6d8c:	ud2
 29d6d8e:	ud2
 29d6d90:	ud2
 29d6d92:	ud2
