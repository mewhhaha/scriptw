
/workspace/scriptw/target/performance-dense-numbers-20261030/v2/native-cause/candidate/runtime-portable.elf:     file format elf64-x86-64


Disassembly of section .text:

00000000029d6da0 <wasm[0]::function[1009]::helper::array_packed_join>:
 29d6da0:	push   %rbp
 29d6da1:	mov    %rsp,%rbp
 29d6da4:	mov    0x8(%rdi),%r10
 29d6da8:	mov    0x18(%r10),%r10
 29d6dac:	add    $0x120,%r10
 29d6db3:	cmp    %rsp,%r10
 29d6db6:	ja     29d85e5 <wasm[0]::function[1009]::helper::array_packed_join+0x1845>
 29d6dbc:	sub    $0x110,%rsp
 29d6dc3:	mov    %rbx,0xe0(%rsp)
 29d6dcb:	mov    %r12,0xe8(%rsp)
 29d6dd3:	mov    %r13,0xf0(%rsp)
 29d6ddb:	mov    %r14,0xf8(%rsp)
 29d6de3:	mov    %r15,0x100(%rsp)
 29d6deb:	mov    %r9,0x68(%rsp)
 29d6df0:	mov    0x10(%rbp),%rsi
 29d6df4:	mov    %r8d,0x38(%rsp)
 29d6df9:	mov    %esi,0x40(%rsp)
 29d6dfd:	movl   $0x0,0x10(%rsp)
 29d6e05:	movl   $0x0,(%rsp)
 29d6e0c:	mov    0x18(%rdi),%rax
 29d6e10:	mov    (%rax),%rcx
 29d6e13:	mov    %rax,0xd0(%rsp)
 29d6e1b:	mov    0x8(%rdi),%rdx
 29d6e1f:	mov    %rdi,0x60(%rsp)
 29d6e24:	mov    0x8(%rdx),%rax
 29d6e28:	mov    %rdx,0xc8(%rsp)
 29d6e30:	cmp    %rax,%rcx
 29d6e33:	jae    29d8334 <wasm[0]::function[1009]::helper::array_packed_join+0x1594>
 29d6e39:	mov    0x68(%rsp),%r15
 29d6e3e:	mov    %rax,0x88(%rsp)
 29d6e46:	test   %r15,%r15
 29d6e49:	je     29d82ef <wasm[0]::function[1009]::helper::array_packed_join+0x154f>
 29d6e4f:	mov    0x40(%rsp),%edx
 29d6e53:	xor    %ecx,%ecx
 29d6e55:	test   %edx,%edx
 29d6e57:	je     29d85e7 <wasm[0]::function[1009]::helper::array_packed_join+0x1847>
 29d6e5d:	test   %edx,%edx
 29d6e5f:	je     29d85e9 <wasm[0]::function[1009]::helper::array_packed_join+0x1849>
 29d6e65:	mov    0xc8(%rsp),%r10
 29d6e6d:	mov    0x28(%r10),%rax
 29d6e71:	mov    0x20(%r10),%rsi
 29d6e75:	mov    %edx,%r8d
 29d6e78:	lea    (%rsi,%r8,1),%rdx
 29d6e7c:	xor    %rdi,%rdi
 29d6e7f:	cmp    %rax,%r8
 29d6e82:	cmova  %rdi,%rdx
 29d6e86:	mov    0x10(%rdx),%edx
 29d6e89:	test   %edx,%edx
 29d6e8b:	je     29d85eb <wasm[0]::function[1009]::helper::array_packed_join+0x184b>
 29d6e91:	test   %edx,%edx
 29d6e93:	je     29d85ed <wasm[0]::function[1009]::helper::array_packed_join+0x184d>
 29d6e99:	mov    %edx,%r8d
 29d6e9c:	lea    0x10(%rsi,%r8,1),%rsi
 29d6ea1:	cmp    %rax,%r8
 29d6ea4:	cmova  %rdi,%rsi
 29d6ea8:	mov    (%rsi),%r14d
 29d6eab:	mov    %r14,0xc0(%rsp)
 29d6eb3:	mov    0x38(%rsp),%eax
 29d6eb7:	test   %eax,%eax
 29d6eb9:	je     29d6f02 <wasm[0]::function[1009]::helper::array_packed_join+0x162>
 29d6ebf:	mov    0x38(%rsp),%eax
 29d6ec3:	xor    %ecx,%ecx
 29d6ec5:	test   $0x1,%eax
 29d6eca:	jne    29d6f02 <wasm[0]::function[1009]::helper::array_packed_join+0x162>
 29d6ed0:	mov    0x28(%r10),%rsi
 29d6ed4:	mov    0x20(%r10),%r8
 29d6ed8:	mov    %eax,%edi
 29d6eda:	lea    0x4(%r8,%rdi,1),%rax
 29d6edf:	xor    %r8,%r8
 29d6ee2:	cmp    %rsi,%rdi
 29d6ee5:	cmova  %r8,%rax
 29d6ee9:	mov    (%rax),%esi
 29d6eeb:	mov    0x60(%rsp),%rcx
 29d6ef0:	mov    0x28(%rcx),%rdi
 29d6ef4:	cmp    0x254(%rdi),%esi
 29d6efa:	sete   %sil
 29d6efe:	movzbl %sil,%ecx
 29d6f02:	mov    0x10(%rsp),%eax
 29d6f06:	xor    %edi,%edi
 29d6f08:	test   %ecx,%ecx
 29d6f0a:	jne    29d6f20 <wasm[0]::function[1009]::helper::array_packed_join+0x180>
 29d6f10:	mov    %rdi,%r8
 29d6f13:	mov    %r10,0xc8(%rsp)
 29d6f1b:	jmp    29d8283 <wasm[0]::function[1009]::helper::array_packed_join+0x14e3>
 29d6f20:	mov    0x38(%rsp),%r9d
 29d6f25:	xor    %ecx,%ecx
 29d6f27:	test   %r9d,%r9d
 29d6f2a:	je     29d6f70 <wasm[0]::function[1009]::helper::array_packed_join+0x1d0>
 29d6f30:	xor    %ecx,%ecx
 29d6f32:	test   $0x1,%r9d
 29d6f39:	jne    29d6f70 <wasm[0]::function[1009]::helper::array_packed_join+0x1d0>
 29d6f3f:	mov    0x28(%r10),%rcx
 29d6f43:	mov    0x20(%r10),%rsi
 29d6f47:	mov    %r9d,%edi
 29d6f4a:	lea    0x4(%rsi,%rdi,1),%rsi
 29d6f4f:	xor    %r8,%r8
 29d6f52:	cmp    %rcx,%rdi
 29d6f55:	cmova  %r8,%rsi
 29d6f59:	mov    (%rsi),%ecx
 29d6f5b:	mov    0x60(%rsp),%rsi
 29d6f60:	mov    0x28(%rsi),%rsi
 29d6f64:	cmp    0x254(%rsi),%ecx
 29d6f6a:	sete   %cl
 29d6f6d:	movzbl %cl,%ecx
 29d6f70:	test   %ecx,%ecx
 29d6f72:	je     29d85ef <wasm[0]::function[1009]::helper::array_packed_join+0x184f>
 29d6f78:	test   %r9d,%r9d
 29d6f7b:	je     29d85f1 <wasm[0]::function[1009]::helper::array_packed_join+0x1851>
 29d6f81:	test   %r9d,%r9d
 29d6f84:	je     29d85f3 <wasm[0]::function[1009]::helper::array_packed_join+0x1853>
 29d6f8a:	mov    0x28(%r10),%rsi
 29d6f8e:	mov    0x20(%r10),%rcx
 29d6f92:	mov    %r9d,%edi
 29d6f95:	add    %rdi,%rcx
 29d6f98:	xor    %r8,%r8
 29d6f9b:	cmp    %rsi,%rdi
 29d6f9e:	cmova  %r8,%rcx
 29d6fa2:	mov    0x14(%rcx),%esi
 29d6fa5:	mov    %esi,0x40(%rsp)
 29d6fa9:	mov    0x18(%rcx),%rcx
 29d6fad:	xor    %edi,%edi
 29d6faf:	cmp    %r15,%rcx
 29d6fb2:	mov    %r15,0x68(%rsp)
 29d6fb7:	je     29d6fcd <wasm[0]::function[1009]::helper::array_packed_join+0x22d>
 29d6fbd:	mov    %rdi,%r8
 29d6fc0:	mov    %r10,0xc8(%rsp)
 29d6fc8:	jmp    29d8283 <wasm[0]::function[1009]::helper::array_packed_join+0x14e3>
 29d6fcd:	mov    0x40(%rsp),%eax
 29d6fd1:	xor    %edi,%edi
 29d6fd3:	test   %eax,%eax
 29d6fd5:	je     29d85f5 <wasm[0]::function[1009]::helper::array_packed_join+0x1855>
 29d6fdb:	test   %eax,%eax
 29d6fdd:	je     29d85f7 <wasm[0]::function[1009]::helper::array_packed_join+0x1857>
 29d6fe3:	mov    0x28(%r10),%rcx
 29d6fe7:	mov    0x20(%r10),%r8
 29d6feb:	mov    %r10,0xc8(%rsp)
 29d6ff3:	mov    %eax,%esi
 29d6ff5:	lea    (%r8,%rsi,1),%rax
 29d6ff9:	xor    %r8,%r8
 29d6ffc:	cmp    %rcx,%rsi
 29d6fff:	cmova  %r8,%rax
 29d7003:	mov    0x24(%rax),%ecx
 29d7006:	mov    0x10(%rsp),%eax
 29d700a:	cmp    $0x2,%ecx
 29d700d:	sete   %sil
 29d7011:	cmp    $0x3,%ecx
 29d7014:	sete   %cl
 29d7017:	or     %ecx,%esi
 29d7019:	movzbl %sil,%ecx
 29d701d:	test   %ecx,%ecx
 29d701f:	jne    29d702d <wasm[0]::function[1009]::helper::array_packed_join+0x28d>
 29d7025:	mov    %rdi,%r8
 29d7028:	jmp    29d8283 <wasm[0]::function[1009]::helper::array_packed_join+0x14e3>
 29d702d:	mov    (%rsp),%ecx
 29d7030:	mov    0x10(%rsp),%eax
 29d7034:	xor    %r15,%r15
 29d7037:	xor    %r13d,%r13d
 29d703a:	mov    %r13,0x80(%rsp)
 29d7042:	mov    $0x1,%esi
 29d7047:	mov    %rsi,0xb8(%rsp)
 29d704f:	mov    0x60(%rsp),%rsi
 29d7054:	mov    0x28(%rsi),%r13
 29d7058:	mov    0x234(%r13),%esi
 29d705f:	mov    %r13,%r12
 29d7062:	mov    0xc0(%rsp),%r14
 29d706a:	mov    %rsi,0xb0(%rsp)
 29d7072:	mov    %r14d,%esi
 29d7075:	mov    %rsi,0xa8(%rsp)
 29d707d:	mov    0x80(%rsp),%rdi
 29d7085:	mov    %r15,%r13
 29d7088:	mov    %r15,%r14
 29d708b:	mov    %ecx,0x8(%rsp)
 29d708f:	mov    %edx,0x38(%rsp)
 29d7093:	mov    %eax,0x10(%rsp)
 29d7097:	mov    %edi,(%rsp)
 29d709a:	mov    0xd0(%rsp),%rcx
 29d70a2:	mov    (%rcx),%rax
 29d70a5:	mov    0x88(%rsp),%rcx
 29d70ad:	cmp    %rcx,%rax
 29d70b0:	jae    29d8350 <wasm[0]::function[1009]::helper::array_packed_join+0x15b0>
 29d70b6:	mov    0x68(%rsp),%rcx
 29d70bb:	jmp    29d70c5 <wasm[0]::function[1009]::helper::array_packed_join+0x325>
 29d70c0:	mov    0x68(%rsp),%rcx
 29d70c5:	cmp    %rcx,%r15
 29d70c8:	jae    29d7548 <wasm[0]::function[1009]::helper::array_packed_join+0x7a8>
 29d70ce:	mov    0x40(%rsp),%eax
 29d70d2:	test   %eax,%eax
 29d70d4:	je     29d85f9 <wasm[0]::function[1009]::helper::array_packed_join+0x1859>
 29d70da:	test   %eax,%eax
 29d70dc:	je     29d85fb <wasm[0]::function[1009]::helper::array_packed_join+0x185b>
 29d70e2:	mov    0xc8(%rsp),%r10
 29d70ea:	mov    0x28(%r10),%rcx
 29d70ee:	mov    %eax,%edx
 29d70f0:	mov    %rdx,%rax
 29d70f3:	add    0x20(%r10),%rax
 29d70f7:	xor    %rsi,%rsi
 29d70fa:	cmp    %rcx,%rdx
 29d70fd:	cmova  %rsi,%rax
 29d7101:	mov    0x24(%rax),%eax
 29d7104:	cmp    $0x3,%eax
 29d7107:	je     29d72ba <wasm[0]::function[1009]::helper::array_packed_join+0x51a>
 29d710d:	mov    0x40(%rsp),%eax
 29d7111:	xor    %edx,%edx
 29d7113:	test   %eax,%eax
 29d7115:	je     29d85fd <wasm[0]::function[1009]::helper::array_packed_join+0x185d>
 29d711b:	test   %eax,%eax
 29d711d:	je     29d85ff <wasm[0]::function[1009]::helper::array_packed_join+0x185f>
 29d7123:	mov    0xc8(%rsp),%r10
 29d712b:	mov    0x28(%r10),%rcx
 29d712f:	mov    0x20(%r10),%r8
 29d7133:	mov    %eax,%edi
 29d7135:	lea    (%r8,%rdi,1),%rsi
 29d7139:	xor    %r9,%r9
 29d713c:	cmp    %rcx,%rdi
 29d713f:	cmova  %r9,%rsi
 29d7143:	mov    0x28(%rsi),%eax
 29d7146:	mov    0x2c(%rsi),%edi
 29d7149:	test   %eax,%eax
 29d714b:	je     29d8601 <wasm[0]::function[1009]::helper::array_packed_join+0x1861>
 29d7151:	test   %eax,%eax
 29d7153:	je     29d8603 <wasm[0]::function[1009]::helper::array_packed_join+0x1863>
 29d7159:	mov    %eax,%esi
 29d715b:	lea    0x10(%r8,%rsi,1),%r8
 29d7160:	cmp    %rcx,%rsi
 29d7163:	cmova  %r9,%r8
 29d7167:	mov    (%r8),%r8d
 29d716a:	mov    0x8(%rsp),%ecx
 29d716e:	mov    %r8d,%r8d
 29d7171:	cmp    %r8,%r15
 29d7174:	jb     29d7182 <wasm[0]::function[1009]::helper::array_packed_join+0x3e2>
 29d717a:	mov    %r13,%rsi
 29d717d:	jmp    29d73f3 <wasm[0]::function[1009]::helper::array_packed_join+0x653>
 29d7182:	xor    %edx,%edx
 29d7184:	test   %edi,%edi
 29d7186:	je     29d8605 <wasm[0]::function[1009]::helper::array_packed_join+0x1865>
 29d718c:	test   %edi,%edi
 29d718e:	je     29d8607 <wasm[0]::function[1009]::helper::array_packed_join+0x1867>
 29d7194:	mov    0xc8(%rsp),%r10
 29d719c:	mov    0x28(%r10),%rcx
 29d71a0:	mov    0x20(%r10),%r8
 29d71a4:	mov    %edi,%r10d
 29d71a7:	lea    0x10(%r8,%r10,1),%r11
 29d71ac:	xor    %r9,%r9
 29d71af:	cmp    %rcx,%r10
 29d71b2:	cmova  %r9,%r11
 29d71b6:	mov    (%r11),%r10d
 29d71b9:	mov    %r15,%r11
 29d71bc:	shr    $0x6,%r11d
 29d71c0:	cmp    %r10d,%r11d
 29d71c3:	jae    29d8609 <wasm[0]::function[1009]::helper::array_packed_join+0x1869>
 29d71c9:	mov    %r10d,%ebx
 29d71cc:	shl    $0x3,%rbx
 29d71d0:	shr    $0x20,%rbx
 29d71d4:	test   %rbx,%rbx
 29d71d7:	jne    29d860b <wasm[0]::function[1009]::helper::array_packed_join+0x186b>
 29d71dd:	shl    $0x3,%r10d
 29d71e1:	add    $0x18,%r10d
 29d71e5:	jb     29d860d <wasm[0]::function[1009]::helper::array_packed_join+0x186d>
 29d71eb:	add    %r10d,%edi
 29d71ee:	jb     29d860f <wasm[0]::function[1009]::helper::array_packed_join+0x186f>
 29d71f4:	mov    %edi,%ebx
 29d71f6:	lea    (%r8,%rbx,1),%rdi
 29d71fa:	cmp    %rcx,%rbx
 29d71fd:	cmova  %r9,%rdi
 29d7201:	shl    $0x3,%r11d
 29d7205:	lea    0x18(%r11),%ecx
 29d7209:	sub    %ecx,%r10d
 29d720c:	sub    %r10,%rdi
 29d720f:	mov    (%rdi),%rdi
 29d7212:	mov    0x8(%rsp),%ecx
 29d7216:	bt     %r15,%rdi
 29d721a:	jb     29d7228 <wasm[0]::function[1009]::helper::array_packed_join+0x488>
 29d7220:	mov    %r13,%rsi
 29d7223:	jmp    29d73f3 <wasm[0]::function[1009]::helper::array_packed_join+0x653>
 29d7228:	mov    0xc8(%rsp),%r10
 29d7230:	mov    0x28(%r10),%rcx
 29d7234:	mov    0x20(%r10),%rdi
 29d7238:	lea    0x10(%rdi,%rsi,1),%r8
 29d723d:	xor    %rdx,%rdx
 29d7240:	cmp    %rcx,%rsi
 29d7243:	cmova  %rdx,%r8
 29d7247:	mov    (%r8),%esi
 29d724a:	cmp    %esi,%r15d
 29d724d:	jae    29d8611 <wasm[0]::function[1009]::helper::array_packed_join+0x1871>
 29d7253:	mov    %esi,%r8d
 29d7256:	shl    $0x3,%r8
 29d725a:	shr    $0x20,%r8
 29d725e:	test   %r8,%r8
 29d7261:	jne    29d8613 <wasm[0]::function[1009]::helper::array_packed_join+0x1873>
 29d7267:	mov    $0x3,%r8d
 29d726d:	mov    %r8,0x80(%rsp)
 29d7275:	shl    $0x3,%esi
 29d7278:	add    $0x18,%esi
 29d727b:	jb     29d8615 <wasm[0]::function[1009]::helper::array_packed_join+0x1875>
 29d7281:	add    %esi,%eax
 29d7283:	jb     29d8617 <wasm[0]::function[1009]::helper::array_packed_join+0x1877>
 29d7289:	mov    %eax,%r8d
 29d728c:	lea    (%rdi,%r8,1),%rax
 29d7290:	cmp    %rcx,%r8
 29d7293:	cmova  %rdx,%rax
 29d7297:	mov    %r15,%rcx
 29d729a:	shl    $0x3,%ecx
 29d729d:	add    $0x18,%ecx
 29d72a3:	sub    %ecx,%esi
 29d72a5:	sub    %rsi,%rax
 29d72a8:	mov    (%rax),%rsi
 29d72ab:	xor    %ecx,%ecx
 29d72ad:	mov    0xb8(%rsp),%rdx
 29d72b5:	jmp    29d73f3 <wasm[0]::function[1009]::helper::array_packed_join+0x653>
 29d72ba:	mov    %r13,%rsi
 29d72bd:	mov    0x40(%rsp),%eax
 29d72c1:	xor    %edx,%edx
 29d72c3:	test   %eax,%eax
 29d72c5:	je     29d8619 <wasm[0]::function[1009]::helper::array_packed_join+0x1879>
 29d72cb:	test   %eax,%eax
 29d72cd:	je     29d861b <wasm[0]::function[1009]::helper::array_packed_join+0x187b>
 29d72d3:	mov    0xc8(%rsp),%r10
 29d72db:	mov    0x28(%r10),%rcx
 29d72df:	mov    0x20(%r10),%r8
 29d72e3:	mov    %eax,%edi
 29d72e5:	lea    (%r8,%rdi,1),%rax
 29d72e9:	xor    %r9,%r9
 29d72ec:	cmp    %rcx,%rdi
 29d72ef:	cmova  %r9,%rax
 29d72f3:	mov    0x30(%rax),%eax
 29d72f6:	test   %eax,%eax
 29d72f8:	je     29d861d <wasm[0]::function[1009]::helper::array_packed_join+0x187d>
 29d72fe:	test   %eax,%eax
 29d7300:	je     29d861f <wasm[0]::function[1009]::helper::array_packed_join+0x187f>
 29d7306:	mov    %eax,%edi
 29d7308:	lea    0x10(%r8,%rdi,1),%r8
 29d730d:	cmp    %rcx,%rdi
 29d7310:	cmova  %r9,%r8
 29d7314:	mov    (%r8),%r8d
 29d7317:	mov    0x8(%rsp),%ecx
 29d731b:	mov    %r8d,%r8d
 29d731e:	cmp    %r8,%r15
 29d7321:	jae    29d73f3 <wasm[0]::function[1009]::helper::array_packed_join+0x653>
 29d7327:	mov    0xc8(%rsp),%r10
 29d732f:	mov    0x28(%r10),%rcx
 29d7333:	mov    0x20(%r10),%r8
 29d7337:	lea    0x10(%r8,%rdi,1),%r9
 29d733c:	xor    %rdx,%rdx
 29d733f:	cmp    %rcx,%rdi
 29d7342:	cmova  %rdx,%r9
 29d7346:	mov    (%r9),%edi
 29d7349:	cmp    %edi,%r15d
 29d734c:	jae    29d8621 <wasm[0]::function[1009]::helper::array_packed_join+0x1881>
 29d7352:	mov    %edi,%r9d
 29d7355:	shl    $0x2,%r9
 29d7359:	shr    $0x20,%r9
 29d735d:	test   %r9,%r9
 29d7360:	jne    29d8623 <wasm[0]::function[1009]::helper::array_packed_join+0x1883>
 29d7366:	shl    $0x2,%edi
 29d7369:	add    $0x14,%edi
 29d736c:	jb     29d8625 <wasm[0]::function[1009]::helper::array_packed_join+0x1885>
 29d7372:	add    %edi,%eax
 29d7374:	jb     29d8627 <wasm[0]::function[1009]::helper::array_packed_join+0x1887>
 29d737a:	mov    %eax,%r9d
 29d737d:	lea    (%r8,%r9,1),%rax
 29d7381:	cmp    %rcx,%r9
 29d7384:	cmova  %rdx,%rax
 29d7388:	mov    %r15,%rcx
 29d738b:	shl    $0x2,%ecx
 29d738e:	add    $0x14,%ecx
 29d7394:	sub    %ecx,%edi
 29d7396:	sub    %rdi,%rax
 29d7399:	mov    (%rax),%eax
 29d739b:	mov    0x8(%rsp),%ecx
 29d739f:	xor    %edx,%edx
 29d73a1:	test   %eax,%eax
 29d73a3:	je     29d73f3 <wasm[0]::function[1009]::helper::array_packed_join+0x653>
 29d73a9:	test   %eax,%eax
 29d73ab:	je     29d8629 <wasm[0]::function[1009]::helper::array_packed_join+0x1889>
 29d73b1:	test   %eax,%eax
 29d73b3:	je     29d862b <wasm[0]::function[1009]::helper::array_packed_join+0x188b>
 29d73b9:	mov    0xc8(%rsp),%r10
 29d73c1:	mov    0x28(%r10),%rcx
 29d73c5:	mov    0x20(%r10),%rsi
 29d73c9:	mov    %eax,%edx
 29d73cb:	lea    (%rsi,%rdx,1),%rax
 29d73cf:	xor    %rsi,%rsi
 29d73d2:	cmp    %rcx,%rdx
 29d73d5:	cmova  %rsi,%rax
 29d73d9:	mov    0x18(%rax),%ecx
 29d73dc:	mov    %rcx,0x80(%rsp)
 29d73e4:	mov    0x10(%rax),%rsi
 29d73e8:	mov    0x1c(%rax),%ecx
 29d73eb:	mov    0xb8(%rsp),%rdx
 29d73f3:	mov    0x10(%rsp),%eax
 29d73f7:	mov    (%rsp),%r8d
 29d73fb:	xor    %edi,%edi
 29d73fd:	test   %edx,%edx
 29d73ff:	je     29d8283 <wasm[0]::function[1009]::helper::array_packed_join+0x14e3>
 29d7405:	mov    0x80(%rsp),%rax
 29d740d:	cmp    $0x4,%eax
 29d7410:	je     29d7453 <wasm[0]::function[1009]::helper::array_packed_join+0x6b3>
 29d7416:	mov    0x10(%rsp),%eax
 29d741a:	mov    (%rsp),%r8d
 29d741e:	mov    0x80(%rsp),%rdx
 29d7426:	cmp    $0x1,%edx
 29d7429:	sete   %r9b
 29d742d:	xor    %edi,%edi
 29d742f:	mov    0x80(%rsp),%r10
 29d7437:	test   %r10d,%edx
 29d743a:	sete   %dl
 29d743d:	or     %edx,%r9d
 29d7440:	movzbl %r9b,%edx
 29d7444:	test   %edx,%edx
 29d7446:	je     29d8283 <wasm[0]::function[1009]::helper::array_packed_join+0x14e3>
 29d744c:	xor    %eax,%eax
 29d744e:	jmp    29d74fe <wasm[0]::function[1009]::helper::array_packed_join+0x75e>
 29d7453:	xor    %eax,%eax
 29d7455:	test   %ecx,%ecx
 29d7457:	je     29d749e <wasm[0]::function[1009]::helper::array_packed_join+0x6fe>
 29d745d:	xor    %eax,%eax
 29d745f:	test   $0x1,%ecx
 29d7465:	jne    29d749e <wasm[0]::function[1009]::helper::array_packed_join+0x6fe>
 29d746b:	mov    0xc8(%rsp),%r10
 29d7473:	mov    0x28(%r10),%rax
 29d7477:	mov    0x20(%r10),%rdx
 29d747b:	mov    %ecx,%edi
 29d747d:	lea    0x4(%rdx,%rdi,1),%rdx
 29d7482:	xor    %r8,%r8
 29d7485:	cmp    %rax,%rdi
 29d7488:	cmova  %r8,%rdx
 29d748c:	mov    (%rdx),%eax
 29d748e:	mov    0xb0(%rsp),%rdx
 29d7496:	cmp    %edx,%eax
 29d7498:	sete   %al
 29d749b:	movzbl %al,%eax
 29d749e:	test   %eax,%eax
 29d74a0:	je     29d862d <wasm[0]::function[1009]::helper::array_packed_join+0x188d>
 29d74a6:	test   %ecx,%ecx
 29d74a8:	je     29d862f <wasm[0]::function[1009]::helper::array_packed_join+0x188f>
 29d74ae:	test   %ecx,%ecx
 29d74b0:	je     29d8631 <wasm[0]::function[1009]::helper::array_packed_join+0x1891>
 29d74b6:	mov    0xc8(%rsp),%r10
 29d74be:	mov    0x28(%r10),%rax
 29d74c2:	mov    0x20(%r10),%rdx
 29d74c6:	mov    %ecx,%r9d
 29d74c9:	lea    (%rdx,%r9,1),%r8
 29d74cd:	xor    %rdi,%rdi
 29d74d0:	cmp    %rax,%r9
 29d74d3:	cmova  %rdi,%r8
 29d74d7:	mov    0x10(%r8),%r8d
 29d74db:	test   %r8d,%r8d
 29d74de:	je     29d8633 <wasm[0]::function[1009]::helper::array_packed_join+0x1893>
 29d74e4:	test   %r8d,%r8d
 29d74e7:	je     29d8635 <wasm[0]::function[1009]::helper::array_packed_join+0x1895>
 29d74ed:	mov    %r8d,%r8d
 29d74f0:	lea    0x10(%rdx,%r8,1),%rdx
 29d74f5:	cmp    %rax,%r8
 29d74f8:	cmova  %rdi,%rdx
 29d74fc:	mov    (%rdx),%eax
 29d74fe:	test   %r15,%r15
 29d7501:	je     29d7512 <wasm[0]::function[1009]::helper::array_packed_join+0x772>
 29d7507:	mov    0xa8(%rsp),%rdx
 29d750f:	add    %rdx,%r14
 29d7512:	mov    %eax,%eax
 29d7514:	add    %rax,%r14
 29d7517:	cmp    0x118a(%rip),%r14        # 29d86a8 <wasm[0]::function[1009]::helper::array_packed_join+0x1908>
 29d751e:	jbe    29d752e <wasm[0]::function[1009]::helper::array_packed_join+0x78e>
 29d7524:	movabs $0x100000000,%r14
 29d752e:	mov    0x38(%rsp),%edx
 29d7532:	mov    0x10(%rsp),%eax
 29d7536:	mov    (%rsp),%edi
 29d7539:	add    $0x1,%r15
 29d7540:	mov    %rsi,%r13
 29d7543:	jmp    29d708b <wasm[0]::function[1009]::helper::array_packed_join+0x2eb>
 29d7548:	cmp    0x1159(%rip),%r14        # 29d86a8 <wasm[0]::function[1009]::helper::array_packed_join+0x1908>
 29d754f:	ja     29d8637 <wasm[0]::function[1009]::helper::array_packed_join+0x1897>
 29d7555:	test   %r14,%r14
 29d7558:	je     29d825e <wasm[0]::function[1009]::helper::array_packed_join+0x14be>
 29d755e:	mov    0x68(%rsp),%rcx
 29d7563:	cmp    $0x1,%rcx
 29d7567:	je     29d8251 <wasm[0]::function[1009]::helper::array_packed_join+0x14b1>
 29d756d:	mov    %r14d,%r13d
 29d7570:	mov    %r13,%rcx
 29d7573:	shl    $1,%rcx
 29d7576:	mov    %rcx,%rax
 29d7579:	shr    $0x20,%rax
 29d757d:	mov    %rcx,0x70(%rsp)
 29d7582:	test   %rax,%rax
 29d7585:	jne    29d8639 <wasm[0]::function[1009]::helper::array_packed_join+0x1899>
 29d758b:	mov    %r14,%rcx
 29d758e:	shl    $1,%ecx
 29d7590:	add    $0x14,%ecx
 29d7593:	jb     29d863b <wasm[0]::function[1009]::helper::array_packed_join+0x189b>
 29d7599:	mov    0x60(%rsp),%rsi
 29d759e:	mov    0x20(%rsi),%rdi
 29d75a2:	mov    (%rdi),%eax
 29d75a4:	mov    %eax,%edx
 29d75a6:	mov    %ecx,%esi
 29d75a8:	add    $0xf,%rsi
 29d75af:	mov    %rsi,%r8
 29d75b2:	and    $0xfffffffffffffff0,%r8
 29d75b6:	add    %rdx,%r8
 29d75b9:	mov    0x4(%rdi),%r9d
 29d75bd:	mov    %rdi,0xa0(%rsp)
 29d75c5:	cmp    %r9,%r8
 29d75c8:	ja     29d8389 <wasm[0]::function[1009]::helper::array_packed_join+0x15e9>
 29d75ce:	mov    %r12,%rdi
 29d75d1:	add    $0xf,%ecx
 29d75d7:	and    $0xfffffff0,%ecx
 29d75da:	add    %eax,%ecx
 29d75dc:	mov    0xa0(%rsp),%r15
 29d75e4:	mov    %ecx,(%r15)
 29d75e7:	mov    0xc8(%rsp),%r10
 29d75ef:	mov    0x20(%r10),%r8
 29d75f3:	lea    (%r8,%rdx,1),%rcx
 29d75f7:	movl   $0xa8000006,(%r8,%rdx,1)
 29d75ff:	mov    0x238(%rdi),%edi
 29d7605:	mov    %edi,0x4(%r8,%rdx,1)
 29d760a:	and    $0xfffffffffffffff0,%rsi
 29d760e:	mov    %esi,0x8(%r8,%rdx,1)
 29d7613:	mov    %eax,0x10(%rsp)
 29d7617:	mov    %r14d,0x10(%rcx)
 29d761b:	test   %eax,%eax
 29d761d:	je     29d863d <wasm[0]::function[1009]::helper::array_packed_join+0x189d>
 29d7623:	mov    0xc8(%rsp),%r10
 29d762b:	mov    0x28(%r10),%rsi
 29d762f:	mov    0x20(%r10),%rdi
 29d7633:	mov    %eax,%r8d
 29d7636:	lea    0x10(%rdi,%r8,1),%r9
 29d763b:	xor    %r10,%r10
 29d763e:	cmp    %rsi,%r8
 29d7641:	cmova  %r10,%r9
 29d7645:	mov    (%r9),%r9d
 29d7648:	cmp    %r9,%r13
 29d764b:	ja     29d863f <wasm[0]::function[1009]::helper::array_packed_join+0x189f>
 29d7651:	lea    0x14(%rdi,%r8,1),%r10
 29d7656:	mov    0x70(%rsp),%r8
 29d765b:	mov    %r10,%r9
 29d765e:	add    %r8,%r9
 29d7661:	mov    %r10,%r12
 29d7664:	jb     29d8641 <wasm[0]::function[1009]::helper::array_packed_join+0x18a1>
 29d766a:	lea    (%rdi,%rsi,1),%r10
 29d766e:	cmp    %r10,%r9
 29d7671:	ja     29d8643 <wasm[0]::function[1009]::helper::array_packed_join+0x18a3>
 29d7677:	mov    0x38(%rsp),%esi
 29d767b:	mov    0x40(%rsp),%edx
 29d767f:	mov    0x8(%rsp),%ecx
 29d7683:	mov    (%rsp),%eax
 29d7686:	cmp    $0x8000000,%r8
 29d768d:	jbe    29d7713 <wasm[0]::function[1009]::helper::array_packed_join+0x973>
 29d7693:	mov    %esi,0x18(%rsp)
 29d7697:	mov    %edx,0x30(%rsp)
 29d769b:	mov    %ecx,0x40(%rsp)
 29d769f:	mov    %eax,0x38(%rsp)
 29d76a3:	mov    0xd0(%rsp),%r14
 29d76ab:	mov    (%r14),%rax
 29d76ae:	mov    0x88(%rsp),%rcx
 29d76b6:	cmp    %rcx,%rax
 29d76b9:	jae    29d83ba <wasm[0]::function[1009]::helper::array_packed_join+0x161a>
 29d76bf:	xor    %edx,%edx
 29d76c1:	mov    $0x8000000,%ecx
 29d76c6:	mov    %r12,%rsi
 29d76c9:	mov    0x60(%rsp),%rdi
 29d76ce:	call   3018cc3 <wasmtime_builtin_memory_fill>
 29d76d3:	mov    0x18(%rsp),%esi
 29d76d7:	mov    0x30(%rsp),%edx
 29d76db:	mov    0x40(%rsp),%ecx
 29d76df:	mov    0x38(%rsp),%eax
 29d76e3:	mov    0x70(%rsp),%rdi
 29d76e8:	sub    $0x8000000,%rdi
 29d76ef:	mov    %rdi,0x70(%rsp)
 29d76f4:	mov    %r12,%rdi
 29d76f7:	add    $0x8000000,%rdi
 29d76fe:	mov    0x70(%rsp),%r8
 29d7703:	mov    %rdi,%r12
 29d7706:	cmp    $0x8000000,%r8
 29d770d:	ja     29d7693 <wasm[0]::function[1009]::helper::array_packed_join+0x8f3>
 29d7713:	mov    %esi,0x38(%rsp)
 29d7717:	mov    %edx,0x40(%rsp)
 29d771b:	mov    %ecx,0x30(%rsp)
 29d771f:	mov    %eax,0x18(%rsp)
 29d7723:	mov    0xd0(%rsp),%r14
 29d772b:	mov    (%r14),%rax
 29d772e:	mov    0x88(%rsp),%rsi
 29d7736:	cmp    %rsi,%rax
 29d7739:	jae    29d83ee <wasm[0]::function[1009]::helper::array_packed_join+0x164e>
 29d773f:	xor    %ebx,%ebx
 29d7741:	mov    0x70(%rsp),%rcx
 29d7746:	mov    %r12,%rsi
 29d7749:	mov    %rbx,%rdx
 29d774c:	mov    0x60(%rsp),%rdi
 29d7751:	call   3018cc3 <wasmtime_builtin_memory_fill>
 29d7756:	mov    %rbx,0x78(%rsp)
 29d775b:	mov    0x10(%rsp),%ecx
 29d775f:	mov    0x38(%rsp),%edx
 29d7763:	mov    0x40(%rsp),%eax
 29d7767:	mov    0x30(%rsp),%edi
 29d776b:	mov    0x18(%rsp),%esi
 29d776f:	xor    %r12,%r12
 29d7772:	mov    0xa8(%rsp),%r13
 29d777a:	mov    %r12,0x70(%rsp)
 29d777f:	shl    $1,%r13
 29d7782:	mov    %r13,0x98(%rsp)
 29d778a:	mov    %ecx,0x18(%rsp)
 29d778e:	mov    %edx,0x30(%rsp)
 29d7792:	mov    %eax,0x40(%rsp)
 29d7796:	mov    %edi,0x38(%rsp)
 29d779a:	mov    %esi,0x10(%rsp)
 29d779e:	mov    0xd0(%rsp),%r14
 29d77a6:	mov    (%r14),%rax
 29d77a9:	mov    0x88(%rsp),%rcx
 29d77b1:	cmp    %rcx,%rax
 29d77b4:	jae    29d8425 <wasm[0]::function[1009]::helper::array_packed_join+0x1685>
 29d77ba:	mov    0x68(%rsp),%rcx
 29d77bf:	mov    0x70(%rsp),%r12
 29d77c4:	jmp    29d77d3 <wasm[0]::function[1009]::helper::array_packed_join+0xa33>
 29d77c9:	mov    0x68(%rsp),%rcx
 29d77ce:	mov    0x70(%rsp),%r12
 29d77d3:	mov    0x68(%rsp),%rcx
 29d77d8:	cmp    %rcx,%r12
 29d77db:	jae    29d81d3 <wasm[0]::function[1009]::helper::array_packed_join+0x1433>
 29d77e1:	mov    0x40(%rsp),%eax
 29d77e5:	mov    0x38(%rsp),%edi
 29d77e9:	mov    0x18(%rsp),%ecx
 29d77ed:	mov    0x30(%rsp),%edx
 29d77f1:	mov    0x10(%rsp),%esi
 29d77f5:	mov    0x70(%rsp),%r8
 29d77fa:	mov    0x70(%rsp),%r12
 29d77ff:	test   %r8,%r12
 29d7802:	je     29d7b4d <wasm[0]::function[1009]::helper::array_packed_join+0xdad>
 29d7808:	mov    0x18(%rsp),%eax
 29d780c:	test   %eax,%eax
 29d780e:	je     29d8645 <wasm[0]::function[1009]::helper::array_packed_join+0x18a5>
 29d7814:	mov    0x30(%rsp),%ecx
 29d7818:	test   %ecx,%ecx
 29d781a:	je     29d8647 <wasm[0]::function[1009]::helper::array_packed_join+0x18a7>
 29d7820:	test   %eax,%eax
 29d7822:	je     29d8649 <wasm[0]::function[1009]::helper::array_packed_join+0x18a9>
 29d7828:	mov    0xc8(%rsp),%r10
 29d7830:	mov    0x28(%r10),%rdi
 29d7834:	mov    0x20(%r10),%rsi
 29d7838:	mov    %eax,%r10d
 29d783b:	lea    (%rsi,%r10,1),%r8
 29d783f:	lea    0x10(%rsi,%r10,1),%rdx
 29d7844:	xor    %r9,%r9
 29d7847:	cmp    %rdi,%r10
 29d784a:	cmova  %r9,%rdx
 29d784e:	mov    0x78(%rsp),%r13
 29d7853:	mov    %r13d,%r11d
 29d7856:	mov    0xa8(%rsp),%rax
 29d785e:	lea    (%r11,%rax,1),%r10
 29d7862:	mov    (%rdx),%eax
 29d7864:	cmp    %rax,%r10
 29d7867:	ja     29d864b <wasm[0]::function[1009]::helper::array_packed_join+0x18ab>
 29d786d:	test   %ecx,%ecx
 29d786f:	je     29d864d <wasm[0]::function[1009]::helper::array_packed_join+0x18ad>
 29d7875:	mov    %ecx,%eax
 29d7877:	lea    (%rsi,%rax,1),%r10
 29d787b:	lea    0x10(%rsi,%rax,1),%rcx
 29d7880:	cmp    %rdi,%rax
 29d7883:	cmova  %r9,%rcx
 29d7887:	mov    (%rcx),%ecx
 29d7889:	mov    0xa8(%rsp),%r9
 29d7891:	cmp    %rcx,%r9
 29d7894:	ja     29d864f <wasm[0]::function[1009]::helper::array_packed_join+0x18af>
 29d789a:	lea    0x14(%r8,%r11,2),%r8
 29d789f:	mov    0x98(%rsp),%r11
 29d78a7:	mov    %r8,%rdx
 29d78aa:	add    %r11,%rdx
 29d78ad:	jb     29d8651 <wasm[0]::function[1009]::helper::array_packed_join+0x18b1>
 29d78b3:	lea    (%rsi,%rdi,1),%rcx
 29d78b7:	cmp    %rcx,%rdx
 29d78ba:	ja     29d8653 <wasm[0]::function[1009]::helper::array_packed_join+0x18b3>
 29d78c0:	lea    0x14(%rsi,%rax,1),%r9
 29d78c5:	mov    0x98(%rsp),%rdx
 29d78cd:	mov    %r9,%rax
 29d78d0:	add    %rdx,%rax
 29d78d3:	jb     29d8655 <wasm[0]::function[1009]::helper::array_packed_join+0x18b5>
 29d78d9:	cmp    %rcx,%rax
 29d78dc:	ja     29d8657 <wasm[0]::function[1009]::helper::array_packed_join+0x18b7>
 29d78e2:	cmp    %r8,%r9
 29d78e5:	ja     29d79f6 <wasm[0]::function[1009]::helper::array_packed_join+0xc56>
 29d78eb:	mov    0x40(%rsp),%eax
 29d78ef:	mov    0x38(%rsp),%ecx
 29d78f3:	mov    0x18(%rsp),%edx
 29d78f7:	mov    0x30(%rsp),%esi
 29d78fb:	mov    0x10(%rsp),%edi
 29d78ff:	mov    0xa8(%rsp),%r9
 29d7907:	lea    (%r8,%r9,2),%r8
 29d790b:	mov    %r8,%rbx
 29d790e:	mov    0xa8(%rsp),%r8
 29d7916:	lea    0x14(%r10,%r8,2),%r9
 29d791b:	mov    0x98(%rsp),%r8
 29d7923:	mov    %r9,%r12
 29d7926:	cmp    $0x8000000,%r8
 29d792d:	jbe    29d7940 <wasm[0]::function[1009]::helper::array_packed_join+0xba0>
 29d7933:	mov    0x98(%rsp),%r15
 29d793b:	jmp    29d7950 <wasm[0]::function[1009]::helper::array_packed_join+0xbb0>
 29d7940:	mov    0x98(%rsp),%r8
 29d7948:	mov    %rbx,%r9
 29d794b:	jmp    29d79df <wasm[0]::function[1009]::helper::array_packed_join+0xc3f>
 29d7950:	mov    %eax,0x28(%rsp)
 29d7954:	mov    %ecx,0x20(%rsp)
 29d7958:	mov    %edx,0x48(%rsp)
 29d795c:	mov    %esi,0x50(%rsp)
 29d7960:	mov    %edi,0x58(%rsp)
 29d7964:	mov    0xd0(%rsp),%r14
 29d796c:	mov    (%r14),%rax
 29d796f:	mov    0x88(%rsp),%rcx
 29d7977:	cmp    %rcx,%rax
 29d797a:	jae    29d8463 <wasm[0]::function[1009]::helper::array_packed_join+0x16c3>
 29d7980:	mov    $0x8000000,%ecx
 29d7985:	mov    %rbx,%rsi
 29d7988:	sub    $0x8000000,%rsi
 29d798f:	mov    %r12,%rdx
 29d7992:	mov    %rsi,%rbx
 29d7995:	sub    $0x8000000,%rdx
 29d799c:	mov    %rdx,%r12
 29d799f:	mov    0x60(%rsp),%rdi
 29d79a4:	call   3018c9a <wasmtime_builtin_memory_copy>
 29d79a9:	mov    0x28(%rsp),%eax
 29d79ad:	mov    0x20(%rsp),%ecx
 29d79b1:	mov    0x48(%rsp),%edx
 29d79b5:	mov    0x50(%rsp),%esi
 29d79b9:	mov    0x58(%rsp),%edi
 29d79bd:	mov    %r15,%r8
 29d79c0:	sub    $0x8000000,%r8
 29d79c7:	cmp    $0x8000000,%r8
 29d79ce:	jbe    29d79dc <wasm[0]::function[1009]::helper::array_packed_join+0xc3c>
 29d79d4:	mov    %r8,%r15
 29d79d7:	jmp    29d7950 <wasm[0]::function[1009]::helper::array_packed_join+0xbb0>
 29d79dc:	mov    %rbx,%r9
 29d79df:	sub    %r8,%r9
 29d79e2:	mov    %r9,%rbx
 29d79e5:	mov    %r12,%r9
 29d79e8:	sub    %r8,%r9
 29d79eb:	mov    %r9,%r12
 29d79ee:	mov    %r8,%r15
 29d79f1:	jmp    29d7acf <wasm[0]::function[1009]::helper::array_packed_join+0xd2f>
 29d79f6:	mov    %r8,%rbx
 29d79f9:	mov    %r9,%r12
 29d79fc:	mov    0x40(%rsp),%eax
 29d7a00:	mov    0x38(%rsp),%ecx
 29d7a04:	mov    0x18(%rsp),%edx
 29d7a08:	mov    0x30(%rsp),%esi
 29d7a0c:	mov    0x10(%rsp),%edi
 29d7a10:	mov    0x98(%rsp),%r8
 29d7a18:	cmp    $0x8000000,%r8
 29d7a1f:	jbe    29d7a32 <wasm[0]::function[1009]::helper::array_packed_join+0xc92>
 29d7a25:	mov    0x98(%rsp),%r15
 29d7a2d:	jmp    29d7a3f <wasm[0]::function[1009]::helper::array_packed_join+0xc9f>
 29d7a32:	mov    0x98(%rsp),%r15
 29d7a3a:	jmp    29d7acf <wasm[0]::function[1009]::helper::array_packed_join+0xd2f>
 29d7a3f:	mov    %eax,0x20(%rsp)
 29d7a43:	mov    %ecx,0x28(%rsp)
 29d7a47:	mov    %edx,0x30(%rsp)
 29d7a4b:	mov    %esi,0x38(%rsp)
 29d7a4f:	mov    %edi,0x40(%rsp)
 29d7a53:	mov    0xd0(%rsp),%r14
 29d7a5b:	mov    (%r14),%rax
 29d7a5e:	mov    0x88(%rsp),%rcx
 29d7a66:	cmp    %rcx,%rax
 29d7a69:	jae    29d8497 <wasm[0]::function[1009]::helper::array_packed_join+0x16f7>
 29d7a6f:	mov    $0x8000000,%ecx
 29d7a74:	mov    %r12,%rdx
 29d7a77:	mov    %rbx,%rsi
 29d7a7a:	mov    0x60(%rsp),%rdi
 29d7a7f:	call   3018c9a <wasmtime_builtin_memory_copy>
 29d7a84:	mov    0x20(%rsp),%eax
 29d7a88:	mov    0x28(%rsp),%ecx
 29d7a8c:	mov    0x30(%rsp),%edx
 29d7a90:	mov    0x38(%rsp),%esi
 29d7a94:	mov    0x40(%rsp),%edi
 29d7a98:	mov    %r15,%r8
 29d7a9b:	sub    $0x8000000,%r8
 29d7aa2:	mov    %r8,%r15
 29d7aa5:	mov    %rbx,%r8
 29d7aa8:	add    $0x8000000,%r8
 29d7aaf:	mov    %r8,%rbx
 29d7ab2:	mov    %r12,%r8
 29d7ab5:	add    $0x8000000,%r8
 29d7abc:	mov    %r8,%r12
 29d7abf:	mov    %r15,%r8
 29d7ac2:	cmp    $0x8000000,%r8
 29d7ac9:	ja     29d7a3f <wasm[0]::function[1009]::helper::array_packed_join+0xc9f>
 29d7acf:	mov    %eax,0x40(%rsp)
 29d7ad3:	mov    %ecx,0x38(%rsp)
 29d7ad7:	mov    %edx,0x30(%rsp)
 29d7adb:	mov    %esi,0x28(%rsp)
 29d7adf:	mov    %edi,0x20(%rsp)
 29d7ae3:	mov    0xd0(%rsp),%r14
 29d7aeb:	mov    (%r14),%rsi
 29d7aee:	mov    0x88(%rsp),%rax
 29d7af6:	cmp    %rax,%rsi
 29d7af9:	jae    29d84cb <wasm[0]::function[1009]::helper::array_packed_join+0x172b>
 29d7aff:	mov    %r15,%rcx
 29d7b02:	mov    %r12,%rdx
 29d7b05:	mov    %rbx,%rsi
 29d7b08:	jmp    29d7b16 <wasm[0]::function[1009]::helper::array_packed_join+0xd76>
 29d7b0d:	mov    %r15,%rcx
 29d7b10:	mov    %r12,%rdx
 29d7b13:	mov    %rbx,%rsi
 29d7b16:	mov    %r15,%rcx
 29d7b19:	mov    %r12,%rdx
 29d7b1c:	mov    %rbx,%rsi
 29d7b1f:	mov    0x60(%rsp),%rdi
 29d7b24:	call   3018c9a <wasmtime_builtin_memory_copy>
 29d7b29:	mov    0x40(%rsp),%eax
 29d7b2d:	mov    0x38(%rsp),%edi
 29d7b31:	mov    0x30(%rsp),%ecx
 29d7b35:	mov    0x28(%rsp),%edx
 29d7b39:	mov    0x20(%rsp),%esi
 29d7b3d:	mov    0xc0(%rsp),%r8
 29d7b45:	add    %r8d,%r13d
 29d7b48:	mov    %r13,0x78(%rsp)
 29d7b4d:	test   %eax,%eax
 29d7b4f:	je     29d8659 <wasm[0]::function[1009]::helper::array_packed_join+0x18b9>
 29d7b55:	test   %eax,%eax
 29d7b57:	je     29d865b <wasm[0]::function[1009]::helper::array_packed_join+0x18bb>
 29d7b5d:	mov    0xc8(%rsp),%r10
 29d7b65:	mov    0x28(%r10),%r9
 29d7b69:	mov    %eax,%r8d
 29d7b6c:	mov    0xc8(%rsp),%r11
 29d7b74:	mov    %r8,%r10
 29d7b77:	add    0x20(%r11),%r10
 29d7b7b:	xor    %r11,%r11
 29d7b7e:	cmp    %r9,%r8
 29d7b81:	cmova  %r11,%r10
 29d7b85:	mov    0x24(%r10),%r9d
 29d7b89:	cmp    $0x3,%r9d
 29d7b8d:	je     29d7d32 <wasm[0]::function[1009]::helper::array_packed_join+0xf92>
 29d7b93:	mov    0xc8(%rsp),%r10
 29d7b9b:	mov    0x28(%r10),%r11
 29d7b9f:	mov    0x20(%r10),%r13
 29d7ba3:	lea    0x0(%r13,%r8,1),%r9
 29d7ba8:	xor    %rbx,%rbx
 29d7bab:	cmp    %r11,%r8
 29d7bae:	cmova  %rbx,%r9
 29d7bb2:	mov    0x28(%r9),%r8d
 29d7bb6:	mov    0x2c(%r9),%r10d
 29d7bba:	test   %r8d,%r8d
 29d7bbd:	je     29d865d <wasm[0]::function[1009]::helper::array_packed_join+0x18bd>
 29d7bc3:	test   %r8d,%r8d
 29d7bc6:	je     29d865f <wasm[0]::function[1009]::helper::array_packed_join+0x18bf>
 29d7bcc:	mov    %r8d,%r9d
 29d7bcf:	lea    0x10(%r13,%r9,1),%r13
 29d7bd4:	cmp    %r11,%r9
 29d7bd7:	cmova  %rbx,%r13
 29d7bdb:	mov    0x0(%r13),%r11d
 29d7bdf:	mov    0x70(%rsp),%r12
 29d7be4:	cmp    %r11,%r12
 29d7be7:	jae    29d7d25 <wasm[0]::function[1009]::helper::array_packed_join+0xf85>
 29d7bed:	test   %r10d,%r10d
 29d7bf0:	je     29d8661 <wasm[0]::function[1009]::helper::array_packed_join+0x18c1>
 29d7bf6:	test   %r10d,%r10d
 29d7bf9:	je     29d8663 <wasm[0]::function[1009]::helper::array_packed_join+0x18c3>
 29d7bff:	mov    0xc8(%rsp),%r11
 29d7c07:	mov    0x28(%r11),%r11
 29d7c0b:	mov    0xc8(%rsp),%r14
 29d7c13:	mov    0x20(%r14),%r13
 29d7c17:	mov    %r10d,%r14d
 29d7c1a:	lea    0x10(%r13,%r14,1),%rbx
 29d7c1f:	xor    %r15,%r15
 29d7c22:	cmp    %r11,%r14
 29d7c25:	cmova  %r15,%rbx
 29d7c29:	mov    (%rbx),%ebx
 29d7c2b:	mov    0x70(%rsp),%r12
 29d7c30:	mov    %r12,%r14
 29d7c33:	shr    $0x6,%r14d
 29d7c37:	cmp    %ebx,%r14d
 29d7c3a:	jae    29d8665 <wasm[0]::function[1009]::helper::array_packed_join+0x18c5>
 29d7c40:	mov    %ebx,%r12d
 29d7c43:	shl    $0x3,%r12
 29d7c47:	shr    $0x20,%r12
 29d7c4b:	test   %r12,%r12
 29d7c4e:	jne    29d8667 <wasm[0]::function[1009]::helper::array_packed_join+0x18c7>
 29d7c54:	shl    $0x3,%ebx
 29d7c57:	add    $0x18,%ebx
 29d7c5a:	jb     29d8669 <wasm[0]::function[1009]::helper::array_packed_join+0x18c9>
 29d7c60:	add    %ebx,%r10d
 29d7c63:	jb     29d866b <wasm[0]::function[1009]::helper::array_packed_join+0x18cb>
 29d7c69:	mov    %r10d,%r12d
 29d7c6c:	lea    0x0(%r13,%r12,1),%r10
 29d7c71:	cmp    %r11,%r12
 29d7c74:	cmova  %r15,%r10
 29d7c78:	shl    $0x3,%r14d
 29d7c7c:	lea    0x18(%r14),%r11d
 29d7c80:	sub    %r11d,%ebx
 29d7c83:	sub    %rbx,%r10
 29d7c86:	mov    (%r10),%r10
 29d7c89:	mov    0x70(%rsp),%r12
 29d7c8e:	bt     %r12,%r10
 29d7c92:	jae    29d7d25 <wasm[0]::function[1009]::helper::array_packed_join+0xf85>
 29d7c98:	mov    0xc8(%rsp),%r10
 29d7ca0:	mov    0x28(%r10),%rdi
 29d7ca4:	mov    0x20(%r10),%r11
 29d7ca8:	lea    0x10(%r11,%r9,1),%rbx
 29d7cad:	xor    %r10,%r10
 29d7cb0:	cmp    %rdi,%r9
 29d7cb3:	cmova  %r10,%rbx
 29d7cb7:	mov    (%rbx),%r9d
 29d7cba:	mov    0x70(%rsp),%r12
 29d7cbf:	cmp    %r9d,%r12d
 29d7cc2:	jae    29d866d <wasm[0]::function[1009]::helper::array_packed_join+0x18cd>
 29d7cc8:	mov    %r9d,%ebx
 29d7ccb:	shl    $0x3,%rbx
 29d7ccf:	shr    $0x20,%rbx
 29d7cd3:	test   %rbx,%rbx
 29d7cd6:	jne    29d866f <wasm[0]::function[1009]::helper::array_packed_join+0x18cf>
 29d7cdc:	mov    $0x3,%ebx
 29d7ce1:	mov    %rbx,0x80(%rsp)
 29d7ce9:	shl    $0x3,%r9d
 29d7ced:	add    $0x18,%r9d
 29d7cf1:	jb     29d8671 <wasm[0]::function[1009]::helper::array_packed_join+0x18d1>
 29d7cf7:	add    %r9d,%r8d
 29d7cfa:	jb     29d8673 <wasm[0]::function[1009]::helper::array_packed_join+0x18d3>
 29d7d00:	mov    %r8d,%ebx
 29d7d03:	lea    (%r11,%rbx,1),%r8
 29d7d07:	cmp    %rdi,%rbx
 29d7d0a:	cmova  %r10,%r8
 29d7d0e:	mov    %r12,%rdi
 29d7d11:	shl    $0x3,%edi
 29d7d14:	add    $0x18,%edi
 29d7d1a:	sub    %edi,%r9d
 29d7d1d:	sub    %r9,%r8
 29d7d20:	mov    (%r8),%rdi
 29d7d23:	xor    %edi,%edi
 29d7d25:	mov    0x80(%rsp),%r8
 29d7d2d:	jmp    29d7e61 <wasm[0]::function[1009]::helper::array_packed_join+0x10c1>
 29d7d32:	mov    0xc8(%rsp),%r10
 29d7d3a:	mov    0x28(%r10),%r9
 29d7d3e:	mov    0x20(%r10),%r11
 29d7d42:	lea    (%r11,%r8,1),%rbx
 29d7d46:	xor    %r10,%r10
 29d7d49:	cmp    %r9,%r8
 29d7d4c:	cmova  %r10,%rbx
 29d7d50:	mov    0x30(%rbx),%r8d
 29d7d54:	test   %r8d,%r8d
 29d7d57:	je     29d8675 <wasm[0]::function[1009]::helper::array_packed_join+0x18d5>
 29d7d5d:	test   %r8d,%r8d
 29d7d60:	je     29d8677 <wasm[0]::function[1009]::helper::array_packed_join+0x18d7>
 29d7d66:	mov    %r8d,%r13d
 29d7d69:	lea    0x10(%r11,%r13,1),%r11
 29d7d6e:	cmp    %r9,%r13
 29d7d71:	cmova  %r10,%r11
 29d7d75:	mov    (%r11),%r9d
 29d7d78:	mov    0x70(%rsp),%r12
 29d7d7d:	cmp    %r9,%r12
 29d7d80:	jae    29d7e59 <wasm[0]::function[1009]::helper::array_packed_join+0x10b9>
 29d7d86:	mov    0xc8(%rsp),%r10
 29d7d8e:	mov    0x28(%r10),%r9
 29d7d92:	mov    0x20(%r10),%rbx
 29d7d96:	lea    0x10(%rbx,%r13,1),%r11
 29d7d9b:	xor    %r10,%r10
 29d7d9e:	cmp    %r9,%r13
 29d7da1:	cmova  %r10,%r11
 29d7da5:	mov    (%r11),%r11d
 29d7da8:	mov    0x70(%rsp),%r12
 29d7dad:	cmp    %r11d,%r12d
 29d7db0:	jae    29d8679 <wasm[0]::function[1009]::helper::array_packed_join+0x18d9>
 29d7db6:	mov    %r11d,%r12d
 29d7db9:	shl    $0x2,%r12
 29d7dbd:	shr    $0x20,%r12
 29d7dc1:	test   %r12,%r12
 29d7dc4:	jne    29d867b <wasm[0]::function[1009]::helper::array_packed_join+0x18db>
 29d7dca:	shl    $0x2,%r11d
 29d7dce:	add    $0x14,%r11d
 29d7dd2:	jb     29d867d <wasm[0]::function[1009]::helper::array_packed_join+0x18dd>
 29d7dd8:	add    %r11d,%r8d
 29d7ddb:	jb     29d867f <wasm[0]::function[1009]::helper::array_packed_join+0x18df>
 29d7de1:	mov    %r8d,%r12d
 29d7de4:	lea    (%rbx,%r12,1),%r8
 29d7de8:	cmp    %r9,%r12
 29d7deb:	cmova  %r10,%r8
 29d7def:	mov    0x70(%rsp),%r12
 29d7df4:	mov    %r12,%r9
 29d7df7:	shl    $0x2,%r9d
 29d7dfb:	add    $0x14,%r9d
 29d7e02:	sub    %r9d,%r11d
 29d7e05:	sub    %r11,%r8
 29d7e08:	mov    (%r8),%r11d
 29d7e0b:	test   %r11d,%r11d
 29d7e0e:	je     29d7e59 <wasm[0]::function[1009]::helper::array_packed_join+0x10b9>
 29d7e14:	test   %r11d,%r11d
 29d7e17:	je     29d8681 <wasm[0]::function[1009]::helper::array_packed_join+0x18e1>
 29d7e1d:	test   %r11d,%r11d
 29d7e20:	je     29d8683 <wasm[0]::function[1009]::helper::array_packed_join+0x18e3>
 29d7e26:	mov    0xc8(%rsp),%r10
 29d7e2e:	mov    0x28(%r10),%r8
 29d7e32:	mov    0x20(%r10),%rdi
 29d7e36:	mov    %r11d,%r9d
 29d7e39:	add    %r9,%rdi
 29d7e3c:	xor    %r10,%r10
 29d7e3f:	cmp    %r8,%r9
 29d7e42:	cmova  %r10,%rdi
 29d7e46:	mov    0x18(%rdi),%r8d
 29d7e4a:	mov    %r8,0x80(%rsp)
 29d7e52:	mov    0x10(%rdi),%r8
 29d7e56:	mov    0x1c(%rdi),%edi
 29d7e59:	mov    0x80(%rsp),%r8
 29d7e61:	cmp    $0x4,%r8d
 29d7e65:	je     29d7e75 <wasm[0]::function[1009]::helper::array_packed_join+0x10d5>
 29d7e6b:	mov    0x70(%rsp),%r12
 29d7e70:	jmp    29d81c2 <wasm[0]::function[1009]::helper::array_packed_join+0x1422>
 29d7e75:	xor    %r8d,%r8d
 29d7e78:	test   %edi,%edi
 29d7e7a:	je     29d7ec7 <wasm[0]::function[1009]::helper::array_packed_join+0x1127>
 29d7e80:	xor    %r8d,%r8d
 29d7e83:	test   $0x1,%edi
 29d7e89:	jne    29d7ec7 <wasm[0]::function[1009]::helper::array_packed_join+0x1127>
 29d7e8f:	mov    0xc8(%rsp),%r10
 29d7e97:	mov    0x28(%r10),%r8
 29d7e9b:	mov    0x20(%r10),%r9
 29d7e9f:	mov    %edi,%r10d
 29d7ea2:	lea    0x4(%r9,%r10,1),%r9
 29d7ea7:	xor    %r11,%r11
 29d7eaa:	cmp    %r8,%r10
 29d7ead:	cmova  %r11,%r9
 29d7eb1:	mov    (%r9),%r8d
 29d7eb4:	mov    0xb0(%rsp),%r9
 29d7ebc:	cmp    %r9d,%r8d
 29d7ebf:	sete   %r8b
 29d7ec3:	movzbl %r8b,%r8d
 29d7ec7:	test   %r8d,%r8d
 29d7eca:	je     29d8685 <wasm[0]::function[1009]::helper::array_packed_join+0x18e5>
 29d7ed0:	test   %edi,%edi
 29d7ed2:	je     29d8687 <wasm[0]::function[1009]::helper::array_packed_join+0x18e7>
 29d7ed8:	test   %edi,%edi
 29d7eda:	je     29d8689 <wasm[0]::function[1009]::helper::array_packed_join+0x18e9>
 29d7ee0:	mov    0xc8(%rsp),%r10
 29d7ee8:	mov    0x28(%r10),%r9
 29d7eec:	mov    0x20(%r10),%r8
 29d7ef0:	mov    %edi,%r11d
 29d7ef3:	lea    (%r8,%r11,1),%r10
 29d7ef7:	xor    %r13,%r13
 29d7efa:	cmp    %r9,%r11
 29d7efd:	cmova  %r13,%r10
 29d7f01:	mov    0x10(%r10),%r10d
 29d7f05:	test   %r10d,%r10d
 29d7f08:	je     29d868b <wasm[0]::function[1009]::helper::array_packed_join+0x18eb>
 29d7f0e:	test   %r10d,%r10d
 29d7f11:	je     29d868d <wasm[0]::function[1009]::helper::array_packed_join+0x18ed>
 29d7f17:	mov    %r10d,%r11d
 29d7f1a:	lea    (%r8,%r11,1),%r10
 29d7f1e:	lea    0x10(%r8,%r11,1),%rbx
 29d7f23:	cmp    %r9,%r11
 29d7f26:	cmova  %r13,%rbx
 29d7f2a:	mov    (%rbx),%r15d
 29d7f2d:	mov    %r15,0x90(%rsp)
 29d7f35:	test   %ecx,%ecx
 29d7f37:	je     29d868f <wasm[0]::function[1009]::helper::array_packed_join+0x18ef>
 29d7f3d:	test   %ecx,%ecx
 29d7f3f:	je     29d8691 <wasm[0]::function[1009]::helper::array_packed_join+0x18f1>
 29d7f45:	mov    %ecx,%ebx
 29d7f47:	lea    (%r8,%rbx,1),%r14
 29d7f4b:	lea    0x10(%r8,%rbx,1),%r15
 29d7f50:	cmp    %r9,%rbx
 29d7f53:	cmova  %r13,%r15
 29d7f57:	mov    0x78(%rsp),%r12
 29d7f5c:	mov    %r12d,%r13d
 29d7f5f:	mov    0x90(%rsp),%r12
 29d7f67:	mov    %r12d,%ebx
 29d7f6a:	lea    0x0(%r13,%rbx,1),%r12
 29d7f6f:	mov    (%r15),%r15d
 29d7f72:	cmp    %r15,%r12
 29d7f75:	ja     29d8693 <wasm[0]::function[1009]::helper::array_packed_join+0x18f3>
 29d7f7b:	lea    0x14(%r14,%r13,2),%r15
 29d7f80:	mov    %rbx,%r14
 29d7f83:	shl    $1,%r14
 29d7f86:	mov    %r15,%r12
 29d7f89:	add    %r14,%r12
 29d7f8c:	jb     29d8695 <wasm[0]::function[1009]::helper::array_packed_join+0x18f5>
 29d7f92:	add    %r8,%r9
 29d7f95:	cmp    %r9,%r12
 29d7f98:	ja     29d8697 <wasm[0]::function[1009]::helper::array_packed_join+0x18f7>
 29d7f9e:	lea    0x14(%r8,%r11,1),%r8
 29d7fa3:	mov    %r8,%r11
 29d7fa6:	add    %r14,%r11
 29d7fa9:	jb     29d8699 <wasm[0]::function[1009]::helper::array_packed_join+0x18f9>
 29d7faf:	cmp    %r9,%r11
 29d7fb2:	ja     29d869b <wasm[0]::function[1009]::helper::array_packed_join+0x18fb>
 29d7fb8:	cmp    %r15,%r8
 29d7fbb:	ja     29d8091 <wasm[0]::function[1009]::helper::array_packed_join+0x12f1>
 29d7fc1:	lea    (%r15,%rbx,2),%r15
 29d7fc5:	mov    %r15,%r12
 29d7fc8:	lea    0x14(%r10,%rbx,2),%r8
 29d7fcd:	mov    %r8,%r13
 29d7fd0:	cmp    $0x8000000,%r14
 29d7fd7:	mov    %r14,%rbx
 29d7fda:	ja     29d7feb <wasm[0]::function[1009]::helper::array_packed_join+0x124b>
 29d7fe0:	mov    %r12,%r8
 29d7fe3:	mov    %rbx,%r11
 29d7fe6:	jmp    29d807a <wasm[0]::function[1009]::helper::array_packed_join+0x12da>
 29d7feb:	mov    %ecx,0x20(%rsp)
 29d7fef:	mov    %edx,0x28(%rsp)
 29d7ff3:	mov    %eax,0x30(%rsp)
 29d7ff7:	mov    %edi,0x38(%rsp)
 29d7ffb:	mov    %esi,0x40(%rsp)
 29d7fff:	mov    0xd0(%rsp),%r14
 29d8007:	mov    (%r14),%rdi
 29d800a:	mov    0x88(%rsp),%rax
 29d8012:	cmp    %rax,%rdi
 29d8015:	jae    29d8508 <wasm[0]::function[1009]::helper::array_packed_join+0x1768>
 29d801b:	mov    $0x8000000,%ecx
 29d8020:	mov    %r12,%rsi
 29d8023:	sub    $0x8000000,%rsi
 29d802a:	mov    %r13,%rdx
 29d802d:	mov    %rsi,%r12
 29d8030:	sub    $0x8000000,%rdx
 29d8037:	mov    %rdx,%r13
 29d803a:	mov    0x60(%rsp),%rdi
 29d803f:	call   3018c9a <wasmtime_builtin_memory_copy>
 29d8044:	mov    0x20(%rsp),%ecx
 29d8048:	mov    0x28(%rsp),%edx
 29d804c:	mov    0x30(%rsp),%eax
 29d8050:	mov    0x38(%rsp),%edi
 29d8054:	mov    0x40(%rsp),%esi
 29d8058:	mov    %rbx,%r11
 29d805b:	sub    $0x8000000,%r11
 29d8062:	cmp    $0x8000000,%r11
 29d8069:	jbe    29d8077 <wasm[0]::function[1009]::helper::array_packed_join+0x12d7>
 29d806f:	mov    %r11,%rbx
 29d8072:	jmp    29d7feb <wasm[0]::function[1009]::helper::array_packed_join+0x124b>
 29d8077:	mov    %r12,%r8
 29d807a:	sub    %r11,%r8
 29d807d:	mov    %r8,%r12
 29d8080:	mov    %r13,%r8
 29d8083:	sub    %r11,%r8
 29d8086:	mov    %r8,%r13
 29d8089:	mov    %r11,%rbx
 29d808c:	jmp    29d813a <wasm[0]::function[1009]::helper::array_packed_join+0x139a>
 29d8091:	mov    %r14,%r11
 29d8094:	mov    %r15,%r12
 29d8097:	mov    %r8,%r13
 29d809a:	cmp    $0x8000000,%r11
 29d80a1:	mov    %r11,%rbx
 29d80a4:	jbe    29d813a <wasm[0]::function[1009]::helper::array_packed_join+0x139a>
 29d80aa:	mov    %ecx,0x40(%rsp)
 29d80ae:	mov    %edx,0x38(%rsp)
 29d80b2:	mov    %eax,0x30(%rsp)
 29d80b6:	mov    %edi,0x28(%rsp)
 29d80ba:	mov    %esi,0x20(%rsp)
 29d80be:	mov    0xd0(%rsp),%r14
 29d80c6:	mov    (%r14),%rax
 29d80c9:	mov    0x88(%rsp),%rcx
 29d80d1:	cmp    %rcx,%rax
 29d80d4:	jae    29d853c <wasm[0]::function[1009]::helper::array_packed_join+0x179c>
 29d80da:	mov    $0x8000000,%ecx
 29d80df:	mov    %r13,%rdx
 29d80e2:	mov    %r12,%rsi
 29d80e5:	mov    0x60(%rsp),%rdi
 29d80ea:	call   3018c9a <wasmtime_builtin_memory_copy>
 29d80ef:	mov    0x40(%rsp),%ecx
 29d80f3:	mov    0x38(%rsp),%edx
 29d80f7:	mov    0x30(%rsp),%eax
 29d80fb:	mov    0x28(%rsp),%edi
 29d80ff:	mov    0x20(%rsp),%esi
 29d8103:	mov    %rbx,%r8
 29d8106:	sub    $0x8000000,%r8
 29d810d:	mov    %r8,%rbx
 29d8110:	mov    %r12,%r8
 29d8113:	add    $0x8000000,%r8
 29d811a:	mov    %r8,%r12
 29d811d:	mov    %r13,%r8
 29d8120:	lea    0x8000000(%r8),%r9
 29d8127:	mov    %rbx,%r8
 29d812a:	mov    %r9,%r13
 29d812d:	cmp    $0x8000000,%r8
 29d8134:	ja     29d80aa <wasm[0]::function[1009]::helper::array_packed_join+0x130a>
 29d813a:	mov    %ecx,0x20(%rsp)
 29d813e:	mov    %edx,0x28(%rsp)
 29d8142:	mov    %eax,0x30(%rsp)
 29d8146:	mov    %edi,0x38(%rsp)
 29d814a:	mov    %esi,0x40(%rsp)
 29d814e:	mov    0xd0(%rsp),%r14
 29d8156:	mov    (%r14),%rax
 29d8159:	mov    0x88(%rsp),%rcx
 29d8161:	cmp    %rcx,%rax
 29d8164:	jae    29d8570 <wasm[0]::function[1009]::helper::array_packed_join+0x17d0>
 29d816a:	mov    %rbx,%rcx
 29d816d:	mov    %r13,%rdx
 29d8170:	mov    %r12,%rsi
 29d8173:	jmp    29d8181 <wasm[0]::function[1009]::helper::array_packed_join+0x13e1>
 29d8178:	mov    %rbx,%rcx
 29d817b:	mov    %r13,%rdx
 29d817e:	mov    %r12,%rsi
 29d8181:	mov    %rbx,%rcx
 29d8184:	mov    %r13,%rdx
 29d8187:	mov    %r12,%rsi
 29d818a:	mov    0x60(%rsp),%rdi
 29d818f:	call   3018c9a <wasmtime_builtin_memory_copy>
 29d8194:	mov    0x20(%rsp),%ecx
 29d8198:	mov    0x28(%rsp),%edx
 29d819c:	mov    0x30(%rsp),%eax
 29d81a0:	mov    0x38(%rsp),%edi
 29d81a4:	mov    0x40(%rsp),%esi
 29d81a8:	mov    0x78(%rsp),%r12
 29d81ad:	mov    0x90(%rsp),%r15
 29d81b5:	add    %r15d,%r12d
 29d81b8:	mov    %r12,0x78(%rsp)
 29d81bd:	mov    0x70(%rsp),%r12
 29d81c2:	add    $0x1,%r12
 29d81c9:	mov    %r12,0x70(%rsp)
 29d81ce:	jmp    29d778a <wasm[0]::function[1009]::helper::array_packed_join+0x9ea>
 29d81d3:	mov    0x18(%rsp),%eax
 29d81d7:	test   %eax,%eax
 29d81d9:	je     29d869d <wasm[0]::function[1009]::helper::array_packed_join+0x18fd>
 29d81df:	mov    0xa0(%rsp),%r15
 29d81e7:	mov    (%r15),%eax
 29d81ea:	mov    %eax,%ecx
 29d81ec:	lea    0x20(%rcx),%rdx
 29d81f0:	mov    0x4(%r15),%esi
 29d81f4:	cmp    %rsi,%rdx
 29d81f7:	ja     29d85b0 <wasm[0]::function[1009]::helper::array_packed_join+0x1810>
 29d81fd:	lea    0x20(%rax),%edx
 29d8200:	mov    %edx,(%r15)
 29d8203:	mov    0xc8(%rsp),%r10
 29d820b:	mov    0x20(%r10),%rsi
 29d820f:	lea    (%rsi,%rcx,1),%rdx
 29d8213:	movl   $0xb000000a,(%rsi,%rcx,1)
 29d821a:	mov    0xb0(%rsp),%r11
 29d8222:	mov    %r11d,0x4(%rsi,%rcx,1)
 29d8227:	mov    $0x20,%edi
 29d822c:	mov    %edi,0x8(%rsi,%rcx,1)
 29d8230:	mov    0x18(%rsp),%esi
 29d8234:	mov    %esi,0x10(%rdx)
 29d8237:	movq   $0x0,0x18(%rdx)
 29d823f:	test   %eax,%eax
 29d8241:	je     29d869f <wasm[0]::function[1009]::helper::array_packed_join+0x18ff>
 29d8247:	mov    0x10(%rsp),%r8d
 29d824c:	jmp    29d827b <wasm[0]::function[1009]::helper::array_packed_join+0x14db>
 29d8251:	mov    0x8(%rsp),%eax
 29d8255:	mov    (%rsp),%r8d
 29d8259:	jmp    29d827b <wasm[0]::function[1009]::helper::array_packed_join+0x14db>
 29d825e:	xor    %edx,%edx
 29d8260:	mov    0x60(%rsp),%rsi
 29d8265:	mov    0x60(%rsp),%rdi
 29d826a:	call   2f307a0 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 29d826f:	test   %eax,%eax
 29d8271:	je     29d86a1 <wasm[0]::function[1009]::helper::array_packed_join+0x1901>
 29d8277:	mov    (%rsp),%r8d
 29d827b:	mov    0xb8(%rsp),%rdi
 29d8283:	test   %edi,%edi
 29d8285:	jne    29d8293 <wasm[0]::function[1009]::helper::array_packed_join+0x14f3>
 29d828b:	mov    %r8,%rax
 29d828e:	jmp    29d82fe <wasm[0]::function[1009]::helper::array_packed_join+0x155e>
 29d8293:	xor    %ecx,%ecx
 29d8295:	test   %eax,%eax
 29d8297:	je     29d82e2 <wasm[0]::function[1009]::helper::array_packed_join+0x1542>
 29d829d:	xor    %ecx,%ecx
 29d829f:	test   $0x1,%eax
 29d82a4:	jne    29d82e2 <wasm[0]::function[1009]::helper::array_packed_join+0x1542>
 29d82aa:	mov    0xc8(%rsp),%r10
 29d82b2:	mov    0x28(%r10),%rcx
 29d82b6:	mov    0x20(%r10),%rdx
 29d82ba:	mov    %eax,%esi
 29d82bc:	lea    0x4(%rdx,%rsi,1),%rdx
 29d82c1:	xor    %rdi,%rdi
 29d82c4:	cmp    %rcx,%rsi
 29d82c7:	cmova  %rdi,%rdx
 29d82cb:	mov    (%rdx),%ecx
 29d82cd:	mov    0x60(%rsp),%rdx
 29d82d2:	mov    0x28(%rdx),%rdx
 29d82d6:	cmp    0x234(%rdx),%ecx
 29d82dc:	sete   %cl
 29d82df:	movzbl %cl,%ecx
 29d82e2:	test   %ecx,%ecx
 29d82e4:	je     29d86a3 <wasm[0]::function[1009]::helper::array_packed_join+0x1903>
 29d82ea:	jmp    29d82fe <wasm[0]::function[1009]::helper::array_packed_join+0x155e>
 29d82ef:	xor    %edx,%edx
 29d82f1:	mov    0x60(%rsp),%rsi
 29d82f6:	mov    %rsi,%rdi
 29d82f9:	call   2f307a0 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 29d82fe:	mov    0xe0(%rsp),%rbx
 29d8306:	mov    0xe8(%rsp),%r12
 29d830e:	mov    0xf0(%rsp),%r13
 29d8316:	mov    0xf8(%rsp),%r14
 29d831e:	mov    0x100(%rsp),%r15
 29d8326:	add    $0x110,%rsp
 29d832d:	mov    %rbp,%rsp
 29d8330:	pop    %rbp
 29d8331:	ret    $0x10
 29d8334:	mov    0x60(%rsp),%rdi
 29d8339:	call   3018d19 <wasmtime_builtin_new_epoch>
 29d833e:	mov    %rax,0x88(%rsp)
 29d8346:	mov    0x68(%rsp),%r15
 29d834b:	jmp    29d6e46 <wasm[0]::function[1009]::helper::array_packed_join+0xa6>
 29d8350:	mov    0xc8(%rsp),%r10
 29d8358:	mov    0x8(%r10),%rcx
 29d835c:	mov    %rcx,0x88(%rsp)
 29d8364:	cmp    %rcx,%rax
 29d8367:	jb     29d70c0 <wasm[0]::function[1009]::helper::array_packed_join+0x320>
 29d836d:	mov    0x60(%rsp),%rdi
 29d8372:	call   3018d19 <wasmtime_builtin_new_epoch>
 29d8377:	mov    %rax,0x88(%rsp)
 29d837f:	mov    0x68(%rsp),%rcx
 29d8384:	jmp    29d70c5 <wasm[0]::function[1009]::helper::array_packed_join+0x325>
 29d8389:	mov    $0xa8000006,%esi
 29d838e:	mov    %r12,%rdi
 29d8391:	mov    0x238(%rdi),%edx
 29d8397:	mov    $0x10,%r8d
 29d839d:	mov    0x60(%rsp),%rdi
 29d83a2:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
 29d83a7:	mov    %eax,%ecx
 29d83a9:	mov    0xc8(%rsp),%r10
 29d83b1:	add    0x20(%r10),%rcx
 29d83b5:	jmp    29d7613 <wasm[0]::function[1009]::helper::array_packed_join+0x873>
 29d83ba:	mov    0xc8(%rsp),%r10
 29d83c2:	mov    0x8(%r10),%rcx
 29d83c6:	mov    %rcx,0x88(%rsp)
 29d83ce:	cmp    %rcx,%rax
 29d83d1:	jb     29d76bf <wasm[0]::function[1009]::helper::array_packed_join+0x91f>
 29d83d7:	mov    0x60(%rsp),%rdi
 29d83dc:	call   3018d19 <wasmtime_builtin_new_epoch>
 29d83e1:	mov    %rax,0x88(%rsp)
 29d83e9:	jmp    29d76bf <wasm[0]::function[1009]::helper::array_packed_join+0x91f>
 29d83ee:	mov    0xc8(%rsp),%r10
 29d83f6:	mov    0x8(%r10),%r9
 29d83fa:	mov    %r9,%r11
 29d83fd:	mov    %r9,0x88(%rsp)
 29d8405:	cmp    %r11,%rax
 29d8408:	jb     29d773f <wasm[0]::function[1009]::helper::array_packed_join+0x99f>
 29d840e:	mov    0x60(%rsp),%rdi
 29d8413:	call   3018d19 <wasmtime_builtin_new_epoch>
 29d8418:	mov    %rax,0x88(%rsp)
 29d8420:	jmp    29d773f <wasm[0]::function[1009]::helper::array_packed_join+0x99f>
 29d8425:	mov    0xc8(%rsp),%r10
 29d842d:	mov    0x8(%r10),%rcx
 29d8431:	mov    %rcx,0x88(%rsp)
 29d8439:	cmp    %rcx,%rax
 29d843c:	jb     29d77c9 <wasm[0]::function[1009]::helper::array_packed_join+0xa29>
 29d8442:	mov    0x60(%rsp),%rdi
 29d8447:	call   3018d19 <wasmtime_builtin_new_epoch>
 29d844c:	mov    %rax,0x88(%rsp)
 29d8454:	mov    0x68(%rsp),%rcx
 29d8459:	mov    0x70(%rsp),%r12
 29d845e:	jmp    29d77d3 <wasm[0]::function[1009]::helper::array_packed_join+0xa33>
 29d8463:	mov    0xc8(%rsp),%r10
 29d846b:	mov    0x8(%r10),%rcx
 29d846f:	mov    %rcx,0x88(%rsp)
 29d8477:	cmp    %rcx,%rax
 29d847a:	jb     29d7980 <wasm[0]::function[1009]::helper::array_packed_join+0xbe0>
 29d8480:	mov    0x60(%rsp),%rdi
 29d8485:	call   3018d19 <wasmtime_builtin_new_epoch>
 29d848a:	mov    %rax,0x88(%rsp)
 29d8492:	jmp    29d7980 <wasm[0]::function[1009]::helper::array_packed_join+0xbe0>
 29d8497:	mov    0xc8(%rsp),%r10
 29d849f:	mov    0x8(%r10),%rcx
 29d84a3:	mov    %rcx,0x88(%rsp)
 29d84ab:	cmp    %rcx,%rax
 29d84ae:	jb     29d7a6f <wasm[0]::function[1009]::helper::array_packed_join+0xccf>
 29d84b4:	mov    0x60(%rsp),%rdi
 29d84b9:	call   3018d19 <wasmtime_builtin_new_epoch>
 29d84be:	mov    %rax,0x88(%rsp)
 29d84c6:	jmp    29d7a6f <wasm[0]::function[1009]::helper::array_packed_join+0xccf>
 29d84cb:	mov    0xc8(%rsp),%r10
 29d84d3:	mov    0x8(%r10),%rax
 29d84d7:	mov    %rax,0x88(%rsp)
 29d84df:	cmp    %rax,%rsi
 29d84e2:	jb     29d7b0d <wasm[0]::function[1009]::helper::array_packed_join+0xd6d>
 29d84e8:	mov    0x60(%rsp),%rdi
 29d84ed:	call   3018d19 <wasmtime_builtin_new_epoch>
 29d84f2:	mov    %rax,0x88(%rsp)
 29d84fa:	mov    %r15,%rcx
 29d84fd:	mov    %r12,%rdx
 29d8500:	mov    %rbx,%rsi
 29d8503:	jmp    29d7b16 <wasm[0]::function[1009]::helper::array_packed_join+0xd76>
 29d8508:	mov    0xc8(%rsp),%r10
 29d8510:	mov    0x8(%r10),%rax
 29d8514:	mov    %rax,0x88(%rsp)
 29d851c:	cmp    %rax,%rdi
 29d851f:	jb     29d801b <wasm[0]::function[1009]::helper::array_packed_join+0x127b>
 29d8525:	mov    0x60(%rsp),%rdi
 29d852a:	call   3018d19 <wasmtime_builtin_new_epoch>
 29d852f:	mov    %rax,0x88(%rsp)
 29d8537:	jmp    29d801b <wasm[0]::function[1009]::helper::array_packed_join+0x127b>
 29d853c:	mov    0xc8(%rsp),%r10
 29d8544:	mov    0x8(%r10),%rcx
 29d8548:	mov    %rcx,0x88(%rsp)
 29d8550:	cmp    %rcx,%rax
 29d8553:	jb     29d80da <wasm[0]::function[1009]::helper::array_packed_join+0x133a>
 29d8559:	mov    0x60(%rsp),%rdi
 29d855e:	call   3018d19 <wasmtime_builtin_new_epoch>
 29d8563:	mov    %rax,0x88(%rsp)
 29d856b:	jmp    29d80da <wasm[0]::function[1009]::helper::array_packed_join+0x133a>
 29d8570:	mov    0xc8(%rsp),%r10
 29d8578:	mov    0x8(%r10),%rcx
 29d857c:	mov    %rcx,%rdx
 29d857f:	mov    %rcx,0x88(%rsp)
 29d8587:	cmp    %rdx,%rax
 29d858a:	jb     29d8178 <wasm[0]::function[1009]::helper::array_packed_join+0x13d8>
 29d8590:	mov    0x60(%rsp),%rdi
 29d8595:	call   3018d19 <wasmtime_builtin_new_epoch>
 29d859a:	mov    %rax,0x88(%rsp)
 29d85a2:	mov    %rbx,%rcx
 29d85a5:	mov    %r13,%rdx
 29d85a8:	mov    %r12,%rsi
 29d85ab:	jmp    29d8181 <wasm[0]::function[1009]::helper::array_packed_join+0x13e1>
 29d85b0:	mov    $0xb000000a,%esi
 29d85b5:	mov    $0x20,%ecx
 29d85ba:	mov    $0x10,%r8d
 29d85c0:	mov    0xb0(%rsp),%rdx
 29d85c8:	mov    0x60(%rsp),%rdi
 29d85cd:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
 29d85d2:	mov    %eax,%edx
 29d85d4:	mov    0xc8(%rsp),%r10
 29d85dc:	add    0x20(%r10),%rdx
 29d85e0:	jmp    29d8230 <wasm[0]::function[1009]::helper::array_packed_join+0x1490>
 29d85e5:	ud2
 29d85e7:	ud2
 29d85e9:	ud2
 29d85eb:	ud2
 29d85ed:	ud2
 29d85ef:	ud2
 29d85f1:	ud2
 29d85f3:	ud2
 29d85f5:	ud2
 29d85f7:	ud2
 29d85f9:	ud2
 29d85fb:	ud2
 29d85fd:	ud2
 29d85ff:	ud2
 29d8601:	ud2
 29d8603:	ud2
 29d8605:	ud2
 29d8607:	ud2
 29d8609:	ud2
 29d860b:	ud2
 29d860d:	ud2
 29d860f:	ud2
 29d8611:	ud2
 29d8613:	ud2
 29d8615:	ud2
 29d8617:	ud2
 29d8619:	ud2
 29d861b:	ud2
 29d861d:	ud2
 29d861f:	ud2
 29d8621:	ud2
 29d8623:	ud2
 29d8625:	ud2
 29d8627:	ud2
 29d8629:	ud2
 29d862b:	ud2
 29d862d:	ud2
 29d862f:	ud2
 29d8631:	ud2
 29d8633:	ud2
 29d8635:	ud2
 29d8637:	ud2
 29d8639:	ud2
 29d863b:	ud2
 29d863d:	ud2
 29d863f:	ud2
 29d8641:	ud2
 29d8643:	ud2
 29d8645:	ud2
 29d8647:	ud2
 29d8649:	ud2
 29d864b:	ud2
 29d864d:	ud2
 29d864f:	ud2
 29d8651:	ud2
 29d8653:	ud2
 29d8655:	ud2
 29d8657:	ud2
 29d8659:	ud2
 29d865b:	ud2
 29d865d:	ud2
 29d865f:	ud2
 29d8661:	ud2
 29d8663:	ud2
 29d8665:	ud2
 29d8667:	ud2
 29d8669:	ud2
 29d866b:	ud2
 29d866d:	ud2
 29d866f:	ud2
 29d8671:	ud2
 29d8673:	ud2
 29d8675:	ud2
 29d8677:	ud2
 29d8679:	ud2
 29d867b:	ud2
 29d867d:	ud2
 29d867f:	ud2
 29d8681:	ud2
 29d8683:	ud2
 29d8685:	ud2
 29d8687:	ud2
 29d8689:	ud2
 29d868b:	ud2
 29d868d:	ud2
 29d868f:	ud2
 29d8691:	ud2
 29d8693:	ud2
 29d8695:	ud2
 29d8697:	ud2
 29d8699:	ud2
 29d869b:	ud2
 29d869d:	ud2
 29d869f:	ud2
 29d86a1:	ud2
 29d86a3:	ud2
 29d86a5:	add    %al,(%rax)
 29d86a7:	add    %bh,%bh
 29d86a9:	(bad)
 29d86aa:	(bad)
 29d86ab:	incl   (%rax)
 29d86ad:	add    %al,(%rax)
	...
