
/workspace/scriptw/target/performance-dense-numbers-20261030/v2/native-cause/candidate/runtime-portable.elf:     file format elf64-x86-64


Disassembly of section .text:

00000000029da920 <wasm[0]::function[1013]::helper::array_indexed_publish>:
 29da920:	push   %rbp
 29da921:	mov    %rsp,%rbp
 29da924:	mov    0x8(%rdi),%r10
 29da928:	mov    0x18(%r10),%r10
 29da92c:	add    $0x120,%r10
 29da933:	cmp    %rsp,%r10
 29da936:	ja     29dfad1 <wasm[0]::function[1013]::helper::array_indexed_publish+0x51b1>
 29da93c:	sub    $0x110,%rsp
 29da943:	mov    %rbx,0xe0(%rsp)
 29da94b:	mov    %r12,0xe8(%rsp)
 29da953:	mov    %r13,0xf0(%rsp)
 29da95b:	mov    %r14,0xf8(%rsp)
 29da963:	mov    %r15,0x100(%rsp)
 29da96b:	mov    %rcx,0x68(%rsp)
 29da970:	mov    %edx,0x20(%rsp)
 29da974:	mov    %r8d,0x18(%rsp)
 29da979:	movl   $0x0,(%rsp)
 29da980:	mov    0x18(%rdi),%rax
 29da984:	mov    (%rax),%rcx
 29da987:	mov    %rax,0xd8(%rsp)
 29da98f:	mov    0x8(%rdi),%rdx
 29da993:	mov    %rdi,0x60(%rsp)
 29da998:	mov    0x8(%rdx),%rax
 29da99c:	mov    %rdx,0xd0(%rsp)
 29da9a4:	cmp    %rax,%rcx
 29da9a7:	jae    29def94 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4674>
 29da9ad:	mov    0x68(%rsp),%rcx
 29da9b2:	mov    %rax,0xa8(%rsp)
 29da9ba:	cmp    0x540f(%rip),%rcx        # 29dfdd0 <wasm[0]::function[1013]::helper::array_indexed_publish+0x54b0>
 29da9c1:	mov    %rcx,0x68(%rsp)
 29da9c6:	jae    29dfad3 <wasm[0]::function[1013]::helper::array_indexed_publish+0x51b3>
 29da9cc:	mov    0x20(%rsp),%r13d
 29da9d1:	xor    %r10d,%r10d
 29da9d4:	test   %r13d,%r13d
 29da9d7:	je     29dfad5 <wasm[0]::function[1013]::helper::array_indexed_publish+0x51b5>
 29da9dd:	test   %r13d,%r13d
 29da9e0:	je     29dfad7 <wasm[0]::function[1013]::helper::array_indexed_publish+0x51b7>
 29da9e6:	mov    0xd0(%rsp),%rsi
 29da9ee:	mov    0x28(%rsi),%rax
 29da9f2:	mov    0x20(%rsi),%rdi
 29da9f6:	mov    %r13d,%r8d
 29da9f9:	xor    %rdx,%rdx
 29da9fc:	add    %r8,%rdi
 29da9ff:	cmp    %rax,%r8
 29daa02:	cmova  %rdx,%rdi
 29daa06:	mov    0x24(%rdi),%eax
 29daa09:	mov    0x18(%rsp),%edx
 29daa0d:	cmp    $0x2,%eax
 29daa10:	sete   %dil
 29daa14:	cmp    $0x3,%eax
 29daa17:	sete   %al
 29daa1a:	or     %eax,%edi
 29daa1c:	test   %dil,%dil
 29daa1f:	jne    29daa37 <wasm[0]::function[1013]::helper::array_indexed_publish+0x117>
 29daa25:	mov    %r13,0x70(%rsp)
 29daa2a:	mov    %rsi,0xd0(%rsp)
 29daa32:	jmp    29dd4d2 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2bb2>
 29daa37:	mov    0x18(%rsp),%edx
 29daa3b:	xor    %r10d,%r10d
 29daa3e:	test   %edx,%edx
 29daa40:	je     29dfad9 <wasm[0]::function[1013]::helper::array_indexed_publish+0x51b9>
 29daa46:	test   %edx,%edx
 29daa48:	je     29dfadb <wasm[0]::function[1013]::helper::array_indexed_publish+0x51bb>
 29daa4e:	mov    0x28(%rsi),%rax
 29daa52:	mov    %edx,%edi
 29daa54:	mov    %rdi,%rcx
 29daa57:	add    0x20(%rsi),%rcx
 29daa5b:	xor    %r8,%r8
 29daa5e:	cmp    %rax,%rdi
 29daa61:	cmova  %r8,%rcx
 29daa65:	mov    0x10(%rcx),%eax
 29daa68:	mov    0x20(%rsp),%r13d
 29daa6d:	cmp    $0xe,%eax
 29daa70:	je     29daa8b <wasm[0]::function[1013]::helper::array_indexed_publish+0x16b>
 29daa76:	mov    %r13,%r12
 29daa79:	mov    %r13,0x70(%rsp)
 29daa7e:	mov    %rsi,0xd0(%rsp)
 29daa86:	jmp    29dc97d <wasm[0]::function[1013]::helper::array_indexed_publish+0x205d>
 29daa8b:	mov    0x18(%rsp),%eax
 29daa8f:	test   %eax,%eax
 29daa91:	je     29dfadd <wasm[0]::function[1013]::helper::array_indexed_publish+0x51bd>
 29daa97:	test   %eax,%eax
 29daa99:	je     29dfadf <wasm[0]::function[1013]::helper::array_indexed_publish+0x51bf>
 29daa9f:	mov    0x28(%rsi),%rdx
 29daaa3:	mov    0x20(%rsi),%r8
 29daaa7:	mov    %eax,%edi
 29daaa9:	lea    (%r8,%rdi,1),%rax
 29daaad:	xor    %r8,%r8
 29daab0:	cmp    %rdx,%rdi
 29daab3:	cmova  %r8,%rax
 29daab7:	mov    0x14(%rax),%edx
 29daaba:	test   %edx,%edx
 29daabc:	je     29dfae1 <wasm[0]::function[1013]::helper::array_indexed_publish+0x51c1>
 29daac2:	xor    %eax,%eax
 29daac4:	test   $0x1,%edx
 29daaca:	je     29daadd <wasm[0]::function[1013]::helper::array_indexed_publish+0x1bd>
 29daad0:	mov    %rsi,0xd0(%rsp)
 29daad8:	jmp    29dab1a <wasm[0]::function[1013]::helper::array_indexed_publish+0x1fa>
 29daadd:	mov    0x28(%rsi),%r9
 29daae1:	mov    0x20(%rsi),%r11
 29daae5:	mov    %rsi,0xd0(%rsp)
 29daaed:	mov    %edx,%r10d
 29daaf0:	lea    0x4(%r11,%r10,1),%rsi
 29daaf5:	xor    %r11,%r11
 29daaf8:	cmp    %r9,%r10
 29daafb:	cmova  %r11,%rsi
 29daaff:	mov    (%rsi),%r10d
 29dab02:	mov    0x60(%rsp),%rdi
 29dab07:	mov    0x28(%rdi),%r11
 29dab0b:	cmp    0x120(%r11),%r10d
 29dab12:	sete   %r11b
 29dab16:	movzbl %r11b,%eax
 29dab1a:	test   %eax,%eax
 29dab1c:	jne    29dab81 <wasm[0]::function[1013]::helper::array_indexed_publish+0x261>
 29dab22:	mov    0x60(%rsp),%rsi
 29dab27:	mov    0x60(%rsp),%rdi
 29dab2c:	call   2a01ba0 <wasm[0]::function[1024]::helper::property_value_resolve>
 29dab31:	test   %eax,%eax
 29dab33:	je     29dfae3 <wasm[0]::function[1013]::helper::array_indexed_publish+0x51c3>
 29dab39:	test   %eax,%eax
 29dab3b:	je     29dfae5 <wasm[0]::function[1013]::helper::array_indexed_publish+0x51c5>
 29dab41:	mov    0xd0(%rsp),%r15
 29dab49:	mov    0x28(%r15),%rcx
 29dab4d:	mov    0x20(%r15),%rsi
 29dab51:	mov    %eax,%edx
 29dab53:	lea    (%rsi,%rdx,1),%rax
 29dab57:	xor    %rsi,%rsi
 29dab5a:	cmp    %rcx,%rdx
 29dab5d:	cmova  %rsi,%rax
 29dab61:	mov    0x18(%rax),%r15d
 29dab65:	mov    0x10(%rax),%r13
 29dab69:	mov    %r13,0x90(%rsp)
 29dab71:	mov    0x1c(%rax),%esi
 29dab74:	mov    %r15,0x98(%rsp)
 29dab7c:	jmp    29dac11 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2f1>
 29dab81:	xor    %eax,%eax
 29dab83:	test   $0x1,%edx
 29dab89:	jne    29dabc7 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2a7>
 29dab8f:	mov    0xd0(%rsp),%r15
 29dab97:	mov    0x28(%r15),%rax
 29dab9b:	mov    0x20(%r15),%rcx
 29dab9f:	mov    %edx,%esi
 29daba1:	lea    0x4(%rcx,%rsi,1),%rcx
 29daba6:	xor    %rdi,%rdi
 29daba9:	cmp    %rax,%rsi
 29dabac:	cmova  %rdi,%rcx
 29dabb0:	mov    (%rcx),%eax
 29dabb2:	mov    0x60(%rsp),%rdi
 29dabb7:	mov    0x28(%rdi),%rcx
 29dabbb:	cmp    0x120(%rcx),%eax
 29dabc1:	sete   %al
 29dabc4:	movzbl %al,%eax
 29dabc7:	test   %eax,%eax
 29dabc9:	je     29dfae7 <wasm[0]::function[1013]::helper::array_indexed_publish+0x51c7>
 29dabcf:	test   %edx,%edx
 29dabd1:	je     29dfae9 <wasm[0]::function[1013]::helper::array_indexed_publish+0x51c9>
 29dabd7:	mov    0xd0(%rsp),%r15
 29dabdf:	mov    0x28(%r15),%rcx
 29dabe3:	mov    0x20(%r15),%rax
 29dabe7:	mov    %edx,%edx
 29dabe9:	add    %rdx,%rax
 29dabec:	xor    %rsi,%rsi
 29dabef:	cmp    %rcx,%rdx
 29dabf2:	cmova  %rsi,%rax
 29dabf6:	mov    0x18(%rax),%r15d
 29dabfa:	mov    %r15,0x98(%rsp)
 29dac02:	mov    0x10(%rax),%r13
 29dac06:	mov    %r13,0x90(%rsp)
 29dac0e:	mov    0x1c(%rax),%esi
 29dac11:	mov    0x20(%rsp),%r13d
 29dac16:	xor    %r10d,%r10d
 29dac19:	test   %r13d,%r13d
 29dac1c:	je     29dfaeb <wasm[0]::function[1013]::helper::array_indexed_publish+0x51cb>
 29dac22:	test   %r13d,%r13d
 29dac25:	je     29dfaed <wasm[0]::function[1013]::helper::array_indexed_publish+0x51cd>
 29dac2b:	mov    0xd0(%rsp),%r15
 29dac33:	mov    0x28(%r15),%rax
 29dac37:	mov    0x20(%r15),%rdx
 29dac3b:	mov    %r13d,%edi
 29dac3e:	add    %rdi,%rdx
 29dac41:	xor    %r8,%r8
 29dac44:	cmp    %rax,%rdi
 29dac47:	cmova  %r8,%rdx
 29dac4b:	mov    0x24(%rdx),%eax
 29dac4e:	mov    0x18(%rsp),%edx
 29dac52:	cmp    $0x3,%eax
 29dac55:	sete   %cl
 29dac58:	movzbl %cl,%r14d
 29dac5c:	mov    %r14,0x88(%rsp)
 29dac64:	cmp    $0x3,%eax
 29dac67:	jne    29dac87 <wasm[0]::function[1013]::helper::array_indexed_publish+0x367>
 29dac6d:	mov    0x88(%rsp),%r12
 29dac75:	mov    %r13,0x70(%rsp)
 29dac7a:	mov    %r10,0xa0(%rsp)
 29dac82:	jmp    29dc23f <wasm[0]::function[1013]::helper::array_indexed_publish+0x191f>
 29dac87:	mov    0x20(%rsp),%r13d
 29dac8c:	xor    %r10d,%r10d
 29dac8f:	test   %r13d,%r13d
 29dac92:	je     29dfaef <wasm[0]::function[1013]::helper::array_indexed_publish+0x51cf>
 29dac98:	test   %r13d,%r13d
 29dac9b:	je     29dfaf1 <wasm[0]::function[1013]::helper::array_indexed_publish+0x51d1>
 29daca1:	mov    0xd0(%rsp),%r15
 29daca9:	mov    0x28(%r15),%rax
 29dacad:	mov    %r13d,%edi
 29dacb0:	mov    %r13,0x70(%rsp)
 29dacb5:	mov    %rdi,%rdx
 29dacb8:	add    0x20(%r15),%rdx
 29dacbc:	xor    %r13,%r13
 29dacbf:	cmp    %rax,%rdi
 29dacc2:	cmova  %r13,%rdx
 29dacc6:	mov    0x24(%rdx),%eax
 29dacc9:	mov    (%rsp),%edi
 29daccc:	mov    0x18(%rsp),%edx
 29dacd0:	cmp    $0x2,%eax
 29dacd3:	sete   %al
 29dacd6:	mov    0x98(%rsp),%r15
 29dacde:	cmp    $0x3,%r15d
 29dace2:	sete   %cl
 29dace5:	test   %al,%cl
 29dace7:	jne    29dacff <wasm[0]::function[1013]::helper::array_indexed_publish+0x3df>
 29daced:	mov    0x70(%rsp),%r12
 29dacf2:	mov    %r13,0x80(%rsp)
 29dacfa:	jmp    29dbaf8 <wasm[0]::function[1013]::helper::array_indexed_publish+0x11d8>
 29dacff:	mov    0x20(%rsp),%r13d
 29dad04:	xor    %r10d,%r10d
 29dad07:	test   %r13d,%r13d
 29dad0a:	je     29dfaf3 <wasm[0]::function[1013]::helper::array_indexed_publish+0x51d3>
 29dad10:	test   %r13d,%r13d
 29dad13:	je     29dfaf5 <wasm[0]::function[1013]::helper::array_indexed_publish+0x51d5>
 29dad19:	mov    0xd0(%rsp),%r15
 29dad21:	mov    0x28(%r15),%rax
 29dad25:	mov    0x20(%r15),%rdi
 29dad29:	mov    %r13d,%r8d
 29dad2c:	mov    %r13,0x70(%rsp)
 29dad31:	lea    (%rdi,%r8,1),%rdx
 29dad35:	xor    %r13,%r13
 29dad38:	cmp    %rax,%r8
 29dad3b:	cmova  %r13,%rdx
 29dad3f:	mov    0x28(%rdx),%r9d
 29dad43:	mov    0x2c(%rdx),%r8d
 29dad47:	test   %r9d,%r9d
 29dad4a:	je     29dfaf7 <wasm[0]::function[1013]::helper::array_indexed_publish+0x51d7>
 29dad50:	test   %r9d,%r9d
 29dad53:	je     29dfaf9 <wasm[0]::function[1013]::helper::array_indexed_publish+0x51d9>
 29dad59:	mov    %r9d,%r11d
 29dad5c:	lea    0x10(%rdi,%r11,1),%rdi
 29dad61:	cmp    %rax,%r11
 29dad64:	cmova  %r13,%rdi
 29dad68:	mov    (%rdi),%r15d
 29dad6b:	mov    0x18(%rdx),%r12
 29dad6f:	mov    %r12,0xb8(%rsp)
 29dad77:	mov    (%rsp),%edi
 29dad7a:	mov    0x18(%rsp),%edx
 29dad7e:	mov    %r15d,%r14d
 29dad81:	mov    0x68(%rsp),%rcx
 29dad86:	cmp    %r14,%rcx
 29dad89:	setb   %al
 29dad8c:	cmp    $0x100000,%rcx
 29dad93:	setb   %r11b
 29dad97:	lea    0x8(%r12,%r12,1),%rcx
 29dad9c:	mov    0x68(%rsp),%r12
 29dada1:	cmp    %rcx,%r12
 29dada4:	setbe  %bl
 29dada7:	and    %ebx,%r11d
 29dadaa:	or     %r11d,%eax
 29dadad:	test   %al,%al
 29dadaf:	jne    29dadc2 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4a2>
 29dadb5:	mov    %r13,0x80(%rsp)
 29dadbd:	jmp    29dbaf3 <wasm[0]::function[1013]::helper::array_indexed_publish+0x11d3>
 29dadc2:	mov    0x20(%rsp),%r12d
 29dadc7:	mov    %r12,0x70(%rsp)
 29dadcc:	mov    (%rsp),%edi
 29dadcf:	mov    0x18(%rsp),%edx
 29dadd3:	mov    0x68(%rsp),%rcx
 29dadd8:	cmp    %r14,%rcx
 29daddb:	jb     29db8d2 <wasm[0]::function[1013]::helper::array_indexed_publish+0xfb2>
 29dade1:	test   %r15d,%r15d
 29dade4:	jne    29dadf0 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4d0>
 29dadea:	mov    $0x4,%r15d
 29dadf0:	mov    %r9d,0x30(%rsp)
 29dadf5:	mov    %r8d,0x58(%rsp)
 29dadfa:	mov    0x70(%rsp),%r12
 29dadff:	mov    %r12d,0x10(%rsp)
 29dae04:	mov    %edi,0x18(%rsp)
 29dae08:	mov    %esi,(%rsp)
 29dae0b:	mov    %edx,0x20(%rsp)
 29dae0f:	mov    0xd8(%rsp),%r13
 29dae17:	mov    0x0(%r13),%rax
 29dae1b:	mov    0xa8(%rsp),%rcx
 29dae23:	cmp    %rcx,%rax
 29dae26:	jae    29defb0 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4690>
 29dae2c:	mov    %r15d,%r12d
 29dae2f:	mov    0x68(%rsp),%rcx
 29dae34:	cmp    %r12,%rcx
 29dae37:	jb     29dae64 <wasm[0]::function[1013]::helper::array_indexed_publish+0x544>
 29dae3d:	mov    0x30(%rsp),%r9d
 29dae42:	mov    0x58(%rsp),%r8d
 29dae47:	mov    0x10(%rsp),%r12d
 29dae4c:	mov    %r12,0x70(%rsp)
 29dae51:	mov    0x18(%rsp),%edi
 29dae55:	mov    (%rsp),%esi
 29dae58:	mov    0x20(%rsp),%edx
 29dae5c:	shl    $1,%r15d
 29dae5f:	jmp    29dadf0 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4d0>
 29dae64:	mov    %r12,%rcx
 29dae67:	shl    $0x3,%rcx
 29dae6b:	mov    %rcx,%rax
 29dae6e:	shr    $0x20,%rax
 29dae72:	mov    %rcx,%rbx
 29dae75:	test   %rax,%rax
 29dae78:	jne    29dfafb <wasm[0]::function[1013]::helper::array_indexed_publish+0x51db>
 29dae7e:	mov    %r15,%rcx
 29dae81:	shl    $0x3,%ecx
 29dae84:	add    $0x18,%ecx
 29dae87:	jb     29dfafd <wasm[0]::function[1013]::helper::array_indexed_publish+0x51dd>
 29dae8d:	mov    0x60(%rsp),%rdi
 29dae92:	mov    0x20(%rdi),%rdi
 29dae96:	mov    (%rdi),%eax
 29dae98:	mov    %eax,%edx
 29dae9a:	mov    %ecx,%esi
 29dae9c:	add    $0xf,%rsi
 29daea3:	mov    %rsi,%r8
 29daea6:	and    $0xfffffffffffffff0,%r8
 29daeaa:	add    %rdx,%r8
 29daead:	mov    0x4(%rdi),%r9d
 29daeb1:	mov    %rdi,0xb0(%rsp)
 29daeb9:	cmp    %r9,%r8
 29daebc:	ja     29defe4 <wasm[0]::function[1013]::helper::array_indexed_publish+0x46c4>
 29daec2:	add    $0xf,%ecx
 29daec8:	and    $0xfffffff0,%ecx
 29daecb:	lea    (%rax,%rcx,1),%edi
 29daece:	mov    0xb0(%rsp),%rcx
 29daed6:	mov    %edi,(%rcx)
 29daed8:	mov    0xd0(%rsp),%rcx
 29daee0:	mov    0x20(%rcx),%rcx
 29daee4:	lea    (%rcx,%rdx,1),%r9
 29daee8:	movl   $0xa8000006,(%rcx,%rdx,1)
 29daeef:	mov    0x60(%rsp),%rdi
 29daef4:	mov    0x28(%rdi),%rdi
 29daef8:	mov    0x1a0(%rdi),%edi
 29daefe:	mov    %edi,0x4(%rcx,%rdx,1)
 29daf02:	and    $0xfffffffffffffff0,%rsi
 29daf06:	mov    %esi,0x8(%rcx,%rdx,1)
 29daf0a:	mov    %eax,0x28(%rsp)
 29daf0e:	mov    %r15d,0x10(%r9)
 29daf12:	test   %eax,%eax
 29daf14:	je     29dfaff <wasm[0]::function[1013]::helper::array_indexed_publish+0x51df>
 29daf1a:	mov    0xd0(%rsp),%rcx
 29daf22:	mov    0x28(%rcx),%rcx
 29daf26:	mov    0xd0(%rsp),%rdx
 29daf2e:	mov    0x20(%rdx),%rdx
 29daf32:	mov    %eax,%eax
 29daf34:	lea    0x10(%rdx,%rax,1),%rsi
 29daf39:	xor    %rdi,%rdi
 29daf3c:	cmp    %rcx,%rax
 29daf3f:	cmova  %rdi,%rsi
 29daf43:	mov    (%rsi),%esi
 29daf45:	cmp    %rsi,%r12
 29daf48:	ja     29dfb01 <wasm[0]::function[1013]::helper::array_indexed_publish+0x51e1>
 29daf4e:	lea    0x18(%rdx,%rax,1),%rsi
 29daf53:	mov    %rbx,%rdi
 29daf56:	mov    %rsi,%rax
 29daf59:	add    %rdi,%rax
 29daf5c:	mov    %rsi,%r13
 29daf5f:	jb     29dfb03 <wasm[0]::function[1013]::helper::array_indexed_publish+0x51e3>
 29daf65:	add    %rdx,%rcx
 29daf68:	cmp    %rcx,%rax
 29daf6b:	ja     29dfb05 <wasm[0]::function[1013]::helper::array_indexed_publish+0x51e5>
 29daf71:	mov    0x30(%rsp),%ecx
 29daf75:	mov    0x58(%rsp),%edx
 29daf79:	mov    0x10(%rsp),%esi
 29daf7d:	mov    0x18(%rsp),%r8d
 29daf82:	mov    (%rsp),%r10d
 29daf86:	mov    0x20(%rsp),%eax
 29daf8a:	cmp    $0x8000000,%rdi
 29daf91:	jbe    29db024 <wasm[0]::function[1013]::helper::array_indexed_publish+0x704>
 29daf97:	mov    %ecx,0x20(%rsp)
 29daf9b:	mov    %edx,(%rsp)
 29daf9e:	mov    %esi,0x18(%rsp)
 29dafa2:	mov    %r8d,0x10(%rsp)
 29dafa7:	mov    %r10d,0x58(%rsp)
 29dafac:	mov    %eax,0x30(%rsp)
 29dafb0:	mov    0xd8(%rsp),%r12
 29dafb8:	mov    (%r12),%rax
 29dafbc:	mov    0xa8(%rsp),%rcx
 29dafc4:	cmp    %rcx,%rax
 29dafc7:	jae    29df017 <wasm[0]::function[1013]::helper::array_indexed_publish+0x46f7>
 29dafcd:	xor    %edx,%edx
 29dafcf:	mov    $0x8000000,%ecx
 29dafd4:	mov    %r13,%rsi
 29dafd7:	mov    0x60(%rsp),%rdi
 29dafdc:	call   3018cc3 <wasmtime_builtin_memory_fill>
 29dafe1:	mov    0x20(%rsp),%ecx
 29dafe5:	mov    (%rsp),%edx
 29dafe8:	mov    0x18(%rsp),%esi
 29dafec:	mov    0x10(%rsp),%r8d
 29daff1:	mov    0x58(%rsp),%r10d
 29daff6:	mov    0x30(%rsp),%eax
 29daffa:	mov    %rbx,%rdi
 29daffd:	sub    $0x8000000,%rdi
 29db004:	mov    %rdi,%rbx
 29db007:	mov    %r13,%rdi
 29db00a:	add    $0x8000000,%rdi
 29db011:	mov    %rdi,%r13
 29db014:	mov    %rbx,%rdi
 29db017:	cmp    $0x8000000,%rdi
 29db01e:	ja     29daf97 <wasm[0]::function[1013]::helper::array_indexed_publish+0x677>
 29db024:	mov    %ecx,0x30(%rsp)
 29db028:	mov    %edx,0x58(%rsp)
 29db02c:	mov    %esi,0x10(%rsp)
 29db030:	mov    %r8d,0x18(%rsp)
 29db035:	mov    %r10d,(%rsp)
 29db039:	mov    %eax,0x20(%rsp)
 29db03d:	mov    0xd8(%rsp),%r12
 29db045:	mov    (%r12),%rax
 29db049:	mov    0xa8(%rsp),%r9
 29db051:	cmp    %r9,%rax
 29db054:	jae    29df04e <wasm[0]::function[1013]::helper::array_indexed_publish+0x472e>
 29db05a:	xor    %edx,%edx
 29db05c:	mov    %rbx,%rcx
 29db05f:	mov    %r13,%rsi
 29db062:	mov    0x60(%rsp),%rdi
 29db067:	call   3018cc3 <wasmtime_builtin_memory_fill>
 29db06c:	mov    0x28(%rsp),%edx
 29db070:	test   %edx,%edx
 29db072:	je     29dfb07 <wasm[0]::function[1013]::helper::array_indexed_publish+0x51e7>
 29db078:	mov    0x30(%rsp),%ecx
 29db07c:	test   %ecx,%ecx
 29db07e:	je     29dfb09 <wasm[0]::function[1013]::helper::array_indexed_publish+0x51e9>
 29db084:	test   %edx,%edx
 29db086:	je     29dfb0b <wasm[0]::function[1013]::helper::array_indexed_publish+0x51eb>
 29db08c:	mov    0xd0(%rsp),%rax
 29db094:	mov    0x28(%rax),%rax
 29db098:	mov    0xd0(%rsp),%rsi
 29db0a0:	mov    0x20(%rsi),%rsi
 29db0a4:	mov    %edx,%r8d
 29db0a7:	lea    (%rsi,%r8,1),%r10
 29db0ab:	lea    0x10(%rsi,%r8,1),%rdi
 29db0b0:	xor    %rdx,%rdx
 29db0b3:	cmp    %rax,%r8
 29db0b6:	cmova  %rdx,%rdi
 29db0ba:	mov    (%rdi),%edi
 29db0bc:	cmp    %rdi,%r14
 29db0bf:	ja     29dfb0d <wasm[0]::function[1013]::helper::array_indexed_publish+0x51ed>
 29db0c5:	test   %ecx,%ecx
 29db0c7:	je     29dfb0f <wasm[0]::function[1013]::helper::array_indexed_publish+0x51ef>
 29db0cd:	mov    %ecx,%ebx
 29db0cf:	lea    (%rsi,%rbx,1),%r12
 29db0d3:	lea    0x10(%rsi,%rbx,1),%rcx
 29db0d8:	cmp    %rax,%rbx
 29db0db:	cmova  %rdx,%rcx
 29db0df:	mov    (%rcx),%ecx
 29db0e1:	cmp    %rcx,%r14
 29db0e4:	ja     29dfb11 <wasm[0]::function[1013]::helper::array_indexed_publish+0x51f1>
 29db0ea:	lea    0x18(%rsi,%r8,1),%rcx
 29db0ef:	mov    %r14,%r13
 29db0f2:	shl    $0x3,%r13
 29db0f6:	mov    %rcx,%rdx
 29db0f9:	add    %r13,%rdx
 29db0fc:	jb     29dfb13 <wasm[0]::function[1013]::helper::array_indexed_publish+0x51f3>
 29db102:	add    %rsi,%rax
 29db105:	cmp    %rax,%rdx
 29db108:	ja     29dfb15 <wasm[0]::function[1013]::helper::array_indexed_publish+0x51f5>
 29db10e:	lea    0x18(%rsi,%rbx,1),%rdx
 29db113:	mov    %rdx,%rdi
 29db116:	add    %r13,%rdi
 29db119:	jb     29dfb17 <wasm[0]::function[1013]::helper::array_indexed_publish+0x51f7>
 29db11f:	cmp    %rax,%rdi
 29db122:	ja     29dfb19 <wasm[0]::function[1013]::helper::array_indexed_publish+0x51f9>
 29db128:	cmp    %rcx,%rdx
 29db12b:	ja     29db234 <wasm[0]::function[1013]::helper::array_indexed_publish+0x914>
 29db131:	mov    0x58(%rsp),%edi
 29db135:	mov    0x10(%rsp),%r9d
 29db13a:	mov    0x28(%rsp),%r11d
 29db13f:	mov    0x18(%rsp),%eax
 29db143:	mov    (%rsp),%ecx
 29db146:	mov    0x20(%rsp),%edx
 29db14a:	lea    0x18(%r10,%r14,8),%rsi
 29db14f:	mov    %rsi,0x78(%rsp)
 29db154:	lea    0x18(%r12,%r14,8),%r10
 29db159:	mov    %r10,%r14
 29db15c:	cmp    $0x8000000,%r13
 29db163:	mov    %r13,%rbx
 29db166:	ja     29db179 <wasm[0]::function[1013]::helper::array_indexed_publish+0x859>
 29db16c:	mov    0x78(%rsp),%rsi
 29db171:	mov    %rbx,%r10
 29db174:	jmp    29db21b <wasm[0]::function[1013]::helper::array_indexed_publish+0x8fb>
 29db179:	mov    %edi,0x8(%rsp)
 29db17d:	mov    %r9d,0x50(%rsp)
 29db182:	mov    %r11d,0x48(%rsp)
 29db187:	mov    %eax,0x40(%rsp)
 29db18b:	mov    %ecx,0x38(%rsp)
 29db18f:	mov    %edx,0x30(%rsp)
 29db193:	mov    0xd8(%rsp),%r12
 29db19b:	mov    (%r12),%rax
 29db19f:	mov    0xa8(%rsp),%rcx
 29db1a7:	cmp    %rcx,%rax
 29db1aa:	jae    29df082 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4762>
 29db1b0:	mov    $0x8000000,%ecx
 29db1b5:	mov    0x78(%rsp),%rsi
 29db1ba:	sub    $0x8000000,%rsi
 29db1c1:	mov    %r14,%rdx
 29db1c4:	mov    %rsi,0x78(%rsp)
 29db1c9:	sub    $0x8000000,%rdx
 29db1d0:	mov    %rdx,%r14
 29db1d3:	mov    0x60(%rsp),%rdi
 29db1d8:	call   3018c9a <wasmtime_builtin_memory_copy>
 29db1dd:	mov    0x8(%rsp),%edi
 29db1e1:	mov    0x50(%rsp),%r9d
 29db1e6:	mov    0x48(%rsp),%r11d
 29db1eb:	mov    0x40(%rsp),%eax
 29db1ef:	mov    0x38(%rsp),%ecx
 29db1f3:	mov    0x30(%rsp),%edx
 29db1f7:	mov    %rbx,%r10
 29db1fa:	sub    $0x8000000,%r10
 29db201:	cmp    $0x8000000,%r10
 29db208:	jbe    29db216 <wasm[0]::function[1013]::helper::array_indexed_publish+0x8f6>
 29db20e:	mov    %r10,%rbx
 29db211:	jmp    29db179 <wasm[0]::function[1013]::helper::array_indexed_publish+0x859>
 29db216:	mov    0x78(%rsp),%rsi
 29db21b:	sub    %r10,%rsi
 29db21e:	mov    %rsi,0x78(%rsp)
 29db223:	mov    %r14,%rsi
 29db226:	sub    %r10,%rsi
 29db229:	mov    %rsi,%r14
 29db22c:	mov    %r10,%rbx
 29db22f:	jmp    29db313 <wasm[0]::function[1013]::helper::array_indexed_publish+0x9f3>
 29db234:	mov    %r13,%r10
 29db237:	mov    0x58(%rsp),%edi
 29db23b:	mov    0x10(%rsp),%r9d
 29db240:	mov    0x28(%rsp),%r11d
 29db245:	mov    0x18(%rsp),%eax
 29db249:	mov    (%rsp),%ecx
 29db24c:	mov    0x20(%rsp),%edx
 29db250:	lea    0x18(%rsi,%r8,1),%r8
 29db255:	mov    %r8,0x78(%rsp)
 29db25a:	lea    0x18(%rsi,%rbx,1),%rsi
 29db25f:	mov    %rsi,%r14
 29db262:	cmp    $0x8000000,%r10
 29db269:	mov    %r10,%rbx
 29db26c:	jbe    29db313 <wasm[0]::function[1013]::helper::array_indexed_publish+0x9f3>
 29db272:	mov    %edi,0x20(%rsp)
 29db276:	mov    %r9d,(%rsp)
 29db27a:	mov    %r11d,0x18(%rsp)
 29db27f:	mov    %eax,0x28(%rsp)
 29db283:	mov    %ecx,0x10(%rsp)
 29db287:	mov    %edx,0x58(%rsp)
 29db28b:	mov    0xd8(%rsp),%r12
 29db293:	mov    (%r12),%rax
 29db297:	mov    0xa8(%rsp),%rcx
 29db29f:	cmp    %rcx,%rax
 29db2a2:	jae    29df0b6 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4796>
 29db2a8:	mov    $0x8000000,%ecx
 29db2ad:	mov    %r14,%rdx
 29db2b0:	mov    0x78(%rsp),%rsi
 29db2b5:	mov    0x60(%rsp),%rdi
 29db2ba:	call   3018c9a <wasmtime_builtin_memory_copy>
 29db2bf:	mov    0x20(%rsp),%edi
 29db2c3:	mov    (%rsp),%r9d
 29db2c7:	mov    0x18(%rsp),%r11d
 29db2cc:	mov    0x28(%rsp),%eax
 29db2d0:	mov    0x10(%rsp),%ecx
 29db2d4:	mov    0x58(%rsp),%edx
 29db2d8:	mov    %rbx,%rsi
 29db2db:	sub    $0x8000000,%rsi
 29db2e2:	mov    %rsi,%rbx
 29db2e5:	mov    0x78(%rsp),%rsi
 29db2ea:	add    $0x8000000,%rsi
 29db2f1:	mov    %rsi,0x78(%rsp)
 29db2f6:	mov    %r14,%rsi
 29db2f9:	add    $0x8000000,%rsi
 29db300:	mov    %rbx,%r8
 29db303:	mov    %rsi,%r14
 29db306:	cmp    $0x8000000,%r8
 29db30d:	ja     29db272 <wasm[0]::function[1013]::helper::array_indexed_publish+0x952>
 29db313:	mov    %edi,0x58(%rsp)
 29db317:	mov    %r9d,0x10(%rsp)
 29db31c:	mov    %r11d,0x28(%rsp)
 29db321:	mov    %eax,0x18(%rsp)
 29db325:	mov    %ecx,(%rsp)
 29db328:	mov    %edx,0x20(%rsp)
 29db32c:	mov    0xd8(%rsp),%r12
 29db334:	mov    (%r12),%rax
 29db338:	mov    0xa8(%rsp),%rcx
 29db340:	cmp    %rcx,%rax
 29db343:	jae    29df0ea <wasm[0]::function[1013]::helper::array_indexed_publish+0x47ca>
 29db349:	mov    %rbx,%rcx
 29db34c:	mov    %r14,%rdx
 29db34f:	mov    0x78(%rsp),%rsi
 29db354:	jmp    29db364 <wasm[0]::function[1013]::helper::array_indexed_publish+0xa44>
 29db359:	mov    %rbx,%rcx
 29db35c:	mov    %r14,%rdx
 29db35f:	mov    0x78(%rsp),%rsi
 29db364:	mov    %rbx,%rcx
 29db367:	mov    %r14,%rdx
 29db36a:	mov    0x78(%rsp),%rsi
 29db36f:	mov    0x60(%rsp),%rdi
 29db374:	call   3018c9a <wasmtime_builtin_memory_copy>
 29db379:	lea    0x3f(%r15),%ebx
 29db37d:	shr    $0x6,%ebx
 29db380:	mov    %rbx,%rcx
 29db383:	shl    $0x3,%rcx
 29db387:	mov    %rcx,%rax
 29db38a:	shr    $0x20,%rax
 29db38e:	mov    %rcx,%r13
 29db391:	test   %rax,%rax
 29db394:	jne    29dfb1b <wasm[0]::function[1013]::helper::array_indexed_publish+0x51fb>
 29db39a:	mov    %rbx,%rcx
 29db39d:	shl    $0x3,%ecx
 29db3a0:	add    $0x18,%ecx
 29db3a3:	jb     29dfb1d <wasm[0]::function[1013]::helper::array_indexed_publish+0x51fd>
 29db3a9:	mov    0xb0(%rsp),%r14
 29db3b1:	mov    (%r14),%eax
 29db3b4:	mov    %eax,%edx
 29db3b6:	mov    %ecx,%esi
 29db3b8:	add    $0xf,%rsi
 29db3bf:	and    $0xfffffffffffffff0,%rsi
 29db3c3:	lea    (%rdx,%rsi,1),%rdi
 29db3c7:	mov    0x4(%r14),%r8d
 29db3cb:	cmp    %r8,%rdi
 29db3ce:	ja     29df129 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4809>
 29db3d4:	add    $0xf,%ecx
 29db3da:	and    $0xfffffff0,%ecx
 29db3dd:	add    %eax,%ecx
 29db3df:	mov    %ecx,(%r14)
 29db3e2:	mov    0xd0(%rsp),%r15
 29db3ea:	mov    0x20(%r15),%rdi
 29db3ee:	lea    (%rdi,%rdx,1),%rcx
 29db3f2:	movl   $0xa8000006,(%rdi,%rdx,1)
 29db3f9:	mov    0x60(%rsp),%r8
 29db3fe:	mov    0x28(%r8),%r8
 29db402:	mov    0x1a4(%r8),%r8d
 29db409:	mov    %r8d,0x4(%rdi,%rdx,1)
 29db40e:	mov    %esi,0x8(%rdi,%rdx,1)
 29db412:	mov    %eax,0x8(%rsp)
 29db416:	mov    %ebx,0x10(%rcx)
 29db419:	test   %eax,%eax
 29db41b:	je     29dfb1f <wasm[0]::function[1013]::helper::array_indexed_publish+0x51ff>
 29db421:	mov    0xd0(%rsp),%r15
 29db429:	mov    0x28(%r15),%rcx
 29db42d:	mov    0x20(%r15),%rdx
 29db431:	mov    %eax,%eax
 29db433:	lea    0x10(%rdx,%rax,1),%rsi
 29db438:	xor    %rdi,%rdi
 29db43b:	cmp    %rcx,%rax
 29db43e:	cmova  %rdi,%rsi
 29db442:	mov    (%rsi),%esi
 29db444:	cmp    %rsi,%rbx
 29db447:	ja     29dfb21 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5201>
 29db44d:	lea    0x18(%rdx,%rax,1),%rsi
 29db452:	mov    %r13,%r9
 29db455:	mov    %rsi,%rax
 29db458:	add    %r9,%rax
 29db45b:	mov    %rsi,%rbx
 29db45e:	jb     29dfb23 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5203>
 29db464:	add    %rdx,%rcx
 29db467:	cmp    %rcx,%rax
 29db46a:	ja     29dfb25 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5205>
 29db470:	mov    0x58(%rsp),%r8d
 29db475:	mov    0x10(%rsp),%edi
 29db479:	mov    0x28(%rsp),%esi
 29db47d:	mov    0x18(%rsp),%edx
 29db481:	mov    (%rsp),%ecx
 29db484:	mov    0x20(%rsp),%eax
 29db488:	cmp    $0x8000000,%r9
 29db48f:	jbe    29db520 <wasm[0]::function[1013]::helper::array_indexed_publish+0xc00>
 29db495:	mov    %r8d,0x20(%rsp)
 29db49a:	mov    %edi,(%rsp)
 29db49d:	mov    %esi,0x18(%rsp)
 29db4a1:	mov    %edx,0x28(%rsp)
 29db4a5:	mov    %ecx,0x10(%rsp)
 29db4a9:	mov    %eax,0x58(%rsp)
 29db4ad:	mov    0xd8(%rsp),%r12
 29db4b5:	mov    (%r12),%r9
 29db4b9:	mov    0xa8(%rsp),%rax
 29db4c1:	cmp    %rax,%r9
 29db4c4:	jae    29df15b <wasm[0]::function[1013]::helper::array_indexed_publish+0x483b>
 29db4ca:	xor    %edx,%edx
 29db4cc:	mov    $0x8000000,%ecx
 29db4d1:	mov    %rbx,%rsi
 29db4d4:	mov    0x60(%rsp),%rdi
 29db4d9:	call   3018cc3 <wasmtime_builtin_memory_fill>
 29db4de:	mov    0x20(%rsp),%r8d
 29db4e3:	mov    (%rsp),%edi
 29db4e6:	mov    0x18(%rsp),%esi
 29db4ea:	mov    0x28(%rsp),%edx
 29db4ee:	mov    0x10(%rsp),%ecx
 29db4f2:	mov    0x58(%rsp),%eax
 29db4f6:	mov    %r13,%r9
 29db4f9:	sub    $0x8000000,%r9
 29db500:	mov    %r9,%r13
 29db503:	mov    %rbx,%r9
 29db506:	add    $0x8000000,%r9
 29db50d:	mov    %r9,%rbx
 29db510:	mov    %r13,%r9
 29db513:	cmp    $0x8000000,%r9
 29db51a:	ja     29db495 <wasm[0]::function[1013]::helper::array_indexed_publish+0xb75>
 29db520:	mov    %r8d,0x58(%rsp)
 29db525:	mov    %edi,0x10(%rsp)
 29db529:	mov    %esi,0x28(%rsp)
 29db52d:	mov    %edx,0x18(%rsp)
 29db531:	mov    %ecx,(%rsp)
 29db534:	mov    %eax,0x20(%rsp)
 29db538:	mov    0xd8(%rsp),%r12
 29db540:	mov    (%r12),%rax
 29db544:	mov    0xa8(%rsp),%rcx
 29db54c:	cmp    %rcx,%rax
 29db54f:	jae    29df18f <wasm[0]::function[1013]::helper::array_indexed_publish+0x486f>
 29db555:	xor    %edx,%edx
 29db557:	mov    %r13,%rcx
 29db55a:	mov    %rbx,%rsi
 29db55d:	mov    0x60(%rsp),%rdi
 29db562:	call   3018cc3 <wasmtime_builtin_memory_fill>
 29db567:	mov    0x58(%rsp),%ecx
 29db56b:	test   %ecx,%ecx
 29db56d:	je     29dfb27 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5207>
 29db573:	test   %ecx,%ecx
 29db575:	je     29dfb29 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5209>
 29db57b:	mov    0xd0(%rsp),%r15
 29db583:	mov    0x28(%r15),%rax
 29db587:	mov    0x20(%r15),%r9
 29db58b:	mov    %ecx,%r10d
 29db58e:	lea    (%r9,%r10,1),%r11
 29db592:	lea    0x10(%r9,%r10,1),%rdx
 29db597:	xor    %rcx,%rcx
 29db59a:	cmp    %rax,%r10
 29db59d:	cmova  %rcx,%rdx
 29db5a1:	mov    (%rdx),%edx
 29db5a3:	mov    0x8(%rsp),%esi
 29db5a7:	test   %esi,%esi
 29db5a9:	je     29dfb2b <wasm[0]::function[1013]::helper::array_indexed_publish+0x520b>
 29db5af:	test   %esi,%esi
 29db5b1:	je     29dfb2d <wasm[0]::function[1013]::helper::array_indexed_publish+0x520d>
 29db5b7:	mov    %esi,%ebx
 29db5b9:	lea    (%r9,%rbx,1),%r12
 29db5bd:	lea    0x10(%r9,%rbx,1),%rsi
 29db5c2:	cmp    %rax,%rbx
 29db5c5:	cmova  %rcx,%rsi
 29db5c9:	mov    %edx,%r13d
 29db5cc:	mov    (%rsi),%ecx
 29db5ce:	cmp    %rcx,%r13
 29db5d1:	ja     29dfb2f <wasm[0]::function[1013]::helper::array_indexed_publish+0x520f>
 29db5d7:	lea    0x18(%r9,%rbx,1),%rcx
 29db5dc:	mov    %r13,%r14
 29db5df:	shl    $0x3,%r14
 29db5e3:	mov    %rcx,%rdx
 29db5e6:	add    %r14,%rdx
 29db5e9:	jb     29dfb31 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5211>
 29db5ef:	add    %r9,%rax
 29db5f2:	cmp    %rax,%rdx
 29db5f5:	ja     29dfb33 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5213>
 29db5fb:	lea    0x18(%r9,%r10,1),%rdx
 29db600:	mov    %rdx,%rsi
 29db603:	add    %r14,%rsi
 29db606:	jb     29dfb35 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5215>
 29db60c:	cmp    %rax,%rsi
 29db60f:	ja     29dfb37 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5217>
 29db615:	cmp    %rcx,%rdx
 29db618:	ja     29db71e <wasm[0]::function[1013]::helper::array_indexed_publish+0xdfe>
 29db61e:	mov    0x10(%rsp),%eax
 29db622:	mov    0x28(%rsp),%ecx
 29db626:	mov    0x8(%rsp),%edx
 29db62a:	mov    0x18(%rsp),%esi
 29db62e:	mov    (%rsp),%edi
 29db631:	mov    0x20(%rsp),%r8d
 29db636:	lea    0x18(%r12,%r13,8),%r9
 29db63b:	mov    %r9,0x78(%rsp)
 29db640:	lea    0x18(%r11,%r13,8),%r9
 29db645:	mov    %r9,%r13
 29db648:	cmp    $0x8000000,%r14
 29db64f:	mov    %r14,%rbx
 29db652:	ja     29db665 <wasm[0]::function[1013]::helper::array_indexed_publish+0xd45>
 29db658:	mov    0x78(%rsp),%r9
 29db65d:	mov    %rbx,%r11
 29db660:	jmp    29db705 <wasm[0]::function[1013]::helper::array_indexed_publish+0xde5>
 29db665:	mov    %eax,0x30(%rsp)
 29db669:	mov    %ecx,0x38(%rsp)
 29db66d:	mov    %edx,0x40(%rsp)
 29db671:	mov    %esi,0x48(%rsp)
 29db675:	mov    %edi,0x50(%rsp)
 29db679:	mov    %r8d,0x58(%rsp)
 29db67e:	mov    0xd8(%rsp),%r12
 29db686:	mov    (%r12),%rdx
 29db68a:	mov    0xa8(%rsp),%rax
 29db692:	cmp    %rax,%rdx
 29db695:	jae    29df1c3 <wasm[0]::function[1013]::helper::array_indexed_publish+0x48a3>
 29db69b:	mov    $0x8000000,%ecx
 29db6a0:	mov    0x78(%rsp),%rsi
 29db6a5:	sub    $0x8000000,%rsi
 29db6ac:	mov    %r13,%rdx
 29db6af:	mov    %rsi,0x78(%rsp)
 29db6b4:	sub    $0x8000000,%rdx
 29db6bb:	mov    %rdx,%r13
 29db6be:	mov    0x60(%rsp),%rdi
 29db6c3:	call   3018c9a <wasmtime_builtin_memory_copy>
 29db6c8:	mov    0x30(%rsp),%eax
 29db6cc:	mov    0x38(%rsp),%ecx
 29db6d0:	mov    0x40(%rsp),%edx
 29db6d4:	mov    0x48(%rsp),%esi
 29db6d8:	mov    0x50(%rsp),%edi
 29db6dc:	mov    0x58(%rsp),%r8d
 29db6e1:	mov    %rbx,%r11
 29db6e4:	sub    $0x8000000,%r11
 29db6eb:	cmp    $0x8000000,%r11
 29db6f2:	jbe    29db700 <wasm[0]::function[1013]::helper::array_indexed_publish+0xde0>
 29db6f8:	mov    %r11,%rbx
 29db6fb:	jmp    29db665 <wasm[0]::function[1013]::helper::array_indexed_publish+0xd45>
 29db700:	mov    0x78(%rsp),%r9
 29db705:	sub    %r11,%r9
 29db708:	mov    %r9,0x78(%rsp)
 29db70d:	mov    %r13,%r9
 29db710:	sub    %r11,%r9
 29db713:	mov    %r9,%r13
 29db716:	mov    %r11,%rbx
 29db719:	jmp    29db7fa <wasm[0]::function[1013]::helper::array_indexed_publish+0xeda>
 29db71e:	mov    %r14,%r11
 29db721:	mov    0x10(%rsp),%eax
 29db725:	mov    0x28(%rsp),%ecx
 29db729:	mov    0x8(%rsp),%edx
 29db72d:	mov    0x18(%rsp),%esi
 29db731:	mov    (%rsp),%edi
 29db734:	mov    0x20(%rsp),%r8d
 29db739:	lea    0x18(%r9,%rbx,1),%rbx
 29db73e:	mov    %rbx,0x78(%rsp)
 29db743:	lea    0x18(%r9,%r10,1),%r9
 29db748:	mov    %r9,%r13
 29db74b:	cmp    $0x8000000,%r11
 29db752:	mov    %r11,%rbx
 29db755:	jbe    29db7fa <wasm[0]::function[1013]::helper::array_indexed_publish+0xeda>
 29db75b:	mov    %eax,0x20(%rsp)
 29db75f:	mov    %ecx,(%rsp)
 29db762:	mov    %edx,0x18(%rsp)
 29db766:	mov    %esi,0x8(%rsp)
 29db76a:	mov    %edi,0x28(%rsp)
 29db76e:	mov    %r8d,0x10(%rsp)
 29db773:	mov    0xd8(%rsp),%r12
 29db77b:	mov    (%r12),%rax
 29db77f:	mov    0xa8(%rsp),%rcx
 29db787:	cmp    %rcx,%rax
 29db78a:	jae    29df1f7 <wasm[0]::function[1013]::helper::array_indexed_publish+0x48d7>
 29db790:	mov    $0x8000000,%ecx
 29db795:	mov    %r13,%rdx
 29db798:	mov    0x78(%rsp),%rsi
 29db79d:	mov    0x60(%rsp),%rdi
 29db7a2:	call   3018c9a <wasmtime_builtin_memory_copy>
 29db7a7:	mov    0x20(%rsp),%eax
 29db7ab:	mov    (%rsp),%ecx
 29db7ae:	mov    0x18(%rsp),%edx
 29db7b2:	mov    0x8(%rsp),%esi
 29db7b6:	mov    0x28(%rsp),%edi
 29db7ba:	mov    0x10(%rsp),%r8d
 29db7bf:	mov    %rbx,%r9
 29db7c2:	sub    $0x8000000,%r9
 29db7c9:	mov    %r9,%rbx
 29db7cc:	mov    0x78(%rsp),%r9
 29db7d1:	add    $0x8000000,%r9
 29db7d8:	mov    %r9,0x78(%rsp)
 29db7dd:	mov    %r13,%r9
 29db7e0:	add    $0x8000000,%r9
 29db7e7:	mov    %r9,%r13
 29db7ea:	mov    %rbx,%r9
 29db7ed:	cmp    $0x8000000,%r9
 29db7f4:	ja     29db75b <wasm[0]::function[1013]::helper::array_indexed_publish+0xe3b>
 29db7fa:	mov    %eax,0x10(%rsp)
 29db7fe:	mov    %ecx,0x28(%rsp)
 29db802:	mov    %edx,0x8(%rsp)
 29db806:	mov    %esi,0x18(%rsp)
 29db80a:	mov    %edi,(%rsp)
 29db80d:	mov    %r8d,0x20(%rsp)
 29db812:	mov    0xd8(%rsp),%r12
 29db81a:	mov    (%r12),%rax
 29db81e:	mov    0xa8(%rsp),%rcx
 29db826:	cmp    %rcx,%rax
 29db829:	jae    29df22b <wasm[0]::function[1013]::helper::array_indexed_publish+0x490b>
 29db82f:	mov    %rbx,%rcx
 29db832:	mov    %r13,%rdx
 29db835:	mov    0x78(%rsp),%rsi
 29db83a:	jmp    29db84a <wasm[0]::function[1013]::helper::array_indexed_publish+0xf2a>
 29db83f:	mov    %rbx,%rcx
 29db842:	mov    %r13,%rdx
 29db845:	mov    0x78(%rsp),%rsi
 29db84a:	mov    %rbx,%rcx
 29db84d:	mov    %r13,%rdx
 29db850:	mov    0x78(%rsp),%rsi
 29db855:	mov    0x60(%rsp),%rdi
 29db85a:	call   3018c9a <wasmtime_builtin_memory_copy>
 29db85f:	mov    0x10(%rsp),%r12d
 29db864:	mov    %r12,%rax
 29db867:	mov    %r12,0x70(%rsp)
 29db86c:	test   %eax,%r12d
 29db86f:	je     29dfb39 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5219>
 29db875:	mov    0x28(%rsp),%r9d
 29db87a:	test   %r9d,%r9d
 29db87d:	je     29dfb3b <wasm[0]::function[1013]::helper::array_indexed_publish+0x521b>
 29db883:	mov    0x70(%rsp),%rax
 29db888:	test   %eax,%r12d
 29db88b:	je     29dfb3d <wasm[0]::function[1013]::helper::array_indexed_publish+0x521d>
 29db891:	mov    0xd0(%rsp),%r15
 29db899:	mov    0x28(%r15),%rdx
 29db89d:	mov    0x20(%r15),%rax
 29db8a1:	mov    %r12d,%esi
 29db8a4:	add    %rsi,%rax
 29db8a7:	xor    %rdi,%rdi
 29db8aa:	cmp    %rdx,%rsi
 29db8ad:	cmova  %rdi,%rax
 29db8b1:	mov    %r9d,0x28(%rax)
 29db8b5:	mov    0x8(%rsp),%r8d
 29db8ba:	test   %r8d,%r8d
 29db8bd:	je     29dfb3f <wasm[0]::function[1013]::helper::array_indexed_publish+0x521f>
 29db8c3:	mov    %r8d,0x2c(%rax)
 29db8c7:	mov    0x18(%rsp),%edi
 29db8cb:	mov    (%rsp),%esi
 29db8ce:	mov    0x20(%rsp),%edx
 29db8d2:	test   %r8d,%r8d
 29db8d5:	je     29dfb41 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5221>
 29db8db:	test   %r8d,%r8d
 29db8de:	je     29dfb43 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5223>
 29db8e4:	mov    0xd0(%rsp),%r15
 29db8ec:	mov    0x28(%r15),%rax
 29db8f0:	mov    0x20(%r15),%r12
 29db8f4:	mov    %r8d,%r10d
 29db8f7:	lea    0x10(%r12,%r10,1),%r11
 29db8fc:	xor    %r13,%r13
 29db8ff:	cmp    %rax,%r10
 29db902:	cmova  %r13,%r11
 29db906:	mov    (%r11),%ebx
 29db909:	mov    0x68(%rsp),%rcx
 29db90e:	mov    %rcx,%r11
 29db911:	shr    $0x6,%r11d
 29db915:	cmp    %ebx,%r11d
 29db918:	mov    %r11,0x78(%rsp)
 29db91d:	jae    29dfb45 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5225>
 29db923:	mov    %ebx,%r11d
 29db926:	shl    $0x3,%r11
 29db92a:	shr    $0x20,%r11
 29db92e:	test   %r11,%r11
 29db931:	jne    29dfb47 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5227>
 29db937:	shl    $0x3,%ebx
 29db93a:	add    $0x18,%ebx
 29db93d:	jb     29dfb49 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5229>
 29db943:	mov    %r8,%r11
 29db946:	add    %ebx,%r11d
 29db949:	jb     29dfb4b <wasm[0]::function[1013]::helper::array_indexed_publish+0x522b>
 29db94f:	mov    %r11d,%r11d
 29db952:	add    %r11,%r12
 29db955:	cmp    %rax,%r11
 29db958:	cmova  %r13,%r12
 29db95c:	mov    0x78(%rsp),%rax
 29db961:	mov    %rax,%r11
 29db964:	shl    $0x3,%r11d
 29db968:	lea    0x18(%r11),%eax
 29db96c:	mov    %r11,0xc8(%rsp)
 29db974:	sub    %eax,%ebx
 29db976:	sub    %rbx,%r12
 29db979:	mov    (%r12),%r12
 29db97d:	mov    $0x1,%r13d
 29db983:	shl    %cl,%r13
 29db986:	bt     %rcx,%r12
 29db98a:	jb     29db9e5 <wasm[0]::function[1013]::helper::array_indexed_publish+0x10c5>
 29db990:	mov    0x70(%rsp),%rax
 29db995:	mov    0x70(%rsp),%rcx
 29db99a:	test   %ecx,%eax
 29db99c:	je     29dfb4d <wasm[0]::function[1013]::helper::array_indexed_publish+0x522d>
 29db9a2:	test   %ecx,%eax
 29db9a4:	je     29dfb4f <wasm[0]::function[1013]::helper::array_indexed_publish+0x522f>
 29db9aa:	mov    0xd0(%rsp),%r15
 29db9b2:	mov    0x28(%r15),%rbx
 29db9b6:	mov    0xb8(%rsp),%rax
 29db9be:	add    $0x1,%rax
 29db9c5:	mov    %ecx,%r15d
 29db9c8:	mov    0xd0(%rsp),%r11
 29db9d0:	mov    %r15,%r14
 29db9d3:	add    0x20(%r11),%r14
 29db9d7:	xor    %r11,%r11
 29db9da:	cmp    %rbx,%r15
 29db9dd:	cmova  %r11,%r14
 29db9e1:	mov    %rax,0x18(%r14)
 29db9e5:	test   %r9d,%r9d
 29db9e8:	je     29dfb51 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5231>
 29db9ee:	test   %r9d,%r9d
 29db9f1:	je     29dfb53 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5233>
 29db9f7:	mov    0xd0(%rsp),%r15
 29db9ff:	mov    0x28(%r15),%r14
 29dba03:	mov    0x20(%r15),%r15
 29dba07:	mov    %r9d,%r11d
 29dba0a:	lea    0x10(%r15,%r11,1),%rbx
 29dba0f:	xor    %rax,%rax
 29dba12:	cmp    %r14,%r11
 29dba15:	cmova  %rax,%rbx
 29dba19:	mov    (%rbx),%ebx
 29dba1b:	mov    0x68(%rsp),%rcx
 29dba20:	cmp    %ebx,%ecx
 29dba22:	jae    29dfb55 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5235>
 29dba28:	mov    %ebx,%r11d
 29dba2b:	shl    $0x3,%r11
 29dba2f:	shr    $0x20,%r11
 29dba33:	test   %r11,%r11
 29dba36:	jne    29dfb57 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5237>
 29dba3c:	shl    $0x3,%ebx
 29dba3f:	add    $0x18,%ebx
 29dba42:	jb     29dfb59 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5239>
 29dba48:	add    %ebx,%r9d
 29dba4b:	jb     29dfb5b <wasm[0]::function[1013]::helper::array_indexed_publish+0x523b>
 29dba51:	mov    %r9d,%r11d
 29dba54:	lea    (%r15,%r11,1),%r9
 29dba58:	cmp    %r14,%r11
 29dba5b:	cmova  %rax,%r9
 29dba5f:	shl    $0x3,%ecx
 29dba62:	lea    0x18(%rcx),%r11d
 29dba66:	sub    %r11d,%ebx
 29dba69:	sub    %rbx,%r9
 29dba6c:	mov    0x90(%rsp),%rcx
 29dba74:	mov    %rcx,(%r9)
 29dba77:	lea    0x10(%r15,%r10,1),%r9
 29dba7c:	cmp    %r14,%r10
 29dba7f:	cmova  %rax,%r9
 29dba83:	mov    (%r9),%r9d
 29dba86:	mov    0x78(%rsp),%r10
 29dba8b:	cmp    %r9d,%r10d
 29dba8e:	jae    29dfb5d <wasm[0]::function[1013]::helper::array_indexed_publish+0x523d>
 29dba94:	mov    %r9d,%r10d
 29dba97:	shl    $0x3,%r10
 29dba9b:	shr    $0x20,%r10
 29dba9f:	test   %r10,%r10
 29dbaa2:	jne    29dfb5f <wasm[0]::function[1013]::helper::array_indexed_publish+0x523f>
 29dbaa8:	shl    $0x3,%r9d
 29dbaac:	add    $0x18,%r9d
 29dbab0:	jb     29dfb61 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5241>
 29dbab6:	add    %r9d,%r8d
 29dbab9:	jb     29dfb63 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5243>
 29dbabf:	or     %r13,%r12
 29dbac2:	mov    %r13,0x80(%rsp)
 29dbaca:	mov    %r8d,%r10d
 29dbacd:	lea    (%r15,%r10,1),%r8
 29dbad1:	cmp    %r14,%r10
 29dbad4:	cmova  %rax,%r8
 29dbad8:	mov    0xc8(%rsp),%r11
 29dbae0:	lea    0x18(%r11),%eax
 29dbae4:	sub    %eax,%r9d
 29dbae7:	sub    %r9,%r8
 29dbaea:	mov    %r12,(%r8)
 29dbaed:	mov    $0x1,%r10d
 29dbaf3:	mov    0x70(%rsp),%r12
 29dbaf8:	mov    %r12d,0x18(%rsp)
 29dbafd:	mov    %edi,0x28(%rsp)
 29dbb01:	mov    %esi,0x10(%rsp)
 29dbb05:	mov    %edx,0x8(%rsp)
 29dbb09:	test   %r10d,%r10d
 29dbb0c:	mov    %r10,0xa0(%rsp)
 29dbb14:	jne    29dc237 <wasm[0]::function[1013]::helper::array_indexed_publish+0x1917>
 29dbb1a:	mov    0x70(%rsp),%rax
 29dbb1f:	mov    0x70(%rsp),%r12
 29dbb24:	test   %eax,%r12d
 29dbb27:	je     29dfb65 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5245>
 29dbb2d:	test   %eax,%r12d
 29dbb30:	je     29dfb67 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5247>
 29dbb36:	mov    0xd0(%rsp),%r15
 29dbb3e:	mov    0x28(%r15),%rax
 29dbb42:	mov    %r12d,%r8d
 29dbb45:	mov    %r8,%rdi
 29dbb48:	add    0x20(%r15),%rdi
 29dbb4c:	xor    %r9,%r9
 29dbb4f:	cmp    %rax,%r8
 29dbb52:	cmova  %r9,%rdi
 29dbb56:	mov    0x24(%rdi),%eax
 29dbb59:	cmp    $0x2,%eax
 29dbb5c:	sete   %al
 29dbb5f:	mov    0x98(%rsp),%rdi
 29dbb67:	cmp    $0x3,%edi
 29dbb6a:	setne  %cl
 29dbb6d:	test   %al,%cl
 29dbb6f:	je     29dc237 <wasm[0]::function[1013]::helper::array_indexed_publish+0x1917>
 29dbb75:	mov    0x18(%rsp),%r12d
 29dbb7a:	mov    %r12,%rax
 29dbb7d:	mov    %r12,0x70(%rsp)
 29dbb82:	test   %eax,%r12d
 29dbb85:	je     29dfb69 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5249>
 29dbb8b:	mov    0x70(%rsp),%rax
 29dbb90:	test   %eax,%r12d
 29dbb93:	je     29dfb6b <wasm[0]::function[1013]::helper::array_indexed_publish+0x524b>
 29dbb99:	mov    0xd0(%rsp),%r15
 29dbba1:	mov    0x28(%r15),%rsi
 29dbba5:	mov    0x20(%r15),%rdi
 29dbba9:	mov    %r12d,%r9d
 29dbbac:	lea    (%rdi,%r9,1),%rdx
 29dbbb0:	xor    %r8,%r8
 29dbbb3:	cmp    %rsi,%r9
 29dbbb6:	cmova  %r8,%rdx
 29dbbba:	mov    0x28(%rdx),%r9d
 29dbbbe:	mov    0x2c(%rdx),%r10d
 29dbbc2:	test   %r9d,%r9d
 29dbbc5:	je     29dfb6d <wasm[0]::function[1013]::helper::array_indexed_publish+0x524d>
 29dbbcb:	test   %r9d,%r9d
 29dbbce:	je     29dfb6f <wasm[0]::function[1013]::helper::array_indexed_publish+0x524f>
 29dbbd4:	mov    %r9d,%r10d
 29dbbd7:	lea    0x10(%rdi,%r10,1),%r9
 29dbbdc:	cmp    %rsi,%r10
 29dbbdf:	cmova  %r8,%r9
 29dbbe3:	mov    (%r9),%r11d
 29dbbe6:	mov    0x18(%rdx),%r10
 29dbbea:	mov    0x10(%rsp),%esi
 29dbbee:	mov    0x8(%rsp),%edx
 29dbbf2:	mov    %r11d,%r11d
 29dbbf5:	mov    0x68(%rsp),%rcx
 29dbbfa:	cmp    %r11,%rcx
 29dbbfd:	setb   %dil
 29dbc01:	cmp    $0x100000,%rcx
 29dbc08:	setb   %r9b
 29dbc0c:	lea    0x8(%r10,%r10,1),%rax
 29dbc11:	cmp    %rax,%rcx
 29dbc14:	setbe  %al
 29dbc17:	and    %eax,%r9d
 29dbc1a:	or     %r9d,%edi
 29dbc1d:	test   %dil,%dil
 29dbc20:	je     29dc237 <wasm[0]::function[1013]::helper::array_indexed_publish+0x1917>
 29dbc26:	mov    0x18(%rsp),%edx
 29dbc2a:	test   %edx,%edx
 29dbc2c:	je     29dfb71 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5251>
 29dbc32:	test   %edx,%edx
 29dbc34:	je     29dfb73 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5253>
 29dbc3a:	mov    0xd0(%rsp),%r15
 29dbc42:	mov    0x28(%r15),%rax
 29dbc46:	mov    0x20(%r15),%rcx
 29dbc4a:	mov    %edx,%edi
 29dbc4c:	lea    (%rcx,%rdi,1),%rsi
 29dbc50:	xor    %rdx,%rdx
 29dbc53:	cmp    %rax,%rdi
 29dbc56:	cmova  %rdx,%rsi
 29dbc5a:	mov    0x28(%rsi),%edi
 29dbc5d:	mov    0x2c(%rsi),%esi
 29dbc60:	test   %edi,%edi
 29dbc62:	je     29dfb75 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5255>
 29dbc68:	test   %edi,%edi
 29dbc6a:	je     29dfb77 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5257>
 29dbc70:	mov    %edi,%esi
 29dbc72:	lea    0x10(%rcx,%rsi,1),%rcx
 29dbc77:	cmp    %rax,%rsi
 29dbc7a:	cmova  %rdx,%rcx
 29dbc7e:	mov    (%rcx),%eax
 29dbc80:	mov    %eax,%r12d
 29dbc83:	mov    %r12,%rbx
 29dbc86:	shl    $0x2,%rbx
 29dbc8a:	mov    $0x20,%ecx
 29dbc8f:	mov    %rcx,0xc0(%rsp)
 29dbc97:	mov    %rbx,%rcx
 29dbc9a:	shr    $0x20,%rcx
 29dbc9e:	test   %rcx,%rcx
 29dbca1:	jne    29dfb79 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5259>
 29dbca7:	mov    %rax,%rcx
 29dbcaa:	shl    $0x2,%ecx
 29dbcad:	mov    %rax,0xc8(%rsp)
 29dbcb5:	add    $0x14,%ecx
 29dbcb8:	jb     29dfb7b <wasm[0]::function[1013]::helper::array_indexed_publish+0x525b>
 29dbcbe:	mov    0x60(%rsp),%rdi
 29dbcc3:	mov    0x20(%rdi),%rsi
 29dbcc7:	mov    (%rsi),%eax
 29dbcc9:	mov    %eax,%edx
 29dbccb:	mov    %ecx,%edi
 29dbccd:	lea    0xf(%rdi),%r11
 29dbcd1:	mov    %r11,%rdi
 29dbcd4:	and    $0xfffffffffffffff0,%rdi
 29dbcd8:	add    %rdx,%rdi
 29dbcdb:	mov    0x4(%rsi),%r8d
 29dbcdf:	mov    %rsi,0xb8(%rsp)
 29dbce7:	cmp    %r8,%rdi
 29dbcea:	ja     29df26a <wasm[0]::function[1013]::helper::array_indexed_publish+0x494a>
 29dbcf0:	add    $0xf,%ecx
 29dbcf6:	and    $0xfffffff0,%ecx
 29dbcf9:	add    %eax,%ecx
 29dbcfb:	mov    0xb8(%rsp),%r13
 29dbd03:	mov    %ecx,0x0(%r13)
 29dbd07:	mov    0xd0(%rsp),%r15
 29dbd0f:	mov    0x20(%r15),%rsi
 29dbd13:	lea    (%rsi,%rdx,1),%rcx
 29dbd17:	movl   $0xa800000e,(%rsi,%rdx,1)
 29dbd1e:	mov    0x60(%rsp),%rdi
 29dbd23:	mov    0x28(%rdi),%rdi
 29dbd27:	mov    0x19c(%rdi),%edi
 29dbd2d:	mov    %edi,0x4(%rsi,%rdx,1)
 29dbd31:	and    $0xfffffffffffffff0,%r11
 29dbd35:	mov    %r11d,0x8(%rsi,%rdx,1)
 29dbd3a:	mov    %eax,(%rsp)
 29dbd3d:	mov    0xc8(%rsp),%r15
 29dbd45:	mov    %r15d,0x10(%rcx)
 29dbd49:	test   %eax,%eax
 29dbd4b:	je     29dfb7d <wasm[0]::function[1013]::helper::array_indexed_publish+0x525d>
 29dbd51:	mov    0xd0(%rsp),%r15
 29dbd59:	mov    0x28(%r15),%rcx
 29dbd5d:	mov    0x20(%r15),%rdx
 29dbd61:	mov    %eax,%esi
 29dbd63:	lea    (%rdx,%rsi,1),%rax
 29dbd67:	lea    0x10(%rdx,%rsi,1),%rdi
 29dbd6c:	xor    %r8,%r8
 29dbd6f:	cmp    %rcx,%rsi
 29dbd72:	cmova  %r8,%rdi
 29dbd76:	mov    (%rdi),%edi
 29dbd78:	cmp    %rdi,%r12
 29dbd7b:	ja     29dfb7f <wasm[0]::function[1013]::helper::array_indexed_publish+0x525f>
 29dbd81:	lea    0x14(%rdx,%rsi,1),%r13
 29dbd86:	mov    %r13,%rsi
 29dbd89:	add    %rbx,%rsi
 29dbd8c:	jb     29dfb81 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5261>
 29dbd92:	add    %rdx,%rcx
 29dbd95:	cmp    %rcx,%rsi
 29dbd98:	ja     29dfb83 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5263>
 29dbd9e:	mov    0x18(%rsp),%ecx
 29dbda2:	mov    0x28(%rsp),%edi
 29dbda6:	mov    0x10(%rsp),%r8d
 29dbdab:	mov    0x8(%rsp),%r11d
 29dbdb0:	lea    0x14(%rax,%r12,4),%rbx
 29dbdb5:	test   %r12,%r12
 29dbdb8:	je     29dbe17 <wasm[0]::function[1013]::helper::array_indexed_publish+0x14f7>
 29dbdbe:	mov    %ecx,0x8(%rsp)
 29dbdc2:	mov    %edi,0x10(%rsp)
 29dbdc6:	mov    %r8d,0x28(%rsp)
 29dbdcb:	mov    %r11d,0x18(%rsp)
 29dbdd0:	mov    0xd8(%rsp),%r12
 29dbdd8:	mov    (%r12),%rcx
 29dbddc:	mov    0xa8(%rsp),%rax
 29dbde4:	cmp    %rax,%rcx
 29dbde7:	jae    29df29c <wasm[0]::function[1013]::helper::array_indexed_publish+0x497c>
 29dbded:	movl   $0x0,0x0(%r13)
 29dbdf5:	mov    0x8(%rsp),%ecx
 29dbdf9:	mov    0x10(%rsp),%edi
 29dbdfd:	mov    0x28(%rsp),%r8d
 29dbe02:	mov    0x18(%rsp),%r11d
 29dbe07:	add    $0x4,%r13
 29dbe0e:	cmp    %rbx,%r13
 29dbe11:	jne    29dbdbe <wasm[0]::function[1013]::helper::array_indexed_publish+0x149e>
 29dbe17:	mov    %ecx,0x8(%rsp)
 29dbe1b:	xor    %r12d,%r12d
 29dbe1e:	mov    $0x1,%eax
 29dbe23:	mov    0x60(%rsp),%rdx
 29dbe28:	mov    %rax,0x88(%rsp)
 29dbe30:	mov    0x28(%rdx),%rsi
 29dbe34:	mov    0x120(%rsi),%eax
 29dbe3a:	mov    %rax,%r14
 29dbe3d:	mov    $0x10,%r15d
 29dbe43:	mov    %r15,0xb0(%rsp)
 29dbe4b:	mov    %r12,0x78(%rsp)
 29dbe50:	mov    %edi,0x18(%rsp)
 29dbe54:	mov    %r8d,0x28(%rsp)
 29dbe59:	mov    %r11d,0x10(%rsp)
 29dbe5e:	mov    0xd8(%rsp),%rcx
 29dbe66:	mov    (%rcx),%r9
 29dbe69:	mov    0xa8(%rsp),%rax
 29dbe71:	cmp    %rax,%r9
 29dbe74:	jae    29df2d0 <wasm[0]::function[1013]::helper::array_indexed_publish+0x49b0>
 29dbe7a:	mov    0xc8(%rsp),%rcx
 29dbe82:	jmp    29dbe8f <wasm[0]::function[1013]::helper::array_indexed_publish+0x156f>
 29dbe87:	mov    0xc8(%rsp),%rcx
 29dbe8f:	cmp    %ecx,%r12d
 29dbe92:	jae    29dc1a8 <wasm[0]::function[1013]::helper::array_indexed_publish+0x1888>
 29dbe98:	mov    0x8(%rsp),%eax
 29dbe9c:	xor    %edx,%edx
 29dbe9e:	test   %eax,%eax
 29dbea0:	je     29dfb85 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5265>
 29dbea6:	test   %eax,%eax
 29dbea8:	je     29dfb87 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5267>
 29dbeae:	mov    0xd0(%rsp),%r15
 29dbeb6:	mov    0x28(%r15),%rdi
 29dbeba:	mov    0x20(%r15),%r8
 29dbebe:	mov    %eax,%ecx
 29dbec0:	lea    (%r8,%rcx,1),%rax
 29dbec4:	xor    %r9,%r9
 29dbec7:	cmp    %rdi,%rcx
 29dbeca:	cmova  %r9,%rax
 29dbece:	mov    0x28(%rax),%ecx
 29dbed1:	mov    0x2c(%rax),%esi
 29dbed4:	test   %ecx,%ecx
 29dbed6:	je     29dfb89 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5269>
 29dbedc:	test   %ecx,%ecx
 29dbede:	je     29dfb8b <wasm[0]::function[1013]::helper::array_indexed_publish+0x526b>
 29dbee4:	mov    %ecx,%eax
 29dbee6:	lea    0x10(%r8,%rax,1),%r8
 29dbeeb:	cmp    %rdi,%rax
 29dbeee:	cmova  %r9,%r8
 29dbef2:	mov    (%r8),%r8d
 29dbef5:	mov    0x18(%rsp),%edi
 29dbef9:	mov    %r12d,%r9d
 29dbefc:	mov    %r8d,%r8d
 29dbeff:	cmp    %r8,%r9
 29dbf02:	jb     29dbf15 <wasm[0]::function[1013]::helper::array_indexed_publish+0x15f5>
 29dbf08:	mov    0x80(%rsp),%r15
 29dbf10:	jmp    29dc04a <wasm[0]::function[1013]::helper::array_indexed_publish+0x172a>
 29dbf15:	xor    %edx,%edx
 29dbf17:	test   %esi,%esi
 29dbf19:	je     29dfb8d <wasm[0]::function[1013]::helper::array_indexed_publish+0x526d>
 29dbf1f:	test   %esi,%esi
 29dbf21:	je     29dfb8f <wasm[0]::function[1013]::helper::array_indexed_publish+0x526f>
 29dbf27:	mov    0xd0(%rsp),%r15
 29dbf2f:	mov    0x28(%r15),%rdi
 29dbf33:	mov    0x20(%r15),%r8
 29dbf37:	mov    %esi,%r11d
 29dbf3a:	lea    0x10(%r8,%r11,1),%r10
 29dbf3f:	xor    %r9,%r9
 29dbf42:	cmp    %rdi,%r11
 29dbf45:	cmova  %r9,%r10
 29dbf49:	mov    (%r10),%r10d
 29dbf4c:	mov    %r12,%r11
 29dbf4f:	shr    $0x6,%r11d
 29dbf53:	cmp    %r10d,%r11d
 29dbf56:	jae    29dfb91 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5271>
 29dbf5c:	mov    %r10d,%ebx
 29dbf5f:	shl    $0x3,%rbx
 29dbf63:	shr    $0x20,%rbx
 29dbf67:	test   %rbx,%rbx
 29dbf6a:	jne    29dfb93 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5273>
 29dbf70:	shl    $0x3,%r10d
 29dbf74:	add    $0x18,%r10d
 29dbf78:	jb     29dfb95 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5275>
 29dbf7e:	add    %r10d,%esi
 29dbf81:	jb     29dfb97 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5277>
 29dbf87:	mov    %esi,%ebx
 29dbf89:	lea    (%r8,%rbx,1),%rsi
 29dbf8d:	cmp    %rdi,%rbx
 29dbf90:	cmova  %r9,%rsi
 29dbf94:	shl    $0x3,%r11d
 29dbf98:	lea    0x18(%r11),%edi
 29dbf9c:	sub    %edi,%r10d
 29dbf9f:	sub    %r10,%rsi
 29dbfa2:	mov    (%rsi),%rsi
 29dbfa5:	mov    0x18(%rsp),%edi
 29dbfa9:	bt     %r12,%rsi
 29dbfad:	jb     29dbfc0 <wasm[0]::function[1013]::helper::array_indexed_publish+0x16a0>
 29dbfb3:	mov    0x80(%rsp),%r15
 29dbfbb:	jmp    29dc04a <wasm[0]::function[1013]::helper::array_indexed_publish+0x172a>
 29dbfc0:	mov    0xd0(%rsp),%r15
 29dbfc8:	mov    0x28(%r15),%rdx
 29dbfcc:	mov    0x20(%r15),%rdi
 29dbfd0:	lea    0x10(%rdi,%rax,1),%r8
 29dbfd5:	xor    %rsi,%rsi
 29dbfd8:	cmp    %rdx,%rax
 29dbfdb:	cmova  %rsi,%r8
 29dbfdf:	mov    (%r8),%eax
 29dbfe2:	cmp    %eax,%r12d
 29dbfe5:	jae    29dfb99 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5279>
 29dbfeb:	mov    %eax,%r8d
 29dbfee:	shl    $0x3,%r8
 29dbff2:	shr    $0x20,%r8
 29dbff6:	test   %r8,%r8
 29dbff9:	jne    29dfb9b <wasm[0]::function[1013]::helper::array_indexed_publish+0x527b>
 29dbfff:	mov    $0x3,%r8d
 29dc005:	mov    %r8,0x78(%rsp)
 29dc00a:	shl    $0x3,%eax
 29dc00d:	add    $0x18,%eax
 29dc010:	jb     29dfb9d <wasm[0]::function[1013]::helper::array_indexed_publish+0x527d>
 29dc016:	add    %eax,%ecx
 29dc018:	jb     29dfb9f <wasm[0]::function[1013]::helper::array_indexed_publish+0x527f>
 29dc01e:	mov    %ecx,%r8d
 29dc021:	lea    (%rdi,%r8,1),%rcx
 29dc025:	cmp    %rdx,%r8
 29dc028:	cmova  %rsi,%rcx
 29dc02c:	mov    %r12,%rdx
 29dc02f:	shl    $0x3,%edx
 29dc032:	add    $0x18,%edx
 29dc038:	sub    %edx,%eax
 29dc03a:	sub    %rax,%rcx
 29dc03d:	mov    (%rcx),%r15
 29dc040:	xor    %edi,%edi
 29dc042:	mov    0x88(%rsp),%rdx
 29dc04a:	mov    %edi,0x18(%rsp)
 29dc04e:	test   %edx,%edx
 29dc050:	jne    29dc070 <wasm[0]::function[1013]::helper::array_indexed_publish+0x1750>
 29dc056:	mov    0xc0(%rsp),%rcx
 29dc05e:	mov    0x78(%rsp),%rsi
 29dc063:	mov    0xb8(%rsp),%r13
 29dc06b:	jmp    29dc171 <wasm[0]::function[1013]::helper::array_indexed_publish+0x1851>
 29dc070:	mov    0xb8(%rsp),%r13
 29dc078:	mov    0x0(%r13),%eax
 29dc07c:	mov    %eax,%edx
 29dc07e:	lea    0x20(%rdx),%rcx
 29dc082:	mov    0x4(%r13),%esi
 29dc086:	cmp    %rsi,%rcx
 29dc089:	ja     29df30c <wasm[0]::function[1013]::helper::array_indexed_publish+0x49ec>
 29dc08f:	lea    0x20(%rax),%ecx
 29dc092:	mov    %ecx,0x0(%r13)
 29dc096:	mov    0xd0(%rsp),%rdi
 29dc09e:	mov    0x20(%rdi),%rsi
 29dc0a2:	lea    (%rsi,%rdx,1),%rdi
 29dc0a6:	movl   $0xb0000042,(%rsi,%rdx,1)
 29dc0ad:	mov    %r14d,0x4(%rsi,%rdx,1)
 29dc0b2:	mov    0xc0(%rsp),%rcx
 29dc0ba:	mov    %ecx,0x8(%rsi,%rdx,1)
 29dc0be:	mov    %r15,0x10(%rdi)
 29dc0c2:	mov    0x78(%rsp),%rsi
 29dc0c7:	mov    %esi,0x18(%rdi)
 29dc0ca:	mov    0x18(%rsp),%r8d
 29dc0cf:	mov    %r8d,0x1c(%rdi)
 29dc0d3:	mov    (%rsp),%edx
 29dc0d6:	test   %edx,%edx
 29dc0d8:	je     29dfba1 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5281>
 29dc0de:	test   %eax,%eax
 29dc0e0:	je     29dfba3 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5283>
 29dc0e6:	test   %edx,%edx
 29dc0e8:	je     29dfba5 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5285>
 29dc0ee:	mov    0xd0(%rsp),%rdi
 29dc0f6:	mov    0x28(%rdi),%rdi
 29dc0fa:	mov    0xd0(%rsp),%r8
 29dc102:	mov    0x20(%r8),%r8
 29dc106:	mov    %edx,%r10d
 29dc109:	lea    0x10(%r8,%r10,1),%r11
 29dc10e:	xor    %r9,%r9
 29dc111:	cmp    %rdi,%r10
 29dc114:	cmova  %r9,%r11
 29dc118:	mov    (%r11),%r10d
 29dc11b:	cmp    %r10d,%r12d
 29dc11e:	jae    29dfba7 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5287>
 29dc124:	mov    %r10d,%r11d
 29dc127:	shl    $0x2,%r11
 29dc12b:	shr    $0x20,%r11
 29dc12f:	test   %r11,%r11
 29dc132:	jne    29dfba9 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5289>
 29dc138:	shl    $0x2,%r10d
 29dc13c:	add    $0x14,%r10d
 29dc140:	jb     29dfbab <wasm[0]::function[1013]::helper::array_indexed_publish+0x528b>
 29dc146:	add    %r10d,%edx
 29dc149:	jb     29dfbad <wasm[0]::function[1013]::helper::array_indexed_publish+0x528d>
 29dc14f:	mov    %edx,%r11d
 29dc152:	lea    (%r8,%r11,1),%rdx
 29dc156:	cmp    %rdi,%r11
 29dc159:	cmova  %r9,%rdx
 29dc15d:	mov    %r12,%rdi
 29dc160:	shl    $0x2,%edi
 29dc163:	add    $0x14,%edi
 29dc169:	sub    %edi,%r10d
 29dc16c:	sub    %r10,%rdx
 29dc16f:	mov    %eax,(%rdx)
 29dc171:	mov    0x18(%rsp),%edi
 29dc175:	mov    0x28(%rsp),%r8d
 29dc17a:	mov    0x10(%rsp),%r11d
 29dc17f:	add    $0x1,%r12d
 29dc186:	mov    %rsi,0x78(%rsp)
 29dc18b:	mov    %r15,0x80(%rsp)
 29dc193:	mov    %r13,0xb8(%rsp)
 29dc19b:	mov    %rcx,0xc0(%rsp)
 29dc1a3:	jmp    29dbe50 <wasm[0]::function[1013]::helper::array_indexed_publish+0x1530>
 29dc1a8:	mov    0x60(%rsp),%rdi
 29dc1ad:	mov    0xa00(%rdi),%edx
 29dc1b3:	mov    0xa10(%rdi),%eax
 29dc1b9:	mov    0x8(%rsp),%r12d
 29dc1be:	mov    %r12,%rsi
 29dc1c1:	mov    %r12,0x70(%rsp)
 29dc1c6:	test   %esi,%r12d
 29dc1c9:	je     29dfbaf <wasm[0]::function[1013]::helper::array_indexed_publish+0x528f>
 29dc1cf:	test   %edx,%edx
 29dc1d1:	je     29dfbb1 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5291>
 29dc1d7:	mov    0x70(%rsp),%r11
 29dc1dc:	test   %r11d,%r12d
 29dc1df:	je     29dfbb3 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5293>
 29dc1e5:	mov    0xd0(%rsp),%r15
 29dc1ed:	mov    0x28(%r15),%rdi
 29dc1f1:	mov    0x20(%r15),%rsi
 29dc1f5:	mov    %r12d,%r8d
 29dc1f8:	add    %r8,%rsi
 29dc1fb:	xor    %r9,%r9
 29dc1fe:	cmp    %rdi,%r8
 29dc201:	cmova  %r9,%rsi
 29dc205:	mov    %edx,0x28(%rsi)
 29dc208:	test   %eax,%eax
 29dc20a:	je     29dfbb5 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5295>
 29dc210:	mov    %eax,0x2c(%rsi)
 29dc213:	movl   $0x0,0x30(%rsi)
 29dc21a:	mov    (%rsp),%eax
 29dc21d:	test   %eax,%eax
 29dc21f:	je     29dfbb7 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5297>
 29dc225:	mov    %eax,0x30(%rsi)
 29dc228:	movl   $0x3,0x24(%rsi)
 29dc22f:	mov    0x28(%rsp),%esi
 29dc233:	mov    0x10(%rsp),%edx
 29dc237:	mov    0x88(%rsp),%r12
 29dc23f:	test   %r12d,%r12d
 29dc242:	jne    29dc255 <wasm[0]::function[1013]::helper::array_indexed_publish+0x1935>
 29dc248:	mov    0xa0(%rsp),%r10
 29dc250:	jmp    29dc978 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2058>
 29dc255:	mov    0x70(%rsp),%rax
 29dc25a:	mov    0x70(%rsp),%r12
 29dc25f:	test   %eax,%r12d
 29dc262:	je     29dfbb9 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5299>
 29dc268:	test   %eax,%r12d
 29dc26b:	je     29dfbbb <wasm[0]::function[1013]::helper::array_indexed_publish+0x529b>
 29dc271:	mov    0xd0(%rsp),%r15
 29dc279:	mov    0x28(%r15),%rax
 29dc27d:	mov    0x20(%r15),%r9
 29dc281:	mov    %r12d,%edi
 29dc284:	lea    (%r9,%rdi,1),%r8
 29dc288:	xor    %r10,%r10
 29dc28b:	cmp    %rax,%rdi
 29dc28e:	cmova  %r10,%r8
 29dc292:	mov    0x30(%r8),%edi
 29dc296:	test   %edi,%edi
 29dc298:	je     29dfbbd <wasm[0]::function[1013]::helper::array_indexed_publish+0x529d>
 29dc29e:	test   %edi,%edi
 29dc2a0:	je     29dfbbf <wasm[0]::function[1013]::helper::array_indexed_publish+0x529f>
 29dc2a6:	mov    %edi,%r11d
 29dc2a9:	lea    0x10(%r9,%r11,1),%r9
 29dc2ae:	cmp    %rax,%r11
 29dc2b1:	cmova  %r10,%r9
 29dc2b5:	mov    (%r9),%ebx
 29dc2b8:	mov    %rbx,0x78(%rsp)
 29dc2bd:	mov    0x18(%r8),%r14
 29dc2c1:	mov    %r14,0x80(%rsp)
 29dc2c9:	mov    %ebx,%r12d
 29dc2cc:	mov    0x68(%rsp),%rcx
 29dc2d1:	cmp    %r12,%rcx
 29dc2d4:	setb   %al
 29dc2d7:	cmp    $0x100000,%rcx
 29dc2de:	setb   %r8b
 29dc2e2:	lea    0x8(%r14,%r14,1),%rcx
 29dc2e7:	mov    0x68(%rsp),%r9
 29dc2ec:	cmp    %rcx,%r9
 29dc2ef:	setbe  %r9b
 29dc2f3:	and    %r9d,%r8d
 29dc2f6:	or     %r8d,%eax
 29dc2f9:	test   %al,%al
 29dc2fb:	jne    29dc30e <wasm[0]::function[1013]::helper::array_indexed_publish+0x19ee>
 29dc301:	mov    0xa0(%rsp),%r10
 29dc309:	jmp    29dc978 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2058>
 29dc30e:	mov    0x68(%rsp),%rcx
 29dc313:	cmp    %r12,%rcx
 29dc316:	jb     29dc75d <wasm[0]::function[1013]::helper::array_indexed_publish+0x1e3d>
 29dc31c:	mov    0x78(%rsp),%rax
 29dc321:	mov    0x78(%rsp),%rbx
 29dc326:	test   %eax,%ebx
 29dc328:	je     29dc338 <wasm[0]::function[1013]::helper::array_indexed_publish+0x1a18>
 29dc32e:	mov    0x78(%rsp),%rbx
 29dc333:	jmp    29dc33d <wasm[0]::function[1013]::helper::array_indexed_publish+0x1a1d>
 29dc338:	mov    $0x4,%ebx
 29dc33d:	mov    %edi,(%rsp)
 29dc340:	mov    0x70(%rsp),%rax
 29dc345:	mov    %eax,0x10(%rsp)
 29dc349:	mov    %esi,0x28(%rsp)
 29dc34d:	mov    %edx,0x8(%rsp)
 29dc351:	mov    0xd8(%rsp),%rax
 29dc359:	mov    (%rax),%rax
 29dc35c:	mov    0xa8(%rsp),%rcx
 29dc364:	cmp    %rcx,%rax
 29dc367:	jae    29df346 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4a26>
 29dc36d:	mov    %ebx,%r15d
 29dc370:	mov    0x68(%rsp),%rcx
 29dc375:	cmp    %r15,%rcx
 29dc378:	jb     29dc399 <wasm[0]::function[1013]::helper::array_indexed_publish+0x1a79>
 29dc37e:	mov    (%rsp),%edi
 29dc381:	mov    0x10(%rsp),%eax
 29dc385:	mov    %rax,0x70(%rsp)
 29dc38a:	mov    0x28(%rsp),%esi
 29dc38e:	mov    0x8(%rsp),%edx
 29dc392:	shl    $1,%ebx
 29dc394:	jmp    29dc33d <wasm[0]::function[1013]::helper::array_indexed_publish+0x1a1d>
 29dc399:	mov    %r15,%r13
 29dc39c:	shl    $0x2,%r13
 29dc3a0:	mov    %r13,%rax
 29dc3a3:	shr    $0x20,%rax
 29dc3a7:	test   %rax,%rax
 29dc3aa:	jne    29dfbc1 <wasm[0]::function[1013]::helper::array_indexed_publish+0x52a1>
 29dc3b0:	mov    %rbx,%rcx
 29dc3b3:	shl    $0x2,%ecx
 29dc3b6:	add    $0x14,%ecx
 29dc3b9:	jb     29dfbc3 <wasm[0]::function[1013]::helper::array_indexed_publish+0x52a3>
 29dc3bf:	mov    0x60(%rsp),%rdi
 29dc3c4:	mov    0x20(%rdi),%rsi
 29dc3c8:	mov    (%rsi),%eax
 29dc3ca:	mov    %eax,%edx
 29dc3cc:	mov    %ecx,%edi
 29dc3ce:	lea    0xf(%rdi),%r8
 29dc3d2:	mov    %r8,%rdi
 29dc3d5:	and    $0xfffffffffffffff0,%rdi
 29dc3d9:	add    %rdx,%rdi
 29dc3dc:	mov    0x4(%rsi),%r9d
 29dc3e0:	cmp    %r9,%rdi
 29dc3e3:	ja     29df37a <wasm[0]::function[1013]::helper::array_indexed_publish+0x4a5a>
 29dc3e9:	add    $0xf,%ecx
 29dc3ef:	and    $0xfffffff0,%ecx
 29dc3f2:	add    %eax,%ecx
 29dc3f4:	mov    %ecx,(%rsi)
 29dc3f6:	mov    0xd0(%rsp),%rcx
 29dc3fe:	mov    0x20(%rcx),%rcx
 29dc402:	lea    (%rcx,%rdx,1),%rsi
 29dc406:	movl   $0xa800000e,(%rcx,%rdx,1)
 29dc40d:	mov    0x60(%rsp),%rdi
 29dc412:	mov    0x28(%rdi),%rdi
 29dc416:	mov    0x19c(%rdi),%edi
 29dc41c:	mov    %edi,0x4(%rcx,%rdx,1)
 29dc420:	and    $0xfffffffffffffff0,%r8
 29dc424:	mov    %r8d,0x8(%rcx,%rdx,1)
 29dc429:	mov    %eax,0x18(%rsp)
 29dc42d:	mov    %ebx,0x10(%rsi)
 29dc430:	test   %eax,%eax
 29dc432:	je     29dfbc5 <wasm[0]::function[1013]::helper::array_indexed_publish+0x52a5>
 29dc438:	mov    0xd0(%rsp),%rcx
 29dc440:	mov    0x28(%rcx),%rcx
 29dc444:	mov    0xd0(%rsp),%rdx
 29dc44c:	mov    0x20(%rdx),%rdx
 29dc450:	mov    %eax,%eax
 29dc452:	lea    (%rdx,%rax,1),%rdi
 29dc456:	lea    0x10(%rdx,%rax,1),%rsi
 29dc45b:	xor    %r8,%r8
 29dc45e:	cmp    %rcx,%rax
 29dc461:	cmova  %r8,%rsi
 29dc465:	mov    (%rsi),%esi
 29dc467:	cmp    %rsi,%r15
 29dc46a:	ja     29dfbc7 <wasm[0]::function[1013]::helper::array_indexed_publish+0x52a7>
 29dc470:	lea    0x14(%rdx,%rax,1),%r14
 29dc475:	mov    %r14,%rax
 29dc478:	add    %r13,%rax
 29dc47b:	jb     29dfbc9 <wasm[0]::function[1013]::helper::array_indexed_publish+0x52a9>
 29dc481:	add    %rdx,%rcx
 29dc484:	cmp    %rcx,%rax
 29dc487:	ja     29dfbcb <wasm[0]::function[1013]::helper::array_indexed_publish+0x52ab>
 29dc48d:	mov    (%rsp),%eax
 29dc490:	mov    0x10(%rsp),%ecx
 29dc494:	mov    %rcx,0x70(%rsp)
 29dc499:	mov    0x28(%rsp),%esi
 29dc49d:	mov    0x8(%rsp),%edx
 29dc4a1:	lea    0x14(%rdi,%r15,4),%rbx
 29dc4a6:	test   %r15,%r15
 29dc4a9:	je     29dc50a <wasm[0]::function[1013]::helper::array_indexed_publish+0x1bea>
 29dc4af:	mov    %eax,0x8(%rsp)
 29dc4b3:	mov    0x70(%rsp),%rax
 29dc4b8:	mov    %eax,0x28(%rsp)
 29dc4bc:	mov    %esi,0x10(%rsp)
 29dc4c0:	mov    %edx,(%rsp)
 29dc4c3:	mov    0xd8(%rsp),%rax
 29dc4cb:	mov    (%rax),%rax
 29dc4ce:	mov    0xa8(%rsp),%rcx
 29dc4d6:	cmp    %rcx,%rax
 29dc4d9:	jae    29df3ac <wasm[0]::function[1013]::helper::array_indexed_publish+0x4a8c>
 29dc4df:	movl   $0x0,(%r14)
 29dc4e6:	mov    0x8(%rsp),%eax
 29dc4ea:	mov    0x28(%rsp),%ecx
 29dc4ee:	mov    %rcx,0x70(%rsp)
 29dc4f3:	mov    0x10(%rsp),%esi
 29dc4f7:	mov    (%rsp),%edx
 29dc4fa:	add    $0x4,%r14
 29dc501:	cmp    %rbx,%r14
 29dc504:	jne    29dc4af <wasm[0]::function[1013]::helper::array_indexed_publish+0x1b8f>
 29dc50a:	mov    0x18(%rsp),%edi
 29dc50e:	test   %edi,%edi
 29dc510:	je     29dfbcd <wasm[0]::function[1013]::helper::array_indexed_publish+0x52ad>
 29dc516:	test   %eax,%eax
 29dc518:	je     29dfbcf <wasm[0]::function[1013]::helper::array_indexed_publish+0x52af>
 29dc51e:	test   %edi,%edi
 29dc520:	je     29dfbd1 <wasm[0]::function[1013]::helper::array_indexed_publish+0x52b1>
 29dc526:	mov    0xd0(%rsp),%r15
 29dc52e:	mov    0x28(%r15),%r10
 29dc532:	mov    0x20(%r15),%r9
 29dc536:	mov    %edi,%r13d
 29dc539:	lea    (%r9,%r13,1),%r8
 29dc53d:	lea    0x10(%r9,%r13,1),%r11
 29dc542:	xor    %r15,%r15
 29dc545:	cmp    %r10,%r13
 29dc548:	cmova  %r15,%r11
 29dc54c:	mov    (%r11),%r11d
 29dc54f:	cmp    %r11,%r12
 29dc552:	ja     29dfbd3 <wasm[0]::function[1013]::helper::array_indexed_publish+0x52b3>
 29dc558:	test   %eax,%eax
 29dc55a:	je     29dfbd5 <wasm[0]::function[1013]::helper::array_indexed_publish+0x52b5>
 29dc560:	mov    %eax,%r14d
 29dc563:	lea    (%r9,%r14,1),%r11
 29dc567:	lea    0x10(%r9,%r14,1),%rbx
 29dc56c:	cmp    %r10,%r14
 29dc56f:	cmova  %r15,%rbx
 29dc573:	mov    (%rbx),%ecx
 29dc575:	cmp    %rcx,%r12
 29dc578:	ja     29dfbd7 <wasm[0]::function[1013]::helper::array_indexed_publish+0x52b7>
 29dc57e:	lea    0x14(%r9,%r13,1),%r13
 29dc583:	mov    %r12,%rbx
 29dc586:	shl    $0x2,%rbx
 29dc58a:	mov    %r13,%r15
 29dc58d:	add    %rbx,%r15
 29dc590:	jb     29dfbd9 <wasm[0]::function[1013]::helper::array_indexed_publish+0x52b9>
 29dc596:	add    %r9,%r10
 29dc599:	cmp    %r10,%r15
 29dc59c:	ja     29dfbdb <wasm[0]::function[1013]::helper::array_indexed_publish+0x52bb>
 29dc5a2:	lea    0x14(%r9,%r14,1),%r15
 29dc5a7:	mov    %r15,%r9
 29dc5aa:	add    %rbx,%r9
 29dc5ad:	jb     29dfbdd <wasm[0]::function[1013]::helper::array_indexed_publish+0x52bd>
 29dc5b3:	cmp    %r10,%r9
 29dc5b6:	ja     29dfbdf <wasm[0]::function[1013]::helper::array_indexed_publish+0x52bf>
 29dc5bc:	mov    0x78(%rsp),%rcx
 29dc5c1:	mov    0x78(%rsp),%rbx
 29dc5c6:	test   %ecx,%ebx
 29dc5c8:	jne    29dc5dd <wasm[0]::function[1013]::helper::array_indexed_publish+0x1cbd>
 29dc5ce:	mov    0x70(%rsp),%rax
 29dc5d3:	mov    0x70(%rsp),%r12
 29dc5d8:	jmp    29dc715 <wasm[0]::function[1013]::helper::array_indexed_publish+0x1df5>
 29dc5dd:	mov    0x18(%rsp),%r9d
 29dc5e2:	xor    %r14d,%r14d
 29dc5e5:	lea    0x14(%r8,%r12,4),%rbx
 29dc5ea:	lea    0x14(%r11,%r12,4),%r12
 29dc5ef:	cmp    %r15,%r13
 29dc5f2:	jae    29dc600 <wasm[0]::function[1013]::helper::array_indexed_publish+0x1ce0>
 29dc5f8:	mov    %r9,%rdi
 29dc5fb:	jmp    29dc690 <wasm[0]::function[1013]::helper::array_indexed_publish+0x1d70>
 29dc600:	mov    %r9,%rdi
 29dc603:	mov    %r9d,0x20(%rsp)
 29dc608:	mov    %eax,(%rsp)
 29dc60b:	mov    0x70(%rsp),%rax
 29dc610:	mov    %eax,0x10(%rsp)
 29dc614:	mov    %edi,0x28(%rsp)
 29dc618:	mov    %esi,0x8(%rsp)
 29dc61c:	mov    %edx,0x18(%rsp)
 29dc620:	mov    0xd8(%rsp),%r9
 29dc628:	mov    (%r9),%rax
 29dc62b:	mov    0xa8(%rsp),%rcx
 29dc633:	cmp    %rcx,%rax
 29dc636:	jae    29df3e3 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4ac3>
 29dc63c:	sub    $0x4,%r12
 29dc640:	mov    (%r12),%eax
 29dc644:	sub    $0x4,%rbx
 29dc648:	mov    %eax,(%rbx)
 29dc64a:	mov    0x10(%rsp),%eax
 29dc64e:	mov    %rax,0x70(%rsp)
 29dc653:	mov    0x28(%rsp),%edi
 29dc657:	mov    0x8(%rsp),%esi
 29dc65b:	mov    0x18(%rsp),%edx
 29dc65f:	mov    0x20(%rsp),%r9d
 29dc664:	mov    (%rsp),%eax
 29dc667:	mov    0x78(%rsp),%r11
 29dc66c:	mov    %r11,%r8
 29dc66f:	sub    $0x1,%r8d
 29dc673:	mov    %r8,0x78(%rsp)
 29dc678:	cmp    %r15,%r12
 29dc67b:	jne    29dc603 <wasm[0]::function[1013]::helper::array_indexed_publish+0x1ce3>
 29dc681:	mov    0x70(%rsp),%rax
 29dc686:	mov    0x70(%rsp),%r12
 29dc68b:	jmp    29dc715 <wasm[0]::function[1013]::helper::array_indexed_publish+0x1df5>
 29dc690:	mov    %r9d,(%rsp)
 29dc694:	mov    %eax,0x20(%rsp)
 29dc698:	mov    0x70(%rsp),%rax
 29dc69d:	mov    %eax,0x18(%rsp)
 29dc6a1:	mov    %edi,0x8(%rsp)
 29dc6a5:	mov    %esi,0x28(%rsp)
 29dc6a9:	mov    %edx,0x10(%rsp)
 29dc6ad:	mov    0xd8(%rsp),%rax
 29dc6b5:	mov    (%rax),%rax
 29dc6b8:	mov    0xa8(%rsp),%rcx
 29dc6c0:	cmp    %rcx,%rax
 29dc6c3:	jae    29df417 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4af7>
 29dc6c9:	mov    (%r15),%eax
 29dc6cc:	mov    %eax,0x0(%r13)
 29dc6d0:	mov    0x18(%rsp),%esi
 29dc6d4:	mov    %rsi,0x70(%rsp)
 29dc6d9:	mov    0x8(%rsp),%edi
 29dc6dd:	mov    0x28(%rsp),%esi
 29dc6e1:	mov    0x10(%rsp),%edx
 29dc6e5:	mov    (%rsp),%r9d
 29dc6e9:	mov    0x20(%rsp),%eax
 29dc6ed:	add    $0x4,%r15
 29dc6f4:	add    $0x4,%r13
 29dc6fb:	add    $0x1,%r14d
 29dc702:	cmp    %r12,%r15
 29dc705:	jne    29dc690 <wasm[0]::function[1013]::helper::array_indexed_publish+0x1d70>
 29dc70b:	mov    0x70(%rsp),%rax
 29dc710:	mov    0x70(%rsp),%r12
 29dc715:	test   %eax,%r12d
 29dc718:	je     29dfbe1 <wasm[0]::function[1013]::helper::array_indexed_publish+0x52c1>
 29dc71e:	test   %edi,%edi
 29dc720:	je     29dfbe3 <wasm[0]::function[1013]::helper::array_indexed_publish+0x52c3>
 29dc726:	mov    0x70(%rsp),%rax
 29dc72b:	mov    0x70(%rsp),%r12
 29dc730:	test   %eax,%r12d
 29dc733:	je     29dfbe5 <wasm[0]::function[1013]::helper::array_indexed_publish+0x52c5>
 29dc739:	mov    0xd0(%rsp),%r15
 29dc741:	mov    0x28(%r15),%r8
 29dc745:	mov    %r12d,%r10d
 29dc748:	mov    %r10,%r9
 29dc74b:	add    0x20(%r15),%r9
 29dc74f:	xor    %r11,%r11
 29dc752:	cmp    %r8,%r10
 29dc755:	cmova  %r11,%r9
 29dc759:	mov    %edi,0x30(%r9)
 29dc75d:	mov    %esi,0x10(%rsp)
 29dc761:	mov    %edi,0x28(%rsp)
 29dc765:	mov    0x70(%rsp),%r12
 29dc76a:	mov    %r12d,0x8(%rsp)
 29dc76f:	mov    %edx,0x18(%rsp)
 29dc773:	mov    0x60(%rsp),%rdi
 29dc778:	mov    0x20(%rdi),%rsi
 29dc77c:	mov    (%rsi),%eax
 29dc77e:	mov    %eax,%ecx
 29dc780:	mov    $0x20,%edx
 29dc785:	lea    0x20(%rcx),%rdi
 29dc789:	mov    0x4(%rsi),%r8d
 29dc78d:	cmp    %r8,%rdi
 29dc790:	ja     29df44b <wasm[0]::function[1013]::helper::array_indexed_publish+0x4b2b>
 29dc796:	lea    0x20(%rax),%edi
 29dc799:	mov    %edi,(%rsi)
 29dc79b:	mov    0xd0(%rsp),%r15
 29dc7a3:	mov    0x20(%r15),%rdi
 29dc7a7:	lea    (%rdi,%rcx,1),%rsi
 29dc7ab:	movl   $0xb0000042,(%rdi,%rcx,1)
 29dc7b2:	mov    0x60(%rsp),%r8
 29dc7b7:	mov    0x28(%r8),%r8
 29dc7bb:	mov    0x120(%r8),%r8d
 29dc7c2:	mov    %r8d,0x4(%rdi,%rcx,1)
 29dc7c7:	mov    %edx,0x8(%rdi,%rcx,1)
 29dc7cb:	mov    0x90(%rsp),%rcx
 29dc7d3:	mov    0x90(%rsp),%rcx
 29dc7db:	mov    %rcx,0x10(%rsi)
 29dc7df:	mov    0x98(%rsp),%rdi
 29dc7e7:	mov    %edi,0x18(%rsi)
 29dc7ea:	mov    0x10(%rsp),%ecx
 29dc7ee:	mov    %ecx,0x1c(%rsi)
 29dc7f1:	mov    0x28(%rsp),%r11d
 29dc7f6:	test   %r11d,%r11d
 29dc7f9:	je     29dfbe7 <wasm[0]::function[1013]::helper::array_indexed_publish+0x52c7>
 29dc7ff:	test   %r11d,%r11d
 29dc802:	je     29dfbe9 <wasm[0]::function[1013]::helper::array_indexed_publish+0x52c9>
 29dc808:	mov    0xd0(%rsp),%r15
 29dc810:	mov    0x28(%r15),%rcx
 29dc814:	mov    0x20(%r15),%rdx
 29dc818:	mov    %r11d,%r8d
 29dc81b:	lea    0x10(%rdx,%r8,1),%rdi
 29dc820:	xor    %rsi,%rsi
 29dc823:	cmp    %rcx,%r8
 29dc826:	cmova  %rsi,%rdi
 29dc82a:	mov    (%rdi),%edi
 29dc82c:	mov    0x68(%rsp),%r8
 29dc831:	cmp    %edi,%r8d
 29dc834:	jae    29dfbeb <wasm[0]::function[1013]::helper::array_indexed_publish+0x52cb>
 29dc83a:	mov    %edi,%r8d
 29dc83d:	shl    $0x2,%r8
 29dc841:	shr    $0x20,%r8
 29dc845:	test   %r8,%r8
 29dc848:	jne    29dfbed <wasm[0]::function[1013]::helper::array_indexed_publish+0x52cd>
 29dc84e:	shl    $0x2,%edi
 29dc851:	add    $0x14,%edi
 29dc854:	jb     29dfbef <wasm[0]::function[1013]::helper::array_indexed_publish+0x52cf>
 29dc85a:	add    %edi,%r11d
 29dc85d:	jb     29dfbf1 <wasm[0]::function[1013]::helper::array_indexed_publish+0x52d1>
 29dc863:	mov    %r11d,%r8d
 29dc866:	add    %r8,%rdx
 29dc869:	cmp    %rcx,%r8
 29dc86c:	cmova  %rsi,%rdx
 29dc870:	mov    0x68(%rsp),%rcx
 29dc875:	shl    $0x2,%ecx
 29dc878:	lea    0x14(%rcx),%esi
 29dc87b:	sub    %esi,%edi
 29dc87d:	sub    %rdi,%rdx
 29dc880:	mov    (%rdx),%edx
 29dc882:	test   %edx,%edx
 29dc884:	jne    29dc8ce <wasm[0]::function[1013]::helper::array_indexed_publish+0x1fae>
 29dc88a:	mov    0x8(%rsp),%edx
 29dc88e:	test   %edx,%edx
 29dc890:	je     29dfbf3 <wasm[0]::function[1013]::helper::array_indexed_publish+0x52d3>
 29dc896:	test   %edx,%edx
 29dc898:	je     29dfbf5 <wasm[0]::function[1013]::helper::array_indexed_publish+0x52d5>
 29dc89e:	mov    0xd0(%rsp),%r15
 29dc8a6:	mov    0x28(%r15),%rdi
 29dc8aa:	mov    0x80(%rsp),%r14
 29dc8b2:	lea    0x1(%r14),%rsi
 29dc8b6:	mov    %edx,%r8d
 29dc8b9:	mov    %r8,%rdx
 29dc8bc:	add    0x20(%r15),%rdx
 29dc8c0:	xor    %r9,%r9
 29dc8c3:	cmp    %rdi,%r8
 29dc8c6:	cmova  %r9,%rdx
 29dc8ca:	mov    %rsi,0x18(%rdx)
 29dc8ce:	mov    0x28(%rsp),%edx
 29dc8d2:	test   %edx,%edx
 29dc8d4:	je     29dfbf7 <wasm[0]::function[1013]::helper::array_indexed_publish+0x52d7>
 29dc8da:	test   %eax,%eax
 29dc8dc:	je     29dfbf9 <wasm[0]::function[1013]::helper::array_indexed_publish+0x52d9>
 29dc8e2:	test   %edx,%edx
 29dc8e4:	je     29dfbfb <wasm[0]::function[1013]::helper::array_indexed_publish+0x52db>
 29dc8ea:	mov    0xd0(%rsp),%r15
 29dc8f2:	mov    0x28(%r15),%rsi
 29dc8f6:	mov    0x20(%r15),%rdi
 29dc8fa:	mov    %edx,%r10d
 29dc8fd:	lea    0x10(%rdi,%r10,1),%r9
 29dc902:	xor    %r8,%r8
 29dc905:	cmp    %rsi,%r10
 29dc908:	cmova  %r8,%r9
 29dc90c:	mov    (%r9),%r9d
 29dc90f:	mov    0x68(%rsp),%r10
 29dc914:	cmp    %r9d,%r10d
 29dc917:	jae    29dfbfd <wasm[0]::function[1013]::helper::array_indexed_publish+0x52dd>
 29dc91d:	mov    %r9d,%r10d
 29dc920:	shl    $0x2,%r10
 29dc924:	shr    $0x20,%r10
 29dc928:	test   %r10,%r10
 29dc92b:	jne    29dfbff <wasm[0]::function[1013]::helper::array_indexed_publish+0x52df>
 29dc931:	shl    $0x2,%r9d
 29dc935:	add    $0x14,%r9d
 29dc939:	jb     29dfc01 <wasm[0]::function[1013]::helper::array_indexed_publish+0x52e1>
 29dc93f:	add    %r9d,%edx
 29dc942:	jb     29dfc03 <wasm[0]::function[1013]::helper::array_indexed_publish+0x52e3>
 29dc948:	mov    %edx,%r10d
 29dc94b:	lea    (%rdi,%r10,1),%rdx
 29dc94f:	cmp    %rsi,%r10
 29dc952:	cmova  %r8,%rdx
 29dc956:	add    $0x14,%ecx
 29dc95c:	sub    %ecx,%r9d
 29dc95f:	sub    %r9,%rdx
 29dc962:	mov    %eax,(%rdx)
 29dc964:	mov    0x8(%rsp),%r12d
 29dc969:	mov    %r12,0x70(%rsp)
 29dc96e:	mov    0x18(%rsp),%edx
 29dc972:	mov    $0x1,%r10d
 29dc978:	mov    0x70(%rsp),%r12
 29dc97d:	mov    %r12d,0x18(%rsp)
 29dc982:	mov    %edx,0x8(%rsp)
 29dc986:	test   %r10d,%r10d
 29dc989:	mov    %r10,0xa0(%rsp)
 29dc991:	jne    29dd4ca <wasm[0]::function[1013]::helper::array_indexed_publish+0x2baa>
 29dc997:	mov    0x70(%rsp),%rax
 29dc99c:	mov    0x70(%rsp),%r12
 29dc9a1:	test   %eax,%r12d
 29dc9a4:	je     29dfc05 <wasm[0]::function[1013]::helper::array_indexed_publish+0x52e5>
 29dc9aa:	test   %eax,%r12d
 29dc9ad:	je     29dfc07 <wasm[0]::function[1013]::helper::array_indexed_publish+0x52e7>
 29dc9b3:	mov    0xd0(%rsp),%r15
 29dc9bb:	mov    0x28(%r15),%r11
 29dc9bf:	mov    %r12d,%eax
 29dc9c2:	mov    %rax,%r8
 29dc9c5:	add    0x20(%r15),%r8
 29dc9c9:	xor    %rcx,%rcx
 29dc9cc:	cmp    %r11,%rax
 29dc9cf:	cmova  %rcx,%r8
 29dc9d3:	mov    0x24(%r8),%eax
 29dc9d7:	cmp    $0x3,%eax
 29dc9da:	je     29dd015 <wasm[0]::function[1013]::helper::array_indexed_publish+0x26f5>
 29dc9e0:	mov    0x18(%rsp),%r12d
 29dc9e5:	mov    %r12,%r8
 29dc9e8:	mov    %r12,0x70(%rsp)
 29dc9ed:	test   %r8d,%r12d
 29dc9f0:	je     29dfc09 <wasm[0]::function[1013]::helper::array_indexed_publish+0x52e9>
 29dc9f6:	mov    0x70(%rsp),%rax
 29dc9fb:	test   %eax,%r12d
 29dc9fe:	je     29dfc0b <wasm[0]::function[1013]::helper::array_indexed_publish+0x52eb>
 29dca04:	mov    0xd0(%rsp),%r15
 29dca0c:	mov    0x28(%r15),%rax
 29dca10:	mov    %r12d,%esi
 29dca13:	mov    %rsi,%rdx
 29dca16:	add    0x20(%r15),%rdx
 29dca1a:	xor    %rdi,%rdi
 29dca1d:	cmp    %rax,%rsi
 29dca20:	cmova  %rdi,%rdx
 29dca24:	mov    0x24(%rdx),%eax
 29dca27:	mov    0x8(%rsp),%edx
 29dca2b:	cmp    $0x2,%eax
 29dca2e:	jne    29dd4ca <wasm[0]::function[1013]::helper::array_indexed_publish+0x2baa>
 29dca34:	mov    0x18(%rsp),%edx
 29dca38:	test   %edx,%edx
 29dca3a:	je     29dfc0d <wasm[0]::function[1013]::helper::array_indexed_publish+0x52ed>
 29dca40:	test   %edx,%edx
 29dca42:	je     29dfc0f <wasm[0]::function[1013]::helper::array_indexed_publish+0x52ef>
 29dca48:	mov    0xd0(%rsp),%r15
 29dca50:	mov    0x28(%r15),%rax
 29dca54:	mov    0x20(%r15),%rcx
 29dca58:	mov    %edx,%esi
 29dca5a:	lea    (%rcx,%rsi,1),%rdi
 29dca5e:	xor    %rdx,%rdx
 29dca61:	cmp    %rax,%rsi
 29dca64:	cmova  %rdx,%rdi
 29dca68:	mov    0x28(%rdi),%esi
 29dca6b:	mov    %esi,0x28(%rsp)
 29dca6f:	mov    0x2c(%rdi),%edi
 29dca72:	mov    %edi,0x10(%rsp)
 29dca76:	test   %esi,%esi
 29dca78:	je     29dfc11 <wasm[0]::function[1013]::helper::array_indexed_publish+0x52f1>
 29dca7e:	test   %esi,%esi
 29dca80:	je     29dfc13 <wasm[0]::function[1013]::helper::array_indexed_publish+0x52f3>
 29dca86:	mov    %esi,%esi
 29dca88:	lea    0x10(%rcx,%rsi,1),%rcx
 29dca8d:	cmp    %rax,%rsi
 29dca90:	cmova  %rdx,%rcx
 29dca94:	mov    (%rcx),%eax
 29dca96:	mov    %eax,%r12d
 29dca99:	mov    %r12,%rbx
 29dca9c:	shl    $0x2,%rbx
 29dcaa0:	mov    $0x20,%ecx
 29dcaa5:	mov    %rcx,0xb8(%rsp)
 29dcaad:	mov    %rbx,%rcx
 29dcab0:	shr    $0x20,%rcx
 29dcab4:	test   %rcx,%rcx
 29dcab7:	jne    29dfc15 <wasm[0]::function[1013]::helper::array_indexed_publish+0x52f5>
 29dcabd:	mov    %rax,%rcx
 29dcac0:	shl    $0x2,%ecx
 29dcac3:	mov    %rax,0x78(%rsp)
 29dcac8:	add    $0x14,%ecx
 29dcacb:	jb     29dfc17 <wasm[0]::function[1013]::helper::array_indexed_publish+0x52f7>
 29dcad1:	mov    0x60(%rsp),%rdi
 29dcad6:	mov    0x20(%rdi),%r15
 29dcada:	mov    (%r15),%eax
 29dcadd:	mov    %eax,%edx
 29dcadf:	mov    %ecx,%esi
 29dcae1:	add    $0xf,%rsi
 29dcae8:	mov    %rsi,%rdi
 29dcaeb:	and    $0xfffffffffffffff0,%rdi
 29dcaef:	add    %rdx,%rdi
 29dcaf2:	mov    0x4(%r15),%r8d
 29dcaf6:	cmp    %r8,%rdi
 29dcaf9:	ja     29df48a <wasm[0]::function[1013]::helper::array_indexed_publish+0x4b6a>
 29dcaff:	add    $0xf,%ecx
 29dcb05:	and    $0xfffffff0,%ecx
 29dcb08:	add    %eax,%ecx
 29dcb0a:	mov    %ecx,(%r15)
 29dcb0d:	mov    0xd0(%rsp),%rcx
 29dcb15:	mov    0x20(%rcx),%rcx
 29dcb19:	lea    (%rcx,%rdx,1),%r9
 29dcb1d:	movl   $0xa800000e,(%rcx,%rdx,1)
 29dcb24:	mov    0x60(%rsp),%rdi
 29dcb29:	mov    0x28(%rdi),%rdi
 29dcb2d:	mov    0x194(%rdi),%edi
 29dcb33:	mov    %edi,0x4(%rcx,%rdx,1)
 29dcb37:	and    $0xfffffffffffffff0,%rsi
 29dcb3b:	mov    %esi,0x8(%rcx,%rdx,1)
 29dcb3f:	mov    %eax,(%rsp)
 29dcb42:	mov    0x78(%rsp),%r13
 29dcb47:	mov    %r13d,0x10(%r9)
 29dcb4b:	test   %eax,%eax
 29dcb4d:	je     29dfc19 <wasm[0]::function[1013]::helper::array_indexed_publish+0x52f9>
 29dcb53:	mov    0xd0(%rsp),%rcx
 29dcb5b:	mov    0x28(%rcx),%rcx
 29dcb5f:	mov    0xd0(%rsp),%rdx
 29dcb67:	mov    0x20(%rdx),%rsi
 29dcb6b:	mov    %eax,%eax
 29dcb6d:	lea    (%rsi,%rax,1),%rdx
 29dcb71:	lea    0x10(%rsi,%rax,1),%rdi
 29dcb76:	xor    %r8,%r8
 29dcb79:	cmp    %rcx,%rax
 29dcb7c:	cmova  %r8,%rdi
 29dcb80:	mov    (%rdi),%edi
 29dcb82:	cmp    %rdi,%r12
 29dcb85:	ja     29dfc1b <wasm[0]::function[1013]::helper::array_indexed_publish+0x52fb>
 29dcb8b:	lea    0x14(%rsi,%rax,1),%r13
 29dcb90:	mov    %r13,%rax
 29dcb93:	add    %rbx,%rax
 29dcb96:	jb     29dfc1d <wasm[0]::function[1013]::helper::array_indexed_publish+0x52fd>
 29dcb9c:	add    %rsi,%rcx
 29dcb9f:	cmp    %rcx,%rax
 29dcba2:	ja     29dfc1f <wasm[0]::function[1013]::helper::array_indexed_publish+0x52ff>
 29dcba8:	mov    0x10(%rsp),%edi
 29dcbac:	mov    0x28(%rsp),%esi
 29dcbb0:	mov    0x18(%rsp),%eax
 29dcbb4:	mov    0x8(%rsp),%ecx
 29dcbb8:	lea    0x14(%rdx,%r12,4),%rbx
 29dcbbd:	test   %r12,%r12
 29dcbc0:	je     29dcc1b <wasm[0]::function[1013]::helper::array_indexed_publish+0x22fb>
 29dcbc6:	mov    %edi,0x30(%rsp)
 29dcbca:	mov    %esi,0x20(%rsp)
 29dcbce:	mov    %eax,0x28(%rsp)
 29dcbd2:	mov    %ecx,0x10(%rsp)
 29dcbd6:	mov    0xd8(%rsp),%r12
 29dcbde:	mov    (%r12),%rax
 29dcbe2:	mov    0xa8(%rsp),%rcx
 29dcbea:	cmp    %rcx,%rax
 29dcbed:	jae    29df4bd <wasm[0]::function[1013]::helper::array_indexed_publish+0x4b9d>
 29dcbf3:	movl   $0x0,0x0(%r13)
 29dcbfb:	mov    0x30(%rsp),%edi
 29dcbff:	mov    0x20(%rsp),%esi
 29dcc03:	mov    0x28(%rsp),%eax
 29dcc07:	mov    0x10(%rsp),%ecx
 29dcc0b:	add    $0x4,%r13
 29dcc12:	cmp    %rbx,%r13
 29dcc15:	jne    29dcbc6 <wasm[0]::function[1013]::helper::array_indexed_publish+0x22a6>
 29dcc1b:	mov    %edi,0x20(%rsp)
 29dcc1f:	mov    %esi,0x30(%rsp)
 29dcc23:	xor    %r12d,%r12d
 29dcc26:	mov    $0xb0000042,%r14d
 29dcc2c:	mov    0x60(%rsp),%rdi
 29dcc31:	mov    %r14,0xb0(%rsp)
 29dcc39:	mov    0x28(%rdi),%rdx
 29dcc3d:	mov    0x120(%rdx),%r13d
 29dcc44:	mov    %r13,0x98(%rsp)
 29dcc4c:	mov    $0x20,%r14d
 29dcc52:	mov    %r14,0x90(%rsp)
 29dcc5a:	mov    $0x10,%r13d
 29dcc60:	mov    %r13,0x88(%rsp)
 29dcc68:	mov    0x13c(%rdx),%edx
 29dcc6e:	mov    %rdx,%r13
 29dcc71:	mov    %eax,0x10(%rsp)
 29dcc75:	mov    %ecx,0x28(%rsp)
 29dcc79:	mov    0xd8(%rsp),%rsi
 29dcc81:	mov    (%rsi),%rax
 29dcc84:	mov    0xa8(%rsp),%rcx
 29dcc8c:	cmp    %rcx,%rax
 29dcc8f:	jae    29df4f1 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4bd1>
 29dcc95:	mov    0x78(%rsp),%rcx
 29dcc9a:	jmp    29dcca4 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2384>
 29dcc9f:	mov    0x78(%rsp),%rcx
 29dcca4:	cmp    %ecx,%r12d
 29dcca7:	jae    29dcf85 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2665>
 29dccad:	mov    0x20(%rsp),%r11d
 29dccb2:	test   %r11d,%r11d
 29dccb5:	je     29dfc21 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5301>
 29dccbb:	test   %r11d,%r11d
 29dccbe:	je     29dfc23 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5303>
 29dccc4:	mov    0xd0(%rsp),%rax
 29dcccc:	mov    0x28(%rax),%rax
 29dccd0:	mov    0xd0(%rsp),%rcx
 29dccd8:	mov    0x20(%rcx),%rcx
 29dccdc:	mov    %r11d,%edi
 29dccdf:	lea    0x10(%rcx,%rdi,1),%rsi
 29dcce4:	xor    %rdx,%rdx
 29dcce7:	cmp    %rax,%rdi
 29dccea:	cmova  %rdx,%rsi
 29dccee:	mov    (%rsi),%esi
 29dccf0:	mov    %r12,%rdi
 29dccf3:	shr    $0x6,%edi
 29dccf6:	cmp    %esi,%edi
 29dccf8:	jae    29dfc25 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5305>
 29dccfe:	mov    %esi,%r8d
 29dcd01:	shl    $0x3,%r8
 29dcd05:	shr    $0x20,%r8
 29dcd09:	test   %r8,%r8
 29dcd0c:	jne    29dfc27 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5307>
 29dcd12:	shl    $0x3,%esi
 29dcd15:	add    $0x18,%esi
 29dcd18:	jb     29dfc29 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5309>
 29dcd1e:	add    %esi,%r11d
 29dcd21:	jb     29dfc2b <wasm[0]::function[1013]::helper::array_indexed_publish+0x530b>
 29dcd27:	mov    %r11d,%r8d
 29dcd2a:	add    %r8,%rcx
 29dcd2d:	cmp    %rax,%r8
 29dcd30:	cmova  %rdx,%rcx
 29dcd34:	shl    $0x3,%edi
 29dcd37:	lea    0x18(%rdi),%eax
 29dcd3a:	sub    %eax,%esi
 29dcd3c:	sub    %rsi,%rcx
 29dcd3f:	mov    (%rcx),%rax
 29dcd42:	bt     %r12,%rax
 29dcd46:	jb     29dcd59 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2439>
 29dcd4c:	mov    0xb8(%rsp),%r14
 29dcd54:	jmp    29dcf69 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2649>
 29dcd59:	mov    0x30(%rsp),%eax
 29dcd5d:	test   %eax,%eax
 29dcd5f:	je     29dfc2d <wasm[0]::function[1013]::helper::array_indexed_publish+0x530d>
 29dcd65:	test   %eax,%eax
 29dcd67:	je     29dfc2f <wasm[0]::function[1013]::helper::array_indexed_publish+0x530f>
 29dcd6d:	mov    0xd0(%rsp),%rcx
 29dcd75:	mov    0x28(%rcx),%rcx
 29dcd79:	mov    0xd0(%rsp),%rdx
 29dcd81:	mov    0x20(%rdx),%rdx
 29dcd85:	mov    %eax,%r8d
 29dcd88:	lea    0x10(%rdx,%r8,1),%rdi
 29dcd8d:	xor    %rsi,%rsi
 29dcd90:	cmp    %rcx,%r8
 29dcd93:	cmova  %rsi,%rdi
 29dcd97:	mov    (%rdi),%edi
 29dcd99:	cmp    %edi,%r12d
 29dcd9c:	jae    29dfc31 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5311>
 29dcda2:	mov    %edi,%r8d
 29dcda5:	shl    $0x3,%r8
 29dcda9:	shr    $0x20,%r8
 29dcdad:	test   %r8,%r8
 29dcdb0:	jne    29dfc33 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5313>
 29dcdb6:	shl    $0x3,%edi
 29dcdb9:	add    $0x18,%edi
 29dcdbc:	jb     29dfc35 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5315>
 29dcdc2:	add    %edi,%eax
 29dcdc4:	jb     29dfc37 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5317>
 29dcdca:	mov    %eax,%r8d
 29dcdcd:	lea    (%rdx,%r8,1),%rax
 29dcdd1:	cmp    %rcx,%r8
 29dcdd4:	cmova  %rsi,%rax
 29dcdd8:	mov    %r12,%rcx
 29dcddb:	shl    $0x3,%ecx
 29dcdde:	add    $0x18,%ecx
 29dcde4:	sub    %ecx,%edi
 29dcde6:	sub    %rdi,%rax
 29dcde9:	mov    (%rax),%rbx
 29dcdec:	movl   $0x0,0x38(%rsp)
 29dcdf4:	mov    (%r15),%eax
 29dcdf7:	mov    %eax,%edx
 29dcdf9:	lea    0x20(%rdx),%rcx
 29dcdfd:	mov    0x4(%r15),%esi
 29dce01:	cmp    %rsi,%rcx
 29dce04:	ja     29df52a <wasm[0]::function[1013]::helper::array_indexed_publish+0x4c0a>
 29dce0a:	lea    0x20(%rax),%ecx
 29dce0d:	mov    %ecx,(%r15)
 29dce10:	mov    0xd0(%rsp),%r11
 29dce18:	mov    0x20(%r11),%rsi
 29dce1c:	lea    (%rsi,%rdx,1),%rcx
 29dce20:	movl   $0xb0000042,(%rsi,%rdx,1)
 29dce27:	mov    0x98(%rsp),%rdi
 29dce2f:	mov    %edi,0x4(%rsi,%rdx,1)
 29dce33:	mov    0xb8(%rsp),%r14
 29dce3b:	mov    %r14d,0x8(%rsi,%rdx,1)
 29dce40:	mov    %eax,0x40(%rsp)
 29dce44:	mov    %rbx,0x10(%rcx)
 29dce48:	movl   $0x3,0x18(%rcx)
 29dce4f:	mov    0x38(%rsp),%edx
 29dce53:	mov    %edx,0x1c(%rcx)
 29dce56:	mov    0x60(%rsp),%rdi
 29dce5b:	mov    0xa20(%rdi),%esi
 29dce61:	mov    %esi,0x38(%rsp)
 29dce65:	test   %eax,%eax
 29dce67:	je     29dfc39 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5319>
 29dce6d:	test   %esi,%esi
 29dce6f:	je     29dfc3b <wasm[0]::function[1013]::helper::array_indexed_publish+0x531b>
 29dce75:	mov    (%r15),%eax
 29dce78:	mov    %eax,%r8d
 29dce7b:	lea    0x20(%r8),%r9
 29dce7f:	mov    0x4(%r15),%r10d
 29dce83:	cmp    %r10,%r9
 29dce86:	ja     29df56f <wasm[0]::function[1013]::helper::array_indexed_publish+0x4c4f>
 29dce8c:	lea    0x20(%rax),%r11d
 29dce90:	mov    %r11d,(%r15)
 29dce93:	mov    0xd0(%rsp),%rcx
 29dce9b:	mov    0x20(%rcx),%rdx
 29dce9f:	lea    (%rdx,%r8,1),%rcx
 29dcea3:	movl   $0xb0000072,(%rdx,%r8,1)
 29dceab:	mov    %r13d,0x4(%rdx,%r8,1)
 29dceb0:	mov    %r14d,0x8(%rdx,%r8,1)
 29dceb5:	movl   $0xe,0x10(%rcx)
 29dcebc:	mov    0x40(%rsp),%edx
 29dcec0:	mov    %edx,0x14(%rcx)
 29dcec3:	mov    0x38(%rsp),%edx
 29dcec7:	mov    %edx,0x18(%rcx)
 29dceca:	mov    %edx,0x1c(%rcx)
 29dcecd:	mov    (%rsp),%esi
 29dced0:	test   %esi,%esi
 29dced2:	je     29dfc3d <wasm[0]::function[1013]::helper::array_indexed_publish+0x531d>
 29dced8:	test   %eax,%eax
 29dceda:	je     29dfc3f <wasm[0]::function[1013]::helper::array_indexed_publish+0x531f>
 29dcee0:	test   %esi,%esi
 29dcee2:	je     29dfc41 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5321>
 29dcee8:	mov    0xd0(%rsp),%rcx
 29dcef0:	mov    0x28(%rcx),%rcx
 29dcef4:	mov    0xd0(%rsp),%rdx
 29dcefc:	mov    0x20(%rdx),%rdx
 29dcf00:	mov    %esi,%r9d
 29dcf03:	lea    0x10(%rdx,%r9,1),%r8
 29dcf08:	xor    %rdi,%rdi
 29dcf0b:	cmp    %rcx,%r9
 29dcf0e:	cmova  %rdi,%r8
 29dcf12:	mov    (%r8),%r8d
 29dcf15:	cmp    %r8d,%r12d
 29dcf18:	jae    29dfc43 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5323>
 29dcf1e:	mov    %r8d,%r9d
 29dcf21:	shl    $0x2,%r9
 29dcf25:	shr    $0x20,%r9
 29dcf29:	test   %r9,%r9
 29dcf2c:	jne    29dfc45 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5325>
 29dcf32:	shl    $0x2,%r8d
 29dcf36:	add    $0x14,%r8d
 29dcf3a:	jb     29dfc47 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5327>
 29dcf40:	add    %r8d,%esi
 29dcf43:	jb     29dfc49 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5329>
 29dcf49:	mov    %esi,%esi
 29dcf4b:	add    %rsi,%rdx
 29dcf4e:	cmp    %rcx,%rsi
 29dcf51:	cmova  %rdi,%rdx
 29dcf55:	mov    %r12,%rcx
 29dcf58:	shl    $0x2,%ecx
 29dcf5b:	add    $0x14,%ecx
 29dcf61:	sub    %ecx,%r8d
 29dcf64:	sub    %r8,%rdx
 29dcf67:	mov    %eax,(%rdx)
 29dcf69:	mov    0x10(%rsp),%eax
 29dcf6d:	mov    0x28(%rsp),%ecx
 29dcf71:	add    $0x1,%r12d
 29dcf78:	mov    %r14,0xb8(%rsp)
 29dcf80:	jmp    29dcc71 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2351>
 29dcf85:	mov    0x10(%rsp),%r12d
 29dcf8a:	mov    %r12,%rax
 29dcf8d:	mov    %r12,0x70(%rsp)
 29dcf92:	test   %eax,%r12d
 29dcf95:	je     29dfc4b <wasm[0]::function[1013]::helper::array_indexed_publish+0x532b>
 29dcf9b:	mov    (%rsp),%edx
 29dcf9e:	test   %edx,%edx
 29dcfa0:	je     29dfc4d <wasm[0]::function[1013]::helper::array_indexed_publish+0x532d>
 29dcfa6:	mov    0x70(%rsp),%rax
 29dcfab:	test   %eax,%r12d
 29dcfae:	je     29dfc4f <wasm[0]::function[1013]::helper::array_indexed_publish+0x532f>
 29dcfb4:	mov    0xd0(%rsp),%r15
 29dcfbc:	mov    0x28(%r15),%rsi
 29dcfc0:	mov    0x20(%r15),%rax
 29dcfc4:	mov    %r12d,%edi
 29dcfc7:	add    %rdi,%rax
 29dcfca:	xor    %r8,%r8
 29dcfcd:	cmp    %rsi,%rdi
 29dcfd0:	cmova  %r8,%rax
 29dcfd4:	mov    %edx,0x20(%rax)
 29dcfd7:	mov    0x60(%rsp),%rdi
 29dcfdc:	mov    0xa00(%rdi),%esi
 29dcfe2:	mov    0xa10(%rdi),%edx
 29dcfe8:	test   %esi,%esi
 29dcfea:	je     29dfc51 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5331>
 29dcff0:	mov    %esi,0x28(%rax)
 29dcff3:	test   %edx,%edx
 29dcff5:	je     29dfc53 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5333>
 29dcffb:	mov    %edx,0x2c(%rax)
 29dcffe:	movl   $0x0,0x30(%rax)
 29dd005:	movl   $0x0,0x24(%rax)
 29dd00c:	mov    0x28(%rsp),%edx
 29dd010:	jmp    29dd4ca <wasm[0]::function[1013]::helper::array_indexed_publish+0x2baa>
 29dd015:	mov    0x18(%rsp),%edx
 29dd019:	test   %edx,%edx
 29dd01b:	je     29dfc55 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5335>
 29dd021:	test   %edx,%edx
 29dd023:	je     29dfc57 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5337>
 29dd029:	mov    0xd0(%rsp),%r15
 29dd031:	mov    0x28(%r15),%rax
 29dd035:	mov    0x20(%r15),%rcx
 29dd039:	mov    %edx,%edi
 29dd03b:	lea    (%rcx,%rdi,1),%rsi
 29dd03f:	xor    %rdx,%rdx
 29dd042:	cmp    %rax,%rdi
 29dd045:	cmova  %rdx,%rsi
 29dd049:	mov    0x30(%rsi),%esi
 29dd04c:	mov    %esi,0x10(%rsp)
 29dd050:	test   %esi,%esi
 29dd052:	je     29dfc59 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5339>
 29dd058:	test   %esi,%esi
 29dd05a:	je     29dfc5b <wasm[0]::function[1013]::helper::array_indexed_publish+0x533b>
 29dd060:	mov    %esi,%esi
 29dd062:	lea    0x10(%rcx,%rsi,1),%rcx
 29dd067:	cmp    %rax,%rsi
 29dd06a:	cmova  %rdx,%rcx
 29dd06e:	mov    (%rcx),%esi
 29dd070:	mov    %esi,%r12d
 29dd073:	mov    %r12,%r13
 29dd076:	shl    $0x2,%r13
 29dd07a:	mov    $0x20,%edi
 29dd07f:	mov    %rdi,0x80(%rsp)
 29dd087:	mov    %r13,%rdi
 29dd08a:	shr    $0x20,%rdi
 29dd08e:	test   %rdi,%rdi
 29dd091:	jne    29dfc5d <wasm[0]::function[1013]::helper::array_indexed_publish+0x533d>
 29dd097:	mov    %rsi,%rcx
 29dd09a:	shl    $0x2,%ecx
 29dd09d:	mov    %rsi,0x88(%rsp)
 29dd0a5:	add    $0x14,%ecx
 29dd0a8:	jb     29dfc5f <wasm[0]::function[1013]::helper::array_indexed_publish+0x533f>
 29dd0ae:	mov    0x60(%rsp),%rdi
 29dd0b3:	mov    0x20(%rdi),%r15
 29dd0b7:	mov    (%r15),%eax
 29dd0ba:	mov    %eax,%esi
 29dd0bc:	mov    %ecx,%edi
 29dd0be:	lea    0xf(%rdi),%rdx
 29dd0c2:	mov    %rdx,%rdi
 29dd0c5:	and    $0xfffffffffffffff0,%rdi
 29dd0c9:	add    %rsi,%rdi
 29dd0cc:	mov    0x4(%r15),%r8d
 29dd0d0:	cmp    %r8,%rdi
 29dd0d3:	ja     29df5a4 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4c84>
 29dd0d9:	lea    0xf(%rcx),%r8d
 29dd0dd:	and    $0xfffffff0,%r8d
 29dd0e1:	lea    (%rax,%r8,1),%r9d
 29dd0e5:	mov    %r9d,(%r15)
 29dd0e8:	mov    0xd0(%rsp),%rcx
 29dd0f0:	mov    0x20(%rcx),%r10
 29dd0f4:	lea    (%r10,%rsi,1),%rcx
 29dd0f8:	movl   $0xa800000e,(%r10,%rsi,1)
 29dd100:	mov    0x60(%rsp),%rdi
 29dd105:	mov    0x28(%rdi),%r11
 29dd109:	mov    0x194(%r11),%r11d
 29dd110:	mov    %r11d,0x4(%r10,%rsi,1)
 29dd115:	and    $0xfffffffffffffff0,%rdx
 29dd119:	mov    %edx,0x8(%r10,%rsi,1)
 29dd11e:	mov    %eax,0x28(%rsp)
 29dd122:	mov    0x88(%rsp),%rdx
 29dd12a:	mov    %edx,0x10(%rcx)
 29dd12d:	test   %eax,%eax
 29dd12f:	je     29dfc61 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5341>
 29dd135:	mov    0xd0(%rsp),%rcx
 29dd13d:	mov    0x28(%rcx),%rcx
 29dd141:	mov    0xd0(%rsp),%rdx
 29dd149:	mov    0x20(%rdx),%rsi
 29dd14d:	mov    %eax,%eax
 29dd14f:	lea    (%rsi,%rax,1),%rdx
 29dd153:	lea    0x10(%rsi,%rax,1),%rdi
 29dd158:	xor    %r8,%r8
 29dd15b:	cmp    %rcx,%rax
 29dd15e:	cmova  %r8,%rdi
 29dd162:	mov    (%rdi),%edi
 29dd164:	cmp    %rdi,%r12
 29dd167:	ja     29dfc63 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5343>
 29dd16d:	lea    0x14(%rsi,%rax,1),%rbx
 29dd172:	mov    %rbx,%rax
 29dd175:	add    %r13,%rax
 29dd178:	jb     29dfc65 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5345>
 29dd17e:	add    %rsi,%rcx
 29dd181:	cmp    %rcx,%rax
 29dd184:	ja     29dfc67 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5347>
 29dd18a:	mov    0x10(%rsp),%esi
 29dd18e:	mov    0x18(%rsp),%eax
 29dd192:	mov    0x8(%rsp),%ecx
 29dd196:	lea    0x14(%rdx,%r12,4),%r13
 29dd19b:	test   %r12,%r12
 29dd19e:	je     29dd1ef <wasm[0]::function[1013]::helper::array_indexed_publish+0x28cf>
 29dd1a4:	mov    %esi,0x8(%rsp)
 29dd1a8:	mov    %eax,0x18(%rsp)
 29dd1ac:	mov    %ecx,0x10(%rsp)
 29dd1b0:	mov    0xd8(%rsp),%r12
 29dd1b8:	mov    (%r12),%rax
 29dd1bc:	mov    0xa8(%rsp),%rcx
 29dd1c4:	cmp    %rcx,%rax
 29dd1c7:	jae    29df5d7 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4cb7>
 29dd1cd:	movl   $0x0,(%rbx)
 29dd1d3:	mov    0x8(%rsp),%esi
 29dd1d7:	mov    0x18(%rsp),%eax
 29dd1db:	mov    0x10(%rsp),%ecx
 29dd1df:	add    $0x4,%rbx
 29dd1e6:	cmp    %r13,%rbx
 29dd1e9:	jne    29dd1a4 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2884>
 29dd1ef:	mov    %esi,0x8(%rsp)
 29dd1f3:	mov    0x60(%rsp),%rdi
 29dd1f8:	mov    0xa20(%rdi),%edx
 29dd1fe:	mov    %edx,0x18(%rsp)
 29dd202:	xor    %r12d,%r12d
 29dd205:	mov    $0xb0000072,%r13d
 29dd20b:	mov    %r13,%rbx
 29dd20e:	mov    0x28(%rdi),%rdx
 29dd212:	mov    0x13c(%rdx),%r14d
 29dd219:	mov    $0x20,%r13d
 29dd21f:	mov    %r13,0x78(%rsp)
 29dd224:	mov    $0x10,%r13d
 29dd22a:	mov    %r13,0xb8(%rsp)
 29dd232:	mov    %eax,(%rsp)
 29dd235:	mov    %ecx,0x10(%rsp)
 29dd239:	mov    0xd8(%rsp),%rax
 29dd241:	mov    (%rax),%rax
 29dd244:	mov    0xa8(%rsp),%rcx
 29dd24c:	cmp    %rcx,%rax
 29dd24f:	jae    29df60b <wasm[0]::function[1013]::helper::array_indexed_publish+0x4ceb>
 29dd255:	mov    0x88(%rsp),%rcx
 29dd25d:	jmp    29dd26a <wasm[0]::function[1013]::helper::array_indexed_publish+0x294a>
 29dd262:	mov    0x88(%rsp),%rcx
 29dd26a:	cmp    %ecx,%r12d
 29dd26d:	jae    29dd43f <wasm[0]::function[1013]::helper::array_indexed_publish+0x2b1f>
 29dd273:	mov    0x8(%rsp),%eax
 29dd277:	test   %eax,%eax
 29dd279:	je     29dfc69 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5349>
 29dd27f:	test   %eax,%eax
 29dd281:	je     29dfc6b <wasm[0]::function[1013]::helper::array_indexed_publish+0x534b>
 29dd287:	mov    0xd0(%rsp),%rcx
 29dd28f:	mov    0x28(%rcx),%rcx
 29dd293:	mov    0xd0(%rsp),%rdx
 29dd29b:	mov    0x20(%rdx),%rdx
 29dd29f:	mov    %eax,%r8d
 29dd2a2:	lea    0x10(%rdx,%r8,1),%rdi
 29dd2a7:	xor    %rsi,%rsi
 29dd2aa:	cmp    %rcx,%r8
 29dd2ad:	cmova  %rsi,%rdi
 29dd2b1:	mov    (%rdi),%edi
 29dd2b3:	cmp    %edi,%r12d
 29dd2b6:	jae    29dfc6d <wasm[0]::function[1013]::helper::array_indexed_publish+0x534d>
 29dd2bc:	mov    %edi,%r8d
 29dd2bf:	shl    $0x2,%r8
 29dd2c3:	shr    $0x20,%r8
 29dd2c7:	test   %r8,%r8
 29dd2ca:	jne    29dfc6f <wasm[0]::function[1013]::helper::array_indexed_publish+0x534f>
 29dd2d0:	shl    $0x2,%edi
 29dd2d3:	add    $0x14,%edi
 29dd2d6:	jb     29dfc71 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5351>
 29dd2dc:	add    %edi,%eax
 29dd2de:	jb     29dfc73 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5353>
 29dd2e4:	mov    %eax,%r8d
 29dd2e7:	lea    (%rdx,%r8,1),%rax
 29dd2eb:	cmp    %rcx,%r8
 29dd2ee:	cmova  %rsi,%rax
 29dd2f2:	mov    %r12,%r13
 29dd2f5:	shl    $0x2,%r13d
 29dd2f9:	lea    0x14(%r13),%esi
 29dd2fd:	sub    %esi,%edi
 29dd2ff:	sub    %rdi,%rax
 29dd302:	mov    (%rax),%esi
 29dd304:	mov    %esi,0x20(%rsp)
 29dd308:	test   %esi,%esi
 29dd30a:	jne    29dd31d <wasm[0]::function[1013]::helper::array_indexed_publish+0x29fd>
 29dd310:	mov    0x80(%rsp),%rsi
 29dd318:	jmp    29dd424 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2b04>
 29dd31d:	test   %esi,%esi
 29dd31f:	je     29dfc75 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5355>
 29dd325:	mov    0x18(%rsp),%eax
 29dd329:	test   %eax,%eax
 29dd32b:	je     29dfc77 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5357>
 29dd331:	mov    (%r15),%eax
 29dd334:	mov    %eax,%edx
 29dd336:	lea    0x20(%rdx),%rcx
 29dd33a:	mov    0x4(%r15),%esi
 29dd33e:	cmp    %rsi,%rcx
 29dd341:	ja     29df647 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4d27>
 29dd347:	lea    0x20(%rax),%ecx
 29dd34a:	mov    %ecx,(%r15)
 29dd34d:	mov    0xd0(%rsp),%rcx
 29dd355:	mov    0x20(%rcx),%rdi
 29dd359:	lea    (%rdi,%rdx,1),%rcx
 29dd35d:	movl   $0xb0000072,(%rdi,%rdx,1)
 29dd364:	mov    %r14d,0x4(%rdi,%rdx,1)
 29dd369:	mov    0x80(%rsp),%rsi
 29dd371:	mov    %esi,0x8(%rdi,%rdx,1)
 29dd375:	movl   $0xe,0x10(%rcx)
 29dd37c:	mov    0x20(%rsp),%edx
 29dd380:	mov    %edx,0x14(%rcx)
 29dd383:	mov    0x18(%rsp),%edx
 29dd387:	mov    %edx,0x18(%rcx)
 29dd38a:	mov    %edx,0x1c(%rcx)
 29dd38d:	mov    0x28(%rsp),%ecx
 29dd391:	test   %ecx,%ecx
 29dd393:	je     29dfc79 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5359>
 29dd399:	test   %eax,%eax
 29dd39b:	je     29dfc7b <wasm[0]::function[1013]::helper::array_indexed_publish+0x535b>
 29dd3a1:	test   %ecx,%ecx
 29dd3a3:	je     29dfc7d <wasm[0]::function[1013]::helper::array_indexed_publish+0x535d>
 29dd3a9:	mov    0xd0(%rsp),%rdx
 29dd3b1:	mov    0x28(%rdx),%rdx
 29dd3b5:	mov    0xd0(%rsp),%rdi
 29dd3bd:	mov    0x20(%rdi),%rdi
 29dd3c1:	mov    %ecx,%r10d
 29dd3c4:	lea    0x10(%rdi,%r10,1),%r9
 29dd3c9:	xor    %r8,%r8
 29dd3cc:	cmp    %rdx,%r10
 29dd3cf:	cmova  %r8,%r9
 29dd3d3:	mov    (%r9),%r9d
 29dd3d6:	cmp    %r9d,%r12d
 29dd3d9:	jae    29dfc7f <wasm[0]::function[1013]::helper::array_indexed_publish+0x535f>
 29dd3df:	mov    %r9d,%r10d
 29dd3e2:	shl    $0x2,%r10
 29dd3e6:	shr    $0x20,%r10
 29dd3ea:	test   %r10,%r10
 29dd3ed:	jne    29dfc81 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5361>
 29dd3f3:	shl    $0x2,%r9d
 29dd3f7:	add    $0x14,%r9d
 29dd3fb:	jb     29dfc83 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5363>
 29dd401:	add    %r9d,%ecx
 29dd404:	jb     29dfc85 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5365>
 29dd40a:	mov    %ecx,%r10d
 29dd40d:	lea    (%rdi,%r10,1),%rcx
 29dd411:	cmp    %rdx,%r10
 29dd414:	cmova  %r8,%rcx
 29dd418:	lea    0x14(%r13),%edx
 29dd41c:	sub    %edx,%r9d
 29dd41f:	sub    %r9,%rcx
 29dd422:	mov    %eax,(%rcx)
 29dd424:	mov    (%rsp),%eax
 29dd427:	mov    0x10(%rsp),%ecx
 29dd42b:	add    $0x1,%r12d
 29dd432:	mov    %rsi,0x80(%rsp)
 29dd43a:	jmp    29dd232 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2912>
 29dd43f:	mov    (%rsp),%r12d
 29dd443:	mov    %r12,%rsi
 29dd446:	mov    %r12,0x70(%rsp)
 29dd44b:	test   %esi,%r12d
 29dd44e:	je     29dfc87 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5367>
 29dd454:	mov    0x28(%rsp),%edx
 29dd458:	test   %edx,%edx
 29dd45a:	je     29dfc89 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5369>
 29dd460:	mov    0x70(%rsp),%r11
 29dd465:	test   %r11d,%r12d
 29dd468:	je     29dfc8b <wasm[0]::function[1013]::helper::array_indexed_publish+0x536b>
 29dd46e:	mov    0xd0(%rsp),%r15
 29dd476:	mov    0x28(%r15),%rsi
 29dd47a:	mov    0x20(%r15),%rax
 29dd47e:	mov    %r12d,%edi
 29dd481:	add    %rdi,%rax
 29dd484:	xor    %r8,%r8
 29dd487:	cmp    %rsi,%rdi
 29dd48a:	cmova  %r8,%rax
 29dd48e:	mov    %edx,0x20(%rax)
 29dd491:	mov    0x60(%rsp),%rdi
 29dd496:	mov    0xa00(%rdi),%esi
 29dd49c:	mov    0xa10(%rdi),%edx
 29dd4a2:	test   %esi,%esi
 29dd4a4:	je     29dfc8d <wasm[0]::function[1013]::helper::array_indexed_publish+0x536d>
 29dd4aa:	mov    %esi,0x28(%rax)
 29dd4ad:	test   %edx,%edx
 29dd4af:	je     29dfc8f <wasm[0]::function[1013]::helper::array_indexed_publish+0x536f>
 29dd4b5:	mov    %edx,0x2c(%rax)
 29dd4b8:	movl   $0x0,0x30(%rax)
 29dd4bf:	movl   $0x0,0x24(%rax)
 29dd4c6:	mov    0x10(%rsp),%edx
 29dd4ca:	mov    0xa0(%rsp),%r10
 29dd4d2:	test   %r10d,%r10d
 29dd4d5:	je     29dd4e5 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2bc5>
 29dd4db:	mov    0x70(%rsp),%r12
 29dd4e0:	jmp    29de153 <wasm[0]::function[1013]::helper::array_indexed_publish+0x3833>
 29dd4e5:	xor    %r10d,%r10d
 29dd4e8:	mov    0x70(%rsp),%rax
 29dd4ed:	mov    0x70(%rsp),%r12
 29dd4f2:	test   %eax,%r12d
 29dd4f5:	je     29dfc91 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5371>
 29dd4fb:	test   %eax,%r12d
 29dd4fe:	je     29dfc93 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5373>
 29dd504:	mov    0xd0(%rsp),%r15
 29dd50c:	mov    0x28(%r15),%rdi
 29dd510:	mov    %r12d,%esi
 29dd513:	mov    %rsi,%r8
 29dd516:	add    0x20(%r15),%r8
 29dd51a:	xor    %r9,%r9
 29dd51d:	cmp    %rdi,%rsi
 29dd520:	cmova  %r9,%r8
 29dd524:	mov    0x24(%r8),%edi
 29dd528:	test   %edi,%edi
 29dd52a:	jne    29de14e <wasm[0]::function[1013]::helper::array_indexed_publish+0x382e>
 29dd530:	mov    0xd0(%rsp),%r15
 29dd538:	mov    0x28(%r15),%r10
 29dd53c:	mov    0x20(%r15),%rax
 29dd540:	lea    (%rax,%rsi,1),%rdi
 29dd544:	xor    %r11,%r11
 29dd547:	cmp    %r10,%rsi
 29dd54a:	cmova  %r11,%rdi
 29dd54e:	mov    $0x20,%r14d
 29dd554:	mov    %r14,0xb8(%rsp)
 29dd55c:	mov    0x20(%rdi),%esi
 29dd55f:	test   %esi,%esi
 29dd561:	je     29dfc95 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5375>
 29dd567:	test   %esi,%esi
 29dd569:	je     29dfc97 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5377>
 29dd56f:	mov    %esi,%r8d
 29dd572:	lea    0x10(%rax,%r8,1),%rax
 29dd577:	cmp    %r10,%r8
 29dd57a:	cmova  %r11,%rax
 29dd57e:	mov    (%rax),%r15d
 29dd581:	mov    0x18(%rdi),%r13
 29dd585:	mov    %r15d,%r12d
 29dd588:	mov    0x68(%rsp),%rcx
 29dd58d:	mov    %r15,0x78(%rsp)
 29dd592:	cmp    %r12,%rcx
 29dd595:	setb   %al
 29dd598:	cmp    $0x100000,%rcx
 29dd59f:	setb   %dil
 29dd5a3:	lea    0x8(%r13,%r13,1),%rcx
 29dd5a8:	mov    0x68(%rsp),%r8
 29dd5ad:	cmp    %rcx,%r8
 29dd5b0:	setbe  %r8b
 29dd5b4:	and    %r8d,%edi
 29dd5b7:	or     %edi,%eax
 29dd5b9:	test   %al,%al
 29dd5bb:	jne    29ddb5f <wasm[0]::function[1013]::helper::array_indexed_publish+0x323f>
 29dd5c1:	mov    $0x8,%eax
 29dd5c6:	mov    %rax,0x98(%rsp)
 29dd5ce:	shl    $0x2,%r13
 29dd5d2:	mov    %esi,0x28(%rsp)
 29dd5d6:	mov    0x70(%rsp),%r12
 29dd5db:	mov    %r12d,0x10(%rsp)
 29dd5e0:	mov    %edx,(%rsp)
 29dd5e3:	mov    0xd8(%rsp),%r12
 29dd5eb:	mov    (%r12),%rax
 29dd5ef:	mov    0xa8(%rsp),%rcx
 29dd5f7:	cmp    %rcx,%rax
 29dd5fa:	jae    29df67f <wasm[0]::function[1013]::helper::array_indexed_publish+0x4d5f>
 29dd600:	mov    0x98(%rsp),%rdi
 29dd608:	jmp    29dd615 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2cf5>
 29dd60d:	mov    0x98(%rsp),%rdi
 29dd615:	mov    %edi,%r14d
 29dd618:	imul   $0x3,%r14,%rax
 29dd61c:	cmp    %rax,%r13
 29dd61f:	mov    %r13,0xb0(%rsp)
 29dd627:	jbe    29dd655 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2d35>
 29dd62d:	mov    0x28(%rsp),%esi
 29dd631:	mov    0x10(%rsp),%r12d
 29dd636:	mov    %r12,0x70(%rsp)
 29dd63b:	mov    (%rsp),%edx
 29dd63e:	shl    $1,%edi
 29dd640:	mov    0xb0(%rsp),%r13
 29dd648:	mov    %rdi,0x98(%rsp)
 29dd650:	jmp    29dd5d2 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2cb2>
 29dd655:	mov    %r14,%r12
 29dd658:	shl    $0x2,%r12
 29dd65c:	mov    %r12,%rax
 29dd65f:	shr    $0x20,%rax
 29dd663:	test   %rax,%rax
 29dd666:	jne    29dfc99 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5379>
 29dd66c:	mov    %rdi,%rcx
 29dd66f:	shl    $0x2,%ecx
 29dd672:	mov    %rdi,0x98(%rsp)
 29dd67a:	add    $0x14,%ecx
 29dd67d:	jb     29dfc9b <wasm[0]::function[1013]::helper::array_indexed_publish+0x537b>
 29dd683:	mov    0x60(%rsp),%rdi
 29dd688:	mov    0x20(%rdi),%rdi
 29dd68c:	mov    (%rdi),%eax
 29dd68e:	mov    %eax,%edx
 29dd690:	mov    %ecx,%esi
 29dd692:	add    $0xf,%rsi
 29dd699:	mov    %rsi,%r8
 29dd69c:	and    $0xfffffffffffffff0,%r8
 29dd6a0:	add    %rdx,%r8
 29dd6a3:	mov    0x4(%rdi),%r9d
 29dd6a7:	mov    %rdi,0x80(%rsp)
 29dd6af:	cmp    %r9,%r8
 29dd6b2:	ja     29df6bb <wasm[0]::function[1013]::helper::array_indexed_publish+0x4d9b>
 29dd6b8:	add    $0xf,%ecx
 29dd6be:	and    $0xfffffff0,%ecx
 29dd6c1:	add    %eax,%ecx
 29dd6c3:	mov    0x80(%rsp),%rbx
 29dd6cb:	mov    %ecx,(%rbx)
 29dd6cd:	mov    0xd0(%rsp),%r15
 29dd6d5:	mov    0x20(%r15),%rdi
 29dd6d9:	lea    (%rdi,%rdx,1),%rcx
 29dd6dd:	movl   $0xa800000e,(%rdi,%rdx,1)
 29dd6e4:	mov    0x60(%rsp),%r8
 29dd6e9:	mov    0x28(%r8),%r8
 29dd6ed:	mov    0x1ac(%r8),%r8d
 29dd6f4:	mov    %r8d,0x4(%rdi,%rdx,1)
 29dd6f9:	and    $0xfffffffffffffff0,%rsi
 29dd6fd:	mov    %esi,0x8(%rdi,%rdx,1)
 29dd701:	mov    %eax,0x18(%rsp)
 29dd705:	mov    0x98(%rsp),%r13
 29dd70d:	mov    %r13d,0x10(%rcx)
 29dd711:	test   %eax,%eax
 29dd713:	je     29dfc9d <wasm[0]::function[1013]::helper::array_indexed_publish+0x537d>
 29dd719:	mov    0xd0(%rsp),%r15
 29dd721:	mov    0x28(%r15),%rcx
 29dd725:	mov    0x20(%r15),%rdx
 29dd729:	mov    %eax,%esi
 29dd72b:	lea    (%rdx,%rsi,1),%rax
 29dd72f:	lea    0x10(%rdx,%rsi,1),%rdi
 29dd734:	xor    %r8,%r8
 29dd737:	cmp    %rcx,%rsi
 29dd73a:	cmova  %r8,%rdi
 29dd73e:	mov    (%rdi),%edi
 29dd740:	cmp    %rdi,%r14
 29dd743:	ja     29dfc9f <wasm[0]::function[1013]::helper::array_indexed_publish+0x537f>
 29dd749:	lea    0x14(%rdx,%rsi,1),%rbx
 29dd74e:	mov    %rbx,%rsi
 29dd751:	add    %r12,%rsi
 29dd754:	jb     29dfca1 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5381>
 29dd75a:	add    %rdx,%rcx
 29dd75d:	cmp    %rcx,%rsi
 29dd760:	ja     29dfca3 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5383>
 29dd766:	mov    0x28(%rsp),%edx
 29dd76a:	mov    0x10(%rsp),%esi
 29dd76e:	mov    (%rsp),%edi
 29dd771:	lea    0x14(%rax,%r14,4),%r12
 29dd776:	test   %r14,%r14
 29dd779:	je     29dd7c7 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2ea7>
 29dd77f:	mov    %edx,(%rsp)
 29dd782:	mov    %esi,0x10(%rsp)
 29dd786:	mov    %edi,0x28(%rsp)
 29dd78a:	mov    0xd8(%rsp),%rax
 29dd792:	mov    (%rax),%rcx
 29dd795:	mov    0xa8(%rsp),%rax
 29dd79d:	cmp    %rax,%rcx
 29dd7a0:	jae    29df6ed <wasm[0]::function[1013]::helper::array_indexed_publish+0x4dcd>
 29dd7a6:	movl   $0x0,(%rbx)
 29dd7ac:	mov    (%rsp),%edx
 29dd7af:	mov    0x10(%rsp),%esi
 29dd7b3:	mov    0x28(%rsp),%edi
 29dd7b7:	add    $0x4,%rbx
 29dd7be:	cmp    %r12,%rbx
 29dd7c1:	jne    29dd77f <wasm[0]::function[1013]::helper::array_indexed_publish+0x2e5f>
 29dd7c7:	mov    %edx,(%rsp)
 29dd7ca:	xor    %r12d,%r12d
 29dd7cd:	mov    $0x10,%eax
 29dd7d2:	mov    %rax,%rbx
 29dd7d5:	mov    0x60(%rsp),%r8
 29dd7da:	mov    0x28(%r8),%rax
 29dd7de:	mov    0x1a8(%rax),%r15d
 29dd7e5:	mov    %r15,0x90(%rsp)
 29dd7ed:	mov    $0x20,%eax
 29dd7f2:	mov    %rax,0x88(%rsp)
 29dd7fa:	mov    %esi,0x28(%rsp)
 29dd7fe:	mov    %edi,0x10(%rsp)
 29dd802:	mov    0xd8(%rsp),%rax
 29dd80a:	mov    (%rax),%rax
 29dd80d:	mov    0xa8(%rsp),%rcx
 29dd815:	cmp    %rcx,%rax
 29dd818:	jae    29df721 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4e01>
 29dd81e:	mov    0x78(%rsp),%rdi
 29dd823:	jmp    29dd82d <wasm[0]::function[1013]::helper::array_indexed_publish+0x2f0d>
 29dd828:	mov    0x78(%rsp),%rdi
 29dd82d:	cmp    %edi,%r12d
 29dd830:	mov    %rdi,0x78(%rsp)
 29dd835:	jae    29ddae6 <wasm[0]::function[1013]::helper::array_indexed_publish+0x31c6>
 29dd83b:	mov    (%rsp),%r11d
 29dd83f:	test   %r11d,%r11d
 29dd842:	je     29dfca5 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5385>
 29dd848:	test   %r11d,%r11d
 29dd84b:	je     29dfca7 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5387>
 29dd851:	mov    0xd0(%rsp),%r15
 29dd859:	mov    0x28(%r15),%rax
 29dd85d:	mov    0x20(%r15),%rcx
 29dd861:	mov    %r11d,%edi
 29dd864:	lea    0x10(%rcx,%rdi,1),%rsi
 29dd869:	xor    %rdx,%rdx
 29dd86c:	cmp    %rax,%rdi
 29dd86f:	cmova  %rdx,%rsi
 29dd873:	mov    (%rsi),%esi
 29dd875:	cmp    %esi,%r12d
 29dd878:	jae    29dfca9 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5389>
 29dd87e:	mov    %esi,%edi
 29dd880:	shl    $0x2,%rdi
 29dd884:	shr    $0x20,%rdi
 29dd888:	test   %rdi,%rdi
 29dd88b:	jne    29dfcab <wasm[0]::function[1013]::helper::array_indexed_publish+0x538b>
 29dd891:	shl    $0x2,%esi
 29dd894:	add    $0x14,%esi
 29dd897:	jb     29dfcad <wasm[0]::function[1013]::helper::array_indexed_publish+0x538d>
 29dd89d:	add    %esi,%r11d
 29dd8a0:	jb     29dfcaf <wasm[0]::function[1013]::helper::array_indexed_publish+0x538f>
 29dd8a6:	mov    %r11d,%edi
 29dd8a9:	add    %rdi,%rcx
 29dd8ac:	cmp    %rax,%rdi
 29dd8af:	cmova  %rdx,%rcx
 29dd8b3:	mov    %r12,%rax
 29dd8b6:	shl    $0x2,%eax
 29dd8b9:	add    $0x14,%eax
 29dd8bf:	sub    %eax,%esi
 29dd8c1:	sub    %rsi,%rcx
 29dd8c4:	mov    (%rcx),%eax
 29dd8c6:	mov    %eax,0x8(%rsp)
 29dd8ca:	test   %eax,%eax
 29dd8cc:	jne    29dd8ef <wasm[0]::function[1013]::helper::array_indexed_publish+0x2fcf>
 29dd8d2:	mov    0x90(%rsp),%rcx
 29dd8da:	mov    0xb8(%rsp),%r9
 29dd8e2:	mov    0x80(%rsp),%r15
 29dd8ea:	jmp    29ddaba <wasm[0]::function[1013]::helper::array_indexed_publish+0x319a>
 29dd8ef:	mov    0x18(%rsp),%ecx
 29dd8f3:	test   %ecx,%ecx
 29dd8f5:	je     29dfcb1 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5391>
 29dd8fb:	test   %ecx,%ecx
 29dd8fd:	je     29dfcb3 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5393>
 29dd903:	mov    0xd0(%rsp),%r15
 29dd90b:	mov    0x28(%r15),%rdx
 29dd90f:	mov    0x20(%r15),%rsi
 29dd913:	mov    %ecx,%r9d
 29dd916:	lea    0x10(%rsi,%r9,1),%r8
 29dd91b:	xor    %rdi,%rdi
 29dd91e:	cmp    %rdx,%r9
 29dd921:	cmova  %rdi,%r8
 29dd925:	mov    (%r8),%r8d
 29dd928:	mov    %r12,%r9
 29dd92b:	shr    $0x10,%r9d
 29dd92f:	mov    %r12,%r10
 29dd932:	xor    %r9d,%r10d
 29dd935:	imul   $0x7feb352d,%r10d,%r9d
 29dd93c:	mov    %r9,%r10
 29dd93f:	shr    $0xf,%r10d
 29dd943:	xor    %r10d,%r9d
 29dd946:	imul   $0x846ca68b,%r9d,%r13d
 29dd94d:	mov    %r13,%r9
 29dd950:	shr    $0x10,%r9d
 29dd954:	xor    %r9d,%r13d
 29dd957:	mov    0x98(%rsp),%r9
 29dd95f:	sub    $0x1,%r9d
 29dd963:	and    %r9d,%r13d
 29dd966:	cmp    %r8d,%r13d
 29dd969:	jae    29dfcb5 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5395>
 29dd96f:	mov    %r8d,%r9d
 29dd972:	shl    $0x2,%r9
 29dd976:	shr    $0x20,%r9
 29dd97a:	test   %r9,%r9
 29dd97d:	jne    29dfcb7 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5397>
 29dd983:	shl    $0x2,%r8d
 29dd987:	add    $0x14,%r8d
 29dd98b:	jb     29dfcb9 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5399>
 29dd991:	add    %r8d,%ecx
 29dd994:	jb     29dfcbb <wasm[0]::function[1013]::helper::array_indexed_publish+0x539b>
 29dd99a:	mov    %ecx,%r9d
 29dd99d:	lea    (%rsi,%r9,1),%rcx
 29dd9a1:	cmp    %rdx,%r9
 29dd9a4:	cmova  %rdi,%rcx
 29dd9a8:	mov    %r13,%r14
 29dd9ab:	shl    $0x2,%r14d
 29dd9af:	lea    0x14(%r14),%edx
 29dd9b3:	sub    %edx,%r8d
 29dd9b6:	sub    %r8,%rcx
 29dd9b9:	mov    (%rcx),%ecx
 29dd9bb:	mov    %ecx,0x20(%rsp)
 29dd9bf:	test   %eax,%eax
 29dd9c1:	je     29dfcbd <wasm[0]::function[1013]::helper::array_indexed_publish+0x539d>
 29dd9c7:	mov    0x80(%rsp),%r15
 29dd9cf:	mov    (%r15),%eax
 29dd9d2:	mov    %eax,%esi
 29dd9d4:	lea    0x20(%rsi),%rcx
 29dd9d8:	mov    0x4(%r15),%edx
 29dd9dc:	cmp    %rdx,%rcx
 29dd9df:	ja     29df75a <wasm[0]::function[1013]::helper::array_indexed_publish+0x4e3a>
 29dd9e5:	lea    0x20(%rax),%ecx
 29dd9e8:	mov    %ecx,(%r15)
 29dd9eb:	mov    0xd0(%rsp),%rcx
 29dd9f3:	mov    0x20(%rcx),%rdi
 29dd9f7:	lea    (%rdi,%rsi,1),%rdx
 29dd9fb:	movl   $0xb0000062,(%rdi,%rsi,1)
 29dda02:	mov    0x90(%rsp),%rcx
 29dda0a:	mov    %ecx,0x4(%rdi,%rsi,1)
 29dda0e:	mov    0xb8(%rsp),%r9
 29dda16:	mov    %r9d,0x8(%rdi,%rsi,1)
 29dda1b:	mov    %r12d,%esi
 29dda1e:	mov    %rsi,0x10(%rdx)
 29dda22:	mov    0x8(%rsp),%esi
 29dda26:	mov    %esi,0x18(%rdx)
 29dda29:	mov    0x20(%rsp),%esi
 29dda2d:	mov    %esi,0x1c(%rdx)
 29dda30:	mov    0x18(%rsp),%edx
 29dda34:	test   %edx,%edx
 29dda36:	je     29dfcbf <wasm[0]::function[1013]::helper::array_indexed_publish+0x539f>
 29dda3c:	test   %eax,%eax
 29dda3e:	je     29dfcc1 <wasm[0]::function[1013]::helper::array_indexed_publish+0x53a1>
 29dda44:	test   %edx,%edx
 29dda46:	je     29dfcc3 <wasm[0]::function[1013]::helper::array_indexed_publish+0x53a3>
 29dda4c:	mov    0xd0(%rsp),%rsi
 29dda54:	mov    0x28(%rsi),%r10
 29dda58:	mov    0x20(%rsi),%r11
 29dda5c:	mov    %edx,%r8d
 29dda5f:	lea    0x10(%r11,%r8,1),%rdi
 29dda64:	xor    %rsi,%rsi
 29dda67:	cmp    %r10,%r8
 29dda6a:	cmova  %rsi,%rdi
 29dda6e:	mov    (%rdi),%edi
 29dda70:	cmp    %edi,%r13d
 29dda73:	jae    29dfcc5 <wasm[0]::function[1013]::helper::array_indexed_publish+0x53a5>
 29dda79:	mov    %edi,%r8d
 29dda7c:	shl    $0x2,%r8
 29dda80:	shr    $0x20,%r8
 29dda84:	test   %r8,%r8
 29dda87:	jne    29dfcc7 <wasm[0]::function[1013]::helper::array_indexed_publish+0x53a7>
 29dda8d:	shl    $0x2,%edi
 29dda90:	add    $0x14,%edi
 29dda93:	jb     29dfcc9 <wasm[0]::function[1013]::helper::array_indexed_publish+0x53a9>
 29dda99:	add    %edi,%edx
 29dda9b:	jb     29dfccb <wasm[0]::function[1013]::helper::array_indexed_publish+0x53ab>
 29ddaa1:	mov    %edx,%r8d
 29ddaa4:	lea    (%r11,%r8,1),%rdx
 29ddaa8:	cmp    %r10,%r8
 29ddaab:	cmova  %rsi,%rdx
 29ddaaf:	lea    0x14(%r14),%esi
 29ddab3:	sub    %esi,%edi
 29ddab5:	sub    %rdi,%rdx
 29ddab8:	mov    %eax,(%rdx)
 29ddaba:	mov    0x28(%rsp),%esi
 29ddabe:	mov    0x10(%rsp),%edi
 29ddac2:	add    $0x1,%r12d
 29ddac9:	mov    %r15,0x80(%rsp)
 29ddad1:	mov    %rcx,0x90(%rsp)
 29ddad9:	mov    %r9,0xb8(%rsp)
 29ddae1:	jmp    29dd7fa <wasm[0]::function[1013]::helper::array_indexed_publish+0x2eda>
 29ddae6:	mov    0x60(%rsp),%rdi
 29ddaeb:	mov    0x9f0(%rdi),%eax
 29ddaf1:	mov    0x28(%rsp),%r12d
 29ddaf6:	mov    %r12,0x70(%rsp)
 29ddafb:	xor    %r10d,%r10d
 29ddafe:	mov    0x70(%rsp),%rcx
 29ddb03:	test   %ecx,%r12d
 29ddb06:	je     29dfccd <wasm[0]::function[1013]::helper::array_indexed_publish+0x53ad>
 29ddb0c:	test   %eax,%eax
 29ddb0e:	je     29dfccf <wasm[0]::function[1013]::helper::array_indexed_publish+0x53af>
 29ddb14:	test   %ecx,%r12d
 29ddb17:	je     29dfcd1 <wasm[0]::function[1013]::helper::array_indexed_publish+0x53b1>
 29ddb1d:	mov    0xd0(%rsp),%r15
 29ddb25:	mov    0x28(%r15),%rsi
 29ddb29:	mov    0x20(%r15),%rdx
 29ddb2d:	mov    %r12d,%edi
 29ddb30:	add    %rdi,%rdx
 29ddb33:	xor    %r8,%r8
 29ddb36:	cmp    %rsi,%rdi
 29ddb39:	cmova  %r8,%rdx
 29ddb3d:	mov    %eax,0x20(%rdx)
 29ddb40:	mov    0x18(%rsp),%eax
 29ddb44:	test   %eax,%eax
 29ddb46:	je     29dfcd3 <wasm[0]::function[1013]::helper::array_indexed_publish+0x53b3>
 29ddb4c:	mov    %eax,0x10(%rdx)
 29ddb4f:	movl   $0x1,0x24(%rdx)
 29ddb56:	mov    0x10(%rsp),%edx
 29ddb5a:	jmp    29de14e <wasm[0]::function[1013]::helper::array_indexed_publish+0x382e>
 29ddb5f:	mov    0x68(%rsp),%rcx
 29ddb64:	mov    %r13,0xb0(%rsp)
 29ddb6c:	cmp    %r12,%rcx
 29ddb6f:	jb     29ddff4 <wasm[0]::function[1013]::helper::array_indexed_publish+0x36d4>
 29ddb75:	mov    0x78(%rsp),%rax
 29ddb7a:	mov    0x78(%rsp),%rbx
 29ddb7f:	test   %eax,%ebx
 29ddb81:	je     29ddb91 <wasm[0]::function[1013]::helper::array_indexed_publish+0x3271>
 29ddb87:	mov    0x78(%rsp),%r15
 29ddb8c:	jmp    29ddb97 <wasm[0]::function[1013]::helper::array_indexed_publish+0x3277>
 29ddb91:	mov    $0x8,%r15d
 29ddb97:	mov    %esi,0x18(%rsp)
 29ddb9b:	mov    0x70(%rsp),%rax
 29ddba0:	mov    %eax,0x10(%rsp)
 29ddba4:	mov    %edx,0x28(%rsp)
 29ddba8:	mov    0xd8(%rsp),%rdx
 29ddbb0:	mov    (%rdx),%rax
 29ddbb3:	mov    0xa8(%rsp),%rcx
 29ddbbb:	cmp    %rcx,%rax
 29ddbbe:	jae    29df79f <wasm[0]::function[1013]::helper::array_indexed_publish+0x4e7f>
 29ddbc4:	mov    %r15d,%r14d
 29ddbc7:	mov    0x68(%rsp),%rcx
 29ddbcc:	cmp    %r14,%rcx
 29ddbcf:	jb     29ddbee <wasm[0]::function[1013]::helper::array_indexed_publish+0x32ce>
 29ddbd5:	mov    0x18(%rsp),%esi
 29ddbd9:	mov    0x10(%rsp),%edi
 29ddbdd:	mov    %rdi,0x70(%rsp)
 29ddbe2:	mov    0x28(%rsp),%edx
 29ddbe6:	shl    $1,%r15d
 29ddbe9:	jmp    29ddb97 <wasm[0]::function[1013]::helper::array_indexed_publish+0x3277>
 29ddbee:	mov    %r14,%r13
 29ddbf1:	shl    $0x2,%r13
 29ddbf5:	mov    %r13,%rax
 29ddbf8:	shr    $0x20,%rax
 29ddbfc:	test   %rax,%rax
 29ddbff:	jne    29dfcd5 <wasm[0]::function[1013]::helper::array_indexed_publish+0x53b5>
 29ddc05:	mov    %r15,%rcx
 29ddc08:	shl    $0x2,%ecx
 29ddc0b:	add    $0x14,%ecx
 29ddc0e:	jb     29dfcd7 <wasm[0]::function[1013]::helper::array_indexed_publish+0x53b7>
 29ddc14:	mov    0x60(%rsp),%rdi
 29ddc19:	mov    0x20(%rdi),%rdi
 29ddc1d:	mov    (%rdi),%eax
 29ddc1f:	mov    %eax,%edx
 29ddc21:	mov    %ecx,%esi
 29ddc23:	add    $0xf,%rsi
 29ddc2a:	mov    %rsi,%r8
 29ddc2d:	and    $0xfffffffffffffff0,%r8
 29ddc31:	add    %rdx,%r8
 29ddc34:	mov    0x4(%rdi),%r9d
 29ddc38:	cmp    %r9,%r8
 29ddc3b:	ja     29df7d3 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4eb3>
 29ddc41:	add    $0xf,%ecx
 29ddc47:	and    $0xfffffff0,%ecx
 29ddc4a:	add    %eax,%ecx
 29ddc4c:	mov    %ecx,(%rdi)
 29ddc4e:	mov    0xd0(%rsp),%rcx
 29ddc56:	mov    0x20(%rcx),%rdi
 29ddc5a:	lea    (%rdi,%rdx,1),%rcx
 29ddc5e:	movl   $0xa800000e,(%rdi,%rdx,1)
 29ddc65:	mov    0x60(%rsp),%r8
 29ddc6a:	mov    0x28(%r8),%r8
 29ddc6e:	mov    0x194(%r8),%r8d
 29ddc75:	mov    %r8d,0x4(%rdi,%rdx,1)
 29ddc7a:	and    $0xfffffffffffffff0,%rsi
 29ddc7e:	mov    %esi,0x8(%rdi,%rdx,1)
 29ddc82:	mov    %eax,(%rsp)
 29ddc85:	mov    %r15d,0x10(%rcx)
 29ddc89:	test   %eax,%eax
 29ddc8b:	je     29dfcd9 <wasm[0]::function[1013]::helper::array_indexed_publish+0x53b9>
 29ddc91:	mov    0xd0(%rsp),%r15
 29ddc99:	mov    0x28(%r15),%rdi
 29ddc9d:	mov    0x20(%r15),%r9
 29ddca1:	mov    %eax,%r10d
 29ddca4:	lea    (%r9,%r10,1),%r8
 29ddca8:	lea    0x10(%r9,%r10,1),%rsi
 29ddcad:	xor    %r11,%r11
 29ddcb0:	cmp    %rdi,%r10
 29ddcb3:	cmova  %r11,%rsi
 29ddcb7:	mov    (%rsi),%r11d
 29ddcba:	cmp    %r11,%r14
 29ddcbd:	ja     29dfcdb <wasm[0]::function[1013]::helper::array_indexed_publish+0x53bb>
 29ddcc3:	lea    0x14(%r9,%r10,1),%rbx
 29ddcc8:	mov    %rbx,%r10
 29ddccb:	add    %r13,%r10
 29ddcce:	jb     29dfcdd <wasm[0]::function[1013]::helper::array_indexed_publish+0x53bd>
 29ddcd4:	lea    (%r9,%rdi,1),%r11
 29ddcd8:	cmp    %r11,%r10
 29ddcdb:	ja     29dfcdf <wasm[0]::function[1013]::helper::array_indexed_publish+0x53bf>
 29ddce1:	mov    0x18(%rsp),%edi
 29ddce5:	mov    0x10(%rsp),%r9d
 29ddcea:	mov    %r9,0x70(%rsp)
 29ddcef:	mov    0x28(%rsp),%edx
 29ddcf3:	lea    0x14(%r8,%r14,4),%r13
 29ddcf8:	test   %r14,%r14
 29ddcfb:	je     29ddd55 <wasm[0]::function[1013]::helper::array_indexed_publish+0x3435>
 29ddd01:	mov    %edi,0x28(%rsp)
 29ddd05:	mov    0x70(%rsp),%rax
 29ddd0a:	mov    %eax,0x10(%rsp)
 29ddd0e:	mov    %edx,0x18(%rsp)
 29ddd12:	mov    0xd8(%rsp),%rax
 29ddd1a:	mov    (%rax),%rcx
 29ddd1d:	mov    0xa8(%rsp),%rax
 29ddd25:	cmp    %rax,%rcx
 29ddd28:	jae    29df805 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4ee5>
 29ddd2e:	movl   $0x0,(%rbx)
 29ddd34:	mov    0x28(%rsp),%edi
 29ddd38:	mov    0x10(%rsp),%eax
 29ddd3c:	mov    %rax,0x70(%rsp)
 29ddd41:	mov    0x18(%rsp),%edx
 29ddd45:	add    $0x4,%rbx
 29ddd4c:	cmp    %r13,%rbx
 29ddd4f:	jne    29ddd01 <wasm[0]::function[1013]::helper::array_indexed_publish+0x33e1>
 29ddd55:	mov    (%rsp),%esi
 29ddd58:	test   %esi,%esi
 29ddd5a:	je     29dfce1 <wasm[0]::function[1013]::helper::array_indexed_publish+0x53c1>
 29ddd60:	test   %edi,%edi
 29ddd62:	je     29dfce3 <wasm[0]::function[1013]::helper::array_indexed_publish+0x53c3>
 29ddd68:	test   %esi,%esi
 29ddd6a:	je     29dfce5 <wasm[0]::function[1013]::helper::array_indexed_publish+0x53c5>
 29ddd70:	mov    0xd0(%rsp),%r15
 29ddd78:	mov    0x28(%r15),%r10
 29ddd7c:	mov    0x20(%r15),%rax
 29ddd80:	mov    %rax,0x88(%rsp)
 29ddd88:	mov    %esi,%eax
 29ddd8a:	mov    0x88(%rsp),%r9
 29ddd92:	lea    (%r9,%rax,1),%r8
 29ddd96:	lea    0x10(%r9,%rax,1),%r9
 29ddd9b:	xor    %r11,%r11
 29ddd9e:	cmp    %r10,%rax
 29ddda1:	cmova  %r11,%r9
 29ddda5:	mov    (%r9),%ecx
 29ddda8:	cmp    %rcx,%r12
 29dddab:	ja     29dfce7 <wasm[0]::function[1013]::helper::array_indexed_publish+0x53c7>
 29dddb1:	test   %edi,%edi
 29dddb3:	je     29dfce9 <wasm[0]::function[1013]::helper::array_indexed_publish+0x53c9>
 29dddb9:	mov    %edi,%r14d
 29dddbc:	mov    0x88(%rsp),%rcx
 29dddc4:	mov    %r14,%rbx
 29dddc7:	lea    (%rcx,%rbx,1),%r9
 29dddcb:	mov    %rbx,0x80(%rsp)
 29dddd3:	lea    0x10(%rcx,%r14,1),%rbx
 29dddd8:	mov    0x80(%rsp),%r14
 29ddde0:	cmp    %r10,%r14
 29ddde3:	cmova  %r11,%rbx
 29ddde7:	mov    (%rbx),%ecx
 29ddde9:	cmp    %rcx,%r12
 29dddec:	ja     29dfceb <wasm[0]::function[1013]::helper::array_indexed_publish+0x53cb>
 29dddf2:	mov    0x88(%rsp),%rcx
 29dddfa:	lea    0x14(%rcx,%rax,1),%rbx
 29dddff:	mov    %r12,%r11
 29dde02:	shl    $0x2,%r11
 29dde06:	add    %r11,%rbx
 29dde09:	jb     29dfced <wasm[0]::function[1013]::helper::array_indexed_publish+0x53cd>
 29dde0f:	add    %rcx,%r10
 29dde12:	cmp    %r10,%rbx
 29dde15:	ja     29dfcef <wasm[0]::function[1013]::helper::array_indexed_publish+0x53cf>
 29dde1b:	lea    0x14(%rcx,%r14,1),%rbx
 29dde20:	add    %r11,%rbx
 29dde23:	jb     29dfcf1 <wasm[0]::function[1013]::helper::array_indexed_publish+0x53d1>
 29dde29:	cmp    %r10,%rbx
 29dde2c:	ja     29dfcf3 <wasm[0]::function[1013]::helper::array_indexed_publish+0x53d3>
 29dde32:	mov    0x78(%rsp),%rbx
 29dde37:	mov    0x78(%rsp),%r10
 29dde3c:	test   %r10d,%ebx
 29dde3f:	jne    29dde54 <wasm[0]::function[1013]::helper::array_indexed_publish+0x3534>
 29dde45:	mov    0x70(%rsp),%rax
 29dde4a:	mov    0x70(%rsp),%r12
 29dde4f:	jmp    29ddfad <wasm[0]::function[1013]::helper::array_indexed_publish+0x368d>
 29dde54:	mov    (%rsp),%r10d
 29dde58:	mov    0x88(%rsp),%rcx
 29dde60:	lea    0x14(%rcx,%rax,1),%r13
 29dde65:	mov    0x88(%rsp),%rax
 29dde6d:	mov    0x80(%rsp),%r14
 29dde75:	lea    0x14(%rax,%r14,1),%r14
 29dde7a:	xor    %ebx,%ebx
 29dde7c:	lea    0x14(%r8,%r12,4),%r15
 29dde81:	lea    0x14(%r9,%r12,4),%r12
 29dde86:	cmp    %r14,%r13
 29dde89:	jae    29dde97 <wasm[0]::function[1013]::helper::array_indexed_publish+0x3577>
 29dde8f:	mov    %r10,%rsi
 29dde92:	jmp    29ddf31 <wasm[0]::function[1013]::helper::array_indexed_publish+0x3611>
 29dde97:	mov    %r10,%rsi
 29dde9a:	mov    %r10d,0x20(%rsp)
 29dde9f:	mov    %edi,0x18(%rsp)
 29ddea3:	mov    0x70(%rsp),%rax
 29ddea8:	mov    %eax,0x10(%rsp)
 29ddeac:	mov    %esi,0x28(%rsp)
 29ddeb0:	mov    %edx,(%rsp)
 29ddeb3:	mov    0xd8(%rsp),%rax
 29ddebb:	mov    (%rax),%rcx
 29ddebe:	mov    0xa8(%rsp),%rax
 29ddec6:	cmp    %rax,%rcx
 29ddec9:	jae    29df839 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4f19>
 29ddecf:	sub    $0x4,%r12
 29dded3:	mov    (%r12),%r8d
 29dded7:	sub    $0x4,%r15
 29ddedb:	mov    %r8d,(%r15)
 29ddede:	mov    0x10(%rsp),%eax
 29ddee2:	mov    %rax,0x70(%rsp)
 29ddee7:	mov    0x28(%rsp),%esi
 29ddeeb:	mov    (%rsp),%edx
 29ddeee:	mov    0x20(%rsp),%r10d
 29ddef3:	mov    0x18(%rsp),%edi
 29ddef7:	mov    0x88(%rsp),%rax
 29ddeff:	mov    0x80(%rsp),%r14
 29ddf07:	lea    0x14(%rax,%r14,1),%r9
 29ddf0c:	mov    0x78(%rsp),%rbx
 29ddf11:	sub    $0x1,%ebx
 29ddf14:	mov    %rbx,0x78(%rsp)
 29ddf19:	cmp    %r9,%r12
 29ddf1c:	jne    29dde9a <wasm[0]::function[1013]::helper::array_indexed_publish+0x357a>
 29ddf22:	mov    0x70(%rsp),%rax
 29ddf27:	mov    0x70(%rsp),%r12
 29ddf2c:	jmp    29ddfad <wasm[0]::function[1013]::helper::array_indexed_publish+0x368d>
 29ddf31:	mov    %r10d,0x18(%rsp)
 29ddf36:	mov    %edi,0x20(%rsp)
 29ddf3a:	mov    0x70(%rsp),%rdi
 29ddf3f:	mov    %edi,(%rsp)
 29ddf42:	mov    %esi,0x28(%rsp)
 29ddf46:	mov    %edx,0x10(%rsp)
 29ddf4a:	mov    0xd8(%rsp),%rax
 29ddf52:	mov    (%rax),%rcx
 29ddf55:	mov    0xa8(%rsp),%rax
 29ddf5d:	cmp    %rax,%rcx
 29ddf60:	jae    29df86d <wasm[0]::function[1013]::helper::array_indexed_publish+0x4f4d>
 29ddf66:	mov    (%r14),%eax
 29ddf69:	mov    %eax,0x0(%r13)
 29ddf6d:	mov    (%rsp),%eax
 29ddf70:	mov    %rax,0x70(%rsp)
 29ddf75:	mov    0x28(%rsp),%esi
 29ddf79:	mov    0x10(%rsp),%edx
 29ddf7d:	mov    0x18(%rsp),%r10d
 29ddf82:	mov    0x20(%rsp),%edi
 29ddf86:	add    $0x4,%r14
 29ddf8d:	add    $0x4,%r13
 29ddf94:	add    $0x1,%ebx
 29ddf9a:	cmp    %r12,%r14
 29ddf9d:	jne    29ddf31 <wasm[0]::function[1013]::helper::array_indexed_publish+0x3611>
 29ddfa3:	mov    0x70(%rsp),%rax
 29ddfa8:	mov    0x70(%rsp),%r12
 29ddfad:	test   %eax,%r12d
 29ddfb0:	je     29dfcf5 <wasm[0]::function[1013]::helper::array_indexed_publish+0x53d5>
 29ddfb6:	test   %esi,%esi
 29ddfb8:	je     29dfcf7 <wasm[0]::function[1013]::helper::array_indexed_publish+0x53d7>
 29ddfbe:	mov    0x70(%rsp),%rax
 29ddfc3:	mov    0x70(%rsp),%r12
 29ddfc8:	test   %eax,%r12d
 29ddfcb:	je     29dfcf9 <wasm[0]::function[1013]::helper::array_indexed_publish+0x53d9>
 29ddfd1:	mov    0xd0(%rsp),%r15
 29ddfd9:	mov    0x28(%r15),%rax
 29ddfdd:	mov    %r12d,%r8d
 29ddfe0:	mov    %r8,%rdi
 29ddfe3:	add    0x20(%r15),%rdi
 29ddfe7:	xor    %r9,%r9
 29ddfea:	cmp    %rax,%r8
 29ddfed:	cmova  %r9,%rdi
 29ddff1:	mov    %esi,0x20(%rdi)
 29ddff4:	test   %esi,%esi
 29ddff6:	je     29dfcfb <wasm[0]::function[1013]::helper::array_indexed_publish+0x53db>
 29ddffc:	test   %esi,%esi
 29ddffe:	je     29dfcfd <wasm[0]::function[1013]::helper::array_indexed_publish+0x53dd>
 29de004:	mov    0xd0(%rsp),%r15
 29de00c:	mov    0x28(%r15),%rdi
 29de010:	mov    0x20(%r15),%r8
 29de014:	mov    %esi,%eax
 29de016:	lea    0x10(%r8,%rax,1),%r10
 29de01b:	xor    %r9,%r9
 29de01e:	cmp    %rdi,%rax
 29de021:	cmova  %r9,%r10
 29de025:	mov    (%r10),%r10d
 29de028:	mov    0x68(%rsp),%rcx
 29de02d:	cmp    %r10d,%ecx
 29de030:	jae    29dfcff <wasm[0]::function[1013]::helper::array_indexed_publish+0x53df>
 29de036:	mov    %r10d,%r11d
 29de039:	shl    $0x2,%r11
 29de03d:	shr    $0x20,%r11
 29de041:	test   %r11,%r11
 29de044:	jne    29dfd01 <wasm[0]::function[1013]::helper::array_indexed_publish+0x53e1>
 29de04a:	shl    $0x2,%r10d
 29de04e:	add    $0x14,%r10d
 29de052:	jb     29dfd03 <wasm[0]::function[1013]::helper::array_indexed_publish+0x53e3>
 29de058:	mov    %rsi,%r11
 29de05b:	add    %r10d,%r11d
 29de05e:	jb     29dfd05 <wasm[0]::function[1013]::helper::array_indexed_publish+0x53e5>
 29de064:	mov    %r11d,%r11d
 29de067:	add    %r11,%r8
 29de06a:	cmp    %rdi,%r11
 29de06d:	cmova  %r9,%r8
 29de071:	shl    $0x2,%ecx
 29de074:	lea    0x14(%rcx),%edi
 29de077:	sub    %edi,%r10d
 29de07a:	sub    %r10,%r8
 29de07d:	mov    (%r8),%ecx
 29de080:	test   %ecx,%ecx
 29de082:	jne    29de0d4 <wasm[0]::function[1013]::helper::array_indexed_publish+0x37b4>
 29de088:	mov    0x70(%rsp),%rcx
 29de08d:	mov    0x70(%rsp),%r12
 29de092:	test   %ecx,%r12d
 29de095:	je     29dfd07 <wasm[0]::function[1013]::helper::array_indexed_publish+0x53e7>
 29de09b:	test   %ecx,%r12d
 29de09e:	je     29dfd09 <wasm[0]::function[1013]::helper::array_indexed_publish+0x53e9>
 29de0a4:	mov    0xd0(%rsp),%r15
 29de0ac:	mov    0x28(%r15),%r9
 29de0b0:	mov    0xb0(%rsp),%r13
 29de0b8:	lea    0x1(%r13),%r8
 29de0bc:	mov    %r12d,%r11d
 29de0bf:	mov    %r11,%r10
 29de0c2:	add    0x20(%r15),%r10
 29de0c6:	xor    %rbx,%rbx
 29de0c9:	cmp    %r9,%r11
 29de0cc:	cmova  %rbx,%r10
 29de0d0:	mov    %r8,0x18(%r10)
 29de0d4:	test   %edx,%edx
 29de0d6:	je     29dfd0b <wasm[0]::function[1013]::helper::array_indexed_publish+0x53eb>
 29de0dc:	mov    0xd0(%rsp),%r15
 29de0e4:	mov    0x28(%r15),%r8
 29de0e8:	mov    0x20(%r15),%r10
 29de0ec:	lea    0x10(%r10,%rax,1),%r11
 29de0f1:	xor    %r9,%r9
 29de0f4:	cmp    %r8,%rax
 29de0f7:	cmova  %r9,%r11
 29de0fb:	mov    (%r11),%eax
 29de0fe:	mov    0x68(%rsp),%rcx
 29de103:	cmp    %eax,%ecx
 29de105:	jae    29dfd0d <wasm[0]::function[1013]::helper::array_indexed_publish+0x53ed>
 29de10b:	mov    %eax,%r11d
 29de10e:	shl    $0x2,%r11
 29de112:	shr    $0x20,%r11
 29de116:	test   %r11,%r11
 29de119:	jne    29dfd0f <wasm[0]::function[1013]::helper::array_indexed_publish+0x53ef>
 29de11f:	shl    $0x2,%eax
 29de122:	add    $0x14,%eax
 29de125:	jb     29dfd11 <wasm[0]::function[1013]::helper::array_indexed_publish+0x53f1>
 29de12b:	add    %eax,%esi
 29de12d:	jb     29dfd13 <wasm[0]::function[1013]::helper::array_indexed_publish+0x53f3>
 29de133:	mov    %esi,%r11d
 29de136:	lea    (%r10,%r11,1),%rsi
 29de13a:	cmp    %r8,%r11
 29de13d:	cmova  %r9,%rsi
 29de141:	sub    %edi,%eax
 29de143:	sub    %rax,%rsi
 29de146:	mov    %edx,(%rsi)
 29de148:	mov    $0x1,%r10d
 29de14e:	mov    0x70(%rsp),%r12
 29de153:	mov    %r12d,0x28(%rsp)
 29de158:	mov    %edx,(%rsp)
 29de15b:	test   %r10d,%r10d
 29de15e:	jne    29def60 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4640>
 29de164:	mov    0x70(%rsp),%rax
 29de169:	mov    0x70(%rsp),%r12
 29de16e:	test   %eax,%r12d
 29de171:	je     29dfd15 <wasm[0]::function[1013]::helper::array_indexed_publish+0x53f5>
 29de177:	test   %eax,%r12d
 29de17a:	je     29dfd17 <wasm[0]::function[1013]::helper::array_indexed_publish+0x53f7>
 29de180:	mov    0xd0(%rsp),%r15
 29de188:	mov    0x28(%r15),%rax
 29de18c:	mov    0x20(%r15),%rdi
 29de190:	mov    %r12d,%r9d
 29de193:	lea    (%rdi,%r9,1),%rsi
 29de197:	xor    %r8,%r8
 29de19a:	cmp    %rax,%r9
 29de19d:	cmova  %r8,%rsi
 29de1a1:	mov    0x10(%rsi),%esi
 29de1a4:	test   %esi,%esi
 29de1a6:	je     29dfd19 <wasm[0]::function[1013]::helper::array_indexed_publish+0x53f9>
 29de1ac:	test   %esi,%esi
 29de1ae:	je     29dfd1b <wasm[0]::function[1013]::helper::array_indexed_publish+0x53fb>
 29de1b4:	mov    %esi,%r9d
 29de1b7:	lea    0x10(%rdi,%r9,1),%rdi
 29de1bc:	cmp    %rax,%r9
 29de1bf:	cmova  %r8,%rdi
 29de1c3:	mov    (%rdi),%edi
 29de1c5:	test   %edi,%edi
 29de1c7:	je     29de1da <wasm[0]::function[1013]::helper::array_indexed_publish+0x38ba>
 29de1cd:	mov    %rdi,0x80(%rsp)
 29de1d5:	jmp    29de63f <wasm[0]::function[1013]::helper::array_indexed_publish+0x3d1f>
 29de1da:	mov    0x28(%rsp),%eax
 29de1de:	test   %eax,%eax
 29de1e0:	je     29dfd1d <wasm[0]::function[1013]::helper::array_indexed_publish+0x53fd>
 29de1e6:	test   %eax,%eax
 29de1e8:	je     29dfd1f <wasm[0]::function[1013]::helper::array_indexed_publish+0x53ff>
 29de1ee:	mov    0xd0(%rsp),%r15
 29de1f6:	mov    0x28(%r15),%rcx
 29de1fa:	mov    %eax,%edx
 29de1fc:	mov    %rdx,%rax
 29de1ff:	add    0x20(%r15),%rax
 29de203:	xor    %rsi,%rsi
 29de206:	cmp    %rcx,%rdx
 29de209:	cmova  %rsi,%rax
 29de20d:	mov    0x10(%rax),%eax
 29de210:	mov    %eax,0x10(%rsp)
 29de214:	mov    0x60(%rsp),%rdi
 29de219:	mov    0x20(%rdi),%rdx
 29de21d:	mov    (%rdx),%eax
 29de21f:	mov    %eax,%ecx
 29de221:	lea    0x40(%rcx),%rsi
 29de225:	mov    0x4(%rdx),%edi
 29de228:	cmp    %rdi,%rsi
 29de22b:	ja     29df8a1 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4f81>
 29de231:	lea    0x40(%rax),%esi
 29de234:	mov    %esi,(%rdx)
 29de236:	mov    0xd0(%rsp),%r15
 29de23e:	mov    0x20(%r15),%rsi
 29de242:	lea    (%rsi,%rcx,1),%rdx
 29de246:	movl   $0xa800000e,(%rsi,%rcx,1)
 29de24d:	mov    0x60(%rsp),%rdi
 29de252:	mov    0x28(%rdi),%rdi
 29de256:	mov    0x1ac(%rdi),%edi
 29de25c:	mov    %edi,0x4(%rsi,%rcx,1)
 29de260:	mov    $0x40,%edi
 29de265:	mov    %edi,0x8(%rsi,%rcx,1)
 29de269:	mov    %eax,0x18(%rsp)
 29de26d:	mov    $0x8,%edi
 29de272:	mov    %rdi,0x80(%rsp)
 29de27a:	movl   $0x8,0x10(%rdx)
 29de281:	test   %eax,%eax
 29de283:	je     29dfd21 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5401>
 29de289:	mov    0xd0(%rsp),%r15
 29de291:	mov    0x28(%r15),%rcx
 29de295:	mov    0x20(%r15),%r13
 29de299:	mov    %eax,%r12d
 29de29c:	lea    0x10(%r13,%r12,1),%rax
 29de2a1:	xor    %rdx,%rdx
 29de2a4:	cmp    %rcx,%r12
 29de2a7:	cmova  %rdx,%rax
 29de2ab:	mov    (%rax),%eax
 29de2ad:	cmp    $0x8,%rax
 29de2b1:	jb     29dfd23 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5403>
 29de2b7:	lea    0x14(%r13,%r12,1),%rbx
 29de2bc:	mov    %rbx,%rax
 29de2bf:	add    $0x20,%rax
 29de2c3:	jb     29dfd25 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5405>
 29de2c9:	add    %r13,%rcx
 29de2cc:	cmp    %rcx,%rax
 29de2cf:	ja     29dfd27 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5407>
 29de2d5:	mov    0x10(%rsp),%ecx
 29de2d9:	mov    0x28(%rsp),%edx
 29de2dd:	mov    (%rsp),%esi
 29de2e0:	mov    %ecx,(%rsp)
 29de2e3:	mov    %edx,0x28(%rsp)
 29de2e7:	mov    %esi,0x10(%rsp)
 29de2eb:	mov    0xd8(%rsp),%rax
 29de2f3:	mov    (%rax),%rax
 29de2f6:	mov    0xa8(%rsp),%rcx
 29de2fe:	cmp    %rcx,%rax
 29de301:	jae    29df8d8 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4fb8>
 29de307:	movl   $0x0,(%rbx)
 29de30d:	mov    (%rsp),%ecx
 29de310:	mov    0x28(%rsp),%edx
 29de314:	mov    0x10(%rsp),%esi
 29de318:	lea    0x30(%r13,%r12,1),%r8
 29de31d:	lea    0x4(%rbx),%rdi
 29de321:	cmp    %r8,%rbx
 29de324:	je     29de332 <wasm[0]::function[1013]::helper::array_indexed_publish+0x3a12>
 29de32a:	mov    %rdi,%rbx
 29de32d:	jmp    29de2e0 <wasm[0]::function[1013]::helper::array_indexed_publish+0x39c0>
 29de332:	xor    %r12d,%r12d
 29de335:	test   %ecx,%ecx
 29de337:	je     29dfd29 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5409>
 29de33d:	test   %ecx,%ecx
 29de33f:	je     29dfd2b <wasm[0]::function[1013]::helper::array_indexed_publish+0x540b>
 29de345:	mov    0xd0(%rsp),%r15
 29de34d:	mov    0x28(%r15),%r10
 29de351:	mov    0x20(%r15),%rdi
 29de355:	mov    %ecx,%r11d
 29de358:	lea    0x10(%rdi,%r11,1),%rdi
 29de35d:	xor    %r8,%r8
 29de360:	cmp    %r10,%r11
 29de363:	cmova  %r8,%rdi
 29de367:	mov    (%rdi),%r11d
 29de36a:	mov    %r11,0x98(%rsp)
 29de372:	mov    %ecx,0x10(%rsp)
 29de376:	mov    %edx,0x28(%rsp)
 29de37a:	mov    %esi,(%rsp)
 29de37d:	mov    0xd8(%rsp),%rax
 29de385:	mov    (%rax),%rcx
 29de388:	mov    0xa8(%rsp),%rax
 29de390:	cmp    %rax,%rcx
 29de393:	jae    29df90c <wasm[0]::function[1013]::helper::array_indexed_publish+0x4fec>
 29de399:	mov    0x98(%rsp),%rax
 29de3a1:	jmp    29de3ae <wasm[0]::function[1013]::helper::array_indexed_publish+0x3a8e>
 29de3a6:	mov    0x98(%rsp),%rax
 29de3ae:	cmp    %eax,%r12d
 29de3b1:	mov    %rax,0x98(%rsp)
 29de3b9:	jae    29de5e9 <wasm[0]::function[1013]::helper::array_indexed_publish+0x3cc9>
 29de3bf:	mov    0x10(%rsp),%r10d
 29de3c4:	test   %r10d,%r10d
 29de3c7:	je     29dfd2d <wasm[0]::function[1013]::helper::array_indexed_publish+0x540d>
 29de3cd:	test   %r10d,%r10d
 29de3d0:	je     29dfd2f <wasm[0]::function[1013]::helper::array_indexed_publish+0x540f>
 29de3d6:	mov    0xd0(%rsp),%r15
 29de3de:	mov    0x28(%r15),%rcx
 29de3e2:	mov    0x20(%r15),%rdx
 29de3e6:	mov    %r10d,%r8d
 29de3e9:	lea    0x10(%rdx,%r8,1),%rdi
 29de3ee:	xor    %rsi,%rsi
 29de3f1:	cmp    %rcx,%r8
 29de3f4:	cmova  %rsi,%rdi
 29de3f8:	mov    (%rdi),%edi
 29de3fa:	cmp    %edi,%r12d
 29de3fd:	jae    29dfd31 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5411>
 29de403:	mov    %edi,%r8d
 29de406:	shl    $0x2,%r8
 29de40a:	shr    $0x20,%r8
 29de40e:	test   %r8,%r8
 29de411:	jne    29dfd33 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5413>
 29de417:	shl    $0x2,%edi
 29de41a:	add    $0x14,%edi
 29de41d:	jb     29dfd35 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5415>
 29de423:	mov    %r10,%r8
 29de426:	add    %edi,%r8d
 29de429:	jb     29dfd37 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5417>
 29de42f:	mov    %r8d,%r8d
 29de432:	add    %r8,%rdx
 29de435:	cmp    %rcx,%r8
 29de438:	cmova  %rsi,%rdx
 29de43c:	mov    %r12,%rax
 29de43f:	shl    $0x2,%eax
 29de442:	lea    0x14(%rax),%ecx
 29de445:	sub    %ecx,%edi
 29de447:	sub    %rdi,%rdx
 29de44a:	mov    (%rdx),%edx
 29de44c:	mov    0x28(%rsp),%ecx
 29de450:	mov    (%rsp),%esi
 29de453:	mov    %edx,0x30(%rsp)
 29de457:	mov    %r10d,0x8(%rsp)
 29de45c:	mov    %ecx,0x20(%rsp)
 29de460:	mov    %esi,0x10(%rsp)
 29de464:	mov    0xd8(%rsp),%rax
 29de46c:	mov    (%rax),%rcx
 29de46f:	mov    0xa8(%rsp),%rax
 29de477:	cmp    %rax,%rcx
 29de47a:	jae    29df948 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5028>
 29de480:	mov    0x30(%rsp),%eax
 29de484:	test   %eax,%eax
 29de486:	je     29de5d1 <wasm[0]::function[1013]::helper::array_indexed_publish+0x3cb1>
 29de48c:	mov    0x30(%rsp),%ecx
 29de490:	test   %ecx,%ecx
 29de492:	je     29dfd39 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5419>
 29de498:	mov    0xd0(%rsp),%r15
 29de4a0:	mov    0x28(%r15),%rsi
 29de4a4:	mov    0x20(%r15),%rdi
 29de4a8:	mov    %ecx,%edx
 29de4aa:	lea    (%rdi,%rdx,1),%r10
 29de4ae:	xor    %r8,%r8
 29de4b1:	cmp    %rsi,%rdx
 29de4b4:	cmova  %r8,%r10
 29de4b8:	mov    0x1c(%r10),%edx
 29de4bc:	mov    0x10(%r10),%r13
 29de4c0:	mov    0x18(%rsp),%r9d
 29de4c5:	test   %r9d,%r9d
 29de4c8:	je     29dfd3b <wasm[0]::function[1013]::helper::array_indexed_publish+0x541b>
 29de4ce:	test   %r9d,%r9d
 29de4d1:	je     29dfd3d <wasm[0]::function[1013]::helper::array_indexed_publish+0x541d>
 29de4d7:	mov    %r9d,%ebx
 29de4da:	lea    0x10(%rdi,%rbx,1),%r11
 29de4df:	cmp    %rsi,%rbx
 29de4e2:	cmova  %r8,%r11
 29de4e6:	mov    (%r11),%ebx
 29de4e9:	mov    %r13,%r14
 29de4ec:	shr    $0x10,%r14d
 29de4f0:	xor    %r14d,%r13d
 29de4f3:	imul   $0x7feb352d,%r13d,%r13d
 29de4fa:	mov    %r13,%r14
 29de4fd:	shr    $0xf,%r14d
 29de501:	xor    %r14d,%r13d
 29de504:	imul   $0x846ca68b,%r13d,%r13d
 29de50b:	mov    %r13,%r14
 29de50e:	shr    $0x10,%r14d
 29de512:	xor    %r14d,%r13d
 29de515:	and    $0x7,%r13d
 29de519:	cmp    %ebx,%r13d
 29de51c:	jae    29dfd3f <wasm[0]::function[1013]::helper::array_indexed_publish+0x541f>
 29de522:	mov    %ebx,%r14d
 29de525:	shl    $0x2,%r14
 29de529:	shr    $0x20,%r14
 29de52d:	test   %r14,%r14
 29de530:	jne    29dfd41 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5421>
 29de536:	shl    $0x2,%ebx
 29de539:	add    $0x14,%ebx
 29de53c:	jb     29dfd43 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5423>
 29de542:	mov    %r9,%r14
 29de545:	add    %ebx,%r14d
 29de548:	jb     29dfd45 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5425>
 29de54e:	mov    %r14d,%r14d
 29de551:	lea    (%rdi,%r14,1),%r15
 29de555:	cmp    %rsi,%r14
 29de558:	cmova  %r8,%r15
 29de55c:	mov    %r13,%rax
 29de55f:	shl    $0x2,%eax
 29de562:	lea    0x14(%rax),%r14d
 29de566:	sub    %r14d,%ebx
 29de569:	sub    %rbx,%r15
 29de56c:	mov    (%r15),%eax
 29de56f:	mov    %eax,0x1c(%r10)
 29de573:	mov    (%r11),%r10d
 29de576:	cmp    %r10d,%r13d
 29de579:	jae    29dfd47 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5427>
 29de57f:	mov    %r10d,%r11d
 29de582:	shl    $0x2,%r11
 29de586:	shr    $0x20,%r11
 29de58a:	test   %r11,%r11
 29de58d:	jne    29dfd49 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5429>
 29de593:	shl    $0x2,%r10d
 29de597:	add    $0x14,%r10d
 29de59b:	jb     29dfd4b <wasm[0]::function[1013]::helper::array_indexed_publish+0x542b>
 29de5a1:	add    %r10d,%r9d
 29de5a4:	jb     29dfd4d <wasm[0]::function[1013]::helper::array_indexed_publish+0x542d>
 29de5aa:	mov    %r9d,%r9d
 29de5ad:	add    %r9,%rdi
 29de5b0:	cmp    %rsi,%r9
 29de5b3:	cmova  %r8,%rdi
 29de5b7:	sub    %r14d,%r10d
 29de5ba:	sub    %r10,%rdi
 29de5bd:	mov    %ecx,(%rdi)
 29de5bf:	mov    0x8(%rsp),%r10d
 29de5c4:	mov    0x20(%rsp),%ecx
 29de5c8:	mov    0x10(%rsp),%esi
 29de5cc:	jmp    29de453 <wasm[0]::function[1013]::helper::array_indexed_publish+0x3b33>
 29de5d1:	mov    0x8(%rsp),%ecx
 29de5d5:	mov    0x20(%rsp),%edx
 29de5d9:	mov    0x10(%rsp),%esi
 29de5dd:	add    $0x1,%r12d
 29de5e4:	jmp    29de372 <wasm[0]::function[1013]::helper::array_indexed_publish+0x3a52>
 29de5e9:	mov    0x28(%rsp),%r12d
 29de5ee:	mov    %r12,%rax
 29de5f1:	mov    %r12,0x70(%rsp)
 29de5f6:	test   %eax,%r12d
 29de5f9:	je     29dfd4f <wasm[0]::function[1013]::helper::array_indexed_publish+0x542f>
 29de5ff:	mov    0x18(%rsp),%esi
 29de603:	test   %esi,%esi
 29de605:	je     29dfd51 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5431>
 29de60b:	mov    0x70(%rsp),%rdi
 29de610:	test   %edi,%r12d
 29de613:	je     29dfd53 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5433>
 29de619:	mov    0xd0(%rsp),%r15
 29de621:	mov    0x28(%r15),%rax
 29de625:	mov    %r12d,%edi
 29de628:	mov    %rdi,%rdx
 29de62b:	add    0x20(%r15),%rdx
 29de62f:	xor    %r8,%r8
 29de632:	cmp    %rax,%rdi
 29de635:	cmova  %r8,%rdx
 29de639:	mov    %esi,0x10(%rdx)
 29de63c:	mov    (%rsp),%edx
 29de63f:	mov    %edx,(%rsp)
 29de642:	test   %esi,%esi
 29de644:	je     29dfd55 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5435>
 29de64a:	test   %esi,%esi
 29de64c:	je     29dfd57 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5437>
 29de652:	mov    0xd0(%rsp),%r15
 29de65a:	mov    0x28(%r15),%rax
 29de65e:	mov    0x20(%r15),%rdx
 29de662:	mov    %esi,%r9d
 29de665:	lea    0x10(%rdx,%r9,1),%r8
 29de66a:	xor    %rdi,%rdi
 29de66d:	cmp    %rax,%r9
 29de670:	cmova  %rdi,%r8
 29de674:	mov    (%r8),%r8d
 29de677:	mov    $0x10,%ecx
 29de67c:	mov    %rcx,0x98(%rsp)
 29de684:	mov    0x68(%rsp),%rcx
 29de689:	mov    %rcx,%r9
 29de68c:	shr    $0x10,%r9d
 29de690:	xor    %r9d,%ecx
 29de693:	imul   $0x7feb352d,%ecx,%r9d
 29de69a:	mov    %r9,%r10
 29de69d:	shr    $0xf,%r10d
 29de6a1:	xor    %r10d,%r9d
 29de6a4:	imul   $0x846ca68b,%r9d,%r13d
 29de6ab:	mov    %r13,%r9
 29de6ae:	shr    $0x10,%r9d
 29de6b2:	xor    %r9d,%r13d
 29de6b5:	mov    0x80(%rsp),%r10
 29de6bd:	mov    %r10,%r9
 29de6c0:	sub    $0x1,%r9d
 29de6c4:	mov    %r13,%r12
 29de6c7:	and    %r9d,%r12d
 29de6ca:	mov    %r13,0x78(%rsp)
 29de6cf:	cmp    %r8d,%r12d
 29de6d2:	jae    29dfd59 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5439>
 29de6d8:	mov    %r8d,%r9d
 29de6db:	shl    $0x2,%r9
 29de6df:	mov    $0x20,%r14d
 29de6e5:	mov    %r14,0x90(%rsp)
 29de6ed:	shr    $0x20,%r9
 29de6f1:	test   %r9,%r9
 29de6f4:	jne    29dfd5b <wasm[0]::function[1013]::helper::array_indexed_publish+0x543b>
 29de6fa:	shl    $0x2,%r8d
 29de6fe:	add    $0x14,%r8d
 29de702:	jb     29dfd5d <wasm[0]::function[1013]::helper::array_indexed_publish+0x543d>
 29de708:	mov    %rsi,%r9
 29de70b:	add    %r8d,%r9d
 29de70e:	jb     29dfd5f <wasm[0]::function[1013]::helper::array_indexed_publish+0x543f>
 29de714:	mov    %r9d,%r9d
 29de717:	add    %r9,%rdx
 29de71a:	cmp    %rax,%r9
 29de71d:	cmova  %rdi,%rdx
 29de721:	mov    %r12,%rax
 29de724:	shl    $0x2,%eax
 29de727:	add    $0x14,%eax
 29de72d:	sub    %eax,%r8d
 29de730:	sub    %r8,%rdx
 29de733:	mov    (%rdx),%eax
 29de735:	mov    %eax,0x8(%rsp)
 29de739:	mov    0x70(%rsp),%rdi
 29de73e:	mov    %edi,0x18(%rsp)
 29de742:	mov    %esi,0x28(%rsp)
 29de746:	mov    0xd8(%rsp),%rax
 29de74e:	mov    (%rax),%rax
 29de751:	mov    0xa8(%rsp),%rcx
 29de759:	cmp    %rcx,%rax
 29de75c:	jae    29df97c <wasm[0]::function[1013]::helper::array_indexed_publish+0x505c>
 29de762:	mov    0x8(%rsp),%eax
 29de766:	test   %eax,%eax
 29de768:	je     29de829 <wasm[0]::function[1013]::helper::array_indexed_publish+0x3f09>
 29de76e:	mov    0x8(%rsp),%ecx
 29de772:	test   %ecx,%ecx
 29de774:	je     29dfd61 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5441>
 29de77a:	mov    0xd0(%rsp),%r15
 29de782:	mov    0x28(%r15),%rax
 29de786:	mov    %ecx,%edx
 29de788:	mov    %rdx,%rcx
 29de78b:	add    0x20(%r15),%rcx
 29de78f:	xor    %rsi,%rsi
 29de792:	cmp    %rax,%rdx
 29de795:	cmova  %rsi,%rcx
 29de799:	mov    0x10(%rcx),%rax
 29de79d:	mov    0x68(%rsp),%rcx
 29de7a2:	cmp    %rcx,%rax
 29de7a5:	je     29de7eb <wasm[0]::function[1013]::helper::array_indexed_publish+0x3ecb>
 29de7ab:	mov    0x8(%rsp),%ecx
 29de7af:	test   %ecx,%ecx
 29de7b1:	je     29dfd63 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5443>
 29de7b7:	mov    0xd0(%rsp),%r15
 29de7bf:	mov    0x28(%r15),%rax
 29de7c3:	mov    %ecx,%edx
 29de7c5:	mov    %rdx,%rcx
 29de7c8:	add    0x20(%r15),%rcx
 29de7cc:	xor    %rsi,%rsi
 29de7cf:	cmp    %rax,%rdx
 29de7d2:	cmova  %rsi,%rcx
 29de7d6:	mov    0x1c(%rcx),%eax
 29de7d9:	mov    0x18(%rsp),%ecx
 29de7dd:	mov    %rcx,0x70(%rsp)
 29de7e2:	mov    0x28(%rsp),%esi
 29de7e6:	jmp    29de735 <wasm[0]::function[1013]::helper::array_indexed_publish+0x3e15>
 29de7eb:	mov    (%rsp),%eax
 29de7ee:	test   %eax,%eax
 29de7f0:	je     29dfd65 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5445>
 29de7f6:	mov    0x8(%rsp),%edx
 29de7fa:	test   %edx,%edx
 29de7fc:	je     29dfd67 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5447>
 29de802:	mov    0xd0(%rsp),%r15
 29de80a:	mov    0x28(%r15),%rcx
 29de80e:	mov    %edx,%esi
 29de810:	mov    %rsi,%rdx
 29de813:	add    0x20(%r15),%rdx
 29de817:	xor    %rdi,%rdi
 29de81a:	cmp    %rcx,%rsi
 29de81d:	cmova  %rdi,%rdx
 29de821:	mov    %eax,0x18(%rdx)
 29de824:	jmp    29def60 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4640>
 29de829:	mov    0x18(%rsp),%ecx
 29de82d:	test   %ecx,%ecx
 29de82f:	je     29dfd69 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5449>
 29de835:	test   %ecx,%ecx
 29de837:	je     29dfd6b <wasm[0]::function[1013]::helper::array_indexed_publish+0x544b>
 29de83d:	mov    0xd0(%rsp),%r15
 29de845:	mov    0x28(%r15),%rsi
 29de849:	mov    0x20(%r15),%r8
 29de84d:	mov    %ecx,%edi
 29de84f:	lea    (%r8,%rdi,1),%rdx
 29de853:	xor    %r8,%r8
 29de856:	cmp    %rsi,%rdi
 29de859:	cmova  %r8,%rdx
 29de85d:	mov    0x18(%rdx),%rsi
 29de861:	mov    0x28(%rsp),%edi
 29de865:	mov    (%rsp),%eax
 29de868:	lea    0x1(%rsi),%r8
 29de86c:	mov    %rsi,0x88(%rsp)
 29de874:	shl    $0x2,%r8
 29de878:	mov    0x80(%rsp),%rdx
 29de880:	mov    %edx,%esi
 29de882:	imul   $0x3,%rsi,%rsi
 29de886:	cmp    %rsi,%r8
 29de889:	ja     29de897 <wasm[0]::function[1013]::helper::array_indexed_publish+0x3f77>
 29de88f:	mov    %r12,%r13
 29de892:	jmp    29ded87 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4467>
 29de897:	mov    0x80(%rsp),%rcx
 29de89f:	cmp    $0x80000000,%ecx
 29de8a5:	jae    29dfd6d <wasm[0]::function[1013]::helper::array_indexed_publish+0x544d>
 29de8ab:	mov    0x18(%rsp),%eax
 29de8af:	test   %eax,%eax
 29de8b1:	je     29dfd6f <wasm[0]::function[1013]::helper::array_indexed_publish+0x544f>
 29de8b7:	test   %eax,%eax
 29de8b9:	je     29dfd71 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5451>
 29de8bf:	mov    0xd0(%rsp),%r15
 29de8c7:	mov    0x28(%r15),%rcx
 29de8cb:	mov    %eax,%edx
 29de8cd:	mov    %rdx,%rax
 29de8d0:	add    0x20(%r15),%rax
 29de8d4:	xor    %rsi,%rsi
 29de8d7:	cmp    %rcx,%rdx
 29de8da:	cmova  %rsi,%rax
 29de8de:	mov    0x10(%rax),%eax
 29de8e1:	mov    %eax,0x28(%rsp)
 29de8e5:	mov    0x80(%rsp),%rcx
 29de8ed:	mov    %rcx,%r15
 29de8f0:	shl    $1,%r15d
 29de8f3:	mov    %r15,%rbx
 29de8f6:	shl    $0x2,%rbx
 29de8fa:	mov    %rbx,%rax
 29de8fd:	shr    $0x20,%rax
 29de901:	test   %rax,%rax
 29de904:	jne    29dfd73 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5453>
 29de90a:	shl    $0x3,%ecx
 29de90d:	mov    %rcx,0x80(%rsp)
 29de915:	add    $0x14,%ecx
 29de918:	mov    %rcx,0x80(%rsp)
 29de920:	jb     29dfd75 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5455>
 29de926:	mov    0x60(%rsp),%rdi
 29de92b:	mov    0x20(%rdi),%rdx
 29de92f:	mov    (%rdx),%eax
 29de931:	mov    %eax,%ecx
 29de933:	mov    0x80(%rsp),%rsi
 29de93b:	mov    %esi,%esi
 29de93d:	add    $0xf,%rsi
 29de944:	mov    %rsi,%rdi
 29de947:	and    $0xfffffffffffffff0,%rdi
 29de94b:	add    %rcx,%rdi
 29de94e:	mov    0x4(%rdx),%r8d
 29de952:	cmp    %r8,%rdi
 29de955:	ja     29df9b0 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5090>
 29de95b:	mov    0x80(%rsp),%r9
 29de963:	lea    0xf(%r9),%edi
 29de967:	and    $0xfffffff0,%edi
 29de96a:	add    %eax,%edi
 29de96c:	mov    %edi,(%rdx)
 29de96e:	mov    0xd0(%rsp),%rdx
 29de976:	mov    0x20(%rdx),%rdi
 29de97a:	lea    (%rdi,%rcx,1),%rdx
 29de97e:	movl   $0xa800000e,(%rdi,%rcx,1)
 29de985:	mov    0x60(%rsp),%r8
 29de98a:	mov    0x28(%r8),%r8
 29de98e:	mov    0x1ac(%r8),%r8d
 29de995:	mov    %r8d,0x4(%rdi,%rcx,1)
 29de99a:	and    $0xfffffffffffffff0,%rsi
 29de99e:	mov    %esi,0x8(%rdi,%rcx,1)
 29de9a2:	mov    %eax,0x8(%rsp)
 29de9a6:	mov    %r15d,0x10(%rdx)
 29de9aa:	test   %eax,%eax
 29de9ac:	je     29dfd77 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5457>
 29de9b2:	mov    0xd0(%rsp),%rcx
 29de9ba:	mov    0x28(%rcx),%rcx
 29de9be:	mov    0xd0(%rsp),%rdx
 29de9c6:	mov    0x20(%rdx),%rdx
 29de9ca:	mov    %eax,%eax
 29de9cc:	lea    (%rdx,%rax,1),%rsi
 29de9d0:	lea    0x10(%rdx,%rax,1),%rdi
 29de9d5:	xor    %r8,%r8
 29de9d8:	cmp    %rcx,%rax
 29de9db:	cmova  %r8,%rdi
 29de9df:	mov    (%rdi),%edi
 29de9e1:	cmp    %rdi,%r15
 29de9e4:	ja     29dfd79 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5459>
 29de9ea:	lea    0x14(%rdx,%rax,1),%r12
 29de9ef:	mov    %r12,%rax
 29de9f2:	add    %rbx,%rax
 29de9f5:	jb     29dfd7b <wasm[0]::function[1013]::helper::array_indexed_publish+0x545b>
 29de9fb:	add    %rdx,%rcx
 29de9fe:	cmp    %rcx,%rax
 29dea01:	ja     29dfd7d <wasm[0]::function[1013]::helper::array_indexed_publish+0x545d>
 29dea07:	mov    0x28(%rsp),%eax
 29dea0b:	mov    0x18(%rsp),%ecx
 29dea0f:	mov    (%rsp),%edx
 29dea12:	lea    0x14(%rsi,%r15,4),%rbx
 29dea17:	test   %r15,%r15
 29dea1a:	je     29dea6a <wasm[0]::function[1013]::helper::array_indexed_publish+0x414a>
 29dea20:	mov    %eax,(%rsp)
 29dea23:	mov    %ecx,0x18(%rsp)
 29dea27:	mov    %edx,0x28(%rsp)
 29dea2b:	mov    0xd8(%rsp),%rax
 29dea33:	mov    (%rax),%rax
 29dea36:	mov    0xa8(%rsp),%rcx
 29dea3e:	cmp    %rcx,%rax
 29dea41:	jae    29df9ec <wasm[0]::function[1013]::helper::array_indexed_publish+0x50cc>
 29dea47:	movl   $0x0,(%r12)
 29dea4f:	mov    (%rsp),%eax
 29dea52:	mov    0x18(%rsp),%ecx
 29dea56:	mov    0x28(%rsp),%edx
 29dea5a:	add    $0x4,%r12
 29dea61:	cmp    %rbx,%r12
 29dea64:	jne    29dea20 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4100>
 29dea6a:	xor    %r12d,%r12d
 29dea6d:	test   %eax,%eax
 29dea6f:	je     29dfd7f <wasm[0]::function[1013]::helper::array_indexed_publish+0x545f>
 29dea75:	test   %eax,%eax
 29dea77:	je     29dfd81 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5461>
 29dea7d:	mov    0xd0(%rsp),%rsi
 29dea85:	mov    0x28(%rsi),%rsi
 29dea89:	mov    0xd0(%rsp),%rdi
 29dea91:	mov    0x20(%rdi),%rdi
 29dea95:	mov    %eax,%r8d
 29dea98:	lea    0x10(%rdi,%r8,1),%rdi
 29dea9d:	xor    %r9,%r9
 29deaa0:	cmp    %rsi,%r8
 29deaa3:	cmova  %r9,%rdi
 29deaa7:	mov    (%rdi),%esi
 29deaa9:	mov    %rsi,0x80(%rsp)
 29deab1:	mov    %eax,0x28(%rsp)
 29deab5:	mov    %ecx,0x18(%rsp)
 29deab9:	mov    %edx,(%rsp)
 29deabc:	mov    0xd8(%rsp),%r11
 29deac4:	mov    (%r11),%rsi
 29deac7:	mov    0xa8(%rsp),%rax
 29deacf:	cmp    %rax,%rsi
 29dead2:	jae    29dfa20 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5100>
 29dead8:	mov    0x80(%rsp),%r10
 29deae0:	jmp    29deaed <wasm[0]::function[1013]::helper::array_indexed_publish+0x41cd>
 29deae5:	mov    0x80(%rsp),%r10
 29deaed:	cmp    %r10d,%r12d
 29deaf0:	mov    %r10,0x80(%rsp)
 29deaf8:	jae    29ded35 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4415>
 29deafe:	mov    0x28(%rsp),%eax
 29deb02:	test   %eax,%eax
 29deb04:	je     29dfd83 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5463>
 29deb0a:	test   %eax,%eax
 29deb0c:	je     29dfd85 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5465>
 29deb12:	mov    0xd0(%rsp),%rcx
 29deb1a:	mov    0x28(%rcx),%rcx
 29deb1e:	mov    0xd0(%rsp),%rdx
 29deb26:	mov    0x20(%rdx),%rdx
 29deb2a:	mov    %eax,%r8d
 29deb2d:	lea    0x10(%rdx,%r8,1),%rdi
 29deb32:	xor    %rsi,%rsi
 29deb35:	cmp    %rcx,%r8
 29deb38:	cmova  %rsi,%rdi
 29deb3c:	mov    (%rdi),%edi
 29deb3e:	cmp    %edi,%r12d
 29deb41:	jae    29dfd87 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5467>
 29deb47:	mov    %edi,%r8d
 29deb4a:	shl    $0x2,%r8
 29deb4e:	shr    $0x20,%r8
 29deb52:	test   %r8,%r8
 29deb55:	jne    29dfd89 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5469>
 29deb5b:	shl    $0x2,%edi
 29deb5e:	add    $0x14,%edi
 29deb61:	jb     29dfd8b <wasm[0]::function[1013]::helper::array_indexed_publish+0x546b>
 29deb67:	mov    %rax,%r8
 29deb6a:	add    %edi,%r8d
 29deb6d:	jb     29dfd8d <wasm[0]::function[1013]::helper::array_indexed_publish+0x546d>
 29deb73:	mov    %r8d,%r8d
 29deb76:	add    %r8,%rdx
 29deb79:	cmp    %rcx,%r8
 29deb7c:	cmova  %rsi,%rdx
 29deb80:	mov    %r12,%rcx
 29deb83:	shl    $0x2,%ecx
 29deb86:	add    $0x14,%ecx
 29deb8c:	sub    %ecx,%edi
 29deb8e:	sub    %rdi,%rdx
 29deb91:	mov    (%rdx),%edx
 29deb93:	mov    0x18(%rsp),%ecx
 29deb97:	mov    (%rsp),%esi
 29deb9a:	mov    %edx,0x30(%rsp)
 29deb9e:	mov    %eax,0x10(%rsp)
 29deba2:	mov    %ecx,0x20(%rsp)
 29deba6:	mov    %esi,0x28(%rsp)
 29debaa:	mov    0xd8(%rsp),%rsi
 29debb2:	mov    (%rsi),%rax
 29debb5:	mov    0xa8(%rsp),%rsi
 29debbd:	cmp    %rsi,%rax
 29debc0:	jae    29dfa5c <wasm[0]::function[1013]::helper::array_indexed_publish+0x513c>
 29debc6:	mov    0x30(%rsp),%eax
 29debca:	test   %eax,%eax
 29debcc:	je     29ded1d <wasm[0]::function[1013]::helper::array_indexed_publish+0x43fd>
 29debd2:	mov    0x30(%rsp),%ecx
 29debd6:	test   %ecx,%ecx
 29debd8:	je     29dfd8f <wasm[0]::function[1013]::helper::array_indexed_publish+0x546f>
 29debde:	mov    0xd0(%rsp),%rax
 29debe6:	mov    0x28(%rax),%rsi
 29debea:	mov    0x20(%rax),%rdi
 29debee:	mov    %ecx,%edx
 29debf0:	lea    (%rdi,%rdx,1),%rax
 29debf4:	xor    %r8,%r8
 29debf7:	cmp    %rsi,%rdx
 29debfa:	cmova  %r8,%rax
 29debfe:	mov    0x1c(%rax),%edx
 29dec01:	mov    0x10(%rax),%rbx
 29dec05:	mov    0x8(%rsp),%r9d
 29dec0a:	test   %r9d,%r9d
 29dec0d:	je     29dfd91 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5471>
 29dec13:	test   %r9d,%r9d
 29dec16:	je     29dfd93 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5473>
 29dec1c:	mov    %r9d,%r11d
 29dec1f:	lea    0x10(%rdi,%r11,1),%r10
 29dec24:	cmp    %rsi,%r11
 29dec27:	cmova  %r8,%r10
 29dec2b:	mov    (%r10),%r11d
 29dec2e:	mov    %rbx,%r13
 29dec31:	shr    $0x10,%r13d
 29dec35:	xor    %r13d,%ebx
 29dec38:	imul   $0x7feb352d,%ebx,%ebx
 29dec3e:	mov    %rbx,%r13
 29dec41:	shr    $0xf,%r13d
 29dec45:	xor    %r13d,%ebx
 29dec48:	imul   $0x846ca68b,%ebx,%ebx
 29dec4e:	mov    %rbx,%r13
 29dec51:	shr    $0x10,%r13d
 29dec55:	xor    %r13d,%ebx
 29dec58:	mov    %r15,%r13
 29dec5b:	sub    $0x1,%r13d
 29dec5f:	and    %r13d,%ebx
 29dec62:	cmp    %r11d,%ebx
 29dec65:	jae    29dfd95 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5475>
 29dec6b:	mov    %r11d,%r13d
 29dec6e:	shl    $0x2,%r13
 29dec72:	shr    $0x20,%r13
 29dec76:	test   %r13,%r13
 29dec79:	jne    29dfd97 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5477>
 29dec7f:	shl    $0x2,%r11d
 29dec83:	add    $0x14,%r11d
 29dec87:	jb     29dfd99 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5479>
 29dec8d:	mov    %r9,%r13
 29dec90:	add    %r11d,%r13d
 29dec93:	jb     29dfd9b <wasm[0]::function[1013]::helper::array_indexed_publish+0x547b>
 29dec99:	mov    %r13d,%r14d
 29dec9c:	lea    (%rdi,%r14,1),%r13
 29deca0:	cmp    %rsi,%r14
 29deca3:	cmova  %r8,%r13
 29deca7:	mov    %rbx,%r14
 29decaa:	shl    $0x2,%r14d
 29decae:	add    $0x14,%r14d
 29decb5:	sub    %r14d,%r11d
 29decb8:	sub    %r11,%r13
 29decbb:	mov    0x0(%r13),%r11d
 29decbf:	mov    %r11d,0x1c(%rax)
 29decc3:	mov    (%r10),%eax
 29decc6:	cmp    %eax,%ebx
 29decc8:	jae    29dfd9d <wasm[0]::function[1013]::helper::array_indexed_publish+0x547d>
 29decce:	mov    %eax,%r10d
 29decd1:	shl    $0x2,%r10
 29decd5:	shr    $0x20,%r10
 29decd9:	test   %r10,%r10
 29decdc:	jne    29dfd9f <wasm[0]::function[1013]::helper::array_indexed_publish+0x547f>
 29dece2:	shl    $0x2,%eax
 29dece5:	add    $0x14,%eax
 29dece8:	jb     29dfda1 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5481>
 29decee:	add    %eax,%r9d
 29decf1:	jb     29dfda3 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5483>
 29decf7:	mov    %r9d,%r9d
 29decfa:	add    %r9,%rdi
 29decfd:	cmp    %rsi,%r9
 29ded00:	cmova  %r8,%rdi
 29ded04:	sub    %r14d,%eax
 29ded07:	sub    %rax,%rdi
 29ded0a:	mov    %ecx,(%rdi)
 29ded0c:	mov    0x10(%rsp),%eax
 29ded10:	mov    0x20(%rsp),%ecx
 29ded14:	mov    0x28(%rsp),%esi
 29ded18:	jmp    29deb9a <wasm[0]::function[1013]::helper::array_indexed_publish+0x427a>
 29ded1d:	mov    0x10(%rsp),%eax
 29ded21:	mov    0x20(%rsp),%ecx
 29ded25:	mov    0x28(%rsp),%edx
 29ded29:	add    $0x1,%r12d
 29ded30:	jmp    29deab1 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4191>
 29ded35:	mov    0x18(%rsp),%ecx
 29ded39:	test   %ecx,%ecx
 29ded3b:	je     29dfda5 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5485>
 29ded41:	mov    0x8(%rsp),%edi
 29ded45:	test   %edi,%edi
 29ded47:	je     29dfda7 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5487>
 29ded4d:	test   %ecx,%ecx
 29ded4f:	je     29dfda9 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5489>
 29ded55:	mov    0xd0(%rsp),%rax
 29ded5d:	mov    0x28(%rax),%r8
 29ded61:	mov    %ecx,%r9d
 29ded64:	mov    %r9,%rsi
 29ded67:	add    0x20(%rax),%rsi
 29ded6b:	xor    %r10,%r10
 29ded6e:	cmp    %r8,%r9
 29ded71:	cmova  %r10,%rsi
 29ded75:	mov    %edi,0x10(%rsi)
 29ded78:	mov    (%rsp),%eax
 29ded7b:	sub    $0x1,%r15d
 29ded7f:	mov    0x78(%rsp),%r13
 29ded84:	and    %r15d,%r13d
 29ded87:	mov    %edi,0x8(%rsp)
 29ded8b:	mov    %eax,0x18(%rsp)
 29ded8f:	mov    %ecx,(%rsp)
 29ded92:	test   %edi,%edi
 29ded94:	je     29dfdab <wasm[0]::function[1013]::helper::array_indexed_publish+0x548b>
 29ded9a:	test   %edi,%edi
 29ded9c:	je     29dfdad <wasm[0]::function[1013]::helper::array_indexed_publish+0x548d>
 29deda2:	mov    0xd0(%rsp),%r15
 29dedaa:	mov    0x28(%r15),%rcx
 29dedae:	mov    0x20(%r15),%rdx
 29dedb2:	mov    %edi,%r9d
 29dedb5:	lea    0x10(%rdx,%r9,1),%r8
 29dedba:	xor    %rsi,%rsi
 29dedbd:	cmp    %rcx,%r9
 29dedc0:	cmova  %rsi,%r8
 29dedc4:	mov    (%r8),%r8d
 29dedc7:	cmp    %r8d,%r13d
 29dedca:	jae    29dfdaf <wasm[0]::function[1013]::helper::array_indexed_publish+0x548f>
 29dedd0:	mov    %r8d,%r9d
 29dedd3:	shl    $0x2,%r9
 29dedd7:	shr    $0x20,%r9
 29deddb:	test   %r9,%r9
 29dedde:	jne    29dfdb1 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5491>
 29dede4:	shl    $0x2,%r8d
 29dede8:	add    $0x14,%r8d
 29dedec:	jb     29dfdb3 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5493>
 29dedf2:	add    %r8d,%edi
 29dedf5:	jb     29dfdb5 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5495>
 29dedfb:	mov    %edi,%edi
 29dedfd:	add    %rdi,%rdx
 29dee00:	cmp    %rcx,%rdi
 29dee03:	cmova  %rsi,%rdx
 29dee07:	mov    %r13,%r12
 29dee0a:	shl    $0x2,%r12d
 29dee0e:	lea    0x14(%r12),%ecx
 29dee13:	sub    %ecx,%r8d
 29dee16:	sub    %r8,%rdx
 29dee19:	mov    (%rdx),%ecx
 29dee1b:	mov    %ecx,0x10(%rsp)
 29dee1f:	test   %eax,%eax
 29dee21:	je     29dfdb7 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5497>
 29dee27:	mov    0x60(%rsp),%rdi
 29dee2c:	mov    0x20(%rdi),%rcx
 29dee30:	mov    (%rcx),%eax
 29dee32:	mov    %eax,%edx
 29dee34:	lea    0x20(%rdx),%rsi
 29dee38:	mov    0x4(%rcx),%edi
 29dee3b:	cmp    %rdi,%rsi
 29dee3e:	ja     29dfa93 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5173>
 29dee44:	lea    0x20(%rax),%esi
 29dee47:	mov    %esi,(%rcx)
 29dee49:	mov    0xd0(%rsp),%r15
 29dee51:	mov    0x20(%r15),%rsi
 29dee55:	lea    (%rsi,%rdx,1),%rcx
 29dee59:	movl   $0xb0000062,(%rsi,%rdx,1)
 29dee60:	mov    0x60(%rsp),%rdi
 29dee65:	mov    0x28(%rdi),%rdi
 29dee69:	mov    0x1a8(%rdi),%edi
 29dee6f:	mov    %edi,0x4(%rsi,%rdx,1)
 29dee73:	mov    0x90(%rsp),%r14
 29dee7b:	mov    %r14d,0x8(%rsi,%rdx,1)
 29dee80:	mov    0x68(%rsp),%rdx
 29dee85:	mov    0x68(%rsp),%rdx
 29dee8a:	mov    %rdx,0x10(%rcx)
 29dee8e:	mov    0x18(%rsp),%edx
 29dee92:	mov    %edx,0x18(%rcx)
 29dee95:	mov    0x10(%rsp),%edx
 29dee99:	mov    %edx,0x1c(%rcx)
 29dee9c:	mov    0x8(%rsp),%edi
 29deea0:	test   %edi,%edi
 29deea2:	je     29dfdb9 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5499>
 29deea8:	test   %eax,%eax
 29deeaa:	je     29dfdbb <wasm[0]::function[1013]::helper::array_indexed_publish+0x549b>
 29deeb0:	test   %edi,%edi
 29deeb2:	je     29dfdbd <wasm[0]::function[1013]::helper::array_indexed_publish+0x549d>
 29deeb8:	mov    0xd0(%rsp),%r15
 29deec0:	mov    0x28(%r15),%rcx
 29deec4:	mov    0x20(%r15),%rdx
 29deec8:	mov    %edi,%r9d
 29deecb:	lea    0x10(%rdx,%r9,1),%r8
 29deed0:	xor    %rsi,%rsi
 29deed3:	cmp    %rcx,%r9
 29deed6:	cmova  %rsi,%r8
 29deeda:	mov    (%r8),%r8d
 29deedd:	cmp    %r8d,%r13d
 29deee0:	jae    29dfdbf <wasm[0]::function[1013]::helper::array_indexed_publish+0x549f>
 29deee6:	mov    %r8d,%r9d
 29deee9:	shl    $0x2,%r9
 29deeed:	shr    $0x20,%r9
 29deef1:	test   %r9,%r9
 29deef4:	jne    29dfdc1 <wasm[0]::function[1013]::helper::array_indexed_publish+0x54a1>
 29deefa:	shl    $0x2,%r8d
 29deefe:	add    $0x14,%r8d
 29def02:	jb     29dfdc3 <wasm[0]::function[1013]::helper::array_indexed_publish+0x54a3>
 29def08:	add    %r8d,%edi
 29def0b:	jb     29dfdc5 <wasm[0]::function[1013]::helper::array_indexed_publish+0x54a5>
 29def11:	mov    %edi,%r9d
 29def14:	lea    (%rdx,%r9,1),%rdi
 29def18:	cmp    %rcx,%r9
 29def1b:	cmova  %rsi,%rdi
 29def1f:	lea    0x14(%r12),%r9d
 29def24:	sub    %r9d,%r8d
 29def27:	sub    %r8,%rdi
 29def2a:	mov    %eax,(%rdi)
 29def2c:	mov    (%rsp),%eax
 29def2f:	test   %eax,%eax
 29def31:	je     29dfdc7 <wasm[0]::function[1013]::helper::array_indexed_publish+0x54a7>
 29def37:	test   %eax,%eax
 29def39:	je     29dfdc9 <wasm[0]::function[1013]::helper::array_indexed_publish+0x54a9>
 29def3f:	mov    0x88(%rsp),%rdi
 29def47:	add    $0x1,%rdi
 29def4e:	mov    %eax,%r8d
 29def51:	lea    (%rdx,%r8,1),%rax
 29def55:	cmp    %rcx,%r8
 29def58:	cmova  %rsi,%rax
 29def5c:	mov    %rdi,0x18(%rax)
 29def60:	mov    0xe0(%rsp),%rbx
 29def68:	mov    0xe8(%rsp),%r12
 29def70:	mov    0xf0(%rsp),%r13
 29def78:	mov    0xf8(%rsp),%r14
 29def80:	mov    0x100(%rsp),%r15
 29def88:	add    $0x110,%rsp
 29def8f:	mov    %rbp,%rsp
 29def92:	pop    %rbp
 29def93:	ret
 29def94:	mov    0x60(%rsp),%rdi
 29def99:	call   3018d19 <wasmtime_builtin_new_epoch>
 29def9e:	mov    %rax,0xa8(%rsp)
 29defa6:	mov    0x68(%rsp),%rcx
 29defab:	jmp    29da9ba <wasm[0]::function[1013]::helper::array_indexed_publish+0x9a>
 29defb0:	mov    0xd0(%rsp),%rcx
 29defb8:	mov    0x8(%rcx),%rcx
 29defbc:	mov    %rcx,0xa8(%rsp)
 29defc4:	cmp    %rcx,%rax
 29defc7:	jb     29dae2c <wasm[0]::function[1013]::helper::array_indexed_publish+0x50c>
 29defcd:	mov    0x60(%rsp),%rdi
 29defd2:	call   3018d19 <wasmtime_builtin_new_epoch>
 29defd7:	mov    %rax,0xa8(%rsp)
 29defdf:	jmp    29dae2c <wasm[0]::function[1013]::helper::array_indexed_publish+0x50c>
 29defe4:	mov    $0xa8000006,%esi
 29defe9:	mov    0x60(%rsp),%rdi
 29defee:	mov    0x28(%rdi),%rax
 29deff2:	mov    0x1a0(%rax),%edx
 29deff8:	mov    $0x10,%r8d
 29deffe:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
 29df003:	mov    %eax,%r9d
 29df006:	mov    0xd0(%rsp),%rcx
 29df00e:	add    0x20(%rcx),%r9
 29df012:	jmp    29daf0a <wasm[0]::function[1013]::helper::array_indexed_publish+0x5ea>
 29df017:	mov    0xd0(%rsp),%rcx
 29df01f:	mov    0x8(%rcx),%rcx
 29df023:	mov    %rcx,%rsi
 29df026:	mov    %rcx,0xa8(%rsp)
 29df02e:	cmp    %rsi,%rax
 29df031:	jb     29dafcd <wasm[0]::function[1013]::helper::array_indexed_publish+0x6ad>
 29df037:	mov    0x60(%rsp),%rdi
 29df03c:	call   3018d19 <wasmtime_builtin_new_epoch>
 29df041:	mov    %rax,0xa8(%rsp)
 29df049:	jmp    29dafcd <wasm[0]::function[1013]::helper::array_indexed_publish+0x6ad>
 29df04e:	mov    0xd0(%rsp),%rsi
 29df056:	mov    0x8(%rsi),%rcx
 29df05a:	mov    %rcx,0xa8(%rsp)
 29df062:	cmp    %rcx,%rax
 29df065:	jb     29db05a <wasm[0]::function[1013]::helper::array_indexed_publish+0x73a>
 29df06b:	mov    0x60(%rsp),%rdi
 29df070:	call   3018d19 <wasmtime_builtin_new_epoch>
 29df075:	mov    %rax,0xa8(%rsp)
 29df07d:	jmp    29db05a <wasm[0]::function[1013]::helper::array_indexed_publish+0x73a>
 29df082:	mov    0xd0(%rsp),%rcx
 29df08a:	mov    0x8(%rcx),%rcx
 29df08e:	mov    %rcx,0xa8(%rsp)
 29df096:	cmp    %rcx,%rax
 29df099:	jb     29db1b0 <wasm[0]::function[1013]::helper::array_indexed_publish+0x890>
 29df09f:	mov    0x60(%rsp),%rdi
 29df0a4:	call   3018d19 <wasmtime_builtin_new_epoch>
 29df0a9:	mov    %rax,0xa8(%rsp)
 29df0b1:	jmp    29db1b0 <wasm[0]::function[1013]::helper::array_indexed_publish+0x890>
 29df0b6:	mov    0xd0(%rsp),%rsi
 29df0be:	mov    0x8(%rsi),%rcx
 29df0c2:	mov    %rcx,0xa8(%rsp)
 29df0ca:	cmp    %rcx,%rax
 29df0cd:	jb     29db2a8 <wasm[0]::function[1013]::helper::array_indexed_publish+0x988>
 29df0d3:	mov    0x60(%rsp),%rdi
 29df0d8:	call   3018d19 <wasmtime_builtin_new_epoch>
 29df0dd:	mov    %rax,0xa8(%rsp)
 29df0e5:	jmp    29db2a8 <wasm[0]::function[1013]::helper::array_indexed_publish+0x988>
 29df0ea:	mov    0xd0(%rsp),%rcx
 29df0f2:	mov    0x8(%rcx),%rcx
 29df0f6:	mov    %rcx,0xa8(%rsp)
 29df0fe:	cmp    %rcx,%rax
 29df101:	jb     29db359 <wasm[0]::function[1013]::helper::array_indexed_publish+0xa39>
 29df107:	mov    0x60(%rsp),%rdi
 29df10c:	call   3018d19 <wasmtime_builtin_new_epoch>
 29df111:	mov    %rax,0xa8(%rsp)
 29df119:	mov    %rbx,%rcx
 29df11c:	mov    %r14,%rdx
 29df11f:	mov    0x78(%rsp),%rsi
 29df124:	jmp    29db364 <wasm[0]::function[1013]::helper::array_indexed_publish+0xa44>
 29df129:	mov    $0xa8000006,%esi
 29df12e:	mov    0x60(%rsp),%rdi
 29df133:	mov    0x28(%rdi),%rax
 29df137:	mov    0x1a4(%rax),%edx
 29df13d:	mov    $0x10,%r8d
 29df143:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
 29df148:	mov    %eax,%ecx
 29df14a:	mov    0xd0(%rsp),%r15
 29df152:	add    0x20(%r15),%rcx
 29df156:	jmp    29db412 <wasm[0]::function[1013]::helper::array_indexed_publish+0xaf2>
 29df15b:	mov    0xd0(%rsp),%r15
 29df163:	mov    0x8(%r15),%rax
 29df167:	mov    %rax,0xa8(%rsp)
 29df16f:	cmp    %rax,%r9
 29df172:	jb     29db4ca <wasm[0]::function[1013]::helper::array_indexed_publish+0xbaa>
 29df178:	mov    0x60(%rsp),%rdi
 29df17d:	call   3018d19 <wasmtime_builtin_new_epoch>
 29df182:	mov    %rax,0xa8(%rsp)
 29df18a:	jmp    29db4ca <wasm[0]::function[1013]::helper::array_indexed_publish+0xbaa>
 29df18f:	mov    0xd0(%rsp),%r15
 29df197:	mov    0x8(%r15),%rcx
 29df19b:	mov    %rcx,0xa8(%rsp)
 29df1a3:	cmp    %rcx,%rax
 29df1a6:	jb     29db555 <wasm[0]::function[1013]::helper::array_indexed_publish+0xc35>
 29df1ac:	mov    0x60(%rsp),%rdi
 29df1b1:	call   3018d19 <wasmtime_builtin_new_epoch>
 29df1b6:	mov    %rax,0xa8(%rsp)
 29df1be:	jmp    29db555 <wasm[0]::function[1013]::helper::array_indexed_publish+0xc35>
 29df1c3:	mov    0xd0(%rsp),%r15
 29df1cb:	mov    0x8(%r15),%rax
 29df1cf:	mov    %rax,0xa8(%rsp)
 29df1d7:	cmp    %rax,%rdx
 29df1da:	jb     29db69b <wasm[0]::function[1013]::helper::array_indexed_publish+0xd7b>
 29df1e0:	mov    0x60(%rsp),%rdi
 29df1e5:	call   3018d19 <wasmtime_builtin_new_epoch>
 29df1ea:	mov    %rax,0xa8(%rsp)
 29df1f2:	jmp    29db69b <wasm[0]::function[1013]::helper::array_indexed_publish+0xd7b>
 29df1f7:	mov    0xd0(%rsp),%r15
 29df1ff:	mov    0x8(%r15),%rcx
 29df203:	mov    %rcx,0xa8(%rsp)
 29df20b:	cmp    %rcx,%rax
 29df20e:	jb     29db790 <wasm[0]::function[1013]::helper::array_indexed_publish+0xe70>
 29df214:	mov    0x60(%rsp),%rdi
 29df219:	call   3018d19 <wasmtime_builtin_new_epoch>
 29df21e:	mov    %rax,0xa8(%rsp)
 29df226:	jmp    29db790 <wasm[0]::function[1013]::helper::array_indexed_publish+0xe70>
 29df22b:	mov    0xd0(%rsp),%r15
 29df233:	mov    0x8(%r15),%rcx
 29df237:	mov    %rcx,0xa8(%rsp)
 29df23f:	cmp    %rcx,%rax
 29df242:	jb     29db83f <wasm[0]::function[1013]::helper::array_indexed_publish+0xf1f>
 29df248:	mov    0x60(%rsp),%rdi
 29df24d:	call   3018d19 <wasmtime_builtin_new_epoch>
 29df252:	mov    %rax,0xa8(%rsp)
 29df25a:	mov    %rbx,%rcx
 29df25d:	mov    %r13,%rdx
 29df260:	mov    0x78(%rsp),%rsi
 29df265:	jmp    29db84a <wasm[0]::function[1013]::helper::array_indexed_publish+0xf2a>
 29df26a:	mov    $0xa800000e,%esi
 29df26f:	mov    0x60(%rsp),%rdi
 29df274:	mov    0x28(%rdi),%rax
 29df278:	mov    0x19c(%rax),%edx
 29df27e:	mov    $0x10,%r8d
 29df284:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
 29df289:	mov    %eax,%ecx
 29df28b:	mov    0xd0(%rsp),%r15
 29df293:	add    0x20(%r15),%rcx
 29df297:	jmp    29dbd3a <wasm[0]::function[1013]::helper::array_indexed_publish+0x141a>
 29df29c:	mov    0xd0(%rsp),%r15
 29df2a4:	mov    0x8(%r15),%rax
 29df2a8:	mov    %rax,0xa8(%rsp)
 29df2b0:	cmp    %rax,%rcx
 29df2b3:	jb     29dbded <wasm[0]::function[1013]::helper::array_indexed_publish+0x14cd>
 29df2b9:	mov    0x60(%rsp),%rdi
 29df2be:	call   3018d19 <wasmtime_builtin_new_epoch>
 29df2c3:	mov    %rax,0xa8(%rsp)
 29df2cb:	jmp    29dbded <wasm[0]::function[1013]::helper::array_indexed_publish+0x14cd>
 29df2d0:	mov    0xd0(%rsp),%r15
 29df2d8:	mov    0x8(%r15),%rax
 29df2dc:	mov    %rax,0xa8(%rsp)
 29df2e4:	cmp    %rax,%r9
 29df2e7:	jb     29dbe87 <wasm[0]::function[1013]::helper::array_indexed_publish+0x1567>
 29df2ed:	mov    0x60(%rsp),%rdi
 29df2f2:	call   3018d19 <wasmtime_builtin_new_epoch>
 29df2f7:	mov    %rax,0xa8(%rsp)
 29df2ff:	mov    0xc8(%rsp),%rcx
 29df307:	jmp    29dbe8f <wasm[0]::function[1013]::helper::array_indexed_publish+0x156f>
 29df30c:	mov    $0xb0000042,%esi
 29df311:	mov    $0x20,%ecx
 29df316:	mov    %r14,%rdx
 29df319:	mov    0x60(%rsp),%rdi
 29df31e:	mov    0xb0(%rsp),%r8
 29df326:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
 29df32b:	mov    %eax,%edi
 29df32d:	mov    0xd0(%rsp),%rdx
 29df335:	add    0x20(%rdx),%rdi
 29df339:	mov    0xc0(%rsp),%rcx
 29df341:	jmp    29dc0be <wasm[0]::function[1013]::helper::array_indexed_publish+0x179e>
 29df346:	mov    0xd0(%rsp),%r15
 29df34e:	mov    0x8(%r15),%rcx
 29df352:	mov    %rcx,0xa8(%rsp)
 29df35a:	cmp    %rcx,%rax
 29df35d:	jb     29dc36d <wasm[0]::function[1013]::helper::array_indexed_publish+0x1a4d>
 29df363:	mov    0x60(%rsp),%rdi
 29df368:	call   3018d19 <wasmtime_builtin_new_epoch>
 29df36d:	mov    %rax,0xa8(%rsp)
 29df375:	jmp    29dc36d <wasm[0]::function[1013]::helper::array_indexed_publish+0x1a4d>
 29df37a:	mov    $0xa800000e,%esi
 29df37f:	mov    0x60(%rsp),%rdi
 29df384:	mov    0x28(%rdi),%rax
 29df388:	mov    0x19c(%rax),%edx
 29df38e:	mov    $0x10,%r8d
 29df394:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
 29df399:	mov    %eax,%esi
 29df39b:	mov    0xd0(%rsp),%rdi
 29df3a3:	add    0x20(%rdi),%rsi
 29df3a7:	jmp    29dc429 <wasm[0]::function[1013]::helper::array_indexed_publish+0x1b09>
 29df3ac:	mov    0xd0(%rsp),%r15
 29df3b4:	mov    0x8(%r15),%rcx
 29df3b8:	mov    %rcx,%rdx
 29df3bb:	mov    %rcx,0xa8(%rsp)
 29df3c3:	cmp    %rdx,%rax
 29df3c6:	jb     29dc4df <wasm[0]::function[1013]::helper::array_indexed_publish+0x1bbf>
 29df3cc:	mov    0x60(%rsp),%rdi
 29df3d1:	call   3018d19 <wasmtime_builtin_new_epoch>
 29df3d6:	mov    %rax,0xa8(%rsp)
 29df3de:	jmp    29dc4df <wasm[0]::function[1013]::helper::array_indexed_publish+0x1bbf>
 29df3e3:	mov    0xd0(%rsp),%rcx
 29df3eb:	mov    0x8(%rcx),%rcx
 29df3ef:	mov    %rcx,0xa8(%rsp)
 29df3f7:	cmp    %rcx,%rax
 29df3fa:	jb     29dc63c <wasm[0]::function[1013]::helper::array_indexed_publish+0x1d1c>
 29df400:	mov    0x60(%rsp),%rdi
 29df405:	call   3018d19 <wasmtime_builtin_new_epoch>
 29df40a:	mov    %rax,0xa8(%rsp)
 29df412:	jmp    29dc63c <wasm[0]::function[1013]::helper::array_indexed_publish+0x1d1c>
 29df417:	mov    0xd0(%rsp),%rcx
 29df41f:	mov    0x8(%rcx),%rcx
 29df423:	mov    %rcx,0xa8(%rsp)
 29df42b:	cmp    %rcx,%rax
 29df42e:	jb     29dc6c9 <wasm[0]::function[1013]::helper::array_indexed_publish+0x1da9>
 29df434:	mov    0x60(%rsp),%rdi
 29df439:	call   3018d19 <wasmtime_builtin_new_epoch>
 29df43e:	mov    %rax,0xa8(%rsp)
 29df446:	jmp    29dc6c9 <wasm[0]::function[1013]::helper::array_indexed_publish+0x1da9>
 29df44b:	mov    $0xb0000042,%esi
 29df450:	mov    0x60(%rsp),%rdi
 29df455:	mov    0x28(%rdi),%rax
 29df459:	mov    0x120(%rax),%edx
 29df45f:	mov    $0x20,%ecx
 29df464:	mov    $0x10,%r8d
 29df46a:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
 29df46f:	mov    %eax,%esi
 29df471:	mov    0xd0(%rsp),%r15
 29df479:	add    0x20(%r15),%rsi
 29df47d:	mov    0x90(%rsp),%rcx
 29df485:	jmp    29dc7d3 <wasm[0]::function[1013]::helper::array_indexed_publish+0x1eb3>
 29df48a:	mov    $0xa800000e,%esi
 29df48f:	mov    0x60(%rsp),%rdi
 29df494:	mov    0x28(%rdi),%rax
 29df498:	mov    0x194(%rax),%edx
 29df49e:	mov    $0x10,%r8d
 29df4a4:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
 29df4a9:	mov    %eax,%r9d
 29df4ac:	mov    0xd0(%rsp),%rdi
 29df4b4:	add    0x20(%rdi),%r9
 29df4b8:	jmp    29dcb3f <wasm[0]::function[1013]::helper::array_indexed_publish+0x221f>
 29df4bd:	mov    0xd0(%rsp),%rdx
 29df4c5:	mov    0x8(%rdx),%rcx
 29df4c9:	mov    %rcx,0xa8(%rsp)
 29df4d1:	cmp    %rcx,%rax
 29df4d4:	jb     29dcbf3 <wasm[0]::function[1013]::helper::array_indexed_publish+0x22d3>
 29df4da:	mov    0x60(%rsp),%rdi
 29df4df:	call   3018d19 <wasmtime_builtin_new_epoch>
 29df4e4:	mov    %rax,0xa8(%rsp)
 29df4ec:	jmp    29dcbf3 <wasm[0]::function[1013]::helper::array_indexed_publish+0x22d3>
 29df4f1:	mov    0xd0(%rsp),%rcx
 29df4f9:	mov    0x8(%rcx),%rcx
 29df4fd:	mov    %rcx,0xa8(%rsp)
 29df505:	cmp    %rcx,%rax
 29df508:	jb     29dcc9f <wasm[0]::function[1013]::helper::array_indexed_publish+0x237f>
 29df50e:	mov    0x60(%rsp),%rdi
 29df513:	call   3018d19 <wasmtime_builtin_new_epoch>
 29df518:	mov    %rax,0xa8(%rsp)
 29df520:	mov    0x78(%rsp),%rcx
 29df525:	jmp    29dcca4 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2384>
 29df52a:	mov    0x90(%rsp),%rcx
 29df532:	mov    0x98(%rsp),%rdx
 29df53a:	mov    0xb0(%rsp),%rsi
 29df542:	mov    0x60(%rsp),%rdi
 29df547:	mov    0x88(%rsp),%r8
 29df54f:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
 29df554:	mov    %eax,%ecx
 29df556:	mov    0xd0(%rsp),%rsi
 29df55e:	add    0x20(%rsi),%rcx
 29df562:	mov    0xb8(%rsp),%r14
 29df56a:	jmp    29dce40 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2520>
 29df56f:	mov    $0xb0000072,%esi
 29df574:	mov    0x90(%rsp),%rcx
 29df57c:	mov    %r13,%rdx
 29df57f:	mov    0x60(%rsp),%rdi
 29df584:	mov    0x88(%rsp),%r8
 29df58c:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
 29df591:	mov    %eax,%ecx
 29df593:	mov    0xd0(%rsp),%rdx
 29df59b:	add    0x20(%rdx),%rcx
 29df59f:	jmp    29dceb5 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2595>
 29df5a4:	mov    $0xa800000e,%esi
 29df5a9:	mov    0x60(%rsp),%rdi
 29df5ae:	mov    0x28(%rdi),%r8
 29df5b2:	mov    0x194(%r8),%edx
 29df5b9:	mov    $0x10,%r8d
 29df5bf:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
 29df5c4:	mov    %eax,%ecx
 29df5c6:	mov    0xd0(%rsp),%rdx
 29df5ce:	add    0x20(%rdx),%rcx
 29df5d2:	jmp    29dd11e <wasm[0]::function[1013]::helper::array_indexed_publish+0x27fe>
 29df5d7:	mov    0xd0(%rsp),%rcx
 29df5df:	mov    0x8(%rcx),%rcx
 29df5e3:	mov    %rcx,0xa8(%rsp)
 29df5eb:	cmp    %rcx,%rax
 29df5ee:	jb     29dd1cd <wasm[0]::function[1013]::helper::array_indexed_publish+0x28ad>
 29df5f4:	mov    0x60(%rsp),%rdi
 29df5f9:	call   3018d19 <wasmtime_builtin_new_epoch>
 29df5fe:	mov    %rax,0xa8(%rsp)
 29df606:	jmp    29dd1cd <wasm[0]::function[1013]::helper::array_indexed_publish+0x28ad>
 29df60b:	mov    0xd0(%rsp),%rcx
 29df613:	mov    0x8(%rcx),%rcx
 29df617:	mov    %rcx,0xa8(%rsp)
 29df61f:	cmp    %rcx,%rax
 29df622:	jb     29dd262 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2942>
 29df628:	mov    0x60(%rsp),%rdi
 29df62d:	call   3018d19 <wasmtime_builtin_new_epoch>
 29df632:	mov    %rax,0xa8(%rsp)
 29df63a:	mov    0x88(%rsp),%rcx
 29df642:	jmp    29dd26a <wasm[0]::function[1013]::helper::array_indexed_publish+0x294a>
 29df647:	mov    0x78(%rsp),%rcx
 29df64c:	mov    %r14,%rdx
 29df64f:	mov    %rbx,%rsi
 29df652:	mov    0x60(%rsp),%rdi
 29df657:	mov    0xb8(%rsp),%r8
 29df65f:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
 29df664:	mov    %eax,%ecx
 29df666:	mov    0xd0(%rsp),%rdx
 29df66e:	add    0x20(%rdx),%rcx
 29df672:	mov    0x80(%rsp),%rsi
 29df67a:	jmp    29dd375 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2a55>
 29df67f:	mov    0xd0(%rsp),%r15
 29df687:	mov    0x8(%r15),%rcx
 29df68b:	mov    %rcx,0xa8(%rsp)
 29df693:	cmp    %rcx,%rax
 29df696:	jb     29dd60d <wasm[0]::function[1013]::helper::array_indexed_publish+0x2ced>
 29df69c:	mov    0x60(%rsp),%rdi
 29df6a1:	call   3018d19 <wasmtime_builtin_new_epoch>
 29df6a6:	mov    %rax,0xa8(%rsp)
 29df6ae:	mov    0x98(%rsp),%rdi
 29df6b6:	jmp    29dd615 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2cf5>
 29df6bb:	mov    $0xa800000e,%esi
 29df6c0:	mov    0x60(%rsp),%rdi
 29df6c5:	mov    0x28(%rdi),%rax
 29df6c9:	mov    0x1ac(%rax),%edx
 29df6cf:	mov    $0x10,%r8d
 29df6d5:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
 29df6da:	mov    %eax,%ecx
 29df6dc:	mov    0xd0(%rsp),%r15
 29df6e4:	add    0x20(%r15),%rcx
 29df6e8:	jmp    29dd701 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2de1>
 29df6ed:	mov    0xd0(%rsp),%r15
 29df6f5:	mov    0x8(%r15),%rax
 29df6f9:	mov    %rax,0xa8(%rsp)
 29df701:	cmp    %rax,%rcx
 29df704:	jb     29dd7a6 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2e86>
 29df70a:	mov    0x60(%rsp),%rdi
 29df70f:	call   3018d19 <wasmtime_builtin_new_epoch>
 29df714:	mov    %rax,0xa8(%rsp)
 29df71c:	jmp    29dd7a6 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2e86>
 29df721:	mov    0xd0(%rsp),%r15
 29df729:	mov    0x8(%r15),%rcx
 29df72d:	mov    %rcx,0xa8(%rsp)
 29df735:	cmp    %rcx,%rax
 29df738:	jb     29dd828 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2f08>
 29df73e:	mov    0x60(%rsp),%rdi
 29df743:	call   3018d19 <wasmtime_builtin_new_epoch>
 29df748:	mov    %rax,0xa8(%rsp)
 29df750:	mov    0x78(%rsp),%rdi
 29df755:	jmp    29dd82d <wasm[0]::function[1013]::helper::array_indexed_publish+0x2f0d>
 29df75a:	mov    $0xb0000062,%esi
 29df75f:	mov    0x88(%rsp),%rcx
 29df767:	mov    0x90(%rsp),%rdx
 29df76f:	mov    0x60(%rsp),%rdi
 29df774:	mov    %rbx,%r8
 29df777:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
 29df77c:	mov    %eax,%edx
 29df77e:	mov    0xd0(%rsp),%rcx
 29df786:	add    0x20(%rcx),%rdx
 29df78a:	mov    0x90(%rsp),%rcx
 29df792:	mov    0xb8(%rsp),%r9
 29df79a:	jmp    29dda1b <wasm[0]::function[1013]::helper::array_indexed_publish+0x30fb>
 29df79f:	mov    0xd0(%rsp),%rcx
 29df7a7:	mov    0x8(%rcx),%rcx
 29df7ab:	mov    %rcx,0xa8(%rsp)
 29df7b3:	cmp    %rcx,%rax
 29df7b6:	jb     29ddbc4 <wasm[0]::function[1013]::helper::array_indexed_publish+0x32a4>
 29df7bc:	mov    0x60(%rsp),%rdi
 29df7c1:	call   3018d19 <wasmtime_builtin_new_epoch>
 29df7c6:	mov    %rax,0xa8(%rsp)
 29df7ce:	jmp    29ddbc4 <wasm[0]::function[1013]::helper::array_indexed_publish+0x32a4>
 29df7d3:	mov    $0xa800000e,%esi
 29df7d8:	mov    0x60(%rsp),%rdi
 29df7dd:	mov    0x28(%rdi),%rax
 29df7e1:	mov    0x194(%rax),%edx
 29df7e7:	mov    $0x10,%r8d
 29df7ed:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
 29df7f2:	mov    %eax,%ecx
 29df7f4:	mov    0xd0(%rsp),%rdx
 29df7fc:	add    0x20(%rdx),%rcx
 29df800:	jmp    29ddc82 <wasm[0]::function[1013]::helper::array_indexed_publish+0x3362>
 29df805:	mov    0xd0(%rsp),%r15
 29df80d:	mov    0x8(%r15),%rax
 29df811:	mov    %rax,0xa8(%rsp)
 29df819:	cmp    %rax,%rcx
 29df81c:	jb     29ddd2e <wasm[0]::function[1013]::helper::array_indexed_publish+0x340e>
 29df822:	mov    0x60(%rsp),%rdi
 29df827:	call   3018d19 <wasmtime_builtin_new_epoch>
 29df82c:	mov    %rax,0xa8(%rsp)
 29df834:	jmp    29ddd2e <wasm[0]::function[1013]::helper::array_indexed_publish+0x340e>
 29df839:	mov    0xd0(%rsp),%rdx
 29df841:	mov    0x8(%rdx),%rax
 29df845:	mov    %rax,0xa8(%rsp)
 29df84d:	cmp    %rax,%rcx
 29df850:	jb     29ddecf <wasm[0]::function[1013]::helper::array_indexed_publish+0x35af>
 29df856:	mov    0x60(%rsp),%rdi
 29df85b:	call   3018d19 <wasmtime_builtin_new_epoch>
 29df860:	mov    %rax,0xa8(%rsp)
 29df868:	jmp    29ddecf <wasm[0]::function[1013]::helper::array_indexed_publish+0x35af>
 29df86d:	mov    0xd0(%rsp),%r15
 29df875:	mov    0x8(%r15),%rax
 29df879:	mov    %rax,0xa8(%rsp)
 29df881:	cmp    %rax,%rcx
 29df884:	jb     29ddf66 <wasm[0]::function[1013]::helper::array_indexed_publish+0x3646>
 29df88a:	mov    0x60(%rsp),%rdi
 29df88f:	call   3018d19 <wasmtime_builtin_new_epoch>
 29df894:	mov    %rax,0xa8(%rsp)
 29df89c:	jmp    29ddf66 <wasm[0]::function[1013]::helper::array_indexed_publish+0x3646>
 29df8a1:	mov    $0xa800000e,%esi
 29df8a6:	mov    0x60(%rsp),%rdi
 29df8ab:	mov    0x28(%rdi),%rax
 29df8af:	mov    0x1ac(%rax),%edx
 29df8b5:	mov    $0x34,%ecx
 29df8ba:	mov    $0x10,%r8d
 29df8c0:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
 29df8c5:	mov    %eax,%edx
 29df8c7:	mov    0xd0(%rsp),%r15
 29df8cf:	add    0x20(%r15),%rdx
 29df8d3:	jmp    29de269 <wasm[0]::function[1013]::helper::array_indexed_publish+0x3949>
 29df8d8:	mov    0xd0(%rsp),%r15
 29df8e0:	mov    0x8(%r15),%rcx
 29df8e4:	mov    %rcx,0xa8(%rsp)
 29df8ec:	cmp    %rcx,%rax
 29df8ef:	jb     29de307 <wasm[0]::function[1013]::helper::array_indexed_publish+0x39e7>
 29df8f5:	mov    0x60(%rsp),%rdi
 29df8fa:	call   3018d19 <wasmtime_builtin_new_epoch>
 29df8ff:	mov    %rax,0xa8(%rsp)
 29df907:	jmp    29de307 <wasm[0]::function[1013]::helper::array_indexed_publish+0x39e7>
 29df90c:	mov    0xd0(%rsp),%r15
 29df914:	mov    0x8(%r15),%rax
 29df918:	mov    %rax,0xa8(%rsp)
 29df920:	cmp    %rax,%rcx
 29df923:	jb     29de3a6 <wasm[0]::function[1013]::helper::array_indexed_publish+0x3a86>
 29df929:	mov    0x60(%rsp),%rdi
 29df92e:	call   3018d19 <wasmtime_builtin_new_epoch>
 29df933:	mov    %rax,0xa8(%rsp)
 29df93b:	mov    0x98(%rsp),%rax
 29df943:	jmp    29de3ae <wasm[0]::function[1013]::helper::array_indexed_publish+0x3a8e>
 29df948:	mov    0xd0(%rsp),%r15
 29df950:	mov    0x8(%r15),%rax
 29df954:	mov    %rax,0xa8(%rsp)
 29df95c:	cmp    %rax,%rcx
 29df95f:	jb     29de480 <wasm[0]::function[1013]::helper::array_indexed_publish+0x3b60>
 29df965:	mov    0x60(%rsp),%rdi
 29df96a:	call   3018d19 <wasmtime_builtin_new_epoch>
 29df96f:	mov    %rax,0xa8(%rsp)
 29df977:	jmp    29de480 <wasm[0]::function[1013]::helper::array_indexed_publish+0x3b60>
 29df97c:	mov    0xd0(%rsp),%r15
 29df984:	mov    0x8(%r15),%rcx
 29df988:	mov    %rcx,0xa8(%rsp)
 29df990:	cmp    %rcx,%rax
 29df993:	jb     29de762 <wasm[0]::function[1013]::helper::array_indexed_publish+0x3e42>
 29df999:	mov    0x60(%rsp),%rdi
 29df99e:	call   3018d19 <wasmtime_builtin_new_epoch>
 29df9a3:	mov    %rax,0xa8(%rsp)
 29df9ab:	jmp    29de762 <wasm[0]::function[1013]::helper::array_indexed_publish+0x3e42>
 29df9b0:	mov    $0xa800000e,%esi
 29df9b5:	mov    0x60(%rsp),%rdi
 29df9ba:	mov    0x28(%rdi),%rax
 29df9be:	mov    0x1ac(%rax),%edx
 29df9c4:	mov    0x80(%rsp),%rcx
 29df9cc:	mov    0x98(%rsp),%r8
 29df9d4:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
 29df9d9:	mov    %eax,%edx
 29df9db:	mov    0xd0(%rsp),%rcx
 29df9e3:	add    0x20(%rcx),%rdx
 29df9e7:	jmp    29de9a2 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4082>
 29df9ec:	mov    0xd0(%rsp),%rcx
 29df9f4:	mov    0x8(%rcx),%rcx
 29df9f8:	mov    %rcx,0xa8(%rsp)
 29dfa00:	cmp    %rcx,%rax
 29dfa03:	jb     29dea47 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4127>
 29dfa09:	mov    0x60(%rsp),%rdi
 29dfa0e:	call   3018d19 <wasmtime_builtin_new_epoch>
 29dfa13:	mov    %rax,0xa8(%rsp)
 29dfa1b:	jmp    29dea47 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4127>
 29dfa20:	mov    0xd0(%rsp),%r8
 29dfa28:	mov    0x8(%r8),%rax
 29dfa2c:	mov    %rax,0xa8(%rsp)
 29dfa34:	cmp    %rax,%rsi
 29dfa37:	jb     29deae5 <wasm[0]::function[1013]::helper::array_indexed_publish+0x41c5>
 29dfa3d:	mov    0x60(%rsp),%rdi
 29dfa42:	call   3018d19 <wasmtime_builtin_new_epoch>
 29dfa47:	mov    %rax,0xa8(%rsp)
 29dfa4f:	mov    0x80(%rsp),%r10
 29dfa57:	jmp    29deaed <wasm[0]::function[1013]::helper::array_indexed_publish+0x41cd>
 29dfa5c:	mov    0xd0(%rsp),%rdx
 29dfa64:	mov    0x8(%rdx),%r8
 29dfa68:	mov    %r8,%r10
 29dfa6b:	mov    %r8,0xa8(%rsp)
 29dfa73:	cmp    %r10,%rax
 29dfa76:	jb     29debc6 <wasm[0]::function[1013]::helper::array_indexed_publish+0x42a6>
 29dfa7c:	mov    0x60(%rsp),%rdi
 29dfa81:	call   3018d19 <wasmtime_builtin_new_epoch>
 29dfa86:	mov    %rax,0xa8(%rsp)
 29dfa8e:	jmp    29debc6 <wasm[0]::function[1013]::helper::array_indexed_publish+0x42a6>
 29dfa93:	mov    $0xb0000062,%esi
 29dfa98:	mov    0x60(%rsp),%rdi
 29dfa9d:	mov    0x28(%rdi),%rax
 29dfaa1:	mov    0x1a8(%rax),%edx
 29dfaa7:	mov    $0x20,%ecx
 29dfaac:	mov    0x98(%rsp),%r8
 29dfab4:	call   3018d7a <wasmtime_builtin_gc_alloc_raw>
 29dfab9:	mov    %eax,%ecx
 29dfabb:	mov    0xd0(%rsp),%r15
 29dfac3:	add    0x20(%r15),%rcx
 29dfac7:	mov    0x68(%rsp),%rdx
 29dfacc:	jmp    29dee85 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4565>
 29dfad1:	ud2
 29dfad3:	ud2
 29dfad5:	ud2
 29dfad7:	ud2
 29dfad9:	ud2
 29dfadb:	ud2
 29dfadd:	ud2
 29dfadf:	ud2
 29dfae1:	ud2
 29dfae3:	ud2
 29dfae5:	ud2
 29dfae7:	ud2
 29dfae9:	ud2
 29dfaeb:	ud2
 29dfaed:	ud2
 29dfaef:	ud2
 29dfaf1:	ud2
 29dfaf3:	ud2
 29dfaf5:	ud2
 29dfaf7:	ud2
 29dfaf9:	ud2
 29dfafb:	ud2
 29dfafd:	ud2
 29dfaff:	ud2
 29dfb01:	ud2
 29dfb03:	ud2
 29dfb05:	ud2
 29dfb07:	ud2
 29dfb09:	ud2
 29dfb0b:	ud2
 29dfb0d:	ud2
 29dfb0f:	ud2
 29dfb11:	ud2
 29dfb13:	ud2
 29dfb15:	ud2
 29dfb17:	ud2
 29dfb19:	ud2
 29dfb1b:	ud2
 29dfb1d:	ud2
 29dfb1f:	ud2
 29dfb21:	ud2
 29dfb23:	ud2
 29dfb25:	ud2
 29dfb27:	ud2
 29dfb29:	ud2
 29dfb2b:	ud2
 29dfb2d:	ud2
 29dfb2f:	ud2
 29dfb31:	ud2
 29dfb33:	ud2
 29dfb35:	ud2
 29dfb37:	ud2
 29dfb39:	ud2
 29dfb3b:	ud2
 29dfb3d:	ud2
 29dfb3f:	ud2
 29dfb41:	ud2
 29dfb43:	ud2
 29dfb45:	ud2
 29dfb47:	ud2
 29dfb49:	ud2
 29dfb4b:	ud2
 29dfb4d:	ud2
 29dfb4f:	ud2
 29dfb51:	ud2
 29dfb53:	ud2
 29dfb55:	ud2
 29dfb57:	ud2
 29dfb59:	ud2
 29dfb5b:	ud2
 29dfb5d:	ud2
 29dfb5f:	ud2
 29dfb61:	ud2
 29dfb63:	ud2
 29dfb65:	ud2
 29dfb67:	ud2
 29dfb69:	ud2
 29dfb6b:	ud2
 29dfb6d:	ud2
 29dfb6f:	ud2
 29dfb71:	ud2
 29dfb73:	ud2
 29dfb75:	ud2
 29dfb77:	ud2
 29dfb79:	ud2
 29dfb7b:	ud2
 29dfb7d:	ud2
 29dfb7f:	ud2
 29dfb81:	ud2
 29dfb83:	ud2
 29dfb85:	ud2
 29dfb87:	ud2
 29dfb89:	ud2
 29dfb8b:	ud2
 29dfb8d:	ud2
 29dfb8f:	ud2
 29dfb91:	ud2
 29dfb93:	ud2
 29dfb95:	ud2
 29dfb97:	ud2
 29dfb99:	ud2
 29dfb9b:	ud2
 29dfb9d:	ud2
 29dfb9f:	ud2
 29dfba1:	ud2
 29dfba3:	ud2
 29dfba5:	ud2
 29dfba7:	ud2
 29dfba9:	ud2
 29dfbab:	ud2
 29dfbad:	ud2
 29dfbaf:	ud2
 29dfbb1:	ud2
 29dfbb3:	ud2
 29dfbb5:	ud2
 29dfbb7:	ud2
 29dfbb9:	ud2
 29dfbbb:	ud2
 29dfbbd:	ud2
 29dfbbf:	ud2
 29dfbc1:	ud2
 29dfbc3:	ud2
 29dfbc5:	ud2
 29dfbc7:	ud2
 29dfbc9:	ud2
 29dfbcb:	ud2
 29dfbcd:	ud2
 29dfbcf:	ud2
 29dfbd1:	ud2
 29dfbd3:	ud2
 29dfbd5:	ud2
 29dfbd7:	ud2
 29dfbd9:	ud2
 29dfbdb:	ud2
 29dfbdd:	ud2
 29dfbdf:	ud2
 29dfbe1:	ud2
 29dfbe3:	ud2
 29dfbe5:	ud2
 29dfbe7:	ud2
 29dfbe9:	ud2
 29dfbeb:	ud2
 29dfbed:	ud2
 29dfbef:	ud2
 29dfbf1:	ud2
 29dfbf3:	ud2
 29dfbf5:	ud2
 29dfbf7:	ud2
 29dfbf9:	ud2
 29dfbfb:	ud2
 29dfbfd:	ud2
 29dfbff:	ud2
 29dfc01:	ud2
 29dfc03:	ud2
 29dfc05:	ud2
 29dfc07:	ud2
 29dfc09:	ud2
 29dfc0b:	ud2
 29dfc0d:	ud2
 29dfc0f:	ud2
 29dfc11:	ud2
 29dfc13:	ud2
 29dfc15:	ud2
 29dfc17:	ud2
 29dfc19:	ud2
 29dfc1b:	ud2
 29dfc1d:	ud2
 29dfc1f:	ud2
 29dfc21:	ud2
 29dfc23:	ud2
 29dfc25:	ud2
 29dfc27:	ud2
 29dfc29:	ud2
 29dfc2b:	ud2
 29dfc2d:	ud2
 29dfc2f:	ud2
 29dfc31:	ud2
 29dfc33:	ud2
 29dfc35:	ud2
 29dfc37:	ud2
 29dfc39:	ud2
 29dfc3b:	ud2
 29dfc3d:	ud2
 29dfc3f:	ud2
 29dfc41:	ud2
 29dfc43:	ud2
 29dfc45:	ud2
 29dfc47:	ud2
 29dfc49:	ud2
 29dfc4b:	ud2
 29dfc4d:	ud2
 29dfc4f:	ud2
 29dfc51:	ud2
 29dfc53:	ud2
 29dfc55:	ud2
 29dfc57:	ud2
 29dfc59:	ud2
 29dfc5b:	ud2
 29dfc5d:	ud2
 29dfc5f:	ud2
 29dfc61:	ud2
 29dfc63:	ud2
 29dfc65:	ud2
 29dfc67:	ud2
 29dfc69:	ud2
 29dfc6b:	ud2
 29dfc6d:	ud2
 29dfc6f:	ud2
 29dfc71:	ud2
 29dfc73:	ud2
 29dfc75:	ud2
 29dfc77:	ud2
 29dfc79:	ud2
 29dfc7b:	ud2
 29dfc7d:	ud2
 29dfc7f:	ud2
 29dfc81:	ud2
 29dfc83:	ud2
 29dfc85:	ud2
 29dfc87:	ud2
 29dfc89:	ud2
 29dfc8b:	ud2
 29dfc8d:	ud2
 29dfc8f:	ud2
 29dfc91:	ud2
 29dfc93:	ud2
 29dfc95:	ud2
 29dfc97:	ud2
 29dfc99:	ud2
 29dfc9b:	ud2
 29dfc9d:	ud2
 29dfc9f:	ud2
 29dfca1:	ud2
 29dfca3:	ud2
 29dfca5:	ud2
 29dfca7:	ud2
 29dfca9:	ud2
 29dfcab:	ud2
 29dfcad:	ud2
 29dfcaf:	ud2
 29dfcb1:	ud2
 29dfcb3:	ud2
 29dfcb5:	ud2
 29dfcb7:	ud2
 29dfcb9:	ud2
 29dfcbb:	ud2
 29dfcbd:	ud2
 29dfcbf:	ud2
 29dfcc1:	ud2
 29dfcc3:	ud2
 29dfcc5:	ud2
 29dfcc7:	ud2
 29dfcc9:	ud2
 29dfccb:	ud2
 29dfccd:	ud2
 29dfccf:	ud2
 29dfcd1:	ud2
 29dfcd3:	ud2
 29dfcd5:	ud2
 29dfcd7:	ud2
 29dfcd9:	ud2
 29dfcdb:	ud2
 29dfcdd:	ud2
 29dfcdf:	ud2
 29dfce1:	ud2
 29dfce3:	ud2
 29dfce5:	ud2
 29dfce7:	ud2
 29dfce9:	ud2
 29dfceb:	ud2
 29dfced:	ud2
 29dfcef:	ud2
 29dfcf1:	ud2
 29dfcf3:	ud2
 29dfcf5:	ud2
 29dfcf7:	ud2
 29dfcf9:	ud2
 29dfcfb:	ud2
 29dfcfd:	ud2
 29dfcff:	ud2
 29dfd01:	ud2
 29dfd03:	ud2
 29dfd05:	ud2
 29dfd07:	ud2
 29dfd09:	ud2
 29dfd0b:	ud2
 29dfd0d:	ud2
 29dfd0f:	ud2
 29dfd11:	ud2
 29dfd13:	ud2
 29dfd15:	ud2
 29dfd17:	ud2
 29dfd19:	ud2
 29dfd1b:	ud2
 29dfd1d:	ud2
 29dfd1f:	ud2
 29dfd21:	ud2
 29dfd23:	ud2
 29dfd25:	ud2
 29dfd27:	ud2
 29dfd29:	ud2
 29dfd2b:	ud2
 29dfd2d:	ud2
 29dfd2f:	ud2
 29dfd31:	ud2
 29dfd33:	ud2
 29dfd35:	ud2
 29dfd37:	ud2
 29dfd39:	ud2
 29dfd3b:	ud2
 29dfd3d:	ud2
 29dfd3f:	ud2
 29dfd41:	ud2
 29dfd43:	ud2
 29dfd45:	ud2
 29dfd47:	ud2
 29dfd49:	ud2
 29dfd4b:	ud2
 29dfd4d:	ud2
 29dfd4f:	ud2
 29dfd51:	ud2
 29dfd53:	ud2
 29dfd55:	ud2
 29dfd57:	ud2
 29dfd59:	ud2
 29dfd5b:	ud2
 29dfd5d:	ud2
 29dfd5f:	ud2
 29dfd61:	ud2
 29dfd63:	ud2
 29dfd65:	ud2
 29dfd67:	ud2
 29dfd69:	ud2
 29dfd6b:	ud2
 29dfd6d:	ud2
 29dfd6f:	ud2
 29dfd71:	ud2
 29dfd73:	ud2
 29dfd75:	ud2
 29dfd77:	ud2
 29dfd79:	ud2
 29dfd7b:	ud2
 29dfd7d:	ud2
 29dfd7f:	ud2
 29dfd81:	ud2
 29dfd83:	ud2
 29dfd85:	ud2
 29dfd87:	ud2
 29dfd89:	ud2
 29dfd8b:	ud2
 29dfd8d:	ud2
 29dfd8f:	ud2
 29dfd91:	ud2
 29dfd93:	ud2
 29dfd95:	ud2
 29dfd97:	ud2
 29dfd99:	ud2
 29dfd9b:	ud2
 29dfd9d:	ud2
 29dfd9f:	ud2
 29dfda1:	ud2
 29dfda3:	ud2
 29dfda5:	ud2
 29dfda7:	ud2
 29dfda9:	ud2
 29dfdab:	ud2
 29dfdad:	ud2
 29dfdaf:	ud2
 29dfdb1:	ud2
 29dfdb3:	ud2
 29dfdb5:	ud2
 29dfdb7:	ud2
 29dfdb9:	ud2
 29dfdbb:	ud2
 29dfdbd:	ud2
 29dfdbf:	ud2
 29dfdc1:	ud2
 29dfdc3:	ud2
 29dfdc5:	ud2
 29dfdc7:	ud2
 29dfdc9:	ud2
 29dfdcb:	add    %al,(%rax)
 29dfdcd:	add    %al,(%rax)
 29dfdcf:	add    %bh,%bh
 29dfdd1:	(bad)
 29dfdd2:	(bad)
 29dfdd3:	incl   (%rax)
 29dfdd5:	add    %al,(%rax)
	...
