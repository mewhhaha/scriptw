
/workspace/scriptw/target/performance-dense-numbers-20261030/v2/native-cause/candidate/runtime-portable.elf:     file format elf64-x86-64


Disassembly of section .text:

00000000029d86c0 <wasm[0]::function[1010]::helper::array_packed_push1>:
 29d86c0:	push   %rbp
 29d86c1:	mov    %rsp,%rbp
 29d86c4:	mov    0x8(%rdi),%r10
 29d86c8:	mov    0x18(%r10),%r10
 29d86cc:	add    $0xe0,%r10
 29d86d3:	cmp    %rsp,%r10
 29d86d6:	ja     29d90dd <wasm[0]::function[1010]::helper::array_packed_push1+0xa1d>
 29d86dc:	sub    $0xd0,%rsp
 29d86e3:	mov    %rbx,0xa0(%rsp)
 29d86eb:	mov    %r12,0xa8(%rsp)
 29d86f3:	mov    %r13,0xb0(%rsp)
 29d86fb:	mov    %r14,0xb8(%rsp)
 29d8703:	mov    %r15,0xc0(%rsp)
 29d870b:	mov    %r9,0x48(%rsp)
 29d8710:	mov    0x10(%rbp),%r9
 29d8714:	mov    %r9,0x50(%rsp)
 29d8719:	mov    0x18(%rbp),%rsi
 29d871d:	mov    %r8d,0x20(%rsp)
 29d8722:	mov    %esi,0x18(%rsp)
 29d8726:	mov    0x18(%rdi),%rax
 29d872a:	mov    (%rax),%rcx
 29d872d:	mov    %rax,0x90(%rsp)
 29d8735:	mov    0x8(%rdi),%rbx
 29d8739:	mov    %rdi,%r10
 29d873c:	mov    0x8(%rbx),%rax
 29d8740:	cmp    %rax,%rcx
 29d8743:	jae    29d907d <wasm[0]::function[1010]::helper::array_packed_push1+0x9bd>
 29d8749:	mov    %r10,%r14
 29d874c:	mov    %rax,0x58(%rsp)
 29d8751:	mov    0x20(%rsp),%eax
 29d8755:	xor    %edx,%edx
 29d8757:	test   %eax,%eax
 29d8759:	je     29d879f <wasm[0]::function[1010]::helper::array_packed_push1+0xdf>
 29d875f:	mov    0x20(%rsp),%eax
 29d8763:	xor    %edx,%edx
 29d8765:	test   $0x1,%eax
 29d876a:	jne    29d879f <wasm[0]::function[1010]::helper::array_packed_push1+0xdf>
 29d8770:	mov    0x20(%rsp),%ecx
 29d8774:	mov    0x28(%rbx),%rax
 29d8778:	mov    0x20(%rbx),%rdx
 29d877c:	mov    %ecx,%esi
 29d877e:	xor    %rcx,%rcx
 29d8781:	lea    0x4(%rdx,%rsi,1),%rdx
 29d8786:	cmp    %rax,%rsi
 29d8789:	cmova  %rcx,%rdx
 29d878d:	mov    (%rdx),%eax
 29d878f:	mov    0x28(%r14),%rcx
 29d8793:	cmp    0x254(%rcx),%eax
 29d8799:	sete   %al
 29d879c:	movzbl %al,%edx
 29d879f:	xor    %eax,%eax
 29d87a1:	xor    %rcx,%rcx
 29d87a4:	test   %edx,%edx
 29d87a6:	jne    29d87bf <wasm[0]::function[1010]::helper::array_packed_push1+0xff>
 29d87ac:	mov    %rax,%rdx
 29d87af:	mov    %rax,%rsi
 29d87b2:	mov    %rax,%rdi
 29d87b5:	mov    %rcx,0x68(%rsp)
 29d87ba:	jmp    29d9042 <wasm[0]::function[1010]::helper::array_packed_push1+0x982>
 29d87bf:	mov    0x20(%rsp),%edx
 29d87c3:	xor    %eax,%eax
 29d87c5:	test   %edx,%edx
 29d87c7:	je     29d880b <wasm[0]::function[1010]::helper::array_packed_push1+0x14b>
 29d87cd:	mov    0x20(%rsp),%edx
 29d87d1:	xor    %eax,%eax
 29d87d3:	test   $0x1,%edx
 29d87d9:	jne    29d880b <wasm[0]::function[1010]::helper::array_packed_push1+0x14b>
 29d87df:	mov    0x20(%rsp),%edx
 29d87e3:	mov    0x28(%rbx),%rax
 29d87e7:	mov    0x20(%rbx),%rsi
 29d87eb:	mov    %edx,%edi
 29d87ed:	lea    0x4(%rsi,%rdi,1),%rdx
 29d87f2:	cmp    %rax,%rdi
 29d87f5:	cmova  %rcx,%rdx
 29d87f9:	mov    (%rdx),%eax
 29d87fb:	mov    0x28(%r14),%rdx
 29d87ff:	cmp    0x254(%rdx),%eax
 29d8805:	sete   %al
 29d8808:	movzbl %al,%eax
 29d880b:	test   %eax,%eax
 29d880d:	je     29d90df <wasm[0]::function[1010]::helper::array_packed_push1+0xa1f>
 29d8813:	mov    0x20(%rsp),%eax
 29d8817:	xor    %edx,%edx
 29d8819:	test   %eax,%eax
 29d881b:	je     29d90e1 <wasm[0]::function[1010]::helper::array_packed_push1+0xa21>
 29d8821:	test   %eax,%eax
 29d8823:	je     29d90e3 <wasm[0]::function[1010]::helper::array_packed_push1+0xa23>
 29d8829:	mov    0x28(%rbx),%rsi
 29d882d:	mov    0x20(%rbx),%rdi
 29d8831:	mov    %eax,%r8d
 29d8834:	add    %r8,%rdi
 29d8837:	cmp    %rsi,%r8
 29d883a:	cmova  %rcx,%rdi
 29d883e:	mov    0x18(%rdi),%r15
 29d8842:	test   %eax,%eax
 29d8844:	je     29d8889 <wasm[0]::function[1010]::helper::array_packed_push1+0x1c9>
 29d884a:	mov    0x20(%rsp),%esi
 29d884e:	xor    %edx,%edx
 29d8850:	test   $0x1,%esi
 29d8856:	jne    29d8889 <wasm[0]::function[1010]::helper::array_packed_push1+0x1c9>
 29d885c:	mov    0x28(%rbx),%r8
 29d8860:	mov    0x20(%rbx),%r9
 29d8864:	mov    %esi,%r10d
 29d8867:	lea    0x4(%r9,%r10,1),%rdi
 29d886c:	cmp    %r8,%r10
 29d886f:	cmova  %rcx,%rdi
 29d8873:	mov    (%rdi),%r9d
 29d8876:	mov    0x28(%r14),%r10
 29d887a:	cmp    0x254(%r10),%r9d
 29d8881:	sete   %r10b
 29d8885:	movzbl %r10b,%edx
 29d8889:	xor    %edi,%edi
 29d888b:	test   %edx,%edx
 29d888d:	jne    29d88a3 <wasm[0]::function[1010]::helper::array_packed_push1+0x1e3>
 29d8893:	mov    %rdi,%rdx
 29d8896:	mov    %r15,%r12
 29d8899:	mov    %rcx,0x68(%rsp)
 29d889e:	jmp    29d8fe3 <wasm[0]::function[1010]::helper::array_packed_push1+0x923>
 29d88a3:	mov    0x20(%rsp),%edx
 29d88a7:	xor    %eax,%eax
 29d88a9:	test   %edx,%edx
 29d88ab:	je     29d88e7 <wasm[0]::function[1010]::helper::array_packed_push1+0x227>
 29d88b1:	xor    %eax,%eax
 29d88b3:	test   $0x1,%edx
 29d88b9:	jne    29d88e7 <wasm[0]::function[1010]::helper::array_packed_push1+0x227>
 29d88bf:	mov    0x28(%rbx),%rax
 29d88c3:	mov    0x20(%rbx),%rsi
 29d88c7:	mov    %edx,%edi
 29d88c9:	lea    0x4(%rsi,%rdi,1),%rsi
 29d88ce:	cmp    %rax,%rdi
 29d88d1:	cmova  %rcx,%rsi
 29d88d5:	mov    (%rsi),%eax
 29d88d7:	mov    0x28(%r14),%rsi
 29d88db:	cmp    0x254(%rsi),%eax
 29d88e1:	sete   %al
 29d88e4:	movzbl %al,%eax
 29d88e7:	test   %eax,%eax
 29d88e9:	je     29d90e5 <wasm[0]::function[1010]::helper::array_packed_push1+0xa25>
 29d88ef:	test   %edx,%edx
 29d88f1:	je     29d90e7 <wasm[0]::function[1010]::helper::array_packed_push1+0xa27>
 29d88f7:	test   %edx,%edx
 29d88f9:	je     29d90e9 <wasm[0]::function[1010]::helper::array_packed_push1+0xa29>
 29d88ff:	mov    0x28(%rbx),%rax
 29d8903:	mov    0x20(%rbx),%rsi
 29d8907:	mov    %edx,%edi
 29d8909:	lea    (%rsi,%rdi,1),%rdx
 29d890d:	cmp    %rax,%rdi
 29d8910:	cmova  %rcx,%rdx
 29d8914:	mov    0x14(%rdx),%eax
 29d8917:	mov    0x18(%rdx),%rdx
 29d891b:	xor    %edi,%edi
 29d891d:	cmp    %r15,%rdx
 29d8920:	je     29d8936 <wasm[0]::function[1010]::helper::array_packed_push1+0x276>
 29d8926:	mov    %rdi,%rdx
 29d8929:	mov    %r15,%r12
 29d892c:	mov    %rcx,0x68(%rsp)
 29d8931:	jmp    29d8fe3 <wasm[0]::function[1010]::helper::array_packed_push1+0x923>
 29d8936:	xor    %edi,%edi
 29d8938:	test   %eax,%eax
 29d893a:	je     29d90eb <wasm[0]::function[1010]::helper::array_packed_push1+0xa2b>
 29d8940:	test   %eax,%eax
 29d8942:	je     29d90ed <wasm[0]::function[1010]::helper::array_packed_push1+0xa2d>
 29d8948:	mov    0x28(%rbx),%rdx
 29d894c:	mov    0x20(%rbx),%r8
 29d8950:	mov    %eax,%esi
 29d8952:	lea    (%r8,%rsi,1),%rax
 29d8956:	cmp    %rdx,%rsi
 29d8959:	cmova  %rcx,%rax
 29d895d:	mov    0x24(%rax),%edx
 29d8960:	cmp    $0x2,%edx
 29d8963:	sete   %al
 29d8966:	cmp    $0x3,%edx
 29d8969:	sete   %dl
 29d896c:	or     %edx,%eax
 29d896e:	movzbl %al,%eax
 29d8971:	test   %eax,%eax
 29d8973:	jne    29d8989 <wasm[0]::function[1010]::helper::array_packed_push1+0x2c9>
 29d8979:	mov    %rdi,%rdx
 29d897c:	mov    %r15,%r12
 29d897f:	mov    %rcx,0x68(%rsp)
 29d8984:	jmp    29d8fe3 <wasm[0]::function[1010]::helper::array_packed_push1+0x923>
 29d8989:	lea    0x1(%r15),%rax
 29d898d:	xor    %edi,%edi
 29d898f:	cmp    0x78a(%rip),%rax        # 29d9120 <wasm[0]::function[1010]::helper::array_packed_push1+0xa60>
 29d8996:	jbe    29d89ac <wasm[0]::function[1010]::helper::array_packed_push1+0x2ec>
 29d899c:	mov    %rdi,%rdx
 29d899f:	mov    %r15,%r12
 29d89a2:	mov    %rcx,0x68(%rsp)
 29d89a7:	jmp    29d8fe3 <wasm[0]::function[1010]::helper::array_packed_push1+0x923>
 29d89ac:	mov    0x20(%rsp),%eax
 29d89b0:	xor    %edi,%edi
 29d89b2:	test   %eax,%eax
 29d89b4:	je     29d90ef <wasm[0]::function[1010]::helper::array_packed_push1+0xa2f>
 29d89ba:	test   %eax,%eax
 29d89bc:	je     29d90f1 <wasm[0]::function[1010]::helper::array_packed_push1+0xa31>
 29d89c2:	mov    0x28(%rbx),%rdx
 29d89c6:	mov    %eax,%r8d
 29d89c9:	mov    %r8,%rax
 29d89cc:	add    0x20(%rbx),%rax
 29d89d0:	cmp    %rdx,%r8
 29d89d3:	cmova  %rcx,%rax
 29d89d7:	mov    0x20(%rax),%eax
 29d89da:	test   %eax,%eax
 29d89dc:	jne    29d89f2 <wasm[0]::function[1010]::helper::array_packed_push1+0x332>
 29d89e2:	mov    %rdi,%rdx
 29d89e5:	mov    %r15,%r12
 29d89e8:	mov    %rcx,0x68(%rsp)
 29d89ed:	jmp    29d8fe3 <wasm[0]::function[1010]::helper::array_packed_push1+0x923>
 29d89f2:	mov    0x20(%rsp),%r8d
 29d89f7:	xor    %edi,%edi
 29d89f9:	test   %r8d,%r8d
 29d89fc:	je     29d90f3 <wasm[0]::function[1010]::helper::array_packed_push1+0xa33>
 29d8a02:	test   %r8d,%r8d
 29d8a05:	je     29d90f5 <wasm[0]::function[1010]::helper::array_packed_push1+0xa35>
 29d8a0b:	mov    0x28(%rbx),%rax
 29d8a0f:	mov    0x20(%rbx),%rdx
 29d8a13:	mov    %r8d,%r9d
 29d8a16:	lea    (%rdx,%r9,1),%r8
 29d8a1a:	cmp    %rax,%r9
 29d8a1d:	cmova  %rcx,%r8
 29d8a21:	mov    0x10(%r8),%r8d
 29d8a25:	test   %r8d,%r8d
 29d8a28:	je     29d90f7 <wasm[0]::function[1010]::helper::array_packed_push1+0xa37>
 29d8a2e:	test   %r8d,%r8d
 29d8a31:	je     29d90f9 <wasm[0]::function[1010]::helper::array_packed_push1+0xa39>
 29d8a37:	mov    %r8d,%r8d
 29d8a3a:	add    %r8,%rdx
 29d8a3d:	cmp    %rax,%r8
 29d8a40:	cmova  %rcx,%rdx
 29d8a44:	mov    0x1c(%rdx),%edx
 29d8a47:	test   %edx,%edx
 29d8a49:	jne    29d8a5f <wasm[0]::function[1010]::helper::array_packed_push1+0x39f>
 29d8a4f:	mov    %rdi,%rdx
 29d8a52:	mov    %r15,%r12
 29d8a55:	mov    %rcx,0x68(%rsp)
 29d8a5a:	jmp    29d8fe3 <wasm[0]::function[1010]::helper::array_packed_push1+0x923>
 29d8a5f:	mov    0x28(%rbx),%r8
 29d8a63:	mov    %rsi,%rdi
 29d8a66:	add    0x20(%rbx),%rdi
 29d8a6a:	cmp    %r8,%rsi
 29d8a6d:	cmova  %rcx,%rdi
 29d8a71:	mov    0x18(%rdi),%rsi
 29d8a75:	xor    %edi,%edi
 29d8a77:	cmp    %r15,%rsi
 29d8a7a:	mov    %r15,0x88(%rsp)
 29d8a82:	je     29d8a9d <wasm[0]::function[1010]::helper::array_packed_push1+0x3dd>
 29d8a88:	mov    %rdi,%rdx
 29d8a8b:	mov    0x88(%rsp),%r12
 29d8a93:	mov    %rcx,0x68(%rsp)
 29d8a98:	jmp    29d8fe3 <wasm[0]::function[1010]::helper::array_packed_push1+0x923>
 29d8a9d:	mov    0x20(%rsp),%edx
 29d8aa1:	xor    %eax,%eax
 29d8aa3:	mov    %rax,0x60(%rsp)
 29d8aa8:	test   %edx,%edx
 29d8aaa:	je     29d90fb <wasm[0]::function[1010]::helper::array_packed_push1+0xa3b>
 29d8ab0:	test   %edx,%edx
 29d8ab2:	je     29d90fd <wasm[0]::function[1010]::helper::array_packed_push1+0xa3d>
 29d8ab8:	mov    0x28(%rbx),%rax
 29d8abc:	mov    0x20(%rbx),%rsi
 29d8ac0:	mov    %edx,%r8d
 29d8ac3:	lea    (%rsi,%r8,1),%rdi
 29d8ac7:	cmp    %rax,%r8
 29d8aca:	cmova  %rcx,%rdi
 29d8ace:	mov    0x10(%rdi),%edi
 29d8ad1:	test   %edi,%edi
 29d8ad3:	je     29d90ff <wasm[0]::function[1010]::helper::array_packed_push1+0xa3f>
 29d8ad9:	mov    %edi,%edi
 29d8adb:	add    %rdi,%rsi
 29d8ade:	cmp    %rax,%rdi
 29d8ae1:	cmova  %rcx,%rsi
 29d8ae5:	mov    %rcx,0x68(%rsp)
 29d8aea:	mov    0x10(%rsi),%edi
 29d8aed:	mov    0x18(%rsp),%esi
 29d8af1:	mov    $0x1,%r12d
 29d8af7:	mov    %r12,0x80(%rsp)
 29d8aff:	mov    0x28(%r14),%rax
 29d8b03:	mov    0x254(%rax),%r12d
 29d8b0a:	mov    %r12,0x78(%rsp)
 29d8b0f:	mov    0x138(%rax),%r13d
 29d8b16:	mov    %r13,0x70(%rsp)
 29d8b1b:	mov    0x60(%rsp),%r8
 29d8b20:	mov    %edi,0x28(%rsp)
 29d8b24:	mov    %edx,0x10(%rsp)
 29d8b28:	mov    %esi,0x18(%rsp)
 29d8b2c:	mov    %r8d,0x20(%rsp)
 29d8b31:	mov    0x90(%rsp),%rax
 29d8b39:	mov    (%rax),%rcx
 29d8b3c:	mov    0x58(%rsp),%rax
 29d8b41:	cmp    %rax,%rcx
 29d8b44:	jae    29d9092 <wasm[0]::function[1010]::helper::array_packed_push1+0x9d2>
 29d8b4a:	mov    %rax,0x58(%rsp)
 29d8b4f:	jmp    29d8b59 <wasm[0]::function[1010]::helper::array_packed_push1+0x499>
 29d8b54:	mov    %rax,0x58(%rsp)
 29d8b59:	mov    0x28(%rsp),%eax
 29d8b5d:	test   %eax,%eax
 29d8b5f:	je     29d8f3a <wasm[0]::function[1010]::helper::array_packed_push1+0x87a>
 29d8b65:	mov    0x10(%rsp),%edx
 29d8b69:	mov    %rdx,%r11
 29d8b6c:	mov    0x18(%rsp),%esi
 29d8b70:	mov    0x20(%rsp),%edi
 29d8b74:	xor    %r13d,%r13d
 29d8b77:	mov    0x60(%rsp),%rax
 29d8b7c:	cmp    $0x8,%eax
 29d8b7f:	jb     29d8b9b <wasm[0]::function[1010]::helper::array_packed_push1+0x4db>
 29d8b85:	mov    %r11,%rcx
 29d8b88:	mov    %rdi,%rdx
 29d8b8b:	mov    %r14,%r10
 29d8b8e:	mov    0x88(%rsp),%r12
 29d8b96:	jmp    29d8f5f <wasm[0]::function[1010]::helper::array_packed_push1+0x89f>
 29d8b9b:	mov    0x28(%rsp),%eax
 29d8b9f:	xor    %edx,%edx
 29d8ba1:	test   %eax,%eax
 29d8ba3:	jne    29d8bb3 <wasm[0]::function[1010]::helper::array_packed_push1+0x4f3>
 29d8ba9:	mov    0x68(%rsp),%rcx
 29d8bae:	jmp    29d8bfd <wasm[0]::function[1010]::helper::array_packed_push1+0x53d>
 29d8bb3:	mov    0x28(%rsp),%eax
 29d8bb7:	xor    %edx,%edx
 29d8bb9:	test   $0x1,%eax
 29d8bbe:	je     29d8bce <wasm[0]::function[1010]::helper::array_packed_push1+0x50e>
 29d8bc4:	mov    0x68(%rsp),%rcx
 29d8bc9:	jmp    29d8bfd <wasm[0]::function[1010]::helper::array_packed_push1+0x53d>
 29d8bce:	mov    0x28(%rsp),%ecx
 29d8bd2:	mov    0x28(%rbx),%rax
 29d8bd6:	mov    0x20(%rbx),%rdx
 29d8bda:	mov    %ecx,%ecx
 29d8bdc:	lea    0x4(%rdx,%rcx,1),%rdx
 29d8be1:	cmp    %rax,%rcx
 29d8be4:	mov    0x68(%rsp),%rcx
 29d8be9:	cmova  %rcx,%rdx
 29d8bed:	mov    (%rdx),%eax
 29d8bef:	mov    0x78(%rsp),%r13
 29d8bf4:	cmp    %r13d,%eax
 29d8bf7:	sete   %al
 29d8bfa:	movzbl %al,%edx
 29d8bfd:	test   %edx,%edx
 29d8bff:	jne    29d8dec <wasm[0]::function[1010]::helper::array_packed_push1+0x72c>
 29d8c05:	mov    0x28(%rsp),%eax
 29d8c09:	xor    %edx,%edx
 29d8c0b:	test   %eax,%eax
 29d8c0d:	je     29d8c4e <wasm[0]::function[1010]::helper::array_packed_push1+0x58e>
 29d8c13:	mov    0x28(%rsp),%eax
 29d8c17:	xor    %edx,%edx
 29d8c19:	test   $0x1,%eax
 29d8c1e:	jne    29d8c4e <wasm[0]::function[1010]::helper::array_packed_push1+0x58e>
 29d8c24:	mov    0x28(%rsp),%edx
 29d8c28:	mov    0x28(%rbx),%rax
 29d8c2c:	mov    0x20(%rbx),%rsi
 29d8c30:	mov    %edx,%edi
 29d8c32:	lea    0x4(%rsi,%rdi,1),%rdx
 29d8c37:	cmp    %rax,%rdi
 29d8c3a:	cmova  %rcx,%rdx
 29d8c3e:	mov    (%rdx),%eax
 29d8c40:	mov    0x70(%rsp),%r13
 29d8c45:	cmp    %r13d,%eax
 29d8c48:	sete   %al
 29d8c4b:	movzbl %al,%edx
 29d8c4e:	mov    0x10(%rsp),%eax
 29d8c52:	mov    %rax,%r11
 29d8c55:	mov    0x18(%rsp),%esi
 29d8c59:	mov    0x20(%rsp),%edi
 29d8c5d:	xor    %r13d,%r13d
 29d8c60:	test   %edx,%edx
 29d8c62:	jne    29d8c83 <wasm[0]::function[1010]::helper::array_packed_push1+0x5c3>
 29d8c68:	mov    %rcx,0x68(%rsp)
 29d8c6d:	mov    0x88(%rsp),%r12
 29d8c75:	mov    %r14,%r10
 29d8c78:	mov    %rdi,%rdx
 29d8c7b:	mov    %r11,%rcx
 29d8c7e:	jmp    29d8f5f <wasm[0]::function[1010]::helper::array_packed_push1+0x89f>
 29d8c83:	mov    0x28(%rsp),%eax
 29d8c87:	xor    %edx,%edx
 29d8c89:	test   %eax,%eax
 29d8c8b:	jne    29d8c9b <wasm[0]::function[1010]::helper::array_packed_push1+0x5db>
 29d8c91:	mov    %rcx,0x68(%rsp)
 29d8c96:	jmp    29d8ce5 <wasm[0]::function[1010]::helper::array_packed_push1+0x625>
 29d8c9b:	mov    0x28(%rsp),%eax
 29d8c9f:	xor    %edx,%edx
 29d8ca1:	test   $0x1,%eax
 29d8ca6:	je     29d8cb6 <wasm[0]::function[1010]::helper::array_packed_push1+0x5f6>
 29d8cac:	mov    %rcx,0x68(%rsp)
 29d8cb1:	jmp    29d8ce5 <wasm[0]::function[1010]::helper::array_packed_push1+0x625>
 29d8cb6:	mov    0x28(%rsp),%edx
 29d8cba:	mov    0x28(%rbx),%rax
 29d8cbe:	mov    0x20(%rbx),%rsi
 29d8cc2:	mov    %edx,%edi
 29d8cc4:	lea    0x4(%rsi,%rdi,1),%rdx
 29d8cc9:	cmp    %rax,%rdi
 29d8ccc:	cmova  %rcx,%rdx
 29d8cd0:	mov    %rcx,0x68(%rsp)
 29d8cd5:	mov    (%rdx),%ecx
 29d8cd7:	mov    0x70(%rsp),%r13
 29d8cdc:	cmp    %r13d,%ecx
 29d8cdf:	sete   %dl
 29d8ce2:	movzbl %dl,%edx
 29d8ce5:	test   %edx,%edx
 29d8ce7:	je     29d9101 <wasm[0]::function[1010]::helper::array_packed_push1+0xa41>
 29d8ced:	mov    0x10(%rsp),%edx
 29d8cf1:	mov    %rdx,%r11
 29d8cf4:	mov    0x18(%rsp),%esi
 29d8cf8:	mov    0x20(%rsp),%edi
 29d8cfc:	mov    0x88(%rsp),%r15
 29d8d04:	mov    %edx,0x30(%rsp)
 29d8d08:	mov    %esi,0x38(%rsp)
 29d8d0c:	mov    %rdi,%rdx
 29d8d0f:	mov    %edx,0x40(%rsp)
 29d8d13:	mov    0x90(%rsp),%rcx
 29d8d1b:	mov    (%rcx),%r9
 29d8d1e:	mov    0x58(%rsp),%rax
 29d8d23:	cmp    %rax,%r9
 29d8d26:	jae    29d90b1 <wasm[0]::function[1010]::helper::array_packed_push1+0x9f1>
 29d8d2c:	mov    0x88(%rsp),%r12
 29d8d34:	jmp    29d8d41 <wasm[0]::function[1010]::helper::array_packed_push1+0x681>
 29d8d39:	mov    0x88(%rsp),%r12
 29d8d41:	lea    0x1(%r12),%rax
 29d8d46:	cmp    %rax,%r15
 29d8d49:	jae    29d8dce <wasm[0]::function[1010]::helper::array_packed_push1+0x70e>
 29d8d4f:	xor    %r13d,%r13d
 29d8d52:	mov    %r13,%rcx
 29d8d55:	mov    %r15,%rdx
 29d8d58:	mov    %r14,%rsi
 29d8d5b:	mov    %r14,%rdi
 29d8d5e:	call   2ae5800 <wasm[0]::function[1058]::helper::integer_decimal_string>
 29d8d63:	test   %eax,%eax
 29d8d65:	je     29d9103 <wasm[0]::function[1010]::helper::array_packed_push1+0xa43>
 29d8d6b:	mov    0x28(%rsp),%edx
 29d8d6f:	test   %edx,%edx
 29d8d71:	je     29d9105 <wasm[0]::function[1010]::helper::array_packed_push1+0xa45>
 29d8d77:	mov    $0x4,%ecx
 29d8d7c:	mov    %rax,%r9
 29d8d7f:	mov    %r14,%rsi
 29d8d82:	mov    %r14,%rdi
 29d8d85:	mov    0x68(%rsp),%r8
 29d8d8a:	call   29ffc00 <wasm[0]::function[1019]::helper::ordinary_own_descriptor>
 29d8d8f:	mov    %r14,%r10
 29d8d92:	mov    0x30(%rsp),%edx
 29d8d96:	mov    %rdx,%r11
 29d8d99:	mov    0x38(%rsp),%esi
 29d8d9d:	mov    0x40(%rsp),%edx
 29d8da1:	test   %eax,%eax
 29d8da3:	je     29d8db1 <wasm[0]::function[1010]::helper::array_packed_push1+0x6f1>
 29d8da9:	mov    %r11,%rcx
 29d8dac:	jmp    29d8f5f <wasm[0]::function[1010]::helper::array_packed_push1+0x89f>
 29d8db1:	add    $0x1,%r15
 29d8db8:	mov    %r12,0x88(%rsp)
 29d8dc0:	mov    %r10,%r14
 29d8dc3:	mov    %rdx,%rdi
 29d8dc6:	mov    %r11,%rdx
 29d8dc9:	jmp    29d8d04 <wasm[0]::function[1010]::helper::array_packed_push1+0x644>
 29d8dce:	mov    %r14,%r10
 29d8dd1:	mov    0x28(%rsp),%edi
 29d8dd5:	mov    0x30(%rsp),%edx
 29d8dd9:	mov    0x38(%rsp),%esi
 29d8ddd:	mov    0x40(%rsp),%r8d
 29d8de2:	mov    0x78(%rsp),%rcx
 29d8de7:	jmp    29d8ef0 <wasm[0]::function[1010]::helper::array_packed_push1+0x830>
 29d8dec:	mov    %r14,%r10
 29d8def:	mov    0x88(%rsp),%r12
 29d8df7:	mov    %rcx,0x68(%rsp)
 29d8dfc:	mov    0x28(%rsp),%eax
 29d8e00:	xor    %edx,%edx
 29d8e02:	test   %eax,%eax
 29d8e04:	jne    29d8e14 <wasm[0]::function[1010]::helper::array_packed_push1+0x754>
 29d8e0a:	mov    0x78(%rsp),%rcx
 29d8e0f:	jmp    29d8e5d <wasm[0]::function[1010]::helper::array_packed_push1+0x79d>
 29d8e14:	mov    0x28(%rsp),%eax
 29d8e18:	xor    %edx,%edx
 29d8e1a:	test   $0x1,%eax
 29d8e1f:	je     29d8e2f <wasm[0]::function[1010]::helper::array_packed_push1+0x76f>
 29d8e25:	mov    0x78(%rsp),%rcx
 29d8e2a:	jmp    29d8e5d <wasm[0]::function[1010]::helper::array_packed_push1+0x79d>
 29d8e2f:	mov    0x28(%rsp),%ecx
 29d8e33:	mov    0x28(%rbx),%rax
 29d8e37:	mov    0x20(%rbx),%rdx
 29d8e3b:	mov    %ecx,%esi
 29d8e3d:	lea    0x4(%rdx,%rsi,1),%rcx
 29d8e42:	cmp    %rax,%rsi
 29d8e45:	mov    0x68(%rsp),%rax
 29d8e4a:	cmova  %rax,%rcx
 29d8e4e:	mov    (%rcx),%eax
 29d8e50:	mov    0x78(%rsp),%rcx
 29d8e55:	cmp    %ecx,%eax
 29d8e57:	sete   %al
 29d8e5a:	movzbl %al,%edx
 29d8e5d:	test   %edx,%edx
 29d8e5f:	je     29d9107 <wasm[0]::function[1010]::helper::array_packed_push1+0xa47>
 29d8e65:	mov    0x28(%rsp),%esi
 29d8e69:	xor    %r13d,%r13d
 29d8e6c:	test   %esi,%esi
 29d8e6e:	je     29d9109 <wasm[0]::function[1010]::helper::array_packed_push1+0xa49>
 29d8e74:	test   %esi,%esi
 29d8e76:	je     29d910b <wasm[0]::function[1010]::helper::array_packed_push1+0xa4b>
 29d8e7c:	mov    0x28(%rbx),%rdx
 29d8e80:	mov    0x20(%rbx),%rdi
 29d8e84:	mov    %esi,%eax
 29d8e86:	lea    (%rdi,%rax,1),%rsi
 29d8e8a:	cmp    %rdx,%rax
 29d8e8d:	mov    0x68(%rsp),%r8
 29d8e92:	cmova  %r8,%rsi
 29d8e96:	mov    0x14(%rsi),%eax
 29d8e99:	test   %eax,%eax
 29d8e9b:	je     29d910d <wasm[0]::function[1010]::helper::array_packed_push1+0xa4d>
 29d8ea1:	test   %eax,%eax
 29d8ea3:	je     29d910f <wasm[0]::function[1010]::helper::array_packed_push1+0xa4f>
 29d8ea9:	mov    %eax,%r8d
 29d8eac:	lea    (%rdi,%r8,1),%rax
 29d8eb0:	cmp    %rdx,%r8
 29d8eb3:	mov    0x68(%rsp),%r11
 29d8eb8:	cmova  %r11,%rax
 29d8ebc:	mov    0x18(%rax),%rax
 29d8ec0:	mov    0x10(%rsi),%edi
 29d8ec3:	mov    0x10(%rsp),%edx
 29d8ec7:	mov    %rdx,%r11
 29d8eca:	mov    0x18(%rsp),%esi
 29d8ece:	mov    0x20(%rsp),%edx
 29d8ed2:	test   %rax,%rax
 29d8ed5:	je     29d8ee3 <wasm[0]::function[1010]::helper::array_packed_push1+0x823>
 29d8edb:	mov    %r11,%rcx
 29d8ede:	jmp    29d8f5f <wasm[0]::function[1010]::helper::array_packed_push1+0x89f>
 29d8ee3:	mov    0x10(%rsp),%edx
 29d8ee7:	mov    0x18(%rsp),%esi
 29d8eeb:	mov    0x20(%rsp),%r8d
 29d8ef0:	test   %edi,%edi
 29d8ef2:	je     29d9111 <wasm[0]::function[1010]::helper::array_packed_push1+0xa51>
 29d8ef8:	mov    0x28(%rbx),%rax
 29d8efc:	mov    %edi,%r9d
 29d8eff:	mov    %r9,%rdi
 29d8f02:	add    0x20(%rbx),%rdi
 29d8f06:	cmp    %rax,%r9
 29d8f09:	mov    0x68(%rsp),%rax
 29d8f0e:	cmova  %rax,%rdi
 29d8f12:	mov    0x10(%rdi),%edi
 29d8f15:	mov    0x60(%rsp),%rax
 29d8f1a:	add    $0x1,%eax
 29d8f20:	mov    %rax,0x60(%rsp)
 29d8f25:	mov    %r10,%r14
 29d8f28:	mov    %rcx,0x78(%rsp)
 29d8f2d:	mov    %r12,0x88(%rsp)
 29d8f35:	jmp    29d8b20 <wasm[0]::function[1010]::helper::array_packed_push1+0x460>
 29d8f3a:	mov    %r14,%r10
 29d8f3d:	mov    0x88(%rsp),%r12
 29d8f45:	mov    0x10(%rsp),%edx
 29d8f49:	mov    %rdx,%r11
 29d8f4c:	mov    0x18(%rsp),%esi
 29d8f50:	mov    0x20(%rsp),%edx
 29d8f54:	mov    %r11,%rcx
 29d8f57:	mov    0x80(%rsp),%r13
 29d8f5f:	mov    %ecx,0x18(%rsp)
 29d8f63:	mov    %edx,0x10(%rsp)
 29d8f67:	xor    %edi,%edi
 29d8f69:	test   %r13d,%r13d
 29d8f6c:	je     29d8fe3 <wasm[0]::function[1010]::helper::array_packed_push1+0x923>
 29d8f72:	mov    %r11,%rdx
 29d8f75:	mov    %r11,%r9
 29d8f78:	test   %r9d,%edx
 29d8f7b:	je     29d9113 <wasm[0]::function[1010]::helper::array_packed_push1+0xa53>
 29d8f81:	mov    %esi,(%rsp)
 29d8f84:	mov    %r10,%rsi
 29d8f87:	mov    0x48(%rsp),%r8
 29d8f8c:	mov    0x50(%rsp),%r9
 29d8f91:	mov    %r12,%rcx
 29d8f94:	mov    %rsi,%rdi
 29d8f97:	call   29d4760 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data>
 29d8f9c:	sub    $0x10,%rsp
 29d8fa0:	mov    0x18(%rsp),%esi
 29d8fa4:	test   %esi,%esi
 29d8fa6:	je     29d9115 <wasm[0]::function[1010]::helper::array_packed_push1+0xa55>
 29d8fac:	test   %esi,%esi
 29d8fae:	je     29d9117 <wasm[0]::function[1010]::helper::array_packed_push1+0xa57>
 29d8fb4:	mov    0x28(%rbx),%r8
 29d8fb8:	lea    0x1(%r12),%rdi
 29d8fbd:	mov    %esi,%r9d
 29d8fc0:	mov    %r9,%rsi
 29d8fc3:	add    0x20(%rbx),%rsi
 29d8fc7:	cmp    %r8,%r9
 29d8fca:	mov    0x68(%rsp),%rcx
 29d8fcf:	cmova  %rcx,%rsi
 29d8fd3:	mov    %rdi,0x18(%rsi)
 29d8fd7:	mov    0x10(%rsp),%edx
 29d8fdb:	mov    0x80(%rsp),%rdi
 29d8fe3:	xor    %eax,%eax
 29d8fe5:	test   %edi,%edi
 29d8fe7:	jne    29d8ff8 <wasm[0]::function[1010]::helper::array_packed_push1+0x938>
 29d8fed:	mov    %rax,%rsi
 29d8ff0:	mov    %rax,%rdi
 29d8ff3:	jmp    29d9042 <wasm[0]::function[1010]::helper::array_packed_push1+0x982>
 29d8ff8:	mov    $0x3,%eax
 29d8ffd:	lea    0x1(%r12),%rcx
 29d9002:	cmp    $0x0,%rcx
 29d9006:	jl     29d9016 <wasm[0]::function[1010]::helper::array_packed_push1+0x956>
 29d900c:	cvtsi2sd %rcx,%xmm0
 29d9011:	jmp    29d9030 <wasm[0]::function[1010]::helper::array_packed_push1+0x970>
 29d9016:	mov    %rcx,%rsi
 29d9019:	shr    $0x1,%rsi
 29d901d:	mov    %rcx,%rdx
 29d9020:	and    $0x1,%rdx
 29d9024:	or     %rsi,%rdx
 29d9027:	cvtsi2sd %rdx,%xmm0
 29d902c:	addsd  %xmm0,%xmm0
 29d9030:	movq   %xmm0,%rcx
 29d9035:	mov    %rcx,0x68(%rsp)
 29d903a:	xor    %edx,%edx
 29d903c:	mov    %rdx,%rsi
 29d903f:	mov    %rdx,%rdi
 29d9042:	mov    0x68(%rsp),%rcx
 29d9047:	mov    0xa0(%rsp),%rbx
 29d904f:	mov    0xa8(%rsp),%r12
 29d9057:	mov    0xb0(%rsp),%r13
 29d905f:	mov    0xb8(%rsp),%r14
 29d9067:	mov    0xc0(%rsp),%r15
 29d906f:	add    $0xd0,%rsp
 29d9076:	mov    %rbp,%rsp
 29d9079:	pop    %rbp
 29d907a:	ret    $0x10
 29d907d:	mov    %r10,%r14
 29d9080:	mov    %r14,%rdi
 29d9083:	call   3018d19 <wasmtime_builtin_new_epoch>
 29d9088:	mov    %rax,0x58(%rsp)
 29d908d:	jmp    29d8751 <wasm[0]::function[1010]::helper::array_packed_push1+0x91>
 29d9092:	mov    0x8(%rbx),%rax
 29d9096:	cmp    %rax,%rcx
 29d9099:	jb     29d8b54 <wasm[0]::function[1010]::helper::array_packed_push1+0x494>
 29d909f:	mov    %r14,%rdi
 29d90a2:	call   3018d19 <wasmtime_builtin_new_epoch>
 29d90a7:	mov    %rax,0x58(%rsp)
 29d90ac:	jmp    29d8b59 <wasm[0]::function[1010]::helper::array_packed_push1+0x499>
 29d90b1:	mov    0x8(%rbx),%rax
 29d90b5:	mov    %rax,0x58(%rsp)
 29d90ba:	cmp    %rax,%r9
 29d90bd:	jb     29d8d39 <wasm[0]::function[1010]::helper::array_packed_push1+0x679>
 29d90c3:	mov    %r14,%rdi
 29d90c6:	call   3018d19 <wasmtime_builtin_new_epoch>
 29d90cb:	mov    %rax,0x58(%rsp)
 29d90d0:	mov    0x88(%rsp),%r12
 29d90d8:	jmp    29d8d41 <wasm[0]::function[1010]::helper::array_packed_push1+0x681>
 29d90dd:	ud2
 29d90df:	ud2
 29d90e1:	ud2
 29d90e3:	ud2
 29d90e5:	ud2
 29d90e7:	ud2
 29d90e9:	ud2
 29d90eb:	ud2
 29d90ed:	ud2
 29d90ef:	ud2
 29d90f1:	ud2
 29d90f3:	ud2
 29d90f5:	ud2
 29d90f7:	ud2
 29d90f9:	ud2
 29d90fb:	ud2
 29d90fd:	ud2
 29d90ff:	ud2
 29d9101:	ud2
 29d9103:	ud2
 29d9105:	ud2
 29d9107:	ud2
 29d9109:	ud2
 29d910b:	ud2
 29d910d:	ud2
 29d910f:	ud2
 29d9111:	ud2
 29d9113:	ud2
 29d9115:	ud2
 29d9117:	ud2
 29d9119:	add    %al,(%rax)
 29d911b:	add    %al,(%rax)
 29d911d:	add    %al,(%rax)
 29d911f:	add    %bh,%bh
 29d9121:	(bad)
 29d9122:	(bad)
 29d9123:	incl   (%rax)
 29d9125:	add    %al,(%rax)
	...
