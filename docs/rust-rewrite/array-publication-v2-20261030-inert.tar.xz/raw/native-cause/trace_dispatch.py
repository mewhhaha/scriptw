"""Reproduce the manually established valid-mode3 dispatch paths from inert objdump output."""
from pathlib import Path
import hashlib
import json
import re

OUT = Path(__file__).resolve().parent
RANGES = {
    'baseline': [(0x29d4881,0x29d48b9),(0x29d5666,0x29d5681),(0x29d5699,0x29d571f),(0x29d5de9,0x29d5e2f)],
    'candidate': [(0x29d4867,0x29d48aa),(0x29d5e1f,0x29d5e22)],
}
report = {
    'scope': 'Manually traced static path for valid already-PackedValues storage, from first storage MODE load through the final common Values writer dispatch. Not dynamic sampling, cycles, or a complete invocation. Numeric bodies are skipped; null/capacity checks take their valid-reference paths.',
    'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'products': {},
}
for label, ranges in RANGES.items():
    source = OUT / label / 'helper__array_indexed_publish_default_data.asm'
    insns = []
    for line in source.read_text().splitlines():
        m = re.match(r'\s*([0-9a-f]+):\s+(.*)', line)
        if m:
            insns.append((int(m[1],16),m[2]))
    path = [i for low, high in ranges for i in insns if low <= i[0] <= high]
    assert all(any(address == low for address, _ in path) and any(address == high for address, _ in path) for low, high in ranges)
    branches = [(address, text) for address, text in path if text.split()[0].startswith('j')]
    conditional = [(address, text) for address, text in branches if text.split()[0] != 'jmp']
    loads = [(address, text) for address, text in path if re.match(r'mov\s+0x24\(%\w+\),%',text)]
    report['products'][label] = {
        'assembly_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
        'address_ranges': [[hex(low),hex(high)] for low,high in ranges],
        'instructions': len(path),
        'stack_referencing_instructions': sum('%rsp' in text for _,text in path),
        'branches': len(branches),
        'conditional_branches': len(conditional),
        'unconditional_branches': len(branches)-len(conditional),
        'storage_mode_loads': len(loads),
        'mode_load_listing': [f'{hex(address)} {text}' for address,text in loads],
        'branch_listing': [f'{hex(address)} {text}' for address,text in branches],
        'listing': [f'{hex(address)} {text}' for address,text in path],
    }
assert report['products']['baseline']['instructions'] == 65
assert report['products']['candidate']['instructions'] == 15
report['common_writer'] = {
    'candidate_initial_values_edge': '0x29d48aa jumps to 0x29d5e1f',
    'candidate_promotion_ready': '0x29d59f4 assigns readiness 1; 0x29d59f9 preserves it at stack+0x98',
    'candidate_promotion_publication': '0x29d5e06 publishes VALUES; 0x29d5e09 publishes mode3; falls through to 0x29d5e1f',
    'candidate_shared_ready_guard': '0x29d5e1f test readiness; 0x29d5e22 branches to writer at 0x29d5e3a',
    'candidate_shared_values_load': '0x29d5e6c loads storage VALUES at offset0x30',
    'interpretation': 'The initial Values path and successful numeric promotion converge on this one native writer. The encoded-Wasm structural test independently guards one emitted packed Values writer; this trace does not infer duplication from a raw x86 store count.',
}
report['gc_dereference_interpretation'] = 'Before entering the writer, representation classification uses three storage GC-reference dereference/mode-load stages in baseline and one in v2. The initial pointer conversion occurs before the chosen first-mode-load boundary; two repeated conversions are removed. The shared writer still dereferences storage for VALUES and then its backing, which is excluded from both dispatch counts.'
(OUT/'packed-values-dispatch-path.json').write_text(json.dumps(report,indent=2)+'\n')
for label,result in report['products'].items():
    print(label, {key:result[key] for key in ('instructions','stack_referencing_instructions','branches','conditional_branches','unconditional_branches','storage_mode_loads')})
