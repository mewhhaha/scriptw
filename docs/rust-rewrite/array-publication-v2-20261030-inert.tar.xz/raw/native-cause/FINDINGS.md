# Frozen v2 native comparison

This is inert static inspection of the exact frozen compiler-precompiled hosts, not timing or sampled execution. No native payload was loaded or executed. The original v1 diagnostic directory was left untouched.

## Provenance

The extractor verifies the host SHA against both products.json and identity.json; validates the host ELF; checks the execution receipt checksum and ABI40; binds receipt source/key/package hash to the portable manifest and its target; and verifies SWRTZ001 magic, decoded length, and native SHA. Both manifests use configuration4 and mode bytes [1,3,1].

baseline:
- ABI: 40
- Source fingerprint: `cf48836cd6550acc4e8450bc1194d4a9416f07123fa97ccd6c5752e783667070`
- Frozen host SHA256: `03cd9be685269d039bf879476cb5eb0f7050b1140435ee7475937c4be6cb5ee1`
- Native ELF SHA256: `c56ad0e431ee7916530aebc79cd38a3d193d232f575f96dd12db52bbaa9a6ac4`
- Runtime key: `bd267cdbd71d687df140ef9aeb8d01260cfc9d2a63281b1cccbabb30a563496d`
- Native ELF bytes: 66058392

candidate:
- ABI: 40
- Source fingerprint: `7401427ac8d4c60b044b079b3264578dbff20bcb223600822f46e25752426d2a`
- Frozen host SHA256: `8c102e022b42c04a673a2e74075e08c370a0a51caadbdffe53d1197d91abf998`
- Native ELF SHA256: `92e99e724e6e2cb9ebd21462cb27c4f3723a5c2cbd7f18d87bb7fdfe43e547ab`
- Runtime key: `09f004b3218b6402d8294667d8415d7f0cd9f21ec2a4ae43ca28be382c027283`
- Native ELF bytes: 66062472

## Existing PackedValues dispatch

The path starts with the first storage mode load and ends at the branch entering the common Values writer. The two valid-pointer conversion stages that baseline repeats during classification disappear. This is a partial invocation; the necessary storage/VALUES backing dereferences inside the writer are excluded from both path counts.

| Metric | Baseline | v2 |
| --- | ---: | ---: |
| Static instructions | 65 | 15 |
| Branches | 10 | 3 |
| Conditional branches | 8 | 2 |
| Stack-referencing instructions | 22 | 6 |
| Storage classification mode loads/dereference stages | 3 | 1 |

The initial Values branch jumps to 0x29d5e1f. Successful numeric promotion stores readiness1, publishes VALUES and mode3, then falls through to the same address. The shared readiness branch enters one writer at 0x29d5e3a, with VALUES loaded at 0x29d5e6c. The encoded-Wasm structural assertion independently prevents duplicating the writer.

## Function footprint

| Function | Bytes baseline → v2 | Entry stack bytes baseline → v2 | Body instructions baseline → v2 |
| --- | ---: | ---: | ---: |
| helper::array_packed_join | 6416 → 6416 | 272 → 272 | 1507 → 1507 |
| helper::array_indexed_publish_default_data | 9950 → 9780 | 272 → 272 | 2274 → 2221 |
| helper::array_packed_push1 | 2664 → 2664 | 208 → 208 | 673 → 673 |
| helper::array_indexed_publish | 21632 → 21688 | 256 → 272 | 5061 → 5071 |
| helper::array_indexed_delete | 4392 → 4392 | 144 → 144 | 1168 → 1168 |
| helper::object_read | 113136 → 113136 | 800 → 800 | 24676 → 24676 |
| helper::object_write | 1824 → 1824 | 224 → 224 | 469 → 469 |
| builtin::Array.prototype.push | 5600 → 5600 | 304 → 304 | 1317 → 1317 |
| builtin::Array.prototype.join | 11168 → 11168 | 384 → 384 | 2374 → 2374 |

Equal sizes and instruction counts do not imply identical relocated machine bytes.

## Disposition

The produced native code implements the intended dispatch reduction without duplicating the Values writer. Proceed to the planned semantic and timing gate. This static result establishes the mechanism, not an accepted speedup.

Carry two concerns into measurement: the general descriptor publisher adds16 entry-stack bytes and56 code bytes; numeric arrays now encounter an initial Values readiness classification. Keep numeric, descriptor, ordinary, retained-call, startup, and size controls under the same no-reproducible-material-regression rule. No additional source change is justified by this inspection.

Reproduce extraction with inspect.py and the path-count report with trace_dispatch.py. The exact address ranges and listings are in packed-values-dispatch-path.json.
