"""Repeat the unchanged host campaign in the opposite balanced order."""
from pathlib import Path
import hashlib
import importlib.util
import json
import sys

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
import measure

OUT = BASE / 'confirmation'
OUT.mkdir()
links = {}
for name in ('baseline', 'candidate', 'baseline-images', 'candidate-images'):
    target = (BASE / name).resolve()
    assert target.is_dir() and not target.is_symlink()
    (OUT / name).symlink_to(target, target_is_directory=True)
    links[name] = str(target)
(OUT / 'shared-inputs.json').write_text(json.dumps({
    'immutable_shared_inputs': links,
    'initial_campaign': str(BASE),
    'initial_harness_sha256': hashlib.sha256((BASE / 'run-measurements.py').read_bytes()).hexdigest(),
    'change': 'Only the raw output directory and order change: BAAB then ABBA. Hosts, images, fixtures, samples, warmups and runtime/resource settings remain identical.'
}, indent=2) + '\n')
measure.WORK = OUT
spec = importlib.util.spec_from_file_location('dense_numbers_campaign', BASE / 'run-measurements.py')
campaign = importlib.util.module_from_spec(spec)
spec.loader.exec_module(campaign)
campaign.WORK = OUT
campaign.EXTRA = OUT / 'numeric-fallback-fixture'
campaign.ORDER = ('candidate', 'baseline', 'baseline', 'candidate', 'baseline', 'candidate', 'candidate', 'baseline')
# The original analyzer labels its two four-round groups by their original
# order. Correct only those labels in the separately derived repeat report.
campaign.run()
report = json.loads((OUT / 'analysis.json').read_text())
for row in report['workloads']:
    for boundary in ('retained', 'ordinary'):
        if boundary in row:
            for group, label in zip(row[boundary]['balanced_orders'], ('BAAB', 'ABBA')):
                group['order'] = label
for group, label in zip(report['startup']['balanced_orders'], ('BAAB', 'ABBA')):
    group['order'] = label
(OUT / 'analysis.json').write_text(json.dumps(report, indent=2) + '\n')
