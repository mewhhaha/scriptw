#[path = "/workspace/scriptw/crates/scriptw-engine/tests/structure/wasm_execution_mode_structure.rs"]
mod wasm_execution_mode_structure;
