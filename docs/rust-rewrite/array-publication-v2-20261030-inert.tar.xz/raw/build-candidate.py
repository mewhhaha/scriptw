from pathlib import Path
import hashlib,json,os,shutil,subprocess,time,sys
sys.path.insert(0,"/workspace/scriptw/scripts")
from verification_identity import source_map
ROOT=Path('/workspace/scriptw'); OUT=ROOT/'target/performance-dense-numbers-20261030/v2'
argv=['cargo','build','--release','--offline','--locked','-p','scriptw-cli','--bin','scriptw','--example','runtime_baseline','--example','compiler_precompiled_baseline','--message-format=json']
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
before = source_map(ROOT)
t0=time.time_ns()
with (OUT/'candidate-cargo.jsonl').open('xb') as out,(OUT/'candidate-build.stderr').open('xb') as err:
 result=subprocess.run(argv,cwd=ROOT,stdout=out,stderr=err)
receipt={'argv':argv,'head':head,'exit_code':result.returncode,'elapsed_ns':time.time_ns()-t0,'cloud_affinity':sorted(os.sched_getaffinity(0))}
(OUT/'candidate-build.json').write_text(json.dumps(receipt,indent=2)+'\n')
assert result.returncode==0
assert head==subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
assert source_map(ROOT) == before
products={}
for line in (OUT/'candidate-cargo.jsonl').open():
 r=json.loads(line)
 if r.get('reason')=='compiler-artifact' and r.get('executable') and r['target']['name'] in ('scriptw','runtime_baseline','compiler_precompiled_baseline'):
  products[r['target']['name']]=r
assert len(products)==3
receipt['source_map']=before
(OUT/'candidate-build.json').write_text(json.dumps(receipt,indent=2)+'\n')
frozen=OUT/'candidate';frozen.mkdir()
for name,r in products.items():
 src=Path(r['executable']); dest=frozen/name
 shutil.copy2(src,dest);assert src.stat().st_ino!=dest.stat().st_ino and dest.stat().st_nlink==1
 products[name]={'sha256':digest(dest),'bytes':dest.stat().st_size,'cargo_producer':r}
(frozen/'products.json').write_text(json.dumps(products,indent=2)+'\n')
p=subprocess.run([str(frozen/'compiler_precompiled_baseline'),'identity'],cwd=ROOT,capture_output=True,check=True)
(frozen/'identity.json').write_bytes(p.stdout)
assert json.loads(p.stdout)['source_commit']==head
print(json.dumps({'head':head,'products':{k:v['sha256'] for k,v in products.items()}},indent=2),flush=True)
