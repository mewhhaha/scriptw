"""Run existing hosts in both balanced orders; keep every checked observation."""
from measure import WORK, ROOT, FIXTURES, PLAN, invoke, digest
from pathlib import Path
import json
import os
import statistics

ORDER = ('baseline', 'candidate', 'candidate', 'baseline', 'candidate', 'baseline', 'baseline', 'candidate')
SAMPLES = 21
WARMUPS = 10
EXTRA = WORK / 'numeric-fallback-fixture'
NAME = 'numeric-join-fallback.js'
EXPECTED = '7168\n'

def prepare_extra():
    EXTRA.mkdir()
    (EXTRA / NAME).write_text('(function workload(){var a=[1,2,3,4],s=0;for(var i=0;i<1024;i++)s+=a.join(",").length;print(s);})();\n')
    (EXTRA / 'manifest.json').write_text(json.dumps({'execution': [{'file': NAME, 'stdout': EXPECTED, 'work': 'separate diagnostic of numeric-element generic join fallback; not an original 17-case fixture'}]}, indent=2) + '\n')

def run():
    prepare_extra()
    resources = {'order': ORDER, 'affinity': sorted(os.sched_getaffinity(0)), 'cgroup': {n: (Path('/sys/fs/cgroup') / n).read_text().strip() for n in ('memory.max','memory.swap.max','memory.oom.group','cpu.max','memory.events')}, 'cache_dir': os.environ.get('SCRIPTW_CACHE_DIR'), 'rounds': []}
    for r, label in enumerate(ORDER):
        entry = {'round': r, 'product': label, 'load_average_before': os.getloadavg()}
        images = WORK / f'round-{r}-ordinary-wasm'
        images.mkdir()
        for i in range(SAMPLES + WARMUPS):
            invoke(f'round-{r}-{label}-startup-{i}', [WORK / label / 'scriptw', 'run', FIXTURES / PLAN['startup']['file']], timeout=60, expected=PLAN['startup']['stdout'] + 'run outcome: RunOutcome { backend_used: WasmAot, note: "wasm-aot completion: undefined(undefined)" }\n')
        for case in PLAN['execution']:
            name = case['file']
            invoke(f'round-{r}-{label}-retained-{name}', [WORK / label / 'compiler_precompiled_baseline', 'execute-retained', WORK / (label + '-images') / (name + '.retained.swpc'), case['stdout'], str(SAMPLES), str(WARMUPS)])
            invoke(f'round-{r}-{label}-ordinary-{name}', [WORK / label / 'runtime_baseline', FIXTURES, str(SAMPLES), str(WARMUPS), name, images])
        invoke(f'round-{r}-{label}-ordinary-{NAME}', [WORK / label / 'runtime_baseline', EXTRA, str(SAMPLES), str(WARMUPS), NAME, images])
        entry['load_average_after'] = os.getloadavg()
        resources['rounds'].append(entry)
        (WORK / 'measurement-resources.json').write_text(json.dumps(resources, indent=2) + '\n')
    analyze()

def comparison(products):
    pooled = {label: statistics.median([v for row in rows for v in row['samples_ns']]) for label, rows in products.items()}
    groups = []
    for start, stop, name in [(0, 4, 'ABBA'), (4, 8, 'BAAB')]:
        medians = {label: statistics.median([v for row in rows if start <= row['round'] < stop for v in row['samples_ns']]) for label, rows in products.items()}
        groups.append({'order': name, 'median_ns': medians, 'change_percent': 100 * (medians['candidate'] / medians['baseline'] - 1)})
    return {'products': products, 'median_ns': pooled, 'change_percent': 100 * (pooled['candidate'] / pooled['baseline'] - 1), 'balanced_orders': groups}

def analyze():
    identities = {label: json.loads((WORK / label / 'identity.json').read_text()) for label in ('baseline','candidate')}
    artifacts = {label: json.loads((WORK / label / 'products.json').read_text()) for label in identities}
    producers = {label: {c['file']: c for c in json.loads((WORK / (label + '-images') / 'producer.json').read_text())['cases']} for label in identities}
    assert identities['baseline']['shared_configuration'] == identities['candidate']['shared_configuration']
    workloads = []
    for case in [*PLAN['execution'], {'file': NAME, 'stdout': EXPECTED}]:
        name = case['file']
        row = {'file': name, 'original_17_case_fixture': name != NAME}
        for boundary in (('retained','ordinary') if name != NAME else ('ordinary',)):
            products = {label: [] for label in identities}
            for r, label in enumerate(ORDER):
                stem = f'round-{r}-{label}-{boundary}-{name}'
                value = json.loads((WORK / (stem + '.stdout')).read_text())
                host = 'compiler_precompiled_baseline' if boundary == 'retained' else 'runtime_baseline'
                assert value['executable_sha256'] == artifacts[label][host]['sha256']
                assert value['source_fingerprint'] == identities[label]['source_fingerprint']
                obs = value['observations'] if boundary == 'retained' else value['cases'][0]['observations']
                assert len(obs) == SAMPLES + WARMUPS and all(v['stdout'] == case['stdout'] and v.get('matched',True) for v in obs)
                samples = [v['call_ns' if boundary == 'retained' else 'execution_ns'] for v in obs if not v['warmup']]
                assert len(samples) == SAMPLES
                command = json.loads((WORK / (stem + '.command.json')).read_text())
                item = {'round': r, 'median_ns': statistics.median(samples), 'samples_ns': samples, 'process_lifetime_peak_rss_bytes': command['peak_rss_bytes'], 'raw': stem + '.stdout'}
                products[label].append(item)
            row[boundary] = comparison(products)
        if name != NAME:
            for field in ('original_source_sha256','derived_source_sha256','stdout'):
                assert producers['baseline'][name][field] == producers['candidate'][name][field]
            row['original_source_sha256'] = producers['baseline'][name]['original_source_sha256']
        else:
            row['original_source_sha256'] = digest(EXTRA / NAME)
        workloads.append(row)
    products = {label: [] for label in identities}
    for r, label in enumerate(ORDER):
        rows = [json.loads((WORK / f'round-{r}-{label}-startup-{i}.command.json').read_text()) for i in range(WARMUPS, WARMUPS + SAMPLES)]
        assert all(v['exit_code']==0 and not v['timed_out'] and v['executable_sha256']==artifacts[label]['scriptw']['sha256'] for v in rows)
        products[label].append({'round': r, 'median_ns': statistics.median(v['elapsed_ns'] for v in rows), 'samples_ns': [v['elapsed_ns'] for v in rows], 'process_lifetime_peak_rss_bytes': [v['peak_rss_bytes'] for v in rows]})
    report = {'order': ORDER, 'samples_per_round': SAMPLES, 'warmups_per_round': WARMUPS, 'workloads': workloads, 'startup': comparison(products), 'scope': 'same-machine default-feature diagnostic; original ordinary scripts and separately derived strict retained-call modules; numeric join fallback is a separate diagnostic, not part of the original 17 cases; no V8/Scriptc parity claim', 'memory_scope': 'whole-child high-water RSS includes admission/setup/warmups; raw ordinary records also retain sampled invocation RSS and GC capacity; neither is live JS bytes or per-call memory'}
    (WORK / 'analysis.json').write_text(json.dumps(report, indent=2) + '\n')
    for row in workloads:
        print(row['file'], {boundary: [round(g['change_percent'],1) for g in row[boundary]['balanced_orders']] for boundary in ('retained','ordinary') if boundary in row}, flush=True)
    print('startup', [round(g['change_percent'],1) for g in report['startup']['balanced_orders']], flush=True)

if __name__ == '__main__':
    import sys
    if sys.argv[1] == 'run': run()
    elif sys.argv[1] == 'analyze': analyze()
