(function workload(){var a=[1,2,3,4],s=0;for(var i=0;i<1024;i++)s+=a.join(",").length;print(s);})();
