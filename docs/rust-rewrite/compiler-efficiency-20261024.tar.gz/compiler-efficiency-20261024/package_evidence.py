import pathlib,json,hashlib,tarfile,io,os
root=pathlib.Path('/home/mewhhaha/src/porffor');base=root/'target/compiler-efficiency-20261024';output=root/'docs/rust-rewrite/compiler-efficiency-20261024.tar.gz';report=json.loads((base/'checkpoint.json').read_text());assert report['test262']['complete'] and report['test262']['matches_known_failures'];assert not output.exists();os.sched_setaffinity(0,{min(os.sched_getaffinity(0))})
def digest(path):
 with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def admitted(path):
 if not path.is_file() or path.is_symlink():return False
 rel=path.relative_to(base)
 if any(p in {'cache','execution-cache','hot-cache','tmp','__pycache__'} or p.startswith('cold-cache-') for p in rel.parts):return False
 return path.suffix in {'.json','.jsonl','.js','.rs','.attempts','.log','.stderr','.stdout','.py','.snapshot','.executions','.bundle','.txt','.gz'} or path.name in {'executions','batch-executions'}
paths=[]
for p in base.iterdir():
 if p.is_file() and admitted(p):paths.append(p)
 elif p.is_dir() and p.name.startswith(('native','focused','source-guards','engine-batches','regexp-batches','remaining','original-replay','regexp-baseline-check','workload-validation','product-build')):
  paths.extend(f for f in p.rglob('*') if admitted(f))
watch=base/'source/target/watched';paths.extend(f for f in watch.iterdir() if f.is_file() and f.suffix=='.log');paths=sorted(set(paths));assert all(p.stat().st_size<64*1024*1024 for p in paths)
rows=[{'path':str(p.relative_to(base)),'bytes':p.stat().st_size,'sha256':digest(p)} for p in paths];manifest={'schema':'scriptw-compiler-efficiency-evidence-v1','prefix':'compiler-efficiency-20261024/','source_commit':report['source_commit'],'members':rows,'excluded':'Compiler/test executables, caches, temporary trees and vendored source are omitted. tested-source.bundle contains the exact source changes over0443509f3.'};data=(json.dumps(manifest,indent=2)+'\n').encode();prefix=manifest['prefix']
with tarfile.open(output,'w:gz',compresslevel=6) as archive:
 for path,row in zip(paths,rows):
  assert path.stat().st_size==row['bytes'] and digest(path)==row['sha256'];info=archive.gettarinfo(str(path),arcname=prefix+row['path']);info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0;info.mode=0o644
  with path.open('rb') as f:archive.addfile(info,f)
 info=tarfile.TarInfo(prefix+'archive-members.json');info.size=len(data);info.mode=0o644;archive.addfile(info,io.BytesIO(data))
expected={prefix+r['path']:r for r in rows};seen=set()
with tarfile.open(output,'r:gz') as archive:
 for member in archive:
  assert member.isfile() and member.name not in seen;seen.add(member.name)
  if member.name==prefix+'archive-members.json':assert archive.extractfile(member).read()==data;continue
  row=expected[member.name];assert member.size==row['bytes'];assert hashlib.file_digest(archive.extractfile(member),'sha256').hexdigest()==row['sha256']
assert seen==set(expected)|{prefix+'archive-members.json'}
report['archive']={'file':output.name,'sha256':digest(output),'bytes':output.stat().st_size,'member_count':len(seen),'manifest_sha256':hashlib.sha256(data).hexdigest(),'expanded_bytes':sum(r['bytes'] for r in rows)+len(data)};report['source_bundle']={'member':prefix+'tested-source.bundle','sha256':digest(base/'tested-source.bundle'),'prerequisite':'0443509f370dde7ed1a2c690770e9111ddb5a1f9'};public=root/'docs/rust-rewrite/compiler-efficiency-20261024.json';assert not public.exists();public.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report['archive'],indent=2))
