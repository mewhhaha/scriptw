import pathlib,json,subprocess,os,time
base=pathlib.Path('/home/mewhhaha/src/porffor/target/compiler-efficiency-20261024');source=base/'source'
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip();output=base/('native-'+head[:9]);assert not output.exists()
previous=json.loads((base/'native/receipt.json').read_text())
targets=[c['package']+':'+c['target'] for c in previous['cases'] if (c['package'],c['target'])!=('scriptw-engine','scriptw_engine')];assert len(targets)==65
command=['python3','-B','scripts/run_workspace_tests.py','--profile','release','--include-ignored','--test-processes','1','--build-selected-together','--preserve-test-artifacts','--packages','scriptw-front','scriptw-ir','scriptw-aot-wasm','scriptw-engine','scriptw-runtime-image','scriptw-cli','--only-targets',*targets,'--output',str(output)]
started=time.monotonic();result=subprocess.run(command,cwd=source)
group=pathlib.Path('/sys/fs/cgroup')/next(s[3:] for s in pathlib.Path('/proc/self/cgroup').read_text().splitlines() if s.startswith('0::')).lstrip('/')
report={'command':command,'source':head,'exit':result.returncode,'elapsed_seconds':time.monotonic()-started,'affinity':sorted(os.sched_getaffinity(0)),'resources':{n:(group/n).read_text().strip() for n in ['memory.max','memory.peak','memory.swap.max','memory.oom.group','memory.events']},'excluded_scope':'scriptw-engine:scriptw_engine; separate bounded-process execution required'}
(base/('native-'+head[:9]+'-resources.json')).write_text(json.dumps(report,indent=2)+'\n');raise SystemExit(result.returncode)
