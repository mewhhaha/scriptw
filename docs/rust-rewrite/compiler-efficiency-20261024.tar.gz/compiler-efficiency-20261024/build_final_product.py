import pathlib,json,subprocess,os,time,hashlib,shutil
base=pathlib.Path('/home/mewhhaha/src/porffor/target/compiler-efficiency-20261024');source=base/'source';head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip();assert not subprocess.check_output(['git','status','--porcelain'],cwd=source)
output=base/('product-build-'+head[:9]);output.mkdir(exist_ok=False)
command=['cargo','build','--locked','--offline','--release','-p','scriptw-cli','--bin','scriptw','--example','runtime_baseline','--jobs','1','--message-format=json'];start=time.monotonic()
with (output/'cargo.jsonl').open('x') as stdout,(output/'build.stderr').open('x') as stderr:result=subprocess.run(command,cwd=source,stdout=stdout,stderr=stderr)
group=pathlib.Path('/sys/fs/cgroup')/next(s[3:] for s in pathlib.Path('/proc/self/cgroup').read_text().splitlines() if s.startswith('0::')).lstrip('/')
report={'command':command,'source':head,'exit':result.returncode,'elapsed_seconds':time.monotonic()-start,'affinity':sorted(os.sched_getaffinity(0)),'resources':{n:(group/n).read_text().strip() for n in ['memory.max','memory.peak','memory.swap.max','memory.oom.group','memory.events']},'products':[]}
if result.returncode==0:
 for s in (output/'cargo.jsonl').read_text().splitlines():
  r=json.loads(s)
  if r.get('reason')!='compiler-artifact' or not r.get('executable') or r['target']['name'] not in ['scriptw','runtime_baseline']:continue
  assert r['profile']['opt_level']=='3' and not r['profile']['test'] and not r['features'];p=pathlib.Path(r['executable']);dst=output/p.name;shutil.copy2(p,dst);report['products'].append({'name':p.name,'producer_executable':str(p),'retained_executable':str(dst),'sha256':hashlib.sha256(dst.read_bytes()).hexdigest(),'bytes':dst.stat().st_size})
 assert {r['name'] for r in report['products']}=={'scriptw','runtime_baseline'}
(output/'receipt.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2));raise SystemExit(result.returncode)
