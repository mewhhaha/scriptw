
    /^\p{Basic_Emoji}$/iv.test('\u24DC\uFE0F') &&
    /^\p{RGI_Emoji}$/iv.test('\u24DC\uFE0F') &&
    /^[\p{Basic_Emoji}&&\q{\u24C2\uFE0F}]$/iv.test('\u24DC\uFE0F') &&
    /^[\p{RGI_Emoji}&&\q{\u24DC\uFE0F}]$/iv.test('\u24C2\uFE0F') &&
    !/^[\p{Basic_Emoji}--\q{\u24DC\uFE0F}]$/iv.test('\u24C2\uFE0F') &&
    !/^[\q{\u24C2\uFE0F}--\p{RGI_Emoji}]$/iv.test('\u24DC\uFE0F') &&
    /^\p{Basic_Emoji}$/v.test('\u24C2\uFE0F') &&
    !/^\p{Basic_Emoji}$/v.test('\u24DC\uFE0F') &&
    /^(?i:[\p{Basic_Emoji}&&\q{\u24DC\uFE0F}])$/v.test('\u24C2\uFE0F') &&
    !/^(?-i:[\p{RGI_Emoji}&&\q{\u24DC\uFE0F}])$/iv.test('\u24C2\uFE0F');
    
