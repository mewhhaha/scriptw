import pathlib,json,subprocess,os,time,hashlib,sys
base=pathlib.Path('/home/mewhhaha/src/porffor/target/compiler-efficiency-20261024');source=base/'source';head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip();output=base/('remaining2-'+head[:9]);output.mkdir(exist_ok=False);os.sched_setaffinity(0,{min(os.sched_getaffinity(0))});native=json.loads((base/('native-'+head[:9])/'receipt.json').read_text());pending=json.loads((base/('native-pending-'+head[:9])/'receipt.json').read_text());done=[c for c in native['cases'] if c.get('state')=='passed'];assert len(done)==35 and len(pending['cases'])==29 and all(c['state']=='passed' for c in pending['cases']);assert native['source_map_sha256']==pending['source_map_sha256'] and native['head']==pending['head']==head and pending['source_unchanged'];keys=lambda cases:{(c['package'],c['target']) for c in cases};assert not keys(done)&keys(pending['cases']) and keys(done)|keys(pending['cases'])==keys(native['cases'])-{('scriptw-engine','aot_regexp')}
sys.path.insert(0,str(source/'scripts'))
from verification_identity import source_map,file_sha256
assert native['source_unchanged'] and hashlib.sha256(json.dumps(source_map(source),sort_keys=True).encode()).hexdigest()==native['source_map_sha256']
for case in [*done,*pending['cases']]:
 assert case['exit_code']==0 and case['inventory_matches'] is True
 assert case['outcomes']==[{'passed':case['inventoried_tests'],'failed':0,'ignored':0}]
 for role in ['inventory','transcript']:
  path=pathlib.Path(case[role+'_log']);path=path if path.is_absolute() else source/path
  assert file_sha256(path)==case[role+'_sha256']

receipt={'source':head,'phases':[],'complete':False}
for name,capped in [('run_regexp_batches2.py',False),('run_engine_batches.py',False),('build_final_product.py',True),('validate_workloads.py',True),('run_original_replay.py',True)]:
 command=['python3','-B',str(base/name)]
 if capped:command=['python3','-B','scripts/limited_verification.py','--',*command]
 row={'script':name,'command':command,'state':'running'};receipt['phases'].append(row);(output/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print('PHASE START',name,flush=True);start=time.monotonic()
 with (output/(name+'.stdout')).open('x') as stdout,(output/(name+'.stderr')).open('x') as stderr:result=subprocess.run(command,cwd=source,stdout=stdout,stderr=stderr)
 row.update(exit_code=result.returncode,state='passed' if result.returncode==0 else 'failed-or-incomplete',elapsed_seconds=time.monotonic()-start);(output/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print('PHASE END',name,'exit',result.returncode,flush=True)
 if result.returncode:
  if name in ['run_engine_batches.py','run_regexp_batches2.py']:
   batch=json.loads((base/(('engine-batches-' if name=='run_engine_batches.py' else 'regexp-batches2-')+head[:9])/'receipt.json').read_text());failed=[g for g in batch['groups'] if g['state']!='passed'];allowed={n for n in batch['inventory'] if n.startswith('runtime_profile::native_mode_cohort_tests::') and n.endswith(('explicit_16_and_32_mib_controls_access_the_same_matching_image_owner','explicit_speed_capacity_profile_preserves_gc_roots_and_fresh_realm_state','forced_modes_are_reported_exactly_and_reuse_only_their_own_cached_modules'))};allowed=allowed if name=='run_engine_batches.py' else {'aot_regexp_iv_class_strings::property_and_direct_strings_fold_circled_m_before_algebra'};assert batch.get('all_groups_attempted') and batch['source_unchanged'] and batch['executable_unchanged'] and failed and all(g['exit_code'] in (-9,137) and g.get('kernel_oom_confirmed') is True and len(g['ids'])==1 and g['ids'][0] in allowed for g in failed);row['continuation_reason']='Only explicitly retained isolated native stress/diagnostic memory interruptions; other required verification continues. Overall native checkpoint remains incomplete.'
  else:raise SystemExit(result.returncode)
receipt['complete']=all(r['exit_code']==0 for r in receipt['phases']);(output/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');raise SystemExit(0 if receipt['complete'] else 1)
