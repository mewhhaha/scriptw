import pathlib,json,hashlib,sys,collections,re,subprocess
root=pathlib.Path('/home/mewhhaha/src/porffor');base=root/'target/compiler-efficiency-20261024';source=base/'source';head=json.loads((base/'snapshot.json').read_text())['commit'];sys.path.insert(0,str(source/'scripts'));from native_test_protocol import test_names
from verification_identity import file_sha256,source_map
old=json.loads((base/('native-'+head[:9])/'receipt.json').read_text());pending=json.loads((base/('native-pending-'+head[:9])/'receipt.json').read_text());engine=json.loads((base/('engine-batches-'+head[:9])/'receipt.json').read_text());regexp=json.loads((base/('regexp-batches2-'+head[:9])/'receipt.json').read_text());build=json.loads((base/('product-build-'+head[:9])/'receipt.json').read_text());fixtures=json.loads((base/('workload-validation-'+head[:9])/'receipt.json').read_text());replay=json.loads((base/('original-replay-'+head[:9])/'acceptance.json').read_text())
assert old['head']==pending['head']==engine['source_commit']==regexp['source_commit']==build['source']==fixtures['source']==replay['source']==head
assert old['source_unchanged'] and pending['source_unchanged']
assert old['source_map_sha256']==pending['source_map_sha256']==hashlib.sha256(json.dumps(source_map(source),sort_keys=True).encode()).hexdigest()
expected_oom='aot_regexp_iv_class_strings::property_and_direct_strings_fold_circled_m_before_algebra'
assert [n for g in regexp['groups'] if g['state']!='passed' for n in g['ids']]==[expected_oom]
baseline_root=base/'regexp-baseline-check';baseline=json.loads((baseline_root/'identity.json').read_text());baseline_result=json.loads((baseline_root/'result.json').read_text());baseline_build=json.loads((baseline_root/'original-build-receipt.json').read_text())
assert baseline['source']==baseline_result['source']==baseline_build['source']['head']=='559151e323dfba7a85d046dc0e1394d83798df69'
assert baseline['sha256']=='298aad24ef711bf65845f2aaa68afbb501258dc1f6bb6aa9b1a145569203bbd5' and baseline_build['source_unchanged'] and baseline_build['complete']
assert next(r['sha256'] for r in baseline_build['binaries'] if r['file']=='scriptw')==baseline['sha256']
assert baseline_result['kernel_oom_confirmed'] and baseline_result['actual_launcher_exit_code'] in (-9,137) and baseline_result['execution_reached'] is False
journal=(baseline_root/'kernel-journal.log').read_text();assert baseline_result['kernel_unit'] in journal and "Failed with result 'oom-kill'" in journal
text=(source/'crates/scriptw-engine/tests/aot_regexp/aot_regexp_iv_class_strings.rs').read_text();body=re.search(r'fn property_and_direct_strings_fold_circled_m_before_algebra\(\) \{.*?r#"(.*?)"#',text,re.S).group(1)
assert (baseline_root/'circled-m.js').read_text()==body+'\n' and file_sha256(baseline_root/'circled-m.js')==baseline['fixture_sha256']
assert subprocess.run(['git','diff','--exit-code',baseline['source'],'0443509f3','--','crates','Cargo.toml','Cargo.lock','.cargo','vendor'],cwd=source,stdout=subprocess.DEVNULL).returncode==0
assert pending['source_unchanged'] and engine['complete'] and regexp['all_groups_attempted'] and regexp['source_unchanged'] and regexp['executable_unchanged'];assert build['exit']==0 and fixtures['complete'] and replay['complete'] and replay['matches_known_failures'];rows=[];identities=[]
for case in [*[c for c in old['cases'] if c.get('state')=='passed'],*pending['cases']]:
 assert case['state']=='passed' and case['exit_code']==0 and case['inventory_matches']
 for role in ['inventory','transcript']:
  path=pathlib.Path(case[role+'_log']);path=path if path.is_absolute() else source/path;assert file_sha256(path)==case[role+'_sha256']
 p=pathlib.Path(case['inventory_log']);p=p if p.is_absolute() else source/p;names=test_names(p.read_text());assert len(names)==case['inventoried_tests'];qualified=case['package']+':'+case['target'];rows.append({'target':qualified,'kind':case['kind'],'inventoried':len(names),'passed':len(names),'incomplete':0});identities.extend(qualified+'::'+n for n in names)
for label,data in [('scriptw-engine:scriptw_engine',engine),('scriptw-engine:aot_regexp',regexp)]:
 all_ids=data['inventory']
 folder=base/(('engine-batches-' if label.endswith(':scriptw_engine') else 'regexp-batches2-')+head[:9])
 assert file_sha256(folder/'inventory.log')==data['inventory_sha256']
 for group in data['groups']:
  for role in ['transcript','resource']:
   assert file_sha256(folder/group[role+'_log'])==group[role+'_sha256']
 passed=[n for g in data['groups'] if g['state']=='passed' for n in g['ids']];bad=[g for g in data['groups'] if g['state']!='passed'];assert len(set(all_ids))==len(all_ids) and sorted(n for g in data['groups'] for n in g['ids'])==sorted(all_ids);assert all(g['exit_code'] in (-9,137) and g['kernel_oom_confirmed'] and len(g['ids'])==1 and all(x['outcome']=='ok' for x in g['outcomes']) for g in bad);rows.append({'target':label,'inventoried':len(all_ids),'passed':len(passed),'incomplete':sum(len(g['ids']) for g in bad),'incomplete_ids':[n for g in bad for n in g['ids']]});identities.extend(label+'::'+n for n in all_ids)
assert len(rows)==66 and len({r['target'] for r in rows})==66 and len(identities)==8407 and len(set(identities))==8407;assert sum(r['passed'] for r in rows)==8406 and sum(r['incomplete'] for r in rows)==1
inventory='\n'.join(sorted(identities))+'\n';(base/'verified-native-inventory.txt').write_text(inventory)
report={'schema':'scriptw-compiler-efficiency-checkpoint-v1','refresh_date':'2026-10-24','source_commit':head,'review_base':'0443509f370dde7ed1a2c690770e9111ddb5a1f9','native':{'scope_count':66,'inventory_count':8407,'passed':8406,'incomplete':1,'inventory_sha256':hashlib.sha256(inventory.encode()).hexdigest(),'complete':False,'targets':rows},'baseline_memory_control':{'identity':baseline,'result':baseline_result,'incomplete_native_test_id':expected_oom},'test262':replay,'workload_checks':{'count':16,'passed':16,'purpose':fixtures['purpose']},'product_build':build,'resources':{'memory_max_bytes':4294967296,'swap_max_bytes':0,'cpu_affinity':[0],'cargo_jobs':1,'libtest_threads':1,'test262_workers':1,'retained_module_cache_entries':1,'retained_module_cache_image_bytes':67108864},'performance':{'new_idle_machine_measurement':False,'readme_graph':'Historical measured source retained; no timing speedup claimed.'},'limitations':['One existing large-function RegExp native compilation exceeds4GiB on both current and product-source-identical pre-task compiler.','Selected Test262 executions do not replace the historical full pinned-suite chart.','See change documentation for boxed generic calls, conservative discovery and inference fallbacks.']}
(base/'checkpoint.json').write_text(json.dumps(report,indent=2)+'\n');print('Checkpoint counts verified:8406nativepassed+1incomplete;14931selectedTest262recorded;16fixtureoutputs.')
