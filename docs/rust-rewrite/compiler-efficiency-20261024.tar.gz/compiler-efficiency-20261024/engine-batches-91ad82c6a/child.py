import pathlib,json,os,subprocess,sys,time
plan=json.loads(pathlib.Path(sys.argv[1]).read_text());resource=pathlib.Path(plan["resource"])
group=pathlib.Path("/sys/fs/cgroup")/next(s[3:] for s in pathlib.Path("/proc/self/cgroup").read_text().splitlines() if s.startswith("0::")).lstrip("/")
def observe():return {"cgroup":str(group),"affinity":sorted(os.sched_getaffinity(0)),**{n:(group/n).read_text().strip() for n in ["memory.max","memory.peak","memory.swap.max","memory.oom.group","memory.events"]}}
r={"before":observe(),"command":plan["command"]};resource.write_text(json.dumps(r,indent=2)+"\n");start=time.monotonic();result=subprocess.run(plan["command"]);r.update(after=observe(),exit_code=result.returncode,elapsed_seconds=time.monotonic()-start);resource.write_text(json.dumps(r,indent=2)+"\n");sys.exit(result.returncode)
