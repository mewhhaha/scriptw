import pathlib,subprocess,json,hashlib,os,re,time,sys,gzip
def file_sha(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
 return h.hexdigest()
base=pathlib.Path('/home/mewhhaha/src/porffor/target/compiler-efficiency-20261024');source=base/'source';head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip();output=base/('regexp-batches-'+head[:9]);output.mkdir(exist_ok=False)
build=base/('native-'+head[:9])/'0000-scriptw-aot-wasm-scriptw_aot_wasm.build.jsonl.gz';build_bytes=gzip.decompress(build.read_bytes());producer=None
for s in build_bytes.decode().splitlines():
 r=json.loads(s)
 if r.get('reason')=='compiler-artifact' and r.get('executable') and r['profile']['test'] and r['target']['name']=='aot_regexp' and r['target']['kind']==['test']:
  assert producer is None;producer=r
assert producer is not None
executable=pathlib.Path(producer['executable']);binary_sha=file_sha(executable);assert binary_sha=='1fa7fd06da7eccbb98ffbf8204d73a59f0c643b351b281cae0292506e3c0edf2';os.sched_setaffinity(0,{min(os.sched_getaffinity(0))})
receipt={'source_commit':head,'cargo_producer':producer,'cargo_build_jsonl_sha256':hashlib.sha256(build_bytes).hexdigest(),'executable_sha256':binary_sha,'policy':'Serial fresh processes, each kernel capped at4GiB/no swap/grouped OOM/oneCPU; no skipped original IDs; Unicode case-fold stress test isolated. Original native watcher stall900seconds. Resource interruption remains incomplete.','groups':[],'complete':False}
def save(): (output/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
def invoke(label,command):
 with (output/(label+'.launcher.log')).open('x') as log:
  return subprocess.run(['python3','-B','scripts/limited_verification.py','--',*command],cwd=source,stdout=log,stderr=subprocess.STDOUT).returncode
save();listfile=output/'inventory.log'
listcommand=['python3','-c','import subprocess,sys; p=subprocess.run(sys.argv[2:],capture_output=True); open(sys.argv[1],"wb").write(p.stdout+p.stderr); sys.exit(p.returncode)',str(listfile),str(executable),'--list','--include-ignored']
assert invoke('inventory',listcommand)==0
inventory=re.findall(r'^(.+): test$',listfile.read_text(),re.M);assert len(inventory)==152 and len(set(inventory))==152
original=base/('native-'+head[:9])/'0038-scriptw-engine-aot_regexp.inventory.log';assert inventory==re.findall(r'^(.+): test$',original.read_text(),re.M)
receipt['inventory']=inventory;receipt['inventory_sha256']=hashlib.sha256(listfile.read_bytes()).hexdigest()
singletons=['aot_regexp_iv_class_strings::property_and_direct_strings_fold_circled_m_before_algebra'];assert set(singletons)<=set(inventory)
remaining=[n for n in inventory if n not in singletons];groups=[[n] for n in singletons]+[remaining[i:i+8] for i in range(0,len(remaining),8)];assert sorted(n for g in groups for n in g)==sorted(inventory)
child=output/'child.py';child.write_text('''import pathlib,json,os,subprocess,sys,time
plan=json.loads(pathlib.Path(sys.argv[1]).read_text());resource=pathlib.Path(plan["resource"])
group=pathlib.Path("/sys/fs/cgroup")/next(s[3:] for s in pathlib.Path("/proc/self/cgroup").read_text().splitlines() if s.startswith("0::")).lstrip("/")
def observe():return {"cgroup":str(group),"affinity":sorted(os.sched_getaffinity(0)),**{n:(group/n).read_text().strip() for n in ["memory.max","memory.peak","memory.swap.max","memory.oom.group","memory.events"]}}
r={"before":observe(),"command":plan["command"]};resource.write_text(json.dumps(r,indent=2)+"\\n");start=time.monotonic();result=subprocess.run(plan["command"]);r.update(after=observe(),exit_code=result.returncode,elapsed_seconds=time.monotonic()-start);resource.write_text(json.dumps(r,indent=2)+"\\n");sys.exit(result.returncode)
''')
for i,ids in enumerate(groups):
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()==head and not subprocess.check_output(['git','status','--porcelain'],cwd=source)
 label=f'efficiency-regexp-{head[:9]}-{i:02}';watch=source/'target/watched'/f'{label}.log';command=['./scripts/run-watched.sh','--label',label,'--stall','900','--',str(executable),'--exact',*ids,'--test-threads=1','--include-ignored'];plan=output/f'{i:02}.plan.json';plan.write_text(json.dumps({'command':command,'resource':str(output/f'{i:02}.resources.json')})+'\n');row={'ids':ids,'state':'running','command':command};receipt['groups'].append(row);save();print('REGEXP GROUP',i+1,'/',len(groups),'cases',len(ids),flush=True)
 result=invoke(f'{i:02}', ['python3','-B',str(child),str(plan)]);row['exit_code']=result
 resource_log=output/f'{i:02}.resources.json';row['resource_log']=resource_log.name;row['resource_sha256']=file_sha(resource_log)
 if result==137:
  resource=json.loads((output/f'{i:02}.resources.json').read_text());unit=pathlib.Path(resource['before']['cgroup']).name
  journal=subprocess.run(['journalctl','--user','--unit',unit,'--no-pager','-o','short-iso'],capture_output=True,text=True);(output/f'{i:02}.kernel-journal.log').write_text(journal.stdout+journal.stderr);row['kernel_oom_confirmed']=journal.returncode==0 and "Failed with result 'oom-kill'" in journal.stdout
 if watch.exists():
  copied=output/f'{i:02}.native.log';copied.write_bytes(watch.read_bytes());row['transcript_log']=copied.name;row['transcript_sha256']=file_sha(copied);data=copied.read_text(errors='replace');row['outcomes']=[{'id':n,'outcome':v} for n,v in re.findall(r'^test (.*?) \.\.\. (ok|FAILED|ignored)\s*$',data,re.M)];row['summaries']=re.findall(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',data)
 else:row['outcomes']=[];row['summaries']=[]
 row['state']='passed' if result==0 and sorted(r['id'] for r in row['outcomes'])==sorted(ids) and all(r['outcome']=='ok' for r in row['outcomes']) and row['summaries']==[('ok',str(len(ids)),'0','0')] else 'incomplete-or-failed';save();print('REGEXP RESULT',i+1,row['state'],'exit',result,'completed',len(row['outcomes']),flush=True)
 if row['state']!='passed':
  known_oom=result==137 and row.get('kernel_oom_confirmed') is True and len(ids)==1 and ids[0] in singletons and all(v['outcome']=='ok' for v in row['outcomes'])
  if not known_oom:
   receipt['aborted_on_unexpected_failure']=i;receipt['all_groups_attempted']=False;save();raise SystemExit(1)

receipt['all_groups_attempted']=len(receipt['groups'])==len(groups);receipt['source_unchanged']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()==head and not subprocess.check_output(['git','status','--porcelain'],cwd=source);receipt['executable_unchanged']=file_sha(executable)==binary_sha;receipt['complete']=receipt['all_groups_attempted'] and receipt['source_unchanged'] and receipt['executable_unchanged'] and all(r['state']=='passed' for r in receipt['groups']);save();raise SystemExit(0 if receipt['complete'] else 1)
