import json, os, re, subprocess, time
from pathlib import Path
base = Path('/home/mewhhaha/src/porffor/target/compiler-efficiency-20261024')
source = base / 'source'
output = base / ('focused-' + subprocess.check_output(['git','rev-parse','--short=9','HEAD'],cwd=source,text=True).strip())
output.mkdir(exist_ok=False)
selections = [
 ('scriptw-ir', ['--lib'], 'function_inference::tests::'),
 ('scriptw-ir', ['--lib'], 'pure_realm_discovery::tests::'),
 ('scriptw-aot-wasm', ['--lib'], 'tests::numeric_leaf::'),
 ('scriptw-aot-wasm', ['--lib'], 'tests::program_cache_pages::'),
 ('scriptw-aot-wasm', ['--lib'], 'gc_types::type_registration_tests::'),
 ('scriptw-engine', ['--lib'], 'closed_module_cache_hit_skips_lowering'),
 ('scriptw-engine', ['--lib'], 'initial_module_cache_candidate'),
 ('scriptw-engine', ['--lib'], 'prepared_source_catalog::tests::'),
 ('scriptw-engine', ['--test', 'aot_gc_entries'], 'aot_gc_compact_data_storage::'),
 ('scriptw-engine', ['--test', 'aot_gc_entries'], 'aot_gc_collection_entries::'),
 ('scriptw-engine', ['--test', 'aot_gc_entries'], 'aot_gc_property_read_plans::'),
 ('scriptw-engine', ['--test', 'aot_language'], 'aot_unobserved_arguments::'),
 ('scriptw-engine', ['--test', 'aot_language'], 'aot_numeric_call_rows::'),
]
selections = selections[int(os.environ.get('EFFICIENCY_FOCUS_START_INDEX','0')):]
report = {'source':subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip(), 'complete':False, 'selections':[]}
def save():
 (output/'report.json').write_text(json.dumps(report,indent=2)+'\n')
save()
for i,(package,selector,selected) in enumerate(selections):
 command=['cargo','test','--locked','--offline','--release','--jobs','1','-p',package,*selector,selected]
 row={'command':command,'filter':selected,'state':'inventory'}
 report['selections'].append(row);save()
 print('Focused inventory '+str(i+1)+'/'+str(len(selections))+': '+selected,flush=True)
 path=output/(str(i)+'-inventory.log')
 with path.open('x') as log:
  result=subprocess.run(command+['--','--list','--include-ignored'],cwd=source,stdout=log,stderr=subprocess.STDOUT)
 row['inventory_exit']=result.returncode
 names=re.findall(r'^(.+): test$',path.read_text(),re.M)
 row['inventory']=names;save()
 if result.returncode or not names or len(names)!=len(set(names)):
  row['state']='failed-inventory';save();print(path.read_text()[-14000:],flush=True);raise SystemExit(result.returncode or 1)
 row['state']='executing';save();print('Running '+str(len(names))+' cases: '+selected,flush=True)
 path=output/(str(i)+'-run.log')
 with path.open('x') as log:
  result=subprocess.run(command+['--','--test-threads=1','--include-ignored'],cwd=source,stdout=log,stderr=subprocess.STDOUT)
 row['exit']=result.returncode
 row['summaries']=re.findall(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',path.read_text())
 row['state']='passed' if result.returncode==0 and row['summaries']==[('ok',str(len(names)),'0','0')] else 'failed'
 save()
 if row['state']!='passed':print(path.read_text()[-14000:],flush=True);raise SystemExit(result.returncode or 1)
report['complete']=True
membership=next(x[3:] for x in Path('/proc/self/cgroup').read_text().splitlines() if x.startswith('0::'))
group=Path('/sys/fs/cgroup')/membership.lstrip('/')
report['resources']={'affinity':sorted(os.sched_getaffinity(0)),**{n:(group/n).read_text().strip() for n in ('memory.max','memory.peak','memory.swap.max','memory.oom.group','memory.events')}}
save();print('Focused complete: '+str(sum(len(r['inventory']) for r in report['selections']))+' checks',flush=True)
