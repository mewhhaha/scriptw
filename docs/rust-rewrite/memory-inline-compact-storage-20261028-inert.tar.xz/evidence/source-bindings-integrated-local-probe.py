"""Compare exact Git-tree compiler inputs with captured CI/local identities."""
import hashlib,json,re,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
ROOTS=['Cargo.toml','Cargo.lock','crates/scriptw-front','crates/scriptw-ir','crates/scriptw-aot-wasm','crates/scriptw-runtime','crates/scriptw-runtime-image','crates/scriptw-intl','crates/scriptw-intl-build-data','crates/scriptw-engine/Cargo.toml','crates/scriptw-engine/src','crates/scriptw-engine/build.rs','crates/scriptw-engine/compiler_fingerprint.rs','vendor']
def one(args):return subprocess.check_output(args,cwd=ROOT)
def fingerprint(revision,extra=False):
 source=one(['git','show',revision+':crates/scriptw-engine/compiler_fingerprint.rs']).decode()
 block=source.split('const TEST_ONLY_INPUTS: &[&str] = &[',1)[1].split('];',1)[0]
 excluded=re.findall(r'^\s*"([^"]+)",',block,re.M)
 items=[]
 for raw in one(['git','ls-tree','-r','-z',revision,'--',*ROOTS]).split(b'\0'):
  if not raw:continue
  fields,path=raw.split(b'\t',1);mode,kind,oid=fields.decode().split();path=path.decode()
  if any(path==x or path.startswith(x+'/') for x in excluded):continue
  assert kind=='blob' and mode=='100644',(mode,kind,path)
  items.append((path,oid))
 if extra:items.append(('vendor/regress-0.10.5/Cargo.lock',None))
 digest=hashlib.sha256(b'scriptw-program-cache-compiler-v3');total=0
 child=subprocess.Popen(['git','cat-file','--batch'],cwd=ROOT,stdin=subprocess.PIPE,stdout=subprocess.PIPE)
 try:
  for path,oid in sorted(items,key=lambda x:tuple(x[0].split('/'))):
   if oid is None:data=(ROOT/path).read_bytes()
   else:
    child.stdin.write((oid+'\n').encode());child.stdin.flush();header=child.stdout.readline().split();assert header[:2]==[oid.encode(),b'blob'];length=int(header[2]);data=child.stdout.read(length);assert len(data)==length and child.stdout.read(1)==b'\n'
   label=path.encode();digest.update(len(label).to_bytes(8,'little'));digest.update(label);digest.update(len(data).to_bytes(8,'little'));digest.update(data);total+=len(data)
 finally:child.stdin.close();child.stdout.close();assert child.wait()==0
 return dict(revision=one(['git','rev-parse',revision]).decode().strip(),extra_ignored_regress_lock=extra,source_fingerprint=digest.hexdigest(),files=len(items),bytes=total)

import os,sys
sys.path.insert(0,str(ROOT/'scripts'))
from limited_verification import require_kernel_budget,kernel_group
require_kernel_budget(256*1024**2);assert sorted(os.sched_getaffinity(0))==[0]
feature='a74353c93a4db0664cfee73e99d09edff78f7e79';verified='1c959788e10807e711ffbe72143a2529dae93576';probe='a19ba7395edfa93327ec01fbe53765ce50020c82'
group=kernel_group()
def budget():return {k:(group/k).read_text().strip() for k in ['memory.max','memory.swap.max','memory.oom.group','memory.peak','memory.events']}
before=budget();rows=[fingerprint(rev,extra) for rev in [feature,verified,probe] for extra in [False,True]]
for extra,fp in [(False,'d8cc0f78b8d68e8fe9f30f9b5841d795e95585141b7d110f996c498934f0fbbc'),(True,'0ee8c6b9eae2bc62ce06b2ad406729ede64ad773e31040fa1a87870583bb4d9d')]:
 selected=[r for r in rows if r['extra_ignored_regress_lock']==extra];assert len(selected)==3 and {r['source_fingerprint'] for r in selected}=={fp};assert len({(r['files'],r['bytes']) for r in selected})==1
r=dict(feature=feature,verified=verified,probe=probe,computed_compiler_inputs_equal=True,rows=rows,before=before,after=budget(),cpu_affinity=[0])
out=OUT/'source-bindings-integrated-local-probe.json';assert not out.exists();out.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
