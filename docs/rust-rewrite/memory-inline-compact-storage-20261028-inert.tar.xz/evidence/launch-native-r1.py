import hashlib,json,os,re,subprocess,sys
from pathlib import Path
base=Path(__file__).resolve().parent
repo=base.parents[1]
source=sys.argv[1]
assert re.fullmatch('[0-9a-f]{40}',source)
driver=base/'native-inline-compact-storage-r1.py'
assert 'FINAL_SOURCE_COMMIT_PLACEHOLDER' not in driver.read_text()
assert ('SOURCE = '+repr(source)) in driver.read_text()
assert driver.stat().st_mode & 0o222 == 0
sha=hashlib.sha256(driver.read_bytes()).hexdigest()
unit='scriptw-inline-compact-storage-native-r1-20261028.service'
output=base/('native-'+source[:9]);assert not output.exists()
cmd=['systemd-run','--user','--collect','--quiet','--no-ask-password','--expand-environment=no','--unit='+unit,'--property=MemoryMax=4294967296','--property=MemorySwapMax=0','--property=OOMPolicy=kill','--property=CPUAffinity=0','--working-directory='+str(repo),'--setenv=PATH='+os.environ['PATH'],'--setenv=SCRIPTW_EXPECTED_SOURCE='+source,'--','/usr/bin/python3','-B',str(repo/'scripts/limited_verification.py'),'--in-scope','--','/usr/bin/python3','-B',str(driver),'--workspace',str(repo/'target/memory-calendar-rows-20261028'),'--expected-source',source,'--output',str(output)]
r=dict(source=source,driver=str(driver),driver_sha256=sha,unit=unit,command=cmd)
receipt=base/('native-'+source[:9]+'-launch.json');assert not receipt.exists()
receipt.write_text(json.dumps(r,indent=2)+'\n')
child=subprocess.run(cmd,text=True,capture_output=True);r.update(exit_code=child.returncode,stdout=child.stdout,stderr=child.stderr)
receipt.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:r[k] for k in ('source','unit','driver_sha256','exit_code','stdout','stderr')}))
raise SystemExit(child.returncode)
