import json,os,subprocess,tempfile
from pathlib import Path
root=Path('/home/mewhhaha/src/porffor/target/memory-inline-compact-storage-20261028')
out=Path(__file__).parent/'toolchain-pin-checks';out.mkdir(exist_ok=False)
rows=[]
for argv in [['bash','-n','scripts/run-benchmark-scope.sh'],['python3','-B','-m','unittest','scripts.tests.test_tooling_benchmark_boundary'],['bash','scripts/check-no-legacy-js.sh'],['git','diff','--check']]:
 r=subprocess.run(argv,cwd=root,text=True,capture_output=True,timeout=120);rows.append(dict(command=argv,exit_code=r.returncode,stdout=r.stdout,stderr=r.stderr));assert r.returncode==0,rows[-1]
with tempfile.TemporaryDirectory() as td:
 p=Path(td)/'sudo';p.write_text('#!/usr/bin/env python3\nimport json,sys\nprint(json.dumps(sys.argv[1:]))\n');p.chmod(0o700)
 for selected in [None,'1.99.1']:
  env=dict(os.environ,PATH=td+os.pathsep+os.environ['PATH']);env.pop('RUSTUP_TOOLCHAIN',None)
  if selected:env['RUSTUP_TOOLCHAIN']=selected
  r=subprocess.run(['bash','scripts/run-benchmark-scope.sh','cargo','--version'],cwd=root,env=env,text=True,capture_output=True,timeout=10);assert r.returncode==0,r.stderr
  argv=json.loads(r.stdout);actual=[arg for arg in argv if arg.startswith('RUSTUP_TOOLCHAIN=')];assert actual==([] if selected is None else ['RUSTUP_TOOLCHAIN='+selected]);assert argv[-7:]==['python3','-B','scripts/limited_verification.py','--in-scope','--','cargo','--version']
  rows.append(dict(check='actual shell delegation captures optional explicit toolchain',selected=selected,actual=actual))
(out/'report.json').write_text(json.dumps(dict(complete=True,commands=rows),indent=2)+'\n');print('7 boundary tests, shell syntax/delegation, legacy audit and diff passed; no native execution')
