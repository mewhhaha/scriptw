"""Inert scored admission and separate ownership summaries for CI 40594118953.

Prepare only; run after artifacts exist, under a fresh 1-GiB/no-swap CPU-0 scope.
Never loads a native executable/image, launches a workload, or downloads inputs.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import sys

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
WORKTREE = ROOT / 'target/memory-module-ownership-20261027'
SCRIPTS = WORKTREE / 'scripts'
FEATURE = '06289f6c22d686ffbe69e7165869af0fdfcda813'
SOURCE = 'c79ab683848b6baf32adc528d144ea88a02a0fa0'
FINGERPRINT = '59bfb33612b5eadff0b32dbb703d876df230655b8e9f1a789a52274a9a63be92'
LOCAL_FINGERPRINT = '05961dd70907c0998e039d1b0f19b05f0d1aba61e1e08f08e0a2ed7f2b929cf9'
RUN = 40594118953
sys.path.insert(0, str(SCRIPTS))
import precompiled_comparison as p
import benchmark_module_images as m
from limited_verification import require_kernel_budget, kernel_group
spec = importlib.util.spec_from_file_location('ownership_diagnostic_contract', SCRIPTS / 'diagnose-precompiled-mappings.py')
d = importlib.util.module_from_spec(spec)
spec.loader.exec_module(d)
PHASES = list(d.PHASES)
EXPECTED_CASES = [(runtime, name) for name in ('integer.js', 'retained-objects.js') for runtime in ('scriptw', 'scriptc')]
INPUTS = {}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def bounded(path, maximum, root=None):
    path = Path(path)
    info = path.lstat()
    p.require(stat.S_ISREG(info.st_mode) and not path.is_symlink() and info.st_size <= maximum,
              'missing/nonregular/symlinked/oversized inert input: ' + str(path))
    if root is not None:
        p.require(path.resolve() == path and path.is_relative_to(root), 'input escapes artifact directory')
    with path.open('rb') as stream:
        raw = stream.read(maximum + 1)
    p.require(len(raw) <= maximum and len(raw) == info.st_size, 'input changed/exceeds bound')
    p.require(not raw.startswith((b'\x7fELF', b'MZ', b'SCRWEP', b'SCRWWA', b'SCRWRB', b'SCRWNR')),
              'native payload is outside this inert processor')
    INPUTS[str(path)] = dict(bytes=len(raw), sha256=sha(raw))
    return raw


def read(path, maximum=16 * 1024**2, root=None):
    return p._json(bounded(path, maximum, root))


def retained(directory, row, maximum):
    name = p.safe_name(row['path'])
    path = directory / name
    raw = bounded(path, maximum, directory)
    p.require(len(raw) == row['bytes'] and sha(raw) == row['sha256'], 'diagnostic retained length/hash differs')
    return raw


def checked_host_metadata(value, executable_sha):
    """Check the retained ELF metadata without requesting original ELF bytes."""
    p.require(set(value) == {'schema', 'sha256', 'bytes', 'inode', 'machine', 'kind', 'loads', 'sections',
                            'functions', 'zero_size_functions', 'total_defined_function_symbols',
                            'retained_present_overlap_symbols', 'interpretation'}, 'host metadata keys differ')
    p.require(value['schema'] == 'scriptw-host-elf-symbols-v1' and value['sha256'] == executable_sha,
              'host metadata executable binding differs')
    size = value['bytes']
    p.require(type(size) is int and 64 <= size <= m.MAX_ELF and type(value['inode']) is int and value['inode'] > 0
              and value['machine'] in (62, 183, 243) and value['kind'] in (2, 3), 'host ELF metadata identity differs')
    loads, sections, functions = (value[key] for key in ('loads', 'sections', 'functions'))
    p.require(isinstance(loads, list) and 0 < len(loads) <= 256 and isinstance(sections, list)
              and 0 < len(sections) <= 4096 and isinstance(functions, list) and len(functions) <= m.MAX_SYMBOLS,
              'host ELF metadata count bound exceeded')
    for row in loads:
        p.require(set(row) == {'offset', 'vaddr', 'filesz', 'memsz', 'flags', 'align'} and all(m.integer(v) for v in row.values()),
                  'host PT_LOAD metadata keys/numbers differ')
        off, va, filesz, memsz, align = (row[key] for key in ('offset', 'vaddr', 'filesz', 'memsz', 'align'))
        p.require(off <= size and filesz <= size - off and filesz <= memsz and va <= m.MAX_ADDRESS - memsz
                  and (align in (0, 1) or align & (align - 1) == 0)
                  and (align in (0, 1) or off % align == va % align), 'host PT_LOAD metadata extent differs')
    name_bytes = 0
    for row in sections:
        p.require(set(row) == {'name_offset', 'type', 'flags', 'vaddr', 'offset', 'size', 'link', 'entsize', 'name'}
                  and all(m.integer(row[k]) for k in row if k != 'name') and isinstance(row['name'], str),
                  'host section metadata keys/numbers differ')
        name_bytes += len(row['name'].encode())
        p.require(len(row['name'].encode()) <= m.MAX_SECTION_NAME_BYTES and row['vaddr'] <= m.MAX_ADDRESS - row['size']
                  and (row['type'] == 8 or row['offset'] <= size and row['size'] <= size - row['offset']),
                  'host section metadata extent differs')
    sections_by_name = {}
    for section in sections:
        sections_by_name.setdefault(section['name'], []).append(section)
    work = 0
    for row in functions:
        p.require(set(row) == {'name', 'vaddr', 'bytes', 'file_offset', 'section'} and isinstance(row['name'], str)
                  and isinstance(row['section'], str) and all(m.integer(row[k]) for k in ('vaddr', 'bytes', 'file_offset'))
                  and row['bytes'] > 0, 'host function metadata keys/numbers differ')
        name_bytes += len(row['name'].encode())
        p.require(len(row['name'].encode()) <= m.MAX_SYMBOL_NAME_BYTES and row['file_offset'] <= size
                  and row['bytes'] <= size - row['file_offset'] and row['vaddr'] <= m.MAX_ADDRESS - row['bytes'],
                  'host function metadata extent differs')
        candidates = sections_by_name.get(row['section'], [])
        work += len(candidates) + len(loads)
        p.require(work <= 8_000_000, 'host metadata section/load validation work bound exceeded')
        p.require(any(section['type'] == 1 and section['flags'] & 6 == 6
                      and section['vaddr'] <= row['vaddr'] and row['vaddr'] + row['bytes'] <= section['vaddr'] + section['size']
                      and section['offset'] + row['vaddr'] - section['vaddr'] == row['file_offset'] for section in candidates),
                  'host function metadata lacks executable section')
        backing = [load for load in loads if load['flags'] & 1 and load['offset'] <= row['file_offset']
                   and row['file_offset'] + row['bytes'] <= load['offset'] + load['filesz']
                   and load['vaddr'] + row['file_offset'] - load['offset'] == row['vaddr']]
        p.require(len(backing) == 1, 'host function metadata lacks unique executable PT_LOAD translation')
    p.require(name_bytes <= m.MAX_NAME_BYTES and type(value['zero_size_functions']) is int and value['zero_size_functions'] >= 0
              and type(value['total_defined_function_symbols']) is int and type(value['retained_present_overlap_symbols']) is int
              and len(functions) == value['retained_present_overlap_symbols'] <= value['total_defined_function_symbols'] <= m.MAX_SYMBOLS,
              'host symbol metadata count/name budget differs')
    return value


def executable_presence(snapshot, host):
    value = snapshot.get('executable_presence', {})
    p.require(value.get('status') == 'present-bits-only-no-PFNs' and set(value) == {'status', 'mappings'},
              'host executable bit63 presence unavailable/malformed')
    rows = [row for row in snapshot['mappings'] if row['path'] == host and row['permissions'] in ('r--p', 'r-xp')]
    p.require(len(value['mappings']) == len(rows), 'host presence coverage differs')
    total = 0
    for record, row in zip(value['mappings'], rows):
        p.require(set(record) == {'file_offset', 'permissions', 'page_bytes', 'pages', 'present_bits_lsb_hex'},
                  'host presence record includes unknown bits/fields')
        page = m.page_size(record['page_bytes'])
        pages = (row['end'] - row['start']) // page
        total += pages
        p.require(record['file_offset'] == row['file_offset'] and record['permissions'] == row['permissions']
                  and type(record['pages']) is int and record['pages'] == pages and total <= 65536,
                  'host presence record extent differs')
        encoded = record['present_bits_lsb_hex']
        p.require(isinstance(encoded, str) and re.fullmatch('[0-9a-f]*', encoded) is not None, 'host presence bits invalid')
        bits = bytes.fromhex(encoded)
        p.require(len(bits) == (pages + 7) // 8 and (not pages % 8 or bits[-1] >> (pages % 8) == 0),
                  'host presence bit extent/padding differs')


def diagnostic(directory, campaign, run):
    if directory is None or not (directory / 'report.json').exists():
        return dict(status='unavailable', scored=False, scored_admission_affected=False,
                    reason='Unscored diagnostic artifact/report is absent; no ownership conclusion.')
    result = read(directory / 'report.json', root=directory)
    p.require(result['schema'] == 'scriptw-precompiled-mapping-diagnostic-v2' and result['scored'] is False
              and result['excluded_from_scored_cohorts'] is True, 'diagnostic cohort declaration differs')
    p.require(result['status'] in ('captured', 'incomplete', 'unavailable'), 'unknown diagnostic status')
    if 'source_commit' not in result:
        p.require(result['status'] != 'captured', 'captured diagnostic lacks source authority')
        return dict(status=result['status'], scored=False, scored_admission_affected=False,
                    reason=result.get('error', 'Diagnostic did not reach source/endpoint admission.'),
                    report_sha256=INPUTS[str(directory / 'report.json')]['sha256'])
    p.require(result['source_commit'] == SOURCE and result['source_fingerprint'] == FINGERPRINT
              and result['scored_report_sha256'] == p.digest(args.scored_report)
              and result['executable_sha256'] == campaign['tools']['consumer']['sha256']
              and result['shared_configuration'] == campaign['shared_configuration'], 'diagnostic/scored source bindings differ')
    resources = result.get('resources', {})
    resource_status = 'unavailable'
    if set(resources) == {'before', 'after'}:
        before, after = resources['before'], resources['after']
        p.require(before['cpu_affinity'] == after['cpu_affinity'] and len(before['cpu_affinity']) == 1,
                  'diagnostic CPU resource origin differs')
        p._resources(dict(machine=dict(measurement_affinity=before['cpu_affinity']),
                          resources=dict(cpu_affinity=before['cpu_affinity'], before=before['counters'], after=after['counters'])))
        resource_status = 'validated'
    cases = result['cases']
    p.require(isinstance(cases, list) and len(cases) <= 4
              and [(case['runtime'], case['file']) for case in cases] == EXPECTED_CASES[:len(cases)],
              'diagnostic case order/inventory differs')
    summary = dict(status='incomplete', captured_status=result['status'], scored=False, scored_admission_affected=False,
                   report_sha256=INPUTS[str(directory / 'report.json')]['sha256'], resource_status=resource_status,
                   cases=[], phase_history='Transport drop precedes all runs; the other captures select observation16 after10 warmups+6 prior measured executions. Warm-phase differences are not cold bootstrap isolation.')
    admitted = []
    total_smaps = 0
    nonces = set()
    for case in cases:
        runtime, name = case['runtime'], case['file']
        row = dict(runtime=runtime, file=name, status='incomplete')
        summary['cases'].append(row)
        if case.get('status') != 'captured' or not case.get('endpoint_stdout_validated'):
            row['reason'] = case.get('error', 'Missing complete endpoint capture.')
            continue
        nonce, index = case['nonce'], case['observation_index']
        p.require(re.fullmatch('[0-9a-f]{32}', nonce) is not None and type(index) is int and index == 16,
                  'diagnostic nonce/index differs')
        child_pid = case['owned_child_pid']
        p.require(nonce not in nonces and type(child_pid) is int and 0 < child_pid <= 2**31-1,
                  'diagnostic nonce reused or child PID malformed')
        nonces.add(nonce)
        p.require(case['returncode'] == 0 and case['completed_phases'] == PHASES and case['phase_attribution_validated'] is True,
                  'diagnostic completion declaration differs')
        folder = directory / (runtime + '-' + name)
        raw = retained(folder, case['stdout'], d.MAX_READ)
        retained(folder, case['stderr'], d.MAX_READ)
        control = retained(folder, case['control'], d.MAX_CONTROL_BYTES)
        p.require(control == ''.join(f'SWPHASE1 {nonce} {n+1} {phase} {index}\n' for n, phase in enumerate(PHASES)).encode(),
                  'raw acknowledged phase control inventory differs')
        attempt = next(item for item in campaign['attempts'] if item['runtime'] == runtime and item['file'] == name and item['round'] == 0)
        workload = next(item for item in campaign['workloads'] if item['file'] == name)
        command = next(item for item in campaign['commands'] if item['id'] == attempt['consumer_id'])
        p.require(case['argv'] == command['argv'] and case['image_sha256'] == attempt['image']['sha256'],
                  'diagnostic original producer/consumer command binding differs')
        owner_value = d.validate_endpoint(raw, campaign, attempt['image'], workload, runtime, nonce, index)
        p.require(owner_value == case.get('module_images'), 'endpoint ModuleImages differs from retained case')
        shots = case['snapshots']
        p.require(len(shots) == 4 and [shot['phase'] for shot in shots] == PHASES, 'four ordered snapshot captures required')
        for n, shot in enumerate(shots):
            p.require(type(shot['sequence']) is int and shot['sequence'] == n+1 and shot['nonce'] == nonce
                      and type(shot['observation_index']) is int and shot['observation_index'] == index
                      and shot['path'] == f'{n+1:03d}-{PHASES[n]}.smaps', 'snapshot sequence/nonce/path differs')
            smaps = retained(folder, shot, d.MAX_READ)
            total_smaps += len(smaps)
            p.require(total_smaps <= d.MAX_TOTAL and d.mappings(smaps) == shot['mappings']
                      and shot['rss_bytes'] == sum(item['Rss'] for item in shot['mappings']), 'raw smaps mapping/aggregate differs')
        # Endpoint admission above is independent of optional page diagnostics.
        if not case.get('module_attribution_validated'):
            row['reason'] = case.get('module_attribution_error', 'Module ownership/presence unavailable.')
            continue
        identity = dict(source_commit=SOURCE, source_fingerprint=FINGERPRINT, executable_sha256=result['executable_sha256'],
                        image_sha256=attempt['image']['sha256'], program_native_sha256=attempt['image']['native_sha256'],
                        runtime_key=attempt['image']['runtime_key'], shared_configuration=campaign['shared_configuration'])
        attribution = m.validate_module_images(owner_value, runtime, nonce, index, shots, identity)
        p.require(attribution == case['module_attribution'], 'rederived ownership page attribution differs')
        for shot in shots:
            executable_presence(shot, campaign['tools']['consumer']['path'])
        row.update(status='module-ownership-validated', module_attribution=attribution)
        admitted.append((case, row))
    # Only inspect inert host metadata after the endpoint checks for every case.
    if result.get('host_symbol_inventory_status') != 'validated':
        summary['host_metadata_status'] = 'unavailable'
        summary['host_metadata_reason'] = result.get('host_symbol_inventory_error', 'Host ELF metadata unavailable.')
        return summary
    inventory = checked_host_metadata(p._json(retained(directory, result['host_symbol_inventory'], d.MAX_SYMBOL_METADATA_BYTES)),
                                      result['executable_sha256'])
    summary['host_metadata_status'] = 'inert-metadata-validated-original-ELF-not-downloaded-or-reparsed'
    for case, row in admitted:
        if not case.get('host_symbol_attribution_validated'):
            row['host_status'] = 'unavailable'
            row['host_reason'] = case.get('host_symbol_attribution_error', 'Host overlap unavailable.')
            continue
        overlap = m.attribute_host(inventory, case['snapshots'], campaign['tools']['consumer']['path'])
        captured = p._json(retained(directory, case['host_symbol_attribution'], d.MAX_SYMBOL_METADATA_BYTES))
        p.require(overlap == captured and case['host_symbol_attribution']['overlapping_functions'] == len(overlap['symbols']),
                  'rederived inert host function/page overlap differs')
        p.require(all(shot['proc_exe']['inode'] == inventory['inode'] for shot in case['snapshots']), 'captured host inode differs')
        row.update(status='validated', host_status='validated', host_phases=overlap['phases'],
                   host_overlapping_function_count=len(overlap['symbols']), host_overlap_metadata=dict(case['host_symbol_attribution']),
                   host_function_overlap=overlap['symbols'])
    if len(summary['cases']) == 4 and all(row['status'] == 'validated' for row in summary['cases']) and resource_status == 'validated':
        p.require(result['status'] == 'captured', 'complete raw diagnostics status differs')
        mapping_steps = [step for job in run['jobs'] for step in job['steps'] if step['name'] == 'Observe unscored consumer mappings']
        p.require(len(mapping_steps) == 1 and mapping_steps[0]['conclusion'] == 'success', 'captured diagnostic CI step differs')
        summary['status'] = 'validated'
    return summary


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--scored-report', type=Path, required=True)
parser.add_argument('--scored-archive', type=Path)
parser.add_argument('--diagnostic', type=Path)
parser.add_argument('--run-metadata', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
args.scored_report = args.scored_report.resolve(strict=True)
args.run_metadata = args.run_metadata.resolve(strict=True)
if args.scored_archive is not None:
    args.scored_archive = args.scored_archive.resolve(strict=True)
if args.diagnostic is not None:
    args.diagnostic = args.diagnostic.resolve()
args.output = args.output.resolve()
require_kernel_budget(1024**3)
p.require(sorted(os.sched_getaffinity(0)) == [0], 'processor requires CPU0')
p.require(args.output.is_relative_to(BASE) and not args.output.exists(), 'fresh private output directory required')
group = kernel_group()


def budget():
    return {key: (group / key).read_text().strip() for key in ('memory.max', 'memory.swap.max', 'memory.oom.group', 'memory.peak', 'memory.events')}


before = budget()
p.require(subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORKTREE, text=True).strip() == FEATURE,
          'feature validator worktree changed')
tool_sources = {}
for module, name in [(p, 'precompiled_comparison.py'), (m, 'benchmark_module_images.py'), (d, 'diagnose-precompiled-mappings.py')]:
    path = SCRIPTS / name
    p.require(Path(module.__file__).resolve() == path, 'main/other validator module imported')
    raw = bounded(path, 256 * 1024)
    expected = subprocess.check_output(['git', 'show', FEATURE + ':scripts/' + name], cwd=WORKTREE)
    p.require(raw == expected, 'feature validation tools differ from reviewed source')
    tool_sources[name] = dict(source_commit=FEATURE, sha256=sha(raw))
proof_path = BASE / 'source-bindings-ci-long-symbol-equivalence.json'
proof = read(proof_path)
p.require(proof['feature_source'] == FEATURE and proof['probe_source'] == SOURCE
          and proof['probe_only_workflow_change'] is True and proof['computed_compiler_inputs_equal'] is True
          and len(proof['rows']) == 4, 'source closure equivalence proof differs')
for revision in (FEATURE, SOURCE):
    for local, fingerprint in [(False, FINGERPRINT), (True, LOCAL_FINGERPRINT)]:
        rows = [row for row in proof['rows'] if row['revision'] == revision and row['extra_ignored_regress_lock'] is local]
        p.require(len(rows) == 1 and rows[0]['source_fingerprint'] == fingerprint, 'source fingerprint binding differs')
run = read(args.run_metadata)
p.require(run['databaseId'] == RUN and run['headSha'] == SOURCE and run['headBranch'] == 'memory-module-ownership-ci-20261027'
          and run['status'] == 'completed' and run['conclusion'] == 'success'
          and run['url'] == 'https://github.com/mewhhaha/scriptw/actions/runs/' + str(RUN), 'completed CI run/source binding differs')
p.require(len(run['jobs']) == 1 and run['jobs'][0]['name'] == 'measure' and run['jobs'][0]['status'] == 'completed'
          and run['jobs'][0]['conclusion'] == 'success', 'completed measurement job metadata differs')
for name in ('Verify and build the shared host', 'Measure both compiler-free consumers', 'Retain all raw observations and failures'):
    rows = [step for job in run['jobs'] for step in job['steps'] if step['name'] == name]
    p.require(len(rows) == 1 and rows[0]['conclusion'] == 'success', 'required scored CI step not successful: ' + name)
bounded(args.scored_report, p.MAX_REPORT)
campaign, table = p.load_report(args.scored_report, archive=args.scored_archive)
if args.scored_archive is not None:
    INPUTS[str(args.scored_archive)] = dict(bytes=args.scored_archive.stat().st_size, sha256=p.digest(args.scored_archive))
p.require(campaign['source_commit'] == SOURCE and campaign['source_fingerprint'] == FINGERPRINT
          and campaign['tools']['consumer']['cargo_producer']['features'] == ['benchmark-module-images']
          and len(campaign['attempts']) == 68 and len(table) == 17, 'actual scored CI source/feature/inventory differs')
summary = dict(schema='scriptw-private-module-ownership-ci-validation-v1', complete=False,
               started_at=datetime.now(timezone.utc).isoformat(), source_commit=SOURCE, feature_source_commit=FEATURE,
               source_fingerprint=FINGERPRINT, run=RUN, cpu_affinity=[0], before=before, scored_admitted=True,
               scored_all_attempts_ok=all(attempt['status'] == 'ok' for attempt in campaign['attempts']),
               scored_attempts=68, scored_workloads=17, scored_table=table, validator_sources=tool_sources,
               actual_shared_host_identity_confirmed_by_scored_report=True,
               source_equivalence_proof_sha256=INPUTS[str(proof_path)]['sha256'],
               interpretation='Source-bound inert evidence admission only. Ownership views overlap within an owner and must not be summed. Bit63 page presence and nonexclusive host function/page overlap do not establish execution or causal RSS/timing savings. Diagnostic availability never changes scored observations.')
try:
    summary['diagnostic'] = diagnostic(args.diagnostic, campaign, run)
except (OSError, ValueError, KeyError, TypeError, StopIteration) as error:
    summary['diagnostic'] = dict(status='invalid-or-incomplete', scored=False, scored_admission_affected=False,
                                 reason=str(error), ownership_conclusion_available=False)
after = budget()
events = [dict(line.split() for line in value['memory.events'].splitlines()) for value in (before, after)]
p.require(all(events[0][key] == events[1][key] for key in ('oom', 'oom_kill', 'oom_group_kill')), 'processor OOM event')
summary.update(complete=True, finished_at=datetime.now(timezone.utc).isoformat(), after=after, inputs=INPUTS)
args.output.mkdir()
(args.output / 'report.json').write_text(json.dumps(summary, indent=2) + '\n')
lines = ['CI ' + str(RUN) + ': scored evidence admitted (' + str(sum(item['status'] == 'ok' for item in campaign['attempts'])) + '/68 attempts successful; 17 workloads).',
         'Unscored ownership diagnostic: ' + summary['diagnostic']['status'] + '.', '',
         'Present base pages; image/text views overlap and must not be summed.',
         '| Case | Owner | Phase | Image | Text | Union |', '|---|---|---|---:|---:|---:|']
for case in summary['diagnostic'].get('cases', []):
    for owner in case.get('module_attribution', {}).get('owners', []):
        for phase in owner['phases']:
            lines.append('| ' + case['runtime'] + '/' + case['file'] + ' | ' + owner['role'] + ' | ' + phase['phase']
                         + ' | ' + str(phase['image_present_pages']) + ' | ' + str(phase['text_present_pages']) + ' | ' + str(phase['union_present_pages']) + ' |')
lines += ['', '| Case | Phase | Host RX present pages |', '|---|---|---:|']
for case in summary['diagnostic'].get('cases', []):
    for phase in case.get('host_phases', []):
        lines.append('| ' + case['runtime'] + '/' + case['file'] + ' | ' + phase['phase'] + ' | ' + str(phase['present_host_rx_pages']) + ' |')
lines += ['', 'Transport drop is cold relative to the run loop. Other snapshots select observation16 after16 prior executions; last-sample growth cannot isolate or exclude Realm bootstrap.',
          'Host function/page overlaps are nonexclusive and do not establish execution. No native executable or image was loaded, retained, or executed by this processor.',
          'Unavailable/incomplete diagnostics supply no ownership conclusion and do not invalidate the scored cohort.']
(args.output / 'summary.md').write_text('\n'.join(lines) + '\n')
print(json.dumps(dict(scored_admitted=True, scored_all_attempts_ok=summary['scored_all_attempts_ok'], diagnostic_status=summary['diagnostic']['status'], output=str(args.output))))
