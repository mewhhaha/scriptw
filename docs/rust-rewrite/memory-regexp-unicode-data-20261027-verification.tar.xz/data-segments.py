"""Inert bounded extraction of the exact successful Cargo-check R package."""
import hashlib,json,pathlib,struct
D=pathlib.Path(__file__).resolve().parent
SOURCE='e7e51222101533e421ffae41bb0ccad78ba638ba'
def sha(b):return hashlib.sha256(b).hexdigest()
def leb(b,p,signed=False):
 v=0
 for i in range(5):
  assert p<len(b);x=b[p];p+=1;v|=(x&127)<<(7*i)
  if not x&128:
   if signed and x&64:v-=1<<(7*(i+1))
   assert -(1<<31)<=v<(1<<32)
   return v,p
 raise AssertionError('oversize LEB')
def parse(path,fp):
 assert path.stat().st_size<128*1024*1024
 b=path.read_bytes();assert b[:8]==b'SCRWRB01' and struct.unpack_from('<I',b,8)[0]==27
 assert b[12:44].hex()==fp and sha(b[:-32])==b[-32:].hex()
 static,utf16,strings,n=struct.unpack_from('<QQIQ',b,108)
 assert n==len(b)-168
 w=memoryview(b)[136:-32];assert w[:8]==b'\0asm\1\0\0\0'
 p=8;segments=None
 while p<len(w):
  sid=w[p];p+=1;size,p=leb(w,p);end=p+size;assert end<=len(w)
  if sid==11:
   assert segments is None
   count,q=leb(w,p);assert count==6;segments=[]
   for i in range(count):
    flag,q=leb(w,q);assert flag==(1 if i<3 else 0)
    offset=None
    if flag==0:
     assert w[q]==0x41;q+=1;offset,q=leb(w,q,True);offset&=0xffffffff
     assert w[q]==0x0b;q+=1
    length,q=leb(w,q);assert q+length<=end
    segments.append(dict(physical=i,mode='passive' if flag else 'active',bytes=length,offset=offset));q+=length
   assert q==end
  p=end
 assert p==len(w) and segments is not None
 lens=[s['bytes'] for s in segments];assert lens[0]==utf16
 cursor=4096
 for i,gap in [(3,lens[2]),(4,lens[1]),(5,0)]:
  assert segments[i]['offset']==cursor
  cursor+=lens[i]+gap;assert cursor<=0xffffffff
 assert cursor==4096+static and sum(lens[1:])==static
 return dict(path=str(path),package_sha256=sha(b),package_bytes=len(b),wasm_bytes=n,layout=27,source_fingerprint=fp,static_bytes=static,pooled_utf16_bytes=utf16,strings=strings,segments=segments,virtual_reassembly_order=[3,2,4,1,5],virtual_reassembly_bytes=sum(lens[1:]))
check=json.loads((D/'check.json').read_text());assert check['complete'] and check['exit_code']==0 and check['source_commit']==SOURCE
raw=(D/'cargo-check.jsonl').read_bytes();assert sha(raw)==check['stdout_sha256']
rows=[json.loads(l) for l in raw.splitlines() if l.startswith(b'{')]
rows=[r for r in rows if r.get('reason')=='build-script-executed' and r.get('package_id')=='path+file:///home/mewhhaha/src/porffor/crates/scriptw-runtime-image#0.1.0'];assert len(rows)==1
row=rows[0];out=pathlib.Path(row['out_dir']);assert out.is_absolute()
bindings=json.loads((D/'source-bindings-computed.json').read_text());binding=[r for r in bindings if r['revision']==SOURCE and r['extra_ignored_regress_lock']];assert len(binding)==1
result=dict(source_commit=SOURCE,check_stdout_sha256=sha(raw),producer_row=row,scope='inert static bytes only; no native deserialization or execution',packages=[parse(out/name,binding[0]['source_fingerprint']) for name in ['scriptw-runtime-package.bin','scriptw-runtime-portable-package.bin']])
(D/'data-segments-producer-row.json').write_text(json.dumps(row,indent=2)+'\n')
(D/'data-segments.json').write_text(json.dumps(result,indent=2)+'\n')
for p in result['packages']:print(pathlib.Path(p['path']).name,[(s['physical'],s['bytes'],s['offset']) for s in p['segments']], 'static',p['static_bytes'])
