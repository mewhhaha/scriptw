"""Publish completed Unicode-data verification; no native artifacts are executed.

Usage: publish-verification.py SOURCE CI_RUN [--ci-report ACTUAL_RAW_REPORT]
Paths below follow the prepared verify/check/native/test262 driver schemas.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import lzma
from pathlib import Path, PurePosixPath
import re
import subprocess
import sys
import tarfile

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
DEST = ROOT/'docs/rust-rewrite'
STEM = 'memory-regexp-unicode-data-20261027'
PRIOR = ROOT/'target/memory-intrinsic-publication-20261027-evidence'
PRIOR_SOURCE = 'fa204ae2bdccd798b98439d4c347b576c2ee4508'
sys.path.insert(0, str(ROOT/'scripts'))
import precompiled_comparison as p
from native_test_protocol import result_summaries


def read(path):
    return json.loads(path.read_text())


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def streams(directory, commands):
    for row in commands:
        assert row.get('exit_code', row.get('returncode')) == 0
        for key in ('stdout', 'stderr'):
            assert sha(directory/row[key]) == row[key+'_sha256']


def resource(report):
    # Nested conformance reports inherit the driver scope and omit affinity.
    if 'cpu_affinity' in report:
        assert report['cpu_affinity'] == [0]
    for moment in ('before', 'after'):
        values = report[moment]
        assert values['memory.max'] == '4294967296'
        assert values['memory.swap.max'] == '0' and values['memory.oom.group'] == '1'
    before = dict(line.split() for line in report['before']['memory.events'].splitlines())
    after = dict(line.split() for line in report['after']['memory.events'].splitlines())
    assert all(before[key] == after[key] for key in ('oom', 'oom_kill', 'oom_group_kill'))


def conformance(directory, source):
    report = read(directory/'report.json')
    assert report['complete'] and report['source_commit'] == source and report['batch_limit'] == 16
    resource(report)
    streams(directory, report['commands'])
    listing = directory/'executions'
    assert sha(listing) == report['execution_list_sha256']
    selected = listing.read_text().splitlines()
    assert selected and len(selected) == len(set(selected)) == report['selected_executions']
    actual = []
    for part in report['batches']:
        ids_file, snapshot_file = directory/part['list_file'], directory/part['snapshot_file']
        assert sha(ids_file) == part['list_sha256'] and sha(snapshot_file) == part['snapshot_sha256']
        ids = ids_file.read_text().splitlines()
        snapshot = read(snapshot_file)
        assert 0 < len(ids) <= 16 and len(ids) == len(set(ids)) == part['passed'] == snapshot['total'] == snapshot['passed']
        assert snapshot['compiler_identity'] == report['compiler']['identity']
        assert set(snapshot['completed_test_ids']) == set(ids)
        assert not snapshot['failures'] and not snapshot['timeout_test_ids']
        assert snapshot['counts_per_outcome'] == dict(Bug=0, Crash=0, NotImplemented=0, Success=len(ids))
        actual.extend(ids)
    assert len(actual) == len(set(actual)) == report['total'] == report['passed'] == len(selected)
    assert set(actual) == set(selected)
    assert report['compiler']['identity']['source_revision'] == dict(kind='git-commit', commit=source)
    assert report['compiler']['identity']['executable_sha256'] == report['compiler']['sha256']
    return report, set(selected)


def validate_stopped_driver(source):
    stopped = read(BASE/'verification-repaired.json')
    assert stopped['source_commit'] == source and not stopped['complete'] and 'after' not in stopped
    assert stopped['cpu_affinity'] == [0]
    assert stopped['before']['memory.max'] == '4294967296'
    assert stopped['before']['memory.swap.max'] == '0' and stopped['before']['memory.oom.group'] == '1'
    assert [(row['label'], row['exit_code']) for row in stopped['commands']] == [
        ('cheap-after-repair-driver',0), ('native-resume-driver',0), ('cargo-products',0), ('test262-driver',1)]
    for command in stopped['commands']:
        for key in ('stdout','stderr'):
            assert sha(BASE/command[key]) == command[key+'_sha256']
    guard = BASE/'conformance-guard-attempt'
    assert guard.is_dir() and {path.name for path in guard.iterdir()} == {'compiler'}
    assert not (guard/'report.json').exists(), 'guard failed before the first invocation was recorded'
    products = [json.loads(line) for line in (BASE/'cargo-products.jsonl').read_text().splitlines()]
    assert products[-1] == dict(reason='build-finished',success=True)
    rows = [row for row in products if row.get('reason')=='compiler-artifact' and row.get('executable')
            and row['target']['name']=='scriptw' and row['target']['kind']==['bin'] and not row['profile']['test']]
    assert len(rows)==1
    frozen_sha = sha(guard/'compiler')
    repair = read(BASE/'driver-repair.json')
    assert repair['source_commit'] == source and repair['path'] == 'test262.py'
    assert repair['before_path'] == 'test262-guard-attempt.py'
    assert repair['guard_attempt_directory'] == 'conformance-guard-attempt'
    assert repair['executed_commands'] == repair['executed_cases'] == 0
    assert frozen_sha == repair['guard_attempt_compiler_sha256']
    assert sha(BASE/repair['before_path']) == repair['before_sha256']
    assert sha(BASE/repair['path']) == repair['after_sha256']
    assert sha(BASE/repair['patch']) == repair['patch_sha256']
    return stopped, rows[0], frozen_sha


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source')
    parser.add_argument('run')
    parser.add_argument('--ci-report', type=Path, help='actual raw CI report; default is this evidence directory’s standard artifact path')
    args = parser.parse_args()
    source = args.source
    assert re.fullmatch('[0-9a-f]{40}', source) and args.run.isdecimal()
    ci_path = args.ci_report or BASE/('github-'+args.run)/'precompiled-measurements/precompiled-evidence/report.json'
    native = read(BASE/'native-final/report.json')
    batch = read(BASE/'verification-final.json')
    stopped_batch, product_producer, frozen_guard_sha = validate_stopped_driver(source)
    check = read(BASE/'check.json')
    cheap = read(BASE/'cheap-verified/cheap-main.json')
    cheap_repaired = read(BASE/'cheap-after-repair/cheap-main.json')
    assert all(report['complete'] and report['source_commit'] == source for report in (native, batch, check))
    assert check['exit_code'] == 0
    assert all(row['complete'] and row['base_commit'] == source for row in (cheap, cheap_repaired))
    repair = batch['required_repair_source']
    assert re.fullmatch('[0-9a-f]{40}', repair)
    assert subprocess.run(['git', 'merge-base', '--is-ancestor', repair, source], cwd=ROOT).returncode == 0
    assert subprocess.run(['git', 'merge-base', '--is-ancestor', PRIOR_SOURCE, source], cwd=ROOT).returncode == 0
    for report in (native, batch, check):
        assert report['cpu_affinity'] == [0]
        resource(report)
    assert sha(BASE/'cargo-check.jsonl') == check['stdout_sha256']
    assert sha(BASE/'cargo-check.stderr') == check['stderr_sha256']
    streams(BASE/'native-final', native['commands'])
    assert [row['label'] for row in batch['commands']] == ['test262-final-driver','test262-unicode-final-driver']
    streams(BASE, batch['commands'])
    assert batch['driver_repair'] == read(BASE/'driver-repair.json')
    assert batch['retained_completed_scope'] == 'verification-repaired.json'
    assert batch['retained_native_report'] == 'native-final/report.json'
    assert batch['retained_product_compiler_sha256'] == frozen_guard_sha
    streams(BASE/'cheap-verified', cheap['commands'])
    streams(BASE/'cheap-after-repair', cheap_repaired['commands'])
    fixture = read(BASE/'wire-data-fixture.json')
    assert native['test_fixture_patch'] == batch['test_fixture_patch'] == stopped_batch['test_fixture_patch'] == fixture
    assert batch['required_repair_source'] == stopped_batch['required_repair_source']
    assert fixture['source_commit'] == source
    assert fixture['path'] == 'crates/scriptw-aot-wasm/src/tests.rs'
    assert fixture['compiler_input_exclusion'] == fixture['path']
    assert sha(BASE/fixture['patch']) == fixture['patch_sha256']
    patch = (BASE/fixture['patch']).read_text()
    assert re.findall(r'^diff --git a/(\S+) b/(\S+)$', patch, re.M) == [(fixture['path'], fixture['path'])]
    assert sha(ROOT/fixture['path']) == fixture['after_sha256']
    original_fixture = subprocess.check_output(['git','show',source+':'+fixture['path']], cwd=ROOT)
    assert hashlib.sha256(original_fixture).hexdigest() == fixture['before_sha256']
    original_native = read(BASE/'native/report.json')
    assert original_native['source_commit'] == source and not original_native['complete']
    completed = [scope for scope in original_native['scopes'] if scope['complete']]
    assert len(completed) == 4 and sum(scope['passed'] for scope in completed) == 420
    assert native['original_budget_before'] == original_native['before'] and 'after' not in original_native
    for field, value in [('memory.max','4294967296'),('memory.swap.max','0'),('memory.oom.group','1')]:
        assert original_native['before'][field] == value
    failures = [command for command in original_native['commands'] if command.get('exit_code', command.get('returncode')) != 0]
    assert len(failures) == 1 and failures[0]['label'] == 'scriptw-aot-wasm-scriptw_aot_wasm-part-000'
    for command in original_native['commands']:
        for key in ('stdout', 'stderr'):
            assert sha(BASE/'native'/command[key]) == command[key+'_sha256']
    failed_raw = (BASE/'native'/failures[0]['stdout']).read_text()
    assert result_summaries(failed_raw) == [('FAILED','501','1','0','0','0')]
    before_binaries = read(BASE/'native-original-binaries.json')
    assert len(before_binaries) == 19
    unchanged = 0
    for scope in native['scopes']:
        if scope['package'] == 'scriptw-aot-wasm' and scope['target'] == 'scriptw_aot_wasm':
            continue
        previous_binary = [row for row in before_binaries if row['target'] == scope['target'] and row['kind'] == [scope['kind']]]
        assert len(previous_binary) == 1 and scope['executable_sha256'] == previous_binary[0]['sha256']
        unchanged += 1
    assert unchanged == native['unchanged_original_binaries'] == 18
    for scope in completed:
        resumed = next(row for row in native['scopes'] if (row['package'],row['target']) == (scope['package'],scope['target']))
        assert resumed['inventory'] == scope['inventory'] and resumed['executable_sha256'] == scope['executable_sha256']
        prefix = scope['package']+'-'+scope['target']+'-'
        for command in original_native['commands']:
            if command['label'].startswith(prefix):
                for key in ('stdout','stderr'):
                    assert sha(BASE/'native-final'/command[key]) == command[key+'_sha256']
    old_attempt = read(BASE/'attempt-3b9094856/check.json')
    assert old_attempt['source_commit'] == '3b9094856c195255a5ce900d535855d0803de109'
    assert old_attempt['exit_code'] != 0 and not old_attempt['complete']
    assert sha(BASE/'attempt-3b9094856/cargo-check.jsonl') == old_attempt['stdout_sha256']
    assert sha(BASE/'attempt-3b9094856/cargo-check.stderr') == old_attempt['stderr_sha256']

    original, original_ids = conformance(BASE/'conformance', source)
    supplemental, supplemental_ids = conformance(BASE/'conformance-unicode', source)
    assert original['passed'] == original['total'] == len(original_ids) == 2365
    assert original['compiler']['cargo_producer'] == product_producer
    assert original['compiler']['sha256'] == frozen_guard_sha
    prior_ids = set((PRIOR/'conformance/executions').read_text().splitlines())
    assert original_ids == prior_ids and len(prior_ids) == 2365
    assert 0 < len(supplemental_ids) <= 32 and not original_ids.intersection(supplemental_ids)
    assert supplemental['separate_from_original_executions'] == 2365
    assert supplemental['compiler']['identity'] == original['compiler']['identity']
    assert supplemental['compiler']['sha256'] == original['compiler']['sha256']
    assert supplemental['selected_source_files']
    for row in supplemental['selected_source_files']:
        path = ROOT/'test262/vendor/test262'/row['path']
        assert path.resolve().is_relative_to((ROOT/'test262/vendor/test262/test').resolve())
        assert path.stat().st_size == row['bytes'] and sha(path) == row['sha256']

    previous = read(PRIOR/'native-final/report.json')
    prior_record = read(DEST/'memory-intrinsic-publication-20261027.json')
    assert previous['complete'] and previous['source_commit'] == PRIOR_SOURCE and previous['passed_disjoint_scopes'] == 4874
    assert prior_record['verified_source_commit'] == prior_record['measured_source_commit'] == PRIOR_SOURCE
    assert prior_record['native']['passed'] == 4874
    prior_files = {row['path']:row for row in prior_record['retained_files']}
    for name in ('native-final/report.json', 'conformance/executions'):
        assert sha(PRIOR/name) == prior_files[name]['sha256']
    old = {(row['package'], row['target']):set(row['inventory']) for row in previous['scopes']}
    assert len(old) == 19 and len(native['scopes']) == 19
    scopes = []
    for scope in native['scopes']:
        key = scope['package'], scope['target']
        inventory = scope['inventory']
        assert scope['complete'] and len(inventory) == len(set(inventory)) == scope['passed']
        assert old[key] <= set(inventory), 'prior fa test IDs must remain present'
        prefix = scope['package']+'-'+scope['target']+'-part-'
        names = []
        for command in native['commands']:
            if not command['label'].startswith(prefix):
                continue
            raw = (BASE/'native-final'/command['stdout']).read_text()
            passed = [name.removesuffix(' - should panic') for name in re.findall(r'^test ([^\r\n]+) \.\.\. ok$', raw, re.M)]
            assert result_summaries(raw) == [('ok', str(len(passed)), '0', '0', '0', str(len(inventory)-len(passed)))]
            names.extend(passed)
        assert len(names) == len(set(names)) == len(inventory) and set(names) == set(inventory)
        scopes.append(dict(package=scope['package'], target=scope['target'], passed=scope['passed'],
                           executable_sha256=scope['executable_sha256'], focused_overlap=scope.get('focused_overlap', [])))
    assert len({(row['package'],row['target']) for row in scopes}) == 19
    assert {(row['package'],row['target']) for row in scopes} == set(old)
    assert sum(row['passed'] for row in scopes) == native['passed_disjoint_scopes'] == 4876

    bindings = read(BASE/'source-bindings-computed.json')
    assert len(bindings) == 2 and all(row['revision'] == source for row in bindings)
    by_lock = {row['extra_ignored_regress_lock']:row for row in bindings}
    assert set(by_lock) == {False, True}
    clean, local = by_lock[False], by_lock[True]
    assert original['compiler']['identity']['source_fingerprint'] == local['source_fingerprint']
    measured, rows = p.load_report(ci_path)
    assert measured['source_commit'] == source and measured['source_fingerprint'] == clean['source_fingerprint']
    assert measured['github_run_url'].endswith('/actions/runs/'+args.run)
    assert len(rows) == 17 and all(row['runtimes'][runtime]['status'] == 'ok' for row in rows for runtime in p.RUNTIMES)
    assert measured['rounds'] == 2 and measured['warmups'] == 10 and measured['samples'] == 7

    # All gates precede public mutations. Failed product-admission and stale
    # test-fixture attempts are retained separately from successful inventories.
    target, archive = DEST/(STEM+'.json'), DEST/(STEM+'-verification.tar.xz')
    assert not target.exists() and not archive.exists()
    provenance = BASE/'provenance'
    provenance.mkdir(exist_ok=True)
    (provenance/'ignored-regress-Cargo.lock').write_bytes((ROOT/'vendor/regress-0.10.5/Cargo.lock').read_bytes())
    files = []
    for path in sorted(BASE.rglob('*')):
        if not path.is_file():
            continue
        rel = path.relative_to(BASE).as_posix()
        parts = PurePosixPath(rel).parts
        if parts[0].startswith('github-') or 'images' in parts or path.name.startswith(('publication.', 'preview-')):
            continue
        if path.suffix not in ('.py','.json','.jsonl','.stdout','.stderr','.smaps','.txt','.lock','.md','.rs','.patch','.executions','.attempts') and path.name not in ('executions','stdout','stderr'):
            continue
        assert not path.is_symlink() and path.stat().st_size <= 128*1024**2
        assert not PurePosixPath(rel).is_absolute() and '..' not in parts
        with path.open('rb') as stream:
            assert not stream.read(8).startswith((b'\x7fELF', b'MZ', b'SCRWEP01', b'SCRWEP02', b'SCRWWA01'))
        files.append(dict(path=rel, bytes=path.stat().st_size, sha256=sha(path)))
    expanded = sum(row['bytes'] for row in files)
    assert expanded <= 2*1024**3
    with archive.open('xb') as output, lzma.LZMAFile(output, 'w', format=lzma.FORMAT_XZ, filters=[dict(id=lzma.FILTER_LZMA2,preset=1,dict_size=64*1024**2)]) as compressed:
        with tarfile.open(fileobj=compressed, mode='w|', format=tarfile.PAX_FORMAT) as tar:
            for row in files:
                member = tarfile.TarInfo(row['path']); member.size = row['bytes']; member.mode = 0o644
                with (BASE/row['path']).open('rb') as stream:
                    tar.addfile(member, stream)
    assert archive.stat().st_size <= 32*1024**2
    inventory = {row['path']:row for row in files}
    seen = set(); roundtrip = 0
    with tarfile.open(archive, 'r|xz') as tar:
        for member in tar:
            assert member.isfile() and member.name in inventory and member.name not in seen
            row = inventory[member.name]
            assert member.size == row['bytes'] <= 128*1024**2
            assert hashlib.file_digest(tar.extractfile(member), 'sha256').hexdigest() == row['sha256']
            seen.add(member.name); roundtrip += member.size
            assert roundtrip <= 2*1024**3
    assert seen == set(inventory) and roundtrip == expanded
    record = dict(schema='scriptw-regexp-unicode-memory-verification-v1', recorded_at=datetime.now(timezone.utc).isoformat(),
        verified_source_commit=source, measured_source_commit=source, required_repair_source=repair,
        prior_checkpoint='memory-intrinsic-publication-20261027.json', source_bindings=bindings,
        native=dict(passed=4876,scopes=scopes,raw_report='native-final/report.json',test_fixture_patch=fixture,original_failed_report='native/report.json',original_completed_scopes=4,original_completed_passed=420,unrelated_binaries_byte_identical=18,original_after_counters_available=False),
        stopped_conformance_guard=dict(raw_report='verification-repaired.json',raw_compiler_directory='conformance-guard-attempt',executions=0,after_counters_available=False,driver_repair=read(BASE/'driver-repair.json')),
        final_verification_report='verification-final.json',
        prior_product_admission_failure=dict(source='3b9094856c195255a5ce900d535855d0803de109',raw_report='attempt-3b9094856/check.json'),
        test262=dict(passed=2365,total=2365,batch_limit=16,compiler=original['compiler'],raw_report='conformance/report.json'),
        supplemental_unicode=dict(passed=supplemental['passed'],total=supplemental['total'],batch_limit=16,
            raw_report='conformance-unicode/report.json',scope=supplemental['scope'],disjoint_from_original=True),
        measurement=dict(run=args.run,url=measured['github_run_url'],raw_report_sha256=sha(ci_path)),
        interpretation='All19 native target inventories preserve priorfa IDs. Original2365 and separate bounded supplemental Unicode IDs are exact, disjoint selections in fresh batches<=16. Required prior repair commit is an ancestor of final source. The excluded tests.rs wire-data fixture is explicitly repaired; original501pass/1fail and original4scopes/420passes remain separate. All18unrelated binaries are byte-identical; original stopped scope has no after counters. The intermediate private conformance guard failed before any invocation; its stopped scope has no after counters, and final conformance uses a separate scope with the same completed Cargo producer. Prior3b product-admission failure is retained, and priorfa failed-fixture history remains in the linked checkpoint; none are counted again. No full pinned-suite refresh or causal RSS claim; local ignored regress lock and cleanCI identities remain distinct.',
        archive=dict(file=archive.name,sha256=sha(archive),bytes=archive.stat().st_size,expanded_bytes=expanded,member_count=len(files),max_expanded_bytes=2*1024**3,max_member_bytes=128*1024**2),
        retained_files=files)
    target.write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps(dict(native=4876,test262=2365,supplemental=supplemental['total'],archive=record['archive']),indent=2))


if __name__ == '__main__':
    main()
