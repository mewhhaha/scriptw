"""Bounded source-gated inert CI processing; private outputs only."""
import os,sys,subprocess,json,hashlib,time
from pathlib import Path
BASE=Path(__file__).resolve().parent;ROOT=BASE.parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from limited_verification import require_kernel_budget,kernel_group
require_kernel_budget(4*1024**3);assert sorted(os.sched_getaffinity(0))==[0]
group=kernel_group()
def counters():return {k:(group/k).read_text().strip() for k in ['memory.max','memory.swap.max','memory.oom.group','memory.peak','memory.events']}
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
record=dict(source_commit='e7e51222101533e421ffae41bb0ccad78ba638ba',run='40519969552',complete=False,scored_mutations=False,cpu_affinity=sorted(os.sched_getaffinity(0)),before=counters(),commands=[])
out=BASE/'ci-processing.json'
def save():out.write_text(json.dumps(record,indent=2)+'\n')
save();os.environ['MPLCONFIGDIR']=str(BASE/'mplconfig')
for name,args in [('validate-measured.py',['40519969552']),('analyze-ci-mappings.py',['40519969552']),('retain-unscored.py',['40519969552']),('render-previews.py',[])]:
 if name=='retain-unscored.py' and record.get('mapping_status')=='unavailable-validation-failed':continue
 stdout=BASE/(name+'.stdout');stderr=BASE/(name+'.stderr');start=time.monotonic()
 with stdout.open('xb') as a,stderr.open('xb') as b:r=subprocess.run([sys.executable,'-B',str(BASE/name),*args],cwd=ROOT,stdout=a,stderr=b,timeout=300)
 record['commands'].append(dict(script=name,args=args,exit_code=r.returncode,seconds=time.monotonic()-start,stdout=stdout.name,stdout_sha256=sha(stdout),stderr=stderr.name,stderr_sha256=sha(stderr)));record['after']=counters();save()
 if r.returncode and name in ('validate-measured.py','render-previews.py'):raise SystemExit(r.returncode)
 if r.returncode and name=='analyze-ci-mappings.py':
  record['mapping_status']='unavailable-validation-failed';save()
  continue
record['complete']=True;save()
