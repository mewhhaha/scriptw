"""Build affected scopes together, then verify exact native inventories serially."""
from datetime import datetime,timezone
import copy,hashlib,json,os,re,shutil,subprocess,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'scripts'))
from limited_verification import require_kernel_budget,kernel_group
from native_test_protocol import parse_inventory,result_summaries
require_kernel_budget(4*1024**3);assert len(os.sched_getaffinity(0))==1
SOURCE=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
OUT=BASE/'native-final';OUT.mkdir(exist_ok=False)
BUILD=ROOT/'target/performance-work-20261024/build'
PLAN=[('scriptw-aot-wasm','scriptw_aot_wasm','lib'),('scriptw-aot-wasm','runtime_link','test'),('scriptw-aot-wasm','structure_builtins','test'),('scriptw-aot-wasm','structure_language','test'),('scriptw-engine','scriptw_engine','lib')]
PLAN += [('scriptw-aot-wasm',name,'test') for name in ['emission','modules_realms','intl_temporal','structure_async']]
PLAN += [('scriptw-engine',name,'test') for name in ['aot_builtins','aot_gc_entries','aot_realm_modules','aot_language','aot_async','aot_generators','aot_regexp','aot_intl','aot_temporal','structure']]
gc_scope=('scriptw-engine','aot_gc_entries','test')
PLAN.remove(gc_scope);PLAN.insert(2,gc_scope)
engine_scope=('scriptw-engine','scriptw_engine','lib')
PLAN.remove(engine_scope);PLAN.insert(1,engine_scope)
# Execute every repaired target before the full adjacent checkpoint.
for name in reversed(['emission','modules_realms','intl_temporal']):
 scope=('scriptw-aot-wasm',name,'test');PLAN.remove(scope);PLAN.insert(0,scope)
PLAN.remove(gc_scope); PLAN.insert(0,gc_scope)
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def stamp():return datetime.now(timezone.utc).isoformat()
group=kernel_group()
def budget():return {k:(group/k).read_text().strip() for k in ['memory.max','memory.swap.max','memory.oom.group','memory.peak','memory.events']}
original=json.loads((BASE/'native/report.json').read_text())
fixture=json.loads((BASE/'wire-data-fixture.json').read_text())
old_binaries=json.loads((BASE/'native-original-binaries.json').read_text())
assert SOURCE==original['source_commit']==fixture['source_commit']=='e7e51222101533e421ffae41bb0ccad78ba638ba'
assert fixture['path']=='crates/scriptw-aot-wasm/src/tests.rs'
assert fixture['patch']=='wire-data-fixture.patch'
assert hashlib.sha256(subprocess.check_output(['git','show',SOURCE+':'+fixture['path']],cwd=ROOT)).hexdigest()==fixture['before_sha256']
assert len(old_binaries)==19 and len({(row['target'],tuple(row['kind']))for row in old_binaries})==19
assert {(row['target'],tuple(row['kind']))for row in old_binaries}=={(name,(kind,))for _,name,kind in PLAN}
assert os.environ['SCRIPTW_MODULE_MEMORY_CACHE_ENTRIES']=='1' and os.environ['SCRIPTW_MODULE_MEMORY_CACHE_LIMIT_BYTES']==str(64*1024**2)
completed=[scope for scope in original['scopes'] if scope['complete']]
assert len(completed)==4 and sum(scope['passed'] for scope in completed)==420
failed=[scope for scope in original['scopes'] if not scope['complete']]
assert len(failed)==1 and failed[0]['target']=='scriptw_aot_wasm' and len(failed[0]['inventory'])==502
completed_keys={(scope['package'],scope['target']) for scope in completed}
baseline=json.loads((ROOT/'target/memory-intrinsic-publication-20261027-evidence/native-final/report.json').read_text())
assert baseline['complete'] and baseline['passed_disjoint_scopes']==4874 and baseline['source_commit']=='fa204ae2bdccd798b98439d4c347b576c2ee4508'
for scope in completed:
 previous=[row for row in baseline['scopes']if row['package']==scope['package']and row['target']==scope['target']];assert len(previous)==1
 assert set(previous[0]['inventory'])<=set(scope['inventory'])
report=dict(source_commit=SOURCE,complete=False,started_at=stamp(),cpu_affinity=sorted(os.sched_getaffinity(0)),before=budget(),commands=[],scopes=[])
report.update(original_report='native/report.json', original_budget_before=original['before'],test_fixture_patch=fixture,
 interpretation='Four completed unchanged target inventories retain exact original execution streams. The failed502-case AOT library target is rebuilt with a recorded excluded-test-only R active-segment inspection repair; original501pass/1fail attempt is retained separately, not added to totals. Every other original native binary must remain byte-identical after the identical19-target rebuild. Current before/after counters belong to this repair scope; original stopped scope has no after counters.')
report['scopes']=copy.deepcopy(completed)
for row in original['commands']:
 if not any(row['label'].startswith(package+'-'+target+'-') for package,target in completed_keys):continue
 assert row['exit_code']==0
 for stream in ('stdout','stderr'):
  src=BASE/'native'/row[stream];assert sha(src)==row[stream+'_sha256'];shutil.copyfile(src,OUT/row[stream]);assert sha(OUT/row[stream])==row[stream+'_sha256']
 report['commands'].append(copy.deepcopy(row))
def save():(OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n')
def source():
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==SOURCE
 changed=subprocess.check_output(['git','diff','--name-only','HEAD','--','crates','vendor','scripts','Cargo.toml','Cargo.lock'],cwd=ROOT,text=True).splitlines()
 assert changed==[fixture['path']],changed
 assert sha(ROOT/fixture['path'])==fixture['after_sha256'] and sha(BASE/fixture['patch'])==fixture['patch_sha256']
 assert subprocess.check_output(['git','diff','--binary','HEAD','--',fixture['path']],cwd=ROOT)==(BASE/fixture['patch']).read_bytes()
def run(label,args,cwd=ROOT):
 source();row=dict(label=label,command=list(map(str,args)),cwd=str(cwd),started_at=stamp(),stdout=label+'.stdout',stderr=label+'.stderr')
 report['commands'].append(row);save();print(label,'started',flush=True);start=time.monotonic()
 with (OUT/row['stdout']).open('xb') as out,(OUT/row['stderr']).open('xb') as err:
  child=subprocess.run(row['command'],cwd=cwd,stdout=out,stderr=err,timeout=3600)
 row.update(exit_code=child.returncode,seconds=time.monotonic()-start,stdout_sha256=sha(OUT/row['stdout']),stderr_sha256=sha(OUT/row['stderr']));save()
 assert child.returncode==0,label+' failed; original streams retained'
 return (OUT/row['stdout']).read_text()
args=['cargo','test','--locked','--offline','--release','--jobs','1','--target-dir',BUILD,'-p','scriptw-engine','-p','scriptw-aot-wasm','--lib']
for name in sorted({n for _,n,k in PLAN if k=='test'}):args+=['--test',name]
args+=['--no-run','--message-format=json']
assert list(map(str,args))==original['commands'][0]['command'], 'repair must retain the identical19-target Cargo feature graph'
text=run('cargo-native',args);cargo=[json.loads(x) for x in text.splitlines()]
assert cargo[-1]==dict(reason='build-finished',success=True)
unchanged=0
for old in old_binaries:
 if old['target']=='scriptw_aot_wasm' and old['kind']==['lib']:continue
 assert sha(Path(old['path']))==old['sha256'],('unrelated native binary changed',old['target'])
 unchanged+=1
assert unchanged==18
report['unchanged_original_binaries']=18;save()

for package,name,kind in PLAN:
 if (package,name) in completed_keys:continue
 producers=[r for r in cargo if r.get('reason')=='compiler-artifact' and r.get('executable') and r['target']['name']==name and r['target']['kind']==[kind] and r['profile']['test']]
 assert len(producers)==1,(package,name)
 producer=producers[0];original=Path(producer['executable']);folder=OUT/(package+'-'+name);folder.mkdir()
 binary=folder/'tests';shutil.copy2(original,binary);assert sha(binary)==sha(original) and binary.stat().st_nlink==1
 scope=dict(package=package,target=name,kind=kind,executable_sha256=sha(binary),cargo_producer=producer,complete=False)
 report['scopes'].append(scope);save()
 inventory=parse_inventory(run(package+'-'+name+'-inventory',[binary,'--list'],ROOT/'crates'/package));scope['inventory']=inventory;save()
 if name=='scriptw_aot_wasm':assert inventory==failed[0]['inventory'];scope['test_fixture_patch']=fixture;save()
 baseline=json.loads((ROOT/'target/memory-intrinsic-publication-20261027-evidence/native-final/report.json').read_text())
 assert baseline['complete'] and baseline['passed_disjoint_scopes']==4874 and baseline['source_commit']=='fa204ae2bdccd798b98439d4c347b576c2ee4508'
 previous=[s for s in baseline['scopes'] if s['package']==package and s['target']==name];assert len(previous)==1
 assert set(previous[0]['inventory'])<=set(inventory)
 if name=='aot_regexp':assert all(any(case in identifier for identifier in inventory)for case in ['cold_and_repeated_property_lookups_survive_gc_in_independent_runtimes','property_and_normalization_images_initialize_independently_in_either_order'])
 if name in ('scriptw_aot_wasm','scriptw_engine','aot_gc_entries','runtime_link','aot_regexp'):
  focused=[n for n in inventory if any(part in n for part in ('tests::preseeded_wire_data_stays_in_private_memory','compiler_owned_pool::','build_package::metadata::','runtime_artifact::cache::','aot_regexp_unicode_property_data::','literal_length_grows_passive_data_without_expanding_bootstrap_code','tests::unobserved_arguments::','aot_gc_intrinsic_publication::','aot_gc_value_backing_transitions::','intrinsics::deferred_methods::','compact_records::','packed_array','rooted_completion_graph::','program_imports::','import_compaction::','import_exports_tests::','heap_programs_link_against_one_runtime_module','with_has_binding_has_bounded_incremental_function_body_growth','nested_with_writes_share_dynamic_property_set_dispatch','plain_data_literals::','emitted_direct_eval_factory_retains_full_witness_exact_r_and_valid_typed_hook_closure','emitted_native_global_scripts_are_fresh_valid_p_with_owned_hook_factory_and_init_only_bootstrap','regexp_program_wire_data_is_aligned_and_deduplicated','decimal_helper_tests::','native_context_','late_runtime_import','retained_runtime_export','native_function_and_regexp_eval_resolve_new_exports_from_the_original_r'))]
  assert focused,(package,name)
  focus_chunks=[focused[i:i+8] for i in range(0,len(focused),8)] if name=='scriptw_engine' else [focused]
  for focus_index,focus_chunk in enumerate(focus_chunks):
   focused_text=run(package+'-'+name+f'-focused-{focus_index:02d}',[binary,'--exact','--include-ignored','--test-threads=1',*focus_chunk],ROOT/'crates'/package)
   focused_names=[n.removesuffix(' - should panic') for n in re.findall(r'^test ([^\r\n]+) \.\.\. ok$',focused_text,re.M)]
   assert len(focused_names)==len(focus_chunk) and set(focused_names)==set(focus_chunk)
  scope['focused_overlap']=focused;save()
 chunks=[inventory[i:i+8] for i in range(0,len(inventory),8)] if name=='scriptw_engine' else [inventory]
 passed=set()
 for index,chunk in enumerate(chunks):
  label=package+'-'+name+f'-part-{index:03d}'
  # Explicit exact names allow small processes without reducing scope or skipping ignored cases.
  text=run(label,[binary,'--exact','--include-ignored','--test-threads=1',*chunk],ROOT/'crates'/package)
  names=[n.removesuffix(' - should panic') for n in re.findall(r'^test ([^\r\n]+) \.\.\. ok$',text,re.M)]
  assert len(names)==len(chunk) and set(names)==set(chunk) and not passed.intersection(names),(label,names,chunk)
  assert result_summaries(text)==[('ok',str(len(chunk)),'0','0','0',str(len(inventory)-len(chunk)))],label
  passed.update(names);scope['passed']=len(passed);save()
 assert passed==set(inventory) and sha(binary)==scope['executable_sha256']
 scope['complete']=True;save();print(package,name,len(passed),'passed',flush=True)
assert len(report['scopes'])==len(PLAN)==19
assert sum(scope['passed']for scope in report['scopes'])==4876
report.update(complete=True,finished_at=stamp(),after=budget(),passed_disjoint_scopes=sum(x['passed'] for x in report['scopes']));save()
print('complete',report['passed_disjoint_scopes'],'native cases',flush=True)
