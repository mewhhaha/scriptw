"""Validate complete matched evidence and summarize actual post-execution RSS."""
import json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'scripts'))
import precompiled_comparison as p
import argparse
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('run')
parser.add_argument('--report',type=Path,help='actual downloaded raw CI report path')
args=parser.parse_args()
run=args.run;assert run.isdecimal()
path=args.report or BASE/('github-'+run)/'precompiled-measurements/precompiled-evidence/report.json'
report,rows=p.load_report(path)
assert report['github_run_url'].endswith('/actions/runs/'+run)
assert report['samples']==7 and report['warmups']==10 and report['rounds']==2
bindings=json.loads((BASE/'source-bindings-computed.json').read_text())
clean=next(b for b in bindings if not b['extra_ignored_regress_lock'])
assert report['source_commit']==clean['revision']=='3b9094856c195255a5ce900d535855d0803de109'
assert report['source_fingerprint']==clean['source_fingerprint']
assert len(rows)==17 and all(row['runtimes'][rt]['status']=='ok' for row in rows for rt in p.RUNTIMES)
table=[]
for row in rows:
 sw,sc=row['runtimes']['scriptw'],row['runtimes']['scriptc']
 table.append(dict(file=row['file'],scriptw_rss_mib=sw['rss_mib'],scriptc_rss_mib=sc['rss_mib'],
                   ratio=sw['rss_mib']/sc['rss_mib'],scriptw_ms=sw['ms'],scriptc_ms=sc['ms']))
summary=dict(source=report['source_commit'],report_sha256=p.digest(path),
             ratio_min=min(r['ratio'] for r in table),ratio_max=max(r['ratio'] for r in table),table=table)
(BASE/'measured-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(dict(source=summary['source'],ratio_min=summary['ratio_min'],ratio_max=summary['ratio_max'],
                     representative=[r for r in table if r['file'] in ('integer.js','objects.js','retained-objects.js')]),indent=2))
