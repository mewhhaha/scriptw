"""Publish prose only after the complete source-bound Unicode checkpoint exists.

Prepared privately; do not run while verification/publication gates are pending.
This script executes no archived artifacts and publishes no benchmark scores.
"""
import hashlib
import json
from pathlib import Path
import re
import sys

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
DEST = ROOT/'docs/rust-rewrite'
STEM = 'memory-regexp-unicode-data-20261027'
SOURCE = 'e7e51222101533e421ffae41bb0ccad78ba638ba'
PREVIOUS = 'fa204ae2bdccd798b98439d4c347b576c2ee4508'
CLEAN = '65545230fcd34527854e06431e0917a98adbe58c2a5ba92b5518ccd99ae09321'
LOCAL = 'f95991e5a2af12a901c2986c0b0f98ac72200cc6d70627f178e8b80bf68fbb7e'
sys.path.insert(0, str(ROOT/'scripts'))
import precompiled_comparison as p
from native_test_protocol import result_summaries


def read(path):
    return json.loads(path.read_text())


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def validate_stopped_driver(source):
    stopped = read(BASE/'verification-repaired.json')
    assert stopped['source_commit'] == source and not stopped['complete'] and 'after' not in stopped
    assert stopped['cpu_affinity'] == [0]
    assert stopped['before']['memory.max'] == '4294967296'
    assert stopped['before']['memory.swap.max'] == '0' and stopped['before']['memory.oom.group'] == '1'
    assert [(row['label'], row['exit_code']) for row in stopped['commands']] == [
        ('cheap-after-repair-driver',0), ('native-resume-driver',0), ('cargo-products',0), ('test262-driver',1)]
    for command in stopped['commands']:
        for key in ('stdout','stderr'):
            assert sha(BASE/command[key]) == command[key+'_sha256']
    guard = BASE/'conformance-guard-attempt'
    assert guard.is_dir() and {path.name for path in guard.iterdir()} == {'compiler'}
    assert not (guard/'report.json').exists(), 'guard failed before the first invocation was recorded'
    products = [json.loads(line) for line in (BASE/'cargo-products.jsonl').read_text().splitlines()]
    assert products[-1] == dict(reason='build-finished',success=True)
    rows = [row for row in products if row.get('reason')=='compiler-artifact' and row.get('executable')
            and row['target']['name']=='scriptw' and row['target']['kind']==['bin'] and not row['profile']['test']]
    assert len(rows)==1
    frozen_sha = sha(guard/'compiler')
    repair = read(BASE/'driver-repair.json')
    assert repair['source_commit'] == source and repair['path'] == 'test262.py'
    assert repair['before_path'] == 'test262-guard-attempt.py'
    assert repair['guard_attempt_directory'] == 'conformance-guard-attempt'
    assert repair['executed_commands'] == repair['executed_cases'] == 0
    assert frozen_sha == repair['guard_attempt_compiler_sha256']
    assert sha(BASE/repair['before_path']) == repair['before_sha256']
    assert sha(BASE/repair['path']) == repair['after_sha256']
    assert sha(BASE/repair['patch']) == repair['patch_sha256']
    return stopped, rows[0], frozen_sha


def main():
    record = read(DEST/(STEM+'.json'))
    assert record['schema'] == 'scriptw-regexp-unicode-memory-verification-v1'
    assert record['verified_source_commit'] == record['measured_source_commit'] == SOURCE
    assert record['measurement']['run'] == '40519969552'
    assert record['measurement']['url'] == 'https://github.com/mewhhaha/scriptw/actions/runs/40519969552'
    scopes = record['native']['scopes']
    assert record['native']['passed'] == sum(row['passed'] for row in scopes) == 4876
    assert len(scopes) == len({(row['package'], row['target']) for row in scopes}) == 19
    assert record['test262']['passed'] == record['test262']['total'] == 2365
    assert record['test262']['batch_limit'] == 16
    supplemental = record['supplemental_unicode']
    extra = supplemental['passed']
    assert 1 <= extra <= 32 and extra == supplemental['total']
    assert supplemental['disjoint_from_original'] and supplemental['batch_limit'] == 16
    bindings = {row['extra_ignored_regress_lock']: row for row in record['source_bindings']}
    assert len(record['source_bindings']) == 2 and set(bindings) == {False, True}
    assert all(row['revision'] == SOURCE for row in bindings.values())
    assert bindings[False]['source_fingerprint'] == CLEAN and bindings[True]['source_fingerprint'] == LOCAL
    assert bindings[True]['files'] == bindings[False]['files'] + 1
    compiler = record['test262']['compiler']['identity']
    assert compiler['source_revision'] == dict(kind='git-commit', commit=SOURCE)
    assert compiler['source_fingerprint'] == LOCAL

    native = read(BASE/'native-final/report.json')
    repaired = read(BASE/'verification-final.json')
    stopped_batch, product_producer, frozen_guard_sha = validate_stopped_driver(SOURCE)
    check = read(BASE/'check.json')
    for report in (native, repaired, check):
        assert report['complete'] and report['source_commit'] == SOURCE
    assert native['passed_disjoint_scopes'] == 4876 and check['exit_code'] == 0
    assert repaired['driver_repair'] == record['stopped_conformance_guard']['driver_repair'] == read(BASE/'driver-repair.json')
    assert record['final_verification_report'] == 'verification-final.json'
    assert record['required_repair_source'] == repaired['required_repair_source'] == stopped_batch['required_repair_source']
    assert re.fullmatch('[0-9a-f]{40}', record['required_repair_source'])
    assert [row['label'] for row in repaired['commands']] == ['test262-final-driver','test262-unicode-final-driver']
    assert all(row.get('exit_code', row.get('returncode')) == 0 for row in repaired['commands'])
    for command in repaired['commands']:
        for key in ('stdout','stderr'):
            assert sha(BASE/command[key]) == command[key+'_sha256']
    for name in ('cheap-verified/cheap-main.json', 'cheap-after-repair/cheap-main.json'):
        cheap = read(BASE/name)
        assert cheap['complete'] and cheap['base_commit'] == SOURCE
        assert all(row.get('exit_code', row.get('returncode')) == 0 for row in cheap['commands'])
    original = read(BASE/'conformance/report.json')
    unicode = read(BASE/'conformance-unicode/report.json')
    ids = []
    for report, path, expected in ((original, 'conformance', 2365), (unicode, 'conformance-unicode', extra)):
        assert report['complete'] and report['source_commit'] == SOURCE and report['batch_limit'] == 16
        assert report['passed'] == report['total'] == report['selected_executions'] == expected
        assert report['compiler']['identity'] == compiler
        assert report['compiler']['cargo_producer'] == product_producer and report['compiler']['sha256'] == frozen_guard_sha
        listing = BASE/path/'executions'
        assert sha(listing) == report['execution_list_sha256']
        selected = listing.read_text().splitlines()
        assert len(selected) == len(set(selected)) == expected
        ids.append(set(selected))
    assert not ids[0].intersection(ids[1]) and unicode['separate_from_original_executions'] == 2365
    assert ids[0] == set((ROOT/'target/memory-intrinsic-publication-20261027-evidence/conformance/executions').read_text().splitlines())

    retained = {row['path']: row for row in record['retained_files']}
    for name in ('native-final/report.json', 'verification-repaired.json', 'verification-final.json', 'driver-repair.json', 'check.json',
                 'cheap-verified/cheap-main.json', 'cheap-after-repair/cheap-main.json',
                 'conformance/report.json', 'conformance/executions',
                 'conformance-unicode/report.json', 'conformance-unicode/executions',
                 'wire-data-fixture.json', 'native/report.json', 'native-original-binaries.json',
                 'attempt-3b9094856/check.json', 'data-segments.json'):
        assert name in retained and sha(BASE/name) == retained[name]['sha256']
    archive = DEST/record['archive']['file']
    assert archive.name == STEM+'-verification.tar.xz'
    assert archive.stat().st_size == record['archive']['bytes'] and sha(archive) == record['archive']['sha256']
    fixture = read(BASE/'wire-data-fixture.json')
    assert fixture == native['test_fixture_patch'] == repaired['test_fixture_patch'] == stopped_batch['test_fixture_patch'] == record['native']['test_fixture_patch']
    assert fixture['source_commit'] == SOURCE
    assert fixture['path'] == fixture['compiler_input_exclusion'] == 'crates/scriptw-aot-wasm/src/tests.rs'
    assert fixture['before_sha256'] != fixture['after_sha256'] and sha(ROOT/fixture['path']) == fixture['after_sha256']
    assert sha(BASE/fixture['patch']) == fixture['patch_sha256'] == retained[fixture['patch']]['sha256']
    patch = (BASE/fixture['patch']).read_text()
    assert re.findall(r'^diff --git a/(\S+) b/(\S+)$', patch, re.M) == [(fixture['path'], fixture['path'])]
    failed = read(BASE/'native/report.json')
    assert failed['source_commit'] == SOURCE and not failed['complete'] and 'after' not in failed
    completed = [row for row in failed['scopes'] if row['complete']]
    assert len(completed) == 4 and sum(row['passed'] for row in completed) == 420
    assert native['original_budget_before'] == failed['before']
    raw = BASE/'native/scriptw-aot-wasm-scriptw_aot_wasm-part-000.stdout'
    assert result_summaries(raw.read_text()) == [('FAILED', '501', '1', '0', '0', '0')]
    assert sha(raw) == retained[str(raw.relative_to(BASE))]['sha256']
    binaries = read(BASE/'native-original-binaries.json')
    assert len(binaries) == 19
    unchanged = 0
    for row in native['scopes']:
        if row['package'] == 'scriptw-aot-wasm' and row['target'] == 'scriptw_aot_wasm':
            assert row['passed'] == 502
            continue
        before = [old for old in binaries if old['target'] == row['target'] and old['kind'] == [row['kind']]]
        assert len(before) == 1 and before[0]['sha256'] == row['executable_sha256']
        unchanged += 1
    assert unchanged == native['unchanged_original_binaries'] == record['native']['unrelated_binaries_byte_identical'] == 18
    prior_failure = read(BASE/'attempt-3b9094856/check.json')
    assert not prior_failure['complete'] and prior_failure['exit_code'] != 0
    assert prior_failure['source_commit'] == record['prior_product_admission_failure']['source'] == '3b9094856c195255a5ce900d535855d0803de109'

    static = read(BASE/'data-segments.json')
    assert static['source_commit'] == SOURCE and 'inert static bytes only' in static['scope']
    assert static['check_stdout_sha256'] == check['stdout_sha256']
    assert len(static['packages']) == 2
    for package in static['packages']:
        assert package['layout'] == 27 and package['source_fingerprint'] == LOCAL
        segments = package['segments']
        assert [row['physical'] for row in segments] == list(range(6))
        assert [row['mode'] for row in segments] == ['passive']*3 + ['active']*3
        assert segments[2]['bytes'] == 455304
        assert package['virtual_reassembly_order'] == [3, 2, 4, 1, 5]
        assert package['virtual_reassembly_bytes'] == package['static_bytes'] == sum(row['bytes'] for row in segments[1:])
        cursor = 4096
        for index in package['virtual_reassembly_order']:
            row = segments[index]
            if row['mode'] == 'active':
                assert row['offset'] == cursor
            cursor += row['bytes']
        assert cursor == 4096 + package['static_bytes']

    measured, rows = p.load_report(DEST/'precompiled-comparison.json', DEST/'precompiled-comparison.tar.gz')
    assert measured['source_commit'] == SOURCE and measured['source_fingerprint'] == CLEAN
    assert measured['samples'] == 7 and measured['warmups'] == 10 and measured['rounds'] == 2
    assert len(rows) == 17 and all(row['runtimes'][rt]['status'] == 'ok' for row in rows for rt in p.RUNTIMES)
    summary = read(BASE/'measured-summary.json')
    assert summary['source'] == SOURCE and summary['report_sha256'] == record['measurement']['raw_report_sha256']
    actual = [dict(file=row['file'], scriptw_rss_mib=row['runtimes']['scriptw']['rss_mib'],
                   scriptc_rss_mib=row['runtimes']['scriptc']['rss_mib'],
                   ratio=row['runtimes']['scriptw']['rss_mib']/row['runtimes']['scriptc']['rss_mib'],
                   scriptw_ms=row['runtimes']['scriptw']['ms'], scriptc_ms=row['runtimes']['scriptc']['ms']) for row in rows]
    assert actual == summary['table']
    assert summary['ratio_min'] == min(row['ratio'] for row in actual)
    assert summary['ratio_max'] == max(row['ratio'] for row in actual) and summary['ratio_max'] > 1
    ratio = f"{summary['ratio_min']:.3f}–{summary['ratio_max']:.3f}"
    table = {row['file']: row for row in actual}
    for graph in ('precompiled-memory.svg', 'precompiled-execution.svg'):
        assert (DEST/'assets'/graph).is_file()
    prior_record = read(DEST/'memory-intrinsic-publication-20261027.json')
    assert prior_record['verified_source_commit'] == prior_record['measured_source_commit'] == PREVIOUS

    readme = ROOT/'README.md'
    old = readme.read_text()
    start = old.index('**Measured 2026-10-27 on one GitHub Actions runner**, compiler `fa204ae2b`.')
    end = old.index('\n## Benchmarks', start)
    lines = [f'**Measured 2026-10-27 on one GitHub Actions runner**, compiler `{SOURCE[:9]}`.',
        'The [precompiled benchmark workflow](docs/rust-rewrite/contracts/precompiled-comparison.md)',
        'compares Scriptw and Scriptc in the same Wasmtime executable. JavaScript and',
        'Wasm compilation run in separate producer processes; both measured consumers',
        'disable compilation and use identical native optimization and runtime settings.',
        'Both passed the original checksums on **17/17 workloads** across two rounds.',
        f"Scriptw's median post-execution process RSS remains **{ratio}× Scriptc's**:", '',
        '| Workload | Scriptw RSS | Scriptc RSS |', '| --- | ---: | ---: |']
    for label, filename in [('Integer','integer.js'), ('Objects','objects.js'), ('Retained objects','retained-objects.js')]:
        row = table[filename]
        lines.append(f"| {label} | {row['scriptw_rss_mib']:.1f} MiB | {row['scriptc_rss_mib']:.1f} MiB |")
    lines += ['', 'These are medians of 14 measured samples per runtime and workload, after ten',
        'checked warmups per round, with each Store still alive. RSS includes code,',
        'runtime and allocator history; it is neither live JS heap nor peak memory.',
        'Scriptc parity remains open under the same workloads, checksums and boundaries.',
        'This pass retains the complete RegExp Unicode property catalogue as passive',
        'data and copies its reserved range on first use in each actual R instance.',
        'Comparisons across separate CI runners do not establish causal savings.',
        f'[Verification](docs/rust-rewrite/{STEM}.md):',
        f'**4,876 native cases, 2,365 original pinned Test262 executions and {extra} separate',
        'Unicode executions passed**. The supplemental IDs are disjoint from the',
        'original selection. One excluded wire-data inspection fixture was repaired;',
        'the original failed attempt and exact patch are retained. Product compiler',
        'inputs match the measured source; verification fixtures are explicitly recorded.',
        'Verification used one CPU, a 4-GiB process-tree cap, no swap and bounded module',
        'retention. Original Test262 executions ran in fresh batches of at most 16.',
        'This selected verification leaves the ordinary V8 comparison and full pinned',
        'Test262 status below unchanged.', '',
        '[All measurements and complete evidence](docs/rust-rewrite/precompiled-comparison.md) ·',
        '[Precompiled process-memory graph](docs/rust-rewrite/assets/precompiled-memory.svg) ·',
        '[Precompiled execution-time graph](docs/rust-rewrite/assets/precompiled-execution.svg) ·',
        f"[CI run]({record['measurement']['url']}).", '']
    readme_text = old[:start] + '\n'.join(lines) + old[end:]
    assert readme_text[:start] == old[:start]
    assert readme_text[readme_text.index('\n## Benchmarks'):] == old[end:]
    contract = DEST/'contracts/regexp-unicode-property-data.md'
    footer = ('Whole-batch compilation, semantic verification and matched measurements remain\n'
              'pending. Passive storage does not establish reduced native-map residency: native\n'
              'admission may still read the bytes. No RSS or execution-time saving is claimed.\n')
    contract_text = contract.read_text()
    assert contract_text.count(footer) == 1
    contract_text = contract_text.replace(footer, f'''The source-bound batch passed 4,876 native cases across 19 targets, 2,365 exact
original pinned Test262 executions and {extra} separate disjoint Unicode executions.
The matched 17-workload comparison remains {ratio}× Scriptc process RSS; parity
is still open. Passive storage and independent CI runner observations do not
establish causal resident-memory or execution-time savings.
See [verification and measurements](../{STEM}.md).
''')
    checkpoint = DEST/(STEM+'.md')
    assert not checkpoint.exists(), 'Inspect an existing checkpoint before replacing it'
    doc = f'''# RegExp Unicode data memory checkpoint

Measured and verified product source `{SOURCE}`; refreshed 2026-10-27.
The [matched comparison](precompiled-comparison.md) remains **{ratio}× Scriptc
process RSS**. Scriptc parity is still open. The [CI run]({record['measurement']['url']})
passed all 17 unchanged workloads and original checksums in both runtimes.

R keeps its complete 455,304-byte RegExp Unicode property catalogue in passive
segment 2. The sole runtime property lookup copies the exact reserved range
before reading, then publishes readiness on that actual R instance. Copy and
readiness publication invoke no JavaScript. The segment remains available;
normalization has its own readiness and segment, preserving both initialization
orders and independent Stores. Alias names, code-point ranges, string properties,
all table pointers and virtual addresses retain their original representation.

R has six physical data segments: passive UTF-16, normalization and property
catalogue followed by three active fragments excluding the two deferred ranges.
P retains its four passive data roles. Immutable Cargo metadata hashes all six
physical spans and reconstructs the canonical static image in order [3,2,4,1,5].
Exact lengths, checked cursor bounds and per-span hashes remain required. Receipt
magic SCRWRM02 and runtime layout 27 bind this private contract.
Raw runtime-package/cache admission was corrected to validate all active offsets
across both deferred gaps and the complete static extent; checksums alone cannot
substitute for those structural checks. The earlier product-admission failure
at `3b9094856c195255a5ce900d535855d0803de109` is retained separately, never counted
as successful verification. [Inert segment inspection]({STEM}.json) retains
`data-segments.json` for both owned Cargo runtime packages. It proves segment
placement and extents, not which pages were resident during a measured execution.
See the [data contract](contracts/regexp-unicode-property-data.md).

The release workspace/all-target check and complete source/identity/profile,
retired-JS and formatting guards passed. All **4,876 native cases across 19
disjoint target inventories** passed, retaining the prior checkpoint's IDs.
All **2,365 original pinned Test262 executions** passed in fresh batches of at
most 16, preserving the exact prior selection. Another **{extra} Unicode executions**
passed as a separate bounded selection with no overlapping IDs. The published
record owns their exact IDs, source files and compiler identity. This selected
verification leaves ordinary V8 results and full pinned-suite status unchanged.

An explicitly recorded excluded test-fixture repair changes only
`crates/scriptw-aot-wasm/src/tests.rs`: its preseed inspection selects physical
R segment 3 instead of 2, while retaining exact prefix bytes, reconstructed virtual
image, increasing active offsets, and R/P segment-count assertions. The original
501-pass/1-fail attempt and exact before/after patch are retained. The
rebuilt AOT library passed all 502 cases; 18 unrelated binaries are byte-identical.
Four completed original scopes totaling 420 passes retain their original streams.
Those passes are counted once. The stopped original scope has no after-resource
counters; successful resume counters describe the new bounded scope. A private
conformance-driver guard then rejected this recorded fixture before any compiler
invocation. Its raw failure and driver repair remain separate; final conformance
used the same completed Cargo producer in a fresh bounded scope.

Both runtimes use the same compiler-disabled Wasmtime host/configuration, with
two rounds, ten checked warmups per round and seven measured samples per round.
Post-execution RSS includes code, runtime and allocator history with Store alive;
it is neither live JS heap nor peak memory. Separate CI runner observations and
unscored mapping samples cannot isolate causal savings from this change. No cost
was subtracted from either runtime. The canonical report owns exact values and
both regenerated graphs.

Verification retained one CPU, a 4-GiB process-tree cap, no swap, grouped OOM and
a one-entry/64-MiB module cache. Clean CI input fingerprint: `{CLEAN}`.
Local fingerprint with the separately recorded ignored regress lock: `{LOCAL}`.
These source closures remain distinct and explicitly bound to the same commit.

[Verification record]({STEM}.json) · [Lossless raw archive]({STEM}-verification.tar.xz).
Native executables and serialized images are excluded from publication. Exact
raw failures, repairs, limits, disjoint test inventories and hashes are retained.
'''
    # Sole public mutation boundary: every gate and prepared text check precedes it.
    assert 'remain pending' not in contract_text and ratio in doc
    readme.write_text(readme_text)
    contract.write_text(contract_text)
    checkpoint.write_text(doc)


if __name__ == '__main__':
    main()
