"""Render source-validated scored evidence into private previews only."""
import json,os,sys,subprocess
from pathlib import Path
BASE=Path(__file__).resolve().parent;ROOT=BASE.parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
import precompiled_comparison as p
from limited_verification import require_kernel_budget
require_kernel_budget(4*1024**3);assert len(os.sched_getaffinity(0))==1
report,rows=p.load_report(BASE/'github-40519969552/precompiled-measurements/precompiled-evidence/report.json')
summary=json.loads((BASE/'measured-summary.json').read_text())
assert report['source_commit']==summary['source']=='e7e51222101533e421ffae41bb0ccad78ba638ba'
assert p.digest(BASE/'github-40519969552/precompiled-measurements/precompiled-evidence/report.json')==summary['report_sha256']
for metric in p.CHARTS:
 svg=BASE/('preview-'+metric+'.svg');png=svg.with_suffix('.png')
 svg.write_bytes(p.render(report,rows,metric))
 subprocess.run(['rsvg-convert','-o',str(png),str(svg)],check=True,timeout=60)
 print(svg.name,p.digest(svg),png.name,p.digest(png),flush=True)
