#[path = "/home/mewhhaha/src/porffor/target/memory-regexp-unicode-data-20261027/crates/scriptw-aot-wasm/tests/structure_builtins/array_pop_algorithm_owner_structure.rs"]
mod array_pop_algorithm_owner_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-regexp-unicode-data-20261027/crates/scriptw-aot-wasm/tests/structure_builtins/array_push_algorithm_owner_structure.rs"]
mod array_push_algorithm_owner_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-regexp-unicode-data-20261027/crates/scriptw-aot-wasm/tests/structure_builtins/bigint_number_policy_structure.rs"]
mod bigint_number_policy_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-regexp-unicode-data-20261027/crates/scriptw-aot-wasm/tests/structure_builtins/callable_function_prototype_structure.rs"]
mod callable_function_prototype_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-regexp-unicode-data-20261027/crates/scriptw-aot-wasm/tests/structure_builtins/coercive_number_arithmetic_operation_structure.rs"]
mod coercive_number_arithmetic_operation_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-regexp-unicode-data-20261027/crates/scriptw-aot-wasm/tests/structure_builtins/ecmascript_trim_mode_structure.rs"]
mod ecmascript_trim_mode_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-regexp-unicode-data-20261027/crates/scriptw-aot-wasm/tests/structure_builtins/error_builtin_dispatch_ownership_structure.rs"]
mod error_builtin_dispatch_ownership_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-regexp-unicode-data-20261027/crates/scriptw-aot-wasm/tests/structure_builtins/find_via_predicate_structure.rs"]
mod find_via_predicate_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-regexp-unicode-data-20261027/crates/scriptw-aot-wasm/tests/structure_builtins/function_prototype_materialization_structure.rs"]
mod function_prototype_materialization_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-regexp-unicode-data-20261027/crates/scriptw-aot-wasm/tests/structure_builtins/function_prototype_receiver_ownership_structure.rs"]
mod function_prototype_receiver_ownership_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-regexp-unicode-data-20261027/crates/scriptw-aot-wasm/tests/structure_builtins/function_prototype_symbol_has_instance_structure.rs"]
mod function_prototype_symbol_has_instance_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-regexp-unicode-data-20261027/crates/scriptw-aot-wasm/tests/structure_builtins/heap_bigint_sign_domain_structure.rs"]
mod heap_bigint_sign_domain_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-regexp-unicode-data-20261027/crates/scriptw-aot-wasm/tests/structure_builtins/json_builtin_policy_domain_structure.rs"]
mod json_builtin_policy_domain_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-regexp-unicode-data-20261027/crates/scriptw-aot-wasm/tests/structure_builtins/json_module_native_structure.rs"]
mod json_module_native_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-regexp-unicode-data-20261027/crates/scriptw-aot-wasm/tests/structure_builtins/json_parse_frame_state_structure.rs"]
mod json_parse_frame_state_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-regexp-unicode-data-20261027/crates/scriptw-aot-wasm/tests/structure_builtins/json_reviver_frame_structure.rs"]
mod json_reviver_frame_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-regexp-unicode-data-20261027/crates/scriptw-aot-wasm/tests/structure_builtins/json_stringify_replacer_invocation_authority_structure.rs"]
mod json_stringify_replacer_invocation_authority_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-regexp-unicode-data-20261027/crates/scriptw-aot-wasm/tests/structure_builtins/number_decimal_formatting_structure.rs"]
mod number_decimal_formatting_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-regexp-unicode-data-20261027/crates/scriptw-aot-wasm/tests/structure_builtins/number_to_string_shortest_integral_structure.rs"]
mod number_to_string_shortest_integral_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-regexp-unicode-data-20261027/crates/scriptw-aot-wasm/tests/structure_builtins/ordinary_to_primitive_receiver_kind_structure.rs"]
mod ordinary_to_primitive_receiver_kind_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-regexp-unicode-data-20261027/crates/scriptw-aot-wasm/tests/structure_builtins/pending_to_primitive_operation_identity_structure.rs"]
mod pending_to_primitive_operation_identity_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-regexp-unicode-data-20261027/crates/scriptw-aot-wasm/tests/structure_builtins/promise_combinator_mode_structure.rs"]
mod promise_combinator_mode_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-regexp-unicode-data-20261027/crates/scriptw-aot-wasm/tests/structure_builtins/promise_combinator_reaction_pair_ownership_structure.rs"]
mod promise_combinator_reaction_pair_ownership_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-regexp-unicode-data-20261027/crates/scriptw-aot-wasm/tests/structure_builtins/promise_finally_completion_structure.rs"]
mod promise_finally_completion_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-regexp-unicode-data-20261027/crates/scriptw-aot-wasm/tests/structure_builtins/promise_job_to_enqueue_structure.rs"]
mod promise_job_to_enqueue_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-regexp-unicode-data-20261027/crates/scriptw-aot-wasm/tests/structure_builtins/promise_keyed_element_projection_structure.rs"]
mod promise_keyed_element_projection_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-regexp-unicode-data-20261027/crates/scriptw-aot-wasm/tests/structure_builtins/promise_reaction_initialization_structure.rs"]
mod promise_reaction_initialization_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-regexp-unicode-data-20261027/crates/scriptw-aot-wasm/tests/structure_builtins/promise_reaction_list_domain_structure.rs"]
mod promise_reaction_list_domain_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-regexp-unicode-data-20261027/crates/scriptw-aot-wasm/tests/structure_builtins/proxy_define_property_handler_protocol_structure.rs"]
mod proxy_define_property_handler_protocol_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-regexp-unicode-data-20261027/crates/scriptw-aot-wasm/tests/structure_builtins/proxy_delete_traversal_structure.rs"]
mod proxy_delete_traversal_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-regexp-unicode-data-20261027/crates/scriptw-aot-wasm/tests/structure_builtins/proxy_get_trap_result_lifecycle_structure.rs"]
mod proxy_get_trap_result_lifecycle_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-regexp-unicode-data-20261027/crates/scriptw-aot-wasm/tests/structure_builtins/proxy_own_keys_handler_protocol_structure.rs"]
mod proxy_own_keys_handler_protocol_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-regexp-unicode-data-20261027/crates/scriptw-aot-wasm/tests/structure_builtins/proxy_prevent_extensions_request_structure.rs"]
mod proxy_prevent_extensions_request_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-regexp-unicode-data-20261027/crates/scriptw-aot-wasm/tests/structure_builtins/proxy_revocation_route_ownership_structure.rs"]
mod proxy_revocation_route_ownership_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-regexp-unicode-data-20261027/crates/scriptw-aot-wasm/tests/structure_builtins/proxy_set_prototype_of_handler_protocol_structure.rs"]
mod proxy_set_prototype_of_handler_protocol_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-regexp-unicode-data-20261027/crates/scriptw-aot-wasm/tests/structure_builtins/regexp_exec_result_mode_structure.rs"]
mod regexp_exec_result_mode_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-regexp-unicode-data-20261027/crates/scriptw-aot-wasm/tests/structure_builtins/regexp_flag_getter_structure.rs"]
mod regexp_flag_getter_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-regexp-unicode-data-20261027/crates/scriptw-aot-wasm/tests/structure_builtins/regexp_matcher_failure_route_structure.rs"]
mod regexp_matcher_failure_route_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-regexp-unicode-data-20261027/crates/scriptw-aot-wasm/tests/structure_builtins/regexp_matcher_result_domain_structure.rs"]
mod regexp_matcher_result_domain_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-regexp-unicode-data-20261027/crates/scriptw-aot-wasm/tests/structure_builtins/regexp_range_bound_domain_structure.rs"]
mod regexp_range_bound_domain_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-regexp-unicode-data-20261027/crates/scriptw-aot-wasm/tests/structure_builtins/regexp_substitution_kind_structure.rs"]
mod regexp_substitution_kind_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-regexp-unicode-data-20261027/crates/scriptw-aot-wasm/tests/structure_builtins/regexp_unicode_sets_class_strings_structure.rs"]
mod regexp_unicode_sets_class_strings_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-regexp-unicode-data-20261027/crates/scriptw-aot-wasm/tests/structure_builtins/regexp_unicode_string_property_domain_structure.rs"]
mod regexp_unicode_string_property_domain_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-regexp-unicode-data-20261027/crates/scriptw-aot-wasm/tests/structure_builtins/string_empty_split_unit_ownership_structure.rs"]
mod string_empty_split_unit_ownership_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-regexp-unicode-data-20261027/crates/scriptw-aot-wasm/tests/structure_builtins/string_exotic_property_key_structure.rs"]
mod string_exotic_property_key_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-regexp-unicode-data-20261027/crates/scriptw-aot-wasm/tests/structure_builtins/string_literal_replacement_scope_structure.rs"]
mod string_literal_replacement_scope_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-regexp-unicode-data-20261027/crates/scriptw-aot-wasm/tests/structure_builtins/string_repeat_count_structure.rs"]
mod string_repeat_count_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-regexp-unicode-data-20261027/crates/scriptw-aot-wasm/tests/structure_builtins/string_symbol_hook_operation_structure.rs"]
mod string_symbol_hook_operation_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-regexp-unicode-data-20261027/crates/scriptw-aot-wasm/tests/structure_builtins/string_well_formed_operation_structure.rs"]
mod string_well_formed_operation_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-regexp-unicode-data-20261027/crates/scriptw-aot-wasm/tests/structure_builtins/symbol_receiver_operation_domain_structure.rs"]
mod symbol_receiver_operation_domain_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-regexp-unicode-data-20261027/crates/scriptw-aot-wasm/tests/structure_builtins/to_locale_string_receiver_kind_structure.rs"]
mod to_locale_string_receiver_kind_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-regexp-unicode-data-20261027/crates/scriptw-aot-wasm/tests/structure_builtins/typed_array_constructor_identity_structure.rs"]
mod typed_array_constructor_identity_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-regexp-unicode-data-20261027/crates/scriptw-aot-wasm/tests/structure_builtins/typed_array_length_mode_wire_domain_structure.rs"]
mod typed_array_length_mode_wire_domain_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-regexp-unicode-data-20261027/crates/scriptw-aot-wasm/tests/structure_builtins/typed_array_with_witness_structure.rs"]
mod typed_array_with_witness_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-regexp-unicode-data-20261027/crates/scriptw-aot-wasm/tests/structure_builtins/typed_array_witness_use_ownership_structure.rs"]
mod typed_array_witness_use_ownership_structure;
