from datetime import datetime,timezone
import hashlib,json,os,subprocess,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'scripts'))
from limited_verification import require_kernel_budget,kernel_group
require_kernel_budget(4*1024**3);assert sorted(os.sched_getaffinity(0))==[0]
SOURCE='e7e51222101533e421ffae41bb0ccad78ba638ba'
old=json.loads((BASE/'verification-repaired.json').read_text());fixture=json.loads((BASE/'wire-data-fixture.json').read_text());repair=json.loads((BASE/'driver-repair.json').read_text())
assert old['source_commit']==fixture['source_commit']==repair['source_commit']==SOURCE
assert not old['complete'] and 'after' not in old
assert [c['label']for c in old['commands']]==['cheap-after-repair-driver','native-resume-driver','cargo-products','test262-driver']
assert [c['exit_code']for c in old['commands']]==[0,0,0,1]
def sha(p):
 with p.open('rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()
for c in old['commands']:
 for key in ('stdout','stderr'):assert sha(BASE/c[key])==c[key+'_sha256']
assert repair['executed_commands']==repair['executed_cases']==0
assert not (BASE/'conformance-guard-attempt/report.json').exists()
assert sha(BASE/repair['before_path'])==repair['before_sha256'] and sha(BASE/repair['path'])==repair['after_sha256'] and sha(BASE/repair['patch'])==repair['patch_sha256']
native=json.loads((BASE/'native-final/report.json').read_text());assert native['complete']and native['passed_disjoint_scopes']==4876 and len(native['scopes'])==19
products=[json.loads(line)for line in (BASE/'cargo-products.jsonl').read_text().splitlines()];assert products[-1]==dict(reason='build-finished',success=True)
producer,=[r for r in products if r.get('reason')=='compiler-artifact' and r.get('executable') and r['target']['name']=='scriptw' and r['target']['kind']==['bin']and not r['profile']['test']]
assert sha(Path(producer['executable']))==repair['guard_attempt_compiler_sha256']==sha(BASE/'conformance-guard-attempt/compiler')
os.environ['SCRIPTW_EXPECTED_SOURCE']=SOURCE;os.environ['SCRIPTW_REQUIRED_REPAIR_SOURCE']=old['required_repair_source']
group=kernel_group()
def budget():return {k:(group/k).read_text().strip()for k in ['memory.max','memory.swap.max','memory.oom.group','memory.peak','memory.events']}
def source():
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==SOURCE
 assert subprocess.check_output(['git','diff','--name-only','HEAD','--','crates','vendor','scripts','Cargo.toml','Cargo.lock'],cwd=ROOT,text=True).splitlines()==[fixture['path']]
 assert sha(ROOT/fixture['path'])==fixture['after_sha256']and sha(BASE/fixture['patch'])==fixture['patch_sha256']
 assert subprocess.check_output(['git','diff','--binary','HEAD','--',fixture['path']],cwd=ROOT)==(BASE/fixture['patch']).read_bytes()
source();assert not(BASE/'verification-final.json').exists()
report=dict(source_commit=SOURCE,required_repair_source=old['required_repair_source'],complete=False,started_at=datetime.now(timezone.utc).isoformat(),before=budget(),cpu_affinity=sorted(os.sched_getaffinity(0)),commands=[],test_fixture_patch=fixture,driver_repair=repair,retained_completed_scope='verification-repaired.json',retained_native_report='native-final/report.json',retained_product_compiler_sha256=repair['guard_attempt_compiler_sha256'],interpretation='Native4876, product build and guards completed before the private conformance clean-tree guard stopped without executing a command/case. Their original streams remain unchanged. Only original2365 plus disjoint supplementalUnicode execute in this fresh bounded scope. No stopped-scope after counters synthesized.')
def save():(BASE/'verification-final.json').write_text(json.dumps(report,indent=2)+'\n')
save()
for label,args in [('test262-final-driver',[sys.executable,'-B',str(BASE/'test262.py')]),('test262-unicode-final-driver',[sys.executable,'-B',str(BASE/'test262.py'),'--unicode'])]:
 source();out=BASE/(label+'.stdout');err=BASE/(label+'.stderr');row=dict(label=label,command=args,stdout=out.name,stderr=err.name);report['commands'].append(row);save();print(label,'started',flush=True);start=time.monotonic()
 with out.open('xb')as stdout,err.open('xb')as stderr:r=subprocess.run(args,cwd=ROOT,stdout=stdout,stderr=stderr,timeout=10800)
 row.update(exit_code=r.returncode,seconds=time.monotonic()-start,stdout_sha256=sha(out),stderr_sha256=sha(err));save();print(label,'finished',r.returncode,flush=True)
 if r.returncode:print(err.read_text()[-12000:],flush=True);raise SystemExit(r.returncode)
report.update(complete=True,finished_at=datetime.now(timezone.utc).isoformat(),after=budget());save();print('verification complete',flush=True)
