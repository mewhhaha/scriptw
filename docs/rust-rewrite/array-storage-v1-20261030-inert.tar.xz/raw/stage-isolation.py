"""Frozen-host ordinary diagnostics separate mixed construction from join cost."""
from pathlib import Path
import json
import statistics
import sys

BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(BASE))
import measure
from measure import ROOT, digest
OUT=BASE/'stage-isolation';OUT.mkdir()
measure.WORK=OUT
FIXTURES=OUT/'fixtures';FIXTURES.mkdir()
construction='var a=[];for(var i=0;i<1024;i++)a.push(i%4===0?null:i%4===1?undefined:i%4===2?"xy":"z");'
check='var checked=a.length+(a[0]===null?1:0)+(a[1]===undefined?2:0)+a[2].length+a[3].length;'
cases=[{'file':'mixed-construction.js','stdout':'1030\n','source':'(function workload(){'+construction+check+'print(checked);})();\n'},
       {'file':'mixed-joins-128.js','stdout':'230278\n','source':'(function workload(){'+construction+check+'for(var j=0;j<128;j++)checked+=a.join(",").length;print(checked);})();\n'}]
for case in cases:(FIXTURES/case['file']).write_text(case['source'])
(FIXTURES/'manifest.json').write_text(json.dumps({'schema':'scriptw-v8-workloads-v1','execution':[{k:c[k] for k in ('file','stdout')} for c in cases]},indent=2)+'\n')
ORDER=('baseline','candidate','candidate','baseline','candidate','baseline','baseline','candidate')
(OUT/'plan.json').write_text(json.dumps({'order':ORDER,'samples':21,'warmups':10,'scope':'Separate ordinary diagnostics, not original17 or scored cohorts. Same dense mixed construction and value/type checksum; join-dominated case adds128 joins. Compare whole lifetimes; do not subtract construction as an isolatedjoin score.','products':{p:json.loads((BASE/p/'products.json').read_text()) for p in ('baseline','candidate')}},indent=2)+'\n')
for r,label in enumerate(ORDER):
    artifacts=OUT/f'round-{r}-wasm';artifacts.mkdir()
    for case in cases:
        measure.invoke(f'round-{r}-{label}-{case["file"]}',[BASE/label/'runtime_baseline',FIXTURES,'21','10',case['file'],artifacts])
rows=[]
for case in cases:
    products={label:[] for label in ('baseline','candidate')}
    for r,label in enumerate(ORDER):
        stem=f'round-{r}-{label}-{case["file"]}'
        report=json.loads((OUT/(stem+'.stdout')).read_text())
        assert report['executable_sha256']==json.loads((BASE/label/'products.json').read_text())['runtime_baseline']['sha256']
        obs=report['cases'][0]['observations']
        assert len(obs)==31 and all(o['stdout']==case['stdout'] for o in obs)
        samples=[o['execution_ns'] for o in obs if not o['warmup']]
        assert len(samples)==21
        products[label].append({'round':r,'median_ns':statistics.median(samples),'samples_ns':samples,'raw':stem+'.stdout'})
    groups=[]
    for start,stop,order in [(0,4,'ABBA'),(4,8,'BAAB')]:
        med={label:statistics.median([n for p in ps if start<=p['round']<stop for n in p['samples_ns']]) for label,ps in products.items()}
        groups.append({'order':order,'median_ns':med,'change_percent':100*(med['candidate']/med['baseline']-1)})
    rows.append({'file':case['file'],'source_sha256':digest(FIXTURES/case['file']),'stdout':case['stdout'],'products':products,'balanced_orders':groups})
    print(case['file'],[g['change_percent'] for g in groups],flush=True)
(OUT/'analysis.json').write_text(json.dumps({'scope':'Whole ordinary lifetime stage diagnostics; not an isolated subtraction score or original17 result.','workloads':rows},indent=2)+'\n')
