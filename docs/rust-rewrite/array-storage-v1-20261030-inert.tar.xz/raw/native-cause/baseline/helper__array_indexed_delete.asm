
/workspace/scriptw/target/performance-dense-numbers-20261030/native-cause/baseline/runtime-portable.elf:     file format elf64-x86-64


Disassembly of section .text:

00000000029dfe40 <wasm[0]::function[1014]::helper::array_indexed_delete>:
 29dfe40:	push   %rbp
 29dfe41:	mov    %rsp,%rbp
 29dfe44:	mov    0x8(%rdi),%r10
 29dfe48:	mov    0x18(%r10),%r10
 29dfe4c:	add    $0xa0,%r10
 29dfe53:	cmp    %rsp,%r10
 29dfe56:	ja     29e0e6b <wasm[0]::function[1014]::helper::array_indexed_delete+0x102b>
 29dfe5c:	sub    $0x90,%rsp
 29dfe63:	mov    %rbx,0x60(%rsp)
 29dfe68:	mov    %r12,0x68(%rsp)
 29dfe6d:	mov    %r13,0x70(%rsp)
 29dfe72:	mov    %r14,0x78(%rsp)
 29dfe77:	mov    %r15,0x80(%rsp)
 29dfe7f:	mov    %rcx,%rbx
 29dfe82:	mov    %edx,(%rsp)
 29dfe85:	mov    0x18(%rdi),%rcx
 29dfe89:	mov    (%rcx),%rax
 29dfe8c:	mov    %rcx,0x50(%rsp)
 29dfe91:	mov    0x8(%rdi),%r12
 29dfe95:	mov    %rdi,0x30(%rsp)
 29dfe9a:	mov    0x8(%r12),%rcx
 29dfe9f:	cmp    %rcx,%rax
 29dfea2:	mov    %rcx,0x38(%rsp)
 29dfea7:	jae    29e0d83 <wasm[0]::function[1014]::helper::array_indexed_delete+0xf43>
 29dfead:	mov    %rbx,%rcx
 29dfeb0:	cmp    0x10a9(%rip),%rcx        # 29e0f60 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1120>
 29dfeb7:	jae    29e0e6d <wasm[0]::function[1014]::helper::array_indexed_delete+0x102d>
 29dfebd:	mov    (%rsp),%eax
 29dfec0:	test   %eax,%eax
 29dfec2:	je     29e0e6f <wasm[0]::function[1014]::helper::array_indexed_delete+0x102f>
 29dfec8:	test   %eax,%eax
 29dfeca:	je     29e0e71 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1031>
 29dfed0:	mov    0x28(%r12),%rdx
 29dfed5:	mov    0x20(%r12),%rsi
 29dfeda:	mov    %eax,%edi
 29dfedc:	xor    %rax,%rax
 29dfedf:	add    %rdi,%rsi
 29dfee2:	cmp    %rdx,%rdi
 29dfee5:	cmova  %rax,%rsi
 29dfee9:	mov    0x24(%rsi),%eax
 29dfeec:	cmp    $0x3,%eax
 29dfeef:	sete   %dl
 29dfef2:	cmp    $0x3,%eax
 29dfef5:	je     29e01c4 <wasm[0]::function[1014]::helper::array_indexed_delete+0x384>
 29dfefb:	mov    (%rsp),%eax
 29dfefe:	test   %eax,%eax
 29dff00:	je     29e0e73 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1033>
 29dff06:	test   %eax,%eax
 29dff08:	je     29e0e75 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1035>
 29dff0e:	mov    0x28(%r12),%rdx
 29dff13:	mov    0x20(%r12),%rdi
 29dff18:	mov    %eax,%esi
 29dff1a:	lea    (%rdi,%rsi,1),%rax
 29dff1e:	xor    %rdi,%rdi
 29dff21:	cmp    %rdx,%rsi
 29dff24:	cmova  %rdi,%rax
 29dff28:	mov    0x24(%rax),%eax
 29dff2b:	cmp    $0x2,%eax
 29dff2e:	sete   %dl
 29dff31:	mov    %rdx,0x48(%rsp)
 29dff36:	cmp    $0x2,%eax
 29dff39:	je     29dff49 <wasm[0]::function[1014]::helper::array_indexed_delete+0x109>
 29dff3f:	mov    0x48(%rsp),%rax
 29dff44:	jmp    29e01bc <wasm[0]::function[1014]::helper::array_indexed_delete+0x37c>
 29dff49:	mov    (%rsp),%esi
 29dff4c:	test   %esi,%esi
 29dff4e:	je     29e0e77 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1037>
 29dff54:	test   %esi,%esi
 29dff56:	je     29e0e79 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1039>
 29dff5c:	mov    0x28(%r12),%rax
 29dff61:	mov    0x20(%r12),%r9
 29dff66:	mov    %esi,%edx
 29dff68:	lea    (%r9,%rdx,1),%rdi
 29dff6c:	xor    %r10,%r10
 29dff6f:	cmp    %rax,%rdx
 29dff72:	cmova  %r10,%rdi
 29dff76:	mov    0x28(%rdi),%esi
 29dff79:	mov    0x2c(%rdi),%r8d
 29dff7d:	test   %esi,%esi
 29dff7f:	je     29e0e7b <wasm[0]::function[1014]::helper::array_indexed_delete+0x103b>
 29dff85:	test   %esi,%esi
 29dff87:	je     29e0e7d <wasm[0]::function[1014]::helper::array_indexed_delete+0x103d>
 29dff8d:	mov    %esi,%edi
 29dff8f:	lea    0x10(%r9,%rdi,1),%rdx
 29dff94:	cmp    %rax,%rdi
 29dff97:	cmova  %r10,%rdx
 29dff9b:	mov    (%rdx),%eax
 29dff9d:	cmp    %rax,%rcx
 29dffa0:	jae    29e01b7 <wasm[0]::function[1014]::helper::array_indexed_delete+0x377>
 29dffa6:	test   %r8d,%r8d
 29dffa9:	je     29e0e7f <wasm[0]::function[1014]::helper::array_indexed_delete+0x103f>
 29dffaf:	test   %r8d,%r8d
 29dffb2:	je     29e0e81 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1041>
 29dffb8:	mov    0x28(%r12),%rax
 29dffbd:	mov    0x20(%r12),%r9
 29dffc2:	mov    %r8d,%r13d
 29dffc5:	lea    0x10(%r9,%r13,1),%r11
 29dffca:	xor    %r10,%r10
 29dffcd:	cmp    %rax,%r13
 29dffd0:	cmova  %r10,%r11
 29dffd4:	mov    (%r11),%r11d
 29dffd7:	mov    %rcx,%r15
 29dffda:	shr    $0x6,%r15d
 29dffde:	cmp    %r11d,%r15d
 29dffe1:	jae    29e0e83 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1043>
 29dffe7:	mov    %r11d,%edx
 29dffea:	shl    $0x3,%rdx
 29dffee:	shr    $0x20,%rdx
 29dfff2:	test   %rdx,%rdx
 29dfff5:	jne    29e0e85 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1045>
 29dfffb:	shl    $0x3,%r11d
 29dffff:	add    $0x18,%r11d
 29e0003:	jb     29e0e87 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1047>
 29e0009:	mov    %r8,%rdx
 29e000c:	add    %r11d,%edx
 29e000f:	jb     29e0e89 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1049>
 29e0015:	mov    %edx,%edx
 29e0017:	add    %rdx,%r9
 29e001a:	cmp    %rax,%rdx
 29e001d:	cmova  %r10,%r9
 29e0021:	mov    %r15,%r14
 29e0024:	shl    $0x3,%r14d
 29e0028:	lea    0x18(%r14),%r10d
 29e002c:	sub    %r10d,%r11d
 29e002f:	sub    %r11,%r9
 29e0032:	mov    (%r9),%rbx
 29e0035:	mov    $0x1,%eax
 29e003a:	shl    %cl,%rax
 29e003d:	bt     %rcx,%rbx
 29e0041:	jae    29e01b7 <wasm[0]::function[1014]::helper::array_indexed_delete+0x377>
 29e0047:	mov    0x28(%r12),%r10
 29e004c:	mov    0x20(%r12),%r9
 29e0051:	lea    0x10(%r9,%r13,1),%rdx
 29e0056:	xor    %r11,%r11
 29e0059:	cmp    %r10,%r13
 29e005c:	cmova  %r11,%rdx
 29e0060:	mov    (%rdx),%r13d
 29e0063:	cmp    %r13d,%r15d
 29e0066:	jae    29e0e8b <wasm[0]::function[1014]::helper::array_indexed_delete+0x104b>
 29e006c:	mov    %r13d,%edx
 29e006f:	shl    $0x3,%rdx
 29e0073:	shr    $0x20,%rdx
 29e0077:	test   %rdx,%rdx
 29e007a:	jne    29e0e8d <wasm[0]::function[1014]::helper::array_indexed_delete+0x104d>
 29e0080:	shl    $0x3,%r13d
 29e0084:	add    $0x18,%r13d
 29e0088:	jb     29e0e8f <wasm[0]::function[1014]::helper::array_indexed_delete+0x104f>
 29e008e:	add    %r13d,%r8d
 29e0091:	jb     29e0e91 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1051>
 29e0097:	not    %rax
 29e009a:	and    %rax,%rbx
 29e009d:	mov    %r8d,%edx
 29e00a0:	lea    (%r9,%rdx,1),%rax
 29e00a4:	cmp    %r10,%rdx
 29e00a7:	cmova  %r11,%rax
 29e00ab:	lea    0x18(%r14),%edx
 29e00af:	sub    %edx,%r13d
 29e00b2:	sub    %r13,%rax
 29e00b5:	mov    %rbx,(%rax)
 29e00b8:	lea    0x10(%r9,%rdi,1),%rax
 29e00bd:	cmp    %r10,%rdi
 29e00c0:	cmova  %r11,%rax
 29e00c4:	mov    (%rax),%r8d
 29e00c7:	cmp    %r8d,%ecx
 29e00ca:	jae    29e0e93 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1053>
 29e00d0:	mov    %r8d,%eax
 29e00d3:	shl    $0x3,%rax
 29e00d7:	shr    $0x20,%rax
 29e00db:	test   %rax,%rax
 29e00de:	jne    29e0e95 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1055>
 29e00e4:	shl    $0x3,%r8d
 29e00e8:	add    $0x18,%r8d
 29e00ec:	jb     29e0e97 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1057>
 29e00f2:	add    %r8d,%esi
 29e00f5:	jb     29e0e99 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1059>
 29e00fb:	mov    %esi,%edx
 29e00fd:	lea    (%r9,%rdx,1),%rax
 29e0101:	cmp    %r10,%rdx
 29e0104:	cmova  %r11,%rax
 29e0108:	mov    %rcx,%rdx
 29e010b:	shl    $0x3,%edx
 29e010e:	add    $0x18,%edx
 29e0114:	sub    %edx,%r8d
 29e0117:	sub    %r8,%rax
 29e011a:	movq   $0x0,(%rax)
 29e0121:	mov    (%rsp),%eax
 29e0124:	test   %eax,%eax
 29e0126:	je     29e0e9b <wasm[0]::function[1014]::helper::array_indexed_delete+0x105b>
 29e012c:	test   %eax,%eax
 29e012e:	je     29e0e9d <wasm[0]::function[1014]::helper::array_indexed_delete+0x105d>
 29e0134:	mov    %eax,%edx
 29e0136:	lea    (%r9,%rdx,1),%rax
 29e013a:	cmp    %r10,%rdx
 29e013d:	cmova  %r11,%rax
 29e0141:	mov    0x18(%rax),%rdx
 29e0145:	mov    %rdx,%rsi
 29e0148:	sub    $0x1,%rsi
 29e014c:	mov    %rsi,0x18(%rax)
 29e0150:	cmp    $0x1,%rdx
 29e0154:	jne    29e01b7 <wasm[0]::function[1014]::helper::array_indexed_delete+0x377>
 29e015a:	mov    0x30(%rsp),%r15
 29e015f:	mov    0xa00(%r15),%esi
 29e0166:	mov    0xa10(%r15),%eax
 29e016d:	mov    (%rsp),%edi
 29e0170:	test   %edi,%edi
 29e0172:	je     29e0e9f <wasm[0]::function[1014]::helper::array_indexed_delete+0x105f>
 29e0178:	test   %esi,%esi
 29e017a:	je     29e0ea1 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1061>
 29e0180:	test   %edi,%edi
 29e0182:	je     29e0ea3 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1063>
 29e0188:	mov    0x28(%r12),%r8
 29e018d:	mov    0x20(%r12),%r9
 29e0192:	mov    %edi,%edx
 29e0194:	lea    (%r9,%rdx,1),%rdi
 29e0198:	xor    %r9,%r9
 29e019b:	cmp    %r8,%rdx
 29e019e:	cmova  %r9,%rdi
 29e01a2:	mov    %esi,0x28(%rdi)
 29e01a5:	test   %eax,%eax
 29e01a7:	je     29e0ea5 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1065>
 29e01ad:	mov    %eax,0x2c(%rdi)
 29e01b0:	movl   $0x0,0x30(%rdi)
 29e01b7:	mov    0x48(%rsp),%rax
 29e01bc:	movzbl %al,%eax
 29e01bf:	jmp    29e03a5 <wasm[0]::function[1014]::helper::array_indexed_delete+0x565>
 29e01c4:	mov    (%rsp),%esi
 29e01c7:	test   %esi,%esi
 29e01c9:	je     29e0ea7 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1067>
 29e01cf:	test   %esi,%esi
 29e01d1:	je     29e0ea9 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1069>
 29e01d7:	mov    0x28(%r12),%rax
 29e01dc:	mov    0x20(%r12),%r8
 29e01e1:	mov    %esi,%edi
 29e01e3:	lea    (%r8,%rdi,1),%rsi
 29e01e7:	xor    %r9,%r9
 29e01ea:	cmp    %rax,%rdi
 29e01ed:	cmova  %r9,%rsi
 29e01f1:	mov    0x30(%rsi),%esi
 29e01f4:	test   %esi,%esi
 29e01f6:	je     29e0eab <wasm[0]::function[1014]::helper::array_indexed_delete+0x106b>
 29e01fc:	test   %esi,%esi
 29e01fe:	je     29e0ead <wasm[0]::function[1014]::helper::array_indexed_delete+0x106d>
 29e0204:	mov    %esi,%edi
 29e0206:	lea    0x10(%r8,%rdi,1),%r8
 29e020b:	cmp    %rax,%rdi
 29e020e:	cmova  %r9,%r8
 29e0212:	mov    (%r8),%r8d
 29e0215:	cmp    %r8,%rcx
 29e0218:	jae    29e03a2 <wasm[0]::function[1014]::helper::array_indexed_delete+0x562>
 29e021e:	mov    0x28(%r12),%r8
 29e0223:	mov    0x20(%r12),%r11
 29e0228:	lea    0x10(%r11,%rdi,1),%r10
 29e022d:	xor    %r9,%r9
 29e0230:	cmp    %r8,%rdi
 29e0233:	cmova  %r9,%r10
 29e0237:	mov    (%r10),%r10d
 29e023a:	cmp    %r10d,%ecx
 29e023d:	jae    29e0eaf <wasm[0]::function[1014]::helper::array_indexed_delete+0x106f>
 29e0243:	mov    %r10d,%eax
 29e0246:	shl    $0x2,%rax
 29e024a:	shr    $0x20,%rax
 29e024e:	test   %rax,%rax
 29e0251:	jne    29e0eb1 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1071>
 29e0257:	shl    $0x2,%r10d
 29e025b:	add    $0x14,%r10d
 29e025f:	jb     29e0eb3 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1073>
 29e0265:	mov    %rsi,%rax
 29e0268:	add    %r10d,%eax
 29e026b:	jb     29e0eb5 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1075>
 29e0271:	mov    %eax,%eax
 29e0273:	add    %rax,%r11
 29e0276:	cmp    %r8,%rax
 29e0279:	cmova  %r9,%r11
 29e027d:	mov    %rcx,%rax
 29e0280:	shl    $0x2,%eax
 29e0283:	lea    0x14(%rax),%r8d
 29e0287:	sub    %r8d,%r10d
 29e028a:	sub    %r10,%r11
 29e028d:	mov    (%r11),%r8d
 29e0290:	test   %r8d,%r8d
 29e0293:	je     29e03a2 <wasm[0]::function[1014]::helper::array_indexed_delete+0x562>
 29e0299:	mov    0x28(%r12),%r8
 29e029e:	mov    0x20(%r12),%r10
 29e02a3:	lea    0x10(%r10,%rdi,1),%r11
 29e02a8:	xor    %r9,%r9
 29e02ab:	cmp    %r8,%rdi
 29e02ae:	cmova  %r9,%r11
 29e02b2:	mov    (%r11),%edi
 29e02b5:	cmp    %edi,%ecx
 29e02b7:	jae    29e0eb7 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1077>
 29e02bd:	mov    %edi,%r11d
 29e02c0:	shl    $0x2,%r11
 29e02c4:	shr    $0x20,%r11
 29e02c8:	test   %r11,%r11
 29e02cb:	jne    29e0eb9 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1079>
 29e02d1:	shl    $0x2,%edi
 29e02d4:	add    $0x14,%edi
 29e02d7:	jb     29e0ebb <wasm[0]::function[1014]::helper::array_indexed_delete+0x107b>
 29e02dd:	add    %edi,%esi
 29e02df:	jb     29e0ebd <wasm[0]::function[1014]::helper::array_indexed_delete+0x107d>
 29e02e5:	mov    %esi,%r11d
 29e02e8:	lea    (%r10,%r11,1),%rsi
 29e02ec:	cmp    %r8,%r11
 29e02ef:	cmova  %r9,%rsi
 29e02f3:	add    $0x14,%eax
 29e02f9:	sub    %eax,%edi
 29e02fb:	sub    %rdi,%rsi
 29e02fe:	movl   $0x0,(%rsi)
 29e0304:	mov    (%rsp),%eax
 29e0307:	test   %eax,%eax
 29e0309:	je     29e0ebf <wasm[0]::function[1014]::helper::array_indexed_delete+0x107f>
 29e030f:	test   %eax,%eax
 29e0311:	je     29e0ec1 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1081>
 29e0317:	mov    %eax,%esi
 29e0319:	lea    (%r10,%rsi,1),%rax
 29e031d:	cmp    %r8,%rsi
 29e0320:	cmova  %r9,%rax
 29e0324:	mov    0x18(%rax),%rsi
 29e0328:	mov    %rsi,%rdi
 29e032b:	sub    $0x1,%rdi
 29e032f:	mov    %rdi,0x18(%rax)
 29e0333:	cmp    $0x1,%rsi
 29e0337:	jne    29e03a2 <wasm[0]::function[1014]::helper::array_indexed_delete+0x562>
 29e033d:	mov    0x30(%rsp),%r15
 29e0342:	mov    0xa00(%r15),%esi
 29e0349:	mov    0xa10(%r15),%eax
 29e0350:	mov    (%rsp),%edi
 29e0353:	test   %edi,%edi
 29e0355:	je     29e0ec3 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1083>
 29e035b:	test   %esi,%esi
 29e035d:	je     29e0ec5 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1085>
 29e0363:	test   %edi,%edi
 29e0365:	je     29e0ec7 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1087>
 29e036b:	mov    0x28(%r12),%r8
 29e0370:	mov    0x20(%r12),%r10
 29e0375:	mov    %edi,%r9d
 29e0378:	lea    (%r10,%r9,1),%rdi
 29e037c:	xor    %r10,%r10
 29e037f:	cmp    %r8,%r9
 29e0382:	cmova  %r10,%rdi
 29e0386:	mov    %esi,0x28(%rdi)
 29e0389:	test   %eax,%eax
 29e038b:	je     29e0ec9 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1089>
 29e0391:	mov    %eax,0x2c(%rdi)
 29e0394:	movl   $0x0,0x30(%rdi)
 29e039b:	movl   $0x2,0x24(%rdi)
 29e03a2:	movzbl %dl,%eax
 29e03a5:	test   %eax,%eax
 29e03a7:	jne    29e05ac <wasm[0]::function[1014]::helper::array_indexed_delete+0x76c>
 29e03ad:	mov    (%rsp),%eax
 29e03b0:	test   %eax,%eax
 29e03b2:	je     29e0ecb <wasm[0]::function[1014]::helper::array_indexed_delete+0x108b>
 29e03b8:	test   %eax,%eax
 29e03ba:	je     29e0ecd <wasm[0]::function[1014]::helper::array_indexed_delete+0x108d>
 29e03c0:	mov    0x28(%r12),%rdx
 29e03c5:	mov    0x20(%r12),%rdi
 29e03ca:	mov    %eax,%esi
 29e03cc:	lea    (%rdi,%rsi,1),%rax
 29e03d0:	xor    %rdi,%rdi
 29e03d3:	cmp    %rdx,%rsi
 29e03d6:	cmova  %rdi,%rax
 29e03da:	mov    0x24(%rax),%eax
 29e03dd:	test   %eax,%eax
 29e03df:	sete   %dl
 29e03e2:	test   %eax,%eax
 29e03e4:	jne    29e05a9 <wasm[0]::function[1014]::helper::array_indexed_delete+0x769>
 29e03ea:	mov    (%rsp),%eax
 29e03ed:	test   %eax,%eax
 29e03ef:	je     29e0ecf <wasm[0]::function[1014]::helper::array_indexed_delete+0x108f>
 29e03f5:	test   %eax,%eax
 29e03f7:	je     29e0ed1 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1091>
 29e03fd:	mov    0x28(%r12),%rdi
 29e0402:	mov    0x20(%r12),%r9
 29e0407:	mov    %eax,%esi
 29e0409:	lea    (%r9,%rsi,1),%rax
 29e040d:	xor    %r10,%r10
 29e0410:	cmp    %rdi,%rsi
 29e0413:	cmova  %r10,%rax
 29e0417:	mov    0x20(%rax),%esi
 29e041a:	test   %esi,%esi
 29e041c:	je     29e0ed3 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1093>
 29e0422:	test   %esi,%esi
 29e0424:	je     29e0ed5 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1095>
 29e042a:	mov    %esi,%r8d
 29e042d:	lea    0x10(%r9,%r8,1),%r9
 29e0432:	cmp    %rdi,%r8
 29e0435:	cmova  %r10,%r9
 29e0439:	mov    (%r9),%r9d
 29e043c:	cmp    %r9,%rcx
 29e043f:	jae    29e05a9 <wasm[0]::function[1014]::helper::array_indexed_delete+0x769>
 29e0445:	mov    0x28(%r12),%rax
 29e044a:	mov    0x20(%r12),%r10
 29e044f:	lea    0x10(%r10,%r8,1),%r9
 29e0454:	xor    %rdi,%rdi
 29e0457:	cmp    %rax,%r8
 29e045a:	cmova  %rdi,%r9
 29e045e:	mov    (%r9),%r9d
 29e0461:	cmp    %r9d,%ecx
 29e0464:	jae    29e0ed7 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1097>
 29e046a:	mov    %r9d,%r11d
 29e046d:	shl    $0x2,%r11
 29e0471:	shr    $0x20,%r11
 29e0475:	test   %r11,%r11
 29e0478:	jne    29e0ed9 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1099>
 29e047e:	shl    $0x2,%r9d
 29e0482:	add    $0x14,%r9d
 29e0486:	jb     29e0edb <wasm[0]::function[1014]::helper::array_indexed_delete+0x109b>
 29e048c:	mov    %rsi,%r11
 29e048f:	add    %r9d,%r11d
 29e0492:	jb     29e0edd <wasm[0]::function[1014]::helper::array_indexed_delete+0x109d>
 29e0498:	mov    %r11d,%r11d
 29e049b:	add    %r11,%r10
 29e049e:	cmp    %rax,%r11
 29e04a1:	cmova  %rdi,%r10
 29e04a5:	mov    %rcx,%rax
 29e04a8:	shl    $0x2,%eax
 29e04ab:	add    $0x14,%eax
 29e04b1:	sub    %eax,%r9d
 29e04b4:	sub    %r9,%r10
 29e04b7:	mov    (%r10),%edi
 29e04ba:	test   %edi,%edi
 29e04bc:	je     29e05a9 <wasm[0]::function[1014]::helper::array_indexed_delete+0x769>
 29e04c2:	mov    0x28(%r12),%rdi
 29e04c7:	mov    0x20(%r12),%r10
 29e04cc:	lea    0x10(%r10,%r8,1),%r11
 29e04d1:	xor    %r9,%r9
 29e04d4:	cmp    %rdi,%r8
 29e04d7:	cmova  %r9,%r11
 29e04db:	mov    (%r11),%r8d
 29e04de:	cmp    %r8d,%ecx
 29e04e1:	jae    29e0edf <wasm[0]::function[1014]::helper::array_indexed_delete+0x109f>
 29e04e7:	mov    %r8d,%r11d
 29e04ea:	shl    $0x2,%r11
 29e04ee:	shr    $0x20,%r11
 29e04f2:	test   %r11,%r11
 29e04f5:	jne    29e0ee1 <wasm[0]::function[1014]::helper::array_indexed_delete+0x10a1>
 29e04fb:	shl    $0x2,%r8d
 29e04ff:	add    $0x14,%r8d
 29e0503:	jb     29e0ee3 <wasm[0]::function[1014]::helper::array_indexed_delete+0x10a3>
 29e0509:	add    %r8d,%esi
 29e050c:	jb     29e0ee5 <wasm[0]::function[1014]::helper::array_indexed_delete+0x10a5>
 29e0512:	mov    %esi,%r11d
 29e0515:	lea    (%r10,%r11,1),%rsi
 29e0519:	cmp    %rdi,%r11
 29e051c:	cmova  %r9,%rsi
 29e0520:	sub    %eax,%r8d
 29e0523:	sub    %r8,%rsi
 29e0526:	movl   $0x0,(%rsi)
 29e052c:	mov    (%rsp),%eax
 29e052f:	test   %eax,%eax
 29e0531:	je     29e0ee7 <wasm[0]::function[1014]::helper::array_indexed_delete+0x10a7>
 29e0537:	test   %eax,%eax
 29e0539:	je     29e0ee9 <wasm[0]::function[1014]::helper::array_indexed_delete+0x10a9>
 29e053f:	mov    %eax,%esi
 29e0541:	lea    (%r10,%rsi,1),%rax
 29e0545:	cmp    %rdi,%rsi
 29e0548:	cmova  %r9,%rax
 29e054c:	mov    0x18(%rax),%rsi
 29e0550:	mov    %rsi,%rdi
 29e0553:	sub    $0x1,%rdi
 29e0557:	mov    %rdi,0x18(%rax)
 29e055b:	cmp    $0x1,%rsi
 29e055f:	jne    29e05a9 <wasm[0]::function[1014]::helper::array_indexed_delete+0x769>
 29e0565:	mov    0x30(%rsp),%r15
 29e056a:	mov    0x9f0(%r15),%eax
 29e0571:	mov    (%rsp),%esi
 29e0574:	test   %esi,%esi
 29e0576:	je     29e0eeb <wasm[0]::function[1014]::helper::array_indexed_delete+0x10ab>
 29e057c:	test   %eax,%eax
 29e057e:	je     29e0eed <wasm[0]::function[1014]::helper::array_indexed_delete+0x10ad>
 29e0584:	test   %esi,%esi
 29e0586:	je     29e0eef <wasm[0]::function[1014]::helper::array_indexed_delete+0x10af>
 29e058c:	mov    0x28(%r12),%rdi
 29e0591:	mov    %esi,%r8d
 29e0594:	mov    %r8,%rsi
 29e0597:	add    0x20(%r12),%rsi
 29e059c:	xor    %r9,%r9
 29e059f:	cmp    %rdi,%r8
 29e05a2:	cmova  %r9,%rsi
 29e05a6:	mov    %eax,0x20(%rsi)
 29e05a9:	movzbl %dl,%eax
 29e05ac:	test   %eax,%eax
 29e05ae:	jne    29e0d5b <wasm[0]::function[1014]::helper::array_indexed_delete+0xf1b>
 29e05b4:	mov    (%rsp),%esi
 29e05b7:	test   %esi,%esi
 29e05b9:	je     29e0ef1 <wasm[0]::function[1014]::helper::array_indexed_delete+0x10b1>
 29e05bf:	test   %esi,%esi
 29e05c1:	je     29e0ef3 <wasm[0]::function[1014]::helper::array_indexed_delete+0x10b3>
 29e05c7:	mov    0x28(%r12),%rax
 29e05cc:	mov    0x20(%r12),%rdx
 29e05d1:	mov    %esi,%r8d
 29e05d4:	lea    (%rdx,%r8,1),%rdi
 29e05d8:	xor    %rsi,%rsi
 29e05db:	cmp    %rax,%r8
 29e05de:	cmova  %rsi,%rdi
 29e05e2:	mov    0x10(%rdi),%edi
 29e05e5:	mov    %edi,0x20(%rsp)
 29e05e9:	test   %edi,%edi
 29e05eb:	je     29e0ef5 <wasm[0]::function[1014]::helper::array_indexed_delete+0x10b5>
 29e05f1:	test   %edi,%edi
 29e05f3:	je     29e0ef7 <wasm[0]::function[1014]::helper::array_indexed_delete+0x10b7>
 29e05f9:	mov    %edi,%r8d
 29e05fc:	lea    0x10(%rdx,%r8,1),%rdi
 29e0601:	cmp    %rax,%r8
 29e0604:	cmova  %rsi,%rdi
 29e0608:	mov    (%rdi),%eax
 29e060a:	mov    %rax,%r10
 29e060d:	test   %r10d,%r10d
 29e0610:	mov    %r10,0x40(%rsp)
 29e0615:	je     29e0d5b <wasm[0]::function[1014]::helper::array_indexed_delete+0xf1b>
 29e061b:	mov    0x20(%rsp),%esi
 29e061f:	xor    %edx,%edx
 29e0621:	test   %esi,%esi
 29e0623:	je     29e0ef9 <wasm[0]::function[1014]::helper::array_indexed_delete+0x10b9>
 29e0629:	test   %esi,%esi
 29e062b:	je     29e0efb <wasm[0]::function[1014]::helper::array_indexed_delete+0x10bb>
 29e0631:	mov    0x28(%r12),%rdi
 29e0636:	mov    0x20(%r12),%rax
 29e063b:	mov    %esi,%r10d
 29e063e:	lea    0x10(%rax,%r10,1),%r9
 29e0643:	xor    %r8,%r8
 29e0646:	cmp    %rdi,%r10
 29e0649:	cmova  %r8,%r9
 29e064d:	mov    (%r9),%r9d
 29e0650:	mov    %rcx,%r10
 29e0653:	shr    $0x10,%r10d
 29e0657:	mov    %rcx,%r11
 29e065a:	xor    %r10d,%r11d
 29e065d:	mov    %rcx,%rbx
 29e0660:	imul   $0x7feb352d,%r11d,%r11d
 29e0667:	mov    %r11,%rcx
 29e066a:	shr    $0xf,%ecx
 29e066d:	xor    %ecx,%r11d
 29e0670:	imul   $0x846ca68b,%r11d,%r14d
 29e0677:	mov    %r14,%rcx
 29e067a:	shr    $0x10,%ecx
 29e067d:	xor    %ecx,%r14d
 29e0680:	mov    0x40(%rsp),%rcx
 29e0685:	sub    $0x1,%ecx
 29e0688:	and    %ecx,%r14d
 29e068b:	cmp    %r9d,%r14d
 29e068e:	jae    29e0efd <wasm[0]::function[1014]::helper::array_indexed_delete+0x10bd>
 29e0694:	mov    %r9d,%ecx
 29e0697:	shl    $0x2,%rcx
 29e069b:	shr    $0x20,%rcx
 29e069f:	test   %rcx,%rcx
 29e06a2:	jne    29e0eff <wasm[0]::function[1014]::helper::array_indexed_delete+0x10bf>
 29e06a8:	shl    $0x2,%r9d
 29e06ac:	add    $0x14,%r9d
 29e06b0:	jb     29e0f01 <wasm[0]::function[1014]::helper::array_indexed_delete+0x10c1>
 29e06b6:	add    %r9d,%esi
 29e06b9:	jb     29e0f03 <wasm[0]::function[1014]::helper::array_indexed_delete+0x10c3>
 29e06bf:	mov    %esi,%ecx
 29e06c1:	add    %rcx,%rax
 29e06c4:	cmp    %rdi,%rcx
 29e06c7:	cmova  %r8,%rax
 29e06cb:	mov    %r14,%r15
 29e06ce:	shl    $0x2,%r15d
 29e06d2:	lea    0x14(%r15),%ecx
 29e06d6:	sub    %ecx,%r9d
 29e06d9:	sub    %r9,%rax
 29e06dc:	mov    (%rax),%esi
 29e06de:	mov    %esi,0x10(%rsp)
 29e06e2:	mov    %edx,0x8(%rsp)
 29e06e6:	mov    0x50(%rsp),%rcx
 29e06eb:	mov    (%rcx),%rax
 29e06ee:	mov    0x38(%rsp),%rcx
 29e06f3:	cmp    %rcx,%rax
 29e06f6:	jae    29e0d9a <wasm[0]::function[1014]::helper::array_indexed_delete+0xf5a>
 29e06fc:	mov    0x10(%rsp),%eax
 29e0700:	test   %eax,%eax
 29e0702:	je     29e0d5b <wasm[0]::function[1014]::helper::array_indexed_delete+0xf1b>
 29e0708:	mov    0x10(%rsp),%ecx
 29e070c:	test   %ecx,%ecx
 29e070e:	je     29e0f05 <wasm[0]::function[1014]::helper::array_indexed_delete+0x10c5>
 29e0714:	mov    0x28(%r12),%rax
 29e0719:	mov    %ecx,%edx
 29e071b:	mov    %rdx,%rcx
 29e071e:	add    0x20(%r12),%rcx
 29e0723:	xor    %rsi,%rsi
 29e0726:	cmp    %rax,%rdx
 29e0729:	cmova  %rsi,%rcx
 29e072d:	mov    0x10(%rcx),%rax
 29e0731:	mov    %rbx,%rcx
 29e0734:	cmp    %rcx,%rax
 29e0737:	je     29e076d <wasm[0]::function[1014]::helper::array_indexed_delete+0x92d>
 29e073d:	mov    0x10(%rsp),%edx
 29e0741:	test   %edx,%edx
 29e0743:	je     29e0f07 <wasm[0]::function[1014]::helper::array_indexed_delete+0x10c7>
 29e0749:	mov    0x28(%r12),%rax
 29e074e:	mov    %edx,%edi
 29e0750:	mov    %rdi,%rsi
 29e0753:	add    0x20(%r12),%rsi
 29e0758:	xor    %r8,%r8
 29e075b:	cmp    %rax,%rdi
 29e075e:	cmova  %r8,%rsi
 29e0762:	mov    0x1c(%rsi),%esi
 29e0765:	mov    %rcx,%rbx
 29e0768:	jmp    29e06de <wasm[0]::function[1014]::helper::array_indexed_delete+0x89e>
 29e076d:	mov    0x10(%rsp),%ecx
 29e0771:	test   %ecx,%ecx
 29e0773:	je     29e0f09 <wasm[0]::function[1014]::helper::array_indexed_delete+0x10c9>
 29e0779:	mov    0x28(%r12),%rax
 29e077e:	mov    0x20(%r12),%rsi
 29e0783:	mov    %ecx,%edx
 29e0785:	lea    (%rsi,%rdx,1),%rcx
 29e0789:	xor    %rsi,%rsi
 29e078c:	cmp    %rax,%rdx
 29e078f:	cmova  %rsi,%rcx
 29e0793:	mov    0x1c(%rcx),%ecx
 29e0796:	mov    0x8(%rsp),%eax
 29e079a:	test   %eax,%eax
 29e079c:	je     29e07cf <wasm[0]::function[1014]::helper::array_indexed_delete+0x98f>
 29e07a2:	mov    0x8(%rsp),%edx
 29e07a6:	test   %edx,%edx
 29e07a8:	je     29e0f0b <wasm[0]::function[1014]::helper::array_indexed_delete+0x10cb>
 29e07ae:	mov    0x28(%r12),%rax
 29e07b3:	mov    %edx,%esi
 29e07b5:	mov    %rsi,%rdx
 29e07b8:	add    0x20(%r12),%rdx
 29e07bd:	xor    %rdi,%rdi
 29e07c0:	cmp    %rax,%rsi
 29e07c3:	cmova  %rdi,%rdx
 29e07c7:	mov    %ecx,0x1c(%rdx)
 29e07ca:	jmp    29e0850 <wasm[0]::function[1014]::helper::array_indexed_delete+0xa10>
 29e07cf:	mov    0x20(%rsp),%eax
 29e07d3:	test   %eax,%eax
 29e07d5:	je     29e0f0d <wasm[0]::function[1014]::helper::array_indexed_delete+0x10cd>
 29e07db:	test   %eax,%eax
 29e07dd:	je     29e0f0f <wasm[0]::function[1014]::helper::array_indexed_delete+0x10cf>
 29e07e3:	mov    0x28(%r12),%rdx
 29e07e8:	mov    0x20(%r12),%rsi
 29e07ed:	mov    %eax,%r9d
 29e07f0:	lea    0x10(%rsi,%r9,1),%r8
 29e07f5:	xor    %rdi,%rdi
 29e07f8:	cmp    %rdx,%r9
 29e07fb:	cmova  %rdi,%r8
 29e07ff:	mov    (%r8),%r8d
 29e0802:	cmp    %r8d,%r14d
 29e0805:	jae    29e0f11 <wasm[0]::function[1014]::helper::array_indexed_delete+0x10d1>
 29e080b:	mov    %r8d,%r9d
 29e080e:	shl    $0x2,%r9
 29e0812:	shr    $0x20,%r9
 29e0816:	test   %r9,%r9
 29e0819:	jne    29e0f13 <wasm[0]::function[1014]::helper::array_indexed_delete+0x10d3>
 29e081f:	shl    $0x2,%r8d
 29e0823:	add    $0x14,%r8d
 29e0827:	jb     29e0f15 <wasm[0]::function[1014]::helper::array_indexed_delete+0x10d5>
 29e082d:	add    %r8d,%eax
 29e0830:	jb     29e0f17 <wasm[0]::function[1014]::helper::array_indexed_delete+0x10d7>
 29e0836:	mov    %eax,%r9d
 29e0839:	lea    (%rsi,%r9,1),%rax
 29e083d:	cmp    %rdx,%r9
 29e0840:	cmova  %rdi,%rax
 29e0844:	lea    0x14(%r15),%edx
 29e0848:	sub    %edx,%r8d
 29e084b:	sub    %r8,%rax
 29e084e:	mov    %ecx,(%rax)
 29e0850:	mov    (%rsp),%esi
 29e0853:	test   %esi,%esi
 29e0855:	je     29e0f19 <wasm[0]::function[1014]::helper::array_indexed_delete+0x10d9>
 29e085b:	test   %esi,%esi
 29e085d:	je     29e0f1b <wasm[0]::function[1014]::helper::array_indexed_delete+0x10db>
 29e0863:	mov    0x28(%r12),%r8
 29e0868:	mov    0x20(%r12),%rdi
 29e086d:	mov    %esi,%r9d
 29e0870:	add    %r9,%rdi
 29e0873:	xor    %r10,%r10
 29e0876:	cmp    %r8,%r9
 29e0879:	cmova  %r10,%rdi
 29e087d:	mov    0x18(%rdi),%rsi
 29e0881:	mov    %rsi,%r8
 29e0884:	sub    $0x1,%r8
 29e0888:	mov    %r8,0x18(%rdi)
 29e088c:	cmp    $0x1,%rsi
 29e0890:	je     29e0d18 <wasm[0]::function[1014]::helper::array_indexed_delete+0xed8>
 29e0896:	mov    0x40(%rsp),%rax
 29e089b:	cmp    $0x8,%eax
 29e089e:	seta   %al
 29e08a1:	sub    $0x1,%rsi
 29e08a5:	shl    $0x2,%rsi
 29e08a9:	mov    0x40(%rsp),%rdx
 29e08ae:	mov    %edx,%ecx
 29e08b0:	cmp    %rcx,%rsi
 29e08b3:	setb   %cl
 29e08b6:	test   %al,%cl
 29e08b8:	je     29e0d5b <wasm[0]::function[1014]::helper::array_indexed_delete+0xf1b>
 29e08be:	mov    (%rsp),%eax
 29e08c1:	test   %eax,%eax
 29e08c3:	je     29e0f1d <wasm[0]::function[1014]::helper::array_indexed_delete+0x10dd>
 29e08c9:	test   %eax,%eax
 29e08cb:	je     29e0f1f <wasm[0]::function[1014]::helper::array_indexed_delete+0x10df>
 29e08d1:	mov    0x28(%r12),%rcx
 29e08d6:	mov    %eax,%edx
 29e08d8:	mov    %rdx,%rax
 29e08db:	add    0x20(%r12),%rax
 29e08e0:	xor    %rsi,%rsi
 29e08e3:	cmp    %rcx,%rdx
 29e08e6:	cmova  %rsi,%rax
 29e08ea:	mov    0x10(%rax),%eax
 29e08ed:	mov    %eax,0x20(%rsp)
 29e08f1:	mov    0x40(%rsp),%rax
 29e08f6:	shr    $1,%eax
 29e08f8:	mov    %rax,0x40(%rsp)
 29e08fd:	mov    %rax,%r14
 29e0900:	shl    $0x2,%r14
 29e0904:	mov    %r14,%rax
 29e0907:	shr    $0x20,%rax
 29e090b:	test   %rax,%rax
 29e090e:	jne    29e0f21 <wasm[0]::function[1014]::helper::array_indexed_delete+0x10e1>
 29e0914:	mov    0x40(%rsp),%rax
 29e0919:	mov    %rax,%rcx
 29e091c:	shl    $0x2,%ecx
 29e091f:	add    $0x14,%ecx
 29e0922:	jb     29e0f23 <wasm[0]::function[1014]::helper::array_indexed_delete+0x10e3>
 29e0928:	mov    0x30(%rsp),%r15
 29e092d:	mov    0x20(%r15),%rsi
 29e0931:	mov    (%rsi),%eax
 29e0933:	mov    %eax,%edx
 29e0935:	mov    %ecx,%edi
 29e0937:	add    $0xf,%rdi
 29e093e:	mov    %rdi,%r8
 29e0941:	and    $0xfffffffffffffff0,%r8
 29e0945:	add    %rdx,%r8
 29e0948:	mov    0x4(%rsi),%r9d
 29e094c:	cmp    %r9,%r8
 29e094f:	ja     29e0dc1 <wasm[0]::function[1014]::helper::array_indexed_delete+0xf81>
 29e0955:	add    $0xf,%ecx
 29e095b:	and    $0xfffffff0,%ecx
 29e095e:	add    %eax,%ecx
 29e0960:	mov    %ecx,(%rsi)
 29e0962:	mov    0x20(%r12),%rsi
 29e0967:	lea    (%rsi,%rdx,1),%rcx
 29e096b:	movl   $0xa800000e,(%rsi,%rdx,1)
 29e0972:	mov    0x30(%rsp),%r15
 29e0977:	mov    0x28(%r15),%r8
 29e097b:	mov    0x1ac(%r8),%r8d
 29e0982:	mov    %r8d,0x4(%rsi,%rdx,1)
 29e0987:	and    $0xfffffffffffffff0,%rdi
 29e098b:	mov    %edi,0x8(%rsi,%rdx,1)
 29e098f:	mov    %eax,0x8(%rsp)
 29e0993:	mov    0x40(%rsp),%rsi
 29e0998:	mov    %esi,0x10(%rcx)
 29e099b:	test   %eax,%eax
 29e099d:	je     29e0f25 <wasm[0]::function[1014]::helper::array_indexed_delete+0x10e5>
 29e09a3:	mov    0x28(%r12),%rcx
 29e09a8:	mov    0x20(%r12),%rdx
 29e09ad:	mov    %eax,%eax
 29e09af:	lea    (%rdx,%rax,1),%rsi
 29e09b3:	lea    0x10(%rdx,%rax,1),%rdi
 29e09b8:	xor    %r8,%r8
 29e09bb:	cmp    %rcx,%rax
 29e09be:	cmova  %r8,%rdi
 29e09c2:	mov    (%rdi),%edi
 29e09c4:	mov    0x40(%rsp),%r8
 29e09c9:	cmp    %rdi,%r8
 29e09cc:	ja     29e0f27 <wasm[0]::function[1014]::helper::array_indexed_delete+0x10e7>
 29e09d2:	lea    0x14(%rdx,%rax,1),%rbx
 29e09d7:	mov    %rbx,%rdi
 29e09da:	add    %r14,%rdi
 29e09dd:	jb     29e0f29 <wasm[0]::function[1014]::helper::array_indexed_delete+0x10e9>
 29e09e3:	lea    (%rdx,%rcx,1),%rax
 29e09e7:	cmp    %rax,%rdi
 29e09ea:	ja     29e0f2b <wasm[0]::function[1014]::helper::array_indexed_delete+0x10eb>
 29e09f0:	mov    0x20(%rsp),%ecx
 29e09f4:	mov    (%rsp),%edx
 29e09f7:	mov    0x40(%rsp),%rax
 29e09fc:	lea    0x14(%rsi,%rax,4),%r14
 29e0a01:	mov    0x40(%rsp),%rsi
 29e0a06:	test   %rsi,%rax
 29e0a09:	je     29e0a4b <wasm[0]::function[1014]::helper::array_indexed_delete+0xc0b>
 29e0a0f:	mov    %ecx,0x10(%rsp)
 29e0a13:	mov    %edx,0x20(%rsp)
 29e0a17:	mov    0x50(%rsp),%rcx
 29e0a1c:	mov    (%rcx),%rcx
 29e0a1f:	mov    0x38(%rsp),%rax
 29e0a24:	cmp    %rax,%rcx
 29e0a27:	jae    29e0df1 <wasm[0]::function[1014]::helper::array_indexed_delete+0xfb1>
 29e0a2d:	movl   $0x0,(%rbx)
 29e0a33:	mov    0x10(%rsp),%ecx
 29e0a37:	mov    0x20(%rsp),%edx
 29e0a3b:	add    $0x4,%rbx
 29e0a42:	cmp    %r14,%rbx
 29e0a45:	jne    29e0a0f <wasm[0]::function[1014]::helper::array_indexed_delete+0xbcf>
 29e0a4b:	xor    %r14d,%r14d
 29e0a4e:	test   %ecx,%ecx
 29e0a50:	je     29e0f2d <wasm[0]::function[1014]::helper::array_indexed_delete+0x10ed>
 29e0a56:	test   %ecx,%ecx
 29e0a58:	je     29e0f2f <wasm[0]::function[1014]::helper::array_indexed_delete+0x10ef>
 29e0a5e:	mov    0x28(%r12),%rsi
 29e0a63:	mov    0x20(%r12),%r8
 29e0a68:	mov    %ecx,%edi
 29e0a6a:	lea    0x10(%r8,%rdi,1),%rax
 29e0a6f:	xor    %r8,%r8
 29e0a72:	cmp    %rsi,%rdi
 29e0a75:	cmova  %r8,%rax
 29e0a79:	mov    (%rax),%ebx
 29e0a7b:	mov    0x40(%rsp),%r9
 29e0a80:	mov    %rbx,0x48(%rsp)
 29e0a85:	mov    %r9,%r10
 29e0a88:	sub    $0x1,%r10d
 29e0a8c:	mov    %r10,0x40(%rsp)
 29e0a91:	mov    %ecx,0x20(%rsp)
 29e0a95:	mov    %edx,0x10(%rsp)
 29e0a99:	mov    0x50(%rsp),%rcx
 29e0a9e:	mov    (%rcx),%rsi
 29e0aa1:	mov    0x38(%rsp),%rax
 29e0aa6:	cmp    %rax,%rsi
 29e0aa9:	jae    29e0e18 <wasm[0]::function[1014]::helper::array_indexed_delete+0xfd8>
 29e0aaf:	mov    0x48(%rsp),%rbx
 29e0ab4:	jmp    29e0abe <wasm[0]::function[1014]::helper::array_indexed_delete+0xc7e>
 29e0ab9:	mov    0x48(%rsp),%rbx
 29e0abe:	cmp    %ebx,%r14d
 29e0ac1:	mov    %rbx,0x48(%rsp)
 29e0ac6:	jae    29e0cd6 <wasm[0]::function[1014]::helper::array_indexed_delete+0xe96>
 29e0acc:	mov    0x20(%rsp),%ecx
 29e0ad0:	test   %ecx,%ecx
 29e0ad2:	je     29e0f31 <wasm[0]::function[1014]::helper::array_indexed_delete+0x10f1>
 29e0ad8:	test   %ecx,%ecx
 29e0ada:	je     29e0f33 <wasm[0]::function[1014]::helper::array_indexed_delete+0x10f3>
 29e0ae0:	mov    0x28(%r12),%rax
 29e0ae5:	mov    0x20(%r12),%rdx
 29e0aea:	mov    %ecx,%r8d
 29e0aed:	lea    0x10(%rdx,%r8,1),%rdi
 29e0af2:	xor    %rsi,%rsi
 29e0af5:	cmp    %rax,%r8
 29e0af8:	cmova  %rsi,%rdi
 29e0afc:	mov    (%rdi),%r8d
 29e0aff:	cmp    %r8d,%r14d
 29e0b02:	jae    29e0f35 <wasm[0]::function[1014]::helper::array_indexed_delete+0x10f5>
 29e0b08:	mov    %r8d,%edi
 29e0b0b:	shl    $0x2,%rdi
 29e0b0f:	shr    $0x20,%rdi
 29e0b13:	test   %rdi,%rdi
 29e0b16:	jne    29e0f37 <wasm[0]::function[1014]::helper::array_indexed_delete+0x10f7>
 29e0b1c:	shl    $0x2,%r8d
 29e0b20:	add    $0x14,%r8d
 29e0b24:	jb     29e0f39 <wasm[0]::function[1014]::helper::array_indexed_delete+0x10f9>
 29e0b2a:	mov    %rcx,%rdi
 29e0b2d:	add    %r8d,%edi
 29e0b30:	jb     29e0f3b <wasm[0]::function[1014]::helper::array_indexed_delete+0x10fb>
 29e0b36:	mov    %edi,%edi
 29e0b38:	add    %rdi,%rdx
 29e0b3b:	cmp    %rax,%rdi
 29e0b3e:	cmova  %rsi,%rdx
 29e0b42:	mov    %r14,%rax
 29e0b45:	shl    $0x2,%eax
 29e0b48:	add    $0x14,%eax
 29e0b4e:	sub    %eax,%r8d
 29e0b51:	sub    %r8,%rdx
 29e0b54:	mov    (%rdx),%r9d
 29e0b57:	mov    0x10(%rsp),%eax
 29e0b5b:	mov    %r9d,0x28(%rsp)
 29e0b60:	mov    %ecx,0x18(%rsp)
 29e0b64:	mov    %eax,0x20(%rsp)
 29e0b68:	mov    0x50(%rsp),%rcx
 29e0b6d:	mov    (%rcx),%rax
 29e0b70:	mov    0x38(%rsp),%rcx
 29e0b75:	cmp    %rcx,%rax
 29e0b78:	jae    29e0e44 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1004>
 29e0b7e:	mov    0x28(%rsp),%eax
 29e0b82:	test   %eax,%eax
 29e0b84:	je     29e0cc2 <wasm[0]::function[1014]::helper::array_indexed_delete+0xe82>
 29e0b8a:	mov    0x28(%rsp),%ecx
 29e0b8e:	test   %ecx,%ecx
 29e0b90:	je     29e0f3d <wasm[0]::function[1014]::helper::array_indexed_delete+0x10fd>
 29e0b96:	mov    0x28(%r12),%rdx
 29e0b9b:	mov    0x20(%r12),%rsi
 29e0ba0:	mov    %ecx,%eax
 29e0ba2:	lea    (%rsi,%rax,1),%r8
 29e0ba6:	xor    %rdi,%rdi
 29e0ba9:	cmp    %rdx,%rax
 29e0bac:	cmova  %rdi,%r8
 29e0bb0:	mov    0x1c(%r8),%r9d
 29e0bb4:	mov    0x10(%r8),%rbx
 29e0bb8:	mov    0x8(%rsp),%r10d
 29e0bbd:	test   %r10d,%r10d
 29e0bc0:	je     29e0f3f <wasm[0]::function[1014]::helper::array_indexed_delete+0x10ff>
 29e0bc6:	test   %r10d,%r10d
 29e0bc9:	je     29e0f41 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1101>
 29e0bcf:	mov    %r10d,%eax
 29e0bd2:	lea    0x10(%rsi,%rax,1),%r11
 29e0bd7:	cmp    %rdx,%rax
 29e0bda:	cmova  %rdi,%r11
 29e0bde:	mov    (%r11),%eax
 29e0be1:	mov    %rbx,%r13
 29e0be4:	shr    $0x10,%r13d
 29e0be8:	xor    %r13d,%ebx
 29e0beb:	imul   $0x7feb352d,%ebx,%ebx
 29e0bf1:	mov    %rbx,%r13
 29e0bf4:	shr    $0xf,%r13d
 29e0bf8:	xor    %r13d,%ebx
 29e0bfb:	imul   $0x846ca68b,%ebx,%r15d
 29e0c02:	mov    %r15,%rbx
 29e0c05:	shr    $0x10,%ebx
 29e0c08:	xor    %ebx,%r15d
 29e0c0b:	mov    0x40(%rsp),%rbx
 29e0c10:	and    %ebx,%r15d
 29e0c13:	cmp    %eax,%r15d
 29e0c16:	jae    29e0f43 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1103>
 29e0c1c:	mov    %eax,%ebx
 29e0c1e:	shl    $0x2,%rbx
 29e0c22:	shr    $0x20,%rbx
 29e0c26:	test   %rbx,%rbx
 29e0c29:	jne    29e0f45 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1105>
 29e0c2f:	shl    $0x2,%eax
 29e0c32:	add    $0x14,%eax
 29e0c35:	jb     29e0f47 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1107>
 29e0c3b:	mov    %r10,%rbx
 29e0c3e:	add    %eax,%ebx
 29e0c40:	jb     29e0f49 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1109>
 29e0c46:	mov    %ebx,%ebx
 29e0c48:	lea    (%rsi,%rbx,1),%r13
 29e0c4c:	cmp    %rdx,%rbx
 29e0c4f:	cmova  %rdi,%r13
 29e0c53:	mov    %r15,%rbx
 29e0c56:	shl    $0x2,%ebx
 29e0c59:	add    $0x14,%ebx
 29e0c5f:	sub    %ebx,%eax
 29e0c61:	sub    %rax,%r13
 29e0c64:	mov    0x0(%r13),%eax
 29e0c68:	mov    %eax,0x1c(%r8)
 29e0c6c:	mov    (%r11),%eax
 29e0c6f:	cmp    %eax,%r15d
 29e0c72:	jae    29e0f4b <wasm[0]::function[1014]::helper::array_indexed_delete+0x110b>
 29e0c78:	mov    %eax,%r8d
 29e0c7b:	shl    $0x2,%r8
 29e0c7f:	shr    $0x20,%r8
 29e0c83:	test   %r8,%r8
 29e0c86:	jne    29e0f4d <wasm[0]::function[1014]::helper::array_indexed_delete+0x110d>
 29e0c8c:	shl    $0x2,%eax
 29e0c8f:	add    $0x14,%eax
 29e0c92:	jb     29e0f4f <wasm[0]::function[1014]::helper::array_indexed_delete+0x110f>
 29e0c98:	add    %eax,%r10d
 29e0c9b:	jb     29e0f51 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1111>
 29e0ca1:	mov    %r10d,%r8d
 29e0ca4:	add    %r8,%rsi
 29e0ca7:	cmp    %rdx,%r8
 29e0caa:	cmova  %rdi,%rsi
 29e0cae:	sub    %ebx,%eax
 29e0cb0:	sub    %rax,%rsi
 29e0cb3:	mov    %ecx,(%rsi)
 29e0cb5:	mov    0x18(%rsp),%ecx
 29e0cb9:	mov    0x20(%rsp),%eax
 29e0cbd:	jmp    29e0b5b <wasm[0]::function[1014]::helper::array_indexed_delete+0xd1b>
 29e0cc2:	mov    0x18(%rsp),%ecx
 29e0cc6:	mov    0x20(%rsp),%edx
 29e0cca:	add    $0x1,%r14d
 29e0cd1:	jmp    29e0a91 <wasm[0]::function[1014]::helper::array_indexed_delete+0xc51>
 29e0cd6:	mov    0x10(%rsp),%edi
 29e0cda:	test   %edi,%edi
 29e0cdc:	je     29e0f53 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1113>
 29e0ce2:	mov    0x8(%rsp),%esi
 29e0ce6:	test   %esi,%esi
 29e0ce8:	je     29e0f55 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1115>
 29e0cee:	test   %edi,%edi
 29e0cf0:	je     29e0f57 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1117>
 29e0cf6:	mov    0x28(%r12),%r9
 29e0cfb:	mov    %edi,%r10d
 29e0cfe:	mov    %r10,%rdi
 29e0d01:	add    0x20(%r12),%rdi
 29e0d06:	xor    %r11,%r11
 29e0d09:	cmp    %r9,%r10
 29e0d0c:	cmova  %r11,%rdi
 29e0d10:	mov    %esi,0x10(%rdi)
 29e0d13:	jmp    29e0d5b <wasm[0]::function[1014]::helper::array_indexed_delete+0xf1b>
 29e0d18:	mov    0x30(%rsp),%r15
 29e0d1d:	mov    0x9e0(%r15),%eax
 29e0d24:	mov    (%rsp),%ecx
 29e0d27:	test   %ecx,%ecx
 29e0d29:	je     29e0f59 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1119>
 29e0d2f:	test   %eax,%eax
 29e0d31:	je     29e0f5b <wasm[0]::function[1014]::helper::array_indexed_delete+0x111b>
 29e0d37:	test   %ecx,%ecx
 29e0d39:	je     29e0f5d <wasm[0]::function[1014]::helper::array_indexed_delete+0x111d>
 29e0d3f:	mov    0x28(%r12),%rdx
 29e0d44:	mov    %ecx,%esi
 29e0d46:	mov    %rsi,%rcx
 29e0d49:	add    0x20(%r12),%rcx
 29e0d4e:	xor    %rdi,%rdi
 29e0d51:	cmp    %rdx,%rsi
 29e0d54:	cmova  %rdi,%rcx
 29e0d58:	mov    %eax,0x10(%rcx)
 29e0d5b:	mov    0x60(%rsp),%rbx
 29e0d60:	mov    0x68(%rsp),%r12
 29e0d65:	mov    0x70(%rsp),%r13
 29e0d6a:	mov    0x78(%rsp),%r14
 29e0d6f:	mov    0x80(%rsp),%r15
 29e0d77:	add    $0x90,%rsp
 29e0d7e:	mov    %rbp,%rsp
 29e0d81:	pop    %rbp
 29e0d82:	ret
 29e0d83:	mov    0x30(%rsp),%rdi
 29e0d88:	call   3018b79 <wasmtime_builtin_new_epoch>
 29e0d8d:	mov    %rax,0x38(%rsp)
 29e0d92:	mov    %rbx,%rcx
 29e0d95:	jmp    29dfeb0 <wasm[0]::function[1014]::helper::array_indexed_delete+0x70>
 29e0d9a:	mov    0x8(%r12),%rcx
 29e0d9f:	mov    %rcx,0x38(%rsp)
 29e0da4:	cmp    %rcx,%rax
 29e0da7:	jb     29e06fc <wasm[0]::function[1014]::helper::array_indexed_delete+0x8bc>
 29e0dad:	mov    0x30(%rsp),%rdi
 29e0db2:	call   3018b79 <wasmtime_builtin_new_epoch>
 29e0db7:	mov    %rax,0x38(%rsp)
 29e0dbc:	jmp    29e06fc <wasm[0]::function[1014]::helper::array_indexed_delete+0x8bc>
 29e0dc1:	mov    $0xa800000e,%esi
 29e0dc6:	mov    0x30(%rsp),%r15
 29e0dcb:	mov    0x28(%r15),%rax
 29e0dcf:	mov    0x1ac(%rax),%edx
 29e0dd5:	mov    $0x10,%r8d
 29e0ddb:	mov    0x30(%rsp),%rdi
 29e0de0:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
 29e0de5:	mov    %eax,%ecx
 29e0de7:	add    0x20(%r12),%rcx
 29e0dec:	jmp    29e098f <wasm[0]::function[1014]::helper::array_indexed_delete+0xb4f>
 29e0df1:	mov    0x8(%r12),%rax
 29e0df6:	mov    %rax,0x38(%rsp)
 29e0dfb:	cmp    %rax,%rcx
 29e0dfe:	jb     29e0a2d <wasm[0]::function[1014]::helper::array_indexed_delete+0xbed>
 29e0e04:	mov    0x30(%rsp),%rdi
 29e0e09:	call   3018b79 <wasmtime_builtin_new_epoch>
 29e0e0e:	mov    %rax,0x38(%rsp)
 29e0e13:	jmp    29e0a2d <wasm[0]::function[1014]::helper::array_indexed_delete+0xbed>
 29e0e18:	mov    0x8(%r12),%rax
 29e0e1d:	mov    %rax,0x38(%rsp)
 29e0e22:	cmp    %rax,%rsi
 29e0e25:	jb     29e0ab9 <wasm[0]::function[1014]::helper::array_indexed_delete+0xc79>
 29e0e2b:	mov    0x30(%rsp),%rdi
 29e0e30:	call   3018b79 <wasmtime_builtin_new_epoch>
 29e0e35:	mov    %rax,0x38(%rsp)
 29e0e3a:	mov    0x48(%rsp),%rbx
 29e0e3f:	jmp    29e0abe <wasm[0]::function[1014]::helper::array_indexed_delete+0xc7e>
 29e0e44:	mov    0x8(%r12),%rcx
 29e0e49:	mov    %rcx,0x38(%rsp)
 29e0e4e:	cmp    %rcx,%rax
 29e0e51:	jb     29e0b7e <wasm[0]::function[1014]::helper::array_indexed_delete+0xd3e>
 29e0e57:	mov    0x30(%rsp),%rdi
 29e0e5c:	call   3018b79 <wasmtime_builtin_new_epoch>
 29e0e61:	mov    %rax,0x38(%rsp)
 29e0e66:	jmp    29e0b7e <wasm[0]::function[1014]::helper::array_indexed_delete+0xd3e>
 29e0e6b:	ud2
 29e0e6d:	ud2
 29e0e6f:	ud2
 29e0e71:	ud2
 29e0e73:	ud2
 29e0e75:	ud2
 29e0e77:	ud2
 29e0e79:	ud2
 29e0e7b:	ud2
 29e0e7d:	ud2
 29e0e7f:	ud2
 29e0e81:	ud2
 29e0e83:	ud2
 29e0e85:	ud2
 29e0e87:	ud2
 29e0e89:	ud2
 29e0e8b:	ud2
 29e0e8d:	ud2
 29e0e8f:	ud2
 29e0e91:	ud2
 29e0e93:	ud2
 29e0e95:	ud2
 29e0e97:	ud2
 29e0e99:	ud2
 29e0e9b:	ud2
 29e0e9d:	ud2
 29e0e9f:	ud2
 29e0ea1:	ud2
 29e0ea3:	ud2
 29e0ea5:	ud2
 29e0ea7:	ud2
 29e0ea9:	ud2
 29e0eab:	ud2
 29e0ead:	ud2
 29e0eaf:	ud2
 29e0eb1:	ud2
 29e0eb3:	ud2
 29e0eb5:	ud2
 29e0eb7:	ud2
 29e0eb9:	ud2
 29e0ebb:	ud2
 29e0ebd:	ud2
 29e0ebf:	ud2
 29e0ec1:	ud2
 29e0ec3:	ud2
 29e0ec5:	ud2
 29e0ec7:	ud2
 29e0ec9:	ud2
 29e0ecb:	ud2
 29e0ecd:	ud2
 29e0ecf:	ud2
 29e0ed1:	ud2
 29e0ed3:	ud2
 29e0ed5:	ud2
 29e0ed7:	ud2
 29e0ed9:	ud2
 29e0edb:	ud2
 29e0edd:	ud2
 29e0edf:	ud2
 29e0ee1:	ud2
 29e0ee3:	ud2
 29e0ee5:	ud2
 29e0ee7:	ud2
 29e0ee9:	ud2
 29e0eeb:	ud2
 29e0eed:	ud2
 29e0eef:	ud2
 29e0ef1:	ud2
 29e0ef3:	ud2
 29e0ef5:	ud2
 29e0ef7:	ud2
 29e0ef9:	ud2
 29e0efb:	ud2
 29e0efd:	ud2
 29e0eff:	ud2
 29e0f01:	ud2
 29e0f03:	ud2
 29e0f05:	ud2
 29e0f07:	ud2
 29e0f09:	ud2
 29e0f0b:	ud2
 29e0f0d:	ud2
 29e0f0f:	ud2
 29e0f11:	ud2
 29e0f13:	ud2
 29e0f15:	ud2
 29e0f17:	ud2
 29e0f19:	ud2
 29e0f1b:	ud2
 29e0f1d:	ud2
 29e0f1f:	ud2
 29e0f21:	ud2
 29e0f23:	ud2
 29e0f25:	ud2
 29e0f27:	ud2
 29e0f29:	ud2
 29e0f2b:	ud2
 29e0f2d:	ud2
 29e0f2f:	ud2
 29e0f31:	ud2
 29e0f33:	ud2
 29e0f35:	ud2
 29e0f37:	ud2
 29e0f39:	ud2
 29e0f3b:	ud2
 29e0f3d:	ud2
 29e0f3f:	ud2
 29e0f41:	ud2
 29e0f43:	ud2
 29e0f45:	ud2
 29e0f47:	ud2
 29e0f49:	ud2
 29e0f4b:	ud2
 29e0f4d:	ud2
 29e0f4f:	ud2
 29e0f51:	ud2
 29e0f53:	ud2
 29e0f55:	ud2
 29e0f57:	ud2
 29e0f59:	ud2
 29e0f5b:	ud2
 29e0f5d:	ud2
 29e0f5f:	add    %bh,%bh
 29e0f61:	(bad)
 29e0f62:	(bad)
 29e0f63:	incl   (%rax)
 29e0f65:	add    %al,(%rax)
	...
