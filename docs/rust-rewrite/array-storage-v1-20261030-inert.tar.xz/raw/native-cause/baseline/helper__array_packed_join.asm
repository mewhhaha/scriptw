
/workspace/scriptw/target/performance-dense-numbers-20261030/native-cause/baseline/runtime-portable.elf:     file format elf64-x86-64


Disassembly of section .text:

00000000029d6e40 <wasm[0]::function[1009]::helper::array_packed_join>:
 29d6e40:	push   %rbp
 29d6e41:	mov    %rsp,%rbp
 29d6e44:	mov    0x8(%rdi),%r10
 29d6e48:	mov    0x18(%r10),%r10
 29d6e4c:	add    $0x120,%r10
 29d6e53:	cmp    %rsp,%r10
 29d6e56:	ja     29d8685 <wasm[0]::function[1009]::helper::array_packed_join+0x1845>
 29d6e5c:	sub    $0x110,%rsp
 29d6e63:	mov    %rbx,0xe0(%rsp)
 29d6e6b:	mov    %r12,0xe8(%rsp)
 29d6e73:	mov    %r13,0xf0(%rsp)
 29d6e7b:	mov    %r14,0xf8(%rsp)
 29d6e83:	mov    %r15,0x100(%rsp)
 29d6e8b:	mov    %r9,0x68(%rsp)
 29d6e90:	mov    0x10(%rbp),%rsi
 29d6e94:	mov    %r8d,0x38(%rsp)
 29d6e99:	mov    %esi,0x40(%rsp)
 29d6e9d:	movl   $0x0,0x10(%rsp)
 29d6ea5:	movl   $0x0,(%rsp)
 29d6eac:	mov    0x18(%rdi),%rax
 29d6eb0:	mov    (%rax),%rcx
 29d6eb3:	mov    %rax,0xd0(%rsp)
 29d6ebb:	mov    0x8(%rdi),%rdx
 29d6ebf:	mov    %rdi,0x60(%rsp)
 29d6ec4:	mov    0x8(%rdx),%rax
 29d6ec8:	mov    %rdx,0xc8(%rsp)
 29d6ed0:	cmp    %rax,%rcx
 29d6ed3:	jae    29d83d4 <wasm[0]::function[1009]::helper::array_packed_join+0x1594>
 29d6ed9:	mov    0x68(%rsp),%r15
 29d6ede:	mov    %rax,0x88(%rsp)
 29d6ee6:	test   %r15,%r15
 29d6ee9:	je     29d838f <wasm[0]::function[1009]::helper::array_packed_join+0x154f>
 29d6eef:	mov    0x40(%rsp),%edx
 29d6ef3:	xor    %ecx,%ecx
 29d6ef5:	test   %edx,%edx
 29d6ef7:	je     29d8687 <wasm[0]::function[1009]::helper::array_packed_join+0x1847>
 29d6efd:	test   %edx,%edx
 29d6eff:	je     29d8689 <wasm[0]::function[1009]::helper::array_packed_join+0x1849>
 29d6f05:	mov    0xc8(%rsp),%r10
 29d6f0d:	mov    0x28(%r10),%rax
 29d6f11:	mov    0x20(%r10),%rsi
 29d6f15:	mov    %edx,%r8d
 29d6f18:	lea    (%rsi,%r8,1),%rdx
 29d6f1c:	xor    %rdi,%rdi
 29d6f1f:	cmp    %rax,%r8
 29d6f22:	cmova  %rdi,%rdx
 29d6f26:	mov    0x10(%rdx),%edx
 29d6f29:	test   %edx,%edx
 29d6f2b:	je     29d868b <wasm[0]::function[1009]::helper::array_packed_join+0x184b>
 29d6f31:	test   %edx,%edx
 29d6f33:	je     29d868d <wasm[0]::function[1009]::helper::array_packed_join+0x184d>
 29d6f39:	mov    %edx,%r8d
 29d6f3c:	lea    0x10(%rsi,%r8,1),%rsi
 29d6f41:	cmp    %rax,%r8
 29d6f44:	cmova  %rdi,%rsi
 29d6f48:	mov    (%rsi),%r14d
 29d6f4b:	mov    %r14,0xc0(%rsp)
 29d6f53:	mov    0x38(%rsp),%eax
 29d6f57:	test   %eax,%eax
 29d6f59:	je     29d6fa2 <wasm[0]::function[1009]::helper::array_packed_join+0x162>
 29d6f5f:	mov    0x38(%rsp),%eax
 29d6f63:	xor    %ecx,%ecx
 29d6f65:	test   $0x1,%eax
 29d6f6a:	jne    29d6fa2 <wasm[0]::function[1009]::helper::array_packed_join+0x162>
 29d6f70:	mov    0x28(%r10),%rsi
 29d6f74:	mov    0x20(%r10),%r8
 29d6f78:	mov    %eax,%edi
 29d6f7a:	lea    0x4(%r8,%rdi,1),%rax
 29d6f7f:	xor    %r8,%r8
 29d6f82:	cmp    %rsi,%rdi
 29d6f85:	cmova  %r8,%rax
 29d6f89:	mov    (%rax),%esi
 29d6f8b:	mov    0x60(%rsp),%rcx
 29d6f90:	mov    0x28(%rcx),%rdi
 29d6f94:	cmp    0x254(%rdi),%esi
 29d6f9a:	sete   %sil
 29d6f9e:	movzbl %sil,%ecx
 29d6fa2:	mov    0x10(%rsp),%eax
 29d6fa6:	xor    %edi,%edi
 29d6fa8:	test   %ecx,%ecx
 29d6faa:	jne    29d6fc0 <wasm[0]::function[1009]::helper::array_packed_join+0x180>
 29d6fb0:	mov    %rdi,%r8
 29d6fb3:	mov    %r10,0xc8(%rsp)
 29d6fbb:	jmp    29d8323 <wasm[0]::function[1009]::helper::array_packed_join+0x14e3>
 29d6fc0:	mov    0x38(%rsp),%r9d
 29d6fc5:	xor    %ecx,%ecx
 29d6fc7:	test   %r9d,%r9d
 29d6fca:	je     29d7010 <wasm[0]::function[1009]::helper::array_packed_join+0x1d0>
 29d6fd0:	xor    %ecx,%ecx
 29d6fd2:	test   $0x1,%r9d
 29d6fd9:	jne    29d7010 <wasm[0]::function[1009]::helper::array_packed_join+0x1d0>
 29d6fdf:	mov    0x28(%r10),%rcx
 29d6fe3:	mov    0x20(%r10),%rsi
 29d6fe7:	mov    %r9d,%edi
 29d6fea:	lea    0x4(%rsi,%rdi,1),%rsi
 29d6fef:	xor    %r8,%r8
 29d6ff2:	cmp    %rcx,%rdi
 29d6ff5:	cmova  %r8,%rsi
 29d6ff9:	mov    (%rsi),%ecx
 29d6ffb:	mov    0x60(%rsp),%rsi
 29d7000:	mov    0x28(%rsi),%rsi
 29d7004:	cmp    0x254(%rsi),%ecx
 29d700a:	sete   %cl
 29d700d:	movzbl %cl,%ecx
 29d7010:	test   %ecx,%ecx
 29d7012:	je     29d868f <wasm[0]::function[1009]::helper::array_packed_join+0x184f>
 29d7018:	test   %r9d,%r9d
 29d701b:	je     29d8691 <wasm[0]::function[1009]::helper::array_packed_join+0x1851>
 29d7021:	test   %r9d,%r9d
 29d7024:	je     29d8693 <wasm[0]::function[1009]::helper::array_packed_join+0x1853>
 29d702a:	mov    0x28(%r10),%rsi
 29d702e:	mov    0x20(%r10),%rcx
 29d7032:	mov    %r9d,%edi
 29d7035:	add    %rdi,%rcx
 29d7038:	xor    %r8,%r8
 29d703b:	cmp    %rsi,%rdi
 29d703e:	cmova  %r8,%rcx
 29d7042:	mov    0x14(%rcx),%esi
 29d7045:	mov    %esi,0x40(%rsp)
 29d7049:	mov    0x18(%rcx),%rcx
 29d704d:	xor    %edi,%edi
 29d704f:	cmp    %r15,%rcx
 29d7052:	mov    %r15,0x68(%rsp)
 29d7057:	je     29d706d <wasm[0]::function[1009]::helper::array_packed_join+0x22d>
 29d705d:	mov    %rdi,%r8
 29d7060:	mov    %r10,0xc8(%rsp)
 29d7068:	jmp    29d8323 <wasm[0]::function[1009]::helper::array_packed_join+0x14e3>
 29d706d:	mov    0x40(%rsp),%eax
 29d7071:	xor    %edi,%edi
 29d7073:	test   %eax,%eax
 29d7075:	je     29d8695 <wasm[0]::function[1009]::helper::array_packed_join+0x1855>
 29d707b:	test   %eax,%eax
 29d707d:	je     29d8697 <wasm[0]::function[1009]::helper::array_packed_join+0x1857>
 29d7083:	mov    0x28(%r10),%rcx
 29d7087:	mov    0x20(%r10),%r8
 29d708b:	mov    %r10,0xc8(%rsp)
 29d7093:	mov    %eax,%esi
 29d7095:	lea    (%r8,%rsi,1),%rax
 29d7099:	xor    %r8,%r8
 29d709c:	cmp    %rcx,%rsi
 29d709f:	cmova  %r8,%rax
 29d70a3:	mov    0x24(%rax),%ecx
 29d70a6:	mov    0x10(%rsp),%eax
 29d70aa:	cmp    $0x2,%ecx
 29d70ad:	sete   %sil
 29d70b1:	cmp    $0x3,%ecx
 29d70b4:	sete   %cl
 29d70b7:	or     %ecx,%esi
 29d70b9:	movzbl %sil,%ecx
 29d70bd:	test   %ecx,%ecx
 29d70bf:	jne    29d70cd <wasm[0]::function[1009]::helper::array_packed_join+0x28d>
 29d70c5:	mov    %rdi,%r8
 29d70c8:	jmp    29d8323 <wasm[0]::function[1009]::helper::array_packed_join+0x14e3>
 29d70cd:	mov    (%rsp),%ecx
 29d70d0:	mov    0x10(%rsp),%eax
 29d70d4:	xor    %r15,%r15
 29d70d7:	xor    %r13d,%r13d
 29d70da:	mov    %r13,0x80(%rsp)
 29d70e2:	mov    $0x1,%esi
 29d70e7:	mov    %rsi,0xb8(%rsp)
 29d70ef:	mov    0x60(%rsp),%rsi
 29d70f4:	mov    0x28(%rsi),%r13
 29d70f8:	mov    0x234(%r13),%esi
 29d70ff:	mov    %r13,%r12
 29d7102:	mov    0xc0(%rsp),%r14
 29d710a:	mov    %rsi,0xb0(%rsp)
 29d7112:	mov    %r14d,%esi
 29d7115:	mov    %rsi,0xa8(%rsp)
 29d711d:	mov    0x80(%rsp),%rdi
 29d7125:	mov    %r15,%r13
 29d7128:	mov    %r15,%r14
 29d712b:	mov    %ecx,0x8(%rsp)
 29d712f:	mov    %edx,0x38(%rsp)
 29d7133:	mov    %eax,0x10(%rsp)
 29d7137:	mov    %edi,(%rsp)
 29d713a:	mov    0xd0(%rsp),%rcx
 29d7142:	mov    (%rcx),%rax
 29d7145:	mov    0x88(%rsp),%rcx
 29d714d:	cmp    %rcx,%rax
 29d7150:	jae    29d83f0 <wasm[0]::function[1009]::helper::array_packed_join+0x15b0>
 29d7156:	mov    0x68(%rsp),%rcx
 29d715b:	jmp    29d7165 <wasm[0]::function[1009]::helper::array_packed_join+0x325>
 29d7160:	mov    0x68(%rsp),%rcx
 29d7165:	cmp    %rcx,%r15
 29d7168:	jae    29d75e8 <wasm[0]::function[1009]::helper::array_packed_join+0x7a8>
 29d716e:	mov    0x40(%rsp),%eax
 29d7172:	test   %eax,%eax
 29d7174:	je     29d8699 <wasm[0]::function[1009]::helper::array_packed_join+0x1859>
 29d717a:	test   %eax,%eax
 29d717c:	je     29d869b <wasm[0]::function[1009]::helper::array_packed_join+0x185b>
 29d7182:	mov    0xc8(%rsp),%r10
 29d718a:	mov    0x28(%r10),%rcx
 29d718e:	mov    %eax,%edx
 29d7190:	mov    %rdx,%rax
 29d7193:	add    0x20(%r10),%rax
 29d7197:	xor    %rsi,%rsi
 29d719a:	cmp    %rcx,%rdx
 29d719d:	cmova  %rsi,%rax
 29d71a1:	mov    0x24(%rax),%eax
 29d71a4:	cmp    $0x3,%eax
 29d71a7:	je     29d735a <wasm[0]::function[1009]::helper::array_packed_join+0x51a>
 29d71ad:	mov    0x40(%rsp),%eax
 29d71b1:	xor    %edx,%edx
 29d71b3:	test   %eax,%eax
 29d71b5:	je     29d869d <wasm[0]::function[1009]::helper::array_packed_join+0x185d>
 29d71bb:	test   %eax,%eax
 29d71bd:	je     29d869f <wasm[0]::function[1009]::helper::array_packed_join+0x185f>
 29d71c3:	mov    0xc8(%rsp),%r10
 29d71cb:	mov    0x28(%r10),%rcx
 29d71cf:	mov    0x20(%r10),%r8
 29d71d3:	mov    %eax,%edi
 29d71d5:	lea    (%r8,%rdi,1),%rsi
 29d71d9:	xor    %r9,%r9
 29d71dc:	cmp    %rcx,%rdi
 29d71df:	cmova  %r9,%rsi
 29d71e3:	mov    0x28(%rsi),%eax
 29d71e6:	mov    0x2c(%rsi),%edi
 29d71e9:	test   %eax,%eax
 29d71eb:	je     29d86a1 <wasm[0]::function[1009]::helper::array_packed_join+0x1861>
 29d71f1:	test   %eax,%eax
 29d71f3:	je     29d86a3 <wasm[0]::function[1009]::helper::array_packed_join+0x1863>
 29d71f9:	mov    %eax,%esi
 29d71fb:	lea    0x10(%r8,%rsi,1),%r8
 29d7200:	cmp    %rcx,%rsi
 29d7203:	cmova  %r9,%r8
 29d7207:	mov    (%r8),%r8d
 29d720a:	mov    0x8(%rsp),%ecx
 29d720e:	mov    %r8d,%r8d
 29d7211:	cmp    %r8,%r15
 29d7214:	jb     29d7222 <wasm[0]::function[1009]::helper::array_packed_join+0x3e2>
 29d721a:	mov    %r13,%rsi
 29d721d:	jmp    29d7493 <wasm[0]::function[1009]::helper::array_packed_join+0x653>
 29d7222:	xor    %edx,%edx
 29d7224:	test   %edi,%edi
 29d7226:	je     29d86a5 <wasm[0]::function[1009]::helper::array_packed_join+0x1865>
 29d722c:	test   %edi,%edi
 29d722e:	je     29d86a7 <wasm[0]::function[1009]::helper::array_packed_join+0x1867>
 29d7234:	mov    0xc8(%rsp),%r10
 29d723c:	mov    0x28(%r10),%rcx
 29d7240:	mov    0x20(%r10),%r8
 29d7244:	mov    %edi,%r10d
 29d7247:	lea    0x10(%r8,%r10,1),%r11
 29d724c:	xor    %r9,%r9
 29d724f:	cmp    %rcx,%r10
 29d7252:	cmova  %r9,%r11
 29d7256:	mov    (%r11),%r10d
 29d7259:	mov    %r15,%r11
 29d725c:	shr    $0x6,%r11d
 29d7260:	cmp    %r10d,%r11d
 29d7263:	jae    29d86a9 <wasm[0]::function[1009]::helper::array_packed_join+0x1869>
 29d7269:	mov    %r10d,%ebx
 29d726c:	shl    $0x3,%rbx
 29d7270:	shr    $0x20,%rbx
 29d7274:	test   %rbx,%rbx
 29d7277:	jne    29d86ab <wasm[0]::function[1009]::helper::array_packed_join+0x186b>
 29d727d:	shl    $0x3,%r10d
 29d7281:	add    $0x18,%r10d
 29d7285:	jb     29d86ad <wasm[0]::function[1009]::helper::array_packed_join+0x186d>
 29d728b:	add    %r10d,%edi
 29d728e:	jb     29d86af <wasm[0]::function[1009]::helper::array_packed_join+0x186f>
 29d7294:	mov    %edi,%ebx
 29d7296:	lea    (%r8,%rbx,1),%rdi
 29d729a:	cmp    %rcx,%rbx
 29d729d:	cmova  %r9,%rdi
 29d72a1:	shl    $0x3,%r11d
 29d72a5:	lea    0x18(%r11),%ecx
 29d72a9:	sub    %ecx,%r10d
 29d72ac:	sub    %r10,%rdi
 29d72af:	mov    (%rdi),%rdi
 29d72b2:	mov    0x8(%rsp),%ecx
 29d72b6:	bt     %r15,%rdi
 29d72ba:	jb     29d72c8 <wasm[0]::function[1009]::helper::array_packed_join+0x488>
 29d72c0:	mov    %r13,%rsi
 29d72c3:	jmp    29d7493 <wasm[0]::function[1009]::helper::array_packed_join+0x653>
 29d72c8:	mov    0xc8(%rsp),%r10
 29d72d0:	mov    0x28(%r10),%rcx
 29d72d4:	mov    0x20(%r10),%rdi
 29d72d8:	lea    0x10(%rdi,%rsi,1),%r8
 29d72dd:	xor    %rdx,%rdx
 29d72e0:	cmp    %rcx,%rsi
 29d72e3:	cmova  %rdx,%r8
 29d72e7:	mov    (%r8),%esi
 29d72ea:	cmp    %esi,%r15d
 29d72ed:	jae    29d86b1 <wasm[0]::function[1009]::helper::array_packed_join+0x1871>
 29d72f3:	mov    %esi,%r8d
 29d72f6:	shl    $0x3,%r8
 29d72fa:	shr    $0x20,%r8
 29d72fe:	test   %r8,%r8
 29d7301:	jne    29d86b3 <wasm[0]::function[1009]::helper::array_packed_join+0x1873>
 29d7307:	mov    $0x3,%r8d
 29d730d:	mov    %r8,0x80(%rsp)
 29d7315:	shl    $0x3,%esi
 29d7318:	add    $0x18,%esi
 29d731b:	jb     29d86b5 <wasm[0]::function[1009]::helper::array_packed_join+0x1875>
 29d7321:	add    %esi,%eax
 29d7323:	jb     29d86b7 <wasm[0]::function[1009]::helper::array_packed_join+0x1877>
 29d7329:	mov    %eax,%r8d
 29d732c:	lea    (%rdi,%r8,1),%rax
 29d7330:	cmp    %rcx,%r8
 29d7333:	cmova  %rdx,%rax
 29d7337:	mov    %r15,%rcx
 29d733a:	shl    $0x3,%ecx
 29d733d:	add    $0x18,%ecx
 29d7343:	sub    %ecx,%esi
 29d7345:	sub    %rsi,%rax
 29d7348:	mov    (%rax),%rsi
 29d734b:	xor    %ecx,%ecx
 29d734d:	mov    0xb8(%rsp),%rdx
 29d7355:	jmp    29d7493 <wasm[0]::function[1009]::helper::array_packed_join+0x653>
 29d735a:	mov    %r13,%rsi
 29d735d:	mov    0x40(%rsp),%eax
 29d7361:	xor    %edx,%edx
 29d7363:	test   %eax,%eax
 29d7365:	je     29d86b9 <wasm[0]::function[1009]::helper::array_packed_join+0x1879>
 29d736b:	test   %eax,%eax
 29d736d:	je     29d86bb <wasm[0]::function[1009]::helper::array_packed_join+0x187b>
 29d7373:	mov    0xc8(%rsp),%r10
 29d737b:	mov    0x28(%r10),%rcx
 29d737f:	mov    0x20(%r10),%r8
 29d7383:	mov    %eax,%edi
 29d7385:	lea    (%r8,%rdi,1),%rax
 29d7389:	xor    %r9,%r9
 29d738c:	cmp    %rcx,%rdi
 29d738f:	cmova  %r9,%rax
 29d7393:	mov    0x30(%rax),%eax
 29d7396:	test   %eax,%eax
 29d7398:	je     29d86bd <wasm[0]::function[1009]::helper::array_packed_join+0x187d>
 29d739e:	test   %eax,%eax
 29d73a0:	je     29d86bf <wasm[0]::function[1009]::helper::array_packed_join+0x187f>
 29d73a6:	mov    %eax,%edi
 29d73a8:	lea    0x10(%r8,%rdi,1),%r8
 29d73ad:	cmp    %rcx,%rdi
 29d73b0:	cmova  %r9,%r8
 29d73b4:	mov    (%r8),%r8d
 29d73b7:	mov    0x8(%rsp),%ecx
 29d73bb:	mov    %r8d,%r8d
 29d73be:	cmp    %r8,%r15
 29d73c1:	jae    29d7493 <wasm[0]::function[1009]::helper::array_packed_join+0x653>
 29d73c7:	mov    0xc8(%rsp),%r10
 29d73cf:	mov    0x28(%r10),%rcx
 29d73d3:	mov    0x20(%r10),%r8
 29d73d7:	lea    0x10(%r8,%rdi,1),%r9
 29d73dc:	xor    %rdx,%rdx
 29d73df:	cmp    %rcx,%rdi
 29d73e2:	cmova  %rdx,%r9
 29d73e6:	mov    (%r9),%edi
 29d73e9:	cmp    %edi,%r15d
 29d73ec:	jae    29d86c1 <wasm[0]::function[1009]::helper::array_packed_join+0x1881>
 29d73f2:	mov    %edi,%r9d
 29d73f5:	shl    $0x2,%r9
 29d73f9:	shr    $0x20,%r9
 29d73fd:	test   %r9,%r9
 29d7400:	jne    29d86c3 <wasm[0]::function[1009]::helper::array_packed_join+0x1883>
 29d7406:	shl    $0x2,%edi
 29d7409:	add    $0x14,%edi
 29d740c:	jb     29d86c5 <wasm[0]::function[1009]::helper::array_packed_join+0x1885>
 29d7412:	add    %edi,%eax
 29d7414:	jb     29d86c7 <wasm[0]::function[1009]::helper::array_packed_join+0x1887>
 29d741a:	mov    %eax,%r9d
 29d741d:	lea    (%r8,%r9,1),%rax
 29d7421:	cmp    %rcx,%r9
 29d7424:	cmova  %rdx,%rax
 29d7428:	mov    %r15,%rcx
 29d742b:	shl    $0x2,%ecx
 29d742e:	add    $0x14,%ecx
 29d7434:	sub    %ecx,%edi
 29d7436:	sub    %rdi,%rax
 29d7439:	mov    (%rax),%eax
 29d743b:	mov    0x8(%rsp),%ecx
 29d743f:	xor    %edx,%edx
 29d7441:	test   %eax,%eax
 29d7443:	je     29d7493 <wasm[0]::function[1009]::helper::array_packed_join+0x653>
 29d7449:	test   %eax,%eax
 29d744b:	je     29d86c9 <wasm[0]::function[1009]::helper::array_packed_join+0x1889>
 29d7451:	test   %eax,%eax
 29d7453:	je     29d86cb <wasm[0]::function[1009]::helper::array_packed_join+0x188b>
 29d7459:	mov    0xc8(%rsp),%r10
 29d7461:	mov    0x28(%r10),%rcx
 29d7465:	mov    0x20(%r10),%rsi
 29d7469:	mov    %eax,%edx
 29d746b:	lea    (%rsi,%rdx,1),%rax
 29d746f:	xor    %rsi,%rsi
 29d7472:	cmp    %rcx,%rdx
 29d7475:	cmova  %rsi,%rax
 29d7479:	mov    0x18(%rax),%ecx
 29d747c:	mov    %rcx,0x80(%rsp)
 29d7484:	mov    0x10(%rax),%rsi
 29d7488:	mov    0x1c(%rax),%ecx
 29d748b:	mov    0xb8(%rsp),%rdx
 29d7493:	mov    0x10(%rsp),%eax
 29d7497:	mov    (%rsp),%r8d
 29d749b:	xor    %edi,%edi
 29d749d:	test   %edx,%edx
 29d749f:	je     29d8323 <wasm[0]::function[1009]::helper::array_packed_join+0x14e3>
 29d74a5:	mov    0x80(%rsp),%rax
 29d74ad:	cmp    $0x4,%eax
 29d74b0:	je     29d74f3 <wasm[0]::function[1009]::helper::array_packed_join+0x6b3>
 29d74b6:	mov    0x10(%rsp),%eax
 29d74ba:	mov    (%rsp),%r8d
 29d74be:	mov    0x80(%rsp),%rdx
 29d74c6:	cmp    $0x1,%edx
 29d74c9:	sete   %r9b
 29d74cd:	xor    %edi,%edi
 29d74cf:	mov    0x80(%rsp),%r10
 29d74d7:	test   %r10d,%edx
 29d74da:	sete   %dl
 29d74dd:	or     %edx,%r9d
 29d74e0:	movzbl %r9b,%edx
 29d74e4:	test   %edx,%edx
 29d74e6:	je     29d8323 <wasm[0]::function[1009]::helper::array_packed_join+0x14e3>
 29d74ec:	xor    %eax,%eax
 29d74ee:	jmp    29d759e <wasm[0]::function[1009]::helper::array_packed_join+0x75e>
 29d74f3:	xor    %eax,%eax
 29d74f5:	test   %ecx,%ecx
 29d74f7:	je     29d753e <wasm[0]::function[1009]::helper::array_packed_join+0x6fe>
 29d74fd:	xor    %eax,%eax
 29d74ff:	test   $0x1,%ecx
 29d7505:	jne    29d753e <wasm[0]::function[1009]::helper::array_packed_join+0x6fe>
 29d750b:	mov    0xc8(%rsp),%r10
 29d7513:	mov    0x28(%r10),%rax
 29d7517:	mov    0x20(%r10),%rdx
 29d751b:	mov    %ecx,%edi
 29d751d:	lea    0x4(%rdx,%rdi,1),%rdx
 29d7522:	xor    %r8,%r8
 29d7525:	cmp    %rax,%rdi
 29d7528:	cmova  %r8,%rdx
 29d752c:	mov    (%rdx),%eax
 29d752e:	mov    0xb0(%rsp),%rdx
 29d7536:	cmp    %edx,%eax
 29d7538:	sete   %al
 29d753b:	movzbl %al,%eax
 29d753e:	test   %eax,%eax
 29d7540:	je     29d86cd <wasm[0]::function[1009]::helper::array_packed_join+0x188d>
 29d7546:	test   %ecx,%ecx
 29d7548:	je     29d86cf <wasm[0]::function[1009]::helper::array_packed_join+0x188f>
 29d754e:	test   %ecx,%ecx
 29d7550:	je     29d86d1 <wasm[0]::function[1009]::helper::array_packed_join+0x1891>
 29d7556:	mov    0xc8(%rsp),%r10
 29d755e:	mov    0x28(%r10),%rax
 29d7562:	mov    0x20(%r10),%rdx
 29d7566:	mov    %ecx,%r9d
 29d7569:	lea    (%rdx,%r9,1),%r8
 29d756d:	xor    %rdi,%rdi
 29d7570:	cmp    %rax,%r9
 29d7573:	cmova  %rdi,%r8
 29d7577:	mov    0x10(%r8),%r8d
 29d757b:	test   %r8d,%r8d
 29d757e:	je     29d86d3 <wasm[0]::function[1009]::helper::array_packed_join+0x1893>
 29d7584:	test   %r8d,%r8d
 29d7587:	je     29d86d5 <wasm[0]::function[1009]::helper::array_packed_join+0x1895>
 29d758d:	mov    %r8d,%r8d
 29d7590:	lea    0x10(%rdx,%r8,1),%rdx
 29d7595:	cmp    %rax,%r8
 29d7598:	cmova  %rdi,%rdx
 29d759c:	mov    (%rdx),%eax
 29d759e:	test   %r15,%r15
 29d75a1:	je     29d75b2 <wasm[0]::function[1009]::helper::array_packed_join+0x772>
 29d75a7:	mov    0xa8(%rsp),%rdx
 29d75af:	add    %rdx,%r14
 29d75b2:	mov    %eax,%eax
 29d75b4:	add    %rax,%r14
 29d75b7:	cmp    0x118a(%rip),%r14        # 29d8748 <wasm[0]::function[1009]::helper::array_packed_join+0x1908>
 29d75be:	jbe    29d75ce <wasm[0]::function[1009]::helper::array_packed_join+0x78e>
 29d75c4:	movabs $0x100000000,%r14
 29d75ce:	mov    0x38(%rsp),%edx
 29d75d2:	mov    0x10(%rsp),%eax
 29d75d6:	mov    (%rsp),%edi
 29d75d9:	add    $0x1,%r15
 29d75e0:	mov    %rsi,%r13
 29d75e3:	jmp    29d712b <wasm[0]::function[1009]::helper::array_packed_join+0x2eb>
 29d75e8:	cmp    0x1159(%rip),%r14        # 29d8748 <wasm[0]::function[1009]::helper::array_packed_join+0x1908>
 29d75ef:	ja     29d86d7 <wasm[0]::function[1009]::helper::array_packed_join+0x1897>
 29d75f5:	test   %r14,%r14
 29d75f8:	je     29d82fe <wasm[0]::function[1009]::helper::array_packed_join+0x14be>
 29d75fe:	mov    0x68(%rsp),%rcx
 29d7603:	cmp    $0x1,%rcx
 29d7607:	je     29d82f1 <wasm[0]::function[1009]::helper::array_packed_join+0x14b1>
 29d760d:	mov    %r14d,%r13d
 29d7610:	mov    %r13,%rcx
 29d7613:	shl    $1,%rcx
 29d7616:	mov    %rcx,%rax
 29d7619:	shr    $0x20,%rax
 29d761d:	mov    %rcx,0x70(%rsp)
 29d7622:	test   %rax,%rax
 29d7625:	jne    29d86d9 <wasm[0]::function[1009]::helper::array_packed_join+0x1899>
 29d762b:	mov    %r14,%rcx
 29d762e:	shl    $1,%ecx
 29d7630:	add    $0x14,%ecx
 29d7633:	jb     29d86db <wasm[0]::function[1009]::helper::array_packed_join+0x189b>
 29d7639:	mov    0x60(%rsp),%rsi
 29d763e:	mov    0x20(%rsi),%rdi
 29d7642:	mov    (%rdi),%eax
 29d7644:	mov    %eax,%edx
 29d7646:	mov    %ecx,%esi
 29d7648:	add    $0xf,%rsi
 29d764f:	mov    %rsi,%r8
 29d7652:	and    $0xfffffffffffffff0,%r8
 29d7656:	add    %rdx,%r8
 29d7659:	mov    0x4(%rdi),%r9d
 29d765d:	mov    %rdi,0xa0(%rsp)
 29d7665:	cmp    %r9,%r8
 29d7668:	ja     29d8429 <wasm[0]::function[1009]::helper::array_packed_join+0x15e9>
 29d766e:	mov    %r12,%rdi
 29d7671:	add    $0xf,%ecx
 29d7677:	and    $0xfffffff0,%ecx
 29d767a:	add    %eax,%ecx
 29d767c:	mov    0xa0(%rsp),%r15
 29d7684:	mov    %ecx,(%r15)
 29d7687:	mov    0xc8(%rsp),%r10
 29d768f:	mov    0x20(%r10),%r8
 29d7693:	lea    (%r8,%rdx,1),%rcx
 29d7697:	movl   $0xa8000006,(%r8,%rdx,1)
 29d769f:	mov    0x238(%rdi),%edi
 29d76a5:	mov    %edi,0x4(%r8,%rdx,1)
 29d76aa:	and    $0xfffffffffffffff0,%rsi
 29d76ae:	mov    %esi,0x8(%r8,%rdx,1)
 29d76b3:	mov    %eax,0x10(%rsp)
 29d76b7:	mov    %r14d,0x10(%rcx)
 29d76bb:	test   %eax,%eax
 29d76bd:	je     29d86dd <wasm[0]::function[1009]::helper::array_packed_join+0x189d>
 29d76c3:	mov    0xc8(%rsp),%r10
 29d76cb:	mov    0x28(%r10),%rsi
 29d76cf:	mov    0x20(%r10),%rdi
 29d76d3:	mov    %eax,%r8d
 29d76d6:	lea    0x10(%rdi,%r8,1),%r9
 29d76db:	xor    %r10,%r10
 29d76de:	cmp    %rsi,%r8
 29d76e1:	cmova  %r10,%r9
 29d76e5:	mov    (%r9),%r9d
 29d76e8:	cmp    %r9,%r13
 29d76eb:	ja     29d86df <wasm[0]::function[1009]::helper::array_packed_join+0x189f>
 29d76f1:	lea    0x14(%rdi,%r8,1),%r10
 29d76f6:	mov    0x70(%rsp),%r8
 29d76fb:	mov    %r10,%r9
 29d76fe:	add    %r8,%r9
 29d7701:	mov    %r10,%r12
 29d7704:	jb     29d86e1 <wasm[0]::function[1009]::helper::array_packed_join+0x18a1>
 29d770a:	lea    (%rdi,%rsi,1),%r10
 29d770e:	cmp    %r10,%r9
 29d7711:	ja     29d86e3 <wasm[0]::function[1009]::helper::array_packed_join+0x18a3>
 29d7717:	mov    0x38(%rsp),%esi
 29d771b:	mov    0x40(%rsp),%edx
 29d771f:	mov    0x8(%rsp),%ecx
 29d7723:	mov    (%rsp),%eax
 29d7726:	cmp    $0x8000000,%r8
 29d772d:	jbe    29d77b3 <wasm[0]::function[1009]::helper::array_packed_join+0x973>
 29d7733:	mov    %esi,0x18(%rsp)
 29d7737:	mov    %edx,0x30(%rsp)
 29d773b:	mov    %ecx,0x40(%rsp)
 29d773f:	mov    %eax,0x38(%rsp)
 29d7743:	mov    0xd0(%rsp),%r14
 29d774b:	mov    (%r14),%rax
 29d774e:	mov    0x88(%rsp),%rcx
 29d7756:	cmp    %rcx,%rax
 29d7759:	jae    29d845a <wasm[0]::function[1009]::helper::array_packed_join+0x161a>
 29d775f:	xor    %edx,%edx
 29d7761:	mov    $0x8000000,%ecx
 29d7766:	mov    %r12,%rsi
 29d7769:	mov    0x60(%rsp),%rdi
 29d776e:	call   3018b23 <wasmtime_builtin_memory_fill>
 29d7773:	mov    0x18(%rsp),%esi
 29d7777:	mov    0x30(%rsp),%edx
 29d777b:	mov    0x40(%rsp),%ecx
 29d777f:	mov    0x38(%rsp),%eax
 29d7783:	mov    0x70(%rsp),%rdi
 29d7788:	sub    $0x8000000,%rdi
 29d778f:	mov    %rdi,0x70(%rsp)
 29d7794:	mov    %r12,%rdi
 29d7797:	add    $0x8000000,%rdi
 29d779e:	mov    0x70(%rsp),%r8
 29d77a3:	mov    %rdi,%r12
 29d77a6:	cmp    $0x8000000,%r8
 29d77ad:	ja     29d7733 <wasm[0]::function[1009]::helper::array_packed_join+0x8f3>
 29d77b3:	mov    %esi,0x38(%rsp)
 29d77b7:	mov    %edx,0x40(%rsp)
 29d77bb:	mov    %ecx,0x30(%rsp)
 29d77bf:	mov    %eax,0x18(%rsp)
 29d77c3:	mov    0xd0(%rsp),%r14
 29d77cb:	mov    (%r14),%rax
 29d77ce:	mov    0x88(%rsp),%rsi
 29d77d6:	cmp    %rsi,%rax
 29d77d9:	jae    29d848e <wasm[0]::function[1009]::helper::array_packed_join+0x164e>
 29d77df:	xor    %ebx,%ebx
 29d77e1:	mov    0x70(%rsp),%rcx
 29d77e6:	mov    %r12,%rsi
 29d77e9:	mov    %rbx,%rdx
 29d77ec:	mov    0x60(%rsp),%rdi
 29d77f1:	call   3018b23 <wasmtime_builtin_memory_fill>
 29d77f6:	mov    %rbx,0x78(%rsp)
 29d77fb:	mov    0x10(%rsp),%ecx
 29d77ff:	mov    0x38(%rsp),%edx
 29d7803:	mov    0x40(%rsp),%eax
 29d7807:	mov    0x30(%rsp),%edi
 29d780b:	mov    0x18(%rsp),%esi
 29d780f:	xor    %r12,%r12
 29d7812:	mov    0xa8(%rsp),%r13
 29d781a:	mov    %r12,0x70(%rsp)
 29d781f:	shl    $1,%r13
 29d7822:	mov    %r13,0x98(%rsp)
 29d782a:	mov    %ecx,0x18(%rsp)
 29d782e:	mov    %edx,0x30(%rsp)
 29d7832:	mov    %eax,0x40(%rsp)
 29d7836:	mov    %edi,0x38(%rsp)
 29d783a:	mov    %esi,0x10(%rsp)
 29d783e:	mov    0xd0(%rsp),%r14
 29d7846:	mov    (%r14),%rax
 29d7849:	mov    0x88(%rsp),%rcx
 29d7851:	cmp    %rcx,%rax
 29d7854:	jae    29d84c5 <wasm[0]::function[1009]::helper::array_packed_join+0x1685>
 29d785a:	mov    0x68(%rsp),%rcx
 29d785f:	mov    0x70(%rsp),%r12
 29d7864:	jmp    29d7873 <wasm[0]::function[1009]::helper::array_packed_join+0xa33>
 29d7869:	mov    0x68(%rsp),%rcx
 29d786e:	mov    0x70(%rsp),%r12
 29d7873:	mov    0x68(%rsp),%rcx
 29d7878:	cmp    %rcx,%r12
 29d787b:	jae    29d8273 <wasm[0]::function[1009]::helper::array_packed_join+0x1433>
 29d7881:	mov    0x40(%rsp),%eax
 29d7885:	mov    0x38(%rsp),%edi
 29d7889:	mov    0x18(%rsp),%ecx
 29d788d:	mov    0x30(%rsp),%edx
 29d7891:	mov    0x10(%rsp),%esi
 29d7895:	mov    0x70(%rsp),%r8
 29d789a:	mov    0x70(%rsp),%r12
 29d789f:	test   %r8,%r12
 29d78a2:	je     29d7bed <wasm[0]::function[1009]::helper::array_packed_join+0xdad>
 29d78a8:	mov    0x18(%rsp),%eax
 29d78ac:	test   %eax,%eax
 29d78ae:	je     29d86e5 <wasm[0]::function[1009]::helper::array_packed_join+0x18a5>
 29d78b4:	mov    0x30(%rsp),%ecx
 29d78b8:	test   %ecx,%ecx
 29d78ba:	je     29d86e7 <wasm[0]::function[1009]::helper::array_packed_join+0x18a7>
 29d78c0:	test   %eax,%eax
 29d78c2:	je     29d86e9 <wasm[0]::function[1009]::helper::array_packed_join+0x18a9>
 29d78c8:	mov    0xc8(%rsp),%r10
 29d78d0:	mov    0x28(%r10),%rdi
 29d78d4:	mov    0x20(%r10),%rsi
 29d78d8:	mov    %eax,%r10d
 29d78db:	lea    (%rsi,%r10,1),%r8
 29d78df:	lea    0x10(%rsi,%r10,1),%rdx
 29d78e4:	xor    %r9,%r9
 29d78e7:	cmp    %rdi,%r10
 29d78ea:	cmova  %r9,%rdx
 29d78ee:	mov    0x78(%rsp),%r13
 29d78f3:	mov    %r13d,%r11d
 29d78f6:	mov    0xa8(%rsp),%rax
 29d78fe:	lea    (%r11,%rax,1),%r10
 29d7902:	mov    (%rdx),%eax
 29d7904:	cmp    %rax,%r10
 29d7907:	ja     29d86eb <wasm[0]::function[1009]::helper::array_packed_join+0x18ab>
 29d790d:	test   %ecx,%ecx
 29d790f:	je     29d86ed <wasm[0]::function[1009]::helper::array_packed_join+0x18ad>
 29d7915:	mov    %ecx,%eax
 29d7917:	lea    (%rsi,%rax,1),%r10
 29d791b:	lea    0x10(%rsi,%rax,1),%rcx
 29d7920:	cmp    %rdi,%rax
 29d7923:	cmova  %r9,%rcx
 29d7927:	mov    (%rcx),%ecx
 29d7929:	mov    0xa8(%rsp),%r9
 29d7931:	cmp    %rcx,%r9
 29d7934:	ja     29d86ef <wasm[0]::function[1009]::helper::array_packed_join+0x18af>
 29d793a:	lea    0x14(%r8,%r11,2),%r8
 29d793f:	mov    0x98(%rsp),%r11
 29d7947:	mov    %r8,%rdx
 29d794a:	add    %r11,%rdx
 29d794d:	jb     29d86f1 <wasm[0]::function[1009]::helper::array_packed_join+0x18b1>
 29d7953:	lea    (%rsi,%rdi,1),%rcx
 29d7957:	cmp    %rcx,%rdx
 29d795a:	ja     29d86f3 <wasm[0]::function[1009]::helper::array_packed_join+0x18b3>
 29d7960:	lea    0x14(%rsi,%rax,1),%r9
 29d7965:	mov    0x98(%rsp),%rdx
 29d796d:	mov    %r9,%rax
 29d7970:	add    %rdx,%rax
 29d7973:	jb     29d86f5 <wasm[0]::function[1009]::helper::array_packed_join+0x18b5>
 29d7979:	cmp    %rcx,%rax
 29d797c:	ja     29d86f7 <wasm[0]::function[1009]::helper::array_packed_join+0x18b7>
 29d7982:	cmp    %r8,%r9
 29d7985:	ja     29d7a96 <wasm[0]::function[1009]::helper::array_packed_join+0xc56>
 29d798b:	mov    0x40(%rsp),%eax
 29d798f:	mov    0x38(%rsp),%ecx
 29d7993:	mov    0x18(%rsp),%edx
 29d7997:	mov    0x30(%rsp),%esi
 29d799b:	mov    0x10(%rsp),%edi
 29d799f:	mov    0xa8(%rsp),%r9
 29d79a7:	lea    (%r8,%r9,2),%r8
 29d79ab:	mov    %r8,%rbx
 29d79ae:	mov    0xa8(%rsp),%r8
 29d79b6:	lea    0x14(%r10,%r8,2),%r9
 29d79bb:	mov    0x98(%rsp),%r8
 29d79c3:	mov    %r9,%r12
 29d79c6:	cmp    $0x8000000,%r8
 29d79cd:	jbe    29d79e0 <wasm[0]::function[1009]::helper::array_packed_join+0xba0>
 29d79d3:	mov    0x98(%rsp),%r15
 29d79db:	jmp    29d79f0 <wasm[0]::function[1009]::helper::array_packed_join+0xbb0>
 29d79e0:	mov    0x98(%rsp),%r8
 29d79e8:	mov    %rbx,%r9
 29d79eb:	jmp    29d7a7f <wasm[0]::function[1009]::helper::array_packed_join+0xc3f>
 29d79f0:	mov    %eax,0x28(%rsp)
 29d79f4:	mov    %ecx,0x20(%rsp)
 29d79f8:	mov    %edx,0x48(%rsp)
 29d79fc:	mov    %esi,0x50(%rsp)
 29d7a00:	mov    %edi,0x58(%rsp)
 29d7a04:	mov    0xd0(%rsp),%r14
 29d7a0c:	mov    (%r14),%rax
 29d7a0f:	mov    0x88(%rsp),%rcx
 29d7a17:	cmp    %rcx,%rax
 29d7a1a:	jae    29d8503 <wasm[0]::function[1009]::helper::array_packed_join+0x16c3>
 29d7a20:	mov    $0x8000000,%ecx
 29d7a25:	mov    %rbx,%rsi
 29d7a28:	sub    $0x8000000,%rsi
 29d7a2f:	mov    %r12,%rdx
 29d7a32:	mov    %rsi,%rbx
 29d7a35:	sub    $0x8000000,%rdx
 29d7a3c:	mov    %rdx,%r12
 29d7a3f:	mov    0x60(%rsp),%rdi
 29d7a44:	call   3018afa <wasmtime_builtin_memory_copy>
 29d7a49:	mov    0x28(%rsp),%eax
 29d7a4d:	mov    0x20(%rsp),%ecx
 29d7a51:	mov    0x48(%rsp),%edx
 29d7a55:	mov    0x50(%rsp),%esi
 29d7a59:	mov    0x58(%rsp),%edi
 29d7a5d:	mov    %r15,%r8
 29d7a60:	sub    $0x8000000,%r8
 29d7a67:	cmp    $0x8000000,%r8
 29d7a6e:	jbe    29d7a7c <wasm[0]::function[1009]::helper::array_packed_join+0xc3c>
 29d7a74:	mov    %r8,%r15
 29d7a77:	jmp    29d79f0 <wasm[0]::function[1009]::helper::array_packed_join+0xbb0>
 29d7a7c:	mov    %rbx,%r9
 29d7a7f:	sub    %r8,%r9
 29d7a82:	mov    %r9,%rbx
 29d7a85:	mov    %r12,%r9
 29d7a88:	sub    %r8,%r9
 29d7a8b:	mov    %r9,%r12
 29d7a8e:	mov    %r8,%r15
 29d7a91:	jmp    29d7b6f <wasm[0]::function[1009]::helper::array_packed_join+0xd2f>
 29d7a96:	mov    %r8,%rbx
 29d7a99:	mov    %r9,%r12
 29d7a9c:	mov    0x40(%rsp),%eax
 29d7aa0:	mov    0x38(%rsp),%ecx
 29d7aa4:	mov    0x18(%rsp),%edx
 29d7aa8:	mov    0x30(%rsp),%esi
 29d7aac:	mov    0x10(%rsp),%edi
 29d7ab0:	mov    0x98(%rsp),%r8
 29d7ab8:	cmp    $0x8000000,%r8
 29d7abf:	jbe    29d7ad2 <wasm[0]::function[1009]::helper::array_packed_join+0xc92>
 29d7ac5:	mov    0x98(%rsp),%r15
 29d7acd:	jmp    29d7adf <wasm[0]::function[1009]::helper::array_packed_join+0xc9f>
 29d7ad2:	mov    0x98(%rsp),%r15
 29d7ada:	jmp    29d7b6f <wasm[0]::function[1009]::helper::array_packed_join+0xd2f>
 29d7adf:	mov    %eax,0x20(%rsp)
 29d7ae3:	mov    %ecx,0x28(%rsp)
 29d7ae7:	mov    %edx,0x30(%rsp)
 29d7aeb:	mov    %esi,0x38(%rsp)
 29d7aef:	mov    %edi,0x40(%rsp)
 29d7af3:	mov    0xd0(%rsp),%r14
 29d7afb:	mov    (%r14),%rax
 29d7afe:	mov    0x88(%rsp),%rcx
 29d7b06:	cmp    %rcx,%rax
 29d7b09:	jae    29d8537 <wasm[0]::function[1009]::helper::array_packed_join+0x16f7>
 29d7b0f:	mov    $0x8000000,%ecx
 29d7b14:	mov    %r12,%rdx
 29d7b17:	mov    %rbx,%rsi
 29d7b1a:	mov    0x60(%rsp),%rdi
 29d7b1f:	call   3018afa <wasmtime_builtin_memory_copy>
 29d7b24:	mov    0x20(%rsp),%eax
 29d7b28:	mov    0x28(%rsp),%ecx
 29d7b2c:	mov    0x30(%rsp),%edx
 29d7b30:	mov    0x38(%rsp),%esi
 29d7b34:	mov    0x40(%rsp),%edi
 29d7b38:	mov    %r15,%r8
 29d7b3b:	sub    $0x8000000,%r8
 29d7b42:	mov    %r8,%r15
 29d7b45:	mov    %rbx,%r8
 29d7b48:	add    $0x8000000,%r8
 29d7b4f:	mov    %r8,%rbx
 29d7b52:	mov    %r12,%r8
 29d7b55:	add    $0x8000000,%r8
 29d7b5c:	mov    %r8,%r12
 29d7b5f:	mov    %r15,%r8
 29d7b62:	cmp    $0x8000000,%r8
 29d7b69:	ja     29d7adf <wasm[0]::function[1009]::helper::array_packed_join+0xc9f>
 29d7b6f:	mov    %eax,0x40(%rsp)
 29d7b73:	mov    %ecx,0x38(%rsp)
 29d7b77:	mov    %edx,0x30(%rsp)
 29d7b7b:	mov    %esi,0x28(%rsp)
 29d7b7f:	mov    %edi,0x20(%rsp)
 29d7b83:	mov    0xd0(%rsp),%r14
 29d7b8b:	mov    (%r14),%rsi
 29d7b8e:	mov    0x88(%rsp),%rax
 29d7b96:	cmp    %rax,%rsi
 29d7b99:	jae    29d856b <wasm[0]::function[1009]::helper::array_packed_join+0x172b>
 29d7b9f:	mov    %r15,%rcx
 29d7ba2:	mov    %r12,%rdx
 29d7ba5:	mov    %rbx,%rsi
 29d7ba8:	jmp    29d7bb6 <wasm[0]::function[1009]::helper::array_packed_join+0xd76>
 29d7bad:	mov    %r15,%rcx
 29d7bb0:	mov    %r12,%rdx
 29d7bb3:	mov    %rbx,%rsi
 29d7bb6:	mov    %r15,%rcx
 29d7bb9:	mov    %r12,%rdx
 29d7bbc:	mov    %rbx,%rsi
 29d7bbf:	mov    0x60(%rsp),%rdi
 29d7bc4:	call   3018afa <wasmtime_builtin_memory_copy>
 29d7bc9:	mov    0x40(%rsp),%eax
 29d7bcd:	mov    0x38(%rsp),%edi
 29d7bd1:	mov    0x30(%rsp),%ecx
 29d7bd5:	mov    0x28(%rsp),%edx
 29d7bd9:	mov    0x20(%rsp),%esi
 29d7bdd:	mov    0xc0(%rsp),%r8
 29d7be5:	add    %r8d,%r13d
 29d7be8:	mov    %r13,0x78(%rsp)
 29d7bed:	test   %eax,%eax
 29d7bef:	je     29d86f9 <wasm[0]::function[1009]::helper::array_packed_join+0x18b9>
 29d7bf5:	test   %eax,%eax
 29d7bf7:	je     29d86fb <wasm[0]::function[1009]::helper::array_packed_join+0x18bb>
 29d7bfd:	mov    0xc8(%rsp),%r10
 29d7c05:	mov    0x28(%r10),%r9
 29d7c09:	mov    %eax,%r8d
 29d7c0c:	mov    0xc8(%rsp),%r11
 29d7c14:	mov    %r8,%r10
 29d7c17:	add    0x20(%r11),%r10
 29d7c1b:	xor    %r11,%r11
 29d7c1e:	cmp    %r9,%r8
 29d7c21:	cmova  %r11,%r10
 29d7c25:	mov    0x24(%r10),%r9d
 29d7c29:	cmp    $0x3,%r9d
 29d7c2d:	je     29d7dd2 <wasm[0]::function[1009]::helper::array_packed_join+0xf92>
 29d7c33:	mov    0xc8(%rsp),%r10
 29d7c3b:	mov    0x28(%r10),%r11
 29d7c3f:	mov    0x20(%r10),%r13
 29d7c43:	lea    0x0(%r13,%r8,1),%r9
 29d7c48:	xor    %rbx,%rbx
 29d7c4b:	cmp    %r11,%r8
 29d7c4e:	cmova  %rbx,%r9
 29d7c52:	mov    0x28(%r9),%r8d
 29d7c56:	mov    0x2c(%r9),%r10d
 29d7c5a:	test   %r8d,%r8d
 29d7c5d:	je     29d86fd <wasm[0]::function[1009]::helper::array_packed_join+0x18bd>
 29d7c63:	test   %r8d,%r8d
 29d7c66:	je     29d86ff <wasm[0]::function[1009]::helper::array_packed_join+0x18bf>
 29d7c6c:	mov    %r8d,%r9d
 29d7c6f:	lea    0x10(%r13,%r9,1),%r13
 29d7c74:	cmp    %r11,%r9
 29d7c77:	cmova  %rbx,%r13
 29d7c7b:	mov    0x0(%r13),%r11d
 29d7c7f:	mov    0x70(%rsp),%r12
 29d7c84:	cmp    %r11,%r12
 29d7c87:	jae    29d7dc5 <wasm[0]::function[1009]::helper::array_packed_join+0xf85>
 29d7c8d:	test   %r10d,%r10d
 29d7c90:	je     29d8701 <wasm[0]::function[1009]::helper::array_packed_join+0x18c1>
 29d7c96:	test   %r10d,%r10d
 29d7c99:	je     29d8703 <wasm[0]::function[1009]::helper::array_packed_join+0x18c3>
 29d7c9f:	mov    0xc8(%rsp),%r11
 29d7ca7:	mov    0x28(%r11),%r11
 29d7cab:	mov    0xc8(%rsp),%r14
 29d7cb3:	mov    0x20(%r14),%r13
 29d7cb7:	mov    %r10d,%r14d
 29d7cba:	lea    0x10(%r13,%r14,1),%rbx
 29d7cbf:	xor    %r15,%r15
 29d7cc2:	cmp    %r11,%r14
 29d7cc5:	cmova  %r15,%rbx
 29d7cc9:	mov    (%rbx),%ebx
 29d7ccb:	mov    0x70(%rsp),%r12
 29d7cd0:	mov    %r12,%r14
 29d7cd3:	shr    $0x6,%r14d
 29d7cd7:	cmp    %ebx,%r14d
 29d7cda:	jae    29d8705 <wasm[0]::function[1009]::helper::array_packed_join+0x18c5>
 29d7ce0:	mov    %ebx,%r12d
 29d7ce3:	shl    $0x3,%r12
 29d7ce7:	shr    $0x20,%r12
 29d7ceb:	test   %r12,%r12
 29d7cee:	jne    29d8707 <wasm[0]::function[1009]::helper::array_packed_join+0x18c7>
 29d7cf4:	shl    $0x3,%ebx
 29d7cf7:	add    $0x18,%ebx
 29d7cfa:	jb     29d8709 <wasm[0]::function[1009]::helper::array_packed_join+0x18c9>
 29d7d00:	add    %ebx,%r10d
 29d7d03:	jb     29d870b <wasm[0]::function[1009]::helper::array_packed_join+0x18cb>
 29d7d09:	mov    %r10d,%r12d
 29d7d0c:	lea    0x0(%r13,%r12,1),%r10
 29d7d11:	cmp    %r11,%r12
 29d7d14:	cmova  %r15,%r10
 29d7d18:	shl    $0x3,%r14d
 29d7d1c:	lea    0x18(%r14),%r11d
 29d7d20:	sub    %r11d,%ebx
 29d7d23:	sub    %rbx,%r10
 29d7d26:	mov    (%r10),%r10
 29d7d29:	mov    0x70(%rsp),%r12
 29d7d2e:	bt     %r12,%r10
 29d7d32:	jae    29d7dc5 <wasm[0]::function[1009]::helper::array_packed_join+0xf85>
 29d7d38:	mov    0xc8(%rsp),%r10
 29d7d40:	mov    0x28(%r10),%rdi
 29d7d44:	mov    0x20(%r10),%r11
 29d7d48:	lea    0x10(%r11,%r9,1),%rbx
 29d7d4d:	xor    %r10,%r10
 29d7d50:	cmp    %rdi,%r9
 29d7d53:	cmova  %r10,%rbx
 29d7d57:	mov    (%rbx),%r9d
 29d7d5a:	mov    0x70(%rsp),%r12
 29d7d5f:	cmp    %r9d,%r12d
 29d7d62:	jae    29d870d <wasm[0]::function[1009]::helper::array_packed_join+0x18cd>
 29d7d68:	mov    %r9d,%ebx
 29d7d6b:	shl    $0x3,%rbx
 29d7d6f:	shr    $0x20,%rbx
 29d7d73:	test   %rbx,%rbx
 29d7d76:	jne    29d870f <wasm[0]::function[1009]::helper::array_packed_join+0x18cf>
 29d7d7c:	mov    $0x3,%ebx
 29d7d81:	mov    %rbx,0x80(%rsp)
 29d7d89:	shl    $0x3,%r9d
 29d7d8d:	add    $0x18,%r9d
 29d7d91:	jb     29d8711 <wasm[0]::function[1009]::helper::array_packed_join+0x18d1>
 29d7d97:	add    %r9d,%r8d
 29d7d9a:	jb     29d8713 <wasm[0]::function[1009]::helper::array_packed_join+0x18d3>
 29d7da0:	mov    %r8d,%ebx
 29d7da3:	lea    (%r11,%rbx,1),%r8
 29d7da7:	cmp    %rdi,%rbx
 29d7daa:	cmova  %r10,%r8
 29d7dae:	mov    %r12,%rdi
 29d7db1:	shl    $0x3,%edi
 29d7db4:	add    $0x18,%edi
 29d7dba:	sub    %edi,%r9d
 29d7dbd:	sub    %r9,%r8
 29d7dc0:	mov    (%r8),%rdi
 29d7dc3:	xor    %edi,%edi
 29d7dc5:	mov    0x80(%rsp),%r8
 29d7dcd:	jmp    29d7f01 <wasm[0]::function[1009]::helper::array_packed_join+0x10c1>
 29d7dd2:	mov    0xc8(%rsp),%r10
 29d7dda:	mov    0x28(%r10),%r9
 29d7dde:	mov    0x20(%r10),%r11
 29d7de2:	lea    (%r11,%r8,1),%rbx
 29d7de6:	xor    %r10,%r10
 29d7de9:	cmp    %r9,%r8
 29d7dec:	cmova  %r10,%rbx
 29d7df0:	mov    0x30(%rbx),%r8d
 29d7df4:	test   %r8d,%r8d
 29d7df7:	je     29d8715 <wasm[0]::function[1009]::helper::array_packed_join+0x18d5>
 29d7dfd:	test   %r8d,%r8d
 29d7e00:	je     29d8717 <wasm[0]::function[1009]::helper::array_packed_join+0x18d7>
 29d7e06:	mov    %r8d,%r13d
 29d7e09:	lea    0x10(%r11,%r13,1),%r11
 29d7e0e:	cmp    %r9,%r13
 29d7e11:	cmova  %r10,%r11
 29d7e15:	mov    (%r11),%r9d
 29d7e18:	mov    0x70(%rsp),%r12
 29d7e1d:	cmp    %r9,%r12
 29d7e20:	jae    29d7ef9 <wasm[0]::function[1009]::helper::array_packed_join+0x10b9>
 29d7e26:	mov    0xc8(%rsp),%r10
 29d7e2e:	mov    0x28(%r10),%r9
 29d7e32:	mov    0x20(%r10),%rbx
 29d7e36:	lea    0x10(%rbx,%r13,1),%r11
 29d7e3b:	xor    %r10,%r10
 29d7e3e:	cmp    %r9,%r13
 29d7e41:	cmova  %r10,%r11
 29d7e45:	mov    (%r11),%r11d
 29d7e48:	mov    0x70(%rsp),%r12
 29d7e4d:	cmp    %r11d,%r12d
 29d7e50:	jae    29d8719 <wasm[0]::function[1009]::helper::array_packed_join+0x18d9>
 29d7e56:	mov    %r11d,%r12d
 29d7e59:	shl    $0x2,%r12
 29d7e5d:	shr    $0x20,%r12
 29d7e61:	test   %r12,%r12
 29d7e64:	jne    29d871b <wasm[0]::function[1009]::helper::array_packed_join+0x18db>
 29d7e6a:	shl    $0x2,%r11d
 29d7e6e:	add    $0x14,%r11d
 29d7e72:	jb     29d871d <wasm[0]::function[1009]::helper::array_packed_join+0x18dd>
 29d7e78:	add    %r11d,%r8d
 29d7e7b:	jb     29d871f <wasm[0]::function[1009]::helper::array_packed_join+0x18df>
 29d7e81:	mov    %r8d,%r12d
 29d7e84:	lea    (%rbx,%r12,1),%r8
 29d7e88:	cmp    %r9,%r12
 29d7e8b:	cmova  %r10,%r8
 29d7e8f:	mov    0x70(%rsp),%r12
 29d7e94:	mov    %r12,%r9
 29d7e97:	shl    $0x2,%r9d
 29d7e9b:	add    $0x14,%r9d
 29d7ea2:	sub    %r9d,%r11d
 29d7ea5:	sub    %r11,%r8
 29d7ea8:	mov    (%r8),%r11d
 29d7eab:	test   %r11d,%r11d
 29d7eae:	je     29d7ef9 <wasm[0]::function[1009]::helper::array_packed_join+0x10b9>
 29d7eb4:	test   %r11d,%r11d
 29d7eb7:	je     29d8721 <wasm[0]::function[1009]::helper::array_packed_join+0x18e1>
 29d7ebd:	test   %r11d,%r11d
 29d7ec0:	je     29d8723 <wasm[0]::function[1009]::helper::array_packed_join+0x18e3>
 29d7ec6:	mov    0xc8(%rsp),%r10
 29d7ece:	mov    0x28(%r10),%r8
 29d7ed2:	mov    0x20(%r10),%rdi
 29d7ed6:	mov    %r11d,%r9d
 29d7ed9:	add    %r9,%rdi
 29d7edc:	xor    %r10,%r10
 29d7edf:	cmp    %r8,%r9
 29d7ee2:	cmova  %r10,%rdi
 29d7ee6:	mov    0x18(%rdi),%r8d
 29d7eea:	mov    %r8,0x80(%rsp)
 29d7ef2:	mov    0x10(%rdi),%r8
 29d7ef6:	mov    0x1c(%rdi),%edi
 29d7ef9:	mov    0x80(%rsp),%r8
 29d7f01:	cmp    $0x4,%r8d
 29d7f05:	je     29d7f15 <wasm[0]::function[1009]::helper::array_packed_join+0x10d5>
 29d7f0b:	mov    0x70(%rsp),%r12
 29d7f10:	jmp    29d8262 <wasm[0]::function[1009]::helper::array_packed_join+0x1422>
 29d7f15:	xor    %r8d,%r8d
 29d7f18:	test   %edi,%edi
 29d7f1a:	je     29d7f67 <wasm[0]::function[1009]::helper::array_packed_join+0x1127>
 29d7f20:	xor    %r8d,%r8d
 29d7f23:	test   $0x1,%edi
 29d7f29:	jne    29d7f67 <wasm[0]::function[1009]::helper::array_packed_join+0x1127>
 29d7f2f:	mov    0xc8(%rsp),%r10
 29d7f37:	mov    0x28(%r10),%r8
 29d7f3b:	mov    0x20(%r10),%r9
 29d7f3f:	mov    %edi,%r10d
 29d7f42:	lea    0x4(%r9,%r10,1),%r9
 29d7f47:	xor    %r11,%r11
 29d7f4a:	cmp    %r8,%r10
 29d7f4d:	cmova  %r11,%r9
 29d7f51:	mov    (%r9),%r8d
 29d7f54:	mov    0xb0(%rsp),%r9
 29d7f5c:	cmp    %r9d,%r8d
 29d7f5f:	sete   %r8b
 29d7f63:	movzbl %r8b,%r8d
 29d7f67:	test   %r8d,%r8d
 29d7f6a:	je     29d8725 <wasm[0]::function[1009]::helper::array_packed_join+0x18e5>
 29d7f70:	test   %edi,%edi
 29d7f72:	je     29d8727 <wasm[0]::function[1009]::helper::array_packed_join+0x18e7>
 29d7f78:	test   %edi,%edi
 29d7f7a:	je     29d8729 <wasm[0]::function[1009]::helper::array_packed_join+0x18e9>
 29d7f80:	mov    0xc8(%rsp),%r10
 29d7f88:	mov    0x28(%r10),%r9
 29d7f8c:	mov    0x20(%r10),%r8
 29d7f90:	mov    %edi,%r11d
 29d7f93:	lea    (%r8,%r11,1),%r10
 29d7f97:	xor    %r13,%r13
 29d7f9a:	cmp    %r9,%r11
 29d7f9d:	cmova  %r13,%r10
 29d7fa1:	mov    0x10(%r10),%r10d
 29d7fa5:	test   %r10d,%r10d
 29d7fa8:	je     29d872b <wasm[0]::function[1009]::helper::array_packed_join+0x18eb>
 29d7fae:	test   %r10d,%r10d
 29d7fb1:	je     29d872d <wasm[0]::function[1009]::helper::array_packed_join+0x18ed>
 29d7fb7:	mov    %r10d,%r11d
 29d7fba:	lea    (%r8,%r11,1),%r10
 29d7fbe:	lea    0x10(%r8,%r11,1),%rbx
 29d7fc3:	cmp    %r9,%r11
 29d7fc6:	cmova  %r13,%rbx
 29d7fca:	mov    (%rbx),%r15d
 29d7fcd:	mov    %r15,0x90(%rsp)
 29d7fd5:	test   %ecx,%ecx
 29d7fd7:	je     29d872f <wasm[0]::function[1009]::helper::array_packed_join+0x18ef>
 29d7fdd:	test   %ecx,%ecx
 29d7fdf:	je     29d8731 <wasm[0]::function[1009]::helper::array_packed_join+0x18f1>
 29d7fe5:	mov    %ecx,%ebx
 29d7fe7:	lea    (%r8,%rbx,1),%r14
 29d7feb:	lea    0x10(%r8,%rbx,1),%r15
 29d7ff0:	cmp    %r9,%rbx
 29d7ff3:	cmova  %r13,%r15
 29d7ff7:	mov    0x78(%rsp),%r12
 29d7ffc:	mov    %r12d,%r13d
 29d7fff:	mov    0x90(%rsp),%r12
 29d8007:	mov    %r12d,%ebx
 29d800a:	lea    0x0(%r13,%rbx,1),%r12
 29d800f:	mov    (%r15),%r15d
 29d8012:	cmp    %r15,%r12
 29d8015:	ja     29d8733 <wasm[0]::function[1009]::helper::array_packed_join+0x18f3>
 29d801b:	lea    0x14(%r14,%r13,2),%r15
 29d8020:	mov    %rbx,%r14
 29d8023:	shl    $1,%r14
 29d8026:	mov    %r15,%r12
 29d8029:	add    %r14,%r12
 29d802c:	jb     29d8735 <wasm[0]::function[1009]::helper::array_packed_join+0x18f5>
 29d8032:	add    %r8,%r9
 29d8035:	cmp    %r9,%r12
 29d8038:	ja     29d8737 <wasm[0]::function[1009]::helper::array_packed_join+0x18f7>
 29d803e:	lea    0x14(%r8,%r11,1),%r8
 29d8043:	mov    %r8,%r11
 29d8046:	add    %r14,%r11
 29d8049:	jb     29d8739 <wasm[0]::function[1009]::helper::array_packed_join+0x18f9>
 29d804f:	cmp    %r9,%r11
 29d8052:	ja     29d873b <wasm[0]::function[1009]::helper::array_packed_join+0x18fb>
 29d8058:	cmp    %r15,%r8
 29d805b:	ja     29d8131 <wasm[0]::function[1009]::helper::array_packed_join+0x12f1>
 29d8061:	lea    (%r15,%rbx,2),%r15
 29d8065:	mov    %r15,%r12
 29d8068:	lea    0x14(%r10,%rbx,2),%r8
 29d806d:	mov    %r8,%r13
 29d8070:	cmp    $0x8000000,%r14
 29d8077:	mov    %r14,%rbx
 29d807a:	ja     29d808b <wasm[0]::function[1009]::helper::array_packed_join+0x124b>
 29d8080:	mov    %r12,%r8
 29d8083:	mov    %rbx,%r11
 29d8086:	jmp    29d811a <wasm[0]::function[1009]::helper::array_packed_join+0x12da>
 29d808b:	mov    %ecx,0x20(%rsp)
 29d808f:	mov    %edx,0x28(%rsp)
 29d8093:	mov    %eax,0x30(%rsp)
 29d8097:	mov    %edi,0x38(%rsp)
 29d809b:	mov    %esi,0x40(%rsp)
 29d809f:	mov    0xd0(%rsp),%r14
 29d80a7:	mov    (%r14),%rdi
 29d80aa:	mov    0x88(%rsp),%rax
 29d80b2:	cmp    %rax,%rdi
 29d80b5:	jae    29d85a8 <wasm[0]::function[1009]::helper::array_packed_join+0x1768>
 29d80bb:	mov    $0x8000000,%ecx
 29d80c0:	mov    %r12,%rsi
 29d80c3:	sub    $0x8000000,%rsi
 29d80ca:	mov    %r13,%rdx
 29d80cd:	mov    %rsi,%r12
 29d80d0:	sub    $0x8000000,%rdx
 29d80d7:	mov    %rdx,%r13
 29d80da:	mov    0x60(%rsp),%rdi
 29d80df:	call   3018afa <wasmtime_builtin_memory_copy>
 29d80e4:	mov    0x20(%rsp),%ecx
 29d80e8:	mov    0x28(%rsp),%edx
 29d80ec:	mov    0x30(%rsp),%eax
 29d80f0:	mov    0x38(%rsp),%edi
 29d80f4:	mov    0x40(%rsp),%esi
 29d80f8:	mov    %rbx,%r11
 29d80fb:	sub    $0x8000000,%r11
 29d8102:	cmp    $0x8000000,%r11
 29d8109:	jbe    29d8117 <wasm[0]::function[1009]::helper::array_packed_join+0x12d7>
 29d810f:	mov    %r11,%rbx
 29d8112:	jmp    29d808b <wasm[0]::function[1009]::helper::array_packed_join+0x124b>
 29d8117:	mov    %r12,%r8
 29d811a:	sub    %r11,%r8
 29d811d:	mov    %r8,%r12
 29d8120:	mov    %r13,%r8
 29d8123:	sub    %r11,%r8
 29d8126:	mov    %r8,%r13
 29d8129:	mov    %r11,%rbx
 29d812c:	jmp    29d81da <wasm[0]::function[1009]::helper::array_packed_join+0x139a>
 29d8131:	mov    %r14,%r11
 29d8134:	mov    %r15,%r12
 29d8137:	mov    %r8,%r13
 29d813a:	cmp    $0x8000000,%r11
 29d8141:	mov    %r11,%rbx
 29d8144:	jbe    29d81da <wasm[0]::function[1009]::helper::array_packed_join+0x139a>
 29d814a:	mov    %ecx,0x40(%rsp)
 29d814e:	mov    %edx,0x38(%rsp)
 29d8152:	mov    %eax,0x30(%rsp)
 29d8156:	mov    %edi,0x28(%rsp)
 29d815a:	mov    %esi,0x20(%rsp)
 29d815e:	mov    0xd0(%rsp),%r14
 29d8166:	mov    (%r14),%rax
 29d8169:	mov    0x88(%rsp),%rcx
 29d8171:	cmp    %rcx,%rax
 29d8174:	jae    29d85dc <wasm[0]::function[1009]::helper::array_packed_join+0x179c>
 29d817a:	mov    $0x8000000,%ecx
 29d817f:	mov    %r13,%rdx
 29d8182:	mov    %r12,%rsi
 29d8185:	mov    0x60(%rsp),%rdi
 29d818a:	call   3018afa <wasmtime_builtin_memory_copy>
 29d818f:	mov    0x40(%rsp),%ecx
 29d8193:	mov    0x38(%rsp),%edx
 29d8197:	mov    0x30(%rsp),%eax
 29d819b:	mov    0x28(%rsp),%edi
 29d819f:	mov    0x20(%rsp),%esi
 29d81a3:	mov    %rbx,%r8
 29d81a6:	sub    $0x8000000,%r8
 29d81ad:	mov    %r8,%rbx
 29d81b0:	mov    %r12,%r8
 29d81b3:	add    $0x8000000,%r8
 29d81ba:	mov    %r8,%r12
 29d81bd:	mov    %r13,%r8
 29d81c0:	lea    0x8000000(%r8),%r9
 29d81c7:	mov    %rbx,%r8
 29d81ca:	mov    %r9,%r13
 29d81cd:	cmp    $0x8000000,%r8
 29d81d4:	ja     29d814a <wasm[0]::function[1009]::helper::array_packed_join+0x130a>
 29d81da:	mov    %ecx,0x20(%rsp)
 29d81de:	mov    %edx,0x28(%rsp)
 29d81e2:	mov    %eax,0x30(%rsp)
 29d81e6:	mov    %edi,0x38(%rsp)
 29d81ea:	mov    %esi,0x40(%rsp)
 29d81ee:	mov    0xd0(%rsp),%r14
 29d81f6:	mov    (%r14),%rax
 29d81f9:	mov    0x88(%rsp),%rcx
 29d8201:	cmp    %rcx,%rax
 29d8204:	jae    29d8610 <wasm[0]::function[1009]::helper::array_packed_join+0x17d0>
 29d820a:	mov    %rbx,%rcx
 29d820d:	mov    %r13,%rdx
 29d8210:	mov    %r12,%rsi
 29d8213:	jmp    29d8221 <wasm[0]::function[1009]::helper::array_packed_join+0x13e1>
 29d8218:	mov    %rbx,%rcx
 29d821b:	mov    %r13,%rdx
 29d821e:	mov    %r12,%rsi
 29d8221:	mov    %rbx,%rcx
 29d8224:	mov    %r13,%rdx
 29d8227:	mov    %r12,%rsi
 29d822a:	mov    0x60(%rsp),%rdi
 29d822f:	call   3018afa <wasmtime_builtin_memory_copy>
 29d8234:	mov    0x20(%rsp),%ecx
 29d8238:	mov    0x28(%rsp),%edx
 29d823c:	mov    0x30(%rsp),%eax
 29d8240:	mov    0x38(%rsp),%edi
 29d8244:	mov    0x40(%rsp),%esi
 29d8248:	mov    0x78(%rsp),%r12
 29d824d:	mov    0x90(%rsp),%r15
 29d8255:	add    %r15d,%r12d
 29d8258:	mov    %r12,0x78(%rsp)
 29d825d:	mov    0x70(%rsp),%r12
 29d8262:	add    $0x1,%r12
 29d8269:	mov    %r12,0x70(%rsp)
 29d826e:	jmp    29d782a <wasm[0]::function[1009]::helper::array_packed_join+0x9ea>
 29d8273:	mov    0x18(%rsp),%eax
 29d8277:	test   %eax,%eax
 29d8279:	je     29d873d <wasm[0]::function[1009]::helper::array_packed_join+0x18fd>
 29d827f:	mov    0xa0(%rsp),%r15
 29d8287:	mov    (%r15),%eax
 29d828a:	mov    %eax,%ecx
 29d828c:	lea    0x20(%rcx),%rdx
 29d8290:	mov    0x4(%r15),%esi
 29d8294:	cmp    %rsi,%rdx
 29d8297:	ja     29d8650 <wasm[0]::function[1009]::helper::array_packed_join+0x1810>
 29d829d:	lea    0x20(%rax),%edx
 29d82a0:	mov    %edx,(%r15)
 29d82a3:	mov    0xc8(%rsp),%r10
 29d82ab:	mov    0x20(%r10),%rsi
 29d82af:	lea    (%rsi,%rcx,1),%rdx
 29d82b3:	movl   $0xb000000a,(%rsi,%rcx,1)
 29d82ba:	mov    0xb0(%rsp),%r11
 29d82c2:	mov    %r11d,0x4(%rsi,%rcx,1)
 29d82c7:	mov    $0x20,%edi
 29d82cc:	mov    %edi,0x8(%rsi,%rcx,1)
 29d82d0:	mov    0x18(%rsp),%esi
 29d82d4:	mov    %esi,0x10(%rdx)
 29d82d7:	movq   $0x0,0x18(%rdx)
 29d82df:	test   %eax,%eax
 29d82e1:	je     29d873f <wasm[0]::function[1009]::helper::array_packed_join+0x18ff>
 29d82e7:	mov    0x10(%rsp),%r8d
 29d82ec:	jmp    29d831b <wasm[0]::function[1009]::helper::array_packed_join+0x14db>
 29d82f1:	mov    0x8(%rsp),%eax
 29d82f5:	mov    (%rsp),%r8d
 29d82f9:	jmp    29d831b <wasm[0]::function[1009]::helper::array_packed_join+0x14db>
 29d82fe:	xor    %edx,%edx
 29d8300:	mov    0x60(%rsp),%rsi
 29d8305:	mov    0x60(%rsp),%rdi
 29d830a:	call   2f30600 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 29d830f:	test   %eax,%eax
 29d8311:	je     29d8741 <wasm[0]::function[1009]::helper::array_packed_join+0x1901>
 29d8317:	mov    (%rsp),%r8d
 29d831b:	mov    0xb8(%rsp),%rdi
 29d8323:	test   %edi,%edi
 29d8325:	jne    29d8333 <wasm[0]::function[1009]::helper::array_packed_join+0x14f3>
 29d832b:	mov    %r8,%rax
 29d832e:	jmp    29d839e <wasm[0]::function[1009]::helper::array_packed_join+0x155e>
 29d8333:	xor    %ecx,%ecx
 29d8335:	test   %eax,%eax
 29d8337:	je     29d8382 <wasm[0]::function[1009]::helper::array_packed_join+0x1542>
 29d833d:	xor    %ecx,%ecx
 29d833f:	test   $0x1,%eax
 29d8344:	jne    29d8382 <wasm[0]::function[1009]::helper::array_packed_join+0x1542>
 29d834a:	mov    0xc8(%rsp),%r10
 29d8352:	mov    0x28(%r10),%rcx
 29d8356:	mov    0x20(%r10),%rdx
 29d835a:	mov    %eax,%esi
 29d835c:	lea    0x4(%rdx,%rsi,1),%rdx
 29d8361:	xor    %rdi,%rdi
 29d8364:	cmp    %rcx,%rsi
 29d8367:	cmova  %rdi,%rdx
 29d836b:	mov    (%rdx),%ecx
 29d836d:	mov    0x60(%rsp),%rdx
 29d8372:	mov    0x28(%rdx),%rdx
 29d8376:	cmp    0x234(%rdx),%ecx
 29d837c:	sete   %cl
 29d837f:	movzbl %cl,%ecx
 29d8382:	test   %ecx,%ecx
 29d8384:	je     29d8743 <wasm[0]::function[1009]::helper::array_packed_join+0x1903>
 29d838a:	jmp    29d839e <wasm[0]::function[1009]::helper::array_packed_join+0x155e>
 29d838f:	xor    %edx,%edx
 29d8391:	mov    0x60(%rsp),%rsi
 29d8396:	mov    %rsi,%rdi
 29d8399:	call   2f30600 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 29d839e:	mov    0xe0(%rsp),%rbx
 29d83a6:	mov    0xe8(%rsp),%r12
 29d83ae:	mov    0xf0(%rsp),%r13
 29d83b6:	mov    0xf8(%rsp),%r14
 29d83be:	mov    0x100(%rsp),%r15
 29d83c6:	add    $0x110,%rsp
 29d83cd:	mov    %rbp,%rsp
 29d83d0:	pop    %rbp
 29d83d1:	ret    $0x10
 29d83d4:	mov    0x60(%rsp),%rdi
 29d83d9:	call   3018b79 <wasmtime_builtin_new_epoch>
 29d83de:	mov    %rax,0x88(%rsp)
 29d83e6:	mov    0x68(%rsp),%r15
 29d83eb:	jmp    29d6ee6 <wasm[0]::function[1009]::helper::array_packed_join+0xa6>
 29d83f0:	mov    0xc8(%rsp),%r10
 29d83f8:	mov    0x8(%r10),%rcx
 29d83fc:	mov    %rcx,0x88(%rsp)
 29d8404:	cmp    %rcx,%rax
 29d8407:	jb     29d7160 <wasm[0]::function[1009]::helper::array_packed_join+0x320>
 29d840d:	mov    0x60(%rsp),%rdi
 29d8412:	call   3018b79 <wasmtime_builtin_new_epoch>
 29d8417:	mov    %rax,0x88(%rsp)
 29d841f:	mov    0x68(%rsp),%rcx
 29d8424:	jmp    29d7165 <wasm[0]::function[1009]::helper::array_packed_join+0x325>
 29d8429:	mov    $0xa8000006,%esi
 29d842e:	mov    %r12,%rdi
 29d8431:	mov    0x238(%rdi),%edx
 29d8437:	mov    $0x10,%r8d
 29d843d:	mov    0x60(%rsp),%rdi
 29d8442:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
 29d8447:	mov    %eax,%ecx
 29d8449:	mov    0xc8(%rsp),%r10
 29d8451:	add    0x20(%r10),%rcx
 29d8455:	jmp    29d76b3 <wasm[0]::function[1009]::helper::array_packed_join+0x873>
 29d845a:	mov    0xc8(%rsp),%r10
 29d8462:	mov    0x8(%r10),%rcx
 29d8466:	mov    %rcx,0x88(%rsp)
 29d846e:	cmp    %rcx,%rax
 29d8471:	jb     29d775f <wasm[0]::function[1009]::helper::array_packed_join+0x91f>
 29d8477:	mov    0x60(%rsp),%rdi
 29d847c:	call   3018b79 <wasmtime_builtin_new_epoch>
 29d8481:	mov    %rax,0x88(%rsp)
 29d8489:	jmp    29d775f <wasm[0]::function[1009]::helper::array_packed_join+0x91f>
 29d848e:	mov    0xc8(%rsp),%r10
 29d8496:	mov    0x8(%r10),%r9
 29d849a:	mov    %r9,%r11
 29d849d:	mov    %r9,0x88(%rsp)
 29d84a5:	cmp    %r11,%rax
 29d84a8:	jb     29d77df <wasm[0]::function[1009]::helper::array_packed_join+0x99f>
 29d84ae:	mov    0x60(%rsp),%rdi
 29d84b3:	call   3018b79 <wasmtime_builtin_new_epoch>
 29d84b8:	mov    %rax,0x88(%rsp)
 29d84c0:	jmp    29d77df <wasm[0]::function[1009]::helper::array_packed_join+0x99f>
 29d84c5:	mov    0xc8(%rsp),%r10
 29d84cd:	mov    0x8(%r10),%rcx
 29d84d1:	mov    %rcx,0x88(%rsp)
 29d84d9:	cmp    %rcx,%rax
 29d84dc:	jb     29d7869 <wasm[0]::function[1009]::helper::array_packed_join+0xa29>
 29d84e2:	mov    0x60(%rsp),%rdi
 29d84e7:	call   3018b79 <wasmtime_builtin_new_epoch>
 29d84ec:	mov    %rax,0x88(%rsp)
 29d84f4:	mov    0x68(%rsp),%rcx
 29d84f9:	mov    0x70(%rsp),%r12
 29d84fe:	jmp    29d7873 <wasm[0]::function[1009]::helper::array_packed_join+0xa33>
 29d8503:	mov    0xc8(%rsp),%r10
 29d850b:	mov    0x8(%r10),%rcx
 29d850f:	mov    %rcx,0x88(%rsp)
 29d8517:	cmp    %rcx,%rax
 29d851a:	jb     29d7a20 <wasm[0]::function[1009]::helper::array_packed_join+0xbe0>
 29d8520:	mov    0x60(%rsp),%rdi
 29d8525:	call   3018b79 <wasmtime_builtin_new_epoch>
 29d852a:	mov    %rax,0x88(%rsp)
 29d8532:	jmp    29d7a20 <wasm[0]::function[1009]::helper::array_packed_join+0xbe0>
 29d8537:	mov    0xc8(%rsp),%r10
 29d853f:	mov    0x8(%r10),%rcx
 29d8543:	mov    %rcx,0x88(%rsp)
 29d854b:	cmp    %rcx,%rax
 29d854e:	jb     29d7b0f <wasm[0]::function[1009]::helper::array_packed_join+0xccf>
 29d8554:	mov    0x60(%rsp),%rdi
 29d8559:	call   3018b79 <wasmtime_builtin_new_epoch>
 29d855e:	mov    %rax,0x88(%rsp)
 29d8566:	jmp    29d7b0f <wasm[0]::function[1009]::helper::array_packed_join+0xccf>
 29d856b:	mov    0xc8(%rsp),%r10
 29d8573:	mov    0x8(%r10),%rax
 29d8577:	mov    %rax,0x88(%rsp)
 29d857f:	cmp    %rax,%rsi
 29d8582:	jb     29d7bad <wasm[0]::function[1009]::helper::array_packed_join+0xd6d>
 29d8588:	mov    0x60(%rsp),%rdi
 29d858d:	call   3018b79 <wasmtime_builtin_new_epoch>
 29d8592:	mov    %rax,0x88(%rsp)
 29d859a:	mov    %r15,%rcx
 29d859d:	mov    %r12,%rdx
 29d85a0:	mov    %rbx,%rsi
 29d85a3:	jmp    29d7bb6 <wasm[0]::function[1009]::helper::array_packed_join+0xd76>
 29d85a8:	mov    0xc8(%rsp),%r10
 29d85b0:	mov    0x8(%r10),%rax
 29d85b4:	mov    %rax,0x88(%rsp)
 29d85bc:	cmp    %rax,%rdi
 29d85bf:	jb     29d80bb <wasm[0]::function[1009]::helper::array_packed_join+0x127b>
 29d85c5:	mov    0x60(%rsp),%rdi
 29d85ca:	call   3018b79 <wasmtime_builtin_new_epoch>
 29d85cf:	mov    %rax,0x88(%rsp)
 29d85d7:	jmp    29d80bb <wasm[0]::function[1009]::helper::array_packed_join+0x127b>
 29d85dc:	mov    0xc8(%rsp),%r10
 29d85e4:	mov    0x8(%r10),%rcx
 29d85e8:	mov    %rcx,0x88(%rsp)
 29d85f0:	cmp    %rcx,%rax
 29d85f3:	jb     29d817a <wasm[0]::function[1009]::helper::array_packed_join+0x133a>
 29d85f9:	mov    0x60(%rsp),%rdi
 29d85fe:	call   3018b79 <wasmtime_builtin_new_epoch>
 29d8603:	mov    %rax,0x88(%rsp)
 29d860b:	jmp    29d817a <wasm[0]::function[1009]::helper::array_packed_join+0x133a>
 29d8610:	mov    0xc8(%rsp),%r10
 29d8618:	mov    0x8(%r10),%rcx
 29d861c:	mov    %rcx,%rdx
 29d861f:	mov    %rcx,0x88(%rsp)
 29d8627:	cmp    %rdx,%rax
 29d862a:	jb     29d8218 <wasm[0]::function[1009]::helper::array_packed_join+0x13d8>
 29d8630:	mov    0x60(%rsp),%rdi
 29d8635:	call   3018b79 <wasmtime_builtin_new_epoch>
 29d863a:	mov    %rax,0x88(%rsp)
 29d8642:	mov    %rbx,%rcx
 29d8645:	mov    %r13,%rdx
 29d8648:	mov    %r12,%rsi
 29d864b:	jmp    29d8221 <wasm[0]::function[1009]::helper::array_packed_join+0x13e1>
 29d8650:	mov    $0xb000000a,%esi
 29d8655:	mov    $0x20,%ecx
 29d865a:	mov    $0x10,%r8d
 29d8660:	mov    0xb0(%rsp),%rdx
 29d8668:	mov    0x60(%rsp),%rdi
 29d866d:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
 29d8672:	mov    %eax,%edx
 29d8674:	mov    0xc8(%rsp),%r10
 29d867c:	add    0x20(%r10),%rdx
 29d8680:	jmp    29d82d0 <wasm[0]::function[1009]::helper::array_packed_join+0x1490>
 29d8685:	ud2
 29d8687:	ud2
 29d8689:	ud2
 29d868b:	ud2
 29d868d:	ud2
 29d868f:	ud2
 29d8691:	ud2
 29d8693:	ud2
 29d8695:	ud2
 29d8697:	ud2
 29d8699:	ud2
 29d869b:	ud2
 29d869d:	ud2
 29d869f:	ud2
 29d86a1:	ud2
 29d86a3:	ud2
 29d86a5:	ud2
 29d86a7:	ud2
 29d86a9:	ud2
 29d86ab:	ud2
 29d86ad:	ud2
 29d86af:	ud2
 29d86b1:	ud2
 29d86b3:	ud2
 29d86b5:	ud2
 29d86b7:	ud2
 29d86b9:	ud2
 29d86bb:	ud2
 29d86bd:	ud2
 29d86bf:	ud2
 29d86c1:	ud2
 29d86c3:	ud2
 29d86c5:	ud2
 29d86c7:	ud2
 29d86c9:	ud2
 29d86cb:	ud2
 29d86cd:	ud2
 29d86cf:	ud2
 29d86d1:	ud2
 29d86d3:	ud2
 29d86d5:	ud2
 29d86d7:	ud2
 29d86d9:	ud2
 29d86db:	ud2
 29d86dd:	ud2
 29d86df:	ud2
 29d86e1:	ud2
 29d86e3:	ud2
 29d86e5:	ud2
 29d86e7:	ud2
 29d86e9:	ud2
 29d86eb:	ud2
 29d86ed:	ud2
 29d86ef:	ud2
 29d86f1:	ud2
 29d86f3:	ud2
 29d86f5:	ud2
 29d86f7:	ud2
 29d86f9:	ud2
 29d86fb:	ud2
 29d86fd:	ud2
 29d86ff:	ud2
 29d8701:	ud2
 29d8703:	ud2
 29d8705:	ud2
 29d8707:	ud2
 29d8709:	ud2
 29d870b:	ud2
 29d870d:	ud2
 29d870f:	ud2
 29d8711:	ud2
 29d8713:	ud2
 29d8715:	ud2
 29d8717:	ud2
 29d8719:	ud2
 29d871b:	ud2
 29d871d:	ud2
 29d871f:	ud2
 29d8721:	ud2
 29d8723:	ud2
 29d8725:	ud2
 29d8727:	ud2
 29d8729:	ud2
 29d872b:	ud2
 29d872d:	ud2
 29d872f:	ud2
 29d8731:	ud2
 29d8733:	ud2
 29d8735:	ud2
 29d8737:	ud2
 29d8739:	ud2
 29d873b:	ud2
 29d873d:	ud2
 29d873f:	ud2
 29d8741:	ud2
 29d8743:	ud2
 29d8745:	add    %al,(%rax)
 29d8747:	add    %bh,%bh
 29d8749:	(bad)
 29d874a:	(bad)
 29d874b:	incl   (%rax)
 29d874d:	add    %al,(%rax)
	...
