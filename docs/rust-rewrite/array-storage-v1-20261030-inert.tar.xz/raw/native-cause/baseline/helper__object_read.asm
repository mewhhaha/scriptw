
/workspace/scriptw/target/performance-dense-numbers-20261030/native-cause/baseline/runtime-portable.elf:     file format elf64-x86-64


Disassembly of section .text:

00000000029e0f80 <wasm[0]::function[1015]::helper::object_read>:
 29e0f80:	push   %rbp
 29e0f81:	mov    %rsp,%rbp
 29e0f84:	mov    0x8(%rdi),%r10
 29e0f88:	mov    0x18(%r10),%r10
 29e0f8c:	add    $0x330,%r10
 29e0f93:	cmp    %rsp,%r10
 29e0f96:	ja     29fbb99 <wasm[0]::function[1015]::helper::object_read+0x1ac19>
 29e0f9c:	sub    $0x320,%rsp
 29e0fa3:	mov    %rbx,0x2f0(%rsp)
 29e0fab:	mov    %r12,0x2f8(%rsp)
 29e0fb3:	mov    %r13,0x300(%rsp)
 29e0fbb:	mov    %r14,0x308(%rsp)
 29e0fc3:	mov    %r15,0x310(%rsp)
 29e0fcb:	mov    %rdx,0x198(%rsp)
 29e0fd3:	mov    %rcx,0x1a0(%rsp)
 29e0fdb:	mov    %r9,0x1a8(%rsp)
 29e0fe3:	mov    0x10(%rbp),%rsi
 29e0fe7:	mov    %rsi,0x1b0(%rsp)
 29e0fef:	mov    0x18(%rbp),%r9
 29e0ff3:	mov    0x20(%rbp),%rcx
 29e0ff7:	mov    %rcx,0x1b8(%rsp)
 29e0fff:	mov    0x28(%rbp),%rax
 29e1003:	mov    %rax,0x1c0(%rsp)
 29e100b:	mov    0x30(%rbp),%rdx
 29e100f:	mov    0x38(%rbp),%rcx
 29e1013:	mov    0x40(%rbp),%rax
 29e1017:	mov    %r8d,0xe8(%rsp)
 29e101f:	mov    %r9d,0x68(%rsp)
 29e1024:	mov    %edx,0x60(%rsp)
 29e1028:	mov    %ecx,0xd0(%rsp)
 29e102f:	mov    %eax,0x140(%rsp)
 29e1036:	movl   $0x0,0x40(%rsp)
 29e103e:	movl   $0x0,0x70(%rsp)
 29e1046:	movl   $0x0,0x50(%rsp)
 29e104e:	mov    0x18(%rdi),%rcx
 29e1052:	mov    (%rcx),%rax
 29e1055:	mov    %rcx,0x2e8(%rsp)
 29e105d:	mov    0x8(%rdi),%rcx
 29e1061:	mov    %rdi,0x190(%rsp)
 29e1069:	mov    0x8(%rcx),%rdx
 29e106d:	mov    %rcx,0x2e0(%rsp)
 29e1075:	mov    %rdx,0x228(%rsp)
 29e107d:	mov    %rdx,%rcx
 29e1080:	cmp    %rcx,%rax
 29e1083:	jae    29fa4eb <wasm[0]::function[1015]::helper::object_read+0x1956b>
 29e1089:	mov    0x140(%rsp),%ecx
 29e1090:	xor    %ebx,%ebx
 29e1092:	test   %ecx,%ecx
 29e1094:	je     29fbb9b <wasm[0]::function[1015]::helper::object_read+0x1ac1b>
 29e109a:	mov    0xe8(%rsp),%r9d
 29e10a2:	mov    0xd0(%rsp),%esi
 29e10a9:	mov    0x68(%rsp),%edi
 29e10ad:	mov    0x60(%rsp),%r11d
 29e10b2:	mov    0x70(%rsp),%r8d
 29e10b7:	mov    0x50(%rsp),%r10d
 29e10bc:	mov    0x40(%rsp),%edx
 29e10c0:	xor    %r13,%r13
 29e10c3:	mov    0x198(%rsp),%rax
 29e10cb:	cmp    $0x4,%eax
 29e10ce:	je     29e1109 <wasm[0]::function[1015]::helper::object_read+0x189>
 29e10d4:	mov    %rbx,0x1d0(%rsp)
 29e10dc:	mov    %rbx,0x240(%rsp)
 29e10e4:	mov    %rbx,0x280(%rsp)
 29e10ec:	mov    %r13,0x288(%rsp)
 29e10f4:	mov    %rbx,0x290(%rsp)
 29e10fc:	mov    %rbx,0x298(%rsp)
 29e1104:	jmp    29e1b07 <wasm[0]::function[1015]::helper::object_read+0xb87>
 29e1109:	mov    0xe8(%rsp),%r9d
 29e1111:	mov    0xd0(%rsp),%esi
 29e1118:	mov    0x140(%rsp),%ecx
 29e111f:	mov    0x68(%rsp),%edi
 29e1123:	mov    0x60(%rsp),%r11d
 29e1128:	mov    0x70(%rsp),%r8d
 29e112d:	mov    0x50(%rsp),%r10d
 29e1132:	mov    0x40(%rsp),%edx
 29e1136:	xor    %eax,%eax
 29e1138:	xor    %r13,%r13
 29e113b:	mov    0x1b8(%rsp),%rbx
 29e1143:	cmp    $0x4,%ebx
 29e1146:	je     29e1161 <wasm[0]::function[1015]::helper::object_read+0x1e1>
 29e114c:	mov    %rax,0x1d0(%rsp)
 29e1154:	mov    %rax,0x240(%rsp)
 29e115c:	jmp    29e19de <wasm[0]::function[1015]::helper::object_read+0xa5e>
 29e1161:	xor    %r12d,%r12d
 29e1164:	test   %r11d,%r11d
 29e1167:	jne    29e117a <wasm[0]::function[1015]::helper::object_read+0x1fa>
 29e116d:	mov    0x2e0(%rsp),%rax
 29e1175:	jmp    29e11d9 <wasm[0]::function[1015]::helper::object_read+0x259>
 29e117a:	xor    %r12d,%r12d
 29e117d:	test   $0x1,%r11d
 29e1184:	je     29e1197 <wasm[0]::function[1015]::helper::object_read+0x217>
 29e118a:	mov    0x2e0(%rsp),%rax
 29e1192:	jmp    29e11d9 <wasm[0]::function[1015]::helper::object_read+0x259>
 29e1197:	mov    0x2e0(%rsp),%rax
 29e119f:	mov    0x28(%rax),%rbx
 29e11a3:	mov    0x20(%rax),%r12
 29e11a7:	mov    %r11d,%r13d
 29e11aa:	lea    0x4(%r12,%r13,1),%r12
 29e11af:	xor    %r14,%r14
 29e11b2:	cmp    %rbx,%r13
 29e11b5:	cmova  %r14,%r12
 29e11b9:	mov    (%r12),%ebx
 29e11bd:	mov    0x190(%rsp),%r12
 29e11c5:	mov    0x28(%r12),%r12
 29e11ca:	cmp    0x234(%r12),%ebx
 29e11d2:	sete   %bl
 29e11d5:	movzbl %bl,%r12d
 29e11d9:	test   %r12d,%r12d
 29e11dc:	je     29fbb9d <wasm[0]::function[1015]::helper::object_read+0x1ac1d>
 29e11e2:	test   %r11d,%r11d
 29e11e5:	je     29fbb9f <wasm[0]::function[1015]::helper::object_read+0x1ac1f>
 29e11eb:	test   %r11d,%r11d
 29e11ee:	je     29fbba1 <wasm[0]::function[1015]::helper::object_read+0x1ac21>
 29e11f4:	mov    0x28(%rax),%rbx
 29e11f8:	mov    0x20(%rax),%r12
 29e11fc:	mov    %rax,0x2e0(%rsp)
 29e1204:	mov    %r11d,%r14d
 29e1207:	lea    (%r12,%r14,1),%rax
 29e120b:	xor    %r13,%r13
 29e120e:	cmp    %rbx,%r14
 29e1211:	cmova  %r13,%rax
 29e1215:	mov    0x10(%rax),%r14d
 29e1219:	xor    %eax,%eax
 29e121b:	test   %r14d,%r14d
 29e121e:	je     29fbba3 <wasm[0]::function[1015]::helper::object_read+0x1ac23>
 29e1224:	test   %r14d,%r14d
 29e1227:	je     29fbba5 <wasm[0]::function[1015]::helper::object_read+0x1ac25>
 29e122d:	mov    %r14d,%r14d
 29e1230:	lea    0x10(%r12,%r14,1),%r12
 29e1235:	cmp    %rbx,%r14
 29e1238:	cmova  %r13,%r12
 29e123c:	mov    (%r12),%ebx
 29e1240:	cmp    $0x6,%ebx
 29e1243:	je     29e125e <wasm[0]::function[1015]::helper::object_read+0x2de>
 29e1249:	mov    %rax,0x1d0(%rsp)
 29e1251:	mov    %rax,0x240(%rsp)
 29e1259:	jmp    29e19de <wasm[0]::function[1015]::helper::object_read+0xa5e>
 29e125e:	mov    $0x8c,%edx
 29e1263:	mov    0x190(%rsp),%rsi
 29e126b:	mov    0x190(%rsp),%rdi
 29e1273:	call   2f30600 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 29e1278:	test   %eax,%eax
 29e127a:	mov    %rax,%rdi
 29e127d:	je     29fbba7 <wasm[0]::function[1015]::helper::object_read+0x1ac27>
 29e1283:	mov    0x1b8(%rsp),%rcx
 29e128b:	cmp    $0x4,%ecx
 29e128e:	je     29e12d8 <wasm[0]::function[1015]::helper::object_read+0x358>
 29e1294:	mov    0xe8(%rsp),%r9d
 29e129c:	mov    0xd0(%rsp),%esi
 29e12a3:	mov    0x140(%rsp),%ecx
 29e12aa:	mov    0x68(%rsp),%edi
 29e12ae:	mov    0x60(%rsp),%r11d
 29e12b3:	mov    0x70(%rsp),%r8d
 29e12b8:	mov    0x50(%rsp),%r10d
 29e12bd:	mov    0x40(%rsp),%edx
 29e12c1:	xor    %eax,%eax
 29e12c3:	mov    %rax,0x1d0(%rsp)
 29e12cb:	mov    %rax,0x240(%rsp)
 29e12d3:	jmp    29e19db <wasm[0]::function[1015]::helper::object_read+0xa5b>
 29e12d8:	mov    0x1b8(%rsp),%rcx
 29e12e0:	cmp    $0x3,%ecx
 29e12e3:	je     29e1949 <wasm[0]::function[1015]::helper::object_read+0x9c9>
 29e12e9:	mov    0x1b8(%rsp),%rcx
 29e12f1:	cmp    $0x4,%ecx
 29e12f4:	je     29e17f7 <wasm[0]::function[1015]::helper::object_read+0x877>
 29e12fa:	mov    0x1b8(%rsp),%rcx
 29e1302:	cmp    $0xa,%ecx
 29e1305:	je     29e13b4 <wasm[0]::function[1015]::helper::object_read+0x434>
 29e130b:	mov    0x1b8(%rsp),%rax
 29e1313:	mov    0x1b8(%rsp),%rcx
 29e131b:	test   %eax,%ecx
 29e131d:	sete   %cl
 29e1320:	mov    $0x1,%eax
 29e1325:	mov    0x1b8(%rsp),%rdx
 29e132d:	cmp    $0x1,%edx
 29e1330:	sete   %dl
 29e1333:	or     %edx,%ecx
 29e1335:	test   %cl,%cl
 29e1337:	jne    29e1377 <wasm[0]::function[1015]::helper::object_read+0x3f7>
 29e133d:	mov    0x1b8(%rsp),%rcx
 29e1345:	cmp    $0x2,%ecx
 29e1348:	je     29e1364 <wasm[0]::function[1015]::helper::object_read+0x3e4>
 29e134e:	mov    0x60(%rsp),%edx
 29e1352:	mov    %rdi,%rax
 29e1355:	cmp    %eax,%edx
 29e1357:	sete   %sil
 29e135b:	movzbl %sil,%eax
 29e135f:	jmp    29e1377 <wasm[0]::function[1015]::helper::object_read+0x3f7>
 29e1364:	mov    0x1c0(%rsp),%r8
 29e136c:	test   %r8,%r8
 29e136f:	sete   %sil
 29e1373:	movzbl %sil,%eax
 29e1377:	mov    0xe8(%rsp),%r9d
 29e137f:	mov    0xd0(%rsp),%esi
 29e1386:	mov    0x140(%rsp),%ecx
 29e138d:	mov    0x68(%rsp),%edi
 29e1391:	mov    0x60(%rsp),%r11d
 29e1396:	mov    0x70(%rsp),%r8d
 29e139b:	mov    0x50(%rsp),%r10d
 29e13a0:	mov    0x40(%rsp),%edx
 29e13a4:	xor    %r13d,%r13d
 29e13a7:	mov    %r13,0x1d0(%rsp)
 29e13af:	jmp    29e193c <wasm[0]::function[1015]::helper::object_read+0x9bc>
 29e13b4:	mov    %rdi,%rax
 29e13b7:	mov    0x60(%rsp),%r9d
 29e13bc:	xor    %ecx,%ecx
 29e13be:	test   %r9d,%r9d
 29e13c1:	je     29e1414 <wasm[0]::function[1015]::helper::object_read+0x494>
 29e13c7:	xor    %ecx,%ecx
 29e13c9:	test   $0x1,%r9d
 29e13d0:	jne    29e1414 <wasm[0]::function[1015]::helper::object_read+0x494>
 29e13d6:	mov    0x2e0(%rsp),%r12
 29e13de:	mov    0x28(%r12),%rcx
 29e13e3:	mov    0x20(%r12),%rdx
 29e13e8:	mov    %r9d,%esi
 29e13eb:	lea    0x4(%rdx,%rsi,1),%rdx
 29e13f0:	xor    %rdi,%rdi
 29e13f3:	cmp    %rcx,%rsi
 29e13f6:	cmova  %rdi,%rdx
 29e13fa:	mov    (%rdx),%ecx
 29e13fc:	mov    0x190(%rsp),%rdx
 29e1404:	mov    0x28(%rdx),%rdx
 29e1408:	cmp    0x23c(%rdx),%ecx
 29e140e:	sete   %cl
 29e1411:	movzbl %cl,%ecx
 29e1414:	test   %ecx,%ecx
 29e1416:	je     29fbba9 <wasm[0]::function[1015]::helper::object_read+0x1ac29>
 29e141c:	xor    %ecx,%ecx
 29e141e:	test   %eax,%eax
 29e1420:	je     29e1470 <wasm[0]::function[1015]::helper::object_read+0x4f0>
 29e1426:	xor    %ecx,%ecx
 29e1428:	test   $0x1,%eax
 29e142d:	jne    29e1470 <wasm[0]::function[1015]::helper::object_read+0x4f0>
 29e1433:	mov    0x2e0(%rsp),%r12
 29e143b:	mov    0x28(%r12),%rcx
 29e1440:	mov    0x20(%r12),%rdx
 29e1445:	mov    %eax,%esi
 29e1447:	lea    0x4(%rdx,%rsi,1),%rdx
 29e144c:	xor    %rdi,%rdi
 29e144f:	cmp    %rcx,%rsi
 29e1452:	cmova  %rdi,%rdx
 29e1456:	mov    (%rdx),%ecx
 29e1458:	mov    0x190(%rsp),%rdx
 29e1460:	mov    0x28(%rdx),%rdx
 29e1464:	cmp    0x23c(%rdx),%ecx
 29e146a:	sete   %cl
 29e146d:	movzbl %cl,%ecx
 29e1470:	test   %ecx,%ecx
 29e1472:	je     29fbbab <wasm[0]::function[1015]::helper::object_read+0x1ac2b>
 29e1478:	mov    0x60(%rsp),%r11d
 29e147d:	xor    %r13d,%r13d
 29e1480:	test   %r11d,%r11d
 29e1483:	je     29fbbad <wasm[0]::function[1015]::helper::object_read+0x1ac2d>
 29e1489:	test   %r11d,%r11d
 29e148c:	je     29fbbaf <wasm[0]::function[1015]::helper::object_read+0x1ac2f>
 29e1492:	mov    0x2e0(%rsp),%r12
 29e149a:	mov    0x28(%r12),%rcx
 29e149f:	mov    0x20(%r12),%rdx
 29e14a4:	mov    %r11d,%r8d
 29e14a7:	lea    (%rdx,%r8,1),%rdi
 29e14ab:	xor    %rsi,%rsi
 29e14ae:	cmp    %rcx,%r8
 29e14b1:	cmova  %rsi,%rdi
 29e14b5:	mov    0x10(%rdi),%r14d
 29e14b9:	test   %eax,%eax
 29e14bb:	je     29fbbb1 <wasm[0]::function[1015]::helper::object_read+0x1ac31>
 29e14c1:	mov    %eax,%eax
 29e14c3:	lea    (%rdx,%rax,1),%r9
 29e14c7:	cmp    %rcx,%rax
 29e14ca:	cmova  %rsi,%r9
 29e14ce:	mov    0x10(%r9),%eax
 29e14d2:	mov    0x14(%rdi),%r8d
 29e14d6:	mov    %r8d,0xf0(%rsp)
 29e14de:	mov    0x14(%r9),%edi
 29e14e2:	mov    %edi,0x148(%rsp)
 29e14e9:	test   %r8d,%r8d
 29e14ec:	je     29fbbb3 <wasm[0]::function[1015]::helper::object_read+0x1ac33>
 29e14f2:	test   %r8d,%r8d
 29e14f5:	je     29fbbb5 <wasm[0]::function[1015]::helper::object_read+0x1ac35>
 29e14fb:	mov    %r8d,%r9d
 29e14fe:	lea    0x10(%rdx,%r9,1),%r8
 29e1503:	cmp    %rcx,%r9
 29e1506:	cmova  %rsi,%r8
 29e150a:	mov    (%r8),%ebx
 29e150d:	test   %edi,%edi
 29e150f:	je     29fbbb7 <wasm[0]::function[1015]::helper::object_read+0x1ac37>
 29e1515:	test   %edi,%edi
 29e1517:	je     29fbbb9 <wasm[0]::function[1015]::helper::object_read+0x1ac39>
 29e151d:	mov    %edi,%edi
 29e151f:	lea    0x10(%rdx,%rdi,1),%rdx
 29e1524:	cmp    %rcx,%rdi
 29e1527:	cmova  %rsi,%rdx
 29e152b:	mov    (%rdx),%ecx
 29e152d:	mov    %rcx,0x1d0(%rsp)
 29e1535:	mov    0xe8(%rsp),%r9d
 29e153d:	mov    0xd0(%rsp),%esi
 29e1544:	mov    0x140(%rsp),%ecx
 29e154b:	mov    0x68(%rsp),%edi
 29e154f:	mov    0x70(%rsp),%r8d
 29e1554:	mov    0x50(%rsp),%r10d
 29e1559:	mov    0x40(%rsp),%edx
 29e155d:	cmp    %eax,%r14d
 29e1560:	sete   %r12b
 29e1564:	mov    0x1d0(%rsp),%rax
 29e156c:	cmp    %eax,%ebx
 29e156e:	sete   %r14b
 29e1572:	mov    %r12,%rax
 29e1575:	and    %r14d,%eax
 29e1578:	movzbl %al,%eax
 29e157b:	mov    %rax,0x1c8(%rsp)
 29e1583:	test   %r12b,%r14b
 29e1586:	jne    29e1599 <wasm[0]::function[1015]::helper::object_read+0x619>
 29e158c:	mov    0x1c8(%rsp),%rax
 29e1594:	jmp    29e193c <wasm[0]::function[1015]::helper::object_read+0x9bc>
 29e1599:	mov    0xe8(%rsp),%ecx
 29e15a0:	mov    0xd0(%rsp),%edx
 29e15a7:	mov    0x140(%rsp),%esi
 29e15ae:	mov    0x68(%rsp),%edi
 29e15b2:	mov    0x60(%rsp),%r8d
 29e15b7:	mov    0x70(%rsp),%r9d
 29e15bc:	mov    0x50(%rsp),%r10d
 29e15c1:	mov    0x40(%rsp),%r11d
 29e15c6:	xor    %r13d,%r13d
 29e15c9:	mov    %r13,0x240(%rsp)
 29e15d1:	mov    %ecx,0x100(%rsp)
 29e15d8:	mov    %edx,0x78(%rsp)
 29e15dc:	mov    %esi,0xa0(%rsp)
 29e15e3:	mov    %edi,0xa8(%rsp)
 29e15ea:	mov    %r8d,0x48(%rsp)
 29e15ef:	mov    %r9d,0x80(%rsp)
 29e15f7:	mov    %r10d,0xb8(%rsp)
 29e15ff:	mov    %r11d,0x130(%rsp)
 29e1607:	mov    0x2e8(%rsp),%r15
 29e160f:	mov    (%r15),%rdx
 29e1612:	mov    0x228(%rsp),%rax
 29e161a:	cmp    %rax,%rdx
 29e161d:	jae    29fa505 <wasm[0]::function[1015]::helper::object_read+0x19585>
 29e1623:	mov    0x240(%rsp),%r13
 29e162b:	jmp    29e1638 <wasm[0]::function[1015]::helper::object_read+0x6b8>
 29e1630:	mov    0x240(%rsp),%r13
 29e1638:	cmp    %ebx,%r13d
 29e163b:	jb     29e164e <wasm[0]::function[1015]::helper::object_read+0x6ce>
 29e1641:	mov    0x1c8(%rsp),%rax
 29e1649:	jmp    29e17bc <wasm[0]::function[1015]::helper::object_read+0x83c>
 29e164e:	mov    0xf0(%rsp),%esi
 29e1655:	test   %esi,%esi
 29e1657:	je     29fbbbb <wasm[0]::function[1015]::helper::object_read+0x1ac3b>
 29e165d:	test   %esi,%esi
 29e165f:	je     29fbbbd <wasm[0]::function[1015]::helper::object_read+0x1ac3d>
 29e1665:	mov    0x2e0(%rsp),%r12
 29e166d:	mov    0x28(%r12),%rax
 29e1672:	mov    0x20(%r12),%rcx
 29e1677:	mov    %esi,%r8d
 29e167a:	lea    0x10(%rcx,%r8,1),%rdi
 29e167f:	xor    %rdx,%rdx
 29e1682:	cmp    %rax,%r8
 29e1685:	cmova  %rdx,%rdi
 29e1689:	mov    (%rdi),%r8d
 29e168c:	cmp    %r8d,%r13d
 29e168f:	jae    29fbbbf <wasm[0]::function[1015]::helper::object_read+0x1ac3f>
 29e1695:	mov    %r8d,%edi
 29e1698:	shl    $0x3,%rdi
 29e169c:	shr    $0x20,%rdi
 29e16a0:	test   %rdi,%rdi
 29e16a3:	jne    29fbbc1 <wasm[0]::function[1015]::helper::object_read+0x1ac41>
 29e16a9:	shl    $0x3,%r8d
 29e16ad:	add    $0x18,%r8d
 29e16b1:	jb     29fbbc3 <wasm[0]::function[1015]::helper::object_read+0x1ac43>
 29e16b7:	add    %r8d,%esi
 29e16ba:	jb     29fbbc5 <wasm[0]::function[1015]::helper::object_read+0x1ac45>
 29e16c0:	mov    %esi,%edi
 29e16c2:	lea    (%rcx,%rdi,1),%rsi
 29e16c6:	cmp    %rax,%rdi
 29e16c9:	cmova  %rdx,%rsi
 29e16cd:	mov    %r13,%rdi
 29e16d0:	shl    $0x3,%edi
 29e16d3:	add    $0x18,%edi
 29e16d9:	sub    %edi,%r8d
 29e16dc:	sub    %r8,%rsi
 29e16df:	mov    (%rsi),%rsi
 29e16e2:	mov    0x148(%rsp),%r8d
 29e16ea:	test   %r8d,%r8d
 29e16ed:	je     29fbbc7 <wasm[0]::function[1015]::helper::object_read+0x1ac47>
 29e16f3:	test   %r8d,%r8d
 29e16f6:	je     29fbbc9 <wasm[0]::function[1015]::helper::object_read+0x1ac49>
 29e16fc:	mov    %r8d,%r10d
 29e16ff:	lea    0x10(%rcx,%r10,1),%r9
 29e1704:	cmp    %rax,%r10
 29e1707:	cmova  %rdx,%r9
 29e170b:	mov    (%r9),%r9d
 29e170e:	cmp    %r9d,%r13d
 29e1711:	jae    29fbbcb <wasm[0]::function[1015]::helper::object_read+0x1ac4b>
 29e1717:	mov    %r9d,%r10d
 29e171a:	shl    $0x3,%r10
 29e171e:	shr    $0x20,%r10
 29e1722:	test   %r10,%r10
 29e1725:	jne    29fbbcd <wasm[0]::function[1015]::helper::object_read+0x1ac4d>
 29e172b:	shl    $0x3,%r9d
 29e172f:	add    $0x18,%r9d
 29e1733:	jb     29fbbcf <wasm[0]::function[1015]::helper::object_read+0x1ac4f>
 29e1739:	add    %r9d,%r8d
 29e173c:	jb     29fbbd1 <wasm[0]::function[1015]::helper::object_read+0x1ac51>
 29e1742:	mov    %r8d,%r8d
 29e1745:	add    %r8,%rcx
 29e1748:	cmp    %rax,%r8
 29e174b:	cmova  %rdx,%rcx
 29e174f:	sub    %edi,%r9d
 29e1752:	sub    %r9,%rcx
 29e1755:	mov    (%rcx),%rcx
 29e1758:	cmp    %rcx,%rsi
 29e175b:	sete   %al
 29e175e:	movzbl %al,%eax
 29e1761:	cmp    %rcx,%rsi
 29e1764:	jne    29e17bc <wasm[0]::function[1015]::helper::object_read+0x83c>
 29e176a:	mov    0x100(%rsp),%ecx
 29e1771:	mov    0x78(%rsp),%edx
 29e1775:	mov    0xa0(%rsp),%esi
 29e177c:	mov    0xa8(%rsp),%edi
 29e1783:	mov    0x48(%rsp),%r8d
 29e1788:	mov    0x80(%rsp),%r9d
 29e1790:	mov    0xb8(%rsp),%r10d
 29e1798:	mov    0x130(%rsp),%r11d
 29e17a0:	add    $0x1,%r13d
 29e17a7:	mov    %rax,0x1c8(%rsp)
 29e17af:	mov    %r13,0x240(%rsp)
 29e17b7:	jmp    29e15d1 <wasm[0]::function[1015]::helper::object_read+0x651>
 29e17bc:	mov    0x100(%rsp),%r9d
 29e17c4:	mov    0x78(%rsp),%esi
 29e17c8:	mov    0xa0(%rsp),%ecx
 29e17cf:	mov    0xa8(%rsp),%edi
 29e17d6:	mov    0x48(%rsp),%r11d
 29e17db:	mov    0x80(%rsp),%r8d
 29e17e3:	mov    0xb8(%rsp),%r10d
 29e17eb:	mov    0x130(%rsp),%edx
 29e17f2:	jmp    29e193c <wasm[0]::function[1015]::helper::object_read+0x9bc>
 29e17f7:	mov    %rdi,%rax
 29e17fa:	mov    0x60(%rsp),%ecx
 29e17fe:	cmp    %eax,%ecx
 29e1800:	je     29e18ff <wasm[0]::function[1015]::helper::object_read+0x97f>
 29e1806:	xor    %edx,%edx
 29e1808:	test   %ecx,%ecx
 29e180a:	je     29e185b <wasm[0]::function[1015]::helper::object_read+0x8db>
 29e1810:	xor    %edx,%edx
 29e1812:	test   $0x1,%ecx
 29e1818:	jne    29e185b <wasm[0]::function[1015]::helper::object_read+0x8db>
 29e181e:	mov    0x2e0(%rsp),%r12
 29e1826:	mov    0x28(%r12),%rdx
 29e182b:	mov    0x20(%r12),%rdi
 29e1830:	mov    %ecx,%esi
 29e1832:	lea    0x4(%rdi,%rsi,1),%rcx
 29e1837:	xor    %rdi,%rdi
 29e183a:	cmp    %rdx,%rsi
 29e183d:	cmova  %rdi,%rcx
 29e1841:	mov    (%rcx),%ecx
 29e1843:	mov    0x190(%rsp),%rdx
 29e184b:	mov    0x28(%rdx),%rdx
 29e184f:	cmp    0x234(%rdx),%ecx
 29e1855:	sete   %cl
 29e1858:	movzbl %cl,%edx
 29e185b:	test   %edx,%edx
 29e185d:	je     29fbbd3 <wasm[0]::function[1015]::helper::object_read+0x1ac53>
 29e1863:	xor    %esi,%esi
 29e1865:	test   %eax,%eax
 29e1867:	jne    29e1875 <wasm[0]::function[1015]::helper::object_read+0x8f5>
 29e186d:	mov    %rax,%rdi
 29e1870:	jmp    29e18cb <wasm[0]::function[1015]::helper::object_read+0x94b>
 29e1875:	xor    %esi,%esi
 29e1877:	test   $0x1,%eax
 29e187c:	je     29e188a <wasm[0]::function[1015]::helper::object_read+0x90a>
 29e1882:	mov    %rax,%rdi
 29e1885:	jmp    29e18cb <wasm[0]::function[1015]::helper::object_read+0x94b>
 29e188a:	mov    0x2e0(%rsp),%r12
 29e1892:	mov    0x28(%r12),%rcx
 29e1897:	mov    0x20(%r12),%rsi
 29e189c:	mov    %eax,%edx
 29e189e:	mov    %rax,%rdi
 29e18a1:	lea    0x4(%rsi,%rdx,1),%rax
 29e18a6:	xor    %rsi,%rsi
 29e18a9:	cmp    %rcx,%rdx
 29e18ac:	cmova  %rsi,%rax
 29e18b0:	mov    (%rax),%ecx
 29e18b2:	mov    0x190(%rsp),%rdx
 29e18ba:	mov    0x28(%rdx),%rdx
 29e18be:	cmp    0x234(%rdx),%ecx
 29e18c4:	sete   %dl
 29e18c7:	rex movzbl %dl,%esi
 29e18cb:	test   %esi,%esi
 29e18cd:	je     29fbbd5 <wasm[0]::function[1015]::helper::object_read+0x1ac55>
 29e18d3:	mov    0x60(%rsp),%edx
 29e18d7:	xor    %r8d,%r8d
 29e18da:	test   %edx,%edx
 29e18dc:	je     29fbbd7 <wasm[0]::function[1015]::helper::object_read+0x1ac57>
 29e18e2:	mov    %rdi,%rcx
 29e18e5:	mov    0x190(%rsp),%rsi
 29e18ed:	mov    0x190(%rsp),%rdi
 29e18f5:	call   2ae5540 <wasm[0]::function[1057]::helper::string_equality>
 29e18fa:	jmp    29e1904 <wasm[0]::function[1015]::helper::object_read+0x984>
 29e18ff:	mov    $0x1,%eax
 29e1904:	mov    0xe8(%rsp),%r9d
 29e190c:	mov    0xd0(%rsp),%esi
 29e1913:	mov    0x140(%rsp),%ecx
 29e191a:	mov    0x68(%rsp),%edi
 29e191e:	mov    0x60(%rsp),%r11d
 29e1923:	mov    0x70(%rsp),%r8d
 29e1928:	mov    0x50(%rsp),%r10d
 29e192d:	mov    0x40(%rsp),%edx
 29e1931:	xor    %r13d,%r13d
 29e1934:	mov    %r13,0x1d0(%rsp)
 29e193c:	mov    %r13,0x240(%rsp)
 29e1944:	jmp    29e19db <wasm[0]::function[1015]::helper::object_read+0xa5b>
 29e1949:	mov    0xe8(%rsp),%r9d
 29e1951:	mov    0xd0(%rsp),%esi
 29e1958:	mov    0x140(%rsp),%ecx
 29e195f:	mov    0x68(%rsp),%edi
 29e1963:	mov    0x60(%rsp),%r11d
 29e1968:	mov    0x70(%rsp),%r8d
 29e196d:	mov    0x50(%rsp),%r10d
 29e1972:	mov    0x40(%rsp),%edx
 29e1976:	xor    %r13,%r13
 29e1979:	mov    0x1c0(%rsp),%rax
 29e1981:	mov    0x1c0(%rsp),%rbx
 29e1989:	test   %rbx,%rax
 29e198c:	sete   %al
 29e198f:	movq   %rbx,%xmm0
 29e1994:	ucomisd %xmm0,%xmm0
 29e1998:	setp   %r12b
 29e199c:	setne  %r14b
 29e19a0:	or     %r14d,%r12d
 29e19a3:	movq   %r13,%xmm0
 29e19a8:	ucomisd %xmm0,%xmm0
 29e19ac:	setp   %r14b
 29e19b0:	setne  %r15b
 29e19b4:	or     %r15d,%r14d
 29e19b7:	and    %r14d,%r12d
 29e19ba:	or     %r12d,%eax
 29e19bd:	movzbl %al,%eax
 29e19c0:	xor    %r13d,%r13d
 29e19c3:	mov    %r13,0x240(%rsp)
 29e19cb:	mov    0x240(%rsp),%rbx
 29e19d3:	mov    %rbx,0x1d0(%rsp)
 29e19db:	xor    %r13,%r13
 29e19de:	xor    %ebx,%ebx
 29e19e0:	xor    %r12,%r12
 29e19e3:	test   %eax,%eax
 29e19e5:	jne    29e1a10 <wasm[0]::function[1015]::helper::object_read+0xa90>
 29e19eb:	mov    %rbx,0x280(%rsp)
 29e19f3:	mov    %r12,0x288(%rsp)
 29e19fb:	mov    %rbx,0x290(%rsp)
 29e1a03:	mov    %rbx,0x298(%rsp)
 29e1a0b:	jmp    29e1b07 <wasm[0]::function[1015]::helper::object_read+0xb87>
 29e1a10:	xor    %eax,%eax
 29e1a12:	test   %r9d,%r9d
 29e1a15:	je     29e1a68 <wasm[0]::function[1015]::helper::object_read+0xae8>
 29e1a1b:	xor    %eax,%eax
 29e1a1d:	test   $0x1,%r9d
 29e1a24:	jne    29e1a68 <wasm[0]::function[1015]::helper::object_read+0xae8>
 29e1a2a:	mov    0x2e0(%rsp),%r12
 29e1a32:	mov    0x28(%r12),%rax
 29e1a37:	mov    0x20(%r12),%rdx
 29e1a3c:	mov    %r9d,%ebx
 29e1a3f:	lea    0x4(%rdx,%rbx,1),%rdx
 29e1a44:	xor    %r12,%r12
 29e1a47:	cmp    %rax,%rbx
 29e1a4a:	cmova  %r12,%rdx
 29e1a4e:	mov    (%rdx),%eax
 29e1a50:	mov    0x190(%rsp),%rdx
 29e1a58:	mov    0x28(%rdx),%rdx
 29e1a5c:	cmp    0x234(%rdx),%eax
 29e1a62:	sete   %al
 29e1a65:	movzbl %al,%eax
 29e1a68:	test   %eax,%eax
 29e1a6a:	je     29fbbd9 <wasm[0]::function[1015]::helper::object_read+0x1ac59>
 29e1a70:	test   %r9d,%r9d
 29e1a73:	je     29fbbdb <wasm[0]::function[1015]::helper::object_read+0x1ac5b>
 29e1a79:	test   %r9d,%r9d
 29e1a7c:	je     29fbbdd <wasm[0]::function[1015]::helper::object_read+0x1ac5d>
 29e1a82:	mov    0x2e0(%rsp),%r12
 29e1a8a:	mov    0x28(%r12),%rax
 29e1a8f:	mov    0x20(%r12),%rbx
 29e1a94:	mov    %r9d,%r14d
 29e1a97:	lea    (%rbx,%r14,1),%rdx
 29e1a9b:	xor    %r12,%r12
 29e1a9e:	cmp    %rax,%r14
 29e1aa1:	cmova  %r12,%rdx
 29e1aa5:	mov    0x10(%rdx),%r14d
 29e1aa9:	xor    %edx,%edx
 29e1aab:	test   %r14d,%r14d
 29e1aae:	je     29fbbdf <wasm[0]::function[1015]::helper::object_read+0x1ac5f>
 29e1ab4:	test   %r14d,%r14d
 29e1ab7:	je     29fbbe1 <wasm[0]::function[1015]::helper::object_read+0x1ac61>
 29e1abd:	mov    %r14d,%r15d
 29e1ac0:	lea    0x10(%rbx,%r15,1),%r14
 29e1ac5:	cmp    %rax,%r15
 29e1ac8:	cmova  %r12,%r14
 29e1acc:	mov    $0x1,%ebx
 29e1ad1:	mov    $0x3,%eax
 29e1ad6:	mov    %rax,0x280(%rsp)
 29e1ade:	xorpd  %xmm0,%xmm0
 29e1ae2:	mov    (%r14),%eax
 29e1ae5:	cvtsi2sd %rax,%xmm0
 29e1aea:	movq   %xmm0,%r12
 29e1aef:	mov    %r12,0x288(%rsp)
 29e1af7:	mov    %rdx,0x290(%rsp)
 29e1aff:	mov    %rdx,0x298(%rsp)
 29e1b07:	mov    %esi,0x50(%rsp)
 29e1b0b:	mov    %ecx,0x70(%rsp)
 29e1b0f:	mov    %edi,0x60(%rsp)
 29e1b13:	mov    %r11d,0x68(%rsp)
 29e1b18:	mov    %r8d,0x140(%rsp)
 29e1b20:	mov    %r10d,0xd0(%rsp)
 29e1b28:	mov    %edx,0xe8(%rsp)
 29e1b2f:	test   %ebx,%ebx
 29e1b31:	je     29e1b47 <wasm[0]::function[1015]::helper::object_read+0xbc7>
 29e1b37:	mov    %rdx,%rax
 29e1b3a:	mov    0x290(%rsp),%rsi
 29e1b42:	jmp    29fa49a <wasm[0]::function[1015]::helper::object_read+0x1951a>
 29e1b47:	mov    0x190(%rsp),%rcx
 29e1b4f:	mov    0x8c0(%rcx),%edx
 29e1b55:	test   %edx,%edx
 29e1b57:	je     29fbbe3 <wasm[0]::function[1015]::helper::object_read+0x1ac63>
 29e1b5d:	mov    0x198(%rsp),%rcx
 29e1b65:	mov    0x1a0(%rsp),%r8
 29e1b6d:	mov    0x190(%rsp),%rsi
 29e1b75:	mov    0x190(%rsp),%rdi
 29e1b7d:	call   2a631a0 <wasm[0]::function[1041]::helper::value_to_object>
 29e1b82:	mov    %rax,0x2d0(%rsp)
 29e1b8a:	mov    %rcx,0x2d8(%rsp)
 29e1b92:	mov    %edx,0x40(%rsp)
 29e1b96:	mov    $0x1,%eax
 29e1b9b:	mov    %rax,0x278(%rsp)
 29e1ba3:	cmp    $0x1,%esi
 29e1ba6:	je     29fa46f <wasm[0]::function[1015]::helper::object_read+0x194ef>
 29e1bac:	xor    %eax,%eax
 29e1bae:	test   %edx,%edx
 29e1bb0:	je     29e1c01 <wasm[0]::function[1015]::helper::object_read+0xc81>
 29e1bb6:	xor    %eax,%eax
 29e1bb8:	test   $0x1,%edx
 29e1bbe:	jne    29e1c01 <wasm[0]::function[1015]::helper::object_read+0xc81>
 29e1bc4:	mov    0x2e0(%rsp),%r12
 29e1bcc:	mov    0x28(%r12),%rax
 29e1bd1:	mov    0x20(%r12),%rcx
 29e1bd6:	mov    %edx,%esi
 29e1bd8:	lea    0x4(%rcx,%rsi,1),%rcx
 29e1bdd:	xor    %rdi,%rdi
 29e1be0:	cmp    %rax,%rsi
 29e1be3:	cmova  %rdi,%rcx
 29e1be7:	mov    (%rcx),%eax
 29e1be9:	mov    0x190(%rsp),%rcx
 29e1bf1:	mov    0x28(%rcx),%rcx
 29e1bf5:	cmp    0x1e8(%rcx),%eax
 29e1bfb:	sete   %al
 29e1bfe:	movzbl %al,%eax
 29e1c01:	test   %eax,%eax
 29e1c03:	jne    29efc12 <wasm[0]::function[1015]::helper::object_read+0xec92>
 29e1c09:	xor    %eax,%eax
 29e1c0b:	movl   $0x0,0x100(%rsp)
 29e1c16:	test   %edx,%edx
 29e1c18:	je     29e1c6c <wasm[0]::function[1015]::helper::object_read+0xcec>
 29e1c1e:	xor    %eax,%eax
 29e1c20:	test   $0x1,%edx
 29e1c26:	jne    29e1c6c <wasm[0]::function[1015]::helper::object_read+0xcec>
 29e1c2c:	mov    0x2e0(%rsp),%r12
 29e1c34:	mov    0x28(%r12),%r10
 29e1c39:	mov    0x20(%r12),%rax
 29e1c3e:	mov    %edx,%r11d
 29e1c41:	lea    0x4(%rax,%r11,1),%rdi
 29e1c46:	xor    %rax,%rax
 29e1c49:	cmp    %r10,%r11
 29e1c4c:	cmova  %rax,%rdi
 29e1c50:	mov    (%rdi),%r11d
 29e1c53:	mov    0x190(%rsp),%rcx
 29e1c5b:	mov    0x28(%rcx),%rax
 29e1c5f:	cmp    0x138(%rax),%r11d
 29e1c66:	sete   %al
 29e1c69:	movzbl %al,%eax
 29e1c6c:	test   %eax,%eax
 29e1c6e:	jne    29e1e16 <wasm[0]::function[1015]::helper::object_read+0xe96>
 29e1c74:	xor    %r9d,%r9d
 29e1c77:	test   %edx,%edx
 29e1c79:	je     29e1ccc <wasm[0]::function[1015]::helper::object_read+0xd4c>
 29e1c7f:	xor    %r9d,%r9d
 29e1c82:	test   $0x1,%edx
 29e1c88:	jne    29e1ccc <wasm[0]::function[1015]::helper::object_read+0xd4c>
 29e1c8e:	mov    0x2e0(%rsp),%r12
 29e1c96:	mov    0x28(%r12),%rax
 29e1c9b:	mov    0x20(%r12),%rcx
 29e1ca0:	mov    %edx,%esi
 29e1ca2:	lea    0x4(%rcx,%rsi,1),%rcx
 29e1ca7:	xor    %rdi,%rdi
 29e1caa:	cmp    %rax,%rsi
 29e1cad:	cmova  %rdi,%rcx
 29e1cb1:	mov    (%rcx),%eax
 29e1cb3:	mov    0x190(%rsp),%rcx
 29e1cbb:	mov    0x28(%rcx),%rcx
 29e1cbf:	cmp    0x1d4(%rcx),%eax
 29e1cc5:	sete   %al
 29e1cc8:	movzbl %al,%r9d
 29e1ccc:	xor    %esi,%esi
 29e1cce:	test   %r9d,%r9d
 29e1cd1:	je     29e1e77 <wasm[0]::function[1015]::helper::object_read+0xef7>
 29e1cd7:	xor    %eax,%eax
 29e1cd9:	test   %edx,%edx
 29e1cdb:	je     29e1d2c <wasm[0]::function[1015]::helper::object_read+0xdac>
 29e1ce1:	xor    %eax,%eax
 29e1ce3:	test   $0x1,%edx
 29e1ce9:	jne    29e1d2c <wasm[0]::function[1015]::helper::object_read+0xdac>
 29e1cef:	mov    0x2e0(%rsp),%r12
 29e1cf7:	mov    0x28(%r12),%rax
 29e1cfc:	mov    0x20(%r12),%rcx
 29e1d01:	mov    %edx,%esi
 29e1d03:	lea    0x4(%rcx,%rsi,1),%rcx
 29e1d08:	xor    %rdi,%rdi
 29e1d0b:	cmp    %rax,%rsi
 29e1d0e:	cmova  %rdi,%rcx
 29e1d12:	mov    (%rcx),%eax
 29e1d14:	mov    0x190(%rsp),%rcx
 29e1d1c:	mov    0x28(%rcx),%rcx
 29e1d20:	cmp    0x1d4(%rcx),%eax
 29e1d26:	sete   %al
 29e1d29:	movzbl %al,%eax
 29e1d2c:	test   %eax,%eax
 29e1d2e:	je     29fbbe5 <wasm[0]::function[1015]::helper::object_read+0x1ac65>
 29e1d34:	test   %edx,%edx
 29e1d36:	je     29fbbe7 <wasm[0]::function[1015]::helper::object_read+0x1ac67>
 29e1d3c:	test   %edx,%edx
 29e1d3e:	je     29fbbe9 <wasm[0]::function[1015]::helper::object_read+0x1ac69>
 29e1d44:	mov    0x2e0(%rsp),%r12
 29e1d4c:	mov    0x28(%r12),%rax
 29e1d51:	mov    0x20(%r12),%rcx
 29e1d56:	mov    %edx,%edi
 29e1d58:	lea    (%rcx,%rdi,1),%rsi
 29e1d5c:	xor    %rdx,%rdx
 29e1d5f:	cmp    %rax,%rdi
 29e1d62:	cmova  %rdx,%rsi
 29e1d66:	mov    0x10(%rsi),%esi
 29e1d69:	mov    %esi,0x78(%rsp)
 29e1d6d:	test   %esi,%esi
 29e1d6f:	je     29fbbeb <wasm[0]::function[1015]::helper::object_read+0x1ac6b>
 29e1d75:	test   %esi,%esi
 29e1d77:	je     29fbbed <wasm[0]::function[1015]::helper::object_read+0x1ac6d>
 29e1d7d:	mov    %esi,%esi
 29e1d7f:	add    %rsi,%rcx
 29e1d82:	cmp    %rax,%rsi
 29e1d85:	cmova  %rdx,%rcx
 29e1d89:	mov    0x14(%rcx),%ecx
 29e1d8c:	test   %ecx,%ecx
 29e1d8e:	je     29fbbef <wasm[0]::function[1015]::helper::object_read+0x1ac6f>
 29e1d94:	xor    %eax,%eax
 29e1d96:	test   $0x1,%ecx
 29e1d9c:	jne    29e1df6 <wasm[0]::function[1015]::helper::object_read+0xe76>
 29e1da2:	mov    0x2e0(%rsp),%r12
 29e1daa:	mov    0x28(%r12),%rax
 29e1daf:	mov    0x20(%r12),%rsi
 29e1db4:	mov    %ecx,%edx
 29e1db6:	lea    0x4(%rsi,%rdx,1),%rcx
 29e1dbb:	xor    %rsi,%rsi
 29e1dbe:	cmp    %rax,%rdx
 29e1dc1:	cmova  %rsi,%rcx
 29e1dc5:	mov    (%rcx),%esi
 29e1dc7:	mov    0x190(%rsp),%rcx
 29e1dcf:	mov    0x28(%rcx),%rax
 29e1dd3:	mov    0x158(%rax),%edx
 29e1dd9:	cmp    %edx,%esi
 29e1ddb:	sete   %al
 29e1dde:	movzbl %al,%eax
 29e1de1:	cmp    %edx,%esi
 29e1de3:	je     29e1df6 <wasm[0]::function[1015]::helper::object_read+0xe76>
 29e1de9:	mov    0x190(%rsp),%rdi
 29e1df1:	call   3018cd5 <wasmtime_builtin_is_subtype>
 29e1df6:	mov    0x100(%rsp),%esi
 29e1dfd:	test   %eax,%eax
 29e1dff:	je     29e1e77 <wasm[0]::function[1015]::helper::object_read+0xef7>
 29e1e05:	mov    0x78(%rsp),%esi
 29e1e09:	test   %esi,%esi
 29e1e0b:	je     29fbbf1 <wasm[0]::function[1015]::helper::object_read+0x1ac71>
 29e1e11:	jmp    29e1e77 <wasm[0]::function[1015]::helper::object_read+0xef7>
 29e1e16:	xor    %eax,%eax
 29e1e18:	test   %edx,%edx
 29e1e1a:	je     29e1e6c <wasm[0]::function[1015]::helper::object_read+0xeec>
 29e1e20:	xor    %eax,%eax
 29e1e22:	test   $0x1,%edx
 29e1e28:	jne    29e1e6c <wasm[0]::function[1015]::helper::object_read+0xeec>
 29e1e2e:	mov    0x2e0(%rsp),%r12
 29e1e36:	mov    0x28(%r12),%rax
 29e1e3b:	mov    0x20(%r12),%rsi
 29e1e40:	mov    %edx,%ecx
 29e1e42:	lea    0x4(%rsi,%rcx,1),%r10
 29e1e47:	xor    %rsi,%rsi
 29e1e4a:	cmp    %rax,%rcx
 29e1e4d:	cmova  %rsi,%r10
 29e1e51:	mov    (%r10),%eax
 29e1e54:	mov    0x190(%rsp),%rcx
 29e1e5c:	mov    0x28(%rcx),%rcx
 29e1e60:	cmp    0x138(%rcx),%eax
 29e1e66:	sete   %al
 29e1e69:	movzbl %al,%eax
 29e1e6c:	test   %eax,%eax
 29e1e6e:	je     29fbbf3 <wasm[0]::function[1015]::helper::object_read+0x1ac73>
 29e1e74:	mov    %rdx,%rsi
 29e1e77:	mov    %esi,0x78(%rsp)
 29e1e7b:	mov    0x40(%rsp),%edx
 29e1e7f:	mov    %rdx,0x210(%rsp)
 29e1e87:	mov    0x68(%rsp),%r9d
 29e1e8c:	mov    0xd0(%rsp),%r8d
 29e1e94:	mov    0x50(%rsp),%r14d
 29e1e99:	mov    %r14,0x208(%rsp)
 29e1ea1:	mov    0x70(%rsp),%r14d
 29e1ea6:	mov    0x60(%rsp),%edi
 29e1eaa:	mov    0xe8(%rsp),%edx
 29e1eb1:	xor    %eax,%eax
 29e1eb3:	test   %esi,%esi
 29e1eb5:	jne    29e1ed8 <wasm[0]::function[1015]::helper::object_read+0xf58>
 29e1ebb:	mov    0x210(%rsp),%rcx
 29e1ec3:	mov    %rax,0x1e0(%rsp)
 29e1ecb:	mov    %rax,0x200(%rsp)
 29e1ed3:	jmp    29e2c3d <wasm[0]::function[1015]::helper::object_read+0x1cbd>
 29e1ed8:	test   %esi,%esi
 29e1eda:	je     29fbbf5 <wasm[0]::function[1015]::helper::object_read+0x1ac75>
 29e1ee0:	test   %esi,%esi
 29e1ee2:	je     29fbbf7 <wasm[0]::function[1015]::helper::object_read+0x1ac77>
 29e1ee8:	mov    0x2e0(%rsp),%r12
 29e1ef0:	mov    0x28(%r12),%rax
 29e1ef5:	mov    0x20(%r12),%rcx
 29e1efa:	mov    %esi,%edx
 29e1efc:	add    %rdx,%rcx
 29e1eff:	xor    %rsi,%rsi
 29e1f02:	cmp    %rax,%rdx
 29e1f05:	cmova  %rsi,%rcx
 29e1f09:	mov    0x14(%rcx),%eax
 29e1f0c:	mov    %eax,0x100(%rsp)
 29e1f13:	test   %eax,%eax
 29e1f15:	je     29fbbf9 <wasm[0]::function[1015]::helper::object_read+0x1ac79>
 29e1f1b:	mov    0x100(%rsp),%ecx
 29e1f22:	xor    %eax,%eax
 29e1f24:	test   $0x1,%ecx
 29e1f2a:	jne    29e1f84 <wasm[0]::function[1015]::helper::object_read+0x1004>
 29e1f30:	mov    0x2e0(%rsp),%r12
 29e1f38:	mov    0x28(%r12),%rax
 29e1f3d:	mov    0x20(%r12),%rsi
 29e1f42:	mov    %ecx,%edx
 29e1f44:	lea    0x4(%rsi,%rdx,1),%rcx
 29e1f49:	xor    %rsi,%rsi
 29e1f4c:	cmp    %rax,%rdx
 29e1f4f:	cmova  %rsi,%rcx
 29e1f53:	mov    (%rcx),%esi
 29e1f55:	mov    0x190(%rsp),%rcx
 29e1f5d:	mov    0x28(%rcx),%rax
 29e1f61:	mov    0x158(%rax),%edx
 29e1f67:	cmp    %edx,%esi
 29e1f69:	sete   %al
 29e1f6c:	movzbl %al,%eax
 29e1f6f:	cmp    %edx,%esi
 29e1f71:	je     29e1f84 <wasm[0]::function[1015]::helper::object_read+0x1004>
 29e1f77:	mov    0x190(%rsp),%rdi
 29e1f7f:	call   3018cd5 <wasmtime_builtin_is_subtype>
 29e1f84:	test   %eax,%eax
 29e1f86:	jne    29e221b <wasm[0]::function[1015]::helper::object_read+0x129b>
 29e1f8c:	mov    0x78(%rsp),%edx
 29e1f90:	xor    %ebx,%ebx
 29e1f92:	test   %edx,%edx
 29e1f94:	je     29fbbfb <wasm[0]::function[1015]::helper::object_read+0x1ac7b>
 29e1f9a:	mov    0x68(%rsp),%r9d
 29e1f9f:	mov    0x1b8(%rsp),%rcx
 29e1fa7:	mov    0x190(%rsp),%rsi
 29e1faf:	mov    0x190(%rsp),%rdi
 29e1fb7:	mov    0x1c0(%rsp),%r8
 29e1fbf:	call   2a58e80 <wasm[0]::function[1032]::helper::ordinary_property_find>
 29e1fc4:	test   %eax,%eax
 29e1fc6:	je     29e2000 <wasm[0]::function[1015]::helper::object_read+0x1080>
 29e1fcc:	test   %eax,%eax
 29e1fce:	je     29fbbfd <wasm[0]::function[1015]::helper::object_read+0x1ac7d>
 29e1fd4:	test   %eax,%eax
 29e1fd6:	je     29fbbff <wasm[0]::function[1015]::helper::object_read+0x1ac7f>
 29e1fdc:	mov    0x2e0(%rsp),%r12
 29e1fe4:	mov    0x28(%r12),%rcx
 29e1fe9:	mov    %eax,%edx
 29e1feb:	mov    %rdx,%rax
 29e1fee:	add    0x20(%r12),%rax
 29e1ff3:	xor    %rsi,%rsi
 29e1ff6:	cmp    %rcx,%rdx
 29e1ff9:	cmova  %rsi,%rax
 29e1ffd:	mov    0x14(%rax),%ebx
 29e2000:	mov    0x140(%rsp),%edx
 29e2007:	xor    %eax,%eax
 29e2009:	test   %ebx,%ebx
 29e200b:	je     29e21ab <wasm[0]::function[1015]::helper::object_read+0x122b>
 29e2011:	test   %ebx,%ebx
 29e2013:	je     29fbc01 <wasm[0]::function[1015]::helper::object_read+0x1ac81>
 29e2019:	mov    0x2e0(%rsp),%r12
 29e2021:	mov    0x28(%r12),%rax
 29e2026:	mov    0x20(%r12),%rcx
 29e202b:	mov    %ebx,%edx
 29e202d:	add    %rdx,%rcx
 29e2030:	xor    %rsi,%rsi
 29e2033:	cmp    %rax,%rdx
 29e2036:	cmova  %rsi,%rcx
 29e203a:	mov    0x10(%rcx),%esi
 29e203d:	mov    0x140(%rsp),%edx
 29e2044:	xor    %eax,%eax
 29e2046:	test   $0x1,%esi
 29e204c:	jne    29e21ab <wasm[0]::function[1015]::helper::object_read+0x122b>
 29e2052:	mov    0x14(%rcx),%edx
 29e2055:	test   %edx,%edx
 29e2057:	je     29fbc03 <wasm[0]::function[1015]::helper::object_read+0x1ac83>
 29e205d:	xor    %eax,%eax
 29e205f:	test   $0x1,%edx
 29e2065:	jne    29e20ad <wasm[0]::function[1015]::helper::object_read+0x112d>
 29e206b:	mov    0x2e0(%rsp),%r12
 29e2073:	mov    0x28(%r12),%rdi
 29e2078:	mov    0x20(%r12),%r9
 29e207d:	mov    %edx,%r8d
 29e2080:	lea    0x4(%r9,%r8,1),%rsi
 29e2085:	xor    %r9,%r9
 29e2088:	cmp    %rdi,%r8
 29e208b:	cmova  %r9,%rsi
 29e208f:	mov    (%rsi),%r8d
 29e2092:	mov    0x190(%rsp),%rcx
 29e209a:	mov    0x28(%rcx),%r9
 29e209e:	cmp    0x120(%r9),%r8d
 29e20a5:	sete   %r9b
 29e20a9:	movzbl %r9b,%eax
 29e20ad:	test   %eax,%eax
 29e20af:	jne    29e2114 <wasm[0]::function[1015]::helper::object_read+0x1194>
 29e20b5:	mov    0x190(%rsp),%rsi
 29e20bd:	mov    0x190(%rsp),%rdi
 29e20c5:	call   2a01c00 <wasm[0]::function[1024]::helper::property_value_resolve>
 29e20ca:	test   %eax,%eax
 29e20cc:	je     29fbc05 <wasm[0]::function[1015]::helper::object_read+0x1ac85>
 29e20d2:	test   %eax,%eax
 29e20d4:	je     29fbc07 <wasm[0]::function[1015]::helper::object_read+0x1ac87>
 29e20da:	mov    0x2e0(%rsp),%r12
 29e20e2:	mov    0x28(%r12),%rcx
 29e20e7:	mov    0x20(%r12),%rsi
 29e20ec:	mov    %eax,%edx
 29e20ee:	lea    (%rsi,%rdx,1),%rax
 29e20f2:	xor    %rsi,%rsi
 29e20f5:	cmp    %rcx,%rdx
 29e20f8:	cmova  %rsi,%rax
 29e20fc:	mov    0x18(%rax),%r13d
 29e2100:	mov    %r13,0x1d0(%rsp)
 29e2108:	mov    0x10(%rax),%r13
 29e210c:	mov    0x1c(%rax),%edx
 29e210f:	jmp    29e21a3 <wasm[0]::function[1015]::helper::object_read+0x1223>
 29e2114:	xor    %eax,%eax
 29e2116:	test   $0x1,%edx
 29e211c:	jne    29e215f <wasm[0]::function[1015]::helper::object_read+0x11df>
 29e2122:	mov    0x2e0(%rsp),%r12
 29e212a:	mov    0x28(%r12),%rax
 29e212f:	mov    0x20(%r12),%rcx
 29e2134:	mov    %edx,%esi
 29e2136:	lea    0x4(%rcx,%rsi,1),%rcx
 29e213b:	xor    %rdi,%rdi
 29e213e:	cmp    %rax,%rsi
 29e2141:	cmova  %rdi,%rcx
 29e2145:	mov    (%rcx),%eax
 29e2147:	mov    0x190(%rsp),%rcx
 29e214f:	mov    0x28(%rcx),%rcx
 29e2153:	cmp    0x120(%rcx),%eax
 29e2159:	sete   %al
 29e215c:	movzbl %al,%eax
 29e215f:	test   %eax,%eax
 29e2161:	je     29fbc09 <wasm[0]::function[1015]::helper::object_read+0x1ac89>
 29e2167:	test   %edx,%edx
 29e2169:	je     29fbc0b <wasm[0]::function[1015]::helper::object_read+0x1ac8b>
 29e216f:	mov    0x2e0(%rsp),%r12
 29e2177:	mov    0x28(%r12),%rcx
 29e217c:	mov    0x20(%r12),%rax
 29e2181:	mov    %edx,%edx
 29e2183:	add    %rdx,%rax
 29e2186:	xor    %rsi,%rsi
 29e2189:	cmp    %rcx,%rdx
 29e218c:	cmova  %rsi,%rax
 29e2190:	mov    0x18(%rax),%r13d
 29e2194:	mov    %r13,0x1d0(%rsp)
 29e219c:	mov    0x10(%rax),%r13
 29e21a0:	mov    0x1c(%rax),%edx
 29e21a3:	mov    0x278(%rsp),%rax
 29e21ab:	mov    0x40(%rsp),%ecx
 29e21af:	mov    %rcx,0x210(%rsp)
 29e21b7:	mov    0x68(%rsp),%r9d
 29e21bc:	mov    0xd0(%rsp),%r8d
 29e21c4:	mov    0x50(%rsp),%r14d
 29e21c9:	mov    %r14,0x208(%rsp)
 29e21d1:	mov    0x70(%rsp),%r14d
 29e21d6:	mov    0x60(%rsp),%edi
 29e21da:	mov    0xe8(%rsp),%ecx
 29e21e1:	mov    %rcx,0x1a0(%rsp)
 29e21e9:	mov    %rcx,%rsi
 29e21ec:	mov    %rcx,0x1e0(%rsp)
 29e21f4:	xor    %esi,%esi
 29e21f6:	mov    %rsi,0x1e0(%rsp)
 29e21fe:	mov    0x1d0(%rsp),%r15
 29e2206:	mov    0x1e0(%rsp),%rcx
 29e220e:	mov    %rcx,0x200(%rsp)
 29e2216:	jmp    29e2be6 <wasm[0]::function[1015]::helper::object_read+0x1c66>
 29e221b:	mov    0x100(%rsp),%eax
 29e2222:	test   %eax,%eax
 29e2224:	je     29fbc0d <wasm[0]::function[1015]::helper::object_read+0x1ac8d>
 29e222a:	mov    0x100(%rsp),%ecx
 29e2231:	xor    %eax,%eax
 29e2233:	test   $0x1,%ecx
 29e2239:	jne    29e2293 <wasm[0]::function[1015]::helper::object_read+0x1313>
 29e223f:	mov    0x2e0(%rsp),%r12
 29e2247:	mov    0x28(%r12),%rax
 29e224c:	mov    0x20(%r12),%rsi
 29e2251:	mov    %ecx,%edx
 29e2253:	lea    0x4(%rsi,%rdx,1),%rcx
 29e2258:	xor    %rsi,%rsi
 29e225b:	cmp    %rax,%rdx
 29e225e:	cmova  %rsi,%rcx
 29e2262:	mov    (%rcx),%esi
 29e2264:	mov    0x190(%rsp),%rcx
 29e226c:	mov    0x28(%rcx),%rax
 29e2270:	mov    0x158(%rax),%edx
 29e2276:	cmp    %edx,%esi
 29e2278:	sete   %al
 29e227b:	movzbl %al,%eax
 29e227e:	cmp    %edx,%esi
 29e2280:	je     29e2293 <wasm[0]::function[1015]::helper::object_read+0x1313>
 29e2286:	mov    0x190(%rsp),%rdi
 29e228e:	call   3018cd5 <wasmtime_builtin_is_subtype>
 29e2293:	test   %eax,%eax
 29e2295:	je     29fbc0f <wasm[0]::function[1015]::helper::object_read+0x1ac8f>
 29e229b:	mov    0x100(%rsp),%r11d
 29e22a3:	mov    0x140(%rsp),%edx
 29e22aa:	mov    0x40(%rsp),%eax
 29e22ae:	mov    %rax,0x210(%rsp)
 29e22b6:	mov    0x68(%rsp),%r9d
 29e22bb:	mov    0xd0(%rsp),%r8d
 29e22c3:	mov    0x50(%rsp),%r14d
 29e22c8:	mov    %r14,0x208(%rsp)
 29e22d0:	mov    0x70(%rsp),%r14d
 29e22d5:	mov    0x60(%rsp),%edi
 29e22d9:	mov    0xe8(%rsp),%eax
 29e22e0:	mov    %rax,0x1a0(%rsp)
 29e22e8:	xor    %eax,%eax
 29e22ea:	mov    0x1b8(%rsp),%rcx
 29e22f2:	mov    %rax,0x1d8(%rsp)
 29e22fa:	cmp    $0x4,%ecx
 29e22fd:	je     29e2328 <wasm[0]::function[1015]::helper::object_read+0x13a8>
 29e2303:	mov    0x1d8(%rsp),%rax
 29e230b:	mov    0x1d8(%rsp),%rcx
 29e2313:	mov    %rcx,0x1e0(%rsp)
 29e231b:	mov    %rcx,0x200(%rsp)
 29e2323:	jmp    29e2764 <wasm[0]::function[1015]::helper::object_read+0x17e4>
 29e2328:	mov    %rcx,%rax
 29e232b:	mov    %rcx,0x240(%rsp)
 29e2333:	xor    %eax,%ecx
 29e2335:	mov    %rcx,0x240(%rsp)
 29e233d:	test   %r11d,%r11d
 29e2340:	je     29fbc11 <wasm[0]::function[1015]::helper::object_read+0x1ac91>
 29e2346:	test   %r11d,%r11d
 29e2349:	je     29fbc13 <wasm[0]::function[1015]::helper::object_read+0x1ac93>
 29e234f:	mov    0x2e0(%rsp),%r12
 29e2357:	mov    0x28(%r12),%rax
 29e235c:	mov    0x20(%r12),%rbx
 29e2361:	mov    %r11d,%r15d
 29e2364:	lea    (%rbx,%r15,1),%rsi
 29e2368:	xor    %r12,%r12
 29e236b:	cmp    %rax,%r15
 29e236e:	cmova  %r12,%rsi
 29e2372:	mov    0x10(%rsi),%esi
 29e2375:	test   %esi,%esi
 29e2377:	je     29fbc15 <wasm[0]::function[1015]::helper::object_read+0x1ac95>
 29e237d:	test   %esi,%esi
 29e237f:	je     29fbc17 <wasm[0]::function[1015]::helper::object_read+0x1ac97>
 29e2385:	mov    %esi,%r15d
 29e2388:	lea    (%rbx,%r15,1),%rsi
 29e238c:	cmp    %rax,%r15
 29e238f:	cmova  %r12,%rsi
 29e2393:	mov    0x10(%rsi),%esi
 29e2396:	test   %esi,%esi
 29e2398:	je     29fbc19 <wasm[0]::function[1015]::helper::object_read+0x1ac99>
 29e239e:	test   %esi,%esi
 29e23a0:	je     29fbc1b <wasm[0]::function[1015]::helper::object_read+0x1ac9b>
 29e23a6:	mov    %esi,%r15d
 29e23a9:	lea    0x10(%rbx,%r15,1),%rbx
 29e23ae:	cmp    %rax,%r15
 29e23b1:	cmova  %r12,%rbx
 29e23b5:	mov    (%rbx),%ebx
 29e23b7:	mov    0x190(%rsp),%rcx
 29e23bf:	mov    0x28(%rcx),%r10
 29e23c3:	mov    0x234(%r10),%r15d
 29e23ca:	mov    0x240(%rsp),%rax
 29e23d2:	mov    %rax,0x1d8(%rsp)
 29e23da:	mov    %rax,0x1e0(%rsp)
 29e23e2:	mov    %rax,0x200(%rsp)
 29e23ea:	mov    %esi,0xb8(%rsp)
 29e23f1:	mov    %r9d,0x80(%rsp)
 29e23f9:	mov    %r11d,0x48(%rsp)
 29e23fe:	mov    %edx,0xa8(%rsp)
 29e2405:	mov    0x210(%rsp),%rdx
 29e240d:	mov    %edx,0xa0(%rsp)
 29e2414:	mov    %r8d,0x78(%rsp)
 29e2419:	mov    0x208(%rsp),%rax
 29e2421:	mov    %eax,0xe8(%rsp)
 29e2428:	mov    %r14d,0xd0(%rsp)
 29e2430:	mov    %edi,0x140(%rsp)
 29e2437:	mov    0x1a0(%rsp),%r8
 29e243f:	mov    %r8d,0x100(%rsp)
 29e2447:	mov    0x2e8(%rsp),%rax
 29e244f:	mov    (%rax),%rcx
 29e2452:	mov    0x228(%rsp),%rax
 29e245a:	cmp    %rax,%rcx
 29e245d:	jae    29fa545 <wasm[0]::function[1015]::helper::object_read+0x195c5>
 29e2463:	mov    0x48(%rsp),%r11d
 29e2468:	mov    0xa8(%rsp),%edx
 29e246f:	mov    0xa0(%rsp),%eax
 29e2476:	mov    %rax,0x210(%rsp)
 29e247e:	mov    0x80(%rsp),%r9d
 29e2486:	mov    0x78(%rsp),%r8d
 29e248b:	mov    0xe8(%rsp),%r14d
 29e2493:	mov    %r14,0x208(%rsp)
 29e249b:	mov    0xd0(%rsp),%r14d
 29e24a3:	mov    0x140(%rsp),%edi
 29e24aa:	mov    0x100(%rsp),%r10d
 29e24b2:	mov    0x240(%rsp),%rcx
 29e24ba:	mov    %r10,0x1a0(%rsp)
 29e24c2:	cmp    %ebx,%ecx
 29e24c4:	jb     29e24d7 <wasm[0]::function[1015]::helper::object_read+0x1557>
 29e24ca:	mov    0x1d8(%rsp),%rax
 29e24d2:	jmp    29e2764 <wasm[0]::function[1015]::helper::object_read+0x17e4>
 29e24d7:	mov    0xb8(%rsp),%r11d
 29e24df:	test   %r11d,%r11d
 29e24e2:	je     29fbc1d <wasm[0]::function[1015]::helper::object_read+0x1ac9d>
 29e24e8:	test   %r11d,%r11d
 29e24eb:	je     29fbc1f <wasm[0]::function[1015]::helper::object_read+0x1ac9f>
 29e24f1:	mov    0x2e0(%rsp),%r12
 29e24f9:	mov    0x28(%r12),%rax
 29e24fe:	mov    0x20(%r12),%rcx
 29e2503:	mov    %r11d,%edi
 29e2506:	lea    0x10(%rcx,%rdi,1),%rsi
 29e250b:	xor    %rdx,%rdx
 29e250e:	cmp    %rax,%rdi
 29e2511:	cmova  %rdx,%rsi
 29e2515:	mov    (%rsi),%esi
 29e2517:	mov    0x240(%rsp),%rdi
 29e251f:	cmp    %esi,%edi
 29e2521:	jae    29fbc21 <wasm[0]::function[1015]::helper::object_read+0x1aca1>
 29e2527:	mov    %esi,%edi
 29e2529:	shl    $0x2,%rdi
 29e252d:	shr    $0x20,%rdi
 29e2531:	test   %rdi,%rdi
 29e2534:	jne    29fbc23 <wasm[0]::function[1015]::helper::object_read+0x1aca3>
 29e253a:	shl    $0x2,%esi
 29e253d:	add    $0x14,%esi
 29e2540:	jb     29fbc25 <wasm[0]::function[1015]::helper::object_read+0x1aca5>
 29e2546:	add    %esi,%r11d
 29e2549:	jb     29fbc27 <wasm[0]::function[1015]::helper::object_read+0x1aca7>
 29e254f:	mov    %r11d,%edi
 29e2552:	add    %rdi,%rcx
 29e2555:	cmp    %rax,%rdi
 29e2558:	cmova  %rdx,%rcx
 29e255c:	mov    0x240(%rsp),%rax
 29e2564:	shl    $0x2,%eax
 29e2567:	add    $0x14,%eax
 29e256d:	sub    %eax,%esi
 29e256f:	sub    %rsi,%rcx
 29e2572:	mov    (%rcx),%edx
 29e2574:	test   %edx,%edx
 29e2576:	je     29fbc29 <wasm[0]::function[1015]::helper::object_read+0x1aca9>
 29e257c:	mov    0x1b8(%rsp),%rcx
 29e2584:	cmp    $0x4,%ecx
 29e2587:	je     29e25f1 <wasm[0]::function[1015]::helper::object_read+0x1671>
 29e258d:	mov    0xb8(%rsp),%esi
 29e2594:	mov    0x80(%rsp),%r9d
 29e259c:	mov    0x48(%rsp),%r11d
 29e25a1:	mov    0xa8(%rsp),%edx
 29e25a8:	mov    0xa0(%rsp),%eax
 29e25af:	mov    %rax,0x210(%rsp)
 29e25b7:	mov    0x78(%rsp),%r8d
 29e25bc:	mov    0xe8(%rsp),%r14d
 29e25c4:	mov    %r14,0x208(%rsp)
 29e25cc:	mov    0xd0(%rsp),%r14d
 29e25d4:	mov    0x140(%rsp),%edi
 29e25db:	mov    0x100(%rsp),%eax
 29e25e2:	mov    %rax,0x1a0(%rsp)
 29e25ea:	xor    %eax,%eax
 29e25ec:	jmp    29e2739 <wasm[0]::function[1015]::helper::object_read+0x17b9>
 29e25f1:	mov    0x80(%rsp),%eax
 29e25f8:	cmp    %eax,%edx
 29e25fa:	je     29e26d3 <wasm[0]::function[1015]::helper::object_read+0x1753>
 29e2600:	xor    %ecx,%ecx
 29e2602:	test   %edx,%edx
 29e2604:	je     29e2646 <wasm[0]::function[1015]::helper::object_read+0x16c6>
 29e260a:	xor    %ecx,%ecx
 29e260c:	test   $0x1,%edx
 29e2612:	jne    29e2646 <wasm[0]::function[1015]::helper::object_read+0x16c6>
 29e2618:	mov    0x2e0(%rsp),%r12
 29e2620:	mov    0x28(%r12),%rcx
 29e2625:	mov    0x20(%r12),%rsi
 29e262a:	mov    %edx,%edi
 29e262c:	lea    0x4(%rsi,%rdi,1),%rsi
 29e2631:	xor    %r8,%r8
 29e2634:	cmp    %rcx,%rdi
 29e2637:	cmova  %r8,%rsi
 29e263b:	mov    (%rsi),%ecx
 29e263d:	cmp    %r15d,%ecx
 29e2640:	sete   %cl
 29e2643:	movzbl %cl,%ecx
 29e2646:	test   %ecx,%ecx
 29e2648:	je     29fbc2b <wasm[0]::function[1015]::helper::object_read+0x1acab>
 29e264e:	xor    %r9d,%r9d
 29e2651:	test   %eax,%eax
 29e2653:	je     29e269e <wasm[0]::function[1015]::helper::object_read+0x171e>
 29e2659:	mov    0x80(%rsp),%eax
 29e2660:	xor    %r9d,%r9d
 29e2663:	test   $0x1,%eax
 29e2668:	jne    29e269e <wasm[0]::function[1015]::helper::object_read+0x171e>
 29e266e:	mov    0x2e0(%rsp),%r12
 29e2676:	mov    0x28(%r12),%rcx
 29e267b:	mov    0x20(%r12),%rdi
 29e2680:	mov    %eax,%esi
 29e2682:	lea    0x4(%rdi,%rsi,1),%rax
 29e2687:	xor    %rdi,%rdi
 29e268a:	cmp    %rcx,%rsi
 29e268d:	cmova  %rdi,%rax
 29e2691:	mov    (%rax),%ecx
 29e2693:	cmp    %r15d,%ecx
 29e2696:	sete   %sil
 29e269a:	movzbl %sil,%r9d
 29e269e:	test   %r9d,%r9d
 29e26a1:	je     29fbc2d <wasm[0]::function[1015]::helper::object_read+0x1acad>
 29e26a7:	mov    0x80(%rsp),%ecx
 29e26ae:	xor    %r8d,%r8d
 29e26b1:	test   %ecx,%ecx
 29e26b3:	je     29fbc2f <wasm[0]::function[1015]::helper::object_read+0x1acaf>
 29e26b9:	mov    0x190(%rsp),%rsi
 29e26c1:	mov    0x190(%rsp),%rdi
 29e26c9:	call   2ae5540 <wasm[0]::function[1057]::helper::string_equality>
 29e26ce:	jmp    29e26db <wasm[0]::function[1015]::helper::object_read+0x175b>
 29e26d3:	mov    0x278(%rsp),%rax
 29e26db:	mov    0xb8(%rsp),%esi
 29e26e2:	mov    0x80(%rsp),%r9d
 29e26ea:	mov    0x48(%rsp),%r11d
 29e26ef:	mov    0xa8(%rsp),%edx
 29e26f6:	mov    0xa0(%rsp),%ecx
 29e26fd:	mov    %rcx,0x210(%rsp)
 29e2705:	mov    0x78(%rsp),%r8d
 29e270a:	mov    0xe8(%rsp),%r14d
 29e2712:	mov    %r14,0x208(%rsp)
 29e271a:	mov    0xd0(%rsp),%r14d
 29e2722:	mov    0x140(%rsp),%edi
 29e2729:	mov    0x100(%rsp),%r10d
 29e2731:	mov    %r10,0x1a0(%rsp)
 29e2739:	test   %eax,%eax
 29e273b:	jne    29e2764 <wasm[0]::function[1015]::helper::object_read+0x17e4>
 29e2741:	mov    0x240(%rsp),%rcx
 29e2749:	add    $0x1,%ecx
 29e274f:	mov    %rcx,0x240(%rsp)
 29e2757:	mov    %rax,0x1d8(%rsp)
 29e275f:	jmp    29e23ea <wasm[0]::function[1015]::helper::object_read+0x146a>
 29e2764:	test   %eax,%eax
 29e2766:	jne    29e2779 <wasm[0]::function[1015]::helper::object_read+0x17f9>
 29e276c:	mov    0x1d0(%rsp),%r15
 29e2774:	jmp    29e2be6 <wasm[0]::function[1015]::helper::object_read+0x1c66>
 29e2779:	test   %r11d,%r11d
 29e277c:	je     29fbc31 <wasm[0]::function[1015]::helper::object_read+0x1acb1>
 29e2782:	xor    %edx,%edx
 29e2784:	test   $0x1,%r11d
 29e278b:	jne    29e27cf <wasm[0]::function[1015]::helper::object_read+0x184f>
 29e2791:	mov    0x2e0(%rsp),%r12
 29e2799:	mov    0x28(%r12),%rdx
 29e279e:	mov    0x20(%r12),%rsi
 29e27a3:	mov    %r11d,%ebx
 29e27a6:	lea    0x4(%rsi,%rbx,1),%rsi
 29e27ab:	xor    %r12,%r12
 29e27ae:	cmp    %rdx,%rbx
 29e27b1:	cmova  %r12,%rsi
 29e27b5:	mov    (%rsi),%edx
 29e27b7:	mov    0x190(%rsp),%rcx
 29e27bf:	mov    0x28(%rcx),%rcx
 29e27c3:	cmp    0x160(%rcx),%edx
 29e27c9:	sete   %cl
 29e27cc:	movzbl %cl,%edx
 29e27cf:	test   %edx,%edx
 29e27d1:	jne    29e2a3e <wasm[0]::function[1015]::helper::object_read+0x1abe>
 29e27d7:	xor    %edx,%edx
 29e27d9:	test   $0x1,%r11d
 29e27e0:	jne    29e2824 <wasm[0]::function[1015]::helper::object_read+0x18a4>
 29e27e6:	mov    0x2e0(%rsp),%r12
 29e27ee:	mov    0x28(%r12),%rdx
 29e27f3:	mov    0x20(%r12),%rsi
 29e27f8:	mov    %r11d,%ebx
 29e27fb:	lea    0x4(%rsi,%rbx,1),%rsi
 29e2800:	xor    %r12,%r12
 29e2803:	cmp    %rdx,%rbx
 29e2806:	cmova  %r12,%rsi
 29e280a:	mov    (%rsi),%edx
 29e280c:	mov    0x190(%rsp),%rcx
 29e2814:	mov    0x28(%rcx),%rcx
 29e2818:	cmp    0x15c(%rcx),%edx
 29e281e:	sete   %cl
 29e2821:	movzbl %cl,%edx
 29e2824:	test   %edx,%edx
 29e2826:	je     29fbc33 <wasm[0]::function[1015]::helper::object_read+0x1acb3>
 29e282c:	test   %r11d,%r11d
 29e282f:	je     29fbc35 <wasm[0]::function[1015]::helper::object_read+0x1acb5>
 29e2835:	mov    0x2e0(%rsp),%r12
 29e283d:	mov    0x28(%r12),%rbx
 29e2842:	mov    0x20(%r12),%r12
 29e2847:	mov    %r11d,%edx
 29e284a:	lea    (%r12,%rdx,1),%rsi
 29e284e:	xor    %r13,%r13
 29e2851:	cmp    %rbx,%rdx
 29e2854:	cmova  %r13,%rsi
 29e2858:	mov    0x14(%rsi),%r11d
 29e285c:	mov    0x18(%rsi),%edx
 29e285f:	mov    0x1c(%rsi),%esi
 29e2862:	test   %r11d,%r11d
 29e2865:	je     29fbc37 <wasm[0]::function[1015]::helper::object_read+0x1acb7>
 29e286b:	test   %r11d,%r11d
 29e286e:	je     29fbc39 <wasm[0]::function[1015]::helper::object_read+0x1acb9>
 29e2874:	mov    %r11d,%r10d
 29e2877:	lea    0x10(%r12,%r10,1),%r15
 29e287c:	cmp    %rbx,%r10
 29e287f:	cmova  %r13,%r15
 29e2883:	mov    (%r15),%r15d
 29e2886:	mov    0x240(%rsp),%rcx
 29e288e:	cmp    %r15d,%ecx
 29e2891:	jae    29fbc3b <wasm[0]::function[1015]::helper::object_read+0x1acbb>
 29e2897:	mov    %r15d,%r10d
 29e289a:	shr    $0x20,%r10
 29e289e:	test   %r10,%r10
 29e28a1:	jne    29fbc3d <wasm[0]::function[1015]::helper::object_read+0x1acbd>
 29e28a7:	add    $0x14,%r15d
 29e28ab:	jb     29fbc3f <wasm[0]::function[1015]::helper::object_read+0x1acbf>
 29e28b1:	add    %r15d,%r11d
 29e28b4:	jb     29fbc41 <wasm[0]::function[1015]::helper::object_read+0x1acc1>
 29e28ba:	mov    %r11d,%r10d
 29e28bd:	lea    (%r12,%r10,1),%r11
 29e28c1:	cmp    %rbx,%r10
 29e28c4:	cmova  %r13,%r11
 29e28c8:	lea    0x14(%rcx),%r10d
 29e28cc:	sub    %r10d,%r15d
 29e28cf:	sub    %r15,%r11
 29e28d2:	movzbq (%r11),%r10
 29e28d6:	mov    %r10,0x248(%rsp)
 29e28de:	test   %edx,%edx
 29e28e0:	je     29e297e <wasm[0]::function[1015]::helper::object_read+0x19fe>
 29e28e6:	test   %edx,%edx
 29e28e8:	je     29fbc43 <wasm[0]::function[1015]::helper::object_read+0x1acc3>
 29e28ee:	test   %edx,%edx
 29e28f0:	je     29fbc45 <wasm[0]::function[1015]::helper::object_read+0x1acc5>
 29e28f6:	mov    0x2e0(%rsp),%r12
 29e28fe:	mov    0x28(%r12),%rbx
 29e2903:	mov    0x20(%r12),%r12
 29e2908:	mov    %edx,%r11d
 29e290b:	lea    0x10(%r12,%r11,1),%r15
 29e2910:	xor    %r13,%r13
 29e2913:	cmp    %rbx,%r11
 29e2916:	cmova  %r13,%r15
 29e291a:	mov    (%r15),%r15d
 29e291d:	mov    0x240(%rsp),%rcx
 29e2925:	cmp    %r15d,%ecx
 29e2928:	jae    29fbc47 <wasm[0]::function[1015]::helper::object_read+0x1acc7>
 29e292e:	mov    %r15d,%r11d
 29e2931:	shl    $0x3,%r11
 29e2935:	shr    $0x20,%r11
 29e2939:	test   %r11,%r11
 29e293c:	jne    29fbc49 <wasm[0]::function[1015]::helper::object_read+0x1acc9>
 29e2942:	shl    $0x3,%r15d
 29e2946:	add    $0x18,%r15d
 29e294a:	jb     29fbc4b <wasm[0]::function[1015]::helper::object_read+0x1accb>
 29e2950:	add    %r15d,%edx
 29e2953:	jb     29fbc4d <wasm[0]::function[1015]::helper::object_read+0x1accd>
 29e2959:	mov    %edx,%r10d
 29e295c:	lea    (%r12,%r10,1),%rdx
 29e2960:	cmp    %rbx,%r10
 29e2963:	cmova  %r13,%rdx
 29e2967:	mov    %rcx,%r10
 29e296a:	shl    $0x3,%r10d
 29e296e:	add    $0x18,%r10d
 29e2975:	sub    %r10d,%r15d
 29e2978:	sub    %r15,%rdx
 29e297b:	mov    (%rdx),%r13
 29e297e:	xor    %edx,%edx
 29e2980:	test   %esi,%esi
 29e2982:	jne    29e2995 <wasm[0]::function[1015]::helper::object_read+0x1a15>
 29e2988:	mov    0x248(%rsp),%r10
 29e2990:	jmp    29e2a35 <wasm[0]::function[1015]::helper::object_read+0x1ab5>
 29e2995:	test   %esi,%esi
 29e2997:	je     29fbc4f <wasm[0]::function[1015]::helper::object_read+0x1accf>
 29e299d:	test   %esi,%esi
 29e299f:	je     29fbc51 <wasm[0]::function[1015]::helper::object_read+0x1acd1>
 29e29a5:	mov    0x2e0(%rsp),%r12
 29e29ad:	mov    0x28(%r12),%rdx
 29e29b2:	mov    0x20(%r12),%r15
 29e29b7:	mov    %esi,%r11d
 29e29ba:	lea    0x10(%r15,%r11,1),%r12
 29e29bf:	xor    %rbx,%rbx
 29e29c2:	cmp    %rdx,%r11
 29e29c5:	cmova  %rbx,%r12
 29e29c9:	mov    (%r12),%r12d
 29e29cd:	mov    0x240(%rsp),%rcx
 29e29d5:	cmp    %r12d,%ecx
 29e29d8:	jae    29fbc53 <wasm[0]::function[1015]::helper::object_read+0x1acd3>
 29e29de:	mov    %r12d,%r11d
 29e29e1:	shl    $0x2,%r11
 29e29e5:	shr    $0x20,%r11
 29e29e9:	test   %r11,%r11
 29e29ec:	jne    29fbc55 <wasm[0]::function[1015]::helper::object_read+0x1acd5>
 29e29f2:	shl    $0x2,%r12d
 29e29f6:	add    $0x14,%r12d
 29e29fa:	jb     29fbc57 <wasm[0]::function[1015]::helper::object_read+0x1acd7>
 29e2a00:	add    %r12d,%esi
 29e2a03:	jb     29fbc59 <wasm[0]::function[1015]::helper::object_read+0x1acd9>
 29e2a09:	mov    %esi,%r10d
 29e2a0c:	lea    (%r15,%r10,1),%rsi
 29e2a10:	cmp    %rdx,%r10
 29e2a13:	cmova  %rbx,%rsi
 29e2a17:	shl    $0x2,%ecx
 29e2a1a:	mov    %rcx,0x240(%rsp)
 29e2a22:	lea    0x14(%rcx),%edx
 29e2a25:	sub    %edx,%r12d
 29e2a28:	sub    %r12,%rsi
 29e2a2b:	mov    (%rsi),%edx
 29e2a2d:	mov    0x248(%rsp),%r10
 29e2a35:	movzbl %r10b,%r15d
 29e2a39:	jmp    29e2be6 <wasm[0]::function[1015]::helper::object_read+0x1c66>
 29e2a3e:	xor    %edx,%edx
 29e2a40:	test   $0x1,%r11d
 29e2a47:	jne    29e2a8b <wasm[0]::function[1015]::helper::object_read+0x1b0b>
 29e2a4d:	mov    0x2e0(%rsp),%r12
 29e2a55:	mov    0x28(%r12),%rdx
 29e2a5a:	mov    0x20(%r12),%rsi
 29e2a5f:	mov    %r11d,%ebx
 29e2a62:	lea    0x4(%rsi,%rbx,1),%rsi
 29e2a67:	xor    %r12,%r12
 29e2a6a:	cmp    %rdx,%rbx
 29e2a6d:	cmova  %r12,%rsi
 29e2a71:	mov    (%rsi),%edx
 29e2a73:	mov    0x190(%rsp),%rcx
 29e2a7b:	mov    0x28(%rcx),%rcx
 29e2a7f:	cmp    0x160(%rcx),%edx
 29e2a85:	sete   %cl
 29e2a88:	movzbl %cl,%edx
 29e2a8b:	test   %edx,%edx
 29e2a8d:	je     29fbc5b <wasm[0]::function[1015]::helper::object_read+0x1acdb>
 29e2a93:	test   %r11d,%r11d
 29e2a96:	je     29fbc5d <wasm[0]::function[1015]::helper::object_read+0x1acdd>
 29e2a9c:	mov    0x2e0(%rsp),%r12
 29e2aa4:	mov    0x28(%r12),%rsi
 29e2aa9:	mov    0x20(%r12),%rbx
 29e2aae:	mov    %r11d,%edx
 29e2ab1:	lea    (%rbx,%rdx,1),%r12
 29e2ab5:	xor    %r11,%r11
 29e2ab8:	cmp    %rsi,%rdx
 29e2abb:	cmova  %r11,%r12
 29e2abf:	mov    0x10(%r12),%r12d
 29e2ac4:	test   %r12d,%r12d
 29e2ac7:	je     29fbc5f <wasm[0]::function[1015]::helper::object_read+0x1acdf>
 29e2acd:	test   %r12d,%r12d
 29e2ad0:	je     29fbc61 <wasm[0]::function[1015]::helper::object_read+0x1ace1>
 29e2ad6:	mov    %r12d,%r10d
 29e2ad9:	lea    (%rbx,%r10,1),%r12
 29e2add:	cmp    %rsi,%r10
 29e2ae0:	cmova  %r11,%r12
 29e2ae4:	mov    0x10(%r12),%r12d
 29e2ae9:	test   %r12d,%r12d
 29e2aec:	je     29fbc63 <wasm[0]::function[1015]::helper::object_read+0x1ace3>
 29e2af2:	test   %r12d,%r12d
 29e2af5:	je     29fbc65 <wasm[0]::function[1015]::helper::object_read+0x1ace5>
 29e2afb:	mov    %r12d,%r10d
 29e2afe:	lea    0x10(%rbx,%r10,1),%rbx
 29e2b03:	cmp    %rsi,%r10
 29e2b06:	cmova  %r11,%rbx
 29e2b0a:	mov    0x240(%rsp),%rcx
 29e2b12:	cmp    (%rbx),%ecx
 29e2b14:	setae  %sil
 29e2b18:	cmp    $0x2,%ecx
 29e2b1b:	setae  %r10b
 29e2b1f:	or     %r10d,%esi
 29e2b22:	test   %sil,%sil
 29e2b25:	jne    29fbc67 <wasm[0]::function[1015]::helper::object_read+0x1ace7>
 29e2b2b:	mov    0x2e0(%rsp),%r12
 29e2b33:	mov    0x28(%r12),%r11
 29e2b38:	mov    %rdx,%rsi
 29e2b3b:	add    0x20(%r12),%rsi
 29e2b40:	xor    %rbx,%rbx
 29e2b43:	cmp    %r11,%rdx
 29e2b46:	cmova  %rbx,%rsi
 29e2b4a:	mov    0x14(%rsi),%r15d
 29e2b4e:	mov    0x240(%rsp),%rcx
 29e2b56:	mov    0x240(%rsp),%rsi
 29e2b5e:	test   %esi,%ecx
 29e2b60:	je     29e2b9a <wasm[0]::function[1015]::helper::object_read+0x1c1a>
 29e2b66:	mov    0x2e0(%rsp),%r12
 29e2b6e:	mov    0x28(%r12),%r11
 29e2b73:	mov    0x20(%r12),%rcx
 29e2b78:	lea    (%rcx,%rdx,1),%rsi
 29e2b7c:	xor    %rbx,%rbx
 29e2b7f:	cmp    %r11,%rdx
 29e2b82:	cmova  %rbx,%rsi
 29e2b86:	mov    0x20(%rsi),%r13
 29e2b8a:	mov    0x2c(%rsi),%edx
 29e2b8d:	mov    0x240(%rsp),%rcx
 29e2b95:	jmp    29e2bc9 <wasm[0]::function[1015]::helper::object_read+0x1c49>
 29e2b9a:	mov    0x2e0(%rsp),%r12
 29e2ba2:	mov    0x28(%r12),%r11
 29e2ba7:	mov    0x20(%r12),%rcx
 29e2bac:	lea    (%rcx,%rdx,1),%rsi
 29e2bb0:	xor    %rbx,%rbx
 29e2bb3:	cmp    %r11,%rdx
 29e2bb6:	cmova  %rbx,%rsi
 29e2bba:	mov    0x18(%rsi),%r13
 29e2bbe:	mov    0x28(%rsi),%edx
 29e2bc1:	mov    0x240(%rsp),%rcx
 29e2bc9:	mov    0x240(%rsp),%rcx
 29e2bd1:	shl    $0x3,%ecx
 29e2bd4:	mov    %rcx,0x240(%rsp)
 29e2bdc:	shr    %cl,%r15d
 29e2bdf:	and    $0xff,%r15d
 29e2be6:	test   %eax,%eax
 29e2be8:	jne    29e2c0b <wasm[0]::function[1015]::helper::object_read+0x1c8b>
 29e2bee:	mov    0x1a0(%rsp),%rdx
 29e2bf6:	mov    0x288(%rsp),%r13
 29e2bfe:	mov    0x280(%rsp),%r15
 29e2c06:	jmp    29e2c25 <wasm[0]::function[1015]::helper::object_read+0x1ca5>
 29e2c0b:	xor    %esi,%esi
 29e2c0d:	mov    %rsi,0x290(%rsp)
 29e2c15:	mov    0x290(%rsp),%rcx
 29e2c1d:	mov    %rcx,0x298(%rsp)
 29e2c25:	mov    0x210(%rsp),%rcx
 29e2c2d:	mov    %r15,0x280(%rsp)
 29e2c35:	mov    %r13,0x288(%rsp)
 29e2c3d:	mov    %ecx,0xe8(%rsp)
 29e2c44:	mov    %r9d,0x78(%rsp)
 29e2c49:	mov    %r8d,0xa0(%rsp)
 29e2c51:	mov    0x208(%rsp),%rcx
 29e2c59:	mov    %ecx,0xa8(%rsp)
 29e2c60:	mov    %r14d,0x48(%rsp)
 29e2c65:	mov    %edi,0x80(%rsp)
 29e2c6c:	mov    %edx,0xb8(%rsp)
 29e2c73:	test   %eax,%eax
 29e2c75:	je     29e2c90 <wasm[0]::function[1015]::helper::object_read+0x1d10>
 29e2c7b:	mov    0x290(%rsp),%rsi
 29e2c83:	mov    0x298(%rsp),%rdi
 29e2c8b:	jmp    29efc02 <wasm[0]::function[1015]::helper::object_read+0xec82>
 29e2c90:	xor    %r10d,%r10d
 29e2c93:	mov    0x210(%rsp),%rax
 29e2c9b:	mov    0x210(%rsp),%rcx
 29e2ca3:	test   %ecx,%eax
 29e2ca5:	je     29e2d08 <wasm[0]::function[1015]::helper::object_read+0x1d88>
 29e2cab:	xor    %r10d,%r10d
 29e2cae:	mov    0x210(%rsp),%rax
 29e2cb6:	test   $0x1,%eax
 29e2cbb:	jne    29e2d08 <wasm[0]::function[1015]::helper::object_read+0x1d88>
 29e2cc1:	mov    0x2e0(%rsp),%r12
 29e2cc9:	mov    0x28(%r12),%rax
 29e2cce:	mov    0x20(%r12),%rsi
 29e2cd3:	mov    0x210(%rsp),%rcx
 29e2cdb:	mov    %ecx,%r10d
 29e2cde:	lea    0x4(%rsi,%r10,1),%rsi
 29e2ce3:	xor    %r11,%r11
 29e2ce6:	cmp    %rax,%r10
 29e2ce9:	cmova  %r11,%rsi
 29e2ced:	mov    (%rsi),%eax
 29e2cef:	mov    0x190(%rsp),%rcx
 29e2cf7:	mov    0x28(%rcx),%rcx
 29e2cfb:	cmp    0x254(%rcx),%eax
 29e2d01:	sete   %al
 29e2d04:	movzbl %al,%r10d
 29e2d08:	xor    %ebx,%ebx
 29e2d0a:	test   %r10d,%r10d
 29e2d0d:	jne    29e2d28 <wasm[0]::function[1015]::helper::object_read+0x1da8>
 29e2d13:	mov    0x210(%rsp),%rax
 29e2d1b:	mov    0x290(%rsp),%rsi
 29e2d23:	jmp    29e5abe <wasm[0]::function[1015]::helper::object_read+0x4b3e>
 29e2d28:	xor    %eax,%eax
 29e2d2a:	mov    0x210(%rsp),%r10
 29e2d32:	mov    0x210(%rsp),%r11
 29e2d3a:	test   %r11d,%r10d
 29e2d3d:	je     29e2d9f <wasm[0]::function[1015]::helper::object_read+0x1e1f>
 29e2d43:	xor    %eax,%eax
 29e2d45:	mov    0x210(%rsp),%rcx
 29e2d4d:	test   $0x1,%ecx
 29e2d53:	jne    29e2d9f <wasm[0]::function[1015]::helper::object_read+0x1e1f>
 29e2d59:	mov    0x2e0(%rsp),%r12
 29e2d61:	mov    0x28(%r12),%rax
 29e2d66:	mov    0x20(%r12),%rsi
 29e2d6b:	mov    0x210(%rsp),%rcx
 29e2d73:	mov    %ecx,%r10d
 29e2d76:	lea    0x4(%rsi,%r10,1),%rsi
 29e2d7b:	xor    %r11,%r11
 29e2d7e:	cmp    %rax,%r10
 29e2d81:	cmova  %r11,%rsi
 29e2d85:	mov    (%rsi),%eax
 29e2d87:	mov    0x190(%rsp),%rcx
 29e2d8f:	mov    0x28(%rcx),%rcx
 29e2d93:	cmp    0x254(%rcx),%eax
 29e2d99:	sete   %al
 29e2d9c:	movzbl %al,%eax
 29e2d9f:	test   %eax,%eax
 29e2da1:	je     29fbc69 <wasm[0]::function[1015]::helper::object_read+0x1ace9>
 29e2da7:	xor    %eax,%eax
 29e2da9:	mov    0x1b8(%rsp),%rcx
 29e2db1:	cmp    $0x4,%ecx
 29e2db4:	je     29e2dc7 <wasm[0]::function[1015]::helper::object_read+0x1e47>
 29e2dba:	mov    0x210(%rsp),%r10
 29e2dc2:	jmp    29e3673 <wasm[0]::function[1015]::helper::object_read+0x26f3>
 29e2dc7:	mov    0x78(%rsp),%r9d
 29e2dcc:	xor    %edi,%edi
 29e2dce:	test   %r9d,%r9d
 29e2dd1:	je     29e2e25 <wasm[0]::function[1015]::helper::object_read+0x1ea5>
 29e2dd7:	xor    %edi,%edi
 29e2dd9:	test   $0x1,%r9d
 29e2de0:	jne    29e2e25 <wasm[0]::function[1015]::helper::object_read+0x1ea5>
 29e2de6:	mov    0x2e0(%rsp),%r12
 29e2dee:	mov    0x28(%r12),%rax
 29e2df3:	mov    0x20(%r12),%rcx
 29e2df8:	mov    %r9d,%edx
 29e2dfb:	lea    0x4(%rcx,%rdx,1),%rcx
 29e2e00:	xor    %rsi,%rsi
 29e2e03:	cmp    %rax,%rdx
 29e2e06:	cmova  %rsi,%rcx
 29e2e0a:	mov    (%rcx),%eax
 29e2e0c:	mov    0x190(%rsp),%rcx
 29e2e14:	mov    0x28(%rcx),%rcx
 29e2e18:	cmp    0x234(%rcx),%eax
 29e2e1e:	sete   %al
 29e2e21:	rex movzbl %al,%edi
 29e2e25:	test   %edi,%edi
 29e2e27:	je     29fbc6b <wasm[0]::function[1015]::helper::object_read+0x1aceb>
 29e2e2d:	test   %r9d,%r9d
 29e2e30:	je     29fbc6d <wasm[0]::function[1015]::helper::object_read+0x1aced>
 29e2e36:	test   %r9d,%r9d
 29e2e39:	je     29fbc6f <wasm[0]::function[1015]::helper::object_read+0x1acef>
 29e2e3f:	mov    0x2e0(%rsp),%r12
 29e2e47:	mov    0x28(%r12),%rcx
 29e2e4c:	mov    0x20(%r12),%rdx
 29e2e51:	mov    %r9d,%edi
 29e2e54:	lea    (%rdx,%rdi,1),%rax
 29e2e58:	xor    %rsi,%rsi
 29e2e5b:	cmp    %rcx,%rdi
 29e2e5e:	cmova  %rsi,%rax
 29e2e62:	mov    0x10(%rax),%edi
 29e2e65:	xor    %eax,%eax
 29e2e67:	test   %edi,%edi
 29e2e69:	je     29fbc71 <wasm[0]::function[1015]::helper::object_read+0x1acf1>
 29e2e6f:	test   %edi,%edi
 29e2e71:	je     29fbc73 <wasm[0]::function[1015]::helper::object_read+0x1acf3>
 29e2e77:	mov    %edi,%edi
 29e2e79:	lea    0x10(%rdx,%rdi,1),%rdx
 29e2e7e:	cmp    %rcx,%rdi
 29e2e81:	cmova  %rsi,%rdx
 29e2e85:	mov    (%rdx),%esi
 29e2e87:	mov    0xe8(%rsp),%edx
 29e2e8e:	mov    %rdx,0x210(%rsp)
 29e2e96:	mov    0xa0(%rsp),%r8d
 29e2e9e:	mov    0xa8(%rsp),%r14d
 29e2ea6:	mov    %r14,0x208(%rsp)
 29e2eae:	mov    0x48(%rsp),%r14d
 29e2eb3:	mov    0x80(%rsp),%edi
 29e2eba:	mov    0xb8(%rsp),%edx
 29e2ec1:	cmp    $0x6,%esi
 29e2ec4:	je     29e2ed7 <wasm[0]::function[1015]::helper::object_read+0x1f57>
 29e2eca:	mov    0x210(%rsp),%r10
 29e2ed2:	jmp    29e3673 <wasm[0]::function[1015]::helper::object_read+0x26f3>
 29e2ed7:	mov    $0x8c,%edx
 29e2edc:	mov    0x190(%rsp),%rsi
 29e2ee4:	mov    0x190(%rsp),%rdi
 29e2eec:	call   2f30600 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 29e2ef1:	test   %eax,%eax
 29e2ef3:	je     29fbc75 <wasm[0]::function[1015]::helper::object_read+0x1acf5>
 29e2ef9:	mov    0x1b8(%rsp),%rcx
 29e2f01:	cmp    $0x4,%ecx
 29e2f04:	je     29e2f58 <wasm[0]::function[1015]::helper::object_read+0x1fd8>
 29e2f0a:	mov    0xe8(%rsp),%edx
 29e2f11:	mov    %rdx,0x210(%rsp)
 29e2f19:	mov    0x78(%rsp),%r9d
 29e2f1e:	mov    0xa0(%rsp),%r8d
 29e2f26:	mov    0xa8(%rsp),%r14d
 29e2f2e:	mov    %r14,0x208(%rsp)
 29e2f36:	mov    0x48(%rsp),%r14d
 29e2f3b:	mov    0x80(%rsp),%edi
 29e2f42:	mov    0xb8(%rsp),%edx
 29e2f49:	xor    %eax,%eax
 29e2f4b:	mov    0x210(%rsp),%r10
 29e2f53:	jmp    29e3673 <wasm[0]::function[1015]::helper::object_read+0x26f3>
 29e2f58:	mov    0x1b8(%rsp),%rcx
 29e2f60:	cmp    $0x3,%ecx
 29e2f63:	je     29e35e3 <wasm[0]::function[1015]::helper::object_read+0x2663>
 29e2f69:	mov    0x1b8(%rsp),%rcx
 29e2f71:	cmp    $0x4,%ecx
 29e2f74:	je     29e3489 <wasm[0]::function[1015]::helper::object_read+0x2509>
 29e2f7a:	mov    0x1b8(%rsp),%rcx
 29e2f82:	cmp    $0xa,%ecx
 29e2f85:	je     29e3047 <wasm[0]::function[1015]::helper::object_read+0x20c7>
 29e2f8b:	mov    0x1b8(%rsp),%rcx
 29e2f93:	mov    0x1b8(%rsp),%rdx
 29e2f9b:	test   %edx,%ecx
 29e2f9d:	sete   %r11b
 29e2fa1:	cmp    $0x1,%ecx
 29e2fa4:	sete   %cl
 29e2fa7:	or     %ecx,%r11d
 29e2faa:	test   %r11b,%r11b
 29e2fad:	jne    29e2ff3 <wasm[0]::function[1015]::helper::object_read+0x2073>
 29e2fb3:	mov    0x1b8(%rsp),%rcx
 29e2fbb:	cmp    $0x2,%ecx
 29e2fbe:	je     29e2fd5 <wasm[0]::function[1015]::helper::object_read+0x2055>
 29e2fc4:	mov    0x78(%rsp),%ecx
 29e2fc8:	cmp    %eax,%ecx
 29e2fca:	sete   %al
 29e2fcd:	movzbl %al,%eax
 29e2fd0:	jmp    29e2ffb <wasm[0]::function[1015]::helper::object_read+0x207b>
 29e2fd5:	mov    0x1c0(%rsp),%rax
 29e2fdd:	mov    0x1c0(%rsp),%r8
 29e2fe5:	test   %rax,%r8
 29e2fe8:	sete   %al
 29e2feb:	movzbl %al,%eax
 29e2fee:	jmp    29e2ffb <wasm[0]::function[1015]::helper::object_read+0x207b>
 29e2ff3:	mov    0x278(%rsp),%rax
 29e2ffb:	mov    0xe8(%rsp),%edx
 29e3002:	mov    %rdx,0x210(%rsp)
 29e300a:	mov    0x78(%rsp),%r9d
 29e300f:	mov    0xa0(%rsp),%r8d
 29e3017:	mov    0xa8(%rsp),%r14d
 29e301f:	mov    %r14,0x208(%rsp)
 29e3027:	mov    0x48(%rsp),%r14d
 29e302c:	mov    0x80(%rsp),%edi
 29e3033:	mov    0xb8(%rsp),%edx
 29e303a:	mov    0x210(%rsp),%r10
 29e3042:	jmp    29e3673 <wasm[0]::function[1015]::helper::object_read+0x26f3>
 29e3047:	mov    0x78(%rsp),%edx
 29e304b:	xor    %ecx,%ecx
 29e304d:	test   %edx,%edx
 29e304f:	je     29e30a0 <wasm[0]::function[1015]::helper::object_read+0x2120>
 29e3055:	xor    %ecx,%ecx
 29e3057:	test   $0x1,%edx
 29e305d:	jne    29e30a0 <wasm[0]::function[1015]::helper::object_read+0x2120>
 29e3063:	mov    0x2e0(%rsp),%r12
 29e306b:	mov    0x28(%r12),%rcx
 29e3070:	mov    0x20(%r12),%rdi
 29e3075:	mov    %edx,%esi
 29e3077:	lea    0x4(%rdi,%rsi,1),%rdx
 29e307c:	xor    %rdi,%rdi
 29e307f:	cmp    %rcx,%rsi
 29e3082:	cmova  %rdi,%rdx
 29e3086:	mov    (%rdx),%ecx
 29e3088:	mov    0x190(%rsp),%rdx
 29e3090:	mov    0x28(%rdx),%rdx
 29e3094:	cmp    0x23c(%rdx),%ecx
 29e309a:	sete   %cl
 29e309d:	movzbl %cl,%ecx
 29e30a0:	test   %ecx,%ecx
 29e30a2:	je     29fbc77 <wasm[0]::function[1015]::helper::object_read+0x1acf7>
 29e30a8:	xor    %ecx,%ecx
 29e30aa:	test   %eax,%eax
 29e30ac:	je     29e30fc <wasm[0]::function[1015]::helper::object_read+0x217c>
 29e30b2:	xor    %ecx,%ecx
 29e30b4:	test   $0x1,%eax
 29e30b9:	jne    29e30fc <wasm[0]::function[1015]::helper::object_read+0x217c>
 29e30bf:	mov    0x2e0(%rsp),%r12
 29e30c7:	mov    0x28(%r12),%rcx
 29e30cc:	mov    0x20(%r12),%rdx
 29e30d1:	mov    %eax,%esi
 29e30d3:	lea    0x4(%rdx,%rsi,1),%rdx
 29e30d8:	xor    %rdi,%rdi
 29e30db:	cmp    %rcx,%rsi
 29e30de:	cmova  %rdi,%rdx
 29e30e2:	mov    (%rdx),%ecx
 29e30e4:	mov    0x190(%rsp),%rdx
 29e30ec:	mov    0x28(%rdx),%rdx
 29e30f0:	cmp    0x23c(%rdx),%ecx
 29e30f6:	sete   %cl
 29e30f9:	movzbl %cl,%ecx
 29e30fc:	test   %ecx,%ecx
 29e30fe:	je     29fbc79 <wasm[0]::function[1015]::helper::object_read+0x1acf9>
 29e3104:	mov    0x78(%rsp),%r9d
 29e3109:	test   %r9d,%r9d
 29e310c:	je     29fbc7b <wasm[0]::function[1015]::helper::object_read+0x1acfb>
 29e3112:	test   %r9d,%r9d
 29e3115:	je     29fbc7d <wasm[0]::function[1015]::helper::object_read+0x1acfd>
 29e311b:	mov    0x2e0(%rsp),%r12
 29e3123:	mov    0x28(%r12),%rcx
 29e3128:	mov    0x20(%r12),%rdx
 29e312d:	mov    %r9d,%esi
 29e3130:	lea    (%rdx,%rsi,1),%r8
 29e3134:	xor    %rdi,%rdi
 29e3137:	cmp    %rcx,%rsi
 29e313a:	cmova  %rdi,%r8
 29e313e:	mov    0x10(%r8),%esi
 29e3142:	test   %eax,%eax
 29e3144:	je     29fbc7f <wasm[0]::function[1015]::helper::object_read+0x1acff>
 29e314a:	mov    %eax,%eax
 29e314c:	lea    (%rdx,%rax,1),%r11
 29e3150:	cmp    %rcx,%rax
 29e3153:	cmova  %rdi,%r11
 29e3157:	mov    0x10(%r11),%eax
 29e315b:	mov    0x14(%r8),%r10d
 29e315f:	mov    %r10d,0xd0(%rsp)
 29e3167:	mov    0x14(%r11),%r8d
 29e316b:	mov    %r8d,0x140(%rsp)
 29e3173:	test   %r10d,%r10d
 29e3176:	je     29fbc81 <wasm[0]::function[1015]::helper::object_read+0x1ad01>
 29e317c:	test   %r10d,%r10d
 29e317f:	je     29fbc83 <wasm[0]::function[1015]::helper::object_read+0x1ad03>
 29e3185:	mov    %r10d,%r11d
 29e3188:	lea    0x10(%rdx,%r11,1),%r10
 29e318d:	cmp    %rcx,%r11
 29e3190:	cmova  %rdi,%r10
 29e3194:	mov    (%r10),%ebx
 29e3197:	test   %r8d,%r8d
 29e319a:	je     29fbc85 <wasm[0]::function[1015]::helper::object_read+0x1ad05>
 29e31a0:	test   %r8d,%r8d
 29e31a3:	je     29fbc87 <wasm[0]::function[1015]::helper::object_read+0x1ad07>
 29e31a9:	mov    %r8d,%r8d
 29e31ac:	lea    0x10(%rdx,%r8,1),%rdx
 29e31b1:	cmp    %rcx,%r8
 29e31b4:	cmova  %rdi,%rdx
 29e31b8:	mov    (%rdx),%r10d
 29e31bb:	mov    0xe8(%rsp),%edx
 29e31c2:	mov    %rdx,0x210(%rsp)
 29e31ca:	mov    0xa0(%rsp),%r8d
 29e31d2:	mov    0xa8(%rsp),%r14d
 29e31da:	mov    %r14,0x208(%rsp)
 29e31e2:	mov    0x48(%rsp),%r14d
 29e31e7:	mov    0x80(%rsp),%edi
 29e31ee:	mov    0xb8(%rsp),%edx
 29e31f5:	cmp    %eax,%esi
 29e31f7:	sete   %sil
 29e31fb:	cmp    %r10d,%ebx
 29e31fe:	sete   %r10b
 29e3202:	mov    %rsi,%r11
 29e3205:	and    %r10d,%r11d
 29e3208:	movzbl %r11b,%eax
 29e320c:	mov    %rax,0x1d8(%rsp)
 29e3214:	test   %sil,%r10b
 29e3217:	jne    29e3232 <wasm[0]::function[1015]::helper::object_read+0x22b2>
 29e321d:	mov    0x1d8(%rsp),%rax
 29e3225:	mov    0x210(%rsp),%r10
 29e322d:	jmp    29e3673 <wasm[0]::function[1015]::helper::object_read+0x26f3>
 29e3232:	mov    0xe8(%rsp),%ecx
 29e3239:	mov    0x78(%rsp),%edx
 29e323d:	mov    0xa0(%rsp),%esi
 29e3244:	mov    0xa8(%rsp),%edi
 29e324b:	mov    0x48(%rsp),%r8d
 29e3250:	mov    0x80(%rsp),%r9d
 29e3258:	mov    0xb8(%rsp),%r10d
 29e3260:	xor    %r13d,%r13d
 29e3263:	mov    %rcx,%r11
 29e3266:	mov    %ecx,0x58(%rsp)
 29e326a:	mov    %edx,0xc0(%rsp)
 29e3271:	mov    %esi,0xe0(%rsp)
 29e3278:	mov    %r11d,0x88(%rsp)
 29e3280:	mov    %edi,0xb0(%rsp)
 29e3287:	mov    %r8d,0x110(%rsp)
 29e328f:	mov    %r9d,0x120(%rsp)
 29e3297:	mov    %r10d,0x100(%rsp)
 29e329f:	mov    0x2e8(%rsp),%r15
 29e32a7:	mov    (%r15),%rcx
 29e32aa:	mov    0x228(%rsp),%rax
 29e32b2:	cmp    %rax,%rcx
 29e32b5:	jae    29fa57d <wasm[0]::function[1015]::helper::object_read+0x195fd>
 29e32bb:	cmp    %ebx,%r13d
 29e32be:	jb     29e32d1 <wasm[0]::function[1015]::helper::object_read+0x2351>
 29e32c4:	mov    0x1d8(%rsp),%rax
 29e32cc:	jmp    29e343a <wasm[0]::function[1015]::helper::object_read+0x24ba>
 29e32d1:	mov    0xd0(%rsp),%esi
 29e32d8:	test   %esi,%esi
 29e32da:	je     29fbc89 <wasm[0]::function[1015]::helper::object_read+0x1ad09>
 29e32e0:	test   %esi,%esi
 29e32e2:	je     29fbc8b <wasm[0]::function[1015]::helper::object_read+0x1ad0b>
 29e32e8:	mov    0x2e0(%rsp),%r12
 29e32f0:	mov    0x28(%r12),%rax
 29e32f5:	mov    0x20(%r12),%rcx
 29e32fa:	mov    %esi,%r8d
 29e32fd:	lea    0x10(%rcx,%r8,1),%rdi
 29e3302:	xor    %rdx,%rdx
 29e3305:	cmp    %rax,%r8
 29e3308:	cmova  %rdx,%rdi
 29e330c:	mov    (%rdi),%r8d
 29e330f:	cmp    %r8d,%r13d
 29e3312:	jae    29fbc8d <wasm[0]::function[1015]::helper::object_read+0x1ad0d>
 29e3318:	mov    %r8d,%edi
 29e331b:	shl    $0x3,%rdi
 29e331f:	shr    $0x20,%rdi
 29e3323:	test   %rdi,%rdi
 29e3326:	jne    29fbc8f <wasm[0]::function[1015]::helper::object_read+0x1ad0f>
 29e332c:	shl    $0x3,%r8d
 29e3330:	add    $0x18,%r8d
 29e3334:	jb     29fbc91 <wasm[0]::function[1015]::helper::object_read+0x1ad11>
 29e333a:	add    %r8d,%esi
 29e333d:	jb     29fbc93 <wasm[0]::function[1015]::helper::object_read+0x1ad13>
 29e3343:	mov    %esi,%edi
 29e3345:	lea    (%rcx,%rdi,1),%rsi
 29e3349:	cmp    %rax,%rdi
 29e334c:	cmova  %rdx,%rsi
 29e3350:	mov    %r13,%rdi
 29e3353:	shl    $0x3,%edi
 29e3356:	add    $0x18,%edi
 29e335c:	sub    %edi,%r8d
 29e335f:	sub    %r8,%rsi
 29e3362:	mov    (%rsi),%rsi
 29e3365:	mov    0x140(%rsp),%r8d
 29e336d:	test   %r8d,%r8d
 29e3370:	je     29fbc95 <wasm[0]::function[1015]::helper::object_read+0x1ad15>
 29e3376:	test   %r8d,%r8d
 29e3379:	je     29fbc97 <wasm[0]::function[1015]::helper::object_read+0x1ad17>
 29e337f:	mov    %r8d,%r10d
 29e3382:	lea    0x10(%rcx,%r10,1),%r9
 29e3387:	cmp    %rax,%r10
 29e338a:	cmova  %rdx,%r9
 29e338e:	mov    (%r9),%r9d
 29e3391:	cmp    %r9d,%r13d
 29e3394:	jae    29fbc99 <wasm[0]::function[1015]::helper::object_read+0x1ad19>
 29e339a:	mov    %r9d,%r10d
 29e339d:	shl    $0x3,%r10
 29e33a1:	shr    $0x20,%r10
 29e33a5:	test   %r10,%r10
 29e33a8:	jne    29fbc9b <wasm[0]::function[1015]::helper::object_read+0x1ad1b>
 29e33ae:	shl    $0x3,%r9d
 29e33b2:	add    $0x18,%r9d
 29e33b6:	jb     29fbc9d <wasm[0]::function[1015]::helper::object_read+0x1ad1d>
 29e33bc:	add    %r9d,%r8d
 29e33bf:	jb     29fbc9f <wasm[0]::function[1015]::helper::object_read+0x1ad1f>
 29e33c5:	mov    %r8d,%r8d
 29e33c8:	add    %r8,%rcx
 29e33cb:	cmp    %rax,%r8
 29e33ce:	cmova  %rdx,%rcx
 29e33d2:	sub    %edi,%r9d
 29e33d5:	sub    %r9,%rcx
 29e33d8:	mov    (%rcx),%rcx
 29e33db:	cmp    %rcx,%rsi
 29e33de:	sete   %al
 29e33e1:	movzbl %al,%eax
 29e33e4:	cmp    %rcx,%rsi
 29e33e7:	jne    29e343a <wasm[0]::function[1015]::helper::object_read+0x24ba>
 29e33ed:	mov    0x58(%rsp),%ecx
 29e33f1:	mov    0xc0(%rsp),%edx
 29e33f8:	mov    0xe0(%rsp),%esi
 29e33ff:	mov    0x88(%rsp),%r11d
 29e3407:	mov    0xb0(%rsp),%edi
 29e340e:	mov    0x110(%rsp),%r8d
 29e3416:	mov    0x120(%rsp),%r9d
 29e341e:	mov    0x100(%rsp),%r10d
 29e3426:	add    $0x1,%r13d
 29e342d:	mov    %rax,0x1d8(%rsp)
 29e3435:	jmp    29e3266 <wasm[0]::function[1015]::helper::object_read+0x22e6>
 29e343a:	mov    0x58(%rsp),%edx
 29e343e:	mov    %rdx,0x210(%rsp)
 29e3446:	mov    0xc0(%rsp),%r9d
 29e344e:	mov    0xe0(%rsp),%r8d
 29e3456:	mov    0x88(%rsp),%r10d
 29e345e:	mov    0xb0(%rsp),%r14d
 29e3466:	mov    %r14,0x208(%rsp)
 29e346e:	mov    0x110(%rsp),%r14d
 29e3476:	mov    0x120(%rsp),%edi
 29e347d:	mov    0x100(%rsp),%edx
 29e3484:	jmp    29e3673 <wasm[0]::function[1015]::helper::object_read+0x26f3>
 29e3489:	mov    0x78(%rsp),%ecx
 29e348d:	cmp    %eax,%ecx
 29e348f:	je     29e358f <wasm[0]::function[1015]::helper::object_read+0x260f>
 29e3495:	xor    %edx,%edx
 29e3497:	test   %ecx,%ecx
 29e3499:	je     29e34ec <wasm[0]::function[1015]::helper::object_read+0x256c>
 29e349f:	xor    %edx,%edx
 29e34a1:	test   $0x1,%ecx
 29e34a7:	jne    29e34ec <wasm[0]::function[1015]::helper::object_read+0x256c>
 29e34ad:	mov    0x2e0(%rsp),%r12
 29e34b5:	mov    0x28(%r12),%rsi
 29e34ba:	mov    0x20(%r12),%r8
 29e34bf:	mov    %ecx,%edi
 29e34c1:	lea    0x4(%r8,%rdi,1),%rdx
 29e34c6:	xor    %r8,%r8
 29e34c9:	cmp    %rsi,%rdi
 29e34cc:	cmova  %r8,%rdx
 29e34d0:	mov    (%rdx),%esi
 29e34d2:	mov    0x190(%rsp),%rcx
 29e34da:	mov    0x28(%rcx),%rdi
 29e34de:	cmp    0x234(%rdi),%esi
 29e34e4:	sete   %dil
 29e34e8:	movzbl %dil,%edx
 29e34ec:	test   %edx,%edx
 29e34ee:	je     29fbca1 <wasm[0]::function[1015]::helper::object_read+0x1ad21>
 29e34f4:	xor    %edx,%edx
 29e34f6:	test   %eax,%eax
 29e34f8:	jne    29e3506 <wasm[0]::function[1015]::helper::object_read+0x2586>
 29e34fe:	mov    %rax,%rdi
 29e3501:	jmp    29e355b <wasm[0]::function[1015]::helper::object_read+0x25db>
 29e3506:	xor    %edx,%edx
 29e3508:	test   $0x1,%eax
 29e350d:	je     29e351b <wasm[0]::function[1015]::helper::object_read+0x259b>
 29e3513:	mov    %rax,%rdi
 29e3516:	jmp    29e355b <wasm[0]::function[1015]::helper::object_read+0x25db>
 29e351b:	mov    0x2e0(%rsp),%r12
 29e3523:	mov    0x28(%r12),%rcx
 29e3528:	mov    0x20(%r12),%rsi
 29e352d:	mov    %eax,%edx
 29e352f:	mov    %rax,%rdi
 29e3532:	lea    0x4(%rsi,%rdx,1),%rax
 29e3537:	xor    %rsi,%rsi
 29e353a:	cmp    %rcx,%rdx
 29e353d:	cmova  %rsi,%rax
 29e3541:	mov    (%rax),%eax
 29e3543:	mov    0x190(%rsp),%rcx
 29e354b:	mov    0x28(%rcx),%rcx
 29e354f:	cmp    0x234(%rcx),%eax
 29e3555:	sete   %al
 29e3558:	movzbl %al,%edx
 29e355b:	test   %edx,%edx
 29e355d:	je     29fbca3 <wasm[0]::function[1015]::helper::object_read+0x1ad23>
 29e3563:	mov    0x78(%rsp),%edx
 29e3567:	xor    %r8d,%r8d
 29e356a:	test   %edx,%edx
 29e356c:	je     29fbca5 <wasm[0]::function[1015]::helper::object_read+0x1ad25>
 29e3572:	mov    %rdi,%rcx
 29e3575:	mov    0x190(%rsp),%rsi
 29e357d:	mov    0x190(%rsp),%rdi
 29e3585:	call   2ae5540 <wasm[0]::function[1057]::helper::string_equality>
 29e358a:	jmp    29e3597 <wasm[0]::function[1015]::helper::object_read+0x2617>
 29e358f:	mov    0x278(%rsp),%rax
 29e3597:	mov    0xe8(%rsp),%edx
 29e359e:	mov    %rdx,0x210(%rsp)
 29e35a6:	mov    0x78(%rsp),%r9d
 29e35ab:	mov    0xa0(%rsp),%r8d
 29e35b3:	mov    0xa8(%rsp),%r14d
 29e35bb:	mov    %r14,0x208(%rsp)
 29e35c3:	mov    0x48(%rsp),%r14d
 29e35c8:	mov    0x80(%rsp),%edi
 29e35cf:	mov    0xb8(%rsp),%edx
 29e35d6:	mov    0x210(%rsp),%r10
 29e35de:	jmp    29e3673 <wasm[0]::function[1015]::helper::object_read+0x26f3>
 29e35e3:	mov    0xe8(%rsp),%edx
 29e35ea:	mov    %rdx,0x210(%rsp)
 29e35f2:	mov    0x78(%rsp),%r9d
 29e35f7:	mov    0xa0(%rsp),%r8d
 29e35ff:	mov    0xa8(%rsp),%r14d
 29e3607:	mov    %r14,0x208(%rsp)
 29e360f:	mov    0x48(%rsp),%r14d
 29e3614:	mov    0x80(%rsp),%edi
 29e361b:	mov    0xb8(%rsp),%edx
 29e3622:	xor    %r10,%r10
 29e3625:	mov    0x1c0(%rsp),%rax
 29e362d:	mov    0x1c0(%rsp),%rcx
 29e3635:	test   %rcx,%rax
 29e3638:	sete   %al
 29e363b:	movq   %rcx,%xmm0
 29e3640:	ucomisd %xmm0,%xmm0
 29e3644:	setp   %sil
 29e3648:	setne  %r11b
 29e364c:	or     %r11d,%esi
 29e364f:	movq   %r10,%xmm0
 29e3654:	ucomisd %xmm0,%xmm0
 29e3658:	setp   %r10b
 29e365c:	setne  %r11b
 29e3660:	or     %r11d,%r10d
 29e3663:	and    %r10d,%esi
 29e3666:	or     %esi,%eax
 29e3668:	movzbl %al,%eax
 29e366b:	mov    0x210(%rsp),%r10
 29e3673:	test   %eax,%eax
 29e3675:	jne    29e5a08 <wasm[0]::function[1015]::helper::object_read+0x4a88>
 29e367b:	xor    %eax,%eax
 29e367d:	mov    0x1b8(%rsp),%rcx
 29e3685:	cmp    $0x4,%ecx
 29e3688:	je     29e3696 <wasm[0]::function[1015]::helper::object_read+0x2716>
 29e368e:	mov    %rax,%rsi
 29e3691:	jmp    29e3a27 <wasm[0]::function[1015]::helper::object_read+0x2aa7>
 29e3696:	xor    %eax,%eax
 29e3698:	test   %r9d,%r9d
 29e369b:	je     29e36ee <wasm[0]::function[1015]::helper::object_read+0x276e>
 29e36a1:	xor    %eax,%eax
 29e36a3:	test   $0x1,%r9d
 29e36aa:	jne    29e36ee <wasm[0]::function[1015]::helper::object_read+0x276e>
 29e36b0:	mov    0x2e0(%rsp),%r12
 29e36b8:	mov    0x28(%r12),%rax
 29e36bd:	mov    0x20(%r12),%rsi
 29e36c2:	mov    %r9d,%r11d
 29e36c5:	lea    0x4(%rsi,%r11,1),%rsi
 29e36ca:	xor    %rbx,%rbx
 29e36cd:	cmp    %rax,%r11
 29e36d0:	cmova  %rbx,%rsi
 29e36d4:	mov    (%rsi),%eax
 29e36d6:	mov    0x190(%rsp),%rcx
 29e36de:	mov    0x28(%rcx),%rcx
 29e36e2:	cmp    0x234(%rcx),%eax
 29e36e8:	sete   %al
 29e36eb:	movzbl %al,%eax
 29e36ee:	test   %eax,%eax
 29e36f0:	je     29fbca7 <wasm[0]::function[1015]::helper::object_read+0x1ad27>
 29e36f6:	test   %r9d,%r9d
 29e36f9:	je     29fbca9 <wasm[0]::function[1015]::helper::object_read+0x1ad29>
 29e36ff:	test   %r9d,%r9d
 29e3702:	je     29fbcab <wasm[0]::function[1015]::helper::object_read+0x1ad2b>
 29e3708:	mov    0x2e0(%rsp),%r12
 29e3710:	mov    0x28(%r12),%rsi
 29e3715:	mov    0x20(%r12),%r11
 29e371a:	mov    %r9d,%r12d
 29e371d:	lea    (%r11,%r12,1),%rax
 29e3721:	xor    %rbx,%rbx
 29e3724:	cmp    %rsi,%r12
 29e3727:	cmova  %rbx,%rax
 29e372b:	mov    0x10(%rax),%r12d
 29e372f:	mov    %r12d,0xe8(%rsp)
 29e3737:	xor    %eax,%eax
 29e3739:	test   %r12d,%r12d
 29e373c:	je     29fbcad <wasm[0]::function[1015]::helper::object_read+0x1ad2d>
 29e3742:	test   %r12d,%r12d
 29e3745:	je     29fbcaf <wasm[0]::function[1015]::helper::object_read+0x1ad2f>
 29e374b:	mov    %r12d,%r12d
 29e374e:	lea    0x10(%r11,%r12,1),%r11
 29e3753:	cmp    %rsi,%r12
 29e3756:	cmova  %rbx,%r11
 29e375a:	mov    (%r11),%ebx
 29e375d:	test   %ebx,%ebx
 29e375f:	sete   %sil
 29e3763:	cmp    $0xa,%ebx
 29e3766:	seta   %r11b
 29e376a:	or     %r11d,%esi
 29e376d:	test   %sil,%sil
 29e3770:	je     29e377e <wasm[0]::function[1015]::helper::object_read+0x27fe>
 29e3776:	mov    %rax,%rsi
 29e3779:	jmp    29e3a27 <wasm[0]::function[1015]::helper::object_read+0x2aa7>
 29e377e:	mov    0xe8(%rsp),%eax
 29e3785:	test   %eax,%eax
 29e3787:	je     29fbcb1 <wasm[0]::function[1015]::helper::object_read+0x1ad31>
 29e378d:	test   %eax,%eax
 29e378f:	je     29fbcb3 <wasm[0]::function[1015]::helper::object_read+0x1ad33>
 29e3795:	mov    0x2e0(%rsp),%r12
 29e379d:	mov    0x28(%r12),%r11
 29e37a2:	mov    0x20(%r12),%rsi
 29e37a7:	mov    %eax,%r15d
 29e37aa:	lea    0x10(%rsi,%r15,1),%r13
 29e37af:	xor    %r12,%r12
 29e37b2:	cmp    %r11,%r15
 29e37b5:	cmova  %r12,%r13
 29e37b9:	mov    0x0(%r13),%r13d
 29e37bd:	test   %r13d,%r13d
 29e37c0:	je     29fbcb5 <wasm[0]::function[1015]::helper::object_read+0x1ad35>
 29e37c6:	mov    %r13d,%r15d
 29e37c9:	shl    $1,%r15
 29e37cc:	shr    $0x20,%r15
 29e37d0:	test   %r15,%r15
 29e37d3:	jne    29fbcb7 <wasm[0]::function[1015]::helper::object_read+0x1ad37>
 29e37d9:	add    %r13d,%r13d
 29e37dc:	add    $0x14,%r13d
 29e37e0:	jb     29fbcb9 <wasm[0]::function[1015]::helper::object_read+0x1ad39>
 29e37e6:	add    %r13d,%eax
 29e37e9:	jb     29fbcbb <wasm[0]::function[1015]::helper::object_read+0x1ad3b>
 29e37ef:	mov    %eax,%r15d
 29e37f2:	lea    (%rsi,%r15,1),%rax
 29e37f6:	cmp    %r11,%r15
 29e37f9:	cmova  %r12,%rax
 29e37fd:	sub    $0x14,%r13d
 29e3801:	sub    %r13,%rax
 29e3804:	movzwl (%rax),%eax
 29e3807:	cmp    $0x30,%eax
 29e380a:	je     29e3a09 <wasm[0]::function[1015]::helper::object_read+0x2a89>
 29e3810:	xor    %r15d,%r15d
 29e3813:	xor    %r13,%r13
 29e3816:	mov    0x210(%rsp),%rax
 29e381e:	mov    %r15,%rsi
 29e3821:	mov    %eax,0xe0(%rsp)
 29e3828:	mov    %r8d,0xc0(%rsp)
 29e3830:	mov    %r9d,0x58(%rsp)
 29e3835:	mov    %esi,0xb8(%rsp)
 29e383c:	mov    %r10d,0x80(%rsp)
 29e3844:	mov    0x208(%rsp),%rax
 29e384c:	mov    %eax,0x48(%rsp)
 29e3850:	mov    %r14d,0xa8(%rsp)
 29e3858:	mov    %edi,0xa0(%rsp)
 29e385f:	mov    %edx,0x78(%rsp)
 29e3863:	mov    0x2e8(%rsp),%r11
 29e386b:	mov    (%r11),%rax
 29e386e:	mov    0x228(%rsp),%rcx
 29e3876:	cmp    %rcx,%rax
 29e3879:	jae    29fa5b5 <wasm[0]::function[1015]::helper::object_read+0x19635>
 29e387f:	mov    0xe8(%rsp),%ecx
 29e3886:	xor    %eax,%eax
 29e3888:	test   %ecx,%ecx
 29e388a:	je     29fbcbd <wasm[0]::function[1015]::helper::object_read+0x1ad3d>
 29e3890:	test   %ecx,%ecx
 29e3892:	je     29fbcbf <wasm[0]::function[1015]::helper::object_read+0x1ad3f>
 29e3898:	mov    0x2e0(%rsp),%r12
 29e38a0:	mov    0x28(%r12),%rdx
 29e38a5:	mov    0x20(%r12),%rsi
 29e38aa:	mov    %ecx,%r9d
 29e38ad:	lea    0x10(%rsi,%r9,1),%r8
 29e38b2:	xor    %rdi,%rdi
 29e38b5:	cmp    %rdx,%r9
 29e38b8:	cmova  %rdi,%r8
 29e38bc:	mov    (%r8),%r8d
 29e38bf:	cmp    %r8d,%r15d
 29e38c2:	jae    29fbcc1 <wasm[0]::function[1015]::helper::object_read+0x1ad41>
 29e38c8:	mov    %r8d,%r9d
 29e38cb:	shl    $1,%r9
 29e38ce:	shr    $0x20,%r9
 29e38d2:	test   %r9,%r9
 29e38d5:	jne    29fbcc3 <wasm[0]::function[1015]::helper::object_read+0x1ad43>
 29e38db:	add    %r8d,%r8d
 29e38de:	add    $0x14,%r8d
 29e38e2:	jb     29fbcc5 <wasm[0]::function[1015]::helper::object_read+0x1ad45>
 29e38e8:	add    %r8d,%ecx
 29e38eb:	jb     29fbcc7 <wasm[0]::function[1015]::helper::object_read+0x1ad47>
 29e38f1:	mov    %ecx,%r9d
 29e38f4:	lea    (%rsi,%r9,1),%rcx
 29e38f8:	cmp    %rdx,%r9
 29e38fb:	cmova  %rdi,%rcx
 29e38ff:	lea    0x14(%r15,%r15,1),%edx
 29e3904:	sub    %edx,%r8d
 29e3907:	sub    %r8,%rcx
 29e390a:	movzwq (%rcx),%r11
 29e390e:	mov    0xe0(%rsp),%edx
 29e3915:	mov    %rdx,0x210(%rsp)
 29e391d:	mov    0xc0(%rsp),%r8d
 29e3925:	mov    0x58(%rsp),%r9d
 29e392a:	mov    0xb8(%rsp),%esi
 29e3931:	mov    0x80(%rsp),%r10d
 29e3939:	mov    0x48(%rsp),%r14d
 29e393e:	mov    %r14,0x208(%rsp)
 29e3946:	mov    0xa8(%rsp),%r14d
 29e394e:	mov    0xa0(%rsp),%edi
 29e3955:	mov    0x78(%rsp),%edx
 29e3959:	movzwl %r11w,%r11d
 29e395d:	sub    $0x30,%r11d
 29e3961:	cmp    $0x9,%r11d
 29e3965:	ja     29e3a27 <wasm[0]::function[1015]::helper::object_read+0x2aa7>
 29e396b:	mov    0xe0(%rsp),%edx
 29e3972:	mov    %rdx,0x210(%rsp)
 29e397a:	mov    0xc0(%rsp),%r8d
 29e3982:	mov    0x58(%rsp),%r9d
 29e3987:	mov    0xb8(%rsp),%esi
 29e398e:	mov    0x80(%rsp),%r10d
 29e3996:	mov    0x48(%rsp),%r14d
 29e399b:	mov    %r14,0x208(%rsp)
 29e39a3:	mov    0xa8(%rsp),%r14d
 29e39ab:	mov    0xa0(%rsp),%edi
 29e39b2:	mov    0x78(%rsp),%edx
 29e39b6:	add    $0x1,%r15d
 29e39bd:	imul   $0xa,%r13,%rax
 29e39c1:	lea    (%rax,%r11,1),%r12
 29e39c5:	cmp    %ebx,%r15d
 29e39c8:	jae    29e39de <wasm[0]::function[1015]::helper::object_read+0x2a5e>
 29e39ce:	mov    0x210(%rsp),%rax
 29e39d6:	mov    %r12,%r13
 29e39d9:	jmp    29e3821 <wasm[0]::function[1015]::helper::object_read+0x28a1>
 29e39de:	xor    %eax,%eax
 29e39e0:	cmp    0x18f21(%rip),%r12        # 29fc908 <wasm[0]::function[1015]::helper::object_read+0x1b988>
 29e39e7:	jae    29e3a27 <wasm[0]::function[1015]::helper::object_read+0x2aa7>
 29e39ed:	imul   $0xa,%r13d,%eax
 29e39f1:	add    %r11d,%eax
 29e39f4:	mov    %rax,0x1e0(%rsp)
 29e39fc:	mov    0x278(%rsp),%rax
 29e3a04:	jmp    29e3a27 <wasm[0]::function[1015]::helper::object_read+0x2aa7>
 29e3a09:	cmp    $0x1,%ebx
 29e3a0c:	sete   %al
 29e3a0f:	movzbl %al,%eax
 29e3a12:	mov    %rsi,%rcx
 29e3a15:	mov    %rsi,0x1e0(%rsp)
 29e3a1d:	xor    %esi,%esi
 29e3a1f:	mov    %rsi,0x1e0(%rsp)
 29e3a27:	mov    %r8d,0xa0(%rsp)
 29e3a2f:	mov    %r9d,0xa8(%rsp)
 29e3a37:	mov    %esi,0x48(%rsp)
 29e3a3b:	mov    %r10d,0x80(%rsp)
 29e3a43:	mov    0x208(%rsp),%r8
 29e3a4b:	mov    %r8d,0xb8(%rsp)
 29e3a53:	mov    %r14d,0x58(%rsp)
 29e3a58:	mov    %edi,0xc0(%rsp)
 29e3a5f:	mov    %edx,0xe0(%rsp)
 29e3a66:	test   %eax,%eax
 29e3a68:	mov    %rax,0x200(%rsp)
 29e3a70:	jne    29e3b2b <wasm[0]::function[1015]::helper::object_read+0x2bab>
 29e3a76:	xor    %ebx,%ebx
 29e3a78:	mov    0x210(%rsp),%rax
 29e3a80:	mov    0x210(%rsp),%rdx
 29e3a88:	test   %eax,%edx
 29e3a8a:	je     29fbcc9 <wasm[0]::function[1015]::helper::object_read+0x1ad49>
 29e3a90:	test   %eax,%edx
 29e3a92:	je     29fbccb <wasm[0]::function[1015]::helper::object_read+0x1ad4b>
 29e3a98:	mov    0x2e0(%rsp),%r12
 29e3aa0:	mov    0x28(%r12),%rax
 29e3aa5:	mov    0x20(%r12),%rdx
 29e3aaa:	mov    0x210(%rsp),%rcx
 29e3ab2:	mov    %ecx,%ecx
 29e3ab4:	lea    (%rdx,%rcx,1),%r10
 29e3ab8:	xor    %rdx,%rdx
 29e3abb:	cmp    %rax,%rcx
 29e3abe:	cmova  %rdx,%r10
 29e3ac2:	mov    0x10(%r10),%edx
 29e3ac6:	test   %edx,%edx
 29e3ac8:	je     29fbccd <wasm[0]::function[1015]::helper::object_read+0x1ad4d>
 29e3ace:	mov    0x1b8(%rsp),%rcx
 29e3ad6:	mov    0x190(%rsp),%rsi
 29e3ade:	mov    0x190(%rsp),%rdi
 29e3ae6:	mov    0x1c0(%rsp),%r8
 29e3aee:	call   29ffc60 <wasm[0]::function[1019]::helper::ordinary_own_descriptor>
 29e3af3:	mov    0x80(%rsp),%edi
 29e3afa:	mov    0xa8(%rsp),%r8d
 29e3b02:	mov    0xb8(%rsp),%r11d
 29e3b0a:	mov    0x58(%rsp),%r12d
 29e3b0f:	mov    0xc0(%rsp),%r13d
 29e3b17:	mov    0xe0(%rsp),%edx
 29e3b1e:	mov    0x290(%rsp),%rsi
 29e3b26:	jmp    29e57d4 <wasm[0]::function[1015]::helper::object_read+0x4854>
 29e3b2b:	mov    0x210(%rsp),%rax
 29e3b33:	mov    0x210(%rsp),%rdx
 29e3b3b:	test   %eax,%edx
 29e3b3d:	je     29fbccf <wasm[0]::function[1015]::helper::object_read+0x1ad4f>
 29e3b43:	test   %eax,%edx
 29e3b45:	je     29fbcd1 <wasm[0]::function[1015]::helper::object_read+0x1ad51>
 29e3b4b:	mov    0x2e0(%rsp),%r12
 29e3b53:	mov    0x28(%r12),%rcx
 29e3b58:	mov    0x20(%r12),%rsi
 29e3b5d:	mov    %edx,%edx
 29e3b5f:	lea    (%rsi,%rdx,1),%rax
 29e3b63:	xor    %rdi,%rdi
 29e3b66:	cmp    %rcx,%rdx
 29e3b69:	cmova  %rdi,%rax
 29e3b6d:	mov    0x14(%rax),%eax
 29e3b70:	test   %eax,%eax
 29e3b72:	je     29fbcd3 <wasm[0]::function[1015]::helper::object_read+0x1ad53>
 29e3b78:	test   %eax,%eax
 29e3b7a:	je     29fbcd5 <wasm[0]::function[1015]::helper::object_read+0x1ad55>
 29e3b80:	mov    %eax,%eax
 29e3b82:	add    %rax,%rsi
 29e3b85:	cmp    %rcx,%rax
 29e3b88:	cmova  %rdi,%rsi
 29e3b8c:	mov    0x24(%rsi),%edi
 29e3b8f:	cmp    $0x2,%edi
 29e3b92:	sete   %sil
 29e3b96:	mov    $0x3,%ecx
 29e3b9b:	cmp    $0x3,%edi
 29e3b9e:	sete   %dil
 29e3ba2:	or     %edi,%esi
 29e3ba4:	test   %sil,%sil
 29e3ba7:	jne    29e545d <wasm[0]::function[1015]::helper::object_read+0x44dd>
 29e3bad:	mov    0x2e0(%rsp),%r12
 29e3bb5:	mov    0x28(%r12),%rax
 29e3bba:	mov    0x20(%r12),%rsi
 29e3bbf:	lea    (%rsi,%rdx,1),%rdi
 29e3bc3:	xor    %rcx,%rcx
 29e3bc6:	cmp    %rax,%rdx
 29e3bc9:	cmova  %rcx,%rdi
 29e3bcd:	mov    0x14(%rdi),%r11d
 29e3bd1:	mov    %r11d,0x78(%rsp)
 29e3bd6:	test   %r11d,%r11d
 29e3bd9:	je     29fbcd7 <wasm[0]::function[1015]::helper::object_read+0x1ad57>
 29e3bdf:	test   %r11d,%r11d
 29e3be2:	je     29fbcd9 <wasm[0]::function[1015]::helper::object_read+0x1ad59>
 29e3be8:	mov    %r11d,%edi
 29e3beb:	lea    (%rsi,%rdi,1),%rdx
 29e3bef:	cmp    %rax,%rdi
 29e3bf2:	cmova  %rcx,%rdx
 29e3bf6:	mov    0x24(%rdx),%eax
 29e3bf9:	mov    0xa0(%rsp),%edx
 29e3c00:	mov    0x48(%rsp),%ecx
 29e3c04:	mov    %rcx,0x1e8(%rsp)
 29e3c0c:	mov    0x80(%rsp),%esi
 29e3c13:	mov    %rsi,0x1f0(%rsp)
 29e3c1b:	mov    0xa8(%rsp),%edi
 29e3c22:	mov    %rdi,0x1f8(%rsp)
 29e3c2a:	mov    0xb8(%rsp),%edi
 29e3c31:	mov    0x58(%rsp),%r8d
 29e3c36:	mov    0xc0(%rsp),%r9d
 29e3c3e:	mov    0xe0(%rsp),%r10d
 29e3c46:	cmp    $0x2,%eax
 29e3c49:	sete   %cl
 29e3c4c:	cmp    $0x3,%eax
 29e3c4f:	sete   %al
 29e3c52:	or     %eax,%ecx
 29e3c54:	test   %cl,%cl
 29e3c56:	je     29e4e32 <wasm[0]::function[1015]::helper::object_read+0x3eb2>
 29e3c5c:	mov    0x78(%rsp),%eax
 29e3c60:	test   %eax,%eax
 29e3c62:	je     29fbcdb <wasm[0]::function[1015]::helper::object_read+0x1ad5b>
 29e3c68:	test   %eax,%eax
 29e3c6a:	je     29fbcdd <wasm[0]::function[1015]::helper::object_read+0x1ad5d>
 29e3c70:	mov    0x2e0(%rsp),%r12
 29e3c78:	mov    0x28(%r12),%rcx
 29e3c7d:	mov    %eax,%edx
 29e3c7f:	mov    %rdx,%rax
 29e3c82:	add    0x20(%r12),%rax
 29e3c87:	xor    %rsi,%rsi
 29e3c8a:	cmp    %rcx,%rdx
 29e3c8d:	cmova  %rsi,%rax
 29e3c91:	mov    0x24(%rax),%eax
 29e3c94:	cmp    $0x3,%eax
 29e3c97:	je     29e3db9 <wasm[0]::function[1015]::helper::object_read+0x2e39>
 29e3c9d:	mov    0x78(%rsp),%eax
 29e3ca1:	xor    %ebx,%ebx
 29e3ca3:	test   %eax,%eax
 29e3ca5:	je     29fbcdf <wasm[0]::function[1015]::helper::object_read+0x1ad5f>
 29e3cab:	test   %eax,%eax
 29e3cad:	je     29fbce1 <wasm[0]::function[1015]::helper::object_read+0x1ad61>
 29e3cb3:	mov    0x2e0(%rsp),%r12
 29e3cbb:	mov    0x28(%r12),%rcx
 29e3cc0:	mov    0x20(%r12),%rdx
 29e3cc5:	mov    %eax,%edi
 29e3cc7:	lea    (%rdx,%rdi,1),%rax
 29e3ccb:	xor    %rsi,%rsi
 29e3cce:	cmp    %rcx,%rdi
 29e3cd1:	cmova  %rsi,%rax
 29e3cd5:	mov    0x28(%rax),%edi
 29e3cd8:	mov    0x2c(%rax),%eax
 29e3cdb:	test   %edi,%edi
 29e3cdd:	je     29fbce3 <wasm[0]::function[1015]::helper::object_read+0x1ad63>
 29e3ce3:	test   %edi,%edi
 29e3ce5:	je     29fbce5 <wasm[0]::function[1015]::helper::object_read+0x1ad65>
 29e3ceb:	mov    %edi,%edi
 29e3ced:	lea    0x10(%rdx,%rdi,1),%rdx
 29e3cf2:	cmp    %rcx,%rdi
 29e3cf5:	cmova  %rsi,%rdx
 29e3cf9:	mov    0x1e0(%rsp),%r14
 29e3d01:	mov    %r14d,%ecx
 29e3d04:	mov    (%rdx),%edx
 29e3d06:	cmp    %rdx,%rcx
 29e3d09:	jae    29e3eb8 <wasm[0]::function[1015]::helper::object_read+0x2f38>
 29e3d0f:	xor    %ebx,%ebx
 29e3d11:	test   %eax,%eax
 29e3d13:	je     29fbce7 <wasm[0]::function[1015]::helper::object_read+0x1ad67>
 29e3d19:	test   %eax,%eax
 29e3d1b:	je     29fbce9 <wasm[0]::function[1015]::helper::object_read+0x1ad69>
 29e3d21:	mov    0x2e0(%rsp),%r12
 29e3d29:	mov    0x28(%r12),%rsi
 29e3d2e:	mov    0x20(%r12),%rdi
 29e3d33:	mov    %eax,%r9d
 29e3d36:	lea    0x10(%rdi,%r9,1),%rcx
 29e3d3b:	xor    %r8,%r8
 29e3d3e:	cmp    %rsi,%r9
 29e3d41:	cmova  %r8,%rcx
 29e3d45:	mov    (%rcx),%ecx
 29e3d47:	mov    0x1e0(%rsp),%r14
 29e3d4f:	mov    %r14,%rdx
 29e3d52:	shr    $0x6,%edx
 29e3d55:	cmp    %ecx,%edx
 29e3d57:	jae    29fbceb <wasm[0]::function[1015]::helper::object_read+0x1ad6b>
 29e3d5d:	mov    %ecx,%r9d
 29e3d60:	shl    $0x3,%r9
 29e3d64:	shr    $0x20,%r9
 29e3d68:	test   %r9,%r9
 29e3d6b:	jne    29fbced <wasm[0]::function[1015]::helper::object_read+0x1ad6d>
 29e3d71:	shl    $0x3,%ecx
 29e3d74:	add    $0x18,%ecx
 29e3d77:	jb     29fbcef <wasm[0]::function[1015]::helper::object_read+0x1ad6f>
 29e3d7d:	add    %ecx,%eax
 29e3d7f:	jb     29fbcf1 <wasm[0]::function[1015]::helper::object_read+0x1ad71>
 29e3d85:	mov    %eax,%r10d
 29e3d88:	add    %r10,%rdi
 29e3d8b:	cmp    %rsi,%r10
 29e3d8e:	cmova  %r8,%rdi
 29e3d92:	shl    $0x3,%edx
 29e3d95:	lea    0x18(%rdx),%r11d
 29e3d99:	sub    %r11d,%ecx
 29e3d9c:	sub    %rcx,%rdi
 29e3d9f:	mov    (%rdi),%r11
 29e3da2:	bt     %r14,%r11
 29e3da6:	jae    29e3eb8 <wasm[0]::function[1015]::helper::object_read+0x2f38>
 29e3dac:	mov    0x278(%rsp),%rbx
 29e3db4:	jmp    29e3eb8 <wasm[0]::function[1015]::helper::object_read+0x2f38>
 29e3db9:	mov    0x78(%rsp),%edx
 29e3dbd:	xor    %ebx,%ebx
 29e3dbf:	test   %edx,%edx
 29e3dc1:	je     29fbcf3 <wasm[0]::function[1015]::helper::object_read+0x1ad73>
 29e3dc7:	test   %edx,%edx
 29e3dc9:	je     29fbcf5 <wasm[0]::function[1015]::helper::object_read+0x1ad75>
 29e3dcf:	mov    0x2e0(%rsp),%r12
 29e3dd7:	mov    0x28(%r12),%rax
 29e3ddc:	mov    0x20(%r12),%rcx
 29e3de1:	mov    %edx,%edi
 29e3de3:	lea    (%rcx,%rdi,1),%rsi
 29e3de7:	xor    %rdx,%rdx
 29e3dea:	cmp    %rax,%rdi
 29e3ded:	cmova  %rdx,%rsi
 29e3df1:	mov    0x30(%rsi),%esi
 29e3df4:	test   %esi,%esi
 29e3df6:	je     29fbcf7 <wasm[0]::function[1015]::helper::object_read+0x1ad77>
 29e3dfc:	test   %esi,%esi
 29e3dfe:	je     29fbcf9 <wasm[0]::function[1015]::helper::object_read+0x1ad79>
 29e3e04:	mov    %esi,%r8d
 29e3e07:	lea    0x10(%rcx,%r8,1),%rcx
 29e3e0c:	cmp    %rax,%r8
 29e3e0f:	cmova  %rdx,%rcx
 29e3e13:	mov    0x1e0(%rsp),%r14
 29e3e1b:	mov    %r14d,%eax
 29e3e1e:	mov    (%rcx),%ecx
 29e3e20:	cmp    %rcx,%rax
 29e3e23:	jae    29e3eb8 <wasm[0]::function[1015]::helper::object_read+0x2f38>
 29e3e29:	mov    0x2e0(%rsp),%r12
 29e3e31:	mov    0x28(%r12),%rax
 29e3e36:	mov    0x20(%r12),%rdi
 29e3e3b:	lea    0x10(%rdi,%r8,1),%rdx
 29e3e40:	xor    %rcx,%rcx
 29e3e43:	cmp    %rax,%r8
 29e3e46:	cmova  %rcx,%rdx
 29e3e4a:	mov    (%rdx),%edx
 29e3e4c:	mov    0x1e0(%rsp),%r14
 29e3e54:	cmp    %edx,%r14d
 29e3e57:	jae    29fbcfb <wasm[0]::function[1015]::helper::object_read+0x1ad7b>
 29e3e5d:	mov    %edx,%r8d
 29e3e60:	shl    $0x2,%r8
 29e3e64:	shr    $0x20,%r8
 29e3e68:	test   %r8,%r8
 29e3e6b:	jne    29fbcfd <wasm[0]::function[1015]::helper::object_read+0x1ad7d>
 29e3e71:	shl    $0x2,%edx
 29e3e74:	add    $0x14,%edx
 29e3e77:	jb     29fbcff <wasm[0]::function[1015]::helper::object_read+0x1ad7f>
 29e3e7d:	add    %edx,%esi
 29e3e7f:	jb     29fbd01 <wasm[0]::function[1015]::helper::object_read+0x1ad81>
 29e3e85:	mov    %esi,%r8d
 29e3e88:	lea    (%rdi,%r8,1),%rsi
 29e3e8c:	cmp    %rax,%r8
 29e3e8f:	cmova  %rcx,%rsi
 29e3e93:	mov    %r14,%rax
 29e3e96:	shl    $0x2,%eax
 29e3e99:	add    $0x14,%eax
 29e3e9f:	sub    %eax,%edx
 29e3ea1:	sub    %rdx,%rsi
 29e3ea4:	mov    (%rsi),%eax
 29e3ea6:	xor    %ebx,%ebx
 29e3ea8:	test   %eax,%eax
 29e3eaa:	je     29e3eb8 <wasm[0]::function[1015]::helper::object_read+0x2f38>
 29e3eb0:	mov    0x278(%rsp),%rbx
 29e3eb8:	mov    0x78(%rsp),%r11d
 29e3ebd:	mov    0xa0(%rsp),%edx
 29e3ec4:	mov    0x48(%rsp),%ecx
 29e3ec8:	mov    %rcx,0x1e8(%rsp)
 29e3ed0:	mov    0x80(%rsp),%esi
 29e3ed7:	mov    %rsi,0x1f0(%rsp)
 29e3edf:	mov    0xa8(%rsp),%edi
 29e3ee6:	mov    %rdi,0x1f8(%rsp)
 29e3eee:	mov    0xb8(%rsp),%edi
 29e3ef5:	mov    0x58(%rsp),%r8d
 29e3efa:	mov    0xc0(%rsp),%r9d
 29e3f02:	mov    0xe0(%rsp),%r10d
 29e3f0a:	test   %ebx,%ebx
 29e3f0c:	je     29e4e32 <wasm[0]::function[1015]::helper::object_read+0x3eb2>
 29e3f12:	mov    0x78(%rsp),%eax
 29e3f16:	test   %eax,%eax
 29e3f18:	je     29fbd03 <wasm[0]::function[1015]::helper::object_read+0x1ad83>
 29e3f1e:	test   %eax,%eax
 29e3f20:	je     29fbd05 <wasm[0]::function[1015]::helper::object_read+0x1ad85>
 29e3f26:	mov    0x2e0(%rsp),%r12
 29e3f2e:	mov    0x28(%r12),%rcx
 29e3f33:	mov    %eax,%edx
 29e3f35:	mov    %rdx,%rax
 29e3f38:	add    0x20(%r12),%rax
 29e3f3d:	xor    %rsi,%rsi
 29e3f40:	cmp    %rcx,%rdx
 29e3f43:	cmova  %rsi,%rax
 29e3f47:	mov    0x24(%rax),%eax
 29e3f4a:	cmp    $0x3,%eax
 29e3f4d:	je     29e47c1 <wasm[0]::function[1015]::helper::object_read+0x3841>
 29e3f53:	mov    0x78(%rsp),%r11d
 29e3f58:	test   %r11d,%r11d
 29e3f5b:	je     29fbd07 <wasm[0]::function[1015]::helper::object_read+0x1ad87>
 29e3f61:	test   %r11d,%r11d
 29e3f64:	je     29fbd09 <wasm[0]::function[1015]::helper::object_read+0x1ad89>
 29e3f6a:	mov    0x2e0(%rsp),%r12
 29e3f72:	mov    0x28(%r12),%rax
 29e3f77:	mov    %r11d,%edx
 29e3f7a:	mov    %rdx,%rcx
 29e3f7d:	add    0x20(%r12),%rcx
 29e3f82:	xor    %rsi,%rsi
 29e3f85:	cmp    %rax,%rdx
 29e3f88:	cmova  %rsi,%rcx
 29e3f8c:	mov    0x24(%rcx),%eax
 29e3f8f:	mov    0xa0(%rsp),%edx
 29e3f96:	mov    0x48(%rsp),%ecx
 29e3f9a:	mov    %rcx,0x1e8(%rsp)
 29e3fa2:	mov    0x80(%rsp),%esi
 29e3fa9:	mov    %rsi,0x1f0(%rsp)
 29e3fb1:	mov    0xa8(%rsp),%edi
 29e3fb8:	mov    %rdi,0x1f8(%rsp)
 29e3fc0:	mov    0xb8(%rsp),%edi
 29e3fc7:	mov    0x58(%rsp),%r8d
 29e3fcc:	mov    0xc0(%rsp),%r9d
 29e3fd4:	mov    0xe0(%rsp),%r10d
 29e3fdc:	cmp    $0x2,%eax
 29e3fdf:	jne    29e4e32 <wasm[0]::function[1015]::helper::object_read+0x3eb2>
 29e3fe5:	mov    0x78(%rsp),%eax
 29e3fe9:	test   %eax,%eax
 29e3feb:	je     29fbd0b <wasm[0]::function[1015]::helper::object_read+0x1ad8b>
 29e3ff1:	test   %eax,%eax
 29e3ff3:	je     29fbd0d <wasm[0]::function[1015]::helper::object_read+0x1ad8d>
 29e3ff9:	mov    0x2e0(%rsp),%r12
 29e4001:	mov    0x28(%r12),%rsi
 29e4006:	mov    0x20(%r12),%rdi
 29e400b:	mov    %eax,%r9d
 29e400e:	lea    (%rdi,%r9,1),%rax
 29e4012:	xor    %r8,%r8
 29e4015:	cmp    %rsi,%r9
 29e4018:	cmova  %r8,%rax
 29e401c:	mov    0x28(%rax),%r9d
 29e4020:	mov    %r9d,0xe8(%rsp)
 29e4028:	mov    0x2c(%rax),%r10d
 29e402c:	mov    %r10d,0x88(%rsp)
 29e4034:	test   %r9d,%r9d
 29e4037:	je     29fbd0f <wasm[0]::function[1015]::helper::object_read+0x1ad8f>
 29e403d:	test   %r9d,%r9d
 29e4040:	je     29fbd11 <wasm[0]::function[1015]::helper::object_read+0x1ad91>
 29e4046:	mov    %r9d,%r10d
 29e4049:	lea    0x10(%rdi,%r10,1),%r9
 29e404e:	cmp    %rsi,%r10
 29e4051:	cmova  %r8,%r9
 29e4055:	mov    (%r9),%r11d
 29e4058:	mov    %r11d,%r15d
 29e405b:	mov    %r15,%r14
 29e405e:	shl    $0x2,%r14
 29e4062:	mov    $0x20,%eax
 29e4067:	mov    %rax,0x238(%rsp)
 29e406f:	mov    %r14,%rax
 29e4072:	shr    $0x20,%rax
 29e4076:	test   %rax,%rax
 29e4079:	jne    29fbd13 <wasm[0]::function[1015]::helper::object_read+0x1ad93>
 29e407f:	mov    %r11,%rcx
 29e4082:	shl    $0x2,%ecx
 29e4085:	mov    %r11,0x240(%rsp)
 29e408d:	add    $0x14,%ecx
 29e4090:	jb     29fbd15 <wasm[0]::function[1015]::helper::object_read+0x1ad95>
 29e4096:	mov    0x190(%rsp),%rax
 29e409e:	mov    0x20(%rax),%rdi
 29e40a2:	mov    (%rdi),%eax
 29e40a4:	mov    %eax,%edx
 29e40a6:	mov    %ecx,%esi
 29e40a8:	add    $0xf,%rsi
 29e40af:	mov    %rsi,%r8
 29e40b2:	and    $0xfffffffffffffff0,%r8
 29e40b6:	add    %rdx,%r8
 29e40b9:	mov    0x4(%rdi),%r9d
 29e40bd:	mov    %rdi,0x230(%rsp)
 29e40c5:	cmp    %r9,%r8
 29e40c8:	ja     29fa5ed <wasm[0]::function[1015]::helper::object_read+0x1966d>
 29e40ce:	add    $0xf,%ecx
 29e40d4:	and    $0xfffffff0,%ecx
 29e40d7:	add    %eax,%ecx
 29e40d9:	mov    0x230(%rsp),%r12
 29e40e1:	mov    %ecx,(%r12)
 29e40e5:	mov    0x2e0(%rsp),%r12
 29e40ed:	mov    0x20(%r12),%rdi
 29e40f2:	lea    (%rdi,%rdx,1),%rcx
 29e40f6:	movl   $0xa800000e,(%rdi,%rdx,1)
 29e40fd:	mov    0x190(%rsp),%r8
 29e4105:	mov    0x28(%r8),%r8
 29e4109:	mov    0x194(%r8),%r8d
 29e4110:	mov    %r8d,0x4(%rdi,%rdx,1)
 29e4115:	and    $0xfffffffffffffff0,%rsi
 29e4119:	mov    %esi,0x8(%rdi,%rdx,1)
 29e411d:	mov    %eax,0xb0(%rsp)
 29e4124:	mov    0x240(%rsp),%rdx
 29e412c:	mov    %edx,0x10(%rcx)
 29e412f:	test   %eax,%eax
 29e4131:	je     29fbd17 <wasm[0]::function[1015]::helper::object_read+0x1ad97>
 29e4137:	mov    0x2e0(%rsp),%r12
 29e413f:	mov    0x28(%r12),%rcx
 29e4144:	mov    0x20(%r12),%rdx
 29e4149:	mov    %eax,%esi
 29e414b:	lea    (%rdx,%rsi,1),%rax
 29e414f:	lea    0x10(%rdx,%rsi,1),%rdi
 29e4154:	xor    %r8,%r8
 29e4157:	cmp    %rcx,%rsi
 29e415a:	cmova  %r8,%rdi
 29e415e:	mov    (%rdi),%edi
 29e4160:	cmp    %rdi,%r15
 29e4163:	ja     29fbd19 <wasm[0]::function[1015]::helper::object_read+0x1ad99>
 29e4169:	lea    0x14(%rdx,%rsi,1),%r13
 29e416e:	mov    %r13,%rsi
 29e4171:	add    %r14,%rsi
 29e4174:	jb     29fbd1b <wasm[0]::function[1015]::helper::object_read+0x1ad9b>
 29e417a:	add    %rdx,%rcx
 29e417d:	cmp    %rcx,%rsi
 29e4180:	ja     29fbd1d <wasm[0]::function[1015]::helper::object_read+0x1ad9d>
 29e4186:	mov    0x88(%rsp),%r12d
 29e418e:	mov    0xe8(%rsp),%ebx
 29e4195:	mov    0x78(%rsp),%esi
 29e4199:	mov    0xa0(%rsp),%edi
 29e41a0:	mov    0x48(%rsp),%r9d
 29e41a5:	mov    0x80(%rsp),%r11d
 29e41ad:	mov    0xa8(%rsp),%ecx
 29e41b4:	mov    0xb8(%rsp),%edx
 29e41bb:	mov    0x58(%rsp),%r8d
 29e41c0:	mov    0xc0(%rsp),%r10d
 29e41c8:	mov    0xe0(%rsp),%r14d
 29e41d0:	lea    0x14(%rax,%r15,4),%rax
 29e41d5:	mov    %rax,0x220(%rsp)
 29e41dd:	test   %r15,%r15
 29e41e0:	je     29e42d5 <wasm[0]::function[1015]::helper::object_read+0x3355>
 29e41e6:	mov    %r12d,0x130(%rsp)
 29e41ee:	mov    %ebx,0x148(%rsp)
 29e41f5:	mov    %esi,0x118(%rsp)
 29e41fc:	mov    %edi,0x98(%rsp)
 29e4203:	mov    %r9d,0x140(%rsp)
 29e420b:	mov    %r11d,0xd0(%rsp)
 29e4213:	mov    %ecx,0x100(%rsp)
 29e421a:	mov    %edx,0x120(%rsp)
 29e4221:	mov    %r8d,0x110(%rsp)
 29e4229:	mov    %r10d,0xe8(%rsp)
 29e4231:	mov    %r14d,0x88(%rsp)
 29e4239:	mov    0x2e8(%rsp),%r15
 29e4241:	mov    (%r15),%rcx
 29e4244:	mov    0x228(%rsp),%rax
 29e424c:	cmp    %rax,%rcx
 29e424f:	jae    29fa623 <wasm[0]::function[1015]::helper::object_read+0x196a3>
 29e4255:	movl   $0x0,0x0(%r13)
 29e425d:	mov    0x130(%rsp),%r12d
 29e4265:	mov    0x148(%rsp),%ebx
 29e426c:	mov    0x118(%rsp),%esi
 29e4273:	mov    0x98(%rsp),%edi
 29e427a:	mov    0x140(%rsp),%r9d
 29e4282:	mov    0xd0(%rsp),%r11d
 29e428a:	mov    0x100(%rsp),%ecx
 29e4291:	mov    0x120(%rsp),%edx
 29e4298:	mov    0x110(%rsp),%r8d
 29e42a0:	mov    0xe8(%rsp),%r10d
 29e42a8:	mov    0x88(%rsp),%r14d
 29e42b0:	add    $0x4,%r13
 29e42b7:	mov    0x220(%rsp),%r15
 29e42bf:	cmp    %r15,%r13
 29e42c2:	je     29e42d5 <wasm[0]::function[1015]::helper::object_read+0x3355>
 29e42c8:	mov    %r15,0x220(%rsp)
 29e42d0:	jmp    29e41e6 <wasm[0]::function[1015]::helper::object_read+0x3266>
 29e42d5:	mov    %r12d,0x148(%rsp)
 29e42dd:	mov    %ebx,0x130(%rsp)
 29e42e4:	xor    %r13d,%r13d
 29e42e7:	mov    0x190(%rsp),%rax
 29e42ef:	mov    0x28(%rax),%rax
 29e42f3:	mov    0x120(%rax),%r15d
 29e42fa:	mov    %r15,0x220(%rsp)
 29e4302:	mov    $0x10,%r15d
 29e4308:	mov    %r15,0x218(%rsp)
 29e4310:	mov    0x13c(%rax),%ebx
 29e4316:	mov    %rbx,0x1d8(%rsp)
 29e431e:	mov    %esi,0x88(%rsp)
 29e4325:	mov    %edi,0xe8(%rsp)
 29e432c:	mov    %r9d,0x110(%rsp)
 29e4334:	mov    %r11d,0x120(%rsp)
 29e433c:	mov    %ecx,0x100(%rsp)
 29e4343:	mov    %edx,0xd0(%rsp)
 29e434a:	mov    %r8d,0x140(%rsp)
 29e4352:	mov    %r10d,0x98(%rsp)
 29e435a:	mov    %r14d,0x118(%rsp)
 29e4362:	mov    0x2e8(%rsp),%r15
 29e436a:	mov    (%r15),%r8
 29e436d:	mov    0x228(%rsp),%rax
 29e4375:	cmp    %rax,%r8
 29e4378:	jae    29fa65b <wasm[0]::function[1015]::helper::object_read+0x196db>
 29e437e:	mov    0x240(%rsp),%rcx
 29e4386:	jmp    29e4393 <wasm[0]::function[1015]::helper::object_read+0x3413>
 29e438b:	mov    0x240(%rsp),%rcx
 29e4393:	cmp    %ecx,%r13d
 29e4396:	jae    29e46e3 <wasm[0]::function[1015]::helper::object_read+0x3763>
 29e439c:	mov    0x148(%rsp),%edx
 29e43a3:	test   %edx,%edx
 29e43a5:	je     29fbd1f <wasm[0]::function[1015]::helper::object_read+0x1ad9f>
 29e43ab:	test   %edx,%edx
 29e43ad:	je     29fbd21 <wasm[0]::function[1015]::helper::object_read+0x1ada1>
 29e43b3:	mov    0x2e0(%rsp),%r12
 29e43bb:	mov    0x28(%r12),%rax
 29e43c0:	mov    0x20(%r12),%rcx
 29e43c5:	mov    %edx,%r8d
 29e43c8:	lea    0x10(%rcx,%r8,1),%rdi
 29e43cd:	xor    %rsi,%rsi
 29e43d0:	cmp    %rax,%r8
 29e43d3:	cmova  %rsi,%rdi
 29e43d7:	mov    (%rdi),%r9d
 29e43da:	mov    %r13,%rdi
 29e43dd:	shr    $0x6,%edi
 29e43e0:	cmp    %r9d,%edi
 29e43e3:	jae    29fbd23 <wasm[0]::function[1015]::helper::object_read+0x1ada3>
 29e43e9:	mov    %r9d,%r8d
 29e43ec:	shl    $0x3,%r8
 29e43f0:	shr    $0x20,%r8
 29e43f4:	test   %r8,%r8
 29e43f7:	jne    29fbd25 <wasm[0]::function[1015]::helper::object_read+0x1ada5>
 29e43fd:	shl    $0x3,%r9d
 29e4401:	add    $0x18,%r9d
 29e4405:	jb     29fbd27 <wasm[0]::function[1015]::helper::object_read+0x1ada7>
 29e440b:	add    %r9d,%edx
 29e440e:	jb     29fbd29 <wasm[0]::function[1015]::helper::object_read+0x1ada9>
 29e4414:	mov    %edx,%edx
 29e4416:	add    %rdx,%rcx
 29e4419:	cmp    %rax,%rdx
 29e441c:	cmova  %rsi,%rcx
 29e4420:	shl    $0x3,%edi
 29e4423:	lea    0x18(%rdi),%eax
 29e4426:	sub    %eax,%r9d
 29e4429:	sub    %r9,%rcx
 29e442c:	mov    (%rcx),%rax
 29e442f:	bt     %r13,%rax
 29e4433:	jb     29e444e <wasm[0]::function[1015]::helper::object_read+0x34ce>
 29e4439:	mov    0x230(%rsp),%rbx
 29e4441:	mov    0x1d8(%rsp),%r15
 29e4449:	jmp    29e4683 <wasm[0]::function[1015]::helper::object_read+0x3703>
 29e444e:	mov    0x130(%rsp),%eax
 29e4455:	test   %eax,%eax
 29e4457:	je     29fbd2b <wasm[0]::function[1015]::helper::object_read+0x1adab>
 29e445d:	test   %eax,%eax
 29e445f:	je     29fbd2d <wasm[0]::function[1015]::helper::object_read+0x1adad>
 29e4465:	mov    0x2e0(%rsp),%r12
 29e446d:	mov    0x28(%r12),%rcx
 29e4472:	mov    0x20(%r12),%rdx
 29e4477:	mov    %eax,%r8d
 29e447a:	lea    0x10(%rdx,%r8,1),%rdi
 29e447f:	xor    %rsi,%rsi
 29e4482:	cmp    %rcx,%r8
 29e4485:	cmova  %rsi,%rdi
 29e4489:	mov    (%rdi),%edi
 29e448b:	cmp    %edi,%r13d
 29e448e:	jae    29fbd2f <wasm[0]::function[1015]::helper::object_read+0x1adaf>
 29e4494:	mov    %edi,%r8d
 29e4497:	shl    $0x3,%r8
 29e449b:	shr    $0x20,%r8
 29e449f:	test   %r8,%r8
 29e44a2:	jne    29fbd31 <wasm[0]::function[1015]::helper::object_read+0x1adb1>
 29e44a8:	shl    $0x3,%edi
 29e44ab:	add    $0x18,%edi
 29e44ae:	jb     29fbd33 <wasm[0]::function[1015]::helper::object_read+0x1adb3>
 29e44b4:	add    %edi,%eax
 29e44b6:	jb     29fbd35 <wasm[0]::function[1015]::helper::object_read+0x1adb5>
 29e44bc:	mov    %eax,%r8d
 29e44bf:	lea    (%rdx,%r8,1),%rax
 29e44c3:	cmp    %rcx,%r8
 29e44c6:	cmova  %rsi,%rax
 29e44ca:	mov    %r13,%rcx
 29e44cd:	shl    $0x3,%ecx
 29e44d0:	add    $0x18,%ecx
 29e44d6:	sub    %ecx,%edi
 29e44d8:	sub    %rdi,%rax
 29e44db:	mov    (%rax),%r12
 29e44de:	movl   $0x0,0xf0(%rsp)
 29e44e9:	mov    0x230(%rsp),%rbx
 29e44f1:	mov    (%rbx),%eax
 29e44f3:	mov    %eax,%edx
 29e44f5:	lea    0x20(%rdx),%rcx
 29e44f9:	mov    0x4(%rbx),%esi
 29e44fc:	cmp    %rsi,%rcx
 29e44ff:	ja     29fa69b <wasm[0]::function[1015]::helper::object_read+0x1971b>
 29e4505:	lea    0x20(%rax),%ecx
 29e4508:	mov    %ecx,(%rbx)
 29e450a:	mov    0x2e0(%rsp),%rcx
 29e4512:	mov    0x20(%rcx),%rsi
 29e4516:	lea    (%rsi,%rdx,1),%rcx
 29e451a:	movl   $0xb0000042,(%rsi,%rdx,1)
 29e4521:	mov    0x220(%rsp),%rdi
 29e4529:	mov    %edi,0x4(%rsi,%rdx,1)
 29e452d:	mov    0x238(%rsp),%rdi
 29e4535:	mov    %edi,0x8(%rsi,%rdx,1)
 29e4539:	mov    %eax,0xd8(%rsp)
 29e4540:	mov    %r12,0x10(%rcx)
 29e4544:	movl   $0x3,0x18(%rcx)
 29e454b:	mov    0xf0(%rsp),%edx
 29e4552:	mov    %edx,0x1c(%rcx)
 29e4555:	mov    0x190(%rsp),%rcx
 29e455d:	mov    0xa20(%rcx),%ecx
 29e4563:	mov    %ecx,0xf0(%rsp)
 29e456a:	test   %eax,%eax
 29e456c:	je     29fbd37 <wasm[0]::function[1015]::helper::object_read+0x1adb7>
 29e4572:	test   %ecx,%ecx
 29e4574:	je     29fbd39 <wasm[0]::function[1015]::helper::object_read+0x1adb9>
 29e457a:	mov    (%rbx),%eax
 29e457c:	mov    %eax,%ecx
 29e457e:	lea    0x20(%rcx),%rdx
 29e4582:	mov    0x4(%rbx),%esi
 29e4585:	cmp    %rsi,%rdx
 29e4588:	ja     29fa6d5 <wasm[0]::function[1015]::helper::object_read+0x19755>
 29e458e:	mov    0x1d8(%rsp),%r15
 29e4596:	lea    0x20(%rax),%edx
 29e4599:	mov    %edx,(%rbx)
 29e459b:	mov    0x2e0(%rsp),%r12
 29e45a3:	mov    0x20(%r12),%rsi
 29e45a8:	lea    (%rsi,%rcx,1),%rdx
 29e45ac:	movl   $0xb0000072,(%rsi,%rcx,1)
 29e45b3:	mov    %r15d,0x4(%rsi,%rcx,1)
 29e45b8:	mov    0x238(%rsp),%rdi
 29e45c0:	mov    %edi,0x8(%rsi,%rcx,1)
 29e45c4:	movl   $0xe,0x10(%rdx)
 29e45cb:	mov    0xd8(%rsp),%r8d
 29e45d3:	mov    %r8d,0x14(%rdx)
 29e45d7:	mov    0xf0(%rsp),%r9d
 29e45df:	mov    %r9d,0x18(%rdx)
 29e45e3:	mov    %r9d,0x1c(%rdx)
 29e45e7:	mov    0xb0(%rsp),%ecx
 29e45ee:	test   %ecx,%ecx
 29e45f0:	je     29fbd3b <wasm[0]::function[1015]::helper::object_read+0x1adbb>
 29e45f6:	test   %eax,%eax
 29e45f8:	je     29fbd3d <wasm[0]::function[1015]::helper::object_read+0x1adbd>
 29e45fe:	test   %ecx,%ecx
 29e4600:	je     29fbd3f <wasm[0]::function[1015]::helper::object_read+0x1adbf>
 29e4606:	mov    0x2e0(%rsp),%r12
 29e460e:	mov    0x28(%r12),%rdx
 29e4613:	mov    0x20(%r12),%rsi
 29e4618:	mov    %ecx,%r9d
 29e461b:	lea    0x10(%rsi,%r9,1),%r8
 29e4620:	xor    %rdi,%rdi
 29e4623:	cmp    %rdx,%r9
 29e4626:	cmova  %rdi,%r8
 29e462a:	mov    (%r8),%r8d
 29e462d:	cmp    %r8d,%r13d
 29e4630:	jae    29fbd41 <wasm[0]::function[1015]::helper::object_read+0x1adc1>
 29e4636:	mov    %r8d,%r9d
 29e4639:	shl    $0x2,%r9
 29e463d:	shr    $0x20,%r9
 29e4641:	test   %r9,%r9
 29e4644:	jne    29fbd43 <wasm[0]::function[1015]::helper::object_read+0x1adc3>
 29e464a:	shl    $0x2,%r8d
 29e464e:	add    $0x14,%r8d
 29e4652:	jb     29fbd45 <wasm[0]::function[1015]::helper::object_read+0x1adc5>
 29e4658:	add    %r8d,%ecx
 29e465b:	jb     29fbd47 <wasm[0]::function[1015]::helper::object_read+0x1adc7>
 29e4661:	mov    %ecx,%r9d
 29e4664:	lea    (%rsi,%r9,1),%rcx
 29e4668:	cmp    %rdx,%r9
 29e466b:	cmova  %rdi,%rcx
 29e466f:	mov    %r13,%rdx
 29e4672:	shl    $0x2,%edx
 29e4675:	add    $0x14,%edx
 29e467b:	sub    %edx,%r8d
 29e467e:	sub    %r8,%rcx
 29e4681:	mov    %eax,(%rcx)
 29e4683:	mov    0x88(%rsp),%esi
 29e468a:	mov    0xe8(%rsp),%edi
 29e4691:	mov    0x110(%rsp),%r9d
 29e4699:	mov    0x120(%rsp),%r11d
 29e46a1:	mov    0x100(%rsp),%ecx
 29e46a8:	mov    0xd0(%rsp),%edx
 29e46af:	mov    0x140(%rsp),%r8d
 29e46b7:	mov    0x98(%rsp),%r10d
 29e46bf:	mov    0x118(%rsp),%r14d
 29e46c7:	add    $0x1,%r13d
 29e46ce:	mov    %r15,0x1d8(%rsp)
 29e46d6:	mov    %rbx,0x230(%rsp)
 29e46de:	jmp    29e431e <wasm[0]::function[1015]::helper::object_read+0x339e>
 29e46e3:	mov    0x88(%rsp),%r11d
 29e46eb:	test   %r11d,%r11d
 29e46ee:	je     29fbd49 <wasm[0]::function[1015]::helper::object_read+0x1adc9>
 29e46f4:	mov    0xb0(%rsp),%ecx
 29e46fb:	test   %ecx,%ecx
 29e46fd:	je     29fbd4b <wasm[0]::function[1015]::helper::object_read+0x1adcb>
 29e4703:	test   %r11d,%r11d
 29e4706:	je     29fbd4d <wasm[0]::function[1015]::helper::object_read+0x1adcd>
 29e470c:	mov    0x2e0(%rsp),%r12
 29e4714:	mov    0x28(%r12),%rdx
 29e4719:	mov    0x20(%r12),%rax
 29e471e:	mov    %r11d,%esi
 29e4721:	add    %rsi,%rax
 29e4724:	xor    %rdi,%rdi
 29e4727:	cmp    %rdx,%rsi
 29e472a:	cmova  %rdi,%rax
 29e472e:	mov    %ecx,0x20(%rax)
 29e4731:	mov    0x190(%rsp),%rcx
 29e4739:	mov    0xa00(%rcx),%edx
 29e473f:	mov    0xa10(%rcx),%ecx
 29e4745:	test   %edx,%edx
 29e4747:	je     29fbd4f <wasm[0]::function[1015]::helper::object_read+0x1adcf>
 29e474d:	mov    %edx,0x28(%rax)
 29e4750:	test   %ecx,%ecx
 29e4752:	je     29fbd51 <wasm[0]::function[1015]::helper::object_read+0x1add1>
 29e4758:	mov    %ecx,0x2c(%rax)
 29e475b:	movl   $0x0,0x30(%rax)
 29e4762:	movl   $0x0,0x24(%rax)
 29e4769:	mov    0xe8(%rsp),%edx
 29e4770:	mov    0x110(%rsp),%ecx
 29e4777:	mov    %rcx,0x1e8(%rsp)
 29e477f:	mov    0x120(%rsp),%esi
 29e4786:	mov    %rsi,0x1f0(%rsp)
 29e478e:	mov    0x100(%rsp),%edi
 29e4795:	mov    %rdi,0x1f8(%rsp)
 29e479d:	mov    0xd0(%rsp),%edi
 29e47a4:	mov    0x140(%rsp),%r8d
 29e47ac:	mov    0x98(%rsp),%r9d
 29e47b4:	mov    0x118(%rsp),%r10d
 29e47bc:	jmp    29e4e32 <wasm[0]::function[1015]::helper::object_read+0x3eb2>
 29e47c1:	mov    0x78(%rsp),%edx
 29e47c5:	test   %edx,%edx
 29e47c7:	je     29fbd53 <wasm[0]::function[1015]::helper::object_read+0x1add3>
 29e47cd:	test   %edx,%edx
 29e47cf:	je     29fbd55 <wasm[0]::function[1015]::helper::object_read+0x1add5>
 29e47d5:	mov    0x2e0(%rsp),%r12
 29e47dd:	mov    0x28(%r12),%rax
 29e47e2:	mov    0x20(%r12),%rcx
 29e47e7:	mov    %edx,%edi
 29e47e9:	lea    (%rcx,%rdi,1),%rsi
 29e47ed:	xor    %rdx,%rdx
 29e47f0:	cmp    %rax,%rdi
 29e47f3:	cmova  %rdx,%rsi
 29e47f7:	mov    0x30(%rsi),%esi
 29e47fa:	mov    %esi,0x88(%rsp)
 29e4801:	test   %esi,%esi
 29e4803:	je     29fbd57 <wasm[0]::function[1015]::helper::object_read+0x1add7>
 29e4809:	test   %esi,%esi
 29e480b:	je     29fbd59 <wasm[0]::function[1015]::helper::object_read+0x1add9>
 29e4811:	mov    %esi,%esi
 29e4813:	lea    0x10(%rcx,%rsi,1),%rcx
 29e4818:	cmp    %rax,%rsi
 29e481b:	cmova  %rdx,%rcx
 29e481f:	mov    (%rcx),%eax
 29e4821:	mov    %eax,%ebx
 29e4823:	mov    %rbx,%r12
 29e4826:	shl    $0x2,%r12
 29e482a:	mov    $0x20,%ecx
 29e482f:	mov    %rcx,0x1d0(%rsp)
 29e4837:	mov    %r12,%rcx
 29e483a:	shr    $0x20,%rcx
 29e483e:	test   %rcx,%rcx
 29e4841:	jne    29fbd5b <wasm[0]::function[1015]::helper::object_read+0x1addb>
 29e4847:	mov    %rax,%rcx
 29e484a:	shl    $0x2,%ecx
 29e484d:	mov    %rax,0x1d8(%rsp)
 29e4855:	add    $0x14,%ecx
 29e4858:	jb     29fbd5d <wasm[0]::function[1015]::helper::object_read+0x1addd>
 29e485e:	mov    0x190(%rsp),%rax
 29e4866:	mov    0x20(%rax),%rdi
 29e486a:	mov    (%rdi),%eax
 29e486c:	mov    %eax,%edx
 29e486e:	mov    %ecx,%esi
 29e4870:	add    $0xf,%rsi
 29e4877:	mov    %rsi,%r8
 29e487a:	and    $0xfffffffffffffff0,%r8
 29e487e:	add    %rdx,%r8
 29e4881:	mov    0x4(%rdi),%r9d
 29e4885:	mov    %rdi,0x1c8(%rsp)
 29e488d:	cmp    %r9,%r8
 29e4890:	ja     29fa713 <wasm[0]::function[1015]::helper::object_read+0x19793>
 29e4896:	add    $0xf,%ecx
 29e489c:	and    $0xfffffff0,%ecx
 29e489f:	lea    (%rax,%rcx,1),%edi
 29e48a2:	mov    0x1c8(%rsp),%rcx
 29e48aa:	mov    %edi,(%rcx)
 29e48ac:	mov    0x2e0(%rsp),%rcx
 29e48b4:	mov    0x20(%rcx),%rdi
 29e48b8:	lea    (%rdi,%rdx,1),%rcx
 29e48bc:	movl   $0xa800000e,(%rdi,%rdx,1)
 29e48c3:	mov    0x190(%rsp),%r8
 29e48cb:	mov    0x28(%r8),%r8
 29e48cf:	mov    0x194(%r8),%r8d
 29e48d6:	mov    %r8d,0x4(%rdi,%rdx,1)
 29e48db:	and    $0xfffffffffffffff0,%rsi
 29e48df:	mov    %esi,0x8(%rdi,%rdx,1)
 29e48e3:	mov    %eax,0xe8(%rsp)
 29e48ea:	mov    0x1d8(%rsp),%r14
 29e48f2:	mov    %r14d,0x10(%rcx)
 29e48f6:	test   %eax,%eax
 29e48f8:	je     29fbd5f <wasm[0]::function[1015]::helper::object_read+0x1addf>
 29e48fe:	mov    0x2e0(%rsp),%rcx
 29e4906:	mov    0x28(%rcx),%r9
 29e490a:	mov    0x20(%rcx),%r10
 29e490e:	mov    %eax,%r11d
 29e4911:	lea    (%r10,%r11,1),%r14
 29e4915:	lea    0x10(%r10,%r11,1),%rsi
 29e491a:	xor    %rax,%rax
 29e491d:	cmp    %r9,%r11
 29e4920:	cmova  %rax,%rsi
 29e4924:	mov    (%rsi),%eax
 29e4926:	cmp    %rax,%rbx
 29e4929:	ja     29fbd61 <wasm[0]::function[1015]::helper::object_read+0x1ade1>
 29e492f:	lea    0x14(%r10,%r11,1),%r13
 29e4934:	mov    %r13,%rax
 29e4937:	add    %r12,%rax
 29e493a:	jb     29fbd63 <wasm[0]::function[1015]::helper::object_read+0x1ade3>
 29e4940:	lea    (%r10,%r9,1),%rcx
 29e4944:	cmp    %rcx,%rax
 29e4947:	ja     29fbd65 <wasm[0]::function[1015]::helper::object_read+0x1ade5>
 29e494d:	mov    0x88(%rsp),%ecx
 29e4954:	mov    0x78(%rsp),%eax
 29e4958:	mov    0xa0(%rsp),%edx
 29e495f:	mov    0x48(%rsp),%esi
 29e4963:	mov    0x80(%rsp),%edi
 29e496a:	mov    0xa8(%rsp),%r8d
 29e4972:	mov    0xb8(%rsp),%r9d
 29e497a:	mov    0x58(%rsp),%r10d
 29e497f:	mov    0xc0(%rsp),%r11d
 29e4987:	mov    0xe0(%rsp),%r15d
 29e498f:	lea    0x14(%r14,%rbx,4),%r14
 29e4994:	test   %rbx,%rbx
 29e4997:	je     29e4a61 <wasm[0]::function[1015]::helper::object_read+0x3ae1>
 29e499d:	mov    %ecx,0xb0(%rsp)
 29e49a4:	mov    %eax,0x118(%rsp)
 29e49ab:	mov    %edx,0x98(%rsp)
 29e49b2:	mov    %esi,0x140(%rsp)
 29e49b9:	mov    %edi,0xd0(%rsp)
 29e49c0:	mov    %r8d,0x100(%rsp)
 29e49c8:	mov    %r9d,0x120(%rsp)
 29e49d0:	mov    %r10d,0x110(%rsp)
 29e49d8:	mov    %r11d,0x78(%rsp)
 29e49dd:	mov    %r15d,0x88(%rsp)
 29e49e5:	mov    0x2e8(%rsp),%r15
 29e49ed:	mov    (%r15),%rax
 29e49f0:	mov    0x228(%rsp),%r11
 29e49f8:	cmp    %r11,%rax
 29e49fb:	jae    29fa750 <wasm[0]::function[1015]::helper::object_read+0x197d0>
 29e4a01:	movl   $0x0,0x0(%r13)
 29e4a09:	mov    0xb0(%rsp),%ecx
 29e4a10:	mov    0x118(%rsp),%eax
 29e4a17:	mov    0x98(%rsp),%edx
 29e4a1e:	mov    0x140(%rsp),%esi
 29e4a25:	mov    0xd0(%rsp),%edi
 29e4a2c:	mov    0x100(%rsp),%r8d
 29e4a34:	mov    0x120(%rsp),%r9d
 29e4a3c:	mov    0x110(%rsp),%r10d
 29e4a44:	mov    0x78(%rsp),%r11d
 29e4a49:	mov    0x88(%rsp),%r15d
 29e4a51:	add    $0x4,%r13
 29e4a58:	cmp    %r14,%r13
 29e4a5b:	jne    29e499d <wasm[0]::function[1015]::helper::object_read+0x3a1d>
 29e4a61:	mov    %ecx,0xb0(%rsp)
 29e4a68:	mov    0x190(%rsp),%rcx
 29e4a70:	mov    0xa20(%rcx),%ecx
 29e4a76:	mov    %ecx,0x118(%rsp)
 29e4a7d:	xor    %r13d,%r13d
 29e4a80:	mov    $0xb0000072,%ecx
 29e4a85:	mov    %rcx,0x1a0(%rsp)
 29e4a8d:	mov    0x190(%rsp),%rcx
 29e4a95:	mov    0x28(%rcx),%rcx
 29e4a99:	mov    0x13c(%rcx),%ebx
 29e4a9f:	mov    $0x20,%ecx
 29e4aa4:	mov    %rcx,0x198(%rsp)
 29e4aac:	mov    $0x10,%ecx
 29e4ab1:	mov    %rcx,0x2c8(%rsp)
 29e4ab9:	mov    %eax,0x148(%rsp)
 29e4ac0:	mov    %edx,0x88(%rsp)
 29e4ac7:	mov    %esi,0x78(%rsp)
 29e4acb:	mov    %edi,0x110(%rsp)
 29e4ad2:	mov    %r8d,0x120(%rsp)
 29e4ada:	mov    %r9d,0x100(%rsp)
 29e4ae2:	mov    %r10d,0xd0(%rsp)
 29e4aea:	mov    %r11d,0x140(%rsp)
 29e4af2:	mov    %r15d,0x98(%rsp)
 29e4afa:	mov    0x2e8(%rsp),%r15
 29e4b02:	mov    (%r15),%rax
 29e4b05:	mov    0x228(%rsp),%rcx
 29e4b0d:	cmp    %rcx,%rax
 29e4b10:	jae    29fa788 <wasm[0]::function[1015]::helper::object_read+0x19808>
 29e4b16:	mov    0x1d8(%rsp),%rcx
 29e4b1e:	jmp    29e4b2b <wasm[0]::function[1015]::helper::object_read+0x3bab>
 29e4b23:	mov    0x1d8(%rsp),%rcx
 29e4b2b:	cmp    %ecx,%r13d
 29e4b2e:	jae    29e4d5c <wasm[0]::function[1015]::helper::object_read+0x3ddc>
 29e4b34:	mov    0xb0(%rsp),%eax
 29e4b3b:	test   %eax,%eax
 29e4b3d:	je     29fbd67 <wasm[0]::function[1015]::helper::object_read+0x1ade7>
 29e4b43:	test   %eax,%eax
 29e4b45:	je     29fbd69 <wasm[0]::function[1015]::helper::object_read+0x1ade9>
 29e4b4b:	mov    0x2e0(%rsp),%r12
 29e4b53:	mov    0x28(%r12),%rsi
 29e4b58:	mov    0x20(%r12),%rdi
 29e4b5d:	mov    %eax,%r9d
 29e4b60:	lea    0x10(%rdi,%r9,1),%rcx
 29e4b65:	xor    %r8,%r8
 29e4b68:	cmp    %rsi,%r9
 29e4b6b:	cmova  %r8,%rcx
 29e4b6f:	mov    (%rcx),%ecx
 29e4b71:	cmp    %ecx,%r13d
 29e4b74:	jae    29fbd6b <wasm[0]::function[1015]::helper::object_read+0x1adeb>
 29e4b7a:	mov    %ecx,%r9d
 29e4b7d:	shl    $0x2,%r9
 29e4b81:	shr    $0x20,%r9
 29e4b85:	test   %r9,%r9
 29e4b88:	jne    29fbd6d <wasm[0]::function[1015]::helper::object_read+0x1aded>
 29e4b8e:	shl    $0x2,%ecx
 29e4b91:	add    $0x14,%ecx
 29e4b94:	jb     29fbd6f <wasm[0]::function[1015]::helper::object_read+0x1adef>
 29e4b9a:	add    %ecx,%eax
 29e4b9c:	jb     29fbd71 <wasm[0]::function[1015]::helper::object_read+0x1adf1>
 29e4ba2:	mov    %eax,%r10d
 29e4ba5:	add    %r10,%rdi
 29e4ba8:	cmp    %rsi,%r10
 29e4bab:	cmova  %r8,%rdi
 29e4baf:	mov    %r13,%r15
 29e4bb2:	shl    $0x2,%r15d
 29e4bb6:	lea    0x14(%r15),%r11d
 29e4bba:	sub    %r11d,%ecx
 29e4bbd:	sub    %rcx,%rdi
 29e4bc0:	mov    (%rdi),%r11d
 29e4bc3:	mov    %r11d,0x130(%rsp)
 29e4bcb:	test   %r11d,%r11d
 29e4bce:	jne    29e4be9 <wasm[0]::function[1015]::helper::object_read+0x3c69>
 29e4bd4:	mov    0x1d0(%rsp),%rcx
 29e4bdc:	mov    0x1c8(%rsp),%r14
 29e4be4:	jmp    29e4cff <wasm[0]::function[1015]::helper::object_read+0x3d7f>
 29e4be9:	test   %r11d,%r11d
 29e4bec:	je     29fbd73 <wasm[0]::function[1015]::helper::object_read+0x1adf3>
 29e4bf2:	mov    0x118(%rsp),%eax
 29e4bf9:	test   %eax,%eax
 29e4bfb:	je     29fbd75 <wasm[0]::function[1015]::helper::object_read+0x1adf5>
 29e4c01:	mov    0x1c8(%rsp),%r14
 29e4c09:	mov    (%r14),%eax
 29e4c0c:	mov    %eax,%esi
 29e4c0e:	lea    0x20(%rsi),%rcx
 29e4c12:	mov    0x4(%r14),%edx
 29e4c16:	cmp    %rdx,%rcx
 29e4c19:	ja     29fa7cb <wasm[0]::function[1015]::helper::object_read+0x1984b>
 29e4c1f:	lea    0x20(%rax),%ecx
 29e4c22:	mov    %ecx,(%r14)
 29e4c25:	mov    0x2e0(%rsp),%r12
 29e4c2d:	mov    0x20(%r12),%rdi
 29e4c32:	lea    (%rdi,%rsi,1),%rdx
 29e4c36:	movl   $0xb0000072,(%rdi,%rsi,1)
 29e4c3d:	mov    %ebx,0x4(%rdi,%rsi,1)
 29e4c41:	mov    0x1d0(%rsp),%rcx
 29e4c49:	mov    %ecx,0x8(%rdi,%rsi,1)
 29e4c4d:	movl   $0xe,0x10(%rdx)
 29e4c54:	mov    0x130(%rsp),%esi
 29e4c5b:	mov    %esi,0x14(%rdx)
 29e4c5e:	mov    0x118(%rsp),%esi
 29e4c65:	mov    %esi,0x18(%rdx)
 29e4c68:	mov    %esi,0x1c(%rdx)
 29e4c6b:	mov    0xe8(%rsp),%edx
 29e4c72:	test   %edx,%edx
 29e4c74:	je     29fbd77 <wasm[0]::function[1015]::helper::object_read+0x1adf7>
 29e4c7a:	test   %eax,%eax
 29e4c7c:	je     29fbd79 <wasm[0]::function[1015]::helper::object_read+0x1adf9>
 29e4c82:	test   %edx,%edx
 29e4c84:	je     29fbd7b <wasm[0]::function[1015]::helper::object_read+0x1adfb>
 29e4c8a:	mov    0x2e0(%rsp),%r12
 29e4c92:	mov    0x28(%r12),%rsi
 29e4c97:	mov    0x20(%r12),%rdi
 29e4c9c:	mov    %edx,%r10d
 29e4c9f:	lea    0x10(%rdi,%r10,1),%r9
 29e4ca4:	xor    %r8,%r8
 29e4ca7:	cmp    %rsi,%r10
 29e4caa:	cmova  %r8,%r9
 29e4cae:	mov    (%r9),%r9d
 29e4cb1:	cmp    %r9d,%r13d
 29e4cb4:	jae    29fbd7d <wasm[0]::function[1015]::helper::object_read+0x1adfd>
 29e4cba:	mov    %r9d,%r10d
 29e4cbd:	shl    $0x2,%r10
 29e4cc1:	shr    $0x20,%r10
 29e4cc5:	test   %r10,%r10
 29e4cc8:	jne    29fbd7f <wasm[0]::function[1015]::helper::object_read+0x1adff>
 29e4cce:	shl    $0x2,%r9d
 29e4cd2:	add    $0x14,%r9d
 29e4cd6:	jb     29fbd81 <wasm[0]::function[1015]::helper::object_read+0x1ae01>
 29e4cdc:	add    %r9d,%edx
 29e4cdf:	jb     29fbd83 <wasm[0]::function[1015]::helper::object_read+0x1ae03>
 29e4ce5:	mov    %edx,%r10d
 29e4ce8:	lea    (%rdi,%r10,1),%rdx
 29e4cec:	cmp    %rsi,%r10
 29e4cef:	cmova  %r8,%rdx
 29e4cf3:	lea    0x14(%r15),%esi
 29e4cf7:	sub    %esi,%r9d
 29e4cfa:	sub    %r9,%rdx
 29e4cfd:	mov    %eax,(%rdx)
 29e4cff:	mov    0x148(%rsp),%eax
 29e4d06:	mov    0x88(%rsp),%edx
 29e4d0d:	mov    0x78(%rsp),%esi
 29e4d11:	mov    0x110(%rsp),%edi
 29e4d18:	mov    0x120(%rsp),%r8d
 29e4d20:	mov    0x100(%rsp),%r9d
 29e4d28:	mov    0xd0(%rsp),%r10d
 29e4d30:	mov    0x140(%rsp),%r11d
 29e4d38:	mov    0x98(%rsp),%r15d
 29e4d40:	add    $0x1,%r13d
 29e4d47:	mov    %r14,0x1c8(%rsp)
 29e4d4f:	mov    %rcx,0x1d0(%rsp)
 29e4d57:	jmp    29e4ab9 <wasm[0]::function[1015]::helper::object_read+0x3b39>
 29e4d5c:	mov    0x148(%rsp),%r11d
 29e4d64:	test   %r11d,%r11d
 29e4d67:	je     29fbd85 <wasm[0]::function[1015]::helper::object_read+0x1ae05>
 29e4d6d:	mov    0xe8(%rsp),%ecx
 29e4d74:	test   %ecx,%ecx
 29e4d76:	je     29fbd87 <wasm[0]::function[1015]::helper::object_read+0x1ae07>
 29e4d7c:	test   %r11d,%r11d
 29e4d7f:	je     29fbd89 <wasm[0]::function[1015]::helper::object_read+0x1ae09>
 29e4d85:	mov    0x2e0(%rsp),%r12
 29e4d8d:	mov    0x28(%r12),%rdx
 29e4d92:	mov    0x20(%r12),%rax
 29e4d97:	mov    %r11d,%esi
 29e4d9a:	add    %rsi,%rax
 29e4d9d:	xor    %rdi,%rdi
 29e4da0:	cmp    %rdx,%rsi
 29e4da3:	cmova  %rdi,%rax
 29e4da7:	mov    %ecx,0x20(%rax)
 29e4daa:	mov    0x190(%rsp),%rcx
 29e4db2:	mov    0xa00(%rcx),%edx
 29e4db8:	mov    0xa10(%rcx),%ecx
 29e4dbe:	test   %edx,%edx
 29e4dc0:	je     29fbd8b <wasm[0]::function[1015]::helper::object_read+0x1ae0b>
 29e4dc6:	mov    %edx,0x28(%rax)
 29e4dc9:	test   %ecx,%ecx
 29e4dcb:	je     29fbd8d <wasm[0]::function[1015]::helper::object_read+0x1ae0d>
 29e4dd1:	mov    %ecx,0x2c(%rax)
 29e4dd4:	movl   $0x0,0x30(%rax)
 29e4ddb:	movl   $0x0,0x24(%rax)
 29e4de2:	mov    0x88(%rsp),%edx
 29e4de9:	mov    0x78(%rsp),%ecx
 29e4ded:	mov    %rcx,0x1e8(%rsp)
 29e4df5:	mov    0x110(%rsp),%esi
 29e4dfc:	mov    %rsi,0x1f0(%rsp)
 29e4e04:	mov    0x120(%rsp),%edi
 29e4e0b:	mov    %rdi,0x1f8(%rsp)
 29e4e13:	mov    0x100(%rsp),%edi
 29e4e1a:	mov    0xd0(%rsp),%r8d
 29e4e22:	mov    0x140(%rsp),%r9d
 29e4e2a:	mov    0x98(%rsp),%r10d
 29e4e32:	test   %r11d,%r11d
 29e4e35:	je     29fbd8f <wasm[0]::function[1015]::helper::object_read+0x1ae0f>
 29e4e3b:	test   %r11d,%r11d
 29e4e3e:	je     29fbd91 <wasm[0]::function[1015]::helper::object_read+0x1ae11>
 29e4e44:	mov    0x2e0(%rsp),%r12
 29e4e4c:	mov    0x28(%r12),%rax
 29e4e51:	mov    0x20(%r12),%r13
 29e4e56:	mov    %r11d,%r11d
 29e4e59:	lea    0x0(%r13,%r11,1),%r12
 29e4e5e:	xor    %r14,%r14
 29e4e61:	cmp    %rax,%r11
 29e4e64:	cmova  %r14,%r12
 29e4e68:	mov    0x10(%r12),%ebx
 29e4e6d:	test   %ebx,%ebx
 29e4e6f:	je     29fbd93 <wasm[0]::function[1015]::helper::object_read+0x1ae13>
 29e4e75:	test   %ebx,%ebx
 29e4e77:	je     29fbd95 <wasm[0]::function[1015]::helper::object_read+0x1ae15>
 29e4e7d:	mov    %ebx,%ecx
 29e4e7f:	lea    0x10(%r13,%rcx,1),%r13
 29e4e84:	cmp    %rax,%rcx
 29e4e87:	cmova  %r14,%r13
 29e4e8b:	mov    0x0(%r13),%eax
 29e4e8f:	mov    0x24(%r12),%esi
 29e4e94:	test   %esi,%esi
 29e4e96:	je     29e5145 <wasm[0]::function[1015]::helper::object_read+0x41c5>
 29e4e9c:	xor    %r11d,%r11d
 29e4e9f:	test   %eax,%eax
 29e4ea1:	je     29e5138 <wasm[0]::function[1015]::helper::object_read+0x41b8>
 29e4ea7:	mov    0x2e0(%rsp),%r12
 29e4eaf:	mov    0x28(%r12),%r11
 29e4eb4:	mov    0x20(%r12),%r14
 29e4eb9:	lea    0x10(%r14,%rcx,1),%r13
 29e4ebe:	xor    %r12,%r12
 29e4ec1:	cmp    %r11,%rcx
 29e4ec4:	cmova  %r12,%r13
 29e4ec8:	mov    0x0(%r13),%r13d
 29e4ecc:	mov    0x1e0(%rsp),%r15
 29e4ed4:	mov    %r15,%rcx
 29e4ed7:	shr    $0x10,%ecx
 29e4eda:	mov    %r15,%rsi
 29e4edd:	xor    %ecx,%esi
 29e4edf:	imul   $0x7feb352d,%esi,%ecx
 29e4ee5:	mov    %rcx,%rsi
 29e4ee8:	shr    $0xf,%esi
 29e4eeb:	xor    %esi,%ecx
 29e4eed:	imul   $0x846ca68b,%ecx,%ecx
 29e4ef3:	mov    %rcx,%rsi
 29e4ef6:	shr    $0x10,%esi
 29e4ef9:	xor    %esi,%ecx
 29e4efb:	sub    $0x1,%eax
 29e4efe:	and    %eax,%ecx
 29e4f00:	cmp    %r13d,%ecx
 29e4f03:	jae    29fbd97 <wasm[0]::function[1015]::helper::object_read+0x1ae17>
 29e4f09:	mov    %r13d,%eax
 29e4f0c:	shl    $0x2,%rax
 29e4f10:	shr    $0x20,%rax
 29e4f14:	test   %rax,%rax
 29e4f17:	jne    29fbd99 <wasm[0]::function[1015]::helper::object_read+0x1ae19>
 29e4f1d:	shl    $0x2,%r13d
 29e4f21:	add    $0x14,%r13d
 29e4f25:	jb     29fbd9b <wasm[0]::function[1015]::helper::object_read+0x1ae1b>
 29e4f2b:	add    %r13d,%ebx
 29e4f2e:	jb     29fbd9d <wasm[0]::function[1015]::helper::object_read+0x1ae1d>
 29e4f34:	mov    %ebx,%esi
 29e4f36:	lea    (%r14,%rsi,1),%rax
 29e4f3a:	cmp    %r11,%rsi
 29e4f3d:	cmova  %r12,%rax
 29e4f41:	shl    $0x2,%ecx
 29e4f44:	add    $0x14,%ecx
 29e4f4a:	sub    %ecx,%r13d
 29e4f4d:	sub    %r13,%rax
 29e4f50:	mov    (%rax),%eax
 29e4f52:	xor    %ecx,%ecx
 29e4f54:	mov    %r15d,%ebx
 29e4f57:	mov    %eax,0xe8(%rsp)
 29e4f5e:	mov    %ecx,0x98(%rsp)
 29e4f65:	mov    %edx,0x140(%rsp)
 29e4f6c:	mov    0x1e8(%rsp),%rcx
 29e4f74:	mov    %ecx,0xd0(%rsp)
 29e4f7b:	mov    0x1f0(%rsp),%rsi
 29e4f83:	mov    %esi,0x100(%rsp)
 29e4f8a:	mov    0x1f8(%rsp),%rax
 29e4f92:	mov    %eax,0x120(%rsp)
 29e4f99:	mov    %edi,0x110(%rsp)
 29e4fa0:	mov    %r8d,0x78(%rsp)
 29e4fa5:	mov    %r9d,0x88(%rsp)
 29e4fad:	mov    %r10d,0x148(%rsp)
 29e4fb5:	mov    0x2e8(%rsp),%r15
 29e4fbd:	mov    (%r15),%rax
 29e4fc0:	mov    0x228(%rsp),%rcx
 29e4fc8:	cmp    %rcx,%rax
 29e4fcb:	jae    29fa80f <wasm[0]::function[1015]::helper::object_read+0x1988f>
 29e4fd1:	mov    0xe8(%rsp),%eax
 29e4fd8:	mov    0x98(%rsp),%r11d
 29e4fe0:	test   %eax,%eax
 29e4fe2:	je     29e50e8 <wasm[0]::function[1015]::helper::object_read+0x4168>
 29e4fe8:	mov    0xe8(%rsp),%ecx
 29e4fef:	test   %ecx,%ecx
 29e4ff1:	je     29fbd9f <wasm[0]::function[1015]::helper::object_read+0x1ae1f>
 29e4ff7:	mov    0x2e0(%rsp),%r12
 29e4fff:	mov    0x28(%r12),%rax
 29e5004:	mov    %ecx,%edx
 29e5006:	mov    %rdx,%rcx
 29e5009:	add    0x20(%r12),%rcx
 29e500e:	xor    %rsi,%rsi
 29e5011:	cmp    %rax,%rdx
 29e5014:	cmova  %rsi,%rcx
 29e5018:	mov    0x10(%rcx),%rax
 29e501c:	cmp    %rbx,%rax
 29e501f:	je     29e50b4 <wasm[0]::function[1015]::helper::object_read+0x4134>
 29e5025:	mov    0xe8(%rsp),%ecx
 29e502c:	test   %ecx,%ecx
 29e502e:	je     29fbda1 <wasm[0]::function[1015]::helper::object_read+0x1ae21>
 29e5034:	mov    0x2e0(%rsp),%r12
 29e503c:	mov    0x28(%r12),%rax
 29e5041:	mov    %ecx,%edx
 29e5043:	mov    %rdx,%rcx
 29e5046:	add    0x20(%r12),%rcx
 29e504b:	xor    %rsi,%rsi
 29e504e:	cmp    %rax,%rdx
 29e5051:	cmova  %rsi,%rcx
 29e5055:	mov    0x1c(%rcx),%eax
 29e5058:	mov    0x98(%rsp),%ecx
 29e505f:	mov    0x140(%rsp),%edx
 29e5066:	mov    0xd0(%rsp),%esi
 29e506d:	mov    %rsi,0x1e8(%rsp)
 29e5075:	mov    0x100(%rsp),%esi
 29e507c:	mov    %rsi,0x1f0(%rsp)
 29e5084:	mov    0x120(%rsp),%edi
 29e508b:	mov    %rdi,0x1f8(%rsp)
 29e5093:	mov    0x110(%rsp),%edi
 29e509a:	mov    0x78(%rsp),%r8d
 29e509f:	mov    0x88(%rsp),%r9d
 29e50a7:	mov    0x148(%rsp),%r10d
 29e50af:	jmp    29e4f57 <wasm[0]::function[1015]::helper::object_read+0x3fd7>
 29e50b4:	mov    0xe8(%rsp),%ecx
 29e50bb:	test   %ecx,%ecx
 29e50bd:	je     29fbda3 <wasm[0]::function[1015]::helper::object_read+0x1ae23>
 29e50c3:	mov    0x2e0(%rsp),%r12
 29e50cb:	mov    0x28(%r12),%rax
 29e50d0:	mov    %ecx,%edx
 29e50d2:	mov    %rdx,%rcx
 29e50d5:	add    0x20(%r12),%rcx
 29e50da:	xor    %rsi,%rsi
 29e50dd:	cmp    %rax,%rdx
 29e50e0:	cmova  %rsi,%rcx
 29e50e4:	mov    0x18(%rcx),%r11d
 29e50e8:	mov    0x140(%rsp),%edx
 29e50ef:	mov    0xd0(%rsp),%ecx
 29e50f6:	mov    %rcx,0x1e8(%rsp)
 29e50fe:	mov    0x100(%rsp),%esi
 29e5105:	mov    %rsi,0x1f0(%rsp)
 29e510d:	mov    0x120(%rsp),%edi
 29e5114:	mov    %rdi,0x1f8(%rsp)
 29e511c:	mov    0x110(%rsp),%edi
 29e5123:	mov    0x78(%rsp),%r8d
 29e5128:	mov    0x88(%rsp),%r9d
 29e5130:	mov    0x148(%rsp),%r10d
 29e5138:	mov    0x1e8(%rsp),%rcx
 29e5140:	jmp    29e521b <wasm[0]::function[1015]::helper::object_read+0x429b>
 29e5145:	mov    0x2e0(%rsp),%r12
 29e514d:	mov    0x1e0(%rsp),%r15
 29e5155:	mov    0x28(%r12),%rax
 29e515a:	mov    0x20(%r12),%r12
 29e515f:	lea    (%r12,%r11,1),%rbx
 29e5163:	xor    %rcx,%rcx
 29e5166:	cmp    %rax,%r11
 29e5169:	cmova  %rcx,%rbx
 29e516d:	mov    0x20(%rbx),%ebx
 29e5170:	xor    %r11d,%r11d
 29e5173:	test   %ebx,%ebx
 29e5175:	je     29fbda5 <wasm[0]::function[1015]::helper::object_read+0x1ae25>
 29e517b:	test   %ebx,%ebx
 29e517d:	je     29fbda7 <wasm[0]::function[1015]::helper::object_read+0x1ae27>
 29e5183:	mov    %ebx,%r13d
 29e5186:	lea    0x10(%r12,%r13,1),%r12
 29e518b:	cmp    %rax,%r13
 29e518e:	cmova  %rcx,%r12
 29e5192:	mov    %r15d,%esi
 29e5195:	mov    (%r12),%eax
 29e5199:	cmp    %rax,%rsi
 29e519c:	jae    29e5213 <wasm[0]::function[1015]::helper::object_read+0x4293>
 29e51a2:	mov    0x2e0(%rsp),%r12
 29e51aa:	mov    0x28(%r12),%r11
 29e51af:	mov    0x20(%r12),%r12
 29e51b4:	lea    0x10(%r12,%r13,1),%rcx
 29e51b9:	xor    %rax,%rax
 29e51bc:	cmp    %r11,%r13
 29e51bf:	cmova  %rax,%rcx
 29e51c3:	mov    (%rcx),%ecx
 29e51c5:	cmp    %ecx,%r15d
 29e51c8:	jae    29fbda9 <wasm[0]::function[1015]::helper::object_read+0x1ae29>
 29e51ce:	mov    %ecx,%r13d
 29e51d1:	shl    $0x2,%r13
 29e51d5:	shr    $0x20,%r13
 29e51d9:	test   %r13,%r13
 29e51dc:	jne    29fbdab <wasm[0]::function[1015]::helper::object_read+0x1ae2b>
 29e51e2:	shl    $0x2,%ecx
 29e51e5:	add    $0x14,%ecx
 29e51e8:	jb     29fbdad <wasm[0]::function[1015]::helper::object_read+0x1ae2d>
 29e51ee:	add    %ecx,%ebx
 29e51f0:	jb     29fbdaf <wasm[0]::function[1015]::helper::object_read+0x1ae2f>
 29e51f6:	mov    %ebx,%esi
 29e51f8:	add    %rsi,%r12
 29e51fb:	cmp    %r11,%rsi
 29e51fe:	cmova  %rax,%r12
 29e5202:	shl    $0x2,%r15d
 29e5206:	lea    0x14(%r15),%eax
 29e520a:	sub    %eax,%ecx
 29e520c:	sub    %rcx,%r12
 29e520f:	mov    (%r12),%r11d
 29e5213:	mov    0x1e8(%rsp),%rcx
 29e521b:	mov    %ecx,0x88(%rsp)
 29e5222:	mov    0x1f0(%rsp),%rsi
 29e522a:	mov    %esi,0x78(%rsp)
 29e522e:	mov    0x1f8(%rsp),%rax
 29e5236:	mov    %eax,0x110(%rsp)
 29e523d:	mov    %edi,0x120(%rsp)
 29e5244:	mov    %r8d,0x100(%rsp)
 29e524c:	mov    %r9d,0xd0(%rsp)
 29e5254:	mov    %r10d,0x140(%rsp)
 29e525c:	xor    %r10d,%r10d
 29e525f:	xor    %r9,%r9
 29e5262:	test   %r11d,%r11d
 29e5265:	jne    29e5273 <wasm[0]::function[1015]::helper::object_read+0x42f3>
 29e526b:	mov    %r10,%rcx
 29e526e:	jmp    29e5426 <wasm[0]::function[1015]::helper::object_read+0x44a6>
 29e5273:	xor    %r10d,%r10d
 29e5276:	test   %r11d,%r11d
 29e5279:	je     29fbdb1 <wasm[0]::function[1015]::helper::object_read+0x1ae31>
 29e527f:	test   %r11d,%r11d
 29e5282:	je     29fbdb3 <wasm[0]::function[1015]::helper::object_read+0x1ae33>
 29e5288:	mov    0x2e0(%rsp),%r12
 29e5290:	mov    0x28(%r12),%rcx
 29e5295:	mov    %r11d,%eax
 29e5298:	mov    %rax,%rsi
 29e529b:	add    0x20(%r12),%rsi
 29e52a0:	xor    %r9,%r9
 29e52a3:	cmp    %rcx,%rax
 29e52a6:	cmova  %r9,%rsi
 29e52aa:	mov    0x10(%rsi),%ecx
 29e52ad:	test   $0x1,%ecx
 29e52b3:	je     29e52c1 <wasm[0]::function[1015]::helper::object_read+0x4341>
 29e52b9:	mov    %r10,%rcx
 29e52bc:	jmp    29e5426 <wasm[0]::function[1015]::helper::object_read+0x44a6>
 29e52c1:	mov    0x2e0(%rsp),%r12
 29e52c9:	mov    0x28(%r12),%rcx
 29e52ce:	mov    0x20(%r12),%rdx
 29e52d3:	add    %rax,%rdx
 29e52d6:	xor    %rsi,%rsi
 29e52d9:	cmp    %rcx,%rax
 29e52dc:	cmova  %rsi,%rdx
 29e52e0:	mov    0x14(%rdx),%edx
 29e52e3:	test   %edx,%edx
 29e52e5:	je     29fbdb5 <wasm[0]::function[1015]::helper::object_read+0x1ae35>
 29e52eb:	xor    %eax,%eax
 29e52ed:	test   $0x1,%edx
 29e52f3:	jne    29e5336 <wasm[0]::function[1015]::helper::object_read+0x43b6>
 29e52f9:	mov    0x2e0(%rsp),%r12
 29e5301:	mov    0x28(%r12),%rax
 29e5306:	mov    0x20(%r12),%rcx
 29e530b:	mov    %edx,%esi
 29e530d:	lea    0x4(%rcx,%rsi,1),%rcx
 29e5312:	xor    %rdi,%rdi
 29e5315:	cmp    %rax,%rsi
 29e5318:	cmova  %rdi,%rcx
 29e531c:	mov    (%rcx),%eax
 29e531e:	mov    0x190(%rsp),%rcx
 29e5326:	mov    0x28(%rcx),%rcx
 29e532a:	cmp    0x120(%rcx),%eax
 29e5330:	sete   %al
 29e5333:	movzbl %al,%eax
 29e5336:	test   %eax,%eax
 29e5338:	jne    29e5394 <wasm[0]::function[1015]::helper::object_read+0x4414>
 29e533e:	mov    0x190(%rsp),%rsi
 29e5346:	mov    0x190(%rsp),%rdi
 29e534e:	call   2a01c00 <wasm[0]::function[1024]::helper::property_value_resolve>
 29e5353:	test   %eax,%eax
 29e5355:	je     29fbdb7 <wasm[0]::function[1015]::helper::object_read+0x1ae37>
 29e535b:	test   %eax,%eax
 29e535d:	je     29fbdb9 <wasm[0]::function[1015]::helper::object_read+0x1ae39>
 29e5363:	mov    0x2e0(%rsp),%r12
 29e536b:	mov    0x28(%r12),%rcx
 29e5370:	mov    0x20(%r12),%rsi
 29e5375:	mov    %eax,%edx
 29e5377:	lea    (%rsi,%rdx,1),%rax
 29e537b:	xor    %rsi,%rsi
 29e537e:	cmp    %rcx,%rdx
 29e5381:	cmova  %rsi,%rax
 29e5385:	mov    0x18(%rax),%ecx
 29e5388:	mov    0x10(%rax),%r9
 29e538c:	mov    0x1c(%rax),%edx
 29e538f:	jmp    29e541e <wasm[0]::function[1015]::helper::object_read+0x449e>
 29e5394:	xor    %r9d,%r9d
 29e5397:	test   $0x1,%edx
 29e539d:	jne    29e53e1 <wasm[0]::function[1015]::helper::object_read+0x4461>
 29e53a3:	mov    0x2e0(%rsp),%r12
 29e53ab:	mov    0x28(%r12),%rax
 29e53b0:	mov    0x20(%r12),%rcx
 29e53b5:	mov    %edx,%esi
 29e53b7:	lea    0x4(%rcx,%rsi,1),%rcx
 29e53bc:	xor    %rdi,%rdi
 29e53bf:	cmp    %rax,%rsi
 29e53c2:	cmova  %rdi,%rcx
 29e53c6:	mov    (%rcx),%eax
 29e53c8:	mov    0x190(%rsp),%rcx
 29e53d0:	mov    0x28(%rcx),%rcx
 29e53d4:	cmp    0x120(%rcx),%eax
 29e53da:	sete   %al
 29e53dd:	movzbl %al,%r9d
 29e53e1:	test   %r9d,%r9d
 29e53e4:	je     29fbdbb <wasm[0]::function[1015]::helper::object_read+0x1ae3b>
 29e53ea:	test   %edx,%edx
 29e53ec:	je     29fbdbd <wasm[0]::function[1015]::helper::object_read+0x1ae3d>
 29e53f2:	mov    0x2e0(%rsp),%r12
 29e53fa:	mov    0x28(%r12),%rsi
 29e53ff:	mov    0x20(%r12),%r8
 29e5404:	mov    %edx,%edi
 29e5406:	lea    (%r8,%rdi,1),%rax
 29e540a:	xor    %r8,%r8
 29e540d:	cmp    %rsi,%rdi
 29e5410:	cmova  %r8,%rax
 29e5414:	mov    0x18(%rax),%ecx
 29e5417:	mov    0x10(%rax),%r9
 29e541b:	mov    0x1c(%rax),%edx
 29e541e:	mov    0x278(%rsp),%r10
 29e5426:	mov    0x88(%rsp),%eax
 29e542d:	mov    0x78(%rsp),%edi
 29e5431:	mov    0x110(%rsp),%r8d
 29e5439:	mov    0x120(%rsp),%r11d
 29e5441:	mov    0x100(%rsp),%r12d
 29e5449:	mov    0xd0(%rsp),%r13d
 29e5451:	mov    0x140(%rsp),%esi
 29e5458:	jmp    29e5787 <wasm[0]::function[1015]::helper::object_read+0x4807>
 29e545d:	mov    0x2e0(%rsp),%r12
 29e5465:	mov    0x1e0(%rsp),%r15
 29e546d:	mov    0x28(%r12),%r8
 29e5472:	mov    %rax,%rsi
 29e5475:	add    0x20(%r12),%rsi
 29e547a:	xor    %r9,%r9
 29e547d:	cmp    %r8,%rax
 29e5480:	cmova  %r9,%rsi
 29e5484:	mov    0x24(%rsi),%r9d
 29e5488:	cmp    $0x3,%r9d
 29e548c:	je     29e5627 <wasm[0]::function[1015]::helper::object_read+0x46a7>
 29e5492:	mov    0x2e0(%rsp),%r12
 29e549a:	mov    0x28(%r12),%r11
 29e549f:	mov    0x20(%r12),%rdx
 29e54a4:	lea    (%rdx,%rax,1),%r8
 29e54a8:	xor    %r9,%r9
 29e54ab:	cmp    %r11,%rax
 29e54ae:	cmova  %r9,%r8
 29e54b2:	mov    0x28(%r8),%esi
 29e54b6:	mov    0x2c(%r8),%r8d
 29e54ba:	xor    %r10d,%r10d
 29e54bd:	test   %esi,%esi
 29e54bf:	je     29fbdbf <wasm[0]::function[1015]::helper::object_read+0x1ae3f>
 29e54c5:	test   %esi,%esi
 29e54c7:	je     29fbdc1 <wasm[0]::function[1015]::helper::object_read+0x1ae41>
 29e54cd:	mov    %esi,%edi
 29e54cf:	lea    0x10(%rdx,%rdi,1),%rax
 29e54d4:	cmp    %r11,%rdi
 29e54d7:	cmova  %r9,%rax
 29e54db:	mov    (%rax),%eax
 29e54dd:	mov    0xa0(%rsp),%edx
 29e54e4:	mov    %r15d,%r11d
 29e54e7:	mov    %eax,%eax
 29e54e9:	cmp    %rax,%r11
 29e54ec:	jb     29e54fa <wasm[0]::function[1015]::helper::object_read+0x457a>
 29e54f2:	mov    %r10,%rcx
 29e54f5:	jmp    29e5758 <wasm[0]::function[1015]::helper::object_read+0x47d8>
 29e54fa:	xor    %r10d,%r10d
 29e54fd:	test   %r8d,%r8d
 29e5500:	je     29fbdc3 <wasm[0]::function[1015]::helper::object_read+0x1ae43>
 29e5506:	test   %r8d,%r8d
 29e5509:	je     29fbdc5 <wasm[0]::function[1015]::helper::object_read+0x1ae45>
 29e550f:	mov    0x2e0(%rsp),%r12
 29e5517:	mov    0x28(%r12),%rax
 29e551c:	mov    0x20(%r12),%rdx
 29e5521:	mov    %r8d,%ebx
 29e5524:	lea    0x10(%rdx,%rbx,1),%r11
 29e5529:	xor    %r9,%r9
 29e552c:	cmp    %rax,%rbx
 29e552f:	cmova  %r9,%r11
 29e5533:	mov    (%r11),%r11d
 29e5536:	mov    %r15,%rbx
 29e5539:	shr    $0x6,%ebx
 29e553c:	cmp    %r11d,%ebx
 29e553f:	jae    29fbdc7 <wasm[0]::function[1015]::helper::object_read+0x1ae47>
 29e5545:	mov    %r11d,%r12d
 29e5548:	shl    $0x3,%r12
 29e554c:	shr    $0x20,%r12
 29e5550:	test   %r12,%r12
 29e5553:	jne    29fbdc9 <wasm[0]::function[1015]::helper::object_read+0x1ae49>
 29e5559:	shl    $0x3,%r11d
 29e555d:	add    $0x18,%r11d
 29e5561:	jb     29fbdcb <wasm[0]::function[1015]::helper::object_read+0x1ae4b>
 29e5567:	add    %r11d,%r8d
 29e556a:	jb     29fbdcd <wasm[0]::function[1015]::helper::object_read+0x1ae4d>
 29e5570:	mov    %r8d,%r8d
 29e5573:	add    %r8,%rdx
 29e5576:	cmp    %rax,%r8
 29e5579:	cmova  %r9,%rdx
 29e557d:	shl    $0x3,%ebx
 29e5580:	lea    0x18(%rbx),%eax
 29e5583:	sub    %eax,%r11d
 29e5586:	sub    %r11,%rdx
 29e5589:	mov    (%rdx),%rax
 29e558c:	mov    0xa0(%rsp),%edx
 29e5593:	bt     %r15,%rax
 29e5597:	jb     29e55a5 <wasm[0]::function[1015]::helper::object_read+0x4625>
 29e559d:	mov    %r10,%rcx
 29e55a0:	jmp    29e5758 <wasm[0]::function[1015]::helper::object_read+0x47d8>
 29e55a5:	mov    0x2e0(%rsp),%r12
 29e55ad:	mov    0x28(%r12),%rax
 29e55b2:	mov    0x20(%r12),%r8
 29e55b7:	lea    0x10(%r8,%rdi,1),%r9
 29e55bc:	xor    %rdx,%rdx
 29e55bf:	cmp    %rax,%rdi
 29e55c2:	cmova  %rdx,%r9
 29e55c6:	mov    (%r9),%edi
 29e55c9:	cmp    %edi,%r15d
 29e55cc:	jae    29fbdcf <wasm[0]::function[1015]::helper::object_read+0x1ae4f>
 29e55d2:	mov    %edi,%r9d
 29e55d5:	shl    $0x3,%r9
 29e55d9:	shr    $0x20,%r9
 29e55dd:	test   %r9,%r9
 29e55e0:	jne    29fbdd1 <wasm[0]::function[1015]::helper::object_read+0x1ae51>
 29e55e6:	shl    $0x3,%edi
 29e55e9:	add    $0x18,%edi
 29e55ec:	jb     29fbdd3 <wasm[0]::function[1015]::helper::object_read+0x1ae53>
 29e55f2:	add    %edi,%esi
 29e55f4:	jb     29fbdd5 <wasm[0]::function[1015]::helper::object_read+0x1ae55>
 29e55fa:	mov    %esi,%r9d
 29e55fd:	lea    (%r8,%r9,1),%rsi
 29e5601:	cmp    %rax,%r9
 29e5604:	cmova  %rdx,%rsi
 29e5608:	shl    $0x3,%r15d
 29e560c:	lea    0x18(%r15),%eax
 29e5610:	sub    %eax,%edi
 29e5612:	sub    %rdi,%rsi
 29e5615:	mov    (%rsi),%r9
 29e5618:	xor    %edx,%edx
 29e561a:	mov    0x278(%rsp),%r10
 29e5622:	jmp    29e5758 <wasm[0]::function[1015]::helper::object_read+0x47d8>
 29e5627:	mov    0x2e0(%rsp),%r12
 29e562f:	mov    0x28(%r12),%rcx
 29e5634:	mov    0x20(%r12),%rdx
 29e5639:	lea    (%rdx,%rax,1),%rsi
 29e563d:	xor    %r9,%r9
 29e5640:	cmp    %rcx,%rax
 29e5643:	cmova  %r9,%rsi
 29e5647:	mov    0x30(%rsi),%eax
 29e564a:	xor    %r10d,%r10d
 29e564d:	test   %eax,%eax
 29e564f:	je     29fbdd7 <wasm[0]::function[1015]::helper::object_read+0x1ae57>
 29e5655:	test   %eax,%eax
 29e5657:	je     29fbdd9 <wasm[0]::function[1015]::helper::object_read+0x1ae59>
 29e565d:	mov    %eax,%edi
 29e565f:	lea    0x10(%rdx,%rdi,1),%rdx
 29e5664:	cmp    %rcx,%rdi
 29e5667:	cmova  %r9,%rdx
 29e566b:	mov    (%rdx),%ecx
 29e566d:	mov    0xa0(%rsp),%edx
 29e5674:	mov    %r15d,%esi
 29e5677:	mov    %ecx,%ecx
 29e5679:	cmp    %rcx,%rsi
 29e567c:	jb     29e568a <wasm[0]::function[1015]::helper::object_read+0x470a>
 29e5682:	mov    %r10,%rcx
 29e5685:	jmp    29e5758 <wasm[0]::function[1015]::helper::object_read+0x47d8>
 29e568a:	mov    0x2e0(%rsp),%r12
 29e5692:	mov    0x28(%r12),%rcx
 29e5697:	mov    0x20(%r12),%rsi
 29e569c:	lea    0x10(%rsi,%rdi,1),%rdx
 29e56a1:	xor    %r9,%r9
 29e56a4:	cmp    %rcx,%rdi
 29e56a7:	cmova  %r9,%rdx
 29e56ab:	mov    (%rdx),%edx
 29e56ad:	cmp    %edx,%r15d
 29e56b0:	jae    29fbddb <wasm[0]::function[1015]::helper::object_read+0x1ae5b>
 29e56b6:	mov    %edx,%edi
 29e56b8:	shl    $0x2,%rdi
 29e56bc:	shr    $0x20,%rdi
 29e56c0:	test   %rdi,%rdi
 29e56c3:	jne    29fbddd <wasm[0]::function[1015]::helper::object_read+0x1ae5d>
 29e56c9:	shl    $0x2,%edx
 29e56cc:	add    $0x14,%edx
 29e56cf:	jb     29fbddf <wasm[0]::function[1015]::helper::object_read+0x1ae5f>
 29e56d5:	add    %edx,%eax
 29e56d7:	jb     29fbde1 <wasm[0]::function[1015]::helper::object_read+0x1ae61>
 29e56dd:	mov    %eax,%edi
 29e56df:	lea    (%rsi,%rdi,1),%rax
 29e56e3:	cmp    %rcx,%rdi
 29e56e6:	cmova  %r9,%rax
 29e56ea:	shl    $0x2,%r15d
 29e56ee:	lea    0x14(%r15),%ecx
 29e56f2:	sub    %ecx,%edx
 29e56f4:	sub    %rdx,%rax
 29e56f7:	mov    (%rax),%eax
 29e56f9:	mov    0xa0(%rsp),%edx
 29e5700:	xor    %r10d,%r10d
 29e5703:	test   %eax,%eax
 29e5705:	jne    29e5713 <wasm[0]::function[1015]::helper::object_read+0x4793>
 29e570b:	mov    %r10,%rcx
 29e570e:	jmp    29e5758 <wasm[0]::function[1015]::helper::object_read+0x47d8>
 29e5713:	test   %eax,%eax
 29e5715:	je     29fbde3 <wasm[0]::function[1015]::helper::object_read+0x1ae63>
 29e571b:	test   %eax,%eax
 29e571d:	je     29fbde5 <wasm[0]::function[1015]::helper::object_read+0x1ae65>
 29e5723:	mov    0x2e0(%rsp),%r12
 29e572b:	mov    0x28(%r12),%rdi
 29e5730:	mov    0x20(%r12),%r9
 29e5735:	mov    %eax,%r8d
 29e5738:	lea    (%r9,%r8,1),%rsi
 29e573c:	xor    %r9,%r9
 29e573f:	cmp    %rdi,%r8
 29e5742:	cmova  %r9,%rsi
 29e5746:	mov    0x18(%rsi),%ecx
 29e5749:	mov    0x10(%rsi),%r9
 29e574d:	mov    0x1c(%rsi),%edx
 29e5750:	mov    0x278(%rsp),%r10
 29e5758:	mov    0x48(%rsp),%eax
 29e575c:	mov    0x80(%rsp),%edi
 29e5763:	mov    0xa8(%rsp),%r8d
 29e576b:	mov    0xb8(%rsp),%r11d
 29e5773:	mov    0x58(%rsp),%r12d
 29e5778:	mov    0xc0(%rsp),%r13d
 29e5780:	mov    0xe0(%rsp),%esi
 29e5787:	xor    %ebx,%ebx
 29e5789:	test   %r10d,%r10d
 29e578c:	jne    29e57b2 <wasm[0]::function[1015]::helper::object_read+0x4832>
 29e5792:	mov    0x288(%rsp),%r9
 29e579a:	mov    %rsi,%rdx
 29e579d:	mov    0x290(%rsp),%rsi
 29e57a5:	mov    0x280(%rsp),%rcx
 29e57ad:	jmp    29e57c4 <wasm[0]::function[1015]::helper::object_read+0x4844>
 29e57b2:	xor    %esi,%esi
 29e57b4:	mov    0x278(%rsp),%rbx
 29e57bc:	mov    %rsi,0x298(%rsp)
 29e57c4:	mov    %rcx,0x280(%rsp)
 29e57cc:	mov    %r9,0x288(%rsp)
 29e57d4:	mov    %edi,0x58(%rsp)
 29e57d8:	mov    %r8d,0xb8(%rsp)
 29e57e0:	mov    %r11d,0xa8(%rsp)
 29e57e8:	mov    %r12d,0x80(%rsp)
 29e57f0:	mov    %r13d,0x48(%rsp)
 29e57f5:	test   %eax,%eax
 29e57f7:	jne    29e580a <wasm[0]::function[1015]::helper::object_read+0x488a>
 29e57fd:	mov    0x288(%rsp),%rax
 29e5805:	jmp    29e59d2 <wasm[0]::function[1015]::helper::object_read+0x4a52>
 29e580a:	test   %eax,%eax
 29e580c:	je     29fbde7 <wasm[0]::function[1015]::helper::object_read+0x1ae67>
 29e5812:	test   %eax,%eax
 29e5814:	je     29fbde9 <wasm[0]::function[1015]::helper::object_read+0x1ae69>
 29e581a:	mov    0x2e0(%rsp),%r12
 29e5822:	mov    0x28(%r12),%rcx
 29e5827:	mov    %eax,%eax
 29e5829:	mov    %rax,%rdi
 29e582c:	add    0x20(%r12),%rdi
 29e5831:	xor    %r8,%r8
 29e5834:	cmp    %rcx,%rax
 29e5837:	cmova  %r8,%rdi
 29e583b:	mov    0x10(%rdi),%ecx
 29e583e:	test   $0x1,%ecx
 29e5844:	je     29e5857 <wasm[0]::function[1015]::helper::object_read+0x48d7>
 29e584a:	mov    0x288(%rsp),%rax
 29e5852:	jmp    29e59d2 <wasm[0]::function[1015]::helper::object_read+0x4a52>
 29e5857:	mov    0x2e0(%rsp),%r12
 29e585f:	mov    0x28(%r12),%rcx
 29e5864:	mov    0x20(%r12),%rdx
 29e5869:	add    %rax,%rdx
 29e586c:	xor    %rsi,%rsi
 29e586f:	cmp    %rcx,%rax
 29e5872:	cmova  %rsi,%rdx
 29e5876:	mov    0x14(%rdx),%edx
 29e5879:	test   %edx,%edx
 29e587b:	je     29fbdeb <wasm[0]::function[1015]::helper::object_read+0x1ae6b>
 29e5881:	xor    %eax,%eax
 29e5883:	test   $0x1,%edx
 29e5889:	jne    29e58cc <wasm[0]::function[1015]::helper::object_read+0x494c>
 29e588f:	mov    0x2e0(%rsp),%r12
 29e5897:	mov    0x28(%r12),%rax
 29e589c:	mov    0x20(%r12),%rcx
 29e58a1:	mov    %edx,%esi
 29e58a3:	lea    0x4(%rcx,%rsi,1),%rcx
 29e58a8:	xor    %rdi,%rdi
 29e58ab:	cmp    %rax,%rsi
 29e58ae:	cmova  %rdi,%rcx
 29e58b2:	mov    (%rcx),%eax
 29e58b4:	mov    0x190(%rsp),%rcx
 29e58bc:	mov    0x28(%rcx),%rcx
 29e58c0:	cmp    0x120(%rcx),%eax
 29e58c6:	sete   %al
 29e58c9:	movzbl %al,%eax
 29e58cc:	test   %eax,%eax
 29e58ce:	jne    29e5931 <wasm[0]::function[1015]::helper::object_read+0x49b1>
 29e58d4:	mov    0x190(%rsp),%rsi
 29e58dc:	mov    0x190(%rsp),%rdi
 29e58e4:	call   2a01c00 <wasm[0]::function[1024]::helper::property_value_resolve>
 29e58e9:	test   %eax,%eax
 29e58eb:	je     29fbded <wasm[0]::function[1015]::helper::object_read+0x1ae6d>
 29e58f1:	test   %eax,%eax
 29e58f3:	je     29fbdef <wasm[0]::function[1015]::helper::object_read+0x1ae6f>
 29e58f9:	mov    0x2e0(%rsp),%r12
 29e5901:	mov    0x28(%r12),%rdx
 29e5906:	mov    0x20(%r12),%rcx
 29e590b:	mov    %eax,%eax
 29e590d:	add    %rax,%rcx
 29e5910:	xor    %rsi,%rsi
 29e5913:	cmp    %rdx,%rax
 29e5916:	cmova  %rsi,%rcx
 29e591a:	mov    0x18(%rcx),%eax
 29e591d:	mov    %rax,0x280(%rsp)
 29e5925:	mov    0x10(%rcx),%rax
 29e5929:	mov    0x1c(%rcx),%edx
 29e592c:	jmp    29e59c0 <wasm[0]::function[1015]::helper::object_read+0x4a40>
 29e5931:	xor    %esi,%esi
 29e5933:	test   $0x1,%edx
 29e5939:	jne    29e597d <wasm[0]::function[1015]::helper::object_read+0x49fd>
 29e593f:	mov    0x2e0(%rsp),%r12
 29e5947:	mov    0x28(%r12),%rax
 29e594c:	mov    0x20(%r12),%rcx
 29e5951:	mov    %edx,%esi
 29e5953:	lea    0x4(%rcx,%rsi,1),%rcx
 29e5958:	xor    %rdi,%rdi
 29e595b:	cmp    %rax,%rsi
 29e595e:	cmova  %rdi,%rcx
 29e5962:	mov    (%rcx),%eax
 29e5964:	mov    0x190(%rsp),%rcx
 29e596c:	mov    0x28(%rcx),%rcx
 29e5970:	cmp    0x120(%rcx),%eax
 29e5976:	sete   %al
 29e5979:	rex movzbl %al,%esi
 29e597d:	test   %esi,%esi
 29e597f:	je     29fbdf1 <wasm[0]::function[1015]::helper::object_read+0x1ae71>
 29e5985:	test   %edx,%edx
 29e5987:	je     29fbdf3 <wasm[0]::function[1015]::helper::object_read+0x1ae73>
 29e598d:	mov    0x2e0(%rsp),%r12
 29e5995:	mov    0x28(%r12),%rax
 29e599a:	mov    0x20(%r12),%rcx
 29e599f:	mov    %edx,%edx
 29e59a1:	add    %rdx,%rcx
 29e59a4:	xor    %rsi,%rsi
 29e59a7:	cmp    %rax,%rdx
 29e59aa:	cmova  %rsi,%rcx
 29e59ae:	mov    0x18(%rcx),%eax
 29e59b1:	mov    %rax,0x280(%rsp)
 29e59b9:	mov    0x10(%rcx),%rax
 29e59bd:	mov    0x1c(%rcx),%edx
 29e59c0:	xor    %esi,%esi
 29e59c2:	mov    0x278(%rsp),%rbx
 29e59ca:	mov    %rsi,0x298(%rsp)
 29e59d2:	mov    0x58(%rsp),%r10d
 29e59d7:	mov    0xb8(%rsp),%r9d
 29e59df:	mov    0xa8(%rsp),%r14d
 29e59e7:	mov    %r14,0x208(%rsp)
 29e59ef:	mov    0x80(%rsp),%r14d
 29e59f7:	mov    0x48(%rsp),%edi
 29e59fb:	mov    %rax,0x288(%rsp)
 29e5a03:	jmp    29e5ab3 <wasm[0]::function[1015]::helper::object_read+0x4b33>
 29e5a08:	xor    %edx,%edx
 29e5a0a:	mov    0x210(%rsp),%rax
 29e5a12:	mov    0x210(%rsp),%rcx
 29e5a1a:	test   %ecx,%eax
 29e5a1c:	je     29fbdf5 <wasm[0]::function[1015]::helper::object_read+0x1ae75>
 29e5a22:	test   %ecx,%eax
 29e5a24:	je     29fbdf7 <wasm[0]::function[1015]::helper::object_read+0x1ae77>
 29e5a2a:	mov    0x2e0(%rsp),%r12
 29e5a32:	mov    0x28(%r12),%r8
 29e5a37:	mov    0x210(%rsp),%rsi
 29e5a3f:	mov    %esi,%r11d
 29e5a42:	mov    %r11,%rsi
 29e5a45:	add    0x20(%r12),%rsi
 29e5a4a:	xor    %rax,%rax
 29e5a4d:	cmp    %r8,%r11
 29e5a50:	cmova  %rax,%rsi
 29e5a54:	mov    0x18(%rsi),%r11
 29e5a58:	mov    $0x3,%eax
 29e5a5d:	mov    %rax,0x280(%rsp)
 29e5a65:	cmp    $0x0,%r11
 29e5a69:	jl     29e5a79 <wasm[0]::function[1015]::helper::object_read+0x4af9>
 29e5a6f:	cvtsi2sd %r11,%xmm7
 29e5a74:	jmp    29e5a93 <wasm[0]::function[1015]::helper::object_read+0x4b13>
 29e5a79:	mov    %r11,%r8
 29e5a7c:	shr    $0x1,%r8
 29e5a80:	mov    %r11,%rax
 29e5a83:	and    $0x1,%rax
 29e5a87:	or     %r8,%rax
 29e5a8a:	cvtsi2sd %rax,%xmm7
 29e5a8f:	addsd  %xmm7,%xmm7
 29e5a93:	movq   %xmm7,%rax
 29e5a98:	mov    %rax,0x288(%rsp)
 29e5aa0:	mov    0x278(%rsp),%rbx
 29e5aa8:	mov    %rdx,%rsi
 29e5aab:	mov    %rdx,0x298(%rsp)
 29e5ab3:	mov    %r10,%rax
 29e5ab6:	mov    %r10,0x210(%rsp)
 29e5abe:	mov    %eax,0x48(%rsp)
 29e5ac2:	mov    %r9d,0x80(%rsp)
 29e5aca:	mov    0x208(%rsp),%rax
 29e5ad2:	mov    %eax,0xa8(%rsp)
 29e5ad9:	mov    %r14d,0xb8(%rsp)
 29e5ae1:	mov    %edi,0x58(%rsp)
 29e5ae5:	test   %ebx,%ebx
 29e5ae7:	je     29e5afa <wasm[0]::function[1015]::helper::object_read+0x4b7a>
 29e5aed:	mov    0x298(%rsp),%rdi
 29e5af5:	jmp    29efc02 <wasm[0]::function[1015]::helper::object_read+0xec82>
 29e5afa:	xor    %eax,%eax
 29e5afc:	movl   $0x0,0xc0(%rsp)
 29e5b07:	mov    0x210(%rsp),%rcx
 29e5b0f:	mov    0x210(%rsp),%rdx
 29e5b17:	test   %ecx,%edx
 29e5b19:	je     29e5b7a <wasm[0]::function[1015]::helper::object_read+0x4bfa>
 29e5b1f:	xor    %eax,%eax
 29e5b21:	mov    0x210(%rsp),%rdx
 29e5b29:	test   $0x1,%edx
 29e5b2f:	jne    29e5b7a <wasm[0]::function[1015]::helper::object_read+0x4bfa>
 29e5b35:	mov    0x2e0(%rsp),%r12
 29e5b3d:	mov    0x28(%r12),%rax
 29e5b42:	mov    0x20(%r12),%rdx
 29e5b47:	mov    0x210(%rsp),%rcx
 29e5b4f:	mov    %ecx,%esi
 29e5b51:	lea    0x4(%rdx,%rsi,1),%rdx
 29e5b56:	xor    %r8,%r8
 29e5b59:	cmp    %rax,%rsi
 29e5b5c:	cmova  %r8,%rdx
 29e5b60:	mov    (%rdx),%eax
 29e5b62:	mov    0x190(%rsp),%rcx
 29e5b6a:	mov    0x28(%rcx),%rcx
 29e5b6e:	cmp    0x138(%rcx),%eax
 29e5b74:	sete   %al
 29e5b77:	movzbl %al,%eax
 29e5b7a:	test   %eax,%eax
 29e5b7c:	jne    29eeee3 <wasm[0]::function[1015]::helper::object_read+0xdf63>
 29e5b82:	xor    %eax,%eax
 29e5b84:	mov    0x210(%rsp),%rcx
 29e5b8c:	mov    0x210(%rsp),%rdx
 29e5b94:	test   %ecx,%edx
 29e5b96:	je     29e5bf8 <wasm[0]::function[1015]::helper::object_read+0x4c78>
 29e5b9c:	xor    %eax,%eax
 29e5b9e:	mov    0x210(%rsp),%rdx
 29e5ba6:	test   $0x1,%edx
 29e5bac:	jne    29e5bf8 <wasm[0]::function[1015]::helper::object_read+0x4c78>
 29e5bb2:	mov    0x2e0(%rsp),%r12
 29e5bba:	mov    0x28(%r12),%rax
 29e5bbf:	mov    0x20(%r12),%rdx
 29e5bc4:	mov    0x210(%rsp),%r8
 29e5bcc:	mov    %r8d,%esi
 29e5bcf:	lea    0x4(%rdx,%rsi,1),%rdx
 29e5bd4:	xor    %r8,%r8
 29e5bd7:	cmp    %rax,%rsi
 29e5bda:	cmova  %r8,%rdx
 29e5bde:	mov    (%rdx),%eax
 29e5be0:	mov    0x190(%rsp),%rcx
 29e5be8:	mov    0x28(%rcx),%rcx
 29e5bec:	cmp    0x254(%rcx),%eax
 29e5bf2:	sete   %al
 29e5bf5:	movzbl %al,%eax
 29e5bf8:	test   %eax,%eax
 29e5bfa:	jne    29ec834 <wasm[0]::function[1015]::helper::object_read+0xb8b4>
 29e5c00:	xor    %eax,%eax
 29e5c02:	mov    0x208(%rsp),%rcx
 29e5c0a:	mov    %rax,%rdx
 29e5c0d:	mov    0x208(%rsp),%rsi
 29e5c15:	mov    %rax,%r8
 29e5c18:	mov    %ecx,0x140(%rsp)
 29e5c1f:	mov    %eax,0xd0(%rsp)
 29e5c26:	mov    %r8d,0x100(%rsp)
 29e5c2e:	mov    0x210(%rsp),%rax
 29e5c36:	mov    %eax,0x120(%rsp)
 29e5c3d:	mov    %r9d,0x110(%rsp)
 29e5c45:	mov    %esi,0x78(%rsp)
 29e5c49:	mov    %r14d,0x88(%rsp)
 29e5c51:	mov    %edx,0xa0(%rsp)
 29e5c58:	mov    %edi,0xe0(%rsp)
 29e5c5f:	mov    0x2e8(%rsp),%r15
 29e5c67:	mov    (%r15),%rax
 29e5c6a:	mov    0x228(%rsp),%rcx
 29e5c72:	cmp    %rcx,%rax
 29e5c75:	jae    29fa847 <wasm[0]::function[1015]::helper::object_read+0x198c7>
 29e5c7b:	mov    0x140(%rsp),%ecx
 29e5c82:	mov    0xd0(%rsp),%eax
 29e5c89:	test   %ecx,%ecx
 29e5c8b:	je     29e5d4f <wasm[0]::function[1015]::helper::object_read+0x4dcf>
 29e5c91:	mov    0x140(%rsp),%ecx
 29e5c98:	test   %ecx,%ecx
 29e5c9a:	je     29fbdf9 <wasm[0]::function[1015]::helper::object_read+0x1ae79>
 29e5ca0:	mov    0x2e0(%rsp),%r12
 29e5ca8:	mov    0x28(%r12),%rax
 29e5cad:	mov    0x20(%r12),%rsi
 29e5cb2:	mov    %ecx,%edx
 29e5cb4:	lea    (%rsi,%rdx,1),%rcx
 29e5cb8:	xor    %rsi,%rsi
 29e5cbb:	cmp    %rax,%rdx
 29e5cbe:	cmova  %rsi,%rcx
 29e5cc2:	mov    0x10(%rcx),%eax
 29e5cc5:	test   %eax,%eax
 29e5cc7:	jne    29e5d4f <wasm[0]::function[1015]::helper::object_read+0x4dcf>
 29e5ccd:	mov    0x140(%rsp),%edi
 29e5cd4:	test   %edi,%edi
 29e5cd6:	je     29fbdfb <wasm[0]::function[1015]::helper::object_read+0x1ae7b>
 29e5cdc:	mov    0x2e0(%rsp),%r12
 29e5ce4:	mov    0x28(%r12),%rsi
 29e5ce9:	mov    %edi,%edi
 29e5ceb:	mov    %rdi,%rdx
 29e5cee:	add    0x20(%r12),%rdx
 29e5cf3:	xor    %r8,%r8
 29e5cf6:	cmp    %rsi,%rdi
 29e5cf9:	cmova  %r8,%rdx
 29e5cfd:	mov    0x1c(%rdx),%r14d
 29e5d01:	mov    %r14,0x208(%rsp)
 29e5d09:	mov    0x100(%rsp),%r8d
 29e5d11:	mov    0x120(%rsp),%edx
 29e5d18:	mov    %rdx,0x210(%rsp)
 29e5d20:	mov    0x110(%rsp),%r9d
 29e5d28:	mov    0x78(%rsp),%esi
 29e5d2c:	mov    0x88(%rsp),%r14d
 29e5d34:	mov    0xa0(%rsp),%edx
 29e5d3b:	mov    0xe0(%rsp),%edi
 29e5d42:	mov    0x208(%rsp),%rcx
 29e5d4a:	jmp    29e5c18 <wasm[0]::function[1015]::helper::object_read+0x4c98>
 29e5d4f:	test   %eax,%eax
 29e5d51:	jne    29e5d6d <wasm[0]::function[1015]::helper::object_read+0x4ded>
 29e5d57:	mov    0x190(%rsp),%rcx
 29e5d5f:	mov    0x8c0(%rcx),%eax
 29e5d65:	test   %eax,%eax
 29e5d67:	je     29fbdfd <wasm[0]::function[1015]::helper::object_read+0x1ae7d>
 29e5d6d:	mov    %eax,0x140(%rsp)
 29e5d74:	test   %eax,%eax
 29e5d76:	je     29fbdff <wasm[0]::function[1015]::helper::object_read+0x1ae7f>
 29e5d7c:	test   %eax,%eax
 29e5d7e:	je     29fbe01 <wasm[0]::function[1015]::helper::object_read+0x1ae81>
 29e5d84:	mov    0x2e0(%rsp),%r12
 29e5d8c:	mov    0x28(%r12),%rcx
 29e5d91:	mov    0x20(%r12),%rdx
 29e5d96:	mov    %eax,%edi
 29e5d98:	lea    (%rdx,%rdi,1),%rsi
 29e5d9c:	xor    %rax,%rax
 29e5d9f:	cmp    %rcx,%rdi
 29e5da2:	cmova  %rax,%rsi
 29e5da6:	mov    0x2c(%rsi),%r8d
 29e5daa:	test   %r8d,%r8d
 29e5dad:	je     29fbe03 <wasm[0]::function[1015]::helper::object_read+0x1ae83>
 29e5db3:	test   %r8d,%r8d
 29e5db6:	je     29fbe05 <wasm[0]::function[1015]::helper::object_read+0x1ae85>
 29e5dbc:	mov    %r8d,%edi
 29e5dbf:	lea    0x10(%rdx,%rdi,1),%rsi
 29e5dc4:	cmp    %rcx,%rdi
 29e5dc7:	cmova  %rax,%rsi
 29e5dcb:	mov    (%rsi),%esi
 29e5dcd:	cmp    $0xd,%esi
 29e5dd0:	jbe    29fbe07 <wasm[0]::function[1015]::helper::object_read+0x1ae87>
 29e5dd6:	mov    %esi,%edi
 29e5dd8:	shl    $0x2,%rdi
 29e5ddc:	mov    $0x20,%r9d
 29e5de2:	mov    %r9,0x2c8(%rsp)
 29e5dea:	shr    $0x20,%rdi
 29e5dee:	test   %rdi,%rdi
 29e5df1:	jne    29fbe09 <wasm[0]::function[1015]::helper::object_read+0x1ae89>
 29e5df7:	shl    $0x2,%esi
 29e5dfa:	add    $0x14,%esi
 29e5dfd:	jb     29fbe0b <wasm[0]::function[1015]::helper::object_read+0x1ae8b>
 29e5e03:	add    %esi,%r8d
 29e5e06:	jb     29fbe0d <wasm[0]::function[1015]::helper::object_read+0x1ae8d>
 29e5e0c:	mov    %r8d,%r8d
 29e5e0f:	lea    (%rdx,%r8,1),%rdi
 29e5e13:	cmp    %rcx,%r8
 29e5e16:	cmova  %rax,%rdi
 29e5e1a:	sub    $0x48,%esi
 29e5e1d:	sub    %rsi,%rdi
 29e5e20:	mov    (%rdi),%esi
 29e5e22:	test   %esi,%esi
 29e5e24:	je     29fbe0f <wasm[0]::function[1015]::helper::object_read+0x1ae8f>
 29e5e2a:	test   %esi,%esi
 29e5e2c:	je     29fbe11 <wasm[0]::function[1015]::helper::object_read+0x1ae91>
 29e5e32:	mov    %esi,%esi
 29e5e34:	add    %rsi,%rdx
 29e5e37:	cmp    %rcx,%rsi
 29e5e3a:	cmova  %rax,%rdx
 29e5e3e:	mov    0x18(%rdx),%ecx
 29e5e41:	mov    0x10(%rdx),%rax
 29e5e45:	mov    0x1c(%rdx),%eax
 29e5e48:	mov    %eax,0xd0(%rsp)
 29e5e4f:	cmp    $0x6,%ecx
 29e5e52:	sete   %dl
 29e5e55:	cmp    $0x7,%ecx
 29e5e58:	sete   %sil
 29e5e5c:	or     %esi,%edx
 29e5e5e:	cmp    $0x8,%ecx
 29e5e61:	sete   %sil
 29e5e65:	or     %esi,%edx
 29e5e67:	cmp    $0x9,%ecx
 29e5e6a:	sete   %cl
 29e5e6d:	or     %ecx,%edx
 29e5e6f:	movzbl %dl,%ecx
 29e5e72:	test   %ecx,%ecx
 29e5e74:	je     29fbe13 <wasm[0]::function[1015]::helper::object_read+0x1ae93>
 29e5e7a:	xor    %ecx,%ecx
 29e5e7c:	test   %eax,%eax
 29e5e7e:	je     29e5ece <wasm[0]::function[1015]::helper::object_read+0x4f4e>
 29e5e84:	xor    %ecx,%ecx
 29e5e86:	test   $0x1,%eax
 29e5e8b:	jne    29e5ece <wasm[0]::function[1015]::helper::object_read+0x4f4e>
 29e5e91:	mov    0x2e0(%rsp),%r12
 29e5e99:	mov    0x28(%r12),%rcx
 29e5e9e:	mov    0x20(%r12),%rdx
 29e5ea3:	mov    %eax,%esi
 29e5ea5:	lea    0x4(%rdx,%rsi,1),%rdx
 29e5eaa:	xor    %rdi,%rdi
 29e5ead:	cmp    %rcx,%rsi
 29e5eb0:	cmova  %rdi,%rdx
 29e5eb4:	mov    (%rdx),%ecx
 29e5eb6:	mov    0x190(%rsp),%rdx
 29e5ebe:	mov    0x28(%rdx),%rdx
 29e5ec2:	cmp    0x1d4(%rdx),%ecx
 29e5ec8:	sete   %cl
 29e5ecb:	movzbl %cl,%ecx
 29e5ece:	test   %ecx,%ecx
 29e5ed0:	je     29fbe15 <wasm[0]::function[1015]::helper::object_read+0x1ae95>
 29e5ed6:	test   %eax,%eax
 29e5ed8:	je     29fbe17 <wasm[0]::function[1015]::helper::object_read+0x1ae97>
 29e5ede:	movl   $0x0,0x148(%rsp)
 29e5ee9:	movl   $0x0,0xe8(%rsp)
 29e5ef4:	movl   $0x0,0x98(%rsp)
 29e5eff:	movl   $0x0,0x118(%rsp)
 29e5f0a:	movl   $0x0,0xb0(%rsp)
 29e5f15:	mov    $0x105,%edx
 29e5f1a:	mov    0x190(%rsp),%rsi
 29e5f22:	mov    0x190(%rsp),%rdi
 29e5f2a:	call   2f30600 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 29e5f2f:	test   %eax,%eax
 29e5f31:	je     29fbe19 <wasm[0]::function[1015]::helper::object_read+0x1ae99>
 29e5f37:	mov    0xd0(%rsp),%r8d
 29e5f3f:	mov    $0x8,%edx
 29e5f44:	xor    %rcx,%rcx
 29e5f47:	movabs $0x4000000000000000,%rsi
 29e5f51:	mov    %rsi,(%rsp)
 29e5f55:	mov    0x278(%rsp),%rsi
 29e5f5d:	mov    %esi,0x8(%rsp)
 29e5f61:	mov    %rax,%r9
 29e5f64:	mov    0x190(%rsp),%rsi
 29e5f6c:	mov    0x190(%rsp),%rdi
 29e5f74:	call   2a560c0 <wasm[0]::function[1029]::helper::native_function_allocate>
 29e5f79:	sub    $0x10,%rsp
 29e5f7d:	mov    %eax,0xd0(%rsp)
 29e5f84:	mov    $0x51,%esi
 29e5f89:	mov    0x190(%rsp),%rdi
 29e5f91:	call   3018b4e <wasmtime_builtin_ref_func>
 29e5f96:	mov    0x190(%rsp),%rcx
 29e5f9e:	mov    %rax,%r13
 29e5fa1:	mov    0x20(%rcx),%rdi
 29e5fa5:	mov    (%rdi),%eax
 29e5fa7:	mov    %eax,%esi
 29e5fa9:	lea    0x40(%rsi),%r8
 29e5fad:	mov    0x4(%rdi),%r9d
 29e5fb1:	mov    %rdi,0x2c0(%rsp)
 29e5fb9:	cmp    %r9,%r8
 29e5fbc:	ja     29fa87f <wasm[0]::function[1015]::helper::object_read+0x198ff>
 29e5fc2:	lea    0x40(%rax),%edi
 29e5fc5:	mov    0x2c0(%rsp),%rcx
 29e5fcd:	mov    %edi,(%rcx)
 29e5fcf:	mov    0x2e0(%rsp),%r12
 29e5fd7:	mov    0x20(%r12),%r8
 29e5fdc:	lea    (%r8,%rsi,1),%rbx
 29e5fe0:	movl   $0xb0000002,(%r8,%rsi,1)
 29e5fe8:	mov    0x190(%rsp),%rcx
 29e5ff0:	mov    0x28(%rcx),%r9
 29e5ff4:	mov    0x1d0(%r9),%r9d
 29e5ffb:	mov    %r9d,0x4(%r8,%rsi,1)
 29e6000:	mov    $0x40,%r10d
 29e6006:	mov    %r10d,0x8(%r8,%rsi,1)
 29e600b:	mov    %eax,0x130(%rsp)
 29e6012:	movq   $0x51,0x10(%rbx)
 29e601a:	movl   $0x1,0x18(%rbx)
 29e6021:	movl   $0xf,0x1c(%rbx)
 29e6028:	movl   $0xffffffff,0x20(%rbx)
 29e602f:	movl   $0x0,0x24(%rbx)
 29e6036:	movl   $0x0,0x28(%rbx)
 29e603d:	mov    %r13,%rsi
 29e6040:	mov    0x190(%rsp),%rdi
 29e6048:	call   3018c43 <wasmtime_builtin_intern_func_ref_for_gc_heap>
 29e604d:	mov    %eax,0x2c(%rbx)
 29e6050:	xor    %rsi,%rsi
 29e6053:	mov    %rsi,%r12
 29e6056:	mov    0x190(%rsp),%rdi
 29e605e:	call   3018c43 <wasmtime_builtin_intern_func_ref_for_gc_heap>
 29e6063:	mov    %eax,0x30(%rbx)
 29e6066:	mov    %r12,%rsi
 29e6069:	mov    0x190(%rsp),%rdi
 29e6071:	call   3018c43 <wasmtime_builtin_intern_func_ref_for_gc_heap>
 29e6076:	mov    %eax,0x34(%rbx)
 29e6079:	mov    %r12,%rsi
 29e607c:	mov    0x190(%rsp),%rdi
 29e6084:	call   3018c43 <wasmtime_builtin_intern_func_ref_for_gc_heap>
 29e6089:	mov    %eax,0x38(%rbx)
 29e608c:	mov    %r12,%rsi
 29e608f:	mov    0x190(%rsp),%rdi
 29e6097:	call   3018c43 <wasmtime_builtin_intern_func_ref_for_gc_heap>
 29e609c:	mov    %eax,0x3c(%rbx)
 29e609f:	mov    0x190(%rsp),%rcx
 29e60a7:	mov    0xa20(%rcx),%eax
 29e60ad:	mov    %eax,0xf0(%rsp)
 29e60b4:	mov    0x140(%rsp),%ecx
 29e60bb:	test   %ecx,%ecx
 29e60bd:	je     29fbe1b <wasm[0]::function[1015]::helper::object_read+0x1ae9b>
 29e60c3:	test   %eax,%eax
 29e60c5:	je     29fbe1d <wasm[0]::function[1015]::helper::object_read+0x1ae9d>
 29e60cb:	mov    0x2c0(%rsp),%rsi
 29e60d3:	mov    (%rsi),%eax
 29e60d5:	mov    %eax,%ecx
 29e60d7:	lea    0x40(%rcx),%rdx
 29e60db:	mov    0x4(%rsi),%esi
 29e60de:	cmp    %rsi,%rdx
 29e60e1:	ja     29fa8c2 <wasm[0]::function[1015]::helper::object_read+0x19942>
 29e60e7:	mov    %rax,%rdx
 29e60ea:	lea    0x40(%rdx),%eax
 29e60ed:	mov    0x2c0(%rsp),%rsi
 29e60f5:	mov    %eax,(%rsi)
 29e60f7:	mov    0x2e0(%rsp),%r12
 29e60ff:	mov    0x20(%r12),%rax
 29e6104:	lea    (%rax,%rcx,1),%rbx
 29e6108:	movl   $0xb0001ffa,(%rax,%rcx,1)
 29e610f:	mov    0x190(%rsp),%rsi
 29e6117:	mov    0x28(%rsi),%rsi
 29e611b:	mov    0x1e0(%rsi),%esi
 29e6121:	mov    %esi,0x4(%rax,%rcx,1)
 29e6125:	mov    $0x40,%esi
 29e612a:	mov    %esi,0x8(%rax,%rcx,1)
 29e612e:	mov    %edx,0xd8(%rsp)
 29e6135:	mov    0x140(%rsp),%eax
 29e613c:	mov    %eax,0x10(%rbx)
 29e613f:	mov    0x148(%rsp),%eax
 29e6146:	mov    %eax,0x14(%rbx)
 29e6149:	mov    0xe8(%rsp),%eax
 29e6150:	mov    %eax,0x18(%rbx)
 29e6153:	movl   $0x0,0x1c(%rbx)
 29e615a:	mov    0xf0(%rsp),%eax
 29e6161:	mov    %eax,0x20(%rbx)
 29e6164:	mov    0x98(%rsp),%eax
 29e616b:	mov    %eax,0x24(%rbx)
 29e616e:	mov    0xb0(%rsp),%eax
 29e6175:	mov    %eax,0x28(%rbx)
 29e6178:	mov    0x100(%rsp),%eax
 29e617f:	mov    %eax,0x2c(%rbx)
 29e6182:	mov    0x118(%rsp),%eax
 29e6189:	mov    %eax,0x30(%rbx)
 29e618c:	movl   $0x0,0x34(%rbx)
 29e6193:	xor    %rsi,%rsi
 29e6196:	mov    0x190(%rsp),%rdi
 29e619e:	call   3018c43 <wasmtime_builtin_intern_func_ref_for_gc_heap>
 29e61a3:	mov    %eax,0x38(%rbx)
 29e61a6:	mov    $0xea5,%edx
 29e61ab:	mov    0x190(%rsp),%rsi
 29e61b3:	mov    0x190(%rsp),%rdi
 29e61bb:	call   2f30600 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 29e61c0:	mov    %eax,0x118(%rsp)
 29e61c7:	mov    0x190(%rsp),%rcx
 29e61cf:	mov    0xa20(%rcx),%ecx
 29e61d5:	mov    %ecx,0x100(%rsp)
 29e61dc:	mov    0xd0(%rsp),%edx
 29e61e3:	test   %edx,%edx
 29e61e5:	je     29fbe1f <wasm[0]::function[1015]::helper::object_read+0x1ae9f>
 29e61eb:	mov    0x130(%rsp),%edx
 29e61f2:	test   %edx,%edx
 29e61f4:	je     29fbe21 <wasm[0]::function[1015]::helper::object_read+0x1aea1>
 29e61fa:	mov    0xd8(%rsp),%edx
 29e6201:	test   %edx,%edx
 29e6203:	je     29fbe23 <wasm[0]::function[1015]::helper::object_read+0x1aea3>
 29e6209:	test   %eax,%eax
 29e620b:	je     29fbe25 <wasm[0]::function[1015]::helper::object_read+0x1aea5>
 29e6211:	test   %ecx,%ecx
 29e6213:	je     29fbe27 <wasm[0]::function[1015]::helper::object_read+0x1aea7>
 29e6219:	mov    0x2c0(%rsp),%rsi
 29e6221:	mov    (%rsi),%eax
 29e6223:	mov    %eax,%edx
 29e6225:	lea    0x50(%rdx),%rcx
 29e6229:	mov    0x4(%rsi),%esi
 29e622c:	cmp    %rsi,%rcx
 29e622f:	ja     29fa908 <wasm[0]::function[1015]::helper::object_read+0x19988>
 29e6235:	lea    0x50(%rax),%ecx
 29e6238:	mov    0x2c0(%rsp),%rsi
 29e6240:	mov    %ecx,(%rsi)
 29e6242:	mov    0x2e0(%rsp),%r12
 29e624a:	mov    0x20(%r12),%rsi
 29e624f:	lea    (%rsi,%rdx,1),%rcx
 29e6253:	movl   $0xb00300fa,(%rsi,%rdx,1)
 29e625a:	mov    0x190(%rsp),%rdi
 29e6262:	mov    0x28(%rdi),%rdi
 29e6266:	mov    0x1d4(%rdi),%edi
 29e626c:	mov    %edi,0x4(%rsi,%rdx,1)
 29e6270:	mov    $0x50,%edi
 29e6275:	mov    %edi,0x8(%rsi,%rdx,1)
 29e6279:	mov    %eax,0xb0(%rsp)
 29e6280:	mov    0xd0(%rsp),%edi
 29e6287:	mov    %edi,0x10(%rcx)
 29e628a:	mov    0x130(%rsp),%r8d
 29e6292:	mov    %r8d,0x14(%rcx)
 29e6296:	mov    0xd8(%rsp),%r9d
 29e629e:	mov    %r9d,0x18(%rcx)
 29e62a2:	mov    0x118(%rsp),%r10d
 29e62aa:	mov    %r10d,0x1c(%rcx)
 29e62ae:	mov    0x100(%rsp),%r11d
 29e62b6:	mov    %r11d,0x20(%rcx)
 29e62ba:	movl   $0x1,0x24(%rcx)
 29e62c1:	movl   $0x0,0x28(%rcx)
 29e62c8:	movl   $0x0,0x2c(%rcx)
 29e62cf:	movl   $0x0,0x30(%rcx)
 29e62d6:	movl   $0x0,0x34(%rcx)
 29e62dd:	movl   $0x0,0x38(%rcx)
 29e62e4:	movl   $0x0,0x3c(%rcx)
 29e62eb:	movl   $0xffffffff,0x40(%rcx)
 29e62f2:	movl   $0x0,0x44(%rcx)
 29e62f9:	movl   $0x0,0x48(%rcx)
 29e6300:	test   %r9d,%r9d
 29e6303:	je     29fbe29 <wasm[0]::function[1015]::helper::object_read+0x1aea9>
 29e6309:	test   %eax,%eax
 29e630b:	je     29fbe2b <wasm[0]::function[1015]::helper::object_read+0x1aeab>
 29e6311:	test   %r9d,%r9d
 29e6314:	je     29fbe2d <wasm[0]::function[1015]::helper::object_read+0x1aead>
 29e631a:	mov    0x2e0(%rsp),%r12
 29e6322:	mov    0x28(%r12),%rcx
 29e6327:	mov    %r9d,%esi
 29e632a:	mov    %rsi,%rdx
 29e632d:	add    0x20(%r12),%rdx
 29e6332:	xor    %rdi,%rdi
 29e6335:	cmp    %rcx,%rsi
 29e6338:	cmova  %rdi,%rdx
 29e633c:	mov    %eax,0x1c(%rdx)
 29e633f:	movl   $0x0,0xd8(%rsp)
 29e634a:	mov    0x2c0(%rsp),%rsi
 29e6352:	mov    (%rsi),%eax
 29e6354:	mov    %eax,%edx
 29e6356:	lea    0x20(%rdx),%rcx
 29e635a:	mov    0x4(%rsi),%esi
 29e635d:	cmp    %rsi,%rcx
 29e6360:	ja     29fa94b <wasm[0]::function[1015]::helper::object_read+0x199cb>
 29e6366:	lea    0x20(%rax),%ecx
 29e6369:	mov    0x2c0(%rsp),%rsi
 29e6371:	mov    %ecx,(%rsi)
 29e6373:	mov    0x2e0(%rsp),%r12
 29e637b:	mov    0x20(%r12),%rsi
 29e6380:	lea    (%rsi,%rdx,1),%rcx
 29e6384:	movl   $0xb0000042,(%rsi,%rdx,1)
 29e638b:	mov    0x190(%rsp),%rdi
 29e6393:	mov    0x28(%rdi),%rdi
 29e6397:	mov    0x120(%rdi),%edi
 29e639d:	mov    %edi,0x4(%rsi,%rdx,1)
 29e63a1:	mov    0x2c8(%rsp),%rdi
 29e63a9:	mov    %edi,0x8(%rsi,%rdx,1)
 29e63ad:	mov    %eax,0x100(%rsp)
 29e63b4:	mov    0x2d8(%rsp),%rax
 29e63bc:	mov    %rax,0x10(%rcx)
 29e63c0:	mov    0x2d0(%rsp),%rax
 29e63c8:	mov    %eax,0x18(%rcx)
 29e63cb:	mov    0x120(%rsp),%eax
 29e63d2:	mov    %eax,0x1c(%rcx)
 29e63d5:	mov    0x2c0(%rsp),%rsi
 29e63dd:	mov    (%rsi),%eax
 29e63df:	mov    %eax,%ecx
 29e63e1:	lea    0x20(%rcx),%rdx
 29e63e5:	mov    0x4(%rsi),%esi
 29e63e8:	cmp    %rsi,%rdx
 29e63eb:	ja     29fa98e <wasm[0]::function[1015]::helper::object_read+0x19a0e>
 29e63f1:	lea    0x20(%rax),%edx
 29e63f4:	mov    0x2c0(%rsp),%rsi
 29e63fc:	mov    %edx,(%rsi)
 29e63fe:	mov    0x2e0(%rsp),%r12
 29e6406:	mov    0x20(%r12),%rdx
 29e640b:	lea    (%rdx,%rcx,1),%rsi
 29e640f:	movl   $0xb0000042,(%rdx,%rcx,1)
 29e6416:	mov    0x190(%rsp),%rdi
 29e641e:	mov    0x28(%rdi),%rdi
 29e6422:	mov    0x120(%rdi),%edi
 29e6428:	mov    %edi,0x4(%rdx,%rcx,1)
 29e642c:	mov    0x2c8(%rsp),%rdi
 29e6434:	mov    %edi,0x8(%rdx,%rcx,1)
 29e6438:	mov    %eax,0x118(%rsp)
 29e643f:	mov    0x1c0(%rsp),%r8
 29e6447:	mov    %r8,0x10(%rsi)
 29e644b:	mov    0x1b8(%rsp),%rcx
 29e6453:	mov    %ecx,0x18(%rsi)
 29e6456:	mov    0x110(%rsp),%ecx
 29e645d:	mov    %ecx,0x1c(%rsi)
 29e6460:	mov    0x100(%rsp),%ecx
 29e6467:	test   %ecx,%ecx
 29e6469:	je     29fbe2f <wasm[0]::function[1015]::helper::object_read+0x1aeaf>
 29e646f:	test   %eax,%eax
 29e6471:	je     29fbe31 <wasm[0]::function[1015]::helper::object_read+0x1aeb1>
 29e6477:	mov    0x2c0(%rsp),%rsi
 29e647f:	mov    (%rsi),%eax
 29e6481:	mov    %eax,%ecx
 29e6483:	lea    0x20(%rcx),%rdx
 29e6487:	mov    0x4(%rsi),%esi
 29e648a:	cmp    %rsi,%rdx
 29e648d:	ja     29fa9d1 <wasm[0]::function[1015]::helper::object_read+0x19a51>
 29e6493:	lea    0x20(%rax),%edx
 29e6496:	mov    0x2c0(%rsp),%rsi
 29e649e:	mov    %edx,(%rsi)
 29e64a0:	mov    0x2e0(%rsp),%r12
 29e64a8:	mov    0x20(%r12),%rsi
 29e64ad:	lea    (%rsi,%rcx,1),%rdx
 29e64b1:	movl   $0xa800000e,(%rsi,%rcx,1)
 29e64b8:	mov    0x190(%rsp),%r9
 29e64c0:	mov    0x28(%r9),%rdi
 29e64c4:	mov    0x1b4(%rdi),%edi
 29e64ca:	mov    %edi,0x4(%rsi,%rcx,1)
 29e64ce:	mov    0x2c8(%rsp),%rdi
 29e64d6:	mov    %edi,0x8(%rsi,%rcx,1)
 29e64da:	movl   $0x2,0x10(%rdx)
 29e64e1:	test   %eax,%eax
 29e64e3:	je     29fbe33 <wasm[0]::function[1015]::helper::object_read+0x1aeb3>
 29e64e9:	mov    0x2e0(%rsp),%r12
 29e64f1:	mov    0x28(%r12),%rdi
 29e64f6:	mov    0x20(%r12),%r8
 29e64fb:	mov    %eax,%r9d
 29e64fe:	lea    0x10(%r8,%r9,1),%rsi
 29e6503:	xor    %rcx,%rcx
 29e6506:	cmp    %rdi,%r9
 29e6509:	cmova  %rcx,%rsi
 29e650d:	mov    (%rsi),%edx
 29e650f:	test   %edx,%edx
 29e6511:	je     29fbe35 <wasm[0]::function[1015]::helper::object_read+0x1aeb5>
 29e6517:	mov    %edx,%r9d
 29e651a:	shl    $0x2,%r9
 29e651e:	shr    $0x20,%r9
 29e6522:	test   %r9,%r9
 29e6525:	jne    29fbe37 <wasm[0]::function[1015]::helper::object_read+0x1aeb7>
 29e652b:	shl    $0x2,%edx
 29e652e:	add    $0x14,%edx
 29e6531:	jb     29fbe39 <wasm[0]::function[1015]::helper::object_read+0x1aeb9>
 29e6537:	mov    %rax,%r10
 29e653a:	add    %edx,%r10d
 29e653d:	jb     29fbe3b <wasm[0]::function[1015]::helper::object_read+0x1aebb>
 29e6543:	mov    0x100(%rsp),%r9d
 29e654b:	mov    %r10d,%r10d
 29e654e:	lea    (%r8,%r10,1),%r11
 29e6552:	cmp    %rdi,%r10
 29e6555:	cmova  %rcx,%r11
 29e6559:	sub    $0x14,%edx
 29e655c:	sub    %rdx,%r11
 29e655f:	mov    %r9d,(%r11)
 29e6562:	mov    (%rsi),%esi
 29e6564:	cmp    $0x1,%esi
 29e6567:	jbe    29fbe3d <wasm[0]::function[1015]::helper::object_read+0x1aebd>
 29e656d:	mov    %esi,%edx
 29e656f:	shl    $0x2,%rdx
 29e6573:	shr    $0x20,%rdx
 29e6577:	test   %rdx,%rdx
 29e657a:	jne    29fbe3f <wasm[0]::function[1015]::helper::object_read+0x1aebf>
 29e6580:	shl    $0x2,%esi
 29e6583:	add    $0x14,%esi
 29e6586:	jb     29fbe41 <wasm[0]::function[1015]::helper::object_read+0x1aec1>
 29e658c:	mov    %rax,%r9
 29e658f:	add    %esi,%r9d
 29e6592:	jb     29fbe43 <wasm[0]::function[1015]::helper::object_read+0x1aec3>
 29e6598:	mov    0x118(%rsp),%edx
 29e659f:	mov    %r9d,%r9d
 29e65a2:	add    %r9,%r8
 29e65a5:	cmp    %rdi,%r9
 29e65a8:	cmova  %rcx,%r8
 29e65ac:	sub    $0x18,%esi
 29e65af:	sub    %rsi,%r8
 29e65b2:	mov    %edx,(%r8)
 29e65b5:	mov    0x190(%rsp),%rsi
 29e65bd:	mov    0x8c0(%rsi),%edi
 29e65c3:	mov    %edi,0x118(%rsp)
 29e65ca:	xor    %r9d,%r9d
 29e65cd:	test   %edi,%edi
 29e65cf:	je     29fbe45 <wasm[0]::function[1015]::helper::object_read+0x1aec5>
 29e65d5:	test   %eax,%eax
 29e65d7:	je     29fbe47 <wasm[0]::function[1015]::helper::object_read+0x1aec7>
 29e65dd:	mov    0x88(%rsp),%esi
 29e65e4:	test   %esi,%esi
 29e65e6:	je     29fbe49 <wasm[0]::function[1015]::helper::object_read+0x1aec9>
 29e65ec:	mov    0xb0(%rsp),%r8d
 29e65f4:	mov    0xd8(%rsp),%r11d
 29e65fc:	mov    0x78(%rsp),%r10d
 29e6601:	mov    $0x8,%edx
 29e6606:	mov    %rcx,(%rsp)
 29e660a:	mov    %r11d,0x8(%rsp)
 29e660f:	mov    %eax,0x10(%rsp)
 29e6613:	mov    %edi,0x18(%rsp)
 29e6617:	mov    %r10d,0x20(%rsp)
 29e661c:	mov    %esi,0x28(%rsp)
 29e6620:	mov    0x190(%rsp),%rsi
 29e6628:	mov    0x190(%rsp),%rdi
 29e6630:	call   2adef60 <wasm[0]::function[1055]::helper::proxy_call>
 29e6635:	sub    $0x30,%rsp
 29e6639:	mov    %rax,0x2a8(%rsp)
 29e6641:	mov    %rcx,0x2b0(%rsp)
 29e6649:	mov    %edx,0xb0(%rsp)
 29e6650:	mov    0x118(%rsp),%eax
 29e6657:	test   %eax,%eax
 29e6659:	je     29fbe4b <wasm[0]::function[1015]::helper::object_read+0x1aecb>
 29e665f:	mov    0x190(%rsp),%rcx
 29e6667:	mov    %eax,0x8c0(%rcx)
 29e666d:	cmp    $0x2,%esi
 29e6670:	jne    29e667b <wasm[0]::function[1015]::helper::object_read+0x56fb>
 29e6676:	xor    %esi,%esi
 29e6678:	mov    %rsi,%rdi
 29e667b:	cmp    $0x1,%esi
 29e667e:	je     29ec7e7 <wasm[0]::function[1015]::helper::object_read+0xb867>
 29e6684:	mov    0xa0(%rsp),%eax
 29e668b:	mov    0xe0(%rsp),%esi
 29e6692:	mov    0x78(%rsp),%edi
 29e6696:	mov    0x88(%rsp),%r8d
 29e669e:	mov    0x120(%rsp),%edx
 29e66a5:	mov    0x110(%rsp),%ecx
 29e66ac:	mov    0x2a8(%rsp),%r9
 29e66b4:	mov    0x2a8(%rsp),%r10
 29e66bc:	test   %r10d,%r9d
 29e66bf:	je     29ec7df <wasm[0]::function[1015]::helper::object_read+0xb85f>
 29e66c5:	mov    $0x12b,%edx
 29e66ca:	mov    0x190(%rsp),%rsi
 29e66d2:	mov    0x190(%rsp),%rdi
 29e66da:	call   2f30600 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 29e66df:	mov    %eax,0xa0(%rsp)
 29e66e6:	xor    %r13d,%r13d
 29e66e9:	test   %eax,%eax
 29e66eb:	je     29fbe4d <wasm[0]::function[1015]::helper::object_read+0x1aecd>
 29e66f1:	movl   $0x0,0x118(%rsp)
 29e66fc:	mov    0xb0(%rsp),%edx
 29e6703:	mov    %rdx,0x220(%rsp)
 29e670b:	mov    0xe0(%rsp),%edx
 29e6712:	mov    0x78(%rsp),%esi
 29e6716:	mov    0x88(%rsp),%edi
 29e671d:	mov    0x120(%rsp),%r15d
 29e6725:	mov    0x110(%rsp),%r8d
 29e672d:	mov    0x2a8(%rsp),%rcx
 29e6735:	cmp    $0x6,%ecx
 29e6738:	sete   %cl
 29e673b:	mov    0x2a8(%rsp),%rax
 29e6743:	cmp    $0x7,%eax
 29e6746:	sete   %al
 29e6749:	or     %eax,%ecx
 29e674b:	mov    0x2a8(%rsp),%rax
 29e6753:	cmp    $0x8,%eax
 29e6756:	sete   %al
 29e6759:	or     %eax,%ecx
 29e675b:	mov    0x2a8(%rsp),%rax
 29e6763:	cmp    $0x9,%eax
 29e6766:	sete   %al
 29e6769:	or     %eax,%ecx
 29e676b:	xor    %r11,%r11
 29e676e:	test   %cl,%cl
 29e6770:	mov    %rcx,0x2a0(%rsp)
 29e6778:	jne    29e679e <wasm[0]::function[1015]::helper::object_read+0x581e>
 29e677e:	mov    0x220(%rsp),%rax
 29e6786:	mov    %r13,%r14
 29e6789:	mov    %r11,0x240(%rsp)
 29e6791:	mov    %r13,0x248(%rsp)
 29e6799:	jmp    29e73a4 <wasm[0]::function[1015]::helper::object_read+0x6424>
 29e679e:	mov    0xb0(%rsp),%r8d
 29e67a6:	mov    0x2b0(%rsp),%rcx
 29e67ae:	mov    0x2a8(%rsp),%rdx
 29e67b6:	mov    0x190(%rsp),%rsi
 29e67be:	mov    0x190(%rsp),%rdi
 29e67c6:	call   2a5f680 <wasm[0]::function[1039]::helper::object_header_projection>
 29e67cb:	mov    %eax,0xd8(%rsp)
 29e67d2:	test   %eax,%eax
 29e67d4:	je     29fbe4f <wasm[0]::function[1015]::helper::object_read+0x1aecf>
 29e67da:	test   %eax,%eax
 29e67dc:	je     29fbe51 <wasm[0]::function[1015]::helper::object_read+0x1aed1>
 29e67e2:	mov    0x2e0(%rsp),%r12
 29e67ea:	mov    0x28(%r12),%rcx
 29e67ef:	mov    0x20(%r12),%rsi
 29e67f4:	mov    %eax,%edx
 29e67f6:	lea    (%rsi,%rdx,1),%rax
 29e67fa:	xor    %rsi,%rsi
 29e67fd:	cmp    %rcx,%rdx
 29e6800:	cmova  %rsi,%rax
 29e6804:	mov    0x14(%rax),%eax
 29e6807:	mov    %eax,0x100(%rsp)
 29e680e:	test   %eax,%eax
 29e6810:	je     29fbe53 <wasm[0]::function[1015]::helper::object_read+0x1aed3>
 29e6816:	mov    0x100(%rsp),%esi
 29e681d:	xor    %eax,%eax
 29e681f:	test   $0x1,%esi
 29e6825:	jne    29e6883 <wasm[0]::function[1015]::helper::object_read+0x5903>
 29e682b:	mov    0x2e0(%rsp),%r12
 29e6833:	mov    0x28(%r12),%rdi
 29e6838:	mov    0x20(%r12),%r9
 29e683d:	mov    %esi,%r8d
 29e6840:	lea    0x4(%r9,%r8,1),%rsi
 29e6845:	xor    %r9,%r9
 29e6848:	cmp    %rdi,%r8
 29e684b:	cmova  %r9,%rsi
 29e684f:	mov    (%rsi),%esi
 29e6851:	mov    0x190(%rsp),%rcx
 29e6859:	mov    0x28(%rcx),%r8
 29e685d:	mov    0x158(%r8),%edx
 29e6864:	cmp    %edx,%esi
 29e6866:	sete   %r9b
 29e686a:	movzbl %r9b,%eax
 29e686e:	cmp    %edx,%esi
 29e6870:	je     29e6883 <wasm[0]::function[1015]::helper::object_read+0x5903>
 29e6876:	mov    0x190(%rsp),%rdi
 29e687e:	call   3018cd5 <wasmtime_builtin_is_subtype>
 29e6883:	test   %eax,%eax
 29e6885:	jne    29e6adf <wasm[0]::function[1015]::helper::object_read+0x5b5f>
 29e688b:	mov    0xd8(%rsp),%edx
 29e6892:	xor    %r12d,%r12d
 29e6895:	test   %edx,%edx
 29e6897:	je     29fbe55 <wasm[0]::function[1015]::helper::object_read+0x1aed5>
 29e689d:	mov    0xa0(%rsp),%r9d
 29e68a5:	mov    $0x4,%ecx
 29e68aa:	xor    %r8,%r8
 29e68ad:	mov    0x190(%rsp),%rsi
 29e68b5:	mov    0x190(%rsp),%rdi
 29e68bd:	call   2a58e80 <wasm[0]::function[1032]::helper::ordinary_property_find>
 29e68c2:	test   %eax,%eax
 29e68c4:	je     29e68ff <wasm[0]::function[1015]::helper::object_read+0x597f>
 29e68ca:	test   %eax,%eax
 29e68cc:	je     29fbe57 <wasm[0]::function[1015]::helper::object_read+0x1aed7>
 29e68d2:	test   %eax,%eax
 29e68d4:	je     29fbe59 <wasm[0]::function[1015]::helper::object_read+0x1aed9>
 29e68da:	mov    0x2e0(%rsp),%r12
 29e68e2:	mov    0x28(%r12),%rcx
 29e68e7:	mov    %eax,%edx
 29e68e9:	mov    %rdx,%rax
 29e68ec:	add    0x20(%r12),%rax
 29e68f1:	xor    %rsi,%rsi
 29e68f4:	cmp    %rcx,%rdx
 29e68f7:	cmova  %rsi,%rax
 29e68fb:	mov    0x14(%rax),%r12d
 29e68ff:	mov    0x118(%rsp),%r14d
 29e6907:	xor    %r11,%r11
 29e690a:	xor    %r13d,%r13d
 29e690d:	test   %r12d,%r12d
 29e6910:	je     29e6a99 <wasm[0]::function[1015]::helper::object_read+0x5b19>
 29e6916:	test   %r12d,%r12d
 29e6919:	je     29fbe5b <wasm[0]::function[1015]::helper::object_read+0x1aedb>
 29e691f:	mov    0x2e0(%rsp),%rax
 29e6927:	mov    0x28(%rax),%rcx
 29e692b:	mov    0x20(%rax),%rax
 29e692f:	mov    %r12d,%edx
 29e6932:	add    %rdx,%rax
 29e6935:	xor    %r11,%r11
 29e6938:	cmp    %rcx,%rdx
 29e693b:	cmova  %r11,%rax
 29e693f:	mov    0x10(%rax),%ecx
 29e6942:	mov    0x118(%rsp),%r14d
 29e694a:	xor    %r13d,%r13d
 29e694d:	test   $0x1,%ecx
 29e6953:	jne    29e6a99 <wasm[0]::function[1015]::helper::object_read+0x5b19>
 29e6959:	mov    0x14(%rax),%edx
 29e695c:	test   %edx,%edx
 29e695e:	je     29fbe5d <wasm[0]::function[1015]::helper::object_read+0x1aedd>
 29e6964:	xor    %esi,%esi
 29e6966:	test   $0x1,%edx
 29e696c:	jne    29e69b0 <wasm[0]::function[1015]::helper::object_read+0x5a30>
 29e6972:	mov    0x2e0(%rsp),%r12
 29e697a:	mov    0x28(%r12),%rax
 29e697f:	mov    0x20(%r12),%rcx
 29e6984:	mov    %edx,%esi
 29e6986:	lea    0x4(%rcx,%rsi,1),%rcx
 29e698b:	xor    %rdi,%rdi
 29e698e:	cmp    %rax,%rsi
 29e6991:	cmova  %rdi,%rcx
 29e6995:	mov    (%rcx),%eax
 29e6997:	mov    0x190(%rsp),%rcx
 29e699f:	mov    0x28(%rcx),%rcx
 29e69a3:	cmp    0x120(%rcx),%eax
 29e69a9:	sete   %al
 29e69ac:	rex movzbl %al,%esi
 29e69b0:	test   %esi,%esi
 29e69b2:	jne    29e6a10 <wasm[0]::function[1015]::helper::object_read+0x5a90>
 29e69b8:	mov    0x190(%rsp),%rsi
 29e69c0:	mov    0x190(%rsp),%rdi
 29e69c8:	call   2a01c00 <wasm[0]::function[1024]::helper::property_value_resolve>
 29e69cd:	test   %eax,%eax
 29e69cf:	je     29fbe5f <wasm[0]::function[1015]::helper::object_read+0x1aedf>
 29e69d5:	test   %eax,%eax
 29e69d7:	je     29fbe61 <wasm[0]::function[1015]::helper::object_read+0x1aee1>
 29e69dd:	mov    0x2e0(%rsp),%r12
 29e69e5:	mov    0x28(%r12),%rcx
 29e69ea:	mov    0x20(%r12),%rsi
 29e69ef:	mov    %eax,%edx
 29e69f1:	lea    (%rsi,%rdx,1),%rax
 29e69f5:	xor    %rsi,%rsi
 29e69f8:	cmp    %rcx,%rdx
 29e69fb:	cmova  %rsi,%rax
 29e69ff:	mov    0x18(%rax),%r13d
 29e6a03:	mov    0x10(%rax),%r11
 29e6a07:	mov    0x1c(%rax),%r14d
 29e6a0b:	jmp    29e6a99 <wasm[0]::function[1015]::helper::object_read+0x5b19>
 29e6a10:	xor    %eax,%eax
 29e6a12:	test   $0x1,%edx
 29e6a18:	jne    29e6a5b <wasm[0]::function[1015]::helper::object_read+0x5adb>
 29e6a1e:	mov    0x2e0(%rsp),%r12
 29e6a26:	mov    0x28(%r12),%rax
 29e6a2b:	mov    0x20(%r12),%rcx
 29e6a30:	mov    %edx,%esi
 29e6a32:	lea    0x4(%rcx,%rsi,1),%rcx
 29e6a37:	xor    %rdi,%rdi
 29e6a3a:	cmp    %rax,%rsi
 29e6a3d:	cmova  %rdi,%rcx
 29e6a41:	mov    (%rcx),%eax
 29e6a43:	mov    0x190(%rsp),%rcx
 29e6a4b:	mov    0x28(%rcx),%rcx
 29e6a4f:	cmp    0x120(%rcx),%eax
 29e6a55:	sete   %al
 29e6a58:	movzbl %al,%eax
 29e6a5b:	test   %eax,%eax
 29e6a5d:	je     29fbe63 <wasm[0]::function[1015]::helper::object_read+0x1aee3>
 29e6a63:	test   %edx,%edx
 29e6a65:	je     29fbe65 <wasm[0]::function[1015]::helper::object_read+0x1aee5>
 29e6a6b:	mov    0x2e0(%rsp),%r12
 29e6a73:	mov    0x28(%r12),%rcx
 29e6a78:	mov    0x20(%r12),%rsi
 29e6a7d:	mov    %edx,%edx
 29e6a7f:	lea    (%rsi,%rdx,1),%rax
 29e6a83:	xor    %rsi,%rsi
 29e6a86:	cmp    %rcx,%rdx
 29e6a89:	cmova  %rsi,%rax
 29e6a8d:	mov    0x18(%rax),%r13d
 29e6a91:	mov    0x10(%rax),%r11
 29e6a95:	mov    0x1c(%rax),%r14d
 29e6a99:	mov    0xb0(%rsp),%edx
 29e6aa0:	mov    %rdx,0x220(%rsp)
 29e6aa8:	mov    0xe0(%rsp),%edx
 29e6aaf:	mov    0x78(%rsp),%esi
 29e6ab3:	mov    0x88(%rsp),%edi
 29e6aba:	mov    0x120(%rsp),%r15d
 29e6ac2:	mov    0x110(%rsp),%r8d
 29e6aca:	mov    %r11,0x240(%rsp)
 29e6ad2:	mov    %r13,0x248(%rsp)
 29e6ada:	jmp    29e739c <wasm[0]::function[1015]::helper::object_read+0x641c>
 29e6adf:	mov    0x100(%rsp),%esi
 29e6ae6:	test   %esi,%esi
 29e6ae8:	je     29fbe67 <wasm[0]::function[1015]::helper::object_read+0x1aee7>
 29e6aee:	mov    0x100(%rsp),%r9d
 29e6af6:	xor    %eax,%eax
 29e6af8:	test   $0x1,%r9d
 29e6aff:	jne    29e6b5b <wasm[0]::function[1015]::helper::object_read+0x5bdb>
 29e6b05:	mov    0x2e0(%rsp),%r12
 29e6b0d:	mov    0x28(%r12),%rax
 29e6b12:	mov    0x20(%r12),%rdx
 29e6b17:	mov    %r9d,%ecx
 29e6b1a:	lea    0x4(%rdx,%rcx,1),%r9
 29e6b1f:	xor    %rdx,%rdx
 29e6b22:	cmp    %rax,%rcx
 29e6b25:	cmova  %rdx,%r9
 29e6b29:	mov    (%r9),%esi
 29e6b2c:	mov    0x190(%rsp),%rcx
 29e6b34:	mov    0x28(%rcx),%rax
 29e6b38:	mov    0x158(%rax),%edx
 29e6b3e:	cmp    %edx,%esi
 29e6b40:	sete   %al
 29e6b43:	movzbl %al,%eax
 29e6b46:	cmp    %edx,%esi
 29e6b48:	je     29e6b5b <wasm[0]::function[1015]::helper::object_read+0x5bdb>
 29e6b4e:	mov    0x190(%rsp),%rdi
 29e6b56:	call   3018cd5 <wasmtime_builtin_is_subtype>
 29e6b5b:	test   %eax,%eax
 29e6b5d:	je     29fbe69 <wasm[0]::function[1015]::helper::object_read+0x1aee9>
 29e6b63:	mov    0x100(%rsp),%r10d
 29e6b6b:	mov    0xb0(%rsp),%edx
 29e6b72:	mov    %rdx,0x220(%rsp)
 29e6b7a:	mov    0x118(%rsp),%r14d
 29e6b82:	mov    0xe0(%rsp),%edx
 29e6b89:	mov    0x78(%rsp),%esi
 29e6b8d:	mov    0x88(%rsp),%edi
 29e6b94:	mov    0x120(%rsp),%r15d
 29e6b9c:	mov    0x110(%rsp),%r8d
 29e6ba4:	xor    %ecx,%ecx
 29e6ba6:	mov    %rcx,0x250(%rsp)
 29e6bae:	test   %r10d,%r10d
 29e6bb1:	je     29fbe6b <wasm[0]::function[1015]::helper::object_read+0x1aeeb>
 29e6bb7:	test   %r10d,%r10d
 29e6bba:	je     29fbe6d <wasm[0]::function[1015]::helper::object_read+0x1aeed>
 29e6bc0:	mov    0x2e0(%rsp),%r12
 29e6bc8:	mov    0x28(%r12),%rax
 29e6bcd:	mov    0x20(%r12),%rcx
 29e6bd2:	mov    %r10d,%r12d
 29e6bd5:	lea    (%rcx,%r12,1),%r11
 29e6bd9:	xor    %rbx,%rbx
 29e6bdc:	cmp    %rax,%r12
 29e6bdf:	cmova  %rbx,%r11
 29e6be3:	mov    0x10(%r11),%r11d
 29e6be7:	test   %r11d,%r11d
 29e6bea:	je     29fbe6f <wasm[0]::function[1015]::helper::object_read+0x1aeef>
 29e6bf0:	test   %r11d,%r11d
 29e6bf3:	je     29fbe71 <wasm[0]::function[1015]::helper::object_read+0x1aef1>
 29e6bf9:	mov    %r11d,%r12d
 29e6bfc:	lea    (%rcx,%r12,1),%r11
 29e6c00:	cmp    %rax,%r12
 29e6c03:	cmova  %rbx,%r11
 29e6c07:	mov    0x10(%r11),%r11d
 29e6c0b:	test   %r11d,%r11d
 29e6c0e:	je     29fbe73 <wasm[0]::function[1015]::helper::object_read+0x1aef3>
 29e6c14:	test   %r11d,%r11d
 29e6c17:	je     29fbe75 <wasm[0]::function[1015]::helper::object_read+0x1aef5>
 29e6c1d:	mov    %r11d,%r12d
 29e6c20:	lea    0x10(%rcx,%r12,1),%rcx
 29e6c25:	cmp    %rax,%r12
 29e6c28:	cmova  %rbx,%rcx
 29e6c2c:	mov    (%rcx),%ebx
 29e6c2e:	mov    0xa0(%rsp),%r12d
 29e6c36:	mov    0x190(%rsp),%rcx
 29e6c3e:	mov    0x28(%rcx),%rax
 29e6c42:	mov    0x234(%rax),%r13d
 29e6c49:	mov    0x250(%rsp),%rax
 29e6c51:	mov    %rax,0x218(%rsp)
 29e6c59:	mov    %r11d,0x130(%rsp)
 29e6c61:	mov    %r12d,0xd8(%rsp)
 29e6c69:	mov    %r10d,0x110(%rsp)
 29e6c71:	mov    0x220(%rsp),%rax
 29e6c79:	mov    %eax,0x120(%rsp)
 29e6c80:	mov    %r14d,0x88(%rsp)
 29e6c88:	mov    %edx,0x78(%rsp)
 29e6c8c:	mov    %esi,0xe0(%rsp)
 29e6c93:	mov    %edi,0x118(%rsp)
 29e6c9a:	mov    %r15d,0x100(%rsp)
 29e6ca2:	mov    %r8d,0xa0(%rsp)
 29e6caa:	mov    0x2e8(%rsp),%rax
 29e6cb2:	mov    (%rax),%rcx
 29e6cb5:	mov    0x228(%rsp),%rax
 29e6cbd:	cmp    %rax,%rcx
 29e6cc0:	jae    29faa14 <wasm[0]::function[1015]::helper::object_read+0x19a94>
 29e6cc6:	mov    0x110(%rsp),%r10d
 29e6cce:	mov    0x120(%rsp),%edx
 29e6cd5:	mov    %rdx,0x220(%rsp)
 29e6cdd:	mov    0x88(%rsp),%r14d
 29e6ce5:	mov    0x78(%rsp),%edx
 29e6ce9:	mov    0xe0(%rsp),%esi
 29e6cf0:	mov    0x118(%rsp),%edi
 29e6cf7:	mov    0x100(%rsp),%r15d
 29e6cff:	mov    0xa0(%rsp),%r8d
 29e6d07:	mov    0x250(%rsp),%rcx
 29e6d0f:	cmp    %ebx,%ecx
 29e6d11:	jb     29e6d24 <wasm[0]::function[1015]::helper::object_read+0x5da4>
 29e6d17:	mov    0x218(%rsp),%rax
 29e6d1f:	jmp    29e6f35 <wasm[0]::function[1015]::helper::object_read+0x5fb5>
 29e6d24:	mov    0x130(%rsp),%eax
 29e6d2b:	test   %eax,%eax
 29e6d2d:	je     29fbe77 <wasm[0]::function[1015]::helper::object_read+0x1aef7>
 29e6d33:	test   %eax,%eax
 29e6d35:	je     29fbe79 <wasm[0]::function[1015]::helper::object_read+0x1aef9>
 29e6d3b:	mov    0x2e0(%rsp),%r12
 29e6d43:	mov    0x28(%r12),%rdx
 29e6d48:	mov    0x20(%r12),%rsi
 29e6d4d:	mov    %eax,%r9d
 29e6d50:	lea    0x10(%rsi,%r9,1),%r8
 29e6d55:	xor    %rdi,%rdi
 29e6d58:	cmp    %rdx,%r9
 29e6d5b:	cmova  %rdi,%r8
 29e6d5f:	mov    (%r8),%r8d
 29e6d62:	cmp    %r8d,%ecx
 29e6d65:	jae    29fbe7b <wasm[0]::function[1015]::helper::object_read+0x1aefb>
 29e6d6b:	mov    %r8d,%r9d
 29e6d6e:	shl    $0x2,%r9
 29e6d72:	shr    $0x20,%r9
 29e6d76:	test   %r9,%r9
 29e6d79:	jne    29fbe7d <wasm[0]::function[1015]::helper::object_read+0x1aefd>
 29e6d7f:	shl    $0x2,%r8d
 29e6d83:	add    $0x14,%r8d
 29e6d87:	jb     29fbe7f <wasm[0]::function[1015]::helper::object_read+0x1aeff>
 29e6d8d:	add    %r8d,%eax
 29e6d90:	jb     29fbe81 <wasm[0]::function[1015]::helper::object_read+0x1af01>
 29e6d96:	mov    %eax,%r9d
 29e6d99:	add    %r9,%rsi
 29e6d9c:	cmp    %rdx,%r9
 29e6d9f:	cmova  %rdi,%rsi
 29e6da3:	mov    %rcx,%rdi
 29e6da6:	shl    $0x2,%edi
 29e6da9:	mov    %rcx,0x250(%rsp)
 29e6db1:	add    $0x14,%edi
 29e6db7:	sub    %edi,%r8d
 29e6dba:	sub    %r8,%rsi
 29e6dbd:	mov    (%rsi),%edx
 29e6dbf:	test   %edx,%edx
 29e6dc1:	je     29fbe83 <wasm[0]::function[1015]::helper::object_read+0x1af03>
 29e6dc7:	mov    0xd8(%rsp),%eax
 29e6dce:	cmp    %eax,%edx
 29e6dd0:	je     29e6ea4 <wasm[0]::function[1015]::helper::object_read+0x5f24>
 29e6dd6:	xor    %ecx,%ecx
 29e6dd8:	test   %edx,%edx
 29e6dda:	je     29e6e1c <wasm[0]::function[1015]::helper::object_read+0x5e9c>
 29e6de0:	xor    %ecx,%ecx
 29e6de2:	test   $0x1,%edx
 29e6de8:	jne    29e6e1c <wasm[0]::function[1015]::helper::object_read+0x5e9c>
 29e6dee:	mov    0x2e0(%rsp),%r12
 29e6df6:	mov    0x28(%r12),%rcx
 29e6dfb:	mov    0x20(%r12),%rsi
 29e6e00:	mov    %edx,%edi
 29e6e02:	lea    0x4(%rsi,%rdi,1),%rsi
 29e6e07:	xor    %r8,%r8
 29e6e0a:	cmp    %rcx,%rdi
 29e6e0d:	cmova  %r8,%rsi
 29e6e11:	mov    (%rsi),%ecx
 29e6e13:	cmp    %r13d,%ecx
 29e6e16:	sete   %cl
 29e6e19:	movzbl %cl,%ecx
 29e6e1c:	test   %ecx,%ecx
 29e6e1e:	je     29fbe85 <wasm[0]::function[1015]::helper::object_read+0x1af05>
 29e6e24:	xor    %ecx,%ecx
 29e6e26:	test   %eax,%eax
 29e6e28:	je     29e6e70 <wasm[0]::function[1015]::helper::object_read+0x5ef0>
 29e6e2e:	mov    0xd8(%rsp),%eax
 29e6e35:	xor    %ecx,%ecx
 29e6e37:	test   $0x1,%eax
 29e6e3c:	jne    29e6e70 <wasm[0]::function[1015]::helper::object_read+0x5ef0>
 29e6e42:	mov    0x2e0(%rsp),%r12
 29e6e4a:	mov    0x28(%r12),%rcx
 29e6e4f:	mov    0x20(%r12),%rdi
 29e6e54:	mov    %eax,%esi
 29e6e56:	lea    0x4(%rdi,%rsi,1),%rax
 29e6e5b:	xor    %rdi,%rdi
 29e6e5e:	cmp    %rcx,%rsi
 29e6e61:	cmova  %rdi,%rax
 29e6e65:	mov    (%rax),%eax
 29e6e67:	cmp    %r13d,%eax
 29e6e6a:	sete   %al
 29e6e6d:	movzbl %al,%ecx
 29e6e70:	test   %ecx,%ecx
 29e6e72:	je     29fbe87 <wasm[0]::function[1015]::helper::object_read+0x1af07>
 29e6e78:	mov    0xd8(%rsp),%ecx
 29e6e7f:	xor    %r8d,%r8d
 29e6e82:	test   %ecx,%ecx
 29e6e84:	je     29fbe89 <wasm[0]::function[1015]::helper::object_read+0x1af09>
 29e6e8a:	mov    0x190(%rsp),%rsi
 29e6e92:	mov    0x190(%rsp),%rdi
 29e6e9a:	call   2ae5540 <wasm[0]::function[1057]::helper::string_equality>
 29e6e9f:	jmp    29e6eac <wasm[0]::function[1015]::helper::object_read+0x5f2c>
 29e6ea4:	mov    0x278(%rsp),%rax
 29e6eac:	mov    0x130(%rsp),%r11d
 29e6eb4:	mov    0xd8(%rsp),%r12d
 29e6ebc:	mov    0x110(%rsp),%r10d
 29e6ec4:	mov    0x120(%rsp),%edx
 29e6ecb:	mov    %rdx,0x220(%rsp)
 29e6ed3:	mov    0x88(%rsp),%r14d
 29e6edb:	mov    0x78(%rsp),%edx
 29e6edf:	mov    0xe0(%rsp),%esi
 29e6ee6:	mov    0x118(%rsp),%edi
 29e6eed:	mov    0x100(%rsp),%r15d
 29e6ef5:	mov    0xa0(%rsp),%r8d
 29e6efd:	test   %eax,%eax
 29e6eff:	je     29e6f12 <wasm[0]::function[1015]::helper::object_read+0x5f92>
 29e6f05:	mov    0x250(%rsp),%rcx
 29e6f0d:	jmp    29e6f35 <wasm[0]::function[1015]::helper::object_read+0x5fb5>
 29e6f12:	mov    0x250(%rsp),%rcx
 29e6f1a:	add    $0x1,%ecx
 29e6f20:	mov    %rax,0x218(%rsp)
 29e6f28:	mov    %rcx,0x250(%rsp)
 29e6f30:	jmp    29e6c59 <wasm[0]::function[1015]::helper::object_read+0x5cd9>
 29e6f35:	xor    %r11,%r11
 29e6f38:	xor    %r13d,%r13d
 29e6f3b:	test   %eax,%eax
 29e6f3d:	jne    29e6f58 <wasm[0]::function[1015]::helper::object_read+0x5fd8>
 29e6f43:	mov    %r11,0x240(%rsp)
 29e6f4b:	mov    %r13,0x248(%rsp)
 29e6f53:	jmp    29e739c <wasm[0]::function[1015]::helper::object_read+0x641c>
 29e6f58:	test   %r10d,%r10d
 29e6f5b:	je     29fbe8b <wasm[0]::function[1015]::helper::object_read+0x1af0b>
 29e6f61:	xor    %eax,%eax
 29e6f63:	test   $0x1,%r10d
 29e6f6a:	jne    29e6fb0 <wasm[0]::function[1015]::helper::object_read+0x6030>
 29e6f70:	mov    0x2e0(%rsp),%r12
 29e6f78:	mov    0x28(%r12),%rax
 29e6f7d:	mov    0x20(%r12),%r11
 29e6f82:	mov    %r10d,%ebx
 29e6f85:	lea    0x4(%r11,%rbx,1),%r11
 29e6f8a:	xor    %r12,%r12
 29e6f8d:	cmp    %rax,%rbx
 29e6f90:	cmova  %r12,%r11
 29e6f94:	mov    (%r11),%eax
 29e6f97:	mov    0x190(%rsp),%r9
 29e6f9f:	mov    0x28(%r9),%r9
 29e6fa3:	cmp    0x160(%r9),%eax
 29e6faa:	sete   %al
 29e6fad:	movzbl %al,%eax
 29e6fb0:	test   %eax,%eax
 29e6fb2:	jne    29e7216 <wasm[0]::function[1015]::helper::object_read+0x6296>
 29e6fb8:	xor    %eax,%eax
 29e6fba:	test   $0x1,%r10d
 29e6fc1:	jne    29e7009 <wasm[0]::function[1015]::helper::object_read+0x6089>
 29e6fc7:	mov    0x2e0(%rsp),%r12
 29e6fcf:	mov    0x28(%r12),%r11
 29e6fd4:	mov    0x20(%r12),%rax
 29e6fd9:	mov    %r10d,%ebx
 29e6fdc:	lea    0x4(%rax,%rbx,1),%rax
 29e6fe1:	xor    %r12,%r12
 29e6fe4:	cmp    %r11,%rbx
 29e6fe7:	cmova  %r12,%rax
 29e6feb:	mov    (%rax),%r11d
 29e6fee:	mov    0x190(%rsp),%rax
 29e6ff6:	mov    0x28(%rax),%r9
 29e6ffa:	cmp    0x15c(%r9),%r11d
 29e7001:	sete   %r9b
 29e7005:	movzbl %r9b,%eax
 29e7009:	test   %eax,%eax
 29e700b:	je     29fbe8d <wasm[0]::function[1015]::helper::object_read+0x1af0d>
 29e7011:	test   %r10d,%r10d
 29e7014:	je     29fbe8f <wasm[0]::function[1015]::helper::object_read+0x1af0f>
 29e701a:	mov    0x2e0(%rsp),%r12
 29e7022:	mov    0x28(%r12),%rax
 29e7027:	mov    0x20(%r12),%r12
 29e702c:	mov    %r10d,%r13d
 29e702f:	lea    (%r12,%r13,1),%r10
 29e7033:	xor    %r11,%r11
 29e7036:	cmp    %rax,%r13
 29e7039:	cmova  %r11,%r10
 29e703d:	mov    0x14(%r10),%ebx
 29e7041:	mov    0x18(%r10),%r13d
 29e7045:	mov    0x1c(%r10),%r10d
 29e7049:	test   %ebx,%ebx
 29e704b:	je     29fbe91 <wasm[0]::function[1015]::helper::object_read+0x1af11>
 29e7051:	test   %ebx,%ebx
 29e7053:	je     29fbe93 <wasm[0]::function[1015]::helper::object_read+0x1af13>
 29e7059:	mov    %ebx,%r9d
 29e705c:	lea    0x10(%r12,%r9,1),%r14
 29e7061:	cmp    %rax,%r9
 29e7064:	cmova  %r11,%r14
 29e7068:	mov    (%r14),%r14d
 29e706b:	cmp    %r14d,%ecx
 29e706e:	jae    29fbe95 <wasm[0]::function[1015]::helper::object_read+0x1af15>
 29e7074:	mov    %r14d,%r9d
 29e7077:	shr    $0x20,%r9
 29e707b:	test   %r9,%r9
 29e707e:	jne    29fbe97 <wasm[0]::function[1015]::helper::object_read+0x1af17>
 29e7084:	add    $0x14,%r14d
 29e7088:	jb     29fbe99 <wasm[0]::function[1015]::helper::object_read+0x1af19>
 29e708e:	add    %r14d,%ebx
 29e7091:	jb     29fbe9b <wasm[0]::function[1015]::helper::object_read+0x1af1b>
 29e7097:	mov    %ebx,%r9d
 29e709a:	lea    (%r12,%r9,1),%rbx
 29e709e:	cmp    %rax,%r9
 29e70a1:	cmova  %r11,%rbx
 29e70a5:	lea    0x14(%rcx),%eax
 29e70a8:	sub    %eax,%r14d
 29e70ab:	sub    %r14,%rbx
 29e70ae:	movzbq (%rbx),%r9
 29e70b2:	mov    %r9,0x258(%rsp)
 29e70ba:	test   %r13d,%r13d
 29e70bd:	je     29e7152 <wasm[0]::function[1015]::helper::object_read+0x61d2>
 29e70c3:	test   %r13d,%r13d
 29e70c6:	je     29fbe9d <wasm[0]::function[1015]::helper::object_read+0x1af1d>
 29e70cc:	test   %r13d,%r13d
 29e70cf:	je     29fbe9f <wasm[0]::function[1015]::helper::object_read+0x1af1f>
 29e70d5:	mov    0x2e0(%rsp),%r12
 29e70dd:	mov    0x28(%r12),%rax
 29e70e2:	mov    0x20(%r12),%r11
 29e70e7:	mov    %r13d,%ebx
 29e70ea:	lea    0x10(%r11,%rbx,1),%r14
 29e70ef:	xor    %r12,%r12
 29e70f2:	cmp    %rax,%rbx
 29e70f5:	cmova  %r12,%r14
 29e70f9:	mov    (%r14),%r14d
 29e70fc:	cmp    %r14d,%ecx
 29e70ff:	jae    29fbea1 <wasm[0]::function[1015]::helper::object_read+0x1af21>
 29e7105:	mov    %r14d,%ebx
 29e7108:	shl    $0x3,%rbx
 29e710c:	shr    $0x20,%rbx
 29e7110:	test   %rbx,%rbx
 29e7113:	jne    29fbea3 <wasm[0]::function[1015]::helper::object_read+0x1af23>
 29e7119:	shl    $0x3,%r14d
 29e711d:	add    $0x18,%r14d
 29e7121:	jb     29fbea5 <wasm[0]::function[1015]::helper::object_read+0x1af25>
 29e7127:	add    %r14d,%r13d
 29e712a:	jb     29fbea7 <wasm[0]::function[1015]::helper::object_read+0x1af27>
 29e7130:	mov    %r13d,%r9d
 29e7133:	add    %r9,%r11
 29e7136:	cmp    %rax,%r9
 29e7139:	cmova  %r12,%r11
 29e713d:	mov    %rcx,%rax
 29e7140:	shl    $0x3,%eax
 29e7143:	add    $0x18,%eax
 29e7149:	sub    %eax,%r14d
 29e714c:	sub    %r14,%r11
 29e714f:	mov    (%r11),%r11
 29e7152:	xor    %r14d,%r14d
 29e7155:	test   %r10d,%r10d
 29e7158:	jne    29e716b <wasm[0]::function[1015]::helper::object_read+0x61eb>
 29e715e:	mov    0x258(%rsp),%r9
 29e7166:	jmp    29e71fd <wasm[0]::function[1015]::helper::object_read+0x627d>
 29e716b:	test   %r10d,%r10d
 29e716e:	je     29fbea9 <wasm[0]::function[1015]::helper::object_read+0x1af29>
 29e7174:	test   %r10d,%r10d
 29e7177:	je     29fbeab <wasm[0]::function[1015]::helper::object_read+0x1af2b>
 29e717d:	mov    0x2e0(%rsp),%r12
 29e7185:	mov    0x28(%r12),%rax
 29e718a:	mov    0x20(%r12),%r12
 29e718f:	mov    %r10d,%ebx
 29e7192:	lea    0x10(%r12,%rbx,1),%r14
 29e7197:	xor    %r13,%r13
 29e719a:	cmp    %rax,%rbx
 29e719d:	cmova  %r13,%r14
 29e71a1:	mov    (%r14),%r14d
 29e71a4:	cmp    %r14d,%ecx
 29e71a7:	jae    29fbead <wasm[0]::function[1015]::helper::object_read+0x1af2d>
 29e71ad:	mov    %r14d,%ebx
 29e71b0:	shl    $0x2,%rbx
 29e71b4:	shr    $0x20,%rbx
 29e71b8:	test   %rbx,%rbx
 29e71bb:	jne    29fbeaf <wasm[0]::function[1015]::helper::object_read+0x1af2f>
 29e71c1:	shl    $0x2,%r14d
 29e71c5:	add    $0x14,%r14d
 29e71c9:	jb     29fbeb1 <wasm[0]::function[1015]::helper::object_read+0x1af31>
 29e71cf:	add    %r14d,%r10d
 29e71d2:	jb     29fbeb3 <wasm[0]::function[1015]::helper::object_read+0x1af33>
 29e71d8:	mov    %r10d,%r9d
 29e71db:	lea    (%r12,%r9,1),%r10
 29e71df:	cmp    %rax,%r9
 29e71e2:	cmova  %r13,%r10
 29e71e6:	shl    $0x2,%ecx
 29e71e9:	lea    0x14(%rcx),%eax
 29e71ec:	sub    %eax,%r14d
 29e71ef:	sub    %r14,%r10
 29e71f2:	mov    (%r10),%r14d
 29e71f5:	mov    0x258(%rsp),%r9
 29e71fd:	movzbl %r9b,%r13d
 29e7201:	mov    %r11,0x240(%rsp)
 29e7209:	mov    %r13,0x248(%rsp)
 29e7211:	jmp    29e739c <wasm[0]::function[1015]::helper::object_read+0x641c>
 29e7216:	xor    %eax,%eax
 29e7218:	test   $0x1,%r10d
 29e721f:	jne    29e7265 <wasm[0]::function[1015]::helper::object_read+0x62e5>
 29e7225:	mov    0x2e0(%rsp),%r12
 29e722d:	mov    0x28(%r12),%rax
 29e7232:	mov    0x20(%r12),%r9
 29e7237:	mov    %r10d,%ebx
 29e723a:	lea    0x4(%r9,%rbx,1),%r11
 29e723f:	xor    %r12,%r12
 29e7242:	cmp    %rax,%rbx
 29e7245:	cmova  %r12,%r11
 29e7249:	mov    (%r11),%eax
 29e724c:	mov    0x190(%rsp),%r9
 29e7254:	mov    0x28(%r9),%r9
 29e7258:	cmp    0x160(%r9),%eax
 29e725f:	sete   %al
 29e7262:	movzbl %al,%eax
 29e7265:	test   %eax,%eax
 29e7267:	je     29fbeb5 <wasm[0]::function[1015]::helper::object_read+0x1af35>
 29e726d:	test   %r10d,%r10d
 29e7270:	je     29fbeb7 <wasm[0]::function[1015]::helper::object_read+0x1af37>
 29e7276:	mov    0x2e0(%rsp),%r12
 29e727e:	mov    0x28(%r12),%r11
 29e7283:	mov    0x20(%r12),%rax
 29e7288:	mov    %r10d,%r10d
 29e728b:	lea    (%rax,%r10,1),%rbx
 29e728f:	xor    %r12,%r12
 29e7292:	cmp    %r11,%r10
 29e7295:	cmova  %r12,%rbx
 29e7299:	mov    0x10(%rbx),%r13d
 29e729d:	test   %r13d,%r13d
 29e72a0:	je     29fbeb9 <wasm[0]::function[1015]::helper::object_read+0x1af39>
 29e72a6:	test   %r13d,%r13d
 29e72a9:	je     29fbebb <wasm[0]::function[1015]::helper::object_read+0x1af3b>
 29e72af:	mov    %r13d,%r9d
 29e72b2:	lea    (%rax,%r9,1),%r13
 29e72b6:	cmp    %r11,%r9
 29e72b9:	cmova  %r12,%r13
 29e72bd:	mov    0x10(%r13),%r13d
 29e72c1:	test   %r13d,%r13d
 29e72c4:	je     29fbebd <wasm[0]::function[1015]::helper::object_read+0x1af3d>
 29e72ca:	test   %r13d,%r13d
 29e72cd:	je     29fbebf <wasm[0]::function[1015]::helper::object_read+0x1af3f>
 29e72d3:	mov    %r13d,%r9d
 29e72d6:	lea    0x10(%rax,%r9,1),%rax
 29e72db:	cmp    %r11,%r9
 29e72de:	cmova  %r12,%rax
 29e72e2:	cmp    (%rax),%ecx
 29e72e4:	setae  %al
 29e72e7:	cmp    $0x2,%ecx
 29e72ea:	setae  %r9b
 29e72ee:	or     %r9d,%eax
 29e72f1:	test   %al,%al
 29e72f3:	jne    29fbec1 <wasm[0]::function[1015]::helper::object_read+0x1af41>
 29e72f9:	mov    0x2e0(%rsp),%r12
 29e7301:	mov    0x28(%r12),%r11
 29e7306:	mov    %r10,%rax
 29e7309:	add    0x20(%r12),%rax
 29e730e:	xor    %rbx,%rbx
 29e7311:	cmp    %r11,%r10
 29e7314:	cmova  %rbx,%rax
 29e7318:	mov    0x14(%rax),%r13d
 29e731c:	test   %ecx,%ecx
 29e731e:	je     29e7358 <wasm[0]::function[1015]::helper::object_read+0x63d8>
 29e7324:	mov    0x2e0(%rsp),%r12
 29e732c:	mov    0x28(%r12),%r11
 29e7331:	mov    0x20(%r12),%rax
 29e7336:	add    %r10,%rax
 29e7339:	xor    %rbx,%rbx
 29e733c:	cmp    %r11,%r10
 29e733f:	cmova  %rbx,%rax
 29e7343:	mov    0x20(%rax),%r11
 29e7347:	mov    0x2c(%rax),%r14d
 29e734b:	mov    %r11,0x240(%rsp)
 29e7353:	jmp    29e7387 <wasm[0]::function[1015]::helper::object_read+0x6407>
 29e7358:	mov    0x2e0(%rsp),%r12
 29e7360:	mov    0x28(%r12),%r11
 29e7365:	mov    0x20(%r12),%rax
 29e736a:	add    %r10,%rax
 29e736d:	xor    %rbx,%rbx
 29e7370:	cmp    %r11,%r10
 29e7373:	cmova  %rbx,%rax
 29e7377:	mov    0x18(%rax),%r11
 29e737b:	mov    %r11,0x240(%rsp)
 29e7383:	mov    0x28(%rax),%r14d
 29e7387:	shl    $0x3,%ecx
 29e738a:	shr    %cl,%r13d
 29e738d:	and    $0xff,%r13d
 29e7394:	mov    %r13,0x248(%rsp)
 29e739c:	mov    0x220(%rsp),%rax
 29e73a4:	mov    %eax,0xe0(%rsp)
 29e73ab:	mov    %r14d,0x78(%rsp)
 29e73b0:	mov    %edx,0x88(%rsp)
 29e73b7:	mov    %esi,0x120(%rsp)
 29e73be:	mov    %edi,0x110(%rsp)
 29e73c5:	mov    %r15d,0xd8(%rsp)
 29e73cd:	mov    %r8d,0x130(%rsp)
 29e73d5:	mov    $0x285,%edx
 29e73da:	mov    0x190(%rsp),%rsi
 29e73e2:	mov    0x190(%rsp),%rdi
 29e73ea:	call   2f30600 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 29e73ef:	mov    %eax,0x118(%rsp)
 29e73f6:	xor    %r13d,%r13d
 29e73f9:	test   %eax,%eax
 29e73fb:	je     29fbec3 <wasm[0]::function[1015]::helper::object_read+0x1af43>
 29e7401:	movl   $0x0,0x100(%rsp)
 29e740c:	mov    0xe0(%rsp),%edx
 29e7413:	mov    %rdx,0x198(%rsp)
 29e741b:	mov    0x78(%rsp),%esi
 29e741f:	mov    %rsi,0x1a0(%rsp)
 29e7427:	mov    0x88(%rsp),%r15d
 29e742f:	mov    0x120(%rsp),%esi
 29e7436:	mov    0x110(%rsp),%edi
 29e743d:	mov    0xd8(%rsp),%r8d
 29e7445:	mov    0x130(%rsp),%r9d
 29e744d:	xor    %rbx,%rbx
 29e7450:	mov    0x2a0(%rsp),%rcx
 29e7458:	test   %cl,%cl
 29e745a:	jne    29e7480 <wasm[0]::function[1015]::helper::object_read+0x6500>
 29e7460:	mov    0x198(%rsp),%rdx
 29e7468:	mov    %r13,%r14
 29e746b:	mov    %r13,0x230(%rsp)
 29e7473:	mov    %rbx,0x238(%rsp)
 29e747b:	jmp    29e80e2 <wasm[0]::function[1015]::helper::object_read+0x7162>
 29e7480:	mov    0xe0(%rsp),%r8d
 29e7488:	mov    0x2b0(%rsp),%rcx
 29e7490:	mov    0x2a8(%rsp),%rdx
 29e7498:	mov    0x190(%rsp),%rsi
 29e74a0:	mov    0x190(%rsp),%rdi
 29e74a8:	call   2a5f680 <wasm[0]::function[1039]::helper::object_header_projection>
 29e74ad:	mov    %eax,0xa0(%rsp)
 29e74b4:	test   %eax,%eax
 29e74b6:	je     29fbec5 <wasm[0]::function[1015]::helper::object_read+0x1af45>
 29e74bc:	test   %eax,%eax
 29e74be:	je     29fbec7 <wasm[0]::function[1015]::helper::object_read+0x1af47>
 29e74c4:	mov    0x2e0(%rsp),%r12
 29e74cc:	mov    0x28(%r12),%rcx
 29e74d1:	mov    0x20(%r12),%rsi
 29e74d6:	mov    %eax,%edx
 29e74d8:	lea    (%rsi,%rdx,1),%rax
 29e74dc:	xor    %rsi,%rsi
 29e74df:	cmp    %rcx,%rdx
 29e74e2:	cmova  %rsi,%rax
 29e74e6:	mov    0x14(%rax),%eax
 29e74e9:	mov    %eax,0xc8(%rsp)
 29e74f0:	test   %eax,%eax
 29e74f2:	je     29fbec9 <wasm[0]::function[1015]::helper::object_read+0x1af49>
 29e74f8:	mov    0xc8(%rsp),%ecx
 29e74ff:	xor    %eax,%eax
 29e7501:	test   $0x1,%ecx
 29e7507:	jne    29e7561 <wasm[0]::function[1015]::helper::object_read+0x65e1>
 29e750d:	mov    0x2e0(%rsp),%r12
 29e7515:	mov    0x28(%r12),%rax
 29e751a:	mov    0x20(%r12),%rsi
 29e751f:	mov    %ecx,%edx
 29e7521:	lea    0x4(%rsi,%rdx,1),%rcx
 29e7526:	xor    %rsi,%rsi
 29e7529:	cmp    %rax,%rdx
 29e752c:	cmova  %rsi,%rcx
 29e7530:	mov    (%rcx),%esi
 29e7532:	mov    0x190(%rsp),%rcx
 29e753a:	mov    0x28(%rcx),%rax
 29e753e:	mov    0x158(%rax),%edx
 29e7544:	cmp    %edx,%esi
 29e7546:	sete   %al
 29e7549:	movzbl %al,%eax
 29e754c:	cmp    %edx,%esi
 29e754e:	je     29e7561 <wasm[0]::function[1015]::helper::object_read+0x65e1>
 29e7554:	mov    0x190(%rsp),%rdi
 29e755c:	call   3018cd5 <wasmtime_builtin_is_subtype>
 29e7561:	test   %eax,%eax
 29e7563:	jne    29e77cb <wasm[0]::function[1015]::helper::object_read+0x684b>
 29e7569:	mov    0xa0(%rsp),%edx
 29e7570:	xor    %r12d,%r12d
 29e7573:	test   %edx,%edx
 29e7575:	je     29fbecb <wasm[0]::function[1015]::helper::object_read+0x1af4b>
 29e757b:	mov    0x118(%rsp),%r9d
 29e7583:	mov    $0x4,%ecx
 29e7588:	xor    %r8,%r8
 29e758b:	mov    0x190(%rsp),%rsi
 29e7593:	mov    0x190(%rsp),%rdi
 29e759b:	call   2a58e80 <wasm[0]::function[1032]::helper::ordinary_property_find>
 29e75a0:	test   %eax,%eax
 29e75a2:	je     29e75dd <wasm[0]::function[1015]::helper::object_read+0x665d>
 29e75a8:	test   %eax,%eax
 29e75aa:	je     29fbecd <wasm[0]::function[1015]::helper::object_read+0x1af4d>
 29e75b0:	test   %eax,%eax
 29e75b2:	je     29fbecf <wasm[0]::function[1015]::helper::object_read+0x1af4f>
 29e75b8:	mov    0x2e0(%rsp),%r12
 29e75c0:	mov    0x28(%r12),%rcx
 29e75c5:	mov    %eax,%eax
 29e75c7:	mov    %rax,%r10
 29e75ca:	add    0x20(%r12),%r10
 29e75cf:	xor    %rdx,%rdx
 29e75d2:	cmp    %rcx,%rax
 29e75d5:	cmova  %rdx,%r10
 29e75d9:	mov    0x14(%r10),%r12d
 29e75dd:	mov    0x100(%rsp),%r14d
 29e75e5:	xor    %r13d,%r13d
 29e75e8:	xor    %rbx,%rbx
 29e75eb:	test   %r12d,%r12d
 29e75ee:	je     29e7775 <wasm[0]::function[1015]::helper::object_read+0x67f5>
 29e75f4:	test   %r12d,%r12d
 29e75f7:	je     29fbed1 <wasm[0]::function[1015]::helper::object_read+0x1af51>
 29e75fd:	mov    0x2e0(%rsp),%rax
 29e7605:	mov    0x28(%rax),%rcx
 29e7609:	mov    0x20(%rax),%rax
 29e760d:	mov    %r12d,%edx
 29e7610:	add    %rdx,%rax
 29e7613:	xor    %rbx,%rbx
 29e7616:	cmp    %rcx,%rdx
 29e7619:	cmova  %rbx,%rax
 29e761d:	mov    0x10(%rax),%ecx
 29e7620:	mov    0x100(%rsp),%r14d
 29e7628:	xor    %r13d,%r13d
 29e762b:	test   $0x1,%ecx
 29e7631:	jne    29e7775 <wasm[0]::function[1015]::helper::object_read+0x67f5>
 29e7637:	mov    0x14(%rax),%edx
 29e763a:	test   %edx,%edx
 29e763c:	je     29fbed3 <wasm[0]::function[1015]::helper::object_read+0x1af53>
 29e7642:	xor    %eax,%eax
 29e7644:	test   $0x1,%edx
 29e764a:	jne    29e768d <wasm[0]::function[1015]::helper::object_read+0x670d>
 29e7650:	mov    0x2e0(%rsp),%r12
 29e7658:	mov    0x28(%r12),%rax
 29e765d:	mov    0x20(%r12),%rcx
 29e7662:	mov    %edx,%esi
 29e7664:	lea    0x4(%rcx,%rsi,1),%rcx
 29e7669:	xor    %rdi,%rdi
 29e766c:	cmp    %rax,%rsi
 29e766f:	cmova  %rdi,%rcx
 29e7673:	mov    (%rcx),%eax
 29e7675:	mov    0x190(%rsp),%rcx
 29e767d:	mov    0x28(%rcx),%rcx
 29e7681:	cmp    0x120(%rcx),%eax
 29e7687:	sete   %al
 29e768a:	movzbl %al,%eax
 29e768d:	test   %eax,%eax
 29e768f:	jne    29e76ed <wasm[0]::function[1015]::helper::object_read+0x676d>
 29e7695:	mov    0x190(%rsp),%rsi
 29e769d:	mov    0x190(%rsp),%rdi
 29e76a5:	call   2a01c00 <wasm[0]::function[1024]::helper::property_value_resolve>
 29e76aa:	test   %eax,%eax
 29e76ac:	je     29fbed5 <wasm[0]::function[1015]::helper::object_read+0x1af55>
 29e76b2:	test   %eax,%eax
 29e76b4:	je     29fbed7 <wasm[0]::function[1015]::helper::object_read+0x1af57>
 29e76ba:	mov    0x2e0(%rsp),%r12
 29e76c2:	mov    0x28(%r12),%rcx
 29e76c7:	mov    0x20(%r12),%rsi
 29e76cc:	mov    %eax,%edx
 29e76ce:	lea    (%rsi,%rdx,1),%rax
 29e76d2:	xor    %rsi,%rsi
 29e76d5:	cmp    %rcx,%rdx
 29e76d8:	cmova  %rsi,%rax
 29e76dc:	mov    0x18(%rax),%r13d
 29e76e0:	mov    0x10(%rax),%rbx
 29e76e4:	mov    0x1c(%rax),%r14d
 29e76e8:	jmp    29e7775 <wasm[0]::function[1015]::helper::object_read+0x67f5>
 29e76ed:	xor    %eax,%eax
 29e76ef:	test   $0x1,%edx
 29e76f5:	jne    29e7738 <wasm[0]::function[1015]::helper::object_read+0x67b8>
 29e76fb:	mov    0x2e0(%rsp),%r12
 29e7703:	mov    0x28(%r12),%rax
 29e7708:	mov    0x20(%r12),%rcx
 29e770d:	mov    %edx,%esi
 29e770f:	lea    0x4(%rcx,%rsi,1),%rcx
 29e7714:	xor    %rdi,%rdi
 29e7717:	cmp    %rax,%rsi
 29e771a:	cmova  %rdi,%rcx
 29e771e:	mov    (%rcx),%eax
 29e7720:	mov    0x190(%rsp),%rcx
 29e7728:	mov    0x28(%rcx),%rcx
 29e772c:	cmp    0x120(%rcx),%eax
 29e7732:	sete   %al
 29e7735:	movzbl %al,%eax
 29e7738:	test   %eax,%eax
 29e773a:	je     29fbed9 <wasm[0]::function[1015]::helper::object_read+0x1af59>
 29e7740:	test   %edx,%edx
 29e7742:	je     29fbedb <wasm[0]::function[1015]::helper::object_read+0x1af5b>
 29e7748:	mov    0x2e0(%rsp),%r12
 29e7750:	mov    0x28(%r12),%rcx
 29e7755:	mov    0x20(%r12),%rax
 29e775a:	mov    %edx,%edx
 29e775c:	add    %rdx,%rax
 29e775f:	xor    %rsi,%rsi
 29e7762:	cmp    %rcx,%rdx
 29e7765:	cmova  %rsi,%rax
 29e7769:	mov    0x18(%rax),%r13d
 29e776d:	mov    0x10(%rax),%rbx
 29e7771:	mov    0x1c(%rax),%r14d
 29e7775:	mov    0xe0(%rsp),%edx
 29e777c:	mov    %rdx,0x198(%rsp)
 29e7784:	mov    0x78(%rsp),%esi
 29e7788:	mov    %rsi,0x1a0(%rsp)
 29e7790:	mov    0x88(%rsp),%r15d
 29e7798:	mov    0x120(%rsp),%esi
 29e779f:	mov    0x110(%rsp),%edi
 29e77a6:	mov    0xd8(%rsp),%r8d
 29e77ae:	mov    0x130(%rsp),%r9d
 29e77b6:	mov    %r13,0x230(%rsp)
 29e77be:	mov    %rbx,0x238(%rsp)
 29e77c6:	jmp    29e80da <wasm[0]::function[1015]::helper::object_read+0x715a>
 29e77cb:	mov    0xc8(%rsp),%eax
 29e77d2:	test   %eax,%eax
 29e77d4:	je     29fbedd <wasm[0]::function[1015]::helper::object_read+0x1af5d>
 29e77da:	mov    0xc8(%rsp),%ecx
 29e77e1:	xor    %eax,%eax
 29e77e3:	test   $0x1,%ecx
 29e77e9:	jne    29e7845 <wasm[0]::function[1015]::helper::object_read+0x68c5>
 29e77ef:	mov    0x2e0(%rsp),%r12
 29e77f7:	mov    0x28(%r12),%rax
 29e77fc:	mov    0x20(%r12),%rsi
 29e7801:	mov    %ecx,%edx
 29e7803:	lea    0x4(%rsi,%rdx,1),%rcx
 29e7808:	xor    %rsi,%rsi
 29e780b:	cmp    %rax,%rdx
 29e780e:	cmova  %rsi,%rcx
 29e7812:	mov    (%rcx),%esi
 29e7814:	mov    0x190(%rsp),%rcx
 29e781c:	mov    0x28(%rcx),%rcx
 29e7820:	mov    0x158(%rcx),%edx
 29e7826:	cmp    %edx,%esi
 29e7828:	sete   %dil
 29e782c:	movzbl %dil,%eax
 29e7830:	cmp    %edx,%esi
 29e7832:	je     29e7845 <wasm[0]::function[1015]::helper::object_read+0x68c5>
 29e7838:	mov    0x190(%rsp),%rdi
 29e7840:	call   3018cd5 <wasmtime_builtin_is_subtype>
 29e7845:	test   %eax,%eax
 29e7847:	je     29fbedf <wasm[0]::function[1015]::helper::object_read+0x1af5f>
 29e784d:	mov    0xc8(%rsp),%r11d
 29e7855:	mov    0xe0(%rsp),%edx
 29e785c:	mov    %rdx,0x198(%rsp)
 29e7864:	mov    0x100(%rsp),%r14d
 29e786c:	mov    0x78(%rsp),%esi
 29e7870:	mov    %rsi,0x1a0(%rsp)
 29e7878:	mov    0x88(%rsp),%r15d
 29e7880:	mov    0x120(%rsp),%esi
 29e7887:	mov    0x110(%rsp),%edi
 29e788e:	mov    0xd8(%rsp),%r8d
 29e7896:	mov    0x130(%rsp),%r9d
 29e789e:	xor    %ecx,%ecx
 29e78a0:	mov    %rcx,0x218(%rsp)
 29e78a8:	test   %r11d,%r11d
 29e78ab:	je     29fbee1 <wasm[0]::function[1015]::helper::object_read+0x1af61>
 29e78b1:	test   %r11d,%r11d
 29e78b4:	je     29fbee3 <wasm[0]::function[1015]::helper::object_read+0x1af63>
 29e78ba:	mov    0x2e0(%rsp),%r12
 29e78c2:	mov    0x28(%r12),%rax
 29e78c7:	mov    0x20(%r12),%rcx
 29e78cc:	mov    %r11d,%ebx
 29e78cf:	lea    (%rcx,%rbx,1),%r10
 29e78d3:	xor    %r12,%r12
 29e78d6:	cmp    %rax,%rbx
 29e78d9:	cmova  %r12,%r10
 29e78dd:	mov    0x10(%r10),%r10d
 29e78e1:	test   %r10d,%r10d
 29e78e4:	je     29fbee5 <wasm[0]::function[1015]::helper::object_read+0x1af65>
 29e78ea:	test   %r10d,%r10d
 29e78ed:	je     29fbee7 <wasm[0]::function[1015]::helper::object_read+0x1af67>
 29e78f3:	mov    %r10d,%ebx
 29e78f6:	lea    (%rcx,%rbx,1),%r10
 29e78fa:	cmp    %rax,%rbx
 29e78fd:	cmova  %r12,%r10
 29e7901:	mov    0x10(%r10),%ebx
 29e7905:	test   %ebx,%ebx
 29e7907:	je     29fbee9 <wasm[0]::function[1015]::helper::object_read+0x1af69>
 29e790d:	test   %ebx,%ebx
 29e790f:	je     29fbeeb <wasm[0]::function[1015]::helper::object_read+0x1af6b>
 29e7915:	mov    %ebx,%r10d
 29e7918:	lea    0x10(%rcx,%r10,1),%rcx
 29e791d:	cmp    %rax,%r10
 29e7920:	cmova  %r12,%rcx
 29e7924:	mov    (%rcx),%r13d
 29e7927:	mov    %r13,0x250(%rsp)
 29e792f:	mov    0x118(%rsp),%r12d
 29e7937:	mov    0x190(%rsp),%rcx
 29e793f:	mov    0x28(%rcx),%rax
 29e7943:	mov    0x234(%rax),%r13d
 29e794a:	mov    0x218(%rsp),%rax
 29e7952:	mov    %rax,0x220(%rsp)
 29e795a:	mov    %ebx,0xa0(%rsp)
 29e7961:	mov    %r12d,0x130(%rsp)
 29e7969:	mov    %r11d,0xd8(%rsp)
 29e7971:	mov    0x198(%rsp),%rdx
 29e7979:	mov    %edx,0x110(%rsp)
 29e7980:	mov    %r14d,0x120(%rsp)
 29e7988:	mov    0x1a0(%rsp),%r10
 29e7990:	mov    %r10d,0x88(%rsp)
 29e7998:	mov    %r15d,0x78(%rsp)
 29e799d:	mov    %esi,0x100(%rsp)
 29e79a4:	mov    %edi,0xe0(%rsp)
 29e79ab:	mov    %r8d,0xc8(%rsp)
 29e79b3:	mov    %r9d,0x118(%rsp)
 29e79bb:	mov    0x2e8(%rsp),%rax
 29e79c3:	mov    (%rax),%rcx
 29e79c6:	mov    0x228(%rsp),%rax
 29e79ce:	cmp    %rax,%rcx
 29e79d1:	jae    29faa4c <wasm[0]::function[1015]::helper::object_read+0x19acc>
 29e79d7:	mov    0xd8(%rsp),%r11d
 29e79df:	mov    0x110(%rsp),%edx
 29e79e6:	mov    %rdx,0x198(%rsp)
 29e79ee:	mov    0x120(%rsp),%r14d
 29e79f6:	mov    0x88(%rsp),%esi
 29e79fd:	mov    %rsi,0x1a0(%rsp)
 29e7a05:	mov    0x78(%rsp),%r15d
 29e7a0a:	mov    0x100(%rsp),%esi
 29e7a11:	mov    0xe0(%rsp),%edi
 29e7a18:	mov    0xc8(%rsp),%r8d
 29e7a20:	mov    0x118(%rsp),%r9d
 29e7a28:	mov    0x218(%rsp),%rcx
 29e7a30:	mov    0x250(%rsp),%r10
 29e7a38:	cmp    %r10d,%ecx
 29e7a3b:	jb     29e7a4e <wasm[0]::function[1015]::helper::object_read+0x6ace>
 29e7a41:	mov    0x220(%rsp),%rax
 29e7a49:	jmp    29e7c71 <wasm[0]::function[1015]::helper::object_read+0x6cf1>
 29e7a4e:	mov    0xa0(%rsp),%eax
 29e7a55:	test   %eax,%eax
 29e7a57:	je     29fbeed <wasm[0]::function[1015]::helper::object_read+0x1af6d>
 29e7a5d:	test   %eax,%eax
 29e7a5f:	je     29fbeef <wasm[0]::function[1015]::helper::object_read+0x1af6f>
 29e7a65:	mov    0x2e0(%rsp),%r12
 29e7a6d:	mov    0x28(%r12),%rdx
 29e7a72:	mov    0x20(%r12),%rsi
 29e7a77:	mov    %eax,%r9d
 29e7a7a:	lea    0x10(%rsi,%r9,1),%r8
 29e7a7f:	xor    %rdi,%rdi
 29e7a82:	cmp    %rdx,%r9
 29e7a85:	cmova  %rdi,%r8
 29e7a89:	mov    (%r8),%r8d
 29e7a8c:	cmp    %r8d,%ecx
 29e7a8f:	jae    29fbef1 <wasm[0]::function[1015]::helper::object_read+0x1af71>
 29e7a95:	mov    %r8d,%r9d
 29e7a98:	shl    $0x2,%r9
 29e7a9c:	shr    $0x20,%r9
 29e7aa0:	test   %r9,%r9
 29e7aa3:	jne    29fbef3 <wasm[0]::function[1015]::helper::object_read+0x1af73>
 29e7aa9:	shl    $0x2,%r8d
 29e7aad:	add    $0x14,%r8d
 29e7ab1:	jb     29fbef5 <wasm[0]::function[1015]::helper::object_read+0x1af75>
 29e7ab7:	add    %r8d,%eax
 29e7aba:	jb     29fbef7 <wasm[0]::function[1015]::helper::object_read+0x1af77>
 29e7ac0:	mov    %eax,%r9d
 29e7ac3:	lea    (%rsi,%r9,1),%rax
 29e7ac7:	cmp    %rdx,%r9
 29e7aca:	cmova  %rdi,%rax
 29e7ace:	mov    %rcx,%rdx
 29e7ad1:	shl    $0x2,%edx
 29e7ad4:	mov    %rcx,0x218(%rsp)
 29e7adc:	lea    0x14(%rdx),%ecx
 29e7adf:	sub    %ecx,%r8d
 29e7ae2:	sub    %r8,%rax
 29e7ae5:	mov    (%rax),%edx
 29e7ae7:	test   %edx,%edx
 29e7ae9:	je     29fbef9 <wasm[0]::function[1015]::helper::object_read+0x1af79>
 29e7aef:	mov    0x130(%rsp),%ecx
 29e7af6:	cmp    %ecx,%edx
 29e7af8:	je     29e7bd1 <wasm[0]::function[1015]::helper::object_read+0x6c51>
 29e7afe:	xor    %eax,%eax
 29e7b00:	test   %edx,%edx
 29e7b02:	je     29e7b48 <wasm[0]::function[1015]::helper::object_read+0x6bc8>
 29e7b08:	xor    %eax,%eax
 29e7b0a:	test   $0x1,%edx
 29e7b10:	jne    29e7b48 <wasm[0]::function[1015]::helper::object_read+0x6bc8>
 29e7b16:	mov    0x2e0(%rsp),%r12
 29e7b1e:	mov    0x28(%r12),%r9
 29e7b23:	mov    0x20(%r12),%r11
 29e7b28:	mov    %edx,%r10d
 29e7b2b:	lea    0x4(%r11,%r10,1),%rsi
 29e7b30:	xor    %r11,%r11
 29e7b33:	cmp    %r9,%r10
 29e7b36:	cmova  %r11,%rsi
 29e7b3a:	mov    (%rsi),%r10d
 29e7b3d:	cmp    %r13d,%r10d
 29e7b40:	sete   %r11b
 29e7b44:	movzbl %r11b,%eax
 29e7b48:	test   %eax,%eax
 29e7b4a:	je     29fbefb <wasm[0]::function[1015]::helper::object_read+0x1af7b>
 29e7b50:	xor    %eax,%eax
 29e7b52:	test   %ecx,%ecx
 29e7b54:	je     29e7b9d <wasm[0]::function[1015]::helper::object_read+0x6c1d>
 29e7b5a:	mov    0x130(%rsp),%ecx
 29e7b61:	xor    %eax,%eax
 29e7b63:	test   $0x1,%ecx
 29e7b69:	jne    29e7b9d <wasm[0]::function[1015]::helper::object_read+0x6c1d>
 29e7b6f:	mov    0x2e0(%rsp),%r12
 29e7b77:	mov    0x28(%r12),%rax
 29e7b7c:	mov    0x20(%r12),%rdi
 29e7b81:	mov    %ecx,%esi
 29e7b83:	lea    0x4(%rdi,%rsi,1),%rcx
 29e7b88:	xor    %rdi,%rdi
 29e7b8b:	cmp    %rax,%rsi
 29e7b8e:	cmova  %rdi,%rcx
 29e7b92:	mov    (%rcx),%eax
 29e7b94:	cmp    %r13d,%eax
 29e7b97:	sete   %al
 29e7b9a:	movzbl %al,%eax
 29e7b9d:	test   %eax,%eax
 29e7b9f:	je     29fbefd <wasm[0]::function[1015]::helper::object_read+0x1af7d>
 29e7ba5:	mov    0x130(%rsp),%ecx
 29e7bac:	xor    %r8d,%r8d
 29e7baf:	test   %ecx,%ecx
 29e7bb1:	je     29fbeff <wasm[0]::function[1015]::helper::object_read+0x1af7f>
 29e7bb7:	mov    0x190(%rsp),%rsi
 29e7bbf:	mov    0x190(%rsp),%rdi
 29e7bc7:	call   2ae5540 <wasm[0]::function[1057]::helper::string_equality>
 29e7bcc:	jmp    29e7bd9 <wasm[0]::function[1015]::helper::object_read+0x6c59>
 29e7bd1:	mov    0x278(%rsp),%rax
 29e7bd9:	mov    0xa0(%rsp),%ebx
 29e7be0:	mov    0x130(%rsp),%r12d
 29e7be8:	mov    0xd8(%rsp),%r11d
 29e7bf0:	mov    0x110(%rsp),%edx
 29e7bf7:	mov    %rdx,0x198(%rsp)
 29e7bff:	mov    0x120(%rsp),%r14d
 29e7c07:	mov    0x88(%rsp),%esi
 29e7c0e:	mov    %rsi,0x1a0(%rsp)
 29e7c16:	mov    0x78(%rsp),%r15d
 29e7c1b:	mov    0x100(%rsp),%esi
 29e7c22:	mov    0xe0(%rsp),%edi
 29e7c29:	mov    0xc8(%rsp),%r8d
 29e7c31:	mov    0x118(%rsp),%r9d
 29e7c39:	test   %eax,%eax
 29e7c3b:	je     29e7c4e <wasm[0]::function[1015]::helper::object_read+0x6cce>
 29e7c41:	mov    0x218(%rsp),%rcx
 29e7c49:	jmp    29e7c71 <wasm[0]::function[1015]::helper::object_read+0x6cf1>
 29e7c4e:	mov    0x218(%rsp),%rcx
 29e7c56:	add    $0x1,%ecx
 29e7c5c:	mov    %rcx,0x218(%rsp)
 29e7c64:	mov    %rax,0x220(%rsp)
 29e7c6c:	jmp    29e795a <wasm[0]::function[1015]::helper::object_read+0x69da>
 29e7c71:	xor    %r13d,%r13d
 29e7c74:	xor    %rbx,%rbx
 29e7c77:	test   %eax,%eax
 29e7c79:	jne    29e7c94 <wasm[0]::function[1015]::helper::object_read+0x6d14>
 29e7c7f:	mov    %r13,0x230(%rsp)
 29e7c87:	mov    %rbx,0x238(%rsp)
 29e7c8f:	jmp    29e80da <wasm[0]::function[1015]::helper::object_read+0x715a>
 29e7c94:	test   %r11d,%r11d
 29e7c97:	je     29fbf01 <wasm[0]::function[1015]::helper::object_read+0x1af81>
 29e7c9d:	xor    %eax,%eax
 29e7c9f:	test   $0x1,%r11d
 29e7ca6:	jne    29e7ceb <wasm[0]::function[1015]::helper::object_read+0x6d6b>
 29e7cac:	mov    0x2e0(%rsp),%r12
 29e7cb4:	mov    0x28(%r12),%rax
 29e7cb9:	mov    0x20(%r12),%r10
 29e7cbe:	mov    %r11d,%ebx
 29e7cc1:	lea    0x4(%r10,%rbx,1),%r10
 29e7cc6:	xor    %r12,%r12
 29e7cc9:	cmp    %rax,%rbx
 29e7ccc:	cmova  %r12,%r10
 29e7cd0:	mov    (%r10),%eax
 29e7cd3:	mov    0x190(%rsp),%rdx
 29e7cdb:	mov    0x28(%rdx),%rdx
 29e7cdf:	cmp    0x160(%rdx),%eax
 29e7ce5:	sete   %al
 29e7ce8:	movzbl %al,%eax
 29e7ceb:	test   %eax,%eax
 29e7ced:	jne    29e7f50 <wasm[0]::function[1015]::helper::object_read+0x6fd0>
 29e7cf3:	xor    %r10d,%r10d
 29e7cf6:	test   $0x1,%r11d
 29e7cfd:	jne    29e7d43 <wasm[0]::function[1015]::helper::object_read+0x6dc3>
 29e7d03:	mov    0x2e0(%rsp),%r12
 29e7d0b:	mov    0x28(%r12),%rax
 29e7d10:	mov    0x20(%r12),%r10
 29e7d15:	mov    %r11d,%ebx
 29e7d18:	lea    0x4(%r10,%rbx,1),%r10
 29e7d1d:	xor    %r12,%r12
 29e7d20:	cmp    %rax,%rbx
 29e7d23:	cmova  %r12,%r10
 29e7d27:	mov    (%r10),%eax
 29e7d2a:	mov    0x190(%rsp),%rdx
 29e7d32:	mov    0x28(%rdx),%rdx
 29e7d36:	cmp    0x15c(%rdx),%eax
 29e7d3c:	sete   %al
 29e7d3f:	movzbl %al,%r10d
 29e7d43:	test   %r10d,%r10d
 29e7d46:	je     29fbf03 <wasm[0]::function[1015]::helper::object_read+0x1af83>
 29e7d4c:	test   %r11d,%r11d
 29e7d4f:	je     29fbf05 <wasm[0]::function[1015]::helper::object_read+0x1af85>
 29e7d55:	mov    0x2e0(%rsp),%r12
 29e7d5d:	mov    0x28(%r12),%r13
 29e7d62:	mov    0x20(%r12),%r12
 29e7d67:	mov    %r11d,%eax
 29e7d6a:	lea    (%r12,%rax,1),%r10
 29e7d6e:	xor    %rbx,%rbx
 29e7d71:	cmp    %r13,%rax
 29e7d74:	cmova  %rbx,%r10
 29e7d78:	mov    0x14(%r10),%r14d
 29e7d7c:	mov    0x18(%r10),%eax
 29e7d80:	mov    0x1c(%r10),%r11d
 29e7d84:	test   %r14d,%r14d
 29e7d87:	je     29fbf07 <wasm[0]::function[1015]::helper::object_read+0x1af87>
 29e7d8d:	test   %r14d,%r14d
 29e7d90:	je     29fbf09 <wasm[0]::function[1015]::helper::object_read+0x1af89>
 29e7d96:	mov    %r14d,%edx
 29e7d99:	lea    0x10(%r12,%rdx,1),%r10
 29e7d9e:	cmp    %r13,%rdx
 29e7da1:	cmova  %rbx,%r10
 29e7da5:	mov    (%r10),%r10d
 29e7da8:	cmp    %r10d,%ecx
 29e7dab:	jae    29fbf0b <wasm[0]::function[1015]::helper::object_read+0x1af8b>
 29e7db1:	mov    %r10d,%edx
 29e7db4:	shr    $0x20,%rdx
 29e7db8:	test   %rdx,%rdx
 29e7dbb:	jne    29fbf0d <wasm[0]::function[1015]::helper::object_read+0x1af8d>
 29e7dc1:	add    $0x14,%r10d
 29e7dc5:	jb     29fbf0f <wasm[0]::function[1015]::helper::object_read+0x1af8f>
 29e7dcb:	add    %r10d,%r14d
 29e7dce:	jb     29fbf11 <wasm[0]::function[1015]::helper::object_read+0x1af91>
 29e7dd4:	mov    %r14d,%edx
 29e7dd7:	add    %rdx,%r12
 29e7dda:	cmp    %r13,%rdx
 29e7ddd:	cmova  %rbx,%r12
 29e7de1:	lea    0x14(%rcx),%edx
 29e7de4:	sub    %edx,%r10d
 29e7de7:	sub    %r10,%r12
 29e7dea:	movzbq (%r12),%r10
 29e7def:	mov    %r10,0x220(%rsp)
 29e7df7:	test   %eax,%eax
 29e7df9:	je     29e7e8c <wasm[0]::function[1015]::helper::object_read+0x6f0c>
 29e7dff:	test   %eax,%eax
 29e7e01:	je     29fbf13 <wasm[0]::function[1015]::helper::object_read+0x1af93>
 29e7e07:	test   %eax,%eax
 29e7e09:	je     29fbf15 <wasm[0]::function[1015]::helper::object_read+0x1af95>
 29e7e0f:	mov    0x2e0(%rsp),%r12
 29e7e17:	mov    0x28(%r12),%rbx
 29e7e1c:	mov    0x20(%r12),%r12
 29e7e21:	mov    %eax,%r13d
 29e7e24:	lea    0x10(%r12,%r13,1),%r10
 29e7e29:	xor    %r14,%r14
 29e7e2c:	cmp    %rbx,%r13
 29e7e2f:	cmova  %r14,%r10
 29e7e33:	mov    (%r10),%r13d
 29e7e36:	cmp    %r13d,%ecx
 29e7e39:	jae    29fbf17 <wasm[0]::function[1015]::helper::object_read+0x1af97>
 29e7e3f:	mov    %r13d,%r10d
 29e7e42:	shl    $0x3,%r10
 29e7e46:	shr    $0x20,%r10
 29e7e4a:	test   %r10,%r10
 29e7e4d:	jne    29fbf19 <wasm[0]::function[1015]::helper::object_read+0x1af99>
 29e7e53:	shl    $0x3,%r13d
 29e7e57:	add    $0x18,%r13d
 29e7e5b:	jb     29fbf1b <wasm[0]::function[1015]::helper::object_read+0x1af9b>
 29e7e61:	add    %r13d,%eax
 29e7e64:	jb     29fbf1d <wasm[0]::function[1015]::helper::object_read+0x1af9d>
 29e7e6a:	mov    %eax,%edx
 29e7e6c:	lea    (%r12,%rdx,1),%rax
 29e7e70:	cmp    %rbx,%rdx
 29e7e73:	cmova  %r14,%rax
 29e7e77:	mov    %rcx,%rdx
 29e7e7a:	shl    $0x3,%edx
 29e7e7d:	add    $0x18,%edx
 29e7e83:	sub    %edx,%r13d
 29e7e86:	sub    %r13,%rax
 29e7e89:	mov    (%rax),%rbx
 29e7e8c:	xor    %r14d,%r14d
 29e7e8f:	test   %r11d,%r11d
 29e7e92:	jne    29e7ea5 <wasm[0]::function[1015]::helper::object_read+0x6f25>
 29e7e98:	mov    0x220(%rsp),%r10
 29e7ea0:	jmp    29e7f37 <wasm[0]::function[1015]::helper::object_read+0x6fb7>
 29e7ea5:	test   %r11d,%r11d
 29e7ea8:	je     29fbf1f <wasm[0]::function[1015]::helper::object_read+0x1af9f>
 29e7eae:	test   %r11d,%r11d
 29e7eb1:	je     29fbf21 <wasm[0]::function[1015]::helper::object_read+0x1afa1>
 29e7eb7:	mov    0x2e0(%rsp),%r12
 29e7ebf:	mov    0x28(%r12),%rax
 29e7ec4:	mov    0x20(%r12),%r12
 29e7ec9:	mov    %r11d,%r14d
 29e7ecc:	lea    0x10(%r12,%r14,1),%r10
 29e7ed1:	xor    %r13,%r13
 29e7ed4:	cmp    %rax,%r14
 29e7ed7:	cmova  %r13,%r10
 29e7edb:	mov    (%r10),%r14d
 29e7ede:	cmp    %r14d,%ecx
 29e7ee1:	jae    29fbf23 <wasm[0]::function[1015]::helper::object_read+0x1afa3>
 29e7ee7:	mov    %r14d,%r10d
 29e7eea:	shl    $0x2,%r10
 29e7eee:	shr    $0x20,%r10
 29e7ef2:	test   %r10,%r10
 29e7ef5:	jne    29fbf25 <wasm[0]::function[1015]::helper::object_read+0x1afa5>
 29e7efb:	shl    $0x2,%r14d
 29e7eff:	add    $0x14,%r14d
 29e7f03:	jb     29fbf27 <wasm[0]::function[1015]::helper::object_read+0x1afa7>
 29e7f09:	add    %r14d,%r11d
 29e7f0c:	jb     29fbf29 <wasm[0]::function[1015]::helper::object_read+0x1afa9>
 29e7f12:	mov    %r11d,%edx
 29e7f15:	lea    (%r12,%rdx,1),%r10
 29e7f19:	cmp    %rax,%rdx
 29e7f1c:	cmova  %r13,%r10
 29e7f20:	shl    $0x2,%ecx
 29e7f23:	lea    0x14(%rcx),%eax
 29e7f26:	sub    %eax,%r14d
 29e7f29:	sub    %r14,%r10
 29e7f2c:	mov    (%r10),%r14d
 29e7f2f:	mov    0x220(%rsp),%r10
 29e7f37:	movzbl %r10b,%r13d
 29e7f3b:	mov    %r13,0x230(%rsp)
 29e7f43:	mov    %rbx,0x238(%rsp)
 29e7f4b:	jmp    29e80da <wasm[0]::function[1015]::helper::object_read+0x715a>
 29e7f50:	xor    %eax,%eax
 29e7f52:	test   $0x1,%r11d
 29e7f59:	jne    29e7f9e <wasm[0]::function[1015]::helper::object_read+0x701e>
 29e7f5f:	mov    0x2e0(%rsp),%r12
 29e7f67:	mov    0x28(%r12),%rax
 29e7f6c:	mov    0x20(%r12),%rdx
 29e7f71:	mov    %r11d,%ebx
 29e7f74:	lea    0x4(%rdx,%rbx,1),%r10
 29e7f79:	xor    %r12,%r12
 29e7f7c:	cmp    %rax,%rbx
 29e7f7f:	cmova  %r12,%r10
 29e7f83:	mov    (%r10),%eax
 29e7f86:	mov    0x190(%rsp),%rdx
 29e7f8e:	mov    0x28(%rdx),%rdx
 29e7f92:	cmp    0x160(%rdx),%eax
 29e7f98:	sete   %al
 29e7f9b:	movzbl %al,%eax
 29e7f9e:	test   %eax,%eax
 29e7fa0:	je     29fbf2b <wasm[0]::function[1015]::helper::object_read+0x1afab>
 29e7fa6:	test   %r11d,%r11d
 29e7fa9:	je     29fbf2d <wasm[0]::function[1015]::helper::object_read+0x1afad>
 29e7faf:	mov    0x2e0(%rsp),%r12
 29e7fb7:	mov    0x28(%r12),%rbx
 29e7fbc:	mov    0x20(%r12),%r12
 29e7fc1:	mov    %r11d,%eax
 29e7fc4:	lea    (%r12,%rax,1),%r10
 29e7fc8:	xor    %r11,%r11
 29e7fcb:	cmp    %rbx,%rax
 29e7fce:	cmova  %r11,%r10
 29e7fd2:	mov    0x10(%r10),%r10d
 29e7fd6:	test   %r10d,%r10d
 29e7fd9:	je     29fbf2f <wasm[0]::function[1015]::helper::object_read+0x1afaf>
 29e7fdf:	test   %r10d,%r10d
 29e7fe2:	je     29fbf31 <wasm[0]::function[1015]::helper::object_read+0x1afb1>
 29e7fe8:	mov    %r10d,%edx
 29e7feb:	lea    (%r12,%rdx,1),%r10
 29e7fef:	cmp    %rbx,%rdx
 29e7ff2:	cmova  %r11,%r10
 29e7ff6:	mov    0x10(%r10),%r10d
 29e7ffa:	test   %r10d,%r10d
 29e7ffd:	je     29fbf33 <wasm[0]::function[1015]::helper::object_read+0x1afb3>
 29e8003:	test   %r10d,%r10d
 29e8006:	je     29fbf35 <wasm[0]::function[1015]::helper::object_read+0x1afb5>
 29e800c:	mov    %r10d,%edx
 29e800f:	lea    0x10(%r12,%rdx,1),%r10
 29e8014:	cmp    %rbx,%rdx
 29e8017:	cmova  %r11,%r10
 29e801b:	cmp    (%r10),%ecx
 29e801e:	setae  %r10b
 29e8022:	cmp    $0x2,%ecx
 29e8025:	setae  %r11b
 29e8029:	or     %r11d,%r10d
 29e802c:	test   %r10b,%r10b
 29e802f:	jne    29fbf37 <wasm[0]::function[1015]::helper::object_read+0x1afb7>
 29e8035:	mov    0x2e0(%rsp),%r12
 29e803d:	mov    0x28(%r12),%r11
 29e8042:	mov    %rax,%r10
 29e8045:	add    0x20(%r12),%r10
 29e804a:	xor    %r12,%r12
 29e804d:	cmp    %r11,%rax
 29e8050:	cmova  %r12,%r10
 29e8054:	mov    0x14(%r10),%r13d
 29e8058:	test   %ecx,%ecx
 29e805a:	je     29e8095 <wasm[0]::function[1015]::helper::object_read+0x7115>
 29e8060:	mov    0x2e0(%rsp),%r12
 29e8068:	mov    0x28(%r12),%r11
 29e806d:	mov    0x20(%r12),%rdx
 29e8072:	lea    (%rdx,%rax,1),%r10
 29e8076:	xor    %r12,%r12
 29e8079:	cmp    %r11,%rax
 29e807c:	cmova  %r12,%r10
 29e8080:	mov    0x20(%r10),%rbx
 29e8084:	mov    0x2c(%r10),%r14d
 29e8088:	mov    %rbx,0x238(%rsp)
 29e8090:	jmp    29e80c5 <wasm[0]::function[1015]::helper::object_read+0x7145>
 29e8095:	mov    0x2e0(%rsp),%r12
 29e809d:	mov    0x28(%r12),%r10
 29e80a2:	mov    0x20(%r12),%rdx
 29e80a7:	lea    (%rdx,%rax,1),%r11
 29e80ab:	xor    %r14,%r14
 29e80ae:	cmp    %r10,%rax
 29e80b1:	cmova  %r14,%r11
 29e80b5:	mov    0x18(%r11),%rbx
 29e80b9:	mov    %rbx,0x238(%rsp)
 29e80c1:	mov    0x28(%r11),%r14d
 29e80c5:	shl    $0x3,%ecx
 29e80c8:	shr    %cl,%r13d
 29e80cb:	and    $0xff,%r13d
 29e80d2:	mov    %r13,0x230(%rsp)
 29e80da:	mov    0x198(%rsp),%rdx
 29e80e2:	mov    %edx,0x100(%rsp)
 29e80e9:	mov    %r14d,0x78(%rsp)
 29e80ee:	mov    0x1a0(%rsp),%rax
 29e80f6:	mov    %eax,0x88(%rsp)
 29e80fd:	mov    %r15d,0x120(%rsp)
 29e8105:	mov    %esi,0x110(%rsp)
 29e810c:	mov    %edi,0xd8(%rsp)
 29e8113:	mov    %r8d,0x130(%rsp)
 29e811b:	mov    %r9d,0xa0(%rsp)
 29e8123:	mov    $0x27b,%edx
 29e8128:	mov    0x190(%rsp),%rsi
 29e8130:	mov    0x190(%rsp),%rdi
 29e8138:	call   2f30600 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 29e813d:	mov    %eax,0xe0(%rsp)
 29e8144:	mov    %rsi,%rcx
 29e8147:	xor    %ecx,%ecx
 29e8149:	mov    %rcx,0x270(%rsp)
 29e8151:	test   %eax,%eax
 29e8153:	je     29fbf39 <wasm[0]::function[1015]::helper::object_read+0x1afb9>
 29e8159:	movl   $0x0,0xc8(%rsp)
 29e8164:	mov    0x100(%rsp),%edx
 29e816b:	mov    %rdx,0x1a0(%rsp)
 29e8173:	mov    0x78(%rsp),%esi
 29e8177:	mov    %rsi,0x1c8(%rsp)
 29e817f:	mov    0x88(%rsp),%edi
 29e8186:	mov    %rdi,0x1d0(%rsp)
 29e818e:	mov    0x120(%rsp),%edi
 29e8195:	mov    0x110(%rsp),%eax
 29e819c:	mov    0xd8(%rsp),%r8d
 29e81a4:	mov    0x130(%rsp),%r9d
 29e81ac:	mov    0xa0(%rsp),%r10d
 29e81b4:	xor    %r15,%r15
 29e81b7:	mov    0x2a0(%rsp),%rcx
 29e81bf:	mov    0x2a0(%rsp),%rdx
 29e81c7:	test   %dl,%cl
 29e81c9:	jne    29e81fc <wasm[0]::function[1015]::helper::object_read+0x727c>
 29e81cf:	mov    0x1a0(%rsp),%rdx
 29e81d7:	mov    0x270(%rsp),%r14
 29e81df:	mov    %r15,0x250(%rsp)
 29e81e7:	mov    0x270(%rsp),%rcx
 29e81ef:	mov    %rcx,0x258(%rsp)
 29e81f7:	jmp    29e8ef9 <wasm[0]::function[1015]::helper::object_read+0x7f79>
 29e81fc:	mov    0x100(%rsp),%r8d
 29e8204:	mov    0x2b0(%rsp),%rcx
 29e820c:	mov    0x2a8(%rsp),%rdx
 29e8214:	mov    0x190(%rsp),%rsi
 29e821c:	mov    0x190(%rsp),%rdi
 29e8224:	call   2a5f680 <wasm[0]::function[1039]::helper::object_header_projection>
 29e8229:	mov    %eax,0x118(%rsp)
 29e8230:	test   %eax,%eax
 29e8232:	je     29fbf3b <wasm[0]::function[1015]::helper::object_read+0x1afbb>
 29e8238:	test   %eax,%eax
 29e823a:	je     29fbf3d <wasm[0]::function[1015]::helper::object_read+0x1afbd>
 29e8240:	mov    0x2e0(%rsp),%r12
 29e8248:	mov    0x28(%r12),%rcx
 29e824d:	mov    0x20(%r12),%rsi
 29e8252:	mov    %eax,%edx
 29e8254:	lea    (%rsi,%rdx,1),%rax
 29e8258:	xor    %rsi,%rsi
 29e825b:	cmp    %rcx,%rdx
 29e825e:	cmova  %rsi,%rax
 29e8262:	mov    0x14(%rax),%eax
 29e8265:	mov    %eax,0x138(%rsp)
 29e826c:	test   %eax,%eax
 29e826e:	je     29fbf3f <wasm[0]::function[1015]::helper::object_read+0x1afbf>
 29e8274:	mov    0x138(%rsp),%ecx
 29e827b:	xor    %eax,%eax
 29e827d:	test   $0x1,%ecx
 29e8283:	jne    29e82dd <wasm[0]::function[1015]::helper::object_read+0x735d>
 29e8289:	mov    0x2e0(%rsp),%r12
 29e8291:	mov    0x28(%r12),%rax
 29e8296:	mov    0x20(%r12),%rsi
 29e829b:	mov    %ecx,%edx
 29e829d:	lea    0x4(%rsi,%rdx,1),%rcx
 29e82a2:	xor    %rsi,%rsi
 29e82a5:	cmp    %rax,%rdx
 29e82a8:	cmova  %rsi,%rcx
 29e82ac:	mov    (%rcx),%esi
 29e82ae:	mov    0x190(%rsp),%rcx
 29e82b6:	mov    0x28(%rcx),%rax
 29e82ba:	mov    0x158(%rax),%edx
 29e82c0:	cmp    %edx,%esi
 29e82c2:	sete   %al
 29e82c5:	movzbl %al,%eax
 29e82c8:	cmp    %edx,%esi
 29e82ca:	je     29e82dd <wasm[0]::function[1015]::helper::object_read+0x735d>
 29e82d0:	mov    0x190(%rsp),%rdi
 29e82d8:	call   3018cd5 <wasmtime_builtin_is_subtype>
 29e82dd:	test   %eax,%eax
 29e82df:	jne    29e85a3 <wasm[0]::function[1015]::helper::object_read+0x7623>
 29e82e5:	mov    0x118(%rsp),%edx
 29e82ec:	xor    %ebx,%ebx
 29e82ee:	test   %edx,%edx
 29e82f0:	je     29fbf41 <wasm[0]::function[1015]::helper::object_read+0x1afc1>
 29e82f6:	mov    0xe0(%rsp),%r9d
 29e82fe:	mov    $0x4,%ecx
 29e8303:	xor    %r8,%r8
 29e8306:	mov    0x190(%rsp),%rsi
 29e830e:	mov    0x190(%rsp),%rdi
 29e8316:	call   2a58e80 <wasm[0]::function[1032]::helper::ordinary_property_find>
 29e831b:	test   %eax,%eax
 29e831d:	je     29e8357 <wasm[0]::function[1015]::helper::object_read+0x73d7>
 29e8323:	test   %eax,%eax
 29e8325:	je     29fbf43 <wasm[0]::function[1015]::helper::object_read+0x1afc3>
 29e832b:	test   %eax,%eax
 29e832d:	je     29fbf45 <wasm[0]::function[1015]::helper::object_read+0x1afc5>
 29e8333:	mov    0x2e0(%rsp),%r12
 29e833b:	mov    0x28(%r12),%rsi
 29e8340:	mov    %eax,%edi
 29e8342:	mov    %rdi,%rax
 29e8345:	add    0x20(%r12),%rax
 29e834a:	xor    %r8,%r8
 29e834d:	cmp    %rsi,%rdi
 29e8350:	cmova  %r8,%rax
 29e8354:	mov    0x14(%rax),%ebx
 29e8357:	mov    0xc8(%rsp),%r14d
 29e835f:	mov    %rax,%rsi
 29e8362:	mov    %rax,0x270(%rsp)
 29e836a:	xor    %esi,%eax
 29e836c:	mov    %rax,0x270(%rsp)
 29e8374:	xor    %r15,%r15
 29e8377:	test   %ebx,%ebx
 29e8379:	jne    29e838c <wasm[0]::function[1015]::helper::object_read+0x740c>
 29e837f:	mov    0x270(%rsp),%rbx
 29e8387:	jmp    29e853e <wasm[0]::function[1015]::helper::object_read+0x75be>
 29e838c:	test   %ebx,%ebx
 29e838e:	je     29fbf47 <wasm[0]::function[1015]::helper::object_read+0x1afc7>
 29e8394:	mov    0x2e0(%rsp),%r12
 29e839c:	mov    0x28(%r12),%r10
 29e83a1:	mov    0x20(%r12),%rax
 29e83a6:	mov    %ebx,%r11d
 29e83a9:	lea    (%rax,%r11,1),%rdi
 29e83ad:	xor    %r15,%r15
 29e83b0:	cmp    %r10,%r11
 29e83b3:	cmova  %r15,%rdi
 29e83b7:	mov    0x10(%rdi),%r11d
 29e83bb:	mov    0xc8(%rsp),%r14d
 29e83c3:	mov    %rax,%rcx
 29e83c6:	mov    %rax,0x270(%rsp)
 29e83ce:	xor    %ecx,%eax
 29e83d0:	mov    %rax,0x270(%rsp)
 29e83d8:	test   $0x1,%r11d
 29e83df:	je     29e83f2 <wasm[0]::function[1015]::helper::object_read+0x7472>
 29e83e5:	mov    0x270(%rsp),%rbx
 29e83ed:	jmp    29e853e <wasm[0]::function[1015]::helper::object_read+0x75be>
 29e83f2:	mov    0x14(%rdi),%edx
 29e83f5:	test   %edx,%edx
 29e83f7:	je     29fbf49 <wasm[0]::function[1015]::helper::object_read+0x1afc9>
 29e83fd:	xor    %eax,%eax
 29e83ff:	test   $0x1,%edx
 29e8405:	jne    29e8448 <wasm[0]::function[1015]::helper::object_read+0x74c8>
 29e840b:	mov    0x2e0(%rsp),%r12
 29e8413:	mov    0x28(%r12),%rax
 29e8418:	mov    0x20(%r12),%rcx
 29e841d:	mov    %edx,%esi
 29e841f:	lea    0x4(%rcx,%rsi,1),%rcx
 29e8424:	xor    %rdi,%rdi
 29e8427:	cmp    %rax,%rsi
 29e842a:	cmova  %rdi,%rcx
 29e842e:	mov    (%rcx),%eax
 29e8430:	mov    0x190(%rsp),%rcx
 29e8438:	mov    0x28(%rcx),%rcx
 29e843c:	cmp    0x120(%rcx),%eax
 29e8442:	sete   %al
 29e8445:	movzbl %al,%eax
 29e8448:	test   %eax,%eax
 29e844a:	jne    29e84a7 <wasm[0]::function[1015]::helper::object_read+0x7527>
 29e8450:	mov    0x190(%rsp),%rsi
 29e8458:	mov    0x190(%rsp),%rdi
 29e8460:	call   2a01c00 <wasm[0]::function[1024]::helper::property_value_resolve>
 29e8465:	test   %eax,%eax
 29e8467:	je     29fbf4b <wasm[0]::function[1015]::helper::object_read+0x1afcb>
 29e846d:	test   %eax,%eax
 29e846f:	je     29fbf4d <wasm[0]::function[1015]::helper::object_read+0x1afcd>
 29e8475:	mov    0x2e0(%rsp),%r12
 29e847d:	mov    0x28(%r12),%rcx
 29e8482:	mov    0x20(%r12),%rsi
 29e8487:	mov    %eax,%edx
 29e8489:	lea    (%rsi,%rdx,1),%rax
 29e848d:	xor    %rsi,%rsi
 29e8490:	cmp    %rcx,%rdx
 29e8493:	cmova  %rsi,%rax
 29e8497:	mov    0x18(%rax),%ebx
 29e849a:	mov    0x10(%rax),%r15
 29e849e:	mov    0x1c(%rax),%r14d
 29e84a2:	jmp    29e852e <wasm[0]::function[1015]::helper::object_read+0x75ae>
 29e84a7:	xor    %eax,%eax
 29e84a9:	test   $0x1,%edx
 29e84af:	jne    29e84f2 <wasm[0]::function[1015]::helper::object_read+0x7572>
 29e84b5:	mov    0x2e0(%rsp),%r12
 29e84bd:	mov    0x28(%r12),%rax
 29e84c2:	mov    0x20(%r12),%rcx
 29e84c7:	mov    %edx,%esi
 29e84c9:	lea    0x4(%rcx,%rsi,1),%rcx
 29e84ce:	xor    %rdi,%rdi
 29e84d1:	cmp    %rax,%rsi
 29e84d4:	cmova  %rdi,%rcx
 29e84d8:	mov    (%rcx),%eax
 29e84da:	mov    0x190(%rsp),%rcx
 29e84e2:	mov    0x28(%rcx),%rcx
 29e84e6:	cmp    0x120(%rcx),%eax
 29e84ec:	sete   %al
 29e84ef:	movzbl %al,%eax
 29e84f2:	test   %eax,%eax
 29e84f4:	je     29fbf4f <wasm[0]::function[1015]::helper::object_read+0x1afcf>
 29e84fa:	test   %edx,%edx
 29e84fc:	je     29fbf51 <wasm[0]::function[1015]::helper::object_read+0x1afd1>
 29e8502:	mov    0x2e0(%rsp),%r12
 29e850a:	mov    0x28(%r12),%rcx
 29e850f:	mov    0x20(%r12),%rax
 29e8514:	mov    %edx,%edx
 29e8516:	add    %rdx,%rax
 29e8519:	xor    %rsi,%rsi
 29e851c:	cmp    %rcx,%rdx
 29e851f:	cmova  %rsi,%rax
 29e8523:	mov    0x18(%rax),%ebx
 29e8526:	mov    0x10(%rax),%r15
 29e852a:	mov    0x1c(%rax),%r14d
 29e852e:	mov    0x278(%rsp),%rax
 29e8536:	mov    %rax,0x270(%rsp)
 29e853e:	mov    0x100(%rsp),%edx
 29e8545:	mov    %rdx,0x1a0(%rsp)
 29e854d:	mov    0x78(%rsp),%esi
 29e8551:	mov    %rsi,0x1c8(%rsp)
 29e8559:	mov    0x88(%rsp),%edi
 29e8560:	mov    %rdi,0x1d0(%rsp)
 29e8568:	mov    0x120(%rsp),%edi
 29e856f:	mov    0x110(%rsp),%eax
 29e8576:	mov    0xd8(%rsp),%r8d
 29e857e:	mov    0x130(%rsp),%r9d
 29e8586:	mov    0xa0(%rsp),%r10d
 29e858e:	mov    %r15,0x250(%rsp)
 29e8596:	mov    %rbx,0x258(%rsp)
 29e859e:	jmp    29e8ef1 <wasm[0]::function[1015]::helper::object_read+0x7f71>
 29e85a3:	mov    0x138(%rsp),%eax
 29e85aa:	test   %eax,%eax
 29e85ac:	je     29fbf53 <wasm[0]::function[1015]::helper::object_read+0x1afd3>
 29e85b2:	mov    0x138(%rsp),%ecx
 29e85b9:	xor    %eax,%eax
 29e85bb:	test   $0x1,%ecx
 29e85c1:	jne    29e861b <wasm[0]::function[1015]::helper::object_read+0x769b>
 29e85c7:	mov    0x2e0(%rsp),%r12
 29e85cf:	mov    0x28(%r12),%rax
 29e85d4:	mov    0x20(%r12),%rsi
 29e85d9:	mov    %ecx,%edx
 29e85db:	lea    0x4(%rsi,%rdx,1),%rcx
 29e85e0:	xor    %rsi,%rsi
 29e85e3:	cmp    %rax,%rdx
 29e85e6:	cmova  %rsi,%rcx
 29e85ea:	mov    (%rcx),%esi
 29e85ec:	mov    0x190(%rsp),%rcx
 29e85f4:	mov    0x28(%rcx),%rax
 29e85f8:	mov    0x158(%rax),%edx
 29e85fe:	cmp    %edx,%esi
 29e8600:	sete   %al
 29e8603:	movzbl %al,%eax
 29e8606:	cmp    %edx,%esi
 29e8608:	je     29e861b <wasm[0]::function[1015]::helper::object_read+0x769b>
 29e860e:	mov    0x190(%rsp),%rdi
 29e8616:	call   3018cd5 <wasmtime_builtin_is_subtype>
 29e861b:	test   %eax,%eax
 29e861d:	je     29fbf55 <wasm[0]::function[1015]::helper::object_read+0x1afd5>
 29e8623:	mov    0x138(%rsp),%r13d
 29e862b:	mov    0x100(%rsp),%edx
 29e8632:	mov    %rdx,0x1a0(%rsp)
 29e863a:	mov    0x78(%rsp),%esi
 29e863e:	mov    %rsi,0x1c8(%rsp)
 29e8646:	mov    0x88(%rsp),%edi
 29e864d:	mov    %rdi,0x1d0(%rsp)
 29e8655:	mov    0xc8(%rsp),%r14d
 29e865d:	mov    0x120(%rsp),%edi
 29e8664:	mov    0x110(%rsp),%eax
 29e866b:	mov    0xd8(%rsp),%r8d
 29e8673:	mov    0x130(%rsp),%r9d
 29e867b:	mov    0xa0(%rsp),%r10d
 29e8683:	xor    %ecx,%ecx
 29e8685:	mov    %rcx,0x208(%rsp)
 29e868d:	test   %r13d,%r13d
 29e8690:	je     29fbf57 <wasm[0]::function[1015]::helper::object_read+0x1afd7>
 29e8696:	test   %r13d,%r13d
 29e8699:	je     29fbf59 <wasm[0]::function[1015]::helper::object_read+0x1afd9>
 29e869f:	mov    0x2e0(%rsp),%r12
 29e86a7:	mov    0x28(%r12),%r11
 29e86ac:	mov    0x20(%r12),%rcx
 29e86b1:	mov    %r13d,%r15d
 29e86b4:	lea    (%rcx,%r15,1),%rdx
 29e86b8:	xor    %r12,%r12
 29e86bb:	cmp    %r11,%r15
 29e86be:	cmova  %r12,%rdx
 29e86c2:	mov    0x10(%rdx),%edx
 29e86c5:	test   %edx,%edx
 29e86c7:	je     29fbf5b <wasm[0]::function[1015]::helper::object_read+0x1afdb>
 29e86cd:	test   %edx,%edx
 29e86cf:	je     29fbf5d <wasm[0]::function[1015]::helper::object_read+0x1afdd>
 29e86d5:	mov    %edx,%r15d
 29e86d8:	lea    (%rcx,%r15,1),%rdx
 29e86dc:	cmp    %r11,%r15
 29e86df:	cmova  %r12,%rdx
 29e86e3:	mov    0x10(%rdx),%r15d
 29e86e7:	test   %r15d,%r15d
 29e86ea:	je     29fbf5f <wasm[0]::function[1015]::helper::object_read+0x1afdf>
 29e86f0:	test   %r15d,%r15d
 29e86f3:	je     29fbf61 <wasm[0]::function[1015]::helper::object_read+0x1afe1>
 29e86f9:	mov    %r15d,%edx
 29e86fc:	lea    0x10(%rcx,%rdx,1),%rcx
 29e8701:	cmp    %r11,%rdx
 29e8704:	cmova  %r12,%rcx
 29e8708:	mov    (%rcx),%ebx
 29e870a:	mov    %rbx,0x218(%rsp)
 29e8712:	mov    0xe0(%rsp),%r11d
 29e871a:	mov    0x190(%rsp),%rcx
 29e8722:	mov    0x28(%rcx),%rcx
 29e8726:	mov    0x234(%rcx),%ebx
 29e872c:	mov    0x208(%rsp),%rcx
 29e8734:	mov    %rcx,0x270(%rsp)
 29e873c:	mov    %r15d,0x118(%rsp)
 29e8744:	mov    %r11d,0xa0(%rsp)
 29e874c:	mov    %r13d,0x130(%rsp)
 29e8754:	mov    0x1a0(%rsp),%rdx
 29e875c:	mov    %edx,0xd8(%rsp)
 29e8763:	mov    0x1c8(%rsp),%rsi
 29e876b:	mov    %esi,0x110(%rsp)
 29e8772:	mov    0x1d0(%rsp),%rcx
 29e877a:	mov    %ecx,0x120(%rsp)
 29e8781:	mov    %r14d,0xc8(%rsp)
 29e8789:	mov    %edi,0x88(%rsp)
 29e8790:	mov    %eax,0x78(%rsp)
 29e8794:	mov    %r8d,0x100(%rsp)
 29e879c:	mov    %r9d,0x138(%rsp)
 29e87a4:	mov    %r10d,0xe0(%rsp)
 29e87ac:	mov    0x2e8(%rsp),%r13
 29e87b4:	mov    0x0(%r13),%rax
 29e87b8:	mov    0x228(%rsp),%rcx
 29e87c0:	cmp    %rcx,%rax
 29e87c3:	jae    29faa84 <wasm[0]::function[1015]::helper::object_read+0x19b04>
 29e87c9:	mov    0x130(%rsp),%r13d
 29e87d1:	mov    0xd8(%rsp),%edx
 29e87d8:	mov    %rdx,0x1a0(%rsp)
 29e87e0:	mov    0x110(%rsp),%esi
 29e87e7:	mov    %rsi,0x1c8(%rsp)
 29e87ef:	mov    0x120(%rsp),%edi
 29e87f6:	mov    %rdi,0x1d0(%rsp)
 29e87fe:	mov    0xc8(%rsp),%r14d
 29e8806:	mov    0x88(%rsp),%edi
 29e880d:	mov    0x78(%rsp),%eax
 29e8811:	mov    0x100(%rsp),%r8d
 29e8819:	mov    0x138(%rsp),%r9d
 29e8821:	mov    0xe0(%rsp),%r10d
 29e8829:	mov    0x208(%rsp),%rcx
 29e8831:	mov    0x218(%rsp),%rdx
 29e8839:	cmp    %edx,%ecx
 29e883b:	jae    29e8a8c <wasm[0]::function[1015]::helper::object_read+0x7b0c>
 29e8841:	mov    0x118(%rsp),%eax
 29e8848:	test   %eax,%eax
 29e884a:	je     29fbf63 <wasm[0]::function[1015]::helper::object_read+0x1afe3>
 29e8850:	test   %eax,%eax
 29e8852:	je     29fbf65 <wasm[0]::function[1015]::helper::object_read+0x1afe5>
 29e8858:	mov    0x2e0(%rsp),%r12
 29e8860:	mov    0x28(%r12),%rdx
 29e8865:	mov    0x20(%r12),%rsi
 29e886a:	mov    %eax,%r9d
 29e886d:	lea    0x10(%rsi,%r9,1),%r8
 29e8872:	xor    %rdi,%rdi
 29e8875:	cmp    %rdx,%r9
 29e8878:	cmova  %rdi,%r8
 29e887c:	mov    (%r8),%r8d
 29e887f:	cmp    %r8d,%ecx
 29e8882:	jae    29fbf67 <wasm[0]::function[1015]::helper::object_read+0x1afe7>
 29e8888:	mov    %r8d,%r9d
 29e888b:	shl    $0x2,%r9
 29e888f:	shr    $0x20,%r9
 29e8893:	test   %r9,%r9
 29e8896:	jne    29fbf69 <wasm[0]::function[1015]::helper::object_read+0x1afe9>
 29e889c:	shl    $0x2,%r8d
 29e88a0:	add    $0x14,%r8d
 29e88a4:	jb     29fbf6b <wasm[0]::function[1015]::helper::object_read+0x1afeb>
 29e88aa:	add    %r8d,%eax
 29e88ad:	jb     29fbf6d <wasm[0]::function[1015]::helper::object_read+0x1afed>
 29e88b3:	mov    %eax,%r9d
 29e88b6:	lea    (%rsi,%r9,1),%rax
 29e88ba:	cmp    %rdx,%r9
 29e88bd:	cmova  %rdi,%rax
 29e88c1:	mov    %rcx,%rdx
 29e88c4:	shl    $0x2,%edx
 29e88c7:	mov    %rcx,0x208(%rsp)
 29e88cf:	lea    0x14(%rdx),%ecx
 29e88d2:	sub    %ecx,%r8d
 29e88d5:	sub    %r8,%rax
 29e88d8:	mov    (%rax),%edx
 29e88da:	test   %edx,%edx
 29e88dc:	je     29fbf6f <wasm[0]::function[1015]::helper::object_read+0x1afef>
 29e88e2:	mov    0xa0(%rsp),%eax
 29e88e9:	cmp    %eax,%edx
 29e88eb:	je     29e89cc <wasm[0]::function[1015]::helper::object_read+0x7a4c>
 29e88f1:	xor    %ecx,%ecx
 29e88f3:	test   %edx,%edx
 29e88f5:	je     29e8938 <wasm[0]::function[1015]::helper::object_read+0x79b8>
 29e88fb:	xor    %ecx,%ecx
 29e88fd:	test   $0x1,%edx
 29e8903:	jne    29e8938 <wasm[0]::function[1015]::helper::object_read+0x79b8>
 29e8909:	mov    0x2e0(%rsp),%r12
 29e8911:	mov    0x28(%r12),%rcx
 29e8916:	mov    0x20(%r12),%rsi
 29e891b:	mov    %edx,%edi
 29e891d:	lea    0x4(%rsi,%rdi,1),%rsi
 29e8922:	xor    %r8,%r8
 29e8925:	cmp    %rcx,%rdi
 29e8928:	cmova  %r8,%rsi
 29e892c:	mov    (%rsi),%ecx
 29e892e:	cmp    %ebx,%ecx
 29e8930:	sete   %sil
 29e8934:	movzbl %sil,%ecx
 29e8938:	test   %ecx,%ecx
 29e893a:	je     29fbf71 <wasm[0]::function[1015]::helper::object_read+0x1aff1>
 29e8940:	xor    %ecx,%ecx
 29e8942:	test   %eax,%eax
 29e8944:	je     29e8990 <wasm[0]::function[1015]::helper::object_read+0x7a10>
 29e894a:	mov    0xa0(%rsp),%r8d
 29e8952:	xor    %ecx,%ecx
 29e8954:	test   $0x1,%r8d
 29e895b:	jne    29e8990 <wasm[0]::function[1015]::helper::object_read+0x7a10>
 29e8961:	mov    0x2e0(%rsp),%r12
 29e8969:	mov    0x28(%r12),%r11
 29e896e:	mov    0x20(%r12),%rcx
 29e8973:	mov    %r8d,%eax
 29e8976:	lea    0x4(%rcx,%rax,1),%r8
 29e897b:	xor    %rcx,%rcx
 29e897e:	cmp    %r11,%rax
 29e8981:	cmova  %rcx,%r8
 29e8985:	mov    (%r8),%eax
 29e8988:	cmp    %ebx,%eax
 29e898a:	sete   %al
 29e898d:	movzbl %al,%ecx
 29e8990:	test   %ecx,%ecx
 29e8992:	je     29fbf73 <wasm[0]::function[1015]::helper::object_read+0x1aff3>
 29e8998:	mov    0xa0(%rsp),%ecx
 29e899f:	xor    %r8d,%r8d
 29e89a2:	test   %ecx,%ecx
 29e89a4:	je     29fbf75 <wasm[0]::function[1015]::helper::object_read+0x1aff5>
 29e89aa:	mov    0x190(%rsp),%rsi
 29e89b2:	mov    0x190(%rsp),%rdi
 29e89ba:	call   2ae5540 <wasm[0]::function[1057]::helper::string_equality>
 29e89bf:	mov    %rax,0x270(%rsp)
 29e89c7:	jmp    29e89dc <wasm[0]::function[1015]::helper::object_read+0x7a5c>
 29e89cc:	mov    0x278(%rsp),%rax
 29e89d4:	mov    %rax,0x270(%rsp)
 29e89dc:	mov    0x118(%rsp),%r15d
 29e89e4:	mov    0xa0(%rsp),%r11d
 29e89ec:	mov    0x130(%rsp),%r13d
 29e89f4:	mov    0xd8(%rsp),%edx
 29e89fb:	mov    %rdx,0x1a0(%rsp)
 29e8a03:	mov    0x110(%rsp),%esi
 29e8a0a:	mov    %rsi,0x1c8(%rsp)
 29e8a12:	mov    0x120(%rsp),%edi
 29e8a19:	mov    %rdi,0x1d0(%rsp)
 29e8a21:	mov    0xc8(%rsp),%r14d
 29e8a29:	mov    0x88(%rsp),%edi
 29e8a30:	mov    0x78(%rsp),%eax
 29e8a34:	mov    0x100(%rsp),%r8d
 29e8a3c:	mov    0x138(%rsp),%r9d
 29e8a44:	mov    0xe0(%rsp),%r10d
 29e8a4c:	mov    0x270(%rsp),%rcx
 29e8a54:	mov    0x270(%rsp),%rdx
 29e8a5c:	test   %edx,%ecx
 29e8a5e:	je     29e8a71 <wasm[0]::function[1015]::helper::object_read+0x7af1>
 29e8a64:	mov    0x208(%rsp),%rcx
 29e8a6c:	jmp    29e8a8c <wasm[0]::function[1015]::helper::object_read+0x7b0c>
 29e8a71:	mov    0x208(%rsp),%rcx
 29e8a79:	add    $0x1,%ecx
 29e8a7f:	mov    %rcx,0x208(%rsp)
 29e8a87:	jmp    29e873c <wasm[0]::function[1015]::helper::object_read+0x77bc>
 29e8a8c:	xor    %r15,%r15
 29e8a8f:	xor    %ebx,%ebx
 29e8a91:	mov    0x270(%rsp),%rdx
 29e8a99:	mov    0x270(%rsp),%rsi
 29e8aa1:	test   %esi,%edx
 29e8aa3:	jne    29e8abe <wasm[0]::function[1015]::helper::object_read+0x7b3e>
 29e8aa9:	mov    %r15,0x250(%rsp)
 29e8ab1:	mov    %rbx,0x258(%rsp)
 29e8ab9:	jmp    29e8ef1 <wasm[0]::function[1015]::helper::object_read+0x7f71>
 29e8abe:	test   %r13d,%r13d
 29e8ac1:	je     29fbf77 <wasm[0]::function[1015]::helper::object_read+0x1aff7>
 29e8ac7:	xor    %edx,%edx
 29e8ac9:	test   $0x1,%r13d
 29e8ad0:	jne    29e8b15 <wasm[0]::function[1015]::helper::object_read+0x7b95>
 29e8ad6:	mov    0x2e0(%rsp),%r12
 29e8ade:	mov    0x28(%r12),%rdx
 29e8ae3:	mov    0x20(%r12),%r11
 29e8ae8:	mov    %r13d,%ebx
 29e8aeb:	lea    0x4(%r11,%rbx,1),%r11
 29e8af0:	xor    %r12,%r12
 29e8af3:	cmp    %rdx,%rbx
 29e8af6:	cmova  %r12,%r11
 29e8afa:	mov    (%r11),%edx
 29e8afd:	mov    0x190(%rsp),%rsi
 29e8b05:	mov    0x28(%rsi),%rsi
 29e8b09:	cmp    0x160(%rsi),%edx
 29e8b0f:	sete   %dl
 29e8b12:	movzbl %dl,%edx
 29e8b15:	test   %edx,%edx
 29e8b17:	jne    29e8d76 <wasm[0]::function[1015]::helper::object_read+0x7df6>
 29e8b1d:	xor    %r11d,%r11d
 29e8b20:	test   $0x1,%r13d
 29e8b27:	jne    29e8b6d <wasm[0]::function[1015]::helper::object_read+0x7bed>
 29e8b2d:	mov    0x2e0(%rsp),%r12
 29e8b35:	mov    0x28(%r12),%rdx
 29e8b3a:	mov    0x20(%r12),%r11
 29e8b3f:	mov    %r13d,%ebx
 29e8b42:	lea    0x4(%r11,%rbx,1),%r11
 29e8b47:	xor    %r12,%r12
 29e8b4a:	cmp    %rdx,%rbx
 29e8b4d:	cmova  %r12,%r11
 29e8b51:	mov    (%r11),%edx
 29e8b54:	mov    0x190(%rsp),%rsi
 29e8b5c:	mov    0x28(%rsi),%rsi
 29e8b60:	cmp    0x15c(%rsi),%edx
 29e8b66:	sete   %dl
 29e8b69:	movzbl %dl,%r11d
 29e8b6d:	test   %r11d,%r11d
 29e8b70:	je     29fbf79 <wasm[0]::function[1015]::helper::object_read+0x1aff9>
 29e8b76:	test   %r13d,%r13d
 29e8b79:	je     29fbf7b <wasm[0]::function[1015]::helper::object_read+0x1affb>
 29e8b7f:	mov    0x2e0(%rsp),%r12
 29e8b87:	mov    0x28(%r12),%r11
 29e8b8c:	mov    0x20(%r12),%r12
 29e8b91:	mov    %r13d,%ebx
 29e8b94:	lea    (%r12,%rbx,1),%rdx
 29e8b98:	xor    %r15,%r15
 29e8b9b:	cmp    %r11,%rbx
 29e8b9e:	cmova  %r15,%rdx
 29e8ba2:	mov    0x14(%rdx),%r13d
 29e8ba6:	mov    0x18(%rdx),%r14d
 29e8baa:	mov    0x1c(%rdx),%ebx
 29e8bad:	test   %r13d,%r13d
 29e8bb0:	je     29fbf7d <wasm[0]::function[1015]::helper::object_read+0x1affd>
 29e8bb6:	test   %r13d,%r13d
 29e8bb9:	je     29fbf7f <wasm[0]::function[1015]::helper::object_read+0x1afff>
 29e8bbf:	mov    %r13d,%esi
 29e8bc2:	lea    0x10(%r12,%rsi,1),%rdx
 29e8bc7:	cmp    %r11,%rsi
 29e8bca:	cmova  %r15,%rdx
 29e8bce:	mov    (%rdx),%edx
 29e8bd0:	cmp    %edx,%ecx
 29e8bd2:	jae    29fbf81 <wasm[0]::function[1015]::helper::object_read+0x1b001>
 29e8bd8:	mov    %edx,%esi
 29e8bda:	shr    $0x20,%rsi
 29e8bde:	test   %rsi,%rsi
 29e8be1:	jne    29fbf83 <wasm[0]::function[1015]::helper::object_read+0x1b003>
 29e8be7:	add    $0x14,%edx
 29e8bea:	jb     29fbf85 <wasm[0]::function[1015]::helper::object_read+0x1b005>
 29e8bf0:	add    %edx,%r13d
 29e8bf3:	jb     29fbf87 <wasm[0]::function[1015]::helper::object_read+0x1b007>
 29e8bf9:	mov    %r13d,%esi
 29e8bfc:	add    %rsi,%r12
 29e8bff:	cmp    %r11,%rsi
 29e8c02:	cmova  %r15,%r12
 29e8c06:	lea    0x14(%rcx),%esi
 29e8c09:	sub    %esi,%edx
 29e8c0b:	sub    %rdx,%r12
 29e8c0e:	movzbq (%r12),%rdx
 29e8c13:	mov    %rdx,0x218(%rsp)
 29e8c1b:	test   %r14d,%r14d
 29e8c1e:	je     29e8cb4 <wasm[0]::function[1015]::helper::object_read+0x7d34>
 29e8c24:	test   %r14d,%r14d
 29e8c27:	je     29fbf89 <wasm[0]::function[1015]::helper::object_read+0x1b009>
 29e8c2d:	test   %r14d,%r14d
 29e8c30:	je     29fbf8b <wasm[0]::function[1015]::helper::object_read+0x1b00b>
 29e8c36:	mov    0x2e0(%rsp),%r12
 29e8c3e:	mov    0x28(%r12),%r11
 29e8c43:	mov    0x20(%r12),%r12
 29e8c48:	mov    %r14d,%r13d
 29e8c4b:	lea    0x10(%r12,%r13,1),%rdx
 29e8c50:	xor    %r15,%r15
 29e8c53:	cmp    %r11,%r13
 29e8c56:	cmova  %r15,%rdx
 29e8c5a:	mov    (%rdx),%r13d
 29e8c5d:	cmp    %r13d,%ecx
 29e8c60:	jae    29fbf8d <wasm[0]::function[1015]::helper::object_read+0x1b00d>
 29e8c66:	mov    %r13d,%edx
 29e8c69:	shl    $0x3,%rdx
 29e8c6d:	shr    $0x20,%rdx
 29e8c71:	test   %rdx,%rdx
 29e8c74:	jne    29fbf8f <wasm[0]::function[1015]::helper::object_read+0x1b00f>
 29e8c7a:	shl    $0x3,%r13d
 29e8c7e:	add    $0x18,%r13d
 29e8c82:	jb     29fbf91 <wasm[0]::function[1015]::helper::object_read+0x1b011>
 29e8c88:	add    %r13d,%r14d
 29e8c8b:	jb     29fbf93 <wasm[0]::function[1015]::helper::object_read+0x1b013>
 29e8c91:	mov    %r14d,%esi
 29e8c94:	lea    (%r12,%rsi,1),%rdx
 29e8c98:	cmp    %r11,%rsi
 29e8c9b:	cmova  %r15,%rdx
 29e8c9f:	mov    %rcx,%rsi
 29e8ca2:	shl    $0x3,%esi
 29e8ca5:	add    $0x18,%esi
 29e8cab:	sub    %esi,%r13d
 29e8cae:	sub    %r13,%rdx
 29e8cb1:	mov    (%rdx),%r15
 29e8cb4:	xor    %r14d,%r14d
 29e8cb7:	test   %ebx,%ebx
 29e8cb9:	jne    29e8ccc <wasm[0]::function[1015]::helper::object_read+0x7d4c>
 29e8cbf:	mov    0x218(%rsp),%rdx
 29e8cc7:	jmp    29e8d5e <wasm[0]::function[1015]::helper::object_read+0x7dde>
 29e8ccc:	test   %ebx,%ebx
 29e8cce:	je     29fbf95 <wasm[0]::function[1015]::helper::object_read+0x1b015>
 29e8cd4:	test   %ebx,%ebx
 29e8cd6:	je     29fbf97 <wasm[0]::function[1015]::helper::object_read+0x1b017>
 29e8cdc:	mov    0x2e0(%rsp),%r12
 29e8ce4:	mov    0x28(%r12),%r11
 29e8ce9:	mov    0x20(%r12),%r12
 29e8cee:	mov    %ebx,%r14d
 29e8cf1:	lea    0x10(%r12,%r14,1),%rdx
 29e8cf6:	xor    %r13,%r13
 29e8cf9:	cmp    %r11,%r14
 29e8cfc:	cmova  %r13,%rdx
 29e8d00:	mov    (%rdx),%r14d
 29e8d03:	cmp    %r14d,%ecx
 29e8d06:	jae    29fbf99 <wasm[0]::function[1015]::helper::object_read+0x1b019>
 29e8d0c:	mov    %r14d,%edx
 29e8d0f:	shl    $0x2,%rdx
 29e8d13:	shr    $0x20,%rdx
 29e8d17:	test   %rdx,%rdx
 29e8d1a:	jne    29fbf9b <wasm[0]::function[1015]::helper::object_read+0x1b01b>
 29e8d20:	shl    $0x2,%r14d
 29e8d24:	add    $0x14,%r14d
 29e8d28:	jb     29fbf9d <wasm[0]::function[1015]::helper::object_read+0x1b01d>
 29e8d2e:	add    %r14d,%ebx
 29e8d31:	jb     29fbf9f <wasm[0]::function[1015]::helper::object_read+0x1b01f>
 29e8d37:	mov    %ebx,%esi
 29e8d39:	lea    (%r12,%rsi,1),%rdx
 29e8d3d:	cmp    %r11,%rsi
 29e8d40:	cmova  %r13,%rdx
 29e8d44:	shl    $0x2,%ecx
 29e8d47:	add    $0x14,%ecx
 29e8d4d:	sub    %ecx,%r14d
 29e8d50:	sub    %r14,%rdx
 29e8d53:	mov    (%rdx),%r14d
 29e8d56:	mov    0x218(%rsp),%rdx
 29e8d5e:	movzbl %dl,%ebx
 29e8d61:	mov    %r15,0x250(%rsp)
 29e8d69:	mov    %rbx,0x258(%rsp)
 29e8d71:	jmp    29e8ef1 <wasm[0]::function[1015]::helper::object_read+0x7f71>
 29e8d76:	xor    %edx,%edx
 29e8d78:	test   $0x1,%r13d
 29e8d7f:	jne    29e8dc4 <wasm[0]::function[1015]::helper::object_read+0x7e44>
 29e8d85:	mov    0x2e0(%rsp),%r12
 29e8d8d:	mov    0x28(%r12),%rdx
 29e8d92:	mov    0x20(%r12),%rsi
 29e8d97:	mov    %r13d,%ebx
 29e8d9a:	lea    0x4(%rsi,%rbx,1),%r11
 29e8d9f:	xor    %r12,%r12
 29e8da2:	cmp    %rdx,%rbx
 29e8da5:	cmova  %r12,%r11
 29e8da9:	mov    (%r11),%edx
 29e8dac:	mov    0x190(%rsp),%rsi
 29e8db4:	mov    0x28(%rsi),%rsi
 29e8db8:	cmp    0x160(%rsi),%edx
 29e8dbe:	sete   %dl
 29e8dc1:	movzbl %dl,%edx
 29e8dc4:	test   %edx,%edx
 29e8dc6:	je     29fbfa1 <wasm[0]::function[1015]::helper::object_read+0x1b021>
 29e8dcc:	test   %r13d,%r13d
 29e8dcf:	je     29fbfa3 <wasm[0]::function[1015]::helper::object_read+0x1b023>
 29e8dd5:	mov    0x2e0(%rsp),%r12
 29e8ddd:	mov    0x28(%r12),%r11
 29e8de2:	mov    0x20(%r12),%rbx
 29e8de7:	mov    %r13d,%r13d
 29e8dea:	lea    (%rbx,%r13,1),%rdx
 29e8dee:	xor    %r12,%r12
 29e8df1:	cmp    %r11,%r13
 29e8df4:	cmova  %r12,%rdx
 29e8df8:	mov    0x10(%rdx),%edx
 29e8dfb:	test   %edx,%edx
 29e8dfd:	je     29fbfa5 <wasm[0]::function[1015]::helper::object_read+0x1b025>
 29e8e03:	test   %edx,%edx
 29e8e05:	je     29fbfa7 <wasm[0]::function[1015]::helper::object_read+0x1b027>
 29e8e0b:	mov    %edx,%esi
 29e8e0d:	lea    (%rbx,%rsi,1),%rdx
 29e8e11:	cmp    %r11,%rsi
 29e8e14:	cmova  %r12,%rdx
 29e8e18:	mov    0x10(%rdx),%edx
 29e8e1b:	test   %edx,%edx
 29e8e1d:	je     29fbfa9 <wasm[0]::function[1015]::helper::object_read+0x1b029>
 29e8e23:	test   %edx,%edx
 29e8e25:	je     29fbfab <wasm[0]::function[1015]::helper::object_read+0x1b02b>
 29e8e2b:	mov    %edx,%esi
 29e8e2d:	lea    0x10(%rbx,%rsi,1),%rdx
 29e8e32:	cmp    %r11,%rsi
 29e8e35:	cmova  %r12,%rdx
 29e8e39:	cmp    (%rdx),%ecx
 29e8e3b:	setae  %dl
 29e8e3e:	cmp    $0x2,%ecx
 29e8e41:	setae  %sil
 29e8e45:	or     %esi,%edx
 29e8e47:	test   %dl,%dl
 29e8e49:	jne    29fbfad <wasm[0]::function[1015]::helper::object_read+0x1b02d>
 29e8e4f:	mov    0x2e0(%rsp),%r12
 29e8e57:	mov    0x28(%r12),%r11
 29e8e5c:	mov    %r13,%rdx
 29e8e5f:	add    0x20(%r12),%rdx
 29e8e64:	xor    %rbx,%rbx
 29e8e67:	cmp    %r11,%r13
 29e8e6a:	cmova  %rbx,%rdx
 29e8e6e:	mov    0x14(%rdx),%ebx
 29e8e71:	test   %ecx,%ecx
 29e8e73:	je     29e8eae <wasm[0]::function[1015]::helper::object_read+0x7f2e>
 29e8e79:	mov    0x2e0(%rsp),%r12
 29e8e81:	mov    0x28(%r12),%r11
 29e8e86:	mov    0x20(%r12),%rsi
 29e8e8b:	lea    (%rsi,%r13,1),%rdx
 29e8e8f:	xor    %r12,%r12
 29e8e92:	cmp    %r11,%r13
 29e8e95:	cmova  %r12,%rdx
 29e8e99:	mov    0x20(%rdx),%r15
 29e8e9d:	mov    0x2c(%rdx),%r14d
 29e8ea1:	mov    %r15,0x250(%rsp)
 29e8ea9:	jmp    29e8ede <wasm[0]::function[1015]::helper::object_read+0x7f5e>
 29e8eae:	mov    0x2e0(%rsp),%r12
 29e8eb6:	mov    0x28(%r12),%r11
 29e8ebb:	mov    0x20(%r12),%rsi
 29e8ec0:	lea    (%rsi,%r13,1),%rdx
 29e8ec4:	xor    %r12,%r12
 29e8ec7:	cmp    %r11,%r13
 29e8eca:	cmova  %r12,%rdx
 29e8ece:	mov    0x18(%rdx),%r15
 29e8ed2:	mov    %r15,0x250(%rsp)
 29e8eda:	mov    0x28(%rdx),%r14d
 29e8ede:	shl    $0x3,%ecx
 29e8ee1:	shr    %cl,%ebx
 29e8ee3:	and    $0xff,%ebx
 29e8ee9:	mov    %rbx,0x258(%rsp)
 29e8ef1:	mov    0x1a0(%rsp),%rdx
 29e8ef9:	mov    %edx,0x78(%rsp)
 29e8efd:	mov    0x1c8(%rsp),%rsi
 29e8f05:	mov    %esi,0x88(%rsp)
 29e8f0c:	mov    0x1d0(%rsp),%rcx
 29e8f14:	mov    %ecx,0xc8(%rsp)
 29e8f1b:	mov    %r14d,0x120(%rsp)
 29e8f23:	mov    %edi,0x110(%rsp)
 29e8f2a:	mov    %eax,0xd8(%rsp)
 29e8f31:	mov    %r8d,0x130(%rsp)
 29e8f39:	mov    %r9d,0xa0(%rsp)
 29e8f41:	mov    %r10d,0x118(%rsp)
 29e8f49:	mov    $0x27c,%edx
 29e8f4e:	mov    0x190(%rsp),%rsi
 29e8f56:	mov    0x190(%rsp),%rdi
 29e8f5e:	call   2f30600 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 29e8f63:	mov    %eax,0x100(%rsp)
 29e8f6a:	xor    %esi,%esi
 29e8f6c:	test   %eax,%eax
 29e8f6e:	je     29fbfaf <wasm[0]::function[1015]::helper::object_read+0x1b02f>
 29e8f74:	movl   $0x0,0x138(%rsp)
 29e8f7f:	mov    0x78(%rsp),%r8d
 29e8f84:	mov    %r8,0x1d8(%rsp)
 29e8f8c:	mov    0x88(%rsp),%r13d
 29e8f94:	mov    %r13,0x1e0(%rsp)
 29e8f9c:	mov    0xc8(%rsp),%edx
 29e8fa3:	mov    %rdx,0x1e8(%rsp)
 29e8fab:	mov    0x120(%rsp),%edi
 29e8fb2:	mov    %rdi,0x1f0(%rsp)
 29e8fba:	mov    0x110(%rsp),%edi
 29e8fc1:	mov    0xd8(%rsp),%r9d
 29e8fc9:	mov    0x130(%rsp),%r8d
 29e8fd1:	mov    0xa0(%rsp),%r10d
 29e8fd9:	mov    0x118(%rsp),%r11d
 29e8fe1:	xor    %r15,%r15
 29e8fe4:	mov    0x2a0(%rsp),%rax
 29e8fec:	mov    0x2a0(%rsp),%rcx
 29e8ff4:	test   %al,%cl
 29e8ff6:	jne    29e901c <wasm[0]::function[1015]::helper::object_read+0x809c>
 29e8ffc:	mov    0x1d8(%rsp),%rax
 29e9004:	mov    %rsi,%r14
 29e9007:	mov    %r15,0x260(%rsp)
 29e900f:	mov    %rsi,0x268(%rsp)
 29e9017:	jmp    29e9d03 <wasm[0]::function[1015]::helper::object_read+0x8d83>
 29e901c:	mov    0x78(%rsp),%r8d
 29e9021:	mov    0x2b0(%rsp),%rcx
 29e9029:	mov    0x2a8(%rsp),%rdx
 29e9031:	mov    0x190(%rsp),%rsi
 29e9039:	mov    0x190(%rsp),%rdi
 29e9041:	call   2a5f680 <wasm[0]::function[1039]::helper::object_header_projection>
 29e9046:	mov    %eax,0xe0(%rsp)
 29e904d:	test   %eax,%eax
 29e904f:	je     29fbfb1 <wasm[0]::function[1015]::helper::object_read+0x1b031>
 29e9055:	test   %eax,%eax
 29e9057:	je     29fbfb3 <wasm[0]::function[1015]::helper::object_read+0x1b033>
 29e905d:	mov    0x2e0(%rsp),%r12
 29e9065:	mov    0x28(%r12),%rcx
 29e906a:	mov    0x20(%r12),%rsi
 29e906f:	mov    %eax,%edx
 29e9071:	lea    (%rsi,%rdx,1),%rax
 29e9075:	xor    %rsi,%rsi
 29e9078:	cmp    %rcx,%rdx
 29e907b:	cmova  %rsi,%rax
 29e907f:	mov    0x14(%rax),%eax
 29e9082:	mov    %eax,0x108(%rsp)
 29e9089:	test   %eax,%eax
 29e908b:	je     29fbfb5 <wasm[0]::function[1015]::helper::object_read+0x1b035>
 29e9091:	mov    0x108(%rsp),%ecx
 29e9098:	xor    %eax,%eax
 29e909a:	test   $0x1,%ecx
 29e90a0:	jne    29e90fa <wasm[0]::function[1015]::helper::object_read+0x817a>
 29e90a6:	mov    0x2e0(%rsp),%r12
 29e90ae:	mov    0x28(%r12),%rax
 29e90b3:	mov    0x20(%r12),%rsi
 29e90b8:	mov    %ecx,%edx
 29e90ba:	lea    0x4(%rsi,%rdx,1),%rcx
 29e90bf:	xor    %rsi,%rsi
 29e90c2:	cmp    %rax,%rdx
 29e90c5:	cmova  %rsi,%rcx
 29e90c9:	mov    (%rcx),%esi
 29e90cb:	mov    0x190(%rsp),%rcx
 29e90d3:	mov    0x28(%rcx),%rax
 29e90d7:	mov    0x158(%rax),%edx
 29e90dd:	cmp    %edx,%esi
 29e90df:	sete   %al
 29e90e2:	movzbl %al,%eax
 29e90e5:	cmp    %edx,%esi
 29e90e7:	je     29e90fa <wasm[0]::function[1015]::helper::object_read+0x817a>
 29e90ed:	mov    0x190(%rsp),%rdi
 29e90f5:	call   3018cd5 <wasmtime_builtin_is_subtype>
 29e90fa:	test   %eax,%eax
 29e90fc:	jne    29e9381 <wasm[0]::function[1015]::helper::object_read+0x8401>
 29e9102:	mov    0xe0(%rsp),%edx
 29e9109:	xor    %ebx,%ebx
 29e910b:	test   %edx,%edx
 29e910d:	je     29fbfb7 <wasm[0]::function[1015]::helper::object_read+0x1b037>
 29e9113:	mov    0x100(%rsp),%r9d
 29e911b:	mov    $0x4,%ecx
 29e9120:	xor    %r8,%r8
 29e9123:	mov    0x190(%rsp),%rsi
 29e912b:	mov    0x190(%rsp),%rdi
 29e9133:	call   2a58e80 <wasm[0]::function[1032]::helper::ordinary_property_find>
 29e9138:	test   %eax,%eax
 29e913a:	je     29e9174 <wasm[0]::function[1015]::helper::object_read+0x81f4>
 29e9140:	test   %eax,%eax
 29e9142:	je     29fbfb9 <wasm[0]::function[1015]::helper::object_read+0x1b039>
 29e9148:	test   %eax,%eax
 29e914a:	je     29fbfbb <wasm[0]::function[1015]::helper::object_read+0x1b03b>
 29e9150:	mov    0x2e0(%rsp),%r12
 29e9158:	mov    0x28(%r12),%rcx
 29e915d:	mov    %eax,%edx
 29e915f:	mov    %rdx,%rax
 29e9162:	add    0x20(%r12),%rax
 29e9167:	xor    %rsi,%rsi
 29e916a:	cmp    %rcx,%rdx
 29e916d:	cmova  %rsi,%rax
 29e9171:	mov    0x14(%rax),%ebx
 29e9174:	mov    0x138(%rsp),%r14d
 29e917c:	xor    %r15,%r15
 29e917f:	xor    %esi,%esi
 29e9181:	test   %ebx,%ebx
 29e9183:	je     29e930a <wasm[0]::function[1015]::helper::object_read+0x838a>
 29e9189:	test   %ebx,%ebx
 29e918b:	je     29fbfbd <wasm[0]::function[1015]::helper::object_read+0x1b03d>
 29e9191:	mov    0x2e0(%rsp),%r12
 29e9199:	mov    0x28(%r12),%rdx
 29e919e:	mov    0x20(%r12),%rdi
 29e91a3:	mov    %ebx,%esi
 29e91a5:	lea    (%rdi,%rsi,1),%rax
 29e91a9:	xor    %r15,%r15
 29e91ac:	cmp    %rdx,%rsi
 29e91af:	cmova  %r15,%rax
 29e91b3:	mov    0x10(%rax),%edi
 29e91b6:	mov    0x138(%rsp),%r14d
 29e91be:	xor    %esi,%esi
 29e91c0:	test   $0x1,%edi
 29e91c6:	jne    29e930a <wasm[0]::function[1015]::helper::object_read+0x838a>
 29e91cc:	mov    0x14(%rax),%edx
 29e91cf:	test   %edx,%edx
 29e91d1:	je     29fbfbf <wasm[0]::function[1015]::helper::object_read+0x1b03f>
 29e91d7:	xor    %eax,%eax
 29e91d9:	test   $0x1,%edx
 29e91df:	jne    29e9223 <wasm[0]::function[1015]::helper::object_read+0x82a3>
 29e91e5:	mov    0x2e0(%rsp),%r12
 29e91ed:	mov    0x28(%r12),%rax
 29e91f2:	mov    0x20(%r12),%rsi
 29e91f7:	mov    %edx,%ecx
 29e91f9:	lea    0x4(%rsi,%rcx,1),%r9
 29e91fe:	xor    %rsi,%rsi
 29e9201:	cmp    %rax,%rcx
 29e9204:	cmova  %rsi,%r9
 29e9208:	mov    (%r9),%eax
 29e920b:	mov    0x190(%rsp),%rcx
 29e9213:	mov    0x28(%rcx),%rcx
 29e9217:	cmp    0x120(%rcx),%eax
 29e921d:	sete   %al
 29e9220:	movzbl %al,%eax
 29e9223:	test   %eax,%eax
 29e9225:	jne    29e9282 <wasm[0]::function[1015]::helper::object_read+0x8302>
 29e922b:	mov    0x190(%rsp),%rsi
 29e9233:	mov    0x190(%rsp),%rdi
 29e923b:	call   2a01c00 <wasm[0]::function[1024]::helper::property_value_resolve>
 29e9240:	test   %eax,%eax
 29e9242:	je     29fbfc1 <wasm[0]::function[1015]::helper::object_read+0x1b041>
 29e9248:	test   %eax,%eax
 29e924a:	je     29fbfc3 <wasm[0]::function[1015]::helper::object_read+0x1b043>
 29e9250:	mov    0x2e0(%rsp),%r12
 29e9258:	mov    0x28(%r12),%rcx
 29e925d:	mov    0x20(%r12),%rsi
 29e9262:	mov    %eax,%edx
 29e9264:	lea    (%rsi,%rdx,1),%rax
 29e9268:	xor    %rsi,%rsi
 29e926b:	cmp    %rcx,%rdx
 29e926e:	cmova  %rsi,%rax
 29e9272:	mov    0x18(%rax),%esi
 29e9275:	mov    0x10(%rax),%r15
 29e9279:	mov    0x1c(%rax),%r14d
 29e927d:	jmp    29e930a <wasm[0]::function[1015]::helper::object_read+0x838a>
 29e9282:	xor    %esi,%esi
 29e9284:	test   $0x1,%edx
 29e928a:	jne    29e92ce <wasm[0]::function[1015]::helper::object_read+0x834e>
 29e9290:	mov    0x2e0(%rsp),%r12
 29e9298:	mov    0x28(%r12),%rax
 29e929d:	mov    0x20(%r12),%rcx
 29e92a2:	mov    %edx,%esi
 29e92a4:	lea    0x4(%rcx,%rsi,1),%rcx
 29e92a9:	xor    %rdi,%rdi
 29e92ac:	cmp    %rax,%rsi
 29e92af:	cmova  %rdi,%rcx
 29e92b3:	mov    (%rcx),%eax
 29e92b5:	mov    0x190(%rsp),%rcx
 29e92bd:	mov    0x28(%rcx),%rcx
 29e92c1:	cmp    0x120(%rcx),%eax
 29e92c7:	sete   %al
 29e92ca:	rex movzbl %al,%esi
 29e92ce:	test   %esi,%esi
 29e92d0:	je     29fbfc5 <wasm[0]::function[1015]::helper::object_read+0x1b045>
 29e92d6:	test   %edx,%edx
 29e92d8:	je     29fbfc7 <wasm[0]::function[1015]::helper::object_read+0x1b047>
 29e92de:	mov    0x2e0(%rsp),%r12
 29e92e6:	mov    0x28(%r12),%rcx
 29e92eb:	mov    0x20(%r12),%rax
 29e92f0:	mov    %edx,%edx
 29e92f2:	add    %rdx,%rax
 29e92f5:	xor    %rsi,%rsi
 29e92f8:	cmp    %rcx,%rdx
 29e92fb:	cmova  %rsi,%rax
 29e92ff:	mov    0x18(%rax),%esi
 29e9302:	mov    0x10(%rax),%r15
 29e9306:	mov    0x1c(%rax),%r14d
 29e930a:	mov    0x78(%rsp),%r8d
 29e930f:	mov    %r8,0x1d8(%rsp)
 29e9317:	mov    0x88(%rsp),%r13d
 29e931f:	mov    %r13,0x1e0(%rsp)
 29e9327:	mov    0xc8(%rsp),%edx
 29e932e:	mov    %rdx,0x1e8(%rsp)
 29e9336:	mov    0x120(%rsp),%edi
 29e933d:	mov    %rdi,0x1f0(%rsp)
 29e9345:	mov    0x110(%rsp),%edi
 29e934c:	mov    0xd8(%rsp),%r9d
 29e9354:	mov    0x130(%rsp),%r8d
 29e935c:	mov    0xa0(%rsp),%r10d
 29e9364:	mov    0x118(%rsp),%r11d
 29e936c:	mov    %r15,0x260(%rsp)
 29e9374:	mov    %rsi,0x268(%rsp)
 29e937c:	jmp    29e9cfb <wasm[0]::function[1015]::helper::object_read+0x8d7b>
 29e9381:	mov    0x108(%rsp),%eax
 29e9388:	test   %eax,%eax
 29e938a:	je     29fbfc9 <wasm[0]::function[1015]::helper::object_read+0x1b049>
 29e9390:	mov    0x108(%rsp),%ecx
 29e9397:	xor    %eax,%eax
 29e9399:	test   $0x1,%ecx
 29e939f:	jne    29e93f9 <wasm[0]::function[1015]::helper::object_read+0x8479>
 29e93a5:	mov    0x2e0(%rsp),%r12
 29e93ad:	mov    0x28(%r12),%rax
 29e93b2:	mov    0x20(%r12),%rsi
 29e93b7:	mov    %ecx,%edx
 29e93b9:	lea    0x4(%rsi,%rdx,1),%rcx
 29e93be:	xor    %rsi,%rsi
 29e93c1:	cmp    %rax,%rdx
 29e93c4:	cmova  %rsi,%rcx
 29e93c8:	mov    (%rcx),%esi
 29e93ca:	mov    0x190(%rsp),%rcx
 29e93d2:	mov    0x28(%rcx),%rax
 29e93d6:	mov    0x158(%rax),%edx
 29e93dc:	cmp    %edx,%esi
 29e93de:	sete   %al
 29e93e1:	movzbl %al,%eax
 29e93e4:	cmp    %edx,%esi
 29e93e6:	je     29e93f9 <wasm[0]::function[1015]::helper::object_read+0x8479>
 29e93ec:	mov    0x190(%rsp),%rdi
 29e93f4:	call   3018cd5 <wasmtime_builtin_is_subtype>
 29e93f9:	test   %eax,%eax
 29e93fb:	je     29fbfcb <wasm[0]::function[1015]::helper::object_read+0x1b04b>
 29e9401:	mov    0x108(%rsp),%ebx
 29e9408:	mov    0x78(%rsp),%r8d
 29e940d:	mov    %r8,0x1d8(%rsp)
 29e9415:	mov    0x88(%rsp),%r13d
 29e941d:	mov    %r13,0x1e0(%rsp)
 29e9425:	mov    0xc8(%rsp),%edx
 29e942c:	mov    %rdx,0x1e8(%rsp)
 29e9434:	mov    0x120(%rsp),%edi
 29e943b:	mov    %rdi,0x1f0(%rsp)
 29e9443:	mov    0x138(%rsp),%r14d
 29e944b:	mov    0x110(%rsp),%edi
 29e9452:	mov    0xd8(%rsp),%r9d
 29e945a:	mov    0x130(%rsp),%r8d
 29e9462:	mov    0xa0(%rsp),%r10d
 29e946a:	mov    0x118(%rsp),%r11d
 29e9472:	xor    %ecx,%ecx
 29e9474:	mov    %rcx,0x1f8(%rsp)
 29e947c:	test   %ebx,%ebx
 29e947e:	je     29fbfcd <wasm[0]::function[1015]::helper::object_read+0x1b04d>
 29e9484:	test   %ebx,%ebx
 29e9486:	je     29fbfcf <wasm[0]::function[1015]::helper::object_read+0x1b04f>
 29e948c:	mov    0x2e0(%rsp),%r12
 29e9494:	mov    0x28(%r12),%rax
 29e9499:	mov    0x20(%r12),%rcx
 29e949e:	mov    %ebx,%r13d
 29e94a1:	lea    (%rcx,%r13,1),%rsi
 29e94a5:	xor    %r12,%r12
 29e94a8:	cmp    %rax,%r13
 29e94ab:	cmova  %r12,%rsi
 29e94af:	mov    0x10(%rsi),%esi
 29e94b2:	test   %esi,%esi
 29e94b4:	je     29fbfd1 <wasm[0]::function[1015]::helper::object_read+0x1b051>
 29e94ba:	test   %esi,%esi
 29e94bc:	je     29fbfd3 <wasm[0]::function[1015]::helper::object_read+0x1b053>
 29e94c2:	mov    %esi,%r13d
 29e94c5:	lea    (%rcx,%r13,1),%rsi
 29e94c9:	cmp    %rax,%r13
 29e94cc:	cmova  %r12,%rsi
 29e94d0:	mov    0x10(%rsi),%esi
 29e94d3:	test   %esi,%esi
 29e94d5:	je     29fbfd5 <wasm[0]::function[1015]::helper::object_read+0x1b055>
 29e94db:	test   %esi,%esi
 29e94dd:	je     29fbfd7 <wasm[0]::function[1015]::helper::object_read+0x1b057>
 29e94e3:	mov    %esi,%r13d
 29e94e6:	lea    0x10(%rcx,%r13,1),%rcx
 29e94eb:	cmp    %rax,%r13
 29e94ee:	cmova  %r12,%rcx
 29e94f2:	mov    (%rcx),%r15d
 29e94f5:	mov    %r15,0x208(%rsp)
 29e94fd:	mov    0x100(%rsp),%r12d
 29e9505:	mov    0x190(%rsp),%rcx
 29e950d:	mov    0x28(%rcx),%rax
 29e9511:	mov    0x234(%rax),%r15d
 29e9518:	mov    0x1f8(%rsp),%rax
 29e9520:	mov    %rax,0x1d0(%rsp)
 29e9528:	mov    %esi,0xe0(%rsp)
 29e952f:	mov    %r12d,0x118(%rsp)
 29e9537:	mov    %ebx,0xa0(%rsp)
 29e953e:	mov    0x1d8(%rsp),%rax
 29e9546:	mov    %eax,0x130(%rsp)
 29e954d:	mov    0x1e0(%rsp),%r13
 29e9555:	mov    %r13d,0xd8(%rsp)
 29e955d:	mov    0x1e8(%rsp),%rdx
 29e9565:	mov    %edx,0x110(%rsp)
 29e956c:	mov    0x1f0(%rsp),%rax
 29e9574:	mov    %eax,0x138(%rsp)
 29e957b:	mov    %r14d,0x120(%rsp)
 29e9583:	mov    %edi,0xc8(%rsp)
 29e958a:	mov    %r9d,0x88(%rsp)
 29e9592:	mov    %r8d,0x78(%rsp)
 29e9597:	mov    %r10d,0x108(%rsp)
 29e959f:	mov    %r11d,0x100(%rsp)
 29e95a7:	mov    0x2e8(%rsp),%r13
 29e95af:	mov    0x0(%r13),%rcx
 29e95b3:	mov    0x228(%rsp),%rax
 29e95bb:	cmp    %rax,%rcx
 29e95be:	jae    29faabc <wasm[0]::function[1015]::helper::object_read+0x19b3c>
 29e95c4:	mov    0xa0(%rsp),%ebx
 29e95cb:	mov    0x130(%rsp),%r8d
 29e95d3:	mov    %r8,0x1d8(%rsp)
 29e95db:	mov    0xd8(%rsp),%r13d
 29e95e3:	mov    %r13,0x1e0(%rsp)
 29e95eb:	mov    0x110(%rsp),%edx
 29e95f2:	mov    %rdx,0x1e8(%rsp)
 29e95fa:	mov    0x138(%rsp),%edi
 29e9601:	mov    %rdi,0x1f0(%rsp)
 29e9609:	mov    0x120(%rsp),%r14d
 29e9611:	mov    0xc8(%rsp),%edi
 29e9618:	mov    0x88(%rsp),%r9d
 29e9620:	mov    0x78(%rsp),%r8d
 29e9625:	mov    0x108(%rsp),%r10d
 29e962d:	mov    0x100(%rsp),%r11d
 29e9635:	mov    0x1f8(%rsp),%rcx
 29e963d:	mov    0x208(%rsp),%rdx
 29e9645:	cmp    %edx,%ecx
 29e9647:	jb     29e965a <wasm[0]::function[1015]::helper::object_read+0x86da>
 29e964d:	mov    0x1d0(%rsp),%rax
 29e9655:	jmp    29e989b <wasm[0]::function[1015]::helper::object_read+0x891b>
 29e965a:	mov    0xe0(%rsp),%eax
 29e9661:	test   %eax,%eax
 29e9663:	je     29fbfd9 <wasm[0]::function[1015]::helper::object_read+0x1b059>
 29e9669:	test   %eax,%eax
 29e966b:	je     29fbfdb <wasm[0]::function[1015]::helper::object_read+0x1b05b>
 29e9671:	mov    0x2e0(%rsp),%r12
 29e9679:	mov    0x28(%r12),%rdx
 29e967e:	mov    0x20(%r12),%rsi
 29e9683:	mov    %eax,%r9d
 29e9686:	lea    0x10(%rsi,%r9,1),%r8
 29e968b:	xor    %rdi,%rdi
 29e968e:	cmp    %rdx,%r9
 29e9691:	cmova  %rdi,%r8
 29e9695:	mov    (%r8),%r8d
 29e9698:	cmp    %r8d,%ecx
 29e969b:	jae    29fbfdd <wasm[0]::function[1015]::helper::object_read+0x1b05d>
 29e96a1:	mov    %r8d,%r9d
 29e96a4:	shl    $0x2,%r9
 29e96a8:	shr    $0x20,%r9
 29e96ac:	test   %r9,%r9
 29e96af:	jne    29fbfdf <wasm[0]::function[1015]::helper::object_read+0x1b05f>
 29e96b5:	shl    $0x2,%r8d
 29e96b9:	add    $0x14,%r8d
 29e96bd:	jb     29fbfe1 <wasm[0]::function[1015]::helper::object_read+0x1b061>
 29e96c3:	add    %r8d,%eax
 29e96c6:	jb     29fbfe3 <wasm[0]::function[1015]::helper::object_read+0x1b063>
 29e96cc:	mov    %eax,%r9d
 29e96cf:	lea    (%rsi,%r9,1),%rax
 29e96d3:	cmp    %rdx,%r9
 29e96d6:	cmova  %rdi,%rax
 29e96da:	mov    %rcx,%rdx
 29e96dd:	shl    $0x2,%edx
 29e96e0:	mov    %rcx,0x1f8(%rsp)
 29e96e8:	lea    0x14(%rdx),%ecx
 29e96eb:	sub    %ecx,%r8d
 29e96ee:	sub    %r8,%rax
 29e96f1:	mov    (%rax),%edx
 29e96f3:	test   %edx,%edx
 29e96f5:	je     29fbfe5 <wasm[0]::function[1015]::helper::object_read+0x1b065>
 29e96fb:	mov    0x118(%rsp),%eax
 29e9702:	cmp    %eax,%edx
 29e9704:	je     29e97db <wasm[0]::function[1015]::helper::object_read+0x885b>
 29e970a:	xor    %ecx,%ecx
 29e970c:	test   %edx,%edx
 29e970e:	je     29e9750 <wasm[0]::function[1015]::helper::object_read+0x87d0>
 29e9714:	xor    %ecx,%ecx
 29e9716:	test   $0x1,%edx
 29e971c:	jne    29e9750 <wasm[0]::function[1015]::helper::object_read+0x87d0>
 29e9722:	mov    0x2e0(%rsp),%r12
 29e972a:	mov    0x28(%r12),%rcx
 29e972f:	mov    0x20(%r12),%rsi
 29e9734:	mov    %edx,%edi
 29e9736:	lea    0x4(%rsi,%rdi,1),%rsi
 29e973b:	xor    %r8,%r8
 29e973e:	cmp    %rcx,%rdi
 29e9741:	cmova  %r8,%rsi
 29e9745:	mov    (%rsi),%ecx
 29e9747:	cmp    %r15d,%ecx
 29e974a:	sete   %cl
 29e974d:	movzbl %cl,%ecx
 29e9750:	test   %ecx,%ecx
 29e9752:	je     29fbfe7 <wasm[0]::function[1015]::helper::object_read+0x1b067>
 29e9758:	xor    %ecx,%ecx
 29e975a:	test   %eax,%eax
 29e975c:	je     29e97a7 <wasm[0]::function[1015]::helper::object_read+0x8827>
 29e9762:	mov    0x118(%rsp),%esi
 29e9769:	xor    %ecx,%ecx
 29e976b:	test   $0x1,%esi
 29e9771:	jne    29e97a7 <wasm[0]::function[1015]::helper::object_read+0x8827>
 29e9777:	mov    0x2e0(%rsp),%r12
 29e977f:	mov    0x28(%r12),%rdi
 29e9784:	mov    0x20(%r12),%r8
 29e9789:	mov    %esi,%esi
 29e978b:	lea    0x4(%r8,%rsi,1),%rcx
 29e9790:	xor    %r8,%r8
 29e9793:	cmp    %rdi,%rsi
 29e9796:	cmova  %r8,%rcx
 29e979a:	mov    (%rcx),%esi
 29e979c:	cmp    %r15d,%esi
 29e979f:	sete   %sil
 29e97a3:	movzbl %sil,%ecx
 29e97a7:	test   %ecx,%ecx
 29e97a9:	je     29fbfe9 <wasm[0]::function[1015]::helper::object_read+0x1b069>
 29e97af:	mov    0x118(%rsp),%ecx
 29e97b6:	xor    %r8d,%r8d
 29e97b9:	test   %ecx,%ecx
 29e97bb:	je     29fbfeb <wasm[0]::function[1015]::helper::object_read+0x1b06b>
 29e97c1:	mov    0x190(%rsp),%rsi
 29e97c9:	mov    0x190(%rsp),%rdi
 29e97d1:	call   2ae5540 <wasm[0]::function[1057]::helper::string_equality>
 29e97d6:	jmp    29e97e3 <wasm[0]::function[1015]::helper::object_read+0x8863>
 29e97db:	mov    0x278(%rsp),%rax
 29e97e3:	mov    0xe0(%rsp),%esi
 29e97ea:	mov    0x118(%rsp),%r12d
 29e97f2:	mov    0xa0(%rsp),%ebx
 29e97f9:	mov    0x130(%rsp),%r8d
 29e9801:	mov    %r8,0x1d8(%rsp)
 29e9809:	mov    0xd8(%rsp),%r13d
 29e9811:	mov    %r13,0x1e0(%rsp)
 29e9819:	mov    0x110(%rsp),%edx
 29e9820:	mov    %rdx,0x1e8(%rsp)
 29e9828:	mov    0x138(%rsp),%edi
 29e982f:	mov    %rdi,0x1f0(%rsp)
 29e9837:	mov    0x120(%rsp),%r14d
 29e983f:	mov    0xc8(%rsp),%edi
 29e9846:	mov    0x88(%rsp),%r9d
 29e984e:	mov    0x78(%rsp),%r8d
 29e9853:	mov    0x108(%rsp),%r10d
 29e985b:	mov    0x100(%rsp),%r11d
 29e9863:	test   %eax,%eax
 29e9865:	je     29e9878 <wasm[0]::function[1015]::helper::object_read+0x88f8>
 29e986b:	mov    0x1f8(%rsp),%rcx
 29e9873:	jmp    29e989b <wasm[0]::function[1015]::helper::object_read+0x891b>
 29e9878:	mov    0x1f8(%rsp),%rcx
 29e9880:	add    $0x1,%ecx
 29e9886:	mov    %rax,0x1d0(%rsp)
 29e988e:	mov    %rcx,0x1f8(%rsp)
 29e9896:	jmp    29e9528 <wasm[0]::function[1015]::helper::object_read+0x85a8>
 29e989b:	xor    %r15,%r15
 29e989e:	xor    %esi,%esi
 29e98a0:	test   %eax,%eax
 29e98a2:	jne    29e98bd <wasm[0]::function[1015]::helper::object_read+0x893d>
 29e98a8:	mov    %r15,0x260(%rsp)
 29e98b0:	mov    %rsi,0x268(%rsp)
 29e98b8:	jmp    29e9cfb <wasm[0]::function[1015]::helper::object_read+0x8d7b>
 29e98bd:	test   %ebx,%ebx
 29e98bf:	je     29fbfed <wasm[0]::function[1015]::helper::object_read+0x1b06d>
 29e98c5:	xor    %eax,%eax
 29e98c7:	test   $0x1,%ebx
 29e98cd:	jne    29e9911 <wasm[0]::function[1015]::helper::object_read+0x8991>
 29e98d3:	mov    0x2e0(%rsp),%r12
 29e98db:	mov    0x28(%r12),%rax
 29e98e0:	mov    0x20(%r12),%rsi
 29e98e5:	mov    %ebx,%r12d
 29e98e8:	lea    0x4(%rsi,%r12,1),%rsi
 29e98ed:	xor    %r13,%r13
 29e98f0:	cmp    %rax,%r12
 29e98f3:	cmova  %r13,%rsi
 29e98f7:	mov    (%rsi),%eax
 29e98f9:	mov    0x190(%rsp),%rdx
 29e9901:	mov    0x28(%rdx),%rdx
 29e9905:	cmp    0x160(%rdx),%eax
 29e990b:	sete   %al
 29e990e:	movzbl %al,%eax
 29e9911:	test   %eax,%eax
 29e9913:	jne    29e9b6b <wasm[0]::function[1015]::helper::object_read+0x8beb>
 29e9919:	xor    %eax,%eax
 29e991b:	test   $0x1,%ebx
 29e9921:	jne    29e9965 <wasm[0]::function[1015]::helper::object_read+0x89e5>
 29e9927:	mov    0x2e0(%rsp),%r12
 29e992f:	mov    0x28(%r12),%rax
 29e9934:	mov    0x20(%r12),%rsi
 29e9939:	mov    %ebx,%r12d
 29e993c:	lea    0x4(%rsi,%r12,1),%rsi
 29e9941:	xor    %r13,%r13
 29e9944:	cmp    %rax,%r12
 29e9947:	cmova  %r13,%rsi
 29e994b:	mov    (%rsi),%eax
 29e994d:	mov    0x190(%rsp),%rdx
 29e9955:	mov    0x28(%rdx),%rdx
 29e9959:	cmp    0x15c(%rdx),%eax
 29e995f:	sete   %al
 29e9962:	movzbl %al,%eax
 29e9965:	test   %eax,%eax
 29e9967:	je     29fbfef <wasm[0]::function[1015]::helper::object_read+0x1b06f>
 29e996d:	test   %ebx,%ebx
 29e996f:	je     29fbff1 <wasm[0]::function[1015]::helper::object_read+0x1b071>
 29e9975:	mov    0x2e0(%rsp),%r12
 29e997d:	mov    0x28(%r12),%rsi
 29e9982:	mov    0x20(%r12),%r12
 29e9987:	mov    %ebx,%eax
 29e9989:	lea    (%r12,%rax,1),%rbx
 29e998d:	xor    %r15,%r15
 29e9990:	cmp    %rsi,%rax
 29e9993:	cmova  %r15,%rbx
 29e9997:	mov    0x14(%rbx),%r14d
 29e999b:	mov    0x18(%rbx),%eax
 29e999e:	mov    0x1c(%rbx),%ebx
 29e99a1:	test   %r14d,%r14d
 29e99a4:	je     29fbff3 <wasm[0]::function[1015]::helper::object_read+0x1b073>
 29e99aa:	test   %r14d,%r14d
 29e99ad:	je     29fbff5 <wasm[0]::function[1015]::helper::object_read+0x1b075>
 29e99b3:	mov    %r14d,%edx
 29e99b6:	lea    0x10(%r12,%rdx,1),%r13
 29e99bb:	cmp    %rsi,%rdx
 29e99be:	cmova  %r15,%r13
 29e99c2:	mov    0x0(%r13),%r13d
 29e99c6:	cmp    %r13d,%ecx
 29e99c9:	jae    29fbff7 <wasm[0]::function[1015]::helper::object_read+0x1b077>
 29e99cf:	mov    %r13d,%edx
 29e99d2:	shr    $0x20,%rdx
 29e99d6:	test   %rdx,%rdx
 29e99d9:	jne    29fbff9 <wasm[0]::function[1015]::helper::object_read+0x1b079>
 29e99df:	add    $0x14,%r13d
 29e99e3:	jb     29fbffb <wasm[0]::function[1015]::helper::object_read+0x1b07b>
 29e99e9:	add    %r13d,%r14d
 29e99ec:	jb     29fbffd <wasm[0]::function[1015]::helper::object_read+0x1b07d>
 29e99f2:	mov    %r14d,%edx
 29e99f5:	add    %rdx,%r12
 29e99f8:	cmp    %rsi,%rdx
 29e99fb:	cmova  %r15,%r12
 29e99ff:	lea    0x14(%rcx),%edx
 29e9a02:	sub    %edx,%r13d
 29e9a05:	sub    %r13,%r12
 29e9a08:	movzbq (%r12),%r13
 29e9a0d:	mov    %r13,0x208(%rsp)
 29e9a15:	test   %eax,%eax
 29e9a17:	je     29e9aab <wasm[0]::function[1015]::helper::object_read+0x8b2b>
 29e9a1d:	test   %eax,%eax
 29e9a1f:	je     29fbfff <wasm[0]::function[1015]::helper::object_read+0x1b07f>
 29e9a25:	test   %eax,%eax
 29e9a27:	je     29fc001 <wasm[0]::function[1015]::helper::object_read+0x1b081>
 29e9a2d:	mov    0x2e0(%rsp),%r12
 29e9a35:	mov    0x28(%r12),%r12
 29e9a3a:	mov    0x2e0(%rsp),%rdx
 29e9a42:	mov    0x20(%rdx),%r14
 29e9a46:	mov    %eax,%r13d
 29e9a49:	lea    0x10(%r14,%r13,1),%rsi
 29e9a4e:	xor    %r15,%r15
 29e9a51:	cmp    %r12,%r13
 29e9a54:	cmova  %r15,%rsi
 29e9a58:	mov    (%rsi),%esi
 29e9a5a:	cmp    %esi,%ecx
 29e9a5c:	jae    29fc003 <wasm[0]::function[1015]::helper::object_read+0x1b083>
 29e9a62:	mov    %esi,%r13d
 29e9a65:	shl    $0x3,%r13
 29e9a69:	shr    $0x20,%r13
 29e9a6d:	test   %r13,%r13
 29e9a70:	jne    29fc005 <wasm[0]::function[1015]::helper::object_read+0x1b085>
 29e9a76:	shl    $0x3,%esi
 29e9a79:	add    $0x18,%esi
 29e9a7c:	jb     29fc007 <wasm[0]::function[1015]::helper::object_read+0x1b087>
 29e9a82:	add    %esi,%eax
 29e9a84:	jb     29fc009 <wasm[0]::function[1015]::helper::object_read+0x1b089>
 29e9a8a:	mov    %eax,%edx
 29e9a8c:	lea    (%r14,%rdx,1),%rax
 29e9a90:	cmp    %r12,%rdx
 29e9a93:	cmova  %r15,%rax
 29e9a97:	mov    %rcx,%rdx
 29e9a9a:	shl    $0x3,%edx
 29e9a9d:	add    $0x18,%edx
 29e9aa3:	sub    %edx,%esi
 29e9aa5:	sub    %rsi,%rax
 29e9aa8:	mov    (%rax),%r15
 29e9aab:	xor    %r14d,%r14d
 29e9aae:	test   %ebx,%ebx
 29e9ab0:	jne    29e9ac3 <wasm[0]::function[1015]::helper::object_read+0x8b43>
 29e9ab6:	mov    0x208(%rsp),%r13
 29e9abe:	jmp    29e9b52 <wasm[0]::function[1015]::helper::object_read+0x8bd2>
 29e9ac3:	test   %ebx,%ebx
 29e9ac5:	je     29fc00b <wasm[0]::function[1015]::helper::object_read+0x1b08b>
 29e9acb:	test   %ebx,%ebx
 29e9acd:	je     29fc00d <wasm[0]::function[1015]::helper::object_read+0x1b08d>
 29e9ad3:	mov    0x2e0(%rsp),%r12
 29e9adb:	mov    0x28(%r12),%rax
 29e9ae0:	mov    0x20(%r12),%rsi
 29e9ae5:	mov    %ebx,%r14d
 29e9ae8:	lea    0x10(%rsi,%r14,1),%r13
 29e9aed:	xor    %r12,%r12
 29e9af0:	cmp    %rax,%r14
 29e9af3:	cmova  %r12,%r13
 29e9af7:	mov    0x0(%r13),%r14d
 29e9afb:	cmp    %r14d,%ecx
 29e9afe:	jae    29fc00f <wasm[0]::function[1015]::helper::object_read+0x1b08f>
 29e9b04:	mov    %r14d,%r13d
 29e9b07:	shl    $0x2,%r13
 29e9b0b:	shr    $0x20,%r13
 29e9b0f:	test   %r13,%r13
 29e9b12:	jne    29fc011 <wasm[0]::function[1015]::helper::object_read+0x1b091>
 29e9b18:	shl    $0x2,%r14d
 29e9b1c:	add    $0x14,%r14d
 29e9b20:	jb     29fc013 <wasm[0]::function[1015]::helper::object_read+0x1b093>
 29e9b26:	add    %r14d,%ebx
 29e9b29:	jb     29fc015 <wasm[0]::function[1015]::helper::object_read+0x1b095>
 29e9b2f:	mov    %ebx,%edx
 29e9b31:	add    %rdx,%rsi
 29e9b34:	cmp    %rax,%rdx
 29e9b37:	cmova  %r12,%rsi
 29e9b3b:	shl    $0x2,%ecx
 29e9b3e:	lea    0x14(%rcx),%eax
 29e9b41:	sub    %eax,%r14d
 29e9b44:	sub    %r14,%rsi
 29e9b47:	mov    (%rsi),%r14d
 29e9b4a:	mov    0x208(%rsp),%r13
 29e9b52:	movzbl %r13b,%esi
 29e9b56:	mov    %r15,0x260(%rsp)
 29e9b5e:	mov    %rsi,0x268(%rsp)
 29e9b66:	jmp    29e9cfb <wasm[0]::function[1015]::helper::object_read+0x8d7b>
 29e9b6b:	xor    %eax,%eax
 29e9b6d:	test   $0x1,%ebx
 29e9b73:	jne    29e9bb7 <wasm[0]::function[1015]::helper::object_read+0x8c37>
 29e9b79:	mov    0x2e0(%rsp),%r12
 29e9b81:	mov    0x28(%r12),%rax
 29e9b86:	mov    0x20(%r12),%rdx
 29e9b8b:	mov    %ebx,%r12d
 29e9b8e:	lea    0x4(%rdx,%r12,1),%rsi
 29e9b93:	xor    %r13,%r13
 29e9b96:	cmp    %rax,%r12
 29e9b99:	cmova  %r13,%rsi
 29e9b9d:	mov    (%rsi),%eax
 29e9b9f:	mov    0x190(%rsp),%rdx
 29e9ba7:	mov    0x28(%rdx),%rdx
 29e9bab:	cmp    0x160(%rdx),%eax
 29e9bb1:	sete   %al
 29e9bb4:	movzbl %al,%eax
 29e9bb7:	test   %eax,%eax
 29e9bb9:	je     29fc017 <wasm[0]::function[1015]::helper::object_read+0x1b097>
 29e9bbf:	test   %ebx,%ebx
 29e9bc1:	je     29fc019 <wasm[0]::function[1015]::helper::object_read+0x1b099>
 29e9bc7:	mov    0x2e0(%rsp),%r12
 29e9bcf:	mov    0x28(%r12),%rsi
 29e9bd4:	mov    0x20(%r12),%r12
 29e9bd9:	mov    %ebx,%eax
 29e9bdb:	lea    (%r12,%rax,1),%r13
 29e9bdf:	xor    %rbx,%rbx
 29e9be2:	cmp    %rsi,%rax
 29e9be5:	cmova  %rbx,%r13
 29e9be9:	mov    0x10(%r13),%r13d
 29e9bed:	test   %r13d,%r13d
 29e9bf0:	je     29fc01b <wasm[0]::function[1015]::helper::object_read+0x1b09b>
 29e9bf6:	test   %r13d,%r13d
 29e9bf9:	je     29fc01d <wasm[0]::function[1015]::helper::object_read+0x1b09d>
 29e9bff:	mov    %r13d,%edx
 29e9c02:	lea    (%r12,%rdx,1),%r13
 29e9c06:	cmp    %rsi,%rdx
 29e9c09:	cmova  %rbx,%r13
 29e9c0d:	mov    0x10(%r13),%r13d
 29e9c11:	test   %r13d,%r13d
 29e9c14:	je     29fc01f <wasm[0]::function[1015]::helper::object_read+0x1b09f>
 29e9c1a:	test   %r13d,%r13d
 29e9c1d:	je     29fc021 <wasm[0]::function[1015]::helper::object_read+0x1b0a1>
 29e9c23:	mov    %r13d,%edx
 29e9c26:	lea    0x10(%r12,%rdx,1),%r12
 29e9c2b:	cmp    %rsi,%rdx
 29e9c2e:	cmova  %rbx,%r12
 29e9c32:	cmp    (%r12),%ecx
 29e9c36:	setae  %sil
 29e9c3a:	cmp    $0x2,%ecx
 29e9c3d:	setae  %dl
 29e9c40:	or     %edx,%esi
 29e9c42:	test   %sil,%sil
 29e9c45:	jne    29fc023 <wasm[0]::function[1015]::helper::object_read+0x1b0a3>
 29e9c4b:	mov    0x2e0(%rsp),%r12
 29e9c53:	mov    0x28(%r12),%rbx
 29e9c58:	mov    %rax,%rsi
 29e9c5b:	add    0x20(%r12),%rsi
 29e9c60:	xor    %r12,%r12
 29e9c63:	cmp    %rbx,%rax
 29e9c66:	cmova  %r12,%rsi
 29e9c6a:	mov    0x14(%rsi),%esi
 29e9c6d:	test   %ecx,%ecx
 29e9c6f:	je     29e9cb1 <wasm[0]::function[1015]::helper::object_read+0x8d31>
 29e9c75:	mov    0x2e0(%rsp),%r12
 29e9c7d:	mov    0x28(%r12),%r12
 29e9c82:	mov    0x2e0(%rsp),%rdx
 29e9c8a:	mov    0x20(%rdx),%rdx
 29e9c8e:	lea    (%rdx,%rax,1),%rbx
 29e9c92:	xor    %r13,%r13
 29e9c95:	cmp    %r12,%rax
 29e9c98:	cmova  %r13,%rbx
 29e9c9c:	mov    0x20(%rbx),%r15
 29e9ca0:	mov    0x2c(%rbx),%r14d
 29e9ca4:	mov    %r15,0x260(%rsp)
 29e9cac:	jmp    29e9ce8 <wasm[0]::function[1015]::helper::object_read+0x8d68>
 29e9cb1:	mov    0x2e0(%rsp),%r12
 29e9cb9:	mov    0x28(%r12),%r12
 29e9cbe:	mov    0x2e0(%rsp),%rdx
 29e9cc6:	mov    0x20(%rdx),%rdx
 29e9cca:	lea    (%rdx,%rax,1),%rbx
 29e9cce:	xor    %r13,%r13
 29e9cd1:	cmp    %r12,%rax
 29e9cd4:	cmova  %r13,%rbx
 29e9cd8:	mov    0x18(%rbx),%r15
 29e9cdc:	mov    %r15,0x260(%rsp)
 29e9ce4:	mov    0x28(%rbx),%r14d
 29e9ce8:	shl    $0x3,%ecx
 29e9ceb:	shr    %cl,%esi
 29e9ced:	and    $0xff,%esi
 29e9cf3:	mov    %rsi,0x268(%rsp)
 29e9cfb:	mov    0x1d8(%rsp),%rax
 29e9d03:	mov    %eax,0x88(%rsp)
 29e9d0a:	mov    0x1e0(%rsp),%r13
 29e9d12:	mov    %r13d,0xc8(%rsp)
 29e9d1a:	mov    0x1e8(%rsp),%rdx
 29e9d22:	mov    %edx,0x120(%rsp)
 29e9d29:	mov    0x1f0(%rsp),%rax
 29e9d31:	mov    %eax,0x138(%rsp)
 29e9d38:	mov    %r14d,0x110(%rsp)
 29e9d40:	mov    %edi,0xd8(%rsp)
 29e9d47:	mov    %r9d,0x130(%rsp)
 29e9d4f:	mov    %r8d,0xa0(%rsp)
 29e9d57:	mov    %r10d,0x118(%rsp)
 29e9d5f:	mov    %r11d,0xe0(%rsp)
 29e9d67:	mov    $0x286,%edx
 29e9d6c:	mov    0x190(%rsp),%rsi
 29e9d74:	mov    0x190(%rsp),%rdi
 29e9d7c:	call   2f30600 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 29e9d81:	mov    %eax,0x78(%rsp)
 29e9d85:	xor    %r14d,%r14d
 29e9d88:	mov    %r14,0x1a0(%rsp)
 29e9d90:	test   %eax,%eax
 29e9d92:	je     29fc025 <wasm[0]::function[1015]::helper::object_read+0x1b0a5>
 29e9d98:	movl   $0x0,0x108(%rsp)
 29e9da3:	mov    0x88(%rsp),%edx
 29e9daa:	mov    %rdx,0x1f8(%rsp)
 29e9db2:	mov    0xc8(%rsp),%esi
 29e9db9:	mov    %rsi,0x208(%rsp)
 29e9dc1:	mov    0x120(%rsp),%edi
 29e9dc8:	mov    %rdi,0x218(%rsp)
 29e9dd0:	mov    0x138(%rsp),%r8d
 29e9dd8:	mov    %r8,0x220(%rsp)
 29e9de0:	mov    0x110(%rsp),%r9d
 29e9de8:	mov    %r9,0x198(%rsp)
 29e9df0:	mov    0xd8(%rsp),%r9d
 29e9df8:	mov    0x130(%rsp),%r10d
 29e9e00:	mov    0xa0(%rsp),%edx
 29e9e07:	mov    0x118(%rsp),%r11d
 29e9e0f:	mov    0xe0(%rsp),%ebx
 29e9e16:	xor    %r13,%r13
 29e9e19:	mov    0x2a0(%rsp),%rax
 29e9e21:	mov    0x2a0(%rsp),%rcx
 29e9e29:	test   %al,%cl
 29e9e2b:	jne    29e9e4e <wasm[0]::function[1015]::helper::object_read+0x8ece>
 29e9e31:	mov    0x1f8(%rsp),%rax
 29e9e39:	mov    0x1a0(%rsp),%r15
 29e9e41:	mov    %r13,0x1c8(%rsp)
 29e9e49:	jmp    29eabe7 <wasm[0]::function[1015]::helper::object_read+0x9c67>
 29e9e4e:	mov    0x88(%rsp),%r8d
 29e9e56:	mov    0x2b0(%rsp),%rcx
 29e9e5e:	mov    0x2a8(%rsp),%rdx
 29e9e66:	mov    0x190(%rsp),%rsi
 29e9e6e:	mov    0x190(%rsp),%rdi
 29e9e76:	call   2a5f680 <wasm[0]::function[1039]::helper::object_header_projection>
 29e9e7b:	mov    %eax,0x100(%rsp)
 29e9e82:	test   %eax,%eax
 29e9e84:	je     29fc027 <wasm[0]::function[1015]::helper::object_read+0x1b0a7>
 29e9e8a:	test   %eax,%eax
 29e9e8c:	je     29fc029 <wasm[0]::function[1015]::helper::object_read+0x1b0a9>
 29e9e92:	mov    0x2e0(%rsp),%r12
 29e9e9a:	mov    0x28(%r12),%rcx
 29e9e9f:	mov    0x20(%r12),%rsi
 29e9ea4:	mov    %eax,%edx
 29e9ea6:	lea    (%rsi,%rdx,1),%rax
 29e9eaa:	xor    %rsi,%rsi
 29e9ead:	cmp    %rcx,%rdx
 29e9eb0:	cmova  %rsi,%rax
 29e9eb4:	mov    0x14(%rax),%eax
 29e9eb7:	mov    %eax,0xf8(%rsp)
 29e9ebe:	test   %eax,%eax
 29e9ec0:	je     29fc02b <wasm[0]::function[1015]::helper::object_read+0x1b0ab>
 29e9ec6:	mov    0xf8(%rsp),%ecx
 29e9ecd:	xor    %eax,%eax
 29e9ecf:	test   $0x1,%ecx
 29e9ed5:	jne    29e9f2f <wasm[0]::function[1015]::helper::object_read+0x8faf>
 29e9edb:	mov    0x2e0(%rsp),%r12
 29e9ee3:	mov    0x28(%r12),%rax
 29e9ee8:	mov    0x20(%r12),%rsi
 29e9eed:	mov    %ecx,%edx
 29e9eef:	lea    0x4(%rsi,%rdx,1),%rcx
 29e9ef4:	xor    %rsi,%rsi
 29e9ef7:	cmp    %rax,%rdx
 29e9efa:	cmova  %rsi,%rcx
 29e9efe:	mov    (%rcx),%esi
 29e9f00:	mov    0x190(%rsp),%rcx
 29e9f08:	mov    0x28(%rcx),%rax
 29e9f0c:	mov    0x158(%rax),%edx
 29e9f12:	cmp    %edx,%esi
 29e9f14:	sete   %al
 29e9f17:	movzbl %al,%eax
 29e9f1a:	cmp    %edx,%esi
 29e9f1c:	je     29e9f2f <wasm[0]::function[1015]::helper::object_read+0x8faf>
 29e9f22:	mov    0x190(%rsp),%rdi
 29e9f2a:	call   3018cd5 <wasmtime_builtin_is_subtype>
 29e9f2f:	test   %eax,%eax
 29e9f31:	jne    29ea1ec <wasm[0]::function[1015]::helper::object_read+0x926c>
 29e9f37:	mov    0x100(%rsp),%edx
 29e9f3e:	xor    %ebx,%ebx
 29e9f40:	test   %edx,%edx
 29e9f42:	je     29fc02d <wasm[0]::function[1015]::helper::object_read+0x1b0ad>
 29e9f48:	mov    0x78(%rsp),%r9d
 29e9f4d:	mov    $0x4,%ecx
 29e9f52:	xor    %r8,%r8
 29e9f55:	mov    0x190(%rsp),%rsi
 29e9f5d:	mov    0x190(%rsp),%rdi
 29e9f65:	call   2a58e80 <wasm[0]::function[1032]::helper::ordinary_property_find>
 29e9f6a:	test   %eax,%eax
 29e9f6c:	je     29e9fa6 <wasm[0]::function[1015]::helper::object_read+0x9026>
 29e9f72:	test   %eax,%eax
 29e9f74:	je     29fc02f <wasm[0]::function[1015]::helper::object_read+0x1b0af>
 29e9f7a:	test   %eax,%eax
 29e9f7c:	je     29fc031 <wasm[0]::function[1015]::helper::object_read+0x1b0b1>
 29e9f82:	mov    0x2e0(%rsp),%r12
 29e9f8a:	mov    0x28(%r12),%rcx
 29e9f8f:	mov    %eax,%edx
 29e9f91:	mov    %rdx,%rax
 29e9f94:	add    0x20(%r12),%rax
 29e9f99:	xor    %rsi,%rsi
 29e9f9c:	cmp    %rcx,%rdx
 29e9f9f:	cmova  %rsi,%rax
 29e9fa3:	mov    0x14(%rax),%ebx
 29e9fa6:	mov    0x108(%rsp),%r15d
 29e9fae:	xor    %r14d,%r14d
 29e9fb1:	mov    %r14,0x1a0(%rsp)
 29e9fb9:	xor    %r13,%r13
 29e9fbc:	test   %ebx,%ebx
 29e9fbe:	je     29ea16c <wasm[0]::function[1015]::helper::object_read+0x91ec>
 29e9fc4:	test   %ebx,%ebx
 29e9fc6:	je     29fc033 <wasm[0]::function[1015]::helper::object_read+0x1b0b3>
 29e9fcc:	mov    0x2e0(%rsp),%r12
 29e9fd4:	mov    0x28(%r12),%rcx
 29e9fd9:	mov    0x20(%r12),%rax
 29e9fde:	mov    %ebx,%edx
 29e9fe0:	add    %rdx,%rax
 29e9fe3:	xor    %r13,%r13
 29e9fe6:	cmp    %rcx,%rdx
 29e9fe9:	cmova  %r13,%rax
 29e9fed:	mov    0x10(%rax),%ecx
 29e9ff0:	mov    0x108(%rsp),%r15d
 29e9ff8:	mov    %r14,%rdx
 29e9ffb:	mov    %r14,0x1a0(%rsp)
 29ea003:	xor    %edx,%r14d
 29ea006:	mov    %r14,0x1a0(%rsp)
 29ea00e:	test   $0x1,%ecx
 29ea014:	jne    29ea16c <wasm[0]::function[1015]::helper::object_read+0x91ec>
 29ea01a:	mov    0x14(%rax),%edx
 29ea01d:	test   %edx,%edx
 29ea01f:	je     29fc035 <wasm[0]::function[1015]::helper::object_read+0x1b0b5>
 29ea025:	xor    %eax,%eax
 29ea027:	test   $0x1,%edx
 29ea02d:	jne    29ea074 <wasm[0]::function[1015]::helper::object_read+0x90f4>
 29ea033:	mov    0x2e0(%rsp),%r12
 29ea03b:	mov    0x28(%r12),%rsi
 29ea040:	mov    0x20(%r12),%rdi
 29ea045:	mov    %edx,%r8d
 29ea048:	lea    0x4(%rdi,%r8,1),%rdi
 29ea04d:	xor    %r9,%r9
 29ea050:	cmp    %rsi,%r8
 29ea053:	cmova  %r9,%rdi
 29ea057:	mov    (%rdi),%edi
 29ea059:	mov    0x190(%rsp),%rcx
 29ea061:	mov    0x28(%rcx),%r8
 29ea065:	cmp    0x120(%r8),%edi
 29ea06c:	sete   %r8b
 29ea070:	movzbl %r8b,%eax
 29ea074:	test   %eax,%eax
 29ea076:	jne    29ea0dc <wasm[0]::function[1015]::helper::object_read+0x915c>
 29ea07c:	mov    0x190(%rsp),%rsi
 29ea084:	mov    0x190(%rsp),%rdi
 29ea08c:	call   2a01c00 <wasm[0]::function[1024]::helper::property_value_resolve>
 29ea091:	test   %eax,%eax
 29ea093:	je     29fc037 <wasm[0]::function[1015]::helper::object_read+0x1b0b7>
 29ea099:	test   %eax,%eax
 29ea09b:	je     29fc039 <wasm[0]::function[1015]::helper::object_read+0x1b0b9>
 29ea0a1:	mov    0x2e0(%rsp),%r12
 29ea0a9:	mov    0x28(%r12),%rcx
 29ea0ae:	mov    0x20(%r12),%rsi
 29ea0b3:	mov    %eax,%edx
 29ea0b5:	lea    (%rsi,%rdx,1),%rax
 29ea0b9:	xor    %rsi,%rsi
 29ea0bc:	cmp    %rcx,%rdx
 29ea0bf:	cmova  %rsi,%rax
 29ea0c3:	mov    0x18(%rax),%r14d
 29ea0c7:	mov    %r14,0x1a0(%rsp)
 29ea0cf:	mov    0x10(%rax),%r13
 29ea0d3:	mov    0x1c(%rax),%r15d
 29ea0d7:	jmp    29ea16c <wasm[0]::function[1015]::helper::object_read+0x91ec>
 29ea0dc:	xor    %eax,%eax
 29ea0de:	test   $0x1,%edx
 29ea0e4:	jne    29ea127 <wasm[0]::function[1015]::helper::object_read+0x91a7>
 29ea0ea:	mov    0x2e0(%rsp),%r12
 29ea0f2:	mov    0x28(%r12),%rax
 29ea0f7:	mov    0x20(%r12),%rcx
 29ea0fc:	mov    %edx,%esi
 29ea0fe:	lea    0x4(%rcx,%rsi,1),%rcx
 29ea103:	xor    %rdi,%rdi
 29ea106:	cmp    %rax,%rsi
 29ea109:	cmova  %rdi,%rcx
 29ea10d:	mov    (%rcx),%eax
 29ea10f:	mov    0x190(%rsp),%rcx
 29ea117:	mov    0x28(%rcx),%rcx
 29ea11b:	cmp    0x120(%rcx),%eax
 29ea121:	sete   %al
 29ea124:	movzbl %al,%eax
 29ea127:	test   %eax,%eax
 29ea129:	je     29fc03b <wasm[0]::function[1015]::helper::object_read+0x1b0bb>
 29ea12f:	test   %edx,%edx
 29ea131:	je     29fc03d <wasm[0]::function[1015]::helper::object_read+0x1b0bd>
 29ea137:	mov    0x2e0(%rsp),%r12
 29ea13f:	mov    0x28(%r12),%rcx
 29ea144:	mov    0x20(%r12),%rax
 29ea149:	mov    %edx,%edx
 29ea14b:	add    %rdx,%rax
 29ea14e:	xor    %rsi,%rsi
 29ea151:	cmp    %rcx,%rdx
 29ea154:	cmova  %rsi,%rax
 29ea158:	mov    0x18(%rax),%r14d
 29ea15c:	mov    %r14,0x1a0(%rsp)
 29ea164:	mov    0x10(%rax),%r13
 29ea168:	mov    0x1c(%rax),%r15d
 29ea16c:	mov    0x88(%rsp),%edx
 29ea173:	mov    %rdx,0x1f8(%rsp)
 29ea17b:	mov    0xc8(%rsp),%esi
 29ea182:	mov    %rsi,0x208(%rsp)
 29ea18a:	mov    0x120(%rsp),%edi
 29ea191:	mov    %rdi,0x218(%rsp)
 29ea199:	mov    0x138(%rsp),%r8d
 29ea1a1:	mov    %r8,0x220(%rsp)
 29ea1a9:	mov    0x110(%rsp),%r9d
 29ea1b1:	mov    %r9,0x198(%rsp)
 29ea1b9:	mov    0xd8(%rsp),%r9d
 29ea1c1:	mov    0x130(%rsp),%r10d
 29ea1c9:	mov    0xa0(%rsp),%edx
 29ea1d0:	mov    0x118(%rsp),%r11d
 29ea1d8:	mov    0xe0(%rsp),%ebx
 29ea1df:	mov    %r13,0x1c8(%rsp)
 29ea1e7:	jmp    29eabdf <wasm[0]::function[1015]::helper::object_read+0x9c5f>
 29ea1ec:	mov    0xf8(%rsp),%eax
 29ea1f3:	test   %eax,%eax
 29ea1f5:	je     29fc03f <wasm[0]::function[1015]::helper::object_read+0x1b0bf>
 29ea1fb:	mov    0xf8(%rsp),%ecx
 29ea202:	xor    %eax,%eax
 29ea204:	test   $0x1,%ecx
 29ea20a:	jne    29ea264 <wasm[0]::function[1015]::helper::object_read+0x92e4>
 29ea210:	mov    0x2e0(%rsp),%r12
 29ea218:	mov    0x28(%r12),%rax
 29ea21d:	mov    0x20(%r12),%rsi
 29ea222:	mov    %ecx,%edx
 29ea224:	lea    0x4(%rsi,%rdx,1),%rcx
 29ea229:	xor    %rsi,%rsi
 29ea22c:	cmp    %rax,%rdx
 29ea22f:	cmova  %rsi,%rcx
 29ea233:	mov    (%rcx),%esi
 29ea235:	mov    0x190(%rsp),%rcx
 29ea23d:	mov    0x28(%rcx),%rax
 29ea241:	mov    0x158(%rax),%edx
 29ea247:	cmp    %edx,%esi
 29ea249:	sete   %al
 29ea24c:	movzbl %al,%eax
 29ea24f:	cmp    %edx,%esi
 29ea251:	je     29ea264 <wasm[0]::function[1015]::helper::object_read+0x92e4>
 29ea257:	mov    0x190(%rsp),%rdi
 29ea25f:	call   3018cd5 <wasmtime_builtin_is_subtype>
 29ea264:	test   %eax,%eax
 29ea266:	je     29fc041 <wasm[0]::function[1015]::helper::object_read+0x1b0c1>
 29ea26c:	mov    0xf8(%rsp),%r14d
 29ea274:	mov    0x88(%rsp),%edx
 29ea27b:	mov    %rdx,0x1f8(%rsp)
 29ea283:	mov    0xc8(%rsp),%esi
 29ea28a:	mov    %rsi,0x208(%rsp)
 29ea292:	mov    0x108(%rsp),%r15d
 29ea29a:	mov    0x120(%rsp),%edi
 29ea2a1:	mov    %rdi,0x218(%rsp)
 29ea2a9:	mov    0x138(%rsp),%r8d
 29ea2b1:	mov    %r8,0x220(%rsp)
 29ea2b9:	mov    0x110(%rsp),%r9d
 29ea2c1:	mov    %r9,0x198(%rsp)
 29ea2c9:	mov    0xd8(%rsp),%r9d
 29ea2d1:	mov    0x130(%rsp),%r10d
 29ea2d9:	mov    0xa0(%rsp),%edx
 29ea2e0:	mov    0x118(%rsp),%r11d
 29ea2e8:	mov    0xe0(%rsp),%ebx
 29ea2ef:	xor    %ecx,%ecx
 29ea2f1:	mov    %rcx,0x2b8(%rsp)
 29ea2f9:	test   %r14d,%r14d
 29ea2fc:	je     29fc043 <wasm[0]::function[1015]::helper::object_read+0x1b0c3>
 29ea302:	test   %r14d,%r14d
 29ea305:	je     29fc045 <wasm[0]::function[1015]::helper::object_read+0x1b0c5>
 29ea30b:	mov    0x2e0(%rsp),%r12
 29ea313:	mov    0x28(%r12),%rax
 29ea318:	mov    0x20(%r12),%rcx
 29ea31d:	mov    %r14d,%edi
 29ea320:	lea    (%rcx,%rdi,1),%rsi
 29ea324:	xor    %r12,%r12
 29ea327:	cmp    %rax,%rdi
 29ea32a:	cmova  %r12,%rsi
 29ea32e:	mov    0x10(%rsi),%esi
 29ea331:	test   %esi,%esi
 29ea333:	je     29fc047 <wasm[0]::function[1015]::helper::object_read+0x1b0c7>
 29ea339:	test   %esi,%esi
 29ea33b:	je     29fc049 <wasm[0]::function[1015]::helper::object_read+0x1b0c9>
 29ea341:	mov    %esi,%edi
 29ea343:	lea    (%rcx,%rdi,1),%rsi
 29ea347:	cmp    %rax,%rdi
 29ea34a:	cmova  %r12,%rsi
 29ea34e:	mov    0x10(%rsi),%esi
 29ea351:	test   %esi,%esi
 29ea353:	je     29fc04b <wasm[0]::function[1015]::helper::object_read+0x1b0cb>
 29ea359:	test   %esi,%esi
 29ea35b:	je     29fc04d <wasm[0]::function[1015]::helper::object_read+0x1b0cd>
 29ea361:	mov    %esi,%edi
 29ea363:	lea    0x10(%rcx,%rdi,1),%rcx
 29ea368:	cmp    %rax,%rdi
 29ea36b:	cmova  %r12,%rcx
 29ea36f:	mov    (%rcx),%ecx
 29ea371:	mov    %rcx,0x1d8(%rsp)
 29ea379:	mov    0x78(%rsp),%r12d
 29ea37e:	mov    0x190(%rsp),%rcx
 29ea386:	mov    0x28(%rcx),%rcx
 29ea38a:	mov    0x234(%rcx),%r13d
 29ea391:	mov    %r13,0x1d0(%rsp)
 29ea399:	mov    0x2b8(%rsp),%rax
 29ea3a1:	mov    %rax,0x1f0(%rsp)
 29ea3a9:	mov    %esi,0x100(%rsp)
 29ea3b0:	mov    %r12d,0xe0(%rsp)
 29ea3b8:	mov    %r14d,0x118(%rsp)
 29ea3c0:	mov    0x1f8(%rsp),%rax
 29ea3c8:	mov    %eax,0xa0(%rsp)
 29ea3cf:	mov    0x208(%rsp),%rsi
 29ea3d7:	mov    %esi,0x130(%rsp)
 29ea3de:	mov    %r15d,0xd8(%rsp)
 29ea3e6:	mov    0x218(%rsp),%rdi
 29ea3ee:	mov    %edi,0x110(%rsp)
 29ea3f5:	mov    0x220(%rsp),%r8
 29ea3fd:	mov    %r8d,0x138(%rsp)
 29ea405:	mov    0x198(%rsp),%r8
 29ea40d:	mov    %r8d,0x120(%rsp)
 29ea415:	mov    %r9d,0x108(%rsp)
 29ea41d:	mov    %r10d,0xc8(%rsp)
 29ea425:	mov    %edx,0x88(%rsp)
 29ea42c:	mov    %r11d,0xf8(%rsp)
 29ea434:	mov    %ebx,0x78(%rsp)
 29ea438:	mov    0x2e8(%rsp),%r13
 29ea440:	mov    0x0(%r13),%rcx
 29ea444:	mov    0x228(%rsp),%rax
 29ea44c:	cmp    %rax,%rcx
 29ea44f:	jae    29faaf4 <wasm[0]::function[1015]::helper::object_read+0x19b74>
 29ea455:	mov    0x118(%rsp),%r14d
 29ea45d:	mov    0xa0(%rsp),%edx
 29ea464:	mov    %rdx,0x1f8(%rsp)
 29ea46c:	mov    0x130(%rsp),%esi
 29ea473:	mov    %rsi,0x208(%rsp)
 29ea47b:	mov    0xd8(%rsp),%r15d
 29ea483:	mov    0x110(%rsp),%edi
 29ea48a:	mov    %rdi,0x218(%rsp)
 29ea492:	mov    0x138(%rsp),%r8d
 29ea49a:	mov    %r8,0x220(%rsp)
 29ea4a2:	mov    0x120(%rsp),%r9d
 29ea4aa:	mov    %r9,0x198(%rsp)
 29ea4b2:	mov    0x108(%rsp),%r9d
 29ea4ba:	mov    0xc8(%rsp),%r10d
 29ea4c2:	mov    0x88(%rsp),%edx
 29ea4c9:	mov    0xf8(%rsp),%r11d
 29ea4d1:	mov    0x78(%rsp),%ebx
 29ea4d5:	mov    0x2b8(%rsp),%rcx
 29ea4dd:	mov    0x1d8(%rsp),%rsi
 29ea4e5:	cmp    %esi,%ecx
 29ea4e7:	jb     29ea4fa <wasm[0]::function[1015]::helper::object_read+0x957a>
 29ea4ed:	mov    0x1f0(%rsp),%rax
 29ea4f5:	jmp    29ea779 <wasm[0]::function[1015]::helper::object_read+0x97f9>
 29ea4fa:	mov    0x100(%rsp),%eax
 29ea501:	test   %eax,%eax
 29ea503:	je     29fc04f <wasm[0]::function[1015]::helper::object_read+0x1b0cf>
 29ea509:	test   %eax,%eax
 29ea50b:	je     29fc051 <wasm[0]::function[1015]::helper::object_read+0x1b0d1>
 29ea511:	mov    0x2e0(%rsp),%r12
 29ea519:	mov    0x28(%r12),%rdx
 29ea51e:	mov    0x20(%r12),%rsi
 29ea523:	mov    %eax,%r9d
 29ea526:	lea    0x10(%rsi,%r9,1),%r8
 29ea52b:	xor    %rdi,%rdi
 29ea52e:	cmp    %rdx,%r9
 29ea531:	cmova  %rdi,%r8
 29ea535:	mov    (%r8),%r8d
 29ea538:	cmp    %r8d,%ecx
 29ea53b:	jae    29fc053 <wasm[0]::function[1015]::helper::object_read+0x1b0d3>
 29ea541:	mov    %r8d,%r9d
 29ea544:	shl    $0x2,%r9
 29ea548:	shr    $0x20,%r9
 29ea54c:	test   %r9,%r9
 29ea54f:	jne    29fc055 <wasm[0]::function[1015]::helper::object_read+0x1b0d5>
 29ea555:	shl    $0x2,%r8d
 29ea559:	add    $0x14,%r8d
 29ea55d:	jb     29fc057 <wasm[0]::function[1015]::helper::object_read+0x1b0d7>
 29ea563:	add    %r8d,%eax
 29ea566:	jb     29fc059 <wasm[0]::function[1015]::helper::object_read+0x1b0d9>
 29ea56c:	mov    %eax,%r9d
 29ea56f:	lea    (%rsi,%r9,1),%rax
 29ea573:	cmp    %rdx,%r9
 29ea576:	cmova  %rdi,%rax
 29ea57a:	mov    %rcx,%rdx
 29ea57d:	shl    $0x2,%edx
 29ea580:	mov    %rcx,0x2b8(%rsp)
 29ea588:	lea    0x14(%rdx),%ecx
 29ea58b:	sub    %ecx,%r8d
 29ea58e:	sub    %r8,%rax
 29ea591:	mov    (%rax),%edx
 29ea593:	test   %edx,%edx
 29ea595:	je     29fc05b <wasm[0]::function[1015]::helper::object_read+0x1b0db>
 29ea59b:	mov    0xe0(%rsp),%eax
 29ea5a2:	cmp    %eax,%edx
 29ea5a4:	je     29ea69a <wasm[0]::function[1015]::helper::object_read+0x971a>
 29ea5aa:	xor    %ecx,%ecx
 29ea5ac:	test   %edx,%edx
 29ea5ae:	jne    29ea5c1 <wasm[0]::function[1015]::helper::object_read+0x9641>
 29ea5b4:	mov    0x1d0(%rsp),%r13
 29ea5bc:	jmp    29ea612 <wasm[0]::function[1015]::helper::object_read+0x9692>
 29ea5c1:	xor    %ecx,%ecx
 29ea5c3:	test   $0x1,%edx
 29ea5c9:	je     29ea5dc <wasm[0]::function[1015]::helper::object_read+0x965c>
 29ea5cf:	mov    0x1d0(%rsp),%r13
 29ea5d7:	jmp    29ea612 <wasm[0]::function[1015]::helper::object_read+0x9692>
 29ea5dc:	mov    0x2e0(%rsp),%r12
 29ea5e4:	mov    0x28(%r12),%rcx
 29ea5e9:	mov    0x20(%r12),%rsi
 29ea5ee:	mov    %edx,%edi
 29ea5f0:	lea    0x4(%rsi,%rdi,1),%rsi
 29ea5f5:	xor    %r8,%r8
 29ea5f8:	cmp    %rcx,%rdi
 29ea5fb:	cmova  %r8,%rsi
 29ea5ff:	mov    (%rsi),%ecx
 29ea601:	mov    0x1d0(%rsp),%r13
 29ea609:	cmp    %r13d,%ecx
 29ea60c:	sete   %cl
 29ea60f:	movzbl %cl,%ecx
 29ea612:	test   %ecx,%ecx
 29ea614:	je     29fc05d <wasm[0]::function[1015]::helper::object_read+0x1b0dd>
 29ea61a:	xor    %ecx,%ecx
 29ea61c:	test   %eax,%eax
 29ea61e:	je     29ea666 <wasm[0]::function[1015]::helper::object_read+0x96e6>
 29ea624:	mov    0xe0(%rsp),%eax
 29ea62b:	xor    %ecx,%ecx
 29ea62d:	test   $0x1,%eax
 29ea632:	jne    29ea666 <wasm[0]::function[1015]::helper::object_read+0x96e6>
 29ea638:	mov    0x2e0(%rsp),%r12
 29ea640:	mov    0x28(%r12),%rcx
 29ea645:	mov    0x20(%r12),%rdi
 29ea64a:	mov    %eax,%esi
 29ea64c:	lea    0x4(%rdi,%rsi,1),%rax
 29ea651:	xor    %rdi,%rdi
 29ea654:	cmp    %rcx,%rsi
 29ea657:	cmova  %rdi,%rax
 29ea65b:	mov    (%rax),%eax
 29ea65d:	cmp    %r13d,%eax
 29ea660:	sete   %cl
 29ea663:	movzbl %cl,%ecx
 29ea666:	test   %ecx,%ecx
 29ea668:	je     29fc05f <wasm[0]::function[1015]::helper::object_read+0x1b0df>
 29ea66e:	mov    0xe0(%rsp),%ecx
 29ea675:	xor    %r8d,%r8d
 29ea678:	test   %ecx,%ecx
 29ea67a:	je     29fc061 <wasm[0]::function[1015]::helper::object_read+0x1b0e1>
 29ea680:	mov    0x190(%rsp),%rsi
 29ea688:	mov    0x190(%rsp),%rdi
 29ea690:	call   2ae5540 <wasm[0]::function[1057]::helper::string_equality>
 29ea695:	jmp    29ea6aa <wasm[0]::function[1015]::helper::object_read+0x972a>
 29ea69a:	mov    0x1d0(%rsp),%r13
 29ea6a2:	mov    0x278(%rsp),%rax
 29ea6aa:	mov    0x100(%rsp),%esi
 29ea6b1:	mov    0xe0(%rsp),%r12d
 29ea6b9:	mov    0x118(%rsp),%r14d
 29ea6c1:	mov    0xa0(%rsp),%edx
 29ea6c8:	mov    %rdx,0x1f8(%rsp)
 29ea6d0:	mov    0x130(%rsp),%ecx
 29ea6d7:	mov    %rcx,0x208(%rsp)
 29ea6df:	mov    0xd8(%rsp),%r15d
 29ea6e7:	mov    0x110(%rsp),%edi
 29ea6ee:	mov    %rdi,0x218(%rsp)
 29ea6f6:	mov    0x138(%rsp),%r8d
 29ea6fe:	mov    %r8,0x220(%rsp)
 29ea706:	mov    0x120(%rsp),%r9d
 29ea70e:	mov    %r9,0x198(%rsp)
 29ea716:	mov    0x108(%rsp),%r9d
 29ea71e:	mov    0xc8(%rsp),%r10d
 29ea726:	mov    0x88(%rsp),%edx
 29ea72d:	mov    0xf8(%rsp),%r11d
 29ea735:	mov    0x78(%rsp),%ebx
 29ea739:	test   %eax,%eax
 29ea73b:	je     29ea74e <wasm[0]::function[1015]::helper::object_read+0x97ce>
 29ea741:	mov    0x2b8(%rsp),%rcx
 29ea749:	jmp    29ea779 <wasm[0]::function[1015]::helper::object_read+0x97f9>
 29ea74e:	mov    0x2b8(%rsp),%rcx
 29ea756:	add    $0x1,%ecx
 29ea75c:	mov    %r13,0x1d0(%rsp)
 29ea764:	mov    %rax,0x1f0(%rsp)
 29ea76c:	mov    %rcx,0x2b8(%rsp)
 29ea774:	jmp    29ea3a9 <wasm[0]::function[1015]::helper::object_read+0x9429>
 29ea779:	mov    %rsi,%rdi
 29ea77c:	mov    %rsi,0x1a0(%rsp)
 29ea784:	xor    %edi,%esi
 29ea786:	mov    %rsi,0x1a0(%rsp)
 29ea78e:	xor    %r13,%r13
 29ea791:	test   %eax,%eax
 29ea793:	jne    29ea7a6 <wasm[0]::function[1015]::helper::object_read+0x9826>
 29ea799:	mov    %r13,0x1c8(%rsp)
 29ea7a1:	jmp    29eabdf <wasm[0]::function[1015]::helper::object_read+0x9c5f>
 29ea7a6:	test   %r14d,%r14d
 29ea7a9:	je     29fc063 <wasm[0]::function[1015]::helper::object_read+0x1b0e3>
 29ea7af:	xor    %eax,%eax
 29ea7b1:	test   $0x1,%r14d
 29ea7b8:	jne    29ea7fc <wasm[0]::function[1015]::helper::object_read+0x987c>
 29ea7be:	mov    0x2e0(%rsp),%r12
 29ea7c6:	mov    0x28(%r12),%rax
 29ea7cb:	mov    0x20(%r12),%rsi
 29ea7d0:	mov    %r14d,%edi
 29ea7d3:	lea    0x4(%rsi,%rdi,1),%rsi
 29ea7d8:	xor    %r12,%r12
 29ea7db:	cmp    %rax,%rdi
 29ea7de:	cmova  %r12,%rsi
 29ea7e2:	mov    (%rsi),%eax
 29ea7e4:	mov    0x190(%rsp),%rsi
 29ea7ec:	mov    0x28(%rsi),%rsi
 29ea7f0:	cmp    0x160(%rsi),%eax
 29ea7f6:	sete   %al
 29ea7f9:	movzbl %al,%eax
 29ea7fc:	test   %eax,%eax
 29ea7fe:	jne    29eaa48 <wasm[0]::function[1015]::helper::object_read+0x9ac8>
 29ea804:	xor    %eax,%eax
 29ea806:	test   $0x1,%r14d
 29ea80d:	jne    29ea851 <wasm[0]::function[1015]::helper::object_read+0x98d1>
 29ea813:	mov    0x2e0(%rsp),%r12
 29ea81b:	mov    0x28(%r12),%rax
 29ea820:	mov    0x20(%r12),%rsi
 29ea825:	mov    %r14d,%edi
 29ea828:	lea    0x4(%rsi,%rdi,1),%rsi
 29ea82d:	xor    %r12,%r12
 29ea830:	cmp    %rax,%rdi
 29ea833:	cmova  %r12,%rsi
 29ea837:	mov    (%rsi),%eax
 29ea839:	mov    0x190(%rsp),%rsi
 29ea841:	mov    0x28(%rsi),%rsi
 29ea845:	cmp    0x15c(%rsi),%eax
 29ea84b:	sete   %al
 29ea84e:	movzbl %al,%eax
 29ea851:	test   %eax,%eax
 29ea853:	je     29fc065 <wasm[0]::function[1015]::helper::object_read+0x1b0e5>
 29ea859:	test   %r14d,%r14d
 29ea85c:	je     29fc067 <wasm[0]::function[1015]::helper::object_read+0x1b0e7>
 29ea862:	mov    0x2e0(%rsp),%r12
 29ea86a:	mov    0x28(%r12),%rsi
 29ea86f:	mov    0x20(%r12),%r12
 29ea874:	mov    %r14d,%eax
 29ea877:	lea    (%r12,%rax,1),%rdi
 29ea87b:	xor    %r13,%r13
 29ea87e:	cmp    %rsi,%rax
 29ea881:	cmova  %r13,%rdi
 29ea885:	mov    0x14(%rdi),%r15d
 29ea889:	mov    0x18(%rdi),%eax
 29ea88c:	mov    0x1c(%rdi),%r14d
 29ea890:	test   %r15d,%r15d
 29ea893:	je     29fc069 <wasm[0]::function[1015]::helper::object_read+0x1b0e9>
 29ea899:	test   %r15d,%r15d
 29ea89c:	je     29fc06b <wasm[0]::function[1015]::helper::object_read+0x1b0eb>
 29ea8a2:	mov    %r15d,%r8d
 29ea8a5:	lea    0x10(%r12,%r8,1),%rdi
 29ea8aa:	cmp    %rsi,%r8
 29ea8ad:	cmova  %r13,%rdi
 29ea8b1:	mov    (%rdi),%edi
 29ea8b3:	cmp    %edi,%ecx
 29ea8b5:	jae    29fc06d <wasm[0]::function[1015]::helper::object_read+0x1b0ed>
 29ea8bb:	mov    %edi,%r8d
 29ea8be:	shr    $0x20,%r8
 29ea8c2:	test   %r8,%r8
 29ea8c5:	jne    29fc06f <wasm[0]::function[1015]::helper::object_read+0x1b0ef>
 29ea8cb:	add    $0x14,%edi
 29ea8ce:	jb     29fc071 <wasm[0]::function[1015]::helper::object_read+0x1b0f1>
 29ea8d4:	add    %edi,%r15d
 29ea8d7:	jb     29fc073 <wasm[0]::function[1015]::helper::object_read+0x1b0f3>
 29ea8dd:	mov    %r15d,%r8d
 29ea8e0:	add    %r8,%r12
 29ea8e3:	cmp    %rsi,%r8
 29ea8e6:	cmova  %r13,%r12
 29ea8ea:	lea    0x14(%rcx),%esi
 29ea8ed:	sub    %esi,%edi
 29ea8ef:	sub    %rdi,%r12
 29ea8f2:	movzbq (%r12),%rsi
 29ea8f7:	mov    %rsi,%r8
 29ea8fa:	test   %eax,%eax
 29ea8fc:	je     29ea98f <wasm[0]::function[1015]::helper::object_read+0x9a0f>
 29ea902:	test   %eax,%eax
 29ea904:	je     29fc075 <wasm[0]::function[1015]::helper::object_read+0x1b0f5>
 29ea90a:	test   %eax,%eax
 29ea90c:	je     29fc077 <wasm[0]::function[1015]::helper::object_read+0x1b0f7>
 29ea912:	mov    0x2e0(%rsp),%r12
 29ea91a:	mov    0x28(%r12),%rsi
 29ea91f:	mov    0x20(%r12),%r12
 29ea924:	mov    %eax,%r15d
 29ea927:	lea    0x10(%r12,%r15,1),%rdi
 29ea92c:	xor    %r13,%r13
 29ea92f:	cmp    %rsi,%r15
 29ea932:	cmova  %r13,%rdi
 29ea936:	mov    (%rdi),%r15d
 29ea939:	cmp    %r15d,%ecx
 29ea93c:	jae    29fc079 <wasm[0]::function[1015]::helper::object_read+0x1b0f9>
 29ea942:	mov    %r15d,%edi
 29ea945:	shl    $0x3,%rdi
 29ea949:	shr    $0x20,%rdi
 29ea94d:	test   %rdi,%rdi
 29ea950:	jne    29fc07b <wasm[0]::function[1015]::helper::object_read+0x1b0fb>
 29ea956:	shl    $0x3,%r15d
 29ea95a:	add    $0x18,%r15d
 29ea95e:	jb     29fc07d <wasm[0]::function[1015]::helper::object_read+0x1b0fd>
 29ea964:	add    %r15d,%eax
 29ea967:	jb     29fc07f <wasm[0]::function[1015]::helper::object_read+0x1b0ff>
 29ea96d:	mov    %eax,%edi
 29ea96f:	lea    (%r12,%rdi,1),%rax
 29ea973:	cmp    %rsi,%rdi
 29ea976:	cmova  %r13,%rax
 29ea97a:	mov    %rcx,%rsi
 29ea97d:	shl    $0x3,%esi
 29ea980:	add    $0x18,%esi
 29ea986:	sub    %esi,%r15d
 29ea989:	sub    %r15,%rax
 29ea98c:	mov    (%rax),%r13
 29ea98f:	xor    %r15d,%r15d
 29ea992:	test   %r14d,%r14d
 29ea995:	jne    29ea9a3 <wasm[0]::function[1015]::helper::object_read+0x9a23>
 29ea99b:	mov    %r8,%rax
 29ea99e:	jmp    29eaa2f <wasm[0]::function[1015]::helper::object_read+0x9aaf>
 29ea9a3:	test   %r14d,%r14d
 29ea9a6:	je     29fc081 <wasm[0]::function[1015]::helper::object_read+0x1b101>
 29ea9ac:	test   %r14d,%r14d
 29ea9af:	je     29fc083 <wasm[0]::function[1015]::helper::object_read+0x1b103>
 29ea9b5:	mov    0x2e0(%rsp),%r12
 29ea9bd:	mov    0x28(%r12),%rax
 29ea9c2:	mov    0x20(%r12),%rsi
 29ea9c7:	mov    %r14d,%r12d
 29ea9ca:	lea    0x10(%rsi,%r12,1),%rdi
 29ea9cf:	xor    %r15,%r15
 29ea9d2:	cmp    %rax,%r12
 29ea9d5:	cmova  %r15,%rdi
 29ea9d9:	mov    (%rdi),%r12d
 29ea9dc:	cmp    %r12d,%ecx
 29ea9df:	jae    29fc085 <wasm[0]::function[1015]::helper::object_read+0x1b105>
 29ea9e5:	mov    %r12d,%edi
 29ea9e8:	shl    $0x2,%rdi
 29ea9ec:	shr    $0x20,%rdi
 29ea9f0:	test   %rdi,%rdi
 29ea9f3:	jne    29fc087 <wasm[0]::function[1015]::helper::object_read+0x1b107>
 29ea9f9:	shl    $0x2,%r12d
 29ea9fd:	add    $0x14,%r12d
 29eaa01:	jb     29fc089 <wasm[0]::function[1015]::helper::object_read+0x1b109>
 29eaa07:	add    %r12d,%r14d
 29eaa0a:	jb     29fc08b <wasm[0]::function[1015]::helper::object_read+0x1b10b>
 29eaa10:	mov    %r14d,%edi
 29eaa13:	add    %rdi,%rsi
 29eaa16:	cmp    %rax,%rdi
 29eaa19:	cmova  %r15,%rsi
 29eaa1d:	shl    $0x2,%ecx
 29eaa20:	lea    0x14(%rcx),%eax
 29eaa23:	sub    %eax,%r12d
 29eaa26:	sub    %r12,%rsi
 29eaa29:	mov    (%rsi),%r15d
 29eaa2c:	mov    %r8,%rax
 29eaa2f:	movzbl %al,%r14d
 29eaa33:	mov    %r14,0x1a0(%rsp)
 29eaa3b:	mov    %r13,0x1c8(%rsp)
 29eaa43:	jmp    29eabdf <wasm[0]::function[1015]::helper::object_read+0x9c5f>
 29eaa48:	xor    %eax,%eax
 29eaa4a:	test   $0x1,%r14d
 29eaa51:	jne    29eaa95 <wasm[0]::function[1015]::helper::object_read+0x9b15>
 29eaa57:	mov    0x2e0(%rsp),%r12
 29eaa5f:	mov    0x28(%r12),%rax
 29eaa64:	mov    0x20(%r12),%rsi
 29eaa69:	mov    %r14d,%edi
 29eaa6c:	lea    0x4(%rsi,%rdi,1),%rsi
 29eaa71:	xor    %r12,%r12
 29eaa74:	cmp    %rax,%rdi
 29eaa77:	cmova  %r12,%rsi
 29eaa7b:	mov    (%rsi),%eax
 29eaa7d:	mov    0x190(%rsp),%rsi
 29eaa85:	mov    0x28(%rsi),%rsi
 29eaa89:	cmp    0x160(%rsi),%eax
 29eaa8f:	sete   %al
 29eaa92:	movzbl %al,%eax
 29eaa95:	test   %eax,%eax
 29eaa97:	je     29fc08d <wasm[0]::function[1015]::helper::object_read+0x1b10d>
 29eaa9d:	test   %r14d,%r14d
 29eaaa0:	je     29fc08f <wasm[0]::function[1015]::helper::object_read+0x1b10f>
 29eaaa6:	mov    0x2e0(%rsp),%r12
 29eaaae:	mov    0x28(%r12),%rsi
 29eaab3:	mov    0x20(%r12),%r12
 29eaab8:	mov    %r14d,%eax
 29eaabb:	lea    (%r12,%rax,1),%rdi
 29eaabf:	xor    %r13,%r13
 29eaac2:	cmp    %rsi,%rax
 29eaac5:	cmova  %r13,%rdi
 29eaac9:	mov    0x10(%rdi),%edi
 29eaacc:	test   %edi,%edi
 29eaace:	je     29fc091 <wasm[0]::function[1015]::helper::object_read+0x1b111>
 29eaad4:	test   %edi,%edi
 29eaad6:	je     29fc093 <wasm[0]::function[1015]::helper::object_read+0x1b113>
 29eaadc:	mov    %edi,%r8d
 29eaadf:	lea    (%r12,%r8,1),%rdi
 29eaae3:	cmp    %rsi,%r8
 29eaae6:	cmova  %r13,%rdi
 29eaaea:	mov    0x10(%rdi),%edi
 29eaaed:	test   %edi,%edi
 29eaaef:	je     29fc095 <wasm[0]::function[1015]::helper::object_read+0x1b115>
 29eaaf5:	test   %edi,%edi
 29eaaf7:	je     29fc097 <wasm[0]::function[1015]::helper::object_read+0x1b117>
 29eaafd:	mov    %edi,%r8d
 29eab00:	lea    0x10(%r12,%r8,1),%rdi
 29eab05:	cmp    %rsi,%r8
 29eab08:	cmova  %r13,%rdi
 29eab0c:	cmp    (%rdi),%ecx
 29eab0e:	setae  %sil
 29eab12:	cmp    $0x2,%ecx
 29eab15:	setae  %dil
 29eab19:	or     %edi,%esi
 29eab1b:	test   %sil,%sil
 29eab1e:	jne    29fc099 <wasm[0]::function[1015]::helper::object_read+0x1b119>
 29eab24:	mov    0x2e0(%rsp),%r12
 29eab2c:	mov    0x28(%r12),%rdi
 29eab31:	mov    %rax,%rsi
 29eab34:	add    0x20(%r12),%rsi
 29eab39:	xor    %r12,%r12
 29eab3c:	cmp    %rdi,%rax
 29eab3f:	cmova  %r12,%rsi
 29eab43:	mov    0x14(%rsi),%r14d
 29eab47:	mov    %r14,0x1a0(%rsp)
 29eab4f:	test   %ecx,%ecx
 29eab51:	je     29eab8b <wasm[0]::function[1015]::helper::object_read+0x9c0b>
 29eab57:	mov    0x2e0(%rsp),%r12
 29eab5f:	mov    0x28(%r12),%rdi
 29eab64:	mov    0x20(%r12),%rsi
 29eab69:	add    %rax,%rsi
 29eab6c:	xor    %r12,%r12
 29eab6f:	cmp    %rdi,%rax
 29eab72:	cmova  %r12,%rsi
 29eab76:	mov    0x20(%rsi),%r13
 29eab7a:	mov    0x2c(%rsi),%r15d
 29eab7e:	mov    %r13,0x1c8(%rsp)
 29eab86:	jmp    29eabba <wasm[0]::function[1015]::helper::object_read+0x9c3a>
 29eab8b:	mov    0x2e0(%rsp),%r12
 29eab93:	mov    0x28(%r12),%rdi
 29eab98:	mov    0x20(%r12),%rsi
 29eab9d:	add    %rax,%rsi
 29eaba0:	xor    %r12,%r12
 29eaba3:	cmp    %rdi,%rax
 29eaba6:	cmova  %r12,%rsi
 29eabaa:	mov    0x18(%rsi),%r13
 29eabae:	mov    %r13,0x1c8(%rsp)
 29eabb6:	mov    0x28(%rsi),%r15d
 29eabba:	shl    $0x3,%ecx
 29eabbd:	mov    0x1a0(%rsp),%r14
 29eabc5:	shr    %cl,%r14d
 29eabc8:	mov    %r14,0x1a0(%rsp)
 29eabd0:	and    $0xff,%r14d
 29eabd7:	mov    %r14,0x1a0(%rsp)
 29eabdf:	mov    0x1f8(%rsp),%rax
 29eabe7:	mov    %eax,0xc8(%rsp)
 29eabee:	mov    0x208(%rsp),%rsi
 29eabf6:	mov    %esi,0x108(%rsp)
 29eabfd:	mov    %r15d,0x120(%rsp)
 29eac05:	mov    0x218(%rsp),%rdi
 29eac0d:	mov    %edi,0x138(%rsp)
 29eac14:	mov    0x220(%rsp),%r8
 29eac1c:	mov    %r8d,0x110(%rsp)
 29eac24:	mov    0x198(%rsp),%rax
 29eac2c:	mov    %eax,0xd8(%rsp)
 29eac33:	mov    %r9d,0x130(%rsp)
 29eac3b:	mov    %r10d,0xa0(%rsp)
 29eac43:	mov    %edx,0x118(%rsp)
 29eac4a:	mov    %r11d,0xe0(%rsp)
 29eac52:	mov    %ebx,0x100(%rsp)
 29eac59:	mov    $0x287,%edx
 29eac5e:	mov    0x190(%rsp),%rsi
 29eac66:	mov    0x190(%rsp),%rdi
 29eac6e:	call   2f30600 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 29eac73:	mov    %eax,0x88(%rsp)
 29eac7a:	xor    %edi,%edi
 29eac7c:	test   %eax,%eax
 29eac7e:	je     29fc09b <wasm[0]::function[1015]::helper::object_read+0x1b11b>
 29eac84:	movl   $0x0,0xf8(%rsp)
 29eac8f:	mov    0x108(%rsp),%r8d
 29eac97:	mov    0x120(%rsp),%r9d
 29eac9f:	mov    0x138(%rsp),%r10d
 29eaca7:	mov    %r10,0x1d0(%rsp)
 29eacaf:	mov    0x110(%rsp),%r11d
 29eacb7:	mov    %r11,0x1d8(%rsp)
 29eacbf:	mov    0xd8(%rsp),%r13d
 29eacc7:	mov    %r13,0x1e0(%rsp)
 29eaccf:	mov    0x130(%rsp),%r11d
 29eacd7:	mov    %r11,0x1e8(%rsp)
 29eacdf:	mov    0xa0(%rsp),%ebx
 29eace6:	mov    %rbx,0x1f0(%rsp)
 29eacee:	mov    0x118(%rsp),%ebx
 29eacf5:	mov    0xe0(%rsp),%r15d
 29eacfd:	mov    0x100(%rsp),%r14d
 29ead05:	xor    %rsi,%rsi
 29ead08:	mov    0x2a0(%rsp),%rax
 29ead10:	mov    0x2a0(%rsp),%rcx
 29ead18:	test   %al,%cl
 29ead1a:	jne    29ead30 <wasm[0]::function[1015]::helper::object_read+0x9db0>
 29ead20:	mov    %rdi,%rdx
 29ead23:	mov    0x1d0(%rsp),%r10
 29ead2b:	jmp    29eba24 <wasm[0]::function[1015]::helper::object_read+0xaaa4>
 29ead30:	mov    0xc8(%rsp),%r8d
 29ead38:	mov    0x2b0(%rsp),%rcx
 29ead40:	mov    0x2a8(%rsp),%rdx
 29ead48:	mov    0x190(%rsp),%rsi
 29ead50:	mov    0x190(%rsp),%rdi
 29ead58:	call   2a5f680 <wasm[0]::function[1039]::helper::object_header_projection>
 29ead5d:	mov    %eax,0xc8(%rsp)
 29ead64:	test   %eax,%eax
 29ead66:	je     29fc09d <wasm[0]::function[1015]::helper::object_read+0x1b11d>
 29ead6c:	test   %eax,%eax
 29ead6e:	je     29fc09f <wasm[0]::function[1015]::helper::object_read+0x1b11f>
 29ead74:	mov    0x2e0(%rsp),%r12
 29ead7c:	mov    0x28(%r12),%rcx
 29ead81:	mov    0x20(%r12),%rsi
 29ead86:	mov    %eax,%edx
 29ead88:	lea    (%rsi,%rdx,1),%rax
 29ead8c:	xor    %rsi,%rsi
 29ead8f:	cmp    %rcx,%rdx
 29ead92:	cmova  %rsi,%rax
 29ead96:	mov    0x14(%rax),%eax
 29ead99:	mov    %eax,0x78(%rsp)
 29ead9d:	test   %eax,%eax
 29ead9f:	je     29fc0a1 <wasm[0]::function[1015]::helper::object_read+0x1b121>
 29eada5:	mov    0x78(%rsp),%ecx
 29eada9:	xor    %eax,%eax
 29eadab:	test   $0x1,%ecx
 29eadb1:	jne    29eae0b <wasm[0]::function[1015]::helper::object_read+0x9e8b>
 29eadb7:	mov    0x2e0(%rsp),%r12
 29eadbf:	mov    0x28(%r12),%rax
 29eadc4:	mov    0x20(%r12),%rsi
 29eadc9:	mov    %ecx,%edx
 29eadcb:	lea    0x4(%rsi,%rdx,1),%rcx
 29eadd0:	xor    %rsi,%rsi
 29eadd3:	cmp    %rax,%rdx
 29eadd6:	cmova  %rsi,%rcx
 29eadda:	mov    (%rcx),%esi
 29eaddc:	mov    0x190(%rsp),%rcx
 29eade4:	mov    0x28(%rcx),%rax
 29eade8:	mov    0x158(%rax),%edx
 29eadee:	cmp    %edx,%esi
 29eadf0:	sete   %al
 29eadf3:	movzbl %al,%eax
 29eadf6:	cmp    %edx,%esi
 29eadf8:	je     29eae0b <wasm[0]::function[1015]::helper::object_read+0x9e8b>
 29eadfe:	mov    0x190(%rsp),%rdi
 29eae06:	call   3018cd5 <wasmtime_builtin_is_subtype>
 29eae0b:	test   %eax,%eax
 29eae0d:	jne    29eb098 <wasm[0]::function[1015]::helper::object_read+0xa118>
 29eae13:	mov    0xc8(%rsp),%edx
 29eae1a:	xor    %r15d,%r15d
 29eae1d:	test   %edx,%edx
 29eae1f:	je     29fc0a3 <wasm[0]::function[1015]::helper::object_read+0x1b123>
 29eae25:	mov    0x88(%rsp),%r9d
 29eae2d:	mov    $0x4,%ecx
 29eae32:	xor    %r8,%r8
 29eae35:	mov    0x190(%rsp),%rsi
 29eae3d:	mov    0x190(%rsp),%rdi
 29eae45:	call   2a58e80 <wasm[0]::function[1032]::helper::ordinary_property_find>
 29eae4a:	test   %eax,%eax
 29eae4c:	je     29eae87 <wasm[0]::function[1015]::helper::object_read+0x9f07>
 29eae52:	test   %eax,%eax
 29eae54:	je     29fc0a5 <wasm[0]::function[1015]::helper::object_read+0x1b125>
 29eae5a:	test   %eax,%eax
 29eae5c:	je     29fc0a7 <wasm[0]::function[1015]::helper::object_read+0x1b127>
 29eae62:	mov    0x2e0(%rsp),%r12
 29eae6a:	mov    0x28(%r12),%rcx
 29eae6f:	mov    %eax,%edx
 29eae71:	mov    %rdx,%rax
 29eae74:	add    0x20(%r12),%rax
 29eae79:	xor    %rsi,%rsi
 29eae7c:	cmp    %rcx,%rdx
 29eae7f:	cmova  %rsi,%rax
 29eae83:	mov    0x14(%rax),%r15d
 29eae87:	mov    0xf8(%rsp),%edx
 29eae8e:	xor    %edi,%edi
 29eae90:	xor    %rsi,%rsi
 29eae93:	test   %r15d,%r15d
 29eae96:	je     29eb01d <wasm[0]::function[1015]::helper::object_read+0xa09d>
 29eae9c:	test   %r15d,%r15d
 29eae9f:	je     29fc0a9 <wasm[0]::function[1015]::helper::object_read+0x1b129>
 29eaea5:	mov    0x2e0(%rsp),%r12
 29eaead:	mov    0x28(%r12),%rcx
 29eaeb2:	mov    0x20(%r12),%rax
 29eaeb7:	mov    %r15d,%edx
 29eaeba:	add    %rdx,%rax
 29eaebd:	xor    %rsi,%rsi
 29eaec0:	cmp    %rcx,%rdx
 29eaec3:	cmova  %rsi,%rax
 29eaec7:	mov    0x10(%rax),%ecx
 29eaeca:	mov    0xf8(%rsp),%edx
 29eaed1:	xor    %edi,%edi
 29eaed3:	test   $0x1,%ecx
 29eaed9:	jne    29eb01d <wasm[0]::function[1015]::helper::object_read+0xa09d>
 29eaedf:	mov    0x14(%rax),%edx
 29eaee2:	test   %edx,%edx
 29eaee4:	je     29fc0ab <wasm[0]::function[1015]::helper::object_read+0x1b12b>
 29eaeea:	xor    %edi,%edi
 29eaeec:	test   $0x1,%edx
 29eaef2:	jne    29eaf37 <wasm[0]::function[1015]::helper::object_read+0x9fb7>
 29eaef8:	mov    0x2e0(%rsp),%r12
 29eaf00:	mov    0x28(%r12),%rsi
 29eaf05:	mov    0x20(%r12),%r8
 29eaf0a:	mov    %edx,%edi
 29eaf0c:	lea    0x4(%r8,%rdi,1),%rax
 29eaf11:	xor    %r8,%r8
 29eaf14:	cmp    %rsi,%rdi
 29eaf17:	cmova  %r8,%rax
 29eaf1b:	mov    (%rax),%esi
 29eaf1d:	mov    0x190(%rsp),%rcx
 29eaf25:	mov    0x28(%rcx),%rdi
 29eaf29:	cmp    0x120(%rdi),%esi
 29eaf2f:	sete   %sil
 29eaf33:	movzbl %sil,%edi
 29eaf37:	test   %edi,%edi
 29eaf39:	jne    29eaf97 <wasm[0]::function[1015]::helper::object_read+0xa017>
 29eaf3f:	mov    0x190(%rsp),%rsi
 29eaf47:	mov    0x190(%rsp),%rdi
 29eaf4f:	call   2a01c00 <wasm[0]::function[1024]::helper::property_value_resolve>
 29eaf54:	test   %eax,%eax
 29eaf56:	je     29fc0ad <wasm[0]::function[1015]::helper::object_read+0x1b12d>
 29eaf5c:	test   %eax,%eax
 29eaf5e:	je     29fc0af <wasm[0]::function[1015]::helper::object_read+0x1b12f>
 29eaf64:	mov    0x2e0(%rsp),%r12
 29eaf6c:	mov    0x28(%r12),%r11
 29eaf71:	mov    0x20(%r12),%rcx
 29eaf76:	mov    %eax,%eax
 29eaf78:	lea    (%rcx,%rax,1),%r8
 29eaf7c:	xor    %rcx,%rcx
 29eaf7f:	cmp    %r11,%rax
 29eaf82:	cmova  %rcx,%r8
 29eaf86:	mov    0x18(%r8),%edi
 29eaf8a:	mov    0x10(%r8),%rsi
 29eaf8e:	mov    0x1c(%r8),%edx
 29eaf92:	jmp    29eb01d <wasm[0]::function[1015]::helper::object_read+0xa09d>
 29eaf97:	xor    %eax,%eax
 29eaf99:	test   $0x1,%edx
 29eaf9f:	jne    29eafe2 <wasm[0]::function[1015]::helper::object_read+0xa062>
 29eafa5:	mov    0x2e0(%rsp),%r12
 29eafad:	mov    0x28(%r12),%rax
 29eafb2:	mov    0x20(%r12),%rcx
 29eafb7:	mov    %edx,%esi
 29eafb9:	lea    0x4(%rcx,%rsi,1),%rcx
 29eafbe:	xor    %rdi,%rdi
 29eafc1:	cmp    %rax,%rsi
 29eafc4:	cmova  %rdi,%rcx
 29eafc8:	mov    (%rcx),%eax
 29eafca:	mov    0x190(%rsp),%rcx
 29eafd2:	mov    0x28(%rcx),%rcx
 29eafd6:	cmp    0x120(%rcx),%eax
 29eafdc:	sete   %al
 29eafdf:	movzbl %al,%eax
 29eafe2:	test   %eax,%eax
 29eafe4:	je     29fc0b1 <wasm[0]::function[1015]::helper::object_read+0x1b131>
 29eafea:	test   %edx,%edx
 29eafec:	je     29fc0b3 <wasm[0]::function[1015]::helper::object_read+0x1b133>
 29eaff2:	mov    0x2e0(%rsp),%r12
 29eaffa:	mov    0x28(%r12),%rcx
 29eafff:	mov    0x20(%r12),%rax
 29eb004:	mov    %edx,%edx
 29eb006:	add    %rdx,%rax
 29eb009:	xor    %rsi,%rsi
 29eb00c:	cmp    %rcx,%rdx
 29eb00f:	cmova  %rsi,%rax
 29eb013:	mov    0x18(%rax),%edi
 29eb016:	mov    0x10(%rax),%rsi
 29eb01a:	mov    0x1c(%rax),%edx
 29eb01d:	mov    0x108(%rsp),%r8d
 29eb025:	mov    0x120(%rsp),%r9d
 29eb02d:	mov    0x138(%rsp),%r10d
 29eb035:	mov    %r10,0x1d0(%rsp)
 29eb03d:	mov    0x110(%rsp),%r11d
 29eb045:	mov    %r11,0x1d8(%rsp)
 29eb04d:	mov    0xd8(%rsp),%r13d
 29eb055:	mov    %r13,0x1e0(%rsp)
 29eb05d:	mov    0x130(%rsp),%r11d
 29eb065:	mov    %r11,0x1e8(%rsp)
 29eb06d:	mov    0xa0(%rsp),%ebx
 29eb074:	mov    %rbx,0x1f0(%rsp)
 29eb07c:	mov    0x118(%rsp),%ebx
 29eb083:	mov    0xe0(%rsp),%r15d
 29eb08b:	mov    0x100(%rsp),%r14d
 29eb093:	jmp    29eba1c <wasm[0]::function[1015]::helper::object_read+0xaa9c>
 29eb098:	mov    0x78(%rsp),%eax
 29eb09c:	test   %eax,%eax
 29eb09e:	je     29fc0b5 <wasm[0]::function[1015]::helper::object_read+0x1b135>
 29eb0a4:	mov    0x78(%rsp),%ecx
 29eb0a8:	xor    %eax,%eax
 29eb0aa:	test   $0x1,%ecx
 29eb0b0:	jne    29eb10a <wasm[0]::function[1015]::helper::object_read+0xa18a>
 29eb0b6:	mov    0x2e0(%rsp),%r12
 29eb0be:	mov    0x28(%r12),%rax
 29eb0c3:	mov    0x20(%r12),%rsi
 29eb0c8:	mov    %ecx,%edx
 29eb0ca:	lea    0x4(%rsi,%rdx,1),%rcx
 29eb0cf:	xor    %rsi,%rsi
 29eb0d2:	cmp    %rax,%rdx
 29eb0d5:	cmova  %rsi,%rcx
 29eb0d9:	mov    (%rcx),%esi
 29eb0db:	mov    0x190(%rsp),%rcx
 29eb0e3:	mov    0x28(%rcx),%rax
 29eb0e7:	mov    0x158(%rax),%edx
 29eb0ed:	cmp    %edx,%esi
 29eb0ef:	sete   %al
 29eb0f2:	movzbl %al,%eax
 29eb0f5:	cmp    %edx,%esi
 29eb0f7:	je     29eb10a <wasm[0]::function[1015]::helper::object_read+0xa18a>
 29eb0fd:	mov    0x190(%rsp),%rdi
 29eb105:	call   3018cd5 <wasmtime_builtin_is_subtype>
 29eb10a:	test   %eax,%eax
 29eb10c:	je     29fc0b7 <wasm[0]::function[1015]::helper::object_read+0x1b137>
 29eb112:	mov    0x78(%rsp),%r10d
 29eb117:	mov    0x108(%rsp),%r8d
 29eb11f:	mov    0x120(%rsp),%r9d
 29eb127:	mov    0xf8(%rsp),%edx
 29eb12e:	mov    0x138(%rsp),%eax
 29eb135:	mov    %rax,0x1d0(%rsp)
 29eb13d:	mov    0x110(%rsp),%r11d
 29eb145:	mov    %r11,0x1d8(%rsp)
 29eb14d:	mov    0xd8(%rsp),%r13d
 29eb155:	mov    %r13,0x1e0(%rsp)
 29eb15d:	mov    0x130(%rsp),%r11d
 29eb165:	mov    %r11,0x1e8(%rsp)
 29eb16d:	mov    0xa0(%rsp),%ebx
 29eb174:	mov    %rbx,0x1f0(%rsp)
 29eb17c:	mov    0x118(%rsp),%ebx
 29eb183:	mov    0xe0(%rsp),%r15d
 29eb18b:	mov    0x100(%rsp),%r14d
 29eb193:	xor    %ecx,%ecx
 29eb195:	mov    %rcx,0x208(%rsp)
 29eb19d:	test   %r10d,%r10d
 29eb1a0:	je     29fc0b9 <wasm[0]::function[1015]::helper::object_read+0x1b139>
 29eb1a6:	test   %r10d,%r10d
 29eb1a9:	je     29fc0bb <wasm[0]::function[1015]::helper::object_read+0x1b13b>
 29eb1af:	mov    0x2e0(%rsp),%r12
 29eb1b7:	mov    0x28(%r12),%rax
 29eb1bc:	mov    0x20(%r12),%rcx
 29eb1c1:	mov    %r10d,%r12d
 29eb1c4:	lea    (%rcx,%r12,1),%rsi
 29eb1c8:	xor    %rdi,%rdi
 29eb1cb:	cmp    %rax,%r12
 29eb1ce:	cmova  %rdi,%rsi
 29eb1d2:	mov    0x10(%rsi),%esi
 29eb1d5:	test   %esi,%esi
 29eb1d7:	je     29fc0bd <wasm[0]::function[1015]::helper::object_read+0x1b13d>
 29eb1dd:	test   %esi,%esi
 29eb1df:	je     29fc0bf <wasm[0]::function[1015]::helper::object_read+0x1b13f>
 29eb1e5:	mov    %esi,%r12d
 29eb1e8:	lea    (%rcx,%r12,1),%rsi
 29eb1ec:	cmp    %rax,%r12
 29eb1ef:	cmova  %rdi,%rsi
 29eb1f3:	mov    0x10(%rsi),%esi
 29eb1f6:	test   %esi,%esi
 29eb1f8:	je     29fc0c1 <wasm[0]::function[1015]::helper::object_read+0x1b141>
 29eb1fe:	test   %esi,%esi
 29eb200:	je     29fc0c3 <wasm[0]::function[1015]::helper::object_read+0x1b143>
 29eb206:	mov    %esi,%r12d
 29eb209:	lea    0x10(%rcx,%r12,1),%rcx
 29eb20e:	cmp    %rax,%r12
 29eb211:	cmova  %rdi,%rcx
 29eb215:	mov    (%rcx),%r13d
 29eb218:	mov    %r13,0x220(%rsp)
 29eb220:	mov    0x88(%rsp),%edi
 29eb227:	mov    0x190(%rsp),%rcx
 29eb22f:	mov    0x28(%rcx),%rax
 29eb233:	mov    0x234(%rax),%r13d
 29eb23a:	mov    %r13,0x218(%rsp)
 29eb242:	mov    0x208(%rsp),%rax
 29eb24a:	mov    %rax,0x198(%rsp)
 29eb252:	mov    %esi,0xc8(%rsp)
 29eb259:	mov    %edi,0x100(%rsp)
 29eb260:	mov    %r10d,0xe0(%rsp)
 29eb268:	mov    %r8d,0x118(%rsp)
 29eb270:	mov    %r9d,0xa0(%rsp)
 29eb278:	mov    %edx,0x130(%rsp)
 29eb27f:	mov    0x1d0(%rsp),%r10
 29eb287:	mov    %r10d,0xd8(%rsp)
 29eb28f:	mov    0x1d8(%rsp),%r11
 29eb297:	mov    %r11d,0x110(%rsp)
 29eb29f:	mov    0x1e0(%rsp),%r13
 29eb2a7:	mov    %r13d,0x138(%rsp)
 29eb2af:	mov    0x1e8(%rsp),%r11
 29eb2b7:	mov    %r11d,0xf8(%rsp)
 29eb2bf:	mov    0x1f0(%rsp),%rax
 29eb2c7:	mov    %eax,0x120(%rsp)
 29eb2ce:	mov    %ebx,0x108(%rsp)
 29eb2d5:	mov    %r15d,0x78(%rsp)
 29eb2da:	mov    %r14d,0x88(%rsp)
 29eb2e2:	mov    0x2e8(%rsp),%r13
 29eb2ea:	mov    0x0(%r13),%rcx
 29eb2ee:	mov    0x228(%rsp),%rax
 29eb2f6:	cmp    %rax,%rcx
 29eb2f9:	jae    29fab2c <wasm[0]::function[1015]::helper::object_read+0x19bac>
 29eb2ff:	mov    0xe0(%rsp),%r10d
 29eb307:	mov    0x118(%rsp),%r8d
 29eb30f:	mov    0xa0(%rsp),%r9d
 29eb317:	mov    0x130(%rsp),%edx
 29eb31e:	mov    0xd8(%rsp),%ecx
 29eb325:	mov    %rcx,0x1d0(%rsp)
 29eb32d:	mov    0x110(%rsp),%r11d
 29eb335:	mov    %r11,0x1d8(%rsp)
 29eb33d:	mov    0x138(%rsp),%r13d
 29eb345:	mov    %r13,0x1e0(%rsp)
 29eb34d:	mov    0xf8(%rsp),%r11d
 29eb355:	mov    %r11,0x1e8(%rsp)
 29eb35d:	mov    0x120(%rsp),%ebx
 29eb364:	mov    %rbx,0x1f0(%rsp)
 29eb36c:	mov    0x108(%rsp),%ebx
 29eb373:	mov    0x78(%rsp),%r15d
 29eb378:	mov    0x88(%rsp),%r14d
 29eb380:	mov    0x208(%rsp),%rcx
 29eb388:	mov    0x220(%rsp),%rsi
 29eb390:	cmp    %esi,%ecx
 29eb392:	jb     29eb3a5 <wasm[0]::function[1015]::helper::object_read+0xa425>
 29eb398:	mov    0x198(%rsp),%rax
 29eb3a0:	jmp    29eb624 <wasm[0]::function[1015]::helper::object_read+0xa6a4>
 29eb3a5:	mov    0xc8(%rsp),%r8d
 29eb3ad:	test   %r8d,%r8d
 29eb3b0:	je     29fc0c5 <wasm[0]::function[1015]::helper::object_read+0x1b145>
 29eb3b6:	test   %r8d,%r8d
 29eb3b9:	je     29fc0c7 <wasm[0]::function[1015]::helper::object_read+0x1b147>
 29eb3bf:	mov    0x2e0(%rsp),%r12
 29eb3c7:	mov    0x28(%r12),%rax
 29eb3cc:	mov    0x20(%r12),%rdx
 29eb3d1:	mov    %r8d,%r9d
 29eb3d4:	lea    0x10(%rdx,%r9,1),%rdi
 29eb3d9:	xor    %rsi,%rsi
 29eb3dc:	cmp    %rax,%r9
 29eb3df:	cmova  %rsi,%rdi
 29eb3e3:	mov    (%rdi),%edi
 29eb3e5:	cmp    %edi,%ecx
 29eb3e7:	jae    29fc0c9 <wasm[0]::function[1015]::helper::object_read+0x1b149>
 29eb3ed:	mov    %edi,%r9d
 29eb3f0:	shl    $0x2,%r9
 29eb3f4:	shr    $0x20,%r9
 29eb3f8:	test   %r9,%r9
 29eb3fb:	jne    29fc0cb <wasm[0]::function[1015]::helper::object_read+0x1b14b>
 29eb401:	shl    $0x2,%edi
 29eb404:	add    $0x14,%edi
 29eb407:	jb     29fc0cd <wasm[0]::function[1015]::helper::object_read+0x1b14d>
 29eb40d:	add    %edi,%r8d
 29eb410:	jb     29fc0cf <wasm[0]::function[1015]::helper::object_read+0x1b14f>
 29eb416:	mov    %r8d,%r8d
 29eb419:	add    %r8,%rdx
 29eb41c:	cmp    %rax,%r8
 29eb41f:	cmova  %rsi,%rdx
 29eb423:	mov    %rcx,%rax
 29eb426:	shl    $0x2,%eax
 29eb429:	mov    %rcx,0x208(%rsp)
 29eb431:	add    $0x14,%eax
 29eb437:	sub    %eax,%edi
 29eb439:	sub    %rdi,%rdx
 29eb43c:	mov    (%rdx),%edx
 29eb43e:	test   %edx,%edx
 29eb440:	je     29fc0d1 <wasm[0]::function[1015]::helper::object_read+0x1b151>
 29eb446:	mov    0x100(%rsp),%eax
 29eb44d:	cmp    %eax,%edx
 29eb44f:	je     29eb546 <wasm[0]::function[1015]::helper::object_read+0xa5c6>
 29eb455:	xor    %ecx,%ecx
 29eb457:	test   %edx,%edx
 29eb459:	jne    29eb46c <wasm[0]::function[1015]::helper::object_read+0xa4ec>
 29eb45f:	mov    0x218(%rsp),%r13
 29eb467:	jmp    29eb4bd <wasm[0]::function[1015]::helper::object_read+0xa53d>
 29eb46c:	xor    %ecx,%ecx
 29eb46e:	test   $0x1,%edx
 29eb474:	je     29eb487 <wasm[0]::function[1015]::helper::object_read+0xa507>
 29eb47a:	mov    0x218(%rsp),%r13
 29eb482:	jmp    29eb4bd <wasm[0]::function[1015]::helper::object_read+0xa53d>
 29eb487:	mov    0x2e0(%rsp),%r12
 29eb48f:	mov    0x28(%r12),%rcx
 29eb494:	mov    0x20(%r12),%rsi
 29eb499:	mov    %edx,%edi
 29eb49b:	lea    0x4(%rsi,%rdi,1),%rsi
 29eb4a0:	xor    %r8,%r8
 29eb4a3:	cmp    %rcx,%rdi
 29eb4a6:	cmova  %r8,%rsi
 29eb4aa:	mov    (%rsi),%ecx
 29eb4ac:	mov    0x218(%rsp),%r13
 29eb4b4:	cmp    %r13d,%ecx
 29eb4b7:	sete   %cl
 29eb4ba:	movzbl %cl,%ecx
 29eb4bd:	test   %ecx,%ecx
 29eb4bf:	je     29fc0d3 <wasm[0]::function[1015]::helper::object_read+0x1b153>
 29eb4c5:	xor    %edi,%edi
 29eb4c7:	test   %eax,%eax
 29eb4c9:	je     29eb512 <wasm[0]::function[1015]::helper::object_read+0xa592>
 29eb4cf:	mov    0x100(%rsp),%eax
 29eb4d6:	xor    %edi,%edi
 29eb4d8:	test   $0x1,%eax
 29eb4dd:	jne    29eb512 <wasm[0]::function[1015]::helper::object_read+0xa592>
 29eb4e3:	mov    0x2e0(%rsp),%r12
 29eb4eb:	mov    0x28(%r12),%rcx
 29eb4f0:	mov    0x20(%r12),%rdi
 29eb4f5:	mov    %eax,%esi
 29eb4f7:	lea    0x4(%rdi,%rsi,1),%rax
 29eb4fc:	xor    %rdi,%rdi
 29eb4ff:	cmp    %rcx,%rsi
 29eb502:	cmova  %rdi,%rax
 29eb506:	mov    (%rax),%eax
 29eb508:	cmp    %r13d,%eax
 29eb50b:	sete   %al
 29eb50e:	rex movzbl %al,%edi
 29eb512:	test   %edi,%edi
 29eb514:	je     29fc0d5 <wasm[0]::function[1015]::helper::object_read+0x1b155>
 29eb51a:	mov    0x100(%rsp),%ecx
 29eb521:	xor    %r8d,%r8d
 29eb524:	test   %ecx,%ecx
 29eb526:	je     29fc0d7 <wasm[0]::function[1015]::helper::object_read+0x1b157>
 29eb52c:	mov    0x190(%rsp),%rsi
 29eb534:	mov    0x190(%rsp),%rdi
 29eb53c:	call   2ae5540 <wasm[0]::function[1057]::helper::string_equality>
 29eb541:	jmp    29eb556 <wasm[0]::function[1015]::helper::object_read+0xa5d6>
 29eb546:	mov    0x218(%rsp),%r13
 29eb54e:	mov    0x278(%rsp),%rax
 29eb556:	mov    0xc8(%rsp),%esi
 29eb55d:	mov    0x100(%rsp),%edi
 29eb564:	mov    0xe0(%rsp),%r10d
 29eb56c:	mov    0x118(%rsp),%r8d
 29eb574:	mov    0xa0(%rsp),%r9d
 29eb57c:	mov    0x130(%rsp),%edx
 29eb583:	mov    0xd8(%rsp),%ecx
 29eb58a:	mov    %rcx,0x1d0(%rsp)
 29eb592:	mov    0x110(%rsp),%r11d
 29eb59a:	mov    %r11,0x1d8(%rsp)
 29eb5a2:	mov    0x138(%rsp),%ecx
 29eb5a9:	mov    %rcx,0x1e0(%rsp)
 29eb5b1:	mov    0xf8(%rsp),%r11d
 29eb5b9:	mov    %r11,0x1e8(%rsp)
 29eb5c1:	mov    0x120(%rsp),%ebx
 29eb5c8:	mov    %rbx,0x1f0(%rsp)
 29eb5d0:	mov    0x108(%rsp),%ebx
 29eb5d7:	mov    0x78(%rsp),%r15d
 29eb5dc:	mov    0x88(%rsp),%r14d
 29eb5e4:	test   %eax,%eax
 29eb5e6:	je     29eb5f9 <wasm[0]::function[1015]::helper::object_read+0xa679>
 29eb5ec:	mov    0x208(%rsp),%rcx
 29eb5f4:	jmp    29eb624 <wasm[0]::function[1015]::helper::object_read+0xa6a4>
 29eb5f9:	mov    0x208(%rsp),%rcx
 29eb601:	add    $0x1,%ecx
 29eb607:	mov    %rax,0x198(%rsp)
 29eb60f:	mov    %rcx,0x208(%rsp)
 29eb617:	mov    %r13,0x218(%rsp)
 29eb61f:	jmp    29eb252 <wasm[0]::function[1015]::helper::object_read+0xa2d2>
 29eb624:	xor    %edi,%edi
 29eb626:	xor    %rsi,%rsi
 29eb629:	test   %eax,%eax
 29eb62b:	je     29eba1c <wasm[0]::function[1015]::helper::object_read+0xaa9c>
 29eb631:	test   %r10d,%r10d
 29eb634:	je     29fc0d9 <wasm[0]::function[1015]::helper::object_read+0x1b159>
 29eb63a:	xor    %eax,%eax
 29eb63c:	test   $0x1,%r10d
 29eb643:	jne    29eb687 <wasm[0]::function[1015]::helper::object_read+0xa707>
 29eb649:	mov    0x2e0(%rsp),%r12
 29eb651:	mov    0x28(%r12),%rax
 29eb656:	mov    0x20(%r12),%rdx
 29eb65b:	mov    %r10d,%esi
 29eb65e:	lea    0x4(%rdx,%rsi,1),%rdx
 29eb663:	xor    %rdi,%rdi
 29eb666:	cmp    %rax,%rsi
 29eb669:	cmova  %rdi,%rdx
 29eb66d:	mov    (%rdx),%eax
 29eb66f:	mov    0x190(%rsp),%rdx
 29eb677:	mov    0x28(%rdx),%rdx
 29eb67b:	cmp    0x160(%rdx),%eax
 29eb681:	sete   %al
 29eb684:	movzbl %al,%eax
 29eb687:	test   %eax,%eax
 29eb689:	jne    29eb8b6 <wasm[0]::function[1015]::helper::object_read+0xa936>
 29eb68f:	xor    %eax,%eax
 29eb691:	test   $0x1,%r10d
 29eb698:	jne    29eb6dc <wasm[0]::function[1015]::helper::object_read+0xa75c>
 29eb69e:	mov    0x2e0(%rsp),%r12
 29eb6a6:	mov    0x28(%r12),%rax
 29eb6ab:	mov    0x20(%r12),%rdx
 29eb6b0:	mov    %r10d,%esi
 29eb6b3:	lea    0x4(%rdx,%rsi,1),%rdx
 29eb6b8:	xor    %rdi,%rdi
 29eb6bb:	cmp    %rax,%rsi
 29eb6be:	cmova  %rdi,%rdx
 29eb6c2:	mov    (%rdx),%eax
 29eb6c4:	mov    0x190(%rsp),%rdi
 29eb6cc:	mov    0x28(%rdi),%rdx
 29eb6d0:	cmp    0x15c(%rdx),%eax
 29eb6d6:	sete   %al
 29eb6d9:	movzbl %al,%eax
 29eb6dc:	test   %eax,%eax
 29eb6de:	je     29fc0db <wasm[0]::function[1015]::helper::object_read+0x1b15b>
 29eb6e4:	test   %r10d,%r10d
 29eb6e7:	je     29fc0dd <wasm[0]::function[1015]::helper::object_read+0x1b15d>
 29eb6ed:	mov    0x2e0(%rsp),%r12
 29eb6f5:	mov    0x28(%r12),%rdx
 29eb6fa:	mov    0x20(%r12),%r12
 29eb6ff:	mov    %r10d,%eax
 29eb702:	lea    (%r12,%rax,1),%rdi
 29eb706:	xor    %rsi,%rsi
 29eb709:	cmp    %rdx,%rax
 29eb70c:	cmova  %rsi,%rdi
 29eb710:	mov    0x14(%rdi),%r10d
 29eb714:	mov    0x18(%rdi),%eax
 29eb717:	mov    0x1c(%rdi),%edi
 29eb71a:	test   %r10d,%r10d
 29eb71d:	je     29fc0df <wasm[0]::function[1015]::helper::object_read+0x1b15f>
 29eb723:	test   %r10d,%r10d
 29eb726:	je     29fc0e1 <wasm[0]::function[1015]::helper::object_read+0x1b161>
 29eb72c:	mov    %r10d,%r11d
 29eb72f:	lea    0x10(%r12,%r11,1),%r13
 29eb734:	cmp    %rdx,%r11
 29eb737:	cmova  %rsi,%r13
 29eb73b:	mov    0x0(%r13),%r13d
 29eb73f:	cmp    %r13d,%ecx
 29eb742:	jae    29fc0e3 <wasm[0]::function[1015]::helper::object_read+0x1b163>
 29eb748:	mov    %r13d,%r11d
 29eb74b:	shr    $0x20,%r11
 29eb74f:	test   %r11,%r11
 29eb752:	jne    29fc0e5 <wasm[0]::function[1015]::helper::object_read+0x1b165>
 29eb758:	add    $0x14,%r13d
 29eb75c:	jb     29fc0e7 <wasm[0]::function[1015]::helper::object_read+0x1b167>
 29eb762:	add    %r13d,%r10d
 29eb765:	jb     29fc0e9 <wasm[0]::function[1015]::helper::object_read+0x1b169>
 29eb76b:	mov    %r10d,%r11d
 29eb76e:	lea    (%r12,%r11,1),%r10
 29eb772:	cmp    %rdx,%r11
 29eb775:	cmova  %rsi,%r10
 29eb779:	lea    0x14(%rcx),%edx
 29eb77c:	sub    %edx,%r13d
 29eb77f:	sub    %r13,%r10
 29eb782:	movzbq (%r10),%r11
 29eb786:	test   %eax,%eax
 29eb788:	je     29eb81d <wasm[0]::function[1015]::helper::object_read+0xa89d>
 29eb78e:	test   %eax,%eax
 29eb790:	je     29fc0eb <wasm[0]::function[1015]::helper::object_read+0x1b16b>
 29eb796:	test   %eax,%eax
 29eb798:	je     29fc0ed <wasm[0]::function[1015]::helper::object_read+0x1b16d>
 29eb79e:	mov    0x2e0(%rsp),%r12
 29eb7a6:	mov    0x28(%r12),%rdx
 29eb7ab:	mov    0x20(%r12),%rsi
 29eb7b0:	mov    %eax,%r10d
 29eb7b3:	lea    0x10(%rsi,%r10,1),%r13
 29eb7b8:	xor    %r12,%r12
 29eb7bb:	cmp    %rdx,%r10
 29eb7be:	cmova  %r12,%r13
 29eb7c2:	mov    0x0(%r13),%r13d
 29eb7c6:	cmp    %r13d,%ecx
 29eb7c9:	jae    29fc0ef <wasm[0]::function[1015]::helper::object_read+0x1b16f>
 29eb7cf:	mov    %r13d,%r10d
 29eb7d2:	shl    $0x3,%r10
 29eb7d6:	shr    $0x20,%r10
 29eb7da:	test   %r10,%r10
 29eb7dd:	jne    29fc0f1 <wasm[0]::function[1015]::helper::object_read+0x1b171>
 29eb7e3:	shl    $0x3,%r13d
 29eb7e7:	add    $0x18,%r13d
 29eb7eb:	jb     29fc0f3 <wasm[0]::function[1015]::helper::object_read+0x1b173>
 29eb7f1:	add    %r13d,%eax
 29eb7f4:	jb     29fc0f5 <wasm[0]::function[1015]::helper::object_read+0x1b175>
 29eb7fa:	mov    %eax,%r10d
 29eb7fd:	lea    (%rsi,%r10,1),%rax
 29eb801:	cmp    %rdx,%r10
 29eb804:	cmova  %r12,%rax
 29eb808:	mov    %rcx,%rdx
 29eb80b:	shl    $0x3,%edx
 29eb80e:	add    $0x18,%edx
 29eb814:	sub    %edx,%r13d
 29eb817:	sub    %r13,%rax
 29eb81a:	mov    (%rax),%rsi
 29eb81d:	xor    %edx,%edx
 29eb81f:	test   %edi,%edi
 29eb821:	je     29eb8ad <wasm[0]::function[1015]::helper::object_read+0xa92d>
 29eb827:	test   %edi,%edi
 29eb829:	je     29fc0f7 <wasm[0]::function[1015]::helper::object_read+0x1b177>
 29eb82f:	test   %edi,%edi
 29eb831:	je     29fc0f9 <wasm[0]::function[1015]::helper::object_read+0x1b179>
 29eb837:	mov    0x2e0(%rsp),%r12
 29eb83f:	mov    0x28(%r12),%rax
 29eb844:	mov    0x20(%r12),%rdx
 29eb849:	mov    %edi,%r10d
 29eb84c:	lea    0x10(%rdx,%r10,1),%r13
 29eb851:	xor    %r12,%r12
 29eb854:	cmp    %rax,%r10
 29eb857:	cmova  %r12,%r13
 29eb85b:	mov    0x0(%r13),%r13d
 29eb85f:	cmp    %r13d,%ecx
 29eb862:	jae    29fc0fb <wasm[0]::function[1015]::helper::object_read+0x1b17b>
 29eb868:	mov    %r13d,%r10d
 29eb86b:	shl    $0x2,%r10
 29eb86f:	shr    $0x20,%r10
 29eb873:	test   %r10,%r10
 29eb876:	jne    29fc0fd <wasm[0]::function[1015]::helper::object_read+0x1b17d>
 29eb87c:	shl    $0x2,%r13d
 29eb880:	add    $0x14,%r13d
 29eb884:	jb     29fc0ff <wasm[0]::function[1015]::helper::object_read+0x1b17f>
 29eb88a:	add    %r13d,%edi
 29eb88d:	jb     29fc101 <wasm[0]::function[1015]::helper::object_read+0x1b181>
 29eb893:	mov    %edi,%edi
 29eb895:	add    %rdi,%rdx
 29eb898:	cmp    %rax,%rdi
 29eb89b:	cmova  %r12,%rdx
 29eb89f:	shl    $0x2,%ecx
 29eb8a2:	lea    0x14(%rcx),%eax
 29eb8a5:	sub    %eax,%r13d
 29eb8a8:	sub    %r13,%rdx
 29eb8ab:	mov    (%rdx),%edx
 29eb8ad:	movzbl %r11b,%edi
 29eb8b1:	jmp    29eba1c <wasm[0]::function[1015]::helper::object_read+0xaa9c>
 29eb8b6:	xor    %eax,%eax
 29eb8b8:	test   $0x1,%r10d
 29eb8bf:	jne    29eb903 <wasm[0]::function[1015]::helper::object_read+0xa983>
 29eb8c5:	mov    0x2e0(%rsp),%r12
 29eb8cd:	mov    0x28(%r12),%rax
 29eb8d2:	mov    0x20(%r12),%rdx
 29eb8d7:	mov    %r10d,%esi
 29eb8da:	lea    0x4(%rdx,%rsi,1),%rdx
 29eb8df:	xor    %rdi,%rdi
 29eb8e2:	cmp    %rax,%rsi
 29eb8e5:	cmova  %rdi,%rdx
 29eb8e9:	mov    (%rdx),%eax
 29eb8eb:	mov    0x190(%rsp),%rdx
 29eb8f3:	mov    0x28(%rdx),%rdx
 29eb8f7:	cmp    0x160(%rdx),%eax
 29eb8fd:	sete   %al
 29eb900:	movzbl %al,%eax
 29eb903:	test   %eax,%eax
 29eb905:	je     29fc103 <wasm[0]::function[1015]::helper::object_read+0x1b183>
 29eb90b:	test   %r10d,%r10d
 29eb90e:	je     29fc105 <wasm[0]::function[1015]::helper::object_read+0x1b185>
 29eb914:	mov    0x2e0(%rsp),%r12
 29eb91c:	mov    0x28(%r12),%rdx
 29eb921:	mov    0x20(%r12),%rsi
 29eb926:	mov    %r10d,%eax
 29eb929:	lea    (%rsi,%rax,1),%r10
 29eb92d:	xor    %rdi,%rdi
 29eb930:	cmp    %rdx,%rax
 29eb933:	cmova  %rdi,%r10
 29eb937:	mov    0x10(%r10),%r10d
 29eb93b:	test   %r10d,%r10d
 29eb93e:	je     29fc107 <wasm[0]::function[1015]::helper::object_read+0x1b187>
 29eb944:	test   %r10d,%r10d
 29eb947:	je     29fc109 <wasm[0]::function[1015]::helper::object_read+0x1b189>
 29eb94d:	mov    %r10d,%r11d
 29eb950:	lea    (%rsi,%r11,1),%r10
 29eb954:	cmp    %rdx,%r11
 29eb957:	cmova  %rdi,%r10
 29eb95b:	mov    0x10(%r10),%r10d
 29eb95f:	test   %r10d,%r10d
 29eb962:	je     29fc10b <wasm[0]::function[1015]::helper::object_read+0x1b18b>
 29eb968:	test   %r10d,%r10d
 29eb96b:	je     29fc10d <wasm[0]::function[1015]::helper::object_read+0x1b18d>
 29eb971:	mov    %r10d,%r10d
 29eb974:	lea    0x10(%rsi,%r10,1),%rsi
 29eb979:	cmp    %rdx,%r10
 29eb97c:	cmova  %rdi,%rsi
 29eb980:	cmp    (%rsi),%ecx
 29eb982:	setae  %dl
 29eb985:	cmp    $0x2,%ecx
 29eb988:	setae  %sil
 29eb98c:	or     %esi,%edx
 29eb98e:	test   %dl,%dl
 29eb990:	jne    29fc10f <wasm[0]::function[1015]::helper::object_read+0x1b18f>
 29eb996:	mov    0x2e0(%rsp),%r12
 29eb99e:	mov    0x28(%r12),%rsi
 29eb9a3:	mov    %rax,%rdx
 29eb9a6:	add    0x20(%r12),%rdx
 29eb9ab:	xor    %rdi,%rdi
 29eb9ae:	cmp    %rsi,%rax
 29eb9b1:	cmova  %rdi,%rdx
 29eb9b5:	mov    0x14(%rdx),%edi
 29eb9b8:	test   %ecx,%ecx
 29eb9ba:	je     29eb9eb <wasm[0]::function[1015]::helper::object_read+0xaa6b>
 29eb9c0:	mov    0x2e0(%rsp),%r12
 29eb9c8:	mov    0x28(%r12),%rsi
 29eb9cd:	mov    0x20(%r12),%rdx
 29eb9d2:	add    %rax,%rdx
 29eb9d5:	xor    %r10,%r10
 29eb9d8:	cmp    %rsi,%rax
 29eb9db:	cmova  %r10,%rdx
 29eb9df:	mov    0x20(%rdx),%rsi
 29eb9e3:	mov    0x2c(%rdx),%edx
 29eb9e6:	jmp    29eba11 <wasm[0]::function[1015]::helper::object_read+0xaa91>
 29eb9eb:	mov    0x2e0(%rsp),%r12
 29eb9f3:	mov    0x28(%r12),%rsi
 29eb9f8:	mov    0x20(%r12),%rdx
 29eb9fd:	add    %rax,%rdx
 29eba00:	xor    %r10,%r10
 29eba03:	cmp    %rsi,%rax
 29eba06:	cmova  %r10,%rdx
 29eba0a:	mov    0x18(%rdx),%rsi
 29eba0e:	mov    0x28(%rdx),%edx
 29eba11:	shl    $0x3,%ecx
 29eba14:	shr    %cl,%edi
 29eba16:	and    $0xff,%edi
 29eba1c:	mov    0x1d0(%rsp),%r10
 29eba24:	mov    %r10d,0x110(%rsp)
 29eba2c:	mov    0x1d8(%rsp),%r11
 29eba34:	mov    %r11d,0xd8(%rsp)
 29eba3c:	mov    0x1e0(%rsp),%r13
 29eba44:	mov    %r13d,0x130(%rsp)
 29eba4c:	mov    0x1e8(%rsp),%r11
 29eba54:	mov    %r11d,0xa0(%rsp)
 29eba5c:	mov    0x1f0(%rsp),%rax
 29eba64:	mov    %eax,0x118(%rsp)
 29eba6b:	mov    %ebx,0xe0(%rsp)
 29eba72:	mov    %r15d,0x100(%rsp)
 29eba7a:	mov    %r14d,0xc8(%rsp)
 29eba82:	mov    0x230(%rsp),%rcx
 29eba8a:	cmp    $0x2,%ecx
 29eba8d:	je     29ebdc1 <wasm[0]::function[1015]::helper::object_read+0xae41>
 29eba93:	cmp    $0x4,%ecx
 29eba96:	je     29ebcef <wasm[0]::function[1015]::helper::object_read+0xad6f>
 29eba9c:	cmp    $0x3,%ecx
 29eba9f:	je     29ebcab <wasm[0]::function[1015]::helper::object_read+0xad2b>
 29ebaa5:	cmp    $0xa,%ecx
 29ebaa8:	je     29ebbda <wasm[0]::function[1015]::helper::object_read+0xac5a>
 29ebaae:	test   %ecx,%ecx
 29ebab0:	sete   %r10b
 29ebab4:	cmp    $0x1,%ecx
 29ebab7:	sete   %al
 29ebaba:	or     %eax,%r10d
 29ebabd:	test   %r10b,%r10b
 29ebac0:	jne    29ebbd2 <wasm[0]::function[1015]::helper::object_read+0xac52>
 29ebac6:	xor    %eax,%eax
 29ebac8:	test   %r8d,%r8d
 29ebacb:	je     29ebb1e <wasm[0]::function[1015]::helper::object_read+0xab9e>
 29ebad1:	xor    %eax,%eax
 29ebad3:	test   $0x1,%r8d
 29ebada:	jne    29ebb1e <wasm[0]::function[1015]::helper::object_read+0xab9e>
 29ebae0:	mov    0x2e0(%rsp),%r12
 29ebae8:	mov    0x28(%r12),%rax
 29ebaed:	mov    0x20(%r12),%rcx
 29ebaf2:	mov    %r8d,%r10d
 29ebaf5:	lea    0x4(%rcx,%r10,1),%rcx
 29ebafa:	xor    %r11,%r11
 29ebafd:	cmp    %rax,%r10
 29ebb00:	cmova  %r11,%rcx
 29ebb04:	mov    (%rcx),%eax
 29ebb06:	mov    0x190(%rsp),%rcx
 29ebb0e:	mov    0x28(%rcx),%rcx
 29ebb12:	cmp    0x1d4(%rcx),%eax
 29ebb18:	sete   %al
 29ebb1b:	movzbl %al,%eax
 29ebb1e:	test   %eax,%eax
 29ebb20:	jne    29ebb2d <wasm[0]::function[1015]::helper::object_read+0xabad>
 29ebb26:	xor    %eax,%eax
 29ebb28:	jmp    29ebbc4 <wasm[0]::function[1015]::helper::object_read+0xac44>
 29ebb2d:	xor    %eax,%eax
 29ebb2f:	test   %r8d,%r8d
 29ebb32:	je     29ebb85 <wasm[0]::function[1015]::helper::object_read+0xac05>
 29ebb38:	xor    %eax,%eax
 29ebb3a:	test   $0x1,%r8d
 29ebb41:	jne    29ebb85 <wasm[0]::function[1015]::helper::object_read+0xac05>
 29ebb47:	mov    0x2e0(%rsp),%r12
 29ebb4f:	mov    0x28(%r12),%rax
 29ebb54:	mov    0x20(%r12),%rcx
 29ebb59:	mov    %r8d,%r10d
 29ebb5c:	lea    0x4(%rcx,%r10,1),%rcx
 29ebb61:	xor    %r11,%r11
 29ebb64:	cmp    %rax,%r10
 29ebb67:	cmova  %r11,%rcx
 29ebb6b:	mov    (%rcx),%eax
 29ebb6d:	mov    0x190(%rsp),%rcx
 29ebb75:	mov    0x28(%rcx),%rcx
 29ebb79:	cmp    0x1d4(%rcx),%eax
 29ebb7f:	sete   %al
 29ebb82:	movzbl %al,%eax
 29ebb85:	test   %eax,%eax
 29ebb87:	je     29fc111 <wasm[0]::function[1015]::helper::object_read+0x1b191>
 29ebb8d:	test   %r8d,%r8d
 29ebb90:	je     29fc113 <wasm[0]::function[1015]::helper::object_read+0x1b193>
 29ebb96:	test   %r8d,%r8d
 29ebb99:	je     29fc115 <wasm[0]::function[1015]::helper::object_read+0x1b195>
 29ebb9f:	mov    0x2e0(%rsp),%r12
 29ebba7:	mov    0x28(%r12),%rax
 29ebbac:	mov    %r8d,%r8d
 29ebbaf:	mov    %r8,%rcx
 29ebbb2:	add    0x20(%r12),%rcx
 29ebbb7:	xor    %r10,%r10
 29ebbba:	cmp    %rax,%r8
 29ebbbd:	cmova  %r10,%rcx
 29ebbc1:	mov    0x3c(%rcx),%eax
 29ebbc4:	test   %eax,%eax
 29ebbc6:	sete   %al
 29ebbc9:	movzbl %al,%r13d
 29ebbcd:	jmp    29ebdb4 <wasm[0]::function[1015]::helper::object_read+0xae34>
 29ebbd2:	xor    %r13d,%r13d
 29ebbd5:	jmp    29ebdb4 <wasm[0]::function[1015]::helper::object_read+0xae34>
 29ebbda:	xor    %r10d,%r10d
 29ebbdd:	test   %r8d,%r8d
 29ebbe0:	je     29ebc35 <wasm[0]::function[1015]::helper::object_read+0xacb5>
 29ebbe6:	xor    %r10d,%r10d
 29ebbe9:	test   $0x1,%r8d
 29ebbf0:	jne    29ebc35 <wasm[0]::function[1015]::helper::object_read+0xacb5>
 29ebbf6:	mov    0x2e0(%rsp),%r12
 29ebbfe:	mov    0x28(%r12),%rax
 29ebc03:	mov    0x20(%r12),%rcx
 29ebc08:	mov    %r8d,%r10d
 29ebc0b:	lea    0x4(%rcx,%r10,1),%rcx
 29ebc10:	xor    %r11,%r11
 29ebc13:	cmp    %rax,%r10
 29ebc16:	cmova  %r11,%rcx
 29ebc1a:	mov    (%rcx),%eax
 29ebc1c:	mov    0x190(%rsp),%rcx
 29ebc24:	mov    0x28(%rcx),%rcx
 29ebc28:	cmp    0x23c(%rcx),%eax
 29ebc2e:	sete   %al
 29ebc31:	movzbl %al,%r10d
 29ebc35:	test   %r10d,%r10d
 29ebc38:	je     29fc117 <wasm[0]::function[1015]::helper::object_read+0x1b197>
 29ebc3e:	test   %r8d,%r8d
 29ebc41:	je     29fc119 <wasm[0]::function[1015]::helper::object_read+0x1b199>
 29ebc47:	test   %r8d,%r8d
 29ebc4a:	je     29fc11b <wasm[0]::function[1015]::helper::object_read+0x1b19b>
 29ebc50:	mov    0x2e0(%rsp),%r12
 29ebc58:	mov    0x28(%r12),%rax
 29ebc5d:	mov    0x20(%r12),%rcx
 29ebc62:	mov    %r8d,%r11d
 29ebc65:	lea    (%rcx,%r11,1),%r10
 29ebc69:	xor    %r8,%r8
 29ebc6c:	cmp    %rax,%r11
 29ebc6f:	cmova  %r8,%r10
 29ebc73:	mov    0x14(%r10),%r10d
 29ebc77:	test   %r10d,%r10d
 29ebc7a:	je     29fc11d <wasm[0]::function[1015]::helper::object_read+0x1b19d>
 29ebc80:	test   %r10d,%r10d
 29ebc83:	je     29fc11f <wasm[0]::function[1015]::helper::object_read+0x1b19f>
 29ebc89:	mov    %r10d,%r11d
 29ebc8c:	lea    0x10(%rcx,%r11,1),%r10
 29ebc91:	cmp    %rax,%r11
 29ebc94:	cmova  %r8,%r10
 29ebc98:	mov    (%r10),%r8d
 29ebc9b:	test   %r8d,%r8d
 29ebc9e:	setne  %r8b
 29ebca2:	movzbl %r8b,%r13d
 29ebca6:	jmp    29ebdb4 <wasm[0]::function[1015]::helper::object_read+0xae34>
 29ebcab:	mov    0x238(%rsp),%rcx
 29ebcb3:	movq   %rcx,%xmm0
 29ebcb8:	ucomisd 0x10c50(%rip),%xmm0        # 29fc910 <wasm[0]::function[1015]::helper::object_read+0x1b990>
 29ebcc0:	setnp  %r8b
 29ebcc4:	sete   %r10b
 29ebcc8:	and    %r10d,%r8d
 29ebccb:	ucomisd %xmm0,%xmm0
 29ebccf:	setp   %r11b
 29ebcd3:	setne  %al
 29ebcd6:	or     %eax,%r11d
 29ebcd9:	or     %r11d,%r8d
 29ebcdc:	movzbl %r8b,%r11d
 29ebce0:	test   %r11d,%r11d
 29ebce3:	sete   %al
 29ebce6:	movzbl %al,%r13d
 29ebcea:	jmp    29ebdb4 <wasm[0]::function[1015]::helper::object_read+0xae34>
 29ebcef:	xor    %eax,%eax
 29ebcf1:	test   %r8d,%r8d
 29ebcf4:	je     29ebd47 <wasm[0]::function[1015]::helper::object_read+0xadc7>
 29ebcfa:	xor    %eax,%eax
 29ebcfc:	test   $0x1,%r8d
 29ebd03:	jne    29ebd47 <wasm[0]::function[1015]::helper::object_read+0xadc7>
 29ebd09:	mov    0x2e0(%rsp),%r12
 29ebd11:	mov    0x28(%r12),%rax
 29ebd16:	mov    0x20(%r12),%rcx
 29ebd1b:	mov    %r8d,%r10d
 29ebd1e:	lea    0x4(%rcx,%r10,1),%rcx
 29ebd23:	xor    %r11,%r11
 29ebd26:	cmp    %rax,%r10
 29ebd29:	cmova  %r11,%rcx
 29ebd2d:	mov    (%rcx),%eax
 29ebd2f:	mov    0x190(%rsp),%rcx
 29ebd37:	mov    0x28(%rcx),%rcx
 29ebd3b:	cmp    0x234(%rcx),%eax
 29ebd41:	sete   %al
 29ebd44:	movzbl %al,%eax
 29ebd47:	test   %eax,%eax
 29ebd49:	je     29fc121 <wasm[0]::function[1015]::helper::object_read+0x1b1a1>
 29ebd4f:	test   %r8d,%r8d
 29ebd52:	je     29fc123 <wasm[0]::function[1015]::helper::object_read+0x1b1a3>
 29ebd58:	test   %r8d,%r8d
 29ebd5b:	je     29fc125 <wasm[0]::function[1015]::helper::object_read+0x1b1a5>
 29ebd61:	mov    0x2e0(%rsp),%r12
 29ebd69:	mov    0x28(%r12),%rax
 29ebd6e:	mov    0x20(%r12),%rcx
 29ebd73:	mov    %r8d,%r11d
 29ebd76:	lea    (%rcx,%r11,1),%r10
 29ebd7a:	xor    %r8,%r8
 29ebd7d:	cmp    %rax,%r11
 29ebd80:	cmova  %r8,%r10
 29ebd84:	mov    0x10(%r10),%r10d
 29ebd88:	test   %r10d,%r10d
 29ebd8b:	je     29fc127 <wasm[0]::function[1015]::helper::object_read+0x1b1a7>
 29ebd91:	test   %r10d,%r10d
 29ebd94:	je     29fc129 <wasm[0]::function[1015]::helper::object_read+0x1b1a9>
 29ebd9a:	mov    %r10d,%r10d
 29ebd9d:	lea    0x10(%rcx,%r10,1),%rcx
 29ebda2:	cmp    %rax,%r10
 29ebda5:	cmova  %r8,%rcx
 29ebda9:	mov    (%rcx),%eax
 29ebdab:	test   %eax,%eax
 29ebdad:	setne  %al
 29ebdb0:	movzbl %al,%r13d
 29ebdb4:	mov    0x1a0(%rsp),%r14
 29ebdbc:	jmp    29ebddb <wasm[0]::function[1015]::helper::object_read+0xae5b>
 29ebdc1:	mov    0x238(%rsp),%rcx
 29ebdc9:	test   %rcx,%rcx
 29ebdcc:	setne  %al
 29ebdcf:	movzbl %al,%r13d
 29ebdd3:	mov    0x1a0(%rsp),%r14
 29ebddb:	mov    0x1a0(%rsp),%r14
 29ebde3:	cmp    $0x2,%r14d
 29ebde7:	je     29ec13a <wasm[0]::function[1015]::helper::object_read+0xb1ba>
 29ebded:	mov    0x1a0(%rsp),%r14
 29ebdf5:	cmp    $0x4,%r14d
 29ebdf9:	je     29ec06d <wasm[0]::function[1015]::helper::object_read+0xb0ed>
 29ebdff:	mov    0x1a0(%rsp),%r14
 29ebe07:	cmp    $0x3,%r14d
 29ebe0b:	je     29ec02f <wasm[0]::function[1015]::helper::object_read+0xb0af>
 29ebe11:	mov    0x1a0(%rsp),%r14
 29ebe19:	cmp    $0xa,%r14d
 29ebe1d:	je     29ebf65 <wasm[0]::function[1015]::helper::object_read+0xafe5>
 29ebe23:	mov    0x1a0(%rsp),%rax
 29ebe2b:	mov    0x1a0(%rsp),%r14
 29ebe33:	test   %eax,%r14d
 29ebe36:	sete   %al
 29ebe39:	cmp    $0x1,%r14d
 29ebe3d:	sete   %cl
 29ebe40:	or     %ecx,%eax
 29ebe42:	test   %al,%al
 29ebe44:	jne    29ebf5d <wasm[0]::function[1015]::helper::object_read+0xafdd>
 29ebe4a:	xor    %eax,%eax
 29ebe4c:	test   %r9d,%r9d
 29ebe4f:	je     29ebea2 <wasm[0]::function[1015]::helper::object_read+0xaf22>
 29ebe55:	xor    %eax,%eax
 29ebe57:	test   $0x1,%r9d
 29ebe5e:	jne    29ebea2 <wasm[0]::function[1015]::helper::object_read+0xaf22>
 29ebe64:	mov    0x2e0(%rsp),%r12
 29ebe6c:	mov    0x28(%r12),%rax
 29ebe71:	mov    0x20(%r12),%rcx
 29ebe76:	mov    %r9d,%r8d
 29ebe79:	lea    0x4(%rcx,%r8,1),%rcx
 29ebe7e:	xor    %r10,%r10
 29ebe81:	cmp    %rax,%r8
 29ebe84:	cmova  %r10,%rcx
 29ebe88:	mov    (%rcx),%eax
 29ebe8a:	mov    0x190(%rsp),%rcx
 29ebe92:	mov    0x28(%rcx),%rcx
 29ebe96:	cmp    0x1d4(%rcx),%eax
 29ebe9c:	sete   %al
 29ebe9f:	movzbl %al,%eax
 29ebea2:	test   %eax,%eax
 29ebea4:	jne    29ebeb1 <wasm[0]::function[1015]::helper::object_read+0xaf31>
 29ebeaa:	xor    %ecx,%ecx
 29ebeac:	jmp    29ebf4f <wasm[0]::function[1015]::helper::object_read+0xafcf>
 29ebeb1:	xor    %r8d,%r8d
 29ebeb4:	test   %r9d,%r9d
 29ebeb7:	je     29ebf0f <wasm[0]::function[1015]::helper::object_read+0xaf8f>
 29ebebd:	xor    %r8d,%r8d
 29ebec0:	test   $0x1,%r9d
 29ebec7:	jne    29ebf0f <wasm[0]::function[1015]::helper::object_read+0xaf8f>
 29ebecd:	mov    0x2e0(%rsp),%r12
 29ebed5:	mov    0x28(%r12),%r8
 29ebeda:	mov    0x20(%r12),%r10
 29ebedf:	mov    %r9d,%r11d
 29ebee2:	lea    0x4(%r10,%r11,1),%r10
 29ebee7:	xor    %rax,%rax
 29ebeea:	cmp    %r8,%r11
 29ebeed:	cmova  %rax,%r10
 29ebef1:	mov    (%r10),%r8d
 29ebef4:	mov    0x190(%rsp),%rcx
 29ebefc:	mov    0x28(%rcx),%r10
 29ebf00:	cmp    0x1d4(%r10),%r8d
 29ebf07:	sete   %r10b
 29ebf0b:	movzbl %r10b,%r8d
 29ebf0f:	test   %r8d,%r8d
 29ebf12:	je     29fc12b <wasm[0]::function[1015]::helper::object_read+0x1b1ab>
 29ebf18:	test   %r9d,%r9d
 29ebf1b:	je     29fc12d <wasm[0]::function[1015]::helper::object_read+0x1b1ad>
 29ebf21:	test   %r9d,%r9d
 29ebf24:	je     29fc12f <wasm[0]::function[1015]::helper::object_read+0x1b1af>
 29ebf2a:	mov    0x2e0(%rsp),%r12
 29ebf32:	mov    0x28(%r12),%rax
 29ebf37:	mov    %r9d,%r8d
 29ebf3a:	mov    %r8,%rcx
 29ebf3d:	add    0x20(%r12),%rcx
 29ebf42:	xor    %r9,%r9
 29ebf45:	cmp    %rax,%r8
 29ebf48:	cmova  %r9,%rcx
 29ebf4c:	mov    0x3c(%rcx),%ecx
 29ebf4f:	test   %ecx,%ecx
 29ebf51:	sete   %al
 29ebf54:	movzbl %al,%r14d
 29ebf58:	jmp    29ec14c <wasm[0]::function[1015]::helper::object_read+0xb1cc>
 29ebf5d:	xor    %r14d,%r14d
 29ebf60:	jmp    29ec14c <wasm[0]::function[1015]::helper::object_read+0xb1cc>
 29ebf65:	xor    %eax,%eax
 29ebf67:	test   %r9d,%r9d
 29ebf6a:	je     29ebfbd <wasm[0]::function[1015]::helper::object_read+0xb03d>
 29ebf70:	xor    %eax,%eax
 29ebf72:	test   $0x1,%r9d
 29ebf79:	jne    29ebfbd <wasm[0]::function[1015]::helper::object_read+0xb03d>
 29ebf7f:	mov    0x2e0(%rsp),%r12
 29ebf87:	mov    0x28(%r12),%rax
 29ebf8c:	mov    0x20(%r12),%rcx
 29ebf91:	mov    %r9d,%r8d
 29ebf94:	lea    0x4(%rcx,%r8,1),%rcx
 29ebf99:	xor    %r10,%r10
 29ebf9c:	cmp    %rax,%r8
 29ebf9f:	cmova  %r10,%rcx
 29ebfa3:	mov    (%rcx),%eax
 29ebfa5:	mov    0x190(%rsp),%rcx
 29ebfad:	mov    0x28(%rcx),%rcx
 29ebfb1:	cmp    0x23c(%rcx),%eax
 29ebfb7:	sete   %al
 29ebfba:	movzbl %al,%eax
 29ebfbd:	test   %eax,%eax
 29ebfbf:	je     29fc131 <wasm[0]::function[1015]::helper::object_read+0x1b1b1>
 29ebfc5:	test   %r9d,%r9d
 29ebfc8:	je     29fc133 <wasm[0]::function[1015]::helper::object_read+0x1b1b3>
 29ebfce:	test   %r9d,%r9d
 29ebfd1:	je     29fc135 <wasm[0]::function[1015]::helper::object_read+0x1b1b5>
 29ebfd7:	mov    0x2e0(%rsp),%r12
 29ebfdf:	mov    0x28(%r12),%rax
 29ebfe4:	mov    0x20(%r12),%rcx
 29ebfe9:	mov    %r9d,%r10d
 29ebfec:	lea    (%rcx,%r10,1),%r9
 29ebff0:	xor    %r8,%r8
 29ebff3:	cmp    %rax,%r10
 29ebff6:	cmova  %r8,%r9
 29ebffa:	mov    0x14(%r9),%r9d
 29ebffe:	test   %r9d,%r9d
 29ec001:	je     29fc137 <wasm[0]::function[1015]::helper::object_read+0x1b1b7>
 29ec007:	test   %r9d,%r9d
 29ec00a:	je     29fc139 <wasm[0]::function[1015]::helper::object_read+0x1b1b9>
 29ec010:	mov    %r9d,%r9d
 29ec013:	lea    0x10(%rcx,%r9,1),%rcx
 29ec018:	cmp    %rax,%r9
 29ec01b:	cmova  %r8,%rcx
 29ec01f:	mov    (%rcx),%eax
 29ec021:	test   %eax,%eax
 29ec023:	setne  %al
 29ec026:	movzbl %al,%r14d
 29ec02a:	jmp    29ec14c <wasm[0]::function[1015]::helper::object_read+0xb1cc>
 29ec02f:	mov    0x1c8(%rsp),%rcx
 29ec037:	movq   %rcx,%xmm0
 29ec03c:	ucomisd 0x108dc(%rip),%xmm0        # 29fc920 <wasm[0]::function[1015]::helper::object_read+0x1b9a0>
 29ec044:	setnp  %al
 29ec047:	sete   %cl
 29ec04a:	and    %ecx,%eax
 29ec04c:	ucomisd %xmm0,%xmm0
 29ec050:	setp   %cl
 29ec053:	setne  %r8b
 29ec057:	or     %r8d,%ecx
 29ec05a:	or     %ecx,%eax
 29ec05c:	movzbl %al,%eax
 29ec05f:	test   %eax,%eax
 29ec061:	sete   %al
 29ec064:	movzbl %al,%r14d
 29ec068:	jmp    29ec14c <wasm[0]::function[1015]::helper::object_read+0xb1cc>
 29ec06d:	xor    %eax,%eax
 29ec06f:	test   %r9d,%r9d
 29ec072:	je     29ec0c5 <wasm[0]::function[1015]::helper::object_read+0xb145>
 29ec078:	xor    %eax,%eax
 29ec07a:	test   $0x1,%r9d
 29ec081:	jne    29ec0c5 <wasm[0]::function[1015]::helper::object_read+0xb145>
 29ec087:	mov    0x2e0(%rsp),%r12
 29ec08f:	mov    0x28(%r12),%rax
 29ec094:	mov    0x20(%r12),%rcx
 29ec099:	mov    %r9d,%r8d
 29ec09c:	lea    0x4(%rcx,%r8,1),%rcx
 29ec0a1:	xor    %r10,%r10
 29ec0a4:	cmp    %rax,%r8
 29ec0a7:	cmova  %r10,%rcx
 29ec0ab:	mov    (%rcx),%eax
 29ec0ad:	mov    0x190(%rsp),%rcx
 29ec0b5:	mov    0x28(%rcx),%rcx
 29ec0b9:	cmp    0x234(%rcx),%eax
 29ec0bf:	sete   %al
 29ec0c2:	movzbl %al,%eax
 29ec0c5:	test   %eax,%eax
 29ec0c7:	je     29fc13b <wasm[0]::function[1015]::helper::object_read+0x1b1bb>
 29ec0cd:	test   %r9d,%r9d
 29ec0d0:	je     29fc13d <wasm[0]::function[1015]::helper::object_read+0x1b1bd>
 29ec0d6:	test   %r9d,%r9d
 29ec0d9:	je     29fc13f <wasm[0]::function[1015]::helper::object_read+0x1b1bf>
 29ec0df:	mov    0x2e0(%rsp),%r12
 29ec0e7:	mov    0x28(%r12),%r8
 29ec0ec:	mov    0x20(%r12),%r10
 29ec0f1:	mov    %r9d,%r11d
 29ec0f4:	lea    (%r10,%r11,1),%rax
 29ec0f8:	xor    %r9,%r9
 29ec0fb:	cmp    %r8,%r11
 29ec0fe:	cmova  %r9,%rax
 29ec102:	mov    0x10(%rax),%r11d
 29ec106:	test   %r11d,%r11d
 29ec109:	je     29fc141 <wasm[0]::function[1015]::helper::object_read+0x1b1c1>
 29ec10f:	test   %r11d,%r11d
 29ec112:	je     29fc143 <wasm[0]::function[1015]::helper::object_read+0x1b1c3>
 29ec118:	mov    %r11d,%r11d
 29ec11b:	lea    0x10(%r10,%r11,1),%r10
 29ec120:	cmp    %r8,%r11
 29ec123:	cmova  %r9,%r10
 29ec127:	mov    (%r10),%r9d
 29ec12a:	test   %r9d,%r9d
 29ec12d:	setne  %r10b
 29ec131:	movzbl %r10b,%r14d
 29ec135:	jmp    29ec14c <wasm[0]::function[1015]::helper::object_read+0xb1cc>
 29ec13a:	mov    0x1c8(%rsp),%rcx
 29ec142:	test   %rcx,%rcx
 29ec145:	setne  %al
 29ec148:	movzbl %al,%r14d
 29ec14c:	cmp    $0x2,%edi
 29ec14f:	je     29ec44e <wasm[0]::function[1015]::helper::object_read+0xb4ce>
 29ec155:	cmp    $0x4,%edi
 29ec158:	je     29ec387 <wasm[0]::function[1015]::helper::object_read+0xb407>
 29ec15e:	cmp    $0x3,%edi
 29ec161:	je     29ec354 <wasm[0]::function[1015]::helper::object_read+0xb3d4>
 29ec167:	cmp    $0xa,%edi
 29ec16a:	je     29ec292 <wasm[0]::function[1015]::helper::object_read+0xb312>
 29ec170:	test   %edi,%edi
 29ec172:	sete   %al
 29ec175:	cmp    $0x1,%edi
 29ec178:	sete   %cl
 29ec17b:	or     %ecx,%eax
 29ec17d:	test   %al,%al
 29ec17f:	jne    29ec28b <wasm[0]::function[1015]::helper::object_read+0xb30b>
 29ec185:	xor    %r11d,%r11d
 29ec188:	test   %edx,%edx
 29ec18a:	je     29ec1dd <wasm[0]::function[1015]::helper::object_read+0xb25d>
 29ec190:	xor    %r11d,%r11d
 29ec193:	test   $0x1,%edx
 29ec199:	jne    29ec1dd <wasm[0]::function[1015]::helper::object_read+0xb25d>
 29ec19f:	mov    0x2e0(%rsp),%r12
 29ec1a7:	mov    0x28(%r12),%rax
 29ec1ac:	mov    0x20(%r12),%rcx
 29ec1b1:	mov    %edx,%esi
 29ec1b3:	lea    0x4(%rcx,%rsi,1),%rcx
 29ec1b8:	xor    %rdi,%rdi
 29ec1bb:	cmp    %rax,%rsi
 29ec1be:	cmova  %rdi,%rcx
 29ec1c2:	mov    (%rcx),%eax
 29ec1c4:	mov    0x190(%rsp),%rcx
 29ec1cc:	mov    0x28(%rcx),%rcx
 29ec1d0:	cmp    0x1d4(%rcx),%eax
 29ec1d6:	sete   %al
 29ec1d9:	movzbl %al,%r11d
 29ec1dd:	test   %r11d,%r11d
 29ec1e0:	jne    29ec1ed <wasm[0]::function[1015]::helper::object_read+0xb26d>
 29ec1e6:	xor    %eax,%eax
 29ec1e8:	jmp    29ec27e <wasm[0]::function[1015]::helper::object_read+0xb2fe>
 29ec1ed:	xor    %eax,%eax
 29ec1ef:	test   %edx,%edx
 29ec1f1:	je     29ec242 <wasm[0]::function[1015]::helper::object_read+0xb2c2>
 29ec1f7:	xor    %eax,%eax
 29ec1f9:	test   $0x1,%edx
 29ec1ff:	jne    29ec242 <wasm[0]::function[1015]::helper::object_read+0xb2c2>
 29ec205:	mov    0x2e0(%rsp),%r12
 29ec20d:	mov    0x28(%r12),%rax
 29ec212:	mov    0x20(%r12),%rcx
 29ec217:	mov    %edx,%esi
 29ec219:	lea    0x4(%rcx,%rsi,1),%rcx
 29ec21e:	xor    %rdi,%rdi
 29ec221:	cmp    %rax,%rsi
 29ec224:	cmova  %rdi,%rcx
 29ec228:	mov    (%rcx),%eax
 29ec22a:	mov    0x190(%rsp),%rcx
 29ec232:	mov    0x28(%rcx),%rcx
 29ec236:	cmp    0x1d4(%rcx),%eax
 29ec23c:	sete   %al
 29ec23f:	movzbl %al,%eax
 29ec242:	test   %eax,%eax
 29ec244:	je     29fc145 <wasm[0]::function[1015]::helper::object_read+0x1b1c5>
 29ec24a:	test   %edx,%edx
 29ec24c:	je     29fc147 <wasm[0]::function[1015]::helper::object_read+0x1b1c7>
 29ec252:	test   %edx,%edx
 29ec254:	je     29fc149 <wasm[0]::function[1015]::helper::object_read+0x1b1c9>
 29ec25a:	mov    0x2e0(%rsp),%r12
 29ec262:	mov    0x28(%r12),%rax
 29ec267:	mov    %edx,%edx
 29ec269:	mov    %rdx,%rcx
 29ec26c:	add    0x20(%r12),%rcx
 29ec271:	xor    %rsi,%rsi
 29ec274:	cmp    %rax,%rdx
 29ec277:	cmova  %rsi,%rcx
 29ec27b:	mov    0x3c(%rcx),%eax
 29ec27e:	test   %eax,%eax
 29ec280:	sete   %al
 29ec283:	movzbl %al,%ebx
 29ec286:	jmp    29ec441 <wasm[0]::function[1015]::helper::object_read+0xb4c1>
 29ec28b:	xor    %ebx,%ebx
 29ec28d:	jmp    29ec441 <wasm[0]::function[1015]::helper::object_read+0xb4c1>
 29ec292:	xor    %eax,%eax
 29ec294:	test   %edx,%edx
 29ec296:	je     29ec2e9 <wasm[0]::function[1015]::helper::object_read+0xb369>
 29ec29c:	xor    %eax,%eax
 29ec29e:	test   $0x1,%edx
 29ec2a4:	jne    29ec2e9 <wasm[0]::function[1015]::helper::object_read+0xb369>
 29ec2aa:	mov    0x2e0(%rsp),%r12
 29ec2b2:	mov    0x28(%r12),%rsi
 29ec2b7:	mov    0x20(%r12),%r8
 29ec2bc:	mov    %edx,%edi
 29ec2be:	lea    0x4(%r8,%rdi,1),%rax
 29ec2c3:	xor    %r8,%r8
 29ec2c6:	cmp    %rsi,%rdi
 29ec2c9:	cmova  %r8,%rax
 29ec2cd:	mov    (%rax),%esi
 29ec2cf:	mov    0x190(%rsp),%rcx
 29ec2d7:	mov    0x28(%rcx),%rdi
 29ec2db:	cmp    0x23c(%rdi),%esi
 29ec2e1:	sete   %sil
 29ec2e5:	movzbl %sil,%eax
 29ec2e9:	test   %eax,%eax
 29ec2eb:	je     29fc14b <wasm[0]::function[1015]::helper::object_read+0x1b1cb>
 29ec2f1:	test   %edx,%edx
 29ec2f3:	je     29fc14d <wasm[0]::function[1015]::helper::object_read+0x1b1cd>
 29ec2f9:	test   %edx,%edx
 29ec2fb:	je     29fc14f <wasm[0]::function[1015]::helper::object_read+0x1b1cf>
 29ec301:	mov    0x2e0(%rsp),%r12
 29ec309:	mov    0x28(%r12),%r11
 29ec30e:	mov    0x20(%r12),%rax
 29ec313:	mov    %edx,%edx
 29ec315:	lea    (%rax,%rdx,1),%r8
 29ec319:	xor    %rcx,%rcx
 29ec31c:	cmp    %r11,%rdx
 29ec31f:	cmova  %rcx,%r8
 29ec323:	mov    0x14(%r8),%edx
 29ec327:	test   %edx,%edx
 29ec329:	je     29fc151 <wasm[0]::function[1015]::helper::object_read+0x1b1d1>
 29ec32f:	test   %edx,%edx
 29ec331:	je     29fc153 <wasm[0]::function[1015]::helper::object_read+0x1b1d3>
 29ec337:	mov    %edx,%edx
 29ec339:	lea    0x10(%rax,%rdx,1),%rax
 29ec33e:	cmp    %r11,%rdx
 29ec341:	cmova  %rcx,%rax
 29ec345:	mov    (%rax),%eax
 29ec347:	test   %eax,%eax
 29ec349:	setne  %al
 29ec34c:	movzbl %al,%ebx
 29ec34f:	jmp    29ec441 <wasm[0]::function[1015]::helper::object_read+0xb4c1>
 29ec354:	movq   %rsi,%xmm0
 29ec359:	ucomisd 0x105cf(%rip),%xmm0        # 29fc930 <wasm[0]::function[1015]::helper::object_read+0x1b9b0>
 29ec361:	setnp  %al
 29ec364:	sete   %cl
 29ec367:	and    %ecx,%eax
 29ec369:	ucomisd %xmm0,%xmm0
 29ec36d:	setp   %cl
 29ec370:	setne  %dl
 29ec373:	or     %edx,%ecx
 29ec375:	or     %ecx,%eax
 29ec377:	movzbl %al,%eax
 29ec37a:	test   %eax,%eax
 29ec37c:	sete   %al
 29ec37f:	movzbl %al,%ebx
 29ec382:	jmp    29ec441 <wasm[0]::function[1015]::helper::object_read+0xb4c1>
 29ec387:	xor    %eax,%eax
 29ec389:	test   %edx,%edx
 29ec38b:	je     29ec3dc <wasm[0]::function[1015]::helper::object_read+0xb45c>
 29ec391:	xor    %eax,%eax
 29ec393:	test   $0x1,%edx
 29ec399:	jne    29ec3dc <wasm[0]::function[1015]::helper::object_read+0xb45c>
 29ec39f:	mov    0x2e0(%rsp),%r12
 29ec3a7:	mov    0x28(%r12),%rax
 29ec3ac:	mov    0x20(%r12),%rcx
 29ec3b1:	mov    %edx,%esi
 29ec3b3:	lea    0x4(%rcx,%rsi,1),%rcx
 29ec3b8:	xor    %rdi,%rdi
 29ec3bb:	cmp    %rax,%rsi
 29ec3be:	cmova  %rdi,%rcx
 29ec3c2:	mov    (%rcx),%eax
 29ec3c4:	mov    0x190(%rsp),%rcx
 29ec3cc:	mov    0x28(%rcx),%rcx
 29ec3d0:	cmp    0x234(%rcx),%eax
 29ec3d6:	sete   %al
 29ec3d9:	movzbl %al,%eax
 29ec3dc:	test   %eax,%eax
 29ec3de:	je     29fc155 <wasm[0]::function[1015]::helper::object_read+0x1b1d5>
 29ec3e4:	test   %edx,%edx
 29ec3e6:	je     29fc157 <wasm[0]::function[1015]::helper::object_read+0x1b1d7>
 29ec3ec:	test   %edx,%edx
 29ec3ee:	je     29fc159 <wasm[0]::function[1015]::helper::object_read+0x1b1d9>
 29ec3f4:	mov    0x2e0(%rsp),%r12
 29ec3fc:	mov    0x28(%r12),%rax
 29ec401:	mov    0x20(%r12),%rcx
 29ec406:	mov    %edx,%edi
 29ec408:	lea    (%rcx,%rdi,1),%rsi
 29ec40c:	xor    %rdx,%rdx
 29ec40f:	cmp    %rax,%rdi
 29ec412:	cmova  %rdx,%rsi
 29ec416:	mov    0x10(%rsi),%esi
 29ec419:	test   %esi,%esi
 29ec41b:	je     29fc15b <wasm[0]::function[1015]::helper::object_read+0x1b1db>
 29ec421:	test   %esi,%esi
 29ec423:	je     29fc15d <wasm[0]::function[1015]::helper::object_read+0x1b1dd>
 29ec429:	mov    %esi,%esi
 29ec42b:	lea    0x10(%rcx,%rsi,1),%rcx
 29ec430:	cmp    %rax,%rsi
 29ec433:	cmova  %rdx,%rcx
 29ec437:	mov    (%rcx),%eax
 29ec439:	test   %eax,%eax
 29ec43b:	setne  %al
 29ec43e:	movzbl %al,%ebx
 29ec441:	mov    0x2c0(%rsp),%rsi
 29ec449:	jmp    29ec45f <wasm[0]::function[1015]::helper::object_read+0xb4df>
 29ec44e:	test   %rsi,%rsi
 29ec451:	setne  %al
 29ec454:	movzbl %al,%ebx
 29ec457:	mov    0x2c0(%rsp),%rsi
 29ec45f:	mov    0x2c0(%rsp),%rsi
 29ec467:	mov    (%rsi),%eax
 29ec469:	mov    %eax,%edx
 29ec46b:	lea    0x20(%rdx),%rcx
 29ec46f:	mov    0x4(%rsi),%esi
 29ec472:	cmp    %rsi,%rcx
 29ec475:	ja     29fab64 <wasm[0]::function[1015]::helper::object_read+0x19be4>
 29ec47b:	lea    0x20(%rax),%ecx
 29ec47e:	mov    0x2c0(%rsp),%rsi
 29ec486:	mov    %ecx,(%rsi)
 29ec488:	mov    0x2e0(%rsp),%r12
 29ec490:	mov    0x20(%r12),%rsi
 29ec495:	lea    (%rsi,%rdx,1),%rcx
 29ec499:	movl   $0xb0000042,(%rsi,%rdx,1)
 29ec4a0:	mov    0x190(%rsp),%rdi
 29ec4a8:	mov    0x28(%rdi),%rdi
 29ec4ac:	mov    0x120(%rdi),%edi
 29ec4b2:	mov    %edi,0x4(%rsi,%rdx,1)
 29ec4b6:	mov    0x2c8(%rsp),%rdi
 29ec4be:	mov    %edi,0x8(%rsi,%rdx,1)
 29ec4c2:	mov    %eax,0x138(%rsp)
 29ec4c9:	mov    0x240(%rsp),%rax
 29ec4d1:	mov    %rax,0x10(%rcx)
 29ec4d5:	mov    0x248(%rsp),%r10
 29ec4dd:	mov    %r10d,0x18(%rcx)
 29ec4e1:	mov    0x110(%rsp),%eax
 29ec4e8:	mov    %eax,0x1c(%rcx)
 29ec4eb:	mov    0x2c0(%rsp),%rsi
 29ec4f3:	mov    (%rsi),%eax
 29ec4f5:	mov    %eax,%edx
 29ec4f7:	lea    0x20(%rdx),%rcx
 29ec4fb:	mov    0x4(%rsi),%esi
 29ec4fe:	cmp    %rsi,%rcx
 29ec501:	ja     29faba7 <wasm[0]::function[1015]::helper::object_read+0x19c27>
 29ec507:	lea    0x20(%rax),%esi
 29ec50a:	mov    0x2c0(%rsp),%rcx
 29ec512:	mov    %esi,(%rcx)
 29ec514:	mov    0x2e0(%rsp),%r12
 29ec51c:	mov    0x20(%r12),%rsi
 29ec521:	lea    (%rsi,%rdx,1),%rcx
 29ec525:	movl   $0xb0000042,(%rsi,%rdx,1)
 29ec52c:	mov    0x190(%rsp),%r9
 29ec534:	mov    0x28(%r9),%rdi
 29ec538:	mov    0x120(%rdi),%edi
 29ec53e:	mov    %edi,0x4(%rsi,%rdx,1)
 29ec542:	mov    0x2c8(%rsp),%rdi
 29ec54a:	mov    %edi,0x8(%rsi,%rdx,1)
 29ec54e:	mov    %eax,0x110(%rsp)
 29ec555:	mov    0x250(%rsp),%rax
 29ec55d:	mov    %rax,0x10(%rcx)
 29ec561:	mov    0x258(%rsp),%rax
 29ec569:	mov    %eax,0x18(%rcx)
 29ec56c:	mov    0xd8(%rsp),%r11d
 29ec574:	mov    %r11d,0x1c(%rcx)
 29ec578:	mov    0x2c0(%rsp),%rsi
 29ec580:	mov    (%rsi),%eax
 29ec582:	mov    %eax,%edx
 29ec584:	lea    0x20(%rdx),%rcx
 29ec588:	mov    0x4(%rsi),%esi
 29ec58b:	cmp    %rsi,%rcx
 29ec58e:	ja     29fabea <wasm[0]::function[1015]::helper::object_read+0x19c6a>
 29ec594:	lea    0x20(%rax),%ecx
 29ec597:	mov    0x2c0(%rsp),%rsi
 29ec59f:	mov    %ecx,(%rsi)
 29ec5a1:	mov    0x2e0(%rsp),%r12
 29ec5a9:	mov    0x20(%r12),%rsi
 29ec5ae:	lea    (%rsi,%rdx,1),%rcx
 29ec5b2:	movl   $0xb0000042,(%rsi,%rdx,1)
 29ec5b9:	mov    0x190(%rsp),%rdi
 29ec5c1:	mov    0x28(%rdi),%rdi
 29ec5c5:	mov    0x120(%rdi),%edi
 29ec5cb:	mov    %edi,0x4(%rsi,%rdx,1)
 29ec5cf:	mov    0x2c8(%rsp),%rdi
 29ec5d7:	mov    %edi,0x8(%rsi,%rdx,1)
 29ec5db:	mov    %eax,0xd8(%rsp)
 29ec5e2:	mov    0x260(%rsp),%rdx
 29ec5ea:	mov    %rdx,0x10(%rcx)
 29ec5ee:	mov    0x268(%rsp),%rdx
 29ec5f6:	mov    %edx,0x18(%rcx)
 29ec5f9:	mov    0x130(%rsp),%edx
 29ec600:	mov    %edx,0x1c(%rcx)
 29ec603:	mov    0x270(%rsp),%rcx
 29ec60b:	mov    0x270(%rsp),%rdx
 29ec613:	test   %edx,%ecx
 29ec615:	jne    29ec6f4 <wasm[0]::function[1015]::helper::object_read+0xb774>
 29ec61b:	mov    0x138(%rsp),%ecx
 29ec622:	test   %ecx,%ecx
 29ec624:	je     29fc15f <wasm[0]::function[1015]::helper::object_read+0x1b1df>
 29ec62a:	mov    0x110(%rsp),%ecx
 29ec631:	test   %ecx,%ecx
 29ec633:	je     29fc161 <wasm[0]::function[1015]::helper::object_read+0x1b1e1>
 29ec639:	test   %eax,%eax
 29ec63b:	je     29fc163 <wasm[0]::function[1015]::helper::object_read+0x1b1e3>
 29ec641:	mov    0x2c0(%rsp),%rsi
 29ec649:	mov    (%rsi),%eax
 29ec64b:	mov    %eax,%edx
 29ec64d:	lea    0x20(%rdx),%rcx
 29ec651:	mov    0x4(%rsi),%esi
 29ec654:	cmp    %rsi,%rcx
 29ec657:	ja     29fac2d <wasm[0]::function[1015]::helper::object_read+0x19cad>
 29ec65d:	lea    0x20(%rax),%ecx
 29ec660:	mov    0x2c0(%rsp),%rsi
 29ec668:	mov    %ecx,(%rsi)
 29ec66a:	mov    0x2e0(%rsp),%r12
 29ec672:	mov    0x20(%r12),%rsi
 29ec677:	lea    (%rsi,%rdx,1),%rcx
 29ec67b:	movl   $0xb0000072,(%rsi,%rdx,1)
 29ec682:	mov    0x190(%rsp),%rdi
 29ec68a:	mov    0x28(%rdi),%rdi
 29ec68e:	mov    0x13c(%rdi),%edi
 29ec694:	mov    %edi,0x4(%rsi,%rdx,1)
 29ec698:	mov    0x2c8(%rsp),%rdi
 29ec6a0:	mov    %edi,0x8(%rsi,%rdx,1)
 29ec6a4:	test   %r13d,%r13d
 29ec6a7:	setne  %dl
 29ec6aa:	movzbl %dl,%edx
 29ec6ad:	shl    $0x2,%edx
 29ec6b0:	test   %r14d,%r14d
 29ec6b3:	setne  %sil
 29ec6b7:	movzbl %sil,%esi
 29ec6bb:	shl    $0x3,%esi
 29ec6be:	or     %esi,%edx
 29ec6c0:	test   %ebx,%ebx
 29ec6c2:	setne  %sil
 29ec6c6:	movzbl %sil,%esi
 29ec6ca:	shl    $1,%esi
 29ec6cc:	or     %esi,%edx
 29ec6ce:	mov    %edx,0x10(%rcx)
 29ec6d1:	mov    0x138(%rsp),%edx
 29ec6d8:	mov    %edx,0x14(%rcx)
 29ec6db:	mov    0x110(%rsp),%edx
 29ec6e2:	mov    %edx,0x18(%rcx)
 29ec6e5:	mov    0xd8(%rsp),%edx
 29ec6ec:	mov    %edx,0x1c(%rcx)
 29ec6ef:	jmp    29ec7bb <wasm[0]::function[1015]::helper::object_read+0xb83b>
 29ec6f4:	mov    0x138(%rsp),%ecx
 29ec6fb:	test   %ecx,%ecx
 29ec6fd:	je     29fc165 <wasm[0]::function[1015]::helper::object_read+0x1b1e5>
 29ec703:	mov    0x110(%rsp),%ecx
 29ec70a:	test   %ecx,%ecx
 29ec70c:	je     29fc167 <wasm[0]::function[1015]::helper::object_read+0x1b1e7>
 29ec712:	test   %eax,%eax
 29ec714:	je     29fc169 <wasm[0]::function[1015]::helper::object_read+0x1b1e9>
 29ec71a:	mov    0x2c0(%rsp),%rsi
 29ec722:	mov    (%rsi),%eax
 29ec724:	mov    %eax,%edx
 29ec726:	lea    0x20(%rdx),%rcx
 29ec72a:	mov    0x4(%rsi),%esi
 29ec72d:	cmp    %rsi,%rcx
 29ec730:	ja     29fac70 <wasm[0]::function[1015]::helper::object_read+0x19cf0>
 29ec736:	lea    0x20(%rax),%ecx
 29ec739:	mov    0x2c0(%rsp),%rsi
 29ec741:	mov    %ecx,(%rsi)
 29ec743:	mov    0x2e0(%rsp),%r12
 29ec74b:	mov    0x20(%r12),%rsi
 29ec750:	lea    (%rsi,%rdx,1),%rcx
 29ec754:	movl   $0xb0000072,(%rsi,%rdx,1)
 29ec75b:	mov    0x190(%rsp),%rdi
 29ec763:	mov    0x28(%rdi),%rdi
 29ec767:	mov    0x13c(%rdi),%edi
 29ec76d:	mov    %edi,0x4(%rsi,%rdx,1)
 29ec771:	mov    0x2c8(%rsp),%rdi
 29ec779:	mov    %edi,0x8(%rsi,%rdx,1)
 29ec77d:	test   %r14d,%r14d
 29ec780:	setne  %dl
 29ec783:	movzbl %dl,%edx
 29ec786:	shl    $0x3,%edx
 29ec789:	or     $0x1,%edx
 29ec78c:	test   %ebx,%ebx
 29ec78e:	setne  %sil
 29ec792:	movzbl %sil,%esi
 29ec796:	shl    $1,%esi
 29ec798:	or     %esi,%edx
 29ec79a:	mov    %edx,0x10(%rcx)
 29ec79d:	mov    0x138(%rsp),%edx
 29ec7a4:	mov    %edx,0x14(%rcx)
 29ec7a7:	mov    0x110(%rsp),%esi
 29ec7ae:	mov    %esi,0x18(%rcx)
 29ec7b1:	mov    0xd8(%rsp),%esi
 29ec7b8:	mov    %esi,0x1c(%rcx)
 29ec7bb:	mov    0xa0(%rsp),%esi
 29ec7c2:	mov    0x118(%rsp),%edi
 29ec7c9:	mov    0xe0(%rsp),%r8d
 29ec7d1:	mov    0x100(%rsp),%edx
 29ec7d8:	mov    0xc8(%rsp),%ecx
 29ec7df:	mov    %rax,%r15
 29ec7e2:	jmp    29ef2e7 <wasm[0]::function[1015]::helper::object_read+0xe367>
 29ec7e7:	mov    0xb0(%rsp),%edx
 29ec7ee:	mov    0x2a8(%rsp),%rax
 29ec7f6:	mov    0x2b0(%rsp),%rcx
 29ec7fe:	mov    0x2f0(%rsp),%rbx
 29ec806:	mov    0x2f8(%rsp),%r12
 29ec80e:	mov    0x300(%rsp),%r13
 29ec816:	mov    0x308(%rsp),%r14
 29ec81e:	mov    0x310(%rsp),%r15
 29ec826:	add    $0x320,%rsp
 29ec82d:	mov    %rbp,%rsp
 29ec830:	pop    %rbp
 29ec831:	ret    $0x40
 29ec834:	xor    %eax,%eax
 29ec836:	mov    0x210(%rsp),%rdx
 29ec83e:	mov    0x210(%rsp),%rsi
 29ec846:	test   %esi,%edx
 29ec848:	je     29ec8a9 <wasm[0]::function[1015]::helper::object_read+0xb929>
 29ec84e:	xor    %eax,%eax
 29ec850:	mov    0x210(%rsp),%rdx
 29ec858:	test   $0x1,%edx
 29ec85e:	jne    29ec8a9 <wasm[0]::function[1015]::helper::object_read+0xb929>
 29ec864:	mov    0x2e0(%rsp),%r12
 29ec86c:	mov    0x28(%r12),%rax
 29ec871:	mov    0x20(%r12),%rcx
 29ec876:	mov    0x210(%rsp),%rdx
 29ec87e:	mov    %edx,%edx
 29ec880:	lea    0x4(%rcx,%rdx,1),%rcx
 29ec885:	xor    %rsi,%rsi
 29ec888:	cmp    %rax,%rdx
 29ec88b:	cmova  %rsi,%rcx
 29ec88f:	mov    (%rcx),%eax
 29ec891:	mov    0x190(%rsp),%rcx
 29ec899:	mov    0x28(%rcx),%rcx
 29ec89d:	cmp    0x254(%rcx),%eax
 29ec8a3:	sete   %al
 29ec8a6:	movzbl %al,%eax
 29ec8a9:	test   %eax,%eax
 29ec8ab:	je     29fc16b <wasm[0]::function[1015]::helper::object_read+0x1b1eb>
 29ec8b1:	mov    0x210(%rsp),%rax
 29ec8b9:	mov    0x210(%rsp),%rdx
 29ec8c1:	test   %eax,%edx
 29ec8c3:	je     29fc16d <wasm[0]::function[1015]::helper::object_read+0x1b1ed>
 29ec8c9:	test   %eax,%edx
 29ec8cb:	je     29fc16f <wasm[0]::function[1015]::helper::object_read+0x1b1ef>
 29ec8d1:	mov    0x2e0(%rsp),%r12
 29ec8d9:	mov    0x28(%r12),%rax
 29ec8de:	mov    0x20(%r12),%rcx
 29ec8e3:	mov    %edx,%edx
 29ec8e5:	add    %rdx,%rcx
 29ec8e8:	xor    %rsi,%rsi
 29ec8eb:	cmp    %rax,%rdx
 29ec8ee:	cmova  %rsi,%rcx
 29ec8f2:	mov    0x10(%rcx),%edx
 29ec8f5:	test   %edx,%edx
 29ec8f7:	je     29fc171 <wasm[0]::function[1015]::helper::object_read+0x1b1f1>
 29ec8fd:	mov    0x1b8(%rsp),%rcx
 29ec905:	mov    0x190(%rsp),%rsi
 29ec90d:	mov    0x190(%rsp),%rdi
 29ec915:	mov    0x1c0(%rsp),%r8
 29ec91d:	call   29ffc60 <wasm[0]::function[1019]::helper::ordinary_own_descriptor>
 29ec922:	mov    %rax,%r11
 29ec925:	mov    0xc0(%rsp),%eax
 29ec92c:	mov    %rax,%r15
 29ec92f:	mov    0x58(%rsp),%ecx
 29ec933:	mov    0xa8(%rsp),%edx
 29ec93a:	mov    0xb8(%rsp),%edi
 29ec941:	mov    0x48(%rsp),%r8d
 29ec946:	mov    0x80(%rsp),%esi
 29ec94d:	mov    %r11,%rax
 29ec950:	test   %eax,%eax
 29ec952:	jne    29eeb83 <wasm[0]::function[1015]::helper::object_read+0xdc03>
 29ec958:	xor    %r9d,%r9d
 29ec95b:	mov    0x1b8(%rsp),%r10
 29ec963:	cmp    $0x4,%r10d
 29ec967:	je     29ec975 <wasm[0]::function[1015]::helper::object_read+0xb9f5>
 29ec96d:	mov    %r8,%r10
 29ec970:	jmp    29ecd3b <wasm[0]::function[1015]::helper::object_read+0xbdbb>
 29ec975:	xor    %r9d,%r9d
 29ec978:	test   %esi,%esi
 29ec97a:	je     29ec9d1 <wasm[0]::function[1015]::helper::object_read+0xba51>
 29ec980:	xor    %r9d,%r9d
 29ec983:	test   $0x1,%esi
 29ec989:	jne    29ec9d1 <wasm[0]::function[1015]::helper::object_read+0xba51>
 29ec98f:	mov    0x2e0(%rsp),%r12
 29ec997:	mov    0x28(%r12),%r9
 29ec99c:	mov    0x20(%r12),%r10
 29ec9a1:	mov    %esi,%r11d
 29ec9a4:	lea    0x4(%r10,%r11,1),%r10
 29ec9a9:	xor    %rbx,%rbx
 29ec9ac:	cmp    %r9,%r11
 29ec9af:	cmova  %rbx,%r10
 29ec9b3:	mov    (%r10),%r9d
 29ec9b6:	mov    0x190(%rsp),%r10
 29ec9be:	mov    0x28(%r10),%r10
 29ec9c2:	cmp    0x234(%r10),%r9d
 29ec9c9:	sete   %r9b
 29ec9cd:	movzbl %r9b,%r9d
 29ec9d1:	test   %r9d,%r9d
 29ec9d4:	je     29fc173 <wasm[0]::function[1015]::helper::object_read+0x1b1f3>
 29ec9da:	test   %esi,%esi
 29ec9dc:	je     29fc175 <wasm[0]::function[1015]::helper::object_read+0x1b1f5>
 29ec9e2:	test   %esi,%esi
 29ec9e4:	je     29fc177 <wasm[0]::function[1015]::helper::object_read+0x1b1f7>
 29ec9ea:	mov    0x2e0(%rsp),%r12
 29ec9f2:	mov    0x28(%r12),%r10
 29ec9f7:	mov    0x20(%r12),%r11
 29ec9fc:	mov    %esi,%r12d
 29ec9ff:	lea    (%r11,%r12,1),%r9
 29eca03:	xor    %rbx,%rbx
 29eca06:	cmp    %r10,%r12
 29eca09:	cmova  %rbx,%r9
 29eca0d:	mov    0x10(%r9),%r12d
 29eca11:	mov    %r12d,0xb0(%rsp)
 29eca19:	xor    %r9d,%r9d
 29eca1c:	test   %r12d,%r12d
 29eca1f:	je     29fc179 <wasm[0]::function[1015]::helper::object_read+0x1b1f9>
 29eca25:	test   %r12d,%r12d
 29eca28:	je     29fc17b <wasm[0]::function[1015]::helper::object_read+0x1b1fb>
 29eca2e:	mov    %r12d,%r12d
 29eca31:	lea    0x10(%r11,%r12,1),%r11
 29eca36:	cmp    %r10,%r12
 29eca39:	cmova  %rbx,%r11
 29eca3d:	mov    (%r11),%ebx
 29eca40:	test   %ebx,%ebx
 29eca42:	sete   %r10b
 29eca46:	cmp    $0xa,%ebx
 29eca49:	seta   %r11b
 29eca4d:	or     %r11d,%r10d
 29eca50:	test   %r10b,%r10b
 29eca53:	je     29eca61 <wasm[0]::function[1015]::helper::object_read+0xbae1>
 29eca59:	mov    %r8,%r10
 29eca5c:	jmp    29ecd3b <wasm[0]::function[1015]::helper::object_read+0xbdbb>
 29eca61:	mov    0xb0(%rsp),%ecx
 29eca68:	test   %ecx,%ecx
 29eca6a:	je     29fc17d <wasm[0]::function[1015]::helper::object_read+0x1b1fd>
 29eca70:	test   %ecx,%ecx
 29eca72:	je     29fc17f <wasm[0]::function[1015]::helper::object_read+0x1b1ff>
 29eca78:	mov    0x2e0(%rsp),%r12
 29eca80:	mov    0x28(%r12),%rdx
 29eca85:	mov    0x20(%r12),%rsi
 29eca8a:	mov    %ecx,%r9d
 29eca8d:	lea    0x10(%rsi,%r9,1),%r8
 29eca92:	xor    %rdi,%rdi
 29eca95:	cmp    %rdx,%r9
 29eca98:	cmova  %rdi,%r8
 29eca9c:	mov    (%r8),%r8d
 29eca9f:	test   %r8d,%r8d
 29ecaa2:	je     29fc181 <wasm[0]::function[1015]::helper::object_read+0x1b201>
 29ecaa8:	mov    %r8d,%r9d
 29ecaab:	shl    $1,%r9
 29ecaae:	shr    $0x20,%r9
 29ecab2:	test   %r9,%r9
 29ecab5:	jne    29fc183 <wasm[0]::function[1015]::helper::object_read+0x1b203>
 29ecabb:	add    %r8d,%r8d
 29ecabe:	add    $0x14,%r8d
 29ecac2:	jb     29fc185 <wasm[0]::function[1015]::helper::object_read+0x1b205>
 29ecac8:	add    %r8d,%ecx
 29ecacb:	jb     29fc187 <wasm[0]::function[1015]::helper::object_read+0x1b207>
 29ecad1:	mov    %ecx,%r9d
 29ecad4:	add    %r9,%rsi
 29ecad7:	cmp    %rdx,%r9
 29ecada:	cmova  %rdi,%rsi
 29ecade:	sub    $0x14,%r8d
 29ecae2:	sub    %r8,%rsi
 29ecae5:	movzwl (%rsi),%r9d
 29ecae9:	cmp    $0x30,%r9d
 29ecaed:	je     29eccef <wasm[0]::function[1015]::helper::object_read+0xbd6f>
 29ecaf3:	mov    0x48(%rsp),%r10d
 29ecaf8:	mov    0x80(%rsp),%esi
 29ecaff:	mov    0xc0(%rsp),%ecx
 29ecb06:	mov    %rcx,%r15
 29ecb09:	mov    0x58(%rsp),%ecx
 29ecb0d:	mov    0xa8(%rsp),%edx
 29ecb14:	mov    0xb8(%rsp),%edi
 29ecb1b:	xor    %r14d,%r14d
 29ecb1e:	xor    %r13,%r13
 29ecb21:	mov    %r10,%r8
 29ecb24:	mov    %r10d,0x138(%rsp)
 29ecb2c:	mov    %esi,0x110(%rsp)
 29ecb33:	mov    %eax,0xd8(%rsp)
 29ecb3a:	mov    %r15,%rax
 29ecb3d:	mov    %eax,0xc8(%rsp)
 29ecb44:	mov    %ecx,0x100(%rsp)
 29ecb4b:	mov    %edx,0xe0(%rsp)
 29ecb52:	mov    %edi,0x118(%rsp)
 29ecb59:	mov    %r8d,0xa0(%rsp)
 29ecb61:	mov    0x2e8(%rsp),%r10
 29ecb69:	mov    (%r10),%rax
 29ecb6c:	mov    0x228(%rsp),%rsi
 29ecb74:	cmp    %rsi,%rax
 29ecb77:	jae    29facb3 <wasm[0]::function[1015]::helper::object_read+0x19d33>
 29ecb7d:	mov    0xb0(%rsp),%r11d
 29ecb85:	xor    %r9d,%r9d
 29ecb88:	test   %r11d,%r11d
 29ecb8b:	je     29fc189 <wasm[0]::function[1015]::helper::object_read+0x1b209>
 29ecb91:	test   %r11d,%r11d
 29ecb94:	je     29fc18b <wasm[0]::function[1015]::helper::object_read+0x1b20b>
 29ecb9a:	mov    0x2e0(%rsp),%r12
 29ecba2:	mov    0x28(%r12),%rax
 29ecba7:	mov    0x20(%r12),%rcx
 29ecbac:	mov    %r11d,%edi
 29ecbaf:	lea    0x10(%rcx,%rdi,1),%rsi
 29ecbb4:	xor    %rdx,%rdx
 29ecbb7:	cmp    %rax,%rdi
 29ecbba:	cmova  %rdx,%rsi
 29ecbbe:	mov    (%rsi),%esi
 29ecbc0:	cmp    %esi,%r14d
 29ecbc3:	jae    29fc18d <wasm[0]::function[1015]::helper::object_read+0x1b20d>
 29ecbc9:	mov    %esi,%edi
 29ecbcb:	shl    $1,%rdi
 29ecbce:	shr    $0x20,%rdi
 29ecbd2:	test   %rdi,%rdi
 29ecbd5:	jne    29fc18f <wasm[0]::function[1015]::helper::object_read+0x1b20f>
 29ecbdb:	add    %esi,%esi
 29ecbdd:	add    $0x14,%esi
 29ecbe0:	jb     29fc191 <wasm[0]::function[1015]::helper::object_read+0x1b211>
 29ecbe6:	add    %esi,%r11d
 29ecbe9:	jb     29fc193 <wasm[0]::function[1015]::helper::object_read+0x1b213>
 29ecbef:	mov    %r11d,%edi
 29ecbf2:	add    %rdi,%rcx
 29ecbf5:	cmp    %rax,%rdi
 29ecbf8:	cmova  %rdx,%rcx
 29ecbfc:	lea    0x14(%r14,%r14,1),%eax
 29ecc01:	sub    %eax,%esi
 29ecc03:	sub    %rsi,%rcx
 29ecc06:	movzwq (%rcx),%r11
 29ecc0a:	mov    0x138(%rsp),%r10d
 29ecc12:	mov    0x110(%rsp),%esi
 29ecc19:	mov    0xd8(%rsp),%eax
 29ecc20:	mov    0xc8(%rsp),%ecx
 29ecc27:	mov    %rcx,%r15
 29ecc2a:	mov    0x100(%rsp),%ecx
 29ecc31:	mov    0xe0(%rsp),%edx
 29ecc38:	mov    0x118(%rsp),%edi
 29ecc3f:	mov    0xa0(%rsp),%r8d
 29ecc47:	movzwl %r11w,%r11d
 29ecc4b:	mov    %r11,%r12
 29ecc4e:	sub    $0x30,%r12d
 29ecc52:	cmp    $0x9,%r12d
 29ecc56:	ja     29ecd3b <wasm[0]::function[1015]::helper::object_read+0xbdbb>
 29ecc5c:	mov    0x138(%rsp),%r10d
 29ecc64:	mov    0x110(%rsp),%esi
 29ecc6b:	mov    0xd8(%rsp),%eax
 29ecc72:	mov    0xc8(%rsp),%edi
 29ecc79:	mov    %rdi,%r15
 29ecc7c:	mov    0x100(%rsp),%ecx
 29ecc83:	mov    0xe0(%rsp),%edx
 29ecc8a:	mov    0x118(%rsp),%edi
 29ecc91:	mov    0xa0(%rsp),%r8d
 29ecc99:	add    $0x1,%r14d
 29ecca0:	imul   $0xa,%r13,%r9
 29ecca4:	mov    %r11,%r12
 29ecca7:	sub    $0x30,%r12d
 29eccab:	add    %r9,%r12
 29eccae:	cmp    %ebx,%r14d
 29eccb1:	jae    29eccbf <wasm[0]::function[1015]::helper::object_read+0xbd3f>
 29eccb7:	mov    %r12,%r13
 29eccba:	jmp    29ecb24 <wasm[0]::function[1015]::helper::object_read+0xbba4>
 29eccbf:	xor    %r9d,%r9d
 29eccc2:	cmp    0xfc3f(%rip),%r12        # 29fc908 <wasm[0]::function[1015]::helper::object_read+0x1b988>
 29eccc9:	jae    29ecd3b <wasm[0]::function[1015]::helper::object_read+0xbdbb>
 29ecccf:	imul   $0xa,%r13d,%r9d
 29eccd3:	sub    $0x30,%r11d
 29eccd7:	add    %r11d,%r9d
 29eccda:	mov    %r9,0x200(%rsp)
 29ecce2:	mov    0x278(%rsp),%r9
 29eccea:	jmp    29ecd3b <wasm[0]::function[1015]::helper::object_read+0xbdbb>
 29eccef:	mov    0x48(%rsp),%r10d
 29eccf4:	mov    0x80(%rsp),%esi
 29eccfb:	mov    0xc0(%rsp),%ecx
 29ecd02:	mov    %rcx,%r15
 29ecd05:	mov    0x58(%rsp),%ecx
 29ecd09:	mov    0xa8(%rsp),%edx
 29ecd10:	mov    0xb8(%rsp),%edi
 29ecd17:	cmp    $0x1,%ebx
 29ecd1a:	sete   %r8b
 29ecd1e:	movzbl %r8b,%r9d
 29ecd22:	mov    %r8,%r11
 29ecd25:	mov    %r8,0x200(%rsp)
 29ecd2d:	xor    %r11d,%r8d
 29ecd30:	mov    %r8,0x200(%rsp)
 29ecd38:	mov    %r10,%r8
 29ecd3b:	mov    %r10d,0xa0(%rsp)
 29ecd43:	mov    %esi,0x118(%rsp)
 29ecd4a:	mov    %eax,0xe0(%rsp)
 29ecd51:	mov    %r15,%rax
 29ecd54:	mov    %eax,0x100(%rsp)
 29ecd5b:	mov    %ecx,0xc8(%rsp)
 29ecd62:	mov    %edx,0xd8(%rsp)
 29ecd69:	mov    %edi,0x110(%rsp)
 29ecd70:	mov    %r8d,0x138(%rsp)
 29ecd78:	test   %r9d,%r9d
 29ecd7b:	jne    29ed70c <wasm[0]::function[1015]::helper::object_read+0xc78c>
 29ecd81:	mov    $0x8c,%edx
 29ecd86:	mov    0x190(%rsp),%rsi
 29ecd8e:	mov    0x190(%rsp),%rdi
 29ecd96:	call   2f30600 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 29ecd9b:	test   %eax,%eax
 29ecd9d:	je     29fc195 <wasm[0]::function[1015]::helper::object_read+0x1b215>
 29ecda3:	mov    0x1b8(%rsp),%rcx
 29ecdab:	cmp    $0x4,%ecx
 29ecdae:	je     29ecdff <wasm[0]::function[1015]::helper::object_read+0xbe7f>
 29ecdb4:	mov    0xa0(%rsp),%ecx
 29ecdbb:	mov    0xe0(%rsp),%eax
 29ecdc2:	mov    %rax,%r11
 29ecdc5:	mov    0x100(%rsp),%esi
 29ecdcc:	mov    0xc8(%rsp),%edi
 29ecdd3:	mov    0xd8(%rsp),%r8d
 29ecddb:	mov    0x110(%rsp),%r9d
 29ecde3:	mov    0x138(%rsp),%r10d
 29ecdeb:	mov    0x118(%rsp),%edx
 29ecdf2:	xor    %eax,%eax
 29ecdf4:	mov    %rax,%r14
 29ecdf7:	mov    %r11,%rax
 29ecdfa:	jmp    29ed4db <wasm[0]::function[1015]::helper::object_read+0xc55b>
 29ecdff:	mov    0x1b8(%rsp),%rcx
 29ece07:	cmp    $0x3,%ecx
 29ece0a:	je     29ed44a <wasm[0]::function[1015]::helper::object_read+0xc4ca>
 29ece10:	mov    0x1b8(%rsp),%rcx
 29ece18:	cmp    $0x4,%ecx
 29ece1b:	je     29ed2f3 <wasm[0]::function[1015]::helper::object_read+0xc373>
 29ece21:	mov    0x1b8(%rsp),%rcx
 29ece29:	cmp    $0xa,%ecx
 29ece2c:	je     29eceeb <wasm[0]::function[1015]::helper::object_read+0xbf6b>
 29ece32:	mov    0x1b8(%rsp),%rcx
 29ece3a:	mov    0x1b8(%rsp),%rdx
 29ece42:	test   %edx,%ecx
 29ece44:	sete   %r11b
 29ece48:	cmp    $0x1,%ecx
 29ece4b:	sete   %cl
 29ece4e:	or     %ecx,%r11d
 29ece51:	test   %r11b,%r11b
 29ece54:	jne    29ecea3 <wasm[0]::function[1015]::helper::object_read+0xbf23>
 29ece5a:	mov    0x1b8(%rsp),%rcx
 29ece62:	cmp    $0x2,%ecx
 29ece65:	je     29ece82 <wasm[0]::function[1015]::helper::object_read+0xbf02>
 29ece6b:	mov    0x118(%rsp),%ecx
 29ece72:	cmp    %eax,%ecx
 29ece74:	sete   %al
 29ece77:	movzbl %al,%eax
 29ece7a:	mov    %rax,%r14
 29ece7d:	jmp    29eceab <wasm[0]::function[1015]::helper::object_read+0xbf2b>
 29ece82:	mov    0x1c0(%rsp),%rax
 29ece8a:	mov    0x1c0(%rsp),%r8
 29ece92:	test   %rax,%r8
 29ece95:	sete   %al
 29ece98:	movzbl %al,%eax
 29ece9b:	mov    %rax,%r14
 29ece9e:	jmp    29eceab <wasm[0]::function[1015]::helper::object_read+0xbf2b>
 29ecea3:	mov    0x278(%rsp),%r14
 29eceab:	mov    0xa0(%rsp),%ecx
 29eceb2:	mov    0xe0(%rsp),%eax
 29eceb9:	mov    0x100(%rsp),%esi
 29ecec0:	mov    0xc8(%rsp),%edi
 29ecec7:	mov    0xd8(%rsp),%r8d
 29ececf:	mov    0x110(%rsp),%r9d
 29eced7:	mov    0x138(%rsp),%r10d
 29ecedf:	mov    0x118(%rsp),%edx
 29ecee6:	jmp    29ed4db <wasm[0]::function[1015]::helper::object_read+0xc55b>
 29eceeb:	mov    0x118(%rsp),%edx
 29ecef2:	xor    %ecx,%ecx
 29ecef4:	test   %edx,%edx
 29ecef6:	je     29ecf47 <wasm[0]::function[1015]::helper::object_read+0xbfc7>
 29ecefc:	xor    %ecx,%ecx
 29ecefe:	test   $0x1,%edx
 29ecf04:	jne    29ecf47 <wasm[0]::function[1015]::helper::object_read+0xbfc7>
 29ecf0a:	mov    0x2e0(%rsp),%r12
 29ecf12:	mov    0x28(%r12),%rcx
 29ecf17:	mov    0x20(%r12),%rdi
 29ecf1c:	mov    %edx,%esi
 29ecf1e:	lea    0x4(%rdi,%rsi,1),%rdx
 29ecf23:	xor    %rdi,%rdi
 29ecf26:	cmp    %rcx,%rsi
 29ecf29:	cmova  %rdi,%rdx
 29ecf2d:	mov    (%rdx),%ecx
 29ecf2f:	mov    0x190(%rsp),%rdx
 29ecf37:	mov    0x28(%rdx),%rdx
 29ecf3b:	cmp    0x23c(%rdx),%ecx
 29ecf41:	sete   %cl
 29ecf44:	movzbl %cl,%ecx
 29ecf47:	test   %ecx,%ecx
 29ecf49:	je     29fc197 <wasm[0]::function[1015]::helper::object_read+0x1b217>
 29ecf4f:	xor    %edx,%edx
 29ecf51:	test   %eax,%eax
 29ecf53:	je     29ecfa3 <wasm[0]::function[1015]::helper::object_read+0xc023>
 29ecf59:	xor    %edx,%edx
 29ecf5b:	test   $0x1,%eax
 29ecf60:	jne    29ecfa3 <wasm[0]::function[1015]::helper::object_read+0xc023>
 29ecf66:	mov    0x2e0(%rsp),%r12
 29ecf6e:	mov    0x28(%r12),%rcx
 29ecf73:	mov    0x20(%r12),%rdx
 29ecf78:	mov    %eax,%esi
 29ecf7a:	lea    0x4(%rdx,%rsi,1),%rdx
 29ecf7f:	xor    %rdi,%rdi
 29ecf82:	cmp    %rcx,%rsi
 29ecf85:	cmova  %rdi,%rdx
 29ecf89:	mov    (%rdx),%ecx
 29ecf8b:	mov    0x190(%rsp),%rdx
 29ecf93:	mov    0x28(%rdx),%rdx
 29ecf97:	cmp    0x23c(%rdx),%ecx
 29ecf9d:	sete   %cl
 29ecfa0:	movzbl %cl,%edx
 29ecfa3:	test   %edx,%edx
 29ecfa5:	je     29fc199 <wasm[0]::function[1015]::helper::object_read+0x1b219>
 29ecfab:	mov    0x118(%rsp),%edx
 29ecfb2:	test   %edx,%edx
 29ecfb4:	je     29fc19b <wasm[0]::function[1015]::helper::object_read+0x1b21b>
 29ecfba:	test   %edx,%edx
 29ecfbc:	je     29fc19d <wasm[0]::function[1015]::helper::object_read+0x1b21d>
 29ecfc2:	mov    0x2e0(%rsp),%r12
 29ecfca:	mov    0x28(%r12),%rcx
 29ecfcf:	mov    0x20(%r12),%rsi
 29ecfd4:	mov    %edx,%r9d
 29ecfd7:	lea    (%rsi,%r9,1),%r8
 29ecfdb:	xor    %rdi,%rdi
 29ecfde:	cmp    %rcx,%r9
 29ecfe1:	cmova  %rdi,%r8
 29ecfe5:	mov    0x10(%r8),%r11d
 29ecfe9:	test   %eax,%eax
 29ecfeb:	je     29fc19f <wasm[0]::function[1015]::helper::object_read+0x1b21f>
 29ecff1:	mov    %eax,%r9d
 29ecff4:	lea    (%rsi,%r9,1),%rax
 29ecff8:	cmp    %rcx,%r9
 29ecffb:	cmova  %rdi,%rax
 29ecfff:	mov    0x10(%rax),%r12d
 29ed003:	mov    0x14(%r8),%r8d
 29ed007:	mov    %r8d,0xb0(%rsp)
 29ed00f:	mov    0x14(%rax),%eax
 29ed012:	mov    %eax,0x130(%rsp)
 29ed019:	test   %r8d,%r8d
 29ed01c:	je     29fc1a1 <wasm[0]::function[1015]::helper::object_read+0x1b221>
 29ed022:	test   %r8d,%r8d
 29ed025:	je     29fc1a3 <wasm[0]::function[1015]::helper::object_read+0x1b223>
 29ed02b:	mov    %r8d,%r9d
 29ed02e:	lea    0x10(%rsi,%r9,1),%r8
 29ed033:	cmp    %rcx,%r9
 29ed036:	cmova  %rdi,%r8
 29ed03a:	mov    (%r8),%ebx
 29ed03d:	test   %eax,%eax
 29ed03f:	je     29fc1a5 <wasm[0]::function[1015]::helper::object_read+0x1b225>
 29ed045:	test   %eax,%eax
 29ed047:	je     29fc1a7 <wasm[0]::function[1015]::helper::object_read+0x1b227>
 29ed04d:	mov    %eax,%r8d
 29ed050:	lea    0x10(%rsi,%r8,1),%rsi
 29ed055:	cmp    %rcx,%r8
 29ed058:	cmova  %rdi,%rsi
 29ed05c:	mov    (%rsi),%r13d
 29ed05f:	mov    0xa0(%rsp),%ecx
 29ed066:	mov    0xe0(%rsp),%eax
 29ed06d:	mov    0x100(%rsp),%esi
 29ed074:	mov    0xc8(%rsp),%edi
 29ed07b:	mov    0xd8(%rsp),%r8d
 29ed083:	mov    0x110(%rsp),%r9d
 29ed08b:	mov    0x138(%rsp),%r10d
 29ed093:	cmp    %r12d,%r11d
 29ed096:	sete   %r11b
 29ed09a:	cmp    %r13d,%ebx
 29ed09d:	sete   %r12b
 29ed0a1:	mov    %r11,%r13
 29ed0a4:	and    %r12d,%r13d
 29ed0a7:	movzbl %r13b,%r13d
 29ed0ab:	mov    %r13,%r14
 29ed0ae:	test   %r11b,%r12b
 29ed0b1:	je     29ed4db <wasm[0]::function[1015]::helper::object_read+0xc55b>
 29ed0b7:	mov    0xa0(%rsp),%ecx
 29ed0be:	mov    0xe0(%rsp),%edx
 29ed0c5:	mov    0x100(%rsp),%esi
 29ed0cc:	mov    0xc8(%rsp),%edi
 29ed0d3:	mov    0xd8(%rsp),%r8d
 29ed0db:	mov    0x110(%rsp),%r9d
 29ed0e3:	mov    0x138(%rsp),%r10d
 29ed0eb:	mov    0x118(%rsp),%r11d
 29ed0f3:	xor    %r12d,%r12d
 29ed0f6:	mov    %ecx,0x90(%rsp)
 29ed0fd:	mov    %edx,0x128(%rsp)
 29ed104:	mov    %esi,0x98(%rsp)
 29ed10b:	mov    %edi,0x88(%rsp)
 29ed112:	mov    %r8d,0x78(%rsp)
 29ed117:	mov    %r9d,0x108(%rsp)
 29ed11f:	mov    %r10d,0x120(%rsp)
 29ed127:	mov    %r11d,0xf8(%rsp)
 29ed12f:	mov    0x2e8(%rsp),%r13
 29ed137:	mov    0x0(%r13),%rcx
 29ed13b:	mov    0x228(%rsp),%rax
 29ed143:	cmp    %rax,%rcx
 29ed146:	jae    29facee <wasm[0]::function[1015]::helper::object_read+0x19d6e>
 29ed14c:	cmp    %ebx,%r12d
 29ed14f:	jae    29ed2b6 <wasm[0]::function[1015]::helper::object_read+0xc336>
 29ed155:	mov    0xb0(%rsp),%edi
 29ed15c:	test   %edi,%edi
 29ed15e:	je     29fc1a9 <wasm[0]::function[1015]::helper::object_read+0x1b229>
 29ed164:	test   %edi,%edi
 29ed166:	je     29fc1ab <wasm[0]::function[1015]::helper::object_read+0x1b22b>
 29ed16c:	mov    0x2e0(%rsp),%rax
 29ed174:	mov    0x28(%rax),%rcx
 29ed178:	mov    0x20(%rax),%rdx
 29ed17c:	mov    %edi,%r9d
 29ed17f:	lea    0x10(%rdx,%r9,1),%r8
 29ed184:	xor    %rsi,%rsi
 29ed187:	cmp    %rcx,%r9
 29ed18a:	cmova  %rsi,%r8
 29ed18e:	mov    (%r8),%r9d
 29ed191:	cmp    %r9d,%r12d
 29ed194:	jae    29fc1ad <wasm[0]::function[1015]::helper::object_read+0x1b22d>
 29ed19a:	mov    %r9d,%r8d
 29ed19d:	shl    $0x3,%r8
 29ed1a1:	shr    $0x20,%r8
 29ed1a5:	test   %r8,%r8
 29ed1a8:	jne    29fc1af <wasm[0]::function[1015]::helper::object_read+0x1b22f>
 29ed1ae:	shl    $0x3,%r9d
 29ed1b2:	add    $0x18,%r9d
 29ed1b6:	jb     29fc1b1 <wasm[0]::function[1015]::helper::object_read+0x1b231>
 29ed1bc:	add    %r9d,%edi
 29ed1bf:	jb     29fc1b3 <wasm[0]::function[1015]::helper::object_read+0x1b233>
 29ed1c5:	mov    %edi,%r8d
 29ed1c8:	lea    (%rdx,%r8,1),%rdi
 29ed1cc:	cmp    %rcx,%r8
 29ed1cf:	cmova  %rsi,%rdi
 29ed1d3:	mov    %r12,%rax
 29ed1d6:	shl    $0x3,%eax
 29ed1d9:	lea    0x18(%rax),%r8d
 29ed1dd:	sub    %r8d,%r9d
 29ed1e0:	sub    %r9,%rdi
 29ed1e3:	mov    (%rdi),%rdi
 29ed1e6:	mov    0x130(%rsp),%r9d
 29ed1ee:	test   %r9d,%r9d
 29ed1f1:	je     29fc1b5 <wasm[0]::function[1015]::helper::object_read+0x1b235>
 29ed1f7:	test   %r9d,%r9d
 29ed1fa:	je     29fc1b7 <wasm[0]::function[1015]::helper::object_read+0x1b237>
 29ed200:	mov    %r9d,%r11d
 29ed203:	lea    0x10(%rdx,%r11,1),%r10
 29ed208:	cmp    %rcx,%r11
 29ed20b:	cmova  %rsi,%r10
 29ed20f:	mov    (%r10),%r10d
 29ed212:	cmp    %r10d,%r12d
 29ed215:	jae    29fc1b9 <wasm[0]::function[1015]::helper::object_read+0x1b239>
 29ed21b:	mov    %r10d,%r11d
 29ed21e:	shl    $0x3,%r11
 29ed222:	shr    $0x20,%r11
 29ed226:	test   %r11,%r11
 29ed229:	jne    29fc1bb <wasm[0]::function[1015]::helper::object_read+0x1b23b>
 29ed22f:	shl    $0x3,%r10d
 29ed233:	add    $0x18,%r10d
 29ed237:	jb     29fc1bd <wasm[0]::function[1015]::helper::object_read+0x1b23d>
 29ed23d:	add    %r10d,%r9d
 29ed240:	jb     29fc1bf <wasm[0]::function[1015]::helper::object_read+0x1b23f>
 29ed246:	mov    %r9d,%r9d
 29ed249:	add    %r9,%rdx
 29ed24c:	cmp    %rcx,%r9
 29ed24f:	cmova  %rsi,%rdx
 29ed253:	sub    %r8d,%r10d
 29ed256:	sub    %r10,%rdx
 29ed259:	mov    (%rdx),%rcx
 29ed25c:	cmp    %rcx,%rdi
 29ed25f:	sete   %al
 29ed262:	movzbl %al,%edx
 29ed265:	mov    %rdx,%r14
 29ed268:	cmp    %rcx,%rdi
 29ed26b:	jne    29ed2b6 <wasm[0]::function[1015]::helper::object_read+0xc336>
 29ed271:	mov    0x90(%rsp),%ecx
 29ed278:	mov    0x128(%rsp),%edx
 29ed27f:	mov    0x98(%rsp),%esi
 29ed286:	mov    0x88(%rsp),%edi
 29ed28d:	mov    0x78(%rsp),%r8d
 29ed292:	mov    0x108(%rsp),%r9d
 29ed29a:	mov    0x120(%rsp),%r10d
 29ed2a2:	mov    0xf8(%rsp),%r11d
 29ed2aa:	add    $0x1,%r12d
 29ed2b1:	jmp    29ed0f6 <wasm[0]::function[1015]::helper::object_read+0xc176>
 29ed2b6:	mov    0x90(%rsp),%ecx
 29ed2bd:	mov    0x128(%rsp),%eax
 29ed2c4:	mov    0x98(%rsp),%esi
 29ed2cb:	mov    0x88(%rsp),%edi
 29ed2d2:	mov    0x78(%rsp),%r8d
 29ed2d7:	mov    0x108(%rsp),%r9d
 29ed2df:	mov    0x120(%rsp),%r10d
 29ed2e7:	mov    0xf8(%rsp),%edx
 29ed2ee:	jmp    29ed4db <wasm[0]::function[1015]::helper::object_read+0xc55b>
 29ed2f3:	mov    0x118(%rsp),%ecx
 29ed2fa:	cmp    %eax,%ecx
 29ed2fc:	je     29ed402 <wasm[0]::function[1015]::helper::object_read+0xc482>
 29ed302:	xor    %edx,%edx
 29ed304:	test   %ecx,%ecx
 29ed306:	je     29ed359 <wasm[0]::function[1015]::helper::object_read+0xc3d9>
 29ed30c:	xor    %edx,%edx
 29ed30e:	test   $0x1,%ecx
 29ed314:	jne    29ed359 <wasm[0]::function[1015]::helper::object_read+0xc3d9>
 29ed31a:	mov    0x2e0(%rsp),%r12
 29ed322:	mov    0x28(%r12),%rsi
 29ed327:	mov    0x20(%r12),%r8
 29ed32c:	mov    %ecx,%edi
 29ed32e:	lea    0x4(%r8,%rdi,1),%rdx
 29ed333:	xor    %r8,%r8
 29ed336:	cmp    %rsi,%rdi
 29ed339:	cmova  %r8,%rdx
 29ed33d:	mov    (%rdx),%esi
 29ed33f:	mov    0x190(%rsp),%rcx
 29ed347:	mov    0x28(%rcx),%rdi
 29ed34b:	cmp    0x234(%rdi),%esi
 29ed351:	sete   %dil
 29ed355:	movzbl %dil,%edx
 29ed359:	test   %edx,%edx
 29ed35b:	je     29fc1c1 <wasm[0]::function[1015]::helper::object_read+0x1b241>
 29ed361:	xor    %ecx,%ecx
 29ed363:	test   %eax,%eax
 29ed365:	jne    29ed373 <wasm[0]::function[1015]::helper::object_read+0xc3f3>
 29ed36b:	mov    %rax,%rdi
 29ed36e:	jmp    29ed3c8 <wasm[0]::function[1015]::helper::object_read+0xc448>
 29ed373:	xor    %ecx,%ecx
 29ed375:	test   $0x1,%eax
 29ed37a:	je     29ed388 <wasm[0]::function[1015]::helper::object_read+0xc408>
 29ed380:	mov    %rax,%rdi
 29ed383:	jmp    29ed3c8 <wasm[0]::function[1015]::helper::object_read+0xc448>
 29ed388:	mov    0x2e0(%rsp),%r12
 29ed390:	mov    0x28(%r12),%rcx
 29ed395:	mov    0x20(%r12),%rsi
 29ed39a:	mov    %eax,%edx
 29ed39c:	mov    %rax,%rdi
 29ed39f:	lea    0x4(%rsi,%rdx,1),%rax
 29ed3a4:	xor    %rsi,%rsi
 29ed3a7:	cmp    %rcx,%rdx
 29ed3aa:	cmova  %rsi,%rax
 29ed3ae:	mov    (%rax),%eax
 29ed3b0:	mov    0x190(%rsp),%rcx
 29ed3b8:	mov    0x28(%rcx),%rcx
 29ed3bc:	cmp    0x234(%rcx),%eax
 29ed3c2:	sete   %al
 29ed3c5:	movzbl %al,%ecx
 29ed3c8:	test   %ecx,%ecx
 29ed3ca:	je     29fc1c3 <wasm[0]::function[1015]::helper::object_read+0x1b243>
 29ed3d0:	mov    0x118(%rsp),%edx
 29ed3d7:	xor    %r8d,%r8d
 29ed3da:	test   %edx,%edx
 29ed3dc:	je     29fc1c5 <wasm[0]::function[1015]::helper::object_read+0x1b245>
 29ed3e2:	mov    %rdi,%rcx
 29ed3e5:	mov    0x190(%rsp),%rsi
 29ed3ed:	mov    0x190(%rsp),%rdi
 29ed3f5:	call   2ae5540 <wasm[0]::function[1057]::helper::string_equality>
 29ed3fa:	mov    %rax,%r14
 29ed3fd:	jmp    29ed40a <wasm[0]::function[1015]::helper::object_read+0xc48a>
 29ed402:	mov    0x278(%rsp),%r14
 29ed40a:	mov    0xa0(%rsp),%ecx
 29ed411:	mov    0xe0(%rsp),%eax
 29ed418:	mov    0x100(%rsp),%esi
 29ed41f:	mov    0xc8(%rsp),%edi
 29ed426:	mov    0xd8(%rsp),%r8d
 29ed42e:	mov    0x110(%rsp),%r9d
 29ed436:	mov    0x138(%rsp),%r10d
 29ed43e:	mov    0x118(%rsp),%edx
 29ed445:	jmp    29ed4db <wasm[0]::function[1015]::helper::object_read+0xc55b>
 29ed44a:	mov    0xa0(%rsp),%ecx
 29ed451:	mov    0xe0(%rsp),%eax
 29ed458:	mov    0x100(%rsp),%esi
 29ed45f:	mov    0xc8(%rsp),%edi
 29ed466:	mov    0xd8(%rsp),%r8d
 29ed46e:	mov    0x110(%rsp),%r9d
 29ed476:	mov    0x138(%rsp),%r10d
 29ed47e:	mov    0x118(%rsp),%edx
 29ed485:	xor    %r12,%r12
 29ed488:	mov    0x1c0(%rsp),%rbx
 29ed490:	mov    0x1c0(%rsp),%r11
 29ed498:	test   %rbx,%r11
 29ed49b:	sete   %r11b
 29ed49f:	mov    0x1c0(%rsp),%r13
 29ed4a7:	movq   %r13,%xmm0
 29ed4ac:	ucomisd %xmm0,%xmm0
 29ed4b0:	setp   %bl
 29ed4b3:	setne  %r13b
 29ed4b7:	or     %r13d,%ebx
 29ed4ba:	movq   %r12,%xmm0
 29ed4bf:	ucomisd %xmm0,%xmm0
 29ed4c3:	setp   %r12b
 29ed4c7:	setne  %r13b
 29ed4cb:	or     %r13d,%r12d
 29ed4ce:	and    %r12d,%ebx
 29ed4d1:	or     %ebx,%r11d
 29ed4d4:	movzbl %r11b,%r11d
 29ed4d8:	mov    %r11,%r14
 29ed4db:	mov    %esi,0x78(%rsp)
 29ed4df:	mov    %edi,0x88(%rsp)
 29ed4e6:	mov    %r8d,0x98(%rsp)
 29ed4ee:	mov    %r9d,0x128(%rsp)
 29ed4f6:	mov    %r10d,0x90(%rsp)
 29ed4fe:	mov    %edx,0xe0(%rsp)
 29ed505:	mov    %r14,%rdx
 29ed508:	mov    %r14,%rsi
 29ed50b:	test   %esi,%edx
 29ed50d:	je     29ed6dc <wasm[0]::function[1015]::helper::object_read+0xc75c>
 29ed513:	test   %ecx,%ecx
 29ed515:	je     29fc1c7 <wasm[0]::function[1015]::helper::object_read+0x1b247>
 29ed51b:	test   %ecx,%ecx
 29ed51d:	je     29fc1c9 <wasm[0]::function[1015]::helper::object_read+0x1b249>
 29ed523:	mov    0x2e0(%rsp),%r12
 29ed52b:	mov    0x28(%r12),%rdx
 29ed530:	mov    0x20(%r12),%rax
 29ed535:	mov    %ecx,%ecx
 29ed537:	add    %rcx,%rax
 29ed53a:	xor    %rsi,%rsi
 29ed53d:	cmp    %rdx,%rcx
 29ed540:	cmova  %rsi,%rax
 29ed544:	mov    0x18(%rax),%r12
 29ed548:	movl   $0x0,0x108(%rsp)
 29ed553:	mov    $0x20,%r13d
 29ed559:	mov    0x20(%rax),%ebx
 29ed55c:	mov    0x190(%rsp),%rcx
 29ed564:	mov    0x20(%rcx),%r14
 29ed568:	mov    (%r14),%eax
 29ed56b:	mov    %eax,%edx
 29ed56d:	lea    0x20(%rdx),%rcx
 29ed571:	mov    0x4(%r14),%esi
 29ed575:	cmp    %rsi,%rcx
 29ed578:	ja     29fad25 <wasm[0]::function[1015]::helper::object_read+0x19da5>
 29ed57e:	lea    0x20(%rax),%ecx
 29ed581:	mov    %ecx,(%r14)
 29ed584:	mov    0x2e0(%rsp),%rcx
 29ed58c:	mov    0x20(%rcx),%rsi
 29ed590:	lea    (%rsi,%rdx,1),%rcx
 29ed594:	movl   $0xb0000042,(%rsi,%rdx,1)
 29ed59b:	mov    0x190(%rsp),%r9
 29ed5a3:	mov    0x28(%r9),%rdi
 29ed5a7:	mov    0x120(%rdi),%edi
 29ed5ad:	mov    %edi,0x4(%rsi,%rdx,1)
 29ed5b1:	mov    %r13d,0x8(%rsi,%rdx,1)
 29ed5b6:	mov    %eax,0x120(%rsp)
 29ed5bd:	cmp    $0x0,%r12
 29ed5c1:	jl     29ed5d1 <wasm[0]::function[1015]::helper::object_read+0xc651>
 29ed5c7:	cvtsi2sd %r12,%xmm0
 29ed5cc:	jmp    29ed5eb <wasm[0]::function[1015]::helper::object_read+0xc66b>
 29ed5d1:	mov    %r12,%rsi
 29ed5d4:	shr    $0x1,%rsi
 29ed5d8:	mov    %r12,%rdx
 29ed5db:	and    $0x1,%rdx
 29ed5df:	or     %rsi,%rdx
 29ed5e2:	cvtsi2sd %rdx,%xmm0
 29ed5e7:	addsd  %xmm0,%xmm0
 29ed5eb:	movq   %xmm0,%rdx
 29ed5f0:	mov    %rdx,0x10(%rcx)
 29ed5f4:	movl   $0x3,0x18(%rcx)
 29ed5fb:	mov    0x108(%rsp),%edx
 29ed602:	mov    %edx,0x1c(%rcx)
 29ed605:	mov    0x190(%rsp),%rcx
 29ed60d:	mov    0xa20(%rcx),%ecx
 29ed613:	mov    %ecx,0x108(%rsp)
 29ed61a:	test   %eax,%eax
 29ed61c:	je     29fc1cb <wasm[0]::function[1015]::helper::object_read+0x1b24b>
 29ed622:	test   %ecx,%ecx
 29ed624:	je     29fc1cd <wasm[0]::function[1015]::helper::object_read+0x1b24d>
 29ed62a:	mov    (%r14),%eax
 29ed62d:	mov    %eax,%ecx
 29ed62f:	lea    0x20(%rcx),%rdx
 29ed633:	mov    0x4(%r14),%esi
 29ed637:	cmp    %rsi,%rdx
 29ed63a:	ja     29fad67 <wasm[0]::function[1015]::helper::object_read+0x19de7>
 29ed640:	lea    0x20(%rax),%edx
 29ed643:	mov    %edx,(%r14)
 29ed646:	mov    0x2e0(%rsp),%r12
 29ed64e:	mov    0x20(%r12),%rsi
 29ed653:	lea    (%rsi,%rcx,1),%r9
 29ed657:	movl   $0xb0000072,(%rsi,%rcx,1)
 29ed65e:	mov    0x190(%rsp),%rdx
 29ed666:	mov    0x28(%rdx),%rdi
 29ed66a:	mov    0x13c(%rdi),%edi
 29ed670:	mov    %edi,0x4(%rsi,%rcx,1)
 29ed674:	mov    %r13d,0x8(%rsi,%rcx,1)
 29ed679:	movl   $0x4,0x10(%r9)
 29ed681:	mov    0x120(%rsp),%r8d
 29ed689:	mov    %r8d,0x14(%r9)
 29ed68d:	mov    0x108(%rsp),%r10d
 29ed695:	mov    %r10d,0x18(%r9)
 29ed699:	mov    %r10d,0x1c(%r9)
 29ed69d:	test   %eax,%eax
 29ed69f:	je     29fc1cf <wasm[0]::function[1015]::helper::object_read+0x1b24f>
 29ed6a5:	test   %eax,%eax
 29ed6a7:	je     29fc1d1 <wasm[0]::function[1015]::helper::object_read+0x1b251>
 29ed6ad:	mov    0x2e0(%rsp),%r12
 29ed6b5:	mov    0x28(%r12),%rcx
 29ed6ba:	test   %ebx,%ebx
 29ed6bc:	setne  %dl
 29ed6bf:	movzbl %dl,%edx
 29ed6c2:	shl    $0x2,%edx
 29ed6c5:	mov    %eax,%edi
 29ed6c7:	mov    %rdi,%rsi
 29ed6ca:	add    0x20(%r12),%rsi
 29ed6cf:	xor    %r8,%r8
 29ed6d2:	cmp    %rcx,%rdi
 29ed6d5:	cmova  %r8,%rsi
 29ed6d9:	mov    %edx,0x10(%rsi)
 29ed6dc:	mov    0x78(%rsp),%ecx
 29ed6e0:	mov    %rcx,%r15
 29ed6e3:	mov    0x88(%rsp),%ecx
 29ed6ea:	mov    0x98(%rsp),%edx
 29ed6f1:	mov    0x128(%rsp),%edi
 29ed6f8:	mov    0x90(%rsp),%r8d
 29ed700:	mov    0xe0(%rsp),%esi
 29ed707:	jmp    29eeb83 <wasm[0]::function[1015]::helper::object_read+0xdc03>
 29ed70c:	test   %r10d,%r10d
 29ed70f:	je     29fc1d3 <wasm[0]::function[1015]::helper::object_read+0x1b253>
 29ed715:	test   %r10d,%r10d
 29ed718:	je     29fc1d5 <wasm[0]::function[1015]::helper::object_read+0x1b255>
 29ed71e:	mov    0x2e0(%rsp),%r12
 29ed726:	mov    0x28(%r12),%r9
 29ed72b:	mov    0x20(%r12),%r11
 29ed730:	mov    %r10d,%ebx
 29ed733:	lea    (%r11,%rbx,1),%rax
 29ed737:	xor    %r10,%r10
 29ed73a:	cmp    %r9,%rbx
 29ed73d:	cmova  %r10,%rax
 29ed741:	mov    0x14(%rax),%eax
 29ed744:	mov    %eax,0xa0(%rsp)
 29ed74b:	test   %eax,%eax
 29ed74d:	je     29fc1d7 <wasm[0]::function[1015]::helper::object_read+0x1b257>
 29ed753:	test   %eax,%eax
 29ed755:	je     29fc1d9 <wasm[0]::function[1015]::helper::object_read+0x1b259>
 29ed75b:	mov    %eax,%ebx
 29ed75d:	add    %rbx,%r11
 29ed760:	cmp    %r9,%rbx
 29ed763:	cmova  %r10,%r11
 29ed767:	mov    0x24(%r11),%r10d
 29ed76b:	cmp    $0x2,%r10d
 29ed76f:	sete   %r9b
 29ed773:	cmp    $0x3,%r10d
 29ed777:	sete   %r10b
 29ed77b:	or     %r10d,%r9d
 29ed77e:	test   %r9b,%r9b
 29ed781:	je     29ee7ed <wasm[0]::function[1015]::helper::object_read+0xd86d>
 29ed787:	mov    0xa0(%rsp),%eax
 29ed78e:	test   %eax,%eax
 29ed790:	je     29fc1db <wasm[0]::function[1015]::helper::object_read+0x1b25b>
 29ed796:	test   %eax,%eax
 29ed798:	je     29fc1dd <wasm[0]::function[1015]::helper::object_read+0x1b25d>
 29ed79e:	mov    0x2e0(%rsp),%r12
 29ed7a6:	mov    0x28(%r12),%rcx
 29ed7ab:	mov    %eax,%edx
 29ed7ad:	mov    %rdx,%rax
 29ed7b0:	add    0x20(%r12),%rax
 29ed7b5:	xor    %rsi,%rsi
 29ed7b8:	cmp    %rcx,%rdx
 29ed7bb:	cmova  %rsi,%rax
 29ed7bf:	mov    0x24(%rax),%eax
 29ed7c2:	cmp    $0x3,%eax
 29ed7c5:	je     29ed8f3 <wasm[0]::function[1015]::helper::object_read+0xc973>
 29ed7cb:	mov    0xa0(%rsp),%eax
 29ed7d2:	xor    %r9d,%r9d
 29ed7d5:	test   %eax,%eax
 29ed7d7:	je     29fc1df <wasm[0]::function[1015]::helper::object_read+0x1b25f>
 29ed7dd:	test   %eax,%eax
 29ed7df:	je     29fc1e1 <wasm[0]::function[1015]::helper::object_read+0x1b261>
 29ed7e5:	mov    0x2e0(%rsp),%r12
 29ed7ed:	mov    0x28(%r12),%rcx
 29ed7f2:	mov    0x20(%r12),%rdx
 29ed7f7:	mov    %eax,%edi
 29ed7f9:	lea    (%rdx,%rdi,1),%rax
 29ed7fd:	xor    %rsi,%rsi
 29ed800:	cmp    %rcx,%rdi
 29ed803:	cmova  %rsi,%rax
 29ed807:	mov    0x28(%rax),%edi
 29ed80a:	mov    0x2c(%rax),%eax
 29ed80d:	test   %edi,%edi
 29ed80f:	je     29fc1e3 <wasm[0]::function[1015]::helper::object_read+0x1b263>
 29ed815:	test   %edi,%edi
 29ed817:	je     29fc1e5 <wasm[0]::function[1015]::helper::object_read+0x1b265>
 29ed81d:	mov    %edi,%edi
 29ed81f:	lea    0x10(%rdx,%rdi,1),%rdx
 29ed824:	cmp    %rcx,%rdi
 29ed827:	cmova  %rsi,%rdx
 29ed82b:	mov    0x200(%rsp),%rcx
 29ed833:	mov    %ecx,%ecx
 29ed835:	mov    (%rdx),%edx
 29ed837:	cmp    %rdx,%rcx
 29ed83a:	jae    29ed9fa <wasm[0]::function[1015]::helper::object_read+0xca7a>
 29ed840:	xor    %r9d,%r9d
 29ed843:	test   %eax,%eax
 29ed845:	je     29fc1e7 <wasm[0]::function[1015]::helper::object_read+0x1b267>
 29ed84b:	test   %eax,%eax
 29ed84d:	je     29fc1e9 <wasm[0]::function[1015]::helper::object_read+0x1b269>
 29ed853:	mov    0x2e0(%rsp),%r12
 29ed85b:	mov    0x28(%r12),%rcx
 29ed860:	mov    0x20(%r12),%rdx
 29ed865:	mov    %eax,%r8d
 29ed868:	lea    0x10(%rdx,%r8,1),%rdi
 29ed86d:	xor    %rsi,%rsi
 29ed870:	cmp    %rcx,%r8
 29ed873:	cmova  %rsi,%rdi
 29ed877:	mov    (%rdi),%edi
 29ed879:	mov    0x200(%rsp),%r8
 29ed881:	shr    $0x6,%r8d
 29ed885:	cmp    %edi,%r8d
 29ed888:	jae    29fc1eb <wasm[0]::function[1015]::helper::object_read+0x1b26b>
 29ed88e:	mov    %edi,%r10d
 29ed891:	shl    $0x3,%r10
 29ed895:	shr    $0x20,%r10
 29ed899:	test   %r10,%r10
 29ed89c:	jne    29fc1ed <wasm[0]::function[1015]::helper::object_read+0x1b26d>
 29ed8a2:	shl    $0x3,%edi
 29ed8a5:	add    $0x18,%edi
 29ed8a8:	jb     29fc1ef <wasm[0]::function[1015]::helper::object_read+0x1b26f>
 29ed8ae:	add    %edi,%eax
 29ed8b0:	jb     29fc1f1 <wasm[0]::function[1015]::helper::object_read+0x1b271>
 29ed8b6:	mov    %eax,%r10d
 29ed8b9:	lea    (%rdx,%r10,1),%rax
 29ed8bd:	cmp    %rcx,%r10
 29ed8c0:	cmova  %rsi,%rax
 29ed8c4:	shl    $0x3,%r8d
 29ed8c8:	lea    0x18(%r8),%esi
 29ed8cc:	sub    %esi,%edi
 29ed8ce:	sub    %rdi,%rax
 29ed8d1:	mov    (%rax),%rsi
 29ed8d4:	mov    0x200(%rsp),%rax
 29ed8dc:	bt     %rax,%rsi
 29ed8e0:	jae    29ed9fa <wasm[0]::function[1015]::helper::object_read+0xca7a>
 29ed8e6:	mov    0x278(%rsp),%r9
 29ed8ee:	jmp    29ed9fa <wasm[0]::function[1015]::helper::object_read+0xca7a>
 29ed8f3:	mov    0xa0(%rsp),%r11d
 29ed8fb:	xor    %r9d,%r9d
 29ed8fe:	test   %r11d,%r11d
 29ed901:	je     29fc1f3 <wasm[0]::function[1015]::helper::object_read+0x1b273>
 29ed907:	test   %r11d,%r11d
 29ed90a:	je     29fc1f5 <wasm[0]::function[1015]::helper::object_read+0x1b275>
 29ed910:	mov    0x2e0(%rsp),%r12
 29ed918:	mov    0x28(%r12),%rcx
 29ed91d:	mov    0x20(%r12),%rdx
 29ed922:	mov    %r11d,%edi
 29ed925:	lea    (%rdx,%rdi,1),%rax
 29ed929:	xor    %rsi,%rsi
 29ed92c:	cmp    %rcx,%rdi
 29ed92f:	cmova  %rsi,%rax
 29ed933:	mov    0x30(%rax),%eax
 29ed936:	test   %eax,%eax
 29ed938:	je     29fc1f7 <wasm[0]::function[1015]::helper::object_read+0x1b277>
 29ed93e:	test   %eax,%eax
 29ed940:	je     29fc1f9 <wasm[0]::function[1015]::helper::object_read+0x1b279>
 29ed946:	mov    %eax,%r8d
 29ed949:	lea    0x10(%rdx,%r8,1),%rdx
 29ed94e:	cmp    %rcx,%r8
 29ed951:	cmova  %rsi,%rdx
 29ed955:	mov    0x200(%rsp),%rsi
 29ed95d:	mov    %esi,%ecx
 29ed95f:	mov    (%rdx),%edx
 29ed961:	cmp    %rdx,%rcx
 29ed964:	jae    29ed9fa <wasm[0]::function[1015]::helper::object_read+0xca7a>
 29ed96a:	mov    0x2e0(%rsp),%r12
 29ed972:	mov    0x28(%r12),%rcx
 29ed977:	mov    0x20(%r12),%rdi
 29ed97c:	lea    0x10(%rdi,%r8,1),%rsi
 29ed981:	xor    %rdx,%rdx
 29ed984:	cmp    %rcx,%r8
 29ed987:	cmova  %rdx,%rsi
 29ed98b:	mov    (%rsi),%esi
 29ed98d:	mov    0x200(%rsp),%r9
 29ed995:	cmp    %esi,%r9d
 29ed998:	jae    29fc1fb <wasm[0]::function[1015]::helper::object_read+0x1b27b>
 29ed99e:	mov    %esi,%r8d
 29ed9a1:	shl    $0x2,%r8
 29ed9a5:	shr    $0x20,%r8
 29ed9a9:	test   %r8,%r8
 29ed9ac:	jne    29fc1fd <wasm[0]::function[1015]::helper::object_read+0x1b27d>
 29ed9b2:	shl    $0x2,%esi
 29ed9b5:	add    $0x14,%esi
 29ed9b8:	jb     29fc1ff <wasm[0]::function[1015]::helper::object_read+0x1b27f>
 29ed9be:	add    %esi,%eax
 29ed9c0:	jb     29fc201 <wasm[0]::function[1015]::helper::object_read+0x1b281>
 29ed9c6:	mov    %eax,%r8d
 29ed9c9:	lea    (%rdi,%r8,1),%rax
 29ed9cd:	cmp    %rcx,%r8
 29ed9d0:	cmova  %rdx,%rax
 29ed9d4:	mov    %r9,%rcx
 29ed9d7:	shl    $0x2,%ecx
 29ed9da:	add    $0x14,%ecx
 29ed9e0:	sub    %ecx,%esi
 29ed9e2:	sub    %rsi,%rax
 29ed9e5:	mov    (%rax),%eax
 29ed9e7:	xor    %r9d,%r9d
 29ed9ea:	test   %eax,%eax
 29ed9ec:	je     29ed9fa <wasm[0]::function[1015]::helper::object_read+0xca7a>
 29ed9f2:	mov    0x278(%rsp),%r9
 29ed9fa:	mov    0xa0(%rsp),%eax
 29eda01:	mov    0x100(%rsp),%ecx
 29eda08:	mov    %rcx,%r15
 29eda0b:	mov    0xc8(%rsp),%ecx
 29eda12:	mov    0xd8(%rsp),%edx
 29eda19:	mov    0x110(%rsp),%edi
 29eda20:	mov    0x138(%rsp),%r8d
 29eda28:	mov    0x118(%rsp),%esi
 29eda2f:	test   %r9d,%r9d
 29eda32:	je     29ee7ed <wasm[0]::function[1015]::helper::object_read+0xd86d>
 29eda38:	mov    0xa0(%rsp),%eax
 29eda3f:	test   %eax,%eax
 29eda41:	je     29fc203 <wasm[0]::function[1015]::helper::object_read+0x1b283>
 29eda47:	test   %eax,%eax
 29eda49:	je     29fc205 <wasm[0]::function[1015]::helper::object_read+0x1b285>
 29eda4f:	mov    0x2e0(%rsp),%r12
 29eda57:	mov    0x28(%r12),%rcx
 29eda5c:	mov    %eax,%edx
 29eda5e:	mov    %rdx,%rax
 29eda61:	add    0x20(%r12),%rax
 29eda66:	xor    %rsi,%rsi
 29eda69:	cmp    %rcx,%rdx
 29eda6c:	cmova  %rsi,%rax
 29eda70:	mov    0x24(%rax),%eax
 29eda73:	cmp    $0x3,%eax
 29eda76:	je     29ee208 <wasm[0]::function[1015]::helper::object_read+0xd288>
 29eda7c:	mov    0xa0(%rsp),%eax
 29eda83:	test   %eax,%eax
 29eda85:	je     29fc207 <wasm[0]::function[1015]::helper::object_read+0x1b287>
 29eda8b:	test   %eax,%eax
 29eda8d:	je     29fc209 <wasm[0]::function[1015]::helper::object_read+0x1b289>
 29eda93:	mov    0x2e0(%rsp),%r12
 29eda9b:	mov    0x28(%r12),%rcx
 29edaa0:	mov    %eax,%esi
 29edaa2:	mov    %rsi,%rdx
 29edaa5:	add    0x20(%r12),%rdx
 29edaaa:	xor    %rdi,%rdi
 29edaad:	cmp    %rcx,%rsi
 29edab0:	cmova  %rdi,%rdx
 29edab4:	mov    0x24(%rdx),%r9d
 29edab8:	mov    0x100(%rsp),%ecx
 29edabf:	mov    %rcx,%r15
 29edac2:	mov    0xc8(%rsp),%ecx
 29edac9:	mov    0xd8(%rsp),%edx
 29edad0:	mov    0x110(%rsp),%edi
 29edad7:	mov    0x138(%rsp),%r8d
 29edadf:	mov    0x118(%rsp),%esi
 29edae6:	cmp    $0x2,%r9d
 29edaea:	jne    29ee7ed <wasm[0]::function[1015]::helper::object_read+0xd86d>
 29edaf0:	mov    0xa0(%rsp),%edx
 29edaf7:	test   %edx,%edx
 29edaf9:	je     29fc20b <wasm[0]::function[1015]::helper::object_read+0x1b28b>
 29edaff:	test   %edx,%edx
 29edb01:	je     29fc20d <wasm[0]::function[1015]::helper::object_read+0x1b28d>
 29edb07:	mov    0x2e0(%rsp),%r12
 29edb0f:	mov    0x28(%r12),%rax
 29edb14:	mov    0x20(%r12),%rcx
 29edb19:	mov    %edx,%esi
 29edb1b:	lea    (%rcx,%rsi,1),%rdi
 29edb1f:	xor    %rdx,%rdx
 29edb22:	cmp    %rax,%rsi
 29edb25:	cmova  %rdx,%rdi
 29edb29:	mov    0x28(%rdi),%esi
 29edb2c:	mov    %esi,0x78(%rsp)
 29edb30:	mov    0x2c(%rdi),%edi
 29edb33:	mov    %edi,0x88(%rsp)
 29edb3a:	test   %esi,%esi
 29edb3c:	je     29fc20f <wasm[0]::function[1015]::helper::object_read+0x1b28f>
 29edb42:	test   %esi,%esi
 29edb44:	je     29fc211 <wasm[0]::function[1015]::helper::object_read+0x1b291>
 29edb4a:	mov    %esi,%edi
 29edb4c:	lea    0x10(%rcx,%rdi,1),%rsi
 29edb51:	cmp    %rax,%rdi
 29edb54:	cmova  %rdx,%rsi
 29edb58:	mov    (%rsi),%esi
 29edb5a:	mov    %esi,%r14d
 29edb5d:	mov    %r14,%r13
 29edb60:	shl    $0x2,%r13
 29edb64:	mov    $0x20,%edi
 29edb69:	mov    %rdi,0x1f8(%rsp)
 29edb71:	mov    %r13,%rdi
 29edb74:	shr    $0x20,%rdi
 29edb78:	test   %rdi,%rdi
 29edb7b:	jne    29fc213 <wasm[0]::function[1015]::helper::object_read+0x1b293>
 29edb81:	mov    %rsi,%rcx
 29edb84:	shl    $0x2,%ecx
 29edb87:	mov    %rsi,0x208(%rsp)
 29edb8f:	add    $0x14,%ecx
 29edb92:	jb     29fc215 <wasm[0]::function[1015]::helper::object_read+0x1b295>
 29edb98:	mov    0x190(%rsp),%rax
 29edba0:	mov    0x20(%rax),%r15
 29edba4:	mov    (%r15),%eax
 29edba7:	mov    %eax,%r8d
 29edbaa:	mov    %ecx,%r9d
 29edbad:	lea    0xf(%r9),%rdx
 29edbb1:	mov    %rdx,%r9
 29edbb4:	and    $0xfffffffffffffff0,%r9
 29edbb8:	add    %r8,%r9
 29edbbb:	mov    0x4(%r15),%r10d
 29edbbf:	cmp    %r10,%r9
 29edbc2:	ja     29fadab <wasm[0]::function[1015]::helper::object_read+0x19e2b>
 29edbc8:	lea    0xf(%rcx),%r10d
 29edbcc:	and    $0xfffffff0,%r10d
 29edbd0:	lea    (%rax,%r10,1),%r11d
 29edbd4:	mov    %r11d,(%r15)
 29edbd7:	mov    0x2e0(%rsp),%r12
 29edbdf:	mov    0x20(%r12),%rsi
 29edbe4:	lea    (%rsi,%r8,1),%rcx
 29edbe8:	movl   $0xa800000e,(%rsi,%r8,1)
 29edbf0:	mov    0x190(%rsp),%rdi
 29edbf8:	mov    0x28(%rdi),%rdi
 29edbfc:	mov    0x194(%rdi),%edi
 29edc02:	mov    %edi,0x4(%rsi,%r8,1)
 29edc07:	and    $0xfffffffffffffff0,%rdx
 29edc0b:	mov    %edx,0x8(%rsi,%r8,1)
 29edc10:	mov    %eax,0x98(%rsp)
 29edc17:	mov    0x208(%rsp),%rdx
 29edc1f:	mov    %edx,0x10(%rcx)
 29edc22:	test   %eax,%eax
 29edc24:	je     29fc217 <wasm[0]::function[1015]::helper::object_read+0x1b297>
 29edc2a:	mov    0x2e0(%rsp),%r12
 29edc32:	mov    0x28(%r12),%rcx
 29edc37:	mov    0x20(%r12),%rdx
 29edc3c:	mov    %eax,%eax
 29edc3e:	lea    (%rdx,%rax,1),%r12
 29edc42:	lea    0x10(%rdx,%rax,1),%rsi
 29edc47:	xor    %rdi,%rdi
 29edc4a:	cmp    %rcx,%rax
 29edc4d:	cmova  %rdi,%rsi
 29edc51:	mov    (%rsi),%esi
 29edc53:	cmp    %rsi,%r14
 29edc56:	ja     29fc219 <wasm[0]::function[1015]::helper::object_read+0x1b299>
 29edc5c:	lea    0x14(%rdx,%rax,1),%rbx
 29edc61:	mov    %rbx,%rax
 29edc64:	add    %r13,%rax
 29edc67:	jb     29fc21b <wasm[0]::function[1015]::helper::object_read+0x1b29b>
 29edc6d:	add    %rdx,%rcx
 29edc70:	cmp    %rcx,%rax
 29edc73:	ja     29fc21d <wasm[0]::function[1015]::helper::object_read+0x1b29d>
 29edc79:	mov    0x88(%rsp),%r11d
 29edc81:	mov    0x78(%rsp),%eax
 29edc85:	mov    0xa0(%rsp),%ecx
 29edc8c:	mov    0x100(%rsp),%edx
 29edc93:	mov    0xc8(%rsp),%esi
 29edc9a:	mov    0xd8(%rsp),%edi
 29edca1:	mov    0x110(%rsp),%r8d
 29edca9:	mov    0x138(%rsp),%r9d
 29edcb1:	mov    0x118(%rsp),%r10d
 29edcb9:	lea    0x14(%r12,%r14,4),%r13
 29edcbe:	test   %r14,%r14
 29edcc1:	je     29edd79 <wasm[0]::function[1015]::helper::object_read+0xcdf9>
 29edcc7:	mov    %r11d,0xb0(%rsp)
 29edccf:	mov    %eax,0xf8(%rsp)
 29edcd6:	mov    %ecx,0x120(%rsp)
 29edcdd:	mov    %edx,0x108(%rsp)
 29edce4:	mov    %esi,0xe0(%rsp)
 29edceb:	mov    %edi,0x90(%rsp)
 29edcf2:	mov    %r8d,0x128(%rsp)
 29edcfa:	mov    %r9d,0x78(%rsp)
 29edcff:	mov    %r10d,0x88(%rsp)
 29edd07:	mov    0x2e8(%rsp),%rax
 29edd0f:	mov    (%rax),%rax
 29edd12:	mov    0x228(%rsp),%rcx
 29edd1a:	cmp    %rcx,%rax
 29edd1d:	jae    29fadea <wasm[0]::function[1015]::helper::object_read+0x19e6a>
 29edd23:	movl   $0x0,(%rbx)
 29edd29:	mov    0xb0(%rsp),%r11d
 29edd31:	mov    0xf8(%rsp),%eax
 29edd38:	mov    0x120(%rsp),%ecx
 29edd3f:	mov    0x108(%rsp),%edx
 29edd46:	mov    0xe0(%rsp),%esi
 29edd4d:	mov    0x90(%rsp),%edi
 29edd54:	mov    0x128(%rsp),%r8d
 29edd5c:	mov    0x78(%rsp),%r9d
 29edd61:	mov    0x88(%rsp),%r10d
 29edd69:	add    $0x4,%rbx
 29edd70:	cmp    %r13,%rbx
 29edd73:	jne    29edcc7 <wasm[0]::function[1015]::helper::object_read+0xcd47>
 29edd79:	mov    %r11d,0xf8(%rsp)
 29edd81:	mov    %eax,0xb0(%rsp)
 29edd88:	xor    %ebx,%ebx
 29edd8a:	mov    $0xb0000042,%r14d
 29edd90:	mov    0x190(%rsp),%rax
 29edd98:	mov    %r14,0x1f0(%rsp)
 29edda0:	mov    0x28(%rax),%rax
 29edda4:	mov    0x120(%rax),%r14d
 29eddab:	mov    %r14,0x1e8(%rsp)
 29eddb3:	mov    $0x20,%r14d
 29eddb9:	mov    %r14,0x1e0(%rsp)
 29eddc1:	mov    $0x10,%r13d
 29eddc7:	mov    %r13,0x1d8(%rsp)
 29eddcf:	mov    $0xb0000072,%r11d
 29eddd5:	mov    %r11,0x1d0(%rsp)
 29edddd:	mov    0x13c(%rax),%eax
 29edde3:	mov    %rax,%r14
 29edde6:	mov    %ecx,0x88(%rsp)
 29edded:	mov    %edx,0x78(%rsp)
 29eddf1:	mov    %esi,0x128(%rsp)
 29eddf8:	mov    %edi,0x90(%rsp)
 29eddff:	mov    %r8d,0xe0(%rsp)
 29ede07:	mov    %r9d,0x108(%rsp)
 29ede0f:	mov    %r10d,0x120(%rsp)
 29ede17:	mov    0x2e8(%rsp),%r13
 29ede1f:	mov    0x0(%r13),%rax
 29ede23:	mov    0x228(%rsp),%r8
 29ede2b:	cmp    %r8,%rax
 29ede2e:	jae    29fae22 <wasm[0]::function[1015]::helper::object_read+0x19ea2>
 29ede34:	mov    0x208(%rsp),%rcx
 29ede3c:	jmp    29ede49 <wasm[0]::function[1015]::helper::object_read+0xcec9>
 29ede41:	mov    0x208(%rsp),%rcx
 29ede49:	cmp    %ecx,%ebx
 29ede4b:	jae    29ee156 <wasm[0]::function[1015]::helper::object_read+0xd1d6>
 29ede51:	mov    0xf8(%rsp),%eax
 29ede58:	test   %eax,%eax
 29ede5a:	je     29fc21f <wasm[0]::function[1015]::helper::object_read+0x1b29f>
 29ede60:	test   %eax,%eax
 29ede62:	je     29fc221 <wasm[0]::function[1015]::helper::object_read+0x1b2a1>
 29ede68:	mov    0x2e0(%rsp),%r12
 29ede70:	mov    0x28(%r12),%r11
 29ede75:	mov    0x20(%r12),%rcx
 29ede7a:	mov    %eax,%esi
 29ede7c:	lea    0x10(%rcx,%rsi,1),%r8
 29ede81:	xor    %rdx,%rdx
 29ede84:	cmp    %r11,%rsi
 29ede87:	cmova  %rdx,%r8
 29ede8b:	mov    (%r8),%esi
 29ede8e:	mov    %rbx,%rdi
 29ede91:	shr    $0x6,%edi
 29ede94:	cmp    %esi,%edi
 29ede96:	jae    29fc223 <wasm[0]::function[1015]::helper::object_read+0x1b2a3>
 29ede9c:	mov    %esi,%r8d
 29ede9f:	shl    $0x3,%r8
 29edea3:	shr    $0x20,%r8
 29edea7:	test   %r8,%r8
 29edeaa:	jne    29fc225 <wasm[0]::function[1015]::helper::object_read+0x1b2a5>
 29edeb0:	shl    $0x3,%esi
 29edeb3:	add    $0x18,%esi
 29edeb6:	jb     29fc227 <wasm[0]::function[1015]::helper::object_read+0x1b2a7>
 29edebc:	add    %esi,%eax
 29edebe:	jb     29fc229 <wasm[0]::function[1015]::helper::object_read+0x1b2a9>
 29edec4:	mov    %eax,%r8d
 29edec7:	lea    (%rcx,%r8,1),%rax
 29edecb:	cmp    %r11,%r8
 29edece:	cmova  %rdx,%rax
 29eded2:	shl    $0x3,%edi
 29eded5:	lea    0x18(%rdi),%ecx
 29eded8:	sub    %ecx,%esi
 29ededa:	sub    %rsi,%rax
 29ededd:	mov    (%rax),%rax
 29edee0:	bt     %rbx,%rax
 29edee4:	jb     29edef7 <wasm[0]::function[1015]::helper::object_read+0xcf77>
 29edeea:	mov    0x1f8(%rsp),%r13
 29edef2:	jmp    29ee112 <wasm[0]::function[1015]::helper::object_read+0xd192>
 29edef7:	mov    0xb0(%rsp),%r8d
 29edeff:	test   %r8d,%r8d
 29edf02:	je     29fc22b <wasm[0]::function[1015]::helper::object_read+0x1b2ab>
 29edf08:	test   %r8d,%r8d
 29edf0b:	je     29fc22d <wasm[0]::function[1015]::helper::object_read+0x1b2ad>
 29edf11:	mov    0x2e0(%rsp),%r12
 29edf19:	mov    0x28(%r12),%rax
 29edf1e:	mov    0x20(%r12),%rcx
 29edf23:	mov    %r8d,%edi
 29edf26:	lea    0x10(%rcx,%rdi,1),%rsi
 29edf2b:	xor    %rdx,%rdx
 29edf2e:	cmp    %rax,%rdi
 29edf31:	cmova  %rdx,%rsi
 29edf35:	mov    (%rsi),%esi
 29edf37:	cmp    %esi,%ebx
 29edf39:	jae    29fc22f <wasm[0]::function[1015]::helper::object_read+0x1b2af>
 29edf3f:	mov    %esi,%edi
 29edf41:	shl    $0x3,%rdi
 29edf45:	shr    $0x20,%rdi
 29edf49:	test   %rdi,%rdi
 29edf4c:	jne    29fc231 <wasm[0]::function[1015]::helper::object_read+0x1b2b1>
 29edf52:	shl    $0x3,%esi
 29edf55:	add    $0x18,%esi
 29edf58:	jb     29fc233 <wasm[0]::function[1015]::helper::object_read+0x1b2b3>
 29edf5e:	add    %esi,%r8d
 29edf61:	jb     29fc235 <wasm[0]::function[1015]::helper::object_read+0x1b2b5>
 29edf67:	mov    %r8d,%edi
 29edf6a:	add    %rdi,%rcx
 29edf6d:	cmp    %rax,%rdi
 29edf70:	cmova  %rdx,%rcx
 29edf74:	mov    %rbx,%rax
 29edf77:	shl    $0x3,%eax
 29edf7a:	add    $0x18,%eax
 29edf80:	sub    %eax,%esi
 29edf82:	sub    %rsi,%rcx
 29edf85:	mov    (%rcx),%r12
 29edf88:	movl   $0x0,0x130(%rsp)
 29edf93:	mov    (%r15),%eax
 29edf96:	mov    %eax,%edx
 29edf98:	lea    0x20(%rdx),%rcx
 29edf9c:	mov    0x4(%r15),%esi
 29edfa0:	cmp    %rsi,%rcx
 29edfa3:	ja     29fae62 <wasm[0]::function[1015]::helper::object_read+0x19ee2>
 29edfa9:	lea    0x20(%rax),%ecx
 29edfac:	mov    %ecx,(%r15)
 29edfaf:	mov    0x2e0(%rsp),%rcx
 29edfb7:	mov    0x20(%rcx),%rsi
 29edfbb:	lea    (%rsi,%rdx,1),%rcx
 29edfbf:	movl   $0xb0000042,(%rsi,%rdx,1)
 29edfc6:	mov    0x1e8(%rsp),%rdi
 29edfce:	mov    %edi,0x4(%rsi,%rdx,1)
 29edfd2:	mov    0x1f8(%rsp),%r13
 29edfda:	mov    %r13d,0x8(%rsi,%rdx,1)
 29edfdf:	mov    %eax,0xd0(%rsp)
 29edfe6:	mov    %r12,0x10(%rcx)
 29edfea:	movl   $0x3,0x18(%rcx)
 29edff1:	mov    0x130(%rsp),%edx
 29edff8:	mov    %edx,0x1c(%rcx)
 29edffb:	mov    0x190(%rsp),%rcx
 29ee003:	mov    0xa20(%rcx),%ecx
 29ee009:	mov    %ecx,0x130(%rsp)
 29ee010:	test   %eax,%eax
 29ee012:	je     29fc237 <wasm[0]::function[1015]::helper::object_read+0x1b2b7>
 29ee018:	test   %ecx,%ecx
 29ee01a:	je     29fc239 <wasm[0]::function[1015]::helper::object_read+0x1b2b9>
 29ee020:	mov    (%r15),%eax
 29ee023:	mov    %eax,%edx
 29ee025:	lea    0x20(%rdx),%rcx
 29ee029:	mov    0x4(%r15),%esi
 29ee02d:	cmp    %rsi,%rcx
 29ee030:	ja     29faeaa <wasm[0]::function[1015]::helper::object_read+0x19f2a>
 29ee036:	lea    0x20(%rax),%ecx
 29ee039:	mov    %ecx,(%r15)
 29ee03c:	mov    0x2e0(%rsp),%r12
 29ee044:	mov    0x20(%r12),%rsi
 29ee049:	lea    (%rsi,%rdx,1),%rcx
 29ee04d:	movl   $0xb0000072,(%rsi,%rdx,1)
 29ee054:	mov    %r14d,0x4(%rsi,%rdx,1)
 29ee059:	mov    %r13d,0x8(%rsi,%rdx,1)
 29ee05e:	movl   $0xe,0x10(%rcx)
 29ee065:	mov    0xd0(%rsp),%edx
 29ee06c:	mov    %edx,0x14(%rcx)
 29ee06f:	mov    0x130(%rsp),%edx
 29ee076:	mov    %edx,0x18(%rcx)
 29ee079:	mov    %edx,0x1c(%rcx)
 29ee07c:	mov    0x98(%rsp),%ecx
 29ee083:	test   %ecx,%ecx
 29ee085:	je     29fc23b <wasm[0]::function[1015]::helper::object_read+0x1b2bb>
 29ee08b:	test   %eax,%eax
 29ee08d:	je     29fc23d <wasm[0]::function[1015]::helper::object_read+0x1b2bd>
 29ee093:	test   %ecx,%ecx
 29ee095:	je     29fc23f <wasm[0]::function[1015]::helper::object_read+0x1b2bf>
 29ee09b:	mov    0x2e0(%rsp),%r12
 29ee0a3:	mov    0x28(%r12),%rdi
 29ee0a8:	mov    0x20(%r12),%r8
 29ee0ad:	mov    %ecx,%r10d
 29ee0b0:	lea    0x10(%r8,%r10,1),%rsi
 29ee0b5:	xor    %r9,%r9
 29ee0b8:	cmp    %rdi,%r10
 29ee0bb:	cmova  %r9,%rsi
 29ee0bf:	mov    (%rsi),%edx
 29ee0c1:	cmp    %edx,%ebx
 29ee0c3:	jae    29fc241 <wasm[0]::function[1015]::helper::object_read+0x1b2c1>
 29ee0c9:	mov    %edx,%r10d
 29ee0cc:	shl    $0x2,%r10
 29ee0d0:	shr    $0x20,%r10
 29ee0d4:	test   %r10,%r10
 29ee0d7:	jne    29fc243 <wasm[0]::function[1015]::helper::object_read+0x1b2c3>
 29ee0dd:	shl    $0x2,%edx
 29ee0e0:	add    $0x14,%edx
 29ee0e3:	jb     29fc245 <wasm[0]::function[1015]::helper::object_read+0x1b2c5>
 29ee0e9:	add    %edx,%ecx
 29ee0eb:	jb     29fc247 <wasm[0]::function[1015]::helper::object_read+0x1b2c7>
 29ee0f1:	mov    %ecx,%ecx
 29ee0f3:	lea    (%r8,%rcx,1),%r10
 29ee0f7:	cmp    %rdi,%rcx
 29ee0fa:	cmova  %r9,%r10
 29ee0fe:	mov    %rbx,%rcx
 29ee101:	shl    $0x2,%ecx
 29ee104:	add    $0x14,%ecx
 29ee10a:	sub    %ecx,%edx
 29ee10c:	sub    %rdx,%r10
 29ee10f:	mov    %eax,(%r10)
 29ee112:	mov    0x88(%rsp),%ecx
 29ee119:	mov    0x78(%rsp),%edx
 29ee11d:	mov    0x128(%rsp),%esi
 29ee124:	mov    0x90(%rsp),%edi
 29ee12b:	mov    0xe0(%rsp),%r8d
 29ee133:	mov    0x108(%rsp),%r9d
 29ee13b:	mov    0x120(%rsp),%r10d
 29ee143:	add    $0x1,%ebx
 29ee149:	mov    %r13,0x1f8(%rsp)
 29ee151:	jmp    29edde6 <wasm[0]::function[1015]::helper::object_read+0xce66>
 29ee156:	mov    0x88(%rsp),%eax
 29ee15d:	test   %eax,%eax
 29ee15f:	je     29fc249 <wasm[0]::function[1015]::helper::object_read+0x1b2c9>
 29ee165:	mov    0x98(%rsp),%edx
 29ee16c:	test   %edx,%edx
 29ee16e:	je     29fc24b <wasm[0]::function[1015]::helper::object_read+0x1b2cb>
 29ee174:	test   %eax,%eax
 29ee176:	je     29fc24d <wasm[0]::function[1015]::helper::object_read+0x1b2cd>
 29ee17c:	mov    0x2e0(%rsp),%r12
 29ee184:	mov    0x28(%r12),%rsi
 29ee189:	mov    0x20(%r12),%rcx
 29ee18e:	mov    %eax,%edi
 29ee190:	add    %rdi,%rcx
 29ee193:	xor    %r8,%r8
 29ee196:	cmp    %rsi,%rdi
 29ee199:	cmova  %r8,%rcx
 29ee19d:	mov    %edx,0x20(%rcx)
 29ee1a0:	mov    0x190(%rsp),%rdx
 29ee1a8:	mov    0xa00(%rdx),%esi
 29ee1ae:	mov    0xa10(%rdx),%edx
 29ee1b4:	test   %esi,%esi
 29ee1b6:	je     29fc24f <wasm[0]::function[1015]::helper::object_read+0x1b2cf>
 29ee1bc:	mov    %esi,0x28(%rcx)
 29ee1bf:	test   %edx,%edx
 29ee1c1:	je     29fc251 <wasm[0]::function[1015]::helper::object_read+0x1b2d1>
 29ee1c7:	mov    %edx,0x2c(%rcx)
 29ee1ca:	movl   $0x0,0x30(%rcx)
 29ee1d1:	movl   $0x0,0x24(%rcx)
 29ee1d8:	mov    0x78(%rsp),%ecx
 29ee1dc:	mov    %rcx,%r15
 29ee1df:	mov    0x128(%rsp),%ecx
 29ee1e6:	mov    0x90(%rsp),%edx
 29ee1ed:	mov    0xe0(%rsp),%edi
 29ee1f4:	mov    0x108(%rsp),%r8d
 29ee1fc:	mov    0x120(%rsp),%esi
 29ee203:	jmp    29ee7ed <wasm[0]::function[1015]::helper::object_read+0xd86d>
 29ee208:	mov    0xa0(%rsp),%edx
 29ee20f:	test   %edx,%edx
 29ee211:	je     29fc253 <wasm[0]::function[1015]::helper::object_read+0x1b2d3>
 29ee217:	test   %edx,%edx
 29ee219:	je     29fc255 <wasm[0]::function[1015]::helper::object_read+0x1b2d5>
 29ee21f:	mov    0x2e0(%rsp),%r12
 29ee227:	mov    0x28(%r12),%rax
 29ee22c:	mov    0x20(%r12),%rcx
 29ee231:	mov    %edx,%edi
 29ee233:	lea    (%rcx,%rdi,1),%rsi
 29ee237:	xor    %rdx,%rdx
 29ee23a:	cmp    %rax,%rdi
 29ee23d:	cmova  %rdx,%rsi
 29ee241:	mov    0x30(%rsi),%esi
 29ee244:	mov    %esi,0x88(%rsp)
 29ee24b:	test   %esi,%esi
 29ee24d:	je     29fc257 <wasm[0]::function[1015]::helper::object_read+0x1b2d7>
 29ee253:	test   %esi,%esi
 29ee255:	je     29fc259 <wasm[0]::function[1015]::helper::object_read+0x1b2d9>
 29ee25b:	mov    %esi,%esi
 29ee25d:	lea    0x10(%rcx,%rsi,1),%rcx
 29ee262:	cmp    %rax,%rsi
 29ee265:	cmova  %rdx,%rcx
 29ee269:	mov    (%rcx),%eax
 29ee26b:	mov    %eax,%ebx
 29ee26d:	mov    %rbx,%r15
 29ee270:	shl    $0x2,%r15
 29ee274:	mov    $0x20,%ecx
 29ee279:	mov    %rcx,0x1c8(%rsp)
 29ee281:	mov    %r15,%rcx
 29ee284:	shr    $0x20,%rcx
 29ee288:	test   %rcx,%rcx
 29ee28b:	jne    29fc25b <wasm[0]::function[1015]::helper::object_read+0x1b2db>
 29ee291:	mov    %rax,%rcx
 29ee294:	shl    $0x2,%ecx
 29ee297:	mov    %rax,0x1d0(%rsp)
 29ee29f:	add    $0x14,%ecx
 29ee2a2:	jb     29fc25d <wasm[0]::function[1015]::helper::object_read+0x1b2dd>
 29ee2a8:	mov    0x190(%rsp),%rax
 29ee2b0:	mov    0x20(%rax),%r14
 29ee2b4:	mov    (%r14),%eax
 29ee2b7:	mov    %eax,%edx
 29ee2b9:	mov    %ecx,%esi
 29ee2bb:	add    $0xf,%rsi
 29ee2c2:	mov    %rsi,%rdi
 29ee2c5:	and    $0xfffffffffffffff0,%rdi
 29ee2c9:	add    %rdx,%rdi
 29ee2cc:	mov    0x4(%r14),%r8d
 29ee2d0:	cmp    %r8,%rdi
 29ee2d3:	ja     29faee6 <wasm[0]::function[1015]::helper::object_read+0x19f66>
 29ee2d9:	add    $0xf,%ecx
 29ee2df:	and    $0xfffffff0,%ecx
 29ee2e2:	add    %eax,%ecx
 29ee2e4:	mov    %ecx,(%r14)
 29ee2e7:	mov    0x2e0(%rsp),%r12
 29ee2ef:	mov    0x20(%r12),%rcx
 29ee2f4:	lea    (%rcx,%rdx,1),%r8
 29ee2f8:	movl   $0xa800000e,(%rcx,%rdx,1)
 29ee2ff:	mov    0x190(%rsp),%rdi
 29ee307:	mov    0x28(%rdi),%rdi
 29ee30b:	mov    0x194(%rdi),%edi
 29ee311:	mov    %edi,0x4(%rcx,%rdx,1)
 29ee315:	and    $0xfffffffffffffff0,%rsi
 29ee319:	mov    %esi,0x8(%rcx,%rdx,1)
 29ee31d:	mov    %eax,0x78(%rsp)
 29ee321:	mov    0x1d0(%rsp),%rcx
 29ee329:	mov    %ecx,0x10(%r8)
 29ee32d:	test   %eax,%eax
 29ee32f:	je     29fc25f <wasm[0]::function[1015]::helper::object_read+0x1b2df>
 29ee335:	mov    0x2e0(%rsp),%r12
 29ee33d:	mov    0x28(%r12),%rcx
 29ee342:	mov    0x20(%r12),%rdx
 29ee347:	mov    %eax,%eax
 29ee349:	lea    (%rdx,%rax,1),%r11
 29ee34d:	lea    0x10(%rdx,%rax,1),%rsi
 29ee352:	xor    %rdi,%rdi
 29ee355:	cmp    %rcx,%rax
 29ee358:	cmova  %rdi,%rsi
 29ee35c:	mov    (%rsi),%esi
 29ee35e:	cmp    %rsi,%rbx
 29ee361:	ja     29fc261 <wasm[0]::function[1015]::helper::object_read+0x1b2e1>
 29ee367:	lea    0x14(%rdx,%rax,1),%r13
 29ee36c:	mov    %r13,%rsi
 29ee36f:	add    %r15,%rsi
 29ee372:	jb     29fc263 <wasm[0]::function[1015]::helper::object_read+0x1b2e3>
 29ee378:	lea    (%rdx,%rcx,1),%rdi
 29ee37c:	cmp    %rdi,%rsi
 29ee37f:	ja     29fc265 <wasm[0]::function[1015]::helper::object_read+0x1b2e5>
 29ee385:	mov    0x88(%rsp),%ecx
 29ee38c:	mov    0xa0(%rsp),%eax
 29ee393:	mov    0x100(%rsp),%edx
 29ee39a:	mov    0xc8(%rsp),%esi
 29ee3a1:	mov    0xd8(%rsp),%edi
 29ee3a8:	mov    0x110(%rsp),%r8d
 29ee3b0:	mov    0x138(%rsp),%r9d
 29ee3b8:	mov    0x118(%rsp),%r10d
 29ee3c0:	lea    0x14(%r11,%rbx,4),%r15
 29ee3c5:	test   %rbx,%rbx
 29ee3c8:	je     29ee478 <wasm[0]::function[1015]::helper::object_read+0xd4f8>
 29ee3ce:	mov    %ecx,0x118(%rsp)
 29ee3d5:	mov    %eax,0x138(%rsp)
 29ee3dc:	mov    %edx,0x110(%rsp)
 29ee3e3:	mov    %esi,0xd8(%rsp)
 29ee3ea:	mov    %edi,0xc8(%rsp)
 29ee3f1:	mov    %r8d,0x100(%rsp)
 29ee3f9:	mov    %r9d,0xa0(%rsp)
 29ee401:	mov    %r10d,0x88(%rsp)
 29ee409:	mov    0x2e8(%rsp),%rax
 29ee411:	mov    (%rax),%rax
 29ee414:	mov    0x228(%rsp),%rcx
 29ee41c:	cmp    %rcx,%rax
 29ee41f:	jae    29faf25 <wasm[0]::function[1015]::helper::object_read+0x19fa5>
 29ee425:	movl   $0x0,0x0(%r13)
 29ee42d:	mov    0x118(%rsp),%ecx
 29ee434:	mov    0x138(%rsp),%eax
 29ee43b:	mov    0x110(%rsp),%edx
 29ee442:	mov    0xd8(%rsp),%esi
 29ee449:	mov    0xc8(%rsp),%edi
 29ee450:	mov    0x100(%rsp),%r8d
 29ee458:	mov    0xa0(%rsp),%r9d
 29ee460:	mov    0x88(%rsp),%r10d
 29ee468:	add    $0x4,%r13
 29ee46f:	cmp    %r15,%r13
 29ee472:	jne    29ee3ce <wasm[0]::function[1015]::helper::object_read+0xd44e>
 29ee478:	mov    %ecx,0x118(%rsp)
 29ee47f:	mov    0x190(%rsp),%rcx
 29ee487:	mov    0xa20(%rcx),%ecx
 29ee48d:	mov    %ecx,0x138(%rsp)
 29ee494:	xor    %r13d,%r13d
 29ee497:	mov    $0xb0000072,%r15d
 29ee49d:	mov    0x190(%rsp),%rcx
 29ee4a5:	mov    %r15,0x1a0(%rsp)
 29ee4ad:	mov    0x28(%rcx),%rcx
 29ee4b1:	mov    0x13c(%rcx),%ebx
 29ee4b7:	mov    $0x20,%r15d
 29ee4bd:	mov    %r15,0x198(%rsp)
 29ee4c5:	mov    $0x10,%ecx
 29ee4ca:	mov    %rcx,0x2b0(%rsp)
 29ee4d2:	mov    %eax,0x128(%rsp)
 29ee4d9:	mov    %edx,0x88(%rsp)
 29ee4e0:	mov    %esi,0xa0(%rsp)
 29ee4e7:	mov    %edi,0x100(%rsp)
 29ee4ee:	mov    %r8d,0xc8(%rsp)
 29ee4f6:	mov    %r9d,0xd8(%rsp)
 29ee4fe:	mov    %r10d,0x110(%rsp)
 29ee506:	mov    0x2e8(%rsp),%rcx
 29ee50e:	mov    (%rcx),%rax
 29ee511:	mov    0x228(%rsp),%r9
 29ee519:	cmp    %r9,%rax
 29ee51c:	jae    29faf5d <wasm[0]::function[1015]::helper::object_read+0x19fdd>
 29ee522:	mov    0x1d0(%rsp),%rdi
 29ee52a:	jmp    29ee537 <wasm[0]::function[1015]::helper::object_read+0xd5b7>
 29ee52f:	mov    0x1d0(%rsp),%rdi
 29ee537:	cmp    %edi,%r13d
 29ee53a:	jae    29ee740 <wasm[0]::function[1015]::helper::object_read+0xd7c0>
 29ee540:	mov    0x118(%rsp),%eax
 29ee547:	test   %eax,%eax
 29ee549:	je     29fc267 <wasm[0]::function[1015]::helper::object_read+0x1b2e7>
 29ee54f:	test   %eax,%eax
 29ee551:	je     29fc269 <wasm[0]::function[1015]::helper::object_read+0x1b2e9>
 29ee557:	mov    0x2e0(%rsp),%r12
 29ee55f:	mov    0x28(%r12),%rcx
 29ee564:	mov    0x20(%r12),%rdx
 29ee569:	mov    %eax,%r8d
 29ee56c:	lea    0x10(%rdx,%r8,1),%rdi
 29ee571:	xor    %rsi,%rsi
 29ee574:	cmp    %rcx,%r8
 29ee577:	cmova  %rsi,%rdi
 29ee57b:	mov    (%rdi),%edi
 29ee57d:	cmp    %edi,%r13d
 29ee580:	jae    29fc26b <wasm[0]::function[1015]::helper::object_read+0x1b2eb>
 29ee586:	mov    %edi,%r8d
 29ee589:	shl    $0x2,%r8
 29ee58d:	shr    $0x20,%r8
 29ee591:	test   %r8,%r8
 29ee594:	jne    29fc26d <wasm[0]::function[1015]::helper::object_read+0x1b2ed>
 29ee59a:	shl    $0x2,%edi
 29ee59d:	add    $0x14,%edi
 29ee5a0:	jb     29fc26f <wasm[0]::function[1015]::helper::object_read+0x1b2ef>
 29ee5a6:	add    %edi,%eax
 29ee5a8:	jb     29fc271 <wasm[0]::function[1015]::helper::object_read+0x1b2f1>
 29ee5ae:	mov    %eax,%r8d
 29ee5b1:	lea    (%rdx,%r8,1),%rax
 29ee5b5:	cmp    %rcx,%r8
 29ee5b8:	cmova  %rsi,%rax
 29ee5bc:	mov    %r13,%r15
 29ee5bf:	shl    $0x2,%r15d
 29ee5c3:	lea    0x14(%r15),%ecx
 29ee5c7:	sub    %ecx,%edi
 29ee5c9:	sub    %rdi,%rax
 29ee5cc:	mov    (%rax),%eax
 29ee5ce:	mov    %eax,0x90(%rsp)
 29ee5d5:	test   %eax,%eax
 29ee5d7:	jne    29ee5ea <wasm[0]::function[1015]::helper::object_read+0xd66a>
 29ee5dd:	mov    0x1c8(%rsp),%rcx
 29ee5e5:	jmp    29ee6f8 <wasm[0]::function[1015]::helper::object_read+0xd778>
 29ee5ea:	test   %eax,%eax
 29ee5ec:	je     29fc273 <wasm[0]::function[1015]::helper::object_read+0x1b2f3>
 29ee5f2:	mov    0x138(%rsp),%esi
 29ee5f9:	test   %esi,%esi
 29ee5fb:	je     29fc275 <wasm[0]::function[1015]::helper::object_read+0x1b2f5>
 29ee601:	mov    (%r14),%eax
 29ee604:	mov    %eax,%esi
 29ee606:	lea    0x20(%rsi),%rdi
 29ee60a:	mov    0x4(%r14),%r8d
 29ee60e:	cmp    %r8,%rdi
 29ee611:	ja     29faf9d <wasm[0]::function[1015]::helper::object_read+0x1a01d>
 29ee617:	lea    0x20(%rax),%r8d
 29ee61b:	mov    %r8d,(%r14)
 29ee61e:	mov    0x2e0(%rsp),%r12
 29ee626:	mov    0x20(%r12),%r9
 29ee62b:	lea    (%r9,%rsi,1),%rdx
 29ee62f:	movl   $0xb0000072,(%r9,%rsi,1)
 29ee637:	mov    %ebx,0x4(%r9,%rsi,1)
 29ee63c:	mov    0x1c8(%rsp),%rcx
 29ee644:	mov    %ecx,0x8(%r9,%rsi,1)
 29ee649:	movl   $0xe,0x10(%rdx)
 29ee650:	mov    0x90(%rsp),%esi
 29ee657:	mov    %esi,0x14(%rdx)
 29ee65a:	mov    0x138(%rsp),%esi
 29ee661:	mov    %esi,0x18(%rdx)
 29ee664:	mov    %esi,0x1c(%rdx)
 29ee667:	mov    0x78(%rsp),%esi
 29ee66b:	test   %esi,%esi
 29ee66d:	je     29fc277 <wasm[0]::function[1015]::helper::object_read+0x1b2f7>
 29ee673:	test   %eax,%eax
 29ee675:	je     29fc279 <wasm[0]::function[1015]::helper::object_read+0x1b2f9>
 29ee67b:	test   %esi,%esi
 29ee67d:	je     29fc27b <wasm[0]::function[1015]::helper::object_read+0x1b2fb>
 29ee683:	mov    0x2e0(%rsp),%r12
 29ee68b:	mov    0x28(%r12),%rdx
 29ee690:	mov    0x20(%r12),%rdi
 29ee695:	mov    %esi,%r10d
 29ee698:	lea    0x10(%rdi,%r10,1),%r9
 29ee69d:	xor    %r8,%r8
 29ee6a0:	cmp    %rdx,%r10
 29ee6a3:	cmova  %r8,%r9
 29ee6a7:	mov    (%r9),%r9d
 29ee6aa:	cmp    %r9d,%r13d
 29ee6ad:	jae    29fc27d <wasm[0]::function[1015]::helper::object_read+0x1b2fd>
 29ee6b3:	mov    %r9d,%r10d
 29ee6b6:	shl    $0x2,%r10
 29ee6ba:	shr    $0x20,%r10
 29ee6be:	test   %r10,%r10
 29ee6c1:	jne    29fc27f <wasm[0]::function[1015]::helper::object_read+0x1b2ff>
 29ee6c7:	shl    $0x2,%r9d
 29ee6cb:	add    $0x14,%r9d
 29ee6cf:	jb     29fc281 <wasm[0]::function[1015]::helper::object_read+0x1b301>
 29ee6d5:	add    %r9d,%esi
 29ee6d8:	jb     29fc283 <wasm[0]::function[1015]::helper::object_read+0x1b303>
 29ee6de:	mov    %esi,%r10d
 29ee6e1:	lea    (%rdi,%r10,1),%rsi
 29ee6e5:	cmp    %rdx,%r10
 29ee6e8:	cmova  %r8,%rsi
 29ee6ec:	lea    0x14(%r15),%edx
 29ee6f0:	sub    %edx,%r9d
 29ee6f3:	sub    %r9,%rsi
 29ee6f6:	mov    %eax,(%rsi)
 29ee6f8:	mov    0x128(%rsp),%eax
 29ee6ff:	mov    0x88(%rsp),%edx
 29ee706:	mov    0xa0(%rsp),%esi
 29ee70d:	mov    0x100(%rsp),%edi
 29ee714:	mov    0xc8(%rsp),%r8d
 29ee71c:	mov    0xd8(%rsp),%r9d
 29ee724:	mov    0x110(%rsp),%r10d
 29ee72c:	add    $0x1,%r13d
 29ee733:	mov    %rcx,0x1c8(%rsp)
 29ee73b:	jmp    29ee4d2 <wasm[0]::function[1015]::helper::object_read+0xd552>
 29ee740:	mov    0x128(%rsp),%eax
 29ee747:	test   %eax,%eax
 29ee749:	je     29fc285 <wasm[0]::function[1015]::helper::object_read+0x1b305>
 29ee74f:	mov    0x78(%rsp),%edx
 29ee753:	test   %edx,%edx
 29ee755:	je     29fc287 <wasm[0]::function[1015]::helper::object_read+0x1b307>
 29ee75b:	test   %eax,%eax
 29ee75d:	je     29fc289 <wasm[0]::function[1015]::helper::object_read+0x1b309>
 29ee763:	mov    0x2e0(%rsp),%r12
 29ee76b:	mov    0x28(%r12),%rsi
 29ee770:	mov    0x20(%r12),%rcx
 29ee775:	mov    %eax,%edi
 29ee777:	add    %rdi,%rcx
 29ee77a:	xor    %r8,%r8
 29ee77d:	cmp    %rsi,%rdi
 29ee780:	cmova  %r8,%rcx
 29ee784:	mov    %edx,0x20(%rcx)
 29ee787:	mov    0x190(%rsp),%rdx
 29ee78f:	mov    0xa00(%rdx),%esi
 29ee795:	mov    0xa10(%rdx),%edx
 29ee79b:	test   %esi,%esi
 29ee79d:	je     29fc28b <wasm[0]::function[1015]::helper::object_read+0x1b30b>
 29ee7a3:	mov    %esi,0x28(%rcx)
 29ee7a6:	test   %edx,%edx
 29ee7a8:	je     29fc28d <wasm[0]::function[1015]::helper::object_read+0x1b30d>
 29ee7ae:	mov    %edx,0x2c(%rcx)
 29ee7b1:	movl   $0x0,0x30(%rcx)
 29ee7b8:	movl   $0x0,0x24(%rcx)
 29ee7bf:	mov    0x88(%rsp),%ecx
 29ee7c6:	mov    %rcx,%r15
 29ee7c9:	mov    0xa0(%rsp),%ecx
 29ee7d0:	mov    0x100(%rsp),%edx
 29ee7d7:	mov    0xc8(%rsp),%edi
 29ee7de:	mov    0xd8(%rsp),%r8d
 29ee7e6:	mov    0x110(%rsp),%esi
 29ee7ed:	test   %eax,%eax
 29ee7ef:	je     29fc28f <wasm[0]::function[1015]::helper::object_read+0x1b30f>
 29ee7f5:	test   %eax,%eax
 29ee7f7:	je     29fc291 <wasm[0]::function[1015]::helper::object_read+0x1b311>
 29ee7fd:	mov    0x2e0(%rsp),%r12
 29ee805:	mov    0x28(%r12),%r10
 29ee80a:	mov    0x20(%r12),%rbx
 29ee80f:	mov    %eax,%eax
 29ee811:	lea    (%rbx,%rax,1),%r11
 29ee815:	xor    %r12,%r12
 29ee818:	cmp    %r10,%rax
 29ee81b:	cmova  %r12,%r11
 29ee81f:	mov    0x10(%r11),%r9d
 29ee823:	test   %r9d,%r9d
 29ee826:	je     29fc293 <wasm[0]::function[1015]::helper::object_read+0x1b313>
 29ee82c:	test   %r9d,%r9d
 29ee82f:	je     29fc295 <wasm[0]::function[1015]::helper::object_read+0x1b315>
 29ee835:	mov    %r9d,%r13d
 29ee838:	lea    0x10(%rbx,%r13,1),%rbx
 29ee83d:	cmp    %r10,%r13
 29ee840:	cmova  %r12,%rbx
 29ee844:	mov    (%rbx),%ebx
 29ee846:	mov    0x24(%r11),%r10d
 29ee84a:	test   %r10d,%r10d
 29ee84d:	je     29eea91 <wasm[0]::function[1015]::helper::object_read+0xdb11>
 29ee853:	xor    %eax,%eax
 29ee855:	test   %ebx,%ebx
 29ee857:	je     29eeb83 <wasm[0]::function[1015]::helper::object_read+0xdc03>
 29ee85d:	mov    0x2e0(%rsp),%r12
 29ee865:	mov    0x28(%r12),%r10
 29ee86a:	mov    0x20(%r12),%r12
 29ee86f:	lea    0x10(%r12,%r13,1),%rax
 29ee874:	xor    %r11,%r11
 29ee877:	cmp    %r10,%r13
 29ee87a:	cmova  %r11,%rax
 29ee87e:	mov    (%rax),%eax
 29ee880:	mov    0x200(%rsp),%r13
 29ee888:	shr    $0x10,%r13d
 29ee88c:	mov    0x200(%rsp),%r14
 29ee894:	xor    %r13d,%r14d
 29ee897:	imul   $0x7feb352d,%r14d,%r13d
 29ee89e:	mov    %r13,%r14
 29ee8a1:	shr    $0xf,%r14d
 29ee8a5:	xor    %r14d,%r13d
 29ee8a8:	imul   $0x846ca68b,%r13d,%r13d
 29ee8af:	mov    %r13,%r14
 29ee8b2:	shr    $0x10,%r14d
 29ee8b6:	xor    %r14d,%r13d
 29ee8b9:	sub    $0x1,%ebx
 29ee8bc:	and    %ebx,%r13d
 29ee8bf:	cmp    %eax,%r13d
 29ee8c2:	jae    29fc297 <wasm[0]::function[1015]::helper::object_read+0x1b317>
 29ee8c8:	mov    %eax,%r14d
 29ee8cb:	shl    $0x2,%r14
 29ee8cf:	shr    $0x20,%r14
 29ee8d3:	test   %r14,%r14
 29ee8d6:	jne    29fc299 <wasm[0]::function[1015]::helper::object_read+0x1b319>
 29ee8dc:	shl    $0x2,%eax
 29ee8df:	add    $0x14,%eax
 29ee8e2:	jb     29fc29b <wasm[0]::function[1015]::helper::object_read+0x1b31b>
 29ee8e8:	add    %eax,%r9d
 29ee8eb:	jb     29fc29d <wasm[0]::function[1015]::helper::object_read+0x1b31d>
 29ee8f1:	mov    %r9d,%r14d
 29ee8f4:	lea    (%r12,%r14,1),%r9
 29ee8f8:	cmp    %r10,%r14
 29ee8fb:	cmova  %r11,%r9
 29ee8ff:	shl    $0x2,%r13d
 29ee903:	lea    0x14(%r13),%r10d
 29ee907:	sub    %r10d,%eax
 29ee90a:	sub    %rax,%r9
 29ee90d:	mov    (%r9),%r9d
 29ee910:	xor    %r10d,%r10d
 29ee913:	mov    0x200(%rsp),%rax
 29ee91b:	mov    %eax,%r13d
 29ee91e:	mov    %r9d,0x78(%rsp)
 29ee923:	mov    %r10d,0x110(%rsp)
 29ee92b:	mov    %r15,%rax
 29ee92e:	mov    %eax,0xd8(%rsp)
 29ee935:	mov    %ecx,0xc8(%rsp)
 29ee93c:	mov    %edx,0x100(%rsp)
 29ee943:	mov    %edi,0xa0(%rsp)
 29ee94a:	mov    %r8d,0x88(%rsp)
 29ee952:	mov    %esi,0x128(%rsp)
 29ee959:	mov    0x2e8(%rsp),%rax
 29ee961:	mov    (%rax),%rax
 29ee964:	mov    0x228(%rsp),%rsi
 29ee96c:	cmp    %rsi,%rax
 29ee96f:	jae    29fafe1 <wasm[0]::function[1015]::helper::object_read+0x1a061>
 29ee975:	mov    0x78(%rsp),%ecx
 29ee979:	mov    0x110(%rsp),%eax
 29ee980:	test   %ecx,%ecx
 29ee982:	je     29eea5e <wasm[0]::function[1015]::helper::object_read+0xdade>
 29ee988:	mov    0x78(%rsp),%ecx
 29ee98c:	test   %ecx,%ecx
 29ee98e:	je     29fc29f <wasm[0]::function[1015]::helper::object_read+0x1b31f>
 29ee994:	mov    0x2e0(%rsp),%r12
 29ee99c:	mov    0x28(%r12),%rax
 29ee9a1:	mov    %ecx,%edx
 29ee9a3:	mov    %rdx,%rcx
 29ee9a6:	add    0x20(%r12),%rcx
 29ee9ab:	xor    %rsi,%rsi
 29ee9ae:	cmp    %rax,%rdx
 29ee9b1:	cmova  %rsi,%rcx
 29ee9b5:	mov    0x10(%rcx),%rax
 29ee9b9:	cmp    %r13,%rax
 29ee9bc:	je     29eea2e <wasm[0]::function[1015]::helper::object_read+0xdaae>
 29ee9c2:	mov    0x78(%rsp),%ecx
 29ee9c6:	test   %ecx,%ecx
 29ee9c8:	je     29fc2a1 <wasm[0]::function[1015]::helper::object_read+0x1b321>
 29ee9ce:	mov    0x2e0(%rsp),%r12
 29ee9d6:	mov    0x28(%r12),%rax
 29ee9db:	mov    %ecx,%edx
 29ee9dd:	mov    %rdx,%rcx
 29ee9e0:	add    0x20(%r12),%rcx
 29ee9e5:	xor    %rsi,%rsi
 29ee9e8:	cmp    %rax,%rdx
 29ee9eb:	cmova  %rsi,%rcx
 29ee9ef:	mov    0x1c(%rcx),%r9d
 29ee9f3:	mov    0x110(%rsp),%r10d
 29ee9fb:	mov    0xd8(%rsp),%eax
 29eea02:	mov    %rax,%r15
 29eea05:	mov    0xc8(%rsp),%ecx
 29eea0c:	mov    0x100(%rsp),%edx
 29eea13:	mov    0xa0(%rsp),%edi
 29eea1a:	mov    0x88(%rsp),%r8d
 29eea22:	mov    0x128(%rsp),%esi
 29eea29:	jmp    29ee91e <wasm[0]::function[1015]::helper::object_read+0xd99e>
 29eea2e:	mov    0x78(%rsp),%ecx
 29eea32:	test   %ecx,%ecx
 29eea34:	je     29fc2a3 <wasm[0]::function[1015]::helper::object_read+0x1b323>
 29eea3a:	mov    0x2e0(%rsp),%r12
 29eea42:	mov    0x28(%r12),%rax
 29eea47:	mov    %ecx,%edx
 29eea49:	mov    %rdx,%rcx
 29eea4c:	add    0x20(%r12),%rcx
 29eea51:	xor    %rsi,%rsi
 29eea54:	cmp    %rax,%rdx
 29eea57:	cmova  %rsi,%rcx
 29eea5b:	mov    0x18(%rcx),%eax
 29eea5e:	mov    0xd8(%rsp),%ecx
 29eea65:	mov    %rcx,%r15
 29eea68:	mov    0xc8(%rsp),%ecx
 29eea6f:	mov    0x100(%rsp),%edx
 29eea76:	mov    0xa0(%rsp),%edi
 29eea7d:	mov    0x88(%rsp),%r8d
 29eea85:	mov    0x128(%rsp),%esi
 29eea8c:	jmp    29eeb83 <wasm[0]::function[1015]::helper::object_read+0xdc03>
 29eea91:	mov    0x2e0(%rsp),%r12
 29eea99:	mov    0x28(%r12),%r10
 29eea9e:	mov    0x20(%r12),%rbx
 29eeaa3:	lea    (%rbx,%rax,1),%r9
 29eeaa7:	xor    %r11,%r11
 29eeaaa:	cmp    %r10,%rax
 29eeaad:	cmova  %r11,%r9
 29eeab1:	mov    0x20(%r9),%r9d
 29eeab5:	xor    %eax,%eax
 29eeab7:	test   %r9d,%r9d
 29eeaba:	je     29fc2a5 <wasm[0]::function[1015]::helper::object_read+0x1b325>
 29eeac0:	test   %r9d,%r9d
 29eeac3:	je     29fc2a7 <wasm[0]::function[1015]::helper::object_read+0x1b327>
 29eeac9:	mov    %r9d,%r12d
 29eeacc:	lea    0x10(%rbx,%r12,1),%rbx
 29eead1:	cmp    %r10,%r12
 29eead4:	cmova  %r11,%rbx
 29eead8:	mov    0x200(%rsp),%r10
 29eeae0:	mov    %r10d,%r10d
 29eeae3:	mov    (%rbx),%r11d
 29eeae6:	cmp    %r11,%r10
 29eeae9:	jae    29eeb83 <wasm[0]::function[1015]::helper::object_read+0xdc03>
 29eeaef:	mov    0x2e0(%rsp),%rax
 29eeaf7:	mov    0x28(%rax),%rax
 29eeafb:	mov    0x2e0(%rsp),%r10
 29eeb03:	mov    0x20(%r10),%rbx
 29eeb07:	lea    0x10(%rbx,%r12,1),%r11
 29eeb0c:	xor    %r10,%r10
 29eeb0f:	cmp    %rax,%r12
 29eeb12:	cmova  %r10,%r11
 29eeb16:	mov    (%r11),%r11d
 29eeb19:	mov    0x200(%rsp),%r12
 29eeb21:	cmp    %r11d,%r12d
 29eeb24:	jae    29fc2a9 <wasm[0]::function[1015]::helper::object_read+0x1b329>
 29eeb2a:	mov    %r11d,%r12d
 29eeb2d:	shl    $0x2,%r12
 29eeb31:	shr    $0x20,%r12
 29eeb35:	test   %r12,%r12
 29eeb38:	jne    29fc2ab <wasm[0]::function[1015]::helper::object_read+0x1b32b>
 29eeb3e:	shl    $0x2,%r11d
 29eeb42:	add    $0x14,%r11d
 29eeb46:	jb     29fc2ad <wasm[0]::function[1015]::helper::object_read+0x1b32d>
 29eeb4c:	add    %r11d,%r9d
 29eeb4f:	jb     29fc2af <wasm[0]::function[1015]::helper::object_read+0x1b32f>
 29eeb55:	mov    %r9d,%r12d
 29eeb58:	lea    (%rbx,%r12,1),%r9
 29eeb5c:	cmp    %rax,%r12
 29eeb5f:	cmova  %r10,%r9
 29eeb63:	mov    0x200(%rsp),%rax
 29eeb6b:	shl    $0x2,%eax
 29eeb6e:	mov    %rax,0x200(%rsp)
 29eeb76:	lea    0x14(%rax),%r10d
 29eeb7a:	sub    %r10d,%r11d
 29eeb7d:	sub    %r11,%r9
 29eeb80:	mov    (%r9),%eax
 29eeb83:	mov    %ecx,0x88(%rsp)
 29eeb8a:	mov    %edx,0xa0(%rsp)
 29eeb91:	mov    %edi,0x100(%rsp)
 29eeb98:	mov    %r8d,0xc8(%rsp)
 29eeba0:	mov    %esi,0xd8(%rsp)
 29eeba7:	test   %eax,%eax
 29eeba9:	je     29eeeba <wasm[0]::function[1015]::helper::object_read+0xdf3a>
 29eebaf:	test   %eax,%eax
 29eebb1:	jne    29eebbf <wasm[0]::function[1015]::helper::object_read+0xdc3f>
 29eebb7:	xor    %r14d,%r14d
 29eebba:	jmp    29eebf8 <wasm[0]::function[1015]::helper::object_read+0xdc78>
 29eebbf:	test   %eax,%eax
 29eebc1:	je     29fc2b1 <wasm[0]::function[1015]::helper::object_read+0x1b331>
 29eebc7:	mov    0x2e0(%rsp),%r12
 29eebcf:	mov    0x28(%r12),%rcx
 29eebd4:	mov    %eax,%esi
 29eebd6:	mov    %rsi,%rdx
 29eebd9:	add    0x20(%r12),%rdx
 29eebde:	xor    %rdi,%rdi
 29eebe1:	cmp    %rcx,%rsi
 29eebe4:	cmova  %rdi,%rdx
 29eebe8:	mov    0x10(%rdx),%ecx
 29eebeb:	test   $0x4,%ecx
 29eebf1:	setne  %cl
 29eebf4:	movzbl %cl,%r14d
 29eebf8:	test   %eax,%eax
 29eebfa:	jne    29eec07 <wasm[0]::function[1015]::helper::object_read+0xdc87>
 29eec00:	xor    %ebx,%ebx
 29eec02:	jmp    29eec3f <wasm[0]::function[1015]::helper::object_read+0xdcbf>
 29eec07:	test   %eax,%eax
 29eec09:	je     29fc2b3 <wasm[0]::function[1015]::helper::object_read+0x1b333>
 29eec0f:	mov    0x2e0(%rsp),%r12
 29eec17:	mov    0x28(%r12),%rcx
 29eec1c:	mov    %eax,%esi
 29eec1e:	mov    %rsi,%rdx
 29eec21:	add    0x20(%r12),%rdx
 29eec26:	xor    %rdi,%rdi
 29eec29:	cmp    %rcx,%rsi
 29eec2c:	cmova  %rdi,%rdx
 29eec30:	mov    0x10(%rdx),%ecx
 29eec33:	test   $0x8,%ecx
 29eec39:	setne  %cl
 29eec3c:	movzbl %cl,%ebx
 29eec3f:	test   %eax,%eax
 29eec41:	jne    29eec4f <wasm[0]::function[1015]::helper::object_read+0xdccf>
 29eec47:	xor    %r13d,%r13d
 29eec4a:	jmp    29eec88 <wasm[0]::function[1015]::helper::object_read+0xdd08>
 29eec4f:	test   %eax,%eax
 29eec51:	je     29fc2b5 <wasm[0]::function[1015]::helper::object_read+0x1b335>
 29eec57:	mov    0x2e0(%rsp),%r12
 29eec5f:	mov    0x28(%r12),%rcx
 29eec64:	mov    %eax,%esi
 29eec66:	mov    %rsi,%rdx
 29eec69:	add    0x20(%r12),%rdx
 29eec6e:	xor    %rdi,%rdi
 29eec71:	cmp    %rcx,%rsi
 29eec74:	cmova  %rdi,%rdx
 29eec78:	mov    0x10(%rdx),%ecx
 29eec7b:	test   $0x2,%ecx
 29eec81:	setne  %cl
 29eec84:	movzbl %cl,%r13d
 29eec88:	test   %eax,%eax
 29eec8a:	je     29fc2b7 <wasm[0]::function[1015]::helper::object_read+0x1b337>
 29eec90:	mov    0x2e0(%rsp),%r12
 29eec98:	mov    0x28(%r12),%rsi
 29eec9d:	mov    0x20(%r12),%rdx
 29eeca2:	mov    %eax,%ecx
 29eeca4:	add    %rcx,%rdx
 29eeca7:	xor    %rdi,%rdi
 29eecaa:	cmp    %rsi,%rcx
 29eecad:	cmova  %rdi,%rdx
 29eecb1:	mov    0x14(%rdx),%esi
 29eecb4:	mov    %esi,0x128(%rsp)
 29eecbb:	mov    0x18(%rdx),%esi
 29eecbe:	mov    %esi,0x78(%rsp)
 29eecc2:	mov    0x1c(%rdx),%edx
 29eecc5:	mov    %edx,0x110(%rsp)
 29eeccc:	test   %eax,%eax
 29eecce:	jne    29eecdb <wasm[0]::function[1015]::helper::object_read+0xdd5b>
 29eecd4:	xor    %eax,%eax
 29eecd6:	jmp    29eed08 <wasm[0]::function[1015]::helper::object_read+0xdd88>
 29eecdb:	mov    0x2e0(%rsp),%r12
 29eece3:	mov    0x28(%r12),%rdx
 29eece8:	mov    %rcx,%rax
 29eeceb:	add    0x20(%r12),%rax
 29eecf0:	xor    %rsi,%rsi
 29eecf3:	cmp    %rdx,%rcx
 29eecf6:	cmova  %rsi,%rax
 29eecfa:	mov    0x10(%rax),%eax
 29eecfd:	test   $0x1,%eax
 29eed02:	setne  %al
 29eed05:	movzbl %al,%eax
 29eed08:	test   %eax,%eax
 29eed0a:	jne    29eedf0 <wasm[0]::function[1015]::helper::object_read+0xde70>
 29eed10:	mov    0x128(%rsp),%eax
 29eed17:	test   %eax,%eax
 29eed19:	je     29fc2b9 <wasm[0]::function[1015]::helper::object_read+0x1b339>
 29eed1f:	mov    0x78(%rsp),%eax
 29eed23:	test   %eax,%eax
 29eed25:	je     29fc2bb <wasm[0]::function[1015]::helper::object_read+0x1b33b>
 29eed2b:	mov    0x110(%rsp),%eax
 29eed32:	test   %eax,%eax
 29eed34:	je     29fc2bd <wasm[0]::function[1015]::helper::object_read+0x1b33d>
 29eed3a:	mov    0x190(%rsp),%rcx
 29eed42:	mov    0x20(%rcx),%rax
 29eed46:	mov    (%rax),%ecx
 29eed48:	mov    %rcx,%r15
 29eed4b:	mov    %ecx,%ecx
 29eed4d:	mov    $0x20,%edx
 29eed52:	lea    0x20(%rcx),%rsi
 29eed56:	mov    0x4(%rax),%edi
 29eed59:	cmp    %rdi,%rsi
 29eed5c:	ja     29fb01c <wasm[0]::function[1015]::helper::object_read+0x1a09c>
 29eed62:	mov    %r15,%rsi
 29eed65:	add    $0x20,%esi
 29eed6b:	mov    %esi,(%rax)
 29eed6d:	mov    0x2e0(%rsp),%r12
 29eed75:	mov    0x20(%r12),%rsi
 29eed7a:	lea    (%rsi,%rcx,1),%rax
 29eed7e:	movl   $0xb0000072,(%rsi,%rcx,1)
 29eed85:	mov    0x190(%rsp),%rdi
 29eed8d:	mov    0x28(%rdi),%rdi
 29eed91:	mov    0x13c(%rdi),%edi
 29eed97:	mov    %edi,0x4(%rsi,%rcx,1)
 29eed9b:	mov    %edx,0x8(%rsi,%rcx,1)
 29eed9f:	test   %r14d,%r14d
 29eeda2:	setne  %sil
 29eeda6:	movzbl %sil,%ecx
 29eedaa:	shl    $0x2,%ecx
 29eedad:	test   %ebx,%ebx
 29eedaf:	setne  %sil
 29eedb3:	movzbl %sil,%esi
 29eedb7:	shl    $0x3,%esi
 29eedba:	or     %esi,%ecx
 29eedbc:	test   %r13d,%r13d
 29eedbf:	setne  %sil
 29eedc3:	movzbl %sil,%esi
 29eedc7:	shl    $1,%esi
 29eedc9:	or     %esi,%ecx
 29eedcb:	mov    %ecx,0x10(%rax)
 29eedce:	mov    0x128(%rsp),%esi
 29eedd5:	mov    %esi,0x14(%rax)
 29eedd8:	mov    0x78(%rsp),%edi
 29eeddc:	mov    %edi,0x18(%rax)
 29eeddf:	mov    0x110(%rsp),%r8d
 29eede7:	mov    %r8d,0x1c(%rax)
 29eedeb:	jmp    29eeeba <wasm[0]::function[1015]::helper::object_read+0xdf3a>
 29eedf0:	mov    0x128(%rsp),%r10d
 29eedf8:	test   %r10d,%r10d
 29eedfb:	je     29fc2bf <wasm[0]::function[1015]::helper::object_read+0x1b33f>
 29eee01:	mov    0x78(%rsp),%eax
 29eee05:	test   %eax,%eax
 29eee07:	je     29fc2c1 <wasm[0]::function[1015]::helper::object_read+0x1b341>
 29eee0d:	mov    0x110(%rsp),%eax
 29eee14:	test   %eax,%eax
 29eee16:	je     29fc2c3 <wasm[0]::function[1015]::helper::object_read+0x1b343>
 29eee1c:	mov    0x190(%rsp),%rcx
 29eee24:	mov    0x20(%rcx),%rax
 29eee28:	mov    (%rax),%ecx
 29eee2a:	mov    %rcx,%r15
 29eee2d:	mov    %ecx,%ecx
 29eee2f:	mov    $0x20,%edx
 29eee34:	lea    0x20(%rcx),%rsi
 29eee38:	mov    0x4(%rax),%edi
 29eee3b:	cmp    %rdi,%rsi
 29eee3e:	ja     29fb062 <wasm[0]::function[1015]::helper::object_read+0x1a0e2>
 29eee44:	mov    %r15,%rsi
 29eee47:	add    $0x20,%esi
 29eee4d:	mov    %esi,(%rax)
 29eee4f:	mov    0x2e0(%rsp),%r12
 29eee57:	mov    0x20(%r12),%rsi
 29eee5c:	lea    (%rsi,%rcx,1),%rax
 29eee60:	movl   $0xb0000072,(%rsi,%rcx,1)
 29eee67:	mov    0x190(%rsp),%rdi
 29eee6f:	mov    0x28(%rdi),%rdi
 29eee73:	mov    0x13c(%rdi),%edi
 29eee79:	mov    %edi,0x4(%rsi,%rcx,1)
 29eee7d:	mov    %edx,0x8(%rsi,%rcx,1)
 29eee81:	test   %ebx,%ebx
 29eee83:	setne  %cl
 29eee86:	movzbl %cl,%ecx
 29eee89:	shl    $0x3,%ecx
 29eee8c:	or     $0x1,%ecx
 29eee8f:	test   %r13d,%r13d
 29eee92:	setne  %dl
 29eee95:	movzbl %dl,%edx
 29eee98:	shl    $1,%edx
 29eee9a:	or     %edx,%ecx
 29eee9c:	mov    %ecx,0x10(%rax)
 29eee9f:	mov    0x128(%rsp),%ecx
 29eeea6:	mov    %ecx,0x14(%rax)
 29eeea9:	mov    0x78(%rsp),%ecx
 29eeead:	mov    %ecx,0x18(%rax)
 29eeeb0:	mov    0x110(%rsp),%ecx
 29eeeb7:	mov    %ecx,0x1c(%rax)
 29eeeba:	mov    0x88(%rsp),%esi
 29eeec1:	mov    0xa0(%rsp),%edi
 29eeec8:	mov    0x100(%rsp),%r8d
 29eeed0:	mov    0xc8(%rsp),%edx
 29eeed7:	mov    0xd8(%rsp),%ecx
 29eeede:	jmp    29ef2e7 <wasm[0]::function[1015]::helper::object_read+0xe367>
 29eeee3:	xor    %edi,%edi
 29eeee5:	mov    0x210(%rsp),%rax
 29eeeed:	mov    0x210(%rsp),%rdx
 29eeef5:	test   %eax,%edx
 29eeef7:	je     29eef59 <wasm[0]::function[1015]::helper::object_read+0xdfd9>
 29eeefd:	xor    %edi,%edi
 29eeeff:	mov    0x210(%rsp),%rdx
 29eef07:	test   $0x1,%edx
 29eef0d:	jne    29eef59 <wasm[0]::function[1015]::helper::object_read+0xdfd9>
 29eef13:	mov    0x2e0(%rsp),%r12
 29eef1b:	mov    0x28(%r12),%rax
 29eef20:	mov    0x20(%r12),%rcx
 29eef25:	mov    0x210(%rsp),%rdx
 29eef2d:	mov    %edx,%edx
 29eef2f:	lea    0x4(%rcx,%rdx,1),%rcx
 29eef34:	xor    %rsi,%rsi
 29eef37:	cmp    %rax,%rdx
 29eef3a:	cmova  %rsi,%rcx
 29eef3e:	mov    (%rcx),%eax
 29eef40:	mov    0x190(%rsp),%rcx
 29eef48:	mov    0x28(%rcx),%rcx
 29eef4c:	cmp    0x138(%rcx),%eax
 29eef52:	sete   %al
 29eef55:	rex movzbl %al,%edi
 29eef59:	test   %edi,%edi
 29eef5b:	je     29fc2c5 <wasm[0]::function[1015]::helper::object_read+0x1b345>
 29eef61:	mov    0x210(%rsp),%rax
 29eef69:	mov    0x210(%rsp),%rdx
 29eef71:	test   %eax,%edx
 29eef73:	je     29fc2c7 <wasm[0]::function[1015]::helper::object_read+0x1b347>
 29eef79:	mov    0x1b8(%rsp),%rcx
 29eef81:	mov    0x190(%rsp),%rsi
 29eef89:	mov    0x190(%rsp),%rdi
 29eef91:	mov    0x1c0(%rsp),%r8
 29eef99:	call   29ffc60 <wasm[0]::function[1019]::helper::ordinary_own_descriptor>
 29eef9e:	mov    0xc0(%rsp),%ecx
 29eefa5:	mov    %rcx,%r15
 29eefa8:	test   %eax,%eax
 29eefaa:	je     29ef2c9 <wasm[0]::function[1015]::helper::object_read+0xe349>
 29eefb0:	test   %eax,%eax
 29eefb2:	jne    29eefc0 <wasm[0]::function[1015]::helper::object_read+0xe040>
 29eefb8:	xor    %r13d,%r13d
 29eefbb:	jmp    29eeff9 <wasm[0]::function[1015]::helper::object_read+0xe079>
 29eefc0:	test   %eax,%eax
 29eefc2:	je     29fc2c9 <wasm[0]::function[1015]::helper::object_read+0x1b349>
 29eefc8:	mov    0x2e0(%rsp),%r12
 29eefd0:	mov    0x28(%r12),%rcx
 29eefd5:	mov    %eax,%esi
 29eefd7:	mov    %rsi,%rdx
 29eefda:	add    0x20(%r12),%rdx
 29eefdf:	xor    %rdi,%rdi
 29eefe2:	cmp    %rcx,%rsi
 29eefe5:	cmova  %rdi,%rdx
 29eefe9:	mov    0x10(%rdx),%ecx
 29eefec:	test   $0x4,%ecx
 29eeff2:	setne  %cl
 29eeff5:	movzbl %cl,%r13d
 29eeff9:	test   %eax,%eax
 29eeffb:	jne    29ef009 <wasm[0]::function[1015]::helper::object_read+0xe089>
 29ef001:	xor    %r14d,%r14d
 29ef004:	jmp    29ef042 <wasm[0]::function[1015]::helper::object_read+0xe0c2>
 29ef009:	test   %eax,%eax
 29ef00b:	je     29fc2cb <wasm[0]::function[1015]::helper::object_read+0x1b34b>
 29ef011:	mov    0x2e0(%rsp),%r12
 29ef019:	mov    0x28(%r12),%rcx
 29ef01e:	mov    %eax,%esi
 29ef020:	mov    %rsi,%rdx
 29ef023:	add    0x20(%r12),%rdx
 29ef028:	xor    %rdi,%rdi
 29ef02b:	cmp    %rcx,%rsi
 29ef02e:	cmova  %rdi,%rdx
 29ef032:	mov    0x10(%rdx),%ecx
 29ef035:	test   $0x8,%ecx
 29ef03b:	setne  %dl
 29ef03e:	movzbl %dl,%r14d
 29ef042:	test   %eax,%eax
 29ef044:	jne    29ef051 <wasm[0]::function[1015]::helper::object_read+0xe0d1>
 29ef04a:	xor    %ebx,%ebx
 29ef04c:	jmp    29ef08e <wasm[0]::function[1015]::helper::object_read+0xe10e>
 29ef051:	test   %eax,%eax
 29ef053:	je     29fc2cd <wasm[0]::function[1015]::helper::object_read+0x1b34d>
 29ef059:	mov    0x2e0(%rsp),%r12
 29ef061:	mov    0x28(%r12),%r8
 29ef066:	mov    %eax,%r9d
 29ef069:	mov    %r9,%rsi
 29ef06c:	add    0x20(%r12),%rsi
 29ef071:	xor    %r10,%r10
 29ef074:	cmp    %r8,%r9
 29ef077:	cmova  %r10,%rsi
 29ef07b:	mov    0x10(%rsi),%r9d
 29ef07f:	test   $0x2,%r9d
 29ef086:	setne  %r10b
 29ef08a:	movzbl %r10b,%ebx
 29ef08e:	test   %eax,%eax
 29ef090:	je     29fc2cf <wasm[0]::function[1015]::helper::object_read+0x1b34f>
 29ef096:	mov    0x2e0(%rsp),%r12
 29ef09e:	mov    0x28(%r12),%rdx
 29ef0a3:	mov    0x20(%r12),%rsi
 29ef0a8:	mov    %eax,%ecx
 29ef0aa:	lea    (%rsi,%rcx,1),%r10
 29ef0ae:	xor    %rsi,%rsi
 29ef0b1:	cmp    %rdx,%rcx
 29ef0b4:	cmova  %rsi,%r10
 29ef0b8:	mov    0x14(%r10),%edx
 29ef0bc:	mov    %edx,0xc0(%rsp)
 29ef0c3:	mov    0x18(%r10),%edx
 29ef0c7:	mov    %edx,0x88(%rsp)
 29ef0ce:	mov    0x1c(%r10),%edx
 29ef0d2:	mov    %edx,0xa0(%rsp)
 29ef0d9:	test   %eax,%eax
 29ef0db:	jne    29ef0e8 <wasm[0]::function[1015]::helper::object_read+0xe168>
 29ef0e1:	xor    %eax,%eax
 29ef0e3:	jmp    29ef115 <wasm[0]::function[1015]::helper::object_read+0xe195>
 29ef0e8:	mov    0x2e0(%rsp),%r12
 29ef0f0:	mov    0x28(%r12),%rdx
 29ef0f5:	mov    %rcx,%rax
 29ef0f8:	add    0x20(%r12),%rax
 29ef0fd:	xor    %rsi,%rsi
 29ef100:	cmp    %rdx,%rcx
 29ef103:	cmova  %rsi,%rax
 29ef107:	mov    0x10(%rax),%eax
 29ef10a:	test   $0x1,%eax
 29ef10f:	setne  %al
 29ef112:	movzbl %al,%eax
 29ef115:	test   %eax,%eax
 29ef117:	jne    29ef1fb <wasm[0]::function[1015]::helper::object_read+0xe27b>
 29ef11d:	mov    0xc0(%rsp),%eax
 29ef124:	test   %eax,%eax
 29ef126:	je     29fc2d1 <wasm[0]::function[1015]::helper::object_read+0x1b351>
 29ef12c:	mov    0x88(%rsp),%eax
 29ef133:	test   %eax,%eax
 29ef135:	je     29fc2d3 <wasm[0]::function[1015]::helper::object_read+0x1b353>
 29ef13b:	mov    0xa0(%rsp),%eax
 29ef142:	test   %eax,%eax
 29ef144:	je     29fc2d5 <wasm[0]::function[1015]::helper::object_read+0x1b355>
 29ef14a:	mov    0x190(%rsp),%rcx
 29ef152:	mov    0x20(%rcx),%rax
 29ef156:	mov    (%rax),%ecx
 29ef158:	mov    %rcx,%r15
 29ef15b:	mov    %ecx,%ecx
 29ef15d:	mov    $0x20,%edx
 29ef162:	lea    0x20(%rcx),%rsi
 29ef166:	mov    0x4(%rax),%edi
 29ef169:	cmp    %rdi,%rsi
 29ef16c:	ja     29fb0a8 <wasm[0]::function[1015]::helper::object_read+0x1a128>
 29ef172:	mov    %r15,%rsi
 29ef175:	add    $0x20,%esi
 29ef17b:	mov    %esi,(%rax)
 29ef17d:	mov    0x2e0(%rsp),%r12
 29ef185:	mov    0x20(%r12),%rsi
 29ef18a:	lea    (%rsi,%rcx,1),%rax
 29ef18e:	movl   $0xb0000072,(%rsi,%rcx,1)
 29ef195:	mov    0x190(%rsp),%rdi
 29ef19d:	mov    0x28(%rdi),%rdi
 29ef1a1:	mov    0x13c(%rdi),%edi
 29ef1a7:	mov    %edi,0x4(%rsi,%rcx,1)
 29ef1ab:	mov    %edx,0x8(%rsi,%rcx,1)
 29ef1af:	test   %r13d,%r13d
 29ef1b2:	setne  %cl
 29ef1b5:	movzbl %cl,%ecx
 29ef1b8:	shl    $0x2,%ecx
 29ef1bb:	test   %r14d,%r14d
 29ef1be:	setne  %dl
 29ef1c1:	movzbl %dl,%edx
 29ef1c4:	shl    $0x3,%edx
 29ef1c7:	or     %edx,%ecx
 29ef1c9:	test   %ebx,%ebx
 29ef1cb:	setne  %dl
 29ef1ce:	movzbl %dl,%edx
 29ef1d1:	shl    $1,%edx
 29ef1d3:	or     %edx,%ecx
 29ef1d5:	mov    %ecx,0x10(%rax)
 29ef1d8:	mov    0xc0(%rsp),%ecx
 29ef1df:	mov    %ecx,0x14(%rax)
 29ef1e2:	mov    0x88(%rsp),%ecx
 29ef1e9:	mov    %ecx,0x18(%rax)
 29ef1ec:	mov    0xa0(%rsp),%ecx
 29ef1f3:	mov    %ecx,0x1c(%rax)
 29ef1f6:	jmp    29ef2c9 <wasm[0]::function[1015]::helper::object_read+0xe349>
 29ef1fb:	mov    0xc0(%rsp),%eax
 29ef202:	test   %eax,%eax
 29ef204:	je     29fc2d7 <wasm[0]::function[1015]::helper::object_read+0x1b357>
 29ef20a:	mov    0x88(%rsp),%eax
 29ef211:	test   %eax,%eax
 29ef213:	je     29fc2d9 <wasm[0]::function[1015]::helper::object_read+0x1b359>
 29ef219:	mov    0xa0(%rsp),%eax
 29ef220:	test   %eax,%eax
 29ef222:	je     29fc2db <wasm[0]::function[1015]::helper::object_read+0x1b35b>
 29ef228:	mov    0x190(%rsp),%rcx
 29ef230:	mov    0x20(%rcx),%rax
 29ef234:	mov    (%rax),%ecx
 29ef236:	mov    %rcx,%r15
 29ef239:	mov    %ecx,%ecx
 29ef23b:	mov    $0x20,%edx
 29ef240:	lea    0x20(%rcx),%rsi
 29ef244:	mov    0x4(%rax),%edi
 29ef247:	cmp    %rdi,%rsi
 29ef24a:	ja     29fb0ee <wasm[0]::function[1015]::helper::object_read+0x1a16e>
 29ef250:	mov    %r15,%rsi
 29ef253:	add    $0x20,%esi
 29ef259:	mov    %esi,(%rax)
 29ef25b:	mov    0x2e0(%rsp),%r12
 29ef263:	mov    0x20(%r12),%rsi
 29ef268:	lea    (%rsi,%rcx,1),%rax
 29ef26c:	movl   $0xb0000072,(%rsi,%rcx,1)
 29ef273:	mov    0x190(%rsp),%rdi
 29ef27b:	mov    0x28(%rdi),%rdi
 29ef27f:	mov    0x13c(%rdi),%edi
 29ef285:	mov    %edi,0x4(%rsi,%rcx,1)
 29ef289:	mov    %edx,0x8(%rsi,%rcx,1)
 29ef28d:	test   %r14d,%r14d
 29ef290:	setne  %cl
 29ef293:	movzbl %cl,%ecx
 29ef296:	shl    $0x3,%ecx
 29ef299:	or     $0x1,%ecx
 29ef29c:	test   %ebx,%ebx
 29ef29e:	setne  %dl
 29ef2a1:	movzbl %dl,%edx
 29ef2a4:	shl    $1,%edx
 29ef2a6:	or     %edx,%ecx
 29ef2a8:	mov    %ecx,0x10(%rax)
 29ef2ab:	mov    0xc0(%rsp),%ecx
 29ef2b2:	mov    %ecx,0x14(%rax)
 29ef2b5:	mov    0x88(%rsp),%edx
 29ef2bc:	mov    %edx,0x18(%rax)
 29ef2bf:	mov    0xa0(%rsp),%esi
 29ef2c6:	mov    %esi,0x1c(%rax)
 29ef2c9:	mov    0x58(%rsp),%esi
 29ef2cd:	mov    0xa8(%rsp),%edi
 29ef2d4:	mov    0xb8(%rsp),%r8d
 29ef2dc:	mov    0x48(%rsp),%edx
 29ef2e0:	mov    0x80(%rsp),%ecx
 29ef2e7:	mov    %esi,0x80(%rsp)
 29ef2ee:	mov    %edi,0x48(%rsp)
 29ef2f2:	mov    %r8d,0xb8(%rsp)
 29ef2fa:	mov    %edx,0xa8(%rsp)
 29ef301:	mov    %ecx,0x58(%rsp)
 29ef305:	mov    %r15,%rax
 29ef308:	mov    %r15,%rsi
 29ef30b:	test   %esi,%eax
 29ef30d:	jne    29ef82a <wasm[0]::function[1015]::helper::object_read+0xe8aa>
 29ef313:	xor    %esi,%esi
 29ef315:	test   %edx,%edx
 29ef317:	je     29ef369 <wasm[0]::function[1015]::helper::object_read+0xe3e9>
 29ef31d:	xor    %esi,%esi
 29ef31f:	test   $0x1,%edx
 29ef325:	jne    29ef369 <wasm[0]::function[1015]::helper::object_read+0xe3e9>
 29ef32b:	mov    0x2e0(%rsp),%r12
 29ef333:	mov    0x28(%r12),%rax
 29ef338:	mov    0x20(%r12),%rdi
 29ef33d:	mov    %edx,%esi
 29ef33f:	lea    0x4(%rdi,%rsi,1),%rdx
 29ef344:	xor    %rdi,%rdi
 29ef347:	cmp    %rax,%rsi
 29ef34a:	cmova  %rdi,%rdx
 29ef34e:	mov    (%rdx),%eax
 29ef350:	mov    0x190(%rsp),%rdx
 29ef358:	mov    0x28(%rdx),%rdx
 29ef35c:	cmp    0x26c(%rdx),%eax
 29ef362:	sete   %al
 29ef365:	rex movzbl %al,%esi
 29ef369:	xor    %eax,%eax
 29ef36b:	test   %esi,%esi
 29ef36d:	je     29ef4af <wasm[0]::function[1015]::helper::object_read+0xe52f>
 29ef373:	xor    %eax,%eax
 29ef375:	mov    0x1b8(%rsp),%rdx
 29ef37d:	cmp    $0x4,%edx
 29ef380:	jne    29ef4af <wasm[0]::function[1015]::helper::object_read+0xe52f>
 29ef386:	xor    %eax,%eax
 29ef388:	test   %ecx,%ecx
 29ef38a:	je     29ef3db <wasm[0]::function[1015]::helper::object_read+0xe45b>
 29ef390:	xor    %eax,%eax
 29ef392:	test   $0x1,%ecx
 29ef398:	jne    29ef3db <wasm[0]::function[1015]::helper::object_read+0xe45b>
 29ef39e:	mov    0x2e0(%rsp),%r12
 29ef3a6:	mov    0x28(%r12),%rax
 29ef3ab:	mov    0x20(%r12),%rsi
 29ef3b0:	mov    %ecx,%edx
 29ef3b2:	lea    0x4(%rsi,%rdx,1),%rcx
 29ef3b7:	xor    %rsi,%rsi
 29ef3ba:	cmp    %rax,%rdx
 29ef3bd:	cmova  %rsi,%rcx
 29ef3c1:	mov    (%rcx),%eax
 29ef3c3:	mov    0x190(%rsp),%rcx
 29ef3cb:	mov    0x28(%rcx),%rcx
 29ef3cf:	cmp    0x234(%rcx),%eax
 29ef3d5:	sete   %al
 29ef3d8:	movzbl %al,%eax
 29ef3db:	test   %eax,%eax
 29ef3dd:	je     29fc2dd <wasm[0]::function[1015]::helper::object_read+0x1b35d>
 29ef3e3:	mov    $0xb,%edx
 29ef3e8:	mov    0x190(%rsp),%rsi
 29ef3f0:	mov    0x190(%rsp),%rdi
 29ef3f8:	call   2f30600 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 29ef3fd:	mov    0x58(%rsp),%edx
 29ef401:	xor    %r8d,%r8d
 29ef404:	test   %edx,%edx
 29ef406:	je     29fc2df <wasm[0]::function[1015]::helper::object_read+0x1b35f>
 29ef40c:	test   %eax,%eax
 29ef40e:	je     29fc2e1 <wasm[0]::function[1015]::helper::object_read+0x1b361>
 29ef414:	mov    %rax,%rcx
 29ef417:	mov    0x190(%rsp),%rsi
 29ef41f:	mov    0x190(%rsp),%rdi
 29ef427:	call   2ae5540 <wasm[0]::function[1057]::helper::string_equality>
 29ef42c:	test   %eax,%eax
 29ef42e:	jne    29ef4a7 <wasm[0]::function[1015]::helper::object_read+0xe527>
 29ef434:	mov    0x58(%rsp),%edx
 29ef438:	xor    %r8d,%r8d
 29ef43b:	mov    %r8,%rbx
 29ef43e:	test   %edx,%edx
 29ef440:	je     29fc2e3 <wasm[0]::function[1015]::helper::object_read+0x1b363>
 29ef446:	mov    0x190(%rsp),%rsi
 29ef44e:	mov    0x190(%rsp),%rdi
 29ef456:	call   2aec9a0 <wasm[0]::function[1060]::helper::string_to_number>
 29ef45b:	mov    %rax,%rdx
 29ef45e:	mov    0x190(%rsp),%rsi
 29ef466:	mov    0x190(%rsp),%rdi
 29ef46e:	call   2ae5dc0 <wasm[0]::function[1059]::helper::number_to_string>
 29ef473:	mov    0x58(%rsp),%edx
 29ef477:	test   %edx,%edx
 29ef479:	je     29fc2e5 <wasm[0]::function[1015]::helper::object_read+0x1b365>
 29ef47f:	test   %eax,%eax
 29ef481:	je     29fc2e7 <wasm[0]::function[1015]::helper::object_read+0x1b367>
 29ef487:	mov    %rax,%rcx
 29ef48a:	mov    %rbx,%r8
 29ef48d:	mov    0x190(%rsp),%rsi
 29ef495:	mov    0x190(%rsp),%rdi
 29ef49d:	call   2ae5540 <wasm[0]::function[1057]::helper::string_equality>
 29ef4a2:	jmp    29ef4af <wasm[0]::function[1015]::helper::object_read+0xe52f>
 29ef4a7:	mov    0x278(%rsp),%rax
 29ef4af:	test   %eax,%eax
 29ef4b1:	jne    29ef7e2 <wasm[0]::function[1015]::helper::object_read+0xe862>
 29ef4b7:	mov    0xa8(%rsp),%r8d
 29ef4bf:	mov    0x2d8(%rsp),%rcx
 29ef4c7:	mov    0x2d0(%rsp),%rdx
 29ef4cf:	mov    0x190(%rsp),%rsi
 29ef4d7:	mov    0x190(%rsp),%rdi
 29ef4df:	call   2a5f680 <wasm[0]::function[1039]::helper::object_header_projection>
 29ef4e4:	xor    %ecx,%ecx
 29ef4e6:	test   %eax,%eax
 29ef4e8:	je     29fc2e9 <wasm[0]::function[1015]::helper::object_read+0x1b369>
 29ef4ee:	test   %eax,%eax
 29ef4f0:	je     29fc2eb <wasm[0]::function[1015]::helper::object_read+0x1b36b>
 29ef4f6:	mov    0x2e0(%rsp),%r12
 29ef4fe:	mov    0x28(%r12),%rdx
 29ef503:	mov    0x20(%r12),%rdi
 29ef508:	mov    %eax,%esi
 29ef50a:	lea    (%rdi,%rsi,1),%rax
 29ef50e:	xor    %rdi,%rdi
 29ef511:	cmp    %rdx,%rsi
 29ef514:	cmova  %rdi,%rax
 29ef518:	mov    0x10(%rax),%r8d
 29ef51c:	test   %r8d,%r8d
 29ef51f:	jne    29ef535 <wasm[0]::function[1015]::helper::object_read+0xe5b5>
 29ef525:	mov    0x278(%rsp),%rdx
 29ef52d:	mov    %rcx,%r8
 29ef530:	jmp    29ef702 <wasm[0]::function[1015]::helper::object_read+0xe782>
 29ef535:	xor    %eax,%eax
 29ef537:	test   %r8d,%r8d
 29ef53a:	je     29ef591 <wasm[0]::function[1015]::helper::object_read+0xe611>
 29ef540:	xor    %eax,%eax
 29ef542:	test   $0x1,%r8d
 29ef549:	jne    29ef591 <wasm[0]::function[1015]::helper::object_read+0xe611>
 29ef54f:	mov    0x2e0(%rsp),%r12
 29ef557:	mov    0x28(%r12),%r9
 29ef55c:	mov    0x20(%r12),%r11
 29ef561:	mov    %r8d,%r10d
 29ef564:	lea    0x4(%r11,%r10,1),%rsi
 29ef569:	xor    %r11,%r11
 29ef56c:	cmp    %r9,%r10
 29ef56f:	cmova  %r11,%rsi
 29ef573:	mov    (%rsi),%r10d
 29ef576:	mov    0x190(%rsp),%rcx
 29ef57e:	mov    0x28(%rcx),%r11
 29ef582:	cmp    0x1d4(%r11),%r10d
 29ef589:	sete   %r11b
 29ef58d:	movzbl %r11b,%eax
 29ef591:	mov    $0x6,%edx
 29ef596:	mov    %rdx,0x278(%rsp)
 29ef59e:	test   %eax,%eax
 29ef5a0:	je     29ef5b3 <wasm[0]::function[1015]::helper::object_read+0xe633>
 29ef5a6:	mov    $0x8,%edx
 29ef5ab:	mov    %rdx,0x278(%rsp)
 29ef5b3:	xor    %eax,%eax
 29ef5b5:	test   %r8d,%r8d
 29ef5b8:	je     29ef60b <wasm[0]::function[1015]::helper::object_read+0xe68b>
 29ef5be:	xor    %eax,%eax
 29ef5c0:	test   $0x1,%r8d
 29ef5c7:	jne    29ef60b <wasm[0]::function[1015]::helper::object_read+0xe68b>
 29ef5cd:	mov    0x2e0(%rsp),%r12
 29ef5d5:	mov    0x28(%r12),%rax
 29ef5da:	mov    0x20(%r12),%rcx
 29ef5df:	mov    %r8d,%edx
 29ef5e2:	lea    0x4(%rcx,%rdx,1),%rcx
 29ef5e7:	xor    %rsi,%rsi
 29ef5ea:	cmp    %rax,%rdx
 29ef5ed:	cmova  %rsi,%rcx
 29ef5f1:	mov    (%rcx),%eax
 29ef5f3:	mov    0x190(%rsp),%rcx
 29ef5fb:	mov    0x28(%rcx),%rcx
 29ef5ff:	cmp    0x1e4(%rcx),%eax
 29ef605:	sete   %al
 29ef608:	movzbl %al,%eax
 29ef60b:	test   %eax,%eax
 29ef60d:	je     29ef620 <wasm[0]::function[1015]::helper::object_read+0xe6a0>
 29ef613:	mov    $0x8,%edx
 29ef618:	mov    %rdx,0x278(%rsp)
 29ef620:	xor    %eax,%eax
 29ef622:	test   %r8d,%r8d
 29ef625:	je     29ef678 <wasm[0]::function[1015]::helper::object_read+0xe6f8>
 29ef62b:	xor    %eax,%eax
 29ef62d:	test   $0x1,%r8d
 29ef634:	jne    29ef678 <wasm[0]::function[1015]::helper::object_read+0xe6f8>
 29ef63a:	mov    0x2e0(%rsp),%r12
 29ef642:	mov    0x28(%r12),%rax
 29ef647:	mov    0x20(%r12),%rcx
 29ef64c:	mov    %r8d,%edx
 29ef64f:	lea    0x4(%rcx,%rdx,1),%rcx
 29ef654:	xor    %rsi,%rsi
 29ef657:	cmp    %rax,%rdx
 29ef65a:	cmova  %rsi,%rcx
 29ef65e:	mov    (%rcx),%eax
 29ef660:	mov    0x190(%rsp),%rcx
 29ef668:	mov    0x28(%rcx),%rcx
 29ef66c:	cmp    0x1f0(%rcx),%eax
 29ef672:	sete   %al
 29ef675:	movzbl %al,%eax
 29ef678:	test   %eax,%eax
 29ef67a:	je     29ef68d <wasm[0]::function[1015]::helper::object_read+0xe70d>
 29ef680:	mov    $0x9,%edx
 29ef685:	mov    %rdx,0x278(%rsp)
 29ef68d:	xor    %eax,%eax
 29ef68f:	test   %r8d,%r8d
 29ef692:	je     29ef6e5 <wasm[0]::function[1015]::helper::object_read+0xe765>
 29ef698:	xor    %eax,%eax
 29ef69a:	test   $0x1,%r8d
 29ef6a1:	jne    29ef6e5 <wasm[0]::function[1015]::helper::object_read+0xe765>
 29ef6a7:	mov    0x2e0(%rsp),%r12
 29ef6af:	mov    0x28(%r12),%rax
 29ef6b4:	mov    0x20(%r12),%rcx
 29ef6b9:	mov    %r8d,%edx
 29ef6bc:	lea    0x4(%rcx,%rdx,1),%rcx
 29ef6c1:	xor    %rsi,%rsi
 29ef6c4:	cmp    %rax,%rdx
 29ef6c7:	cmova  %rsi,%rcx
 29ef6cb:	mov    (%rcx),%eax
 29ef6cd:	mov    0x190(%rsp),%rcx
 29ef6d5:	mov    0x28(%rcx),%rcx
 29ef6d9:	cmp    0x254(%rcx),%eax
 29ef6df:	sete   %al
 29ef6e2:	movzbl %al,%eax
 29ef6e5:	test   %eax,%eax
 29ef6e7:	je     29ef6fa <wasm[0]::function[1015]::helper::object_read+0xe77a>
 29ef6ed:	mov    $0x7,%edx
 29ef6f2:	mov    %rdx,0x278(%rsp)
 29ef6fa:	mov    0x278(%rsp),%rdx
 29ef702:	cmp    $0x1,%edx
 29ef705:	je     29ef79a <wasm[0]::function[1015]::helper::object_read+0xe81a>
 29ef70b:	mov    0xb8(%rsp),%eax
 29ef712:	test   %eax,%eax
 29ef714:	je     29fc2ed <wasm[0]::function[1015]::helper::object_read+0x1b36d>
 29ef71a:	mov    0x80(%rsp),%edi
 29ef721:	mov    0x58(%rsp),%edx
 29ef725:	mov    0x48(%rsp),%esi
 29ef729:	xor    %rcx,%rcx
 29ef72c:	mov    0x1b0(%rsp),%r12
 29ef734:	mov    %r12,(%rsp)
 29ef738:	mov    %edi,0x8(%rsp)
 29ef73c:	mov    0x1b8(%rsp),%rdi
 29ef744:	mov    %edi,0x10(%rsp)
 29ef748:	mov    0x1c0(%rsp),%rdi
 29ef750:	mov    %rdi,0x18(%rsp)
 29ef755:	mov    %edx,0x20(%rsp)
 29ef759:	mov    %esi,0x28(%rsp)
 29ef75d:	mov    %eax,0x30(%rsp)
 29ef761:	mov    0x278(%rsp),%rdx
 29ef769:	mov    0x190(%rsp),%rsi
 29ef771:	mov    0x1a8(%rsp),%r9
 29ef779:	mov    %rsi,%rdi
 29ef77c:	call   29e0f80 <wasm[0]::function[1015]::helper::object_read>
 29ef781:	sub    $0x40,%rsp
 29ef785:	mov    %rax,0x280(%rsp)
 29ef78d:	mov    %rcx,0x288(%rsp)
 29ef795:	jmp    29efc02 <wasm[0]::function[1015]::helper::object_read+0xec82>
 29ef79a:	mov    %rax,%rcx
 29ef79d:	mov    %rax,0x280(%rsp)
 29ef7a5:	xor    %ecx,%eax
 29ef7a7:	mov    %rax,0x280(%rsp)
 29ef7af:	mov    %rcx,%rax
 29ef7b2:	mov    %rcx,0x288(%rsp)
 29ef7ba:	xor    %rax,%rcx
 29ef7bd:	mov    %rcx,0x288(%rsp)
 29ef7c5:	mov    0x280(%rsp),%rdx
 29ef7cd:	mov    0x280(%rsp),%rsi
 29ef7d5:	mov    0x280(%rsp),%rdi
 29ef7dd:	jmp    29efc02 <wasm[0]::function[1015]::helper::object_read+0xec82>
 29ef7e2:	mov    %rax,%rcx
 29ef7e5:	mov    %rax,0x280(%rsp)
 29ef7ed:	xor    %ecx,%eax
 29ef7ef:	mov    %rax,0x280(%rsp)
 29ef7f7:	mov    %rcx,%rax
 29ef7fa:	mov    %rcx,0x288(%rsp)
 29ef802:	xor    %rax,%rcx
 29ef805:	mov    %rcx,0x288(%rsp)
 29ef80d:	mov    0x280(%rsp),%rdx
 29ef815:	mov    0x280(%rsp),%rsi
 29ef81d:	mov    0x280(%rsp),%rdi
 29ef825:	jmp    29efc02 <wasm[0]::function[1015]::helper::object_read+0xec82>
 29ef82a:	mov    %r15,%rax
 29ef82d:	mov    %r15,%rcx
 29ef830:	mov    0x1a8(%rsp),%r9
 29ef838:	mov    0x1b0(%rsp),%r12
 29ef840:	test   %ecx,%eax
 29ef842:	jne    29ef850 <wasm[0]::function[1015]::helper::object_read+0xe8d0>
 29ef848:	xor    %r8d,%r8d
 29ef84b:	jmp    29ef89b <wasm[0]::function[1015]::helper::object_read+0xe91b>
 29ef850:	mov    %r15,%rax
 29ef853:	mov    %r15,%rcx
 29ef856:	test   %ecx,%eax
 29ef858:	je     29fc2ef <wasm[0]::function[1015]::helper::object_read+0x1b36f>
 29ef85e:	mov    0x2e0(%rsp),%rax
 29ef866:	mov    0x28(%rax),%r10
 29ef86a:	mov    %r15,%rax
 29ef86d:	mov    %eax,%r11d
 29ef870:	mov    0x2e0(%rsp),%rax
 29ef878:	mov    %r11,%rdi
 29ef87b:	add    0x20(%rax),%rdi
 29ef87f:	xor    %rax,%rax
 29ef882:	cmp    %r10,%r11
 29ef885:	cmova  %rax,%rdi
 29ef889:	mov    0x10(%rdi),%r11d
 29ef88d:	test   $0x1,%r11d
 29ef894:	setne  %al
 29ef897:	movzbl %al,%r8d
 29ef89b:	test   %r8d,%r8d
 29ef89e:	jne    29efa7b <wasm[0]::function[1015]::helper::object_read+0xeafb>
 29ef8a4:	mov    %rax,%rcx
 29ef8a7:	mov    %rax,0x280(%rsp)
 29ef8af:	xor    %ecx,%eax
 29ef8b1:	mov    %rax,0x280(%rsp)
 29ef8b9:	mov    %rcx,%rax
 29ef8bc:	mov    %rcx,0x288(%rsp)
 29ef8c4:	xor    %rax,%rcx
 29ef8c7:	mov    %rcx,0x288(%rsp)
 29ef8cf:	mov    %r15,%rcx
 29ef8d2:	mov    %r15,%rax
 29ef8d5:	test   %ecx,%eax
 29ef8d7:	jne    29ef8ea <wasm[0]::function[1015]::helper::object_read+0xe96a>
 29ef8dd:	mov    0x280(%rsp),%rdx
 29ef8e5:	jmp    29efa71 <wasm[0]::function[1015]::helper::object_read+0xeaf1>
 29ef8ea:	mov    %r15,%rax
 29ef8ed:	mov    %r15,%rcx
 29ef8f0:	test   %ecx,%eax
 29ef8f2:	je     29fc2f1 <wasm[0]::function[1015]::helper::object_read+0x1b371>
 29ef8f8:	mov    0x2e0(%rsp),%r12
 29ef900:	mov    0x28(%r12),%rax
 29ef905:	mov    0x20(%r12),%rcx
 29ef90a:	mov    %r15,%rdx
 29ef90d:	mov    %edx,%edx
 29ef90f:	add    %rdx,%rcx
 29ef912:	xor    %rsi,%rsi
 29ef915:	cmp    %rax,%rdx
 29ef918:	cmova  %rsi,%rcx
 29ef91c:	mov    0x14(%rcx),%edx
 29ef91f:	test   %edx,%edx
 29ef921:	je     29fc2f3 <wasm[0]::function[1015]::helper::object_read+0x1b373>
 29ef927:	xor    %eax,%eax
 29ef929:	test   $0x1,%edx
 29ef92f:	jne    29ef972 <wasm[0]::function[1015]::helper::object_read+0xe9f2>
 29ef935:	mov    0x2e0(%rsp),%r12
 29ef93d:	mov    0x28(%r12),%rax
 29ef942:	mov    0x20(%r12),%rcx
 29ef947:	mov    %edx,%esi
 29ef949:	lea    0x4(%rcx,%rsi,1),%rcx
 29ef94e:	xor    %rdi,%rdi
 29ef951:	cmp    %rax,%rsi
 29ef954:	cmova  %rdi,%rcx
 29ef958:	mov    (%rcx),%eax
 29ef95a:	mov    0x190(%rsp),%rsi
 29ef962:	mov    0x28(%rsi),%rcx
 29ef966:	cmp    0x120(%rcx),%eax
 29ef96c:	sete   %al
 29ef96f:	movzbl %al,%eax
 29ef972:	test   %eax,%eax
 29ef974:	jne    29ef9db <wasm[0]::function[1015]::helper::object_read+0xea5b>
 29ef97a:	mov    0x190(%rsp),%rsi
 29ef982:	mov    %rsi,%rdi
 29ef985:	call   2a01c00 <wasm[0]::function[1024]::helper::property_value_resolve>
 29ef98a:	test   %eax,%eax
 29ef98c:	je     29fc2f5 <wasm[0]::function[1015]::helper::object_read+0x1b375>
 29ef992:	test   %eax,%eax
 29ef994:	je     29fc2f7 <wasm[0]::function[1015]::helper::object_read+0x1b377>
 29ef99a:	mov    0x2e0(%rsp),%r12
 29ef9a2:	mov    0x28(%r12),%rcx
 29ef9a7:	mov    0x20(%r12),%rsi
 29ef9ac:	mov    %eax,%edx
 29ef9ae:	lea    (%rsi,%rdx,1),%rax
 29ef9b2:	xor    %rsi,%rsi
 29ef9b5:	cmp    %rcx,%rdx
 29ef9b8:	cmova  %rsi,%rax
 29ef9bc:	mov    0x18(%rax),%edi
 29ef9bf:	mov    %rdi,0x280(%rsp)
 29ef9c7:	mov    0x10(%rax),%rcx
 29ef9cb:	mov    %rcx,0x288(%rsp)
 29ef9d3:	mov    0x1c(%rax),%edx
 29ef9d6:	jmp    29efa71 <wasm[0]::function[1015]::helper::object_read+0xeaf1>
 29ef9db:	xor    %eax,%eax
 29ef9dd:	test   $0x1,%edx
 29ef9e3:	jne    29efa26 <wasm[0]::function[1015]::helper::object_read+0xeaa6>
 29ef9e9:	mov    0x2e0(%rsp),%r12
 29ef9f1:	mov    0x28(%r12),%rax
 29ef9f6:	mov    0x20(%r12),%rcx
 29ef9fb:	mov    %edx,%esi
 29ef9fd:	lea    0x4(%rcx,%rsi,1),%rcx
 29efa02:	xor    %rdi,%rdi
 29efa05:	cmp    %rax,%rsi
 29efa08:	cmova  %rdi,%rcx
 29efa0c:	mov    (%rcx),%eax
 29efa0e:	mov    0x190(%rsp),%rsi
 29efa16:	mov    0x28(%rsi),%rcx
 29efa1a:	cmp    0x120(%rcx),%eax
 29efa20:	sete   %al
 29efa23:	movzbl %al,%eax
 29efa26:	test   %eax,%eax
 29efa28:	je     29fc2f9 <wasm[0]::function[1015]::helper::object_read+0x1b379>
 29efa2e:	test   %edx,%edx
 29efa30:	je     29fc2fb <wasm[0]::function[1015]::helper::object_read+0x1b37b>
 29efa36:	mov    0x2e0(%rsp),%r12
 29efa3e:	mov    0x28(%r12),%rcx
 29efa43:	mov    0x20(%r12),%rax
 29efa48:	mov    %edx,%edx
 29efa4a:	add    %rdx,%rax
 29efa4d:	xor    %rsi,%rsi
 29efa50:	cmp    %rcx,%rdx
 29efa53:	cmova  %rsi,%rax
 29efa57:	mov    0x18(%rax),%ecx
 29efa5a:	mov    %rcx,0x280(%rsp)
 29efa62:	mov    0x10(%rax),%rcx
 29efa66:	mov    %rcx,0x288(%rsp)
 29efa6e:	mov    0x1c(%rax),%edx
 29efa71:	xor    %esi,%esi
 29efa73:	mov    %rsi,%rdi
 29efa76:	jmp    29efc02 <wasm[0]::function[1015]::helper::object_read+0xec82>
 29efa7b:	xor    %edx,%edx
 29efa7d:	xor    %rcx,%rcx
 29efa80:	mov    %r15,%rax
 29efa83:	mov    %r15,%rsi
 29efa86:	test   %esi,%eax
 29efa88:	jne    29efa96 <wasm[0]::function[1015]::helper::object_read+0xeb16>
 29efa8e:	mov    %rdx,%r8
 29efa91:	jmp    29efafa <wasm[0]::function[1015]::helper::object_read+0xeb7a>
 29efa96:	mov    %r15,%rax
 29efa99:	mov    %r15,%rcx
 29efa9c:	test   %ecx,%eax
 29efa9e:	je     29fc2fd <wasm[0]::function[1015]::helper::object_read+0x1b37d>
 29efaa4:	mov    0x2e0(%rsp),%rax
 29efaac:	mov    0x28(%rax),%rax
 29efab0:	mov    0x2e0(%rsp),%rcx
 29efab8:	mov    0x20(%rcx),%rcx
 29efabc:	mov    %r15,%rsi
 29efabf:	mov    %esi,%edi
 29efac1:	lea    (%rcx,%rdi,1),%rsi
 29efac5:	xor    %rdx,%rdx
 29efac8:	cmp    %rax,%rdi
 29efacb:	cmova  %rdx,%rsi
 29efacf:	mov    0x18(%rsi),%esi
 29efad2:	test   %esi,%esi
 29efad4:	je     29fc2ff <wasm[0]::function[1015]::helper::object_read+0x1b37f>
 29efada:	test   %esi,%esi
 29efadc:	je     29fc301 <wasm[0]::function[1015]::helper::object_read+0x1b381>
 29efae2:	mov    %esi,%edi
 29efae4:	lea    (%rcx,%rdi,1),%rsi
 29efae8:	cmp    %rax,%rdi
 29efaeb:	cmova  %rdx,%rsi
 29efaef:	mov    0x18(%rsi),%edx
 29efaf2:	mov    0x10(%rsi),%rcx
 29efaf6:	mov    0x1c(%rsi),%r8d
 29efafa:	test   %edx,%edx
 29efafc:	je     29efbbf <wasm[0]::function[1015]::helper::object_read+0xec3f>
 29efb02:	mov    0x190(%rsp),%rsi
 29efb0a:	mov    0x9a0(%rsi),%esi
 29efb10:	mov    0x190(%rsp),%rax
 29efb18:	mov    0x8c0(%rax),%edi
 29efb1e:	mov    %edi,0x58(%rsp)
 29efb22:	test   %edi,%edi
 29efb24:	je     29fc303 <wasm[0]::function[1015]::helper::object_read+0x1b383>
 29efb2a:	test   %esi,%esi
 29efb2c:	je     29fc305 <wasm[0]::function[1015]::helper::object_read+0x1b385>
 29efb32:	mov    0xb8(%rsp),%r10d
 29efb3a:	test   %r10d,%r10d
 29efb3d:	je     29fc307 <wasm[0]::function[1015]::helper::object_read+0x1b387>
 29efb43:	mov    0x80(%rsp),%eax
 29efb4a:	mov    0x48(%rsp),%r11d
 29efb4f:	mov    %r12,(%rsp)
 29efb53:	mov    %eax,0x8(%rsp)
 29efb57:	mov    %esi,0x10(%rsp)
 29efb5b:	mov    %edi,0x18(%rsp)
 29efb5f:	mov    %r11d,0x20(%rsp)
 29efb64:	mov    %r10d,0x28(%rsp)
 29efb69:	mov    0x190(%rsp),%rsi
 29efb71:	mov    0x190(%rsp),%rdi
 29efb79:	call   2adef60 <wasm[0]::function[1055]::helper::proxy_call>
 29efb7e:	sub    $0x30,%rsp
 29efb82:	mov    %rax,0x280(%rsp)
 29efb8a:	mov    %rcx,0x288(%rsp)
 29efb92:	mov    0x58(%rsp),%eax
 29efb96:	test   %eax,%eax
 29efb98:	je     29fc309 <wasm[0]::function[1015]::helper::object_read+0x1b389>
 29efb9e:	mov    0x190(%rsp),%rcx
 29efba6:	mov    %eax,0x8c0(%rcx)
 29efbac:	cmp    $0x2,%esi
 29efbaf:	jne    29efc02 <wasm[0]::function[1015]::helper::object_read+0xec82>
 29efbb5:	xor    %esi,%esi
 29efbb7:	mov    %rsi,%rdi
 29efbba:	jmp    29efc02 <wasm[0]::function[1015]::helper::object_read+0xec82>
 29efbbf:	mov    %rax,%rcx
 29efbc2:	mov    %rax,0x280(%rsp)
 29efbca:	xor    %ecx,%eax
 29efbcc:	mov    %rax,0x280(%rsp)
 29efbd4:	mov    %rcx,%rax
 29efbd7:	mov    %rcx,0x288(%rsp)
 29efbdf:	xor    %rax,%rcx
 29efbe2:	mov    %rcx,0x288(%rsp)
 29efbea:	mov    0x280(%rsp),%rdx
 29efbf2:	mov    0x280(%rsp),%rsi
 29efbfa:	mov    0x280(%rsp),%rdi
 29efc02:	mov    %rdx,%rax
 29efc05:	mov    %rdi,0x298(%rsp)
 29efc0d:	jmp    29fa49a <wasm[0]::function[1015]::helper::object_read+0x1951a>
 29efc12:	mov    0x1b0(%rsp),%r12
 29efc1a:	xor    %eax,%eax
 29efc1c:	test   %edx,%edx
 29efc1e:	je     29efc75 <wasm[0]::function[1015]::helper::object_read+0xecf5>
 29efc24:	xor    %eax,%eax
 29efc26:	test   $0x1,%edx
 29efc2c:	jne    29efc75 <wasm[0]::function[1015]::helper::object_read+0xecf5>
 29efc32:	mov    0x2e0(%rsp),%rax
 29efc3a:	mov    0x28(%rax),%rax
 29efc3e:	mov    0x2e0(%rsp),%rcx
 29efc46:	mov    0x20(%rcx),%rcx
 29efc4a:	mov    %edx,%esi
 29efc4c:	lea    0x4(%rcx,%rsi,1),%rcx
 29efc51:	xor    %rdi,%rdi
 29efc54:	cmp    %rax,%rsi
 29efc57:	cmova  %rdi,%rcx
 29efc5b:	mov    (%rcx),%eax
 29efc5d:	mov    0x190(%rsp),%rsi
 29efc65:	mov    0x28(%rsi),%rcx
 29efc69:	cmp    0x1e8(%rcx),%eax
 29efc6f:	sete   %al
 29efc72:	movzbl %al,%eax
 29efc75:	test   %eax,%eax
 29efc77:	je     29fc30b <wasm[0]::function[1015]::helper::object_read+0x1b38b>
 29efc7d:	test   %edx,%edx
 29efc7f:	je     29fc30d <wasm[0]::function[1015]::helper::object_read+0x1b38d>
 29efc85:	test   %edx,%edx
 29efc87:	je     29fc30f <wasm[0]::function[1015]::helper::object_read+0x1b38f>
 29efc8d:	mov    0x2e0(%rsp),%rax
 29efc95:	mov    0x28(%rax),%rax
 29efc99:	mov    0x2e0(%rsp),%rcx
 29efca1:	mov    0x20(%rcx),%rcx
 29efca5:	mov    %edx,%edi
 29efca7:	lea    (%rcx,%rdi,1),%rsi
 29efcab:	xor    %rdx,%rdx
 29efcae:	cmp    %rax,%rdi
 29efcb1:	cmova  %rdx,%rsi
 29efcb5:	mov    0x14(%rsi),%edi
 29efcb8:	test   %edi,%edi
 29efcba:	je     29fc311 <wasm[0]::function[1015]::helper::object_read+0x1b391>
 29efcc0:	test   %edi,%edi
 29efcc2:	je     29fc313 <wasm[0]::function[1015]::helper::object_read+0x1b393>
 29efcc8:	mov    %edi,%r8d
 29efccb:	lea    (%rcx,%r8,1),%rdi
 29efccf:	cmp    %rax,%r8
 29efcd2:	cmova  %rdx,%rdi
 29efcd6:	mov    0x18(%rdi),%r8d
 29efcda:	mov    %r8,0x2b0(%rsp)
 29efce2:	mov    0x10(%rdi),%r8
 29efce6:	mov    %r8,0x2a8(%rsp)
 29efcee:	mov    0x1c(%rdi),%edi
 29efcf1:	mov    %edi,0x58(%rsp)
 29efcf5:	mov    0x18(%rsi),%esi
 29efcf8:	test   %esi,%esi
 29efcfa:	je     29fc315 <wasm[0]::function[1015]::helper::object_read+0x1b395>
 29efd00:	test   %esi,%esi
 29efd02:	je     29fc317 <wasm[0]::function[1015]::helper::object_read+0x1b397>
 29efd08:	mov    %esi,%esi
 29efd0a:	add    %rsi,%rcx
 29efd0d:	cmp    %rax,%rsi
 29efd10:	cmova  %rdx,%rcx
 29efd14:	mov    0x18(%rcx),%ebx
 29efd17:	mov    0x10(%rcx),%r13
 29efd1b:	mov    0x1c(%rcx),%eax
 29efd1e:	mov    %eax,0x80(%rsp)
 29efd25:	cmp    $0x1,%ebx
 29efd28:	je     29fa1ea <wasm[0]::function[1015]::helper::object_read+0x1926a>
 29efd2e:	mov    $0x27b,%edx
 29efd33:	mov    %rdx,0x198(%rsp)
 29efd3b:	mov    0x190(%rsp),%rsi
 29efd43:	mov    0x190(%rsp),%rdi
 29efd4b:	call   2f30600 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 29efd50:	test   %eax,%eax
 29efd52:	je     29fc319 <wasm[0]::function[1015]::helper::object_read+0x1b399>
 29efd58:	mov    0x70(%rsp),%ecx
 29efd5c:	test   %ecx,%ecx
 29efd5e:	je     29fc31b <wasm[0]::function[1015]::helper::object_read+0x1b39b>
 29efd64:	mov    0x80(%rsp),%r8d
 29efd6c:	mov    0x50(%rsp),%edx
 29efd70:	mov    $0x4,%esi
 29efd75:	xor    %rdi,%rdi
 29efd78:	mov    %r13,(%rsp)
 29efd7c:	mov    %r8d,0x8(%rsp)
 29efd81:	mov    %esi,0x10(%rsp)
 29efd85:	mov    %rdi,0x18(%rsp)
 29efd8a:	mov    %eax,0x20(%rsp)
 29efd8e:	mov    %edx,0x28(%rsp)
 29efd92:	mov    %ecx,0x30(%rsp)
 29efd96:	mov    %r13,%rcx
 29efd99:	mov    %rbx,%rdx
 29efd9c:	mov    0x190(%rsp),%rsi
 29efda4:	mov    0x190(%rsp),%rdi
 29efdac:	mov    %rbx,%r9
 29efdaf:	call   29e0f80 <wasm[0]::function[1015]::helper::object_read>
 29efdb4:	sub    $0x40,%rsp
 29efdb8:	mov    %rcx,%r15
 29efdbb:	mov    %edx,0x48(%rsp)
 29efdbf:	cmp    $0x1,%esi
 29efdc2:	je     29fa1c1 <wasm[0]::function[1015]::helper::object_read+0x19241>
 29efdc8:	test   %eax,%eax
 29efdca:	sete   %sil
 29efdce:	cmp    $0x1,%eax
 29efdd1:	mov    %rax,0x2a0(%rsp)
 29efdd9:	sete   %dil
 29efddd:	or     %edi,%esi
 29efddf:	test   %sil,%sil
 29efde2:	jne    29fa128 <wasm[0]::function[1015]::helper::object_read+0x191a8>
 29efde8:	xor    %ecx,%ecx
 29efdea:	test   %edx,%edx
 29efdec:	je     29efe44 <wasm[0]::function[1015]::helper::object_read+0xeec4>
 29efdf2:	xor    %ecx,%ecx
 29efdf4:	test   $0x1,%edx
 29efdfa:	jne    29efe44 <wasm[0]::function[1015]::helper::object_read+0xeec4>
 29efe00:	mov    0x2e0(%rsp),%rax
 29efe08:	mov    0x28(%rax),%rax
 29efe0c:	mov    0x2e0(%rsp),%rcx
 29efe14:	mov    0x20(%rcx),%rsi
 29efe18:	mov    %edx,%ecx
 29efe1a:	lea    0x4(%rsi,%rcx,1),%r10
 29efe1f:	xor    %rsi,%rsi
 29efe22:	cmp    %rax,%rcx
 29efe25:	cmova  %rsi,%r10
 29efe29:	mov    (%r10),%eax
 29efe2c:	mov    0x190(%rsp),%rsi
 29efe34:	mov    0x28(%rsi),%rcx
 29efe38:	cmp    0x1d4(%rcx),%eax
 29efe3e:	sete   %al
 29efe41:	movzbl %al,%ecx
 29efe44:	xor    %eax,%eax
 29efe46:	test   %edx,%edx
 29efe48:	je     29efe9f <wasm[0]::function[1015]::helper::object_read+0xef1f>
 29efe4e:	xor    %eax,%eax
 29efe50:	test   $0x1,%edx
 29efe56:	jne    29efe9f <wasm[0]::function[1015]::helper::object_read+0xef1f>
 29efe5c:	mov    0x2e0(%rsp),%rax
 29efe64:	mov    0x28(%rax),%rax
 29efe68:	mov    0x2e0(%rsp),%rsi
 29efe70:	mov    0x20(%rsi),%rsi
 29efe74:	mov    %edx,%edi
 29efe76:	lea    0x4(%rsi,%rdi,1),%rsi
 29efe7b:	xor    %r8,%r8
 29efe7e:	cmp    %rax,%rdi
 29efe81:	cmova  %r8,%rsi
 29efe85:	mov    (%rsi),%eax
 29efe87:	mov    0x190(%rsp),%rsi
 29efe8f:	mov    0x28(%rsi),%rsi
 29efe93:	cmp    0x1e4(%rsi),%eax
 29efe99:	sete   %al
 29efe9c:	movzbl %al,%eax
 29efe9f:	or     %eax,%ecx
 29efea1:	test   %ecx,%ecx
 29efea3:	jne    29effbd <wasm[0]::function[1015]::helper::object_read+0xf03d>
 29efea9:	xor    %eax,%eax
 29efeab:	test   %edx,%edx
 29efead:	je     29eff04 <wasm[0]::function[1015]::helper::object_read+0xef84>
 29efeb3:	xor    %eax,%eax
 29efeb5:	test   $0x1,%edx
 29efebb:	jne    29eff04 <wasm[0]::function[1015]::helper::object_read+0xef84>
 29efec1:	mov    0x2e0(%rsp),%rsi
 29efec9:	mov    0x28(%rsi),%rax
 29efecd:	mov    0x2e0(%rsp),%rdi
 29efed5:	mov    0x20(%rdi),%rcx
 29efed9:	mov    %edx,%esi
 29efedb:	lea    0x4(%rcx,%rsi,1),%rcx
 29efee0:	xor    %rdi,%rdi
 29efee3:	cmp    %rax,%rsi
 29efee6:	cmova  %rdi,%rcx
 29efeea:	mov    (%rcx),%eax
 29efeec:	mov    0x190(%rsp),%rsi
 29efef4:	mov    0x28(%rsi),%rcx
 29efef8:	cmp    0x1e8(%rcx),%eax
 29efefe:	sete   %al
 29eff01:	movzbl %al,%eax
 29eff04:	test   %eax,%eax
 29eff06:	jne    29eff13 <wasm[0]::function[1015]::helper::object_read+0xef93>
 29eff0c:	xor    %eax,%eax
 29eff0e:	jmp    29effc5 <wasm[0]::function[1015]::helper::object_read+0xf045>
 29eff13:	xor    %eax,%eax
 29eff15:	test   %edx,%edx
 29eff17:	je     29eff6e <wasm[0]::function[1015]::helper::object_read+0xefee>
 29eff1d:	xor    %eax,%eax
 29eff1f:	test   $0x1,%edx
 29eff25:	jne    29eff6e <wasm[0]::function[1015]::helper::object_read+0xefee>
 29eff2b:	mov    0x2e0(%rsp),%rax
 29eff33:	mov    0x28(%rax),%rax
 29eff37:	mov    0x2e0(%rsp),%rcx
 29eff3f:	mov    0x20(%rcx),%rcx
 29eff43:	mov    %edx,%esi
 29eff45:	lea    0x4(%rcx,%rsi,1),%rcx
 29eff4a:	xor    %rdi,%rdi
 29eff4d:	cmp    %rax,%rsi
 29eff50:	cmova  %rdi,%rcx
 29eff54:	mov    (%rcx),%eax
 29eff56:	mov    0x190(%rsp),%rsi
 29eff5e:	mov    0x28(%rsi),%rcx
 29eff62:	cmp    0x1e8(%rcx),%eax
 29eff68:	sete   %al
 29eff6b:	movzbl %al,%eax
 29eff6e:	test   %eax,%eax
 29eff70:	je     29fc31d <wasm[0]::function[1015]::helper::object_read+0x1b39d>
 29eff76:	test   %edx,%edx
 29eff78:	je     29fc31f <wasm[0]::function[1015]::helper::object_read+0x1b39f>
 29eff7e:	test   %edx,%edx
 29eff80:	je     29fc321 <wasm[0]::function[1015]::helper::object_read+0x1b3a1>
 29eff86:	mov    0x2e0(%rsp),%rax
 29eff8e:	mov    0x28(%rax),%rax
 29eff92:	mov    %edx,%edx
 29eff94:	mov    0x2e0(%rsp),%rsi
 29eff9c:	mov    %rdx,%rcx
 29eff9f:	add    0x20(%rsi),%rcx
 29effa3:	xor    %rsi,%rsi
 29effa6:	cmp    %rax,%rdx
 29effa9:	cmova  %rsi,%rcx
 29effad:	mov    0x1c(%rcx),%eax
 29effb0:	test   %eax,%eax
 29effb2:	setne  %al
 29effb5:	movzbl %al,%eax
 29effb8:	jmp    29effc5 <wasm[0]::function[1015]::helper::object_read+0xf045>
 29effbd:	mov    0x278(%rsp),%rax
 29effc5:	test   %eax,%eax
 29effc7:	je     29f9e9e <wasm[0]::function[1015]::helper::object_read+0x18f1e>
 29effcd:	mov    0x190(%rsp),%rsi
 29effd5:	mov    0x20(%rsi),%rcx
 29effd9:	mov    (%rcx),%eax
 29effdb:	mov    %eax,%edx
 29effdd:	mov    $0x20,%esi
 29effe2:	mov    %rsi,0x268(%rsp)
 29effea:	lea    0x20(%rdx),%rsi
 29effee:	mov    0x4(%rcx),%edi
 29efff1:	mov    %rcx,0x270(%rsp)
 29efff9:	cmp    %rdi,%rsi
 29efffc:	ja     29fb134 <wasm[0]::function[1015]::helper::object_read+0x1a1b4>
 29f0002:	lea    0x20(%rax),%esi
 29f0005:	mov    0x270(%rsp),%rcx
 29f000d:	mov    %esi,(%rcx)
 29f000f:	mov    0x2e0(%rsp),%rsi
 29f0017:	mov    0x20(%rsi),%rdi
 29f001b:	lea    (%rdi,%rdx,1),%rsi
 29f001f:	movl   $0xb0000042,(%rdi,%rdx,1)
 29f0026:	mov    0x190(%rsp),%r8
 29f002e:	mov    0x28(%r8),%r8
 29f0032:	mov    0x120(%r8),%r8d
 29f0039:	mov    %r8d,0x4(%rdi,%rdx,1)
 29f003e:	mov    0x268(%rsp),%r8
 29f0046:	mov    %r8d,0x8(%rdi,%rdx,1)
 29f004b:	mov    %eax,0xb8(%rsp)
 29f0052:	mov    0x2a8(%rsp),%rax
 29f005a:	mov    %rax,0x10(%rsi)
 29f005e:	mov    0x2b0(%rsp),%rdx
 29f0066:	mov    %edx,0x18(%rsi)
 29f0069:	mov    0x58(%rsp),%r9d
 29f006e:	mov    %r9d,0x1c(%rsi)
 29f0072:	mov    (%rcx),%eax
 29f0074:	mov    %eax,%r10d
 29f0077:	lea    0x20(%r10),%r11
 29f007b:	mov    0x4(%rcx),%edx
 29f007e:	mov    %rcx,0x270(%rsp)
 29f0086:	cmp    %rdx,%r11
 29f0089:	ja     29fb17e <wasm[0]::function[1015]::helper::object_read+0x1a1fe>
 29f008f:	lea    0x20(%rax),%ecx
 29f0092:	mov    0x270(%rsp),%rdx
 29f009a:	mov    %ecx,(%rdx)
 29f009c:	mov    0x2e0(%rsp),%rdx
 29f00a4:	mov    0x20(%rdx),%rdx
 29f00a8:	lea    (%rdx,%r10,1),%rcx
 29f00ac:	movl   $0xb0000042,(%rdx,%r10,1)
 29f00b4:	mov    0x190(%rsp),%rsi
 29f00bc:	mov    0x28(%rsi),%rsi
 29f00c0:	mov    0x120(%rsi),%esi
 29f00c6:	mov    %esi,0x4(%rdx,%r10,1)
 29f00cb:	mov    0x268(%rsp),%rsi
 29f00d3:	mov    %esi,0x8(%rdx,%r10,1)
 29f00d8:	mov    %eax,0xa8(%rsp)
 29f00df:	mov    0x1c0(%rsp),%r8
 29f00e7:	mov    %r8,0x10(%rcx)
 29f00eb:	mov    0x1b8(%rsp),%rax
 29f00f3:	mov    %eax,0x18(%rcx)
 29f00f6:	mov    0x68(%rsp),%eax
 29f00fa:	mov    %eax,0x1c(%rcx)
 29f00fd:	mov    0x270(%rsp),%rcx
 29f0105:	mov    (%rcx),%eax
 29f0107:	mov    %eax,%edx
 29f0109:	lea    0x20(%rdx),%rcx
 29f010d:	mov    0x270(%rsp),%rsi
 29f0115:	mov    0x4(%rsi),%esi
 29f0118:	cmp    %rsi,%rcx
 29f011b:	ja     29fb1c0 <wasm[0]::function[1015]::helper::object_read+0x1a240>
 29f0121:	lea    0x20(%rax),%ecx
 29f0124:	mov    0x270(%rsp),%rsi
 29f012c:	mov    %ecx,(%rsi)
 29f012e:	mov    0x2e0(%rsp),%rcx
 29f0136:	mov    0x20(%rcx),%rsi
 29f013a:	lea    (%rsi,%rdx,1),%rcx
 29f013e:	movl   $0xb0000042,(%rsi,%rdx,1)
 29f0145:	mov    0x190(%rsp),%r8
 29f014d:	mov    0x28(%r8),%rdi
 29f0151:	mov    0x120(%rdi),%edi
 29f0157:	mov    %edi,0x4(%rsi,%rdx,1)
 29f015b:	mov    0x268(%rsp),%rdi
 29f0163:	mov    %edi,0x8(%rsi,%rdx,1)
 29f0167:	mov    %eax,0xa0(%rsp)
 29f016e:	mov    %r12,0x10(%rcx)
 29f0172:	mov    0x1a8(%rsp),%r9
 29f017a:	mov    %r9d,0x18(%rcx)
 29f017e:	mov    0x60(%rsp),%edx
 29f0182:	mov    %edx,0x1c(%rcx)
 29f0185:	mov    0xb8(%rsp),%ecx
 29f018c:	test   %ecx,%ecx
 29f018e:	je     29fc323 <wasm[0]::function[1015]::helper::object_read+0x1b3a3>
 29f0194:	mov    0xa8(%rsp),%ecx
 29f019b:	test   %ecx,%ecx
 29f019d:	je     29fc325 <wasm[0]::function[1015]::helper::object_read+0x1b3a5>
 29f01a3:	test   %eax,%eax
 29f01a5:	je     29fc327 <wasm[0]::function[1015]::helper::object_read+0x1b3a7>
 29f01ab:	mov    0x270(%rsp),%rcx
 29f01b3:	mov    (%rcx),%eax
 29f01b5:	mov    %eax,%ecx
 29f01b7:	lea    0x20(%rcx),%rdx
 29f01bb:	mov    0x270(%rsp),%rsi
 29f01c3:	mov    0x4(%rsi),%esi
 29f01c6:	cmp    %rsi,%rdx
 29f01c9:	ja     29fb202 <wasm[0]::function[1015]::helper::object_read+0x1a282>
 29f01cf:	lea    0x20(%rax),%edx
 29f01d2:	mov    0x270(%rsp),%rsi
 29f01da:	mov    %edx,(%rsi)
 29f01dc:	mov    0x2e0(%rsp),%r12
 29f01e4:	mov    0x20(%r12),%rsi
 29f01e9:	lea    (%rsi,%rcx,1),%rdx
 29f01ed:	movl   $0xa800000e,(%rsi,%rcx,1)
 29f01f4:	mov    0x190(%rsp),%rdi
 29f01fc:	mov    0x28(%rdi),%rdi
 29f0200:	mov    0x1b4(%rdi),%edi
 29f0206:	mov    %edi,0x4(%rsi,%rcx,1)
 29f020a:	mov    0x268(%rsp),%rdi
 29f0212:	mov    %edi,0x8(%rsi,%rcx,1)
 29f0216:	movl   $0x3,0x10(%rdx)
 29f021d:	test   %eax,%eax
 29f021f:	je     29fc329 <wasm[0]::function[1015]::helper::object_read+0x1b3a9>
 29f0225:	mov    0x2e0(%rsp),%r12
 29f022d:	mov    0x28(%r12),%rcx
 29f0232:	mov    0x20(%r12),%rdx
 29f0237:	mov    %eax,%r8d
 29f023a:	lea    0x10(%rdx,%r8,1),%rdi
 29f023f:	xor    %rsi,%rsi
 29f0242:	cmp    %rcx,%r8
 29f0245:	cmova  %rsi,%rdi
 29f0249:	mov    (%rdi),%r8d
 29f024c:	test   %r8d,%r8d
 29f024f:	je     29fc32b <wasm[0]::function[1015]::helper::object_read+0x1b3ab>
 29f0255:	mov    %r8d,%r9d
 29f0258:	shl    $0x2,%r9
 29f025c:	shr    $0x20,%r9
 29f0260:	test   %r9,%r9
 29f0263:	jne    29fc32d <wasm[0]::function[1015]::helper::object_read+0x1b3ad>
 29f0269:	shl    $0x2,%r8d
 29f026d:	add    $0x14,%r8d
 29f0271:	jb     29fc32f <wasm[0]::function[1015]::helper::object_read+0x1b3af>
 29f0277:	mov    %rax,%r10
 29f027a:	add    %r8d,%r10d
 29f027d:	jb     29fc331 <wasm[0]::function[1015]::helper::object_read+0x1b3b1>
 29f0283:	mov    0xb8(%rsp),%r9d
 29f028b:	mov    %r10d,%r11d
 29f028e:	lea    (%rdx,%r11,1),%r10
 29f0292:	cmp    %rcx,%r11
 29f0295:	cmova  %rsi,%r10
 29f0299:	sub    $0x14,%r8d
 29f029d:	sub    %r8,%r10
 29f02a0:	mov    %r9d,(%r10)
 29f02a3:	mov    (%rdi),%r8d
 29f02a6:	cmp    $0x1,%r8d
 29f02aa:	jbe    29fc333 <wasm[0]::function[1015]::helper::object_read+0x1b3b3>
 29f02b0:	mov    %r8d,%r9d
 29f02b3:	shl    $0x2,%r9
 29f02b7:	shr    $0x20,%r9
 29f02bb:	test   %r9,%r9
 29f02be:	jne    29fc335 <wasm[0]::function[1015]::helper::object_read+0x1b3b5>
 29f02c4:	shl    $0x2,%r8d
 29f02c8:	add    $0x14,%r8d
 29f02cc:	jb     29fc337 <wasm[0]::function[1015]::helper::object_read+0x1b3b7>
 29f02d2:	mov    %rax,%r10
 29f02d5:	add    %r8d,%r10d
 29f02d8:	jb     29fc339 <wasm[0]::function[1015]::helper::object_read+0x1b3b9>
 29f02de:	mov    0xa8(%rsp),%r9d
 29f02e6:	mov    %r10d,%r11d
 29f02e9:	lea    (%rdx,%r11,1),%r10
 29f02ed:	cmp    %rcx,%r11
 29f02f0:	cmova  %rsi,%r10
 29f02f4:	sub    $0x18,%r8d
 29f02f8:	sub    %r8,%r10
 29f02fb:	mov    %r9d,(%r10)
 29f02fe:	mov    (%rdi),%edi
 29f0300:	cmp    $0x2,%edi
 29f0303:	jbe    29fc33b <wasm[0]::function[1015]::helper::object_read+0x1b3bb>
 29f0309:	mov    %edi,%r8d
 29f030c:	shl    $0x2,%r8
 29f0310:	shr    $0x20,%r8
 29f0314:	test   %r8,%r8
 29f0317:	jne    29fc33d <wasm[0]::function[1015]::helper::object_read+0x1b3bd>
 29f031d:	shl    $0x2,%edi
 29f0320:	add    $0x14,%edi
 29f0323:	jb     29fc33f <wasm[0]::function[1015]::helper::object_read+0x1b3bf>
 29f0329:	mov    %rax,%r10
 29f032c:	add    %edi,%r10d
 29f032f:	jb     29fc341 <wasm[0]::function[1015]::helper::object_read+0x1b3c1>
 29f0335:	mov    0xa0(%rsp),%r11d
 29f033d:	mov    %r10d,%r9d
 29f0340:	lea    (%rdx,%r9,1),%r8
 29f0344:	cmp    %rcx,%r9
 29f0347:	cmova  %rsi,%r8
 29f034b:	mov    $0x1c,%r14d
 29f0351:	sub    $0x1c,%edi
 29f0354:	sub    %rdi,%r8
 29f0357:	mov    %r11d,(%r8)
 29f035a:	mov    0x190(%rsp),%rsi
 29f0362:	mov    0x8c0(%rsi),%ecx
 29f0368:	mov    %ecx,0xa0(%rsp)
 29f036f:	test   %ecx,%ecx
 29f0371:	je     29fc343 <wasm[0]::function[1015]::helper::object_read+0x1b3c3>
 29f0377:	test   %eax,%eax
 29f0379:	je     29fc345 <wasm[0]::function[1015]::helper::object_read+0x1b3c5>
 29f037f:	mov    0x70(%rsp),%edx
 29f0383:	test   %edx,%edx
 29f0385:	je     29fc347 <wasm[0]::function[1015]::helper::object_read+0x1b3c7>
 29f038b:	mov    0x48(%rsp),%r8d
 29f0390:	mov    0x80(%rsp),%edi
 29f0397:	mov    0x50(%rsp),%esi
 29f039b:	mov    %r13,(%rsp)
 29f039f:	mov    %edi,0x8(%rsp)
 29f03a3:	mov    %eax,0x10(%rsp)
 29f03a7:	mov    %ecx,0x18(%rsp)
 29f03ab:	mov    %esi,0x20(%rsp)
 29f03af:	mov    %edx,0x28(%rsp)
 29f03b3:	mov    %r15,%rcx
 29f03b6:	mov    0x2a0(%rsp),%rdx
 29f03be:	mov    %rbx,%r9
 29f03c1:	mov    0x190(%rsp),%rsi
 29f03c9:	mov    0x190(%rsp),%rdi
 29f03d1:	call   2adef60 <wasm[0]::function[1055]::helper::proxy_call>
 29f03d6:	sub    $0x30,%rsp
 29f03da:	mov    %rax,0x280(%rsp)
 29f03e2:	mov    %rcx,0x288(%rsp)
 29f03ea:	mov    %edx,0x80(%rsp)
 29f03f1:	mov    0xa0(%rsp),%eax
 29f03f8:	test   %eax,%eax
 29f03fa:	je     29fc349 <wasm[0]::function[1015]::helper::object_read+0x1b3c9>
 29f0400:	mov    0x190(%rsp),%rcx
 29f0408:	mov    %eax,0x8c0(%rcx)
 29f040e:	cmp    $0x2,%esi
 29f0411:	jne    29f041c <wasm[0]::function[1015]::helper::object_read+0xf49c>
 29f0417:	xor    %esi,%esi
 29f0419:	mov    %rsi,%rdi
 29f041c:	cmp    $0x1,%esi
 29f041f:	je     29f9e87 <wasm[0]::function[1015]::helper::object_read+0x18f07>
 29f0425:	xor    %eax,%eax
 29f0427:	movl   $0x0,0xa0(%rsp)
 29f0432:	mov    0x58(%rsp),%edx
 29f0436:	test   %edx,%edx
 29f0438:	je     29f0489 <wasm[0]::function[1015]::helper::object_read+0xf509>
 29f043e:	xor    %eax,%eax
 29f0440:	test   $0x1,%edx
 29f0446:	jne    29f0489 <wasm[0]::function[1015]::helper::object_read+0xf509>
 29f044c:	mov    0x2e0(%rsp),%r12
 29f0454:	mov    0x28(%r12),%rax
 29f0459:	mov    0x20(%r12),%rcx
 29f045e:	mov    %edx,%esi
 29f0460:	lea    0x4(%rcx,%rsi,1),%rcx
 29f0465:	xor    %rdi,%rdi
 29f0468:	cmp    %rax,%rsi
 29f046b:	cmova  %rdi,%rcx
 29f046f:	mov    (%rcx),%eax
 29f0471:	mov    0x190(%rsp),%rsi
 29f0479:	mov    0x28(%rsi),%rcx
 29f047d:	cmp    0x138(%rcx),%eax
 29f0483:	sete   %al
 29f0486:	movzbl %al,%eax
 29f0489:	test   %eax,%eax
 29f048b:	jne    29f8c4f <wasm[0]::function[1015]::helper::object_read+0x17ccf>
 29f0491:	xor    %eax,%eax
 29f0493:	test   %edx,%edx
 29f0495:	je     29f04e6 <wasm[0]::function[1015]::helper::object_read+0xf566>
 29f049b:	xor    %eax,%eax
 29f049d:	test   $0x1,%edx
 29f04a3:	jne    29f04e6 <wasm[0]::function[1015]::helper::object_read+0xf566>
 29f04a9:	mov    0x2e0(%rsp),%r12
 29f04b1:	mov    0x28(%r12),%rax
 29f04b6:	mov    0x20(%r12),%rcx
 29f04bb:	mov    %edx,%esi
 29f04bd:	lea    0x4(%rcx,%rsi,1),%rcx
 29f04c2:	xor    %rdi,%rdi
 29f04c5:	cmp    %rax,%rsi
 29f04c8:	cmova  %rdi,%rcx
 29f04cc:	mov    (%rcx),%eax
 29f04ce:	mov    0x190(%rsp),%rsi
 29f04d6:	mov    0x28(%rsi),%rcx
 29f04da:	cmp    0x254(%rcx),%eax
 29f04e0:	sete   %al
 29f04e3:	movzbl %al,%eax
 29f04e6:	test   %eax,%eax
 29f04e8:	jne    29f6884 <wasm[0]::function[1015]::helper::object_read+0x15904>
 29f04ee:	mov    0x50(%rsp),%eax
 29f04f2:	mov    0x68(%rsp),%esi
 29f04f6:	mov    0x70(%rsp),%edi
 29f04fa:	mov    0x80(%rsp),%r8d
 29f0502:	xor    %ecx,%ecx
 29f0504:	mov    %rax,%r9
 29f0507:	mov    %rcx,%r10
 29f050a:	mov    %rcx,%r11
 29f050d:	mov    %eax,0x78(%rsp)
 29f0511:	mov    %ecx,0x110(%rsp)
 29f0518:	mov    %r10d,0xd8(%rsp)
 29f0520:	mov    %edx,0xc8(%rsp)
 29f0527:	mov    %esi,0x100(%rsp)
 29f052e:	mov    %r9d,0xc0(%rsp)
 29f0536:	mov    %edi,0x88(%rsp)
 29f053d:	mov    %r8d,0xb8(%rsp)
 29f0545:	mov    %r11d,0xa8(%rsp)
 29f054d:	mov    0x2e8(%rsp),%r13
 29f0555:	mov    0x0(%r13),%rdx
 29f0559:	mov    0x228(%rsp),%rax
 29f0561:	cmp    %rax,%rdx
 29f0564:	jae    29fb245 <wasm[0]::function[1015]::helper::object_read+0x1a2c5>
 29f056a:	mov    0x78(%rsp),%r9d
 29f056f:	mov    0x110(%rsp),%ecx
 29f0576:	test   %r9d,%r9d
 29f0579:	je     29f0623 <wasm[0]::function[1015]::helper::object_read+0xf6a3>
 29f057f:	mov    0x78(%rsp),%ecx
 29f0583:	test   %ecx,%ecx
 29f0585:	je     29fc34b <wasm[0]::function[1015]::helper::object_read+0x1b3cb>
 29f058b:	mov    0x2e0(%rsp),%r12
 29f0593:	mov    0x28(%r12),%rax
 29f0598:	mov    0x20(%r12),%rdx
 29f059d:	mov    %ecx,%ecx
 29f059f:	lea    (%rdx,%rcx,1),%r11
 29f05a3:	xor    %rdx,%rdx
 29f05a6:	cmp    %rax,%rcx
 29f05a9:	cmova  %rdx,%r11
 29f05ad:	mov    0x10(%r11),%ecx
 29f05b1:	test   %ecx,%ecx
 29f05b3:	jne    29f0623 <wasm[0]::function[1015]::helper::object_read+0xf6a3>
 29f05b9:	mov    0x78(%rsp),%edx
 29f05bd:	test   %edx,%edx
 29f05bf:	je     29fc34d <wasm[0]::function[1015]::helper::object_read+0x1b3cd>
 29f05c5:	mov    0x2e0(%rsp),%r12
 29f05cd:	mov    0x28(%r12),%rax
 29f05d2:	mov    %edx,%esi
 29f05d4:	mov    %rsi,%rdx
 29f05d7:	add    0x20(%r12),%rdx
 29f05dc:	xor    %rdi,%rdi
 29f05df:	cmp    %rax,%rsi
 29f05e2:	cmova  %rdi,%rdx
 29f05e6:	mov    0x1c(%rdx),%eax
 29f05e9:	mov    0xd8(%rsp),%r10d
 29f05f1:	mov    0xc8(%rsp),%edx
 29f05f8:	mov    0x100(%rsp),%esi
 29f05ff:	mov    0xc0(%rsp),%r9d
 29f0607:	mov    0x88(%rsp),%edi
 29f060e:	mov    0xb8(%rsp),%r8d
 29f0616:	mov    0xa8(%rsp),%r11d
 29f061e:	jmp    29f050d <wasm[0]::function[1015]::helper::object_read+0xf58d>
 29f0623:	test   %ecx,%ecx
 29f0625:	jne    29f0641 <wasm[0]::function[1015]::helper::object_read+0xf6c1>
 29f062b:	mov    0x190(%rsp),%rsi
 29f0633:	mov    0x8c0(%rsi),%ecx
 29f0639:	test   %ecx,%ecx
 29f063b:	je     29fc34f <wasm[0]::function[1015]::helper::object_read+0x1b3cf>
 29f0641:	mov    %ecx,0x78(%rsp)
 29f0645:	test   %ecx,%ecx
 29f0647:	je     29fc351 <wasm[0]::function[1015]::helper::object_read+0x1b3d1>
 29f064d:	test   %ecx,%ecx
 29f064f:	je     29fc353 <wasm[0]::function[1015]::helper::object_read+0x1b3d3>
 29f0655:	mov    0x2e0(%rsp),%r12
 29f065d:	mov    0x28(%r12),%rax
 29f0662:	mov    0x20(%r12),%rdx
 29f0667:	mov    %ecx,%edi
 29f0669:	lea    (%rdx,%rdi,1),%rsi
 29f066d:	xor    %rcx,%rcx
 29f0670:	cmp    %rax,%rdi
 29f0673:	cmova  %rcx,%rsi
 29f0677:	mov    0x2c(%rsi),%esi
 29f067a:	test   %esi,%esi
 29f067c:	je     29fc355 <wasm[0]::function[1015]::helper::object_read+0x1b3d5>
 29f0682:	test   %esi,%esi
 29f0684:	je     29fc357 <wasm[0]::function[1015]::helper::object_read+0x1b3d7>
 29f068a:	mov    %esi,%r8d
 29f068d:	lea    0x10(%rdx,%r8,1),%rdi
 29f0692:	cmp    %rax,%r8
 29f0695:	cmova  %rcx,%rdi
 29f0699:	mov    (%rdi),%edi
 29f069b:	cmp    $0xd,%edi
 29f069e:	jbe    29fc359 <wasm[0]::function[1015]::helper::object_read+0x1b3d9>
 29f06a4:	mov    %edi,%r8d
 29f06a7:	shl    $0x2,%r8
 29f06ab:	shr    $0x20,%r8
 29f06af:	test   %r8,%r8
 29f06b2:	jne    29fc35b <wasm[0]::function[1015]::helper::object_read+0x1b3db>
 29f06b8:	shl    $0x2,%edi
 29f06bb:	add    $0x14,%edi
 29f06be:	jb     29fc35d <wasm[0]::function[1015]::helper::object_read+0x1b3dd>
 29f06c4:	add    %edi,%esi
 29f06c6:	jb     29fc35f <wasm[0]::function[1015]::helper::object_read+0x1b3df>
 29f06cc:	mov    %esi,%r8d
 29f06cf:	lea    (%rdx,%r8,1),%rsi
 29f06d3:	cmp    %rax,%r8
 29f06d6:	cmova  %rcx,%rsi
 29f06da:	sub    $0x48,%edi
 29f06dd:	sub    %rdi,%rsi
 29f06e0:	mov    (%rsi),%esi
 29f06e2:	test   %esi,%esi
 29f06e4:	je     29fc361 <wasm[0]::function[1015]::helper::object_read+0x1b3e1>
 29f06ea:	test   %esi,%esi
 29f06ec:	je     29fc363 <wasm[0]::function[1015]::helper::object_read+0x1b3e3>
 29f06f2:	mov    %esi,%esi
 29f06f4:	add    %rsi,%rdx
 29f06f7:	cmp    %rax,%rsi
 29f06fa:	cmova  %rcx,%rdx
 29f06fe:	mov    0x18(%rdx),%ecx
 29f0701:	mov    0x10(%rdx),%rax
 29f0705:	mov    0x1c(%rdx),%eax
 29f0708:	mov    %eax,0x110(%rsp)
 29f070f:	cmp    $0x6,%ecx
 29f0712:	sete   %dl
 29f0715:	cmp    $0x7,%ecx
 29f0718:	sete   %sil
 29f071c:	or     %esi,%edx
 29f071e:	mov    $0x8,%ebx
 29f0723:	cmp    $0x8,%ecx
 29f0726:	sete   %sil
 29f072a:	or     %esi,%edx
 29f072c:	cmp    $0x9,%ecx
 29f072f:	sete   %cl
 29f0732:	or     %ecx,%edx
 29f0734:	movzbl %dl,%ecx
 29f0737:	test   %ecx,%ecx
 29f0739:	je     29fc365 <wasm[0]::function[1015]::helper::object_read+0x1b3e5>
 29f073f:	xor    %ecx,%ecx
 29f0741:	test   %eax,%eax
 29f0743:	je     29f0795 <wasm[0]::function[1015]::helper::object_read+0xf815>
 29f0749:	xor    %ecx,%ecx
 29f074b:	test   $0x1,%eax
 29f0750:	jne    29f0795 <wasm[0]::function[1015]::helper::object_read+0xf815>
 29f0756:	mov    0x2e0(%rsp),%r12
 29f075e:	mov    0x28(%r12),%rdx
 29f0763:	mov    0x20(%r12),%rdi
 29f0768:	mov    %eax,%esi
 29f076a:	lea    0x4(%rdi,%rsi,1),%rcx
 29f076f:	xor    %rdi,%rdi
 29f0772:	cmp    %rdx,%rsi
 29f0775:	cmova  %rdi,%rcx
 29f0779:	mov    (%rcx),%esi
 29f077b:	mov    0x190(%rsp),%rdi
 29f0783:	mov    0x28(%rdi),%rdi
 29f0787:	cmp    0x1d4(%rdi),%esi
 29f078d:	sete   %sil
 29f0791:	movzbl %sil,%ecx
 29f0795:	test   %ecx,%ecx
 29f0797:	je     29fc367 <wasm[0]::function[1015]::helper::object_read+0x1b3e7>
 29f079d:	test   %eax,%eax
 29f079f:	je     29fc369 <wasm[0]::function[1015]::helper::object_read+0x1b3e9>
 29f07a5:	movl   $0x0,0x128(%rsp)
 29f07b0:	movl   $0x0,0x138(%rsp)
 29f07bb:	movl   $0x0,0x118(%rsp)
 29f07c6:	movl   $0x0,0x90(%rsp)
 29f07d1:	movl   $0x0,0xe0(%rsp)
 29f07dc:	mov    $0x105,%edx
 29f07e1:	mov    0x190(%rsp),%rsi
 29f07e9:	mov    0x190(%rsp),%rdi
 29f07f1:	call   2f30600 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 29f07f6:	test   %eax,%eax
 29f07f8:	je     29fc36b <wasm[0]::function[1015]::helper::object_read+0x1b3eb>
 29f07fe:	mov    0x110(%rsp),%r8d
 29f0806:	xor    %rcx,%rcx
 29f0809:	movabs $0x4000000000000000,%rdx
 29f0813:	mov    %rdx,(%rsp)
 29f0817:	mov    0x278(%rsp),%rdx
 29f081f:	mov    %edx,0x8(%rsp)
 29f0823:	mov    %rax,%r9
 29f0826:	mov    %rbx,%rdx
 29f0829:	mov    0x190(%rsp),%rsi
 29f0831:	mov    0x190(%rsp),%rdi
 29f0839:	call   2a560c0 <wasm[0]::function[1029]::helper::native_function_allocate>
 29f083e:	sub    $0x10,%rsp
 29f0842:	mov    %eax,0x110(%rsp)
 29f0849:	mov    $0x51,%esi
 29f084e:	mov    0x190(%rsp),%rdi
 29f0856:	call   3018b4e <wasmtime_builtin_ref_func>
 29f085b:	mov    0x270(%rsp),%rcx
 29f0863:	mov    %rax,%r13
 29f0866:	mov    (%rcx),%eax
 29f0868:	mov    %eax,%ecx
 29f086a:	mov    $0x40,%r15d
 29f0870:	lea    0x40(%rcx),%rdx
 29f0874:	mov    0x270(%rsp),%rsi
 29f087c:	mov    0x4(%rsi),%esi
 29f087f:	cmp    %rsi,%rdx
 29f0882:	ja     29fb27d <wasm[0]::function[1015]::helper::object_read+0x1a2fd>
 29f0888:	lea    0x40(%rax),%edx
 29f088b:	mov    0x270(%rsp),%rsi
 29f0893:	mov    %edx,(%rsi)
 29f0895:	mov    0x2e0(%rsp),%r12
 29f089d:	mov    0x20(%r12),%rdx
 29f08a2:	lea    (%rdx,%rcx,1),%r12
 29f08a6:	movl   $0xb0000002,(%rdx,%rcx,1)
 29f08ad:	mov    0x190(%rsp),%rsi
 29f08b5:	mov    0x28(%rsi),%rsi
 29f08b9:	mov    0x1d0(%rsi),%esi
 29f08bf:	mov    %esi,0x4(%rdx,%rcx,1)
 29f08c3:	mov    %r15d,0x8(%rdx,%rcx,1)
 29f08c8:	mov    %eax,0x108(%rsp)
 29f08cf:	movq   $0x51,0x10(%r12)
 29f08d8:	movl   $0x1,0x18(%r12)
 29f08e1:	movl   $0xf,0x1c(%r12)
 29f08ea:	movl   $0xffffffff,0x20(%r12)
 29f08f3:	movl   $0x0,0x24(%r12)
 29f08fc:	movl   $0x0,0x28(%r12)
 29f0905:	mov    %r13,%rsi
 29f0908:	mov    0x190(%rsp),%rdi
 29f0910:	call   3018c43 <wasmtime_builtin_intern_func_ref_for_gc_heap>
 29f0915:	mov    %eax,0x2c(%r12)
 29f091a:	xor    %rsi,%rsi
 29f091d:	mov    %rsi,%r13
 29f0920:	mov    0x190(%rsp),%rdi
 29f0928:	call   3018c43 <wasmtime_builtin_intern_func_ref_for_gc_heap>
 29f092d:	mov    %eax,0x30(%r12)
 29f0932:	mov    %r13,%rsi
 29f0935:	mov    0x190(%rsp),%rdi
 29f093d:	call   3018c43 <wasmtime_builtin_intern_func_ref_for_gc_heap>
 29f0942:	mov    %eax,0x34(%r12)
 29f0947:	mov    %r13,%rsi
 29f094a:	mov    0x190(%rsp),%rdi
 29f0952:	call   3018c43 <wasmtime_builtin_intern_func_ref_for_gc_heap>
 29f0957:	mov    %eax,0x38(%r12)
 29f095c:	mov    %r13,%rsi
 29f095f:	mov    0x190(%rsp),%rdi
 29f0967:	call   3018c43 <wasmtime_builtin_intern_func_ref_for_gc_heap>
 29f096c:	mov    %eax,0x3c(%r12)
 29f0971:	mov    0x190(%rsp),%rsi
 29f0979:	mov    0xa20(%rsi),%eax
 29f097f:	mov    %eax,0x120(%rsp)
 29f0986:	mov    0x78(%rsp),%ecx
 29f098a:	test   %ecx,%ecx
 29f098c:	je     29fc36d <wasm[0]::function[1015]::helper::object_read+0x1b3ed>
 29f0992:	test   %eax,%eax
 29f0994:	je     29fc36f <wasm[0]::function[1015]::helper::object_read+0x1b3ef>
 29f099a:	mov    0x270(%rsp),%rcx
 29f09a2:	mov    (%rcx),%eax
 29f09a4:	mov    %eax,%ecx
 29f09a6:	lea    0x40(%rcx),%rdx
 29f09aa:	mov    0x270(%rsp),%rsi
 29f09b2:	mov    0x4(%rsi),%esi
 29f09b5:	cmp    %rsi,%rdx
 29f09b8:	ja     29fb2c0 <wasm[0]::function[1015]::helper::object_read+0x1a340>
 29f09be:	lea    0x40(%rax),%edx
 29f09c1:	mov    0x270(%rsp),%rsi
 29f09c9:	mov    %edx,(%rsi)
 29f09cb:	mov    0x2e0(%rsp),%r12
 29f09d3:	mov    0x20(%r12),%rdx
 29f09d8:	lea    (%rdx,%rcx,1),%r13
 29f09dc:	movl   $0xb0001ffa,(%rdx,%rcx,1)
 29f09e3:	mov    0x190(%rsp),%rsi
 29f09eb:	mov    0x28(%rsi),%rsi
 29f09ef:	mov    0x1e0(%rsi),%esi
 29f09f5:	mov    %esi,0x4(%rdx,%rcx,1)
 29f09f9:	mov    %r15d,0x8(%rdx,%rcx,1)
 29f09fe:	mov    %eax,0x98(%rsp)
 29f0a05:	mov    0x78(%rsp),%eax
 29f0a09:	mov    %eax,0x10(%r13)
 29f0a0d:	mov    0x128(%rsp),%eax
 29f0a14:	mov    %eax,0x14(%r13)
 29f0a18:	mov    0x138(%rsp),%eax
 29f0a1f:	mov    %eax,0x18(%r13)
 29f0a23:	movl   $0x0,0x1c(%r13)
 29f0a2b:	mov    0x120(%rsp),%eax
 29f0a32:	mov    %eax,0x20(%r13)
 29f0a36:	mov    0x118(%rsp),%eax
 29f0a3d:	mov    %eax,0x24(%r13)
 29f0a41:	mov    0xe0(%rsp),%eax
 29f0a48:	mov    %eax,0x28(%r13)
 29f0a4c:	mov    0xd8(%rsp),%eax
 29f0a53:	mov    %eax,0x2c(%r13)
 29f0a57:	mov    0x90(%rsp),%eax
 29f0a5e:	mov    %eax,0x30(%r13)
 29f0a62:	movl   $0x0,0x34(%r13)
 29f0a6a:	xor    %rsi,%rsi
 29f0a6d:	mov    0x190(%rsp),%rdi
 29f0a75:	call   3018c43 <wasmtime_builtin_intern_func_ref_for_gc_heap>
 29f0a7a:	mov    %eax,0x38(%r13)
 29f0a7e:	mov    $0xea5,%edx
 29f0a83:	mov    0x190(%rsp),%rsi
 29f0a8b:	mov    0x190(%rsp),%rdi
 29f0a93:	call   2f30600 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 29f0a98:	mov    %eax,0x90(%rsp)
 29f0a9f:	mov    0x190(%rsp),%rsi
 29f0aa7:	mov    0xa20(%rsi),%edx
 29f0aad:	mov    %edx,0xd8(%rsp)
 29f0ab4:	mov    0x110(%rsp),%esi
 29f0abb:	test   %esi,%esi
 29f0abd:	je     29fc371 <wasm[0]::function[1015]::helper::object_read+0x1b3f1>
 29f0ac3:	mov    0x108(%rsp),%esi
 29f0aca:	test   %esi,%esi
 29f0acc:	je     29fc373 <wasm[0]::function[1015]::helper::object_read+0x1b3f3>
 29f0ad2:	mov    0x98(%rsp),%edi
 29f0ad9:	test   %edi,%edi
 29f0adb:	je     29fc375 <wasm[0]::function[1015]::helper::object_read+0x1b3f5>
 29f0ae1:	test   %eax,%eax
 29f0ae3:	je     29fc377 <wasm[0]::function[1015]::helper::object_read+0x1b3f7>
 29f0ae9:	test   %edx,%edx
 29f0aeb:	je     29fc379 <wasm[0]::function[1015]::helper::object_read+0x1b3f9>
 29f0af1:	mov    0x270(%rsp),%rcx
 29f0af9:	mov    (%rcx),%eax
 29f0afb:	mov    %eax,%edx
 29f0afd:	mov    $0x50,%esi
 29f0b02:	lea    0x50(%rdx),%rcx
 29f0b06:	mov    0x270(%rsp),%rdi
 29f0b0e:	mov    0x4(%rdi),%edi
 29f0b11:	cmp    %rdi,%rcx
 29f0b14:	ja     29fb304 <wasm[0]::function[1015]::helper::object_read+0x1a384>
 29f0b1a:	lea    0x50(%rax),%ecx
 29f0b1d:	mov    0x270(%rsp),%rdi
 29f0b25:	mov    %ecx,(%rdi)
 29f0b27:	mov    0x2e0(%rsp),%r12
 29f0b2f:	mov    0x20(%r12),%rdi
 29f0b34:	lea    (%rdi,%rdx,1),%rcx
 29f0b38:	movl   $0xb00300fa,(%rdi,%rdx,1)
 29f0b3f:	mov    0x190(%rsp),%r8
 29f0b47:	mov    0x28(%r8),%r8
 29f0b4b:	mov    0x1d4(%r8),%r8d
 29f0b52:	mov    %r8d,0x4(%rdi,%rdx,1)
 29f0b57:	mov    %esi,0x8(%rdi,%rdx,1)
 29f0b5b:	mov    %eax,0xe0(%rsp)
 29f0b62:	mov    0x110(%rsp),%edx
 29f0b69:	mov    %edx,0x10(%rcx)
 29f0b6c:	mov    0x108(%rsp),%edx
 29f0b73:	mov    %edx,0x14(%rcx)
 29f0b76:	mov    0x98(%rsp),%edx
 29f0b7d:	mov    %edx,0x18(%rcx)
 29f0b80:	mov    0x90(%rsp),%esi
 29f0b87:	mov    %esi,0x1c(%rcx)
 29f0b8a:	mov    0xd8(%rsp),%esi
 29f0b91:	mov    %esi,0x20(%rcx)
 29f0b94:	movl   $0x1,0x24(%rcx)
 29f0b9b:	movl   $0x0,0x28(%rcx)
 29f0ba2:	movl   $0x0,0x2c(%rcx)
 29f0ba9:	movl   $0x0,0x30(%rcx)
 29f0bb0:	movl   $0x0,0x34(%rcx)
 29f0bb7:	movl   $0x0,0x38(%rcx)
 29f0bbe:	movl   $0x0,0x3c(%rcx)
 29f0bc5:	movl   $0xffffffff,0x40(%rcx)
 29f0bcc:	movl   $0x0,0x44(%rcx)
 29f0bd3:	movl   $0x0,0x48(%rcx)
 29f0bda:	test   %edx,%edx
 29f0bdc:	je     29fc37b <wasm[0]::function[1015]::helper::object_read+0x1b3fb>
 29f0be2:	test   %eax,%eax
 29f0be4:	je     29fc37d <wasm[0]::function[1015]::helper::object_read+0x1b3fd>
 29f0bea:	test   %edx,%edx
 29f0bec:	je     29fc37f <wasm[0]::function[1015]::helper::object_read+0x1b3ff>
 29f0bf2:	mov    0x2e0(%rsp),%r12
 29f0bfa:	mov    0x28(%r12),%rcx
 29f0bff:	mov    %edx,%esi
 29f0c01:	mov    %rsi,%rdx
 29f0c04:	add    0x20(%r12),%rdx
 29f0c09:	xor    %rdi,%rdi
 29f0c0c:	cmp    %rcx,%rsi
 29f0c0f:	cmova  %rdi,%rdx
 29f0c13:	mov    %eax,0x1c(%rdx)
 29f0c16:	movl   $0x0,0x98(%rsp)
 29f0c21:	mov    0x270(%rsp),%rcx
 29f0c29:	mov    (%rcx),%eax
 29f0c2b:	mov    %eax,%ecx
 29f0c2d:	lea    0x20(%rcx),%rdx
 29f0c31:	mov    0x270(%rsp),%rsi
 29f0c39:	mov    0x4(%rsi),%esi
 29f0c3c:	cmp    %rsi,%rdx
 29f0c3f:	ja     29fb347 <wasm[0]::function[1015]::helper::object_read+0x1a3c7>
 29f0c45:	lea    0x20(%rax),%edx
 29f0c48:	mov    0x270(%rsp),%rsi
 29f0c50:	mov    %edx,(%rsi)
 29f0c52:	mov    0x2e0(%rsp),%r12
 29f0c5a:	mov    0x20(%r12),%rdx
 29f0c5f:	lea    (%rdx,%rcx,1),%rsi
 29f0c63:	movl   $0xb0000042,(%rdx,%rcx,1)
 29f0c6a:	mov    0x190(%rsp),%rdi
 29f0c72:	mov    0x28(%rdi),%rdi
 29f0c76:	mov    0x120(%rdi),%edi
 29f0c7c:	mov    %edi,0x4(%rdx,%rcx,1)
 29f0c80:	mov    0x268(%rsp),%rdi
 29f0c88:	mov    %edi,0x8(%rdx,%rcx,1)
 29f0c8c:	mov    %eax,0xd8(%rsp)
 29f0c93:	mov    0x2a8(%rsp),%rcx
 29f0c9b:	mov    %rcx,0x10(%rsi)
 29f0c9f:	mov    0x2b0(%rsp),%rdx
 29f0ca7:	mov    %edx,0x18(%rsi)
 29f0caa:	mov    0xc8(%rsp),%eax
 29f0cb1:	mov    %eax,0x1c(%rsi)
 29f0cb4:	mov    0x270(%rsp),%rcx
 29f0cbc:	mov    (%rcx),%eax
 29f0cbe:	mov    %eax,%edx
 29f0cc0:	lea    0x20(%rdx),%rcx
 29f0cc4:	mov    0x270(%rsp),%rsi
 29f0ccc:	mov    0x4(%rsi),%esi
 29f0ccf:	cmp    %rsi,%rcx
 29f0cd2:	ja     29fb38a <wasm[0]::function[1015]::helper::object_read+0x1a40a>
 29f0cd8:	lea    0x20(%rax),%ecx
 29f0cdb:	mov    0x270(%rsp),%r10
 29f0ce3:	mov    %ecx,(%r10)
 29f0ce6:	mov    0x2e0(%rsp),%r12
 29f0cee:	mov    0x20(%r12),%rsi
 29f0cf3:	lea    (%rsi,%rdx,1),%rcx
 29f0cf7:	movl   $0xb0000042,(%rsi,%rdx,1)
 29f0cfe:	mov    0x190(%rsp),%rdi
 29f0d06:	mov    0x28(%rdi),%rdi
 29f0d0a:	mov    0x120(%rdi),%edi
 29f0d10:	mov    %edi,0x4(%rsi,%rdx,1)
 29f0d14:	mov    0x268(%rsp),%rdi
 29f0d1c:	mov    %edi,0x8(%rsi,%rdx,1)
 29f0d20:	mov    %eax,0xc8(%rsp)
 29f0d27:	mov    0x1c0(%rsp),%r8
 29f0d2f:	mov    %r8,0x10(%rcx)
 29f0d33:	mov    0x1b8(%rsp),%rsi
 29f0d3b:	mov    %esi,0x18(%rcx)
 29f0d3e:	mov    0x100(%rsp),%esi
 29f0d45:	mov    %esi,0x1c(%rcx)
 29f0d48:	mov    0xd8(%rsp),%edi
 29f0d4f:	test   %edi,%edi
 29f0d51:	je     29fc381 <wasm[0]::function[1015]::helper::object_read+0x1b401>
 29f0d57:	test   %eax,%eax
 29f0d59:	je     29fc383 <wasm[0]::function[1015]::helper::object_read+0x1b403>
 29f0d5f:	mov    0x270(%rsp),%rcx
 29f0d67:	mov    (%rcx),%eax
 29f0d69:	mov    %eax,%r11d
 29f0d6c:	lea    0x20(%r11),%rcx
 29f0d70:	mov    0x270(%rsp),%rdx
 29f0d78:	mov    0x4(%rdx),%edx
 29f0d7b:	cmp    %rdx,%rcx
 29f0d7e:	ja     29fb3c5 <wasm[0]::function[1015]::helper::object_read+0x1a445>
 29f0d84:	lea    0x20(%rax),%ecx
 29f0d87:	mov    0x270(%rsp),%rdx
 29f0d8f:	mov    %ecx,(%rdx)
 29f0d91:	mov    0x2e0(%rsp),%r12
 29f0d99:	mov    0x20(%r12),%rdx
 29f0d9e:	lea    (%rdx,%r11,1),%rcx
 29f0da2:	movl   $0xa800000e,(%rdx,%r11,1)
 29f0daa:	mov    0x190(%rsp),%rsi
 29f0db2:	mov    0x28(%rsi),%rsi
 29f0db6:	mov    0x1b4(%rsi),%esi
 29f0dbc:	mov    %esi,0x4(%rdx,%r11,1)
 29f0dc1:	mov    0x268(%rsp),%rsi
 29f0dc9:	mov    %esi,0x8(%rdx,%r11,1)
 29f0dce:	movl   $0x2,0x10(%rcx)
 29f0dd5:	test   %eax,%eax
 29f0dd7:	je     29fc385 <wasm[0]::function[1015]::helper::object_read+0x1b405>
 29f0ddd:	mov    0x2e0(%rsp),%r12
 29f0de5:	mov    0x28(%r12),%rdx
 29f0dea:	mov    0x20(%r12),%rsi
 29f0def:	mov    %eax,%r8d
 29f0df2:	lea    0x10(%rsi,%r8,1),%rdi
 29f0df7:	xor    %rcx,%rcx
 29f0dfa:	cmp    %rdx,%r8
 29f0dfd:	cmova  %rcx,%rdi
 29f0e01:	mov    (%rdi),%r8d
 29f0e04:	test   %r8d,%r8d
 29f0e07:	je     29fc387 <wasm[0]::function[1015]::helper::object_read+0x1b407>
 29f0e0d:	mov    %r8d,%r9d
 29f0e10:	shl    $0x2,%r9
 29f0e14:	shr    $0x20,%r9
 29f0e18:	test   %r9,%r9
 29f0e1b:	jne    29fc389 <wasm[0]::function[1015]::helper::object_read+0x1b409>
 29f0e21:	shl    $0x2,%r8d
 29f0e25:	add    $0x14,%r8d
 29f0e29:	jb     29fc38b <wasm[0]::function[1015]::helper::object_read+0x1b40b>
 29f0e2f:	mov    %rax,%r10
 29f0e32:	add    %r8d,%r10d
 29f0e35:	jb     29fc38d <wasm[0]::function[1015]::helper::object_read+0x1b40d>
 29f0e3b:	mov    0xd8(%rsp),%r9d
 29f0e43:	mov    %r10d,%r11d
 29f0e46:	lea    (%rsi,%r11,1),%r10
 29f0e4a:	cmp    %rdx,%r11
 29f0e4d:	cmova  %rcx,%r10
 29f0e51:	sub    $0x14,%r8d
 29f0e55:	sub    %r8,%r10
 29f0e58:	mov    %r9d,(%r10)
 29f0e5b:	mov    (%rdi),%edi
 29f0e5d:	cmp    $0x1,%edi
 29f0e60:	jbe    29fc38f <wasm[0]::function[1015]::helper::object_read+0x1b40f>
 29f0e66:	mov    %edi,%r8d
 29f0e69:	shl    $0x2,%r8
 29f0e6d:	shr    $0x20,%r8
 29f0e71:	test   %r8,%r8
 29f0e74:	jne    29fc391 <wasm[0]::function[1015]::helper::object_read+0x1b411>
 29f0e7a:	shl    $0x2,%edi
 29f0e7d:	add    $0x14,%edi
 29f0e80:	jb     29fc393 <wasm[0]::function[1015]::helper::object_read+0x1b413>
 29f0e86:	mov    %rax,%r9
 29f0e89:	add    %edi,%r9d
 29f0e8c:	jb     29fc395 <wasm[0]::function[1015]::helper::object_read+0x1b415>
 29f0e92:	mov    0xc8(%rsp),%r8d
 29f0e9a:	mov    %r9d,%r9d
 29f0e9d:	add    %r9,%rsi
 29f0ea0:	cmp    %rdx,%r9
 29f0ea3:	cmova  %rcx,%rsi
 29f0ea7:	sub    $0x18,%edi
 29f0eaa:	sub    %rdi,%rsi
 29f0ead:	mov    %r8d,(%rsi)
 29f0eb0:	mov    0x190(%rsp),%rsi
 29f0eb8:	mov    0x8c0(%rsi),%edx
 29f0ebe:	mov    %edx,0xc8(%rsp)
 29f0ec5:	xor    %r9d,%r9d
 29f0ec8:	test   %edx,%edx
 29f0eca:	je     29fc397 <wasm[0]::function[1015]::helper::object_read+0x1b417>
 29f0ed0:	test   %eax,%eax
 29f0ed2:	je     29fc399 <wasm[0]::function[1015]::helper::object_read+0x1b419>
 29f0ed8:	mov    0x88(%rsp),%esi
 29f0edf:	test   %esi,%esi
 29f0ee1:	je     29fc39b <wasm[0]::function[1015]::helper::object_read+0x1b41b>
 29f0ee7:	mov    0xe0(%rsp),%r8d
 29f0eef:	mov    0x98(%rsp),%r10d
 29f0ef7:	mov    0xc0(%rsp),%edi
 29f0efe:	mov    %rcx,(%rsp)
 29f0f02:	mov    %r10d,0x8(%rsp)
 29f0f07:	mov    %eax,0x10(%rsp)
 29f0f0b:	mov    %edx,0x18(%rsp)
 29f0f0f:	mov    %edi,0x20(%rsp)
 29f0f13:	mov    %esi,0x28(%rsp)
 29f0f17:	mov    %rbx,%rdx
 29f0f1a:	mov    0x190(%rsp),%rsi
 29f0f22:	mov    0x190(%rsp),%rdi
 29f0f2a:	call   2adef60 <wasm[0]::function[1055]::helper::proxy_call>
 29f0f2f:	sub    $0x30,%rsp
 29f0f33:	mov    %rax,0x258(%rsp)
 29f0f3b:	mov    %rcx,0x260(%rsp)
 29f0f43:	mov    %edx,0xe0(%rsp)
 29f0f4a:	mov    0xc8(%rsp),%eax
 29f0f51:	test   %eax,%eax
 29f0f53:	je     29fc39d <wasm[0]::function[1015]::helper::object_read+0x1b41d>
 29f0f59:	mov    0x190(%rsp),%rcx
 29f0f61:	mov    %eax,0x8c0(%rcx)
 29f0f67:	cmp    $0x2,%esi
 29f0f6a:	jne    29f0f75 <wasm[0]::function[1015]::helper::object_read+0xfff5>
 29f0f70:	xor    %esi,%esi
 29f0f72:	mov    %rsi,%rdi
 29f0f75:	cmp    $0x1,%esi
 29f0f78:	je     29f6837 <wasm[0]::function[1015]::helper::object_read+0x158b7>
 29f0f7e:	mov    0xb8(%rsp),%eax
 29f0f85:	mov    0xa8(%rsp),%ecx
 29f0f8c:	mov    %rcx,%r15
 29f0f8f:	mov    0xc0(%rsp),%ecx
 29f0f96:	mov    0x258(%rsp),%rdx
 29f0f9e:	mov    0x258(%rsp),%rsi
 29f0fa6:	test   %esi,%edx
 29f0fa8:	je     29f901a <wasm[0]::function[1015]::helper::object_read+0x1809a>
 29f0fae:	mov    $0x12b,%edx
 29f0fb3:	mov    0x190(%rsp),%rsi
 29f0fbb:	mov    0x190(%rsp),%rdi
 29f0fc3:	call   2f30600 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 29f0fc8:	mov    %eax,0xa8(%rsp)
 29f0fcf:	xor    %r10d,%r10d
 29f0fd2:	test   %eax,%eax
 29f0fd4:	je     29fc39f <wasm[0]::function[1015]::helper::object_read+0x1b41f>
 29f0fda:	movl   $0x0,0xc8(%rsp)
 29f0fe5:	mov    0xe0(%rsp),%r11d
 29f0fed:	mov    0xb8(%rsp),%esi
 29f0ff4:	mov    0xc0(%rsp),%edx
 29f0ffb:	mov    0x258(%rsp),%rcx
 29f1003:	cmp    $0x6,%ecx
 29f1006:	sete   %cl
 29f1009:	mov    0x258(%rsp),%rax
 29f1011:	cmp    $0x7,%eax
 29f1014:	sete   %dil
 29f1018:	or     %edi,%ecx
 29f101a:	mov    0x258(%rsp),%rdi
 29f1022:	cmp    $0x8,%edi
 29f1025:	sete   %dil
 29f1029:	or     %edi,%ecx
 29f102b:	mov    0x258(%rsp),%rdi
 29f1033:	cmp    $0x9,%edi
 29f1036:	sete   %dil
 29f103a:	or     %edi,%ecx
 29f103c:	xor    %r8,%r8
 29f103f:	test   %cl,%cl
 29f1041:	mov    %rcx,0x250(%rsp)
 29f1049:	jne    29f1067 <wasm[0]::function[1015]::helper::object_read+0x100e7>
 29f104f:	mov    %r10,%r9
 29f1052:	mov    %r8,0x1f0(%rsp)
 29f105a:	mov    %r10,0x1f8(%rsp)
 29f1062:	jmp    29f1b6e <wasm[0]::function[1015]::helper::object_read+0x10bee>
 29f1067:	mov    0xe0(%rsp),%r8d
 29f106f:	mov    0x260(%rsp),%rcx
 29f1077:	mov    0x258(%rsp),%rdx
 29f107f:	mov    0x190(%rsp),%rsi
 29f1087:	mov    0x190(%rsp),%rdi
 29f108f:	call   2a5f680 <wasm[0]::function[1039]::helper::object_header_projection>
 29f1094:	mov    %eax,0x98(%rsp)
 29f109b:	test   %eax,%eax
 29f109d:	je     29fc3a1 <wasm[0]::function[1015]::helper::object_read+0x1b421>
 29f10a3:	test   %eax,%eax
 29f10a5:	je     29fc3a3 <wasm[0]::function[1015]::helper::object_read+0x1b423>
 29f10ab:	mov    0x2e0(%rsp),%r12
 29f10b3:	mov    0x28(%r12),%rcx
 29f10b8:	mov    0x20(%r12),%rdx
 29f10bd:	mov    %eax,%eax
 29f10bf:	lea    (%rdx,%rax,1),%r11
 29f10c3:	xor    %rdx,%rdx
 29f10c6:	cmp    %rcx,%rax
 29f10c9:	cmova  %rdx,%r11
 29f10cd:	mov    0x14(%r11),%eax
 29f10d1:	mov    %eax,0x88(%rsp)
 29f10d8:	test   %eax,%eax
 29f10da:	je     29fc3a5 <wasm[0]::function[1015]::helper::object_read+0x1b425>
 29f10e0:	mov    0x88(%rsp),%ecx
 29f10e7:	xor    %eax,%eax
 29f10e9:	test   $0x1,%ecx
 29f10ef:	jne    29f1149 <wasm[0]::function[1015]::helper::object_read+0x101c9>
 29f10f5:	mov    0x2e0(%rsp),%r12
 29f10fd:	mov    0x28(%r12),%rax
 29f1102:	mov    0x20(%r12),%rsi
 29f1107:	mov    %ecx,%edx
 29f1109:	lea    0x4(%rsi,%rdx,1),%rcx
 29f110e:	xor    %rsi,%rsi
 29f1111:	cmp    %rax,%rdx
 29f1114:	cmova  %rsi,%rcx
 29f1118:	mov    (%rcx),%esi
 29f111a:	mov    0x190(%rsp),%rax
 29f1122:	mov    0x28(%rax),%rax
 29f1126:	mov    0x158(%rax),%edx
 29f112c:	cmp    %edx,%esi
 29f112e:	sete   %al
 29f1131:	movzbl %al,%eax
 29f1134:	cmp    %edx,%esi
 29f1136:	je     29f1149 <wasm[0]::function[1015]::helper::object_read+0x101c9>
 29f113c:	mov    0x190(%rsp),%rdi
 29f1144:	call   3018cd5 <wasmtime_builtin_is_subtype>
 29f1149:	test   %eax,%eax
 29f114b:	jne    29f138a <wasm[0]::function[1015]::helper::object_read+0x1040a>
 29f1151:	mov    0x98(%rsp),%edx
 29f1158:	xor    %ebx,%ebx
 29f115a:	test   %edx,%edx
 29f115c:	je     29fc3a7 <wasm[0]::function[1015]::helper::object_read+0x1b427>
 29f1162:	mov    0xa8(%rsp),%r9d
 29f116a:	mov    $0x4,%ecx
 29f116f:	xor    %r8,%r8
 29f1172:	mov    0x190(%rsp),%rsi
 29f117a:	mov    0x190(%rsp),%rdi
 29f1182:	call   2a58e80 <wasm[0]::function[1032]::helper::ordinary_property_find>
 29f1187:	test   %eax,%eax
 29f1189:	je     29f11c3 <wasm[0]::function[1015]::helper::object_read+0x10243>
 29f118f:	test   %eax,%eax
 29f1191:	je     29fc3a9 <wasm[0]::function[1015]::helper::object_read+0x1b429>
 29f1197:	test   %eax,%eax
 29f1199:	je     29fc3ab <wasm[0]::function[1015]::helper::object_read+0x1b42b>
 29f119f:	mov    0x2e0(%rsp),%r12
 29f11a7:	mov    0x28(%r12),%rcx
 29f11ac:	mov    %eax,%edx
 29f11ae:	mov    %rdx,%rax
 29f11b1:	add    0x20(%r12),%rax
 29f11b6:	xor    %rsi,%rsi
 29f11b9:	cmp    %rcx,%rdx
 29f11bc:	cmova  %rsi,%rax
 29f11c0:	mov    0x14(%rax),%ebx
 29f11c3:	mov    0xc8(%rsp),%r9d
 29f11cb:	xor    %r8,%r8
 29f11ce:	xor    %r10d,%r10d
 29f11d1:	test   %ebx,%ebx
 29f11d3:	je     29f135f <wasm[0]::function[1015]::helper::object_read+0x103df>
 29f11d9:	test   %ebx,%ebx
 29f11db:	je     29fc3ad <wasm[0]::function[1015]::helper::object_read+0x1b42d>
 29f11e1:	mov    0x2e0(%rsp),%r12
 29f11e9:	mov    0x28(%r12),%rcx
 29f11ee:	mov    0x20(%r12),%rax
 29f11f3:	mov    %ebx,%edx
 29f11f5:	add    %rdx,%rax
 29f11f8:	xor    %r8,%r8
 29f11fb:	cmp    %rcx,%rdx
 29f11fe:	cmova  %r8,%rax
 29f1202:	mov    0x10(%rax),%ecx
 29f1205:	mov    0xc8(%rsp),%r9d
 29f120d:	xor    %r10d,%r10d
 29f1210:	test   $0x1,%ecx
 29f1216:	jne    29f135f <wasm[0]::function[1015]::helper::object_read+0x103df>
 29f121c:	mov    0x14(%rax),%edx
 29f121f:	test   %edx,%edx
 29f1221:	je     29fc3af <wasm[0]::function[1015]::helper::object_read+0x1b42f>
 29f1227:	xor    %eax,%eax
 29f1229:	test   $0x1,%edx
 29f122f:	jne    29f1272 <wasm[0]::function[1015]::helper::object_read+0x102f2>
 29f1235:	mov    0x2e0(%rsp),%r12
 29f123d:	mov    0x28(%r12),%rax
 29f1242:	mov    0x20(%r12),%rcx
 29f1247:	mov    %edx,%esi
 29f1249:	lea    0x4(%rcx,%rsi,1),%rcx
 29f124e:	xor    %rdi,%rdi
 29f1251:	cmp    %rax,%rsi
 29f1254:	cmova  %rdi,%rcx
 29f1258:	mov    (%rcx),%eax
 29f125a:	mov    0x190(%rsp),%rsi
 29f1262:	mov    0x28(%rsi),%rcx
 29f1266:	cmp    0x120(%rcx),%eax
 29f126c:	sete   %al
 29f126f:	movzbl %al,%eax
 29f1272:	test   %eax,%eax
 29f1274:	jne    29f12d2 <wasm[0]::function[1015]::helper::object_read+0x10352>
 29f127a:	mov    0x190(%rsp),%rsi
 29f1282:	mov    0x190(%rsp),%rdi
 29f128a:	call   2a01c00 <wasm[0]::function[1024]::helper::property_value_resolve>
 29f128f:	test   %eax,%eax
 29f1291:	je     29fc3b1 <wasm[0]::function[1015]::helper::object_read+0x1b431>
 29f1297:	test   %eax,%eax
 29f1299:	je     29fc3b3 <wasm[0]::function[1015]::helper::object_read+0x1b433>
 29f129f:	mov    0x2e0(%rsp),%r12
 29f12a7:	mov    0x28(%r12),%rsi
 29f12ac:	mov    0x20(%r12),%r8
 29f12b1:	mov    %eax,%edi
 29f12b3:	lea    (%r8,%rdi,1),%rax
 29f12b7:	xor    %r8,%r8
 29f12ba:	cmp    %rsi,%rdi
 29f12bd:	cmova  %r8,%rax
 29f12c1:	mov    0x18(%rax),%r10d
 29f12c5:	mov    0x10(%rax),%r8
 29f12c9:	mov    0x1c(%rax),%r9d
 29f12cd:	jmp    29f135f <wasm[0]::function[1015]::helper::object_read+0x103df>
 29f12d2:	xor    %esi,%esi
 29f12d4:	test   $0x1,%edx
 29f12da:	jne    29f1322 <wasm[0]::function[1015]::helper::object_read+0x103a2>
 29f12e0:	mov    0x2e0(%rsp),%r12
 29f12e8:	mov    0x28(%r12),%r9
 29f12ed:	mov    0x20(%r12),%r11
 29f12f2:	mov    %edx,%r10d
 29f12f5:	lea    0x4(%r11,%r10,1),%rsi
 29f12fa:	xor    %r11,%r11
 29f12fd:	cmp    %r9,%r10
 29f1300:	cmova  %r11,%rsi
 29f1304:	mov    (%rsi),%r10d
 29f1307:	mov    0x190(%rsp),%rsi
 29f130f:	mov    0x28(%rsi),%r11
 29f1313:	cmp    0x120(%r11),%r10d
 29f131a:	sete   %r11b
 29f131e:	movzbl %r11b,%esi
 29f1322:	test   %esi,%esi
 29f1324:	je     29fc3b5 <wasm[0]::function[1015]::helper::object_read+0x1b435>
 29f132a:	test   %edx,%edx
 29f132c:	je     29fc3b7 <wasm[0]::function[1015]::helper::object_read+0x1b437>
 29f1332:	mov    0x2e0(%rsp),%r12
 29f133a:	mov    0x28(%r12),%rcx
 29f133f:	mov    0x20(%r12),%rax
 29f1344:	mov    %edx,%edx
 29f1346:	add    %rdx,%rax
 29f1349:	xor    %rsi,%rsi
 29f134c:	cmp    %rcx,%rdx
 29f134f:	cmova  %rsi,%rax
 29f1353:	mov    0x18(%rax),%r10d
 29f1357:	mov    0x10(%rax),%r8
 29f135b:	mov    0x1c(%rax),%r9d
 29f135f:	mov    0xe0(%rsp),%r11d
 29f1367:	mov    0xb8(%rsp),%esi
 29f136e:	mov    0xc0(%rsp),%edx
 29f1375:	mov    %r8,0x1f0(%rsp)
 29f137d:	mov    %r10,0x1f8(%rsp)
 29f1385:	jmp    29f1b6e <wasm[0]::function[1015]::helper::object_read+0x10bee>
 29f138a:	mov    0x88(%rsp),%eax
 29f1391:	test   %eax,%eax
 29f1393:	je     29fc3b9 <wasm[0]::function[1015]::helper::object_read+0x1b439>
 29f1399:	mov    0x88(%rsp),%ecx
 29f13a0:	xor    %eax,%eax
 29f13a2:	test   $0x1,%ecx
 29f13a8:	jne    29f1402 <wasm[0]::function[1015]::helper::object_read+0x10482>
 29f13ae:	mov    0x2e0(%rsp),%r12
 29f13b6:	mov    0x28(%r12),%rax
 29f13bb:	mov    0x20(%r12),%rsi
 29f13c0:	mov    %ecx,%edx
 29f13c2:	lea    0x4(%rsi,%rdx,1),%rcx
 29f13c7:	xor    %rsi,%rsi
 29f13ca:	cmp    %rax,%rdx
 29f13cd:	cmova  %rsi,%rcx
 29f13d1:	mov    (%rcx),%esi
 29f13d3:	mov    0x190(%rsp),%rax
 29f13db:	mov    0x28(%rax),%rax
 29f13df:	mov    0x158(%rax),%edx
 29f13e5:	cmp    %edx,%esi
 29f13e7:	sete   %al
 29f13ea:	movzbl %al,%eax
 29f13ed:	cmp    %edx,%esi
 29f13ef:	je     29f1402 <wasm[0]::function[1015]::helper::object_read+0x10482>
 29f13f5:	mov    0x190(%rsp),%rdi
 29f13fd:	call   3018cd5 <wasmtime_builtin_is_subtype>
 29f1402:	test   %eax,%eax
 29f1404:	je     29fc3bb <wasm[0]::function[1015]::helper::object_read+0x1b43b>
 29f140a:	mov    0x88(%rsp),%edi
 29f1411:	mov    0xe0(%rsp),%r11d
 29f1419:	mov    0xc8(%rsp),%r9d
 29f1421:	mov    0xb8(%rsp),%esi
 29f1428:	mov    0xc0(%rsp),%edx
 29f142f:	xor    %ecx,%ecx
 29f1431:	mov    %rcx,%r14
 29f1434:	test   %edi,%edi
 29f1436:	je     29fc3bd <wasm[0]::function[1015]::helper::object_read+0x1b43d>
 29f143c:	test   %edi,%edi
 29f143e:	je     29fc3bf <wasm[0]::function[1015]::helper::object_read+0x1b43f>
 29f1444:	mov    0x2e0(%rsp),%r12
 29f144c:	mov    0x28(%r12),%rax
 29f1451:	mov    0x20(%r12),%rcx
 29f1456:	mov    %edi,%ebx
 29f1458:	lea    (%rcx,%rbx,1),%r8
 29f145c:	xor    %r10,%r10
 29f145f:	cmp    %rax,%rbx
 29f1462:	cmova  %r10,%r8
 29f1466:	mov    0x10(%r8),%r8d
 29f146a:	test   %r8d,%r8d
 29f146d:	je     29fc3c1 <wasm[0]::function[1015]::helper::object_read+0x1b441>
 29f1473:	test   %r8d,%r8d
 29f1476:	je     29fc3c3 <wasm[0]::function[1015]::helper::object_read+0x1b443>
 29f147c:	mov    %r8d,%ebx
 29f147f:	lea    (%rcx,%rbx,1),%r8
 29f1483:	cmp    %rax,%rbx
 29f1486:	cmova  %r10,%r8
 29f148a:	mov    0x10(%r8),%r8d
 29f148e:	test   %r8d,%r8d
 29f1491:	je     29fc3c5 <wasm[0]::function[1015]::helper::object_read+0x1b445>
 29f1497:	test   %r8d,%r8d
 29f149a:	je     29fc3c7 <wasm[0]::function[1015]::helper::object_read+0x1b447>
 29f14a0:	mov    %r8d,%ebx
 29f14a3:	lea    0x10(%rcx,%rbx,1),%rcx
 29f14a8:	cmp    %rax,%rbx
 29f14ab:	cmova  %r10,%rcx
 29f14af:	mov    (%rcx),%ebx
 29f14b1:	mov    0xa8(%rsp),%r10d
 29f14b9:	mov    0x190(%rsp),%rax
 29f14c1:	mov    0x28(%rax),%rax
 29f14c5:	mov    0x234(%rax),%r13d
 29f14cc:	mov    %r14,%r15
 29f14cf:	mov    %r8d,0xd8(%rsp)
 29f14d7:	mov    %r10d,0x98(%rsp)
 29f14df:	mov    %edi,0xc0(%rsp)
 29f14e6:	mov    %r11d,0xb8(%rsp)
 29f14ee:	mov    %r9d,0xc8(%rsp)
 29f14f6:	mov    %esi,0x88(%rsp)
 29f14fd:	mov    %edx,0xa8(%rsp)
 29f1504:	mov    0x2e8(%rsp),%rax
 29f150c:	mov    (%rax),%rcx
 29f150f:	mov    0x228(%rsp),%rax
 29f1517:	cmp    %rax,%rcx
 29f151a:	jae    29fb406 <wasm[0]::function[1015]::helper::object_read+0x1a486>
 29f1520:	mov    0xc0(%rsp),%edi
 29f1527:	mov    0xb8(%rsp),%r11d
 29f152f:	mov    0xc8(%rsp),%r9d
 29f1537:	mov    0x88(%rsp),%esi
 29f153e:	mov    0xa8(%rsp),%edx
 29f1545:	mov    %r14,%rcx
 29f1548:	cmp    %ebx,%ecx
 29f154a:	jb     29f1558 <wasm[0]::function[1015]::helper::object_read+0x105d8>
 29f1550:	mov    %r15,%rax
 29f1553:	jmp    29f172c <wasm[0]::function[1015]::helper::object_read+0x107ac>
 29f1558:	mov    0xd8(%rsp),%eax
 29f155f:	test   %eax,%eax
 29f1561:	je     29fc3c9 <wasm[0]::function[1015]::helper::object_read+0x1b449>
 29f1567:	test   %eax,%eax
 29f1569:	je     29fc3cb <wasm[0]::function[1015]::helper::object_read+0x1b44b>
 29f156f:	mov    0x2e0(%rsp),%r12
 29f1577:	mov    0x28(%r12),%r11
 29f157c:	mov    0x20(%r12),%rdx
 29f1581:	mov    %eax,%edi
 29f1583:	lea    0x10(%rdx,%rdi,1),%r8
 29f1588:	xor    %rsi,%rsi
 29f158b:	cmp    %r11,%rdi
 29f158e:	cmova  %rsi,%r8
 29f1592:	mov    (%r8),%edi
 29f1595:	cmp    %edi,%ecx
 29f1597:	jae    29fc3cd <wasm[0]::function[1015]::helper::object_read+0x1b44d>
 29f159d:	mov    %edi,%r8d
 29f15a0:	shl    $0x2,%r8
 29f15a4:	shr    $0x20,%r8
 29f15a8:	test   %r8,%r8
 29f15ab:	jne    29fc3cf <wasm[0]::function[1015]::helper::object_read+0x1b44f>
 29f15b1:	shl    $0x2,%edi
 29f15b4:	add    $0x14,%edi
 29f15b7:	jb     29fc3d1 <wasm[0]::function[1015]::helper::object_read+0x1b451>
 29f15bd:	add    %edi,%eax
 29f15bf:	jb     29fc3d3 <wasm[0]::function[1015]::helper::object_read+0x1b453>
 29f15c5:	mov    %eax,%r8d
 29f15c8:	lea    (%rdx,%r8,1),%rax
 29f15cc:	cmp    %r11,%r8
 29f15cf:	cmova  %rsi,%rax
 29f15d3:	mov    %rcx,%rdx
 29f15d6:	shl    $0x2,%edx
 29f15d9:	mov    %rcx,%r14
 29f15dc:	lea    0x14(%rdx),%ecx
 29f15df:	sub    %ecx,%edi
 29f15e1:	sub    %rdi,%rax
 29f15e4:	mov    (%rax),%edx
 29f15e6:	test   %edx,%edx
 29f15e8:	je     29fc3d5 <wasm[0]::function[1015]::helper::object_read+0x1b455>
 29f15ee:	mov    0x98(%rsp),%eax
 29f15f5:	cmp    %eax,%edx
 29f15f7:	je     29f16cb <wasm[0]::function[1015]::helper::object_read+0x1074b>
 29f15fd:	xor    %ecx,%ecx
 29f15ff:	test   %edx,%edx
 29f1601:	je     29f1643 <wasm[0]::function[1015]::helper::object_read+0x106c3>
 29f1607:	xor    %ecx,%ecx
 29f1609:	test   $0x1,%edx
 29f160f:	jne    29f1643 <wasm[0]::function[1015]::helper::object_read+0x106c3>
 29f1615:	mov    0x2e0(%rsp),%r12
 29f161d:	mov    0x28(%r12),%rcx
 29f1622:	mov    0x20(%r12),%rsi
 29f1627:	mov    %edx,%edi
 29f1629:	lea    0x4(%rsi,%rdi,1),%rsi
 29f162e:	xor    %r8,%r8
 29f1631:	cmp    %rcx,%rdi
 29f1634:	cmova  %r8,%rsi
 29f1638:	mov    (%rsi),%ecx
 29f163a:	cmp    %r13d,%ecx
 29f163d:	sete   %cl
 29f1640:	movzbl %cl,%ecx
 29f1643:	test   %ecx,%ecx
 29f1645:	je     29fc3d7 <wasm[0]::function[1015]::helper::object_read+0x1b457>
 29f164b:	xor    %ecx,%ecx
 29f164d:	test   %eax,%eax
 29f164f:	je     29f1697 <wasm[0]::function[1015]::helper::object_read+0x10717>
 29f1655:	mov    0x98(%rsp),%eax
 29f165c:	xor    %ecx,%ecx
 29f165e:	test   $0x1,%eax
 29f1663:	jne    29f1697 <wasm[0]::function[1015]::helper::object_read+0x10717>
 29f1669:	mov    0x2e0(%rsp),%r12
 29f1671:	mov    0x28(%r12),%rcx
 29f1676:	mov    0x20(%r12),%rdi
 29f167b:	mov    %eax,%esi
 29f167d:	lea    0x4(%rdi,%rsi,1),%rax
 29f1682:	xor    %rdi,%rdi
 29f1685:	cmp    %rcx,%rsi
 29f1688:	cmova  %rdi,%rax
 29f168c:	mov    (%rax),%eax
 29f168e:	cmp    %r13d,%eax
 29f1691:	sete   %al
 29f1694:	movzbl %al,%ecx
 29f1697:	test   %ecx,%ecx
 29f1699:	je     29fc3d9 <wasm[0]::function[1015]::helper::object_read+0x1b459>
 29f169f:	mov    0x98(%rsp),%ecx
 29f16a6:	xor    %r8d,%r8d
 29f16a9:	test   %ecx,%ecx
 29f16ab:	je     29fc3db <wasm[0]::function[1015]::helper::object_read+0x1b45b>
 29f16b1:	mov    0x190(%rsp),%rsi
 29f16b9:	mov    0x190(%rsp),%rdi
 29f16c1:	call   2ae5540 <wasm[0]::function[1057]::helper::string_equality>
 29f16c6:	jmp    29f16d3 <wasm[0]::function[1015]::helper::object_read+0x10753>
 29f16cb:	mov    0x278(%rsp),%rax
 29f16d3:	mov    0xd8(%rsp),%r8d
 29f16db:	mov    0x98(%rsp),%r10d
 29f16e3:	mov    0xc0(%rsp),%edi
 29f16ea:	mov    0xb8(%rsp),%r11d
 29f16f2:	mov    0xc8(%rsp),%r9d
 29f16fa:	mov    0x88(%rsp),%esi
 29f1701:	mov    0xa8(%rsp),%edx
 29f1708:	test   %eax,%eax
 29f170a:	je     29f1718 <wasm[0]::function[1015]::helper::object_read+0x10798>
 29f1710:	mov    %r14,%rcx
 29f1713:	jmp    29f172c <wasm[0]::function[1015]::helper::object_read+0x107ac>
 29f1718:	mov    %r14,%rcx
 29f171b:	add    $0x1,%ecx
 29f1721:	mov    %rcx,%r14
 29f1724:	mov    %rax,%r15
 29f1727:	jmp    29f14cf <wasm[0]::function[1015]::helper::object_read+0x1054f>
 29f172c:	xor    %r8,%r8
 29f172f:	xor    %r10d,%r10d
 29f1732:	test   %eax,%eax
 29f1734:	jne    29f174f <wasm[0]::function[1015]::helper::object_read+0x107cf>
 29f173a:	mov    %r8,0x1f0(%rsp)
 29f1742:	mov    %r10,0x1f8(%rsp)
 29f174a:	jmp    29f1b6e <wasm[0]::function[1015]::helper::object_read+0x10bee>
 29f174f:	test   %edi,%edi
 29f1751:	je     29fc3dd <wasm[0]::function[1015]::helper::object_read+0x1b45d>
 29f1757:	xor    %r8d,%r8d
 29f175a:	test   $0x1,%edi
 29f1760:	jne    29f17a8 <wasm[0]::function[1015]::helper::object_read+0x10828>
 29f1766:	mov    0x2e0(%rsp),%r12
 29f176e:	mov    0x28(%r12),%r8
 29f1773:	mov    0x20(%r12),%r9
 29f1778:	mov    %edi,%r10d
 29f177b:	lea    0x4(%r9,%r10,1),%r9
 29f1780:	xor    %rax,%rax
 29f1783:	cmp    %r8,%r10
 29f1786:	cmova  %rax,%r9
 29f178a:	mov    (%r9),%r8d
 29f178d:	mov    0x190(%rsp),%rax
 29f1795:	mov    0x28(%rax),%r9
 29f1799:	cmp    0x160(%r9),%r8d
 29f17a0:	sete   %r8b
 29f17a4:	movzbl %r8b,%r8d
 29f17a8:	test   %r8d,%r8d
 29f17ab:	jne    29f19ea <wasm[0]::function[1015]::helper::object_read+0x10a6a>
 29f17b1:	xor    %eax,%eax
 29f17b3:	test   $0x1,%edi
 29f17b9:	jne    29f17ff <wasm[0]::function[1015]::helper::object_read+0x1087f>
 29f17bf:	mov    0x2e0(%rsp),%r12
 29f17c7:	mov    0x28(%r12),%rax
 29f17cc:	mov    0x20(%r12),%r8
 29f17d1:	mov    %edi,%r9d
 29f17d4:	lea    0x4(%r8,%r9,1),%r8
 29f17d9:	xor    %r10,%r10
 29f17dc:	cmp    %rax,%r9
 29f17df:	cmova  %r10,%r8
 29f17e3:	mov    (%r8),%eax
 29f17e6:	mov    0x190(%rsp),%r8
 29f17ee:	mov    0x28(%r8),%r8
 29f17f2:	cmp    0x15c(%r8),%eax
 29f17f9:	sete   %al
 29f17fc:	movzbl %al,%eax
 29f17ff:	test   %eax,%eax
 29f1801:	je     29fc3df <wasm[0]::function[1015]::helper::object_read+0x1b45f>
 29f1807:	test   %edi,%edi
 29f1809:	je     29fc3e1 <wasm[0]::function[1015]::helper::object_read+0x1b461>
 29f180f:	mov    0x2e0(%rsp),%r12
 29f1817:	mov    0x28(%r12),%rax
 29f181c:	mov    0x20(%r12),%r10
 29f1821:	mov    %edi,%r9d
 29f1824:	lea    (%r10,%r9,1),%rdi
 29f1828:	xor    %r8,%r8
 29f182b:	cmp    %rax,%r9
 29f182e:	cmova  %r8,%rdi
 29f1832:	mov    0x14(%rdi),%r13d
 29f1836:	mov    0x18(%rdi),%r9d
 29f183a:	mov    0x1c(%rdi),%edi
 29f183d:	test   %r13d,%r13d
 29f1840:	je     29fc3e3 <wasm[0]::function[1015]::helper::object_read+0x1b463>
 29f1846:	test   %r13d,%r13d
 29f1849:	je     29fc3e5 <wasm[0]::function[1015]::helper::object_read+0x1b465>
 29f184f:	mov    %r13d,%r12d
 29f1852:	lea    0x10(%r10,%r12,1),%rbx
 29f1857:	cmp    %rax,%r12
 29f185a:	cmova  %r8,%rbx
 29f185e:	mov    (%rbx),%ebx
 29f1860:	cmp    %ebx,%ecx
 29f1862:	jae    29fc3e7 <wasm[0]::function[1015]::helper::object_read+0x1b467>
 29f1868:	mov    %ebx,%r12d
 29f186b:	shr    $0x20,%r12
 29f186f:	test   %r12,%r12
 29f1872:	jne    29fc3e9 <wasm[0]::function[1015]::helper::object_read+0x1b469>
 29f1878:	add    $0x14,%ebx
 29f187b:	jb     29fc3eb <wasm[0]::function[1015]::helper::object_read+0x1b46b>
 29f1881:	add    %ebx,%r13d
 29f1884:	jb     29fc3ed <wasm[0]::function[1015]::helper::object_read+0x1b46d>
 29f188a:	mov    %r13d,%r12d
 29f188d:	add    %r12,%r10
 29f1890:	cmp    %rax,%r12
 29f1893:	cmova  %r8,%r10
 29f1897:	lea    0x14(%rcx),%eax
 29f189a:	sub    %eax,%ebx
 29f189c:	sub    %rbx,%r10
 29f189f:	movzbq (%r10),%r10
 29f18a3:	test   %r9d,%r9d
 29f18a6:	je     29f193c <wasm[0]::function[1015]::helper::object_read+0x109bc>
 29f18ac:	test   %r9d,%r9d
 29f18af:	je     29fc3ef <wasm[0]::function[1015]::helper::object_read+0x1b46f>
 29f18b5:	test   %r9d,%r9d
 29f18b8:	je     29fc3f1 <wasm[0]::function[1015]::helper::object_read+0x1b471>
 29f18be:	mov    0x2e0(%rsp),%r12
 29f18c6:	mov    0x28(%r12),%rax
 29f18cb:	mov    0x20(%r12),%r8
 29f18d0:	mov    %r9d,%r13d
 29f18d3:	lea    0x10(%r8,%r13,1),%r12
 29f18d8:	xor    %rbx,%rbx
 29f18db:	cmp    %rax,%r13
 29f18de:	cmova  %rbx,%r12
 29f18e2:	mov    (%r12),%r12d
 29f18e6:	cmp    %r12d,%ecx
 29f18e9:	jae    29fc3f3 <wasm[0]::function[1015]::helper::object_read+0x1b473>
 29f18ef:	mov    %r12d,%r13d
 29f18f2:	shl    $0x3,%r13
 29f18f6:	shr    $0x20,%r13
 29f18fa:	test   %r13,%r13
 29f18fd:	jne    29fc3f5 <wasm[0]::function[1015]::helper::object_read+0x1b475>
 29f1903:	shl    $0x3,%r12d
 29f1907:	add    $0x18,%r12d
 29f190b:	jb     29fc3f7 <wasm[0]::function[1015]::helper::object_read+0x1b477>
 29f1911:	add    %r12d,%r9d
 29f1914:	jb     29fc3f9 <wasm[0]::function[1015]::helper::object_read+0x1b479>
 29f191a:	mov    %r9d,%r9d
 29f191d:	add    %r9,%r8
 29f1920:	cmp    %rax,%r9
 29f1923:	cmova  %rbx,%r8
 29f1927:	mov    %rcx,%rax
 29f192a:	shl    $0x3,%eax
 29f192d:	add    $0x18,%eax
 29f1933:	sub    %eax,%r12d
 29f1936:	sub    %r12,%r8
 29f1939:	mov    (%r8),%r8
 29f193c:	xor    %r9d,%r9d
 29f193f:	test   %edi,%edi
 29f1941:	je     29f19d1 <wasm[0]::function[1015]::helper::object_read+0x10a51>
 29f1947:	test   %edi,%edi
 29f1949:	je     29fc3fb <wasm[0]::function[1015]::helper::object_read+0x1b47b>
 29f194f:	test   %edi,%edi
 29f1951:	je     29fc3fd <wasm[0]::function[1015]::helper::object_read+0x1b47d>
 29f1957:	mov    0x2e0(%rsp),%r12
 29f195f:	mov    0x28(%r12),%rax
 29f1964:	mov    0x20(%r12),%r9
 29f1969:	mov    %edi,%r13d
 29f196c:	lea    0x10(%r9,%r13,1),%r12
 29f1971:	xor    %rbx,%rbx
 29f1974:	cmp    %rax,%r13
 29f1977:	cmova  %rbx,%r12
 29f197b:	mov    (%r12),%r12d
 29f197f:	cmp    %r12d,%ecx
 29f1982:	jae    29fc3ff <wasm[0]::function[1015]::helper::object_read+0x1b47f>
 29f1988:	mov    %r12d,%r13d
 29f198b:	shl    $0x2,%r13
 29f198f:	shr    $0x20,%r13
 29f1993:	test   %r13,%r13
 29f1996:	jne    29fc401 <wasm[0]::function[1015]::helper::object_read+0x1b481>
 29f199c:	shl    $0x2,%r12d
 29f19a0:	add    $0x14,%r12d
 29f19a4:	jb     29fc403 <wasm[0]::function[1015]::helper::object_read+0x1b483>
 29f19aa:	add    %r12d,%edi
 29f19ad:	jb     29fc405 <wasm[0]::function[1015]::helper::object_read+0x1b485>
 29f19b3:	mov    %edi,%r13d
 29f19b6:	lea    (%r9,%r13,1),%rdi
 29f19ba:	cmp    %rax,%r13
 29f19bd:	cmova  %rbx,%rdi
 29f19c1:	shl    $0x2,%ecx
 29f19c4:	lea    0x14(%rcx),%r9d
 29f19c8:	sub    %r9d,%r12d
 29f19cb:	sub    %r12,%rdi
 29f19ce:	mov    (%rdi),%r9d
 29f19d1:	movzbl %r10b,%r10d
 29f19d5:	mov    %r8,0x1f0(%rsp)
 29f19dd:	mov    %r10,0x1f8(%rsp)
 29f19e5:	jmp    29f1b6e <wasm[0]::function[1015]::helper::object_read+0x10bee>
 29f19ea:	xor    %eax,%eax
 29f19ec:	test   $0x1,%edi
 29f19f2:	jne    29f1a38 <wasm[0]::function[1015]::helper::object_read+0x10ab8>
 29f19f8:	mov    0x2e0(%rsp),%r12
 29f1a00:	mov    0x28(%r12),%r9
 29f1a05:	mov    0x20(%r12),%rax
 29f1a0a:	mov    %edi,%r10d
 29f1a0d:	lea    0x4(%rax,%r10,1),%r8
 29f1a12:	xor    %rax,%rax
 29f1a15:	cmp    %r9,%r10
 29f1a18:	cmova  %rax,%r8
 29f1a1c:	mov    (%r8),%r10d
 29f1a1f:	mov    0x190(%rsp),%rax
 29f1a27:	mov    0x28(%rax),%rax
 29f1a2b:	cmp    0x160(%rax),%r10d
 29f1a32:	sete   %al
 29f1a35:	movzbl %al,%eax
 29f1a38:	test   %eax,%eax
 29f1a3a:	je     29fc407 <wasm[0]::function[1015]::helper::object_read+0x1b487>
 29f1a40:	test   %edi,%edi
 29f1a42:	je     29fc409 <wasm[0]::function[1015]::helper::object_read+0x1b489>
 29f1a48:	mov    0x2e0(%rsp),%r12
 29f1a50:	mov    0x28(%r12),%rax
 29f1a55:	mov    0x20(%r12),%r8
 29f1a5a:	mov    %edi,%edi
 29f1a5c:	lea    (%r8,%rdi,1),%r10
 29f1a60:	xor    %r9,%r9
 29f1a63:	cmp    %rax,%rdi
 29f1a66:	cmova  %r9,%r10
 29f1a6a:	mov    0x10(%r10),%r10d
 29f1a6e:	test   %r10d,%r10d
 29f1a71:	je     29fc40b <wasm[0]::function[1015]::helper::object_read+0x1b48b>
 29f1a77:	test   %r10d,%r10d
 29f1a7a:	je     29fc40d <wasm[0]::function[1015]::helper::object_read+0x1b48d>
 29f1a80:	mov    %r10d,%ebx
 29f1a83:	lea    (%r8,%rbx,1),%r10
 29f1a87:	cmp    %rax,%rbx
 29f1a8a:	cmova  %r9,%r10
 29f1a8e:	mov    0x10(%r10),%r10d
 29f1a92:	test   %r10d,%r10d
 29f1a95:	je     29fc40f <wasm[0]::function[1015]::helper::object_read+0x1b48f>
 29f1a9b:	test   %r10d,%r10d
 29f1a9e:	je     29fc411 <wasm[0]::function[1015]::helper::object_read+0x1b491>
 29f1aa4:	mov    %r10d,%r10d
 29f1aa7:	lea    0x10(%r8,%r10,1),%r8
 29f1aac:	cmp    %rax,%r10
 29f1aaf:	cmova  %r9,%r8
 29f1ab3:	cmp    (%r8),%ecx
 29f1ab6:	setae  %al
 29f1ab9:	cmp    $0x2,%ecx
 29f1abc:	setae  %r8b
 29f1ac0:	or     %r8d,%eax
 29f1ac3:	test   %al,%al
 29f1ac5:	jne    29fc413 <wasm[0]::function[1015]::helper::object_read+0x1b493>
 29f1acb:	mov    0x2e0(%rsp),%r12
 29f1ad3:	mov    0x28(%r12),%r8
 29f1ad8:	mov    %rdi,%rax
 29f1adb:	add    0x20(%r12),%rax
 29f1ae0:	xor    %r9,%r9
 29f1ae3:	cmp    %r8,%rdi
 29f1ae6:	cmova  %r9,%rax
 29f1aea:	mov    0x14(%rax),%r10d
 29f1aee:	test   %ecx,%ecx
 29f1af0:	je     29f1b2a <wasm[0]::function[1015]::helper::object_read+0x10baa>
 29f1af6:	mov    0x2e0(%rsp),%r12
 29f1afe:	mov    0x28(%r12),%r8
 29f1b03:	mov    0x20(%r12),%rax
 29f1b08:	add    %rdi,%rax
 29f1b0b:	xor    %r9,%r9
 29f1b0e:	cmp    %r8,%rdi
 29f1b11:	cmova  %r9,%rax
 29f1b15:	mov    0x20(%rax),%r8
 29f1b19:	mov    0x2c(%rax),%r9d
 29f1b1d:	mov    %r8,0x1f0(%rsp)
 29f1b25:	jmp    29f1b59 <wasm[0]::function[1015]::helper::object_read+0x10bd9>
 29f1b2a:	mov    0x2e0(%rsp),%r12
 29f1b32:	mov    0x28(%r12),%r8
 29f1b37:	mov    0x20(%r12),%rax
 29f1b3c:	add    %rdi,%rax
 29f1b3f:	xor    %r9,%r9
 29f1b42:	cmp    %r8,%rdi
 29f1b45:	cmova  %r9,%rax
 29f1b49:	mov    0x18(%rax),%r8
 29f1b4d:	mov    %r8,0x1f0(%rsp)
 29f1b55:	mov    0x28(%rax),%r9d
 29f1b59:	shl    $0x3,%ecx
 29f1b5c:	shr    %cl,%r10d
 29f1b5f:	and    $0xff,%r10d
 29f1b66:	mov    %r10,0x1f8(%rsp)
 29f1b6e:	mov    %r11d,0xb8(%rsp)
 29f1b76:	mov    %r9d,0xc0(%rsp)
 29f1b7e:	mov    %esi,0x98(%rsp)
 29f1b85:	mov    %edx,0xd8(%rsp)
 29f1b8c:	mov    $0x285,%edx
 29f1b91:	mov    0x190(%rsp),%rsi
 29f1b99:	mov    0x190(%rsp),%rdi
 29f1ba1:	call   2f30600 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 29f1ba6:	mov    %eax,0xc8(%rsp)
 29f1bad:	xor    %r11d,%r11d
 29f1bb0:	test   %eax,%eax
 29f1bb2:	je     29fc415 <wasm[0]::function[1015]::helper::object_read+0x1b495>
 29f1bb8:	movl   $0x0,0x88(%rsp)
 29f1bc3:	mov    0xb8(%rsp),%r14d
 29f1bcb:	mov    0xc0(%rsp),%edi
 29f1bd2:	mov    0x98(%rsp),%edx
 29f1bd9:	mov    0xd8(%rsp),%esi
 29f1be0:	xor    %r9,%r9
 29f1be3:	mov    0x250(%rsp),%rcx
 29f1beb:	test   %cl,%cl
 29f1bed:	jne    29f1c0b <wasm[0]::function[1015]::helper::object_read+0x10c8b>
 29f1bf3:	mov    %r11,%r10
 29f1bf6:	mov    %r11,0x1d0(%rsp)
 29f1bfe:	mov    %r9,0x1d8(%rsp)
 29f1c06:	jmp    29f274a <wasm[0]::function[1015]::helper::object_read+0x117ca>
 29f1c0b:	mov    0xb8(%rsp),%r8d
 29f1c13:	mov    0x260(%rsp),%rcx
 29f1c1b:	mov    0x258(%rsp),%rdx
 29f1c23:	mov    0x190(%rsp),%rsi
 29f1c2b:	mov    0x190(%rsp),%rdi
 29f1c33:	call   2a5f680 <wasm[0]::function[1039]::helper::object_header_projection>
 29f1c38:	mov    %eax,0xa8(%rsp)
 29f1c3f:	test   %eax,%eax
 29f1c41:	je     29fc417 <wasm[0]::function[1015]::helper::object_read+0x1b497>
 29f1c47:	test   %eax,%eax
 29f1c49:	je     29fc419 <wasm[0]::function[1015]::helper::object_read+0x1b499>
 29f1c4f:	mov    0x2e0(%rsp),%r12
 29f1c57:	mov    0x28(%r12),%rcx
 29f1c5c:	mov    0x20(%r12),%rsi
 29f1c61:	mov    %eax,%edx
 29f1c63:	lea    (%rsi,%rdx,1),%rax
 29f1c67:	xor    %rsi,%rsi
 29f1c6a:	cmp    %rcx,%rdx
 29f1c6d:	cmova  %rsi,%rax
 29f1c71:	mov    0x14(%rax),%eax
 29f1c74:	mov    %eax,0x78(%rsp)
 29f1c78:	test   %eax,%eax
 29f1c7a:	je     29fc41b <wasm[0]::function[1015]::helper::object_read+0x1b49b>
 29f1c80:	mov    0x78(%rsp),%ecx
 29f1c84:	xor    %eax,%eax
 29f1c86:	test   $0x1,%ecx
 29f1c8c:	jne    29f1ce8 <wasm[0]::function[1015]::helper::object_read+0x10d68>
 29f1c92:	mov    0x2e0(%rsp),%r12
 29f1c9a:	mov    0x28(%r12),%rsi
 29f1c9f:	mov    0x20(%r12),%r8
 29f1ca4:	mov    %ecx,%edi
 29f1ca6:	lea    0x4(%r8,%rdi,1),%rcx
 29f1cab:	xor    %r8,%r8
 29f1cae:	cmp    %rsi,%rdi
 29f1cb1:	cmova  %r8,%rcx
 29f1cb5:	mov    (%rcx),%esi
 29f1cb7:	mov    0x190(%rsp),%rax
 29f1cbf:	mov    0x28(%rax),%rdi
 29f1cc3:	mov    0x158(%rdi),%edx
 29f1cc9:	cmp    %edx,%esi
 29f1ccb:	sete   %dil
 29f1ccf:	movzbl %dil,%eax
 29f1cd3:	cmp    %edx,%esi
 29f1cd5:	je     29f1ce8 <wasm[0]::function[1015]::helper::object_read+0x10d68>
 29f1cdb:	mov    0x190(%rsp),%rdi
 29f1ce3:	call   3018cd5 <wasmtime_builtin_is_subtype>
 29f1ce8:	test   %eax,%eax
 29f1cea:	jne    29f1f2b <wasm[0]::function[1015]::helper::object_read+0x10fab>
 29f1cf0:	mov    0xa8(%rsp),%edx
 29f1cf7:	xor    %ebx,%ebx
 29f1cf9:	test   %edx,%edx
 29f1cfb:	je     29fc41d <wasm[0]::function[1015]::helper::object_read+0x1b49d>
 29f1d01:	mov    0xc8(%rsp),%r9d
 29f1d09:	mov    $0x4,%ecx
 29f1d0e:	xor    %r8,%r8
 29f1d11:	mov    0x190(%rsp),%rsi
 29f1d19:	mov    0x190(%rsp),%rdi
 29f1d21:	call   2a58e80 <wasm[0]::function[1032]::helper::ordinary_property_find>
 29f1d26:	test   %eax,%eax
 29f1d28:	je     29f1d62 <wasm[0]::function[1015]::helper::object_read+0x10de2>
 29f1d2e:	test   %eax,%eax
 29f1d30:	je     29fc41f <wasm[0]::function[1015]::helper::object_read+0x1b49f>
 29f1d36:	test   %eax,%eax
 29f1d38:	je     29fc421 <wasm[0]::function[1015]::helper::object_read+0x1b4a1>
 29f1d3e:	mov    0x2e0(%rsp),%r12
 29f1d46:	mov    0x28(%r12),%rcx
 29f1d4b:	mov    %eax,%edx
 29f1d4d:	mov    %rdx,%rax
 29f1d50:	add    0x20(%r12),%rax
 29f1d55:	xor    %rsi,%rsi
 29f1d58:	cmp    %rcx,%rdx
 29f1d5b:	cmova  %rsi,%rax
 29f1d5f:	mov    0x14(%rax),%ebx
 29f1d62:	mov    0x88(%rsp),%r10d
 29f1d6a:	xor    %r11d,%r11d
 29f1d6d:	xor    %r9,%r9
 29f1d70:	test   %ebx,%ebx
 29f1d72:	je     29f1ef9 <wasm[0]::function[1015]::helper::object_read+0x10f79>
 29f1d78:	test   %ebx,%ebx
 29f1d7a:	je     29fc423 <wasm[0]::function[1015]::helper::object_read+0x1b4a3>
 29f1d80:	mov    0x2e0(%rsp),%r12
 29f1d88:	mov    0x28(%r12),%rcx
 29f1d8d:	mov    0x20(%r12),%rax
 29f1d92:	mov    %ebx,%edx
 29f1d94:	add    %rdx,%rax
 29f1d97:	xor    %r9,%r9
 29f1d9a:	cmp    %rcx,%rdx
 29f1d9d:	cmova  %r9,%rax
 29f1da1:	mov    0x10(%rax),%ecx
 29f1da4:	mov    0x88(%rsp),%r10d
 29f1dac:	xor    %r11d,%r11d
 29f1daf:	test   $0x1,%ecx
 29f1db5:	jne    29f1ef9 <wasm[0]::function[1015]::helper::object_read+0x10f79>
 29f1dbb:	mov    0x14(%rax),%edx
 29f1dbe:	test   %edx,%edx
 29f1dc0:	je     29fc425 <wasm[0]::function[1015]::helper::object_read+0x1b4a5>
 29f1dc6:	xor    %eax,%eax
 29f1dc8:	test   $0x1,%edx
 29f1dce:	jne    29f1e11 <wasm[0]::function[1015]::helper::object_read+0x10e91>
 29f1dd4:	mov    0x2e0(%rsp),%r12
 29f1ddc:	mov    0x28(%r12),%rax
 29f1de1:	mov    0x20(%r12),%rcx
 29f1de6:	mov    %edx,%esi
 29f1de8:	lea    0x4(%rcx,%rsi,1),%rcx
 29f1ded:	xor    %rdi,%rdi
 29f1df0:	cmp    %rax,%rsi
 29f1df3:	cmova  %rdi,%rcx
 29f1df7:	mov    (%rcx),%eax
 29f1df9:	mov    0x190(%rsp),%rsi
 29f1e01:	mov    0x28(%rsi),%rcx
 29f1e05:	cmp    0x120(%rcx),%eax
 29f1e0b:	sete   %al
 29f1e0e:	movzbl %al,%eax
 29f1e11:	test   %eax,%eax
 29f1e13:	jne    29f1e71 <wasm[0]::function[1015]::helper::object_read+0x10ef1>
 29f1e19:	mov    0x190(%rsp),%rsi
 29f1e21:	mov    0x190(%rsp),%rdi
 29f1e29:	call   2a01c00 <wasm[0]::function[1024]::helper::property_value_resolve>
 29f1e2e:	test   %eax,%eax
 29f1e30:	je     29fc427 <wasm[0]::function[1015]::helper::object_read+0x1b4a7>
 29f1e36:	test   %eax,%eax
 29f1e38:	je     29fc429 <wasm[0]::function[1015]::helper::object_read+0x1b4a9>
 29f1e3e:	mov    0x2e0(%rsp),%r12
 29f1e46:	mov    0x28(%r12),%rcx
 29f1e4b:	mov    0x20(%r12),%rsi
 29f1e50:	mov    %eax,%edx
 29f1e52:	lea    (%rsi,%rdx,1),%rax
 29f1e56:	xor    %rsi,%rsi
 29f1e59:	cmp    %rcx,%rdx
 29f1e5c:	cmova  %rsi,%rax
 29f1e60:	mov    0x18(%rax),%r11d
 29f1e64:	mov    0x10(%rax),%r9
 29f1e68:	mov    0x1c(%rax),%r10d
 29f1e6c:	jmp    29f1ef9 <wasm[0]::function[1015]::helper::object_read+0x10f79>
 29f1e71:	xor    %eax,%eax
 29f1e73:	test   $0x1,%edx
 29f1e79:	jne    29f1ebc <wasm[0]::function[1015]::helper::object_read+0x10f3c>
 29f1e7f:	mov    0x2e0(%rsp),%r12
 29f1e87:	mov    0x28(%r12),%rax
 29f1e8c:	mov    0x20(%r12),%rcx
 29f1e91:	mov    %edx,%esi
 29f1e93:	lea    0x4(%rcx,%rsi,1),%rcx
 29f1e98:	xor    %rdi,%rdi
 29f1e9b:	cmp    %rax,%rsi
 29f1e9e:	cmova  %rdi,%rcx
 29f1ea2:	mov    (%rcx),%eax
 29f1ea4:	mov    0x190(%rsp),%rsi
 29f1eac:	mov    0x28(%rsi),%rcx
 29f1eb0:	cmp    0x120(%rcx),%eax
 29f1eb6:	sete   %al
 29f1eb9:	movzbl %al,%eax
 29f1ebc:	test   %eax,%eax
 29f1ebe:	je     29fc42b <wasm[0]::function[1015]::helper::object_read+0x1b4ab>
 29f1ec4:	test   %edx,%edx
 29f1ec6:	je     29fc42d <wasm[0]::function[1015]::helper::object_read+0x1b4ad>
 29f1ecc:	mov    0x2e0(%rsp),%r12
 29f1ed4:	mov    0x28(%r12),%rcx
 29f1ed9:	mov    0x20(%r12),%rax
 29f1ede:	mov    %edx,%edx
 29f1ee0:	add    %rdx,%rax
 29f1ee3:	xor    %rsi,%rsi
 29f1ee6:	cmp    %rcx,%rdx
 29f1ee9:	cmova  %rsi,%rax
 29f1eed:	mov    0x18(%rax),%r11d
 29f1ef1:	mov    0x10(%rax),%r9
 29f1ef5:	mov    0x1c(%rax),%r10d
 29f1ef9:	mov    0xb8(%rsp),%r14d
 29f1f01:	mov    0xc0(%rsp),%edi
 29f1f08:	mov    0x98(%rsp),%edx
 29f1f0f:	mov    0xd8(%rsp),%esi
 29f1f16:	mov    %r11,0x1d0(%rsp)
 29f1f1e:	mov    %r9,0x1d8(%rsp)
 29f1f26:	jmp    29f274a <wasm[0]::function[1015]::helper::object_read+0x117ca>
 29f1f2b:	mov    0x78(%rsp),%esi
 29f1f2f:	test   %esi,%esi
 29f1f31:	je     29fc42f <wasm[0]::function[1015]::helper::object_read+0x1b4af>
 29f1f37:	mov    0x78(%rsp),%esi
 29f1f3b:	xor    %eax,%eax
 29f1f3d:	test   $0x1,%esi
 29f1f43:	jne    29f1fa1 <wasm[0]::function[1015]::helper::object_read+0x11021>
 29f1f49:	mov    0x2e0(%rsp),%r12
 29f1f51:	mov    0x28(%r12),%r9
 29f1f56:	mov    0x20(%r12),%r11
 29f1f5b:	mov    %esi,%r10d
 29f1f5e:	lea    0x4(%r11,%r10,1),%rsi
 29f1f63:	xor    %r11,%r11
 29f1f66:	cmp    %r9,%r10
 29f1f69:	cmova  %r11,%rsi
 29f1f6d:	mov    (%rsi),%esi
 29f1f6f:	mov    0x190(%rsp),%rax
 29f1f77:	mov    0x28(%rax),%r10
 29f1f7b:	mov    0x158(%r10),%edx
 29f1f82:	cmp    %edx,%esi
 29f1f84:	sete   %r11b
 29f1f88:	movzbl %r11b,%eax
 29f1f8c:	cmp    %edx,%esi
 29f1f8e:	je     29f1fa1 <wasm[0]::function[1015]::helper::object_read+0x11021>
 29f1f94:	mov    0x190(%rsp),%rdi
 29f1f9c:	call   3018cd5 <wasmtime_builtin_is_subtype>
 29f1fa1:	test   %eax,%eax
 29f1fa3:	je     29fc431 <wasm[0]::function[1015]::helper::object_read+0x1b4b1>
 29f1fa9:	mov    0x78(%rsp),%r8d
 29f1fae:	mov    0xb8(%rsp),%r14d
 29f1fb6:	mov    0x88(%rsp),%r10d
 29f1fbe:	mov    0xc0(%rsp),%edi
 29f1fc5:	mov    0x98(%rsp),%edx
 29f1fcc:	mov    0xd8(%rsp),%esi
 29f1fd3:	xor    %ecx,%ecx
 29f1fd5:	mov    %rcx,%r15
 29f1fd8:	test   %r8d,%r8d
 29f1fdb:	je     29fc433 <wasm[0]::function[1015]::helper::object_read+0x1b4b3>
 29f1fe1:	test   %r8d,%r8d
 29f1fe4:	je     29fc435 <wasm[0]::function[1015]::helper::object_read+0x1b4b5>
 29f1fea:	mov    0x2e0(%rsp),%r12
 29f1ff2:	mov    0x28(%r12),%rax
 29f1ff7:	mov    0x20(%r12),%rcx
 29f1ffc:	mov    %r8d,%ebx
 29f1fff:	lea    (%rcx,%rbx,1),%r9
 29f2003:	xor    %r11,%r11
 29f2006:	cmp    %rax,%rbx
 29f2009:	cmova  %r11,%r9
 29f200d:	mov    0x10(%r9),%r9d
 29f2011:	test   %r9d,%r9d
 29f2014:	je     29fc437 <wasm[0]::function[1015]::helper::object_read+0x1b4b7>
 29f201a:	test   %r9d,%r9d
 29f201d:	je     29fc439 <wasm[0]::function[1015]::helper::object_read+0x1b4b9>
 29f2023:	mov    %r9d,%ebx
 29f2026:	lea    (%rcx,%rbx,1),%r9
 29f202a:	cmp    %rax,%rbx
 29f202d:	cmova  %r11,%r9
 29f2031:	mov    0x10(%r9),%r9d
 29f2035:	test   %r9d,%r9d
 29f2038:	je     29fc43b <wasm[0]::function[1015]::helper::object_read+0x1b4bb>
 29f203e:	test   %r9d,%r9d
 29f2041:	je     29fc43d <wasm[0]::function[1015]::helper::object_read+0x1b4bd>
 29f2047:	mov    %r9d,%ebx
 29f204a:	lea    0x10(%rcx,%rbx,1),%rcx
 29f204f:	cmp    %rax,%rbx
 29f2052:	cmova  %r11,%rcx
 29f2056:	mov    (%rcx),%ebx
 29f2058:	mov    0xc8(%rsp),%r11d
 29f2060:	mov    0x190(%rsp),%rax
 29f2068:	mov    0x28(%rax),%rax
 29f206c:	mov    0x234(%rax),%r13d
 29f2073:	mov    %r15,0x1c8(%rsp)
 29f207b:	mov    %r9d,0xa8(%rsp)
 29f2083:	mov    %r11d,0xd8(%rsp)
 29f208b:	mov    %r8d,0x98(%rsp)
 29f2093:	mov    %r14d,0xc0(%rsp)
 29f209b:	mov    %r10d,0x88(%rsp)
 29f20a3:	mov    %edi,0xb8(%rsp)
 29f20aa:	mov    %edx,0x78(%rsp)
 29f20ae:	mov    %esi,0xc8(%rsp)
 29f20b5:	mov    0x2e8(%rsp),%rax
 29f20bd:	mov    (%rax),%rcx
 29f20c0:	mov    0x228(%rsp),%rax
 29f20c8:	cmp    %rax,%rcx
 29f20cb:	jae    29fb43e <wasm[0]::function[1015]::helper::object_read+0x1a4be>
 29f20d1:	mov    0x98(%rsp),%r8d
 29f20d9:	mov    0xc0(%rsp),%r14d
 29f20e1:	mov    0x88(%rsp),%r10d
 29f20e9:	mov    0xb8(%rsp),%edi
 29f20f0:	mov    0x78(%rsp),%edx
 29f20f4:	mov    0xc8(%rsp),%esi
 29f20fb:	mov    %r15,%rcx
 29f20fe:	cmp    %ebx,%ecx
 29f2100:	jb     29f2113 <wasm[0]::function[1015]::helper::object_read+0x11193>
 29f2106:	mov    0x1c8(%rsp),%rax
 29f210e:	jmp    29f22fb <wasm[0]::function[1015]::helper::object_read+0x1137b>
 29f2113:	mov    0xa8(%rsp),%eax
 29f211a:	test   %eax,%eax
 29f211c:	je     29fc43f <wasm[0]::function[1015]::helper::object_read+0x1b4bf>
 29f2122:	test   %eax,%eax
 29f2124:	je     29fc441 <wasm[0]::function[1015]::helper::object_read+0x1b4c1>
 29f212a:	mov    0x2e0(%rsp),%r12
 29f2132:	mov    0x28(%r12),%rdx
 29f2137:	mov    0x20(%r12),%rsi
 29f213c:	mov    %eax,%r9d
 29f213f:	lea    0x10(%rsi,%r9,1),%r8
 29f2144:	xor    %rdi,%rdi
 29f2147:	cmp    %rdx,%r9
 29f214a:	cmova  %rdi,%r8
 29f214e:	mov    (%r8),%r8d
 29f2151:	cmp    %r8d,%ecx
 29f2154:	jae    29fc443 <wasm[0]::function[1015]::helper::object_read+0x1b4c3>
 29f215a:	mov    %r8d,%r9d
 29f215d:	shl    $0x2,%r9
 29f2161:	shr    $0x20,%r9
 29f2165:	test   %r9,%r9
 29f2168:	jne    29fc445 <wasm[0]::function[1015]::helper::object_read+0x1b4c5>
 29f216e:	shl    $0x2,%r8d
 29f2172:	add    $0x14,%r8d
 29f2176:	jb     29fc447 <wasm[0]::function[1015]::helper::object_read+0x1b4c7>
 29f217c:	add    %r8d,%eax
 29f217f:	jb     29fc449 <wasm[0]::function[1015]::helper::object_read+0x1b4c9>
 29f2185:	mov    %eax,%r9d
 29f2188:	lea    (%rsi,%r9,1),%rax
 29f218c:	cmp    %rdx,%r9
 29f218f:	cmova  %rdi,%rax
 29f2193:	mov    %rcx,%rdx
 29f2196:	shl    $0x2,%edx
 29f2199:	mov    %rcx,%r15
 29f219c:	add    $0x14,%edx
 29f21a2:	sub    %edx,%r8d
 29f21a5:	sub    %r8,%rax
 29f21a8:	mov    (%rax),%edx
 29f21aa:	test   %edx,%edx
 29f21ac:	je     29fc44b <wasm[0]::function[1015]::helper::object_read+0x1b4cb>
 29f21b2:	mov    0xd8(%rsp),%edi
 29f21b9:	cmp    %edi,%edx
 29f21bb:	je     29f2290 <wasm[0]::function[1015]::helper::object_read+0x11310>
 29f21c1:	xor    %eax,%eax
 29f21c3:	test   %edx,%edx
 29f21c5:	je     29f2207 <wasm[0]::function[1015]::helper::object_read+0x11287>
 29f21cb:	xor    %eax,%eax
 29f21cd:	test   $0x1,%edx
 29f21d3:	jne    29f2207 <wasm[0]::function[1015]::helper::object_read+0x11287>
 29f21d9:	mov    0x2e0(%rsp),%r12
 29f21e1:	mov    0x28(%r12),%rax
 29f21e6:	mov    0x20(%r12),%rcx
 29f21eb:	mov    %edx,%esi
 29f21ed:	lea    0x4(%rcx,%rsi,1),%rcx
 29f21f2:	xor    %r8,%r8
 29f21f5:	cmp    %rax,%rsi
 29f21f8:	cmova  %r8,%rcx
 29f21fc:	mov    (%rcx),%eax
 29f21fe:	cmp    %r13d,%eax
 29f2201:	sete   %al
 29f2204:	movzbl %al,%eax
 29f2207:	test   %eax,%eax
 29f2209:	je     29fc44d <wasm[0]::function[1015]::helper::object_read+0x1b4cd>
 29f220f:	xor    %esi,%esi
 29f2211:	test   %edi,%edi
 29f2213:	je     29f225c <wasm[0]::function[1015]::helper::object_read+0x112dc>
 29f2219:	mov    0xd8(%rsp),%eax
 29f2220:	xor    %esi,%esi
 29f2222:	test   $0x1,%eax
 29f2227:	jne    29f225c <wasm[0]::function[1015]::helper::object_read+0x112dc>
 29f222d:	mov    0x2e0(%rsp),%r12
 29f2235:	mov    0x28(%r12),%rcx
 29f223a:	mov    0x20(%r12),%rdi
 29f223f:	mov    %eax,%esi
 29f2241:	lea    0x4(%rdi,%rsi,1),%rax
 29f2246:	xor    %rdi,%rdi
 29f2249:	cmp    %rcx,%rsi
 29f224c:	cmova  %rdi,%rax
 29f2250:	mov    (%rax),%eax
 29f2252:	cmp    %r13d,%eax
 29f2255:	sete   %al
 29f2258:	rex movzbl %al,%esi
 29f225c:	test   %esi,%esi
 29f225e:	je     29fc44f <wasm[0]::function[1015]::helper::object_read+0x1b4cf>
 29f2264:	mov    0xd8(%rsp),%ecx
 29f226b:	xor    %r8d,%r8d
 29f226e:	test   %ecx,%ecx
 29f2270:	je     29fc451 <wasm[0]::function[1015]::helper::object_read+0x1b4d1>
 29f2276:	mov    0x190(%rsp),%rsi
 29f227e:	mov    0x190(%rsp),%rdi
 29f2286:	call   2ae5540 <wasm[0]::function[1057]::helper::string_equality>
 29f228b:	jmp    29f2298 <wasm[0]::function[1015]::helper::object_read+0x11318>
 29f2290:	mov    0x278(%rsp),%rax
 29f2298:	mov    0xa8(%rsp),%r9d
 29f22a0:	mov    0xd8(%rsp),%r11d
 29f22a8:	mov    0x98(%rsp),%r8d
 29f22b0:	mov    0xc0(%rsp),%r14d
 29f22b8:	mov    0x88(%rsp),%r10d
 29f22c0:	mov    0xb8(%rsp),%edi
 29f22c7:	mov    0x78(%rsp),%edx
 29f22cb:	mov    0xc8(%rsp),%esi
 29f22d2:	test   %eax,%eax
 29f22d4:	je     29f22e2 <wasm[0]::function[1015]::helper::object_read+0x11362>
 29f22da:	mov    %r15,%rcx
 29f22dd:	jmp    29f22fb <wasm[0]::function[1015]::helper::object_read+0x1137b>
 29f22e2:	mov    %r15,%rcx
 29f22e5:	add    $0x1,%ecx
 29f22eb:	mov    %rcx,%r15
 29f22ee:	mov    %rax,0x1c8(%rsp)
 29f22f6:	jmp    29f207b <wasm[0]::function[1015]::helper::object_read+0x110fb>
 29f22fb:	xor    %r11d,%r11d
 29f22fe:	xor    %r9,%r9
 29f2301:	test   %eax,%eax
 29f2303:	jne    29f231e <wasm[0]::function[1015]::helper::object_read+0x1139e>
 29f2309:	mov    %r11,0x1d0(%rsp)
 29f2311:	mov    %r9,0x1d8(%rsp)
 29f2319:	jmp    29f274a <wasm[0]::function[1015]::helper::object_read+0x117ca>
 29f231e:	test   %r8d,%r8d
 29f2321:	je     29fc453 <wasm[0]::function[1015]::helper::object_read+0x1b4d3>
 29f2327:	xor    %r9d,%r9d
 29f232a:	test   $0x1,%r8d
 29f2331:	jne    29f2378 <wasm[0]::function[1015]::helper::object_read+0x113f8>
 29f2337:	mov    0x2e0(%rsp),%r12
 29f233f:	mov    0x28(%r12),%rax
 29f2344:	mov    0x20(%r12),%r9
 29f2349:	mov    %r8d,%r10d
 29f234c:	lea    0x4(%r9,%r10,1),%r9
 29f2351:	xor    %r11,%r11
 29f2354:	cmp    %rax,%r10
 29f2357:	cmova  %r11,%r9
 29f235b:	mov    (%r9),%eax
 29f235e:	mov    0x190(%rsp),%r9
 29f2366:	mov    0x28(%r9),%r9
 29f236a:	cmp    0x160(%r9),%eax
 29f2371:	sete   %al
 29f2374:	movzbl %al,%r9d
 29f2378:	test   %r9d,%r9d
 29f237b:	jne    29f25c2 <wasm[0]::function[1015]::helper::object_read+0x11642>
 29f2381:	xor    %eax,%eax
 29f2383:	test   $0x1,%r8d
 29f238a:	jne    29f23d0 <wasm[0]::function[1015]::helper::object_read+0x11450>
 29f2390:	mov    0x2e0(%rsp),%r12
 29f2398:	mov    0x28(%r12),%rax
 29f239d:	mov    0x20(%r12),%r9
 29f23a2:	mov    %r8d,%r10d
 29f23a5:	lea    0x4(%r9,%r10,1),%r9
 29f23aa:	xor    %r11,%r11
 29f23ad:	cmp    %rax,%r10
 29f23b0:	cmova  %r11,%r9
 29f23b4:	mov    (%r9),%eax
 29f23b7:	mov    0x190(%rsp),%r9
 29f23bf:	mov    0x28(%r9),%r9
 29f23c3:	cmp    0x15c(%r9),%eax
 29f23ca:	sete   %al
 29f23cd:	movzbl %al,%eax
 29f23d0:	test   %eax,%eax
 29f23d2:	je     29fc455 <wasm[0]::function[1015]::helper::object_read+0x1b4d5>
 29f23d8:	test   %r8d,%r8d
 29f23db:	je     29fc457 <wasm[0]::function[1015]::helper::object_read+0x1b4d7>
 29f23e1:	mov    0x2e0(%rsp),%r12
 29f23e9:	mov    0x28(%r12),%r11
 29f23ee:	mov    0x20(%r12),%rax
 29f23f3:	mov    %r8d,%r10d
 29f23f6:	lea    (%rax,%r10,1),%r8
 29f23fa:	xor    %r9,%r9
 29f23fd:	cmp    %r11,%r10
 29f2400:	cmova  %r9,%r8
 29f2404:	mov    0x14(%r8),%ebx
 29f2408:	mov    0x18(%r8),%r10d
 29f240c:	mov    0x1c(%r8),%r8d
 29f2410:	test   %ebx,%ebx
 29f2412:	je     29fc459 <wasm[0]::function[1015]::helper::object_read+0x1b4d9>
 29f2418:	test   %ebx,%ebx
 29f241a:	je     29fc45b <wasm[0]::function[1015]::helper::object_read+0x1b4db>
 29f2420:	mov    %ebx,%r13d
 29f2423:	lea    0x10(%rax,%r13,1),%r12
 29f2428:	cmp    %r11,%r13
 29f242b:	cmova  %r9,%r12
 29f242f:	mov    (%r12),%r12d
 29f2433:	cmp    %r12d,%ecx
 29f2436:	jae    29fc45d <wasm[0]::function[1015]::helper::object_read+0x1b4dd>
 29f243c:	mov    %r12d,%r13d
 29f243f:	shr    $0x20,%r13
 29f2443:	test   %r13,%r13
 29f2446:	jne    29fc45f <wasm[0]::function[1015]::helper::object_read+0x1b4df>
 29f244c:	add    $0x14,%r12d
 29f2450:	jb     29fc461 <wasm[0]::function[1015]::helper::object_read+0x1b4e1>
 29f2456:	add    %r12d,%ebx
 29f2459:	jb     29fc463 <wasm[0]::function[1015]::helper::object_read+0x1b4e3>
 29f245f:	mov    %ebx,%ebx
 29f2461:	add    %rbx,%rax
 29f2464:	cmp    %r11,%rbx
 29f2467:	cmova  %r9,%rax
 29f246b:	lea    0x14(%rcx),%r11d
 29f246f:	sub    %r11d,%r12d
 29f2472:	sub    %r12,%rax
 29f2475:	movzbq (%rax),%r11
 29f2479:	test   %r10d,%r10d
 29f247c:	je     29f2512 <wasm[0]::function[1015]::helper::object_read+0x11592>
 29f2482:	test   %r10d,%r10d
 29f2485:	je     29fc465 <wasm[0]::function[1015]::helper::object_read+0x1b4e5>
 29f248b:	test   %r10d,%r10d
 29f248e:	je     29fc467 <wasm[0]::function[1015]::helper::object_read+0x1b4e7>
 29f2494:	mov    0x2e0(%rsp),%r12
 29f249c:	mov    0x28(%r12),%rax
 29f24a1:	mov    0x20(%r12),%r9
 29f24a6:	mov    %r10d,%r13d
 29f24a9:	lea    0x10(%r9,%r13,1),%r12
 29f24ae:	xor    %rbx,%rbx
 29f24b1:	cmp    %rax,%r13
 29f24b4:	cmova  %rbx,%r12
 29f24b8:	mov    (%r12),%r15d
 29f24bc:	cmp    %r15d,%ecx
 29f24bf:	jae    29fc469 <wasm[0]::function[1015]::helper::object_read+0x1b4e9>
 29f24c5:	mov    %r15d,%r12d
 29f24c8:	shl    $0x3,%r12
 29f24cc:	shr    $0x20,%r12
 29f24d0:	test   %r12,%r12
 29f24d3:	jne    29fc46b <wasm[0]::function[1015]::helper::object_read+0x1b4eb>
 29f24d9:	shl    $0x3,%r15d
 29f24dd:	add    $0x18,%r15d
 29f24e1:	jb     29fc46d <wasm[0]::function[1015]::helper::object_read+0x1b4ed>
 29f24e7:	add    %r15d,%r10d
 29f24ea:	jb     29fc46f <wasm[0]::function[1015]::helper::object_read+0x1b4ef>
 29f24f0:	mov    %r10d,%r10d
 29f24f3:	add    %r10,%r9
 29f24f6:	cmp    %rax,%r10
 29f24f9:	cmova  %rbx,%r9
 29f24fd:	mov    %rcx,%rax
 29f2500:	shl    $0x3,%eax
 29f2503:	add    $0x18,%eax
 29f2509:	sub    %eax,%r15d
 29f250c:	sub    %r15,%r9
 29f250f:	mov    (%r9),%r9
 29f2512:	xor    %r10d,%r10d
 29f2515:	test   %r8d,%r8d
 29f2518:	je     29f25a9 <wasm[0]::function[1015]::helper::object_read+0x11629>
 29f251e:	test   %r8d,%r8d
 29f2521:	je     29fc471 <wasm[0]::function[1015]::helper::object_read+0x1b4f1>
 29f2527:	test   %r8d,%r8d
 29f252a:	je     29fc473 <wasm[0]::function[1015]::helper::object_read+0x1b4f3>
 29f2530:	mov    0x2e0(%rsp),%r12
 29f2538:	mov    0x28(%r12),%rax
 29f253d:	mov    0x20(%r12),%r10
 29f2542:	mov    %r8d,%r13d
 29f2545:	lea    0x10(%r10,%r13,1),%r12
 29f254a:	xor    %rbx,%rbx
 29f254d:	cmp    %rax,%r13
 29f2550:	cmova  %rbx,%r12
 29f2554:	mov    (%r12),%r12d
 29f2558:	cmp    %r12d,%ecx
 29f255b:	jae    29fc475 <wasm[0]::function[1015]::helper::object_read+0x1b4f5>
 29f2561:	mov    %r12d,%r13d
 29f2564:	shl    $0x2,%r13
 29f2568:	shr    $0x20,%r13
 29f256c:	test   %r13,%r13
 29f256f:	jne    29fc477 <wasm[0]::function[1015]::helper::object_read+0x1b4f7>
 29f2575:	shl    $0x2,%r12d
 29f2579:	add    $0x14,%r12d
 29f257d:	jb     29fc479 <wasm[0]::function[1015]::helper::object_read+0x1b4f9>
 29f2583:	add    %r12d,%r8d
 29f2586:	jb     29fc47b <wasm[0]::function[1015]::helper::object_read+0x1b4fb>
 29f258c:	mov    %r8d,%r13d
 29f258f:	lea    (%r10,%r13,1),%r8
 29f2593:	cmp    %rax,%r13
 29f2596:	cmova  %rbx,%r8
 29f259a:	shl    $0x2,%ecx
 29f259d:	lea    0x14(%rcx),%eax
 29f25a0:	sub    %eax,%r12d
 29f25a3:	sub    %r12,%r8
 29f25a6:	mov    (%r8),%r10d
 29f25a9:	movzbl %r11b,%r11d
 29f25ad:	mov    %r11,0x1d0(%rsp)
 29f25b5:	mov    %r9,0x1d8(%rsp)
 29f25bd:	jmp    29f274a <wasm[0]::function[1015]::helper::object_read+0x117ca>
 29f25c2:	xor    %eax,%eax
 29f25c4:	test   $0x1,%r8d
 29f25cb:	jne    29f2611 <wasm[0]::function[1015]::helper::object_read+0x11691>
 29f25d1:	mov    0x2e0(%rsp),%r12
 29f25d9:	mov    0x28(%r12),%rax
 29f25de:	mov    0x20(%r12),%r9
 29f25e3:	mov    %r8d,%r10d
 29f25e6:	lea    0x4(%r9,%r10,1),%r9
 29f25eb:	xor    %r11,%r11
 29f25ee:	cmp    %rax,%r10
 29f25f1:	cmova  %r11,%r9
 29f25f5:	mov    (%r9),%eax
 29f25f8:	mov    0x190(%rsp),%r9
 29f2600:	mov    0x28(%r9),%r9
 29f2604:	cmp    0x160(%r9),%eax
 29f260b:	sete   %al
 29f260e:	movzbl %al,%eax
 29f2611:	test   %eax,%eax
 29f2613:	je     29fc47d <wasm[0]::function[1015]::helper::object_read+0x1b4fd>
 29f2619:	test   %r8d,%r8d
 29f261c:	je     29fc47f <wasm[0]::function[1015]::helper::object_read+0x1b4ff>
 29f2622:	mov    0x2e0(%rsp),%r12
 29f262a:	mov    0x28(%r12),%rax
 29f262f:	mov    0x20(%r12),%r9
 29f2634:	mov    %r8d,%r8d
 29f2637:	lea    (%r9,%r8,1),%r11
 29f263b:	xor    %r10,%r10
 29f263e:	cmp    %rax,%r8
 29f2641:	cmova  %r10,%r11
 29f2645:	mov    0x10(%r11),%r11d
 29f2649:	test   %r11d,%r11d
 29f264c:	je     29fc481 <wasm[0]::function[1015]::helper::object_read+0x1b501>
 29f2652:	test   %r11d,%r11d
 29f2655:	je     29fc483 <wasm[0]::function[1015]::helper::object_read+0x1b503>
 29f265b:	mov    %r11d,%r12d
 29f265e:	lea    (%r9,%r12,1),%r11
 29f2662:	cmp    %rax,%r12
 29f2665:	cmova  %r10,%r11
 29f2669:	mov    0x10(%r11),%r11d
 29f266d:	test   %r11d,%r11d
 29f2670:	je     29fc485 <wasm[0]::function[1015]::helper::object_read+0x1b505>
 29f2676:	test   %r11d,%r11d
 29f2679:	je     29fc487 <wasm[0]::function[1015]::helper::object_read+0x1b507>
 29f267f:	mov    %r11d,%r11d
 29f2682:	lea    0x10(%r9,%r11,1),%r9
 29f2687:	cmp    %rax,%r11
 29f268a:	cmova  %r10,%r9
 29f268e:	cmp    (%r9),%ecx
 29f2691:	setae  %r9b
 29f2695:	cmp    $0x2,%ecx
 29f2698:	setae  %al
 29f269b:	or     %eax,%r9d
 29f269e:	test   %r9b,%r9b
 29f26a1:	jne    29fc489 <wasm[0]::function[1015]::helper::object_read+0x1b509>
 29f26a7:	mov    0x2e0(%rsp),%r12
 29f26af:	mov    0x28(%r12),%r9
 29f26b4:	mov    %r8,%rax
 29f26b7:	add    0x20(%r12),%rax
 29f26bc:	xor    %r10,%r10
 29f26bf:	cmp    %r9,%r8
 29f26c2:	cmova  %r10,%rax
 29f26c6:	mov    0x14(%rax),%r11d
 29f26ca:	test   %ecx,%ecx
 29f26cc:	je     29f2706 <wasm[0]::function[1015]::helper::object_read+0x11786>
 29f26d2:	mov    0x2e0(%rsp),%r12
 29f26da:	mov    0x28(%r12),%r9
 29f26df:	mov    0x20(%r12),%rax
 29f26e4:	add    %r8,%rax
 29f26e7:	xor    %r10,%r10
 29f26ea:	cmp    %r9,%r8
 29f26ed:	cmova  %r10,%rax
 29f26f1:	mov    0x20(%rax),%r9
 29f26f5:	mov    0x2c(%rax),%r10d
 29f26f9:	mov    %r9,0x1d8(%rsp)
 29f2701:	jmp    29f2735 <wasm[0]::function[1015]::helper::object_read+0x117b5>
 29f2706:	mov    0x2e0(%rsp),%r12
 29f270e:	mov    0x28(%r12),%r9
 29f2713:	mov    0x20(%r12),%rax
 29f2718:	add    %r8,%rax
 29f271b:	xor    %r10,%r10
 29f271e:	cmp    %r9,%r8
 29f2721:	cmova  %r10,%rax
 29f2725:	mov    0x18(%rax),%r9
 29f2729:	mov    %r9,0x1d8(%rsp)
 29f2731:	mov    0x28(%rax),%r10d
 29f2735:	shl    $0x3,%ecx
 29f2738:	shr    %cl,%r11d
 29f273b:	and    $0xff,%r11d
 29f2742:	mov    %r11,0x1d0(%rsp)
 29f274a:	mov    %r14d,0x88(%rsp)
 29f2752:	mov    %r10d,0xc0(%rsp)
 29f275a:	mov    %edi,0x98(%rsp)
 29f2761:	mov    %edx,0xd8(%rsp)
 29f2768:	mov    %esi,0xa8(%rsp)
 29f276f:	mov    0x198(%rsp),%rdx
 29f2777:	mov    0x190(%rsp),%rsi
 29f277f:	mov    0x190(%rsp),%rdi
 29f2787:	call   2f30600 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 29f278c:	mov    %eax,0xb8(%rsp)
 29f2793:	xor    %ecx,%ecx
 29f2795:	mov    %rcx,0x220(%rsp)
 29f279d:	test   %eax,%eax
 29f279f:	je     29fc48b <wasm[0]::function[1015]::helper::object_read+0x1b50b>
 29f27a5:	movl   $0x0,0x78(%rsp)
 29f27ad:	mov    0x88(%rsp),%eax
 29f27b4:	mov    0xc0(%rsp),%r8d
 29f27bc:	mov    0x98(%rsp),%edx
 29f27c3:	mov    0xd8(%rsp),%esi
 29f27ca:	mov    0xa8(%rsp),%edi
 29f27d1:	xor    %r10,%r10
 29f27d4:	mov    0x250(%rsp),%rcx
 29f27dc:	mov    0x250(%rsp),%r9
 29f27e4:	test   %r9b,%cl
 29f27e7:	jne    29f2812 <wasm[0]::function[1015]::helper::object_read+0x11892>
 29f27ed:	mov    0x220(%rsp),%r11
 29f27f5:	mov    %r10,0x200(%rsp)
 29f27fd:	mov    0x220(%rsp),%rcx
 29f2805:	mov    %rcx,0x208(%rsp)
 29f280d:	jmp    29f33f0 <wasm[0]::function[1015]::helper::object_read+0x12470>
 29f2812:	mov    0x88(%rsp),%r8d
 29f281a:	mov    0x260(%rsp),%rcx
 29f2822:	mov    0x258(%rsp),%rdx
 29f282a:	mov    0x190(%rsp),%rsi
 29f2832:	mov    0x190(%rsp),%rdi
 29f283a:	call   2a5f680 <wasm[0]::function[1039]::helper::object_header_projection>
 29f283f:	mov    %eax,0xc8(%rsp)
 29f2846:	test   %eax,%eax
 29f2848:	je     29fc48d <wasm[0]::function[1015]::helper::object_read+0x1b50d>
 29f284e:	test   %eax,%eax
 29f2850:	je     29fc48f <wasm[0]::function[1015]::helper::object_read+0x1b50f>
 29f2856:	mov    0x2e0(%rsp),%r12
 29f285e:	mov    0x28(%r12),%rcx
 29f2863:	mov    0x20(%r12),%rsi
 29f2868:	mov    %eax,%edx
 29f286a:	lea    (%rsi,%rdx,1),%rax
 29f286e:	xor    %rsi,%rsi
 29f2871:	cmp    %rcx,%rdx
 29f2874:	cmova  %rsi,%rax
 29f2878:	mov    0x14(%rax),%eax
 29f287b:	mov    %eax,0xb0(%rsp)
 29f2882:	test   %eax,%eax
 29f2884:	je     29fc491 <wasm[0]::function[1015]::helper::object_read+0x1b511>
 29f288a:	mov    0xb0(%rsp),%ecx
 29f2891:	xor    %eax,%eax
 29f2893:	test   $0x1,%ecx
 29f2899:	jne    29f28f3 <wasm[0]::function[1015]::helper::object_read+0x11973>
 29f289f:	mov    0x2e0(%rsp),%r12
 29f28a7:	mov    0x28(%r12),%rax
 29f28ac:	mov    0x20(%r12),%rsi
 29f28b1:	mov    %ecx,%edx
 29f28b3:	lea    0x4(%rsi,%rdx,1),%rcx
 29f28b8:	xor    %rsi,%rsi
 29f28bb:	cmp    %rax,%rdx
 29f28be:	cmova  %rsi,%rcx
 29f28c2:	mov    (%rcx),%esi
 29f28c4:	mov    0x190(%rsp),%rax
 29f28cc:	mov    0x28(%rax),%rax
 29f28d0:	mov    0x158(%rax),%edx
 29f28d6:	cmp    %edx,%esi
 29f28d8:	sete   %al
 29f28db:	movzbl %al,%eax
 29f28de:	cmp    %edx,%esi
 29f28e0:	je     29f28f3 <wasm[0]::function[1015]::helper::object_read+0x11973>
 29f28e6:	mov    0x190(%rsp),%rdi
 29f28ee:	call   3018cd5 <wasmtime_builtin_is_subtype>
 29f28f3:	test   %eax,%eax
 29f28f5:	jne    29f2b85 <wasm[0]::function[1015]::helper::object_read+0x11c05>
 29f28fb:	mov    0xc8(%rsp),%edx
 29f2902:	xor    %ebx,%ebx
 29f2904:	test   %edx,%edx
 29f2906:	je     29fc493 <wasm[0]::function[1015]::helper::object_read+0x1b513>
 29f290c:	mov    0xb8(%rsp),%r9d
 29f2914:	mov    $0x4,%ecx
 29f2919:	xor    %r8,%r8
 29f291c:	mov    0x190(%rsp),%rsi
 29f2924:	mov    0x190(%rsp),%rdi
 29f292c:	call   2a58e80 <wasm[0]::function[1032]::helper::ordinary_property_find>
 29f2931:	test   %eax,%eax
 29f2933:	je     29f296e <wasm[0]::function[1015]::helper::object_read+0x119ee>
 29f2939:	test   %eax,%eax
 29f293b:	je     29fc495 <wasm[0]::function[1015]::helper::object_read+0x1b515>
 29f2941:	test   %eax,%eax
 29f2943:	je     29fc497 <wasm[0]::function[1015]::helper::object_read+0x1b517>
 29f2949:	mov    0x2e0(%rsp),%r12
 29f2951:	mov    0x28(%r12),%rsi
 29f2956:	mov    %eax,%r8d
 29f2959:	mov    %r8,%rdi
 29f295c:	add    0x20(%r12),%rdi
 29f2961:	xor    %r9,%r9
 29f2964:	cmp    %rsi,%r8
 29f2967:	cmova  %r9,%rdi
 29f296b:	mov    0x14(%rdi),%ebx
 29f296e:	mov    0x78(%rsp),%r11d
 29f2973:	mov    %rax,%r10
 29f2976:	mov    %rax,0x220(%rsp)
 29f297e:	xor    %r10d,%eax
 29f2981:	mov    %rax,0x220(%rsp)
 29f2989:	xor    %r10,%r10
 29f298c:	test   %ebx,%ebx
 29f298e:	jne    29f29a1 <wasm[0]::function[1015]::helper::object_read+0x11a21>
 29f2994:	mov    0x220(%rsp),%rbx
 29f299c:	jmp    29f2b4c <wasm[0]::function[1015]::helper::object_read+0x11bcc>
 29f29a1:	test   %ebx,%ebx
 29f29a3:	je     29fc499 <wasm[0]::function[1015]::helper::object_read+0x1b519>
 29f29a9:	mov    0x2e0(%rsp),%r12
 29f29b1:	mov    0x28(%r12),%rcx
 29f29b6:	mov    0x20(%r12),%rax
 29f29bb:	mov    %ebx,%edx
 29f29bd:	add    %rdx,%rax
 29f29c0:	xor    %r10,%r10
 29f29c3:	cmp    %rcx,%rdx
 29f29c6:	cmova  %r10,%rax
 29f29ca:	mov    0x10(%rax),%ecx
 29f29cd:	mov    0x78(%rsp),%r11d
 29f29d2:	mov    %rdx,%rsi
 29f29d5:	mov    %rdx,0x220(%rsp)
 29f29dd:	xor    %esi,%edx
 29f29df:	mov    %rdx,0x220(%rsp)
 29f29e7:	test   $0x1,%ecx
 29f29ed:	je     29f2a00 <wasm[0]::function[1015]::helper::object_read+0x11a80>
 29f29f3:	mov    0x220(%rsp),%rbx
 29f29fb:	jmp    29f2b4c <wasm[0]::function[1015]::helper::object_read+0x11bcc>
 29f2a00:	mov    0x14(%rax),%edx
 29f2a03:	test   %edx,%edx
 29f2a05:	je     29fc49b <wasm[0]::function[1015]::helper::object_read+0x1b51b>
 29f2a0b:	xor    %eax,%eax
 29f2a0d:	test   $0x1,%edx
 29f2a13:	jne    29f2a56 <wasm[0]::function[1015]::helper::object_read+0x11ad6>
 29f2a19:	mov    0x2e0(%rsp),%r12
 29f2a21:	mov    0x28(%r12),%rax
 29f2a26:	mov    0x20(%r12),%rcx
 29f2a2b:	mov    %edx,%esi
 29f2a2d:	lea    0x4(%rcx,%rsi,1),%rcx
 29f2a32:	xor    %rdi,%rdi
 29f2a35:	cmp    %rax,%rsi
 29f2a38:	cmova  %rdi,%rcx
 29f2a3c:	mov    (%rcx),%eax
 29f2a3e:	mov    0x190(%rsp),%rsi
 29f2a46:	mov    0x28(%rsi),%rcx
 29f2a4a:	cmp    0x120(%rcx),%eax
 29f2a50:	sete   %al
 29f2a53:	movzbl %al,%eax
 29f2a56:	test   %eax,%eax
 29f2a58:	jne    29f2ab5 <wasm[0]::function[1015]::helper::object_read+0x11b35>
 29f2a5e:	mov    0x190(%rsp),%rsi
 29f2a66:	mov    0x190(%rsp),%rdi
 29f2a6e:	call   2a01c00 <wasm[0]::function[1024]::helper::property_value_resolve>
 29f2a73:	test   %eax,%eax
 29f2a75:	je     29fc49d <wasm[0]::function[1015]::helper::object_read+0x1b51d>
 29f2a7b:	test   %eax,%eax
 29f2a7d:	je     29fc49f <wasm[0]::function[1015]::helper::object_read+0x1b51f>
 29f2a83:	mov    0x2e0(%rsp),%r12
 29f2a8b:	mov    0x28(%r12),%rcx
 29f2a90:	mov    0x20(%r12),%rsi
 29f2a95:	mov    %eax,%edx
 29f2a97:	lea    (%rsi,%rdx,1),%rax
 29f2a9b:	xor    %rsi,%rsi
 29f2a9e:	cmp    %rcx,%rdx
 29f2aa1:	cmova  %rsi,%rax
 29f2aa5:	mov    0x18(%rax),%ebx
 29f2aa8:	mov    0x10(%rax),%r10
 29f2aac:	mov    0x1c(%rax),%r11d
 29f2ab0:	jmp    29f2b3c <wasm[0]::function[1015]::helper::object_read+0x11bbc>
 29f2ab5:	xor    %eax,%eax
 29f2ab7:	test   $0x1,%edx
 29f2abd:	jne    29f2b00 <wasm[0]::function[1015]::helper::object_read+0x11b80>
 29f2ac3:	mov    0x2e0(%rsp),%r12
 29f2acb:	mov    0x28(%r12),%rax
 29f2ad0:	mov    0x20(%r12),%rcx
 29f2ad5:	mov    %edx,%esi
 29f2ad7:	lea    0x4(%rcx,%rsi,1),%rcx
 29f2adc:	xor    %rdi,%rdi
 29f2adf:	cmp    %rax,%rsi
 29f2ae2:	cmova  %rdi,%rcx
 29f2ae6:	mov    (%rcx),%eax
 29f2ae8:	mov    0x190(%rsp),%rsi
 29f2af0:	mov    0x28(%rsi),%rcx
 29f2af4:	cmp    0x120(%rcx),%eax
 29f2afa:	sete   %al
 29f2afd:	movzbl %al,%eax
 29f2b00:	test   %eax,%eax
 29f2b02:	je     29fc4a1 <wasm[0]::function[1015]::helper::object_read+0x1b521>
 29f2b08:	test   %edx,%edx
 29f2b0a:	je     29fc4a3 <wasm[0]::function[1015]::helper::object_read+0x1b523>
 29f2b10:	mov    0x2e0(%rsp),%r12
 29f2b18:	mov    0x28(%r12),%rcx
 29f2b1d:	mov    0x20(%r12),%rax
 29f2b22:	mov    %edx,%edx
 29f2b24:	add    %rdx,%rax
 29f2b27:	xor    %rsi,%rsi
 29f2b2a:	cmp    %rcx,%rdx
 29f2b2d:	cmova  %rsi,%rax
 29f2b31:	mov    0x18(%rax),%ebx
 29f2b34:	mov    0x10(%rax),%r10
 29f2b38:	mov    0x1c(%rax),%r11d
 29f2b3c:	mov    0x278(%rsp),%rax
 29f2b44:	mov    %rax,0x220(%rsp)
 29f2b4c:	mov    0x88(%rsp),%eax
 29f2b53:	mov    0xc0(%rsp),%r8d
 29f2b5b:	mov    0x98(%rsp),%edx
 29f2b62:	mov    0xd8(%rsp),%esi
 29f2b69:	mov    0xa8(%rsp),%edi
 29f2b70:	mov    %r10,0x200(%rsp)
 29f2b78:	mov    %rbx,0x208(%rsp)
 29f2b80:	jmp    29f33f0 <wasm[0]::function[1015]::helper::object_read+0x12470>
 29f2b85:	mov    0xb0(%rsp),%eax
 29f2b8c:	test   %eax,%eax
 29f2b8e:	je     29fc4a5 <wasm[0]::function[1015]::helper::object_read+0x1b525>
 29f2b94:	mov    0xb0(%rsp),%ecx
 29f2b9b:	xor    %eax,%eax
 29f2b9d:	test   $0x1,%ecx
 29f2ba3:	jne    29f2bfd <wasm[0]::function[1015]::helper::object_read+0x11c7d>
 29f2ba9:	mov    0x2e0(%rsp),%r12
 29f2bb1:	mov    0x28(%r12),%rax
 29f2bb6:	mov    0x20(%r12),%rsi
 29f2bbb:	mov    %ecx,%edx
 29f2bbd:	lea    0x4(%rsi,%rdx,1),%rcx
 29f2bc2:	xor    %rsi,%rsi
 29f2bc5:	cmp    %rax,%rdx
 29f2bc8:	cmova  %rsi,%rcx
 29f2bcc:	mov    (%rcx),%esi
 29f2bce:	mov    0x190(%rsp),%rax
 29f2bd6:	mov    0x28(%rax),%rax
 29f2bda:	mov    0x158(%rax),%edx
 29f2be0:	cmp    %edx,%esi
 29f2be2:	sete   %al
 29f2be5:	movzbl %al,%eax
 29f2be8:	cmp    %edx,%esi
 29f2bea:	je     29f2bfd <wasm[0]::function[1015]::helper::object_read+0x11c7d>
 29f2bf0:	mov    0x190(%rsp),%rdi
 29f2bf8:	call   3018cd5 <wasmtime_builtin_is_subtype>
 29f2bfd:	test   %eax,%eax
 29f2bff:	je     29fc4a7 <wasm[0]::function[1015]::helper::object_read+0x1b527>
 29f2c05:	mov    0xb0(%rsp),%r9d
 29f2c0d:	mov    0x88(%rsp),%eax
 29f2c14:	mov    0xc0(%rsp),%r8d
 29f2c1c:	mov    0x98(%rsp),%edx
 29f2c23:	mov    0x78(%rsp),%r11d
 29f2c28:	mov    0xd8(%rsp),%esi
 29f2c2f:	mov    0xa8(%rsp),%edi
 29f2c36:	xor    %ecx,%ecx
 29f2c38:	mov    %rcx,%r15
 29f2c3b:	test   %r9d,%r9d
 29f2c3e:	je     29fc4a9 <wasm[0]::function[1015]::helper::object_read+0x1b529>
 29f2c44:	test   %r9d,%r9d
 29f2c47:	je     29fc4ab <wasm[0]::function[1015]::helper::object_read+0x1b52b>
 29f2c4d:	mov    0x2e0(%rsp),%r12
 29f2c55:	mov    0x28(%r12),%rcx
 29f2c5a:	mov    0x20(%r12),%r12
 29f2c5f:	mov    %r9d,%r14d
 29f2c62:	lea    (%r12,%r14,1),%r10
 29f2c66:	xor    %r13,%r13
 29f2c69:	cmp    %rcx,%r14
 29f2c6c:	cmova  %r13,%r10
 29f2c70:	mov    0x10(%r10),%r10d
 29f2c74:	test   %r10d,%r10d
 29f2c77:	je     29fc4ad <wasm[0]::function[1015]::helper::object_read+0x1b52d>
 29f2c7d:	test   %r10d,%r10d
 29f2c80:	je     29fc4af <wasm[0]::function[1015]::helper::object_read+0x1b52f>
 29f2c86:	mov    %r10d,%r14d
 29f2c89:	lea    (%r12,%r14,1),%r10
 29f2c8d:	cmp    %rcx,%r14
 29f2c90:	cmova  %r13,%r10
 29f2c94:	mov    0x10(%r10),%r10d
 29f2c98:	test   %r10d,%r10d
 29f2c9b:	je     29fc4b1 <wasm[0]::function[1015]::helper::object_read+0x1b531>
 29f2ca1:	test   %r10d,%r10d
 29f2ca4:	je     29fc4b3 <wasm[0]::function[1015]::helper::object_read+0x1b533>
 29f2caa:	mov    %r10d,%r14d
 29f2cad:	lea    0x10(%r12,%r14,1),%rbx
 29f2cb2:	cmp    %rcx,%r14
 29f2cb5:	cmova  %r13,%rbx
 29f2cb9:	mov    (%rbx),%ebx
 29f2cbb:	mov    0xb8(%rsp),%r12d
 29f2cc3:	mov    0x190(%rsp),%rcx
 29f2ccb:	mov    0x28(%rcx),%rcx
 29f2ccf:	mov    0x234(%rcx),%r13d
 29f2cd6:	mov    %r15,0x220(%rsp)
 29f2cde:	mov    %r10d,0xc8(%rsp)
 29f2ce6:	mov    %r12d,0xa8(%rsp)
 29f2cee:	mov    %r9d,0xd8(%rsp)
 29f2cf6:	mov    %eax,0x78(%rsp)
 29f2cfa:	mov    %r8d,0x98(%rsp)
 29f2d02:	mov    %edx,0xc0(%rsp)
 29f2d09:	mov    %r11d,0x88(%rsp)
 29f2d11:	mov    %esi,0xb0(%rsp)
 29f2d18:	mov    %edi,0xb8(%rsp)
 29f2d1f:	mov    0x2e8(%rsp),%rcx
 29f2d27:	mov    (%rcx),%rax
 29f2d2a:	mov    0x228(%rsp),%rcx
 29f2d32:	cmp    %rcx,%rax
 29f2d35:	jae    29fb476 <wasm[0]::function[1015]::helper::object_read+0x1a4f6>
 29f2d3b:	mov    0xd8(%rsp),%r9d
 29f2d43:	mov    0x78(%rsp),%eax
 29f2d47:	mov    0x98(%rsp),%r8d
 29f2d4f:	mov    0xc0(%rsp),%edx
 29f2d56:	mov    0x88(%rsp),%r11d
 29f2d5e:	mov    0xb0(%rsp),%esi
 29f2d65:	mov    0xb8(%rsp),%edi
 29f2d6c:	mov    %r15,%rcx
 29f2d6f:	cmp    %ebx,%ecx
 29f2d71:	jae    29f2f82 <wasm[0]::function[1015]::helper::object_read+0x12002>
 29f2d77:	mov    0xc8(%rsp),%eax
 29f2d7e:	test   %eax,%eax
 29f2d80:	je     29fc4b5 <wasm[0]::function[1015]::helper::object_read+0x1b535>
 29f2d86:	test   %eax,%eax
 29f2d88:	je     29fc4b7 <wasm[0]::function[1015]::helper::object_read+0x1b537>
 29f2d8e:	mov    0x2e0(%rsp),%r12
 29f2d96:	mov    0x28(%r12),%rdx
 29f2d9b:	mov    0x20(%r12),%rsi
 29f2da0:	mov    %eax,%r9d
 29f2da3:	lea    0x10(%rsi,%r9,1),%r8
 29f2da8:	xor    %rdi,%rdi
 29f2dab:	cmp    %rdx,%r9
 29f2dae:	cmova  %rdi,%r8
 29f2db2:	mov    (%r8),%r8d
 29f2db5:	cmp    %r8d,%ecx
 29f2db8:	jae    29fc4b9 <wasm[0]::function[1015]::helper::object_read+0x1b539>
 29f2dbe:	mov    %r8d,%r9d
 29f2dc1:	shl    $0x2,%r9
 29f2dc5:	shr    $0x20,%r9
 29f2dc9:	test   %r9,%r9
 29f2dcc:	jne    29fc4bb <wasm[0]::function[1015]::helper::object_read+0x1b53b>
 29f2dd2:	shl    $0x2,%r8d
 29f2dd6:	add    $0x14,%r8d
 29f2dda:	jb     29fc4bd <wasm[0]::function[1015]::helper::object_read+0x1b53d>
 29f2de0:	add    %r8d,%eax
 29f2de3:	jb     29fc4bf <wasm[0]::function[1015]::helper::object_read+0x1b53f>
 29f2de9:	mov    %eax,%r9d
 29f2dec:	lea    (%rsi,%r9,1),%rax
 29f2df0:	cmp    %rdx,%r9
 29f2df3:	cmova  %rdi,%rax
 29f2df7:	mov    %rcx,%rdx
 29f2dfa:	shl    $0x2,%edx
 29f2dfd:	mov    %rcx,%r15
 29f2e00:	lea    0x14(%rdx),%ecx
 29f2e03:	sub    %ecx,%r8d
 29f2e06:	sub    %r8,%rax
 29f2e09:	mov    (%rax),%edx
 29f2e0b:	test   %edx,%edx
 29f2e0d:	je     29fc4c1 <wasm[0]::function[1015]::helper::object_read+0x1b541>
 29f2e13:	mov    0xa8(%rsp),%eax
 29f2e1a:	cmp    %eax,%edx
 29f2e1c:	je     29f2eff <wasm[0]::function[1015]::helper::object_read+0x11f7f>
 29f2e22:	xor    %ecx,%ecx
 29f2e24:	test   %edx,%edx
 29f2e26:	je     29f2e6a <wasm[0]::function[1015]::helper::object_read+0x11eea>
 29f2e2c:	xor    %ecx,%ecx
 29f2e2e:	test   $0x1,%edx
 29f2e34:	jne    29f2e6a <wasm[0]::function[1015]::helper::object_read+0x11eea>
 29f2e3a:	mov    0x2e0(%rsp),%r12
 29f2e42:	mov    0x28(%r12),%rcx
 29f2e47:	mov    0x20(%r12),%rsi
 29f2e4c:	mov    %edx,%edi
 29f2e4e:	lea    0x4(%rsi,%rdi,1),%rsi
 29f2e53:	xor    %r8,%r8
 29f2e56:	cmp    %rcx,%rdi
 29f2e59:	cmova  %r8,%rsi
 29f2e5d:	mov    (%rsi),%ecx
 29f2e5f:	cmp    %r13d,%ecx
 29f2e62:	sete   %sil
 29f2e66:	movzbl %sil,%ecx
 29f2e6a:	test   %ecx,%ecx
 29f2e6c:	je     29fc4c3 <wasm[0]::function[1015]::helper::object_read+0x1b543>
 29f2e72:	xor    %ecx,%ecx
 29f2e74:	test   %eax,%eax
 29f2e76:	je     29f2ec3 <wasm[0]::function[1015]::helper::object_read+0x11f43>
 29f2e7c:	mov    0xa8(%rsp),%r8d
 29f2e84:	xor    %ecx,%ecx
 29f2e86:	test   $0x1,%r8d
 29f2e8d:	jne    29f2ec3 <wasm[0]::function[1015]::helper::object_read+0x11f43>
 29f2e93:	mov    0x2e0(%rsp),%r12
 29f2e9b:	mov    0x28(%r12),%r11
 29f2ea0:	mov    0x20(%r12),%rcx
 29f2ea5:	mov    %r8d,%eax
 29f2ea8:	lea    0x4(%rcx,%rax,1),%r8
 29f2ead:	xor    %rcx,%rcx
 29f2eb0:	cmp    %r11,%rax
 29f2eb3:	cmova  %rcx,%r8
 29f2eb7:	mov    (%r8),%eax
 29f2eba:	cmp    %r13d,%eax
 29f2ebd:	sete   %al
 29f2ec0:	movzbl %al,%ecx
 29f2ec3:	test   %ecx,%ecx
 29f2ec5:	je     29fc4c5 <wasm[0]::function[1015]::helper::object_read+0x1b545>
 29f2ecb:	mov    0xa8(%rsp),%ecx
 29f2ed2:	xor    %r8d,%r8d
 29f2ed5:	test   %ecx,%ecx
 29f2ed7:	je     29fc4c7 <wasm[0]::function[1015]::helper::object_read+0x1b547>
 29f2edd:	mov    0x190(%rsp),%rsi
 29f2ee5:	mov    0x190(%rsp),%rdi
 29f2eed:	call   2ae5540 <wasm[0]::function[1057]::helper::string_equality>
 29f2ef2:	mov    %rax,0x220(%rsp)
 29f2efa:	jmp    29f2f0f <wasm[0]::function[1015]::helper::object_read+0x11f8f>
 29f2eff:	mov    0x278(%rsp),%rax
 29f2f07:	mov    %rax,0x220(%rsp)
 29f2f0f:	mov    0xc8(%rsp),%r10d
 29f2f17:	mov    0xa8(%rsp),%r12d
 29f2f1f:	mov    0xd8(%rsp),%r9d
 29f2f27:	mov    0x78(%rsp),%eax
 29f2f2b:	mov    0x98(%rsp),%r8d
 29f2f33:	mov    0xc0(%rsp),%edx
 29f2f3a:	mov    0x88(%rsp),%r11d
 29f2f42:	mov    0xb0(%rsp),%esi
 29f2f49:	mov    0xb8(%rsp),%edi
 29f2f50:	mov    0x220(%rsp),%rcx
 29f2f58:	mov    0x220(%rsp),%r14
 29f2f60:	test   %r14d,%ecx
 29f2f63:	je     29f2f71 <wasm[0]::function[1015]::helper::object_read+0x11ff1>
 29f2f69:	mov    %r15,%rcx
 29f2f6c:	jmp    29f2f82 <wasm[0]::function[1015]::helper::object_read+0x12002>
 29f2f71:	mov    %r15,%rcx
 29f2f74:	add    $0x1,%ecx
 29f2f7a:	mov    %rcx,%r15
 29f2f7d:	jmp    29f2cde <wasm[0]::function[1015]::helper::object_read+0x11d5e>
 29f2f82:	xor    %r10,%r10
 29f2f85:	xor    %ebx,%ebx
 29f2f87:	mov    0x220(%rsp),%r12
 29f2f8f:	mov    0x220(%rsp),%r13
 29f2f97:	test   %r13d,%r12d
 29f2f9a:	jne    29f2fb5 <wasm[0]::function[1015]::helper::object_read+0x12035>
 29f2fa0:	mov    %r10,0x200(%rsp)
 29f2fa8:	mov    %rbx,0x208(%rsp)
 29f2fb0:	jmp    29f33f0 <wasm[0]::function[1015]::helper::object_read+0x12470>
 29f2fb5:	test   %r9d,%r9d
 29f2fb8:	je     29fc4c9 <wasm[0]::function[1015]::helper::object_read+0x1b549>
 29f2fbe:	xor    %r10d,%r10d
 29f2fc1:	test   $0x1,%r9d
 29f2fc8:	jne    29f3010 <wasm[0]::function[1015]::helper::object_read+0x12090>
 29f2fce:	mov    0x2e0(%rsp),%r12
 29f2fd6:	mov    0x28(%r12),%r10
 29f2fdb:	mov    0x20(%r12),%r11
 29f2fe0:	mov    %r9d,%ebx
 29f2fe3:	lea    0x4(%r11,%rbx,1),%r11
 29f2fe8:	xor    %r12,%r12
 29f2feb:	cmp    %r10,%rbx
 29f2fee:	cmova  %r12,%r11
 29f2ff2:	mov    (%r11),%r10d
 29f2ff5:	mov    0x190(%rsp),%r11
 29f2ffd:	mov    0x28(%r11),%r11
 29f3001:	cmp    0x160(%r11),%r10d
 29f3008:	sete   %r10b
 29f300c:	movzbl %r10b,%r10d
 29f3010:	test   %r10d,%r10d
 29f3013:	jne    29f3263 <wasm[0]::function[1015]::helper::object_read+0x122e3>
 29f3019:	xor    %r10d,%r10d
 29f301c:	test   $0x1,%r9d
 29f3023:	jne    29f306b <wasm[0]::function[1015]::helper::object_read+0x120eb>
 29f3029:	mov    0x2e0(%rsp),%r12
 29f3031:	mov    0x28(%r12),%r10
 29f3036:	mov    0x20(%r12),%r11
 29f303b:	mov    %r9d,%ebx
 29f303e:	lea    0x4(%r11,%rbx,1),%r11
 29f3043:	xor    %r12,%r12
 29f3046:	cmp    %r10,%rbx
 29f3049:	cmova  %r12,%r11
 29f304d:	mov    (%r11),%r10d
 29f3050:	mov    0x190(%rsp),%r11
 29f3058:	mov    0x28(%r11),%r11
 29f305c:	cmp    0x15c(%r11),%r10d
 29f3063:	sete   %r10b
 29f3067:	movzbl %r10b,%r10d
 29f306b:	test   %r10d,%r10d
 29f306e:	je     29fc4cb <wasm[0]::function[1015]::helper::object_read+0x1b54b>
 29f3074:	test   %r9d,%r9d
 29f3077:	je     29fc4cd <wasm[0]::function[1015]::helper::object_read+0x1b54d>
 29f307d:	mov    0x2e0(%rsp),%r12
 29f3085:	mov    0x28(%r12),%rbx
 29f308a:	mov    0x20(%r12),%r12
 29f308f:	mov    %r9d,%r11d
 29f3092:	lea    (%r12,%r11,1),%r9
 29f3096:	xor    %r10,%r10
 29f3099:	cmp    %rbx,%r11
 29f309c:	cmova  %r10,%r9
 29f30a0:	mov    0x14(%r9),%r13d
 29f30a4:	mov    0x18(%r9),%r11d
 29f30a8:	mov    0x1c(%r9),%r9d
 29f30ac:	test   %r13d,%r13d
 29f30af:	je     29fc4cf <wasm[0]::function[1015]::helper::object_read+0x1b54f>
 29f30b5:	test   %r13d,%r13d
 29f30b8:	je     29fc4d1 <wasm[0]::function[1015]::helper::object_read+0x1b551>
 29f30be:	mov    %r13d,%r15d
 29f30c1:	lea    0x10(%r12,%r15,1),%r14
 29f30c6:	cmp    %rbx,%r15
 29f30c9:	cmova  %r10,%r14
 29f30cd:	mov    (%r14),%r14d
 29f30d0:	cmp    %r14d,%ecx
 29f30d3:	jae    29fc4d3 <wasm[0]::function[1015]::helper::object_read+0x1b553>
 29f30d9:	mov    %r14d,%r15d
 29f30dc:	shr    $0x20,%r15
 29f30e0:	test   %r15,%r15
 29f30e3:	jne    29fc4d5 <wasm[0]::function[1015]::helper::object_read+0x1b555>
 29f30e9:	add    $0x14,%r14d
 29f30ed:	jb     29fc4d7 <wasm[0]::function[1015]::helper::object_read+0x1b557>
 29f30f3:	add    %r14d,%r13d
 29f30f6:	jb     29fc4d9 <wasm[0]::function[1015]::helper::object_read+0x1b559>
 29f30fc:	mov    %r13d,%r13d
 29f30ff:	add    %r13,%r12
 29f3102:	cmp    %rbx,%r13
 29f3105:	cmova  %r10,%r12
 29f3109:	lea    0x14(%rcx),%ebx
 29f310c:	sub    %ebx,%r14d
 29f310f:	sub    %r14,%r12
 29f3112:	movzbq (%r12),%rbx
 29f3117:	test   %r11d,%r11d
 29f311a:	je     29f31b2 <wasm[0]::function[1015]::helper::object_read+0x12232>
 29f3120:	test   %r11d,%r11d
 29f3123:	je     29fc4db <wasm[0]::function[1015]::helper::object_read+0x1b55b>
 29f3129:	test   %r11d,%r11d
 29f312c:	je     29fc4dd <wasm[0]::function[1015]::helper::object_read+0x1b55d>
 29f3132:	mov    0x2e0(%rsp),%r12
 29f313a:	mov    0x28(%r12),%r10
 29f313f:	mov    0x20(%r12),%r12
 29f3144:	mov    %r11d,%r15d
 29f3147:	lea    0x10(%r12,%r15,1),%r14
 29f314c:	xor    %r13,%r13
 29f314f:	cmp    %r10,%r15
 29f3152:	cmova  %r13,%r14
 29f3156:	mov    (%r14),%r14d
 29f3159:	cmp    %r14d,%ecx
 29f315c:	jae    29fc4df <wasm[0]::function[1015]::helper::object_read+0x1b55f>
 29f3162:	mov    %r14d,%r15d
 29f3165:	shl    $0x3,%r15
 29f3169:	shr    $0x20,%r15
 29f316d:	test   %r15,%r15
 29f3170:	jne    29fc4e1 <wasm[0]::function[1015]::helper::object_read+0x1b561>
 29f3176:	shl    $0x3,%r14d
 29f317a:	add    $0x18,%r14d
 29f317e:	jb     29fc4e3 <wasm[0]::function[1015]::helper::object_read+0x1b563>
 29f3184:	add    %r14d,%r11d
 29f3187:	jb     29fc4e5 <wasm[0]::function[1015]::helper::object_read+0x1b565>
 29f318d:	mov    %r11d,%r15d
 29f3190:	lea    (%r12,%r15,1),%r11
 29f3194:	cmp    %r10,%r15
 29f3197:	cmova  %r13,%r11
 29f319b:	mov    %rcx,%r10
 29f319e:	shl    $0x3,%r10d
 29f31a2:	add    $0x18,%r10d
 29f31a9:	sub    %r10d,%r14d
 29f31ac:	sub    %r14,%r11
 29f31af:	mov    (%r11),%r10
 29f31b2:	xor    %r11d,%r11d
 29f31b5:	test   %r9d,%r9d
 29f31b8:	je     29f324b <wasm[0]::function[1015]::helper::object_read+0x122cb>
 29f31be:	test   %r9d,%r9d
 29f31c1:	je     29fc4e7 <wasm[0]::function[1015]::helper::object_read+0x1b567>
 29f31c7:	test   %r9d,%r9d
 29f31ca:	je     29fc4e9 <wasm[0]::function[1015]::helper::object_read+0x1b569>
 29f31d0:	mov    0x2e0(%rsp),%r12
 29f31d8:	mov    0x28(%r12),%r11
 29f31dd:	mov    0x20(%r12),%r12
 29f31e2:	mov    %r9d,%r15d
 29f31e5:	lea    0x10(%r12,%r15,1),%r14
 29f31ea:	xor    %r13,%r13
 29f31ed:	cmp    %r11,%r15
 29f31f0:	cmova  %r13,%r14
 29f31f4:	mov    (%r14),%r15d
 29f31f7:	cmp    %r15d,%ecx
 29f31fa:	jae    29fc4eb <wasm[0]::function[1015]::helper::object_read+0x1b56b>
 29f3200:	mov    %r15d,%r14d
 29f3203:	shl    $0x2,%r14
 29f3207:	shr    $0x20,%r14
 29f320b:	test   %r14,%r14
 29f320e:	jne    29fc4ed <wasm[0]::function[1015]::helper::object_read+0x1b56d>
 29f3214:	shl    $0x2,%r15d
 29f3218:	add    $0x14,%r15d
 29f321c:	jb     29fc4ef <wasm[0]::function[1015]::helper::object_read+0x1b56f>
 29f3222:	add    %r15d,%r9d
 29f3225:	jb     29fc4f1 <wasm[0]::function[1015]::helper::object_read+0x1b571>
 29f322b:	mov    %r9d,%r14d
 29f322e:	lea    (%r12,%r14,1),%r9
 29f3232:	cmp    %r11,%r14
 29f3235:	cmova  %r13,%r9
 29f3239:	shl    $0x2,%ecx
 29f323c:	add    $0x14,%ecx
 29f3242:	sub    %ecx,%r15d
 29f3245:	sub    %r15,%r9
 29f3248:	mov    (%r9),%r11d
 29f324b:	movzbl %bl,%ebx
 29f324e:	mov    %r10,0x200(%rsp)
 29f3256:	mov    %rbx,0x208(%rsp)
 29f325e:	jmp    29f33f0 <wasm[0]::function[1015]::helper::object_read+0x12470>
 29f3263:	xor    %r10d,%r10d
 29f3266:	test   $0x1,%r9d
 29f326d:	jne    29f32b5 <wasm[0]::function[1015]::helper::object_read+0x12335>
 29f3273:	mov    0x2e0(%rsp),%r12
 29f327b:	mov    0x28(%r12),%r10
 29f3280:	mov    0x20(%r12),%r11
 29f3285:	mov    %r9d,%ebx
 29f3288:	lea    0x4(%r11,%rbx,1),%r11
 29f328d:	xor    %r12,%r12
 29f3290:	cmp    %r10,%rbx
 29f3293:	cmova  %r12,%r11
 29f3297:	mov    (%r11),%r10d
 29f329a:	mov    0x190(%rsp),%r11
 29f32a2:	mov    0x28(%r11),%r11
 29f32a6:	cmp    0x160(%r11),%r10d
 29f32ad:	sete   %r10b
 29f32b1:	movzbl %r10b,%r10d
 29f32b5:	test   %r10d,%r10d
 29f32b8:	je     29fc4f3 <wasm[0]::function[1015]::helper::object_read+0x1b573>
 29f32be:	test   %r9d,%r9d
 29f32c1:	je     29fc4f5 <wasm[0]::function[1015]::helper::object_read+0x1b575>
 29f32c7:	mov    0x2e0(%rsp),%r12
 29f32cf:	mov    0x28(%r12),%r10
 29f32d4:	mov    0x20(%r12),%r11
 29f32d9:	mov    %r9d,%r9d
 29f32dc:	lea    (%r11,%r9,1),%r12
 29f32e0:	xor    %rbx,%rbx
 29f32e3:	cmp    %r10,%r9
 29f32e6:	cmova  %rbx,%r12
 29f32ea:	mov    0x10(%r12),%r12d
 29f32ef:	test   %r12d,%r12d
 29f32f2:	je     29fc4f7 <wasm[0]::function[1015]::helper::object_read+0x1b577>
 29f32f8:	test   %r12d,%r12d
 29f32fb:	je     29fc4f9 <wasm[0]::function[1015]::helper::object_read+0x1b579>
 29f3301:	mov    %r12d,%r13d
 29f3304:	lea    (%r11,%r13,1),%r12
 29f3308:	cmp    %r10,%r13
 29f330b:	cmova  %rbx,%r12
 29f330f:	mov    0x10(%r12),%r12d
 29f3314:	test   %r12d,%r12d
 29f3317:	je     29fc4fb <wasm[0]::function[1015]::helper::object_read+0x1b57b>
 29f331d:	test   %r12d,%r12d
 29f3320:	je     29fc4fd <wasm[0]::function[1015]::helper::object_read+0x1b57d>
 29f3326:	mov    %r12d,%r12d
 29f3329:	lea    0x10(%r11,%r12,1),%r11
 29f332e:	cmp    %r10,%r12
 29f3331:	cmova  %rbx,%r11
 29f3335:	cmp    (%r11),%ecx
 29f3338:	setae  %r10b
 29f333c:	cmp    $0x2,%ecx
 29f333f:	setae  %r11b
 29f3343:	or     %r11d,%r10d
 29f3346:	test   %r10b,%r10b
 29f3349:	jne    29fc4ff <wasm[0]::function[1015]::helper::object_read+0x1b57f>
 29f334f:	mov    0x2e0(%rsp),%r12
 29f3357:	mov    0x28(%r12),%r11
 29f335c:	mov    %r9,%r10
 29f335f:	add    0x20(%r12),%r10
 29f3364:	xor    %rbx,%rbx
 29f3367:	cmp    %r11,%r9
 29f336a:	cmova  %rbx,%r10
 29f336e:	mov    0x14(%r10),%ebx
 29f3372:	test   %ecx,%ecx
 29f3374:	je     29f33ae <wasm[0]::function[1015]::helper::object_read+0x1242e>
 29f337a:	mov    0x2e0(%rsp),%r12
 29f3382:	mov    0x28(%r12),%r10
 29f3387:	mov    0x20(%r12),%r11
 29f338c:	add    %r9,%r11
 29f338f:	xor    %r12,%r12
 29f3392:	cmp    %r10,%r9
 29f3395:	cmova  %r12,%r11
 29f3399:	mov    0x20(%r11),%r10
 29f339d:	mov    0x2c(%r11),%r11d
 29f33a1:	mov    %r10,0x200(%rsp)
 29f33a9:	jmp    29f33dd <wasm[0]::function[1015]::helper::object_read+0x1245d>
 29f33ae:	mov    0x2e0(%rsp),%r12
 29f33b6:	mov    0x28(%r12),%r10
 29f33bb:	mov    0x20(%r12),%r11
 29f33c0:	add    %r9,%r11
 29f33c3:	xor    %r12,%r12
 29f33c6:	cmp    %r10,%r9
 29f33c9:	cmova  %r12,%r11
 29f33cd:	mov    0x18(%r11),%r10
 29f33d1:	mov    %r10,0x200(%rsp)
 29f33d9:	mov    0x28(%r11),%r11d
 29f33dd:	shl    $0x3,%ecx
 29f33e0:	shr    %cl,%ebx
 29f33e2:	and    $0xff,%ebx
 29f33e8:	mov    %rbx,0x208(%rsp)
 29f33f0:	mov    %eax,0xc0(%rsp)
 29f33f7:	mov    %r8d,0x98(%rsp)
 29f33ff:	mov    %edx,0x78(%rsp)
 29f3403:	mov    %r11d,0xd8(%rsp)
 29f340b:	mov    %esi,0xa8(%rsp)
 29f3412:	mov    %edi,0xc8(%rsp)
 29f3419:	mov    $0x27c,%edx
 29f341e:	mov    0x190(%rsp),%rsi
 29f3426:	mov    0x190(%rsp),%rdi
 29f342e:	call   2f30600 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 29f3433:	mov    %eax,0x88(%rsp)
 29f343a:	xor    %r13d,%r13d
 29f343d:	test   %eax,%eax
 29f343f:	je     29fc501 <wasm[0]::function[1015]::helper::object_read+0x1b581>
 29f3445:	movl   $0x0,0xb0(%rsp)
 29f3450:	mov    0xc0(%rsp),%r9d
 29f3458:	mov    %r9,0x198(%rsp)
 29f3460:	mov    0x98(%rsp),%r9d
 29f3468:	mov    0x78(%rsp),%edx
 29f346c:	mov    0xd8(%rsp),%esi
 29f3473:	mov    0xa8(%rsp),%edi
 29f347a:	mov    0xc8(%rsp),%r8d
 29f3482:	xor    %r11,%r11
 29f3485:	mov    0x250(%rsp),%rax
 29f348d:	mov    0x250(%rsp),%rcx
 29f3495:	test   %al,%cl
 29f3497:	jne    29f34bd <wasm[0]::function[1015]::helper::object_read+0x1253d>
 29f349d:	mov    0x198(%rsp),%rax
 29f34a5:	mov    %r13,%rbx
 29f34a8:	mov    %r11,0x210(%rsp)
 29f34b0:	mov    %r13,0x218(%rsp)
 29f34b8:	jmp    29f407f <wasm[0]::function[1015]::helper::object_read+0x130ff>
 29f34bd:	mov    0xc0(%rsp),%r8d
 29f34c5:	mov    0x260(%rsp),%rcx
 29f34cd:	mov    0x258(%rsp),%rdx
 29f34d5:	mov    0x190(%rsp),%rsi
 29f34dd:	mov    0x190(%rsp),%rdi
 29f34e5:	call   2a5f680 <wasm[0]::function[1039]::helper::object_header_projection>
 29f34ea:	mov    %eax,0xb8(%rsp)
 29f34f1:	test   %eax,%eax
 29f34f3:	je     29fc503 <wasm[0]::function[1015]::helper::object_read+0x1b583>
 29f34f9:	test   %eax,%eax
 29f34fb:	je     29fc505 <wasm[0]::function[1015]::helper::object_read+0x1b585>
 29f3501:	mov    0x2e0(%rsp),%r12
 29f3509:	mov    0x28(%r12),%rcx
 29f350e:	mov    0x20(%r12),%rsi
 29f3513:	mov    %eax,%edx
 29f3515:	lea    (%rsi,%rdx,1),%rax
 29f3519:	xor    %rsi,%rsi
 29f351c:	cmp    %rcx,%rdx
 29f351f:	cmova  %rsi,%rax
 29f3523:	mov    0x14(%rax),%eax
 29f3526:	mov    %eax,0xd0(%rsp)
 29f352d:	test   %eax,%eax
 29f352f:	je     29fc507 <wasm[0]::function[1015]::helper::object_read+0x1b587>
 29f3535:	mov    0xd0(%rsp),%ecx
 29f353c:	xor    %eax,%eax
 29f353e:	test   $0x1,%ecx
 29f3544:	jne    29f359e <wasm[0]::function[1015]::helper::object_read+0x1261e>
 29f354a:	mov    0x2e0(%rsp),%r12
 29f3552:	mov    0x28(%r12),%rax
 29f3557:	mov    0x20(%r12),%rsi
 29f355c:	mov    %ecx,%edx
 29f355e:	lea    0x4(%rsi,%rdx,1),%rcx
 29f3563:	xor    %rsi,%rsi
 29f3566:	cmp    %rax,%rdx
 29f3569:	cmova  %rsi,%rcx
 29f356d:	mov    (%rcx),%esi
 29f356f:	mov    0x190(%rsp),%rax
 29f3577:	mov    0x28(%rax),%rax
 29f357b:	mov    0x158(%rax),%edx
 29f3581:	cmp    %edx,%esi
 29f3583:	sete   %al
 29f3586:	movzbl %al,%eax
 29f3589:	cmp    %edx,%esi
 29f358b:	je     29f359e <wasm[0]::function[1015]::helper::object_read+0x1261e>
 29f3591:	mov    0x190(%rsp),%rdi
 29f3599:	call   3018cd5 <wasmtime_builtin_is_subtype>
 29f359e:	test   %eax,%eax
 29f35a0:	jne    29f37fa <wasm[0]::function[1015]::helper::object_read+0x1287a>
 29f35a6:	mov    0xb8(%rsp),%edx
 29f35ad:	xor    %r12d,%r12d
 29f35b0:	test   %edx,%edx
 29f35b2:	je     29fc509 <wasm[0]::function[1015]::helper::object_read+0x1b589>
 29f35b8:	mov    0x88(%rsp),%r9d
 29f35c0:	mov    $0x4,%ecx
 29f35c5:	xor    %r8,%r8
 29f35c8:	mov    0x190(%rsp),%rsi
 29f35d0:	mov    0x190(%rsp),%rdi
 29f35d8:	call   2a58e80 <wasm[0]::function[1032]::helper::ordinary_property_find>
 29f35dd:	test   %eax,%eax
 29f35df:	je     29f361a <wasm[0]::function[1015]::helper::object_read+0x1269a>
 29f35e5:	test   %eax,%eax
 29f35e7:	je     29fc50b <wasm[0]::function[1015]::helper::object_read+0x1b58b>
 29f35ed:	test   %eax,%eax
 29f35ef:	je     29fc50d <wasm[0]::function[1015]::helper::object_read+0x1b58d>
 29f35f5:	mov    0x2e0(%rsp),%r12
 29f35fd:	mov    0x28(%r12),%rcx
 29f3602:	mov    %eax,%edx
 29f3604:	mov    %rdx,%rax
 29f3607:	add    0x20(%r12),%rax
 29f360c:	xor    %rsi,%rsi
 29f360f:	cmp    %rcx,%rdx
 29f3612:	cmova  %rsi,%rax
 29f3616:	mov    0x14(%rax),%r12d
 29f361a:	mov    0xb0(%rsp),%ebx
 29f3621:	xor    %r11,%r11
 29f3624:	xor    %r13d,%r13d
 29f3627:	test   %r12d,%r12d
 29f362a:	je     29f37b3 <wasm[0]::function[1015]::helper::object_read+0x12833>
 29f3630:	test   %r12d,%r12d
 29f3633:	je     29fc50f <wasm[0]::function[1015]::helper::object_read+0x1b58f>
 29f3639:	mov    0x2e0(%rsp),%rax
 29f3641:	mov    0x28(%rax),%rcx
 29f3645:	mov    0x20(%rax),%rax
 29f3649:	mov    %r12d,%edx
 29f364c:	add    %rdx,%rax
 29f364f:	xor    %r11,%r11
 29f3652:	cmp    %rcx,%rdx
 29f3655:	cmova  %r11,%rax
 29f3659:	mov    0x10(%rax),%ecx
 29f365c:	mov    0xb0(%rsp),%ebx
 29f3663:	xor    %r13d,%r13d
 29f3666:	test   $0x1,%ecx
 29f366c:	jne    29f37b3 <wasm[0]::function[1015]::helper::object_read+0x12833>
 29f3672:	mov    0x14(%rax),%edx
 29f3675:	test   %edx,%edx
 29f3677:	je     29fc511 <wasm[0]::function[1015]::helper::object_read+0x1b591>
 29f367d:	xor    %eax,%eax
 29f367f:	test   $0x1,%edx
 29f3685:	jne    29f36cd <wasm[0]::function[1015]::helper::object_read+0x1274d>
 29f368b:	mov    0x2e0(%rsp),%r12
 29f3693:	mov    0x28(%r12),%r9
 29f3698:	mov    0x20(%r12),%r11
 29f369d:	mov    %edx,%r10d
 29f36a0:	lea    0x4(%r11,%r10,1),%rsi
 29f36a5:	xor    %r11,%r11
 29f36a8:	cmp    %r9,%r10
 29f36ab:	cmova  %r11,%rsi
 29f36af:	mov    (%rsi),%r10d
 29f36b2:	mov    0x190(%rsp),%rsi
 29f36ba:	mov    0x28(%rsi),%r11
 29f36be:	cmp    0x120(%r11),%r10d
 29f36c5:	sete   %r11b
 29f36c9:	movzbl %r11b,%eax
 29f36cd:	test   %eax,%eax
 29f36cf:	jne    29f372c <wasm[0]::function[1015]::helper::object_read+0x127ac>
 29f36d5:	mov    0x190(%rsp),%rsi
 29f36dd:	mov    0x190(%rsp),%rdi
 29f36e5:	call   2a01c00 <wasm[0]::function[1024]::helper::property_value_resolve>
 29f36ea:	test   %eax,%eax
 29f36ec:	je     29fc513 <wasm[0]::function[1015]::helper::object_read+0x1b593>
 29f36f2:	test   %eax,%eax
 29f36f4:	je     29fc515 <wasm[0]::function[1015]::helper::object_read+0x1b595>
 29f36fa:	mov    0x2e0(%rsp),%r12
 29f3702:	mov    0x28(%r12),%rcx
 29f3707:	mov    0x20(%r12),%rsi
 29f370c:	mov    %eax,%edx
 29f370e:	lea    (%rsi,%rdx,1),%rax
 29f3712:	xor    %rsi,%rsi
 29f3715:	cmp    %rcx,%rdx
 29f3718:	cmova  %rsi,%rax
 29f371c:	mov    0x18(%rax),%r13d
 29f3720:	mov    0x10(%rax),%r11
 29f3724:	mov    0x1c(%rax),%ebx
 29f3727:	jmp    29f37b3 <wasm[0]::function[1015]::helper::object_read+0x12833>
 29f372c:	xor    %eax,%eax
 29f372e:	test   $0x1,%edx
 29f3734:	jne    29f3777 <wasm[0]::function[1015]::helper::object_read+0x127f7>
 29f373a:	mov    0x2e0(%rsp),%r12
 29f3742:	mov    0x28(%r12),%rax
 29f3747:	mov    0x20(%r12),%rcx
 29f374c:	mov    %edx,%esi
 29f374e:	lea    0x4(%rcx,%rsi,1),%rcx
 29f3753:	xor    %rdi,%rdi
 29f3756:	cmp    %rax,%rsi
 29f3759:	cmova  %rdi,%rcx
 29f375d:	mov    (%rcx),%eax
 29f375f:	mov    0x190(%rsp),%rsi
 29f3767:	mov    0x28(%rsi),%rcx
 29f376b:	cmp    0x120(%rcx),%eax
 29f3771:	sete   %al
 29f3774:	movzbl %al,%eax
 29f3777:	test   %eax,%eax
 29f3779:	je     29fc517 <wasm[0]::function[1015]::helper::object_read+0x1b597>
 29f377f:	test   %edx,%edx
 29f3781:	je     29fc519 <wasm[0]::function[1015]::helper::object_read+0x1b599>
 29f3787:	mov    0x2e0(%rsp),%r12
 29f378f:	mov    0x28(%r12),%rcx
 29f3794:	mov    0x20(%r12),%rax
 29f3799:	mov    %edx,%edx
 29f379b:	add    %rdx,%rax
 29f379e:	xor    %rsi,%rsi
 29f37a1:	cmp    %rcx,%rdx
 29f37a4:	cmova  %rsi,%rax
 29f37a8:	mov    0x18(%rax),%r13d
 29f37ac:	mov    0x10(%rax),%r11
 29f37b0:	mov    0x1c(%rax),%ebx
 29f37b3:	mov    0xc0(%rsp),%r9d
 29f37bb:	mov    %r9,0x198(%rsp)
 29f37c3:	mov    0x98(%rsp),%r9d
 29f37cb:	mov    0x78(%rsp),%edx
 29f37cf:	mov    0xd8(%rsp),%esi
 29f37d6:	mov    0xa8(%rsp),%edi
 29f37dd:	mov    0xc8(%rsp),%r8d
 29f37e5:	mov    %r11,0x210(%rsp)
 29f37ed:	mov    %r13,0x218(%rsp)
 29f37f5:	jmp    29f4077 <wasm[0]::function[1015]::helper::object_read+0x130f7>
 29f37fa:	mov    0xd0(%rsp),%eax
 29f3801:	test   %eax,%eax
 29f3803:	je     29fc51b <wasm[0]::function[1015]::helper::object_read+0x1b59b>
 29f3809:	mov    0xd0(%rsp),%ecx
 29f3810:	xor    %eax,%eax
 29f3812:	test   $0x1,%ecx
 29f3818:	jne    29f3872 <wasm[0]::function[1015]::helper::object_read+0x128f2>
 29f381e:	mov    0x2e0(%rsp),%r12
 29f3826:	mov    0x28(%r12),%rax
 29f382b:	mov    0x20(%r12),%rsi
 29f3830:	mov    %ecx,%edx
 29f3832:	lea    0x4(%rsi,%rdx,1),%rcx
 29f3837:	xor    %rsi,%rsi
 29f383a:	cmp    %rax,%rdx
 29f383d:	cmova  %rsi,%rcx
 29f3841:	mov    (%rcx),%esi
 29f3843:	mov    0x190(%rsp),%rax
 29f384b:	mov    0x28(%rax),%rax
 29f384f:	mov    0x158(%rax),%edx
 29f3855:	cmp    %edx,%esi
 29f3857:	sete   %al
 29f385a:	movzbl %al,%eax
 29f385d:	cmp    %edx,%esi
 29f385f:	je     29f3872 <wasm[0]::function[1015]::helper::object_read+0x128f2>
 29f3865:	mov    0x190(%rsp),%rdi
 29f386d:	call   3018cd5 <wasmtime_builtin_is_subtype>
 29f3872:	test   %eax,%eax
 29f3874:	je     29fc51d <wasm[0]::function[1015]::helper::object_read+0x1b59d>
 29f387a:	mov    0xd0(%rsp),%r10d
 29f3882:	mov    0xc0(%rsp),%r9d
 29f388a:	mov    %r9,0x198(%rsp)
 29f3892:	mov    0x98(%rsp),%r9d
 29f389a:	mov    0x78(%rsp),%edx
 29f389e:	mov    0xd8(%rsp),%esi
 29f38a5:	mov    0xb0(%rsp),%ebx
 29f38ac:	mov    0xa8(%rsp),%edi
 29f38b3:	mov    0xc8(%rsp),%r8d
 29f38bb:	xor    %ecx,%ecx
 29f38bd:	mov    %rcx,%r15
 29f38c0:	test   %r10d,%r10d
 29f38c3:	je     29fc51f <wasm[0]::function[1015]::helper::object_read+0x1b59f>
 29f38c9:	test   %r10d,%r10d
 29f38cc:	je     29fc521 <wasm[0]::function[1015]::helper::object_read+0x1b5a1>
 29f38d2:	mov    0x2e0(%rsp),%r12
 29f38da:	mov    0x28(%r12),%rax
 29f38df:	mov    0x20(%r12),%rcx
 29f38e4:	mov    %r10d,%r13d
 29f38e7:	lea    (%rcx,%r13,1),%r11
 29f38eb:	xor    %r12,%r12
 29f38ee:	cmp    %rax,%r13
 29f38f1:	cmova  %r12,%r11
 29f38f5:	mov    0x10(%r11),%r11d
 29f38f9:	test   %r11d,%r11d
 29f38fc:	je     29fc523 <wasm[0]::function[1015]::helper::object_read+0x1b5a3>
 29f3902:	test   %r11d,%r11d
 29f3905:	je     29fc525 <wasm[0]::function[1015]::helper::object_read+0x1b5a5>
 29f390b:	mov    %r11d,%r13d
 29f390e:	lea    (%rcx,%r13,1),%r11
 29f3912:	cmp    %rax,%r13
 29f3915:	cmova  %r12,%r11
 29f3919:	mov    0x10(%r11),%r11d
 29f391d:	test   %r11d,%r11d
 29f3920:	je     29fc527 <wasm[0]::function[1015]::helper::object_read+0x1b5a7>
 29f3926:	test   %r11d,%r11d
 29f3929:	je     29fc529 <wasm[0]::function[1015]::helper::object_read+0x1b5a9>
 29f392f:	mov    %r11d,%r13d
 29f3932:	lea    0x10(%rcx,%r13,1),%rcx
 29f3937:	cmp    %rax,%r13
 29f393a:	cmova  %r12,%rcx
 29f393e:	mov    (%rcx),%r13d
 29f3941:	mov    0x88(%rsp),%r12d
 29f3949:	mov    0x190(%rsp),%rax
 29f3951:	mov    0x28(%rax),%rax
 29f3955:	mov    0x234(%rax),%r14d
 29f395c:	mov    %r15,0x1c8(%rsp)
 29f3964:	mov    %r11d,0xb8(%rsp)
 29f396c:	mov    %r12d,0xc8(%rsp)
 29f3974:	mov    %r10d,0xa8(%rsp)
 29f397c:	mov    0x198(%rsp),%rcx
 29f3984:	mov    %ecx,0xb0(%rsp)
 29f398b:	mov    %r9d,0xd8(%rsp)
 29f3993:	mov    %edx,0x78(%rsp)
 29f3997:	mov    %esi,0x98(%rsp)
 29f399e:	mov    %ebx,0xc0(%rsp)
 29f39a5:	mov    %edi,0xd0(%rsp)
 29f39ac:	mov    %r8d,0x88(%rsp)
 29f39b4:	mov    0x2e8(%rsp),%rax
 29f39bc:	mov    (%rax),%rcx
 29f39bf:	mov    0x228(%rsp),%rax
 29f39c7:	cmp    %rax,%rcx
 29f39ca:	jae    29fb4ae <wasm[0]::function[1015]::helper::object_read+0x1a52e>
 29f39d0:	mov    0xa8(%rsp),%r10d
 29f39d8:	mov    0xb0(%rsp),%r9d
 29f39e0:	mov    %r9,0x198(%rsp)
 29f39e8:	mov    0xd8(%rsp),%r9d
 29f39f0:	mov    0x78(%rsp),%edx
 29f39f4:	mov    0x98(%rsp),%esi
 29f39fb:	mov    0xc0(%rsp),%ebx
 29f3a02:	mov    0xd0(%rsp),%edi
 29f3a09:	mov    0x88(%rsp),%r8d
 29f3a11:	mov    %r15,%rcx
 29f3a14:	cmp    %r13d,%ecx
 29f3a17:	jb     29f3a2a <wasm[0]::function[1015]::helper::object_read+0x12aaa>
 29f3a1d:	mov    0x1c8(%rsp),%rax
 29f3a25:	jmp    29f3c25 <wasm[0]::function[1015]::helper::object_read+0x12ca5>
 29f3a2a:	mov    0xb8(%rsp),%r11d
 29f3a32:	test   %r11d,%r11d
 29f3a35:	je     29fc52b <wasm[0]::function[1015]::helper::object_read+0x1b5ab>
 29f3a3b:	test   %r11d,%r11d
 29f3a3e:	je     29fc52d <wasm[0]::function[1015]::helper::object_read+0x1b5ad>
 29f3a44:	mov    0x2e0(%rsp),%r12
 29f3a4c:	mov    0x28(%r12),%rax
 29f3a51:	mov    0x20(%r12),%rdx
 29f3a56:	mov    %r11d,%r8d
 29f3a59:	lea    0x10(%rdx,%r8,1),%rdi
 29f3a5e:	xor    %rsi,%rsi
 29f3a61:	cmp    %rax,%r8
 29f3a64:	cmova  %rsi,%rdi
 29f3a68:	mov    (%rdi),%edi
 29f3a6a:	cmp    %edi,%ecx
 29f3a6c:	jae    29fc52f <wasm[0]::function[1015]::helper::object_read+0x1b5af>
 29f3a72:	mov    %edi,%r8d
 29f3a75:	shl    $0x2,%r8
 29f3a79:	shr    $0x20,%r8
 29f3a7d:	test   %r8,%r8
 29f3a80:	jne    29fc531 <wasm[0]::function[1015]::helper::object_read+0x1b5b1>
 29f3a86:	shl    $0x2,%edi
 29f3a89:	add    $0x14,%edi
 29f3a8c:	jb     29fc533 <wasm[0]::function[1015]::helper::object_read+0x1b5b3>
 29f3a92:	add    %edi,%r11d
 29f3a95:	jb     29fc535 <wasm[0]::function[1015]::helper::object_read+0x1b5b5>
 29f3a9b:	mov    %r11d,%r8d
 29f3a9e:	add    %r8,%rdx
 29f3aa1:	cmp    %rax,%r8
 29f3aa4:	cmova  %rsi,%rdx
 29f3aa8:	mov    %rcx,%rax
 29f3aab:	shl    $0x2,%eax
 29f3aae:	mov    %rcx,%r15
 29f3ab1:	add    $0x14,%eax
 29f3ab7:	sub    %eax,%edi
 29f3ab9:	sub    %rdi,%rdx
 29f3abc:	mov    (%rdx),%edx
 29f3abe:	test   %edx,%edx
 29f3ac0:	je     29fc537 <wasm[0]::function[1015]::helper::object_read+0x1b5b7>
 29f3ac6:	mov    0xc8(%rsp),%eax
 29f3acd:	cmp    %eax,%edx
 29f3acf:	je     29f3ba3 <wasm[0]::function[1015]::helper::object_read+0x12c23>
 29f3ad5:	xor    %ecx,%ecx
 29f3ad7:	test   %edx,%edx
 29f3ad9:	je     29f3b1b <wasm[0]::function[1015]::helper::object_read+0x12b9b>
 29f3adf:	xor    %ecx,%ecx
 29f3ae1:	test   $0x1,%edx
 29f3ae7:	jne    29f3b1b <wasm[0]::function[1015]::helper::object_read+0x12b9b>
 29f3aed:	mov    0x2e0(%rsp),%r12
 29f3af5:	mov    0x28(%r12),%rcx
 29f3afa:	mov    0x20(%r12),%rsi
 29f3aff:	mov    %edx,%edi
 29f3b01:	lea    0x4(%rsi,%rdi,1),%rsi
 29f3b06:	xor    %r8,%r8
 29f3b09:	cmp    %rcx,%rdi
 29f3b0c:	cmova  %r8,%rsi
 29f3b10:	mov    (%rsi),%ecx
 29f3b12:	cmp    %r14d,%ecx
 29f3b15:	sete   %cl
 29f3b18:	movzbl %cl,%ecx
 29f3b1b:	test   %ecx,%ecx
 29f3b1d:	je     29fc539 <wasm[0]::function[1015]::helper::object_read+0x1b5b9>
 29f3b23:	xor    %ecx,%ecx
 29f3b25:	test   %eax,%eax
 29f3b27:	je     29f3b6f <wasm[0]::function[1015]::helper::object_read+0x12bef>
 29f3b2d:	mov    0xc8(%rsp),%eax
 29f3b34:	xor    %ecx,%ecx
 29f3b36:	test   $0x1,%eax
 29f3b3b:	jne    29f3b6f <wasm[0]::function[1015]::helper::object_read+0x12bef>
 29f3b41:	mov    0x2e0(%rsp),%r12
 29f3b49:	mov    0x28(%r12),%rcx
 29f3b4e:	mov    0x20(%r12),%rdi
 29f3b53:	mov    %eax,%esi
 29f3b55:	lea    0x4(%rdi,%rsi,1),%rax
 29f3b5a:	xor    %rdi,%rdi
 29f3b5d:	cmp    %rcx,%rsi
 29f3b60:	cmova  %rdi,%rax
 29f3b64:	mov    (%rax),%eax
 29f3b66:	cmp    %r14d,%eax
 29f3b69:	sete   %al
 29f3b6c:	movzbl %al,%ecx
 29f3b6f:	test   %ecx,%ecx
 29f3b71:	je     29fc53b <wasm[0]::function[1015]::helper::object_read+0x1b5bb>
 29f3b77:	mov    0xc8(%rsp),%ecx
 29f3b7e:	xor    %r8d,%r8d
 29f3b81:	test   %ecx,%ecx
 29f3b83:	je     29fc53d <wasm[0]::function[1015]::helper::object_read+0x1b5bd>
 29f3b89:	mov    0x190(%rsp),%rsi
 29f3b91:	mov    0x190(%rsp),%rdi
 29f3b99:	call   2ae5540 <wasm[0]::function[1057]::helper::string_equality>
 29f3b9e:	jmp    29f3bab <wasm[0]::function[1015]::helper::object_read+0x12c2b>
 29f3ba3:	mov    0x278(%rsp),%rax
 29f3bab:	mov    0xb8(%rsp),%r11d
 29f3bb3:	mov    0xc8(%rsp),%r12d
 29f3bbb:	mov    0xa8(%rsp),%r10d
 29f3bc3:	mov    0xb0(%rsp),%r9d
 29f3bcb:	mov    %r9,0x198(%rsp)
 29f3bd3:	mov    0xd8(%rsp),%r9d
 29f3bdb:	mov    0x78(%rsp),%edx
 29f3bdf:	mov    0x98(%rsp),%esi
 29f3be6:	mov    0xc0(%rsp),%ebx
 29f3bed:	mov    0xd0(%rsp),%edi
 29f3bf4:	mov    0x88(%rsp),%r8d
 29f3bfc:	test   %eax,%eax
 29f3bfe:	je     29f3c0c <wasm[0]::function[1015]::helper::object_read+0x12c8c>
 29f3c04:	mov    %r15,%rcx
 29f3c07:	jmp    29f3c25 <wasm[0]::function[1015]::helper::object_read+0x12ca5>
 29f3c0c:	mov    %r15,%rcx
 29f3c0f:	add    $0x1,%ecx
 29f3c15:	mov    %rcx,%r15
 29f3c18:	mov    %rax,0x1c8(%rsp)
 29f3c20:	jmp    29f3964 <wasm[0]::function[1015]::helper::object_read+0x129e4>
 29f3c25:	xor    %r11,%r11
 29f3c28:	xor    %r13d,%r13d
 29f3c2b:	test   %eax,%eax
 29f3c2d:	jne    29f3c48 <wasm[0]::function[1015]::helper::object_read+0x12cc8>
 29f3c33:	mov    %r11,0x210(%rsp)
 29f3c3b:	mov    %r13,0x218(%rsp)
 29f3c43:	jmp    29f4077 <wasm[0]::function[1015]::helper::object_read+0x130f7>
 29f3c48:	test   %r10d,%r10d
 29f3c4b:	je     29fc53f <wasm[0]::function[1015]::helper::object_read+0x1b5bf>
 29f3c51:	xor    %eax,%eax
 29f3c53:	test   $0x1,%r10d
 29f3c5a:	jne    29f3ca0 <wasm[0]::function[1015]::helper::object_read+0x12d20>
 29f3c60:	mov    0x2e0(%rsp),%r12
 29f3c68:	mov    0x28(%r12),%rax
 29f3c6d:	mov    0x20(%r12),%r11
 29f3c72:	mov    %r10d,%ebx
 29f3c75:	lea    0x4(%r11,%rbx,1),%r11
 29f3c7a:	xor    %r12,%r12
 29f3c7d:	cmp    %rax,%rbx
 29f3c80:	cmova  %r12,%r11
 29f3c84:	mov    (%r11),%eax
 29f3c87:	mov    0x190(%rsp),%r11
 29f3c8f:	mov    0x28(%r11),%r11
 29f3c93:	cmp    0x160(%r11),%eax
 29f3c9a:	sete   %al
 29f3c9d:	movzbl %al,%eax
 29f3ca0:	test   %eax,%eax
 29f3ca2:	jne    29f3eea <wasm[0]::function[1015]::helper::object_read+0x12f6a>
 29f3ca8:	xor    %eax,%eax
 29f3caa:	test   $0x1,%r10d
 29f3cb1:	jne    29f3cf7 <wasm[0]::function[1015]::helper::object_read+0x12d77>
 29f3cb7:	mov    0x2e0(%rsp),%r12
 29f3cbf:	mov    0x28(%r12),%rax
 29f3cc4:	mov    0x20(%r12),%r11
 29f3cc9:	mov    %r10d,%ebx
 29f3ccc:	lea    0x4(%r11,%rbx,1),%r11
 29f3cd1:	xor    %r12,%r12
 29f3cd4:	cmp    %rax,%rbx
 29f3cd7:	cmova  %r12,%r11
 29f3cdb:	mov    (%r11),%eax
 29f3cde:	mov    0x190(%rsp),%r11
 29f3ce6:	mov    0x28(%r11),%r11
 29f3cea:	cmp    0x15c(%r11),%eax
 29f3cf1:	sete   %al
 29f3cf4:	movzbl %al,%eax
 29f3cf7:	test   %eax,%eax
 29f3cf9:	je     29fc541 <wasm[0]::function[1015]::helper::object_read+0x1b5c1>
 29f3cff:	test   %r10d,%r10d
 29f3d02:	je     29fc543 <wasm[0]::function[1015]::helper::object_read+0x1b5c3>
 29f3d08:	mov    0x2e0(%rsp),%r12
 29f3d10:	mov    0x28(%r12),%rax
 29f3d15:	mov    0x20(%r12),%rbx
 29f3d1a:	mov    %r10d,%r12d
 29f3d1d:	lea    (%rbx,%r12,1),%r10
 29f3d21:	xor    %r11,%r11
 29f3d24:	cmp    %rax,%r12
 29f3d27:	cmova  %r11,%r10
 29f3d2b:	mov    0x14(%r10),%r12d
 29f3d2f:	mov    0x18(%r10),%r14d
 29f3d33:	mov    0x1c(%r10),%r10d
 29f3d37:	test   %r12d,%r12d
 29f3d3a:	je     29fc545 <wasm[0]::function[1015]::helper::object_read+0x1b5c5>
 29f3d40:	test   %r12d,%r12d
 29f3d43:	je     29fc547 <wasm[0]::function[1015]::helper::object_read+0x1b5c7>
 29f3d49:	mov    %r12d,%r15d
 29f3d4c:	lea    0x10(%rbx,%r15,1),%r13
 29f3d51:	cmp    %rax,%r15
 29f3d54:	cmova  %r11,%r13
 29f3d58:	mov    0x0(%r13),%r13d
 29f3d5c:	cmp    %r13d,%ecx
 29f3d5f:	jae    29fc549 <wasm[0]::function[1015]::helper::object_read+0x1b5c9>
 29f3d65:	mov    %r13d,%r15d
 29f3d68:	shr    $0x20,%r15
 29f3d6c:	test   %r15,%r15
 29f3d6f:	jne    29fc54b <wasm[0]::function[1015]::helper::object_read+0x1b5cb>
 29f3d75:	add    $0x14,%r13d
 29f3d79:	jb     29fc54d <wasm[0]::function[1015]::helper::object_read+0x1b5cd>
 29f3d7f:	add    %r13d,%r12d
 29f3d82:	jb     29fc54f <wasm[0]::function[1015]::helper::object_read+0x1b5cf>
 29f3d88:	mov    %r12d,%r12d
 29f3d8b:	add    %r12,%rbx
 29f3d8e:	cmp    %rax,%r12
 29f3d91:	cmova  %r11,%rbx
 29f3d95:	lea    0x14(%rcx),%eax
 29f3d98:	sub    %eax,%r13d
 29f3d9b:	sub    %r13,%rbx
 29f3d9e:	movzbq (%rbx),%r15
 29f3da2:	test   %r14d,%r14d
 29f3da5:	je     29f3e3b <wasm[0]::function[1015]::helper::object_read+0x12ebb>
 29f3dab:	test   %r14d,%r14d
 29f3dae:	je     29fc551 <wasm[0]::function[1015]::helper::object_read+0x1b5d1>
 29f3db4:	test   %r14d,%r14d
 29f3db7:	je     29fc553 <wasm[0]::function[1015]::helper::object_read+0x1b5d3>
 29f3dbd:	mov    0x2e0(%rsp),%r12
 29f3dc5:	mov    0x28(%r12),%rax
 29f3dca:	mov    0x20(%r12),%r11
 29f3dcf:	mov    %r14d,%r13d
 29f3dd2:	lea    0x10(%r11,%r13,1),%r12
 29f3dd7:	xor    %rbx,%rbx
 29f3dda:	cmp    %rax,%r13
 29f3ddd:	cmova  %rbx,%r12
 29f3de1:	mov    (%r12),%r12d
 29f3de5:	cmp    %r12d,%ecx
 29f3de8:	jae    29fc555 <wasm[0]::function[1015]::helper::object_read+0x1b5d5>
 29f3dee:	mov    %r12d,%r13d
 29f3df1:	shl    $0x3,%r13
 29f3df5:	shr    $0x20,%r13
 29f3df9:	test   %r13,%r13
 29f3dfc:	jne    29fc557 <wasm[0]::function[1015]::helper::object_read+0x1b5d7>
 29f3e02:	shl    $0x3,%r12d
 29f3e06:	add    $0x18,%r12d
 29f3e0a:	jb     29fc559 <wasm[0]::function[1015]::helper::object_read+0x1b5d9>
 29f3e10:	add    %r12d,%r14d
 29f3e13:	jb     29fc55b <wasm[0]::function[1015]::helper::object_read+0x1b5db>
 29f3e19:	mov    %r14d,%r13d
 29f3e1c:	add    %r13,%r11
 29f3e1f:	cmp    %rax,%r13
 29f3e22:	cmova  %rbx,%r11
 29f3e26:	mov    %rcx,%rax
 29f3e29:	shl    $0x3,%eax
 29f3e2c:	add    $0x18,%eax
 29f3e32:	sub    %eax,%r12d
 29f3e35:	sub    %r12,%r11
 29f3e38:	mov    (%r11),%r11
 29f3e3b:	xor    %ebx,%ebx
 29f3e3d:	test   %r10d,%r10d
 29f3e40:	je     29f3ed1 <wasm[0]::function[1015]::helper::object_read+0x12f51>
 29f3e46:	test   %r10d,%r10d
 29f3e49:	je     29fc55d <wasm[0]::function[1015]::helper::object_read+0x1b5dd>
 29f3e4f:	test   %r10d,%r10d
 29f3e52:	je     29fc55f <wasm[0]::function[1015]::helper::object_read+0x1b5df>
 29f3e58:	mov    0x2e0(%rsp),%r12
 29f3e60:	mov    0x28(%r12),%rax
 29f3e65:	mov    0x20(%r12),%r14
 29f3e6a:	mov    %r10d,%r13d
 29f3e6d:	lea    0x10(%r14,%r13,1),%r12
 29f3e72:	xor    %rbx,%rbx
 29f3e75:	cmp    %rax,%r13
 29f3e78:	cmova  %rbx,%r12
 29f3e7c:	mov    (%r12),%r12d
 29f3e80:	cmp    %r12d,%ecx
 29f3e83:	jae    29fc561 <wasm[0]::function[1015]::helper::object_read+0x1b5e1>
 29f3e89:	mov    %r12d,%r13d
 29f3e8c:	shl    $0x2,%r13
 29f3e90:	shr    $0x20,%r13
 29f3e94:	test   %r13,%r13
 29f3e97:	jne    29fc563 <wasm[0]::function[1015]::helper::object_read+0x1b5e3>
 29f3e9d:	shl    $0x2,%r12d
 29f3ea1:	add    $0x14,%r12d
 29f3ea5:	jb     29fc565 <wasm[0]::function[1015]::helper::object_read+0x1b5e5>
 29f3eab:	add    %r12d,%r10d
 29f3eae:	jb     29fc567 <wasm[0]::function[1015]::helper::object_read+0x1b5e7>
 29f3eb4:	mov    %r10d,%r13d
 29f3eb7:	lea    (%r14,%r13,1),%r10
 29f3ebb:	cmp    %rax,%r13
 29f3ebe:	cmova  %rbx,%r10
 29f3ec2:	shl    $0x2,%ecx
 29f3ec5:	lea    0x14(%rcx),%eax
 29f3ec8:	sub    %eax,%r12d
 29f3ecb:	sub    %r12,%r10
 29f3ece:	mov    (%r10),%ebx
 29f3ed1:	movzbl %r15b,%r13d
 29f3ed5:	mov    %r11,0x210(%rsp)
 29f3edd:	mov    %r13,0x218(%rsp)
 29f3ee5:	jmp    29f4077 <wasm[0]::function[1015]::helper::object_read+0x130f7>
 29f3eea:	xor    %r11d,%r11d
 29f3eed:	test   $0x1,%r10d
 29f3ef4:	jne    29f3f3b <wasm[0]::function[1015]::helper::object_read+0x12fbb>
 29f3efa:	mov    0x2e0(%rsp),%r12
 29f3f02:	mov    0x28(%r12),%rax
 29f3f07:	mov    0x20(%r12),%r11
 29f3f0c:	mov    %r10d,%ebx
 29f3f0f:	lea    0x4(%r11,%rbx,1),%r11
 29f3f14:	xor    %r12,%r12
 29f3f17:	cmp    %rax,%rbx
 29f3f1a:	cmova  %r12,%r11
 29f3f1e:	mov    (%r11),%eax
 29f3f21:	mov    0x190(%rsp),%r11
 29f3f29:	mov    0x28(%r11),%r11
 29f3f2d:	cmp    0x160(%r11),%eax
 29f3f34:	sete   %al
 29f3f37:	movzbl %al,%r11d
 29f3f3b:	test   %r11d,%r11d
 29f3f3e:	je     29fc569 <wasm[0]::function[1015]::helper::object_read+0x1b5e9>
 29f3f44:	test   %r10d,%r10d
 29f3f47:	je     29fc56b <wasm[0]::function[1015]::helper::object_read+0x1b5eb>
 29f3f4d:	mov    0x2e0(%rsp),%r12
 29f3f55:	mov    0x28(%r12),%r11
 29f3f5a:	mov    0x20(%r12),%rbx
 29f3f5f:	mov    %r10d,%eax
 29f3f62:	lea    (%rbx,%rax,1),%r12
 29f3f66:	xor    %r10,%r10
 29f3f69:	cmp    %r11,%rax
 29f3f6c:	cmova  %r10,%r12
 29f3f70:	mov    0x10(%r12),%r12d
 29f3f75:	test   %r12d,%r12d
 29f3f78:	je     29fc56d <wasm[0]::function[1015]::helper::object_read+0x1b5ed>
 29f3f7e:	test   %r12d,%r12d
 29f3f81:	je     29fc56f <wasm[0]::function[1015]::helper::object_read+0x1b5ef>
 29f3f87:	mov    %r12d,%r13d
 29f3f8a:	lea    (%rbx,%r13,1),%r12
 29f3f8e:	cmp    %r11,%r13
 29f3f91:	cmova  %r10,%r12
 29f3f95:	mov    0x10(%r12),%r12d
 29f3f9a:	test   %r12d,%r12d
 29f3f9d:	je     29fc571 <wasm[0]::function[1015]::helper::object_read+0x1b5f1>
 29f3fa3:	test   %r12d,%r12d
 29f3fa6:	je     29fc573 <wasm[0]::function[1015]::helper::object_read+0x1b5f3>
 29f3fac:	mov    %r12d,%r12d
 29f3faf:	lea    0x10(%rbx,%r12,1),%rbx
 29f3fb4:	cmp    %r11,%r12
 29f3fb7:	cmova  %r10,%rbx
 29f3fbb:	cmp    (%rbx),%ecx
 29f3fbd:	setae  %r10b
 29f3fc1:	cmp    $0x2,%ecx
 29f3fc4:	setae  %r11b
 29f3fc8:	or     %r11d,%r10d
 29f3fcb:	test   %r10b,%r10b
 29f3fce:	jne    29fc575 <wasm[0]::function[1015]::helper::object_read+0x1b5f5>
 29f3fd4:	mov    0x2e0(%rsp),%r12
 29f3fdc:	mov    0x28(%r12),%r11
 29f3fe1:	mov    %rax,%r10
 29f3fe4:	add    0x20(%r12),%r10
 29f3fe9:	xor    %rbx,%rbx
 29f3fec:	cmp    %r11,%rax
 29f3fef:	cmova  %rbx,%r10
 29f3ff3:	mov    0x14(%r10),%r13d
 29f3ff7:	test   %ecx,%ecx
 29f3ff9:	je     29f4033 <wasm[0]::function[1015]::helper::object_read+0x130b3>
 29f3fff:	mov    0x2e0(%rsp),%r12
 29f4007:	mov    0x28(%r12),%r11
 29f400c:	mov    0x20(%r12),%r10
 29f4011:	add    %rax,%r10
 29f4014:	xor    %rbx,%rbx
 29f4017:	cmp    %r11,%rax
 29f401a:	cmova  %rbx,%r10
 29f401e:	mov    0x20(%r10),%r11
 29f4022:	mov    0x2c(%r10),%ebx
 29f4026:	mov    %r11,0x210(%rsp)
 29f402e:	jmp    29f4062 <wasm[0]::function[1015]::helper::object_read+0x130e2>
 29f4033:	mov    0x2e0(%rsp),%r12
 29f403b:	mov    0x28(%r12),%r11
 29f4040:	mov    0x20(%r12),%r10
 29f4045:	add    %rax,%r10
 29f4048:	xor    %rbx,%rbx
 29f404b:	cmp    %r11,%rax
 29f404e:	cmova  %rbx,%r10
 29f4052:	mov    0x18(%r10),%r11
 29f4056:	mov    %r11,0x210(%rsp)
 29f405e:	mov    0x28(%r10),%ebx
 29f4062:	shl    $0x3,%ecx
 29f4065:	shr    %cl,%r13d
 29f4068:	and    $0xff,%r13d
 29f406f:	mov    %r13,0x218(%rsp)
 29f4077:	mov    0x198(%rsp),%rax
 29f407f:	mov    %eax,0x98(%rsp)
 29f4086:	mov    %r9d,0x78(%rsp)
 29f408b:	mov    %edx,0xd8(%rsp)
 29f4092:	mov    %esi,0xb0(%rsp)
 29f4099:	mov    %ebx,0xa8(%rsp)
 29f40a0:	mov    %edi,0xc8(%rsp)
 29f40a7:	mov    %r8d,0xb8(%rsp)
 29f40af:	mov    $0x286,%edx
 29f40b4:	mov    0x190(%rsp),%rsi
 29f40bc:	mov    0x190(%rsp),%rdi
 29f40c4:	call   2f30600 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 29f40c9:	mov    %eax,0xc0(%rsp)
 29f40d0:	xor    %r15d,%r15d
 29f40d3:	test   %eax,%eax
 29f40d5:	je     29fc577 <wasm[0]::function[1015]::helper::object_read+0x1b5f7>
 29f40db:	movl   $0x0,0xd0(%rsp)
 29f40e6:	mov    0x98(%rsp),%r10d
 29f40ee:	mov    %r10,0x1a0(%rsp)
 29f40f6:	mov    0x78(%rsp),%edx
 29f40fa:	mov    %rdx,0x1c8(%rsp)
 29f4102:	mov    0xd8(%rsp),%edx
 29f4109:	mov    0xb0(%rsp),%esi
 29f4110:	mov    0xa8(%rsp),%edi
 29f4117:	mov    0xc8(%rsp),%r8d
 29f411f:	mov    0xb8(%rsp),%r9d
 29f4127:	xor    %r13,%r13
 29f412a:	mov    0x250(%rsp),%rcx
 29f4132:	mov    0x250(%rsp),%r11
 29f413a:	test   %r11b,%cl
 29f413d:	jne    29f4163 <wasm[0]::function[1015]::helper::object_read+0x131e3>
 29f4143:	mov    0x1a0(%rsp),%r10
 29f414b:	mov    %r15,%r14
 29f414e:	mov    %r15,0x1e0(%rsp)
 29f4156:	mov    %r13,0x1e8(%rsp)
 29f415e:	jmp    29f4dbe <wasm[0]::function[1015]::helper::object_read+0x13e3e>
 29f4163:	mov    0x98(%rsp),%r8d
 29f416b:	mov    0x260(%rsp),%rcx
 29f4173:	mov    0x258(%rsp),%rdx
 29f417b:	mov    0x190(%rsp),%rsi
 29f4183:	mov    0x190(%rsp),%rdi
 29f418b:	call   2a5f680 <wasm[0]::function[1039]::helper::object_header_projection>
 29f4190:	mov    %eax,0x88(%rsp)
 29f4197:	test   %eax,%eax
 29f4199:	je     29fc579 <wasm[0]::function[1015]::helper::object_read+0x1b5f9>
 29f419f:	test   %eax,%eax
 29f41a1:	je     29fc57b <wasm[0]::function[1015]::helper::object_read+0x1b5fb>
 29f41a7:	mov    0x2e0(%rsp),%r12
 29f41af:	mov    0x28(%r12),%rcx
 29f41b4:	mov    0x20(%r12),%rsi
 29f41b9:	mov    %eax,%edx
 29f41bb:	lea    (%rsi,%rdx,1),%rax
 29f41bf:	xor    %rsi,%rsi
 29f41c2:	cmp    %rcx,%rdx
 29f41c5:	cmova  %rsi,%rax
 29f41c9:	mov    0x14(%rax),%eax
 29f41cc:	mov    %eax,0xe8(%rsp)
 29f41d3:	test   %eax,%eax
 29f41d5:	je     29fc57d <wasm[0]::function[1015]::helper::object_read+0x1b5fd>
 29f41db:	mov    0xe8(%rsp),%ecx
 29f41e2:	xor    %eax,%eax
 29f41e4:	test   $0x1,%ecx
 29f41ea:	jne    29f4244 <wasm[0]::function[1015]::helper::object_read+0x132c4>
 29f41f0:	mov    0x2e0(%rsp),%r12
 29f41f8:	mov    0x28(%r12),%rax
 29f41fd:	mov    0x20(%r12),%rsi
 29f4202:	mov    %ecx,%edx
 29f4204:	lea    0x4(%rsi,%rdx,1),%rcx
 29f4209:	xor    %rsi,%rsi
 29f420c:	cmp    %rax,%rdx
 29f420f:	cmova  %rsi,%rcx
 29f4213:	mov    (%rcx),%esi
 29f4215:	mov    0x190(%rsp),%rax
 29f421d:	mov    0x28(%rax),%rax
 29f4221:	mov    0x158(%rax),%edx
 29f4227:	cmp    %edx,%esi
 29f4229:	sete   %al
 29f422c:	movzbl %al,%eax
 29f422f:	cmp    %edx,%esi
 29f4231:	je     29f4244 <wasm[0]::function[1015]::helper::object_read+0x132c4>
 29f4237:	mov    0x190(%rsp),%rdi
 29f423f:	call   3018cd5 <wasmtime_builtin_is_subtype>
 29f4244:	test   %eax,%eax
 29f4246:	jne    29f44b0 <wasm[0]::function[1015]::helper::object_read+0x13530>
 29f424c:	mov    0x88(%rsp),%edx
 29f4253:	xor    %r12d,%r12d
 29f4256:	test   %edx,%edx
 29f4258:	je     29fc57f <wasm[0]::function[1015]::helper::object_read+0x1b5ff>
 29f425e:	mov    0xc0(%rsp),%r9d
 29f4266:	mov    $0x4,%ecx
 29f426b:	xor    %r8,%r8
 29f426e:	mov    0x190(%rsp),%rsi
 29f4276:	mov    0x190(%rsp),%rdi
 29f427e:	call   2a58e80 <wasm[0]::function[1032]::helper::ordinary_property_find>
 29f4283:	test   %eax,%eax
 29f4285:	je     29f42c0 <wasm[0]::function[1015]::helper::object_read+0x13340>
 29f428b:	test   %eax,%eax
 29f428d:	je     29fc581 <wasm[0]::function[1015]::helper::object_read+0x1b601>
 29f4293:	test   %eax,%eax
 29f4295:	je     29fc583 <wasm[0]::function[1015]::helper::object_read+0x1b603>
 29f429b:	mov    0x2e0(%rsp),%r12
 29f42a3:	mov    0x28(%r12),%rcx
 29f42a8:	mov    %eax,%edx
 29f42aa:	mov    %rdx,%rax
 29f42ad:	add    0x20(%r12),%rax
 29f42b2:	xor    %rsi,%rsi
 29f42b5:	cmp    %rcx,%rdx
 29f42b8:	cmova  %rsi,%rax
 29f42bc:	mov    0x14(%rax),%r12d
 29f42c0:	mov    0xd0(%rsp),%r14d
 29f42c8:	xor    %r15d,%r15d
 29f42cb:	xor    %r13,%r13
 29f42ce:	test   %r12d,%r12d
 29f42d1:	je     29f445a <wasm[0]::function[1015]::helper::object_read+0x134da>
 29f42d7:	test   %r12d,%r12d
 29f42da:	je     29fc585 <wasm[0]::function[1015]::helper::object_read+0x1b605>
 29f42e0:	mov    0x2e0(%rsp),%rax
 29f42e8:	mov    0x28(%rax),%rcx
 29f42ec:	mov    0x20(%rax),%rax
 29f42f0:	mov    %r12d,%edx
 29f42f3:	add    %rdx,%rax
 29f42f6:	xor    %r13,%r13
 29f42f9:	cmp    %rcx,%rdx
 29f42fc:	cmova  %r13,%rax
 29f4300:	mov    0x10(%rax),%ecx
 29f4303:	mov    0xd0(%rsp),%r14d
 29f430b:	xor    %r15d,%r15d
 29f430e:	test   $0x1,%ecx
 29f4314:	jne    29f445a <wasm[0]::function[1015]::helper::object_read+0x134da>
 29f431a:	mov    0x14(%rax),%edx
 29f431d:	test   %edx,%edx
 29f431f:	je     29fc587 <wasm[0]::function[1015]::helper::object_read+0x1b607>
 29f4325:	xor    %esi,%esi
 29f4327:	test   $0x1,%edx
 29f432d:	jne    29f4371 <wasm[0]::function[1015]::helper::object_read+0x133f1>
 29f4333:	mov    0x2e0(%rsp),%r12
 29f433b:	mov    0x28(%r12),%rax
 29f4340:	mov    0x20(%r12),%rcx
 29f4345:	mov    %edx,%esi
 29f4347:	lea    0x4(%rcx,%rsi,1),%rcx
 29f434c:	xor    %rdi,%rdi
 29f434f:	cmp    %rax,%rsi
 29f4352:	cmova  %rdi,%rcx
 29f4356:	mov    (%rcx),%eax
 29f4358:	mov    0x190(%rsp),%rsi
 29f4360:	mov    0x28(%rsi),%rcx
 29f4364:	cmp    0x120(%rcx),%eax
 29f436a:	sete   %al
 29f436d:	rex movzbl %al,%esi
 29f4371:	test   %esi,%esi
 29f4373:	jne    29f43d1 <wasm[0]::function[1015]::helper::object_read+0x13451>
 29f4379:	mov    0x190(%rsp),%rsi
 29f4381:	mov    0x190(%rsp),%rdi
 29f4389:	call   2a01c00 <wasm[0]::function[1024]::helper::property_value_resolve>
 29f438e:	test   %eax,%eax
 29f4390:	je     29fc589 <wasm[0]::function[1015]::helper::object_read+0x1b609>
 29f4396:	test   %eax,%eax
 29f4398:	je     29fc58b <wasm[0]::function[1015]::helper::object_read+0x1b60b>
 29f439e:	mov    0x2e0(%rsp),%r12
 29f43a6:	mov    0x28(%r12),%rdi
 29f43ab:	mov    0x20(%r12),%rsi
 29f43b0:	mov    %eax,%r8d
 29f43b3:	add    %r8,%rsi
 29f43b6:	xor    %r9,%r9
 29f43b9:	cmp    %rdi,%r8
 29f43bc:	cmova  %r9,%rsi
 29f43c0:	mov    0x18(%rsi),%r15d
 29f43c4:	mov    0x10(%rsi),%r13
 29f43c8:	mov    0x1c(%rsi),%r14d
 29f43cc:	jmp    29f445a <wasm[0]::function[1015]::helper::object_read+0x134da>
 29f43d1:	xor    %eax,%eax
 29f43d3:	test   $0x1,%edx
 29f43d9:	jne    29f441d <wasm[0]::function[1015]::helper::object_read+0x1349d>
 29f43df:	mov    0x2e0(%rsp),%r12
 29f43e7:	mov    0x28(%r12),%rax
 29f43ec:	mov    0x20(%r12),%rsi
 29f43f1:	mov    %edx,%ecx
 29f43f3:	lea    0x4(%rsi,%rcx,1),%r9
 29f43f8:	xor    %rsi,%rsi
 29f43fb:	cmp    %rax,%rcx
 29f43fe:	cmova  %rsi,%r9
 29f4402:	mov    (%r9),%eax
 29f4405:	mov    0x190(%rsp),%rsi
 29f440d:	mov    0x28(%rsi),%rcx
 29f4411:	cmp    0x120(%rcx),%eax
 29f4417:	sete   %al
 29f441a:	movzbl %al,%eax
 29f441d:	test   %eax,%eax
 29f441f:	je     29fc58d <wasm[0]::function[1015]::helper::object_read+0x1b60d>
 29f4425:	test   %edx,%edx
 29f4427:	je     29fc58f <wasm[0]::function[1015]::helper::object_read+0x1b60f>
 29f442d:	mov    0x2e0(%rsp),%r12
 29f4435:	mov    0x28(%r12),%rcx
 29f443a:	mov    0x20(%r12),%rax
 29f443f:	mov    %edx,%edx
 29f4441:	add    %rdx,%rax
 29f4444:	xor    %rsi,%rsi
 29f4447:	cmp    %rcx,%rdx
 29f444a:	cmova  %rsi,%rax
 29f444e:	mov    0x18(%rax),%r15d
 29f4452:	mov    0x10(%rax),%r13
 29f4456:	mov    0x1c(%rax),%r14d
 29f445a:	mov    0x98(%rsp),%r10d
 29f4462:	mov    %r10,0x1a0(%rsp)
 29f446a:	mov    0x78(%rsp),%edx
 29f446e:	mov    %rdx,0x1c8(%rsp)
 29f4476:	mov    0xd8(%rsp),%edx
 29f447d:	mov    0xb0(%rsp),%esi
 29f4484:	mov    0xa8(%rsp),%edi
 29f448b:	mov    0xc8(%rsp),%r8d
 29f4493:	mov    0xb8(%rsp),%r9d
 29f449b:	mov    %r15,0x1e0(%rsp)
 29f44a3:	mov    %r13,0x1e8(%rsp)
 29f44ab:	jmp    29f4db6 <wasm[0]::function[1015]::helper::object_read+0x13e36>
 29f44b0:	mov    0xe8(%rsp),%eax
 29f44b7:	test   %eax,%eax
 29f44b9:	je     29fc591 <wasm[0]::function[1015]::helper::object_read+0x1b611>
 29f44bf:	mov    0xe8(%rsp),%ecx
 29f44c6:	xor    %eax,%eax
 29f44c8:	test   $0x1,%ecx
 29f44ce:	jne    29f4528 <wasm[0]::function[1015]::helper::object_read+0x135a8>
 29f44d4:	mov    0x2e0(%rsp),%r12
 29f44dc:	mov    0x28(%r12),%rax
 29f44e1:	mov    0x20(%r12),%rsi
 29f44e6:	mov    %ecx,%edx
 29f44e8:	lea    0x4(%rsi,%rdx,1),%rcx
 29f44ed:	xor    %rsi,%rsi
 29f44f0:	cmp    %rax,%rdx
 29f44f3:	cmova  %rsi,%rcx
 29f44f7:	mov    (%rcx),%esi
 29f44f9:	mov    0x190(%rsp),%r10
 29f4501:	mov    0x28(%r10),%rax
 29f4505:	mov    0x158(%rax),%edx
 29f450b:	cmp    %edx,%esi
 29f450d:	sete   %al
 29f4510:	movzbl %al,%eax
 29f4513:	cmp    %edx,%esi
 29f4515:	je     29f4528 <wasm[0]::function[1015]::helper::object_read+0x135a8>
 29f451b:	mov    0x190(%rsp),%rdi
 29f4523:	call   3018cd5 <wasmtime_builtin_is_subtype>
 29f4528:	test   %eax,%eax
 29f452a:	je     29fc593 <wasm[0]::function[1015]::helper::object_read+0x1b613>
 29f4530:	mov    0xe8(%rsp),%r11d
 29f4538:	mov    0x98(%rsp),%r10d
 29f4540:	mov    %r10,0x1a0(%rsp)
 29f4548:	mov    0x78(%rsp),%edx
 29f454c:	mov    %rdx,0x1c8(%rsp)
 29f4554:	mov    0xd0(%rsp),%r14d
 29f455c:	mov    0xd8(%rsp),%edx
 29f4563:	mov    0xb0(%rsp),%esi
 29f456a:	mov    0xa8(%rsp),%edi
 29f4571:	mov    0xc8(%rsp),%r8d
 29f4579:	mov    0xb8(%rsp),%r9d
 29f4581:	xor    %ecx,%ecx
 29f4583:	mov    %rcx,0x240(%rsp)
 29f458b:	test   %r11d,%r11d
 29f458e:	je     29fc595 <wasm[0]::function[1015]::helper::object_read+0x1b615>
 29f4594:	test   %r11d,%r11d
 29f4597:	je     29fc597 <wasm[0]::function[1015]::helper::object_read+0x1b617>
 29f459d:	mov    0x2e0(%rsp),%r12
 29f45a5:	mov    0x28(%r12),%rax
 29f45aa:	mov    0x20(%r12),%rcx
 29f45af:	mov    %r11d,%r12d
 29f45b2:	lea    (%rcx,%r12,1),%rbx
 29f45b6:	xor    %r13,%r13
 29f45b9:	cmp    %rax,%r12
 29f45bc:	cmova  %r13,%rbx
 29f45c0:	mov    0x10(%rbx),%ebx
 29f45c3:	test   %ebx,%ebx
 29f45c5:	je     29fc599 <wasm[0]::function[1015]::helper::object_read+0x1b619>
 29f45cb:	test   %ebx,%ebx
 29f45cd:	je     29fc59b <wasm[0]::function[1015]::helper::object_read+0x1b61b>
 29f45d3:	mov    %ebx,%r12d
 29f45d6:	lea    (%rcx,%r12,1),%rbx
 29f45da:	cmp    %rax,%r12
 29f45dd:	cmova  %r13,%rbx
 29f45e1:	mov    0x10(%rbx),%r12d
 29f45e5:	test   %r12d,%r12d
 29f45e8:	je     29fc59d <wasm[0]::function[1015]::helper::object_read+0x1b61d>
 29f45ee:	test   %r12d,%r12d
 29f45f1:	je     29fc59f <wasm[0]::function[1015]::helper::object_read+0x1b61f>
 29f45f7:	mov    %r12d,%ebx
 29f45fa:	lea    0x10(%rcx,%rbx,1),%rcx
 29f45ff:	cmp    %rax,%rbx
 29f4602:	cmova  %r13,%rcx
 29f4606:	mov    (%rcx),%ebx
 29f4608:	mov    0xc0(%rsp),%r15d
 29f4610:	mov    0x190(%rsp),%r10
 29f4618:	mov    0x28(%r10),%rax
 29f461c:	mov    0x234(%rax),%r13d
 29f4623:	mov    0x240(%rsp),%rax
 29f462b:	mov    %rax,0x198(%rsp)
 29f4633:	mov    %r12d,0x88(%rsp)
 29f463b:	mov    %r15d,0xb8(%rsp)
 29f4643:	mov    %r11d,0xc8(%rsp)
 29f464b:	mov    0x1a0(%rsp),%r10
 29f4653:	mov    %r10d,0xa8(%rsp)
 29f465b:	mov    0x1c8(%rsp),%rax
 29f4663:	mov    %eax,0xb0(%rsp)
 29f466a:	mov    %r14d,0xd8(%rsp)
 29f4672:	mov    %edx,0xd0(%rsp)
 29f4679:	mov    %esi,0x78(%rsp)
 29f467d:	mov    %edi,0x98(%rsp)
 29f4684:	mov    %r8d,0xe8(%rsp)
 29f468c:	mov    %r9d,0xc0(%rsp)
 29f4694:	mov    0x2e8(%rsp),%rax
 29f469c:	mov    (%rax),%rsi
 29f469f:	mov    0x228(%rsp),%rax
 29f46a7:	cmp    %rax,%rsi
 29f46aa:	jae    29fb4e6 <wasm[0]::function[1015]::helper::object_read+0x1a566>
 29f46b0:	mov    0xc8(%rsp),%r11d
 29f46b8:	mov    0xa8(%rsp),%r10d
 29f46c0:	mov    %r10,0x1a0(%rsp)
 29f46c8:	mov    0xb0(%rsp),%edx
 29f46cf:	mov    %rdx,0x1c8(%rsp)
 29f46d7:	mov    0xd8(%rsp),%r14d
 29f46df:	mov    0xd0(%rsp),%edx
 29f46e6:	mov    0x78(%rsp),%esi
 29f46ea:	mov    0x98(%rsp),%edi
 29f46f1:	mov    0xe8(%rsp),%r8d
 29f46f9:	mov    0xc0(%rsp),%r9d
 29f4701:	mov    0x240(%rsp),%rcx
 29f4709:	cmp    %ebx,%ecx
 29f470b:	jb     29f471e <wasm[0]::function[1015]::helper::object_read+0x1379e>
 29f4711:	mov    0x198(%rsp),%rax
 29f4719:	jmp    29f493d <wasm[0]::function[1015]::helper::object_read+0x139bd>
 29f471e:	mov    0x88(%rsp),%eax
 29f4725:	test   %eax,%eax
 29f4727:	je     29fc5a1 <wasm[0]::function[1015]::helper::object_read+0x1b621>
 29f472d:	test   %eax,%eax
 29f472f:	je     29fc5a3 <wasm[0]::function[1015]::helper::object_read+0x1b623>
 29f4735:	mov    0x2e0(%rsp),%r12
 29f473d:	mov    0x28(%r12),%rdx
 29f4742:	mov    0x20(%r12),%rsi
 29f4747:	mov    %eax,%r9d
 29f474a:	lea    0x10(%rsi,%r9,1),%r8
 29f474f:	xor    %rdi,%rdi
 29f4752:	cmp    %rdx,%r9
 29f4755:	cmova  %rdi,%r8
 29f4759:	mov    (%r8),%r8d
 29f475c:	cmp    %r8d,%ecx
 29f475f:	jae    29fc5a5 <wasm[0]::function[1015]::helper::object_read+0x1b625>
 29f4765:	mov    %r8d,%r9d
 29f4768:	shl    $0x2,%r9
 29f476c:	shr    $0x20,%r9
 29f4770:	test   %r9,%r9
 29f4773:	jne    29fc5a7 <wasm[0]::function[1015]::helper::object_read+0x1b627>
 29f4779:	shl    $0x2,%r8d
 29f477d:	add    $0x14,%r8d
 29f4781:	jb     29fc5a9 <wasm[0]::function[1015]::helper::object_read+0x1b629>
 29f4787:	add    %r8d,%eax
 29f478a:	jb     29fc5ab <wasm[0]::function[1015]::helper::object_read+0x1b62b>
 29f4790:	mov    %eax,%r9d
 29f4793:	lea    (%rsi,%r9,1),%rax
 29f4797:	cmp    %rdx,%r9
 29f479a:	cmova  %rdi,%rax
 29f479e:	mov    %rcx,%rdx
 29f47a1:	shl    $0x2,%edx
 29f47a4:	mov    %rcx,0x240(%rsp)
 29f47ac:	lea    0x14(%rdx),%ecx
 29f47af:	sub    %ecx,%r8d
 29f47b2:	sub    %r8,%rax
 29f47b5:	mov    (%rax),%edx
 29f47b7:	test   %edx,%edx
 29f47b9:	je     29fc5ad <wasm[0]::function[1015]::helper::object_read+0x1b62d>
 29f47bf:	mov    0xb8(%rsp),%eax
 29f47c6:	cmp    %eax,%edx
 29f47c8:	je     29f489c <wasm[0]::function[1015]::helper::object_read+0x1391c>
 29f47ce:	xor    %ecx,%ecx
 29f47d0:	test   %edx,%edx
 29f47d2:	je     29f4814 <wasm[0]::function[1015]::helper::object_read+0x13894>
 29f47d8:	xor    %ecx,%ecx
 29f47da:	test   $0x1,%edx
 29f47e0:	jne    29f4814 <wasm[0]::function[1015]::helper::object_read+0x13894>
 29f47e6:	mov    0x2e0(%rsp),%r12
 29f47ee:	mov    0x28(%r12),%rcx
 29f47f3:	mov    0x20(%r12),%rsi
 29f47f8:	mov    %edx,%edi
 29f47fa:	lea    0x4(%rsi,%rdi,1),%rsi
 29f47ff:	xor    %r8,%r8
 29f4802:	cmp    %rcx,%rdi
 29f4805:	cmova  %r8,%rsi
 29f4809:	mov    (%rsi),%ecx
 29f480b:	cmp    %r13d,%ecx
 29f480e:	sete   %cl
 29f4811:	movzbl %cl,%ecx
 29f4814:	test   %ecx,%ecx
 29f4816:	je     29fc5af <wasm[0]::function[1015]::helper::object_read+0x1b62f>
 29f481c:	xor    %ecx,%ecx
 29f481e:	test   %eax,%eax
 29f4820:	je     29f4868 <wasm[0]::function[1015]::helper::object_read+0x138e8>
 29f4826:	mov    0xb8(%rsp),%eax
 29f482d:	xor    %ecx,%ecx
 29f482f:	test   $0x1,%eax
 29f4834:	jne    29f4868 <wasm[0]::function[1015]::helper::object_read+0x138e8>
 29f483a:	mov    0x2e0(%rsp),%r12
 29f4842:	mov    0x28(%r12),%rcx
 29f4847:	mov    0x20(%r12),%rdi
 29f484c:	mov    %eax,%esi
 29f484e:	lea    0x4(%rdi,%rsi,1),%rax
 29f4853:	xor    %rdi,%rdi
 29f4856:	cmp    %rcx,%rsi
 29f4859:	cmova  %rdi,%rax
 29f485d:	mov    (%rax),%eax
 29f485f:	cmp    %r13d,%eax
 29f4862:	sete   %al
 29f4865:	movzbl %al,%ecx
 29f4868:	test   %ecx,%ecx
 29f486a:	je     29fc5b1 <wasm[0]::function[1015]::helper::object_read+0x1b631>
 29f4870:	mov    0xb8(%rsp),%ecx
 29f4877:	xor    %r8d,%r8d
 29f487a:	test   %ecx,%ecx
 29f487c:	je     29fc5b3 <wasm[0]::function[1015]::helper::object_read+0x1b633>
 29f4882:	mov    0x190(%rsp),%rsi
 29f488a:	mov    0x190(%rsp),%rdi
 29f4892:	call   2ae5540 <wasm[0]::function[1057]::helper::string_equality>
 29f4897:	jmp    29f48a4 <wasm[0]::function[1015]::helper::object_read+0x13924>
 29f489c:	mov    0x278(%rsp),%rax
 29f48a4:	mov    0x88(%rsp),%r12d
 29f48ac:	mov    0xb8(%rsp),%r15d
 29f48b4:	mov    0xc8(%rsp),%r11d
 29f48bc:	mov    0xa8(%rsp),%r10d
 29f48c4:	mov    %r10,0x1a0(%rsp)
 29f48cc:	mov    0xb0(%rsp),%edx
 29f48d3:	mov    %rdx,0x1c8(%rsp)
 29f48db:	mov    0xd8(%rsp),%r14d
 29f48e3:	mov    0xd0(%rsp),%edx
 29f48ea:	mov    0x78(%rsp),%esi
 29f48ee:	mov    0x98(%rsp),%edi
 29f48f5:	mov    0xe8(%rsp),%r8d
 29f48fd:	mov    0xc0(%rsp),%r9d
 29f4905:	test   %eax,%eax
 29f4907:	je     29f491a <wasm[0]::function[1015]::helper::object_read+0x1399a>
 29f490d:	mov    0x240(%rsp),%rcx
 29f4915:	jmp    29f493d <wasm[0]::function[1015]::helper::object_read+0x139bd>
 29f491a:	mov    0x240(%rsp),%rcx
 29f4922:	add    $0x1,%ecx
 29f4928:	mov    %rax,0x198(%rsp)
 29f4930:	mov    %rcx,0x240(%rsp)
 29f4938:	jmp    29f4633 <wasm[0]::function[1015]::helper::object_read+0x136b3>
 29f493d:	xor    %r15d,%r15d
 29f4940:	xor    %r13,%r13
 29f4943:	test   %eax,%eax
 29f4945:	jne    29f4960 <wasm[0]::function[1015]::helper::object_read+0x139e0>
 29f494b:	mov    %r15,0x1e0(%rsp)
 29f4953:	mov    %r13,0x1e8(%rsp)
 29f495b:	jmp    29f4db6 <wasm[0]::function[1015]::helper::object_read+0x13e36>
 29f4960:	test   %r11d,%r11d
 29f4963:	je     29fc5b5 <wasm[0]::function[1015]::helper::object_read+0x1b635>
 29f4969:	xor    %eax,%eax
 29f496b:	test   $0x1,%r11d
 29f4972:	jne    29f49b9 <wasm[0]::function[1015]::helper::object_read+0x13a39>
 29f4978:	mov    0x2e0(%rsp),%r12
 29f4980:	mov    0x28(%r12),%rax
 29f4985:	mov    0x20(%r12),%r14
 29f498a:	mov    %r11d,%r13d
 29f498d:	lea    0x4(%r14,%r13,1),%r12
 29f4992:	xor    %r14,%r14
 29f4995:	cmp    %rax,%r13
 29f4998:	cmova  %r14,%r12
 29f499c:	mov    (%r12),%eax
 29f49a0:	mov    0x190(%rsp),%r10
 29f49a8:	mov    0x28(%r10),%r10
 29f49ac:	cmp    0x160(%r10),%eax
 29f49b3:	sete   %al
 29f49b6:	movzbl %al,%eax
 29f49b9:	test   %eax,%eax
 29f49bb:	jne    29f4c28 <wasm[0]::function[1015]::helper::object_read+0x13ca8>
 29f49c1:	xor    %eax,%eax
 29f49c3:	test   $0x1,%r11d
 29f49ca:	jne    29f4a0f <wasm[0]::function[1015]::helper::object_read+0x13a8f>
 29f49d0:	mov    0x2e0(%rsp),%r12
 29f49d8:	mov    0x28(%r12),%rax
 29f49dd:	mov    0x20(%r12),%rbx
 29f49e2:	mov    %r11d,%r12d
 29f49e5:	lea    0x4(%rbx,%r12,1),%rbx
 29f49ea:	xor    %r13,%r13
 29f49ed:	cmp    %rax,%r12
 29f49f0:	cmova  %r13,%rbx
 29f49f4:	mov    (%rbx),%eax
 29f49f6:	mov    0x190(%rsp),%r10
 29f49fe:	mov    0x28(%r10),%r10
 29f4a02:	cmp    0x15c(%r10),%eax
 29f4a09:	sete   %al
 29f4a0c:	movzbl %al,%eax
 29f4a0f:	test   %eax,%eax
 29f4a11:	je     29fc5b7 <wasm[0]::function[1015]::helper::object_read+0x1b637>
 29f4a17:	test   %r11d,%r11d
 29f4a1a:	je     29fc5b9 <wasm[0]::function[1015]::helper::object_read+0x1b639>
 29f4a20:	mov    0x2e0(%rsp),%r12
 29f4a28:	mov    0x28(%r12),%rax
 29f4a2d:	mov    0x20(%r12),%r12
 29f4a32:	mov    %r11d,%ebx
 29f4a35:	lea    (%r12,%rbx,1),%r11
 29f4a39:	xor    %r13,%r13
 29f4a3c:	cmp    %rax,%rbx
 29f4a3f:	cmova  %r13,%r11
 29f4a43:	mov    0x14(%r11),%r15d
 29f4a47:	mov    0x18(%r11),%r14d
 29f4a4b:	mov    0x1c(%r11),%r11d
 29f4a4f:	test   %r15d,%r15d
 29f4a52:	je     29fc5bb <wasm[0]::function[1015]::helper::object_read+0x1b63b>
 29f4a58:	test   %r15d,%r15d
 29f4a5b:	je     29fc5bd <wasm[0]::function[1015]::helper::object_read+0x1b63d>
 29f4a61:	mov    %r15d,%r10d
 29f4a64:	lea    0x10(%r12,%r10,1),%rbx
 29f4a69:	cmp    %rax,%r10
 29f4a6c:	cmova  %r13,%rbx
 29f4a70:	mov    (%rbx),%ebx
 29f4a72:	cmp    %ebx,%ecx
 29f4a74:	jae    29fc5bf <wasm[0]::function[1015]::helper::object_read+0x1b63f>
 29f4a7a:	mov    %ebx,%r10d
 29f4a7d:	shr    $0x20,%r10
 29f4a81:	test   %r10,%r10
 29f4a84:	jne    29fc5c1 <wasm[0]::function[1015]::helper::object_read+0x1b641>
 29f4a8a:	add    $0x14,%ebx
 29f4a8d:	jb     29fc5c3 <wasm[0]::function[1015]::helper::object_read+0x1b643>
 29f4a93:	add    %ebx,%r15d
 29f4a96:	jb     29fc5c5 <wasm[0]::function[1015]::helper::object_read+0x1b645>
 29f4a9c:	mov    %r15d,%r10d
 29f4a9f:	add    %r10,%r12
 29f4aa2:	cmp    %rax,%r10
 29f4aa5:	cmova  %r13,%r12
 29f4aa9:	lea    0x14(%rcx),%eax
 29f4aac:	sub    %eax,%ebx
 29f4aae:	sub    %rbx,%r12
 29f4ab1:	movzbq (%r12),%rbx
 29f4ab6:	mov    %rbx,0x248(%rsp)
 29f4abe:	test   %r14d,%r14d
 29f4ac1:	je     29f4b5c <wasm[0]::function[1015]::helper::object_read+0x13bdc>
 29f4ac7:	test   %r14d,%r14d
 29f4aca:	je     29fc5c7 <wasm[0]::function[1015]::helper::object_read+0x1b647>
 29f4ad0:	test   %r14d,%r14d
 29f4ad3:	je     29fc5c9 <wasm[0]::function[1015]::helper::object_read+0x1b649>
 29f4ad9:	mov    0x2e0(%rsp),%r12
 29f4ae1:	mov    0x28(%r12),%r12
 29f4ae6:	mov    0x2e0(%rsp),%rax
 29f4aee:	mov    0x20(%rax),%r13
 29f4af2:	mov    %r14d,%ebx
 29f4af5:	lea    0x10(%r13,%rbx,1),%rax
 29f4afa:	xor    %r15,%r15
 29f4afd:	cmp    %r12,%rbx
 29f4b00:	cmova  %r15,%rax
 29f4b04:	mov    (%rax),%eax
 29f4b06:	cmp    %eax,%ecx
 29f4b08:	jae    29fc5cb <wasm[0]::function[1015]::helper::object_read+0x1b64b>
 29f4b0e:	mov    %eax,%ebx
 29f4b10:	shl    $0x3,%rbx
 29f4b14:	shr    $0x20,%rbx
 29f4b18:	test   %rbx,%rbx
 29f4b1b:	jne    29fc5cd <wasm[0]::function[1015]::helper::object_read+0x1b64d>
 29f4b21:	shl    $0x3,%eax
 29f4b24:	add    $0x18,%eax
 29f4b27:	jb     29fc5cf <wasm[0]::function[1015]::helper::object_read+0x1b64f>
 29f4b2d:	add    %eax,%r14d
 29f4b30:	jb     29fc5d1 <wasm[0]::function[1015]::helper::object_read+0x1b651>
 29f4b36:	mov    %r14d,%r10d
 29f4b39:	lea    0x0(%r13,%r10,1),%rbx
 29f4b3e:	cmp    %r12,%r10
 29f4b41:	cmova  %r15,%rbx
 29f4b45:	mov    %rcx,%r10
 29f4b48:	shl    $0x3,%r10d
 29f4b4c:	add    $0x18,%r10d
 29f4b53:	sub    %r10d,%eax
 29f4b56:	sub    %rax,%rbx
 29f4b59:	mov    (%rbx),%r13
 29f4b5c:	xor    %r14d,%r14d
 29f4b5f:	test   %r11d,%r11d
 29f4b62:	jne    29f4b75 <wasm[0]::function[1015]::helper::object_read+0x13bf5>
 29f4b68:	mov    0x248(%rsp),%rbx
 29f4b70:	jmp    29f4c0f <wasm[0]::function[1015]::helper::object_read+0x13c8f>
 29f4b75:	test   %r11d,%r11d
 29f4b78:	je     29fc5d3 <wasm[0]::function[1015]::helper::object_read+0x1b653>
 29f4b7e:	test   %r11d,%r11d
 29f4b81:	je     29fc5d5 <wasm[0]::function[1015]::helper::object_read+0x1b655>
 29f4b87:	mov    0x2e0(%rsp),%r12
 29f4b8f:	mov    0x28(%r12),%r12
 29f4b94:	mov    0x2e0(%rsp),%rax
 29f4b9c:	mov    0x20(%rax),%rax
 29f4ba0:	mov    %r11d,%r15d
 29f4ba3:	lea    0x10(%rax,%r15,1),%rbx
 29f4ba8:	xor    %r14,%r14
 29f4bab:	cmp    %r12,%r15
 29f4bae:	cmova  %r14,%rbx
 29f4bb2:	mov    (%rbx),%r15d
 29f4bb5:	cmp    %r15d,%ecx
 29f4bb8:	jae    29fc5d7 <wasm[0]::function[1015]::helper::object_read+0x1b657>
 29f4bbe:	mov    %r15d,%ebx
 29f4bc1:	shl    $0x2,%rbx
 29f4bc5:	shr    $0x20,%rbx
 29f4bc9:	test   %rbx,%rbx
 29f4bcc:	jne    29fc5d9 <wasm[0]::function[1015]::helper::object_read+0x1b659>
 29f4bd2:	shl    $0x2,%r15d
 29f4bd6:	add    $0x14,%r15d
 29f4bda:	jb     29fc5db <wasm[0]::function[1015]::helper::object_read+0x1b65b>
 29f4be0:	add    %r15d,%r11d
 29f4be3:	jb     29fc5dd <wasm[0]::function[1015]::helper::object_read+0x1b65d>
 29f4be9:	mov    %r11d,%r10d
 29f4bec:	lea    (%rax,%r10,1),%r11
 29f4bf0:	cmp    %r12,%r10
 29f4bf3:	cmova  %r14,%r11
 29f4bf7:	shl    $0x2,%ecx
 29f4bfa:	lea    0x14(%rcx),%r10d
 29f4bfe:	sub    %r10d,%r15d
 29f4c01:	sub    %r15,%r11
 29f4c04:	mov    (%r11),%r14d
 29f4c07:	mov    0x248(%rsp),%rbx
 29f4c0f:	movzbl %bl,%r15d
 29f4c13:	mov    %r15,0x1e0(%rsp)
 29f4c1b:	mov    %r13,0x1e8(%rsp)
 29f4c23:	jmp    29f4db6 <wasm[0]::function[1015]::helper::object_read+0x13e36>
 29f4c28:	xor    %eax,%eax
 29f4c2a:	test   $0x1,%r11d
 29f4c31:	jne    29f4c78 <wasm[0]::function[1015]::helper::object_read+0x13cf8>
 29f4c37:	mov    0x2e0(%rsp),%r12
 29f4c3f:	mov    0x28(%r12),%rax
 29f4c44:	mov    0x20(%r12),%r10
 29f4c49:	mov    %r11d,%ebx
 29f4c4c:	lea    0x4(%r10,%rbx,1),%r13
 29f4c51:	xor    %r12,%r12
 29f4c54:	cmp    %rax,%rbx
 29f4c57:	cmova  %r12,%r13
 29f4c5b:	mov    0x0(%r13),%eax
 29f4c5f:	mov    0x190(%rsp),%r10
 29f4c67:	mov    0x28(%r10),%r10
 29f4c6b:	cmp    0x160(%r10),%eax
 29f4c72:	sete   %al
 29f4c75:	movzbl %al,%eax
 29f4c78:	test   %eax,%eax
 29f4c7a:	je     29fc5df <wasm[0]::function[1015]::helper::object_read+0x1b65f>
 29f4c80:	test   %r11d,%r11d
 29f4c83:	je     29fc5e1 <wasm[0]::function[1015]::helper::object_read+0x1b661>
 29f4c89:	mov    0x2e0(%rsp),%r12
 29f4c91:	mov    0x28(%r12),%r12
 29f4c96:	mov    0x2e0(%rsp),%rax
 29f4c9e:	mov    0x20(%rax),%r13
 29f4ca2:	mov    %r11d,%eax
 29f4ca5:	lea    0x0(%r13,%rax,1),%rbx
 29f4caa:	xor    %r11,%r11
 29f4cad:	cmp    %r12,%rax
 29f4cb0:	cmova  %r11,%rbx
 29f4cb4:	mov    0x10(%rbx),%ebx
 29f4cb7:	test   %ebx,%ebx
 29f4cb9:	je     29fc5e3 <wasm[0]::function[1015]::helper::object_read+0x1b663>
 29f4cbf:	test   %ebx,%ebx
 29f4cc1:	je     29fc5e5 <wasm[0]::function[1015]::helper::object_read+0x1b665>
 29f4cc7:	mov    %ebx,%r10d
 29f4cca:	lea    0x0(%r13,%r10,1),%rbx
 29f4ccf:	cmp    %r12,%r10
 29f4cd2:	cmova  %r11,%rbx
 29f4cd6:	mov    0x10(%rbx),%ebx
 29f4cd9:	test   %ebx,%ebx
 29f4cdb:	je     29fc5e7 <wasm[0]::function[1015]::helper::object_read+0x1b667>
 29f4ce1:	test   %ebx,%ebx
 29f4ce3:	je     29fc5e9 <wasm[0]::function[1015]::helper::object_read+0x1b669>
 29f4ce9:	mov    %ebx,%r10d
 29f4cec:	lea    0x10(%r13,%r10,1),%rbx
 29f4cf1:	cmp    %r12,%r10
 29f4cf4:	cmova  %r11,%rbx
 29f4cf8:	cmp    (%rbx),%ecx
 29f4cfa:	setae  %r11b
 29f4cfe:	cmp    $0x2,%ecx
 29f4d01:	setae  %r10b
 29f4d05:	or     %r10d,%r11d
 29f4d08:	test   %r11b,%r11b
 29f4d0b:	jne    29fc5eb <wasm[0]::function[1015]::helper::object_read+0x1b66b>
 29f4d11:	mov    0x2e0(%rsp),%r12
 29f4d19:	mov    0x28(%r12),%rbx
 29f4d1e:	mov    %rax,%r11
 29f4d21:	add    0x20(%r12),%r11
 29f4d26:	xor    %r12,%r12
 29f4d29:	cmp    %rbx,%rax
 29f4d2c:	cmova  %r12,%r11
 29f4d30:	mov    0x14(%r11),%r15d
 29f4d34:	test   %ecx,%ecx
 29f4d36:	je     29f4d71 <wasm[0]::function[1015]::helper::object_read+0x13df1>
 29f4d3c:	mov    0x2e0(%rsp),%r12
 29f4d44:	mov    0x28(%r12),%rbx
 29f4d49:	mov    0x20(%r12),%r10
 29f4d4e:	lea    (%r10,%rax,1),%r11
 29f4d52:	xor    %r12,%r12
 29f4d55:	cmp    %rbx,%rax
 29f4d58:	cmova  %r12,%r11
 29f4d5c:	mov    0x20(%r11),%r13
 29f4d60:	mov    0x2c(%r11),%r14d
 29f4d64:	mov    %r13,0x1e8(%rsp)
 29f4d6c:	jmp    29f4da1 <wasm[0]::function[1015]::helper::object_read+0x13e21>
 29f4d71:	mov    0x2e0(%rsp),%r12
 29f4d79:	mov    0x28(%r12),%rbx
 29f4d7e:	mov    0x20(%r12),%r10
 29f4d83:	lea    (%r10,%rax,1),%r11
 29f4d87:	xor    %r12,%r12
 29f4d8a:	cmp    %rbx,%rax
 29f4d8d:	cmova  %r12,%r11
 29f4d91:	mov    0x18(%r11),%r13
 29f4d95:	mov    %r13,0x1e8(%rsp)
 29f4d9d:	mov    0x28(%r11),%r14d
 29f4da1:	shl    $0x3,%ecx
 29f4da4:	shr    %cl,%r15d
 29f4da7:	and    $0xff,%r15d
 29f4dae:	mov    %r15,0x1e0(%rsp)
 29f4db6:	mov    0x1a0(%rsp),%r10
 29f4dbe:	mov    %r10d,0x78(%rsp)
 29f4dc3:	mov    0x1c8(%rsp),%r10
 29f4dcb:	mov    %r10d,0xd0(%rsp)
 29f4dd3:	mov    %r14d,0xd8(%rsp)
 29f4ddb:	mov    %edx,0xb0(%rsp)
 29f4de2:	mov    %esi,0xa8(%rsp)
 29f4de9:	mov    %edi,0xc8(%rsp)
 29f4df0:	mov    %r8d,0xb8(%rsp)
 29f4df8:	mov    %r9d,0x88(%rsp)
 29f4e00:	mov    $0x287,%edx
 29f4e05:	mov    0x190(%rsp),%rsi
 29f4e0d:	mov    0x190(%rsp),%rdi
 29f4e15:	call   2f30600 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 29f4e1a:	mov    %eax,0x98(%rsp)
 29f4e21:	xor    %edx,%edx
 29f4e23:	test   %eax,%eax
 29f4e25:	je     29fc5ed <wasm[0]::function[1015]::helper::object_read+0x1b66d>
 29f4e2b:	movl   $0x0,0xe8(%rsp)
 29f4e36:	mov    0xd0(%rsp),%edi
 29f4e3d:	mov    0xd8(%rsp),%r15d
 29f4e45:	mov    0xb0(%rsp),%r9d
 29f4e4d:	mov    %r9,0x198(%rsp)
 29f4e55:	mov    0xa8(%rsp),%r10d
 29f4e5d:	mov    %r10,0x1a0(%rsp)
 29f4e65:	mov    0xc8(%rsp),%r10d
 29f4e6d:	mov    0xb8(%rsp),%r11d
 29f4e75:	mov    0x88(%rsp),%ebx
 29f4e7c:	xor    %r8,%r8
 29f4e7f:	mov    0x250(%rsp),%rax
 29f4e87:	mov    0x250(%rsp),%rcx
 29f4e8f:	test   %al,%cl
 29f4e91:	jne    29f4ea7 <wasm[0]::function[1015]::helper::object_read+0x13f27>
 29f4e97:	mov    %rdx,%rsi
 29f4e9a:	mov    0x198(%rsp),%r9
 29f4ea2:	jmp    29f5ae6 <wasm[0]::function[1015]::helper::object_read+0x14b66>
 29f4ea7:	mov    0x78(%rsp),%r8d
 29f4eac:	mov    0x260(%rsp),%rcx
 29f4eb4:	mov    0x258(%rsp),%rdx
 29f4ebc:	mov    0x190(%rsp),%rsi
 29f4ec4:	mov    0x190(%rsp),%rdi
 29f4ecc:	call   2a5f680 <wasm[0]::function[1039]::helper::object_header_projection>
 29f4ed1:	mov    %eax,0x78(%rsp)
 29f4ed5:	test   %eax,%eax
 29f4ed7:	je     29fc5ef <wasm[0]::function[1015]::helper::object_read+0x1b66f>
 29f4edd:	test   %eax,%eax
 29f4edf:	je     29fc5f1 <wasm[0]::function[1015]::helper::object_read+0x1b671>
 29f4ee5:	mov    0x2e0(%rsp),%r12
 29f4eed:	mov    0x28(%r12),%rdi
 29f4ef2:	mov    0x20(%r12),%r9
 29f4ef7:	mov    %eax,%r8d
 29f4efa:	lea    (%r9,%r8,1),%rsi
 29f4efe:	xor    %r9,%r9
 29f4f01:	cmp    %rdi,%r8
 29f4f04:	cmova  %r9,%rsi
 29f4f08:	mov    0x14(%rsi),%r8d
 29f4f0c:	mov    %r8d,0xc0(%rsp)
 29f4f14:	test   %r8d,%r8d
 29f4f17:	je     29fc5f3 <wasm[0]::function[1015]::helper::object_read+0x1b673>
 29f4f1d:	mov    0xc0(%rsp),%ecx
 29f4f24:	xor    %eax,%eax
 29f4f26:	test   $0x1,%ecx
 29f4f2c:	jne    29f4f86 <wasm[0]::function[1015]::helper::object_read+0x14006>
 29f4f32:	mov    0x2e0(%rsp),%r12
 29f4f3a:	mov    0x28(%r12),%rax
 29f4f3f:	mov    0x20(%r12),%rsi
 29f4f44:	mov    %ecx,%edx
 29f4f46:	lea    0x4(%rsi,%rdx,1),%rcx
 29f4f4b:	xor    %rsi,%rsi
 29f4f4e:	cmp    %rax,%rdx
 29f4f51:	cmova  %rsi,%rcx
 29f4f55:	mov    (%rcx),%esi
 29f4f57:	mov    0x190(%rsp),%rax
 29f4f5f:	mov    0x28(%rax),%rax
 29f4f63:	mov    0x158(%rax),%edx
 29f4f69:	cmp    %edx,%esi
 29f4f6b:	sete   %al
 29f4f6e:	movzbl %al,%eax
 29f4f71:	cmp    %edx,%esi
 29f4f73:	je     29f4f86 <wasm[0]::function[1015]::helper::object_read+0x14006>
 29f4f79:	mov    0x190(%rsp),%rdi
 29f4f81:	call   3018cd5 <wasmtime_builtin_is_subtype>
 29f4f86:	test   %eax,%eax
 29f4f88:	jne    29f51db <wasm[0]::function[1015]::helper::object_read+0x1425b>
 29f4f8e:	mov    0x78(%rsp),%edx
 29f4f92:	xor    %ebx,%ebx
 29f4f94:	test   %edx,%edx
 29f4f96:	je     29fc5f5 <wasm[0]::function[1015]::helper::object_read+0x1b675>
 29f4f9c:	mov    0x98(%rsp),%r9d
 29f4fa4:	mov    $0x4,%ecx
 29f4fa9:	xor    %r8,%r8
 29f4fac:	mov    0x190(%rsp),%rsi
 29f4fb4:	mov    0x190(%rsp),%rdi
 29f4fbc:	call   2a58e80 <wasm[0]::function[1032]::helper::ordinary_property_find>
 29f4fc1:	test   %eax,%eax
 29f4fc3:	je     29f4ffd <wasm[0]::function[1015]::helper::object_read+0x1407d>
 29f4fc9:	test   %eax,%eax
 29f4fcb:	je     29fc5f7 <wasm[0]::function[1015]::helper::object_read+0x1b677>
 29f4fd1:	test   %eax,%eax
 29f4fd3:	je     29fc5f9 <wasm[0]::function[1015]::helper::object_read+0x1b679>
 29f4fd9:	mov    0x2e0(%rsp),%r12
 29f4fe1:	mov    0x28(%r12),%rcx
 29f4fe6:	mov    %eax,%edx
 29f4fe8:	mov    %rdx,%rax
 29f4feb:	add    0x20(%r12),%rax
 29f4ff0:	xor    %rsi,%rsi
 29f4ff3:	cmp    %rcx,%rdx
 29f4ff6:	cmova  %rsi,%rax
 29f4ffa:	mov    0x14(%rax),%ebx
 29f4ffd:	mov    0xe8(%rsp),%esi
 29f5004:	xor    %edx,%edx
 29f5006:	xor    %r8,%r8
 29f5009:	test   %ebx,%ebx
 29f500b:	je     29f5190 <wasm[0]::function[1015]::helper::object_read+0x14210>
 29f5011:	test   %ebx,%ebx
 29f5013:	je     29fc5fb <wasm[0]::function[1015]::helper::object_read+0x1b67b>
 29f5019:	mov    0x2e0(%rsp),%r12
 29f5021:	mov    0x28(%r12),%rcx
 29f5026:	mov    0x20(%r12),%rax
 29f502b:	mov    %ebx,%edx
 29f502d:	add    %rdx,%rax
 29f5030:	xor    %r8,%r8
 29f5033:	cmp    %rcx,%rdx
 29f5036:	cmova  %r8,%rax
 29f503a:	mov    0x10(%rax),%ecx
 29f503d:	mov    0xe8(%rsp),%esi
 29f5044:	xor    %edx,%edx
 29f5046:	test   $0x1,%ecx
 29f504c:	jne    29f5190 <wasm[0]::function[1015]::helper::object_read+0x14210>
 29f5052:	mov    0x14(%rax),%edx
 29f5055:	test   %edx,%edx
 29f5057:	je     29fc5fd <wasm[0]::function[1015]::helper::object_read+0x1b67d>
 29f505d:	xor    %eax,%eax
 29f505f:	test   $0x1,%edx
 29f5065:	jne    29f50a8 <wasm[0]::function[1015]::helper::object_read+0x14128>
 29f506b:	mov    0x2e0(%rsp),%r12
 29f5073:	mov    0x28(%r12),%rax
 29f5078:	mov    0x20(%r12),%rcx
 29f507d:	mov    %edx,%esi
 29f507f:	lea    0x4(%rcx,%rsi,1),%rcx
 29f5084:	xor    %rdi,%rdi
 29f5087:	cmp    %rax,%rsi
 29f508a:	cmova  %rdi,%rcx
 29f508e:	mov    (%rcx),%eax
 29f5090:	mov    0x190(%rsp),%rsi
 29f5098:	mov    0x28(%rsi),%rcx
 29f509c:	cmp    0x120(%rcx),%eax
 29f50a2:	sete   %al
 29f50a5:	movzbl %al,%eax
 29f50a8:	test   %eax,%eax
 29f50aa:	jne    29f5106 <wasm[0]::function[1015]::helper::object_read+0x14186>
 29f50b0:	mov    0x190(%rsp),%rsi
 29f50b8:	mov    0x190(%rsp),%rdi
 29f50c0:	call   2a01c00 <wasm[0]::function[1024]::helper::property_value_resolve>
 29f50c5:	test   %eax,%eax
 29f50c7:	je     29fc5ff <wasm[0]::function[1015]::helper::object_read+0x1b67f>
 29f50cd:	test   %eax,%eax
 29f50cf:	je     29fc601 <wasm[0]::function[1015]::helper::object_read+0x1b681>
 29f50d5:	mov    0x2e0(%rsp),%r12
 29f50dd:	mov    0x28(%r12),%rcx
 29f50e2:	mov    0x20(%r12),%rsi
 29f50e7:	mov    %eax,%edx
 29f50e9:	lea    (%rsi,%rdx,1),%rax
 29f50ed:	xor    %rsi,%rsi
 29f50f0:	cmp    %rcx,%rdx
 29f50f3:	cmova  %rsi,%rax
 29f50f7:	mov    0x18(%rax),%edx
 29f50fa:	mov    0x10(%rax),%r8
 29f50fe:	mov    0x1c(%rax),%esi
 29f5101:	jmp    29f5190 <wasm[0]::function[1015]::helper::object_read+0x14210>
 29f5106:	xor    %eax,%eax
 29f5108:	test   $0x1,%edx
 29f510e:	jne    29f5153 <wasm[0]::function[1015]::helper::object_read+0x141d3>
 29f5114:	mov    0x2e0(%rsp),%r12
 29f511c:	mov    0x28(%r12),%rsi
 29f5121:	mov    0x20(%r12),%r8
 29f5126:	mov    %edx,%edi
 29f5128:	lea    0x4(%r8,%rdi,1),%rax
 29f512d:	xor    %r8,%r8
 29f5130:	cmp    %rsi,%rdi
 29f5133:	cmova  %r8,%rax
 29f5137:	mov    (%rax),%esi
 29f5139:	mov    0x190(%rsp),%rax
 29f5141:	mov    0x28(%rax),%rdi
 29f5145:	cmp    0x120(%rdi),%esi
 29f514b:	sete   %sil
 29f514f:	movzbl %sil,%eax
 29f5153:	test   %eax,%eax
 29f5155:	je     29fc603 <wasm[0]::function[1015]::helper::object_read+0x1b683>
 29f515b:	test   %edx,%edx
 29f515d:	je     29fc605 <wasm[0]::function[1015]::helper::object_read+0x1b685>
 29f5163:	mov    0x2e0(%rsp),%r12
 29f516b:	mov    0x28(%r12),%r9
 29f5170:	mov    0x20(%r12),%r11
 29f5175:	mov    %edx,%r10d
 29f5178:	lea    (%r11,%r10,1),%rsi
 29f517c:	xor    %r11,%r11
 29f517f:	cmp    %r9,%r10
 29f5182:	cmova  %r11,%rsi
 29f5186:	mov    0x18(%rsi),%edx
 29f5189:	mov    0x10(%rsi),%r8
 29f518d:	mov    0x1c(%rsi),%esi
 29f5190:	mov    0xd0(%rsp),%edi
 29f5197:	mov    0xd8(%rsp),%r15d
 29f519f:	mov    0xb0(%rsp),%r9d
 29f51a7:	mov    %r9,0x198(%rsp)
 29f51af:	mov    0xa8(%rsp),%r10d
 29f51b7:	mov    %r10,0x1a0(%rsp)
 29f51bf:	mov    0xc8(%rsp),%r10d
 29f51c7:	mov    0xb8(%rsp),%r11d
 29f51cf:	mov    0x88(%rsp),%ebx
 29f51d6:	jmp    29f5ade <wasm[0]::function[1015]::helper::object_read+0x14b5e>
 29f51db:	mov    0xc0(%rsp),%eax
 29f51e2:	test   %eax,%eax
 29f51e4:	je     29fc607 <wasm[0]::function[1015]::helper::object_read+0x1b687>
 29f51ea:	mov    0xc0(%rsp),%ecx
 29f51f1:	xor    %eax,%eax
 29f51f3:	test   $0x1,%ecx
 29f51f9:	jne    29f5253 <wasm[0]::function[1015]::helper::object_read+0x142d3>
 29f51ff:	mov    0x2e0(%rsp),%r12
 29f5207:	mov    0x28(%r12),%rax
 29f520c:	mov    0x20(%r12),%rsi
 29f5211:	mov    %ecx,%edx
 29f5213:	lea    0x4(%rsi,%rdx,1),%rcx
 29f5218:	xor    %rsi,%rsi
 29f521b:	cmp    %rax,%rdx
 29f521e:	cmova  %rsi,%rcx
 29f5222:	mov    (%rcx),%esi
 29f5224:	mov    0x190(%rsp),%rax
 29f522c:	mov    0x28(%rax),%rax
 29f5230:	mov    0x158(%rax),%edx
 29f5236:	cmp    %edx,%esi
 29f5238:	sete   %al
 29f523b:	movzbl %al,%eax
 29f523e:	cmp    %edx,%esi
 29f5240:	je     29f5253 <wasm[0]::function[1015]::helper::object_read+0x142d3>
 29f5246:	mov    0x190(%rsp),%rdi
 29f524e:	call   3018cd5 <wasmtime_builtin_is_subtype>
 29f5253:	test   %eax,%eax
 29f5255:	je     29fc609 <wasm[0]::function[1015]::helper::object_read+0x1b689>
 29f525b:	mov    0xc0(%rsp),%r14d
 29f5263:	mov    0xd0(%rsp),%edi
 29f526a:	mov    0xd8(%rsp),%r15d
 29f5272:	mov    0xe8(%rsp),%esi
 29f5279:	mov    0xb0(%rsp),%r9d
 29f5281:	mov    %r9,0x198(%rsp)
 29f5289:	mov    0xa8(%rsp),%r10d
 29f5291:	mov    %r10,0x1a0(%rsp)
 29f5299:	mov    0xc8(%rsp),%r10d
 29f52a1:	mov    0xb8(%rsp),%r11d
 29f52a9:	mov    0x88(%rsp),%ebx
 29f52b0:	xor    %ecx,%ecx
 29f52b2:	mov    %rcx,0x230(%rsp)
 29f52ba:	test   %r14d,%r14d
 29f52bd:	je     29fc60b <wasm[0]::function[1015]::helper::object_read+0x1b68b>
 29f52c3:	test   %r14d,%r14d
 29f52c6:	je     29fc60d <wasm[0]::function[1015]::helper::object_read+0x1b68d>
 29f52cc:	mov    0x2e0(%rsp),%r12
 29f52d4:	mov    0x28(%r12),%rax
 29f52d9:	mov    0x20(%r12),%rcx
 29f52de:	mov    %r14d,%r12d
 29f52e1:	lea    (%rcx,%r12,1),%rdx
 29f52e5:	xor    %r8,%r8
 29f52e8:	cmp    %rax,%r12
 29f52eb:	cmova  %r8,%rdx
 29f52ef:	mov    0x10(%rdx),%edx
 29f52f2:	test   %edx,%edx
 29f52f4:	je     29fc60f <wasm[0]::function[1015]::helper::object_read+0x1b68f>
 29f52fa:	test   %edx,%edx
 29f52fc:	je     29fc611 <wasm[0]::function[1015]::helper::object_read+0x1b691>
 29f5302:	mov    %edx,%r12d
 29f5305:	lea    (%rcx,%r12,1),%rdx
 29f5309:	cmp    %rax,%r12
 29f530c:	cmova  %r8,%rdx
 29f5310:	mov    0x10(%rdx),%edx
 29f5313:	test   %edx,%edx
 29f5315:	je     29fc613 <wasm[0]::function[1015]::helper::object_read+0x1b693>
 29f531b:	test   %edx,%edx
 29f531d:	je     29fc615 <wasm[0]::function[1015]::helper::object_read+0x1b695>
 29f5323:	mov    %edx,%r12d
 29f5326:	lea    0x10(%rcx,%r12,1),%rcx
 29f532b:	cmp    %rax,%r12
 29f532e:	cmova  %r8,%rcx
 29f5332:	mov    (%rcx),%r13d
 29f5335:	mov    %r13,0x240(%rsp)
 29f533d:	mov    0x98(%rsp),%r8d
 29f5345:	mov    0x190(%rsp),%rax
 29f534d:	mov    0x28(%rax),%rax
 29f5351:	mov    0x234(%rax),%r13d
 29f5358:	mov    %r13,0x238(%rsp)
 29f5360:	mov    0x230(%rsp),%rax
 29f5368:	mov    %rax,0x1c8(%rsp)
 29f5370:	mov    %edx,0x78(%rsp)
 29f5374:	mov    %r8d,0x88(%rsp)
 29f537c:	mov    %r14d,0xb8(%rsp)
 29f5384:	mov    %edi,0xc8(%rsp)
 29f538b:	mov    %r15d,0xa8(%rsp)
 29f5393:	mov    %esi,0xb0(%rsp)
 29f539a:	mov    0x198(%rsp),%r9
 29f53a2:	mov    %r9d,0xe8(%rsp)
 29f53aa:	mov    0x1a0(%rsp),%rdx
 29f53b2:	mov    %edx,0xd8(%rsp)
 29f53b9:	mov    %r10d,0xd0(%rsp)
 29f53c1:	mov    %r11d,0xc0(%rsp)
 29f53c9:	mov    %ebx,0x98(%rsp)
 29f53d0:	mov    0x2e8(%rsp),%r13
 29f53d8:	mov    0x0(%r13),%rcx
 29f53dc:	mov    0x228(%rsp),%rax
 29f53e4:	cmp    %rax,%rcx
 29f53e7:	jae    29fb51e <wasm[0]::function[1015]::helper::object_read+0x1a59e>
 29f53ed:	jmp    29f53fa <wasm[0]::function[1015]::helper::object_read+0x1447a>
 29f53f2:	mov    %rdx,0x228(%rsp)
 29f53fa:	mov    0xb8(%rsp),%r14d
 29f5402:	mov    0xc8(%rsp),%edi
 29f5409:	mov    0xa8(%rsp),%r15d
 29f5411:	mov    0xb0(%rsp),%esi
 29f5418:	mov    0xe8(%rsp),%r9d
 29f5420:	mov    %r9,0x198(%rsp)
 29f5428:	mov    0xd8(%rsp),%r10d
 29f5430:	mov    %r10,0x1a0(%rsp)
 29f5438:	mov    0xd0(%rsp),%r10d
 29f5440:	mov    0xc0(%rsp),%r11d
 29f5448:	mov    0x98(%rsp),%ebx
 29f544f:	mov    0x240(%rsp),%rax
 29f5457:	mov    0x230(%rsp),%rcx
 29f545f:	cmp    %eax,%ecx
 29f5461:	jb     29f5474 <wasm[0]::function[1015]::helper::object_read+0x144f4>
 29f5467:	mov    0x1c8(%rsp),%rax
 29f546f:	jmp    29f56bf <wasm[0]::function[1015]::helper::object_read+0x1473f>
 29f5474:	mov    0x78(%rsp),%eax
 29f5478:	test   %eax,%eax
 29f547a:	je     29fc617 <wasm[0]::function[1015]::helper::object_read+0x1b697>
 29f5480:	test   %eax,%eax
 29f5482:	je     29fc619 <wasm[0]::function[1015]::helper::object_read+0x1b699>
 29f5488:	mov    0x2e0(%rsp),%r12
 29f5490:	mov    0x28(%r12),%r8
 29f5495:	mov    0x20(%r12),%r9
 29f549a:	mov    %eax,%r11d
 29f549d:	lea    0x10(%r9,%r11,1),%rsi
 29f54a2:	xor    %r10,%r10
 29f54a5:	cmp    %r8,%r11
 29f54a8:	cmova  %r10,%rsi
 29f54ac:	mov    (%rsi),%edx
 29f54ae:	cmp    %edx,%ecx
 29f54b0:	jae    29fc61b <wasm[0]::function[1015]::helper::object_read+0x1b69b>
 29f54b6:	mov    %edx,%r11d
 29f54b9:	shl    $0x2,%r11
 29f54bd:	shr    $0x20,%r11
 29f54c1:	test   %r11,%r11
 29f54c4:	jne    29fc61d <wasm[0]::function[1015]::helper::object_read+0x1b69d>
 29f54ca:	shl    $0x2,%edx
 29f54cd:	add    $0x14,%edx
 29f54d0:	jb     29fc61f <wasm[0]::function[1015]::helper::object_read+0x1b69f>
 29f54d6:	add    %edx,%eax
 29f54d8:	jb     29fc621 <wasm[0]::function[1015]::helper::object_read+0x1b6a1>
 29f54de:	mov    %eax,%eax
 29f54e0:	lea    (%r9,%rax,1),%r11
 29f54e4:	cmp    %r8,%rax
 29f54e7:	cmova  %r10,%r11
 29f54eb:	mov    %rcx,%rax
 29f54ee:	shl    $0x2,%eax
 29f54f1:	mov    %rcx,0x230(%rsp)
 29f54f9:	add    $0x14,%eax
 29f54ff:	sub    %eax,%edx
 29f5501:	sub    %rdx,%r11
 29f5504:	mov    (%r11),%edx
 29f5507:	test   %edx,%edx
 29f5509:	je     29fc623 <wasm[0]::function[1015]::helper::object_read+0x1b6a3>
 29f550f:	mov    0x88(%rsp),%eax
 29f5516:	cmp    %eax,%edx
 29f5518:	je     29f560e <wasm[0]::function[1015]::helper::object_read+0x1468e>
 29f551e:	xor    %ecx,%ecx
 29f5520:	test   %edx,%edx
 29f5522:	jne    29f5535 <wasm[0]::function[1015]::helper::object_read+0x145b5>
 29f5528:	mov    0x238(%rsp),%r13
 29f5530:	jmp    29f5586 <wasm[0]::function[1015]::helper::object_read+0x14606>
 29f5535:	xor    %ecx,%ecx
 29f5537:	test   $0x1,%edx
 29f553d:	je     29f5550 <wasm[0]::function[1015]::helper::object_read+0x145d0>
 29f5543:	mov    0x238(%rsp),%r13
 29f554b:	jmp    29f5586 <wasm[0]::function[1015]::helper::object_read+0x14606>
 29f5550:	mov    0x2e0(%rsp),%r12
 29f5558:	mov    0x28(%r12),%rcx
 29f555d:	mov    0x20(%r12),%rsi
 29f5562:	mov    %edx,%edi
 29f5564:	lea    0x4(%rsi,%rdi,1),%rsi
 29f5569:	xor    %r8,%r8
 29f556c:	cmp    %rcx,%rdi
 29f556f:	cmova  %r8,%rsi
 29f5573:	mov    (%rsi),%ecx
 29f5575:	mov    0x238(%rsp),%r13
 29f557d:	cmp    %r13d,%ecx
 29f5580:	sete   %cl
 29f5583:	movzbl %cl,%ecx
 29f5586:	test   %ecx,%ecx
 29f5588:	je     29fc625 <wasm[0]::function[1015]::helper::object_read+0x1b6a5>
 29f558e:	xor    %ecx,%ecx
 29f5590:	test   %eax,%eax
 29f5592:	je     29f55da <wasm[0]::function[1015]::helper::object_read+0x1465a>
 29f5598:	mov    0x88(%rsp),%eax
 29f559f:	xor    %ecx,%ecx
 29f55a1:	test   $0x1,%eax
 29f55a6:	jne    29f55da <wasm[0]::function[1015]::helper::object_read+0x1465a>
 29f55ac:	mov    0x2e0(%rsp),%r12
 29f55b4:	mov    0x28(%r12),%rcx
 29f55b9:	mov    0x20(%r12),%rdi
 29f55be:	mov    %eax,%esi
 29f55c0:	lea    0x4(%rdi,%rsi,1),%rax
 29f55c5:	xor    %rdi,%rdi
 29f55c8:	cmp    %rcx,%rsi
 29f55cb:	cmova  %rdi,%rax
 29f55cf:	mov    (%rax),%eax
 29f55d1:	cmp    %r13d,%eax
 29f55d4:	sete   %al
 29f55d7:	movzbl %al,%ecx
 29f55da:	test   %ecx,%ecx
 29f55dc:	je     29fc627 <wasm[0]::function[1015]::helper::object_read+0x1b6a7>
 29f55e2:	mov    0x88(%rsp),%ecx
 29f55e9:	xor    %r8d,%r8d
 29f55ec:	test   %ecx,%ecx
 29f55ee:	je     29fc629 <wasm[0]::function[1015]::helper::object_read+0x1b6a9>
 29f55f4:	mov    0x190(%rsp),%rsi
 29f55fc:	mov    0x190(%rsp),%rdi
 29f5604:	call   2ae5540 <wasm[0]::function[1057]::helper::string_equality>
 29f5609:	jmp    29f561e <wasm[0]::function[1015]::helper::object_read+0x1469e>
 29f560e:	mov    0x238(%rsp),%r13
 29f5616:	mov    0x278(%rsp),%rax
 29f561e:	mov    0x78(%rsp),%edx
 29f5622:	mov    0x88(%rsp),%r8d
 29f562a:	mov    0xb8(%rsp),%r14d
 29f5632:	mov    0xc8(%rsp),%edi
 29f5639:	mov    0xa8(%rsp),%r15d
 29f5641:	mov    0xb0(%rsp),%esi
 29f5648:	mov    0xe8(%rsp),%r9d
 29f5650:	mov    %r9,0x198(%rsp)
 29f5658:	mov    0xd8(%rsp),%r10d
 29f5660:	mov    %r10,0x1a0(%rsp)
 29f5668:	mov    0xd0(%rsp),%r10d
 29f5670:	mov    0xc0(%rsp),%r11d
 29f5678:	mov    0x98(%rsp),%ebx
 29f567f:	test   %eax,%eax
 29f5681:	je     29f5694 <wasm[0]::function[1015]::helper::object_read+0x14714>
 29f5687:	mov    0x230(%rsp),%rcx
 29f568f:	jmp    29f56bf <wasm[0]::function[1015]::helper::object_read+0x1473f>
 29f5694:	mov    0x230(%rsp),%rcx
 29f569c:	add    $0x1,%ecx
 29f56a2:	mov    %rax,0x1c8(%rsp)
 29f56aa:	mov    %rcx,0x230(%rsp)
 29f56b2:	mov    %r13,0x238(%rsp)
 29f56ba:	jmp    29f5370 <wasm[0]::function[1015]::helper::object_read+0x143f0>
 29f56bf:	xor    %edx,%edx
 29f56c1:	xor    %r8,%r8
 29f56c4:	test   %eax,%eax
 29f56c6:	je     29f5ade <wasm[0]::function[1015]::helper::object_read+0x14b5e>
 29f56cc:	test   %r14d,%r14d
 29f56cf:	je     29fc62b <wasm[0]::function[1015]::helper::object_read+0x1b6ab>
 29f56d5:	xor    %eax,%eax
 29f56d7:	test   $0x1,%r14d
 29f56de:	jne    29f5725 <wasm[0]::function[1015]::helper::object_read+0x147a5>
 29f56e4:	mov    0x2e0(%rsp),%r12
 29f56ec:	mov    0x28(%r12),%rsi
 29f56f1:	mov    0x20(%r12),%rax
 29f56f6:	mov    %r14d,%r8d
 29f56f9:	lea    0x4(%rax,%r8,1),%rax
 29f56fe:	xor    %rdx,%rdx
 29f5701:	cmp    %rsi,%r8
 29f5704:	cmova  %rdx,%rax
 29f5708:	mov    (%rax),%esi
 29f570a:	mov    0x190(%rsp),%rax
 29f5712:	mov    0x28(%rax),%r8
 29f5716:	cmp    0x160(%r8),%esi
 29f571d:	sete   %sil
 29f5721:	movzbl %sil,%eax
 29f5725:	test   %eax,%eax
 29f5727:	jne    29f5972 <wasm[0]::function[1015]::helper::object_read+0x149f2>
 29f572d:	xor    %eax,%eax
 29f572f:	test   $0x1,%r14d
 29f5736:	jne    29f577a <wasm[0]::function[1015]::helper::object_read+0x147fa>
 29f573c:	mov    0x2e0(%rsp),%r12
 29f5744:	mov    0x28(%r12),%rax
 29f5749:	mov    0x20(%r12),%rdx
 29f574e:	mov    %r14d,%esi
 29f5751:	lea    0x4(%rdx,%rsi,1),%rdx
 29f5756:	xor    %r8,%r8
 29f5759:	cmp    %rax,%rsi
 29f575c:	cmova  %r8,%rdx
 29f5760:	mov    (%rdx),%eax
 29f5762:	mov    0x190(%rsp),%rsi
 29f576a:	mov    0x28(%rsi),%rdx
 29f576e:	cmp    0x15c(%rdx),%eax
 29f5774:	sete   %al
 29f5777:	movzbl %al,%eax
 29f577a:	test   %eax,%eax
 29f577c:	je     29fc62d <wasm[0]::function[1015]::helper::object_read+0x1b6ad>
 29f5782:	test   %r14d,%r14d
 29f5785:	je     29fc62f <wasm[0]::function[1015]::helper::object_read+0x1b6af>
 29f578b:	mov    0x2e0(%rsp),%r12
 29f5793:	mov    0x28(%r12),%rsi
 29f5798:	mov    0x20(%r12),%r12
 29f579d:	mov    %r14d,%eax
 29f57a0:	lea    (%r12,%rax,1),%rdx
 29f57a4:	xor    %r8,%r8
 29f57a7:	cmp    %rsi,%rax
 29f57aa:	cmova  %r8,%rdx
 29f57ae:	mov    0x14(%rdx),%r13d
 29f57b2:	mov    0x18(%rdx),%eax
 29f57b5:	mov    0x1c(%rdx),%edx
 29f57b8:	test   %r13d,%r13d
 29f57bb:	je     29fc631 <wasm[0]::function[1015]::helper::object_read+0x1b6b1>
 29f57c1:	test   %r13d,%r13d
 29f57c4:	je     29fc633 <wasm[0]::function[1015]::helper::object_read+0x1b6b3>
 29f57ca:	mov    %r13d,%r9d
 29f57cd:	lea    0x10(%r12,%r9,1),%r14
 29f57d2:	cmp    %rsi,%r9
 29f57d5:	cmova  %r8,%r14
 29f57d9:	mov    (%r14),%r14d
 29f57dc:	cmp    %r14d,%ecx
 29f57df:	jae    29fc635 <wasm[0]::function[1015]::helper::object_read+0x1b6b5>
 29f57e5:	mov    %r14d,%r9d
 29f57e8:	shr    $0x20,%r9
 29f57ec:	test   %r9,%r9
 29f57ef:	jne    29fc637 <wasm[0]::function[1015]::helper::object_read+0x1b6b7>
 29f57f5:	add    $0x14,%r14d
 29f57f9:	jb     29fc639 <wasm[0]::function[1015]::helper::object_read+0x1b6b9>
 29f57ff:	add    %r14d,%r13d
 29f5802:	jb     29fc63b <wasm[0]::function[1015]::helper::object_read+0x1b6bb>
 29f5808:	mov    %r13d,%r9d
 29f580b:	add    %r9,%r12
 29f580e:	cmp    %rsi,%r9
 29f5811:	cmova  %r8,%r12
 29f5815:	lea    0x14(%rcx),%esi
 29f5818:	sub    %esi,%r14d
 29f581b:	sub    %r14,%r12
 29f581e:	movzbq (%r12),%r9
 29f5823:	mov    %r9,0x238(%rsp)
 29f582b:	test   %eax,%eax
 29f582d:	je     29f58c2 <wasm[0]::function[1015]::helper::object_read+0x14942>
 29f5833:	test   %eax,%eax
 29f5835:	je     29fc63d <wasm[0]::function[1015]::helper::object_read+0x1b6bd>
 29f583b:	test   %eax,%eax
 29f583d:	je     29fc63f <wasm[0]::function[1015]::helper::object_read+0x1b6bf>
 29f5843:	mov    0x2e0(%rsp),%r12
 29f584b:	mov    0x28(%r12),%rsi
 29f5850:	mov    0x20(%r12),%r8
 29f5855:	mov    %eax,%r14d
 29f5858:	lea    0x10(%r8,%r14,1),%r13
 29f585d:	xor    %r12,%r12
 29f5860:	cmp    %rsi,%r14
 29f5863:	cmova  %r12,%r13
 29f5867:	mov    0x0(%r13),%r13d
 29f586b:	cmp    %r13d,%ecx
 29f586e:	jae    29fc641 <wasm[0]::function[1015]::helper::object_read+0x1b6c1>
 29f5874:	mov    %r13d,%r14d
 29f5877:	shl    $0x3,%r14
 29f587b:	shr    $0x20,%r14
 29f587f:	test   %r14,%r14
 29f5882:	jne    29fc643 <wasm[0]::function[1015]::helper::object_read+0x1b6c3>
 29f5888:	shl    $0x3,%r13d
 29f588c:	add    $0x18,%r13d
 29f5890:	jb     29fc645 <wasm[0]::function[1015]::helper::object_read+0x1b6c5>
 29f5896:	add    %r13d,%eax
 29f5899:	jb     29fc647 <wasm[0]::function[1015]::helper::object_read+0x1b6c7>
 29f589f:	mov    %eax,%r9d
 29f58a2:	lea    (%r8,%r9,1),%rax
 29f58a6:	cmp    %rsi,%r9
 29f58a9:	cmova  %r12,%rax
 29f58ad:	mov    %rcx,%rsi
 29f58b0:	shl    $0x3,%esi
 29f58b3:	add    $0x18,%esi
 29f58b9:	sub    %esi,%r13d
 29f58bc:	sub    %r13,%rax
 29f58bf:	mov    (%rax),%r8
 29f58c2:	xor    %esi,%esi
 29f58c4:	test   %edx,%edx
 29f58c6:	jne    29f58d9 <wasm[0]::function[1015]::helper::object_read+0x14959>
 29f58cc:	mov    0x238(%rsp),%r9
 29f58d4:	jmp    29f5969 <wasm[0]::function[1015]::helper::object_read+0x149e9>
 29f58d9:	test   %edx,%edx
 29f58db:	je     29fc649 <wasm[0]::function[1015]::helper::object_read+0x1b6c9>
 29f58e1:	test   %edx,%edx
 29f58e3:	je     29fc64b <wasm[0]::function[1015]::helper::object_read+0x1b6cb>
 29f58e9:	mov    0x2e0(%rsp),%r12
 29f58f1:	mov    0x28(%r12),%rax
 29f58f6:	mov    0x20(%r12),%rsi
 29f58fb:	mov    %edx,%r14d
 29f58fe:	lea    0x10(%rsi,%r14,1),%r13
 29f5903:	xor    %r12,%r12
 29f5906:	cmp    %rax,%r14
 29f5909:	cmova  %r12,%r13
 29f590d:	mov    0x0(%r13),%r13d
 29f5911:	cmp    %r13d,%ecx
 29f5914:	jae    29fc64d <wasm[0]::function[1015]::helper::object_read+0x1b6cd>
 29f591a:	mov    %r13d,%r14d
 29f591d:	shl    $0x2,%r14
 29f5921:	shr    $0x20,%r14
 29f5925:	test   %r14,%r14
 29f5928:	jne    29fc64f <wasm[0]::function[1015]::helper::object_read+0x1b6cf>
 29f592e:	shl    $0x2,%r13d
 29f5932:	add    $0x14,%r13d
 29f5936:	jb     29fc651 <wasm[0]::function[1015]::helper::object_read+0x1b6d1>
 29f593c:	add    %r13d,%edx
 29f593f:	jb     29fc653 <wasm[0]::function[1015]::helper::object_read+0x1b6d3>
 29f5945:	mov    %edx,%r9d
 29f5948:	lea    (%rsi,%r9,1),%rdx
 29f594c:	cmp    %rax,%r9
 29f594f:	cmova  %r12,%rdx
 29f5953:	shl    $0x2,%ecx
 29f5956:	lea    0x14(%rcx),%eax
 29f5959:	sub    %eax,%r13d
 29f595c:	sub    %r13,%rdx
 29f595f:	mov    (%rdx),%esi
 29f5961:	mov    0x238(%rsp),%r9
 29f5969:	movzbl %r9b,%edx
 29f596d:	jmp    29f5ade <wasm[0]::function[1015]::helper::object_read+0x14b5e>
 29f5972:	xor    %eax,%eax
 29f5974:	test   $0x1,%r14d
 29f597b:	jne    29f59c3 <wasm[0]::function[1015]::helper::object_read+0x14a43>
 29f5981:	mov    0x2e0(%rsp),%r12
 29f5989:	mov    0x28(%r12),%rsi
 29f598e:	mov    0x20(%r12),%r8
 29f5993:	mov    %r14d,%eax
 29f5996:	lea    0x4(%r8,%rax,1),%r8
 29f599b:	xor    %rdx,%rdx
 29f599e:	cmp    %rsi,%rax
 29f59a1:	cmova  %rdx,%r8
 29f59a5:	mov    (%r8),%r8d
 29f59a8:	mov    0x190(%rsp),%rsi
 29f59b0:	mov    0x28(%rsi),%r9
 29f59b4:	cmp    0x160(%r9),%r8d
 29f59bb:	sete   %r8b
 29f59bf:	movzbl %r8b,%eax
 29f59c3:	test   %eax,%eax
 29f59c5:	je     29fc655 <wasm[0]::function[1015]::helper::object_read+0x1b6d5>
 29f59cb:	test   %r14d,%r14d
 29f59ce:	je     29fc657 <wasm[0]::function[1015]::helper::object_read+0x1b6d7>
 29f59d4:	mov    0x2e0(%rsp),%r12
 29f59dc:	mov    0x28(%r12),%rdx
 29f59e1:	mov    0x20(%r12),%rsi
 29f59e6:	mov    %r14d,%eax
 29f59e9:	lea    (%rsi,%rax,1),%r12
 29f59ed:	xor    %r8,%r8
 29f59f0:	cmp    %rdx,%rax
 29f59f3:	cmova  %r8,%r12
 29f59f7:	mov    0x10(%r12),%r14d
 29f59fc:	test   %r14d,%r14d
 29f59ff:	je     29fc659 <wasm[0]::function[1015]::helper::object_read+0x1b6d9>
 29f5a05:	test   %r14d,%r14d
 29f5a08:	je     29fc65b <wasm[0]::function[1015]::helper::object_read+0x1b6db>
 29f5a0e:	mov    %r14d,%r9d
 29f5a11:	lea    (%rsi,%r9,1),%r12
 29f5a15:	cmp    %rdx,%r9
 29f5a18:	cmova  %r8,%r12
 29f5a1c:	mov    0x10(%r12),%r12d
 29f5a21:	test   %r12d,%r12d
 29f5a24:	je     29fc65d <wasm[0]::function[1015]::helper::object_read+0x1b6dd>
 29f5a2a:	test   %r12d,%r12d
 29f5a2d:	je     29fc65f <wasm[0]::function[1015]::helper::object_read+0x1b6df>
 29f5a33:	mov    %r12d,%r9d
 29f5a36:	lea    0x10(%rsi,%r9,1),%rsi
 29f5a3b:	cmp    %rdx,%r9
 29f5a3e:	cmova  %r8,%rsi
 29f5a42:	cmp    (%rsi),%ecx
 29f5a44:	setae  %dl
 29f5a47:	cmp    $0x2,%ecx
 29f5a4a:	setae  %sil
 29f5a4e:	or     %esi,%edx
 29f5a50:	test   %dl,%dl
 29f5a52:	jne    29fc661 <wasm[0]::function[1015]::helper::object_read+0x1b6e1>
 29f5a58:	mov    0x2e0(%rsp),%r12
 29f5a60:	mov    0x28(%r12),%rsi
 29f5a65:	mov    %rax,%rdx
 29f5a68:	add    0x20(%r12),%rdx
 29f5a6d:	xor    %r8,%r8
 29f5a70:	cmp    %rsi,%rax
 29f5a73:	cmova  %r8,%rdx
 29f5a77:	mov    0x14(%rdx),%edx
 29f5a7a:	test   %ecx,%ecx
 29f5a7c:	je     29f5aad <wasm[0]::function[1015]::helper::object_read+0x14b2d>
 29f5a82:	mov    0x2e0(%rsp),%r12
 29f5a8a:	mov    0x28(%r12),%r8
 29f5a8f:	mov    0x20(%r12),%rsi
 29f5a94:	add    %rax,%rsi
 29f5a97:	xor    %r12,%r12
 29f5a9a:	cmp    %r8,%rax
 29f5a9d:	cmova  %r12,%rsi
 29f5aa1:	mov    0x20(%rsi),%r8
 29f5aa5:	mov    0x2c(%rsi),%esi
 29f5aa8:	jmp    29f5ad3 <wasm[0]::function[1015]::helper::object_read+0x14b53>
 29f5aad:	mov    0x2e0(%rsp),%r12
 29f5ab5:	mov    0x28(%r12),%r8
 29f5aba:	mov    0x20(%r12),%rsi
 29f5abf:	add    %rax,%rsi
 29f5ac2:	xor    %r12,%r12
 29f5ac5:	cmp    %r8,%rax
 29f5ac8:	cmova  %r12,%rsi
 29f5acc:	mov    0x18(%rsi),%r8
 29f5ad0:	mov    0x28(%rsi),%esi
 29f5ad3:	shl    $0x3,%ecx
 29f5ad6:	shr    %cl,%edx
 29f5ad8:	and    $0xff,%edx
 29f5ade:	mov    0x198(%rsp),%r9
 29f5ae6:	mov    %r9d,0xa8(%rsp)
 29f5aee:	mov    0x1a0(%rsp),%rax
 29f5af6:	mov    %eax,0xc8(%rsp)
 29f5afd:	mov    %r10d,0xb8(%rsp)
 29f5b05:	mov    %r11d,0x88(%rsp)
 29f5b0d:	mov    %ebx,0x78(%rsp)
 29f5b11:	mov    0x1d0(%rsp),%rcx
 29f5b19:	cmp    $0x2,%ecx
 29f5b1c:	je     29f5e29 <wasm[0]::function[1015]::helper::object_read+0x14ea9>
 29f5b22:	cmp    $0x4,%ecx
 29f5b25:	je     29f5d61 <wasm[0]::function[1015]::helper::object_read+0x14de1>
 29f5b2b:	cmp    $0x3,%ecx
 29f5b2e:	je     29f5d25 <wasm[0]::function[1015]::helper::object_read+0x14da5>
 29f5b34:	cmp    $0xa,%ecx
 29f5b37:	je     29f5c60 <wasm[0]::function[1015]::helper::object_read+0x14ce0>
 29f5b3d:	test   %ecx,%ecx
 29f5b3f:	sete   %al
 29f5b42:	cmp    $0x1,%ecx
 29f5b45:	sete   %cl
 29f5b48:	or     %ecx,%eax
 29f5b4a:	test   %al,%al
 29f5b4c:	jne    29f5c59 <wasm[0]::function[1015]::helper::object_read+0x14cd9>
 29f5b52:	xor    %eax,%eax
 29f5b54:	test   %edi,%edi
 29f5b56:	je     29f5bab <wasm[0]::function[1015]::helper::object_read+0x14c2b>
 29f5b5c:	xor    %eax,%eax
 29f5b5e:	test   $0x1,%edi
 29f5b64:	jne    29f5bab <wasm[0]::function[1015]::helper::object_read+0x14c2b>
 29f5b6a:	mov    0x2e0(%rsp),%r12
 29f5b72:	mov    0x28(%r12),%rax
 29f5b77:	mov    0x20(%r12),%rcx
 29f5b7c:	mov    %edi,%r9d
 29f5b7f:	lea    0x4(%rcx,%r9,1),%rcx
 29f5b84:	xor    %r10,%r10
 29f5b87:	cmp    %rax,%r9
 29f5b8a:	cmova  %r10,%rcx
 29f5b8e:	mov    (%rcx),%ecx
 29f5b90:	mov    0x190(%rsp),%rax
 29f5b98:	mov    0x28(%rax),%r9
 29f5b9c:	cmp    0x1d4(%r9),%ecx
 29f5ba3:	sete   %r9b
 29f5ba7:	movzbl %r9b,%eax
 29f5bab:	test   %eax,%eax
 29f5bad:	jne    29f5bba <wasm[0]::function[1015]::helper::object_read+0x14c3a>
 29f5bb3:	xor    %eax,%eax
 29f5bb5:	jmp    29f5c4c <wasm[0]::function[1015]::helper::object_read+0x14ccc>
 29f5bba:	xor    %eax,%eax
 29f5bbc:	test   %edi,%edi
 29f5bbe:	je     29f5c10 <wasm[0]::function[1015]::helper::object_read+0x14c90>
 29f5bc4:	xor    %eax,%eax
 29f5bc6:	test   $0x1,%edi
 29f5bcc:	jne    29f5c10 <wasm[0]::function[1015]::helper::object_read+0x14c90>
 29f5bd2:	mov    0x2e0(%rsp),%r12
 29f5bda:	mov    0x28(%r12),%rax
 29f5bdf:	mov    0x20(%r12),%r9
 29f5be4:	mov    %edi,%ecx
 29f5be6:	lea    0x4(%r9,%rcx,1),%r9
 29f5beb:	xor    %r10,%r10
 29f5bee:	cmp    %rax,%rcx
 29f5bf1:	cmova  %r10,%r9
 29f5bf5:	mov    (%r9),%eax
 29f5bf8:	mov    0x190(%rsp),%rcx
 29f5c00:	mov    0x28(%rcx),%rcx
 29f5c04:	cmp    0x1d4(%rcx),%eax
 29f5c0a:	sete   %al
 29f5c0d:	movzbl %al,%eax
 29f5c10:	test   %eax,%eax
 29f5c12:	je     29fc663 <wasm[0]::function[1015]::helper::object_read+0x1b6e3>
 29f5c18:	test   %edi,%edi
 29f5c1a:	je     29fc665 <wasm[0]::function[1015]::helper::object_read+0x1b6e5>
 29f5c20:	test   %edi,%edi
 29f5c22:	je     29fc667 <wasm[0]::function[1015]::helper::object_read+0x1b6e7>
 29f5c28:	mov    0x2e0(%rsp),%r12
 29f5c30:	mov    0x28(%r12),%rax
 29f5c35:	mov    %edi,%edi
 29f5c37:	mov    %rdi,%rcx
 29f5c3a:	add    0x20(%r12),%rcx
 29f5c3f:	xor    %r9,%r9
 29f5c42:	cmp    %rax,%rdi
 29f5c45:	cmova  %r9,%rcx
 29f5c49:	mov    0x3c(%rcx),%eax
 29f5c4c:	test   %eax,%eax
 29f5c4e:	sete   %al
 29f5c51:	movzbl %al,%ebx
 29f5c54:	jmp    29f5e1c <wasm[0]::function[1015]::helper::object_read+0x14e9c>
 29f5c59:	xor    %ebx,%ebx
 29f5c5b:	jmp    29f5e1c <wasm[0]::function[1015]::helper::object_read+0x14e9c>
 29f5c60:	xor    %eax,%eax
 29f5c62:	test   %edi,%edi
 29f5c64:	je     29f5cb6 <wasm[0]::function[1015]::helper::object_read+0x14d36>
 29f5c6a:	xor    %eax,%eax
 29f5c6c:	test   $0x1,%edi
 29f5c72:	jne    29f5cb6 <wasm[0]::function[1015]::helper::object_read+0x14d36>
 29f5c78:	mov    0x2e0(%rsp),%r12
 29f5c80:	mov    0x28(%r12),%rax
 29f5c85:	mov    0x20(%r12),%rcx
 29f5c8a:	mov    %edi,%r9d
 29f5c8d:	lea    0x4(%rcx,%r9,1),%rcx
 29f5c92:	xor    %r10,%r10
 29f5c95:	cmp    %rax,%r9
 29f5c98:	cmova  %r10,%rcx
 29f5c9c:	mov    (%rcx),%eax
 29f5c9e:	mov    0x190(%rsp),%rcx
 29f5ca6:	mov    0x28(%rcx),%rcx
 29f5caa:	cmp    0x23c(%rcx),%eax
 29f5cb0:	sete   %al
 29f5cb3:	movzbl %al,%eax
 29f5cb6:	test   %eax,%eax
 29f5cb8:	je     29fc669 <wasm[0]::function[1015]::helper::object_read+0x1b6e9>
 29f5cbe:	test   %edi,%edi
 29f5cc0:	je     29fc66b <wasm[0]::function[1015]::helper::object_read+0x1b6eb>
 29f5cc6:	test   %edi,%edi
 29f5cc8:	je     29fc66d <wasm[0]::function[1015]::helper::object_read+0x1b6ed>
 29f5cce:	mov    0x2e0(%rsp),%r12
 29f5cd6:	mov    0x28(%r12),%rax
 29f5cdb:	mov    0x20(%r12),%rcx
 29f5ce0:	mov    %edi,%r10d
 29f5ce3:	lea    (%rcx,%r10,1),%r9
 29f5ce7:	xor    %rdi,%rdi
 29f5cea:	cmp    %rax,%r10
 29f5ced:	cmova  %rdi,%r9
 29f5cf1:	mov    0x14(%r9),%r9d
 29f5cf5:	test   %r9d,%r9d
 29f5cf8:	je     29fc66f <wasm[0]::function[1015]::helper::object_read+0x1b6ef>
 29f5cfe:	test   %r9d,%r9d
 29f5d01:	je     29fc671 <wasm[0]::function[1015]::helper::object_read+0x1b6f1>
 29f5d07:	mov    %r9d,%r9d
 29f5d0a:	lea    0x10(%rcx,%r9,1),%rcx
 29f5d0f:	cmp    %rax,%r9
 29f5d12:	cmova  %rdi,%rcx
 29f5d16:	mov    (%rcx),%eax
 29f5d18:	test   %eax,%eax
 29f5d1a:	setne  %al
 29f5d1d:	movzbl %al,%ebx
 29f5d20:	jmp    29f5e1c <wasm[0]::function[1015]::helper::object_read+0x14e9c>
 29f5d25:	mov    0x1d8(%rsp),%rcx
 29f5d2d:	movq   %rcx,%xmm0
 29f5d32:	ucomisd 0x6c06(%rip),%xmm0        # 29fc940 <wasm[0]::function[1015]::helper::object_read+0x1b9c0>
 29f5d3a:	setnp  %al
 29f5d3d:	sete   %cl
 29f5d40:	and    %ecx,%eax
 29f5d42:	ucomisd %xmm0,%xmm0
 29f5d46:	setp   %cl
 29f5d49:	setne  %dil
 29f5d4d:	or     %edi,%ecx
 29f5d4f:	or     %ecx,%eax
 29f5d51:	movzbl %al,%eax
 29f5d54:	test   %eax,%eax
 29f5d56:	sete   %al
 29f5d59:	movzbl %al,%ebx
 29f5d5c:	jmp    29f5e1c <wasm[0]::function[1015]::helper::object_read+0x14e9c>
 29f5d61:	xor    %eax,%eax
 29f5d63:	test   %edi,%edi
 29f5d65:	je     29f5db7 <wasm[0]::function[1015]::helper::object_read+0x14e37>
 29f5d6b:	xor    %eax,%eax
 29f5d6d:	test   $0x1,%edi
 29f5d73:	jne    29f5db7 <wasm[0]::function[1015]::helper::object_read+0x14e37>
 29f5d79:	mov    0x2e0(%rsp),%r12
 29f5d81:	mov    0x28(%r12),%rax
 29f5d86:	mov    0x20(%r12),%rcx
 29f5d8b:	mov    %edi,%r9d
 29f5d8e:	lea    0x4(%rcx,%r9,1),%rcx
 29f5d93:	xor    %r10,%r10
 29f5d96:	cmp    %rax,%r9
 29f5d99:	cmova  %r10,%rcx
 29f5d9d:	mov    (%rcx),%eax
 29f5d9f:	mov    0x190(%rsp),%rcx
 29f5da7:	mov    0x28(%rcx),%rcx
 29f5dab:	cmp    0x234(%rcx),%eax
 29f5db1:	sete   %cl
 29f5db4:	movzbl %cl,%eax
 29f5db7:	test   %eax,%eax
 29f5db9:	je     29fc673 <wasm[0]::function[1015]::helper::object_read+0x1b6f3>
 29f5dbf:	test   %edi,%edi
 29f5dc1:	je     29fc675 <wasm[0]::function[1015]::helper::object_read+0x1b6f5>
 29f5dc7:	test   %edi,%edi
 29f5dc9:	je     29fc677 <wasm[0]::function[1015]::helper::object_read+0x1b6f7>
 29f5dcf:	mov    0x2e0(%rsp),%r12
 29f5dd7:	mov    0x28(%r12),%r9
 29f5ddc:	mov    0x20(%r12),%r10
 29f5de1:	mov    %edi,%eax
 29f5de3:	lea    (%r10,%rax,1),%rdi
 29f5de7:	xor    %r11,%r11
 29f5dea:	cmp    %r9,%rax
 29f5ded:	cmova  %r11,%rdi
 29f5df1:	mov    0x10(%rdi),%eax
 29f5df4:	test   %eax,%eax
 29f5df6:	je     29fc679 <wasm[0]::function[1015]::helper::object_read+0x1b6f9>
 29f5dfc:	test   %eax,%eax
 29f5dfe:	je     29fc67b <wasm[0]::function[1015]::helper::object_read+0x1b6fb>
 29f5e04:	mov    %eax,%ecx
 29f5e06:	lea    0x10(%r10,%rcx,1),%rax
 29f5e0b:	cmp    %r9,%rcx
 29f5e0e:	cmova  %r11,%rax
 29f5e12:	mov    (%rax),%eax
 29f5e14:	test   %eax,%eax
 29f5e16:	setne  %al
 29f5e19:	movzbl %al,%ebx
 29f5e1c:	mov    0x1e0(%rsp),%r11
 29f5e24:	jmp    29f5e42 <wasm[0]::function[1015]::helper::object_read+0x14ec2>
 29f5e29:	mov    0x1d8(%rsp),%rcx
 29f5e31:	test   %rcx,%rcx
 29f5e34:	setne  %al
 29f5e37:	movzbl %al,%ebx
 29f5e3a:	mov    0x1e0(%rsp),%r11
 29f5e42:	cmp    $0x2,%r11d
 29f5e46:	je     29f616a <wasm[0]::function[1015]::helper::object_read+0x151ea>
 29f5e4c:	cmp    $0x4,%r11d
 29f5e50:	je     29f60a0 <wasm[0]::function[1015]::helper::object_read+0x15120>
 29f5e56:	cmp    $0x3,%r11d
 29f5e5a:	je     29f6063 <wasm[0]::function[1015]::helper::object_read+0x150e3>
 29f5e60:	cmp    $0xa,%r11d
 29f5e64:	je     29f5f95 <wasm[0]::function[1015]::helper::object_read+0x15015>
 29f5e6a:	test   %r11d,%r11d
 29f5e6d:	sete   %al
 29f5e70:	cmp    $0x1,%r11d
 29f5e74:	sete   %cl
 29f5e77:	or     %ecx,%eax
 29f5e79:	test   %al,%al
 29f5e7b:	jne    29f5f8d <wasm[0]::function[1015]::helper::object_read+0x1500d>
 29f5e81:	xor    %ecx,%ecx
 29f5e83:	test   %r15d,%r15d
 29f5e86:	je     29f5ed9 <wasm[0]::function[1015]::helper::object_read+0x14f59>
 29f5e8c:	xor    %ecx,%ecx
 29f5e8e:	test   $0x1,%r15d
 29f5e95:	jne    29f5ed9 <wasm[0]::function[1015]::helper::object_read+0x14f59>
 29f5e9b:	mov    0x2e0(%rsp),%r12
 29f5ea3:	mov    0x28(%r12),%rax
 29f5ea8:	mov    0x20(%r12),%rcx
 29f5ead:	mov    %r15d,%edi
 29f5eb0:	lea    0x4(%rcx,%rdi,1),%rcx
 29f5eb5:	xor    %r9,%r9
 29f5eb8:	cmp    %rax,%rdi
 29f5ebb:	cmova  %r9,%rcx
 29f5ebf:	mov    (%rcx),%eax
 29f5ec1:	mov    0x190(%rsp),%rcx
 29f5ec9:	mov    0x28(%rcx),%rcx
 29f5ecd:	cmp    0x1d4(%rcx),%eax
 29f5ed3:	sete   %al
 29f5ed6:	movzbl %al,%ecx
 29f5ed9:	test   %ecx,%ecx
 29f5edb:	jne    29f5ee8 <wasm[0]::function[1015]::helper::object_read+0x14f68>
 29f5ee1:	xor    %eax,%eax
 29f5ee3:	jmp    29f5f7f <wasm[0]::function[1015]::helper::object_read+0x14fff>
 29f5ee8:	xor    %eax,%eax
 29f5eea:	test   %r15d,%r15d
 29f5eed:	je     29f5f40 <wasm[0]::function[1015]::helper::object_read+0x14fc0>
 29f5ef3:	xor    %eax,%eax
 29f5ef5:	test   $0x1,%r15d
 29f5efc:	jne    29f5f40 <wasm[0]::function[1015]::helper::object_read+0x14fc0>
 29f5f02:	mov    0x2e0(%rsp),%r12
 29f5f0a:	mov    0x28(%r12),%rax
 29f5f0f:	mov    0x20(%r12),%rcx
 29f5f14:	mov    %r15d,%edi
 29f5f17:	lea    0x4(%rcx,%rdi,1),%rcx
 29f5f1c:	xor    %r9,%r9
 29f5f1f:	cmp    %rax,%rdi
 29f5f22:	cmova  %r9,%rcx
 29f5f26:	mov    (%rcx),%eax
 29f5f28:	mov    0x190(%rsp),%rcx
 29f5f30:	mov    0x28(%rcx),%rcx
 29f5f34:	cmp    0x1d4(%rcx),%eax
 29f5f3a:	sete   %al
 29f5f3d:	movzbl %al,%eax
 29f5f40:	test   %eax,%eax
 29f5f42:	je     29fc67d <wasm[0]::function[1015]::helper::object_read+0x1b6fd>
 29f5f48:	test   %r15d,%r15d
 29f5f4b:	je     29fc67f <wasm[0]::function[1015]::helper::object_read+0x1b6ff>
 29f5f51:	test   %r15d,%r15d
 29f5f54:	je     29fc681 <wasm[0]::function[1015]::helper::object_read+0x1b701>
 29f5f5a:	mov    0x2e0(%rsp),%r12
 29f5f62:	mov    0x28(%r12),%rax
 29f5f67:	mov    %r15d,%edi
 29f5f6a:	mov    %rdi,%rcx
 29f5f6d:	add    0x20(%r12),%rcx
 29f5f72:	xor    %r9,%r9
 29f5f75:	cmp    %rax,%rdi
 29f5f78:	cmova  %r9,%rcx
 29f5f7c:	mov    0x3c(%rcx),%eax
 29f5f7f:	test   %eax,%eax
 29f5f81:	sete   %al
 29f5f84:	movzbl %al,%r13d
 29f5f88:	jmp    29f617c <wasm[0]::function[1015]::helper::object_read+0x151fc>
 29f5f8d:	xor    %r13d,%r13d
 29f5f90:	jmp    29f617c <wasm[0]::function[1015]::helper::object_read+0x151fc>
 29f5f95:	xor    %eax,%eax
 29f5f97:	test   %r15d,%r15d
 29f5f9a:	je     29f5ff1 <wasm[0]::function[1015]::helper::object_read+0x15071>
 29f5fa0:	xor    %eax,%eax
 29f5fa2:	test   $0x1,%r15d
 29f5fa9:	jne    29f5ff1 <wasm[0]::function[1015]::helper::object_read+0x15071>
 29f5faf:	mov    0x2e0(%rsp),%r12
 29f5fb7:	mov    0x28(%r12),%rdi
 29f5fbc:	mov    0x20(%r12),%r9
 29f5fc1:	mov    %r15d,%r10d
 29f5fc4:	lea    0x4(%r9,%r10,1),%r9
 29f5fc9:	xor    %r11,%r11
 29f5fcc:	cmp    %rdi,%r10
 29f5fcf:	cmova  %r11,%r9
 29f5fd3:	mov    (%r9),%r9d
 29f5fd6:	mov    0x190(%rsp),%rax
 29f5fde:	mov    0x28(%rax),%r10
 29f5fe2:	cmp    0x23c(%r10),%r9d
 29f5fe9:	sete   %r9b
 29f5fed:	movzbl %r9b,%eax
 29f5ff1:	test   %eax,%eax
 29f5ff3:	je     29fc683 <wasm[0]::function[1015]::helper::object_read+0x1b703>
 29f5ff9:	test   %r15d,%r15d
 29f5ffc:	je     29fc685 <wasm[0]::function[1015]::helper::object_read+0x1b705>
 29f6002:	test   %r15d,%r15d
 29f6005:	je     29fc687 <wasm[0]::function[1015]::helper::object_read+0x1b707>
 29f600b:	mov    0x2e0(%rsp),%r12
 29f6013:	mov    0x28(%r12),%rax
 29f6018:	mov    0x20(%r12),%rcx
 29f601d:	mov    %r15d,%r10d
 29f6020:	lea    (%rcx,%r10,1),%r9
 29f6024:	xor    %rdi,%rdi
 29f6027:	cmp    %rax,%r10
 29f602a:	cmova  %rdi,%r9
 29f602e:	mov    0x14(%r9),%r9d
 29f6032:	test   %r9d,%r9d
 29f6035:	je     29fc689 <wasm[0]::function[1015]::helper::object_read+0x1b709>
 29f603b:	test   %r9d,%r9d
 29f603e:	je     29fc68b <wasm[0]::function[1015]::helper::object_read+0x1b70b>
 29f6044:	mov    %r9d,%r9d
 29f6047:	lea    0x10(%rcx,%r9,1),%rcx
 29f604c:	cmp    %rax,%r9
 29f604f:	cmova  %rdi,%rcx
 29f6053:	mov    (%rcx),%eax
 29f6055:	test   %eax,%eax
 29f6057:	setne  %al
 29f605a:	movzbl %al,%r13d
 29f605e:	jmp    29f617c <wasm[0]::function[1015]::helper::object_read+0x151fc>
 29f6063:	mov    0x1e8(%rsp),%r10
 29f606b:	movq   %r10,%xmm0
 29f6070:	ucomisd 0x68d8(%rip),%xmm0        # 29fc950 <wasm[0]::function[1015]::helper::object_read+0x1b9d0>
 29f6078:	setnp  %al
 29f607b:	sete   %cl
 29f607e:	and    %ecx,%eax
 29f6080:	ucomisd %xmm0,%xmm0
 29f6084:	setp   %cl
 29f6087:	setne  %dil
 29f608b:	or     %edi,%ecx
 29f608d:	or     %ecx,%eax
 29f608f:	movzbl %al,%eax
 29f6092:	test   %eax,%eax
 29f6094:	sete   %al
 29f6097:	movzbl %al,%r13d
 29f609b:	jmp    29f617c <wasm[0]::function[1015]::helper::object_read+0x151fc>
 29f60a0:	xor    %eax,%eax
 29f60a2:	test   %r15d,%r15d
 29f60a5:	je     29f60f8 <wasm[0]::function[1015]::helper::object_read+0x15178>
 29f60ab:	xor    %eax,%eax
 29f60ad:	test   $0x1,%r15d
 29f60b4:	jne    29f60f8 <wasm[0]::function[1015]::helper::object_read+0x15178>
 29f60ba:	mov    0x2e0(%rsp),%r12
 29f60c2:	mov    0x28(%r12),%rax
 29f60c7:	mov    0x20(%r12),%rcx
 29f60cc:	mov    %r15d,%edi
 29f60cf:	lea    0x4(%rcx,%rdi,1),%rcx
 29f60d4:	xor    %r9,%r9
 29f60d7:	cmp    %rax,%rdi
 29f60da:	cmova  %r9,%rcx
 29f60de:	mov    (%rcx),%eax
 29f60e0:	mov    0x190(%rsp),%rcx
 29f60e8:	mov    0x28(%rcx),%rcx
 29f60ec:	cmp    0x234(%rcx),%eax
 29f60f2:	sete   %al
 29f60f5:	movzbl %al,%eax
 29f60f8:	test   %eax,%eax
 29f60fa:	je     29fc68d <wasm[0]::function[1015]::helper::object_read+0x1b70d>
 29f6100:	test   %r15d,%r15d
 29f6103:	je     29fc68f <wasm[0]::function[1015]::helper::object_read+0x1b70f>
 29f6109:	test   %r15d,%r15d
 29f610c:	je     29fc691 <wasm[0]::function[1015]::helper::object_read+0x1b711>
 29f6112:	mov    0x2e0(%rsp),%r12
 29f611a:	mov    0x28(%r12),%rax
 29f611f:	mov    0x20(%r12),%rcx
 29f6124:	mov    %r15d,%r10d
 29f6127:	lea    (%rcx,%r10,1),%r9
 29f612b:	xor    %rdi,%rdi
 29f612e:	cmp    %rax,%r10
 29f6131:	cmova  %rdi,%r9
 29f6135:	mov    0x10(%r9),%r9d
 29f6139:	test   %r9d,%r9d
 29f613c:	je     29fc693 <wasm[0]::function[1015]::helper::object_read+0x1b713>
 29f6142:	test   %r9d,%r9d
 29f6145:	je     29fc695 <wasm[0]::function[1015]::helper::object_read+0x1b715>
 29f614b:	mov    %r9d,%r9d
 29f614e:	lea    0x10(%rcx,%r9,1),%rcx
 29f6153:	cmp    %rax,%r9
 29f6156:	cmova  %rdi,%rcx
 29f615a:	mov    (%rcx),%eax
 29f615c:	test   %eax,%eax
 29f615e:	setne  %al
 29f6161:	movzbl %al,%r13d
 29f6165:	jmp    29f617c <wasm[0]::function[1015]::helper::object_read+0x151fc>
 29f616a:	mov    0x1e8(%rsp),%r10
 29f6172:	test   %r10,%r10
 29f6175:	setne  %al
 29f6178:	movzbl %al,%r13d
 29f617c:	cmp    $0x2,%edx
 29f617f:	je     29f6482 <wasm[0]::function[1015]::helper::object_read+0x15502>
 29f6185:	cmp    $0x4,%edx
 29f6188:	je     29f63b7 <wasm[0]::function[1015]::helper::object_read+0x15437>
 29f618e:	cmp    $0x3,%edx
 29f6191:	je     29f6383 <wasm[0]::function[1015]::helper::object_read+0x15403>
 29f6197:	cmp    $0xa,%edx
 29f619a:	je     29f62c3 <wasm[0]::function[1015]::helper::object_read+0x15343>
 29f61a0:	test   %edx,%edx
 29f61a2:	sete   %al
 29f61a5:	cmp    $0x1,%edx
 29f61a8:	sete   %dil
 29f61ac:	or     %edi,%eax
 29f61ae:	test   %al,%al
 29f61b0:	jne    29f62bb <wasm[0]::function[1015]::helper::object_read+0x1533b>
 29f61b6:	xor    %eax,%eax
 29f61b8:	test   %esi,%esi
 29f61ba:	je     29f620c <wasm[0]::function[1015]::helper::object_read+0x1528c>
 29f61c0:	xor    %eax,%eax
 29f61c2:	test   $0x1,%esi
 29f61c8:	jne    29f620c <wasm[0]::function[1015]::helper::object_read+0x1528c>
 29f61ce:	mov    0x2e0(%rsp),%r12
 29f61d6:	mov    0x28(%r12),%r11
 29f61db:	mov    0x20(%r12),%rcx
 29f61e0:	mov    %esi,%eax
 29f61e2:	lea    0x4(%rcx,%rax,1),%r8
 29f61e7:	xor    %rcx,%rcx
 29f61ea:	cmp    %r11,%rax
 29f61ed:	cmova  %rcx,%r8
 29f61f1:	mov    (%r8),%eax
 29f61f4:	mov    0x190(%rsp),%rcx
 29f61fc:	mov    0x28(%rcx),%rcx
 29f6200:	cmp    0x1d4(%rcx),%eax
 29f6206:	sete   %al
 29f6209:	movzbl %al,%eax
 29f620c:	test   %eax,%eax
 29f620e:	jne    29f621b <wasm[0]::function[1015]::helper::object_read+0x1529b>
 29f6214:	xor    %esi,%esi
 29f6216:	jmp    29f62ad <wasm[0]::function[1015]::helper::object_read+0x1532d>
 29f621b:	xor    %edi,%edi
 29f621d:	test   %esi,%esi
 29f621f:	je     29f6271 <wasm[0]::function[1015]::helper::object_read+0x152f1>
 29f6225:	xor    %edi,%edi
 29f6227:	test   $0x1,%esi
 29f622d:	jne    29f6271 <wasm[0]::function[1015]::helper::object_read+0x152f1>
 29f6233:	mov    0x2e0(%rsp),%r12
 29f623b:	mov    0x28(%r12),%rax
 29f6240:	mov    0x20(%r12),%rcx
 29f6245:	mov    %esi,%edx
 29f6247:	lea    0x4(%rcx,%rdx,1),%rcx
 29f624c:	xor    %rdi,%rdi
 29f624f:	cmp    %rax,%rdx
 29f6252:	cmova  %rdi,%rcx
 29f6256:	mov    (%rcx),%eax
 29f6258:	mov    0x190(%rsp),%rcx
 29f6260:	mov    0x28(%rcx),%rcx
 29f6264:	cmp    0x1d4(%rcx),%eax
 29f626a:	sete   %al
 29f626d:	rex movzbl %al,%edi
 29f6271:	test   %edi,%edi
 29f6273:	je     29fc697 <wasm[0]::function[1015]::helper::object_read+0x1b717>
 29f6279:	test   %esi,%esi
 29f627b:	je     29fc699 <wasm[0]::function[1015]::helper::object_read+0x1b719>
 29f6281:	test   %esi,%esi
 29f6283:	je     29fc69b <wasm[0]::function[1015]::helper::object_read+0x1b71b>
 29f6289:	mov    0x2e0(%rsp),%r12
 29f6291:	mov    0x28(%r12),%rax
 29f6296:	mov    %esi,%edx
 29f6298:	mov    %rdx,%rcx
 29f629b:	add    0x20(%r12),%rcx
 29f62a0:	xor    %rsi,%rsi
 29f62a3:	cmp    %rax,%rdx
 29f62a6:	cmova  %rsi,%rcx
 29f62aa:	mov    0x3c(%rcx),%esi
 29f62ad:	test   %esi,%esi
 29f62af:	sete   %al
 29f62b2:	movzbl %al,%r14d
 29f62b6:	jmp    29f6475 <wasm[0]::function[1015]::helper::object_read+0x154f5>
 29f62bb:	xor    %r14d,%r14d
 29f62be:	jmp    29f6475 <wasm[0]::function[1015]::helper::object_read+0x154f5>
 29f62c3:	xor    %eax,%eax
 29f62c5:	test   %esi,%esi
 29f62c7:	je     29f6318 <wasm[0]::function[1015]::helper::object_read+0x15398>
 29f62cd:	xor    %eax,%eax
 29f62cf:	test   $0x1,%esi
 29f62d5:	jne    29f6318 <wasm[0]::function[1015]::helper::object_read+0x15398>
 29f62db:	mov    0x2e0(%rsp),%r12
 29f62e3:	mov    0x28(%r12),%rax
 29f62e8:	mov    0x20(%r12),%rcx
 29f62ed:	mov    %esi,%edx
 29f62ef:	lea    0x4(%rcx,%rdx,1),%rcx
 29f62f4:	xor    %rdi,%rdi
 29f62f7:	cmp    %rax,%rdx
 29f62fa:	cmova  %rdi,%rcx
 29f62fe:	mov    (%rcx),%eax
 29f6300:	mov    0x190(%rsp),%rcx
 29f6308:	mov    0x28(%rcx),%rcx
 29f630c:	cmp    0x23c(%rcx),%eax
 29f6312:	sete   %al
 29f6315:	movzbl %al,%eax
 29f6318:	test   %eax,%eax
 29f631a:	je     29fc69d <wasm[0]::function[1015]::helper::object_read+0x1b71d>
 29f6320:	test   %esi,%esi
 29f6322:	je     29fc69f <wasm[0]::function[1015]::helper::object_read+0x1b71f>
 29f6328:	test   %esi,%esi
 29f632a:	je     29fc6a1 <wasm[0]::function[1015]::helper::object_read+0x1b721>
 29f6330:	mov    0x2e0(%rsp),%r12
 29f6338:	mov    0x28(%r12),%rax
 29f633d:	mov    0x20(%r12),%rcx
 29f6342:	mov    %esi,%edi
 29f6344:	lea    (%rcx,%rdi,1),%rsi
 29f6348:	xor    %rdx,%rdx
 29f634b:	cmp    %rax,%rdi
 29f634e:	cmova  %rdx,%rsi
 29f6352:	mov    0x14(%rsi),%esi
 29f6355:	test   %esi,%esi
 29f6357:	je     29fc6a3 <wasm[0]::function[1015]::helper::object_read+0x1b723>
 29f635d:	test   %esi,%esi
 29f635f:	je     29fc6a5 <wasm[0]::function[1015]::helper::object_read+0x1b725>
 29f6365:	mov    %esi,%esi
 29f6367:	lea    0x10(%rcx,%rsi,1),%rcx
 29f636c:	cmp    %rax,%rsi
 29f636f:	cmova  %rdx,%rcx
 29f6373:	mov    (%rcx),%eax
 29f6375:	test   %eax,%eax
 29f6377:	setne  %al
 29f637a:	movzbl %al,%r14d
 29f637e:	jmp    29f6475 <wasm[0]::function[1015]::helper::object_read+0x154f5>
 29f6383:	movq   %r8,%xmm0
 29f6388:	ucomisd 0x65d0(%rip),%xmm0        # 29fc960 <wasm[0]::function[1015]::helper::object_read+0x1b9e0>
 29f6390:	setnp  %al
 29f6393:	sete   %cl
 29f6396:	and    %ecx,%eax
 29f6398:	ucomisd %xmm0,%xmm0
 29f639c:	setp   %cl
 29f639f:	setne  %dl
 29f63a2:	or     %edx,%ecx
 29f63a4:	or     %ecx,%eax
 29f63a6:	movzbl %al,%ecx
 29f63a9:	test   %ecx,%ecx
 29f63ab:	sete   %dl
 29f63ae:	movzbl %dl,%r14d
 29f63b2:	jmp    29f6475 <wasm[0]::function[1015]::helper::object_read+0x154f5>
 29f63b7:	xor    %eax,%eax
 29f63b9:	test   %esi,%esi
 29f63bb:	je     29f640f <wasm[0]::function[1015]::helper::object_read+0x1548f>
 29f63c1:	xor    %eax,%eax
 29f63c3:	test   $0x1,%esi
 29f63c9:	jne    29f640f <wasm[0]::function[1015]::helper::object_read+0x1548f>
 29f63cf:	mov    0x2e0(%rsp),%r12
 29f63d7:	mov    0x28(%r12),%r10
 29f63dc:	mov    0x20(%r12),%rax
 29f63e1:	mov    %esi,%r11d
 29f63e4:	lea    0x4(%rax,%r11,1),%rdi
 29f63e9:	xor    %rax,%rax
 29f63ec:	cmp    %r10,%r11
 29f63ef:	cmova  %rax,%rdi
 29f63f3:	mov    (%rdi),%r11d
 29f63f6:	mov    0x190(%rsp),%rax
 29f63fe:	mov    0x28(%rax),%rax
 29f6402:	cmp    0x234(%rax),%r11d
 29f6409:	sete   %al
 29f640c:	movzbl %al,%eax
 29f640f:	test   %eax,%eax
 29f6411:	je     29fc6a7 <wasm[0]::function[1015]::helper::object_read+0x1b727>
 29f6417:	test   %esi,%esi
 29f6419:	je     29fc6a9 <wasm[0]::function[1015]::helper::object_read+0x1b729>
 29f641f:	test   %esi,%esi
 29f6421:	je     29fc6ab <wasm[0]::function[1015]::helper::object_read+0x1b72b>
 29f6427:	mov    0x2e0(%rsp),%r12
 29f642f:	mov    0x28(%r12),%rax
 29f6434:	mov    0x20(%r12),%rcx
 29f6439:	mov    %esi,%edi
 29f643b:	lea    (%rcx,%rdi,1),%rsi
 29f643f:	xor    %rdx,%rdx
 29f6442:	cmp    %rax,%rdi
 29f6445:	cmova  %rdx,%rsi
 29f6449:	mov    0x10(%rsi),%esi
 29f644c:	test   %esi,%esi
 29f644e:	je     29fc6ad <wasm[0]::function[1015]::helper::object_read+0x1b72d>
 29f6454:	test   %esi,%esi
 29f6456:	je     29fc6af <wasm[0]::function[1015]::helper::object_read+0x1b72f>
 29f645c:	mov    %esi,%esi
 29f645e:	lea    0x10(%rcx,%rsi,1),%rcx
 29f6463:	cmp    %rax,%rsi
 29f6466:	cmova  %rdx,%rcx
 29f646a:	mov    (%rcx),%eax
 29f646c:	test   %eax,%eax
 29f646e:	setne  %al
 29f6471:	movzbl %al,%r14d
 29f6475:	mov    0x270(%rsp),%rcx
 29f647d:	jmp    29f6494 <wasm[0]::function[1015]::helper::object_read+0x15514>
 29f6482:	test   %r8,%r8
 29f6485:	setne  %al
 29f6488:	movzbl %al,%r14d
 29f648c:	mov    0x270(%rsp),%rcx
 29f6494:	mov    0x270(%rsp),%rcx
 29f649c:	mov    (%rcx),%eax
 29f649e:	mov    %eax,%ecx
 29f64a0:	lea    0x20(%rcx),%rdx
 29f64a4:	mov    0x270(%rsp),%rsi
 29f64ac:	mov    0x4(%rsi),%esi
 29f64af:	cmp    %rsi,%rdx
 29f64b2:	ja     29fb54e <wasm[0]::function[1015]::helper::object_read+0x1a5ce>
 29f64b8:	lea    0x20(%rax),%edx
 29f64bb:	mov    0x270(%rsp),%rsi
 29f64c3:	mov    %edx,(%rsi)
 29f64c5:	mov    0x2e0(%rsp),%r12
 29f64cd:	mov    0x20(%r12),%rdx
 29f64d2:	lea    (%rdx,%rcx,1),%r10
 29f64d6:	movl   $0xb0000042,(%rdx,%rcx,1)
 29f64dd:	mov    0x190(%rsp),%rsi
 29f64e5:	mov    0x28(%rsi),%rsi
 29f64e9:	mov    0x120(%rsi),%esi
 29f64ef:	mov    %esi,0x4(%rdx,%rcx,1)
 29f64f3:	mov    0x268(%rsp),%rsi
 29f64fb:	mov    %esi,0x8(%rdx,%rcx,1)
 29f64ff:	mov    %eax,0xb0(%rsp)
 29f6506:	mov    0x1f0(%rsp),%rcx
 29f650e:	mov    %rcx,0x10(%r10)
 29f6512:	mov    0x1f8(%rsp),%rcx
 29f651a:	mov    %ecx,0x18(%r10)
 29f651e:	mov    0xa8(%rsp),%eax
 29f6525:	mov    %eax,0x1c(%r10)
 29f6529:	mov    0x270(%rsp),%rcx
 29f6531:	mov    (%rcx),%eax
 29f6533:	mov    %eax,%edx
 29f6535:	lea    0x20(%rdx),%rcx
 29f6539:	mov    0x270(%rsp),%rsi
 29f6541:	mov    0x4(%rsi),%esi
 29f6544:	cmp    %rsi,%rcx
 29f6547:	ja     29fb58a <wasm[0]::function[1015]::helper::object_read+0x1a60a>
 29f654d:	lea    0x20(%rax),%ecx
 29f6550:	mov    0x270(%rsp),%rsi
 29f6558:	mov    %ecx,(%rsi)
 29f655a:	mov    0x2e0(%rsp),%r12
 29f6562:	mov    0x20(%r12),%rsi
 29f6567:	lea    (%rsi,%rdx,1),%rcx
 29f656b:	movl   $0xb0000042,(%rsi,%rdx,1)
 29f6572:	mov    0x190(%rsp),%rdi
 29f657a:	mov    0x28(%rdi),%rdi
 29f657e:	mov    0x120(%rdi),%edi
 29f6584:	mov    %edi,0x4(%rsi,%rdx,1)
 29f6588:	mov    0x268(%rsp),%rdi
 29f6590:	mov    %edi,0x8(%rsi,%rdx,1)
 29f6594:	mov    %eax,0xa8(%rsp)
 29f659b:	mov    0x200(%rsp),%rax
 29f65a3:	mov    %rax,0x10(%rcx)
 29f65a7:	mov    0x208(%rsp),%rsi
 29f65af:	mov    %esi,0x18(%rcx)
 29f65b2:	mov    0xc8(%rsp),%eax
 29f65b9:	mov    %eax,0x1c(%rcx)
 29f65bc:	mov    0x270(%rsp),%rcx
 29f65c4:	mov    (%rcx),%eax
 29f65c6:	mov    %eax,%ecx
 29f65c8:	lea    0x20(%rcx),%rdx
 29f65cc:	mov    0x270(%rsp),%rsi
 29f65d4:	mov    0x4(%rsi),%esi
 29f65d7:	cmp    %rsi,%rdx
 29f65da:	ja     29fb5cd <wasm[0]::function[1015]::helper::object_read+0x1a64d>
 29f65e0:	lea    0x20(%rax),%edx
 29f65e3:	mov    0x270(%rsp),%rsi
 29f65eb:	mov    %edx,(%rsi)
 29f65ed:	mov    0x2e0(%rsp),%r12
 29f65f5:	mov    0x20(%r12),%rdx
 29f65fa:	lea    (%rdx,%rcx,1),%r11
 29f65fe:	movl   $0xb0000042,(%rdx,%rcx,1)
 29f6605:	mov    0x190(%rsp),%rsi
 29f660d:	mov    0x28(%rsi),%rsi
 29f6611:	mov    0x120(%rsi),%esi
 29f6617:	mov    %esi,0x4(%rdx,%rcx,1)
 29f661b:	mov    0x268(%rsp),%rsi
 29f6623:	mov    %esi,0x8(%rdx,%rcx,1)
 29f6627:	mov    %eax,0xc8(%rsp)
 29f662e:	mov    0x210(%rsp),%r10
 29f6636:	mov    %r10,0x10(%r11)
 29f663a:	mov    0x218(%rsp),%rsi
 29f6642:	mov    %esi,0x18(%r11)
 29f6646:	mov    0xb8(%rsp),%edx
 29f664d:	mov    %edx,0x1c(%r11)
 29f6651:	mov    0x220(%rsp),%rcx
 29f6659:	mov    0x220(%rsp),%rdx
 29f6661:	test   %edx,%ecx
 29f6663:	jne    29f6750 <wasm[0]::function[1015]::helper::object_read+0x157d0>
 29f6669:	mov    0xb0(%rsp),%esi
 29f6670:	test   %esi,%esi
 29f6672:	je     29fc6b1 <wasm[0]::function[1015]::helper::object_read+0x1b731>
 29f6678:	mov    0xa8(%rsp),%edi
 29f667f:	test   %edi,%edi
 29f6681:	je     29fc6b3 <wasm[0]::function[1015]::helper::object_read+0x1b733>
 29f6687:	test   %eax,%eax
 29f6689:	je     29fc6b5 <wasm[0]::function[1015]::helper::object_read+0x1b735>
 29f668f:	mov    0x270(%rsp),%rcx
 29f6697:	mov    (%rcx),%eax
 29f6699:	mov    %rax,%r15
 29f669c:	mov    %eax,%r11d
 29f669f:	lea    0x20(%r11),%rax
 29f66a3:	mov    0x4(%rcx),%ecx
 29f66a6:	cmp    %rcx,%rax
 29f66a9:	ja     29fb609 <wasm[0]::function[1015]::helper::object_read+0x1a689>
 29f66af:	mov    %r15,%rax
 29f66b2:	add    $0x20,%eax
 29f66b8:	mov    0x270(%rsp),%rcx
 29f66c0:	mov    %eax,(%rcx)
 29f66c2:	mov    0x2e0(%rsp),%r12
 29f66ca:	mov    0x20(%r12),%rcx
 29f66cf:	lea    (%rcx,%r11,1),%rax
 29f66d3:	movl   $0xb0000072,(%rcx,%r11,1)
 29f66db:	mov    0x190(%rsp),%rsi
 29f66e3:	mov    0x28(%rsi),%rdx
 29f66e7:	mov    0x13c(%rdx),%edx
 29f66ed:	mov    %edx,0x4(%rcx,%r11,1)
 29f66f2:	mov    0x268(%rsp),%rdx
 29f66fa:	mov    %edx,0x8(%rcx,%r11,1)
 29f66ff:	test   %ebx,%ebx
 29f6701:	setne  %cl
 29f6704:	movzbl %cl,%r11d
 29f6708:	shl    $0x2,%r11d
 29f670c:	test   %r13d,%r13d
 29f670f:	setne  %cl
 29f6712:	movzbl %cl,%ecx
 29f6715:	shl    $0x3,%ecx
 29f6718:	or     %ecx,%r11d
 29f671b:	test   %r14d,%r14d
 29f671e:	setne  %cl
 29f6721:	movzbl %cl,%ecx
 29f6724:	shl    $1,%ecx
 29f6726:	or     %ecx,%r11d
 29f6729:	mov    %r11d,0x10(%rax)
 29f672d:	mov    0xb0(%rsp),%ecx
 29f6734:	mov    %ecx,0x14(%rax)
 29f6737:	mov    0xa8(%rsp),%ecx
 29f673e:	mov    %ecx,0x18(%rax)
 29f6741:	mov    0xc8(%rsp),%ecx
 29f6748:	mov    %ecx,0x1c(%rax)
 29f674b:	jmp    29f6827 <wasm[0]::function[1015]::helper::object_read+0x158a7>
 29f6750:	mov    0xb0(%rsp),%ecx
 29f6757:	test   %ecx,%ecx
 29f6759:	je     29fc6b7 <wasm[0]::function[1015]::helper::object_read+0x1b737>
 29f675f:	mov    0xa8(%rsp),%ecx
 29f6766:	test   %ecx,%ecx
 29f6768:	je     29fc6b9 <wasm[0]::function[1015]::helper::object_read+0x1b739>
 29f676e:	test   %eax,%eax
 29f6770:	je     29fc6bb <wasm[0]::function[1015]::helper::object_read+0x1b73b>
 29f6776:	mov    0x270(%rsp),%rcx
 29f677e:	mov    (%rcx),%eax
 29f6780:	mov    %rax,%r15
 29f6783:	mov    %eax,%ecx
 29f6785:	lea    0x20(%rcx),%rax
 29f6789:	mov    0x270(%rsp),%rdx
 29f6791:	mov    0x4(%rdx),%edx
 29f6794:	cmp    %rdx,%rax
 29f6797:	ja     29fb64f <wasm[0]::function[1015]::helper::object_read+0x1a6cf>
 29f679d:	mov    %r15,%rax
 29f67a0:	add    $0x20,%eax
 29f67a6:	mov    0x270(%rsp),%rdx
 29f67ae:	mov    %eax,(%rdx)
 29f67b0:	mov    0x2e0(%rsp),%r12
 29f67b8:	mov    0x20(%r12),%rdx
 29f67bd:	lea    (%rdx,%rcx,1),%rax
 29f67c1:	movl   $0xb0000072,(%rdx,%rcx,1)
 29f67c8:	mov    0x190(%rsp),%rsi
 29f67d0:	mov    0x28(%rsi),%rsi
 29f67d4:	mov    0x13c(%rsi),%esi
 29f67da:	mov    %esi,0x4(%rdx,%rcx,1)
 29f67de:	mov    0x268(%rsp),%rsi
 29f67e6:	mov    %esi,0x8(%rdx,%rcx,1)
 29f67ea:	test   %r13d,%r13d
 29f67ed:	setne  %cl
 29f67f0:	movzbl %cl,%ecx
 29f67f3:	shl    $0x3,%ecx
 29f67f6:	or     $0x1,%ecx
 29f67f9:	test   %r14d,%r14d
 29f67fc:	setne  %dl
 29f67ff:	movzbl %dl,%edx
 29f6802:	shl    $1,%edx
 29f6804:	or     %edx,%ecx
 29f6806:	mov    %ecx,0x10(%rax)
 29f6809:	mov    0xb0(%rsp),%ecx
 29f6810:	mov    %ecx,0x14(%rax)
 29f6813:	mov    0xa8(%rsp),%ecx
 29f681a:	mov    %ecx,0x18(%rax)
 29f681d:	mov    0xc8(%rsp),%ecx
 29f6824:	mov    %ecx,0x1c(%rax)
 29f6827:	mov    0x88(%rsp),%eax
 29f682e:	mov    0x78(%rsp),%ecx
 29f6832:	jmp    29f901a <wasm[0]::function[1015]::helper::object_read+0x1809a>
 29f6837:	mov    0xe0(%rsp),%edx
 29f683e:	mov    0x258(%rsp),%rax
 29f6846:	mov    0x260(%rsp),%rcx
 29f684e:	mov    0x2f0(%rsp),%rbx
 29f6856:	mov    0x2f8(%rsp),%r12
 29f685e:	mov    0x300(%rsp),%r13
 29f6866:	mov    0x308(%rsp),%r14
 29f686e:	mov    0x310(%rsp),%r15
 29f6876:	add    $0x320,%rsp
 29f687d:	mov    %rbp,%rsp
 29f6880:	pop    %rbp
 29f6881:	ret    $0x40
 29f6884:	xor    %r9d,%r9d
 29f6887:	test   %edx,%edx
 29f6889:	je     29f68dc <wasm[0]::function[1015]::helper::object_read+0x1595c>
 29f688f:	xor    %r9d,%r9d
 29f6892:	test   $0x1,%edx
 29f6898:	jne    29f68dc <wasm[0]::function[1015]::helper::object_read+0x1595c>
 29f689e:	mov    0x2e0(%rsp),%r12
 29f68a6:	mov    0x28(%r12),%rax
 29f68ab:	mov    0x20(%r12),%rcx
 29f68b0:	mov    %edx,%esi
 29f68b2:	lea    0x4(%rcx,%rsi,1),%rcx
 29f68b7:	xor    %rdi,%rdi
 29f68ba:	cmp    %rax,%rsi
 29f68bd:	cmova  %rdi,%rcx
 29f68c1:	mov    (%rcx),%eax
 29f68c3:	mov    0x190(%rsp),%rsi
 29f68cb:	mov    0x28(%rsi),%rcx
 29f68cf:	cmp    0x254(%rcx),%eax
 29f68d5:	sete   %al
 29f68d8:	movzbl %al,%r9d
 29f68dc:	test   %r9d,%r9d
 29f68df:	je     29fc6bd <wasm[0]::function[1015]::helper::object_read+0x1b73d>
 29f68e5:	test   %edx,%edx
 29f68e7:	je     29fc6bf <wasm[0]::function[1015]::helper::object_read+0x1b73f>
 29f68ed:	test   %edx,%edx
 29f68ef:	je     29fc6c1 <wasm[0]::function[1015]::helper::object_read+0x1b741>
 29f68f5:	mov    0x2e0(%rsp),%r12
 29f68fd:	mov    0x28(%r12),%rsi
 29f6902:	mov    0x20(%r12),%r8
 29f6907:	mov    %edx,%edi
 29f6909:	lea    (%r8,%rdi,1),%rax
 29f690d:	xor    %r8,%r8
 29f6910:	cmp    %rsi,%rdi
 29f6913:	cmova  %r8,%rax
 29f6917:	mov    0x10(%rax),%edx
 29f691a:	test   %edx,%edx
 29f691c:	je     29fc6c3 <wasm[0]::function[1015]::helper::object_read+0x1b743>
 29f6922:	mov    0x68(%rsp),%r9d
 29f6927:	mov    0x1b8(%rsp),%rcx
 29f692f:	mov    0x190(%rsp),%rsi
 29f6937:	mov    0x190(%rsp),%rdi
 29f693f:	mov    0x1c0(%rsp),%r8
 29f6947:	call   29ffc60 <wasm[0]::function[1019]::helper::ordinary_own_descriptor>
 29f694c:	mov    0x80(%rsp),%ecx
 29f6953:	mov    0xa0(%rsp),%edx
 29f695a:	mov    %rdx,%r15
 29f695d:	mov    0x50(%rsp),%edx
 29f6961:	test   %eax,%eax
 29f6963:	jne    29f88fd <wasm[0]::function[1015]::helper::object_read+0x1797d>
 29f6969:	mov    0x58(%rsp),%edi
 29f696d:	mov    0x68(%rsp),%r8d
 29f6972:	xor    %r9d,%r9d
 29f6975:	mov    0x1b8(%rsp),%rsi
 29f697d:	cmp    $0x4,%esi
 29f6980:	je     29f698e <wasm[0]::function[1015]::helper::object_read+0x15a0e>
 29f6986:	mov    %r9,%rsi
 29f6989:	jmp    29f6cfc <wasm[0]::function[1015]::helper::object_read+0x15d7c>
 29f698e:	xor    %esi,%esi
 29f6990:	test   %r8d,%r8d
 29f6993:	je     29f69ea <wasm[0]::function[1015]::helper::object_read+0x15a6a>
 29f6999:	xor    %esi,%esi
 29f699b:	test   $0x1,%r8d
 29f69a2:	jne    29f69ea <wasm[0]::function[1015]::helper::object_read+0x15a6a>
 29f69a8:	mov    0x2e0(%rsp),%r12
 29f69b0:	mov    0x28(%r12),%rsi
 29f69b5:	mov    0x20(%r12),%r9
 29f69ba:	mov    %r8d,%r10d
 29f69bd:	lea    0x4(%r9,%r10,1),%r9
 29f69c2:	xor    %r11,%r11
 29f69c5:	cmp    %rsi,%r10
 29f69c8:	cmova  %r11,%r9
 29f69cc:	mov    (%r9),%esi
 29f69cf:	mov    0x190(%rsp),%r9
 29f69d7:	mov    0x28(%r9),%r9
 29f69db:	cmp    0x234(%r9),%esi
 29f69e2:	sete   %sil
 29f69e6:	movzbl %sil,%esi
 29f69ea:	test   %esi,%esi
 29f69ec:	je     29fc6c5 <wasm[0]::function[1015]::helper::object_read+0x1b745>
 29f69f2:	test   %r8d,%r8d
 29f69f5:	je     29fc6c7 <wasm[0]::function[1015]::helper::object_read+0x1b747>
 29f69fb:	test   %r8d,%r8d
 29f69fe:	je     29fc6c9 <wasm[0]::function[1015]::helper::object_read+0x1b749>
 29f6a04:	mov    0x2e0(%rsp),%r12
 29f6a0c:	mov    0x28(%r12),%rsi
 29f6a11:	mov    0x20(%r12),%r10
 29f6a16:	mov    %r8d,%ebx
 29f6a19:	lea    (%r10,%rbx,1),%r9
 29f6a1d:	xor    %r11,%r11
 29f6a20:	cmp    %rsi,%rbx
 29f6a23:	cmova  %r11,%r9
 29f6a27:	mov    0x10(%r9),%ebx
 29f6a2b:	mov    %ebx,0xe0(%rsp)
 29f6a32:	xor    %r9d,%r9d
 29f6a35:	test   %ebx,%ebx
 29f6a37:	je     29fc6cb <wasm[0]::function[1015]::helper::object_read+0x1b74b>
 29f6a3d:	test   %ebx,%ebx
 29f6a3f:	je     29fc6cd <wasm[0]::function[1015]::helper::object_read+0x1b74d>
 29f6a45:	mov    %ebx,%ebx
 29f6a47:	lea    0x10(%r10,%rbx,1),%r10
 29f6a4c:	cmp    %rsi,%rbx
 29f6a4f:	cmova  %r11,%r10
 29f6a53:	mov    (%r10),%ebx
 29f6a56:	test   %ebx,%ebx
 29f6a58:	sete   %sil
 29f6a5c:	cmp    $0xa,%ebx
 29f6a5f:	seta   %r10b
 29f6a63:	or     %r10d,%esi
 29f6a66:	test   %sil,%sil
 29f6a69:	je     29f6a77 <wasm[0]::function[1015]::helper::object_read+0x15af7>
 29f6a6f:	mov    %r9,%rsi
 29f6a72:	jmp    29f6cfc <wasm[0]::function[1015]::helper::object_read+0x15d7c>
 29f6a77:	mov    0xe0(%rsp),%ecx
 29f6a7e:	test   %ecx,%ecx
 29f6a80:	je     29fc6cf <wasm[0]::function[1015]::helper::object_read+0x1b74f>
 29f6a86:	test   %ecx,%ecx
 29f6a88:	je     29fc6d1 <wasm[0]::function[1015]::helper::object_read+0x1b751>
 29f6a8e:	mov    0x2e0(%rsp),%r12
 29f6a96:	mov    0x28(%r12),%rdx
 29f6a9b:	mov    0x20(%r12),%rsi
 29f6aa0:	mov    %ecx,%r9d
 29f6aa3:	lea    0x10(%rsi,%r9,1),%r8
 29f6aa8:	xor    %rdi,%rdi
 29f6aab:	cmp    %rdx,%r9
 29f6aae:	cmova  %rdi,%r8
 29f6ab2:	mov    (%r8),%r8d
 29f6ab5:	test   %r8d,%r8d
 29f6ab8:	je     29fc6d3 <wasm[0]::function[1015]::helper::object_read+0x1b753>
 29f6abe:	mov    %r8d,%r9d
 29f6ac1:	shl    $1,%r9
 29f6ac4:	shr    $0x20,%r9
 29f6ac8:	test   %r9,%r9
 29f6acb:	jne    29fc6d5 <wasm[0]::function[1015]::helper::object_read+0x1b755>
 29f6ad1:	add    %r8d,%r8d
 29f6ad4:	add    $0x14,%r8d
 29f6ad8:	jb     29fc6d7 <wasm[0]::function[1015]::helper::object_read+0x1b757>
 29f6ade:	add    %r8d,%ecx
 29f6ae1:	jb     29fc6d9 <wasm[0]::function[1015]::helper::object_read+0x1b759>
 29f6ae7:	mov    %ecx,%r9d
 29f6aea:	lea    (%rsi,%r9,1),%rcx
 29f6aee:	cmp    %rdx,%r9
 29f6af1:	cmova  %rdi,%rcx
 29f6af5:	sub    $0x14,%r8d
 29f6af9:	sub    %r8,%rcx
 29f6afc:	movzwl (%rcx),%ecx
 29f6aff:	cmp    $0x30,%ecx
 29f6b02:	je     29f6cd1 <wasm[0]::function[1015]::helper::object_read+0x15d51>
 29f6b08:	mov    0x58(%rsp),%edi
 29f6b0c:	mov    0x68(%rsp),%r8d
 29f6b11:	mov    0x80(%rsp),%ecx
 29f6b18:	mov    0xa0(%rsp),%esi
 29f6b1f:	mov    %rsi,%r15
 29f6b22:	mov    0x50(%rsp),%edx
 29f6b26:	xor    %r14d,%r14d
 29f6b29:	xor    %r13,%r13
 29f6b2c:	mov    %edi,0xb8(%rsp)
 29f6b33:	mov    %r8d,0xb0(%rsp)
 29f6b3b:	mov    %eax,0xa8(%rsp)
 29f6b42:	mov    %ecx,0xc8(%rsp)
 29f6b49:	mov    %r15,%rax
 29f6b4c:	mov    %eax,0x78(%rsp)
 29f6b50:	mov    %edx,0x88(%rsp)
 29f6b57:	mov    0x2e8(%rsp),%rax
 29f6b5f:	mov    (%rax),%rax
 29f6b62:	mov    0x228(%rsp),%rcx
 29f6b6a:	cmp    %rcx,%rax
 29f6b6d:	jae    29fb695 <wasm[0]::function[1015]::helper::object_read+0x1a715>
 29f6b73:	jmp    29f6b80 <wasm[0]::function[1015]::helper::object_read+0x15c00>
 29f6b78:	mov    %rcx,0x228(%rsp)
 29f6b80:	mov    0xe0(%rsp),%eax
 29f6b87:	xor    %r9d,%r9d
 29f6b8a:	test   %eax,%eax
 29f6b8c:	je     29fc6db <wasm[0]::function[1015]::helper::object_read+0x1b75b>
 29f6b92:	test   %eax,%eax
 29f6b94:	je     29fc6dd <wasm[0]::function[1015]::helper::object_read+0x1b75d>
 29f6b9a:	mov    0x2e0(%rsp),%r12
 29f6ba2:	mov    0x28(%r12),%r8
 29f6ba7:	mov    0x20(%r12),%r10
 29f6bac:	mov    %eax,%ecx
 29f6bae:	lea    0x10(%r10,%rcx,1),%rsi
 29f6bb3:	xor    %r11,%r11
 29f6bb6:	cmp    %r8,%rcx
 29f6bb9:	cmova  %r11,%rsi
 29f6bbd:	mov    (%rsi),%ecx
 29f6bbf:	cmp    %ecx,%r14d
 29f6bc2:	jae    29fc6df <wasm[0]::function[1015]::helper::object_read+0x1b75f>
 29f6bc8:	mov    %ecx,%edx
 29f6bca:	shl    $1,%rdx
 29f6bcd:	shr    $0x20,%rdx
 29f6bd1:	test   %rdx,%rdx
 29f6bd4:	jne    29fc6e1 <wasm[0]::function[1015]::helper::object_read+0x1b761>
 29f6bda:	lea    (%rcx,%rcx,1),%esi
 29f6bdd:	add    $0x14,%esi
 29f6be0:	jb     29fc6e3 <wasm[0]::function[1015]::helper::object_read+0x1b763>
 29f6be6:	add    %esi,%eax
 29f6be8:	jb     29fc6e5 <wasm[0]::function[1015]::helper::object_read+0x1b765>
 29f6bee:	mov    %eax,%ecx
 29f6bf0:	lea    (%r10,%rcx,1),%rax
 29f6bf4:	cmp    %r8,%rcx
 29f6bf7:	cmova  %r11,%rax
 29f6bfb:	lea    0x14(%r14,%r14,1),%ecx
 29f6c00:	sub    %ecx,%esi
 29f6c02:	sub    %rsi,%rax
 29f6c05:	movzwq (%rax),%rsi
 29f6c09:	mov    0xb8(%rsp),%edi
 29f6c10:	mov    0xb0(%rsp),%r8d
 29f6c18:	mov    0xa8(%rsp),%eax
 29f6c1f:	mov    0xc8(%rsp),%ecx
 29f6c26:	mov    0x78(%rsp),%r10d
 29f6c2b:	mov    %r10,%r15
 29f6c2e:	mov    0x88(%rsp),%edx
 29f6c35:	movzwl %si,%esi
 29f6c38:	mov    %rsi,%r10
 29f6c3b:	sub    $0x30,%r10d
 29f6c3f:	cmp    $0x9,%r10d
 29f6c43:	jbe    29f6c51 <wasm[0]::function[1015]::helper::object_read+0x15cd1>
 29f6c49:	mov    %r9,%rsi
 29f6c4c:	jmp    29f6cfc <wasm[0]::function[1015]::helper::object_read+0x15d7c>
 29f6c51:	mov    0xb8(%rsp),%edi
 29f6c58:	mov    0xb0(%rsp),%r8d
 29f6c60:	mov    0xa8(%rsp),%eax
 29f6c67:	mov    0xc8(%rsp),%ecx
 29f6c6e:	mov    0x78(%rsp),%edx
 29f6c72:	mov    %rdx,%r15
 29f6c75:	mov    0x88(%rsp),%edx
 29f6c7c:	add    $0x1,%r14d
 29f6c83:	imul   $0xa,%r13,%r9
 29f6c87:	mov    %rsi,%r10
 29f6c8a:	sub    $0x30,%r10d
 29f6c8e:	add    %r9,%r10
 29f6c91:	cmp    %ebx,%r14d
 29f6c94:	jae    29f6ca2 <wasm[0]::function[1015]::helper::object_read+0x15d22>
 29f6c9a:	mov    %r10,%r13
 29f6c9d:	jmp    29f6b2c <wasm[0]::function[1015]::helper::object_read+0x15bac>
 29f6ca2:	xor    %r9d,%r9d
 29f6ca5:	cmp    0x5c5c(%rip),%r10        # 29fc908 <wasm[0]::function[1015]::helper::object_read+0x1b988>
 29f6cac:	jb     29f6cba <wasm[0]::function[1015]::helper::object_read+0x15d3a>
 29f6cb2:	mov    %r9,%rsi
 29f6cb5:	jmp    29f6cfc <wasm[0]::function[1015]::helper::object_read+0x15d7c>
 29f6cba:	imul   $0xa,%r13d,%r9d
 29f6cbe:	sub    $0x30,%esi
 29f6cc1:	add    %r9d,%esi
 29f6cc4:	mov    0x278(%rsp),%r9
 29f6ccc:	jmp    29f6cfc <wasm[0]::function[1015]::helper::object_read+0x15d7c>
 29f6cd1:	mov    0x58(%rsp),%edi
 29f6cd5:	mov    0x68(%rsp),%r8d
 29f6cda:	mov    0x80(%rsp),%ecx
 29f6ce1:	mov    0xa0(%rsp),%edx
 29f6ce8:	mov    %rdx,%r15
 29f6ceb:	mov    0x50(%rsp),%edx
 29f6cef:	cmp    $0x1,%ebx
 29f6cf2:	sete   %sil
 29f6cf6:	movzbl %sil,%r9d
 29f6cfa:	xor    %esi,%esi
 29f6cfc:	mov    %edi,0x88(%rsp)
 29f6d03:	mov    %r8d,0x78(%rsp)
 29f6d08:	mov    %eax,0xc8(%rsp)
 29f6d0f:	mov    %ecx,0xa8(%rsp)
 29f6d16:	mov    %r15,%rax
 29f6d19:	mov    %eax,0xb0(%rsp)
 29f6d20:	mov    %edx,0xb8(%rsp)
 29f6d27:	test   %r9d,%r9d
 29f6d2a:	jne    29f75e5 <wasm[0]::function[1015]::helper::object_read+0x16665>
 29f6d30:	mov    $0x8c,%edx
 29f6d35:	mov    0x190(%rsp),%rsi
 29f6d3d:	mov    0x190(%rsp),%rdi
 29f6d45:	call   2f30600 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 29f6d4a:	test   %eax,%eax
 29f6d4c:	je     29fc6e7 <wasm[0]::function[1015]::helper::object_read+0x1b767>
 29f6d52:	mov    0x1b8(%rsp),%rcx
 29f6d5a:	cmp    $0x4,%ecx
 29f6d5d:	je     29f6d96 <wasm[0]::function[1015]::helper::object_read+0x15e16>
 29f6d63:	mov    0x88(%rsp),%ecx
 29f6d6a:	mov    0xc8(%rsp),%eax
 29f6d71:	mov    %rax,%r8
 29f6d74:	mov    0xa8(%rsp),%edx
 29f6d7b:	mov    0xb0(%rsp),%esi
 29f6d82:	mov    0xb8(%rsp),%edi
 29f6d89:	xor    %eax,%eax
 29f6d8b:	mov    %rax,%r14
 29f6d8e:	mov    %r8,%rax
 29f6d91:	jmp    29f73bb <wasm[0]::function[1015]::helper::object_read+0x1643b>
 29f6d96:	mov    0x1b8(%rsp),%rcx
 29f6d9e:	cmp    $0x3,%ecx
 29f6da1:	je     29f7349 <wasm[0]::function[1015]::helper::object_read+0x163c9>
 29f6da7:	mov    0x1b8(%rsp),%rcx
 29f6daf:	cmp    $0x4,%ecx
 29f6db2:	je     29f720e <wasm[0]::function[1015]::helper::object_read+0x1628e>
 29f6db8:	mov    0x1b8(%rsp),%rcx
 29f6dc0:	cmp    $0xa,%ecx
 29f6dc3:	je     29f6e64 <wasm[0]::function[1015]::helper::object_read+0x15ee4>
 29f6dc9:	mov    0x1b8(%rsp),%rcx
 29f6dd1:	mov    0x1b8(%rsp),%rdx
 29f6dd9:	test   %edx,%ecx
 29f6ddb:	sete   %cl
 29f6dde:	cmp    $0x1,%edx
 29f6de1:	sete   %dl
 29f6de4:	or     %edx,%ecx
 29f6de6:	test   %cl,%cl
 29f6de8:	jne    29f6e34 <wasm[0]::function[1015]::helper::object_read+0x15eb4>
 29f6dee:	mov    0x1b8(%rsp),%rcx
 29f6df6:	cmp    $0x2,%ecx
 29f6df9:	je     29f6e13 <wasm[0]::function[1015]::helper::object_read+0x15e93>
 29f6dff:	mov    0x78(%rsp),%ecx
 29f6e03:	cmp    %eax,%ecx
 29f6e05:	sete   %al
 29f6e08:	movzbl %al,%eax
 29f6e0b:	mov    %rax,%r14
 29f6e0e:	jmp    29f6e3c <wasm[0]::function[1015]::helper::object_read+0x15ebc>
 29f6e13:	mov    0x1c0(%rsp),%rsi
 29f6e1b:	mov    0x1c0(%rsp),%r8
 29f6e23:	test   %rsi,%r8
 29f6e26:	sete   %al
 29f6e29:	movzbl %al,%eax
 29f6e2c:	mov    %rax,%r14
 29f6e2f:	jmp    29f6e3c <wasm[0]::function[1015]::helper::object_read+0x15ebc>
 29f6e34:	mov    0x278(%rsp),%r14
 29f6e3c:	mov    0x88(%rsp),%ecx
 29f6e43:	mov    0xc8(%rsp),%eax
 29f6e4a:	mov    0xa8(%rsp),%edx
 29f6e51:	mov    0xb0(%rsp),%esi
 29f6e58:	mov    0xb8(%rsp),%edi
 29f6e5f:	jmp    29f73bb <wasm[0]::function[1015]::helper::object_read+0x1643b>
 29f6e64:	mov    0x78(%rsp),%edx
 29f6e68:	xor    %ecx,%ecx
 29f6e6a:	test   %edx,%edx
 29f6e6c:	je     29f6ec1 <wasm[0]::function[1015]::helper::object_read+0x15f41>
 29f6e72:	xor    %ecx,%ecx
 29f6e74:	test   $0x1,%edx
 29f6e7a:	jne    29f6ec1 <wasm[0]::function[1015]::helper::object_read+0x15f41>
 29f6e80:	mov    0x2e0(%rsp),%r12
 29f6e88:	mov    0x28(%r12),%rsi
 29f6e8d:	mov    0x20(%r12),%rdi
 29f6e92:	mov    %edx,%r8d
 29f6e95:	lea    0x4(%rdi,%r8,1),%rdi
 29f6e9a:	xor    %r9,%r9
 29f6e9d:	cmp    %rsi,%r8
 29f6ea0:	cmova  %r9,%rdi
 29f6ea4:	mov    (%rdi),%edi
 29f6ea6:	mov    0x190(%rsp),%rsi
 29f6eae:	mov    0x28(%rsi),%r8
 29f6eb2:	cmp    0x23c(%r8),%edi
 29f6eb9:	sete   %r8b
 29f6ebd:	movzbl %r8b,%ecx
 29f6ec1:	test   %ecx,%ecx
 29f6ec3:	je     29fc6e9 <wasm[0]::function[1015]::helper::object_read+0x1b769>
 29f6ec9:	xor    %ecx,%ecx
 29f6ecb:	test   %eax,%eax
 29f6ecd:	je     29f6f1d <wasm[0]::function[1015]::helper::object_read+0x15f9d>
 29f6ed3:	xor    %ecx,%ecx
 29f6ed5:	test   $0x1,%eax
 29f6eda:	jne    29f6f1d <wasm[0]::function[1015]::helper::object_read+0x15f9d>
 29f6ee0:	mov    0x2e0(%rsp),%r12
 29f6ee8:	mov    0x28(%r12),%rcx
 29f6eed:	mov    0x20(%r12),%rdx
 29f6ef2:	mov    %eax,%esi
 29f6ef4:	lea    0x4(%rdx,%rsi,1),%rdx
 29f6ef9:	xor    %rdi,%rdi
 29f6efc:	cmp    %rcx,%rsi
 29f6eff:	cmova  %rdi,%rdx
 29f6f03:	mov    (%rdx),%ecx
 29f6f05:	mov    0x190(%rsp),%rsi
 29f6f0d:	mov    0x28(%rsi),%rdx
 29f6f11:	cmp    0x23c(%rdx),%ecx
 29f6f17:	sete   %cl
 29f6f1a:	movzbl %cl,%ecx
 29f6f1d:	test   %ecx,%ecx
 29f6f1f:	je     29fc6eb <wasm[0]::function[1015]::helper::object_read+0x1b76b>
 29f6f25:	mov    0x78(%rsp),%esi
 29f6f29:	test   %esi,%esi
 29f6f2b:	je     29fc6ed <wasm[0]::function[1015]::helper::object_read+0x1b76d>
 29f6f31:	test   %esi,%esi
 29f6f33:	je     29fc6ef <wasm[0]::function[1015]::helper::object_read+0x1b76f>
 29f6f39:	mov    0x2e0(%rsp),%r12
 29f6f41:	mov    0x28(%r12),%rcx
 29f6f46:	mov    0x20(%r12),%rdx
 29f6f4b:	mov    %esi,%r8d
 29f6f4e:	lea    (%rdx,%r8,1),%rdi
 29f6f52:	xor    %rsi,%rsi
 29f6f55:	cmp    %rcx,%r8
 29f6f58:	cmova  %rsi,%rdi
 29f6f5c:	mov    0x10(%rdi),%r8d
 29f6f60:	test   %eax,%eax
 29f6f62:	je     29fc6f1 <wasm[0]::function[1015]::helper::object_read+0x1b771>
 29f6f68:	mov    %eax,%r9d
 29f6f6b:	lea    (%rdx,%r9,1),%rax
 29f6f6f:	cmp    %rcx,%r9
 29f6f72:	cmova  %rsi,%rax
 29f6f76:	mov    0x10(%rax),%r9d
 29f6f7a:	mov    0x14(%rdi),%edi
 29f6f7d:	mov    %edi,0xe0(%rsp)
 29f6f84:	mov    0x14(%rax),%eax
 29f6f87:	mov    %eax,0xe8(%rsp)
 29f6f8e:	test   %edi,%edi
 29f6f90:	je     29fc6f3 <wasm[0]::function[1015]::helper::object_read+0x1b773>
 29f6f96:	test   %edi,%edi
 29f6f98:	je     29fc6f5 <wasm[0]::function[1015]::helper::object_read+0x1b775>
 29f6f9e:	mov    %edi,%r10d
 29f6fa1:	lea    0x10(%rdx,%r10,1),%rdi
 29f6fa6:	cmp    %rcx,%r10
 29f6fa9:	cmova  %rsi,%rdi
 29f6fad:	mov    (%rdi),%ebx
 29f6faf:	test   %eax,%eax
 29f6fb1:	je     29fc6f7 <wasm[0]::function[1015]::helper::object_read+0x1b777>
 29f6fb7:	test   %eax,%eax
 29f6fb9:	je     29fc6f9 <wasm[0]::function[1015]::helper::object_read+0x1b779>
 29f6fbf:	mov    %eax,%edi
 29f6fc1:	lea    0x10(%rdx,%rdi,1),%rax
 29f6fc6:	cmp    %rcx,%rdi
 29f6fc9:	cmova  %rsi,%rax
 29f6fcd:	mov    (%rax),%r10d
 29f6fd0:	mov    0x88(%rsp),%ecx
 29f6fd7:	mov    0xc8(%rsp),%eax
 29f6fde:	mov    0xa8(%rsp),%edx
 29f6fe5:	mov    0xb0(%rsp),%esi
 29f6fec:	mov    0xb8(%rsp),%edi
 29f6ff3:	cmp    %r9d,%r8d
 29f6ff6:	sete   %r8b
 29f6ffa:	cmp    %r10d,%ebx
 29f6ffd:	sete   %r9b
 29f7001:	mov    %r8,%r10
 29f7004:	and    %r9d,%r10d
 29f7007:	movzbl %r10b,%r10d
 29f700b:	mov    %r10,%r14
 29f700e:	test   %r8b,%r9b
 29f7011:	je     29f73bb <wasm[0]::function[1015]::helper::object_read+0x1643b>
 29f7017:	mov    0x88(%rsp),%esi
 29f701e:	mov    0xc8(%rsp),%edi
 29f7025:	mov    0xa8(%rsp),%r8d
 29f702d:	mov    0xb0(%rsp),%r9d
 29f7035:	mov    0xb8(%rsp),%r11d
 29f703d:	xor    %r12d,%r12d
 29f7040:	mov    %esi,0x90(%rsp)
 29f7047:	mov    %edi,0x98(%rsp)
 29f704e:	mov    %r8d,0xc0(%rsp)
 29f7056:	mov    %r9d,0xd0(%rsp)
 29f705e:	mov    %r11d,0xd8(%rsp)
 29f7066:	mov    0x2e8(%rsp),%r13
 29f706e:	mov    0x0(%r13),%rcx
 29f7072:	mov    0x228(%rsp),%rax
 29f707a:	cmp    %rax,%rcx
 29f707d:	jae    29fb6c5 <wasm[0]::function[1015]::helper::object_read+0x1a745>
 29f7083:	jmp    29f7090 <wasm[0]::function[1015]::helper::object_read+0x16110>
 29f7088:	mov    %rdx,0x228(%rsp)
 29f7090:	cmp    %ebx,%r12d
 29f7093:	jae    29f71e6 <wasm[0]::function[1015]::helper::object_read+0x16266>
 29f7099:	mov    0xe0(%rsp),%ecx
 29f70a0:	test   %ecx,%ecx
 29f70a2:	je     29fc6fb <wasm[0]::function[1015]::helper::object_read+0x1b77b>
 29f70a8:	test   %ecx,%ecx
 29f70aa:	je     29fc6fd <wasm[0]::function[1015]::helper::object_read+0x1b77d>
 29f70b0:	mov    0x2e0(%rsp),%rax
 29f70b8:	mov    0x28(%rax),%rsi
 29f70bc:	mov    0x20(%rax),%rdi
 29f70c0:	mov    %ecx,%r9d
 29f70c3:	lea    0x10(%rdi,%r9,1),%rdx
 29f70c8:	xor    %r8,%r8
 29f70cb:	cmp    %rsi,%r9
 29f70ce:	cmova  %r8,%rdx
 29f70d2:	mov    (%rdx),%r9d
 29f70d5:	cmp    %r9d,%r12d
 29f70d8:	jae    29fc6ff <wasm[0]::function[1015]::helper::object_read+0x1b77f>
 29f70de:	mov    %r9d,%r10d
 29f70e1:	shl    $0x3,%r10
 29f70e5:	shr    $0x20,%r10
 29f70e9:	test   %r10,%r10
 29f70ec:	jne    29fc701 <wasm[0]::function[1015]::helper::object_read+0x1b781>
 29f70f2:	shl    $0x3,%r9d
 29f70f6:	add    $0x18,%r9d
 29f70fa:	jb     29fc703 <wasm[0]::function[1015]::helper::object_read+0x1b783>
 29f7100:	add    %r9d,%ecx
 29f7103:	jb     29fc705 <wasm[0]::function[1015]::helper::object_read+0x1b785>
 29f7109:	mov    %ecx,%r11d
 29f710c:	lea    (%rdi,%r11,1),%r10
 29f7110:	cmp    %rsi,%r11
 29f7113:	cmova  %r8,%r10
 29f7117:	mov    %r12,%rax
 29f711a:	shl    $0x3,%eax
 29f711d:	lea    0x18(%rax),%edx
 29f7120:	sub    %edx,%r9d
 29f7123:	sub    %r9,%r10
 29f7126:	mov    (%r10),%rcx
 29f7129:	mov    0xe8(%rsp),%r9d
 29f7131:	test   %r9d,%r9d
 29f7134:	je     29fc707 <wasm[0]::function[1015]::helper::object_read+0x1b787>
 29f713a:	test   %r9d,%r9d
 29f713d:	je     29fc709 <wasm[0]::function[1015]::helper::object_read+0x1b789>
 29f7143:	mov    %r9d,%eax
 29f7146:	lea    0x10(%rdi,%rax,1),%r10
 29f714b:	cmp    %rsi,%rax
 29f714e:	cmova  %r8,%r10
 29f7152:	mov    (%r10),%r10d
 29f7155:	cmp    %r10d,%r12d
 29f7158:	jae    29fc70b <wasm[0]::function[1015]::helper::object_read+0x1b78b>
 29f715e:	mov    %r10d,%r11d
 29f7161:	shl    $0x3,%r11
 29f7165:	shr    $0x20,%r11
 29f7169:	test   %r11,%r11
 29f716c:	jne    29fc70d <wasm[0]::function[1015]::helper::object_read+0x1b78d>
 29f7172:	shl    $0x3,%r10d
 29f7176:	add    $0x18,%r10d
 29f717a:	jb     29fc70f <wasm[0]::function[1015]::helper::object_read+0x1b78f>
 29f7180:	add    %r10d,%r9d
 29f7183:	jb     29fc711 <wasm[0]::function[1015]::helper::object_read+0x1b791>
 29f7189:	mov    %r9d,%eax
 29f718c:	add    %rax,%rdi
 29f718f:	cmp    %rsi,%rax
 29f7192:	cmova  %r8,%rdi
 29f7196:	sub    %edx,%r10d
 29f7199:	sub    %r10,%rdi
 29f719c:	mov    (%rdi),%rdx
 29f719f:	cmp    %rdx,%rcx
 29f71a2:	sete   %al
 29f71a5:	movzbl %al,%eax
 29f71a8:	mov    %rax,%r14
 29f71ab:	cmp    %rdx,%rcx
 29f71ae:	jne    29f71e6 <wasm[0]::function[1015]::helper::object_read+0x16266>
 29f71b4:	mov    0x90(%rsp),%esi
 29f71bb:	mov    0x98(%rsp),%edi
 29f71c2:	mov    0xc0(%rsp),%r8d
 29f71ca:	mov    0xd0(%rsp),%r9d
 29f71d2:	mov    0xd8(%rsp),%r11d
 29f71da:	add    $0x1,%r12d
 29f71e1:	jmp    29f7040 <wasm[0]::function[1015]::helper::object_read+0x160c0>
 29f71e6:	mov    0x90(%rsp),%ecx
 29f71ed:	mov    0x98(%rsp),%eax
 29f71f4:	mov    0xc0(%rsp),%edx
 29f71fb:	mov    0xd0(%rsp),%esi
 29f7202:	mov    0xd8(%rsp),%edi
 29f7209:	jmp    29f73bb <wasm[0]::function[1015]::helper::object_read+0x1643b>
 29f720e:	mov    0x78(%rsp),%ecx
 29f7212:	cmp    %eax,%ecx
 29f7214:	je     29f7319 <wasm[0]::function[1015]::helper::object_read+0x16399>
 29f721a:	xor    %edx,%edx
 29f721c:	test   %ecx,%ecx
 29f721e:	je     29f726f <wasm[0]::function[1015]::helper::object_read+0x162ef>
 29f7224:	xor    %edx,%edx
 29f7226:	test   $0x1,%ecx
 29f722c:	jne    29f726f <wasm[0]::function[1015]::helper::object_read+0x162ef>
 29f7232:	mov    0x2e0(%rsp),%r12
 29f723a:	mov    0x28(%r12),%rdx
 29f723f:	mov    0x20(%r12),%rdi
 29f7244:	mov    %ecx,%esi
 29f7246:	lea    0x4(%rdi,%rsi,1),%rcx
 29f724b:	xor    %rdi,%rdi
 29f724e:	cmp    %rdx,%rsi
 29f7251:	cmova  %rdi,%rcx
 29f7255:	mov    (%rcx),%ecx
 29f7257:	mov    0x190(%rsp),%rsi
 29f725f:	mov    0x28(%rsi),%rdx
 29f7263:	cmp    0x234(%rdx),%ecx
 29f7269:	sete   %cl
 29f726c:	movzbl %cl,%edx
 29f726f:	test   %edx,%edx
 29f7271:	je     29fc713 <wasm[0]::function[1015]::helper::object_read+0x1b793>
 29f7277:	xor    %r10d,%r10d
 29f727a:	test   %eax,%eax
 29f727c:	jne    29f728a <wasm[0]::function[1015]::helper::object_read+0x1630a>
 29f7282:	mov    %rax,%rdi
 29f7285:	jmp    29f72e1 <wasm[0]::function[1015]::helper::object_read+0x16361>
 29f728a:	xor    %r10d,%r10d
 29f728d:	test   $0x1,%eax
 29f7292:	je     29f72a0 <wasm[0]::function[1015]::helper::object_read+0x16320>
 29f7298:	mov    %rax,%rdi
 29f729b:	jmp    29f72e1 <wasm[0]::function[1015]::helper::object_read+0x16361>
 29f72a0:	mov    0x2e0(%rsp),%r12
 29f72a8:	mov    0x28(%r12),%rcx
 29f72ad:	mov    0x20(%r12),%rsi
 29f72b2:	mov    %eax,%edx
 29f72b4:	mov    %rax,%rdi
 29f72b7:	lea    0x4(%rsi,%rdx,1),%rax
 29f72bc:	xor    %rsi,%rsi
 29f72bf:	cmp    %rcx,%rdx
 29f72c2:	cmova  %rsi,%rax
 29f72c6:	mov    (%rax),%eax
 29f72c8:	mov    0x190(%rsp),%rsi
 29f72d0:	mov    0x28(%rsi),%rcx
 29f72d4:	cmp    0x234(%rcx),%eax
 29f72da:	sete   %al
 29f72dd:	movzbl %al,%r10d
 29f72e1:	test   %r10d,%r10d
 29f72e4:	je     29fc715 <wasm[0]::function[1015]::helper::object_read+0x1b795>
 29f72ea:	mov    0x78(%rsp),%edx
 29f72ee:	xor    %r8d,%r8d
 29f72f1:	test   %edx,%edx
 29f72f3:	je     29fc717 <wasm[0]::function[1015]::helper::object_read+0x1b797>
 29f72f9:	mov    %rdi,%rcx
 29f72fc:	mov    0x190(%rsp),%rsi
 29f7304:	mov    0x190(%rsp),%rdi
 29f730c:	call   2ae5540 <wasm[0]::function[1057]::helper::string_equality>
 29f7311:	mov    %rax,%r14
 29f7314:	jmp    29f7321 <wasm[0]::function[1015]::helper::object_read+0x163a1>
 29f7319:	mov    0x278(%rsp),%r14
 29f7321:	mov    0x88(%rsp),%ecx
 29f7328:	mov    0xc8(%rsp),%eax
 29f732f:	mov    0xa8(%rsp),%edx
 29f7336:	mov    0xb0(%rsp),%esi
 29f733d:	mov    0xb8(%rsp),%edi
 29f7344:	jmp    29f73bb <wasm[0]::function[1015]::helper::object_read+0x1643b>
 29f7349:	mov    0x88(%rsp),%ecx
 29f7350:	mov    0xc8(%rsp),%eax
 29f7357:	mov    0xa8(%rsp),%edx
 29f735e:	mov    0xb0(%rsp),%esi
 29f7365:	mov    0xb8(%rsp),%edi
 29f736c:	xor    %r10,%r10
 29f736f:	mov    0x1c0(%rsp),%r8
 29f7377:	mov    0x1c0(%rsp),%r9
 29f737f:	test   %r9,%r8
 29f7382:	sete   %r8b
 29f7386:	movq   %r9,%xmm0
 29f738b:	ucomisd %xmm0,%xmm0
 29f738f:	setp   %r9b
 29f7393:	setne  %r11b
 29f7397:	or     %r11d,%r9d
 29f739a:	movq   %r10,%xmm1
 29f739f:	ucomisd %xmm1,%xmm1
 29f73a3:	setp   %r10b
 29f73a7:	setne  %r11b
 29f73ab:	or     %r11d,%r10d
 29f73ae:	and    %r10d,%r9d
 29f73b1:	or     %r9d,%r8d
 29f73b4:	movzbl %r8b,%r8d
 29f73b8:	mov    %r8,%r14
 29f73bb:	mov    %edx,0x90(%rsp)
 29f73c2:	mov    %esi,0x78(%rsp)
 29f73c6:	mov    %edi,0xc8(%rsp)
 29f73cd:	mov    %r14,%rdx
 29f73d0:	mov    %r14,%rsi
 29f73d3:	test   %esi,%edx
 29f73d5:	je     29f75cb <wasm[0]::function[1015]::helper::object_read+0x1664b>
 29f73db:	test   %ecx,%ecx
 29f73dd:	je     29fc719 <wasm[0]::function[1015]::helper::object_read+0x1b799>
 29f73e3:	test   %ecx,%ecx
 29f73e5:	je     29fc71b <wasm[0]::function[1015]::helper::object_read+0x1b79b>
 29f73eb:	mov    0x2e0(%rsp),%r12
 29f73f3:	mov    0x28(%r12),%rax
 29f73f8:	mov    0x20(%r12),%rdx
 29f73fd:	mov    %ecx,%ecx
 29f73ff:	lea    (%rdx,%rcx,1),%r11
 29f7403:	xor    %rdx,%rdx
 29f7406:	cmp    %rax,%rcx
 29f7409:	cmova  %rdx,%r11
 29f740d:	mov    0x18(%r11),%r15
 29f7411:	movl   $0x0,0x98(%rsp)
 29f741c:	mov    0x20(%r11),%ebx
 29f7420:	mov    0x270(%rsp),%rcx
 29f7428:	mov    (%rcx),%eax
 29f742a:	mov    %eax,%edx
 29f742c:	lea    0x20(%rdx),%rcx
 29f7430:	mov    0x270(%rsp),%rsi
 29f7438:	mov    0x4(%rsi),%esi
 29f743b:	cmp    %rsi,%rcx
 29f743e:	ja     29fb6f4 <wasm[0]::function[1015]::helper::object_read+0x1a774>
 29f7444:	lea    0x20(%rax),%ecx
 29f7447:	mov    0x270(%rsp),%rsi
 29f744f:	mov    %ecx,(%rsi)
 29f7451:	mov    0x2e0(%rsp),%r12
 29f7459:	mov    0x20(%r12),%rsi
 29f745e:	lea    (%rsi,%rdx,1),%rcx
 29f7462:	movl   $0xb0000042,(%rsi,%rdx,1)
 29f7469:	mov    0x190(%rsp),%rdi
 29f7471:	mov    0x28(%rdi),%rdi
 29f7475:	mov    0x120(%rdi),%edi
 29f747b:	mov    %edi,0x4(%rsi,%rdx,1)
 29f747f:	mov    0x268(%rsp),%rdi
 29f7487:	mov    %edi,0x8(%rsi,%rdx,1)
 29f748b:	mov    %eax,0xc0(%rsp)
 29f7492:	cmp    $0x0,%r15
 29f7496:	jl     29f74a6 <wasm[0]::function[1015]::helper::object_read+0x16526>
 29f749c:	cvtsi2sd %r15,%xmm0
 29f74a1:	jmp    29f74c0 <wasm[0]::function[1015]::helper::object_read+0x16540>
 29f74a6:	mov    %r15,%rsi
 29f74a9:	shr    $0x1,%rsi
 29f74ad:	mov    %r15,%rdx
 29f74b0:	and    $0x1,%rdx
 29f74b4:	or     %rsi,%rdx
 29f74b7:	cvtsi2sd %rdx,%xmm0
 29f74bc:	addsd  %xmm0,%xmm0
 29f74c0:	movq   %xmm0,%rdx
 29f74c5:	mov    %rdx,0x10(%rcx)
 29f74c9:	movl   $0x3,0x18(%rcx)
 29f74d0:	mov    0x98(%rsp),%edx
 29f74d7:	mov    %edx,0x1c(%rcx)
 29f74da:	mov    0x190(%rsp),%rsi
 29f74e2:	mov    0xa20(%rsi),%ecx
 29f74e8:	mov    %ecx,0x98(%rsp)
 29f74ef:	test   %eax,%eax
 29f74f1:	je     29fc71d <wasm[0]::function[1015]::helper::object_read+0x1b79d>
 29f74f7:	test   %ecx,%ecx
 29f74f9:	je     29fc71f <wasm[0]::function[1015]::helper::object_read+0x1b79f>
 29f74ff:	mov    0x270(%rsp),%rcx
 29f7507:	mov    (%rcx),%eax
 29f7509:	mov    %eax,%ecx
 29f750b:	lea    0x20(%rcx),%rdx
 29f750f:	mov    0x270(%rsp),%rsi
 29f7517:	mov    0x4(%rsi),%esi
 29f751a:	cmp    %rsi,%rdx
 29f751d:	ja     29fb737 <wasm[0]::function[1015]::helper::object_read+0x1a7b7>
 29f7523:	lea    0x20(%rax),%edx
 29f7526:	mov    0x270(%rsp),%rsi
 29f752e:	mov    %edx,(%rsi)
 29f7530:	mov    0x2e0(%rsp),%r12
 29f7538:	mov    0x20(%r12),%rdx
 29f753d:	lea    (%rdx,%rcx,1),%r11
 29f7541:	movl   $0xb0000072,(%rdx,%rcx,1)
 29f7548:	mov    0x190(%rsp),%rsi
 29f7550:	mov    0x28(%rsi),%rsi
 29f7554:	mov    0x13c(%rsi),%esi
 29f755a:	mov    %esi,0x4(%rdx,%rcx,1)
 29f755e:	mov    0x268(%rsp),%rsi
 29f7566:	mov    %esi,0x8(%rdx,%rcx,1)
 29f756a:	movl   $0x4,0x10(%r11)
 29f7572:	mov    0xc0(%rsp),%ecx
 29f7579:	mov    %ecx,0x14(%r11)
 29f757d:	mov    0x98(%rsp),%ecx
 29f7584:	mov    %ecx,0x18(%r11)
 29f7588:	mov    %ecx,0x1c(%r11)
 29f758c:	test   %eax,%eax
 29f758e:	je     29fc721 <wasm[0]::function[1015]::helper::object_read+0x1b7a1>
 29f7594:	test   %eax,%eax
 29f7596:	je     29fc723 <wasm[0]::function[1015]::helper::object_read+0x1b7a3>
 29f759c:	mov    0x2e0(%rsp),%r12
 29f75a4:	mov    0x28(%r12),%rcx
 29f75a9:	test   %ebx,%ebx
 29f75ab:	setne  %dl
 29f75ae:	movzbl %dl,%edx
 29f75b1:	shl    $0x2,%edx
 29f75b4:	mov    %eax,%edi
 29f75b6:	mov    %rdi,%rsi
 29f75b9:	add    0x20(%r12),%rsi
 29f75be:	xor    %r8,%r8
 29f75c1:	cmp    %rcx,%rdi
 29f75c4:	cmova  %r8,%rsi
 29f75c8:	mov    %edx,0x10(%rsi)
 29f75cb:	mov    0x90(%rsp),%ecx
 29f75d2:	mov    0x78(%rsp),%edx
 29f75d6:	mov    %rdx,%r15
 29f75d9:	mov    0xc8(%rsp),%edx
 29f75e0:	jmp    29f88fd <wasm[0]::function[1015]::helper::object_read+0x1797d>
 29f75e5:	test   %edi,%edi
 29f75e7:	je     29fc725 <wasm[0]::function[1015]::helper::object_read+0x1b7a5>
 29f75ed:	test   %edi,%edi
 29f75ef:	je     29fc727 <wasm[0]::function[1015]::helper::object_read+0x1b7a7>
 29f75f5:	mov    0x2e0(%rsp),%r12
 29f75fd:	mov    0x28(%r12),%r8
 29f7602:	mov    0x20(%r12),%r9
 29f7607:	mov    %edi,%r10d
 29f760a:	lea    (%r9,%r10,1),%rax
 29f760e:	xor    %rdi,%rdi
 29f7611:	cmp    %r8,%r10
 29f7614:	cmova  %rdi,%rax
 29f7618:	mov    0x14(%rax),%eax
 29f761b:	mov    %eax,0x88(%rsp)
 29f7622:	test   %eax,%eax
 29f7624:	je     29fc729 <wasm[0]::function[1015]::helper::object_read+0x1b7a9>
 29f762a:	test   %eax,%eax
 29f762c:	je     29fc72b <wasm[0]::function[1015]::helper::object_read+0x1b7ab>
 29f7632:	mov    %eax,%r10d
 29f7635:	add    %r10,%r9
 29f7638:	cmp    %r8,%r10
 29f763b:	cmova  %rdi,%r9
 29f763f:	mov    0x24(%r9),%r8d
 29f7643:	cmp    $0x2,%r8d
 29f7647:	sete   %dil
 29f764b:	cmp    $0x3,%r8d
 29f764f:	sete   %r8b
 29f7653:	or     %r8d,%edi
 29f7656:	test   %dil,%dil
 29f7659:	jne    29f766c <wasm[0]::function[1015]::helper::object_read+0x166ec>
 29f765f:	mov    %rsi,0x198(%rsp)
 29f7667:	jmp    29f85cb <wasm[0]::function[1015]::helper::object_read+0x1764b>
 29f766c:	mov    0x88(%rsp),%edi
 29f7673:	test   %edi,%edi
 29f7675:	je     29fc72d <wasm[0]::function[1015]::helper::object_read+0x1b7ad>
 29f767b:	test   %edi,%edi
 29f767d:	je     29fc72f <wasm[0]::function[1015]::helper::object_read+0x1b7af>
 29f7683:	mov    0x2e0(%rsp),%r12
 29f768b:	mov    0x28(%r12),%r9
 29f7690:	mov    %edi,%r10d
 29f7693:	mov    %r10,%rdi
 29f7696:	add    0x20(%r12),%rdi
 29f769b:	xor    %r11,%r11
 29f769e:	cmp    %r9,%r10
 29f76a1:	cmova  %r11,%rdi
 29f76a5:	mov    0x24(%rdi),%r10d
 29f76a9:	cmp    $0x3,%r10d
 29f76ad:	je     29f77d6 <wasm[0]::function[1015]::helper::object_read+0x16856>
 29f76b3:	mov    0x88(%rsp),%eax
 29f76ba:	xor    %edi,%edi
 29f76bc:	test   %eax,%eax
 29f76be:	je     29fc731 <wasm[0]::function[1015]::helper::object_read+0x1b7b1>
 29f76c4:	test   %eax,%eax
 29f76c6:	je     29fc733 <wasm[0]::function[1015]::helper::object_read+0x1b7b3>
 29f76cc:	mov    0x2e0(%rsp),%r12
 29f76d4:	mov    0x28(%r12),%rcx
 29f76d9:	mov    0x20(%r12),%rdx
 29f76de:	mov    %eax,%r9d
 29f76e1:	lea    (%rdx,%r9,1),%rax
 29f76e5:	xor    %r8,%r8
 29f76e8:	cmp    %rcx,%r9
 29f76eb:	cmova  %r8,%rax
 29f76ef:	mov    0x28(%rax),%r9d
 29f76f3:	mov    0x2c(%rax),%eax
 29f76f6:	test   %r9d,%r9d
 29f76f9:	je     29fc735 <wasm[0]::function[1015]::helper::object_read+0x1b7b5>
 29f76ff:	test   %r9d,%r9d
 29f7702:	je     29fc737 <wasm[0]::function[1015]::helper::object_read+0x1b7b7>
 29f7708:	mov    %r9d,%r9d
 29f770b:	lea    0x10(%rdx,%r9,1),%rdx
 29f7710:	cmp    %rcx,%r9
 29f7713:	cmova  %r8,%rdx
 29f7717:	mov    %esi,%ecx
 29f7719:	mov    (%rdx),%edx
 29f771b:	cmp    %rdx,%rcx
 29f771e:	jae    29f77c9 <wasm[0]::function[1015]::helper::object_read+0x16849>
 29f7724:	xor    %edi,%edi
 29f7726:	test   %eax,%eax
 29f7728:	je     29fc739 <wasm[0]::function[1015]::helper::object_read+0x1b7b9>
 29f772e:	test   %eax,%eax
 29f7730:	je     29fc73b <wasm[0]::function[1015]::helper::object_read+0x1b7bb>
 29f7736:	mov    0x2e0(%rsp),%r12
 29f773e:	mov    0x28(%r12),%rcx
 29f7743:	mov    0x20(%r12),%rdx
 29f7748:	mov    %eax,%r10d
 29f774b:	lea    0x10(%rdx,%r10,1),%r9
 29f7750:	xor    %r8,%r8
 29f7753:	cmp    %rcx,%r10
 29f7756:	cmova  %r8,%r9
 29f775a:	mov    (%r9),%r9d
 29f775d:	mov    %rsi,%r10
 29f7760:	shr    $0x6,%r10d
 29f7764:	cmp    %r9d,%r10d
 29f7767:	jae    29fc73d <wasm[0]::function[1015]::helper::object_read+0x1b7bd>
 29f776d:	mov    %r9d,%r11d
 29f7770:	shl    $0x3,%r11
 29f7774:	shr    $0x20,%r11
 29f7778:	test   %r11,%r11
 29f777b:	jne    29fc73f <wasm[0]::function[1015]::helper::object_read+0x1b7bf>
 29f7781:	shl    $0x3,%r9d
 29f7785:	add    $0x18,%r9d
 29f7789:	jb     29fc741 <wasm[0]::function[1015]::helper::object_read+0x1b7c1>
 29f778f:	add    %r9d,%eax
 29f7792:	jb     29fc743 <wasm[0]::function[1015]::helper::object_read+0x1b7c3>
 29f7798:	mov    %eax,%r11d
 29f779b:	lea    (%rdx,%r11,1),%rax
 29f779f:	cmp    %rcx,%r11
 29f77a2:	cmova  %r8,%rax
 29f77a6:	shl    $0x3,%r10d
 29f77aa:	lea    0x18(%r10),%ecx
 29f77ae:	sub    %ecx,%r9d
 29f77b1:	sub    %r9,%rax
 29f77b4:	mov    (%rax),%rax
 29f77b7:	bt     %rsi,%rax
 29f77bb:	jae    29f77c9 <wasm[0]::function[1015]::helper::object_read+0x16849>
 29f77c1:	mov    0x278(%rsp),%rdi
 29f77c9:	mov    %rsi,0x198(%rsp)
 29f77d1:	jmp    29f78dc <wasm[0]::function[1015]::helper::object_read+0x1695c>
 29f77d6:	mov    0x88(%rsp),%eax
 29f77dd:	xor    %edi,%edi
 29f77df:	test   %eax,%eax
 29f77e1:	je     29fc745 <wasm[0]::function[1015]::helper::object_read+0x1b7c5>
 29f77e7:	test   %eax,%eax
 29f77e9:	je     29fc747 <wasm[0]::function[1015]::helper::object_read+0x1b7c7>
 29f77ef:	mov    0x2e0(%rsp),%r12
 29f77f7:	mov    0x28(%r12),%rcx
 29f77fc:	mov    0x20(%r12),%rdx
 29f7801:	mov    %eax,%r9d
 29f7804:	lea    (%rdx,%r9,1),%rax
 29f7808:	xor    %r8,%r8
 29f780b:	cmp    %rcx,%r9
 29f780e:	cmova  %r8,%rax
 29f7812:	mov    0x30(%rax),%eax
 29f7815:	test   %eax,%eax
 29f7817:	je     29fc749 <wasm[0]::function[1015]::helper::object_read+0x1b7c9>
 29f781d:	test   %eax,%eax
 29f781f:	je     29fc74b <wasm[0]::function[1015]::helper::object_read+0x1b7cb>
 29f7825:	mov    %eax,%r9d
 29f7828:	lea    0x10(%rdx,%r9,1),%rdx
 29f782d:	cmp    %rcx,%r9
 29f7830:	cmova  %r8,%rdx
 29f7834:	mov    %esi,%ecx
 29f7836:	mov    (%rdx),%edx
 29f7838:	cmp    %rdx,%rcx
 29f783b:	jb     29f784e <wasm[0]::function[1015]::helper::object_read+0x168ce>
 29f7841:	mov    %rsi,0x198(%rsp)
 29f7849:	jmp    29f78dc <wasm[0]::function[1015]::helper::object_read+0x1695c>
 29f784e:	mov    0x2e0(%rsp),%r12
 29f7856:	mov    0x28(%r12),%rcx
 29f785b:	mov    0x20(%r12),%r8
 29f7860:	lea    0x10(%r8,%r9,1),%rdi
 29f7865:	xor    %rdx,%rdx
 29f7868:	cmp    %rcx,%r9
 29f786b:	cmova  %rdx,%rdi
 29f786f:	mov    (%rdi),%edi
 29f7871:	cmp    %edi,%esi
 29f7873:	jae    29fc74d <wasm[0]::function[1015]::helper::object_read+0x1b7cd>
 29f7879:	mov    %edi,%r9d
 29f787c:	shl    $0x2,%r9
 29f7880:	shr    $0x20,%r9
 29f7884:	test   %r9,%r9
 29f7887:	jne    29fc74f <wasm[0]::function[1015]::helper::object_read+0x1b7cf>
 29f788d:	shl    $0x2,%edi
 29f7890:	add    $0x14,%edi
 29f7893:	jb     29fc751 <wasm[0]::function[1015]::helper::object_read+0x1b7d1>
 29f7899:	add    %edi,%eax
 29f789b:	jb     29fc753 <wasm[0]::function[1015]::helper::object_read+0x1b7d3>
 29f78a1:	mov    %eax,%r9d
 29f78a4:	lea    (%r8,%r9,1),%rax
 29f78a8:	cmp    %rcx,%r9
 29f78ab:	cmova  %rdx,%rax
 29f78af:	mov    %rsi,%rcx
 29f78b2:	shl    $0x2,%ecx
 29f78b5:	mov    %rsi,0x198(%rsp)
 29f78bd:	add    $0x14,%ecx
 29f78c3:	sub    %ecx,%edi
 29f78c5:	sub    %rdi,%rax
 29f78c8:	mov    (%rax),%ecx
 29f78ca:	xor    %edi,%edi
 29f78cc:	test   %ecx,%ecx
 29f78ce:	je     29f78dc <wasm[0]::function[1015]::helper::object_read+0x1695c>
 29f78d4:	mov    0x278(%rsp),%rdi
 29f78dc:	mov    0x88(%rsp),%eax
 29f78e3:	mov    0xa8(%rsp),%ecx
 29f78ea:	mov    0xb0(%rsp),%edx
 29f78f1:	mov    %rdx,%r15
 29f78f4:	mov    0xb8(%rsp),%edx
 29f78fb:	test   %edi,%edi
 29f78fd:	je     29f85cb <wasm[0]::function[1015]::helper::object_read+0x1764b>
 29f7903:	mov    0x88(%rsp),%r10d
 29f790b:	test   %r10d,%r10d
 29f790e:	je     29fc755 <wasm[0]::function[1015]::helper::object_read+0x1b7d5>
 29f7914:	test   %r10d,%r10d
 29f7917:	je     29fc757 <wasm[0]::function[1015]::helper::object_read+0x1b7d7>
 29f791d:	mov    0x2e0(%rsp),%r12
 29f7925:	mov    0x28(%r12),%rax
 29f792a:	mov    %r10d,%ecx
 29f792d:	mov    %rcx,%r11
 29f7930:	add    0x20(%r12),%r11
 29f7935:	xor    %rdx,%rdx
 29f7938:	cmp    %rax,%rcx
 29f793b:	cmova  %rdx,%r11
 29f793f:	mov    0x24(%r11),%eax
 29f7943:	cmp    $0x3,%eax
 29f7946:	je     29f8067 <wasm[0]::function[1015]::helper::object_read+0x170e7>
 29f794c:	mov    0x88(%rsp),%eax
 29f7953:	test   %eax,%eax
 29f7955:	je     29fc759 <wasm[0]::function[1015]::helper::object_read+0x1b7d9>
 29f795b:	test   %eax,%eax
 29f795d:	je     29fc75b <wasm[0]::function[1015]::helper::object_read+0x1b7db>
 29f7963:	mov    0x2e0(%rsp),%r12
 29f796b:	mov    0x28(%r12),%rcx
 29f7970:	mov    %eax,%esi
 29f7972:	mov    %rsi,%rdx
 29f7975:	add    0x20(%r12),%rdx
 29f797a:	xor    %rdi,%rdi
 29f797d:	cmp    %rcx,%rsi
 29f7980:	cmova  %rdi,%rdx
 29f7984:	mov    0x24(%rdx),%esi
 29f7987:	mov    0xa8(%rsp),%ecx
 29f798e:	mov    0xb0(%rsp),%edi
 29f7995:	mov    %rdi,%r15
 29f7998:	mov    0xb8(%rsp),%edx
 29f799f:	cmp    $0x2,%esi
 29f79a2:	jne    29f85cb <wasm[0]::function[1015]::helper::object_read+0x1764b>
 29f79a8:	mov    0x88(%rsp),%edx
 29f79af:	test   %edx,%edx
 29f79b1:	je     29fc75d <wasm[0]::function[1015]::helper::object_read+0x1b7dd>
 29f79b7:	test   %edx,%edx
 29f79b9:	je     29fc75f <wasm[0]::function[1015]::helper::object_read+0x1b7df>
 29f79bf:	mov    0x2e0(%rsp),%r12
 29f79c7:	mov    0x28(%r12),%rax
 29f79cc:	mov    0x20(%r12),%rcx
 29f79d1:	mov    %edx,%esi
 29f79d3:	lea    (%rcx,%rsi,1),%rdi
 29f79d7:	xor    %rdx,%rdx
 29f79da:	cmp    %rax,%rsi
 29f79dd:	cmova  %rdx,%rdi
 29f79e1:	mov    0x28(%rdi),%esi
 29f79e4:	mov    %esi,0x90(%rsp)
 29f79eb:	mov    0x2c(%rdi),%edi
 29f79ee:	mov    %edi,0x78(%rsp)
 29f79f2:	test   %esi,%esi
 29f79f4:	je     29fc761 <wasm[0]::function[1015]::helper::object_read+0x1b7e1>
 29f79fa:	test   %esi,%esi
 29f79fc:	je     29fc763 <wasm[0]::function[1015]::helper::object_read+0x1b7e3>
 29f7a02:	mov    %esi,%esi
 29f7a04:	lea    0x10(%rcx,%rsi,1),%rcx
 29f7a09:	cmp    %rax,%rsi
 29f7a0c:	cmova  %rdx,%rcx
 29f7a10:	mov    (%rcx),%eax
 29f7a12:	mov    %eax,%r12d
 29f7a15:	mov    %r12,%rbx
 29f7a18:	shl    $0x2,%rbx
 29f7a1c:	mov    %rbx,%rcx
 29f7a1f:	shr    $0x20,%rcx
 29f7a23:	test   %rcx,%rcx
 29f7a26:	jne    29fc765 <wasm[0]::function[1015]::helper::object_read+0x1b7e5>
 29f7a2c:	mov    %rax,%rcx
 29f7a2f:	shl    $0x2,%ecx
 29f7a32:	mov    %rax,0x1e8(%rsp)
 29f7a3a:	add    $0x14,%ecx
 29f7a3d:	jb     29fc767 <wasm[0]::function[1015]::helper::object_read+0x1b7e7>
 29f7a43:	mov    0x270(%rsp),%rax
 29f7a4b:	mov    (%rax),%eax
 29f7a4d:	mov    %eax,%esi
 29f7a4f:	mov    %ecx,%edx
 29f7a51:	add    $0xf,%rdx
 29f7a58:	mov    %rdx,%rdi
 29f7a5b:	and    $0xfffffffffffffff0,%rdi
 29f7a5f:	add    %rsi,%rdi
 29f7a62:	mov    0x270(%rsp),%r8
 29f7a6a:	mov    0x4(%r8),%r8d
 29f7a6e:	cmp    %r8,%rdi
 29f7a71:	ja     29fb77b <wasm[0]::function[1015]::helper::object_read+0x1a7fb>
 29f7a77:	add    $0xf,%ecx
 29f7a7d:	and    $0xfffffff0,%ecx
 29f7a80:	add    %eax,%ecx
 29f7a82:	mov    0x270(%rsp),%rdi
 29f7a8a:	mov    %ecx,(%rdi)
 29f7a8c:	mov    0x2e0(%rsp),%rcx
 29f7a94:	mov    0x20(%rcx),%rdi
 29f7a98:	lea    (%rdi,%rsi,1),%rcx
 29f7a9c:	movl   $0xa800000e,(%rdi,%rsi,1)
 29f7aa3:	mov    0x190(%rsp),%r8
 29f7aab:	mov    0x28(%r8),%r8
 29f7aaf:	mov    0x194(%r8),%r8d
 29f7ab6:	mov    %r8d,0x4(%rdi,%rsi,1)
 29f7abb:	and    $0xfffffffffffffff0,%rdx
 29f7abf:	mov    %edx,0x8(%rdi,%rsi,1)
 29f7ac3:	mov    %eax,0xc8(%rsp)
 29f7aca:	mov    0x1e8(%rsp),%r14
 29f7ad2:	mov    %r14d,0x10(%rcx)
 29f7ad6:	test   %eax,%eax
 29f7ad8:	je     29fc769 <wasm[0]::function[1015]::helper::object_read+0x1b7e9>
 29f7ade:	mov    0x2e0(%rsp),%rcx
 29f7ae6:	mov    0x28(%rcx),%rcx
 29f7aea:	mov    0x2e0(%rsp),%rdx
 29f7af2:	mov    0x20(%rdx),%rdx
 29f7af6:	mov    %eax,%esi
 29f7af8:	lea    (%rdx,%rsi,1),%rax
 29f7afc:	lea    0x10(%rdx,%rsi,1),%rdi
 29f7b01:	xor    %r8,%r8
 29f7b04:	cmp    %rcx,%rsi
 29f7b07:	cmova  %r8,%rdi
 29f7b0b:	mov    (%rdi),%edi
 29f7b0d:	cmp    %rdi,%r12
 29f7b10:	ja     29fc76b <wasm[0]::function[1015]::helper::object_read+0x1b7eb>
 29f7b16:	lea    0x14(%rdx,%rsi,1),%r13
 29f7b1b:	mov    %r13,%rsi
 29f7b1e:	add    %rbx,%rsi
 29f7b21:	jb     29fc76d <wasm[0]::function[1015]::helper::object_read+0x1b7ed>
 29f7b27:	add    %rdx,%rcx
 29f7b2a:	cmp    %rcx,%rsi
 29f7b2d:	ja     29fc76f <wasm[0]::function[1015]::helper::object_read+0x1b7ef>
 29f7b33:	mov    0x78(%rsp),%r9d
 29f7b38:	mov    0x90(%rsp),%r8d
 29f7b40:	mov    0x88(%rsp),%ecx
 29f7b47:	mov    0xa8(%rsp),%edx
 29f7b4e:	mov    0xb0(%rsp),%esi
 29f7b55:	mov    0xb8(%rsp),%edi
 29f7b5c:	lea    0x14(%rax,%r12,4),%rbx
 29f7b61:	test   %r12,%r12
 29f7b64:	je     29f7bfd <wasm[0]::function[1015]::helper::object_read+0x16c7d>
 29f7b6a:	mov    %r9d,0xd8(%rsp)
 29f7b72:	mov    %r8d,0xd0(%rsp)
 29f7b7a:	mov    %ecx,0xc0(%rsp)
 29f7b81:	mov    %edx,0x98(%rsp)
 29f7b88:	mov    %esi,0x90(%rsp)
 29f7b8f:	mov    %edi,0x78(%rsp)
 29f7b93:	mov    0x2e8(%rsp),%r8
 29f7b9b:	mov    (%r8),%rsi
 29f7b9e:	mov    0x228(%rsp),%rax
 29f7ba6:	cmp    %rax,%rsi
 29f7ba9:	jae    29fb7b8 <wasm[0]::function[1015]::helper::object_read+0x1a838>
 29f7baf:	jmp    29f7bbc <wasm[0]::function[1015]::helper::object_read+0x16c3c>
 29f7bb4:	mov    %r8,0x228(%rsp)
 29f7bbc:	movl   $0x0,0x0(%r13)
 29f7bc4:	mov    0xd8(%rsp),%r9d
 29f7bcc:	mov    0xd0(%rsp),%r8d
 29f7bd4:	mov    0xc0(%rsp),%ecx
 29f7bdb:	mov    0x98(%rsp),%edx
 29f7be2:	mov    0x90(%rsp),%esi
 29f7be9:	mov    0x78(%rsp),%edi
 29f7bed:	add    $0x4,%r13
 29f7bf4:	cmp    %rbx,%r13
 29f7bf7:	jne    29f7b6a <wasm[0]::function[1015]::helper::object_read+0x16bea>
 29f7bfd:	mov    %r9d,0xd0(%rsp)
 29f7c05:	mov    %r8d,0xd8(%rsp)
 29f7c0d:	xor    %r13d,%r13d
 29f7c10:	mov    $0xb0000042,%ebx
 29f7c15:	mov    0x190(%rsp),%rax
 29f7c1d:	mov    %rbx,0x1e0(%rsp)
 29f7c25:	mov    0x28(%rax),%rax
 29f7c29:	mov    0x120(%rax),%r15d
 29f7c30:	mov    $0x20,%ebx
 29f7c35:	mov    %rbx,0x1d8(%rsp)
 29f7c3d:	mov    $0x10,%ebx
 29f7c42:	mov    $0xb0000072,%r8d
 29f7c48:	mov    %r8,0x1d0(%rsp)
 29f7c50:	mov    0x13c(%rax),%r14d
 29f7c57:	mov    %ecx,0x78(%rsp)
 29f7c5b:	mov    %edx,0x90(%rsp)
 29f7c62:	mov    %esi,0x98(%rsp)
 29f7c69:	mov    %edi,0xc0(%rsp)
 29f7c70:	mov    0x2e8(%rsp),%rax
 29f7c78:	mov    (%rax),%rax
 29f7c7b:	mov    0x228(%rsp),%rcx
 29f7c83:	cmp    %rcx,%rax
 29f7c86:	jae    29fb7e8 <wasm[0]::function[1015]::helper::object_read+0x1a868>
 29f7c8c:	mov    0x1e8(%rsp),%rcx
 29f7c94:	jmp    29f7ca9 <wasm[0]::function[1015]::helper::object_read+0x16d29>
 29f7c99:	mov    %rcx,0x228(%rsp)
 29f7ca1:	mov    0x1e8(%rsp),%rcx
 29f7ca9:	cmp    %ecx,%r13d
 29f7cac:	jae    29f7fc3 <wasm[0]::function[1015]::helper::object_read+0x17043>
 29f7cb2:	mov    0xd0(%rsp),%eax
 29f7cb9:	test   %eax,%eax
 29f7cbb:	je     29fc771 <wasm[0]::function[1015]::helper::object_read+0x1b7f1>
 29f7cc1:	test   %eax,%eax
 29f7cc3:	je     29fc773 <wasm[0]::function[1015]::helper::object_read+0x1b7f3>
 29f7cc9:	mov    0x2e0(%rsp),%r12
 29f7cd1:	mov    0x28(%r12),%rcx
 29f7cd6:	mov    0x20(%r12),%rdx
 29f7cdb:	mov    %eax,%r8d
 29f7cde:	lea    0x10(%rdx,%r8,1),%rdi
 29f7ce3:	xor    %rsi,%rsi
 29f7ce6:	cmp    %rcx,%r8
 29f7ce9:	cmova  %rsi,%rdi
 29f7ced:	mov    (%rdi),%edi
 29f7cef:	mov    %r13,%r8
 29f7cf2:	shr    $0x6,%r8d
 29f7cf6:	cmp    %edi,%r8d
 29f7cf9:	jae    29fc775 <wasm[0]::function[1015]::helper::object_read+0x1b7f5>
 29f7cff:	mov    %edi,%r9d
 29f7d02:	shl    $0x3,%r9
 29f7d06:	shr    $0x20,%r9
 29f7d0a:	test   %r9,%r9
 29f7d0d:	jne    29fc777 <wasm[0]::function[1015]::helper::object_read+0x1b7f7>
 29f7d13:	shl    $0x3,%edi
 29f7d16:	add    $0x18,%edi
 29f7d19:	jb     29fc779 <wasm[0]::function[1015]::helper::object_read+0x1b7f9>
 29f7d1f:	add    %edi,%eax
 29f7d21:	jb     29fc77b <wasm[0]::function[1015]::helper::object_read+0x1b7fb>
 29f7d27:	mov    %eax,%r9d
 29f7d2a:	lea    (%rdx,%r9,1),%rax
 29f7d2e:	cmp    %rcx,%r9
 29f7d31:	cmova  %rsi,%rax
 29f7d35:	shl    $0x3,%r8d
 29f7d39:	lea    0x18(%r8),%ecx
 29f7d3d:	sub    %ecx,%edi
 29f7d3f:	sub    %rdi,%rax
 29f7d42:	mov    (%rax),%rax
 29f7d45:	bt     %r13,%rax
 29f7d49:	jae    29f7f9e <wasm[0]::function[1015]::helper::object_read+0x1701e>
 29f7d4f:	mov    0xd8(%rsp),%eax
 29f7d56:	test   %eax,%eax
 29f7d58:	je     29fc77d <wasm[0]::function[1015]::helper::object_read+0x1b7fd>
 29f7d5e:	test   %eax,%eax
 29f7d60:	je     29fc77f <wasm[0]::function[1015]::helper::object_read+0x1b7ff>
 29f7d66:	mov    0x2e0(%rsp),%r12
 29f7d6e:	mov    0x28(%r12),%rcx
 29f7d73:	mov    0x20(%r12),%rdx
 29f7d78:	mov    %eax,%r8d
 29f7d7b:	lea    0x10(%rdx,%r8,1),%rdi
 29f7d80:	xor    %rsi,%rsi
 29f7d83:	cmp    %rcx,%r8
 29f7d86:	cmova  %rsi,%rdi
 29f7d8a:	mov    (%rdi),%edi
 29f7d8c:	cmp    %edi,%r13d
 29f7d8f:	jae    29fc781 <wasm[0]::function[1015]::helper::object_read+0x1b801>
 29f7d95:	mov    %edi,%r8d
 29f7d98:	shl    $0x3,%r8
 29f7d9c:	shr    $0x20,%r8
 29f7da0:	test   %r8,%r8
 29f7da3:	jne    29fc783 <wasm[0]::function[1015]::helper::object_read+0x1b803>
 29f7da9:	shl    $0x3,%edi
 29f7dac:	add    $0x18,%edi
 29f7daf:	jb     29fc785 <wasm[0]::function[1015]::helper::object_read+0x1b805>
 29f7db5:	add    %edi,%eax
 29f7db7:	jb     29fc787 <wasm[0]::function[1015]::helper::object_read+0x1b807>
 29f7dbd:	mov    %eax,%r8d
 29f7dc0:	lea    (%rdx,%r8,1),%rax
 29f7dc4:	cmp    %rcx,%r8
 29f7dc7:	cmova  %rsi,%rax
 29f7dcb:	mov    %r13,%rcx
 29f7dce:	shl    $0x3,%ecx
 29f7dd1:	add    $0x18,%ecx
 29f7dd7:	sub    %ecx,%edi
 29f7dd9:	sub    %rdi,%rax
 29f7ddc:	mov    (%rax),%r12
 29f7ddf:	movl   $0x0,0xe0(%rsp)
 29f7dea:	mov    0x270(%rsp),%rcx
 29f7df2:	mov    (%rcx),%eax
 29f7df4:	mov    %eax,%edx
 29f7df6:	lea    0x20(%rdx),%rcx
 29f7dfa:	mov    0x270(%rsp),%rsi
 29f7e02:	mov    0x4(%rsi),%esi
 29f7e05:	cmp    %rsi,%rcx
 29f7e08:	ja     29fb820 <wasm[0]::function[1015]::helper::object_read+0x1a8a0>
 29f7e0e:	lea    0x20(%rax),%ecx
 29f7e11:	mov    0x270(%rsp),%rsi
 29f7e19:	mov    %ecx,(%rsi)
 29f7e1b:	mov    0x2e0(%rsp),%rcx
 29f7e23:	mov    0x20(%rcx),%rsi
 29f7e27:	lea    (%rsi,%rdx,1),%rcx
 29f7e2b:	movl   $0xb0000042,(%rsi,%rdx,1)
 29f7e32:	mov    %r15d,0x4(%rsi,%rdx,1)
 29f7e37:	mov    0x268(%rsp),%rdi
 29f7e3f:	mov    %edi,0x8(%rsi,%rdx,1)
 29f7e43:	mov    %eax,0xe8(%rsp)
 29f7e4a:	mov    %r12,0x10(%rcx)
 29f7e4e:	movl   $0x3,0x18(%rcx)
 29f7e55:	mov    0xe0(%rsp),%r9d
 29f7e5d:	mov    %r9d,0x1c(%rcx)
 29f7e61:	mov    0x190(%rsp),%rsi
 29f7e69:	mov    0xa20(%rsi),%r10d
 29f7e70:	mov    %r10d,0xe0(%rsp)
 29f7e78:	test   %eax,%eax
 29f7e7a:	je     29fc789 <wasm[0]::function[1015]::helper::object_read+0x1b809>
 29f7e80:	test   %r10d,%r10d
 29f7e83:	je     29fc78b <wasm[0]::function[1015]::helper::object_read+0x1b80b>
 29f7e89:	mov    0x270(%rsp),%rcx
 29f7e91:	mov    (%rcx),%eax
 29f7e93:	mov    %eax,%ecx
 29f7e95:	lea    0x20(%rcx),%rdx
 29f7e99:	mov    0x270(%rsp),%rsi
 29f7ea1:	mov    0x4(%rsi),%esi
 29f7ea4:	cmp    %rsi,%rdx
 29f7ea7:	ja     29fb856 <wasm[0]::function[1015]::helper::object_read+0x1a8d6>
 29f7ead:	lea    0x20(%rax),%edx
 29f7eb0:	mov    0x270(%rsp),%r11
 29f7eb8:	mov    %edx,(%r11)
 29f7ebb:	mov    0x2e0(%rsp),%r12
 29f7ec3:	mov    0x20(%r12),%rdx
 29f7ec8:	lea    (%rdx,%rcx,1),%rsi
 29f7ecc:	movl   $0xb0000072,(%rdx,%rcx,1)
 29f7ed3:	mov    %r14d,0x4(%rdx,%rcx,1)
 29f7ed8:	mov    0x268(%rsp),%rdi
 29f7ee0:	mov    %edi,0x8(%rdx,%rcx,1)
 29f7ee4:	movl   $0xe,0x10(%rsi)
 29f7eeb:	mov    0xe8(%rsp),%ecx
 29f7ef2:	mov    %ecx,0x14(%rsi)
 29f7ef5:	mov    0xe0(%rsp),%ecx
 29f7efc:	mov    %ecx,0x18(%rsi)
 29f7eff:	mov    %ecx,0x1c(%rsi)
 29f7f02:	mov    0xc8(%rsp),%ecx
 29f7f09:	test   %ecx,%ecx
 29f7f0b:	je     29fc78d <wasm[0]::function[1015]::helper::object_read+0x1b80d>
 29f7f11:	test   %eax,%eax
 29f7f13:	je     29fc78f <wasm[0]::function[1015]::helper::object_read+0x1b80f>
 29f7f19:	test   %ecx,%ecx
 29f7f1b:	je     29fc791 <wasm[0]::function[1015]::helper::object_read+0x1b811>
 29f7f21:	mov    0x2e0(%rsp),%r12
 29f7f29:	mov    0x28(%r12),%rdx
 29f7f2e:	mov    0x20(%r12),%rsi
 29f7f33:	mov    %ecx,%r9d
 29f7f36:	lea    0x10(%rsi,%r9,1),%r8
 29f7f3b:	xor    %rdi,%rdi
 29f7f3e:	cmp    %rdx,%r9
 29f7f41:	cmova  %rdi,%r8
 29f7f45:	mov    (%r8),%r8d
 29f7f48:	cmp    %r8d,%r13d
 29f7f4b:	jae    29fc793 <wasm[0]::function[1015]::helper::object_read+0x1b813>
 29f7f51:	mov    %r8d,%r9d
 29f7f54:	shl    $0x2,%r9
 29f7f58:	shr    $0x20,%r9
 29f7f5c:	test   %r9,%r9
 29f7f5f:	jne    29fc795 <wasm[0]::function[1015]::helper::object_read+0x1b815>
 29f7f65:	shl    $0x2,%r8d
 29f7f69:	add    $0x14,%r8d
 29f7f6d:	jb     29fc797 <wasm[0]::function[1015]::helper::object_read+0x1b817>
 29f7f73:	add    %r8d,%ecx
 29f7f76:	jb     29fc799 <wasm[0]::function[1015]::helper::object_read+0x1b819>
 29f7f7c:	mov    %ecx,%r9d
 29f7f7f:	lea    (%rsi,%r9,1),%rcx
 29f7f83:	cmp    %rdx,%r9
 29f7f86:	cmova  %rdi,%rcx
 29f7f8a:	mov    %r13,%rdx
 29f7f8d:	shl    $0x2,%edx
 29f7f90:	add    $0x14,%edx
 29f7f96:	sub    %edx,%r8d
 29f7f99:	sub    %r8,%rcx
 29f7f9c:	mov    %eax,(%rcx)
 29f7f9e:	mov    0x78(%rsp),%ecx
 29f7fa2:	mov    0x90(%rsp),%edx
 29f7fa9:	mov    0x98(%rsp),%esi
 29f7fb0:	mov    0xc0(%rsp),%edi
 29f7fb7:	add    $0x1,%r13d
 29f7fbe:	jmp    29f7c57 <wasm[0]::function[1015]::helper::object_read+0x16cd7>
 29f7fc3:	mov    0x78(%rsp),%eax
 29f7fc7:	test   %eax,%eax
 29f7fc9:	je     29fc79b <wasm[0]::function[1015]::helper::object_read+0x1b81b>
 29f7fcf:	mov    0xc8(%rsp),%edx
 29f7fd6:	test   %edx,%edx
 29f7fd8:	je     29fc79d <wasm[0]::function[1015]::helper::object_read+0x1b81d>
 29f7fde:	test   %eax,%eax
 29f7fe0:	je     29fc79f <wasm[0]::function[1015]::helper::object_read+0x1b81f>
 29f7fe6:	mov    0x2e0(%rsp),%r12
 29f7fee:	mov    0x28(%r12),%rsi
 29f7ff3:	mov    0x20(%r12),%rcx
 29f7ff8:	mov    %eax,%edi
 29f7ffa:	add    %rdi,%rcx
 29f7ffd:	xor    %r8,%r8
 29f8000:	cmp    %rsi,%rdi
 29f8003:	cmova  %r8,%rcx
 29f8007:	mov    %edx,0x20(%rcx)
 29f800a:	mov    0x190(%rsp),%rsi
 29f8012:	mov    0xa00(%rsi),%esi
 29f8018:	mov    0x190(%rsp),%rdx
 29f8020:	mov    0xa10(%rdx),%edx
 29f8026:	test   %esi,%esi
 29f8028:	je     29fc7a1 <wasm[0]::function[1015]::helper::object_read+0x1b821>
 29f802e:	mov    %esi,0x28(%rcx)
 29f8031:	test   %edx,%edx
 29f8033:	je     29fc7a3 <wasm[0]::function[1015]::helper::object_read+0x1b823>
 29f8039:	mov    %edx,0x2c(%rcx)
 29f803c:	movl   $0x0,0x30(%rcx)
 29f8043:	movl   $0x0,0x24(%rcx)
 29f804a:	mov    0x90(%rsp),%ecx
 29f8051:	mov    0x98(%rsp),%edx
 29f8058:	mov    %rdx,%r15
 29f805b:	mov    0xc0(%rsp),%edx
 29f8062:	jmp    29f85cb <wasm[0]::function[1015]::helper::object_read+0x1764b>
 29f8067:	mov    0x88(%rsp),%eax
 29f806e:	test   %eax,%eax
 29f8070:	je     29fc7a5 <wasm[0]::function[1015]::helper::object_read+0x1b825>
 29f8076:	test   %eax,%eax
 29f8078:	je     29fc7a7 <wasm[0]::function[1015]::helper::object_read+0x1b827>
 29f807e:	mov    0x2e0(%rsp),%r12
 29f8086:	mov    0x28(%r12),%rsi
 29f808b:	mov    0x20(%r12),%rdi
 29f8090:	mov    %eax,%r9d
 29f8093:	lea    (%rdi,%r9,1),%rax
 29f8097:	xor    %r8,%r8
 29f809a:	cmp    %rsi,%r9
 29f809d:	cmova  %r8,%rax
 29f80a1:	mov    0x30(%rax),%r9d
 29f80a5:	mov    %r9d,0x78(%rsp)
 29f80aa:	test   %r9d,%r9d
 29f80ad:	je     29fc7a9 <wasm[0]::function[1015]::helper::object_read+0x1b829>
 29f80b3:	test   %r9d,%r9d
 29f80b6:	je     29fc7ab <wasm[0]::function[1015]::helper::object_read+0x1b82b>
 29f80bc:	mov    %r9d,%r10d
 29f80bf:	lea    0x10(%rdi,%r10,1),%r9
 29f80c4:	cmp    %rsi,%r10
 29f80c7:	cmova  %r8,%r9
 29f80cb:	mov    (%r9),%r10d
 29f80ce:	mov    %r10d,%r13d
 29f80d1:	mov    %r13,%r12
 29f80d4:	shl    $0x2,%r12
 29f80d8:	mov    %r12,%r11
 29f80db:	shr    $0x20,%r11
 29f80df:	test   %r11,%r11
 29f80e2:	jne    29fc7ad <wasm[0]::function[1015]::helper::object_read+0x1b82d>
 29f80e8:	mov    %r10,%rcx
 29f80eb:	shl    $0x2,%ecx
 29f80ee:	mov    %r10,0x1d0(%rsp)
 29f80f6:	add    $0x14,%ecx
 29f80f9:	jb     29fc7af <wasm[0]::function[1015]::helper::object_read+0x1b82f>
 29f80ff:	mov    0x270(%rsp),%rdi
 29f8107:	mov    (%rdi),%eax
 29f8109:	mov    %eax,%esi
 29f810b:	mov    %ecx,%edx
 29f810d:	add    $0xf,%rdx
 29f8114:	mov    %rdx,%rdi
 29f8117:	and    $0xfffffffffffffff0,%rdi
 29f811b:	add    %rsi,%rdi
 29f811e:	mov    0x270(%rsp),%r8
 29f8126:	mov    0x4(%r8),%r8d
 29f812a:	cmp    %r8,%rdi
 29f812d:	ja     29fb88d <wasm[0]::function[1015]::helper::object_read+0x1a90d>
 29f8133:	add    $0xf,%ecx
 29f8139:	and    $0xfffffff0,%ecx
 29f813c:	add    %eax,%ecx
 29f813e:	mov    0x270(%rsp),%rdi
 29f8146:	mov    %ecx,(%rdi)
 29f8148:	mov    0x2e0(%rsp),%r10
 29f8150:	mov    0x20(%r10),%rdi
 29f8154:	lea    (%rdi,%rsi,1),%rcx
 29f8158:	movl   $0xa800000e,(%rdi,%rsi,1)
 29f815f:	mov    0x190(%rsp),%r8
 29f8167:	mov    0x28(%r8),%r8
 29f816b:	mov    0x194(%r8),%r8d
 29f8172:	mov    %r8d,0x4(%rdi,%rsi,1)
 29f8177:	and    $0xfffffffffffffff0,%rdx
 29f817b:	mov    %edx,0x8(%rdi,%rsi,1)
 29f817f:	mov    %eax,0x90(%rsp)
 29f8186:	mov    0x1d0(%rsp),%r14
 29f818e:	mov    %r14d,0x10(%rcx)
 29f8192:	test   %eax,%eax
 29f8194:	je     29fc7b1 <wasm[0]::function[1015]::helper::object_read+0x1b831>
 29f819a:	mov    0x2e0(%rsp),%rcx
 29f81a2:	mov    0x28(%rcx),%rcx
 29f81a6:	mov    0x2e0(%rsp),%rdx
 29f81ae:	mov    0x20(%rdx),%rsi
 29f81b2:	mov    %eax,%eax
 29f81b4:	lea    (%rsi,%rax,1),%rdx
 29f81b8:	lea    0x10(%rsi,%rax,1),%rdi
 29f81bd:	xor    %r8,%r8
 29f81c0:	cmp    %rcx,%rax
 29f81c3:	cmova  %r8,%rdi
 29f81c7:	mov    (%rdi),%edi
 29f81c9:	cmp    %rdi,%r13
 29f81cc:	ja     29fc7b3 <wasm[0]::function[1015]::helper::object_read+0x1b833>
 29f81d2:	lea    0x14(%rsi,%rax,1),%rbx
 29f81d7:	mov    %rbx,%rax
 29f81da:	add    %r12,%rax
 29f81dd:	jb     29fc7b5 <wasm[0]::function[1015]::helper::object_read+0x1b835>
 29f81e3:	add    %rsi,%rcx
 29f81e6:	cmp    %rcx,%rax
 29f81e9:	ja     29fc7b7 <wasm[0]::function[1015]::helper::object_read+0x1b837>
 29f81ef:	mov    0x78(%rsp),%edi
 29f81f3:	mov    0x88(%rsp),%r9d
 29f81fb:	mov    0xa8(%rsp),%r11d
 29f8203:	mov    0xb0(%rsp),%eax
 29f820a:	mov    0xb8(%rsp),%ecx
 29f8211:	lea    0x14(%rdx,%r13,4),%r12
 29f8216:	test   %r13,%r13
 29f8219:	je     29f82a3 <wasm[0]::function[1015]::helper::object_read+0x17323>
 29f821f:	mov    %edi,0xb8(%rsp)
 29f8226:	mov    %r9d,0xb0(%rsp)
 29f822e:	mov    %r11d,0xa8(%rsp)
 29f8236:	mov    %eax,0x88(%rsp)
 29f823d:	mov    %ecx,0x78(%rsp)
 29f8241:	mov    0x2e8(%rsp),%r13
 29f8249:	mov    0x0(%r13),%rax
 29f824d:	mov    0x228(%rsp),%rcx
 29f8255:	cmp    %rcx,%rax
 29f8258:	jae    29fb8ca <wasm[0]::function[1015]::helper::object_read+0x1a94a>
 29f825e:	jmp    29f826b <wasm[0]::function[1015]::helper::object_read+0x172eb>
 29f8263:	mov    %rcx,0x228(%rsp)
 29f826b:	movl   $0x0,(%rbx)
 29f8271:	mov    0xb8(%rsp),%edi
 29f8278:	mov    0xb0(%rsp),%r9d
 29f8280:	mov    0xa8(%rsp),%r11d
 29f8288:	mov    0x88(%rsp),%eax
 29f828f:	mov    0x78(%rsp),%ecx
 29f8293:	add    $0x4,%rbx
 29f829a:	cmp    %r12,%rbx
 29f829d:	jne    29f821f <wasm[0]::function[1015]::helper::object_read+0x1729f>
 29f82a3:	mov    %edi,0xb8(%rsp)
 29f82aa:	mov    0x190(%rsp),%rsi
 29f82b2:	mov    0xa20(%rsi),%edx
 29f82b8:	mov    %edx,0xb0(%rsp)
 29f82bf:	xor    %ebx,%ebx
 29f82c1:	mov    $0xb0000072,%r15d
 29f82c7:	mov    %r15,0x1c8(%rsp)
 29f82cf:	mov    0x28(%rsi),%rdx
 29f82d3:	mov    0x13c(%rdx),%r14d
 29f82da:	mov    $0x20,%r13d
 29f82e0:	mov    %r13,0x1a0(%rsp)
 29f82e8:	mov    $0x10,%r13d
 29f82ee:	mov    %r9d,0x98(%rsp)
 29f82f6:	mov    %r11d,0x78(%rsp)
 29f82fb:	mov    %eax,0x88(%rsp)
 29f8302:	mov    %ecx,0xa8(%rsp)
 29f8309:	mov    0x2e8(%rsp),%rax
 29f8311:	mov    (%rax),%rax
 29f8314:	mov    0x228(%rsp),%rcx
 29f831c:	cmp    %rcx,%rax
 29f831f:	jae    29fb8f9 <wasm[0]::function[1015]::helper::object_read+0x1a979>
 29f8325:	mov    0x1d0(%rsp),%rcx
 29f832d:	jmp    29f8342 <wasm[0]::function[1015]::helper::object_read+0x173c2>
 29f8332:	mov    %rcx,0x228(%rsp)
 29f833a:	mov    0x1d0(%rsp),%rcx
 29f8342:	cmp    %ecx,%ebx
 29f8344:	jae    29f852c <wasm[0]::function[1015]::helper::object_read+0x175ac>
 29f834a:	mov    0xb8(%rsp),%eax
 29f8351:	test   %eax,%eax
 29f8353:	je     29fc7b9 <wasm[0]::function[1015]::helper::object_read+0x1b839>
 29f8359:	test   %eax,%eax
 29f835b:	je     29fc7bb <wasm[0]::function[1015]::helper::object_read+0x1b83b>
 29f8361:	mov    0x2e0(%rsp),%r12
 29f8369:	mov    0x28(%r12),%r9
 29f836e:	mov    0x20(%r12),%r10
 29f8373:	mov    %eax,%ecx
 29f8375:	lea    0x10(%r10,%rcx,1),%rsi
 29f837a:	xor    %r11,%r11
 29f837d:	cmp    %r9,%rcx
 29f8380:	cmova  %r11,%rsi
 29f8384:	mov    (%rsi),%ecx
 29f8386:	cmp    %ecx,%ebx
 29f8388:	jae    29fc7bd <wasm[0]::function[1015]::helper::object_read+0x1b83d>
 29f838e:	mov    %ecx,%edx
 29f8390:	shl    $0x2,%rdx
 29f8394:	shr    $0x20,%rdx
 29f8398:	test   %rdx,%rdx
 29f839b:	jne    29fc7bf <wasm[0]::function[1015]::helper::object_read+0x1b83f>
 29f83a1:	shl    $0x2,%ecx
 29f83a4:	add    $0x14,%ecx
 29f83a7:	jb     29fc7c1 <wasm[0]::function[1015]::helper::object_read+0x1b841>
 29f83ad:	add    %ecx,%eax
 29f83af:	jb     29fc7c3 <wasm[0]::function[1015]::helper::object_read+0x1b843>
 29f83b5:	mov    %eax,%edx
 29f83b7:	lea    (%r10,%rdx,1),%rax
 29f83bb:	cmp    %r9,%rdx
 29f83be:	cmova  %r11,%rax
 29f83c2:	mov    %rbx,%r15
 29f83c5:	shl    $0x2,%r15d
 29f83c9:	lea    0x14(%r15),%edx
 29f83cd:	sub    %edx,%ecx
 29f83cf:	sub    %rcx,%rax
 29f83d2:	mov    (%rax),%eax
 29f83d4:	mov    %eax,0xc0(%rsp)
 29f83db:	test   %eax,%eax
 29f83dd:	je     29f8506 <wasm[0]::function[1015]::helper::object_read+0x17586>
 29f83e3:	test   %eax,%eax
 29f83e5:	je     29fc7c5 <wasm[0]::function[1015]::helper::object_read+0x1b845>
 29f83eb:	mov    0xb0(%rsp),%eax
 29f83f2:	test   %eax,%eax
 29f83f4:	je     29fc7c7 <wasm[0]::function[1015]::helper::object_read+0x1b847>
 29f83fa:	mov    0x270(%rsp),%rcx
 29f8402:	mov    (%rcx),%eax
 29f8404:	mov    %eax,%edx
 29f8406:	lea    0x20(%rdx),%rcx
 29f840a:	mov    0x270(%rsp),%rsi
 29f8412:	mov    0x4(%rsi),%esi
 29f8415:	cmp    %rsi,%rcx
 29f8418:	ja     29fb931 <wasm[0]::function[1015]::helper::object_read+0x1a9b1>
 29f841e:	lea    0x20(%rax),%ecx
 29f8421:	mov    0x270(%rsp),%rsi
 29f8429:	mov    %ecx,(%rsi)
 29f842b:	mov    0x2e0(%rsp),%r12
 29f8433:	mov    0x20(%r12),%rsi
 29f8438:	lea    (%rsi,%rdx,1),%rcx
 29f843c:	movl   $0xb0000072,(%rsi,%rdx,1)
 29f8443:	mov    %r14d,0x4(%rsi,%rdx,1)
 29f8448:	mov    0x268(%rsp),%rdi
 29f8450:	mov    %edi,0x8(%rsi,%rdx,1)
 29f8454:	movl   $0xe,0x10(%rcx)
 29f845b:	mov    0xc0(%rsp),%edx
 29f8462:	mov    %edx,0x14(%rcx)
 29f8465:	mov    0xb0(%rsp),%edx
 29f846c:	mov    %edx,0x18(%rcx)
 29f846f:	mov    %edx,0x1c(%rcx)
 29f8472:	mov    0x90(%rsp),%ecx
 29f8479:	test   %ecx,%ecx
 29f847b:	je     29fc7c9 <wasm[0]::function[1015]::helper::object_read+0x1b849>
 29f8481:	test   %eax,%eax
 29f8483:	je     29fc7cb <wasm[0]::function[1015]::helper::object_read+0x1b84b>
 29f8489:	test   %ecx,%ecx
 29f848b:	je     29fc7cd <wasm[0]::function[1015]::helper::object_read+0x1b84d>
 29f8491:	mov    0x2e0(%rsp),%r12
 29f8499:	mov    0x28(%r12),%rdx
 29f849e:	mov    0x20(%r12),%rsi
 29f84a3:	mov    %ecx,%r9d
 29f84a6:	lea    0x10(%rsi,%r9,1),%r8
 29f84ab:	xor    %rdi,%rdi
 29f84ae:	cmp    %rdx,%r9
 29f84b1:	cmova  %rdi,%r8
 29f84b5:	mov    (%r8),%r8d
 29f84b8:	cmp    %r8d,%ebx
 29f84bb:	jae    29fc7cf <wasm[0]::function[1015]::helper::object_read+0x1b84f>
 29f84c1:	mov    %r8d,%r9d
 29f84c4:	shl    $0x2,%r9
 29f84c8:	shr    $0x20,%r9
 29f84cc:	test   %r9,%r9
 29f84cf:	jne    29fc7d1 <wasm[0]::function[1015]::helper::object_read+0x1b851>
 29f84d5:	shl    $0x2,%r8d
 29f84d9:	add    $0x14,%r8d
 29f84dd:	jb     29fc7d3 <wasm[0]::function[1015]::helper::object_read+0x1b853>
 29f84e3:	add    %r8d,%ecx
 29f84e6:	jb     29fc7d5 <wasm[0]::function[1015]::helper::object_read+0x1b855>
 29f84ec:	mov    %ecx,%r9d
 29f84ef:	lea    (%rsi,%r9,1),%rcx
 29f84f3:	cmp    %rdx,%r9
 29f84f6:	cmova  %rdi,%rcx
 29f84fa:	lea    0x14(%r15),%edx
 29f84fe:	sub    %edx,%r8d
 29f8501:	sub    %r8,%rcx
 29f8504:	mov    %eax,(%rcx)
 29f8506:	mov    0x98(%rsp),%r9d
 29f850e:	mov    0x78(%rsp),%r11d
 29f8513:	mov    0x88(%rsp),%eax
 29f851a:	mov    0xa8(%rsp),%ecx
 29f8521:	add    $0x1,%ebx
 29f8527:	jmp    29f82ee <wasm[0]::function[1015]::helper::object_read+0x1736e>
 29f852c:	mov    0x98(%rsp),%eax
 29f8533:	test   %eax,%eax
 29f8535:	je     29fc7d7 <wasm[0]::function[1015]::helper::object_read+0x1b857>
 29f853b:	mov    0x90(%rsp),%edx
 29f8542:	test   %edx,%edx
 29f8544:	je     29fc7d9 <wasm[0]::function[1015]::helper::object_read+0x1b859>
 29f854a:	test   %eax,%eax
 29f854c:	je     29fc7db <wasm[0]::function[1015]::helper::object_read+0x1b85b>
 29f8552:	mov    0x2e0(%rsp),%r12
 29f855a:	mov    0x28(%r12),%rsi
 29f855f:	mov    0x20(%r12),%rcx
 29f8564:	mov    %eax,%edi
 29f8566:	add    %rdi,%rcx
 29f8569:	xor    %r8,%r8
 29f856c:	cmp    %rsi,%rdi
 29f856f:	cmova  %r8,%rcx
 29f8573:	mov    %edx,0x20(%rcx)
 29f8576:	mov    0x190(%rsp),%rsi
 29f857e:	mov    0xa00(%rsi),%esi
 29f8584:	mov    0x190(%rsp),%rdi
 29f858c:	mov    0xa10(%rdi),%edx
 29f8592:	test   %esi,%esi
 29f8594:	je     29fc7dd <wasm[0]::function[1015]::helper::object_read+0x1b85d>
 29f859a:	mov    %esi,0x28(%rcx)
 29f859d:	test   %edx,%edx
 29f859f:	je     29fc7df <wasm[0]::function[1015]::helper::object_read+0x1b85f>
 29f85a5:	mov    %edx,0x2c(%rcx)
 29f85a8:	movl   $0x0,0x30(%rcx)
 29f85af:	movl   $0x0,0x24(%rcx)
 29f85b6:	mov    0x78(%rsp),%ecx
 29f85ba:	mov    0x88(%rsp),%edx
 29f85c1:	mov    %rdx,%r15
 29f85c4:	mov    0xa8(%rsp),%edx
 29f85cb:	test   %eax,%eax
 29f85cd:	je     29fc7e1 <wasm[0]::function[1015]::helper::object_read+0x1b861>
 29f85d3:	test   %eax,%eax
 29f85d5:	je     29fc7e3 <wasm[0]::function[1015]::helper::object_read+0x1b863>
 29f85db:	mov    0x2e0(%rsp),%r12
 29f85e3:	mov    0x28(%r12),%r8
 29f85e8:	mov    0x20(%r12),%r10
 29f85ed:	mov    %eax,%eax
 29f85ef:	lea    (%r10,%rax,1),%r9
 29f85f3:	xor    %r11,%r11
 29f85f6:	cmp    %r8,%rax
 29f85f9:	cmova  %r11,%r9
 29f85fd:	mov    0x10(%r9),%edi
 29f8601:	test   %edi,%edi
 29f8603:	je     29fc7e5 <wasm[0]::function[1015]::helper::object_read+0x1b865>
 29f8609:	test   %edi,%edi
 29f860b:	je     29fc7e7 <wasm[0]::function[1015]::helper::object_read+0x1b867>
 29f8611:	mov    %edi,%esi
 29f8613:	lea    0x10(%r10,%rsi,1),%r10
 29f8618:	cmp    %r8,%rsi
 29f861b:	cmova  %r11,%r10
 29f861f:	mov    (%r10),%r11d
 29f8622:	mov    0x24(%r9),%r8d
 29f8626:	test   %r8d,%r8d
 29f8629:	je     29f8832 <wasm[0]::function[1015]::helper::object_read+0x178b2>
 29f862f:	xor    %eax,%eax
 29f8631:	test   %r11d,%r11d
 29f8634:	je     29f88fd <wasm[0]::function[1015]::helper::object_read+0x1797d>
 29f863a:	mov    0x2e0(%rsp),%r12
 29f8642:	mov    0x28(%r12),%rax
 29f8647:	mov    0x20(%r12),%r10
 29f864c:	lea    0x10(%r10,%rsi,1),%r9
 29f8651:	xor    %r8,%r8
 29f8654:	cmp    %rax,%rsi
 29f8657:	cmova  %r8,%r9
 29f865b:	mov    (%r9),%r9d
 29f865e:	mov    0x198(%rsp),%rsi
 29f8666:	mov    %rsi,%rbx
 29f8669:	shr    $0x10,%ebx
 29f866c:	mov    %rsi,%r12
 29f866f:	xor    %ebx,%r12d
 29f8672:	imul   $0x7feb352d,%r12d,%ebx
 29f8679:	mov    %rbx,%r12
 29f867c:	shr    $0xf,%r12d
 29f8680:	xor    %r12d,%ebx
 29f8683:	imul   $0x846ca68b,%ebx,%r12d
 29f868a:	mov    %r12,%rbx
 29f868d:	shr    $0x10,%ebx
 29f8690:	xor    %ebx,%r12d
 29f8693:	sub    $0x1,%r11d
 29f8697:	and    %r11d,%r12d
 29f869a:	cmp    %r9d,%r12d
 29f869d:	jae    29fc7e9 <wasm[0]::function[1015]::helper::object_read+0x1b869>
 29f86a3:	mov    %r9d,%r11d
 29f86a6:	shl    $0x2,%r11
 29f86aa:	shr    $0x20,%r11
 29f86ae:	test   %r11,%r11
 29f86b1:	jne    29fc7eb <wasm[0]::function[1015]::helper::object_read+0x1b86b>
 29f86b7:	shl    $0x2,%r9d
 29f86bb:	add    $0x14,%r9d
 29f86bf:	jb     29fc7ed <wasm[0]::function[1015]::helper::object_read+0x1b86d>
 29f86c5:	add    %r9d,%edi
 29f86c8:	jb     29fc7ef <wasm[0]::function[1015]::helper::object_read+0x1b86f>
 29f86ce:	mov    %edi,%r11d
 29f86d1:	lea    (%r10,%r11,1),%rdi
 29f86d5:	cmp    %rax,%r11
 29f86d8:	cmova  %r8,%rdi
 29f86dc:	shl    $0x2,%r12d
 29f86e0:	lea    0x14(%r12),%eax
 29f86e5:	sub    %eax,%r9d
 29f86e8:	sub    %r9,%rdi
 29f86eb:	mov    (%rdi),%eax
 29f86ed:	xor    %edi,%edi
 29f86ef:	mov    %esi,%ebx
 29f86f1:	mov    %eax,0x90(%rsp)
 29f86f8:	mov    %edi,0xa8(%rsp)
 29f86ff:	mov    %ecx,0x88(%rsp)
 29f8706:	mov    %r15,%rax
 29f8709:	mov    %eax,0x78(%rsp)
 29f870d:	mov    %edx,0x98(%rsp)
 29f8714:	mov    0x2e8(%rsp),%r13
 29f871c:	mov    0x0(%r13),%rax
 29f8720:	mov    0x228(%rsp),%rcx
 29f8728:	cmp    %rcx,%rax
 29f872b:	jae    29fb968 <wasm[0]::function[1015]::helper::object_read+0x1a9e8>
 29f8731:	jmp    29f873e <wasm[0]::function[1015]::helper::object_read+0x177be>
 29f8736:	mov    %rcx,0x228(%rsp)
 29f873e:	mov    0x90(%rsp),%ecx
 29f8745:	mov    0xa8(%rsp),%eax
 29f874c:	test   %ecx,%ecx
 29f874e:	je     29f8818 <wasm[0]::function[1015]::helper::object_read+0x17898>
 29f8754:	mov    0x90(%rsp),%ecx
 29f875b:	test   %ecx,%ecx
 29f875d:	je     29fc7f1 <wasm[0]::function[1015]::helper::object_read+0x1b871>
 29f8763:	mov    0x2e0(%rsp),%r12
 29f876b:	mov    0x28(%r12),%rax
 29f8770:	mov    %ecx,%edx
 29f8772:	mov    %rdx,%rcx
 29f8775:	add    0x20(%r12),%rcx
 29f877a:	xor    %rsi,%rsi
 29f877d:	cmp    %rax,%rdx
 29f8780:	cmova  %rsi,%rcx
 29f8784:	mov    0x10(%rcx),%rax
 29f8788:	cmp    %rbx,%rax
 29f878b:	je     29f87e5 <wasm[0]::function[1015]::helper::object_read+0x17865>
 29f8791:	mov    0x90(%rsp),%ecx
 29f8798:	test   %ecx,%ecx
 29f879a:	je     29fc7f3 <wasm[0]::function[1015]::helper::object_read+0x1b873>
 29f87a0:	mov    0x2e0(%rsp),%r12
 29f87a8:	mov    0x28(%r12),%rax
 29f87ad:	mov    %ecx,%edx
 29f87af:	mov    %rdx,%rcx
 29f87b2:	add    0x20(%r12),%rcx
 29f87b7:	xor    %rsi,%rsi
 29f87ba:	cmp    %rax,%rdx
 29f87bd:	cmova  %rsi,%rcx
 29f87c1:	mov    0x1c(%rcx),%eax
 29f87c4:	mov    0xa8(%rsp),%edi
 29f87cb:	mov    0x88(%rsp),%ecx
 29f87d2:	mov    0x78(%rsp),%edx
 29f87d6:	mov    %rdx,%r15
 29f87d9:	mov    0x98(%rsp),%edx
 29f87e0:	jmp    29f86f1 <wasm[0]::function[1015]::helper::object_read+0x17771>
 29f87e5:	mov    0x90(%rsp),%ecx
 29f87ec:	test   %ecx,%ecx
 29f87ee:	je     29fc7f5 <wasm[0]::function[1015]::helper::object_read+0x1b875>
 29f87f4:	mov    0x2e0(%rsp),%r12
 29f87fc:	mov    0x28(%r12),%rax
 29f8801:	mov    %ecx,%edx
 29f8803:	mov    %rdx,%rcx
 29f8806:	add    0x20(%r12),%rcx
 29f880b:	xor    %rsi,%rsi
 29f880e:	cmp    %rax,%rdx
 29f8811:	cmova  %rsi,%rcx
 29f8815:	mov    0x18(%rcx),%eax
 29f8818:	mov    0x88(%rsp),%ecx
 29f881f:	mov    0x78(%rsp),%edx
 29f8823:	mov    %rdx,%r15
 29f8826:	mov    0x98(%rsp),%edx
 29f882d:	jmp    29f88fd <wasm[0]::function[1015]::helper::object_read+0x1797d>
 29f8832:	mov    0x198(%rsp),%rsi
 29f883a:	mov    0x2e0(%rsp),%r12
 29f8842:	mov    0x28(%r12),%r8
 29f8847:	mov    0x20(%r12),%r10
 29f884c:	lea    (%r10,%rax,1),%rdi
 29f8850:	xor    %r9,%r9
 29f8853:	cmp    %r8,%rax
 29f8856:	cmova  %r9,%rdi
 29f885a:	mov    0x20(%rdi),%edi
 29f885d:	xor    %eax,%eax
 29f885f:	test   %edi,%edi
 29f8861:	je     29fc7f7 <wasm[0]::function[1015]::helper::object_read+0x1b877>
 29f8867:	test   %edi,%edi
 29f8869:	je     29fc7f9 <wasm[0]::function[1015]::helper::object_read+0x1b879>
 29f886f:	mov    %edi,%r12d
 29f8872:	lea    0x10(%r10,%r12,1),%r10
 29f8877:	cmp    %r8,%r12
 29f887a:	cmova  %r9,%r10
 29f887e:	mov    %esi,%r8d
 29f8881:	mov    (%r10),%r9d
 29f8884:	cmp    %r9,%r8
 29f8887:	jae    29f88fd <wasm[0]::function[1015]::helper::object_read+0x1797d>
 29f888d:	mov    0x2e0(%rsp),%rax
 29f8895:	mov    0x28(%rax),%r10
 29f8899:	mov    0x20(%rax),%r8
 29f889d:	lea    0x10(%r8,%r12,1),%r9
 29f88a2:	xor    %r11,%r11
 29f88a5:	cmp    %r10,%r12
 29f88a8:	cmova  %r11,%r9
 29f88ac:	mov    (%r9),%eax
 29f88af:	cmp    %eax,%esi
 29f88b1:	jae    29fc7fb <wasm[0]::function[1015]::helper::object_read+0x1b87b>
 29f88b7:	mov    %eax,%r9d
 29f88ba:	shl    $0x2,%r9
 29f88be:	shr    $0x20,%r9
 29f88c2:	test   %r9,%r9
 29f88c5:	jne    29fc7fd <wasm[0]::function[1015]::helper::object_read+0x1b87d>
 29f88cb:	shl    $0x2,%eax
 29f88ce:	add    $0x14,%eax
 29f88d1:	jb     29fc7ff <wasm[0]::function[1015]::helper::object_read+0x1b87f>
 29f88d7:	add    %eax,%edi
 29f88d9:	jb     29fc801 <wasm[0]::function[1015]::helper::object_read+0x1b881>
 29f88df:	mov    %edi,%r9d
 29f88e2:	lea    (%r8,%r9,1),%rdi
 29f88e6:	cmp    %r10,%r9
 29f88e9:	cmova  %r11,%rdi
 29f88ed:	shl    $0x2,%esi
 29f88f0:	add    $0x14,%esi
 29f88f6:	sub    %esi,%eax
 29f88f8:	sub    %rax,%rdi
 29f88fb:	mov    (%rdi),%eax
 29f88fd:	mov    %ecx,0x78(%rsp)
 29f8901:	mov    %edx,0x88(%rsp)
 29f8908:	test   %eax,%eax
 29f890a:	je     29f8c3f <wasm[0]::function[1015]::helper::object_read+0x17cbf>
 29f8910:	test   %eax,%eax
 29f8912:	jne    29f8920 <wasm[0]::function[1015]::helper::object_read+0x179a0>
 29f8918:	xor    %r14d,%r14d
 29f891b:	jmp    29f8959 <wasm[0]::function[1015]::helper::object_read+0x179d9>
 29f8920:	test   %eax,%eax
 29f8922:	je     29fc803 <wasm[0]::function[1015]::helper::object_read+0x1b883>
 29f8928:	mov    0x2e0(%rsp),%r12
 29f8930:	mov    0x28(%r12),%rcx
 29f8935:	mov    %eax,%esi
 29f8937:	mov    %rsi,%rdx
 29f893a:	add    0x20(%r12),%rdx
 29f893f:	xor    %rdi,%rdi
 29f8942:	cmp    %rcx,%rsi
 29f8945:	cmova  %rdi,%rdx
 29f8949:	mov    0x10(%rdx),%ecx
 29f894c:	test   $0x4,%ecx
 29f8952:	setne  %cl
 29f8955:	movzbl %cl,%r14d
 29f8959:	test   %eax,%eax
 29f895b:	jne    29f8968 <wasm[0]::function[1015]::helper::object_read+0x179e8>
 29f8961:	xor    %ebx,%ebx
 29f8963:	jmp    29f89a0 <wasm[0]::function[1015]::helper::object_read+0x17a20>
 29f8968:	test   %eax,%eax
 29f896a:	je     29fc805 <wasm[0]::function[1015]::helper::object_read+0x1b885>
 29f8970:	mov    0x2e0(%rsp),%r12
 29f8978:	mov    0x28(%r12),%rcx
 29f897d:	mov    %eax,%esi
 29f897f:	mov    %rsi,%rdx
 29f8982:	add    0x20(%r12),%rdx
 29f8987:	xor    %rdi,%rdi
 29f898a:	cmp    %rcx,%rsi
 29f898d:	cmova  %rdi,%rdx
 29f8991:	mov    0x10(%rdx),%ecx
 29f8994:	test   $0x8,%ecx
 29f899a:	setne  %cl
 29f899d:	movzbl %cl,%ebx
 29f89a0:	test   %eax,%eax
 29f89a2:	jne    29f89b0 <wasm[0]::function[1015]::helper::object_read+0x17a30>
 29f89a8:	xor    %r13d,%r13d
 29f89ab:	jmp    29f89e9 <wasm[0]::function[1015]::helper::object_read+0x17a69>
 29f89b0:	test   %eax,%eax
 29f89b2:	je     29fc807 <wasm[0]::function[1015]::helper::object_read+0x1b887>
 29f89b8:	mov    0x2e0(%rsp),%r12
 29f89c0:	mov    0x28(%r12),%rcx
 29f89c5:	mov    %eax,%esi
 29f89c7:	mov    %rsi,%rdx
 29f89ca:	add    0x20(%r12),%rdx
 29f89cf:	xor    %rdi,%rdi
 29f89d2:	cmp    %rcx,%rsi
 29f89d5:	cmova  %rdi,%rdx
 29f89d9:	mov    0x10(%rdx),%ecx
 29f89dc:	test   $0x2,%ecx
 29f89e2:	setne  %cl
 29f89e5:	movzbl %cl,%r13d
 29f89e9:	test   %eax,%eax
 29f89eb:	je     29fc809 <wasm[0]::function[1015]::helper::object_read+0x1b889>
 29f89f1:	mov    0x2e0(%rsp),%r12
 29f89f9:	mov    0x28(%r12),%rsi
 29f89fe:	mov    0x20(%r12),%rdx
 29f8a03:	mov    %eax,%ecx
 29f8a05:	add    %rcx,%rdx
 29f8a08:	xor    %rdi,%rdi
 29f8a0b:	cmp    %rsi,%rcx
 29f8a0e:	cmova  %rdi,%rdx
 29f8a12:	mov    0x14(%rdx),%esi
 29f8a15:	mov    %esi,0x98(%rsp)
 29f8a1c:	mov    0x18(%rdx),%esi
 29f8a1f:	mov    %esi,0x90(%rsp)
 29f8a26:	mov    0x1c(%rdx),%edx
 29f8a29:	mov    %edx,0xa8(%rsp)
 29f8a30:	test   %eax,%eax
 29f8a32:	jne    29f8a3f <wasm[0]::function[1015]::helper::object_read+0x17abf>
 29f8a38:	xor    %eax,%eax
 29f8a3a:	jmp    29f8a6c <wasm[0]::function[1015]::helper::object_read+0x17aec>
 29f8a3f:	mov    0x2e0(%rsp),%r12
 29f8a47:	mov    0x28(%r12),%rdx
 29f8a4c:	mov    %rcx,%rax
 29f8a4f:	add    0x20(%r12),%rax
 29f8a54:	xor    %rsi,%rsi
 29f8a57:	cmp    %rdx,%rcx
 29f8a5a:	cmova  %rsi,%rax
 29f8a5e:	mov    0x10(%rax),%eax
 29f8a61:	test   $0x1,%eax
 29f8a66:	setne  %al
 29f8a69:	movzbl %al,%eax
 29f8a6c:	test   %eax,%eax
 29f8a6e:	jne    29f8b62 <wasm[0]::function[1015]::helper::object_read+0x17be2>
 29f8a74:	mov    0x98(%rsp),%edx
 29f8a7b:	test   %edx,%edx
 29f8a7d:	je     29fc80b <wasm[0]::function[1015]::helper::object_read+0x1b88b>
 29f8a83:	mov    0x90(%rsp),%esi
 29f8a8a:	test   %esi,%esi
 29f8a8c:	je     29fc80d <wasm[0]::function[1015]::helper::object_read+0x1b88d>
 29f8a92:	mov    0xa8(%rsp),%esi
 29f8a99:	test   %esi,%esi
 29f8a9b:	je     29fc80f <wasm[0]::function[1015]::helper::object_read+0x1b88f>
 29f8aa1:	mov    0x270(%rsp),%rcx
 29f8aa9:	mov    (%rcx),%eax
 29f8aab:	mov    %rax,%r15
 29f8aae:	mov    %eax,%r8d
 29f8ab1:	lea    0x20(%r8),%r9
 29f8ab5:	mov    0x4(%rcx),%r10d
 29f8ab9:	cmp    %r10,%r9
 29f8abc:	ja     29fb998 <wasm[0]::function[1015]::helper::object_read+0x1aa18>
 29f8ac2:	mov    %r15,%rax
 29f8ac5:	lea    0x20(%rax),%r11d
 29f8ac9:	mov    0x270(%rsp),%rcx
 29f8ad1:	mov    %r11d,(%rcx)
 29f8ad4:	mov    0x2e0(%rsp),%r12
 29f8adc:	mov    0x20(%r12),%rcx
 29f8ae1:	lea    (%rcx,%r8,1),%rax
 29f8ae5:	movl   $0xb0000072,(%rcx,%r8,1)
 29f8aed:	mov    0x190(%rsp),%rsi
 29f8af5:	mov    0x28(%rsi),%rdx
 29f8af9:	mov    0x13c(%rdx),%edx
 29f8aff:	mov    %edx,0x4(%rcx,%r8,1)
 29f8b04:	mov    0x268(%rsp),%rdx
 29f8b0c:	mov    %edx,0x8(%rcx,%r8,1)
 29f8b11:	test   %r14d,%r14d
 29f8b14:	setne  %cl
 29f8b17:	movzbl %cl,%r8d
 29f8b1b:	shl    $0x2,%r8d
 29f8b1f:	test   %ebx,%ebx
 29f8b21:	setne  %cl
 29f8b24:	movzbl %cl,%ecx
 29f8b27:	shl    $0x3,%ecx
 29f8b2a:	or     %ecx,%r8d
 29f8b2d:	test   %r13d,%r13d
 29f8b30:	setne  %cl
 29f8b33:	movzbl %cl,%ecx
 29f8b36:	shl    $1,%ecx
 29f8b38:	or     %ecx,%r8d
 29f8b3b:	mov    %r8d,0x10(%rax)
 29f8b3f:	mov    0x98(%rsp),%ecx
 29f8b46:	mov    %ecx,0x14(%rax)
 29f8b49:	mov    0x90(%rsp),%ecx
 29f8b50:	mov    %ecx,0x18(%rax)
 29f8b53:	mov    0xa8(%rsp),%ecx
 29f8b5a:	mov    %ecx,0x1c(%rax)
 29f8b5d:	jmp    29f8c3f <wasm[0]::function[1015]::helper::object_read+0x17cbf>
 29f8b62:	mov    0x98(%rsp),%eax
 29f8b69:	test   %eax,%eax
 29f8b6b:	je     29fc811 <wasm[0]::function[1015]::helper::object_read+0x1b891>
 29f8b71:	mov    0x90(%rsp),%eax
 29f8b78:	test   %eax,%eax
 29f8b7a:	je     29fc813 <wasm[0]::function[1015]::helper::object_read+0x1b893>
 29f8b80:	mov    0xa8(%rsp),%eax
 29f8b87:	test   %eax,%eax
 29f8b89:	je     29fc815 <wasm[0]::function[1015]::helper::object_read+0x1b895>
 29f8b8f:	mov    0x270(%rsp),%rcx
 29f8b97:	mov    (%rcx),%eax
 29f8b99:	mov    %rax,%r15
 29f8b9c:	mov    %eax,%ecx
 29f8b9e:	lea    0x20(%rcx),%rax
 29f8ba2:	mov    0x270(%rsp),%rsi
 29f8baa:	mov    0x4(%rsi),%edx
 29f8bad:	cmp    %rdx,%rax
 29f8bb0:	ja     29fb9df <wasm[0]::function[1015]::helper::object_read+0x1aa5f>
 29f8bb6:	mov    %r15,%rax
 29f8bb9:	add    $0x20,%eax
 29f8bbf:	mov    0x270(%rsp),%rdx
 29f8bc7:	mov    %eax,(%rdx)
 29f8bc9:	mov    0x2e0(%rsp),%r12
 29f8bd1:	mov    0x20(%r12),%rdx
 29f8bd6:	lea    (%rdx,%rcx,1),%rax
 29f8bda:	movl   $0xb0000072,(%rdx,%rcx,1)
 29f8be1:	mov    0x190(%rsp),%rsi
 29f8be9:	mov    0x28(%rsi),%rsi
 29f8bed:	mov    0x13c(%rsi),%esi
 29f8bf3:	mov    %esi,0x4(%rdx,%rcx,1)
 29f8bf7:	mov    0x268(%rsp),%rsi
 29f8bff:	mov    %esi,0x8(%rdx,%rcx,1)
 29f8c03:	test   %ebx,%ebx
 29f8c05:	setne  %cl
 29f8c08:	movzbl %cl,%ecx
 29f8c0b:	shl    $0x3,%ecx
 29f8c0e:	or     $0x1,%ecx
 29f8c11:	test   %r13d,%r13d
 29f8c14:	setne  %dl
 29f8c17:	movzbl %dl,%edx
 29f8c1a:	shl    $1,%edx
 29f8c1c:	or     %edx,%ecx
 29f8c1e:	mov    %ecx,0x10(%rax)
 29f8c21:	mov    0x98(%rsp),%ecx
 29f8c28:	mov    %ecx,0x14(%rax)
 29f8c2b:	mov    0x90(%rsp),%ecx
 29f8c32:	mov    %ecx,0x18(%rax)
 29f8c35:	mov    0xa8(%rsp),%ecx
 29f8c3c:	mov    %ecx,0x1c(%rax)
 29f8c3f:	mov    0x78(%rsp),%eax
 29f8c43:	mov    0x88(%rsp),%ecx
 29f8c4a:	jmp    29f901a <wasm[0]::function[1015]::helper::object_read+0x1809a>
 29f8c4f:	xor    %eax,%eax
 29f8c51:	test   %edx,%edx
 29f8c53:	je     29f8ca4 <wasm[0]::function[1015]::helper::object_read+0x17d24>
 29f8c59:	xor    %eax,%eax
 29f8c5b:	test   $0x1,%edx
 29f8c61:	jne    29f8ca4 <wasm[0]::function[1015]::helper::object_read+0x17d24>
 29f8c67:	mov    0x2e0(%rsp),%r12
 29f8c6f:	mov    0x28(%r12),%rax
 29f8c74:	mov    0x20(%r12),%rcx
 29f8c79:	mov    %edx,%esi
 29f8c7b:	lea    0x4(%rcx,%rsi,1),%rcx
 29f8c80:	xor    %rdi,%rdi
 29f8c83:	cmp    %rax,%rsi
 29f8c86:	cmova  %rdi,%rcx
 29f8c8a:	mov    (%rcx),%eax
 29f8c8c:	mov    0x190(%rsp),%rsi
 29f8c94:	mov    0x28(%rsi),%rcx
 29f8c98:	cmp    0x138(%rcx),%eax
 29f8c9e:	sete   %al
 29f8ca1:	movzbl %al,%eax
 29f8ca4:	test   %eax,%eax
 29f8ca6:	je     29fc817 <wasm[0]::function[1015]::helper::object_read+0x1b897>
 29f8cac:	test   %edx,%edx
 29f8cae:	je     29fc819 <wasm[0]::function[1015]::helper::object_read+0x1b899>
 29f8cb4:	mov    0x68(%rsp),%r9d
 29f8cb9:	mov    0x1b8(%rsp),%rcx
 29f8cc1:	mov    0x1c0(%rsp),%r8
 29f8cc9:	mov    0x190(%rsp),%rsi
 29f8cd1:	mov    0x190(%rsp),%rdi
 29f8cd9:	call   29ffc60 <wasm[0]::function[1019]::helper::ordinary_own_descriptor>
 29f8cde:	mov    0xa0(%rsp),%ecx
 29f8ce5:	mov    %rcx,%r15
 29f8ce8:	test   %eax,%eax
 29f8cea:	je     29f900f <wasm[0]::function[1015]::helper::object_read+0x1808f>
 29f8cf0:	test   %eax,%eax
 29f8cf2:	jne    29f8cff <wasm[0]::function[1015]::helper::object_read+0x17d7f>
 29f8cf8:	xor    %ebx,%ebx
 29f8cfa:	jmp    29f8d3a <wasm[0]::function[1015]::helper::object_read+0x17dba>
 29f8cff:	test   %eax,%eax
 29f8d01:	je     29fc81b <wasm[0]::function[1015]::helper::object_read+0x1b89b>
 29f8d07:	mov    0x2e0(%rsp),%r12
 29f8d0f:	mov    0x28(%r12),%rsi
 29f8d14:	mov    %eax,%r8d
 29f8d17:	mov    %r8,%rdi
 29f8d1a:	add    0x20(%r12),%rdi
 29f8d1f:	xor    %r9,%r9
 29f8d22:	cmp    %rsi,%r8
 29f8d25:	cmova  %r9,%rdi
 29f8d29:	mov    0x10(%rdi),%edi
 29f8d2c:	test   $0x4,%edi
 29f8d32:	setne  %r8b
 29f8d36:	movzbl %r8b,%ebx
 29f8d3a:	test   %eax,%eax
 29f8d3c:	jne    29f8d4a <wasm[0]::function[1015]::helper::object_read+0x17dca>
 29f8d42:	xor    %r14d,%r14d
 29f8d45:	jmp    29f8d84 <wasm[0]::function[1015]::helper::object_read+0x17e04>
 29f8d4a:	test   %eax,%eax
 29f8d4c:	je     29fc81d <wasm[0]::function[1015]::helper::object_read+0x1b89d>
 29f8d52:	mov    0x2e0(%rsp),%r12
 29f8d5a:	mov    0x28(%r12),%rcx
 29f8d5f:	mov    %eax,%edx
 29f8d61:	mov    %rdx,%r11
 29f8d64:	add    0x20(%r12),%r11
 29f8d69:	xor    %rsi,%rsi
 29f8d6c:	cmp    %rcx,%rdx
 29f8d6f:	cmova  %rsi,%r11
 29f8d73:	mov    0x10(%r11),%ecx
 29f8d77:	test   $0x8,%ecx
 29f8d7d:	setne  %cl
 29f8d80:	movzbl %cl,%r14d
 29f8d84:	test   %eax,%eax
 29f8d86:	jne    29f8d94 <wasm[0]::function[1015]::helper::object_read+0x17e14>
 29f8d8c:	xor    %r13d,%r13d
 29f8d8f:	jmp    29f8dcd <wasm[0]::function[1015]::helper::object_read+0x17e4d>
 29f8d94:	test   %eax,%eax
 29f8d96:	je     29fc81f <wasm[0]::function[1015]::helper::object_read+0x1b89f>
 29f8d9c:	mov    0x2e0(%rsp),%r12
 29f8da4:	mov    0x28(%r12),%rcx
 29f8da9:	mov    %eax,%esi
 29f8dab:	mov    %rsi,%rdx
 29f8dae:	add    0x20(%r12),%rdx
 29f8db3:	xor    %rdi,%rdi
 29f8db6:	cmp    %rcx,%rsi
 29f8db9:	cmova  %rdi,%rdx
 29f8dbd:	mov    0x10(%rdx),%ecx
 29f8dc0:	test   $0x2,%ecx
 29f8dc6:	setne  %cl
 29f8dc9:	movzbl %cl,%r13d
 29f8dcd:	test   %eax,%eax
 29f8dcf:	je     29fc821 <wasm[0]::function[1015]::helper::object_read+0x1b8a1>
 29f8dd5:	mov    0x2e0(%rsp),%r12
 29f8ddd:	mov    0x28(%r12),%rsi
 29f8de2:	mov    0x20(%r12),%rdx
 29f8de7:	mov    %eax,%ecx
 29f8de9:	add    %rcx,%rdx
 29f8dec:	xor    %rdi,%rdi
 29f8def:	cmp    %rsi,%rcx
 29f8df2:	cmova  %rdi,%rdx
 29f8df6:	mov    0x14(%rdx),%esi
 29f8df9:	mov    %esi,0xa0(%rsp)
 29f8e00:	mov    0x18(%rdx),%esi
 29f8e03:	mov    %esi,0x78(%rsp)
 29f8e07:	mov    0x1c(%rdx),%edx
 29f8e0a:	mov    %edx,0x88(%rsp)
 29f8e11:	test   %eax,%eax
 29f8e13:	jne    29f8e20 <wasm[0]::function[1015]::helper::object_read+0x17ea0>
 29f8e19:	xor    %eax,%eax
 29f8e1b:	jmp    29f8e4d <wasm[0]::function[1015]::helper::object_read+0x17ecd>
 29f8e20:	mov    0x2e0(%rsp),%r12
 29f8e28:	mov    0x28(%r12),%rdx
 29f8e2d:	mov    %rcx,%rax
 29f8e30:	add    0x20(%r12),%rax
 29f8e35:	xor    %rsi,%rsi
 29f8e38:	cmp    %rdx,%rcx
 29f8e3b:	cmova  %rsi,%rax
 29f8e3f:	mov    0x10(%rax),%eax
 29f8e42:	test   $0x1,%eax
 29f8e47:	setne  %al
 29f8e4a:	movzbl %al,%eax
 29f8e4d:	test   %eax,%eax
 29f8e4f:	jne    29f8f3c <wasm[0]::function[1015]::helper::object_read+0x17fbc>
 29f8e55:	mov    0xa0(%rsp),%eax
 29f8e5c:	test   %eax,%eax
 29f8e5e:	je     29fc823 <wasm[0]::function[1015]::helper::object_read+0x1b8a3>
 29f8e64:	mov    0x78(%rsp),%eax
 29f8e68:	test   %eax,%eax
 29f8e6a:	je     29fc825 <wasm[0]::function[1015]::helper::object_read+0x1b8a5>
 29f8e70:	mov    0x88(%rsp),%eax
 29f8e77:	test   %eax,%eax
 29f8e79:	je     29fc827 <wasm[0]::function[1015]::helper::object_read+0x1b8a7>
 29f8e7f:	mov    0x270(%rsp),%rcx
 29f8e87:	mov    (%rcx),%eax
 29f8e89:	mov    %rax,%r15
 29f8e8c:	mov    %eax,%ecx
 29f8e8e:	lea    0x20(%rcx),%rax
 29f8e92:	mov    0x270(%rsp),%rdx
 29f8e9a:	mov    0x4(%rdx),%edx
 29f8e9d:	cmp    %rdx,%rax
 29f8ea0:	ja     29fba25 <wasm[0]::function[1015]::helper::object_read+0x1aaa5>
 29f8ea6:	mov    %r15,%rax
 29f8ea9:	add    $0x20,%eax
 29f8eaf:	mov    0x270(%rsp),%rdx
 29f8eb7:	mov    %eax,(%rdx)
 29f8eb9:	mov    0x2e0(%rsp),%r12
 29f8ec1:	mov    0x20(%r12),%rdx
 29f8ec6:	lea    (%rdx,%rcx,1),%rax
 29f8eca:	movl   $0xb0000072,(%rdx,%rcx,1)
 29f8ed1:	mov    0x190(%rsp),%rsi
 29f8ed9:	mov    0x28(%rsi),%rsi
 29f8edd:	mov    0x13c(%rsi),%esi
 29f8ee3:	mov    %esi,0x4(%rdx,%rcx,1)
 29f8ee7:	mov    0x268(%rsp),%rsi
 29f8eef:	mov    %esi,0x8(%rdx,%rcx,1)
 29f8ef3:	test   %ebx,%ebx
 29f8ef5:	setne  %cl
 29f8ef8:	movzbl %cl,%ecx
 29f8efb:	shl    $0x2,%ecx
 29f8efe:	test   %r14d,%r14d
 29f8f01:	setne  %dl
 29f8f04:	movzbl %dl,%edx
 29f8f07:	shl    $0x3,%edx
 29f8f0a:	or     %edx,%ecx
 29f8f0c:	test   %r13d,%r13d
 29f8f0f:	setne  %dl
 29f8f12:	movzbl %dl,%edx
 29f8f15:	shl    $1,%edx
 29f8f17:	or     %edx,%ecx
 29f8f19:	mov    %ecx,0x10(%rax)
 29f8f1c:	mov    0xa0(%rsp),%ecx
 29f8f23:	mov    %ecx,0x14(%rax)
 29f8f26:	mov    0x78(%rsp),%ecx
 29f8f2a:	mov    %ecx,0x18(%rax)
 29f8f2d:	mov    0x88(%rsp),%ecx
 29f8f34:	mov    %ecx,0x1c(%rax)
 29f8f37:	jmp    29f900f <wasm[0]::function[1015]::helper::object_read+0x1808f>
 29f8f3c:	mov    0xa0(%rsp),%eax
 29f8f43:	test   %eax,%eax
 29f8f45:	je     29fc829 <wasm[0]::function[1015]::helper::object_read+0x1b8a9>
 29f8f4b:	mov    0x78(%rsp),%eax
 29f8f4f:	test   %eax,%eax
 29f8f51:	je     29fc82b <wasm[0]::function[1015]::helper::object_read+0x1b8ab>
 29f8f57:	mov    0x88(%rsp),%edx
 29f8f5e:	test   %edx,%edx
 29f8f60:	je     29fc82d <wasm[0]::function[1015]::helper::object_read+0x1b8ad>
 29f8f66:	mov    0x270(%rsp),%rcx
 29f8f6e:	mov    (%rcx),%eax
 29f8f70:	mov    %rax,%r15
 29f8f73:	mov    %eax,%esi
 29f8f75:	lea    0x20(%rsi),%rdi
 29f8f79:	mov    0x4(%rcx),%r8d
 29f8f7d:	cmp    %r8,%rdi
 29f8f80:	ja     29fba63 <wasm[0]::function[1015]::helper::object_read+0x1aae3>
 29f8f86:	mov    %r15,%rax
 29f8f89:	lea    0x20(%rax),%edi
 29f8f8c:	mov    0x270(%rsp),%rcx
 29f8f94:	mov    %edi,(%rcx)
 29f8f96:	mov    0x2e0(%rsp),%r12
 29f8f9e:	mov    0x20(%r12),%r8
 29f8fa3:	lea    (%r8,%rsi,1),%rax
 29f8fa7:	movl   $0xb0000072,(%r8,%rsi,1)
 29f8faf:	mov    0x190(%rsp),%rcx
 29f8fb7:	mov    0x28(%rcx),%r9
 29f8fbb:	mov    0x13c(%r9),%r9d
 29f8fc2:	mov    %r9d,0x4(%r8,%rsi,1)
 29f8fc7:	mov    0x268(%rsp),%rcx
 29f8fcf:	mov    %ecx,0x8(%r8,%rsi,1)
 29f8fd4:	test   %r14d,%r14d
 29f8fd7:	setne  %cl
 29f8fda:	rex movzbl %cl,%edi
 29f8fde:	shl    $0x3,%edi
 29f8fe1:	or     $0x1,%edi
 29f8fe4:	test   %r13d,%r13d
 29f8fe7:	setne  %cl
 29f8fea:	movzbl %cl,%ecx
 29f8fed:	shl    $1,%ecx
 29f8fef:	or     %ecx,%edi
 29f8ff1:	mov    %edi,0x10(%rax)
 29f8ff4:	mov    0xa0(%rsp),%ecx
 29f8ffb:	mov    %ecx,0x14(%rax)
 29f8ffe:	mov    0x78(%rsp),%ecx
 29f9002:	mov    %ecx,0x18(%rax)
 29f9005:	mov    0x88(%rsp),%ecx
 29f900c:	mov    %ecx,0x1c(%rax)
 29f900f:	mov    0x80(%rsp),%eax
 29f9016:	mov    0x50(%rsp),%ecx
 29f901a:	mov    %eax,0x78(%rsp)
 29f901e:	mov    %ecx,0x88(%rsp)
 29f9025:	mov    %r15,%rax
 29f9028:	mov    %r15,%rsi
 29f902b:	test   %esi,%eax
 29f902d:	jne    29f903a <wasm[0]::function[1015]::helper::object_read+0x180ba>
 29f9033:	xor    %eax,%eax
 29f9035:	jmp    29f907b <wasm[0]::function[1015]::helper::object_read+0x180fb>
 29f903a:	mov    %r15,%rax
 29f903d:	mov    %r15,%r10
 29f9040:	test   %r10d,%eax
 29f9043:	je     29fc82f <wasm[0]::function[1015]::helper::object_read+0x1b8af>
 29f9049:	mov    0x2e0(%rsp),%r12
 29f9051:	mov    0x28(%r12),%rax
 29f9056:	mov    %r15,%rcx
 29f9059:	mov    %ecx,%edx
 29f905b:	mov    %rdx,%rcx
 29f905e:	add    0x20(%r12),%rcx
 29f9063:	xor    %rsi,%rsi
 29f9066:	cmp    %rax,%rdx
 29f9069:	cmova  %rsi,%rcx
 29f906d:	mov    0x10(%rcx),%eax
 29f9070:	test   $0x2,%eax
 29f9075:	setne  %al
 29f9078:	movzbl %al,%eax
 29f907b:	mov    0x78(%rsp),%edx
 29f907f:	xor    %esi,%esi
 29f9081:	mov    %r15,%rcx
 29f9084:	mov    %r15,%rdi
 29f9087:	test   %edi,%ecx
 29f9089:	setne  %cl
 29f908c:	test   %eax,%eax
 29f908e:	sete   %al
 29f9091:	test   %cl,%al
 29f9093:	jne    29f90a6 <wasm[0]::function[1015]::helper::object_read+0x18126>
 29f9099:	mov    %rsi,0x298(%rsp)
 29f90a1:	jmp    29f9e7f <wasm[0]::function[1015]::helper::object_read+0x18eff>
 29f90a6:	mov    %r15,%rax
 29f90a9:	mov    %r15,%rcx
 29f90ac:	test   %ecx,%eax
 29f90ae:	jne    29f90bb <wasm[0]::function[1015]::helper::object_read+0x1813b>
 29f90b4:	xor    %eax,%eax
 29f90b6:	jmp    29f90f8 <wasm[0]::function[1015]::helper::object_read+0x18178>
 29f90bb:	mov    %r15,%rax
 29f90be:	mov    %r15,%rcx
 29f90c1:	test   %ecx,%eax
 29f90c3:	je     29fc831 <wasm[0]::function[1015]::helper::object_read+0x1b8b1>
 29f90c9:	mov    0x2e0(%rsp),%r12
 29f90d1:	mov    0x28(%r12),%rax
 29f90d6:	mov    %ecx,%edx
 29f90d8:	mov    %rdx,%rcx
 29f90db:	add    0x20(%r12),%rcx
 29f90e0:	xor    %rsi,%rsi
 29f90e3:	cmp    %rax,%rdx
 29f90e6:	cmova  %rsi,%rcx
 29f90ea:	mov    0x10(%rcx),%eax
 29f90ed:	test   $0x1,%eax
 29f90f2:	setne  %al
 29f90f5:	movzbl %al,%eax
 29f90f8:	test   %eax,%eax
 29f90fa:	jne    29f9b4d <wasm[0]::function[1015]::helper::object_read+0x18bcd>
 29f9100:	mov    %r15,%rax
 29f9103:	mov    %r15,%rdx
 29f9106:	test   %edx,%eax
 29f9108:	jne    29f9115 <wasm[0]::function[1015]::helper::object_read+0x18195>
 29f910e:	xor    %eax,%eax
 29f9110:	jmp    29f9156 <wasm[0]::function[1015]::helper::object_read+0x181d6>
 29f9115:	mov    %r15,%rax
 29f9118:	mov    %r15,%r9
 29f911b:	test   %r9d,%eax
 29f911e:	je     29fc833 <wasm[0]::function[1015]::helper::object_read+0x1b8b3>
 29f9124:	mov    0x2e0(%rsp),%r12
 29f912c:	mov    0x28(%r12),%rax
 29f9131:	mov    %r15,%rcx
 29f9134:	mov    %ecx,%edx
 29f9136:	mov    %rdx,%rcx
 29f9139:	add    0x20(%r12),%rcx
 29f913e:	xor    %rsi,%rsi
 29f9141:	cmp    %rax,%rdx
 29f9144:	cmova  %rsi,%rcx
 29f9148:	mov    0x10(%rcx),%eax
 29f914b:	test   $0x4,%eax
 29f9150:	setne  %al
 29f9153:	movzbl %al,%eax
 29f9156:	mov    0x78(%rsp),%edx
 29f915a:	xor    %esi,%esi
 29f915c:	test   %eax,%eax
 29f915e:	je     29f9171 <wasm[0]::function[1015]::helper::object_read+0x181f1>
 29f9164:	mov    %rsi,0x298(%rsp)
 29f916c:	jmp    29f9e7f <wasm[0]::function[1015]::helper::object_read+0x18eff>
 29f9171:	xor    %edx,%edx
 29f9173:	xor    %rax,%rax
 29f9176:	mov    %r15,%rcx
 29f9179:	mov    %r15,%rsi
 29f917c:	test   %esi,%ecx
 29f917e:	jne    29f9194 <wasm[0]::function[1015]::helper::object_read+0x18214>
 29f9184:	mov    %rdx,%rcx
 29f9187:	mov    0x280(%rsp),%r10
 29f918f:	jmp    29f930d <wasm[0]::function[1015]::helper::object_read+0x1838d>
 29f9194:	mov    %r15,%rax
 29f9197:	mov    %r15,%rcx
 29f919a:	test   %ecx,%eax
 29f919c:	je     29fc835 <wasm[0]::function[1015]::helper::object_read+0x1b8b5>
 29f91a2:	mov    0x2e0(%rsp),%r12
 29f91aa:	mov    0x28(%r12),%rax
 29f91af:	mov    0x20(%r12),%rcx
 29f91b4:	mov    %r15,%rdx
 29f91b7:	mov    %edx,%edx
 29f91b9:	add    %rdx,%rcx
 29f91bc:	xor    %rsi,%rsi
 29f91bf:	cmp    %rax,%rdx
 29f91c2:	cmova  %rsi,%rcx
 29f91c6:	mov    0x14(%rcx),%edx
 29f91c9:	test   %edx,%edx
 29f91cb:	je     29fc837 <wasm[0]::function[1015]::helper::object_read+0x1b8b7>
 29f91d1:	xor    %r8d,%r8d
 29f91d4:	test   $0x1,%edx
 29f91da:	jne    29f9221 <wasm[0]::function[1015]::helper::object_read+0x182a1>
 29f91e0:	mov    0x2e0(%rsp),%r12
 29f91e8:	mov    0x28(%r12),%rsi
 29f91ed:	mov    0x20(%r12),%rdi
 29f91f2:	mov    %edx,%r8d
 29f91f5:	lea    0x4(%rdi,%r8,1),%rdi
 29f91fa:	xor    %r9,%r9
 29f91fd:	cmp    %rsi,%r8
 29f9200:	cmova  %r9,%rdi
 29f9204:	mov    (%rdi),%edi
 29f9206:	mov    0x190(%rsp),%rsi
 29f920e:	mov    0x28(%rsi),%r8
 29f9212:	cmp    0x120(%r8),%edi
 29f9219:	sete   %r8b
 29f921d:	movzbl %r8b,%r8d
 29f9221:	test   %r8d,%r8d
 29f9224:	jne    29f927f <wasm[0]::function[1015]::helper::object_read+0x182ff>
 29f922a:	mov    0x190(%rsp),%rsi
 29f9232:	mov    0x190(%rsp),%rdi
 29f923a:	call   2a01c00 <wasm[0]::function[1024]::helper::property_value_resolve>
 29f923f:	test   %eax,%eax
 29f9241:	je     29fc839 <wasm[0]::function[1015]::helper::object_read+0x1b8b9>
 29f9247:	test   %eax,%eax
 29f9249:	je     29fc83b <wasm[0]::function[1015]::helper::object_read+0x1b8bb>
 29f924f:	mov    0x2e0(%rsp),%r12
 29f9257:	mov    0x28(%r12),%rdx
 29f925c:	mov    0x20(%r12),%rcx
 29f9261:	mov    %eax,%eax
 29f9263:	add    %rax,%rcx
 29f9266:	xor    %rsi,%rsi
 29f9269:	cmp    %rdx,%rax
 29f926c:	cmova  %rsi,%rcx
 29f9270:	mov    0x18(%rcx),%edx
 29f9273:	mov    0x10(%rcx),%rax
 29f9277:	mov    0x1c(%rcx),%ecx
 29f927a:	jmp    29f9305 <wasm[0]::function[1015]::helper::object_read+0x18385>
 29f927f:	xor    %eax,%eax
 29f9281:	test   $0x1,%edx
 29f9287:	jne    29f92ca <wasm[0]::function[1015]::helper::object_read+0x1834a>
 29f928d:	mov    0x2e0(%rsp),%r12
 29f9295:	mov    0x28(%r12),%rax
 29f929a:	mov    0x20(%r12),%rcx
 29f929f:	mov    %edx,%esi
 29f92a1:	lea    0x4(%rcx,%rsi,1),%rcx
 29f92a6:	xor    %rdi,%rdi
 29f92a9:	cmp    %rax,%rsi
 29f92ac:	cmova  %rdi,%rcx
 29f92b0:	mov    (%rcx),%eax
 29f92b2:	mov    0x190(%rsp),%rsi
 29f92ba:	mov    0x28(%rsi),%rcx
 29f92be:	cmp    0x120(%rcx),%eax
 29f92c4:	sete   %al
 29f92c7:	movzbl %al,%eax
 29f92ca:	test   %eax,%eax
 29f92cc:	je     29fc83d <wasm[0]::function[1015]::helper::object_read+0x1b8bd>
 29f92d2:	test   %edx,%edx
 29f92d4:	je     29fc83f <wasm[0]::function[1015]::helper::object_read+0x1b8bf>
 29f92da:	mov    0x2e0(%rsp),%r12
 29f92e2:	mov    0x28(%r12),%rax
 29f92e7:	mov    0x20(%r12),%rcx
 29f92ec:	mov    %edx,%edx
 29f92ee:	add    %rdx,%rcx
 29f92f1:	xor    %rsi,%rsi
 29f92f4:	cmp    %rax,%rdx
 29f92f7:	cmova  %rsi,%rcx
 29f92fb:	mov    0x18(%rcx),%edx
 29f92fe:	mov    0x10(%rcx),%rax
 29f9302:	mov    0x1c(%rcx),%ecx
 29f9305:	mov    0x280(%rsp),%r10
 29f930d:	mov    0x280(%rsp),%r10
 29f9315:	cmp    %edx,%r10d
 29f9318:	je     29f9330 <wasm[0]::function[1015]::helper::object_read+0x183b0>
 29f931e:	mov    0x88(%rsp),%edi
 29f9325:	mov    0x78(%rsp),%edx
 29f9329:	xor    %eax,%eax
 29f932b:	jmp    29f989a <wasm[0]::function[1015]::helper::object_read+0x1891a>
 29f9330:	mov    0x280(%rsp),%rdx
 29f9338:	cmp    $0x3,%edx
 29f933b:	je     29f984b <wasm[0]::function[1015]::helper::object_read+0x188cb>
 29f9341:	mov    0x280(%rsp),%rdx
 29f9349:	cmp    $0x4,%edx
 29f934c:	je     29f9730 <wasm[0]::function[1015]::helper::object_read+0x187b0>
 29f9352:	mov    0x280(%rsp),%rdx
 29f935a:	cmp    $0xa,%edx
 29f935d:	je     29f93d9 <wasm[0]::function[1015]::helper::object_read+0x18459>
 29f9363:	mov    0x280(%rsp),%rdx
 29f936b:	mov    0x280(%rsp),%rsi
 29f9373:	test   %esi,%edx
 29f9375:	sete   %dl
 29f9378:	cmp    $0x1,%esi
 29f937b:	sete   %sil
 29f937f:	or     %esi,%edx
 29f9381:	test   %dl,%dl
 29f9383:	jne    29f93c1 <wasm[0]::function[1015]::helper::object_read+0x18441>
 29f9389:	mov    0x280(%rsp),%rdx
 29f9391:	cmp    $0x2,%edx
 29f9394:	je     29f93ab <wasm[0]::function[1015]::helper::object_read+0x1842b>
 29f939a:	mov    0x78(%rsp),%eax
 29f939e:	cmp    %ecx,%eax
 29f93a0:	sete   %al
 29f93a3:	movzbl %al,%eax
 29f93a6:	jmp    29f93c9 <wasm[0]::function[1015]::helper::object_read+0x18449>
 29f93ab:	mov    0x288(%rsp),%rcx
 29f93b3:	cmp    %rax,%rcx
 29f93b6:	sete   %al
 29f93b9:	movzbl %al,%eax
 29f93bc:	jmp    29f93c9 <wasm[0]::function[1015]::helper::object_read+0x18449>
 29f93c1:	mov    0x278(%rsp),%rax
 29f93c9:	mov    0x88(%rsp),%edi
 29f93d0:	mov    0x78(%rsp),%edx
 29f93d4:	jmp    29f989a <wasm[0]::function[1015]::helper::object_read+0x1891a>
 29f93d9:	mov    0x78(%rsp),%eax
 29f93dd:	xor    %esi,%esi
 29f93df:	test   %eax,%eax
 29f93e1:	je     29f943a <wasm[0]::function[1015]::helper::object_read+0x184ba>
 29f93e7:	mov    0x78(%rsp),%eax
 29f93eb:	xor    %esi,%esi
 29f93ed:	test   $0x1,%eax
 29f93f2:	jne    29f943a <wasm[0]::function[1015]::helper::object_read+0x184ba>
 29f93f8:	mov    0x78(%rsp),%edx
 29f93fc:	mov    0x2e0(%rsp),%r12
 29f9404:	mov    0x28(%r12),%rax
 29f9409:	mov    0x20(%r12),%rdi
 29f940e:	mov    %edx,%esi
 29f9410:	lea    0x4(%rdi,%rsi,1),%rdx
 29f9415:	xor    %rdi,%rdi
 29f9418:	cmp    %rax,%rsi
 29f941b:	cmova  %rdi,%rdx
 29f941f:	mov    (%rdx),%eax
 29f9421:	mov    0x190(%rsp),%rsi
 29f9429:	mov    0x28(%rsi),%rdx
 29f942d:	cmp    0x23c(%rdx),%eax
 29f9433:	sete   %al
 29f9436:	rex movzbl %al,%esi
 29f943a:	test   %esi,%esi
 29f943c:	je     29fc841 <wasm[0]::function[1015]::helper::object_read+0x1b8c1>
 29f9442:	xor    %eax,%eax
 29f9444:	test   %ecx,%ecx
 29f9446:	je     29f949c <wasm[0]::function[1015]::helper::object_read+0x1851c>
 29f944c:	xor    %eax,%eax
 29f944e:	test   $0x1,%ecx
 29f9454:	jne    29f949c <wasm[0]::function[1015]::helper::object_read+0x1851c>
 29f945a:	mov    0x2e0(%rsp),%r12
 29f9462:	mov    0x28(%r12),%rdi
 29f9467:	mov    0x20(%r12),%r9
 29f946c:	mov    %ecx,%r8d
 29f946f:	lea    0x4(%r9,%r8,1),%rsi
 29f9474:	xor    %r9,%r9
 29f9477:	cmp    %rdi,%r8
 29f947a:	cmova  %r9,%rsi
 29f947e:	mov    (%rsi),%r8d
 29f9481:	mov    0x190(%rsp),%rsi
 29f9489:	mov    0x28(%rsi),%r9
 29f948d:	cmp    0x23c(%r9),%r8d
 29f9494:	sete   %r9b
 29f9498:	movzbl %r9b,%eax
 29f949c:	test   %eax,%eax
 29f949e:	je     29fc843 <wasm[0]::function[1015]::helper::object_read+0x1b8c3>
 29f94a4:	mov    0x78(%rsp),%edx
 29f94a8:	test   %edx,%edx
 29f94aa:	je     29fc845 <wasm[0]::function[1015]::helper::object_read+0x1b8c5>
 29f94b0:	test   %edx,%edx
 29f94b2:	je     29fc847 <wasm[0]::function[1015]::helper::object_read+0x1b8c7>
 29f94b8:	mov    0x2e0(%rsp),%r12
 29f94c0:	mov    0x28(%r12),%rax
 29f94c5:	mov    0x20(%r12),%rsi
 29f94ca:	mov    %edx,%r8d
 29f94cd:	lea    (%rsi,%r8,1),%r9
 29f94d1:	xor    %rdi,%rdi
 29f94d4:	cmp    %rax,%r8
 29f94d7:	cmova  %rdi,%r9
 29f94db:	mov    0x10(%r9),%r8d
 29f94df:	test   %ecx,%ecx
 29f94e1:	je     29fc849 <wasm[0]::function[1015]::helper::object_read+0x1b8c9>
 29f94e7:	test   %ecx,%ecx
 29f94e9:	je     29fc84b <wasm[0]::function[1015]::helper::object_read+0x1b8cb>
 29f94ef:	mov    %ecx,%ecx
 29f94f1:	lea    (%rsi,%rcx,1),%r11
 29f94f5:	cmp    %rax,%rcx
 29f94f8:	cmova  %rdi,%r11
 29f94fc:	mov    0x10(%r11),%ecx
 29f9500:	mov    0x14(%r9),%r10d
 29f9504:	mov    %r10d,0xa0(%rsp)
 29f950c:	mov    0x14(%r11),%r9d
 29f9510:	mov    %r9d,0xa8(%rsp)
 29f9518:	test   %r10d,%r10d
 29f951b:	je     29fc84d <wasm[0]::function[1015]::helper::object_read+0x1b8cd>
 29f9521:	test   %r10d,%r10d
 29f9524:	je     29fc84f <wasm[0]::function[1015]::helper::object_read+0x1b8cf>
 29f952a:	mov    %r10d,%r11d
 29f952d:	lea    0x10(%rsi,%r11,1),%r10
 29f9532:	cmp    %rax,%r11
 29f9535:	cmova  %rdi,%r10
 29f9539:	mov    (%r10),%r13d
 29f953c:	test   %r9d,%r9d
 29f953f:	je     29fc851 <wasm[0]::function[1015]::helper::object_read+0x1b8d1>
 29f9545:	test   %r9d,%r9d
 29f9548:	je     29fc853 <wasm[0]::function[1015]::helper::object_read+0x1b8d3>
 29f954e:	mov    %r9d,%r9d
 29f9551:	lea    0x10(%rsi,%r9,1),%rsi
 29f9556:	cmp    %rax,%r9
 29f9559:	cmova  %rdi,%rsi
 29f955d:	mov    (%rsi),%eax
 29f955f:	mov    0x88(%rsp),%edi
 29f9566:	cmp    %ecx,%r8d
 29f9569:	sete   %cl
 29f956c:	cmp    %eax,%r13d
 29f956f:	sete   %sil
 29f9573:	mov    %rcx,%rax
 29f9576:	and    %esi,%eax
 29f9578:	movzbl %al,%eax
 29f957b:	mov    %rax,%r14
 29f957e:	test   %cl,%sil
 29f9581:	jne    29f958f <wasm[0]::function[1015]::helper::object_read+0x1860f>
 29f9587:	mov    %r14,%rax
 29f958a:	jmp    29f989a <wasm[0]::function[1015]::helper::object_read+0x1891a>
 29f958f:	mov    0x88(%rsp),%ecx
 29f9596:	mov    0x78(%rsp),%edx
 29f959a:	xor    %ebx,%ebx
 29f959c:	mov    %ecx,0x98(%rsp)
 29f95a3:	mov    %edx,0x90(%rsp)
 29f95aa:	mov    0x2e8(%rsp),%rax
 29f95b2:	mov    (%rax),%rcx
 29f95b5:	mov    0x228(%rsp),%rax
 29f95bd:	cmp    %rax,%rcx
 29f95c0:	jae    29fbaa9 <wasm[0]::function[1015]::helper::object_read+0x1ab29>
 29f95c6:	jmp    29f95d3 <wasm[0]::function[1015]::helper::object_read+0x18653>
 29f95cb:	mov    %rdx,0x228(%rsp)
 29f95d3:	cmp    %r13d,%ebx
 29f95d6:	jb     29f95e4 <wasm[0]::function[1015]::helper::object_read+0x18664>
 29f95dc:	mov    %r14,%rax
 29f95df:	jmp    29f971d <wasm[0]::function[1015]::helper::object_read+0x1879d>
 29f95e4:	mov    0xa0(%rsp),%esi
 29f95eb:	test   %esi,%esi
 29f95ed:	je     29fc855 <wasm[0]::function[1015]::helper::object_read+0x1b8d5>
 29f95f3:	test   %esi,%esi
 29f95f5:	je     29fc857 <wasm[0]::function[1015]::helper::object_read+0x1b8d7>
 29f95fb:	mov    0x2e0(%rsp),%r12
 29f9603:	mov    0x28(%r12),%rax
 29f9608:	mov    0x20(%r12),%rcx
 29f960d:	mov    %esi,%r8d
 29f9610:	lea    0x10(%rcx,%r8,1),%rdi
 29f9615:	xor    %rdx,%rdx
 29f9618:	cmp    %rax,%r8
 29f961b:	cmova  %rdx,%rdi
 29f961f:	mov    (%rdi),%r8d
 29f9622:	cmp    %r8d,%ebx
 29f9625:	jae    29fc859 <wasm[0]::function[1015]::helper::object_read+0x1b8d9>
 29f962b:	mov    %r8d,%edi
 29f962e:	shl    $0x3,%rdi
 29f9632:	shr    $0x20,%rdi
 29f9636:	test   %rdi,%rdi
 29f9639:	jne    29fc85b <wasm[0]::function[1015]::helper::object_read+0x1b8db>
 29f963f:	shl    $0x3,%r8d
 29f9643:	add    $0x18,%r8d
 29f9647:	jb     29fc85d <wasm[0]::function[1015]::helper::object_read+0x1b8dd>
 29f964d:	add    %r8d,%esi
 29f9650:	jb     29fc85f <wasm[0]::function[1015]::helper::object_read+0x1b8df>
 29f9656:	mov    %esi,%edi
 29f9658:	lea    (%rcx,%rdi,1),%rsi
 29f965c:	cmp    %rax,%rdi
 29f965f:	cmova  %rdx,%rsi
 29f9663:	mov    %rbx,%rdi
 29f9666:	shl    $0x3,%edi
 29f9669:	add    $0x18,%edi
 29f966f:	sub    %edi,%r8d
 29f9672:	sub    %r8,%rsi
 29f9675:	mov    (%rsi),%rsi
 29f9678:	mov    0xa8(%rsp),%r8d
 29f9680:	test   %r8d,%r8d
 29f9683:	je     29fc861 <wasm[0]::function[1015]::helper::object_read+0x1b8e1>
 29f9689:	test   %r8d,%r8d
 29f968c:	je     29fc863 <wasm[0]::function[1015]::helper::object_read+0x1b8e3>
 29f9692:	mov    %r8d,%r10d
 29f9695:	lea    0x10(%rcx,%r10,1),%r9
 29f969a:	cmp    %rax,%r10
 29f969d:	cmova  %rdx,%r9
 29f96a1:	mov    (%r9),%r9d
 29f96a4:	cmp    %r9d,%ebx
 29f96a7:	jae    29fc865 <wasm[0]::function[1015]::helper::object_read+0x1b8e5>
 29f96ad:	mov    %r9d,%r10d
 29f96b0:	shl    $0x3,%r10
 29f96b4:	shr    $0x20,%r10
 29f96b8:	test   %r10,%r10
 29f96bb:	jne    29fc867 <wasm[0]::function[1015]::helper::object_read+0x1b8e7>
 29f96c1:	shl    $0x3,%r9d
 29f96c5:	add    $0x18,%r9d
 29f96c9:	jb     29fc869 <wasm[0]::function[1015]::helper::object_read+0x1b8e9>
 29f96cf:	add    %r9d,%r8d
 29f96d2:	jb     29fc86b <wasm[0]::function[1015]::helper::object_read+0x1b8eb>
 29f96d8:	mov    %r8d,%r8d
 29f96db:	lea    (%rcx,%r8,1),%r10
 29f96df:	cmp    %rax,%r8
 29f96e2:	cmova  %rdx,%r10
 29f96e6:	sub    %edi,%r9d
 29f96e9:	sub    %r9,%r10
 29f96ec:	mov    (%r10),%rcx
 29f96ef:	cmp    %rcx,%rsi
 29f96f2:	sete   %al
 29f96f5:	movzbl %al,%eax
 29f96f8:	cmp    %rcx,%rsi
 29f96fb:	jne    29f971d <wasm[0]::function[1015]::helper::object_read+0x1879d>
 29f9701:	mov    0x98(%rsp),%ecx
 29f9708:	mov    0x90(%rsp),%edx
 29f970f:	add    $0x1,%ebx
 29f9715:	mov    %rax,%r14
 29f9718:	jmp    29f959c <wasm[0]::function[1015]::helper::object_read+0x1861c>
 29f971d:	mov    0x98(%rsp),%edi
 29f9724:	mov    0x90(%rsp),%edx
 29f972b:	jmp    29f989a <wasm[0]::function[1015]::helper::object_read+0x1891a>
 29f9730:	mov    0x78(%rsp),%eax
 29f9734:	cmp    %ecx,%eax
 29f9736:	je     29f9833 <wasm[0]::function[1015]::helper::object_read+0x188b3>
 29f973c:	mov    0x78(%rsp),%edx
 29f9740:	xor    %eax,%eax
 29f9742:	test   %edx,%edx
 29f9744:	je     29f979d <wasm[0]::function[1015]::helper::object_read+0x1881d>
 29f974a:	mov    0x78(%rsp),%edx
 29f974e:	xor    %eax,%eax
 29f9750:	test   $0x1,%edx
 29f9756:	jne    29f979d <wasm[0]::function[1015]::helper::object_read+0x1881d>
 29f975c:	mov    0x78(%rsp),%edx
 29f9760:	mov    0x2e0(%rsp),%r12
 29f9768:	mov    0x28(%r12),%rax
 29f976d:	mov    0x20(%r12),%rdi
 29f9772:	mov    %edx,%esi
 29f9774:	lea    0x4(%rdi,%rsi,1),%rdx
 29f9779:	xor    %rdi,%rdi
 29f977c:	cmp    %rax,%rsi
 29f977f:	cmova  %rdi,%rdx
 29f9783:	mov    (%rdx),%eax
 29f9785:	mov    0x190(%rsp),%rsi
 29f978d:	mov    0x28(%rsi),%rdx
 29f9791:	cmp    0x234(%rdx),%eax
 29f9797:	sete   %al
 29f979a:	movzbl %al,%eax
 29f979d:	test   %eax,%eax
 29f979f:	je     29fc86d <wasm[0]::function[1015]::helper::object_read+0x1b8ed>
 29f97a5:	xor    %eax,%eax
 29f97a7:	test   %ecx,%ecx
 29f97a9:	je     29f97fa <wasm[0]::function[1015]::helper::object_read+0x1887a>
 29f97af:	xor    %eax,%eax
 29f97b1:	test   $0x1,%ecx
 29f97b7:	jne    29f97fa <wasm[0]::function[1015]::helper::object_read+0x1887a>
 29f97bd:	mov    0x2e0(%rsp),%r12
 29f97c5:	mov    0x28(%r12),%rax
 29f97ca:	mov    0x20(%r12),%rdx
 29f97cf:	mov    %ecx,%esi
 29f97d1:	lea    0x4(%rdx,%rsi,1),%rdx
 29f97d6:	xor    %rdi,%rdi
 29f97d9:	cmp    %rax,%rsi
 29f97dc:	cmova  %rdi,%rdx
 29f97e0:	mov    (%rdx),%eax
 29f97e2:	mov    0x190(%rsp),%rsi
 29f97ea:	mov    0x28(%rsi),%rdx
 29f97ee:	cmp    0x234(%rdx),%eax
 29f97f4:	sete   %al
 29f97f7:	movzbl %al,%eax
 29f97fa:	test   %eax,%eax
 29f97fc:	je     29fc86f <wasm[0]::function[1015]::helper::object_read+0x1b8ef>
 29f9802:	mov    0x78(%rsp),%edx
 29f9806:	xor    %r8d,%r8d
 29f9809:	test   %edx,%edx
 29f980b:	je     29fc871 <wasm[0]::function[1015]::helper::object_read+0x1b8f1>
 29f9811:	test   %ecx,%ecx
 29f9813:	je     29fc873 <wasm[0]::function[1015]::helper::object_read+0x1b8f3>
 29f9819:	mov    0x190(%rsp),%rsi
 29f9821:	mov    0x190(%rsp),%rdi
 29f9829:	call   2ae5540 <wasm[0]::function[1057]::helper::string_equality>
 29f982e:	jmp    29f983b <wasm[0]::function[1015]::helper::object_read+0x188bb>
 29f9833:	mov    0x278(%rsp),%rax
 29f983b:	mov    0x88(%rsp),%edi
 29f9842:	mov    0x78(%rsp),%edx
 29f9846:	jmp    29f989a <wasm[0]::function[1015]::helper::object_read+0x1891a>
 29f984b:	mov    0x88(%rsp),%edi
 29f9852:	mov    0x78(%rsp),%edx
 29f9856:	mov    0x288(%rsp),%rcx
 29f985e:	cmp    %rax,%rcx
 29f9861:	sete   %cl
 29f9864:	mov    0x288(%rsp),%rsi
 29f986c:	movq   %rsi,%xmm0
 29f9871:	ucomisd %xmm0,%xmm0
 29f9875:	setp   %sil
 29f9879:	setne  %r8b
 29f987d:	or     %r8d,%esi
 29f9880:	movq   %rax,%xmm0
 29f9885:	ucomisd %xmm0,%xmm0
 29f9889:	setp   %al
 29f988c:	setne  %r8b
 29f9890:	or     %r8d,%eax
 29f9893:	and    %eax,%esi
 29f9895:	or     %esi,%ecx
 29f9897:	movzbl %cl,%eax
 29f989a:	xor    %esi,%esi
 29f989c:	test   %eax,%eax
 29f989e:	je     29f98b1 <wasm[0]::function[1015]::helper::object_read+0x18931>
 29f98a4:	mov    %rsi,0x298(%rsp)
 29f98ac:	jmp    29f9e7f <wasm[0]::function[1015]::helper::object_read+0x18eff>
 29f98b1:	xor    %edx,%edx
 29f98b3:	mov    %edi,0x90(%rsp)
 29f98ba:	mov    %edx,0x98(%rsp)
 29f98c1:	mov    0x2e8(%rsp),%r13
 29f98c9:	mov    0x0(%r13),%rcx
 29f98cd:	mov    0x228(%rsp),%rax
 29f98d5:	cmp    %rax,%rcx
 29f98d8:	jae    29fbad9 <wasm[0]::function[1015]::helper::object_read+0x1ab59>
 29f98de:	jmp    29f98eb <wasm[0]::function[1015]::helper::object_read+0x1896b>
 29f98e3:	mov    %rsi,0x228(%rsp)
 29f98eb:	mov    0x90(%rsp),%r8d
 29f98f3:	mov    0x98(%rsp),%edx
 29f98fa:	test   %r8d,%r8d
 29f98fd:	je     29f997b <wasm[0]::function[1015]::helper::object_read+0x189fb>
 29f9903:	mov    0x90(%rsp),%r11d
 29f990b:	test   %r11d,%r11d
 29f990e:	je     29fc875 <wasm[0]::function[1015]::helper::object_read+0x1b8f5>
 29f9914:	mov    0x2e0(%rsp),%r12
 29f991c:	mov    0x28(%r12),%rax
 29f9921:	mov    0x20(%r12),%rdx
 29f9926:	mov    %r11d,%ecx
 29f9929:	lea    (%rdx,%rcx,1),%r10
 29f992d:	xor    %rdx,%rdx
 29f9930:	cmp    %rax,%rcx
 29f9933:	cmova  %rdx,%r10
 29f9937:	mov    0x10(%r10),%edx
 29f993b:	test   %edx,%edx
 29f993d:	jne    29f997b <wasm[0]::function[1015]::helper::object_read+0x189fb>
 29f9943:	mov    0x90(%rsp),%ecx
 29f994a:	test   %ecx,%ecx
 29f994c:	je     29fc877 <wasm[0]::function[1015]::helper::object_read+0x1b8f7>
 29f9952:	mov    0x2e0(%rsp),%r12
 29f995a:	mov    0x28(%r12),%rax
 29f995f:	mov    %ecx,%esi
 29f9961:	mov    %rsi,%rcx
 29f9964:	add    0x20(%r12),%rcx
 29f9969:	xor    %rdi,%rdi
 29f996c:	cmp    %rax,%rsi
 29f996f:	cmova  %rdi,%rcx
 29f9973:	mov    0x1c(%rcx),%edi
 29f9976:	jmp    29f98b3 <wasm[0]::function[1015]::helper::object_read+0x18933>
 29f997b:	test   %edx,%edx
 29f997d:	jne    29f9999 <wasm[0]::function[1015]::helper::object_read+0x18a19>
 29f9983:	mov    0x190(%rsp),%rsi
 29f998b:	mov    0x8c0(%rsi),%edx
 29f9991:	test   %edx,%edx
 29f9993:	je     29fc879 <wasm[0]::function[1015]::helper::object_read+0x1b8f9>
 29f9999:	mov    %edx,0x90(%rsp)
 29f99a0:	test   %edx,%edx
 29f99a2:	je     29fc87b <wasm[0]::function[1015]::helper::object_read+0x1b8fb>
 29f99a8:	mov    0x190(%rsp),%rsi
 29f99b0:	mov    0x190(%rsp),%rdi
 29f99b8:	call   2ac60a0 <wasm[0]::function[1049]::helper::realm_ensure_errors>
 29f99bd:	mov    0x90(%rsp),%edx
 29f99c4:	test   %edx,%edx
 29f99c6:	je     29fc87d <wasm[0]::function[1015]::helper::object_read+0x1b8fd>
 29f99cc:	test   %edx,%edx
 29f99ce:	je     29fc87f <wasm[0]::function[1015]::helper::object_read+0x1b8ff>
 29f99d4:	mov    0x2e0(%rsp),%r12
 29f99dc:	mov    0x28(%r12),%rax
 29f99e1:	mov    0x20(%r12),%rcx
 29f99e6:	mov    %edx,%edi
 29f99e8:	lea    (%rcx,%rdi,1),%rsi
 29f99ec:	xor    %rdx,%rdx
 29f99ef:	cmp    %rax,%rdi
 29f99f2:	cmova  %rdx,%rsi
 29f99f6:	mov    0x2c(%rsi),%esi
 29f99f9:	test   %esi,%esi
 29f99fb:	je     29fc881 <wasm[0]::function[1015]::helper::object_read+0x1b901>
 29f9a01:	test   %esi,%esi
 29f9a03:	je     29fc883 <wasm[0]::function[1015]::helper::object_read+0x1b903>
 29f9a09:	mov    %esi,%r8d
 29f9a0c:	lea    0x10(%rcx,%r8,1),%rdi
 29f9a11:	cmp    %rax,%r8
 29f9a14:	cmova  %rdx,%rdi
 29f9a18:	mov    (%rdi),%edi
 29f9a1a:	cmp    $0x3,%edi
 29f9a1d:	jbe    29fc885 <wasm[0]::function[1015]::helper::object_read+0x1b905>
 29f9a23:	mov    %edi,%r8d
 29f9a26:	shl    $0x2,%r8
 29f9a2a:	shr    $0x20,%r8
 29f9a2e:	test   %r8,%r8
 29f9a31:	jne    29fc887 <wasm[0]::function[1015]::helper::object_read+0x1b907>
 29f9a37:	shl    $0x2,%edi
 29f9a3a:	add    $0x14,%edi
 29f9a3d:	jb     29fc889 <wasm[0]::function[1015]::helper::object_read+0x1b909>
 29f9a43:	add    %edi,%esi
 29f9a45:	jb     29fc88b <wasm[0]::function[1015]::helper::object_read+0x1b90b>
 29f9a4b:	mov    %esi,%r8d
 29f9a4e:	lea    (%rcx,%r8,1),%rsi
 29f9a52:	cmp    %rax,%r8
 29f9a55:	cmova  %rdx,%rsi
 29f9a59:	sub    $0x20,%edi
 29f9a5c:	sub    %rdi,%rsi
 29f9a5f:	mov    (%rsi),%esi
 29f9a61:	test   %esi,%esi
 29f9a63:	je     29fc88d <wasm[0]::function[1015]::helper::object_read+0x1b90d>
 29f9a69:	test   %esi,%esi
 29f9a6b:	je     29fc88f <wasm[0]::function[1015]::helper::object_read+0x1b90f>
 29f9a71:	mov    %esi,%esi
 29f9a73:	add    %rsi,%rcx
 29f9a76:	cmp    %rax,%rsi
 29f9a79:	cmova  %rdx,%rcx
 29f9a7d:	mov    0x18(%rcx),%r12d
 29f9a81:	mov    0x10(%rcx),%rbx
 29f9a85:	mov    0x1c(%rcx),%eax
 29f9a88:	mov    %eax,0x90(%rsp)
 29f9a8f:	mov    $0x6,%eax
 29f9a94:	mov    %rax,0x280(%rsp)
 29f9a9c:	cmp    $0x6,%r12d
 29f9aa0:	sete   %cl
 29f9aa3:	cmp    $0x7,%r12d
 29f9aa7:	sete   %al
 29f9aaa:	or     %eax,%ecx
 29f9aac:	cmp    $0x8,%r12d
 29f9ab0:	sete   %al
 29f9ab3:	or     %eax,%ecx
 29f9ab5:	cmp    $0x9,%r12d
 29f9ab9:	sete   %al
 29f9abc:	or     %eax,%ecx
 29f9abe:	movzbl %cl,%eax
 29f9ac1:	test   %eax,%eax
 29f9ac3:	je     29fc891 <wasm[0]::function[1015]::helper::object_read+0x1b911>
 29f9ac9:	mov    $0x998,%edx
 29f9ace:	mov    0x190(%rsp),%rsi
 29f9ad6:	mov    0x190(%rsp),%rdi
 29f9ade:	call   2f30600 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 29f9ae3:	xor    %edi,%edi
 29f9ae5:	mov    %rdi,0x298(%rsp)
 29f9aed:	test   %eax,%eax
 29f9aef:	je     29fc893 <wasm[0]::function[1015]::helper::object_read+0x1b913>
 29f9af5:	mov    0x90(%rsp),%r9d
 29f9afd:	mov    $0x5,%edx
 29f9b02:	mov    %eax,(%rsp)
 29f9b05:	mov    %r12,%rcx
 29f9b08:	mov    0x190(%rsp),%rsi
 29f9b10:	mov    %rbx,%r8
 29f9b13:	mov    %rsi,%rdi
 29f9b16:	call   2f30360 <wasm[0]::function[1101]::helper::runtime_error_for_throw>
 29f9b1b:	sub    $0x10,%rsp
 29f9b1f:	test   %eax,%eax
 29f9b21:	je     29fc895 <wasm[0]::function[1015]::helper::object_read+0x1b915>
 29f9b27:	mov    %rcx,%rdx
 29f9b2a:	mov    %rcx,0x288(%rsp)
 29f9b32:	xor    %rdx,%rcx
 29f9b35:	mov    %rcx,0x288(%rsp)
 29f9b3d:	mov    %rax,%rdx
 29f9b40:	mov    0x278(%rsp),%rsi
 29f9b48:	jmp    29f9e7f <wasm[0]::function[1015]::helper::object_read+0x18eff>
 29f9b4d:	xor    %eax,%eax
 29f9b4f:	mov    %r15,%rcx
 29f9b52:	mov    %r15,%rdx
 29f9b55:	test   %edx,%ecx
 29f9b57:	je     29f9bbb <wasm[0]::function[1015]::helper::object_read+0x18c3b>
 29f9b5d:	mov    %r15,%rax
 29f9b60:	mov    %r15,%rcx
 29f9b63:	test   %ecx,%eax
 29f9b65:	je     29fc897 <wasm[0]::function[1015]::helper::object_read+0x1b917>
 29f9b6b:	mov    0x2e0(%rsp),%r12
 29f9b73:	mov    0x28(%r12),%r11
 29f9b78:	mov    0x20(%r12),%rax
 29f9b7d:	mov    %r15,%rdx
 29f9b80:	mov    %edx,%edx
 29f9b82:	lea    (%rax,%rdx,1),%r8
 29f9b86:	xor    %rcx,%rcx
 29f9b89:	cmp    %r11,%rdx
 29f9b8c:	cmova  %rcx,%r8
 29f9b90:	mov    0x18(%r8),%edx
 29f9b94:	test   %edx,%edx
 29f9b96:	je     29fc899 <wasm[0]::function[1015]::helper::object_read+0x1b919>
 29f9b9c:	test   %edx,%edx
 29f9b9e:	je     29fc89b <wasm[0]::function[1015]::helper::object_read+0x1b91b>
 29f9ba4:	mov    %edx,%esi
 29f9ba6:	lea    (%rax,%rsi,1),%rdx
 29f9baa:	cmp    %r11,%rsi
 29f9bad:	cmova  %rcx,%rdx
 29f9bb1:	mov    0x18(%rdx),%eax
 29f9bb4:	mov    0x10(%rdx),%rcx
 29f9bb8:	mov    0x1c(%rdx),%ecx
 29f9bbb:	mov    0x78(%rsp),%edx
 29f9bbf:	xor    %esi,%esi
 29f9bc1:	test   %eax,%eax
 29f9bc3:	sete   %al
 29f9bc6:	mov    0x280(%rsp),%rcx
 29f9bce:	mov    0x280(%rsp),%rdi
 29f9bd6:	test   %edi,%ecx
 29f9bd8:	setne  %cl
 29f9bdb:	test   %al,%cl
 29f9bdd:	jne    29f9bf0 <wasm[0]::function[1015]::helper::object_read+0x18c70>
 29f9be3:	mov    %rsi,0x298(%rsp)
 29f9beb:	jmp    29f9e7f <wasm[0]::function[1015]::helper::object_read+0x18eff>
 29f9bf0:	mov    0x88(%rsp),%eax
 29f9bf7:	xor    %edx,%edx
 29f9bf9:	mov    %eax,0x78(%rsp)
 29f9bfd:	mov    %edx,0x88(%rsp)
 29f9c04:	mov    0x2e8(%rsp),%r13
 29f9c0c:	mov    0x0(%r13),%rax
 29f9c10:	mov    0x228(%rsp),%rcx
 29f9c18:	cmp    %rcx,%rax
 29f9c1b:	jae    29fbb09 <wasm[0]::function[1015]::helper::object_read+0x1ab89>
 29f9c21:	jmp    29f9c2e <wasm[0]::function[1015]::helper::object_read+0x18cae>
 29f9c26:	mov    %rcx,0x228(%rsp)
 29f9c2e:	mov    0x78(%rsp),%eax
 29f9c32:	mov    0x88(%rsp),%edx
 29f9c39:	test   %eax,%eax
 29f9c3b:	je     29f9caf <wasm[0]::function[1015]::helper::object_read+0x18d2f>
 29f9c41:	mov    0x78(%rsp),%ecx
 29f9c45:	test   %ecx,%ecx
 29f9c47:	je     29fc89d <wasm[0]::function[1015]::helper::object_read+0x1b91d>
 29f9c4d:	mov    0x2e0(%rsp),%r12
 29f9c55:	mov    0x28(%r12),%rax
 29f9c5a:	mov    0x20(%r12),%rsi
 29f9c5f:	mov    %ecx,%edx
 29f9c61:	lea    (%rsi,%rdx,1),%rcx
 29f9c65:	xor    %rsi,%rsi
 29f9c68:	cmp    %rax,%rdx
 29f9c6b:	cmova  %rsi,%rcx
 29f9c6f:	mov    0x10(%rcx),%edx
 29f9c72:	test   %edx,%edx
 29f9c74:	jne    29f9caf <wasm[0]::function[1015]::helper::object_read+0x18d2f>
 29f9c7a:	mov    0x78(%rsp),%ecx
 29f9c7e:	test   %ecx,%ecx
 29f9c80:	je     29fc89f <wasm[0]::function[1015]::helper::object_read+0x1b91f>
 29f9c86:	mov    0x2e0(%rsp),%r12
 29f9c8e:	mov    0x28(%r12),%rax
 29f9c93:	mov    %ecx,%esi
 29f9c95:	mov    %rsi,%rcx
 29f9c98:	add    0x20(%r12),%rcx
 29f9c9d:	xor    %rdi,%rdi
 29f9ca0:	cmp    %rax,%rsi
 29f9ca3:	cmova  %rdi,%rcx
 29f9ca7:	mov    0x1c(%rcx),%eax
 29f9caa:	jmp    29f9bf9 <wasm[0]::function[1015]::helper::object_read+0x18c79>
 29f9caf:	test   %edx,%edx
 29f9cb1:	jne    29f9ccd <wasm[0]::function[1015]::helper::object_read+0x18d4d>
 29f9cb7:	mov    0x190(%rsp),%rsi
 29f9cbf:	mov    0x8c0(%rsi),%edx
 29f9cc5:	test   %edx,%edx
 29f9cc7:	je     29fc8a1 <wasm[0]::function[1015]::helper::object_read+0x1b921>
 29f9ccd:	mov    %edx,0x78(%rsp)
 29f9cd1:	test   %edx,%edx
 29f9cd3:	je     29fc8a3 <wasm[0]::function[1015]::helper::object_read+0x1b923>
 29f9cd9:	mov    0x190(%rsp),%rsi
 29f9ce1:	mov    0x190(%rsp),%rdi
 29f9ce9:	call   2ac60a0 <wasm[0]::function[1049]::helper::realm_ensure_errors>
 29f9cee:	mov    0x78(%rsp),%edx
 29f9cf2:	test   %edx,%edx
 29f9cf4:	je     29fc8a5 <wasm[0]::function[1015]::helper::object_read+0x1b925>
 29f9cfa:	test   %edx,%edx
 29f9cfc:	je     29fc8a7 <wasm[0]::function[1015]::helper::object_read+0x1b927>
 29f9d02:	mov    0x2e0(%rsp),%r12
 29f9d0a:	mov    0x28(%r12),%rax
 29f9d0f:	mov    0x20(%r12),%rcx
 29f9d14:	mov    %edx,%edi
 29f9d16:	lea    (%rcx,%rdi,1),%rsi
 29f9d1a:	xor    %rdx,%rdx
 29f9d1d:	cmp    %rax,%rdi
 29f9d20:	cmova  %rdx,%rsi
 29f9d24:	mov    0x2c(%rsi),%esi
 29f9d27:	test   %esi,%esi
 29f9d29:	je     29fc8a9 <wasm[0]::function[1015]::helper::object_read+0x1b929>
 29f9d2f:	test   %esi,%esi
 29f9d31:	je     29fc8ab <wasm[0]::function[1015]::helper::object_read+0x1b92b>
 29f9d37:	mov    %esi,%r8d
 29f9d3a:	lea    0x10(%rcx,%r8,1),%rdi
 29f9d3f:	cmp    %rax,%r8
 29f9d42:	cmova  %rdx,%rdi
 29f9d46:	mov    (%rdi),%edi
 29f9d48:	cmp    $0x3,%edi
 29f9d4b:	jbe    29fc8ad <wasm[0]::function[1015]::helper::object_read+0x1b92d>
 29f9d51:	mov    %edi,%r8d
 29f9d54:	shl    $0x2,%r8
 29f9d58:	shr    $0x20,%r8
 29f9d5c:	test   %r8,%r8
 29f9d5f:	jne    29fc8af <wasm[0]::function[1015]::helper::object_read+0x1b92f>
 29f9d65:	shl    $0x2,%edi
 29f9d68:	add    $0x14,%edi
 29f9d6b:	jb     29fc8b1 <wasm[0]::function[1015]::helper::object_read+0x1b931>
 29f9d71:	add    %edi,%esi
 29f9d73:	jb     29fc8b3 <wasm[0]::function[1015]::helper::object_read+0x1b933>
 29f9d79:	mov    %esi,%r9d
 29f9d7c:	lea    (%rcx,%r9,1),%rsi
 29f9d80:	cmp    %rax,%r9
 29f9d83:	cmova  %rdx,%rsi
 29f9d87:	sub    $0x20,%edi
 29f9d8a:	sub    %rdi,%rsi
 29f9d8d:	mov    (%rsi),%r10d
 29f9d90:	test   %r10d,%r10d
 29f9d93:	je     29fc8b5 <wasm[0]::function[1015]::helper::object_read+0x1b935>
 29f9d99:	test   %r10d,%r10d
 29f9d9c:	je     29fc8b7 <wasm[0]::function[1015]::helper::object_read+0x1b937>
 29f9da2:	mov    %r10d,%esi
 29f9da5:	add    %rsi,%rcx
 29f9da8:	cmp    %rax,%rsi
 29f9dab:	cmova  %rdx,%rcx
 29f9daf:	mov    0x18(%rcx),%ebx
 29f9db2:	mov    0x10(%rcx),%r15
 29f9db6:	mov    0x1c(%rcx),%eax
 29f9db9:	mov    %eax,0x78(%rsp)
 29f9dbd:	mov    $0x6,%eax
 29f9dc2:	mov    %rax,0x280(%rsp)
 29f9dca:	cmp    $0x6,%ebx
 29f9dcd:	sete   %r11b
 29f9dd1:	cmp    $0x7,%ebx
 29f9dd4:	sete   %al
 29f9dd7:	or     %eax,%r11d
 29f9dda:	cmp    $0x8,%ebx
 29f9ddd:	sete   %al
 29f9de0:	or     %eax,%r11d
 29f9de3:	cmp    $0x9,%ebx
 29f9de6:	sete   %al
 29f9de9:	or     %eax,%r11d
 29f9dec:	movzbl %r11b,%eax
 29f9df0:	test   %eax,%eax
 29f9df2:	je     29fc8b9 <wasm[0]::function[1015]::helper::object_read+0x1b939>
 29f9df8:	mov    $0x999,%edx
 29f9dfd:	mov    0x190(%rsp),%rsi
 29f9e05:	mov    0x190(%rsp),%rdi
 29f9e0d:	call   2f30600 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 29f9e12:	mov    %rdi,%rcx
 29f9e15:	mov    %rdi,0x298(%rsp)
 29f9e1d:	xor    %ecx,%edi
 29f9e1f:	mov    %rdi,0x298(%rsp)
 29f9e27:	test   %eax,%eax
 29f9e29:	je     29fc8bb <wasm[0]::function[1015]::helper::object_read+0x1b93b>
 29f9e2f:	mov    0x78(%rsp),%r9d
 29f9e34:	mov    $0x5,%edx
 29f9e39:	mov    %eax,(%rsp)
 29f9e3c:	mov    %rbx,%rcx
 29f9e3f:	mov    0x190(%rsp),%rsi
 29f9e47:	mov    %r15,%r8
 29f9e4a:	mov    %rsi,%rdi
 29f9e4d:	call   2f30360 <wasm[0]::function[1101]::helper::runtime_error_for_throw>
 29f9e52:	sub    $0x10,%rsp
 29f9e56:	test   %eax,%eax
 29f9e58:	je     29fc8bd <wasm[0]::function[1015]::helper::object_read+0x1b93d>
 29f9e5e:	mov    %rcx,%rdx
 29f9e61:	mov    %rcx,0x288(%rsp)
 29f9e69:	xor    %rdx,%rcx
 29f9e6c:	mov    %rcx,0x288(%rsp)
 29f9e74:	mov    %rax,%rdx
 29f9e77:	mov    0x278(%rsp),%rsi
 29f9e7f:	mov    %rdx,%rax
 29f9e82:	jmp    29fa49a <wasm[0]::function[1015]::helper::object_read+0x1951a>
 29f9e87:	mov    %rdi,0x298(%rsp)
 29f9e8f:	mov    0x80(%rsp),%edx
 29f9e96:	mov    %rdx,%rax
 29f9e99:	jmp    29fa49a <wasm[0]::function[1015]::helper::object_read+0x1951a>
 29f9e9e:	mov    0x50(%rsp),%eax
 29f9ea2:	xor    %edx,%edx
 29f9ea4:	mov    %eax,0x78(%rsp)
 29f9ea8:	mov    %edx,0x80(%rsp)
 29f9eaf:	mov    0x2e8(%rsp),%r13
 29f9eb7:	mov    0x0(%r13),%rax
 29f9ebb:	mov    0x228(%rsp),%rdi
 29f9ec3:	cmp    %rdi,%rax
 29f9ec6:	jae    29fbb39 <wasm[0]::function[1015]::helper::object_read+0x1abb9>
 29f9ecc:	jmp    29f9ed9 <wasm[0]::function[1015]::helper::object_read+0x18f59>
 29f9ed1:	mov    %rcx,0x228(%rsp)
 29f9ed9:	mov    0x78(%rsp),%eax
 29f9edd:	mov    0x80(%rsp),%edx
 29f9ee4:	test   %eax,%eax
 29f9ee6:	je     29f9f5a <wasm[0]::function[1015]::helper::object_read+0x18fda>
 29f9eec:	mov    0x78(%rsp),%ecx
 29f9ef0:	test   %ecx,%ecx
 29f9ef2:	je     29fc8bf <wasm[0]::function[1015]::helper::object_read+0x1b93f>
 29f9ef8:	mov    0x2e0(%rsp),%r12
 29f9f00:	mov    0x28(%r12),%rax
 29f9f05:	mov    0x20(%r12),%rsi
 29f9f0a:	mov    %ecx,%edx
 29f9f0c:	lea    (%rsi,%rdx,1),%rcx
 29f9f10:	xor    %rsi,%rsi
 29f9f13:	cmp    %rax,%rdx
 29f9f16:	cmova  %rsi,%rcx
 29f9f1a:	mov    0x10(%rcx),%edx
 29f9f1d:	test   %edx,%edx
 29f9f1f:	jne    29f9f5a <wasm[0]::function[1015]::helper::object_read+0x18fda>
 29f9f25:	mov    0x78(%rsp),%ecx
 29f9f29:	test   %ecx,%ecx
 29f9f2b:	je     29fc8c1 <wasm[0]::function[1015]::helper::object_read+0x1b941>
 29f9f31:	mov    0x2e0(%rsp),%r12
 29f9f39:	mov    0x28(%r12),%rax
 29f9f3e:	mov    %ecx,%esi
 29f9f40:	mov    %rsi,%rcx
 29f9f43:	add    0x20(%r12),%rcx
 29f9f48:	xor    %rdi,%rdi
 29f9f4b:	cmp    %rax,%rsi
 29f9f4e:	cmova  %rdi,%rcx
 29f9f52:	mov    0x1c(%rcx),%eax
 29f9f55:	jmp    29f9ea4 <wasm[0]::function[1015]::helper::object_read+0x18f24>
 29f9f5a:	test   %edx,%edx
 29f9f5c:	jne    29f9f78 <wasm[0]::function[1015]::helper::object_read+0x18ff8>
 29f9f62:	mov    0x190(%rsp),%rsi
 29f9f6a:	mov    0x8c0(%rsi),%edx
 29f9f70:	test   %edx,%edx
 29f9f72:	je     29fc8c3 <wasm[0]::function[1015]::helper::object_read+0x1b943>
 29f9f78:	mov    %edx,0x78(%rsp)
 29f9f7c:	test   %edx,%edx
 29f9f7e:	je     29fc8c5 <wasm[0]::function[1015]::helper::object_read+0x1b945>
 29f9f84:	mov    0x190(%rsp),%rsi
 29f9f8c:	mov    0x190(%rsp),%rdi
 29f9f94:	call   2ac60a0 <wasm[0]::function[1049]::helper::realm_ensure_errors>
 29f9f99:	mov    0x78(%rsp),%esi
 29f9f9d:	test   %esi,%esi
 29f9f9f:	je     29fc8c7 <wasm[0]::function[1015]::helper::object_read+0x1b947>
 29f9fa5:	test   %esi,%esi
 29f9fa7:	je     29fc8c9 <wasm[0]::function[1015]::helper::object_read+0x1b949>
 29f9fad:	mov    0x2e0(%rsp),%r12
 29f9fb5:	mov    0x28(%r12),%rdi
 29f9fba:	mov    0x20(%r12),%r8
 29f9fbf:	mov    %esi,%r10d
 29f9fc2:	lea    (%r8,%r10,1),%rsi
 29f9fc6:	xor    %r9,%r9
 29f9fc9:	cmp    %rdi,%r10
 29f9fcc:	cmova  %r9,%rsi
 29f9fd0:	mov    0x2c(%rsi),%eax
 29f9fd3:	test   %eax,%eax
 29f9fd5:	je     29fc8cb <wasm[0]::function[1015]::helper::object_read+0x1b94b>
 29f9fdb:	test   %eax,%eax
 29f9fdd:	je     29fc8cd <wasm[0]::function[1015]::helper::object_read+0x1b94d>
 29f9fe3:	mov    %eax,%ecx
 29f9fe5:	lea    0x10(%r8,%rcx,1),%r11
 29f9fea:	cmp    %rdi,%rcx
 29f9fed:	cmova  %r9,%r11
 29f9ff1:	mov    (%r11),%esi
 29f9ff4:	cmp    $0x3,%esi
 29f9ff7:	jbe    29fc8cf <wasm[0]::function[1015]::helper::object_read+0x1b94f>
 29f9ffd:	mov    %esi,%ecx
 29f9fff:	shl    $0x2,%rcx
 29fa003:	shr    $0x20,%rcx
 29fa007:	test   %rcx,%rcx
 29fa00a:	jne    29fc8d1 <wasm[0]::function[1015]::helper::object_read+0x1b951>
 29fa010:	shl    $0x2,%esi
 29fa013:	add    $0x14,%esi
 29fa016:	jb     29fc8d3 <wasm[0]::function[1015]::helper::object_read+0x1b953>
 29fa01c:	add    %esi,%eax
 29fa01e:	jb     29fc8d5 <wasm[0]::function[1015]::helper::object_read+0x1b955>
 29fa024:	mov    %eax,%ecx
 29fa026:	lea    (%r8,%rcx,1),%rax
 29fa02a:	cmp    %rdi,%rcx
 29fa02d:	cmova  %r9,%rax
 29fa031:	sub    $0x20,%esi
 29fa034:	sub    %rsi,%rax
 29fa037:	mov    (%rax),%eax
 29fa039:	test   %eax,%eax
 29fa03b:	je     29fc8d7 <wasm[0]::function[1015]::helper::object_read+0x1b957>
 29fa041:	test   %eax,%eax
 29fa043:	je     29fc8d9 <wasm[0]::function[1015]::helper::object_read+0x1b959>
 29fa049:	mov    %eax,%ecx
 29fa04b:	lea    (%r8,%rcx,1),%rax
 29fa04f:	cmp    %rdi,%rcx
 29fa052:	cmova  %r9,%rax
 29fa056:	mov    0x18(%rax),%r12d
 29fa05a:	mov    0x10(%rax),%rbx
 29fa05e:	mov    0x1c(%rax),%eax
 29fa061:	mov    %eax,0x78(%rsp)
 29fa065:	mov    $0x6,%eax
 29fa06a:	mov    %rax,0x280(%rsp)
 29fa072:	cmp    $0x6,%r12d
 29fa076:	sete   %cl
 29fa079:	cmp    $0x7,%r12d
 29fa07d:	sete   %al
 29fa080:	or     %eax,%ecx
 29fa082:	cmp    $0x8,%r12d
 29fa086:	sete   %al
 29fa089:	or     %eax,%ecx
 29fa08b:	cmp    $0x9,%r12d
 29fa08f:	sete   %al
 29fa092:	or     %eax,%ecx
 29fa094:	movzbl %cl,%eax
 29fa097:	test   %eax,%eax
 29fa099:	je     29fc8db <wasm[0]::function[1015]::helper::object_read+0x1b95b>
 29fa09f:	mov    $0x997,%edx
 29fa0a4:	mov    0x190(%rsp),%rsi
 29fa0ac:	mov    0x190(%rsp),%rdi
 29fa0b4:	call   2f30600 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 29fa0b9:	mov    %rdi,%rcx
 29fa0bc:	mov    %rdi,0x298(%rsp)
 29fa0c4:	xor    %ecx,%edi
 29fa0c6:	mov    %rdi,0x298(%rsp)
 29fa0ce:	test   %eax,%eax
 29fa0d0:	je     29fc8dd <wasm[0]::function[1015]::helper::object_read+0x1b95d>
 29fa0d6:	mov    0x78(%rsp),%r9d
 29fa0db:	mov    $0x5,%edx
 29fa0e0:	mov    %eax,(%rsp)
 29fa0e3:	mov    %r12,%rcx
 29fa0e6:	mov    0x190(%rsp),%rsi
 29fa0ee:	mov    %rbx,%r8
 29fa0f1:	mov    %rsi,%rdi
 29fa0f4:	call   2f30360 <wasm[0]::function[1101]::helper::runtime_error_for_throw>
 29fa0f9:	sub    $0x10,%rsp
 29fa0fd:	test   %eax,%eax
 29fa0ff:	je     29fc8df <wasm[0]::function[1015]::helper::object_read+0x1b95f>
 29fa105:	mov    %rcx,%rdx
 29fa108:	mov    %rcx,0x288(%rsp)
 29fa110:	xor    %rdx,%rcx
 29fa113:	mov    %rcx,0x288(%rsp)
 29fa11b:	mov    0x278(%rsp),%rsi
 29fa123:	jmp    29fa49a <wasm[0]::function[1015]::helper::object_read+0x1951a>
 29fa128:	mov    0x2a8(%rsp),%rcx
 29fa130:	mov    0x2b0(%rsp),%rdx
 29fa138:	mov    0x1a8(%rsp),%r9
 29fa140:	mov    0x70(%rsp),%eax
 29fa144:	test   %eax,%eax
 29fa146:	je     29fc8e1 <wasm[0]::function[1015]::helper::object_read+0x1b961>
 29fa14c:	mov    0x58(%rsp),%r8d
 29fa151:	mov    0x60(%rsp),%r10d
 29fa156:	mov    0x68(%rsp),%esi
 29fa15a:	mov    0x50(%rsp),%edi
 29fa15e:	mov    %r12,(%rsp)
 29fa162:	mov    %r10d,0x8(%rsp)
 29fa167:	mov    0x1b8(%rsp),%r10
 29fa16f:	mov    %r10d,0x10(%rsp)
 29fa174:	mov    0x1c0(%rsp),%r10
 29fa17c:	mov    %r10,0x18(%rsp)
 29fa181:	mov    %esi,0x20(%rsp)
 29fa185:	mov    %edi,0x28(%rsp)
 29fa189:	mov    %eax,0x30(%rsp)
 29fa18d:	mov    0x190(%rsp),%rsi
 29fa195:	mov    %rsi,%rdi
 29fa198:	call   29e0f80 <wasm[0]::function[1015]::helper::object_read>
 29fa19d:	sub    $0x40,%rsp
 29fa1a1:	mov    %rdi,0x298(%rsp)
 29fa1a9:	mov    %rcx,0x288(%rsp)
 29fa1b1:	mov    %rax,0x280(%rsp)
 29fa1b9:	mov    %rdx,%rax
 29fa1bc:	jmp    29fa49a <wasm[0]::function[1015]::helper::object_read+0x1951a>
 29fa1c1:	mov    %rdi,0x298(%rsp)
 29fa1c9:	mov    %r15,%rcx
 29fa1cc:	mov    %rax,%r8
 29fa1cf:	mov    %rdx,%rax
 29fa1d2:	mov    %r8,%rdx
 29fa1d5:	mov    %rdx,0x280(%rsp)
 29fa1dd:	mov    %rcx,0x288(%rsp)
 29fa1e5:	jmp    29fa49a <wasm[0]::function[1015]::helper::object_read+0x1951a>
 29fa1ea:	mov    0x50(%rsp),%eax
 29fa1ee:	xor    %edx,%edx
 29fa1f0:	mov    %eax,0x48(%rsp)
 29fa1f4:	mov    %edx,0x50(%rsp)
 29fa1f8:	mov    0x2e8(%rsp),%r13
 29fa200:	mov    0x0(%r13),%rax
 29fa204:	mov    0x228(%rsp),%rcx
 29fa20c:	cmp    %rcx,%rax
 29fa20f:	jae    29fbb69 <wasm[0]::function[1015]::helper::object_read+0x1abe9>
 29fa215:	jmp    29fa222 <wasm[0]::function[1015]::helper::object_read+0x192a2>
 29fa21a:	mov    %rcx,0x228(%rsp)
 29fa222:	mov    0x48(%rsp),%eax
 29fa226:	mov    0x50(%rsp),%edx
 29fa22a:	test   %eax,%eax
 29fa22c:	je     29fa2a1 <wasm[0]::function[1015]::helper::object_read+0x19321>
 29fa232:	mov    0x48(%rsp),%ecx
 29fa236:	test   %ecx,%ecx
 29fa238:	je     29fc8e3 <wasm[0]::function[1015]::helper::object_read+0x1b963>
 29fa23e:	mov    0x2e0(%rsp),%r12
 29fa246:	mov    0x28(%r12),%rax
 29fa24b:	mov    0x20(%r12),%rsi
 29fa250:	mov    %ecx,%edx
 29fa252:	lea    (%rsi,%rdx,1),%rcx
 29fa256:	xor    %rsi,%rsi
 29fa259:	cmp    %rax,%rdx
 29fa25c:	cmova  %rsi,%rcx
 29fa260:	mov    0x10(%rcx),%edx
 29fa263:	test   %edx,%edx
 29fa265:	jne    29fa2a1 <wasm[0]::function[1015]::helper::object_read+0x19321>
 29fa26b:	mov    0x48(%rsp),%edi
 29fa26f:	test   %edi,%edi
 29fa271:	je     29fc8e5 <wasm[0]::function[1015]::helper::object_read+0x1b965>
 29fa277:	mov    0x2e0(%rsp),%r12
 29fa27f:	mov    0x28(%r12),%rsi
 29fa284:	mov    %edi,%r8d
 29fa287:	mov    %r8,%rdi
 29fa28a:	add    0x20(%r12),%rdi
 29fa28f:	xor    %r9,%r9
 29fa292:	cmp    %rsi,%r8
 29fa295:	cmova  %r9,%rdi
 29fa299:	mov    0x1c(%rdi),%eax
 29fa29c:	jmp    29fa1f0 <wasm[0]::function[1015]::helper::object_read+0x19270>
 29fa2a1:	test   %edx,%edx
 29fa2a3:	jne    29fa2bf <wasm[0]::function[1015]::helper::object_read+0x1933f>
 29fa2a9:	mov    0x190(%rsp),%rsi
 29fa2b1:	mov    0x8c0(%rsi),%edx
 29fa2b7:	test   %edx,%edx
 29fa2b9:	je     29fc8e7 <wasm[0]::function[1015]::helper::object_read+0x1b967>
 29fa2bf:	mov    %edx,0x48(%rsp)
 29fa2c3:	test   %edx,%edx
 29fa2c5:	je     29fc8e9 <wasm[0]::function[1015]::helper::object_read+0x1b969>
 29fa2cb:	mov    0x190(%rsp),%rsi
 29fa2d3:	mov    0x190(%rsp),%rdi
 29fa2db:	call   2ac60a0 <wasm[0]::function[1049]::helper::realm_ensure_errors>
 29fa2e0:	mov    0x48(%rsp),%edx
 29fa2e4:	test   %edx,%edx
 29fa2e6:	je     29fc8eb <wasm[0]::function[1015]::helper::object_read+0x1b96b>
 29fa2ec:	test   %edx,%edx
 29fa2ee:	je     29fc8ed <wasm[0]::function[1015]::helper::object_read+0x1b96d>
 29fa2f4:	mov    0x2e0(%rsp),%r12
 29fa2fc:	mov    0x28(%r12),%rax
 29fa301:	mov    0x20(%r12),%rcx
 29fa306:	mov    %edx,%edi
 29fa308:	lea    (%rcx,%rdi,1),%rsi
 29fa30c:	xor    %rdx,%rdx
 29fa30f:	cmp    %rax,%rdi
 29fa312:	cmova  %rdx,%rsi
 29fa316:	mov    0x2c(%rsi),%esi
 29fa319:	test   %esi,%esi
 29fa31b:	je     29fc8ef <wasm[0]::function[1015]::helper::object_read+0x1b96f>
 29fa321:	test   %esi,%esi
 29fa323:	je     29fc8f1 <wasm[0]::function[1015]::helper::object_read+0x1b971>
 29fa329:	mov    %esi,%r8d
 29fa32c:	lea    0x10(%rcx,%r8,1),%rdi
 29fa331:	cmp    %rax,%r8
 29fa334:	cmova  %rdx,%rdi
 29fa338:	mov    (%rdi),%edi
 29fa33a:	cmp    $0x3,%edi
 29fa33d:	jbe    29fc8f3 <wasm[0]::function[1015]::helper::object_read+0x1b973>
 29fa343:	mov    %edi,%r8d
 29fa346:	shl    $0x2,%r8
 29fa34a:	shr    $0x20,%r8
 29fa34e:	test   %r8,%r8
 29fa351:	jne    29fc8f5 <wasm[0]::function[1015]::helper::object_read+0x1b975>
 29fa357:	shl    $0x2,%edi
 29fa35a:	add    $0x14,%edi
 29fa35d:	jb     29fc8f7 <wasm[0]::function[1015]::helper::object_read+0x1b977>
 29fa363:	add    %edi,%esi
 29fa365:	jb     29fc8f9 <wasm[0]::function[1015]::helper::object_read+0x1b979>
 29fa36b:	mov    %esi,%r8d
 29fa36e:	lea    (%rcx,%r8,1),%rsi
 29fa372:	cmp    %rax,%r8
 29fa375:	cmova  %rdx,%rsi
 29fa379:	sub    $0x20,%edi
 29fa37c:	sub    %rdi,%rsi
 29fa37f:	mov    (%rsi),%esi
 29fa381:	test   %esi,%esi
 29fa383:	je     29fc8fb <wasm[0]::function[1015]::helper::object_read+0x1b97b>
 29fa389:	test   %esi,%esi
 29fa38b:	je     29fc8fd <wasm[0]::function[1015]::helper::object_read+0x1b97d>
 29fa391:	mov    %esi,%esi
 29fa393:	add    %rsi,%rcx
 29fa396:	cmp    %rax,%rsi
 29fa399:	cmova  %rdx,%rcx
 29fa39d:	mov    0x18(%rcx),%r12d
 29fa3a1:	mov    0x10(%rcx),%rbx
 29fa3a5:	mov    0x1c(%rcx),%eax
 29fa3a8:	mov    %eax,0x48(%rsp)
 29fa3ac:	mov    $0x6,%eax
 29fa3b1:	mov    %rax,0x280(%rsp)
 29fa3b9:	cmp    $0x6,%r12d
 29fa3bd:	sete   %cl
 29fa3c0:	cmp    $0x7,%r12d
 29fa3c4:	sete   %al
 29fa3c7:	or     %eax,%ecx
 29fa3c9:	cmp    $0x8,%r12d
 29fa3cd:	sete   %al
 29fa3d0:	or     %eax,%ecx
 29fa3d2:	cmp    $0x9,%r12d
 29fa3d6:	sete   %al
 29fa3d9:	or     %eax,%ecx
 29fa3db:	movzbl %cl,%eax
 29fa3de:	test   %eax,%eax
 29fa3e0:	je     29fc8ff <wasm[0]::function[1015]::helper::object_read+0x1b97f>
 29fa3e6:	mov    $0x9a6,%edx
 29fa3eb:	mov    0x190(%rsp),%rsi
 29fa3f3:	mov    0x190(%rsp),%rdi
 29fa3fb:	call   2f30600 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 29fa400:	mov    %rdi,%rcx
 29fa403:	mov    %rdi,0x298(%rsp)
 29fa40b:	xor    %ecx,%edi
 29fa40d:	mov    %rdi,0x298(%rsp)
 29fa415:	test   %eax,%eax
 29fa417:	je     29fc901 <wasm[0]::function[1015]::helper::object_read+0x1b981>
 29fa41d:	mov    0x48(%rsp),%r9d
 29fa422:	mov    $0x5,%edx
 29fa427:	mov    %eax,(%rsp)
 29fa42a:	mov    %r12,%rcx
 29fa42d:	mov    0x190(%rsp),%rsi
 29fa435:	mov    %rbx,%r8
 29fa438:	mov    %rsi,%rdi
 29fa43b:	call   2f30360 <wasm[0]::function[1101]::helper::runtime_error_for_throw>
 29fa440:	sub    $0x10,%rsp
 29fa444:	test   %eax,%eax
 29fa446:	je     29fc903 <wasm[0]::function[1015]::helper::object_read+0x1b983>
 29fa44c:	mov    %rcx,%rdx
 29fa44f:	mov    %rcx,0x288(%rsp)
 29fa457:	xor    %rdx,%rcx
 29fa45a:	mov    %rcx,0x288(%rsp)
 29fa462:	mov    0x278(%rsp),%rsi
 29fa46a:	jmp    29fa49a <wasm[0]::function[1015]::helper::object_read+0x1951a>
 29fa46f:	mov    0x2d8(%rsp),%rcx
 29fa477:	mov    %rdx,%rax
 29fa47a:	mov    0x2d0(%rsp),%rdx
 29fa482:	mov    %rdx,0x280(%rsp)
 29fa48a:	mov    %rcx,0x288(%rsp)
 29fa492:	mov    %rdi,0x298(%rsp)
 29fa49a:	mov    0x298(%rsp),%rdi
 29fa4a2:	mov    %rax,%rdx
 29fa4a5:	mov    0x288(%rsp),%rcx
 29fa4ad:	mov    0x280(%rsp),%rax
 29fa4b5:	mov    0x2f0(%rsp),%rbx
 29fa4bd:	mov    0x2f8(%rsp),%r12
 29fa4c5:	mov    0x300(%rsp),%r13
 29fa4cd:	mov    0x308(%rsp),%r14
 29fa4d5:	mov    0x310(%rsp),%r15
 29fa4dd:	add    $0x320,%rsp
 29fa4e4:	mov    %rbp,%rsp
 29fa4e7:	pop    %rbp
 29fa4e8:	ret    $0x40
 29fa4eb:	mov    0x190(%rsp),%rdi
 29fa4f3:	call   3018b79 <wasmtime_builtin_new_epoch>
 29fa4f8:	mov    %rax,0x228(%rsp)
 29fa500:	jmp    29e1089 <wasm[0]::function[1015]::helper::object_read+0x109>
 29fa505:	mov    0x2e0(%rsp),%r12
 29fa50d:	mov    0x8(%r12),%rax
 29fa512:	mov    %rax,0x228(%rsp)
 29fa51a:	cmp    %rax,%rdx
 29fa51d:	jb     29e1630 <wasm[0]::function[1015]::helper::object_read+0x6b0>
 29fa523:	mov    0x190(%rsp),%rdi
 29fa52b:	call   3018b79 <wasmtime_builtin_new_epoch>
 29fa530:	mov    %rax,0x228(%rsp)
 29fa538:	mov    0x240(%rsp),%r13
 29fa540:	jmp    29e1638 <wasm[0]::function[1015]::helper::object_read+0x6b8>
 29fa545:	mov    0x2e0(%rsp),%r12
 29fa54d:	mov    0x8(%r12),%rax
 29fa552:	mov    %rax,0x228(%rsp)
 29fa55a:	cmp    %rax,%rcx
 29fa55d:	jb     29e2463 <wasm[0]::function[1015]::helper::object_read+0x14e3>
 29fa563:	mov    0x190(%rsp),%rdi
 29fa56b:	call   3018b79 <wasmtime_builtin_new_epoch>
 29fa570:	mov    %rax,0x228(%rsp)
 29fa578:	jmp    29e2463 <wasm[0]::function[1015]::helper::object_read+0x14e3>
 29fa57d:	mov    0x2e0(%rsp),%r12
 29fa585:	mov    0x8(%r12),%rax
 29fa58a:	mov    %rax,0x228(%rsp)
 29fa592:	cmp    %rax,%rcx
 29fa595:	jb     29e32bb <wasm[0]::function[1015]::helper::object_read+0x233b>
 29fa59b:	mov    0x190(%rsp),%rdi
 29fa5a3:	call   3018b79 <wasmtime_builtin_new_epoch>
 29fa5a8:	mov    %rax,0x228(%rsp)
 29fa5b0:	jmp    29e32bb <wasm[0]::function[1015]::helper::object_read+0x233b>
 29fa5b5:	mov    0x2e0(%rsp),%r12
 29fa5bd:	mov    0x8(%r12),%rcx
 29fa5c2:	mov    %rcx,0x228(%rsp)
 29fa5ca:	cmp    %rcx,%rax
 29fa5cd:	jb     29e387f <wasm[0]::function[1015]::helper::object_read+0x28ff>
 29fa5d3:	mov    0x190(%rsp),%rdi
 29fa5db:	call   3018b79 <wasmtime_builtin_new_epoch>
 29fa5e0:	mov    %rax,0x228(%rsp)
 29fa5e8:	jmp    29e387f <wasm[0]::function[1015]::helper::object_read+0x28ff>
 29fa5ed:	mov    $0xa800000e,%esi
 29fa5f2:	mov    0x190(%rsp),%rdi
 29fa5fa:	mov    0x28(%rdi),%rax
 29fa5fe:	mov    0x194(%rax),%edx
 29fa604:	mov    $0x10,%r8d
 29fa60a:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
 29fa60f:	mov    %eax,%ecx
 29fa611:	mov    0x2e0(%rsp),%r12
 29fa619:	add    0x20(%r12),%rcx
 29fa61e:	jmp    29e411d <wasm[0]::function[1015]::helper::object_read+0x319d>
 29fa623:	mov    0x2e0(%rsp),%r12
 29fa62b:	mov    0x8(%r12),%rax
 29fa630:	mov    %rax,0x228(%rsp)
 29fa638:	cmp    %rax,%rcx
 29fa63b:	jb     29e4255 <wasm[0]::function[1015]::helper::object_read+0x32d5>
 29fa641:	mov    0x190(%rsp),%rdi
 29fa649:	call   3018b79 <wasmtime_builtin_new_epoch>
 29fa64e:	mov    %rax,0x228(%rsp)
 29fa656:	jmp    29e4255 <wasm[0]::function[1015]::helper::object_read+0x32d5>
 29fa65b:	mov    0x2e0(%rsp),%r12
 29fa663:	mov    0x8(%r12),%rax
 29fa668:	mov    %rax,0x228(%rsp)
 29fa670:	cmp    %rax,%r8
 29fa673:	jb     29e438b <wasm[0]::function[1015]::helper::object_read+0x340b>
 29fa679:	mov    0x190(%rsp),%rdi
 29fa681:	call   3018b79 <wasmtime_builtin_new_epoch>
 29fa686:	mov    %rax,0x228(%rsp)
 29fa68e:	mov    0x240(%rsp),%rcx
 29fa696:	jmp    29e4393 <wasm[0]::function[1015]::helper::object_read+0x3413>
 29fa69b:	mov    $0xb0000042,%esi
 29fa6a0:	mov    $0x20,%ecx
 29fa6a5:	mov    0x220(%rsp),%rdx
 29fa6ad:	mov    0x190(%rsp),%rdi
 29fa6b5:	mov    0x218(%rsp),%r8
 29fa6bd:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
 29fa6c2:	mov    %eax,%ecx
 29fa6c4:	mov    0x2e0(%rsp),%rdx
 29fa6cc:	add    0x20(%rdx),%rcx
 29fa6d0:	jmp    29e4539 <wasm[0]::function[1015]::helper::object_read+0x35b9>
 29fa6d5:	mov    $0xb0000072,%esi
 29fa6da:	mov    $0x20,%ecx
 29fa6df:	mov    0x1d8(%rsp),%r15
 29fa6e7:	mov    %r15,%rdx
 29fa6ea:	mov    0x190(%rsp),%rdi
 29fa6f2:	mov    0x218(%rsp),%r8
 29fa6fa:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
 29fa6ff:	mov    %eax,%edx
 29fa701:	mov    0x2e0(%rsp),%r12
 29fa709:	add    0x20(%r12),%rdx
 29fa70e:	jmp    29e45c4 <wasm[0]::function[1015]::helper::object_read+0x3644>
 29fa713:	mov    $0xa800000e,%esi
 29fa718:	mov    0x190(%rsp),%rax
 29fa720:	mov    0x28(%rax),%rax
 29fa724:	mov    0x194(%rax),%edx
 29fa72a:	mov    $0x10,%r8d
 29fa730:	mov    0x190(%rsp),%rdi
 29fa738:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
 29fa73d:	mov    %eax,%ecx
 29fa73f:	mov    0x2e0(%rsp),%rdx
 29fa747:	add    0x20(%rdx),%rcx
 29fa74b:	jmp    29e48e3 <wasm[0]::function[1015]::helper::object_read+0x3963>
 29fa750:	mov    0x2e0(%rsp),%r12
 29fa758:	mov    0x8(%r12),%rcx
 29fa75d:	mov    %rcx,0x228(%rsp)
 29fa765:	cmp    %rcx,%rax
 29fa768:	jb     29e4a01 <wasm[0]::function[1015]::helper::object_read+0x3a81>
 29fa76e:	mov    0x190(%rsp),%rdi
 29fa776:	call   3018b79 <wasmtime_builtin_new_epoch>
 29fa77b:	mov    %rax,0x228(%rsp)
 29fa783:	jmp    29e4a01 <wasm[0]::function[1015]::helper::object_read+0x3a81>
 29fa788:	mov    0x2e0(%rsp),%r12
 29fa790:	mov    0x8(%r12),%rdx
 29fa795:	mov    %rdx,%rsi
 29fa798:	mov    %rdx,0x228(%rsp)
 29fa7a0:	cmp    %rsi,%rax
 29fa7a3:	jb     29e4b23 <wasm[0]::function[1015]::helper::object_read+0x3ba3>
 29fa7a9:	mov    0x190(%rsp),%rdi
 29fa7b1:	call   3018b79 <wasmtime_builtin_new_epoch>
 29fa7b6:	mov    %rax,0x228(%rsp)
 29fa7be:	mov    0x1d8(%rsp),%rcx
 29fa7c6:	jmp    29e4b2b <wasm[0]::function[1015]::helper::object_read+0x3bab>
 29fa7cb:	mov    0x198(%rsp),%rcx
 29fa7d3:	mov    %rbx,%rdx
 29fa7d6:	mov    0x1a0(%rsp),%rsi
 29fa7de:	mov    0x190(%rsp),%rdi
 29fa7e6:	mov    0x2c8(%rsp),%r8
 29fa7ee:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
 29fa7f3:	mov    %eax,%edx
 29fa7f5:	mov    0x2e0(%rsp),%r12
 29fa7fd:	add    0x20(%r12),%rdx
 29fa802:	mov    0x1d0(%rsp),%rcx
 29fa80a:	jmp    29e4c4d <wasm[0]::function[1015]::helper::object_read+0x3ccd>
 29fa80f:	mov    0x2e0(%rsp),%r12
 29fa817:	mov    0x8(%r12),%rsi
 29fa81c:	mov    %rsi,0x228(%rsp)
 29fa824:	cmp    %rsi,%rax
 29fa827:	jb     29e4fd1 <wasm[0]::function[1015]::helper::object_read+0x4051>
 29fa82d:	mov    0x190(%rsp),%rdi
 29fa835:	call   3018b79 <wasmtime_builtin_new_epoch>
 29fa83a:	mov    %rax,0x228(%rsp)
 29fa842:	jmp    29e4fd1 <wasm[0]::function[1015]::helper::object_read+0x4051>
 29fa847:	mov    0x2e0(%rsp),%r12
 29fa84f:	mov    0x8(%r12),%rcx
 29fa854:	mov    %rcx,0x228(%rsp)
 29fa85c:	cmp    %rcx,%rax
 29fa85f:	jb     29e5c7b <wasm[0]::function[1015]::helper::object_read+0x4cfb>
 29fa865:	mov    0x190(%rsp),%rdi
 29fa86d:	call   3018b79 <wasmtime_builtin_new_epoch>
 29fa872:	mov    %rax,0x228(%rsp)
 29fa87a:	jmp    29e5c7b <wasm[0]::function[1015]::helper::object_read+0x4cfb>
 29fa87f:	mov    $0xb0000002,%esi
 29fa884:	mov    0x190(%rsp),%rcx
 29fa88c:	mov    0x28(%rcx),%rdi
 29fa890:	mov    0x1d0(%rdi),%edx
 29fa896:	mov    $0x40,%ecx
 29fa89b:	mov    $0x10,%r8d
 29fa8a1:	mov    0x190(%rsp),%rdi
 29fa8a9:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
 29fa8ae:	mov    %eax,%ebx
 29fa8b0:	mov    0x2e0(%rsp),%r12
 29fa8b8:	add    0x20(%r12),%rbx
 29fa8bd:	jmp    29e600b <wasm[0]::function[1015]::helper::object_read+0x508b>
 29fa8c2:	mov    $0xb0001ffa,%esi
 29fa8c7:	mov    0x190(%rsp),%rcx
 29fa8cf:	mov    0x28(%rcx),%rax
 29fa8d3:	mov    0x1e0(%rax),%edx
 29fa8d9:	mov    $0x40,%ecx
 29fa8de:	mov    $0x10,%r8d
 29fa8e4:	mov    0x190(%rsp),%rdi
 29fa8ec:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
 29fa8f1:	mov    %eax,%ebx
 29fa8f3:	mov    0x2e0(%rsp),%r12
 29fa8fb:	add    0x20(%r12),%rbx
 29fa900:	mov    %rax,%rdx
 29fa903:	jmp    29e612e <wasm[0]::function[1015]::helper::object_read+0x51ae>
 29fa908:	mov    $0xb00300fa,%esi
 29fa90d:	mov    0x190(%rsp),%rcx
 29fa915:	mov    0x28(%rcx),%rax
 29fa919:	mov    0x1d4(%rax),%edx
 29fa91f:	mov    $0x50,%ecx
 29fa924:	mov    $0x10,%r8d
 29fa92a:	mov    0x190(%rsp),%rdi
 29fa932:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
 29fa937:	mov    %eax,%ecx
 29fa939:	mov    0x2e0(%rsp),%r12
 29fa941:	add    0x20(%r12),%rcx
 29fa946:	jmp    29e6279 <wasm[0]::function[1015]::helper::object_read+0x52f9>
 29fa94b:	mov    $0xb0000042,%esi
 29fa950:	mov    0x190(%rsp),%rcx
 29fa958:	mov    0x28(%rcx),%rax
 29fa95c:	mov    0x120(%rax),%edx
 29fa962:	mov    $0x20,%ecx
 29fa967:	mov    $0x10,%r8d
 29fa96d:	mov    0x190(%rsp),%rdi
 29fa975:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
 29fa97a:	mov    %eax,%ecx
 29fa97c:	mov    0x2e0(%rsp),%r12
 29fa984:	add    0x20(%r12),%rcx
 29fa989:	jmp    29e63ad <wasm[0]::function[1015]::helper::object_read+0x542d>
 29fa98e:	mov    $0xb0000042,%esi
 29fa993:	mov    0x190(%rsp),%rcx
 29fa99b:	mov    0x28(%rcx),%rax
 29fa99f:	mov    0x120(%rax),%edx
 29fa9a5:	mov    $0x20,%ecx
 29fa9aa:	mov    $0x10,%r8d
 29fa9b0:	mov    0x190(%rsp),%rdi
 29fa9b8:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
 29fa9bd:	mov    %eax,%esi
 29fa9bf:	mov    0x2e0(%rsp),%r12
 29fa9c7:	add    0x20(%r12),%rsi
 29fa9cc:	jmp    29e6438 <wasm[0]::function[1015]::helper::object_read+0x54b8>
 29fa9d1:	mov    $0xa800000e,%esi
 29fa9d6:	mov    0x190(%rsp),%rcx
 29fa9de:	mov    0x28(%rcx),%rax
 29fa9e2:	mov    0x1b4(%rax),%edx
 29fa9e8:	mov    $0x1c,%ecx
 29fa9ed:	mov    $0x10,%r8d
 29fa9f3:	mov    0x190(%rsp),%rdi
 29fa9fb:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
 29faa00:	mov    %eax,%edx
 29faa02:	mov    0x2e0(%rsp),%r12
 29faa0a:	add    0x20(%r12),%rdx
 29faa0f:	jmp    29e64da <wasm[0]::function[1015]::helper::object_read+0x555a>
 29faa14:	mov    0x2e0(%rsp),%r12
 29faa1c:	mov    0x8(%r12),%rax
 29faa21:	mov    %rax,0x228(%rsp)
 29faa29:	cmp    %rax,%rcx
 29faa2c:	jb     29e6cc6 <wasm[0]::function[1015]::helper::object_read+0x5d46>
 29faa32:	mov    0x190(%rsp),%rdi
 29faa3a:	call   3018b79 <wasmtime_builtin_new_epoch>
 29faa3f:	mov    %rax,0x228(%rsp)
 29faa47:	jmp    29e6cc6 <wasm[0]::function[1015]::helper::object_read+0x5d46>
 29faa4c:	mov    0x2e0(%rsp),%r12
 29faa54:	mov    0x8(%r12),%rax
 29faa59:	mov    %rax,0x228(%rsp)
 29faa61:	cmp    %rax,%rcx
 29faa64:	jb     29e79d7 <wasm[0]::function[1015]::helper::object_read+0x6a57>
 29faa6a:	mov    0x190(%rsp),%rdi
 29faa72:	call   3018b79 <wasmtime_builtin_new_epoch>
 29faa77:	mov    %rax,0x228(%rsp)
 29faa7f:	jmp    29e79d7 <wasm[0]::function[1015]::helper::object_read+0x6a57>
 29faa84:	mov    0x2e0(%rsp),%r12
 29faa8c:	mov    0x8(%r12),%rsi
 29faa91:	mov    %rsi,0x228(%rsp)
 29faa99:	cmp    %rsi,%rax
 29faa9c:	jb     29e87c9 <wasm[0]::function[1015]::helper::object_read+0x7849>
 29faaa2:	mov    0x190(%rsp),%rdi
 29faaaa:	call   3018b79 <wasmtime_builtin_new_epoch>
 29faaaf:	mov    %rax,0x228(%rsp)
 29faab7:	jmp    29e87c9 <wasm[0]::function[1015]::helper::object_read+0x7849>
 29faabc:	mov    0x2e0(%rsp),%r12
 29faac4:	mov    0x8(%r12),%rax
 29faac9:	mov    %rax,0x228(%rsp)
 29faad1:	cmp    %rax,%rcx
 29faad4:	jb     29e95c4 <wasm[0]::function[1015]::helper::object_read+0x8644>
 29faada:	mov    0x190(%rsp),%rdi
 29faae2:	call   3018b79 <wasmtime_builtin_new_epoch>
 29faae7:	mov    %rax,0x228(%rsp)
 29faaef:	jmp    29e95c4 <wasm[0]::function[1015]::helper::object_read+0x8644>
 29faaf4:	mov    0x2e0(%rsp),%r12
 29faafc:	mov    0x8(%r12),%rax
 29fab01:	mov    %rax,0x228(%rsp)
 29fab09:	cmp    %rax,%rcx
 29fab0c:	jb     29ea455 <wasm[0]::function[1015]::helper::object_read+0x94d5>
 29fab12:	mov    0x190(%rsp),%rdi
 29fab1a:	call   3018b79 <wasmtime_builtin_new_epoch>
 29fab1f:	mov    %rax,0x228(%rsp)
 29fab27:	jmp    29ea455 <wasm[0]::function[1015]::helper::object_read+0x94d5>
 29fab2c:	mov    0x2e0(%rsp),%r12
 29fab34:	mov    0x8(%r12),%rax
 29fab39:	mov    %rax,0x228(%rsp)
 29fab41:	cmp    %rax,%rcx
 29fab44:	jb     29eb2ff <wasm[0]::function[1015]::helper::object_read+0xa37f>
 29fab4a:	mov    0x190(%rsp),%rdi
 29fab52:	call   3018b79 <wasmtime_builtin_new_epoch>
 29fab57:	mov    %rax,0x228(%rsp)
 29fab5f:	jmp    29eb2ff <wasm[0]::function[1015]::helper::object_read+0xa37f>
 29fab64:	mov    $0xb0000042,%esi
 29fab69:	mov    0x190(%rsp),%rcx
 29fab71:	mov    0x28(%rcx),%rax
 29fab75:	mov    0x120(%rax),%edx
 29fab7b:	mov    $0x20,%ecx
 29fab80:	mov    $0x10,%r8d
 29fab86:	mov    0x190(%rsp),%rdi
 29fab8e:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
 29fab93:	mov    %eax,%ecx
 29fab95:	mov    0x2e0(%rsp),%r12
 29fab9d:	add    0x20(%r12),%rcx
 29faba2:	jmp    29ec4c2 <wasm[0]::function[1015]::helper::object_read+0xb542>
 29faba7:	mov    $0xb0000042,%esi
 29fabac:	mov    0x190(%rsp),%rcx
 29fabb4:	mov    0x28(%rcx),%rdx
 29fabb8:	mov    0x120(%rdx),%edx
 29fabbe:	mov    $0x20,%ecx
 29fabc3:	mov    $0x10,%r8d
 29fabc9:	mov    0x190(%rsp),%rdi
 29fabd1:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
 29fabd6:	mov    %eax,%ecx
 29fabd8:	mov    0x2e0(%rsp),%r12
 29fabe0:	add    0x20(%r12),%rcx
 29fabe5:	jmp    29ec54e <wasm[0]::function[1015]::helper::object_read+0xb5ce>
 29fabea:	mov    $0xb0000042,%esi
 29fabef:	mov    0x190(%rsp),%rcx
 29fabf7:	mov    0x28(%rcx),%rax
 29fabfb:	mov    0x120(%rax),%edx
 29fac01:	mov    $0x20,%ecx
 29fac06:	mov    $0x10,%r8d
 29fac0c:	mov    0x190(%rsp),%rdi
 29fac14:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
 29fac19:	mov    %eax,%ecx
 29fac1b:	mov    0x2e0(%rsp),%r12
 29fac23:	add    0x20(%r12),%rcx
 29fac28:	jmp    29ec5db <wasm[0]::function[1015]::helper::object_read+0xb65b>
 29fac2d:	mov    $0xb0000072,%esi
 29fac32:	mov    0x190(%rsp),%rcx
 29fac3a:	mov    0x28(%rcx),%rax
 29fac3e:	mov    0x13c(%rax),%edx
 29fac44:	mov    $0x20,%ecx
 29fac49:	mov    $0x10,%r8d
 29fac4f:	mov    0x190(%rsp),%rdi
 29fac57:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
 29fac5c:	mov    %eax,%ecx
 29fac5e:	mov    0x2e0(%rsp),%r12
 29fac66:	add    0x20(%r12),%rcx
 29fac6b:	jmp    29ec6a4 <wasm[0]::function[1015]::helper::object_read+0xb724>
 29fac70:	mov    $0xb0000072,%esi
 29fac75:	mov    0x190(%rsp),%rcx
 29fac7d:	mov    0x28(%rcx),%rax
 29fac81:	mov    0x13c(%rax),%edx
 29fac87:	mov    $0x20,%ecx
 29fac8c:	mov    $0x10,%r8d
 29fac92:	mov    0x190(%rsp),%rdi
 29fac9a:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
 29fac9f:	mov    %eax,%ecx
 29faca1:	mov    0x2e0(%rsp),%r12
 29faca9:	add    0x20(%r12),%rcx
 29facae:	jmp    29ec77d <wasm[0]::function[1015]::helper::object_read+0xb7fd>
 29facb3:	mov    0x2e0(%rsp),%r12
 29facbb:	mov    0x8(%r12),%rdi
 29facc0:	mov    %rdi,%r9
 29facc3:	mov    %rdi,0x228(%rsp)
 29faccb:	cmp    %r9,%rax
 29facce:	jb     29ecb7d <wasm[0]::function[1015]::helper::object_read+0xbbfd>
 29facd4:	mov    0x190(%rsp),%rdi
 29facdc:	call   3018b79 <wasmtime_builtin_new_epoch>
 29face1:	mov    %rax,0x228(%rsp)
 29face9:	jmp    29ecb7d <wasm[0]::function[1015]::helper::object_read+0xbbfd>
 29facee:	mov    0x2e0(%rsp),%rax
 29facf6:	mov    0x8(%rax),%rax
 29facfa:	mov    %rax,0x228(%rsp)
 29fad02:	cmp    %rax,%rcx
 29fad05:	jb     29ed14c <wasm[0]::function[1015]::helper::object_read+0xc1cc>
 29fad0b:	mov    0x190(%rsp),%rdi
 29fad13:	call   3018b79 <wasmtime_builtin_new_epoch>
 29fad18:	mov    %rax,0x228(%rsp)
 29fad20:	jmp    29ed14c <wasm[0]::function[1015]::helper::object_read+0xc1cc>
 29fad25:	mov    $0xb0000042,%esi
 29fad2a:	mov    0x190(%rsp),%rcx
 29fad32:	mov    0x28(%rcx),%rax
 29fad36:	mov    0x120(%rax),%edx
 29fad3c:	mov    $0x20,%ecx
 29fad41:	mov    $0x10,%r8d
 29fad47:	mov    0x190(%rsp),%rdi
 29fad4f:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
 29fad54:	mov    %eax,%ecx
 29fad56:	mov    0x2e0(%rsp),%rdx
 29fad5e:	add    0x20(%rdx),%rcx
 29fad62:	jmp    29ed5b6 <wasm[0]::function[1015]::helper::object_read+0xc636>
 29fad67:	mov    $0xb0000072,%esi
 29fad6c:	mov    0x190(%rsp),%rcx
 29fad74:	mov    0x28(%rcx),%rcx
 29fad78:	mov    0x13c(%rcx),%edx
 29fad7e:	mov    $0x20,%ecx
 29fad83:	mov    $0x10,%r8d
 29fad89:	mov    0x190(%rsp),%rdi
 29fad91:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
 29fad96:	mov    %eax,%r9d
 29fad99:	mov    0x2e0(%rsp),%r12
 29fada1:	add    0x20(%r12),%r9
 29fada6:	jmp    29ed679 <wasm[0]::function[1015]::helper::object_read+0xc6f9>
 29fadab:	mov    $0xa800000e,%esi
 29fadb0:	mov    0x190(%rsp),%rax
 29fadb8:	mov    0x28(%rax),%r10
 29fadbc:	mov    0x194(%r10),%edx
 29fadc3:	mov    $0x10,%r8d
 29fadc9:	mov    0x190(%rsp),%rdi
 29fadd1:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
 29fadd6:	mov    %eax,%ecx
 29fadd8:	mov    0x2e0(%rsp),%r12
 29fade0:	add    0x20(%r12),%rcx
 29fade5:	jmp    29edc10 <wasm[0]::function[1015]::helper::object_read+0xcc90>
 29fadea:	mov    0x2e0(%rsp),%r12
 29fadf2:	mov    0x8(%r12),%rcx
 29fadf7:	mov    %rcx,0x228(%rsp)
 29fadff:	cmp    %rcx,%rax
 29fae02:	jb     29edd23 <wasm[0]::function[1015]::helper::object_read+0xcda3>
 29fae08:	mov    0x190(%rsp),%rdi
 29fae10:	call   3018b79 <wasmtime_builtin_new_epoch>
 29fae15:	mov    %rax,0x228(%rsp)
 29fae1d:	jmp    29edd23 <wasm[0]::function[1015]::helper::object_read+0xcda3>
 29fae22:	mov    0x2e0(%rsp),%r12
 29fae2a:	mov    0x8(%r12),%rcx
 29fae2f:	mov    %rcx,0x228(%rsp)
 29fae37:	cmp    %rcx,%rax
 29fae3a:	jb     29ede41 <wasm[0]::function[1015]::helper::object_read+0xcec1>
 29fae40:	mov    0x190(%rsp),%rdi
 29fae48:	call   3018b79 <wasmtime_builtin_new_epoch>
 29fae4d:	mov    %rax,0x228(%rsp)
 29fae55:	mov    0x208(%rsp),%rcx
 29fae5d:	jmp    29ede49 <wasm[0]::function[1015]::helper::object_read+0xcec9>
 29fae62:	mov    0x1e0(%rsp),%rcx
 29fae6a:	mov    0x1e8(%rsp),%rdx
 29fae72:	mov    0x1f0(%rsp),%rsi
 29fae7a:	mov    0x190(%rsp),%rdi
 29fae82:	mov    0x1d8(%rsp),%r8
 29fae8a:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
 29fae8f:	mov    %eax,%ecx
 29fae91:	mov    0x2e0(%rsp),%r8
 29fae99:	add    0x20(%r8),%rcx
 29fae9d:	mov    0x1f8(%rsp),%r13
 29faea5:	jmp    29edfdf <wasm[0]::function[1015]::helper::object_read+0xd05f>
 29faeaa:	mov    0x1e0(%rsp),%rcx
 29faeb2:	mov    %r14,%rdx
 29faeb5:	mov    0x1d0(%rsp),%rsi
 29faebd:	mov    0x190(%rsp),%rdi
 29faec5:	mov    0x1d8(%rsp),%r8
 29faecd:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
 29faed2:	mov    %eax,%ecx
 29faed4:	mov    0x2e0(%rsp),%r12
 29faedc:	add    0x20(%r12),%rcx
 29faee1:	jmp    29ee05e <wasm[0]::function[1015]::helper::object_read+0xd0de>
 29faee6:	mov    $0xa800000e,%esi
 29faeeb:	mov    0x190(%rsp),%rax
 29faef3:	mov    0x28(%rax),%rax
 29faef7:	mov    0x194(%rax),%edx
 29faefd:	mov    $0x10,%r8d
 29faf03:	mov    0x190(%rsp),%rdi
 29faf0b:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
 29faf10:	mov    %eax,%r8d
 29faf13:	mov    0x2e0(%rsp),%r12
 29faf1b:	add    0x20(%r12),%r8
 29faf20:	jmp    29ee31d <wasm[0]::function[1015]::helper::object_read+0xd39d>
 29faf25:	mov    0x2e0(%rsp),%r12
 29faf2d:	mov    0x8(%r12),%rcx
 29faf32:	mov    %rcx,0x228(%rsp)
 29faf3a:	cmp    %rcx,%rax
 29faf3d:	jb     29ee425 <wasm[0]::function[1015]::helper::object_read+0xd4a5>
 29faf43:	mov    0x190(%rsp),%rdi
 29faf4b:	call   3018b79 <wasmtime_builtin_new_epoch>
 29faf50:	mov    %rax,0x228(%rsp)
 29faf58:	jmp    29ee425 <wasm[0]::function[1015]::helper::object_read+0xd4a5>
 29faf5d:	mov    0x2e0(%rsp),%r12
 29faf65:	mov    0x8(%r12),%rcx
 29faf6a:	mov    %rcx,0x228(%rsp)
 29faf72:	cmp    %rcx,%rax
 29faf75:	jb     29ee52f <wasm[0]::function[1015]::helper::object_read+0xd5af>
 29faf7b:	mov    0x190(%rsp),%rdi
 29faf83:	call   3018b79 <wasmtime_builtin_new_epoch>
 29faf88:	mov    %rax,0x228(%rsp)
 29faf90:	mov    0x1d0(%rsp),%rdi
 29faf98:	jmp    29ee537 <wasm[0]::function[1015]::helper::object_read+0xd5b7>
 29faf9d:	mov    0x198(%rsp),%rcx
 29fafa5:	mov    %rbx,%rdx
 29fafa8:	mov    0x1a0(%rsp),%rsi
 29fafb0:	mov    0x190(%rsp),%rdi
 29fafb8:	mov    0x2b0(%rsp),%r8
 29fafc0:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
 29fafc5:	mov    %eax,%edx
 29fafc7:	mov    0x2e0(%rsp),%r12
 29fafcf:	add    0x20(%r12),%rdx
 29fafd4:	mov    0x1c8(%rsp),%rcx
 29fafdc:	jmp    29ee649 <wasm[0]::function[1015]::helper::object_read+0xd6c9>
 29fafe1:	mov    0x2e0(%rsp),%r12
 29fafe9:	mov    0x8(%r12),%r8
 29fafee:	mov    %r8,%r10
 29faff1:	mov    %r8,0x228(%rsp)
 29faff9:	cmp    %r10,%rax
 29faffc:	jb     29ee975 <wasm[0]::function[1015]::helper::object_read+0xd9f5>
 29fb002:	mov    0x190(%rsp),%rdi
 29fb00a:	call   3018b79 <wasmtime_builtin_new_epoch>
 29fb00f:	mov    %rax,0x228(%rsp)
 29fb017:	jmp    29ee975 <wasm[0]::function[1015]::helper::object_read+0xd9f5>
 29fb01c:	mov    $0xb0000072,%esi
 29fb021:	mov    0x190(%rsp),%rcx
 29fb029:	mov    0x28(%rcx),%rax
 29fb02d:	mov    0x13c(%rax),%edx
 29fb033:	mov    $0x20,%ecx
 29fb038:	mov    $0x10,%r8d
 29fb03e:	mov    0x190(%rsp),%rdi
 29fb046:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
 29fb04b:	mov    %rax,%r15
 29fb04e:	mov    %eax,%eax
 29fb050:	mov    0x2e0(%rsp),%r12
 29fb058:	add    0x20(%r12),%rax
 29fb05d:	jmp    29eed9f <wasm[0]::function[1015]::helper::object_read+0xde1f>
 29fb062:	mov    $0xb0000072,%esi
 29fb067:	mov    0x190(%rsp),%rcx
 29fb06f:	mov    0x28(%rcx),%rax
 29fb073:	mov    0x13c(%rax),%edx
 29fb079:	mov    $0x20,%ecx
 29fb07e:	mov    $0x10,%r8d
 29fb084:	mov    0x190(%rsp),%rdi
 29fb08c:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
 29fb091:	mov    %rax,%r15
 29fb094:	mov    %eax,%eax
 29fb096:	mov    0x2e0(%rsp),%r12
 29fb09e:	add    0x20(%r12),%rax
 29fb0a3:	jmp    29eee81 <wasm[0]::function[1015]::helper::object_read+0xdf01>
 29fb0a8:	mov    $0xb0000072,%esi
 29fb0ad:	mov    0x190(%rsp),%rcx
 29fb0b5:	mov    0x28(%rcx),%rax
 29fb0b9:	mov    0x13c(%rax),%edx
 29fb0bf:	mov    $0x20,%ecx
 29fb0c4:	mov    $0x10,%r8d
 29fb0ca:	mov    0x190(%rsp),%rdi
 29fb0d2:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
 29fb0d7:	mov    %rax,%r15
 29fb0da:	mov    %eax,%eax
 29fb0dc:	mov    0x2e0(%rsp),%r12
 29fb0e4:	add    0x20(%r12),%rax
 29fb0e9:	jmp    29ef1af <wasm[0]::function[1015]::helper::object_read+0xe22f>
 29fb0ee:	mov    $0xb0000072,%esi
 29fb0f3:	mov    0x190(%rsp),%rcx
 29fb0fb:	mov    0x28(%rcx),%rax
 29fb0ff:	mov    0x13c(%rax),%edx
 29fb105:	mov    $0x20,%ecx
 29fb10a:	mov    $0x10,%r8d
 29fb110:	mov    0x190(%rsp),%rdi
 29fb118:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
 29fb11d:	mov    %rax,%r15
 29fb120:	mov    %eax,%eax
 29fb122:	mov    0x2e0(%rsp),%r12
 29fb12a:	add    0x20(%r12),%rax
 29fb12f:	jmp    29ef28d <wasm[0]::function[1015]::helper::object_read+0xe30d>
 29fb134:	mov    $0xb0000042,%esi
 29fb139:	mov    0x190(%rsp),%rax
 29fb141:	mov    0x28(%rax),%rax
 29fb145:	mov    0x120(%rax),%edx
 29fb14b:	mov    $0x20,%ecx
 29fb150:	mov    $0x10,%r8d
 29fb156:	mov    0x190(%rsp),%rdi
 29fb15e:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
 29fb163:	mov    %eax,%esi
 29fb165:	mov    0x2e0(%rsp),%rcx
 29fb16d:	add    0x20(%rcx),%rsi
 29fb171:	mov    0x270(%rsp),%rcx
 29fb179:	jmp    29f004b <wasm[0]::function[1015]::helper::object_read+0xf0cb>
 29fb17e:	mov    $0xb0000042,%esi
 29fb183:	mov    0x190(%rsp),%rax
 29fb18b:	mov    0x28(%rax),%rax
 29fb18f:	mov    0x120(%rax),%edx
 29fb195:	mov    $0x20,%ecx
 29fb19a:	mov    $0x10,%r8d
 29fb1a0:	mov    0x190(%rsp),%rdi
 29fb1a8:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
 29fb1ad:	mov    %eax,%ecx
 29fb1af:	mov    0x2e0(%rsp),%rdx
 29fb1b7:	add    0x20(%rdx),%rcx
 29fb1bb:	jmp    29f00d8 <wasm[0]::function[1015]::helper::object_read+0xf158>
 29fb1c0:	mov    $0xb0000042,%esi
 29fb1c5:	mov    0x190(%rsp),%rax
 29fb1cd:	mov    0x28(%rax),%rax
 29fb1d1:	mov    0x120(%rax),%edx
 29fb1d7:	mov    $0x20,%ecx
 29fb1dc:	mov    $0x10,%r8d
 29fb1e2:	mov    0x190(%rsp),%rdi
 29fb1ea:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
 29fb1ef:	mov    %eax,%ecx
 29fb1f1:	mov    0x2e0(%rsp),%rdx
 29fb1f9:	add    0x20(%rdx),%rcx
 29fb1fd:	jmp    29f0167 <wasm[0]::function[1015]::helper::object_read+0xf1e7>
 29fb202:	mov    $0xa800000e,%esi
 29fb207:	mov    0x190(%rsp),%rax
 29fb20f:	mov    0x28(%rax),%rax
 29fb213:	mov    0x1b4(%rax),%edx
 29fb219:	mov    $0x20,%ecx
 29fb21e:	mov    $0x10,%r8d
 29fb224:	mov    0x190(%rsp),%rdi
 29fb22c:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
 29fb231:	mov    %eax,%edx
 29fb233:	mov    0x2e0(%rsp),%r12
 29fb23b:	add    0x20(%r12),%rdx
 29fb240:	jmp    29f0216 <wasm[0]::function[1015]::helper::object_read+0xf296>
 29fb245:	mov    0x2e0(%rsp),%r12
 29fb24d:	mov    0x8(%r12),%rax
 29fb252:	mov    %rax,0x228(%rsp)
 29fb25a:	cmp    %rax,%rdx
 29fb25d:	jb     29f056a <wasm[0]::function[1015]::helper::object_read+0xf5ea>
 29fb263:	mov    0x190(%rsp),%rdi
 29fb26b:	call   3018b79 <wasmtime_builtin_new_epoch>
 29fb270:	mov    %rax,0x228(%rsp)
 29fb278:	jmp    29f056a <wasm[0]::function[1015]::helper::object_read+0xf5ea>
 29fb27d:	mov    $0xb0000002,%esi
 29fb282:	mov    0x190(%rsp),%rax
 29fb28a:	mov    0x28(%rax),%rax
 29fb28e:	mov    0x1d0(%rax),%edx
 29fb294:	mov    $0x40,%ecx
 29fb299:	mov    $0x10,%r8d
 29fb29f:	mov    0x190(%rsp),%rdi
 29fb2a7:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
 29fb2ac:	mov    %eax,%r12d
 29fb2af:	mov    0x2e0(%rsp),%rcx
 29fb2b7:	add    0x20(%rcx),%r12
 29fb2bb:	jmp    29f08c8 <wasm[0]::function[1015]::helper::object_read+0xf948>
 29fb2c0:	mov    $0xb0001ffa,%esi
 29fb2c5:	mov    0x190(%rsp),%rax
 29fb2cd:	mov    0x28(%rax),%rax
 29fb2d1:	mov    0x1e0(%rax),%edx
 29fb2d7:	mov    $0x40,%ecx
 29fb2dc:	mov    $0x10,%r8d
 29fb2e2:	mov    0x190(%rsp),%rdi
 29fb2ea:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
 29fb2ef:	mov    %eax,%r13d
 29fb2f2:	mov    0x2e0(%rsp),%r12
 29fb2fa:	add    0x20(%r12),%r13
 29fb2ff:	jmp    29f09fe <wasm[0]::function[1015]::helper::object_read+0xfa7e>
 29fb304:	mov    $0xb00300fa,%esi
 29fb309:	mov    0x190(%rsp),%rax
 29fb311:	mov    0x28(%rax),%rax
 29fb315:	mov    0x1d4(%rax),%edx
 29fb31b:	mov    $0x50,%ecx
 29fb320:	mov    $0x10,%r8d
 29fb326:	mov    0x190(%rsp),%rdi
 29fb32e:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
 29fb333:	mov    %eax,%ecx
 29fb335:	mov    0x2e0(%rsp),%r12
 29fb33d:	add    0x20(%r12),%rcx
 29fb342:	jmp    29f0b5b <wasm[0]::function[1015]::helper::object_read+0xfbdb>
 29fb347:	mov    $0xb0000042,%esi
 29fb34c:	mov    0x190(%rsp),%rax
 29fb354:	mov    0x28(%rax),%rax
 29fb358:	mov    0x120(%rax),%edx
 29fb35e:	mov    $0x20,%ecx
 29fb363:	mov    $0x10,%r8d
 29fb369:	mov    0x190(%rsp),%rdi
 29fb371:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
 29fb376:	mov    %eax,%esi
 29fb378:	mov    0x2e0(%rsp),%r12
 29fb380:	add    0x20(%r12),%rsi
 29fb385:	jmp    29f0c8c <wasm[0]::function[1015]::helper::object_read+0xfd0c>
 29fb38a:	mov    $0xb0000042,%esi
 29fb38f:	mov    0x190(%rsp),%rdi
 29fb397:	mov    0x28(%rdi),%rax
 29fb39b:	mov    0x120(%rax),%edx
 29fb3a1:	mov    $0x20,%ecx
 29fb3a6:	mov    $0x10,%r8d
 29fb3ac:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
 29fb3b1:	mov    %eax,%ecx
 29fb3b3:	mov    0x2e0(%rsp),%r12
 29fb3bb:	add    0x20(%r12),%rcx
 29fb3c0:	jmp    29f0d20 <wasm[0]::function[1015]::helper::object_read+0xfda0>
 29fb3c5:	mov    $0xa800000e,%esi
 29fb3ca:	mov    0x190(%rsp),%rax
 29fb3d2:	mov    0x28(%rax),%rax
 29fb3d6:	mov    0x1b4(%rax),%edx
 29fb3dc:	mov    $0x10,%r8d
 29fb3e2:	mov    %r14,%rcx
 29fb3e5:	mov    0x190(%rsp),%rdi
 29fb3ed:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
 29fb3f2:	mov    %eax,%ecx
 29fb3f4:	mov    0x2e0(%rsp),%r12
 29fb3fc:	add    0x20(%r12),%rcx
 29fb401:	jmp    29f0dce <wasm[0]::function[1015]::helper::object_read+0xfe4e>
 29fb406:	mov    0x2e0(%rsp),%r12
 29fb40e:	mov    0x8(%r12),%rax
 29fb413:	mov    %rax,0x228(%rsp)
 29fb41b:	cmp    %rax,%rcx
 29fb41e:	jb     29f1520 <wasm[0]::function[1015]::helper::object_read+0x105a0>
 29fb424:	mov    0x190(%rsp),%rdi
 29fb42c:	call   3018b79 <wasmtime_builtin_new_epoch>
 29fb431:	mov    %rax,0x228(%rsp)
 29fb439:	jmp    29f1520 <wasm[0]::function[1015]::helper::object_read+0x105a0>
 29fb43e:	mov    0x2e0(%rsp),%r12
 29fb446:	mov    0x8(%r12),%rax
 29fb44b:	mov    %rax,0x228(%rsp)
 29fb453:	cmp    %rax,%rcx
 29fb456:	jb     29f20d1 <wasm[0]::function[1015]::helper::object_read+0x11151>
 29fb45c:	mov    0x190(%rsp),%rdi
 29fb464:	call   3018b79 <wasmtime_builtin_new_epoch>
 29fb469:	mov    %rax,0x228(%rsp)
 29fb471:	jmp    29f20d1 <wasm[0]::function[1015]::helper::object_read+0x11151>
 29fb476:	mov    0x2e0(%rsp),%r12
 29fb47e:	mov    0x8(%r12),%rcx
 29fb483:	mov    %rcx,0x228(%rsp)
 29fb48b:	cmp    %rcx,%rax
 29fb48e:	jb     29f2d3b <wasm[0]::function[1015]::helper::object_read+0x11dbb>
 29fb494:	mov    0x190(%rsp),%rdi
 29fb49c:	call   3018b79 <wasmtime_builtin_new_epoch>
 29fb4a1:	mov    %rax,0x228(%rsp)
 29fb4a9:	jmp    29f2d3b <wasm[0]::function[1015]::helper::object_read+0x11dbb>
 29fb4ae:	mov    0x2e0(%rsp),%r12
 29fb4b6:	mov    0x8(%r12),%rax
 29fb4bb:	mov    %rax,0x228(%rsp)
 29fb4c3:	cmp    %rax,%rcx
 29fb4c6:	jb     29f39d0 <wasm[0]::function[1015]::helper::object_read+0x12a50>
 29fb4cc:	mov    0x190(%rsp),%rdi
 29fb4d4:	call   3018b79 <wasmtime_builtin_new_epoch>
 29fb4d9:	mov    %rax,0x228(%rsp)
 29fb4e1:	jmp    29f39d0 <wasm[0]::function[1015]::helper::object_read+0x12a50>
 29fb4e6:	mov    0x2e0(%rsp),%r12
 29fb4ee:	mov    0x8(%r12),%rax
 29fb4f3:	mov    %rax,0x228(%rsp)
 29fb4fb:	cmp    %rax,%rsi
 29fb4fe:	jb     29f46b0 <wasm[0]::function[1015]::helper::object_read+0x13730>
 29fb504:	mov    0x190(%rsp),%rdi
 29fb50c:	call   3018b79 <wasmtime_builtin_new_epoch>
 29fb511:	mov    %rax,0x228(%rsp)
 29fb519:	jmp    29f46b0 <wasm[0]::function[1015]::helper::object_read+0x13730>
 29fb51e:	mov    0x2e0(%rsp),%r12
 29fb526:	mov    0x8(%r12),%rdx
 29fb52b:	cmp    %rdx,%rcx
 29fb52e:	jb     29f53f2 <wasm[0]::function[1015]::helper::object_read+0x14472>
 29fb534:	mov    0x190(%rsp),%rdi
 29fb53c:	call   3018b79 <wasmtime_builtin_new_epoch>
 29fb541:	mov    %rax,0x228(%rsp)
 29fb549:	jmp    29f53fa <wasm[0]::function[1015]::helper::object_read+0x1447a>
 29fb54e:	mov    $0xb0000042,%esi
 29fb553:	mov    0x190(%rsp),%rdi
 29fb55b:	mov    0x28(%rdi),%rax
 29fb55f:	mov    0x120(%rax),%edx
 29fb565:	mov    $0x20,%ecx
 29fb56a:	mov    $0x10,%r8d
 29fb570:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
 29fb575:	mov    %eax,%r10d
 29fb578:	mov    0x2e0(%rsp),%r12
 29fb580:	add    0x20(%r12),%r10
 29fb585:	jmp    29f64ff <wasm[0]::function[1015]::helper::object_read+0x1557f>
 29fb58a:	mov    $0xb0000042,%esi
 29fb58f:	mov    0x190(%rsp),%rax
 29fb597:	mov    0x28(%rax),%rax
 29fb59b:	mov    0x120(%rax),%edx
 29fb5a1:	mov    $0x20,%ecx
 29fb5a6:	mov    $0x10,%r8d
 29fb5ac:	mov    0x190(%rsp),%rdi
 29fb5b4:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
 29fb5b9:	mov    %eax,%ecx
 29fb5bb:	mov    0x2e0(%rsp),%r12
 29fb5c3:	add    0x20(%r12),%rcx
 29fb5c8:	jmp    29f6594 <wasm[0]::function[1015]::helper::object_read+0x15614>
 29fb5cd:	mov    $0xb0000042,%esi
 29fb5d2:	mov    0x190(%rsp),%rdi
 29fb5da:	mov    0x28(%rdi),%rax
 29fb5de:	mov    0x120(%rax),%edx
 29fb5e4:	mov    $0x20,%ecx
 29fb5e9:	mov    $0x10,%r8d
 29fb5ef:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
 29fb5f4:	mov    %eax,%r11d
 29fb5f7:	mov    0x2e0(%rsp),%r12
 29fb5ff:	add    0x20(%r12),%r11
 29fb604:	jmp    29f6627 <wasm[0]::function[1015]::helper::object_read+0x156a7>
 29fb609:	mov    $0xb0000072,%esi
 29fb60e:	mov    0x190(%rsp),%rax
 29fb616:	mov    0x28(%rax),%rax
 29fb61a:	mov    0x13c(%rax),%edx
 29fb620:	mov    $0x20,%ecx
 29fb625:	mov    $0x10,%r8d
 29fb62b:	mov    0x190(%rsp),%rdi
 29fb633:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
 29fb638:	mov    %rax,%r15
 29fb63b:	mov    %eax,%eax
 29fb63d:	mov    0x2e0(%rsp),%r12
 29fb645:	add    0x20(%r12),%rax
 29fb64a:	jmp    29f66ff <wasm[0]::function[1015]::helper::object_read+0x1577f>
 29fb64f:	mov    $0xb0000072,%esi
 29fb654:	mov    0x190(%rsp),%rax
 29fb65c:	mov    0x28(%rax),%rax
 29fb660:	mov    0x13c(%rax),%edx
 29fb666:	mov    $0x20,%ecx
 29fb66b:	mov    $0x10,%r8d
 29fb671:	mov    0x190(%rsp),%rdi
 29fb679:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
 29fb67e:	mov    %rax,%r15
 29fb681:	mov    %eax,%eax
 29fb683:	mov    0x2e0(%rsp),%r12
 29fb68b:	add    0x20(%r12),%rax
 29fb690:	jmp    29f67ea <wasm[0]::function[1015]::helper::object_read+0x1586a>
 29fb695:	mov    0x2e0(%rsp),%r12
 29fb69d:	mov    0x8(%r12),%rcx
 29fb6a2:	cmp    %rcx,%rax
 29fb6a5:	jb     29f6b78 <wasm[0]::function[1015]::helper::object_read+0x15bf8>
 29fb6ab:	mov    0x190(%rsp),%rdi
 29fb6b3:	call   3018b79 <wasmtime_builtin_new_epoch>
 29fb6b8:	mov    %rax,0x228(%rsp)
 29fb6c0:	jmp    29f6b80 <wasm[0]::function[1015]::helper::object_read+0x15c00>
 29fb6c5:	mov    0x2e0(%rsp),%rax
 29fb6cd:	mov    0x8(%rax),%rdx
 29fb6d1:	cmp    %rdx,%rcx
 29fb6d4:	jb     29f7088 <wasm[0]::function[1015]::helper::object_read+0x16108>
 29fb6da:	mov    0x190(%rsp),%rdi
 29fb6e2:	call   3018b79 <wasmtime_builtin_new_epoch>
 29fb6e7:	mov    %rax,0x228(%rsp)
 29fb6ef:	jmp    29f7090 <wasm[0]::function[1015]::helper::object_read+0x16110>
 29fb6f4:	mov    $0xb0000042,%esi
 29fb6f9:	mov    0x190(%rsp),%rax
 29fb701:	mov    0x28(%rax),%rax
 29fb705:	mov    0x120(%rax),%edx
 29fb70b:	mov    $0x20,%ecx
 29fb710:	mov    $0x10,%r8d
 29fb716:	mov    0x190(%rsp),%rdi
 29fb71e:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
 29fb723:	mov    %eax,%ecx
 29fb725:	mov    0x2e0(%rsp),%r12
 29fb72d:	add    0x20(%r12),%rcx
 29fb732:	jmp    29f748b <wasm[0]::function[1015]::helper::object_read+0x1650b>
 29fb737:	mov    $0xb0000072,%esi
 29fb73c:	mov    0x190(%rsp),%rax
 29fb744:	mov    0x28(%rax),%rax
 29fb748:	mov    0x13c(%rax),%edx
 29fb74e:	mov    $0x20,%ecx
 29fb753:	mov    $0x10,%r8d
 29fb759:	mov    0x190(%rsp),%rdi
 29fb761:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
 29fb766:	mov    %eax,%r11d
 29fb769:	mov    0x2e0(%rsp),%r12
 29fb771:	add    0x20(%r12),%r11
 29fb776:	jmp    29f756a <wasm[0]::function[1015]::helper::object_read+0x165ea>
 29fb77b:	mov    $0xa800000e,%esi
 29fb780:	mov    0x190(%rsp),%rax
 29fb788:	mov    0x28(%rax),%rax
 29fb78c:	mov    0x194(%rax),%edx
 29fb792:	mov    $0x10,%r8d
 29fb798:	mov    0x190(%rsp),%rdi
 29fb7a0:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
 29fb7a5:	mov    %eax,%ecx
 29fb7a7:	mov    0x2e0(%rsp),%rsi
 29fb7af:	add    0x20(%rsi),%rcx
 29fb7b3:	jmp    29f7ac3 <wasm[0]::function[1015]::helper::object_read+0x16b43>
 29fb7b8:	mov    0x2e0(%rsp),%r12
 29fb7c0:	mov    0x8(%r12),%r8
 29fb7c5:	cmp    %r8,%rsi
 29fb7c8:	jb     29f7bb4 <wasm[0]::function[1015]::helper::object_read+0x16c34>
 29fb7ce:	mov    0x190(%rsp),%rdi
 29fb7d6:	call   3018b79 <wasmtime_builtin_new_epoch>
 29fb7db:	mov    %rax,0x228(%rsp)
 29fb7e3:	jmp    29f7bbc <wasm[0]::function[1015]::helper::object_read+0x16c3c>
 29fb7e8:	mov    0x2e0(%rsp),%r12
 29fb7f0:	mov    0x8(%r12),%rcx
 29fb7f5:	cmp    %rcx,%rax
 29fb7f8:	jb     29f7c99 <wasm[0]::function[1015]::helper::object_read+0x16d19>
 29fb7fe:	mov    0x190(%rsp),%rdi
 29fb806:	call   3018b79 <wasmtime_builtin_new_epoch>
 29fb80b:	mov    0x1e8(%rsp),%rcx
 29fb813:	mov    %rax,0x228(%rsp)
 29fb81b:	jmp    29f7ca9 <wasm[0]::function[1015]::helper::object_read+0x16d29>
 29fb820:	mov    0x1d8(%rsp),%rcx
 29fb828:	mov    %r15,%rdx
 29fb82b:	mov    0x1e0(%rsp),%rsi
 29fb833:	mov    0x190(%rsp),%rdi
 29fb83b:	mov    %rbx,%r8
 29fb83e:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
 29fb843:	mov    %eax,%ecx
 29fb845:	mov    0x2e0(%rsp),%rdx
 29fb84d:	add    0x20(%rdx),%rcx
 29fb851:	jmp    29f7e43 <wasm[0]::function[1015]::helper::object_read+0x16ec3>
 29fb856:	mov    0x1d8(%rsp),%rcx
 29fb85e:	mov    %r14,%rdx
 29fb861:	mov    0x1d0(%rsp),%rsi
 29fb869:	mov    0x190(%rsp),%rdi
 29fb871:	mov    %rbx,%r8
 29fb874:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
 29fb879:	mov    %eax,%esi
 29fb87b:	mov    0x2e0(%rsp),%r12
 29fb883:	add    0x20(%r12),%rsi
 29fb888:	jmp    29f7ee4 <wasm[0]::function[1015]::helper::object_read+0x16f64>
 29fb88d:	mov    $0xa800000e,%esi
 29fb892:	mov    0x190(%rsp),%rax
 29fb89a:	mov    0x28(%rax),%rax
 29fb89e:	mov    0x194(%rax),%edx
 29fb8a4:	mov    $0x10,%r8d
 29fb8aa:	mov    0x190(%rsp),%rdi
 29fb8b2:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
 29fb8b7:	mov    %eax,%ecx
 29fb8b9:	mov    0x2e0(%rsp),%rsi
 29fb8c1:	add    0x20(%rsi),%rcx
 29fb8c5:	jmp    29f817f <wasm[0]::function[1015]::helper::object_read+0x171ff>
 29fb8ca:	mov    0x2e0(%rsp),%rcx
 29fb8d2:	mov    0x8(%rcx),%rcx
 29fb8d6:	cmp    %rcx,%rax
 29fb8d9:	jb     29f8263 <wasm[0]::function[1015]::helper::object_read+0x172e3>
 29fb8df:	mov    0x190(%rsp),%rdi
 29fb8e7:	call   3018b79 <wasmtime_builtin_new_epoch>
 29fb8ec:	mov    %rax,0x228(%rsp)
 29fb8f4:	jmp    29f826b <wasm[0]::function[1015]::helper::object_read+0x172eb>
 29fb8f9:	mov    0x2e0(%rsp),%r12
 29fb901:	mov    0x8(%r12),%rcx
 29fb906:	cmp    %rcx,%rax
 29fb909:	jb     29f8332 <wasm[0]::function[1015]::helper::object_read+0x173b2>
 29fb90f:	mov    0x190(%rsp),%rdi
 29fb917:	call   3018b79 <wasmtime_builtin_new_epoch>
 29fb91c:	mov    0x1d0(%rsp),%rcx
 29fb924:	mov    %rax,0x228(%rsp)
 29fb92c:	jmp    29f8342 <wasm[0]::function[1015]::helper::object_read+0x173c2>
 29fb931:	mov    0x1a0(%rsp),%rcx
 29fb939:	mov    %r14,%rdx
 29fb93c:	mov    0x1c8(%rsp),%rsi
 29fb944:	mov    0x190(%rsp),%rdi
 29fb94c:	mov    %r13,%r8
 29fb94f:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
 29fb954:	mov    %eax,%ecx
 29fb956:	mov    0x2e0(%rsp),%r12
 29fb95e:	add    0x20(%r12),%rcx
 29fb963:	jmp    29f8454 <wasm[0]::function[1015]::helper::object_read+0x174d4>
 29fb968:	mov    0x2e0(%rsp),%r12
 29fb970:	mov    0x8(%r12),%rcx
 29fb975:	cmp    %rcx,%rax
 29fb978:	jb     29f8736 <wasm[0]::function[1015]::helper::object_read+0x177b6>
 29fb97e:	mov    0x190(%rsp),%rdi
 29fb986:	call   3018b79 <wasmtime_builtin_new_epoch>
 29fb98b:	mov    %rax,0x228(%rsp)
 29fb993:	jmp    29f873e <wasm[0]::function[1015]::helper::object_read+0x177be>
 29fb998:	mov    $0xb0000072,%esi
 29fb99d:	mov    0x190(%rsp),%rax
 29fb9a5:	mov    0x28(%rax),%r10
 29fb9a9:	mov    0x13c(%r10),%edx
 29fb9b0:	mov    $0x20,%ecx
 29fb9b5:	mov    $0x10,%r8d
 29fb9bb:	mov    0x190(%rsp),%rdi
 29fb9c3:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
 29fb9c8:	mov    %rax,%r15
 29fb9cb:	mov    %eax,%eax
 29fb9cd:	mov    0x2e0(%rsp),%r12
 29fb9d5:	add    0x20(%r12),%rax
 29fb9da:	jmp    29f8b11 <wasm[0]::function[1015]::helper::object_read+0x17b91>
 29fb9df:	mov    $0xb0000072,%esi
 29fb9e4:	mov    0x190(%rsp),%r9
 29fb9ec:	mov    0x28(%r9),%rax
 29fb9f0:	mov    0x13c(%rax),%edx
 29fb9f6:	mov    $0x20,%ecx
 29fb9fb:	mov    $0x10,%r8d
 29fba01:	mov    0x190(%rsp),%rdi
 29fba09:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
 29fba0e:	mov    %rax,%r15
 29fba11:	mov    %eax,%eax
 29fba13:	mov    0x2e0(%rsp),%r12
 29fba1b:	add    0x20(%r12),%rax
 29fba20:	jmp    29f8c03 <wasm[0]::function[1015]::helper::object_read+0x17c83>
 29fba25:	mov    $0xb0000072,%esi
 29fba2a:	mov    0x190(%rsp),%rdi
 29fba32:	mov    0x28(%rdi),%rax
 29fba36:	mov    0x13c(%rax),%edx
 29fba3c:	mov    $0x20,%ecx
 29fba41:	mov    $0x10,%r8d
 29fba47:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
 29fba4c:	mov    %rax,%r15
 29fba4f:	mov    %eax,%eax
 29fba51:	mov    0x2e0(%rsp),%r12
 29fba59:	add    0x20(%r12),%rax
 29fba5e:	jmp    29f8ef3 <wasm[0]::function[1015]::helper::object_read+0x17f73>
 29fba63:	mov    $0xb0000072,%esi
 29fba68:	mov    0x190(%rsp),%rax
 29fba70:	mov    0x28(%rax),%rdi
 29fba74:	mov    0x13c(%rdi),%edx
 29fba7a:	mov    $0x20,%ecx
 29fba7f:	mov    $0x10,%r8d
 29fba85:	mov    0x190(%rsp),%rdi
 29fba8d:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
 29fba92:	mov    %rax,%r15
 29fba95:	mov    %eax,%eax
 29fba97:	mov    0x2e0(%rsp),%r12
 29fba9f:	add    0x20(%r12),%rax
 29fbaa4:	jmp    29f8fd4 <wasm[0]::function[1015]::helper::object_read+0x18054>
 29fbaa9:	mov    0x2e0(%rsp),%r12
 29fbab1:	mov    0x8(%r12),%rdx
 29fbab6:	cmp    %rdx,%rcx
 29fbab9:	jb     29f95cb <wasm[0]::function[1015]::helper::object_read+0x1864b>
 29fbabf:	mov    0x190(%rsp),%rdi
 29fbac7:	call   3018b79 <wasmtime_builtin_new_epoch>
 29fbacc:	mov    %rax,0x228(%rsp)
 29fbad4:	jmp    29f95d3 <wasm[0]::function[1015]::helper::object_read+0x18653>
 29fbad9:	mov    0x2e0(%rsp),%r12
 29fbae1:	mov    0x8(%r12),%rsi
 29fbae6:	cmp    %rsi,%rcx
 29fbae9:	jb     29f98e3 <wasm[0]::function[1015]::helper::object_read+0x18963>
 29fbaef:	mov    0x190(%rsp),%rdi
 29fbaf7:	call   3018b79 <wasmtime_builtin_new_epoch>
 29fbafc:	mov    %rax,0x228(%rsp)
 29fbb04:	jmp    29f98eb <wasm[0]::function[1015]::helper::object_read+0x1896b>
 29fbb09:	mov    0x2e0(%rsp),%r12
 29fbb11:	mov    0x8(%r12),%rcx
 29fbb16:	cmp    %rcx,%rax
 29fbb19:	jb     29f9c26 <wasm[0]::function[1015]::helper::object_read+0x18ca6>
 29fbb1f:	mov    0x190(%rsp),%rdi
 29fbb27:	call   3018b79 <wasmtime_builtin_new_epoch>
 29fbb2c:	mov    %rax,0x228(%rsp)
 29fbb34:	jmp    29f9c2e <wasm[0]::function[1015]::helper::object_read+0x18cae>
 29fbb39:	mov    0x2e0(%rsp),%r12
 29fbb41:	mov    0x8(%r12),%rcx
 29fbb46:	cmp    %rcx,%rax
 29fbb49:	jb     29f9ed1 <wasm[0]::function[1015]::helper::object_read+0x18f51>
 29fbb4f:	mov    0x190(%rsp),%rdi
 29fbb57:	call   3018b79 <wasmtime_builtin_new_epoch>
 29fbb5c:	mov    %rax,0x228(%rsp)
 29fbb64:	jmp    29f9ed9 <wasm[0]::function[1015]::helper::object_read+0x18f59>
 29fbb69:	mov    0x2e0(%rsp),%r12
 29fbb71:	mov    0x8(%r12),%rcx
 29fbb76:	cmp    %rcx,%rax
 29fbb79:	jb     29fa21a <wasm[0]::function[1015]::helper::object_read+0x1929a>
 29fbb7f:	mov    0x190(%rsp),%rdi
 29fbb87:	call   3018b79 <wasmtime_builtin_new_epoch>
 29fbb8c:	mov    %rax,0x228(%rsp)
 29fbb94:	jmp    29fa222 <wasm[0]::function[1015]::helper::object_read+0x192a2>
 29fbb99:	ud2
 29fbb9b:	ud2
 29fbb9d:	ud2
 29fbb9f:	ud2
 29fbba1:	ud2
 29fbba3:	ud2
 29fbba5:	ud2
 29fbba7:	ud2
 29fbba9:	ud2
 29fbbab:	ud2
 29fbbad:	ud2
 29fbbaf:	ud2
 29fbbb1:	ud2
 29fbbb3:	ud2
 29fbbb5:	ud2
 29fbbb7:	ud2
 29fbbb9:	ud2
 29fbbbb:	ud2
 29fbbbd:	ud2
 29fbbbf:	ud2
 29fbbc1:	ud2
 29fbbc3:	ud2
 29fbbc5:	ud2
 29fbbc7:	ud2
 29fbbc9:	ud2
 29fbbcb:	ud2
 29fbbcd:	ud2
 29fbbcf:	ud2
 29fbbd1:	ud2
 29fbbd3:	ud2
 29fbbd5:	ud2
 29fbbd7:	ud2
 29fbbd9:	ud2
 29fbbdb:	ud2
 29fbbdd:	ud2
 29fbbdf:	ud2
 29fbbe1:	ud2
 29fbbe3:	ud2
 29fbbe5:	ud2
 29fbbe7:	ud2
 29fbbe9:	ud2
 29fbbeb:	ud2
 29fbbed:	ud2
 29fbbef:	ud2
 29fbbf1:	ud2
 29fbbf3:	ud2
 29fbbf5:	ud2
 29fbbf7:	ud2
 29fbbf9:	ud2
 29fbbfb:	ud2
 29fbbfd:	ud2
 29fbbff:	ud2
 29fbc01:	ud2
 29fbc03:	ud2
 29fbc05:	ud2
 29fbc07:	ud2
 29fbc09:	ud2
 29fbc0b:	ud2
 29fbc0d:	ud2
 29fbc0f:	ud2
 29fbc11:	ud2
 29fbc13:	ud2
 29fbc15:	ud2
 29fbc17:	ud2
 29fbc19:	ud2
 29fbc1b:	ud2
 29fbc1d:	ud2
 29fbc1f:	ud2
 29fbc21:	ud2
 29fbc23:	ud2
 29fbc25:	ud2
 29fbc27:	ud2
 29fbc29:	ud2
 29fbc2b:	ud2
 29fbc2d:	ud2
 29fbc2f:	ud2
 29fbc31:	ud2
 29fbc33:	ud2
 29fbc35:	ud2
 29fbc37:	ud2
 29fbc39:	ud2
 29fbc3b:	ud2
 29fbc3d:	ud2
 29fbc3f:	ud2
 29fbc41:	ud2
 29fbc43:	ud2
 29fbc45:	ud2
 29fbc47:	ud2
 29fbc49:	ud2
 29fbc4b:	ud2
 29fbc4d:	ud2
 29fbc4f:	ud2
 29fbc51:	ud2
 29fbc53:	ud2
 29fbc55:	ud2
 29fbc57:	ud2
 29fbc59:	ud2
 29fbc5b:	ud2
 29fbc5d:	ud2
 29fbc5f:	ud2
 29fbc61:	ud2
 29fbc63:	ud2
 29fbc65:	ud2
 29fbc67:	ud2
 29fbc69:	ud2
 29fbc6b:	ud2
 29fbc6d:	ud2
 29fbc6f:	ud2
 29fbc71:	ud2
 29fbc73:	ud2
 29fbc75:	ud2
 29fbc77:	ud2
 29fbc79:	ud2
 29fbc7b:	ud2
 29fbc7d:	ud2
 29fbc7f:	ud2
 29fbc81:	ud2
 29fbc83:	ud2
 29fbc85:	ud2
 29fbc87:	ud2
 29fbc89:	ud2
 29fbc8b:	ud2
 29fbc8d:	ud2
 29fbc8f:	ud2
 29fbc91:	ud2
 29fbc93:	ud2
 29fbc95:	ud2
 29fbc97:	ud2
 29fbc99:	ud2
 29fbc9b:	ud2
 29fbc9d:	ud2
 29fbc9f:	ud2
 29fbca1:	ud2
 29fbca3:	ud2
 29fbca5:	ud2
 29fbca7:	ud2
 29fbca9:	ud2
 29fbcab:	ud2
 29fbcad:	ud2
 29fbcaf:	ud2
 29fbcb1:	ud2
 29fbcb3:	ud2
 29fbcb5:	ud2
 29fbcb7:	ud2
 29fbcb9:	ud2
 29fbcbb:	ud2
 29fbcbd:	ud2
 29fbcbf:	ud2
 29fbcc1:	ud2
 29fbcc3:	ud2
 29fbcc5:	ud2
 29fbcc7:	ud2
 29fbcc9:	ud2
 29fbccb:	ud2
 29fbccd:	ud2
 29fbccf:	ud2
 29fbcd1:	ud2
 29fbcd3:	ud2
 29fbcd5:	ud2
 29fbcd7:	ud2
 29fbcd9:	ud2
 29fbcdb:	ud2
 29fbcdd:	ud2
 29fbcdf:	ud2
 29fbce1:	ud2
 29fbce3:	ud2
 29fbce5:	ud2
 29fbce7:	ud2
 29fbce9:	ud2
 29fbceb:	ud2
 29fbced:	ud2
 29fbcef:	ud2
 29fbcf1:	ud2
 29fbcf3:	ud2
 29fbcf5:	ud2
 29fbcf7:	ud2
 29fbcf9:	ud2
 29fbcfb:	ud2
 29fbcfd:	ud2
 29fbcff:	ud2
 29fbd01:	ud2
 29fbd03:	ud2
 29fbd05:	ud2
 29fbd07:	ud2
 29fbd09:	ud2
 29fbd0b:	ud2
 29fbd0d:	ud2
 29fbd0f:	ud2
 29fbd11:	ud2
 29fbd13:	ud2
 29fbd15:	ud2
 29fbd17:	ud2
 29fbd19:	ud2
 29fbd1b:	ud2
 29fbd1d:	ud2
 29fbd1f:	ud2
 29fbd21:	ud2
 29fbd23:	ud2
 29fbd25:	ud2
 29fbd27:	ud2
 29fbd29:	ud2
 29fbd2b:	ud2
 29fbd2d:	ud2
 29fbd2f:	ud2
 29fbd31:	ud2
 29fbd33:	ud2
 29fbd35:	ud2
 29fbd37:	ud2
 29fbd39:	ud2
 29fbd3b:	ud2
 29fbd3d:	ud2
 29fbd3f:	ud2
 29fbd41:	ud2
 29fbd43:	ud2
 29fbd45:	ud2
 29fbd47:	ud2
 29fbd49:	ud2
 29fbd4b:	ud2
 29fbd4d:	ud2
 29fbd4f:	ud2
 29fbd51:	ud2
 29fbd53:	ud2
 29fbd55:	ud2
 29fbd57:	ud2
 29fbd59:	ud2
 29fbd5b:	ud2
 29fbd5d:	ud2
 29fbd5f:	ud2
 29fbd61:	ud2
 29fbd63:	ud2
 29fbd65:	ud2
 29fbd67:	ud2
 29fbd69:	ud2
 29fbd6b:	ud2
 29fbd6d:	ud2
 29fbd6f:	ud2
 29fbd71:	ud2
 29fbd73:	ud2
 29fbd75:	ud2
 29fbd77:	ud2
 29fbd79:	ud2
 29fbd7b:	ud2
 29fbd7d:	ud2
 29fbd7f:	ud2
 29fbd81:	ud2
 29fbd83:	ud2
 29fbd85:	ud2
 29fbd87:	ud2
 29fbd89:	ud2
 29fbd8b:	ud2
 29fbd8d:	ud2
 29fbd8f:	ud2
 29fbd91:	ud2
 29fbd93:	ud2
 29fbd95:	ud2
 29fbd97:	ud2
 29fbd99:	ud2
 29fbd9b:	ud2
 29fbd9d:	ud2
 29fbd9f:	ud2
 29fbda1:	ud2
 29fbda3:	ud2
 29fbda5:	ud2
 29fbda7:	ud2
 29fbda9:	ud2
 29fbdab:	ud2
 29fbdad:	ud2
 29fbdaf:	ud2
 29fbdb1:	ud2
 29fbdb3:	ud2
 29fbdb5:	ud2
 29fbdb7:	ud2
 29fbdb9:	ud2
 29fbdbb:	ud2
 29fbdbd:	ud2
 29fbdbf:	ud2
 29fbdc1:	ud2
 29fbdc3:	ud2
 29fbdc5:	ud2
 29fbdc7:	ud2
 29fbdc9:	ud2
 29fbdcb:	ud2
 29fbdcd:	ud2
 29fbdcf:	ud2
 29fbdd1:	ud2
 29fbdd3:	ud2
 29fbdd5:	ud2
 29fbdd7:	ud2
 29fbdd9:	ud2
 29fbddb:	ud2
 29fbddd:	ud2
 29fbddf:	ud2
 29fbde1:	ud2
 29fbde3:	ud2
 29fbde5:	ud2
 29fbde7:	ud2
 29fbde9:	ud2
 29fbdeb:	ud2
 29fbded:	ud2
 29fbdef:	ud2
 29fbdf1:	ud2
 29fbdf3:	ud2
 29fbdf5:	ud2
 29fbdf7:	ud2
 29fbdf9:	ud2
 29fbdfb:	ud2
 29fbdfd:	ud2
 29fbdff:	ud2
 29fbe01:	ud2
 29fbe03:	ud2
 29fbe05:	ud2
 29fbe07:	ud2
 29fbe09:	ud2
 29fbe0b:	ud2
 29fbe0d:	ud2
 29fbe0f:	ud2
 29fbe11:	ud2
 29fbe13:	ud2
 29fbe15:	ud2
 29fbe17:	ud2
 29fbe19:	ud2
 29fbe1b:	ud2
 29fbe1d:	ud2
 29fbe1f:	ud2
 29fbe21:	ud2
 29fbe23:	ud2
 29fbe25:	ud2
 29fbe27:	ud2
 29fbe29:	ud2
 29fbe2b:	ud2
 29fbe2d:	ud2
 29fbe2f:	ud2
 29fbe31:	ud2
 29fbe33:	ud2
 29fbe35:	ud2
 29fbe37:	ud2
 29fbe39:	ud2
 29fbe3b:	ud2
 29fbe3d:	ud2
 29fbe3f:	ud2
 29fbe41:	ud2
 29fbe43:	ud2
 29fbe45:	ud2
 29fbe47:	ud2
 29fbe49:	ud2
 29fbe4b:	ud2
 29fbe4d:	ud2
 29fbe4f:	ud2
 29fbe51:	ud2
 29fbe53:	ud2
 29fbe55:	ud2
 29fbe57:	ud2
 29fbe59:	ud2
 29fbe5b:	ud2
 29fbe5d:	ud2
 29fbe5f:	ud2
 29fbe61:	ud2
 29fbe63:	ud2
 29fbe65:	ud2
 29fbe67:	ud2
 29fbe69:	ud2
 29fbe6b:	ud2
 29fbe6d:	ud2
 29fbe6f:	ud2
 29fbe71:	ud2
 29fbe73:	ud2
 29fbe75:	ud2
 29fbe77:	ud2
 29fbe79:	ud2
 29fbe7b:	ud2
 29fbe7d:	ud2
 29fbe7f:	ud2
 29fbe81:	ud2
 29fbe83:	ud2
 29fbe85:	ud2
 29fbe87:	ud2
 29fbe89:	ud2
 29fbe8b:	ud2
 29fbe8d:	ud2
 29fbe8f:	ud2
 29fbe91:	ud2
 29fbe93:	ud2
 29fbe95:	ud2
 29fbe97:	ud2
 29fbe99:	ud2
 29fbe9b:	ud2
 29fbe9d:	ud2
 29fbe9f:	ud2
 29fbea1:	ud2
 29fbea3:	ud2
 29fbea5:	ud2
 29fbea7:	ud2
 29fbea9:	ud2
 29fbeab:	ud2
 29fbead:	ud2
 29fbeaf:	ud2
 29fbeb1:	ud2
 29fbeb3:	ud2
 29fbeb5:	ud2
 29fbeb7:	ud2
 29fbeb9:	ud2
 29fbebb:	ud2
 29fbebd:	ud2
 29fbebf:	ud2
 29fbec1:	ud2
 29fbec3:	ud2
 29fbec5:	ud2
 29fbec7:	ud2
 29fbec9:	ud2
 29fbecb:	ud2
 29fbecd:	ud2
 29fbecf:	ud2
 29fbed1:	ud2
 29fbed3:	ud2
 29fbed5:	ud2
 29fbed7:	ud2
 29fbed9:	ud2
 29fbedb:	ud2
 29fbedd:	ud2
 29fbedf:	ud2
 29fbee1:	ud2
 29fbee3:	ud2
 29fbee5:	ud2
 29fbee7:	ud2
 29fbee9:	ud2
 29fbeeb:	ud2
 29fbeed:	ud2
 29fbeef:	ud2
 29fbef1:	ud2
 29fbef3:	ud2
 29fbef5:	ud2
 29fbef7:	ud2
 29fbef9:	ud2
 29fbefb:	ud2
 29fbefd:	ud2
 29fbeff:	ud2
 29fbf01:	ud2
 29fbf03:	ud2
 29fbf05:	ud2
 29fbf07:	ud2
 29fbf09:	ud2
 29fbf0b:	ud2
 29fbf0d:	ud2
 29fbf0f:	ud2
 29fbf11:	ud2
 29fbf13:	ud2
 29fbf15:	ud2
 29fbf17:	ud2
 29fbf19:	ud2
 29fbf1b:	ud2
 29fbf1d:	ud2
 29fbf1f:	ud2
 29fbf21:	ud2
 29fbf23:	ud2
 29fbf25:	ud2
 29fbf27:	ud2
 29fbf29:	ud2
 29fbf2b:	ud2
 29fbf2d:	ud2
 29fbf2f:	ud2
 29fbf31:	ud2
 29fbf33:	ud2
 29fbf35:	ud2
 29fbf37:	ud2
 29fbf39:	ud2
 29fbf3b:	ud2
 29fbf3d:	ud2
 29fbf3f:	ud2
 29fbf41:	ud2
 29fbf43:	ud2
 29fbf45:	ud2
 29fbf47:	ud2
 29fbf49:	ud2
 29fbf4b:	ud2
 29fbf4d:	ud2
 29fbf4f:	ud2
 29fbf51:	ud2
 29fbf53:	ud2
 29fbf55:	ud2
 29fbf57:	ud2
 29fbf59:	ud2
 29fbf5b:	ud2
 29fbf5d:	ud2
 29fbf5f:	ud2
 29fbf61:	ud2
 29fbf63:	ud2
 29fbf65:	ud2
 29fbf67:	ud2
 29fbf69:	ud2
 29fbf6b:	ud2
 29fbf6d:	ud2
 29fbf6f:	ud2
 29fbf71:	ud2
 29fbf73:	ud2
 29fbf75:	ud2
 29fbf77:	ud2
 29fbf79:	ud2
 29fbf7b:	ud2
 29fbf7d:	ud2
 29fbf7f:	ud2
 29fbf81:	ud2
 29fbf83:	ud2
 29fbf85:	ud2
 29fbf87:	ud2
 29fbf89:	ud2
 29fbf8b:	ud2
 29fbf8d:	ud2
 29fbf8f:	ud2
 29fbf91:	ud2
 29fbf93:	ud2
 29fbf95:	ud2
 29fbf97:	ud2
 29fbf99:	ud2
 29fbf9b:	ud2
 29fbf9d:	ud2
 29fbf9f:	ud2
 29fbfa1:	ud2
 29fbfa3:	ud2
 29fbfa5:	ud2
 29fbfa7:	ud2
 29fbfa9:	ud2
 29fbfab:	ud2
 29fbfad:	ud2
 29fbfaf:	ud2
 29fbfb1:	ud2
 29fbfb3:	ud2
 29fbfb5:	ud2
 29fbfb7:	ud2
 29fbfb9:	ud2
 29fbfbb:	ud2
 29fbfbd:	ud2
 29fbfbf:	ud2
 29fbfc1:	ud2
 29fbfc3:	ud2
 29fbfc5:	ud2
 29fbfc7:	ud2
 29fbfc9:	ud2
 29fbfcb:	ud2
 29fbfcd:	ud2
 29fbfcf:	ud2
 29fbfd1:	ud2
 29fbfd3:	ud2
 29fbfd5:	ud2
 29fbfd7:	ud2
 29fbfd9:	ud2
 29fbfdb:	ud2
 29fbfdd:	ud2
 29fbfdf:	ud2
 29fbfe1:	ud2
 29fbfe3:	ud2
 29fbfe5:	ud2
 29fbfe7:	ud2
 29fbfe9:	ud2
 29fbfeb:	ud2
 29fbfed:	ud2
 29fbfef:	ud2
 29fbff1:	ud2
 29fbff3:	ud2
 29fbff5:	ud2
 29fbff7:	ud2
 29fbff9:	ud2
 29fbffb:	ud2
 29fbffd:	ud2
 29fbfff:	ud2
 29fc001:	ud2
 29fc003:	ud2
 29fc005:	ud2
 29fc007:	ud2
 29fc009:	ud2
 29fc00b:	ud2
 29fc00d:	ud2
 29fc00f:	ud2
 29fc011:	ud2
 29fc013:	ud2
 29fc015:	ud2
 29fc017:	ud2
 29fc019:	ud2
 29fc01b:	ud2
 29fc01d:	ud2
 29fc01f:	ud2
 29fc021:	ud2
 29fc023:	ud2
 29fc025:	ud2
 29fc027:	ud2
 29fc029:	ud2
 29fc02b:	ud2
 29fc02d:	ud2
 29fc02f:	ud2
 29fc031:	ud2
 29fc033:	ud2
 29fc035:	ud2
 29fc037:	ud2
 29fc039:	ud2
 29fc03b:	ud2
 29fc03d:	ud2
 29fc03f:	ud2
 29fc041:	ud2
 29fc043:	ud2
 29fc045:	ud2
 29fc047:	ud2
 29fc049:	ud2
 29fc04b:	ud2
 29fc04d:	ud2
 29fc04f:	ud2
 29fc051:	ud2
 29fc053:	ud2
 29fc055:	ud2
 29fc057:	ud2
 29fc059:	ud2
 29fc05b:	ud2
 29fc05d:	ud2
 29fc05f:	ud2
 29fc061:	ud2
 29fc063:	ud2
 29fc065:	ud2
 29fc067:	ud2
 29fc069:	ud2
 29fc06b:	ud2
 29fc06d:	ud2
 29fc06f:	ud2
 29fc071:	ud2
 29fc073:	ud2
 29fc075:	ud2
 29fc077:	ud2
 29fc079:	ud2
 29fc07b:	ud2
 29fc07d:	ud2
 29fc07f:	ud2
 29fc081:	ud2
 29fc083:	ud2
 29fc085:	ud2
 29fc087:	ud2
 29fc089:	ud2
 29fc08b:	ud2
 29fc08d:	ud2
 29fc08f:	ud2
 29fc091:	ud2
 29fc093:	ud2
 29fc095:	ud2
 29fc097:	ud2
 29fc099:	ud2
 29fc09b:	ud2
 29fc09d:	ud2
 29fc09f:	ud2
 29fc0a1:	ud2
 29fc0a3:	ud2
 29fc0a5:	ud2
 29fc0a7:	ud2
 29fc0a9:	ud2
 29fc0ab:	ud2
 29fc0ad:	ud2
 29fc0af:	ud2
 29fc0b1:	ud2
 29fc0b3:	ud2
 29fc0b5:	ud2
 29fc0b7:	ud2
 29fc0b9:	ud2
 29fc0bb:	ud2
 29fc0bd:	ud2
 29fc0bf:	ud2
 29fc0c1:	ud2
 29fc0c3:	ud2
 29fc0c5:	ud2
 29fc0c7:	ud2
 29fc0c9:	ud2
 29fc0cb:	ud2
 29fc0cd:	ud2
 29fc0cf:	ud2
 29fc0d1:	ud2
 29fc0d3:	ud2
 29fc0d5:	ud2
 29fc0d7:	ud2
 29fc0d9:	ud2
 29fc0db:	ud2
 29fc0dd:	ud2
 29fc0df:	ud2
 29fc0e1:	ud2
 29fc0e3:	ud2
 29fc0e5:	ud2
 29fc0e7:	ud2
 29fc0e9:	ud2
 29fc0eb:	ud2
 29fc0ed:	ud2
 29fc0ef:	ud2
 29fc0f1:	ud2
 29fc0f3:	ud2
 29fc0f5:	ud2
 29fc0f7:	ud2
 29fc0f9:	ud2
 29fc0fb:	ud2
 29fc0fd:	ud2
 29fc0ff:	ud2
 29fc101:	ud2
 29fc103:	ud2
 29fc105:	ud2
 29fc107:	ud2
 29fc109:	ud2
 29fc10b:	ud2
 29fc10d:	ud2
 29fc10f:	ud2
 29fc111:	ud2
 29fc113:	ud2
 29fc115:	ud2
 29fc117:	ud2
 29fc119:	ud2
 29fc11b:	ud2
 29fc11d:	ud2
 29fc11f:	ud2
 29fc121:	ud2
 29fc123:	ud2
 29fc125:	ud2
 29fc127:	ud2
 29fc129:	ud2
 29fc12b:	ud2
 29fc12d:	ud2
 29fc12f:	ud2
 29fc131:	ud2
 29fc133:	ud2
 29fc135:	ud2
 29fc137:	ud2
 29fc139:	ud2
 29fc13b:	ud2
 29fc13d:	ud2
 29fc13f:	ud2
 29fc141:	ud2
 29fc143:	ud2
 29fc145:	ud2
 29fc147:	ud2
 29fc149:	ud2
 29fc14b:	ud2
 29fc14d:	ud2
 29fc14f:	ud2
 29fc151:	ud2
 29fc153:	ud2
 29fc155:	ud2
 29fc157:	ud2
 29fc159:	ud2
 29fc15b:	ud2
 29fc15d:	ud2
 29fc15f:	ud2
 29fc161:	ud2
 29fc163:	ud2
 29fc165:	ud2
 29fc167:	ud2
 29fc169:	ud2
 29fc16b:	ud2
 29fc16d:	ud2
 29fc16f:	ud2
 29fc171:	ud2
 29fc173:	ud2
 29fc175:	ud2
 29fc177:	ud2
 29fc179:	ud2
 29fc17b:	ud2
 29fc17d:	ud2
 29fc17f:	ud2
 29fc181:	ud2
 29fc183:	ud2
 29fc185:	ud2
 29fc187:	ud2
 29fc189:	ud2
 29fc18b:	ud2
 29fc18d:	ud2
 29fc18f:	ud2
 29fc191:	ud2
 29fc193:	ud2
 29fc195:	ud2
 29fc197:	ud2
 29fc199:	ud2
 29fc19b:	ud2
 29fc19d:	ud2
 29fc19f:	ud2
 29fc1a1:	ud2
 29fc1a3:	ud2
 29fc1a5:	ud2
 29fc1a7:	ud2
 29fc1a9:	ud2
 29fc1ab:	ud2
 29fc1ad:	ud2
 29fc1af:	ud2
 29fc1b1:	ud2
 29fc1b3:	ud2
 29fc1b5:	ud2
 29fc1b7:	ud2
 29fc1b9:	ud2
 29fc1bb:	ud2
 29fc1bd:	ud2
 29fc1bf:	ud2
 29fc1c1:	ud2
 29fc1c3:	ud2
 29fc1c5:	ud2
 29fc1c7:	ud2
 29fc1c9:	ud2
 29fc1cb:	ud2
 29fc1cd:	ud2
 29fc1cf:	ud2
 29fc1d1:	ud2
 29fc1d3:	ud2
 29fc1d5:	ud2
 29fc1d7:	ud2
 29fc1d9:	ud2
 29fc1db:	ud2
 29fc1dd:	ud2
 29fc1df:	ud2
 29fc1e1:	ud2
 29fc1e3:	ud2
 29fc1e5:	ud2
 29fc1e7:	ud2
 29fc1e9:	ud2
 29fc1eb:	ud2
 29fc1ed:	ud2
 29fc1ef:	ud2
 29fc1f1:	ud2
 29fc1f3:	ud2
 29fc1f5:	ud2
 29fc1f7:	ud2
 29fc1f9:	ud2
 29fc1fb:	ud2
 29fc1fd:	ud2
 29fc1ff:	ud2
 29fc201:	ud2
 29fc203:	ud2
 29fc205:	ud2
 29fc207:	ud2
 29fc209:	ud2
 29fc20b:	ud2
 29fc20d:	ud2
 29fc20f:	ud2
 29fc211:	ud2
 29fc213:	ud2
 29fc215:	ud2
 29fc217:	ud2
 29fc219:	ud2
 29fc21b:	ud2
 29fc21d:	ud2
 29fc21f:	ud2
 29fc221:	ud2
 29fc223:	ud2
 29fc225:	ud2
 29fc227:	ud2
 29fc229:	ud2
 29fc22b:	ud2
 29fc22d:	ud2
 29fc22f:	ud2
 29fc231:	ud2
 29fc233:	ud2
 29fc235:	ud2
 29fc237:	ud2
 29fc239:	ud2
 29fc23b:	ud2
 29fc23d:	ud2
 29fc23f:	ud2
 29fc241:	ud2
 29fc243:	ud2
 29fc245:	ud2
 29fc247:	ud2
 29fc249:	ud2
 29fc24b:	ud2
 29fc24d:	ud2
 29fc24f:	ud2
 29fc251:	ud2
 29fc253:	ud2
 29fc255:	ud2
 29fc257:	ud2
 29fc259:	ud2
 29fc25b:	ud2
 29fc25d:	ud2
 29fc25f:	ud2
 29fc261:	ud2
 29fc263:	ud2
 29fc265:	ud2
 29fc267:	ud2
 29fc269:	ud2
 29fc26b:	ud2
 29fc26d:	ud2
 29fc26f:	ud2
 29fc271:	ud2
 29fc273:	ud2
 29fc275:	ud2
 29fc277:	ud2
 29fc279:	ud2
 29fc27b:	ud2
 29fc27d:	ud2
 29fc27f:	ud2
 29fc281:	ud2
 29fc283:	ud2
 29fc285:	ud2
 29fc287:	ud2
 29fc289:	ud2
 29fc28b:	ud2
 29fc28d:	ud2
 29fc28f:	ud2
 29fc291:	ud2
 29fc293:	ud2
 29fc295:	ud2
 29fc297:	ud2
 29fc299:	ud2
 29fc29b:	ud2
 29fc29d:	ud2
 29fc29f:	ud2
 29fc2a1:	ud2
 29fc2a3:	ud2
 29fc2a5:	ud2
 29fc2a7:	ud2
 29fc2a9:	ud2
 29fc2ab:	ud2
 29fc2ad:	ud2
 29fc2af:	ud2
 29fc2b1:	ud2
 29fc2b3:	ud2
 29fc2b5:	ud2
 29fc2b7:	ud2
 29fc2b9:	ud2
 29fc2bb:	ud2
 29fc2bd:	ud2
 29fc2bf:	ud2
 29fc2c1:	ud2
 29fc2c3:	ud2
 29fc2c5:	ud2
 29fc2c7:	ud2
 29fc2c9:	ud2
 29fc2cb:	ud2
 29fc2cd:	ud2
 29fc2cf:	ud2
 29fc2d1:	ud2
 29fc2d3:	ud2
 29fc2d5:	ud2
 29fc2d7:	ud2
 29fc2d9:	ud2
 29fc2db:	ud2
 29fc2dd:	ud2
 29fc2df:	ud2
 29fc2e1:	ud2
 29fc2e3:	ud2
 29fc2e5:	ud2
 29fc2e7:	ud2
 29fc2e9:	ud2
 29fc2eb:	ud2
 29fc2ed:	ud2
 29fc2ef:	ud2
 29fc2f1:	ud2
 29fc2f3:	ud2
 29fc2f5:	ud2
 29fc2f7:	ud2
 29fc2f9:	ud2
 29fc2fb:	ud2
 29fc2fd:	ud2
 29fc2ff:	ud2
 29fc301:	ud2
 29fc303:	ud2
 29fc305:	ud2
 29fc307:	ud2
 29fc309:	ud2
 29fc30b:	ud2
 29fc30d:	ud2
 29fc30f:	ud2
 29fc311:	ud2
 29fc313:	ud2
 29fc315:	ud2
 29fc317:	ud2
 29fc319:	ud2
 29fc31b:	ud2
 29fc31d:	ud2
 29fc31f:	ud2
 29fc321:	ud2
 29fc323:	ud2
 29fc325:	ud2
 29fc327:	ud2
 29fc329:	ud2
 29fc32b:	ud2
 29fc32d:	ud2
 29fc32f:	ud2
 29fc331:	ud2
 29fc333:	ud2
 29fc335:	ud2
 29fc337:	ud2
 29fc339:	ud2
 29fc33b:	ud2
 29fc33d:	ud2
 29fc33f:	ud2
 29fc341:	ud2
 29fc343:	ud2
 29fc345:	ud2
 29fc347:	ud2
 29fc349:	ud2
 29fc34b:	ud2
 29fc34d:	ud2
 29fc34f:	ud2
 29fc351:	ud2
 29fc353:	ud2
 29fc355:	ud2
 29fc357:	ud2
 29fc359:	ud2
 29fc35b:	ud2
 29fc35d:	ud2
 29fc35f:	ud2
 29fc361:	ud2
 29fc363:	ud2
 29fc365:	ud2
 29fc367:	ud2
 29fc369:	ud2
 29fc36b:	ud2
 29fc36d:	ud2
 29fc36f:	ud2
 29fc371:	ud2
 29fc373:	ud2
 29fc375:	ud2
 29fc377:	ud2
 29fc379:	ud2
 29fc37b:	ud2
 29fc37d:	ud2
 29fc37f:	ud2
 29fc381:	ud2
 29fc383:	ud2
 29fc385:	ud2
 29fc387:	ud2
 29fc389:	ud2
 29fc38b:	ud2
 29fc38d:	ud2
 29fc38f:	ud2
 29fc391:	ud2
 29fc393:	ud2
 29fc395:	ud2
 29fc397:	ud2
 29fc399:	ud2
 29fc39b:	ud2
 29fc39d:	ud2
 29fc39f:	ud2
 29fc3a1:	ud2
 29fc3a3:	ud2
 29fc3a5:	ud2
 29fc3a7:	ud2
 29fc3a9:	ud2
 29fc3ab:	ud2
 29fc3ad:	ud2
 29fc3af:	ud2
 29fc3b1:	ud2
 29fc3b3:	ud2
 29fc3b5:	ud2
 29fc3b7:	ud2
 29fc3b9:	ud2
 29fc3bb:	ud2
 29fc3bd:	ud2
 29fc3bf:	ud2
 29fc3c1:	ud2
 29fc3c3:	ud2
 29fc3c5:	ud2
 29fc3c7:	ud2
 29fc3c9:	ud2
 29fc3cb:	ud2
 29fc3cd:	ud2
 29fc3cf:	ud2
 29fc3d1:	ud2
 29fc3d3:	ud2
 29fc3d5:	ud2
 29fc3d7:	ud2
 29fc3d9:	ud2
 29fc3db:	ud2
 29fc3dd:	ud2
 29fc3df:	ud2
 29fc3e1:	ud2
 29fc3e3:	ud2
 29fc3e5:	ud2
 29fc3e7:	ud2
 29fc3e9:	ud2
 29fc3eb:	ud2
 29fc3ed:	ud2
 29fc3ef:	ud2
 29fc3f1:	ud2
 29fc3f3:	ud2
 29fc3f5:	ud2
 29fc3f7:	ud2
 29fc3f9:	ud2
 29fc3fb:	ud2
 29fc3fd:	ud2
 29fc3ff:	ud2
 29fc401:	ud2
 29fc403:	ud2
 29fc405:	ud2
 29fc407:	ud2
 29fc409:	ud2
 29fc40b:	ud2
 29fc40d:	ud2
 29fc40f:	ud2
 29fc411:	ud2
 29fc413:	ud2
 29fc415:	ud2
 29fc417:	ud2
 29fc419:	ud2
 29fc41b:	ud2
 29fc41d:	ud2
 29fc41f:	ud2
 29fc421:	ud2
 29fc423:	ud2
 29fc425:	ud2
 29fc427:	ud2
 29fc429:	ud2
 29fc42b:	ud2
 29fc42d:	ud2
 29fc42f:	ud2
 29fc431:	ud2
 29fc433:	ud2
 29fc435:	ud2
 29fc437:	ud2
 29fc439:	ud2
 29fc43b:	ud2
 29fc43d:	ud2
 29fc43f:	ud2
 29fc441:	ud2
 29fc443:	ud2
 29fc445:	ud2
 29fc447:	ud2
 29fc449:	ud2
 29fc44b:	ud2
 29fc44d:	ud2
 29fc44f:	ud2
 29fc451:	ud2
 29fc453:	ud2
 29fc455:	ud2
 29fc457:	ud2
 29fc459:	ud2
 29fc45b:	ud2
 29fc45d:	ud2
 29fc45f:	ud2
 29fc461:	ud2
 29fc463:	ud2
 29fc465:	ud2
 29fc467:	ud2
 29fc469:	ud2
 29fc46b:	ud2
 29fc46d:	ud2
 29fc46f:	ud2
 29fc471:	ud2
 29fc473:	ud2
 29fc475:	ud2
 29fc477:	ud2
 29fc479:	ud2
 29fc47b:	ud2
 29fc47d:	ud2
 29fc47f:	ud2
 29fc481:	ud2
 29fc483:	ud2
 29fc485:	ud2
 29fc487:	ud2
 29fc489:	ud2
 29fc48b:	ud2
 29fc48d:	ud2
 29fc48f:	ud2
 29fc491:	ud2
 29fc493:	ud2
 29fc495:	ud2
 29fc497:	ud2
 29fc499:	ud2
 29fc49b:	ud2
 29fc49d:	ud2
 29fc49f:	ud2
 29fc4a1:	ud2
 29fc4a3:	ud2
 29fc4a5:	ud2
 29fc4a7:	ud2
 29fc4a9:	ud2
 29fc4ab:	ud2
 29fc4ad:	ud2
 29fc4af:	ud2
 29fc4b1:	ud2
 29fc4b3:	ud2
 29fc4b5:	ud2
 29fc4b7:	ud2
 29fc4b9:	ud2
 29fc4bb:	ud2
 29fc4bd:	ud2
 29fc4bf:	ud2
 29fc4c1:	ud2
 29fc4c3:	ud2
 29fc4c5:	ud2
 29fc4c7:	ud2
 29fc4c9:	ud2
 29fc4cb:	ud2
 29fc4cd:	ud2
 29fc4cf:	ud2
 29fc4d1:	ud2
 29fc4d3:	ud2
 29fc4d5:	ud2
 29fc4d7:	ud2
 29fc4d9:	ud2
 29fc4db:	ud2
 29fc4dd:	ud2
 29fc4df:	ud2
 29fc4e1:	ud2
 29fc4e3:	ud2
 29fc4e5:	ud2
 29fc4e7:	ud2
 29fc4e9:	ud2
 29fc4eb:	ud2
 29fc4ed:	ud2
 29fc4ef:	ud2
 29fc4f1:	ud2
 29fc4f3:	ud2
 29fc4f5:	ud2
 29fc4f7:	ud2
 29fc4f9:	ud2
 29fc4fb:	ud2
 29fc4fd:	ud2
 29fc4ff:	ud2
 29fc501:	ud2
 29fc503:	ud2
 29fc505:	ud2
 29fc507:	ud2
 29fc509:	ud2
 29fc50b:	ud2
 29fc50d:	ud2
 29fc50f:	ud2
 29fc511:	ud2
 29fc513:	ud2
 29fc515:	ud2
 29fc517:	ud2
 29fc519:	ud2
 29fc51b:	ud2
 29fc51d:	ud2
 29fc51f:	ud2
 29fc521:	ud2
 29fc523:	ud2
 29fc525:	ud2
 29fc527:	ud2
 29fc529:	ud2
 29fc52b:	ud2
 29fc52d:	ud2
 29fc52f:	ud2
 29fc531:	ud2
 29fc533:	ud2
 29fc535:	ud2
 29fc537:	ud2
 29fc539:	ud2
 29fc53b:	ud2
 29fc53d:	ud2
 29fc53f:	ud2
 29fc541:	ud2
 29fc543:	ud2
 29fc545:	ud2
 29fc547:	ud2
 29fc549:	ud2
 29fc54b:	ud2
 29fc54d:	ud2
 29fc54f:	ud2
 29fc551:	ud2
 29fc553:	ud2
 29fc555:	ud2
 29fc557:	ud2
 29fc559:	ud2
 29fc55b:	ud2
 29fc55d:	ud2
 29fc55f:	ud2
 29fc561:	ud2
 29fc563:	ud2
 29fc565:	ud2
 29fc567:	ud2
 29fc569:	ud2
 29fc56b:	ud2
 29fc56d:	ud2
 29fc56f:	ud2
 29fc571:	ud2
 29fc573:	ud2
 29fc575:	ud2
 29fc577:	ud2
 29fc579:	ud2
 29fc57b:	ud2
 29fc57d:	ud2
 29fc57f:	ud2
 29fc581:	ud2
 29fc583:	ud2
 29fc585:	ud2
 29fc587:	ud2
 29fc589:	ud2
 29fc58b:	ud2
 29fc58d:	ud2
 29fc58f:	ud2
 29fc591:	ud2
 29fc593:	ud2
 29fc595:	ud2
 29fc597:	ud2
 29fc599:	ud2
 29fc59b:	ud2
 29fc59d:	ud2
 29fc59f:	ud2
 29fc5a1:	ud2
 29fc5a3:	ud2
 29fc5a5:	ud2
 29fc5a7:	ud2
 29fc5a9:	ud2
 29fc5ab:	ud2
 29fc5ad:	ud2
 29fc5af:	ud2
 29fc5b1:	ud2
 29fc5b3:	ud2
 29fc5b5:	ud2
 29fc5b7:	ud2
 29fc5b9:	ud2
 29fc5bb:	ud2
 29fc5bd:	ud2
 29fc5bf:	ud2
 29fc5c1:	ud2
 29fc5c3:	ud2
 29fc5c5:	ud2
 29fc5c7:	ud2
 29fc5c9:	ud2
 29fc5cb:	ud2
 29fc5cd:	ud2
 29fc5cf:	ud2
 29fc5d1:	ud2
 29fc5d3:	ud2
 29fc5d5:	ud2
 29fc5d7:	ud2
 29fc5d9:	ud2
 29fc5db:	ud2
 29fc5dd:	ud2
 29fc5df:	ud2
 29fc5e1:	ud2
 29fc5e3:	ud2
 29fc5e5:	ud2
 29fc5e7:	ud2
 29fc5e9:	ud2
 29fc5eb:	ud2
 29fc5ed:	ud2
 29fc5ef:	ud2
 29fc5f1:	ud2
 29fc5f3:	ud2
 29fc5f5:	ud2
 29fc5f7:	ud2
 29fc5f9:	ud2
 29fc5fb:	ud2
 29fc5fd:	ud2
 29fc5ff:	ud2
 29fc601:	ud2
 29fc603:	ud2
 29fc605:	ud2
 29fc607:	ud2
 29fc609:	ud2
 29fc60b:	ud2
 29fc60d:	ud2
 29fc60f:	ud2
 29fc611:	ud2
 29fc613:	ud2
 29fc615:	ud2
 29fc617:	ud2
 29fc619:	ud2
 29fc61b:	ud2
 29fc61d:	ud2
 29fc61f:	ud2
 29fc621:	ud2
 29fc623:	ud2
 29fc625:	ud2
 29fc627:	ud2
 29fc629:	ud2
 29fc62b:	ud2
 29fc62d:	ud2
 29fc62f:	ud2
 29fc631:	ud2
 29fc633:	ud2
 29fc635:	ud2
 29fc637:	ud2
 29fc639:	ud2
 29fc63b:	ud2
 29fc63d:	ud2
 29fc63f:	ud2
 29fc641:	ud2
 29fc643:	ud2
 29fc645:	ud2
 29fc647:	ud2
 29fc649:	ud2
 29fc64b:	ud2
 29fc64d:	ud2
 29fc64f:	ud2
 29fc651:	ud2
 29fc653:	ud2
 29fc655:	ud2
 29fc657:	ud2
 29fc659:	ud2
 29fc65b:	ud2
 29fc65d:	ud2
 29fc65f:	ud2
 29fc661:	ud2
 29fc663:	ud2
 29fc665:	ud2
 29fc667:	ud2
 29fc669:	ud2
 29fc66b:	ud2
 29fc66d:	ud2
 29fc66f:	ud2
 29fc671:	ud2
 29fc673:	ud2
 29fc675:	ud2
 29fc677:	ud2
 29fc679:	ud2
 29fc67b:	ud2
 29fc67d:	ud2
 29fc67f:	ud2
 29fc681:	ud2
 29fc683:	ud2
 29fc685:	ud2
 29fc687:	ud2
 29fc689:	ud2
 29fc68b:	ud2
 29fc68d:	ud2
 29fc68f:	ud2
 29fc691:	ud2
 29fc693:	ud2
 29fc695:	ud2
 29fc697:	ud2
 29fc699:	ud2
 29fc69b:	ud2
 29fc69d:	ud2
 29fc69f:	ud2
 29fc6a1:	ud2
 29fc6a3:	ud2
 29fc6a5:	ud2
 29fc6a7:	ud2
 29fc6a9:	ud2
 29fc6ab:	ud2
 29fc6ad:	ud2
 29fc6af:	ud2
 29fc6b1:	ud2
 29fc6b3:	ud2
 29fc6b5:	ud2
 29fc6b7:	ud2
 29fc6b9:	ud2
 29fc6bb:	ud2
 29fc6bd:	ud2
 29fc6bf:	ud2
 29fc6c1:	ud2
 29fc6c3:	ud2
 29fc6c5:	ud2
 29fc6c7:	ud2
 29fc6c9:	ud2
 29fc6cb:	ud2
 29fc6cd:	ud2
 29fc6cf:	ud2
 29fc6d1:	ud2
 29fc6d3:	ud2
 29fc6d5:	ud2
 29fc6d7:	ud2
 29fc6d9:	ud2
 29fc6db:	ud2
 29fc6dd:	ud2
 29fc6df:	ud2
 29fc6e1:	ud2
 29fc6e3:	ud2
 29fc6e5:	ud2
 29fc6e7:	ud2
 29fc6e9:	ud2
 29fc6eb:	ud2
 29fc6ed:	ud2
 29fc6ef:	ud2
 29fc6f1:	ud2
 29fc6f3:	ud2
 29fc6f5:	ud2
 29fc6f7:	ud2
 29fc6f9:	ud2
 29fc6fb:	ud2
 29fc6fd:	ud2
 29fc6ff:	ud2
 29fc701:	ud2
 29fc703:	ud2
 29fc705:	ud2
 29fc707:	ud2
 29fc709:	ud2
 29fc70b:	ud2
 29fc70d:	ud2
 29fc70f:	ud2
 29fc711:	ud2
 29fc713:	ud2
 29fc715:	ud2
 29fc717:	ud2
 29fc719:	ud2
 29fc71b:	ud2
 29fc71d:	ud2
 29fc71f:	ud2
 29fc721:	ud2
 29fc723:	ud2
 29fc725:	ud2
 29fc727:	ud2
 29fc729:	ud2
 29fc72b:	ud2
 29fc72d:	ud2
 29fc72f:	ud2
 29fc731:	ud2
 29fc733:	ud2
 29fc735:	ud2
 29fc737:	ud2
 29fc739:	ud2
 29fc73b:	ud2
 29fc73d:	ud2
 29fc73f:	ud2
 29fc741:	ud2
 29fc743:	ud2
 29fc745:	ud2
 29fc747:	ud2
 29fc749:	ud2
 29fc74b:	ud2
 29fc74d:	ud2
 29fc74f:	ud2
 29fc751:	ud2
 29fc753:	ud2
 29fc755:	ud2
 29fc757:	ud2
 29fc759:	ud2
 29fc75b:	ud2
 29fc75d:	ud2
 29fc75f:	ud2
 29fc761:	ud2
 29fc763:	ud2
 29fc765:	ud2
 29fc767:	ud2
 29fc769:	ud2
 29fc76b:	ud2
 29fc76d:	ud2
 29fc76f:	ud2
 29fc771:	ud2
 29fc773:	ud2
 29fc775:	ud2
 29fc777:	ud2
 29fc779:	ud2
 29fc77b:	ud2
 29fc77d:	ud2
 29fc77f:	ud2
 29fc781:	ud2
 29fc783:	ud2
 29fc785:	ud2
 29fc787:	ud2
 29fc789:	ud2
 29fc78b:	ud2
 29fc78d:	ud2
 29fc78f:	ud2
 29fc791:	ud2
 29fc793:	ud2
 29fc795:	ud2
 29fc797:	ud2
 29fc799:	ud2
 29fc79b:	ud2
 29fc79d:	ud2
 29fc79f:	ud2
 29fc7a1:	ud2
 29fc7a3:	ud2
 29fc7a5:	ud2
 29fc7a7:	ud2
 29fc7a9:	ud2
 29fc7ab:	ud2
 29fc7ad:	ud2
 29fc7af:	ud2
 29fc7b1:	ud2
 29fc7b3:	ud2
 29fc7b5:	ud2
 29fc7b7:	ud2
 29fc7b9:	ud2
 29fc7bb:	ud2
 29fc7bd:	ud2
 29fc7bf:	ud2
 29fc7c1:	ud2
 29fc7c3:	ud2
 29fc7c5:	ud2
 29fc7c7:	ud2
 29fc7c9:	ud2
 29fc7cb:	ud2
 29fc7cd:	ud2
 29fc7cf:	ud2
 29fc7d1:	ud2
 29fc7d3:	ud2
 29fc7d5:	ud2
 29fc7d7:	ud2
 29fc7d9:	ud2
 29fc7db:	ud2
 29fc7dd:	ud2
 29fc7df:	ud2
 29fc7e1:	ud2
 29fc7e3:	ud2
 29fc7e5:	ud2
 29fc7e7:	ud2
 29fc7e9:	ud2
 29fc7eb:	ud2
 29fc7ed:	ud2
 29fc7ef:	ud2
 29fc7f1:	ud2
 29fc7f3:	ud2
 29fc7f5:	ud2
 29fc7f7:	ud2
 29fc7f9:	ud2
 29fc7fb:	ud2
 29fc7fd:	ud2
 29fc7ff:	ud2
 29fc801:	ud2
 29fc803:	ud2
 29fc805:	ud2
 29fc807:	ud2
 29fc809:	ud2
 29fc80b:	ud2
 29fc80d:	ud2
 29fc80f:	ud2
 29fc811:	ud2
 29fc813:	ud2
 29fc815:	ud2
 29fc817:	ud2
 29fc819:	ud2
 29fc81b:	ud2
 29fc81d:	ud2
 29fc81f:	ud2
 29fc821:	ud2
 29fc823:	ud2
 29fc825:	ud2
 29fc827:	ud2
 29fc829:	ud2
 29fc82b:	ud2
 29fc82d:	ud2
 29fc82f:	ud2
 29fc831:	ud2
 29fc833:	ud2
 29fc835:	ud2
 29fc837:	ud2
 29fc839:	ud2
 29fc83b:	ud2
 29fc83d:	ud2
 29fc83f:	ud2
 29fc841:	ud2
 29fc843:	ud2
 29fc845:	ud2
 29fc847:	ud2
 29fc849:	ud2
 29fc84b:	ud2
 29fc84d:	ud2
 29fc84f:	ud2
 29fc851:	ud2
 29fc853:	ud2
 29fc855:	ud2
 29fc857:	ud2
 29fc859:	ud2
 29fc85b:	ud2
 29fc85d:	ud2
 29fc85f:	ud2
 29fc861:	ud2
 29fc863:	ud2
 29fc865:	ud2
 29fc867:	ud2
 29fc869:	ud2
 29fc86b:	ud2
 29fc86d:	ud2
 29fc86f:	ud2
 29fc871:	ud2
 29fc873:	ud2
 29fc875:	ud2
 29fc877:	ud2
 29fc879:	ud2
 29fc87b:	ud2
 29fc87d:	ud2
 29fc87f:	ud2
 29fc881:	ud2
 29fc883:	ud2
 29fc885:	ud2
 29fc887:	ud2
 29fc889:	ud2
 29fc88b:	ud2
 29fc88d:	ud2
 29fc88f:	ud2
 29fc891:	ud2
 29fc893:	ud2
 29fc895:	ud2
 29fc897:	ud2
 29fc899:	ud2
 29fc89b:	ud2
 29fc89d:	ud2
 29fc89f:	ud2
 29fc8a1:	ud2
 29fc8a3:	ud2
 29fc8a5:	ud2
 29fc8a7:	ud2
 29fc8a9:	ud2
 29fc8ab:	ud2
 29fc8ad:	ud2
 29fc8af:	ud2
 29fc8b1:	ud2
 29fc8b3:	ud2
 29fc8b5:	ud2
 29fc8b7:	ud2
 29fc8b9:	ud2
 29fc8bb:	ud2
 29fc8bd:	ud2
 29fc8bf:	ud2
 29fc8c1:	ud2
 29fc8c3:	ud2
 29fc8c5:	ud2
 29fc8c7:	ud2
 29fc8c9:	ud2
 29fc8cb:	ud2
 29fc8cd:	ud2
 29fc8cf:	ud2
 29fc8d1:	ud2
 29fc8d3:	ud2
 29fc8d5:	ud2
 29fc8d7:	ud2
 29fc8d9:	ud2
 29fc8db:	ud2
 29fc8dd:	ud2
 29fc8df:	ud2
 29fc8e1:	ud2
 29fc8e3:	ud2
 29fc8e5:	ud2
 29fc8e7:	ud2
 29fc8e9:	ud2
 29fc8eb:	ud2
 29fc8ed:	ud2
 29fc8ef:	ud2
 29fc8f1:	ud2
 29fc8f3:	ud2
 29fc8f5:	ud2
 29fc8f7:	ud2
 29fc8f9:	ud2
 29fc8fb:	ud2
 29fc8fd:	ud2
 29fc8ff:	ud2
 29fc901:	ud2
 29fc903:	ud2
 29fc905:	add    %al,(%rax)
 29fc907:	add    %bh,%bh
 29fc909:	(bad)
 29fc90a:	(bad)
 29fc90b:	incl   (%rax)
	...
