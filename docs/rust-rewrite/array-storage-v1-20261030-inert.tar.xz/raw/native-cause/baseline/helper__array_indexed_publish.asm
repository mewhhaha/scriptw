
/workspace/scriptw/target/performance-dense-numbers-20261030/native-cause/baseline/runtime-portable.elf:     file format elf64-x86-64


Disassembly of section .text:

00000000029da9c0 <wasm[0]::function[1013]::helper::array_indexed_publish>:
 29da9c0:	push   %rbp
 29da9c1:	mov    %rsp,%rbp
 29da9c4:	mov    0x8(%rdi),%r10
 29da9c8:	mov    0x18(%r10),%r10
 29da9cc:	add    $0x110,%r10
 29da9d3:	cmp    %rsp,%r10
 29da9d6:	ja     29dfb3b <wasm[0]::function[1013]::helper::array_indexed_publish+0x517b>
 29da9dc:	sub    $0x100,%rsp
 29da9e3:	mov    %rbx,0xd0(%rsp)
 29da9eb:	mov    %r12,0xd8(%rsp)
 29da9f3:	mov    %r13,0xe0(%rsp)
 29da9fb:	mov    %r14,0xe8(%rsp)
 29daa03:	mov    %r15,0xf0(%rsp)
 29daa0b:	mov    %rcx,0x68(%rsp)
 29daa10:	mov    %edx,0x20(%rsp)
 29daa14:	mov    %r8d,0x18(%rsp)
 29daa19:	movl   $0x0,(%rsp)
 29daa20:	mov    0x18(%rdi),%rax
 29daa24:	mov    (%rax),%rcx
 29daa27:	mov    %rax,0xc8(%rsp)
 29daa2f:	mov    0x8(%rdi),%rdx
 29daa33:	mov    %rdi,0x60(%rsp)
 29daa38:	mov    0x8(%rdx),%rax
 29daa3c:	mov    %rdx,0xc0(%rsp)
 29daa44:	cmp    %rax,%rcx
 29daa47:	jae    29defef <wasm[0]::function[1013]::helper::array_indexed_publish+0x462f>
 29daa4d:	mov    0x68(%rsp),%rcx
 29daa52:	mov    %rax,0xa0(%rsp)
 29daa5a:	cmp    0x53d7(%rip),%rcx        # 29dfe38 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5478>
 29daa61:	mov    %rcx,0x68(%rsp)
 29daa66:	jae    29dfb3d <wasm[0]::function[1013]::helper::array_indexed_publish+0x517d>
 29daa6c:	mov    0x20(%rsp),%r13d
 29daa71:	xor    %r10d,%r10d
 29daa74:	test   %r13d,%r13d
 29daa77:	je     29dfb3f <wasm[0]::function[1013]::helper::array_indexed_publish+0x517f>
 29daa7d:	test   %r13d,%r13d
 29daa80:	je     29dfb41 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5181>
 29daa86:	mov    0xc0(%rsp),%rsi
 29daa8e:	mov    0x28(%rsi),%rax
 29daa92:	mov    0x20(%rsi),%rdi
 29daa96:	mov    %r13d,%r8d
 29daa99:	xor    %rdx,%rdx
 29daa9c:	add    %r8,%rdi
 29daa9f:	cmp    %rax,%r8
 29daaa2:	cmova  %rdx,%rdi
 29daaa6:	mov    0x24(%rdi),%eax
 29daaa9:	mov    0x18(%rsp),%edx
 29daaad:	cmp    $0x2,%eax
 29daab0:	sete   %dil
 29daab4:	cmp    $0x3,%eax
 29daab7:	sete   %al
 29daaba:	or     %eax,%edi
 29daabc:	test   %dil,%dil
 29daabf:	jne    29daad7 <wasm[0]::function[1013]::helper::array_indexed_publish+0x117>
 29daac5:	mov    %r13,0x70(%rsp)
 29daaca:	mov    %rsi,0xc0(%rsp)
 29daad2:	jmp    29dd538 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2b78>
 29daad7:	mov    0x18(%rsp),%edx
 29daadb:	xor    %r10d,%r10d
 29daade:	test   %edx,%edx
 29daae0:	je     29dfb43 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5183>
 29daae6:	test   %edx,%edx
 29daae8:	je     29dfb45 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5185>
 29daaee:	mov    0x28(%rsi),%rax
 29daaf2:	mov    %edx,%edi
 29daaf4:	mov    %rdi,%rcx
 29daaf7:	add    0x20(%rsi),%rcx
 29daafb:	xor    %r8,%r8
 29daafe:	cmp    %rax,%rdi
 29dab01:	cmova  %r8,%rcx
 29dab05:	mov    0x10(%rcx),%eax
 29dab08:	mov    0x20(%rsp),%r13d
 29dab0d:	cmp    $0xe,%eax
 29dab10:	je     29dab28 <wasm[0]::function[1013]::helper::array_indexed_publish+0x168>
 29dab16:	mov    %r13,0x70(%rsp)
 29dab1b:	mov    %rsi,0xc0(%rsp)
 29dab23:	jmp    29dc9df <wasm[0]::function[1013]::helper::array_indexed_publish+0x201f>
 29dab28:	mov    0x18(%rsp),%eax
 29dab2c:	test   %eax,%eax
 29dab2e:	je     29dfb47 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5187>
 29dab34:	test   %eax,%eax
 29dab36:	je     29dfb49 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5189>
 29dab3c:	mov    0x28(%rsi),%rcx
 29dab40:	mov    0x20(%rsi),%rdi
 29dab44:	mov    %eax,%edx
 29dab46:	lea    (%rdi,%rdx,1),%rax
 29dab4a:	xor    %rdi,%rdi
 29dab4d:	cmp    %rcx,%rdx
 29dab50:	cmova  %rdi,%rax
 29dab54:	mov    0x14(%rax),%edx
 29dab57:	test   %edx,%edx
 29dab59:	je     29dfb4b <wasm[0]::function[1013]::helper::array_indexed_publish+0x518b>
 29dab5f:	xor    %eax,%eax
 29dab61:	test   $0x1,%edx
 29dab67:	je     29dab7a <wasm[0]::function[1013]::helper::array_indexed_publish+0x1ba>
 29dab6d:	mov    %rsi,0xc0(%rsp)
 29dab75:	jmp    29dabb2 <wasm[0]::function[1013]::helper::array_indexed_publish+0x1f2>
 29dab7a:	mov    0x28(%rsi),%rax
 29dab7e:	mov    0x20(%rsi),%rcx
 29dab82:	mov    %rsi,0xc0(%rsp)
 29dab8a:	mov    %edx,%esi
 29dab8c:	lea    0x4(%rcx,%rsi,1),%rcx
 29dab91:	xor    %rdi,%rdi
 29dab94:	cmp    %rax,%rsi
 29dab97:	cmova  %rdi,%rcx
 29dab9b:	mov    (%rcx),%eax
 29dab9d:	mov    0x60(%rsp),%rdi
 29daba2:	mov    0x28(%rdi),%rcx
 29daba6:	cmp    0x120(%rcx),%eax
 29dabac:	sete   %al
 29dabaf:	movzbl %al,%eax
 29dabb2:	test   %eax,%eax
 29dabb4:	jne    29dac19 <wasm[0]::function[1013]::helper::array_indexed_publish+0x259>
 29dabba:	mov    0x60(%rsp),%rsi
 29dabbf:	mov    0x60(%rsp),%rdi
 29dabc4:	call   2a01c00 <wasm[0]::function[1024]::helper::property_value_resolve>
 29dabc9:	test   %eax,%eax
 29dabcb:	je     29dfb4d <wasm[0]::function[1013]::helper::array_indexed_publish+0x518d>
 29dabd1:	test   %eax,%eax
 29dabd3:	je     29dfb4f <wasm[0]::function[1013]::helper::array_indexed_publish+0x518f>
 29dabd9:	mov    0xc0(%rsp),%r14
 29dabe1:	mov    0x28(%r14),%rcx
 29dabe5:	mov    0x20(%r14),%rsi
 29dabe9:	mov    %eax,%edx
 29dabeb:	lea    (%rsi,%rdx,1),%rax
 29dabef:	xor    %rsi,%rsi
 29dabf2:	cmp    %rcx,%rdx
 29dabf5:	cmova  %rsi,%rax
 29dabf9:	mov    0x18(%rax),%r14d
 29dabfd:	mov    0x10(%rax),%r12
 29dac01:	mov    %r12,0x88(%rsp)
 29dac09:	mov    0x1c(%rax),%esi
 29dac0c:	mov    %r14,0x90(%rsp)
 29dac14:	jmp    29dacad <wasm[0]::function[1013]::helper::array_indexed_publish+0x2ed>
 29dac19:	xor    %eax,%eax
 29dac1b:	test   $0x1,%edx
 29dac21:	jne    29dac61 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2a1>
 29dac27:	mov    0xc0(%rsp),%r14
 29dac2f:	mov    0x28(%r14),%rsi
 29dac33:	mov    0x20(%r14),%r8
 29dac37:	mov    %edx,%edi
 29dac39:	lea    0x4(%r8,%rdi,1),%rax
 29dac3e:	xor    %r8,%r8
 29dac41:	cmp    %rsi,%rdi
 29dac44:	cmova  %r8,%rax
 29dac48:	mov    (%rax),%esi
 29dac4a:	mov    0x60(%rsp),%rdi
 29dac4f:	mov    0x28(%rdi),%rdi
 29dac53:	cmp    0x120(%rdi),%esi
 29dac59:	sete   %sil
 29dac5d:	movzbl %sil,%eax
 29dac61:	test   %eax,%eax
 29dac63:	je     29dfb51 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5191>
 29dac69:	test   %edx,%edx
 29dac6b:	je     29dfb53 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5193>
 29dac71:	mov    0xc0(%rsp),%r14
 29dac79:	mov    0x28(%r14),%r10
 29dac7d:	mov    0x20(%r14),%rax
 29dac81:	mov    %edx,%r11d
 29dac84:	lea    (%rax,%r11,1),%rdi
 29dac88:	xor    %rax,%rax
 29dac8b:	cmp    %r10,%r11
 29dac8e:	cmova  %rax,%rdi
 29dac92:	mov    0x18(%rdi),%r14d
 29dac96:	mov    %r14,0x90(%rsp)
 29dac9e:	mov    0x10(%rdi),%r12
 29daca2:	mov    %r12,0x88(%rsp)
 29dacaa:	mov    0x1c(%rdi),%esi
 29dacad:	mov    0x20(%rsp),%r13d
 29dacb2:	xor    %r10d,%r10d
 29dacb5:	test   %r13d,%r13d
 29dacb8:	je     29dfb55 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5195>
 29dacbe:	test   %r13d,%r13d
 29dacc1:	je     29dfb57 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5197>
 29dacc7:	mov    0xc0(%rsp),%r14
 29daccf:	mov    0x28(%r14),%rax
 29dacd3:	mov    %r13d,%edi
 29dacd6:	mov    %rdi,%rdx
 29dacd9:	add    0x20(%r14),%rdx
 29dacdd:	xor    %rbx,%rbx
 29dace0:	mov    %rbx,0x80(%rsp)
 29dace8:	cmp    %rax,%rdi
 29daceb:	cmova  %rbx,%rdx
 29dacef:	mov    0x24(%rdx),%eax
 29dacf2:	mov    (%rsp),%edi
 29dacf5:	mov    0x18(%rsp),%edx
 29dacf9:	cmp    $0x2,%eax
 29dacfc:	sete   %al
 29dacff:	mov    0x90(%rsp),%r14
 29dad07:	cmp    $0x3,%r14d
 29dad0b:	sete   %cl
 29dad0e:	test   %al,%cl
 29dad10:	jne    29dad20 <wasm[0]::function[1013]::helper::array_indexed_publish+0x360>
 29dad16:	mov    %r13,0x70(%rsp)
 29dad1b:	jmp    29dbb0b <wasm[0]::function[1013]::helper::array_indexed_publish+0x114b>
 29dad20:	mov    0x20(%rsp),%r13d
 29dad25:	xor    %r10d,%r10d
 29dad28:	test   %r13d,%r13d
 29dad2b:	je     29dfb59 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5199>
 29dad31:	test   %r13d,%r13d
 29dad34:	je     29dfb5b <wasm[0]::function[1013]::helper::array_indexed_publish+0x519b>
 29dad3a:	mov    0xc0(%rsp),%r14
 29dad42:	mov    0x28(%r14),%rax
 29dad46:	mov    0x20(%r14),%rdi
 29dad4a:	mov    %r13d,%r8d
 29dad4d:	mov    %r13,0x70(%rsp)
 29dad52:	lea    (%rdi,%r8,1),%rdx
 29dad56:	xor    %r11,%r11
 29dad59:	cmp    %rax,%r8
 29dad5c:	cmova  %r11,%rdx
 29dad60:	mov    0x28(%rdx),%r9d
 29dad64:	mov    0x2c(%rdx),%r8d
 29dad68:	test   %r9d,%r9d
 29dad6b:	je     29dfb5d <wasm[0]::function[1013]::helper::array_indexed_publish+0x519d>
 29dad71:	test   %r9d,%r9d
 29dad74:	je     29dfb5f <wasm[0]::function[1013]::helper::array_indexed_publish+0x519f>
 29dad7a:	mov    %r9d,%ebx
 29dad7d:	lea    0x10(%rdi,%rbx,1),%rdi
 29dad82:	cmp    %rax,%rbx
 29dad85:	cmova  %r11,%rdi
 29dad89:	mov    (%rdi),%r13d
 29dad8c:	mov    0x18(%rdx),%rbx
 29dad90:	mov    %rbx,0x80(%rsp)
 29dad98:	mov    (%rsp),%edi
 29dad9b:	mov    0x18(%rsp),%edx
 29dad9f:	mov    %r13d,%r14d
 29dada2:	mov    0x68(%rsp),%rcx
 29dada7:	cmp    %r14,%rcx
 29dadaa:	setb   %al
 29dadad:	cmp    $0x100000,%rcx
 29dadb4:	setb   %r11b
 29dadb8:	mov    0x80(%rsp),%rcx
 29dadc0:	lea    0x8(%rbx,%rcx,1),%rcx
 29dadc5:	mov    0x68(%rsp),%rbx
 29dadca:	cmp    %rcx,%rbx
 29dadcd:	setbe  %bl
 29dadd0:	and    %ebx,%r11d
 29dadd3:	or     %r11d,%eax
 29dadd6:	test   %al,%al
 29dadd8:	je     29dbb06 <wasm[0]::function[1013]::helper::array_indexed_publish+0x1146>
 29dadde:	mov    0x20(%rsp),%eax
 29dade2:	mov    %rax,0x70(%rsp)
 29dade7:	mov    (%rsp),%edi
 29dadea:	mov    0x18(%rsp),%edx
 29dadee:	mov    0x68(%rsp),%rcx
 29dadf3:	cmp    %r14,%rcx
 29dadf6:	jb     29db8c7 <wasm[0]::function[1013]::helper::array_indexed_publish+0xf07>
 29dadfc:	test   %r13d,%r13d
 29dadff:	jne    29dae0b <wasm[0]::function[1013]::helper::array_indexed_publish+0x44b>
 29dae05:	mov    $0x4,%r13d
 29dae0b:	mov    %r9d,0x30(%rsp)
 29dae10:	mov    %r8d,0x58(%rsp)
 29dae15:	mov    0x70(%rsp),%rax
 29dae1a:	mov    %eax,0x10(%rsp)
 29dae1e:	mov    %edi,0x18(%rsp)
 29dae22:	mov    %esi,(%rsp)
 29dae25:	mov    %edx,0x20(%rsp)
 29dae29:	mov    0xc8(%rsp),%r12
 29dae31:	mov    (%r12),%rax
 29dae35:	mov    0xa0(%rsp),%rcx
 29dae3d:	cmp    %rcx,%rax
 29dae40:	jae    29df00b <wasm[0]::function[1013]::helper::array_indexed_publish+0x464b>
 29dae46:	mov    %r13d,%ebx
 29dae49:	mov    0x68(%rsp),%rcx
 29dae4e:	cmp    %rbx,%rcx
 29dae51:	jb     29dae7d <wasm[0]::function[1013]::helper::array_indexed_publish+0x4bd>
 29dae57:	mov    0x30(%rsp),%r9d
 29dae5c:	mov    0x58(%rsp),%r8d
 29dae61:	mov    0x10(%rsp),%eax
 29dae65:	mov    %rax,0x70(%rsp)
 29dae6a:	mov    0x18(%rsp),%edi
 29dae6e:	mov    (%rsp),%esi
 29dae71:	mov    0x20(%rsp),%edx
 29dae75:	shl    $1,%r13d
 29dae78:	jmp    29dae0b <wasm[0]::function[1013]::helper::array_indexed_publish+0x44b>
 29dae7d:	mov    %rbx,%rcx
 29dae80:	shl    $0x3,%rcx
 29dae84:	mov    %rcx,%rax
 29dae87:	shr    $0x20,%rax
 29dae8b:	mov    %rcx,%r15
 29dae8e:	test   %rax,%rax
 29dae91:	jne    29dfb61 <wasm[0]::function[1013]::helper::array_indexed_publish+0x51a1>
 29dae97:	mov    %r13,%rcx
 29dae9a:	shl    $0x3,%ecx
 29dae9d:	add    $0x18,%ecx
 29daea0:	jb     29dfb63 <wasm[0]::function[1013]::helper::array_indexed_publish+0x51a3>
 29daea6:	mov    0x60(%rsp),%rdi
 29daeab:	mov    0x20(%rdi),%rdi
 29daeaf:	mov    (%rdi),%eax
 29daeb1:	mov    %eax,%edx
 29daeb3:	mov    %ecx,%esi
 29daeb5:	add    $0xf,%rsi
 29daebc:	mov    %rsi,%r8
 29daebf:	and    $0xfffffffffffffff0,%r8
 29daec3:	add    %rdx,%r8
 29daec6:	mov    0x4(%rdi),%r9d
 29daeca:	mov    %rdi,0xa8(%rsp)
 29daed2:	cmp    %r9,%r8
 29daed5:	ja     29df03f <wasm[0]::function[1013]::helper::array_indexed_publish+0x467f>
 29daedb:	lea    0xf(%rcx),%edi
 29daede:	and    $0xfffffff0,%edi
 29daee1:	add    %eax,%edi
 29daee3:	mov    0xa8(%rsp),%rcx
 29daeeb:	mov    %edi,(%rcx)
 29daeed:	mov    0xc0(%rsp),%rcx
 29daef5:	mov    0x20(%rcx),%rdi
 29daef9:	lea    (%rdi,%rdx,1),%rcx
 29daefd:	movl   $0xa8000006,(%rdi,%rdx,1)
 29daf04:	mov    0x60(%rsp),%r8
 29daf09:	mov    0x28(%r8),%r8
 29daf0d:	mov    0x1a0(%r8),%r8d
 29daf14:	mov    %r8d,0x4(%rdi,%rdx,1)
 29daf19:	and    $0xfffffffffffffff0,%rsi
 29daf1d:	mov    %esi,0x8(%rdi,%rdx,1)
 29daf21:	mov    %eax,0x28(%rsp)
 29daf25:	mov    %r13d,0x10(%rcx)
 29daf29:	test   %eax,%eax
 29daf2b:	je     29dfb65 <wasm[0]::function[1013]::helper::array_indexed_publish+0x51a5>
 29daf31:	mov    0xc0(%rsp),%rsi
 29daf39:	mov    0x28(%rsi),%rcx
 29daf3d:	mov    0x20(%rsi),%rdx
 29daf41:	mov    %eax,%eax
 29daf43:	lea    0x10(%rdx,%rax,1),%r11
 29daf48:	xor    %rsi,%rsi
 29daf4b:	cmp    %rcx,%rax
 29daf4e:	cmova  %rsi,%r11
 29daf52:	mov    (%r11),%esi
 29daf55:	cmp    %rsi,%rbx
 29daf58:	ja     29dfb67 <wasm[0]::function[1013]::helper::array_indexed_publish+0x51a7>
 29daf5e:	lea    0x18(%rdx,%rax,1),%rsi
 29daf63:	mov    %r15,%r9
 29daf66:	mov    %rsi,%rax
 29daf69:	add    %r9,%rax
 29daf6c:	mov    %rsi,%rbx
 29daf6f:	jb     29dfb69 <wasm[0]::function[1013]::helper::array_indexed_publish+0x51a9>
 29daf75:	add    %rdx,%rcx
 29daf78:	cmp    %rcx,%rax
 29daf7b:	ja     29dfb6b <wasm[0]::function[1013]::helper::array_indexed_publish+0x51ab>
 29daf81:	mov    0x30(%rsp),%r8d
 29daf86:	mov    0x58(%rsp),%edi
 29daf8a:	mov    0x10(%rsp),%esi
 29daf8e:	mov    0x18(%rsp),%edx
 29daf92:	mov    (%rsp),%ecx
 29daf95:	mov    0x20(%rsp),%eax
 29daf99:	cmp    $0x8000000,%r9
 29dafa0:	jbe    29db031 <wasm[0]::function[1013]::helper::array_indexed_publish+0x671>
 29dafa6:	mov    %r8d,0x20(%rsp)
 29dafab:	mov    %edi,(%rsp)
 29dafae:	mov    %esi,0x18(%rsp)
 29dafb2:	mov    %edx,0x10(%rsp)
 29dafb6:	mov    %ecx,0x58(%rsp)
 29dafba:	mov    %eax,0x30(%rsp)
 29dafbe:	mov    0xc8(%rsp),%r12
 29dafc6:	mov    (%r12),%rax
 29dafca:	mov    0xa0(%rsp),%rsi
 29dafd2:	cmp    %rsi,%rax
 29dafd5:	jae    29df076 <wasm[0]::function[1013]::helper::array_indexed_publish+0x46b6>
 29dafdb:	xor    %edx,%edx
 29dafdd:	mov    $0x8000000,%ecx
 29dafe2:	mov    %rbx,%rsi
 29dafe5:	mov    0x60(%rsp),%rdi
 29dafea:	call   3018b23 <wasmtime_builtin_memory_fill>
 29dafef:	mov    0x20(%rsp),%r8d
 29daff4:	mov    (%rsp),%edi
 29daff7:	mov    0x18(%rsp),%esi
 29daffb:	mov    0x10(%rsp),%edx
 29dafff:	mov    0x58(%rsp),%ecx
 29db003:	mov    0x30(%rsp),%eax
 29db007:	mov    %r15,%r9
 29db00a:	sub    $0x8000000,%r9
 29db011:	mov    %r9,%r15
 29db014:	mov    %rbx,%r9
 29db017:	add    $0x8000000,%r9
 29db01e:	mov    %r9,%rbx
 29db021:	mov    %r15,%r9
 29db024:	cmp    $0x8000000,%r9
 29db02b:	ja     29dafa6 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5e6>
 29db031:	mov    %r8d,0x30(%rsp)
 29db036:	mov    %edi,0x58(%rsp)
 29db03a:	mov    %esi,0x10(%rsp)
 29db03e:	mov    %edx,0x18(%rsp)
 29db042:	mov    %ecx,(%rsp)
 29db045:	mov    %eax,0x20(%rsp)
 29db049:	mov    0xc8(%rsp),%r12
 29db051:	mov    (%r12),%rax
 29db055:	mov    0xa0(%rsp),%rcx
 29db05d:	cmp    %rcx,%rax
 29db060:	jae    29df0ad <wasm[0]::function[1013]::helper::array_indexed_publish+0x46ed>
 29db066:	xor    %edx,%edx
 29db068:	mov    %r15,%rcx
 29db06b:	mov    %rbx,%rsi
 29db06e:	mov    0x60(%rsp),%rdi
 29db073:	call   3018b23 <wasmtime_builtin_memory_fill>
 29db078:	mov    0x28(%rsp),%edx
 29db07c:	test   %edx,%edx
 29db07e:	je     29dfb6d <wasm[0]::function[1013]::helper::array_indexed_publish+0x51ad>
 29db084:	mov    0x30(%rsp),%ecx
 29db088:	test   %ecx,%ecx
 29db08a:	je     29dfb6f <wasm[0]::function[1013]::helper::array_indexed_publish+0x51af>
 29db090:	test   %edx,%edx
 29db092:	je     29dfb71 <wasm[0]::function[1013]::helper::array_indexed_publish+0x51b1>
 29db098:	mov    0xc0(%rsp),%rax
 29db0a0:	mov    0x28(%rax),%rax
 29db0a4:	mov    0xc0(%rsp),%rsi
 29db0ac:	mov    0x20(%rsi),%r9
 29db0b0:	mov    %edx,%r10d
 29db0b3:	lea    (%r9,%r10,1),%r11
 29db0b7:	lea    0x10(%r9,%r10,1),%rsi
 29db0bc:	xor    %rdx,%rdx
 29db0bf:	cmp    %rax,%r10
 29db0c2:	cmova  %rdx,%rsi
 29db0c6:	mov    (%rsi),%esi
 29db0c8:	cmp    %rsi,%r14
 29db0cb:	ja     29dfb73 <wasm[0]::function[1013]::helper::array_indexed_publish+0x51b3>
 29db0d1:	test   %ecx,%ecx
 29db0d3:	je     29dfb75 <wasm[0]::function[1013]::helper::array_indexed_publish+0x51b5>
 29db0d9:	mov    %ecx,%r15d
 29db0dc:	lea    (%r9,%r15,1),%rbx
 29db0e0:	lea    0x10(%r9,%r15,1),%rsi
 29db0e5:	cmp    %rax,%r15
 29db0e8:	cmova  %rdx,%rsi
 29db0ec:	mov    (%rsi),%esi
 29db0ee:	cmp    %rsi,%r14
 29db0f1:	ja     29dfb77 <wasm[0]::function[1013]::helper::array_indexed_publish+0x51b7>
 29db0f7:	lea    0x18(%r9,%r10,1),%rdi
 29db0fc:	mov    %r14,%r12
 29db0ff:	shl    $0x3,%r12
 29db103:	mov    %rdi,%rcx
 29db106:	add    %r12,%rcx
 29db109:	jb     29dfb79 <wasm[0]::function[1013]::helper::array_indexed_publish+0x51b9>
 29db10f:	lea    (%r9,%rax,1),%r8
 29db113:	cmp    %r8,%rcx
 29db116:	ja     29dfb7b <wasm[0]::function[1013]::helper::array_indexed_publish+0x51bb>
 29db11c:	lea    0x18(%r9,%r15,1),%rax
 29db121:	mov    %rax,%rcx
 29db124:	add    %r12,%rcx
 29db127:	jb     29dfb7d <wasm[0]::function[1013]::helper::array_indexed_publish+0x51bd>
 29db12d:	cmp    %r8,%rcx
 29db130:	ja     29dfb7f <wasm[0]::function[1013]::helper::array_indexed_publish+0x51bf>
 29db136:	cmp    %rdi,%rax
 29db139:	ja     29db23f <wasm[0]::function[1013]::helper::array_indexed_publish+0x87f>
 29db13f:	mov    0x58(%rsp),%eax
 29db143:	mov    0x10(%rsp),%ecx
 29db147:	mov    0x28(%rsp),%edx
 29db14b:	mov    0x18(%rsp),%esi
 29db14f:	mov    (%rsp),%edi
 29db152:	mov    0x20(%rsp),%r8d
 29db157:	lea    0x18(%r11,%r14,8),%r9
 29db15c:	mov    %r9,0x78(%rsp)
 29db161:	lea    0x18(%rbx,%r14,8),%r9
 29db166:	mov    %r9,%r15
 29db169:	cmp    $0x8000000,%r12
 29db170:	mov    %r12,%rbx
 29db173:	ja     29db186 <wasm[0]::function[1013]::helper::array_indexed_publish+0x7c6>
 29db179:	mov    0x78(%rsp),%r9
 29db17e:	mov    %rbx,%r11
 29db181:	jmp    29db226 <wasm[0]::function[1013]::helper::array_indexed_publish+0x866>
 29db186:	mov    %eax,0x8(%rsp)
 29db18a:	mov    %ecx,0x50(%rsp)
 29db18e:	mov    %edx,0x48(%rsp)
 29db192:	mov    %esi,0x40(%rsp)
 29db196:	mov    %edi,0x38(%rsp)
 29db19a:	mov    %r8d,0x30(%rsp)
 29db19f:	mov    0xc8(%rsp),%r12
 29db1a7:	mov    (%r12),%rax
 29db1ab:	mov    0xa0(%rsp),%rcx
 29db1b3:	cmp    %rcx,%rax
 29db1b6:	jae    29df0e1 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4721>
 29db1bc:	mov    $0x8000000,%ecx
 29db1c1:	mov    0x78(%rsp),%rsi
 29db1c6:	sub    $0x8000000,%rsi
 29db1cd:	mov    %r15,%rdx
 29db1d0:	mov    %rsi,0x78(%rsp)
 29db1d5:	sub    $0x8000000,%rdx
 29db1dc:	mov    %rdx,%r15
 29db1df:	mov    0x60(%rsp),%rdi
 29db1e4:	call   3018afa <wasmtime_builtin_memory_copy>
 29db1e9:	mov    0x8(%rsp),%eax
 29db1ed:	mov    0x50(%rsp),%ecx
 29db1f1:	mov    0x48(%rsp),%edx
 29db1f5:	mov    0x40(%rsp),%esi
 29db1f9:	mov    0x38(%rsp),%edi
 29db1fd:	mov    0x30(%rsp),%r8d
 29db202:	mov    %rbx,%r11
 29db205:	sub    $0x8000000,%r11
 29db20c:	cmp    $0x8000000,%r11
 29db213:	jbe    29db221 <wasm[0]::function[1013]::helper::array_indexed_publish+0x861>
 29db219:	mov    %r11,%rbx
 29db21c:	jmp    29db186 <wasm[0]::function[1013]::helper::array_indexed_publish+0x7c6>
 29db221:	mov    0x78(%rsp),%r9
 29db226:	sub    %r11,%r9
 29db229:	mov    %r9,0x78(%rsp)
 29db22e:	mov    %r15,%r9
 29db231:	sub    %r11,%r9
 29db234:	mov    %r9,%r15
 29db237:	mov    %r11,%rbx
 29db23a:	jmp    29db31e <wasm[0]::function[1013]::helper::array_indexed_publish+0x95e>
 29db23f:	mov    %r12,%r11
 29db242:	mov    0x58(%rsp),%eax
 29db246:	mov    0x10(%rsp),%ecx
 29db24a:	mov    0x28(%rsp),%edx
 29db24e:	mov    0x18(%rsp),%esi
 29db252:	mov    (%rsp),%edi
 29db255:	mov    0x20(%rsp),%r8d
 29db25a:	lea    0x18(%r9,%r10,1),%r10
 29db25f:	mov    %r10,0x78(%rsp)
 29db264:	lea    0x18(%r9,%r15,1),%r9
 29db269:	mov    %r9,%r15
 29db26c:	cmp    $0x8000000,%r11
 29db273:	mov    %r11,%rbx
 29db276:	jbe    29db31e <wasm[0]::function[1013]::helper::array_indexed_publish+0x95e>
 29db27c:	mov    %eax,0x20(%rsp)
 29db280:	mov    %ecx,(%rsp)
 29db283:	mov    %edx,0x18(%rsp)
 29db287:	mov    %esi,0x28(%rsp)
 29db28b:	mov    %edi,0x10(%rsp)
 29db28f:	mov    %r8d,0x58(%rsp)
 29db294:	mov    0xc8(%rsp),%r12
 29db29c:	mov    (%r12),%rax
 29db2a0:	mov    0xa0(%rsp),%rcx
 29db2a8:	cmp    %rcx,%rax
 29db2ab:	jae    29df115 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4755>
 29db2b1:	mov    $0x8000000,%ecx
 29db2b6:	mov    %r15,%rdx
 29db2b9:	mov    0x78(%rsp),%rsi
 29db2be:	mov    0x60(%rsp),%rdi
 29db2c3:	call   3018afa <wasmtime_builtin_memory_copy>
 29db2c8:	mov    0x20(%rsp),%eax
 29db2cc:	mov    (%rsp),%ecx
 29db2cf:	mov    0x18(%rsp),%edx
 29db2d3:	mov    0x28(%rsp),%esi
 29db2d7:	mov    0x10(%rsp),%edi
 29db2db:	mov    0x58(%rsp),%r8d
 29db2e0:	mov    %rbx,%r10
 29db2e3:	mov    %r10,%r11
 29db2e6:	sub    $0x8000000,%r11
 29db2ed:	mov    %r11,%rbx
 29db2f0:	mov    0x78(%rsp),%r9
 29db2f5:	add    $0x8000000,%r9
 29db2fc:	mov    %r9,0x78(%rsp)
 29db301:	mov    %r15,%r9
 29db304:	add    $0x8000000,%r9
 29db30b:	mov    %r9,%r15
 29db30e:	mov    %rbx,%r9
 29db311:	cmp    $0x8000000,%r9
 29db318:	ja     29db27c <wasm[0]::function[1013]::helper::array_indexed_publish+0x8bc>
 29db31e:	mov    %eax,0x58(%rsp)
 29db322:	mov    %ecx,0x10(%rsp)
 29db326:	mov    %edx,0x28(%rsp)
 29db32a:	mov    %esi,0x18(%rsp)
 29db32e:	mov    %edi,(%rsp)
 29db331:	mov    %r8d,0x20(%rsp)
 29db336:	mov    0xc8(%rsp),%r12
 29db33e:	mov    (%r12),%rsi
 29db342:	mov    0xa0(%rsp),%rax
 29db34a:	cmp    %rax,%rsi
 29db34d:	jae    29df149 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4789>
 29db353:	mov    %rbx,%rcx
 29db356:	mov    %r15,%rdx
 29db359:	mov    0x78(%rsp),%rsi
 29db35e:	jmp    29db36e <wasm[0]::function[1013]::helper::array_indexed_publish+0x9ae>
 29db363:	mov    %rbx,%rcx
 29db366:	mov    %r15,%rdx
 29db369:	mov    0x78(%rsp),%rsi
 29db36e:	mov    %rbx,%rcx
 29db371:	mov    %r15,%rdx
 29db374:	mov    0x78(%rsp),%rsi
 29db379:	mov    0x60(%rsp),%rdi
 29db37e:	call   3018afa <wasmtime_builtin_memory_copy>
 29db383:	add    $0x3f,%r13d
 29db38a:	shr    $0x6,%r13d
 29db38e:	mov    %r13,%rcx
 29db391:	shl    $0x3,%rcx
 29db395:	mov    %rcx,%r11
 29db398:	shr    $0x20,%r11
 29db39c:	mov    %rcx,%rbx
 29db39f:	test   %r11,%r11
 29db3a2:	jne    29dfb81 <wasm[0]::function[1013]::helper::array_indexed_publish+0x51c1>
 29db3a8:	mov    %r13,%rcx
 29db3ab:	shl    $0x3,%ecx
 29db3ae:	add    $0x18,%ecx
 29db3b1:	jb     29dfb83 <wasm[0]::function[1013]::helper::array_indexed_publish+0x51c3>
 29db3b7:	mov    0xa8(%rsp),%r14
 29db3bf:	mov    (%r14),%eax
 29db3c2:	mov    %eax,%edx
 29db3c4:	mov    %ecx,%esi
 29db3c6:	add    $0xf,%rsi
 29db3cd:	and    $0xfffffffffffffff0,%rsi
 29db3d1:	lea    (%rdx,%rsi,1),%rdi
 29db3d5:	mov    0x4(%r14),%r8d
 29db3d9:	cmp    %r8,%rdi
 29db3dc:	ja     29df188 <wasm[0]::function[1013]::helper::array_indexed_publish+0x47c8>
 29db3e2:	add    $0xf,%ecx
 29db3e8:	and    $0xfffffff0,%ecx
 29db3eb:	add    %eax,%ecx
 29db3ed:	mov    %ecx,(%r14)
 29db3f0:	mov    0xc0(%rsp),%r14
 29db3f8:	mov    0x20(%r14),%rdi
 29db3fc:	lea    (%rdi,%rdx,1),%rcx
 29db400:	movl   $0xa8000006,(%rdi,%rdx,1)
 29db407:	mov    0x60(%rsp),%r8
 29db40c:	mov    0x28(%r8),%r8
 29db410:	mov    0x1a4(%r8),%r8d
 29db417:	mov    %r8d,0x4(%rdi,%rdx,1)
 29db41c:	mov    %esi,0x8(%rdi,%rdx,1)
 29db420:	mov    %eax,0x8(%rsp)
 29db424:	mov    %r13d,0x10(%rcx)
 29db428:	test   %eax,%eax
 29db42a:	je     29dfb85 <wasm[0]::function[1013]::helper::array_indexed_publish+0x51c5>
 29db430:	mov    0xc0(%rsp),%r14
 29db438:	mov    0x28(%r14),%rcx
 29db43c:	mov    0x20(%r14),%rdx
 29db440:	mov    %eax,%eax
 29db442:	lea    0x10(%rdx,%rax,1),%rsi
 29db447:	xor    %rdi,%rdi
 29db44a:	cmp    %rcx,%rax
 29db44d:	cmova  %rdi,%rsi
 29db451:	mov    (%rsi),%esi
 29db453:	cmp    %rsi,%r13
 29db456:	ja     29dfb87 <wasm[0]::function[1013]::helper::array_indexed_publish+0x51c7>
 29db45c:	lea    0x18(%rdx,%rax,1),%rsi
 29db461:	mov    %rbx,%r9
 29db464:	mov    %rsi,%rax
 29db467:	add    %r9,%rax
 29db46a:	mov    %rsi,%r13
 29db46d:	jb     29dfb89 <wasm[0]::function[1013]::helper::array_indexed_publish+0x51c9>
 29db473:	add    %rdx,%rcx
 29db476:	cmp    %rcx,%rax
 29db479:	ja     29dfb8b <wasm[0]::function[1013]::helper::array_indexed_publish+0x51cb>
 29db47f:	mov    0x58(%rsp),%r8d
 29db484:	mov    0x10(%rsp),%edi
 29db488:	mov    0x28(%rsp),%esi
 29db48c:	mov    0x18(%rsp),%edx
 29db490:	mov    (%rsp),%ecx
 29db493:	mov    0x20(%rsp),%eax
 29db497:	cmp    $0x8000000,%r9
 29db49e:	jbe    29db52f <wasm[0]::function[1013]::helper::array_indexed_publish+0xb6f>
 29db4a4:	mov    %r8d,0x20(%rsp)
 29db4a9:	mov    %edi,(%rsp)
 29db4ac:	mov    %esi,0x18(%rsp)
 29db4b0:	mov    %edx,0x28(%rsp)
 29db4b4:	mov    %ecx,0x10(%rsp)
 29db4b8:	mov    %eax,0x58(%rsp)
 29db4bc:	mov    0xc8(%rsp),%r12
 29db4c4:	mov    (%r12),%rax
 29db4c8:	mov    0xa0(%rsp),%rcx
 29db4d0:	cmp    %rcx,%rax
 29db4d3:	jae    29df1ba <wasm[0]::function[1013]::helper::array_indexed_publish+0x47fa>
 29db4d9:	xor    %edx,%edx
 29db4db:	mov    $0x8000000,%ecx
 29db4e0:	mov    %r13,%rsi
 29db4e3:	mov    0x60(%rsp),%rdi
 29db4e8:	call   3018b23 <wasmtime_builtin_memory_fill>
 29db4ed:	mov    0x20(%rsp),%r8d
 29db4f2:	mov    (%rsp),%edi
 29db4f5:	mov    0x18(%rsp),%esi
 29db4f9:	mov    0x28(%rsp),%edx
 29db4fd:	mov    0x10(%rsp),%ecx
 29db501:	mov    0x58(%rsp),%eax
 29db505:	mov    %rbx,%r9
 29db508:	sub    $0x8000000,%r9
 29db50f:	mov    %r9,%rbx
 29db512:	mov    %r13,%r9
 29db515:	add    $0x8000000,%r9
 29db51c:	mov    %r9,%r13
 29db51f:	mov    %rbx,%r9
 29db522:	cmp    $0x8000000,%r9
 29db529:	ja     29db4a4 <wasm[0]::function[1013]::helper::array_indexed_publish+0xae4>
 29db52f:	mov    %r8d,0x58(%rsp)
 29db534:	mov    %edi,0x10(%rsp)
 29db538:	mov    %esi,0x28(%rsp)
 29db53c:	mov    %edx,0x18(%rsp)
 29db540:	mov    %ecx,(%rsp)
 29db543:	mov    %eax,0x20(%rsp)
 29db547:	mov    0xc8(%rsp),%r12
 29db54f:	mov    (%r12),%rax
 29db553:	mov    0xa0(%rsp),%rsi
 29db55b:	cmp    %rsi,%rax
 29db55e:	jae    29df1ee <wasm[0]::function[1013]::helper::array_indexed_publish+0x482e>
 29db564:	xor    %edx,%edx
 29db566:	mov    %rbx,%rcx
 29db569:	mov    %r13,%rsi
 29db56c:	mov    0x60(%rsp),%rdi
 29db571:	call   3018b23 <wasmtime_builtin_memory_fill>
 29db576:	mov    0x58(%rsp),%esi
 29db57a:	test   %esi,%esi
 29db57c:	je     29dfb8d <wasm[0]::function[1013]::helper::array_indexed_publish+0x51cd>
 29db582:	test   %esi,%esi
 29db584:	je     29dfb8f <wasm[0]::function[1013]::helper::array_indexed_publish+0x51cf>
 29db58a:	mov    0xc0(%rsp),%r14
 29db592:	mov    0x28(%r14),%rax
 29db596:	mov    0x20(%r14),%r9
 29db59a:	mov    %esi,%r10d
 29db59d:	lea    (%r9,%r10,1),%r11
 29db5a1:	lea    0x10(%r9,%r10,1),%rsi
 29db5a6:	xor    %rcx,%rcx
 29db5a9:	cmp    %rax,%r10
 29db5ac:	cmova  %rcx,%rsi
 29db5b0:	mov    (%rsi),%edx
 29db5b2:	mov    0x8(%rsp),%esi
 29db5b6:	test   %esi,%esi
 29db5b8:	je     29dfb91 <wasm[0]::function[1013]::helper::array_indexed_publish+0x51d1>
 29db5be:	test   %esi,%esi
 29db5c0:	je     29dfb93 <wasm[0]::function[1013]::helper::array_indexed_publish+0x51d3>
 29db5c6:	mov    %esi,%r14d
 29db5c9:	lea    (%r9,%r14,1),%r15
 29db5cd:	lea    0x10(%r9,%r14,1),%rsi
 29db5d2:	cmp    %rax,%r14
 29db5d5:	cmova  %rcx,%rsi
 29db5d9:	mov    %edx,%ebx
 29db5db:	mov    (%rsi),%ecx
 29db5dd:	cmp    %rcx,%rbx
 29db5e0:	ja     29dfb95 <wasm[0]::function[1013]::helper::array_indexed_publish+0x51d5>
 29db5e6:	lea    0x18(%r9,%r14,1),%rcx
 29db5eb:	mov    %rbx,%r12
 29db5ee:	shl    $0x3,%r12
 29db5f2:	mov    %rcx,%rdx
 29db5f5:	add    %r12,%rdx
 29db5f8:	jb     29dfb97 <wasm[0]::function[1013]::helper::array_indexed_publish+0x51d7>
 29db5fe:	add    %r9,%rax
 29db601:	cmp    %rax,%rdx
 29db604:	ja     29dfb99 <wasm[0]::function[1013]::helper::array_indexed_publish+0x51d9>
 29db60a:	lea    0x18(%r9,%r10,1),%rdx
 29db60f:	mov    %rdx,%rsi
 29db612:	add    %r12,%rsi
 29db615:	jb     29dfb9b <wasm[0]::function[1013]::helper::array_indexed_publish+0x51db>
 29db61b:	cmp    %rax,%rsi
 29db61e:	ja     29dfb9d <wasm[0]::function[1013]::helper::array_indexed_publish+0x51dd>
 29db624:	cmp    %rcx,%rdx
 29db627:	ja     29db721 <wasm[0]::function[1013]::helper::array_indexed_publish+0xd61>
 29db62d:	mov    0x10(%rsp),%eax
 29db631:	mov    0x28(%rsp),%ecx
 29db635:	mov    0x8(%rsp),%edx
 29db639:	mov    0x18(%rsp),%esi
 29db63d:	mov    (%rsp),%edi
 29db640:	mov    0x20(%rsp),%r8d
 29db645:	lea    0x18(%r15,%rbx,8),%r9
 29db64a:	mov    %r9,%r13
 29db64d:	lea    0x18(%r11,%rbx,8),%r9
 29db652:	mov    %r9,%r15
 29db655:	cmp    $0x8000000,%r12
 29db65c:	mov    %r12,%rbx
 29db65f:	ja     29db670 <wasm[0]::function[1013]::helper::array_indexed_publish+0xcb0>
 29db665:	mov    %r13,%r9
 29db668:	mov    %rbx,%r11
 29db66b:	jmp    29db70a <wasm[0]::function[1013]::helper::array_indexed_publish+0xd4a>
 29db670:	mov    %eax,0x30(%rsp)
 29db674:	mov    %ecx,0x38(%rsp)
 29db678:	mov    %edx,0x40(%rsp)
 29db67c:	mov    %esi,0x48(%rsp)
 29db680:	mov    %edi,0x50(%rsp)
 29db684:	mov    %r8d,0x58(%rsp)
 29db689:	mov    0xc8(%rsp),%r12
 29db691:	mov    (%r12),%rax
 29db695:	mov    0xa0(%rsp),%rcx
 29db69d:	cmp    %rcx,%rax
 29db6a0:	jae    29df225 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4865>
 29db6a6:	mov    $0x8000000,%ecx
 29db6ab:	mov    %r13,%rsi
 29db6ae:	sub    $0x8000000,%rsi
 29db6b5:	mov    %r15,%rdx
 29db6b8:	mov    %rsi,%r13
 29db6bb:	sub    $0x8000000,%rdx
 29db6c2:	mov    %rdx,%r15
 29db6c5:	mov    0x60(%rsp),%rdi
 29db6ca:	call   3018afa <wasmtime_builtin_memory_copy>
 29db6cf:	mov    0x30(%rsp),%eax
 29db6d3:	mov    0x38(%rsp),%ecx
 29db6d7:	mov    0x40(%rsp),%edx
 29db6db:	mov    0x48(%rsp),%esi
 29db6df:	mov    0x50(%rsp),%edi
 29db6e3:	mov    0x58(%rsp),%r8d
 29db6e8:	mov    %rbx,%r11
 29db6eb:	sub    $0x8000000,%r11
 29db6f2:	cmp    $0x8000000,%r11
 29db6f9:	jbe    29db707 <wasm[0]::function[1013]::helper::array_indexed_publish+0xd47>
 29db6ff:	mov    %r11,%rbx
 29db702:	jmp    29db670 <wasm[0]::function[1013]::helper::array_indexed_publish+0xcb0>
 29db707:	mov    %r13,%r9
 29db70a:	sub    %r11,%r9
 29db70d:	mov    %r9,%r13
 29db710:	mov    %r15,%r9
 29db713:	sub    %r11,%r9
 29db716:	mov    %r9,%r15
 29db719:	mov    %r11,%rbx
 29db71c:	jmp    29db7f5 <wasm[0]::function[1013]::helper::array_indexed_publish+0xe35>
 29db721:	mov    %r12,%r11
 29db724:	mov    0x10(%rsp),%eax
 29db728:	mov    0x28(%rsp),%ecx
 29db72c:	mov    0x8(%rsp),%edx
 29db730:	mov    0x18(%rsp),%esi
 29db734:	mov    (%rsp),%edi
 29db737:	mov    0x20(%rsp),%r8d
 29db73c:	lea    0x18(%r9,%r14,1),%rbx
 29db741:	mov    %rbx,%r13
 29db744:	lea    0x18(%r9,%r10,1),%r9
 29db749:	mov    %r9,%r15
 29db74c:	cmp    $0x8000000,%r11
 29db753:	mov    %r11,%rbx
 29db756:	jbe    29db7f5 <wasm[0]::function[1013]::helper::array_indexed_publish+0xe35>
 29db75c:	mov    %eax,0x20(%rsp)
 29db760:	mov    %ecx,(%rsp)
 29db763:	mov    %edx,0x18(%rsp)
 29db767:	mov    %esi,0x8(%rsp)
 29db76b:	mov    %edi,0x28(%rsp)
 29db76f:	mov    %r8d,0x10(%rsp)
 29db774:	mov    0xc8(%rsp),%r12
 29db77c:	mov    (%r12),%rax
 29db780:	mov    0xa0(%rsp),%rsi
 29db788:	cmp    %rsi,%rax
 29db78b:	jae    29df259 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4899>
 29db791:	mov    $0x8000000,%ecx
 29db796:	mov    %r15,%rdx
 29db799:	mov    %r13,%rsi
 29db79c:	mov    0x60(%rsp),%rdi
 29db7a1:	call   3018afa <wasmtime_builtin_memory_copy>
 29db7a6:	mov    0x20(%rsp),%eax
 29db7aa:	mov    (%rsp),%ecx
 29db7ad:	mov    0x18(%rsp),%edx
 29db7b1:	mov    0x8(%rsp),%esi
 29db7b5:	mov    0x28(%rsp),%edi
 29db7b9:	mov    0x10(%rsp),%r8d
 29db7be:	mov    %rbx,%r9
 29db7c1:	sub    $0x8000000,%r9
 29db7c8:	mov    %r9,%rbx
 29db7cb:	mov    %r13,%r9
 29db7ce:	add    $0x8000000,%r9
 29db7d5:	mov    %r9,%r13
 29db7d8:	mov    %r15,%r9
 29db7db:	add    $0x8000000,%r9
 29db7e2:	mov    %r9,%r15
 29db7e5:	mov    %rbx,%r9
 29db7e8:	cmp    $0x8000000,%r9
 29db7ef:	ja     29db75c <wasm[0]::function[1013]::helper::array_indexed_publish+0xd9c>
 29db7f5:	mov    %eax,0x10(%rsp)
 29db7f9:	mov    %ecx,0x28(%rsp)
 29db7fd:	mov    %edx,0x8(%rsp)
 29db801:	mov    %esi,0x18(%rsp)
 29db805:	mov    %edi,(%rsp)
 29db808:	mov    %r8d,0x20(%rsp)
 29db80d:	mov    0xc8(%rsp),%r12
 29db815:	mov    (%r12),%rax
 29db819:	mov    0xa0(%rsp),%rcx
 29db821:	cmp    %rcx,%rax
 29db824:	jae    29df290 <wasm[0]::function[1013]::helper::array_indexed_publish+0x48d0>
 29db82a:	mov    %rbx,%rcx
 29db82d:	mov    %r15,%rdx
 29db830:	mov    %r13,%rsi
 29db833:	jmp    29db841 <wasm[0]::function[1013]::helper::array_indexed_publish+0xe81>
 29db838:	mov    %rbx,%rcx
 29db83b:	mov    %r15,%rdx
 29db83e:	mov    %r13,%rsi
 29db841:	mov    %rbx,%rcx
 29db844:	mov    %r15,%rdx
 29db847:	mov    %r13,%rsi
 29db84a:	mov    0x60(%rsp),%rdi
 29db84f:	call   3018afa <wasmtime_builtin_memory_copy>
 29db854:	mov    0x10(%rsp),%r13d
 29db859:	mov    %r13,%rax
 29db85c:	mov    %r13,0x70(%rsp)
 29db861:	test   %eax,%r13d
 29db864:	je     29dfb9f <wasm[0]::function[1013]::helper::array_indexed_publish+0x51df>
 29db86a:	mov    0x28(%rsp),%r9d
 29db86f:	test   %r9d,%r9d
 29db872:	je     29dfba1 <wasm[0]::function[1013]::helper::array_indexed_publish+0x51e1>
 29db878:	mov    0x70(%rsp),%rax
 29db87d:	test   %eax,%r13d
 29db880:	je     29dfba3 <wasm[0]::function[1013]::helper::array_indexed_publish+0x51e3>
 29db886:	mov    0xc0(%rsp),%r14
 29db88e:	mov    0x28(%r14),%rdx
 29db892:	mov    0x20(%r14),%rax
 29db896:	mov    %r13d,%esi
 29db899:	add    %rsi,%rax
 29db89c:	xor    %rdi,%rdi
 29db89f:	cmp    %rdx,%rsi
 29db8a2:	cmova  %rdi,%rax
 29db8a6:	mov    %r9d,0x28(%rax)
 29db8aa:	mov    0x8(%rsp),%r8d
 29db8af:	test   %r8d,%r8d
 29db8b2:	je     29dfba5 <wasm[0]::function[1013]::helper::array_indexed_publish+0x51e5>
 29db8b8:	mov    %r8d,0x2c(%rax)
 29db8bc:	mov    0x18(%rsp),%edi
 29db8c0:	mov    (%rsp),%esi
 29db8c3:	mov    0x20(%rsp),%edx
 29db8c7:	test   %r8d,%r8d
 29db8ca:	je     29dfba7 <wasm[0]::function[1013]::helper::array_indexed_publish+0x51e7>
 29db8d0:	test   %r8d,%r8d
 29db8d3:	je     29dfba9 <wasm[0]::function[1013]::helper::array_indexed_publish+0x51e9>
 29db8d9:	mov    0xc0(%rsp),%r14
 29db8e1:	mov    0x28(%r14),%r11
 29db8e5:	mov    0x20(%r14),%rbx
 29db8e9:	mov    %r8d,%eax
 29db8ec:	lea    0x10(%rbx,%rax,1),%r10
 29db8f1:	xor    %r12,%r12
 29db8f4:	cmp    %r11,%rax
 29db8f7:	cmova  %r12,%r10
 29db8fb:	mov    (%r10),%r13d
 29db8fe:	mov    0x68(%rsp),%rcx
 29db903:	shr    $0x6,%ecx
 29db906:	mov    %rcx,%r10
 29db909:	cmp    %r13d,%r10d
 29db90c:	mov    %r10,0xa8(%rsp)
 29db914:	jae    29dfbab <wasm[0]::function[1013]::helper::array_indexed_publish+0x51eb>
 29db91a:	mov    %r13d,%r10d
 29db91d:	shl    $0x3,%r10
 29db921:	shr    $0x20,%r10
 29db925:	test   %r10,%r10
 29db928:	jne    29dfbad <wasm[0]::function[1013]::helper::array_indexed_publish+0x51ed>
 29db92e:	shl    $0x3,%r13d
 29db932:	add    $0x18,%r13d
 29db936:	jb     29dfbaf <wasm[0]::function[1013]::helper::array_indexed_publish+0x51ef>
 29db93c:	mov    %r8,%r10
 29db93f:	add    %r13d,%r10d
 29db942:	jb     29dfbb1 <wasm[0]::function[1013]::helper::array_indexed_publish+0x51f1>
 29db948:	mov    %r10d,%r10d
 29db94b:	add    %r10,%rbx
 29db94e:	cmp    %r11,%r10
 29db951:	cmova  %r12,%rbx
 29db955:	mov    0xa8(%rsp),%r12
 29db95d:	mov    %r12,%r10
 29db960:	shl    $0x3,%r10d
 29db964:	mov    %r10,%r11
 29db967:	lea    0x18(%r11),%r10d
 29db96b:	mov    %r11,0x78(%rsp)
 29db970:	sub    %r10d,%r13d
 29db973:	sub    %r13,%rbx
 29db976:	mov    (%rbx),%r12
 29db979:	mov    $0x1,%r13d
 29db97f:	mov    0x68(%rsp),%rcx
 29db984:	shl    %cl,%r13
 29db987:	bt     %rcx,%r12
 29db98b:	jb     29db9f8 <wasm[0]::function[1013]::helper::array_indexed_publish+0x1038>
 29db991:	mov    0x70(%rsp),%rcx
 29db996:	mov    0x70(%rsp),%r10
 29db99b:	test   %r10d,%ecx
 29db99e:	je     29dfbb3 <wasm[0]::function[1013]::helper::array_indexed_publish+0x51f3>
 29db9a4:	test   %r10d,%ecx
 29db9a7:	je     29dfbb5 <wasm[0]::function[1013]::helper::array_indexed_publish+0x51f5>
 29db9ad:	mov    0xc0(%rsp),%r14
 29db9b5:	mov    0x28(%r14),%r11
 29db9b9:	mov    0x80(%rsp),%rbx
 29db9c1:	add    $0x1,%rbx
 29db9c8:	mov    %rbx,0x80(%rsp)
 29db9d0:	mov    %ecx,%r14d
 29db9d3:	mov    0xc0(%rsp),%r10
 29db9db:	mov    %r14,%rbx
 29db9de:	add    0x20(%r10),%rbx
 29db9e2:	xor    %r15,%r15
 29db9e5:	cmp    %r11,%r14
 29db9e8:	cmova  %r15,%rbx
 29db9ec:	mov    0x80(%rsp),%rcx
 29db9f4:	mov    %rcx,0x18(%rbx)
 29db9f8:	test   %r9d,%r9d
 29db9fb:	je     29dfbb7 <wasm[0]::function[1013]::helper::array_indexed_publish+0x51f7>
 29dba01:	test   %r9d,%r9d
 29dba04:	je     29dfbb9 <wasm[0]::function[1013]::helper::array_indexed_publish+0x51f9>
 29dba0a:	mov    0xc0(%rsp),%r14
 29dba12:	mov    0x28(%r14),%rbx
 29dba16:	mov    0x20(%r14),%r14
 29dba1a:	mov    %r9d,%r10d
 29dba1d:	lea    0x10(%r14,%r10,1),%r15
 29dba22:	xor    %r11,%r11
 29dba25:	cmp    %rbx,%r10
 29dba28:	cmova  %r11,%r15
 29dba2c:	mov    (%r15),%r15d
 29dba2f:	mov    0x68(%rsp),%rcx
 29dba34:	cmp    %r15d,%ecx
 29dba37:	jae    29dfbbb <wasm[0]::function[1013]::helper::array_indexed_publish+0x51fb>
 29dba3d:	mov    %r15d,%r10d
 29dba40:	shl    $0x3,%r10
 29dba44:	shr    $0x20,%r10
 29dba48:	test   %r10,%r10
 29dba4b:	jne    29dfbbd <wasm[0]::function[1013]::helper::array_indexed_publish+0x51fd>
 29dba51:	shl    $0x3,%r15d
 29dba55:	add    $0x18,%r15d
 29dba59:	jb     29dfbbf <wasm[0]::function[1013]::helper::array_indexed_publish+0x51ff>
 29dba5f:	add    %r15d,%r9d
 29dba62:	jb     29dfbc1 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5201>
 29dba68:	mov    %r9d,%r10d
 29dba6b:	lea    (%r14,%r10,1),%r9
 29dba6f:	cmp    %rbx,%r10
 29dba72:	cmova  %r11,%r9
 29dba76:	mov    %rcx,%r10
 29dba79:	shl    $0x3,%r10d
 29dba7d:	add    $0x18,%r10d
 29dba84:	sub    %r10d,%r15d
 29dba87:	sub    %r15,%r9
 29dba8a:	mov    0x88(%rsp),%rcx
 29dba92:	mov    %rcx,(%r9)
 29dba95:	lea    0x10(%r14,%rax,1),%r9
 29dba9a:	cmp    %rbx,%rax
 29dba9d:	cmova  %r11,%r9
 29dbaa1:	mov    (%r9),%eax
 29dbaa4:	mov    0xa8(%rsp),%rcx
 29dbaac:	cmp    %eax,%ecx
 29dbaae:	jae    29dfbc3 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5203>
 29dbab4:	mov    %eax,%r9d
 29dbab7:	shl    $0x3,%r9
 29dbabb:	shr    $0x20,%r9
 29dbabf:	test   %r9,%r9
 29dbac2:	jne    29dfbc5 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5205>
 29dbac8:	shl    $0x3,%eax
 29dbacb:	add    $0x18,%eax
 29dbace:	jb     29dfbc7 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5207>
 29dbad4:	add    %eax,%r8d
 29dbad7:	jb     29dfbc9 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5209>
 29dbadd:	or     %r13,%r12
 29dbae0:	mov    %r8d,%r9d
 29dbae3:	lea    (%r14,%r9,1),%r8
 29dbae7:	cmp    %rbx,%r9
 29dbaea:	cmova  %r11,%r8
 29dbaee:	mov    0x78(%rsp),%r10
 29dbaf3:	lea    0x18(%r10),%r9d
 29dbaf7:	sub    %r9d,%eax
 29dbafa:	sub    %rax,%r8
 29dbafd:	mov    %r12,(%r8)
 29dbb00:	mov    $0x1,%r10d
 29dbb06:	mov    0x70(%rsp),%r13
 29dbb0b:	mov    %r13d,0x18(%rsp)
 29dbb10:	mov    %edi,0x28(%rsp)
 29dbb14:	mov    %esi,0x10(%rsp)
 29dbb18:	mov    %edx,0x8(%rsp)
 29dbb1c:	test   %r10d,%r10d
 29dbb1f:	mov    %r10,0x98(%rsp)
 29dbb27:	je     29dbb3a <wasm[0]::function[1013]::helper::array_indexed_publish+0x117a>
 29dbb2d:	mov    0x98(%rsp),%r10
 29dbb35:	jmp    29dc9da <wasm[0]::function[1013]::helper::array_indexed_publish+0x201a>
 29dbb3a:	mov    0x70(%rsp),%r9
 29dbb3f:	mov    0x70(%rsp),%r13
 29dbb44:	test   %r9d,%r13d
 29dbb47:	je     29dfbcb <wasm[0]::function[1013]::helper::array_indexed_publish+0x520b>
 29dbb4d:	mov    0x70(%rsp),%rax
 29dbb52:	test   %eax,%r13d
 29dbb55:	je     29dfbcd <wasm[0]::function[1013]::helper::array_indexed_publish+0x520d>
 29dbb5b:	mov    0xc0(%rsp),%r14
 29dbb63:	mov    0x28(%r14),%rax
 29dbb67:	mov    %r13d,%r8d
 29dbb6a:	mov    %r8,%rdi
 29dbb6d:	add    0x20(%r14),%rdi
 29dbb71:	xor    %r9,%r9
 29dbb74:	cmp    %rax,%r8
 29dbb77:	cmova  %r9,%rdi
 29dbb7b:	mov    0x24(%rdi),%eax
 29dbb7e:	cmp    $0x2,%eax
 29dbb81:	sete   %al
 29dbb84:	mov    0x90(%rsp),%r14
 29dbb8c:	cmp    $0x3,%r14d
 29dbb90:	setne  %cl
 29dbb93:	test   %al,%cl
 29dbb95:	jne    29dbbaa <wasm[0]::function[1013]::helper::array_indexed_publish+0x11ea>
 29dbb9b:	mov    0x70(%rsp),%rax
 29dbba0:	mov    0x70(%rsp),%r13
 29dbba5:	jmp    29dc226 <wasm[0]::function[1013]::helper::array_indexed_publish+0x1866>
 29dbbaa:	mov    0x18(%rsp),%r13d
 29dbbaf:	mov    %r13,%rax
 29dbbb2:	mov    %r13,0x70(%rsp)
 29dbbb7:	test   %eax,%r13d
 29dbbba:	je     29dfbcf <wasm[0]::function[1013]::helper::array_indexed_publish+0x520f>
 29dbbc0:	mov    0x70(%rsp),%rax
 29dbbc5:	test   %eax,%r13d
 29dbbc8:	je     29dfbd1 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5211>
 29dbbce:	mov    0xc0(%rsp),%r14
 29dbbd6:	mov    0x28(%r14),%rax
 29dbbda:	mov    0x20(%r14),%rsi
 29dbbde:	mov    %r13d,%r8d
 29dbbe1:	lea    (%rsi,%r8,1),%rdx
 29dbbe5:	xor    %rdi,%rdi
 29dbbe8:	cmp    %rax,%r8
 29dbbeb:	cmova  %rdi,%rdx
 29dbbef:	mov    0x28(%rdx),%r8d
 29dbbf3:	mov    0x2c(%rdx),%ecx
 29dbbf6:	test   %r8d,%r8d
 29dbbf9:	je     29dfbd3 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5213>
 29dbbff:	test   %r8d,%r8d
 29dbc02:	je     29dfbd5 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5215>
 29dbc08:	mov    %r8d,%r8d
 29dbc0b:	lea    0x10(%rsi,%r8,1),%rsi
 29dbc10:	cmp    %rax,%r8
 29dbc13:	cmova  %rdi,%rsi
 29dbc17:	mov    (%rsi),%edi
 29dbc19:	mov    0x18(%rdx),%rax
 29dbc1d:	mov    0x10(%rsp),%esi
 29dbc21:	mov    0x8(%rsp),%edx
 29dbc25:	mov    %edi,%ecx
 29dbc27:	mov    0x68(%rsp),%rdi
 29dbc2c:	cmp    %rcx,%rdi
 29dbc2f:	setb   %dil
 29dbc33:	mov    0x68(%rsp),%rcx
 29dbc38:	cmp    $0x100000,%rcx
 29dbc3f:	setb   %r8b
 29dbc43:	lea    0x8(%rax,%rax,1),%rax
 29dbc48:	cmp    %rax,%rcx
 29dbc4b:	setbe  %al
 29dbc4e:	and    %eax,%r8d
 29dbc51:	or     %r8d,%edi
 29dbc54:	test   %dil,%dil
 29dbc57:	je     29dc21c <wasm[0]::function[1013]::helper::array_indexed_publish+0x185c>
 29dbc5d:	mov    0x18(%rsp),%edx
 29dbc61:	test   %edx,%edx
 29dbc63:	je     29dfbd7 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5217>
 29dbc69:	test   %edx,%edx
 29dbc6b:	je     29dfbd9 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5219>
 29dbc71:	mov    0xc0(%rsp),%r14
 29dbc79:	mov    0x28(%r14),%rax
 29dbc7d:	mov    0x20(%r14),%rcx
 29dbc81:	mov    %edx,%edi
 29dbc83:	lea    (%rcx,%rdi,1),%rsi
 29dbc87:	xor    %rdx,%rdx
 29dbc8a:	cmp    %rax,%rdi
 29dbc8d:	cmova  %rdx,%rsi
 29dbc91:	mov    0x28(%rsi),%edi
 29dbc94:	mov    0x2c(%rsi),%esi
 29dbc97:	test   %edi,%edi
 29dbc99:	je     29dfbdb <wasm[0]::function[1013]::helper::array_indexed_publish+0x521b>
 29dbc9f:	test   %edi,%edi
 29dbca1:	je     29dfbdd <wasm[0]::function[1013]::helper::array_indexed_publish+0x521d>
 29dbca7:	mov    %edi,%esi
 29dbca9:	lea    0x10(%rcx,%rsi,1),%rcx
 29dbcae:	cmp    %rax,%rsi
 29dbcb1:	cmova  %rdx,%rcx
 29dbcb5:	mov    (%rcx),%eax
 29dbcb7:	mov    %eax,%r13d
 29dbcba:	mov    %r13,%r14
 29dbcbd:	shl    $0x2,%r14
 29dbcc1:	mov    $0x20,%ecx
 29dbcc6:	mov    %rcx,0xb8(%rsp)
 29dbcce:	mov    %r14,%rcx
 29dbcd1:	shr    $0x20,%rcx
 29dbcd5:	test   %rcx,%rcx
 29dbcd8:	jne    29dfbdf <wasm[0]::function[1013]::helper::array_indexed_publish+0x521f>
 29dbcde:	mov    %rax,%rcx
 29dbce1:	shl    $0x2,%ecx
 29dbce4:	mov    %rax,0x78(%rsp)
 29dbce9:	add    $0x14,%ecx
 29dbcec:	jb     29dfbe1 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5221>
 29dbcf2:	mov    0x60(%rsp),%rdi
 29dbcf7:	mov    0x20(%rdi),%r12
 29dbcfb:	mov    (%r12),%eax
 29dbcff:	mov    %eax,%edx
 29dbd01:	mov    %ecx,%esi
 29dbd03:	add    $0xf,%rsi
 29dbd0a:	mov    %rsi,%rdi
 29dbd0d:	and    $0xfffffffffffffff0,%rdi
 29dbd11:	add    %rdx,%rdi
 29dbd14:	mov    0x4(%r12),%r8d
 29dbd19:	cmp    %r8,%rdi
 29dbd1c:	ja     29df2cd <wasm[0]::function[1013]::helper::array_indexed_publish+0x490d>
 29dbd22:	add    $0xf,%ecx
 29dbd28:	and    $0xfffffff0,%ecx
 29dbd2b:	lea    (%rax,%rcx,1),%edi
 29dbd2e:	mov    %edi,(%r12)
 29dbd32:	mov    0xc0(%rsp),%rcx
 29dbd3a:	mov    0x20(%rcx),%rdi
 29dbd3e:	lea    (%rdi,%rdx,1),%rcx
 29dbd42:	movl   $0xa800000e,(%rdi,%rdx,1)
 29dbd49:	mov    0x60(%rsp),%r8
 29dbd4e:	mov    0x28(%r8),%r8
 29dbd52:	mov    0x19c(%r8),%r8d
 29dbd59:	mov    %r8d,0x4(%rdi,%rdx,1)
 29dbd5e:	and    $0xfffffffffffffff0,%rsi
 29dbd62:	mov    %esi,0x8(%rdi,%rdx,1)
 29dbd66:	mov    %eax,(%rsp)
 29dbd69:	mov    0x78(%rsp),%rbx
 29dbd6e:	mov    %ebx,0x10(%rcx)
 29dbd71:	test   %eax,%eax
 29dbd73:	je     29dfbe3 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5223>
 29dbd79:	mov    0xc0(%rsp),%rcx
 29dbd81:	mov    0x28(%rcx),%rcx
 29dbd85:	mov    0xc0(%rsp),%rdx
 29dbd8d:	mov    0x20(%rdx),%rdx
 29dbd91:	mov    %eax,%eax
 29dbd93:	lea    (%rdx,%rax,1),%r11
 29dbd97:	lea    0x10(%rdx,%rax,1),%r8
 29dbd9c:	xor    %rsi,%rsi
 29dbd9f:	cmp    %rcx,%rax
 29dbda2:	cmova  %rsi,%r8
 29dbda6:	mov    (%r8),%esi
 29dbda9:	cmp    %rsi,%r13
 29dbdac:	ja     29dfbe5 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5225>
 29dbdb2:	lea    0x14(%rdx,%rax,1),%rbx
 29dbdb7:	mov    %rbx,%rax
 29dbdba:	add    %r14,%rax
 29dbdbd:	jb     29dfbe7 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5227>
 29dbdc3:	add    %rdx,%rcx
 29dbdc6:	cmp    %rcx,%rax
 29dbdc9:	ja     29dfbe9 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5229>
 29dbdcf:	mov    0x18(%rsp),%ecx
 29dbdd3:	mov    0x28(%rsp),%eax
 29dbdd7:	mov    0x10(%rsp),%edx
 29dbddb:	mov    0x8(%rsp),%esi
 29dbddf:	lea    0x14(%r11,%r13,4),%r14
 29dbde4:	test   %r13,%r13
 29dbde7:	je     29dbe3f <wasm[0]::function[1013]::helper::array_indexed_publish+0x147f>
 29dbded:	mov    %ecx,0x8(%rsp)
 29dbdf1:	mov    %eax,0x10(%rsp)
 29dbdf5:	mov    %edx,0x28(%rsp)
 29dbdf9:	mov    %esi,0x18(%rsp)
 29dbdfd:	mov    0xc8(%rsp),%rax
 29dbe05:	mov    (%rax),%rax
 29dbe08:	mov    0xa0(%rsp),%rcx
 29dbe10:	cmp    %rcx,%rax
 29dbe13:	jae    29df2ff <wasm[0]::function[1013]::helper::array_indexed_publish+0x493f>
 29dbe19:	movl   $0x0,(%rbx)
 29dbe1f:	mov    0x8(%rsp),%ecx
 29dbe23:	mov    0x10(%rsp),%eax
 29dbe27:	mov    0x28(%rsp),%edx
 29dbe2b:	mov    0x18(%rsp),%esi
 29dbe2f:	add    $0x4,%rbx
 29dbe36:	cmp    %r14,%rbx
 29dbe39:	jne    29dbded <wasm[0]::function[1013]::helper::array_indexed_publish+0x142d>
 29dbe3f:	mov    %ecx,0x8(%rsp)
 29dbe43:	xor    %r14d,%r14d
 29dbe46:	mov    $0x1,%ebx
 29dbe4b:	mov    0x60(%rsp),%rdi
 29dbe50:	mov    %rbx,0xb0(%rsp)
 29dbe58:	mov    0x28(%rdi),%rcx
 29dbe5c:	mov    0x120(%rcx),%ebx
 29dbe62:	mov    $0x10,%r13d
 29dbe68:	mov    %r13,0xa8(%rsp)
 29dbe70:	mov    %r14,%r13
 29dbe73:	mov    %eax,0x18(%rsp)
 29dbe77:	mov    %edx,0x28(%rsp)
 29dbe7b:	mov    %esi,0x10(%rsp)
 29dbe7f:	mov    0xc8(%rsp),%rcx
 29dbe87:	mov    (%rcx),%rax
 29dbe8a:	mov    0xa0(%rsp),%rcx
 29dbe92:	cmp    %rcx,%rax
 29dbe95:	jae    29df333 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4973>
 29dbe9b:	mov    0x78(%rsp),%rdx
 29dbea0:	jmp    29dbeaa <wasm[0]::function[1013]::helper::array_indexed_publish+0x14ea>
 29dbea5:	mov    0x78(%rsp),%rdx
 29dbeaa:	cmp    %edx,%r14d
 29dbead:	jae    29dc18d <wasm[0]::function[1013]::helper::array_indexed_publish+0x17cd>
 29dbeb3:	mov    0x8(%rsp),%eax
 29dbeb7:	xor    %esi,%esi
 29dbeb9:	test   %eax,%eax
 29dbebb:	je     29dfbeb <wasm[0]::function[1013]::helper::array_indexed_publish+0x522b>
 29dbec1:	test   %eax,%eax
 29dbec3:	je     29dfbed <wasm[0]::function[1013]::helper::array_indexed_publish+0x522d>
 29dbec9:	mov    0xc0(%rsp),%rcx
 29dbed1:	mov    0x28(%rcx),%rdx
 29dbed5:	mov    0x20(%rcx),%rdi
 29dbed9:	mov    %eax,%ecx
 29dbedb:	lea    (%rdi,%rcx,1),%rax
 29dbedf:	xor    %r9,%r9
 29dbee2:	cmp    %rdx,%rcx
 29dbee5:	cmova  %r9,%rax
 29dbee9:	mov    0x28(%rax),%r8d
 29dbeed:	mov    0x2c(%rax),%ecx
 29dbef0:	test   %r8d,%r8d
 29dbef3:	je     29dfbef <wasm[0]::function[1013]::helper::array_indexed_publish+0x522f>
 29dbef9:	test   %r8d,%r8d
 29dbefc:	je     29dfbf1 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5231>
 29dbf02:	mov    %r8d,%eax
 29dbf05:	lea    0x10(%rdi,%rax,1),%rdi
 29dbf0a:	cmp    %rdx,%rax
 29dbf0d:	cmova  %r9,%rdi
 29dbf11:	mov    (%rdi),%edi
 29dbf13:	mov    0x18(%rsp),%edx
 29dbf17:	mov    %r14d,%r9d
 29dbf1a:	mov    %edi,%edi
 29dbf1c:	cmp    %rdi,%r9
 29dbf1f:	jae    29dc051 <wasm[0]::function[1013]::helper::array_indexed_publish+0x1691>
 29dbf25:	xor    %esi,%esi
 29dbf27:	test   %ecx,%ecx
 29dbf29:	je     29dfbf3 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5233>
 29dbf2f:	test   %ecx,%ecx
 29dbf31:	je     29dfbf5 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5235>
 29dbf37:	mov    0xc0(%rsp),%rdx
 29dbf3f:	mov    0x28(%rdx),%rdi
 29dbf43:	mov    0x20(%rdx),%r9
 29dbf47:	mov    %ecx,%r11d
 29dbf4a:	lea    0x10(%r9,%r11,1),%rdx
 29dbf4f:	xor    %r10,%r10
 29dbf52:	cmp    %rdi,%r11
 29dbf55:	cmova  %r10,%rdx
 29dbf59:	mov    (%rdx),%edx
 29dbf5b:	mov    %r14,%r11
 29dbf5e:	shr    $0x6,%r11d
 29dbf62:	cmp    %edx,%r11d
 29dbf65:	jae    29dfbf7 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5237>
 29dbf6b:	mov    %edx,%r15d
 29dbf6e:	shl    $0x3,%r15
 29dbf72:	shr    $0x20,%r15
 29dbf76:	test   %r15,%r15
 29dbf79:	jne    29dfbf9 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5239>
 29dbf7f:	shl    $0x3,%edx
 29dbf82:	add    $0x18,%edx
 29dbf85:	jb     29dfbfb <wasm[0]::function[1013]::helper::array_indexed_publish+0x523b>
 29dbf8b:	add    %edx,%ecx
 29dbf8d:	jb     29dfbfd <wasm[0]::function[1013]::helper::array_indexed_publish+0x523d>
 29dbf93:	mov    %ecx,%ecx
 29dbf95:	add    %rcx,%r9
 29dbf98:	cmp    %rdi,%rcx
 29dbf9b:	cmova  %r10,%r9
 29dbf9f:	shl    $0x3,%r11d
 29dbfa3:	lea    0x18(%r11),%ecx
 29dbfa7:	sub    %ecx,%edx
 29dbfa9:	sub    %rdx,%r9
 29dbfac:	mov    (%r9),%rcx
 29dbfaf:	mov    0x18(%rsp),%edx
 29dbfb3:	bt     %r14,%rcx
 29dbfb7:	jae    29dc051 <wasm[0]::function[1013]::helper::array_indexed_publish+0x1691>
 29dbfbd:	mov    0xc0(%rsp),%rcx
 29dbfc5:	mov    0x28(%rcx),%rcx
 29dbfc9:	mov    0xc0(%rsp),%rdx
 29dbfd1:	mov    0x20(%rdx),%rdi
 29dbfd5:	lea    0x10(%rdi,%rax,1),%rsi
 29dbfda:	xor    %rdx,%rdx
 29dbfdd:	cmp    %rcx,%rax
 29dbfe0:	cmova  %rdx,%rsi
 29dbfe4:	mov    (%rsi),%esi
 29dbfe6:	cmp    %esi,%r14d
 29dbfe9:	jae    29dfbff <wasm[0]::function[1013]::helper::array_indexed_publish+0x523f>
 29dbfef:	mov    %esi,%eax
 29dbff1:	shl    $0x3,%rax
 29dbff5:	shr    $0x20,%rax
 29dbff9:	test   %rax,%rax
 29dbffc:	jne    29dfc01 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5241>
 29dc002:	mov    $0x3,%r13d
 29dc008:	shl    $0x3,%esi
 29dc00b:	add    $0x18,%esi
 29dc00e:	jb     29dfc03 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5243>
 29dc014:	add    %esi,%r8d
 29dc017:	jb     29dfc05 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5245>
 29dc01d:	mov    %r8d,%r8d
 29dc020:	lea    (%rdi,%r8,1),%rax
 29dc024:	cmp    %rcx,%r8
 29dc027:	cmova  %rdx,%rax
 29dc02b:	mov    %r14,%rcx
 29dc02e:	shl    $0x3,%ecx
 29dc031:	add    $0x18,%ecx
 29dc037:	sub    %ecx,%esi
 29dc039:	sub    %rsi,%rax
 29dc03c:	mov    (%rax),%rax
 29dc03f:	mov    %rax,0x80(%rsp)
 29dc047:	xor    %edx,%edx
 29dc049:	mov    0xb0(%rsp),%rsi
 29dc051:	mov    %edx,0x18(%rsp)
 29dc055:	test   %esi,%esi
 29dc057:	jne    29dc06a <wasm[0]::function[1013]::helper::array_indexed_publish+0x16aa>
 29dc05d:	mov    0xb8(%rsp),%rcx
 29dc065:	jmp    29dc16d <wasm[0]::function[1013]::helper::array_indexed_publish+0x17ad>
 29dc06a:	mov    (%r12),%eax
 29dc06e:	mov    %eax,%edx
 29dc070:	lea    0x20(%rdx),%rcx
 29dc074:	mov    0x4(%r12),%esi
 29dc079:	cmp    %rsi,%rcx
 29dc07c:	ja     29df36c <wasm[0]::function[1013]::helper::array_indexed_publish+0x49ac>
 29dc082:	lea    0x20(%rax),%ecx
 29dc085:	mov    %ecx,(%r12)
 29dc089:	mov    0xc0(%rsp),%rcx
 29dc091:	mov    0x20(%rcx),%rdi
 29dc095:	lea    (%rdi,%rdx,1),%rsi
 29dc099:	movl   $0xb0000042,(%rdi,%rdx,1)
 29dc0a0:	mov    %ebx,0x4(%rdi,%rdx,1)
 29dc0a4:	mov    0xb8(%rsp),%rcx
 29dc0ac:	mov    %ecx,0x8(%rdi,%rdx,1)
 29dc0b0:	mov    0x80(%rsp),%rdx
 29dc0b8:	mov    0x80(%rsp),%rdx
 29dc0c0:	mov    %rdx,0x10(%rsi)
 29dc0c4:	mov    %r13d,0x18(%rsi)
 29dc0c8:	mov    0x18(%rsp),%edx
 29dc0cc:	mov    %edx,0x1c(%rsi)
 29dc0cf:	mov    (%rsp),%edx
 29dc0d2:	test   %edx,%edx
 29dc0d4:	je     29dfc07 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5247>
 29dc0da:	test   %eax,%eax
 29dc0dc:	je     29dfc09 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5249>
 29dc0e2:	test   %edx,%edx
 29dc0e4:	je     29dfc0b <wasm[0]::function[1013]::helper::array_indexed_publish+0x524b>
 29dc0ea:	mov    0xc0(%rsp),%rsi
 29dc0f2:	mov    0x28(%rsi),%rsi
 29dc0f6:	mov    0xc0(%rsp),%rdi
 29dc0fe:	mov    0x20(%rdi),%rdi
 29dc102:	mov    %edx,%r10d
 29dc105:	lea    0x10(%rdi,%r10,1),%r9
 29dc10a:	xor    %r8,%r8
 29dc10d:	cmp    %rsi,%r10
 29dc110:	cmova  %r8,%r9
 29dc114:	mov    (%r9),%r9d
 29dc117:	cmp    %r9d,%r14d
 29dc11a:	jae    29dfc0d <wasm[0]::function[1013]::helper::array_indexed_publish+0x524d>
 29dc120:	mov    %r9d,%r10d
 29dc123:	shl    $0x2,%r10
 29dc127:	shr    $0x20,%r10
 29dc12b:	test   %r10,%r10
 29dc12e:	jne    29dfc0f <wasm[0]::function[1013]::helper::array_indexed_publish+0x524f>
 29dc134:	shl    $0x2,%r9d
 29dc138:	add    $0x14,%r9d
 29dc13c:	jb     29dfc11 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5251>
 29dc142:	add    %r9d,%edx
 29dc145:	jb     29dfc13 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5253>
 29dc14b:	mov    %edx,%r10d
 29dc14e:	lea    (%rdi,%r10,1),%rdx
 29dc152:	cmp    %rsi,%r10
 29dc155:	cmova  %r8,%rdx
 29dc159:	mov    %r14,%rsi
 29dc15c:	shl    $0x2,%esi
 29dc15f:	add    $0x14,%esi
 29dc165:	sub    %esi,%r9d
 29dc168:	sub    %r9,%rdx
 29dc16b:	mov    %eax,(%rdx)
 29dc16d:	mov    0x18(%rsp),%eax
 29dc171:	mov    0x28(%rsp),%edx
 29dc175:	mov    0x10(%rsp),%esi
 29dc179:	add    $0x1,%r14d
 29dc180:	mov    %rcx,0xb8(%rsp)
 29dc188:	jmp    29dbe73 <wasm[0]::function[1013]::helper::array_indexed_publish+0x14b3>
 29dc18d:	mov    0x60(%rsp),%rdi
 29dc192:	mov    0xa00(%rdi),%edx
 29dc198:	mov    0xa10(%rdi),%eax
 29dc19e:	mov    0x8(%rsp),%r13d
 29dc1a3:	mov    %r13,%rcx
 29dc1a6:	mov    %r13,0x70(%rsp)
 29dc1ab:	test   %ecx,%r13d
 29dc1ae:	je     29dfc15 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5255>
 29dc1b4:	test   %edx,%edx
 29dc1b6:	je     29dfc17 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5257>
 29dc1bc:	mov    0x70(%rsp),%rcx
 29dc1c1:	test   %ecx,%r13d
 29dc1c4:	je     29dfc19 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5259>
 29dc1ca:	mov    0xc0(%rsp),%r14
 29dc1d2:	mov    0x28(%r14),%rdi
 29dc1d6:	mov    0x20(%r14),%rsi
 29dc1da:	mov    %r13d,%r8d
 29dc1dd:	add    %r8,%rsi
 29dc1e0:	xor    %r9,%r9
 29dc1e3:	cmp    %rdi,%r8
 29dc1e6:	cmova  %r9,%rsi
 29dc1ea:	mov    %edx,0x28(%rsi)
 29dc1ed:	test   %eax,%eax
 29dc1ef:	je     29dfc1b <wasm[0]::function[1013]::helper::array_indexed_publish+0x525b>
 29dc1f5:	mov    %eax,0x2c(%rsi)
 29dc1f8:	movl   $0x0,0x30(%rsi)
 29dc1ff:	mov    (%rsp),%edi
 29dc202:	test   %edi,%edi
 29dc204:	je     29dfc1d <wasm[0]::function[1013]::helper::array_indexed_publish+0x525d>
 29dc20a:	mov    %edi,0x30(%rsi)
 29dc20d:	movl   $0x3,0x24(%rsi)
 29dc214:	mov    0x28(%rsp),%esi
 29dc218:	mov    0x10(%rsp),%edx
 29dc21c:	mov    0x70(%rsp),%rax
 29dc221:	mov    0x70(%rsp),%r13
 29dc226:	test   %eax,%r13d
 29dc229:	je     29dfc1f <wasm[0]::function[1013]::helper::array_indexed_publish+0x525f>
 29dc22f:	mov    0x70(%rsp),%rax
 29dc234:	mov    0x70(%rsp),%r13
 29dc239:	test   %eax,%r13d
 29dc23c:	je     29dfc21 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5261>
 29dc242:	mov    0xc0(%rsp),%r14
 29dc24a:	mov    0x28(%r14),%rax
 29dc24e:	mov    %r13d,%edi
 29dc251:	mov    %rdi,%r8
 29dc254:	add    0x20(%r14),%r8
 29dc258:	xor    %r9,%r9
 29dc25b:	cmp    %rax,%rdi
 29dc25e:	cmova  %r9,%r8
 29dc262:	mov    0x24(%r8),%eax
 29dc266:	cmp    $0x3,%eax
 29dc269:	je     29dc27c <wasm[0]::function[1013]::helper::array_indexed_publish+0x18bc>
 29dc26f:	mov    0x98(%rsp),%r10
 29dc277:	jmp    29dc9da <wasm[0]::function[1013]::helper::array_indexed_publish+0x201a>
 29dc27c:	mov    0xc0(%rsp),%r14
 29dc284:	mov    0x28(%r14),%r8
 29dc288:	mov    0x20(%r14),%r10
 29dc28c:	lea    (%r10,%rdi,1),%rax
 29dc290:	xor    %r9,%r9
 29dc293:	cmp    %r8,%rdi
 29dc296:	cmova  %r9,%rax
 29dc29a:	mov    0x30(%rax),%edi
 29dc29d:	test   %edi,%edi
 29dc29f:	je     29dfc23 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5263>
 29dc2a5:	test   %edi,%edi
 29dc2a7:	je     29dfc25 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5265>
 29dc2ad:	mov    %edi,%r11d
 29dc2b0:	lea    0x10(%r10,%r11,1),%r10
 29dc2b5:	cmp    %r8,%r11
 29dc2b8:	cmova  %r9,%r10
 29dc2bc:	mov    (%r10),%r15d
 29dc2bf:	mov    %r15,0x78(%rsp)
 29dc2c4:	mov    0x18(%rax),%r12
 29dc2c8:	mov    %r12,0xa8(%rsp)
 29dc2d0:	mov    %r15d,%ebx
 29dc2d3:	mov    0x68(%rsp),%rcx
 29dc2d8:	cmp    %rbx,%rcx
 29dc2db:	setb   %al
 29dc2de:	cmp    $0x100000,%rcx
 29dc2e5:	setb   %r8b
 29dc2e9:	lea    0x8(%r12,%r12,1),%rcx
 29dc2ee:	mov    0x68(%rsp),%r9
 29dc2f3:	cmp    %rcx,%r9
 29dc2f6:	setbe  %r9b
 29dc2fa:	and    %r9d,%r8d
 29dc2fd:	or     %r8d,%eax
 29dc300:	test   %al,%al
 29dc302:	jne    29dc315 <wasm[0]::function[1013]::helper::array_indexed_publish+0x1955>
 29dc308:	mov    0x98(%rsp),%r10
 29dc310:	jmp    29dc9da <wasm[0]::function[1013]::helper::array_indexed_publish+0x201a>
 29dc315:	mov    0x68(%rsp),%rcx
 29dc31a:	cmp    %rbx,%rcx
 29dc31d:	jb     29dc7b8 <wasm[0]::function[1013]::helper::array_indexed_publish+0x1df8>
 29dc323:	mov    0x78(%rsp),%rax
 29dc328:	mov    0x78(%rsp),%r15
 29dc32d:	test   %eax,%r15d
 29dc330:	je     29dc340 <wasm[0]::function[1013]::helper::array_indexed_publish+0x1980>
 29dc336:	mov    0x78(%rsp),%r13
 29dc33b:	jmp    29dc346 <wasm[0]::function[1013]::helper::array_indexed_publish+0x1986>
 29dc340:	mov    $0x4,%r13d
 29dc346:	mov    %edi,(%rsp)
 29dc349:	mov    0x70(%rsp),%rax
 29dc34e:	mov    %eax,0x10(%rsp)
 29dc352:	mov    %esi,0x28(%rsp)
 29dc356:	mov    %edx,0x8(%rsp)
 29dc35a:	mov    0xc8(%rsp),%rcx
 29dc362:	mov    (%rcx),%rax
 29dc365:	mov    0xa0(%rsp),%rcx
 29dc36d:	cmp    %rcx,%rax
 29dc370:	jae    29df3ae <wasm[0]::function[1013]::helper::array_indexed_publish+0x49ee>
 29dc376:	mov    %r13d,%r12d
 29dc379:	mov    0x68(%rsp),%rcx
 29dc37e:	cmp    %r12,%rcx
 29dc381:	jb     29dc3a4 <wasm[0]::function[1013]::helper::array_indexed_publish+0x19e4>
 29dc387:	mov    (%rsp),%edi
 29dc38a:	mov    0x10(%rsp),%r11d
 29dc38f:	mov    %r11,0x70(%rsp)
 29dc394:	mov    0x28(%rsp),%esi
 29dc398:	mov    0x8(%rsp),%edx
 29dc39c:	shl    $1,%r13d
 29dc39f:	jmp    29dc346 <wasm[0]::function[1013]::helper::array_indexed_publish+0x1986>
 29dc3a4:	mov    %r12,%r14
 29dc3a7:	shl    $0x2,%r14
 29dc3ab:	mov    %r14,%rax
 29dc3ae:	shr    $0x20,%rax
 29dc3b2:	test   %rax,%rax
 29dc3b5:	jne    29dfc27 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5267>
 29dc3bb:	mov    %r13,%rcx
 29dc3be:	shl    $0x2,%ecx
 29dc3c1:	add    $0x14,%ecx
 29dc3c4:	jb     29dfc29 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5269>
 29dc3ca:	mov    0x60(%rsp),%rdi
 29dc3cf:	mov    0x20(%rdi),%rdi
 29dc3d3:	mov    (%rdi),%eax
 29dc3d5:	mov    %eax,%edx
 29dc3d7:	mov    %ecx,%esi
 29dc3d9:	add    $0xf,%rsi
 29dc3e0:	mov    %rsi,%r8
 29dc3e3:	and    $0xfffffffffffffff0,%r8
 29dc3e7:	add    %rdx,%r8
 29dc3ea:	mov    0x4(%rdi),%r9d
 29dc3ee:	cmp    %r9,%r8
 29dc3f1:	ja     29df3e2 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4a22>
 29dc3f7:	add    $0xf,%ecx
 29dc3fd:	and    $0xfffffff0,%ecx
 29dc400:	add    %eax,%ecx
 29dc402:	mov    %ecx,(%rdi)
 29dc404:	mov    0xc0(%rsp),%rcx
 29dc40c:	mov    0x20(%rcx),%rdi
 29dc410:	lea    (%rdi,%rdx,1),%rcx
 29dc414:	movl   $0xa800000e,(%rdi,%rdx,1)
 29dc41b:	mov    0x60(%rsp),%r8
 29dc420:	mov    0x28(%r8),%r8
 29dc424:	mov    0x19c(%r8),%r8d
 29dc42b:	mov    %r8d,0x4(%rdi,%rdx,1)
 29dc430:	and    $0xfffffffffffffff0,%rsi
 29dc434:	mov    %esi,0x8(%rdi,%rdx,1)
 29dc438:	mov    %eax,0x18(%rsp)
 29dc43c:	mov    %r13d,0x10(%rcx)
 29dc440:	test   %eax,%eax
 29dc442:	je     29dfc2b <wasm[0]::function[1013]::helper::array_indexed_publish+0x526b>
 29dc448:	mov    0xc0(%rsp),%rcx
 29dc450:	mov    0x28(%rcx),%r8
 29dc454:	mov    0x20(%rcx),%r9
 29dc458:	mov    %eax,%r10d
 29dc45b:	lea    (%r9,%r10,1),%rdi
 29dc45f:	lea    0x10(%r9,%r10,1),%rsi
 29dc464:	xor    %r11,%r11
 29dc467:	cmp    %r8,%r10
 29dc46a:	cmova  %r11,%rsi
 29dc46e:	mov    (%rsi),%r11d
 29dc471:	cmp    %r11,%r12
 29dc474:	ja     29dfc2d <wasm[0]::function[1013]::helper::array_indexed_publish+0x526d>
 29dc47a:	lea    0x14(%r9,%r10,1),%r13
 29dc47f:	mov    %r13,%r10
 29dc482:	add    %r14,%r10
 29dc485:	jb     29dfc2f <wasm[0]::function[1013]::helper::array_indexed_publish+0x526f>
 29dc48b:	lea    (%r9,%r8,1),%r11
 29dc48f:	cmp    %r11,%r10
 29dc492:	ja     29dfc31 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5271>
 29dc498:	mov    (%rsp),%r8d
 29dc49c:	mov    0x10(%rsp),%eax
 29dc4a0:	mov    %rax,0x70(%rsp)
 29dc4a5:	mov    0x28(%rsp),%esi
 29dc4a9:	mov    0x8(%rsp),%edx
 29dc4ad:	lea    0x14(%rdi,%r12,4),%r14
 29dc4b2:	test   %r12,%r12
 29dc4b5:	je     29dc519 <wasm[0]::function[1013]::helper::array_indexed_publish+0x1b59>
 29dc4bb:	mov    %r8d,0x8(%rsp)
 29dc4c0:	mov    0x70(%rsp),%rax
 29dc4c5:	mov    %eax,0x28(%rsp)
 29dc4c9:	mov    %esi,0x10(%rsp)
 29dc4cd:	mov    %edx,(%rsp)
 29dc4d0:	mov    0xc8(%rsp),%rcx
 29dc4d8:	mov    (%rcx),%rcx
 29dc4db:	mov    0xa0(%rsp),%rax
 29dc4e3:	cmp    %rax,%rcx
 29dc4e6:	jae    29df414 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4a54>
 29dc4ec:	movl   $0x0,0x0(%r13)
 29dc4f4:	mov    0x8(%rsp),%r8d
 29dc4f9:	mov    0x28(%rsp),%eax
 29dc4fd:	mov    %rax,0x70(%rsp)
 29dc502:	mov    0x10(%rsp),%esi
 29dc506:	mov    (%rsp),%edx
 29dc509:	add    $0x4,%r13
 29dc510:	cmp    %r14,%r13
 29dc513:	jne    29dc4bb <wasm[0]::function[1013]::helper::array_indexed_publish+0x1afb>
 29dc519:	mov    0x18(%rsp),%edi
 29dc51d:	test   %edi,%edi
 29dc51f:	je     29dfc33 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5273>
 29dc525:	test   %r8d,%r8d
 29dc528:	je     29dfc35 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5275>
 29dc52e:	test   %edi,%edi
 29dc530:	je     29dfc37 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5277>
 29dc536:	mov    0xc0(%rsp),%r14
 29dc53e:	mov    0x28(%r14),%r10
 29dc542:	mov    0x20(%r14),%rax
 29dc546:	mov    %edi,%r12d
 29dc549:	lea    (%rax,%r12,1),%r9
 29dc54d:	lea    0x10(%rax,%r12,1),%r11
 29dc552:	xor    %r13,%r13
 29dc555:	cmp    %r10,%r12
 29dc558:	cmova  %r13,%r11
 29dc55c:	mov    (%r11),%ecx
 29dc55f:	cmp    %rcx,%rbx
 29dc562:	ja     29dfc39 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5279>
 29dc568:	test   %r8d,%r8d
 29dc56b:	je     29dfc3b <wasm[0]::function[1013]::helper::array_indexed_publish+0x527b>
 29dc571:	mov    %r8d,%r14d
 29dc574:	lea    (%rax,%r14,1),%r11
 29dc578:	lea    0x10(%rax,%r14,1),%r15
 29dc57d:	cmp    %r10,%r14
 29dc580:	cmova  %r13,%r15
 29dc584:	mov    (%r15),%ecx
 29dc587:	cmp    %rcx,%rbx
 29dc58a:	ja     29dfc3d <wasm[0]::function[1013]::helper::array_indexed_publish+0x527d>
 29dc590:	lea    0x14(%rax,%r12,1),%r13
 29dc595:	mov    %rbx,%r12
 29dc598:	shl    $0x2,%r12
 29dc59c:	mov    %r13,%r15
 29dc59f:	add    %r12,%r15
 29dc5a2:	jb     29dfc3f <wasm[0]::function[1013]::helper::array_indexed_publish+0x527f>
 29dc5a8:	add    %rax,%r10
 29dc5ab:	cmp    %r10,%r15
 29dc5ae:	ja     29dfc41 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5281>
 29dc5b4:	lea    0x14(%rax,%r14,1),%rax
 29dc5b9:	mov    %rax,%r14
 29dc5bc:	add    %r12,%r14
 29dc5bf:	mov    %rax,0x80(%rsp)
 29dc5c7:	jb     29dfc43 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5283>
 29dc5cd:	cmp    %r10,%r14
 29dc5d0:	ja     29dfc45 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5285>
 29dc5d6:	mov    0x78(%rsp),%rax
 29dc5db:	mov    0x78(%rsp),%r15
 29dc5e0:	test   %eax,%r15d
 29dc5e3:	jne    29dc5f8 <wasm[0]::function[1013]::helper::array_indexed_publish+0x1c38>
 29dc5e9:	mov    0x70(%rsp),%rax
 29dc5ee:	mov    0x70(%rsp),%r13
 29dc5f3:	jmp    29dc770 <wasm[0]::function[1013]::helper::array_indexed_publish+0x1db0>
 29dc5f8:	mov    0x18(%rsp),%r10d
 29dc5fd:	xor    %r14d,%r14d
 29dc600:	lea    0x14(%r9,%rbx,4),%r12
 29dc605:	lea    0x14(%r11,%rbx,4),%rbx
 29dc60a:	mov    0x80(%rsp),%rax
 29dc612:	cmp    %rax,%r13
 29dc615:	jae    29dc623 <wasm[0]::function[1013]::helper::array_indexed_publish+0x1c63>
 29dc61b:	mov    %r10,%rdi
 29dc61e:	jmp    29dc6bd <wasm[0]::function[1013]::helper::array_indexed_publish+0x1cfd>
 29dc623:	mov    %r10,%rdi
 29dc626:	mov    %r10d,0x20(%rsp)
 29dc62b:	mov    %r8d,(%rsp)
 29dc62f:	mov    0x70(%rsp),%r13
 29dc634:	mov    %r13d,0x10(%rsp)
 29dc639:	mov    %edi,0x28(%rsp)
 29dc63d:	mov    %esi,0x8(%rsp)
 29dc641:	mov    %edx,0x18(%rsp)
 29dc645:	mov    0xc8(%rsp),%rcx
 29dc64d:	mov    (%rcx),%rsi
 29dc650:	mov    0xa0(%rsp),%rax
 29dc658:	cmp    %rax,%rsi
 29dc65b:	jae    29df448 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4a88>
 29dc661:	sub    $0x4,%rbx
 29dc665:	mov    (%rbx),%r10d
 29dc668:	sub    $0x4,%r12
 29dc66c:	mov    %r10d,(%r12)
 29dc670:	mov    0x10(%rsp),%r13d
 29dc675:	mov    %r13,0x70(%rsp)
 29dc67a:	mov    0x28(%rsp),%edi
 29dc67e:	mov    0x8(%rsp),%esi
 29dc682:	mov    0x18(%rsp),%edx
 29dc686:	mov    0x20(%rsp),%r10d
 29dc68b:	mov    (%rsp),%r8d
 29dc68f:	mov    0x78(%rsp),%r15
 29dc694:	sub    $0x1,%r15d
 29dc698:	mov    0x80(%rsp),%r13
 29dc6a0:	mov    %r15,0x78(%rsp)
 29dc6a5:	cmp    %r13,%rbx
 29dc6a8:	jne    29dc626 <wasm[0]::function[1013]::helper::array_indexed_publish+0x1c66>
 29dc6ae:	mov    0x70(%rsp),%rax
 29dc6b3:	mov    0x70(%rsp),%r13
 29dc6b8:	jmp    29dc770 <wasm[0]::function[1013]::helper::array_indexed_publish+0x1db0>
 29dc6bd:	mov    %r10d,(%rsp)
 29dc6c1:	mov    %r8d,0x20(%rsp)
 29dc6c6:	mov    0x70(%rsp),%rax
 29dc6cb:	mov    %eax,0x18(%rsp)
 29dc6cf:	mov    %edi,0x8(%rsp)
 29dc6d3:	mov    %esi,0x28(%rsp)
 29dc6d7:	mov    %edx,0x10(%rsp)
 29dc6db:	mov    0xc8(%rsp),%rcx
 29dc6e3:	mov    (%rcx),%rcx
 29dc6e6:	mov    0xa0(%rsp),%rax
 29dc6ee:	cmp    %rax,%rcx
 29dc6f1:	jae    29df47c <wasm[0]::function[1013]::helper::array_indexed_publish+0x4abc>
 29dc6f7:	mov    0x80(%rsp),%rax
 29dc6ff:	jmp    29dc70c <wasm[0]::function[1013]::helper::array_indexed_publish+0x1d4c>
 29dc704:	mov    0x80(%rsp),%rax
 29dc70c:	mov    0x80(%rsp),%rax
 29dc714:	mov    (%rax),%eax
 29dc716:	mov    %eax,0x0(%r13)
 29dc71a:	mov    0x18(%rsp),%eax
 29dc71e:	mov    %rax,0x70(%rsp)
 29dc723:	mov    0x8(%rsp),%edi
 29dc727:	mov    0x28(%rsp),%esi
 29dc72b:	mov    0x10(%rsp),%edx
 29dc72f:	mov    (%rsp),%r10d
 29dc733:	mov    0x20(%rsp),%r8d
 29dc738:	mov    0x80(%rsp),%rax
 29dc740:	add    $0x4,%rax
 29dc747:	mov    %rax,0x80(%rsp)
 29dc74f:	add    $0x4,%r13
 29dc756:	add    $0x1,%r14d
 29dc75d:	cmp    %rbx,%rax
 29dc760:	jne    29dc6bd <wasm[0]::function[1013]::helper::array_indexed_publish+0x1cfd>
 29dc766:	mov    0x70(%rsp),%rax
 29dc76b:	mov    0x70(%rsp),%r13
 29dc770:	test   %eax,%r13d
 29dc773:	je     29dfc47 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5287>
 29dc779:	test   %edi,%edi
 29dc77b:	je     29dfc49 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5289>
 29dc781:	mov    0x70(%rsp),%rax
 29dc786:	mov    0x70(%rsp),%r13
 29dc78b:	test   %eax,%r13d
 29dc78e:	je     29dfc4b <wasm[0]::function[1013]::helper::array_indexed_publish+0x528b>
 29dc794:	mov    0xc0(%rsp),%r14
 29dc79c:	mov    0x28(%r14),%rax
 29dc7a0:	mov    %r13d,%r9d
 29dc7a3:	mov    %r9,%r8
 29dc7a6:	add    0x20(%r14),%r8
 29dc7aa:	xor    %r10,%r10
 29dc7ad:	cmp    %rax,%r9
 29dc7b0:	cmova  %r10,%r8
 29dc7b4:	mov    %edi,0x30(%r8)
 29dc7b8:	mov    %esi,0x10(%rsp)
 29dc7bc:	mov    %edi,0x28(%rsp)
 29dc7c0:	mov    0x70(%rsp),%r13
 29dc7c5:	mov    %r13d,0x8(%rsp)
 29dc7ca:	mov    %edx,0x18(%rsp)
 29dc7ce:	mov    0x60(%rsp),%rdi
 29dc7d3:	mov    0x20(%rdi),%rsi
 29dc7d7:	mov    (%rsi),%eax
 29dc7d9:	mov    %eax,%ecx
 29dc7db:	mov    $0x20,%edx
 29dc7e0:	lea    0x20(%rcx),%rdi
 29dc7e4:	mov    0x4(%rsi),%r8d
 29dc7e8:	cmp    %r8,%rdi
 29dc7eb:	ja     29df4b8 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4af8>
 29dc7f1:	lea    0x20(%rax),%edi
 29dc7f4:	mov    %edi,(%rsi)
 29dc7f6:	mov    0xc0(%rsp),%r14
 29dc7fe:	mov    0x20(%r14),%rdi
 29dc802:	lea    (%rdi,%rcx,1),%rsi
 29dc806:	movl   $0xb0000042,(%rdi,%rcx,1)
 29dc80d:	mov    0x60(%rsp),%r8
 29dc812:	mov    0x28(%r8),%r8
 29dc816:	mov    0x120(%r8),%r8d
 29dc81d:	mov    %r8d,0x4(%rdi,%rcx,1)
 29dc822:	mov    %edx,0x8(%rdi,%rcx,1)
 29dc826:	mov    0x88(%rsp),%rdi
 29dc82e:	mov    0x88(%rsp),%rdi
 29dc836:	mov    %rdi,0x10(%rsi)
 29dc83a:	mov    0x90(%rsp),%r12
 29dc842:	mov    %r12d,0x18(%rsi)
 29dc846:	mov    0x10(%rsp),%ecx
 29dc84a:	mov    %ecx,0x1c(%rsi)
 29dc84d:	mov    0x28(%rsp),%ecx
 29dc851:	test   %ecx,%ecx
 29dc853:	je     29dfc4d <wasm[0]::function[1013]::helper::array_indexed_publish+0x528d>
 29dc859:	test   %ecx,%ecx
 29dc85b:	je     29dfc4f <wasm[0]::function[1013]::helper::array_indexed_publish+0x528f>
 29dc861:	mov    0xc0(%rsp),%r14
 29dc869:	mov    0x28(%r14),%rdx
 29dc86d:	mov    0x20(%r14),%rsi
 29dc871:	mov    %ecx,%r9d
 29dc874:	lea    0x10(%rsi,%r9,1),%r8
 29dc879:	xor    %rdi,%rdi
 29dc87c:	cmp    %rdx,%r9
 29dc87f:	cmova  %rdi,%r8
 29dc883:	mov    (%r8),%r8d
 29dc886:	mov    0x68(%rsp),%r9
 29dc88b:	cmp    %r8d,%r9d
 29dc88e:	jae    29dfc51 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5291>
 29dc894:	mov    %r8d,%r9d
 29dc897:	shl    $0x2,%r9
 29dc89b:	shr    $0x20,%r9
 29dc89f:	test   %r9,%r9
 29dc8a2:	jne    29dfc53 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5293>
 29dc8a8:	shl    $0x2,%r8d
 29dc8ac:	add    $0x14,%r8d
 29dc8b0:	jb     29dfc55 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5295>
 29dc8b6:	add    %r8d,%ecx
 29dc8b9:	jb     29dfc57 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5297>
 29dc8bf:	mov    %ecx,%r9d
 29dc8c2:	lea    (%rsi,%r9,1),%rcx
 29dc8c6:	cmp    %rdx,%r9
 29dc8c9:	cmova  %rdi,%rcx
 29dc8cd:	mov    0x68(%rsp),%rdx
 29dc8d2:	mov    %rdx,%rsi
 29dc8d5:	shl    $0x2,%esi
 29dc8d8:	lea    0x14(%rsi),%edi
 29dc8db:	sub    %edi,%r8d
 29dc8de:	sub    %r8,%rcx
 29dc8e1:	mov    (%rcx),%edi
 29dc8e3:	test   %edi,%edi
 29dc8e5:	jne    29dc933 <wasm[0]::function[1013]::helper::array_indexed_publish+0x1f73>
 29dc8eb:	mov    0x8(%rsp),%r9d
 29dc8f0:	test   %r9d,%r9d
 29dc8f3:	je     29dfc59 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5299>
 29dc8f9:	test   %r9d,%r9d
 29dc8fc:	je     29dfc5b <wasm[0]::function[1013]::helper::array_indexed_publish+0x529b>
 29dc902:	mov    0xc0(%rsp),%r14
 29dc90a:	mov    0x28(%r14),%rdx
 29dc90e:	mov    0xa8(%rsp),%r12
 29dc916:	lea    0x1(%r12),%rcx
 29dc91b:	mov    %r9d,%edi
 29dc91e:	mov    %rdi,%r10
 29dc921:	add    0x20(%r14),%r10
 29dc925:	xor    %r8,%r8
 29dc928:	cmp    %rdx,%rdi
 29dc92b:	cmova  %r8,%r10
 29dc92f:	mov    %rcx,0x18(%r10)
 29dc933:	mov    0x28(%rsp),%edx
 29dc937:	test   %edx,%edx
 29dc939:	je     29dfc5d <wasm[0]::function[1013]::helper::array_indexed_publish+0x529d>
 29dc93f:	test   %eax,%eax
 29dc941:	je     29dfc5f <wasm[0]::function[1013]::helper::array_indexed_publish+0x529f>
 29dc947:	test   %edx,%edx
 29dc949:	je     29dfc61 <wasm[0]::function[1013]::helper::array_indexed_publish+0x52a1>
 29dc94f:	mov    0xc0(%rsp),%r14
 29dc957:	mov    0x28(%r14),%rcx
 29dc95b:	mov    0x20(%r14),%rdi
 29dc95f:	mov    %edx,%r10d
 29dc962:	lea    0x10(%rdi,%r10,1),%r9
 29dc967:	xor    %r8,%r8
 29dc96a:	cmp    %rcx,%r10
 29dc96d:	cmova  %r8,%r9
 29dc971:	mov    (%r9),%r9d
 29dc974:	mov    0x68(%rsp),%r10
 29dc979:	cmp    %r9d,%r10d
 29dc97c:	jae    29dfc63 <wasm[0]::function[1013]::helper::array_indexed_publish+0x52a3>
 29dc982:	mov    %r9d,%r10d
 29dc985:	shl    $0x2,%r10
 29dc989:	shr    $0x20,%r10
 29dc98d:	test   %r10,%r10
 29dc990:	jne    29dfc65 <wasm[0]::function[1013]::helper::array_indexed_publish+0x52a5>
 29dc996:	shl    $0x2,%r9d
 29dc99a:	add    $0x14,%r9d
 29dc99e:	jb     29dfc67 <wasm[0]::function[1013]::helper::array_indexed_publish+0x52a7>
 29dc9a4:	add    %r9d,%edx
 29dc9a7:	jb     29dfc69 <wasm[0]::function[1013]::helper::array_indexed_publish+0x52a9>
 29dc9ad:	mov    %edx,%r10d
 29dc9b0:	lea    (%rdi,%r10,1),%rdx
 29dc9b4:	cmp    %rcx,%r10
 29dc9b7:	cmova  %r8,%rdx
 29dc9bb:	lea    0x14(%rsi),%ecx
 29dc9be:	sub    %ecx,%r9d
 29dc9c1:	sub    %r9,%rdx
 29dc9c4:	mov    %eax,(%rdx)
 29dc9c6:	mov    0x8(%rsp),%r13d
 29dc9cb:	mov    %r13,0x70(%rsp)
 29dc9d0:	mov    0x18(%rsp),%edx
 29dc9d4:	mov    $0x1,%r10d
 29dc9da:	mov    0x70(%rsp),%r13
 29dc9df:	mov    %r13d,0x18(%rsp)
 29dc9e4:	mov    %edx,0x8(%rsp)
 29dc9e8:	test   %r10d,%r10d
 29dc9eb:	mov    %r10,0x98(%rsp)
 29dc9f3:	jne    29dd530 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2b70>
 29dc9f9:	mov    0x70(%rsp),%rax
 29dc9fe:	mov    0x70(%rsp),%r13
 29dca03:	test   %eax,%r13d
 29dca06:	je     29dfc6b <wasm[0]::function[1013]::helper::array_indexed_publish+0x52ab>
 29dca0c:	test   %eax,%r13d
 29dca0f:	je     29dfc6d <wasm[0]::function[1013]::helper::array_indexed_publish+0x52ad>
 29dca15:	mov    0xc0(%rsp),%r14
 29dca1d:	mov    0x28(%r14),%rax
 29dca21:	mov    %r13d,%edx
 29dca24:	mov    %rdx,%rcx
 29dca27:	add    0x20(%r14),%rcx
 29dca2b:	xor    %rsi,%rsi
 29dca2e:	cmp    %rax,%rdx
 29dca31:	cmova  %rsi,%rcx
 29dca35:	mov    0x24(%rcx),%eax
 29dca38:	cmp    $0x3,%eax
 29dca3b:	je     29dd095 <wasm[0]::function[1013]::helper::array_indexed_publish+0x26d5>
 29dca41:	mov    0x18(%rsp),%r13d
 29dca46:	mov    %r13,%rax
 29dca49:	mov    %r13,0x70(%rsp)
 29dca4e:	test   %eax,%r13d
 29dca51:	je     29dfc6f <wasm[0]::function[1013]::helper::array_indexed_publish+0x52af>
 29dca57:	mov    0x70(%rsp),%rax
 29dca5c:	test   %eax,%r13d
 29dca5f:	je     29dfc71 <wasm[0]::function[1013]::helper::array_indexed_publish+0x52b1>
 29dca65:	mov    0xc0(%rsp),%r14
 29dca6d:	mov    0x28(%r14),%rax
 29dca71:	mov    %r13d,%esi
 29dca74:	mov    %rsi,%rdx
 29dca77:	add    0x20(%r14),%rdx
 29dca7b:	xor    %rdi,%rdi
 29dca7e:	cmp    %rax,%rsi
 29dca81:	cmova  %rdi,%rdx
 29dca85:	mov    0x24(%rdx),%eax
 29dca88:	mov    0x8(%rsp),%edx
 29dca8c:	cmp    $0x2,%eax
 29dca8f:	jne    29dd530 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2b70>
 29dca95:	mov    0x18(%rsp),%edx
 29dca99:	test   %edx,%edx
 29dca9b:	je     29dfc73 <wasm[0]::function[1013]::helper::array_indexed_publish+0x52b3>
 29dcaa1:	test   %edx,%edx
 29dcaa3:	je     29dfc75 <wasm[0]::function[1013]::helper::array_indexed_publish+0x52b5>
 29dcaa9:	mov    0xc0(%rsp),%r14
 29dcab1:	mov    0x28(%r14),%rax
 29dcab5:	mov    0x20(%r14),%rcx
 29dcab9:	mov    %edx,%esi
 29dcabb:	lea    (%rcx,%rsi,1),%rdi
 29dcabf:	xor    %rdx,%rdx
 29dcac2:	cmp    %rax,%rsi
 29dcac5:	cmova  %rdx,%rdi
 29dcac9:	mov    0x28(%rdi),%esi
 29dcacc:	mov    %esi,0x28(%rsp)
 29dcad0:	mov    0x2c(%rdi),%edi
 29dcad3:	mov    %edi,0x10(%rsp)
 29dcad7:	test   %esi,%esi
 29dcad9:	je     29dfc77 <wasm[0]::function[1013]::helper::array_indexed_publish+0x52b7>
 29dcadf:	test   %esi,%esi
 29dcae1:	je     29dfc79 <wasm[0]::function[1013]::helper::array_indexed_publish+0x52b9>
 29dcae7:	mov    %esi,%edi
 29dcae9:	lea    0x10(%rcx,%rdi,1),%rsi
 29dcaee:	cmp    %rax,%rdi
 29dcaf1:	cmova  %rdx,%rsi
 29dcaf5:	mov    (%rsi),%esi
 29dcaf7:	mov    %esi,%r12d
 29dcafa:	mov    %r12,%r15
 29dcafd:	shl    $0x2,%r15
 29dcb01:	mov    $0x20,%edi
 29dcb06:	mov    %rdi,0xb8(%rsp)
 29dcb0e:	mov    %r15,%rdi
 29dcb11:	shr    $0x20,%rdi
 29dcb15:	test   %rdi,%rdi
 29dcb18:	jne    29dfc7b <wasm[0]::function[1013]::helper::array_indexed_publish+0x52bb>
 29dcb1e:	mov    %rsi,%rcx
 29dcb21:	shl    $0x2,%ecx
 29dcb24:	mov    %rsi,0x78(%rsp)
 29dcb29:	add    $0x14,%ecx
 29dcb2c:	jb     29dfc7d <wasm[0]::function[1013]::helper::array_indexed_publish+0x52bd>
 29dcb32:	mov    0x60(%rsp),%rdi
 29dcb37:	mov    0x20(%rdi),%r14
 29dcb3b:	mov    (%r14),%eax
 29dcb3e:	mov    %eax,%edi
 29dcb40:	mov    %ecx,%r8d
 29dcb43:	lea    0xf(%r8),%rdx
 29dcb47:	mov    %rdx,%r8
 29dcb4a:	and    $0xfffffffffffffff0,%r8
 29dcb4e:	add    %rdi,%r8
 29dcb51:	mov    0x4(%r14),%r9d
 29dcb55:	cmp    %r9,%r8
 29dcb58:	ja     29df4f7 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4b37>
 29dcb5e:	lea    0xf(%rcx),%r9d
 29dcb62:	and    $0xfffffff0,%r9d
 29dcb66:	lea    (%rax,%r9,1),%r10d
 29dcb6a:	mov    %r10d,(%r14)
 29dcb6d:	mov    0xc0(%rsp),%rcx
 29dcb75:	mov    0x20(%rcx),%r11
 29dcb79:	lea    (%r11,%rdi,1),%rcx
 29dcb7d:	movl   $0xa800000e,(%r11,%rdi,1)
 29dcb85:	mov    0x60(%rsp),%rsi
 29dcb8a:	mov    0x28(%rsi),%rsi
 29dcb8e:	mov    0x194(%rsi),%esi
 29dcb94:	mov    %esi,0x4(%r11,%rdi,1)
 29dcb99:	and    $0xfffffffffffffff0,%rdx
 29dcb9d:	mov    %edx,0x8(%r11,%rdi,1)
 29dcba2:	mov    %eax,(%rsp)
 29dcba5:	mov    0x78(%rsp),%rdx
 29dcbaa:	mov    %edx,0x10(%rcx)
 29dcbad:	test   %eax,%eax
 29dcbaf:	je     29dfc7f <wasm[0]::function[1013]::helper::array_indexed_publish+0x52bf>
 29dcbb5:	mov    0xc0(%rsp),%rcx
 29dcbbd:	mov    0x28(%rcx),%rcx
 29dcbc1:	mov    0xc0(%rsp),%rdx
 29dcbc9:	mov    0x20(%rdx),%rsi
 29dcbcd:	mov    %eax,%eax
 29dcbcf:	lea    (%rsi,%rax,1),%rdx
 29dcbd3:	lea    0x10(%rsi,%rax,1),%rdi
 29dcbd8:	xor    %r8,%r8
 29dcbdb:	cmp    %rcx,%rax
 29dcbde:	cmova  %r8,%rdi
 29dcbe2:	mov    (%rdi),%edi
 29dcbe4:	cmp    %rdi,%r12
 29dcbe7:	ja     29dfc81 <wasm[0]::function[1013]::helper::array_indexed_publish+0x52c1>
 29dcbed:	lea    0x14(%rsi,%rax,1),%r13
 29dcbf2:	mov    %r13,%rax
 29dcbf5:	add    %r15,%rax
 29dcbf8:	jb     29dfc83 <wasm[0]::function[1013]::helper::array_indexed_publish+0x52c3>
 29dcbfe:	add    %rsi,%rcx
 29dcc01:	cmp    %rcx,%rax
 29dcc04:	ja     29dfc85 <wasm[0]::function[1013]::helper::array_indexed_publish+0x52c5>
 29dcc0a:	mov    0x10(%rsp),%edi
 29dcc0e:	mov    0x28(%rsp),%esi
 29dcc12:	mov    0x18(%rsp),%eax
 29dcc16:	mov    0x8(%rsp),%ecx
 29dcc1a:	lea    0x14(%rdx,%r12,4),%rbx
 29dcc1f:	test   %r12,%r12
 29dcc22:	je     29dcc7c <wasm[0]::function[1013]::helper::array_indexed_publish+0x22bc>
 29dcc28:	mov    %edi,0x30(%rsp)
 29dcc2c:	mov    %esi,0x20(%rsp)
 29dcc30:	mov    %eax,0x28(%rsp)
 29dcc34:	mov    %ecx,0x10(%rsp)
 29dcc38:	mov    0xc8(%rsp),%rcx
 29dcc40:	mov    (%rcx),%rax
 29dcc43:	mov    0xa0(%rsp),%r9
 29dcc4b:	cmp    %r9,%rax
 29dcc4e:	jae    29df52a <wasm[0]::function[1013]::helper::array_indexed_publish+0x4b6a>
 29dcc54:	movl   $0x0,0x0(%r13)
 29dcc5c:	mov    0x30(%rsp),%edi
 29dcc60:	mov    0x20(%rsp),%esi
 29dcc64:	mov    0x28(%rsp),%eax
 29dcc68:	mov    0x10(%rsp),%ecx
 29dcc6c:	add    $0x4,%r13
 29dcc73:	cmp    %rbx,%r13
 29dcc76:	jne    29dcc28 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2268>
 29dcc7c:	mov    %edi,0x20(%rsp)
 29dcc80:	mov    %esi,0x30(%rsp)
 29dcc84:	xor    %ebx,%ebx
 29dcc86:	mov    $0xb0000042,%r13d
 29dcc8c:	mov    0x60(%rsp),%rdi
 29dcc91:	mov    %r13,%r15
 29dcc94:	mov    0x28(%rdi),%rdx
 29dcc98:	mov    0x120(%rdx),%r12d
 29dcc9f:	mov    %r12,0xb0(%rsp)
 29dcca7:	mov    $0x20,%r13d
 29dccad:	mov    %r13,0xa8(%rsp)
 29dccb5:	mov    $0x10,%r12d
 29dccbb:	mov    %r12,0x90(%rsp)
 29dccc3:	mov    0x13c(%rdx),%edx
 29dccc9:	mov    %rdx,0x88(%rsp)
 29dccd1:	mov    %eax,0x10(%rsp)
 29dccd5:	mov    %ecx,0x28(%rsp)
 29dccd9:	mov    0xc8(%rsp),%rcx
 29dcce1:	mov    (%rcx),%rax
 29dcce4:	mov    0xa0(%rsp),%rcx
 29dccec:	cmp    %rcx,%rax
 29dccef:	jae    29df55e <wasm[0]::function[1013]::helper::array_indexed_publish+0x4b9e>
 29dccf5:	mov    0x78(%rsp),%rcx
 29dccfa:	jmp    29dcd04 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2344>
 29dccff:	mov    0x78(%rsp),%rcx
 29dcd04:	cmp    %ecx,%ebx
 29dcd06:	jae    29dcffd <wasm[0]::function[1013]::helper::array_indexed_publish+0x263d>
 29dcd0c:	mov    0x20(%rsp),%eax
 29dcd10:	test   %eax,%eax
 29dcd12:	je     29dfc87 <wasm[0]::function[1013]::helper::array_indexed_publish+0x52c7>
 29dcd18:	test   %eax,%eax
 29dcd1a:	je     29dfc89 <wasm[0]::function[1013]::helper::array_indexed_publish+0x52c9>
 29dcd20:	mov    0xc0(%rsp),%rcx
 29dcd28:	mov    0x28(%rcx),%rcx
 29dcd2c:	mov    0xc0(%rsp),%rsi
 29dcd34:	mov    0x20(%rsi),%rdx
 29dcd38:	mov    %eax,%r8d
 29dcd3b:	lea    0x10(%rdx,%r8,1),%rdi
 29dcd40:	xor    %rsi,%rsi
 29dcd43:	cmp    %rcx,%r8
 29dcd46:	cmova  %rsi,%rdi
 29dcd4a:	mov    (%rdi),%edi
 29dcd4c:	mov    %rbx,%r8
 29dcd4f:	shr    $0x6,%r8d
 29dcd53:	cmp    %edi,%r8d
 29dcd56:	jae    29dfc8b <wasm[0]::function[1013]::helper::array_indexed_publish+0x52cb>
 29dcd5c:	mov    %edi,%r9d
 29dcd5f:	shl    $0x3,%r9
 29dcd63:	shr    $0x20,%r9
 29dcd67:	test   %r9,%r9
 29dcd6a:	jne    29dfc8d <wasm[0]::function[1013]::helper::array_indexed_publish+0x52cd>
 29dcd70:	shl    $0x3,%edi
 29dcd73:	add    $0x18,%edi
 29dcd76:	jb     29dfc8f <wasm[0]::function[1013]::helper::array_indexed_publish+0x52cf>
 29dcd7c:	add    %edi,%eax
 29dcd7e:	jb     29dfc91 <wasm[0]::function[1013]::helper::array_indexed_publish+0x52d1>
 29dcd84:	mov    %eax,%r9d
 29dcd87:	add    %r9,%rdx
 29dcd8a:	cmp    %rcx,%r9
 29dcd8d:	cmova  %rsi,%rdx
 29dcd91:	shl    $0x3,%r8d
 29dcd95:	add    $0x18,%r8d
 29dcd9c:	sub    %r8d,%edi
 29dcd9f:	sub    %rdi,%rdx
 29dcda2:	mov    (%rdx),%r8
 29dcda5:	bt     %rbx,%r8
 29dcda9:	jb     29dcdc4 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2404>
 29dcdaf:	mov    0x88(%rsp),%r12
 29dcdb7:	mov    0xb8(%rsp),%r13
 29dcdbf:	jmp    29dcfda <wasm[0]::function[1013]::helper::array_indexed_publish+0x261a>
 29dcdc4:	mov    0x30(%rsp),%eax
 29dcdc8:	test   %eax,%eax
 29dcdca:	je     29dfc93 <wasm[0]::function[1013]::helper::array_indexed_publish+0x52d3>
 29dcdd0:	test   %eax,%eax
 29dcdd2:	je     29dfc95 <wasm[0]::function[1013]::helper::array_indexed_publish+0x52d5>
 29dcdd8:	mov    0xc0(%rsp),%rcx
 29dcde0:	mov    0x28(%rcx),%rcx
 29dcde4:	mov    0xc0(%rsp),%rdx
 29dcdec:	mov    0x20(%rdx),%rdx
 29dcdf0:	mov    %eax,%r8d
 29dcdf3:	lea    0x10(%rdx,%r8,1),%rdi
 29dcdf8:	xor    %rsi,%rsi
 29dcdfb:	cmp    %rcx,%r8
 29dcdfe:	cmova  %rsi,%rdi
 29dce02:	mov    (%rdi),%edi
 29dce04:	cmp    %edi,%ebx
 29dce06:	jae    29dfc97 <wasm[0]::function[1013]::helper::array_indexed_publish+0x52d7>
 29dce0c:	mov    %edi,%r8d
 29dce0f:	shl    $0x3,%r8
 29dce13:	shr    $0x20,%r8
 29dce17:	test   %r8,%r8
 29dce1a:	jne    29dfc99 <wasm[0]::function[1013]::helper::array_indexed_publish+0x52d9>
 29dce20:	shl    $0x3,%edi
 29dce23:	add    $0x18,%edi
 29dce26:	jb     29dfc9b <wasm[0]::function[1013]::helper::array_indexed_publish+0x52db>
 29dce2c:	add    %edi,%eax
 29dce2e:	jb     29dfc9d <wasm[0]::function[1013]::helper::array_indexed_publish+0x52dd>
 29dce34:	mov    %eax,%r8d
 29dce37:	lea    (%rdx,%r8,1),%rax
 29dce3b:	cmp    %rcx,%r8
 29dce3e:	cmova  %rsi,%rax
 29dce42:	mov    %rbx,%rcx
 29dce45:	shl    $0x3,%ecx
 29dce48:	add    $0x18,%ecx
 29dce4e:	sub    %ecx,%edi
 29dce50:	sub    %rdi,%rax
 29dce53:	mov    (%rax),%r12
 29dce56:	movl   $0x0,0x38(%rsp)
 29dce5e:	mov    (%r14),%eax
 29dce61:	mov    %eax,%edx
 29dce63:	lea    0x20(%rdx),%rcx
 29dce67:	mov    0x4(%r14),%esi
 29dce6b:	cmp    %rsi,%rcx
 29dce6e:	ja     29df597 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4bd7>
 29dce74:	lea    0x20(%rax),%ecx
 29dce77:	mov    %ecx,(%r14)
 29dce7a:	mov    0xc0(%rsp),%rcx
 29dce82:	mov    0x20(%rcx),%rsi
 29dce86:	lea    (%rsi,%rdx,1),%rcx
 29dce8a:	movl   $0xb0000042,(%rsi,%rdx,1)
 29dce91:	mov    0xb0(%rsp),%rdi
 29dce99:	mov    %edi,0x4(%rsi,%rdx,1)
 29dce9d:	mov    0xb8(%rsp),%r13
 29dcea5:	mov    %r13d,0x8(%rsi,%rdx,1)
 29dceaa:	mov    %eax,0x40(%rsp)
 29dceae:	mov    %r12,0x10(%rcx)
 29dceb2:	movl   $0x3,0x18(%rcx)
 29dceb9:	mov    0x38(%rsp),%edx
 29dcebd:	mov    %edx,0x1c(%rcx)
 29dcec0:	mov    0x60(%rsp),%rdi
 29dcec5:	mov    0xa20(%rdi),%ecx
 29dcecb:	mov    %ecx,0x38(%rsp)
 29dcecf:	test   %eax,%eax
 29dced1:	je     29dfc9f <wasm[0]::function[1013]::helper::array_indexed_publish+0x52df>
 29dced7:	test   %ecx,%ecx
 29dced9:	je     29dfca1 <wasm[0]::function[1013]::helper::array_indexed_publish+0x52e1>
 29dcedf:	mov    (%r14),%eax
 29dcee2:	mov    %eax,%edx
 29dcee4:	lea    0x20(%rdx),%rcx
 29dcee8:	mov    0x4(%r14),%esi
 29dceec:	cmp    %rsi,%rcx
 29dceef:	ja     29df5d7 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4c17>
 29dcef5:	mov    0x88(%rsp),%r12
 29dcefd:	lea    0x20(%rax),%ecx
 29dcf00:	mov    %ecx,(%r14)
 29dcf03:	mov    0xc0(%rsp),%rcx
 29dcf0b:	mov    0x20(%rcx),%rsi
 29dcf0f:	lea    (%rsi,%rdx,1),%rcx
 29dcf13:	movl   $0xb0000072,(%rsi,%rdx,1)
 29dcf1a:	mov    %r12d,0x4(%rsi,%rdx,1)
 29dcf1f:	mov    %r13d,0x8(%rsi,%rdx,1)
 29dcf24:	movl   $0xe,0x10(%rcx)
 29dcf2b:	mov    0x40(%rsp),%edx
 29dcf2f:	mov    %edx,0x14(%rcx)
 29dcf32:	mov    0x38(%rsp),%edx
 29dcf36:	mov    %edx,0x18(%rcx)
 29dcf39:	mov    %edx,0x1c(%rcx)
 29dcf3c:	mov    (%rsp),%ecx
 29dcf3f:	test   %ecx,%ecx
 29dcf41:	je     29dfca3 <wasm[0]::function[1013]::helper::array_indexed_publish+0x52e3>
 29dcf47:	test   %eax,%eax
 29dcf49:	je     29dfca5 <wasm[0]::function[1013]::helper::array_indexed_publish+0x52e5>
 29dcf4f:	test   %ecx,%ecx
 29dcf51:	je     29dfca7 <wasm[0]::function[1013]::helper::array_indexed_publish+0x52e7>
 29dcf57:	mov    0xc0(%rsp),%rdx
 29dcf5f:	mov    0x28(%rdx),%rdx
 29dcf63:	mov    0xc0(%rsp),%rsi
 29dcf6b:	mov    0x20(%rsi),%rsi
 29dcf6f:	mov    %ecx,%r9d
 29dcf72:	lea    0x10(%rsi,%r9,1),%r8
 29dcf77:	xor    %rdi,%rdi
 29dcf7a:	cmp    %rdx,%r9
 29dcf7d:	cmova  %rdi,%r8
 29dcf81:	mov    (%r8),%r8d
 29dcf84:	cmp    %r8d,%ebx
 29dcf87:	jae    29dfca9 <wasm[0]::function[1013]::helper::array_indexed_publish+0x52e9>
 29dcf8d:	mov    %r8d,%r9d
 29dcf90:	shl    $0x2,%r9
 29dcf94:	shr    $0x20,%r9
 29dcf98:	test   %r9,%r9
 29dcf9b:	jne    29dfcab <wasm[0]::function[1013]::helper::array_indexed_publish+0x52eb>
 29dcfa1:	shl    $0x2,%r8d
 29dcfa5:	add    $0x14,%r8d
 29dcfa9:	jb     29dfcad <wasm[0]::function[1013]::helper::array_indexed_publish+0x52ed>
 29dcfaf:	add    %r8d,%ecx
 29dcfb2:	jb     29dfcaf <wasm[0]::function[1013]::helper::array_indexed_publish+0x52ef>
 29dcfb8:	mov    %ecx,%r9d
 29dcfbb:	lea    (%rsi,%r9,1),%rcx
 29dcfbf:	cmp    %rdx,%r9
 29dcfc2:	cmova  %rdi,%rcx
 29dcfc6:	mov    %rbx,%rsi
 29dcfc9:	shl    $0x2,%esi
 29dcfcc:	add    $0x14,%esi
 29dcfd2:	sub    %esi,%r8d
 29dcfd5:	sub    %r8,%rcx
 29dcfd8:	mov    %eax,(%rcx)
 29dcfda:	mov    0x10(%rsp),%eax
 29dcfde:	mov    0x28(%rsp),%ecx
 29dcfe2:	add    $0x1,%ebx
 29dcfe8:	mov    %r12,0x88(%rsp)
 29dcff0:	mov    %r13,0xb8(%rsp)
 29dcff8:	jmp    29dccd1 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2311>
 29dcffd:	mov    0x10(%rsp),%r13d
 29dd002:	mov    %r13,%rax
 29dd005:	mov    %r13,0x70(%rsp)
 29dd00a:	test   %eax,%r13d
 29dd00d:	je     29dfcb1 <wasm[0]::function[1013]::helper::array_indexed_publish+0x52f1>
 29dd013:	mov    (%rsp),%r9d
 29dd017:	test   %r9d,%r9d
 29dd01a:	je     29dfcb3 <wasm[0]::function[1013]::helper::array_indexed_publish+0x52f3>
 29dd020:	mov    0x70(%rsp),%rsi
 29dd025:	test   %esi,%r13d
 29dd028:	je     29dfcb5 <wasm[0]::function[1013]::helper::array_indexed_publish+0x52f5>
 29dd02e:	mov    0xc0(%rsp),%r14
 29dd036:	mov    0x28(%r14),%rax
 29dd03a:	mov    0x20(%r14),%rsi
 29dd03e:	mov    %r13d,%edx
 29dd041:	lea    (%rsi,%rdx,1),%r10
 29dd045:	xor    %rsi,%rsi
 29dd048:	cmp    %rax,%rdx
 29dd04b:	cmova  %rsi,%r10
 29dd04f:	mov    %r9d,0x20(%r10)
 29dd053:	mov    0x60(%rsp),%rdi
 29dd058:	mov    0xa00(%rdi),%edx
 29dd05e:	mov    0xa10(%rdi),%eax
 29dd064:	test   %edx,%edx
 29dd066:	je     29dfcb7 <wasm[0]::function[1013]::helper::array_indexed_publish+0x52f7>
 29dd06c:	mov    %edx,0x28(%r10)
 29dd070:	test   %eax,%eax
 29dd072:	je     29dfcb9 <wasm[0]::function[1013]::helper::array_indexed_publish+0x52f9>
 29dd078:	mov    %eax,0x2c(%r10)
 29dd07c:	movl   $0x0,0x30(%r10)
 29dd084:	movl   $0x0,0x24(%r10)
 29dd08c:	mov    0x28(%rsp),%edx
 29dd090:	jmp    29dd530 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2b70>
 29dd095:	mov    0x18(%rsp),%edx
 29dd099:	test   %edx,%edx
 29dd09b:	je     29dfcbb <wasm[0]::function[1013]::helper::array_indexed_publish+0x52fb>
 29dd0a1:	test   %edx,%edx
 29dd0a3:	je     29dfcbd <wasm[0]::function[1013]::helper::array_indexed_publish+0x52fd>
 29dd0a9:	mov    0xc0(%rsp),%r14
 29dd0b1:	mov    0x28(%r14),%rax
 29dd0b5:	mov    0x20(%r14),%rcx
 29dd0b9:	mov    %edx,%edi
 29dd0bb:	lea    (%rcx,%rdi,1),%rsi
 29dd0bf:	xor    %rdx,%rdx
 29dd0c2:	cmp    %rax,%rdi
 29dd0c5:	cmova  %rdx,%rsi
 29dd0c9:	mov    0x30(%rsi),%esi
 29dd0cc:	mov    %esi,0x10(%rsp)
 29dd0d0:	test   %esi,%esi
 29dd0d2:	je     29dfcbf <wasm[0]::function[1013]::helper::array_indexed_publish+0x52ff>
 29dd0d8:	test   %esi,%esi
 29dd0da:	je     29dfcc1 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5301>
 29dd0e0:	mov    %esi,%esi
 29dd0e2:	lea    0x10(%rcx,%rsi,1),%rcx
 29dd0e7:	cmp    %rax,%rsi
 29dd0ea:	cmova  %rdx,%rcx
 29dd0ee:	mov    (%rcx),%eax
 29dd0f0:	mov    %eax,%ebx
 29dd0f2:	mov    %rbx,%r13
 29dd0f5:	shl    $0x2,%r13
 29dd0f9:	mov    $0x20,%ecx
 29dd0fe:	mov    %rcx,%r15
 29dd101:	mov    %r13,%rcx
 29dd104:	shr    $0x20,%rcx
 29dd108:	test   %rcx,%rcx
 29dd10b:	jne    29dfcc3 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5303>
 29dd111:	mov    %rax,%rcx
 29dd114:	shl    $0x2,%ecx
 29dd117:	mov    %rax,0x88(%rsp)
 29dd11f:	add    $0x14,%ecx
 29dd122:	jb     29dfcc5 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5305>
 29dd128:	mov    0x60(%rsp),%rdi
 29dd12d:	mov    0x20(%rdi),%r14
 29dd131:	mov    (%r14),%eax
 29dd134:	mov    %eax,%edx
 29dd136:	mov    %ecx,%esi
 29dd138:	add    $0xf,%rsi
 29dd13f:	mov    %rsi,%rdi
 29dd142:	and    $0xfffffffffffffff0,%rdi
 29dd146:	add    %rdx,%rdi
 29dd149:	mov    0x4(%r14),%r8d
 29dd14d:	cmp    %r8,%rdi
 29dd150:	ja     29df614 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4c54>
 29dd156:	add    $0xf,%ecx
 29dd15c:	and    $0xfffffff0,%ecx
 29dd15f:	add    %eax,%ecx
 29dd161:	mov    %ecx,(%r14)
 29dd164:	mov    0xc0(%rsp),%rcx
 29dd16c:	mov    0x20(%rcx),%rdi
 29dd170:	lea    (%rdi,%rdx,1),%rcx
 29dd174:	movl   $0xa800000e,(%rdi,%rdx,1)
 29dd17b:	mov    0x60(%rsp),%r8
 29dd180:	mov    0x28(%r8),%r8
 29dd184:	mov    0x194(%r8),%r8d
 29dd18b:	mov    %r8d,0x4(%rdi,%rdx,1)
 29dd190:	and    $0xfffffffffffffff0,%rsi
 29dd194:	mov    %esi,0x8(%rdi,%rdx,1)
 29dd198:	mov    %eax,0x28(%rsp)
 29dd19c:	mov    0x88(%rsp),%rsi
 29dd1a4:	mov    %esi,0x10(%rcx)
 29dd1a7:	test   %eax,%eax
 29dd1a9:	je     29dfcc7 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5307>
 29dd1af:	mov    0xc0(%rsp),%rcx
 29dd1b7:	mov    0x28(%rcx),%rdx
 29dd1bb:	mov    0x20(%rcx),%rsi
 29dd1bf:	mov    %eax,%eax
 29dd1c1:	lea    (%rsi,%rax,1),%rcx
 29dd1c5:	lea    0x10(%rsi,%rax,1),%rdi
 29dd1ca:	xor    %r8,%r8
 29dd1cd:	cmp    %rdx,%rax
 29dd1d0:	cmova  %r8,%rdi
 29dd1d4:	mov    (%rdi),%edi
 29dd1d6:	cmp    %rdi,%rbx
 29dd1d9:	ja     29dfcc9 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5309>
 29dd1df:	lea    0x14(%rsi,%rax,1),%r12
 29dd1e4:	mov    %r12,%rax
 29dd1e7:	add    %r13,%rax
 29dd1ea:	jb     29dfccb <wasm[0]::function[1013]::helper::array_indexed_publish+0x530b>
 29dd1f0:	add    %rsi,%rdx
 29dd1f3:	cmp    %rdx,%rax
 29dd1f6:	ja     29dfccd <wasm[0]::function[1013]::helper::array_indexed_publish+0x530d>
 29dd1fc:	mov    0x10(%rsp),%esi
 29dd200:	mov    0x18(%rsp),%eax
 29dd204:	mov    0x8(%rsp),%edx
 29dd208:	lea    0x14(%rcx,%rbx,4),%r13
 29dd20d:	test   %rbx,%rbx
 29dd210:	je     29dd262 <wasm[0]::function[1013]::helper::array_indexed_publish+0x28a2>
 29dd216:	mov    %esi,0x8(%rsp)
 29dd21a:	mov    %eax,0x18(%rsp)
 29dd21e:	mov    %edx,0x10(%rsp)
 29dd222:	mov    0xc8(%rsp),%rcx
 29dd22a:	mov    (%rcx),%rcx
 29dd22d:	mov    0xa0(%rsp),%rax
 29dd235:	cmp    %rax,%rcx
 29dd238:	jae    29df646 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4c86>
 29dd23e:	movl   $0x0,(%r12)
 29dd246:	mov    0x8(%rsp),%esi
 29dd24a:	mov    0x18(%rsp),%eax
 29dd24e:	mov    0x10(%rsp),%edx
 29dd252:	add    $0x4,%r12
 29dd259:	cmp    %r13,%r12
 29dd25c:	jne    29dd216 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2856>
 29dd262:	mov    %esi,0x8(%rsp)
 29dd266:	mov    0x60(%rsp),%rdi
 29dd26b:	mov    0xa20(%rdi),%ecx
 29dd271:	mov    %ecx,0x18(%rsp)
 29dd275:	xor    %ebx,%ebx
 29dd277:	mov    $0xb0000072,%r12d
 29dd27d:	mov    %r12,0x80(%rsp)
 29dd285:	mov    0x28(%rdi),%rcx
 29dd289:	mov    0x13c(%rcx),%r13d
 29dd290:	mov    $0x20,%r12d
 29dd296:	mov    %r12,0x78(%rsp)
 29dd29b:	mov    $0x10,%r12d
 29dd2a1:	mov    %r12,0xb8(%rsp)
 29dd2a9:	mov    %eax,(%rsp)
 29dd2ac:	mov    %edx,0x10(%rsp)
 29dd2b0:	mov    0xc8(%rsp),%rcx
 29dd2b8:	mov    (%rcx),%rax
 29dd2bb:	mov    0xa0(%rsp),%rcx
 29dd2c3:	cmp    %rcx,%rax
 29dd2c6:	jae    29df67a <wasm[0]::function[1013]::helper::array_indexed_publish+0x4cba>
 29dd2cc:	mov    0x88(%rsp),%rcx
 29dd2d4:	jmp    29dd2e1 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2921>
 29dd2d9:	mov    0x88(%rsp),%rcx
 29dd2e1:	cmp    %ecx,%ebx
 29dd2e3:	jae    29dd4a5 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2ae5>
 29dd2e9:	mov    0x8(%rsp),%eax
 29dd2ed:	test   %eax,%eax
 29dd2ef:	je     29dfccf <wasm[0]::function[1013]::helper::array_indexed_publish+0x530f>
 29dd2f5:	test   %eax,%eax
 29dd2f7:	je     29dfcd1 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5311>
 29dd2fd:	mov    0xc0(%rsp),%rcx
 29dd305:	mov    0x28(%rcx),%rcx
 29dd309:	mov    0xc0(%rsp),%rdx
 29dd311:	mov    0x20(%rdx),%rdx
 29dd315:	mov    %eax,%r8d
 29dd318:	lea    0x10(%rdx,%r8,1),%rdi
 29dd31d:	xor    %rsi,%rsi
 29dd320:	cmp    %rcx,%r8
 29dd323:	cmova  %rsi,%rdi
 29dd327:	mov    (%rdi),%edi
 29dd329:	cmp    %edi,%ebx
 29dd32b:	jae    29dfcd3 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5313>
 29dd331:	mov    %edi,%r8d
 29dd334:	shl    $0x2,%r8
 29dd338:	shr    $0x20,%r8
 29dd33c:	test   %r8,%r8
 29dd33f:	jne    29dfcd5 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5315>
 29dd345:	shl    $0x2,%edi
 29dd348:	add    $0x14,%edi
 29dd34b:	jb     29dfcd7 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5317>
 29dd351:	add    %edi,%eax
 29dd353:	jb     29dfcd9 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5319>
 29dd359:	mov    %eax,%r8d
 29dd35c:	lea    (%rdx,%r8,1),%rax
 29dd360:	cmp    %rcx,%r8
 29dd363:	cmova  %rsi,%rax
 29dd367:	mov    %rbx,%r12
 29dd36a:	shl    $0x2,%r12d
 29dd36e:	lea    0x14(%r12),%ecx
 29dd373:	sub    %ecx,%edi
 29dd375:	sub    %rdi,%rax
 29dd378:	mov    (%rax),%eax
 29dd37a:	mov    %eax,0x20(%rsp)
 29dd37e:	test   %eax,%eax
 29dd380:	jne    29dd38e <wasm[0]::function[1013]::helper::array_indexed_publish+0x29ce>
 29dd386:	mov    %r15,%rcx
 29dd389:	jmp    29dd490 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2ad0>
 29dd38e:	test   %eax,%eax
 29dd390:	je     29dfcdb <wasm[0]::function[1013]::helper::array_indexed_publish+0x531b>
 29dd396:	mov    0x18(%rsp),%eax
 29dd39a:	test   %eax,%eax
 29dd39c:	je     29dfcdd <wasm[0]::function[1013]::helper::array_indexed_publish+0x531d>
 29dd3a2:	mov    (%r14),%eax
 29dd3a5:	mov    %eax,%esi
 29dd3a7:	lea    0x20(%rsi),%rcx
 29dd3ab:	mov    0x4(%r14),%edx
 29dd3af:	cmp    %rdx,%rcx
 29dd3b2:	ja     29df6b6 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4cf6>
 29dd3b8:	lea    0x20(%rax),%ecx
 29dd3bb:	mov    %ecx,(%r14)
 29dd3be:	mov    0xc0(%rsp),%rcx
 29dd3c6:	mov    0x20(%rcx),%rdi
 29dd3ca:	lea    (%rdi,%rsi,1),%rdx
 29dd3ce:	movl   $0xb0000072,(%rdi,%rsi,1)
 29dd3d5:	mov    %r13d,0x4(%rdi,%rsi,1)
 29dd3da:	mov    %r15,%rcx
 29dd3dd:	mov    %ecx,0x8(%rdi,%rsi,1)
 29dd3e1:	movl   $0xe,0x10(%rdx)
 29dd3e8:	mov    0x20(%rsp),%esi
 29dd3ec:	mov    %esi,0x14(%rdx)
 29dd3ef:	mov    0x18(%rsp),%esi
 29dd3f3:	mov    %esi,0x18(%rdx)
 29dd3f6:	mov    %esi,0x1c(%rdx)
 29dd3f9:	mov    0x28(%rsp),%edx
 29dd3fd:	test   %edx,%edx
 29dd3ff:	je     29dfcdf <wasm[0]::function[1013]::helper::array_indexed_publish+0x531f>
 29dd405:	test   %eax,%eax
 29dd407:	je     29dfce1 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5321>
 29dd40d:	test   %edx,%edx
 29dd40f:	je     29dfce3 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5323>
 29dd415:	mov    0xc0(%rsp),%rsi
 29dd41d:	mov    0x28(%rsi),%rsi
 29dd421:	mov    0xc0(%rsp),%rdi
 29dd429:	mov    0x20(%rdi),%rdi
 29dd42d:	mov    %edx,%r10d
 29dd430:	lea    0x10(%rdi,%r10,1),%r9
 29dd435:	xor    %r8,%r8
 29dd438:	cmp    %rsi,%r10
 29dd43b:	cmova  %r8,%r9
 29dd43f:	mov    (%r9),%r9d
 29dd442:	cmp    %r9d,%ebx
 29dd445:	jae    29dfce5 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5325>
 29dd44b:	mov    %r9d,%r10d
 29dd44e:	shl    $0x2,%r10
 29dd452:	shr    $0x20,%r10
 29dd456:	test   %r10,%r10
 29dd459:	jne    29dfce7 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5327>
 29dd45f:	shl    $0x2,%r9d
 29dd463:	add    $0x14,%r9d
 29dd467:	jb     29dfce9 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5329>
 29dd46d:	add    %r9d,%edx
 29dd470:	jb     29dfceb <wasm[0]::function[1013]::helper::array_indexed_publish+0x532b>
 29dd476:	mov    %edx,%r10d
 29dd479:	add    %r10,%rdi
 29dd47c:	cmp    %rsi,%r10
 29dd47f:	cmova  %r8,%rdi
 29dd483:	lea    0x14(%r12),%r10d
 29dd488:	sub    %r10d,%r9d
 29dd48b:	sub    %r9,%rdi
 29dd48e:	mov    %eax,(%rdi)
 29dd490:	mov    (%rsp),%eax
 29dd493:	mov    0x10(%rsp),%edx
 29dd497:	add    $0x1,%ebx
 29dd49d:	mov    %rcx,%r15
 29dd4a0:	jmp    29dd2a9 <wasm[0]::function[1013]::helper::array_indexed_publish+0x28e9>
 29dd4a5:	mov    (%rsp),%r13d
 29dd4a9:	mov    %r13,%rax
 29dd4ac:	mov    %r13,0x70(%rsp)
 29dd4b1:	test   %eax,%r13d
 29dd4b4:	je     29dfced <wasm[0]::function[1013]::helper::array_indexed_publish+0x532d>
 29dd4ba:	mov    0x28(%rsp),%edx
 29dd4be:	test   %edx,%edx
 29dd4c0:	je     29dfcef <wasm[0]::function[1013]::helper::array_indexed_publish+0x532f>
 29dd4c6:	mov    0x70(%rsp),%rax
 29dd4cb:	test   %eax,%r13d
 29dd4ce:	je     29dfcf1 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5331>
 29dd4d4:	mov    0xc0(%rsp),%r14
 29dd4dc:	mov    0x28(%r14),%rsi
 29dd4e0:	mov    0x20(%r14),%rax
 29dd4e4:	mov    %r13d,%edi
 29dd4e7:	add    %rdi,%rax
 29dd4ea:	xor    %r8,%r8
 29dd4ed:	cmp    %rsi,%rdi
 29dd4f0:	cmova  %r8,%rax
 29dd4f4:	mov    %edx,0x20(%rax)
 29dd4f7:	mov    0x60(%rsp),%rdi
 29dd4fc:	mov    0xa00(%rdi),%esi
 29dd502:	mov    0xa10(%rdi),%edx
 29dd508:	test   %esi,%esi
 29dd50a:	je     29dfcf3 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5333>
 29dd510:	mov    %esi,0x28(%rax)
 29dd513:	test   %edx,%edx
 29dd515:	je     29dfcf5 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5335>
 29dd51b:	mov    %edx,0x2c(%rax)
 29dd51e:	movl   $0x0,0x30(%rax)
 29dd525:	movl   $0x0,0x24(%rax)
 29dd52c:	mov    0x10(%rsp),%edx
 29dd530:	mov    0x98(%rsp),%r10
 29dd538:	test   %r10d,%r10d
 29dd53b:	je     29dd54b <wasm[0]::function[1013]::helper::array_indexed_publish+0x2b8b>
 29dd541:	mov    0x70(%rsp),%r13
 29dd546:	jmp    29de1c7 <wasm[0]::function[1013]::helper::array_indexed_publish+0x3807>
 29dd54b:	xor    %r10d,%r10d
 29dd54e:	mov    0x70(%rsp),%rdi
 29dd553:	mov    0x70(%rsp),%r13
 29dd558:	test   %edi,%r13d
 29dd55b:	je     29dfcf7 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5337>
 29dd561:	mov    0x70(%rsp),%r11
 29dd566:	test   %r11d,%r13d
 29dd569:	je     29dfcf9 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5339>
 29dd56f:	mov    0xc0(%rsp),%r14
 29dd577:	mov    0x28(%r14),%rax
 29dd57b:	mov    %r13d,%esi
 29dd57e:	mov    %rsi,%rdi
 29dd581:	add    0x20(%r14),%rdi
 29dd585:	xor    %r8,%r8
 29dd588:	cmp    %rax,%rsi
 29dd58b:	cmova  %r8,%rdi
 29dd58f:	mov    0x24(%rdi),%eax
 29dd592:	test   %eax,%eax
 29dd594:	jne    29de1c2 <wasm[0]::function[1013]::helper::array_indexed_publish+0x3802>
 29dd59a:	mov    0xc0(%rsp),%r14
 29dd5a2:	mov    0x28(%r14),%rdi
 29dd5a6:	mov    0x20(%r14),%r9
 29dd5aa:	lea    (%r9,%rsi,1),%rax
 29dd5ae:	xor    %r8,%r8
 29dd5b1:	cmp    %rdi,%rsi
 29dd5b4:	cmova  %r8,%rax
 29dd5b8:	mov    $0x20,%r13d
 29dd5be:	mov    %r13,0xb8(%rsp)
 29dd5c6:	mov    0x20(%rax),%esi
 29dd5c9:	test   %esi,%esi
 29dd5cb:	je     29dfcfb <wasm[0]::function[1013]::helper::array_indexed_publish+0x533b>
 29dd5d1:	test   %esi,%esi
 29dd5d3:	je     29dfcfd <wasm[0]::function[1013]::helper::array_indexed_publish+0x533d>
 29dd5d9:	mov    %esi,%r10d
 29dd5dc:	lea    0x10(%r9,%r10,1),%r9
 29dd5e1:	cmp    %rdi,%r10
 29dd5e4:	cmova  %r8,%r9
 29dd5e8:	mov    (%r9),%r14d
 29dd5eb:	mov    0x18(%rax),%r12
 29dd5ef:	mov    %r14d,%ebx
 29dd5f2:	mov    0x68(%rsp),%rcx
 29dd5f7:	mov    %r14,0x78(%rsp)
 29dd5fc:	cmp    %rbx,%rcx
 29dd5ff:	setb   %al
 29dd602:	cmp    $0x100000,%rcx
 29dd609:	setb   %dil
 29dd60d:	lea    0x8(%r12,%r12,1),%rcx
 29dd612:	mov    0x68(%rsp),%r8
 29dd617:	cmp    %rcx,%r8
 29dd61a:	setbe  %r8b
 29dd61e:	and    %r8d,%edi
 29dd621:	or     %edi,%eax
 29dd623:	test   %al,%al
 29dd625:	jne    29ddbd3 <wasm[0]::function[1013]::helper::array_indexed_publish+0x3213>
 29dd62b:	mov    $0x8,%eax
 29dd630:	mov    %rax,0x90(%rsp)
 29dd638:	shl    $0x2,%r12
 29dd63c:	mov    %esi,0x28(%rsp)
 29dd640:	mov    0x70(%rsp),%r13
 29dd645:	mov    %r13d,0x10(%rsp)
 29dd64a:	mov    %edx,(%rsp)
 29dd64d:	mov    0xc8(%rsp),%rcx
 29dd655:	mov    (%rcx),%rax
 29dd658:	mov    0xa0(%rsp),%rcx
 29dd660:	cmp    %rcx,%rax
 29dd663:	jae    29df6ee <wasm[0]::function[1013]::helper::array_indexed_publish+0x4d2e>
 29dd669:	mov    0x90(%rsp),%rdi
 29dd671:	jmp    29dd67e <wasm[0]::function[1013]::helper::array_indexed_publish+0x2cbe>
 29dd676:	mov    0x90(%rsp),%rdi
 29dd67e:	mov    %edi,%r13d
 29dd681:	imul   $0x3,%r13,%rdx
 29dd685:	cmp    %rdx,%r12
 29dd688:	mov    %r12,0xb0(%rsp)
 29dd690:	jbe    29dd6be <wasm[0]::function[1013]::helper::array_indexed_publish+0x2cfe>
 29dd696:	mov    0x28(%rsp),%esi
 29dd69a:	mov    0x10(%rsp),%r13d
 29dd69f:	mov    %r13,0x70(%rsp)
 29dd6a4:	mov    (%rsp),%edx
 29dd6a7:	shl    $1,%edi
 29dd6a9:	mov    0xb0(%rsp),%r12
 29dd6b1:	mov    %rdi,0x90(%rsp)
 29dd6b9:	jmp    29dd63c <wasm[0]::function[1013]::helper::array_indexed_publish+0x2c7c>
 29dd6be:	mov    %r13,%r12
 29dd6c1:	shl    $0x2,%r12
 29dd6c5:	mov    %r12,%rsi
 29dd6c8:	shr    $0x20,%rsi
 29dd6cc:	test   %rsi,%rsi
 29dd6cf:	jne    29dfcff <wasm[0]::function[1013]::helper::array_indexed_publish+0x533f>
 29dd6d5:	mov    %rdi,%rcx
 29dd6d8:	shl    $0x2,%ecx
 29dd6db:	mov    %rdi,0x90(%rsp)
 29dd6e3:	add    $0x14,%ecx
 29dd6e6:	jb     29dfd01 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5341>
 29dd6ec:	mov    0x60(%rsp),%rdi
 29dd6f1:	mov    0x20(%rdi),%r9
 29dd6f5:	mov    (%r9),%eax
 29dd6f8:	mov    %eax,%r8d
 29dd6fb:	mov    %ecx,%r10d
 29dd6fe:	lea    0xf(%r10),%rdx
 29dd702:	mov    %rdx,%r10
 29dd705:	and    $0xfffffffffffffff0,%r10
 29dd709:	add    %r8,%r10
 29dd70c:	mov    0x4(%r9),%r11d
 29dd710:	mov    %r9,0xa8(%rsp)
 29dd718:	cmp    %r11,%r10
 29dd71b:	ja     29df72a <wasm[0]::function[1013]::helper::array_indexed_publish+0x4d6a>
 29dd721:	lea    0xf(%rcx),%r10d
 29dd725:	and    $0xfffffff0,%r10d
 29dd729:	lea    (%rax,%r10,1),%r11d
 29dd72d:	mov    0xa8(%rsp),%r15
 29dd735:	mov    %r11d,(%r15)
 29dd738:	mov    0xc0(%rsp),%r14
 29dd740:	mov    0x20(%r14),%rsi
 29dd744:	lea    (%rsi,%r8,1),%rcx
 29dd748:	movl   $0xa800000e,(%rsi,%r8,1)
 29dd750:	mov    0x60(%rsp),%rdi
 29dd755:	mov    0x28(%rdi),%rdi
 29dd759:	mov    0x1ac(%rdi),%edi
 29dd75f:	mov    %edi,0x4(%rsi,%r8,1)
 29dd764:	and    $0xfffffffffffffff0,%rdx
 29dd768:	mov    %edx,0x8(%rsi,%r8,1)
 29dd76d:	mov    %eax,0x18(%rsp)
 29dd771:	mov    0x90(%rsp),%rdi
 29dd779:	mov    %edi,0x10(%rcx)
 29dd77c:	test   %eax,%eax
 29dd77e:	je     29dfd03 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5343>
 29dd784:	mov    0xc0(%rsp),%r14
 29dd78c:	mov    0x28(%r14),%rdx
 29dd790:	mov    0x20(%r14),%rsi
 29dd794:	mov    %eax,%eax
 29dd796:	lea    (%rsi,%rax,1),%rcx
 29dd79a:	lea    0x10(%rsi,%rax,1),%rdi
 29dd79f:	xor    %r8,%r8
 29dd7a2:	cmp    %rdx,%rax
 29dd7a5:	cmova  %r8,%rdi
 29dd7a9:	mov    (%rdi),%edi
 29dd7ab:	cmp    %rdi,%r13
 29dd7ae:	ja     29dfd05 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5345>
 29dd7b4:	lea    0x14(%rsi,%rax,1),%rbx
 29dd7b9:	mov    %rbx,%rax
 29dd7bc:	add    %r12,%rax
 29dd7bf:	jb     29dfd07 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5347>
 29dd7c5:	add    %rsi,%rdx
 29dd7c8:	cmp    %rdx,%rax
 29dd7cb:	ja     29dfd09 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5349>
 29dd7d1:	mov    0x28(%rsp),%edx
 29dd7d5:	mov    0x10(%rsp),%eax
 29dd7d9:	mov    (%rsp),%esi
 29dd7dc:	lea    0x14(%rcx,%r13,4),%r12
 29dd7e1:	test   %r13,%r13
 29dd7e4:	je     29dd832 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2e72>
 29dd7ea:	mov    %edx,(%rsp)
 29dd7ed:	mov    %eax,0x10(%rsp)
 29dd7f1:	mov    %esi,0x28(%rsp)
 29dd7f5:	mov    0xc8(%rsp),%rcx
 29dd7fd:	mov    (%rcx),%rax
 29dd800:	mov    0xa0(%rsp),%r10
 29dd808:	cmp    %r10,%rax
 29dd80b:	jae    29df75d <wasm[0]::function[1013]::helper::array_indexed_publish+0x4d9d>
 29dd811:	movl   $0x0,(%rbx)
 29dd817:	mov    (%rsp),%edx
 29dd81a:	mov    0x10(%rsp),%eax
 29dd81e:	mov    0x28(%rsp),%esi
 29dd822:	add    $0x4,%rbx
 29dd829:	cmp    %r12,%rbx
 29dd82c:	jne    29dd7ea <wasm[0]::function[1013]::helper::array_indexed_publish+0x2e2a>
 29dd832:	mov    %edx,(%rsp)
 29dd835:	xor    %ebx,%ebx
 29dd837:	mov    $0x10,%ecx
 29dd83c:	mov    0x60(%rsp),%rdi
 29dd841:	mov    %rcx,%r15
 29dd844:	mov    0x28(%rdi),%rcx
 29dd848:	mov    0x1a8(%rcx),%r14d
 29dd84f:	mov    %r14,0x80(%rsp)
 29dd857:	mov    $0x20,%ecx
 29dd85c:	mov    %rcx,0x88(%rsp)
 29dd864:	mov    %eax,0x28(%rsp)
 29dd868:	mov    %esi,0x10(%rsp)
 29dd86c:	mov    0xc8(%rsp),%rcx
 29dd874:	mov    (%rcx),%rax
 29dd877:	mov    0xa0(%rsp),%rcx
 29dd87f:	cmp    %rcx,%rax
 29dd882:	jae    29df791 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4dd1>
 29dd888:	mov    0x78(%rsp),%rcx
 29dd88d:	jmp    29dd897 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2ed7>
 29dd892:	mov    0x78(%rsp),%rcx
 29dd897:	cmp    %ecx,%ebx
 29dd899:	mov    %rcx,0x78(%rsp)
 29dd89e:	jae    29ddb5a <wasm[0]::function[1013]::helper::array_indexed_publish+0x319a>
 29dd8a4:	mov    (%rsp),%eax
 29dd8a7:	test   %eax,%eax
 29dd8a9:	je     29dfd0b <wasm[0]::function[1013]::helper::array_indexed_publish+0x534b>
 29dd8af:	test   %eax,%eax
 29dd8b1:	je     29dfd0d <wasm[0]::function[1013]::helper::array_indexed_publish+0x534d>
 29dd8b7:	mov    0xc0(%rsp),%r14
 29dd8bf:	mov    0x28(%r14),%rcx
 29dd8c3:	mov    0x20(%r14),%rdx
 29dd8c7:	mov    %eax,%r8d
 29dd8ca:	lea    0x10(%rdx,%r8,1),%rdi
 29dd8cf:	xor    %rsi,%rsi
 29dd8d2:	cmp    %rcx,%r8
 29dd8d5:	cmova  %rsi,%rdi
 29dd8d9:	mov    (%rdi),%edi
 29dd8db:	cmp    %edi,%ebx
 29dd8dd:	jae    29dfd0f <wasm[0]::function[1013]::helper::array_indexed_publish+0x534f>
 29dd8e3:	mov    %edi,%r8d
 29dd8e6:	shl    $0x2,%r8
 29dd8ea:	shr    $0x20,%r8
 29dd8ee:	test   %r8,%r8
 29dd8f1:	jne    29dfd11 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5351>
 29dd8f7:	shl    $0x2,%edi
 29dd8fa:	add    $0x14,%edi
 29dd8fd:	jb     29dfd13 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5353>
 29dd903:	add    %edi,%eax
 29dd905:	jb     29dfd15 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5355>
 29dd90b:	mov    %eax,%r8d
 29dd90e:	add    %r8,%rdx
 29dd911:	cmp    %rcx,%r8
 29dd914:	cmova  %rsi,%rdx
 29dd918:	mov    %rbx,%r8
 29dd91b:	shl    $0x2,%r8d
 29dd91f:	add    $0x14,%r8d
 29dd926:	sub    %r8d,%edi
 29dd929:	sub    %rdi,%rdx
 29dd92c:	mov    (%rdx),%edi
 29dd92e:	mov    %edi,0x8(%rsp)
 29dd932:	test   %edi,%edi
 29dd934:	jne    29dd957 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2f97>
 29dd93a:	mov    0x80(%rsp),%rcx
 29dd942:	mov    0xb8(%rsp),%rdx
 29dd94a:	mov    0xa8(%rsp),%r14
 29dd952:	jmp    29ddb2f <wasm[0]::function[1013]::helper::array_indexed_publish+0x316f>
 29dd957:	mov    0x18(%rsp),%eax
 29dd95b:	test   %eax,%eax
 29dd95d:	je     29dfd17 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5357>
 29dd963:	test   %eax,%eax
 29dd965:	je     29dfd19 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5359>
 29dd96b:	mov    0xc0(%rsp),%r14
 29dd973:	mov    0x28(%r14),%rcx
 29dd977:	mov    0x20(%r14),%rdx
 29dd97b:	mov    %eax,%r9d
 29dd97e:	lea    0x10(%rdx,%r9,1),%r8
 29dd983:	xor    %rsi,%rsi
 29dd986:	cmp    %rcx,%r9
 29dd989:	cmova  %rsi,%r8
 29dd98d:	mov    (%r8),%r8d
 29dd990:	mov    %rbx,%r9
 29dd993:	shr    $0x10,%r9d
 29dd997:	mov    %rbx,%r10
 29dd99a:	xor    %r9d,%r10d
 29dd99d:	imul   $0x7feb352d,%r10d,%r9d
 29dd9a4:	mov    %r9,%r10
 29dd9a7:	shr    $0xf,%r10d
 29dd9ab:	xor    %r10d,%r9d
 29dd9ae:	imul   $0x846ca68b,%r9d,%r12d
 29dd9b5:	mov    %r12,%r9
 29dd9b8:	shr    $0x10,%r9d
 29dd9bc:	xor    %r9d,%r12d
 29dd9bf:	mov    0x90(%rsp),%r9
 29dd9c7:	sub    $0x1,%r9d
 29dd9cb:	and    %r9d,%r12d
 29dd9ce:	cmp    %r8d,%r12d
 29dd9d1:	jae    29dfd1b <wasm[0]::function[1013]::helper::array_indexed_publish+0x535b>
 29dd9d7:	mov    %r8d,%r9d
 29dd9da:	shl    $0x2,%r9
 29dd9de:	shr    $0x20,%r9
 29dd9e2:	test   %r9,%r9
 29dd9e5:	jne    29dfd1d <wasm[0]::function[1013]::helper::array_indexed_publish+0x535d>
 29dd9eb:	shl    $0x2,%r8d
 29dd9ef:	add    $0x14,%r8d
 29dd9f3:	jb     29dfd1f <wasm[0]::function[1013]::helper::array_indexed_publish+0x535f>
 29dd9f9:	add    %r8d,%eax
 29dd9fc:	jb     29dfd21 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5361>
 29dda02:	mov    %eax,%r9d
 29dda05:	lea    (%rdx,%r9,1),%rax
 29dda09:	cmp    %rcx,%r9
 29dda0c:	cmova  %rsi,%rax
 29dda10:	mov    %r12,%r13
 29dda13:	shl    $0x2,%r13d
 29dda17:	lea    0x14(%r13),%ecx
 29dda1b:	sub    %ecx,%r8d
 29dda1e:	sub    %r8,%rax
 29dda21:	mov    (%rax),%eax
 29dda23:	mov    %eax,0x20(%rsp)
 29dda27:	test   %edi,%edi
 29dda29:	je     29dfd23 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5363>
 29dda2f:	mov    0xa8(%rsp),%r14
 29dda37:	mov    (%r14),%eax
 29dda3a:	mov    %eax,%esi
 29dda3c:	lea    0x20(%rsi),%rcx
 29dda40:	mov    0x4(%r14),%edx
 29dda44:	cmp    %rdx,%rcx
 29dda47:	ja     29df7ca <wasm[0]::function[1013]::helper::array_indexed_publish+0x4e0a>
 29dda4d:	lea    0x20(%rax),%ecx
 29dda50:	mov    %ecx,(%r14)
 29dda53:	mov    0xc0(%rsp),%rcx
 29dda5b:	mov    0x20(%rcx),%rdi
 29dda5f:	lea    (%rdi,%rsi,1),%r9
 29dda63:	movl   $0xb0000062,(%rdi,%rsi,1)
 29dda6a:	mov    0x80(%rsp),%rcx
 29dda72:	mov    %ecx,0x4(%rdi,%rsi,1)
 29dda76:	mov    0xb8(%rsp),%rdx
 29dda7e:	mov    %edx,0x8(%rdi,%rsi,1)
 29dda82:	mov    %ebx,%esi
 29dda84:	mov    %rsi,0x10(%r9)
 29dda88:	mov    0x8(%rsp),%esi
 29dda8c:	mov    %esi,0x18(%r9)
 29dda90:	mov    0x20(%rsp),%esi
 29dda94:	mov    %esi,0x1c(%r9)
 29dda98:	mov    0x18(%rsp),%esi
 29dda9c:	test   %esi,%esi
 29dda9e:	je     29dfd25 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5365>
 29ddaa4:	test   %eax,%eax
 29ddaa6:	je     29dfd27 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5367>
 29ddaac:	test   %esi,%esi
 29ddaae:	je     29dfd29 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5369>
 29ddab4:	mov    0xc0(%rsp),%r11
 29ddabc:	mov    0x28(%r11),%rdi
 29ddac0:	mov    0xc0(%rsp),%r8
 29ddac8:	mov    0x20(%r8),%r8
 29ddacc:	mov    %esi,%r11d
 29ddacf:	lea    0x10(%r8,%r11,1),%r10
 29ddad4:	xor    %r9,%r9
 29ddad7:	cmp    %rdi,%r11
 29ddada:	cmova  %r9,%r10
 29ddade:	mov    (%r10),%r10d
 29ddae1:	cmp    %r10d,%r12d
 29ddae4:	jae    29dfd2b <wasm[0]::function[1013]::helper::array_indexed_publish+0x536b>
 29ddaea:	mov    %r10d,%r11d
 29ddaed:	shl    $0x2,%r11
 29ddaf1:	shr    $0x20,%r11
 29ddaf5:	test   %r11,%r11
 29ddaf8:	jne    29dfd2d <wasm[0]::function[1013]::helper::array_indexed_publish+0x536d>
 29ddafe:	shl    $0x2,%r10d
 29ddb02:	add    $0x14,%r10d
 29ddb06:	jb     29dfd2f <wasm[0]::function[1013]::helper::array_indexed_publish+0x536f>
 29ddb0c:	add    %r10d,%esi
 29ddb0f:	jb     29dfd31 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5371>
 29ddb15:	mov    %esi,%r11d
 29ddb18:	lea    (%r8,%r11,1),%rsi
 29ddb1c:	cmp    %rdi,%r11
 29ddb1f:	cmova  %r9,%rsi
 29ddb23:	lea    0x14(%r13),%edi
 29ddb27:	sub    %edi,%r10d
 29ddb2a:	sub    %r10,%rsi
 29ddb2d:	mov    %eax,(%rsi)
 29ddb2f:	mov    0x28(%rsp),%eax
 29ddb33:	mov    0x10(%rsp),%esi
 29ddb37:	add    $0x1,%ebx
 29ddb3d:	mov    %rcx,0x80(%rsp)
 29ddb45:	mov    %r14,0xa8(%rsp)
 29ddb4d:	mov    %rdx,0xb8(%rsp)
 29ddb55:	jmp    29dd864 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2ea4>
 29ddb5a:	mov    0x60(%rsp),%rdi
 29ddb5f:	mov    0x9f0(%rdi),%eax
 29ddb65:	mov    0x28(%rsp),%r13d
 29ddb6a:	mov    %r13,0x70(%rsp)
 29ddb6f:	xor    %r10d,%r10d
 29ddb72:	mov    0x70(%rsp),%rcx
 29ddb77:	test   %ecx,%r13d
 29ddb7a:	je     29dfd33 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5373>
 29ddb80:	test   %eax,%eax
 29ddb82:	je     29dfd35 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5375>
 29ddb88:	test   %ecx,%r13d
 29ddb8b:	je     29dfd37 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5377>
 29ddb91:	mov    0xc0(%rsp),%r14
 29ddb99:	mov    0x28(%r14),%rsi
 29ddb9d:	mov    0x20(%r14),%rdx
 29ddba1:	mov    %r13d,%edi
 29ddba4:	add    %rdi,%rdx
 29ddba7:	xor    %r8,%r8
 29ddbaa:	cmp    %rsi,%rdi
 29ddbad:	cmova  %r8,%rdx
 29ddbb1:	mov    %eax,0x20(%rdx)
 29ddbb4:	mov    0x18(%rsp),%eax
 29ddbb8:	test   %eax,%eax
 29ddbba:	je     29dfd39 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5379>
 29ddbc0:	mov    %eax,0x10(%rdx)
 29ddbc3:	movl   $0x1,0x24(%rdx)
 29ddbca:	mov    0x10(%rsp),%edx
 29ddbce:	jmp    29de1c2 <wasm[0]::function[1013]::helper::array_indexed_publish+0x3802>
 29ddbd3:	mov    0x68(%rsp),%rcx
 29ddbd8:	mov    %r12,0xb0(%rsp)
 29ddbe0:	cmp    %rbx,%rcx
 29ddbe3:	jb     29de067 <wasm[0]::function[1013]::helper::array_indexed_publish+0x36a7>
 29ddbe9:	mov    0x78(%rsp),%rax
 29ddbee:	mov    0x78(%rsp),%r15
 29ddbf3:	test   %eax,%r15d
 29ddbf6:	je     29ddc06 <wasm[0]::function[1013]::helper::array_indexed_publish+0x3246>
 29ddbfc:	mov    0x78(%rsp),%r14
 29ddc01:	jmp    29ddc0c <wasm[0]::function[1013]::helper::array_indexed_publish+0x324c>
 29ddc06:	mov    $0x8,%r14d
 29ddc0c:	mov    %esi,0x18(%rsp)
 29ddc10:	mov    0x70(%rsp),%r13
 29ddc15:	mov    %r13d,0x10(%rsp)
 29ddc1a:	mov    %edx,0x28(%rsp)
 29ddc1e:	mov    0xc8(%rsp),%rcx
 29ddc26:	mov    (%rcx),%rax
 29ddc29:	mov    0xa0(%rsp),%rcx
 29ddc31:	cmp    %rcx,%rax
 29ddc34:	jae    29df810 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4e50>
 29ddc3a:	mov    %r14d,%r13d
 29ddc3d:	mov    0x68(%rsp),%rcx
 29ddc42:	cmp    %r13,%rcx
 29ddc45:	jb     29ddc65 <wasm[0]::function[1013]::helper::array_indexed_publish+0x32a5>
 29ddc4b:	mov    0x18(%rsp),%esi
 29ddc4f:	mov    0x10(%rsp),%r13d
 29ddc54:	mov    %r13,0x70(%rsp)
 29ddc59:	mov    0x28(%rsp),%edx
 29ddc5d:	shl    $1,%r14d
 29ddc60:	jmp    29ddc0c <wasm[0]::function[1013]::helper::array_indexed_publish+0x324c>
 29ddc65:	mov    %r13,%r12
 29ddc68:	shl    $0x2,%r12
 29ddc6c:	mov    %r12,%rax
 29ddc6f:	shr    $0x20,%rax
 29ddc73:	test   %rax,%rax
 29ddc76:	jne    29dfd3b <wasm[0]::function[1013]::helper::array_indexed_publish+0x537b>
 29ddc7c:	mov    %r14,%rcx
 29ddc7f:	shl    $0x2,%ecx
 29ddc82:	add    $0x14,%ecx
 29ddc85:	jb     29dfd3d <wasm[0]::function[1013]::helper::array_indexed_publish+0x537d>
 29ddc8b:	mov    0x60(%rsp),%rdi
 29ddc90:	mov    0x20(%rdi),%rsi
 29ddc94:	mov    (%rsi),%eax
 29ddc96:	mov    %eax,%edx
 29ddc98:	mov    %ecx,%edi
 29ddc9a:	lea    0xf(%rdi),%r10
 29ddc9e:	mov    %r10,%rdi
 29ddca1:	and    $0xfffffffffffffff0,%rdi
 29ddca5:	add    %rdx,%rdi
 29ddca8:	mov    0x4(%rsi),%r8d
 29ddcac:	cmp    %r8,%rdi
 29ddcaf:	ja     29df847 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4e87>
 29ddcb5:	add    $0xf,%ecx
 29ddcbb:	and    $0xfffffff0,%ecx
 29ddcbe:	add    %eax,%ecx
 29ddcc0:	mov    %ecx,(%rsi)
 29ddcc2:	mov    0xc0(%rsp),%r11
 29ddcca:	mov    0x20(%r11),%rsi
 29ddcce:	lea    (%rsi,%rdx,1),%rcx
 29ddcd2:	movl   $0xa800000e,(%rsi,%rdx,1)
 29ddcd9:	mov    0x60(%rsp),%rdi
 29ddcde:	mov    0x28(%rdi),%rdi
 29ddce2:	mov    0x194(%rdi),%edi
 29ddce8:	mov    %edi,0x4(%rsi,%rdx,1)
 29ddcec:	and    $0xfffffffffffffff0,%r10
 29ddcf0:	mov    %r10d,0x8(%rsi,%rdx,1)
 29ddcf5:	mov    %eax,(%rsp)
 29ddcf8:	mov    %r14d,0x10(%rcx)
 29ddcfc:	test   %eax,%eax
 29ddcfe:	je     29dfd3f <wasm[0]::function[1013]::helper::array_indexed_publish+0x537f>
 29ddd04:	mov    0xc0(%rsp),%r14
 29ddd0c:	mov    0x28(%r14),%rcx
 29ddd10:	mov    0x20(%r14),%rdx
 29ddd14:	mov    %eax,%eax
 29ddd16:	lea    (%rdx,%rax,1),%rsi
 29ddd1a:	lea    0x10(%rdx,%rax,1),%rdi
 29ddd1f:	xor    %r8,%r8
 29ddd22:	cmp    %rcx,%rax
 29ddd25:	cmova  %r8,%rdi
 29ddd29:	mov    (%rdi),%edi
 29ddd2b:	cmp    %rdi,%r13
 29ddd2e:	ja     29dfd41 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5381>
 29ddd34:	lea    0x14(%rdx,%rax,1),%r14
 29ddd39:	mov    %r14,%rdi
 29ddd3c:	add    %r12,%rdi
 29ddd3f:	jb     29dfd43 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5383>
 29ddd45:	lea    (%rdx,%rcx,1),%rax
 29ddd49:	cmp    %rax,%rdi
 29ddd4c:	ja     29dfd45 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5385>
 29ddd52:	mov    0x18(%rsp),%edi
 29ddd56:	mov    0x10(%rsp),%eax
 29ddd5a:	mov    %rax,0x70(%rsp)
 29ddd5f:	mov    0x28(%rsp),%edx
 29ddd63:	lea    0x14(%rsi,%r13,4),%r12
 29ddd68:	test   %r13,%r13
 29ddd6b:	je     29dddc8 <wasm[0]::function[1013]::helper::array_indexed_publish+0x3408>
 29ddd71:	mov    %edi,0x28(%rsp)
 29ddd75:	mov    0x70(%rsp),%r13
 29ddd7a:	mov    %r13d,0x10(%rsp)
 29ddd7f:	mov    %edx,0x18(%rsp)
 29ddd83:	mov    0xc8(%rsp),%rcx
 29ddd8b:	mov    (%rcx),%rcx
 29ddd8e:	mov    0xa0(%rsp),%rax
 29ddd96:	cmp    %rax,%rcx
 29ddd99:	jae    29df879 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4eb9>
 29ddd9f:	movl   $0x0,(%r14)
 29ddda6:	mov    0x28(%rsp),%edi
 29dddaa:	mov    0x10(%rsp),%r13d
 29dddaf:	mov    %r13,0x70(%rsp)
 29dddb4:	mov    0x18(%rsp),%edx
 29dddb8:	add    $0x4,%r14
 29dddbf:	cmp    %r12,%r14
 29dddc2:	jne    29ddd71 <wasm[0]::function[1013]::helper::array_indexed_publish+0x33b1>
 29dddc8:	mov    (%rsp),%esi
 29dddcb:	test   %esi,%esi
 29dddcd:	je     29dfd47 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5387>
 29dddd3:	test   %edi,%edi
 29dddd5:	je     29dfd49 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5389>
 29ddddb:	test   %esi,%esi
 29ddddd:	je     29dfd4b <wasm[0]::function[1013]::helper::array_indexed_publish+0x538b>
 29ddde3:	mov    0xc0(%rsp),%r14
 29dddeb:	mov    0x28(%r14),%r11
 29dddef:	mov    0x20(%r14),%r8
 29dddf3:	mov    %r8,0x88(%rsp)
 29dddfb:	mov    %esi,%r9d
 29dddfe:	mov    0x88(%rsp),%rax
 29dde06:	lea    (%rax,%r9,1),%r8
 29dde0a:	lea    0x10(%rax,%r9,1),%r10
 29dde0f:	xor    %rax,%rax
 29dde12:	cmp    %r11,%r9
 29dde15:	cmova  %rax,%r10
 29dde19:	mov    (%r10),%r10d
 29dde1c:	cmp    %r10,%rbx
 29dde1f:	ja     29dfd4d <wasm[0]::function[1013]::helper::array_indexed_publish+0x538d>
 29dde25:	test   %edi,%edi
 29dde27:	je     29dfd4f <wasm[0]::function[1013]::helper::array_indexed_publish+0x538f>
 29dde2d:	mov    %edi,%r13d
 29dde30:	mov    0x88(%rsp),%rcx
 29dde38:	mov    %r13,%r12
 29dde3b:	lea    (%rcx,%r12,1),%r10
 29dde3f:	mov    %r12,0x80(%rsp)
 29dde47:	lea    0x10(%rcx,%r13,1),%r12
 29dde4c:	mov    0x80(%rsp),%r13
 29dde54:	cmp    %r11,%r13
 29dde57:	cmova  %rax,%r12
 29dde5b:	mov    (%r12),%eax
 29dde5f:	cmp    %rax,%rbx
 29dde62:	ja     29dfd51 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5391>
 29dde68:	mov    0x88(%rsp),%rax
 29dde70:	lea    0x14(%rax,%r9,1),%r14
 29dde75:	mov    %rbx,%rax
 29dde78:	shl    $0x2,%rax
 29dde7c:	add    %rax,%r14
 29dde7f:	jb     29dfd53 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5393>
 29dde85:	add    %rcx,%r11
 29dde88:	cmp    %r11,%r14
 29dde8b:	ja     29dfd55 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5395>
 29dde91:	lea    0x14(%rcx,%r13,1),%r12
 29dde96:	add    %rax,%r12
 29dde99:	jb     29dfd57 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5397>
 29dde9f:	cmp    %r11,%r12
 29ddea2:	ja     29dfd59 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5399>
 29ddea8:	mov    0x78(%rsp),%r11
 29ddead:	mov    0x78(%rsp),%r15
 29ddeb2:	test   %r11d,%r15d
 29ddeb5:	jne    29ddeca <wasm[0]::function[1013]::helper::array_indexed_publish+0x350a>
 29ddebb:	mov    0x70(%rsp),%rax
 29ddec0:	mov    0x70(%rsp),%r13
 29ddec5:	jmp    29de01f <wasm[0]::function[1013]::helper::array_indexed_publish+0x365f>
 29ddeca:	mov    (%rsp),%r11d
 29ddece:	mov    0x88(%rsp),%rax
 29dded6:	lea    0x14(%rax,%r9,1),%r12
 29ddedb:	mov    0x80(%rsp),%r13
 29ddee3:	lea    0x14(%rax,%r13,1),%r13
 29ddee8:	xor    %r15d,%r15d
 29ddeeb:	lea    0x14(%r8,%rbx,4),%r14
 29ddef0:	lea    0x14(%r10,%rbx,4),%rbx
 29ddef5:	cmp    %r13,%r12
 29ddef8:	jae    29ddf06 <wasm[0]::function[1013]::helper::array_indexed_publish+0x3546>
 29ddefe:	mov    %r11,%rsi
 29ddf01:	jmp    29ddfa1 <wasm[0]::function[1013]::helper::array_indexed_publish+0x35e1>
 29ddf06:	mov    %r11,%rsi
 29ddf09:	mov    %r11d,0x20(%rsp)
 29ddf0e:	mov    %edi,0x18(%rsp)
 29ddf12:	mov    0x70(%rsp),%r13
 29ddf17:	mov    %r13d,0x10(%rsp)
 29ddf1c:	mov    %esi,0x28(%rsp)
 29ddf20:	mov    %edx,(%rsp)
 29ddf23:	mov    0xc8(%rsp),%rcx
 29ddf2b:	mov    (%rcx),%rax
 29ddf2e:	mov    0xa0(%rsp),%rcx
 29ddf36:	cmp    %rcx,%rax
 29ddf39:	jae    29df8ad <wasm[0]::function[1013]::helper::array_indexed_publish+0x4eed>
 29ddf3f:	sub    $0x4,%rbx
 29ddf43:	mov    (%rbx),%eax
 29ddf45:	sub    $0x4,%r14
 29ddf49:	mov    %eax,(%r14)
 29ddf4c:	mov    0x10(%rsp),%r13d
 29ddf51:	mov    %r13,0x70(%rsp)
 29ddf56:	mov    0x28(%rsp),%esi
 29ddf5a:	mov    (%rsp),%edx
 29ddf5d:	mov    0x20(%rsp),%r11d
 29ddf62:	mov    0x18(%rsp),%edi
 29ddf66:	mov    0x88(%rsp),%rax
 29ddf6e:	mov    0x80(%rsp),%r13
 29ddf76:	lea    0x14(%rax,%r13,1),%rax
 29ddf7b:	mov    0x78(%rsp),%r15
 29ddf80:	sub    $0x1,%r15d
 29ddf84:	mov    %r15,0x78(%rsp)
 29ddf89:	cmp    %rax,%rbx
 29ddf8c:	jne    29ddf09 <wasm[0]::function[1013]::helper::array_indexed_publish+0x3549>
 29ddf92:	mov    0x70(%rsp),%rax
 29ddf97:	mov    0x70(%rsp),%r13
 29ddf9c:	jmp    29de01f <wasm[0]::function[1013]::helper::array_indexed_publish+0x365f>
 29ddfa1:	mov    %r11d,0x18(%rsp)
 29ddfa6:	mov    %edi,0x20(%rsp)
 29ddfaa:	mov    0x70(%rsp),%rax
 29ddfaf:	mov    %eax,(%rsp)
 29ddfb2:	mov    %esi,0x28(%rsp)
 29ddfb6:	mov    %edx,0x10(%rsp)
 29ddfba:	mov    0xc8(%rsp),%rcx
 29ddfc2:	mov    (%rcx),%rcx
 29ddfc5:	mov    0xa0(%rsp),%rax
 29ddfcd:	cmp    %rax,%rcx
 29ddfd0:	jae    29df8e1 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4f21>
 29ddfd6:	mov    0x0(%r13),%eax
 29ddfda:	mov    %eax,(%r12)
 29ddfde:	mov    (%rsp),%eax
 29ddfe1:	mov    %rax,0x70(%rsp)
 29ddfe6:	mov    0x28(%rsp),%esi
 29ddfea:	mov    0x10(%rsp),%edx
 29ddfee:	mov    0x18(%rsp),%r11d
 29ddff3:	mov    0x20(%rsp),%edi
 29ddff7:	add    $0x4,%r13
 29ddffe:	add    $0x4,%r12
 29de005:	add    $0x1,%r15d
 29de00c:	cmp    %rbx,%r13
 29de00f:	jne    29ddfa1 <wasm[0]::function[1013]::helper::array_indexed_publish+0x35e1>
 29de015:	mov    0x70(%rsp),%rax
 29de01a:	mov    0x70(%rsp),%r13
 29de01f:	test   %eax,%r13d
 29de022:	je     29dfd5b <wasm[0]::function[1013]::helper::array_indexed_publish+0x539b>
 29de028:	test   %esi,%esi
 29de02a:	je     29dfd5d <wasm[0]::function[1013]::helper::array_indexed_publish+0x539d>
 29de030:	mov    0x70(%rsp),%rcx
 29de035:	mov    0x70(%rsp),%r13
 29de03a:	test   %ecx,%r13d
 29de03d:	je     29dfd5f <wasm[0]::function[1013]::helper::array_indexed_publish+0x539f>
 29de043:	mov    0xc0(%rsp),%r14
 29de04b:	mov    0x28(%r14),%rdi
 29de04f:	mov    %r13d,%r9d
 29de052:	mov    %r9,%r8
 29de055:	add    0x20(%r14),%r8
 29de059:	xor    %r10,%r10
 29de05c:	cmp    %rdi,%r9
 29de05f:	cmova  %r10,%r8
 29de063:	mov    %esi,0x20(%r8)
 29de067:	test   %esi,%esi
 29de069:	je     29dfd61 <wasm[0]::function[1013]::helper::array_indexed_publish+0x53a1>
 29de06f:	test   %esi,%esi
 29de071:	je     29dfd63 <wasm[0]::function[1013]::helper::array_indexed_publish+0x53a3>
 29de077:	mov    0xc0(%rsp),%r14
 29de07f:	mov    0x28(%r14),%rdi
 29de083:	mov    0x20(%r14),%r8
 29de087:	mov    %esi,%eax
 29de089:	lea    0x10(%r8,%rax,1),%r10
 29de08e:	xor    %r9,%r9
 29de091:	cmp    %rdi,%rax
 29de094:	cmova  %r9,%r10
 29de098:	mov    (%r10),%r10d
 29de09b:	mov    0x68(%rsp),%rcx
 29de0a0:	cmp    %r10d,%ecx
 29de0a3:	jae    29dfd65 <wasm[0]::function[1013]::helper::array_indexed_publish+0x53a5>
 29de0a9:	mov    %r10d,%r11d
 29de0ac:	shl    $0x2,%r11
 29de0b0:	shr    $0x20,%r11
 29de0b4:	test   %r11,%r11
 29de0b7:	jne    29dfd67 <wasm[0]::function[1013]::helper::array_indexed_publish+0x53a7>
 29de0bd:	shl    $0x2,%r10d
 29de0c1:	add    $0x14,%r10d
 29de0c5:	jb     29dfd69 <wasm[0]::function[1013]::helper::array_indexed_publish+0x53a9>
 29de0cb:	mov    %rsi,%r11
 29de0ce:	add    %r10d,%r11d
 29de0d1:	jb     29dfd6b <wasm[0]::function[1013]::helper::array_indexed_publish+0x53ab>
 29de0d7:	mov    %r11d,%r11d
 29de0da:	add    %r11,%r8
 29de0dd:	cmp    %rdi,%r11
 29de0e0:	cmova  %r9,%r8
 29de0e4:	shl    $0x2,%ecx
 29de0e7:	lea    0x14(%rcx),%edi
 29de0ea:	sub    %edi,%r10d
 29de0ed:	sub    %r10,%r8
 29de0f0:	mov    (%r8),%ecx
 29de0f3:	test   %ecx,%ecx
 29de0f5:	jne    29de148 <wasm[0]::function[1013]::helper::array_indexed_publish+0x3788>
 29de0fb:	mov    0x70(%rsp),%rcx
 29de100:	mov    0x70(%rsp),%r13
 29de105:	test   %ecx,%r13d
 29de108:	je     29dfd6d <wasm[0]::function[1013]::helper::array_indexed_publish+0x53ad>
 29de10e:	test   %ecx,%r13d
 29de111:	je     29dfd6f <wasm[0]::function[1013]::helper::array_indexed_publish+0x53af>
 29de117:	mov    0xc0(%rsp),%r14
 29de11f:	mov    0x28(%r14),%r9
 29de123:	mov    0xb0(%rsp),%r12
 29de12b:	lea    0x1(%r12),%r8
 29de130:	mov    %r13d,%r11d
 29de133:	mov    %r11,%r10
 29de136:	add    0x20(%r14),%r10
 29de13a:	xor    %rbx,%rbx
 29de13d:	cmp    %r9,%r11
 29de140:	cmova  %rbx,%r10
 29de144:	mov    %r8,0x18(%r10)
 29de148:	test   %edx,%edx
 29de14a:	je     29dfd71 <wasm[0]::function[1013]::helper::array_indexed_publish+0x53b1>
 29de150:	mov    0xc0(%rsp),%r14
 29de158:	mov    0x28(%r14),%r8
 29de15c:	mov    0x20(%r14),%r10
 29de160:	lea    0x10(%r10,%rax,1),%r11
 29de165:	xor    %r9,%r9
 29de168:	cmp    %r8,%rax
 29de16b:	cmova  %r9,%r11
 29de16f:	mov    (%r11),%eax
 29de172:	mov    0x68(%rsp),%rcx
 29de177:	cmp    %eax,%ecx
 29de179:	jae    29dfd73 <wasm[0]::function[1013]::helper::array_indexed_publish+0x53b3>
 29de17f:	mov    %eax,%r11d
 29de182:	shl    $0x2,%r11
 29de186:	shr    $0x20,%r11
 29de18a:	test   %r11,%r11
 29de18d:	jne    29dfd75 <wasm[0]::function[1013]::helper::array_indexed_publish+0x53b5>
 29de193:	shl    $0x2,%eax
 29de196:	add    $0x14,%eax
 29de199:	jb     29dfd77 <wasm[0]::function[1013]::helper::array_indexed_publish+0x53b7>
 29de19f:	add    %eax,%esi
 29de1a1:	jb     29dfd79 <wasm[0]::function[1013]::helper::array_indexed_publish+0x53b9>
 29de1a7:	mov    %esi,%r11d
 29de1aa:	lea    (%r10,%r11,1),%rsi
 29de1ae:	cmp    %r8,%r11
 29de1b1:	cmova  %r9,%rsi
 29de1b5:	sub    %edi,%eax
 29de1b7:	sub    %rax,%rsi
 29de1ba:	mov    %edx,(%rsi)
 29de1bc:	mov    $0x1,%r10d
 29de1c2:	mov    0x70(%rsp),%r13
 29de1c7:	mov    %r13d,0x28(%rsp)
 29de1cc:	mov    %edx,(%rsp)
 29de1cf:	test   %r10d,%r10d
 29de1d2:	jne    29defbb <wasm[0]::function[1013]::helper::array_indexed_publish+0x45fb>
 29de1d8:	mov    0x70(%rsp),%rax
 29de1dd:	mov    0x70(%rsp),%r13
 29de1e2:	test   %eax,%r13d
 29de1e5:	je     29dfd7b <wasm[0]::function[1013]::helper::array_indexed_publish+0x53bb>
 29de1eb:	test   %eax,%r13d
 29de1ee:	je     29dfd7d <wasm[0]::function[1013]::helper::array_indexed_publish+0x53bd>
 29de1f4:	mov    0xc0(%rsp),%r14
 29de1fc:	mov    0x28(%r14),%rax
 29de200:	mov    0x20(%r14),%rdi
 29de204:	mov    %r13d,%r9d
 29de207:	lea    (%rdi,%r9,1),%rsi
 29de20b:	xor    %r8,%r8
 29de20e:	cmp    %rax,%r9
 29de211:	cmova  %r8,%rsi
 29de215:	mov    0x10(%rsi),%esi
 29de218:	test   %esi,%esi
 29de21a:	je     29dfd7f <wasm[0]::function[1013]::helper::array_indexed_publish+0x53bf>
 29de220:	test   %esi,%esi
 29de222:	je     29dfd81 <wasm[0]::function[1013]::helper::array_indexed_publish+0x53c1>
 29de228:	mov    %esi,%r9d
 29de22b:	lea    0x10(%rdi,%r9,1),%rdi
 29de230:	cmp    %rax,%r9
 29de233:	cmova  %r8,%rdi
 29de237:	mov    (%rdi),%edi
 29de239:	test   %edi,%edi
 29de23b:	je     29de24e <wasm[0]::function[1013]::helper::array_indexed_publish+0x388e>
 29de241:	mov    %rdi,0x80(%rsp)
 29de249:	jmp    29de6bd <wasm[0]::function[1013]::helper::array_indexed_publish+0x3cfd>
 29de24e:	mov    0x28(%rsp),%eax
 29de252:	test   %eax,%eax
 29de254:	je     29dfd83 <wasm[0]::function[1013]::helper::array_indexed_publish+0x53c3>
 29de25a:	test   %eax,%eax
 29de25c:	je     29dfd85 <wasm[0]::function[1013]::helper::array_indexed_publish+0x53c5>
 29de262:	mov    0xc0(%rsp),%r14
 29de26a:	mov    0x28(%r14),%rsi
 29de26e:	mov    %eax,%edi
 29de270:	mov    %rdi,%rcx
 29de273:	add    0x20(%r14),%rcx
 29de277:	xor    %r8,%r8
 29de27a:	cmp    %rsi,%rdi
 29de27d:	cmova  %r8,%rcx
 29de281:	mov    0x10(%rcx),%esi
 29de284:	mov    %esi,0x10(%rsp)
 29de288:	mov    0x60(%rsp),%rdi
 29de28d:	mov    0x20(%rdi),%rdi
 29de291:	mov    (%rdi),%eax
 29de293:	mov    %eax,%esi
 29de295:	lea    0x40(%rsi),%r8
 29de299:	mov    0x4(%rdi),%r9d
 29de29d:	cmp    %r9,%r8
 29de2a0:	ja     29df915 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4f55>
 29de2a6:	lea    0x40(%rax),%r9d
 29de2aa:	mov    %r9d,(%rdi)
 29de2ad:	mov    0xc0(%rsp),%r14
 29de2b5:	mov    0x20(%r14),%r10
 29de2b9:	lea    (%r10,%rsi,1),%rcx
 29de2bd:	movl   $0xa800000e,(%r10,%rsi,1)
 29de2c5:	mov    0x60(%rsp),%rdi
 29de2ca:	mov    0x28(%rdi),%r11
 29de2ce:	mov    0x1ac(%r11),%r11d
 29de2d5:	mov    %r11d,0x4(%r10,%rsi,1)
 29de2da:	mov    $0x40,%edx
 29de2df:	mov    %edx,0x8(%r10,%rsi,1)
 29de2e4:	mov    %eax,0x18(%rsp)
 29de2e8:	mov    $0x8,%edi
 29de2ed:	mov    %rdi,0x80(%rsp)
 29de2f5:	movl   $0x8,0x10(%rcx)
 29de2fc:	test   %eax,%eax
 29de2fe:	je     29dfd87 <wasm[0]::function[1013]::helper::array_indexed_publish+0x53c7>
 29de304:	mov    0xc0(%rsp),%r14
 29de30c:	mov    0x28(%r14),%rcx
 29de310:	mov    0x20(%r14),%r13
 29de314:	mov    %eax,%ebx
 29de316:	lea    0x10(%r13,%rbx,1),%rax
 29de31b:	xor    %rdx,%rdx
 29de31e:	cmp    %rcx,%rbx
 29de321:	cmova  %rdx,%rax
 29de325:	mov    (%rax),%eax
 29de327:	cmp    $0x8,%rax
 29de32b:	jb     29dfd89 <wasm[0]::function[1013]::helper::array_indexed_publish+0x53c9>
 29de331:	lea    0x14(%r13,%rbx,1),%r12
 29de336:	mov    %r12,%rax
 29de339:	add    $0x20,%rax
 29de33d:	jb     29dfd8b <wasm[0]::function[1013]::helper::array_indexed_publish+0x53cb>
 29de343:	add    %r13,%rcx
 29de346:	cmp    %rcx,%rax
 29de349:	ja     29dfd8d <wasm[0]::function[1013]::helper::array_indexed_publish+0x53cd>
 29de34f:	mov    0x10(%rsp),%ecx
 29de353:	mov    0x28(%rsp),%edx
 29de357:	mov    (%rsp),%esi
 29de35a:	mov    %ecx,(%rsp)
 29de35d:	mov    %edx,0x28(%rsp)
 29de361:	mov    %esi,0x10(%rsp)
 29de365:	mov    0xc8(%rsp),%rcx
 29de36d:	mov    (%rcx),%rax
 29de370:	mov    0xa0(%rsp),%rcx
 29de378:	cmp    %rcx,%rax
 29de37b:	jae    29df94d <wasm[0]::function[1013]::helper::array_indexed_publish+0x4f8d>
 29de381:	movl   $0x0,(%r12)
 29de389:	mov    (%rsp),%ecx
 29de38c:	mov    0x28(%rsp),%edx
 29de390:	mov    0x10(%rsp),%esi
 29de394:	lea    0x30(%r13,%rbx,1),%rdi
 29de399:	lea    0x4(%r12),%rax
 29de39e:	cmp    %rdi,%r12
 29de3a1:	je     29de3af <wasm[0]::function[1013]::helper::array_indexed_publish+0x39ef>
 29de3a7:	mov    %rax,%r12
 29de3aa:	jmp    29de35a <wasm[0]::function[1013]::helper::array_indexed_publish+0x399a>
 29de3af:	xor    %ebx,%ebx
 29de3b1:	test   %ecx,%ecx
 29de3b3:	je     29dfd8f <wasm[0]::function[1013]::helper::array_indexed_publish+0x53cf>
 29de3b9:	test   %ecx,%ecx
 29de3bb:	je     29dfd91 <wasm[0]::function[1013]::helper::array_indexed_publish+0x53d1>
 29de3c1:	mov    0xc0(%rsp),%r14
 29de3c9:	mov    0x28(%r14),%rdi
 29de3cd:	mov    0x20(%r14),%r8
 29de3d1:	mov    %ecx,%r9d
 29de3d4:	lea    0x10(%r8,%r9,1),%r8
 29de3d9:	xor    %r10,%r10
 29de3dc:	cmp    %rdi,%r9
 29de3df:	cmova  %r10,%r8
 29de3e3:	mov    (%r8),%eax
 29de3e6:	mov    %rax,0x98(%rsp)
 29de3ee:	mov    %ecx,0x10(%rsp)
 29de3f2:	mov    %edx,0x28(%rsp)
 29de3f6:	mov    %esi,(%rsp)
 29de3f9:	mov    0xc8(%rsp),%rcx
 29de401:	mov    (%rcx),%rcx
 29de404:	mov    0xa0(%rsp),%rax
 29de40c:	cmp    %rax,%rcx
 29de40f:	jae    29df981 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4fc1>
 29de415:	mov    0x98(%rsp),%rax
 29de41d:	jmp    29de42a <wasm[0]::function[1013]::helper::array_indexed_publish+0x3a6a>
 29de422:	mov    0x98(%rsp),%rax
 29de42a:	cmp    %eax,%ebx
 29de42c:	mov    %rax,0x98(%rsp)
 29de434:	jae    29de667 <wasm[0]::function[1013]::helper::array_indexed_publish+0x3ca7>
 29de43a:	mov    0x10(%rsp),%ecx
 29de43e:	test   %ecx,%ecx
 29de440:	je     29dfd93 <wasm[0]::function[1013]::helper::array_indexed_publish+0x53d3>
 29de446:	test   %ecx,%ecx
 29de448:	je     29dfd95 <wasm[0]::function[1013]::helper::array_indexed_publish+0x53d5>
 29de44e:	mov    0xc0(%rsp),%r14
 29de456:	mov    0x28(%r14),%rdx
 29de45a:	mov    0x20(%r14),%rsi
 29de45e:	mov    %ecx,%r9d
 29de461:	lea    0x10(%rsi,%r9,1),%r8
 29de466:	xor    %rdi,%rdi
 29de469:	cmp    %rdx,%r9
 29de46c:	cmova  %rdi,%r8
 29de470:	mov    (%r8),%r8d
 29de473:	cmp    %r8d,%ebx
 29de476:	jae    29dfd97 <wasm[0]::function[1013]::helper::array_indexed_publish+0x53d7>
 29de47c:	mov    %r8d,%r9d
 29de47f:	shl    $0x2,%r9
 29de483:	shr    $0x20,%r9
 29de487:	test   %r9,%r9
 29de48a:	jne    29dfd99 <wasm[0]::function[1013]::helper::array_indexed_publish+0x53d9>
 29de490:	shl    $0x2,%r8d
 29de494:	add    $0x14,%r8d
 29de498:	jb     29dfd9b <wasm[0]::function[1013]::helper::array_indexed_publish+0x53db>
 29de49e:	mov    %rcx,%r9
 29de4a1:	add    %r8d,%r9d
 29de4a4:	jb     29dfd9d <wasm[0]::function[1013]::helper::array_indexed_publish+0x53dd>
 29de4aa:	mov    %r9d,%r9d
 29de4ad:	add    %r9,%rsi
 29de4b0:	cmp    %rdx,%r9
 29de4b3:	cmova  %rdi,%rsi
 29de4b7:	mov    %rbx,%rdi
 29de4ba:	shl    $0x2,%edi
 29de4bd:	add    $0x14,%edi
 29de4c3:	sub    %edi,%r8d
 29de4c6:	sub    %r8,%rsi
 29de4c9:	mov    (%rsi),%edx
 29de4cb:	mov    0x28(%rsp),%esi
 29de4cf:	mov    (%rsp),%edi
 29de4d2:	mov    %edx,0x30(%rsp)
 29de4d6:	mov    %ecx,0x8(%rsp)
 29de4da:	mov    %esi,0x20(%rsp)
 29de4de:	mov    %edi,0x10(%rsp)
 29de4e2:	mov    0xc8(%rsp),%rcx
 29de4ea:	mov    (%rcx),%r11
 29de4ed:	mov    0xa0(%rsp),%rax
 29de4f5:	cmp    %rax,%r11
 29de4f8:	jae    29df9bd <wasm[0]::function[1013]::helper::array_indexed_publish+0x4ffd>
 29de4fe:	mov    0x30(%rsp),%eax
 29de502:	test   %eax,%eax
 29de504:	je     29de650 <wasm[0]::function[1013]::helper::array_indexed_publish+0x3c90>
 29de50a:	mov    0x30(%rsp),%ecx
 29de50e:	test   %ecx,%ecx
 29de510:	je     29dfd9f <wasm[0]::function[1013]::helper::array_indexed_publish+0x53df>
 29de516:	mov    0xc0(%rsp),%r14
 29de51e:	mov    0x28(%r14),%rsi
 29de522:	mov    0x20(%r14),%rdi
 29de526:	mov    %ecx,%edx
 29de528:	lea    (%rdi,%rdx,1),%r10
 29de52c:	xor    %r8,%r8
 29de52f:	cmp    %rsi,%rdx
 29de532:	cmova  %r8,%r10
 29de536:	mov    0x1c(%r10),%edx
 29de53a:	mov    0x10(%r10),%r13
 29de53e:	mov    0x18(%rsp),%r9d
 29de543:	test   %r9d,%r9d
 29de546:	je     29dfda1 <wasm[0]::function[1013]::helper::array_indexed_publish+0x53e1>
 29de54c:	test   %r9d,%r9d
 29de54f:	je     29dfda3 <wasm[0]::function[1013]::helper::array_indexed_publish+0x53e3>
 29de555:	mov    %r9d,%r12d
 29de558:	lea    0x10(%rdi,%r12,1),%r11
 29de55d:	cmp    %rsi,%r12
 29de560:	cmova  %r8,%r11
 29de564:	mov    (%r11),%r12d
 29de567:	mov    %r13,%r14
 29de56a:	shr    $0x10,%r14d
 29de56e:	xor    %r14d,%r13d
 29de571:	imul   $0x7feb352d,%r13d,%r13d
 29de578:	mov    %r13,%r14
 29de57b:	shr    $0xf,%r14d
 29de57f:	xor    %r14d,%r13d
 29de582:	imul   $0x846ca68b,%r13d,%r13d
 29de589:	mov    %r13,%r14
 29de58c:	shr    $0x10,%r14d
 29de590:	xor    %r14d,%r13d
 29de593:	and    $0x7,%r13d
 29de597:	cmp    %r12d,%r13d
 29de59a:	jae    29dfda5 <wasm[0]::function[1013]::helper::array_indexed_publish+0x53e5>
 29de5a0:	mov    %r12d,%r14d
 29de5a3:	shl    $0x2,%r14
 29de5a7:	shr    $0x20,%r14
 29de5ab:	test   %r14,%r14
 29de5ae:	jne    29dfda7 <wasm[0]::function[1013]::helper::array_indexed_publish+0x53e7>
 29de5b4:	shl    $0x2,%r12d
 29de5b8:	add    $0x14,%r12d
 29de5bc:	jb     29dfda9 <wasm[0]::function[1013]::helper::array_indexed_publish+0x53e9>
 29de5c2:	mov    %r9,%r14
 29de5c5:	add    %r12d,%r14d
 29de5c8:	jb     29dfdab <wasm[0]::function[1013]::helper::array_indexed_publish+0x53eb>
 29de5ce:	mov    %r14d,%r14d
 29de5d1:	lea    (%rdi,%r14,1),%r15
 29de5d5:	cmp    %rsi,%r14
 29de5d8:	cmova  %r8,%r15
 29de5dc:	mov    %r13,%rax
 29de5df:	shl    $0x2,%eax
 29de5e2:	lea    0x14(%rax),%r14d
 29de5e6:	sub    %r14d,%r12d
 29de5e9:	sub    %r12,%r15
 29de5ec:	mov    (%r15),%eax
 29de5ef:	mov    %eax,0x1c(%r10)
 29de5f3:	mov    (%r11),%r10d
 29de5f6:	cmp    %r10d,%r13d
 29de5f9:	jae    29dfdad <wasm[0]::function[1013]::helper::array_indexed_publish+0x53ed>
 29de5ff:	mov    %r10d,%r11d
 29de602:	shl    $0x2,%r11
 29de606:	shr    $0x20,%r11
 29de60a:	test   %r11,%r11
 29de60d:	jne    29dfdaf <wasm[0]::function[1013]::helper::array_indexed_publish+0x53ef>
 29de613:	shl    $0x2,%r10d
 29de617:	add    $0x14,%r10d
 29de61b:	jb     29dfdb1 <wasm[0]::function[1013]::helper::array_indexed_publish+0x53f1>
 29de621:	add    %r10d,%r9d
 29de624:	jb     29dfdb3 <wasm[0]::function[1013]::helper::array_indexed_publish+0x53f3>
 29de62a:	mov    %r9d,%r9d
 29de62d:	add    %r9,%rdi
 29de630:	cmp    %rsi,%r9
 29de633:	cmova  %r8,%rdi
 29de637:	sub    %r14d,%r10d
 29de63a:	sub    %r10,%rdi
 29de63d:	mov    %ecx,(%rdi)
 29de63f:	mov    0x8(%rsp),%ecx
 29de643:	mov    0x20(%rsp),%esi
 29de647:	mov    0x10(%rsp),%edi
 29de64b:	jmp    29de4d2 <wasm[0]::function[1013]::helper::array_indexed_publish+0x3b12>
 29de650:	mov    0x8(%rsp),%ecx
 29de654:	mov    0x20(%rsp),%edx
 29de658:	mov    0x10(%rsp),%esi
 29de65c:	add    $0x1,%ebx
 29de662:	jmp    29de3ee <wasm[0]::function[1013]::helper::array_indexed_publish+0x3a2e>
 29de667:	mov    0x28(%rsp),%r13d
 29de66c:	mov    %r13,%rax
 29de66f:	mov    %r13,0x70(%rsp)
 29de674:	test   %eax,%r13d
 29de677:	je     29dfdb5 <wasm[0]::function[1013]::helper::array_indexed_publish+0x53f5>
 29de67d:	mov    0x18(%rsp),%esi
 29de681:	test   %esi,%esi
 29de683:	je     29dfdb7 <wasm[0]::function[1013]::helper::array_indexed_publish+0x53f7>
 29de689:	mov    0x70(%rsp),%rax
 29de68e:	test   %eax,%r13d
 29de691:	je     29dfdb9 <wasm[0]::function[1013]::helper::array_indexed_publish+0x53f9>
 29de697:	mov    0xc0(%rsp),%r14
 29de69f:	mov    0x28(%r14),%rax
 29de6a3:	mov    %r13d,%edi
 29de6a6:	mov    %rdi,%rdx
 29de6a9:	add    0x20(%r14),%rdx
 29de6ad:	xor    %r8,%r8
 29de6b0:	cmp    %rax,%rdi
 29de6b3:	cmova  %r8,%rdx
 29de6b7:	mov    %esi,0x10(%rdx)
 29de6ba:	mov    (%rsp),%edx
 29de6bd:	mov    %edx,(%rsp)
 29de6c0:	test   %esi,%esi
 29de6c2:	je     29dfdbb <wasm[0]::function[1013]::helper::array_indexed_publish+0x53fb>
 29de6c8:	test   %esi,%esi
 29de6ca:	je     29dfdbd <wasm[0]::function[1013]::helper::array_indexed_publish+0x53fd>
 29de6d0:	mov    0xc0(%rsp),%r14
 29de6d8:	mov    0x28(%r14),%rax
 29de6dc:	mov    0x20(%r14),%rdx
 29de6e0:	mov    %esi,%r9d
 29de6e3:	lea    0x10(%rdx,%r9,1),%r8
 29de6e8:	xor    %rdi,%rdi
 29de6eb:	cmp    %rax,%r9
 29de6ee:	cmova  %rdi,%r8
 29de6f2:	mov    (%r8),%r8d
 29de6f5:	mov    $0x10,%ecx
 29de6fa:	mov    %rcx,0x98(%rsp)
 29de702:	mov    0x68(%rsp),%rcx
 29de707:	mov    %rcx,%r9
 29de70a:	shr    $0x10,%r9d
 29de70e:	xor    %r9d,%ecx
 29de711:	imul   $0x7feb352d,%ecx,%r9d
 29de718:	mov    %r9,%r10
 29de71b:	shr    $0xf,%r10d
 29de71f:	xor    %r10d,%r9d
 29de722:	imul   $0x846ca68b,%r9d,%r14d
 29de729:	mov    %r14,%r9
 29de72c:	shr    $0x10,%r9d
 29de730:	xor    %r9d,%r14d
 29de733:	mov    0x80(%rsp),%r10
 29de73b:	mov    %r10,%r9
 29de73e:	sub    $0x1,%r9d
 29de742:	mov    %r14,%rbx
 29de745:	and    %r9d,%ebx
 29de748:	mov    %r14,0x78(%rsp)
 29de74d:	cmp    %r8d,%ebx
 29de750:	jae    29dfdbf <wasm[0]::function[1013]::helper::array_indexed_publish+0x53ff>
 29de756:	mov    %r8d,%r9d
 29de759:	shl    $0x2,%r9
 29de75d:	mov    $0x20,%r13d
 29de763:	mov    %r13,0x90(%rsp)
 29de76b:	shr    $0x20,%r9
 29de76f:	test   %r9,%r9
 29de772:	jne    29dfdc1 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5401>
 29de778:	shl    $0x2,%r8d
 29de77c:	add    $0x14,%r8d
 29de780:	jb     29dfdc3 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5403>
 29de786:	mov    %rsi,%r9
 29de789:	add    %r8d,%r9d
 29de78c:	jb     29dfdc5 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5405>
 29de792:	mov    %r9d,%r9d
 29de795:	add    %r9,%rdx
 29de798:	cmp    %rax,%r9
 29de79b:	cmova  %rdi,%rdx
 29de79f:	mov    %rbx,%rdi
 29de7a2:	shl    $0x2,%edi
 29de7a5:	add    $0x14,%edi
 29de7ab:	sub    %edi,%r8d
 29de7ae:	sub    %r8,%rdx
 29de7b1:	mov    (%rdx),%edi
 29de7b3:	mov    %edi,0x8(%rsp)
 29de7b7:	mov    0x70(%rsp),%r13
 29de7bc:	mov    %r13d,0x18(%rsp)
 29de7c1:	mov    %esi,0x28(%rsp)
 29de7c5:	mov    0xc8(%rsp),%rcx
 29de7cd:	mov    (%rcx),%r9
 29de7d0:	mov    0xa0(%rsp),%rax
 29de7d8:	cmp    %rax,%r9
 29de7db:	jae    29df9f1 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5031>
 29de7e1:	mov    0x8(%rsp),%eax
 29de7e5:	test   %eax,%eax
 29de7e7:	je     29de8a9 <wasm[0]::function[1013]::helper::array_indexed_publish+0x3ee9>
 29de7ed:	mov    0x8(%rsp),%ecx
 29de7f1:	test   %ecx,%ecx
 29de7f3:	je     29dfdc7 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5407>
 29de7f9:	mov    0xc0(%rsp),%r14
 29de801:	mov    0x28(%r14),%rax
 29de805:	mov    %ecx,%edx
 29de807:	mov    %rdx,%rcx
 29de80a:	add    0x20(%r14),%rcx
 29de80e:	xor    %rsi,%rsi
 29de811:	cmp    %rax,%rdx
 29de814:	cmova  %rsi,%rcx
 29de818:	mov    0x10(%rcx),%rax
 29de81c:	mov    0x68(%rsp),%rcx
 29de821:	cmp    %rcx,%rax
 29de824:	je     29de86b <wasm[0]::function[1013]::helper::array_indexed_publish+0x3eab>
 29de82a:	mov    0x8(%rsp),%ecx
 29de82e:	test   %ecx,%ecx
 29de830:	je     29dfdc9 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5409>
 29de836:	mov    0xc0(%rsp),%r14
 29de83e:	mov    0x28(%r14),%rax
 29de842:	mov    %ecx,%edx
 29de844:	mov    %rdx,%rcx
 29de847:	add    0x20(%r14),%rcx
 29de84b:	xor    %rsi,%rsi
 29de84e:	cmp    %rax,%rdx
 29de851:	cmova  %rsi,%rcx
 29de855:	mov    0x1c(%rcx),%edi
 29de858:	mov    0x18(%rsp),%r13d
 29de85d:	mov    %r13,0x70(%rsp)
 29de862:	mov    0x28(%rsp),%esi
 29de866:	jmp    29de7b3 <wasm[0]::function[1013]::helper::array_indexed_publish+0x3df3>
 29de86b:	mov    (%rsp),%eax
 29de86e:	test   %eax,%eax
 29de870:	je     29dfdcb <wasm[0]::function[1013]::helper::array_indexed_publish+0x540b>
 29de876:	mov    0x8(%rsp),%edx
 29de87a:	test   %edx,%edx
 29de87c:	je     29dfdcd <wasm[0]::function[1013]::helper::array_indexed_publish+0x540d>
 29de882:	mov    0xc0(%rsp),%r14
 29de88a:	mov    0x28(%r14),%rcx
 29de88e:	mov    %edx,%esi
 29de890:	mov    %rsi,%rdx
 29de893:	add    0x20(%r14),%rdx
 29de897:	xor    %rdi,%rdi
 29de89a:	cmp    %rcx,%rsi
 29de89d:	cmova  %rdi,%rdx
 29de8a1:	mov    %eax,0x18(%rdx)
 29de8a4:	jmp    29defbb <wasm[0]::function[1013]::helper::array_indexed_publish+0x45fb>
 29de8a9:	mov    0x18(%rsp),%edx
 29de8ad:	test   %edx,%edx
 29de8af:	je     29dfdcf <wasm[0]::function[1013]::helper::array_indexed_publish+0x540f>
 29de8b5:	test   %edx,%edx
 29de8b7:	je     29dfdd1 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5411>
 29de8bd:	mov    0xc0(%rsp),%r14
 29de8c5:	mov    0x28(%r14),%rax
 29de8c9:	mov    0x20(%r14),%rcx
 29de8cd:	mov    %edx,%esi
 29de8cf:	add    %rsi,%rcx
 29de8d2:	xor    %rdi,%rdi
 29de8d5:	cmp    %rax,%rsi
 29de8d8:	cmova  %rdi,%rcx
 29de8dc:	mov    0x18(%rcx),%rcx
 29de8e0:	mov    0x28(%rsp),%eax
 29de8e4:	mov    (%rsp),%esi
 29de8e7:	lea    0x1(%rcx),%rdi
 29de8eb:	mov    %rcx,0x88(%rsp)
 29de8f3:	shl    $0x2,%rdi
 29de8f7:	mov    0x80(%rsp),%rcx
 29de8ff:	mov    %ecx,%r8d
 29de902:	imul   $0x3,%r8,%r8
 29de906:	cmp    %r8,%rdi
 29de909:	ja     29de917 <wasm[0]::function[1013]::helper::array_indexed_publish+0x3f57>
 29de90f:	mov    %rbx,%r12
 29de912:	jmp    29dede0 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4420>
 29de917:	cmp    $0x80000000,%ecx
 29de91d:	jae    29dfdd3 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5413>
 29de923:	mov    0x18(%rsp),%eax
 29de927:	test   %eax,%eax
 29de929:	je     29dfdd5 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5415>
 29de92f:	test   %eax,%eax
 29de931:	je     29dfdd7 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5417>
 29de937:	mov    0xc0(%rsp),%r14
 29de93f:	mov    0x28(%r14),%rdx
 29de943:	mov    %eax,%esi
 29de945:	mov    %rsi,%rax
 29de948:	add    0x20(%r14),%rax
 29de94c:	xor    %rdi,%rdi
 29de94f:	cmp    %rdx,%rsi
 29de952:	cmova  %rdi,%rax
 29de956:	mov    0x10(%rax),%eax
 29de959:	mov    %eax,0x28(%rsp)
 29de95d:	mov    %rcx,%r14
 29de960:	shl    $1,%r14d
 29de963:	mov    %r14,%r12
 29de966:	shl    $0x2,%r12
 29de96a:	mov    %r12,%rax
 29de96d:	shr    $0x20,%rax
 29de971:	test   %rax,%rax
 29de974:	jne    29dfdd9 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5419>
 29de97a:	shl    $0x3,%ecx
 29de97d:	add    $0x14,%ecx
 29de980:	jb     29dfddb <wasm[0]::function[1013]::helper::array_indexed_publish+0x541b>
 29de986:	mov    0x60(%rsp),%rdi
 29de98b:	mov    0x20(%rdi),%rdi
 29de98f:	mov    (%rdi),%eax
 29de991:	mov    %eax,%edx
 29de993:	mov    %ecx,%esi
 29de995:	add    $0xf,%rsi
 29de99c:	mov    %rsi,%r8
 29de99f:	and    $0xfffffffffffffff0,%r8
 29de9a3:	add    %rdx,%r8
 29de9a6:	mov    0x4(%rdi),%r9d
 29de9aa:	cmp    %r9,%r8
 29de9ad:	ja     29dfa25 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5065>
 29de9b3:	add    $0xf,%ecx
 29de9b9:	and    $0xfffffff0,%ecx
 29de9bc:	add    %eax,%ecx
 29de9be:	mov    %ecx,(%rdi)
 29de9c0:	mov    0xc0(%rsp),%rcx
 29de9c8:	mov    0x20(%rcx),%rcx
 29de9cc:	lea    (%rcx,%rdx,1),%rdi
 29de9d0:	movl   $0xa800000e,(%rcx,%rdx,1)
 29de9d7:	mov    0x60(%rsp),%r8
 29de9dc:	mov    0x28(%r8),%r8
 29de9e0:	mov    0x1ac(%r8),%r8d
 29de9e7:	mov    %r8d,0x4(%rcx,%rdx,1)
 29de9ec:	and    $0xfffffffffffffff0,%rsi
 29de9f0:	mov    %esi,0x8(%rcx,%rdx,1)
 29de9f4:	mov    %eax,0x8(%rsp)
 29de9f8:	mov    %r14d,0x10(%rdi)
 29de9fc:	test   %eax,%eax
 29de9fe:	je     29dfddd <wasm[0]::function[1013]::helper::array_indexed_publish+0x541d>
 29dea04:	mov    0xc0(%rsp),%r9
 29dea0c:	mov    0x28(%r9),%rdi
 29dea10:	mov    0xc0(%rsp),%r11
 29dea18:	mov    0x20(%r11),%r8
 29dea1c:	mov    %eax,%r9d
 29dea1f:	lea    (%r8,%r9,1),%rsi
 29dea23:	lea    0x10(%r8,%r9,1),%rax
 29dea28:	xor    %r10,%r10
 29dea2b:	cmp    %rdi,%r9
 29dea2e:	cmova  %r10,%rax
 29dea32:	mov    (%rax),%r10d
 29dea35:	cmp    %r10,%r14
 29dea38:	ja     29dfddf <wasm[0]::function[1013]::helper::array_indexed_publish+0x541f>
 29dea3e:	lea    0x14(%r8,%r9,1),%rbx
 29dea43:	mov    %rbx,%r9
 29dea46:	add    %r12,%r9
 29dea49:	jb     29dfde1 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5421>
 29dea4f:	add    %r8,%rdi
 29dea52:	cmp    %rdi,%r9
 29dea55:	ja     29dfde3 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5423>
 29dea5b:	mov    0x28(%rsp),%eax
 29dea5f:	mov    0x18(%rsp),%ecx
 29dea63:	mov    (%rsp),%edx
 29dea66:	lea    0x14(%rsi,%r14,4),%r12
 29dea6b:	test   %r14,%r14
 29dea6e:	je     29deabc <wasm[0]::function[1013]::helper::array_indexed_publish+0x40fc>
 29dea74:	mov    %eax,(%rsp)
 29dea77:	mov    %ecx,0x18(%rsp)
 29dea7b:	mov    %edx,0x28(%rsp)
 29dea7f:	mov    0xc8(%rsp),%rcx
 29dea87:	mov    (%rcx),%rax
 29dea8a:	mov    0xa0(%rsp),%rcx
 29dea92:	cmp    %rcx,%rax
 29dea95:	jae    29dfa59 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5099>
 29dea9b:	movl   $0x0,(%rbx)
 29deaa1:	mov    (%rsp),%eax
 29deaa4:	mov    0x18(%rsp),%ecx
 29deaa8:	mov    0x28(%rsp),%edx
 29deaac:	add    $0x4,%rbx
 29deab3:	cmp    %r12,%rbx
 29deab6:	jne    29dea74 <wasm[0]::function[1013]::helper::array_indexed_publish+0x40b4>
 29deabc:	xor    %ebx,%ebx
 29deabe:	test   %eax,%eax
 29deac0:	je     29dfde5 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5425>
 29deac6:	test   %eax,%eax
 29deac8:	je     29dfde7 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5427>
 29deace:	mov    0xc0(%rsp),%rsi
 29dead6:	mov    0x28(%rsi),%rsi
 29deada:	mov    0xc0(%rsp),%rdi
 29deae2:	mov    0x20(%rdi),%rdi
 29deae6:	mov    %eax,%r8d
 29deae9:	lea    0x10(%rdi,%r8,1),%rdi
 29deaee:	xor    %r9,%r9
 29deaf1:	cmp    %rsi,%r8
 29deaf4:	cmova  %r9,%rdi
 29deaf8:	mov    (%rdi),%esi
 29deafa:	mov    %rsi,0x80(%rsp)
 29deb02:	mov    %eax,0x28(%rsp)
 29deb06:	mov    %ecx,0x18(%rsp)
 29deb0a:	mov    %edx,(%rsp)
 29deb0d:	mov    0xc8(%rsp),%rcx
 29deb15:	mov    (%rcx),%rax
 29deb18:	mov    0xa0(%rsp),%rcx
 29deb20:	cmp    %rcx,%rax
 29deb23:	jae    29dfa8d <wasm[0]::function[1013]::helper::array_indexed_publish+0x50cd>
 29deb29:	mov    0x80(%rsp),%rax
 29deb31:	jmp    29deb3e <wasm[0]::function[1013]::helper::array_indexed_publish+0x417e>
 29deb36:	mov    0x80(%rsp),%rax
 29deb3e:	cmp    %eax,%ebx
 29deb40:	mov    %rax,0x80(%rsp)
 29deb48:	jae    29ded87 <wasm[0]::function[1013]::helper::array_indexed_publish+0x43c7>
 29deb4e:	mov    0x28(%rsp),%eax
 29deb52:	test   %eax,%eax
 29deb54:	je     29dfde9 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5429>
 29deb5a:	test   %eax,%eax
 29deb5c:	je     29dfdeb <wasm[0]::function[1013]::helper::array_indexed_publish+0x542b>
 29deb62:	mov    0xc0(%rsp),%rcx
 29deb6a:	mov    0x28(%rcx),%rcx
 29deb6e:	mov    0xc0(%rsp),%rdx
 29deb76:	mov    0x20(%rdx),%rdx
 29deb7a:	mov    %eax,%r8d
 29deb7d:	lea    0x10(%rdx,%r8,1),%rdi
 29deb82:	xor    %rsi,%rsi
 29deb85:	cmp    %rcx,%r8
 29deb88:	cmova  %rsi,%rdi
 29deb8c:	mov    (%rdi),%edi
 29deb8e:	cmp    %edi,%ebx
 29deb90:	jae    29dfded <wasm[0]::function[1013]::helper::array_indexed_publish+0x542d>
 29deb96:	mov    %edi,%r8d
 29deb99:	shl    $0x2,%r8
 29deb9d:	shr    $0x20,%r8
 29deba1:	test   %r8,%r8
 29deba4:	jne    29dfdef <wasm[0]::function[1013]::helper::array_indexed_publish+0x542f>
 29debaa:	shl    $0x2,%edi
 29debad:	add    $0x14,%edi
 29debb0:	jb     29dfdf1 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5431>
 29debb6:	mov    %rax,%r8
 29debb9:	add    %edi,%r8d
 29debbc:	jb     29dfdf3 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5433>
 29debc2:	mov    %r8d,%r8d
 29debc5:	add    %r8,%rdx
 29debc8:	cmp    %rcx,%r8
 29debcb:	cmova  %rsi,%rdx
 29debcf:	mov    %rbx,%rcx
 29debd2:	shl    $0x2,%ecx
 29debd5:	add    $0x14,%ecx
 29debdb:	sub    %ecx,%edi
 29debdd:	sub    %rdi,%rdx
 29debe0:	mov    (%rdx),%ecx
 29debe2:	mov    0x18(%rsp),%edx
 29debe6:	mov    (%rsp),%esi
 29debe9:	mov    %ecx,0x30(%rsp)
 29debed:	mov    %eax,0x10(%rsp)
 29debf1:	mov    %edx,0x20(%rsp)
 29debf5:	mov    %esi,0x28(%rsp)
 29debf9:	mov    0xc8(%rsp),%rcx
 29dec01:	mov    (%rcx),%rax
 29dec04:	mov    0xa0(%rsp),%rcx
 29dec0c:	cmp    %rcx,%rax
 29dec0f:	jae    29dfac9 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5109>
 29dec15:	mov    0x30(%rsp),%edi
 29dec19:	test   %edi,%edi
 29dec1b:	je     29ded70 <wasm[0]::function[1013]::helper::array_indexed_publish+0x43b0>
 29dec21:	mov    0x30(%rsp),%r9d
 29dec26:	test   %r9d,%r9d
 29dec29:	je     29dfdf5 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5435>
 29dec2f:	mov    0xc0(%rsp),%rax
 29dec37:	mov    0x28(%rax),%r11
 29dec3b:	mov    0x20(%rax),%rdx
 29dec3f:	mov    %r9d,%eax
 29dec42:	lea    (%rdx,%rax,1),%r8
 29dec46:	xor    %rsi,%rsi
 29dec49:	cmp    %r11,%rax
 29dec4c:	cmova  %rsi,%r8
 29dec50:	mov    0x1c(%r8),%ecx
 29dec54:	mov    0x10(%r8),%r13
 29dec58:	mov    0x8(%rsp),%eax
 29dec5c:	test   %eax,%eax
 29dec5e:	je     29dfdf7 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5437>
 29dec64:	test   %eax,%eax
 29dec66:	je     29dfdf9 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5439>
 29dec6c:	mov    %eax,%r10d
 29dec6f:	lea    0x10(%rdx,%r10,1),%rdi
 29dec74:	cmp    %r11,%r10
 29dec77:	cmova  %rsi,%rdi
 29dec7b:	mov    (%rdi),%r10d
 29dec7e:	mov    %r13,%r12
 29dec81:	shr    $0x10,%r12d
 29dec85:	xor    %r12d,%r13d
 29dec88:	imul   $0x7feb352d,%r13d,%r15d
 29dec8f:	mov    %r15,%r12
 29dec92:	shr    $0xf,%r12d
 29dec96:	xor    %r12d,%r15d
 29dec99:	imul   $0x846ca68b,%r15d,%r15d
 29deca0:	mov    %r15,%r12
 29deca3:	shr    $0x10,%r12d
 29deca7:	xor    %r12d,%r15d
 29decaa:	mov    %r14,%r12
 29decad:	sub    $0x1,%r12d
 29decb1:	and    %r12d,%r15d
 29decb4:	cmp    %r10d,%r15d
 29decb7:	jae    29dfdfb <wasm[0]::function[1013]::helper::array_indexed_publish+0x543b>
 29decbd:	mov    %r10d,%r12d
 29decc0:	shl    $0x2,%r12
 29decc4:	shr    $0x20,%r12
 29decc8:	test   %r12,%r12
 29deccb:	jne    29dfdfd <wasm[0]::function[1013]::helper::array_indexed_publish+0x543d>
 29decd1:	shl    $0x2,%r10d
 29decd5:	add    $0x14,%r10d
 29decd9:	jb     29dfdff <wasm[0]::function[1013]::helper::array_indexed_publish+0x543f>
 29decdf:	mov    %rax,%r12
 29dece2:	add    %r10d,%r12d
 29dece5:	jb     29dfe01 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5441>
 29deceb:	mov    %r12d,%r13d
 29decee:	lea    (%rdx,%r13,1),%r12
 29decf2:	cmp    %r11,%r13
 29decf5:	cmova  %rsi,%r12
 29decf9:	mov    %r15,%r13
 29decfc:	shl    $0x2,%r13d
 29ded00:	add    $0x14,%r13d
 29ded07:	sub    %r13d,%r10d
 29ded0a:	sub    %r10,%r12
 29ded0d:	mov    (%r12),%r10d
 29ded11:	mov    %r10d,0x1c(%r8)
 29ded15:	mov    (%rdi),%edi
 29ded17:	cmp    %edi,%r15d
 29ded1a:	jae    29dfe03 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5443>
 29ded20:	mov    %edi,%r8d
 29ded23:	shl    $0x2,%r8
 29ded27:	shr    $0x20,%r8
 29ded2b:	test   %r8,%r8
 29ded2e:	jne    29dfe05 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5445>
 29ded34:	shl    $0x2,%edi
 29ded37:	add    $0x14,%edi
 29ded3a:	jb     29dfe07 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5447>
 29ded40:	add    %edi,%eax
 29ded42:	jb     29dfe09 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5449>
 29ded48:	mov    %eax,%r8d
 29ded4b:	lea    (%rdx,%r8,1),%rax
 29ded4f:	cmp    %r11,%r8
 29ded52:	cmova  %rsi,%rax
 29ded56:	sub    %r13d,%edi
 29ded59:	sub    %rdi,%rax
 29ded5c:	mov    %r9d,(%rax)
 29ded5f:	mov    0x10(%rsp),%eax
 29ded63:	mov    0x20(%rsp),%edx
 29ded67:	mov    0x28(%rsp),%esi
 29ded6b:	jmp    29debe9 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4229>
 29ded70:	mov    0x10(%rsp),%eax
 29ded74:	mov    0x20(%rsp),%ecx
 29ded78:	mov    0x28(%rsp),%edx
 29ded7c:	add    $0x1,%ebx
 29ded82:	jmp    29deb02 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4142>
 29ded87:	mov    0x18(%rsp),%edx
 29ded8b:	test   %edx,%edx
 29ded8d:	je     29dfe0b <wasm[0]::function[1013]::helper::array_indexed_publish+0x544b>
 29ded93:	mov    0x8(%rsp),%eax
 29ded97:	test   %eax,%eax
 29ded99:	je     29dfe0d <wasm[0]::function[1013]::helper::array_indexed_publish+0x544d>
 29ded9f:	test   %edx,%edx
 29deda1:	je     29dfe0f <wasm[0]::function[1013]::helper::array_indexed_publish+0x544f>
 29deda7:	mov    0xc0(%rsp),%rcx
 29dedaf:	mov    0x28(%rcx),%rcx
 29dedb3:	mov    %edx,%edi
 29dedb5:	mov    0xc0(%rsp),%r8
 29dedbd:	mov    %rdi,%rsi
 29dedc0:	add    0x20(%r8),%rsi
 29dedc4:	xor    %r8,%r8
 29dedc7:	cmp    %rcx,%rdi
 29dedca:	cmova  %r8,%rsi
 29dedce:	mov    %eax,0x10(%rsi)
 29dedd1:	mov    (%rsp),%esi
 29dedd4:	sub    $0x1,%r14d
 29dedd8:	mov    0x78(%rsp),%r12
 29deddd:	and    %r14d,%r12d
 29dede0:	mov    %eax,0x8(%rsp)
 29dede4:	mov    %esi,0x18(%rsp)
 29dede8:	mov    %edx,(%rsp)
 29dedeb:	test   %eax,%eax
 29deded:	je     29dfe11 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5451>
 29dedf3:	test   %eax,%eax
 29dedf5:	je     29dfe13 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5453>
 29dedfb:	mov    0xc0(%rsp),%r14
 29dee03:	mov    0x28(%r14),%rcx
 29dee07:	mov    0x20(%r14),%rdx
 29dee0b:	mov    %eax,%r9d
 29dee0e:	lea    0x10(%rdx,%r9,1),%r8
 29dee13:	xor    %rdi,%rdi
 29dee16:	cmp    %rcx,%r9
 29dee19:	cmova  %rdi,%r8
 29dee1d:	mov    (%r8),%r8d
 29dee20:	cmp    %r8d,%r12d
 29dee23:	jae    29dfe15 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5455>
 29dee29:	mov    %r8d,%r9d
 29dee2c:	shl    $0x2,%r9
 29dee30:	shr    $0x20,%r9
 29dee34:	test   %r9,%r9
 29dee37:	jne    29dfe17 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5457>
 29dee3d:	shl    $0x2,%r8d
 29dee41:	add    $0x14,%r8d
 29dee45:	jb     29dfe19 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5459>
 29dee4b:	add    %r8d,%eax
 29dee4e:	jb     29dfe1b <wasm[0]::function[1013]::helper::array_indexed_publish+0x545b>
 29dee54:	mov    %eax,%r9d
 29dee57:	lea    (%rdx,%r9,1),%rax
 29dee5b:	cmp    %rcx,%r9
 29dee5e:	cmova  %rdi,%rax
 29dee62:	mov    %r12,%rbx
 29dee65:	shl    $0x2,%ebx
 29dee68:	lea    0x14(%rbx),%ecx
 29dee6b:	sub    %ecx,%r8d
 29dee6e:	sub    %r8,%rax
 29dee71:	mov    (%rax),%eax
 29dee73:	mov    %eax,0x10(%rsp)
 29dee77:	test   %esi,%esi
 29dee79:	je     29dfe1d <wasm[0]::function[1013]::helper::array_indexed_publish+0x545d>
 29dee7f:	mov    0x60(%rsp),%rdi
 29dee84:	mov    0x20(%rdi),%rcx
 29dee88:	mov    (%rcx),%eax
 29dee8a:	mov    %eax,%edx
 29dee8c:	lea    0x20(%rdx),%rsi
 29dee90:	mov    0x4(%rcx),%edi
 29dee93:	cmp    %rdi,%rsi
 29dee96:	ja     29dfafd <wasm[0]::function[1013]::helper::array_indexed_publish+0x513d>
 29dee9c:	lea    0x20(%rax),%esi
 29dee9f:	mov    %esi,(%rcx)
 29deea1:	mov    0xc0(%rsp),%r14
 29deea9:	mov    0x20(%r14),%rsi
 29deead:	lea    (%rsi,%rdx,1),%rcx
 29deeb1:	movl   $0xb0000062,(%rsi,%rdx,1)
 29deeb8:	mov    0x60(%rsp),%rdi
 29deebd:	mov    0x28(%rdi),%rdi
 29deec1:	mov    0x1a8(%rdi),%edi
 29deec7:	mov    %edi,0x4(%rsi,%rdx,1)
 29deecb:	mov    0x90(%rsp),%r13
 29deed3:	mov    %r13d,0x8(%rsi,%rdx,1)
 29deed8:	mov    0x68(%rsp),%rdx
 29deedd:	mov    0x68(%rsp),%rdx
 29deee2:	mov    %rdx,0x10(%rcx)
 29deee6:	mov    0x18(%rsp),%r8d
 29deeeb:	mov    %r8d,0x18(%rcx)
 29deeef:	mov    0x10(%rsp),%r9d
 29deef4:	mov    %r9d,0x1c(%rcx)
 29deef8:	mov    0x8(%rsp),%edi
 29deefc:	test   %edi,%edi
 29deefe:	je     29dfe1f <wasm[0]::function[1013]::helper::array_indexed_publish+0x545f>
 29def04:	test   %eax,%eax
 29def06:	je     29dfe21 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5461>
 29def0c:	test   %edi,%edi
 29def0e:	je     29dfe23 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5463>
 29def14:	mov    0xc0(%rsp),%r14
 29def1c:	mov    0x28(%r14),%rcx
 29def20:	mov    0x20(%r14),%rdx
 29def24:	mov    %edi,%r9d
 29def27:	lea    0x10(%rdx,%r9,1),%r8
 29def2c:	xor    %rsi,%rsi
 29def2f:	cmp    %rcx,%r9
 29def32:	cmova  %rsi,%r8
 29def36:	mov    (%r8),%r8d
 29def39:	cmp    %r8d,%r12d
 29def3c:	jae    29dfe25 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5465>
 29def42:	mov    %r8d,%r9d
 29def45:	shl    $0x2,%r9
 29def49:	shr    $0x20,%r9
 29def4d:	test   %r9,%r9
 29def50:	jne    29dfe27 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5467>
 29def56:	shl    $0x2,%r8d
 29def5a:	add    $0x14,%r8d
 29def5e:	jb     29dfe29 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5469>
 29def64:	add    %r8d,%edi
 29def67:	jb     29dfe2b <wasm[0]::function[1013]::helper::array_indexed_publish+0x546b>
 29def6d:	mov    %edi,%r9d
 29def70:	lea    (%rdx,%r9,1),%rdi
 29def74:	cmp    %rcx,%r9
 29def77:	cmova  %rsi,%rdi
 29def7b:	lea    0x14(%rbx),%r9d
 29def7f:	sub    %r9d,%r8d
 29def82:	sub    %r8,%rdi
 29def85:	mov    %eax,(%rdi)
 29def87:	mov    (%rsp),%eax
 29def8a:	test   %eax,%eax
 29def8c:	je     29dfe2d <wasm[0]::function[1013]::helper::array_indexed_publish+0x546d>
 29def92:	test   %eax,%eax
 29def94:	je     29dfe2f <wasm[0]::function[1013]::helper::array_indexed_publish+0x546f>
 29def9a:	mov    0x88(%rsp),%rdi
 29defa2:	add    $0x1,%rdi
 29defa9:	mov    %eax,%r8d
 29defac:	lea    (%rdx,%r8,1),%rax
 29defb0:	cmp    %rcx,%r8
 29defb3:	cmova  %rsi,%rax
 29defb7:	mov    %rdi,0x18(%rax)
 29defbb:	mov    0xd0(%rsp),%rbx
 29defc3:	mov    0xd8(%rsp),%r12
 29defcb:	mov    0xe0(%rsp),%r13
 29defd3:	mov    0xe8(%rsp),%r14
 29defdb:	mov    0xf0(%rsp),%r15
 29defe3:	add    $0x100,%rsp
 29defea:	mov    %rbp,%rsp
 29defed:	pop    %rbp
 29defee:	ret
 29defef:	mov    0x60(%rsp),%rdi
 29deff4:	call   3018b79 <wasmtime_builtin_new_epoch>
 29deff9:	mov    %rax,0xa0(%rsp)
 29df001:	mov    0x68(%rsp),%rcx
 29df006:	jmp    29daa5a <wasm[0]::function[1013]::helper::array_indexed_publish+0x9a>
 29df00b:	mov    0xc0(%rsp),%rsi
 29df013:	mov    0x8(%rsi),%rcx
 29df017:	mov    %rcx,0xa0(%rsp)
 29df01f:	cmp    %rcx,%rax
 29df022:	jb     29dae46 <wasm[0]::function[1013]::helper::array_indexed_publish+0x486>
 29df028:	mov    0x60(%rsp),%rdi
 29df02d:	call   3018b79 <wasmtime_builtin_new_epoch>
 29df032:	mov    %rax,0xa0(%rsp)
 29df03a:	jmp    29dae46 <wasm[0]::function[1013]::helper::array_indexed_publish+0x486>
 29df03f:	mov    $0xa8000006,%esi
 29df044:	mov    0x60(%rsp),%rdi
 29df049:	mov    0x28(%rdi),%rdi
 29df04d:	mov    0x1a0(%rdi),%edx
 29df053:	mov    $0x10,%r8d
 29df059:	mov    0x60(%rsp),%rdi
 29df05e:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
 29df063:	mov    %eax,%ecx
 29df065:	mov    0xc0(%rsp),%rdx
 29df06d:	add    0x20(%rdx),%rcx
 29df071:	jmp    29daf21 <wasm[0]::function[1013]::helper::array_indexed_publish+0x561>
 29df076:	mov    0xc0(%rsp),%rcx
 29df07e:	mov    0x8(%rcx),%r9
 29df082:	mov    %r9,%r11
 29df085:	mov    %r9,0xa0(%rsp)
 29df08d:	cmp    %r11,%rax
 29df090:	jb     29dafdb <wasm[0]::function[1013]::helper::array_indexed_publish+0x61b>
 29df096:	mov    0x60(%rsp),%rdi
 29df09b:	call   3018b79 <wasmtime_builtin_new_epoch>
 29df0a0:	mov    %rax,0xa0(%rsp)
 29df0a8:	jmp    29dafdb <wasm[0]::function[1013]::helper::array_indexed_publish+0x61b>
 29df0ad:	mov    0xc0(%rsp),%rcx
 29df0b5:	mov    0x8(%rcx),%rcx
 29df0b9:	mov    %rcx,0xa0(%rsp)
 29df0c1:	cmp    %rcx,%rax
 29df0c4:	jb     29db066 <wasm[0]::function[1013]::helper::array_indexed_publish+0x6a6>
 29df0ca:	mov    0x60(%rsp),%rdi
 29df0cf:	call   3018b79 <wasmtime_builtin_new_epoch>
 29df0d4:	mov    %rax,0xa0(%rsp)
 29df0dc:	jmp    29db066 <wasm[0]::function[1013]::helper::array_indexed_publish+0x6a6>
 29df0e1:	mov    0xc0(%rsp),%r14
 29df0e9:	mov    0x8(%r14),%rcx
 29df0ed:	mov    %rcx,0xa0(%rsp)
 29df0f5:	cmp    %rcx,%rax
 29df0f8:	jb     29db1bc <wasm[0]::function[1013]::helper::array_indexed_publish+0x7fc>
 29df0fe:	mov    0x60(%rsp),%rdi
 29df103:	call   3018b79 <wasmtime_builtin_new_epoch>
 29df108:	mov    %rax,0xa0(%rsp)
 29df110:	jmp    29db1bc <wasm[0]::function[1013]::helper::array_indexed_publish+0x7fc>
 29df115:	mov    0xc0(%rsp),%r14
 29df11d:	mov    0x8(%r14),%rcx
 29df121:	mov    %rcx,0xa0(%rsp)
 29df129:	cmp    %rcx,%rax
 29df12c:	jb     29db2b1 <wasm[0]::function[1013]::helper::array_indexed_publish+0x8f1>
 29df132:	mov    0x60(%rsp),%rdi
 29df137:	call   3018b79 <wasmtime_builtin_new_epoch>
 29df13c:	mov    %rax,0xa0(%rsp)
 29df144:	jmp    29db2b1 <wasm[0]::function[1013]::helper::array_indexed_publish+0x8f1>
 29df149:	mov    0xc0(%rsp),%r14
 29df151:	mov    0x8(%r14),%rax
 29df155:	mov    %rax,0xa0(%rsp)
 29df15d:	cmp    %rax,%rsi
 29df160:	jb     29db363 <wasm[0]::function[1013]::helper::array_indexed_publish+0x9a3>
 29df166:	mov    0x60(%rsp),%rdi
 29df16b:	call   3018b79 <wasmtime_builtin_new_epoch>
 29df170:	mov    %rax,0xa0(%rsp)
 29df178:	mov    %rbx,%rcx
 29df17b:	mov    %r15,%rdx
 29df17e:	mov    0x78(%rsp),%rsi
 29df183:	jmp    29db36e <wasm[0]::function[1013]::helper::array_indexed_publish+0x9ae>
 29df188:	mov    $0xa8000006,%esi
 29df18d:	mov    0x60(%rsp),%rdi
 29df192:	mov    0x28(%rdi),%rax
 29df196:	mov    0x1a4(%rax),%edx
 29df19c:	mov    $0x10,%r8d
 29df1a2:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
 29df1a7:	mov    %eax,%ecx
 29df1a9:	mov    0xc0(%rsp),%r14
 29df1b1:	add    0x20(%r14),%rcx
 29df1b5:	jmp    29db420 <wasm[0]::function[1013]::helper::array_indexed_publish+0xa60>
 29df1ba:	mov    0xc0(%rsp),%r14
 29df1c2:	mov    0x8(%r14),%rcx
 29df1c6:	mov    %rcx,0xa0(%rsp)
 29df1ce:	cmp    %rcx,%rax
 29df1d1:	jb     29db4d9 <wasm[0]::function[1013]::helper::array_indexed_publish+0xb19>
 29df1d7:	mov    0x60(%rsp),%rdi
 29df1dc:	call   3018b79 <wasmtime_builtin_new_epoch>
 29df1e1:	mov    %rax,0xa0(%rsp)
 29df1e9:	jmp    29db4d9 <wasm[0]::function[1013]::helper::array_indexed_publish+0xb19>
 29df1ee:	mov    0xc0(%rsp),%r14
 29df1f6:	mov    0x8(%r14),%rdi
 29df1fa:	mov    %rdi,%r9
 29df1fd:	mov    %rdi,0xa0(%rsp)
 29df205:	cmp    %r9,%rax
 29df208:	jb     29db564 <wasm[0]::function[1013]::helper::array_indexed_publish+0xba4>
 29df20e:	mov    0x60(%rsp),%rdi
 29df213:	call   3018b79 <wasmtime_builtin_new_epoch>
 29df218:	mov    %rax,0xa0(%rsp)
 29df220:	jmp    29db564 <wasm[0]::function[1013]::helper::array_indexed_publish+0xba4>
 29df225:	mov    0xc0(%rsp),%r14
 29df22d:	mov    0x8(%r14),%rcx
 29df231:	mov    %rcx,0xa0(%rsp)
 29df239:	cmp    %rcx,%rax
 29df23c:	jb     29db6a6 <wasm[0]::function[1013]::helper::array_indexed_publish+0xce6>
 29df242:	mov    0x60(%rsp),%rdi
 29df247:	call   3018b79 <wasmtime_builtin_new_epoch>
 29df24c:	mov    %rax,0xa0(%rsp)
 29df254:	jmp    29db6a6 <wasm[0]::function[1013]::helper::array_indexed_publish+0xce6>
 29df259:	mov    0xc0(%rsp),%r14
 29df261:	mov    0x8(%r14),%r9
 29df265:	mov    %r9,%r11
 29df268:	mov    %r9,0xa0(%rsp)
 29df270:	cmp    %r11,%rax
 29df273:	jb     29db791 <wasm[0]::function[1013]::helper::array_indexed_publish+0xdd1>
 29df279:	mov    0x60(%rsp),%rdi
 29df27e:	call   3018b79 <wasmtime_builtin_new_epoch>
 29df283:	mov    %rax,0xa0(%rsp)
 29df28b:	jmp    29db791 <wasm[0]::function[1013]::helper::array_indexed_publish+0xdd1>
 29df290:	mov    0xc0(%rsp),%r14
 29df298:	mov    0x8(%r14),%rcx
 29df29c:	mov    %rcx,0xa0(%rsp)
 29df2a4:	cmp    %rcx,%rax
 29df2a7:	jb     29db838 <wasm[0]::function[1013]::helper::array_indexed_publish+0xe78>
 29df2ad:	mov    0x60(%rsp),%rdi
 29df2b2:	call   3018b79 <wasmtime_builtin_new_epoch>
 29df2b7:	mov    %rax,0xa0(%rsp)
 29df2bf:	mov    %rbx,%rcx
 29df2c2:	mov    %r15,%rdx
 29df2c5:	mov    %r13,%rsi
 29df2c8:	jmp    29db841 <wasm[0]::function[1013]::helper::array_indexed_publish+0xe81>
 29df2cd:	mov    $0xa800000e,%esi
 29df2d2:	mov    0x60(%rsp),%rdi
 29df2d7:	mov    0x28(%rdi),%rdx
 29df2db:	mov    0x19c(%rdx),%edx
 29df2e1:	mov    $0x10,%r8d
 29df2e7:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
 29df2ec:	mov    %eax,%ecx
 29df2ee:	mov    0xc0(%rsp),%rdx
 29df2f6:	add    0x20(%rdx),%rcx
 29df2fa:	jmp    29dbd66 <wasm[0]::function[1013]::helper::array_indexed_publish+0x13a6>
 29df2ff:	mov    0xc0(%rsp),%rcx
 29df307:	mov    0x8(%rcx),%rcx
 29df30b:	mov    %rcx,0xa0(%rsp)
 29df313:	cmp    %rcx,%rax
 29df316:	jb     29dbe19 <wasm[0]::function[1013]::helper::array_indexed_publish+0x1459>
 29df31c:	mov    0x60(%rsp),%rdi
 29df321:	call   3018b79 <wasmtime_builtin_new_epoch>
 29df326:	mov    %rax,0xa0(%rsp)
 29df32e:	jmp    29dbe19 <wasm[0]::function[1013]::helper::array_indexed_publish+0x1459>
 29df333:	mov    0xc0(%rsp),%rcx
 29df33b:	mov    0x8(%rcx),%rcx
 29df33f:	mov    %rcx,0xa0(%rsp)
 29df347:	cmp    %rcx,%rax
 29df34a:	jb     29dbea5 <wasm[0]::function[1013]::helper::array_indexed_publish+0x14e5>
 29df350:	mov    0x60(%rsp),%rdi
 29df355:	call   3018b79 <wasmtime_builtin_new_epoch>
 29df35a:	mov    %rax,0xa0(%rsp)
 29df362:	mov    0x78(%rsp),%rdx
 29df367:	jmp    29dbeaa <wasm[0]::function[1013]::helper::array_indexed_publish+0x14ea>
 29df36c:	mov    $0xb0000042,%esi
 29df371:	mov    $0x20,%ecx
 29df376:	mov    %rbx,%rdx
 29df379:	mov    0x60(%rsp),%rdi
 29df37e:	mov    0xa8(%rsp),%r8
 29df386:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
 29df38b:	mov    %eax,%esi
 29df38d:	mov    0xc0(%rsp),%r8
 29df395:	add    0x20(%r8),%rsi
 29df399:	mov    0xb8(%rsp),%rcx
 29df3a1:	mov    0x80(%rsp),%rdx
 29df3a9:	jmp    29dc0b8 <wasm[0]::function[1013]::helper::array_indexed_publish+0x16f8>
 29df3ae:	mov    0xc0(%rsp),%r14
 29df3b6:	mov    0x8(%r14),%rcx
 29df3ba:	mov    %rcx,0xa0(%rsp)
 29df3c2:	cmp    %rcx,%rax
 29df3c5:	jb     29dc376 <wasm[0]::function[1013]::helper::array_indexed_publish+0x19b6>
 29df3cb:	mov    0x60(%rsp),%rdi
 29df3d0:	call   3018b79 <wasmtime_builtin_new_epoch>
 29df3d5:	mov    %rax,0xa0(%rsp)
 29df3dd:	jmp    29dc376 <wasm[0]::function[1013]::helper::array_indexed_publish+0x19b6>
 29df3e2:	mov    $0xa800000e,%esi
 29df3e7:	mov    0x60(%rsp),%rdi
 29df3ec:	mov    0x28(%rdi),%rax
 29df3f0:	mov    0x19c(%rax),%edx
 29df3f6:	mov    $0x10,%r8d
 29df3fc:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
 29df401:	mov    %eax,%ecx
 29df403:	mov    0xc0(%rsp),%rdx
 29df40b:	add    0x20(%rdx),%rcx
 29df40f:	jmp    29dc438 <wasm[0]::function[1013]::helper::array_indexed_publish+0x1a78>
 29df414:	mov    0xc0(%rsp),%rax
 29df41c:	mov    0x8(%rax),%rax
 29df420:	mov    %rax,0xa0(%rsp)
 29df428:	cmp    %rax,%rcx
 29df42b:	jb     29dc4ec <wasm[0]::function[1013]::helper::array_indexed_publish+0x1b2c>
 29df431:	mov    0x60(%rsp),%rdi
 29df436:	call   3018b79 <wasmtime_builtin_new_epoch>
 29df43b:	mov    %rax,0xa0(%rsp)
 29df443:	jmp    29dc4ec <wasm[0]::function[1013]::helper::array_indexed_publish+0x1b2c>
 29df448:	mov    0xc0(%rsp),%r14
 29df450:	mov    0x8(%r14),%rax
 29df454:	mov    %rax,0xa0(%rsp)
 29df45c:	cmp    %rax,%rsi
 29df45f:	jb     29dc661 <wasm[0]::function[1013]::helper::array_indexed_publish+0x1ca1>
 29df465:	mov    0x60(%rsp),%rdi
 29df46a:	call   3018b79 <wasmtime_builtin_new_epoch>
 29df46f:	mov    %rax,0xa0(%rsp)
 29df477:	jmp    29dc661 <wasm[0]::function[1013]::helper::array_indexed_publish+0x1ca1>
 29df47c:	mov    0xc0(%rsp),%rdx
 29df484:	mov    0x8(%rdx),%rax
 29df488:	mov    %rax,0xa0(%rsp)
 29df490:	cmp    %rax,%rcx
 29df493:	jb     29dc704 <wasm[0]::function[1013]::helper::array_indexed_publish+0x1d44>
 29df499:	mov    0x60(%rsp),%rdi
 29df49e:	call   3018b79 <wasmtime_builtin_new_epoch>
 29df4a3:	mov    %rax,0xa0(%rsp)
 29df4ab:	mov    0x80(%rsp),%rax
 29df4b3:	jmp    29dc70c <wasm[0]::function[1013]::helper::array_indexed_publish+0x1d4c>
 29df4b8:	mov    $0xb0000042,%esi
 29df4bd:	mov    0x60(%rsp),%rdi
 29df4c2:	mov    0x28(%rdi),%rax
 29df4c6:	mov    0x120(%rax),%edx
 29df4cc:	mov    $0x20,%ecx
 29df4d1:	mov    $0x10,%r8d
 29df4d7:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
 29df4dc:	mov    %eax,%esi
 29df4de:	mov    0xc0(%rsp),%r14
 29df4e6:	add    0x20(%r14),%rsi
 29df4ea:	mov    0x88(%rsp),%rdi
 29df4f2:	jmp    29dc82e <wasm[0]::function[1013]::helper::array_indexed_publish+0x1e6e>
 29df4f7:	mov    $0xa800000e,%esi
 29df4fc:	mov    0x60(%rsp),%rdi
 29df501:	mov    0x28(%rdi),%r9
 29df505:	mov    0x194(%r9),%edx
 29df50c:	mov    $0x10,%r8d
 29df512:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
 29df517:	mov    %eax,%ecx
 29df519:	mov    0xc0(%rsp),%rdx
 29df521:	add    0x20(%rdx),%rcx
 29df525:	jmp    29dcba2 <wasm[0]::function[1013]::helper::array_indexed_publish+0x21e2>
 29df52a:	mov    0xc0(%rsp),%rcx
 29df532:	mov    0x8(%rcx),%rcx
 29df536:	mov    %rcx,0xa0(%rsp)
 29df53e:	cmp    %rcx,%rax
 29df541:	jb     29dcc54 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2294>
 29df547:	mov    0x60(%rsp),%rdi
 29df54c:	call   3018b79 <wasmtime_builtin_new_epoch>
 29df551:	mov    %rax,0xa0(%rsp)
 29df559:	jmp    29dcc54 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2294>
 29df55e:	mov    0xc0(%rsp),%rcx
 29df566:	mov    0x8(%rcx),%rcx
 29df56a:	mov    %rcx,0xa0(%rsp)
 29df572:	cmp    %rcx,%rax
 29df575:	jb     29dccff <wasm[0]::function[1013]::helper::array_indexed_publish+0x233f>
 29df57b:	mov    0x60(%rsp),%rdi
 29df580:	call   3018b79 <wasmtime_builtin_new_epoch>
 29df585:	mov    %rax,0xa0(%rsp)
 29df58d:	mov    0x78(%rsp),%rcx
 29df592:	jmp    29dcd04 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2344>
 29df597:	mov    0xa8(%rsp),%rcx
 29df59f:	mov    0xb0(%rsp),%rdx
 29df5a7:	mov    %r15,%rsi
 29df5aa:	mov    0x60(%rsp),%rdi
 29df5af:	mov    0x90(%rsp),%r8
 29df5b7:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
 29df5bc:	mov    %eax,%ecx
 29df5be:	mov    0xc0(%rsp),%rdx
 29df5c6:	add    0x20(%rdx),%rcx
 29df5ca:	mov    0xb8(%rsp),%r13
 29df5d2:	jmp    29dceaa <wasm[0]::function[1013]::helper::array_indexed_publish+0x24ea>
 29df5d7:	mov    $0xb0000072,%esi
 29df5dc:	mov    0x88(%rsp),%r12
 29df5e4:	mov    0xa8(%rsp),%rcx
 29df5ec:	mov    %r12,%rdx
 29df5ef:	mov    0x60(%rsp),%rdi
 29df5f4:	mov    0x90(%rsp),%r8
 29df5fc:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
 29df601:	mov    %eax,%ecx
 29df603:	mov    0xc0(%rsp),%rdx
 29df60b:	add    0x20(%rdx),%rcx
 29df60f:	jmp    29dcf24 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2564>
 29df614:	mov    $0xa800000e,%esi
 29df619:	mov    0x60(%rsp),%rdi
 29df61e:	mov    0x28(%rdi),%rax
 29df622:	mov    0x194(%rax),%edx
 29df628:	mov    $0x10,%r8d
 29df62e:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
 29df633:	mov    %eax,%ecx
 29df635:	mov    0xc0(%rsp),%r8
 29df63d:	add    0x20(%r8),%rcx
 29df641:	jmp    29dd198 <wasm[0]::function[1013]::helper::array_indexed_publish+0x27d8>
 29df646:	mov    0xc0(%rsp),%rdx
 29df64e:	mov    0x8(%rdx),%rax
 29df652:	mov    %rax,0xa0(%rsp)
 29df65a:	cmp    %rax,%rcx
 29df65d:	jb     29dd23e <wasm[0]::function[1013]::helper::array_indexed_publish+0x287e>
 29df663:	mov    0x60(%rsp),%rdi
 29df668:	call   3018b79 <wasmtime_builtin_new_epoch>
 29df66d:	mov    %rax,0xa0(%rsp)
 29df675:	jmp    29dd23e <wasm[0]::function[1013]::helper::array_indexed_publish+0x287e>
 29df67a:	mov    0xc0(%rsp),%rcx
 29df682:	mov    0x8(%rcx),%rcx
 29df686:	mov    %rcx,0xa0(%rsp)
 29df68e:	cmp    %rcx,%rax
 29df691:	jb     29dd2d9 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2919>
 29df697:	mov    0x60(%rsp),%rdi
 29df69c:	call   3018b79 <wasmtime_builtin_new_epoch>
 29df6a1:	mov    %rax,0xa0(%rsp)
 29df6a9:	mov    0x88(%rsp),%rcx
 29df6b1:	jmp    29dd2e1 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2921>
 29df6b6:	mov    0x78(%rsp),%rcx
 29df6bb:	mov    %r13,%rdx
 29df6be:	mov    0x80(%rsp),%rsi
 29df6c6:	mov    0x60(%rsp),%rdi
 29df6cb:	mov    0xb8(%rsp),%r8
 29df6d3:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
 29df6d8:	mov    %eax,%edx
 29df6da:	mov    0xc0(%rsp),%rcx
 29df6e2:	add    0x20(%rcx),%rdx
 29df6e6:	mov    %r15,%rcx
 29df6e9:	jmp    29dd3e1 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2a21>
 29df6ee:	mov    0xc0(%rsp),%r14
 29df6f6:	mov    0x8(%r14),%rcx
 29df6fa:	mov    %rcx,0xa0(%rsp)
 29df702:	cmp    %rcx,%rax
 29df705:	jb     29dd676 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2cb6>
 29df70b:	mov    0x60(%rsp),%rdi
 29df710:	call   3018b79 <wasmtime_builtin_new_epoch>
 29df715:	mov    %rax,0xa0(%rsp)
 29df71d:	mov    0x90(%rsp),%rdi
 29df725:	jmp    29dd67e <wasm[0]::function[1013]::helper::array_indexed_publish+0x2cbe>
 29df72a:	mov    $0xa800000e,%esi
 29df72f:	mov    0x60(%rsp),%rdi
 29df734:	mov    0x28(%rdi),%r10
 29df738:	mov    0x1ac(%r10),%edx
 29df73f:	mov    $0x10,%r8d
 29df745:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
 29df74a:	mov    %eax,%ecx
 29df74c:	mov    0xc0(%rsp),%r14
 29df754:	add    0x20(%r14),%rcx
 29df758:	jmp    29dd76d <wasm[0]::function[1013]::helper::array_indexed_publish+0x2dad>
 29df75d:	mov    0xc0(%rsp),%r14
 29df765:	mov    0x8(%r14),%rcx
 29df769:	mov    %rcx,0xa0(%rsp)
 29df771:	cmp    %rcx,%rax
 29df774:	jb     29dd811 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2e51>
 29df77a:	mov    0x60(%rsp),%rdi
 29df77f:	call   3018b79 <wasmtime_builtin_new_epoch>
 29df784:	mov    %rax,0xa0(%rsp)
 29df78c:	jmp    29dd811 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2e51>
 29df791:	mov    0xc0(%rsp),%r14
 29df799:	mov    0x8(%r14),%rcx
 29df79d:	mov    %rcx,0xa0(%rsp)
 29df7a5:	cmp    %rcx,%rax
 29df7a8:	jb     29dd892 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2ed2>
 29df7ae:	mov    0x60(%rsp),%rdi
 29df7b3:	call   3018b79 <wasmtime_builtin_new_epoch>
 29df7b8:	mov    %rax,0xa0(%rsp)
 29df7c0:	mov    0x78(%rsp),%rcx
 29df7c5:	jmp    29dd897 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2ed7>
 29df7ca:	mov    $0xb0000062,%esi
 29df7cf:	mov    0x88(%rsp),%rcx
 29df7d7:	mov    0x80(%rsp),%rdx
 29df7df:	mov    0x60(%rsp),%rdi
 29df7e4:	mov    %r15,%r8
 29df7e7:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
 29df7ec:	mov    %eax,%r9d
 29df7ef:	mov    0xc0(%rsp),%rcx
 29df7f7:	add    0x20(%rcx),%r9
 29df7fb:	mov    0x80(%rsp),%rcx
 29df803:	mov    0xb8(%rsp),%rdx
 29df80b:	jmp    29dda82 <wasm[0]::function[1013]::helper::array_indexed_publish+0x30c2>
 29df810:	mov    0xc0(%rsp),%rcx
 29df818:	mov    0x8(%rcx),%rdx
 29df81c:	mov    %rdx,%rsi
 29df81f:	mov    %rdx,0xa0(%rsp)
 29df827:	cmp    %rsi,%rax
 29df82a:	jb     29ddc3a <wasm[0]::function[1013]::helper::array_indexed_publish+0x327a>
 29df830:	mov    0x60(%rsp),%rdi
 29df835:	call   3018b79 <wasmtime_builtin_new_epoch>
 29df83a:	mov    %rax,0xa0(%rsp)
 29df842:	jmp    29ddc3a <wasm[0]::function[1013]::helper::array_indexed_publish+0x327a>
 29df847:	mov    $0xa800000e,%esi
 29df84c:	mov    0x60(%rsp),%rdi
 29df851:	mov    0x28(%rdi),%rax
 29df855:	mov    0x194(%rax),%edx
 29df85b:	mov    $0x10,%r8d
 29df861:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
 29df866:	mov    %eax,%ecx
 29df868:	mov    0xc0(%rsp),%rsi
 29df870:	add    0x20(%rsi),%rcx
 29df874:	jmp    29ddcf5 <wasm[0]::function[1013]::helper::array_indexed_publish+0x3335>
 29df879:	mov    0xc0(%rsp),%rax
 29df881:	mov    0x8(%rax),%rax
 29df885:	mov    %rax,0xa0(%rsp)
 29df88d:	cmp    %rax,%rcx
 29df890:	jb     29ddd9f <wasm[0]::function[1013]::helper::array_indexed_publish+0x33df>
 29df896:	mov    0x60(%rsp),%rdi
 29df89b:	call   3018b79 <wasmtime_builtin_new_epoch>
 29df8a0:	mov    %rax,0xa0(%rsp)
 29df8a8:	jmp    29ddd9f <wasm[0]::function[1013]::helper::array_indexed_publish+0x33df>
 29df8ad:	mov    0xc0(%rsp),%rcx
 29df8b5:	mov    0x8(%rcx),%rcx
 29df8b9:	mov    %rcx,0xa0(%rsp)
 29df8c1:	cmp    %rcx,%rax
 29df8c4:	jb     29ddf3f <wasm[0]::function[1013]::helper::array_indexed_publish+0x357f>
 29df8ca:	mov    0x60(%rsp),%rdi
 29df8cf:	call   3018b79 <wasmtime_builtin_new_epoch>
 29df8d4:	mov    %rax,0xa0(%rsp)
 29df8dc:	jmp    29ddf3f <wasm[0]::function[1013]::helper::array_indexed_publish+0x357f>
 29df8e1:	mov    0xc0(%rsp),%r14
 29df8e9:	mov    0x8(%r14),%rax
 29df8ed:	mov    %rax,0xa0(%rsp)
 29df8f5:	cmp    %rax,%rcx
 29df8f8:	jb     29ddfd6 <wasm[0]::function[1013]::helper::array_indexed_publish+0x3616>
 29df8fe:	mov    0x60(%rsp),%rdi
 29df903:	call   3018b79 <wasmtime_builtin_new_epoch>
 29df908:	mov    %rax,0xa0(%rsp)
 29df910:	jmp    29ddfd6 <wasm[0]::function[1013]::helper::array_indexed_publish+0x3616>
 29df915:	mov    $0xa800000e,%esi
 29df91a:	mov    0x60(%rsp),%rdi
 29df91f:	mov    0x28(%rdi),%r8
 29df923:	mov    0x1ac(%r8),%edx
 29df92a:	mov    $0x34,%ecx
 29df92f:	mov    $0x10,%r8d
 29df935:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
 29df93a:	mov    %eax,%ecx
 29df93c:	mov    0xc0(%rsp),%r14
 29df944:	add    0x20(%r14),%rcx
 29df948:	jmp    29de2e4 <wasm[0]::function[1013]::helper::array_indexed_publish+0x3924>
 29df94d:	mov    0xc0(%rsp),%r14
 29df955:	mov    0x8(%r14),%rcx
 29df959:	mov    %rcx,0xa0(%rsp)
 29df961:	cmp    %rcx,%rax
 29df964:	jb     29de381 <wasm[0]::function[1013]::helper::array_indexed_publish+0x39c1>
 29df96a:	mov    0x60(%rsp),%rdi
 29df96f:	call   3018b79 <wasmtime_builtin_new_epoch>
 29df974:	mov    %rax,0xa0(%rsp)
 29df97c:	jmp    29de381 <wasm[0]::function[1013]::helper::array_indexed_publish+0x39c1>
 29df981:	mov    0xc0(%rsp),%r14
 29df989:	mov    0x8(%r14),%rax
 29df98d:	mov    %rax,0xa0(%rsp)
 29df995:	cmp    %rax,%rcx
 29df998:	jb     29de422 <wasm[0]::function[1013]::helper::array_indexed_publish+0x3a62>
 29df99e:	mov    0x60(%rsp),%rdi
 29df9a3:	call   3018b79 <wasmtime_builtin_new_epoch>
 29df9a8:	mov    %rax,0xa0(%rsp)
 29df9b0:	mov    0x98(%rsp),%rax
 29df9b8:	jmp    29de42a <wasm[0]::function[1013]::helper::array_indexed_publish+0x3a6a>
 29df9bd:	mov    0xc0(%rsp),%r14
 29df9c5:	mov    0x8(%r14),%rax
 29df9c9:	mov    %rax,0xa0(%rsp)
 29df9d1:	cmp    %rax,%r11
 29df9d4:	jb     29de4fe <wasm[0]::function[1013]::helper::array_indexed_publish+0x3b3e>
 29df9da:	mov    0x60(%rsp),%rdi
 29df9df:	call   3018b79 <wasmtime_builtin_new_epoch>
 29df9e4:	mov    %rax,0xa0(%rsp)
 29df9ec:	jmp    29de4fe <wasm[0]::function[1013]::helper::array_indexed_publish+0x3b3e>
 29df9f1:	mov    0xc0(%rsp),%r14
 29df9f9:	mov    0x8(%r14),%rax
 29df9fd:	mov    %rax,0xa0(%rsp)
 29dfa05:	cmp    %rax,%r9
 29dfa08:	jb     29de7e1 <wasm[0]::function[1013]::helper::array_indexed_publish+0x3e21>
 29dfa0e:	mov    0x60(%rsp),%rdi
 29dfa13:	call   3018b79 <wasmtime_builtin_new_epoch>
 29dfa18:	mov    %rax,0xa0(%rsp)
 29dfa20:	jmp    29de7e1 <wasm[0]::function[1013]::helper::array_indexed_publish+0x3e21>
 29dfa25:	mov    $0xa800000e,%esi
 29dfa2a:	mov    0x60(%rsp),%rdi
 29dfa2f:	mov    0x28(%rdi),%rax
 29dfa33:	mov    0x1ac(%rax),%edx
 29dfa39:	mov    0x98(%rsp),%r8
 29dfa41:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
 29dfa46:	mov    %eax,%edi
 29dfa48:	mov    0xc0(%rsp),%rcx
 29dfa50:	add    0x20(%rcx),%rdi
 29dfa54:	jmp    29de9f4 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4034>
 29dfa59:	mov    0xc0(%rsp),%rcx
 29dfa61:	mov    0x8(%rcx),%rcx
 29dfa65:	mov    %rcx,0xa0(%rsp)
 29dfa6d:	cmp    %rcx,%rax
 29dfa70:	jb     29dea9b <wasm[0]::function[1013]::helper::array_indexed_publish+0x40db>
 29dfa76:	mov    0x60(%rsp),%rdi
 29dfa7b:	call   3018b79 <wasmtime_builtin_new_epoch>
 29dfa80:	mov    %rax,0xa0(%rsp)
 29dfa88:	jmp    29dea9b <wasm[0]::function[1013]::helper::array_indexed_publish+0x40db>
 29dfa8d:	mov    0xc0(%rsp),%rcx
 29dfa95:	mov    0x8(%rcx),%rcx
 29dfa99:	mov    %rcx,0xa0(%rsp)
 29dfaa1:	cmp    %rcx,%rax
 29dfaa4:	jb     29deb36 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4176>
 29dfaaa:	mov    0x60(%rsp),%rdi
 29dfaaf:	call   3018b79 <wasmtime_builtin_new_epoch>
 29dfab4:	mov    %rax,0xa0(%rsp)
 29dfabc:	mov    0x80(%rsp),%rax
 29dfac4:	jmp    29deb3e <wasm[0]::function[1013]::helper::array_indexed_publish+0x417e>
 29dfac9:	mov    0xc0(%rsp),%rcx
 29dfad1:	mov    0x8(%rcx),%rcx
 29dfad5:	mov    %rcx,0xa0(%rsp)
 29dfadd:	cmp    %rcx,%rax
 29dfae0:	jb     29dec15 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4255>
 29dfae6:	mov    0x60(%rsp),%rdi
 29dfaeb:	call   3018b79 <wasmtime_builtin_new_epoch>
 29dfaf0:	mov    %rax,0xa0(%rsp)
 29dfaf8:	jmp    29dec15 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4255>
 29dfafd:	mov    $0xb0000062,%esi
 29dfb02:	mov    0x60(%rsp),%rdi
 29dfb07:	mov    0x28(%rdi),%rcx
 29dfb0b:	mov    0x1a8(%rcx),%edx
 29dfb11:	mov    $0x20,%ecx
 29dfb16:	mov    0x98(%rsp),%r8
 29dfb1e:	call   3018bda <wasmtime_builtin_gc_alloc_raw>
 29dfb23:	mov    %eax,%ecx
 29dfb25:	mov    0xc0(%rsp),%r14
 29dfb2d:	add    0x20(%r14),%rcx
 29dfb31:	mov    0x68(%rsp),%rdx
 29dfb36:	jmp    29deedd <wasm[0]::function[1013]::helper::array_indexed_publish+0x451d>
 29dfb3b:	ud2
 29dfb3d:	ud2
 29dfb3f:	ud2
 29dfb41:	ud2
 29dfb43:	ud2
 29dfb45:	ud2
 29dfb47:	ud2
 29dfb49:	ud2
 29dfb4b:	ud2
 29dfb4d:	ud2
 29dfb4f:	ud2
 29dfb51:	ud2
 29dfb53:	ud2
 29dfb55:	ud2
 29dfb57:	ud2
 29dfb59:	ud2
 29dfb5b:	ud2
 29dfb5d:	ud2
 29dfb5f:	ud2
 29dfb61:	ud2
 29dfb63:	ud2
 29dfb65:	ud2
 29dfb67:	ud2
 29dfb69:	ud2
 29dfb6b:	ud2
 29dfb6d:	ud2
 29dfb6f:	ud2
 29dfb71:	ud2
 29dfb73:	ud2
 29dfb75:	ud2
 29dfb77:	ud2
 29dfb79:	ud2
 29dfb7b:	ud2
 29dfb7d:	ud2
 29dfb7f:	ud2
 29dfb81:	ud2
 29dfb83:	ud2
 29dfb85:	ud2
 29dfb87:	ud2
 29dfb89:	ud2
 29dfb8b:	ud2
 29dfb8d:	ud2
 29dfb8f:	ud2
 29dfb91:	ud2
 29dfb93:	ud2
 29dfb95:	ud2
 29dfb97:	ud2
 29dfb99:	ud2
 29dfb9b:	ud2
 29dfb9d:	ud2
 29dfb9f:	ud2
 29dfba1:	ud2
 29dfba3:	ud2
 29dfba5:	ud2
 29dfba7:	ud2
 29dfba9:	ud2
 29dfbab:	ud2
 29dfbad:	ud2
 29dfbaf:	ud2
 29dfbb1:	ud2
 29dfbb3:	ud2
 29dfbb5:	ud2
 29dfbb7:	ud2
 29dfbb9:	ud2
 29dfbbb:	ud2
 29dfbbd:	ud2
 29dfbbf:	ud2
 29dfbc1:	ud2
 29dfbc3:	ud2
 29dfbc5:	ud2
 29dfbc7:	ud2
 29dfbc9:	ud2
 29dfbcb:	ud2
 29dfbcd:	ud2
 29dfbcf:	ud2
 29dfbd1:	ud2
 29dfbd3:	ud2
 29dfbd5:	ud2
 29dfbd7:	ud2
 29dfbd9:	ud2
 29dfbdb:	ud2
 29dfbdd:	ud2
 29dfbdf:	ud2
 29dfbe1:	ud2
 29dfbe3:	ud2
 29dfbe5:	ud2
 29dfbe7:	ud2
 29dfbe9:	ud2
 29dfbeb:	ud2
 29dfbed:	ud2
 29dfbef:	ud2
 29dfbf1:	ud2
 29dfbf3:	ud2
 29dfbf5:	ud2
 29dfbf7:	ud2
 29dfbf9:	ud2
 29dfbfb:	ud2
 29dfbfd:	ud2
 29dfbff:	ud2
 29dfc01:	ud2
 29dfc03:	ud2
 29dfc05:	ud2
 29dfc07:	ud2
 29dfc09:	ud2
 29dfc0b:	ud2
 29dfc0d:	ud2
 29dfc0f:	ud2
 29dfc11:	ud2
 29dfc13:	ud2
 29dfc15:	ud2
 29dfc17:	ud2
 29dfc19:	ud2
 29dfc1b:	ud2
 29dfc1d:	ud2
 29dfc1f:	ud2
 29dfc21:	ud2
 29dfc23:	ud2
 29dfc25:	ud2
 29dfc27:	ud2
 29dfc29:	ud2
 29dfc2b:	ud2
 29dfc2d:	ud2
 29dfc2f:	ud2
 29dfc31:	ud2
 29dfc33:	ud2
 29dfc35:	ud2
 29dfc37:	ud2
 29dfc39:	ud2
 29dfc3b:	ud2
 29dfc3d:	ud2
 29dfc3f:	ud2
 29dfc41:	ud2
 29dfc43:	ud2
 29dfc45:	ud2
 29dfc47:	ud2
 29dfc49:	ud2
 29dfc4b:	ud2
 29dfc4d:	ud2
 29dfc4f:	ud2
 29dfc51:	ud2
 29dfc53:	ud2
 29dfc55:	ud2
 29dfc57:	ud2
 29dfc59:	ud2
 29dfc5b:	ud2
 29dfc5d:	ud2
 29dfc5f:	ud2
 29dfc61:	ud2
 29dfc63:	ud2
 29dfc65:	ud2
 29dfc67:	ud2
 29dfc69:	ud2
 29dfc6b:	ud2
 29dfc6d:	ud2
 29dfc6f:	ud2
 29dfc71:	ud2
 29dfc73:	ud2
 29dfc75:	ud2
 29dfc77:	ud2
 29dfc79:	ud2
 29dfc7b:	ud2
 29dfc7d:	ud2
 29dfc7f:	ud2
 29dfc81:	ud2
 29dfc83:	ud2
 29dfc85:	ud2
 29dfc87:	ud2
 29dfc89:	ud2
 29dfc8b:	ud2
 29dfc8d:	ud2
 29dfc8f:	ud2
 29dfc91:	ud2
 29dfc93:	ud2
 29dfc95:	ud2
 29dfc97:	ud2
 29dfc99:	ud2
 29dfc9b:	ud2
 29dfc9d:	ud2
 29dfc9f:	ud2
 29dfca1:	ud2
 29dfca3:	ud2
 29dfca5:	ud2
 29dfca7:	ud2
 29dfca9:	ud2
 29dfcab:	ud2
 29dfcad:	ud2
 29dfcaf:	ud2
 29dfcb1:	ud2
 29dfcb3:	ud2
 29dfcb5:	ud2
 29dfcb7:	ud2
 29dfcb9:	ud2
 29dfcbb:	ud2
 29dfcbd:	ud2
 29dfcbf:	ud2
 29dfcc1:	ud2
 29dfcc3:	ud2
 29dfcc5:	ud2
 29dfcc7:	ud2
 29dfcc9:	ud2
 29dfccb:	ud2
 29dfccd:	ud2
 29dfccf:	ud2
 29dfcd1:	ud2
 29dfcd3:	ud2
 29dfcd5:	ud2
 29dfcd7:	ud2
 29dfcd9:	ud2
 29dfcdb:	ud2
 29dfcdd:	ud2
 29dfcdf:	ud2
 29dfce1:	ud2
 29dfce3:	ud2
 29dfce5:	ud2
 29dfce7:	ud2
 29dfce9:	ud2
 29dfceb:	ud2
 29dfced:	ud2
 29dfcef:	ud2
 29dfcf1:	ud2
 29dfcf3:	ud2
 29dfcf5:	ud2
 29dfcf7:	ud2
 29dfcf9:	ud2
 29dfcfb:	ud2
 29dfcfd:	ud2
 29dfcff:	ud2
 29dfd01:	ud2
 29dfd03:	ud2
 29dfd05:	ud2
 29dfd07:	ud2
 29dfd09:	ud2
 29dfd0b:	ud2
 29dfd0d:	ud2
 29dfd0f:	ud2
 29dfd11:	ud2
 29dfd13:	ud2
 29dfd15:	ud2
 29dfd17:	ud2
 29dfd19:	ud2
 29dfd1b:	ud2
 29dfd1d:	ud2
 29dfd1f:	ud2
 29dfd21:	ud2
 29dfd23:	ud2
 29dfd25:	ud2
 29dfd27:	ud2
 29dfd29:	ud2
 29dfd2b:	ud2
 29dfd2d:	ud2
 29dfd2f:	ud2
 29dfd31:	ud2
 29dfd33:	ud2
 29dfd35:	ud2
 29dfd37:	ud2
 29dfd39:	ud2
 29dfd3b:	ud2
 29dfd3d:	ud2
 29dfd3f:	ud2
 29dfd41:	ud2
 29dfd43:	ud2
 29dfd45:	ud2
 29dfd47:	ud2
 29dfd49:	ud2
 29dfd4b:	ud2
 29dfd4d:	ud2
 29dfd4f:	ud2
 29dfd51:	ud2
 29dfd53:	ud2
 29dfd55:	ud2
 29dfd57:	ud2
 29dfd59:	ud2
 29dfd5b:	ud2
 29dfd5d:	ud2
 29dfd5f:	ud2
 29dfd61:	ud2
 29dfd63:	ud2
 29dfd65:	ud2
 29dfd67:	ud2
 29dfd69:	ud2
 29dfd6b:	ud2
 29dfd6d:	ud2
 29dfd6f:	ud2
 29dfd71:	ud2
 29dfd73:	ud2
 29dfd75:	ud2
 29dfd77:	ud2
 29dfd79:	ud2
 29dfd7b:	ud2
 29dfd7d:	ud2
 29dfd7f:	ud2
 29dfd81:	ud2
 29dfd83:	ud2
 29dfd85:	ud2
 29dfd87:	ud2
 29dfd89:	ud2
 29dfd8b:	ud2
 29dfd8d:	ud2
 29dfd8f:	ud2
 29dfd91:	ud2
 29dfd93:	ud2
 29dfd95:	ud2
 29dfd97:	ud2
 29dfd99:	ud2
 29dfd9b:	ud2
 29dfd9d:	ud2
 29dfd9f:	ud2
 29dfda1:	ud2
 29dfda3:	ud2
 29dfda5:	ud2
 29dfda7:	ud2
 29dfda9:	ud2
 29dfdab:	ud2
 29dfdad:	ud2
 29dfdaf:	ud2
 29dfdb1:	ud2
 29dfdb3:	ud2
 29dfdb5:	ud2
 29dfdb7:	ud2
 29dfdb9:	ud2
 29dfdbb:	ud2
 29dfdbd:	ud2
 29dfdbf:	ud2
 29dfdc1:	ud2
 29dfdc3:	ud2
 29dfdc5:	ud2
 29dfdc7:	ud2
 29dfdc9:	ud2
 29dfdcb:	ud2
 29dfdcd:	ud2
 29dfdcf:	ud2
 29dfdd1:	ud2
 29dfdd3:	ud2
 29dfdd5:	ud2
 29dfdd7:	ud2
 29dfdd9:	ud2
 29dfddb:	ud2
 29dfddd:	ud2
 29dfddf:	ud2
 29dfde1:	ud2
 29dfde3:	ud2
 29dfde5:	ud2
 29dfde7:	ud2
 29dfde9:	ud2
 29dfdeb:	ud2
 29dfded:	ud2
 29dfdef:	ud2
 29dfdf1:	ud2
 29dfdf3:	ud2
 29dfdf5:	ud2
 29dfdf7:	ud2
 29dfdf9:	ud2
 29dfdfb:	ud2
 29dfdfd:	ud2
 29dfdff:	ud2
 29dfe01:	ud2
 29dfe03:	ud2
 29dfe05:	ud2
 29dfe07:	ud2
 29dfe09:	ud2
 29dfe0b:	ud2
 29dfe0d:	ud2
 29dfe0f:	ud2
 29dfe11:	ud2
 29dfe13:	ud2
 29dfe15:	ud2
 29dfe17:	ud2
 29dfe19:	ud2
 29dfe1b:	ud2
 29dfe1d:	ud2
 29dfe1f:	ud2
 29dfe21:	ud2
 29dfe23:	ud2
 29dfe25:	ud2
 29dfe27:	ud2
 29dfe29:	ud2
 29dfe2b:	ud2
 29dfe2d:	ud2
 29dfe2f:	ud2
 29dfe31:	add    %al,(%rax)
 29dfe33:	add    %al,(%rax)
 29dfe35:	add    %al,(%rax)
 29dfe37:	add    %bh,%bh
 29dfe39:	(bad)
 29dfe3a:	(bad)
 29dfe3b:	incl   (%rax)
 29dfe3d:	add    %al,(%rax)
	...
