
/workspace/scriptw/target/performance-dense-numbers-20261030/native-cause/candidate/runtime-portable.elf:     file format elf64-x86-64


Disassembly of section .text:

00000000029f4960 <wasm[0]::function[1010]::helper::array_packed_push1>:
 29f4960:	push   %rbp
 29f4961:	mov    %rsp,%rbp
 29f4964:	mov    0x8(%rdi),%r10
 29f4968:	mov    0x18(%r10),%r10
 29f496c:	add    $0xe0,%r10
 29f4973:	cmp    %rsp,%r10
 29f4976:	ja     29f5387 <wasm[0]::function[1010]::helper::array_packed_push1+0xa27>
 29f497c:	sub    $0xd0,%rsp
 29f4983:	mov    %rbx,0xa0(%rsp)
 29f498b:	mov    %r12,0xa8(%rsp)
 29f4993:	mov    %r13,0xb0(%rsp)
 29f499b:	mov    %r14,0xb8(%rsp)
 29f49a3:	mov    %r15,0xc0(%rsp)
 29f49ab:	mov    %r9,0x48(%rsp)
 29f49b0:	mov    0x10(%rbp),%r9
 29f49b4:	mov    %r9,0x50(%rsp)
 29f49b9:	mov    0x18(%rbp),%rsi
 29f49bd:	mov    %r8d,0x20(%rsp)
 29f49c2:	mov    %esi,0x18(%rsp)
 29f49c6:	mov    0x18(%rdi),%rax
 29f49ca:	mov    (%rax),%rcx
 29f49cd:	mov    %rax,0x90(%rsp)
 29f49d5:	mov    0x8(%rdi),%rbx
 29f49d9:	mov    %rdi,%r10
 29f49dc:	mov    0x8(%rbx),%rax
 29f49e0:	cmp    %rax,%rcx
 29f49e3:	jae    29f5327 <wasm[0]::function[1010]::helper::array_packed_push1+0x9c7>
 29f49e9:	mov    %r10,%r14
 29f49ec:	mov    %rax,0x58(%rsp)
 29f49f1:	mov    0x20(%rsp),%eax
 29f49f5:	xor    %edx,%edx
 29f49f7:	test   %eax,%eax
 29f49f9:	je     29f4a3f <wasm[0]::function[1010]::helper::array_packed_push1+0xdf>
 29f49ff:	mov    0x20(%rsp),%eax
 29f4a03:	xor    %edx,%edx
 29f4a05:	test   $0x1,%eax
 29f4a0a:	jne    29f4a3f <wasm[0]::function[1010]::helper::array_packed_push1+0xdf>
 29f4a10:	mov    0x20(%rsp),%ecx
 29f4a14:	mov    0x28(%rbx),%rax
 29f4a18:	mov    0x20(%rbx),%rdx
 29f4a1c:	mov    %ecx,%esi
 29f4a1e:	xor    %rcx,%rcx
 29f4a21:	lea    0x4(%rdx,%rsi,1),%rdx
 29f4a26:	cmp    %rax,%rsi
 29f4a29:	cmova  %rcx,%rdx
 29f4a2d:	mov    (%rdx),%eax
 29f4a2f:	mov    0x28(%r14),%rcx
 29f4a33:	cmp    0x254(%rcx),%eax
 29f4a39:	sete   %al
 29f4a3c:	movzbl %al,%edx
 29f4a3f:	xor    %eax,%eax
 29f4a41:	xor    %rcx,%rcx
 29f4a44:	test   %edx,%edx
 29f4a46:	jne    29f4a5f <wasm[0]::function[1010]::helper::array_packed_push1+0xff>
 29f4a4c:	mov    %rax,%rdx
 29f4a4f:	mov    %rax,%rsi
 29f4a52:	mov    %rax,%rdi
 29f4a55:	mov    %rcx,0x68(%rsp)
 29f4a5a:	jmp    29f52ec <wasm[0]::function[1010]::helper::array_packed_push1+0x98c>
 29f4a5f:	mov    0x20(%rsp),%edx
 29f4a63:	xor    %eax,%eax
 29f4a65:	test   %edx,%edx
 29f4a67:	je     29f4aab <wasm[0]::function[1010]::helper::array_packed_push1+0x14b>
 29f4a6d:	mov    0x20(%rsp),%edx
 29f4a71:	xor    %eax,%eax
 29f4a73:	test   $0x1,%edx
 29f4a79:	jne    29f4aab <wasm[0]::function[1010]::helper::array_packed_push1+0x14b>
 29f4a7f:	mov    0x20(%rsp),%edx
 29f4a83:	mov    0x28(%rbx),%rax
 29f4a87:	mov    0x20(%rbx),%rsi
 29f4a8b:	mov    %edx,%edi
 29f4a8d:	lea    0x4(%rsi,%rdi,1),%rdx
 29f4a92:	cmp    %rax,%rdi
 29f4a95:	cmova  %rcx,%rdx
 29f4a99:	mov    (%rdx),%eax
 29f4a9b:	mov    0x28(%r14),%rdx
 29f4a9f:	cmp    0x254(%rdx),%eax
 29f4aa5:	sete   %al
 29f4aa8:	movzbl %al,%eax
 29f4aab:	test   %eax,%eax
 29f4aad:	je     29f5389 <wasm[0]::function[1010]::helper::array_packed_push1+0xa29>
 29f4ab3:	mov    0x20(%rsp),%eax
 29f4ab7:	xor    %edx,%edx
 29f4ab9:	test   %eax,%eax
 29f4abb:	je     29f538b <wasm[0]::function[1010]::helper::array_packed_push1+0xa2b>
 29f4ac1:	test   %eax,%eax
 29f4ac3:	je     29f538d <wasm[0]::function[1010]::helper::array_packed_push1+0xa2d>
 29f4ac9:	mov    0x28(%rbx),%rsi
 29f4acd:	mov    0x20(%rbx),%rdi
 29f4ad1:	mov    %eax,%r8d
 29f4ad4:	add    %r8,%rdi
 29f4ad7:	cmp    %rsi,%r8
 29f4ada:	cmova  %rcx,%rdi
 29f4ade:	mov    0x18(%rdi),%r15
 29f4ae2:	test   %eax,%eax
 29f4ae4:	je     29f4b26 <wasm[0]::function[1010]::helper::array_packed_push1+0x1c6>
 29f4aea:	mov    0x20(%rsp),%edi
 29f4aee:	xor    %edx,%edx
 29f4af0:	test   $0x1,%edi
 29f4af6:	jne    29f4b26 <wasm[0]::function[1010]::helper::array_packed_push1+0x1c6>
 29f4afc:	mov    0x28(%rbx),%r10
 29f4b00:	mov    0x20(%rbx),%r11
 29f4b04:	mov    %edi,%eax
 29f4b06:	lea    0x4(%r11,%rax,1),%r9
 29f4b0b:	cmp    %r10,%rax
 29f4b0e:	cmova  %rcx,%r9
 29f4b12:	mov    (%r9),%r11d
 29f4b15:	mov    0x28(%r14),%rax
 29f4b19:	cmp    0x254(%rax),%r11d
 29f4b20:	sete   %al
 29f4b23:	movzbl %al,%edx
 29f4b26:	xor    %edi,%edi
 29f4b28:	test   %edx,%edx
 29f4b2a:	jne    29f4b40 <wasm[0]::function[1010]::helper::array_packed_push1+0x1e0>
 29f4b30:	mov    %rdi,%rdx
 29f4b33:	mov    %r15,%r12
 29f4b36:	mov    %rcx,0x68(%rsp)
 29f4b3b:	jmp    29f528d <wasm[0]::function[1010]::helper::array_packed_push1+0x92d>
 29f4b40:	mov    0x20(%rsp),%edx
 29f4b44:	xor    %eax,%eax
 29f4b46:	test   %edx,%edx
 29f4b48:	je     29f4b84 <wasm[0]::function[1010]::helper::array_packed_push1+0x224>
 29f4b4e:	xor    %eax,%eax
 29f4b50:	test   $0x1,%edx
 29f4b56:	jne    29f4b84 <wasm[0]::function[1010]::helper::array_packed_push1+0x224>
 29f4b5c:	mov    0x28(%rbx),%rax
 29f4b60:	mov    0x20(%rbx),%rsi
 29f4b64:	mov    %edx,%edi
 29f4b66:	lea    0x4(%rsi,%rdi,1),%rsi
 29f4b6b:	cmp    %rax,%rdi
 29f4b6e:	cmova  %rcx,%rsi
 29f4b72:	mov    (%rsi),%eax
 29f4b74:	mov    0x28(%r14),%rsi
 29f4b78:	cmp    0x254(%rsi),%eax
 29f4b7e:	sete   %al
 29f4b81:	movzbl %al,%eax
 29f4b84:	test   %eax,%eax
 29f4b86:	je     29f538f <wasm[0]::function[1010]::helper::array_packed_push1+0xa2f>
 29f4b8c:	test   %edx,%edx
 29f4b8e:	je     29f5391 <wasm[0]::function[1010]::helper::array_packed_push1+0xa31>
 29f4b94:	test   %edx,%edx
 29f4b96:	je     29f5393 <wasm[0]::function[1010]::helper::array_packed_push1+0xa33>
 29f4b9c:	mov    0x28(%rbx),%rax
 29f4ba0:	mov    0x20(%rbx),%rsi
 29f4ba4:	mov    %edx,%edi
 29f4ba6:	lea    (%rsi,%rdi,1),%rdx
 29f4baa:	cmp    %rax,%rdi
 29f4bad:	cmova  %rcx,%rdx
 29f4bb1:	mov    0x14(%rdx),%eax
 29f4bb4:	mov    0x18(%rdx),%rdx
 29f4bb8:	xor    %edi,%edi
 29f4bba:	cmp    %r15,%rdx
 29f4bbd:	je     29f4bd3 <wasm[0]::function[1010]::helper::array_packed_push1+0x273>
 29f4bc3:	mov    %rdi,%rdx
 29f4bc6:	mov    %r15,%r12
 29f4bc9:	mov    %rcx,0x68(%rsp)
 29f4bce:	jmp    29f528d <wasm[0]::function[1010]::helper::array_packed_push1+0x92d>
 29f4bd3:	xor    %edi,%edi
 29f4bd5:	test   %eax,%eax
 29f4bd7:	je     29f5395 <wasm[0]::function[1010]::helper::array_packed_push1+0xa35>
 29f4bdd:	test   %eax,%eax
 29f4bdf:	je     29f5397 <wasm[0]::function[1010]::helper::array_packed_push1+0xa37>
 29f4be5:	mov    0x28(%rbx),%rdx
 29f4be9:	mov    0x20(%rbx),%r8
 29f4bed:	mov    %eax,%esi
 29f4bef:	lea    (%r8,%rsi,1),%rax
 29f4bf3:	cmp    %rdx,%rsi
 29f4bf6:	cmova  %rcx,%rax
 29f4bfa:	mov    0x24(%rax),%edx
 29f4bfd:	cmp    $0x4,%edx
 29f4c00:	sete   %al
 29f4c03:	cmp    $0x2,%edx
 29f4c06:	sete   %r8b
 29f4c0a:	or     %r8d,%eax
 29f4c0d:	cmp    $0x3,%edx
 29f4c10:	sete   %dl
 29f4c13:	or     %edx,%eax
 29f4c15:	movzbl %al,%eax
 29f4c18:	test   %eax,%eax
 29f4c1a:	jne    29f4c30 <wasm[0]::function[1010]::helper::array_packed_push1+0x2d0>
 29f4c20:	mov    %rdi,%rdx
 29f4c23:	mov    %r15,%r12
 29f4c26:	mov    %rcx,0x68(%rsp)
 29f4c2b:	jmp    29f528d <wasm[0]::function[1010]::helper::array_packed_push1+0x92d>
 29f4c30:	lea    0x1(%r15),%rax
 29f4c34:	xor    %edi,%edi
 29f4c36:	cmp    0x78b(%rip),%rax        # 29f53c8 <wasm[0]::function[1010]::helper::array_packed_push1+0xa68>
 29f4c3d:	jbe    29f4c53 <wasm[0]::function[1010]::helper::array_packed_push1+0x2f3>
 29f4c43:	mov    %rdi,%rdx
 29f4c46:	mov    %r15,%r12
 29f4c49:	mov    %rcx,0x68(%rsp)
 29f4c4e:	jmp    29f528d <wasm[0]::function[1010]::helper::array_packed_push1+0x92d>
 29f4c53:	mov    0x20(%rsp),%eax
 29f4c57:	xor    %edi,%edi
 29f4c59:	test   %eax,%eax
 29f4c5b:	je     29f5399 <wasm[0]::function[1010]::helper::array_packed_push1+0xa39>
 29f4c61:	test   %eax,%eax
 29f4c63:	je     29f539b <wasm[0]::function[1010]::helper::array_packed_push1+0xa3b>
 29f4c69:	mov    0x28(%rbx),%rdx
 29f4c6d:	mov    %eax,%r8d
 29f4c70:	mov    %r8,%rax
 29f4c73:	add    0x20(%rbx),%rax
 29f4c77:	cmp    %rdx,%r8
 29f4c7a:	cmova  %rcx,%rax
 29f4c7e:	mov    0x20(%rax),%eax
 29f4c81:	test   %eax,%eax
 29f4c83:	jne    29f4c99 <wasm[0]::function[1010]::helper::array_packed_push1+0x339>
 29f4c89:	mov    %rdi,%rdx
 29f4c8c:	mov    %r15,%r12
 29f4c8f:	mov    %rcx,0x68(%rsp)
 29f4c94:	jmp    29f528d <wasm[0]::function[1010]::helper::array_packed_push1+0x92d>
 29f4c99:	mov    0x20(%rsp),%r8d
 29f4c9e:	xor    %edi,%edi
 29f4ca0:	test   %r8d,%r8d
 29f4ca3:	je     29f539d <wasm[0]::function[1010]::helper::array_packed_push1+0xa3d>
 29f4ca9:	test   %r8d,%r8d
 29f4cac:	je     29f539f <wasm[0]::function[1010]::helper::array_packed_push1+0xa3f>
 29f4cb2:	mov    0x28(%rbx),%rax
 29f4cb6:	mov    0x20(%rbx),%rdx
 29f4cba:	mov    %r8d,%r9d
 29f4cbd:	lea    (%rdx,%r9,1),%r8
 29f4cc1:	cmp    %rax,%r9
 29f4cc4:	cmova  %rcx,%r8
 29f4cc8:	mov    0x10(%r8),%r8d
 29f4ccc:	test   %r8d,%r8d
 29f4ccf:	je     29f53a1 <wasm[0]::function[1010]::helper::array_packed_push1+0xa41>
 29f4cd5:	test   %r8d,%r8d
 29f4cd8:	je     29f53a3 <wasm[0]::function[1010]::helper::array_packed_push1+0xa43>
 29f4cde:	mov    %r8d,%r9d
 29f4ce1:	lea    (%rdx,%r9,1),%r8
 29f4ce5:	cmp    %rax,%r9
 29f4ce8:	cmova  %rcx,%r8
 29f4cec:	mov    0x1c(%r8),%r8d
 29f4cf0:	test   %r8d,%r8d
 29f4cf3:	jne    29f4d09 <wasm[0]::function[1010]::helper::array_packed_push1+0x3a9>
 29f4cf9:	mov    %rdi,%rdx
 29f4cfc:	mov    %r15,%r12
 29f4cff:	mov    %rcx,0x68(%rsp)
 29f4d04:	jmp    29f528d <wasm[0]::function[1010]::helper::array_packed_push1+0x92d>
 29f4d09:	mov    0x28(%rbx),%r8
 29f4d0d:	mov    %rsi,%rdi
 29f4d10:	add    0x20(%rbx),%rdi
 29f4d14:	cmp    %r8,%rsi
 29f4d17:	cmova  %rcx,%rdi
 29f4d1b:	mov    0x18(%rdi),%r9
 29f4d1f:	xor    %edi,%edi
 29f4d21:	cmp    %r15,%r9
 29f4d24:	mov    %r15,0x88(%rsp)
 29f4d2c:	je     29f4d47 <wasm[0]::function[1010]::helper::array_packed_push1+0x3e7>
 29f4d32:	mov    %rdi,%rdx
 29f4d35:	mov    0x88(%rsp),%r12
 29f4d3d:	mov    %rcx,0x68(%rsp)
 29f4d42:	jmp    29f528d <wasm[0]::function[1010]::helper::array_packed_push1+0x92d>
 29f4d47:	mov    0x20(%rsp),%edx
 29f4d4b:	xor    %eax,%eax
 29f4d4d:	mov    %rax,0x60(%rsp)
 29f4d52:	test   %edx,%edx
 29f4d54:	je     29f53a5 <wasm[0]::function[1010]::helper::array_packed_push1+0xa45>
 29f4d5a:	test   %edx,%edx
 29f4d5c:	je     29f53a7 <wasm[0]::function[1010]::helper::array_packed_push1+0xa47>
 29f4d62:	mov    0x28(%rbx),%rax
 29f4d66:	mov    0x20(%rbx),%rsi
 29f4d6a:	mov    %edx,%r8d
 29f4d6d:	lea    (%rsi,%r8,1),%rdi
 29f4d71:	cmp    %rax,%r8
 29f4d74:	cmova  %rcx,%rdi
 29f4d78:	mov    0x10(%rdi),%edi
 29f4d7b:	test   %edi,%edi
 29f4d7d:	je     29f53a9 <wasm[0]::function[1010]::helper::array_packed_push1+0xa49>
 29f4d83:	mov    %edi,%edi
 29f4d85:	add    %rdi,%rsi
 29f4d88:	cmp    %rax,%rdi
 29f4d8b:	cmova  %rcx,%rsi
 29f4d8f:	mov    %rcx,0x68(%rsp)
 29f4d94:	mov    0x10(%rsi),%edi
 29f4d97:	mov    0x18(%rsp),%esi
 29f4d9b:	mov    $0x1,%r12d
 29f4da1:	mov    %r12,0x80(%rsp)
 29f4da9:	mov    0x28(%r14),%rax
 29f4dad:	mov    0x254(%rax),%r12d
 29f4db4:	mov    %r12,0x78(%rsp)
 29f4db9:	mov    0x138(%rax),%r13d
 29f4dc0:	mov    %r13,0x70(%rsp)
 29f4dc5:	mov    0x60(%rsp),%r8
 29f4dca:	mov    %edi,0x28(%rsp)
 29f4dce:	mov    %edx,0x10(%rsp)
 29f4dd2:	mov    %esi,0x18(%rsp)
 29f4dd6:	mov    %r8d,0x20(%rsp)
 29f4ddb:	mov    0x90(%rsp),%rax
 29f4de3:	mov    (%rax),%rcx
 29f4de6:	mov    0x58(%rsp),%rax
 29f4deb:	cmp    %rax,%rcx
 29f4dee:	jae    29f533c <wasm[0]::function[1010]::helper::array_packed_push1+0x9dc>
 29f4df4:	mov    %rax,0x58(%rsp)
 29f4df9:	jmp    29f4e03 <wasm[0]::function[1010]::helper::array_packed_push1+0x4a3>
 29f4dfe:	mov    %rax,0x58(%rsp)
 29f4e03:	mov    0x28(%rsp),%eax
 29f4e07:	test   %eax,%eax
 29f4e09:	je     29f51e6 <wasm[0]::function[1010]::helper::array_packed_push1+0x886>
 29f4e0f:	mov    0x10(%rsp),%edx
 29f4e13:	mov    %rdx,%r11
 29f4e16:	mov    0x18(%rsp),%esi
 29f4e1a:	mov    0x20(%rsp),%edi
 29f4e1e:	xor    %r13d,%r13d
 29f4e21:	mov    0x60(%rsp),%rax
 29f4e26:	cmp    $0x8,%eax
 29f4e29:	jb     29f4e45 <wasm[0]::function[1010]::helper::array_packed_push1+0x4e5>
 29f4e2f:	mov    0x88(%rsp),%r12
 29f4e37:	mov    %r14,%r10
 29f4e3a:	mov    %rdi,%rdx
 29f4e3d:	mov    %r11,%rdi
 29f4e40:	jmp    29f520b <wasm[0]::function[1010]::helper::array_packed_push1+0x8ab>
 29f4e45:	mov    0x28(%rsp),%eax
 29f4e49:	xor    %edx,%edx
 29f4e4b:	test   %eax,%eax
 29f4e4d:	jne    29f4e5d <wasm[0]::function[1010]::helper::array_packed_push1+0x4fd>
 29f4e53:	mov    0x68(%rsp),%rcx
 29f4e58:	jmp    29f4ea7 <wasm[0]::function[1010]::helper::array_packed_push1+0x547>
 29f4e5d:	mov    0x28(%rsp),%eax
 29f4e61:	xor    %edx,%edx
 29f4e63:	test   $0x1,%eax
 29f4e68:	je     29f4e78 <wasm[0]::function[1010]::helper::array_packed_push1+0x518>
 29f4e6e:	mov    0x68(%rsp),%rcx
 29f4e73:	jmp    29f4ea7 <wasm[0]::function[1010]::helper::array_packed_push1+0x547>
 29f4e78:	mov    0x28(%rsp),%ecx
 29f4e7c:	mov    0x28(%rbx),%rax
 29f4e80:	mov    0x20(%rbx),%rdx
 29f4e84:	mov    %ecx,%ecx
 29f4e86:	lea    0x4(%rdx,%rcx,1),%rdx
 29f4e8b:	cmp    %rax,%rcx
 29f4e8e:	mov    0x68(%rsp),%rcx
 29f4e93:	cmova  %rcx,%rdx
 29f4e97:	mov    (%rdx),%eax
 29f4e99:	mov    0x78(%rsp),%r13
 29f4e9e:	cmp    %r13d,%eax
 29f4ea1:	sete   %al
 29f4ea4:	movzbl %al,%edx
 29f4ea7:	test   %edx,%edx
 29f4ea9:	jne    29f5098 <wasm[0]::function[1010]::helper::array_packed_push1+0x738>
 29f4eaf:	mov    0x28(%rsp),%eax
 29f4eb3:	xor    %edx,%edx
 29f4eb5:	test   %eax,%eax
 29f4eb7:	je     29f4ef8 <wasm[0]::function[1010]::helper::array_packed_push1+0x598>
 29f4ebd:	mov    0x28(%rsp),%eax
 29f4ec1:	xor    %edx,%edx
 29f4ec3:	test   $0x1,%eax
 29f4ec8:	jne    29f4ef8 <wasm[0]::function[1010]::helper::array_packed_push1+0x598>
 29f4ece:	mov    0x28(%rsp),%edx
 29f4ed2:	mov    0x28(%rbx),%rax
 29f4ed6:	mov    0x20(%rbx),%rsi
 29f4eda:	mov    %edx,%edi
 29f4edc:	lea    0x4(%rsi,%rdi,1),%rdx
 29f4ee1:	cmp    %rax,%rdi
 29f4ee4:	cmova  %rcx,%rdx
 29f4ee8:	mov    (%rdx),%eax
 29f4eea:	mov    0x70(%rsp),%r13
 29f4eef:	cmp    %r13d,%eax
 29f4ef2:	sete   %al
 29f4ef5:	movzbl %al,%edx
 29f4ef8:	mov    0x10(%rsp),%eax
 29f4efc:	mov    %rax,%r11
 29f4eff:	mov    0x18(%rsp),%esi
 29f4f03:	mov    0x20(%rsp),%edi
 29f4f07:	xor    %r13d,%r13d
 29f4f0a:	test   %edx,%edx
 29f4f0c:	jne    29f4f2d <wasm[0]::function[1010]::helper::array_packed_push1+0x5cd>
 29f4f12:	mov    %rcx,0x68(%rsp)
 29f4f17:	mov    0x88(%rsp),%r12
 29f4f1f:	mov    %r14,%r10
 29f4f22:	mov    %rdi,%rdx
 29f4f25:	mov    %r11,%rdi
 29f4f28:	jmp    29f520b <wasm[0]::function[1010]::helper::array_packed_push1+0x8ab>
 29f4f2d:	mov    0x28(%rsp),%eax
 29f4f31:	xor    %edx,%edx
 29f4f33:	test   %eax,%eax
 29f4f35:	jne    29f4f45 <wasm[0]::function[1010]::helper::array_packed_push1+0x5e5>
 29f4f3b:	mov    %rcx,0x68(%rsp)
 29f4f40:	jmp    29f4f91 <wasm[0]::function[1010]::helper::array_packed_push1+0x631>
 29f4f45:	mov    0x28(%rsp),%eax
 29f4f49:	xor    %edx,%edx
 29f4f4b:	test   $0x1,%eax
 29f4f50:	je     29f4f60 <wasm[0]::function[1010]::helper::array_packed_push1+0x600>
 29f4f56:	mov    %rcx,0x68(%rsp)
 29f4f5b:	jmp    29f4f91 <wasm[0]::function[1010]::helper::array_packed_push1+0x631>
 29f4f60:	mov    0x28(%rsp),%edi
 29f4f64:	mov    0x28(%rbx),%rsi
 29f4f68:	mov    0x20(%rbx),%r8
 29f4f6c:	mov    %edi,%edi
 29f4f6e:	lea    0x4(%r8,%rdi,1),%rdx
 29f4f73:	cmp    %rsi,%rdi
 29f4f76:	cmova  %rcx,%rdx
 29f4f7a:	mov    %rcx,0x68(%rsp)
 29f4f7f:	mov    (%rdx),%esi
 29f4f81:	mov    0x70(%rsp),%r13
 29f4f86:	cmp    %r13d,%esi
 29f4f89:	sete   %sil
 29f4f8d:	movzbl %sil,%edx
 29f4f91:	test   %edx,%edx
 29f4f93:	je     29f53ab <wasm[0]::function[1010]::helper::array_packed_push1+0xa4b>
 29f4f99:	mov    0x10(%rsp),%edx
 29f4f9d:	mov    %rdx,%r11
 29f4fa0:	mov    0x18(%rsp),%esi
 29f4fa4:	mov    0x20(%rsp),%edi
 29f4fa8:	mov    0x88(%rsp),%r15
 29f4fb0:	mov    %edx,0x30(%rsp)
 29f4fb4:	mov    %esi,0x38(%rsp)
 29f4fb8:	mov    %rdi,%rdx
 29f4fbb:	mov    %edx,0x40(%rsp)
 29f4fbf:	mov    0x90(%rsp),%rsi
 29f4fc7:	mov    (%rsi),%rax
 29f4fca:	mov    0x58(%rsp),%rcx
 29f4fcf:	cmp    %rcx,%rax
 29f4fd2:	jae    29f535b <wasm[0]::function[1010]::helper::array_packed_push1+0x9fb>
 29f4fd8:	mov    0x88(%rsp),%r12
 29f4fe0:	jmp    29f4fed <wasm[0]::function[1010]::helper::array_packed_push1+0x68d>
 29f4fe5:	mov    0x88(%rsp),%r12
 29f4fed:	lea    0x1(%r12),%rax
 29f4ff2:	cmp    %rax,%r15
 29f4ff5:	jae    29f507a <wasm[0]::function[1010]::helper::array_packed_push1+0x71a>
 29f4ffb:	xor    %r13d,%r13d
 29f4ffe:	mov    %r13,%rcx
 29f5001:	mov    %r15,%rdx
 29f5004:	mov    %r14,%rsi
 29f5007:	mov    %r14,%rdi
 29f500a:	call   2b02b20 <wasm[0]::function[1058]::helper::integer_decimal_string>
 29f500f:	test   %eax,%eax
 29f5011:	je     29f53ad <wasm[0]::function[1010]::helper::array_packed_push1+0xa4d>
 29f5017:	mov    0x28(%rsp),%edx
 29f501b:	test   %edx,%edx
 29f501d:	je     29f53af <wasm[0]::function[1010]::helper::array_packed_push1+0xa4f>
 29f5023:	mov    $0x4,%ecx
 29f5028:	mov    %rax,%r9
 29f502b:	mov    %r14,%rsi
 29f502e:	mov    %r14,%rdi
 29f5031:	mov    0x68(%rsp),%r8
 29f5036:	call   2a1cf20 <wasm[0]::function[1019]::helper::ordinary_own_descriptor>
 29f503b:	mov    %r14,%r10
 29f503e:	mov    0x30(%rsp),%edx
 29f5042:	mov    %rdx,%r11
 29f5045:	mov    0x38(%rsp),%esi
 29f5049:	mov    0x40(%rsp),%edx
 29f504d:	test   %eax,%eax
 29f504f:	je     29f505d <wasm[0]::function[1010]::helper::array_packed_push1+0x6fd>
 29f5055:	mov    %r11,%rdi
 29f5058:	jmp    29f520b <wasm[0]::function[1010]::helper::array_packed_push1+0x8ab>
 29f505d:	add    $0x1,%r15
 29f5064:	mov    %r12,0x88(%rsp)
 29f506c:	mov    %r10,%r14
 29f506f:	mov    %rdx,%rdi
 29f5072:	mov    %r11,%rdx
 29f5075:	jmp    29f4fb0 <wasm[0]::function[1010]::helper::array_packed_push1+0x650>
 29f507a:	mov    %r14,%r10
 29f507d:	mov    0x28(%rsp),%edi
 29f5081:	mov    0x30(%rsp),%edx
 29f5085:	mov    0x38(%rsp),%esi
 29f5089:	mov    0x40(%rsp),%r8d
 29f508e:	mov    0x78(%rsp),%rcx
 29f5093:	jmp    29f519c <wasm[0]::function[1010]::helper::array_packed_push1+0x83c>
 29f5098:	mov    %r14,%r10
 29f509b:	mov    0x88(%rsp),%r12
 29f50a3:	mov    %rcx,0x68(%rsp)
 29f50a8:	mov    0x28(%rsp),%eax
 29f50ac:	xor    %edx,%edx
 29f50ae:	test   %eax,%eax
 29f50b0:	jne    29f50c0 <wasm[0]::function[1010]::helper::array_packed_push1+0x760>
 29f50b6:	mov    0x78(%rsp),%rcx
 29f50bb:	jmp    29f5109 <wasm[0]::function[1010]::helper::array_packed_push1+0x7a9>
 29f50c0:	mov    0x28(%rsp),%eax
 29f50c4:	xor    %edx,%edx
 29f50c6:	test   $0x1,%eax
 29f50cb:	je     29f50db <wasm[0]::function[1010]::helper::array_packed_push1+0x77b>
 29f50d1:	mov    0x78(%rsp),%rcx
 29f50d6:	jmp    29f5109 <wasm[0]::function[1010]::helper::array_packed_push1+0x7a9>
 29f50db:	mov    0x28(%rsp),%ecx
 29f50df:	mov    0x28(%rbx),%rax
 29f50e3:	mov    0x20(%rbx),%rdx
 29f50e7:	mov    %ecx,%esi
 29f50e9:	lea    0x4(%rdx,%rsi,1),%rcx
 29f50ee:	cmp    %rax,%rsi
 29f50f1:	mov    0x68(%rsp),%rax
 29f50f6:	cmova  %rax,%rcx
 29f50fa:	mov    (%rcx),%eax
 29f50fc:	mov    0x78(%rsp),%rcx
 29f5101:	cmp    %ecx,%eax
 29f5103:	sete   %al
 29f5106:	movzbl %al,%edx
 29f5109:	test   %edx,%edx
 29f510b:	je     29f53b1 <wasm[0]::function[1010]::helper::array_packed_push1+0xa51>
 29f5111:	mov    0x28(%rsp),%esi
 29f5115:	xor    %r13d,%r13d
 29f5118:	test   %esi,%esi
 29f511a:	je     29f53b3 <wasm[0]::function[1010]::helper::array_packed_push1+0xa53>
 29f5120:	test   %esi,%esi
 29f5122:	je     29f53b5 <wasm[0]::function[1010]::helper::array_packed_push1+0xa55>
 29f5128:	mov    0x28(%rbx),%rdx
 29f512c:	mov    0x20(%rbx),%rdi
 29f5130:	mov    %esi,%eax
 29f5132:	lea    (%rdi,%rax,1),%rsi
 29f5136:	cmp    %rdx,%rax
 29f5139:	mov    0x68(%rsp),%r8
 29f513e:	cmova  %r8,%rsi
 29f5142:	mov    0x14(%rsi),%eax
 29f5145:	test   %eax,%eax
 29f5147:	je     29f53b7 <wasm[0]::function[1010]::helper::array_packed_push1+0xa57>
 29f514d:	test   %eax,%eax
 29f514f:	je     29f53b9 <wasm[0]::function[1010]::helper::array_packed_push1+0xa59>
 29f5155:	mov    %eax,%r8d
 29f5158:	lea    (%rdi,%r8,1),%rax
 29f515c:	cmp    %rdx,%r8
 29f515f:	mov    0x68(%rsp),%rdx
 29f5164:	cmova  %rdx,%rax
 29f5168:	mov    0x18(%rax),%rax
 29f516c:	mov    0x10(%rsi),%edi
 29f516f:	mov    0x10(%rsp),%edx
 29f5173:	mov    %rdx,%r11
 29f5176:	mov    0x18(%rsp),%esi
 29f517a:	mov    0x20(%rsp),%edx
 29f517e:	test   %rax,%rax
 29f5181:	je     29f518f <wasm[0]::function[1010]::helper::array_packed_push1+0x82f>
 29f5187:	mov    %r11,%rdi
 29f518a:	jmp    29f520b <wasm[0]::function[1010]::helper::array_packed_push1+0x8ab>
 29f518f:	mov    0x10(%rsp),%edx
 29f5193:	mov    0x18(%rsp),%esi
 29f5197:	mov    0x20(%rsp),%r8d
 29f519c:	test   %edi,%edi
 29f519e:	je     29f53bb <wasm[0]::function[1010]::helper::array_packed_push1+0xa5b>
 29f51a4:	mov    0x28(%rbx),%rax
 29f51a8:	mov    %edi,%r9d
 29f51ab:	mov    %r9,%rdi
 29f51ae:	add    0x20(%rbx),%rdi
 29f51b2:	cmp    %rax,%r9
 29f51b5:	mov    0x68(%rsp),%rax
 29f51ba:	cmova  %rax,%rdi
 29f51be:	mov    0x10(%rdi),%edi
 29f51c1:	mov    0x60(%rsp),%rax
 29f51c6:	add    $0x1,%eax
 29f51cc:	mov    %rax,0x60(%rsp)
 29f51d1:	mov    %r10,%r14
 29f51d4:	mov    %rcx,0x78(%rsp)
 29f51d9:	mov    %r12,0x88(%rsp)
 29f51e1:	jmp    29f4dca <wasm[0]::function[1010]::helper::array_packed_push1+0x46a>
 29f51e6:	mov    %r14,%r10
 29f51e9:	mov    0x88(%rsp),%r12
 29f51f1:	mov    0x10(%rsp),%edx
 29f51f5:	mov    %rdx,%r11
 29f51f8:	mov    0x18(%rsp),%esi
 29f51fc:	mov    0x20(%rsp),%edx
 29f5200:	mov    %r11,%rdi
 29f5203:	mov    0x80(%rsp),%r13
 29f520b:	mov    %edi,0x18(%rsp)
 29f520f:	mov    %edx,0x10(%rsp)
 29f5213:	xor    %edi,%edi
 29f5215:	test   %r13d,%r13d
 29f5218:	je     29f528d <wasm[0]::function[1010]::helper::array_packed_push1+0x92d>
 29f521e:	mov    %r11,%rax
 29f5221:	mov    %r11,%rdx
 29f5224:	test   %eax,%edx
 29f5226:	je     29f53bd <wasm[0]::function[1010]::helper::array_packed_push1+0xa5d>
 29f522c:	mov    %esi,(%rsp)
 29f522f:	mov    %r10,%rsi
 29f5232:	mov    0x48(%rsp),%r8
 29f5237:	mov    0x50(%rsp),%r9
 29f523c:	mov    %r12,%rcx
 29f523f:	mov    %rsi,%rdi
 29f5242:	call   29efe20 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data>
 29f5247:	sub    $0x10,%rsp
 29f524b:	mov    0x18(%rsp),%esi
 29f524f:	test   %esi,%esi
 29f5251:	je     29f53bf <wasm[0]::function[1010]::helper::array_packed_push1+0xa5f>
 29f5257:	test   %esi,%esi
 29f5259:	je     29f53c1 <wasm[0]::function[1010]::helper::array_packed_push1+0xa61>
 29f525f:	mov    0x28(%rbx),%r11
 29f5263:	lea    0x1(%r12),%r10
 29f5268:	mov    %esi,%eax
 29f526a:	mov    %rax,%r9
 29f526d:	add    0x20(%rbx),%r9
 29f5271:	cmp    %r11,%rax
 29f5274:	mov    0x68(%rsp),%rcx
 29f5279:	cmova  %rcx,%r9
 29f527d:	mov    %r10,0x18(%r9)
 29f5281:	mov    0x10(%rsp),%edx
 29f5285:	mov    0x80(%rsp),%rdi
 29f528d:	xor    %eax,%eax
 29f528f:	test   %edi,%edi
 29f5291:	jne    29f52a2 <wasm[0]::function[1010]::helper::array_packed_push1+0x942>
 29f5297:	mov    %rax,%rsi
 29f529a:	mov    %rax,%rdi
 29f529d:	jmp    29f52ec <wasm[0]::function[1010]::helper::array_packed_push1+0x98c>
 29f52a2:	mov    $0x3,%eax
 29f52a7:	lea    0x1(%r12),%rcx
 29f52ac:	cmp    $0x0,%rcx
 29f52b0:	jl     29f52c0 <wasm[0]::function[1010]::helper::array_packed_push1+0x960>
 29f52b6:	cvtsi2sd %rcx,%xmm0
 29f52bb:	jmp    29f52da <wasm[0]::function[1010]::helper::array_packed_push1+0x97a>
 29f52c0:	mov    %rcx,%rsi
 29f52c3:	shr    $0x1,%rsi
 29f52c7:	mov    %rcx,%rdx
 29f52ca:	and    $0x1,%rdx
 29f52ce:	or     %rsi,%rdx
 29f52d1:	cvtsi2sd %rdx,%xmm0
 29f52d6:	addsd  %xmm0,%xmm0
 29f52da:	movq   %xmm0,%rcx
 29f52df:	mov    %rcx,0x68(%rsp)
 29f52e4:	xor    %edx,%edx
 29f52e6:	mov    %rdx,%rsi
 29f52e9:	mov    %rdx,%rdi
 29f52ec:	mov    0x68(%rsp),%rcx
 29f52f1:	mov    0xa0(%rsp),%rbx
 29f52f9:	mov    0xa8(%rsp),%r12
 29f5301:	mov    0xb0(%rsp),%r13
 29f5309:	mov    0xb8(%rsp),%r14
 29f5311:	mov    0xc0(%rsp),%r15
 29f5319:	add    $0xd0,%rsp
 29f5320:	mov    %rbp,%rsp
 29f5323:	pop    %rbp
 29f5324:	ret    $0x10
 29f5327:	mov    %r10,%r14
 29f532a:	mov    %r14,%rdi
 29f532d:	call   3039b69 <wasmtime_builtin_new_epoch>
 29f5332:	mov    %rax,0x58(%rsp)
 29f5337:	jmp    29f49f1 <wasm[0]::function[1010]::helper::array_packed_push1+0x91>
 29f533c:	mov    0x8(%rbx),%rax
 29f5340:	cmp    %rax,%rcx
 29f5343:	jb     29f4dfe <wasm[0]::function[1010]::helper::array_packed_push1+0x49e>
 29f5349:	mov    %r14,%rdi
 29f534c:	call   3039b69 <wasmtime_builtin_new_epoch>
 29f5351:	mov    %rax,0x58(%rsp)
 29f5356:	jmp    29f4e03 <wasm[0]::function[1010]::helper::array_packed_push1+0x4a3>
 29f535b:	mov    0x8(%rbx),%rcx
 29f535f:	mov    %rcx,0x58(%rsp)
 29f5364:	cmp    %rcx,%rax
 29f5367:	jb     29f4fe5 <wasm[0]::function[1010]::helper::array_packed_push1+0x685>
 29f536d:	mov    %r14,%rdi
 29f5370:	call   3039b69 <wasmtime_builtin_new_epoch>
 29f5375:	mov    %rax,0x58(%rsp)
 29f537a:	mov    0x88(%rsp),%r12
 29f5382:	jmp    29f4fed <wasm[0]::function[1010]::helper::array_packed_push1+0x68d>
 29f5387:	ud2
 29f5389:	ud2
 29f538b:	ud2
 29f538d:	ud2
 29f538f:	ud2
 29f5391:	ud2
 29f5393:	ud2
 29f5395:	ud2
 29f5397:	ud2
 29f5399:	ud2
 29f539b:	ud2
 29f539d:	ud2
 29f539f:	ud2
 29f53a1:	ud2
 29f53a3:	ud2
 29f53a5:	ud2
 29f53a7:	ud2
 29f53a9:	ud2
 29f53ab:	ud2
 29f53ad:	ud2
 29f53af:	ud2
 29f53b1:	ud2
 29f53b3:	ud2
 29f53b5:	ud2
 29f53b7:	ud2
 29f53b9:	ud2
 29f53bb:	ud2
 29f53bd:	ud2
 29f53bf:	ud2
 29f53c1:	ud2
 29f53c3:	add    %al,(%rax)
 29f53c5:	add    %al,(%rax)
 29f53c7:	add    %bh,%bh
 29f53c9:	(bad)
 29f53ca:	(bad)
 29f53cb:	incl   (%rax)
 29f53cd:	add    %al,(%rax)
	...
