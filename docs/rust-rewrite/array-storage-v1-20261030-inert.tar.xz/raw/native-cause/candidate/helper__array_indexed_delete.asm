
/workspace/scriptw/target/performance-dense-numbers-20261030/native-cause/candidate/runtime-portable.elf:     file format elf64-x86-64


Disassembly of section .text:

00000000029fc9c0 <wasm[0]::function[1014]::helper::array_indexed_delete>:
 29fc9c0:	push   %rbp
 29fc9c1:	mov    %rsp,%rbp
 29fc9c4:	mov    0x8(%rdi),%r10
 29fc9c8:	mov    0x18(%r10),%r10
 29fc9cc:	add    $0xa0,%r10
 29fc9d3:	cmp    %rsp,%r10
 29fc9d6:	ja     29fe009 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1649>
 29fc9dc:	sub    $0x90,%rsp
 29fc9e3:	mov    %rbx,0x60(%rsp)
 29fc9e8:	mov    %r12,0x68(%rsp)
 29fc9ed:	mov    %r13,0x70(%rsp)
 29fc9f2:	mov    %r14,0x78(%rsp)
 29fc9f7:	mov    %r15,0x80(%rsp)
 29fc9ff:	mov    %rcx,0x38(%rsp)
 29fca04:	mov    %edx,(%rsp)
 29fca07:	mov    0x18(%rdi),%rax
 29fca0b:	mov    (%rax),%rcx
 29fca0e:	mov    %rax,0x50(%rsp)
 29fca13:	mov    0x8(%rdi),%rbx
 29fca17:	mov    %rdi,0x30(%rsp)
 29fca1c:	mov    0x8(%rbx),%rax
 29fca20:	cmp    %rax,%rcx
 29fca23:	jae    29fde8b <wasm[0]::function[1014]::helper::array_indexed_delete+0x14cb>
 29fca29:	mov    0x38(%rsp),%rcx
 29fca2e:	mov    %rax,0x48(%rsp)
 29fca33:	cmp    0x170e(%rip),%rcx        # 29fe148 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1788>
 29fca3a:	jae    29fe00b <wasm[0]::function[1014]::helper::array_indexed_delete+0x164b>
 29fca40:	mov    (%rsp),%eax
 29fca43:	test   %eax,%eax
 29fca45:	je     29fe00d <wasm[0]::function[1014]::helper::array_indexed_delete+0x164d>
 29fca4b:	test   %eax,%eax
 29fca4d:	je     29fe00f <wasm[0]::function[1014]::helper::array_indexed_delete+0x164f>
 29fca53:	mov    0x28(%rbx),%rdx
 29fca57:	mov    0x20(%rbx),%rdi
 29fca5b:	mov    %eax,%r8d
 29fca5e:	xor    %rsi,%rsi
 29fca61:	add    %r8,%rdi
 29fca64:	cmp    %rdx,%r8
 29fca67:	cmova  %rsi,%rdi
 29fca6b:	mov    0x24(%rdi),%edi
 29fca6e:	cmp    $0x3,%edi
 29fca71:	sete   %sil
 29fca75:	cmp    $0x3,%edi
 29fca78:	je     29fd2c9 <wasm[0]::function[1014]::helper::array_indexed_delete+0x909>
 29fca7e:	mov    (%rsp),%eax
 29fca81:	xor    %esi,%esi
 29fca83:	test   %eax,%eax
 29fca85:	je     29fe011 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1651>
 29fca8b:	test   %eax,%eax
 29fca8d:	je     29fe013 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1653>
 29fca93:	mov    0x28(%rbx),%r10
 29fca97:	mov    %eax,%r11d
 29fca9a:	mov    %r11,%rdi
 29fca9d:	add    0x20(%rbx),%rdi
 29fcaa1:	xor    %rdx,%rdx
 29fcaa4:	cmp    %r10,%r11
 29fcaa7:	cmova  %rdx,%rdi
 29fcaab:	mov    0x24(%rdi),%r11d
 29fcaaf:	cmp    $0x4,%r11d
 29fcab3:	je     29fcac3 <wasm[0]::function[1014]::helper::array_indexed_delete+0x103>
 29fcab9:	mov    %rcx,0x38(%rsp)
 29fcabe:	jmp    29fd048 <wasm[0]::function[1014]::helper::array_indexed_delete+0x688>
 29fcac3:	mov    (%rsp),%eax
 29fcac6:	test   %eax,%eax
 29fcac8:	je     29fe015 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1655>
 29fcace:	test   %eax,%eax
 29fcad0:	je     29fe017 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1657>
 29fcad6:	mov    0x28(%rbx),%rdx
 29fcada:	mov    0x20(%rbx),%rsi
 29fcade:	mov    %eax,%edi
 29fcae0:	add    %rdi,%rsi
 29fcae3:	xor    %r8,%r8
 29fcae6:	cmp    %rdx,%rdi
 29fcae9:	cmova  %r8,%rsi
 29fcaed:	mov    0x18(%rsi),%rsi
 29fcaf1:	cmp    %rsi,%rcx
 29fcaf4:	jb     29fcb04 <wasm[0]::function[1014]::helper::array_indexed_delete+0x144>
 29fcafa:	mov    %rcx,0x38(%rsp)
 29fcaff:	jmp    29fd043 <wasm[0]::function[1014]::helper::array_indexed_delete+0x683>
 29fcb04:	mov    (%rsp),%eax
 29fcb07:	test   %eax,%eax
 29fcb09:	je     29fe019 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1659>
 29fcb0f:	test   %eax,%eax
 29fcb11:	je     29fe01b <wasm[0]::function[1014]::helper::array_indexed_delete+0x165b>
 29fcb17:	mov    0x28(%rbx),%rdx
 29fcb1b:	mov    0x20(%rbx),%r8
 29fcb1f:	mov    %eax,%edi
 29fcb21:	lea    (%r8,%rdi,1),%rax
 29fcb25:	xor    %r8,%r8
 29fcb28:	cmp    %rdx,%rdi
 29fcb2b:	cmova  %r8,%rax
 29fcb2f:	mov    0x28(%rax),%edx
 29fcb32:	mov    0x2c(%rax),%eax
 29fcb35:	lea    0x1(%rcx),%rax
 29fcb39:	mov    %rcx,0x38(%rsp)
 29fcb3e:	cmp    %rsi,%rax
 29fcb41:	mov    %rsi,%r13
 29fcb44:	je     29fcf1a <wasm[0]::function[1014]::helper::array_indexed_delete+0x55a>
 29fcb4a:	mov    (%rsp),%eax
 29fcb4d:	test   %eax,%eax
 29fcb4f:	je     29fe01d <wasm[0]::function[1014]::helper::array_indexed_delete+0x165d>
 29fcb55:	test   %eax,%eax
 29fcb57:	je     29fe01f <wasm[0]::function[1014]::helper::array_indexed_delete+0x165f>
 29fcb5d:	mov    0x28(%rbx),%rcx
 29fcb61:	mov    %eax,%edi
 29fcb63:	mov    %rdi,%rsi
 29fcb66:	add    0x20(%rbx),%rsi
 29fcb6a:	xor    %r8,%r8
 29fcb6d:	cmp    %rcx,%rdi
 29fcb70:	cmova  %r8,%rsi
 29fcb74:	mov    0x24(%rsi),%ecx
 29fcb77:	cmp    $0x4,%ecx
 29fcb7a:	jne    29fd043 <wasm[0]::function[1014]::helper::array_indexed_delete+0x683>
 29fcb80:	test   %edx,%edx
 29fcb82:	je     29fe021 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1661>
 29fcb88:	test   %edx,%edx
 29fcb8a:	je     29fe023 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1663>
 29fcb90:	mov    0x28(%rbx),%rax
 29fcb94:	mov    0x20(%rbx),%rcx
 29fcb98:	mov    %edx,%edx
 29fcb9a:	lea    0x10(%rcx,%rdx,1),%rcx
 29fcb9f:	xor    %rsi,%rsi
 29fcba2:	cmp    %rax,%rdx
 29fcba5:	cmova  %rsi,%rcx
 29fcba9:	mov    (%rcx),%eax
 29fcbab:	lea    0x3f(%rax),%r12d
 29fcbaf:	shr    $0x6,%r12d
 29fcbb3:	mov    %r12,%rcx
 29fcbb6:	shl    $0x3,%rcx
 29fcbba:	mov    %rcx,%rax
 29fcbbd:	shr    $0x20,%rax
 29fcbc1:	mov    %rcx,0x40(%rsp)
 29fcbc6:	test   %rax,%rax
 29fcbc9:	jne    29fe025 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1665>
 29fcbcf:	mov    %r12,%rcx
 29fcbd2:	shl    $0x3,%ecx
 29fcbd5:	add    $0x18,%ecx
 29fcbd8:	jb     29fe027 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1667>
 29fcbde:	mov    0x30(%rsp),%rax
 29fcbe3:	mov    0x20(%rax),%rdi
 29fcbe7:	mov    (%rdi),%eax
 29fcbe9:	mov    %eax,%edx
 29fcbeb:	mov    %ecx,%esi
 29fcbed:	add    $0xf,%rsi
 29fcbf4:	mov    %rsi,%r8
 29fcbf7:	and    $0xfffffffffffffff0,%r8
 29fcbfb:	add    %rdx,%r8
 29fcbfe:	mov    0x4(%rdi),%r9d
 29fcc02:	cmp    %r9,%r8
 29fcc05:	ja     29fdea4 <wasm[0]::function[1014]::helper::array_indexed_delete+0x14e4>
 29fcc0b:	add    $0xf,%ecx
 29fcc11:	and    $0xfffffff0,%ecx
 29fcc14:	add    %eax,%ecx
 29fcc16:	mov    %ecx,(%rdi)
 29fcc18:	mov    0x20(%rbx),%rdi
 29fcc1c:	lea    (%rdi,%rdx,1),%rcx
 29fcc20:	movl   $0xa8000006,(%rdi,%rdx,1)
 29fcc27:	mov    0x30(%rsp),%r8
 29fcc2c:	mov    0x28(%r8),%r8
 29fcc30:	mov    0x1a4(%r8),%r8d
 29fcc37:	mov    %r8d,0x4(%rdi,%rdx,1)
 29fcc3c:	and    $0xfffffffffffffff0,%rsi
 29fcc40:	mov    %esi,0x8(%rdi,%rdx,1)
 29fcc44:	mov    %eax,0x8(%rsp)
 29fcc48:	mov    %r12d,0x10(%rcx)
 29fcc4c:	test   %eax,%eax
 29fcc4e:	je     29fe029 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1669>
 29fcc54:	mov    0x28(%rbx),%rcx
 29fcc58:	mov    0x20(%rbx),%rdx
 29fcc5c:	mov    %eax,%eax
 29fcc5e:	lea    0x10(%rdx,%rax,1),%rsi
 29fcc63:	xor    %rdi,%rdi
 29fcc66:	cmp    %rcx,%rax
 29fcc69:	cmova  %rdi,%rsi
 29fcc6d:	mov    (%rsi),%esi
 29fcc6f:	cmp    %rsi,%r12
 29fcc72:	ja     29fe02b <wasm[0]::function[1014]::helper::array_indexed_delete+0x166b>
 29fcc78:	lea    0x18(%rdx,%rax,1),%rdi
 29fcc7d:	mov    0x40(%rsp),%rsi
 29fcc82:	mov    %rdi,%rax
 29fcc85:	add    %rsi,%rax
 29fcc88:	mov    %rdi,%r12
 29fcc8b:	jb     29fe02d <wasm[0]::function[1014]::helper::array_indexed_delete+0x166d>
 29fcc91:	add    %rdx,%rcx
 29fcc94:	cmp    %rcx,%rax
 29fcc97:	ja     29fe02f <wasm[0]::function[1014]::helper::array_indexed_delete+0x166f>
 29fcc9d:	mov    (%rsp),%eax
 29fcca0:	cmp    $0x8000000,%rsi
 29fcca7:	ja     29fccb7 <wasm[0]::function[1014]::helper::array_indexed_delete+0x2f7>
 29fccad:	mov    0x50(%rsp),%r15
 29fccb2:	jmp    29fcd2d <wasm[0]::function[1014]::helper::array_indexed_delete+0x36d>
 29fccb7:	mov    %eax,0x20(%rsp)
 29fccbb:	mov    0x50(%rsp),%r15
 29fccc0:	mov    (%r15),%rsi
 29fccc3:	mov    0x48(%rsp),%rax
 29fccc8:	cmp    %rax,%rsi
 29fcccb:	jae    29fded3 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1513>
 29fccd1:	mov    %rax,0x48(%rsp)
 29fccd6:	jmp    29fcce0 <wasm[0]::function[1014]::helper::array_indexed_delete+0x320>
 29fccdb:	mov    %rax,0x48(%rsp)
 29fcce0:	xor    %edx,%edx
 29fcce2:	mov    $0x8000000,%ecx
 29fcce7:	mov    %r12,%rsi
 29fccea:	mov    0x30(%rsp),%rdi
 29fccef:	call   3039b13 <wasmtime_builtin_memory_fill>
 29fccf4:	mov    0x20(%rsp),%eax
 29fccf8:	mov    0x40(%rsp),%rcx
 29fccfd:	sub    $0x8000000,%rcx
 29fcd04:	mov    %r12,%rsi
 29fcd07:	mov    %rcx,0x40(%rsp)
 29fcd0c:	add    $0x8000000,%rsi
 29fcd13:	mov    %rsi,%r12
 29fcd16:	cmp    $0x8000000,%rcx
 29fcd1d:	jbe    29fcd2d <wasm[0]::function[1014]::helper::array_indexed_delete+0x36d>
 29fcd23:	mov    %r15,0x50(%rsp)
 29fcd28:	jmp    29fccb7 <wasm[0]::function[1014]::helper::array_indexed_delete+0x2f7>
 29fcd2d:	mov    %eax,0x20(%rsp)
 29fcd31:	mov    (%r15),%rax
 29fcd34:	mov    0x48(%rsp),%r10
 29fcd39:	cmp    %r10,%rax
 29fcd3c:	jae    29fdef4 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1534>
 29fcd42:	xor    %r14d,%r14d
 29fcd45:	mov    0x40(%rsp),%rcx
 29fcd4a:	mov    %r12,%rsi
 29fcd4d:	mov    %r14,%rdx
 29fcd50:	mov    0x30(%rsp),%rdi
 29fcd55:	call   3039b13 <wasmtime_builtin_memory_fill>
 29fcd5a:	mov    0x20(%rsp),%ecx
 29fcd5e:	mov    %r13,%rsi
 29fcd61:	mov    %rsi,%r12
 29fcd64:	shr    $0x6,%r12
 29fcd68:	mov    %rsi,%r13
 29fcd6b:	mov    %ecx,0x20(%rsp)
 29fcd6f:	mov    (%r15),%rcx
 29fcd72:	mov    0x48(%rsp),%rax
 29fcd77:	mov    %r15,0x50(%rsp)
 29fcd7c:	cmp    %rax,%rcx
 29fcd7f:	jae    29fdf1a <wasm[0]::function[1014]::helper::array_indexed_delete+0x155a>
 29fcd85:	cmp    %r12d,%r14d
 29fcd88:	jae    29fce2c <wasm[0]::function[1014]::helper::array_indexed_delete+0x46c>
 29fcd8e:	mov    0x8(%rsp),%ecx
 29fcd92:	test   %ecx,%ecx
 29fcd94:	je     29fe031 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1671>
 29fcd9a:	test   %ecx,%ecx
 29fcd9c:	je     29fe033 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1673>
 29fcda2:	mov    0x28(%rbx),%rdx
 29fcda6:	mov    0x20(%rbx),%rsi
 29fcdaa:	mov    %ecx,%r9d
 29fcdad:	lea    0x10(%rsi,%r9,1),%r8
 29fcdb2:	xor    %rdi,%rdi
 29fcdb5:	cmp    %rdx,%r9
 29fcdb8:	cmova  %rdi,%r8
 29fcdbc:	mov    (%r8),%r8d
 29fcdbf:	cmp    %r8d,%r14d
 29fcdc2:	jae    29fe035 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1675>
 29fcdc8:	mov    %r8d,%r9d
 29fcdcb:	shl    $0x3,%r9
 29fcdcf:	shr    $0x20,%r9
 29fcdd3:	test   %r9,%r9
 29fcdd6:	jne    29fe037 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1677>
 29fcddc:	shl    $0x3,%r8d
 29fcde0:	add    $0x18,%r8d
 29fcde4:	jb     29fe039 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1679>
 29fcdea:	add    %r8d,%ecx
 29fcded:	jb     29fe03b <wasm[0]::function[1014]::helper::array_indexed_delete+0x167b>
 29fcdf3:	mov    %ecx,%r9d
 29fcdf6:	lea    (%rsi,%r9,1),%rcx
 29fcdfa:	cmp    %rdx,%r9
 29fcdfd:	cmova  %rdi,%rcx
 29fce01:	mov    %r14,%rax
 29fce04:	shl    $0x3,%eax
 29fce07:	lea    0x18(%rax),%edx
 29fce0a:	sub    %edx,%r8d
 29fce0d:	sub    %r8,%rcx
 29fce10:	movq   $0xffffffffffffffff,(%rcx)
 29fce17:	mov    0x20(%rsp),%ecx
 29fce1b:	add    $0x1,%r14d
 29fce22:	mov    0x50(%rsp),%r15
 29fce27:	jmp    29fcd6b <wasm[0]::function[1014]::helper::array_indexed_delete+0x3ab>
 29fce2c:	mov    %r13,%rcx
 29fce2f:	test   $0x3f,%rcx
 29fce36:	je     29fced1 <wasm[0]::function[1014]::helper::array_indexed_delete+0x511>
 29fce3c:	mov    0x8(%rsp),%edx
 29fce40:	test   %edx,%edx
 29fce42:	je     29fe03d <wasm[0]::function[1014]::helper::array_indexed_delete+0x167d>
 29fce48:	test   %edx,%edx
 29fce4a:	je     29fe03f <wasm[0]::function[1014]::helper::array_indexed_delete+0x167f>
 29fce50:	mov    0x28(%rbx),%rsi
 29fce54:	mov    0x20(%rbx),%rdi
 29fce58:	mov    %edx,%r10d
 29fce5b:	lea    0x10(%rdi,%r10,1),%r9
 29fce60:	xor    %r8,%r8
 29fce63:	cmp    %rsi,%r10
 29fce66:	cmova  %r8,%r9
 29fce6a:	mov    (%r9),%r9d
 29fce6d:	cmp    %r9d,%r12d
 29fce70:	jae    29fe041 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1681>
 29fce76:	mov    %r9d,%r10d
 29fce79:	shl    $0x3,%r10
 29fce7d:	shr    $0x20,%r10
 29fce81:	test   %r10,%r10
 29fce84:	jne    29fe043 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1683>
 29fce8a:	shl    $0x3,%r9d
 29fce8e:	add    $0x18,%r9d
 29fce92:	jb     29fe045 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1685>
 29fce98:	add    %r9d,%edx
 29fce9b:	jb     29fe047 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1687>
 29fcea1:	mov    $0x1,%r10d
 29fcea7:	and    $0x3f,%rcx
 29fceab:	shl    %cl,%r10
 29fceae:	sub    $0x1,%r10
 29fceb2:	mov    %edx,%edx
 29fceb4:	lea    (%rdi,%rdx,1),%rcx
 29fceb8:	cmp    %rsi,%rdx
 29fcebb:	cmova  %r8,%rcx
 29fcebf:	shl    $0x3,%r12d
 29fcec3:	lea    0x18(%r12),%esi
 29fcec8:	sub    %esi,%r9d
 29fcecb:	sub    %r9,%rcx
 29fcece:	mov    %r10,(%rcx)
 29fced1:	mov    0x20(%rsp),%eax
 29fced5:	test   %eax,%eax
 29fced7:	je     29fe049 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1689>
 29fcedd:	mov    0x8(%rsp),%edi
 29fcee1:	test   %edi,%edi
 29fcee3:	je     29fe04b <wasm[0]::function[1014]::helper::array_indexed_delete+0x168b>
 29fcee9:	test   %eax,%eax
 29fceeb:	je     29fe04d <wasm[0]::function[1014]::helper::array_indexed_delete+0x168d>
 29fcef1:	mov    0x28(%rbx),%r11
 29fcef5:	mov    0x20(%rbx),%rdx
 29fcef9:	mov    %eax,%ecx
 29fcefb:	lea    (%rdx,%rcx,1),%r8
 29fceff:	xor    %rdx,%rdx
 29fcf02:	cmp    %r11,%rcx
 29fcf05:	cmova  %rdx,%r8
 29fcf09:	mov    %edi,0x2c(%r8)
 29fcf0d:	movl   $0x2,0x24(%r8)
 29fcf15:	jmp    29fd043 <wasm[0]::function[1014]::helper::array_indexed_delete+0x683>
 29fcf1a:	mov    %r13,%rcx
 29fcf1d:	mov    (%rsp),%edi
 29fcf20:	test   %edi,%edi
 29fcf22:	je     29fe04f <wasm[0]::function[1014]::helper::array_indexed_delete+0x168f>
 29fcf28:	test   %edi,%edi
 29fcf2a:	je     29fe051 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1691>
 29fcf30:	mov    0x28(%rbx),%rax
 29fcf34:	mov    0x20(%rbx),%rsi
 29fcf38:	mov    %rcx,%r8
 29fcf3b:	sub    $0x1,%r8
 29fcf3f:	mov    %edi,%r10d
 29fcf42:	lea    (%rsi,%r10,1),%r9
 29fcf46:	xor    %rdi,%rdi
 29fcf49:	cmp    %rax,%r10
 29fcf4c:	cmova  %rdi,%r9
 29fcf50:	mov    %r8,0x18(%r9)
 29fcf54:	test   %edx,%edx
 29fcf56:	je     29fe053 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1693>
 29fcf5c:	test   %edx,%edx
 29fcf5e:	je     29fe055 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1695>
 29fcf64:	mov    %edx,%r9d
 29fcf67:	lea    0x10(%rsi,%r9,1),%r8
 29fcf6c:	cmp    %rax,%r9
 29fcf6f:	cmova  %rdi,%r8
 29fcf73:	mov    (%r8),%r8d
 29fcf76:	mov    0x38(%rsp),%r9
 29fcf7b:	cmp    %r8d,%r9d
 29fcf7e:	jae    29fe057 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1697>
 29fcf84:	mov    %r8d,%r9d
 29fcf87:	shl    $0x3,%r9
 29fcf8b:	shr    $0x20,%r9
 29fcf8f:	test   %r9,%r9
 29fcf92:	jne    29fe059 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1699>
 29fcf98:	shl    $0x3,%r8d
 29fcf9c:	add    $0x18,%r8d
 29fcfa0:	jb     29fe05b <wasm[0]::function[1014]::helper::array_indexed_delete+0x169b>
 29fcfa6:	add    %r8d,%edx
 29fcfa9:	jb     29fe05d <wasm[0]::function[1014]::helper::array_indexed_delete+0x169d>
 29fcfaf:	mov    %edx,%r9d
 29fcfb2:	lea    (%rsi,%r9,1),%rdx
 29fcfb6:	cmp    %rax,%r9
 29fcfb9:	cmova  %rdi,%rdx
 29fcfbd:	mov    0x38(%rsp),%rax
 29fcfc2:	shl    $0x3,%eax
 29fcfc5:	add    $0x18,%eax
 29fcfcb:	sub    %eax,%r8d
 29fcfce:	sub    %r8,%rdx
 29fcfd1:	movq   $0x0,(%rdx)
 29fcfd8:	cmp    $0x1,%rcx
 29fcfdc:	jne    29fd040 <wasm[0]::function[1014]::helper::array_indexed_delete+0x680>
 29fcfe2:	mov    0x30(%rsp),%rcx
 29fcfe7:	mov    0xa00(%rcx),%ecx
 29fcfed:	mov    0x30(%rsp),%rax
 29fcff2:	mov    0xa10(%rax),%eax
 29fcff8:	mov    (%rsp),%edx
 29fcffb:	test   %edx,%edx
 29fcffd:	je     29fe05f <wasm[0]::function[1014]::helper::array_indexed_delete+0x169f>
 29fd003:	test   %ecx,%ecx
 29fd005:	je     29fe061 <wasm[0]::function[1014]::helper::array_indexed_delete+0x16a1>
 29fd00b:	test   %edx,%edx
 29fd00d:	je     29fe063 <wasm[0]::function[1014]::helper::array_indexed_delete+0x16a3>
 29fd013:	mov    0x28(%rbx),%rsi
 29fd017:	mov    0x20(%rbx),%r8
 29fd01b:	mov    %edx,%edi
 29fd01d:	lea    (%r8,%rdi,1),%rdx
 29fd021:	xor    %r8,%r8
 29fd024:	cmp    %rsi,%rdi
 29fd027:	cmova  %r8,%rdx
 29fd02b:	mov    %ecx,0x28(%rdx)
 29fd02e:	test   %eax,%eax
 29fd030:	je     29fe065 <wasm[0]::function[1014]::helper::array_indexed_delete+0x16a5>
 29fd036:	mov    %eax,0x2c(%rdx)
 29fd039:	movl   $0x0,0x30(%rdx)
 29fd040:	mov    (%rsp),%eax
 29fd043:	mov    $0x1,%esi
 29fd048:	test   %eax,%eax
 29fd04a:	je     29fe067 <wasm[0]::function[1014]::helper::array_indexed_delete+0x16a7>
 29fd050:	test   %eax,%eax
 29fd052:	je     29fe069 <wasm[0]::function[1014]::helper::array_indexed_delete+0x16a9>
 29fd058:	mov    0x28(%rbx),%rdx
 29fd05c:	mov    %eax,%r14d
 29fd05f:	mov    %r14,%rdi
 29fd062:	add    0x20(%rbx),%rdi
 29fd066:	xor    %rcx,%rcx
 29fd069:	cmp    %rdx,%r14
 29fd06c:	cmova  %rcx,%rdi
 29fd070:	mov    0x24(%rdi),%ecx
 29fd073:	cmp    $0x2,%ecx
 29fd076:	jne    29fd4c2 <wasm[0]::function[1014]::helper::array_indexed_delete+0xb02>
 29fd07c:	mov    0x28(%rbx),%r8
 29fd080:	mov    0x20(%rbx),%r10
 29fd084:	lea    (%r10,%r14,1),%rdx
 29fd088:	xor    %r9,%r9
 29fd08b:	cmp    %r8,%r14
 29fd08e:	mov    %r14,0x40(%rsp)
 29fd093:	cmova  %r9,%rdx
 29fd097:	mov    0x28(%rdx),%esi
 29fd09a:	mov    0x2c(%rdx),%edx
 29fd09d:	test   %esi,%esi
 29fd09f:	je     29fe06b <wasm[0]::function[1014]::helper::array_indexed_delete+0x16ab>
 29fd0a5:	test   %esi,%esi
 29fd0a7:	je     29fe06d <wasm[0]::function[1014]::helper::array_indexed_delete+0x16ad>
 29fd0ad:	mov    %esi,%edi
 29fd0af:	lea    0x10(%r10,%rdi,1),%r10
 29fd0b4:	cmp    %r8,%rdi
 29fd0b7:	cmova  %r9,%r10
 29fd0bb:	mov    (%r10),%r8d
 29fd0be:	mov    0x38(%rsp),%rcx
 29fd0c3:	cmp    %r8,%rcx
 29fd0c6:	jae    29fd2bf <wasm[0]::function[1014]::helper::array_indexed_delete+0x8ff>
 29fd0cc:	test   %edx,%edx
 29fd0ce:	je     29fe06f <wasm[0]::function[1014]::helper::array_indexed_delete+0x16af>
 29fd0d4:	test   %edx,%edx
 29fd0d6:	je     29fe071 <wasm[0]::function[1014]::helper::array_indexed_delete+0x16b1>
 29fd0dc:	mov    0x28(%rbx),%r8
 29fd0e0:	mov    0x20(%rbx),%r9
 29fd0e4:	mov    %edx,%r11d
 29fd0e7:	lea    0x10(%r9,%r11,1),%r12
 29fd0ec:	xor    %r10,%r10
 29fd0ef:	cmp    %r8,%r11
 29fd0f2:	cmova  %r10,%r12
 29fd0f6:	mov    (%r12),%r12d
 29fd0fa:	mov    0x38(%rsp),%rcx
 29fd0ff:	mov    %rcx,%r15
 29fd102:	shr    $0x6,%r15d
 29fd106:	cmp    %r12d,%r15d
 29fd109:	jae    29fe073 <wasm[0]::function[1014]::helper::array_indexed_delete+0x16b3>
 29fd10f:	mov    %r12d,%ecx
 29fd112:	shl    $0x3,%rcx
 29fd116:	shr    $0x20,%rcx
 29fd11a:	test   %rcx,%rcx
 29fd11d:	jne    29fe075 <wasm[0]::function[1014]::helper::array_indexed_delete+0x16b5>
 29fd123:	shl    $0x3,%r12d
 29fd127:	add    $0x18,%r12d
 29fd12b:	jb     29fe077 <wasm[0]::function[1014]::helper::array_indexed_delete+0x16b7>
 29fd131:	mov    %rdx,%rcx
 29fd134:	add    %r12d,%ecx
 29fd137:	jb     29fe079 <wasm[0]::function[1014]::helper::array_indexed_delete+0x16b9>
 29fd13d:	mov    %ecx,%ecx
 29fd13f:	add    %rcx,%r9
 29fd142:	cmp    %r8,%rcx
 29fd145:	cmova  %r10,%r9
 29fd149:	mov    %r15,%r14
 29fd14c:	shl    $0x3,%r14d
 29fd150:	lea    0x18(%r14),%ecx
 29fd154:	sub    %ecx,%r12d
 29fd157:	sub    %r12,%r9
 29fd15a:	mov    (%r9),%r12
 29fd15d:	mov    $0x1,%r13d
 29fd163:	mov    0x38(%rsp),%rcx
 29fd168:	shl    %cl,%r13
 29fd16b:	bt     %rcx,%r12
 29fd16f:	jae    29fd2bf <wasm[0]::function[1014]::helper::array_indexed_delete+0x8ff>
 29fd175:	mov    0x28(%rbx),%r8
 29fd179:	mov    0x20(%rbx),%r10
 29fd17d:	lea    0x10(%r10,%r11,1),%rcx
 29fd182:	xor    %r9,%r9
 29fd185:	cmp    %r8,%r11
 29fd188:	cmova  %r9,%rcx
 29fd18c:	mov    (%rcx),%r11d
 29fd18f:	cmp    %r11d,%r15d
 29fd192:	jae    29fe07b <wasm[0]::function[1014]::helper::array_indexed_delete+0x16bb>
 29fd198:	mov    %r11d,%ecx
 29fd19b:	shl    $0x3,%rcx
 29fd19f:	shr    $0x20,%rcx
 29fd1a3:	test   %rcx,%rcx
 29fd1a6:	jne    29fe07d <wasm[0]::function[1014]::helper::array_indexed_delete+0x16bd>
 29fd1ac:	shl    $0x3,%r11d
 29fd1b0:	add    $0x18,%r11d
 29fd1b4:	jb     29fe07f <wasm[0]::function[1014]::helper::array_indexed_delete+0x16bf>
 29fd1ba:	add    %r11d,%edx
 29fd1bd:	jb     29fe081 <wasm[0]::function[1014]::helper::array_indexed_delete+0x16c1>
 29fd1c3:	not    %r13
 29fd1c6:	and    %r13,%r12
 29fd1c9:	mov    %edx,%ecx
 29fd1cb:	lea    (%r10,%rcx,1),%rdx
 29fd1cf:	cmp    %r8,%rcx
 29fd1d2:	cmova  %r9,%rdx
 29fd1d6:	lea    0x18(%r14),%ecx
 29fd1da:	sub    %ecx,%r11d
 29fd1dd:	sub    %r11,%rdx
 29fd1e0:	mov    %r12,(%rdx)
 29fd1e3:	lea    0x10(%r10,%rdi,1),%rcx
 29fd1e8:	cmp    %r8,%rdi
 29fd1eb:	cmova  %r9,%rcx
 29fd1ef:	mov    (%rcx),%edx
 29fd1f1:	mov    0x38(%rsp),%rcx
 29fd1f6:	cmp    %edx,%ecx
 29fd1f8:	jae    29fe083 <wasm[0]::function[1014]::helper::array_indexed_delete+0x16c3>
 29fd1fe:	mov    %edx,%ecx
 29fd200:	shl    $0x3,%rcx
 29fd204:	shr    $0x20,%rcx
 29fd208:	test   %rcx,%rcx
 29fd20b:	jne    29fe085 <wasm[0]::function[1014]::helper::array_indexed_delete+0x16c5>
 29fd211:	shl    $0x3,%edx
 29fd214:	add    $0x18,%edx
 29fd217:	jb     29fe087 <wasm[0]::function[1014]::helper::array_indexed_delete+0x16c7>
 29fd21d:	add    %edx,%esi
 29fd21f:	jb     29fe089 <wasm[0]::function[1014]::helper::array_indexed_delete+0x16c9>
 29fd225:	mov    %esi,%ecx
 29fd227:	lea    (%r10,%rcx,1),%rsi
 29fd22b:	cmp    %r8,%rcx
 29fd22e:	cmova  %r9,%rsi
 29fd232:	mov    0x38(%rsp),%rcx
 29fd237:	shl    $0x3,%ecx
 29fd23a:	add    $0x18,%ecx
 29fd240:	sub    %ecx,%edx
 29fd242:	sub    %rdx,%rsi
 29fd245:	movq   $0x0,(%rsi)
 29fd24c:	mov    0x40(%rsp),%r14
 29fd251:	lea    (%r10,%r14,1),%rcx
 29fd255:	cmp    %r8,%r14
 29fd258:	cmova  %r9,%rcx
 29fd25c:	mov    0x18(%rcx),%rdx
 29fd260:	mov    %rdx,%rsi
 29fd263:	sub    $0x1,%rsi
 29fd267:	mov    %rsi,0x18(%rcx)
 29fd26b:	cmp    $0x1,%rdx
 29fd26f:	jne    29fd2bf <wasm[0]::function[1014]::helper::array_indexed_delete+0x8ff>
 29fd275:	mov    0x30(%rsp),%rcx
 29fd27a:	mov    0xa00(%rcx),%esi
 29fd280:	mov    0xa10(%rcx),%edx
 29fd286:	test   %esi,%esi
 29fd288:	je     29fe08b <wasm[0]::function[1014]::helper::array_indexed_delete+0x16cb>
 29fd28e:	mov    0x28(%rbx),%rcx
 29fd292:	mov    0x20(%rbx),%rdi
 29fd296:	add    %r14,%rdi
 29fd299:	xor    %r8,%r8
 29fd29c:	cmp    %rcx,%r14
 29fd29f:	cmova  %r8,%rdi
 29fd2a3:	mov    %esi,0x28(%rdi)
 29fd2a6:	test   %edx,%edx
 29fd2a8:	je     29fe08d <wasm[0]::function[1014]::helper::array_indexed_delete+0x16cd>
 29fd2ae:	mov    %edx,0x2c(%rdi)
 29fd2b1:	movl   $0x0,0x30(%rdi)
 29fd2b8:	movl   $0x4,0x24(%rdi)
 29fd2bf:	mov    $0x1,%esi
 29fd2c4:	jmp    29fd4c2 <wasm[0]::function[1014]::helper::array_indexed_delete+0xb02>
 29fd2c9:	mov    %rcx,0x38(%rsp)
 29fd2ce:	mov    (%rsp),%eax
 29fd2d1:	test   %eax,%eax
 29fd2d3:	je     29fe08f <wasm[0]::function[1014]::helper::array_indexed_delete+0x16cf>
 29fd2d9:	test   %eax,%eax
 29fd2db:	je     29fe091 <wasm[0]::function[1014]::helper::array_indexed_delete+0x16d1>
 29fd2e1:	mov    0x28(%rbx),%rcx
 29fd2e5:	mov    0x20(%rbx),%rdx
 29fd2e9:	mov    %eax,%edi
 29fd2eb:	lea    (%rdx,%rdi,1),%rax
 29fd2ef:	xor    %r8,%r8
 29fd2f2:	cmp    %rcx,%rdi
 29fd2f5:	cmova  %r8,%rax
 29fd2f9:	mov    0x30(%rax),%eax
 29fd2fc:	test   %eax,%eax
 29fd2fe:	je     29fe093 <wasm[0]::function[1014]::helper::array_indexed_delete+0x16d3>
 29fd304:	test   %eax,%eax
 29fd306:	je     29fe095 <wasm[0]::function[1014]::helper::array_indexed_delete+0x16d5>
 29fd30c:	mov    %eax,%edi
 29fd30e:	lea    0x10(%rdx,%rdi,1),%r9
 29fd313:	cmp    %rcx,%rdi
 29fd316:	cmova  %r8,%r9
 29fd31a:	mov    (%r9),%r8d
 29fd31d:	mov    0x38(%rsp),%rcx
 29fd322:	cmp    %r8,%rcx
 29fd325:	jae    29fd4bb <wasm[0]::function[1014]::helper::array_indexed_delete+0xafb>
 29fd32b:	mov    0x28(%rbx),%r10
 29fd32f:	mov    0x20(%rbx),%rdx
 29fd333:	lea    0x10(%rdx,%rdi,1),%r8
 29fd338:	xor    %r11,%r11
 29fd33b:	cmp    %r10,%rdi
 29fd33e:	cmova  %r11,%r8
 29fd342:	mov    (%r8),%ecx
 29fd345:	mov    0x38(%rsp),%r8
 29fd34a:	cmp    %ecx,%r8d
 29fd34d:	jae    29fe097 <wasm[0]::function[1014]::helper::array_indexed_delete+0x16d7>
 29fd353:	mov    %ecx,%r8d
 29fd356:	shl    $0x2,%r8
 29fd35a:	shr    $0x20,%r8
 29fd35e:	test   %r8,%r8
 29fd361:	jne    29fe099 <wasm[0]::function[1014]::helper::array_indexed_delete+0x16d9>
 29fd367:	shl    $0x2,%ecx
 29fd36a:	add    $0x14,%ecx
 29fd36d:	jb     29fe09b <wasm[0]::function[1014]::helper::array_indexed_delete+0x16db>
 29fd373:	mov    %rax,%r8
 29fd376:	add    %ecx,%r8d
 29fd379:	jb     29fe09d <wasm[0]::function[1014]::helper::array_indexed_delete+0x16dd>
 29fd37f:	mov    %r8d,%r8d
 29fd382:	add    %r8,%rdx
 29fd385:	cmp    %r10,%r8
 29fd388:	cmova  %r11,%rdx
 29fd38c:	mov    0x38(%rsp),%r8
 29fd391:	mov    %r8,%r9
 29fd394:	shl    $0x2,%r9d
 29fd398:	lea    0x14(%r9),%r8d
 29fd39c:	sub    %r8d,%ecx
 29fd39f:	sub    %rcx,%rdx
 29fd3a2:	mov    (%rdx),%ecx
 29fd3a4:	test   %ecx,%ecx
 29fd3a6:	je     29fd4bb <wasm[0]::function[1014]::helper::array_indexed_delete+0xafb>
 29fd3ac:	mov    0x28(%rbx),%rcx
 29fd3b0:	mov    0x20(%rbx),%r8
 29fd3b4:	lea    0x10(%r8,%rdi,1),%r10
 29fd3b9:	xor    %rdx,%rdx
 29fd3bc:	cmp    %rcx,%rdi
 29fd3bf:	cmova  %rdx,%r10
 29fd3c3:	mov    (%r10),%r11d
 29fd3c6:	mov    0x38(%rsp),%rdi
 29fd3cb:	cmp    %r11d,%edi
 29fd3ce:	jae    29fe09f <wasm[0]::function[1014]::helper::array_indexed_delete+0x16df>
 29fd3d4:	mov    %r11d,%edi
 29fd3d7:	shl    $0x2,%rdi
 29fd3db:	shr    $0x20,%rdi
 29fd3df:	test   %rdi,%rdi
 29fd3e2:	jne    29fe0a1 <wasm[0]::function[1014]::helper::array_indexed_delete+0x16e1>
 29fd3e8:	shl    $0x2,%r11d
 29fd3ec:	add    $0x14,%r11d
 29fd3f0:	jb     29fe0a3 <wasm[0]::function[1014]::helper::array_indexed_delete+0x16e3>
 29fd3f6:	add    %r11d,%eax
 29fd3f9:	jb     29fe0a5 <wasm[0]::function[1014]::helper::array_indexed_delete+0x16e5>
 29fd3ff:	mov    %eax,%edi
 29fd401:	lea    (%r8,%rdi,1),%rax
 29fd405:	cmp    %rcx,%rdi
 29fd408:	cmova  %rdx,%rax
 29fd40c:	lea    0x14(%r9),%edi
 29fd410:	sub    %edi,%r11d
 29fd413:	sub    %r11,%rax
 29fd416:	movl   $0x0,(%rax)
 29fd41c:	mov    (%rsp),%eax
 29fd41f:	test   %eax,%eax
 29fd421:	je     29fe0a7 <wasm[0]::function[1014]::helper::array_indexed_delete+0x16e7>
 29fd427:	test   %eax,%eax
 29fd429:	je     29fe0a9 <wasm[0]::function[1014]::helper::array_indexed_delete+0x16e9>
 29fd42f:	mov    %eax,%edi
 29fd431:	lea    (%r8,%rdi,1),%rax
 29fd435:	cmp    %rcx,%rdi
 29fd438:	cmova  %rdx,%rax
 29fd43c:	mov    0x18(%rax),%rcx
 29fd440:	mov    %rcx,%rdx
 29fd443:	sub    $0x1,%rdx
 29fd447:	mov    %rdx,0x18(%rax)
 29fd44b:	cmp    $0x1,%rcx
 29fd44f:	jne    29fd4bb <wasm[0]::function[1014]::helper::array_indexed_delete+0xafb>
 29fd455:	mov    0x30(%rsp),%rcx
 29fd45a:	mov    0xa00(%rcx),%ecx
 29fd460:	mov    0x30(%rsp),%rax
 29fd465:	mov    0xa10(%rax),%eax
 29fd46b:	mov    (%rsp),%edx
 29fd46e:	test   %edx,%edx
 29fd470:	je     29fe0ab <wasm[0]::function[1014]::helper::array_indexed_delete+0x16eb>
 29fd476:	test   %ecx,%ecx
 29fd478:	je     29fe0ad <wasm[0]::function[1014]::helper::array_indexed_delete+0x16ed>
 29fd47e:	test   %edx,%edx
 29fd480:	je     29fe0af <wasm[0]::function[1014]::helper::array_indexed_delete+0x16ef>
 29fd486:	mov    0x28(%rbx),%rdi
 29fd48a:	mov    0x20(%rbx),%r9
 29fd48e:	mov    %edx,%r8d
 29fd491:	lea    (%r9,%r8,1),%rdx
 29fd495:	xor    %r9,%r9
 29fd498:	cmp    %rdi,%r8
 29fd49b:	cmova  %r9,%rdx
 29fd49f:	mov    %ecx,0x28(%rdx)
 29fd4a2:	test   %eax,%eax
 29fd4a4:	je     29fe0b1 <wasm[0]::function[1014]::helper::array_indexed_delete+0x16f1>
 29fd4aa:	mov    %eax,0x2c(%rdx)
 29fd4ad:	movl   $0x0,0x30(%rdx)
 29fd4b4:	movl   $0x4,0x24(%rdx)
 29fd4bb:	mov    (%rsp),%eax
 29fd4be:	movzbl %sil,%esi
 29fd4c2:	mov    %eax,(%rsp)
 29fd4c5:	test   %esi,%esi
 29fd4c7:	jne    29fd6ca <wasm[0]::function[1014]::helper::array_indexed_delete+0xd0a>
 29fd4cd:	test   %eax,%eax
 29fd4cf:	je     29fe0b3 <wasm[0]::function[1014]::helper::array_indexed_delete+0x16f3>
 29fd4d5:	test   %eax,%eax
 29fd4d7:	je     29fe0b5 <wasm[0]::function[1014]::helper::array_indexed_delete+0x16f5>
 29fd4dd:	mov    0x28(%rbx),%rcx
 29fd4e1:	mov    0x20(%rbx),%rsi
 29fd4e5:	mov    %eax,%edx
 29fd4e7:	lea    (%rsi,%rdx,1),%rax
 29fd4eb:	xor    %rsi,%rsi
 29fd4ee:	cmp    %rcx,%rdx
 29fd4f1:	cmova  %rsi,%rax
 29fd4f5:	mov    0x24(%rax),%edx
 29fd4f8:	test   %edx,%edx
 29fd4fa:	sete   %sil
 29fd4fe:	test   %edx,%edx
 29fd500:	jne    29fd6c6 <wasm[0]::function[1014]::helper::array_indexed_delete+0xd06>
 29fd506:	mov    (%rsp),%edi
 29fd509:	test   %edi,%edi
 29fd50b:	je     29fe0b7 <wasm[0]::function[1014]::helper::array_indexed_delete+0x16f7>
 29fd511:	test   %edi,%edi
 29fd513:	je     29fe0b9 <wasm[0]::function[1014]::helper::array_indexed_delete+0x16f9>
 29fd519:	mov    0x28(%rbx),%r10
 29fd51d:	mov    0x20(%rbx),%r11
 29fd521:	mov    %edi,%eax
 29fd523:	lea    (%r11,%rax,1),%rdi
 29fd527:	xor    %rdx,%rdx
 29fd52a:	cmp    %r10,%rax
 29fd52d:	cmova  %rdx,%rdi
 29fd531:	mov    0x20(%rdi),%eax
 29fd534:	test   %eax,%eax
 29fd536:	je     29fe0bb <wasm[0]::function[1014]::helper::array_indexed_delete+0x16fb>
 29fd53c:	test   %eax,%eax
 29fd53e:	je     29fe0bd <wasm[0]::function[1014]::helper::array_indexed_delete+0x16fd>
 29fd544:	mov    %eax,%ecx
 29fd546:	lea    0x10(%r11,%rcx,1),%rdi
 29fd54b:	cmp    %r10,%rcx
 29fd54e:	cmova  %rdx,%rdi
 29fd552:	mov    (%rdi),%edx
 29fd554:	mov    0x38(%rsp),%rdi
 29fd559:	cmp    %rdx,%rdi
 29fd55c:	jae    29fd6c6 <wasm[0]::function[1014]::helper::array_indexed_delete+0xd06>
 29fd562:	mov    0x28(%rbx),%rdx
 29fd566:	mov    0x20(%rbx),%r9
 29fd56a:	lea    0x10(%r9,%rcx,1),%r8
 29fd56f:	xor    %rdi,%rdi
 29fd572:	cmp    %rdx,%rcx
 29fd575:	cmova  %rdi,%r8
 29fd579:	mov    (%r8),%r8d
 29fd57c:	mov    0x38(%rsp),%r10
 29fd581:	cmp    %r8d,%r10d
 29fd584:	jae    29fe0bf <wasm[0]::function[1014]::helper::array_indexed_delete+0x16ff>
 29fd58a:	mov    %r8d,%r10d
 29fd58d:	shl    $0x2,%r10
 29fd591:	shr    $0x20,%r10
 29fd595:	test   %r10,%r10
 29fd598:	jne    29fe0c1 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1701>
 29fd59e:	shl    $0x2,%r8d
 29fd5a2:	add    $0x14,%r8d
 29fd5a6:	jb     29fe0c3 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1703>
 29fd5ac:	mov    %rax,%r10
 29fd5af:	add    %r8d,%r10d
 29fd5b2:	jb     29fe0c5 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1705>
 29fd5b8:	mov    %r10d,%r11d
 29fd5bb:	lea    (%r9,%r11,1),%r10
 29fd5bf:	cmp    %rdx,%r11
 29fd5c2:	cmova  %rdi,%r10
 29fd5c6:	mov    0x38(%rsp),%rdx
 29fd5cb:	shl    $0x2,%edx
 29fd5ce:	lea    0x14(%rdx),%r9d
 29fd5d2:	sub    %r9d,%r8d
 29fd5d5:	sub    %r8,%r10
 29fd5d8:	mov    (%r10),%edx
 29fd5db:	test   %edx,%edx
 29fd5dd:	je     29fd6c6 <wasm[0]::function[1014]::helper::array_indexed_delete+0xd06>
 29fd5e3:	mov    0x28(%rbx),%rdx
 29fd5e7:	mov    0x20(%rbx),%r8
 29fd5eb:	lea    0x10(%r8,%rcx,1),%r10
 29fd5f0:	xor    %rdi,%rdi
 29fd5f3:	cmp    %rdx,%rcx
 29fd5f6:	cmova  %rdi,%r10
 29fd5fa:	mov    (%r10),%ecx
 29fd5fd:	mov    0x38(%rsp),%r10
 29fd602:	cmp    %ecx,%r10d
 29fd605:	jae    29fe0c7 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1707>
 29fd60b:	mov    %ecx,%r10d
 29fd60e:	shl    $0x2,%r10
 29fd612:	shr    $0x20,%r10
 29fd616:	test   %r10,%r10
 29fd619:	jne    29fe0c9 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1709>
 29fd61f:	shl    $0x2,%ecx
 29fd622:	add    $0x14,%ecx
 29fd625:	jb     29fe0cb <wasm[0]::function[1014]::helper::array_indexed_delete+0x170b>
 29fd62b:	add    %ecx,%eax
 29fd62d:	jb     29fe0cd <wasm[0]::function[1014]::helper::array_indexed_delete+0x170d>
 29fd633:	mov    %eax,%r10d
 29fd636:	lea    (%r8,%r10,1),%rax
 29fd63a:	cmp    %rdx,%r10
 29fd63d:	cmova  %rdi,%rax
 29fd641:	sub    %r9d,%ecx
 29fd644:	sub    %rcx,%rax
 29fd647:	movl   $0x0,(%rax)
 29fd64d:	mov    (%rsp),%eax
 29fd650:	test   %eax,%eax
 29fd652:	je     29fe0cf <wasm[0]::function[1014]::helper::array_indexed_delete+0x170f>
 29fd658:	test   %eax,%eax
 29fd65a:	je     29fe0d1 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1711>
 29fd660:	mov    %eax,%ecx
 29fd662:	lea    (%r8,%rcx,1),%rax
 29fd666:	cmp    %rdx,%rcx
 29fd669:	cmova  %rdi,%rax
 29fd66d:	mov    0x18(%rax),%rcx
 29fd671:	mov    %rcx,%rdx
 29fd674:	sub    $0x1,%rdx
 29fd678:	mov    %rdx,0x18(%rax)
 29fd67c:	cmp    $0x1,%rcx
 29fd680:	jne    29fd6c6 <wasm[0]::function[1014]::helper::array_indexed_delete+0xd06>
 29fd686:	mov    0x30(%rsp),%rcx
 29fd68b:	mov    0x9f0(%rcx),%eax
 29fd691:	mov    (%rsp),%ecx
 29fd694:	test   %ecx,%ecx
 29fd696:	je     29fe0d3 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1713>
 29fd69c:	test   %eax,%eax
 29fd69e:	je     29fe0d5 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1715>
 29fd6a4:	test   %ecx,%ecx
 29fd6a6:	je     29fe0d7 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1717>
 29fd6ac:	mov    0x28(%rbx),%rdx
 29fd6b0:	mov    %ecx,%edi
 29fd6b2:	mov    %rdi,%rcx
 29fd6b5:	add    0x20(%rbx),%rcx
 29fd6b9:	xor    %r8,%r8
 29fd6bc:	cmp    %rdx,%rdi
 29fd6bf:	cmova  %r8,%rcx
 29fd6c3:	mov    %eax,0x20(%rcx)
 29fd6c6:	movzbl %sil,%esi
 29fd6ca:	test   %esi,%esi
 29fd6cc:	jne    29fde63 <wasm[0]::function[1014]::helper::array_indexed_delete+0x14a3>
 29fd6d2:	mov    (%rsp),%ecx
 29fd6d5:	test   %ecx,%ecx
 29fd6d7:	je     29fe0d9 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1719>
 29fd6dd:	test   %ecx,%ecx
 29fd6df:	je     29fe0db <wasm[0]::function[1014]::helper::array_indexed_delete+0x171b>
 29fd6e5:	mov    0x28(%rbx),%rsi
 29fd6e9:	mov    0x20(%rbx),%rdi
 29fd6ed:	mov    %ecx,%r9d
 29fd6f0:	lea    (%rdi,%r9,1),%rdx
 29fd6f4:	xor    %r8,%r8
 29fd6f7:	cmp    %rsi,%r9
 29fd6fa:	cmova  %r8,%rdx
 29fd6fe:	mov    0x10(%rdx),%r9d
 29fd702:	mov    %r9d,0x20(%rsp)
 29fd707:	test   %r9d,%r9d
 29fd70a:	je     29fe0dd <wasm[0]::function[1014]::helper::array_indexed_delete+0x171d>
 29fd710:	test   %r9d,%r9d
 29fd713:	je     29fe0df <wasm[0]::function[1014]::helper::array_indexed_delete+0x171f>
 29fd719:	mov    %r9d,%r11d
 29fd71c:	lea    0x10(%rdi,%r11,1),%r10
 29fd721:	cmp    %rsi,%r11
 29fd724:	cmova  %r8,%r10
 29fd728:	mov    (%r10),%eax
 29fd72b:	test   %eax,%eax
 29fd72d:	mov    %rax,0x40(%rsp)
 29fd732:	je     29fde63 <wasm[0]::function[1014]::helper::array_indexed_delete+0x14a3>
 29fd738:	mov    0x20(%rsp),%edx
 29fd73c:	xor    %ecx,%ecx
 29fd73e:	test   %edx,%edx
 29fd740:	je     29fe0e1 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1721>
 29fd746:	test   %edx,%edx
 29fd748:	je     29fe0e3 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1723>
 29fd74e:	mov    0x28(%rbx),%rsi
 29fd752:	mov    0x20(%rbx),%rdi
 29fd756:	mov    %edx,%r9d
 29fd759:	lea    0x10(%rdi,%r9,1),%rax
 29fd75e:	xor    %r8,%r8
 29fd761:	cmp    %rsi,%r9
 29fd764:	cmova  %r8,%rax
 29fd768:	mov    (%rax),%r9d
 29fd76b:	mov    $0x10,%eax
 29fd770:	mov    %rax,%r12
 29fd773:	mov    0x38(%rsp),%rax
 29fd778:	shr    $0x10,%eax
 29fd77b:	mov    0x38(%rsp),%r10
 29fd780:	xor    %eax,%r10d
 29fd783:	imul   $0x7feb352d,%r10d,%eax
 29fd78a:	mov    %rax,%r10
 29fd78d:	shr    $0xf,%r10d
 29fd791:	xor    %r10d,%eax
 29fd794:	imul   $0x846ca68b,%eax,%r14d
 29fd79b:	mov    %r14,%rax
 29fd79e:	shr    $0x10,%eax
 29fd7a1:	xor    %eax,%r14d
 29fd7a4:	mov    0x40(%rsp),%rax
 29fd7a9:	sub    $0x1,%eax
 29fd7ac:	and    %eax,%r14d
 29fd7af:	cmp    %r9d,%r14d
 29fd7b2:	jae    29fe0e5 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1725>
 29fd7b8:	mov    %r9d,%eax
 29fd7bb:	shl    $0x2,%rax
 29fd7bf:	shr    $0x20,%rax
 29fd7c3:	test   %rax,%rax
 29fd7c6:	jne    29fe0e7 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1727>
 29fd7cc:	shl    $0x2,%r9d
 29fd7d0:	add    $0x14,%r9d
 29fd7d4:	jb     29fe0e9 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1729>
 29fd7da:	add    %r9d,%edx
 29fd7dd:	jb     29fe0eb <wasm[0]::function[1014]::helper::array_indexed_delete+0x172b>
 29fd7e3:	mov    %edx,%edx
 29fd7e5:	lea    (%rdi,%rdx,1),%rax
 29fd7e9:	cmp    %rsi,%rdx
 29fd7ec:	cmova  %r8,%rax
 29fd7f0:	mov    %r14,%r15
 29fd7f3:	shl    $0x2,%r15d
 29fd7f7:	lea    0x14(%r15),%edx
 29fd7fb:	sub    %edx,%r9d
 29fd7fe:	sub    %r9,%rax
 29fd801:	mov    (%rax),%eax
 29fd803:	mov    %eax,0x10(%rsp)
 29fd807:	mov    %ecx,0x8(%rsp)
 29fd80b:	mov    0x50(%rsp),%rcx
 29fd810:	mov    (%rcx),%rax
 29fd813:	mov    0x48(%rsp),%rcx
 29fd818:	cmp    %rcx,%rax
 29fd81b:	jae    29fdf40 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1580>
 29fd821:	mov    0x10(%rsp),%eax
 29fd825:	test   %eax,%eax
 29fd827:	je     29fde63 <wasm[0]::function[1014]::helper::array_indexed_delete+0x14a3>
 29fd82d:	mov    0x10(%rsp),%ecx
 29fd831:	test   %ecx,%ecx
 29fd833:	je     29fe0ed <wasm[0]::function[1014]::helper::array_indexed_delete+0x172d>
 29fd839:	mov    0x28(%rbx),%rax
 29fd83d:	mov    %ecx,%edx
 29fd83f:	mov    %rdx,%rcx
 29fd842:	add    0x20(%rbx),%rcx
 29fd846:	xor    %rsi,%rsi
 29fd849:	cmp    %rax,%rdx
 29fd84c:	cmova  %rsi,%rcx
 29fd850:	mov    0x10(%rcx),%rax
 29fd854:	mov    0x38(%rsp),%rcx
 29fd859:	cmp    %rcx,%rax
 29fd85c:	je     29fd88d <wasm[0]::function[1014]::helper::array_indexed_delete+0xecd>
 29fd862:	mov    0x10(%rsp),%ecx
 29fd866:	test   %ecx,%ecx
 29fd868:	je     29fe0ef <wasm[0]::function[1014]::helper::array_indexed_delete+0x172f>
 29fd86e:	mov    0x28(%rbx),%rax
 29fd872:	mov    %ecx,%esi
 29fd874:	mov    %rsi,%rdx
 29fd877:	add    0x20(%rbx),%rdx
 29fd87b:	xor    %rdi,%rdi
 29fd87e:	cmp    %rax,%rsi
 29fd881:	cmova  %rdi,%rdx
 29fd885:	mov    0x1c(%rdx),%eax
 29fd888:	jmp    29fd803 <wasm[0]::function[1014]::helper::array_indexed_delete+0xe43>
 29fd88d:	mov    0x10(%rsp),%ecx
 29fd891:	test   %ecx,%ecx
 29fd893:	je     29fe0f1 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1731>
 29fd899:	mov    0x28(%rbx),%rax
 29fd89d:	mov    0x20(%rbx),%rsi
 29fd8a1:	mov    %ecx,%edx
 29fd8a3:	lea    (%rsi,%rdx,1),%rcx
 29fd8a7:	xor    %rsi,%rsi
 29fd8aa:	cmp    %rax,%rdx
 29fd8ad:	cmova  %rsi,%rcx
 29fd8b1:	mov    0x1c(%rcx),%ecx
 29fd8b4:	mov    0x8(%rsp),%eax
 29fd8b8:	test   %eax,%eax
 29fd8ba:	je     29fd8eb <wasm[0]::function[1014]::helper::array_indexed_delete+0xf2b>
 29fd8c0:	mov    0x8(%rsp),%edx
 29fd8c4:	test   %edx,%edx
 29fd8c6:	je     29fe0f3 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1733>
 29fd8cc:	mov    0x28(%rbx),%rax
 29fd8d0:	mov    %edx,%esi
 29fd8d2:	mov    %rsi,%rdx
 29fd8d5:	add    0x20(%rbx),%rdx
 29fd8d9:	xor    %rdi,%rdi
 29fd8dc:	cmp    %rax,%rsi
 29fd8df:	cmova  %rdi,%rdx
 29fd8e3:	mov    %ecx,0x1c(%rdx)
 29fd8e6:	jmp    29fd969 <wasm[0]::function[1014]::helper::array_indexed_delete+0xfa9>
 29fd8eb:	mov    0x20(%rsp),%eax
 29fd8ef:	test   %eax,%eax
 29fd8f1:	je     29fe0f5 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1735>
 29fd8f7:	test   %eax,%eax
 29fd8f9:	je     29fe0f7 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1737>
 29fd8ff:	mov    0x28(%rbx),%rdx
 29fd903:	mov    0x20(%rbx),%rsi
 29fd907:	mov    %eax,%r9d
 29fd90a:	lea    0x10(%rsi,%r9,1),%r8
 29fd90f:	xor    %rdi,%rdi
 29fd912:	cmp    %rdx,%r9
 29fd915:	cmova  %rdi,%r8
 29fd919:	mov    (%r8),%r8d
 29fd91c:	cmp    %r8d,%r14d
 29fd91f:	jae    29fe0f9 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1739>
 29fd925:	mov    %r8d,%r9d
 29fd928:	shl    $0x2,%r9
 29fd92c:	shr    $0x20,%r9
 29fd930:	test   %r9,%r9
 29fd933:	jne    29fe0fb <wasm[0]::function[1014]::helper::array_indexed_delete+0x173b>
 29fd939:	shl    $0x2,%r8d
 29fd93d:	add    $0x14,%r8d
 29fd941:	jb     29fe0fd <wasm[0]::function[1014]::helper::array_indexed_delete+0x173d>
 29fd947:	add    %r8d,%eax
 29fd94a:	jb     29fe0ff <wasm[0]::function[1014]::helper::array_indexed_delete+0x173f>
 29fd950:	mov    %eax,%r9d
 29fd953:	add    %r9,%rsi
 29fd956:	cmp    %rdx,%r9
 29fd959:	cmova  %rdi,%rsi
 29fd95d:	lea    0x14(%r15),%r9d
 29fd961:	sub    %r9d,%r8d
 29fd964:	sub    %r8,%rsi
 29fd967:	mov    %ecx,(%rsi)
 29fd969:	mov    (%rsp),%r10d
 29fd96d:	test   %r10d,%r10d
 29fd970:	je     29fe101 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1741>
 29fd976:	test   %r10d,%r10d
 29fd979:	je     29fe103 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1743>
 29fd97f:	mov    0x28(%rbx),%rcx
 29fd983:	mov    0x20(%rbx),%rax
 29fd987:	mov    %r10d,%edx
 29fd98a:	add    %rdx,%rax
 29fd98d:	xor    %rsi,%rsi
 29fd990:	cmp    %rcx,%rdx
 29fd993:	cmova  %rsi,%rax
 29fd997:	mov    0x18(%rax),%r11
 29fd99b:	mov    %r11,%rcx
 29fd99e:	sub    $0x1,%rcx
 29fd9a2:	mov    %rcx,0x18(%rax)
 29fd9a6:	cmp    $0x1,%r11
 29fd9aa:	je     29fde23 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1463>
 29fd9b0:	mov    0x40(%rsp),%rax
 29fd9b5:	cmp    $0x8,%eax
 29fd9b8:	seta   %al
 29fd9bb:	sub    $0x1,%r11
 29fd9bf:	shl    $0x2,%r11
 29fd9c3:	mov    0x40(%rsp),%rsi
 29fd9c8:	mov    %esi,%ecx
 29fd9ca:	cmp    %rcx,%r11
 29fd9cd:	setb   %cl
 29fd9d0:	test   %al,%cl
 29fd9d2:	je     29fde63 <wasm[0]::function[1014]::helper::array_indexed_delete+0x14a3>
 29fd9d8:	mov    (%rsp),%eax
 29fd9db:	test   %eax,%eax
 29fd9dd:	je     29fe105 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1745>
 29fd9e3:	test   %eax,%eax
 29fd9e5:	je     29fe107 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1747>
 29fd9eb:	mov    0x28(%rbx),%rcx
 29fd9ef:	mov    %eax,%edx
 29fd9f1:	mov    %rdx,%rax
 29fd9f4:	add    0x20(%rbx),%rax
 29fd9f8:	xor    %rsi,%rsi
 29fd9fb:	cmp    %rcx,%rdx
 29fd9fe:	cmova  %rsi,%rax
 29fda02:	mov    0x10(%rax),%eax
 29fda05:	mov    %eax,0x20(%rsp)
 29fda09:	mov    0x40(%rsp),%rax
 29fda0e:	shr    $1,%eax
 29fda10:	mov    %rax,0x40(%rsp)
 29fda15:	mov    %rax,%r14
 29fda18:	shl    $0x2,%r14
 29fda1c:	mov    %r14,%rax
 29fda1f:	shr    $0x20,%rax
 29fda23:	test   %rax,%rax
 29fda26:	jne    29fe109 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1749>
 29fda2c:	mov    0x40(%rsp),%rax
 29fda31:	mov    %rax,%rcx
 29fda34:	shl    $0x2,%ecx
 29fda37:	add    $0x14,%ecx
 29fda3a:	jb     29fe10b <wasm[0]::function[1014]::helper::array_indexed_delete+0x174b>
 29fda40:	mov    0x30(%rsp),%r9
 29fda45:	mov    0x20(%r9),%rdi
 29fda49:	mov    (%rdi),%eax
 29fda4b:	mov    %eax,%esi
 29fda4d:	mov    %ecx,%edx
 29fda4f:	add    $0xf,%rdx
 29fda56:	mov    %rdx,%r8
 29fda59:	and    $0xfffffffffffffff0,%r8
 29fda5d:	add    %rsi,%r8
 29fda60:	mov    0x4(%rdi),%r9d
 29fda64:	cmp    %r9,%r8
 29fda67:	ja     29fdf66 <wasm[0]::function[1014]::helper::array_indexed_delete+0x15a6>
 29fda6d:	add    $0xf,%ecx
 29fda73:	and    $0xfffffff0,%ecx
 29fda76:	add    %eax,%ecx
 29fda78:	mov    %ecx,(%rdi)
 29fda7a:	mov    0x20(%rbx),%rdi
 29fda7e:	lea    (%rdi,%rsi,1),%rcx
 29fda82:	movl   $0xa800000e,(%rdi,%rsi,1)
 29fda89:	mov    0x30(%rsp),%r8
 29fda8e:	mov    0x28(%r8),%r8
 29fda92:	mov    0x1ac(%r8),%r8d
 29fda99:	mov    %r8d,0x4(%rdi,%rsi,1)
 29fda9e:	and    $0xfffffffffffffff0,%rdx
 29fdaa2:	mov    %edx,0x8(%rdi,%rsi,1)
 29fdaa6:	mov    %eax,0x8(%rsp)
 29fdaaa:	mov    0x40(%rsp),%rsi
 29fdaaf:	mov    %esi,0x10(%rcx)
 29fdab2:	test   %eax,%eax
 29fdab4:	je     29fe10d <wasm[0]::function[1014]::helper::array_indexed_delete+0x174d>
 29fdaba:	mov    0x28(%rbx),%rcx
 29fdabe:	mov    0x20(%rbx),%rdx
 29fdac2:	mov    %eax,%eax
 29fdac4:	lea    (%rdx,%rax,1),%rsi
 29fdac8:	lea    0x10(%rdx,%rax,1),%rdi
 29fdacd:	xor    %r8,%r8
 29fdad0:	cmp    %rcx,%rax
 29fdad3:	cmova  %r8,%rdi
 29fdad7:	mov    (%rdi),%edi
 29fdad9:	mov    0x40(%rsp),%r8
 29fdade:	cmp    %rdi,%r8
 29fdae1:	ja     29fe10f <wasm[0]::function[1014]::helper::array_indexed_delete+0x174f>
 29fdae7:	lea    0x14(%rdx,%rax,1),%r12
 29fdaec:	mov    %r12,%rdi
 29fdaef:	add    %r14,%rdi
 29fdaf2:	jb     29fe111 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1751>
 29fdaf8:	lea    (%rdx,%rcx,1),%rax
 29fdafc:	cmp    %rax,%rdi
 29fdaff:	ja     29fe113 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1753>
 29fdb05:	mov    0x20(%rsp),%ecx
 29fdb09:	mov    (%rsp),%edx
 29fdb0c:	mov    0x40(%rsp),%rax
 29fdb11:	lea    0x14(%rsi,%rax,4),%r14
 29fdb16:	mov    0x40(%rsp),%rsi
 29fdb1b:	test   %rsi,%rax
 29fdb1e:	je     29fdb62 <wasm[0]::function[1014]::helper::array_indexed_delete+0x11a2>
 29fdb24:	mov    %ecx,0x10(%rsp)
 29fdb28:	mov    %edx,0x20(%rsp)
 29fdb2c:	mov    0x50(%rsp),%rcx
 29fdb31:	mov    (%rcx),%rcx
 29fdb34:	mov    0x48(%rsp),%rax
 29fdb39:	cmp    %rax,%rcx
 29fdb3c:	jae    29fdf92 <wasm[0]::function[1014]::helper::array_indexed_delete+0x15d2>
 29fdb42:	movl   $0x0,(%r12)
 29fdb4a:	mov    0x10(%rsp),%ecx
 29fdb4e:	mov    0x20(%rsp),%edx
 29fdb52:	add    $0x4,%r12
 29fdb59:	cmp    %r14,%r12
 29fdb5c:	jne    29fdb24 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1164>
 29fdb62:	xor    %r15d,%r15d
 29fdb65:	test   %ecx,%ecx
 29fdb67:	je     29fe115 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1755>
 29fdb6d:	test   %ecx,%ecx
 29fdb6f:	je     29fe117 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1757>
 29fdb75:	mov    0x28(%rbx),%r9
 29fdb79:	mov    0x20(%rbx),%r11
 29fdb7d:	mov    %ecx,%r10d
 29fdb80:	lea    0x10(%r11,%r10,1),%rsi
 29fdb85:	xor    %r11,%r11
 29fdb88:	cmp    %r9,%r10
 29fdb8b:	cmova  %r11,%rsi
 29fdb8f:	mov    (%rsi),%r12d
 29fdb92:	mov    %r12,0x38(%rsp)
 29fdb97:	mov    %ecx,0x20(%rsp)
 29fdb9b:	mov    %edx,0x10(%rsp)
 29fdb9f:	mov    0x50(%rsp),%rcx
 29fdba4:	mov    (%rcx),%rax
 29fdba7:	mov    0x48(%rsp),%rcx
 29fdbac:	cmp    %rcx,%rax
 29fdbaf:	jae    29fdfb8 <wasm[0]::function[1014]::helper::array_indexed_delete+0x15f8>
 29fdbb5:	mov    0x38(%rsp),%r12
 29fdbba:	jmp    29fdbc4 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1204>
 29fdbbf:	mov    0x38(%rsp),%r12
 29fdbc4:	cmp    %r12d,%r15d
 29fdbc7:	mov    %r12,0x38(%rsp)
 29fdbcc:	jae    29fdde0 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1420>
 29fdbd2:	mov    0x20(%rsp),%ecx
 29fdbd6:	test   %ecx,%ecx
 29fdbd8:	je     29fe119 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1759>
 29fdbde:	test   %ecx,%ecx
 29fdbe0:	je     29fe11b <wasm[0]::function[1014]::helper::array_indexed_delete+0x175b>
 29fdbe6:	mov    0x28(%rbx),%rax
 29fdbea:	mov    0x20(%rbx),%rdx
 29fdbee:	mov    %ecx,%r8d
 29fdbf1:	lea    0x10(%rdx,%r8,1),%rdi
 29fdbf6:	xor    %rsi,%rsi
 29fdbf9:	cmp    %rax,%r8
 29fdbfc:	cmova  %rsi,%rdi
 29fdc00:	mov    (%rdi),%edi
 29fdc02:	cmp    %edi,%r15d
 29fdc05:	jae    29fe11d <wasm[0]::function[1014]::helper::array_indexed_delete+0x175d>
 29fdc0b:	mov    %edi,%r8d
 29fdc0e:	shl    $0x2,%r8
 29fdc12:	shr    $0x20,%r8
 29fdc16:	test   %r8,%r8
 29fdc19:	jne    29fe11f <wasm[0]::function[1014]::helper::array_indexed_delete+0x175f>
 29fdc1f:	shl    $0x2,%edi
 29fdc22:	add    $0x14,%edi
 29fdc25:	jb     29fe121 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1761>
 29fdc2b:	mov    %rcx,%r8
 29fdc2e:	add    %edi,%r8d
 29fdc31:	jb     29fe123 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1763>
 29fdc37:	mov    %r8d,%r8d
 29fdc3a:	add    %r8,%rdx
 29fdc3d:	cmp    %rax,%r8
 29fdc40:	cmova  %rsi,%rdx
 29fdc44:	mov    %r15,%rax
 29fdc47:	shl    $0x2,%eax
 29fdc4a:	add    $0x14,%eax
 29fdc50:	sub    %eax,%edi
 29fdc52:	sub    %rdi,%rdx
 29fdc55:	mov    (%rdx),%edx
 29fdc57:	mov    0x10(%rsp),%eax
 29fdc5b:	mov    %edx,0x28(%rsp)
 29fdc5f:	mov    %ecx,0x18(%rsp)
 29fdc63:	mov    %eax,0x20(%rsp)
 29fdc67:	mov    0x50(%rsp),%rcx
 29fdc6c:	mov    (%rcx),%rax
 29fdc6f:	mov    0x48(%rsp),%rcx
 29fdc74:	cmp    %rcx,%rax
 29fdc77:	jae    29fdfe3 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1623>
 29fdc7d:	mov    0x28(%rsp),%eax
 29fdc81:	test   %eax,%eax
 29fdc83:	je     29fddcc <wasm[0]::function[1014]::helper::array_indexed_delete+0x140c>
 29fdc89:	mov    0x28(%rsp),%ecx
 29fdc8d:	test   %ecx,%ecx
 29fdc8f:	je     29fe125 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1765>
 29fdc95:	mov    0x28(%rbx),%rsi
 29fdc99:	mov    0x20(%rbx),%rdi
 29fdc9d:	mov    %ecx,%eax
 29fdc9f:	lea    (%rdi,%rax,1),%r10
 29fdca3:	xor    %r8,%r8
 29fdca6:	cmp    %rsi,%rax
 29fdca9:	cmova  %r8,%r10
 29fdcad:	mov    0x1c(%r10),%edx
 29fdcb1:	mov    0x10(%r10),%r12
 29fdcb5:	mov    0x8(%rsp),%r9d
 29fdcba:	test   %r9d,%r9d
 29fdcbd:	je     29fe127 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1767>
 29fdcc3:	test   %r9d,%r9d
 29fdcc6:	je     29fe129 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1769>
 29fdccc:	mov    %r9d,%eax
 29fdccf:	lea    0x10(%rdi,%rax,1),%r11
 29fdcd4:	cmp    %rsi,%rax
 29fdcd7:	cmova  %r8,%r11
 29fdcdb:	mov    (%r11),%eax
 29fdcde:	mov    %r12,%r13
 29fdce1:	shr    $0x10,%r13d
 29fdce5:	xor    %r13d,%r12d
 29fdce8:	imul   $0x7feb352d,%r12d,%r12d
 29fdcef:	mov    %r12,%r13
 29fdcf2:	shr    $0xf,%r13d
 29fdcf6:	xor    %r13d,%r12d
 29fdcf9:	imul   $0x846ca68b,%r12d,%r14d
 29fdd00:	mov    %r14,%r12
 29fdd03:	shr    $0x10,%r12d
 29fdd07:	xor    %r12d,%r14d
 29fdd0a:	mov    0x40(%rsp),%r12
 29fdd0f:	sub    $0x1,%r12d
 29fdd13:	and    %r12d,%r14d
 29fdd16:	cmp    %eax,%r14d
 29fdd19:	jae    29fe12b <wasm[0]::function[1014]::helper::array_indexed_delete+0x176b>
 29fdd1f:	mov    %eax,%r12d
 29fdd22:	shl    $0x2,%r12
 29fdd26:	shr    $0x20,%r12
 29fdd2a:	test   %r12,%r12
 29fdd2d:	jne    29fe12d <wasm[0]::function[1014]::helper::array_indexed_delete+0x176d>
 29fdd33:	shl    $0x2,%eax
 29fdd36:	add    $0x14,%eax
 29fdd39:	jb     29fe12f <wasm[0]::function[1014]::helper::array_indexed_delete+0x176f>
 29fdd3f:	mov    %r9,%r12
 29fdd42:	add    %eax,%r12d
 29fdd45:	jb     29fe131 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1771>
 29fdd4b:	mov    %r12d,%r12d
 29fdd4e:	lea    (%rdi,%r12,1),%r13
 29fdd52:	cmp    %rsi,%r12
 29fdd55:	cmova  %r8,%r13
 29fdd59:	mov    %r14,%r12
 29fdd5c:	shl    $0x2,%r12d
 29fdd60:	add    $0x14,%r12d
 29fdd67:	sub    %r12d,%eax
 29fdd6a:	sub    %rax,%r13
 29fdd6d:	mov    0x0(%r13),%eax
 29fdd71:	mov    %eax,0x1c(%r10)
 29fdd75:	mov    (%r11),%eax
 29fdd78:	cmp    %eax,%r14d
 29fdd7b:	jae    29fe133 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1773>
 29fdd81:	mov    %eax,%r10d
 29fdd84:	shl    $0x2,%r10
 29fdd88:	shr    $0x20,%r10
 29fdd8c:	test   %r10,%r10
 29fdd8f:	jne    29fe135 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1775>
 29fdd95:	shl    $0x2,%eax
 29fdd98:	add    $0x14,%eax
 29fdd9b:	jb     29fe137 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1777>
 29fdda1:	add    %eax,%r9d
 29fdda4:	jb     29fe139 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1779>
 29fddaa:	mov    %r9d,%r9d
 29fddad:	add    %r9,%rdi
 29fddb0:	cmp    %rsi,%r9
 29fddb3:	cmova  %r8,%rdi
 29fddb7:	sub    %r12d,%eax
 29fddba:	sub    %rax,%rdi
 29fddbd:	mov    %ecx,(%rdi)
 29fddbf:	mov    0x18(%rsp),%ecx
 29fddc3:	mov    0x20(%rsp),%eax
 29fddc7:	jmp    29fdc5b <wasm[0]::function[1014]::helper::array_indexed_delete+0x129b>
 29fddcc:	mov    0x18(%rsp),%ecx
 29fddd0:	mov    0x20(%rsp),%edx
 29fddd4:	add    $0x1,%r15d
 29fdddb:	jmp    29fdb97 <wasm[0]::function[1014]::helper::array_indexed_delete+0x11d7>
 29fdde0:	mov    0x10(%rsp),%r10d
 29fdde5:	test   %r10d,%r10d
 29fdde8:	je     29fe13b <wasm[0]::function[1014]::helper::array_indexed_delete+0x177b>
 29fddee:	mov    0x8(%rsp),%eax
 29fddf2:	test   %eax,%eax
 29fddf4:	je     29fe13d <wasm[0]::function[1014]::helper::array_indexed_delete+0x177d>
 29fddfa:	test   %r10d,%r10d
 29fddfd:	je     29fe13f <wasm[0]::function[1014]::helper::array_indexed_delete+0x177f>
 29fde03:	mov    0x28(%rbx),%rcx
 29fde07:	mov    %r10d,%esi
 29fde0a:	mov    %rsi,%rdx
 29fde0d:	add    0x20(%rbx),%rdx
 29fde11:	xor    %rdi,%rdi
 29fde14:	cmp    %rcx,%rsi
 29fde17:	cmova  %rdi,%rdx
 29fde1b:	mov    %eax,0x10(%rdx)
 29fde1e:	jmp    29fde63 <wasm[0]::function[1014]::helper::array_indexed_delete+0x14a3>
 29fde23:	mov    0x30(%rsp),%rcx
 29fde28:	mov    0x9e0(%rcx),%eax
 29fde2e:	mov    (%rsp),%ecx
 29fde31:	test   %ecx,%ecx
 29fde33:	je     29fe141 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1781>
 29fde39:	test   %eax,%eax
 29fde3b:	je     29fe143 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1783>
 29fde41:	test   %ecx,%ecx
 29fde43:	je     29fe145 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1785>
 29fde49:	mov    0x28(%rbx),%rdx
 29fde4d:	mov    %ecx,%esi
 29fde4f:	mov    %rsi,%rcx
 29fde52:	add    0x20(%rbx),%rcx
 29fde56:	xor    %rdi,%rdi
 29fde59:	cmp    %rdx,%rsi
 29fde5c:	cmova  %rdi,%rcx
 29fde60:	mov    %eax,0x10(%rcx)
 29fde63:	mov    0x60(%rsp),%rbx
 29fde68:	mov    0x68(%rsp),%r12
 29fde6d:	mov    0x70(%rsp),%r13
 29fde72:	mov    0x78(%rsp),%r14
 29fde77:	mov    0x80(%rsp),%r15
 29fde7f:	add    $0x90,%rsp
 29fde86:	mov    %rbp,%rsp
 29fde89:	pop    %rbp
 29fde8a:	ret
 29fde8b:	mov    0x30(%rsp),%rdi
 29fde90:	call   3039b69 <wasmtime_builtin_new_epoch>
 29fde95:	mov    %rax,0x48(%rsp)
 29fde9a:	mov    0x38(%rsp),%rcx
 29fde9f:	jmp    29fca33 <wasm[0]::function[1014]::helper::array_indexed_delete+0x73>
 29fdea4:	mov    $0xa8000006,%esi
 29fdea9:	mov    0x30(%rsp),%rdx
 29fdeae:	mov    0x28(%rdx),%rax
 29fdeb2:	mov    0x1a4(%rax),%edx
 29fdeb8:	mov    $0x10,%r8d
 29fdebe:	mov    0x30(%rsp),%rdi
 29fdec3:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 29fdec8:	mov    %eax,%ecx
 29fdeca:	add    0x20(%rbx),%rcx
 29fdece:	jmp    29fcc44 <wasm[0]::function[1014]::helper::array_indexed_delete+0x284>
 29fded3:	mov    0x8(%rbx),%rax
 29fded7:	cmp    %rax,%rsi
 29fdeda:	jb     29fccdb <wasm[0]::function[1014]::helper::array_indexed_delete+0x31b>
 29fdee0:	mov    0x30(%rsp),%rdi
 29fdee5:	call   3039b69 <wasmtime_builtin_new_epoch>
 29fdeea:	mov    %rax,0x48(%rsp)
 29fdeef:	jmp    29fcce0 <wasm[0]::function[1014]::helper::array_indexed_delete+0x320>
 29fdef4:	mov    0x8(%rbx),%rcx
 29fdef8:	mov    %rcx,0x48(%rsp)
 29fdefd:	cmp    %rcx,%rax
 29fdf00:	jb     29fcd42 <wasm[0]::function[1014]::helper::array_indexed_delete+0x382>
 29fdf06:	mov    0x30(%rsp),%rdi
 29fdf0b:	call   3039b69 <wasmtime_builtin_new_epoch>
 29fdf10:	mov    %rax,0x48(%rsp)
 29fdf15:	jmp    29fcd42 <wasm[0]::function[1014]::helper::array_indexed_delete+0x382>
 29fdf1a:	mov    0x8(%rbx),%rax
 29fdf1e:	mov    %rax,0x48(%rsp)
 29fdf23:	cmp    %rax,%rcx
 29fdf26:	jb     29fcd85 <wasm[0]::function[1014]::helper::array_indexed_delete+0x3c5>
 29fdf2c:	mov    0x30(%rsp),%rdi
 29fdf31:	call   3039b69 <wasmtime_builtin_new_epoch>
 29fdf36:	mov    %rax,0x48(%rsp)
 29fdf3b:	jmp    29fcd85 <wasm[0]::function[1014]::helper::array_indexed_delete+0x3c5>
 29fdf40:	mov    0x8(%rbx),%rcx
 29fdf44:	mov    %rcx,0x48(%rsp)
 29fdf49:	cmp    %rcx,%rax
 29fdf4c:	jb     29fd821 <wasm[0]::function[1014]::helper::array_indexed_delete+0xe61>
 29fdf52:	mov    0x30(%rsp),%rdi
 29fdf57:	call   3039b69 <wasmtime_builtin_new_epoch>
 29fdf5c:	mov    %rax,0x48(%rsp)
 29fdf61:	jmp    29fd821 <wasm[0]::function[1014]::helper::array_indexed_delete+0xe61>
 29fdf66:	mov    $0xa800000e,%esi
 29fdf6b:	mov    0x30(%rsp),%rax
 29fdf70:	mov    0x28(%rax),%rax
 29fdf74:	mov    0x1ac(%rax),%edx
 29fdf7a:	mov    %r12,%r8
 29fdf7d:	mov    0x30(%rsp),%rdi
 29fdf82:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 29fdf87:	mov    %eax,%ecx
 29fdf89:	add    0x20(%rbx),%rcx
 29fdf8d:	jmp    29fdaa6 <wasm[0]::function[1014]::helper::array_indexed_delete+0x10e6>
 29fdf92:	mov    0x8(%rbx),%rax
 29fdf96:	mov    %rax,0x48(%rsp)
 29fdf9b:	cmp    %rax,%rcx
 29fdf9e:	jb     29fdb42 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1182>
 29fdfa4:	mov    0x30(%rsp),%rdi
 29fdfa9:	call   3039b69 <wasmtime_builtin_new_epoch>
 29fdfae:	mov    %rax,0x48(%rsp)
 29fdfb3:	jmp    29fdb42 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1182>
 29fdfb8:	mov    0x8(%rbx),%rcx
 29fdfbc:	mov    %rcx,0x48(%rsp)
 29fdfc1:	cmp    %rcx,%rax
 29fdfc4:	jb     29fdbbf <wasm[0]::function[1014]::helper::array_indexed_delete+0x11ff>
 29fdfca:	mov    0x30(%rsp),%rdi
 29fdfcf:	call   3039b69 <wasmtime_builtin_new_epoch>
 29fdfd4:	mov    %rax,0x48(%rsp)
 29fdfd9:	mov    0x38(%rsp),%r12
 29fdfde:	jmp    29fdbc4 <wasm[0]::function[1014]::helper::array_indexed_delete+0x1204>
 29fdfe3:	mov    0x8(%rbx),%rcx
 29fdfe7:	mov    %rcx,0x48(%rsp)
 29fdfec:	cmp    %rcx,%rax
 29fdfef:	jb     29fdc7d <wasm[0]::function[1014]::helper::array_indexed_delete+0x12bd>
 29fdff5:	mov    0x30(%rsp),%rdi
 29fdffa:	call   3039b69 <wasmtime_builtin_new_epoch>
 29fdfff:	mov    %rax,0x48(%rsp)
 29fe004:	jmp    29fdc7d <wasm[0]::function[1014]::helper::array_indexed_delete+0x12bd>
 29fe009:	ud2
 29fe00b:	ud2
 29fe00d:	ud2
 29fe00f:	ud2
 29fe011:	ud2
 29fe013:	ud2
 29fe015:	ud2
 29fe017:	ud2
 29fe019:	ud2
 29fe01b:	ud2
 29fe01d:	ud2
 29fe01f:	ud2
 29fe021:	ud2
 29fe023:	ud2
 29fe025:	ud2
 29fe027:	ud2
 29fe029:	ud2
 29fe02b:	ud2
 29fe02d:	ud2
 29fe02f:	ud2
 29fe031:	ud2
 29fe033:	ud2
 29fe035:	ud2
 29fe037:	ud2
 29fe039:	ud2
 29fe03b:	ud2
 29fe03d:	ud2
 29fe03f:	ud2
 29fe041:	ud2
 29fe043:	ud2
 29fe045:	ud2
 29fe047:	ud2
 29fe049:	ud2
 29fe04b:	ud2
 29fe04d:	ud2
 29fe04f:	ud2
 29fe051:	ud2
 29fe053:	ud2
 29fe055:	ud2
 29fe057:	ud2
 29fe059:	ud2
 29fe05b:	ud2
 29fe05d:	ud2
 29fe05f:	ud2
 29fe061:	ud2
 29fe063:	ud2
 29fe065:	ud2
 29fe067:	ud2
 29fe069:	ud2
 29fe06b:	ud2
 29fe06d:	ud2
 29fe06f:	ud2
 29fe071:	ud2
 29fe073:	ud2
 29fe075:	ud2
 29fe077:	ud2
 29fe079:	ud2
 29fe07b:	ud2
 29fe07d:	ud2
 29fe07f:	ud2
 29fe081:	ud2
 29fe083:	ud2
 29fe085:	ud2
 29fe087:	ud2
 29fe089:	ud2
 29fe08b:	ud2
 29fe08d:	ud2
 29fe08f:	ud2
 29fe091:	ud2
 29fe093:	ud2
 29fe095:	ud2
 29fe097:	ud2
 29fe099:	ud2
 29fe09b:	ud2
 29fe09d:	ud2
 29fe09f:	ud2
 29fe0a1:	ud2
 29fe0a3:	ud2
 29fe0a5:	ud2
 29fe0a7:	ud2
 29fe0a9:	ud2
 29fe0ab:	ud2
 29fe0ad:	ud2
 29fe0af:	ud2
 29fe0b1:	ud2
 29fe0b3:	ud2
 29fe0b5:	ud2
 29fe0b7:	ud2
 29fe0b9:	ud2
 29fe0bb:	ud2
 29fe0bd:	ud2
 29fe0bf:	ud2
 29fe0c1:	ud2
 29fe0c3:	ud2
 29fe0c5:	ud2
 29fe0c7:	ud2
 29fe0c9:	ud2
 29fe0cb:	ud2
 29fe0cd:	ud2
 29fe0cf:	ud2
 29fe0d1:	ud2
 29fe0d3:	ud2
 29fe0d5:	ud2
 29fe0d7:	ud2
 29fe0d9:	ud2
 29fe0db:	ud2
 29fe0dd:	ud2
 29fe0df:	ud2
 29fe0e1:	ud2
 29fe0e3:	ud2
 29fe0e5:	ud2
 29fe0e7:	ud2
 29fe0e9:	ud2
 29fe0eb:	ud2
 29fe0ed:	ud2
 29fe0ef:	ud2
 29fe0f1:	ud2
 29fe0f3:	ud2
 29fe0f5:	ud2
 29fe0f7:	ud2
 29fe0f9:	ud2
 29fe0fb:	ud2
 29fe0fd:	ud2
 29fe0ff:	ud2
 29fe101:	ud2
 29fe103:	ud2
 29fe105:	ud2
 29fe107:	ud2
 29fe109:	ud2
 29fe10b:	ud2
 29fe10d:	ud2
 29fe10f:	ud2
 29fe111:	ud2
 29fe113:	ud2
 29fe115:	ud2
 29fe117:	ud2
 29fe119:	ud2
 29fe11b:	ud2
 29fe11d:	ud2
 29fe11f:	ud2
 29fe121:	ud2
 29fe123:	ud2
 29fe125:	ud2
 29fe127:	ud2
 29fe129:	ud2
 29fe12b:	ud2
 29fe12d:	ud2
 29fe12f:	ud2
 29fe131:	ud2
 29fe133:	ud2
 29fe135:	ud2
 29fe137:	ud2
 29fe139:	ud2
 29fe13b:	ud2
 29fe13d:	ud2
 29fe13f:	ud2
 29fe141:	ud2
 29fe143:	ud2
 29fe145:	ud2
 29fe147:	add    %bh,%bh
 29fe149:	(bad)
 29fe14a:	(bad)
 29fe14b:	incl   (%rax)
 29fe14d:	add    %al,(%rax)
	...
