
/workspace/scriptw/target/performance-dense-numbers-20261030/native-cause/candidate/runtime-portable.elf:     file format elf64-x86-64


Disassembly of section .text:

00000000029f2ea0 <wasm[0]::function[1009]::helper::array_packed_join>:
 29f2ea0:	push   %rbp
 29f2ea1:	mov    %rsp,%rbp
 29f2ea4:	mov    0x8(%rdi),%r10
 29f2ea8:	mov    0x18(%r10),%r10
 29f2eac:	add    $0x120,%r10
 29f2eb3:	cmp    %rsp,%r10
 29f2eb6:	ja     29f4868 <wasm[0]::function[1009]::helper::array_packed_join+0x19c8>
 29f2ebc:	sub    $0x110,%rsp
 29f2ec3:	mov    %rbx,0xe0(%rsp)
 29f2ecb:	mov    %r12,0xe8(%rsp)
 29f2ed3:	mov    %r13,0xf0(%rsp)
 29f2edb:	mov    %r14,0xf8(%rsp)
 29f2ee3:	mov    %r15,0x100(%rsp)
 29f2eeb:	mov    %r9,0x68(%rsp)
 29f2ef0:	mov    0x10(%rbp),%rsi
 29f2ef4:	mov    %r8d,0x38(%rsp)
 29f2ef9:	mov    %esi,0x40(%rsp)
 29f2efd:	movl   $0x0,0x10(%rsp)
 29f2f05:	movl   $0x0,(%rsp)
 29f2f0c:	mov    0x18(%rdi),%rax
 29f2f10:	mov    (%rax),%rcx
 29f2f13:	mov    %rax,0xd0(%rsp)
 29f2f1b:	mov    0x8(%rdi),%r12
 29f2f1f:	mov    %rdi,0x60(%rsp)
 29f2f24:	mov    0x8(%r12),%rax
 29f2f29:	cmp    %rax,%rcx
 29f2f2c:	jae    29f4603 <wasm[0]::function[1009]::helper::array_packed_join+0x1763>
 29f2f32:	mov    0x68(%rsp),%r15
 29f2f37:	mov    %rax,0x90(%rsp)
 29f2f3f:	test   %r15,%r15
 29f2f42:	je     29f45be <wasm[0]::function[1009]::helper::array_packed_join+0x171e>
 29f2f48:	mov    0x40(%rsp),%edx
 29f2f4c:	xor    %ecx,%ecx
 29f2f4e:	test   %edx,%edx
 29f2f50:	je     29f486a <wasm[0]::function[1009]::helper::array_packed_join+0x19ca>
 29f2f56:	test   %edx,%edx
 29f2f58:	je     29f486c <wasm[0]::function[1009]::helper::array_packed_join+0x19cc>
 29f2f5e:	mov    0x28(%r12),%rax
 29f2f63:	mov    0x20(%r12),%rsi
 29f2f68:	mov    %edx,%r8d
 29f2f6b:	lea    (%rsi,%r8,1),%rdx
 29f2f6f:	xor    %rdi,%rdi
 29f2f72:	cmp    %rax,%r8
 29f2f75:	cmova  %rdi,%rdx
 29f2f79:	mov    0x10(%rdx),%edx
 29f2f7c:	test   %edx,%edx
 29f2f7e:	je     29f486e <wasm[0]::function[1009]::helper::array_packed_join+0x19ce>
 29f2f84:	test   %edx,%edx
 29f2f86:	je     29f4870 <wasm[0]::function[1009]::helper::array_packed_join+0x19d0>
 29f2f8c:	mov    %edx,%r8d
 29f2f8f:	lea    0x10(%rsi,%r8,1),%rsi
 29f2f94:	cmp    %rax,%r8
 29f2f97:	cmova  %rdi,%rsi
 29f2f9b:	mov    (%rsi),%r14d
 29f2f9e:	mov    %r14,0xc8(%rsp)
 29f2fa6:	mov    0x38(%rsp),%eax
 29f2faa:	test   %eax,%eax
 29f2fac:	je     29f2ff5 <wasm[0]::function[1009]::helper::array_packed_join+0x155>
 29f2fb2:	mov    0x38(%rsp),%eax
 29f2fb6:	xor    %ecx,%ecx
 29f2fb8:	test   $0x1,%eax
 29f2fbd:	jne    29f2ff5 <wasm[0]::function[1009]::helper::array_packed_join+0x155>
 29f2fc3:	mov    0x28(%r12),%rcx
 29f2fc8:	mov    0x20(%r12),%rdi
 29f2fcd:	mov    %eax,%esi
 29f2fcf:	lea    0x4(%rdi,%rsi,1),%rax
 29f2fd4:	xor    %rdi,%rdi
 29f2fd7:	cmp    %rcx,%rsi
 29f2fda:	cmova  %rdi,%rax
 29f2fde:	mov    (%rax),%eax
 29f2fe0:	mov    0x60(%rsp),%rcx
 29f2fe5:	mov    0x28(%rcx),%rcx
 29f2fe9:	cmp    0x254(%rcx),%eax
 29f2fef:	sete   %al
 29f2ff2:	movzbl %al,%ecx
 29f2ff5:	mov    0x10(%rsp),%eax
 29f2ff9:	xor    %esi,%esi
 29f2ffb:	test   %ecx,%ecx
 29f2ffd:	jne    29f300b <wasm[0]::function[1009]::helper::array_packed_join+0x16b>
 29f3003:	mov    %rsi,%rdi
 29f3006:	jmp    29f4558 <wasm[0]::function[1009]::helper::array_packed_join+0x16b8>
 29f300b:	mov    0x38(%rsp),%ecx
 29f300f:	xor    %esi,%esi
 29f3011:	test   %ecx,%ecx
 29f3013:	je     29f305c <wasm[0]::function[1009]::helper::array_packed_join+0x1bc>
 29f3019:	xor    %esi,%esi
 29f301b:	test   $0x1,%ecx
 29f3021:	jne    29f305c <wasm[0]::function[1009]::helper::array_packed_join+0x1bc>
 29f3027:	mov    0x28(%r12),%rsi
 29f302c:	mov    0x20(%r12),%rdi
 29f3031:	mov    %ecx,%r8d
 29f3034:	lea    0x4(%rdi,%r8,1),%rdi
 29f3039:	xor    %r9,%r9
 29f303c:	cmp    %rsi,%r8
 29f303f:	cmova  %r9,%rdi
 29f3043:	mov    (%rdi),%esi
 29f3045:	mov    0x60(%rsp),%rdi
 29f304a:	mov    0x28(%rdi),%rdi
 29f304e:	cmp    0x254(%rdi),%esi
 29f3054:	sete   %sil
 29f3058:	movzbl %sil,%esi
 29f305c:	test   %esi,%esi
 29f305e:	je     29f4872 <wasm[0]::function[1009]::helper::array_packed_join+0x19d2>
 29f3064:	test   %ecx,%ecx
 29f3066:	je     29f4874 <wasm[0]::function[1009]::helper::array_packed_join+0x19d4>
 29f306c:	test   %ecx,%ecx
 29f306e:	je     29f4876 <wasm[0]::function[1009]::helper::array_packed_join+0x19d6>
 29f3074:	mov    0x28(%r12),%rsi
 29f3079:	mov    0x20(%r12),%r8
 29f307e:	mov    %ecx,%edi
 29f3080:	lea    (%r8,%rdi,1),%rcx
 29f3084:	xor    %r8,%r8
 29f3087:	cmp    %rsi,%rdi
 29f308a:	cmova  %r8,%rcx
 29f308e:	mov    0x14(%rcx),%esi
 29f3091:	mov    %esi,0x40(%rsp)
 29f3095:	mov    0x18(%rcx),%rdi
 29f3099:	xor    %esi,%esi
 29f309b:	cmp    %r15,%rdi
 29f309e:	mov    %r15,0x68(%rsp)
 29f30a3:	je     29f30b1 <wasm[0]::function[1009]::helper::array_packed_join+0x211>
 29f30a9:	mov    %rsi,%rdi
 29f30ac:	jmp    29f4558 <wasm[0]::function[1009]::helper::array_packed_join+0x16b8>
 29f30b1:	mov    0x40(%rsp),%edi
 29f30b5:	xor    %esi,%esi
 29f30b7:	test   %edi,%edi
 29f30b9:	je     29f4878 <wasm[0]::function[1009]::helper::array_packed_join+0x19d8>
 29f30bf:	test   %edi,%edi
 29f30c1:	je     29f487a <wasm[0]::function[1009]::helper::array_packed_join+0x19da>
 29f30c7:	mov    0x28(%r12),%r10
 29f30cc:	mov    0x20(%r12),%rax
 29f30d1:	mov    %edi,%r11d
 29f30d4:	lea    (%rax,%r11,1),%rdi
 29f30d8:	xor    %rax,%rax
 29f30db:	cmp    %r10,%r11
 29f30de:	cmova  %rax,%rdi
 29f30e2:	mov    0x24(%rdi),%r11d
 29f30e6:	mov    0x10(%rsp),%eax
 29f30ea:	cmp    $0x4,%r11d
 29f30ee:	sete   %r8b
 29f30f2:	cmp    $0x2,%r11d
 29f30f6:	sete   %cl
 29f30f9:	or     %ecx,%r8d
 29f30fc:	cmp    $0x3,%r11d
 29f3100:	sete   %cl
 29f3103:	or     %ecx,%r8d
 29f3106:	movzbl %r8b,%ecx
 29f310a:	test   %ecx,%ecx
 29f310c:	jne    29f311a <wasm[0]::function[1009]::helper::array_packed_join+0x27a>
 29f3112:	mov    %rsi,%rdi
 29f3115:	jmp    29f4558 <wasm[0]::function[1009]::helper::array_packed_join+0x16b8>
 29f311a:	mov    (%rsp),%ecx
 29f311d:	mov    0x10(%rsp),%eax
 29f3121:	xor    %r15,%r15
 29f3124:	xor    %r14d,%r14d
 29f3127:	mov    $0x1,%esi
 29f312c:	mov    %rsi,0xc0(%rsp)
 29f3134:	mov    0x60(%rsp),%rsi
 29f3139:	mov    0x28(%rsi),%rbx
 29f313d:	mov    0x234(%rbx),%esi
 29f3143:	mov    %rsi,0xb8(%rsp)
 29f314b:	mov    %rbx,0x78(%rsp)
 29f3150:	mov    0xc8(%rsp),%rsi
 29f3158:	mov    %esi,%r13d
 29f315b:	mov    %r13,0xb0(%rsp)
 29f3163:	mov    %r14,%rsi
 29f3166:	mov    %r15,%r13
 29f3169:	mov    %r15,0x70(%rsp)
 29f316e:	mov    %ecx,0x8(%rsp)
 29f3172:	mov    %edx,0x38(%rsp)
 29f3176:	mov    %eax,0x10(%rsp)
 29f317a:	mov    %esi,(%rsp)
 29f317d:	mov    0xd0(%rsp),%rcx
 29f3185:	mov    (%rcx),%rax
 29f3188:	mov    0x90(%rsp),%rcx
 29f3190:	cmp    %rcx,%rax
 29f3193:	jae    29f461f <wasm[0]::function[1009]::helper::array_packed_join+0x177f>
 29f3199:	mov    0x68(%rsp),%rcx
 29f319e:	jmp    29f31a8 <wasm[0]::function[1009]::helper::array_packed_join+0x308>
 29f31a3:	mov    0x68(%rsp),%rcx
 29f31a8:	cmp    %rcx,%r15
 29f31ab:	jae    29f3722 <wasm[0]::function[1009]::helper::array_packed_join+0x882>
 29f31b1:	mov    0x40(%rsp),%eax
 29f31b5:	test   %eax,%eax
 29f31b7:	je     29f487c <wasm[0]::function[1009]::helper::array_packed_join+0x19dc>
 29f31bd:	test   %eax,%eax
 29f31bf:	je     29f487e <wasm[0]::function[1009]::helper::array_packed_join+0x19de>
 29f31c5:	mov    0x28(%r12),%rcx
 29f31ca:	mov    %eax,%edx
 29f31cc:	mov    %rdx,%rax
 29f31cf:	add    0x20(%r12),%rax
 29f31d4:	xor    %rsi,%rsi
 29f31d7:	cmp    %rcx,%rdx
 29f31da:	cmova  %rsi,%rax
 29f31de:	mov    0x24(%rax),%eax
 29f31e1:	cmp    $0x3,%eax
 29f31e4:	je     29f34b9 <wasm[0]::function[1009]::helper::array_packed_join+0x619>
 29f31ea:	mov    0x40(%rsp),%eax
 29f31ee:	test   %eax,%eax
 29f31f0:	je     29f4880 <wasm[0]::function[1009]::helper::array_packed_join+0x19e0>
 29f31f6:	test   %eax,%eax
 29f31f8:	je     29f4882 <wasm[0]::function[1009]::helper::array_packed_join+0x19e2>
 29f31fe:	mov    0x28(%r12),%rcx
 29f3203:	mov    %eax,%edx
 29f3205:	mov    %rdx,%rax
 29f3208:	add    0x20(%r12),%rax
 29f320d:	xor    %rsi,%rsi
 29f3210:	cmp    %rcx,%rdx
 29f3213:	cmova  %rsi,%rax
 29f3217:	mov    0x24(%rax),%eax
 29f321a:	cmp    $0x4,%eax
 29f321d:	je     29f33b6 <wasm[0]::function[1009]::helper::array_packed_join+0x516>
 29f3223:	mov    0x40(%rsp),%eax
 29f3227:	xor    %edx,%edx
 29f3229:	test   %eax,%eax
 29f322b:	je     29f4884 <wasm[0]::function[1009]::helper::array_packed_join+0x19e4>
 29f3231:	test   %eax,%eax
 29f3233:	je     29f4886 <wasm[0]::function[1009]::helper::array_packed_join+0x19e6>
 29f3239:	mov    0x28(%r12),%rcx
 29f323e:	mov    0x20(%r12),%r8
 29f3243:	mov    %eax,%esi
 29f3245:	lea    (%r8,%rsi,1),%rax
 29f3249:	xor    %r9,%r9
 29f324c:	cmp    %rcx,%rsi
 29f324f:	cmova  %r9,%rax
 29f3253:	mov    0x28(%rax),%esi
 29f3256:	mov    0x2c(%rax),%edi
 29f3259:	test   %esi,%esi
 29f325b:	je     29f4888 <wasm[0]::function[1009]::helper::array_packed_join+0x19e8>
 29f3261:	test   %esi,%esi
 29f3263:	je     29f488a <wasm[0]::function[1009]::helper::array_packed_join+0x19ea>
 29f3269:	mov    %esi,%eax
 29f326b:	lea    0x10(%r8,%rax,1),%r8
 29f3270:	cmp    %rcx,%rax
 29f3273:	cmova  %r9,%r8
 29f3277:	mov    (%r8),%r8d
 29f327a:	mov    0x8(%rsp),%ecx
 29f327e:	mov    %r8d,%r8d
 29f3281:	cmp    %r8,%r15
 29f3284:	jb     29f3294 <wasm[0]::function[1009]::helper::array_packed_join+0x3f4>
 29f328a:	mov    0x70(%rsp),%r10
 29f328f:	jmp    29f35dc <wasm[0]::function[1009]::helper::array_packed_join+0x73c>
 29f3294:	xor    %edx,%edx
 29f3296:	test   %edi,%edi
 29f3298:	je     29f488c <wasm[0]::function[1009]::helper::array_packed_join+0x19ec>
 29f329e:	test   %edi,%edi
 29f32a0:	je     29f488e <wasm[0]::function[1009]::helper::array_packed_join+0x19ee>
 29f32a6:	mov    0x28(%r12),%rcx
 29f32ab:	mov    0x20(%r12),%r8
 29f32b0:	mov    %edi,%r11d
 29f32b3:	lea    0x10(%r8,%r11,1),%r10
 29f32b8:	xor    %r9,%r9
 29f32bb:	cmp    %rcx,%r11
 29f32be:	cmova  %r9,%r10
 29f32c2:	mov    (%r10),%r10d
 29f32c5:	mov    %r15,%r11
 29f32c8:	shr    $0x6,%r11d
 29f32cc:	cmp    %r10d,%r11d
 29f32cf:	jae    29f4890 <wasm[0]::function[1009]::helper::array_packed_join+0x19f0>
 29f32d5:	mov    %r10d,%ebx
 29f32d8:	shl    $0x3,%rbx
 29f32dc:	shr    $0x20,%rbx
 29f32e0:	test   %rbx,%rbx
 29f32e3:	jne    29f4892 <wasm[0]::function[1009]::helper::array_packed_join+0x19f2>
 29f32e9:	shl    $0x3,%r10d
 29f32ed:	add    $0x18,%r10d
 29f32f1:	jb     29f4894 <wasm[0]::function[1009]::helper::array_packed_join+0x19f4>
 29f32f7:	add    %r10d,%edi
 29f32fa:	jb     29f4896 <wasm[0]::function[1009]::helper::array_packed_join+0x19f6>
 29f3300:	mov    %edi,%ebx
 29f3302:	lea    (%r8,%rbx,1),%rdi
 29f3306:	cmp    %rcx,%rbx
 29f3309:	cmova  %r9,%rdi
 29f330d:	shl    $0x3,%r11d
 29f3311:	lea    0x18(%r11),%r8d
 29f3315:	sub    %r8d,%r10d
 29f3318:	sub    %r10,%rdi
 29f331b:	mov    (%rdi),%rdi
 29f331e:	mov    0x8(%rsp),%ecx
 29f3322:	bt     %r15,%rdi
 29f3326:	jb     29f3336 <wasm[0]::function[1009]::helper::array_packed_join+0x496>
 29f332c:	mov    0x70(%rsp),%r10
 29f3331:	jmp    29f35dc <wasm[0]::function[1009]::helper::array_packed_join+0x73c>
 29f3336:	mov    0x28(%r12),%r10
 29f333b:	mov    0x20(%r12),%rcx
 29f3340:	lea    0x10(%rcx,%rax,1),%rdi
 29f3345:	xor    %r11,%r11
 29f3348:	cmp    %r10,%rax
 29f334b:	cmova  %r11,%rdi
 29f334f:	mov    (%rdi),%eax
 29f3351:	cmp    %eax,%r15d
 29f3354:	jae    29f4898 <wasm[0]::function[1009]::helper::array_packed_join+0x19f8>
 29f335a:	mov    %eax,%edx
 29f335c:	shl    $0x3,%rdx
 29f3360:	shr    $0x20,%rdx
 29f3364:	test   %rdx,%rdx
 29f3367:	jne    29f489a <wasm[0]::function[1009]::helper::array_packed_join+0x19fa>
 29f336d:	mov    $0x3,%r14d
 29f3373:	shl    $0x3,%eax
 29f3376:	add    $0x18,%eax
 29f3379:	jb     29f489c <wasm[0]::function[1009]::helper::array_packed_join+0x19fc>
 29f337f:	add    %eax,%esi
 29f3381:	jb     29f489e <wasm[0]::function[1009]::helper::array_packed_join+0x19fe>
 29f3387:	mov    %esi,%edx
 29f3389:	add    %rdx,%rcx
 29f338c:	cmp    %r10,%rdx
 29f338f:	cmova  %r11,%rcx
 29f3393:	mov    %r15,%rdx
 29f3396:	shl    $0x3,%edx
 29f3399:	add    $0x18,%edx
 29f339f:	sub    %edx,%eax
 29f33a1:	sub    %rax,%rcx
 29f33a4:	mov    (%rcx),%r10
 29f33a7:	xor    %ecx,%ecx
 29f33a9:	mov    0xc0(%rsp),%rdx
 29f33b1:	jmp    29f35dc <wasm[0]::function[1009]::helper::array_packed_join+0x73c>
 29f33b6:	mov    0x70(%rsp),%r10
 29f33bb:	mov    0x40(%rsp),%eax
 29f33bf:	xor    %edx,%edx
 29f33c1:	test   %eax,%eax
 29f33c3:	je     29f48a0 <wasm[0]::function[1009]::helper::array_packed_join+0x1a00>
 29f33c9:	test   %eax,%eax
 29f33cb:	je     29f48a2 <wasm[0]::function[1009]::helper::array_packed_join+0x1a02>
 29f33d1:	mov    0x28(%r12),%rcx
 29f33d6:	mov    %eax,%esi
 29f33d8:	mov    %rsi,%rax
 29f33db:	add    0x20(%r12),%rax
 29f33e0:	xor    %rdi,%rdi
 29f33e3:	cmp    %rcx,%rsi
 29f33e6:	cmova  %rdi,%rax
 29f33ea:	mov    0x18(%rax),%rax
 29f33ee:	mov    0x8(%rsp),%ecx
 29f33f2:	cmp    %rax,%r15
 29f33f5:	jae    29f35dc <wasm[0]::function[1009]::helper::array_packed_join+0x73c>
 29f33fb:	mov    0x40(%rsp),%esi
 29f33ff:	xor    %ecx,%ecx
 29f3401:	test   %esi,%esi
 29f3403:	je     29f48a4 <wasm[0]::function[1009]::helper::array_packed_join+0x1a04>
 29f3409:	test   %esi,%esi
 29f340b:	je     29f48a6 <wasm[0]::function[1009]::helper::array_packed_join+0x1a06>
 29f3411:	mov    0x28(%r12),%rax
 29f3416:	mov    0x20(%r12),%rdx
 29f341b:	mov    %esi,%r8d
 29f341e:	lea    (%rdx,%r8,1),%rdi
 29f3422:	xor    %rsi,%rsi
 29f3425:	cmp    %rax,%r8
 29f3428:	cmova  %rsi,%rdi
 29f342c:	mov    0x28(%rdi),%edi
 29f342f:	test   %edi,%edi
 29f3431:	je     29f48a8 <wasm[0]::function[1009]::helper::array_packed_join+0x1a08>
 29f3437:	test   %edi,%edi
 29f3439:	je     29f48aa <wasm[0]::function[1009]::helper::array_packed_join+0x1a0a>
 29f343f:	mov    %edi,%r9d
 29f3442:	lea    0x10(%rdx,%r9,1),%r8
 29f3447:	cmp    %rax,%r9
 29f344a:	cmova  %rsi,%r8
 29f344e:	mov    (%r8),%r8d
 29f3451:	cmp    %r8d,%r15d
 29f3454:	jae    29f48ac <wasm[0]::function[1009]::helper::array_packed_join+0x1a0c>
 29f345a:	mov    %r8d,%r9d
 29f345d:	shl    $0x3,%r9
 29f3461:	shr    $0x20,%r9
 29f3465:	test   %r9,%r9
 29f3468:	jne    29f48ae <wasm[0]::function[1009]::helper::array_packed_join+0x1a0e>
 29f346e:	mov    $0x3,%r14d
 29f3474:	shl    $0x3,%r8d
 29f3478:	add    $0x18,%r8d
 29f347c:	jb     29f48b0 <wasm[0]::function[1009]::helper::array_packed_join+0x1a10>
 29f3482:	add    %r8d,%edi
 29f3485:	jb     29f48b2 <wasm[0]::function[1009]::helper::array_packed_join+0x1a12>
 29f348b:	mov    %edi,%edi
 29f348d:	add    %rdi,%rdx
 29f3490:	cmp    %rax,%rdi
 29f3493:	cmova  %rsi,%rdx
 29f3497:	mov    %r15,%rax
 29f349a:	shl    $0x3,%eax
 29f349d:	add    $0x18,%eax
 29f34a3:	sub    %eax,%r8d
 29f34a6:	sub    %r8,%rdx
 29f34a9:	mov    (%rdx),%r10
 29f34ac:	mov    0xc0(%rsp),%rdx
 29f34b4:	jmp    29f35dc <wasm[0]::function[1009]::helper::array_packed_join+0x73c>
 29f34b9:	mov    0x70(%rsp),%r10
 29f34be:	mov    0x40(%rsp),%eax
 29f34c2:	xor    %edx,%edx
 29f34c4:	test   %eax,%eax
 29f34c6:	je     29f48b4 <wasm[0]::function[1009]::helper::array_packed_join+0x1a14>
 29f34cc:	test   %eax,%eax
 29f34ce:	je     29f48b6 <wasm[0]::function[1009]::helper::array_packed_join+0x1a16>
 29f34d4:	mov    0x28(%r12),%rcx
 29f34d9:	mov    0x20(%r12),%rdi
 29f34de:	mov    %eax,%esi
 29f34e0:	lea    (%rdi,%rsi,1),%rax
 29f34e4:	xor    %r8,%r8
 29f34e7:	cmp    %rcx,%rsi
 29f34ea:	cmova  %r8,%rax
 29f34ee:	mov    0x30(%rax),%eax
 29f34f1:	test   %eax,%eax
 29f34f3:	je     29f48b8 <wasm[0]::function[1009]::helper::array_packed_join+0x1a18>
 29f34f9:	test   %eax,%eax
 29f34fb:	je     29f48ba <wasm[0]::function[1009]::helper::array_packed_join+0x1a1a>
 29f3501:	mov    %eax,%esi
 29f3503:	lea    0x10(%rdi,%rsi,1),%rdi
 29f3508:	cmp    %rcx,%rsi
 29f350b:	cmova  %r8,%rdi
 29f350f:	mov    (%rdi),%edi
 29f3511:	mov    0x8(%rsp),%ecx
 29f3515:	mov    %edi,%edi
 29f3517:	cmp    %rdi,%r15
 29f351a:	jae    29f35dc <wasm[0]::function[1009]::helper::array_packed_join+0x73c>
 29f3520:	mov    0x28(%r12),%rcx
 29f3525:	mov    0x20(%r12),%rdi
 29f352a:	lea    0x10(%rdi,%rsi,1),%r8
 29f352f:	xor    %rdx,%rdx
 29f3532:	cmp    %rcx,%rsi
 29f3535:	cmova  %rdx,%r8
 29f3539:	mov    (%r8),%esi
 29f353c:	cmp    %esi,%r15d
 29f353f:	jae    29f48bc <wasm[0]::function[1009]::helper::array_packed_join+0x1a1c>
 29f3545:	mov    %esi,%r8d
 29f3548:	shl    $0x2,%r8
 29f354c:	shr    $0x20,%r8
 29f3550:	test   %r8,%r8
 29f3553:	jne    29f48be <wasm[0]::function[1009]::helper::array_packed_join+0x1a1e>
 29f3559:	shl    $0x2,%esi
 29f355c:	add    $0x14,%esi
 29f355f:	jb     29f48c0 <wasm[0]::function[1009]::helper::array_packed_join+0x1a20>
 29f3565:	add    %esi,%eax
 29f3567:	jb     29f48c2 <wasm[0]::function[1009]::helper::array_packed_join+0x1a22>
 29f356d:	mov    %eax,%r8d
 29f3570:	add    %r8,%rdi
 29f3573:	cmp    %rcx,%r8
 29f3576:	cmova  %rdx,%rdi
 29f357a:	mov    %r15,%r8
 29f357d:	shl    $0x2,%r8d
 29f3581:	add    $0x14,%r8d
 29f3588:	sub    %r8d,%esi
 29f358b:	sub    %rsi,%rdi
 29f358e:	mov    (%rdi),%edi
 29f3590:	mov    0x8(%rsp),%ecx
 29f3594:	xor    %edx,%edx
 29f3596:	test   %edi,%edi
 29f3598:	je     29f35dc <wasm[0]::function[1009]::helper::array_packed_join+0x73c>
 29f359e:	test   %edi,%edi
 29f35a0:	je     29f48c4 <wasm[0]::function[1009]::helper::array_packed_join+0x1a24>
 29f35a6:	test   %edi,%edi
 29f35a8:	je     29f48c6 <wasm[0]::function[1009]::helper::array_packed_join+0x1a26>
 29f35ae:	mov    0x28(%r12),%rax
 29f35b3:	mov    0x20(%r12),%rdx
 29f35b8:	mov    %edi,%ecx
 29f35ba:	lea    (%rdx,%rcx,1),%r11
 29f35be:	xor    %rdx,%rdx
 29f35c1:	cmp    %rax,%rcx
 29f35c4:	cmova  %rdx,%r11
 29f35c8:	mov    0x18(%r11),%r14d
 29f35cc:	mov    0x10(%r11),%r10
 29f35d0:	mov    0x1c(%r11),%ecx
 29f35d4:	mov    0xc0(%rsp),%rdx
 29f35dc:	mov    0x10(%rsp),%eax
 29f35e0:	mov    (%rsp),%edi
 29f35e3:	xor    %esi,%esi
 29f35e5:	test   %edx,%edx
 29f35e7:	je     29f4558 <wasm[0]::function[1009]::helper::array_packed_join+0x16b8>
 29f35ed:	cmp    $0x4,%r14d
 29f35f1:	je     29f362b <wasm[0]::function[1009]::helper::array_packed_join+0x78b>
 29f35f7:	mov    0x10(%rsp),%eax
 29f35fb:	mov    (%rsp),%edi
 29f35fe:	cmp    $0x1,%r14d
 29f3602:	sete   %dl
 29f3605:	xor    %esi,%esi
 29f3607:	test   %r14d,%r14d
 29f360a:	mov    %r14,0x88(%rsp)
 29f3612:	sete   %r8b
 29f3616:	or     %r8d,%edx
 29f3619:	movzbl %dl,%edx
 29f361c:	test   %edx,%edx
 29f361e:	je     29f4558 <wasm[0]::function[1009]::helper::array_packed_join+0x16b8>
 29f3624:	xor    %eax,%eax
 29f3626:	jmp    29f36ce <wasm[0]::function[1009]::helper::array_packed_join+0x82e>
 29f362b:	mov    %r14,0x88(%rsp)
 29f3633:	xor    %eax,%eax
 29f3635:	test   %ecx,%ecx
 29f3637:	je     29f3678 <wasm[0]::function[1009]::helper::array_packed_join+0x7d8>
 29f363d:	xor    %eax,%eax
 29f363f:	test   $0x1,%ecx
 29f3645:	jne    29f3678 <wasm[0]::function[1009]::helper::array_packed_join+0x7d8>
 29f364b:	mov    0x28(%r12),%rax
 29f3650:	mov    0x20(%r12),%rdx
 29f3655:	mov    %ecx,%esi
 29f3657:	lea    0x4(%rdx,%rsi,1),%rdx
 29f365c:	xor    %rdi,%rdi
 29f365f:	cmp    %rax,%rsi
 29f3662:	cmova  %rdi,%rdx
 29f3666:	mov    (%rdx),%eax
 29f3668:	mov    0xb8(%rsp),%rdx
 29f3670:	cmp    %edx,%eax
 29f3672:	sete   %al
 29f3675:	movzbl %al,%eax
 29f3678:	test   %eax,%eax
 29f367a:	je     29f48c8 <wasm[0]::function[1009]::helper::array_packed_join+0x1a28>
 29f3680:	test   %ecx,%ecx
 29f3682:	je     29f48ca <wasm[0]::function[1009]::helper::array_packed_join+0x1a2a>
 29f3688:	test   %ecx,%ecx
 29f368a:	je     29f48cc <wasm[0]::function[1009]::helper::array_packed_join+0x1a2c>
 29f3690:	mov    0x28(%r12),%rax
 29f3695:	mov    0x20(%r12),%rdx
 29f369a:	mov    %ecx,%r8d
 29f369d:	lea    (%rdx,%r8,1),%rdi
 29f36a1:	xor    %rsi,%rsi
 29f36a4:	cmp    %rax,%r8
 29f36a7:	cmova  %rsi,%rdi
 29f36ab:	mov    0x10(%rdi),%edi
 29f36ae:	test   %edi,%edi
 29f36b0:	je     29f48ce <wasm[0]::function[1009]::helper::array_packed_join+0x1a2e>
 29f36b6:	test   %edi,%edi
 29f36b8:	je     29f48d0 <wasm[0]::function[1009]::helper::array_packed_join+0x1a30>
 29f36be:	mov    %edi,%edi
 29f36c0:	lea    0x10(%rdx,%rdi,1),%rdx
 29f36c5:	cmp    %rax,%rdi
 29f36c8:	cmova  %rsi,%rdx
 29f36cc:	mov    (%rdx),%eax
 29f36ce:	test   %r15,%r15
 29f36d1:	je     29f36e2 <wasm[0]::function[1009]::helper::array_packed_join+0x842>
 29f36d7:	mov    0xb0(%rsp),%rdx
 29f36df:	add    %rdx,%r13
 29f36e2:	mov    %eax,%eax
 29f36e4:	add    %rax,%r13
 29f36e7:	cmp    0x1262(%rip),%r13        # 29f4950 <wasm[0]::function[1009]::helper::array_packed_join+0x1ab0>
 29f36ee:	jbe    29f36fe <wasm[0]::function[1009]::helper::array_packed_join+0x85e>
 29f36f4:	movabs $0x100000000,%r13
 29f36fe:	mov    0x38(%rsp),%edx
 29f3702:	mov    0x10(%rsp),%eax
 29f3706:	mov    (%rsp),%esi
 29f3709:	add    $0x1,%r15
 29f3710:	mov    0x88(%rsp),%r14
 29f3718:	mov    %r10,0x70(%rsp)
 29f371d:	jmp    29f316e <wasm[0]::function[1009]::helper::array_packed_join+0x2ce>
 29f3722:	mov    %r14,0x88(%rsp)
 29f372a:	cmp    0x121f(%rip),%r13        # 29f4950 <wasm[0]::function[1009]::helper::array_packed_join+0x1ab0>
 29f3731:	ja     29f48d2 <wasm[0]::function[1009]::helper::array_packed_join+0x1a32>
 29f3737:	test   %r13,%r13
 29f373a:	je     29f4534 <wasm[0]::function[1009]::helper::array_packed_join+0x1694>
 29f3740:	mov    0x68(%rsp),%rcx
 29f3745:	cmp    $0x1,%rcx
 29f3749:	je     29f4528 <wasm[0]::function[1009]::helper::array_packed_join+0x1688>
 29f374f:	mov    %r13d,%r14d
 29f3752:	mov    %r14,%rcx
 29f3755:	shl    $1,%rcx
 29f3758:	mov    %rcx,%rsi
 29f375b:	shr    $0x20,%rsi
 29f375f:	mov    %rcx,0x70(%rsp)
 29f3764:	test   %rsi,%rsi
 29f3767:	jne    29f48d4 <wasm[0]::function[1009]::helper::array_packed_join+0x1a34>
 29f376d:	mov    %r13,%rcx
 29f3770:	shl    $1,%ecx
 29f3772:	add    $0x14,%ecx
 29f3775:	jb     29f48d6 <wasm[0]::function[1009]::helper::array_packed_join+0x1a36>
 29f377b:	mov    0x60(%rsp),%rax
 29f3780:	mov    0x20(%rax),%r8
 29f3784:	mov    (%r8),%eax
 29f3787:	mov    %eax,%edi
 29f3789:	mov    %ecx,%r9d
 29f378c:	lea    0xf(%r9),%rdx
 29f3790:	mov    %rdx,%r9
 29f3793:	and    $0xfffffffffffffff0,%r9
 29f3797:	add    %rdi,%r9
 29f379a:	mov    0x4(%r8),%r10d
 29f379e:	mov    %r8,0xa8(%rsp)
 29f37a6:	cmp    %r10,%r9
 29f37a9:	ja     29f4651 <wasm[0]::function[1009]::helper::array_packed_join+0x17b1>
 29f37af:	mov    0x78(%rsp),%rbx
 29f37b4:	lea    0xf(%rcx),%r9d
 29f37b8:	and    $0xfffffff0,%r9d
 29f37bc:	lea    (%rax,%r9,1),%r10d
 29f37c0:	mov    0xa8(%rsp),%r15
 29f37c8:	mov    %r10d,(%r15)
 29f37cb:	mov    0x20(%r12),%r11
 29f37d0:	lea    (%r11,%rdi,1),%rsi
 29f37d4:	movl   $0xa8000006,(%r11,%rdi,1)
 29f37dc:	mov    0x238(%rbx),%ecx
 29f37e2:	mov    %ecx,0x4(%r11,%rdi,1)
 29f37e7:	and    $0xfffffffffffffff0,%rdx
 29f37eb:	mov    %edx,0x8(%r11,%rdi,1)
 29f37f0:	mov    %eax,0x10(%rsp)
 29f37f4:	mov    %r13d,0x10(%rsi)
 29f37f8:	test   %eax,%eax
 29f37fa:	je     29f48d8 <wasm[0]::function[1009]::helper::array_packed_join+0x1a38>
 29f3800:	mov    0x28(%r12),%rcx
 29f3805:	mov    0x20(%r12),%rdx
 29f380a:	mov    %eax,%eax
 29f380c:	lea    0x10(%rdx,%rax,1),%rsi
 29f3811:	xor    %rdi,%rdi
 29f3814:	cmp    %rcx,%rax
 29f3817:	cmova  %rdi,%rsi
 29f381b:	mov    (%rsi),%esi
 29f381d:	cmp    %rsi,%r14
 29f3820:	ja     29f48da <wasm[0]::function[1009]::helper::array_packed_join+0x1a3a>
 29f3826:	lea    0x14(%rdx,%rax,1),%rsi
 29f382b:	mov    0x70(%rsp),%rdi
 29f3830:	mov    %rsi,%rax
 29f3833:	add    %rdi,%rax
 29f3836:	mov    %rsi,%r14
 29f3839:	jb     29f48dc <wasm[0]::function[1009]::helper::array_packed_join+0x1a3c>
 29f383f:	add    %rdx,%rcx
 29f3842:	cmp    %rcx,%rax
 29f3845:	ja     29f48de <wasm[0]::function[1009]::helper::array_packed_join+0x1a3e>
 29f384b:	mov    0x38(%rsp),%esi
 29f384f:	mov    0x40(%rsp),%edx
 29f3853:	mov    0x8(%rsp),%ecx
 29f3857:	mov    (%rsp),%eax
 29f385a:	cmp    $0x8000000,%rdi
 29f3861:	jbe    29f38eb <wasm[0]::function[1009]::helper::array_packed_join+0xa4b>
 29f3867:	mov    %esi,0x18(%rsp)
 29f386b:	mov    %edx,0x30(%rsp)
 29f386f:	mov    %ecx,0x40(%rsp)
 29f3873:	mov    %eax,0x38(%rsp)
 29f3877:	mov    0xd0(%rsp),%r13
 29f387f:	mov    0x0(%r13),%rax
 29f3883:	mov    0x90(%rsp),%rcx
 29f388b:	cmp    %rcx,%rax
 29f388e:	jae    29f467d <wasm[0]::function[1009]::helper::array_packed_join+0x17dd>
 29f3894:	xor    %edx,%edx
 29f3896:	mov    $0x8000000,%ecx
 29f389b:	mov    %r14,%rsi
 29f389e:	mov    0x60(%rsp),%rdi
 29f38a3:	call   3039b13 <wasmtime_builtin_memory_fill>
 29f38a8:	mov    0x18(%rsp),%esi
 29f38ac:	mov    0x30(%rsp),%edx
 29f38b0:	mov    0x40(%rsp),%ecx
 29f38b4:	mov    0x38(%rsp),%eax
 29f38b8:	mov    0x70(%rsp),%r10
 29f38bd:	mov    %r10,%r11
 29f38c0:	sub    $0x8000000,%r11
 29f38c7:	mov    %r14,%rdi
 29f38ca:	mov    %r11,0x70(%rsp)
 29f38cf:	add    $0x8000000,%rdi
 29f38d6:	mov    %rdi,%r14
 29f38d9:	mov    0x70(%rsp),%rdi
 29f38de:	cmp    $0x8000000,%rdi
 29f38e5:	ja     29f3867 <wasm[0]::function[1009]::helper::array_packed_join+0x9c7>
 29f38eb:	mov    %esi,0x38(%rsp)
 29f38ef:	mov    %edx,0x40(%rsp)
 29f38f3:	mov    %ecx,0x30(%rsp)
 29f38f7:	mov    %eax,0x18(%rsp)
 29f38fb:	mov    0xd0(%rsp),%r13
 29f3903:	mov    0x0(%r13),%rax
 29f3907:	mov    0x90(%rsp),%rsi
 29f390f:	cmp    %rsi,%rax
 29f3912:	jae    29f46aa <wasm[0]::function[1009]::helper::array_packed_join+0x180a>
 29f3918:	xor    %ebx,%ebx
 29f391a:	mov    0x70(%rsp),%rcx
 29f391f:	mov    %r14,%rsi
 29f3922:	mov    %rbx,%rdx
 29f3925:	mov    0x60(%rsp),%rdi
 29f392a:	call   3039b13 <wasmtime_builtin_memory_fill>
 29f392f:	mov    %rbx,0x78(%rsp)
 29f3934:	mov    0x10(%rsp),%ecx
 29f3938:	mov    0x38(%rsp),%esi
 29f393c:	mov    %rsi,0x70(%rsp)
 29f3941:	mov    0x40(%rsp),%eax
 29f3945:	mov    0x30(%rsp),%edi
 29f3949:	mov    0x18(%rsp),%esi
 29f394d:	xor    %rdx,%rdx
 29f3950:	mov    0xb0(%rsp),%r15
 29f3958:	mov    %rdx,0x80(%rsp)
 29f3960:	shl    $1,%r15
 29f3963:	mov    %r15,0xa0(%rsp)
 29f396b:	mov    %ecx,0x18(%rsp)
 29f396f:	mov    0x70(%rsp),%rcx
 29f3974:	mov    %ecx,0x30(%rsp)
 29f3978:	mov    %eax,0x40(%rsp)
 29f397c:	mov    %edi,0x38(%rsp)
 29f3980:	mov    %esi,0x10(%rsp)
 29f3984:	mov    0xd0(%rsp),%r13
 29f398c:	mov    0x0(%r13),%rax
 29f3990:	mov    0x90(%rsp),%rcx
 29f3998:	cmp    %rcx,%rax
 29f399b:	jae    29f46da <wasm[0]::function[1009]::helper::array_packed_join+0x183a>
 29f39a1:	mov    0x68(%rsp),%rcx
 29f39a6:	mov    0x80(%rsp),%r9
 29f39ae:	jmp    29f39c0 <wasm[0]::function[1009]::helper::array_packed_join+0xb20>
 29f39b3:	mov    0x68(%rsp),%rcx
 29f39b8:	mov    0x80(%rsp),%r9
 29f39c0:	mov    0x68(%rsp),%rcx
 29f39c5:	cmp    %rcx,%r9
 29f39c8:	jae    29f44b3 <wasm[0]::function[1009]::helper::array_packed_join+0x1613>
 29f39ce:	mov    0x40(%rsp),%eax
 29f39d2:	mov    0x38(%rsp),%edi
 29f39d6:	mov    0x18(%rsp),%ecx
 29f39da:	mov    0x30(%rsp),%esi
 29f39de:	mov    %rsi,0x70(%rsp)
 29f39e3:	mov    0x10(%rsp),%esi
 29f39e7:	mov    0x80(%rsp),%rdx
 29f39ef:	mov    0x80(%rsp),%r8
 29f39f7:	test   %r8,%rdx
 29f39fa:	je     29f3d35 <wasm[0]::function[1009]::helper::array_packed_join+0xe95>
 29f3a00:	mov    0x18(%rsp),%esi
 29f3a04:	test   %esi,%esi
 29f3a06:	je     29f48e0 <wasm[0]::function[1009]::helper::array_packed_join+0x1a40>
 29f3a0c:	mov    0x30(%rsp),%edx
 29f3a10:	test   %edx,%edx
 29f3a12:	je     29f48e2 <wasm[0]::function[1009]::helper::array_packed_join+0x1a42>
 29f3a18:	test   %esi,%esi
 29f3a1a:	je     29f48e4 <wasm[0]::function[1009]::helper::array_packed_join+0x1a44>
 29f3a20:	mov    0x28(%r12),%rcx
 29f3a25:	mov    0x20(%r12),%rax
 29f3a2a:	mov    %esi,%r9d
 29f3a2d:	lea    (%rax,%r9,1),%rsi
 29f3a31:	lea    0x10(%rax,%r9,1),%r8
 29f3a36:	xor    %rdi,%rdi
 29f3a39:	cmp    %rcx,%r9
 29f3a3c:	cmova  %rdi,%r8
 29f3a40:	mov    0x78(%rsp),%r14
 29f3a45:	mov    %r14d,%r9d
 29f3a48:	mov    0xb0(%rsp),%r15
 29f3a50:	lea    (%r9,%r15,1),%r10
 29f3a54:	mov    (%r8),%r8d
 29f3a57:	cmp    %r8,%r10
 29f3a5a:	ja     29f48e6 <wasm[0]::function[1009]::helper::array_packed_join+0x1a46>
 29f3a60:	test   %edx,%edx
 29f3a62:	je     29f48e8 <wasm[0]::function[1009]::helper::array_packed_join+0x1a48>
 29f3a68:	mov    %edx,%edx
 29f3a6a:	lea    (%rax,%rdx,1),%r8
 29f3a6e:	lea    0x10(%rax,%rdx,1),%r10
 29f3a73:	cmp    %rcx,%rdx
 29f3a76:	cmova  %rdi,%r10
 29f3a7a:	mov    (%r10),%edi
 29f3a7d:	cmp    %rdi,%r15
 29f3a80:	ja     29f48ea <wasm[0]::function[1009]::helper::array_packed_join+0x1a4a>
 29f3a86:	lea    0x14(%rsi,%r9,2),%r10
 29f3a8b:	mov    0xa0(%rsp),%r15
 29f3a93:	mov    %r10,%rsi
 29f3a96:	add    %r15,%rsi
 29f3a99:	jb     29f48ec <wasm[0]::function[1009]::helper::array_packed_join+0x1a4c>
 29f3a9f:	add    %rax,%rcx
 29f3aa2:	cmp    %rcx,%rsi
 29f3aa5:	ja     29f48ee <wasm[0]::function[1009]::helper::array_packed_join+0x1a4e>
 29f3aab:	lea    0x14(%rax,%rdx,1),%r9
 29f3ab0:	mov    %r9,%rax
 29f3ab3:	add    %r15,%rax
 29f3ab6:	jb     29f48f0 <wasm[0]::function[1009]::helper::array_packed_join+0x1a50>
 29f3abc:	cmp    %rcx,%rax
 29f3abf:	ja     29f48f2 <wasm[0]::function[1009]::helper::array_packed_join+0x1a52>
 29f3ac5:	cmp    %r10,%r9
 29f3ac8:	ja     29f3bd2 <wasm[0]::function[1009]::helper::array_packed_join+0xd32>
 29f3ace:	mov    0x40(%rsp),%eax
 29f3ad2:	mov    0x38(%rsp),%ecx
 29f3ad6:	mov    0x18(%rsp),%edx
 29f3ada:	mov    0x30(%rsp),%esi
 29f3ade:	mov    0x10(%rsp),%edi
 29f3ae2:	mov    0xb0(%rsp),%r15
 29f3aea:	lea    (%r10,%r15,2),%r10
 29f3aee:	mov    %r10,%rbx
 29f3af1:	lea    0x14(%r8,%r15,2),%r9
 29f3af6:	mov    %r9,%r14
 29f3af9:	mov    0xa0(%rsp),%r15
 29f3b01:	cmp    $0x8000000,%r15
 29f3b08:	jbe    29f3b1b <wasm[0]::function[1009]::helper::array_packed_join+0xc7b>
 29f3b0e:	mov    0xa0(%rsp),%r15
 29f3b16:	jmp    29f3b2b <wasm[0]::function[1009]::helper::array_packed_join+0xc8b>
 29f3b1b:	mov    0xa0(%rsp),%r8
 29f3b23:	mov    %rbx,%r9
 29f3b26:	jmp    29f3bbb <wasm[0]::function[1009]::helper::array_packed_join+0xd1b>
 29f3b2b:	mov    %eax,0x28(%rsp)
 29f3b2f:	mov    %ecx,0x20(%rsp)
 29f3b33:	mov    %edx,0x48(%rsp)
 29f3b37:	mov    %esi,0x50(%rsp)
 29f3b3b:	mov    %edi,0x58(%rsp)
 29f3b3f:	mov    0xd0(%rsp),%r13
 29f3b47:	mov    0x0(%r13),%rax
 29f3b4b:	mov    0x90(%rsp),%rcx
 29f3b53:	cmp    %rcx,%rax
 29f3b56:	jae    29f4714 <wasm[0]::function[1009]::helper::array_packed_join+0x1874>
 29f3b5c:	mov    $0x8000000,%ecx
 29f3b61:	mov    %rbx,%rsi
 29f3b64:	sub    $0x8000000,%rsi
 29f3b6b:	mov    %r14,%rdx
 29f3b6e:	mov    %rsi,%rbx
 29f3b71:	sub    $0x8000000,%rdx
 29f3b78:	mov    %rdx,%r14
 29f3b7b:	mov    0x60(%rsp),%rdi
 29f3b80:	call   3039aea <wasmtime_builtin_memory_copy>
 29f3b85:	mov    0x28(%rsp),%eax
 29f3b89:	mov    0x20(%rsp),%ecx
 29f3b8d:	mov    0x48(%rsp),%edx
 29f3b91:	mov    0x50(%rsp),%esi
 29f3b95:	mov    0x58(%rsp),%edi
 29f3b99:	mov    %r15,%r8
 29f3b9c:	sub    $0x8000000,%r8
 29f3ba3:	cmp    $0x8000000,%r8
 29f3baa:	jbe    29f3bb8 <wasm[0]::function[1009]::helper::array_packed_join+0xd18>
 29f3bb0:	mov    %r8,%r15
 29f3bb3:	jmp    29f3b2b <wasm[0]::function[1009]::helper::array_packed_join+0xc8b>
 29f3bb8:	mov    %rbx,%r9
 29f3bbb:	sub    %r8,%r9
 29f3bbe:	mov    %r9,%rbx
 29f3bc1:	mov    %r14,%r9
 29f3bc4:	sub    %r8,%r9
 29f3bc7:	mov    %r9,%r14
 29f3bca:	mov    %r8,%r15
 29f3bcd:	jmp    29f3cac <wasm[0]::function[1009]::helper::array_packed_join+0xe0c>
 29f3bd2:	mov    %r10,%rbx
 29f3bd5:	mov    %r9,%r14
 29f3bd8:	mov    0x40(%rsp),%eax
 29f3bdc:	mov    0x38(%rsp),%ecx
 29f3be0:	mov    0x18(%rsp),%edx
 29f3be4:	mov    0x30(%rsp),%esi
 29f3be8:	mov    0x10(%rsp),%edi
 29f3bec:	mov    0xa0(%rsp),%r15
 29f3bf4:	cmp    $0x8000000,%r15
 29f3bfb:	jbe    29f3c0e <wasm[0]::function[1009]::helper::array_packed_join+0xd6e>
 29f3c01:	mov    0xa0(%rsp),%r15
 29f3c09:	jmp    29f3c1b <wasm[0]::function[1009]::helper::array_packed_join+0xd7b>
 29f3c0e:	mov    0xa0(%rsp),%r15
 29f3c16:	jmp    29f3cac <wasm[0]::function[1009]::helper::array_packed_join+0xe0c>
 29f3c1b:	mov    %eax,0x20(%rsp)
 29f3c1f:	mov    %ecx,0x28(%rsp)
 29f3c23:	mov    %edx,0x30(%rsp)
 29f3c27:	mov    %esi,0x38(%rsp)
 29f3c2b:	mov    %edi,0x40(%rsp)
 29f3c2f:	mov    0xd0(%rsp),%r13
 29f3c37:	mov    0x0(%r13),%rdx
 29f3c3b:	mov    0x90(%rsp),%rax
 29f3c43:	cmp    %rax,%rdx
 29f3c46:	jae    29f4744 <wasm[0]::function[1009]::helper::array_packed_join+0x18a4>
 29f3c4c:	mov    $0x8000000,%ecx
 29f3c51:	mov    %r14,%rdx
 29f3c54:	mov    %rbx,%rsi
 29f3c57:	mov    0x60(%rsp),%rdi
 29f3c5c:	call   3039aea <wasmtime_builtin_memory_copy>
 29f3c61:	mov    0x20(%rsp),%eax
 29f3c65:	mov    0x28(%rsp),%ecx
 29f3c69:	mov    0x30(%rsp),%edx
 29f3c6d:	mov    0x38(%rsp),%esi
 29f3c71:	mov    0x40(%rsp),%edi
 29f3c75:	mov    %r15,%r8
 29f3c78:	sub    $0x8000000,%r8
 29f3c7f:	mov    %r8,%r15
 29f3c82:	mov    %rbx,%r8
 29f3c85:	add    $0x8000000,%r8
 29f3c8c:	mov    %r8,%rbx
 29f3c8f:	mov    %r14,%r8
 29f3c92:	add    $0x8000000,%r8
 29f3c99:	mov    %r8,%r14
 29f3c9c:	mov    %r15,%r8
 29f3c9f:	cmp    $0x8000000,%r8
 29f3ca6:	ja     29f3c1b <wasm[0]::function[1009]::helper::array_packed_join+0xd7b>
 29f3cac:	mov    %eax,0x40(%rsp)
 29f3cb0:	mov    %ecx,0x38(%rsp)
 29f3cb4:	mov    %edx,0x30(%rsp)
 29f3cb8:	mov    %esi,0x28(%rsp)
 29f3cbc:	mov    %edi,0x20(%rsp)
 29f3cc0:	mov    0xd0(%rsp),%r13
 29f3cc8:	mov    0x0(%r13),%rax
 29f3ccc:	mov    0x90(%rsp),%r11
 29f3cd4:	cmp    %r11,%rax
 29f3cd7:	jae    29f4771 <wasm[0]::function[1009]::helper::array_packed_join+0x18d1>
 29f3cdd:	mov    %r15,%rcx
 29f3ce0:	mov    %r14,%rdx
 29f3ce3:	mov    %rbx,%rsi
 29f3ce6:	jmp    29f3cf4 <wasm[0]::function[1009]::helper::array_packed_join+0xe54>
 29f3ceb:	mov    %r15,%rcx
 29f3cee:	mov    %r14,%rdx
 29f3cf1:	mov    %rbx,%rsi
 29f3cf4:	mov    %r15,%rcx
 29f3cf7:	mov    %r14,%rdx
 29f3cfa:	mov    %rbx,%rsi
 29f3cfd:	mov    0x60(%rsp),%rdi
 29f3d02:	call   3039aea <wasmtime_builtin_memory_copy>
 29f3d07:	mov    0x40(%rsp),%eax
 29f3d0b:	mov    0x38(%rsp),%edi
 29f3d0f:	mov    0x30(%rsp),%ecx
 29f3d13:	mov    0x28(%rsp),%esi
 29f3d17:	mov    %rsi,0x70(%rsp)
 29f3d1c:	mov    0x20(%rsp),%esi
 29f3d20:	mov    0x78(%rsp),%r14
 29f3d25:	mov    0xc8(%rsp),%r15
 29f3d2d:	add    %r15d,%r14d
 29f3d30:	mov    %r14,0x78(%rsp)
 29f3d35:	test   %eax,%eax
 29f3d37:	je     29f48f4 <wasm[0]::function[1009]::helper::array_packed_join+0x1a54>
 29f3d3d:	test   %eax,%eax
 29f3d3f:	je     29f48f6 <wasm[0]::function[1009]::helper::array_packed_join+0x1a56>
 29f3d45:	mov    0x28(%r12),%r9
 29f3d4a:	mov    %eax,%r8d
 29f3d4d:	mov    %r8,%r10
 29f3d50:	add    0x20(%r12),%r10
 29f3d55:	xor    %r11,%r11
 29f3d58:	cmp    %r9,%r8
 29f3d5b:	cmova  %r11,%r10
 29f3d5f:	mov    0x24(%r10),%edx
 29f3d63:	cmp    $0x3,%edx
 29f3d66:	je     29f400b <wasm[0]::function[1009]::helper::array_packed_join+0x116b>
 29f3d6c:	mov    0x28(%r12),%r10
 29f3d71:	mov    %r8,%r9
 29f3d74:	add    0x20(%r12),%r9
 29f3d79:	xor    %r11,%r11
 29f3d7c:	cmp    %r10,%r8
 29f3d7f:	cmova  %r11,%r9
 29f3d83:	mov    0x24(%r9),%edx
 29f3d87:	cmp    $0x4,%edx
 29f3d8a:	je     29f3f1f <wasm[0]::function[1009]::helper::array_packed_join+0x107f>
 29f3d90:	mov    0x28(%r12),%r11
 29f3d95:	mov    0x20(%r12),%r13
 29f3d9a:	lea    0x0(%r13,%r8,1),%r9
 29f3d9f:	xor    %rbx,%rbx
 29f3da2:	cmp    %r11,%r8
 29f3da5:	cmova  %rbx,%r9
 29f3da9:	mov    0x28(%r9),%r8d
 29f3dad:	mov    0x2c(%r9),%r10d
 29f3db1:	test   %r8d,%r8d
 29f3db4:	je     29f48f8 <wasm[0]::function[1009]::helper::array_packed_join+0x1a58>
 29f3dba:	test   %r8d,%r8d
 29f3dbd:	je     29f48fa <wasm[0]::function[1009]::helper::array_packed_join+0x1a5a>
 29f3dc3:	mov    %r8d,%r9d
 29f3dc6:	lea    0x10(%r13,%r9,1),%r13
 29f3dcb:	cmp    %r11,%r9
 29f3dce:	cmova  %rbx,%r13
 29f3dd2:	mov    0x0(%r13),%edx
 29f3dd6:	mov    0x80(%rsp),%r11
 29f3dde:	cmp    %rdx,%r11
 29f3de1:	jae    29f3ffe <wasm[0]::function[1009]::helper::array_packed_join+0x115e>
 29f3de7:	test   %r10d,%r10d
 29f3dea:	je     29f48fc <wasm[0]::function[1009]::helper::array_packed_join+0x1a5c>
 29f3df0:	test   %r10d,%r10d
 29f3df3:	je     29f48fe <wasm[0]::function[1009]::helper::array_packed_join+0x1a5e>
 29f3df9:	mov    0x28(%r12),%r11
 29f3dfe:	mov    0x20(%r12),%r14
 29f3e03:	mov    %r10d,%r13d
 29f3e06:	lea    0x10(%r14,%r13,1),%rbx
 29f3e0b:	xor    %r15,%r15
 29f3e0e:	cmp    %r11,%r13
 29f3e11:	cmova  %r15,%rbx
 29f3e15:	mov    (%rbx),%ebx
 29f3e17:	mov    0x80(%rsp),%rdx
 29f3e1f:	mov    %rdx,%r13
 29f3e22:	shr    $0x6,%r13d
 29f3e26:	cmp    %ebx,%r13d
 29f3e29:	jae    29f4900 <wasm[0]::function[1009]::helper::array_packed_join+0x1a60>
 29f3e2f:	mov    %ebx,%edx
 29f3e31:	shl    $0x3,%rdx
 29f3e35:	shr    $0x20,%rdx
 29f3e39:	test   %rdx,%rdx
 29f3e3c:	jne    29f4902 <wasm[0]::function[1009]::helper::array_packed_join+0x1a62>
 29f3e42:	shl    $0x3,%ebx
 29f3e45:	add    $0x18,%ebx
 29f3e48:	jb     29f4904 <wasm[0]::function[1009]::helper::array_packed_join+0x1a64>
 29f3e4e:	add    %ebx,%r10d
 29f3e51:	jb     29f4906 <wasm[0]::function[1009]::helper::array_packed_join+0x1a66>
 29f3e57:	mov    %r10d,%edx
 29f3e5a:	lea    (%r14,%rdx,1),%r10
 29f3e5e:	cmp    %r11,%rdx
 29f3e61:	cmova  %r15,%r10
 29f3e65:	shl    $0x3,%r13d
 29f3e69:	lea    0x18(%r13),%edx
 29f3e6d:	sub    %edx,%ebx
 29f3e6f:	sub    %rbx,%r10
 29f3e72:	mov    (%r10),%rdx
 29f3e75:	mov    0x80(%rsp),%r10
 29f3e7d:	bt     %r10,%rdx
 29f3e81:	jae    29f3ffe <wasm[0]::function[1009]::helper::array_packed_join+0x115e>
 29f3e87:	mov    0x28(%r12),%rdi
 29f3e8c:	mov    0x20(%r12),%r11
 29f3e91:	lea    0x10(%r11,%r9,1),%rbx
 29f3e96:	xor    %r10,%r10
 29f3e99:	cmp    %rdi,%r9
 29f3e9c:	cmova  %r10,%rbx
 29f3ea0:	mov    (%rbx),%r9d
 29f3ea3:	mov    0x80(%rsp),%rdx
 29f3eab:	cmp    %r9d,%edx
 29f3eae:	jae    29f4908 <wasm[0]::function[1009]::helper::array_packed_join+0x1a68>
 29f3eb4:	mov    %r9d,%edx
 29f3eb7:	shl    $0x3,%rdx
 29f3ebb:	shr    $0x20,%rdx
 29f3ebf:	test   %rdx,%rdx
 29f3ec2:	jne    29f490a <wasm[0]::function[1009]::helper::array_packed_join+0x1a6a>
 29f3ec8:	mov    $0x3,%r14d
 29f3ece:	mov    %r14,0x88(%rsp)
 29f3ed6:	shl    $0x3,%r9d
 29f3eda:	add    $0x18,%r9d
 29f3ede:	jb     29f490c <wasm[0]::function[1009]::helper::array_packed_join+0x1a6c>
 29f3ee4:	add    %r9d,%r8d
 29f3ee7:	jb     29f490e <wasm[0]::function[1009]::helper::array_packed_join+0x1a6e>
 29f3eed:	mov    %r8d,%edx
 29f3ef0:	lea    (%r11,%rdx,1),%r8
 29f3ef4:	cmp    %rdi,%rdx
 29f3ef7:	cmova  %r10,%r8
 29f3efb:	mov    0x80(%rsp),%rdx
 29f3f03:	mov    %rdx,%rdi
 29f3f06:	shl    $0x3,%edi
 29f3f09:	add    $0x18,%edi
 29f3f0f:	sub    %edi,%r9d
 29f3f12:	sub    %r9,%r8
 29f3f15:	mov    (%r8),%rdi
 29f3f18:	xor    %edi,%edi
 29f3f1a:	jmp    29f3ffe <wasm[0]::function[1009]::helper::array_packed_join+0x115e>
 29f3f1f:	mov    0x28(%r12),%r10
 29f3f24:	mov    %r8,%r9
 29f3f27:	add    0x20(%r12),%r9
 29f3f2c:	xor    %r11,%r11
 29f3f2f:	cmp    %r10,%r8
 29f3f32:	cmova  %r11,%r9
 29f3f36:	mov    0x18(%r9),%r11
 29f3f3a:	mov    0x80(%rsp),%rdx
 29f3f42:	cmp    %r11,%rdx
 29f3f45:	jae    29f3ffe <wasm[0]::function[1009]::helper::array_packed_join+0x115e>
 29f3f4b:	mov    0x28(%r12),%r9
 29f3f50:	mov    0x20(%r12),%r11
 29f3f55:	lea    (%r11,%r8,1),%rdi
 29f3f59:	xor    %r10,%r10
 29f3f5c:	cmp    %r9,%r8
 29f3f5f:	cmova  %r10,%rdi
 29f3f63:	mov    0x28(%rdi),%r8d
 29f3f67:	xor    %edi,%edi
 29f3f69:	test   %r8d,%r8d
 29f3f6c:	je     29f4910 <wasm[0]::function[1009]::helper::array_packed_join+0x1a70>
 29f3f72:	test   %r8d,%r8d
 29f3f75:	je     29f4912 <wasm[0]::function[1009]::helper::array_packed_join+0x1a72>
 29f3f7b:	mov    %r8d,%ebx
 29f3f7e:	lea    0x10(%r11,%rbx,1),%rdx
 29f3f83:	cmp    %r9,%rbx
 29f3f86:	cmova  %r10,%rdx
 29f3f8a:	mov    (%rdx),%r14d
 29f3f8d:	mov    0x80(%rsp),%rdx
 29f3f95:	cmp    %r14d,%edx
 29f3f98:	jae    29f4914 <wasm[0]::function[1009]::helper::array_packed_join+0x1a74>
 29f3f9e:	mov    %r14d,%edx
 29f3fa1:	shl    $0x3,%rdx
 29f3fa5:	shr    $0x20,%rdx
 29f3fa9:	test   %rdx,%rdx
 29f3fac:	jne    29f4916 <wasm[0]::function[1009]::helper::array_packed_join+0x1a76>
 29f3fb2:	mov    $0x3,%edx
 29f3fb7:	mov    %rdx,0x88(%rsp)
 29f3fbf:	shl    $0x3,%r14d
 29f3fc3:	add    $0x18,%r14d
 29f3fc7:	jb     29f4918 <wasm[0]::function[1009]::helper::array_packed_join+0x1a78>
 29f3fcd:	add    %r14d,%r8d
 29f3fd0:	jb     29f491a <wasm[0]::function[1009]::helper::array_packed_join+0x1a7a>
 29f3fd6:	mov    %r8d,%edx
 29f3fd9:	lea    (%r11,%rdx,1),%r8
 29f3fdd:	cmp    %r9,%rdx
 29f3fe0:	cmova  %r10,%r8
 29f3fe4:	mov    0x80(%rsp),%rdx
 29f3fec:	shl    $0x3,%edx
 29f3fef:	add    $0x18,%edx
 29f3ff5:	sub    %edx,%r14d
 29f3ff8:	sub    %r14,%r8
 29f3ffb:	mov    (%r8),%rdx
 29f3ffe:	mov    0x88(%rsp),%r14
 29f4006:	jmp    29f412c <wasm[0]::function[1009]::helper::array_packed_join+0x128c>
 29f400b:	mov    0x28(%r12),%r9
 29f4010:	mov    0x20(%r12),%r11
 29f4015:	lea    (%r11,%r8,1),%rbx
 29f4019:	xor    %r10,%r10
 29f401c:	cmp    %r9,%r8
 29f401f:	cmova  %r10,%rbx
 29f4023:	mov    0x30(%rbx),%r8d
 29f4027:	test   %r8d,%r8d
 29f402a:	je     29f491c <wasm[0]::function[1009]::helper::array_packed_join+0x1a7c>
 29f4030:	test   %r8d,%r8d
 29f4033:	je     29f491e <wasm[0]::function[1009]::helper::array_packed_join+0x1a7e>
 29f4039:	mov    %r8d,%r13d
 29f403c:	lea    0x10(%r11,%r13,1),%rdx
 29f4041:	cmp    %r9,%r13
 29f4044:	cmova  %r10,%rdx
 29f4048:	mov    (%rdx),%edx
 29f404a:	mov    0x80(%rsp),%r9
 29f4052:	cmp    %rdx,%r9
 29f4055:	jae    29f4124 <wasm[0]::function[1009]::helper::array_packed_join+0x1284>
 29f405b:	mov    0x28(%r12),%r9
 29f4060:	mov    0x20(%r12),%rbx
 29f4065:	lea    0x10(%rbx,%r13,1),%r11
 29f406a:	xor    %r10,%r10
 29f406d:	cmp    %r9,%r13
 29f4070:	cmova  %r10,%r11
 29f4074:	mov    (%r11),%r11d
 29f4077:	mov    0x80(%rsp),%rdx
 29f407f:	cmp    %r11d,%edx
 29f4082:	jae    29f4920 <wasm[0]::function[1009]::helper::array_packed_join+0x1a80>
 29f4088:	mov    %r11d,%edx
 29f408b:	shl    $0x2,%rdx
 29f408f:	shr    $0x20,%rdx
 29f4093:	test   %rdx,%rdx
 29f4096:	jne    29f4922 <wasm[0]::function[1009]::helper::array_packed_join+0x1a82>
 29f409c:	shl    $0x2,%r11d
 29f40a0:	add    $0x14,%r11d
 29f40a4:	jb     29f4924 <wasm[0]::function[1009]::helper::array_packed_join+0x1a84>
 29f40aa:	add    %r11d,%r8d
 29f40ad:	jb     29f4926 <wasm[0]::function[1009]::helper::array_packed_join+0x1a86>
 29f40b3:	mov    %r8d,%edx
 29f40b6:	lea    (%rbx,%rdx,1),%r8
 29f40ba:	cmp    %r9,%rdx
 29f40bd:	cmova  %r10,%r8
 29f40c1:	mov    0x80(%rsp),%rdx
 29f40c9:	shl    $0x2,%edx
 29f40cc:	add    $0x14,%edx
 29f40d2:	sub    %edx,%r11d
 29f40d5:	sub    %r11,%r8
 29f40d8:	mov    (%r8),%r8d
 29f40db:	test   %r8d,%r8d
 29f40de:	je     29f4124 <wasm[0]::function[1009]::helper::array_packed_join+0x1284>
 29f40e4:	test   %r8d,%r8d
 29f40e7:	je     29f4928 <wasm[0]::function[1009]::helper::array_packed_join+0x1a88>
 29f40ed:	test   %r8d,%r8d
 29f40f0:	je     29f492a <wasm[0]::function[1009]::helper::array_packed_join+0x1a8a>
 29f40f6:	mov    0x28(%r12),%r9
 29f40fb:	mov    0x20(%r12),%rdx
 29f4100:	mov    %r8d,%r8d
 29f4103:	lea    (%rdx,%r8,1),%rdi
 29f4107:	xor    %r10,%r10
 29f410a:	cmp    %r9,%r8
 29f410d:	cmova  %r10,%rdi
 29f4111:	mov    0x18(%rdi),%r14d
 29f4115:	mov    %r14,0x88(%rsp)
 29f411d:	mov    0x10(%rdi),%rdx
 29f4121:	mov    0x1c(%rdi),%edi
 29f4124:	mov    0x88(%rsp),%r14
 29f412c:	cmp    $0x4,%r14d
 29f4130:	je     29f4143 <wasm[0]::function[1009]::helper::array_packed_join+0x12a3>
 29f4136:	mov    0x80(%rsp),%rdx
 29f413e:	jmp    29f449f <wasm[0]::function[1009]::helper::array_packed_join+0x15ff>
 29f4143:	xor    %r8d,%r8d
 29f4146:	test   %edi,%edi
 29f4148:	je     29f418f <wasm[0]::function[1009]::helper::array_packed_join+0x12ef>
 29f414e:	xor    %r8d,%r8d
 29f4151:	test   $0x1,%edi
 29f4157:	jne    29f418f <wasm[0]::function[1009]::helper::array_packed_join+0x12ef>
 29f415d:	mov    0x28(%r12),%r8
 29f4162:	mov    0x20(%r12),%r9
 29f4167:	mov    %edi,%r10d
 29f416a:	lea    0x4(%r9,%r10,1),%r9
 29f416f:	xor    %r11,%r11
 29f4172:	cmp    %r8,%r10
 29f4175:	cmova  %r11,%r9
 29f4179:	mov    (%r9),%r8d
 29f417c:	mov    0xb8(%rsp),%rdx
 29f4184:	cmp    %edx,%r8d
 29f4187:	sete   %r8b
 29f418b:	movzbl %r8b,%r8d
 29f418f:	test   %r8d,%r8d
 29f4192:	je     29f492c <wasm[0]::function[1009]::helper::array_packed_join+0x1a8c>
 29f4198:	test   %edi,%edi
 29f419a:	je     29f492e <wasm[0]::function[1009]::helper::array_packed_join+0x1a8e>
 29f41a0:	test   %edi,%edi
 29f41a2:	je     29f4930 <wasm[0]::function[1009]::helper::array_packed_join+0x1a90>
 29f41a8:	mov    0x28(%r12),%r9
 29f41ad:	mov    0x20(%r12),%r8
 29f41b2:	mov    %edi,%r11d
 29f41b5:	lea    (%r8,%r11,1),%r10
 29f41b9:	xor    %r14,%r14
 29f41bc:	cmp    %r9,%r11
 29f41bf:	cmova  %r14,%r10
 29f41c3:	mov    0x10(%r10),%r10d
 29f41c7:	test   %r10d,%r10d
 29f41ca:	je     29f4932 <wasm[0]::function[1009]::helper::array_packed_join+0x1a92>
 29f41d0:	test   %r10d,%r10d
 29f41d3:	je     29f4934 <wasm[0]::function[1009]::helper::array_packed_join+0x1a94>
 29f41d9:	mov    %r10d,%r11d
 29f41dc:	lea    (%r8,%r11,1),%r10
 29f41e0:	lea    0x10(%r8,%r11,1),%rdx
 29f41e5:	cmp    %r9,%r11
 29f41e8:	cmova  %r14,%rdx
 29f41ec:	mov    (%rdx),%edx
 29f41ee:	mov    %rdx,0x98(%rsp)
 29f41f6:	test   %ecx,%ecx
 29f41f8:	je     29f4936 <wasm[0]::function[1009]::helper::array_packed_join+0x1a96>
 29f41fe:	test   %ecx,%ecx
 29f4200:	je     29f4938 <wasm[0]::function[1009]::helper::array_packed_join+0x1a98>
 29f4206:	mov    %ecx,%edx
 29f4208:	lea    (%r8,%rdx,1),%r13
 29f420c:	lea    0x10(%r8,%rdx,1),%r15
 29f4211:	cmp    %r9,%rdx
 29f4214:	cmova  %r14,%r15
 29f4218:	mov    0x78(%rsp),%r14
 29f421d:	mov    %r14d,%r14d
 29f4220:	mov    0x98(%rsp),%rdx
 29f4228:	mov    %edx,%ebx
 29f422a:	lea    (%r14,%rbx,1),%rdx
 29f422e:	mov    (%r15),%r15d
 29f4231:	cmp    %r15,%rdx
 29f4234:	ja     29f493a <wasm[0]::function[1009]::helper::array_packed_join+0x1a9a>
 29f423a:	lea    0x14(%r13,%r14,2),%r14
 29f423f:	mov    %rbx,%r13
 29f4242:	shl    $1,%r13
 29f4245:	mov    %r14,%rdx
 29f4248:	add    %r13,%rdx
 29f424b:	jb     29f493c <wasm[0]::function[1009]::helper::array_packed_join+0x1a9c>
 29f4251:	add    %r8,%r9
 29f4254:	cmp    %r9,%rdx
 29f4257:	ja     29f493e <wasm[0]::function[1009]::helper::array_packed_join+0x1a9e>
 29f425d:	lea    0x14(%r8,%r11,1),%r8
 29f4262:	mov    %r8,%rdx
 29f4265:	add    %r13,%rdx
 29f4268:	jb     29f4940 <wasm[0]::function[1009]::helper::array_packed_join+0x1aa0>
 29f426e:	cmp    %r9,%rdx
 29f4271:	ja     29f4942 <wasm[0]::function[1009]::helper::array_packed_join+0x1aa2>
 29f4277:	cmp    %r14,%r8
 29f427a:	ja     29f4358 <wasm[0]::function[1009]::helper::array_packed_join+0x14b8>
 29f4280:	lea    (%r14,%rbx,2),%r14
 29f4284:	lea    0x14(%r10,%rbx,2),%r8
 29f4289:	mov    %r8,%r15
 29f428c:	cmp    $0x8000000,%r13
 29f4293:	mov    %r13,%rbx
 29f4296:	ja     29f42a7 <wasm[0]::function[1009]::helper::array_packed_join+0x1407>
 29f429c:	mov    %r14,%rdx
 29f429f:	mov    %rbx,%r8
 29f42a2:	jmp    29f4341 <wasm[0]::function[1009]::helper::array_packed_join+0x14a1>
 29f42a7:	mov    %ecx,0x20(%rsp)
 29f42ab:	mov    0x70(%rsp),%rcx
 29f42b0:	mov    %ecx,0x28(%rsp)
 29f42b4:	mov    %eax,0x30(%rsp)
 29f42b8:	mov    %edi,0x38(%rsp)
 29f42bc:	mov    %esi,0x40(%rsp)
 29f42c0:	mov    0xd0(%rsp),%r13
 29f42c8:	mov    0x0(%r13),%rax
 29f42cc:	mov    0x90(%rsp),%rcx
 29f42d4:	cmp    %rcx,%rax
 29f42d7:	jae    29f47a7 <wasm[0]::function[1009]::helper::array_packed_join+0x1907>
 29f42dd:	mov    $0x8000000,%ecx
 29f42e2:	mov    %r14,%rsi
 29f42e5:	sub    $0x8000000,%rsi
 29f42ec:	mov    %r15,%rdx
 29f42ef:	mov    %rsi,%r14
 29f42f2:	sub    $0x8000000,%rdx
 29f42f9:	mov    %rdx,%r15
 29f42fc:	mov    0x60(%rsp),%rdi
 29f4301:	call   3039aea <wasmtime_builtin_memory_copy>
 29f4306:	mov    0x20(%rsp),%ecx
 29f430a:	mov    0x28(%rsp),%esi
 29f430e:	mov    %rsi,0x70(%rsp)
 29f4313:	mov    0x30(%rsp),%eax
 29f4317:	mov    0x38(%rsp),%edi
 29f431b:	mov    0x40(%rsp),%esi
 29f431f:	mov    %rbx,%r8
 29f4322:	sub    $0x8000000,%r8
 29f4329:	cmp    $0x8000000,%r8
 29f4330:	jbe    29f433e <wasm[0]::function[1009]::helper::array_packed_join+0x149e>
 29f4336:	mov    %r8,%rbx
 29f4339:	jmp    29f42a7 <wasm[0]::function[1009]::helper::array_packed_join+0x1407>
 29f433e:	mov    %r14,%rdx
 29f4341:	sub    %r8,%rdx
 29f4344:	mov    %rdx,%r14
 29f4347:	mov    %r15,%rdx
 29f434a:	sub    %r8,%rdx
 29f434d:	mov    %rdx,%r15
 29f4350:	mov    %r8,%rbx
 29f4353:	jmp    29f4409 <wasm[0]::function[1009]::helper::array_packed_join+0x1569>
 29f4358:	mov    %r8,%r15
 29f435b:	mov    %r13,%r8
 29f435e:	cmp    $0x8000000,%r8
 29f4365:	mov    %r8,%rbx
 29f4368:	jbe    29f4409 <wasm[0]::function[1009]::helper::array_packed_join+0x1569>
 29f436e:	mov    %ecx,0x40(%rsp)
 29f4372:	mov    0x70(%rsp),%rcx
 29f4377:	mov    %ecx,0x38(%rsp)
 29f437b:	mov    %eax,0x30(%rsp)
 29f437f:	mov    %edi,0x28(%rsp)
 29f4383:	mov    %esi,0x20(%rsp)
 29f4387:	mov    0xd0(%rsp),%r13
 29f438f:	mov    0x0(%r13),%rdx
 29f4393:	mov    0x90(%rsp),%rax
 29f439b:	cmp    %rax,%rdx
 29f439e:	jae    29f47d4 <wasm[0]::function[1009]::helper::array_packed_join+0x1934>
 29f43a4:	mov    $0x8000000,%ecx
 29f43a9:	mov    %r15,%rdx
 29f43ac:	mov    %r14,%rsi
 29f43af:	mov    0x60(%rsp),%rdi
 29f43b4:	call   3039aea <wasmtime_builtin_memory_copy>
 29f43b9:	mov    0x40(%rsp),%ecx
 29f43bd:	mov    0x38(%rsp),%esi
 29f43c1:	mov    %rsi,0x70(%rsp)
 29f43c6:	mov    0x30(%rsp),%eax
 29f43ca:	mov    0x28(%rsp),%edi
 29f43ce:	mov    0x20(%rsp),%esi
 29f43d2:	mov    %rbx,%rdx
 29f43d5:	sub    $0x8000000,%rdx
 29f43dc:	mov    %rdx,%rbx
 29f43df:	mov    %r14,%r9
 29f43e2:	lea    0x8000000(%r9),%r10
 29f43e9:	mov    %r15,%rdx
 29f43ec:	mov    %r10,%r14
 29f43ef:	add    $0x8000000,%rdx
 29f43f6:	mov    %rdx,%r15
 29f43f9:	mov    %rbx,%rdx
 29f43fc:	cmp    $0x8000000,%rdx
 29f4403:	ja     29f436e <wasm[0]::function[1009]::helper::array_packed_join+0x14ce>
 29f4409:	mov    %ecx,0x20(%rsp)
 29f440d:	mov    0x70(%rsp),%rcx
 29f4412:	mov    %ecx,0x28(%rsp)
 29f4416:	mov    %eax,0x30(%rsp)
 29f441a:	mov    %edi,0x38(%rsp)
 29f441e:	mov    %esi,0x40(%rsp)
 29f4422:	mov    0xd0(%rsp),%r13
 29f442a:	mov    0x0(%r13),%rax
 29f442e:	mov    0x90(%rsp),%rcx
 29f4436:	cmp    %rcx,%rax
 29f4439:	jae    29f4801 <wasm[0]::function[1009]::helper::array_packed_join+0x1961>
 29f443f:	mov    %rbx,%rcx
 29f4442:	mov    %r15,%rdx
 29f4445:	mov    %r14,%rsi
 29f4448:	jmp    29f4456 <wasm[0]::function[1009]::helper::array_packed_join+0x15b6>
 29f444d:	mov    %rbx,%rcx
 29f4450:	mov    %r15,%rdx
 29f4453:	mov    %r14,%rsi
 29f4456:	mov    %rbx,%rcx
 29f4459:	mov    %r15,%rdx
 29f445c:	mov    %r14,%rsi
 29f445f:	mov    0x60(%rsp),%rdi
 29f4464:	call   3039aea <wasmtime_builtin_memory_copy>
 29f4469:	mov    0x20(%rsp),%ecx
 29f446d:	mov    0x28(%rsp),%esi
 29f4471:	mov    %rsi,0x70(%rsp)
 29f4476:	mov    0x30(%rsp),%eax
 29f447a:	mov    0x38(%rsp),%edi
 29f447e:	mov    0x40(%rsp),%esi
 29f4482:	mov    0x98(%rsp),%rdx
 29f448a:	mov    0x78(%rsp),%r14
 29f448f:	add    %edx,%r14d
 29f4492:	mov    %r14,0x78(%rsp)
 29f4497:	mov    0x80(%rsp),%rdx
 29f449f:	add    $0x1,%rdx
 29f44a6:	mov    %rdx,0x80(%rsp)
 29f44ae:	jmp    29f396b <wasm[0]::function[1009]::helper::array_packed_join+0xacb>
 29f44b3:	mov    0x18(%rsp),%eax
 29f44b7:	test   %eax,%eax
 29f44b9:	je     29f4944 <wasm[0]::function[1009]::helper::array_packed_join+0x1aa4>
 29f44bf:	mov    0xa8(%rsp),%r15
 29f44c7:	mov    (%r15),%eax
 29f44ca:	mov    %eax,%ecx
 29f44cc:	lea    0x20(%rcx),%rdx
 29f44d0:	mov    0x4(%r15),%esi
 29f44d4:	cmp    %rsi,%rdx
 29f44d7:	ja     29f483a <wasm[0]::function[1009]::helper::array_packed_join+0x199a>
 29f44dd:	lea    0x20(%rax),%edx
 29f44e0:	mov    %edx,(%r15)
 29f44e3:	mov    0x20(%r12),%rsi
 29f44e8:	lea    (%rsi,%rcx,1),%rdx
 29f44ec:	movl   $0xb000000a,(%rsi,%rcx,1)
 29f44f3:	mov    0xb8(%rsp),%rdi
 29f44fb:	mov    %edi,0x4(%rsi,%rcx,1)
 29f44ff:	mov    $0x20,%edi
 29f4504:	mov    %edi,0x8(%rsi,%rcx,1)
 29f4508:	mov    0x18(%rsp),%ecx
 29f450c:	mov    %ecx,0x10(%rdx)
 29f450f:	movq   $0x0,0x18(%rdx)
 29f4517:	test   %eax,%eax
 29f4519:	je     29f4946 <wasm[0]::function[1009]::helper::array_packed_join+0x1aa6>
 29f451f:	mov    0x10(%rsp),%edi
 29f4523:	jmp    29f4550 <wasm[0]::function[1009]::helper::array_packed_join+0x16b0>
 29f4528:	mov    0x8(%rsp),%eax
 29f452c:	mov    (%rsp),%edi
 29f452f:	jmp    29f4550 <wasm[0]::function[1009]::helper::array_packed_join+0x16b0>
 29f4534:	xor    %edx,%edx
 29f4536:	mov    0x60(%rsp),%rsi
 29f453b:	mov    0x60(%rsp),%rdi
 29f4540:	call   2f4f240 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 29f4545:	test   %eax,%eax
 29f4547:	je     29f4948 <wasm[0]::function[1009]::helper::array_packed_join+0x1aa8>
 29f454d:	mov    (%rsp),%edi
 29f4550:	mov    0xc0(%rsp),%rsi
 29f4558:	test   %esi,%esi
 29f455a:	jne    29f4568 <wasm[0]::function[1009]::helper::array_packed_join+0x16c8>
 29f4560:	mov    %rdi,%rax
 29f4563:	jmp    29f45cd <wasm[0]::function[1009]::helper::array_packed_join+0x172d>
 29f4568:	xor    %ecx,%ecx
 29f456a:	test   %eax,%eax
 29f456c:	je     29f45b1 <wasm[0]::function[1009]::helper::array_packed_join+0x1711>
 29f4572:	xor    %ecx,%ecx
 29f4574:	test   $0x1,%eax
 29f4579:	jne    29f45b1 <wasm[0]::function[1009]::helper::array_packed_join+0x1711>
 29f457f:	mov    0x28(%r12),%rcx
 29f4584:	mov    0x20(%r12),%rdx
 29f4589:	mov    %eax,%esi
 29f458b:	lea    0x4(%rdx,%rsi,1),%rdx
 29f4590:	xor    %rdi,%rdi
 29f4593:	cmp    %rcx,%rsi
 29f4596:	cmova  %rdi,%rdx
 29f459a:	mov    (%rdx),%ecx
 29f459c:	mov    0x60(%rsp),%rdx
 29f45a1:	mov    0x28(%rdx),%rdx
 29f45a5:	cmp    0x234(%rdx),%ecx
 29f45ab:	sete   %cl
 29f45ae:	movzbl %cl,%ecx
 29f45b1:	test   %ecx,%ecx
 29f45b3:	je     29f494a <wasm[0]::function[1009]::helper::array_packed_join+0x1aaa>
 29f45b9:	jmp    29f45cd <wasm[0]::function[1009]::helper::array_packed_join+0x172d>
 29f45be:	xor    %edx,%edx
 29f45c0:	mov    0x60(%rsp),%rsi
 29f45c5:	mov    %rsi,%rdi
 29f45c8:	call   2f4f240 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 29f45cd:	mov    0xe0(%rsp),%rbx
 29f45d5:	mov    0xe8(%rsp),%r12
 29f45dd:	mov    0xf0(%rsp),%r13
 29f45e5:	mov    0xf8(%rsp),%r14
 29f45ed:	mov    0x100(%rsp),%r15
 29f45f5:	add    $0x110,%rsp
 29f45fc:	mov    %rbp,%rsp
 29f45ff:	pop    %rbp
 29f4600:	ret    $0x10
 29f4603:	mov    0x60(%rsp),%rdi
 29f4608:	call   3039b69 <wasmtime_builtin_new_epoch>
 29f460d:	mov    %rax,0x90(%rsp)
 29f4615:	mov    0x68(%rsp),%r15
 29f461a:	jmp    29f2f3f <wasm[0]::function[1009]::helper::array_packed_join+0x9f>
 29f461f:	mov    0x8(%r12),%rcx
 29f4624:	mov    %rcx,0x90(%rsp)
 29f462c:	cmp    %rcx,%rax
 29f462f:	jb     29f31a3 <wasm[0]::function[1009]::helper::array_packed_join+0x303>
 29f4635:	mov    0x60(%rsp),%rdi
 29f463a:	call   3039b69 <wasmtime_builtin_new_epoch>
 29f463f:	mov    %rax,0x90(%rsp)
 29f4647:	mov    0x68(%rsp),%rcx
 29f464c:	jmp    29f31a8 <wasm[0]::function[1009]::helper::array_packed_join+0x308>
 29f4651:	mov    $0xa8000006,%esi
 29f4656:	mov    0x78(%rsp),%rbx
 29f465b:	mov    0x238(%rbx),%edx
 29f4661:	mov    $0x10,%r8d
 29f4667:	mov    0x60(%rsp),%rdi
 29f466c:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 29f4671:	mov    %eax,%esi
 29f4673:	add    0x20(%r12),%rsi
 29f4678:	jmp    29f37f0 <wasm[0]::function[1009]::helper::array_packed_join+0x950>
 29f467d:	mov    0x8(%r12),%rcx
 29f4682:	mov    %rcx,0x90(%rsp)
 29f468a:	cmp    %rcx,%rax
 29f468d:	jb     29f3894 <wasm[0]::function[1009]::helper::array_packed_join+0x9f4>
 29f4693:	mov    0x60(%rsp),%rdi
 29f4698:	call   3039b69 <wasmtime_builtin_new_epoch>
 29f469d:	mov    %rax,0x90(%rsp)
 29f46a5:	jmp    29f3894 <wasm[0]::function[1009]::helper::array_packed_join+0x9f4>
 29f46aa:	mov    0x8(%r12),%r10
 29f46af:	mov    %r10,%rcx
 29f46b2:	mov    %r10,0x90(%rsp)
 29f46ba:	cmp    %rcx,%rax
 29f46bd:	jb     29f3918 <wasm[0]::function[1009]::helper::array_packed_join+0xa78>
 29f46c3:	mov    0x60(%rsp),%rdi
 29f46c8:	call   3039b69 <wasmtime_builtin_new_epoch>
 29f46cd:	mov    %rax,0x90(%rsp)
 29f46d5:	jmp    29f3918 <wasm[0]::function[1009]::helper::array_packed_join+0xa78>
 29f46da:	mov    0x8(%r12),%rcx
 29f46df:	mov    %rcx,0x90(%rsp)
 29f46e7:	cmp    %rcx,%rax
 29f46ea:	jb     29f39b3 <wasm[0]::function[1009]::helper::array_packed_join+0xb13>
 29f46f0:	mov    0x60(%rsp),%rdi
 29f46f5:	call   3039b69 <wasmtime_builtin_new_epoch>
 29f46fa:	mov    %rax,0x90(%rsp)
 29f4702:	mov    0x68(%rsp),%rcx
 29f4707:	mov    0x80(%rsp),%r9
 29f470f:	jmp    29f39c0 <wasm[0]::function[1009]::helper::array_packed_join+0xb20>
 29f4714:	mov    0x8(%r12),%rcx
 29f4719:	mov    %rcx,%rdx
 29f471c:	mov    %rcx,0x90(%rsp)
 29f4724:	cmp    %rdx,%rax
 29f4727:	jb     29f3b5c <wasm[0]::function[1009]::helper::array_packed_join+0xcbc>
 29f472d:	mov    0x60(%rsp),%rdi
 29f4732:	call   3039b69 <wasmtime_builtin_new_epoch>
 29f4737:	mov    %rax,0x90(%rsp)
 29f473f:	jmp    29f3b5c <wasm[0]::function[1009]::helper::array_packed_join+0xcbc>
 29f4744:	mov    0x8(%r12),%rax
 29f4749:	mov    %rax,0x90(%rsp)
 29f4751:	cmp    %rax,%rdx
 29f4754:	jb     29f3c4c <wasm[0]::function[1009]::helper::array_packed_join+0xdac>
 29f475a:	mov    0x60(%rsp),%rdi
 29f475f:	call   3039b69 <wasmtime_builtin_new_epoch>
 29f4764:	mov    %rax,0x90(%rsp)
 29f476c:	jmp    29f3c4c <wasm[0]::function[1009]::helper::array_packed_join+0xdac>
 29f4771:	mov    0x8(%r12),%rcx
 29f4776:	mov    %rcx,0x90(%rsp)
 29f477e:	cmp    %rcx,%rax
 29f4781:	jb     29f3ceb <wasm[0]::function[1009]::helper::array_packed_join+0xe4b>
 29f4787:	mov    0x60(%rsp),%rdi
 29f478c:	call   3039b69 <wasmtime_builtin_new_epoch>
 29f4791:	mov    %rax,0x90(%rsp)
 29f4799:	mov    %r15,%rcx
 29f479c:	mov    %r14,%rdx
 29f479f:	mov    %rbx,%rsi
 29f47a2:	jmp    29f3cf4 <wasm[0]::function[1009]::helper::array_packed_join+0xe54>
 29f47a7:	mov    0x8(%r12),%rcx
 29f47ac:	mov    %rcx,0x90(%rsp)
 29f47b4:	cmp    %rcx,%rax
 29f47b7:	jb     29f42dd <wasm[0]::function[1009]::helper::array_packed_join+0x143d>
 29f47bd:	mov    0x60(%rsp),%rdi
 29f47c2:	call   3039b69 <wasmtime_builtin_new_epoch>
 29f47c7:	mov    %rax,0x90(%rsp)
 29f47cf:	jmp    29f42dd <wasm[0]::function[1009]::helper::array_packed_join+0x143d>
 29f47d4:	mov    0x8(%r12),%rax
 29f47d9:	mov    %rax,0x90(%rsp)
 29f47e1:	cmp    %rax,%rdx
 29f47e4:	jb     29f43a4 <wasm[0]::function[1009]::helper::array_packed_join+0x1504>
 29f47ea:	mov    0x60(%rsp),%rdi
 29f47ef:	call   3039b69 <wasmtime_builtin_new_epoch>
 29f47f4:	mov    %rax,0x90(%rsp)
 29f47fc:	jmp    29f43a4 <wasm[0]::function[1009]::helper::array_packed_join+0x1504>
 29f4801:	mov    0x8(%r12),%rcx
 29f4806:	mov    %rcx,%rsi
 29f4809:	mov    %rcx,0x90(%rsp)
 29f4811:	cmp    %rsi,%rax
 29f4814:	jb     29f444d <wasm[0]::function[1009]::helper::array_packed_join+0x15ad>
 29f481a:	mov    0x60(%rsp),%rdi
 29f481f:	call   3039b69 <wasmtime_builtin_new_epoch>
 29f4824:	mov    %rax,0x90(%rsp)
 29f482c:	mov    %rbx,%rcx
 29f482f:	mov    %r15,%rdx
 29f4832:	mov    %r14,%rsi
 29f4835:	jmp    29f4456 <wasm[0]::function[1009]::helper::array_packed_join+0x15b6>
 29f483a:	mov    $0xb000000a,%esi
 29f483f:	mov    $0x20,%ecx
 29f4844:	mov    $0x10,%r8d
 29f484a:	mov    0xb8(%rsp),%rdx
 29f4852:	mov    0x60(%rsp),%rdi
 29f4857:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 29f485c:	mov    %eax,%edx
 29f485e:	add    0x20(%r12),%rdx
 29f4863:	jmp    29f4508 <wasm[0]::function[1009]::helper::array_packed_join+0x1668>
 29f4868:	ud2
 29f486a:	ud2
 29f486c:	ud2
 29f486e:	ud2
 29f4870:	ud2
 29f4872:	ud2
 29f4874:	ud2
 29f4876:	ud2
 29f4878:	ud2
 29f487a:	ud2
 29f487c:	ud2
 29f487e:	ud2
 29f4880:	ud2
 29f4882:	ud2
 29f4884:	ud2
 29f4886:	ud2
 29f4888:	ud2
 29f488a:	ud2
 29f488c:	ud2
 29f488e:	ud2
 29f4890:	ud2
 29f4892:	ud2
 29f4894:	ud2
 29f4896:	ud2
 29f4898:	ud2
 29f489a:	ud2
 29f489c:	ud2
 29f489e:	ud2
 29f48a0:	ud2
 29f48a2:	ud2
 29f48a4:	ud2
 29f48a6:	ud2
 29f48a8:	ud2
 29f48aa:	ud2
 29f48ac:	ud2
 29f48ae:	ud2
 29f48b0:	ud2
 29f48b2:	ud2
 29f48b4:	ud2
 29f48b6:	ud2
 29f48b8:	ud2
 29f48ba:	ud2
 29f48bc:	ud2
 29f48be:	ud2
 29f48c0:	ud2
 29f48c2:	ud2
 29f48c4:	ud2
 29f48c6:	ud2
 29f48c8:	ud2
 29f48ca:	ud2
 29f48cc:	ud2
 29f48ce:	ud2
 29f48d0:	ud2
 29f48d2:	ud2
 29f48d4:	ud2
 29f48d6:	ud2
 29f48d8:	ud2
 29f48da:	ud2
 29f48dc:	ud2
 29f48de:	ud2
 29f48e0:	ud2
 29f48e2:	ud2
 29f48e4:	ud2
 29f48e6:	ud2
 29f48e8:	ud2
 29f48ea:	ud2
 29f48ec:	ud2
 29f48ee:	ud2
 29f48f0:	ud2
 29f48f2:	ud2
 29f48f4:	ud2
 29f48f6:	ud2
 29f48f8:	ud2
 29f48fa:	ud2
 29f48fc:	ud2
 29f48fe:	ud2
 29f4900:	ud2
 29f4902:	ud2
 29f4904:	ud2
 29f4906:	ud2
 29f4908:	ud2
 29f490a:	ud2
 29f490c:	ud2
 29f490e:	ud2
 29f4910:	ud2
 29f4912:	ud2
 29f4914:	ud2
 29f4916:	ud2
 29f4918:	ud2
 29f491a:	ud2
 29f491c:	ud2
 29f491e:	ud2
 29f4920:	ud2
 29f4922:	ud2
 29f4924:	ud2
 29f4926:	ud2
 29f4928:	ud2
 29f492a:	ud2
 29f492c:	ud2
 29f492e:	ud2
 29f4930:	ud2
 29f4932:	ud2
 29f4934:	ud2
 29f4936:	ud2
 29f4938:	ud2
 29f493a:	ud2
 29f493c:	ud2
 29f493e:	ud2
 29f4940:	ud2
 29f4942:	ud2
 29f4944:	ud2
 29f4946:	ud2
 29f4948:	ud2
 29f494a:	ud2
 29f494c:	add    %al,(%rax)
 29f494e:	add    %al,(%rax)
 29f4950:	(bad)
 29f4951:	(bad)
 29f4952:	(bad)
 29f4953:	incl   (%rax)
 29f4955:	add    %al,(%rax)
	...
