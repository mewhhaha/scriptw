
/workspace/scriptw/target/performance-dense-numbers-20261030/native-cause/candidate/runtime-portable.elf:     file format elf64-x86-64


Disassembly of section .text:

0000000000495440 <wasm[0]::function[160]::builtin::Array.prototype.push>:
  495440:	push   %rbp
  495441:	mov    %rsp,%rbp
  495444:	mov    0x8(%rdi),%r10
  495448:	mov    0x18(%r10),%r10
  49544c:	add    $0x140,%r10
  495453:	cmp    %rsp,%r10
  495456:	ja     49695d <wasm[0]::function[160]::builtin::Array.prototype.push+0x151d>
  49545c:	sub    $0x130,%rsp
  495463:	mov    %rbx,0x100(%rsp)
  49546b:	mov    %r12,0x108(%rsp)
  495473:	mov    %r13,0x110(%rsp)
  49547b:	mov    %r14,0x118(%rsp)
  495483:	mov    %r15,0x120(%rsp)
  49548b:	mov    %r8,%r13
  49548e:	mov    %rcx,%r14
  495491:	mov    0x28(%rbp),%r12
  495495:	mov    0x30(%rbp),%r8
  495499:	mov    0x40(%rbp),%r10
  49549d:	mov    %edx,0x50(%rsp)
  4954a1:	mov    %r9d,0x40(%rsp)
  4954a6:	mov    %r8d,0x68(%rsp)
  4954ab:	mov    %r10d,0x60(%rsp)
  4954b0:	mov    0x18(%rdi),%rax
  4954b4:	mov    (%rax),%rcx
  4954b7:	mov    %rax,0xf8(%rsp)
  4954bf:	mov    0x8(%rdi),%rbx
  4954c3:	mov    %rdi,0xb0(%rsp)
  4954cb:	mov    0x8(%rbx),%rax
  4954cf:	cmp    %rax,%rcx
  4954d2:	jae    496835 <wasm[0]::function[160]::builtin::Array.prototype.push+0x13f5>
  4954d8:	mov    %rax,0xc0(%rsp)
  4954e0:	mov    0x50(%rsp),%edx
  4954e4:	test   %edx,%edx
  4954e6:	je     49695f <wasm[0]::function[160]::builtin::Array.prototype.push+0x151f>
  4954ec:	test   %edx,%edx
  4954ee:	je     496961 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1521>
  4954f4:	mov    0x28(%rbx),%rcx
  4954f8:	mov    0x20(%rbx),%rsi
  4954fc:	mov    %edx,%eax
  4954fe:	xor    %rdx,%rdx
  495501:	lea    (%rsi,%rax,1),%rdi
  495505:	cmp    %rcx,%rax
  495508:	cmova  %rdx,%rdi
  49550c:	mov    0x18(%rdi),%r8d
  495510:	mov    %r8d,0x50(%rsp)
  495515:	mov    0x60(%rsp),%edi
  495519:	test   %edi,%edi
  49551b:	je     496963 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1523>
  495521:	test   %r8d,%r8d
  495524:	je     496965 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1525>
  49552a:	test   %r8d,%r8d
  49552d:	je     496967 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1527>
  495533:	mov    %r8d,%r8d
  495536:	lea    (%rsi,%r8,1),%rax
  49553a:	cmp    %rcx,%r8
  49553d:	cmova  %rdx,%rax
  495541:	mov    0x34(%rax),%ecx
  495544:	test   %ecx,%ecx
  495546:	jne    495554 <wasm[0]::function[160]::builtin::Array.prototype.push+0x114>
  49554c:	mov    %rdi,%rcx
  49554f:	jmp    49555c <wasm[0]::function[160]::builtin::Array.prototype.push+0x11c>
  495554:	test   %ecx,%ecx
  495556:	je     496969 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1529>
  49555c:	mov    %ecx,0x60(%rsp)
  495560:	mov    0x68(%rsp),%eax
  495564:	test   %eax,%eax
  495566:	je     4955a5 <wasm[0]::function[160]::builtin::Array.prototype.push+0x165>
  49556c:	mov    0x68(%rsp),%ecx
  495570:	test   %ecx,%ecx
  495572:	je     49696b <wasm[0]::function[160]::builtin::Array.prototype.push+0x152b>
  495578:	mov    0x28(%rbx),%rdx
  49557c:	mov    0x20(%rbx),%rdi
  495580:	mov    %ecx,%esi
  495582:	lea    0x10(%rdi,%rsi,1),%rcx
  495587:	xor    %rdi,%rdi
  49558a:	cmp    %rdx,%rsi
  49558d:	cmova  %rdi,%rcx
  495591:	mov    (%rcx),%esi
  495593:	cmp    %r12,%rsi
  495596:	jne    49696d <wasm[0]::function[160]::builtin::Array.prototype.push+0x152d>
  49559c:	mov    0x68(%rsp),%eax
  4955a0:	jmp    49560f <wasm[0]::function[160]::builtin::Array.prototype.push+0x1cf>
  4955a5:	test   %r12,%r12
  4955a8:	jne    49696f <wasm[0]::function[160]::builtin::Array.prototype.push+0x152f>
  4955ae:	mov    0xb0(%rsp),%rcx
  4955b6:	mov    0x20(%rcx),%r11
  4955ba:	mov    (%r11),%eax
  4955bd:	mov    %eax,%r10d
  4955c0:	lea    0x20(%r10),%rcx
  4955c4:	mov    0x4(%r11),%edx
  4955c8:	cmp    %rdx,%rcx
  4955cb:	ja     49684f <wasm[0]::function[160]::builtin::Array.prototype.push+0x140f>
  4955d1:	lea    0x20(%rax),%ecx
  4955d4:	mov    %ecx,(%r11)
  4955d7:	mov    0x20(%rbx),%rdx
  4955db:	lea    (%rdx,%r10,1),%rcx
  4955df:	movl   $0xa800000e,(%rdx,%r10,1)
  4955e7:	mov    0xb0(%rsp),%rsi
  4955ef:	mov    0x28(%rsi),%rsi
  4955f3:	mov    0x1b4(%rsi),%esi
  4955f9:	mov    %esi,0x4(%rdx,%r10,1)
  4955fe:	mov    $0x20,%esi
  495603:	mov    %esi,0x8(%rdx,%r10,1)
  495608:	movl   $0x0,0x10(%rcx)
  49560f:	mov    %eax,0x68(%rsp)
  495613:	test   %eax,%eax
  495615:	je     496971 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1531>
  49561b:	test   %eax,%eax
  49561d:	je     496973 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1533>
  495623:	mov    0x28(%rbx),%rcx
  495627:	mov    0x20(%rbx),%rdx
  49562b:	mov    %eax,%edi
  49562d:	lea    0x10(%rdx,%rdi,1),%rsi
  495632:	xor    %rax,%rax
  495635:	cmp    %rcx,%rdi
  495638:	cmova  %rax,%rsi
  49563c:	mov    (%rsi),%esi
  49563e:	mov    0x50(%rsp),%esi
  495642:	test   %esi,%esi
  495644:	je     496975 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1535>
  49564a:	test   %esi,%esi
  49564c:	je     496977 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1537>
  495652:	mov    %esi,%esi
  495654:	add    %rsi,%rdx
  495657:	cmp    %rcx,%rsi
  49565a:	cmova  %rax,%rdx
  49565e:	mov    0x14(%rdx),%eax
  495661:	mov    %eax,0x58(%rsp)
  495665:	mov    0x18(%rdx),%eax
  495668:	mov    0xb0(%rsp),%rcx
  495670:	mov    0x8c0(%rcx),%edx
  495676:	test   %edx,%edx
  495678:	je     496979 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1539>
  49567e:	mov    0x40(%rsp),%r9d
  495683:	mov    %r14,%rcx
  495686:	mov    %r13,%r8
  495689:	mov    0xb0(%rsp),%rsi
  495691:	mov    0xb0(%rsp),%rdi
  495699:	call   2a80460 <wasm[0]::function[1041]::helper::value_to_object>
  49569e:	mov    %rax,0xe8(%rsp)
  4956a6:	mov    %rcx,0xf0(%rsp)
  4956ae:	mov    %edx,0x40(%rsp)
  4956b2:	cmp    $0x1,%esi
  4956b5:	je     4967ef <wasm[0]::function[160]::builtin::Array.prototype.push+0x13af>
  4956bb:	mov    $0x8c,%edx
  4956c0:	mov    0xb0(%rsp),%rsi
  4956c8:	mov    0xb0(%rsp),%rdi
  4956d0:	call   2f4f240 <wasm[0]::function[1102]::helper::pooled_string_resolve>
  4956d5:	test   %eax,%eax
  4956d7:	je     49697b <wasm[0]::function[160]::builtin::Array.prototype.push+0x153b>
  4956dd:	mov    0x60(%rsp),%ecx
  4956e1:	test   %ecx,%ecx
  4956e3:	je     49697d <wasm[0]::function[160]::builtin::Array.prototype.push+0x153d>
  4956e9:	mov    0x40(%rsp),%r8d
  4956ee:	mov    0x58(%rsp),%edx
  4956f2:	mov    $0x4,%esi
  4956f7:	xor    %rdi,%rdi
  4956fa:	mov    0xf0(%rsp),%r9
  495702:	mov    %r9,(%rsp)
  495706:	mov    %r8d,0x8(%rsp)
  49570b:	mov    %esi,0x10(%rsp)
  49570f:	mov    %rdi,0x18(%rsp)
  495714:	mov    %eax,0x20(%rsp)
  495718:	mov    %edx,0x28(%rsp)
  49571c:	mov    %ecx,0x30(%rsp)
  495720:	mov    0xf0(%rsp),%rcx
  495728:	mov    0xe8(%rsp),%rdx
  495730:	mov    0xb0(%rsp),%rsi
  495738:	mov    0xb0(%rsp),%rdi
  495740:	mov    0xe8(%rsp),%r9
  495748:	call   29fe160 <wasm[0]::function[1015]::helper::object_read>
  49574d:	sub    $0x40,%rsp
  495751:	mov    %rdx,%r8
  495754:	mov    %rax,%rdx
  495757:	cmp    $0x1,%esi
  49575a:	je     4967b3 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1373>
  495760:	mov    0x60(%rsp),%eax
  495764:	test   %eax,%eax
  495766:	je     49697f <wasm[0]::function[160]::builtin::Array.prototype.push+0x153f>
  49576c:	mov    0x58(%rsp),%r9d
  495771:	mov    %eax,(%rsp)
  495774:	mov    0xb0(%rsp),%rsi
  49577c:	mov    0xb0(%rsp),%rdi
  495784:	call   2b0ca20 <wasm[0]::function[1062]::helper::value_to_number>
  495789:	sub    $0x10,%rsp
  49578d:	mov    %rdi,%r12
  495790:	mov    %rax,0xe0(%rsp)
  495798:	mov    %edx,0x48(%rsp)
  49579c:	xor    %r14,%r14
  49579f:	test   %esi,%esi
  4957a1:	mov    %rsi,%r13
  4957a4:	je     4957b5 <wasm[0]::function[160]::builtin::Array.prototype.push+0x375>
  4957aa:	mov    %r13,%rsi
  4957ad:	mov    %rcx,%r15
  4957b0:	jmp    495866 <wasm[0]::function[160]::builtin::Array.prototype.push+0x426>
  4957b5:	movq   %rcx,%xmm0
  4957ba:	mov    %rcx,%r15
  4957bd:	ucomisd %xmm0,%xmm0
  4957c1:	setp   %al
  4957c4:	setne  %cl
  4957c7:	or     %ecx,%eax
  4957c9:	xorpd  %xmm1,%xmm1
  4957cd:	ucomisd %xmm0,%xmm1
  4957d1:	setae  %cl
  4957d4:	or     %ecx,%eax
  4957d6:	test   %al,%al
  4957d8:	jne    495860 <wasm[0]::function[160]::builtin::Array.prototype.push+0x420>
  4957de:	ucomisd 0x122a(%rip),%xmm0        # 496a10 <wasm[0]::function[160]::builtin::Array.prototype.push+0x15d0>
  4957e6:	ja     495851 <wasm[0]::function[160]::builtin::Array.prototype.push+0x411>
  4957ec:	mov    0xb0(%rsp),%rdi
  4957f4:	call   3039d4f <wasmtime_builtin_trunc_f64>
  4957f9:	movabs $0x43e0000000000000,%rax
  495803:	movq   %rax,%xmm2
  495808:	ucomisd %xmm2,%xmm0
  49580c:	jae    495829 <wasm[0]::function[160]::builtin::Array.prototype.push+0x3e9>
  495812:	jp     496981 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1541>
  495818:	cvttsd2si %xmm0,%r14
  49581d:	cmp    $0x0,%r14
  495821:	jge    495863 <wasm[0]::function[160]::builtin::Array.prototype.push+0x423>
  495827:	ud2
  495829:	movaps %xmm0,%xmm1
  49582c:	subsd  %xmm2,%xmm1
  495830:	cvttsd2si %xmm1,%r14
  495835:	cmp    $0x0,%r14
  495839:	jl     496983 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1543>
  49583f:	movabs $0x8000000000000000,%rax
  495849:	add    %rax,%r14
  49584c:	jmp    495863 <wasm[0]::function[160]::builtin::Array.prototype.push+0x423>
  495851:	movabs $0x1fffffffffffff,%r14
  49585b:	jmp    495863 <wasm[0]::function[160]::builtin::Array.prototype.push+0x423>
  495860:	xor    %r14,%r14
  495863:	mov    %r13,%rsi
  495866:	cmp    $0x1,%esi
  495869:	je     49676b <wasm[0]::function[160]::builtin::Array.prototype.push+0x132b>
  49586f:	mov    0x68(%rsp),%eax
  495873:	test   %eax,%eax
  495875:	je     496985 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1545>
  49587b:	test   %eax,%eax
  49587d:	je     496987 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1547>
  495883:	mov    0x28(%rbx),%rcx
  495887:	mov    0x20(%rbx),%rsi
  49588b:	mov    %eax,%edx
  49588d:	lea    0x10(%rsi,%rdx,1),%rax
  495892:	xor    %rsi,%rsi
  495895:	cmp    %rcx,%rdx
  495898:	cmova  %rsi,%rax
  49589c:	mov    (%rax),%r12d
  49589f:	mov    %r12d,%eax
  4958a2:	mov    %r12,0xd8(%rsp)
  4958aa:	lea    (%r14,%rax,1),%r12
  4958ae:	cmp    0x116b(%rip),%r12        # 496a20 <wasm[0]::function[160]::builtin::Array.prototype.push+0x15e0>
  4958b5:	ja     496590 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1150>
  4958bb:	mov    0x40(%rsp),%ecx
  4958bf:	xor    %eax,%eax
  4958c1:	test   %ecx,%ecx
  4958c3:	je     49590c <wasm[0]::function[160]::builtin::Array.prototype.push+0x4cc>
  4958c9:	xor    %eax,%eax
  4958cb:	test   $0x1,%ecx
  4958d1:	jne    49590c <wasm[0]::function[160]::builtin::Array.prototype.push+0x4cc>
  4958d7:	mov    0x28(%rbx),%rsi
  4958db:	mov    0x20(%rbx),%r8
  4958df:	mov    %ecx,%edi
  4958e1:	lea    0x4(%r8,%rdi,1),%rdx
  4958e6:	xor    %r8,%r8
  4958e9:	cmp    %rsi,%rdi
  4958ec:	cmova  %r8,%rdx
  4958f0:	mov    (%rdx),%esi
  4958f2:	mov    0xb0(%rsp),%rax
  4958fa:	mov    0x28(%rax),%rdi
  4958fe:	cmp    0x254(%rdi),%esi
  495904:	sete   %dil
  495908:	movzbl %dil,%eax
  49590c:	mov    0x68(%rsp),%edx
  495910:	mov    0x58(%rsp),%esi
  495914:	mov    0x60(%rsp),%edi
  495918:	xor    %r8d,%r8d
  49591b:	test   %eax,%eax
  49591d:	jne    495930 <wasm[0]::function[160]::builtin::Array.prototype.push+0x4f0>
  495923:	mov    %r12,0xd0(%rsp)
  49592b:	jmp    496222 <wasm[0]::function[160]::builtin::Array.prototype.push+0xde2>
  495930:	xor    %eax,%eax
  495932:	test   %ecx,%ecx
  495934:	je     49597e <wasm[0]::function[160]::builtin::Array.prototype.push+0x53e>
  49593a:	xor    %eax,%eax
  49593c:	test   $0x1,%ecx
  495942:	jne    49597e <wasm[0]::function[160]::builtin::Array.prototype.push+0x53e>
  495948:	mov    0x28(%rbx),%rax
  49594c:	mov    0x20(%rbx),%r8
  495950:	mov    %ecx,%r9d
  495953:	lea    0x4(%r8,%r9,1),%r8
  495958:	xor    %r10,%r10
  49595b:	cmp    %rax,%r9
  49595e:	cmova  %r10,%r8
  495962:	mov    (%r8),%eax
  495965:	mov    0xb0(%rsp),%r8
  49596d:	mov    0x28(%r8),%r8
  495971:	cmp    0x254(%r8),%eax
  495978:	sete   %al
  49597b:	movzbl %al,%eax
  49597e:	test   %eax,%eax
  495980:	je     496989 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1549>
  495986:	test   %ecx,%ecx
  495988:	je     49698b <wasm[0]::function[160]::builtin::Array.prototype.push+0x154b>
  49598e:	test   %ecx,%ecx
  495990:	je     49698d <wasm[0]::function[160]::builtin::Array.prototype.push+0x154d>
  495996:	mov    0x28(%rbx),%rax
  49599a:	mov    0x20(%rbx),%r8
  49599e:	mov    %ecx,%r9d
  4959a1:	add    %r9,%r8
  4959a4:	xor    %r10,%r10
  4959a7:	cmp    %rax,%r9
  4959aa:	cmova  %r10,%r8
  4959ae:	mov    0x14(%r8),%eax
  4959b2:	mov    0x18(%r8),%r9
  4959b6:	xor    %r8d,%r8d
  4959b9:	cmp    %r14,%r9
  4959bc:	je     4959cf <wasm[0]::function[160]::builtin::Array.prototype.push+0x58f>
  4959c2:	mov    %r12,0xd0(%rsp)
  4959ca:	jmp    496222 <wasm[0]::function[160]::builtin::Array.prototype.push+0xde2>
  4959cf:	xor    %r8d,%r8d
  4959d2:	test   %eax,%eax
  4959d4:	je     49698f <wasm[0]::function[160]::builtin::Array.prototype.push+0x154f>
  4959da:	test   %eax,%eax
  4959dc:	je     496991 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1551>
  4959e2:	mov    0x28(%rbx),%rcx
  4959e6:	mov    0x20(%rbx),%rdx
  4959ea:	mov    %eax,%eax
  4959ec:	add    %rax,%rdx
  4959ef:	xor    %rsi,%rsi
  4959f2:	cmp    %rcx,%rax
  4959f5:	cmova  %rsi,%rdx
  4959f9:	mov    0x24(%rdx),%r9d
  4959fd:	mov    0x68(%rsp),%edx
  495a01:	mov    0x40(%rsp),%ecx
  495a05:	mov    0x58(%rsp),%esi
  495a09:	mov    0x60(%rsp),%edi
  495a0d:	cmp    $0x4,%r9d
  495a11:	sete   %r10b
  495a15:	cmp    $0x2,%r9d
  495a19:	sete   %r11b
  495a1d:	or     %r11d,%r10d
  495a20:	cmp    $0x3,%r9d
  495a24:	sete   %r9b
  495a28:	or     %r9d,%r10d
  495a2b:	movzbl %r10b,%r9d
  495a2f:	test   %r9d,%r9d
  495a32:	jne    495a45 <wasm[0]::function[160]::builtin::Array.prototype.push+0x605>
  495a38:	mov    %r12,0xd0(%rsp)
  495a40:	jmp    496222 <wasm[0]::function[160]::builtin::Array.prototype.push+0xde2>
  495a45:	mov    0x68(%rsp),%edx
  495a49:	mov    0x40(%rsp),%ecx
  495a4d:	mov    0x58(%rsp),%esi
  495a51:	mov    0x60(%rsp),%edi
  495a55:	xor    %r8d,%r8d
  495a58:	mov    0xd8(%rsp),%r9
  495a60:	mov    0xd8(%rsp),%r10
  495a68:	test   %r10d,%r9d
  495a6b:	jne    495a7e <wasm[0]::function[160]::builtin::Array.prototype.push+0x63e>
  495a71:	mov    %r12,0xd0(%rsp)
  495a79:	jmp    496222 <wasm[0]::function[160]::builtin::Array.prototype.push+0xde2>
  495a7e:	xor    %r8d,%r8d
  495a81:	cmp    0xfa0(%rip),%r12        # 496a28 <wasm[0]::function[160]::builtin::Array.prototype.push+0x15e8>
  495a88:	mov    %r12,0xd0(%rsp)
  495a90:	ja     496222 <wasm[0]::function[160]::builtin::Array.prototype.push+0xde2>
  495a96:	xor    %r8d,%r8d
  495a99:	test   %ecx,%ecx
  495a9b:	je     496993 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1553>
  495aa1:	test   %ecx,%ecx
  495aa3:	je     496995 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1555>
  495aa9:	mov    0x28(%rbx),%r9
  495aad:	mov    %ecx,%r11d
  495ab0:	mov    %r11,%r10
  495ab3:	add    0x20(%rbx),%r10
  495ab7:	xor    %r12,%r12
  495aba:	cmp    %r9,%r11
  495abd:	cmova  %r12,%r10
  495ac1:	mov    0x20(%r10),%r9d
  495ac5:	test   %r9d,%r9d
  495ac8:	je     496222 <wasm[0]::function[160]::builtin::Array.prototype.push+0xde2>
  495ace:	mov    0x40(%rsp),%ecx
  495ad2:	xor    %r8d,%r8d
  495ad5:	test   %ecx,%ecx
  495ad7:	je     496997 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1557>
  495add:	test   %ecx,%ecx
  495adf:	je     496999 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1559>
  495ae5:	mov    0x28(%rbx),%rdx
  495ae9:	mov    0x20(%rbx),%rsi
  495aed:	mov    %ecx,%r10d
  495af0:	lea    (%rsi,%r10,1),%r9
  495af4:	xor    %rdi,%rdi
  495af7:	cmp    %rdx,%r10
  495afa:	cmova  %rdi,%r9
  495afe:	mov    0x10(%r9),%r9d
  495b02:	test   %r9d,%r9d
  495b05:	je     49699b <wasm[0]::function[160]::builtin::Array.prototype.push+0x155b>
  495b0b:	test   %r9d,%r9d
  495b0e:	je     49699d <wasm[0]::function[160]::builtin::Array.prototype.push+0x155d>
  495b14:	mov    %r9d,%r9d
  495b17:	add    %r9,%rsi
  495b1a:	cmp    %rdx,%r9
  495b1d:	cmova  %rdi,%rsi
  495b21:	mov    0x1c(%rsi),%r9d
  495b25:	mov    0x68(%rsp),%edx
  495b29:	mov    0x58(%rsp),%esi
  495b2d:	mov    0x60(%rsp),%edi
  495b31:	test   %r9d,%r9d
  495b34:	je     496222 <wasm[0]::function[160]::builtin::Array.prototype.push+0xde2>
  495b3a:	mov    0x28(%rbx),%rsi
  495b3e:	mov    %rax,%rdx
  495b41:	add    0x20(%rbx),%rdx
  495b45:	xor    %rdi,%rdi
  495b48:	cmp    %rsi,%rax
  495b4b:	cmova  %rdi,%rdx
  495b4f:	mov    0x18(%rdx),%r9
  495b53:	mov    0x68(%rsp),%edx
  495b57:	mov    0x40(%rsp),%ecx
  495b5b:	mov    0x58(%rsp),%esi
  495b5f:	mov    0x60(%rsp),%edi
  495b63:	xor    %r8d,%r8d
  495b66:	cmp    %r14,%r9
  495b69:	jne    496222 <wasm[0]::function[160]::builtin::Array.prototype.push+0xde2>
  495b6f:	mov    0x40(%rsp),%ecx
  495b73:	xor    %r12d,%r12d
  495b76:	test   %ecx,%ecx
  495b78:	je     49699f <wasm[0]::function[160]::builtin::Array.prototype.push+0x155f>
  495b7e:	test   %ecx,%ecx
  495b80:	je     4969a1 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1561>
  495b86:	mov    0x28(%rbx),%rax
  495b8a:	mov    0x20(%rbx),%rdx
  495b8e:	mov    %ecx,%edi
  495b90:	lea    (%rdx,%rdi,1),%r10
  495b94:	xor    %rsi,%rsi
  495b97:	cmp    %rax,%rdi
  495b9a:	cmova  %rsi,%r10
  495b9e:	mov    0x10(%r10),%edi
  495ba2:	test   %edi,%edi
  495ba4:	je     4969a3 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1563>
  495baa:	mov    %edi,%edi
  495bac:	add    %rdi,%rdx
  495baf:	cmp    %rax,%rdi
  495bb2:	cmova  %rsi,%rdx
  495bb6:	mov    0x10(%rdx),%r9d
  495bba:	mov    0x68(%rsp),%esi
  495bbe:	mov    0x58(%rsp),%r10d
  495bc3:	mov    0x60(%rsp),%edx
  495bc7:	mov    0xb0(%rsp),%rax
  495bcf:	mov    0x28(%rax),%rax
  495bd3:	mov    0x254(%rax),%edi
  495bd9:	mov    %rdi,%r13
  495bdc:	mov    0x138(%rax),%eax
  495be2:	mov    %rax,0xc8(%rsp)
  495bea:	mov    %rcx,%rdi
  495bed:	mov    %r9d,0x80(%rsp)
  495bf5:	mov    %esi,0x78(%rsp)
  495bf9:	mov    %ecx,0x70(%rsp)
  495bfd:	mov    %edi,0x60(%rsp)
  495c01:	mov    %r10d,0x58(%rsp)
  495c06:	mov    %edx,0x68(%rsp)
  495c0a:	mov    0xf8(%rsp),%rcx
  495c12:	mov    (%rcx),%rax
  495c15:	mov    0xc0(%rsp),%rcx
  495c1d:	cmp    %rcx,%rax
  495c20:	jae    496889 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1449>
  495c26:	mov    0x80(%rsp),%eax
  495c2d:	test   %eax,%eax
  495c2f:	je     496017 <wasm[0]::function[160]::builtin::Array.prototype.push+0xbd7>
  495c35:	mov    0x78(%rsp),%edx
  495c39:	mov    0x70(%rsp),%r9d
  495c3e:	mov    0x60(%rsp),%ecx
  495c42:	mov    0x58(%rsp),%esi
  495c46:	mov    0x68(%rsp),%edi
  495c4a:	xor    %r15d,%r15d
  495c4d:	cmp    $0x8,%r12d
  495c51:	jae    496032 <wasm[0]::function[160]::builtin::Array.prototype.push+0xbf2>
  495c57:	mov    0x80(%rsp),%eax
  495c5e:	xor    %ecx,%ecx
  495c60:	test   %eax,%eax
  495c62:	je     495caa <wasm[0]::function[160]::builtin::Array.prototype.push+0x86a>
  495c68:	mov    0x80(%rsp),%eax
  495c6f:	xor    %ecx,%ecx
  495c71:	test   $0x1,%eax
  495c76:	jne    495caa <wasm[0]::function[160]::builtin::Array.prototype.push+0x86a>
  495c7c:	mov    0x80(%rsp),%ecx
  495c83:	mov    0x28(%rbx),%rax
  495c87:	mov    0x20(%rbx),%rsi
  495c8b:	mov    %ecx,%edx
  495c8d:	lea    0x4(%rsi,%rdx,1),%rcx
  495c92:	xor    %rsi,%rsi
  495c95:	cmp    %rax,%rdx
  495c98:	cmova  %rsi,%rcx
  495c9c:	mov    (%rcx),%eax
  495c9e:	mov    %r13,%r15
  495ca1:	cmp    %r15d,%eax
  495ca4:	sete   %al
  495ca7:	movzbl %al,%ecx
  495caa:	test   %ecx,%ecx
  495cac:	jne    495ee9 <wasm[0]::function[160]::builtin::Array.prototype.push+0xaa9>
  495cb2:	mov    0x80(%rsp),%eax
  495cb9:	xor    %r8d,%r8d
  495cbc:	test   %eax,%eax
  495cbe:	je     495d0d <wasm[0]::function[160]::builtin::Array.prototype.push+0x8cd>
  495cc4:	mov    0x80(%rsp),%eax
  495ccb:	xor    %r8d,%r8d
  495cce:	test   $0x1,%eax
  495cd3:	jne    495d0d <wasm[0]::function[160]::builtin::Array.prototype.push+0x8cd>
  495cd9:	mov    0x80(%rsp),%ecx
  495ce0:	mov    0x28(%rbx),%rax
  495ce4:	mov    0x20(%rbx),%rsi
  495ce8:	mov    %ecx,%edx
  495cea:	lea    0x4(%rsi,%rdx,1),%rcx
  495cef:	xor    %rsi,%rsi
  495cf2:	cmp    %rax,%rdx
  495cf5:	cmova  %rsi,%rcx
  495cf9:	mov    (%rcx),%eax
  495cfb:	mov    0xc8(%rsp),%r15
  495d03:	cmp    %r15d,%eax
  495d06:	sete   %al
  495d09:	movzbl %al,%r8d
  495d0d:	mov    0x78(%rsp),%edx
  495d11:	mov    0x70(%rsp),%r9d
  495d16:	mov    0x60(%rsp),%ecx
  495d1a:	mov    0x58(%rsp),%esi
  495d1e:	mov    0x68(%rsp),%edi
  495d22:	xor    %r15d,%r15d
  495d25:	test   %r8d,%r8d
  495d28:	je     496032 <wasm[0]::function[160]::builtin::Array.prototype.push+0xbf2>
  495d2e:	mov    0x80(%rsp),%eax
  495d35:	xor    %ecx,%ecx
  495d37:	test   %eax,%eax
  495d39:	je     495d88 <wasm[0]::function[160]::builtin::Array.prototype.push+0x948>
  495d3f:	mov    0x80(%rsp),%eax
  495d46:	xor    %ecx,%ecx
  495d48:	test   $0x1,%eax
  495d4d:	jne    495d88 <wasm[0]::function[160]::builtin::Array.prototype.push+0x948>
  495d53:	mov    0x80(%rsp),%esi
  495d5a:	mov    0x28(%rbx),%rdx
  495d5e:	mov    0x20(%rbx),%rdi
  495d62:	mov    %esi,%esi
  495d64:	lea    0x4(%rdi,%rsi,1),%rax
  495d69:	xor    %rdi,%rdi
  495d6c:	cmp    %rdx,%rsi
  495d6f:	cmova  %rdi,%rax
  495d73:	mov    (%rax),%esi
  495d75:	mov    0xc8(%rsp),%r15
  495d7d:	cmp    %r15d,%esi
  495d80:	sete   %sil
  495d84:	movzbl %sil,%ecx
  495d88:	test   %ecx,%ecx
  495d8a:	je     4969a5 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1565>
  495d90:	mov    0x78(%rsp),%edx
  495d94:	mov    0x70(%rsp),%r9d
  495d99:	mov    0x60(%rsp),%ecx
  495d9d:	mov    0x58(%rsp),%esi
  495da1:	mov    0x68(%rsp),%edi
  495da5:	mov    %r14,0xb8(%rsp)
  495dad:	mov    %edx,0x88(%rsp)
  495db4:	mov    %r9d,0x90(%rsp)
  495dbc:	mov    %ecx,0x98(%rsp)
  495dc3:	mov    %esi,0xa0(%rsp)
  495dca:	mov    %edi,0xa8(%rsp)
  495dd1:	mov    0xf8(%rsp),%rax
  495dd9:	mov    (%rax),%rax
  495ddc:	mov    0xc0(%rsp),%rcx
  495de4:	cmp    %rcx,%rax
  495de7:	jae    4968b8 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1478>
  495ded:	mov    0xd0(%rsp),%rax
  495df5:	jmp    495e02 <wasm[0]::function[160]::builtin::Array.prototype.push+0x9c2>
  495dfa:	mov    0xd0(%rsp),%rax
  495e02:	cmp    %rax,%r14
  495e05:	mov    %rax,0xd0(%rsp)
  495e0d:	jae    495ead <wasm[0]::function[160]::builtin::Array.prototype.push+0xa6d>
  495e13:	xor    %r15d,%r15d
  495e16:	mov    %r15,%rcx
  495e19:	mov    %r14,%rdx
  495e1c:	mov    0xb0(%rsp),%rsi
  495e24:	mov    0xb0(%rsp),%rdi
  495e2c:	call   2b02b20 <wasm[0]::function[1058]::helper::integer_decimal_string>
  495e31:	test   %eax,%eax
  495e33:	je     4969a7 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1567>
  495e39:	mov    0x80(%rsp),%edx
  495e40:	test   %edx,%edx
  495e42:	je     4969a9 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1569>
  495e48:	mov    $0x4,%ecx
  495e4d:	xor    %r8,%r8
  495e50:	mov    %rax,%r9
  495e53:	mov    0xb0(%rsp),%rsi
  495e5b:	mov    0xb0(%rsp),%rdi
  495e63:	call   2a1cf20 <wasm[0]::function[1019]::helper::ordinary_own_descriptor>
  495e68:	mov    0x88(%rsp),%edx
  495e6f:	mov    0x90(%rsp),%r9d
  495e77:	mov    0x98(%rsp),%ecx
  495e7e:	mov    0xa0(%rsp),%esi
  495e85:	mov    0xa8(%rsp),%edi
  495e8c:	test   %eax,%eax
  495e8e:	je     495ea1 <wasm[0]::function[160]::builtin::Array.prototype.push+0xa61>
  495e94:	mov    0xb8(%rsp),%r14
  495e9c:	jmp    496032 <wasm[0]::function[160]::builtin::Array.prototype.push+0xbf2>
  495ea1:	add    $0x1,%r14
  495ea8:	jmp    495dad <wasm[0]::function[160]::builtin::Array.prototype.push+0x96d>
  495ead:	mov    0x80(%rsp),%r11d
  495eb5:	mov    0x88(%rsp),%esi
  495ebc:	mov    0x90(%rsp),%ecx
  495ec3:	mov    0x98(%rsp),%edi
  495eca:	mov    0xa0(%rsp),%r10d
  495ed2:	mov    0xa8(%rsp),%edx
  495ed9:	mov    %r13,%r8
  495edc:	mov    0xb8(%rsp),%r14
  495ee4:	jmp    495fe3 <wasm[0]::function[160]::builtin::Array.prototype.push+0xba3>
  495ee9:	mov    0x80(%rsp),%eax
  495ef0:	xor    %esi,%esi
  495ef2:	test   %eax,%eax
  495ef4:	jne    495f02 <wasm[0]::function[160]::builtin::Array.prototype.push+0xac2>
  495efa:	mov    %r13,%r8
  495efd:	jmp    495f4d <wasm[0]::function[160]::builtin::Array.prototype.push+0xb0d>
  495f02:	mov    0x80(%rsp),%eax
  495f09:	xor    %esi,%esi
  495f0b:	test   $0x1,%eax
  495f10:	je     495f1e <wasm[0]::function[160]::builtin::Array.prototype.push+0xade>
  495f16:	mov    %r13,%r8
  495f19:	jmp    495f4d <wasm[0]::function[160]::builtin::Array.prototype.push+0xb0d>
  495f1e:	mov    0x80(%rsp),%ecx
  495f25:	mov    0x28(%rbx),%rax
  495f29:	mov    0x20(%rbx),%rsi
  495f2d:	mov    %ecx,%edx
  495f2f:	lea    0x4(%rsi,%rdx,1),%rcx
  495f34:	xor    %rsi,%rsi
  495f37:	cmp    %rax,%rdx
  495f3a:	cmova  %rsi,%rcx
  495f3e:	mov    (%rcx),%eax
  495f40:	mov    %r13,%r8
  495f43:	cmp    %r8d,%eax
  495f46:	sete   %al
  495f49:	rex movzbl %al,%esi
  495f4d:	test   %esi,%esi
  495f4f:	je     4969ab <wasm[0]::function[160]::builtin::Array.prototype.push+0x156b>
  495f55:	mov    0x80(%rsp),%eax
  495f5c:	xor    %r15d,%r15d
  495f5f:	test   %eax,%eax
  495f61:	je     4969ad <wasm[0]::function[160]::builtin::Array.prototype.push+0x156d>
  495f67:	test   %eax,%eax
  495f69:	je     4969af <wasm[0]::function[160]::builtin::Array.prototype.push+0x156f>
  495f6f:	mov    0x28(%rbx),%rcx
  495f73:	mov    0x20(%rbx),%rsi
  495f77:	mov    %eax,%eax
  495f79:	lea    (%rsi,%rax,1),%rdx
  495f7d:	xor    %rdi,%rdi
  495f80:	cmp    %rcx,%rax
  495f83:	cmova  %rdi,%rdx
  495f87:	mov    0x14(%rdx),%eax
  495f8a:	test   %eax,%eax
  495f8c:	je     4969b1 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1571>
  495f92:	test   %eax,%eax
  495f94:	je     4969b3 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1573>
  495f9a:	mov    %eax,%r9d
  495f9d:	lea    (%rsi,%r9,1),%rax
  495fa1:	cmp    %rcx,%r9
  495fa4:	cmova  %rdi,%rax
  495fa8:	mov    0x18(%rax),%rax
  495fac:	mov    0x10(%rdx),%r11d
  495fb0:	mov    0x78(%rsp),%edx
  495fb4:	mov    0x70(%rsp),%r9d
  495fb9:	mov    0x60(%rsp),%ecx
  495fbd:	mov    0x58(%rsp),%esi
  495fc1:	mov    0x68(%rsp),%edi
  495fc5:	test   %rax,%rax
  495fc8:	jne    496032 <wasm[0]::function[160]::builtin::Array.prototype.push+0xbf2>
  495fce:	mov    0x78(%rsp),%esi
  495fd2:	mov    0x70(%rsp),%ecx
  495fd6:	mov    0x60(%rsp),%edi
  495fda:	mov    0x58(%rsp),%r10d
  495fdf:	mov    0x68(%rsp),%edx
  495fe3:	test   %r11d,%r11d
  495fe6:	je     4969b5 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1575>
  495fec:	mov    0x28(%rbx),%rax
  495ff0:	mov    %r11d,%r11d
  495ff3:	mov    %r11,%r9
  495ff6:	add    0x20(%rbx),%r9
  495ffa:	xor    %r13,%r13
  495ffd:	cmp    %rax,%r11
  496000:	cmova  %r13,%r9
  496004:	mov    0x10(%r9),%r9d
  496008:	add    $0x1,%r12d
  49600f:	mov    %r8,%r13
  496012:	jmp    495bed <wasm[0]::function[160]::builtin::Array.prototype.push+0x7ad>
  496017:	mov    0x78(%rsp),%edx
  49601b:	mov    0x70(%rsp),%r9d
  496020:	mov    0x60(%rsp),%ecx
  496024:	mov    0x58(%rsp),%esi
  496028:	mov    0x68(%rsp),%edi
  49602c:	mov    $0x1,%r15d
  496032:	mov    %edx,0x70(%rsp)
  496036:	mov    %r9d,0x78(%rsp)
  49603b:	xor    %r8d,%r8d
  49603e:	test   %r15d,%r15d
  496041:	je     496222 <wasm[0]::function[160]::builtin::Array.prototype.push+0xde2>
  496047:	xor    %r12d,%r12d
  49604a:	mov    %r14,%r13
  49604d:	mov    %ecx,0x68(%rsp)
  496051:	mov    %esi,0x58(%rsp)
  496055:	mov    %edi,0x60(%rsp)
  496059:	mov    0xf8(%rsp),%rax
  496061:	mov    (%rax),%rdi
  496064:	mov    0xc0(%rsp),%rax
  49606c:	cmp    %rax,%rdi
  49606f:	jae    4968ef <wasm[0]::function[160]::builtin::Array.prototype.push+0x14af>
  496075:	mov    0xd8(%rsp),%rdi
  49607d:	jmp    49608a <wasm[0]::function[160]::builtin::Array.prototype.push+0xc4a>
  496082:	mov    0xd8(%rsp),%rdi
  49608a:	mov    0xd8(%rsp),%rdi
  496092:	cmp    %edi,%r12d
  496095:	jae    496209 <wasm[0]::function[160]::builtin::Array.prototype.push+0xdc9>
  49609b:	mov    0x70(%rsp),%eax
  49609f:	test   %eax,%eax
  4960a1:	je     4969b7 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1577>
  4960a7:	test   %eax,%eax
  4960a9:	je     4969b9 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1579>
  4960af:	mov    0x28(%rbx),%rcx
  4960b3:	mov    0x20(%rbx),%rsi
  4960b7:	mov    %eax,%edx
  4960b9:	lea    0x10(%rsi,%rdx,1),%rax
  4960be:	xor    %rsi,%rsi
  4960c1:	cmp    %rcx,%rdx
  4960c4:	cmova  %rsi,%rax
  4960c8:	mov    (%rax),%eax
  4960ca:	cmp    %eax,%r12d
  4960cd:	jb     4960e1 <wasm[0]::function[160]::builtin::Array.prototype.push+0xca1>
  4960d3:	xor    %r8d,%r8d
  4960d6:	xor    %r9,%r9
  4960d9:	mov    %r8,%rax
  4960dc:	jmp    496190 <wasm[0]::function[160]::builtin::Array.prototype.push+0xd50>
  4960e1:	mov    0x70(%rsp),%r10d
  4960e6:	test   %r10d,%r10d
  4960e9:	je     4969bb <wasm[0]::function[160]::builtin::Array.prototype.push+0x157b>
  4960ef:	test   %r10d,%r10d
  4960f2:	je     4969bd <wasm[0]::function[160]::builtin::Array.prototype.push+0x157d>
  4960f8:	mov    0x28(%rbx),%rax
  4960fc:	mov    0x20(%rbx),%rcx
  496100:	mov    %r10d,%edi
  496103:	lea    0x10(%rcx,%rdi,1),%rsi
  496108:	xor    %rdx,%rdx
  49610b:	cmp    %rax,%rdi
  49610e:	cmova  %rdx,%rsi
  496112:	mov    (%rsi),%esi
  496114:	cmp    %esi,%r12d
  496117:	jae    4969bf <wasm[0]::function[160]::builtin::Array.prototype.push+0x157f>
  49611d:	mov    %esi,%edi
  49611f:	shl    $0x2,%rdi
  496123:	shr    $0x20,%rdi
  496127:	test   %rdi,%rdi
  49612a:	jne    4969c1 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1581>
  496130:	shl    $0x2,%esi
  496133:	add    $0x14,%esi
  496136:	jb     4969c3 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1583>
  49613c:	add    %esi,%r10d
  49613f:	jb     4969c5 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1585>
  496145:	mov    %r10d,%r8d
  496148:	lea    (%rcx,%r8,1),%rdi
  49614c:	cmp    %rax,%r8
  49614f:	cmova  %rdx,%rdi
  496153:	mov    %r12,%r8
  496156:	shl    $0x2,%r8d
  49615a:	add    $0x14,%r8d
  496161:	sub    %r8d,%esi
  496164:	sub    %rsi,%rdi
  496167:	mov    (%rdi),%esi
  496169:	test   %esi,%esi
  49616b:	je     4969c7 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1587>
  496171:	test   %esi,%esi
  496173:	je     4969c9 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1589>
  496179:	mov    %esi,%esi
  49617b:	add    %rsi,%rcx
  49617e:	cmp    %rax,%rsi
  496181:	cmova  %rdx,%rcx
  496185:	mov    0x18(%rcx),%r8d
  496189:	mov    0x10(%rcx),%r9
  49618d:	mov    0x1c(%rcx),%eax
  496190:	mov    0x78(%rsp),%edx
  496194:	test   %edx,%edx
  496196:	je     4969cb <wasm[0]::function[160]::builtin::Array.prototype.push+0x158b>
  49619c:	mov    %eax,(%rsp)
  49619f:	mov    %r14,%rcx
  4961a2:	mov    0xb0(%rsp),%rsi
  4961aa:	mov    0xb0(%rsp),%rdi
  4961b2:	call   29efe20 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data>
  4961b7:	sub    $0x10,%rsp
  4961bb:	mov    0x78(%rsp),%eax
  4961bf:	test   %eax,%eax
  4961c1:	je     4969cd <wasm[0]::function[160]::builtin::Array.prototype.push+0x158d>
  4961c7:	test   %eax,%eax
  4961c9:	je     4969cf <wasm[0]::function[160]::builtin::Array.prototype.push+0x158f>
  4961cf:	mov    0x28(%rbx),%rcx
  4961d3:	add    $0x1,%r14
  4961da:	mov    %eax,%edx
  4961dc:	mov    %rdx,%rax
  4961df:	add    0x20(%rbx),%rax
  4961e3:	xor    %rsi,%rsi
  4961e6:	cmp    %rcx,%rdx
  4961e9:	cmova  %rsi,%rax
  4961ed:	mov    %r14,0x18(%rax)
  4961f1:	mov    0x68(%rsp),%ecx
  4961f5:	mov    0x58(%rsp),%esi
  4961f9:	mov    0x60(%rsp),%edi
  4961fd:	add    $0x1,%r12d
  496204:	jmp    49604d <wasm[0]::function[160]::builtin::Array.prototype.push+0xc0d>
  496209:	mov    0x70(%rsp),%edx
  49620d:	mov    0x68(%rsp),%ecx
  496211:	mov    0x58(%rsp),%esi
  496215:	mov    0x60(%rsp),%edi
  496219:	mov    $0x1,%r8d
  49621f:	mov    %r13,%r14
  496222:	mov    %edx,0x60(%rsp)
  496226:	mov    %ecx,0x58(%rsp)
  49622a:	mov    %esi,0x68(%rsp)
  49622e:	mov    %edi,0x70(%rsp)
  496232:	test   %r8d,%r8d
  496235:	jne    496543 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1103>
  49623b:	xor    %r13d,%r13d
  49623e:	mov    0xf8(%rsp),%rax
  496246:	mov    0xf8(%rsp),%rax
  49624e:	mov    (%rax),%rax
  496251:	mov    0xc0(%rsp),%rcx
  496259:	cmp    %rcx,%rax
  49625c:	jae    496926 <wasm[0]::function[160]::builtin::Array.prototype.push+0x14e6>
  496262:	mov    0xd8(%rsp),%r12
  49626a:	jmp    496277 <wasm[0]::function[160]::builtin::Array.prototype.push+0xe37>
  49626f:	mov    0xd8(%rsp),%r12
  496277:	mov    0xd8(%rsp),%r12
  49627f:	cmp    %r12d,%r13d
  496282:	jae    496445 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1005>
  496288:	mov    0x60(%rsp),%r8d
  49628d:	test   %r8d,%r8d
  496290:	je     4969d1 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1591>
  496296:	test   %r8d,%r8d
  496299:	je     4969d3 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1593>
  49629f:	mov    0x28(%rbx),%rax
  4962a3:	mov    0x20(%rbx),%rdx
  4962a7:	mov    %r8d,%ecx
  4962aa:	lea    0x10(%rdx,%rcx,1),%r9
  4962af:	xor    %rdx,%rdx
  4962b2:	cmp    %rax,%rcx
  4962b5:	cmova  %rdx,%r9
  4962b9:	mov    (%r9),%eax
  4962bc:	cmp    %eax,%r13d
  4962bf:	jb     4962d3 <wasm[0]::function[160]::builtin::Array.prototype.push+0xe93>
  4962c5:	xor    %r12d,%r12d
  4962c8:	xor    %r15,%r15
  4962cb:	mov    %r12,%rax
  4962ce:	jmp    496381 <wasm[0]::function[160]::builtin::Array.prototype.push+0xf41>
  4962d3:	mov    0x60(%rsp),%edi
  4962d7:	test   %edi,%edi
  4962d9:	je     4969d5 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1595>
  4962df:	test   %edi,%edi
  4962e1:	je     4969d7 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1597>
  4962e7:	mov    0x28(%rbx),%rcx
  4962eb:	mov    0x20(%rbx),%rdx
  4962ef:	mov    %edi,%r8d
  4962f2:	lea    0x10(%rdx,%r8,1),%rax
  4962f7:	xor    %rsi,%rsi
  4962fa:	cmp    %rcx,%r8
  4962fd:	cmova  %rsi,%rax
  496301:	mov    (%rax),%r9d
  496304:	cmp    %r9d,%r13d
  496307:	jae    4969d9 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1599>
  49630d:	mov    %r9d,%eax
  496310:	shl    $0x2,%rax
  496314:	shr    $0x20,%rax
  496318:	test   %rax,%rax
  49631b:	jne    4969db <wasm[0]::function[160]::builtin::Array.prototype.push+0x159b>
  496321:	shl    $0x2,%r9d
  496325:	add    $0x14,%r9d
  496329:	jb     4969dd <wasm[0]::function[160]::builtin::Array.prototype.push+0x159d>
  49632f:	add    %r9d,%edi
  496332:	jb     4969df <wasm[0]::function[160]::builtin::Array.prototype.push+0x159f>
  496338:	mov    %edi,%edi
  49633a:	lea    (%rdx,%rdi,1),%rax
  49633e:	cmp    %rcx,%rdi
  496341:	cmova  %rsi,%rax
  496345:	mov    %r13,%rdi
  496348:	shl    $0x2,%edi
  49634b:	add    $0x14,%edi
  496351:	sub    %edi,%r9d
  496354:	sub    %r9,%rax
  496357:	mov    (%rax),%eax
  496359:	test   %eax,%eax
  49635b:	je     4969e1 <wasm[0]::function[160]::builtin::Array.prototype.push+0x15a1>
  496361:	test   %eax,%eax
  496363:	je     4969e3 <wasm[0]::function[160]::builtin::Array.prototype.push+0x15a3>
  496369:	mov    %eax,%edi
  49636b:	lea    (%rdx,%rdi,1),%rax
  49636f:	cmp    %rcx,%rdi
  496372:	cmova  %rsi,%rax
  496376:	mov    0x18(%rax),%r12d
  49637a:	mov    0x10(%rax),%r15
  49637e:	mov    0x1c(%rax),%eax
  496381:	mov    %eax,0x78(%rsp)
  496385:	xor    %ecx,%ecx
  496387:	mov    %r14,%rdx
  49638a:	mov    0xb0(%rsp),%rsi
  496392:	mov    0xb0(%rsp),%rdi
  49639a:	call   2b02b20 <wasm[0]::function[1058]::helper::integer_decimal_string>
  49639f:	test   %eax,%eax
  4963a1:	je     4969e5 <wasm[0]::function[160]::builtin::Array.prototype.push+0x15a5>
  4963a7:	mov    0x70(%rsp),%ecx
  4963ab:	test   %ecx,%ecx
  4963ad:	je     4969e7 <wasm[0]::function[160]::builtin::Array.prototype.push+0x15a7>
  4963b3:	mov    0x58(%rsp),%r8d
  4963b8:	mov    0x78(%rsp),%esi
  4963bc:	mov    0x68(%rsp),%edx
  4963c0:	mov    $0x4,%r9d
  4963c6:	xor    %r10,%r10
  4963c9:	mov    $0x1,%edi
  4963ce:	mov    %r10,(%rsp)
  4963d2:	mov    %eax,0x8(%rsp)
  4963d6:	mov    %r12d,0x10(%rsp)
  4963db:	mov    %r15,0x18(%rsp)
  4963e0:	mov    %esi,0x20(%rsp)
  4963e4:	mov    %edi,0x28(%rsp)
  4963e8:	mov    %edx,0x30(%rsp)
  4963ec:	mov    %ecx,0x38(%rsp)
  4963f0:	mov    0xf0(%rsp),%rcx
  4963f8:	mov    0xe8(%rsp),%rdx
  496400:	mov    0xb0(%rsp),%rsi
  496408:	mov    0xb0(%rsp),%rdi
  496410:	call   2a19c40 <wasm[0]::function[1016]::helper::object_write>
  496415:	sub    $0x40,%rsp
  496419:	cmp    $0x1,%esi
  49641c:	je     49643d <wasm[0]::function[160]::builtin::Array.prototype.push+0xffd>
  496422:	add    $0x1,%r13d
  496429:	add    $0x1,%r14
  496430:	mov    0xf8(%rsp),%rax
  496438:	jmp    496246 <wasm[0]::function[160]::builtin::Array.prototype.push+0xe06>
  49643d:	mov    %rdi,%r13
  496440:	jmp    496732 <wasm[0]::function[160]::builtin::Array.prototype.push+0x12f2>
  496445:	movl   $0x0,0x60(%rsp)
  49644d:	mov    $0x8c,%edx
  496452:	mov    0xb0(%rsp),%rsi
  49645a:	mov    0xb0(%rsp),%rdi
  496462:	call   2f4f240 <wasm[0]::function[1102]::helper::pooled_string_resolve>
  496467:	test   %eax,%eax
  496469:	je     4969e9 <wasm[0]::function[160]::builtin::Array.prototype.push+0x15a9>
  49646f:	mov    0x70(%rsp),%edx
  496473:	test   %edx,%edx
  496475:	je     4969eb <wasm[0]::function[160]::builtin::Array.prototype.push+0x15ab>
  49647b:	mov    0x58(%rsp),%r8d
  496480:	mov    0x60(%rsp),%edi
  496484:	mov    0x68(%rsp),%ecx
  496488:	mov    $0x4,%r9d
  49648e:	xor    %rsi,%rsi
  496491:	mov    $0x3,%r12d
  496497:	mov    0xd0(%rsp),%r10
  49649f:	cmp    $0x0,%r10
  4964a3:	jl     4964b3 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1073>
  4964a9:	cvtsi2sd %r10,%xmm0
  4964ae:	jmp    4964cd <wasm[0]::function[160]::builtin::Array.prototype.push+0x108d>
  4964b3:	mov    %r10,%rbx
  4964b6:	shr    $0x1,%rbx
  4964ba:	mov    %r10,%r11
  4964bd:	and    $0x1,%r11
  4964c1:	or     %rbx,%r11
  4964c4:	cvtsi2sd %r11,%xmm0
  4964c9:	addsd  %xmm0,%xmm0
  4964cd:	movq   %xmm0,%rbx
  4964d2:	mov    $0x1,%r10d
  4964d8:	mov    %rsi,(%rsp)
  4964dc:	mov    %eax,0x8(%rsp)
  4964e0:	mov    %r12d,0x10(%rsp)
  4964e5:	mov    %rbx,0x18(%rsp)
  4964ea:	mov    %edi,0x20(%rsp)
  4964ee:	mov    %r10d,0x28(%rsp)
  4964f3:	mov    %ecx,0x30(%rsp)
  4964f7:	mov    %edx,0x38(%rsp)
  4964fb:	mov    0xf0(%rsp),%rcx
  496503:	mov    0xe8(%rsp),%rdx
  49650b:	mov    0xb0(%rsp),%rsi
  496513:	mov    %rsi,%rdi
  496516:	call   2a19c40 <wasm[0]::function[1016]::helper::object_write>
  49651b:	sub    $0x40,%rsp
  49651f:	cmp    $0x1,%esi
  496522:	je     49653b <wasm[0]::function[160]::builtin::Array.prototype.push+0x10fb>
  496528:	xor    %edx,%edx
  49652a:	mov    %r12,%rax
  49652d:	mov    %rbx,%rcx
  496530:	mov    %rdx,%rsi
  496533:	mov    %rdx,%r13
  496536:	jmp    496732 <wasm[0]::function[160]::builtin::Array.prototype.push+0x12f2>
  49653b:	mov    %rdi,%r13
  49653e:	jmp    496732 <wasm[0]::function[160]::builtin::Array.prototype.push+0x12f2>
  496543:	mov    0xd0(%rsp),%r10
  49654b:	mov    $0x3,%eax
  496550:	cmp    $0x0,%r10
  496554:	jl     496564 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1124>
  49655a:	cvtsi2sd %r10,%xmm0
  49655f:	jmp    49657e <wasm[0]::function[160]::builtin::Array.prototype.push+0x113e>
  496564:	mov    %r10,%rdx
  496567:	shr    $0x1,%rdx
  49656b:	mov    %r10,%rcx
  49656e:	and    $0x1,%rcx
  496572:	or     %rdx,%rcx
  496575:	cvtsi2sd %rcx,%xmm0
  49657a:	addsd  %xmm0,%xmm0
  49657e:	movq   %xmm0,%rcx
  496583:	xor    %edx,%edx
  496585:	mov    %rdx,%rsi
  496588:	mov    %rdx,%r13
  49658b:	jmp    496732 <wasm[0]::function[160]::builtin::Array.prototype.push+0x12f2>
  496590:	mov    0x50(%rsp),%eax
  496594:	test   %eax,%eax
  496596:	je     4969ed <wasm[0]::function[160]::builtin::Array.prototype.push+0x15ad>
  49659c:	test   %eax,%eax
  49659e:	je     4969ef <wasm[0]::function[160]::builtin::Array.prototype.push+0x15af>
  4965a4:	mov    0x28(%rbx),%rcx
  4965a8:	mov    0x20(%rbx),%rsi
  4965ac:	mov    %eax,%edx
  4965ae:	lea    (%rsi,%rdx,1),%rax
  4965b2:	xor    %r12,%r12
  4965b5:	cmp    %rcx,%rdx
  4965b8:	cmova  %r12,%rax
  4965bc:	mov    0x10(%rax),%edx
  4965bf:	mov    %edx,0x50(%rsp)
  4965c3:	test   %edx,%edx
  4965c5:	je     4969f1 <wasm[0]::function[160]::builtin::Array.prototype.push+0x15b1>
  4965cb:	mov    0xb0(%rsp),%rsi
  4965d3:	mov    0xb0(%rsp),%rdi
  4965db:	call   2ae3360 <wasm[0]::function[1049]::helper::realm_ensure_errors>
  4965e0:	mov    0x50(%rsp),%esi
  4965e4:	test   %esi,%esi
  4965e6:	je     4969f3 <wasm[0]::function[160]::builtin::Array.prototype.push+0x15b3>
  4965ec:	test   %esi,%esi
  4965ee:	je     4969f5 <wasm[0]::function[160]::builtin::Array.prototype.push+0x15b5>
  4965f4:	mov    0x28(%rbx),%rdi
  4965f8:	mov    0x20(%rbx),%r8
  4965fc:	mov    %esi,%r9d
  4965ff:	lea    (%r8,%r9,1),%rsi
  496603:	cmp    %rdi,%r9
  496606:	cmova  %r12,%rsi
  49660a:	mov    0x2c(%rsi),%eax
  49660d:	test   %eax,%eax
  49660f:	je     4969f7 <wasm[0]::function[160]::builtin::Array.prototype.push+0x15b7>
  496615:	test   %eax,%eax
  496617:	je     4969f9 <wasm[0]::function[160]::builtin::Array.prototype.push+0x15b9>
  49661d:	mov    %eax,%ecx
  49661f:	lea    0x10(%r8,%rcx,1),%r11
  496624:	cmp    %rdi,%rcx
  496627:	cmova  %r12,%r11
  49662b:	mov    (%r11),%esi
  49662e:	cmp    $0x3,%esi
  496631:	jbe    4969fb <wasm[0]::function[160]::builtin::Array.prototype.push+0x15bb>
  496637:	mov    %esi,%ecx
  496639:	shl    $0x2,%rcx
  49663d:	shr    $0x20,%rcx
  496641:	test   %rcx,%rcx
  496644:	jne    4969fd <wasm[0]::function[160]::builtin::Array.prototype.push+0x15bd>
  49664a:	shl    $0x2,%esi
  49664d:	add    $0x14,%esi
  496650:	jb     4969ff <wasm[0]::function[160]::builtin::Array.prototype.push+0x15bf>
  496656:	add    %esi,%eax
  496658:	jb     496a01 <wasm[0]::function[160]::builtin::Array.prototype.push+0x15c1>
  49665e:	mov    %eax,%ecx
  496660:	lea    (%r8,%rcx,1),%rax
  496664:	cmp    %rdi,%rcx
  496667:	cmova  %r12,%rax
  49666b:	sub    $0x20,%esi
  49666e:	sub    %rsi,%rax
  496671:	mov    (%rax),%eax
  496673:	test   %eax,%eax
  496675:	je     496a03 <wasm[0]::function[160]::builtin::Array.prototype.push+0x15c3>
  49667b:	test   %eax,%eax
  49667d:	je     496a05 <wasm[0]::function[160]::builtin::Array.prototype.push+0x15c5>
  496683:	mov    %eax,%ecx
  496685:	lea    (%r8,%rcx,1),%rax
  496689:	cmp    %rdi,%rcx
  49668c:	cmova  %r12,%rax
  496690:	mov    0x18(%rax),%r12d
  496694:	mov    0x10(%rax),%rbx
  496698:	mov    0x1c(%rax),%eax
  49669b:	mov    %eax,0x50(%rsp)
  49669f:	cmp    $0x6,%r12d
  4966a3:	sete   %cl
  4966a6:	cmp    $0x7,%r12d
  4966aa:	sete   %al
  4966ad:	or     %eax,%ecx
  4966af:	cmp    $0x8,%r12d
  4966b3:	sete   %al
  4966b6:	or     %eax,%ecx
  4966b8:	cmp    $0x9,%r12d
  4966bc:	sete   %al
  4966bf:	or     %eax,%ecx
  4966c1:	movzbl %cl,%eax
  4966c4:	test   %eax,%eax
  4966c6:	je     496a07 <wasm[0]::function[160]::builtin::Array.prototype.push+0x15c7>
  4966cc:	mov    $0x736,%edx
  4966d1:	mov    0xb0(%rsp),%rsi
  4966d9:	mov    0xb0(%rsp),%rdi
  4966e1:	call   2f4f240 <wasm[0]::function[1102]::helper::pooled_string_resolve>
  4966e6:	xor    %edi,%edi
  4966e8:	mov    %rdi,%r13
  4966eb:	test   %eax,%eax
  4966ed:	je     496a09 <wasm[0]::function[160]::builtin::Array.prototype.push+0x15c9>
  4966f3:	mov    0x50(%rsp),%r9d
  4966f8:	mov    $0x5,%edx
  4966fd:	mov    %eax,(%rsp)
  496700:	mov    %r12,%rcx
  496703:	mov    0xb0(%rsp),%rsi
  49670b:	mov    %rbx,%r8
  49670e:	mov    %rsi,%rdi
  496711:	call   2f4efa0 <wasm[0]::function[1101]::helper::runtime_error_for_throw>
  496716:	sub    $0x10,%rsp
  49671a:	test   %eax,%eax
  49671c:	mov    %rax,%rdx
  49671f:	je     496a0b <wasm[0]::function[160]::builtin::Array.prototype.push+0x15cb>
  496725:	mov    $0x6,%eax
  49672a:	xor    %rcx,%rcx
  49672d:	mov    $0x1,%esi
  496732:	mov    %r13,%rdi
  496735:	mov    0x100(%rsp),%rbx
  49673d:	mov    0x108(%rsp),%r12
  496745:	mov    0x110(%rsp),%r13
  49674d:	mov    0x118(%rsp),%r14
  496755:	mov    0x120(%rsp),%r15
  49675d:	add    $0x130,%rsp
  496764:	mov    %rbp,%rsp
  496767:	pop    %rbp
  496768:	ret    $0x40
  49676b:	mov    0x48(%rsp),%edx
  49676f:	mov    0xe0(%rsp),%rax
  496777:	mov    %r15,%rcx
  49677a:	mov    %r12,%rdi
  49677d:	mov    0x100(%rsp),%rbx
  496785:	mov    0x108(%rsp),%r12
  49678d:	mov    0x110(%rsp),%r13
  496795:	mov    0x118(%rsp),%r14
  49679d:	mov    0x120(%rsp),%r15
  4967a5:	add    $0x130,%rsp
  4967ac:	mov    %rbp,%rsp
  4967af:	pop    %rbp
  4967b0:	ret    $0x40
  4967b3:	mov    %rdx,%rax
  4967b6:	mov    %r8,%rdx
  4967b9:	mov    0x100(%rsp),%rbx
  4967c1:	mov    0x108(%rsp),%r12
  4967c9:	mov    0x110(%rsp),%r13
  4967d1:	mov    0x118(%rsp),%r14
  4967d9:	mov    0x120(%rsp),%r15
  4967e1:	add    $0x130,%rsp
  4967e8:	mov    %rbp,%rsp
  4967eb:	pop    %rbp
  4967ec:	ret    $0x40
  4967ef:	mov    0xe8(%rsp),%rax
  4967f7:	mov    0xf0(%rsp),%rcx
  4967ff:	mov    0x100(%rsp),%rbx
  496807:	mov    0x108(%rsp),%r12
  49680f:	mov    0x110(%rsp),%r13
  496817:	mov    0x118(%rsp),%r14
  49681f:	mov    0x120(%rsp),%r15
  496827:	add    $0x130,%rsp
  49682e:	mov    %rbp,%rsp
  496831:	pop    %rbp
  496832:	ret    $0x40
  496835:	mov    0xb0(%rsp),%rdi
  49683d:	call   3039b69 <wasmtime_builtin_new_epoch>
  496842:	mov    %rax,0xc0(%rsp)
  49684a:	jmp    4954e0 <wasm[0]::function[160]::builtin::Array.prototype.push+0xa0>
  49684f:	mov    $0xa800000e,%esi
  496854:	mov    0xb0(%rsp),%rcx
  49685c:	mov    0x28(%rcx),%rax
  496860:	mov    0x1b4(%rax),%edx
  496866:	mov    $0x14,%ecx
  49686b:	mov    $0x10,%r8d
  496871:	mov    0xb0(%rsp),%rdi
  496879:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
  49687e:	mov    %eax,%ecx
  496880:	add    0x20(%rbx),%rcx
  496884:	jmp    495608 <wasm[0]::function[160]::builtin::Array.prototype.push+0x1c8>
  496889:	mov    0x8(%rbx),%rcx
  49688d:	mov    %rcx,0xc0(%rsp)
  496895:	cmp    %rcx,%rax
  496898:	jb     495c26 <wasm[0]::function[160]::builtin::Array.prototype.push+0x7e6>
  49689e:	mov    0xb0(%rsp),%rdi
  4968a6:	call   3039b69 <wasmtime_builtin_new_epoch>
  4968ab:	mov    %rax,0xc0(%rsp)
  4968b3:	jmp    495c26 <wasm[0]::function[160]::builtin::Array.prototype.push+0x7e6>
  4968b8:	mov    0x8(%rbx),%rcx
  4968bc:	mov    %rcx,0xc0(%rsp)
  4968c4:	cmp    %rcx,%rax
  4968c7:	jb     495dfa <wasm[0]::function[160]::builtin::Array.prototype.push+0x9ba>
  4968cd:	mov    0xb0(%rsp),%rdi
  4968d5:	call   3039b69 <wasmtime_builtin_new_epoch>
  4968da:	mov    %rax,0xc0(%rsp)
  4968e2:	mov    0xd0(%rsp),%rax
  4968ea:	jmp    495e02 <wasm[0]::function[160]::builtin::Array.prototype.push+0x9c2>
  4968ef:	mov    0x8(%rbx),%rax
  4968f3:	mov    %rax,0xc0(%rsp)
  4968fb:	cmp    %rax,%rdi
  4968fe:	jb     496082 <wasm[0]::function[160]::builtin::Array.prototype.push+0xc42>
  496904:	mov    0xb0(%rsp),%rdi
  49690c:	call   3039b69 <wasmtime_builtin_new_epoch>
  496911:	mov    %rax,0xc0(%rsp)
  496919:	mov    0xd8(%rsp),%rdi
  496921:	jmp    49608a <wasm[0]::function[160]::builtin::Array.prototype.push+0xc4a>
  496926:	mov    0x8(%rbx),%rcx
  49692a:	mov    %rcx,0xc0(%rsp)
  496932:	cmp    %rcx,%rax
  496935:	jb     49626f <wasm[0]::function[160]::builtin::Array.prototype.push+0xe2f>
  49693b:	mov    0xb0(%rsp),%rdi
  496943:	call   3039b69 <wasmtime_builtin_new_epoch>
  496948:	mov    %rax,0xc0(%rsp)
  496950:	mov    0xd8(%rsp),%r12
  496958:	jmp    496277 <wasm[0]::function[160]::builtin::Array.prototype.push+0xe37>
  49695d:	ud2
  49695f:	ud2
  496961:	ud2
  496963:	ud2
  496965:	ud2
  496967:	ud2
  496969:	ud2
  49696b:	ud2
  49696d:	ud2
  49696f:	ud2
  496971:	ud2
  496973:	ud2
  496975:	ud2
  496977:	ud2
  496979:	ud2
  49697b:	ud2
  49697d:	ud2
  49697f:	ud2
  496981:	ud2
  496983:	ud2
  496985:	ud2
  496987:	ud2
  496989:	ud2
  49698b:	ud2
  49698d:	ud2
  49698f:	ud2
  496991:	ud2
  496993:	ud2
  496995:	ud2
  496997:	ud2
  496999:	ud2
  49699b:	ud2
  49699d:	ud2
  49699f:	ud2
  4969a1:	ud2
  4969a3:	ud2
  4969a5:	ud2
  4969a7:	ud2
  4969a9:	ud2
  4969ab:	ud2
  4969ad:	ud2
  4969af:	ud2
  4969b1:	ud2
  4969b3:	ud2
  4969b5:	ud2
  4969b7:	ud2
  4969b9:	ud2
  4969bb:	ud2
  4969bd:	ud2
  4969bf:	ud2
  4969c1:	ud2
  4969c3:	ud2
  4969c5:	ud2
  4969c7:	ud2
  4969c9:	ud2
  4969cb:	ud2
  4969cd:	ud2
  4969cf:	ud2
  4969d1:	ud2
  4969d3:	ud2
  4969d5:	ud2
  4969d7:	ud2
  4969d9:	ud2
  4969db:	ud2
  4969dd:	ud2
  4969df:	ud2
  4969e1:	ud2
  4969e3:	ud2
  4969e5:	ud2
  4969e7:	ud2
  4969e9:	ud2
  4969eb:	ud2
  4969ed:	ud2
  4969ef:	ud2
  4969f1:	ud2
  4969f3:	ud2
  4969f5:	ud2
  4969f7:	ud2
  4969f9:	ud2
  4969fb:	ud2
  4969fd:	ud2
  4969ff:	ud2
  496a01:	ud2
  496a03:	ud2
  496a05:	ud2
  496a07:	ud2
  496a09:	ud2
  496a0b:	ud2
  496a0d:	add    %al,(%rax)
  496a0f:	add    %bh,%bh
  496a11:	(bad)
  496a12:	(bad)
  496a13:	(bad)
  496a14:	(bad)
  496a15:	(bad)
  496a16:	(bad)
  496a17:	rex.XB add %al,(%r8)
  496a1a:	add    %al,(%rax)
  496a1c:	add    %al,(%rax)
  496a1e:	add    %al,(%rax)
  496a20:	(bad)
  496a21:	(bad)
  496a22:	(bad)
  496a23:	(bad)
  496a24:	(bad)
  496a25:	lcall  *(%rdi)
  496a27:	add    %bh,%bh
  496a29:	(bad)
  496a2a:	(bad)
  496a2b:	incl   (%rax)
  496a2d:	add    %al,(%rax)
	...
