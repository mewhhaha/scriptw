
/workspace/scriptw/target/performance-dense-numbers-20261030/native-cause/candidate/runtime-portable.elf:     file format elf64-x86-64


Disassembly of section .text:

0000000002a19c40 <wasm[0]::function[1016]::helper::object_write>:
 2a19c40:	push   %rbp
 2a19c41:	mov    %rsp,%rbp
 2a19c44:	mov    0x8(%rdi),%r10
 2a19c48:	mov    0x18(%r10),%r10
 2a19c4c:	add    $0xf0,%r10
 2a19c53:	cmp    %rsp,%r10
 2a19c56:	ja     2a1a307 <wasm[0]::function[1016]::helper::object_write+0x6c7>
 2a19c5c:	sub    $0xe0,%rsp
 2a19c63:	mov    %rbx,0xb0(%rsp)
 2a19c6b:	mov    %r12,0xb8(%rsp)
 2a19c73:	mov    %r13,0xc0(%rsp)
 2a19c7b:	mov    %r14,0xc8(%rsp)
 2a19c83:	mov    %r15,0xd0(%rsp)
 2a19c8b:	mov    %rdx,0x78(%rsp)
 2a19c90:	mov    %rcx,0x80(%rsp)
 2a19c98:	mov    %r9,0x88(%rsp)
 2a19ca0:	mov    0x10(%rbp),%r13
 2a19ca4:	mov    0x18(%rbp),%r9
 2a19ca8:	mov    0x20(%rbp),%r14
 2a19cac:	mov    0x28(%rbp),%r15
 2a19cb0:	mov    0x30(%rbp),%rax
 2a19cb4:	mov    0x38(%rbp),%rcx
 2a19cb8:	mov    %rcx,0x90(%rsp)
 2a19cc0:	mov    0x40(%rbp),%rdx
 2a19cc4:	mov    0x48(%rbp),%rcx
 2a19cc8:	mov    %r8d,0x50(%rsp)
 2a19ccd:	mov    %r9d,0x60(%rsp)
 2a19cd2:	mov    %eax,0x68(%rsp)
 2a19cd6:	mov    %edx,0x58(%rsp)
 2a19cda:	mov    %ecx,0x70(%rsp)
 2a19cde:	mov    0x18(%rdi),%r10
 2a19ce2:	mov    (%r10),%r9
 2a19ce5:	mov    %r10,0xa0(%rsp)
 2a19ced:	mov    0x8(%rdi),%r12
 2a19cf1:	mov    %rdi,%rsi
 2a19cf4:	mov    0x8(%r12),%rax
 2a19cf9:	cmp    %rax,%r9
 2a19cfc:	jae    2a1a2d4 <wasm[0]::function[1016]::helper::object_write+0x694>
 2a19d02:	mov    %rsi,%rbx
 2a19d05:	mov    %rax,0x98(%rsp)
 2a19d0d:	mov    0x70(%rsp),%eax
 2a19d11:	test   %eax,%eax
 2a19d13:	je     2a1a309 <wasm[0]::function[1016]::helper::object_write+0x6c9>
 2a19d19:	mov    0x50(%rsp),%r8d
 2a19d1e:	mov    0x60(%rsp),%edi
 2a19d22:	mov    0x68(%rsp),%edx
 2a19d26:	mov    0x58(%rsp),%esi
 2a19d2a:	mov    0x80(%rsp),%rcx
 2a19d32:	mov    %rcx,(%rsp)
 2a19d36:	mov    %r8d,0x8(%rsp)
 2a19d3b:	mov    0x88(%rsp),%r9
 2a19d43:	mov    %r9d,0x10(%rsp)
 2a19d48:	mov    %r13,0x18(%rsp)
 2a19d4d:	mov    %edi,0x20(%rsp)
 2a19d51:	mov    %r14d,0x28(%rsp)
 2a19d56:	mov    %r15,0x30(%rsp)
 2a19d5b:	mov    %edx,0x38(%rsp)
 2a19d5f:	mov    %esi,0x40(%rsp)
 2a19d63:	mov    %eax,0x48(%rsp)
 2a19d67:	mov    0x78(%rsp),%r9
 2a19d6c:	mov    %rbx,%rsi
 2a19d6f:	mov    %rbx,%rdi
 2a19d72:	mov    %r9,%rdx
 2a19d75:	call   2c736a0 <wasm[0]::function[1073]::helper::ordinary_set>
 2a19d7a:	sub    $0x50,%rsp
 2a19d7e:	test   %esi,%esi
 2a19d80:	je     2a19d91 <wasm[0]::function[1016]::helper::object_write+0x151>
 2a19d86:	mov    %rdi,%rbx
 2a19d89:	mov    %rcx,%r14
 2a19d8c:	jmp    2a1a298 <wasm[0]::function[1016]::helper::object_write+0x658>
 2a19d91:	cmp    $0x2,%eax
 2a19d94:	je     2a1a02f <wasm[0]::function[1016]::helper::object_write+0x3ef>
 2a19d9a:	cmp    $0x4,%eax
 2a19d9d:	je     2a19f88 <wasm[0]::function[1016]::helper::object_write+0x348>
 2a19da3:	cmp    $0x3,%eax
 2a19da6:	je     2a19f55 <wasm[0]::function[1016]::helper::object_write+0x315>
 2a19dac:	cmp    $0xa,%eax
 2a19daf:	je     2a19ead <wasm[0]::function[1016]::helper::object_write+0x26d>
 2a19db5:	test   %eax,%eax
 2a19db7:	sete   %cl
 2a19dba:	cmp    $0x1,%eax
 2a19dbd:	sete   %al
 2a19dc0:	or     %eax,%ecx
 2a19dc2:	test   %cl,%cl
 2a19dc4:	jne    2a19ea6 <wasm[0]::function[1016]::helper::object_write+0x266>
 2a19dca:	xor    %eax,%eax
 2a19dcc:	test   %edx,%edx
 2a19dce:	je     2a19e0f <wasm[0]::function[1016]::helper::object_write+0x1cf>
 2a19dd4:	xor    %eax,%eax
 2a19dd6:	test   $0x1,%edx
 2a19ddc:	jne    2a19e0f <wasm[0]::function[1016]::helper::object_write+0x1cf>
 2a19de2:	mov    0x28(%r12),%rax
 2a19de7:	mov    0x20(%r12),%rsi
 2a19dec:	mov    %edx,%edi
 2a19dee:	xor    %rcx,%rcx
 2a19df1:	lea    0x4(%rsi,%rdi,1),%rsi
 2a19df6:	cmp    %rax,%rdi
 2a19df9:	cmova  %rcx,%rsi
 2a19dfd:	mov    (%rsi),%eax
 2a19dff:	mov    0x28(%rbx),%rcx
 2a19e03:	cmp    0x1d4(%rcx),%eax
 2a19e09:	sete   %al
 2a19e0c:	movzbl %al,%eax
 2a19e0f:	test   %eax,%eax
 2a19e11:	jne    2a19e1e <wasm[0]::function[1016]::helper::object_write+0x1de>
 2a19e17:	xor    %eax,%eax
 2a19e19:	jmp    2a19e97 <wasm[0]::function[1016]::helper::object_write+0x257>
 2a19e1e:	xor    %eax,%eax
 2a19e20:	test   %edx,%edx
 2a19e22:	je     2a19e63 <wasm[0]::function[1016]::helper::object_write+0x223>
 2a19e28:	xor    %eax,%eax
 2a19e2a:	test   $0x1,%edx
 2a19e30:	jne    2a19e63 <wasm[0]::function[1016]::helper::object_write+0x223>
 2a19e36:	mov    0x28(%r12),%rax
 2a19e3b:	mov    0x20(%r12),%rsi
 2a19e40:	mov    %edx,%edi
 2a19e42:	xor    %rcx,%rcx
 2a19e45:	lea    0x4(%rsi,%rdi,1),%rsi
 2a19e4a:	cmp    %rax,%rdi
 2a19e4d:	cmova  %rcx,%rsi
 2a19e51:	mov    (%rsi),%eax
 2a19e53:	mov    0x28(%rbx),%rcx
 2a19e57:	cmp    0x1d4(%rcx),%eax
 2a19e5d:	sete   %al
 2a19e60:	movzbl %al,%eax
 2a19e63:	test   %eax,%eax
 2a19e65:	je     2a1a30b <wasm[0]::function[1016]::helper::object_write+0x6cb>
 2a19e6b:	test   %edx,%edx
 2a19e6d:	je     2a1a30d <wasm[0]::function[1016]::helper::object_write+0x6cd>
 2a19e73:	test   %edx,%edx
 2a19e75:	je     2a1a30f <wasm[0]::function[1016]::helper::object_write+0x6cf>
 2a19e7b:	mov    0x28(%r12),%rax
 2a19e80:	mov    %edx,%edx
 2a19e82:	xor    %rcx,%rcx
 2a19e85:	mov    %rdx,%rsi
 2a19e88:	add    0x20(%r12),%rsi
 2a19e8d:	cmp    %rax,%rdx
 2a19e90:	cmova  %rcx,%rsi
 2a19e94:	mov    0x3c(%rsi),%eax
 2a19e97:	test   %eax,%eax
 2a19e99:	sete   %sil
 2a19e9d:	movzbl %sil,%eax
 2a19ea1:	jmp    2a1a038 <wasm[0]::function[1016]::helper::object_write+0x3f8>
 2a19ea6:	xor    %eax,%eax
 2a19ea8:	jmp    2a1a038 <wasm[0]::function[1016]::helper::object_write+0x3f8>
 2a19ead:	xor    %eax,%eax
 2a19eaf:	test   %edx,%edx
 2a19eb1:	je     2a19ef3 <wasm[0]::function[1016]::helper::object_write+0x2b3>
 2a19eb7:	xor    %eax,%eax
 2a19eb9:	test   $0x1,%edx
 2a19ebf:	jne    2a19ef3 <wasm[0]::function[1016]::helper::object_write+0x2b3>
 2a19ec5:	mov    0x28(%r12),%rax
 2a19eca:	mov    0x20(%r12),%rsi
 2a19ecf:	mov    %edx,%edi
 2a19ed1:	xor    %rcx,%rcx
 2a19ed4:	lea    0x4(%rsi,%rdi,1),%r11
 2a19ed9:	cmp    %rax,%rdi
 2a19edc:	cmova  %rcx,%r11
 2a19ee0:	mov    (%r11),%eax
 2a19ee3:	mov    0x28(%rbx),%rcx
 2a19ee7:	cmp    0x23c(%rcx),%eax
 2a19eed:	sete   %al
 2a19ef0:	movzbl %al,%eax
 2a19ef3:	test   %eax,%eax
 2a19ef5:	je     2a1a311 <wasm[0]::function[1016]::helper::object_write+0x6d1>
 2a19efb:	test   %edx,%edx
 2a19efd:	je     2a1a313 <wasm[0]::function[1016]::helper::object_write+0x6d3>
 2a19f03:	test   %edx,%edx
 2a19f05:	je     2a1a315 <wasm[0]::function[1016]::helper::object_write+0x6d5>
 2a19f0b:	mov    0x28(%r12),%rax
 2a19f10:	mov    0x20(%r12),%rsi
 2a19f15:	mov    %edx,%edx
 2a19f17:	xor    %rcx,%rcx
 2a19f1a:	lea    (%rsi,%rdx,1),%rdi
 2a19f1e:	cmp    %rax,%rdx
 2a19f21:	cmova  %rcx,%rdi
 2a19f25:	mov    0x14(%rdi),%edx
 2a19f28:	test   %edx,%edx
 2a19f2a:	je     2a1a317 <wasm[0]::function[1016]::helper::object_write+0x6d7>
 2a19f30:	test   %edx,%edx
 2a19f32:	je     2a1a319 <wasm[0]::function[1016]::helper::object_write+0x6d9>
 2a19f38:	mov    %edx,%edi
 2a19f3a:	lea    0x10(%rsi,%rdi,1),%rdx
 2a19f3f:	cmp    %rax,%rdi
 2a19f42:	cmova  %rcx,%rdx
 2a19f46:	mov    (%rdx),%eax
 2a19f48:	test   %eax,%eax
 2a19f4a:	setne  %al
 2a19f4d:	movzbl %al,%eax
 2a19f50:	jmp    2a1a038 <wasm[0]::function[1016]::helper::object_write+0x3f8>
 2a19f55:	movq   %rcx,%xmm0
 2a19f5a:	ucomisd 0x3ee(%rip),%xmm0        # 2a1a350 <wasm[0]::function[1016]::helper::object_write+0x710>
 2a19f62:	setnp  %al
 2a19f65:	sete   %cl
 2a19f68:	and    %ecx,%eax
 2a19f6a:	ucomisd %xmm0,%xmm0
 2a19f6e:	setp   %cl
 2a19f71:	setne  %dl
 2a19f74:	or     %edx,%ecx
 2a19f76:	or     %ecx,%eax
 2a19f78:	movzbl %al,%eax
 2a19f7b:	test   %eax,%eax
 2a19f7d:	sete   %al
 2a19f80:	movzbl %al,%eax
 2a19f83:	jmp    2a1a038 <wasm[0]::function[1016]::helper::object_write+0x3f8>
 2a19f88:	xor    %eax,%eax
 2a19f8a:	test   %edx,%edx
 2a19f8c:	je     2a19fcd <wasm[0]::function[1016]::helper::object_write+0x38d>
 2a19f92:	xor    %eax,%eax
 2a19f94:	test   $0x1,%edx
 2a19f9a:	jne    2a19fcd <wasm[0]::function[1016]::helper::object_write+0x38d>
 2a19fa0:	mov    0x28(%r12),%rax
 2a19fa5:	mov    0x20(%r12),%rsi
 2a19faa:	mov    %edx,%edi
 2a19fac:	xor    %rcx,%rcx
 2a19faf:	lea    0x4(%rsi,%rdi,1),%rsi
 2a19fb4:	cmp    %rax,%rdi
 2a19fb7:	cmova  %rcx,%rsi
 2a19fbb:	mov    (%rsi),%eax
 2a19fbd:	mov    0x28(%rbx),%rcx
 2a19fc1:	cmp    0x234(%rcx),%eax
 2a19fc7:	sete   %al
 2a19fca:	movzbl %al,%eax
 2a19fcd:	test   %eax,%eax
 2a19fcf:	je     2a1a31b <wasm[0]::function[1016]::helper::object_write+0x6db>
 2a19fd5:	test   %edx,%edx
 2a19fd7:	je     2a1a31d <wasm[0]::function[1016]::helper::object_write+0x6dd>
 2a19fdd:	test   %edx,%edx
 2a19fdf:	je     2a1a31f <wasm[0]::function[1016]::helper::object_write+0x6df>
 2a19fe5:	mov    0x28(%r12),%rax
 2a19fea:	mov    0x20(%r12),%rsi
 2a19fef:	mov    %edx,%edx
 2a19ff1:	xor    %rcx,%rcx
 2a19ff4:	lea    (%rsi,%rdx,1),%rdi
 2a19ff8:	cmp    %rax,%rdx
 2a19ffb:	cmova  %rcx,%rdi
 2a19fff:	mov    0x10(%rdi),%edx
 2a1a002:	test   %edx,%edx
 2a1a004:	je     2a1a321 <wasm[0]::function[1016]::helper::object_write+0x6e1>
 2a1a00a:	test   %edx,%edx
 2a1a00c:	je     2a1a323 <wasm[0]::function[1016]::helper::object_write+0x6e3>
 2a1a012:	mov    %edx,%edi
 2a1a014:	lea    0x10(%rsi,%rdi,1),%rdx
 2a1a019:	cmp    %rax,%rdi
 2a1a01c:	cmova  %rcx,%rdx
 2a1a020:	mov    (%rdx),%eax
 2a1a022:	test   %eax,%eax
 2a1a024:	setne  %al
 2a1a027:	movzbl %al,%eax
 2a1a02a:	jmp    2a1a038 <wasm[0]::function[1016]::helper::object_write+0x3f8>
 2a1a02f:	test   %rcx,%rcx
 2a1a032:	setne  %al
 2a1a035:	movzbl %al,%eax
 2a1a038:	test   %eax,%eax
 2a1a03a:	sete   %al
 2a1a03d:	movzbl %al,%eax
 2a1a040:	mov    0x90(%rsp),%rcx
 2a1a048:	test   %eax,%ecx
 2a1a04a:	jne    2a1a066 <wasm[0]::function[1016]::helper::object_write+0x426>
 2a1a050:	xor    %eax,%eax
 2a1a052:	xor    %rcx,%rcx
 2a1a055:	mov    %rax,%rdx
 2a1a058:	mov    %rax,%rbx
 2a1a05b:	mov    %rax,%rsi
 2a1a05e:	mov    %rcx,%r14
 2a1a061:	jmp    2a1a298 <wasm[0]::function[1016]::helper::object_write+0x658>
 2a1a066:	mov    0x58(%rsp),%esi
 2a1a06a:	xor    %edx,%edx
 2a1a06c:	xor    %rcx,%rcx
 2a1a06f:	mov    %rcx,%r14
 2a1a072:	mov    %esi,0x50(%rsp)
 2a1a076:	mov    %edx,0x58(%rsp)
 2a1a07a:	mov    0xa0(%rsp),%r13
 2a1a082:	mov    0x0(%r13),%rsi
 2a1a086:	mov    0x98(%rsp),%rax
 2a1a08e:	cmp    %rax,%rsi
 2a1a091:	jae    2a1a2ec <wasm[0]::function[1016]::helper::object_write+0x6ac>
 2a1a097:	mov    0x50(%rsp),%ecx
 2a1a09b:	mov    0x58(%rsp),%edx
 2a1a09f:	test   %ecx,%ecx
 2a1a0a1:	je     2a1a11d <wasm[0]::function[1016]::helper::object_write+0x4dd>
 2a1a0a7:	mov    0x50(%rsp),%ecx
 2a1a0ab:	test   %ecx,%ecx
 2a1a0ad:	je     2a1a325 <wasm[0]::function[1016]::helper::object_write+0x6e5>
 2a1a0b3:	mov    0x28(%r12),%rdx
 2a1a0b8:	mov    0x20(%r12),%rsi
 2a1a0bd:	mov    %ecx,%ecx
 2a1a0bf:	add    %rcx,%rsi
 2a1a0c2:	cmp    %rdx,%rcx
 2a1a0c5:	mov    %r14,%rcx
 2a1a0c8:	cmova  %rcx,%rsi
 2a1a0cc:	mov    0x10(%rsi),%edx
 2a1a0cf:	test   %edx,%edx
 2a1a0d1:	je     2a1a0df <wasm[0]::function[1016]::helper::object_write+0x49f>
 2a1a0d7:	mov    %rcx,%r14
 2a1a0da:	jmp    2a1a11d <wasm[0]::function[1016]::helper::object_write+0x4dd>
 2a1a0df:	mov    0x50(%rsp),%esi
 2a1a0e3:	test   %esi,%esi
 2a1a0e5:	je     2a1a327 <wasm[0]::function[1016]::helper::object_write+0x6e7>
 2a1a0eb:	mov    0x28(%r12),%rdi
 2a1a0f0:	mov    %esi,%r8d
 2a1a0f3:	mov    %r8,%rsi
 2a1a0f6:	add    0x20(%r12),%rsi
 2a1a0fb:	cmp    %rdi,%r8
 2a1a0fe:	cmova  %rcx,%rsi
 2a1a102:	mov    %rcx,%r14
 2a1a105:	mov    0x1c(%rsi),%esi
 2a1a108:	mov    %rax,0x98(%rsp)
 2a1a110:	mov    %r13,0xa0(%rsp)
 2a1a118:	jmp    2a1a072 <wasm[0]::function[1016]::helper::object_write+0x432>
 2a1a11d:	test   %edx,%edx
 2a1a11f:	jne    2a1a133 <wasm[0]::function[1016]::helper::object_write+0x4f3>
 2a1a125:	mov    0x8c0(%rbx),%edx
 2a1a12b:	test   %edx,%edx
 2a1a12d:	je     2a1a329 <wasm[0]::function[1016]::helper::object_write+0x6e9>
 2a1a133:	mov    %edx,0x50(%rsp)
 2a1a137:	test   %edx,%edx
 2a1a139:	je     2a1a32b <wasm[0]::function[1016]::helper::object_write+0x6eb>
 2a1a13f:	mov    %rbx,%rsi
 2a1a142:	mov    %rbx,%rdi
 2a1a145:	call   2ae3360 <wasm[0]::function[1049]::helper::realm_ensure_errors>
 2a1a14a:	mov    0x50(%rsp),%edx
 2a1a14e:	test   %edx,%edx
 2a1a150:	je     2a1a32d <wasm[0]::function[1016]::helper::object_write+0x6ed>
 2a1a156:	test   %edx,%edx
 2a1a158:	je     2a1a32f <wasm[0]::function[1016]::helper::object_write+0x6ef>
 2a1a15e:	mov    0x28(%r12),%rax
 2a1a163:	mov    0x20(%r12),%rcx
 2a1a168:	mov    %edx,%esi
 2a1a16a:	lea    (%rcx,%rsi,1),%rdx
 2a1a16e:	cmp    %rax,%rsi
 2a1a171:	mov    %r14,%rsi
 2a1a174:	cmova  %rsi,%rdx
 2a1a178:	mov    0x2c(%rdx),%edx
 2a1a17b:	test   %edx,%edx
 2a1a17d:	je     2a1a331 <wasm[0]::function[1016]::helper::object_write+0x6f1>
 2a1a183:	test   %edx,%edx
 2a1a185:	je     2a1a333 <wasm[0]::function[1016]::helper::object_write+0x6f3>
 2a1a18b:	mov    %edx,%edi
 2a1a18d:	lea    0x10(%rcx,%rdi,1),%rsi
 2a1a192:	cmp    %rax,%rdi
 2a1a195:	mov    %r14,%rdi
 2a1a198:	cmova  %rdi,%rsi
 2a1a19c:	mov    (%rsi),%esi
 2a1a19e:	cmp    $0x3,%esi
 2a1a1a1:	jbe    2a1a335 <wasm[0]::function[1016]::helper::object_write+0x6f5>
 2a1a1a7:	mov    %esi,%edi
 2a1a1a9:	shl    $0x2,%rdi
 2a1a1ad:	shr    $0x20,%rdi
 2a1a1b1:	test   %rdi,%rdi
 2a1a1b4:	jne    2a1a337 <wasm[0]::function[1016]::helper::object_write+0x6f7>
 2a1a1ba:	shl    $0x2,%esi
 2a1a1bd:	add    $0x14,%esi
 2a1a1c0:	jb     2a1a339 <wasm[0]::function[1016]::helper::object_write+0x6f9>
 2a1a1c6:	add    %esi,%edx
 2a1a1c8:	jb     2a1a33b <wasm[0]::function[1016]::helper::object_write+0x6fb>
 2a1a1ce:	mov    %edx,%edi
 2a1a1d0:	lea    (%rcx,%rdi,1),%rdx
 2a1a1d4:	cmp    %rax,%rdi
 2a1a1d7:	mov    %r14,%rdi
 2a1a1da:	cmova  %rdi,%rdx
 2a1a1de:	sub    $0x20,%esi
 2a1a1e1:	sub    %rsi,%rdx
 2a1a1e4:	mov    (%rdx),%edx
 2a1a1e6:	test   %edx,%edx
 2a1a1e8:	je     2a1a33d <wasm[0]::function[1016]::helper::object_write+0x6fd>
 2a1a1ee:	test   %edx,%edx
 2a1a1f0:	je     2a1a33f <wasm[0]::function[1016]::helper::object_write+0x6ff>
 2a1a1f6:	mov    %edx,%edx
 2a1a1f8:	add    %rdx,%rcx
 2a1a1fb:	cmp    %rax,%rdx
 2a1a1fe:	mov    %r14,%rdx
 2a1a201:	cmova  %rdx,%rcx
 2a1a205:	mov    0x18(%rcx),%r13d
 2a1a209:	mov    0x10(%rcx),%r12
 2a1a20d:	mov    0x1c(%rcx),%eax
 2a1a210:	mov    %eax,0x50(%rsp)
 2a1a214:	cmp    $0x6,%r13d
 2a1a218:	sete   %cl
 2a1a21b:	cmp    $0x7,%r13d
 2a1a21f:	sete   %al
 2a1a222:	or     %eax,%ecx
 2a1a224:	cmp    $0x8,%r13d
 2a1a228:	sete   %al
 2a1a22b:	or     %eax,%ecx
 2a1a22d:	cmp    $0x9,%r13d
 2a1a231:	sete   %al
 2a1a234:	or     %eax,%ecx
 2a1a236:	movzbl %cl,%eax
 2a1a239:	test   %eax,%eax
 2a1a23b:	je     2a1a341 <wasm[0]::function[1016]::helper::object_write+0x701>
 2a1a241:	mov    $0x795,%edx
 2a1a246:	mov    %rbx,%rsi
 2a1a249:	mov    %rbx,%rdi
 2a1a24c:	call   2f4f240 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 2a1a251:	mov    %rbx,%rsi
 2a1a254:	xor    %edi,%edi
 2a1a256:	mov    %rdi,%rbx
 2a1a259:	test   %eax,%eax
 2a1a25b:	je     2a1a343 <wasm[0]::function[1016]::helper::object_write+0x703>
 2a1a261:	mov    0x50(%rsp),%r9d
 2a1a266:	mov    $0x5,%edx
 2a1a26b:	mov    %eax,(%rsp)
 2a1a26e:	mov    %r13,%rcx
 2a1a271:	mov    %r12,%r8
 2a1a274:	mov    %rsi,%rdi
 2a1a277:	call   2f4efa0 <wasm[0]::function[1101]::helper::runtime_error_for_throw>
 2a1a27c:	sub    $0x10,%rsp
 2a1a280:	test   %eax,%eax
 2a1a282:	mov    %rax,%rcx
 2a1a285:	je     2a1a345 <wasm[0]::function[1016]::helper::object_write+0x705>
 2a1a28b:	mov    $0x6,%eax
 2a1a290:	mov    $0x1,%esi
 2a1a295:	mov    %rcx,%rdx
 2a1a298:	mov    %r14,%rcx
 2a1a29b:	mov    %rbx,%rdi
 2a1a29e:	mov    0xb0(%rsp),%rbx
 2a1a2a6:	mov    0xb8(%rsp),%r12
 2a1a2ae:	mov    0xc0(%rsp),%r13
 2a1a2b6:	mov    0xc8(%rsp),%r14
 2a1a2be:	mov    0xd0(%rsp),%r15
 2a1a2c6:	add    $0xe0,%rsp
 2a1a2cd:	mov    %rbp,%rsp
 2a1a2d0:	pop    %rbp
 2a1a2d1:	ret    $0x40
 2a1a2d4:	mov    %rsi,%rbx
 2a1a2d7:	mov    %rbx,%rdi
 2a1a2da:	call   3039b69 <wasmtime_builtin_new_epoch>
 2a1a2df:	mov    %rax,0x98(%rsp)
 2a1a2e7:	jmp    2a19d0d <wasm[0]::function[1016]::helper::object_write+0xcd>
 2a1a2ec:	mov    0x8(%r12),%rax
 2a1a2f1:	cmp    %rax,%rsi
 2a1a2f4:	jb     2a1a097 <wasm[0]::function[1016]::helper::object_write+0x457>
 2a1a2fa:	mov    %rbx,%rdi
 2a1a2fd:	call   3039b69 <wasmtime_builtin_new_epoch>
 2a1a302:	jmp    2a1a097 <wasm[0]::function[1016]::helper::object_write+0x457>
 2a1a307:	ud2
 2a1a309:	ud2
 2a1a30b:	ud2
 2a1a30d:	ud2
 2a1a30f:	ud2
 2a1a311:	ud2
 2a1a313:	ud2
 2a1a315:	ud2
 2a1a317:	ud2
 2a1a319:	ud2
 2a1a31b:	ud2
 2a1a31d:	ud2
 2a1a31f:	ud2
 2a1a321:	ud2
 2a1a323:	ud2
 2a1a325:	ud2
 2a1a327:	ud2
 2a1a329:	ud2
 2a1a32b:	ud2
 2a1a32d:	ud2
 2a1a32f:	ud2
 2a1a331:	ud2
 2a1a333:	ud2
 2a1a335:	ud2
 2a1a337:	ud2
 2a1a339:	ud2
 2a1a33b:	ud2
 2a1a33d:	ud2
 2a1a33f:	ud2
 2a1a341:	ud2
 2a1a343:	ud2
 2a1a345:	ud2
	...
