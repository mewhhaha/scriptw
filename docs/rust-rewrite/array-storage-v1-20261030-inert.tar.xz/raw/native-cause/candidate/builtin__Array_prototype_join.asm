
/workspace/scriptw/target/performance-dense-numbers-20261030/native-cause/candidate/runtime-portable.elf:     file format elf64-x86-64


Disassembly of section .text:

0000000000417380 <wasm[0]::function[131]::builtin::Array.prototype.join>:
  417380:	push   %rbp
  417381:	mov    %rsp,%rbp
  417384:	mov    0x8(%rdi),%r10
  417388:	mov    0x18(%r10),%r10
  41738c:	add    $0x190,%r10
  417393:	cmp    %rsp,%r10
  417396:	ja     419e09 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2a89>
  41739c:	sub    $0x180,%rsp
  4173a3:	mov    %rbx,0x150(%rsp)
  4173ab:	mov    %r12,0x158(%rsp)
  4173b3:	mov    %r13,0x160(%rsp)
  4173bb:	mov    %r14,0x168(%rsp)
  4173c3:	mov    %r15,0x170(%rsp)
  4173cb:	mov    %r8,%r13
  4173ce:	mov    %rcx,%r14
  4173d1:	mov    0x28(%rbp),%r12
  4173d5:	mov    0x30(%rbp),%r8
  4173d9:	mov    0x40(%rbp),%r10
  4173dd:	mov    %edx,0x48(%rsp)
  4173e1:	mov    %r9d,0x40(%rsp)
  4173e6:	mov    %r8d,0xb0(%rsp)
  4173ee:	mov    %r10d,0x58(%rsp)
  4173f3:	movl   $0x0,0x80(%rsp)
  4173fe:	mov    0x18(%rdi),%rax
  417402:	mov    (%rax),%rcx
  417405:	mov    %rax,0x140(%rsp)
  41740d:	mov    0x8(%rdi),%rdx
  417411:	mov    %rdi,0xb8(%rsp)
  417419:	mov    0x8(%rdx),%rax
  41741d:	mov    %rdx,0x138(%rsp)
  417425:	cmp    %rax,%rcx
  417428:	jae    419764 <wasm[0]::function[131]::builtin::Array.prototype.join+0x23e4>
  41742e:	mov    %rax,0xe0(%rsp)
  417436:	mov    0x48(%rsp),%edx
  41743a:	test   %edx,%edx
  41743c:	je     419e0b <wasm[0]::function[131]::builtin::Array.prototype.join+0x2a8b>
  417442:	test   %edx,%edx
  417444:	je     419e0d <wasm[0]::function[131]::builtin::Array.prototype.join+0x2a8d>
  41744a:	mov    0x138(%rsp),%r10
  417452:	mov    0x28(%r10),%rcx
  417456:	mov    0x20(%r10),%rsi
  41745a:	mov    %edx,%eax
  41745c:	xor    %rdx,%rdx
  41745f:	lea    (%rsi,%rax,1),%rdi
  417463:	cmp    %rcx,%rax
  417466:	cmova  %rdx,%rdi
  41746a:	mov    0x18(%rdi),%r8d
  41746e:	mov    %r8d,0x48(%rsp)
  417473:	mov    0x58(%rsp),%edi
  417477:	test   %edi,%edi
  417479:	je     419e0f <wasm[0]::function[131]::builtin::Array.prototype.join+0x2a8f>
  41747f:	test   %r8d,%r8d
  417482:	je     419e11 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2a91>
  417488:	test   %r8d,%r8d
  41748b:	je     419e13 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2a93>
  417491:	mov    %r8d,%r8d
  417494:	lea    (%rsi,%r8,1),%rax
  417498:	cmp    %rcx,%r8
  41749b:	cmova  %rdx,%rax
  41749f:	mov    0x34(%rax),%ecx
  4174a2:	test   %ecx,%ecx
  4174a4:	jne    4174b2 <wasm[0]::function[131]::builtin::Array.prototype.join+0x132>
  4174aa:	mov    %rdi,%rcx
  4174ad:	jmp    4174ba <wasm[0]::function[131]::builtin::Array.prototype.join+0x13a>
  4174b2:	test   %ecx,%ecx
  4174b4:	je     419e15 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2a95>
  4174ba:	mov    %ecx,0x58(%rsp)
  4174be:	mov    0xb0(%rsp),%esi
  4174c5:	test   %esi,%esi
  4174c7:	je     417516 <wasm[0]::function[131]::builtin::Array.prototype.join+0x196>
  4174cd:	mov    0xb0(%rsp),%edi
  4174d4:	test   %edi,%edi
  4174d6:	je     419e17 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2a97>
  4174dc:	mov    0x28(%r10),%r9
  4174e0:	mov    0x20(%r10),%r11
  4174e4:	mov    %r10,0x138(%rsp)
  4174ec:	mov    %edi,%r10d
  4174ef:	lea    0x10(%r11,%r10,1),%rsi
  4174f4:	xor    %r11,%r11
  4174f7:	cmp    %r9,%r10
  4174fa:	cmova  %r11,%rsi
  4174fe:	mov    (%rsi),%r10d
  417501:	cmp    %r12,%r10
  417504:	jne    419e19 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2a99>
  41750a:	mov    0xb0(%rsp),%eax
  417511:	jmp    417589 <wasm[0]::function[131]::builtin::Array.prototype.join+0x209>
  417516:	mov    %r10,0x138(%rsp)
  41751e:	test   %r12,%r12
  417521:	jne    419e1b <wasm[0]::function[131]::builtin::Array.prototype.join+0x2a9b>
  417527:	mov    0xb8(%rsp),%rdi
  41752f:	mov    0x20(%rdi),%rdx
  417533:	mov    (%rdx),%eax
  417535:	mov    %eax,%ecx
  417537:	lea    0x20(%rcx),%rsi
  41753b:	mov    0x4(%rdx),%edi
  41753e:	cmp    %rdi,%rsi
  417541:	ja     41977e <wasm[0]::function[131]::builtin::Array.prototype.join+0x23fe>
  417547:	lea    0x20(%rax),%esi
  41754a:	mov    %esi,(%rdx)
  41754c:	mov    0x138(%rsp),%r9
  417554:	mov    0x20(%r9),%rsi
  417558:	lea    (%rsi,%rcx,1),%rdx
  41755c:	movl   $0xa800000e,(%rsi,%rcx,1)
  417563:	mov    0xb8(%rsp),%rdi
  41756b:	mov    0x28(%rdi),%rdi
  41756f:	mov    0x1b4(%rdi),%edi
  417575:	mov    %edi,0x4(%rsi,%rcx,1)
  417579:	mov    $0x20,%edi
  41757e:	mov    %edi,0x8(%rsi,%rcx,1)
  417582:	movl   $0x0,0x10(%rdx)
  417589:	mov    %eax,0xb0(%rsp)
  417590:	test   %eax,%eax
  417592:	je     419e1d <wasm[0]::function[131]::builtin::Array.prototype.join+0x2a9d>
  417598:	test   %eax,%eax
  41759a:	je     419e1f <wasm[0]::function[131]::builtin::Array.prototype.join+0x2a9f>
  4175a0:	mov    0x138(%rsp),%r9
  4175a8:	mov    0x28(%r9),%rcx
  4175ac:	mov    0x20(%r9),%rdx
  4175b0:	mov    %eax,%edi
  4175b2:	lea    0x10(%rdx,%rdi,1),%rsi
  4175b7:	xor    %rax,%rax
  4175ba:	cmp    %rcx,%rdi
  4175bd:	cmova  %rax,%rsi
  4175c1:	mov    (%rsi),%esi
  4175c3:	mov    0x48(%rsp),%esi
  4175c7:	test   %esi,%esi
  4175c9:	je     419e21 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2aa1>
  4175cf:	test   %esi,%esi
  4175d1:	je     419e23 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2aa3>
  4175d7:	mov    %esi,%esi
  4175d9:	add    %rsi,%rdx
  4175dc:	cmp    %rcx,%rsi
  4175df:	cmova  %rax,%rdx
  4175e3:	mov    0x14(%rdx),%eax
  4175e6:	mov    %eax,0x50(%rsp)
  4175ea:	mov    0x18(%rdx),%eax
  4175ed:	mov    0xb8(%rsp),%rdi
  4175f5:	mov    0x8c0(%rdi),%edx
  4175fb:	test   %edx,%edx
  4175fd:	je     419e25 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2aa5>
  417603:	mov    0x40(%rsp),%r9d
  417608:	mov    %r14,%rcx
  41760b:	mov    %r13,%r8
  41760e:	mov    0xb8(%rsp),%rsi
  417616:	call   2a80460 <wasm[0]::function[1041]::helper::value_to_object>
  41761b:	mov    %rax,0x128(%rsp)
  417623:	mov    %rcx,0x130(%rsp)
  41762b:	mov    %edx,0x40(%rsp)
  41762f:	cmp    $0x1,%esi
  417632:	je     41971e <wasm[0]::function[131]::builtin::Array.prototype.join+0x239e>
  417638:	mov    $0x8c,%edx
  41763d:	mov    0xb8(%rsp),%rsi
  417645:	mov    0xb8(%rsp),%rdi
  41764d:	call   2f4f240 <wasm[0]::function[1102]::helper::pooled_string_resolve>
  417652:	test   %eax,%eax
  417654:	je     419e27 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2aa7>
  41765a:	mov    0x58(%rsp),%ecx
  41765e:	test   %ecx,%ecx
  417660:	je     419e29 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2aa9>
  417666:	mov    0x40(%rsp),%r8d
  41766b:	mov    0x50(%rsp),%edx
  41766f:	mov    $0x4,%esi
  417674:	xor    %rdi,%rdi
  417677:	mov    0x130(%rsp),%r9
  41767f:	mov    %r9,(%rsp)
  417683:	mov    %r8d,0x8(%rsp)
  417688:	mov    %esi,0x10(%rsp)
  41768c:	mov    %rdi,0x18(%rsp)
  417691:	mov    %eax,0x20(%rsp)
  417695:	mov    %edx,0x28(%rsp)
  417699:	mov    %ecx,0x30(%rsp)
  41769d:	mov    0x130(%rsp),%rcx
  4176a5:	mov    0x128(%rsp),%rdx
  4176ad:	mov    0xb8(%rsp),%rsi
  4176b5:	mov    0xb8(%rsp),%rdi
  4176bd:	mov    0x128(%rsp),%r9
  4176c5:	call   29fe160 <wasm[0]::function[1015]::helper::object_read>
  4176ca:	sub    $0x40,%rsp
  4176ce:	mov    %rdx,%r8
  4176d1:	mov    %rax,%rdx
  4176d4:	cmp    $0x1,%esi
  4176d7:	je     4196e2 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2362>
  4176dd:	mov    0x58(%rsp),%eax
  4176e1:	test   %eax,%eax
  4176e3:	je     419e2b <wasm[0]::function[131]::builtin::Array.prototype.join+0x2aab>
  4176e9:	mov    0x50(%rsp),%r9d
  4176ee:	mov    %eax,(%rsp)
  4176f1:	mov    0xb8(%rsp),%rsi
  4176f9:	mov    0xb8(%rsp),%rdi
  417701:	call   2b0ca20 <wasm[0]::function[1062]::helper::value_to_number>
  417706:	sub    $0x10,%rsp
  41770a:	mov    %rdi,%rbx
  41770d:	mov    %rax,%r15
  417710:	mov    %edx,0x48(%rsp)
  417714:	xor    %r13,%r13
  417717:	test   %esi,%esi
  417719:	mov    %rsi,%r12
  41771c:	je     41772d <wasm[0]::function[131]::builtin::Array.prototype.join+0x3ad>
  417722:	mov    %r12,%rsi
  417725:	mov    %rcx,%r14
  417728:	jmp    4177de <wasm[0]::function[131]::builtin::Array.prototype.join+0x45e>
  41772d:	movq   %rcx,%xmm0
  417732:	mov    %rcx,%r14
  417735:	ucomisd %xmm0,%xmm0
  417739:	setp   %al
  41773c:	setne  %cl
  41773f:	or     %ecx,%eax
  417741:	xorpd  %xmm1,%xmm1
  417745:	ucomisd %xmm0,%xmm1
  417749:	setae  %cl
  41774c:	or     %ecx,%eax
  41774e:	test   %al,%al
  417750:	jne    4177d8 <wasm[0]::function[131]::builtin::Array.prototype.join+0x458>
  417756:	ucomisd 0x27b2(%rip),%xmm0        # 419f10 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b90>
  41775e:	ja     4177c9 <wasm[0]::function[131]::builtin::Array.prototype.join+0x449>
  417764:	mov    0xb8(%rsp),%rdi
  41776c:	call   3039d4f <wasmtime_builtin_trunc_f64>
  417771:	movabs $0x43e0000000000000,%rax
  41777b:	movq   %rax,%xmm2
  417780:	ucomisd %xmm2,%xmm0
  417784:	jae    4177a1 <wasm[0]::function[131]::builtin::Array.prototype.join+0x421>
  41778a:	jp     419e2d <wasm[0]::function[131]::builtin::Array.prototype.join+0x2aad>
  417790:	cvttsd2si %xmm0,%r13
  417795:	cmp    $0x0,%r13
  417799:	jge    4177db <wasm[0]::function[131]::builtin::Array.prototype.join+0x45b>
  41779f:	ud2
  4177a1:	movaps %xmm0,%xmm1
  4177a4:	subsd  %xmm2,%xmm1
  4177a8:	cvttsd2si %xmm1,%r13
  4177ad:	cmp    $0x0,%r13
  4177b1:	jl     419e2f <wasm[0]::function[131]::builtin::Array.prototype.join+0x2aaf>
  4177b7:	movabs $0x8000000000000000,%rax
  4177c1:	add    %rax,%r13
  4177c4:	jmp    4177db <wasm[0]::function[131]::builtin::Array.prototype.join+0x45b>
  4177c9:	movabs $0x1fffffffffffff,%r13
  4177d3:	jmp    4177db <wasm[0]::function[131]::builtin::Array.prototype.join+0x45b>
  4177d8:	xor    %r13,%r13
  4177db:	mov    %r12,%rsi
  4177de:	cmp    $0x1,%esi
  4177e1:	je     41969f <wasm[0]::function[131]::builtin::Array.prototype.join+0x231f>
  4177e7:	mov    $0x5,%edx
  4177ec:	mov    0xb8(%rsp),%rsi
  4177f4:	mov    0xb8(%rsp),%rdi
  4177fc:	call   2f4f240 <wasm[0]::function[1102]::helper::pooled_string_resolve>
  417801:	mov    %rax,%r10
  417804:	mov    0xb0(%rsp),%eax
  41780b:	test   %eax,%eax
  41780d:	je     419e31 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2ab1>
  417813:	test   %eax,%eax
  417815:	je     419e33 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2ab3>
  41781b:	mov    0x138(%rsp),%r9
  417823:	mov    0x28(%r9),%rsi
  417827:	mov    0x20(%r9),%r8
  41782b:	mov    %eax,%edi
  41782d:	lea    0x10(%r8,%rdi,1),%rax
  417832:	xor    %r8,%r8
  417835:	cmp    %rsi,%rdi
  417838:	cmova  %r8,%rax
  41783c:	mov    (%rax),%esi
  41783e:	test   %esi,%esi
  417840:	jne    417853 <wasm[0]::function[131]::builtin::Array.prototype.join+0x4d3>
  417846:	xor    %edx,%edx
  417848:	xor    %rcx,%rcx
  41784b:	mov    %rdx,%r8
  41784e:	jmp    4178fa <wasm[0]::function[131]::builtin::Array.prototype.join+0x57a>
  417853:	mov    0xb0(%rsp),%esi
  41785a:	test   %esi,%esi
  41785c:	je     419e35 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2ab5>
  417862:	test   %esi,%esi
  417864:	je     419e37 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2ab7>
  41786a:	mov    0x138(%rsp),%r9
  417872:	mov    0x28(%r9),%r11
  417876:	mov    0x20(%r9),%rcx
  41787a:	mov    %esi,%eax
  41787c:	lea    0x10(%rcx,%rax,1),%r8
  417881:	xor    %rdx,%rdx
  417884:	cmp    %r11,%rax
  417887:	cmova  %rdx,%r8
  41788b:	mov    (%r8),%edi
  41788e:	test   %edi,%edi
  417890:	je     419e39 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2ab9>
  417896:	mov    %edi,%eax
  417898:	shl    $0x2,%rax
  41789c:	shr    $0x20,%rax
  4178a0:	test   %rax,%rax
  4178a3:	jne    419e3b <wasm[0]::function[131]::builtin::Array.prototype.join+0x2abb>
  4178a9:	shl    $0x2,%edi
  4178ac:	add    $0x14,%edi
  4178af:	jb     419e3d <wasm[0]::function[131]::builtin::Array.prototype.join+0x2abd>
  4178b5:	add    %edi,%esi
  4178b7:	jb     419e3f <wasm[0]::function[131]::builtin::Array.prototype.join+0x2abf>
  4178bd:	mov    %esi,%esi
  4178bf:	lea    (%rcx,%rsi,1),%rax
  4178c3:	cmp    %r11,%rsi
  4178c6:	cmova  %rdx,%rax
  4178ca:	sub    $0x14,%edi
  4178cd:	sub    %rdi,%rax
  4178d0:	mov    (%rax),%eax
  4178d2:	test   %eax,%eax
  4178d4:	je     419e41 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2ac1>
  4178da:	test   %eax,%eax
  4178dc:	je     419e43 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2ac3>
  4178e2:	mov    %eax,%esi
  4178e4:	lea    (%rcx,%rsi,1),%rax
  4178e8:	cmp    %r11,%rsi
  4178eb:	cmova  %rdx,%rax
  4178ef:	mov    0x18(%rax),%edx
  4178f2:	mov    0x10(%rax),%rcx
  4178f6:	mov    0x1c(%rax),%r8d
  4178fa:	test   %edx,%edx
  4178fc:	jne    41790a <wasm[0]::function[131]::builtin::Array.prototype.join+0x58a>
  417902:	mov    %r10,%rdx
  417905:	jmp    41799b <wasm[0]::function[131]::builtin::Array.prototype.join+0x61b>
  41790a:	mov    0x58(%rsp),%eax
  41790e:	test   %eax,%eax
  417910:	je     419e45 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2ac5>
  417916:	mov    0x50(%rsp),%r9d
  41791b:	mov    %eax,(%rsp)
  41791e:	mov    0xb8(%rsp),%rsi
  417926:	mov    0xb8(%rsp),%rdi
  41792e:	call   2b0b4c0 <wasm[0]::function[1061]::helper::value_to_string>
  417933:	sub    $0x10,%rsp
  417937:	cmp    $0x1,%esi
  41793a:	je     419669 <wasm[0]::function[131]::builtin::Array.prototype.join+0x22e9>
  417940:	xor    %eax,%eax
  417942:	test   %edx,%edx
  417944:	je     417993 <wasm[0]::function[131]::builtin::Array.prototype.join+0x613>
  41794a:	xor    %eax,%eax
  41794c:	test   $0x1,%edx
  417952:	jne    417993 <wasm[0]::function[131]::builtin::Array.prototype.join+0x613>
  417958:	mov    0x138(%rsp),%r9
  417960:	mov    0x28(%r9),%rax
  417964:	mov    0x20(%r9),%rcx
  417968:	mov    %edx,%esi
  41796a:	lea    0x4(%rcx,%rsi,1),%rcx
  41796f:	xor    %rdi,%rdi
  417972:	cmp    %rax,%rsi
  417975:	cmova  %rdi,%rcx
  417979:	mov    (%rcx),%eax
  41797b:	mov    0xb8(%rsp),%rdi
  417983:	mov    0x28(%rdi),%rcx
  417987:	cmp    0x234(%rcx),%eax
  41798d:	sete   %al
  417990:	movzbl %al,%eax
  417993:	test   %eax,%eax
  417995:	je     419e47 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2ac7>
  41799b:	mov    %edx,0xb0(%rsp)
  4179a2:	xor    %eax,%eax
  4179a4:	mov    %rax,%rbx
  4179a7:	test   %edx,%edx
  4179a9:	je     419e49 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2ac9>
  4179af:	mov    0x40(%rsp),%r8d
  4179b4:	mov    %edx,(%rsp)
  4179b7:	mov    0x130(%rsp),%rcx
  4179bf:	mov    0x128(%rsp),%rdx
  4179c7:	mov    0xb8(%rsp),%rsi
  4179cf:	mov    0xb8(%rsp),%rdi
  4179d7:	mov    %r13,%r9
  4179da:	call   29f2ea0 <wasm[0]::function[1009]::helper::array_packed_join>
  4179df:	sub    $0x10,%rsp
  4179e3:	mov    %r13,0xd0(%rsp)
  4179eb:	mov    0x80(%rsp),%edx
  4179f2:	xor    %rcx,%rcx
  4179f5:	test   %eax,%eax
  4179f7:	je     417a13 <wasm[0]::function[131]::builtin::Array.prototype.join+0x693>
  4179fd:	test   %eax,%eax
  4179ff:	je     419e4b <wasm[0]::function[131]::builtin::Array.prototype.join+0x2acb>
  417a05:	mov    $0x4,%ecx
  417a0a:	mov    %rcx,%rbx
  417a0d:	xor    %rcx,%rcx
  417a10:	mov    %rax,%rdx
  417a13:	test   %eax,%eax
  417a15:	je     417a23 <wasm[0]::function[131]::builtin::Array.prototype.join+0x6a3>
  417a1b:	mov    %rbx,%rax
  417a1e:	jmp    41962e <wasm[0]::function[131]::builtin::Array.prototype.join+0x22ae>
  417a23:	mov    0xb8(%rsp),%rdi
  417a2b:	mov    0x20(%rdi),%r14
  417a2f:	mov    (%r14),%eax
  417a32:	mov    %eax,%ecx
  417a34:	mov    $0x20,%r13d
  417a3a:	lea    0x20(%rcx),%rdx
  417a3e:	mov    0x4(%r14),%esi
  417a42:	cmp    %rsi,%rdx
  417a45:	ja     4197b8 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2438>
  417a4b:	lea    0x20(%rax),%edx
  417a4e:	mov    %edx,(%r14)
  417a51:	mov    0x138(%rsp),%r9
  417a59:	mov    %r14,0x120(%rsp)
  417a61:	mov    0x20(%r9),%rsi
  417a65:	lea    (%rsi,%rcx,1),%rdx
  417a69:	movl   $0xa8000006,(%rsi,%rcx,1)
  417a70:	mov    0xb8(%rsp),%rdi
  417a78:	mov    0x28(%rdi),%rdi
  417a7c:	mov    0x238(%rdi),%edi
  417a82:	mov    %edi,0x4(%rsi,%rcx,1)
  417a86:	mov    %r13d,0x8(%rsi,%rcx,1)
  417a8b:	mov    %r13,0x118(%rsp)
  417a93:	mov    %eax,0x80(%rsp)
  417a9a:	movl   $0x0,0x10(%rdx)
  417aa1:	test   %eax,%eax
  417aa3:	je     419e4d <wasm[0]::function[131]::builtin::Array.prototype.join+0x2acd>
  417aa9:	mov    0x138(%rsp),%r9
  417ab1:	mov    0x28(%r9),%rsi
  417ab5:	mov    0x20(%r9),%rdi
  417ab9:	mov    %eax,%r8d
  417abc:	lea    0x10(%rdi,%r8,1),%rax
  417ac1:	xor    %rcx,%rcx
  417ac4:	cmp    %rsi,%r8
  417ac7:	cmova  %rcx,%rax
  417acb:	mov    %rcx,%r12
  417ace:	mov    (%rax),%r9d
  417ad1:	lea    0x14(%rdi,%r8,1),%rax
  417ad6:	mov    %rax,%r8
  417ad9:	add    $0x0,%r8
  417add:	mov    %rax,%r13
  417ae0:	jb     419e4f <wasm[0]::function[131]::builtin::Array.prototype.join+0x2acf>
  417ae6:	add    %rdi,%rsi
  417ae9:	cmp    %rsi,%r8
  417aec:	ja     419e51 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2ad1>
  417af2:	mov    0xb0(%rsp),%esi
  417af9:	mov    0x40(%rsp),%edx
  417afd:	mov    0x50(%rsp),%ecx
  417b01:	mov    0x58(%rsp),%eax
  417b05:	mov    %esi,0xb0(%rsp)
  417b0c:	mov    %edx,0x50(%rsp)
  417b10:	mov    %ecx,0x58(%rsp)
  417b14:	mov    %eax,0x68(%rsp)
  417b18:	mov    0x140(%rsp),%rax
  417b20:	mov    (%rax),%rcx
  417b23:	mov    0xe0(%rsp),%rax
  417b2b:	cmp    %rax,%rcx
  417b2e:	jae    419802 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2482>
  417b34:	mov    %rax,0xe0(%rsp)
  417b3c:	jmp    417b49 <wasm[0]::function[131]::builtin::Array.prototype.join+0x7c9>
  417b41:	mov    %rax,0xe0(%rsp)
  417b49:	xor    %ebx,%ebx
  417b4b:	mov    %r12,%rcx
  417b4e:	mov    %r13,%rsi
  417b51:	mov    %rbx,%rdx
  417b54:	mov    0xb8(%rsp),%rdi
  417b5c:	call   3039b13 <wasmtime_builtin_memory_fill>
  417b61:	mov    %rbx,0xc0(%rsp)
  417b69:	mov    0xb0(%rsp),%r8d
  417b71:	mov    0x80(%rsp),%edi
  417b78:	mov    0x50(%rsp),%edx
  417b7c:	mov    0x58(%rsp),%r9d
  417b81:	mov    0x68(%rsp),%esi
  417b85:	xor    %r14,%r14
  417b88:	mov    %r14,0xc8(%rsp)
  417b90:	mov    $0x10,%eax
  417b95:	mov    %rax,0x110(%rsp)
  417b9d:	mov    $0xa8000006,%eax
  417ba2:	mov    %rax,0x108(%rsp)
  417baa:	mov    0xb8(%rsp),%rax
  417bb2:	mov    0x28(%rax),%r13
  417bb6:	mov    0x238(%r13),%eax
  417bbd:	mov    %rax,0xf8(%rsp)
  417bc5:	mov    %r13,0x100(%rsp)
  417bcd:	mov    0xc0(%rsp),%rax
  417bd5:	mov    %rax,0xd8(%rsp)
  417bdd:	mov    %r8d,0x68(%rsp)
  417be2:	mov    %edi,0x58(%rsp)
  417be6:	mov    %edx,0x50(%rsp)
  417bea:	mov    %r9d,0x80(%rsp)
  417bf2:	mov    %esi,0xb0(%rsp)
  417bf9:	mov    0x140(%rsp),%rcx
  417c01:	mov    (%rcx),%rax
  417c04:	mov    0xe0(%rsp),%rcx
  417c0c:	cmp    %rcx,%rax
  417c0f:	jae    419831 <wasm[0]::function[131]::builtin::Array.prototype.join+0x24b1>
  417c15:	mov    0xc8(%rsp),%rcx
  417c1d:	mov    0xd0(%rsp),%r11
  417c25:	jmp    417c3a <wasm[0]::function[131]::builtin::Array.prototype.join+0x8ba>
  417c2a:	mov    0xc8(%rsp),%rcx
  417c32:	mov    0xd0(%rsp),%r11
  417c3a:	cmp    %r11,%rcx
  417c3d:	mov    %r11,0xd0(%rsp)
  417c45:	jae    419137 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1db7>
  417c4b:	mov    0x50(%rsp),%r8d
  417c50:	mov    0x80(%rsp),%eax
  417c57:	mov    0xb0(%rsp),%ecx
  417c5e:	mov    0x58(%rsp),%esi
  417c62:	mov    0x68(%rsp),%edi
  417c66:	mov    0xc8(%rsp),%rdx
  417c6e:	mov    0xc8(%rsp),%r9
  417c76:	test   %r9,%rdx
  417c79:	je     4185ed <wasm[0]::function[131]::builtin::Array.prototype.join+0x126d>
  417c7f:	mov    0x68(%rsp),%edx
  417c83:	test   %edx,%edx
  417c85:	je     419e53 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2ad3>
  417c8b:	test   %edx,%edx
  417c8d:	je     419e55 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2ad5>
  417c93:	mov    0x138(%rsp),%r9
  417c9b:	mov    0x28(%r9),%rax
  417c9f:	mov    0x20(%r9),%rcx
  417ca3:	mov    %edx,%edi
  417ca5:	lea    (%rcx,%rdi,1),%rsi
  417ca9:	xor    %rdx,%rdx
  417cac:	cmp    %rax,%rdi
  417caf:	cmova  %rdx,%rsi
  417cb3:	mov    0x10(%rsi),%esi
  417cb6:	mov    %esi,0x88(%rsp)
  417cbd:	test   %esi,%esi
  417cbf:	je     419e57 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2ad7>
  417cc5:	test   %esi,%esi
  417cc7:	je     419e59 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2ad9>
  417ccd:	mov    %esi,%esi
  417ccf:	lea    0x10(%rcx,%rsi,1),%rcx
  417cd4:	cmp    %rax,%rsi
  417cd7:	cmova  %rdx,%rcx
  417cdb:	mov    (%rcx),%eax
  417cdd:	mov    0xc0(%rsp),%r11
  417ce5:	lea    (%r11,%rax,1),%r9d
  417ce9:	mov    %rax,0xe8(%rsp)
  417cf1:	cmp    %r11d,%r9d
  417cf4:	jb     419e5b <wasm[0]::function[131]::builtin::Array.prototype.join+0x2adb>
  417cfa:	mov    0x58(%rsp),%eax
  417cfe:	mov    0x88(%rsp),%r8d
  417d06:	mov    0x50(%rsp),%ecx
  417d0a:	mov    0x80(%rsp),%edx
  417d11:	mov    0xb0(%rsp),%esi
  417d18:	mov    0x68(%rsp),%edi
  417d1c:	mov    0xd8(%rsp),%r10
  417d24:	cmp    %r10d,%r9d
  417d27:	ja     417d42 <wasm[0]::function[131]::builtin::Array.prototype.join+0x9c2>
  417d2d:	mov    %r10,0xd8(%rsp)
  417d35:	mov    %r9,0xf0(%rsp)
  417d3d:	jmp    4182f4 <wasm[0]::function[131]::builtin::Array.prototype.join+0xf74>
  417d42:	lea    (%r10,%r10,1),%eax
  417d46:	cmp    %r10d,%eax
  417d49:	jb     417d57 <wasm[0]::function[131]::builtin::Array.prototype.join+0x9d7>
  417d4f:	mov    %rax,%r10
  417d52:	jmp    417d5a <wasm[0]::function[131]::builtin::Array.prototype.join+0x9da>
  417d57:	mov    %r9,%r10
  417d5a:	cmp    $0x10,%r10d
  417d5e:	jae    417d6c <wasm[0]::function[131]::builtin::Array.prototype.join+0x9ec>
  417d64:	mov    0x110(%rsp),%r10
  417d6c:	cmp    %r9d,%r10d
  417d6f:	mov    %r9,0xf0(%rsp)
  417d77:	jae    417d85 <wasm[0]::function[131]::builtin::Array.prototype.join+0xa05>
  417d7d:	mov    0xf0(%rsp),%r10
  417d85:	mov    %r10d,%r14d
  417d88:	mov    %r14,%rcx
  417d8b:	shl    $1,%rcx
  417d8e:	mov    %rcx,%rsi
  417d91:	shr    $0x20,%rsi
  417d95:	mov    %rcx,%rbx
  417d98:	test   %rsi,%rsi
  417d9b:	jne    419e5d <wasm[0]::function[131]::builtin::Array.prototype.join+0x2add>
  417da1:	lea    (%r10,%r10,1),%ecx
  417da5:	mov    %r10,0xd8(%rsp)
  417dad:	add    $0x14,%ecx
  417db0:	jb     419e5f <wasm[0]::function[131]::builtin::Array.prototype.join+0x2adf>
  417db6:	mov    0x120(%rsp),%rdx
  417dbe:	mov    (%rdx),%eax
  417dc0:	mov    %eax,%edi
  417dc2:	mov    %ecx,%r8d
  417dc5:	lea    0xf(%r8),%rsi
  417dc9:	and    $0xfffffffffffffff0,%rsi
  417dcd:	lea    (%rdi,%rsi,1),%r8
  417dd1:	mov    0x4(%rdx),%r9d
  417dd5:	cmp    %r9,%r8
  417dd8:	ja     419878 <wasm[0]::function[131]::builtin::Array.prototype.join+0x24f8>
  417dde:	lea    0xf(%rcx),%r9d
  417de2:	and    $0xfffffff0,%r9d
  417de6:	lea    (%rax,%r9,1),%r10d
  417dea:	mov    0x120(%rsp),%rcx
  417df2:	mov    %r10d,(%rcx)
  417df5:	mov    0x138(%rsp),%r9
  417dfd:	mov    0x20(%r9),%r11
  417e01:	lea    (%r11,%rdi,1),%rcx
  417e05:	movl   $0xa8000006,(%r11,%rdi,1)
  417e0d:	mov    0xf8(%rsp),%rdx
  417e15:	mov    %edx,0x4(%r11,%rdi,1)
  417e1a:	mov    %esi,0x8(%r11,%rdi,1)
  417e1f:	mov    %eax,0x60(%rsp)
  417e23:	mov    0xd8(%rsp),%r12
  417e2b:	mov    %r12d,0x10(%rcx)
  417e2f:	test   %eax,%eax
  417e31:	je     419e61 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2ae1>
  417e37:	mov    0x138(%rsp),%r9
  417e3f:	mov    0x28(%r9),%rcx
  417e43:	mov    0x20(%r9),%rdx
  417e47:	mov    %eax,%eax
  417e49:	lea    0x10(%rdx,%rax,1),%rsi
  417e4e:	xor    %rdi,%rdi
  417e51:	cmp    %rcx,%rax
  417e54:	cmova  %rdi,%rsi
  417e58:	mov    (%rsi),%esi
  417e5a:	cmp    %rsi,%r14
  417e5d:	ja     419e63 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2ae3>
  417e63:	lea    0x14(%rdx,%rax,1),%rsi
  417e68:	mov    %rbx,%r9
  417e6b:	mov    %rsi,%rax
  417e6e:	add    %r9,%rax
  417e71:	mov    %rsi,%r15
  417e74:	jb     419e65 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2ae5>
  417e7a:	add    %rdx,%rcx
  417e7d:	cmp    %rcx,%rax
  417e80:	ja     419e67 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2ae7>
  417e86:	mov    0x58(%rsp),%r8d
  417e8b:	mov    0x88(%rsp),%edi
  417e92:	mov    0x50(%rsp),%esi
  417e96:	mov    0x80(%rsp),%edx
  417e9d:	mov    0xb0(%rsp),%ecx
  417ea4:	mov    0x68(%rsp),%eax
  417ea8:	cmp    $0x8000000,%r9
  417eaf:	jbe    417f56 <wasm[0]::function[131]::builtin::Array.prototype.join+0xbd6>
  417eb5:	mov    %r8d,0x70(%rsp)
  417eba:	mov    %edi,0x68(%rsp)
  417ebe:	mov    %esi,0xb0(%rsp)
  417ec5:	mov    %edx,0x80(%rsp)
  417ecc:	mov    %ecx,0x50(%rsp)
  417ed0:	mov    %eax,0x88(%rsp)
  417ed7:	mov    0x140(%rsp),%rcx
  417edf:	mov    (%rcx),%rax
  417ee2:	mov    0xe0(%rsp),%rcx
  417eea:	cmp    %rcx,%rax
  417eed:	jae    4198b0 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2530>
  417ef3:	xor    %edx,%edx
  417ef5:	mov    $0x8000000,%ecx
  417efa:	mov    %r15,%rsi
  417efd:	mov    0xb8(%rsp),%rdi
  417f05:	call   3039b13 <wasmtime_builtin_memory_fill>
  417f0a:	mov    0x70(%rsp),%r8d
  417f0f:	mov    0x68(%rsp),%edi
  417f13:	mov    0xb0(%rsp),%esi
  417f1a:	mov    0x80(%rsp),%edx
  417f21:	mov    0x50(%rsp),%ecx
  417f25:	mov    0x88(%rsp),%eax
  417f2c:	mov    %rbx,%r9
  417f2f:	sub    $0x8000000,%r9
  417f36:	mov    %r9,%rbx
  417f39:	mov    %r15,%r9
  417f3c:	add    $0x8000000,%r9
  417f43:	mov    %r9,%r15
  417f46:	mov    %rbx,%r9
  417f49:	cmp    $0x8000000,%r9
  417f50:	ja     417eb5 <wasm[0]::function[131]::builtin::Array.prototype.join+0xb35>
  417f56:	mov    %r8d,0x88(%rsp)
  417f5e:	mov    %edi,0x50(%rsp)
  417f62:	mov    %esi,0x80(%rsp)
  417f69:	mov    %edx,0xb0(%rsp)
  417f70:	mov    %ecx,0x68(%rsp)
  417f74:	mov    %eax,0x70(%rsp)
  417f78:	mov    0x140(%rsp),%rcx
  417f80:	mov    (%rcx),%rax
  417f83:	mov    0xe0(%rsp),%rcx
  417f8b:	cmp    %rcx,%rax
  417f8e:	jae    4198e7 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2567>
  417f94:	xor    %edx,%edx
  417f96:	mov    %rbx,%rcx
  417f99:	mov    %r15,%rsi
  417f9c:	mov    0xb8(%rsp),%rdi
  417fa4:	call   3039b13 <wasmtime_builtin_memory_fill>
  417fa9:	mov    0x60(%rsp),%ecx
  417fad:	test   %ecx,%ecx
  417faf:	je     419e69 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2ae9>
  417fb5:	mov    0x88(%rsp),%eax
  417fbc:	test   %eax,%eax
  417fbe:	je     419e6b <wasm[0]::function[131]::builtin::Array.prototype.join+0x2aeb>
  417fc4:	test   %ecx,%ecx
  417fc6:	je     419e6d <wasm[0]::function[131]::builtin::Array.prototype.join+0x2aed>
  417fcc:	mov    0x138(%rsp),%r9
  417fd4:	mov    0x28(%r9),%rdi
  417fd8:	mov    0x20(%r9),%rsi
  417fdc:	mov    %ecx,%r8d
  417fdf:	lea    (%rsi,%r8,1),%r9
  417fe3:	lea    0x10(%rsi,%r8,1),%rdx
  417fe8:	xor    %rcx,%rcx
  417feb:	cmp    %rdi,%r8
  417fee:	cmova  %rcx,%rdx
  417ff2:	mov    0xc0(%rsp),%r12
  417ffa:	mov    %r12d,%r10d
  417ffd:	mov    (%rdx),%r11d
  418000:	cmp    %r11,%r10
  418003:	ja     419e6f <wasm[0]::function[131]::builtin::Array.prototype.join+0x2aef>
  418009:	test   %eax,%eax
  41800b:	je     419e71 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2af1>
  418011:	mov    %eax,%eax
  418013:	lea    (%rsi,%rax,1),%r11
  418017:	lea    0x10(%rsi,%rax,1),%rdx
  41801c:	cmp    %rdi,%rax
  41801f:	cmova  %rcx,%rdx
  418023:	mov    (%rdx),%ecx
  418025:	cmp    %rcx,%r10
  418028:	ja     419e73 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2af3>
  41802e:	lea    0x14(%rsi,%r8,1),%r12
  418033:	mov    %r10,%r14
  418036:	shl    $1,%r14
  418039:	mov    %r12,%rdx
  41803c:	add    %r14,%rdx
  41803f:	jb     419e75 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2af5>
  418045:	lea    (%rsi,%rdi,1),%rcx
  418049:	cmp    %rcx,%rdx
  41804c:	ja     419e77 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2af7>
  418052:	lea    0x14(%rsi,%rax,1),%r13
  418057:	mov    %r13,%rax
  41805a:	add    %r14,%rax
  41805d:	jb     419e79 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2af9>
  418063:	cmp    %rcx,%rax
  418066:	ja     419e7b <wasm[0]::function[131]::builtin::Array.prototype.join+0x2afb>
  41806c:	cmp    %r12,%r13
  41806f:	ja     41818a <wasm[0]::function[131]::builtin::Array.prototype.join+0xe0a>
  418075:	mov    0x60(%rsp),%eax
  418079:	mov    0x50(%rsp),%ecx
  41807d:	mov    0x80(%rsp),%edx
  418084:	mov    0xb0(%rsp),%esi
  41808b:	mov    0x68(%rsp),%edi
  41808f:	mov    0x70(%rsp),%r8d
  418094:	lea    0x14(%r9,%r10,2),%r12
  418099:	lea    0x14(%r11,%r10,2),%r13
  41809e:	cmp    $0x8000000,%r14
  4180a5:	mov    %r14,%rbx
  4180a8:	ja     4180b9 <wasm[0]::function[131]::builtin::Array.prototype.join+0xd39>
  4180ae:	mov    %rbx,%r9
  4180b1:	mov    %r12,%r10
  4180b4:	jmp    418173 <wasm[0]::function[131]::builtin::Array.prototype.join+0xdf3>
  4180b9:	mov    %eax,0x78(%rsp)
  4180bd:	mov    %ecx,0xa8(%rsp)
  4180c4:	mov    %edx,0xa0(%rsp)
  4180cb:	mov    %esi,0x98(%rsp)
  4180d2:	mov    %edi,0x90(%rsp)
  4180d9:	mov    %r8d,0x88(%rsp)
  4180e1:	mov    0x140(%rsp),%rcx
  4180e9:	mov    (%rcx),%rax
  4180ec:	mov    0xe0(%rsp),%rcx
  4180f4:	cmp    %rcx,%rax
  4180f7:	jae    41991e <wasm[0]::function[131]::builtin::Array.prototype.join+0x259e>
  4180fd:	mov    $0x8000000,%ecx
  418102:	mov    %r12,%rsi
  418105:	sub    $0x8000000,%rsi
  41810c:	mov    %r13,%rdx
  41810f:	mov    %rsi,%r12
  418112:	sub    $0x8000000,%rdx
  418119:	mov    %rdx,%r13
  41811c:	mov    0xb8(%rsp),%rdi
  418124:	call   3039aea <wasmtime_builtin_memory_copy>
  418129:	mov    0x78(%rsp),%eax
  41812d:	mov    0xa8(%rsp),%ecx
  418134:	mov    0xa0(%rsp),%edx
  41813b:	mov    0x98(%rsp),%esi
  418142:	mov    0x90(%rsp),%edi
  418149:	mov    0x88(%rsp),%r8d
  418151:	mov    %rbx,%r9
  418154:	sub    $0x8000000,%r9
  41815b:	cmp    $0x8000000,%r9
  418162:	jbe    418170 <wasm[0]::function[131]::builtin::Array.prototype.join+0xdf0>
  418168:	mov    %r9,%rbx
  41816b:	jmp    4180b9 <wasm[0]::function[131]::builtin::Array.prototype.join+0xd39>
  418170:	mov    %r12,%r10
  418173:	sub    %r9,%r10
  418176:	mov    %r10,%r12
  418179:	mov    %r13,%r10
  41817c:	sub    %r9,%r10
  41817f:	mov    %r10,%r13
  418182:	mov    %r9,%rbx
  418185:	jmp    418265 <wasm[0]::function[131]::builtin::Array.prototype.join+0xee5>
  41818a:	mov    %r14,%r9
  41818d:	mov    0x60(%rsp),%eax
  418191:	mov    0x50(%rsp),%ecx
  418195:	mov    0x80(%rsp),%edx
  41819c:	mov    0xb0(%rsp),%esi
  4181a3:	mov    0x68(%rsp),%edi
  4181a7:	mov    0x70(%rsp),%r8d
  4181ac:	cmp    $0x8000000,%r9
  4181b3:	mov    %r9,%rbx
  4181b6:	jbe    418265 <wasm[0]::function[131]::builtin::Array.prototype.join+0xee5>
  4181bc:	mov    %eax,0x70(%rsp)
  4181c0:	mov    %ecx,0x68(%rsp)
  4181c4:	mov    %edx,0xb0(%rsp)
  4181cb:	mov    %esi,0x80(%rsp)
  4181d2:	mov    %edi,0x50(%rsp)
  4181d6:	mov    %r8d,0x60(%rsp)
  4181db:	mov    0x140(%rsp),%rcx
  4181e3:	mov    (%rcx),%rax
  4181e6:	mov    0xe0(%rsp),%rcx
  4181ee:	cmp    %rcx,%rax
  4181f1:	jae    419955 <wasm[0]::function[131]::builtin::Array.prototype.join+0x25d5>
  4181f7:	mov    $0x8000000,%ecx
  4181fc:	mov    %r13,%rdx
  4181ff:	mov    %r12,%rsi
  418202:	mov    0xb8(%rsp),%rdi
  41820a:	call   3039aea <wasmtime_builtin_memory_copy>
  41820f:	mov    0x70(%rsp),%eax
  418213:	mov    0x68(%rsp),%ecx
  418217:	mov    0xb0(%rsp),%edx
  41821e:	mov    0x80(%rsp),%esi
  418225:	mov    0x50(%rsp),%edi
  418229:	mov    0x60(%rsp),%r8d
  41822e:	mov    %rbx,%r9
  418231:	sub    $0x8000000,%r9
  418238:	mov    %r9,%rbx
  41823b:	mov    %r12,%r9
  41823e:	add    $0x8000000,%r9
  418245:	mov    %r9,%r12
  418248:	mov    %r13,%r9
  41824b:	add    $0x8000000,%r9
  418252:	mov    %r9,%r13
  418255:	mov    %rbx,%r9
  418258:	cmp    $0x8000000,%r9
  41825f:	ja     4181bc <wasm[0]::function[131]::builtin::Array.prototype.join+0xe3c>
  418265:	mov    %eax,0x60(%rsp)
  418269:	mov    %ecx,0x50(%rsp)
  41826d:	mov    %edx,0x80(%rsp)
  418274:	mov    %esi,0xb0(%rsp)
  41827b:	mov    %edi,0x68(%rsp)
  41827f:	mov    %r8d,0x70(%rsp)
  418284:	mov    0x140(%rsp),%rcx
  41828c:	mov    (%rcx),%r8
  41828f:	mov    0xe0(%rsp),%rax
  418297:	cmp    %rax,%r8
  41829a:	jae    41998c <wasm[0]::function[131]::builtin::Array.prototype.join+0x260c>
  4182a0:	mov    %rbx,%rcx
  4182a3:	mov    %r13,%rdx
  4182a6:	mov    %r12,%rsi
  4182a9:	jmp    4182b7 <wasm[0]::function[131]::builtin::Array.prototype.join+0xf37>
  4182ae:	mov    %rbx,%rcx
  4182b1:	mov    %r13,%rdx
  4182b4:	mov    %r12,%rsi
  4182b7:	mov    %rbx,%rcx
  4182ba:	mov    %r13,%rdx
  4182bd:	mov    %r12,%rsi
  4182c0:	mov    0xb8(%rsp),%rdi
  4182c8:	call   3039aea <wasmtime_builtin_memory_copy>
  4182cd:	mov    0x60(%rsp),%eax
  4182d1:	test   %eax,%eax
  4182d3:	je     419e7d <wasm[0]::function[131]::builtin::Array.prototype.join+0x2afd>
  4182d9:	mov    0x50(%rsp),%r8d
  4182de:	mov    0x80(%rsp),%ecx
  4182e5:	mov    0xb0(%rsp),%edx
  4182ec:	mov    0x68(%rsp),%esi
  4182f0:	mov    0x70(%rsp),%edi
  4182f4:	test   %eax,%eax
  4182f6:	je     419e7f <wasm[0]::function[131]::builtin::Array.prototype.join+0x2aff>
  4182fc:	test   %r8d,%r8d
  4182ff:	je     419e81 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b01>
  418305:	test   %eax,%eax
  418307:	je     419e83 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b03>
  41830d:	mov    0x138(%rsp),%r9
  418315:	mov    0x28(%r9),%r11
  418319:	mov    0x20(%r9),%r9
  41831d:	mov    %eax,%r10d
  418320:	lea    (%r9,%r10,1),%r14
  418324:	lea    0x10(%r9,%r10,1),%r12
  418329:	xor    %r15,%r15
  41832c:	cmp    %r11,%r10
  41832f:	cmova  %r15,%r12
  418333:	mov    0xc0(%rsp),%r10
  41833b:	mov    %r10d,%r13d
  41833e:	mov    0xe8(%rsp),%r10
  418346:	mov    %r10d,%r10d
  418349:	lea    0x0(%r13,%r10,1),%rbx
  41834e:	mov    (%r12),%r12d
  418352:	cmp    %r12,%rbx
  418355:	ja     419e85 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b05>
  41835b:	test   %r8d,%r8d
  41835e:	je     419e87 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b07>
  418364:	mov    %r8d,%r12d
  418367:	lea    (%r9,%r12,1),%r8
  41836b:	lea    0x10(%r9,%r12,1),%rbx
  418370:	cmp    %r11,%r12
  418373:	cmova  %r15,%rbx
  418377:	mov    (%rbx),%ebx
  418379:	cmp    %rbx,%r10
  41837c:	ja     419e89 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b09>
  418382:	lea    0x14(%r14,%r13,2),%r14
  418387:	mov    %r10,%r13
  41838a:	shl    $1,%r13
  41838d:	mov    %r14,%rbx
  418390:	add    %r13,%rbx
  418393:	jb     419e8b <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b0b>
  418399:	add    %r9,%r11
  41839c:	cmp    %r11,%rbx
  41839f:	ja     419e8d <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b0d>
  4183a5:	lea    0x14(%r9,%r12,1),%r9
  4183aa:	mov    %r9,%rbx
  4183ad:	add    %r13,%rbx
  4183b0:	jb     419e8f <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b0f>
  4183b6:	cmp    %r11,%rbx
  4183b9:	ja     419e91 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b11>
  4183bf:	cmp    %r14,%r9
  4183c2:	ja     4184a7 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1127>
  4183c8:	lea    (%r14,%r10,2),%r14
  4183cc:	mov    %r14,%rbx
  4183cf:	lea    0x14(%r8,%r10,2),%r9
  4183d4:	mov    %r9,%r14
  4183d7:	cmp    $0x8000000,%r13
  4183de:	mov    %r13,%r12
  4183e1:	ja     4183f2 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1072>
  4183e7:	mov    %r12,%r8
  4183ea:	mov    %rbx,%r9
  4183ed:	jmp    418490 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1110>
  4183f2:	mov    %ecx,0x68(%rsp)
  4183f6:	mov    %edx,0xb0(%rsp)
  4183fd:	mov    %esi,0x80(%rsp)
  418404:	mov    %eax,0x50(%rsp)
  418408:	mov    %edi,0x60(%rsp)
  41840c:	mov    0x140(%rsp),%rcx
  418414:	mov    (%rcx),%rax
  418417:	mov    0xe0(%rsp),%rcx
  41841f:	cmp    %rcx,%rax
  418422:	jae    4199cc <wasm[0]::function[131]::builtin::Array.prototype.join+0x264c>
  418428:	mov    $0x8000000,%ecx
  41842d:	mov    %rbx,%rsi
  418430:	sub    $0x8000000,%rsi
  418437:	mov    %r14,%rdx
  41843a:	mov    %rsi,%rbx
  41843d:	sub    $0x8000000,%rdx
  418444:	mov    %rdx,%r14
  418447:	mov    0xb8(%rsp),%rdi
  41844f:	call   3039aea <wasmtime_builtin_memory_copy>
  418454:	mov    0x68(%rsp),%ecx
  418458:	mov    0xb0(%rsp),%edx
  41845f:	mov    0x80(%rsp),%esi
  418466:	mov    0x50(%rsp),%eax
  41846a:	mov    0x60(%rsp),%edi
  41846e:	mov    %r12,%r8
  418471:	sub    $0x8000000,%r8
  418478:	cmp    $0x8000000,%r8
  41847f:	jbe    41848d <wasm[0]::function[131]::builtin::Array.prototype.join+0x110d>
  418485:	mov    %r8,%r12
  418488:	jmp    4183f2 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1072>
  41848d:	mov    %rbx,%r9
  418490:	sub    %r8,%r9
  418493:	mov    %r9,%rbx
  418496:	mov    %r14,%r9
  418499:	sub    %r8,%r9
  41849c:	mov    %r9,%r14
  41849f:	mov    %r8,%r12
  4184a2:	jmp    41855f <wasm[0]::function[131]::builtin::Array.prototype.join+0x11df>
  4184a7:	mov    %r13,%r8
  4184aa:	mov    %r14,%rbx
  4184ad:	mov    %r9,%r14
  4184b0:	cmp    $0x8000000,%r8
  4184b7:	mov    %r8,%r12
  4184ba:	jbe    41855f <wasm[0]::function[131]::builtin::Array.prototype.join+0x11df>
  4184c0:	mov    %ecx,0x60(%rsp)
  4184c4:	mov    %edx,0x50(%rsp)
  4184c8:	mov    %esi,0x80(%rsp)
  4184cf:	mov    %eax,0xb0(%rsp)
  4184d6:	mov    %edi,0x68(%rsp)
  4184da:	mov    0x140(%rsp),%rcx
  4184e2:	mov    (%rcx),%r9
  4184e5:	mov    0xe0(%rsp),%rax
  4184ed:	cmp    %rax,%r9
  4184f0:	jae    419a03 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2683>
  4184f6:	mov    $0x8000000,%ecx
  4184fb:	mov    %r14,%rdx
  4184fe:	mov    %rbx,%rsi
  418501:	mov    0xb8(%rsp),%rdi
  418509:	call   3039aea <wasmtime_builtin_memory_copy>
  41850e:	mov    0x60(%rsp),%ecx
  418512:	mov    0x50(%rsp),%edx
  418516:	mov    0x80(%rsp),%esi
  41851d:	mov    0xb0(%rsp),%eax
  418524:	mov    0x68(%rsp),%edi
  418528:	mov    %r12,%r8
  41852b:	sub    $0x8000000,%r8
  418532:	mov    %r8,%r12
  418535:	mov    %rbx,%r8
  418538:	add    $0x8000000,%r8
  41853f:	mov    %r8,%rbx
  418542:	mov    %r14,%r8
  418545:	add    $0x8000000,%r8
  41854c:	mov    %r8,%r14
  41854f:	mov    %r12,%r8
  418552:	cmp    $0x8000000,%r8
  418559:	ja     4184c0 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1140>
  41855f:	mov    %ecx,0x68(%rsp)
  418563:	mov    %edx,0xb0(%rsp)
  41856a:	mov    %esi,0x80(%rsp)
  418571:	mov    %eax,0x50(%rsp)
  418575:	mov    %edi,0x60(%rsp)
  418579:	mov    0x140(%rsp),%rcx
  418581:	mov    (%rcx),%rax
  418584:	mov    0xe0(%rsp),%rcx
  41858c:	cmp    %rcx,%rax
  41858f:	jae    419a3a <wasm[0]::function[131]::builtin::Array.prototype.join+0x26ba>
  418595:	mov    %r12,%rcx
  418598:	mov    %r14,%rdx
  41859b:	mov    %rbx,%rsi
  41859e:	jmp    4185ac <wasm[0]::function[131]::builtin::Array.prototype.join+0x122c>
  4185a3:	mov    %r12,%rcx
  4185a6:	mov    %r14,%rdx
  4185a9:	mov    %rbx,%rsi
  4185ac:	mov    %r12,%rcx
  4185af:	mov    %r14,%rdx
  4185b2:	mov    %rbx,%rsi
  4185b5:	mov    0xb8(%rsp),%rdi
  4185bd:	call   3039aea <wasmtime_builtin_memory_copy>
  4185c2:	mov    0x68(%rsp),%r8d
  4185c7:	mov    0xb0(%rsp),%eax
  4185ce:	mov    0x80(%rsp),%ecx
  4185d5:	mov    0x50(%rsp),%esi
  4185d9:	mov    0x60(%rsp),%edi
  4185dd:	mov    0xf0(%rsp),%rdx
  4185e5:	mov    %rdx,0xc0(%rsp)
  4185ed:	mov    %r8d,0x60(%rsp)
  4185f2:	mov    %eax,0x50(%rsp)
  4185f6:	mov    %ecx,0x80(%rsp)
  4185fd:	mov    %esi,0xb0(%rsp)
  418604:	mov    %edi,0x68(%rsp)
  418608:	test   %ecx,%ecx
  41860a:	je     419e93 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b13>
  418610:	mov    %eax,(%rsp)
  418613:	mov    %ecx,0x8(%rsp)
  418617:	mov    0x130(%rsp),%rcx
  41861f:	mov    0x128(%rsp),%rdx
  418627:	mov    0xb8(%rsp),%rsi
  41862f:	mov    0xb8(%rsp),%rdi
  418637:	mov    0xc8(%rsp),%r9
  41863f:	call   2e09c00 <wasm[0]::function[1089]::helper::indexed_element_read>
  418644:	sub    $0x10,%rsp
  418648:	mov    %rdx,%r11
  41864b:	cmp    $0x1,%esi
  41864e:	je     4190fe <wasm[0]::function[131]::builtin::Array.prototype.join+0x1d7e>
  418654:	mov    0x68(%rsp),%r8d
  418659:	mov    0xb0(%rsp),%edi
  418660:	mov    0x60(%rsp),%edx
  418664:	mov    0x50(%rsp),%r9d
  418669:	mov    0x80(%rsp),%esi
  418670:	test   %eax,%eax
  418672:	setne  %r10b
  418676:	cmp    $0x1,%eax
  418679:	mov    %rax,%r14
  41867c:	setne  %al
  41867f:	test   %r10b,%al
  418682:	jne    418695 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1315>
  418688:	mov    0xc8(%rsp),%rcx
  418690:	jmp    4190b4 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1d34>
  418695:	test   %esi,%esi
  418697:	je     419e95 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b15>
  41869d:	mov    %esi,(%rsp)
  4186a0:	mov    %r14,%rdx
  4186a3:	mov    %r11,%r8
  4186a6:	mov    0xb8(%rsp),%rsi
  4186ae:	mov    0xb8(%rsp),%rdi
  4186b6:	call   2b0b4c0 <wasm[0]::function[1061]::helper::value_to_string>
  4186bb:	sub    $0x10,%rsp
  4186bf:	cmp    $0x1,%esi
  4186c2:	je     4190c8 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1d48>
  4186c8:	xor    %eax,%eax
  4186ca:	test   %edx,%edx
  4186cc:	je     418717 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1397>
  4186d2:	xor    %eax,%eax
  4186d4:	test   $0x1,%edx
  4186da:	jne    418717 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1397>
  4186e0:	mov    0x138(%rsp),%r9
  4186e8:	mov    0x28(%r9),%rax
  4186ec:	mov    0x20(%r9),%rcx
  4186f0:	mov    %edx,%esi
  4186f2:	lea    0x4(%rcx,%rsi,1),%rcx
  4186f7:	xor    %rdi,%rdi
  4186fa:	cmp    %rax,%rsi
  4186fd:	cmova  %rdi,%rcx
  418701:	mov    (%rcx),%eax
  418703:	mov    0x100(%rsp),%rcx
  41870b:	cmp    0x234(%rcx),%eax
  418711:	sete   %al
  418714:	movzbl %al,%eax
  418717:	test   %eax,%eax
  418719:	je     419e97 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b17>
  41871f:	test   %edx,%edx
  418721:	je     419e99 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b19>
  418727:	test   %edx,%edx
  418729:	je     419e9b <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b1b>
  41872f:	mov    0x138(%rsp),%r9
  418737:	mov    0x28(%r9),%rax
  41873b:	mov    0x20(%r9),%rcx
  41873f:	mov    %edx,%edi
  418741:	lea    (%rcx,%rdi,1),%rsi
  418745:	xor    %rdx,%rdx
  418748:	cmp    %rax,%rdi
  41874b:	cmova  %rdx,%rsi
  41874f:	mov    0x10(%rsi),%esi
  418752:	mov    %esi,0x70(%rsp)
  418756:	test   %esi,%esi
  418758:	je     419e9d <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b1d>
  41875e:	test   %esi,%esi
  418760:	je     419e9f <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b1f>
  418766:	mov    %esi,%edi
  418768:	lea    0x10(%rcx,%rdi,1),%rsi
  41876d:	cmp    %rax,%rdi
  418770:	cmova  %rdx,%rsi
  418774:	mov    (%rsi),%edi
  418776:	mov    0xc0(%rsp),%r12
  41877e:	lea    (%r12,%rdi,1),%r9d
  418782:	mov    %rdi,0xf0(%rsp)
  41878a:	cmp    %r12d,%r9d
  41878d:	jb     419ea1 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b21>
  418793:	mov    0xb0(%rsp),%eax
  41879a:	mov    0x70(%rsp),%r8d
  41879f:	mov    0x68(%rsp),%edx
  4187a3:	mov    0x60(%rsp),%ecx
  4187a7:	mov    0x50(%rsp),%esi
  4187ab:	mov    0x80(%rsp),%edi
  4187b2:	mov    0xd8(%rsp),%r12
  4187ba:	cmp    %r12d,%r9d
  4187bd:	ja     4187d0 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1450>
  4187c3:	mov    %r9,0xe8(%rsp)
  4187cb:	jmp    418dd6 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1a56>
  4187d0:	mov    0xd8(%rsp),%rax
  4187d8:	mov    0xd8(%rsp),%r12
  4187e0:	add    %r12d,%eax
  4187e3:	cmp    %r12d,%eax
  4187e6:	jb     4187fc <wasm[0]::function[131]::builtin::Array.prototype.join+0x147c>
  4187ec:	mov    %rax,%r12
  4187ef:	mov    %rax,0xd8(%rsp)
  4187f7:	jmp    418807 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1487>
  4187fc:	mov    %r9,%r12
  4187ff:	mov    %r9,0xd8(%rsp)
  418807:	cmp    $0x10,%r12d
  41880b:	jb     41881e <wasm[0]::function[131]::builtin::Array.prototype.join+0x149e>
  418811:	mov    0xd8(%rsp),%r12
  418819:	jmp    418836 <wasm[0]::function[131]::builtin::Array.prototype.join+0x14b6>
  41881e:	mov    0x110(%rsp),%r12
  418826:	mov    0x110(%rsp),%rax
  41882e:	mov    %rax,0xd8(%rsp)
  418836:	cmp    %r9d,%r12d
  418839:	mov    %r9,0xe8(%rsp)
  418841:	jb     418854 <wasm[0]::function[131]::builtin::Array.prototype.join+0x14d4>
  418847:	mov    0xd8(%rsp),%r12
  41884f:	jmp    41886c <wasm[0]::function[131]::builtin::Array.prototype.join+0x14ec>
  418854:	mov    0xe8(%rsp),%r12
  41885c:	mov    0xe8(%rsp),%rax
  418864:	mov    %rax,0xd8(%rsp)
  41886c:	mov    %r12d,%r14d
  41886f:	mov    %r14,%rcx
  418872:	shl    $1,%rcx
  418875:	mov    %rcx,%rax
  418878:	shr    $0x20,%rax
  41887c:	mov    %rcx,%rbx
  41887f:	test   %rax,%rax
  418882:	jne    419ea3 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b23>
  418888:	mov    0xd8(%rsp),%rax
  418890:	mov    0xd8(%rsp),%r12
  418898:	lea    (%r12,%rax,1),%ecx
  41889c:	add    $0x14,%ecx
  41889f:	jb     419ea5 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b25>
  4188a5:	mov    0x120(%rsp),%rax
  4188ad:	mov    (%rax),%eax
  4188af:	mov    %eax,%esi
  4188b1:	mov    %ecx,%edx
  4188b3:	add    $0xf,%rdx
  4188ba:	and    $0xfffffffffffffff0,%rdx
  4188be:	lea    (%rsi,%rdx,1),%rdi
  4188c2:	mov    0x120(%rsp),%r8
  4188ca:	mov    0x4(%r8),%r8d
  4188ce:	cmp    %r8,%rdi
  4188d1:	ja     419a7a <wasm[0]::function[131]::builtin::Array.prototype.join+0x26fa>
  4188d7:	add    $0xf,%ecx
  4188dd:	and    $0xfffffff0,%ecx
  4188e0:	add    %eax,%ecx
  4188e2:	mov    0x120(%rsp),%rdi
  4188ea:	mov    %ecx,(%rdi)
  4188ec:	mov    0x138(%rsp),%r9
  4188f4:	mov    0x20(%r9),%rdi
  4188f8:	lea    (%rdi,%rsi,1),%rcx
  4188fc:	movl   $0xa8000006,(%rdi,%rsi,1)
  418903:	mov    0xf8(%rsp),%r8
  41890b:	mov    %r8d,0x4(%rdi,%rsi,1)
  418910:	mov    %edx,0x8(%rdi,%rsi,1)
  418914:	mov    %eax,0x78(%rsp)
  418918:	mov    0xd8(%rsp),%r12
  418920:	mov    %r12d,0x10(%rcx)
  418924:	test   %eax,%eax
  418926:	je     419ea7 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b27>
  41892c:	mov    0x138(%rsp),%r9
  418934:	mov    0x28(%r9),%rcx
  418938:	mov    0x20(%r9),%rdx
  41893c:	mov    %eax,%eax
  41893e:	lea    0x10(%rdx,%rax,1),%rsi
  418943:	xor    %rdi,%rdi
  418946:	cmp    %rcx,%rax
  418949:	cmova  %rdi,%rsi
  41894d:	mov    (%rsi),%esi
  41894f:	cmp    %rsi,%r14
  418952:	ja     419ea9 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b29>
  418958:	lea    0x14(%rdx,%rax,1),%rsi
  41895d:	mov    %rbx,%r9
  418960:	mov    %rsi,%rax
  418963:	add    %r9,%rax
  418966:	mov    %rsi,%r13
  418969:	jb     419eab <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b2b>
  41896f:	add    %rdx,%rcx
  418972:	cmp    %rcx,%rax
  418975:	ja     419ead <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b2d>
  41897b:	mov    0xb0(%rsp),%r8d
  418983:	mov    0x70(%rsp),%edi
  418987:	mov    0x68(%rsp),%esi
  41898b:	mov    0x60(%rsp),%edx
  41898f:	mov    0x50(%rsp),%ecx
  418993:	mov    0x80(%rsp),%eax
  41899a:	cmp    $0x8000000,%r9
  4189a1:	jbe    418a42 <wasm[0]::function[131]::builtin::Array.prototype.join+0x16c2>
  4189a7:	mov    %r8d,0x80(%rsp)
  4189af:	mov    %edi,0x50(%rsp)
  4189b3:	mov    %esi,0x60(%rsp)
  4189b7:	mov    %edx,0x68(%rsp)
  4189bb:	mov    %ecx,0x70(%rsp)
  4189bf:	mov    %eax,0xb0(%rsp)
  4189c6:	mov    0x140(%rsp),%rcx
  4189ce:	mov    (%rcx),%rax
  4189d1:	mov    0xe0(%rsp),%rcx
  4189d9:	cmp    %rcx,%rax
  4189dc:	jae    419ab2 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2732>
  4189e2:	xor    %edx,%edx
  4189e4:	mov    $0x8000000,%ecx
  4189e9:	mov    %r13,%rsi
  4189ec:	mov    0xb8(%rsp),%rdi
  4189f4:	call   3039b13 <wasmtime_builtin_memory_fill>
  4189f9:	mov    0x80(%rsp),%r8d
  418a01:	mov    0x50(%rsp),%edi
  418a05:	mov    0x60(%rsp),%esi
  418a09:	mov    0x68(%rsp),%edx
  418a0d:	mov    0x70(%rsp),%ecx
  418a11:	mov    0xb0(%rsp),%eax
  418a18:	mov    %rbx,%r9
  418a1b:	sub    $0x8000000,%r9
  418a22:	mov    %r9,%rbx
  418a25:	mov    %r13,%r9
  418a28:	add    $0x8000000,%r9
  418a2f:	mov    %r9,%r13
  418a32:	mov    %rbx,%r9
  418a35:	cmp    $0x8000000,%r9
  418a3c:	ja     4189a7 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1627>
  418a42:	mov    %r8d,0xb0(%rsp)
  418a4a:	mov    %edi,0x70(%rsp)
  418a4e:	mov    %esi,0x68(%rsp)
  418a52:	mov    %edx,0x60(%rsp)
  418a56:	mov    %ecx,0x50(%rsp)
  418a5a:	mov    %eax,0x80(%rsp)
  418a61:	mov    0x140(%rsp),%rcx
  418a69:	mov    (%rcx),%r11
  418a6c:	mov    0xe0(%rsp),%rax
  418a74:	cmp    %rax,%r11
  418a77:	jae    419ae9 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2769>
  418a7d:	xor    %edx,%edx
  418a7f:	mov    %rbx,%rcx
  418a82:	mov    %r13,%rsi
  418a85:	mov    0xb8(%rsp),%rdi
  418a8d:	call   3039b13 <wasmtime_builtin_memory_fill>
  418a92:	mov    0x78(%rsp),%edx
  418a96:	test   %edx,%edx
  418a98:	je     419eaf <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b2f>
  418a9e:	mov    0xb0(%rsp),%esi
  418aa5:	test   %esi,%esi
  418aa7:	je     419eb1 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b31>
  418aad:	test   %edx,%edx
  418aaf:	je     419eb3 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b33>
  418ab5:	mov    0x138(%rsp),%r9
  418abd:	mov    0x28(%r9),%rcx
  418ac1:	mov    0x20(%r9),%rax
  418ac5:	mov    %edx,%edx
  418ac7:	lea    (%rax,%rdx,1),%r9
  418acb:	lea    0x10(%rax,%rdx,1),%r8
  418ad0:	xor    %rdi,%rdi
  418ad3:	cmp    %rcx,%rdx
  418ad6:	cmova  %rdi,%r8
  418ada:	mov    0xc0(%rsp),%r12
  418ae2:	mov    %r12d,%r10d
  418ae5:	mov    (%r8),%r8d
  418ae8:	cmp    %r8,%r10
  418aeb:	ja     419eb5 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b35>
  418af1:	test   %esi,%esi
  418af3:	je     419eb7 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b37>
  418af9:	mov    %esi,%esi
  418afb:	lea    (%rax,%rsi,1),%r11
  418aff:	lea    0x10(%rax,%rsi,1),%r8
  418b04:	cmp    %rcx,%rsi
  418b07:	cmova  %rdi,%r8
  418b0b:	mov    (%r8),%edi
  418b0e:	cmp    %rdi,%r10
  418b11:	ja     419eb9 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b39>
  418b17:	lea    0x14(%rax,%rdx,1),%r12
  418b1c:	mov    %r10,%r14
  418b1f:	shl    $1,%r14
  418b22:	mov    %r12,%rdx
  418b25:	add    %r14,%rdx
  418b28:	jb     419ebb <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b3b>
  418b2e:	add    %rax,%rcx
  418b31:	cmp    %rcx,%rdx
  418b34:	ja     419ebd <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b3d>
  418b3a:	lea    0x14(%rax,%rsi,1),%r13
  418b3f:	mov    %r13,%rax
  418b42:	add    %r14,%rax
  418b45:	jb     419ebf <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b3f>
  418b4b:	cmp    %rcx,%rax
  418b4e:	ja     419ec1 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b41>
  418b54:	cmp    %r12,%r13
  418b57:	ja     418c78 <wasm[0]::function[131]::builtin::Array.prototype.join+0x18f8>
  418b5d:	mov    0x78(%rsp),%eax
  418b61:	mov    0x70(%rsp),%ecx
  418b65:	mov    0x68(%rsp),%edx
  418b69:	mov    0x60(%rsp),%esi
  418b6d:	mov    0x50(%rsp),%edi
  418b71:	mov    0x80(%rsp),%r8d
  418b79:	lea    0x14(%r9,%r10,2),%r12
  418b7e:	mov    %r12,%rbx
  418b81:	lea    0x14(%r11,%r10,2),%r13
  418b86:	mov    %r13,%r12
  418b89:	cmp    $0x8000000,%r14
  418b90:	ja     418ba1 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1821>
  418b96:	mov    %r14,%r9
  418b99:	mov    %rbx,%r10
  418b9c:	jmp    418c61 <wasm[0]::function[131]::builtin::Array.prototype.join+0x18e1>
  418ba1:	mov    %eax,0x88(%rsp)
  418ba8:	mov    %ecx,0x90(%rsp)
  418baf:	mov    %edx,0x98(%rsp)
  418bb6:	mov    %esi,0xa0(%rsp)
  418bbd:	mov    %edi,0xa8(%rsp)
  418bc4:	mov    %r8d,0xb0(%rsp)
  418bcc:	mov    0x140(%rsp),%rcx
  418bd4:	mov    (%rcx),%rax
  418bd7:	mov    0xe0(%rsp),%rcx
  418bdf:	cmp    %rcx,%rax
  418be2:	jae    419b20 <wasm[0]::function[131]::builtin::Array.prototype.join+0x27a0>
  418be8:	mov    $0x8000000,%ecx
  418bed:	mov    %rbx,%rsi
  418bf0:	sub    $0x8000000,%rsi
  418bf7:	mov    %r12,%rdx
  418bfa:	mov    %rsi,%rbx
  418bfd:	sub    $0x8000000,%rdx
  418c04:	mov    %rdx,%r12
  418c07:	mov    0xb8(%rsp),%rdi
  418c0f:	call   3039aea <wasmtime_builtin_memory_copy>
  418c14:	mov    0x88(%rsp),%eax
  418c1b:	mov    0x90(%rsp),%ecx
  418c22:	mov    0x98(%rsp),%edx
  418c29:	mov    0xa0(%rsp),%esi
  418c30:	mov    0xa8(%rsp),%edi
  418c37:	mov    0xb0(%rsp),%r8d
  418c3f:	mov    %r14,%r9
  418c42:	sub    $0x8000000,%r9
  418c49:	cmp    $0x8000000,%r9
  418c50:	jbe    418c5e <wasm[0]::function[131]::builtin::Array.prototype.join+0x18de>
  418c56:	mov    %r9,%r14
  418c59:	jmp    418ba1 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1821>
  418c5e:	mov    %rbx,%r10
  418c61:	sub    %r9,%r10
  418c64:	mov    %r10,%rbx
  418c67:	mov    %r12,%r10
  418c6a:	sub    %r9,%r10
  418c6d:	mov    %r10,%r12
  418c70:	mov    %r9,%r14
  418c73:	jmp    418d4d <wasm[0]::function[131]::builtin::Array.prototype.join+0x19cd>
  418c78:	mov    %r14,%r9
  418c7b:	mov    %r12,%rbx
  418c7e:	mov    %r13,%r12
  418c81:	mov    0x78(%rsp),%eax
  418c85:	mov    0x70(%rsp),%ecx
  418c89:	mov    0x68(%rsp),%edx
  418c8d:	mov    0x60(%rsp),%esi
  418c91:	mov    0x50(%rsp),%edi
  418c95:	mov    0x80(%rsp),%r8d
  418c9d:	cmp    $0x8000000,%r9
  418ca4:	jbe    418d4d <wasm[0]::function[131]::builtin::Array.prototype.join+0x19cd>
  418caa:	mov    %eax,0x80(%rsp)
  418cb1:	mov    %ecx,0x50(%rsp)
  418cb5:	mov    %edx,0x60(%rsp)
  418cb9:	mov    %esi,0x68(%rsp)
  418cbd:	mov    %edi,0x70(%rsp)
  418cc1:	mov    %r8d,0x78(%rsp)
  418cc6:	mov    0x140(%rsp),%rcx
  418cce:	mov    (%rcx),%r11
  418cd1:	mov    0xe0(%rsp),%rax
  418cd9:	cmp    %rax,%r11
  418cdc:	jae    419b57 <wasm[0]::function[131]::builtin::Array.prototype.join+0x27d7>
  418ce2:	mov    $0x8000000,%ecx
  418ce7:	mov    %r12,%rdx
  418cea:	mov    %rbx,%rsi
  418ced:	mov    0xb8(%rsp),%rdi
  418cf5:	call   3039aea <wasmtime_builtin_memory_copy>
  418cfa:	mov    0x80(%rsp),%eax
  418d01:	mov    0x50(%rsp),%ecx
  418d05:	mov    0x60(%rsp),%edx
  418d09:	mov    0x68(%rsp),%esi
  418d0d:	mov    0x70(%rsp),%edi
  418d11:	mov    0x78(%rsp),%r8d
  418d16:	mov    %r14,%r9
  418d19:	sub    $0x8000000,%r9
  418d20:	mov    %r9,%r14
  418d23:	mov    %rbx,%r9
  418d26:	add    $0x8000000,%r9
  418d2d:	mov    %r9,%rbx
  418d30:	mov    %r12,%r9
  418d33:	add    $0x8000000,%r9
  418d3a:	mov    %r9,%r12
  418d3d:	mov    %r14,%r9
  418d40:	cmp    $0x8000000,%r9
  418d47:	ja     418caa <wasm[0]::function[131]::builtin::Array.prototype.join+0x192a>
  418d4d:	mov    %eax,0x78(%rsp)
  418d51:	mov    %ecx,0x70(%rsp)
  418d55:	mov    %edx,0x68(%rsp)
  418d59:	mov    %esi,0x60(%rsp)
  418d5d:	mov    %edi,0x50(%rsp)
  418d61:	mov    %r8d,0x80(%rsp)
  418d69:	mov    0x140(%rsp),%rcx
  418d71:	mov    (%rcx),%rax
  418d74:	mov    0xe0(%rsp),%rcx
  418d7c:	cmp    %rcx,%rax
  418d7f:	jae    419b8e <wasm[0]::function[131]::builtin::Array.prototype.join+0x280e>
  418d85:	mov    %r14,%rcx
  418d88:	mov    %r12,%rdx
  418d8b:	mov    %rbx,%rsi
  418d8e:	jmp    418d9c <wasm[0]::function[131]::builtin::Array.prototype.join+0x1a1c>
  418d93:	mov    %r14,%rcx
  418d96:	mov    %r12,%rdx
  418d99:	mov    %rbx,%rsi
  418d9c:	mov    %r14,%rcx
  418d9f:	mov    %r12,%rdx
  418da2:	mov    %rbx,%rsi
  418da5:	mov    0xb8(%rsp),%rdi
  418dad:	call   3039aea <wasmtime_builtin_memory_copy>
  418db2:	mov    0x78(%rsp),%eax
  418db6:	test   %eax,%eax
  418db8:	je     419ec3 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b43>
  418dbe:	mov    0x70(%rsp),%r8d
  418dc3:	mov    0x68(%rsp),%edx
  418dc7:	mov    0x60(%rsp),%ecx
  418dcb:	mov    0x50(%rsp),%esi
  418dcf:	mov    0x80(%rsp),%edi
  418dd6:	test   %eax,%eax
  418dd8:	je     419ec5 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b45>
  418dde:	test   %r8d,%r8d
  418de1:	je     419ec7 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b47>
  418de7:	test   %eax,%eax
  418de9:	je     419ec9 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b49>
  418def:	mov    0x138(%rsp),%r9
  418df7:	mov    0x28(%r9),%r11
  418dfb:	mov    0x20(%r9),%r9
  418dff:	mov    %eax,%r10d
  418e02:	lea    (%r9,%r10,1),%r14
  418e06:	lea    0x10(%r9,%r10,1),%r12
  418e0b:	xor    %r15,%r15
  418e0e:	cmp    %r11,%r10
  418e11:	cmova  %r15,%r12
  418e15:	mov    0xc0(%rsp),%r10
  418e1d:	mov    %r10d,%r13d
  418e20:	mov    0xf0(%rsp),%r10
  418e28:	mov    %r10d,%r10d
  418e2b:	lea    0x0(%r13,%r10,1),%rbx
  418e30:	mov    (%r12),%r12d
  418e34:	cmp    %r12,%rbx
  418e37:	ja     419ecb <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b4b>
  418e3d:	test   %r8d,%r8d
  418e40:	je     419ecd <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b4d>
  418e46:	mov    %r8d,%r12d
  418e49:	lea    (%r9,%r12,1),%r8
  418e4d:	lea    0x10(%r9,%r12,1),%rbx
  418e52:	cmp    %r11,%r12
  418e55:	cmova  %r15,%rbx
  418e59:	mov    (%rbx),%ebx
  418e5b:	cmp    %rbx,%r10
  418e5e:	ja     419ecf <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b4f>
  418e64:	lea    0x14(%r14,%r13,2),%r14
  418e69:	mov    %r10,%r13
  418e6c:	shl    $1,%r13
  418e6f:	mov    %r14,%rbx
  418e72:	add    %r13,%rbx
  418e75:	jb     419ed1 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b51>
  418e7b:	add    %r9,%r11
  418e7e:	cmp    %r11,%rbx
  418e81:	ja     419ed3 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b53>
  418e87:	lea    0x14(%r9,%r12,1),%r9
  418e8c:	mov    %r9,%rbx
  418e8f:	add    %r13,%rbx
  418e92:	jb     419ed5 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b55>
  418e98:	cmp    %r11,%rbx
  418e9b:	ja     419ed7 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b57>
  418ea1:	cmp    %r14,%r9
  418ea4:	ja     418f7d <wasm[0]::function[131]::builtin::Array.prototype.join+0x1bfd>
  418eaa:	lea    (%r14,%r10,2),%r14
  418eae:	mov    %r14,%rbx
  418eb1:	lea    0x14(%r8,%r10,2),%r9
  418eb6:	mov    %r9,%r14
  418eb9:	cmp    $0x8000000,%r13
  418ec0:	mov    %r13,%r12
  418ec3:	ja     418ed4 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1b54>
  418ec9:	mov    %r12,%r8
  418ecc:	mov    %rbx,%r9
  418ecf:	jmp    418f66 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1be6>
  418ed4:	mov    %edx,0x50(%rsp)
  418ed8:	mov    %eax,0x60(%rsp)
  418edc:	mov    %ecx,0x68(%rsp)
  418ee0:	mov    %esi,0x70(%rsp)
  418ee4:	mov    %edi,0x78(%rsp)
  418ee8:	mov    0x140(%rsp),%rcx
  418ef0:	mov    (%rcx),%r8
  418ef3:	mov    0xe0(%rsp),%rax
  418efb:	cmp    %rax,%r8
  418efe:	jae    419bce <wasm[0]::function[131]::builtin::Array.prototype.join+0x284e>
  418f04:	mov    $0x8000000,%ecx
  418f09:	mov    %rbx,%rsi
  418f0c:	sub    $0x8000000,%rsi
  418f13:	mov    %r14,%rdx
  418f16:	mov    %rsi,%rbx
  418f19:	sub    $0x8000000,%rdx
  418f20:	mov    %rdx,%r14
  418f23:	mov    0xb8(%rsp),%rdi
  418f2b:	call   3039aea <wasmtime_builtin_memory_copy>
  418f30:	mov    0x50(%rsp),%edx
  418f34:	mov    0x60(%rsp),%eax
  418f38:	mov    0x68(%rsp),%ecx
  418f3c:	mov    0x70(%rsp),%esi
  418f40:	mov    0x78(%rsp),%edi
  418f44:	mov    %r12,%r8
  418f47:	sub    $0x8000000,%r8
  418f4e:	cmp    $0x8000000,%r8
  418f55:	jbe    418f63 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1be3>
  418f5b:	mov    %r8,%r12
  418f5e:	jmp    418ed4 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1b54>
  418f63:	mov    %rbx,%r9
  418f66:	sub    %r8,%r9
  418f69:	mov    %r9,%rbx
  418f6c:	mov    %r14,%r9
  418f6f:	sub    %r8,%r9
  418f72:	mov    %r9,%r14
  418f75:	mov    %r8,%r12
  418f78:	jmp    419029 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1ca9>
  418f7d:	mov    %r13,%r8
  418f80:	mov    %r14,%rbx
  418f83:	mov    %r9,%r14
  418f86:	cmp    $0x8000000,%r8
  418f8d:	mov    %r8,%r12
  418f90:	jbe    419029 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1ca9>
  418f96:	mov    %edx,0x78(%rsp)
  418f9a:	mov    %eax,0x70(%rsp)
  418f9e:	mov    %ecx,0x68(%rsp)
  418fa2:	mov    %esi,0x60(%rsp)
  418fa6:	mov    %edi,0x50(%rsp)
  418faa:	mov    0x140(%rsp),%rcx
  418fb2:	mov    (%rcx),%rax
  418fb5:	mov    0xe0(%rsp),%rcx
  418fbd:	cmp    %rcx,%rax
  418fc0:	jae    419c05 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2885>
  418fc6:	mov    $0x8000000,%ecx
  418fcb:	mov    %r14,%rdx
  418fce:	mov    %rbx,%rsi
  418fd1:	mov    0xb8(%rsp),%rdi
  418fd9:	call   3039aea <wasmtime_builtin_memory_copy>
  418fde:	mov    0x78(%rsp),%edx
  418fe2:	mov    0x70(%rsp),%eax
  418fe6:	mov    0x68(%rsp),%ecx
  418fea:	mov    0x60(%rsp),%esi
  418fee:	mov    0x50(%rsp),%edi
  418ff2:	mov    %r12,%r8
  418ff5:	sub    $0x8000000,%r8
  418ffc:	mov    %r8,%r12
  418fff:	mov    %rbx,%r8
  419002:	add    $0x8000000,%r8
  419009:	mov    %r8,%rbx
  41900c:	mov    %r14,%r8
  41900f:	add    $0x8000000,%r8
  419016:	mov    %r8,%r14
  419019:	mov    %r12,%r8
  41901c:	cmp    $0x8000000,%r8
  419023:	ja     418f96 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1c16>
  419029:	mov    %edx,0x50(%rsp)
  41902d:	mov    %eax,0x60(%rsp)
  419031:	mov    %ecx,0x68(%rsp)
  419035:	mov    %esi,0x70(%rsp)
  419039:	mov    %edi,0x78(%rsp)
  41903d:	mov    0x140(%rsp),%rcx
  419045:	mov    (%rcx),%rax
  419048:	mov    0xe0(%rsp),%rdx
  419050:	cmp    %rdx,%rax
  419053:	jae    419c3c <wasm[0]::function[131]::builtin::Array.prototype.join+0x28bc>
  419059:	mov    %r12,%rcx
  41905c:	mov    %r14,%rdx
  41905f:	mov    %rbx,%rsi
  419062:	jmp    419070 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1cf0>
  419067:	mov    %r12,%rcx
  41906a:	mov    %r14,%rdx
  41906d:	mov    %rbx,%rsi
  419070:	mov    %r12,%rcx
  419073:	mov    %r14,%rdx
  419076:	mov    %rbx,%rsi
  419079:	mov    0xb8(%rsp),%rdi
  419081:	call   3039aea <wasmtime_builtin_memory_copy>
  419086:	mov    0x50(%rsp),%r8d
  41908b:	mov    0x60(%rsp),%edi
  41908f:	mov    0x68(%rsp),%edx
  419093:	mov    0x70(%rsp),%r9d
  419098:	mov    0x78(%rsp),%esi
  41909c:	mov    0xc8(%rsp),%rcx
  4190a4:	mov    0xe8(%rsp),%rax
  4190ac:	mov    %rax,0xc0(%rsp)
  4190b4:	add    $0x1,%rcx
  4190bb:	mov    %rcx,0xc8(%rsp)
  4190c3:	jmp    417bdd <wasm[0]::function[131]::builtin::Array.prototype.join+0x85d>
  4190c8:	mov    0x150(%rsp),%rbx
  4190d0:	mov    0x158(%rsp),%r12
  4190d8:	mov    0x160(%rsp),%r13
  4190e0:	mov    0x168(%rsp),%r14
  4190e8:	mov    0x170(%rsp),%r15
  4190f0:	add    $0x180,%rsp
  4190f7:	mov    %rbp,%rsp
  4190fa:	pop    %rbp
  4190fb:	ret    $0x40
  4190fe:	mov    %r11,%rdx
  419101:	mov    0x150(%rsp),%rbx
  419109:	mov    0x158(%rsp),%r12
  419111:	mov    0x160(%rsp),%r13
  419119:	mov    0x168(%rsp),%r14
  419121:	mov    0x170(%rsp),%r15
  419129:	add    $0x180,%rsp
  419130:	mov    %rbp,%rsp
  419133:	pop    %rbp
  419134:	ret    $0x40
  419137:	mov    0x58(%rsp),%eax
  41913b:	test   %eax,%eax
  41913d:	je     419ed9 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b59>
  419143:	test   %eax,%eax
  419145:	je     419edb <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b5b>
  41914b:	mov    0x138(%rsp),%r9
  419153:	mov    0x28(%r9),%rcx
  419157:	mov    0x20(%r9),%rdx
  41915b:	mov    %eax,%esi
  41915d:	lea    0x10(%rdx,%rsi,1),%rdx
  419162:	xor    %rdi,%rdi
  419165:	cmp    %rcx,%rsi
  419168:	cmova  %rdi,%rdx
  41916c:	mov    (%rdx),%ecx
  41916e:	mov    0xc0(%rsp),%r12
  419176:	cmp    %r12d,%ecx
  419179:	je     4195a0 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2220>
  41917f:	mov    0xc0(%rsp),%r12
  419187:	mov    %r12d,%r13d
  41918a:	mov    %r13,%rcx
  41918d:	shl    $1,%rcx
  419190:	mov    %rcx,%rsi
  419193:	shr    $0x20,%rsi
  419197:	mov    %rcx,%rbx
  41919a:	test   %rsi,%rsi
  41919d:	jne    419edd <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b5d>
  4191a3:	mov    0xc0(%rsp),%rax
  4191ab:	lea    (%r12,%rax,1),%ecx
  4191af:	add    $0x14,%ecx
  4191b2:	jb     419edf <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b5f>
  4191b8:	mov    0x120(%rsp),%r14
  4191c0:	mov    (%r14),%eax
  4191c3:	mov    %eax,%edi
  4191c5:	mov    %ecx,%r8d
  4191c8:	lea    0xf(%r8),%rsi
  4191cc:	and    $0xfffffffffffffff0,%rsi
  4191d0:	lea    (%rdi,%rsi,1),%r8
  4191d4:	mov    0x4(%r14),%r9d
  4191d8:	cmp    %r9,%r8
  4191db:	ja     419c7f <wasm[0]::function[131]::builtin::Array.prototype.join+0x28ff>
  4191e1:	lea    0xf(%rcx),%r9d
  4191e5:	and    $0xfffffff0,%r9d
  4191e9:	lea    (%rax,%r9,1),%r10d
  4191ed:	mov    0x120(%rsp),%r14
  4191f5:	mov    %r10d,(%r14)
  4191f8:	mov    0x138(%rsp),%r9
  419200:	mov    0x20(%r9),%r11
  419204:	lea    (%r11,%rdi,1),%rcx
  419208:	movl   $0xa8000006,(%r11,%rdi,1)
  419210:	mov    0xf8(%rsp),%rdx
  419218:	mov    %edx,0x4(%r11,%rdi,1)
  41921d:	mov    %esi,0x8(%r11,%rdi,1)
  419222:	mov    %eax,0x50(%rsp)
  419226:	mov    0xc0(%rsp),%r12
  41922e:	mov    %r12d,0x10(%rcx)
  419232:	test   %eax,%eax
  419234:	je     419ee1 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b61>
  41923a:	mov    0x138(%rsp),%r9
  419242:	mov    0x28(%r9),%rcx
  419246:	mov    0x20(%r9),%rdx
  41924a:	mov    %eax,%eax
  41924c:	lea    0x10(%rdx,%rax,1),%rsi
  419251:	xor    %rdi,%rdi
  419254:	cmp    %rcx,%rax
  419257:	cmova  %rdi,%rsi
  41925b:	mov    (%rsi),%esi
  41925d:	cmp    %rsi,%r13
  419260:	ja     419ee3 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b63>
  419266:	lea    0x14(%rdx,%rax,1),%rdi
  41926b:	mov    %rbx,%rsi
  41926e:	mov    %rdi,%rax
  419271:	add    %rsi,%rax
  419274:	mov    %rdi,%r12
  419277:	jb     419ee5 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b65>
  41927d:	add    %rdx,%rcx
  419280:	cmp    %rcx,%rax
  419283:	ja     419ee7 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b67>
  419289:	mov    0x58(%rsp),%eax
  41928d:	cmp    $0x8000000,%rsi
  419294:	jbe    4192fc <wasm[0]::function[131]::builtin::Array.prototype.join+0x1f7c>
  41929a:	mov    %eax,0x58(%rsp)
  41929e:	mov    0x140(%rsp),%rcx
  4192a6:	mov    (%rcx),%rax
  4192a9:	mov    0xe0(%rsp),%rcx
  4192b1:	cmp    %rcx,%rax
  4192b4:	jae    419cb7 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2937>
  4192ba:	xor    %edx,%edx
  4192bc:	mov    $0x8000000,%ecx
  4192c1:	mov    %r12,%rsi
  4192c4:	mov    0xb8(%rsp),%rdi
  4192cc:	call   3039b13 <wasmtime_builtin_memory_fill>
  4192d1:	mov    0x58(%rsp),%eax
  4192d5:	mov    %rbx,%rcx
  4192d8:	sub    $0x8000000,%rcx
  4192df:	mov    %rcx,%rbx
  4192e2:	mov    %r12,%rsi
  4192e5:	add    $0x8000000,%rsi
  4192ec:	mov    %rsi,%r12
  4192ef:	cmp    $0x8000000,%rcx
  4192f6:	ja     41929a <wasm[0]::function[131]::builtin::Array.prototype.join+0x1f1a>
  4192fc:	mov    %eax,0x58(%rsp)
  419300:	mov    0x140(%rsp),%rcx
  419308:	mov    (%rcx),%rax
  41930b:	mov    0xe0(%rsp),%rdx
  419313:	cmp    %rdx,%rax
  419316:	jae    419cee <wasm[0]::function[131]::builtin::Array.prototype.join+0x296e>
  41931c:	xor    %edx,%edx
  41931e:	mov    %rbx,%rcx
  419321:	mov    %r12,%rsi
  419324:	mov    0xb8(%rsp),%rdi
  41932c:	call   3039b13 <wasmtime_builtin_memory_fill>
  419331:	mov    0x50(%rsp),%eax
  419335:	test   %eax,%eax
  419337:	je     419ee9 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b69>
  41933d:	mov    0x58(%rsp),%edi
  419341:	test   %edi,%edi
  419343:	je     419eeb <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b6b>
  419349:	test   %eax,%eax
  41934b:	je     419eed <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b6d>
  419351:	mov    0x138(%rsp),%r9
  419359:	mov    0x28(%r9),%rsi
  41935d:	mov    0x20(%r9),%rdx
  419361:	mov    %eax,%r8d
  419364:	lea    (%rdx,%r8,1),%rax
  419368:	lea    0x10(%rdx,%r8,1),%r10
  41936d:	xor    %r9,%r9
  419370:	cmp    %rsi,%r8
  419373:	cmova  %r9,%r10
  419377:	mov    0xc0(%rsp),%r12
  41937f:	mov    %r12d,%ecx
  419382:	mov    (%r10),%r10d
  419385:	cmp    %r10,%rcx
  419388:	ja     419eef <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b6f>
  41938e:	test   %edi,%edi
  419390:	je     419ef1 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b71>
  419396:	mov    %edi,%r10d
  419399:	lea    (%rdx,%r10,1),%rdi
  41939d:	lea    0x10(%rdx,%r10,1),%r11
  4193a2:	cmp    %rsi,%r10
  4193a5:	cmova  %r9,%r11
  4193a9:	mov    (%r11),%r9d
  4193ac:	cmp    %r9,%rcx
  4193af:	ja     419ef3 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b73>
  4193b5:	lea    0x14(%rdx,%r8,1),%r11
  4193ba:	mov    %rcx,%r9
  4193bd:	shl    $1,%r9
  4193c0:	mov    %r11,%r8
  4193c3:	add    %r9,%r8
  4193c6:	jb     419ef5 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b75>
  4193cc:	add    %rdx,%rsi
  4193cf:	cmp    %rsi,%r8
  4193d2:	ja     419ef7 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b77>
  4193d8:	lea    0x14(%rdx,%r10,1),%rdx
  4193dd:	mov    %rdx,%r8
  4193e0:	add    %r9,%r8
  4193e3:	jb     419ef9 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b79>
  4193e9:	cmp    %rsi,%r8
  4193ec:	ja     419efb <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b7b>
  4193f2:	cmp    %r11,%rdx
  4193f5:	ja     4194b6 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2136>
  4193fb:	mov    0x50(%rsp),%r8d
  419400:	lea    0x14(%rax,%rcx,2),%r11
  419405:	mov    %r11,%r12
  419408:	lea    0x14(%rdi,%rcx,2),%rdx
  41940d:	mov    %rdx,%r13
  419410:	cmp    $0x8000000,%r9
  419417:	mov    %r9,%rbx
  41941a:	ja     41942b <wasm[0]::function[131]::builtin::Array.prototype.join+0x20ab>
  419420:	mov    %rbx,%rcx
  419423:	mov    %r12,%rsi
  419426:	jmp    41949f <wasm[0]::function[131]::builtin::Array.prototype.join+0x211f>
  41942b:	mov    %r8d,0x58(%rsp)
  419430:	mov    0x140(%rsp),%rcx
  419438:	mov    (%rcx),%rax
  41943b:	mov    0xe0(%rsp),%r9
  419443:	cmp    %r9,%rax
  419446:	jae    419d28 <wasm[0]::function[131]::builtin::Array.prototype.join+0x29a8>
  41944c:	mov    $0x8000000,%ecx
  419451:	mov    %r12,%rsi
  419454:	sub    $0x8000000,%rsi
  41945b:	mov    %r13,%rdx
  41945e:	mov    %rsi,%r12
  419461:	sub    $0x8000000,%rdx
  419468:	mov    %rdx,%r13
  41946b:	mov    0xb8(%rsp),%rdi
  419473:	call   3039aea <wasmtime_builtin_memory_copy>
  419478:	mov    0x58(%rsp),%r8d
  41947d:	mov    %rbx,%rcx
  419480:	sub    $0x8000000,%rcx
  419487:	cmp    $0x8000000,%rcx
  41948e:	jbe    41949c <wasm[0]::function[131]::builtin::Array.prototype.join+0x211c>
  419494:	mov    %rcx,%rbx
  419497:	jmp    41942b <wasm[0]::function[131]::builtin::Array.prototype.join+0x20ab>
  41949c:	mov    %r12,%rsi
  41949f:	sub    %rcx,%rsi
  4194a2:	mov    %r13,%rdx
  4194a5:	mov    %rsi,%r12
  4194a8:	sub    %rcx,%rdx
  4194ab:	mov    %rdx,%r13
  4194ae:	mov    %rcx,%rbx
  4194b1:	jmp    419546 <wasm[0]::function[131]::builtin::Array.prototype.join+0x21c6>
  4194b6:	mov    %r9,%rcx
  4194b9:	mov    %r11,%r12
  4194bc:	mov    %rdx,%r13
  4194bf:	mov    0x50(%rsp),%r8d
  4194c4:	cmp    $0x8000000,%rcx
  4194cb:	mov    %rcx,%rbx
  4194ce:	jbe    419546 <wasm[0]::function[131]::builtin::Array.prototype.join+0x21c6>
  4194d4:	mov    %r8d,0x50(%rsp)
  4194d9:	mov    0x140(%rsp),%rcx
  4194e1:	mov    (%rcx),%rax
  4194e4:	mov    0xe0(%rsp),%rcx
  4194ec:	cmp    %rcx,%rax
  4194ef:	jae    419d5f <wasm[0]::function[131]::builtin::Array.prototype.join+0x29df>
  4194f5:	mov    $0x8000000,%ecx
  4194fa:	mov    %r13,%rdx
  4194fd:	mov    %r12,%rsi
  419500:	mov    0xb8(%rsp),%rdi
  419508:	call   3039aea <wasmtime_builtin_memory_copy>
  41950d:	mov    0x50(%rsp),%r8d
  419512:	mov    %rbx,%rcx
  419515:	sub    $0x8000000,%rcx
  41951c:	mov    %rcx,%rbx
  41951f:	mov    %r12,%rsi
  419522:	add    $0x8000000,%rsi
  419529:	mov    %r13,%rdx
  41952c:	mov    %rsi,%r12
  41952f:	add    $0x8000000,%rdx
  419536:	mov    %rdx,%r13
  419539:	cmp    $0x8000000,%rcx
  419540:	ja     4194d4 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2154>
  419546:	mov    %r8d,0x50(%rsp)
  41954b:	mov    0x140(%rsp),%rcx
  419553:	mov    (%rcx),%rax
  419556:	mov    0xe0(%rsp),%rsi
  41955e:	cmp    %rsi,%rax
  419561:	jae    419d96 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2a16>
  419567:	mov    %rbx,%rcx
  41956a:	mov    %r13,%rdx
  41956d:	mov    %r12,%rsi
  419570:	jmp    41957e <wasm[0]::function[131]::builtin::Array.prototype.join+0x21fe>
  419575:	mov    %rbx,%rcx
  419578:	mov    %r13,%rdx
  41957b:	mov    %r12,%rsi
  41957e:	mov    %rbx,%rcx
  419581:	mov    %r13,%rdx
  419584:	mov    %r12,%rsi
  419587:	mov    0xb8(%rsp),%rdi
  41958f:	call   3039aea <wasmtime_builtin_memory_copy>
  419594:	mov    0x50(%rsp),%eax
  419598:	test   %eax,%eax
  41959a:	je     419efd <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b7d>
  4195a0:	mov    %eax,0x50(%rsp)
  4195a4:	test   %eax,%eax
  4195a6:	je     419eff <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b7f>
  4195ac:	mov    0x120(%rsp),%r14
  4195b4:	mov    (%r14),%edx
  4195b7:	mov    %edx,%ecx
  4195b9:	lea    0x20(%rcx),%rax
  4195bd:	mov    0x4(%r14),%esi
  4195c1:	cmp    %rsi,%rax
  4195c4:	ja     419dc6 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2a46>
  4195ca:	lea    0x20(%rdx),%eax
  4195cd:	mov    0x120(%rsp),%r14
  4195d5:	mov    %eax,(%r14)
  4195d8:	mov    0x138(%rsp),%r9
  4195e0:	mov    0x20(%r9),%rsi
  4195e4:	lea    (%rsi,%rcx,1),%rdi
  4195e8:	movl   $0xb000000a,(%rsi,%rcx,1)
  4195ef:	mov    0x100(%rsp),%r8
  4195f7:	mov    0x234(%r8),%r8d
  4195fe:	mov    %r8d,0x4(%rsi,%rcx,1)
  419603:	mov    0x118(%rsp),%rax
  41960b:	mov    %eax,0x8(%rsi,%rcx,1)
  41960f:	mov    0x50(%rsp),%esi
  419613:	mov    %esi,0x10(%rdi)
  419616:	xor    %rcx,%rcx
  419619:	movq   $0x0,0x18(%rdi)
  419621:	test   %edx,%edx
  419623:	je     419f01 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2b81>
  419629:	mov    $0x4,%eax
  41962e:	xor    %edi,%edi
  419630:	mov    %rdi,%rsi
  419633:	mov    0x150(%rsp),%rbx
  41963b:	mov    0x158(%rsp),%r12
  419643:	mov    0x160(%rsp),%r13
  41964b:	mov    0x168(%rsp),%r14
  419653:	mov    0x170(%rsp),%r15
  41965b:	add    $0x180,%rsp
  419662:	mov    %rbp,%rsp
  419665:	pop    %rbp
  419666:	ret    $0x40
  419669:	mov    0x150(%rsp),%rbx
  419671:	mov    0x158(%rsp),%r12
  419679:	mov    0x160(%rsp),%r13
  419681:	mov    0x168(%rsp),%r14
  419689:	mov    0x170(%rsp),%r15
  419691:	add    $0x180,%rsp
  419698:	mov    %rbp,%rsp
  41969b:	pop    %rbp
  41969c:	ret    $0x40
  41969f:	mov    0x48(%rsp),%edx
  4196a3:	mov    %r15,%rax
  4196a6:	mov    %r14,%rcx
  4196a9:	mov    %rbx,%rdi
  4196ac:	mov    0x150(%rsp),%rbx
  4196b4:	mov    0x158(%rsp),%r12
  4196bc:	mov    0x160(%rsp),%r13
  4196c4:	mov    0x168(%rsp),%r14
  4196cc:	mov    0x170(%rsp),%r15
  4196d4:	add    $0x180,%rsp
  4196db:	mov    %rbp,%rsp
  4196de:	pop    %rbp
  4196df:	ret    $0x40
  4196e2:	mov    %rdx,%rax
  4196e5:	mov    %r8,%rdx
  4196e8:	mov    0x150(%rsp),%rbx
  4196f0:	mov    0x158(%rsp),%r12
  4196f8:	mov    0x160(%rsp),%r13
  419700:	mov    0x168(%rsp),%r14
  419708:	mov    0x170(%rsp),%r15
  419710:	add    $0x180,%rsp
  419717:	mov    %rbp,%rsp
  41971a:	pop    %rbp
  41971b:	ret    $0x40
  41971e:	mov    0x128(%rsp),%rax
  419726:	mov    0x130(%rsp),%rcx
  41972e:	mov    0x150(%rsp),%rbx
  419736:	mov    0x158(%rsp),%r12
  41973e:	mov    0x160(%rsp),%r13
  419746:	mov    0x168(%rsp),%r14
  41974e:	mov    0x170(%rsp),%r15
  419756:	add    $0x180,%rsp
  41975d:	mov    %rbp,%rsp
  419760:	pop    %rbp
  419761:	ret    $0x40
  419764:	mov    0xb8(%rsp),%rdi
  41976c:	call   3039b69 <wasmtime_builtin_new_epoch>
  419771:	mov    %rax,0xe0(%rsp)
  419779:	jmp    417436 <wasm[0]::function[131]::builtin::Array.prototype.join+0xb6>
  41977e:	mov    $0xa800000e,%esi
  419783:	mov    0xb8(%rsp),%rdi
  41978b:	mov    0x28(%rdi),%rax
  41978f:	mov    0x1b4(%rax),%edx
  419795:	mov    $0x14,%ecx
  41979a:	mov    $0x10,%r8d
  4197a0:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
  4197a5:	mov    %eax,%edx
  4197a7:	mov    0x138(%rsp),%r9
  4197af:	add    0x20(%r9),%rdx
  4197b3:	jmp    417582 <wasm[0]::function[131]::builtin::Array.prototype.join+0x202>
  4197b8:	mov    $0xa8000006,%esi
  4197bd:	mov    0xb8(%rsp),%rdi
  4197c5:	mov    0x28(%rdi),%rax
  4197c9:	mov    0x238(%rax),%edx
  4197cf:	mov    $0x14,%ecx
  4197d4:	mov    $0x10,%r8d
  4197da:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
  4197df:	mov    %eax,%edx
  4197e1:	mov    0x138(%rsp),%r9
  4197e9:	add    0x20(%r9),%rdx
  4197ed:	mov    %r13,0x118(%rsp)
  4197f5:	mov    %r14,0x120(%rsp)
  4197fd:	jmp    417a93 <wasm[0]::function[131]::builtin::Array.prototype.join+0x713>
  419802:	mov    0x138(%rsp),%r9
  41980a:	mov    0x8(%r9),%rax
  41980e:	cmp    %rax,%rcx
  419811:	jb     417b41 <wasm[0]::function[131]::builtin::Array.prototype.join+0x7c1>
  419817:	mov    0xb8(%rsp),%rdi
  41981f:	call   3039b69 <wasmtime_builtin_new_epoch>
  419824:	mov    %rax,0xe0(%rsp)
  41982c:	jmp    417b49 <wasm[0]::function[131]::builtin::Array.prototype.join+0x7c9>
  419831:	mov    0x138(%rsp),%r9
  419839:	mov    0x8(%r9),%rcx
  41983d:	mov    %rcx,0xe0(%rsp)
  419845:	cmp    %rcx,%rax
  419848:	jb     417c2a <wasm[0]::function[131]::builtin::Array.prototype.join+0x8aa>
  41984e:	mov    0xb8(%rsp),%rdi
  419856:	call   3039b69 <wasmtime_builtin_new_epoch>
  41985b:	mov    %rax,0xe0(%rsp)
  419863:	mov    0xc8(%rsp),%rcx
  41986b:	mov    0xd0(%rsp),%r11
  419873:	jmp    417c3a <wasm[0]::function[131]::builtin::Array.prototype.join+0x8ba>
  419878:	mov    0xf8(%rsp),%rdx
  419880:	mov    0x108(%rsp),%rsi
  419888:	mov    0xb8(%rsp),%rdi
  419890:	mov    0x110(%rsp),%r8
  419898:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
  41989d:	mov    %eax,%ecx
  41989f:	mov    0x138(%rsp),%r9
  4198a7:	add    0x20(%r9),%rcx
  4198ab:	jmp    417e1f <wasm[0]::function[131]::builtin::Array.prototype.join+0xa9f>
  4198b0:	mov    0x138(%rsp),%r9
  4198b8:	mov    0x8(%r9),%rcx
  4198bc:	mov    %rcx,0xe0(%rsp)
  4198c4:	cmp    %rcx,%rax
  4198c7:	jb     417ef3 <wasm[0]::function[131]::builtin::Array.prototype.join+0xb73>
  4198cd:	mov    0xb8(%rsp),%rdi
  4198d5:	call   3039b69 <wasmtime_builtin_new_epoch>
  4198da:	mov    %rax,0xe0(%rsp)
  4198e2:	jmp    417ef3 <wasm[0]::function[131]::builtin::Array.prototype.join+0xb73>
  4198e7:	mov    0x138(%rsp),%r9
  4198ef:	mov    0x8(%r9),%rcx
  4198f3:	mov    %rcx,0xe0(%rsp)
  4198fb:	cmp    %rcx,%rax
  4198fe:	jb     417f94 <wasm[0]::function[131]::builtin::Array.prototype.join+0xc14>
  419904:	mov    0xb8(%rsp),%rdi
  41990c:	call   3039b69 <wasmtime_builtin_new_epoch>
  419911:	mov    %rax,0xe0(%rsp)
  419919:	jmp    417f94 <wasm[0]::function[131]::builtin::Array.prototype.join+0xc14>
  41991e:	mov    0x138(%rsp),%r9
  419926:	mov    0x8(%r9),%rcx
  41992a:	mov    %rcx,0xe0(%rsp)
  419932:	cmp    %rcx,%rax
  419935:	jb     4180fd <wasm[0]::function[131]::builtin::Array.prototype.join+0xd7d>
  41993b:	mov    0xb8(%rsp),%rdi
  419943:	call   3039b69 <wasmtime_builtin_new_epoch>
  419948:	mov    %rax,0xe0(%rsp)
  419950:	jmp    4180fd <wasm[0]::function[131]::builtin::Array.prototype.join+0xd7d>
  419955:	mov    0x138(%rsp),%r9
  41995d:	mov    0x8(%r9),%rcx
  419961:	mov    %rcx,0xe0(%rsp)
  419969:	cmp    %rcx,%rax
  41996c:	jb     4181f7 <wasm[0]::function[131]::builtin::Array.prototype.join+0xe77>
  419972:	mov    0xb8(%rsp),%rdi
  41997a:	call   3039b69 <wasmtime_builtin_new_epoch>
  41997f:	mov    %rax,0xe0(%rsp)
  419987:	jmp    4181f7 <wasm[0]::function[131]::builtin::Array.prototype.join+0xe77>
  41998c:	mov    0x138(%rsp),%r9
  419994:	mov    0x8(%r9),%rax
  419998:	mov    %rax,0xe0(%rsp)
  4199a0:	cmp    %rax,%r8
  4199a3:	jb     4182ae <wasm[0]::function[131]::builtin::Array.prototype.join+0xf2e>
  4199a9:	mov    0xb8(%rsp),%rdi
  4199b1:	call   3039b69 <wasmtime_builtin_new_epoch>
  4199b6:	mov    %rax,0xe0(%rsp)
  4199be:	mov    %rbx,%rcx
  4199c1:	mov    %r13,%rdx
  4199c4:	mov    %r12,%rsi
  4199c7:	jmp    4182b7 <wasm[0]::function[131]::builtin::Array.prototype.join+0xf37>
  4199cc:	mov    0x138(%rsp),%r9
  4199d4:	mov    0x8(%r9),%rcx
  4199d8:	mov    %rcx,0xe0(%rsp)
  4199e0:	cmp    %rcx,%rax
  4199e3:	jb     418428 <wasm[0]::function[131]::builtin::Array.prototype.join+0x10a8>
  4199e9:	mov    0xb8(%rsp),%rdi
  4199f1:	call   3039b69 <wasmtime_builtin_new_epoch>
  4199f6:	mov    %rax,0xe0(%rsp)
  4199fe:	jmp    418428 <wasm[0]::function[131]::builtin::Array.prototype.join+0x10a8>
  419a03:	mov    0x138(%rsp),%rcx
  419a0b:	mov    0x8(%rcx),%rax
  419a0f:	mov    %rax,0xe0(%rsp)
  419a17:	cmp    %rax,%r9
  419a1a:	jb     4184f6 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1176>
  419a20:	mov    0xb8(%rsp),%rdi
  419a28:	call   3039b69 <wasmtime_builtin_new_epoch>
  419a2d:	mov    %rax,0xe0(%rsp)
  419a35:	jmp    4184f6 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1176>
  419a3a:	mov    0x138(%rsp),%r9
  419a42:	mov    0x8(%r9),%rcx
  419a46:	mov    %rcx,0xe0(%rsp)
  419a4e:	cmp    %rcx,%rax
  419a51:	jb     4185a3 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1223>
  419a57:	mov    0xb8(%rsp),%rdi
  419a5f:	call   3039b69 <wasmtime_builtin_new_epoch>
  419a64:	mov    %rax,0xe0(%rsp)
  419a6c:	mov    %r12,%rcx
  419a6f:	mov    %r14,%rdx
  419a72:	mov    %rbx,%rsi
  419a75:	jmp    4185ac <wasm[0]::function[131]::builtin::Array.prototype.join+0x122c>
  419a7a:	mov    0xf8(%rsp),%rdx
  419a82:	mov    0x108(%rsp),%rsi
  419a8a:	mov    0xb8(%rsp),%rdi
  419a92:	mov    0x110(%rsp),%r8
  419a9a:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
  419a9f:	mov    %eax,%ecx
  419aa1:	mov    0x138(%rsp),%r9
  419aa9:	add    0x20(%r9),%rcx
  419aad:	jmp    418914 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1594>
  419ab2:	mov    0x138(%rsp),%r9
  419aba:	mov    0x8(%r9),%rcx
  419abe:	mov    %rcx,0xe0(%rsp)
  419ac6:	cmp    %rcx,%rax
  419ac9:	jb     4189e2 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1662>
  419acf:	mov    0xb8(%rsp),%rdi
  419ad7:	call   3039b69 <wasmtime_builtin_new_epoch>
  419adc:	mov    %rax,0xe0(%rsp)
  419ae4:	jmp    4189e2 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1662>
  419ae9:	mov    0x138(%rsp),%r9
  419af1:	mov    0x8(%r9),%rax
  419af5:	mov    %rax,0xe0(%rsp)
  419afd:	cmp    %rax,%r11
  419b00:	jb     418a7d <wasm[0]::function[131]::builtin::Array.prototype.join+0x16fd>
  419b06:	mov    0xb8(%rsp),%rdi
  419b0e:	call   3039b69 <wasmtime_builtin_new_epoch>
  419b13:	mov    %rax,0xe0(%rsp)
  419b1b:	jmp    418a7d <wasm[0]::function[131]::builtin::Array.prototype.join+0x16fd>
  419b20:	mov    0x138(%rsp),%r9
  419b28:	mov    0x8(%r9),%rcx
  419b2c:	mov    %rcx,0xe0(%rsp)
  419b34:	cmp    %rcx,%rax
  419b37:	jb     418be8 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1868>
  419b3d:	mov    0xb8(%rsp),%rdi
  419b45:	call   3039b69 <wasmtime_builtin_new_epoch>
  419b4a:	mov    %rax,0xe0(%rsp)
  419b52:	jmp    418be8 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1868>
  419b57:	mov    0x138(%rsp),%r9
  419b5f:	mov    0x8(%r9),%rax
  419b63:	mov    %rax,0xe0(%rsp)
  419b6b:	cmp    %rax,%r11
  419b6e:	jb     418ce2 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1962>
  419b74:	mov    0xb8(%rsp),%rdi
  419b7c:	call   3039b69 <wasmtime_builtin_new_epoch>
  419b81:	mov    %rax,0xe0(%rsp)
  419b89:	jmp    418ce2 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1962>
  419b8e:	mov    0x138(%rsp),%r9
  419b96:	mov    0x8(%r9),%rcx
  419b9a:	mov    %rcx,0xe0(%rsp)
  419ba2:	cmp    %rcx,%rax
  419ba5:	jb     418d93 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1a13>
  419bab:	mov    0xb8(%rsp),%rdi
  419bb3:	call   3039b69 <wasmtime_builtin_new_epoch>
  419bb8:	mov    %rax,0xe0(%rsp)
  419bc0:	mov    %r14,%rcx
  419bc3:	mov    %r12,%rdx
  419bc6:	mov    %rbx,%rsi
  419bc9:	jmp    418d9c <wasm[0]::function[131]::builtin::Array.prototype.join+0x1a1c>
  419bce:	mov    0x138(%rsp),%r9
  419bd6:	mov    0x8(%r9),%rax
  419bda:	mov    %rax,0xe0(%rsp)
  419be2:	cmp    %rax,%r8
  419be5:	jb     418f04 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1b84>
  419beb:	mov    0xb8(%rsp),%rdi
  419bf3:	call   3039b69 <wasmtime_builtin_new_epoch>
  419bf8:	mov    %rax,0xe0(%rsp)
  419c00:	jmp    418f04 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1b84>
  419c05:	mov    0x138(%rsp),%r9
  419c0d:	mov    0x8(%r9),%rcx
  419c11:	mov    %rcx,0xe0(%rsp)
  419c19:	cmp    %rcx,%rax
  419c1c:	jb     418fc6 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1c46>
  419c22:	mov    0xb8(%rsp),%rdi
  419c2a:	call   3039b69 <wasmtime_builtin_new_epoch>
  419c2f:	mov    %rax,0xe0(%rsp)
  419c37:	jmp    418fc6 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1c46>
  419c3c:	mov    0x138(%rsp),%r9
  419c44:	mov    0x8(%r9),%rsi
  419c48:	mov    %rsi,%r8
  419c4b:	mov    %rsi,0xe0(%rsp)
  419c53:	cmp    %r8,%rax
  419c56:	jb     419067 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1ce7>
  419c5c:	mov    0xb8(%rsp),%rdi
  419c64:	call   3039b69 <wasmtime_builtin_new_epoch>
  419c69:	mov    %rax,0xe0(%rsp)
  419c71:	mov    %r12,%rcx
  419c74:	mov    %r14,%rdx
  419c77:	mov    %rbx,%rsi
  419c7a:	jmp    419070 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1cf0>
  419c7f:	mov    0xf8(%rsp),%rdx
  419c87:	mov    0x108(%rsp),%rsi
  419c8f:	mov    0xb8(%rsp),%rdi
  419c97:	mov    0x110(%rsp),%r8
  419c9f:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
  419ca4:	mov    %eax,%ecx
  419ca6:	mov    0x138(%rsp),%r9
  419cae:	add    0x20(%r9),%rcx
  419cb2:	jmp    419222 <wasm[0]::function[131]::builtin::Array.prototype.join+0x1ea2>
  419cb7:	mov    0x138(%rsp),%r9
  419cbf:	mov    0x8(%r9),%rcx
  419cc3:	mov    %rcx,0xe0(%rsp)
  419ccb:	cmp    %rcx,%rax
  419cce:	jb     4192ba <wasm[0]::function[131]::builtin::Array.prototype.join+0x1f3a>
  419cd4:	mov    0xb8(%rsp),%rdi
  419cdc:	call   3039b69 <wasmtime_builtin_new_epoch>
  419ce1:	mov    %rax,0xe0(%rsp)
  419ce9:	jmp    4192ba <wasm[0]::function[131]::builtin::Array.prototype.join+0x1f3a>
  419cee:	mov    0x138(%rsp),%r9
  419cf6:	mov    0x8(%r9),%rsi
  419cfa:	mov    %rsi,%r8
  419cfd:	mov    %rsi,0xe0(%rsp)
  419d05:	cmp    %r8,%rax
  419d08:	jb     41931c <wasm[0]::function[131]::builtin::Array.prototype.join+0x1f9c>
  419d0e:	mov    0xb8(%rsp),%rdi
  419d16:	call   3039b69 <wasmtime_builtin_new_epoch>
  419d1b:	mov    %rax,0xe0(%rsp)
  419d23:	jmp    41931c <wasm[0]::function[131]::builtin::Array.prototype.join+0x1f9c>
  419d28:	mov    0x138(%rsp),%r9
  419d30:	mov    0x8(%r9),%rcx
  419d34:	mov    %rcx,0xe0(%rsp)
  419d3c:	cmp    %rcx,%rax
  419d3f:	jb     41944c <wasm[0]::function[131]::builtin::Array.prototype.join+0x20cc>
  419d45:	mov    0xb8(%rsp),%rdi
  419d4d:	call   3039b69 <wasmtime_builtin_new_epoch>
  419d52:	mov    %rax,0xe0(%rsp)
  419d5a:	jmp    41944c <wasm[0]::function[131]::builtin::Array.prototype.join+0x20cc>
  419d5f:	mov    0x138(%rsp),%r9
  419d67:	mov    0x8(%r9),%rcx
  419d6b:	mov    %rcx,0xe0(%rsp)
  419d73:	cmp    %rcx,%rax
  419d76:	jb     4194f5 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2175>
  419d7c:	mov    0xb8(%rsp),%rdi
  419d84:	call   3039b69 <wasmtime_builtin_new_epoch>
  419d89:	mov    %rax,0xe0(%rsp)
  419d91:	jmp    4194f5 <wasm[0]::function[131]::builtin::Array.prototype.join+0x2175>
  419d96:	mov    0x138(%rsp),%r9
  419d9e:	mov    0x8(%r9),%rcx
  419da2:	cmp    %rcx,%rax
  419da5:	jb     419575 <wasm[0]::function[131]::builtin::Array.prototype.join+0x21f5>
  419dab:	mov    0xb8(%rsp),%rdi
  419db3:	call   3039b69 <wasmtime_builtin_new_epoch>
  419db8:	mov    %rbx,%rcx
  419dbb:	mov    %r13,%rdx
  419dbe:	mov    %r12,%rsi
  419dc1:	jmp    41957e <wasm[0]::function[131]::builtin::Array.prototype.join+0x21fe>
  419dc6:	mov    $0xb000000a,%esi
  419dcb:	mov    0x100(%rsp),%rcx
  419dd3:	mov    0x234(%rcx),%edx
  419dd9:	mov    $0x20,%ecx
  419dde:	mov    0xb8(%rsp),%rdi
  419de6:	mov    0x110(%rsp),%r8
  419dee:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
  419df3:	mov    %eax,%edi
  419df5:	mov    0x138(%rsp),%r9
  419dfd:	add    0x20(%r9),%rdi
  419e01:	mov    %rax,%rdx
  419e04:	jmp    41960f <wasm[0]::function[131]::builtin::Array.prototype.join+0x228f>
  419e09:	ud2
  419e0b:	ud2
  419e0d:	ud2
  419e0f:	ud2
  419e11:	ud2
  419e13:	ud2
  419e15:	ud2
  419e17:	ud2
  419e19:	ud2
  419e1b:	ud2
  419e1d:	ud2
  419e1f:	ud2
  419e21:	ud2
  419e23:	ud2
  419e25:	ud2
  419e27:	ud2
  419e29:	ud2
  419e2b:	ud2
  419e2d:	ud2
  419e2f:	ud2
  419e31:	ud2
  419e33:	ud2
  419e35:	ud2
  419e37:	ud2
  419e39:	ud2
  419e3b:	ud2
  419e3d:	ud2
  419e3f:	ud2
  419e41:	ud2
  419e43:	ud2
  419e45:	ud2
  419e47:	ud2
  419e49:	ud2
  419e4b:	ud2
  419e4d:	ud2
  419e4f:	ud2
  419e51:	ud2
  419e53:	ud2
  419e55:	ud2
  419e57:	ud2
  419e59:	ud2
  419e5b:	ud2
  419e5d:	ud2
  419e5f:	ud2
  419e61:	ud2
  419e63:	ud2
  419e65:	ud2
  419e67:	ud2
  419e69:	ud2
  419e6b:	ud2
  419e6d:	ud2
  419e6f:	ud2
  419e71:	ud2
  419e73:	ud2
  419e75:	ud2
  419e77:	ud2
  419e79:	ud2
  419e7b:	ud2
  419e7d:	ud2
  419e7f:	ud2
  419e81:	ud2
  419e83:	ud2
  419e85:	ud2
  419e87:	ud2
  419e89:	ud2
  419e8b:	ud2
  419e8d:	ud2
  419e8f:	ud2
  419e91:	ud2
  419e93:	ud2
  419e95:	ud2
  419e97:	ud2
  419e99:	ud2
  419e9b:	ud2
  419e9d:	ud2
  419e9f:	ud2
  419ea1:	ud2
  419ea3:	ud2
  419ea5:	ud2
  419ea7:	ud2
  419ea9:	ud2
  419eab:	ud2
  419ead:	ud2
  419eaf:	ud2
  419eb1:	ud2
  419eb3:	ud2
  419eb5:	ud2
  419eb7:	ud2
  419eb9:	ud2
  419ebb:	ud2
  419ebd:	ud2
  419ebf:	ud2
  419ec1:	ud2
  419ec3:	ud2
  419ec5:	ud2
  419ec7:	ud2
  419ec9:	ud2
  419ecb:	ud2
  419ecd:	ud2
  419ecf:	ud2
  419ed1:	ud2
  419ed3:	ud2
  419ed5:	ud2
  419ed7:	ud2
  419ed9:	ud2
  419edb:	ud2
  419edd:	ud2
  419edf:	ud2
  419ee1:	ud2
  419ee3:	ud2
  419ee5:	ud2
  419ee7:	ud2
  419ee9:	ud2
  419eeb:	ud2
  419eed:	ud2
  419eef:	ud2
  419ef1:	ud2
  419ef3:	ud2
  419ef5:	ud2
  419ef7:	ud2
  419ef9:	ud2
  419efb:	ud2
  419efd:	ud2
  419eff:	ud2
  419f01:	ud2
	...
  419f0f:	add    %bh,%bh
  419f11:	(bad)
  419f12:	(bad)
  419f13:	(bad)
  419f14:	(bad)
  419f15:	(bad)
  419f16:	(bad)
  419f17:	rex.XB add %al,(%r8)
  419f1a:	add    %al,(%rax)
  419f1c:	add    %al,(%rax)
	...
