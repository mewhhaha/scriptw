
/workspace/scriptw/target/performance-dense-numbers-20261030/native-cause/candidate/runtime-portable.elf:     file format elf64-x86-64


Disassembly of section .text:

00000000029efe20 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data>:
 29efe20:	push   %rbp
 29efe21:	mov    %rsp,%rbp
 29efe24:	mov    0x8(%rdi),%r10
 29efe28:	mov    0x18(%r10),%r10
 29efe2c:	add    $0x120,%r10
 29efe33:	cmp    %rsp,%r10
 29efe36:	ja     29f2d29 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2f09>
 29efe3c:	sub    $0x110,%rsp
 29efe43:	mov    %rbx,0xe0(%rsp)
 29efe4b:	mov    %r12,0xe8(%rsp)
 29efe53:	mov    %r13,0xf0(%rsp)
 29efe5b:	mov    %r14,0xf8(%rsp)
 29efe63:	mov    %r15,0x100(%rsp)
 29efe6b:	mov    %rcx,0x68(%rsp)
 29efe70:	mov    %r8,0x70(%rsp)
 29efe75:	mov    %r9,0x78(%rsp)
 29efe7a:	mov    0x10(%rbp),%rsi
 29efe7e:	mov    %edx,0x20(%rsp)
 29efe82:	mov    %esi,0x28(%rsp)
 29efe86:	movl   $0x0,(%rsp)
 29efe8d:	mov    0x18(%rdi),%rax
 29efe91:	mov    (%rax),%rcx
 29efe94:	mov    %rax,0xd8(%rsp)
 29efe9c:	mov    0x8(%rdi),%rdx
 29efea0:	mov    %rdi,0x60(%rsp)
 29efea5:	mov    0x8(%rdx),%rax
 29efea9:	mov    %rdx,0xd0(%rsp)
 29efeb1:	cmp    %rax,%rcx
 29efeb4:	jae    29f26b9 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2899>
 29efeba:	mov    %rax,0x98(%rsp)
 29efec2:	mov    0x20(%rsp),%edx
 29efec6:	xor    %r10d,%r10d
 29efec9:	test   %edx,%edx
 29efecb:	je     29f2d2b <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2f0b>
 29efed1:	test   %edx,%edx
 29efed3:	je     29f2d2d <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2f0d>
 29efed9:	mov    0xd0(%rsp),%r14
 29efee1:	mov    0x28(%r14),%rsi
 29efee5:	mov    0x20(%r14),%r8
 29efee9:	mov    %edx,%ecx
 29efeeb:	xor    %rax,%rax
 29efeee:	lea    (%r8,%rcx,1),%rdi
 29efef2:	cmp    %rsi,%rcx
 29efef5:	cmova  %rax,%rdi
 29efef9:	mov    0x14(%rdi),%ecx
 29efefc:	test   %ecx,%ecx
 29efefe:	mov    %rcx,0x80(%rsp)
 29eff06:	je     29f2d2f <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2f0f>
 29eff0c:	mov    0x80(%rsp),%rdi
 29eff14:	test   %edi,%ecx
 29eff16:	je     29f2d31 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2f11>
 29eff1c:	mov    %ecx,%edi
 29eff1e:	add    %rdi,%r8
 29eff21:	cmp    %rsi,%rdi
 29eff24:	cmova  %rax,%r8
 29eff28:	mov    0x24(%r8),%r9d
 29eff2c:	mov    (%rsp),%ebx
 29eff2f:	mov    %rbx,0x88(%rsp)
 29eff37:	mov    0x28(%rsp),%esi
 29eff3b:	cmp    $0x4,%r9d
 29eff3f:	sete   %r8b
 29eff43:	cmp    $0x2,%r9d
 29eff47:	sete   %r9b
 29eff4b:	or     %r9d,%r8d
 29eff4e:	mov    0x70(%rsp),%rcx
 29eff53:	cmp    $0x3,%ecx
 29eff56:	sete   %r11b
 29eff5a:	test   %r8b,%r11b
 29eff5d:	jne    29eff80 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x160>
 29eff63:	mov    %r14,0xd0(%rsp)
 29eff6b:	mov    %rax,0x90(%rsp)
 29eff73:	mov    0x80(%rsp),%r14
 29eff7b:	jmp    29f13d0 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x15b0>
 29eff80:	mov    0x28(%r14),%rax
 29eff84:	mov    0x20(%r14),%rsi
 29eff88:	mov    %r14,0xd0(%rsp)
 29eff90:	lea    (%rsi,%rdi,1),%r11
 29eff94:	xor    %rdx,%rdx
 29eff97:	cmp    %rax,%rdi
 29eff9a:	cmova  %rdx,%r11
 29eff9e:	mov    0x28(%r11),%edi
 29effa2:	mov    0x2c(%r11),%r8d
 29effa6:	xor    %r10d,%r10d
 29effa9:	test   %edi,%edi
 29effab:	je     29f2d33 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2f13>
 29effb1:	test   %edi,%edi
 29effb3:	je     29f2d35 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2f15>
 29effb9:	mov    %edi,%r9d
 29effbc:	lea    0x10(%rsi,%r9,1),%rsi
 29effc1:	cmp    %rax,%r9
 29effc4:	cmova  %rdx,%rsi
 29effc8:	mov    (%rsi),%r14d
 29effcb:	mov    0x18(%r11),%rax
 29effcf:	mov    (%rsp),%ebx
 29effd2:	mov    %rbx,0x88(%rsp)
 29effda:	mov    0x28(%rsp),%esi
 29effde:	mov    0x20(%rsp),%edx
 29effe2:	mov    %r14d,%r15d
 29effe5:	mov    0x68(%rsp),%r9
 29effea:	cmp    %r15,%r9
 29effed:	setb   %r11b
 29efff1:	cmp    $0x100000,%r9
 29efff8:	setb   %r12b
 29efffc:	lea    0x8(%rax,%rax,1),%rcx
 29f0001:	mov    %rax,0x90(%rsp)
 29f0009:	cmp    %rcx,%r9
 29f000c:	setbe  %al
 29f000f:	and    %eax,%r12d
 29f0012:	or     %r12d,%r11d
 29f0015:	test   %r11b,%r11b
 29f0018:	jne    29f0028 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x208>
 29f001e:	mov    %r9,0x68(%rsp)
 29f0023:	jmp    29f13c8 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x15a8>
 29f0028:	mov    (%rsp),%ebx
 29f002b:	mov    %rbx,0x88(%rsp)
 29f0033:	mov    0x28(%rsp),%esi
 29f0037:	mov    0x20(%rsp),%edx
 29f003b:	cmp    %r15,%r9
 29f003e:	mov    %r9,0x68(%rsp)
 29f0043:	jae    29f0056 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x236>
 29f0049:	mov    0x80(%rsp),%r14
 29f0051:	jmp    29f0bd0 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0xdb0>
 29f0056:	test   %r14d,%r14d
 29f0059:	jne    29f0065 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x245>
 29f005f:	mov    $0x4,%r14d
 29f0065:	mov    %edi,0x30(%rsp)
 29f0069:	mov    0x80(%rsp),%rax
 29f0071:	mov    %eax,0x18(%rsp)
 29f0075:	mov    %r8d,0x58(%rsp)
 29f007a:	mov    0x88(%rsp),%rbx
 29f0082:	mov    %ebx,0x20(%rsp)
 29f0086:	mov    %esi,0x28(%rsp)
 29f008a:	mov    %edx,(%rsp)
 29f008d:	mov    0xd8(%rsp),%r13
 29f0095:	mov    0x0(%r13),%rax
 29f0099:	mov    0x98(%rsp),%rcx
 29f00a1:	cmp    %rcx,%rax
 29f00a4:	jae    29f26d0 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x28b0>
 29f00aa:	mov    %r14d,%r12d
 29f00ad:	mov    0x68(%rsp),%rcx
 29f00b2:	cmp    %r12,%rcx
 29f00b5:	jb     29f00eb <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2cb>
 29f00bb:	mov    0x30(%rsp),%edi
 29f00bf:	mov    0x18(%rsp),%esi
 29f00c3:	mov    %rsi,0x80(%rsp)
 29f00cb:	mov    0x58(%rsp),%r8d
 29f00d0:	mov    0x20(%rsp),%ebx
 29f00d4:	mov    %rbx,0x88(%rsp)
 29f00dc:	mov    0x28(%rsp),%esi
 29f00e0:	mov    (%rsp),%edx
 29f00e3:	shl    $1,%r14d
 29f00e6:	jmp    29f0065 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x245>
 29f00eb:	mov    %r12,%rcx
 29f00ee:	shl    $0x3,%rcx
 29f00f2:	mov    %rcx,%rax
 29f00f5:	shr    $0x20,%rax
 29f00f9:	mov    %rcx,%rbx
 29f00fc:	test   %rax,%rax
 29f00ff:	jne    29f2d37 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2f17>
 29f0105:	mov    %r14,%rcx
 29f0108:	shl    $0x3,%ecx
 29f010b:	add    $0x18,%ecx
 29f010e:	jb     29f2d39 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2f19>
 29f0114:	mov    0x60(%rsp),%rsi
 29f0119:	mov    0x20(%rsi),%rdi
 29f011d:	mov    (%rdi),%eax
 29f011f:	mov    %eax,%edx
 29f0121:	mov    %ecx,%esi
 29f0123:	add    $0xf,%rsi
 29f012a:	mov    %rsi,%r8
 29f012d:	and    $0xfffffffffffffff0,%r8
 29f0131:	add    %rdx,%r8
 29f0134:	mov    0x4(%rdi),%r9d
 29f0138:	mov    %rdi,0xc8(%rsp)
 29f0140:	cmp    %r9,%r8
 29f0143:	ja     29f2704 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x28e4>
 29f0149:	add    $0xf,%ecx
 29f014f:	and    $0xfffffff0,%ecx
 29f0152:	add    %eax,%ecx
 29f0154:	mov    0xc8(%rsp),%r13
 29f015c:	mov    %ecx,0x0(%r13)
 29f0160:	mov    0xd0(%rsp),%r13
 29f0168:	mov    0x20(%r13),%rdi
 29f016c:	lea    (%rdi,%rdx,1),%rcx
 29f0170:	movl   $0xa8000006,(%rdi,%rdx,1)
 29f0177:	mov    0x60(%rsp),%r8
 29f017c:	mov    0x28(%r8),%r8
 29f0180:	mov    0x1a0(%r8),%r8d
 29f0187:	mov    %r8d,0x4(%rdi,%rdx,1)
 29f018c:	and    $0xfffffffffffffff0,%rsi
 29f0190:	mov    %esi,0x8(%rdi,%rdx,1)
 29f0194:	mov    %eax,0x10(%rsp)
 29f0198:	mov    %r14d,0x10(%rcx)
 29f019c:	test   %eax,%eax
 29f019e:	je     29f2d3b <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2f1b>
 29f01a4:	mov    0xd0(%rsp),%r13
 29f01ac:	mov    0x28(%r13),%rcx
 29f01b0:	mov    0x20(%r13),%rdx
 29f01b4:	mov    %eax,%esi
 29f01b6:	lea    0x10(%rdx,%rsi,1),%rax
 29f01bb:	xor    %rdi,%rdi
 29f01be:	cmp    %rcx,%rsi
 29f01c1:	cmova  %rdi,%rax
 29f01c5:	mov    (%rax),%edi
 29f01c7:	cmp    %rdi,%r12
 29f01ca:	ja     29f2d3d <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2f1d>
 29f01d0:	lea    0x18(%rdx,%rsi,1),%rax
 29f01d5:	mov    %rbx,%r9
 29f01d8:	mov    %rax,%rsi
 29f01db:	add    %r9,%rsi
 29f01de:	mov    %rax,%r12
 29f01e1:	jb     29f2d3f <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2f1f>
 29f01e7:	lea    (%rdx,%rcx,1),%rdi
 29f01eb:	cmp    %rdi,%rsi
 29f01ee:	ja     29f2d41 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2f21>
 29f01f4:	mov    0x30(%rsp),%r8d
 29f01f9:	mov    0x18(%rsp),%edi
 29f01fd:	mov    0x58(%rsp),%esi
 29f0201:	mov    0x20(%rsp),%edx
 29f0205:	mov    0x28(%rsp),%ecx
 29f0209:	mov    (%rsp),%eax
 29f020c:	cmp    $0x8000000,%r9
 29f0213:	jbe    29f02a4 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x484>
 29f0219:	mov    %r8d,(%rsp)
 29f021d:	mov    %edi,0x28(%rsp)
 29f0221:	mov    %esi,0x20(%rsp)
 29f0225:	mov    %edx,0x58(%rsp)
 29f0229:	mov    %ecx,0x18(%rsp)
 29f022d:	mov    %eax,0x30(%rsp)
 29f0231:	mov    0xd8(%rsp),%r13
 29f0239:	mov    0x0(%r13),%rax
 29f023d:	mov    0x98(%rsp),%rcx
 29f0245:	cmp    %rcx,%rax
 29f0248:	jae    29f273b <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x291b>
 29f024e:	xor    %edx,%edx
 29f0250:	mov    $0x8000000,%ecx
 29f0255:	mov    %r12,%rsi
 29f0258:	mov    0x60(%rsp),%rdi
 29f025d:	call   3039b13 <wasmtime_builtin_memory_fill>
 29f0262:	mov    (%rsp),%r8d
 29f0266:	mov    0x28(%rsp),%edi
 29f026a:	mov    0x20(%rsp),%esi
 29f026e:	mov    0x58(%rsp),%edx
 29f0272:	mov    0x18(%rsp),%ecx
 29f0276:	mov    0x30(%rsp),%eax
 29f027a:	mov    %rbx,%r9
 29f027d:	sub    $0x8000000,%r9
 29f0284:	mov    %r9,%rbx
 29f0287:	mov    %r12,%r9
 29f028a:	add    $0x8000000,%r9
 29f0291:	mov    %r9,%r12
 29f0294:	mov    %rbx,%r9
 29f0297:	cmp    $0x8000000,%r9
 29f029e:	ja     29f0219 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x3f9>
 29f02a4:	mov    %r8d,0x30(%rsp)
 29f02a9:	mov    %edi,0x18(%rsp)
 29f02ad:	mov    %esi,0x58(%rsp)
 29f02b1:	mov    %edx,0x20(%rsp)
 29f02b5:	mov    %ecx,0x28(%rsp)
 29f02b9:	mov    %eax,(%rsp)
 29f02bc:	mov    0xd8(%rsp),%r13
 29f02c4:	mov    0x0(%r13),%rax
 29f02c8:	mov    0x98(%rsp),%rsi
 29f02d0:	cmp    %rsi,%rax
 29f02d3:	jae    29f276f <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x294f>
 29f02d9:	xor    %edx,%edx
 29f02db:	mov    %rbx,%rcx
 29f02de:	mov    %r12,%rsi
 29f02e1:	mov    0x60(%rsp),%rdi
 29f02e6:	call   3039b13 <wasmtime_builtin_memory_fill>
 29f02eb:	mov    0x10(%rsp),%edx
 29f02ef:	test   %edx,%edx
 29f02f1:	je     29f2d43 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2f23>
 29f02f7:	mov    0x30(%rsp),%esi
 29f02fb:	test   %esi,%esi
 29f02fd:	je     29f2d45 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2f25>
 29f0303:	test   %edx,%edx
 29f0305:	je     29f2d47 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2f27>
 29f030b:	mov    0xd0(%rsp),%r13
 29f0313:	mov    0x28(%r13),%rcx
 29f0317:	mov    0x20(%r13),%rax
 29f031b:	mov    %edx,%edx
 29f031d:	lea    (%rax,%rdx,1),%r9
 29f0321:	lea    0x10(%rax,%rdx,1),%r8
 29f0326:	xor    %rdi,%rdi
 29f0329:	cmp    %rcx,%rdx
 29f032c:	cmova  %rdi,%r8
 29f0330:	mov    (%r8),%r8d
 29f0333:	cmp    %r8,%r15
 29f0336:	ja     29f2d49 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2f29>
 29f033c:	test   %esi,%esi
 29f033e:	je     29f2d4b <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2f2b>
 29f0344:	mov    %esi,%esi
 29f0346:	lea    (%rax,%rsi,1),%r10
 29f034a:	lea    0x10(%rax,%rsi,1),%r8
 29f034f:	cmp    %rcx,%rsi
 29f0352:	cmova  %rdi,%r8
 29f0356:	mov    (%r8),%edi
 29f0359:	cmp    %rdi,%r15
 29f035c:	ja     29f2d4d <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2f2d>
 29f0362:	lea    0x18(%rax,%rdx,1),%r12
 29f0367:	mov    %r15,%r11
 29f036a:	shl    $0x3,%r11
 29f036e:	mov    %r12,%rdx
 29f0371:	add    %r11,%rdx
 29f0374:	jb     29f2d4f <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2f2f>
 29f037a:	add    %rax,%rcx
 29f037d:	cmp    %rcx,%rdx
 29f0380:	ja     29f2d51 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2f31>
 29f0386:	lea    0x18(%rax,%rsi,1),%r13
 29f038b:	mov    %r13,%rax
 29f038e:	add    %r11,%rax
 29f0391:	jb     29f2d53 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2f33>
 29f0397:	cmp    %rcx,%rax
 29f039a:	ja     29f2d55 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2f35>
 29f03a0:	cmp    %r12,%r13
 29f03a3:	ja     29f049a <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x67a>
 29f03a9:	mov    0x18(%rsp),%eax
 29f03ad:	mov    0x58(%rsp),%ecx
 29f03b1:	mov    0x10(%rsp),%edx
 29f03b5:	mov    0x20(%rsp),%esi
 29f03b9:	mov    0x28(%rsp),%edi
 29f03bd:	mov    (%rsp),%r8d
 29f03c1:	lea    0x18(%r9,%r15,8),%r12
 29f03c6:	lea    0x18(%r10,%r15,8),%r13
 29f03cb:	mov    %r13,%r15
 29f03ce:	cmp    $0x8000000,%r11
 29f03d5:	mov    %r11,%rbx
 29f03d8:	ja     29f03e9 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x5c9>
 29f03de:	mov    %rbx,%r9
 29f03e1:	mov    %r12,%r10
 29f03e4:	jmp    29f0483 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x663>
 29f03e9:	mov    %eax,0x8(%rsp)
 29f03ed:	mov    %ecx,0x50(%rsp)
 29f03f1:	mov    %edx,0x48(%rsp)
 29f03f5:	mov    %esi,0x40(%rsp)
 29f03f9:	mov    %edi,0x38(%rsp)
 29f03fd:	mov    %r8d,0x30(%rsp)
 29f0402:	mov    0xd8(%rsp),%r13
 29f040a:	mov    0x0(%r13),%rax
 29f040e:	mov    0x98(%rsp),%rcx
 29f0416:	cmp    %rcx,%rax
 29f0419:	jae    29f27a6 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2986>
 29f041f:	mov    $0x8000000,%ecx
 29f0424:	mov    %r12,%rsi
 29f0427:	sub    $0x8000000,%rsi
 29f042e:	mov    %r15,%rdx
 29f0431:	mov    %rsi,%r12
 29f0434:	sub    $0x8000000,%rdx
 29f043b:	mov    %rdx,%r15
 29f043e:	mov    0x60(%rsp),%rdi
 29f0443:	call   3039aea <wasmtime_builtin_memory_copy>
 29f0448:	mov    0x8(%rsp),%eax
 29f044c:	mov    0x50(%rsp),%ecx
 29f0450:	mov    0x48(%rsp),%edx
 29f0454:	mov    0x40(%rsp),%esi
 29f0458:	mov    0x38(%rsp),%edi
 29f045c:	mov    0x30(%rsp),%r8d
 29f0461:	mov    %rbx,%r9
 29f0464:	sub    $0x8000000,%r9
 29f046b:	cmp    $0x8000000,%r9
 29f0472:	jbe    29f0480 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x660>
 29f0478:	mov    %r9,%rbx
 29f047b:	jmp    29f03e9 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x5c9>
 29f0480:	mov    %r12,%r10
 29f0483:	sub    %r9,%r10
 29f0486:	mov    %r10,%r12
 29f0489:	mov    %r15,%r10
 29f048c:	sub    %r9,%r10
 29f048f:	mov    %r10,%r15
 29f0492:	mov    %r9,%rbx
 29f0495:	jmp    29f0561 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x741>
 29f049a:	mov    %r11,%r9
 29f049d:	mov    %r13,%r15
 29f04a0:	mov    0x18(%rsp),%eax
 29f04a4:	mov    0x58(%rsp),%ecx
 29f04a8:	mov    0x10(%rsp),%edx
 29f04ac:	mov    0x20(%rsp),%esi
 29f04b0:	mov    0x28(%rsp),%edi
 29f04b4:	mov    (%rsp),%r8d
 29f04b8:	cmp    $0x8000000,%r9
 29f04bf:	mov    %r9,%rbx
 29f04c2:	jbe    29f0561 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x741>
 29f04c8:	mov    %eax,(%rsp)
 29f04cb:	mov    %ecx,0x28(%rsp)
 29f04cf:	mov    %edx,0x20(%rsp)
 29f04d3:	mov    %esi,0x10(%rsp)
 29f04d7:	mov    %edi,0x58(%rsp)
 29f04db:	mov    %r8d,0x18(%rsp)
 29f04e0:	mov    0xd8(%rsp),%r13
 29f04e8:	mov    0x0(%r13),%rax
 29f04ec:	mov    0x98(%rsp),%rsi
 29f04f4:	cmp    %rsi,%rax
 29f04f7:	jae    29f27da <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x29ba>
 29f04fd:	mov    $0x8000000,%ecx
 29f0502:	mov    %r15,%rdx
 29f0505:	mov    %r12,%rsi
 29f0508:	mov    0x60(%rsp),%rdi
 29f050d:	call   3039aea <wasmtime_builtin_memory_copy>
 29f0512:	mov    (%rsp),%eax
 29f0515:	mov    0x28(%rsp),%ecx
 29f0519:	mov    0x20(%rsp),%edx
 29f051d:	mov    0x10(%rsp),%esi
 29f0521:	mov    0x58(%rsp),%edi
 29f0525:	mov    0x18(%rsp),%r8d
 29f052a:	mov    %rbx,%r9
 29f052d:	sub    $0x8000000,%r9
 29f0534:	mov    %r9,%rbx
 29f0537:	mov    %r12,%r9
 29f053a:	add    $0x8000000,%r9
 29f0541:	mov    %r9,%r12
 29f0544:	mov    %r15,%r9
 29f0547:	add    $0x8000000,%r9
 29f054e:	mov    %r9,%r15
 29f0551:	mov    %rbx,%r9
 29f0554:	cmp    $0x8000000,%r9
 29f055b:	ja     29f04c8 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x6a8>
 29f0561:	mov    %eax,0x18(%rsp)
 29f0565:	mov    %ecx,0x58(%rsp)
 29f0569:	mov    %edx,0x10(%rsp)
 29f056d:	mov    %esi,0x20(%rsp)
 29f0571:	mov    %edi,0x28(%rsp)
 29f0575:	mov    %r8d,(%rsp)
 29f0579:	mov    0xd8(%rsp),%r13
 29f0581:	mov    0x0(%r13),%rax
 29f0585:	mov    0x98(%rsp),%rcx
 29f058d:	cmp    %rcx,%rax
 29f0590:	jae    29f2811 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x29f1>
 29f0596:	mov    %rbx,%rcx
 29f0599:	mov    %r15,%rdx
 29f059c:	mov    %r12,%rsi
 29f059f:	jmp    29f05ad <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x78d>
 29f05a4:	mov    %rbx,%rcx
 29f05a7:	mov    %r15,%rdx
 29f05aa:	mov    %r12,%rsi
 29f05ad:	mov    %rbx,%rcx
 29f05b0:	mov    %r15,%rdx
 29f05b3:	mov    %r12,%rsi
 29f05b6:	mov    0x60(%rsp),%rdi
 29f05bb:	call   3039aea <wasmtime_builtin_memory_copy>
 29f05c0:	mov    0x18(%rsp),%eax
 29f05c4:	mov    %rax,%rcx
 29f05c7:	mov    %rax,0x80(%rsp)
 29f05cf:	test   %ecx,%eax
 29f05d1:	je     29f2d57 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2f37>
 29f05d7:	mov    0x80(%rsp),%rcx
 29f05df:	test   %ecx,%eax
 29f05e1:	je     29f2d59 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2f39>
 29f05e7:	mov    0xd0(%rsp),%r13
 29f05ef:	mov    0x28(%r13),%rdx
 29f05f3:	mov    %eax,%esi
 29f05f5:	mov    %rsi,%rax
 29f05f8:	add    0x20(%r13),%rax
 29f05fc:	xor    %rdi,%rdi
 29f05ff:	cmp    %rdx,%rsi
 29f0602:	cmova  %rdi,%rax
 29f0606:	mov    0x24(%rax),%r9d
 29f060a:	mov    0x10(%rsp),%edi
 29f060e:	mov    0x58(%rsp),%r8d
 29f0613:	mov    0x20(%rsp),%ebx
 29f0617:	mov    %rbx,0x88(%rsp)
 29f061f:	mov    0x28(%rsp),%esi
 29f0623:	mov    (%rsp),%edx
 29f0626:	cmp    $0x2,%r9d
 29f062a:	je     29f0645 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x825>
 29f0630:	mov    0x80(%rsp),%rax
 29f0638:	mov    0x80(%rsp),%r14
 29f0640:	jmp    29f0b82 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0xd62>
 29f0645:	lea    0x3f(%r14),%r12d
 29f0649:	shr    $0x6,%r12d
 29f064d:	mov    %r12,%rcx
 29f0650:	shl    $0x3,%rcx
 29f0654:	mov    %rcx,%rsi
 29f0657:	shr    $0x20,%rsi
 29f065b:	mov    %rcx,%rbx
 29f065e:	test   %rsi,%rsi
 29f0661:	jne    29f2d5b <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2f3b>
 29f0667:	mov    %r12,%rcx
 29f066a:	shl    $0x3,%ecx
 29f066d:	add    $0x18,%ecx
 29f0670:	jb     29f2d5d <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2f3d>
 29f0676:	mov    0xc8(%rsp),%rdx
 29f067e:	mov    (%rdx),%eax
 29f0680:	mov    %eax,%r9d
 29f0683:	mov    %ecx,%r10d
 29f0686:	lea    0xf(%r10),%r8
 29f068a:	and    $0xfffffffffffffff0,%r8
 29f068e:	lea    (%r9,%r8,1),%r10
 29f0692:	mov    0x4(%rdx),%r11d
 29f0696:	cmp    %r11,%r10
 29f0699:	ja     29f284e <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2a2e>
 29f069f:	lea    0xf(%rcx),%r11d
 29f06a3:	and    $0xfffffff0,%r11d
 29f06a7:	lea    (%rax,%r11,1),%ecx
 29f06ab:	mov    %ecx,(%rdx)
 29f06ad:	mov    0xd0(%rsp),%r13
 29f06b5:	mov    0x20(%r13),%rdx
 29f06b9:	lea    (%rdx,%r9,1),%rcx
 29f06bd:	movl   $0xa8000006,(%rdx,%r9,1)
 29f06c5:	mov    0x60(%rsp),%rsi
 29f06ca:	mov    0x28(%rsi),%rsi
 29f06ce:	mov    0x1a4(%rsi),%esi
 29f06d4:	mov    %esi,0x4(%rdx,%r9,1)
 29f06d9:	mov    %r8d,0x8(%rdx,%r9,1)
 29f06de:	mov    %eax,0x8(%rsp)
 29f06e2:	mov    %r12d,0x10(%rcx)
 29f06e6:	test   %eax,%eax
 29f06e8:	je     29f2d5f <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2f3f>
 29f06ee:	mov    0xd0(%rsp),%r13
 29f06f6:	mov    0x28(%r13),%rcx
 29f06fa:	mov    0x20(%r13),%rdx
 29f06fe:	mov    %eax,%eax
 29f0700:	lea    0x10(%rdx,%rax,1),%rsi
 29f0705:	xor    %rdi,%rdi
 29f0708:	cmp    %rcx,%rax
 29f070b:	cmova  %rdi,%rsi
 29f070f:	mov    (%rsi),%esi
 29f0711:	cmp    %rsi,%r12
 29f0714:	ja     29f2d61 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2f41>
 29f071a:	lea    0x18(%rdx,%rax,1),%rsi
 29f071f:	mov    %rbx,%r8
 29f0722:	mov    %rsi,%rax
 29f0725:	add    %r8,%rax
 29f0728:	mov    %rsi,%r12
 29f072b:	jb     29f2d63 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2f43>
 29f0731:	add    %rdx,%rcx
 29f0734:	cmp    %rcx,%rax
 29f0737:	ja     29f2d65 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2f45>
 29f073d:	mov    0x58(%rsp),%r10d
 29f0742:	mov    0x18(%rsp),%edi
 29f0746:	mov    0x10(%rsp),%esi
 29f074a:	mov    0x20(%rsp),%edx
 29f074e:	mov    0x28(%rsp),%ecx
 29f0752:	mov    (%rsp),%eax
 29f0755:	cmp    $0x8000000,%r8
 29f075c:	jbe    29f07ed <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x9cd>
 29f0762:	mov    %r10d,(%rsp)
 29f0766:	mov    %edi,0x28(%rsp)
 29f076a:	mov    %esi,0x20(%rsp)
 29f076e:	mov    %edx,0x10(%rsp)
 29f0772:	mov    %ecx,0x18(%rsp)
 29f0776:	mov    %eax,0x58(%rsp)
 29f077a:	mov    0xd8(%rsp),%r13
 29f0782:	mov    0x0(%r13),%rax
 29f0786:	mov    0x98(%rsp),%rcx
 29f078e:	cmp    %rcx,%rax
 29f0791:	jae    29f2886 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2a66>
 29f0797:	xor    %edx,%edx
 29f0799:	mov    $0x8000000,%ecx
 29f079e:	mov    %r12,%rsi
 29f07a1:	mov    0x60(%rsp),%rdi
 29f07a6:	call   3039b13 <wasmtime_builtin_memory_fill>
 29f07ab:	mov    (%rsp),%r10d
 29f07af:	mov    0x28(%rsp),%edi
 29f07b3:	mov    0x20(%rsp),%esi
 29f07b7:	mov    0x10(%rsp),%edx
 29f07bb:	mov    0x18(%rsp),%ecx
 29f07bf:	mov    0x58(%rsp),%eax
 29f07c3:	mov    %rbx,%r8
 29f07c6:	sub    $0x8000000,%r8
 29f07cd:	mov    %r8,%rbx
 29f07d0:	mov    %r12,%r8
 29f07d3:	add    $0x8000000,%r8
 29f07da:	mov    %r8,%r12
 29f07dd:	mov    %rbx,%r8
 29f07e0:	cmp    $0x8000000,%r8
 29f07e7:	ja     29f0762 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x942>
 29f07ed:	mov    %r10d,0x58(%rsp)
 29f07f2:	mov    %edi,0x18(%rsp)
 29f07f6:	mov    %esi,0x10(%rsp)
 29f07fa:	mov    %edx,0x20(%rsp)
 29f07fe:	mov    %ecx,0x28(%rsp)
 29f0802:	mov    %eax,(%rsp)
 29f0805:	mov    0xd8(%rsp),%r13
 29f080d:	mov    0x0(%r13),%rax
 29f0811:	mov    0x98(%rsp),%rcx
 29f0819:	cmp    %rcx,%rax
 29f081c:	jae    29f28ba <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2a9a>
 29f0822:	xor    %edx,%edx
 29f0824:	mov    %rbx,%rcx
 29f0827:	mov    %r12,%rsi
 29f082a:	mov    0x60(%rsp),%rdi
 29f082f:	call   3039b13 <wasmtime_builtin_memory_fill>
 29f0834:	mov    0x58(%rsp),%eax
 29f0838:	test   %eax,%eax
 29f083a:	je     29f2d67 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2f47>
 29f0840:	test   %eax,%eax
 29f0842:	je     29f2d69 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2f49>
 29f0848:	mov    0xd0(%rsp),%r13
 29f0850:	mov    0x28(%r13),%r9
 29f0854:	mov    0x20(%r13),%rsi
 29f0858:	mov    %eax,%edi
 29f085a:	lea    (%rsi,%rdi,1),%r8
 29f085e:	lea    0x10(%rsi,%rdi,1),%rcx
 29f0863:	xor    %r10,%r10
 29f0866:	cmp    %r9,%rdi
 29f0869:	cmova  %r10,%rcx
 29f086d:	mov    (%rcx),%eax
 29f086f:	mov    0x8(%rsp),%r11d
 29f0874:	test   %r11d,%r11d
 29f0877:	je     29f2d6b <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2f4b>
 29f087d:	test   %r11d,%r11d
 29f0880:	je     29f2d6d <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2f4d>
 29f0886:	mov    %r11d,%ecx
 29f0889:	lea    (%rsi,%rcx,1),%r11
 29f088d:	lea    0x10(%rsi,%rcx,1),%rdx
 29f0892:	cmp    %r9,%rcx
 29f0895:	cmova  %r10,%rdx
 29f0899:	mov    %eax,%r12d
 29f089c:	mov    (%rdx),%r10d
 29f089f:	cmp    %r10,%r12
 29f08a2:	ja     29f2d6f <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2f4f>
 29f08a8:	lea    0x18(%rsi,%rcx,1),%r15
 29f08ad:	mov    %r12,%r14
 29f08b0:	shl    $0x3,%r14
 29f08b4:	mov    %r15,%rcx
 29f08b7:	add    %r14,%rcx
 29f08ba:	jb     29f2d71 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2f51>
 29f08c0:	lea    (%rsi,%r9,1),%rax
 29f08c4:	cmp    %rax,%rcx
 29f08c7:	ja     29f2d73 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2f53>
 29f08cd:	lea    0x18(%rsi,%rdi,1),%r9
 29f08d2:	mov    %r9,%rcx
 29f08d5:	add    %r14,%rcx
 29f08d8:	jb     29f2d75 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2f55>
 29f08de:	cmp    %rax,%rcx
 29f08e1:	ja     29f2d77 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2f57>
 29f08e7:	cmp    %r15,%r9
 29f08ea:	ja     29f09e1 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0xbc1>
 29f08f0:	mov    0x18(%rsp),%r10d
 29f08f5:	mov    0x8(%rsp),%eax
 29f08f9:	mov    0x10(%rsp),%ecx
 29f08fd:	mov    0x20(%rsp),%edx
 29f0901:	mov    0x28(%rsp),%esi
 29f0905:	mov    (%rsp),%edi
 29f0908:	lea    0x18(%r11,%r12,8),%r15
 29f090d:	lea    0x18(%r8,%r12,8),%r9
 29f0912:	mov    %r9,%r12
 29f0915:	cmp    $0x8000000,%r14
 29f091c:	mov    %r14,%rbx
 29f091f:	ja     29f0930 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0xb10>
 29f0925:	mov    %rbx,%r8
 29f0928:	mov    %r15,%r9
 29f092b:	jmp    29f09ca <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0xbaa>
 29f0930:	mov    %r10d,0x30(%rsp)
 29f0935:	mov    %eax,0x38(%rsp)
 29f0939:	mov    %ecx,0x40(%rsp)
 29f093d:	mov    %edx,0x48(%rsp)
 29f0941:	mov    %esi,0x50(%rsp)
 29f0945:	mov    %edi,0x58(%rsp)
 29f0949:	mov    0xd8(%rsp),%r13
 29f0951:	mov    0x0(%r13),%rax
 29f0955:	mov    0x98(%rsp),%rcx
 29f095d:	cmp    %rcx,%rax
 29f0960:	jae    29f28ee <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2ace>
 29f0966:	mov    $0x8000000,%ecx
 29f096b:	mov    %r15,%rsi
 29f096e:	sub    $0x8000000,%rsi
 29f0975:	mov    %r12,%rdx
 29f0978:	mov    %rsi,%r15
 29f097b:	sub    $0x8000000,%rdx
 29f0982:	mov    %rdx,%r12
 29f0985:	mov    0x60(%rsp),%rdi
 29f098a:	call   3039aea <wasmtime_builtin_memory_copy>
 29f098f:	mov    0x30(%rsp),%r10d
 29f0994:	mov    0x38(%rsp),%eax
 29f0998:	mov    0x40(%rsp),%ecx
 29f099c:	mov    0x48(%rsp),%edx
 29f09a0:	mov    0x50(%rsp),%esi
 29f09a4:	mov    0x58(%rsp),%edi
 29f09a8:	mov    %rbx,%r8
 29f09ab:	sub    $0x8000000,%r8
 29f09b2:	cmp    $0x8000000,%r8
 29f09b9:	jbe    29f09c7 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0xba7>
 29f09bf:	mov    %r8,%rbx
 29f09c2:	jmp    29f0930 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0xb10>
 29f09c7:	mov    %r15,%r9
 29f09ca:	sub    %r8,%r9
 29f09cd:	mov    %r9,%r15
 29f09d0:	mov    %r12,%r9
 29f09d3:	sub    %r8,%r9
 29f09d6:	mov    %r9,%r12
 29f09d9:	mov    %r8,%rbx
 29f09dc:	jmp    29f0aa8 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0xc88>
 29f09e1:	mov    %r14,%r8
 29f09e4:	mov    %r9,%r12
 29f09e7:	mov    0x18(%rsp),%r10d
 29f09ec:	mov    0x8(%rsp),%eax
 29f09f0:	mov    0x10(%rsp),%ecx
 29f09f4:	mov    0x20(%rsp),%edx
 29f09f8:	mov    0x28(%rsp),%esi
 29f09fc:	mov    (%rsp),%edi
 29f09ff:	cmp    $0x8000000,%r8
 29f0a06:	mov    %r8,%rbx
 29f0a09:	jbe    29f0aa8 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0xc88>
 29f0a0f:	mov    %r10d,(%rsp)
 29f0a13:	mov    %eax,0x28(%rsp)
 29f0a17:	mov    %ecx,0x20(%rsp)
 29f0a1b:	mov    %edx,0x10(%rsp)
 29f0a1f:	mov    %esi,0x8(%rsp)
 29f0a23:	mov    %edi,0x18(%rsp)
 29f0a27:	mov    0xd8(%rsp),%r13
 29f0a2f:	mov    0x0(%r13),%rax
 29f0a33:	mov    0x98(%rsp),%rcx
 29f0a3b:	cmp    %rcx,%rax
 29f0a3e:	jae    29f2922 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2b02>
 29f0a44:	mov    $0x8000000,%ecx
 29f0a49:	mov    %r12,%rdx
 29f0a4c:	mov    %r15,%rsi
 29f0a4f:	mov    0x60(%rsp),%rdi
 29f0a54:	call   3039aea <wasmtime_builtin_memory_copy>
 29f0a59:	mov    (%rsp),%r10d
 29f0a5d:	mov    0x28(%rsp),%eax
 29f0a61:	mov    0x20(%rsp),%ecx
 29f0a65:	mov    0x10(%rsp),%edx
 29f0a69:	mov    0x8(%rsp),%esi
 29f0a6d:	mov    0x18(%rsp),%edi
 29f0a71:	mov    %rbx,%r8
 29f0a74:	sub    $0x8000000,%r8
 29f0a7b:	mov    %r8,%rbx
 29f0a7e:	mov    %r15,%r8
 29f0a81:	add    $0x8000000,%r8
 29f0a88:	mov    %r8,%r15
 29f0a8b:	mov    %r12,%r8
 29f0a8e:	lea    0x8000000(%r8),%r9
 29f0a95:	mov    %rbx,%r8
 29f0a98:	mov    %r9,%r12
 29f0a9b:	cmp    $0x8000000,%r8
 29f0aa2:	ja     29f0a0f <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0xbef>
 29f0aa8:	mov    %r10d,0x18(%rsp)
 29f0aad:	mov    %eax,0x8(%rsp)
 29f0ab1:	mov    %ecx,0x10(%rsp)
 29f0ab5:	mov    %edx,0x20(%rsp)
 29f0ab9:	mov    %esi,0x28(%rsp)
 29f0abd:	mov    %edi,(%rsp)
 29f0ac0:	mov    0xd8(%rsp),%r13
 29f0ac8:	mov    0x0(%r13),%r8
 29f0acc:	mov    0x98(%rsp),%rax
 29f0ad4:	cmp    %rax,%r8
 29f0ad7:	jae    29f2956 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2b36>
 29f0add:	mov    %rbx,%rcx
 29f0ae0:	mov    %r12,%rdx
 29f0ae3:	mov    %r15,%rsi
 29f0ae6:	jmp    29f0af4 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0xcd4>
 29f0aeb:	mov    %rbx,%rcx
 29f0aee:	mov    %r12,%rdx
 29f0af1:	mov    %r15,%rsi
 29f0af4:	mov    %rbx,%rcx
 29f0af7:	mov    %r12,%rdx
 29f0afa:	mov    %r15,%rsi
 29f0afd:	mov    0x60(%rsp),%rdi
 29f0b02:	call   3039aea <wasmtime_builtin_memory_copy>
 29f0b07:	mov    0x18(%rsp),%r14d
 29f0b0c:	mov    %r14,%r11
 29f0b0f:	mov    %r14,0x80(%rsp)
 29f0b17:	test   %r11d,%r14d
 29f0b1a:	je     29f2d79 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2f59>
 29f0b20:	mov    0x8(%rsp),%r8d
 29f0b25:	test   %r8d,%r8d
 29f0b28:	je     29f2d7b <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2f5b>
 29f0b2e:	mov    0x80(%rsp),%rax
 29f0b36:	test   %eax,%r14d
 29f0b39:	je     29f2d7d <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2f5d>
 29f0b3f:	mov    0xd0(%rsp),%r13
 29f0b47:	mov    0x28(%r13),%rax
 29f0b4b:	mov    %r14d,%esi
 29f0b4e:	mov    %rsi,%rdx
 29f0b51:	add    0x20(%r13),%rdx
 29f0b55:	xor    %rdi,%rdi
 29f0b58:	cmp    %rax,%rsi
 29f0b5b:	cmova  %rdi,%rdx
 29f0b5f:	mov    %r8d,0x2c(%rdx)
 29f0b63:	mov    0x10(%rsp),%edi
 29f0b67:	mov    0x20(%rsp),%ebx
 29f0b6b:	mov    %rbx,0x88(%rsp)
 29f0b73:	mov    0x28(%rsp),%esi
 29f0b77:	mov    (%rsp),%edx
 29f0b7a:	mov    0x80(%rsp),%rax
 29f0b82:	test   %eax,%r14d
 29f0b85:	je     29f2d7f <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2f5f>
 29f0b8b:	test   %edi,%edi
 29f0b8d:	je     29f2d81 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2f61>
 29f0b93:	mov    0x80(%rsp),%rax
 29f0b9b:	mov    0x80(%rsp),%r14
 29f0ba3:	test   %eax,%r14d
 29f0ba6:	je     29f2d83 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2f63>
 29f0bac:	mov    0xd0(%rsp),%r13
 29f0bb4:	mov    0x28(%r13),%rax
 29f0bb8:	mov    %r14d,%r10d
 29f0bbb:	mov    %r10,%r9
 29f0bbe:	add    0x20(%r13),%r9
 29f0bc2:	xor    %r11,%r11
 29f0bc5:	cmp    %rax,%r10
 29f0bc8:	cmova  %r11,%r9
 29f0bcc:	mov    %edi,0x28(%r9)
 29f0bd0:	mov    %r14d,0x28(%rsp)
 29f0bd5:	mov    %edi,0x20(%rsp)
 29f0bd9:	mov    0x88(%rsp),%rbx
 29f0be1:	mov    %ebx,0x8(%rsp)
 29f0be5:	mov    %esi,0x10(%rsp)
 29f0be9:	mov    %edx,0x18(%rsp)
 29f0bed:	mov    0x90(%rsp),%rax
 29f0bf5:	mov    0x68(%rsp),%rcx
 29f0bfa:	cmp    %rax,%rcx
 29f0bfd:	ja     29f0c18 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0xdf8>
 29f0c03:	mov    0x80(%rsp),%rax
 29f0c0b:	mov    0x80(%rsp),%r14
 29f0c13:	jmp    29f10e0 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x12c0>
 29f0c18:	mov    0x80(%rsp),%r9
 29f0c20:	mov    0x80(%rsp),%r14
 29f0c28:	test   %r9d,%r14d
 29f0c2b:	je     29f2d85 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2f65>
 29f0c31:	test   %r9d,%r14d
 29f0c34:	je     29f2d87 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2f67>
 29f0c3a:	mov    0xd0(%rsp),%r13
 29f0c42:	mov    0x28(%r13),%rax
 29f0c46:	mov    %r14d,%r10d
 29f0c49:	mov    %r10,%r9
 29f0c4c:	add    0x20(%r13),%r9
 29f0c50:	xor    %r11,%r11
 29f0c53:	cmp    %rax,%r10
 29f0c56:	cmova  %r11,%r9
 29f0c5a:	mov    0x24(%r9),%eax
 29f0c5e:	cmp    $0x4,%eax
 29f0c61:	jne    29f10d0 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x12b0>
 29f0c67:	mov    0x20(%rsp),%eax
 29f0c6b:	test   %eax,%eax
 29f0c6d:	je     29f2d89 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2f69>
 29f0c73:	test   %eax,%eax
 29f0c75:	je     29f2d8b <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2f6b>
 29f0c7b:	mov    0xd0(%rsp),%r13
 29f0c83:	mov    0x28(%r13),%rcx
 29f0c87:	mov    0x20(%r13),%rsi
 29f0c8b:	mov    %eax,%edx
 29f0c8d:	lea    0x10(%rsi,%rdx,1),%rax
 29f0c92:	xor    %rsi,%rsi
 29f0c95:	cmp    %rcx,%rdx
 29f0c98:	cmova  %rsi,%rax
 29f0c9c:	mov    (%rax),%eax
 29f0c9e:	lea    0x3f(%rax),%r12d
 29f0ca2:	shr    $0x6,%r12d
 29f0ca6:	mov    %r12,%rcx
 29f0ca9:	shl    $0x3,%rcx
 29f0cad:	mov    %rcx,%rax
 29f0cb0:	shr    $0x20,%rax
 29f0cb4:	mov    %rcx,%rbx
 29f0cb7:	test   %rax,%rax
 29f0cba:	jne    29f2d8d <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2f6d>
 29f0cc0:	mov    %r12,%rcx
 29f0cc3:	shl    $0x3,%ecx
 29f0cc6:	add    $0x18,%ecx
 29f0cc9:	jb     29f2d8f <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2f6f>
 29f0ccf:	mov    0x60(%rsp),%rsi
 29f0cd4:	mov    0x20(%rsi),%rdi
 29f0cd8:	mov    (%rdi),%eax
 29f0cda:	mov    %eax,%edx
 29f0cdc:	mov    %ecx,%esi
 29f0cde:	add    $0xf,%rsi
 29f0ce5:	mov    %rsi,%r8
 29f0ce8:	and    $0xfffffffffffffff0,%r8
 29f0cec:	add    %rdx,%r8
 29f0cef:	mov    0x4(%rdi),%r9d
 29f0cf3:	cmp    %r9,%r8
 29f0cf6:	ja     29f2993 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2b73>
 29f0cfc:	add    $0xf,%ecx
 29f0d02:	and    $0xfffffff0,%ecx
 29f0d05:	add    %eax,%ecx
 29f0d07:	mov    %ecx,(%rdi)
 29f0d09:	mov    0xd0(%rsp),%r13
 29f0d11:	mov    0x20(%r13),%rcx
 29f0d15:	lea    (%rcx,%rdx,1),%rdi
 29f0d19:	movl   $0xa8000006,(%rcx,%rdx,1)
 29f0d20:	mov    0x60(%rsp),%r8
 29f0d25:	mov    0x28(%r8),%r8
 29f0d29:	mov    0x1a4(%r8),%r8d
 29f0d30:	mov    %r8d,0x4(%rcx,%rdx,1)
 29f0d35:	and    $0xfffffffffffffff0,%rsi
 29f0d39:	mov    %esi,0x8(%rcx,%rdx,1)
 29f0d3d:	mov    %eax,(%rsp)
 29f0d40:	mov    %r12d,0x10(%rdi)
 29f0d44:	test   %eax,%eax
 29f0d46:	je     29f2d91 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2f71>
 29f0d4c:	mov    0xd0(%rsp),%r13
 29f0d54:	mov    0x28(%r13),%rdi
 29f0d58:	mov    0x20(%r13),%r8
 29f0d5c:	mov    %eax,%r9d
 29f0d5f:	lea    0x10(%r8,%r9,1),%rsi
 29f0d64:	xor    %r10,%r10
 29f0d67:	cmp    %rdi,%r9
 29f0d6a:	cmova  %r10,%rsi
 29f0d6e:	mov    (%rsi),%r10d
 29f0d71:	cmp    %r10,%r12
 29f0d74:	ja     29f2d93 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2f73>
 29f0d7a:	lea    0x18(%r8,%r9,1),%rsi
 29f0d7f:	mov    %rbx,%r9
 29f0d82:	mov    %rsi,%r10
 29f0d85:	add    %r9,%r10
 29f0d88:	mov    %rsi,%r12
 29f0d8b:	jb     29f2d95 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2f75>
 29f0d91:	lea    (%r8,%rdi,1),%r11
 29f0d95:	cmp    %r11,%r10
 29f0d98:	ja     29f2d97 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2f77>
 29f0d9e:	mov    0x28(%rsp),%edi
 29f0da2:	mov    0x20(%rsp),%esi
 29f0da6:	mov    0x8(%rsp),%edx
 29f0daa:	mov    0x10(%rsp),%ecx
 29f0dae:	mov    0x18(%rsp),%eax
 29f0db2:	mov    $0x8000000,%r14d
 29f0db8:	cmp    $0x8000000,%r9
 29f0dbf:	jbe    29f0e46 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1026>
 29f0dc5:	mov    %edi,0x18(%rsp)
 29f0dc9:	mov    %esi,0x10(%rsp)
 29f0dcd:	mov    %edx,0x8(%rsp)
 29f0dd1:	mov    %ecx,0x20(%rsp)
 29f0dd5:	mov    %eax,0x28(%rsp)
 29f0dd9:	mov    0xd8(%rsp),%r13
 29f0de1:	mov    0x0(%r13),%rax
 29f0de5:	mov    0x98(%rsp),%r9
 29f0ded:	cmp    %r9,%rax
 29f0df0:	jae    29f29ca <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2baa>
 29f0df6:	xor    %edx,%edx
 29f0df8:	mov    %r14,%rcx
 29f0dfb:	mov    %r12,%rsi
 29f0dfe:	mov    0x60(%rsp),%rdi
 29f0e03:	call   3039b13 <wasmtime_builtin_memory_fill>
 29f0e08:	mov    0x18(%rsp),%edi
 29f0e0c:	mov    0x10(%rsp),%esi
 29f0e10:	mov    0x8(%rsp),%edx
 29f0e14:	mov    0x20(%rsp),%ecx
 29f0e18:	mov    0x28(%rsp),%eax
 29f0e1c:	mov    %rbx,%r8
 29f0e1f:	sub    $0x8000000,%r8
 29f0e26:	mov    %r8,%rbx
 29f0e29:	mov    %r12,%r8
 29f0e2c:	add    $0x8000000,%r8
 29f0e33:	mov    %r8,%r12
 29f0e36:	mov    %rbx,%r8
 29f0e39:	cmp    $0x8000000,%r8
 29f0e40:	ja     29f0dc5 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0xfa5>
 29f0e46:	mov    %edi,0x28(%rsp)
 29f0e4a:	mov    %esi,0x20(%rsp)
 29f0e4e:	mov    %edx,0x8(%rsp)
 29f0e52:	mov    %ecx,0x10(%rsp)
 29f0e56:	mov    %eax,0x18(%rsp)
 29f0e5a:	mov    0xd8(%rsp),%r13
 29f0e62:	mov    0x0(%r13),%rax
 29f0e66:	mov    0x98(%rsp),%rcx
 29f0e6e:	cmp    %rcx,%rax
 29f0e71:	jae    29f29fe <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2bde>
 29f0e77:	xor    %r14d,%r14d
 29f0e7a:	mov    %rbx,%rcx
 29f0e7d:	mov    %r12,%rsi
 29f0e80:	mov    %r14,%rdx
 29f0e83:	mov    0x60(%rsp),%rdi
 29f0e88:	call   3039b13 <wasmtime_builtin_memory_fill>
 29f0e8d:	mov    0x28(%rsp),%ecx
 29f0e91:	mov    0x20(%rsp),%edx
 29f0e95:	mov    0x8(%rsp),%esi
 29f0e99:	mov    0x10(%rsp),%edi
 29f0e9d:	mov    0x18(%rsp),%r8d
 29f0ea2:	mov    0x90(%rsp),%r13
 29f0eaa:	mov    %r13,%rbx
 29f0ead:	shr    $0x6,%rbx
 29f0eb1:	mov    %ecx,0x18(%rsp)
 29f0eb5:	mov    %edx,0x10(%rsp)
 29f0eb9:	mov    %esi,0x8(%rsp)
 29f0ebd:	mov    %edi,0x20(%rsp)
 29f0ec1:	mov    %r8d,0x28(%rsp)
 29f0ec6:	mov    0xd8(%rsp),%r13
 29f0ece:	mov    0x0(%r13),%rcx
 29f0ed2:	mov    0x98(%rsp),%rax
 29f0eda:	cmp    %rax,%rcx
 29f0edd:	jae    29f2a32 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2c12>
 29f0ee3:	cmp    %ebx,%r14d
 29f0ee6:	jae    29f0f9d <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x117d>
 29f0eec:	mov    (%rsp),%ecx
 29f0eef:	test   %ecx,%ecx
 29f0ef1:	je     29f2d99 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2f79>
 29f0ef7:	test   %ecx,%ecx
 29f0ef9:	je     29f2d9b <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2f7b>
 29f0eff:	mov    0xd0(%rsp),%r13
 29f0f07:	mov    0x28(%r13),%rsi
 29f0f0b:	mov    0x20(%r13),%rdi
 29f0f0f:	mov    %ecx,%r9d
 29f0f12:	lea    0x10(%rdi,%r9,1),%rdx
 29f0f17:	xor    %r8,%r8
 29f0f1a:	cmp    %rsi,%r9
 29f0f1d:	cmova  %r8,%rdx
 29f0f21:	mov    (%rdx),%edx
 29f0f23:	cmp    %edx,%r14d
 29f0f26:	jae    29f2d9d <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2f7d>
 29f0f2c:	mov    %edx,%r9d
 29f0f2f:	shl    $0x3,%r9
 29f0f33:	shr    $0x20,%r9
 29f0f37:	test   %r9,%r9
 29f0f3a:	jne    29f2d9f <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2f7f>
 29f0f40:	shl    $0x3,%edx
 29f0f43:	add    $0x18,%edx
 29f0f46:	jb     29f2da1 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2f81>
 29f0f4c:	add    %edx,%ecx
 29f0f4e:	jb     29f2da3 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2f83>
 29f0f54:	mov    %ecx,%r10d
 29f0f57:	add    %r10,%rdi
 29f0f5a:	cmp    %rsi,%r10
 29f0f5d:	cmova  %r8,%rdi
 29f0f61:	mov    %r14,%r11
 29f0f64:	shl    $0x3,%r11d
 29f0f68:	add    $0x18,%r11d
 29f0f6f:	sub    %r11d,%edx
 29f0f72:	sub    %rdx,%rdi
 29f0f75:	movq   $0xffffffffffffffff,(%rdi)
 29f0f7c:	mov    0x18(%rsp),%ecx
 29f0f80:	mov    0x10(%rsp),%edx
 29f0f84:	mov    0x8(%rsp),%esi
 29f0f88:	mov    0x20(%rsp),%edi
 29f0f8c:	mov    0x28(%rsp),%r8d
 29f0f91:	add    $0x1,%r14d
 29f0f98:	jmp    29f0eb1 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1091>
 29f0f9d:	mov    0x90(%rsp),%r13
 29f0fa5:	test   $0x3f,%r13
 29f0fac:	je     29f1056 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1236>
 29f0fb2:	mov    (%rsp),%edx
 29f0fb5:	test   %edx,%edx
 29f0fb7:	je     29f2da5 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2f85>
 29f0fbd:	test   %edx,%edx
 29f0fbf:	je     29f2da7 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2f87>
 29f0fc5:	mov    0xd0(%rsp),%r13
 29f0fcd:	mov    0x28(%r13),%r10
 29f0fd1:	mov    0x20(%r13),%rsi
 29f0fd5:	mov    %edx,%r9d
 29f0fd8:	lea    0x10(%rsi,%r9,1),%r8
 29f0fdd:	xor    %rdi,%rdi
 29f0fe0:	cmp    %r10,%r9
 29f0fe3:	cmova  %rdi,%r8
 29f0fe7:	mov    (%r8),%r8d
 29f0fea:	cmp    %r8d,%ebx
 29f0fed:	jae    29f2da9 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2f89>
 29f0ff3:	mov    %r8d,%r9d
 29f0ff6:	shl    $0x3,%r9
 29f0ffa:	shr    $0x20,%r9
 29f0ffe:	test   %r9,%r9
 29f1001:	jne    29f2dab <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2f8b>
 29f1007:	shl    $0x3,%r8d
 29f100b:	add    $0x18,%r8d
 29f100f:	jb     29f2dad <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2f8d>
 29f1015:	add    %r8d,%edx
 29f1018:	jb     29f2daf <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2f8f>
 29f101e:	mov    $0x1,%r9d
 29f1024:	mov    0x90(%rsp),%r13
 29f102c:	mov    %r13,%rcx
 29f102f:	and    $0x3f,%rcx
 29f1033:	shl    %cl,%r9
 29f1036:	sub    $0x1,%r9
 29f103a:	mov    %edx,%ecx
 29f103c:	lea    (%rsi,%rcx,1),%rdx
 29f1040:	cmp    %r10,%rcx
 29f1043:	cmova  %rdi,%rdx
 29f1047:	shl    $0x3,%ebx
 29f104a:	lea    0x18(%rbx),%eax
 29f104d:	sub    %eax,%r8d
 29f1050:	sub    %r8,%rdx
 29f1053:	mov    %r9,(%rdx)
 29f1056:	mov    0x18(%rsp),%r14d
 29f105b:	mov    %r14,%rax
 29f105e:	mov    %r14,0x80(%rsp)
 29f1066:	test   %eax,%r14d
 29f1069:	je     29f2db1 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2f91>
 29f106f:	mov    (%rsp),%r8d
 29f1073:	test   %r8d,%r8d
 29f1076:	je     29f2db3 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2f93>
 29f107c:	mov    0x80(%rsp),%rax
 29f1084:	test   %eax,%r14d
 29f1087:	je     29f2db5 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2f95>
 29f108d:	mov    0xd0(%rsp),%r13
 29f1095:	mov    0x28(%r13),%rax
 29f1099:	mov    0x20(%r13),%rdx
 29f109d:	mov    %r14d,%esi
 29f10a0:	add    %rsi,%rdx
 29f10a3:	xor    %rdi,%rdi
 29f10a6:	cmp    %rax,%rsi
 29f10a9:	cmova  %rdi,%rdx
 29f10ad:	mov    %r8d,0x2c(%rdx)
 29f10b1:	movl   $0x2,0x24(%rdx)
 29f10b8:	mov    0x10(%rsp),%edi
 29f10bc:	mov    0x8(%rsp),%ebx
 29f10c0:	mov    %rbx,0x88(%rsp)
 29f10c8:	mov    0x20(%rsp),%esi
 29f10cc:	mov    0x28(%rsp),%edx
 29f10d0:	mov    0x80(%rsp),%rax
 29f10d8:	mov    0x80(%rsp),%r14
 29f10e0:	test   %eax,%r14d
 29f10e3:	je     29f2db7 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2f97>
 29f10e9:	mov    0x80(%rsp),%rax
 29f10f1:	mov    0x80(%rsp),%r14
 29f10f9:	test   %eax,%r14d
 29f10fc:	je     29f2db9 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2f99>
 29f1102:	mov    0xd0(%rsp),%r13
 29f110a:	mov    0x28(%r13),%r9
 29f110e:	mov    %r14d,%eax
 29f1111:	mov    %rax,%r10
 29f1114:	add    0x20(%r13),%r10
 29f1118:	xor    %r11,%r11
 29f111b:	cmp    %r9,%rax
 29f111e:	cmova  %r11,%r10
 29f1122:	mov    0x24(%r10),%ecx
 29f1126:	cmp    $0x4,%ecx
 29f1129:	je     29f12ce <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x14ae>
 29f112f:	test   %r8d,%r8d
 29f1132:	je     29f2dbb <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2f9b>
 29f1138:	test   %r8d,%r8d
 29f113b:	je     29f2dbd <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2f9d>
 29f1141:	mov    0xd0(%rsp),%r13
 29f1149:	mov    0x28(%r13),%r12
 29f114d:	mov    0x20(%r13),%r13
 29f1151:	mov    %r8d,%r10d
 29f1154:	lea    0x10(%r13,%r10,1),%r9
 29f1159:	xor    %r14,%r14
 29f115c:	cmp    %r12,%r10
 29f115f:	cmova  %r14,%r9
 29f1163:	mov    (%r9),%r15d
 29f1166:	mov    0x68(%rsp),%rcx
 29f116b:	mov    %rcx,%r11
 29f116e:	shr    $0x6,%r11d
 29f1172:	cmp    %r15d,%r11d
 29f1175:	jae    29f2dbf <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2f9f>
 29f117b:	mov    %r15d,%r9d
 29f117e:	shl    $0x3,%r9
 29f1182:	shr    $0x20,%r9
 29f1186:	test   %r9,%r9
 29f1189:	jne    29f2dc1 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2fa1>
 29f118f:	shl    $0x3,%r15d
 29f1193:	add    $0x18,%r15d
 29f1197:	jb     29f2dc3 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2fa3>
 29f119d:	mov    %r8,%r9
 29f11a0:	add    %r15d,%r9d
 29f11a3:	jb     29f2dc5 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2fa5>
 29f11a9:	mov    %r9d,%ebx
 29f11ac:	lea    0x0(%r13,%rbx,1),%r9
 29f11b1:	cmp    %r12,%rbx
 29f11b4:	cmova  %r14,%r9
 29f11b8:	mov    %r11,%rbx
 29f11bb:	shl    $0x3,%ebx
 29f11be:	mov    %rbx,%r12
 29f11c1:	lea    0x18(%r12),%ebx
 29f11c6:	mov    %r12,0xc8(%rsp)
 29f11ce:	sub    %ebx,%r15d
 29f11d1:	sub    %r15,%r9
 29f11d4:	mov    (%r9),%r13
 29f11d7:	mov    $0x1,%r14d
 29f11dd:	shl    %cl,%r14
 29f11e0:	bt     %rcx,%r13
 29f11e4:	jae    29f11f7 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x13d7>
 29f11ea:	mov    0xd0(%rsp),%rax
 29f11f2:	jmp    29f1244 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1424>
 29f11f7:	mov    0xd0(%rsp),%rcx
 29f11ff:	mov    0x28(%rcx),%r9
 29f1203:	mov    0x90(%rsp),%rcx
 29f120b:	lea    0x1(%rcx),%rbx
 29f120f:	mov    %rbx,0x90(%rsp)
 29f1217:	mov    0xd0(%rsp),%rbx
 29f121f:	mov    %rax,%r15
 29f1222:	add    0x20(%rbx),%r15
 29f1226:	xor    %r12,%r12
 29f1229:	cmp    %r9,%rax
 29f122c:	cmova  %r12,%r15
 29f1230:	mov    0x90(%rsp),%rax
 29f1238:	mov    %rax,0x18(%r15)
 29f123c:	mov    0xd0(%rsp),%rax
 29f1244:	mov    0xd0(%rsp),%rax
 29f124c:	mov    0x28(%rax),%rax
 29f1250:	mov    0xd0(%rsp),%rcx
 29f1258:	mov    0x20(%rcx),%r9
 29f125c:	lea    0x10(%r9,%r10,1),%r12
 29f1261:	xor    %r15,%r15
 29f1264:	cmp    %rax,%r10
 29f1267:	cmova  %r15,%r12
 29f126b:	mov    (%r12),%r10d
 29f126f:	cmp    %r10d,%r11d
 29f1272:	jae    29f2dc7 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2fa7>
 29f1278:	mov    %r10d,%r11d
 29f127b:	shl    $0x3,%r11
 29f127f:	shr    $0x20,%r11
 29f1283:	test   %r11,%r11
 29f1286:	jne    29f2dc9 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2fa9>
 29f128c:	shl    $0x3,%r10d
 29f1290:	add    $0x18,%r10d
 29f1294:	jb     29f2dcb <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2fab>
 29f129a:	add    %r10d,%r8d
 29f129d:	jb     29f2dcd <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2fad>
 29f12a3:	or     %r14,%r13
 29f12a6:	mov    %r8d,%r11d
 29f12a9:	lea    (%r9,%r11,1),%r8
 29f12ad:	cmp    %rax,%r11
 29f12b0:	cmova  %r15,%r8
 29f12b4:	mov    0xc8(%rsp),%rbx
 29f12bc:	lea    0x18(%rbx),%r11d
 29f12c0:	sub    %r11d,%r10d
 29f12c3:	sub    %r10,%r8
 29f12c6:	mov    %r13,(%r8)
 29f12c9:	jmp    29f132c <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x150c>
 29f12ce:	mov    0x68(%rsp),%rcx
 29f12d3:	mov    0x90(%rsp),%r13
 29f12db:	cmp    %r13,%rcx
 29f12de:	jne    29f132c <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x150c>
 29f12e4:	mov    0xd0(%rsp),%r13
 29f12ec:	mov    0x28(%r13),%r8
 29f12f0:	mov    0x90(%rsp),%r13
 29f12f8:	add    $0x1,%r13
 29f12ff:	mov    %r13,0x90(%rsp)
 29f1307:	mov    0xd0(%rsp),%r13
 29f130f:	mov    %rax,%r9
 29f1312:	add    0x20(%r13),%r9
 29f1316:	xor    %r10,%r10
 29f1319:	cmp    %r8,%rax
 29f131c:	cmova  %r10,%r9
 29f1320:	mov    0x90(%rsp),%r13
 29f1328:	mov    %r13,0x18(%r9)
 29f132c:	test   %edi,%edi
 29f132e:	je     29f2dcf <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2faf>
 29f1334:	test   %edi,%edi
 29f1336:	je     29f2dd1 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2fb1>
 29f133c:	mov    0xd0(%rsp),%r13
 29f1344:	mov    0x28(%r13),%rax
 29f1348:	mov    0x20(%r13),%r8
 29f134c:	mov    %edi,%r11d
 29f134f:	lea    0x10(%r8,%r11,1),%r10
 29f1354:	xor    %r9,%r9
 29f1357:	cmp    %rax,%r11
 29f135a:	cmova  %r9,%r10
 29f135e:	mov    (%r10),%r10d
 29f1361:	mov    0x68(%rsp),%rcx
 29f1366:	cmp    %r10d,%ecx
 29f1369:	jae    29f2dd3 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2fb3>
 29f136f:	mov    %r10d,%r11d
 29f1372:	shl    $0x3,%r11
 29f1376:	shr    $0x20,%r11
 29f137a:	test   %r11,%r11
 29f137d:	jne    29f2dd5 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2fb5>
 29f1383:	shl    $0x3,%r10d
 29f1387:	add    $0x18,%r10d
 29f138b:	jb     29f2dd7 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2fb7>
 29f1391:	add    %r10d,%edi
 29f1394:	jb     29f2dd9 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2fb9>
 29f139a:	mov    %edi,%r11d
 29f139d:	lea    (%r8,%r11,1),%rdi
 29f13a1:	cmp    %rax,%r11
 29f13a4:	cmova  %r9,%rdi
 29f13a8:	mov    %rcx,%rax
 29f13ab:	shl    $0x3,%eax
 29f13ae:	add    $0x18,%eax
 29f13b4:	sub    %eax,%r10d
 29f13b7:	sub    %r10,%rdi
 29f13ba:	mov    0x78(%rsp),%r8
 29f13bf:	mov    %r8,(%rdi)
 29f13c2:	mov    $0x1,%r10d
 29f13c8:	mov    0x80(%rsp),%r14
 29f13d0:	mov    %r14d,0x8(%rsp)
 29f13d5:	mov    0x88(%rsp),%rbx
 29f13dd:	mov    %ebx,0x10(%rsp)
 29f13e1:	mov    %esi,(%rsp)
 29f13e4:	mov    %edx,0x18(%rsp)
 29f13e8:	test   %r10d,%r10d
 29f13eb:	mov    %r10,0xa0(%rsp)
 29f13f3:	je     29f140b <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x15eb>
 29f13f9:	mov    0xa0(%rsp),%r10
 29f1401:	mov    0x78(%rsp),%r14
 29f1406:	jmp    29f251e <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x26fe>
 29f140b:	mov    0x80(%rsp),%r8
 29f1413:	mov    0x80(%rsp),%r14
 29f141b:	test   %r8d,%r14d
 29f141e:	je     29f2ddb <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2fbb>
 29f1424:	mov    0x80(%rsp),%rax
 29f142c:	test   %eax,%r14d
 29f142f:	je     29f2ddd <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2fbd>
 29f1435:	mov    0xd0(%rsp),%r13
 29f143d:	mov    0x28(%r13),%rax
 29f1441:	mov    0x20(%r13),%rdi
 29f1445:	mov    %r14d,%r8d
 29f1448:	add    %r8,%rdi
 29f144b:	xor    %r9,%r9
 29f144e:	cmp    %rax,%r8
 29f1451:	cmova  %r9,%rdi
 29f1455:	mov    0x24(%rdi),%edi
 29f1458:	cmp    $0x4,%edi
 29f145b:	sete   %al
 29f145e:	cmp    $0x2,%edi
 29f1461:	sete   %dil
 29f1465:	or     %edi,%eax
 29f1467:	mov    0x70(%rsp),%r9
 29f146c:	cmp    $0x3,%r9d
 29f1470:	setne  %cl
 29f1473:	test   %al,%cl
 29f1475:	jne    29f1490 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1670>
 29f147b:	mov    0x80(%rsp),%rax
 29f1483:	mov    0x80(%rsp),%r14
 29f148b:	jmp    29f1ccf <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1eaf>
 29f1490:	mov    0x8(%rsp),%r14d
 29f1495:	mov    %r14,%rax
 29f1498:	mov    %r14,0x80(%rsp)
 29f14a0:	test   %eax,%r14d
 29f14a3:	je     29f2ddf <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2fbf>
 29f14a9:	mov    0x80(%rsp),%rax
 29f14b1:	test   %eax,%r14d
 29f14b4:	je     29f2de1 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2fc1>
 29f14ba:	mov    0xd0(%rsp),%r13
 29f14c2:	mov    0x28(%r13),%rax
 29f14c6:	mov    0x20(%r13),%rsi
 29f14ca:	mov    %r14d,%r8d
 29f14cd:	lea    (%rsi,%r8,1),%rdx
 29f14d1:	xor    %rdi,%rdi
 29f14d4:	cmp    %rax,%r8
 29f14d7:	cmova  %rdi,%rdx
 29f14db:	mov    0x28(%rdx),%r8d
 29f14df:	mov    0x2c(%rdx),%ecx
 29f14e2:	test   %r8d,%r8d
 29f14e5:	je     29f2de3 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2fc3>
 29f14eb:	test   %r8d,%r8d
 29f14ee:	je     29f2de5 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2fc5>
 29f14f4:	mov    %r8d,%r8d
 29f14f7:	lea    0x10(%rsi,%r8,1),%rsi
 29f14fc:	cmp    %rax,%r8
 29f14ff:	cmova  %rdi,%rsi
 29f1503:	mov    (%rsi),%edi
 29f1505:	mov    0x18(%rdx),%rax
 29f1509:	mov    (%rsp),%esi
 29f150c:	mov    0x18(%rsp),%edx
 29f1510:	mov    %edi,%ecx
 29f1512:	mov    0x68(%rsp),%rdi
 29f1517:	cmp    %rcx,%rdi
 29f151a:	setb   %dil
 29f151e:	mov    0x68(%rsp),%rcx
 29f1523:	cmp    $0x100000,%rcx
 29f152a:	setb   %r8b
 29f152e:	lea    0x8(%rax,%rax,1),%r9
 29f1533:	cmp    %r9,%rcx
 29f1536:	setbe  %r9b
 29f153a:	and    %r9d,%r8d
 29f153d:	or     %r8d,%edi
 29f1540:	test   %dil,%dil
 29f1543:	je     29f1cbf <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1e9f>
 29f1549:	mov    0x8(%rsp),%esi
 29f154d:	test   %esi,%esi
 29f154f:	je     29f2de7 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2fc7>
 29f1555:	test   %esi,%esi
 29f1557:	je     29f2de9 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2fc9>
 29f155d:	mov    0xd0(%rsp),%r13
 29f1565:	mov    0x28(%r13),%r10
 29f1569:	mov    0x20(%r13),%r11
 29f156d:	mov    %esi,%ecx
 29f156f:	lea    (%r11,%rcx,1),%rdi
 29f1573:	xor    %rax,%rax
 29f1576:	cmp    %r10,%rcx
 29f1579:	cmova  %rax,%rdi
 29f157d:	mov    0x28(%rdi),%ecx
 29f1580:	mov    0x2c(%rdi),%edx
 29f1583:	test   %ecx,%ecx
 29f1585:	je     29f2deb <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2fcb>
 29f158b:	test   %ecx,%ecx
 29f158d:	je     29f2ded <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2fcd>
 29f1593:	mov    %ecx,%edx
 29f1595:	lea    0x10(%r11,%rdx,1),%rcx
 29f159a:	cmp    %r10,%rdx
 29f159d:	cmova  %rax,%rcx
 29f15a1:	mov    (%rcx),%eax
 29f15a3:	mov    %eax,%r14d
 29f15a6:	mov    %r14,%r13
 29f15a9:	shl    $0x2,%r13
 29f15ad:	mov    $0x20,%ecx
 29f15b2:	mov    %rcx,0xc0(%rsp)
 29f15ba:	mov    %r13,%rcx
 29f15bd:	shr    $0x20,%rcx
 29f15c1:	test   %rcx,%rcx
 29f15c4:	jne    29f2def <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2fcf>
 29f15ca:	mov    %rax,%rcx
 29f15cd:	shl    $0x2,%ecx
 29f15d0:	mov    %rax,0xc8(%rsp)
 29f15d8:	add    $0x14,%ecx
 29f15db:	jb     29f2df1 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2fd1>
 29f15e1:	mov    0x60(%rsp),%rsi
 29f15e6:	mov    0x20(%rsi),%rdi
 29f15ea:	mov    (%rdi),%eax
 29f15ec:	mov    %eax,%edx
 29f15ee:	mov    %ecx,%esi
 29f15f0:	add    $0xf,%rsi
 29f15f7:	mov    %rsi,%r8
 29f15fa:	and    $0xfffffffffffffff0,%r8
 29f15fe:	add    %rdx,%r8
 29f1601:	mov    0x4(%rdi),%r9d
 29f1605:	mov    %rdi,0xb8(%rsp)
 29f160d:	cmp    %r9,%r8
 29f1610:	ja     29f2a66 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2c46>
 29f1616:	add    $0xf,%ecx
 29f161c:	and    $0xfffffff0,%ecx
 29f161f:	add    %eax,%ecx
 29f1621:	mov    0xb8(%rsp),%r12
 29f1629:	mov    %ecx,(%r12)
 29f162d:	mov    0xd0(%rsp),%rcx
 29f1635:	mov    0x20(%rcx),%rdi
 29f1639:	lea    (%rdi,%rdx,1),%rcx
 29f163d:	movl   $0xa800000e,(%rdi,%rdx,1)
 29f1644:	mov    0x60(%rsp),%r8
 29f1649:	mov    0x28(%r8),%r8
 29f164d:	mov    0x19c(%r8),%r8d
 29f1654:	mov    %r8d,0x4(%rdi,%rdx,1)
 29f1659:	and    $0xfffffffffffffff0,%rsi
 29f165d:	mov    %esi,0x8(%rdi,%rdx,1)
 29f1661:	mov    %eax,0x20(%rsp)
 29f1665:	mov    0xc8(%rsp),%r15
 29f166d:	mov    %r15d,0x10(%rcx)
 29f1671:	test   %eax,%eax
 29f1673:	je     29f2df3 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2fd3>
 29f1679:	mov    0xd0(%rsp),%rcx
 29f1681:	mov    0x28(%rcx),%rdx
 29f1685:	mov    0x20(%rcx),%rsi
 29f1689:	mov    %eax,%eax
 29f168b:	lea    (%rsi,%rax,1),%rcx
 29f168f:	lea    0x10(%rsi,%rax,1),%rdi
 29f1694:	xor    %r8,%r8
 29f1697:	cmp    %rdx,%rax
 29f169a:	cmova  %r8,%rdi
 29f169e:	mov    (%rdi),%edi
 29f16a0:	cmp    %rdi,%r14
 29f16a3:	ja     29f2df5 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2fd5>
 29f16a9:	lea    0x14(%rsi,%rax,1),%r12
 29f16ae:	mov    %r12,%rax
 29f16b1:	add    %r13,%rax
 29f16b4:	jb     29f2df7 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2fd7>
 29f16ba:	add    %rsi,%rdx
 29f16bd:	cmp    %rdx,%rax
 29f16c0:	ja     29f2df9 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2fd9>
 29f16c6:	mov    0x8(%rsp),%edi
 29f16ca:	mov    0x10(%rsp),%eax
 29f16ce:	mov    (%rsp),%edx
 29f16d1:	mov    0x18(%rsp),%esi
 29f16d5:	lea    0x14(%rcx,%r14,4),%r13
 29f16da:	test   %r14,%r14
 29f16dd:	je     29f1735 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1915>
 29f16e3:	mov    %edi,0x18(%rsp)
 29f16e7:	mov    %eax,(%rsp)
 29f16ea:	mov    %edx,0x10(%rsp)
 29f16ee:	mov    %esi,0x8(%rsp)
 29f16f2:	mov    0xd8(%rsp),%r14
 29f16fa:	mov    (%r14),%rax
 29f16fd:	mov    0x98(%rsp),%rsi
 29f1705:	cmp    %rsi,%rax
 29f1708:	jae    29f2a9d <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2c7d>
 29f170e:	movl   $0x0,(%r12)
 29f1716:	mov    0x18(%rsp),%edi
 29f171a:	mov    (%rsp),%eax
 29f171d:	mov    0x10(%rsp),%edx
 29f1721:	mov    0x8(%rsp),%esi
 29f1725:	add    $0x4,%r12
 29f172c:	cmp    %r13,%r12
 29f172f:	jne    29f16e3 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x18c3>
 29f1735:	mov    %edi,0x18(%rsp)
 29f1739:	xor    %r14d,%r14d
 29f173c:	mov    $0x1,%r15d
 29f1742:	mov    0x60(%rsp),%rcx
 29f1747:	mov    %r15,0xa8(%rsp)
 29f174f:	mov    0x28(%rcx),%rcx
 29f1753:	mov    0x120(%rcx),%r15d
 29f175a:	mov    %r15,0x88(%rsp)
 29f1762:	mov    $0x10,%r15d
 29f1768:	mov    %r15,0xb0(%rsp)
 29f1770:	mov    %r14,%r15
 29f1773:	mov    %eax,0x8(%rsp)
 29f1777:	mov    %edx,0x10(%rsp)
 29f177b:	mov    %esi,(%rsp)
 29f177e:	mov    0xd8(%rsp),%r11
 29f1786:	mov    (%r11),%rax
 29f1789:	mov    0x98(%rsp),%rcx
 29f1791:	cmp    %rcx,%rax
 29f1794:	jae    29f2ad4 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2cb4>
 29f179a:	mov    0xc8(%rsp),%rcx
 29f17a2:	jmp    29f17af <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x198f>
 29f17a7:	mov    0xc8(%rsp),%rcx
 29f17af:	cmp    %ecx,%r14d
 29f17b2:	jae    29f1c2a <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1e0a>
 29f17b8:	mov    0x18(%rsp),%r8d
 29f17bd:	test   %r8d,%r8d
 29f17c0:	je     29f2dfb <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2fdb>
 29f17c6:	test   %r8d,%r8d
 29f17c9:	je     29f2dfd <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2fdd>
 29f17cf:	mov    0xd0(%rsp),%r13
 29f17d7:	mov    0x28(%r13),%rax
 29f17db:	mov    %r8d,%ecx
 29f17de:	mov    %rcx,%r9
 29f17e1:	add    0x20(%r13),%r9
 29f17e5:	xor    %rdx,%rdx
 29f17e8:	cmp    %rax,%rcx
 29f17eb:	cmova  %rdx,%r9
 29f17ef:	mov    0x24(%r9),%eax
 29f17f3:	cmp    $0x4,%eax
 29f17f6:	je     29f19ac <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1b8c>
 29f17fc:	mov    0x18(%rsp),%eax
 29f1800:	xor    %esi,%esi
 29f1802:	test   %eax,%eax
 29f1804:	je     29f2dff <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2fdf>
 29f180a:	test   %eax,%eax
 29f180c:	je     29f2e01 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2fe1>
 29f1812:	mov    0xd0(%rsp),%r13
 29f181a:	mov    0x28(%r13),%rdx
 29f181e:	mov    0x20(%r13),%r8
 29f1822:	mov    %eax,%ecx
 29f1824:	lea    (%r8,%rcx,1),%rax
 29f1828:	xor    %r9,%r9
 29f182b:	cmp    %rdx,%rcx
 29f182e:	cmova  %r9,%rax
 29f1832:	mov    0x28(%rax),%ecx
 29f1835:	mov    0x2c(%rax),%edi
 29f1838:	test   %ecx,%ecx
 29f183a:	je     29f2e03 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2fe3>
 29f1840:	test   %ecx,%ecx
 29f1842:	je     29f2e05 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2fe5>
 29f1848:	mov    %ecx,%eax
 29f184a:	lea    0x10(%r8,%rax,1),%r8
 29f184f:	cmp    %rdx,%rax
 29f1852:	cmova  %r9,%r8
 29f1856:	mov    (%r8),%r8d
 29f1859:	mov    0x8(%rsp),%edx
 29f185d:	mov    %r14d,%r9d
 29f1860:	mov    %r8d,%r8d
 29f1863:	cmp    %r8,%r9
 29f1866:	jb     29f1874 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1a54>
 29f186c:	mov    %r15,%r12
 29f186f:	jmp    29f1abc <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1c9c>
 29f1874:	xor    %esi,%esi
 29f1876:	test   %edi,%edi
 29f1878:	je     29f2e07 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2fe7>
 29f187e:	test   %edi,%edi
 29f1880:	je     29f2e09 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2fe9>
 29f1886:	mov    0xd0(%rsp),%r13
 29f188e:	mov    0x28(%r13),%rdx
 29f1892:	mov    0x20(%r13),%r8
 29f1896:	mov    %edi,%r11d
 29f1899:	lea    0x10(%r8,%r11,1),%r10
 29f189e:	xor    %r9,%r9
 29f18a1:	cmp    %rdx,%r11
 29f18a4:	cmova  %r9,%r10
 29f18a8:	mov    (%r10),%r10d
 29f18ab:	mov    %r14,%r11
 29f18ae:	shr    $0x6,%r11d
 29f18b2:	cmp    %r10d,%r11d
 29f18b5:	jae    29f2e0b <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2feb>
 29f18bb:	mov    %r10d,%r12d
 29f18be:	shl    $0x3,%r12
 29f18c2:	shr    $0x20,%r12
 29f18c6:	test   %r12,%r12
 29f18c9:	jne    29f2e0d <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2fed>
 29f18cf:	shl    $0x3,%r10d
 29f18d3:	add    $0x18,%r10d
 29f18d7:	jb     29f2e0f <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2fef>
 29f18dd:	add    %r10d,%edi
 29f18e0:	jb     29f2e11 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2ff1>
 29f18e6:	mov    %edi,%ebx
 29f18e8:	lea    (%r8,%rbx,1),%rdi
 29f18ec:	cmp    %rdx,%rbx
 29f18ef:	cmova  %r9,%rdi
 29f18f3:	shl    $0x3,%r11d
 29f18f7:	lea    0x18(%r11),%edx
 29f18fb:	sub    %edx,%r10d
 29f18fe:	sub    %r10,%rdi
 29f1901:	mov    (%rdi),%rdi
 29f1904:	mov    0x8(%rsp),%edx
 29f1908:	bt     %r14,%rdi
 29f190c:	jb     29f191a <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1afa>
 29f1912:	mov    %r15,%r12
 29f1915:	jmp    29f1abc <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1c9c>
 29f191a:	mov    0xd0(%rsp),%r13
 29f1922:	mov    0x28(%r13),%rdx
 29f1926:	mov    0x20(%r13),%rdi
 29f192a:	lea    0x10(%rdi,%rax,1),%r8
 29f192f:	xor    %rsi,%rsi
 29f1932:	cmp    %rdx,%rax
 29f1935:	cmova  %rsi,%r8
 29f1939:	mov    (%r8),%eax
 29f193c:	cmp    %eax,%r14d
 29f193f:	jae    29f2e13 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2ff3>
 29f1945:	mov    %eax,%r8d
 29f1948:	shl    $0x3,%r8
 29f194c:	shr    $0x20,%r8
 29f1950:	test   %r8,%r8
 29f1953:	jne    29f2e15 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2ff5>
 29f1959:	mov    $0x3,%r12d
 29f195f:	shl    $0x3,%eax
 29f1962:	add    $0x18,%eax
 29f1965:	jb     29f2e17 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2ff7>
 29f196b:	add    %eax,%ecx
 29f196d:	jb     29f2e19 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2ff9>
 29f1973:	mov    %ecx,%r8d
 29f1976:	lea    (%rdi,%r8,1),%rcx
 29f197a:	cmp    %rdx,%r8
 29f197d:	cmova  %rsi,%rcx
 29f1981:	mov    %r14,%rdx
 29f1984:	shl    $0x3,%edx
 29f1987:	add    $0x18,%edx
 29f198d:	sub    %edx,%eax
 29f198f:	sub    %rax,%rcx
 29f1992:	mov    (%rcx),%r13
 29f1995:	mov    %r13,0x90(%rsp)
 29f199d:	xor    %edx,%edx
 29f199f:	mov    0xa8(%rsp),%rsi
 29f19a7:	jmp    29f1abc <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1c9c>
 29f19ac:	mov    %r15,%r12
 29f19af:	mov    0x18(%rsp),%eax
 29f19b3:	xor    %esi,%esi
 29f19b5:	test   %eax,%eax
 29f19b7:	je     29f2e1b <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2ffb>
 29f19bd:	test   %eax,%eax
 29f19bf:	je     29f2e1d <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2ffd>
 29f19c5:	mov    0xd0(%rsp),%r13
 29f19cd:	mov    0x28(%r13),%rcx
 29f19d1:	mov    %eax,%edx
 29f19d3:	mov    %rdx,%rax
 29f19d6:	add    0x20(%r13),%rax
 29f19da:	xor    %rdi,%rdi
 29f19dd:	cmp    %rcx,%rdx
 29f19e0:	cmova  %rdi,%rax
 29f19e4:	mov    0x18(%rax),%rax
 29f19e8:	mov    0x8(%rsp),%edx
 29f19ec:	mov    %r14d,%ecx
 29f19ef:	cmp    %rax,%rcx
 29f19f2:	jae    29f1abc <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1c9c>
 29f19f8:	mov    0x18(%rsp),%eax
 29f19fc:	xor    %edx,%edx
 29f19fe:	test   %eax,%eax
 29f1a00:	je     29f2e1f <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2fff>
 29f1a06:	test   %eax,%eax
 29f1a08:	je     29f2e21 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x3001>
 29f1a0e:	mov    0xd0(%rsp),%r13
 29f1a16:	mov    0x28(%r13),%rsi
 29f1a1a:	mov    0x20(%r13),%rdi
 29f1a1e:	mov    %eax,%r9d
 29f1a21:	lea    (%rdi,%r9,1),%rax
 29f1a25:	xor    %r8,%r8
 29f1a28:	cmp    %rsi,%r9
 29f1a2b:	cmova  %r8,%rax
 29f1a2f:	mov    0x28(%rax),%eax
 29f1a32:	test   %eax,%eax
 29f1a34:	je     29f2e23 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x3003>
 29f1a3a:	test   %eax,%eax
 29f1a3c:	je     29f2e25 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x3005>
 29f1a42:	mov    %eax,%r10d
 29f1a45:	lea    0x10(%rdi,%r10,1),%r9
 29f1a4a:	cmp    %rsi,%r10
 29f1a4d:	cmova  %r8,%r9
 29f1a51:	mov    (%r9),%ecx
 29f1a54:	cmp    %ecx,%r14d
 29f1a57:	jae    29f2e27 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x3007>
 29f1a5d:	mov    %ecx,%r9d
 29f1a60:	shl    $0x3,%r9
 29f1a64:	shr    $0x20,%r9
 29f1a68:	test   %r9,%r9
 29f1a6b:	jne    29f2e29 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x3009>
 29f1a71:	mov    $0x3,%r12d
 29f1a77:	shl    $0x3,%ecx
 29f1a7a:	add    $0x18,%ecx
 29f1a7d:	jb     29f2e2b <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x300b>
 29f1a83:	add    %ecx,%eax
 29f1a85:	jb     29f2e2d <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x300d>
 29f1a8b:	mov    %eax,%eax
 29f1a8d:	lea    (%rdi,%rax,1),%r10
 29f1a91:	cmp    %rsi,%rax
 29f1a94:	cmova  %r8,%r10
 29f1a98:	mov    %r14,%rax
 29f1a9b:	shl    $0x3,%eax
 29f1a9e:	add    $0x18,%eax
 29f1aa4:	sub    %eax,%ecx
 29f1aa6:	sub    %rcx,%r10
 29f1aa9:	mov    (%r10),%r13
 29f1aac:	mov    %r13,0x90(%rsp)
 29f1ab4:	mov    0xa8(%rsp),%rsi
 29f1abc:	mov    %edx,0x8(%rsp)
 29f1ac0:	test   %esi,%esi
 29f1ac2:	jne    29f1ae5 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1cc5>
 29f1ac8:	mov    0xc0(%rsp),%rcx
 29f1ad0:	mov    0x88(%rsp),%r13
 29f1ad8:	mov    0xb8(%rsp),%r15
 29f1ae0:	jmp    29f1bf8 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1dd8>
 29f1ae5:	mov    0xb8(%rsp),%r15
 29f1aed:	mov    (%r15),%eax
 29f1af0:	mov    %eax,%edx
 29f1af2:	lea    0x20(%rdx),%rcx
 29f1af6:	mov    0x4(%r15),%esi
 29f1afa:	cmp    %rsi,%rcx
 29f1afd:	ja     29f2b10 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2cf0>
 29f1b03:	mov    0x88(%rsp),%r13
 29f1b0b:	lea    0x20(%rax),%ecx
 29f1b0e:	mov    %ecx,(%r15)
 29f1b11:	mov    0xd0(%rsp),%rcx
 29f1b19:	mov    0x20(%rcx),%rsi
 29f1b1d:	lea    (%rsi,%rdx,1),%r10
 29f1b21:	movl   $0xb0000042,(%rsi,%rdx,1)
 29f1b28:	mov    %r13d,0x4(%rsi,%rdx,1)
 29f1b2d:	mov    0xc0(%rsp),%rcx
 29f1b35:	mov    %ecx,0x8(%rsi,%rdx,1)
 29f1b39:	mov    0x90(%rsp),%rdx
 29f1b41:	mov    0x90(%rsp),%rdx
 29f1b49:	mov    %rdx,0x10(%r10)
 29f1b4d:	mov    %r12d,0x18(%r10)
 29f1b51:	mov    0x8(%rsp),%edx
 29f1b55:	mov    %edx,0x1c(%r10)
 29f1b59:	mov    0x20(%rsp),%edx
 29f1b5d:	test   %edx,%edx
 29f1b5f:	je     29f2e2f <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x300f>
 29f1b65:	test   %eax,%eax
 29f1b67:	je     29f2e31 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x3011>
 29f1b6d:	test   %edx,%edx
 29f1b6f:	je     29f2e33 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x3013>
 29f1b75:	mov    0xd0(%rsp),%rsi
 29f1b7d:	mov    0x28(%rsi),%rsi
 29f1b81:	mov    0xd0(%rsp),%rdi
 29f1b89:	mov    0x20(%rdi),%rdi
 29f1b8d:	mov    %edx,%r10d
 29f1b90:	lea    0x10(%rdi,%r10,1),%r9
 29f1b95:	xor    %r8,%r8
 29f1b98:	cmp    %rsi,%r10
 29f1b9b:	cmova  %r8,%r9
 29f1b9f:	mov    (%r9),%r9d
 29f1ba2:	cmp    %r9d,%r14d
 29f1ba5:	jae    29f2e35 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x3015>
 29f1bab:	mov    %r9d,%r10d
 29f1bae:	shl    $0x2,%r10
 29f1bb2:	shr    $0x20,%r10
 29f1bb6:	test   %r10,%r10
 29f1bb9:	jne    29f2e37 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x3017>
 29f1bbf:	shl    $0x2,%r9d
 29f1bc3:	add    $0x14,%r9d
 29f1bc7:	jb     29f2e39 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x3019>
 29f1bcd:	add    %r9d,%edx
 29f1bd0:	jb     29f2e3b <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x301b>
 29f1bd6:	mov    %edx,%r10d
 29f1bd9:	lea    (%rdi,%r10,1),%rdx
 29f1bdd:	cmp    %rsi,%r10
 29f1be0:	cmova  %r8,%rdx
 29f1be4:	mov    %r14,%rsi
 29f1be7:	shl    $0x2,%esi
 29f1bea:	add    $0x14,%esi
 29f1bf0:	sub    %esi,%r9d
 29f1bf3:	sub    %r9,%rdx
 29f1bf6:	mov    %eax,(%rdx)
 29f1bf8:	mov    0x8(%rsp),%eax
 29f1bfc:	mov    0x10(%rsp),%edx
 29f1c00:	mov    (%rsp),%esi
 29f1c03:	add    $0x1,%r14d
 29f1c0a:	mov    %rcx,0xc0(%rsp)
 29f1c12:	mov    %r15,0xb8(%rsp)
 29f1c1a:	mov    %r13,0x88(%rsp)
 29f1c22:	mov    %r12,%r15
 29f1c25:	jmp    29f1773 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1953>
 29f1c2a:	mov    0x60(%rsp),%rsi
 29f1c2f:	mov    0xa00(%rsi),%edx
 29f1c35:	mov    0xa10(%rsi),%eax
 29f1c3b:	mov    0x18(%rsp),%r14d
 29f1c40:	mov    %r14,%rcx
 29f1c43:	mov    %r14,0x80(%rsp)
 29f1c4b:	test   %ecx,%r14d
 29f1c4e:	je     29f2e3d <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x301d>
 29f1c54:	test   %edx,%edx
 29f1c56:	je     29f2e3f <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x301f>
 29f1c5c:	mov    0x80(%rsp),%rcx
 29f1c64:	test   %ecx,%r14d
 29f1c67:	je     29f2e41 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x3021>
 29f1c6d:	mov    0xd0(%rsp),%r13
 29f1c75:	mov    0x28(%r13),%rdi
 29f1c79:	mov    0x20(%r13),%rsi
 29f1c7d:	mov    %r14d,%r8d
 29f1c80:	add    %r8,%rsi
 29f1c83:	xor    %r9,%r9
 29f1c86:	cmp    %rdi,%r8
 29f1c89:	cmova  %r9,%rsi
 29f1c8d:	mov    %edx,0x28(%rsi)
 29f1c90:	test   %eax,%eax
 29f1c92:	je     29f2e43 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x3023>
 29f1c98:	mov    %eax,0x2c(%rsi)
 29f1c9b:	movl   $0x0,0x30(%rsi)
 29f1ca2:	mov    0x20(%rsp),%eax
 29f1ca6:	test   %eax,%eax
 29f1ca8:	je     29f2e45 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x3025>
 29f1cae:	mov    %eax,0x30(%rsi)
 29f1cb1:	movl   $0x3,0x24(%rsi)
 29f1cb8:	mov    0x10(%rsp),%esi
 29f1cbc:	mov    (%rsp),%edx
 29f1cbf:	mov    0x80(%rsp),%rax
 29f1cc7:	mov    0x80(%rsp),%r14
 29f1ccf:	test   %eax,%r14d
 29f1cd2:	je     29f2e47 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x3027>
 29f1cd8:	mov    0x80(%rsp),%rax
 29f1ce0:	mov    0x80(%rsp),%r14
 29f1ce8:	test   %eax,%r14d
 29f1ceb:	je     29f2e49 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x3029>
 29f1cf1:	mov    0xd0(%rsp),%r13
 29f1cf9:	mov    0x28(%r13),%r10
 29f1cfd:	mov    %r14d,%r9d
 29f1d00:	mov    %r9,%rdi
 29f1d03:	add    0x20(%r13),%rdi
 29f1d07:	xor    %r11,%r11
 29f1d0a:	cmp    %r10,%r9
 29f1d0d:	cmova  %r11,%rdi
 29f1d11:	mov    0x24(%rdi),%r10d
 29f1d15:	cmp    $0x3,%r10d
 29f1d19:	je     29f1d31 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1f11>
 29f1d1f:	mov    0xa0(%rsp),%r10
 29f1d27:	mov    0x78(%rsp),%r14
 29f1d2c:	jmp    29f251e <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x26fe>
 29f1d31:	mov    0xd0(%rsp),%r13
 29f1d39:	mov    0x28(%r13),%rax
 29f1d3d:	mov    0x20(%r13),%r8
 29f1d41:	lea    (%r8,%r9,1),%r10
 29f1d45:	xor    %rdi,%rdi
 29f1d48:	cmp    %rax,%r9
 29f1d4b:	cmova  %rdi,%r10
 29f1d4f:	mov    0x30(%r10),%r9d
 29f1d53:	test   %r9d,%r9d
 29f1d56:	je     29f2e4b <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x302b>
 29f1d5c:	test   %r9d,%r9d
 29f1d5f:	je     29f2e4d <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x302d>
 29f1d65:	mov    %r9d,%r11d
 29f1d68:	lea    0x10(%r8,%r11,1),%r8
 29f1d6d:	cmp    %rax,%r11
 29f1d70:	cmova  %rdi,%r8
 29f1d74:	mov    (%r8),%ebx
 29f1d77:	mov    %rbx,0x88(%rsp)
 29f1d7f:	mov    0x18(%r10),%r13
 29f1d83:	mov    %r13,0xb0(%rsp)
 29f1d8b:	mov    %ebx,%r14d
 29f1d8e:	mov    0x68(%rsp),%rcx
 29f1d93:	cmp    %r14,%rcx
 29f1d96:	mov    %r14,0xa8(%rsp)
 29f1d9e:	setb   %al
 29f1da1:	cmp    $0x100000,%rcx
 29f1da8:	setb   %dil
 29f1dac:	lea    0x8(%r13,%r13,1),%rcx
 29f1db1:	mov    0x68(%rsp),%r8
 29f1db6:	cmp    %rcx,%r8
 29f1db9:	setbe  %r8b
 29f1dbd:	and    %r8d,%edi
 29f1dc0:	or     %edi,%eax
 29f1dc2:	test   %al,%al
 29f1dc4:	jne    29f1ddc <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1fbc>
 29f1dca:	mov    0xa0(%rsp),%r10
 29f1dd2:	mov    0x78(%rsp),%r14
 29f1dd7:	jmp    29f251e <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x26fe>
 29f1ddc:	mov    0x68(%rsp),%rcx
 29f1de1:	mov    0xa8(%rsp),%r14
 29f1de9:	cmp    %r14,%rcx
 29f1dec:	jb     29f230d <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x24ed>
 29f1df2:	mov    0x88(%rsp),%rax
 29f1dfa:	mov    0x88(%rsp),%rbx
 29f1e02:	test   %eax,%ebx
 29f1e04:	je     29f1e17 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1ff7>
 29f1e0a:	mov    0x88(%rsp),%r13
 29f1e12:	jmp    29f1e1d <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1ffd>
 29f1e17:	mov    $0x4,%r13d
 29f1e1d:	mov    %r9d,0x20(%rsp)
 29f1e22:	mov    0x80(%rsp),%r14
 29f1e2a:	mov    %r14d,(%rsp)
 29f1e2e:	mov    %esi,0x10(%rsp)
 29f1e32:	mov    %edx,0x18(%rsp)
 29f1e36:	mov    0xd8(%rsp),%r14
 29f1e3e:	mov    (%r14),%rax
 29f1e41:	mov    0x98(%rsp),%rcx
 29f1e49:	cmp    %rcx,%rax
 29f1e4c:	jae    29f2b5b <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2d3b>
 29f1e52:	mov    %r13d,%r14d
 29f1e55:	mov    0x68(%rsp),%rcx
 29f1e5a:	cmp    %r14,%rcx
 29f1e5d:	jb     29f1e84 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2064>
 29f1e63:	mov    0x20(%rsp),%r9d
 29f1e68:	mov    (%rsp),%r14d
 29f1e6c:	mov    %r14,0x80(%rsp)
 29f1e74:	mov    0x10(%rsp),%esi
 29f1e78:	mov    0x18(%rsp),%edx
 29f1e7c:	shl    $1,%r13d
 29f1e7f:	jmp    29f1e1d <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1ffd>
 29f1e84:	mov    %r14,%r12
 29f1e87:	shl    $0x2,%r12
 29f1e8b:	mov    %r12,%rax
 29f1e8e:	shr    $0x20,%rax
 29f1e92:	test   %rax,%rax
 29f1e95:	jne    29f2e4f <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x302f>
 29f1e9b:	mov    %r13,%rcx
 29f1e9e:	shl    $0x2,%ecx
 29f1ea1:	add    $0x14,%ecx
 29f1ea4:	jb     29f2e51 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x3031>
 29f1eaa:	mov    0x60(%rsp),%rsi
 29f1eaf:	mov    0x20(%rsi),%rdi
 29f1eb3:	mov    (%rdi),%eax
 29f1eb5:	mov    %eax,%edx
 29f1eb7:	mov    %ecx,%esi
 29f1eb9:	add    $0xf,%rsi
 29f1ec0:	mov    %rsi,%r8
 29f1ec3:	and    $0xfffffffffffffff0,%r8
 29f1ec7:	add    %rdx,%r8
 29f1eca:	mov    0x4(%rdi),%r9d
 29f1ece:	cmp    %r9,%r8
 29f1ed1:	ja     29f2b8f <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2d6f>
 29f1ed7:	add    $0xf,%ecx
 29f1edd:	and    $0xfffffff0,%ecx
 29f1ee0:	add    %eax,%ecx
 29f1ee2:	mov    %ecx,(%rdi)
 29f1ee4:	mov    0xd0(%rsp),%rcx
 29f1eec:	mov    0x20(%rcx),%rdi
 29f1ef0:	lea    (%rdi,%rdx,1),%rcx
 29f1ef4:	movl   $0xa800000e,(%rdi,%rdx,1)
 29f1efb:	mov    0x60(%rsp),%r8
 29f1f00:	mov    0x28(%r8),%r8
 29f1f04:	mov    0x19c(%r8),%r8d
 29f1f0b:	mov    %r8d,0x4(%rdi,%rdx,1)
 29f1f10:	and    $0xfffffffffffffff0,%rsi
 29f1f14:	mov    %esi,0x8(%rdi,%rdx,1)
 29f1f18:	mov    %eax,0x8(%rsp)
 29f1f1c:	mov    %r13d,0x10(%rcx)
 29f1f20:	test   %eax,%eax
 29f1f22:	je     29f2e53 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x3033>
 29f1f28:	mov    0xd0(%rsp),%r13
 29f1f30:	mov    0x28(%r13),%rcx
 29f1f34:	mov    0x20(%r13),%rdx
 29f1f38:	mov    %eax,%esi
 29f1f3a:	lea    (%rdx,%rsi,1),%rax
 29f1f3e:	lea    0x10(%rdx,%rsi,1),%rdi
 29f1f43:	xor    %r8,%r8
 29f1f46:	cmp    %rcx,%rsi
 29f1f49:	cmova  %r8,%rdi
 29f1f4d:	mov    (%rdi),%edi
 29f1f4f:	cmp    %rdi,%r14
 29f1f52:	ja     29f2e55 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x3035>
 29f1f58:	lea    0x14(%rdx,%rsi,1),%r13
 29f1f5d:	mov    %r13,%rsi
 29f1f60:	add    %r12,%rsi
 29f1f63:	jb     29f2e57 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x3037>
 29f1f69:	lea    (%rdx,%rcx,1),%rdi
 29f1f6d:	cmp    %rdi,%rsi
 29f1f70:	ja     29f2e59 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x3039>
 29f1f76:	mov    0x20(%rsp),%r8d
 29f1f7b:	mov    (%rsp),%ecx
 29f1f7e:	mov    %rcx,0x80(%rsp)
 29f1f86:	mov    0x10(%rsp),%esi
 29f1f8a:	mov    0x18(%rsp),%edx
 29f1f8e:	lea    0x14(%rax,%r14,4),%r12
 29f1f93:	test   %r14,%r14
 29f1f96:	je     29f2002 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x21e2>
 29f1f9c:	mov    %r8d,0x18(%rsp)
 29f1fa1:	mov    0x80(%rsp),%r14
 29f1fa9:	mov    %r14d,0x10(%rsp)
 29f1fae:	mov    %esi,(%rsp)
 29f1fb1:	mov    %edx,0x20(%rsp)
 29f1fb5:	mov    0xd8(%rsp),%r14
 29f1fbd:	mov    (%r14),%rcx
 29f1fc0:	mov    0x98(%rsp),%rax
 29f1fc8:	cmp    %rax,%rcx
 29f1fcb:	jae    29f2bc6 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2da6>
 29f1fd1:	movl   $0x0,0x0(%r13)
 29f1fd9:	mov    0x18(%rsp),%r8d
 29f1fde:	mov    0x10(%rsp),%r14d
 29f1fe3:	mov    %r14,0x80(%rsp)
 29f1feb:	mov    (%rsp),%esi
 29f1fee:	mov    0x20(%rsp),%edx
 29f1ff2:	add    $0x4,%r13
 29f1ff9:	cmp    %r12,%r13
 29f1ffc:	jne    29f1f9c <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x217c>
 29f2002:	mov    0x8(%rsp),%r9d
 29f2007:	test   %r9d,%r9d
 29f200a:	je     29f2e5b <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x303b>
 29f2010:	test   %r8d,%r8d
 29f2013:	je     29f2e5d <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x303d>
 29f2019:	test   %r9d,%r9d
 29f201c:	je     29f2e5f <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x303f>
 29f2022:	mov    0xd0(%rsp),%r13
 29f202a:	mov    0x28(%r13),%r10
 29f202e:	mov    0x20(%r13),%rax
 29f2032:	mov    %r9d,%r12d
 29f2035:	lea    (%rax,%r12,1),%rdi
 29f2039:	lea    0x10(%rax,%r12,1),%r11
 29f203e:	xor    %r14,%r14
 29f2041:	cmp    %r10,%r12
 29f2044:	cmova  %r14,%r11
 29f2048:	mov    (%r11),%ecx
 29f204b:	mov    0xa8(%rsp),%r11
 29f2053:	cmp    %rcx,%r11
 29f2056:	ja     29f2e61 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x3041>
 29f205c:	test   %r8d,%r8d
 29f205f:	je     29f2e63 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x3043>
 29f2065:	mov    %r8d,%r13d
 29f2068:	lea    (%rax,%r13,1),%r11
 29f206c:	lea    0x10(%rax,%r13,1),%r15
 29f2071:	cmp    %r10,%r13
 29f2074:	cmova  %r14,%r15
 29f2078:	mov    (%r15),%ecx
 29f207b:	mov    0xa8(%rsp),%r14
 29f2083:	cmp    %rcx,%r14
 29f2086:	ja     29f2e65 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x3045>
 29f208c:	lea    0x14(%rax,%r12,1),%r12
 29f2091:	shl    $0x2,%r14
 29f2095:	mov    %r12,%r15
 29f2098:	add    %r14,%r15
 29f209b:	jb     29f2e67 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x3047>
 29f20a1:	add    %rax,%r10
 29f20a4:	cmp    %r10,%r15
 29f20a7:	ja     29f2e69 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x3049>
 29f20ad:	lea    0x14(%rax,%r13,1),%rax
 29f20b2:	mov    %rax,%rbx
 29f20b5:	add    %r14,%rbx
 29f20b8:	mov    %rax,0x90(%rsp)
 29f20c0:	jb     29f2e6b <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x304b>
 29f20c6:	cmp    %r10,%rbx
 29f20c9:	ja     29f2e6d <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x304d>
 29f20cf:	mov    0x88(%rsp),%rax
 29f20d7:	mov    0x88(%rsp),%rbx
 29f20df:	test   %eax,%ebx
 29f20e1:	jne    29f20fc <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x22dc>
 29f20e7:	mov    0x80(%rsp),%rdi
 29f20ef:	mov    0x80(%rsp),%r14
 29f20f7:	jmp    29f22be <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x249e>
 29f20fc:	mov    0x8(%rsp),%r10d
 29f2101:	xor    %r15d,%r15d
 29f2104:	mov    0xa8(%rsp),%r14
 29f210c:	lea    0x14(%rdi,%r14,4),%r14
 29f2111:	mov    0xa8(%rsp),%rax
 29f2119:	lea    0x14(%r11,%rax,4),%r13
 29f211e:	mov    0x90(%rsp),%rax
 29f2126:	mov    %r13,%rbx
 29f2129:	cmp    %rax,%r12
 29f212c:	jae    29f213d <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x231d>
 29f2132:	mov    %r10,%r9
 29f2135:	mov    %rbx,%r13
 29f2138:	jmp    29f21fb <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x23db>
 29f213d:	mov    %r10,%r9
 29f2140:	mov    %r10d,0x28(%rsp)
 29f2145:	mov    %r8d,0x20(%rsp)
 29f214a:	mov    0x80(%rsp),%rdi
 29f2152:	mov    %edi,(%rsp)
 29f2155:	mov    %r9d,0x10(%rsp)
 29f215a:	mov    %esi,0x18(%rsp)
 29f215e:	mov    %edx,0x8(%rsp)
 29f2162:	mov    0xd8(%rsp),%rax
 29f216a:	mov    (%rax),%rcx
 29f216d:	mov    0x98(%rsp),%rax
 29f2175:	cmp    %rax,%rcx
 29f2178:	jae    29f2bfa <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2dda>
 29f217e:	mov    %rbx,%r13
 29f2181:	jmp    29f2189 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2369>
 29f2186:	mov    %rbx,%r13
 29f2189:	sub    $0x4,%r13
 29f218d:	mov    0x0(%r13),%edx
 29f2191:	sub    $0x4,%r14
 29f2195:	mov    %edx,(%r14)
 29f2198:	mov    (%rsp),%eax
 29f219b:	mov    %rax,0x80(%rsp)
 29f21a3:	mov    0x10(%rsp),%r9d
 29f21a8:	mov    0x18(%rsp),%esi
 29f21ac:	mov    0x8(%rsp),%edx
 29f21b0:	mov    0x28(%rsp),%r10d
 29f21b5:	mov    0x20(%rsp),%r8d
 29f21ba:	mov    0x88(%rsp),%rbx
 29f21c2:	sub    $0x1,%ebx
 29f21c5:	mov    0x90(%rsp),%r12
 29f21cd:	mov    %rbx,0x88(%rsp)
 29f21d5:	cmp    %r12,%r13
 29f21d8:	jne    29f21f3 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x23d3>
 29f21de:	mov    0x80(%rsp),%rdi
 29f21e6:	mov    0x80(%rsp),%r14
 29f21ee:	jmp    29f22be <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x249e>
 29f21f3:	mov    %r13,%rbx
 29f21f6:	jmp    29f2140 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2320>
 29f21fb:	mov    %r10d,0x20(%rsp)
 29f2200:	mov    %r8d,0x28(%rsp)
 29f2205:	mov    0x80(%rsp),%r14
 29f220d:	mov    %r14d,0x8(%rsp)
 29f2212:	mov    %r9d,0x18(%rsp)
 29f2217:	mov    %esi,0x10(%rsp)
 29f221b:	mov    %edx,(%rsp)
 29f221e:	mov    0xd8(%rsp),%r14
 29f2226:	mov    (%r14),%rcx
 29f2229:	mov    0x98(%rsp),%rax
 29f2231:	cmp    %rax,%rcx
 29f2234:	jae    29f2c31 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2e11>
 29f223a:	mov    0x90(%rsp),%rax
 29f2242:	jmp    29f224f <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x242f>
 29f2247:	mov    0x90(%rsp),%rax
 29f224f:	mov    0x90(%rsp),%rax
 29f2257:	mov    (%rax),%eax
 29f2259:	mov    %eax,(%r12)
 29f225d:	mov    0x8(%rsp),%r14d
 29f2262:	mov    %r14,0x80(%rsp)
 29f226a:	mov    0x18(%rsp),%r9d
 29f226f:	mov    0x10(%rsp),%esi
 29f2273:	mov    (%rsp),%edx
 29f2276:	mov    0x20(%rsp),%r10d
 29f227b:	mov    0x28(%rsp),%r8d
 29f2280:	mov    0x90(%rsp),%rax
 29f2288:	add    $0x4,%rax
 29f228f:	mov    %rax,0x90(%rsp)
 29f2297:	add    $0x4,%r12
 29f229e:	add    $0x1,%r15d
 29f22a5:	cmp    %r13,%rax
 29f22a8:	jne    29f21fb <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x23db>
 29f22ae:	mov    0x80(%rsp),%rdi
 29f22b6:	mov    0x80(%rsp),%r14
 29f22be:	test   %edi,%r14d
 29f22c1:	je     29f2e6f <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x304f>
 29f22c7:	test   %r9d,%r9d
 29f22ca:	je     29f2e71 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x3051>
 29f22d0:	mov    0x80(%rsp),%r11
 29f22d8:	mov    0x80(%rsp),%r14
 29f22e0:	test   %r11d,%r14d
 29f22e3:	je     29f2e73 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x3053>
 29f22e9:	mov    0xd0(%rsp),%r13
 29f22f1:	mov    0x28(%r13),%rax
 29f22f5:	mov    %r14d,%r8d
 29f22f8:	mov    %r8,%rdi
 29f22fb:	add    0x20(%r13),%rdi
 29f22ff:	xor    %r10,%r10
 29f2302:	cmp    %rax,%r8
 29f2305:	cmova  %r10,%rdi
 29f2309:	mov    %r9d,0x30(%rdi)
 29f230d:	mov    %esi,(%rsp)
 29f2310:	mov    %r9d,0x10(%rsp)
 29f2315:	mov    0x80(%rsp),%r14
 29f231d:	mov    %r14d,0x18(%rsp)
 29f2322:	mov    %edx,0x8(%rsp)
 29f2326:	mov    0x60(%rsp),%rsi
 29f232b:	mov    0x20(%rsi),%rsi
 29f232f:	mov    (%rsi),%eax
 29f2331:	mov    %eax,%ecx
 29f2333:	mov    $0x20,%edx
 29f2338:	lea    0x20(%rcx),%rdi
 29f233c:	mov    0x4(%rsi),%r8d
 29f2340:	cmp    %r8,%rdi
 29f2343:	ja     29f2c6d <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2e4d>
 29f2349:	lea    0x20(%rax),%edi
 29f234c:	mov    %edi,(%rsi)
 29f234e:	mov    0xd0(%rsp),%r13
 29f2356:	mov    0x20(%r13),%rdi
 29f235a:	lea    (%rdi,%rcx,1),%rsi
 29f235e:	movl   $0xb0000042,(%rdi,%rcx,1)
 29f2365:	mov    0x60(%rsp),%r8
 29f236a:	mov    0x28(%r8),%r8
 29f236e:	mov    0x120(%r8),%r8d
 29f2375:	mov    %r8d,0x4(%rdi,%rcx,1)
 29f237a:	mov    %edx,0x8(%rdi,%rcx,1)
 29f237e:	mov    0x78(%rsp),%r14
 29f2383:	mov    %r14,0x10(%rsi)
 29f2387:	mov    0x70(%rsp),%r9
 29f238c:	mov    %r9d,0x18(%rsi)
 29f2390:	mov    (%rsp),%ecx
 29f2393:	mov    %ecx,0x1c(%rsi)
 29f2396:	mov    0x10(%rsp),%ecx
 29f239a:	test   %ecx,%ecx
 29f239c:	je     29f2e75 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x3055>
 29f23a2:	test   %ecx,%ecx
 29f23a4:	je     29f2e77 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x3057>
 29f23aa:	mov    0xd0(%rsp),%r13
 29f23b2:	mov    0x28(%r13),%rdx
 29f23b6:	mov    0x20(%r13),%rsi
 29f23ba:	mov    %ecx,%r9d
 29f23bd:	lea    0x10(%rsi,%r9,1),%r8
 29f23c2:	xor    %rdi,%rdi
 29f23c5:	cmp    %rdx,%r9
 29f23c8:	cmova  %rdi,%r8
 29f23cc:	mov    (%r8),%r8d
 29f23cf:	mov    0x68(%rsp),%r9
 29f23d4:	cmp    %r8d,%r9d
 29f23d7:	jae    29f2e79 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x3059>
 29f23dd:	mov    %r8d,%r9d
 29f23e0:	shl    $0x2,%r9
 29f23e4:	shr    $0x20,%r9
 29f23e8:	test   %r9,%r9
 29f23eb:	jne    29f2e7b <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x305b>
 29f23f1:	shl    $0x2,%r8d
 29f23f5:	add    $0x14,%r8d
 29f23f9:	jb     29f2e7d <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x305d>
 29f23ff:	add    %r8d,%ecx
 29f2402:	jb     29f2e7f <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x305f>
 29f2408:	mov    %ecx,%ecx
 29f240a:	add    %rcx,%rsi
 29f240d:	cmp    %rdx,%rcx
 29f2410:	cmova  %rdi,%rsi
 29f2414:	mov    0x68(%rsp),%rcx
 29f2419:	shl    $0x2,%ecx
 29f241c:	lea    0x14(%rcx),%edx
 29f241f:	sub    %edx,%r8d
 29f2422:	sub    %r8,%rsi
 29f2425:	mov    (%rsi),%edx
 29f2427:	test   %edx,%edx
 29f2429:	jne    29f247b <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x265b>
 29f242f:	mov    0x18(%rsp),%edx
 29f2433:	test   %edx,%edx
 29f2435:	je     29f2e81 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x3061>
 29f243b:	test   %edx,%edx
 29f243d:	je     29f2e83 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x3063>
 29f2443:	mov    0xd0(%rsp),%r13
 29f244b:	mov    0x28(%r13),%rdi
 29f244f:	mov    0xb0(%rsp),%r13
 29f2457:	lea    0x1(%r13),%rsi
 29f245b:	mov    %edx,%r8d
 29f245e:	mov    0xd0(%rsp),%r13
 29f2466:	mov    %r8,%rdx
 29f2469:	add    0x20(%r13),%rdx
 29f246d:	xor    %r9,%r9
 29f2470:	cmp    %rdi,%r8
 29f2473:	cmova  %r9,%rdx
 29f2477:	mov    %rsi,0x18(%rdx)
 29f247b:	mov    0x10(%rsp),%edx
 29f247f:	test   %edx,%edx
 29f2481:	je     29f2e85 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x3065>
 29f2487:	test   %eax,%eax
 29f2489:	je     29f2e87 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x3067>
 29f248f:	test   %edx,%edx
 29f2491:	je     29f2e89 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x3069>
 29f2497:	mov    0xd0(%rsp),%r13
 29f249f:	mov    0x28(%r13),%rsi
 29f24a3:	mov    0x20(%r13),%rdi
 29f24a7:	mov    %edx,%r9d
 29f24aa:	lea    0x10(%rdi,%r9,1),%r11
 29f24af:	xor    %r8,%r8
 29f24b2:	cmp    %rsi,%r9
 29f24b5:	cmova  %r8,%r11
 29f24b9:	mov    (%r11),%r9d
 29f24bc:	mov    0x68(%rsp),%r10
 29f24c1:	cmp    %r9d,%r10d
 29f24c4:	jae    29f2e8b <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x306b>
 29f24ca:	mov    %r9d,%r10d
 29f24cd:	shl    $0x2,%r10
 29f24d1:	shr    $0x20,%r10
 29f24d5:	test   %r10,%r10
 29f24d8:	jne    29f2e8d <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x306d>
 29f24de:	shl    $0x2,%r9d
 29f24e2:	add    $0x14,%r9d
 29f24e6:	jb     29f2e8f <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x306f>
 29f24ec:	add    %r9d,%edx
 29f24ef:	jb     29f2e91 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x3071>
 29f24f5:	mov    %edx,%r10d
 29f24f8:	lea    (%rdi,%r10,1),%rdx
 29f24fc:	cmp    %rsi,%r10
 29f24ff:	cmova  %r8,%rdx
 29f2503:	add    $0x14,%ecx
 29f2509:	sub    %ecx,%r9d
 29f250c:	sub    %r9,%rdx
 29f250f:	mov    %eax,(%rdx)
 29f2511:	mov    (%rsp),%esi
 29f2514:	mov    0x8(%rsp),%edx
 29f2518:	mov    $0x1,%r10d
 29f251e:	mov    %esi,0x8(%rsp)
 29f2522:	mov    %edx,(%rsp)
 29f2525:	test   %r10d,%r10d
 29f2528:	jne    29f2683 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2863>
 29f252e:	mov    0x60(%rsp),%rsi
 29f2533:	mov    0x20(%rsi),%r12
 29f2537:	mov    (%r12),%eax
 29f253b:	mov    %eax,%ecx
 29f253d:	mov    $0x20,%r13d
 29f2543:	lea    0x20(%rcx),%rdx
 29f2547:	mov    0x4(%r12),%esi
 29f254c:	cmp    %rsi,%rdx
 29f254f:	ja     29f2cae <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2e8e>
 29f2555:	lea    0x20(%rax),%edx
 29f2558:	mov    %edx,(%r12)
 29f255c:	mov    0xd0(%rsp),%rdx
 29f2564:	mov    0x20(%rdx),%rsi
 29f2568:	lea    (%rsi,%rcx,1),%rdx
 29f256c:	movl   $0xb0000042,(%rsi,%rcx,1)
 29f2573:	mov    0x60(%rsp),%rdi
 29f2578:	mov    0x28(%rdi),%rdi
 29f257c:	mov    0x120(%rdi),%edi
 29f2582:	mov    %edi,0x4(%rsi,%rcx,1)
 29f2586:	mov    %r13d,0x8(%rsi,%rcx,1)
 29f258b:	mov    %eax,0x10(%rsp)
 29f258f:	mov    %r14,0x10(%rdx)
 29f2593:	mov    0x70(%rsp),%r9
 29f2598:	mov    %r9d,0x18(%rdx)
 29f259c:	mov    0x8(%rsp),%ecx
 29f25a0:	mov    %ecx,0x1c(%rdx)
 29f25a3:	mov    0x60(%rsp),%rsi
 29f25a8:	mov    0xa20(%rsi),%ecx
 29f25ae:	mov    %ecx,0x8(%rsp)
 29f25b2:	test   %eax,%eax
 29f25b4:	je     29f2e93 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x3073>
 29f25ba:	test   %ecx,%ecx
 29f25bc:	je     29f2e95 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x3075>
 29f25c2:	mov    (%r12),%r8d
 29f25c6:	mov    %r8d,%ecx
 29f25c9:	lea    0x20(%rcx),%rax
 29f25cd:	mov    0x4(%r12),%edx
 29f25d2:	cmp    %rdx,%rax
 29f25d5:	ja     29f2cea <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2eca>
 29f25db:	lea    0x20(%r8),%eax
 29f25df:	mov    %eax,(%r12)
 29f25e3:	mov    0xd0(%rsp),%rax
 29f25eb:	mov    0x20(%rax),%rdx
 29f25ef:	lea    (%rdx,%rcx,1),%rsi
 29f25f3:	movl   $0xb0000072,(%rdx,%rcx,1)
 29f25fa:	mov    0x60(%rsp),%rax
 29f25ff:	mov    0x28(%rax),%rax
 29f2603:	mov    0x13c(%rax),%eax
 29f2609:	mov    %eax,0x4(%rdx,%rcx,1)
 29f260d:	mov    %r13d,0x8(%rdx,%rcx,1)
 29f2612:	movl   $0xe,0x10(%rsi)
 29f2619:	mov    0x10(%rsp),%eax
 29f261d:	mov    %eax,0x14(%rsi)
 29f2620:	mov    0x8(%rsp),%eax
 29f2624:	mov    %eax,0x18(%rsi)
 29f2627:	mov    %eax,0x1c(%rsi)
 29f262a:	mov    (%rsp),%eax
 29f262d:	test   %eax,%eax
 29f262f:	je     29f2e97 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x3077>
 29f2635:	test   %eax,%eax
 29f2637:	je     29f2e99 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x3079>
 29f263d:	mov    0xd0(%rsp),%r13
 29f2645:	mov    0x28(%r13),%rcx
 29f2649:	mov    0x20(%r13),%rsi
 29f264d:	mov    %eax,%edx
 29f264f:	lea    (%rsi,%rdx,1),%rax
 29f2653:	xor    %rsi,%rsi
 29f2656:	cmp    %rcx,%rdx
 29f2659:	cmova  %rsi,%rax
 29f265d:	mov    0x14(%rax),%edx
 29f2660:	test   %edx,%edx
 29f2662:	je     29f2e9b <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x307b>
 29f2668:	test   %r8d,%r8d
 29f266b:	je     29f2e9d <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x307d>
 29f2671:	mov    0x68(%rsp),%rcx
 29f2676:	mov    0x60(%rsp),%rsi
 29f267b:	mov    %rsi,%rdi
 29f267e:	call   29f6be0 <wasm[0]::function[1013]::helper::array_indexed_publish>
 29f2683:	mov    0xe0(%rsp),%rbx
 29f268b:	mov    0xe8(%rsp),%r12
 29f2693:	mov    0xf0(%rsp),%r13
 29f269b:	mov    0xf8(%rsp),%r14
 29f26a3:	mov    0x100(%rsp),%r15
 29f26ab:	add    $0x110,%rsp
 29f26b2:	mov    %rbp,%rsp
 29f26b5:	pop    %rbp
 29f26b6:	ret    $0x10
 29f26b9:	mov    0x60(%rsp),%rdi
 29f26be:	call   3039b69 <wasmtime_builtin_new_epoch>
 29f26c3:	mov    %rax,0x98(%rsp)
 29f26cb:	jmp    29efec2 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0xa2>
 29f26d0:	mov    0xd0(%rsp),%r13
 29f26d8:	mov    0x8(%r13),%rcx
 29f26dc:	mov    %rcx,0x98(%rsp)
 29f26e4:	cmp    %rcx,%rax
 29f26e7:	jb     29f00aa <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x28a>
 29f26ed:	mov    0x60(%rsp),%rdi
 29f26f2:	call   3039b69 <wasmtime_builtin_new_epoch>
 29f26f7:	mov    %rax,0x98(%rsp)
 29f26ff:	jmp    29f00aa <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x28a>
 29f2704:	mov    $0xa8000006,%esi
 29f2709:	mov    0x60(%rsp),%rax
 29f270e:	mov    0x28(%rax),%rax
 29f2712:	mov    0x1a0(%rax),%edx
 29f2718:	mov    $0x10,%r8d
 29f271e:	mov    0x60(%rsp),%rdi
 29f2723:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 29f2728:	mov    %eax,%ecx
 29f272a:	mov    0xd0(%rsp),%r13
 29f2732:	add    0x20(%r13),%rcx
 29f2736:	jmp    29f0194 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x374>
 29f273b:	mov    0xd0(%rsp),%r13
 29f2743:	mov    0x8(%r13),%rcx
 29f2747:	mov    %rcx,0x98(%rsp)
 29f274f:	cmp    %rcx,%rax
 29f2752:	jb     29f024e <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x42e>
 29f2758:	mov    0x60(%rsp),%rdi
 29f275d:	call   3039b69 <wasmtime_builtin_new_epoch>
 29f2762:	mov    %rax,0x98(%rsp)
 29f276a:	jmp    29f024e <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x42e>
 29f276f:	mov    0xd0(%rsp),%r13
 29f2777:	mov    0x8(%r13),%r9
 29f277b:	mov    %r9,%r11
 29f277e:	mov    %r9,0x98(%rsp)
 29f2786:	cmp    %r11,%rax
 29f2789:	jb     29f02d9 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x4b9>
 29f278f:	mov    0x60(%rsp),%rdi
 29f2794:	call   3039b69 <wasmtime_builtin_new_epoch>
 29f2799:	mov    %rax,0x98(%rsp)
 29f27a1:	jmp    29f02d9 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x4b9>
 29f27a6:	mov    0xd0(%rsp),%r13
 29f27ae:	mov    0x8(%r13),%rcx
 29f27b2:	mov    %rcx,0x98(%rsp)
 29f27ba:	cmp    %rcx,%rax
 29f27bd:	jb     29f041f <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x5ff>
 29f27c3:	mov    0x60(%rsp),%rdi
 29f27c8:	call   3039b69 <wasmtime_builtin_new_epoch>
 29f27cd:	mov    %rax,0x98(%rsp)
 29f27d5:	jmp    29f041f <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x5ff>
 29f27da:	mov    0xd0(%rsp),%r13
 29f27e2:	mov    0x8(%r13),%r10
 29f27e6:	mov    %r10,%rcx
 29f27e9:	mov    %r10,0x98(%rsp)
 29f27f1:	cmp    %rcx,%rax
 29f27f4:	jb     29f04fd <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x6dd>
 29f27fa:	mov    0x60(%rsp),%rdi
 29f27ff:	call   3039b69 <wasmtime_builtin_new_epoch>
 29f2804:	mov    %rax,0x98(%rsp)
 29f280c:	jmp    29f04fd <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x6dd>
 29f2811:	mov    0xd0(%rsp),%r13
 29f2819:	mov    0x8(%r13),%rcx
 29f281d:	mov    %rcx,0x98(%rsp)
 29f2825:	cmp    %rcx,%rax
 29f2828:	jb     29f05a4 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x784>
 29f282e:	mov    0x60(%rsp),%rdi
 29f2833:	call   3039b69 <wasmtime_builtin_new_epoch>
 29f2838:	mov    %rax,0x98(%rsp)
 29f2840:	mov    %rbx,%rcx
 29f2843:	mov    %r15,%rdx
 29f2846:	mov    %r12,%rsi
 29f2849:	jmp    29f05ad <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x78d>
 29f284e:	mov    $0xa8000006,%esi
 29f2853:	mov    0x60(%rsp),%r10
 29f2858:	mov    0x28(%r10),%r11
 29f285c:	mov    0x1a4(%r11),%edx
 29f2863:	mov    $0x10,%r8d
 29f2869:	mov    0x60(%rsp),%rdi
 29f286e:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 29f2873:	mov    %eax,%ecx
 29f2875:	mov    0xd0(%rsp),%r13
 29f287d:	add    0x20(%r13),%rcx
 29f2881:	jmp    29f06de <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x8be>
 29f2886:	mov    0xd0(%rsp),%r13
 29f288e:	mov    0x8(%r13),%rcx
 29f2892:	mov    %rcx,0x98(%rsp)
 29f289a:	cmp    %rcx,%rax
 29f289d:	jb     29f0797 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x977>
 29f28a3:	mov    0x60(%rsp),%rdi
 29f28a8:	call   3039b69 <wasmtime_builtin_new_epoch>
 29f28ad:	mov    %rax,0x98(%rsp)
 29f28b5:	jmp    29f0797 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x977>
 29f28ba:	mov    0xd0(%rsp),%r13
 29f28c2:	mov    0x8(%r13),%rsi
 29f28c6:	mov    %rsi,0x98(%rsp)
 29f28ce:	cmp    %rsi,%rax
 29f28d1:	jb     29f0822 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0xa02>
 29f28d7:	mov    0x60(%rsp),%rdi
 29f28dc:	call   3039b69 <wasmtime_builtin_new_epoch>
 29f28e1:	mov    %rax,0x98(%rsp)
 29f28e9:	jmp    29f0822 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0xa02>
 29f28ee:	mov    0xd0(%rsp),%r13
 29f28f6:	mov    0x8(%r13),%rcx
 29f28fa:	mov    %rcx,0x98(%rsp)
 29f2902:	cmp    %rcx,%rax
 29f2905:	jb     29f0966 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0xb46>
 29f290b:	mov    0x60(%rsp),%rdi
 29f2910:	call   3039b69 <wasmtime_builtin_new_epoch>
 29f2915:	mov    %rax,0x98(%rsp)
 29f291d:	jmp    29f0966 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0xb46>
 29f2922:	mov    0xd0(%rsp),%r13
 29f292a:	mov    0x8(%r13),%rsi
 29f292e:	mov    %rsi,0x98(%rsp)
 29f2936:	cmp    %rsi,%rax
 29f2939:	jb     29f0a44 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0xc24>
 29f293f:	mov    0x60(%rsp),%rdi
 29f2944:	call   3039b69 <wasmtime_builtin_new_epoch>
 29f2949:	mov    %rax,0x98(%rsp)
 29f2951:	jmp    29f0a44 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0xc24>
 29f2956:	mov    0xd0(%rsp),%r13
 29f295e:	mov    0x8(%r13),%rax
 29f2962:	mov    %rax,0x98(%rsp)
 29f296a:	cmp    %rax,%r8
 29f296d:	jb     29f0aeb <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0xccb>
 29f2973:	mov    0x60(%rsp),%rdi
 29f2978:	call   3039b69 <wasmtime_builtin_new_epoch>
 29f297d:	mov    %rax,0x98(%rsp)
 29f2985:	mov    %rbx,%rcx
 29f2988:	mov    %r12,%rdx
 29f298b:	mov    %r15,%rsi
 29f298e:	jmp    29f0af4 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0xcd4>
 29f2993:	mov    $0xa8000006,%esi
 29f2998:	mov    0x60(%rsp),%rax
 29f299d:	mov    0x28(%rax),%rax
 29f29a1:	mov    0x1a4(%rax),%edx
 29f29a7:	mov    $0x10,%r8d
 29f29ad:	mov    0x60(%rsp),%rdi
 29f29b2:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 29f29b7:	mov    %eax,%edi
 29f29b9:	mov    0xd0(%rsp),%r13
 29f29c1:	add    0x20(%r13),%rdi
 29f29c5:	jmp    29f0d3d <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0xf1d>
 29f29ca:	mov    0xd0(%rsp),%r13
 29f29d2:	mov    0x8(%r13),%rcx
 29f29d6:	mov    %rcx,0x98(%rsp)
 29f29de:	cmp    %rcx,%rax
 29f29e1:	jb     29f0df6 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0xfd6>
 29f29e7:	mov    0x60(%rsp),%rdi
 29f29ec:	call   3039b69 <wasmtime_builtin_new_epoch>
 29f29f1:	mov    %rax,0x98(%rsp)
 29f29f9:	jmp    29f0df6 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0xfd6>
 29f29fe:	mov    0xd0(%rsp),%r13
 29f2a06:	mov    0x8(%r13),%rcx
 29f2a0a:	mov    %rcx,0x98(%rsp)
 29f2a12:	cmp    %rcx,%rax
 29f2a15:	jb     29f0e77 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1057>
 29f2a1b:	mov    0x60(%rsp),%rdi
 29f2a20:	call   3039b69 <wasmtime_builtin_new_epoch>
 29f2a25:	mov    %rax,0x98(%rsp)
 29f2a2d:	jmp    29f0e77 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1057>
 29f2a32:	mov    0xd0(%rsp),%r13
 29f2a3a:	mov    0x8(%r13),%rax
 29f2a3e:	mov    %rax,0x98(%rsp)
 29f2a46:	cmp    %rax,%rcx
 29f2a49:	jb     29f0ee3 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x10c3>
 29f2a4f:	mov    0x60(%rsp),%rdi
 29f2a54:	call   3039b69 <wasmtime_builtin_new_epoch>
 29f2a59:	mov    %rax,0x98(%rsp)
 29f2a61:	jmp    29f0ee3 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x10c3>
 29f2a66:	mov    $0xa800000e,%esi
 29f2a6b:	mov    0x60(%rsp),%rax
 29f2a70:	mov    0x28(%rax),%rax
 29f2a74:	mov    0x19c(%rax),%edx
 29f2a7a:	mov    $0x10,%r8d
 29f2a80:	mov    0x60(%rsp),%rdi
 29f2a85:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 29f2a8a:	mov    %eax,%ecx
 29f2a8c:	mov    0xd0(%rsp),%rdx
 29f2a94:	add    0x20(%rdx),%rcx
 29f2a98:	jmp    29f1661 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1841>
 29f2a9d:	mov    0xd0(%rsp),%rdi
 29f2aa5:	mov    0x8(%rdi),%r8
 29f2aa9:	mov    %r8,%r10
 29f2aac:	mov    %r8,0x98(%rsp)
 29f2ab4:	cmp    %r10,%rax
 29f2ab7:	jb     29f170e <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x18ee>
 29f2abd:	mov    0x60(%rsp),%rdi
 29f2ac2:	call   3039b69 <wasmtime_builtin_new_epoch>
 29f2ac7:	mov    %rax,0x98(%rsp)
 29f2acf:	jmp    29f170e <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x18ee>
 29f2ad4:	mov    0xd0(%rsp),%r13
 29f2adc:	mov    0x8(%r13),%rcx
 29f2ae0:	mov    %rcx,0x98(%rsp)
 29f2ae8:	cmp    %rcx,%rax
 29f2aeb:	jb     29f17a7 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1987>
 29f2af1:	mov    0x60(%rsp),%rdi
 29f2af6:	call   3039b69 <wasmtime_builtin_new_epoch>
 29f2afb:	mov    %rax,0x98(%rsp)
 29f2b03:	mov    0xc8(%rsp),%rcx
 29f2b0b:	jmp    29f17af <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x198f>
 29f2b10:	mov    $0xb0000042,%esi
 29f2b15:	mov    $0x20,%ecx
 29f2b1a:	mov    0x88(%rsp),%r13
 29f2b22:	mov    %r13,%rdx
 29f2b25:	mov    0x60(%rsp),%rdi
 29f2b2a:	mov    0xb0(%rsp),%r8
 29f2b32:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 29f2b37:	mov    %eax,%r10d
 29f2b3a:	mov    0xd0(%rsp),%rcx
 29f2b42:	add    0x20(%rcx),%r10
 29f2b46:	mov    0xc0(%rsp),%rcx
 29f2b4e:	mov    0x90(%rsp),%rdx
 29f2b56:	jmp    29f1b41 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x1d21>
 29f2b5b:	mov    0xd0(%rsp),%rcx
 29f2b63:	mov    0x8(%rcx),%rcx
 29f2b67:	mov    %rcx,0x98(%rsp)
 29f2b6f:	cmp    %rcx,%rax
 29f2b72:	jb     29f1e52 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2032>
 29f2b78:	mov    0x60(%rsp),%rdi
 29f2b7d:	call   3039b69 <wasmtime_builtin_new_epoch>
 29f2b82:	mov    %rax,0x98(%rsp)
 29f2b8a:	jmp    29f1e52 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2032>
 29f2b8f:	mov    $0xa800000e,%esi
 29f2b94:	mov    0x60(%rsp),%rax
 29f2b99:	mov    0x28(%rax),%rax
 29f2b9d:	mov    0x19c(%rax),%edx
 29f2ba3:	mov    $0x10,%r8d
 29f2ba9:	mov    0x60(%rsp),%rdi
 29f2bae:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 29f2bb3:	mov    %eax,%ecx
 29f2bb5:	mov    0xd0(%rsp),%rdx
 29f2bbd:	add    0x20(%rdx),%rcx
 29f2bc1:	jmp    29f1f18 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x20f8>
 29f2bc6:	mov    0xd0(%rsp),%rax
 29f2bce:	mov    0x8(%rax),%rax
 29f2bd2:	mov    %rax,0x98(%rsp)
 29f2bda:	cmp    %rax,%rcx
 29f2bdd:	jb     29f1fd1 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x21b1>
 29f2be3:	mov    0x60(%rsp),%rdi
 29f2be8:	call   3039b69 <wasmtime_builtin_new_epoch>
 29f2bed:	mov    %rax,0x98(%rsp)
 29f2bf5:	jmp    29f1fd1 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x21b1>
 29f2bfa:	mov    0xd0(%rsp),%r13
 29f2c02:	mov    0x8(%r13),%rax
 29f2c06:	mov    %rax,0x98(%rsp)
 29f2c0e:	cmp    %rax,%rcx
 29f2c11:	jb     29f2186 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2366>
 29f2c17:	mov    0x60(%rsp),%rdi
 29f2c1c:	call   3039b69 <wasmtime_builtin_new_epoch>
 29f2c21:	mov    %rax,0x98(%rsp)
 29f2c29:	mov    %rbx,%r13
 29f2c2c:	jmp    29f2189 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2369>
 29f2c31:	mov    0xd0(%rsp),%r8
 29f2c39:	mov    0x8(%r8),%rax
 29f2c3d:	mov    %rax,0x98(%rsp)
 29f2c45:	cmp    %rax,%rcx
 29f2c48:	jb     29f2247 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2427>
 29f2c4e:	mov    0x60(%rsp),%rdi
 29f2c53:	call   3039b69 <wasmtime_builtin_new_epoch>
 29f2c58:	mov    %rax,0x98(%rsp)
 29f2c60:	mov    0x90(%rsp),%rax
 29f2c68:	jmp    29f224f <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x242f>
 29f2c6d:	mov    $0xb0000042,%esi
 29f2c72:	mov    0x60(%rsp),%rax
 29f2c77:	mov    0x28(%rax),%rax
 29f2c7b:	mov    0x120(%rax),%edx
 29f2c81:	mov    $0x20,%ecx
 29f2c86:	mov    $0x10,%r8d
 29f2c8c:	mov    0x60(%rsp),%rdi
 29f2c91:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 29f2c96:	mov    %eax,%esi
 29f2c98:	mov    0xd0(%rsp),%r13
 29f2ca0:	add    0x20(%r13),%rsi
 29f2ca4:	mov    0x78(%rsp),%r14
 29f2ca9:	jmp    29f2383 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x2563>
 29f2cae:	mov    $0xb0000042,%esi
 29f2cb3:	mov    0x60(%rsp),%rax
 29f2cb8:	mov    0x28(%rax),%rax
 29f2cbc:	mov    0x120(%rax),%edx
 29f2cc2:	mov    $0x20,%ecx
 29f2cc7:	mov    $0x10,%r8d
 29f2ccd:	mov    0x60(%rsp),%rdi
 29f2cd2:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 29f2cd7:	mov    %eax,%edx
 29f2cd9:	mov    0xd0(%rsp),%rcx
 29f2ce1:	add    0x20(%rcx),%rdx
 29f2ce5:	jmp    29f258b <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x276b>
 29f2cea:	mov    $0xb0000072,%esi
 29f2cef:	mov    0x60(%rsp),%rax
 29f2cf4:	mov    0x28(%rax),%rax
 29f2cf8:	mov    0x13c(%rax),%edx
 29f2cfe:	mov    $0x20,%ecx
 29f2d03:	mov    $0x10,%r8d
 29f2d09:	mov    0x60(%rsp),%rdi
 29f2d0e:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 29f2d13:	mov    %eax,%esi
 29f2d15:	mov    0xd0(%rsp),%r13
 29f2d1d:	add    0x20(%r13),%rsi
 29f2d21:	mov    %rax,%r8
 29f2d24:	jmp    29f2612 <wasm[0]::function[1008]::helper::array_indexed_publish_default_data+0x27f2>
 29f2d29:	ud2
 29f2d2b:	ud2
 29f2d2d:	ud2
 29f2d2f:	ud2
 29f2d31:	ud2
 29f2d33:	ud2
 29f2d35:	ud2
 29f2d37:	ud2
 29f2d39:	ud2
 29f2d3b:	ud2
 29f2d3d:	ud2
 29f2d3f:	ud2
 29f2d41:	ud2
 29f2d43:	ud2
 29f2d45:	ud2
 29f2d47:	ud2
 29f2d49:	ud2
 29f2d4b:	ud2
 29f2d4d:	ud2
 29f2d4f:	ud2
 29f2d51:	ud2
 29f2d53:	ud2
 29f2d55:	ud2
 29f2d57:	ud2
 29f2d59:	ud2
 29f2d5b:	ud2
 29f2d5d:	ud2
 29f2d5f:	ud2
 29f2d61:	ud2
 29f2d63:	ud2
 29f2d65:	ud2
 29f2d67:	ud2
 29f2d69:	ud2
 29f2d6b:	ud2
 29f2d6d:	ud2
 29f2d6f:	ud2
 29f2d71:	ud2
 29f2d73:	ud2
 29f2d75:	ud2
 29f2d77:	ud2
 29f2d79:	ud2
 29f2d7b:	ud2
 29f2d7d:	ud2
 29f2d7f:	ud2
 29f2d81:	ud2
 29f2d83:	ud2
 29f2d85:	ud2
 29f2d87:	ud2
 29f2d89:	ud2
 29f2d8b:	ud2
 29f2d8d:	ud2
 29f2d8f:	ud2
 29f2d91:	ud2
 29f2d93:	ud2
 29f2d95:	ud2
 29f2d97:	ud2
 29f2d99:	ud2
 29f2d9b:	ud2
 29f2d9d:	ud2
 29f2d9f:	ud2
 29f2da1:	ud2
 29f2da3:	ud2
 29f2da5:	ud2
 29f2da7:	ud2
 29f2da9:	ud2
 29f2dab:	ud2
 29f2dad:	ud2
 29f2daf:	ud2
 29f2db1:	ud2
 29f2db3:	ud2
 29f2db5:	ud2
 29f2db7:	ud2
 29f2db9:	ud2
 29f2dbb:	ud2
 29f2dbd:	ud2
 29f2dbf:	ud2
 29f2dc1:	ud2
 29f2dc3:	ud2
 29f2dc5:	ud2
 29f2dc7:	ud2
 29f2dc9:	ud2
 29f2dcb:	ud2
 29f2dcd:	ud2
 29f2dcf:	ud2
 29f2dd1:	ud2
 29f2dd3:	ud2
 29f2dd5:	ud2
 29f2dd7:	ud2
 29f2dd9:	ud2
 29f2ddb:	ud2
 29f2ddd:	ud2
 29f2ddf:	ud2
 29f2de1:	ud2
 29f2de3:	ud2
 29f2de5:	ud2
 29f2de7:	ud2
 29f2de9:	ud2
 29f2deb:	ud2
 29f2ded:	ud2
 29f2def:	ud2
 29f2df1:	ud2
 29f2df3:	ud2
 29f2df5:	ud2
 29f2df7:	ud2
 29f2df9:	ud2
 29f2dfb:	ud2
 29f2dfd:	ud2
 29f2dff:	ud2
 29f2e01:	ud2
 29f2e03:	ud2
 29f2e05:	ud2
 29f2e07:	ud2
 29f2e09:	ud2
 29f2e0b:	ud2
 29f2e0d:	ud2
 29f2e0f:	ud2
 29f2e11:	ud2
 29f2e13:	ud2
 29f2e15:	ud2
 29f2e17:	ud2
 29f2e19:	ud2
 29f2e1b:	ud2
 29f2e1d:	ud2
 29f2e1f:	ud2
 29f2e21:	ud2
 29f2e23:	ud2
 29f2e25:	ud2
 29f2e27:	ud2
 29f2e29:	ud2
 29f2e2b:	ud2
 29f2e2d:	ud2
 29f2e2f:	ud2
 29f2e31:	ud2
 29f2e33:	ud2
 29f2e35:	ud2
 29f2e37:	ud2
 29f2e39:	ud2
 29f2e3b:	ud2
 29f2e3d:	ud2
 29f2e3f:	ud2
 29f2e41:	ud2
 29f2e43:	ud2
 29f2e45:	ud2
 29f2e47:	ud2
 29f2e49:	ud2
 29f2e4b:	ud2
 29f2e4d:	ud2
 29f2e4f:	ud2
 29f2e51:	ud2
 29f2e53:	ud2
 29f2e55:	ud2
 29f2e57:	ud2
 29f2e59:	ud2
 29f2e5b:	ud2
 29f2e5d:	ud2
 29f2e5f:	ud2
 29f2e61:	ud2
 29f2e63:	ud2
 29f2e65:	ud2
 29f2e67:	ud2
 29f2e69:	ud2
 29f2e6b:	ud2
 29f2e6d:	ud2
 29f2e6f:	ud2
 29f2e71:	ud2
 29f2e73:	ud2
 29f2e75:	ud2
 29f2e77:	ud2
 29f2e79:	ud2
 29f2e7b:	ud2
 29f2e7d:	ud2
 29f2e7f:	ud2
 29f2e81:	ud2
 29f2e83:	ud2
 29f2e85:	ud2
 29f2e87:	ud2
 29f2e89:	ud2
 29f2e8b:	ud2
 29f2e8d:	ud2
 29f2e8f:	ud2
 29f2e91:	ud2
 29f2e93:	ud2
 29f2e95:	ud2
 29f2e97:	ud2
 29f2e99:	ud2
 29f2e9b:	ud2
 29f2e9d:	ud2
