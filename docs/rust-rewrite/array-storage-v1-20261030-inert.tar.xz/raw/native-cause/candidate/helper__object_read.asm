
/workspace/scriptw/target/performance-dense-numbers-20261030/native-cause/candidate/runtime-portable.elf:     file format elf64-x86-64


Disassembly of section .text:

00000000029fe160 <wasm[0]::function[1015]::helper::object_read>:
 29fe160:	push   %rbp
 29fe161:	mov    %rsp,%rbp
 29fe164:	mov    0x8(%rdi),%r10
 29fe168:	mov    0x18(%r10),%r10
 29fe16c:	add    $0x330,%r10
 29fe173:	cmp    %rsp,%r10
 29fe176:	ja     2a18e2e <wasm[0]::function[1015]::helper::object_read+0x1acce>
 29fe17c:	sub    $0x320,%rsp
 29fe183:	mov    %rbx,0x2f0(%rsp)
 29fe18b:	mov    %r12,0x2f8(%rsp)
 29fe193:	mov    %r13,0x300(%rsp)
 29fe19b:	mov    %r14,0x308(%rsp)
 29fe1a3:	mov    %r15,0x310(%rsp)
 29fe1ab:	mov    %rdx,0x198(%rsp)
 29fe1b3:	mov    %rcx,0x1a0(%rsp)
 29fe1bb:	mov    %r9,0x1a8(%rsp)
 29fe1c3:	mov    0x10(%rbp),%rsi
 29fe1c7:	mov    %rsi,0x1b0(%rsp)
 29fe1cf:	mov    0x18(%rbp),%r9
 29fe1d3:	mov    0x20(%rbp),%rcx
 29fe1d7:	mov    %rcx,0x1b8(%rsp)
 29fe1df:	mov    0x28(%rbp),%rax
 29fe1e3:	mov    %rax,0x1c0(%rsp)
 29fe1eb:	mov    0x30(%rbp),%rdx
 29fe1ef:	mov    0x38(%rbp),%rcx
 29fe1f3:	mov    0x40(%rbp),%rax
 29fe1f7:	mov    %r8d,0x110(%rsp)
 29fe1ff:	mov    %r9d,0x68(%rsp)
 29fe204:	mov    %edx,0x60(%rsp)
 29fe208:	mov    %ecx,0x140(%rsp)
 29fe20f:	mov    %eax,0xc0(%rsp)
 29fe216:	movl   $0x0,0x40(%rsp)
 29fe21e:	movl   $0x0,0x70(%rsp)
 29fe226:	movl   $0x0,0x50(%rsp)
 29fe22e:	mov    0x18(%rdi),%rcx
 29fe232:	mov    (%rcx),%rax
 29fe235:	mov    %rcx,0x2e8(%rsp)
 29fe23d:	mov    0x8(%rdi),%rcx
 29fe241:	mov    %rdi,0x190(%rsp)
 29fe249:	mov    0x8(%rcx),%rdx
 29fe24d:	mov    %rdx,%rsi
 29fe250:	mov    %rdx,0x228(%rsp)
 29fe258:	mov    %rcx,0x2e0(%rsp)
 29fe260:	cmp    %rsi,%rax
 29fe263:	jae    2a177bf <wasm[0]::function[1015]::helper::object_read+0x1965f>
 29fe269:	mov    0xc0(%rsp),%ecx
 29fe270:	xor    %ebx,%ebx
 29fe272:	test   %ecx,%ecx
 29fe274:	je     2a18e30 <wasm[0]::function[1015]::helper::object_read+0x1acd0>
 29fe27a:	mov    0x110(%rsp),%r9d
 29fe282:	mov    0x140(%rsp),%esi
 29fe289:	mov    0x68(%rsp),%edi
 29fe28d:	mov    0x60(%rsp),%r11d
 29fe292:	mov    0x70(%rsp),%r8d
 29fe297:	mov    0x50(%rsp),%r10d
 29fe29c:	mov    0x40(%rsp),%edx
 29fe2a0:	xor    %r12,%r12
 29fe2a3:	mov    0x198(%rsp),%rax
 29fe2ab:	cmp    $0x4,%eax
 29fe2ae:	je     29fe2e9 <wasm[0]::function[1015]::helper::object_read+0x189>
 29fe2b4:	mov    %rbx,0x1d0(%rsp)
 29fe2bc:	mov    %rbx,0x238(%rsp)
 29fe2c4:	mov    %rbx,0x280(%rsp)
 29fe2cc:	mov    %r12,0x288(%rsp)
 29fe2d4:	mov    %rbx,0x290(%rsp)
 29fe2dc:	mov    %rbx,0x298(%rsp)
 29fe2e4:	jmp    29fece1 <wasm[0]::function[1015]::helper::object_read+0xb81>
 29fe2e9:	mov    0x110(%rsp),%r9d
 29fe2f1:	mov    0x140(%rsp),%esi
 29fe2f8:	mov    0xc0(%rsp),%ecx
 29fe2ff:	mov    0x68(%rsp),%edi
 29fe303:	mov    0x60(%rsp),%r11d
 29fe308:	mov    0x70(%rsp),%r8d
 29fe30d:	mov    0x50(%rsp),%r10d
 29fe312:	mov    0x40(%rsp),%edx
 29fe316:	xor    %eax,%eax
 29fe318:	xor    %r12,%r12
 29fe31b:	mov    0x1b8(%rsp),%rbx
 29fe323:	cmp    $0x4,%ebx
 29fe326:	je     29fe341 <wasm[0]::function[1015]::helper::object_read+0x1e1>
 29fe32c:	mov    %rax,0x1d0(%rsp)
 29fe334:	mov    %rax,0x238(%rsp)
 29fe33c:	jmp    29febbc <wasm[0]::function[1015]::helper::object_read+0xa5c>
 29fe341:	xor    %r12d,%r12d
 29fe344:	test   %r11d,%r11d
 29fe347:	jne    29fe35a <wasm[0]::function[1015]::helper::object_read+0x1fa>
 29fe34d:	mov    0x2e0(%rsp),%rax
 29fe355:	jmp    29fe3b9 <wasm[0]::function[1015]::helper::object_read+0x259>
 29fe35a:	xor    %r12d,%r12d
 29fe35d:	test   $0x1,%r11d
 29fe364:	je     29fe377 <wasm[0]::function[1015]::helper::object_read+0x217>
 29fe36a:	mov    0x2e0(%rsp),%rax
 29fe372:	jmp    29fe3b9 <wasm[0]::function[1015]::helper::object_read+0x259>
 29fe377:	mov    0x2e0(%rsp),%rax
 29fe37f:	mov    0x28(%rax),%rbx
 29fe383:	mov    0x20(%rax),%r12
 29fe387:	mov    %r11d,%r13d
 29fe38a:	lea    0x4(%r12,%r13,1),%r12
 29fe38f:	xor    %r14,%r14
 29fe392:	cmp    %rbx,%r13
 29fe395:	cmova  %r14,%r12
 29fe399:	mov    (%r12),%ebx
 29fe39d:	mov    0x190(%rsp),%r12
 29fe3a5:	mov    0x28(%r12),%r12
 29fe3aa:	cmp    0x234(%r12),%ebx
 29fe3b2:	sete   %bl
 29fe3b5:	movzbl %bl,%r12d
 29fe3b9:	test   %r12d,%r12d
 29fe3bc:	je     2a18e32 <wasm[0]::function[1015]::helper::object_read+0x1acd2>
 29fe3c2:	test   %r11d,%r11d
 29fe3c5:	je     2a18e34 <wasm[0]::function[1015]::helper::object_read+0x1acd4>
 29fe3cb:	test   %r11d,%r11d
 29fe3ce:	je     2a18e36 <wasm[0]::function[1015]::helper::object_read+0x1acd6>
 29fe3d4:	mov    0x28(%rax),%rbx
 29fe3d8:	mov    0x20(%rax),%r13
 29fe3dc:	mov    %rax,0x2e0(%rsp)
 29fe3e4:	mov    %r11d,%r14d
 29fe3e7:	lea    0x0(%r13,%r14,1),%rax
 29fe3ec:	xor    %r12,%r12
 29fe3ef:	cmp    %rbx,%r14
 29fe3f2:	cmova  %r12,%rax
 29fe3f6:	mov    0x10(%rax),%r14d
 29fe3fa:	xor    %eax,%eax
 29fe3fc:	test   %r14d,%r14d
 29fe3ff:	je     2a18e38 <wasm[0]::function[1015]::helper::object_read+0x1acd8>
 29fe405:	test   %r14d,%r14d
 29fe408:	je     2a18e3a <wasm[0]::function[1015]::helper::object_read+0x1acda>
 29fe40e:	mov    %r14d,%r14d
 29fe411:	lea    0x10(%r13,%r14,1),%r13
 29fe416:	cmp    %rbx,%r14
 29fe419:	cmova  %r12,%r13
 29fe41d:	mov    0x0(%r13),%ebx
 29fe421:	cmp    $0x6,%ebx
 29fe424:	je     29fe43f <wasm[0]::function[1015]::helper::object_read+0x2df>
 29fe42a:	mov    %rax,0x1d0(%rsp)
 29fe432:	mov    %rax,0x238(%rsp)
 29fe43a:	jmp    29febbc <wasm[0]::function[1015]::helper::object_read+0xa5c>
 29fe43f:	mov    $0x8c,%edx
 29fe444:	mov    0x190(%rsp),%rsi
 29fe44c:	mov    0x190(%rsp),%rdi
 29fe454:	call   2f4f240 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 29fe459:	test   %eax,%eax
 29fe45b:	mov    %rax,%r9
 29fe45e:	je     2a18e3c <wasm[0]::function[1015]::helper::object_read+0x1acdc>
 29fe464:	mov    0x1b8(%rsp),%rcx
 29fe46c:	cmp    $0x4,%ecx
 29fe46f:	je     29fe4b9 <wasm[0]::function[1015]::helper::object_read+0x359>
 29fe475:	mov    0x110(%rsp),%r9d
 29fe47d:	mov    0x140(%rsp),%esi
 29fe484:	mov    0xc0(%rsp),%ecx
 29fe48b:	mov    0x68(%rsp),%edi
 29fe48f:	mov    0x60(%rsp),%r11d
 29fe494:	mov    0x70(%rsp),%r8d
 29fe499:	mov    0x50(%rsp),%r10d
 29fe49e:	mov    0x40(%rsp),%edx
 29fe4a2:	xor    %eax,%eax
 29fe4a4:	mov    %rax,0x1d0(%rsp)
 29fe4ac:	mov    %rax,0x238(%rsp)
 29fe4b4:	jmp    29febb9 <wasm[0]::function[1015]::helper::object_read+0xa59>
 29fe4b9:	mov    0x1b8(%rsp),%rcx
 29fe4c1:	cmp    $0x3,%ecx
 29fe4c4:	je     29feb28 <wasm[0]::function[1015]::helper::object_read+0x9c8>
 29fe4ca:	mov    0x1b8(%rsp),%rcx
 29fe4d2:	cmp    $0x4,%ecx
 29fe4d5:	je     29fe9d9 <wasm[0]::function[1015]::helper::object_read+0x879>
 29fe4db:	mov    0x1b8(%rsp),%rcx
 29fe4e3:	cmp    $0xa,%ecx
 29fe4e6:	je     29fe595 <wasm[0]::function[1015]::helper::object_read+0x435>
 29fe4ec:	mov    0x1b8(%rsp),%rax
 29fe4f4:	mov    0x1b8(%rsp),%rcx
 29fe4fc:	test   %eax,%ecx
 29fe4fe:	sete   %cl
 29fe501:	mov    $0x1,%eax
 29fe506:	mov    0x1b8(%rsp),%rdx
 29fe50e:	cmp    $0x1,%edx
 29fe511:	sete   %dl
 29fe514:	or     %edx,%ecx
 29fe516:	test   %cl,%cl
 29fe518:	jne    29fe558 <wasm[0]::function[1015]::helper::object_read+0x3f8>
 29fe51e:	mov    0x1b8(%rsp),%rcx
 29fe526:	cmp    $0x2,%ecx
 29fe529:	je     29fe545 <wasm[0]::function[1015]::helper::object_read+0x3e5>
 29fe52f:	mov    0x60(%rsp),%esi
 29fe533:	mov    %r9,%rax
 29fe536:	cmp    %eax,%esi
 29fe538:	sete   %sil
 29fe53c:	movzbl %sil,%eax
 29fe540:	jmp    29fe558 <wasm[0]::function[1015]::helper::object_read+0x3f8>
 29fe545:	mov    0x1c0(%rsp),%r8
 29fe54d:	test   %r8,%r8
 29fe550:	sete   %dil
 29fe554:	movzbl %dil,%eax
 29fe558:	mov    0x110(%rsp),%r9d
 29fe560:	mov    0x140(%rsp),%esi
 29fe567:	mov    0xc0(%rsp),%ecx
 29fe56e:	mov    0x68(%rsp),%edi
 29fe572:	mov    0x60(%rsp),%r11d
 29fe577:	mov    0x70(%rsp),%r8d
 29fe57c:	mov    0x50(%rsp),%r10d
 29fe581:	mov    0x40(%rsp),%edx
 29fe585:	xor    %r12d,%r12d
 29fe588:	mov    %r12,0x1d0(%rsp)
 29fe590:	jmp    29feb1b <wasm[0]::function[1015]::helper::object_read+0x9bb>
 29fe595:	mov    %r9,%rax
 29fe598:	mov    0x60(%rsp),%r11d
 29fe59d:	xor    %ecx,%ecx
 29fe59f:	test   %r11d,%r11d
 29fe5a2:	je     29fe5f3 <wasm[0]::function[1015]::helper::object_read+0x493>
 29fe5a8:	xor    %ecx,%ecx
 29fe5aa:	test   $0x1,%r11d
 29fe5b1:	jne    29fe5f3 <wasm[0]::function[1015]::helper::object_read+0x493>
 29fe5b7:	mov    0x2e0(%rsp),%r14
 29fe5bf:	mov    0x28(%r14),%rcx
 29fe5c3:	mov    0x20(%r14),%rdx
 29fe5c7:	mov    %r11d,%esi
 29fe5ca:	lea    0x4(%rdx,%rsi,1),%rdx
 29fe5cf:	xor    %rdi,%rdi
 29fe5d2:	cmp    %rcx,%rsi
 29fe5d5:	cmova  %rdi,%rdx
 29fe5d9:	mov    (%rdx),%ecx
 29fe5db:	mov    0x190(%rsp),%rdx
 29fe5e3:	mov    0x28(%rdx),%rdx
 29fe5e7:	cmp    0x23c(%rdx),%ecx
 29fe5ed:	sete   %cl
 29fe5f0:	movzbl %cl,%ecx
 29fe5f3:	test   %ecx,%ecx
 29fe5f5:	je     2a18e3e <wasm[0]::function[1015]::helper::object_read+0x1acde>
 29fe5fb:	xor    %ecx,%ecx
 29fe5fd:	test   %eax,%eax
 29fe5ff:	je     29fe64d <wasm[0]::function[1015]::helper::object_read+0x4ed>
 29fe605:	xor    %ecx,%ecx
 29fe607:	test   $0x1,%eax
 29fe60c:	jne    29fe64d <wasm[0]::function[1015]::helper::object_read+0x4ed>
 29fe612:	mov    0x2e0(%rsp),%r14
 29fe61a:	mov    0x28(%r14),%rcx
 29fe61e:	mov    0x20(%r14),%rdx
 29fe622:	mov    %eax,%esi
 29fe624:	lea    0x4(%rdx,%rsi,1),%rdx
 29fe629:	xor    %rdi,%rdi
 29fe62c:	cmp    %rcx,%rsi
 29fe62f:	cmova  %rdi,%rdx
 29fe633:	mov    (%rdx),%ecx
 29fe635:	mov    0x190(%rsp),%rdx
 29fe63d:	mov    0x28(%rdx),%rdx
 29fe641:	cmp    0x23c(%rdx),%ecx
 29fe647:	sete   %cl
 29fe64a:	movzbl %cl,%ecx
 29fe64d:	test   %ecx,%ecx
 29fe64f:	je     2a18e40 <wasm[0]::function[1015]::helper::object_read+0x1ace0>
 29fe655:	mov    0x60(%rsp),%r11d
 29fe65a:	xor    %r12d,%r12d
 29fe65d:	test   %r11d,%r11d
 29fe660:	je     2a18e42 <wasm[0]::function[1015]::helper::object_read+0x1ace2>
 29fe666:	test   %r11d,%r11d
 29fe669:	je     2a18e44 <wasm[0]::function[1015]::helper::object_read+0x1ace4>
 29fe66f:	mov    0x2e0(%rsp),%r14
 29fe677:	mov    0x28(%r14),%rcx
 29fe67b:	mov    0x20(%r14),%rdx
 29fe67f:	mov    %r11d,%r8d
 29fe682:	lea    (%rdx,%r8,1),%rdi
 29fe686:	xor    %rsi,%rsi
 29fe689:	cmp    %rcx,%r8
 29fe68c:	cmova  %rsi,%rdi
 29fe690:	mov    0x10(%rdi),%r13d
 29fe694:	test   %eax,%eax
 29fe696:	je     2a18e46 <wasm[0]::function[1015]::helper::object_read+0x1ace6>
 29fe69c:	mov    %eax,%eax
 29fe69e:	lea    (%rdx,%rax,1),%r9
 29fe6a2:	cmp    %rcx,%rax
 29fe6a5:	cmova  %rsi,%r9
 29fe6a9:	mov    0x10(%r9),%eax
 29fe6ad:	mov    0x14(%rdi),%r8d
 29fe6b1:	mov    %r8d,0xf0(%rsp)
 29fe6b9:	mov    0x14(%r9),%edi
 29fe6bd:	mov    %edi,0x148(%rsp)
 29fe6c4:	test   %r8d,%r8d
 29fe6c7:	je     2a18e48 <wasm[0]::function[1015]::helper::object_read+0x1ace8>
 29fe6cd:	test   %r8d,%r8d
 29fe6d0:	je     2a18e4a <wasm[0]::function[1015]::helper::object_read+0x1acea>
 29fe6d6:	mov    %r8d,%r9d
 29fe6d9:	lea    0x10(%rdx,%r9,1),%r8
 29fe6de:	cmp    %rcx,%r9
 29fe6e1:	cmova  %rsi,%r8
 29fe6e5:	mov    (%r8),%ebx
 29fe6e8:	test   %edi,%edi
 29fe6ea:	je     2a18e4c <wasm[0]::function[1015]::helper::object_read+0x1acec>
 29fe6f0:	test   %edi,%edi
 29fe6f2:	je     2a18e4e <wasm[0]::function[1015]::helper::object_read+0x1acee>
 29fe6f8:	mov    %edi,%edi
 29fe6fa:	lea    0x10(%rdx,%rdi,1),%rdx
 29fe6ff:	cmp    %rcx,%rdi
 29fe702:	cmova  %rsi,%rdx
 29fe706:	mov    (%rdx),%ecx
 29fe708:	mov    %rcx,0x1d0(%rsp)
 29fe710:	mov    0x110(%rsp),%r9d
 29fe718:	mov    0x140(%rsp),%esi
 29fe71f:	mov    0xc0(%rsp),%ecx
 29fe726:	mov    0x68(%rsp),%edi
 29fe72a:	mov    0x70(%rsp),%r8d
 29fe72f:	mov    0x50(%rsp),%r10d
 29fe734:	mov    0x40(%rsp),%edx
 29fe738:	cmp    %eax,%r13d
 29fe73b:	sete   %r13b
 29fe73f:	mov    0x1d0(%rsp),%rax
 29fe747:	cmp    %eax,%ebx
 29fe749:	sete   %r14b
 29fe74d:	mov    %r13,%rax
 29fe750:	and    %r14d,%eax
 29fe753:	movzbl %al,%eax
 29fe756:	mov    %rax,0x1c8(%rsp)
 29fe75e:	test   %r13b,%r14b
 29fe761:	jne    29fe774 <wasm[0]::function[1015]::helper::object_read+0x614>
 29fe767:	mov    0x1c8(%rsp),%rax
 29fe76f:	jmp    29feb1b <wasm[0]::function[1015]::helper::object_read+0x9bb>
 29fe774:	mov    0x110(%rsp),%ecx
 29fe77b:	mov    0x140(%rsp),%edx
 29fe782:	mov    0xc0(%rsp),%esi
 29fe789:	mov    0x68(%rsp),%edi
 29fe78d:	mov    0x60(%rsp),%r8d
 29fe792:	mov    0x70(%rsp),%r9d
 29fe797:	mov    0x50(%rsp),%r10d
 29fe79c:	mov    0x40(%rsp),%r11d
 29fe7a1:	xor    %r12d,%r12d
 29fe7a4:	mov    %r12,0x238(%rsp)
 29fe7ac:	mov    %ecx,0xd0(%rsp)
 29fe7b3:	mov    %edx,0x128(%rsp)
 29fe7ba:	mov    %esi,0xa0(%rsp)
 29fe7c1:	mov    %edi,0xa8(%rsp)
 29fe7c8:	mov    %r8d,0x48(%rsp)
 29fe7cd:	mov    %r9d,0x80(%rsp)
 29fe7d5:	mov    %r10d,0xb8(%rsp)
 29fe7dd:	mov    %r11d,0x130(%rsp)
 29fe7e5:	mov    0x2e8(%rsp),%r15
 29fe7ed:	mov    (%r15),%rsi
 29fe7f0:	mov    0x228(%rsp),%rax
 29fe7f8:	cmp    %rax,%rsi
 29fe7fb:	jae    2a177d9 <wasm[0]::function[1015]::helper::object_read+0x19679>
 29fe801:	mov    0x238(%rsp),%r12
 29fe809:	jmp    29fe816 <wasm[0]::function[1015]::helper::object_read+0x6b6>
 29fe80e:	mov    0x238(%rsp),%r12
 29fe816:	cmp    %ebx,%r12d
 29fe819:	jb     29fe82c <wasm[0]::function[1015]::helper::object_read+0x6cc>
 29fe81f:	mov    0x1c8(%rsp),%rax
 29fe827:	jmp    29fe99b <wasm[0]::function[1015]::helper::object_read+0x83b>
 29fe82c:	mov    0xf0(%rsp),%esi
 29fe833:	test   %esi,%esi
 29fe835:	je     2a18e50 <wasm[0]::function[1015]::helper::object_read+0x1acf0>
 29fe83b:	test   %esi,%esi
 29fe83d:	je     2a18e52 <wasm[0]::function[1015]::helper::object_read+0x1acf2>
 29fe843:	mov    0x2e0(%rsp),%r14
 29fe84b:	mov    0x28(%r14),%rax
 29fe84f:	mov    0x20(%r14),%rcx
 29fe853:	mov    %esi,%r8d
 29fe856:	lea    0x10(%rcx,%r8,1),%rdi
 29fe85b:	xor    %rdx,%rdx
 29fe85e:	cmp    %rax,%r8
 29fe861:	cmova  %rdx,%rdi
 29fe865:	mov    (%rdi),%r8d
 29fe868:	cmp    %r8d,%r12d
 29fe86b:	jae    2a18e54 <wasm[0]::function[1015]::helper::object_read+0x1acf4>
 29fe871:	mov    %r8d,%edi
 29fe874:	shl    $0x3,%rdi
 29fe878:	shr    $0x20,%rdi
 29fe87c:	test   %rdi,%rdi
 29fe87f:	jne    2a18e56 <wasm[0]::function[1015]::helper::object_read+0x1acf6>
 29fe885:	shl    $0x3,%r8d
 29fe889:	add    $0x18,%r8d
 29fe88d:	jb     2a18e58 <wasm[0]::function[1015]::helper::object_read+0x1acf8>
 29fe893:	add    %r8d,%esi
 29fe896:	jb     2a18e5a <wasm[0]::function[1015]::helper::object_read+0x1acfa>
 29fe89c:	mov    %esi,%edi
 29fe89e:	lea    (%rcx,%rdi,1),%rsi
 29fe8a2:	cmp    %rax,%rdi
 29fe8a5:	cmova  %rdx,%rsi
 29fe8a9:	mov    %r12,%rdi
 29fe8ac:	shl    $0x3,%edi
 29fe8af:	add    $0x18,%edi
 29fe8b5:	sub    %edi,%r8d
 29fe8b8:	sub    %r8,%rsi
 29fe8bb:	mov    (%rsi),%rsi
 29fe8be:	mov    0x148(%rsp),%r8d
 29fe8c6:	test   %r8d,%r8d
 29fe8c9:	je     2a18e5c <wasm[0]::function[1015]::helper::object_read+0x1acfc>
 29fe8cf:	test   %r8d,%r8d
 29fe8d2:	je     2a18e5e <wasm[0]::function[1015]::helper::object_read+0x1acfe>
 29fe8d8:	mov    %r8d,%r10d
 29fe8db:	lea    0x10(%rcx,%r10,1),%r9
 29fe8e0:	cmp    %rax,%r10
 29fe8e3:	cmova  %rdx,%r9
 29fe8e7:	mov    (%r9),%r9d
 29fe8ea:	cmp    %r9d,%r12d
 29fe8ed:	jae    2a18e60 <wasm[0]::function[1015]::helper::object_read+0x1ad00>
 29fe8f3:	mov    %r9d,%r10d
 29fe8f6:	shl    $0x3,%r10
 29fe8fa:	shr    $0x20,%r10
 29fe8fe:	test   %r10,%r10
 29fe901:	jne    2a18e62 <wasm[0]::function[1015]::helper::object_read+0x1ad02>
 29fe907:	shl    $0x3,%r9d
 29fe90b:	add    $0x18,%r9d
 29fe90f:	jb     2a18e64 <wasm[0]::function[1015]::helper::object_read+0x1ad04>
 29fe915:	add    %r9d,%r8d
 29fe918:	jb     2a18e66 <wasm[0]::function[1015]::helper::object_read+0x1ad06>
 29fe91e:	mov    %r8d,%r8d
 29fe921:	add    %r8,%rcx
 29fe924:	cmp    %rax,%r8
 29fe927:	cmova  %rdx,%rcx
 29fe92b:	sub    %edi,%r9d
 29fe92e:	sub    %r9,%rcx
 29fe931:	mov    (%rcx),%rcx
 29fe934:	cmp    %rcx,%rsi
 29fe937:	sete   %al
 29fe93a:	movzbl %al,%eax
 29fe93d:	cmp    %rcx,%rsi
 29fe940:	jne    29fe99b <wasm[0]::function[1015]::helper::object_read+0x83b>
 29fe946:	mov    0xd0(%rsp),%ecx
 29fe94d:	mov    0x128(%rsp),%edx
 29fe954:	mov    0xa0(%rsp),%esi
 29fe95b:	mov    0xa8(%rsp),%edi
 29fe962:	mov    0x48(%rsp),%r8d
 29fe967:	mov    0x80(%rsp),%r9d
 29fe96f:	mov    0xb8(%rsp),%r10d
 29fe977:	mov    0x130(%rsp),%r11d
 29fe97f:	add    $0x1,%r12d
 29fe986:	mov    %rax,0x1c8(%rsp)
 29fe98e:	mov    %r12,0x238(%rsp)
 29fe996:	jmp    29fe7ac <wasm[0]::function[1015]::helper::object_read+0x64c>
 29fe99b:	mov    0xd0(%rsp),%r9d
 29fe9a3:	mov    0x128(%rsp),%esi
 29fe9aa:	mov    0xa0(%rsp),%ecx
 29fe9b1:	mov    0xa8(%rsp),%edi
 29fe9b8:	mov    0x48(%rsp),%r11d
 29fe9bd:	mov    0x80(%rsp),%r8d
 29fe9c5:	mov    0xb8(%rsp),%r10d
 29fe9cd:	mov    0x130(%rsp),%edx
 29fe9d4:	jmp    29feb1b <wasm[0]::function[1015]::helper::object_read+0x9bb>
 29fe9d9:	mov    %r9,%rax
 29fe9dc:	mov    0x60(%rsp),%ecx
 29fe9e0:	cmp    %eax,%ecx
 29fe9e2:	je     29feade <wasm[0]::function[1015]::helper::object_read+0x97e>
 29fe9e8:	xor    %edx,%edx
 29fe9ea:	test   %ecx,%ecx
 29fe9ec:	je     29fea3b <wasm[0]::function[1015]::helper::object_read+0x8db>
 29fe9f2:	xor    %edx,%edx
 29fe9f4:	test   $0x1,%ecx
 29fe9fa:	jne    29fea3b <wasm[0]::function[1015]::helper::object_read+0x8db>
 29fea00:	mov    0x2e0(%rsp),%r14
 29fea08:	mov    0x28(%r14),%rdx
 29fea0c:	mov    0x20(%r14),%rdi
 29fea10:	mov    %ecx,%esi
 29fea12:	lea    0x4(%rdi,%rsi,1),%rcx
 29fea17:	xor    %rdi,%rdi
 29fea1a:	cmp    %rdx,%rsi
 29fea1d:	cmova  %rdi,%rcx
 29fea21:	mov    (%rcx),%ecx
 29fea23:	mov    0x190(%rsp),%rdx
 29fea2b:	mov    0x28(%rdx),%rdx
 29fea2f:	cmp    0x234(%rdx),%ecx
 29fea35:	sete   %cl
 29fea38:	movzbl %cl,%edx
 29fea3b:	test   %edx,%edx
 29fea3d:	je     2a18e68 <wasm[0]::function[1015]::helper::object_read+0x1ad08>
 29fea43:	xor    %esi,%esi
 29fea45:	test   %eax,%eax
 29fea47:	jne    29fea55 <wasm[0]::function[1015]::helper::object_read+0x8f5>
 29fea4d:	mov    %rax,%r9
 29fea50:	jmp    29feaaa <wasm[0]::function[1015]::helper::object_read+0x94a>
 29fea55:	xor    %esi,%esi
 29fea57:	test   $0x1,%eax
 29fea5c:	je     29fea6a <wasm[0]::function[1015]::helper::object_read+0x90a>
 29fea62:	mov    %rax,%r9
 29fea65:	jmp    29feaaa <wasm[0]::function[1015]::helper::object_read+0x94a>
 29fea6a:	mov    0x2e0(%rsp),%r14
 29fea72:	mov    0x28(%r14),%rdx
 29fea76:	mov    0x20(%r14),%rdi
 29fea7a:	mov    %eax,%esi
 29fea7c:	mov    %rax,%r9
 29fea7f:	lea    0x4(%rdi,%rsi,1),%rax
 29fea84:	xor    %rdi,%rdi
 29fea87:	cmp    %rdx,%rsi
 29fea8a:	cmova  %rdi,%rax
 29fea8e:	mov    (%rax),%esi
 29fea90:	mov    0x190(%rsp),%rcx
 29fea98:	mov    0x28(%rcx),%rdi
 29fea9c:	cmp    0x234(%rdi),%esi
 29feaa2:	sete   %sil
 29feaa6:	movzbl %sil,%esi
 29feaaa:	test   %esi,%esi
 29feaac:	je     2a18e6a <wasm[0]::function[1015]::helper::object_read+0x1ad0a>
 29feab2:	mov    0x60(%rsp),%edx
 29feab6:	xor    %r8d,%r8d
 29feab9:	test   %edx,%edx
 29feabb:	je     2a18e6c <wasm[0]::function[1015]::helper::object_read+0x1ad0c>
 29feac1:	mov    %r9,%rcx
 29feac4:	mov    0x190(%rsp),%rsi
 29feacc:	mov    0x190(%rsp),%rdi
 29fead4:	call   2b02800 <wasm[0]::function[1057]::helper::string_equality>
 29fead9:	jmp    29feae3 <wasm[0]::function[1015]::helper::object_read+0x983>
 29feade:	mov    $0x1,%eax
 29feae3:	mov    0x110(%rsp),%r9d
 29feaeb:	mov    0x140(%rsp),%esi
 29feaf2:	mov    0xc0(%rsp),%ecx
 29feaf9:	mov    0x68(%rsp),%edi
 29feafd:	mov    0x60(%rsp),%r11d
 29feb02:	mov    0x70(%rsp),%r8d
 29feb07:	mov    0x50(%rsp),%r10d
 29feb0c:	mov    0x40(%rsp),%edx
 29feb10:	xor    %r12d,%r12d
 29feb13:	mov    %r12,0x1d0(%rsp)
 29feb1b:	mov    %r12,0x238(%rsp)
 29feb23:	jmp    29febb9 <wasm[0]::function[1015]::helper::object_read+0xa59>
 29feb28:	mov    0x110(%rsp),%r9d
 29feb30:	mov    0x140(%rsp),%esi
 29feb37:	mov    0xc0(%rsp),%ecx
 29feb3e:	mov    0x68(%rsp),%edi
 29feb42:	mov    0x60(%rsp),%r11d
 29feb47:	mov    0x70(%rsp),%r8d
 29feb4c:	mov    0x50(%rsp),%r10d
 29feb51:	mov    0x40(%rsp),%edx
 29feb55:	xor    %r13,%r13
 29feb58:	mov    0x1c0(%rsp),%rax
 29feb60:	mov    0x1c0(%rsp),%rbx
 29feb68:	test   %rbx,%rax
 29feb6b:	sete   %al
 29feb6e:	movq   %rbx,%xmm0
 29feb73:	ucomisd %xmm0,%xmm0
 29feb77:	setp   %r12b
 29feb7b:	setne  %r15b
 29feb7f:	or     %r15d,%r12d
 29feb82:	movq   %r13,%xmm0
 29feb87:	ucomisd %xmm0,%xmm0
 29feb8b:	setp   %bl
 29feb8e:	setne  %r13b
 29feb92:	or     %r13d,%ebx
 29feb95:	and    %ebx,%r12d
 29feb98:	or     %r12d,%eax
 29feb9b:	movzbl %al,%eax
 29feb9e:	xor    %r12d,%r12d
 29feba1:	mov    %r12,0x238(%rsp)
 29feba9:	mov    0x238(%rsp),%rbx
 29febb1:	mov    %rbx,0x1d0(%rsp)
 29febb9:	xor    %r12,%r12
 29febbc:	xor    %ebx,%ebx
 29febbe:	xor    %r13,%r13
 29febc1:	test   %eax,%eax
 29febc3:	jne    29febee <wasm[0]::function[1015]::helper::object_read+0xa8e>
 29febc9:	mov    %rbx,0x280(%rsp)
 29febd1:	mov    %r13,0x288(%rsp)
 29febd9:	mov    %rbx,0x290(%rsp)
 29febe1:	mov    %rbx,0x298(%rsp)
 29febe9:	jmp    29fece1 <wasm[0]::function[1015]::helper::object_read+0xb81>
 29febee:	xor    %eax,%eax
 29febf0:	test   %r9d,%r9d
 29febf3:	je     29fec44 <wasm[0]::function[1015]::helper::object_read+0xae4>
 29febf9:	xor    %eax,%eax
 29febfb:	test   $0x1,%r9d
 29fec02:	jne    29fec44 <wasm[0]::function[1015]::helper::object_read+0xae4>
 29fec08:	mov    0x2e0(%rsp),%r14
 29fec10:	mov    0x28(%r14),%rax
 29fec14:	mov    0x20(%r14),%rdx
 29fec18:	mov    %r9d,%ebx
 29fec1b:	lea    0x4(%rdx,%rbx,1),%rdx
 29fec20:	xor    %r13,%r13
 29fec23:	cmp    %rax,%rbx
 29fec26:	cmova  %r13,%rdx
 29fec2a:	mov    (%rdx),%eax
 29fec2c:	mov    0x190(%rsp),%rdx
 29fec34:	mov    0x28(%rdx),%rdx
 29fec38:	cmp    0x234(%rdx),%eax
 29fec3e:	sete   %al
 29fec41:	movzbl %al,%eax
 29fec44:	test   %eax,%eax
 29fec46:	je     2a18e6e <wasm[0]::function[1015]::helper::object_read+0x1ad0e>
 29fec4c:	test   %r9d,%r9d
 29fec4f:	je     2a18e70 <wasm[0]::function[1015]::helper::object_read+0x1ad10>
 29fec55:	test   %r9d,%r9d
 29fec58:	je     2a18e72 <wasm[0]::function[1015]::helper::object_read+0x1ad12>
 29fec5e:	mov    0x2e0(%rsp),%r14
 29fec66:	mov    0x28(%r14),%rax
 29fec6a:	mov    0x20(%r14),%rbx
 29fec6e:	mov    %r9d,%r14d
 29fec71:	lea    (%rbx,%r14,1),%rdx
 29fec75:	xor    %r13,%r13
 29fec78:	cmp    %rax,%r14
 29fec7b:	cmova  %r13,%rdx
 29fec7f:	mov    0x10(%rdx),%r14d
 29fec83:	xor    %edx,%edx
 29fec85:	test   %r14d,%r14d
 29fec88:	je     2a18e74 <wasm[0]::function[1015]::helper::object_read+0x1ad14>
 29fec8e:	test   %r14d,%r14d
 29fec91:	je     2a18e76 <wasm[0]::function[1015]::helper::object_read+0x1ad16>
 29fec97:	mov    %r14d,%r15d
 29fec9a:	lea    0x10(%rbx,%r15,1),%r14
 29fec9f:	cmp    %rax,%r15
 29feca2:	cmova  %r13,%r14
 29feca6:	mov    $0x1,%ebx
 29fecab:	mov    $0x3,%eax
 29fecb0:	mov    %rax,0x280(%rsp)
 29fecb8:	xorpd  %xmm0,%xmm0
 29fecbc:	mov    (%r14),%eax
 29fecbf:	cvtsi2sd %rax,%xmm0
 29fecc4:	movq   %xmm0,%r13
 29fecc9:	mov    %r13,0x288(%rsp)
 29fecd1:	mov    %rdx,0x290(%rsp)
 29fecd9:	mov    %rdx,0x298(%rsp)
 29fece1:	mov    %esi,0x50(%rsp)
 29fece5:	mov    %ecx,0x70(%rsp)
 29fece9:	mov    %edi,0x60(%rsp)
 29feced:	mov    %r11d,0x68(%rsp)
 29fecf2:	mov    %r8d,0xc0(%rsp)
 29fecfa:	mov    %r10d,0x140(%rsp)
 29fed02:	mov    %edx,0x110(%rsp)
 29fed09:	test   %ebx,%ebx
 29fed0b:	je     29fed21 <wasm[0]::function[1015]::helper::object_read+0xbc1>
 29fed11:	mov    %rdx,%rax
 29fed14:	mov    0x290(%rsp),%rsi
 29fed1c:	jmp    2a1776e <wasm[0]::function[1015]::helper::object_read+0x1960e>
 29fed21:	mov    0x190(%rsp),%rcx
 29fed29:	mov    0x8c0(%rcx),%edx
 29fed2f:	test   %edx,%edx
 29fed31:	je     2a18e78 <wasm[0]::function[1015]::helper::object_read+0x1ad18>
 29fed37:	mov    0x198(%rsp),%rcx
 29fed3f:	mov    0x1a0(%rsp),%r8
 29fed47:	mov    0x190(%rsp),%rsi
 29fed4f:	mov    0x190(%rsp),%rdi
 29fed57:	call   2a80460 <wasm[0]::function[1041]::helper::value_to_object>
 29fed5c:	mov    %rax,0x2d0(%rsp)
 29fed64:	mov    %rcx,0x2d8(%rsp)
 29fed6c:	mov    %edx,0x40(%rsp)
 29fed70:	mov    $0x1,%eax
 29fed75:	mov    %rax,0x278(%rsp)
 29fed7d:	cmp    $0x1,%esi
 29fed80:	je     2a17743 <wasm[0]::function[1015]::helper::object_read+0x195e3>
 29fed86:	xor    %eax,%eax
 29fed88:	test   %edx,%edx
 29fed8a:	je     29feddb <wasm[0]::function[1015]::helper::object_read+0xc7b>
 29fed90:	xor    %eax,%eax
 29fed92:	test   $0x1,%edx
 29fed98:	jne    29feddb <wasm[0]::function[1015]::helper::object_read+0xc7b>
 29fed9e:	mov    0x2e0(%rsp),%r14
 29feda6:	mov    0x28(%r14),%rax
 29fedaa:	mov    0x20(%r14),%rcx
 29fedae:	mov    %edx,%esi
 29fedb0:	lea    0x4(%rcx,%rsi,1),%rcx
 29fedb5:	xor    %rdi,%rdi
 29fedb8:	cmp    %rax,%rsi
 29fedbb:	cmova  %rdi,%rcx
 29fedbf:	mov    (%rcx),%ecx
 29fedc1:	mov    0x190(%rsp),%rax
 29fedc9:	mov    0x28(%rax),%rsi
 29fedcd:	cmp    0x1e8(%rsi),%ecx
 29fedd3:	sete   %sil
 29fedd7:	movzbl %sil,%eax
 29feddb:	test   %eax,%eax
 29feddd:	jne    2a0cfaa <wasm[0]::function[1015]::helper::object_read+0xee4a>
 29fede3:	xor    %eax,%eax
 29fede5:	movl   $0x0,0xd0(%rsp)
 29fedf0:	test   %edx,%edx
 29fedf2:	je     29fee42 <wasm[0]::function[1015]::helper::object_read+0xce2>
 29fedf8:	xor    %eax,%eax
 29fedfa:	test   $0x1,%edx
 29fee00:	jne    29fee42 <wasm[0]::function[1015]::helper::object_read+0xce2>
 29fee06:	mov    0x2e0(%rsp),%r14
 29fee0e:	mov    0x28(%r14),%rax
 29fee12:	mov    0x20(%r14),%rsi
 29fee16:	mov    %edx,%ecx
 29fee18:	lea    0x4(%rsi,%rcx,1),%r9
 29fee1d:	xor    %rsi,%rsi
 29fee20:	cmp    %rax,%rcx
 29fee23:	cmova  %rsi,%r9
 29fee27:	mov    (%r9),%eax
 29fee2a:	mov    0x190(%rsp),%rcx
 29fee32:	mov    0x28(%rcx),%rcx
 29fee36:	cmp    0x138(%rcx),%eax
 29fee3c:	sete   %al
 29fee3f:	movzbl %al,%eax
 29fee42:	test   %eax,%eax
 29fee44:	jne    29fefea <wasm[0]::function[1015]::helper::object_read+0xe8a>
 29fee4a:	xor    %r11d,%r11d
 29fee4d:	test   %edx,%edx
 29fee4f:	je     29feea0 <wasm[0]::function[1015]::helper::object_read+0xd40>
 29fee55:	xor    %r11d,%r11d
 29fee58:	test   $0x1,%edx
 29fee5e:	jne    29feea0 <wasm[0]::function[1015]::helper::object_read+0xd40>
 29fee64:	mov    0x2e0(%rsp),%r14
 29fee6c:	mov    0x28(%r14),%rax
 29fee70:	mov    0x20(%r14),%rcx
 29fee74:	mov    %edx,%esi
 29fee76:	lea    0x4(%rcx,%rsi,1),%rcx
 29fee7b:	xor    %rdi,%rdi
 29fee7e:	cmp    %rax,%rsi
 29fee81:	cmova  %rdi,%rcx
 29fee85:	mov    (%rcx),%eax
 29fee87:	mov    0x190(%rsp),%rcx
 29fee8f:	mov    0x28(%rcx),%rcx
 29fee93:	cmp    0x1d4(%rcx),%eax
 29fee99:	sete   %al
 29fee9c:	movzbl %al,%r11d
 29feea0:	xor    %esi,%esi
 29feea2:	test   %r11d,%r11d
 29feea5:	je     29ff048 <wasm[0]::function[1015]::helper::object_read+0xee8>
 29feeab:	xor    %eax,%eax
 29feead:	test   %edx,%edx
 29feeaf:	je     29feefe <wasm[0]::function[1015]::helper::object_read+0xd9e>
 29feeb5:	xor    %eax,%eax
 29feeb7:	test   $0x1,%edx
 29feebd:	jne    29feefe <wasm[0]::function[1015]::helper::object_read+0xd9e>
 29feec3:	mov    0x2e0(%rsp),%r14
 29feecb:	mov    0x28(%r14),%rax
 29feecf:	mov    0x20(%r14),%rcx
 29feed3:	mov    %edx,%esi
 29feed5:	lea    0x4(%rcx,%rsi,1),%rcx
 29feeda:	xor    %rdi,%rdi
 29feedd:	cmp    %rax,%rsi
 29feee0:	cmova  %rdi,%rcx
 29feee4:	mov    (%rcx),%eax
 29feee6:	mov    0x190(%rsp),%rcx
 29feeee:	mov    0x28(%rcx),%rcx
 29feef2:	cmp    0x1d4(%rcx),%eax
 29feef8:	sete   %al
 29feefb:	movzbl %al,%eax
 29feefe:	test   %eax,%eax
 29fef00:	je     2a18e7a <wasm[0]::function[1015]::helper::object_read+0x1ad1a>
 29fef06:	test   %edx,%edx
 29fef08:	je     2a18e7c <wasm[0]::function[1015]::helper::object_read+0x1ad1c>
 29fef0e:	test   %edx,%edx
 29fef10:	je     2a18e7e <wasm[0]::function[1015]::helper::object_read+0x1ad1e>
 29fef16:	mov    0x2e0(%rsp),%r14
 29fef1e:	mov    0x28(%r14),%rax
 29fef22:	mov    0x20(%r14),%rcx
 29fef26:	mov    %edx,%edi
 29fef28:	lea    (%rcx,%rdi,1),%rsi
 29fef2c:	xor    %rdx,%rdx
 29fef2f:	cmp    %rax,%rdi
 29fef32:	cmova  %rdx,%rsi
 29fef36:	mov    0x10(%rsi),%esi
 29fef39:	mov    %esi,0x128(%rsp)
 29fef40:	test   %esi,%esi
 29fef42:	je     2a18e80 <wasm[0]::function[1015]::helper::object_read+0x1ad20>
 29fef48:	test   %esi,%esi
 29fef4a:	je     2a18e82 <wasm[0]::function[1015]::helper::object_read+0x1ad22>
 29fef50:	mov    %esi,%esi
 29fef52:	add    %rsi,%rcx
 29fef55:	cmp    %rax,%rsi
 29fef58:	cmova  %rdx,%rcx
 29fef5c:	mov    0x14(%rcx),%ecx
 29fef5f:	test   %ecx,%ecx
 29fef61:	je     2a18e84 <wasm[0]::function[1015]::helper::object_read+0x1ad24>
 29fef67:	xor    %eax,%eax
 29fef69:	test   $0x1,%ecx
 29fef6f:	jne    29fefc7 <wasm[0]::function[1015]::helper::object_read+0xe67>
 29fef75:	mov    0x2e0(%rsp),%r14
 29fef7d:	mov    0x28(%r14),%rax
 29fef81:	mov    0x20(%r14),%rsi
 29fef85:	mov    %ecx,%edx
 29fef87:	lea    0x4(%rsi,%rdx,1),%rcx
 29fef8c:	xor    %rsi,%rsi
 29fef8f:	cmp    %rax,%rdx
 29fef92:	cmova  %rsi,%rcx
 29fef96:	mov    (%rcx),%esi
 29fef98:	mov    0x190(%rsp),%rcx
 29fefa0:	mov    0x28(%rcx),%rax
 29fefa4:	mov    0x158(%rax),%edx
 29fefaa:	cmp    %edx,%esi
 29fefac:	sete   %al
 29fefaf:	movzbl %al,%eax
 29fefb2:	cmp    %edx,%esi
 29fefb4:	je     29fefc7 <wasm[0]::function[1015]::helper::object_read+0xe67>
 29fefba:	mov    0x190(%rsp),%rdi
 29fefc2:	call   3039cc5 <wasmtime_builtin_is_subtype>
 29fefc7:	mov    0xd0(%rsp),%esi
 29fefce:	test   %eax,%eax
 29fefd0:	je     29ff048 <wasm[0]::function[1015]::helper::object_read+0xee8>
 29fefd6:	mov    0x128(%rsp),%esi
 29fefdd:	test   %esi,%esi
 29fefdf:	je     2a18e86 <wasm[0]::function[1015]::helper::object_read+0x1ad26>
 29fefe5:	jmp    29ff048 <wasm[0]::function[1015]::helper::object_read+0xee8>
 29fefea:	xor    %eax,%eax
 29fefec:	test   %edx,%edx
 29fefee:	je     29ff03d <wasm[0]::function[1015]::helper::object_read+0xedd>
 29feff4:	xor    %eax,%eax
 29feff6:	test   $0x1,%edx
 29feffc:	jne    29ff03d <wasm[0]::function[1015]::helper::object_read+0xedd>
 29ff002:	mov    0x2e0(%rsp),%r14
 29ff00a:	mov    0x28(%r14),%rax
 29ff00e:	mov    0x20(%r14),%rcx
 29ff012:	mov    %edx,%esi
 29ff014:	lea    0x4(%rcx,%rsi,1),%rcx
 29ff019:	xor    %rdi,%rdi
 29ff01c:	cmp    %rax,%rsi
 29ff01f:	cmova  %rdi,%rcx
 29ff023:	mov    (%rcx),%eax
 29ff025:	mov    0x190(%rsp),%rcx
 29ff02d:	mov    0x28(%rcx),%rcx
 29ff031:	cmp    0x138(%rcx),%eax
 29ff037:	sete   %al
 29ff03a:	movzbl %al,%eax
 29ff03d:	test   %eax,%eax
 29ff03f:	je     2a18e88 <wasm[0]::function[1015]::helper::object_read+0x1ad28>
 29ff045:	mov    %rdx,%rsi
 29ff048:	mov    %esi,0x128(%rsp)
 29ff04f:	mov    0x40(%rsp),%edx
 29ff053:	mov    %rdx,0x210(%rsp)
 29ff05b:	mov    0x68(%rsp),%r9d
 29ff060:	mov    0x140(%rsp),%r8d
 29ff068:	mov    0x50(%rsp),%r13d
 29ff06d:	mov    %r13,0x208(%rsp)
 29ff075:	mov    0x70(%rsp),%r13d
 29ff07a:	mov    0x60(%rsp),%edi
 29ff07e:	mov    0x110(%rsp),%edx
 29ff085:	xor    %eax,%eax
 29ff087:	test   %esi,%esi
 29ff089:	jne    29ff0ac <wasm[0]::function[1015]::helper::object_read+0xf4c>
 29ff08f:	mov    0x210(%rsp),%rcx
 29ff097:	mov    %rax,0x1e0(%rsp)
 29ff09f:	mov    %rax,0x200(%rsp)
 29ff0a7:	jmp    29ffdf2 <wasm[0]::function[1015]::helper::object_read+0x1c92>
 29ff0ac:	test   %esi,%esi
 29ff0ae:	je     2a18e8a <wasm[0]::function[1015]::helper::object_read+0x1ad2a>
 29ff0b4:	test   %esi,%esi
 29ff0b6:	je     2a18e8c <wasm[0]::function[1015]::helper::object_read+0x1ad2c>
 29ff0bc:	mov    0x2e0(%rsp),%r14
 29ff0c4:	mov    0x28(%r14),%rax
 29ff0c8:	mov    0x20(%r14),%rcx
 29ff0cc:	mov    %esi,%edx
 29ff0ce:	add    %rdx,%rcx
 29ff0d1:	xor    %rsi,%rsi
 29ff0d4:	cmp    %rax,%rdx
 29ff0d7:	cmova  %rsi,%rcx
 29ff0db:	mov    0x14(%rcx),%eax
 29ff0de:	mov    %eax,0xd0(%rsp)
 29ff0e5:	test   %eax,%eax
 29ff0e7:	je     2a18e8e <wasm[0]::function[1015]::helper::object_read+0x1ad2e>
 29ff0ed:	mov    0xd0(%rsp),%ecx
 29ff0f4:	xor    %eax,%eax
 29ff0f6:	test   $0x1,%ecx
 29ff0fc:	jne    29ff154 <wasm[0]::function[1015]::helper::object_read+0xff4>
 29ff102:	mov    0x2e0(%rsp),%r14
 29ff10a:	mov    0x28(%r14),%rax
 29ff10e:	mov    0x20(%r14),%rsi
 29ff112:	mov    %ecx,%edx
 29ff114:	lea    0x4(%rsi,%rdx,1),%rcx
 29ff119:	xor    %rsi,%rsi
 29ff11c:	cmp    %rax,%rdx
 29ff11f:	cmova  %rsi,%rcx
 29ff123:	mov    (%rcx),%esi
 29ff125:	mov    0x190(%rsp),%rcx
 29ff12d:	mov    0x28(%rcx),%rax
 29ff131:	mov    0x158(%rax),%edx
 29ff137:	cmp    %edx,%esi
 29ff139:	sete   %al
 29ff13c:	movzbl %al,%eax
 29ff13f:	cmp    %edx,%esi
 29ff141:	je     29ff154 <wasm[0]::function[1015]::helper::object_read+0xff4>
 29ff147:	mov    0x190(%rsp),%rdi
 29ff14f:	call   3039cc5 <wasmtime_builtin_is_subtype>
 29ff154:	test   %eax,%eax
 29ff156:	jne    29ff3e2 <wasm[0]::function[1015]::helper::object_read+0x1282>
 29ff15c:	mov    0x128(%rsp),%edx
 29ff163:	xor    %ebx,%ebx
 29ff165:	test   %edx,%edx
 29ff167:	je     2a18e90 <wasm[0]::function[1015]::helper::object_read+0x1ad30>
 29ff16d:	mov    0x68(%rsp),%r9d
 29ff172:	mov    0x1b8(%rsp),%rcx
 29ff17a:	mov    0x190(%rsp),%rsi
 29ff182:	mov    0x190(%rsp),%rdi
 29ff18a:	mov    0x1c0(%rsp),%r8
 29ff192:	call   2a76140 <wasm[0]::function[1032]::helper::ordinary_property_find>
 29ff197:	test   %eax,%eax
 29ff199:	je     29ff1d1 <wasm[0]::function[1015]::helper::object_read+0x1071>
 29ff19f:	test   %eax,%eax
 29ff1a1:	je     2a18e92 <wasm[0]::function[1015]::helper::object_read+0x1ad32>
 29ff1a7:	test   %eax,%eax
 29ff1a9:	je     2a18e94 <wasm[0]::function[1015]::helper::object_read+0x1ad34>
 29ff1af:	mov    0x2e0(%rsp),%r14
 29ff1b7:	mov    0x28(%r14),%rcx
 29ff1bb:	mov    %eax,%edx
 29ff1bd:	mov    %rdx,%rax
 29ff1c0:	add    0x20(%r14),%rax
 29ff1c4:	xor    %rsi,%rsi
 29ff1c7:	cmp    %rcx,%rdx
 29ff1ca:	cmova  %rsi,%rax
 29ff1ce:	mov    0x14(%rax),%ebx
 29ff1d1:	mov    0xc0(%rsp),%edx
 29ff1d8:	xor    %eax,%eax
 29ff1da:	test   %ebx,%ebx
 29ff1dc:	je     29ff372 <wasm[0]::function[1015]::helper::object_read+0x1212>
 29ff1e2:	test   %ebx,%ebx
 29ff1e4:	je     2a18e96 <wasm[0]::function[1015]::helper::object_read+0x1ad36>
 29ff1ea:	mov    0x2e0(%rsp),%r14
 29ff1f2:	mov    0x28(%r14),%rax
 29ff1f6:	mov    0x20(%r14),%rcx
 29ff1fa:	mov    %ebx,%edx
 29ff1fc:	add    %rdx,%rcx
 29ff1ff:	xor    %rsi,%rsi
 29ff202:	cmp    %rax,%rdx
 29ff205:	cmova  %rsi,%rcx
 29ff209:	mov    0x10(%rcx),%esi
 29ff20c:	mov    0xc0(%rsp),%edx
 29ff213:	xor    %eax,%eax
 29ff215:	test   $0x1,%esi
 29ff21b:	jne    29ff372 <wasm[0]::function[1015]::helper::object_read+0x1212>
 29ff221:	mov    0x14(%rcx),%edx
 29ff224:	test   %edx,%edx
 29ff226:	je     2a18e98 <wasm[0]::function[1015]::helper::object_read+0x1ad38>
 29ff22c:	xor    %eax,%eax
 29ff22e:	test   $0x1,%edx
 29ff234:	jne    29ff27a <wasm[0]::function[1015]::helper::object_read+0x111a>
 29ff23a:	mov    0x2e0(%rsp),%r14
 29ff242:	mov    0x28(%r14),%r9
 29ff246:	mov    0x20(%r14),%r11
 29ff24a:	mov    %edx,%r10d
 29ff24d:	lea    0x4(%r11,%r10,1),%rsi
 29ff252:	xor    %r11,%r11
 29ff255:	cmp    %r9,%r10
 29ff258:	cmova  %r11,%rsi
 29ff25c:	mov    (%rsi),%r10d
 29ff25f:	mov    0x190(%rsp),%rcx
 29ff267:	mov    0x28(%rcx),%r11
 29ff26b:	cmp    0x120(%r11),%r10d
 29ff272:	sete   %r11b
 29ff276:	movzbl %r11b,%eax
 29ff27a:	test   %eax,%eax
 29ff27c:	jne    29ff2df <wasm[0]::function[1015]::helper::object_read+0x117f>
 29ff282:	mov    0x190(%rsp),%rsi
 29ff28a:	mov    0x190(%rsp),%rdi
 29ff292:	call   2a1eec0 <wasm[0]::function[1024]::helper::property_value_resolve>
 29ff297:	test   %eax,%eax
 29ff299:	je     2a18e9a <wasm[0]::function[1015]::helper::object_read+0x1ad3a>
 29ff29f:	test   %eax,%eax
 29ff2a1:	je     2a18e9c <wasm[0]::function[1015]::helper::object_read+0x1ad3c>
 29ff2a7:	mov    0x2e0(%rsp),%r14
 29ff2af:	mov    0x28(%r14),%rcx
 29ff2b3:	mov    0x20(%r14),%rsi
 29ff2b7:	mov    %eax,%edx
 29ff2b9:	lea    (%rsi,%rdx,1),%rax
 29ff2bd:	xor    %rsi,%rsi
 29ff2c0:	cmp    %rcx,%rdx
 29ff2c3:	cmova  %rsi,%rax
 29ff2c7:	mov    0x18(%rax),%r12d
 29ff2cb:	mov    %r12,0x1d0(%rsp)
 29ff2d3:	mov    0x10(%rax),%r12
 29ff2d7:	mov    0x1c(%rax),%edx
 29ff2da:	jmp    29ff36a <wasm[0]::function[1015]::helper::object_read+0x120a>
 29ff2df:	xor    %eax,%eax
 29ff2e1:	test   $0x1,%edx
 29ff2e7:	jne    29ff328 <wasm[0]::function[1015]::helper::object_read+0x11c8>
 29ff2ed:	mov    0x2e0(%rsp),%r14
 29ff2f5:	mov    0x28(%r14),%rax
 29ff2f9:	mov    0x20(%r14),%rcx
 29ff2fd:	mov    %edx,%esi
 29ff2ff:	lea    0x4(%rcx,%rsi,1),%rcx
 29ff304:	xor    %rdi,%rdi
 29ff307:	cmp    %rax,%rsi
 29ff30a:	cmova  %rdi,%rcx
 29ff30e:	mov    (%rcx),%eax
 29ff310:	mov    0x190(%rsp),%rcx
 29ff318:	mov    0x28(%rcx),%rcx
 29ff31c:	cmp    0x120(%rcx),%eax
 29ff322:	sete   %al
 29ff325:	movzbl %al,%eax
 29ff328:	test   %eax,%eax
 29ff32a:	je     2a18e9e <wasm[0]::function[1015]::helper::object_read+0x1ad3e>
 29ff330:	test   %edx,%edx
 29ff332:	je     2a18ea0 <wasm[0]::function[1015]::helper::object_read+0x1ad40>
 29ff338:	mov    0x2e0(%rsp),%r14
 29ff340:	mov    0x28(%r14),%rcx
 29ff344:	mov    0x20(%r14),%rax
 29ff348:	mov    %edx,%edx
 29ff34a:	add    %rdx,%rax
 29ff34d:	xor    %rsi,%rsi
 29ff350:	cmp    %rcx,%rdx
 29ff353:	cmova  %rsi,%rax
 29ff357:	mov    0x18(%rax),%r12d
 29ff35b:	mov    %r12,0x1d0(%rsp)
 29ff363:	mov    0x10(%rax),%r12
 29ff367:	mov    0x1c(%rax),%edx
 29ff36a:	mov    0x278(%rsp),%rax
 29ff372:	mov    0x40(%rsp),%ecx
 29ff376:	mov    %rcx,0x210(%rsp)
 29ff37e:	mov    0x68(%rsp),%r9d
 29ff383:	mov    0x140(%rsp),%r8d
 29ff38b:	mov    0x50(%rsp),%r13d
 29ff390:	mov    %r13,0x208(%rsp)
 29ff398:	mov    0x70(%rsp),%r13d
 29ff39d:	mov    0x60(%rsp),%edi
 29ff3a1:	mov    0x110(%rsp),%ecx
 29ff3a8:	mov    %rcx,0x1a0(%rsp)
 29ff3b0:	mov    %rcx,%rsi
 29ff3b3:	mov    %rcx,0x1e0(%rsp)
 29ff3bb:	xor    %esi,%esi
 29ff3bd:	mov    %rsi,0x1e0(%rsp)
 29ff3c5:	mov    0x1d0(%rsp),%r15
 29ff3cd:	mov    0x1e0(%rsp),%rcx
 29ff3d5:	mov    %rcx,0x200(%rsp)
 29ff3dd:	jmp    29ffd9b <wasm[0]::function[1015]::helper::object_read+0x1c3b>
 29ff3e2:	mov    0xd0(%rsp),%eax
 29ff3e9:	test   %eax,%eax
 29ff3eb:	je     2a18ea2 <wasm[0]::function[1015]::helper::object_read+0x1ad42>
 29ff3f1:	mov    0xd0(%rsp),%ecx
 29ff3f8:	xor    %eax,%eax
 29ff3fa:	test   $0x1,%ecx
 29ff400:	jne    29ff458 <wasm[0]::function[1015]::helper::object_read+0x12f8>
 29ff406:	mov    0x2e0(%rsp),%r14
 29ff40e:	mov    0x28(%r14),%rax
 29ff412:	mov    0x20(%r14),%rsi
 29ff416:	mov    %ecx,%edx
 29ff418:	lea    0x4(%rsi,%rdx,1),%rcx
 29ff41d:	xor    %rsi,%rsi
 29ff420:	cmp    %rax,%rdx
 29ff423:	cmova  %rsi,%rcx
 29ff427:	mov    (%rcx),%esi
 29ff429:	mov    0x190(%rsp),%rcx
 29ff431:	mov    0x28(%rcx),%rax
 29ff435:	mov    0x158(%rax),%edx
 29ff43b:	cmp    %edx,%esi
 29ff43d:	sete   %al
 29ff440:	movzbl %al,%eax
 29ff443:	cmp    %edx,%esi
 29ff445:	je     29ff458 <wasm[0]::function[1015]::helper::object_read+0x12f8>
 29ff44b:	mov    0x190(%rsp),%rdi
 29ff453:	call   3039cc5 <wasmtime_builtin_is_subtype>
 29ff458:	test   %eax,%eax
 29ff45a:	je     2a18ea4 <wasm[0]::function[1015]::helper::object_read+0x1ad44>
 29ff460:	mov    0xd0(%rsp),%r11d
 29ff468:	mov    0xc0(%rsp),%edx
 29ff46f:	mov    0x40(%rsp),%eax
 29ff473:	mov    %rax,0x210(%rsp)
 29ff47b:	mov    0x68(%rsp),%r9d
 29ff480:	mov    0x140(%rsp),%r8d
 29ff488:	mov    0x50(%rsp),%r13d
 29ff48d:	mov    %r13,0x208(%rsp)
 29ff495:	mov    0x70(%rsp),%r13d
 29ff49a:	mov    0x60(%rsp),%edi
 29ff49e:	mov    0x110(%rsp),%eax
 29ff4a5:	mov    %rax,0x1a0(%rsp)
 29ff4ad:	xor    %eax,%eax
 29ff4af:	mov    0x1b8(%rsp),%rcx
 29ff4b7:	mov    %rax,0x1d8(%rsp)
 29ff4bf:	cmp    $0x4,%ecx
 29ff4c2:	je     29ff4ed <wasm[0]::function[1015]::helper::object_read+0x138d>
 29ff4c8:	mov    0x1d8(%rsp),%rax
 29ff4d0:	mov    0x1d8(%rsp),%rcx
 29ff4d8:	mov    %rcx,0x1e0(%rsp)
 29ff4e0:	mov    %rcx,0x200(%rsp)
 29ff4e8:	jmp    29ff92e <wasm[0]::function[1015]::helper::object_read+0x17ce>
 29ff4ed:	mov    %rcx,%rax
 29ff4f0:	mov    %rcx,0x238(%rsp)
 29ff4f8:	xor    %eax,%ecx
 29ff4fa:	mov    %rcx,0x238(%rsp)
 29ff502:	test   %r11d,%r11d
 29ff505:	je     2a18ea6 <wasm[0]::function[1015]::helper::object_read+0x1ad46>
 29ff50b:	test   %r11d,%r11d
 29ff50e:	je     2a18ea8 <wasm[0]::function[1015]::helper::object_read+0x1ad48>
 29ff514:	mov    0x2e0(%rsp),%r14
 29ff51c:	mov    0x28(%r14),%rax
 29ff520:	mov    0x20(%r14),%rbx
 29ff524:	mov    %r11d,%r15d
 29ff527:	lea    (%rbx,%r15,1),%rsi
 29ff52b:	xor    %r14,%r14
 29ff52e:	cmp    %rax,%r15
 29ff531:	cmova  %r14,%rsi
 29ff535:	mov    0x10(%rsi),%esi
 29ff538:	test   %esi,%esi
 29ff53a:	je     2a18eaa <wasm[0]::function[1015]::helper::object_read+0x1ad4a>
 29ff540:	test   %esi,%esi
 29ff542:	je     2a18eac <wasm[0]::function[1015]::helper::object_read+0x1ad4c>
 29ff548:	mov    %esi,%r15d
 29ff54b:	lea    (%rbx,%r15,1),%rsi
 29ff54f:	cmp    %rax,%r15
 29ff552:	cmova  %r14,%rsi
 29ff556:	mov    0x10(%rsi),%esi
 29ff559:	test   %esi,%esi
 29ff55b:	je     2a18eae <wasm[0]::function[1015]::helper::object_read+0x1ad4e>
 29ff561:	test   %esi,%esi
 29ff563:	je     2a18eb0 <wasm[0]::function[1015]::helper::object_read+0x1ad50>
 29ff569:	mov    %esi,%r10d
 29ff56c:	lea    0x10(%rbx,%r10,1),%r15
 29ff571:	cmp    %rax,%r10
 29ff574:	cmova  %r14,%r15
 29ff578:	mov    (%r15),%ebx
 29ff57b:	mov    0x190(%rsp),%rcx
 29ff583:	mov    0x28(%rcx),%r10
 29ff587:	mov    0x234(%r10),%r15d
 29ff58e:	mov    0x238(%rsp),%rax
 29ff596:	mov    %rax,0x1d8(%rsp)
 29ff59e:	mov    %rax,0x1e0(%rsp)
 29ff5a6:	mov    %rax,0x200(%rsp)
 29ff5ae:	mov    %esi,0xb8(%rsp)
 29ff5b5:	mov    %r9d,0x80(%rsp)
 29ff5bd:	mov    %r11d,0x48(%rsp)
 29ff5c2:	mov    %edx,0xa8(%rsp)
 29ff5c9:	mov    0x210(%rsp),%rdx
 29ff5d1:	mov    %edx,0xa0(%rsp)
 29ff5d8:	mov    %r8d,0x128(%rsp)
 29ff5e0:	mov    0x208(%rsp),%rcx
 29ff5e8:	mov    %ecx,0x110(%rsp)
 29ff5ef:	mov    %r13d,0x140(%rsp)
 29ff5f7:	mov    %edi,0xc0(%rsp)
 29ff5fe:	mov    0x1a0(%rsp),%r14
 29ff606:	mov    %r14d,0xd0(%rsp)
 29ff60e:	mov    0x2e8(%rsp),%rax
 29ff616:	mov    (%rax),%rcx
 29ff619:	mov    0x228(%rsp),%rax
 29ff621:	cmp    %rax,%rcx
 29ff624:	jae    2a17818 <wasm[0]::function[1015]::helper::object_read+0x196b8>
 29ff62a:	mov    0x48(%rsp),%r11d
 29ff62f:	mov    0xa8(%rsp),%edx
 29ff636:	mov    0xa0(%rsp),%eax
 29ff63d:	mov    %rax,0x210(%rsp)
 29ff645:	mov    0x80(%rsp),%r9d
 29ff64d:	mov    0x128(%rsp),%r8d
 29ff655:	mov    0x110(%rsp),%r13d
 29ff65d:	mov    %r13,0x208(%rsp)
 29ff665:	mov    0x140(%rsp),%r13d
 29ff66d:	mov    0xc0(%rsp),%edi
 29ff674:	mov    0xd0(%rsp),%r14d
 29ff67c:	mov    0x238(%rsp),%rcx
 29ff684:	mov    %r14,0x1a0(%rsp)
 29ff68c:	cmp    %ebx,%ecx
 29ff68e:	jb     29ff6a1 <wasm[0]::function[1015]::helper::object_read+0x1541>
 29ff694:	mov    0x1d8(%rsp),%rax
 29ff69c:	jmp    29ff92e <wasm[0]::function[1015]::helper::object_read+0x17ce>
 29ff6a1:	mov    0xb8(%rsp),%eax
 29ff6a8:	test   %eax,%eax
 29ff6aa:	je     2a18eb2 <wasm[0]::function[1015]::helper::object_read+0x1ad52>
 29ff6b0:	test   %eax,%eax
 29ff6b2:	je     2a18eb4 <wasm[0]::function[1015]::helper::object_read+0x1ad54>
 29ff6b8:	mov    0x2e0(%rsp),%r14
 29ff6c0:	mov    0x28(%r14),%rcx
 29ff6c4:	mov    0x20(%r14),%rdx
 29ff6c8:	mov    %eax,%r8d
 29ff6cb:	lea    0x10(%rdx,%r8,1),%rdi
 29ff6d0:	xor    %rsi,%rsi
 29ff6d3:	cmp    %rcx,%r8
 29ff6d6:	cmova  %rsi,%rdi
 29ff6da:	mov    (%rdi),%edi
 29ff6dc:	mov    0x238(%rsp),%r8
 29ff6e4:	cmp    %edi,%r8d
 29ff6e7:	jae    2a18eb6 <wasm[0]::function[1015]::helper::object_read+0x1ad56>
 29ff6ed:	mov    %edi,%r8d
 29ff6f0:	shl    $0x2,%r8
 29ff6f4:	shr    $0x20,%r8
 29ff6f8:	test   %r8,%r8
 29ff6fb:	jne    2a18eb8 <wasm[0]::function[1015]::helper::object_read+0x1ad58>
 29ff701:	shl    $0x2,%edi
 29ff704:	add    $0x14,%edi
 29ff707:	jb     2a18eba <wasm[0]::function[1015]::helper::object_read+0x1ad5a>
 29ff70d:	add    %edi,%eax
 29ff70f:	jb     2a18ebc <wasm[0]::function[1015]::helper::object_read+0x1ad5c>
 29ff715:	mov    %eax,%r8d
 29ff718:	lea    (%rdx,%r8,1),%rax
 29ff71c:	cmp    %rcx,%r8
 29ff71f:	cmova  %rsi,%rax
 29ff723:	mov    0x238(%rsp),%rcx
 29ff72b:	shl    $0x2,%ecx
 29ff72e:	add    $0x14,%ecx
 29ff734:	sub    %ecx,%edi
 29ff736:	sub    %rdi,%rax
 29ff739:	mov    (%rax),%edx
 29ff73b:	test   %edx,%edx
 29ff73d:	je     2a18ebe <wasm[0]::function[1015]::helper::object_read+0x1ad5e>
 29ff743:	mov    0x1b8(%rsp),%rcx
 29ff74b:	cmp    $0x4,%ecx
 29ff74e:	je     29ff7bc <wasm[0]::function[1015]::helper::object_read+0x165c>
 29ff754:	mov    0xb8(%rsp),%esi
 29ff75b:	mov    0x80(%rsp),%r9d
 29ff763:	mov    0x48(%rsp),%r11d
 29ff768:	mov    0xa8(%rsp),%edx
 29ff76f:	mov    0xa0(%rsp),%eax
 29ff776:	mov    %rax,0x210(%rsp)
 29ff77e:	mov    0x128(%rsp),%r8d
 29ff786:	mov    0x110(%rsp),%r13d
 29ff78e:	mov    %r13,0x208(%rsp)
 29ff796:	mov    0x140(%rsp),%r13d
 29ff79e:	mov    0xc0(%rsp),%edi
 29ff7a5:	mov    0xd0(%rsp),%r14d
 29ff7ad:	mov    %r14,0x1a0(%rsp)
 29ff7b5:	xor    %eax,%eax
 29ff7b7:	jmp    29ff903 <wasm[0]::function[1015]::helper::object_read+0x17a3>
 29ff7bc:	mov    0x80(%rsp),%eax
 29ff7c3:	cmp    %eax,%edx
 29ff7c5:	je     29ff89a <wasm[0]::function[1015]::helper::object_read+0x173a>
 29ff7cb:	xor    %ecx,%ecx
 29ff7cd:	test   %edx,%edx
 29ff7cf:	je     29ff80f <wasm[0]::function[1015]::helper::object_read+0x16af>
 29ff7d5:	xor    %ecx,%ecx
 29ff7d7:	test   $0x1,%edx
 29ff7dd:	jne    29ff80f <wasm[0]::function[1015]::helper::object_read+0x16af>
 29ff7e3:	mov    0x2e0(%rsp),%r14
 29ff7eb:	mov    0x28(%r14),%rcx
 29ff7ef:	mov    0x20(%r14),%rsi
 29ff7f3:	mov    %edx,%edi
 29ff7f5:	lea    0x4(%rsi,%rdi,1),%rsi
 29ff7fa:	xor    %r8,%r8
 29ff7fd:	cmp    %rcx,%rdi
 29ff800:	cmova  %r8,%rsi
 29ff804:	mov    (%rsi),%ecx
 29ff806:	cmp    %r15d,%ecx
 29ff809:	sete   %cl
 29ff80c:	movzbl %cl,%ecx
 29ff80f:	test   %ecx,%ecx
 29ff811:	je     2a18ec0 <wasm[0]::function[1015]::helper::object_read+0x1ad60>
 29ff817:	xor    %r11d,%r11d
 29ff81a:	test   %eax,%eax
 29ff81c:	je     29ff865 <wasm[0]::function[1015]::helper::object_read+0x1705>
 29ff822:	mov    0x80(%rsp),%eax
 29ff829:	xor    %r11d,%r11d
 29ff82c:	test   $0x1,%eax
 29ff831:	jne    29ff865 <wasm[0]::function[1015]::helper::object_read+0x1705>
 29ff837:	mov    0x2e0(%rsp),%r14
 29ff83f:	mov    0x28(%r14),%rsi
 29ff843:	mov    0x20(%r14),%r8
 29ff847:	mov    %eax,%edi
 29ff849:	lea    0x4(%r8,%rdi,1),%rax
 29ff84e:	xor    %r8,%r8
 29ff851:	cmp    %rsi,%rdi
 29ff854:	cmova  %r8,%rax
 29ff858:	mov    (%rax),%esi
 29ff85a:	cmp    %r15d,%esi
 29ff85d:	sete   %sil
 29ff861:	movzbl %sil,%r11d
 29ff865:	test   %r11d,%r11d
 29ff868:	je     2a18ec2 <wasm[0]::function[1015]::helper::object_read+0x1ad62>
 29ff86e:	mov    0x80(%rsp),%ecx
 29ff875:	xor    %r8d,%r8d
 29ff878:	test   %ecx,%ecx
 29ff87a:	je     2a18ec4 <wasm[0]::function[1015]::helper::object_read+0x1ad64>
 29ff880:	mov    0x190(%rsp),%rsi
 29ff888:	mov    0x190(%rsp),%rdi
 29ff890:	call   2b02800 <wasm[0]::function[1057]::helper::string_equality>
 29ff895:	jmp    29ff8a2 <wasm[0]::function[1015]::helper::object_read+0x1742>
 29ff89a:	mov    0x278(%rsp),%rax
 29ff8a2:	mov    0xb8(%rsp),%esi
 29ff8a9:	mov    0x80(%rsp),%r9d
 29ff8b1:	mov    0x48(%rsp),%r11d
 29ff8b6:	mov    0xa8(%rsp),%edx
 29ff8bd:	mov    0xa0(%rsp),%ecx
 29ff8c4:	mov    %rcx,0x210(%rsp)
 29ff8cc:	mov    0x128(%rsp),%r8d
 29ff8d4:	mov    0x110(%rsp),%r13d
 29ff8dc:	mov    %r13,0x208(%rsp)
 29ff8e4:	mov    0x140(%rsp),%r13d
 29ff8ec:	mov    0xc0(%rsp),%edi
 29ff8f3:	mov    0xd0(%rsp),%r14d
 29ff8fb:	mov    %r14,0x1a0(%rsp)
 29ff903:	test   %eax,%eax
 29ff905:	jne    29ff92e <wasm[0]::function[1015]::helper::object_read+0x17ce>
 29ff90b:	mov    0x238(%rsp),%rcx
 29ff913:	add    $0x1,%ecx
 29ff919:	mov    %rcx,0x238(%rsp)
 29ff921:	mov    %rax,0x1d8(%rsp)
 29ff929:	jmp    29ff5ae <wasm[0]::function[1015]::helper::object_read+0x144e>
 29ff92e:	test   %eax,%eax
 29ff930:	jne    29ff943 <wasm[0]::function[1015]::helper::object_read+0x17e3>
 29ff936:	mov    0x1d0(%rsp),%r15
 29ff93e:	jmp    29ffd9b <wasm[0]::function[1015]::helper::object_read+0x1c3b>
 29ff943:	test   %r11d,%r11d
 29ff946:	je     2a18ec6 <wasm[0]::function[1015]::helper::object_read+0x1ad66>
 29ff94c:	xor    %edx,%edx
 29ff94e:	test   $0x1,%r11d
 29ff955:	jne    29ff997 <wasm[0]::function[1015]::helper::object_read+0x1837>
 29ff95b:	mov    0x2e0(%rsp),%r14
 29ff963:	mov    0x28(%r14),%rdx
 29ff967:	mov    0x20(%r14),%rsi
 29ff96b:	mov    %r11d,%ebx
 29ff96e:	lea    0x4(%rsi,%rbx,1),%rsi
 29ff973:	xor    %r12,%r12
 29ff976:	cmp    %rdx,%rbx
 29ff979:	cmova  %r12,%rsi
 29ff97d:	mov    (%rsi),%edx
 29ff97f:	mov    0x190(%rsp),%rcx
 29ff987:	mov    0x28(%rcx),%rcx
 29ff98b:	cmp    0x160(%rcx),%edx
 29ff991:	sete   %cl
 29ff994:	movzbl %cl,%edx
 29ff997:	test   %edx,%edx
 29ff999:	jne    29ffbfd <wasm[0]::function[1015]::helper::object_read+0x1a9d>
 29ff99f:	xor    %edx,%edx
 29ff9a1:	test   $0x1,%r11d
 29ff9a8:	jne    29ff9ea <wasm[0]::function[1015]::helper::object_read+0x188a>
 29ff9ae:	mov    0x2e0(%rsp),%r14
 29ff9b6:	mov    0x28(%r14),%rdx
 29ff9ba:	mov    0x20(%r14),%rsi
 29ff9be:	mov    %r11d,%ebx
 29ff9c1:	lea    0x4(%rsi,%rbx,1),%rsi
 29ff9c6:	xor    %r12,%r12
 29ff9c9:	cmp    %rdx,%rbx
 29ff9cc:	cmova  %r12,%rsi
 29ff9d0:	mov    (%rsi),%edx
 29ff9d2:	mov    0x190(%rsp),%rcx
 29ff9da:	mov    0x28(%rcx),%rcx
 29ff9de:	cmp    0x15c(%rcx),%edx
 29ff9e4:	sete   %cl
 29ff9e7:	movzbl %cl,%edx
 29ff9ea:	test   %edx,%edx
 29ff9ec:	je     2a18ec8 <wasm[0]::function[1015]::helper::object_read+0x1ad68>
 29ff9f2:	test   %r11d,%r11d
 29ff9f5:	je     2a18eca <wasm[0]::function[1015]::helper::object_read+0x1ad6a>
 29ff9fb:	mov    0x2e0(%rsp),%r14
 29ffa03:	mov    0x28(%r14),%rbx
 29ffa07:	mov    0x20(%r14),%r14
 29ffa0b:	mov    %r11d,%edx
 29ffa0e:	lea    (%r14,%rdx,1),%rsi
 29ffa12:	xor    %r12,%r12
 29ffa15:	cmp    %rbx,%rdx
 29ffa18:	cmova  %r12,%rsi
 29ffa1c:	mov    0x14(%rsi),%r11d
 29ffa20:	mov    0x18(%rsi),%edx
 29ffa23:	mov    0x1c(%rsi),%esi
 29ffa26:	test   %r11d,%r11d
 29ffa29:	je     2a18ecc <wasm[0]::function[1015]::helper::object_read+0x1ad6c>
 29ffa2f:	test   %r11d,%r11d
 29ffa32:	je     2a18ece <wasm[0]::function[1015]::helper::object_read+0x1ad6e>
 29ffa38:	mov    %r11d,%r10d
 29ffa3b:	lea    0x10(%r14,%r10,1),%r15
 29ffa40:	cmp    %rbx,%r10
 29ffa43:	cmova  %r12,%r15
 29ffa47:	mov    (%r15),%r15d
 29ffa4a:	mov    0x238(%rsp),%rcx
 29ffa52:	cmp    %r15d,%ecx
 29ffa55:	jae    2a18ed0 <wasm[0]::function[1015]::helper::object_read+0x1ad70>
 29ffa5b:	mov    %r15d,%r10d
 29ffa5e:	shr    $0x20,%r10
 29ffa62:	test   %r10,%r10
 29ffa65:	jne    2a18ed2 <wasm[0]::function[1015]::helper::object_read+0x1ad72>
 29ffa6b:	add    $0x14,%r15d
 29ffa6f:	jb     2a18ed4 <wasm[0]::function[1015]::helper::object_read+0x1ad74>
 29ffa75:	add    %r15d,%r11d
 29ffa78:	jb     2a18ed6 <wasm[0]::function[1015]::helper::object_read+0x1ad76>
 29ffa7e:	mov    %r11d,%r10d
 29ffa81:	lea    (%r14,%r10,1),%r11
 29ffa85:	cmp    %rbx,%r10
 29ffa88:	cmova  %r12,%r11
 29ffa8c:	lea    0x14(%rcx),%r10d
 29ffa90:	sub    %r10d,%r15d
 29ffa93:	sub    %r15,%r11
 29ffa96:	movzbq (%r11),%r10
 29ffa9a:	mov    %r10,0x240(%rsp)
 29ffaa2:	test   %edx,%edx
 29ffaa4:	je     29ffb40 <wasm[0]::function[1015]::helper::object_read+0x19e0>
 29ffaaa:	test   %edx,%edx
 29ffaac:	je     2a18ed8 <wasm[0]::function[1015]::helper::object_read+0x1ad78>
 29ffab2:	test   %edx,%edx
 29ffab4:	je     2a18eda <wasm[0]::function[1015]::helper::object_read+0x1ad7a>
 29ffaba:	mov    0x2e0(%rsp),%r14
 29ffac2:	mov    0x28(%r14),%rbx
 29ffac6:	mov    0x20(%r14),%r12
 29ffaca:	mov    %edx,%r11d
 29ffacd:	lea    0x10(%r12,%r11,1),%r15
 29ffad2:	xor    %r14,%r14
 29ffad5:	cmp    %rbx,%r11
 29ffad8:	cmova  %r14,%r15
 29ffadc:	mov    (%r15),%r15d
 29ffadf:	mov    0x238(%rsp),%rcx
 29ffae7:	cmp    %r15d,%ecx
 29ffaea:	jae    2a18edc <wasm[0]::function[1015]::helper::object_read+0x1ad7c>
 29ffaf0:	mov    %r15d,%r11d
 29ffaf3:	shl    $0x3,%r11
 29ffaf7:	shr    $0x20,%r11
 29ffafb:	test   %r11,%r11
 29ffafe:	jne    2a18ede <wasm[0]::function[1015]::helper::object_read+0x1ad7e>
 29ffb04:	shl    $0x3,%r15d
 29ffb08:	add    $0x18,%r15d
 29ffb0c:	jb     2a18ee0 <wasm[0]::function[1015]::helper::object_read+0x1ad80>
 29ffb12:	add    %r15d,%edx
 29ffb15:	jb     2a18ee2 <wasm[0]::function[1015]::helper::object_read+0x1ad82>
 29ffb1b:	mov    %edx,%r10d
 29ffb1e:	lea    (%r12,%r10,1),%rdx
 29ffb22:	cmp    %rbx,%r10
 29ffb25:	cmova  %r14,%rdx
 29ffb29:	mov    %rcx,%r10
 29ffb2c:	shl    $0x3,%r10d
 29ffb30:	add    $0x18,%r10d
 29ffb37:	sub    %r10d,%r15d
 29ffb3a:	sub    %r15,%rdx
 29ffb3d:	mov    (%rdx),%r12
 29ffb40:	xor    %edx,%edx
 29ffb42:	test   %esi,%esi
 29ffb44:	jne    29ffb57 <wasm[0]::function[1015]::helper::object_read+0x19f7>
 29ffb4a:	mov    0x240(%rsp),%r10
 29ffb52:	jmp    29ffbf4 <wasm[0]::function[1015]::helper::object_read+0x1a94>
 29ffb57:	test   %esi,%esi
 29ffb59:	je     2a18ee4 <wasm[0]::function[1015]::helper::object_read+0x1ad84>
 29ffb5f:	test   %esi,%esi
 29ffb61:	je     2a18ee6 <wasm[0]::function[1015]::helper::object_read+0x1ad86>
 29ffb67:	mov    0x2e0(%rsp),%r14
 29ffb6f:	mov    0x28(%r14),%rdx
 29ffb73:	mov    0x20(%r14),%rbx
 29ffb77:	mov    %esi,%r11d
 29ffb7a:	lea    0x10(%rbx,%r11,1),%r15
 29ffb7f:	xor    %r14,%r14
 29ffb82:	cmp    %rdx,%r11
 29ffb85:	cmova  %r14,%r15
 29ffb89:	mov    (%r15),%r15d
 29ffb8c:	mov    0x238(%rsp),%rcx
 29ffb94:	cmp    %r15d,%ecx
 29ffb97:	jae    2a18ee8 <wasm[0]::function[1015]::helper::object_read+0x1ad88>
 29ffb9d:	mov    %r15d,%r11d
 29ffba0:	shl    $0x2,%r11
 29ffba4:	shr    $0x20,%r11
 29ffba8:	test   %r11,%r11
 29ffbab:	jne    2a18eea <wasm[0]::function[1015]::helper::object_read+0x1ad8a>
 29ffbb1:	shl    $0x2,%r15d
 29ffbb5:	add    $0x14,%r15d
 29ffbb9:	jb     2a18eec <wasm[0]::function[1015]::helper::object_read+0x1ad8c>
 29ffbbf:	add    %r15d,%esi
 29ffbc2:	jb     2a18eee <wasm[0]::function[1015]::helper::object_read+0x1ad8e>
 29ffbc8:	mov    %esi,%r10d
 29ffbcb:	lea    (%rbx,%r10,1),%rsi
 29ffbcf:	cmp    %rdx,%r10
 29ffbd2:	cmova  %r14,%rsi
 29ffbd6:	shl    $0x2,%ecx
 29ffbd9:	mov    %rcx,0x238(%rsp)
 29ffbe1:	lea    0x14(%rcx),%edx
 29ffbe4:	sub    %edx,%r15d
 29ffbe7:	sub    %r15,%rsi
 29ffbea:	mov    (%rsi),%edx
 29ffbec:	mov    0x240(%rsp),%r10
 29ffbf4:	movzbl %r10b,%r15d
 29ffbf8:	jmp    29ffd9b <wasm[0]::function[1015]::helper::object_read+0x1c3b>
 29ffbfd:	xor    %edx,%edx
 29ffbff:	test   $0x1,%r11d
 29ffc06:	jne    29ffc48 <wasm[0]::function[1015]::helper::object_read+0x1ae8>
 29ffc0c:	mov    0x2e0(%rsp),%r14
 29ffc14:	mov    0x28(%r14),%rdx
 29ffc18:	mov    0x20(%r14),%rsi
 29ffc1c:	mov    %r11d,%ebx
 29ffc1f:	lea    0x4(%rsi,%rbx,1),%rsi
 29ffc24:	xor    %r12,%r12
 29ffc27:	cmp    %rdx,%rbx
 29ffc2a:	cmova  %r12,%rsi
 29ffc2e:	mov    (%rsi),%edx
 29ffc30:	mov    0x190(%rsp),%rcx
 29ffc38:	mov    0x28(%rcx),%rcx
 29ffc3c:	cmp    0x160(%rcx),%edx
 29ffc42:	sete   %cl
 29ffc45:	movzbl %cl,%edx
 29ffc48:	test   %edx,%edx
 29ffc4a:	je     2a18ef0 <wasm[0]::function[1015]::helper::object_read+0x1ad90>
 29ffc50:	test   %r11d,%r11d
 29ffc53:	je     2a18ef2 <wasm[0]::function[1015]::helper::object_read+0x1ad92>
 29ffc59:	mov    0x2e0(%rsp),%r14
 29ffc61:	mov    0x28(%r14),%rsi
 29ffc65:	mov    0x20(%r14),%rbx
 29ffc69:	mov    %r11d,%edx
 29ffc6c:	lea    (%rbx,%rdx,1),%r12
 29ffc70:	xor    %r11,%r11
 29ffc73:	cmp    %rsi,%rdx
 29ffc76:	cmova  %r11,%r12
 29ffc7a:	mov    0x10(%r12),%r12d
 29ffc7f:	test   %r12d,%r12d
 29ffc82:	je     2a18ef4 <wasm[0]::function[1015]::helper::object_read+0x1ad94>
 29ffc88:	test   %r12d,%r12d
 29ffc8b:	je     2a18ef6 <wasm[0]::function[1015]::helper::object_read+0x1ad96>
 29ffc91:	mov    %r12d,%r10d
 29ffc94:	lea    (%rbx,%r10,1),%r12
 29ffc98:	cmp    %rsi,%r10
 29ffc9b:	cmova  %r11,%r12
 29ffc9f:	mov    0x10(%r12),%r12d
 29ffca4:	test   %r12d,%r12d
 29ffca7:	je     2a18ef8 <wasm[0]::function[1015]::helper::object_read+0x1ad98>
 29ffcad:	test   %r12d,%r12d
 29ffcb0:	je     2a18efa <wasm[0]::function[1015]::helper::object_read+0x1ad9a>
 29ffcb6:	mov    %r12d,%r10d
 29ffcb9:	lea    0x10(%rbx,%r10,1),%rbx
 29ffcbe:	cmp    %rsi,%r10
 29ffcc1:	cmova  %r11,%rbx
 29ffcc5:	mov    0x238(%rsp),%rcx
 29ffccd:	cmp    (%rbx),%ecx
 29ffccf:	setae  %sil
 29ffcd3:	cmp    $0x2,%ecx
 29ffcd6:	setae  %r10b
 29ffcda:	or     %r10d,%esi
 29ffcdd:	test   %sil,%sil
 29ffce0:	jne    2a18efc <wasm[0]::function[1015]::helper::object_read+0x1ad9c>
 29ffce6:	mov    0x2e0(%rsp),%r14
 29ffcee:	mov    0x28(%r14),%r11
 29ffcf2:	mov    %rdx,%rsi
 29ffcf5:	add    0x20(%r14),%rsi
 29ffcf9:	xor    %rbx,%rbx
 29ffcfc:	cmp    %r11,%rdx
 29ffcff:	cmova  %rbx,%rsi
 29ffd03:	mov    0x14(%rsi),%r15d
 29ffd07:	mov    0x238(%rsp),%rcx
 29ffd0f:	mov    0x238(%rsp),%rsi
 29ffd17:	test   %esi,%ecx
 29ffd19:	je     29ffd51 <wasm[0]::function[1015]::helper::object_read+0x1bf1>
 29ffd1f:	mov    0x2e0(%rsp),%r14
 29ffd27:	mov    0x28(%r14),%r11
 29ffd2b:	mov    0x20(%r14),%rcx
 29ffd2f:	lea    (%rcx,%rdx,1),%rsi
 29ffd33:	xor    %rbx,%rbx
 29ffd36:	cmp    %r11,%rdx
 29ffd39:	cmova  %rbx,%rsi
 29ffd3d:	mov    0x20(%rsi),%r12
 29ffd41:	mov    0x2c(%rsi),%edx
 29ffd44:	mov    0x238(%rsp),%rcx
 29ffd4c:	jmp    29ffd7e <wasm[0]::function[1015]::helper::object_read+0x1c1e>
 29ffd51:	mov    0x2e0(%rsp),%r14
 29ffd59:	mov    0x28(%r14),%r11
 29ffd5d:	mov    0x20(%r14),%rcx
 29ffd61:	lea    (%rcx,%rdx,1),%rsi
 29ffd65:	xor    %rbx,%rbx
 29ffd68:	cmp    %r11,%rdx
 29ffd6b:	cmova  %rbx,%rsi
 29ffd6f:	mov    0x18(%rsi),%r12
 29ffd73:	mov    0x28(%rsi),%edx
 29ffd76:	mov    0x238(%rsp),%rcx
 29ffd7e:	mov    0x238(%rsp),%rcx
 29ffd86:	shl    $0x3,%ecx
 29ffd89:	mov    %rcx,0x238(%rsp)
 29ffd91:	shr    %cl,%r15d
 29ffd94:	and    $0xff,%r15d
 29ffd9b:	test   %eax,%eax
 29ffd9d:	jne    29ffdc0 <wasm[0]::function[1015]::helper::object_read+0x1c60>
 29ffda3:	mov    0x1a0(%rsp),%rdx
 29ffdab:	mov    0x288(%rsp),%r12
 29ffdb3:	mov    0x280(%rsp),%r15
 29ffdbb:	jmp    29ffdda <wasm[0]::function[1015]::helper::object_read+0x1c7a>
 29ffdc0:	xor    %esi,%esi
 29ffdc2:	mov    %rsi,0x290(%rsp)
 29ffdca:	mov    0x290(%rsp),%rcx
 29ffdd2:	mov    %rcx,0x298(%rsp)
 29ffdda:	mov    0x210(%rsp),%rcx
 29ffde2:	mov    %r15,0x280(%rsp)
 29ffdea:	mov    %r12,0x288(%rsp)
 29ffdf2:	mov    %ecx,0x110(%rsp)
 29ffdf9:	mov    %r9d,0x128(%rsp)
 29ffe01:	mov    %r8d,0xa0(%rsp)
 29ffe09:	mov    0x208(%rsp),%rcx
 29ffe11:	mov    %ecx,0xa8(%rsp)
 29ffe18:	mov    %r13d,0x48(%rsp)
 29ffe1d:	mov    %edi,0x80(%rsp)
 29ffe24:	mov    %edx,0xb8(%rsp)
 29ffe2b:	test   %eax,%eax
 29ffe2d:	je     29ffe48 <wasm[0]::function[1015]::helper::object_read+0x1ce8>
 29ffe33:	mov    0x290(%rsp),%rsi
 29ffe3b:	mov    0x298(%rsp),%rdi
 29ffe43:	jmp    2a0cf9a <wasm[0]::function[1015]::helper::object_read+0xee3a>
 29ffe48:	xor    %r10d,%r10d
 29ffe4b:	mov    0x210(%rsp),%rax
 29ffe53:	mov    0x210(%rsp),%rcx
 29ffe5b:	test   %ecx,%eax
 29ffe5d:	je     29ffebe <wasm[0]::function[1015]::helper::object_read+0x1d5e>
 29ffe63:	xor    %r10d,%r10d
 29ffe66:	mov    0x210(%rsp),%rax
 29ffe6e:	test   $0x1,%eax
 29ffe73:	jne    29ffebe <wasm[0]::function[1015]::helper::object_read+0x1d5e>
 29ffe79:	mov    0x2e0(%rsp),%r14
 29ffe81:	mov    0x28(%r14),%rax
 29ffe85:	mov    0x20(%r14),%rsi
 29ffe89:	mov    0x210(%rsp),%rcx
 29ffe91:	mov    %ecx,%r10d
 29ffe94:	lea    0x4(%rsi,%r10,1),%rsi
 29ffe99:	xor    %r11,%r11
 29ffe9c:	cmp    %rax,%r10
 29ffe9f:	cmova  %r11,%rsi
 29ffea3:	mov    (%rsi),%eax
 29ffea5:	mov    0x190(%rsp),%rcx
 29ffead:	mov    0x28(%rcx),%rcx
 29ffeb1:	cmp    0x254(%rcx),%eax
 29ffeb7:	sete   %al
 29ffeba:	movzbl %al,%r10d
 29ffebe:	xor    %ebx,%ebx
 29ffec0:	test   %r10d,%r10d
 29ffec3:	jne    29ffede <wasm[0]::function[1015]::helper::object_read+0x1d7e>
 29ffec9:	mov    0x210(%rsp),%rax
 29ffed1:	mov    0x290(%rsp),%rsi
 29ffed9:	jmp    2a02e68 <wasm[0]::function[1015]::helper::object_read+0x4d08>
 29ffede:	xor    %eax,%eax
 29ffee0:	mov    0x210(%rsp),%r10
 29ffee8:	mov    0x210(%rsp),%r11
 29ffef0:	test   %r10d,%r11d
 29ffef3:	je     29fff53 <wasm[0]::function[1015]::helper::object_read+0x1df3>
 29ffef9:	xor    %eax,%eax
 29ffefb:	mov    0x210(%rsp),%rcx
 29fff03:	test   $0x1,%ecx
 29fff09:	jne    29fff53 <wasm[0]::function[1015]::helper::object_read+0x1df3>
 29fff0f:	mov    0x2e0(%rsp),%r14
 29fff17:	mov    0x28(%r14),%rax
 29fff1b:	mov    0x20(%r14),%rsi
 29fff1f:	mov    0x210(%rsp),%rcx
 29fff27:	mov    %ecx,%r10d
 29fff2a:	lea    0x4(%rsi,%r10,1),%rsi
 29fff2f:	xor    %r11,%r11
 29fff32:	cmp    %rax,%r10
 29fff35:	cmova  %r11,%rsi
 29fff39:	mov    (%rsi),%eax
 29fff3b:	mov    0x190(%rsp),%rcx
 29fff43:	mov    0x28(%rcx),%rcx
 29fff47:	cmp    0x254(%rcx),%eax
 29fff4d:	sete   %al
 29fff50:	movzbl %al,%eax
 29fff53:	test   %eax,%eax
 29fff55:	je     2a18efe <wasm[0]::function[1015]::helper::object_read+0x1ad9e>
 29fff5b:	xor    %eax,%eax
 29fff5d:	mov    0x1b8(%rsp),%rcx
 29fff65:	cmp    $0x4,%ecx
 29fff68:	je     29fff7b <wasm[0]::function[1015]::helper::object_read+0x1e1b>
 29fff6e:	mov    0x210(%rsp),%r10
 29fff76:	jmp    2a00832 <wasm[0]::function[1015]::helper::object_read+0x26d2>
 29fff7b:	mov    0x128(%rsp),%r9d
 29fff83:	xor    %r10d,%r10d
 29fff86:	test   %r9d,%r9d
 29fff89:	je     29fffdc <wasm[0]::function[1015]::helper::object_read+0x1e7c>
 29fff8f:	xor    %r10d,%r10d
 29fff92:	test   $0x1,%r9d
 29fff99:	jne    29fffdc <wasm[0]::function[1015]::helper::object_read+0x1e7c>
 29fff9f:	mov    0x2e0(%rsp),%r14
 29fffa7:	mov    0x28(%r14),%rax
 29fffab:	mov    0x20(%r14),%rcx
 29fffaf:	mov    %r9d,%edx
 29fffb2:	lea    0x4(%rcx,%rdx,1),%rcx
 29fffb7:	xor    %rsi,%rsi
 29fffba:	cmp    %rax,%rdx
 29fffbd:	cmova  %rsi,%rcx
 29fffc1:	mov    (%rcx),%eax
 29fffc3:	mov    0x190(%rsp),%rcx
 29fffcb:	mov    0x28(%rcx),%rcx
 29fffcf:	cmp    0x234(%rcx),%eax
 29fffd5:	sete   %al
 29fffd8:	movzbl %al,%r10d
 29fffdc:	test   %r10d,%r10d
 29fffdf:	je     2a18f00 <wasm[0]::function[1015]::helper::object_read+0x1ada0>
 29fffe5:	test   %r9d,%r9d
 29fffe8:	je     2a18f02 <wasm[0]::function[1015]::helper::object_read+0x1ada2>
 29fffee:	test   %r9d,%r9d
 29ffff1:	je     2a18f04 <wasm[0]::function[1015]::helper::object_read+0x1ada4>
 29ffff7:	mov    0x2e0(%rsp),%r14
 29fffff:	mov    0x28(%r14),%rcx
 2a00003:	mov    0x20(%r14),%rdx
 2a00007:	mov    %r9d,%edi
 2a0000a:	lea    (%rdx,%rdi,1),%rax
 2a0000e:	xor    %rsi,%rsi
 2a00011:	cmp    %rcx,%rdi
 2a00014:	cmova  %rsi,%rax
 2a00018:	mov    0x10(%rax),%edi
 2a0001b:	xor    %eax,%eax
 2a0001d:	test   %edi,%edi
 2a0001f:	je     2a18f06 <wasm[0]::function[1015]::helper::object_read+0x1ada6>
 2a00025:	test   %edi,%edi
 2a00027:	je     2a18f08 <wasm[0]::function[1015]::helper::object_read+0x1ada8>
 2a0002d:	mov    %edi,%edi
 2a0002f:	lea    0x10(%rdx,%rdi,1),%rdx
 2a00034:	cmp    %rcx,%rdi
 2a00037:	cmova  %rsi,%rdx
 2a0003b:	mov    (%rdx),%esi
 2a0003d:	mov    0x110(%rsp),%edx
 2a00044:	mov    %rdx,0x210(%rsp)
 2a0004c:	mov    0xa0(%rsp),%r8d
 2a00054:	mov    0xa8(%rsp),%r13d
 2a0005c:	mov    %r13,0x208(%rsp)
 2a00064:	mov    0x48(%rsp),%r13d
 2a00069:	mov    0x80(%rsp),%edi
 2a00070:	mov    0xb8(%rsp),%edx
 2a00077:	cmp    $0x6,%esi
 2a0007a:	je     2a0008d <wasm[0]::function[1015]::helper::object_read+0x1f2d>
 2a00080:	mov    0x210(%rsp),%r10
 2a00088:	jmp    2a00832 <wasm[0]::function[1015]::helper::object_read+0x26d2>
 2a0008d:	mov    $0x8c,%edx
 2a00092:	mov    0x190(%rsp),%rsi
 2a0009a:	mov    0x190(%rsp),%rdi
 2a000a2:	call   2f4f240 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 2a000a7:	test   %eax,%eax
 2a000a9:	je     2a18f0a <wasm[0]::function[1015]::helper::object_read+0x1adaa>
 2a000af:	mov    0x1b8(%rsp),%rcx
 2a000b7:	cmp    $0x4,%ecx
 2a000ba:	je     2a00111 <wasm[0]::function[1015]::helper::object_read+0x1fb1>
 2a000c0:	mov    0x110(%rsp),%edx
 2a000c7:	mov    %rdx,0x210(%rsp)
 2a000cf:	mov    0x128(%rsp),%r9d
 2a000d7:	mov    0xa0(%rsp),%r8d
 2a000df:	mov    0xa8(%rsp),%r13d
 2a000e7:	mov    %r13,0x208(%rsp)
 2a000ef:	mov    0x48(%rsp),%r13d
 2a000f4:	mov    0x80(%rsp),%edi
 2a000fb:	mov    0xb8(%rsp),%edx
 2a00102:	xor    %eax,%eax
 2a00104:	mov    0x210(%rsp),%r10
 2a0010c:	jmp    2a00832 <wasm[0]::function[1015]::helper::object_read+0x26d2>
 2a00111:	mov    0x1b8(%rsp),%rcx
 2a00119:	cmp    $0x3,%ecx
 2a0011c:	je     2a0079f <wasm[0]::function[1015]::helper::object_read+0x263f>
 2a00122:	mov    0x1b8(%rsp),%rcx
 2a0012a:	cmp    $0x4,%ecx
 2a0012d:	je     2a0063c <wasm[0]::function[1015]::helper::object_read+0x24dc>
 2a00133:	mov    0x1b8(%rsp),%rcx
 2a0013b:	cmp    $0xa,%ecx
 2a0013e:	je     2a00203 <wasm[0]::function[1015]::helper::object_read+0x20a3>
 2a00144:	mov    0x1b8(%rsp),%rcx
 2a0014c:	mov    0x1b8(%rsp),%rdx
 2a00154:	test   %edx,%ecx
 2a00156:	sete   %cl
 2a00159:	cmp    $0x1,%edx
 2a0015c:	sete   %dl
 2a0015f:	or     %edx,%ecx
 2a00161:	test   %cl,%cl
 2a00163:	jne    2a001ac <wasm[0]::function[1015]::helper::object_read+0x204c>
 2a00169:	mov    0x1b8(%rsp),%rcx
 2a00171:	cmp    $0x2,%ecx
 2a00174:	je     2a0018e <wasm[0]::function[1015]::helper::object_read+0x202e>
 2a0017a:	mov    0x128(%rsp),%ecx
 2a00181:	cmp    %eax,%ecx
 2a00183:	sete   %al
 2a00186:	movzbl %al,%eax
 2a00189:	jmp    2a001b4 <wasm[0]::function[1015]::helper::object_read+0x2054>
 2a0018e:	mov    0x1c0(%rsp),%rax
 2a00196:	mov    0x1c0(%rsp),%r8
 2a0019e:	test   %rax,%r8
 2a001a1:	sete   %al
 2a001a4:	movzbl %al,%eax
 2a001a7:	jmp    2a001b4 <wasm[0]::function[1015]::helper::object_read+0x2054>
 2a001ac:	mov    0x278(%rsp),%rax
 2a001b4:	mov    0x110(%rsp),%edx
 2a001bb:	mov    %rdx,0x210(%rsp)
 2a001c3:	mov    0x128(%rsp),%r9d
 2a001cb:	mov    0xa0(%rsp),%r8d
 2a001d3:	mov    0xa8(%rsp),%r13d
 2a001db:	mov    %r13,0x208(%rsp)
 2a001e3:	mov    0x48(%rsp),%r13d
 2a001e8:	mov    0x80(%rsp),%edi
 2a001ef:	mov    0xb8(%rsp),%edx
 2a001f6:	mov    0x210(%rsp),%r10
 2a001fe:	jmp    2a00832 <wasm[0]::function[1015]::helper::object_read+0x26d2>
 2a00203:	mov    0x128(%rsp),%edx
 2a0020a:	xor    %ecx,%ecx
 2a0020c:	test   %edx,%edx
 2a0020e:	je     2a0025d <wasm[0]::function[1015]::helper::object_read+0x20fd>
 2a00214:	xor    %ecx,%ecx
 2a00216:	test   $0x1,%edx
 2a0021c:	jne    2a0025d <wasm[0]::function[1015]::helper::object_read+0x20fd>
 2a00222:	mov    0x2e0(%rsp),%r14
 2a0022a:	mov    0x28(%r14),%rcx
 2a0022e:	mov    0x20(%r14),%rdi
 2a00232:	mov    %edx,%esi
 2a00234:	lea    0x4(%rdi,%rsi,1),%rdx
 2a00239:	xor    %rdi,%rdi
 2a0023c:	cmp    %rcx,%rsi
 2a0023f:	cmova  %rdi,%rdx
 2a00243:	mov    (%rdx),%ecx
 2a00245:	mov    0x190(%rsp),%rdx
 2a0024d:	mov    0x28(%rdx),%rdx
 2a00251:	cmp    0x23c(%rdx),%ecx
 2a00257:	sete   %cl
 2a0025a:	movzbl %cl,%ecx
 2a0025d:	test   %ecx,%ecx
 2a0025f:	je     2a18f0c <wasm[0]::function[1015]::helper::object_read+0x1adac>
 2a00265:	xor    %ecx,%ecx
 2a00267:	test   %eax,%eax
 2a00269:	je     2a002b7 <wasm[0]::function[1015]::helper::object_read+0x2157>
 2a0026f:	xor    %ecx,%ecx
 2a00271:	test   $0x1,%eax
 2a00276:	jne    2a002b7 <wasm[0]::function[1015]::helper::object_read+0x2157>
 2a0027c:	mov    0x2e0(%rsp),%r14
 2a00284:	mov    0x28(%r14),%rcx
 2a00288:	mov    0x20(%r14),%rdx
 2a0028c:	mov    %eax,%esi
 2a0028e:	lea    0x4(%rdx,%rsi,1),%rdx
 2a00293:	xor    %rdi,%rdi
 2a00296:	cmp    %rcx,%rsi
 2a00299:	cmova  %rdi,%rdx
 2a0029d:	mov    (%rdx),%ecx
 2a0029f:	mov    0x190(%rsp),%rdx
 2a002a7:	mov    0x28(%rdx),%rdx
 2a002ab:	cmp    0x23c(%rdx),%ecx
 2a002b1:	sete   %cl
 2a002b4:	movzbl %cl,%ecx
 2a002b7:	test   %ecx,%ecx
 2a002b9:	je     2a18f0e <wasm[0]::function[1015]::helper::object_read+0x1adae>
 2a002bf:	mov    0x128(%rsp),%r9d
 2a002c7:	test   %r9d,%r9d
 2a002ca:	je     2a18f10 <wasm[0]::function[1015]::helper::object_read+0x1adb0>
 2a002d0:	test   %r9d,%r9d
 2a002d3:	je     2a18f12 <wasm[0]::function[1015]::helper::object_read+0x1adb2>
 2a002d9:	mov    0x2e0(%rsp),%r14
 2a002e1:	mov    0x28(%r14),%rcx
 2a002e5:	mov    0x20(%r14),%rdx
 2a002e9:	mov    %r9d,%esi
 2a002ec:	lea    (%rdx,%rsi,1),%r8
 2a002f0:	xor    %rdi,%rdi
 2a002f3:	cmp    %rcx,%rsi
 2a002f6:	cmova  %rdi,%r8
 2a002fa:	mov    0x10(%r8),%esi
 2a002fe:	test   %eax,%eax
 2a00300:	je     2a18f14 <wasm[0]::function[1015]::helper::object_read+0x1adb4>
 2a00306:	mov    %eax,%eax
 2a00308:	lea    (%rdx,%rax,1),%r11
 2a0030c:	cmp    %rcx,%rax
 2a0030f:	cmova  %rdi,%r11
 2a00313:	mov    0x10(%r11),%eax
 2a00317:	mov    0x14(%r8),%r10d
 2a0031b:	mov    %r10d,0x140(%rsp)
 2a00323:	mov    0x14(%r11),%r8d
 2a00327:	mov    %r8d,0xc0(%rsp)
 2a0032f:	test   %r10d,%r10d
 2a00332:	je     2a18f16 <wasm[0]::function[1015]::helper::object_read+0x1adb6>
 2a00338:	test   %r10d,%r10d
 2a0033b:	je     2a18f18 <wasm[0]::function[1015]::helper::object_read+0x1adb8>
 2a00341:	mov    %r10d,%r11d
 2a00344:	lea    0x10(%rdx,%r11,1),%r10
 2a00349:	cmp    %rcx,%r11
 2a0034c:	cmova  %rdi,%r10
 2a00350:	mov    (%r10),%ebx
 2a00353:	test   %r8d,%r8d
 2a00356:	je     2a18f1a <wasm[0]::function[1015]::helper::object_read+0x1adba>
 2a0035c:	test   %r8d,%r8d
 2a0035f:	je     2a18f1c <wasm[0]::function[1015]::helper::object_read+0x1adbc>
 2a00365:	mov    %r8d,%r10d
 2a00368:	lea    0x10(%rdx,%r10,1),%r8
 2a0036d:	cmp    %rcx,%r10
 2a00370:	cmova  %rdi,%r8
 2a00374:	mov    (%r8),%r10d
 2a00377:	mov    0x110(%rsp),%edx
 2a0037e:	mov    %rdx,0x210(%rsp)
 2a00386:	mov    0xa0(%rsp),%r8d
 2a0038e:	mov    0xa8(%rsp),%r13d
 2a00396:	mov    %r13,0x208(%rsp)
 2a0039e:	mov    0x48(%rsp),%r13d
 2a003a3:	mov    0x80(%rsp),%edi
 2a003aa:	mov    0xb8(%rsp),%edx
 2a003b1:	cmp    %eax,%esi
 2a003b3:	sete   %r11b
 2a003b7:	cmp    %r10d,%ebx
 2a003ba:	sete   %r10b
 2a003be:	mov    %r11,%rax
 2a003c1:	and    %r10d,%eax
 2a003c4:	movzbl %al,%eax
 2a003c7:	mov    %rax,0x1d8(%rsp)
 2a003cf:	test   %r11b,%r10b
 2a003d2:	jne    2a003ed <wasm[0]::function[1015]::helper::object_read+0x228d>
 2a003d8:	mov    0x1d8(%rsp),%rax
 2a003e0:	mov    0x210(%rsp),%r10
 2a003e8:	jmp    2a00832 <wasm[0]::function[1015]::helper::object_read+0x26d2>
 2a003ed:	mov    0x110(%rsp),%ecx
 2a003f4:	mov    0x128(%rsp),%edx
 2a003fb:	mov    0xa0(%rsp),%esi
 2a00402:	mov    0xa8(%rsp),%edi
 2a00409:	mov    0x48(%rsp),%r8d
 2a0040e:	mov    0x80(%rsp),%r9d
 2a00416:	mov    0xb8(%rsp),%r10d
 2a0041e:	xor    %r12d,%r12d
 2a00421:	mov    %rcx,%r11
 2a00424:	mov    %ecx,0x58(%rsp)
 2a00428:	mov    %edx,0x78(%rsp)
 2a0042c:	mov    %esi,0x108(%rsp)
 2a00433:	mov    %r11d,0xe8(%rsp)
 2a0043b:	mov    %edi,0xb0(%rsp)
 2a00442:	mov    %r8d,0x88(%rsp)
 2a0044a:	mov    %r9d,0x100(%rsp)
 2a00452:	mov    %r10d,0xd0(%rsp)
 2a0045a:	mov    0x2e8(%rsp),%r15
 2a00462:	mov    (%r15),%rcx
 2a00465:	mov    0x228(%rsp),%rax
 2a0046d:	cmp    %rax,%rcx
 2a00470:	jae    2a1784f <wasm[0]::function[1015]::helper::object_read+0x196ef>
 2a00476:	cmp    %ebx,%r12d
 2a00479:	jb     2a0048c <wasm[0]::function[1015]::helper::object_read+0x232c>
 2a0047f:	mov    0x1d8(%rsp),%rax
 2a00487:	jmp    2a005f0 <wasm[0]::function[1015]::helper::object_read+0x2490>
 2a0048c:	mov    0x140(%rsp),%esi
 2a00493:	test   %esi,%esi
 2a00495:	je     2a18f1e <wasm[0]::function[1015]::helper::object_read+0x1adbe>
 2a0049b:	test   %esi,%esi
 2a0049d:	je     2a18f20 <wasm[0]::function[1015]::helper::object_read+0x1adc0>
 2a004a3:	mov    0x2e0(%rsp),%r14
 2a004ab:	mov    0x28(%r14),%rax
 2a004af:	mov    0x20(%r14),%rcx
 2a004b3:	mov    %esi,%r8d
 2a004b6:	lea    0x10(%rcx,%r8,1),%rdi
 2a004bb:	xor    %rdx,%rdx
 2a004be:	cmp    %rax,%r8
 2a004c1:	cmova  %rdx,%rdi
 2a004c5:	mov    (%rdi),%r8d
 2a004c8:	cmp    %r8d,%r12d
 2a004cb:	jae    2a18f22 <wasm[0]::function[1015]::helper::object_read+0x1adc2>
 2a004d1:	mov    %r8d,%edi
 2a004d4:	shl    $0x3,%rdi
 2a004d8:	shr    $0x20,%rdi
 2a004dc:	test   %rdi,%rdi
 2a004df:	jne    2a18f24 <wasm[0]::function[1015]::helper::object_read+0x1adc4>
 2a004e5:	shl    $0x3,%r8d
 2a004e9:	add    $0x18,%r8d
 2a004ed:	jb     2a18f26 <wasm[0]::function[1015]::helper::object_read+0x1adc6>
 2a004f3:	add    %r8d,%esi
 2a004f6:	jb     2a18f28 <wasm[0]::function[1015]::helper::object_read+0x1adc8>
 2a004fc:	mov    %esi,%edi
 2a004fe:	lea    (%rcx,%rdi,1),%rsi
 2a00502:	cmp    %rax,%rdi
 2a00505:	cmova  %rdx,%rsi
 2a00509:	mov    %r12,%rdi
 2a0050c:	shl    $0x3,%edi
 2a0050f:	add    $0x18,%edi
 2a00515:	sub    %edi,%r8d
 2a00518:	sub    %r8,%rsi
 2a0051b:	mov    (%rsi),%rsi
 2a0051e:	mov    0xc0(%rsp),%r8d
 2a00526:	test   %r8d,%r8d
 2a00529:	je     2a18f2a <wasm[0]::function[1015]::helper::object_read+0x1adca>
 2a0052f:	test   %r8d,%r8d
 2a00532:	je     2a18f2c <wasm[0]::function[1015]::helper::object_read+0x1adcc>
 2a00538:	mov    %r8d,%r10d
 2a0053b:	lea    0x10(%rcx,%r10,1),%r9
 2a00540:	cmp    %rax,%r10
 2a00543:	cmova  %rdx,%r9
 2a00547:	mov    (%r9),%r9d
 2a0054a:	cmp    %r9d,%r12d
 2a0054d:	jae    2a18f2e <wasm[0]::function[1015]::helper::object_read+0x1adce>
 2a00553:	mov    %r9d,%r10d
 2a00556:	shl    $0x3,%r10
 2a0055a:	shr    $0x20,%r10
 2a0055e:	test   %r10,%r10
 2a00561:	jne    2a18f30 <wasm[0]::function[1015]::helper::object_read+0x1add0>
 2a00567:	shl    $0x3,%r9d
 2a0056b:	add    $0x18,%r9d
 2a0056f:	jb     2a18f32 <wasm[0]::function[1015]::helper::object_read+0x1add2>
 2a00575:	add    %r9d,%r8d
 2a00578:	jb     2a18f34 <wasm[0]::function[1015]::helper::object_read+0x1add4>
 2a0057e:	mov    %r8d,%r8d
 2a00581:	add    %r8,%rcx
 2a00584:	cmp    %rax,%r8
 2a00587:	cmova  %rdx,%rcx
 2a0058b:	sub    %edi,%r9d
 2a0058e:	sub    %r9,%rcx
 2a00591:	mov    (%rcx),%rcx
 2a00594:	cmp    %rcx,%rsi
 2a00597:	sete   %al
 2a0059a:	movzbl %al,%eax
 2a0059d:	cmp    %rcx,%rsi
 2a005a0:	jne    2a005f0 <wasm[0]::function[1015]::helper::object_read+0x2490>
 2a005a6:	mov    0x58(%rsp),%ecx
 2a005aa:	mov    0x78(%rsp),%edx
 2a005ae:	mov    0x108(%rsp),%esi
 2a005b5:	mov    0xe8(%rsp),%r11d
 2a005bd:	mov    0xb0(%rsp),%edi
 2a005c4:	mov    0x88(%rsp),%r8d
 2a005cc:	mov    0x100(%rsp),%r9d
 2a005d4:	mov    0xd0(%rsp),%r10d
 2a005dc:	add    $0x1,%r12d
 2a005e3:	mov    %rax,0x1d8(%rsp)
 2a005eb:	jmp    2a00424 <wasm[0]::function[1015]::helper::object_read+0x22c4>
 2a005f0:	mov    0x58(%rsp),%edx
 2a005f4:	mov    %rdx,0x210(%rsp)
 2a005fc:	mov    0x78(%rsp),%r9d
 2a00601:	mov    0x108(%rsp),%r8d
 2a00609:	mov    0xe8(%rsp),%r10d
 2a00611:	mov    0xb0(%rsp),%r13d
 2a00619:	mov    %r13,0x208(%rsp)
 2a00621:	mov    0x88(%rsp),%r13d
 2a00629:	mov    0x100(%rsp),%edi
 2a00630:	mov    0xd0(%rsp),%edx
 2a00637:	jmp    2a00832 <wasm[0]::function[1015]::helper::object_read+0x26d2>
 2a0063c:	mov    0x128(%rsp),%ecx
 2a00643:	cmp    %eax,%ecx
 2a00645:	je     2a00748 <wasm[0]::function[1015]::helper::object_read+0x25e8>
 2a0064b:	xor    %edx,%edx
 2a0064d:	test   %ecx,%ecx
 2a0064f:	je     2a006a3 <wasm[0]::function[1015]::helper::object_read+0x2543>
 2a00655:	xor    %edx,%edx
 2a00657:	test   $0x1,%ecx
 2a0065d:	jne    2a006a3 <wasm[0]::function[1015]::helper::object_read+0x2543>
 2a00663:	mov    0x2e0(%rsp),%r14
 2a0066b:	mov    0x28(%r14),%rdi
 2a0066f:	mov    0x20(%r14),%r9
 2a00673:	mov    %ecx,%r8d
 2a00676:	lea    0x4(%r9,%r8,1),%rsi
 2a0067b:	xor    %r9,%r9
 2a0067e:	cmp    %rdi,%r8
 2a00681:	cmova  %r9,%rsi
 2a00685:	mov    (%rsi),%r8d
 2a00688:	mov    0x190(%rsp),%rcx
 2a00690:	mov    0x28(%rcx),%r9
 2a00694:	cmp    0x234(%r9),%r8d
 2a0069b:	sete   %r9b
 2a0069f:	movzbl %r9b,%edx
 2a006a3:	test   %edx,%edx
 2a006a5:	je     2a18f36 <wasm[0]::function[1015]::helper::object_read+0x1add6>
 2a006ab:	xor    %esi,%esi
 2a006ad:	test   %eax,%eax
 2a006af:	jne    2a006bd <wasm[0]::function[1015]::helper::object_read+0x255d>
 2a006b5:	mov    %rax,%rdi
 2a006b8:	jmp    2a00711 <wasm[0]::function[1015]::helper::object_read+0x25b1>
 2a006bd:	xor    %esi,%esi
 2a006bf:	test   $0x1,%eax
 2a006c4:	je     2a006d2 <wasm[0]::function[1015]::helper::object_read+0x2572>
 2a006ca:	mov    %rax,%rdi
 2a006cd:	jmp    2a00711 <wasm[0]::function[1015]::helper::object_read+0x25b1>
 2a006d2:	mov    0x2e0(%rsp),%r14
 2a006da:	mov    0x28(%r14),%rcx
 2a006de:	mov    0x20(%r14),%rsi
 2a006e2:	mov    %eax,%edx
 2a006e4:	mov    %rax,%rdi
 2a006e7:	lea    0x4(%rsi,%rdx,1),%rax
 2a006ec:	xor    %rsi,%rsi
 2a006ef:	cmp    %rcx,%rdx
 2a006f2:	cmova  %rsi,%rax
 2a006f6:	mov    (%rax),%eax
 2a006f8:	mov    0x190(%rsp),%rcx
 2a00700:	mov    0x28(%rcx),%rcx
 2a00704:	cmp    0x234(%rcx),%eax
 2a0070a:	sete   %al
 2a0070d:	rex movzbl %al,%esi
 2a00711:	test   %esi,%esi
 2a00713:	je     2a18f38 <wasm[0]::function[1015]::helper::object_read+0x1add8>
 2a00719:	mov    0x128(%rsp),%edx
 2a00720:	xor    %r8d,%r8d
 2a00723:	test   %edx,%edx
 2a00725:	je     2a18f3a <wasm[0]::function[1015]::helper::object_read+0x1adda>
 2a0072b:	mov    %rdi,%rcx
 2a0072e:	mov    0x190(%rsp),%rsi
 2a00736:	mov    0x190(%rsp),%rdi
 2a0073e:	call   2b02800 <wasm[0]::function[1057]::helper::string_equality>
 2a00743:	jmp    2a00750 <wasm[0]::function[1015]::helper::object_read+0x25f0>
 2a00748:	mov    0x278(%rsp),%rax
 2a00750:	mov    0x110(%rsp),%edx
 2a00757:	mov    %rdx,0x210(%rsp)
 2a0075f:	mov    0x128(%rsp),%r9d
 2a00767:	mov    0xa0(%rsp),%r8d
 2a0076f:	mov    0xa8(%rsp),%r13d
 2a00777:	mov    %r13,0x208(%rsp)
 2a0077f:	mov    0x48(%rsp),%r13d
 2a00784:	mov    0x80(%rsp),%edi
 2a0078b:	mov    0xb8(%rsp),%edx
 2a00792:	mov    0x210(%rsp),%r10
 2a0079a:	jmp    2a00832 <wasm[0]::function[1015]::helper::object_read+0x26d2>
 2a0079f:	mov    0x110(%rsp),%edx
 2a007a6:	mov    %rdx,0x210(%rsp)
 2a007ae:	mov    0x128(%rsp),%r9d
 2a007b6:	mov    0xa0(%rsp),%r8d
 2a007be:	mov    0xa8(%rsp),%r13d
 2a007c6:	mov    %r13,0x208(%rsp)
 2a007ce:	mov    0x48(%rsp),%r13d
 2a007d3:	mov    0x80(%rsp),%edi
 2a007da:	mov    0xb8(%rsp),%edx
 2a007e1:	xor    %r10,%r10
 2a007e4:	mov    0x1c0(%rsp),%rax
 2a007ec:	mov    0x1c0(%rsp),%rcx
 2a007f4:	test   %rcx,%rax
 2a007f7:	sete   %al
 2a007fa:	movq   %rcx,%xmm0
 2a007ff:	ucomisd %xmm0,%xmm0
 2a00803:	setp   %sil
 2a00807:	setne  %r11b
 2a0080b:	or     %r11d,%esi
 2a0080e:	movq   %r10,%xmm0
 2a00813:	ucomisd %xmm0,%xmm0
 2a00817:	setp   %r10b
 2a0081b:	setne  %r11b
 2a0081f:	or     %r11d,%r10d
 2a00822:	and    %r10d,%esi
 2a00825:	or     %esi,%eax
 2a00827:	movzbl %al,%eax
 2a0082a:	mov    0x210(%rsp),%r10
 2a00832:	test   %eax,%eax
 2a00834:	jne    2a02dbc <wasm[0]::function[1015]::helper::object_read+0x4c5c>
 2a0083a:	xor    %eax,%eax
 2a0083c:	mov    0x1b8(%rsp),%rcx
 2a00844:	cmp    $0x4,%ecx
 2a00847:	je     2a00855 <wasm[0]::function[1015]::helper::object_read+0x26f5>
 2a0084d:	mov    %rax,%rsi
 2a00850:	jmp    2a00bdd <wasm[0]::function[1015]::helper::object_read+0x2a7d>
 2a00855:	xor    %eax,%eax
 2a00857:	test   %r9d,%r9d
 2a0085a:	je     2a008ab <wasm[0]::function[1015]::helper::object_read+0x274b>
 2a00860:	xor    %eax,%eax
 2a00862:	test   $0x1,%r9d
 2a00869:	jne    2a008ab <wasm[0]::function[1015]::helper::object_read+0x274b>
 2a0086f:	mov    0x2e0(%rsp),%r14
 2a00877:	mov    0x28(%r14),%rax
 2a0087b:	mov    0x20(%r14),%rsi
 2a0087f:	mov    %r9d,%r11d
 2a00882:	lea    0x4(%rsi,%r11,1),%rsi
 2a00887:	xor    %rbx,%rbx
 2a0088a:	cmp    %rax,%r11
 2a0088d:	cmova  %rbx,%rsi
 2a00891:	mov    (%rsi),%eax
 2a00893:	mov    0x190(%rsp),%rcx
 2a0089b:	mov    0x28(%rcx),%rcx
 2a0089f:	cmp    0x234(%rcx),%eax
 2a008a5:	sete   %al
 2a008a8:	movzbl %al,%eax
 2a008ab:	test   %eax,%eax
 2a008ad:	je     2a18f3c <wasm[0]::function[1015]::helper::object_read+0x1addc>
 2a008b3:	test   %r9d,%r9d
 2a008b6:	je     2a18f3e <wasm[0]::function[1015]::helper::object_read+0x1adde>
 2a008bc:	test   %r9d,%r9d
 2a008bf:	je     2a18f40 <wasm[0]::function[1015]::helper::object_read+0x1ade0>
 2a008c5:	mov    0x2e0(%rsp),%r14
 2a008cd:	mov    0x28(%r14),%rsi
 2a008d1:	mov    0x20(%r14),%r11
 2a008d5:	mov    %r9d,%r12d
 2a008d8:	lea    (%r11,%r12,1),%rax
 2a008dc:	xor    %rbx,%rbx
 2a008df:	cmp    %rsi,%r12
 2a008e2:	cmova  %rbx,%rax
 2a008e6:	mov    0x10(%rax),%r12d
 2a008ea:	mov    %r12d,0x110(%rsp)
 2a008f2:	xor    %eax,%eax
 2a008f4:	test   %r12d,%r12d
 2a008f7:	je     2a18f42 <wasm[0]::function[1015]::helper::object_read+0x1ade2>
 2a008fd:	test   %r12d,%r12d
 2a00900:	je     2a18f44 <wasm[0]::function[1015]::helper::object_read+0x1ade4>
 2a00906:	mov    %r12d,%r12d
 2a00909:	lea    0x10(%r11,%r12,1),%r11
 2a0090e:	cmp    %rsi,%r12
 2a00911:	cmova  %rbx,%r11
 2a00915:	mov    (%r11),%ebx
 2a00918:	test   %ebx,%ebx
 2a0091a:	sete   %sil
 2a0091e:	cmp    $0xa,%ebx
 2a00921:	seta   %r11b
 2a00925:	or     %r11d,%esi
 2a00928:	test   %sil,%sil
 2a0092b:	je     2a00939 <wasm[0]::function[1015]::helper::object_read+0x27d9>
 2a00931:	mov    %rax,%rsi
 2a00934:	jmp    2a00bdd <wasm[0]::function[1015]::helper::object_read+0x2a7d>
 2a00939:	mov    0x110(%rsp),%eax
 2a00940:	test   %eax,%eax
 2a00942:	je     2a18f46 <wasm[0]::function[1015]::helper::object_read+0x1ade6>
 2a00948:	test   %eax,%eax
 2a0094a:	je     2a18f48 <wasm[0]::function[1015]::helper::object_read+0x1ade8>
 2a00950:	mov    0x2e0(%rsp),%r14
 2a00958:	mov    0x28(%r14),%r11
 2a0095c:	mov    0x20(%r14),%rsi
 2a00960:	mov    %eax,%r15d
 2a00963:	lea    0x10(%rsi,%r15,1),%r14
 2a00968:	xor    %r12,%r12
 2a0096b:	cmp    %r11,%r15
 2a0096e:	cmova  %r12,%r14
 2a00972:	mov    (%r14),%r14d
 2a00975:	test   %r14d,%r14d
 2a00978:	je     2a18f4a <wasm[0]::function[1015]::helper::object_read+0x1adea>
 2a0097e:	mov    %r14d,%r15d
 2a00981:	shl    $1,%r15
 2a00984:	shr    $0x20,%r15
 2a00988:	test   %r15,%r15
 2a0098b:	jne    2a18f4c <wasm[0]::function[1015]::helper::object_read+0x1adec>
 2a00991:	add    %r14d,%r14d
 2a00994:	add    $0x14,%r14d
 2a00998:	jb     2a18f4e <wasm[0]::function[1015]::helper::object_read+0x1adee>
 2a0099e:	add    %r14d,%eax
 2a009a1:	jb     2a18f50 <wasm[0]::function[1015]::helper::object_read+0x1adf0>
 2a009a7:	mov    %eax,%r15d
 2a009aa:	lea    (%rsi,%r15,1),%rax
 2a009ae:	cmp    %r11,%r15
 2a009b1:	cmova  %r12,%rax
 2a009b5:	sub    $0x14,%r14d
 2a009b9:	sub    %r14,%rax
 2a009bc:	movzwl (%rax),%eax
 2a009bf:	cmp    $0x30,%eax
 2a009c2:	je     2a00bbf <wasm[0]::function[1015]::helper::object_read+0x2a5f>
 2a009c8:	xor    %r15d,%r15d
 2a009cb:	xor    %r12,%r12
 2a009ce:	mov    0x210(%rsp),%rax
 2a009d6:	mov    %r15,%rsi
 2a009d9:	mov    %eax,0x108(%rsp)
 2a009e0:	mov    %r8d,0x78(%rsp)
 2a009e5:	mov    %r9d,0x58(%rsp)
 2a009ea:	mov    %esi,0xb8(%rsp)
 2a009f1:	mov    %r10d,0x80(%rsp)
 2a009f9:	mov    0x208(%rsp),%rax
 2a00a01:	mov    %eax,0x48(%rsp)
 2a00a05:	mov    %r13d,0xa8(%rsp)
 2a00a0d:	mov    %edi,0xa0(%rsp)
 2a00a14:	mov    %edx,0x128(%rsp)
 2a00a1b:	mov    0x2e8(%rsp),%rax
 2a00a23:	mov    (%rax),%rax
 2a00a26:	mov    0x228(%rsp),%rcx
 2a00a2e:	cmp    %rcx,%rax
 2a00a31:	jae    2a17886 <wasm[0]::function[1015]::helper::object_read+0x19726>
 2a00a37:	mov    0x110(%rsp),%ecx
 2a00a3e:	xor    %eax,%eax
 2a00a40:	test   %ecx,%ecx
 2a00a42:	je     2a18f52 <wasm[0]::function[1015]::helper::object_read+0x1adf2>
 2a00a48:	test   %ecx,%ecx
 2a00a4a:	je     2a18f54 <wasm[0]::function[1015]::helper::object_read+0x1adf4>
 2a00a50:	mov    0x2e0(%rsp),%r14
 2a00a58:	mov    0x28(%r14),%rdx
 2a00a5c:	mov    0x20(%r14),%rsi
 2a00a60:	mov    %ecx,%r9d
 2a00a63:	lea    0x10(%rsi,%r9,1),%r8
 2a00a68:	xor    %rdi,%rdi
 2a00a6b:	cmp    %rdx,%r9
 2a00a6e:	cmova  %rdi,%r8
 2a00a72:	mov    (%r8),%r8d
 2a00a75:	cmp    %r8d,%r15d
 2a00a78:	jae    2a18f56 <wasm[0]::function[1015]::helper::object_read+0x1adf6>
 2a00a7e:	mov    %r8d,%r9d
 2a00a81:	shl    $1,%r9
 2a00a84:	shr    $0x20,%r9
 2a00a88:	test   %r9,%r9
 2a00a8b:	jne    2a18f58 <wasm[0]::function[1015]::helper::object_read+0x1adf8>
 2a00a91:	add    %r8d,%r8d
 2a00a94:	add    $0x14,%r8d
 2a00a98:	jb     2a18f5a <wasm[0]::function[1015]::helper::object_read+0x1adfa>
 2a00a9e:	add    %r8d,%ecx
 2a00aa1:	jb     2a18f5c <wasm[0]::function[1015]::helper::object_read+0x1adfc>
 2a00aa7:	mov    %ecx,%r9d
 2a00aaa:	lea    (%rsi,%r9,1),%rcx
 2a00aae:	cmp    %rdx,%r9
 2a00ab1:	cmova  %rdi,%rcx
 2a00ab5:	lea    0x14(%r15,%r15,1),%edx
 2a00aba:	sub    %edx,%r8d
 2a00abd:	sub    %r8,%rcx
 2a00ac0:	movzwq (%rcx),%r11
 2a00ac4:	mov    0x108(%rsp),%edx
 2a00acb:	mov    %rdx,0x210(%rsp)
 2a00ad3:	mov    0x78(%rsp),%r8d
 2a00ad8:	mov    0x58(%rsp),%r9d
 2a00add:	mov    0xb8(%rsp),%esi
 2a00ae4:	mov    0x80(%rsp),%r10d
 2a00aec:	mov    0x48(%rsp),%r13d
 2a00af1:	mov    %r13,0x208(%rsp)
 2a00af9:	mov    0xa8(%rsp),%r13d
 2a00b01:	mov    0xa0(%rsp),%edi
 2a00b08:	mov    0x128(%rsp),%edx
 2a00b0f:	movzwl %r11w,%r11d
 2a00b13:	sub    $0x30,%r11d
 2a00b17:	cmp    $0x9,%r11d
 2a00b1b:	ja     2a00bdd <wasm[0]::function[1015]::helper::object_read+0x2a7d>
 2a00b21:	mov    0x108(%rsp),%edx
 2a00b28:	mov    %rdx,0x210(%rsp)
 2a00b30:	mov    0x78(%rsp),%r8d
 2a00b35:	mov    0x58(%rsp),%r9d
 2a00b3a:	mov    0xb8(%rsp),%esi
 2a00b41:	mov    0x80(%rsp),%r10d
 2a00b49:	mov    0x48(%rsp),%r13d
 2a00b4e:	mov    %r13,0x208(%rsp)
 2a00b56:	mov    0xa8(%rsp),%r13d
 2a00b5e:	mov    0xa0(%rsp),%edi
 2a00b65:	mov    0x128(%rsp),%edx
 2a00b6c:	add    $0x1,%r15d
 2a00b73:	imul   $0xa,%r12,%rax
 2a00b77:	lea    (%rax,%r11,1),%r14
 2a00b7b:	cmp    %ebx,%r15d
 2a00b7e:	jae    2a00b94 <wasm[0]::function[1015]::helper::object_read+0x2a34>
 2a00b84:	mov    0x210(%rsp),%rax
 2a00b8c:	mov    %r14,%r12
 2a00b8f:	jmp    2a009d9 <wasm[0]::function[1015]::helper::object_read+0x2879>
 2a00b94:	xor    %eax,%eax
 2a00b96:	cmp    0x1903b(%rip),%r14        # 2a19bd8 <wasm[0]::function[1015]::helper::object_read+0x1ba78>
 2a00b9d:	jae    2a00bdd <wasm[0]::function[1015]::helper::object_read+0x2a7d>
 2a00ba3:	imul   $0xa,%r12d,%eax
 2a00ba7:	add    %r11d,%eax
 2a00baa:	mov    %rax,0x1e0(%rsp)
 2a00bb2:	mov    0x278(%rsp),%rax
 2a00bba:	jmp    2a00bdd <wasm[0]::function[1015]::helper::object_read+0x2a7d>
 2a00bbf:	cmp    $0x1,%ebx
 2a00bc2:	sete   %al
 2a00bc5:	movzbl %al,%eax
 2a00bc8:	mov    %rsi,%rcx
 2a00bcb:	mov    %rsi,0x1e0(%rsp)
 2a00bd3:	xor    %esi,%esi
 2a00bd5:	mov    %rsi,0x1e0(%rsp)
 2a00bdd:	mov    %r8d,0xa0(%rsp)
 2a00be5:	mov    %r9d,0xa8(%rsp)
 2a00bed:	mov    %esi,0x48(%rsp)
 2a00bf1:	mov    %r10d,0x80(%rsp)
 2a00bf9:	mov    0x208(%rsp),%rcx
 2a00c01:	mov    %ecx,0xb8(%rsp)
 2a00c08:	mov    %r13d,0x58(%rsp)
 2a00c0d:	mov    %edi,0x78(%rsp)
 2a00c11:	mov    %edx,0x108(%rsp)
 2a00c18:	test   %eax,%eax
 2a00c1a:	mov    %rax,0x200(%rsp)
 2a00c22:	jne    2a00cd9 <wasm[0]::function[1015]::helper::object_read+0x2b79>
 2a00c28:	xor    %ebx,%ebx
 2a00c2a:	mov    0x210(%rsp),%rax
 2a00c32:	mov    0x210(%rsp),%rdx
 2a00c3a:	test   %eax,%edx
 2a00c3c:	je     2a18f5e <wasm[0]::function[1015]::helper::object_read+0x1adfe>
 2a00c42:	test   %eax,%edx
 2a00c44:	je     2a18f60 <wasm[0]::function[1015]::helper::object_read+0x1ae00>
 2a00c4a:	mov    0x2e0(%rsp),%r14
 2a00c52:	mov    0x28(%r14),%rax
 2a00c56:	mov    0x20(%r14),%rdx
 2a00c5a:	mov    0x210(%rsp),%rcx
 2a00c62:	mov    %ecx,%ecx
 2a00c64:	lea    (%rdx,%rcx,1),%r11
 2a00c68:	xor    %rdx,%rdx
 2a00c6b:	cmp    %rax,%rcx
 2a00c6e:	cmova  %rdx,%r11
 2a00c72:	mov    0x10(%r11),%edx
 2a00c76:	test   %edx,%edx
 2a00c78:	je     2a18f62 <wasm[0]::function[1015]::helper::object_read+0x1ae02>
 2a00c7e:	mov    0x1b8(%rsp),%rcx
 2a00c86:	mov    0x190(%rsp),%rsi
 2a00c8e:	mov    0x190(%rsp),%rdi
 2a00c96:	mov    0x1c0(%rsp),%r8
 2a00c9e:	call   2a1cf20 <wasm[0]::function[1019]::helper::ordinary_own_descriptor>
 2a00ca3:	mov    0x80(%rsp),%r8d
 2a00cab:	mov    0xa8(%rsp),%r9d
 2a00cb3:	mov    0xb8(%rsp),%r11d
 2a00cbb:	mov    0x58(%rsp),%r12d
 2a00cc0:	mov    0x78(%rsp),%r13d
 2a00cc5:	mov    0x108(%rsp),%edx
 2a00ccc:	mov    0x290(%rsp),%rsi
 2a00cd4:	jmp    2a02b94 <wasm[0]::function[1015]::helper::object_read+0x4a34>
 2a00cd9:	mov    0x210(%rsp),%rax
 2a00ce1:	mov    0x210(%rsp),%rdx
 2a00ce9:	test   %eax,%edx
 2a00ceb:	je     2a18f64 <wasm[0]::function[1015]::helper::object_read+0x1ae04>
 2a00cf1:	test   %eax,%edx
 2a00cf3:	je     2a18f66 <wasm[0]::function[1015]::helper::object_read+0x1ae06>
 2a00cf9:	mov    0x2e0(%rsp),%r14
 2a00d01:	mov    0x28(%r14),%rcx
 2a00d05:	mov    0x20(%r14),%rdx
 2a00d09:	mov    %eax,%eax
 2a00d0b:	lea    (%rdx,%rax,1),%rsi
 2a00d0f:	xor    %rdi,%rdi
 2a00d12:	cmp    %rcx,%rax
 2a00d15:	cmova  %rdi,%rsi
 2a00d19:	mov    0x14(%rsi),%esi
 2a00d1c:	test   %esi,%esi
 2a00d1e:	je     2a18f68 <wasm[0]::function[1015]::helper::object_read+0x1ae08>
 2a00d24:	test   %esi,%esi
 2a00d26:	je     2a18f6a <wasm[0]::function[1015]::helper::object_read+0x1ae0a>
 2a00d2c:	mov    %esi,%esi
 2a00d2e:	add    %rsi,%rdx
 2a00d31:	cmp    %rcx,%rsi
 2a00d34:	cmova  %rdi,%rdx
 2a00d38:	mov    0x24(%rdx),%edx
 2a00d3b:	cmp    $0x4,%edx
 2a00d3e:	sete   %cl
 2a00d41:	cmp    $0x2,%edx
 2a00d44:	sete   %dil
 2a00d48:	or     %edi,%ecx
 2a00d4a:	mov    $0x3,%edi
 2a00d4f:	cmp    $0x3,%edx
 2a00d52:	sete   %dl
 2a00d55:	or     %edx,%ecx
 2a00d57:	test   %cl,%cl
 2a00d59:	jne    2a02720 <wasm[0]::function[1015]::helper::object_read+0x45c0>
 2a00d5f:	mov    0x2e0(%rsp),%r14
 2a00d67:	mov    0x28(%r14),%rcx
 2a00d6b:	mov    0x20(%r14),%rsi
 2a00d6f:	lea    (%rsi,%rax,1),%rdi
 2a00d73:	xor    %rdx,%rdx
 2a00d76:	cmp    %rcx,%rax
 2a00d79:	cmova  %rdx,%rdi
 2a00d7d:	mov    0x14(%rdi),%r11d
 2a00d81:	mov    %r11d,0x128(%rsp)
 2a00d89:	test   %r11d,%r11d
 2a00d8c:	je     2a18f6c <wasm[0]::function[1015]::helper::object_read+0x1ae0c>
 2a00d92:	test   %r11d,%r11d
 2a00d95:	je     2a18f6e <wasm[0]::function[1015]::helper::object_read+0x1ae0e>
 2a00d9b:	mov    %r11d,%edi
 2a00d9e:	lea    (%rsi,%rdi,1),%rax
 2a00da2:	cmp    %rcx,%rdi
 2a00da5:	cmova  %rdx,%rax
 2a00da9:	mov    0x24(%rax),%eax
 2a00dac:	mov    0xa0(%rsp),%edx
 2a00db3:	mov    0x48(%rsp),%ecx
 2a00db7:	mov    %rcx,0x1e8(%rsp)
 2a00dbf:	mov    0x80(%rsp),%esi
 2a00dc6:	mov    %rsi,0x1f0(%rsp)
 2a00dce:	mov    0xa8(%rsp),%edi
 2a00dd5:	mov    %rdi,0x1f8(%rsp)
 2a00ddd:	mov    0xb8(%rsp),%edi
 2a00de4:	mov    0x58(%rsp),%r8d
 2a00de9:	mov    0x78(%rsp),%r9d
 2a00dee:	mov    0x108(%rsp),%r10d
 2a00df6:	cmp    $0x4,%eax
 2a00df9:	sete   %cl
 2a00dfc:	cmp    $0x2,%eax
 2a00dff:	sete   %bl
 2a00e02:	or     %ebx,%ecx
 2a00e04:	cmp    $0x3,%eax
 2a00e07:	sete   %al
 2a00e0a:	or     %eax,%ecx
 2a00e0c:	test   %cl,%cl
 2a00e0e:	je     2a02101 <wasm[0]::function[1015]::helper::object_read+0x3fa1>
 2a00e14:	mov    0x128(%rsp),%eax
 2a00e1b:	test   %eax,%eax
 2a00e1d:	je     2a18f70 <wasm[0]::function[1015]::helper::object_read+0x1ae10>
 2a00e23:	test   %eax,%eax
 2a00e25:	je     2a18f72 <wasm[0]::function[1015]::helper::object_read+0x1ae12>
 2a00e2b:	mov    0x2e0(%rsp),%r14
 2a00e33:	mov    0x28(%r14),%rcx
 2a00e37:	mov    %eax,%edx
 2a00e39:	mov    %rdx,%rax
 2a00e3c:	add    0x20(%r14),%rax
 2a00e40:	xor    %rsi,%rsi
 2a00e43:	cmp    %rcx,%rdx
 2a00e46:	cmova  %rsi,%rax
 2a00e4a:	mov    0x24(%rax),%eax
 2a00e4d:	cmp    $0x3,%eax
 2a00e50:	je     2a01017 <wasm[0]::function[1015]::helper::object_read+0x2eb7>
 2a00e56:	mov    0x128(%rsp),%eax
 2a00e5d:	test   %eax,%eax
 2a00e5f:	je     2a18f74 <wasm[0]::function[1015]::helper::object_read+0x1ae14>
 2a00e65:	test   %eax,%eax
 2a00e67:	je     2a18f76 <wasm[0]::function[1015]::helper::object_read+0x1ae16>
 2a00e6d:	mov    0x2e0(%rsp),%r14
 2a00e75:	mov    0x28(%r14),%rcx
 2a00e79:	mov    %eax,%edx
 2a00e7b:	mov    %rdx,%rax
 2a00e7e:	add    0x20(%r14),%rax
 2a00e82:	xor    %rsi,%rsi
 2a00e85:	cmp    %rcx,%rdx
 2a00e88:	cmova  %rsi,%rax
 2a00e8c:	mov    0x24(%rax),%eax
 2a00e8f:	cmp    $0x4,%eax
 2a00e92:	je     2a00fb9 <wasm[0]::function[1015]::helper::object_read+0x2e59>
 2a00e98:	mov    0x128(%rsp),%eax
 2a00e9f:	xor    %r12d,%r12d
 2a00ea2:	test   %eax,%eax
 2a00ea4:	je     2a18f78 <wasm[0]::function[1015]::helper::object_read+0x1ae18>
 2a00eaa:	test   %eax,%eax
 2a00eac:	je     2a18f7a <wasm[0]::function[1015]::helper::object_read+0x1ae1a>
 2a00eb2:	mov    0x2e0(%rsp),%r14
 2a00eba:	mov    0x28(%r14),%rcx
 2a00ebe:	mov    0x20(%r14),%rdx
 2a00ec2:	mov    %eax,%edi
 2a00ec4:	lea    (%rdx,%rdi,1),%rax
 2a00ec8:	xor    %rsi,%rsi
 2a00ecb:	cmp    %rcx,%rdi
 2a00ece:	cmova  %rsi,%rax
 2a00ed2:	mov    0x28(%rax),%edi
 2a00ed5:	mov    0x2c(%rax),%eax
 2a00ed8:	test   %edi,%edi
 2a00eda:	je     2a18f7c <wasm[0]::function[1015]::helper::object_read+0x1ae1c>
 2a00ee0:	test   %edi,%edi
 2a00ee2:	je     2a18f7e <wasm[0]::function[1015]::helper::object_read+0x1ae1e>
 2a00ee8:	mov    %edi,%r8d
 2a00eeb:	lea    0x10(%rdx,%r8,1),%rdi
 2a00ef0:	cmp    %rcx,%r8
 2a00ef3:	cmova  %rsi,%rdi
 2a00ef7:	mov    0x1e0(%rsp),%r13
 2a00eff:	mov    %r13d,%r8d
 2a00f02:	mov    (%rdi),%edi
 2a00f04:	cmp    %rdi,%r8
 2a00f07:	jae    2a01117 <wasm[0]::function[1015]::helper::object_read+0x2fb7>
 2a00f0d:	xor    %r12d,%r12d
 2a00f10:	test   %eax,%eax
 2a00f12:	je     2a18f80 <wasm[0]::function[1015]::helper::object_read+0x1ae20>
 2a00f18:	test   %eax,%eax
 2a00f1a:	je     2a18f82 <wasm[0]::function[1015]::helper::object_read+0x1ae22>
 2a00f20:	mov    0x2e0(%rsp),%r14
 2a00f28:	mov    0x28(%r14),%rcx
 2a00f2c:	mov    0x20(%r14),%rdx
 2a00f30:	mov    %eax,%edi
 2a00f32:	lea    0x10(%rdx,%rdi,1),%r11
 2a00f37:	xor    %rsi,%rsi
 2a00f3a:	cmp    %rcx,%rdi
 2a00f3d:	cmova  %rsi,%r11
 2a00f41:	mov    (%r11),%edi
 2a00f44:	mov    0x1e0(%rsp),%r13
 2a00f4c:	mov    %r13,%r8
 2a00f4f:	shr    $0x6,%r8d
 2a00f53:	cmp    %edi,%r8d
 2a00f56:	jae    2a18f84 <wasm[0]::function[1015]::helper::object_read+0x1ae24>
 2a00f5c:	mov    %edi,%r9d
 2a00f5f:	shl    $0x3,%r9
 2a00f63:	shr    $0x20,%r9
 2a00f67:	test   %r9,%r9
 2a00f6a:	jne    2a18f86 <wasm[0]::function[1015]::helper::object_read+0x1ae26>
 2a00f70:	shl    $0x3,%edi
 2a00f73:	add    $0x18,%edi
 2a00f76:	jb     2a18f88 <wasm[0]::function[1015]::helper::object_read+0x1ae28>
 2a00f7c:	add    %edi,%eax
 2a00f7e:	jb     2a18f8a <wasm[0]::function[1015]::helper::object_read+0x1ae2a>
 2a00f84:	mov    %eax,%r9d
 2a00f87:	lea    (%rdx,%r9,1),%rax
 2a00f8b:	cmp    %rcx,%r9
 2a00f8e:	cmova  %rsi,%rax
 2a00f92:	shl    $0x3,%r8d
 2a00f96:	lea    0x18(%r8),%ecx
 2a00f9a:	sub    %ecx,%edi
 2a00f9c:	sub    %rdi,%rax
 2a00f9f:	mov    (%rax),%rax
 2a00fa2:	bt     %r13,%rax
 2a00fa6:	jae    2a01117 <wasm[0]::function[1015]::helper::object_read+0x2fb7>
 2a00fac:	mov    0x278(%rsp),%r12
 2a00fb4:	jmp    2a01117 <wasm[0]::function[1015]::helper::object_read+0x2fb7>
 2a00fb9:	mov    0x128(%rsp),%eax
 2a00fc0:	xor    %r12d,%r12d
 2a00fc3:	test   %eax,%eax
 2a00fc5:	je     2a18f8c <wasm[0]::function[1015]::helper::object_read+0x1ae2c>
 2a00fcb:	test   %eax,%eax
 2a00fcd:	je     2a18f8e <wasm[0]::function[1015]::helper::object_read+0x1ae2e>
 2a00fd3:	mov    0x2e0(%rsp),%r14
 2a00fdb:	mov    0x28(%r14),%rcx
 2a00fdf:	mov    %eax,%edx
 2a00fe1:	mov    %rdx,%rax
 2a00fe4:	add    0x20(%r14),%rax
 2a00fe8:	xor    %rsi,%rsi
 2a00feb:	cmp    %rcx,%rdx
 2a00fee:	cmova  %rsi,%rax
 2a00ff2:	mov    0x18(%rax),%rax
 2a00ff6:	mov    0x1e0(%rsp),%r13
 2a00ffe:	mov    %r13d,%ecx
 2a01001:	cmp    %rax,%rcx
 2a01004:	jae    2a01117 <wasm[0]::function[1015]::helper::object_read+0x2fb7>
 2a0100a:	mov    0x278(%rsp),%r12
 2a01012:	jmp    2a01117 <wasm[0]::function[1015]::helper::object_read+0x2fb7>
 2a01017:	mov    0x128(%rsp),%eax
 2a0101e:	xor    %r12d,%r12d
 2a01021:	test   %eax,%eax
 2a01023:	je     2a18f90 <wasm[0]::function[1015]::helper::object_read+0x1ae30>
 2a01029:	test   %eax,%eax
 2a0102b:	je     2a18f92 <wasm[0]::function[1015]::helper::object_read+0x1ae32>
 2a01031:	mov    0x2e0(%rsp),%r14
 2a01039:	mov    0x28(%r14),%rcx
 2a0103d:	mov    0x20(%r14),%rdx
 2a01041:	mov    %eax,%edi
 2a01043:	lea    (%rdx,%rdi,1),%rax
 2a01047:	xor    %rsi,%rsi
 2a0104a:	cmp    %rcx,%rdi
 2a0104d:	cmova  %rsi,%rax
 2a01051:	mov    0x30(%rax),%eax
 2a01054:	test   %eax,%eax
 2a01056:	je     2a18f94 <wasm[0]::function[1015]::helper::object_read+0x1ae34>
 2a0105c:	test   %eax,%eax
 2a0105e:	je     2a18f96 <wasm[0]::function[1015]::helper::object_read+0x1ae36>
 2a01064:	mov    %eax,%r8d
 2a01067:	lea    0x10(%rdx,%r8,1),%rdx
 2a0106c:	cmp    %rcx,%r8
 2a0106f:	cmova  %rsi,%rdx
 2a01073:	mov    0x1e0(%rsp),%r13
 2a0107b:	mov    %r13d,%ecx
 2a0107e:	mov    (%rdx),%edx
 2a01080:	cmp    %rdx,%rcx
 2a01083:	jae    2a01117 <wasm[0]::function[1015]::helper::object_read+0x2fb7>
 2a01089:	mov    0x2e0(%rsp),%r14
 2a01091:	mov    0x28(%r14),%rcx
 2a01095:	mov    0x20(%r14),%rdi
 2a01099:	lea    0x10(%rdi,%r8,1),%rsi
 2a0109e:	xor    %rdx,%rdx
 2a010a1:	cmp    %rcx,%r8
 2a010a4:	cmova  %rdx,%rsi
 2a010a8:	mov    (%rsi),%esi
 2a010aa:	mov    0x1e0(%rsp),%r13
 2a010b2:	cmp    %esi,%r13d
 2a010b5:	jae    2a18f98 <wasm[0]::function[1015]::helper::object_read+0x1ae38>
 2a010bb:	mov    %esi,%r8d
 2a010be:	shl    $0x2,%r8
 2a010c2:	shr    $0x20,%r8
 2a010c6:	test   %r8,%r8
 2a010c9:	jne    2a18f9a <wasm[0]::function[1015]::helper::object_read+0x1ae3a>
 2a010cf:	shl    $0x2,%esi
 2a010d2:	add    $0x14,%esi
 2a010d5:	jb     2a18f9c <wasm[0]::function[1015]::helper::object_read+0x1ae3c>
 2a010db:	add    %esi,%eax
 2a010dd:	jb     2a18f9e <wasm[0]::function[1015]::helper::object_read+0x1ae3e>
 2a010e3:	mov    %eax,%r8d
 2a010e6:	lea    (%rdi,%r8,1),%rax
 2a010ea:	cmp    %rcx,%r8
 2a010ed:	cmova  %rdx,%rax
 2a010f1:	mov    %r13,%rcx
 2a010f4:	shl    $0x2,%ecx
 2a010f7:	add    $0x14,%ecx
 2a010fd:	sub    %ecx,%esi
 2a010ff:	sub    %rsi,%rax
 2a01102:	mov    (%rax),%eax
 2a01104:	xor    %r12d,%r12d
 2a01107:	test   %eax,%eax
 2a01109:	je     2a01117 <wasm[0]::function[1015]::helper::object_read+0x2fb7>
 2a0110f:	mov    0x278(%rsp),%r12
 2a01117:	mov    0x128(%rsp),%r11d
 2a0111f:	mov    0xa0(%rsp),%edx
 2a01126:	mov    0x48(%rsp),%ecx
 2a0112a:	mov    %rcx,0x1e8(%rsp)
 2a01132:	mov    0x80(%rsp),%esi
 2a01139:	mov    %rsi,0x1f0(%rsp)
 2a01141:	mov    0xa8(%rsp),%edi
 2a01148:	mov    %rdi,0x1f8(%rsp)
 2a01150:	mov    0xb8(%rsp),%edi
 2a01157:	mov    0x58(%rsp),%r8d
 2a0115c:	mov    0x78(%rsp),%r9d
 2a01161:	mov    0x108(%rsp),%r10d
 2a01169:	test   %r12d,%r12d
 2a0116c:	je     2a02101 <wasm[0]::function[1015]::helper::object_read+0x3fa1>
 2a01172:	mov    0x128(%rsp),%esi
 2a01179:	test   %esi,%esi
 2a0117b:	je     2a18fa0 <wasm[0]::function[1015]::helper::object_read+0x1ae40>
 2a01181:	test   %esi,%esi
 2a01183:	je     2a18fa2 <wasm[0]::function[1015]::helper::object_read+0x1ae42>
 2a01189:	mov    0x2e0(%rsp),%r14
 2a01191:	mov    0x28(%r14),%r10
 2a01195:	mov    %esi,%r11d
 2a01198:	mov    %r11,%rdi
 2a0119b:	add    0x20(%r14),%rdi
 2a0119f:	xor    %rax,%rax
 2a011a2:	cmp    %r10,%r11
 2a011a5:	cmova  %rax,%rdi
 2a011a9:	mov    0x24(%rdi),%r11d
 2a011ad:	cmp    $0x3,%r11d
 2a011b1:	je     2a01abb <wasm[0]::function[1015]::helper::object_read+0x395b>
 2a011b7:	mov    0x128(%rsp),%r11d
 2a011bf:	test   %r11d,%r11d
 2a011c2:	je     2a18fa4 <wasm[0]::function[1015]::helper::object_read+0x1ae44>
 2a011c8:	test   %r11d,%r11d
 2a011cb:	je     2a18fa6 <wasm[0]::function[1015]::helper::object_read+0x1ae46>
 2a011d1:	mov    0x2e0(%rsp),%r14
 2a011d9:	mov    0x28(%r14),%rax
 2a011dd:	mov    0x20(%r14),%rcx
 2a011e1:	mov    %r11d,%edx
 2a011e4:	add    %rdx,%rcx
 2a011e7:	xor    %rsi,%rsi
 2a011ea:	cmp    %rax,%rdx
 2a011ed:	cmova  %rsi,%rcx
 2a011f1:	mov    0x24(%rcx),%eax
 2a011f4:	mov    0xa0(%rsp),%edx
 2a011fb:	mov    0x48(%rsp),%ecx
 2a011ff:	mov    %rcx,0x1e8(%rsp)
 2a01207:	mov    0x80(%rsp),%esi
 2a0120e:	mov    %rsi,0x1f0(%rsp)
 2a01216:	mov    0xa8(%rsp),%edi
 2a0121d:	mov    %rdi,0x1f8(%rsp)
 2a01225:	mov    0xb8(%rsp),%edi
 2a0122c:	mov    0x58(%rsp),%r8d
 2a01231:	mov    0x78(%rsp),%r9d
 2a01236:	mov    0x108(%rsp),%r10d
 2a0123e:	cmp    $0x4,%eax
 2a01241:	sete   %cl
 2a01244:	cmp    $0x2,%eax
 2a01247:	sete   %al
 2a0124a:	or     %eax,%ecx
 2a0124c:	test   %cl,%cl
 2a0124e:	je     2a02101 <wasm[0]::function[1015]::helper::object_read+0x3fa1>
 2a01254:	mov    0x128(%rsp),%edx
 2a0125b:	test   %edx,%edx
 2a0125d:	je     2a18fa8 <wasm[0]::function[1015]::helper::object_read+0x1ae48>
 2a01263:	test   %edx,%edx
 2a01265:	je     2a18faa <wasm[0]::function[1015]::helper::object_read+0x1ae4a>
 2a0126b:	mov    0x2e0(%rsp),%r14
 2a01273:	mov    0x28(%r14),%rax
 2a01277:	mov    0x20(%r14),%rcx
 2a0127b:	mov    %edx,%esi
 2a0127d:	lea    (%rcx,%rsi,1),%rdi
 2a01281:	xor    %rdx,%rdx
 2a01284:	cmp    %rax,%rsi
 2a01287:	cmova  %rdx,%rdi
 2a0128b:	mov    0x28(%rdi),%esi
 2a0128e:	mov    %esi,0x110(%rsp)
 2a01295:	mov    0x2c(%rdi),%edi
 2a01298:	mov    %edi,0xe8(%rsp)
 2a0129f:	test   %esi,%esi
 2a012a1:	je     2a18fac <wasm[0]::function[1015]::helper::object_read+0x1ae4c>
 2a012a7:	test   %esi,%esi
 2a012a9:	je     2a18fae <wasm[0]::function[1015]::helper::object_read+0x1ae4e>
 2a012af:	mov    %esi,%esi
 2a012b1:	lea    0x10(%rcx,%rsi,1),%rcx
 2a012b6:	cmp    %rax,%rsi
 2a012b9:	cmova  %rdx,%rcx
 2a012bd:	mov    (%rcx),%eax
 2a012bf:	mov    %eax,%r13d
 2a012c2:	mov    %r13,%rbx
 2a012c5:	shl    $0x2,%rbx
 2a012c9:	mov    $0x20,%ecx
 2a012ce:	mov    %rcx,0x230(%rsp)
 2a012d6:	mov    %rbx,%rcx
 2a012d9:	shr    $0x20,%rcx
 2a012dd:	test   %rcx,%rcx
 2a012e0:	jne    2a18fb0 <wasm[0]::function[1015]::helper::object_read+0x1ae50>
 2a012e6:	mov    %rax,%rcx
 2a012e9:	shl    $0x2,%ecx
 2a012ec:	mov    %rax,0x238(%rsp)
 2a012f4:	add    $0x14,%ecx
 2a012f7:	jb     2a18fb2 <wasm[0]::function[1015]::helper::object_read+0x1ae52>
 2a012fd:	mov    0x190(%rsp),%rax
 2a01305:	mov    0x20(%rax),%rdi
 2a01309:	mov    (%rdi),%eax
 2a0130b:	mov    %eax,%edx
 2a0130d:	mov    %ecx,%esi
 2a0130f:	add    $0xf,%rsi
 2a01316:	mov    %rsi,%r8
 2a01319:	and    $0xfffffffffffffff0,%r8
 2a0131d:	add    %rdx,%r8
 2a01320:	mov    0x4(%rdi),%r9d
 2a01324:	mov    %rdi,0x220(%rsp)
 2a0132c:	cmp    %r9,%r8
 2a0132f:	ja     2a178bd <wasm[0]::function[1015]::helper::object_read+0x1975d>
 2a01335:	add    $0xf,%ecx
 2a0133b:	and    $0xfffffff0,%ecx
 2a0133e:	add    %eax,%ecx
 2a01340:	mov    0x220(%rsp),%r14
 2a01348:	mov    %ecx,(%r14)
 2a0134b:	mov    0x2e0(%rsp),%r14
 2a01353:	mov    0x20(%r14),%rdi
 2a01357:	lea    (%rdi,%rdx,1),%rcx
 2a0135b:	movl   $0xa800000e,(%rdi,%rdx,1)
 2a01362:	mov    0x190(%rsp),%r10
 2a0136a:	mov    0x28(%r10),%r8
 2a0136e:	mov    0x194(%r8),%r8d
 2a01375:	mov    %r8d,0x4(%rdi,%rdx,1)
 2a0137a:	and    $0xfffffffffffffff0,%rsi
 2a0137e:	mov    %esi,0x8(%rdi,%rdx,1)
 2a01382:	mov    %eax,0xb0(%rsp)
 2a01389:	mov    0x238(%rsp),%r15
 2a01391:	mov    %r15d,0x10(%rcx)
 2a01395:	test   %eax,%eax
 2a01397:	je     2a18fb4 <wasm[0]::function[1015]::helper::object_read+0x1ae54>
 2a0139d:	mov    0x2e0(%rsp),%r14
 2a013a5:	mov    0x28(%r14),%rcx
 2a013a9:	mov    0x20(%r14),%rdx
 2a013ad:	mov    %eax,%esi
 2a013af:	lea    (%rdx,%rsi,1),%rax
 2a013b3:	lea    0x10(%rdx,%rsi,1),%rdi
 2a013b8:	xor    %r8,%r8
 2a013bb:	cmp    %rcx,%rsi
 2a013be:	cmova  %r8,%rdi
 2a013c2:	mov    (%rdi),%edi
 2a013c4:	cmp    %rdi,%r13
 2a013c7:	ja     2a18fb6 <wasm[0]::function[1015]::helper::object_read+0x1ae56>
 2a013cd:	lea    0x14(%rdx,%rsi,1),%r12
 2a013d2:	mov    %r12,%rsi
 2a013d5:	add    %rbx,%rsi
 2a013d8:	jb     2a18fb8 <wasm[0]::function[1015]::helper::object_read+0x1ae58>
 2a013de:	add    %rdx,%rcx
 2a013e1:	cmp    %rcx,%rsi
 2a013e4:	ja     2a18fba <wasm[0]::function[1015]::helper::object_read+0x1ae5a>
 2a013ea:	mov    0x128(%rsp),%r14d
 2a013f2:	mov    0xe8(%rsp),%ebx
 2a013f9:	mov    0x110(%rsp),%r15d
 2a01401:	mov    0xa0(%rsp),%esi
 2a01408:	mov    0x48(%rsp),%edi
 2a0140c:	mov    0x80(%rsp),%r9d
 2a01414:	mov    0xa8(%rsp),%r11d
 2a0141c:	mov    0xb8(%rsp),%ecx
 2a01423:	mov    0x58(%rsp),%edx
 2a01427:	mov    0x78(%rsp),%r8d
 2a0142c:	mov    0x108(%rsp),%r10d
 2a01434:	lea    0x14(%rax,%r13,4),%rax
 2a01439:	mov    %rax,0x218(%rsp)
 2a01441:	test   %r13,%r13
 2a01444:	je     2a01539 <wasm[0]::function[1015]::helper::object_read+0x33d9>
 2a0144a:	mov    %r14d,0x130(%rsp)
 2a01452:	mov    %ebx,0x148(%rsp)
 2a01459:	mov    %r15d,0x90(%rsp)
 2a01461:	mov    %esi,0x118(%rsp)
 2a01468:	mov    %edi,0xc0(%rsp)
 2a0146f:	mov    %r9d,0x140(%rsp)
 2a01477:	mov    %r11d,0xd0(%rsp)
 2a0147f:	mov    %ecx,0x100(%rsp)
 2a01486:	mov    %edx,0x88(%rsp)
 2a0148d:	mov    %r8d,0x110(%rsp)
 2a01495:	mov    %r10d,0xe8(%rsp)
 2a0149d:	mov    0x2e8(%rsp),%r15
 2a014a5:	mov    (%r15),%r8
 2a014a8:	mov    0x228(%rsp),%rax
 2a014b0:	cmp    %rax,%r8
 2a014b3:	jae    2a178fa <wasm[0]::function[1015]::helper::object_read+0x1979a>
 2a014b9:	movl   $0x0,(%r12)
 2a014c1:	mov    0x130(%rsp),%r14d
 2a014c9:	mov    0x148(%rsp),%ebx
 2a014d0:	mov    0x90(%rsp),%r15d
 2a014d8:	mov    0x118(%rsp),%esi
 2a014df:	mov    0xc0(%rsp),%edi
 2a014e6:	mov    0x140(%rsp),%r9d
 2a014ee:	mov    0xd0(%rsp),%r11d
 2a014f6:	mov    0x100(%rsp),%ecx
 2a014fd:	mov    0x88(%rsp),%edx
 2a01504:	mov    0x110(%rsp),%r8d
 2a0150c:	mov    0xe8(%rsp),%r10d
 2a01514:	add    $0x4,%r12
 2a0151b:	mov    0x218(%rsp),%r13
 2a01523:	cmp    %r13,%r12
 2a01526:	je     2a01539 <wasm[0]::function[1015]::helper::object_read+0x33d9>
 2a0152c:	mov    %r13,0x218(%rsp)
 2a01534:	jmp    2a0144a <wasm[0]::function[1015]::helper::object_read+0x32ea>
 2a01539:	mov    %r14d,0x90(%rsp)
 2a01541:	mov    %ebx,0x148(%rsp)
 2a01548:	mov    %r15d,0x130(%rsp)
 2a01550:	xor    %r12d,%r12d
 2a01553:	mov    0x190(%rsp),%rax
 2a0155b:	mov    0x28(%rax),%rax
 2a0155f:	mov    0x120(%rax),%r13d
 2a01566:	mov    %r13,0x218(%rsp)
 2a0156e:	mov    $0x10,%ebx
 2a01573:	mov    %rbx,0x1d8(%rsp)
 2a0157b:	mov    0x13c(%rax),%ebx
 2a01581:	mov    %rbx,0x1d0(%rsp)
 2a01589:	mov    %esi,0xe8(%rsp)
 2a01590:	mov    %edi,0x110(%rsp)
 2a01597:	mov    %r9d,0x88(%rsp)
 2a0159f:	mov    %r11d,0x100(%rsp)
 2a015a7:	mov    %ecx,0xd0(%rsp)
 2a015ae:	mov    %edx,0x140(%rsp)
 2a015b5:	mov    %r8d,0xc0(%rsp)
 2a015bd:	mov    %r10d,0x118(%rsp)
 2a015c5:	mov    0x2e8(%rsp),%r15
 2a015cd:	mov    (%r15),%rax
 2a015d0:	mov    0x228(%rsp),%rcx
 2a015d8:	cmp    %rcx,%rax
 2a015db:	jae    2a17931 <wasm[0]::function[1015]::helper::object_read+0x197d1>
 2a015e1:	mov    0x238(%rsp),%rdx
 2a015e9:	jmp    2a015f6 <wasm[0]::function[1015]::helper::object_read+0x3496>
 2a015ee:	mov    0x238(%rsp),%rdx
 2a015f6:	cmp    %edx,%r12d
 2a015f9:	jae    2a019d1 <wasm[0]::function[1015]::helper::object_read+0x3871>
 2a015ff:	mov    0x90(%rsp),%eax
 2a01606:	test   %eax,%eax
 2a01608:	je     2a18fbc <wasm[0]::function[1015]::helper::object_read+0x1ae5c>
 2a0160e:	test   %eax,%eax
 2a01610:	je     2a18fbe <wasm[0]::function[1015]::helper::object_read+0x1ae5e>
 2a01616:	mov    0x2e0(%rsp),%r14
 2a0161e:	mov    0x28(%r14),%rcx
 2a01622:	mov    %eax,%edx
 2a01624:	mov    %rdx,%rax
 2a01627:	add    0x20(%r14),%rax
 2a0162b:	xor    %rsi,%rsi
 2a0162e:	cmp    %rcx,%rdx
 2a01631:	cmova  %rsi,%rax
 2a01635:	mov    0x24(%rax),%eax
 2a01638:	cmp    $0x4,%eax
 2a0163b:	je     2a016e1 <wasm[0]::function[1015]::helper::object_read+0x3581>
 2a01641:	mov    0x148(%rsp),%eax
 2a01648:	test   %eax,%eax
 2a0164a:	je     2a18fc0 <wasm[0]::function[1015]::helper::object_read+0x1ae60>
 2a01650:	test   %eax,%eax
 2a01652:	je     2a18fc2 <wasm[0]::function[1015]::helper::object_read+0x1ae62>
 2a01658:	mov    0x2e0(%rsp),%r14
 2a01660:	mov    0x28(%r14),%rcx
 2a01664:	mov    0x20(%r14),%rdx
 2a01668:	mov    %eax,%r8d
 2a0166b:	lea    0x10(%rdx,%r8,1),%rdi
 2a01670:	xor    %rsi,%rsi
 2a01673:	cmp    %rcx,%r8
 2a01676:	cmova  %rsi,%rdi
 2a0167a:	mov    (%rdi),%edi
 2a0167c:	mov    %r12,%r8
 2a0167f:	shr    $0x6,%r8d
 2a01683:	cmp    %edi,%r8d
 2a01686:	jae    2a18fc4 <wasm[0]::function[1015]::helper::object_read+0x1ae64>
 2a0168c:	mov    %edi,%r9d
 2a0168f:	shl    $0x3,%r9
 2a01693:	shr    $0x20,%r9
 2a01697:	test   %r9,%r9
 2a0169a:	jne    2a18fc6 <wasm[0]::function[1015]::helper::object_read+0x1ae66>
 2a016a0:	shl    $0x3,%edi
 2a016a3:	add    $0x18,%edi
 2a016a6:	jb     2a18fc8 <wasm[0]::function[1015]::helper::object_read+0x1ae68>
 2a016ac:	add    %edi,%eax
 2a016ae:	jb     2a18fca <wasm[0]::function[1015]::helper::object_read+0x1ae6a>
 2a016b4:	mov    %eax,%r9d
 2a016b7:	lea    (%rdx,%r9,1),%rax
 2a016bb:	cmp    %rcx,%r9
 2a016be:	cmova  %rsi,%rax
 2a016c2:	shl    $0x3,%r8d
 2a016c6:	lea    0x18(%r8),%ecx
 2a016ca:	sub    %ecx,%edi
 2a016cc:	sub    %rdi,%rax
 2a016cf:	mov    (%rax),%rax
 2a016d2:	bt     %r12,%rax
 2a016d6:	setb   %al
 2a016d9:	movzbl %al,%eax
 2a016dc:	jmp    2a01726 <wasm[0]::function[1015]::helper::object_read+0x35c6>
 2a016e1:	mov    0x90(%rsp),%eax
 2a016e8:	test   %eax,%eax
 2a016ea:	je     2a18fcc <wasm[0]::function[1015]::helper::object_read+0x1ae6c>
 2a016f0:	test   %eax,%eax
 2a016f2:	je     2a18fce <wasm[0]::function[1015]::helper::object_read+0x1ae6e>
 2a016f8:	mov    0x2e0(%rsp),%r14
 2a01700:	mov    0x28(%r14),%rsi
 2a01704:	mov    %eax,%edi
 2a01706:	mov    %rdi,%rax
 2a01709:	add    0x20(%r14),%rax
 2a0170d:	xor    %r8,%r8
 2a01710:	cmp    %rsi,%rdi
 2a01713:	cmova  %r8,%rax
 2a01717:	mov    %r12d,%esi
 2a0171a:	cmp    0x18(%rax),%rsi
 2a0171e:	setb   %sil
 2a01722:	movzbl %sil,%eax
 2a01726:	test   %eax,%eax
 2a01728:	jne    2a0174b <wasm[0]::function[1015]::helper::object_read+0x35eb>
 2a0172e:	mov    0x220(%rsp),%rbx
 2a01736:	mov    0x1d0(%rsp),%r13
 2a0173e:	mov    0x230(%rsp),%r15
 2a01746:	jmp    2a01971 <wasm[0]::function[1015]::helper::object_read+0x3811>
 2a0174b:	mov    0x130(%rsp),%eax
 2a01752:	test   %eax,%eax
 2a01754:	je     2a18fd0 <wasm[0]::function[1015]::helper::object_read+0x1ae70>
 2a0175a:	test   %eax,%eax
 2a0175c:	je     2a18fd2 <wasm[0]::function[1015]::helper::object_read+0x1ae72>
 2a01762:	mov    0x2e0(%rsp),%r14
 2a0176a:	mov    0x28(%r14),%rcx
 2a0176e:	mov    0x20(%r14),%rdx
 2a01772:	mov    %eax,%edi
 2a01774:	lea    0x10(%rdx,%rdi,1),%r10
 2a01779:	xor    %rsi,%rsi
 2a0177c:	cmp    %rcx,%rdi
 2a0177f:	cmova  %rsi,%r10
 2a01783:	mov    (%r10),%edi
 2a01786:	cmp    %edi,%r12d
 2a01789:	jae    2a18fd4 <wasm[0]::function[1015]::helper::object_read+0x1ae74>
 2a0178f:	mov    %edi,%r8d
 2a01792:	shl    $0x3,%r8
 2a01796:	shr    $0x20,%r8
 2a0179a:	test   %r8,%r8
 2a0179d:	jne    2a18fd6 <wasm[0]::function[1015]::helper::object_read+0x1ae76>
 2a017a3:	shl    $0x3,%edi
 2a017a6:	add    $0x18,%edi
 2a017a9:	jb     2a18fd8 <wasm[0]::function[1015]::helper::object_read+0x1ae78>
 2a017af:	add    %edi,%eax
 2a017b1:	jb     2a18fda <wasm[0]::function[1015]::helper::object_read+0x1ae7a>
 2a017b7:	mov    %eax,%r8d
 2a017ba:	lea    (%rdx,%r8,1),%rax
 2a017be:	cmp    %rcx,%r8
 2a017c1:	cmova  %rsi,%rax
 2a017c5:	mov    %r12,%rcx
 2a017c8:	shl    $0x3,%ecx
 2a017cb:	add    $0x18,%ecx
 2a017d1:	sub    %ecx,%edi
 2a017d3:	sub    %rdi,%rax
 2a017d6:	mov    (%rax),%r13
 2a017d9:	movl   $0x0,0xf0(%rsp)
 2a017e4:	mov    0x220(%rsp),%rbx
 2a017ec:	mov    (%rbx),%eax
 2a017ee:	mov    %eax,%ecx
 2a017f0:	lea    0x20(%rcx),%rdx
 2a017f4:	mov    0x4(%rbx),%esi
 2a017f7:	cmp    %rsi,%rdx
 2a017fa:	ja     2a17970 <wasm[0]::function[1015]::helper::object_read+0x19810>
 2a01800:	lea    0x20(%rax),%edx
 2a01803:	mov    %edx,(%rbx)
 2a01805:	mov    0x2e0(%rsp),%r14
 2a0180d:	mov    0x20(%r14),%rdx
 2a01811:	lea    (%rdx,%rcx,1),%rsi
 2a01815:	movl   $0xb0000042,(%rdx,%rcx,1)
 2a0181c:	mov    0x218(%rsp),%r9
 2a01824:	mov    %r9d,0x4(%rdx,%rcx,1)
 2a01829:	mov    0x230(%rsp),%r15
 2a01831:	mov    %r15d,0x8(%rdx,%rcx,1)
 2a01836:	mov    %eax,0xd8(%rsp)
 2a0183d:	mov    %r13,0x10(%rsi)
 2a01841:	movl   $0x3,0x18(%rsi)
 2a01848:	mov    0xf0(%rsp),%ecx
 2a0184f:	mov    %ecx,0x1c(%rsi)
 2a01852:	mov    0x190(%rsp),%rcx
 2a0185a:	mov    0xa20(%rcx),%ecx
 2a01860:	mov    %ecx,0xf0(%rsp)
 2a01867:	test   %eax,%eax
 2a01869:	je     2a18fdc <wasm[0]::function[1015]::helper::object_read+0x1ae7c>
 2a0186f:	test   %ecx,%ecx
 2a01871:	je     2a18fde <wasm[0]::function[1015]::helper::object_read+0x1ae7e>
 2a01877:	mov    (%rbx),%eax
 2a01879:	mov    %eax,%edx
 2a0187b:	lea    0x20(%rdx),%rcx
 2a0187f:	mov    0x4(%rbx),%esi
 2a01882:	cmp    %rsi,%rcx
 2a01885:	ja     2a179b2 <wasm[0]::function[1015]::helper::object_read+0x19852>
 2a0188b:	mov    0x1d0(%rsp),%r13
 2a01893:	lea    0x20(%rax),%ecx
 2a01896:	mov    %ecx,(%rbx)
 2a01898:	mov    0x2e0(%rsp),%r14
 2a018a0:	mov    0x20(%r14),%rsi
 2a018a4:	lea    (%rsi,%rdx,1),%rcx
 2a018a8:	movl   $0xb0000072,(%rsi,%rdx,1)
 2a018af:	mov    %r13d,0x4(%rsi,%rdx,1)
 2a018b4:	mov    %r15d,0x8(%rsi,%rdx,1)
 2a018b9:	movl   $0xe,0x10(%rcx)
 2a018c0:	mov    0xd8(%rsp),%edx
 2a018c7:	mov    %edx,0x14(%rcx)
 2a018ca:	mov    0xf0(%rsp),%edx
 2a018d1:	mov    %edx,0x18(%rcx)
 2a018d4:	mov    %edx,0x1c(%rcx)
 2a018d7:	mov    0xb0(%rsp),%ecx
 2a018de:	test   %ecx,%ecx
 2a018e0:	je     2a18fe0 <wasm[0]::function[1015]::helper::object_read+0x1ae80>
 2a018e6:	test   %eax,%eax
 2a018e8:	je     2a18fe2 <wasm[0]::function[1015]::helper::object_read+0x1ae82>
 2a018ee:	test   %ecx,%ecx
 2a018f0:	je     2a18fe4 <wasm[0]::function[1015]::helper::object_read+0x1ae84>
 2a018f6:	mov    0x2e0(%rsp),%r14
 2a018fe:	mov    0x28(%r14),%rdx
 2a01902:	mov    0x20(%r14),%rsi
 2a01906:	mov    %ecx,%r9d
 2a01909:	lea    0x10(%rsi,%r9,1),%r8
 2a0190e:	xor    %rdi,%rdi
 2a01911:	cmp    %rdx,%r9
 2a01914:	cmova  %rdi,%r8
 2a01918:	mov    (%r8),%r8d
 2a0191b:	cmp    %r8d,%r12d
 2a0191e:	jae    2a18fe6 <wasm[0]::function[1015]::helper::object_read+0x1ae86>
 2a01924:	mov    %r8d,%r9d
 2a01927:	shl    $0x2,%r9
 2a0192b:	shr    $0x20,%r9
 2a0192f:	test   %r9,%r9
 2a01932:	jne    2a18fe8 <wasm[0]::function[1015]::helper::object_read+0x1ae88>
 2a01938:	shl    $0x2,%r8d
 2a0193c:	add    $0x14,%r8d
 2a01940:	jb     2a18fea <wasm[0]::function[1015]::helper::object_read+0x1ae8a>
 2a01946:	add    %r8d,%ecx
 2a01949:	jb     2a18fec <wasm[0]::function[1015]::helper::object_read+0x1ae8c>
 2a0194f:	mov    %ecx,%r9d
 2a01952:	lea    (%rsi,%r9,1),%rcx
 2a01956:	cmp    %rdx,%r9
 2a01959:	cmova  %rdi,%rcx
 2a0195d:	mov    %r12,%rdx
 2a01960:	shl    $0x2,%edx
 2a01963:	add    $0x14,%edx
 2a01969:	sub    %edx,%r8d
 2a0196c:	sub    %r8,%rcx
 2a0196f:	mov    %eax,(%rcx)
 2a01971:	mov    0xe8(%rsp),%esi
 2a01978:	mov    0x110(%rsp),%edi
 2a0197f:	mov    0x88(%rsp),%r9d
 2a01987:	mov    0x100(%rsp),%r11d
 2a0198f:	mov    0xd0(%rsp),%ecx
 2a01996:	mov    0x140(%rsp),%edx
 2a0199d:	mov    0xc0(%rsp),%r8d
 2a019a5:	mov    0x118(%rsp),%r10d
 2a019ad:	add    $0x1,%r12d
 2a019b4:	mov    %r13,0x1d0(%rsp)
 2a019bc:	mov    %rbx,0x220(%rsp)
 2a019c4:	mov    %r15,0x230(%rsp)
 2a019cc:	jmp    2a01589 <wasm[0]::function[1015]::helper::object_read+0x3429>
 2a019d1:	mov    0x90(%rsp),%r11d
 2a019d9:	test   %r11d,%r11d
 2a019dc:	je     2a18fee <wasm[0]::function[1015]::helper::object_read+0x1ae8e>
 2a019e2:	mov    0xb0(%rsp),%edi
 2a019e9:	test   %edi,%edi
 2a019eb:	je     2a18ff0 <wasm[0]::function[1015]::helper::object_read+0x1ae90>
 2a019f1:	test   %r11d,%r11d
 2a019f4:	je     2a18ff2 <wasm[0]::function[1015]::helper::object_read+0x1ae92>
 2a019fa:	mov    0x2e0(%rsp),%r14
 2a01a02:	mov    0x28(%r14),%rax
 2a01a06:	mov    0x20(%r14),%rdx
 2a01a0a:	mov    %r11d,%ecx
 2a01a0d:	lea    (%rdx,%rcx,1),%r8
 2a01a11:	xor    %rdx,%rdx
 2a01a14:	cmp    %rax,%rcx
 2a01a17:	cmova  %rdx,%r8
 2a01a1b:	mov    %edi,0x20(%r8)
 2a01a1f:	mov    0x190(%rsp),%rcx
 2a01a27:	mov    0xa00(%rcx),%ecx
 2a01a2d:	mov    0x190(%rsp),%rax
 2a01a35:	mov    0xa10(%rax),%eax
 2a01a3b:	test   %ecx,%ecx
 2a01a3d:	je     2a18ff4 <wasm[0]::function[1015]::helper::object_read+0x1ae94>
 2a01a43:	mov    %ecx,0x28(%r8)
 2a01a47:	test   %eax,%eax
 2a01a49:	je     2a18ff6 <wasm[0]::function[1015]::helper::object_read+0x1ae96>
 2a01a4f:	mov    %eax,0x2c(%r8)
 2a01a53:	movl   $0x0,0x30(%r8)
 2a01a5b:	movl   $0x0,0x24(%r8)
 2a01a63:	mov    0xe8(%rsp),%edx
 2a01a6a:	mov    0x110(%rsp),%ecx
 2a01a71:	mov    %rcx,0x1e8(%rsp)
 2a01a79:	mov    0x88(%rsp),%esi
 2a01a80:	mov    %rsi,0x1f0(%rsp)
 2a01a88:	mov    0x100(%rsp),%edi
 2a01a8f:	mov    %rdi,0x1f8(%rsp)
 2a01a97:	mov    0xd0(%rsp),%edi
 2a01a9e:	mov    0x140(%rsp),%r8d
 2a01aa6:	mov    0xc0(%rsp),%r9d
 2a01aae:	mov    0x118(%rsp),%r10d
 2a01ab6:	jmp    2a02101 <wasm[0]::function[1015]::helper::object_read+0x3fa1>
 2a01abb:	mov    0x128(%rsp),%edx
 2a01ac2:	test   %edx,%edx
 2a01ac4:	je     2a18ff8 <wasm[0]::function[1015]::helper::object_read+0x1ae98>
 2a01aca:	test   %edx,%edx
 2a01acc:	je     2a18ffa <wasm[0]::function[1015]::helper::object_read+0x1ae9a>
 2a01ad2:	mov    0x2e0(%rsp),%r14
 2a01ada:	mov    0x28(%r14),%rax
 2a01ade:	mov    0x20(%r14),%rcx
 2a01ae2:	mov    %edx,%edi
 2a01ae4:	lea    (%rcx,%rdi,1),%rsi
 2a01ae8:	xor    %rdx,%rdx
 2a01aeb:	cmp    %rax,%rdi
 2a01aee:	cmova  %rdx,%rsi
 2a01af2:	mov    0x30(%rsi),%esi
 2a01af5:	mov    %esi,0x90(%rsp)
 2a01afc:	test   %esi,%esi
 2a01afe:	je     2a18ffc <wasm[0]::function[1015]::helper::object_read+0x1ae9c>
 2a01b04:	test   %esi,%esi
 2a01b06:	je     2a18ffe <wasm[0]::function[1015]::helper::object_read+0x1ae9e>
 2a01b0c:	mov    %esi,%esi
 2a01b0e:	lea    0x10(%rcx,%rsi,1),%rcx
 2a01b13:	cmp    %rax,%rsi
 2a01b16:	cmova  %rdx,%rcx
 2a01b1a:	mov    (%rcx),%eax
 2a01b1c:	mov    %eax,%ebx
 2a01b1e:	mov    %rbx,%r14
 2a01b21:	shl    $0x2,%r14
 2a01b25:	mov    $0x20,%ecx
 2a01b2a:	mov    %rcx,0x1c8(%rsp)
 2a01b32:	mov    %r14,%rcx
 2a01b35:	shr    $0x20,%rcx
 2a01b39:	test   %rcx,%rcx
 2a01b3c:	jne    2a19000 <wasm[0]::function[1015]::helper::object_read+0x1aea0>
 2a01b42:	mov    %rax,%rcx
 2a01b45:	shl    $0x2,%ecx
 2a01b48:	mov    %rax,0x1d0(%rsp)
 2a01b50:	add    $0x14,%ecx
 2a01b53:	jb     2a19002 <wasm[0]::function[1015]::helper::object_read+0x1aea2>
 2a01b59:	mov    0x190(%rsp),%rax
 2a01b61:	mov    0x20(%rax),%r13
 2a01b65:	mov    0x0(%r13),%eax
 2a01b69:	mov    %eax,%edx
 2a01b6b:	mov    %ecx,%esi
 2a01b6d:	add    $0xf,%rsi
 2a01b74:	mov    %rsi,%rdi
 2a01b77:	and    $0xfffffffffffffff0,%rdi
 2a01b7b:	add    %rdx,%rdi
 2a01b7e:	mov    0x4(%r13),%r8d
 2a01b82:	cmp    %r8,%rdi
 2a01b85:	ja     2a179ef <wasm[0]::function[1015]::helper::object_read+0x1988f>
 2a01b8b:	add    $0xf,%ecx
 2a01b91:	and    $0xfffffff0,%ecx
 2a01b94:	add    %eax,%ecx
 2a01b96:	mov    %ecx,0x0(%r13)
 2a01b9a:	mov    0x2e0(%rsp),%rcx
 2a01ba2:	mov    0x20(%rcx),%rcx
 2a01ba6:	lea    (%rcx,%rdx,1),%r11
 2a01baa:	movl   $0xa800000e,(%rcx,%rdx,1)
 2a01bb1:	mov    0x190(%rsp),%rdi
 2a01bb9:	mov    0x28(%rdi),%rdi
 2a01bbd:	mov    0x194(%rdi),%edi
 2a01bc3:	mov    %edi,0x4(%rcx,%rdx,1)
 2a01bc7:	and    $0xfffffffffffffff0,%rsi
 2a01bcb:	mov    %esi,0x8(%rcx,%rdx,1)
 2a01bcf:	mov    %eax,0xe8(%rsp)
 2a01bd6:	mov    0x1d0(%rsp),%rcx
 2a01bde:	mov    %ecx,0x10(%r11)
 2a01be2:	test   %eax,%eax
 2a01be4:	je     2a19004 <wasm[0]::function[1015]::helper::object_read+0x1aea4>
 2a01bea:	mov    0x2e0(%rsp),%r10
 2a01bf2:	mov    0x28(%r10),%rcx
 2a01bf6:	mov    0x2e0(%rsp),%rdx
 2a01bfe:	mov    0x20(%rdx),%rdx
 2a01c02:	mov    %eax,%eax
 2a01c04:	lea    (%rdx,%rax,1),%r15
 2a01c08:	lea    0x10(%rdx,%rax,1),%rsi
 2a01c0d:	xor    %rdi,%rdi
 2a01c10:	cmp    %rcx,%rax
 2a01c13:	cmova  %rdi,%rsi
 2a01c17:	mov    (%rsi),%esi
 2a01c19:	cmp    %rsi,%rbx
 2a01c1c:	ja     2a19006 <wasm[0]::function[1015]::helper::object_read+0x1aea6>
 2a01c22:	lea    0x14(%rdx,%rax,1),%r12
 2a01c27:	mov    %r12,%rax
 2a01c2a:	add    %r14,%rax
 2a01c2d:	jb     2a19008 <wasm[0]::function[1015]::helper::object_read+0x1aea8>
 2a01c33:	add    %rdx,%rcx
 2a01c36:	cmp    %rcx,%rax
 2a01c39:	ja     2a1900a <wasm[0]::function[1015]::helper::object_read+0x1aeaa>
 2a01c3f:	mov    0x90(%rsp),%r14d
 2a01c47:	mov    0x128(%rsp),%eax
 2a01c4e:	mov    0xa0(%rsp),%edx
 2a01c55:	mov    0x48(%rsp),%esi
 2a01c59:	mov    0x80(%rsp),%edi
 2a01c60:	mov    0xa8(%rsp),%r8d
 2a01c68:	mov    0xb8(%rsp),%r9d
 2a01c70:	mov    0x58(%rsp),%r10d
 2a01c75:	mov    0x78(%rsp),%r11d
 2a01c7a:	mov    0x108(%rsp),%ecx
 2a01c81:	lea    0x14(%r15,%rbx,4),%r15
 2a01c86:	test   %rbx,%rbx
 2a01c89:	je     2a01d59 <wasm[0]::function[1015]::helper::object_read+0x3bf9>
 2a01c8f:	mov    %r14d,0xb0(%rsp)
 2a01c97:	mov    %eax,0x118(%rsp)
 2a01c9e:	mov    %edx,0xc0(%rsp)
 2a01ca5:	mov    %esi,0x140(%rsp)
 2a01cac:	mov    %edi,0xd0(%rsp)
 2a01cb3:	mov    %r8d,0x100(%rsp)
 2a01cbb:	mov    %r9d,0x88(%rsp)
 2a01cc3:	mov    %r10d,0x110(%rsp)
 2a01ccb:	mov    %r11d,0x128(%rsp)
 2a01cd3:	mov    %ecx,0x90(%rsp)
 2a01cda:	mov    0x2e8(%rsp),%rax
 2a01ce2:	mov    (%rax),%rsi
 2a01ce5:	mov    0x228(%rsp),%rax
 2a01ced:	cmp    %rax,%rsi
 2a01cf0:	jae    2a17a2d <wasm[0]::function[1015]::helper::object_read+0x198cd>
 2a01cf6:	movl   $0x0,(%r12)
 2a01cfe:	mov    0xb0(%rsp),%r14d
 2a01d06:	mov    0x118(%rsp),%eax
 2a01d0d:	mov    0xc0(%rsp),%edx
 2a01d14:	mov    0x140(%rsp),%esi
 2a01d1b:	mov    0xd0(%rsp),%edi
 2a01d22:	mov    0x100(%rsp),%r8d
 2a01d2a:	mov    0x88(%rsp),%r9d
 2a01d32:	mov    0x110(%rsp),%r10d
 2a01d3a:	mov    0x128(%rsp),%r11d
 2a01d42:	mov    0x90(%rsp),%ecx
 2a01d49:	add    $0x4,%r12
 2a01d50:	cmp    %r15,%r12
 2a01d53:	jne    2a01c8f <wasm[0]::function[1015]::helper::object_read+0x3b2f>
 2a01d59:	mov    %r14d,0xb0(%rsp)
 2a01d61:	mov    0x190(%rsp),%rbx
 2a01d69:	mov    0xa20(%rbx),%ebx
 2a01d6f:	mov    %ebx,0x118(%rsp)
 2a01d76:	xor    %r15d,%r15d
 2a01d79:	mov    $0xb0000072,%r12d
 2a01d7f:	mov    0x190(%rsp),%rbx
 2a01d87:	mov    %r12,0x1a0(%rsp)
 2a01d8f:	mov    0x28(%rbx),%rbx
 2a01d93:	mov    0x13c(%rbx),%ebx
 2a01d99:	mov    $0x20,%r12d
 2a01d9f:	mov    %r12,0x198(%rsp)
 2a01da7:	mov    $0x10,%r12d
 2a01dad:	mov    %r12,0x2c8(%rsp)
 2a01db5:	mov    %eax,0x148(%rsp)
 2a01dbc:	mov    %edx,0x90(%rsp)
 2a01dc3:	mov    %esi,0x128(%rsp)
 2a01dca:	mov    %edi,0x110(%rsp)
 2a01dd1:	mov    %r8d,0x88(%rsp)
 2a01dd9:	mov    %r9d,0x100(%rsp)
 2a01de1:	mov    %r10d,0xd0(%rsp)
 2a01de9:	mov    %r11d,0x140(%rsp)
 2a01df1:	mov    %ecx,0xc0(%rsp)
 2a01df8:	mov    0x2e8(%rsp),%rax
 2a01e00:	mov    (%rax),%rax
 2a01e03:	mov    0x228(%rsp),%rcx
 2a01e0b:	cmp    %rcx,%rax
 2a01e0e:	jae    2a17a64 <wasm[0]::function[1015]::helper::object_read+0x19904>
 2a01e14:	mov    0x1d0(%rsp),%r9
 2a01e1c:	jmp    2a01e29 <wasm[0]::function[1015]::helper::object_read+0x3cc9>
 2a01e21:	mov    0x1d0(%rsp),%r9
 2a01e29:	cmp    %r9d,%r15d
 2a01e2c:	jae    2a0202a <wasm[0]::function[1015]::helper::object_read+0x3eca>
 2a01e32:	mov    0xb0(%rsp),%eax
 2a01e39:	test   %eax,%eax
 2a01e3b:	je     2a1900c <wasm[0]::function[1015]::helper::object_read+0x1aeac>
 2a01e41:	test   %eax,%eax
 2a01e43:	je     2a1900e <wasm[0]::function[1015]::helper::object_read+0x1aeae>
 2a01e49:	mov    0x2e0(%rsp),%r14
 2a01e51:	mov    0x28(%r14),%rcx
 2a01e55:	mov    0x20(%r14),%rdx
 2a01e59:	mov    %eax,%r8d
 2a01e5c:	lea    0x10(%rdx,%r8,1),%rdi
 2a01e61:	xor    %rsi,%rsi
 2a01e64:	cmp    %rcx,%r8
 2a01e67:	cmova  %rsi,%rdi
 2a01e6b:	mov    (%rdi),%edi
 2a01e6d:	cmp    %edi,%r15d
 2a01e70:	jae    2a19010 <wasm[0]::function[1015]::helper::object_read+0x1aeb0>
 2a01e76:	mov    %edi,%r8d
 2a01e79:	shl    $0x2,%r8
 2a01e7d:	shr    $0x20,%r8
 2a01e81:	test   %r8,%r8
 2a01e84:	jne    2a19012 <wasm[0]::function[1015]::helper::object_read+0x1aeb2>
 2a01e8a:	shl    $0x2,%edi
 2a01e8d:	add    $0x14,%edi
 2a01e90:	jb     2a19014 <wasm[0]::function[1015]::helper::object_read+0x1aeb4>
 2a01e96:	add    %edi,%eax
 2a01e98:	jb     2a19016 <wasm[0]::function[1015]::helper::object_read+0x1aeb6>
 2a01e9e:	mov    %eax,%r8d
 2a01ea1:	lea    (%rdx,%r8,1),%rax
 2a01ea5:	cmp    %rcx,%r8
 2a01ea8:	cmova  %rsi,%rax
 2a01eac:	mov    %r15,%r12
 2a01eaf:	shl    $0x2,%r12d
 2a01eb3:	lea    0x14(%r12),%ecx
 2a01eb8:	sub    %ecx,%edi
 2a01eba:	sub    %rdi,%rax
 2a01ebd:	mov    (%rax),%eax
 2a01ebf:	mov    %eax,0x130(%rsp)
 2a01ec6:	test   %eax,%eax
 2a01ec8:	je     2a01fdb <wasm[0]::function[1015]::helper::object_read+0x3e7b>
 2a01ece:	test   %eax,%eax
 2a01ed0:	je     2a19018 <wasm[0]::function[1015]::helper::object_read+0x1aeb8>
 2a01ed6:	mov    0x118(%rsp),%eax
 2a01edd:	test   %eax,%eax
 2a01edf:	je     2a1901a <wasm[0]::function[1015]::helper::object_read+0x1aeba>
 2a01ee5:	mov    0x0(%r13),%eax
 2a01ee9:	mov    %eax,%edx
 2a01eeb:	lea    0x20(%rdx),%rcx
 2a01eef:	mov    0x4(%r13),%esi
 2a01ef3:	cmp    %rsi,%rcx
 2a01ef6:	ja     2a17aa3 <wasm[0]::function[1015]::helper::object_read+0x19943>
 2a01efc:	lea    0x20(%rax),%ecx
 2a01eff:	mov    %ecx,0x0(%r13)
 2a01f03:	mov    0x2e0(%rsp),%r14
 2a01f0b:	mov    0x20(%r14),%rsi
 2a01f0f:	lea    (%rsi,%rdx,1),%rcx
 2a01f13:	movl   $0xb0000072,(%rsi,%rdx,1)
 2a01f1a:	mov    %ebx,0x4(%rsi,%rdx,1)
 2a01f1e:	mov    0x1c8(%rsp),%rdi
 2a01f26:	mov    %edi,0x8(%rsi,%rdx,1)
 2a01f2a:	movl   $0xe,0x10(%rcx)
 2a01f31:	mov    0x130(%rsp),%esi
 2a01f38:	mov    %esi,0x14(%rcx)
 2a01f3b:	mov    0x118(%rsp),%esi
 2a01f42:	mov    %esi,0x18(%rcx)
 2a01f45:	mov    %esi,0x1c(%rcx)
 2a01f48:	mov    0xe8(%rsp),%ecx
 2a01f4f:	test   %ecx,%ecx
 2a01f51:	je     2a1901c <wasm[0]::function[1015]::helper::object_read+0x1aebc>
 2a01f57:	test   %eax,%eax
 2a01f59:	je     2a1901e <wasm[0]::function[1015]::helper::object_read+0x1aebe>
 2a01f5f:	test   %ecx,%ecx
 2a01f61:	je     2a19020 <wasm[0]::function[1015]::helper::object_read+0x1aec0>
 2a01f67:	mov    0x2e0(%rsp),%r14
 2a01f6f:	mov    0x28(%r14),%rdx
 2a01f73:	mov    0x20(%r14),%rsi
 2a01f77:	mov    %ecx,%r8d
 2a01f7a:	lea    0x10(%rsi,%r8,1),%r11
 2a01f7f:	xor    %rdi,%rdi
 2a01f82:	cmp    %rdx,%r8
 2a01f85:	cmova  %rdi,%r11
 2a01f89:	mov    (%r11),%r8d
 2a01f8c:	cmp    %r8d,%r15d
 2a01f8f:	jae    2a19022 <wasm[0]::function[1015]::helper::object_read+0x1aec2>
 2a01f95:	mov    %r8d,%r9d
 2a01f98:	shl    $0x2,%r9
 2a01f9c:	shr    $0x20,%r9
 2a01fa0:	test   %r9,%r9
 2a01fa3:	jne    2a19024 <wasm[0]::function[1015]::helper::object_read+0x1aec4>
 2a01fa9:	shl    $0x2,%r8d
 2a01fad:	add    $0x14,%r8d
 2a01fb1:	jb     2a19026 <wasm[0]::function[1015]::helper::object_read+0x1aec6>
 2a01fb7:	add    %r8d,%ecx
 2a01fba:	jb     2a19028 <wasm[0]::function[1015]::helper::object_read+0x1aec8>
 2a01fc0:	mov    %ecx,%r9d
 2a01fc3:	lea    (%rsi,%r9,1),%rcx
 2a01fc7:	cmp    %rdx,%r9
 2a01fca:	cmova  %rdi,%rcx
 2a01fce:	lea    0x14(%r12),%edx
 2a01fd3:	sub    %edx,%r8d
 2a01fd6:	sub    %r8,%rcx
 2a01fd9:	mov    %eax,(%rcx)
 2a01fdb:	mov    0x148(%rsp),%eax
 2a01fe2:	mov    0x90(%rsp),%edx
 2a01fe9:	mov    0x128(%rsp),%esi
 2a01ff0:	mov    0x110(%rsp),%edi
 2a01ff7:	mov    0x88(%rsp),%r8d
 2a01fff:	mov    0x100(%rsp),%r9d
 2a02007:	mov    0xd0(%rsp),%r10d
 2a0200f:	mov    0x140(%rsp),%r11d
 2a02017:	mov    0xc0(%rsp),%ecx
 2a0201e:	add    $0x1,%r15d
 2a02025:	jmp    2a01db5 <wasm[0]::function[1015]::helper::object_read+0x3c55>
 2a0202a:	mov    0x148(%rsp),%r11d
 2a02032:	test   %r11d,%r11d
 2a02035:	je     2a1902a <wasm[0]::function[1015]::helper::object_read+0x1aeca>
 2a0203b:	mov    0xe8(%rsp),%ecx
 2a02042:	test   %ecx,%ecx
 2a02044:	je     2a1902c <wasm[0]::function[1015]::helper::object_read+0x1aecc>
 2a0204a:	test   %r11d,%r11d
 2a0204d:	je     2a1902e <wasm[0]::function[1015]::helper::object_read+0x1aece>
 2a02053:	mov    0x2e0(%rsp),%r14
 2a0205b:	mov    0x28(%r14),%rdx
 2a0205f:	mov    0x20(%r14),%rax
 2a02063:	mov    %r11d,%esi
 2a02066:	add    %rsi,%rax
 2a02069:	xor    %rdi,%rdi
 2a0206c:	cmp    %rdx,%rsi
 2a0206f:	cmova  %rdi,%rax
 2a02073:	mov    %ecx,0x20(%rax)
 2a02076:	mov    0x190(%rsp),%rcx
 2a0207e:	mov    0xa00(%rcx),%edx
 2a02084:	mov    0xa10(%rcx),%ecx
 2a0208a:	test   %edx,%edx
 2a0208c:	je     2a19030 <wasm[0]::function[1015]::helper::object_read+0x1aed0>
 2a02092:	mov    %edx,0x28(%rax)
 2a02095:	test   %ecx,%ecx
 2a02097:	je     2a19032 <wasm[0]::function[1015]::helper::object_read+0x1aed2>
 2a0209d:	mov    %ecx,0x2c(%rax)
 2a020a0:	movl   $0x0,0x30(%rax)
 2a020a7:	movl   $0x0,0x24(%rax)
 2a020ae:	mov    0x90(%rsp),%edx
 2a020b5:	mov    0x128(%rsp),%ecx
 2a020bc:	mov    %rcx,0x1e8(%rsp)
 2a020c4:	mov    0x110(%rsp),%esi
 2a020cb:	mov    %rsi,0x1f0(%rsp)
 2a020d3:	mov    0x88(%rsp),%edi
 2a020da:	mov    %rdi,0x1f8(%rsp)
 2a020e2:	mov    0x100(%rsp),%edi
 2a020e9:	mov    0xd0(%rsp),%r8d
 2a020f1:	mov    0x140(%rsp),%r9d
 2a020f9:	mov    0xc0(%rsp),%r10d
 2a02101:	test   %r11d,%r11d
 2a02104:	je     2a19034 <wasm[0]::function[1015]::helper::object_read+0x1aed4>
 2a0210a:	test   %r11d,%r11d
 2a0210d:	je     2a19036 <wasm[0]::function[1015]::helper::object_read+0x1aed6>
 2a02113:	mov    0x2e0(%rsp),%r14
 2a0211b:	mov    0x28(%r14),%rax
 2a0211f:	mov    0x20(%r14),%r13
 2a02123:	mov    %r11d,%r11d
 2a02126:	lea    0x0(%r13,%r11,1),%r12
 2a0212b:	xor    %r14,%r14
 2a0212e:	cmp    %rax,%r11
 2a02131:	cmova  %r14,%r12
 2a02135:	mov    0x10(%r12),%ebx
 2a0213a:	test   %ebx,%ebx
 2a0213c:	je     2a19038 <wasm[0]::function[1015]::helper::object_read+0x1aed8>
 2a02142:	test   %ebx,%ebx
 2a02144:	je     2a1903a <wasm[0]::function[1015]::helper::object_read+0x1aeda>
 2a0214a:	mov    %ebx,%ecx
 2a0214c:	lea    0x10(%r13,%rcx,1),%r13
 2a02151:	cmp    %rax,%rcx
 2a02154:	cmova  %r14,%r13
 2a02158:	mov    0x0(%r13),%eax
 2a0215c:	mov    0x24(%r12),%esi
 2a02161:	test   %esi,%esi
 2a02163:	je     2a02410 <wasm[0]::function[1015]::helper::object_read+0x42b0>
 2a02169:	xor    %r11d,%r11d
 2a0216c:	test   %eax,%eax
 2a0216e:	je     2a02403 <wasm[0]::function[1015]::helper::object_read+0x42a3>
 2a02174:	mov    0x2e0(%rsp),%r14
 2a0217c:	mov    0x28(%r14),%r11
 2a02180:	mov    0x20(%r14),%r14
 2a02184:	lea    0x10(%r14,%rcx,1),%r13
 2a02189:	xor    %r12,%r12
 2a0218c:	cmp    %r11,%rcx
 2a0218f:	cmova  %r12,%r13
 2a02193:	mov    0x0(%r13),%r13d
 2a02197:	mov    0x1e0(%rsp),%r15
 2a0219f:	mov    %r15,%rcx
 2a021a2:	shr    $0x10,%ecx
 2a021a5:	mov    %r15,%rsi
 2a021a8:	xor    %ecx,%esi
 2a021aa:	imul   $0x7feb352d,%esi,%ecx
 2a021b0:	mov    %rcx,%rsi
 2a021b3:	shr    $0xf,%esi
 2a021b6:	xor    %esi,%ecx
 2a021b8:	imul   $0x846ca68b,%ecx,%ecx
 2a021be:	mov    %rcx,%rsi
 2a021c1:	shr    $0x10,%esi
 2a021c4:	xor    %esi,%ecx
 2a021c6:	sub    $0x1,%eax
 2a021c9:	and    %eax,%ecx
 2a021cb:	cmp    %r13d,%ecx
 2a021ce:	jae    2a1903c <wasm[0]::function[1015]::helper::object_read+0x1aedc>
 2a021d4:	mov    %r13d,%eax
 2a021d7:	shl    $0x2,%rax
 2a021db:	shr    $0x20,%rax
 2a021df:	test   %rax,%rax
 2a021e2:	jne    2a1903e <wasm[0]::function[1015]::helper::object_read+0x1aede>
 2a021e8:	shl    $0x2,%r13d
 2a021ec:	add    $0x14,%r13d
 2a021f0:	jb     2a19040 <wasm[0]::function[1015]::helper::object_read+0x1aee0>
 2a021f6:	add    %r13d,%ebx
 2a021f9:	jb     2a19042 <wasm[0]::function[1015]::helper::object_read+0x1aee2>
 2a021ff:	mov    %ebx,%esi
 2a02201:	lea    (%r14,%rsi,1),%rax
 2a02205:	cmp    %r11,%rsi
 2a02208:	cmova  %r12,%rax
 2a0220c:	shl    $0x2,%ecx
 2a0220f:	lea    0x14(%rcx),%esi
 2a02212:	sub    %esi,%r13d
 2a02215:	sub    %r13,%rax
 2a02218:	mov    (%rax),%eax
 2a0221a:	xor    %ecx,%ecx
 2a0221c:	mov    %r15d,%r12d
 2a0221f:	mov    %eax,0xe8(%rsp)
 2a02226:	mov    %ecx,0xc0(%rsp)
 2a0222d:	mov    %edx,0x140(%rsp)
 2a02234:	mov    0x1e8(%rsp),%rcx
 2a0223c:	mov    %ecx,0xd0(%rsp)
 2a02243:	mov    0x1f0(%rsp),%rsi
 2a0224b:	mov    %esi,0x100(%rsp)
 2a02252:	mov    0x1f8(%rsp),%rax
 2a0225a:	mov    %eax,0x88(%rsp)
 2a02261:	mov    %edi,0x110(%rsp)
 2a02268:	mov    %r8d,0x128(%rsp)
 2a02270:	mov    %r9d,0x90(%rsp)
 2a02278:	mov    %r10d,0x148(%rsp)
 2a02280:	mov    0x2e8(%rsp),%r15
 2a02288:	mov    (%r15),%rax
 2a0228b:	mov    0x228(%rsp),%rcx
 2a02293:	cmp    %rcx,%rax
 2a02296:	jae    2a17ade <wasm[0]::function[1015]::helper::object_read+0x1997e>
 2a0229c:	mov    0xe8(%rsp),%eax
 2a022a3:	mov    0xc0(%rsp),%r11d
 2a022ab:	test   %eax,%eax
 2a022ad:	je     2a023b0 <wasm[0]::function[1015]::helper::object_read+0x4250>
 2a022b3:	mov    0xe8(%rsp),%ecx
 2a022ba:	test   %ecx,%ecx
 2a022bc:	je     2a19044 <wasm[0]::function[1015]::helper::object_read+0x1aee4>
 2a022c2:	mov    0x2e0(%rsp),%r14
 2a022ca:	mov    0x28(%r14),%rax
 2a022ce:	mov    %ecx,%edx
 2a022d0:	mov    %rdx,%rcx
 2a022d3:	add    0x20(%r14),%rcx
 2a022d7:	xor    %rsi,%rsi
 2a022da:	cmp    %rax,%rdx
 2a022dd:	cmova  %rsi,%rcx
 2a022e1:	mov    0x10(%rcx),%rax
 2a022e5:	cmp    %r12,%rax
 2a022e8:	je     2a0237e <wasm[0]::function[1015]::helper::object_read+0x421e>
 2a022ee:	mov    0xe8(%rsp),%ecx
 2a022f5:	test   %ecx,%ecx
 2a022f7:	je     2a19046 <wasm[0]::function[1015]::helper::object_read+0x1aee6>
 2a022fd:	mov    0x2e0(%rsp),%r14
 2a02305:	mov    0x28(%r14),%rax
 2a02309:	mov    %ecx,%edx
 2a0230b:	mov    %rdx,%rcx
 2a0230e:	add    0x20(%r14),%rcx
 2a02312:	xor    %rsi,%rsi
 2a02315:	cmp    %rax,%rdx
 2a02318:	cmova  %rsi,%rcx
 2a0231c:	mov    0x1c(%rcx),%eax
 2a0231f:	mov    0xc0(%rsp),%ecx
 2a02326:	mov    0x140(%rsp),%edx
 2a0232d:	mov    0xd0(%rsp),%esi
 2a02334:	mov    %rsi,0x1e8(%rsp)
 2a0233c:	mov    0x100(%rsp),%esi
 2a02343:	mov    %rsi,0x1f0(%rsp)
 2a0234b:	mov    0x88(%rsp),%edi
 2a02352:	mov    %rdi,0x1f8(%rsp)
 2a0235a:	mov    0x110(%rsp),%edi
 2a02361:	mov    0x128(%rsp),%r8d
 2a02369:	mov    0x90(%rsp),%r9d
 2a02371:	mov    0x148(%rsp),%r10d
 2a02379:	jmp    2a0221f <wasm[0]::function[1015]::helper::object_read+0x40bf>
 2a0237e:	mov    0xe8(%rsp),%ecx
 2a02385:	test   %ecx,%ecx
 2a02387:	je     2a19048 <wasm[0]::function[1015]::helper::object_read+0x1aee8>
 2a0238d:	mov    0x2e0(%rsp),%r14
 2a02395:	mov    0x28(%r14),%rax
 2a02399:	mov    %ecx,%edx
 2a0239b:	mov    %rdx,%rcx
 2a0239e:	add    0x20(%r14),%rcx
 2a023a2:	xor    %rsi,%rsi
 2a023a5:	cmp    %rax,%rdx
 2a023a8:	cmova  %rsi,%rcx
 2a023ac:	mov    0x18(%rcx),%r11d
 2a023b0:	mov    0x140(%rsp),%edx
 2a023b7:	mov    0xd0(%rsp),%ecx
 2a023be:	mov    %rcx,0x1e8(%rsp)
 2a023c6:	mov    0x100(%rsp),%esi
 2a023cd:	mov    %rsi,0x1f0(%rsp)
 2a023d5:	mov    0x88(%rsp),%edi
 2a023dc:	mov    %rdi,0x1f8(%rsp)
 2a023e4:	mov    0x110(%rsp),%edi
 2a023eb:	mov    0x128(%rsp),%r8d
 2a023f3:	mov    0x90(%rsp),%r9d
 2a023fb:	mov    0x148(%rsp),%r10d
 2a02403:	mov    0x1e8(%rsp),%rcx
 2a0240b:	jmp    2a024e7 <wasm[0]::function[1015]::helper::object_read+0x4387>
 2a02410:	mov    0x2e0(%rsp),%r14
 2a02418:	mov    0x1e0(%rsp),%r15
 2a02420:	mov    0x28(%r14),%rax
 2a02424:	mov    0x20(%r14),%r12
 2a02428:	lea    (%r12,%r11,1),%rbx
 2a0242c:	xor    %rcx,%rcx
 2a0242f:	cmp    %rax,%r11
 2a02432:	cmova  %rcx,%rbx
 2a02436:	mov    0x20(%rbx),%ebx
 2a02439:	xor    %r11d,%r11d
 2a0243c:	test   %ebx,%ebx
 2a0243e:	je     2a1904a <wasm[0]::function[1015]::helper::object_read+0x1aeea>
 2a02444:	test   %ebx,%ebx
 2a02446:	je     2a1904c <wasm[0]::function[1015]::helper::object_read+0x1aeec>
 2a0244c:	mov    %ebx,%r13d
 2a0244f:	lea    0x10(%r12,%r13,1),%r12
 2a02454:	cmp    %rax,%r13
 2a02457:	cmova  %rcx,%r12
 2a0245b:	mov    %r15d,%eax
 2a0245e:	mov    (%r12),%ecx
 2a02462:	cmp    %rcx,%rax
 2a02465:	jae    2a024df <wasm[0]::function[1015]::helper::object_read+0x437f>
 2a0246b:	mov    0x2e0(%rsp),%r14
 2a02473:	mov    0x28(%r14),%rax
 2a02477:	mov    0x20(%r14),%r12
 2a0247b:	lea    0x10(%r12,%r13,1),%r11
 2a02480:	xor    %rcx,%rcx
 2a02483:	cmp    %rax,%r13
 2a02486:	cmova  %rcx,%r11
 2a0248a:	mov    (%r11),%r11d
 2a0248d:	cmp    %r11d,%r15d
 2a02490:	jae    2a1904e <wasm[0]::function[1015]::helper::object_read+0x1aeee>
 2a02496:	mov    %r11d,%r13d
 2a02499:	shl    $0x2,%r13
 2a0249d:	shr    $0x20,%r13
 2a024a1:	test   %r13,%r13
 2a024a4:	jne    2a19050 <wasm[0]::function[1015]::helper::object_read+0x1aef0>
 2a024aa:	shl    $0x2,%r11d
 2a024ae:	add    $0x14,%r11d
 2a024b2:	jb     2a19052 <wasm[0]::function[1015]::helper::object_read+0x1aef2>
 2a024b8:	add    %r11d,%ebx
 2a024bb:	jb     2a19054 <wasm[0]::function[1015]::helper::object_read+0x1aef4>
 2a024c1:	mov    %ebx,%esi
 2a024c3:	lea    (%r12,%rsi,1),%rbx
 2a024c7:	cmp    %rax,%rsi
 2a024ca:	cmova  %rcx,%rbx
 2a024ce:	shl    $0x2,%r15d
 2a024d2:	lea    0x14(%r15),%eax
 2a024d6:	sub    %eax,%r11d
 2a024d9:	sub    %r11,%rbx
 2a024dc:	mov    (%rbx),%r11d
 2a024df:	mov    0x1e8(%rsp),%rcx
 2a024e7:	mov    %ecx,0x90(%rsp)
 2a024ee:	mov    0x1f0(%rsp),%rsi
 2a024f6:	mov    %esi,0x128(%rsp)
 2a024fd:	mov    0x1f8(%rsp),%rax
 2a02505:	mov    %eax,0x110(%rsp)
 2a0250c:	mov    %edi,0x88(%rsp)
 2a02513:	mov    %r8d,0x100(%rsp)
 2a0251b:	mov    %r9d,0xd0(%rsp)
 2a02523:	mov    %r10d,0x140(%rsp)
 2a0252b:	xor    %r10d,%r10d
 2a0252e:	xor    %rcx,%rcx
 2a02531:	test   %r11d,%r11d
 2a02534:	jne    2a02542 <wasm[0]::function[1015]::helper::object_read+0x43e2>
 2a0253a:	mov    %r10,%rdi
 2a0253d:	jmp    2a026e5 <wasm[0]::function[1015]::helper::object_read+0x4585>
 2a02542:	xor    %r10d,%r10d
 2a02545:	test   %r11d,%r11d
 2a02548:	je     2a19056 <wasm[0]::function[1015]::helper::object_read+0x1aef6>
 2a0254e:	test   %r11d,%r11d
 2a02551:	je     2a19058 <wasm[0]::function[1015]::helper::object_read+0x1aef8>
 2a02557:	mov    0x2e0(%rsp),%r14
 2a0255f:	mov    0x28(%r14),%rax
 2a02563:	mov    %r11d,%r11d
 2a02566:	mov    %r11,%rdi
 2a02569:	add    0x20(%r14),%rdi
 2a0256d:	xor    %rcx,%rcx
 2a02570:	cmp    %rax,%r11
 2a02573:	cmova  %rcx,%rdi
 2a02577:	mov    0x10(%rdi),%eax
 2a0257a:	test   $0x1,%eax
 2a0257f:	je     2a0258d <wasm[0]::function[1015]::helper::object_read+0x442d>
 2a02585:	mov    %r10,%rdi
 2a02588:	jmp    2a026e5 <wasm[0]::function[1015]::helper::object_read+0x4585>
 2a0258d:	mov    0x2e0(%rsp),%r14
 2a02595:	mov    0x28(%r14),%rax
 2a02599:	mov    0x20(%r14),%rcx
 2a0259d:	add    %r11,%rcx
 2a025a0:	xor    %rdx,%rdx
 2a025a3:	cmp    %rax,%r11
 2a025a6:	cmova  %rdx,%rcx
 2a025aa:	mov    0x14(%rcx),%edx
 2a025ad:	test   %edx,%edx
 2a025af:	je     2a1905a <wasm[0]::function[1015]::helper::object_read+0x1aefa>
 2a025b5:	xor    %esi,%esi
 2a025b7:	test   $0x1,%edx
 2a025bd:	jne    2a025ff <wasm[0]::function[1015]::helper::object_read+0x449f>
 2a025c3:	mov    0x2e0(%rsp),%r14
 2a025cb:	mov    0x28(%r14),%rax
 2a025cf:	mov    0x20(%r14),%rcx
 2a025d3:	mov    %edx,%esi
 2a025d5:	lea    0x4(%rcx,%rsi,1),%rcx
 2a025da:	xor    %rdi,%rdi
 2a025dd:	cmp    %rax,%rsi
 2a025e0:	cmova  %rdi,%rcx
 2a025e4:	mov    (%rcx),%eax
 2a025e6:	mov    0x190(%rsp),%rcx
 2a025ee:	mov    0x28(%rcx),%rcx
 2a025f2:	cmp    0x120(%rcx),%eax
 2a025f8:	sete   %al
 2a025fb:	rex movzbl %al,%esi
 2a025ff:	test   %esi,%esi
 2a02601:	jne    2a0265b <wasm[0]::function[1015]::helper::object_read+0x44fb>
 2a02607:	mov    0x190(%rsp),%rsi
 2a0260f:	mov    0x190(%rsp),%rdi
 2a02617:	call   2a1eec0 <wasm[0]::function[1024]::helper::property_value_resolve>
 2a0261c:	test   %eax,%eax
 2a0261e:	je     2a1905c <wasm[0]::function[1015]::helper::object_read+0x1aefc>
 2a02624:	test   %eax,%eax
 2a02626:	je     2a1905e <wasm[0]::function[1015]::helper::object_read+0x1aefe>
 2a0262c:	mov    0x2e0(%rsp),%r14
 2a02634:	mov    0x28(%r14),%rcx
 2a02638:	mov    0x20(%r14),%rsi
 2a0263c:	mov    %eax,%edx
 2a0263e:	lea    (%rsi,%rdx,1),%rax
 2a02642:	xor    %rsi,%rsi
 2a02645:	cmp    %rcx,%rdx
 2a02648:	cmova  %rsi,%rax
 2a0264c:	mov    0x18(%rax),%edi
 2a0264f:	mov    0x10(%rax),%rcx
 2a02653:	mov    0x1c(%rax),%edx
 2a02656:	jmp    2a026dd <wasm[0]::function[1015]::helper::object_read+0x457d>
 2a0265b:	xor    %eax,%eax
 2a0265d:	test   $0x1,%edx
 2a02663:	jne    2a026a4 <wasm[0]::function[1015]::helper::object_read+0x4544>
 2a02669:	mov    0x2e0(%rsp),%r14
 2a02671:	mov    0x28(%r14),%rax
 2a02675:	mov    0x20(%r14),%rcx
 2a02679:	mov    %edx,%esi
 2a0267b:	lea    0x4(%rcx,%rsi,1),%rcx
 2a02680:	xor    %rdi,%rdi
 2a02683:	cmp    %rax,%rsi
 2a02686:	cmova  %rdi,%rcx
 2a0268a:	mov    (%rcx),%eax
 2a0268c:	mov    0x190(%rsp),%rcx
 2a02694:	mov    0x28(%rcx),%rcx
 2a02698:	cmp    0x120(%rcx),%eax
 2a0269e:	sete   %al
 2a026a1:	movzbl %al,%eax
 2a026a4:	test   %eax,%eax
 2a026a6:	je     2a19060 <wasm[0]::function[1015]::helper::object_read+0x1af00>
 2a026ac:	test   %edx,%edx
 2a026ae:	je     2a19062 <wasm[0]::function[1015]::helper::object_read+0x1af02>
 2a026b4:	mov    0x2e0(%rsp),%r14
 2a026bc:	mov    0x28(%r14),%rcx
 2a026c0:	mov    0x20(%r14),%rax
 2a026c4:	mov    %edx,%edx
 2a026c6:	add    %rdx,%rax
 2a026c9:	xor    %rsi,%rsi
 2a026cc:	cmp    %rcx,%rdx
 2a026cf:	cmova  %rsi,%rax
 2a026d3:	mov    0x18(%rax),%edi
 2a026d6:	mov    0x10(%rax),%rcx
 2a026da:	mov    0x1c(%rax),%edx
 2a026dd:	mov    0x278(%rsp),%r10
 2a026e5:	mov    0x90(%rsp),%eax
 2a026ec:	mov    0x128(%rsp),%r8d
 2a026f4:	mov    0x110(%rsp),%r9d
 2a026fc:	mov    0x88(%rsp),%r11d
 2a02704:	mov    0x100(%rsp),%r12d
 2a0270c:	mov    0xd0(%rsp),%r13d
 2a02714:	mov    0x140(%rsp),%esi
 2a0271b:	jmp    2a02b47 <wasm[0]::function[1015]::helper::object_read+0x49e7>
 2a02720:	mov    0x2e0(%rsp),%r14
 2a02728:	mov    0x1e0(%rsp),%r15
 2a02730:	mov    0x28(%r14),%rcx
 2a02734:	mov    %rsi,%rax
 2a02737:	add    0x20(%r14),%rax
 2a0273b:	xor    %rdx,%rdx
 2a0273e:	cmp    %rcx,%rsi
 2a02741:	cmova  %rdx,%rax
 2a02745:	mov    0x24(%rax),%eax
 2a02748:	cmp    $0x3,%eax
 2a0274b:	je     2a029ec <wasm[0]::function[1015]::helper::object_read+0x488c>
 2a02751:	mov    0x2e0(%rsp),%r14
 2a02759:	mov    0x28(%r14),%rcx
 2a0275d:	mov    %rsi,%rax
 2a02760:	add    0x20(%r14),%rax
 2a02764:	xor    %rdx,%rdx
 2a02767:	cmp    %rcx,%rsi
 2a0276a:	cmova  %rdx,%rax
 2a0276e:	mov    0x24(%rax),%eax
 2a02771:	cmp    $0x4,%eax
 2a02774:	je     2a02908 <wasm[0]::function[1015]::helper::object_read+0x47a8>
 2a0277a:	mov    0x2e0(%rsp),%r14
 2a02782:	mov    0x28(%r14),%rax
 2a02786:	mov    0x20(%r14),%rdx
 2a0278a:	lea    (%rdx,%rsi,1),%r8
 2a0278e:	xor    %rcx,%rcx
 2a02791:	cmp    %rax,%rsi
 2a02794:	cmova  %rcx,%r8
 2a02798:	mov    0x28(%r8),%esi
 2a0279c:	mov    0x2c(%r8),%r9d
 2a027a0:	xor    %r10d,%r10d
 2a027a3:	test   %esi,%esi
 2a027a5:	je     2a19064 <wasm[0]::function[1015]::helper::object_read+0x1af04>
 2a027ab:	test   %esi,%esi
 2a027ad:	je     2a19066 <wasm[0]::function[1015]::helper::object_read+0x1af06>
 2a027b3:	mov    %esi,%r8d
 2a027b6:	lea    0x10(%rdx,%r8,1),%rdx
 2a027bb:	cmp    %rax,%r8
 2a027be:	cmova  %rcx,%rdx
 2a027c2:	mov    (%rdx),%eax
 2a027c4:	mov    0xa0(%rsp),%edx
 2a027cb:	mov    %r15d,%r11d
 2a027ce:	mov    %eax,%eax
 2a027d0:	cmp    %rax,%r11
 2a027d3:	jb     2a027e1 <wasm[0]::function[1015]::helper::object_read+0x4681>
 2a027d9:	mov    %r10,%rdi
 2a027dc:	jmp    2a02b1a <wasm[0]::function[1015]::helper::object_read+0x49ba>
 2a027e1:	xor    %r10d,%r10d
 2a027e4:	test   %r9d,%r9d
 2a027e7:	je     2a19068 <wasm[0]::function[1015]::helper::object_read+0x1af08>
 2a027ed:	test   %r9d,%r9d
 2a027f0:	je     2a1906a <wasm[0]::function[1015]::helper::object_read+0x1af0a>
 2a027f6:	mov    0x2e0(%rsp),%r14
 2a027fe:	mov    0x28(%r14),%r11
 2a02802:	mov    0x20(%r14),%rax
 2a02806:	mov    %r9d,%r12d
 2a02809:	lea    0x10(%rax,%r12,1),%rdx
 2a0280e:	xor    %rcx,%rcx
 2a02811:	cmp    %r11,%r12
 2a02814:	cmova  %rcx,%rdx
 2a02818:	mov    (%rdx),%edx
 2a0281a:	mov    %r15,%rbx
 2a0281d:	shr    $0x6,%ebx
 2a02820:	cmp    %edx,%ebx
 2a02822:	jae    2a1906c <wasm[0]::function[1015]::helper::object_read+0x1af0c>
 2a02828:	mov    %edx,%r12d
 2a0282b:	shl    $0x3,%r12
 2a0282f:	shr    $0x20,%r12
 2a02833:	test   %r12,%r12
 2a02836:	jne    2a1906e <wasm[0]::function[1015]::helper::object_read+0x1af0e>
 2a0283c:	shl    $0x3,%edx
 2a0283f:	add    $0x18,%edx
 2a02842:	jb     2a19070 <wasm[0]::function[1015]::helper::object_read+0x1af10>
 2a02848:	add    %edx,%r9d
 2a0284b:	jb     2a19072 <wasm[0]::function[1015]::helper::object_read+0x1af12>
 2a02851:	mov    %r9d,%r12d
 2a02854:	lea    (%rax,%r12,1),%r9
 2a02858:	cmp    %r11,%r12
 2a0285b:	cmova  %rcx,%r9
 2a0285f:	shl    $0x3,%ebx
 2a02862:	lea    0x18(%rbx),%eax
 2a02865:	sub    %eax,%edx
 2a02867:	sub    %rdx,%r9
 2a0286a:	mov    (%r9),%rax
 2a0286d:	mov    0xa0(%rsp),%edx
 2a02874:	bt     %r15,%rax
 2a02878:	jb     2a02886 <wasm[0]::function[1015]::helper::object_read+0x4726>
 2a0287e:	mov    %r10,%rdi
 2a02881:	jmp    2a02b1a <wasm[0]::function[1015]::helper::object_read+0x49ba>
 2a02886:	mov    0x2e0(%rsp),%r14
 2a0288e:	mov    0x28(%r14),%rax
 2a02892:	mov    0x20(%r14),%rdx
 2a02896:	lea    0x10(%rdx,%r8,1),%r9
 2a0289b:	xor    %rcx,%rcx
 2a0289e:	cmp    %rax,%r8
 2a028a1:	cmova  %rcx,%r9
 2a028a5:	mov    (%r9),%r8d
 2a028a8:	cmp    %r8d,%r15d
 2a028ab:	jae    2a19074 <wasm[0]::function[1015]::helper::object_read+0x1af14>
 2a028b1:	mov    %r8d,%r9d
 2a028b4:	shl    $0x3,%r9
 2a028b8:	shr    $0x20,%r9
 2a028bc:	test   %r9,%r9
 2a028bf:	jne    2a19076 <wasm[0]::function[1015]::helper::object_read+0x1af16>
 2a028c5:	shl    $0x3,%r8d
 2a028c9:	add    $0x18,%r8d
 2a028cd:	jb     2a19078 <wasm[0]::function[1015]::helper::object_read+0x1af18>
 2a028d3:	add    %r8d,%esi
 2a028d6:	jb     2a1907a <wasm[0]::function[1015]::helper::object_read+0x1af1a>
 2a028dc:	mov    %esi,%esi
 2a028de:	add    %rsi,%rdx
 2a028e1:	cmp    %rax,%rsi
 2a028e4:	cmova  %rcx,%rdx
 2a028e8:	shl    $0x3,%r15d
 2a028ec:	lea    0x18(%r15),%eax
 2a028f0:	sub    %eax,%r8d
 2a028f3:	sub    %r8,%rdx
 2a028f6:	mov    (%rdx),%rcx
 2a028f9:	xor    %edx,%edx
 2a028fb:	mov    0x278(%rsp),%r10
 2a02903:	jmp    2a02b1a <wasm[0]::function[1015]::helper::object_read+0x49ba>
 2a02908:	mov    0x2e0(%rsp),%r14
 2a02910:	mov    0x28(%r14),%rdx
 2a02914:	mov    %rsi,%rax
 2a02917:	add    0x20(%r14),%rax
 2a0291b:	xor    %rcx,%rcx
 2a0291e:	cmp    %rdx,%rsi
 2a02921:	cmova  %rcx,%rax
 2a02925:	mov    0x18(%rax),%rax
 2a02929:	mov    0xa0(%rsp),%edx
 2a02930:	mov    %r15d,%r8d
 2a02933:	xor    %r10d,%r10d
 2a02936:	cmp    %rax,%r8
 2a02939:	jb     2a02947 <wasm[0]::function[1015]::helper::object_read+0x47e7>
 2a0293f:	mov    %r10,%rdi
 2a02942:	jmp    2a02b1a <wasm[0]::function[1015]::helper::object_read+0x49ba>
 2a02947:	mov    0x2e0(%rsp),%r14
 2a0294f:	mov    0x28(%r14),%rax
 2a02953:	mov    0x20(%r14),%r8
 2a02957:	lea    (%r8,%rsi,1),%rdx
 2a0295b:	xor    %rcx,%rcx
 2a0295e:	cmp    %rax,%rsi
 2a02961:	cmova  %rcx,%rdx
 2a02965:	mov    0x28(%rdx),%esi
 2a02968:	xor    %edx,%edx
 2a0296a:	test   %esi,%esi
 2a0296c:	je     2a1907c <wasm[0]::function[1015]::helper::object_read+0x1af1c>
 2a02972:	test   %esi,%esi
 2a02974:	je     2a1907e <wasm[0]::function[1015]::helper::object_read+0x1af1e>
 2a0297a:	mov    %esi,%r10d
 2a0297d:	lea    0x10(%r8,%r10,1),%r9
 2a02982:	cmp    %rax,%r10
 2a02985:	cmova  %rcx,%r9
 2a02989:	mov    (%r9),%r9d
 2a0298c:	cmp    %r9d,%r15d
 2a0298f:	jae    2a19080 <wasm[0]::function[1015]::helper::object_read+0x1af20>
 2a02995:	mov    %r9d,%r10d
 2a02998:	shl    $0x3,%r10
 2a0299c:	shr    $0x20,%r10
 2a029a0:	test   %r10,%r10
 2a029a3:	jne    2a19082 <wasm[0]::function[1015]::helper::object_read+0x1af22>
 2a029a9:	shl    $0x3,%r9d
 2a029ad:	add    $0x18,%r9d
 2a029b1:	jb     2a19084 <wasm[0]::function[1015]::helper::object_read+0x1af24>
 2a029b7:	add    %r9d,%esi
 2a029ba:	jb     2a19086 <wasm[0]::function[1015]::helper::object_read+0x1af26>
 2a029c0:	mov    %esi,%r10d
 2a029c3:	lea    (%r8,%r10,1),%rsi
 2a029c7:	cmp    %rax,%r10
 2a029ca:	cmova  %rcx,%rsi
 2a029ce:	shl    $0x3,%r15d
 2a029d2:	lea    0x18(%r15),%eax
 2a029d6:	sub    %eax,%r9d
 2a029d9:	sub    %r9,%rsi
 2a029dc:	mov    (%rsi),%rcx
 2a029df:	mov    0x278(%rsp),%r10
 2a029e7:	jmp    2a02b1a <wasm[0]::function[1015]::helper::object_read+0x49ba>
 2a029ec:	mov    0x2e0(%rsp),%r14
 2a029f4:	mov    0x28(%r14),%rdx
 2a029f8:	mov    0x20(%r14),%rdi
 2a029fc:	lea    (%rdi,%rsi,1),%rax
 2a02a00:	xor    %rcx,%rcx
 2a02a03:	cmp    %rdx,%rsi
 2a02a06:	cmova  %rcx,%rax
 2a02a0a:	mov    0x30(%rax),%eax
 2a02a0d:	xor    %r10d,%r10d
 2a02a10:	test   %eax,%eax
 2a02a12:	je     2a19088 <wasm[0]::function[1015]::helper::object_read+0x1af28>
 2a02a18:	test   %eax,%eax
 2a02a1a:	je     2a1908a <wasm[0]::function[1015]::helper::object_read+0x1af2a>
 2a02a20:	mov    %eax,%esi
 2a02a22:	lea    0x10(%rdi,%rsi,1),%rdi
 2a02a27:	cmp    %rdx,%rsi
 2a02a2a:	cmova  %rcx,%rdi
 2a02a2e:	mov    (%rdi),%edi
 2a02a30:	mov    0xa0(%rsp),%edx
 2a02a37:	mov    %r15d,%r8d
 2a02a3a:	mov    %edi,%edi
 2a02a3c:	cmp    %rdi,%r8
 2a02a3f:	jb     2a02a4d <wasm[0]::function[1015]::helper::object_read+0x48ed>
 2a02a45:	mov    %r10,%rdi
 2a02a48:	jmp    2a02b1a <wasm[0]::function[1015]::helper::object_read+0x49ba>
 2a02a4d:	mov    0x2e0(%rsp),%r14
 2a02a55:	mov    0x28(%r14),%rdx
 2a02a59:	mov    0x20(%r14),%rdi
 2a02a5d:	lea    0x10(%rdi,%rsi,1),%r8
 2a02a62:	xor    %rcx,%rcx
 2a02a65:	cmp    %rdx,%rsi
 2a02a68:	cmova  %rcx,%r8
 2a02a6c:	mov    (%r8),%esi
 2a02a6f:	cmp    %esi,%r15d
 2a02a72:	jae    2a1908c <wasm[0]::function[1015]::helper::object_read+0x1af2c>
 2a02a78:	mov    %esi,%r8d
 2a02a7b:	shl    $0x2,%r8
 2a02a7f:	shr    $0x20,%r8
 2a02a83:	test   %r8,%r8
 2a02a86:	jne    2a1908e <wasm[0]::function[1015]::helper::object_read+0x1af2e>
 2a02a8c:	shl    $0x2,%esi
 2a02a8f:	add    $0x14,%esi
 2a02a92:	jb     2a19090 <wasm[0]::function[1015]::helper::object_read+0x1af30>
 2a02a98:	add    %esi,%eax
 2a02a9a:	jb     2a19092 <wasm[0]::function[1015]::helper::object_read+0x1af32>
 2a02aa0:	mov    %eax,%r8d
 2a02aa3:	lea    (%rdi,%r8,1),%rax
 2a02aa7:	cmp    %rdx,%r8
 2a02aaa:	cmova  %rcx,%rax
 2a02aae:	shl    $0x2,%r15d
 2a02ab2:	lea    0x14(%r15),%edx
 2a02ab6:	sub    %edx,%esi
 2a02ab8:	sub    %rsi,%rax
 2a02abb:	mov    (%rax),%eax
 2a02abd:	mov    0xa0(%rsp),%edx
 2a02ac4:	xor    %r10d,%r10d
 2a02ac7:	test   %eax,%eax
 2a02ac9:	jne    2a02ad7 <wasm[0]::function[1015]::helper::object_read+0x4977>
 2a02acf:	mov    %r10,%rdi
 2a02ad2:	jmp    2a02b1a <wasm[0]::function[1015]::helper::object_read+0x49ba>
 2a02ad7:	test   %eax,%eax
 2a02ad9:	je     2a19094 <wasm[0]::function[1015]::helper::object_read+0x1af34>
 2a02adf:	test   %eax,%eax
 2a02ae1:	je     2a19096 <wasm[0]::function[1015]::helper::object_read+0x1af36>
 2a02ae7:	mov    0x2e0(%rsp),%r14
 2a02aef:	mov    0x28(%r14),%rdi
 2a02af3:	mov    0x20(%r14),%r9
 2a02af7:	mov    %eax,%r8d
 2a02afa:	lea    (%r9,%r8,1),%rsi
 2a02afe:	xor    %r9,%r9
 2a02b01:	cmp    %rdi,%r8
 2a02b04:	cmova  %r9,%rsi
 2a02b08:	mov    0x18(%rsi),%edi
 2a02b0b:	mov    0x10(%rsi),%rcx
 2a02b0f:	mov    0x1c(%rsi),%edx
 2a02b12:	mov    0x278(%rsp),%r10
 2a02b1a:	mov    0x48(%rsp),%eax
 2a02b1e:	mov    0x80(%rsp),%r8d
 2a02b26:	mov    0xa8(%rsp),%r9d
 2a02b2e:	mov    0xb8(%rsp),%r11d
 2a02b36:	mov    0x58(%rsp),%r12d
 2a02b3b:	mov    0x78(%rsp),%r13d
 2a02b40:	mov    0x108(%rsp),%esi
 2a02b47:	xor    %ebx,%ebx
 2a02b49:	test   %r10d,%r10d
 2a02b4c:	jne    2a02b72 <wasm[0]::function[1015]::helper::object_read+0x4a12>
 2a02b52:	mov    0x280(%rsp),%rdi
 2a02b5a:	mov    %rsi,%rdx
 2a02b5d:	mov    0x290(%rsp),%rsi
 2a02b65:	mov    0x288(%rsp),%rcx
 2a02b6d:	jmp    2a02b84 <wasm[0]::function[1015]::helper::object_read+0x4a24>
 2a02b72:	xor    %esi,%esi
 2a02b74:	mov    0x278(%rsp),%rbx
 2a02b7c:	mov    %rsi,0x298(%rsp)
 2a02b84:	mov    %rdi,0x280(%rsp)
 2a02b8c:	mov    %rcx,0x288(%rsp)
 2a02b94:	mov    %r8d,0x58(%rsp)
 2a02b99:	mov    %r9d,0xb8(%rsp)
 2a02ba1:	mov    %r11d,0xa8(%rsp)
 2a02ba9:	mov    %r12d,0x80(%rsp)
 2a02bb1:	mov    %r13d,0x48(%rsp)
 2a02bb6:	test   %eax,%eax
 2a02bb8:	jne    2a02bcb <wasm[0]::function[1015]::helper::object_read+0x4a6b>
 2a02bbe:	mov    0x288(%rsp),%rax
 2a02bc6:	jmp    2a02d86 <wasm[0]::function[1015]::helper::object_read+0x4c26>
 2a02bcb:	test   %eax,%eax
 2a02bcd:	je     2a19098 <wasm[0]::function[1015]::helper::object_read+0x1af38>
 2a02bd3:	test   %eax,%eax
 2a02bd5:	je     2a1909a <wasm[0]::function[1015]::helper::object_read+0x1af3a>
 2a02bdb:	mov    0x2e0(%rsp),%r14
 2a02be3:	mov    0x28(%r14),%rcx
 2a02be7:	mov    %eax,%eax
 2a02be9:	mov    %rax,%rdi
 2a02bec:	add    0x20(%r14),%rdi
 2a02bf0:	xor    %r8,%r8
 2a02bf3:	cmp    %rcx,%rax
 2a02bf6:	cmova  %r8,%rdi
 2a02bfa:	mov    0x10(%rdi),%ecx
 2a02bfd:	test   $0x1,%ecx
 2a02c03:	je     2a02c16 <wasm[0]::function[1015]::helper::object_read+0x4ab6>
 2a02c09:	mov    0x288(%rsp),%rax
 2a02c11:	jmp    2a02d86 <wasm[0]::function[1015]::helper::object_read+0x4c26>
 2a02c16:	mov    0x2e0(%rsp),%r14
 2a02c1e:	mov    0x28(%r14),%rcx
 2a02c22:	mov    0x20(%r14),%rdx
 2a02c26:	add    %rax,%rdx
 2a02c29:	xor    %rsi,%rsi
 2a02c2c:	cmp    %rcx,%rax
 2a02c2f:	cmova  %rsi,%rdx
 2a02c33:	mov    0x14(%rdx),%edx
 2a02c36:	test   %edx,%edx
 2a02c38:	je     2a1909c <wasm[0]::function[1015]::helper::object_read+0x1af3c>
 2a02c3e:	xor    %eax,%eax
 2a02c40:	test   $0x1,%edx
 2a02c46:	jne    2a02c87 <wasm[0]::function[1015]::helper::object_read+0x4b27>
 2a02c4c:	mov    0x2e0(%rsp),%r14
 2a02c54:	mov    0x28(%r14),%rax
 2a02c58:	mov    0x20(%r14),%rcx
 2a02c5c:	mov    %edx,%esi
 2a02c5e:	lea    0x4(%rcx,%rsi,1),%rcx
 2a02c63:	xor    %rdi,%rdi
 2a02c66:	cmp    %rax,%rsi
 2a02c69:	cmova  %rdi,%rcx
 2a02c6d:	mov    (%rcx),%eax
 2a02c6f:	mov    0x190(%rsp),%rcx
 2a02c77:	mov    0x28(%rcx),%rcx
 2a02c7b:	cmp    0x120(%rcx),%eax
 2a02c81:	sete   %al
 2a02c84:	movzbl %al,%eax
 2a02c87:	test   %eax,%eax
 2a02c89:	jne    2a02cea <wasm[0]::function[1015]::helper::object_read+0x4b8a>
 2a02c8f:	mov    0x190(%rsp),%rsi
 2a02c97:	mov    0x190(%rsp),%rdi
 2a02c9f:	call   2a1eec0 <wasm[0]::function[1024]::helper::property_value_resolve>
 2a02ca4:	test   %eax,%eax
 2a02ca6:	je     2a1909e <wasm[0]::function[1015]::helper::object_read+0x1af3e>
 2a02cac:	test   %eax,%eax
 2a02cae:	je     2a190a0 <wasm[0]::function[1015]::helper::object_read+0x1af40>
 2a02cb4:	mov    0x2e0(%rsp),%r14
 2a02cbc:	mov    0x28(%r14),%rdx
 2a02cc0:	mov    0x20(%r14),%rcx
 2a02cc4:	mov    %eax,%eax
 2a02cc6:	add    %rax,%rcx
 2a02cc9:	xor    %rsi,%rsi
 2a02ccc:	cmp    %rdx,%rax
 2a02ccf:	cmova  %rsi,%rcx
 2a02cd3:	mov    0x18(%rcx),%eax
 2a02cd6:	mov    %rax,0x280(%rsp)
 2a02cde:	mov    0x10(%rcx),%rax
 2a02ce2:	mov    0x1c(%rcx),%edx
 2a02ce5:	jmp    2a02d74 <wasm[0]::function[1015]::helper::object_read+0x4c14>
 2a02cea:	xor    %eax,%eax
 2a02cec:	test   $0x1,%edx
 2a02cf2:	jne    2a02d33 <wasm[0]::function[1015]::helper::object_read+0x4bd3>
 2a02cf8:	mov    0x2e0(%rsp),%r14
 2a02d00:	mov    0x28(%r14),%rax
 2a02d04:	mov    0x20(%r14),%rcx
 2a02d08:	mov    %edx,%esi
 2a02d0a:	lea    0x4(%rcx,%rsi,1),%rcx
 2a02d0f:	xor    %rdi,%rdi
 2a02d12:	cmp    %rax,%rsi
 2a02d15:	cmova  %rdi,%rcx
 2a02d19:	mov    (%rcx),%eax
 2a02d1b:	mov    0x190(%rsp),%rcx
 2a02d23:	mov    0x28(%rcx),%rcx
 2a02d27:	cmp    0x120(%rcx),%eax
 2a02d2d:	sete   %al
 2a02d30:	movzbl %al,%eax
 2a02d33:	test   %eax,%eax
 2a02d35:	je     2a190a2 <wasm[0]::function[1015]::helper::object_read+0x1af42>
 2a02d3b:	test   %edx,%edx
 2a02d3d:	je     2a190a4 <wasm[0]::function[1015]::helper::object_read+0x1af44>
 2a02d43:	mov    0x2e0(%rsp),%r14
 2a02d4b:	mov    0x28(%r14),%rax
 2a02d4f:	mov    0x20(%r14),%rcx
 2a02d53:	mov    %edx,%edx
 2a02d55:	add    %rdx,%rcx
 2a02d58:	xor    %rsi,%rsi
 2a02d5b:	cmp    %rax,%rdx
 2a02d5e:	cmova  %rsi,%rcx
 2a02d62:	mov    0x18(%rcx),%eax
 2a02d65:	mov    %rax,0x280(%rsp)
 2a02d6d:	mov    0x10(%rcx),%rax
 2a02d71:	mov    0x1c(%rcx),%edx
 2a02d74:	xor    %esi,%esi
 2a02d76:	mov    0x278(%rsp),%rbx
 2a02d7e:	mov    %rsi,0x298(%rsp)
 2a02d86:	mov    0x58(%rsp),%r10d
 2a02d8b:	mov    0xb8(%rsp),%r9d
 2a02d93:	mov    0xa8(%rsp),%r13d
 2a02d9b:	mov    %r13,0x208(%rsp)
 2a02da3:	mov    0x80(%rsp),%r13d
 2a02dab:	mov    0x48(%rsp),%edi
 2a02daf:	mov    %rax,0x288(%rsp)
 2a02db7:	jmp    2a02e5d <wasm[0]::function[1015]::helper::object_read+0x4cfd>
 2a02dbc:	xor    %edx,%edx
 2a02dbe:	mov    0x210(%rsp),%rax
 2a02dc6:	mov    0x210(%rsp),%rcx
 2a02dce:	test   %ecx,%eax
 2a02dd0:	je     2a190a6 <wasm[0]::function[1015]::helper::object_read+0x1af46>
 2a02dd6:	test   %ecx,%eax
 2a02dd8:	je     2a190a8 <wasm[0]::function[1015]::helper::object_read+0x1af48>
 2a02dde:	mov    0x2e0(%rsp),%r14
 2a02de6:	mov    0x28(%r14),%r8
 2a02dea:	mov    %eax,%r11d
 2a02ded:	mov    %r11,%rsi
 2a02df0:	add    0x20(%r14),%rsi
 2a02df4:	xor    %rax,%rax
 2a02df7:	cmp    %r8,%r11
 2a02dfa:	cmova  %rax,%rsi
 2a02dfe:	mov    0x18(%rsi),%r11
 2a02e02:	mov    $0x3,%eax
 2a02e07:	mov    %rax,0x280(%rsp)
 2a02e0f:	cmp    $0x0,%r11
 2a02e13:	jl     2a02e23 <wasm[0]::function[1015]::helper::object_read+0x4cc3>
 2a02e19:	cvtsi2sd %r11,%xmm7
 2a02e1e:	jmp    2a02e3d <wasm[0]::function[1015]::helper::object_read+0x4cdd>
 2a02e23:	mov    %r11,%r8
 2a02e26:	shr    $0x1,%r8
 2a02e2a:	mov    %r11,%rax
 2a02e2d:	and    $0x1,%rax
 2a02e31:	or     %r8,%rax
 2a02e34:	cvtsi2sd %rax,%xmm7
 2a02e39:	addsd  %xmm7,%xmm7
 2a02e3d:	movq   %xmm7,%rax
 2a02e42:	mov    %rax,0x288(%rsp)
 2a02e4a:	mov    0x278(%rsp),%rbx
 2a02e52:	mov    %rdx,%rsi
 2a02e55:	mov    %rdx,0x298(%rsp)
 2a02e5d:	mov    %r10,%rax
 2a02e60:	mov    %r10,0x210(%rsp)
 2a02e68:	mov    %eax,0x48(%rsp)
 2a02e6c:	mov    %r9d,0x80(%rsp)
 2a02e74:	mov    0x208(%rsp),%rax
 2a02e7c:	mov    %eax,0xa8(%rsp)
 2a02e83:	mov    %r13d,0xb8(%rsp)
 2a02e8b:	mov    %edi,0x58(%rsp)
 2a02e8f:	test   %ebx,%ebx
 2a02e91:	je     2a02ea4 <wasm[0]::function[1015]::helper::object_read+0x4d44>
 2a02e97:	mov    0x298(%rsp),%rdi
 2a02e9f:	jmp    2a0cf9a <wasm[0]::function[1015]::helper::object_read+0xee3a>
 2a02ea4:	xor    %eax,%eax
 2a02ea6:	movl   $0x0,0x78(%rsp)
 2a02eae:	mov    0x210(%rsp),%rcx
 2a02eb6:	mov    0x210(%rsp),%rdx
 2a02ebe:	test   %ecx,%edx
 2a02ec0:	je     2a02f1f <wasm[0]::function[1015]::helper::object_read+0x4dbf>
 2a02ec6:	xor    %eax,%eax
 2a02ec8:	mov    0x210(%rsp),%rdx
 2a02ed0:	test   $0x1,%edx
 2a02ed6:	jne    2a02f1f <wasm[0]::function[1015]::helper::object_read+0x4dbf>
 2a02edc:	mov    0x2e0(%rsp),%r14
 2a02ee4:	mov    0x28(%r14),%rax
 2a02ee8:	mov    0x20(%r14),%rdx
 2a02eec:	mov    0x210(%rsp),%rsi
 2a02ef4:	mov    %esi,%esi
 2a02ef6:	lea    0x4(%rdx,%rsi,1),%rdx
 2a02efb:	xor    %r8,%r8
 2a02efe:	cmp    %rax,%rsi
 2a02f01:	cmova  %r8,%rdx
 2a02f05:	mov    (%rdx),%eax
 2a02f07:	mov    0x190(%rsp),%rcx
 2a02f0f:	mov    0x28(%rcx),%rcx
 2a02f13:	cmp    0x138(%rcx),%eax
 2a02f19:	sete   %al
 2a02f1c:	movzbl %al,%eax
 2a02f1f:	test   %eax,%eax
 2a02f21:	jne    2a0c2ce <wasm[0]::function[1015]::helper::object_read+0xe16e>
 2a02f27:	xor    %esi,%esi
 2a02f29:	mov    0x210(%rsp),%rax
 2a02f31:	mov    0x210(%rsp),%rdx
 2a02f39:	test   %eax,%edx
 2a02f3b:	je     2a02f9b <wasm[0]::function[1015]::helper::object_read+0x4e3b>
 2a02f41:	xor    %esi,%esi
 2a02f43:	mov    0x210(%rsp),%rdx
 2a02f4b:	test   $0x1,%edx
 2a02f51:	jne    2a02f9b <wasm[0]::function[1015]::helper::object_read+0x4e3b>
 2a02f57:	mov    0x2e0(%rsp),%r14
 2a02f5f:	mov    0x28(%r14),%rax
 2a02f63:	mov    0x20(%r14),%rdx
 2a02f67:	mov    0x210(%rsp),%rcx
 2a02f6f:	mov    %ecx,%esi
 2a02f71:	lea    0x4(%rdx,%rsi,1),%rdx
 2a02f76:	xor    %r8,%r8
 2a02f79:	cmp    %rax,%rsi
 2a02f7c:	cmova  %r8,%rdx
 2a02f80:	mov    (%rdx),%eax
 2a02f82:	mov    0x190(%rsp),%rcx
 2a02f8a:	mov    0x28(%rcx),%rcx
 2a02f8e:	cmp    0x254(%rcx),%eax
 2a02f94:	sete   %al
 2a02f97:	rex movzbl %al,%esi
 2a02f9b:	test   %esi,%esi
 2a02f9d:	jne    2a09ad8 <wasm[0]::function[1015]::helper::object_read+0xb978>
 2a02fa3:	xor    %eax,%eax
 2a02fa5:	mov    0x208(%rsp),%rcx
 2a02fad:	mov    %rax,%rdx
 2a02fb0:	mov    0x208(%rsp),%rsi
 2a02fb8:	mov    %rax,%r8
 2a02fbb:	mov    %ecx,0x140(%rsp)
 2a02fc2:	mov    %eax,0xd0(%rsp)
 2a02fc9:	mov    %r8d,0x100(%rsp)
 2a02fd1:	mov    0x210(%rsp),%rax
 2a02fd9:	mov    %eax,0x88(%rsp)
 2a02fe0:	mov    %r9d,0x110(%rsp)
 2a02fe8:	mov    %esi,0x128(%rsp)
 2a02fef:	mov    %r13d,0x90(%rsp)
 2a02ff7:	mov    %edx,0xa0(%rsp)
 2a02ffe:	mov    %edi,0x108(%rsp)
 2a03005:	mov    0x2e8(%rsp),%r15
 2a0300d:	mov    (%r15),%rax
 2a03010:	mov    0x228(%rsp),%rdx
 2a03018:	cmp    %rdx,%rax
 2a0301b:	jae    2a17b15 <wasm[0]::function[1015]::helper::object_read+0x199b5>
 2a03021:	mov    0x140(%rsp),%ecx
 2a03028:	mov    0xd0(%rsp),%eax
 2a0302f:	test   %ecx,%ecx
 2a03031:	je     2a030f4 <wasm[0]::function[1015]::helper::object_read+0x4f94>
 2a03037:	mov    0x140(%rsp),%ecx
 2a0303e:	test   %ecx,%ecx
 2a03040:	je     2a190aa <wasm[0]::function[1015]::helper::object_read+0x1af4a>
 2a03046:	mov    0x2e0(%rsp),%r14
 2a0304e:	mov    0x28(%r14),%rax
 2a03052:	mov    0x20(%r14),%rsi
 2a03056:	mov    %ecx,%edx
 2a03058:	lea    (%rsi,%rdx,1),%rcx
 2a0305c:	xor    %rsi,%rsi
 2a0305f:	cmp    %rax,%rdx
 2a03062:	cmova  %rsi,%rcx
 2a03066:	mov    0x10(%rcx),%eax
 2a03069:	test   %eax,%eax
 2a0306b:	jne    2a030f4 <wasm[0]::function[1015]::helper::object_read+0x4f94>
 2a03071:	mov    0x140(%rsp),%edi
 2a03078:	test   %edi,%edi
 2a0307a:	je     2a190ac <wasm[0]::function[1015]::helper::object_read+0x1af4c>
 2a03080:	mov    0x2e0(%rsp),%r14
 2a03088:	mov    0x28(%r14),%rsi
 2a0308c:	mov    %edi,%edi
 2a0308e:	mov    %rdi,%rdx
 2a03091:	add    0x20(%r14),%rdx
 2a03095:	xor    %r8,%r8
 2a03098:	cmp    %rsi,%rdi
 2a0309b:	cmova  %r8,%rdx
 2a0309f:	mov    0x1c(%rdx),%r13d
 2a030a3:	mov    %r13,0x208(%rsp)
 2a030ab:	mov    0x100(%rsp),%r8d
 2a030b3:	mov    0x88(%rsp),%edx
 2a030ba:	mov    %rdx,0x210(%rsp)
 2a030c2:	mov    0x110(%rsp),%r9d
 2a030ca:	mov    0x128(%rsp),%esi
 2a030d1:	mov    0x90(%rsp),%r13d
 2a030d9:	mov    0xa0(%rsp),%edx
 2a030e0:	mov    0x108(%rsp),%edi
 2a030e7:	mov    0x208(%rsp),%rcx
 2a030ef:	jmp    2a02fbb <wasm[0]::function[1015]::helper::object_read+0x4e5b>
 2a030f4:	test   %eax,%eax
 2a030f6:	jne    2a03112 <wasm[0]::function[1015]::helper::object_read+0x4fb2>
 2a030fc:	mov    0x190(%rsp),%rcx
 2a03104:	mov    0x8c0(%rcx),%eax
 2a0310a:	test   %eax,%eax
 2a0310c:	je     2a190ae <wasm[0]::function[1015]::helper::object_read+0x1af4e>
 2a03112:	mov    %eax,0x140(%rsp)
 2a03119:	test   %eax,%eax
 2a0311b:	je     2a190b0 <wasm[0]::function[1015]::helper::object_read+0x1af50>
 2a03121:	test   %eax,%eax
 2a03123:	je     2a190b2 <wasm[0]::function[1015]::helper::object_read+0x1af52>
 2a03129:	mov    0x2e0(%rsp),%r14
 2a03131:	mov    0x28(%r14),%rcx
 2a03135:	mov    0x20(%r14),%rdx
 2a03139:	mov    %eax,%edi
 2a0313b:	lea    (%rdx,%rdi,1),%rsi
 2a0313f:	xor    %rax,%rax
 2a03142:	cmp    %rcx,%rdi
 2a03145:	cmova  %rax,%rsi
 2a03149:	mov    0x2c(%rsi),%r8d
 2a0314d:	test   %r8d,%r8d
 2a03150:	je     2a190b4 <wasm[0]::function[1015]::helper::object_read+0x1af54>
 2a03156:	test   %r8d,%r8d
 2a03159:	je     2a190b6 <wasm[0]::function[1015]::helper::object_read+0x1af56>
 2a0315f:	mov    %r8d,%edi
 2a03162:	lea    0x10(%rdx,%rdi,1),%rsi
 2a03167:	cmp    %rcx,%rdi
 2a0316a:	cmova  %rax,%rsi
 2a0316e:	mov    (%rsi),%esi
 2a03170:	cmp    $0xd,%esi
 2a03173:	jbe    2a190b8 <wasm[0]::function[1015]::helper::object_read+0x1af58>
 2a03179:	mov    %esi,%edi
 2a0317b:	shl    $0x2,%rdi
 2a0317f:	mov    $0x20,%r9d
 2a03185:	mov    %r9,0x2c8(%rsp)
 2a0318d:	shr    $0x20,%rdi
 2a03191:	test   %rdi,%rdi
 2a03194:	jne    2a190ba <wasm[0]::function[1015]::helper::object_read+0x1af5a>
 2a0319a:	shl    $0x2,%esi
 2a0319d:	add    $0x14,%esi
 2a031a0:	jb     2a190bc <wasm[0]::function[1015]::helper::object_read+0x1af5c>
 2a031a6:	add    %esi,%r8d
 2a031a9:	jb     2a190be <wasm[0]::function[1015]::helper::object_read+0x1af5e>
 2a031af:	mov    %r8d,%r8d
 2a031b2:	lea    (%rdx,%r8,1),%rdi
 2a031b6:	cmp    %rcx,%r8
 2a031b9:	cmova  %rax,%rdi
 2a031bd:	sub    $0x48,%esi
 2a031c0:	sub    %rsi,%rdi
 2a031c3:	mov    (%rdi),%esi
 2a031c5:	test   %esi,%esi
 2a031c7:	je     2a190c0 <wasm[0]::function[1015]::helper::object_read+0x1af60>
 2a031cd:	test   %esi,%esi
 2a031cf:	je     2a190c2 <wasm[0]::function[1015]::helper::object_read+0x1af62>
 2a031d5:	mov    %esi,%esi
 2a031d7:	add    %rsi,%rdx
 2a031da:	cmp    %rcx,%rsi
 2a031dd:	cmova  %rax,%rdx
 2a031e1:	mov    0x18(%rdx),%ecx
 2a031e4:	mov    0x10(%rdx),%rax
 2a031e8:	mov    0x1c(%rdx),%eax
 2a031eb:	mov    %eax,0xd0(%rsp)
 2a031f2:	cmp    $0x6,%ecx
 2a031f5:	sete   %dl
 2a031f8:	cmp    $0x7,%ecx
 2a031fb:	sete   %sil
 2a031ff:	or     %esi,%edx
 2a03201:	cmp    $0x8,%ecx
 2a03204:	sete   %sil
 2a03208:	or     %esi,%edx
 2a0320a:	cmp    $0x9,%ecx
 2a0320d:	sete   %cl
 2a03210:	or     %ecx,%edx
 2a03212:	movzbl %dl,%ecx
 2a03215:	test   %ecx,%ecx
 2a03217:	je     2a190c4 <wasm[0]::function[1015]::helper::object_read+0x1af64>
 2a0321d:	xor    %r11d,%r11d
 2a03220:	test   %eax,%eax
 2a03222:	je     2a03272 <wasm[0]::function[1015]::helper::object_read+0x5112>
 2a03228:	xor    %r11d,%r11d
 2a0322b:	test   $0x1,%eax
 2a03230:	jne    2a03272 <wasm[0]::function[1015]::helper::object_read+0x5112>
 2a03236:	mov    0x2e0(%rsp),%r14
 2a0323e:	mov    0x28(%r14),%rcx
 2a03242:	mov    0x20(%r14),%rdx
 2a03246:	mov    %eax,%esi
 2a03248:	lea    0x4(%rdx,%rsi,1),%rdx
 2a0324d:	xor    %rdi,%rdi
 2a03250:	cmp    %rcx,%rsi
 2a03253:	cmova  %rdi,%rdx
 2a03257:	mov    (%rdx),%ecx
 2a03259:	mov    0x190(%rsp),%rdx
 2a03261:	mov    0x28(%rdx),%rdx
 2a03265:	cmp    0x1d4(%rdx),%ecx
 2a0326b:	sete   %cl
 2a0326e:	movzbl %cl,%r11d
 2a03272:	test   %r11d,%r11d
 2a03275:	je     2a190c6 <wasm[0]::function[1015]::helper::object_read+0x1af66>
 2a0327b:	test   %eax,%eax
 2a0327d:	je     2a190c8 <wasm[0]::function[1015]::helper::object_read+0x1af68>
 2a03283:	movl   $0x0,0x148(%rsp)
 2a0328e:	movl   $0x0,0xe8(%rsp)
 2a03299:	movl   $0x0,0xc0(%rsp)
 2a032a4:	movl   $0x0,0x118(%rsp)
 2a032af:	movl   $0x0,0xb0(%rsp)
 2a032ba:	mov    $0x105,%edx
 2a032bf:	mov    0x190(%rsp),%rsi
 2a032c7:	mov    0x190(%rsp),%rdi
 2a032cf:	call   2f4f240 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 2a032d4:	test   %eax,%eax
 2a032d6:	je     2a190ca <wasm[0]::function[1015]::helper::object_read+0x1af6a>
 2a032dc:	mov    0xd0(%rsp),%r8d
 2a032e4:	mov    $0x8,%edx
 2a032e9:	xor    %rcx,%rcx
 2a032ec:	movabs $0x4000000000000000,%rsi
 2a032f6:	mov    %rsi,(%rsp)
 2a032fa:	mov    0x278(%rsp),%rsi
 2a03302:	mov    %esi,0x8(%rsp)
 2a03306:	mov    %rax,%r9
 2a03309:	mov    0x190(%rsp),%rsi
 2a03311:	mov    0x190(%rsp),%rdi
 2a03319:	call   2a73380 <wasm[0]::function[1029]::helper::native_function_allocate>
 2a0331e:	sub    $0x10,%rsp
 2a03322:	mov    %eax,0xd0(%rsp)
 2a03329:	mov    $0x51,%esi
 2a0332e:	mov    0x190(%rsp),%rdi
 2a03336:	call   3039b3e <wasmtime_builtin_ref_func>
 2a0333b:	mov    0x190(%rsp),%rcx
 2a03343:	mov    %rax,%r13
 2a03346:	mov    0x20(%rcx),%rdi
 2a0334a:	mov    (%rdi),%eax
 2a0334c:	mov    %eax,%esi
 2a0334e:	lea    0x40(%rsi),%r8
 2a03352:	mov    0x4(%rdi),%r9d
 2a03356:	mov    %rdi,0x2c0(%rsp)
 2a0335e:	cmp    %r9,%r8
 2a03361:	ja     2a17b4f <wasm[0]::function[1015]::helper::object_read+0x199ef>
 2a03367:	lea    0x40(%rax),%r8d
 2a0336b:	mov    0x2c0(%rsp),%rdi
 2a03373:	mov    %r8d,(%rdi)
 2a03376:	mov    0x2e0(%rsp),%r14
 2a0337e:	mov    0x20(%r14),%r8
 2a03382:	lea    (%r8,%rsi,1),%r12
 2a03386:	movl   $0xb0000002,(%r8,%rsi,1)
 2a0338e:	mov    0x190(%rsp),%rcx
 2a03396:	mov    0x28(%rcx),%r9
 2a0339a:	mov    0x1d0(%r9),%r9d
 2a033a1:	mov    %r9d,0x4(%r8,%rsi,1)
 2a033a6:	mov    $0x40,%r10d
 2a033ac:	mov    %r10d,0x8(%r8,%rsi,1)
 2a033b1:	mov    %eax,0x130(%rsp)
 2a033b8:	movq   $0x51,0x10(%r12)
 2a033c1:	movl   $0x1,0x18(%r12)
 2a033ca:	movl   $0xf,0x1c(%r12)
 2a033d3:	movl   $0xffffffff,0x20(%r12)
 2a033dc:	movl   $0x0,0x24(%r12)
 2a033e5:	movl   $0x0,0x28(%r12)
 2a033ee:	mov    %r13,%rsi
 2a033f1:	mov    0x190(%rsp),%rdi
 2a033f9:	call   3039c33 <wasmtime_builtin_intern_func_ref_for_gc_heap>
 2a033fe:	mov    %eax,0x2c(%r12)
 2a03403:	xor    %rsi,%rsi
 2a03406:	mov    %rsi,%rbx
 2a03409:	mov    0x190(%rsp),%rdi
 2a03411:	call   3039c33 <wasmtime_builtin_intern_func_ref_for_gc_heap>
 2a03416:	mov    %eax,0x30(%r12)
 2a0341b:	mov    %rbx,%rsi
 2a0341e:	mov    0x190(%rsp),%rdi
 2a03426:	call   3039c33 <wasmtime_builtin_intern_func_ref_for_gc_heap>
 2a0342b:	mov    %eax,0x34(%r12)
 2a03430:	mov    %rbx,%rsi
 2a03433:	mov    0x190(%rsp),%rdi
 2a0343b:	call   3039c33 <wasmtime_builtin_intern_func_ref_for_gc_heap>
 2a03440:	mov    %eax,0x38(%r12)
 2a03445:	mov    %rbx,%rsi
 2a03448:	mov    0x190(%rsp),%rdi
 2a03450:	call   3039c33 <wasmtime_builtin_intern_func_ref_for_gc_heap>
 2a03455:	mov    %eax,0x3c(%r12)
 2a0345a:	mov    0x190(%rsp),%rcx
 2a03462:	mov    0xa20(%rcx),%eax
 2a03468:	mov    %eax,0xf0(%rsp)
 2a0346f:	mov    0x140(%rsp),%ecx
 2a03476:	test   %ecx,%ecx
 2a03478:	je     2a190cc <wasm[0]::function[1015]::helper::object_read+0x1af6c>
 2a0347e:	test   %eax,%eax
 2a03480:	je     2a190ce <wasm[0]::function[1015]::helper::object_read+0x1af6e>
 2a03486:	mov    0x2c0(%rsp),%rsi
 2a0348e:	mov    (%rsi),%eax
 2a03490:	mov    %eax,%ecx
 2a03492:	lea    0x40(%rcx),%rdx
 2a03496:	mov    0x4(%rsi),%esi
 2a03499:	cmp    %rsi,%rdx
 2a0349c:	ja     2a17b92 <wasm[0]::function[1015]::helper::object_read+0x19a32>
 2a034a2:	mov    %rax,%rdx
 2a034a5:	lea    0x40(%rdx),%eax
 2a034a8:	mov    0x2c0(%rsp),%rsi
 2a034b0:	mov    %eax,(%rsi)
 2a034b2:	mov    0x2e0(%rsp),%r14
 2a034ba:	mov    0x20(%r14),%rax
 2a034be:	lea    (%rax,%rcx,1),%rbx
 2a034c2:	movl   $0xb0001ffa,(%rax,%rcx,1)
 2a034c9:	mov    0x190(%rsp),%rsi
 2a034d1:	mov    0x28(%rsi),%rsi
 2a034d5:	mov    0x1e0(%rsi),%esi
 2a034db:	mov    %esi,0x4(%rax,%rcx,1)
 2a034df:	mov    $0x40,%esi
 2a034e4:	mov    %esi,0x8(%rax,%rcx,1)
 2a034e8:	mov    %edx,0xd8(%rsp)
 2a034ef:	mov    0x140(%rsp),%eax
 2a034f6:	mov    %eax,0x10(%rbx)
 2a034f9:	mov    0x148(%rsp),%eax
 2a03500:	mov    %eax,0x14(%rbx)
 2a03503:	mov    0xe8(%rsp),%eax
 2a0350a:	mov    %eax,0x18(%rbx)
 2a0350d:	movl   $0x0,0x1c(%rbx)
 2a03514:	mov    0xf0(%rsp),%eax
 2a0351b:	mov    %eax,0x20(%rbx)
 2a0351e:	mov    0xc0(%rsp),%eax
 2a03525:	mov    %eax,0x24(%rbx)
 2a03528:	mov    0xb0(%rsp),%eax
 2a0352f:	mov    %eax,0x28(%rbx)
 2a03532:	mov    0x100(%rsp),%eax
 2a03539:	mov    %eax,0x2c(%rbx)
 2a0353c:	mov    0x118(%rsp),%eax
 2a03543:	mov    %eax,0x30(%rbx)
 2a03546:	movl   $0x0,0x34(%rbx)
 2a0354d:	xor    %rsi,%rsi
 2a03550:	mov    0x190(%rsp),%rdi
 2a03558:	call   3039c33 <wasmtime_builtin_intern_func_ref_for_gc_heap>
 2a0355d:	mov    %eax,0x38(%rbx)
 2a03560:	mov    $0xea5,%edx
 2a03565:	mov    0x190(%rsp),%rsi
 2a0356d:	mov    0x190(%rsp),%rdi
 2a03575:	call   2f4f240 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 2a0357a:	mov    %eax,0x118(%rsp)
 2a03581:	mov    0x190(%rsp),%rcx
 2a03589:	mov    0xa20(%rcx),%ecx
 2a0358f:	mov    %ecx,0x100(%rsp)
 2a03596:	mov    0xd0(%rsp),%edx
 2a0359d:	test   %edx,%edx
 2a0359f:	je     2a190d0 <wasm[0]::function[1015]::helper::object_read+0x1af70>
 2a035a5:	mov    0x130(%rsp),%edx
 2a035ac:	test   %edx,%edx
 2a035ae:	je     2a190d2 <wasm[0]::function[1015]::helper::object_read+0x1af72>
 2a035b4:	mov    0xd8(%rsp),%edx
 2a035bb:	test   %edx,%edx
 2a035bd:	je     2a190d4 <wasm[0]::function[1015]::helper::object_read+0x1af74>
 2a035c3:	test   %eax,%eax
 2a035c5:	je     2a190d6 <wasm[0]::function[1015]::helper::object_read+0x1af76>
 2a035cb:	test   %ecx,%ecx
 2a035cd:	je     2a190d8 <wasm[0]::function[1015]::helper::object_read+0x1af78>
 2a035d3:	mov    0x2c0(%rsp),%rsi
 2a035db:	mov    (%rsi),%eax
 2a035dd:	mov    %eax,%ecx
 2a035df:	lea    0x50(%rcx),%rdx
 2a035e3:	mov    0x4(%rsi),%esi
 2a035e6:	cmp    %rsi,%rdx
 2a035e9:	ja     2a17bd7 <wasm[0]::function[1015]::helper::object_read+0x19a77>
 2a035ef:	lea    0x50(%rax),%edx
 2a035f2:	mov    0x2c0(%rsp),%rsi
 2a035fa:	mov    %edx,(%rsi)
 2a035fc:	mov    0x2e0(%rsp),%r14
 2a03604:	mov    0x20(%r14),%rdx
 2a03608:	lea    (%rdx,%rcx,1),%r8
 2a0360c:	movl   $0xb00300fa,(%rdx,%rcx,1)
 2a03613:	mov    0x190(%rsp),%rsi
 2a0361b:	mov    0x28(%rsi),%rsi
 2a0361f:	mov    0x1d4(%rsi),%esi
 2a03625:	mov    %esi,0x4(%rdx,%rcx,1)
 2a03629:	mov    $0x50,%esi
 2a0362e:	mov    %esi,0x8(%rdx,%rcx,1)
 2a03632:	mov    %eax,0xb0(%rsp)
 2a03639:	mov    0xd0(%rsp),%edi
 2a03640:	mov    %edi,0x10(%r8)
 2a03644:	mov    0x130(%rsp),%r9d
 2a0364c:	mov    %r9d,0x14(%r8)
 2a03650:	mov    0xd8(%rsp),%r9d
 2a03658:	mov    %r9d,0x18(%r8)
 2a0365c:	mov    0x118(%rsp),%r10d
 2a03664:	mov    %r10d,0x1c(%r8)
 2a03668:	mov    0x100(%rsp),%r11d
 2a03670:	mov    %r11d,0x20(%r8)
 2a03674:	movl   $0x1,0x24(%r8)
 2a0367c:	movl   $0x0,0x28(%r8)
 2a03684:	movl   $0x0,0x2c(%r8)
 2a0368c:	movl   $0x0,0x30(%r8)
 2a03694:	movl   $0x0,0x34(%r8)
 2a0369c:	movl   $0x0,0x38(%r8)
 2a036a4:	movl   $0x0,0x3c(%r8)
 2a036ac:	movl   $0xffffffff,0x40(%r8)
 2a036b4:	movl   $0x0,0x44(%r8)
 2a036bc:	movl   $0x0,0x48(%r8)
 2a036c4:	test   %r9d,%r9d
 2a036c7:	je     2a190da <wasm[0]::function[1015]::helper::object_read+0x1af7a>
 2a036cd:	test   %eax,%eax
 2a036cf:	je     2a190dc <wasm[0]::function[1015]::helper::object_read+0x1af7c>
 2a036d5:	test   %r9d,%r9d
 2a036d8:	je     2a190de <wasm[0]::function[1015]::helper::object_read+0x1af7e>
 2a036de:	mov    0x2e0(%rsp),%r14
 2a036e6:	mov    0x28(%r14),%rcx
 2a036ea:	mov    %r9d,%esi
 2a036ed:	mov    %rsi,%rdx
 2a036f0:	add    0x20(%r14),%rdx
 2a036f4:	xor    %rdi,%rdi
 2a036f7:	cmp    %rcx,%rsi
 2a036fa:	cmova  %rdi,%rdx
 2a036fe:	mov    %eax,0x1c(%rdx)
 2a03701:	movl   $0x0,0xd8(%rsp)
 2a0370c:	mov    0x2c0(%rsp),%rsi
 2a03714:	mov    (%rsi),%eax
 2a03716:	mov    %eax,%ecx
 2a03718:	lea    0x20(%rcx),%rdx
 2a0371c:	mov    0x4(%rsi),%esi
 2a0371f:	cmp    %rsi,%rdx
 2a03722:	ja     2a17c1a <wasm[0]::function[1015]::helper::object_read+0x19aba>
 2a03728:	lea    0x20(%rax),%edx
 2a0372b:	mov    0x2c0(%rsp),%rsi
 2a03733:	mov    %edx,(%rsi)
 2a03735:	mov    0x2e0(%rsp),%r14
 2a0373d:	mov    0x20(%r14),%rdx
 2a03741:	lea    (%rdx,%rcx,1),%r9
 2a03745:	movl   $0xb0000042,(%rdx,%rcx,1)
 2a0374c:	mov    0x190(%rsp),%rsi
 2a03754:	mov    0x28(%rsi),%rsi
 2a03758:	mov    0x120(%rsi),%esi
 2a0375e:	mov    %esi,0x4(%rdx,%rcx,1)
 2a03762:	mov    0x2c8(%rsp),%r10
 2a0376a:	mov    %r10d,0x8(%rdx,%rcx,1)
 2a0376f:	mov    %eax,0x100(%rsp)
 2a03776:	mov    0x2d8(%rsp),%rcx
 2a0377e:	mov    %rcx,0x10(%r9)
 2a03782:	mov    0x2d0(%rsp),%rax
 2a0378a:	mov    %eax,0x18(%r9)
 2a0378e:	mov    0x88(%rsp),%eax
 2a03795:	mov    %eax,0x1c(%r9)
 2a03799:	mov    0x2c0(%rsp),%rsi
 2a037a1:	mov    (%rsi),%eax
 2a037a3:	mov    %eax,%edx
 2a037a5:	lea    0x20(%rdx),%rcx
 2a037a9:	mov    0x4(%rsi),%esi
 2a037ac:	cmp    %rsi,%rcx
 2a037af:	ja     2a17c5d <wasm[0]::function[1015]::helper::object_read+0x19afd>
 2a037b5:	lea    0x20(%rax),%ecx
 2a037b8:	mov    0x2c0(%rsp),%rsi
 2a037c0:	mov    %ecx,(%rsi)
 2a037c2:	mov    0x2e0(%rsp),%r14
 2a037ca:	mov    0x20(%r14),%rsi
 2a037ce:	lea    (%rsi,%rdx,1),%rcx
 2a037d2:	movl   $0xb0000042,(%rsi,%rdx,1)
 2a037d9:	mov    0x190(%rsp),%rdi
 2a037e1:	mov    0x28(%rdi),%rdi
 2a037e5:	mov    0x120(%rdi),%edi
 2a037eb:	mov    %edi,0x4(%rsi,%rdx,1)
 2a037ef:	mov    0x2c8(%rsp),%rdi
 2a037f7:	mov    %edi,0x8(%rsi,%rdx,1)
 2a037fb:	mov    %eax,0x118(%rsp)
 2a03802:	mov    0x1c0(%rsp),%r8
 2a0380a:	mov    %r8,0x10(%rcx)
 2a0380e:	mov    0x1b8(%rsp),%rdx
 2a03816:	mov    %edx,0x18(%rcx)
 2a03819:	mov    0x110(%rsp),%edx
 2a03820:	mov    %edx,0x1c(%rcx)
 2a03823:	mov    0x100(%rsp),%ecx
 2a0382a:	test   %ecx,%ecx
 2a0382c:	je     2a190e0 <wasm[0]::function[1015]::helper::object_read+0x1af80>
 2a03832:	test   %eax,%eax
 2a03834:	je     2a190e2 <wasm[0]::function[1015]::helper::object_read+0x1af82>
 2a0383a:	mov    0x2c0(%rsp),%rsi
 2a03842:	mov    (%rsi),%eax
 2a03844:	mov    %eax,%ecx
 2a03846:	lea    0x20(%rcx),%rdx
 2a0384a:	mov    0x4(%rsi),%esi
 2a0384d:	cmp    %rsi,%rdx
 2a03850:	ja     2a17c9f <wasm[0]::function[1015]::helper::object_read+0x19b3f>
 2a03856:	lea    0x20(%rax),%edx
 2a03859:	mov    0x2c0(%rsp),%rsi
 2a03861:	mov    %edx,(%rsi)
 2a03863:	mov    0x2e0(%rsp),%r14
 2a0386b:	mov    0x20(%r14),%rsi
 2a0386f:	lea    (%rsi,%rcx,1),%rdx
 2a03873:	movl   $0xa800000e,(%rsi,%rcx,1)
 2a0387a:	mov    0x190(%rsp),%rdi
 2a03882:	mov    0x28(%rdi),%rdi
 2a03886:	mov    0x1b4(%rdi),%edi
 2a0388c:	mov    %edi,0x4(%rsi,%rcx,1)
 2a03890:	mov    0x2c8(%rsp),%rdi
 2a03898:	mov    %edi,0x8(%rsi,%rcx,1)
 2a0389c:	movl   $0x2,0x10(%rdx)
 2a038a3:	test   %eax,%eax
 2a038a5:	je     2a190e4 <wasm[0]::function[1015]::helper::object_read+0x1af84>
 2a038ab:	mov    0x2e0(%rsp),%r14
 2a038b3:	mov    0x28(%r14),%rdi
 2a038b7:	mov    0x20(%r14),%r8
 2a038bb:	mov    %eax,%r9d
 2a038be:	lea    0x10(%r8,%r9,1),%rsi
 2a038c3:	xor    %rcx,%rcx
 2a038c6:	cmp    %rdi,%r9
 2a038c9:	cmova  %rcx,%rsi
 2a038cd:	mov    (%rsi),%edx
 2a038cf:	test   %edx,%edx
 2a038d1:	je     2a190e6 <wasm[0]::function[1015]::helper::object_read+0x1af86>
 2a038d7:	mov    %edx,%r9d
 2a038da:	shl    $0x2,%r9
 2a038de:	shr    $0x20,%r9
 2a038e2:	test   %r9,%r9
 2a038e5:	jne    2a190e8 <wasm[0]::function[1015]::helper::object_read+0x1af88>
 2a038eb:	shl    $0x2,%edx
 2a038ee:	add    $0x14,%edx
 2a038f1:	jb     2a190ea <wasm[0]::function[1015]::helper::object_read+0x1af8a>
 2a038f7:	mov    %rax,%r10
 2a038fa:	add    %edx,%r10d
 2a038fd:	jb     2a190ec <wasm[0]::function[1015]::helper::object_read+0x1af8c>
 2a03903:	mov    0x100(%rsp),%r9d
 2a0390b:	mov    %r10d,%r10d
 2a0390e:	lea    (%r8,%r10,1),%r11
 2a03912:	cmp    %rdi,%r10
 2a03915:	cmova  %rcx,%r11
 2a03919:	sub    $0x14,%edx
 2a0391c:	sub    %rdx,%r11
 2a0391f:	mov    %r9d,(%r11)
 2a03922:	mov    (%rsi),%esi
 2a03924:	cmp    $0x1,%esi
 2a03927:	jbe    2a190ee <wasm[0]::function[1015]::helper::object_read+0x1af8e>
 2a0392d:	mov    %esi,%edx
 2a0392f:	shl    $0x2,%rdx
 2a03933:	shr    $0x20,%rdx
 2a03937:	test   %rdx,%rdx
 2a0393a:	jne    2a190f0 <wasm[0]::function[1015]::helper::object_read+0x1af90>
 2a03940:	shl    $0x2,%esi
 2a03943:	add    $0x14,%esi
 2a03946:	jb     2a190f2 <wasm[0]::function[1015]::helper::object_read+0x1af92>
 2a0394c:	mov    %rax,%r9
 2a0394f:	add    %esi,%r9d
 2a03952:	jb     2a190f4 <wasm[0]::function[1015]::helper::object_read+0x1af94>
 2a03958:	mov    0x118(%rsp),%edx
 2a0395f:	mov    %r9d,%r9d
 2a03962:	add    %r9,%r8
 2a03965:	cmp    %rdi,%r9
 2a03968:	cmova  %rcx,%r8
 2a0396c:	sub    $0x18,%esi
 2a0396f:	sub    %rsi,%r8
 2a03972:	mov    %edx,(%r8)
 2a03975:	mov    0x190(%rsp),%rdx
 2a0397d:	mov    0x8c0(%rdx),%edi
 2a03983:	mov    %edi,0x118(%rsp)
 2a0398a:	xor    %r9d,%r9d
 2a0398d:	test   %edi,%edi
 2a0398f:	je     2a190f6 <wasm[0]::function[1015]::helper::object_read+0x1af96>
 2a03995:	test   %eax,%eax
 2a03997:	je     2a190f8 <wasm[0]::function[1015]::helper::object_read+0x1af98>
 2a0399d:	mov    0x90(%rsp),%esi
 2a039a4:	test   %esi,%esi
 2a039a6:	je     2a190fa <wasm[0]::function[1015]::helper::object_read+0x1af9a>
 2a039ac:	mov    0xb0(%rsp),%r8d
 2a039b4:	mov    0xd8(%rsp),%r11d
 2a039bc:	mov    0x128(%rsp),%r10d
 2a039c4:	mov    $0x8,%edx
 2a039c9:	mov    %rcx,(%rsp)
 2a039cd:	mov    %r11d,0x8(%rsp)
 2a039d2:	mov    %eax,0x10(%rsp)
 2a039d6:	mov    %edi,0x18(%rsp)
 2a039da:	mov    %r10d,0x20(%rsp)
 2a039df:	mov    %esi,0x28(%rsp)
 2a039e3:	mov    0x190(%rsp),%rsi
 2a039eb:	mov    0x190(%rsp),%rdi
 2a039f3:	call   2afc220 <wasm[0]::function[1055]::helper::proxy_call>
 2a039f8:	sub    $0x30,%rsp
 2a039fc:	mov    %rax,0x2a8(%rsp)
 2a03a04:	mov    %rcx,0x2b8(%rsp)
 2a03a0c:	mov    %edx,0xb0(%rsp)
 2a03a13:	mov    0x118(%rsp),%eax
 2a03a1a:	test   %eax,%eax
 2a03a1c:	je     2a190fc <wasm[0]::function[1015]::helper::object_read+0x1af9c>
 2a03a22:	mov    0x190(%rsp),%rcx
 2a03a2a:	mov    %eax,0x8c0(%rcx)
 2a03a30:	cmp    $0x2,%esi
 2a03a33:	jne    2a03a3e <wasm[0]::function[1015]::helper::object_read+0x58de>
 2a03a39:	xor    %esi,%esi
 2a03a3b:	mov    %rsi,%rdi
 2a03a3e:	cmp    $0x1,%esi
 2a03a41:	je     2a09a8b <wasm[0]::function[1015]::helper::object_read+0xb92b>
 2a03a47:	mov    0xa0(%rsp),%eax
 2a03a4e:	mov    0x108(%rsp),%esi
 2a03a55:	mov    0x128(%rsp),%edi
 2a03a5c:	mov    0x90(%rsp),%r8d
 2a03a64:	mov    0x88(%rsp),%edx
 2a03a6b:	mov    0x110(%rsp),%ecx
 2a03a72:	mov    0x2a8(%rsp),%r9
 2a03a7a:	mov    0x2a8(%rsp),%r10
 2a03a82:	test   %r10d,%r9d
 2a03a85:	je     2a09a83 <wasm[0]::function[1015]::helper::object_read+0xb923>
 2a03a8b:	mov    $0x12b,%edx
 2a03a90:	mov    0x190(%rsp),%rsi
 2a03a98:	mov    0x190(%rsp),%rdi
 2a03aa0:	call   2f4f240 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 2a03aa5:	mov    %eax,0xa0(%rsp)
 2a03aac:	xor    %ebx,%ebx
 2a03aae:	test   %eax,%eax
 2a03ab0:	je     2a190fe <wasm[0]::function[1015]::helper::object_read+0x1af9e>
 2a03ab6:	movl   $0x0,0x118(%rsp)
 2a03ac1:	mov    0xb0(%rsp),%edi
 2a03ac8:	mov    %rdi,0x220(%rsp)
 2a03ad0:	mov    0x108(%rsp),%edi
 2a03ad7:	mov    0x128(%rsp),%r9d
 2a03adf:	mov    0x90(%rsp),%r11d
 2a03ae7:	mov    0x88(%rsp),%r15d
 2a03aef:	mov    0x110(%rsp),%edx
 2a03af6:	mov    0x2a8(%rsp),%rcx
 2a03afe:	cmp    $0x6,%ecx
 2a03b01:	sete   %cl
 2a03b04:	mov    0x2a8(%rsp),%rax
 2a03b0c:	cmp    $0x7,%eax
 2a03b0f:	sete   %al
 2a03b12:	or     %eax,%ecx
 2a03b14:	mov    0x2a8(%rsp),%rax
 2a03b1c:	cmp    $0x8,%eax
 2a03b1f:	sete   %al
 2a03b22:	or     %eax,%ecx
 2a03b24:	mov    0x2a8(%rsp),%rax
 2a03b2c:	cmp    $0x9,%eax
 2a03b2f:	sete   %al
 2a03b32:	or     %eax,%ecx
 2a03b34:	xor    %r10,%r10
 2a03b37:	test   %cl,%cl
 2a03b39:	mov    %rcx,0x2a0(%rsp)
 2a03b41:	jne    2a03b67 <wasm[0]::function[1015]::helper::object_read+0x5a07>
 2a03b47:	mov    %rbx,0x248(%rsp)
 2a03b4f:	mov    %r10,0x240(%rsp)
 2a03b57:	mov    %rbx,%r13
 2a03b5a:	mov    0x220(%rsp),%r10
 2a03b62:	jmp    2a0474d <wasm[0]::function[1015]::helper::object_read+0x65ed>
 2a03b67:	mov    0xb0(%rsp),%r8d
 2a03b6f:	mov    0x2b8(%rsp),%rcx
 2a03b77:	mov    0x2a8(%rsp),%rdx
 2a03b7f:	mov    0x190(%rsp),%rsi
 2a03b87:	mov    0x190(%rsp),%rdi
 2a03b8f:	call   2a7c940 <wasm[0]::function[1039]::helper::object_header_projection>
 2a03b94:	mov    %eax,0xd8(%rsp)
 2a03b9b:	test   %eax,%eax
 2a03b9d:	je     2a19100 <wasm[0]::function[1015]::helper::object_read+0x1afa0>
 2a03ba3:	test   %eax,%eax
 2a03ba5:	je     2a19102 <wasm[0]::function[1015]::helper::object_read+0x1afa2>
 2a03bab:	mov    0x2e0(%rsp),%r14
 2a03bb3:	mov    0x28(%r14),%rcx
 2a03bb7:	mov    0x20(%r14),%rsi
 2a03bbb:	mov    %eax,%edx
 2a03bbd:	lea    (%rsi,%rdx,1),%rax
 2a03bc1:	xor    %rsi,%rsi
 2a03bc4:	cmp    %rcx,%rdx
 2a03bc7:	cmova  %rsi,%rax
 2a03bcb:	mov    0x14(%rax),%eax
 2a03bce:	mov    %eax,0x100(%rsp)
 2a03bd5:	test   %eax,%eax
 2a03bd7:	je     2a19104 <wasm[0]::function[1015]::helper::object_read+0x1afa4>
 2a03bdd:	mov    0x100(%rsp),%esi
 2a03be4:	xor    %eax,%eax
 2a03be6:	test   $0x1,%esi
 2a03bec:	jne    2a03c48 <wasm[0]::function[1015]::helper::object_read+0x5ae8>
 2a03bf2:	mov    0x2e0(%rsp),%r14
 2a03bfa:	mov    0x28(%r14),%rdi
 2a03bfe:	mov    0x20(%r14),%r9
 2a03c02:	mov    %esi,%r8d
 2a03c05:	lea    0x4(%r9,%r8,1),%rsi
 2a03c0a:	xor    %r9,%r9
 2a03c0d:	cmp    %rdi,%r8
 2a03c10:	cmova  %r9,%rsi
 2a03c14:	mov    (%rsi),%esi
 2a03c16:	mov    0x190(%rsp),%rcx
 2a03c1e:	mov    0x28(%rcx),%r8
 2a03c22:	mov    0x158(%r8),%edx
 2a03c29:	cmp    %edx,%esi
 2a03c2b:	sete   %r9b
 2a03c2f:	movzbl %r9b,%eax
 2a03c33:	cmp    %edx,%esi
 2a03c35:	je     2a03c48 <wasm[0]::function[1015]::helper::object_read+0x5ae8>
 2a03c3b:	mov    0x190(%rsp),%rdi
 2a03c43:	call   3039cc5 <wasmtime_builtin_is_subtype>
 2a03c48:	test   %eax,%eax
 2a03c4a:	jne    2a03e99 <wasm[0]::function[1015]::helper::object_read+0x5d39>
 2a03c50:	mov    0xd8(%rsp),%edx
 2a03c57:	xor    %r12d,%r12d
 2a03c5a:	test   %edx,%edx
 2a03c5c:	je     2a19106 <wasm[0]::function[1015]::helper::object_read+0x1afa6>
 2a03c62:	mov    0xa0(%rsp),%r9d
 2a03c6a:	mov    $0x4,%ecx
 2a03c6f:	xor    %r8,%r8
 2a03c72:	mov    0x190(%rsp),%rsi
 2a03c7a:	mov    0x190(%rsp),%rdi
 2a03c82:	call   2a76140 <wasm[0]::function[1032]::helper::ordinary_property_find>
 2a03c87:	test   %eax,%eax
 2a03c89:	je     2a03cc2 <wasm[0]::function[1015]::helper::object_read+0x5b62>
 2a03c8f:	test   %eax,%eax
 2a03c91:	je     2a19108 <wasm[0]::function[1015]::helper::object_read+0x1afa8>
 2a03c97:	test   %eax,%eax
 2a03c99:	je     2a1910a <wasm[0]::function[1015]::helper::object_read+0x1afaa>
 2a03c9f:	mov    0x2e0(%rsp),%r14
 2a03ca7:	mov    0x28(%r14),%rcx
 2a03cab:	mov    %eax,%edx
 2a03cad:	mov    %rdx,%rax
 2a03cb0:	add    0x20(%r14),%rax
 2a03cb4:	xor    %rsi,%rsi
 2a03cb7:	cmp    %rcx,%rdx
 2a03cba:	cmova  %rsi,%rax
 2a03cbe:	mov    0x14(%rax),%r12d
 2a03cc2:	mov    0x118(%rsp),%r13d
 2a03cca:	xor    %r10,%r10
 2a03ccd:	xor    %ebx,%ebx
 2a03ccf:	test   %r12d,%r12d
 2a03cd2:	je     2a03e4f <wasm[0]::function[1015]::helper::object_read+0x5cef>
 2a03cd8:	test   %r12d,%r12d
 2a03cdb:	je     2a1910c <wasm[0]::function[1015]::helper::object_read+0x1afac>
 2a03ce1:	mov    0x2e0(%rsp),%r14
 2a03ce9:	mov    0x28(%r14),%rcx
 2a03ced:	mov    0x20(%r14),%rax
 2a03cf1:	mov    %r12d,%edx
 2a03cf4:	add    %rdx,%rax
 2a03cf7:	xor    %r10,%r10
 2a03cfa:	cmp    %rcx,%rdx
 2a03cfd:	cmova  %r10,%rax
 2a03d01:	mov    0x10(%rax),%ecx
 2a03d04:	mov    0x118(%rsp),%r13d
 2a03d0c:	xor    %ebx,%ebx
 2a03d0e:	test   $0x1,%ecx
 2a03d14:	jne    2a03e4f <wasm[0]::function[1015]::helper::object_read+0x5cef>
 2a03d1a:	mov    0x14(%rax),%edx
 2a03d1d:	test   %edx,%edx
 2a03d1f:	je     2a1910e <wasm[0]::function[1015]::helper::object_read+0x1afae>
 2a03d25:	xor    %eax,%eax
 2a03d27:	test   $0x1,%edx
 2a03d2d:	jne    2a03d6e <wasm[0]::function[1015]::helper::object_read+0x5c0e>
 2a03d33:	mov    0x2e0(%rsp),%r14
 2a03d3b:	mov    0x28(%r14),%rax
 2a03d3f:	mov    0x20(%r14),%rcx
 2a03d43:	mov    %edx,%esi
 2a03d45:	lea    0x4(%rcx,%rsi,1),%rcx
 2a03d4a:	xor    %rdi,%rdi
 2a03d4d:	cmp    %rax,%rsi
 2a03d50:	cmova  %rdi,%rcx
 2a03d54:	mov    (%rcx),%eax
 2a03d56:	mov    0x190(%rsp),%rcx
 2a03d5e:	mov    0x28(%rcx),%rcx
 2a03d62:	cmp    0x120(%rcx),%eax
 2a03d68:	sete   %al
 2a03d6b:	movzbl %al,%eax
 2a03d6e:	test   %eax,%eax
 2a03d70:	jne    2a03dcb <wasm[0]::function[1015]::helper::object_read+0x5c6b>
 2a03d76:	mov    0x190(%rsp),%rsi
 2a03d7e:	mov    0x190(%rsp),%rdi
 2a03d86:	call   2a1eec0 <wasm[0]::function[1024]::helper::property_value_resolve>
 2a03d8b:	test   %eax,%eax
 2a03d8d:	je     2a19110 <wasm[0]::function[1015]::helper::object_read+0x1afb0>
 2a03d93:	test   %eax,%eax
 2a03d95:	je     2a19112 <wasm[0]::function[1015]::helper::object_read+0x1afb2>
 2a03d9b:	mov    0x2e0(%rsp),%r14
 2a03da3:	mov    0x28(%r14),%rcx
 2a03da7:	mov    0x20(%r14),%rsi
 2a03dab:	mov    %eax,%edx
 2a03dad:	lea    (%rsi,%rdx,1),%rax
 2a03db1:	xor    %rsi,%rsi
 2a03db4:	cmp    %rcx,%rdx
 2a03db7:	cmova  %rsi,%rax
 2a03dbb:	mov    0x18(%rax),%ebx
 2a03dbe:	mov    0x10(%rax),%r10
 2a03dc2:	mov    0x1c(%rax),%r13d
 2a03dc6:	jmp    2a03e4f <wasm[0]::function[1015]::helper::object_read+0x5cef>
 2a03dcb:	xor    %eax,%eax
 2a03dcd:	test   $0x1,%edx
 2a03dd3:	jne    2a03e14 <wasm[0]::function[1015]::helper::object_read+0x5cb4>
 2a03dd9:	mov    0x2e0(%rsp),%r14
 2a03de1:	mov    0x28(%r14),%rax
 2a03de5:	mov    0x20(%r14),%rcx
 2a03de9:	mov    %edx,%esi
 2a03deb:	lea    0x4(%rcx,%rsi,1),%rcx
 2a03df0:	xor    %rdi,%rdi
 2a03df3:	cmp    %rax,%rsi
 2a03df6:	cmova  %rdi,%rcx
 2a03dfa:	mov    (%rcx),%eax
 2a03dfc:	mov    0x190(%rsp),%rcx
 2a03e04:	mov    0x28(%rcx),%rcx
 2a03e08:	cmp    0x120(%rcx),%eax
 2a03e0e:	sete   %al
 2a03e11:	movzbl %al,%eax
 2a03e14:	test   %eax,%eax
 2a03e16:	je     2a19114 <wasm[0]::function[1015]::helper::object_read+0x1afb4>
 2a03e1c:	test   %edx,%edx
 2a03e1e:	je     2a19116 <wasm[0]::function[1015]::helper::object_read+0x1afb6>
 2a03e24:	mov    0x2e0(%rsp),%r14
 2a03e2c:	mov    0x28(%r14),%rcx
 2a03e30:	mov    0x20(%r14),%rsi
 2a03e34:	mov    %edx,%edx
 2a03e36:	lea    (%rsi,%rdx,1),%rax
 2a03e3a:	xor    %rsi,%rsi
 2a03e3d:	cmp    %rcx,%rdx
 2a03e40:	cmova  %rsi,%rax
 2a03e44:	mov    0x18(%rax),%ebx
 2a03e47:	mov    0x10(%rax),%r10
 2a03e4b:	mov    0x1c(%rax),%r13d
 2a03e4f:	mov    0xb0(%rsp),%edi
 2a03e56:	mov    %rdi,0x220(%rsp)
 2a03e5e:	mov    0x108(%rsp),%edi
 2a03e65:	mov    0x128(%rsp),%r9d
 2a03e6d:	mov    0x90(%rsp),%r11d
 2a03e75:	mov    0x88(%rsp),%r15d
 2a03e7d:	mov    0x110(%rsp),%edx
 2a03e84:	mov    %r10,0x240(%rsp)
 2a03e8c:	mov    %rbx,0x248(%rsp)
 2a03e94:	jmp    2a04745 <wasm[0]::function[1015]::helper::object_read+0x65e5>
 2a03e99:	mov    0x100(%rsp),%esi
 2a03ea0:	test   %esi,%esi
 2a03ea2:	je     2a19118 <wasm[0]::function[1015]::helper::object_read+0x1afb8>
 2a03ea8:	mov    0x100(%rsp),%r9d
 2a03eb0:	xor    %eax,%eax
 2a03eb2:	test   $0x1,%r9d
 2a03eb9:	jne    2a03f13 <wasm[0]::function[1015]::helper::object_read+0x5db3>
 2a03ebf:	mov    0x2e0(%rsp),%r14
 2a03ec7:	mov    0x28(%r14),%rax
 2a03ecb:	mov    0x20(%r14),%rdx
 2a03ecf:	mov    %r9d,%ecx
 2a03ed2:	lea    0x4(%rdx,%rcx,1),%r9
 2a03ed7:	xor    %rdx,%rdx
 2a03eda:	cmp    %rax,%rcx
 2a03edd:	cmova  %rdx,%r9
 2a03ee1:	mov    (%r9),%esi
 2a03ee4:	mov    0x190(%rsp),%rcx
 2a03eec:	mov    0x28(%rcx),%rax
 2a03ef0:	mov    0x158(%rax),%edx
 2a03ef6:	cmp    %edx,%esi
 2a03ef8:	sete   %al
 2a03efb:	movzbl %al,%eax
 2a03efe:	cmp    %edx,%esi
 2a03f00:	je     2a03f13 <wasm[0]::function[1015]::helper::object_read+0x5db3>
 2a03f06:	mov    0x190(%rsp),%rdi
 2a03f0e:	call   3039cc5 <wasmtime_builtin_is_subtype>
 2a03f13:	test   %eax,%eax
 2a03f15:	je     2a1911a <wasm[0]::function[1015]::helper::object_read+0x1afba>
 2a03f1b:	mov    0x100(%rsp),%r8d
 2a03f23:	mov    0xb0(%rsp),%edi
 2a03f2a:	mov    %rdi,0x220(%rsp)
 2a03f32:	mov    0x118(%rsp),%r13d
 2a03f3a:	mov    0x108(%rsp),%edi
 2a03f41:	mov    0x128(%rsp),%r9d
 2a03f49:	mov    0x90(%rsp),%r11d
 2a03f51:	mov    0x88(%rsp),%r15d
 2a03f59:	mov    0x110(%rsp),%edx
 2a03f60:	xor    %ecx,%ecx
 2a03f62:	mov    %rcx,0x250(%rsp)
 2a03f6a:	test   %r8d,%r8d
 2a03f6d:	je     2a1911c <wasm[0]::function[1015]::helper::object_read+0x1afbc>
 2a03f73:	test   %r8d,%r8d
 2a03f76:	je     2a1911e <wasm[0]::function[1015]::helper::object_read+0x1afbe>
 2a03f7c:	mov    0x2e0(%rsp),%r14
 2a03f84:	mov    0x28(%r14),%rax
 2a03f88:	mov    0x20(%r14),%rcx
 2a03f8c:	mov    %r8d,%r12d
 2a03f8f:	lea    (%rcx,%r12,1),%r10
 2a03f93:	xor    %rbx,%rbx
 2a03f96:	cmp    %rax,%r12
 2a03f99:	cmova  %rbx,%r10
 2a03f9d:	mov    0x10(%r10),%r10d
 2a03fa1:	test   %r10d,%r10d
 2a03fa4:	je     2a19120 <wasm[0]::function[1015]::helper::object_read+0x1afc0>
 2a03faa:	test   %r10d,%r10d
 2a03fad:	je     2a19122 <wasm[0]::function[1015]::helper::object_read+0x1afc2>
 2a03fb3:	mov    %r10d,%r12d
 2a03fb6:	lea    (%rcx,%r12,1),%r10
 2a03fba:	cmp    %rax,%r12
 2a03fbd:	cmova  %rbx,%r10
 2a03fc1:	mov    0x10(%r10),%r10d
 2a03fc5:	test   %r10d,%r10d
 2a03fc8:	je     2a19124 <wasm[0]::function[1015]::helper::object_read+0x1afc4>
 2a03fce:	test   %r10d,%r10d
 2a03fd1:	je     2a19126 <wasm[0]::function[1015]::helper::object_read+0x1afc6>
 2a03fd7:	mov    %r10d,%r12d
 2a03fda:	lea    0x10(%rcx,%r12,1),%rcx
 2a03fdf:	cmp    %rax,%r12
 2a03fe2:	cmova  %rbx,%rcx
 2a03fe6:	mov    (%rcx),%ebx
 2a03fe8:	mov    0xa0(%rsp),%r14d
 2a03ff0:	mov    0x190(%rsp),%rcx
 2a03ff8:	mov    0x28(%rcx),%rax
 2a03ffc:	mov    0x234(%rax),%r12d
 2a04003:	mov    0x250(%rsp),%rax
 2a0400b:	mov    %rax,0x218(%rsp)
 2a04013:	mov    %r10d,0x130(%rsp)
 2a0401b:	mov    %r14d,0xd8(%rsp)
 2a04023:	mov    %r8d,0x110(%rsp)
 2a0402b:	mov    0x220(%rsp),%rax
 2a04033:	mov    %eax,0x88(%rsp)
 2a0403a:	mov    %r13d,0x90(%rsp)
 2a04042:	mov    %edi,0x128(%rsp)
 2a04049:	mov    %r9d,0x108(%rsp)
 2a04051:	mov    %r11d,0x118(%rsp)
 2a04059:	mov    %r15d,0x100(%rsp)
 2a04061:	mov    %edx,0xa0(%rsp)
 2a04068:	mov    0x2e8(%rsp),%r15
 2a04070:	mov    (%r15),%rcx
 2a04073:	mov    0x228(%rsp),%rax
 2a0407b:	cmp    %rax,%rcx
 2a0407e:	jae    2a17ce1 <wasm[0]::function[1015]::helper::object_read+0x19b81>
 2a04084:	mov    0x110(%rsp),%r8d
 2a0408c:	mov    0x88(%rsp),%edi
 2a04093:	mov    %rdi,0x220(%rsp)
 2a0409b:	mov    0x90(%rsp),%r13d
 2a040a3:	mov    0x128(%rsp),%edi
 2a040aa:	mov    0x108(%rsp),%r9d
 2a040b2:	mov    0x118(%rsp),%r11d
 2a040ba:	mov    0x100(%rsp),%r15d
 2a040c2:	mov    0xa0(%rsp),%edx
 2a040c9:	mov    0x250(%rsp),%rcx
 2a040d1:	cmp    %ebx,%ecx
 2a040d3:	jb     2a040e6 <wasm[0]::function[1015]::helper::object_read+0x5f86>
 2a040d9:	mov    0x218(%rsp),%rax
 2a040e1:	jmp    2a042f9 <wasm[0]::function[1015]::helper::object_read+0x6199>
 2a040e6:	mov    0x130(%rsp),%eax
 2a040ed:	test   %eax,%eax
 2a040ef:	je     2a19128 <wasm[0]::function[1015]::helper::object_read+0x1afc8>
 2a040f5:	test   %eax,%eax
 2a040f7:	je     2a1912a <wasm[0]::function[1015]::helper::object_read+0x1afca>
 2a040fd:	mov    0x2e0(%rsp),%r14
 2a04105:	mov    0x28(%r14),%rdx
 2a04109:	mov    0x20(%r14),%rsi
 2a0410d:	mov    %eax,%r9d
 2a04110:	lea    0x10(%rsi,%r9,1),%r8
 2a04115:	xor    %rdi,%rdi
 2a04118:	cmp    %rdx,%r9
 2a0411b:	cmova  %rdi,%r8
 2a0411f:	mov    (%r8),%r8d
 2a04122:	cmp    %r8d,%ecx
 2a04125:	jae    2a1912c <wasm[0]::function[1015]::helper::object_read+0x1afcc>
 2a0412b:	mov    %r8d,%r9d
 2a0412e:	shl    $0x2,%r9
 2a04132:	shr    $0x20,%r9
 2a04136:	test   %r9,%r9
 2a04139:	jne    2a1912e <wasm[0]::function[1015]::helper::object_read+0x1afce>
 2a0413f:	shl    $0x2,%r8d
 2a04143:	add    $0x14,%r8d
 2a04147:	jb     2a19130 <wasm[0]::function[1015]::helper::object_read+0x1afd0>
 2a0414d:	add    %r8d,%eax
 2a04150:	jb     2a19132 <wasm[0]::function[1015]::helper::object_read+0x1afd2>
 2a04156:	mov    %eax,%r9d
 2a04159:	add    %r9,%rsi
 2a0415c:	cmp    %rdx,%r9
 2a0415f:	cmova  %rdi,%rsi
 2a04163:	mov    %rcx,%rdi
 2a04166:	shl    $0x2,%edi
 2a04169:	mov    %rcx,0x250(%rsp)
 2a04171:	add    $0x14,%edi
 2a04177:	sub    %edi,%r8d
 2a0417a:	sub    %r8,%rsi
 2a0417d:	mov    (%rsi),%edx
 2a0417f:	test   %edx,%edx
 2a04181:	je     2a19134 <wasm[0]::function[1015]::helper::object_read+0x1afd4>
 2a04187:	mov    0xd8(%rsp),%eax
 2a0418e:	cmp    %eax,%edx
 2a04190:	je     2a04264 <wasm[0]::function[1015]::helper::object_read+0x6104>
 2a04196:	xor    %r10d,%r10d
 2a04199:	test   %edx,%edx
 2a0419b:	je     2a041dd <wasm[0]::function[1015]::helper::object_read+0x607d>
 2a041a1:	xor    %r10d,%r10d
 2a041a4:	test   $0x1,%edx
 2a041aa:	jne    2a041dd <wasm[0]::function[1015]::helper::object_read+0x607d>
 2a041b0:	mov    0x2e0(%rsp),%r14
 2a041b8:	mov    0x28(%r14),%rcx
 2a041bc:	mov    0x20(%r14),%rsi
 2a041c0:	mov    %edx,%edi
 2a041c2:	lea    0x4(%rsi,%rdi,1),%rsi
 2a041c7:	xor    %r8,%r8
 2a041ca:	cmp    %rcx,%rdi
 2a041cd:	cmova  %r8,%rsi
 2a041d1:	mov    (%rsi),%ecx
 2a041d3:	cmp    %r12d,%ecx
 2a041d6:	sete   %cl
 2a041d9:	movzbl %cl,%r10d
 2a041dd:	test   %r10d,%r10d
 2a041e0:	je     2a19136 <wasm[0]::function[1015]::helper::object_read+0x1afd6>
 2a041e6:	xor    %ecx,%ecx
 2a041e8:	test   %eax,%eax
 2a041ea:	je     2a04230 <wasm[0]::function[1015]::helper::object_read+0x60d0>
 2a041f0:	mov    0xd8(%rsp),%eax
 2a041f7:	xor    %ecx,%ecx
 2a041f9:	test   $0x1,%eax
 2a041fe:	jne    2a04230 <wasm[0]::function[1015]::helper::object_read+0x60d0>
 2a04204:	mov    0x2e0(%rsp),%r14
 2a0420c:	mov    0x28(%r14),%rcx
 2a04210:	mov    0x20(%r14),%rdi
 2a04214:	mov    %eax,%esi
 2a04216:	lea    0x4(%rdi,%rsi,1),%rax
 2a0421b:	xor    %rdi,%rdi
 2a0421e:	cmp    %rcx,%rsi
 2a04221:	cmova  %rdi,%rax
 2a04225:	mov    (%rax),%eax
 2a04227:	cmp    %r12d,%eax
 2a0422a:	sete   %al
 2a0422d:	movzbl %al,%ecx
 2a04230:	test   %ecx,%ecx
 2a04232:	je     2a19138 <wasm[0]::function[1015]::helper::object_read+0x1afd8>
 2a04238:	mov    0xd8(%rsp),%ecx
 2a0423f:	xor    %r8d,%r8d
 2a04242:	test   %ecx,%ecx
 2a04244:	je     2a1913a <wasm[0]::function[1015]::helper::object_read+0x1afda>
 2a0424a:	mov    0x190(%rsp),%rsi
 2a04252:	mov    0x190(%rsp),%rdi
 2a0425a:	call   2b02800 <wasm[0]::function[1057]::helper::string_equality>
 2a0425f:	jmp    2a0426c <wasm[0]::function[1015]::helper::object_read+0x610c>
 2a04264:	mov    0x278(%rsp),%rax
 2a0426c:	mov    0x130(%rsp),%r10d
 2a04274:	mov    0xd8(%rsp),%r14d
 2a0427c:	mov    0x110(%rsp),%r8d
 2a04284:	mov    0x88(%rsp),%edi
 2a0428b:	mov    %rdi,0x220(%rsp)
 2a04293:	mov    0x90(%rsp),%r13d
 2a0429b:	mov    0x128(%rsp),%edi
 2a042a2:	mov    0x108(%rsp),%r9d
 2a042aa:	mov    0x118(%rsp),%r11d
 2a042b2:	mov    0x100(%rsp),%r15d
 2a042ba:	mov    0xa0(%rsp),%edx
 2a042c1:	test   %eax,%eax
 2a042c3:	je     2a042d6 <wasm[0]::function[1015]::helper::object_read+0x6176>
 2a042c9:	mov    0x250(%rsp),%rcx
 2a042d1:	jmp    2a042f9 <wasm[0]::function[1015]::helper::object_read+0x6199>
 2a042d6:	mov    0x250(%rsp),%rcx
 2a042de:	add    $0x1,%ecx
 2a042e4:	mov    %rax,0x218(%rsp)
 2a042ec:	mov    %rcx,0x250(%rsp)
 2a042f4:	jmp    2a04013 <wasm[0]::function[1015]::helper::object_read+0x5eb3>
 2a042f9:	xor    %r10,%r10
 2a042fc:	xor    %ebx,%ebx
 2a042fe:	test   %eax,%eax
 2a04300:	jne    2a0431b <wasm[0]::function[1015]::helper::object_read+0x61bb>
 2a04306:	mov    %r10,0x240(%rsp)
 2a0430e:	mov    %rbx,0x248(%rsp)
 2a04316:	jmp    2a04745 <wasm[0]::function[1015]::helper::object_read+0x65e5>
 2a0431b:	test   %r8d,%r8d
 2a0431e:	je     2a1913c <wasm[0]::function[1015]::helper::object_read+0x1afdc>
 2a04324:	xor    %eax,%eax
 2a04326:	test   $0x1,%r8d
 2a0432d:	jne    2a04370 <wasm[0]::function[1015]::helper::object_read+0x6210>
 2a04333:	mov    0x2e0(%rsp),%r14
 2a0433b:	mov    0x28(%r14),%rax
 2a0433f:	mov    0x20(%r14),%r10
 2a04343:	mov    %r8d,%ebx
 2a04346:	lea    0x4(%r10,%rbx,1),%r10
 2a0434b:	xor    %r12,%r12
 2a0434e:	cmp    %rax,%rbx
 2a04351:	cmova  %r12,%r10
 2a04355:	mov    (%r10),%eax
 2a04358:	mov    0x190(%rsp),%rsi
 2a04360:	mov    0x28(%rsi),%rsi
 2a04364:	cmp    0x160(%rsi),%eax
 2a0436a:	sete   %al
 2a0436d:	movzbl %al,%eax
 2a04370:	test   %eax,%eax
 2a04372:	jne    2a045ce <wasm[0]::function[1015]::helper::object_read+0x646e>
 2a04378:	xor    %eax,%eax
 2a0437a:	test   $0x1,%r8d
 2a04381:	jne    2a043c7 <wasm[0]::function[1015]::helper::object_read+0x6267>
 2a04387:	mov    0x2e0(%rsp),%r14
 2a0438f:	mov    0x28(%r14),%r10
 2a04393:	mov    0x20(%r14),%rax
 2a04397:	mov    %r8d,%ebx
 2a0439a:	lea    0x4(%rax,%rbx,1),%rax
 2a0439f:	xor    %r12,%r12
 2a043a2:	cmp    %r10,%rbx
 2a043a5:	cmova  %r12,%rax
 2a043a9:	mov    (%rax),%r10d
 2a043ac:	mov    0x190(%rsp),%rax
 2a043b4:	mov    0x28(%rax),%rsi
 2a043b8:	cmp    0x15c(%rsi),%r10d
 2a043bf:	sete   %sil
 2a043c3:	movzbl %sil,%eax
 2a043c7:	test   %eax,%eax
 2a043c9:	je     2a1913e <wasm[0]::function[1015]::helper::object_read+0x1afde>
 2a043cf:	test   %r8d,%r8d
 2a043d2:	je     2a19140 <wasm[0]::function[1015]::helper::object_read+0x1afe0>
 2a043d8:	mov    0x2e0(%rsp),%r14
 2a043e0:	mov    0x28(%r14),%rax
 2a043e4:	mov    0x20(%r14),%r13
 2a043e8:	mov    %r8d,%r12d
 2a043eb:	lea    0x0(%r13,%r12,1),%r8
 2a043f0:	xor    %r10,%r10
 2a043f3:	cmp    %rax,%r12
 2a043f6:	cmova  %r10,%r8
 2a043fa:	mov    0x14(%r8),%ebx
 2a043fe:	mov    0x18(%r8),%r12d
 2a04402:	mov    0x1c(%r8),%r8d
 2a04406:	test   %ebx,%ebx
 2a04408:	je     2a19142 <wasm[0]::function[1015]::helper::object_read+0x1afe2>
 2a0440e:	test   %ebx,%ebx
 2a04410:	je     2a19144 <wasm[0]::function[1015]::helper::object_read+0x1afe4>
 2a04416:	mov    %ebx,%esi
 2a04418:	lea    0x10(%r13,%rsi,1),%r14
 2a0441d:	cmp    %rax,%rsi
 2a04420:	cmova  %r10,%r14
 2a04424:	mov    (%r14),%r14d
 2a04427:	cmp    %r14d,%ecx
 2a0442a:	jae    2a19146 <wasm[0]::function[1015]::helper::object_read+0x1afe6>
 2a04430:	mov    %r14d,%esi
 2a04433:	shr    $0x20,%rsi
 2a04437:	test   %rsi,%rsi
 2a0443a:	jne    2a19148 <wasm[0]::function[1015]::helper::object_read+0x1afe8>
 2a04440:	add    $0x14,%r14d
 2a04444:	jb     2a1914a <wasm[0]::function[1015]::helper::object_read+0x1afea>
 2a0444a:	add    %r14d,%ebx
 2a0444d:	jb     2a1914c <wasm[0]::function[1015]::helper::object_read+0x1afec>
 2a04453:	mov    %ebx,%esi
 2a04455:	lea    0x0(%r13,%rsi,1),%rbx
 2a0445a:	cmp    %rax,%rsi
 2a0445d:	cmova  %r10,%rbx
 2a04461:	lea    0x14(%rcx),%eax
 2a04464:	sub    %eax,%r14d
 2a04467:	sub    %r14,%rbx
 2a0446a:	movzbq (%rbx),%rsi
 2a0446e:	mov    %rsi,0x258(%rsp)
 2a04476:	test   %r12d,%r12d
 2a04479:	je     2a0450c <wasm[0]::function[1015]::helper::object_read+0x63ac>
 2a0447f:	test   %r12d,%r12d
 2a04482:	je     2a1914e <wasm[0]::function[1015]::helper::object_read+0x1afee>
 2a04488:	test   %r12d,%r12d
 2a0448b:	je     2a19150 <wasm[0]::function[1015]::helper::object_read+0x1aff0>
 2a04491:	mov    0x2e0(%rsp),%r14
 2a04499:	mov    0x28(%r14),%rax
 2a0449d:	mov    0x20(%r14),%r10
 2a044a1:	mov    %r12d,%ebx
 2a044a4:	lea    0x10(%r10,%rbx,1),%r14
 2a044a9:	xor    %r13,%r13
 2a044ac:	cmp    %rax,%rbx
 2a044af:	cmova  %r13,%r14
 2a044b3:	mov    (%r14),%r14d
 2a044b6:	cmp    %r14d,%ecx
 2a044b9:	jae    2a19152 <wasm[0]::function[1015]::helper::object_read+0x1aff2>
 2a044bf:	mov    %r14d,%ebx
 2a044c2:	shl    $0x3,%rbx
 2a044c6:	shr    $0x20,%rbx
 2a044ca:	test   %rbx,%rbx
 2a044cd:	jne    2a19154 <wasm[0]::function[1015]::helper::object_read+0x1aff4>
 2a044d3:	shl    $0x3,%r14d
 2a044d7:	add    $0x18,%r14d
 2a044db:	jb     2a19156 <wasm[0]::function[1015]::helper::object_read+0x1aff6>
 2a044e1:	add    %r14d,%r12d
 2a044e4:	jb     2a19158 <wasm[0]::function[1015]::helper::object_read+0x1aff8>
 2a044ea:	mov    %r12d,%esi
 2a044ed:	add    %rsi,%r10
 2a044f0:	cmp    %rax,%rsi
 2a044f3:	cmova  %r13,%r10
 2a044f7:	mov    %rcx,%rax
 2a044fa:	shl    $0x3,%eax
 2a044fd:	add    $0x18,%eax
 2a04503:	sub    %eax,%r14d
 2a04506:	sub    %r14,%r10
 2a04509:	mov    (%r10),%r10
 2a0450c:	xor    %r13d,%r13d
 2a0450f:	test   %r8d,%r8d
 2a04512:	jne    2a04525 <wasm[0]::function[1015]::helper::object_read+0x63c5>
 2a04518:	mov    0x258(%rsp),%rsi
 2a04520:	jmp    2a045b5 <wasm[0]::function[1015]::helper::object_read+0x6455>
 2a04525:	test   %r8d,%r8d
 2a04528:	je     2a1915a <wasm[0]::function[1015]::helper::object_read+0x1affa>
 2a0452e:	test   %r8d,%r8d
 2a04531:	je     2a1915c <wasm[0]::function[1015]::helper::object_read+0x1affc>
 2a04537:	mov    0x2e0(%rsp),%r14
 2a0453f:	mov    0x28(%r14),%rax
 2a04543:	mov    0x20(%r14),%r12
 2a04547:	mov    %r8d,%ebx
 2a0454a:	lea    0x10(%r12,%rbx,1),%r14
 2a0454f:	xor    %r13,%r13
 2a04552:	cmp    %rax,%rbx
 2a04555:	cmova  %r13,%r14
 2a04559:	mov    (%r14),%r14d
 2a0455c:	cmp    %r14d,%ecx
 2a0455f:	jae    2a1915e <wasm[0]::function[1015]::helper::object_read+0x1affe>
 2a04565:	mov    %r14d,%ebx
 2a04568:	shl    $0x2,%rbx
 2a0456c:	shr    $0x20,%rbx
 2a04570:	test   %rbx,%rbx
 2a04573:	jne    2a19160 <wasm[0]::function[1015]::helper::object_read+0x1b000>
 2a04579:	shl    $0x2,%r14d
 2a0457d:	add    $0x14,%r14d
 2a04581:	jb     2a19162 <wasm[0]::function[1015]::helper::object_read+0x1b002>
 2a04587:	add    %r14d,%r8d
 2a0458a:	jb     2a19164 <wasm[0]::function[1015]::helper::object_read+0x1b004>
 2a04590:	mov    %r8d,%esi
 2a04593:	lea    (%r12,%rsi,1),%r8
 2a04597:	cmp    %rax,%rsi
 2a0459a:	cmova  %r13,%r8
 2a0459e:	shl    $0x2,%ecx
 2a045a1:	lea    0x14(%rcx),%eax
 2a045a4:	sub    %eax,%r14d
 2a045a7:	sub    %r14,%r8
 2a045aa:	mov    (%r8),%r13d
 2a045ad:	mov    0x258(%rsp),%rsi
 2a045b5:	movzbl %sil,%ebx
 2a045b9:	mov    %r10,0x240(%rsp)
 2a045c1:	mov    %rbx,0x248(%rsp)
 2a045c9:	jmp    2a04745 <wasm[0]::function[1015]::helper::object_read+0x65e5>
 2a045ce:	xor    %eax,%eax
 2a045d0:	test   $0x1,%r8d
 2a045d7:	jne    2a0461a <wasm[0]::function[1015]::helper::object_read+0x64ba>
 2a045dd:	mov    0x2e0(%rsp),%r14
 2a045e5:	mov    0x28(%r14),%rax
 2a045e9:	mov    0x20(%r14),%rsi
 2a045ed:	mov    %r8d,%ebx
 2a045f0:	lea    0x4(%rsi,%rbx,1),%r10
 2a045f5:	xor    %r12,%r12
 2a045f8:	cmp    %rax,%rbx
 2a045fb:	cmova  %r12,%r10
 2a045ff:	mov    (%r10),%eax
 2a04602:	mov    0x190(%rsp),%rsi
 2a0460a:	mov    0x28(%rsi),%rsi
 2a0460e:	cmp    0x160(%rsi),%eax
 2a04614:	sete   %al
 2a04617:	movzbl %al,%eax
 2a0461a:	test   %eax,%eax
 2a0461c:	je     2a19166 <wasm[0]::function[1015]::helper::object_read+0x1b006>
 2a04622:	test   %r8d,%r8d
 2a04625:	je     2a19168 <wasm[0]::function[1015]::helper::object_read+0x1b008>
 2a0462b:	mov    0x2e0(%rsp),%r14
 2a04633:	mov    0x28(%r14),%r10
 2a04637:	mov    0x20(%r14),%rax
 2a0463b:	mov    %r8d,%r8d
 2a0463e:	lea    (%rax,%r8,1),%rbx
 2a04642:	xor    %r12,%r12
 2a04645:	cmp    %r10,%r8
 2a04648:	cmova  %r12,%rbx
 2a0464c:	mov    0x10(%rbx),%r13d
 2a04650:	test   %r13d,%r13d
 2a04653:	je     2a1916a <wasm[0]::function[1015]::helper::object_read+0x1b00a>
 2a04659:	test   %r13d,%r13d
 2a0465c:	je     2a1916c <wasm[0]::function[1015]::helper::object_read+0x1b00c>
 2a04662:	mov    %r13d,%esi
 2a04665:	lea    (%rax,%rsi,1),%r13
 2a04669:	cmp    %r10,%rsi
 2a0466c:	cmova  %r12,%r13
 2a04670:	mov    0x10(%r13),%r13d
 2a04674:	test   %r13d,%r13d
 2a04677:	je     2a1916e <wasm[0]::function[1015]::helper::object_read+0x1b00e>
 2a0467d:	test   %r13d,%r13d
 2a04680:	je     2a19170 <wasm[0]::function[1015]::helper::object_read+0x1b010>
 2a04686:	mov    %r13d,%esi
 2a04689:	lea    0x10(%rax,%rsi,1),%rax
 2a0468e:	cmp    %r10,%rsi
 2a04691:	cmova  %r12,%rax
 2a04695:	cmp    (%rax),%ecx
 2a04697:	setae  %al
 2a0469a:	cmp    $0x2,%ecx
 2a0469d:	setae  %sil
 2a046a1:	or     %esi,%eax
 2a046a3:	test   %al,%al
 2a046a5:	jne    2a19172 <wasm[0]::function[1015]::helper::object_read+0x1b012>
 2a046ab:	mov    0x2e0(%rsp),%r14
 2a046b3:	mov    0x28(%r14),%r10
 2a046b7:	mov    %r8,%rax
 2a046ba:	add    0x20(%r14),%rax
 2a046be:	xor    %rbx,%rbx
 2a046c1:	cmp    %r10,%r8
 2a046c4:	cmova  %rbx,%rax
 2a046c8:	mov    0x14(%rax),%ebx
 2a046cb:	test   %ecx,%ecx
 2a046cd:	je     2a04705 <wasm[0]::function[1015]::helper::object_read+0x65a5>
 2a046d3:	mov    0x2e0(%rsp),%r14
 2a046db:	mov    0x28(%r14),%r10
 2a046df:	mov    0x20(%r14),%rax
 2a046e3:	add    %r8,%rax
 2a046e6:	xor    %r12,%r12
 2a046e9:	cmp    %r10,%r8
 2a046ec:	cmova  %r12,%rax
 2a046f0:	mov    0x20(%rax),%r10
 2a046f4:	mov    0x2c(%rax),%r13d
 2a046f8:	mov    %r10,0x240(%rsp)
 2a04700:	jmp    2a04732 <wasm[0]::function[1015]::helper::object_read+0x65d2>
 2a04705:	mov    0x2e0(%rsp),%r14
 2a0470d:	mov    0x28(%r14),%r10
 2a04711:	mov    0x20(%r14),%rax
 2a04715:	add    %r8,%rax
 2a04718:	xor    %r12,%r12
 2a0471b:	cmp    %r10,%r8
 2a0471e:	cmova  %r12,%rax
 2a04722:	mov    0x18(%rax),%r10
 2a04726:	mov    %r10,0x240(%rsp)
 2a0472e:	mov    0x28(%rax),%r13d
 2a04732:	shl    $0x3,%ecx
 2a04735:	shr    %cl,%ebx
 2a04737:	and    $0xff,%ebx
 2a0473d:	mov    %rbx,0x248(%rsp)
 2a04745:	mov    0x220(%rsp),%r10
 2a0474d:	mov    %r10d,0x108(%rsp)
 2a04755:	mov    %r13d,0x128(%rsp)
 2a0475d:	mov    %edi,0x90(%rsp)
 2a04764:	mov    %r9d,0x88(%rsp)
 2a0476c:	mov    %r11d,0x110(%rsp)
 2a04774:	mov    %r15d,0xd8(%rsp)
 2a0477c:	mov    %edx,0x130(%rsp)
 2a04783:	mov    $0x285,%edx
 2a04788:	mov    0x190(%rsp),%rsi
 2a04790:	mov    0x190(%rsp),%rdi
 2a04798:	call   2f4f240 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 2a0479d:	mov    %eax,0x118(%rsp)
 2a047a4:	xor    %r12d,%r12d
 2a047a7:	test   %eax,%eax
 2a047a9:	je     2a19174 <wasm[0]::function[1015]::helper::object_read+0x1b014>
 2a047af:	movl   $0x0,0x100(%rsp)
 2a047ba:	mov    0x108(%rsp),%edx
 2a047c1:	mov    %rdx,0x198(%rsp)
 2a047c9:	mov    0x128(%rsp),%esi
 2a047d0:	mov    %rsi,0x1a0(%rsp)
 2a047d8:	mov    0x90(%rsp),%r13d
 2a047e0:	mov    0x88(%rsp),%esi
 2a047e7:	mov    0x110(%rsp),%edi
 2a047ee:	mov    0xd8(%rsp),%r8d
 2a047f6:	mov    0x130(%rsp),%r9d
 2a047fe:	xor    %rbx,%rbx
 2a04801:	mov    0x2a0(%rsp),%rcx
 2a04809:	test   %cl,%cl
 2a0480b:	jne    2a04831 <wasm[0]::function[1015]::helper::object_read+0x66d1>
 2a04811:	mov    0x198(%rsp),%rdx
 2a04819:	mov    %r12,%r15
 2a0481c:	mov    %r12,0x230(%rsp)
 2a04824:	mov    %rbx,0x238(%rsp)
 2a0482c:	jmp    2a05471 <wasm[0]::function[1015]::helper::object_read+0x7311>
 2a04831:	mov    0x108(%rsp),%r8d
 2a04839:	mov    0x2b8(%rsp),%rcx
 2a04841:	mov    0x2a8(%rsp),%rdx
 2a04849:	mov    0x190(%rsp),%rsi
 2a04851:	mov    0x190(%rsp),%rdi
 2a04859:	call   2a7c940 <wasm[0]::function[1039]::helper::object_header_projection>
 2a0485e:	mov    %eax,0xa0(%rsp)
 2a04865:	test   %eax,%eax
 2a04867:	je     2a19176 <wasm[0]::function[1015]::helper::object_read+0x1b016>
 2a0486d:	test   %eax,%eax
 2a0486f:	je     2a19178 <wasm[0]::function[1015]::helper::object_read+0x1b018>
 2a04875:	mov    0x2e0(%rsp),%r14
 2a0487d:	mov    0x28(%r14),%rcx
 2a04881:	mov    0x20(%r14),%rsi
 2a04885:	mov    %eax,%edx
 2a04887:	lea    (%rsi,%rdx,1),%rax
 2a0488b:	xor    %rsi,%rsi
 2a0488e:	cmp    %rcx,%rdx
 2a04891:	cmova  %rsi,%rax
 2a04895:	mov    0x14(%rax),%eax
 2a04898:	mov    %eax,0xc8(%rsp)
 2a0489f:	test   %eax,%eax
 2a048a1:	je     2a1917a <wasm[0]::function[1015]::helper::object_read+0x1b01a>
 2a048a7:	mov    0xc8(%rsp),%ecx
 2a048ae:	xor    %eax,%eax
 2a048b0:	test   $0x1,%ecx
 2a048b6:	jne    2a0490e <wasm[0]::function[1015]::helper::object_read+0x67ae>
 2a048bc:	mov    0x2e0(%rsp),%r14
 2a048c4:	mov    0x28(%r14),%rax
 2a048c8:	mov    0x20(%r14),%rsi
 2a048cc:	mov    %ecx,%edx
 2a048ce:	lea    0x4(%rsi,%rdx,1),%rcx
 2a048d3:	xor    %rsi,%rsi
 2a048d6:	cmp    %rax,%rdx
 2a048d9:	cmova  %rsi,%rcx
 2a048dd:	mov    (%rcx),%esi
 2a048df:	mov    0x190(%rsp),%rcx
 2a048e7:	mov    0x28(%rcx),%rax
 2a048eb:	mov    0x158(%rax),%edx
 2a048f1:	cmp    %edx,%esi
 2a048f3:	sete   %al
 2a048f6:	movzbl %al,%eax
 2a048f9:	cmp    %edx,%esi
 2a048fb:	je     2a0490e <wasm[0]::function[1015]::helper::object_read+0x67ae>
 2a04901:	mov    0x190(%rsp),%rdi
 2a04909:	call   3039cc5 <wasmtime_builtin_is_subtype>
 2a0490e:	test   %eax,%eax
 2a04910:	jne    2a04b71 <wasm[0]::function[1015]::helper::object_read+0x6a11>
 2a04916:	mov    0xa0(%rsp),%edx
 2a0491d:	xor    %r13d,%r13d
 2a04920:	test   %edx,%edx
 2a04922:	je     2a1917c <wasm[0]::function[1015]::helper::object_read+0x1b01c>
 2a04928:	mov    0x118(%rsp),%r9d
 2a04930:	mov    $0x4,%ecx
 2a04935:	xor    %r8,%r8
 2a04938:	mov    0x190(%rsp),%rsi
 2a04940:	mov    0x190(%rsp),%rdi
 2a04948:	call   2a76140 <wasm[0]::function[1032]::helper::ordinary_property_find>
 2a0494d:	test   %eax,%eax
 2a0494f:	je     2a04988 <wasm[0]::function[1015]::helper::object_read+0x6828>
 2a04955:	test   %eax,%eax
 2a04957:	je     2a1917e <wasm[0]::function[1015]::helper::object_read+0x1b01e>
 2a0495d:	test   %eax,%eax
 2a0495f:	je     2a19180 <wasm[0]::function[1015]::helper::object_read+0x1b020>
 2a04965:	mov    0x2e0(%rsp),%r14
 2a0496d:	mov    0x28(%r14),%rcx
 2a04971:	mov    %eax,%eax
 2a04973:	mov    %rax,%r10
 2a04976:	add    0x20(%r14),%r10
 2a0497a:	xor    %rdx,%rdx
 2a0497d:	cmp    %rcx,%rax
 2a04980:	cmova  %rdx,%r10
 2a04984:	mov    0x14(%r10),%r13d
 2a04988:	mov    0x100(%rsp),%r15d
 2a04990:	xor    %r12d,%r12d
 2a04993:	xor    %rbx,%rbx
 2a04996:	test   %r13d,%r13d
 2a04999:	je     2a04b18 <wasm[0]::function[1015]::helper::object_read+0x69b8>
 2a0499f:	test   %r13d,%r13d
 2a049a2:	je     2a19182 <wasm[0]::function[1015]::helper::object_read+0x1b022>
 2a049a8:	mov    0x2e0(%rsp),%r14
 2a049b0:	mov    0x28(%r14),%rcx
 2a049b4:	mov    0x20(%r14),%rax
 2a049b8:	mov    %r13d,%edx
 2a049bb:	add    %rdx,%rax
 2a049be:	xor    %rbx,%rbx
 2a049c1:	cmp    %rcx,%rdx
 2a049c4:	cmova  %rbx,%rax
 2a049c8:	mov    0x10(%rax),%ecx
 2a049cb:	mov    0x100(%rsp),%r15d
 2a049d3:	xor    %r12d,%r12d
 2a049d6:	test   $0x1,%ecx
 2a049dc:	jne    2a04b18 <wasm[0]::function[1015]::helper::object_read+0x69b8>
 2a049e2:	mov    0x14(%rax),%edx
 2a049e5:	test   %edx,%edx
 2a049e7:	je     2a19184 <wasm[0]::function[1015]::helper::object_read+0x1b024>
 2a049ed:	xor    %eax,%eax
 2a049ef:	test   $0x1,%edx
 2a049f5:	jne    2a04a36 <wasm[0]::function[1015]::helper::object_read+0x68d6>
 2a049fb:	mov    0x2e0(%rsp),%r14
 2a04a03:	mov    0x28(%r14),%rax
 2a04a07:	mov    0x20(%r14),%rcx
 2a04a0b:	mov    %edx,%esi
 2a04a0d:	lea    0x4(%rcx,%rsi,1),%rcx
 2a04a12:	xor    %rdi,%rdi
 2a04a15:	cmp    %rax,%rsi
 2a04a18:	cmova  %rdi,%rcx
 2a04a1c:	mov    (%rcx),%eax
 2a04a1e:	mov    0x190(%rsp),%rcx
 2a04a26:	mov    0x28(%rcx),%rcx
 2a04a2a:	cmp    0x120(%rcx),%eax
 2a04a30:	sete   %al
 2a04a33:	movzbl %al,%eax
 2a04a36:	test   %eax,%eax
 2a04a38:	jne    2a04a94 <wasm[0]::function[1015]::helper::object_read+0x6934>
 2a04a3e:	mov    0x190(%rsp),%rsi
 2a04a46:	mov    0x190(%rsp),%rdi
 2a04a4e:	call   2a1eec0 <wasm[0]::function[1024]::helper::property_value_resolve>
 2a04a53:	test   %eax,%eax
 2a04a55:	je     2a19186 <wasm[0]::function[1015]::helper::object_read+0x1b026>
 2a04a5b:	test   %eax,%eax
 2a04a5d:	je     2a19188 <wasm[0]::function[1015]::helper::object_read+0x1b028>
 2a04a63:	mov    0x2e0(%rsp),%r14
 2a04a6b:	mov    0x28(%r14),%rcx
 2a04a6f:	mov    0x20(%r14),%rsi
 2a04a73:	mov    %eax,%edx
 2a04a75:	lea    (%rsi,%rdx,1),%rax
 2a04a79:	xor    %rsi,%rsi
 2a04a7c:	cmp    %rcx,%rdx
 2a04a7f:	cmova  %rsi,%rax
 2a04a83:	mov    0x18(%rax),%r12d
 2a04a87:	mov    0x10(%rax),%rbx
 2a04a8b:	mov    0x1c(%rax),%r15d
 2a04a8f:	jmp    2a04b18 <wasm[0]::function[1015]::helper::object_read+0x69b8>
 2a04a94:	xor    %eax,%eax
 2a04a96:	test   $0x1,%edx
 2a04a9c:	jne    2a04add <wasm[0]::function[1015]::helper::object_read+0x697d>
 2a04aa2:	mov    0x2e0(%rsp),%r14
 2a04aaa:	mov    0x28(%r14),%rax
 2a04aae:	mov    0x20(%r14),%rcx
 2a04ab2:	mov    %edx,%esi
 2a04ab4:	lea    0x4(%rcx,%rsi,1),%rcx
 2a04ab9:	xor    %rdi,%rdi
 2a04abc:	cmp    %rax,%rsi
 2a04abf:	cmova  %rdi,%rcx
 2a04ac3:	mov    (%rcx),%eax
 2a04ac5:	mov    0x190(%rsp),%rcx
 2a04acd:	mov    0x28(%rcx),%rcx
 2a04ad1:	cmp    0x120(%rcx),%eax
 2a04ad7:	sete   %al
 2a04ada:	movzbl %al,%eax
 2a04add:	test   %eax,%eax
 2a04adf:	je     2a1918a <wasm[0]::function[1015]::helper::object_read+0x1b02a>
 2a04ae5:	test   %edx,%edx
 2a04ae7:	je     2a1918c <wasm[0]::function[1015]::helper::object_read+0x1b02c>
 2a04aed:	mov    0x2e0(%rsp),%r14
 2a04af5:	mov    0x28(%r14),%rcx
 2a04af9:	mov    0x20(%r14),%rax
 2a04afd:	mov    %edx,%edx
 2a04aff:	add    %rdx,%rax
 2a04b02:	xor    %rsi,%rsi
 2a04b05:	cmp    %rcx,%rdx
 2a04b08:	cmova  %rsi,%rax
 2a04b0c:	mov    0x18(%rax),%r12d
 2a04b10:	mov    0x10(%rax),%rbx
 2a04b14:	mov    0x1c(%rax),%r15d
 2a04b18:	mov    0x108(%rsp),%edx
 2a04b1f:	mov    %rdx,0x198(%rsp)
 2a04b27:	mov    0x128(%rsp),%esi
 2a04b2e:	mov    %rsi,0x1a0(%rsp)
 2a04b36:	mov    0x90(%rsp),%r13d
 2a04b3e:	mov    0x88(%rsp),%esi
 2a04b45:	mov    0x110(%rsp),%edi
 2a04b4c:	mov    0xd8(%rsp),%r8d
 2a04b54:	mov    0x130(%rsp),%r9d
 2a04b5c:	mov    %r12,0x230(%rsp)
 2a04b64:	mov    %rbx,0x238(%rsp)
 2a04b6c:	jmp    2a05469 <wasm[0]::function[1015]::helper::object_read+0x7309>
 2a04b71:	mov    0xc8(%rsp),%eax
 2a04b78:	test   %eax,%eax
 2a04b7a:	je     2a1918e <wasm[0]::function[1015]::helper::object_read+0x1b02e>
 2a04b80:	mov    0xc8(%rsp),%ecx
 2a04b87:	xor    %eax,%eax
 2a04b89:	test   $0x1,%ecx
 2a04b8f:	jne    2a04be9 <wasm[0]::function[1015]::helper::object_read+0x6a89>
 2a04b95:	mov    0x2e0(%rsp),%r14
 2a04b9d:	mov    0x28(%r14),%rax
 2a04ba1:	mov    0x20(%r14),%rsi
 2a04ba5:	mov    %ecx,%edx
 2a04ba7:	lea    0x4(%rsi,%rdx,1),%rcx
 2a04bac:	xor    %rsi,%rsi
 2a04baf:	cmp    %rax,%rdx
 2a04bb2:	cmova  %rsi,%rcx
 2a04bb6:	mov    (%rcx),%esi
 2a04bb8:	mov    0x190(%rsp),%rcx
 2a04bc0:	mov    0x28(%rcx),%rcx
 2a04bc4:	mov    0x158(%rcx),%edx
 2a04bca:	cmp    %edx,%esi
 2a04bcc:	sete   %dil
 2a04bd0:	movzbl %dil,%eax
 2a04bd4:	cmp    %edx,%esi
 2a04bd6:	je     2a04be9 <wasm[0]::function[1015]::helper::object_read+0x6a89>
 2a04bdc:	mov    0x190(%rsp),%rdi
 2a04be4:	call   3039cc5 <wasmtime_builtin_is_subtype>
 2a04be9:	test   %eax,%eax
 2a04beb:	je     2a19190 <wasm[0]::function[1015]::helper::object_read+0x1b030>
 2a04bf1:	mov    0xc8(%rsp),%r11d
 2a04bf9:	mov    0x108(%rsp),%edx
 2a04c00:	mov    %rdx,0x198(%rsp)
 2a04c08:	mov    0x100(%rsp),%r15d
 2a04c10:	mov    0x128(%rsp),%esi
 2a04c17:	mov    %rsi,0x1a0(%rsp)
 2a04c1f:	mov    0x90(%rsp),%r13d
 2a04c27:	mov    0x88(%rsp),%esi
 2a04c2e:	mov    0x110(%rsp),%edi
 2a04c35:	mov    0xd8(%rsp),%r8d
 2a04c3d:	mov    0x130(%rsp),%r9d
 2a04c45:	xor    %ecx,%ecx
 2a04c47:	mov    %rcx,0x218(%rsp)
 2a04c4f:	test   %r11d,%r11d
 2a04c52:	je     2a19192 <wasm[0]::function[1015]::helper::object_read+0x1b032>
 2a04c58:	test   %r11d,%r11d
 2a04c5b:	je     2a19194 <wasm[0]::function[1015]::helper::object_read+0x1b034>
 2a04c61:	mov    0x2e0(%rsp),%r14
 2a04c69:	mov    0x28(%r14),%rax
 2a04c6d:	mov    0x20(%r14),%rcx
 2a04c71:	mov    %r11d,%ebx
 2a04c74:	lea    (%rcx,%rbx,1),%r10
 2a04c78:	xor    %r14,%r14
 2a04c7b:	cmp    %rax,%rbx
 2a04c7e:	cmova  %r14,%r10
 2a04c82:	mov    0x10(%r10),%r10d
 2a04c86:	test   %r10d,%r10d
 2a04c89:	je     2a19196 <wasm[0]::function[1015]::helper::object_read+0x1b036>
 2a04c8f:	test   %r10d,%r10d
 2a04c92:	je     2a19198 <wasm[0]::function[1015]::helper::object_read+0x1b038>
 2a04c98:	mov    %r10d,%ebx
 2a04c9b:	lea    (%rcx,%rbx,1),%r10
 2a04c9f:	cmp    %rax,%rbx
 2a04ca2:	cmova  %r14,%r10
 2a04ca6:	mov    0x10(%r10),%ebx
 2a04caa:	test   %ebx,%ebx
 2a04cac:	je     2a1919a <wasm[0]::function[1015]::helper::object_read+0x1b03a>
 2a04cb2:	test   %ebx,%ebx
 2a04cb4:	je     2a1919c <wasm[0]::function[1015]::helper::object_read+0x1b03c>
 2a04cba:	mov    %ebx,%r10d
 2a04cbd:	lea    0x10(%rcx,%r10,1),%rcx
 2a04cc2:	cmp    %rax,%r10
 2a04cc5:	cmova  %r14,%rcx
 2a04cc9:	mov    (%rcx),%r12d
 2a04ccc:	mov    %r12,0x250(%rsp)
 2a04cd4:	mov    0x118(%rsp),%r14d
 2a04cdc:	mov    0x190(%rsp),%rcx
 2a04ce4:	mov    0x28(%rcx),%rax
 2a04ce8:	mov    0x234(%rax),%r12d
 2a04cef:	mov    0x218(%rsp),%rax
 2a04cf7:	mov    %rax,0x220(%rsp)
 2a04cff:	mov    %ebx,0xa0(%rsp)
 2a04d06:	mov    %r14d,0x130(%rsp)
 2a04d0e:	mov    %r11d,0xd8(%rsp)
 2a04d16:	mov    0x198(%rsp),%rdx
 2a04d1e:	mov    %edx,0x110(%rsp)
 2a04d25:	mov    %r15d,0x88(%rsp)
 2a04d2d:	mov    0x1a0(%rsp),%rax
 2a04d35:	mov    %eax,0x90(%rsp)
 2a04d3c:	mov    %r13d,0x128(%rsp)
 2a04d44:	mov    %esi,0x100(%rsp)
 2a04d4b:	mov    %edi,0x108(%rsp)
 2a04d52:	mov    %r8d,0xc8(%rsp)
 2a04d5a:	mov    %r9d,0x118(%rsp)
 2a04d62:	mov    0x2e8(%rsp),%r15
 2a04d6a:	mov    (%r15),%rcx
 2a04d6d:	mov    0x228(%rsp),%rax
 2a04d75:	cmp    %rax,%rcx
 2a04d78:	jae    2a17d18 <wasm[0]::function[1015]::helper::object_read+0x19bb8>
 2a04d7e:	mov    0xd8(%rsp),%r11d
 2a04d86:	mov    0x110(%rsp),%edx
 2a04d8d:	mov    %rdx,0x198(%rsp)
 2a04d95:	mov    0x88(%rsp),%r15d
 2a04d9d:	mov    0x90(%rsp),%esi
 2a04da4:	mov    %rsi,0x1a0(%rsp)
 2a04dac:	mov    0x128(%rsp),%r13d
 2a04db4:	mov    0x100(%rsp),%esi
 2a04dbb:	mov    0x108(%rsp),%edi
 2a04dc2:	mov    0xc8(%rsp),%r8d
 2a04dca:	mov    0x118(%rsp),%r9d
 2a04dd2:	mov    0x218(%rsp),%rcx
 2a04dda:	mov    0x250(%rsp),%r10
 2a04de2:	cmp    %r10d,%ecx
 2a04de5:	jb     2a04df8 <wasm[0]::function[1015]::helper::object_read+0x6c98>
 2a04deb:	mov    0x220(%rsp),%rax
 2a04df3:	jmp    2a05018 <wasm[0]::function[1015]::helper::object_read+0x6eb8>
 2a04df8:	mov    0xa0(%rsp),%eax
 2a04dff:	test   %eax,%eax
 2a04e01:	je     2a1919e <wasm[0]::function[1015]::helper::object_read+0x1b03e>
 2a04e07:	test   %eax,%eax
 2a04e09:	je     2a191a0 <wasm[0]::function[1015]::helper::object_read+0x1b040>
 2a04e0f:	mov    0x2e0(%rsp),%r14
 2a04e17:	mov    0x28(%r14),%rdx
 2a04e1b:	mov    0x20(%r14),%rsi
 2a04e1f:	mov    %eax,%r9d
 2a04e22:	lea    0x10(%rsi,%r9,1),%r8
 2a04e27:	xor    %rdi,%rdi
 2a04e2a:	cmp    %rdx,%r9
 2a04e2d:	cmova  %rdi,%r8
 2a04e31:	mov    (%r8),%r8d
 2a04e34:	cmp    %r8d,%ecx
 2a04e37:	jae    2a191a2 <wasm[0]::function[1015]::helper::object_read+0x1b042>
 2a04e3d:	mov    %r8d,%r9d
 2a04e40:	shl    $0x2,%r9
 2a04e44:	shr    $0x20,%r9
 2a04e48:	test   %r9,%r9
 2a04e4b:	jne    2a191a4 <wasm[0]::function[1015]::helper::object_read+0x1b044>
 2a04e51:	shl    $0x2,%r8d
 2a04e55:	add    $0x14,%r8d
 2a04e59:	jb     2a191a6 <wasm[0]::function[1015]::helper::object_read+0x1b046>
 2a04e5f:	add    %r8d,%eax
 2a04e62:	jb     2a191a8 <wasm[0]::function[1015]::helper::object_read+0x1b048>
 2a04e68:	mov    %eax,%r9d
 2a04e6b:	lea    (%rsi,%r9,1),%rax
 2a04e6f:	cmp    %rdx,%r9
 2a04e72:	cmova  %rdi,%rax
 2a04e76:	mov    %rcx,%rdx
 2a04e79:	shl    $0x2,%edx
 2a04e7c:	mov    %rcx,0x218(%rsp)
 2a04e84:	lea    0x14(%rdx),%ecx
 2a04e87:	sub    %ecx,%r8d
 2a04e8a:	sub    %r8,%rax
 2a04e8d:	mov    (%rax),%edx
 2a04e8f:	test   %edx,%edx
 2a04e91:	je     2a191aa <wasm[0]::function[1015]::helper::object_read+0x1b04a>
 2a04e97:	mov    0x130(%rsp),%ecx
 2a04e9e:	cmp    %ecx,%edx
 2a04ea0:	je     2a04f75 <wasm[0]::function[1015]::helper::object_read+0x6e15>
 2a04ea6:	xor    %eax,%eax
 2a04ea8:	test   %edx,%edx
 2a04eaa:	je     2a04eee <wasm[0]::function[1015]::helper::object_read+0x6d8e>
 2a04eb0:	xor    %eax,%eax
 2a04eb2:	test   $0x1,%edx
 2a04eb8:	jne    2a04eee <wasm[0]::function[1015]::helper::object_read+0x6d8e>
 2a04ebe:	mov    0x2e0(%rsp),%r14
 2a04ec6:	mov    0x28(%r14),%r9
 2a04eca:	mov    0x20(%r14),%r11
 2a04ece:	mov    %edx,%r10d
 2a04ed1:	lea    0x4(%r11,%r10,1),%rsi
 2a04ed6:	xor    %r11,%r11
 2a04ed9:	cmp    %r9,%r10
 2a04edc:	cmova  %r11,%rsi
 2a04ee0:	mov    (%rsi),%r10d
 2a04ee3:	cmp    %r12d,%r10d
 2a04ee6:	sete   %r11b
 2a04eea:	movzbl %r11b,%eax
 2a04eee:	test   %eax,%eax
 2a04ef0:	je     2a191ac <wasm[0]::function[1015]::helper::object_read+0x1b04c>
 2a04ef6:	xor    %eax,%eax
 2a04ef8:	test   %ecx,%ecx
 2a04efa:	je     2a04f41 <wasm[0]::function[1015]::helper::object_read+0x6de1>
 2a04f00:	mov    0x130(%rsp),%ecx
 2a04f07:	xor    %eax,%eax
 2a04f09:	test   $0x1,%ecx
 2a04f0f:	jne    2a04f41 <wasm[0]::function[1015]::helper::object_read+0x6de1>
 2a04f15:	mov    0x2e0(%rsp),%r14
 2a04f1d:	mov    0x28(%r14),%rax
 2a04f21:	mov    0x20(%r14),%rdi
 2a04f25:	mov    %ecx,%esi
 2a04f27:	lea    0x4(%rdi,%rsi,1),%rcx
 2a04f2c:	xor    %rdi,%rdi
 2a04f2f:	cmp    %rax,%rsi
 2a04f32:	cmova  %rdi,%rcx
 2a04f36:	mov    (%rcx),%eax
 2a04f38:	cmp    %r12d,%eax
 2a04f3b:	sete   %al
 2a04f3e:	movzbl %al,%eax
 2a04f41:	test   %eax,%eax
 2a04f43:	je     2a191ae <wasm[0]::function[1015]::helper::object_read+0x1b04e>
 2a04f49:	mov    0x130(%rsp),%ecx
 2a04f50:	xor    %r8d,%r8d
 2a04f53:	test   %ecx,%ecx
 2a04f55:	je     2a191b0 <wasm[0]::function[1015]::helper::object_read+0x1b050>
 2a04f5b:	mov    0x190(%rsp),%rsi
 2a04f63:	mov    0x190(%rsp),%rdi
 2a04f6b:	call   2b02800 <wasm[0]::function[1057]::helper::string_equality>
 2a04f70:	jmp    2a04f7d <wasm[0]::function[1015]::helper::object_read+0x6e1d>
 2a04f75:	mov    0x278(%rsp),%rax
 2a04f7d:	mov    0xa0(%rsp),%ebx
 2a04f84:	mov    0x130(%rsp),%r14d
 2a04f8c:	mov    0xd8(%rsp),%r11d
 2a04f94:	mov    0x110(%rsp),%edx
 2a04f9b:	mov    %rdx,0x198(%rsp)
 2a04fa3:	mov    0x88(%rsp),%r15d
 2a04fab:	mov    0x90(%rsp),%esi
 2a04fb2:	mov    %rsi,0x1a0(%rsp)
 2a04fba:	mov    0x128(%rsp),%r13d
 2a04fc2:	mov    0x100(%rsp),%esi
 2a04fc9:	mov    0x108(%rsp),%edi
 2a04fd0:	mov    0xc8(%rsp),%r8d
 2a04fd8:	mov    0x118(%rsp),%r9d
 2a04fe0:	test   %eax,%eax
 2a04fe2:	je     2a04ff5 <wasm[0]::function[1015]::helper::object_read+0x6e95>
 2a04fe8:	mov    0x218(%rsp),%rcx
 2a04ff0:	jmp    2a05018 <wasm[0]::function[1015]::helper::object_read+0x6eb8>
 2a04ff5:	mov    0x218(%rsp),%rcx
 2a04ffd:	add    $0x1,%ecx
 2a05003:	mov    %rcx,0x218(%rsp)
 2a0500b:	mov    %rax,0x220(%rsp)
 2a05013:	jmp    2a04cff <wasm[0]::function[1015]::helper::object_read+0x6b9f>
 2a05018:	xor    %r12d,%r12d
 2a0501b:	xor    %rbx,%rbx
 2a0501e:	test   %eax,%eax
 2a05020:	jne    2a0503b <wasm[0]::function[1015]::helper::object_read+0x6edb>
 2a05026:	mov    %r12,0x230(%rsp)
 2a0502e:	mov    %rbx,0x238(%rsp)
 2a05036:	jmp    2a05469 <wasm[0]::function[1015]::helper::object_read+0x7309>
 2a0503b:	test   %r11d,%r11d
 2a0503e:	je     2a191b2 <wasm[0]::function[1015]::helper::object_read+0x1b052>
 2a05044:	xor    %eax,%eax
 2a05046:	test   $0x1,%r11d
 2a0504d:	jne    2a05090 <wasm[0]::function[1015]::helper::object_read+0x6f30>
 2a05053:	mov    0x2e0(%rsp),%r14
 2a0505b:	mov    0x28(%r14),%rax
 2a0505f:	mov    0x20(%r14),%r10
 2a05063:	mov    %r11d,%ebx
 2a05066:	lea    0x4(%r10,%rbx,1),%r10
 2a0506b:	xor    %r12,%r12
 2a0506e:	cmp    %rax,%rbx
 2a05071:	cmova  %r12,%r10
 2a05075:	mov    (%r10),%eax
 2a05078:	mov    0x190(%rsp),%rdx
 2a05080:	mov    0x28(%rdx),%rdx
 2a05084:	cmp    0x160(%rdx),%eax
 2a0508a:	sete   %al
 2a0508d:	movzbl %al,%eax
 2a05090:	test   %eax,%eax
 2a05092:	jne    2a052e9 <wasm[0]::function[1015]::helper::object_read+0x7189>
 2a05098:	xor    %eax,%eax
 2a0509a:	test   $0x1,%r11d
 2a050a1:	jne    2a050e4 <wasm[0]::function[1015]::helper::object_read+0x6f84>
 2a050a7:	mov    0x2e0(%rsp),%r14
 2a050af:	mov    0x28(%r14),%rax
 2a050b3:	mov    0x20(%r14),%r10
 2a050b7:	mov    %r11d,%ebx
 2a050ba:	lea    0x4(%r10,%rbx,1),%r10
 2a050bf:	xor    %r12,%r12
 2a050c2:	cmp    %rax,%rbx
 2a050c5:	cmova  %r12,%r10
 2a050c9:	mov    (%r10),%eax
 2a050cc:	mov    0x190(%rsp),%rdx
 2a050d4:	mov    0x28(%rdx),%rdx
 2a050d8:	cmp    0x15c(%rdx),%eax
 2a050de:	sete   %al
 2a050e1:	movzbl %al,%eax
 2a050e4:	test   %eax,%eax
 2a050e6:	je     2a191b4 <wasm[0]::function[1015]::helper::object_read+0x1b054>
 2a050ec:	test   %r11d,%r11d
 2a050ef:	je     2a191b6 <wasm[0]::function[1015]::helper::object_read+0x1b056>
 2a050f5:	mov    0x2e0(%rsp),%r14
 2a050fd:	mov    0x28(%r14),%r12
 2a05101:	mov    0x20(%r14),%r14
 2a05105:	mov    %r11d,%eax
 2a05108:	lea    (%r14,%rax,1),%r10
 2a0510c:	xor    %rbx,%rbx
 2a0510f:	cmp    %r12,%rax
 2a05112:	cmova  %rbx,%r10
 2a05116:	mov    0x14(%r10),%r15d
 2a0511a:	mov    0x18(%r10),%eax
 2a0511e:	mov    0x1c(%r10),%r11d
 2a05122:	test   %r15d,%r15d
 2a05125:	je     2a191b8 <wasm[0]::function[1015]::helper::object_read+0x1b058>
 2a0512b:	test   %r15d,%r15d
 2a0512e:	je     2a191ba <wasm[0]::function[1015]::helper::object_read+0x1b05a>
 2a05134:	mov    %r15d,%edx
 2a05137:	lea    0x10(%r14,%rdx,1),%r10
 2a0513c:	cmp    %r12,%rdx
 2a0513f:	cmova  %rbx,%r10
 2a05143:	mov    (%r10),%r10d
 2a05146:	cmp    %r10d,%ecx
 2a05149:	jae    2a191bc <wasm[0]::function[1015]::helper::object_read+0x1b05c>
 2a0514f:	mov    %r10d,%edx
 2a05152:	shr    $0x20,%rdx
 2a05156:	test   %rdx,%rdx
 2a05159:	jne    2a191be <wasm[0]::function[1015]::helper::object_read+0x1b05e>
 2a0515f:	add    $0x14,%r10d
 2a05163:	jb     2a191c0 <wasm[0]::function[1015]::helper::object_read+0x1b060>
 2a05169:	add    %r10d,%r15d
 2a0516c:	jb     2a191c2 <wasm[0]::function[1015]::helper::object_read+0x1b062>
 2a05172:	mov    %r15d,%edx
 2a05175:	add    %rdx,%r14
 2a05178:	cmp    %r12,%rdx
 2a0517b:	cmova  %rbx,%r14
 2a0517f:	lea    0x14(%rcx),%edx
 2a05182:	sub    %edx,%r10d
 2a05185:	sub    %r10,%r14
 2a05188:	movzbq (%r14),%r10
 2a0518c:	mov    %r10,0x220(%rsp)
 2a05194:	test   %eax,%eax
 2a05196:	je     2a05227 <wasm[0]::function[1015]::helper::object_read+0x70c7>
 2a0519c:	test   %eax,%eax
 2a0519e:	je     2a191c4 <wasm[0]::function[1015]::helper::object_read+0x1b064>
 2a051a4:	test   %eax,%eax
 2a051a6:	je     2a191c6 <wasm[0]::function[1015]::helper::object_read+0x1b066>
 2a051ac:	mov    0x2e0(%rsp),%r14
 2a051b4:	mov    0x28(%r14),%rbx
 2a051b8:	mov    0x20(%r14),%r14
 2a051bc:	mov    %eax,%r12d
 2a051bf:	lea    0x10(%r14,%r12,1),%r10
 2a051c4:	xor    %r15,%r15
 2a051c7:	cmp    %rbx,%r12
 2a051ca:	cmova  %r15,%r10
 2a051ce:	mov    (%r10),%r12d
 2a051d1:	cmp    %r12d,%ecx
 2a051d4:	jae    2a191c8 <wasm[0]::function[1015]::helper::object_read+0x1b068>
 2a051da:	mov    %r12d,%r10d
 2a051dd:	shl    $0x3,%r10
 2a051e1:	shr    $0x20,%r10
 2a051e5:	test   %r10,%r10
 2a051e8:	jne    2a191ca <wasm[0]::function[1015]::helper::object_read+0x1b06a>
 2a051ee:	shl    $0x3,%r12d
 2a051f2:	add    $0x18,%r12d
 2a051f6:	jb     2a191cc <wasm[0]::function[1015]::helper::object_read+0x1b06c>
 2a051fc:	add    %r12d,%eax
 2a051ff:	jb     2a191ce <wasm[0]::function[1015]::helper::object_read+0x1b06e>
 2a05205:	mov    %eax,%edx
 2a05207:	lea    (%r14,%rdx,1),%rax
 2a0520b:	cmp    %rbx,%rdx
 2a0520e:	cmova  %r15,%rax
 2a05212:	mov    %rcx,%rdx
 2a05215:	shl    $0x3,%edx
 2a05218:	add    $0x18,%edx
 2a0521e:	sub    %edx,%r12d
 2a05221:	sub    %r12,%rax
 2a05224:	mov    (%rax),%rbx
 2a05227:	xor    %r15d,%r15d
 2a0522a:	test   %r11d,%r11d
 2a0522d:	jne    2a05240 <wasm[0]::function[1015]::helper::object_read+0x70e0>
 2a05233:	mov    0x220(%rsp),%r10
 2a0523b:	jmp    2a052d0 <wasm[0]::function[1015]::helper::object_read+0x7170>
 2a05240:	test   %r11d,%r11d
 2a05243:	je     2a191d0 <wasm[0]::function[1015]::helper::object_read+0x1b070>
 2a05249:	test   %r11d,%r11d
 2a0524c:	je     2a191d2 <wasm[0]::function[1015]::helper::object_read+0x1b072>
 2a05252:	mov    0x2e0(%rsp),%r14
 2a0525a:	mov    0x28(%r14),%rax
 2a0525e:	mov    0x20(%r14),%r12
 2a05262:	mov    %r11d,%r15d
 2a05265:	lea    0x10(%r12,%r15,1),%r10
 2a0526a:	xor    %r14,%r14
 2a0526d:	cmp    %rax,%r15
 2a05270:	cmova  %r14,%r10
 2a05274:	mov    (%r10),%r15d
 2a05277:	cmp    %r15d,%ecx
 2a0527a:	jae    2a191d4 <wasm[0]::function[1015]::helper::object_read+0x1b074>
 2a05280:	mov    %r15d,%r10d
 2a05283:	shl    $0x2,%r10
 2a05287:	shr    $0x20,%r10
 2a0528b:	test   %r10,%r10
 2a0528e:	jne    2a191d6 <wasm[0]::function[1015]::helper::object_read+0x1b076>
 2a05294:	shl    $0x2,%r15d
 2a05298:	add    $0x14,%r15d
 2a0529c:	jb     2a191d8 <wasm[0]::function[1015]::helper::object_read+0x1b078>
 2a052a2:	add    %r15d,%r11d
 2a052a5:	jb     2a191da <wasm[0]::function[1015]::helper::object_read+0x1b07a>
 2a052ab:	mov    %r11d,%edx
 2a052ae:	lea    (%r12,%rdx,1),%r10
 2a052b2:	cmp    %rax,%rdx
 2a052b5:	cmova  %r14,%r10
 2a052b9:	shl    $0x2,%ecx
 2a052bc:	lea    0x14(%rcx),%eax
 2a052bf:	sub    %eax,%r15d
 2a052c2:	sub    %r15,%r10
 2a052c5:	mov    (%r10),%r15d
 2a052c8:	mov    0x220(%rsp),%r10
 2a052d0:	movzbl %r10b,%r12d
 2a052d4:	mov    %r12,0x230(%rsp)
 2a052dc:	mov    %rbx,0x238(%rsp)
 2a052e4:	jmp    2a05469 <wasm[0]::function[1015]::helper::object_read+0x7309>
 2a052e9:	xor    %eax,%eax
 2a052eb:	test   $0x1,%r11d
 2a052f2:	jne    2a05335 <wasm[0]::function[1015]::helper::object_read+0x71d5>
 2a052f8:	mov    0x2e0(%rsp),%r14
 2a05300:	mov    0x28(%r14),%rax
 2a05304:	mov    0x20(%r14),%rdx
 2a05308:	mov    %r11d,%ebx
 2a0530b:	lea    0x4(%rdx,%rbx,1),%r10
 2a05310:	xor    %r12,%r12
 2a05313:	cmp    %rax,%rbx
 2a05316:	cmova  %r12,%r10
 2a0531a:	mov    (%r10),%eax
 2a0531d:	mov    0x190(%rsp),%rdx
 2a05325:	mov    0x28(%rdx),%rdx
 2a05329:	cmp    0x160(%rdx),%eax
 2a0532f:	sete   %al
 2a05332:	movzbl %al,%eax
 2a05335:	test   %eax,%eax
 2a05337:	je     2a191dc <wasm[0]::function[1015]::helper::object_read+0x1b07c>
 2a0533d:	test   %r11d,%r11d
 2a05340:	je     2a191de <wasm[0]::function[1015]::helper::object_read+0x1b07e>
 2a05346:	mov    0x2e0(%rsp),%r14
 2a0534e:	mov    0x28(%r14),%rbx
 2a05352:	mov    0x20(%r14),%r12
 2a05356:	mov    %r11d,%eax
 2a05359:	lea    (%r12,%rax,1),%r10
 2a0535d:	xor    %r11,%r11
 2a05360:	cmp    %rbx,%rax
 2a05363:	cmova  %r11,%r10
 2a05367:	mov    0x10(%r10),%r10d
 2a0536b:	test   %r10d,%r10d
 2a0536e:	je     2a191e0 <wasm[0]::function[1015]::helper::object_read+0x1b080>
 2a05374:	test   %r10d,%r10d
 2a05377:	je     2a191e2 <wasm[0]::function[1015]::helper::object_read+0x1b082>
 2a0537d:	mov    %r10d,%edx
 2a05380:	lea    (%r12,%rdx,1),%r10
 2a05384:	cmp    %rbx,%rdx
 2a05387:	cmova  %r11,%r10
 2a0538b:	mov    0x10(%r10),%r10d
 2a0538f:	test   %r10d,%r10d
 2a05392:	je     2a191e4 <wasm[0]::function[1015]::helper::object_read+0x1b084>
 2a05398:	test   %r10d,%r10d
 2a0539b:	je     2a191e6 <wasm[0]::function[1015]::helper::object_read+0x1b086>
 2a053a1:	mov    %r10d,%edx
 2a053a4:	lea    0x10(%r12,%rdx,1),%r10
 2a053a9:	cmp    %rbx,%rdx
 2a053ac:	cmova  %r11,%r10
 2a053b0:	cmp    (%r10),%ecx
 2a053b3:	setae  %r10b
 2a053b7:	cmp    $0x2,%ecx
 2a053ba:	setae  %r11b
 2a053be:	or     %r11d,%r10d
 2a053c1:	test   %r10b,%r10b
 2a053c4:	jne    2a191e8 <wasm[0]::function[1015]::helper::object_read+0x1b088>
 2a053ca:	mov    0x2e0(%rsp),%r14
 2a053d2:	mov    0x28(%r14),%r11
 2a053d6:	mov    %rax,%r10
 2a053d9:	add    0x20(%r14),%r10
 2a053dd:	xor    %r12,%r12
 2a053e0:	cmp    %r11,%rax
 2a053e3:	cmova  %r12,%r10
 2a053e7:	mov    0x14(%r10),%r12d
 2a053eb:	test   %ecx,%ecx
 2a053ed:	je     2a05426 <wasm[0]::function[1015]::helper::object_read+0x72c6>
 2a053f3:	mov    0x2e0(%rsp),%r14
 2a053fb:	mov    0x28(%r14),%r11
 2a053ff:	mov    0x20(%r14),%rdx
 2a05403:	lea    (%rdx,%rax,1),%r10
 2a05407:	xor    %r14,%r14
 2a0540a:	cmp    %r11,%rax
 2a0540d:	cmova  %r14,%r10
 2a05411:	mov    0x20(%r10),%rbx
 2a05415:	mov    0x2c(%r10),%r15d
 2a05419:	mov    %rbx,0x238(%rsp)
 2a05421:	jmp    2a05454 <wasm[0]::function[1015]::helper::object_read+0x72f4>
 2a05426:	mov    0x2e0(%rsp),%r14
 2a0542e:	mov    0x28(%r14),%r10
 2a05432:	mov    0x20(%r14),%rdx
 2a05436:	lea    (%rdx,%rax,1),%r11
 2a0543a:	xor    %r14,%r14
 2a0543d:	cmp    %r10,%rax
 2a05440:	cmova  %r14,%r11
 2a05444:	mov    0x18(%r11),%rbx
 2a05448:	mov    %rbx,0x238(%rsp)
 2a05450:	mov    0x28(%r11),%r15d
 2a05454:	shl    $0x3,%ecx
 2a05457:	shr    %cl,%r12d
 2a0545a:	and    $0xff,%r12d
 2a05461:	mov    %r12,0x230(%rsp)
 2a05469:	mov    0x198(%rsp),%rdx
 2a05471:	mov    %edx,0x100(%rsp)
 2a05478:	mov    %r15d,0x128(%rsp)
 2a05480:	mov    0x1a0(%rsp),%rax
 2a05488:	mov    %eax,0x90(%rsp)
 2a0548f:	mov    %r13d,0x88(%rsp)
 2a05497:	mov    %esi,0x110(%rsp)
 2a0549e:	mov    %edi,0xd8(%rsp)
 2a054a5:	mov    %r8d,0x130(%rsp)
 2a054ad:	mov    %r9d,0xa0(%rsp)
 2a054b5:	mov    $0x27b,%edx
 2a054ba:	mov    0x190(%rsp),%rsi
 2a054c2:	mov    0x190(%rsp),%rdi
 2a054ca:	call   2f4f240 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 2a054cf:	mov    %eax,0x108(%rsp)
 2a054d6:	xor    %ecx,%ecx
 2a054d8:	mov    %rcx,0x270(%rsp)
 2a054e0:	test   %eax,%eax
 2a054e2:	je     2a191ea <wasm[0]::function[1015]::helper::object_read+0x1b08a>
 2a054e8:	movl   $0x0,0xc8(%rsp)
 2a054f3:	mov    0x100(%rsp),%edx
 2a054fa:	mov    %rdx,0x1a0(%rsp)
 2a05502:	mov    0x128(%rsp),%esi
 2a05509:	mov    %rsi,0x1c8(%rsp)
 2a05511:	mov    0x90(%rsp),%r11d
 2a05519:	mov    %r11,0x1d0(%rsp)
 2a05521:	mov    0x88(%rsp),%r11d
 2a05529:	mov    0x110(%rsp),%eax
 2a05530:	mov    0xd8(%rsp),%edi
 2a05537:	mov    0x130(%rsp),%r8d
 2a0553f:	mov    0xa0(%rsp),%r9d
 2a05547:	xor    %r12,%r12
 2a0554a:	mov    0x2a0(%rsp),%rcx
 2a05552:	mov    0x2a0(%rsp),%rdx
 2a0555a:	test   %dl,%cl
 2a0555c:	jne    2a0558f <wasm[0]::function[1015]::helper::object_read+0x742f>
 2a05562:	mov    0x1a0(%rsp),%rdx
 2a0556a:	mov    0x270(%rsp),%r13
 2a05572:	mov    %r12,0x250(%rsp)
 2a0557a:	mov    0x270(%rsp),%rcx
 2a05582:	mov    %rcx,0x258(%rsp)
 2a0558a:	jmp    2a0626f <wasm[0]::function[1015]::helper::object_read+0x810f>
 2a0558f:	mov    0x100(%rsp),%r8d
 2a05597:	mov    0x2b8(%rsp),%rcx
 2a0559f:	mov    0x2a8(%rsp),%rdx
 2a055a7:	mov    0x190(%rsp),%rsi
 2a055af:	mov    0x190(%rsp),%rdi
 2a055b7:	call   2a7c940 <wasm[0]::function[1039]::helper::object_header_projection>
 2a055bc:	mov    %eax,0x118(%rsp)
 2a055c3:	test   %eax,%eax
 2a055c5:	je     2a191ec <wasm[0]::function[1015]::helper::object_read+0x1b08c>
 2a055cb:	test   %eax,%eax
 2a055cd:	je     2a191ee <wasm[0]::function[1015]::helper::object_read+0x1b08e>
 2a055d3:	mov    0x2e0(%rsp),%r14
 2a055db:	mov    0x28(%r14),%rcx
 2a055df:	mov    0x20(%r14),%rsi
 2a055e3:	mov    %eax,%edx
 2a055e5:	lea    (%rsi,%rdx,1),%rax
 2a055e9:	xor    %rsi,%rsi
 2a055ec:	cmp    %rcx,%rdx
 2a055ef:	cmova  %rsi,%rax
 2a055f3:	mov    0x14(%rax),%eax
 2a055f6:	mov    %eax,0x138(%rsp)
 2a055fd:	test   %eax,%eax
 2a055ff:	je     2a191f0 <wasm[0]::function[1015]::helper::object_read+0x1b090>
 2a05605:	mov    0x138(%rsp),%ecx
 2a0560c:	xor    %eax,%eax
 2a0560e:	test   $0x1,%ecx
 2a05614:	jne    2a0566c <wasm[0]::function[1015]::helper::object_read+0x750c>
 2a0561a:	mov    0x2e0(%rsp),%r14
 2a05622:	mov    0x28(%r14),%rax
 2a05626:	mov    0x20(%r14),%rsi
 2a0562a:	mov    %ecx,%edx
 2a0562c:	lea    0x4(%rsi,%rdx,1),%rcx
 2a05631:	xor    %rsi,%rsi
 2a05634:	cmp    %rax,%rdx
 2a05637:	cmova  %rsi,%rcx
 2a0563b:	mov    (%rcx),%esi
 2a0563d:	mov    0x190(%rsp),%rcx
 2a05645:	mov    0x28(%rcx),%rax
 2a05649:	mov    0x158(%rax),%edx
 2a0564f:	cmp    %edx,%esi
 2a05651:	sete   %al
 2a05654:	movzbl %al,%eax
 2a05657:	cmp    %edx,%esi
 2a05659:	je     2a0566c <wasm[0]::function[1015]::helper::object_read+0x750c>
 2a0565f:	mov    0x190(%rsp),%rdi
 2a05667:	call   3039cc5 <wasmtime_builtin_is_subtype>
 2a0566c:	test   %eax,%eax
 2a0566e:	jne    2a0592c <wasm[0]::function[1015]::helper::object_read+0x77cc>
 2a05674:	mov    0x118(%rsp),%edx
 2a0567b:	xor    %ebx,%ebx
 2a0567d:	test   %edx,%edx
 2a0567f:	je     2a191f2 <wasm[0]::function[1015]::helper::object_read+0x1b092>
 2a05685:	mov    0x108(%rsp),%r9d
 2a0568d:	mov    $0x4,%ecx
 2a05692:	xor    %r8,%r8
 2a05695:	mov    0x190(%rsp),%rsi
 2a0569d:	mov    0x190(%rsp),%rdi
 2a056a5:	call   2a76140 <wasm[0]::function[1032]::helper::ordinary_property_find>
 2a056aa:	test   %eax,%eax
 2a056ac:	je     2a056e4 <wasm[0]::function[1015]::helper::object_read+0x7584>
 2a056b2:	test   %eax,%eax
 2a056b4:	je     2a191f4 <wasm[0]::function[1015]::helper::object_read+0x1b094>
 2a056ba:	test   %eax,%eax
 2a056bc:	je     2a191f6 <wasm[0]::function[1015]::helper::object_read+0x1b096>
 2a056c2:	mov    0x2e0(%rsp),%r14
 2a056ca:	mov    0x28(%r14),%rsi
 2a056ce:	mov    %eax,%edi
 2a056d0:	mov    %rdi,%rax
 2a056d3:	add    0x20(%r14),%rax
 2a056d7:	xor    %r8,%r8
 2a056da:	cmp    %rsi,%rdi
 2a056dd:	cmova  %r8,%rax
 2a056e1:	mov    0x14(%rax),%ebx
 2a056e4:	mov    0xc8(%rsp),%r13d
 2a056ec:	mov    %rax,%rcx
 2a056ef:	mov    %rax,0x270(%rsp)
 2a056f7:	xor    %ecx,%eax
 2a056f9:	mov    %rax,0x270(%rsp)
 2a05701:	xor    %r12,%r12
 2a05704:	test   %ebx,%ebx
 2a05706:	jne    2a05719 <wasm[0]::function[1015]::helper::object_read+0x75b9>
 2a0570c:	mov    0x270(%rsp),%r15
 2a05714:	jmp    2a058c3 <wasm[0]::function[1015]::helper::object_read+0x7763>
 2a05719:	test   %ebx,%ebx
 2a0571b:	je     2a191f8 <wasm[0]::function[1015]::helper::object_read+0x1b098>
 2a05721:	mov    0x2e0(%rsp),%r14
 2a05729:	mov    0x28(%r14),%r10
 2a0572d:	mov    0x20(%r14),%rax
 2a05731:	mov    %ebx,%r11d
 2a05734:	lea    (%rax,%r11,1),%rdi
 2a05738:	xor    %r12,%r12
 2a0573b:	cmp    %r10,%r11
 2a0573e:	cmova  %r12,%rdi
 2a05742:	mov    0x10(%rdi),%r11d
 2a05746:	mov    0xc8(%rsp),%r13d
 2a0574e:	mov    %rax,%rcx
 2a05751:	mov    %rax,0x270(%rsp)
 2a05759:	xor    %ecx,%eax
 2a0575b:	mov    %rax,0x270(%rsp)
 2a05763:	test   $0x1,%r11d
 2a0576a:	je     2a0577d <wasm[0]::function[1015]::helper::object_read+0x761d>
 2a05770:	mov    0x270(%rsp),%r15
 2a05778:	jmp    2a058c3 <wasm[0]::function[1015]::helper::object_read+0x7763>
 2a0577d:	mov    0x14(%rdi),%edx
 2a05780:	test   %edx,%edx
 2a05782:	je     2a191fa <wasm[0]::function[1015]::helper::object_read+0x1b09a>
 2a05788:	xor    %eax,%eax
 2a0578a:	test   $0x1,%edx
 2a05790:	jne    2a057d1 <wasm[0]::function[1015]::helper::object_read+0x7671>
 2a05796:	mov    0x2e0(%rsp),%r14
 2a0579e:	mov    0x28(%r14),%rax
 2a057a2:	mov    0x20(%r14),%rcx
 2a057a6:	mov    %edx,%esi
 2a057a8:	lea    0x4(%rcx,%rsi,1),%rcx
 2a057ad:	xor    %rdi,%rdi
 2a057b0:	cmp    %rax,%rsi
 2a057b3:	cmova  %rdi,%rcx
 2a057b7:	mov    (%rcx),%eax
 2a057b9:	mov    0x190(%rsp),%rcx
 2a057c1:	mov    0x28(%rcx),%rcx
 2a057c5:	cmp    0x120(%rcx),%eax
 2a057cb:	sete   %al
 2a057ce:	movzbl %al,%eax
 2a057d1:	test   %eax,%eax
 2a057d3:	jne    2a0582f <wasm[0]::function[1015]::helper::object_read+0x76cf>
 2a057d9:	mov    0x190(%rsp),%rsi
 2a057e1:	mov    0x190(%rsp),%rdi
 2a057e9:	call   2a1eec0 <wasm[0]::function[1024]::helper::property_value_resolve>
 2a057ee:	test   %eax,%eax
 2a057f0:	je     2a191fc <wasm[0]::function[1015]::helper::object_read+0x1b09c>
 2a057f6:	test   %eax,%eax
 2a057f8:	je     2a191fe <wasm[0]::function[1015]::helper::object_read+0x1b09e>
 2a057fe:	mov    0x2e0(%rsp),%r14
 2a05806:	mov    0x28(%r14),%rcx
 2a0580a:	mov    0x20(%r14),%rsi
 2a0580e:	mov    %eax,%edx
 2a05810:	lea    (%rsi,%rdx,1),%rax
 2a05814:	xor    %rsi,%rsi
 2a05817:	cmp    %rcx,%rdx
 2a0581a:	cmova  %rsi,%rax
 2a0581e:	mov    0x18(%rax),%r15d
 2a05822:	mov    0x10(%rax),%r12
 2a05826:	mov    0x1c(%rax),%r13d
 2a0582a:	jmp    2a058b3 <wasm[0]::function[1015]::helper::object_read+0x7753>
 2a0582f:	xor    %eax,%eax
 2a05831:	test   $0x1,%edx
 2a05837:	jne    2a05878 <wasm[0]::function[1015]::helper::object_read+0x7718>
 2a0583d:	mov    0x2e0(%rsp),%r14
 2a05845:	mov    0x28(%r14),%rax
 2a05849:	mov    0x20(%r14),%rcx
 2a0584d:	mov    %edx,%esi
 2a0584f:	lea    0x4(%rcx,%rsi,1),%rcx
 2a05854:	xor    %rdi,%rdi
 2a05857:	cmp    %rax,%rsi
 2a0585a:	cmova  %rdi,%rcx
 2a0585e:	mov    (%rcx),%eax
 2a05860:	mov    0x190(%rsp),%rcx
 2a05868:	mov    0x28(%rcx),%rcx
 2a0586c:	cmp    0x120(%rcx),%eax
 2a05872:	sete   %al
 2a05875:	movzbl %al,%eax
 2a05878:	test   %eax,%eax
 2a0587a:	je     2a19200 <wasm[0]::function[1015]::helper::object_read+0x1b0a0>
 2a05880:	test   %edx,%edx
 2a05882:	je     2a19202 <wasm[0]::function[1015]::helper::object_read+0x1b0a2>
 2a05888:	mov    0x2e0(%rsp),%r14
 2a05890:	mov    0x28(%r14),%rcx
 2a05894:	mov    0x20(%r14),%rax
 2a05898:	mov    %edx,%edx
 2a0589a:	add    %rdx,%rax
 2a0589d:	xor    %rsi,%rsi
 2a058a0:	cmp    %rcx,%rdx
 2a058a3:	cmova  %rsi,%rax
 2a058a7:	mov    0x18(%rax),%r15d
 2a058ab:	mov    0x10(%rax),%r12
 2a058af:	mov    0x1c(%rax),%r13d
 2a058b3:	mov    0x278(%rsp),%rax
 2a058bb:	mov    %rax,0x270(%rsp)
 2a058c3:	mov    0x100(%rsp),%edx
 2a058ca:	mov    %rdx,0x1a0(%rsp)
 2a058d2:	mov    0x128(%rsp),%esi
 2a058d9:	mov    %rsi,0x1c8(%rsp)
 2a058e1:	mov    0x90(%rsp),%r11d
 2a058e9:	mov    %r11,0x1d0(%rsp)
 2a058f1:	mov    0x88(%rsp),%r11d
 2a058f9:	mov    0x110(%rsp),%eax
 2a05900:	mov    0xd8(%rsp),%edi
 2a05907:	mov    0x130(%rsp),%r8d
 2a0590f:	mov    0xa0(%rsp),%r9d
 2a05917:	mov    %r12,0x250(%rsp)
 2a0591f:	mov    %r15,0x258(%rsp)
 2a05927:	jmp    2a06267 <wasm[0]::function[1015]::helper::object_read+0x8107>
 2a0592c:	mov    0x138(%rsp),%eax
 2a05933:	test   %eax,%eax
 2a05935:	je     2a19204 <wasm[0]::function[1015]::helper::object_read+0x1b0a4>
 2a0593b:	mov    0x138(%rsp),%ecx
 2a05942:	xor    %eax,%eax
 2a05944:	test   $0x1,%ecx
 2a0594a:	jne    2a059a2 <wasm[0]::function[1015]::helper::object_read+0x7842>
 2a05950:	mov    0x2e0(%rsp),%r14
 2a05958:	mov    0x28(%r14),%rax
 2a0595c:	mov    0x20(%r14),%rsi
 2a05960:	mov    %ecx,%edx
 2a05962:	lea    0x4(%rsi,%rdx,1),%rcx
 2a05967:	xor    %rsi,%rsi
 2a0596a:	cmp    %rax,%rdx
 2a0596d:	cmova  %rsi,%rcx
 2a05971:	mov    (%rcx),%esi
 2a05973:	mov    0x190(%rsp),%rcx
 2a0597b:	mov    0x28(%rcx),%rax
 2a0597f:	mov    0x158(%rax),%edx
 2a05985:	cmp    %edx,%esi
 2a05987:	sete   %al
 2a0598a:	movzbl %al,%eax
 2a0598d:	cmp    %edx,%esi
 2a0598f:	je     2a059a2 <wasm[0]::function[1015]::helper::object_read+0x7842>
 2a05995:	mov    0x190(%rsp),%rdi
 2a0599d:	call   3039cc5 <wasmtime_builtin_is_subtype>
 2a059a2:	test   %eax,%eax
 2a059a4:	je     2a19206 <wasm[0]::function[1015]::helper::object_read+0x1b0a6>
 2a059aa:	mov    0x138(%rsp),%ebx
 2a059b1:	mov    0x100(%rsp),%edx
 2a059b8:	mov    %rdx,0x1a0(%rsp)
 2a059c0:	mov    0x128(%rsp),%esi
 2a059c7:	mov    %rsi,0x1c8(%rsp)
 2a059cf:	mov    0x90(%rsp),%r11d
 2a059d7:	mov    %r11,0x1d0(%rsp)
 2a059df:	mov    0xc8(%rsp),%r13d
 2a059e7:	mov    0x88(%rsp),%r11d
 2a059ef:	mov    0x110(%rsp),%eax
 2a059f6:	mov    0xd8(%rsp),%edi
 2a059fd:	mov    0x130(%rsp),%r8d
 2a05a05:	mov    0xa0(%rsp),%r9d
 2a05a0d:	xor    %ecx,%ecx
 2a05a0f:	mov    %rcx,0x208(%rsp)
 2a05a17:	test   %ebx,%ebx
 2a05a19:	je     2a19208 <wasm[0]::function[1015]::helper::object_read+0x1b0a8>
 2a05a1f:	test   %ebx,%ebx
 2a05a21:	je     2a1920a <wasm[0]::function[1015]::helper::object_read+0x1b0aa>
 2a05a27:	mov    0x2e0(%rsp),%r14
 2a05a2f:	mov    0x28(%r14),%rcx
 2a05a33:	mov    0x20(%r14),%r12
 2a05a37:	mov    %ebx,%r10d
 2a05a3a:	lea    (%r12,%r10,1),%rdx
 2a05a3e:	xor    %r14,%r14
 2a05a41:	cmp    %rcx,%r10
 2a05a44:	cmova  %r14,%rdx
 2a05a48:	mov    0x10(%rdx),%r10d
 2a05a4c:	test   %r10d,%r10d
 2a05a4f:	je     2a1920c <wasm[0]::function[1015]::helper::object_read+0x1b0ac>
 2a05a55:	test   %r10d,%r10d
 2a05a58:	je     2a1920e <wasm[0]::function[1015]::helper::object_read+0x1b0ae>
 2a05a5e:	mov    %r10d,%edx
 2a05a61:	lea    (%r12,%rdx,1),%r10
 2a05a65:	cmp    %rcx,%rdx
 2a05a68:	cmova  %r14,%r10
 2a05a6c:	mov    0x10(%r10),%r15d
 2a05a70:	test   %r15d,%r15d
 2a05a73:	je     2a19210 <wasm[0]::function[1015]::helper::object_read+0x1b0b0>
 2a05a79:	test   %r15d,%r15d
 2a05a7c:	je     2a19212 <wasm[0]::function[1015]::helper::object_read+0x1b0b2>
 2a05a82:	mov    %r15d,%r10d
 2a05a85:	lea    0x10(%r12,%r10,1),%rdx
 2a05a8a:	cmp    %rcx,%r10
 2a05a8d:	cmova  %r14,%rdx
 2a05a91:	mov    (%rdx),%r12d
 2a05a94:	mov    %r12,0x218(%rsp)
 2a05a9c:	mov    0x108(%rsp),%r14d
 2a05aa4:	mov    0x190(%rsp),%rcx
 2a05aac:	mov    0x28(%rcx),%rcx
 2a05ab0:	mov    0x234(%rcx),%r12d
 2a05ab7:	mov    0x208(%rsp),%rcx
 2a05abf:	mov    %rcx,0x270(%rsp)
 2a05ac7:	mov    %r15d,0x118(%rsp)
 2a05acf:	mov    %r14d,0xa0(%rsp)
 2a05ad7:	mov    %ebx,0x130(%rsp)
 2a05ade:	mov    0x1a0(%rsp),%rdx
 2a05ae6:	mov    %edx,0xd8(%rsp)
 2a05aed:	mov    0x1c8(%rsp),%rsi
 2a05af5:	mov    %esi,0x110(%rsp)
 2a05afc:	mov    0x1d0(%rsp),%rcx
 2a05b04:	mov    %ecx,0x88(%rsp)
 2a05b0b:	mov    %r13d,0xc8(%rsp)
 2a05b13:	mov    %r11d,0x90(%rsp)
 2a05b1b:	mov    %eax,0x128(%rsp)
 2a05b22:	mov    %edi,0x100(%rsp)
 2a05b29:	mov    %r8d,0x138(%rsp)
 2a05b31:	mov    %r9d,0x108(%rsp)
 2a05b39:	mov    0x2e8(%rsp),%r15
 2a05b41:	mov    (%r15),%rax
 2a05b44:	mov    0x228(%rsp),%rcx
 2a05b4c:	cmp    %rcx,%rax
 2a05b4f:	jae    2a17d4f <wasm[0]::function[1015]::helper::object_read+0x19bef>
 2a05b55:	mov    0x130(%rsp),%ebx
 2a05b5c:	mov    0xd8(%rsp),%edx
 2a05b63:	mov    %rdx,0x1a0(%rsp)
 2a05b6b:	mov    0x110(%rsp),%esi
 2a05b72:	mov    %rsi,0x1c8(%rsp)
 2a05b7a:	mov    0x88(%rsp),%r11d
 2a05b82:	mov    %r11,0x1d0(%rsp)
 2a05b8a:	mov    0xc8(%rsp),%r13d
 2a05b92:	mov    0x90(%rsp),%r11d
 2a05b9a:	mov    0x128(%rsp),%eax
 2a05ba1:	mov    0x100(%rsp),%edi
 2a05ba8:	mov    0x138(%rsp),%r8d
 2a05bb0:	mov    0x108(%rsp),%r9d
 2a05bb8:	mov    0x208(%rsp),%rcx
 2a05bc0:	mov    0x218(%rsp),%rdx
 2a05bc8:	cmp    %edx,%ecx
 2a05bca:	jae    2a05e1b <wasm[0]::function[1015]::helper::object_read+0x7cbb>
 2a05bd0:	mov    0x118(%rsp),%eax
 2a05bd7:	test   %eax,%eax
 2a05bd9:	je     2a19214 <wasm[0]::function[1015]::helper::object_read+0x1b0b4>
 2a05bdf:	test   %eax,%eax
 2a05be1:	je     2a19216 <wasm[0]::function[1015]::helper::object_read+0x1b0b6>
 2a05be7:	mov    0x2e0(%rsp),%r14
 2a05bef:	mov    0x28(%r14),%rdx
 2a05bf3:	mov    0x20(%r14),%rsi
 2a05bf7:	mov    %eax,%r9d
 2a05bfa:	lea    0x10(%rsi,%r9,1),%r8
 2a05bff:	xor    %rdi,%rdi
 2a05c02:	cmp    %rdx,%r9
 2a05c05:	cmova  %rdi,%r8
 2a05c09:	mov    (%r8),%r8d
 2a05c0c:	cmp    %r8d,%ecx
 2a05c0f:	jae    2a19218 <wasm[0]::function[1015]::helper::object_read+0x1b0b8>
 2a05c15:	mov    %r8d,%r9d
 2a05c18:	shl    $0x2,%r9
 2a05c1c:	shr    $0x20,%r9
 2a05c20:	test   %r9,%r9
 2a05c23:	jne    2a1921a <wasm[0]::function[1015]::helper::object_read+0x1b0ba>
 2a05c29:	shl    $0x2,%r8d
 2a05c2d:	add    $0x14,%r8d
 2a05c31:	jb     2a1921c <wasm[0]::function[1015]::helper::object_read+0x1b0bc>
 2a05c37:	add    %r8d,%eax
 2a05c3a:	jb     2a1921e <wasm[0]::function[1015]::helper::object_read+0x1b0be>
 2a05c40:	mov    %eax,%r9d
 2a05c43:	lea    (%rsi,%r9,1),%rax
 2a05c47:	cmp    %rdx,%r9
 2a05c4a:	cmova  %rdi,%rax
 2a05c4e:	mov    %rcx,%rdx
 2a05c51:	shl    $0x2,%edx
 2a05c54:	mov    %rcx,0x208(%rsp)
 2a05c5c:	lea    0x14(%rdx),%ecx
 2a05c5f:	sub    %ecx,%r8d
 2a05c62:	sub    %r8,%rax
 2a05c65:	mov    (%rax),%edx
 2a05c67:	test   %edx,%edx
 2a05c69:	je     2a19220 <wasm[0]::function[1015]::helper::object_read+0x1b0c0>
 2a05c6f:	mov    0xa0(%rsp),%eax
 2a05c76:	cmp    %eax,%edx
 2a05c78:	je     2a05d57 <wasm[0]::function[1015]::helper::object_read+0x7bf7>
 2a05c7e:	xor    %ecx,%ecx
 2a05c80:	test   %edx,%edx
 2a05c82:	je     2a05cc4 <wasm[0]::function[1015]::helper::object_read+0x7b64>
 2a05c88:	xor    %ecx,%ecx
 2a05c8a:	test   $0x1,%edx
 2a05c90:	jne    2a05cc4 <wasm[0]::function[1015]::helper::object_read+0x7b64>
 2a05c96:	mov    0x2e0(%rsp),%r14
 2a05c9e:	mov    0x28(%r14),%rcx
 2a05ca2:	mov    0x20(%r14),%rsi
 2a05ca6:	mov    %edx,%edi
 2a05ca8:	lea    0x4(%rsi,%rdi,1),%rsi
 2a05cad:	xor    %r8,%r8
 2a05cb0:	cmp    %rcx,%rdi
 2a05cb3:	cmova  %r8,%rsi
 2a05cb7:	mov    (%rsi),%ecx
 2a05cb9:	cmp    %r12d,%ecx
 2a05cbc:	sete   %sil
 2a05cc0:	movzbl %sil,%ecx
 2a05cc4:	test   %ecx,%ecx
 2a05cc6:	je     2a19222 <wasm[0]::function[1015]::helper::object_read+0x1b0c2>
 2a05ccc:	xor    %ecx,%ecx
 2a05cce:	test   %eax,%eax
 2a05cd0:	je     2a05d1b <wasm[0]::function[1015]::helper::object_read+0x7bbb>
 2a05cd6:	mov    0xa0(%rsp),%r8d
 2a05cde:	xor    %ecx,%ecx
 2a05ce0:	test   $0x1,%r8d
 2a05ce7:	jne    2a05d1b <wasm[0]::function[1015]::helper::object_read+0x7bbb>
 2a05ced:	mov    0x2e0(%rsp),%r14
 2a05cf5:	mov    0x28(%r14),%r11
 2a05cf9:	mov    0x20(%r14),%rcx
 2a05cfd:	mov    %r8d,%eax
 2a05d00:	lea    0x4(%rcx,%rax,1),%r8
 2a05d05:	xor    %rcx,%rcx
 2a05d08:	cmp    %r11,%rax
 2a05d0b:	cmova  %rcx,%r8
 2a05d0f:	mov    (%r8),%eax
 2a05d12:	cmp    %r12d,%eax
 2a05d15:	sete   %al
 2a05d18:	movzbl %al,%ecx
 2a05d1b:	test   %ecx,%ecx
 2a05d1d:	je     2a19224 <wasm[0]::function[1015]::helper::object_read+0x1b0c4>
 2a05d23:	mov    0xa0(%rsp),%ecx
 2a05d2a:	xor    %r8d,%r8d
 2a05d2d:	test   %ecx,%ecx
 2a05d2f:	je     2a19226 <wasm[0]::function[1015]::helper::object_read+0x1b0c6>
 2a05d35:	mov    0x190(%rsp),%rsi
 2a05d3d:	mov    0x190(%rsp),%rdi
 2a05d45:	call   2b02800 <wasm[0]::function[1057]::helper::string_equality>
 2a05d4a:	mov    %rax,0x270(%rsp)
 2a05d52:	jmp    2a05d67 <wasm[0]::function[1015]::helper::object_read+0x7c07>
 2a05d57:	mov    0x278(%rsp),%rax
 2a05d5f:	mov    %rax,0x270(%rsp)
 2a05d67:	mov    0x118(%rsp),%r15d
 2a05d6f:	mov    0xa0(%rsp),%r14d
 2a05d77:	mov    0x130(%rsp),%ebx
 2a05d7e:	mov    0xd8(%rsp),%edx
 2a05d85:	mov    %rdx,0x1a0(%rsp)
 2a05d8d:	mov    0x110(%rsp),%esi
 2a05d94:	mov    %rsi,0x1c8(%rsp)
 2a05d9c:	mov    0x88(%rsp),%r11d
 2a05da4:	mov    %r11,0x1d0(%rsp)
 2a05dac:	mov    0xc8(%rsp),%r13d
 2a05db4:	mov    0x90(%rsp),%r11d
 2a05dbc:	mov    0x128(%rsp),%eax
 2a05dc3:	mov    0x100(%rsp),%edi
 2a05dca:	mov    0x138(%rsp),%r8d
 2a05dd2:	mov    0x108(%rsp),%r9d
 2a05dda:	mov    0x270(%rsp),%rsi
 2a05de2:	mov    0x270(%rsp),%r10
 2a05dea:	test   %esi,%r10d
 2a05ded:	je     2a05e00 <wasm[0]::function[1015]::helper::object_read+0x7ca0>
 2a05df3:	mov    0x208(%rsp),%rcx
 2a05dfb:	jmp    2a05e1b <wasm[0]::function[1015]::helper::object_read+0x7cbb>
 2a05e00:	mov    0x208(%rsp),%rcx
 2a05e08:	add    $0x1,%ecx
 2a05e0e:	mov    %rcx,0x208(%rsp)
 2a05e16:	jmp    2a05ac7 <wasm[0]::function[1015]::helper::object_read+0x7967>
 2a05e1b:	xor    %r12,%r12
 2a05e1e:	xor    %r15d,%r15d
 2a05e21:	mov    0x270(%rsp),%rdx
 2a05e29:	mov    0x270(%rsp),%rsi
 2a05e31:	test   %esi,%edx
 2a05e33:	jne    2a05e4e <wasm[0]::function[1015]::helper::object_read+0x7cee>
 2a05e39:	mov    %r12,0x250(%rsp)
 2a05e41:	mov    %r15,0x258(%rsp)
 2a05e49:	jmp    2a06267 <wasm[0]::function[1015]::helper::object_read+0x8107>
 2a05e4e:	test   %ebx,%ebx
 2a05e50:	je     2a19228 <wasm[0]::function[1015]::helper::object_read+0x1b0c8>
 2a05e56:	xor    %edx,%edx
 2a05e58:	test   $0x1,%ebx
 2a05e5e:	jne    2a05ea1 <wasm[0]::function[1015]::helper::object_read+0x7d41>
 2a05e64:	mov    0x2e0(%rsp),%r14
 2a05e6c:	mov    0x28(%r14),%rdx
 2a05e70:	mov    0x20(%r14),%r10
 2a05e74:	mov    %ebx,%r12d
 2a05e77:	lea    0x4(%r10,%r12,1),%r10
 2a05e7c:	xor    %r13,%r13
 2a05e7f:	cmp    %rdx,%r12
 2a05e82:	cmova  %r13,%r10
 2a05e86:	mov    (%r10),%edx
 2a05e89:	mov    0x190(%rsp),%rsi
 2a05e91:	mov    0x28(%rsi),%rsi
 2a05e95:	cmp    0x160(%rsi),%edx
 2a05e9b:	sete   %dl
 2a05e9e:	movzbl %dl,%edx
 2a05ea1:	test   %edx,%edx
 2a05ea3:	jne    2a060f6 <wasm[0]::function[1015]::helper::object_read+0x7f96>
 2a05ea9:	xor    %edx,%edx
 2a05eab:	test   $0x1,%ebx
 2a05eb1:	jne    2a05ef4 <wasm[0]::function[1015]::helper::object_read+0x7d94>
 2a05eb7:	mov    0x2e0(%rsp),%r14
 2a05ebf:	mov    0x28(%r14),%rdx
 2a05ec3:	mov    0x20(%r14),%r10
 2a05ec7:	mov    %ebx,%r12d
 2a05eca:	lea    0x4(%r10,%r12,1),%r10
 2a05ecf:	xor    %r13,%r13
 2a05ed2:	cmp    %rdx,%r12
 2a05ed5:	cmova  %r13,%r10
 2a05ed9:	mov    (%r10),%edx
 2a05edc:	mov    0x190(%rsp),%rsi
 2a05ee4:	mov    0x28(%rsi),%rsi
 2a05ee8:	cmp    0x15c(%rsi),%edx
 2a05eee:	sete   %dl
 2a05ef1:	movzbl %dl,%edx
 2a05ef4:	test   %edx,%edx
 2a05ef6:	je     2a1922a <wasm[0]::function[1015]::helper::object_read+0x1b0ca>
 2a05efc:	test   %ebx,%ebx
 2a05efe:	je     2a1922c <wasm[0]::function[1015]::helper::object_read+0x1b0cc>
 2a05f04:	mov    0x2e0(%rsp),%r14
 2a05f0c:	mov    0x28(%r14),%r15
 2a05f10:	mov    0x20(%r14),%r14
 2a05f14:	mov    %ebx,%r10d
 2a05f17:	lea    (%r14,%r10,1),%rdx
 2a05f1b:	xor    %r12,%r12
 2a05f1e:	cmp    %r15,%r10
 2a05f21:	cmova  %r12,%rdx
 2a05f25:	mov    0x14(%rdx),%r10d
 2a05f29:	mov    0x18(%rdx),%r13d
 2a05f2d:	mov    0x1c(%rdx),%ebx
 2a05f30:	test   %r10d,%r10d
 2a05f33:	je     2a1922e <wasm[0]::function[1015]::helper::object_read+0x1b0ce>
 2a05f39:	test   %r10d,%r10d
 2a05f3c:	je     2a19230 <wasm[0]::function[1015]::helper::object_read+0x1b0d0>
 2a05f42:	mov    %r10d,%esi
 2a05f45:	lea    0x10(%r14,%rsi,1),%rdx
 2a05f4a:	cmp    %r15,%rsi
 2a05f4d:	cmova  %r12,%rdx
 2a05f51:	mov    (%rdx),%edx
 2a05f53:	cmp    %edx,%ecx
 2a05f55:	jae    2a19232 <wasm[0]::function[1015]::helper::object_read+0x1b0d2>
 2a05f5b:	mov    %edx,%esi
 2a05f5d:	shr    $0x20,%rsi
 2a05f61:	test   %rsi,%rsi
 2a05f64:	jne    2a19234 <wasm[0]::function[1015]::helper::object_read+0x1b0d4>
 2a05f6a:	add    $0x14,%edx
 2a05f6d:	jb     2a19236 <wasm[0]::function[1015]::helper::object_read+0x1b0d6>
 2a05f73:	add    %edx,%r10d
 2a05f76:	jb     2a19238 <wasm[0]::function[1015]::helper::object_read+0x1b0d8>
 2a05f7c:	mov    %r10d,%esi
 2a05f7f:	lea    (%r14,%rsi,1),%r10
 2a05f83:	cmp    %r15,%rsi
 2a05f86:	cmova  %r12,%r10
 2a05f8a:	lea    0x14(%rcx),%esi
 2a05f8d:	sub    %esi,%edx
 2a05f8f:	sub    %rdx,%r10
 2a05f92:	movzbq (%r10),%rdx
 2a05f96:	mov    %rdx,0x218(%rsp)
 2a05f9e:	test   %r13d,%r13d
 2a05fa1:	je     2a06035 <wasm[0]::function[1015]::helper::object_read+0x7ed5>
 2a05fa7:	test   %r13d,%r13d
 2a05faa:	je     2a1923a <wasm[0]::function[1015]::helper::object_read+0x1b0da>
 2a05fb0:	test   %r13d,%r13d
 2a05fb3:	je     2a1923c <wasm[0]::function[1015]::helper::object_read+0x1b0dc>
 2a05fb9:	mov    0x2e0(%rsp),%r14
 2a05fc1:	mov    0x28(%r14),%r12
 2a05fc5:	mov    0x20(%r14),%r10
 2a05fc9:	mov    %r13d,%r15d
 2a05fcc:	lea    0x10(%r10,%r15,1),%rdx
 2a05fd1:	xor    %r14,%r14
 2a05fd4:	cmp    %r12,%r15
 2a05fd7:	cmova  %r14,%rdx
 2a05fdb:	mov    (%rdx),%r15d
 2a05fde:	cmp    %r15d,%ecx
 2a05fe1:	jae    2a1923e <wasm[0]::function[1015]::helper::object_read+0x1b0de>
 2a05fe7:	mov    %r15d,%edx
 2a05fea:	shl    $0x3,%rdx
 2a05fee:	shr    $0x20,%rdx
 2a05ff2:	test   %rdx,%rdx
 2a05ff5:	jne    2a19240 <wasm[0]::function[1015]::helper::object_read+0x1b0e0>
 2a05ffb:	shl    $0x3,%r15d
 2a05fff:	add    $0x18,%r15d
 2a06003:	jb     2a19242 <wasm[0]::function[1015]::helper::object_read+0x1b0e2>
 2a06009:	add    %r15d,%r13d
 2a0600c:	jb     2a19244 <wasm[0]::function[1015]::helper::object_read+0x1b0e4>
 2a06012:	mov    %r13d,%esi
 2a06015:	lea    (%r10,%rsi,1),%rdx
 2a06019:	cmp    %r12,%rsi
 2a0601c:	cmova  %r14,%rdx
 2a06020:	mov    %rcx,%rsi
 2a06023:	shl    $0x3,%esi
 2a06026:	add    $0x18,%esi
 2a0602c:	sub    %esi,%r15d
 2a0602f:	sub    %r15,%rdx
 2a06032:	mov    (%rdx),%r12
 2a06035:	xor    %r13d,%r13d
 2a06038:	test   %ebx,%ebx
 2a0603a:	jne    2a0604d <wasm[0]::function[1015]::helper::object_read+0x7eed>
 2a06040:	mov    0x218(%rsp),%rdx
 2a06048:	jmp    2a060dd <wasm[0]::function[1015]::helper::object_read+0x7f7d>
 2a0604d:	test   %ebx,%ebx
 2a0604f:	je     2a19246 <wasm[0]::function[1015]::helper::object_read+0x1b0e6>
 2a06055:	test   %ebx,%ebx
 2a06057:	je     2a19248 <wasm[0]::function[1015]::helper::object_read+0x1b0e8>
 2a0605d:	mov    0x2e0(%rsp),%r14
 2a06065:	mov    0x28(%r14),%r13
 2a06069:	mov    0x20(%r14),%r10
 2a0606d:	mov    %ebx,%r15d
 2a06070:	lea    0x10(%r10,%r15,1),%rdx
 2a06075:	xor    %r14,%r14
 2a06078:	cmp    %r13,%r15
 2a0607b:	cmova  %r14,%rdx
 2a0607f:	mov    (%rdx),%r15d
 2a06082:	cmp    %r15d,%ecx
 2a06085:	jae    2a1924a <wasm[0]::function[1015]::helper::object_read+0x1b0ea>
 2a0608b:	mov    %r15d,%edx
 2a0608e:	shl    $0x2,%rdx
 2a06092:	shr    $0x20,%rdx
 2a06096:	test   %rdx,%rdx
 2a06099:	jne    2a1924c <wasm[0]::function[1015]::helper::object_read+0x1b0ec>
 2a0609f:	shl    $0x2,%r15d
 2a060a3:	add    $0x14,%r15d
 2a060a7:	jb     2a1924e <wasm[0]::function[1015]::helper::object_read+0x1b0ee>
 2a060ad:	add    %r15d,%ebx
 2a060b0:	jb     2a19250 <wasm[0]::function[1015]::helper::object_read+0x1b0f0>
 2a060b6:	mov    %ebx,%esi
 2a060b8:	lea    (%r10,%rsi,1),%rdx
 2a060bc:	cmp    %r13,%rsi
 2a060bf:	cmova  %r14,%rdx
 2a060c3:	shl    $0x2,%ecx
 2a060c6:	add    $0x14,%ecx
 2a060cc:	sub    %ecx,%r15d
 2a060cf:	sub    %r15,%rdx
 2a060d2:	mov    (%rdx),%r13d
 2a060d5:	mov    0x218(%rsp),%rdx
 2a060dd:	movzbl %dl,%r15d
 2a060e1:	mov    %r12,0x250(%rsp)
 2a060e9:	mov    %r15,0x258(%rsp)
 2a060f1:	jmp    2a06267 <wasm[0]::function[1015]::helper::object_read+0x8107>
 2a060f6:	xor    %edx,%edx
 2a060f8:	test   $0x1,%ebx
 2a060fe:	jne    2a06141 <wasm[0]::function[1015]::helper::object_read+0x7fe1>
 2a06104:	mov    0x2e0(%rsp),%r14
 2a0610c:	mov    0x28(%r14),%rdx
 2a06110:	mov    0x20(%r14),%rsi
 2a06114:	mov    %ebx,%r12d
 2a06117:	lea    0x4(%rsi,%r12,1),%r10
 2a0611c:	xor    %r13,%r13
 2a0611f:	cmp    %rdx,%r12
 2a06122:	cmova  %r13,%r10
 2a06126:	mov    (%r10),%edx
 2a06129:	mov    0x190(%rsp),%rsi
 2a06131:	mov    0x28(%rsi),%rsi
 2a06135:	cmp    0x160(%rsi),%edx
 2a0613b:	sete   %dl
 2a0613e:	movzbl %dl,%edx
 2a06141:	test   %edx,%edx
 2a06143:	je     2a19252 <wasm[0]::function[1015]::helper::object_read+0x1b0f2>
 2a06149:	test   %ebx,%ebx
 2a0614b:	je     2a19254 <wasm[0]::function[1015]::helper::object_read+0x1b0f4>
 2a06151:	mov    0x2e0(%rsp),%r14
 2a06159:	mov    0x28(%r14),%r12
 2a0615d:	mov    0x20(%r14),%r10
 2a06161:	mov    %ebx,%ebx
 2a06163:	lea    (%r10,%rbx,1),%rdx
 2a06167:	xor    %r13,%r13
 2a0616a:	cmp    %r12,%rbx
 2a0616d:	cmova  %r13,%rdx
 2a06171:	mov    0x10(%rdx),%edx
 2a06174:	test   %edx,%edx
 2a06176:	je     2a19256 <wasm[0]::function[1015]::helper::object_read+0x1b0f6>
 2a0617c:	test   %edx,%edx
 2a0617e:	je     2a19258 <wasm[0]::function[1015]::helper::object_read+0x1b0f8>
 2a06184:	mov    %edx,%esi
 2a06186:	lea    (%r10,%rsi,1),%rdx
 2a0618a:	cmp    %r12,%rsi
 2a0618d:	cmova  %r13,%rdx
 2a06191:	mov    0x10(%rdx),%edx
 2a06194:	test   %edx,%edx
 2a06196:	je     2a1925a <wasm[0]::function[1015]::helper::object_read+0x1b0fa>
 2a0619c:	test   %edx,%edx
 2a0619e:	je     2a1925c <wasm[0]::function[1015]::helper::object_read+0x1b0fc>
 2a061a4:	mov    %edx,%esi
 2a061a6:	lea    0x10(%r10,%rsi,1),%rdx
 2a061ab:	cmp    %r12,%rsi
 2a061ae:	cmova  %r13,%rdx
 2a061b2:	cmp    (%rdx),%ecx
 2a061b4:	setae  %dl
 2a061b7:	cmp    $0x2,%ecx
 2a061ba:	setae  %sil
 2a061be:	or     %esi,%edx
 2a061c0:	test   %dl,%dl
 2a061c2:	jne    2a1925e <wasm[0]::function[1015]::helper::object_read+0x1b0fe>
 2a061c8:	mov    0x2e0(%rsp),%r14
 2a061d0:	mov    0x28(%r14),%r10
 2a061d4:	mov    %rbx,%rdx
 2a061d7:	add    0x20(%r14),%rdx
 2a061db:	xor    %r12,%r12
 2a061de:	cmp    %r10,%rbx
 2a061e1:	cmova  %r12,%rdx
 2a061e5:	mov    0x14(%rdx),%r15d
 2a061e9:	test   %ecx,%ecx
 2a061eb:	je     2a06224 <wasm[0]::function[1015]::helper::object_read+0x80c4>
 2a061f1:	mov    0x2e0(%rsp),%r14
 2a061f9:	mov    0x28(%r14),%r10
 2a061fd:	mov    0x20(%r14),%rsi
 2a06201:	lea    (%rsi,%rbx,1),%rdx
 2a06205:	xor    %r12,%r12
 2a06208:	cmp    %r10,%rbx
 2a0620b:	cmova  %r12,%rdx
 2a0620f:	mov    0x20(%rdx),%r12
 2a06213:	mov    0x2c(%rdx),%r13d
 2a06217:	mov    %r12,0x250(%rsp)
 2a0621f:	jmp    2a06252 <wasm[0]::function[1015]::helper::object_read+0x80f2>
 2a06224:	mov    0x2e0(%rsp),%r14
 2a0622c:	mov    0x28(%r14),%r10
 2a06230:	mov    0x20(%r14),%rsi
 2a06234:	lea    (%rsi,%rbx,1),%rdx
 2a06238:	xor    %r12,%r12
 2a0623b:	cmp    %r10,%rbx
 2a0623e:	cmova  %r12,%rdx
 2a06242:	mov    0x18(%rdx),%r12
 2a06246:	mov    %r12,0x250(%rsp)
 2a0624e:	mov    0x28(%rdx),%r13d
 2a06252:	shl    $0x3,%ecx
 2a06255:	shr    %cl,%r15d
 2a06258:	and    $0xff,%r15d
 2a0625f:	mov    %r15,0x258(%rsp)
 2a06267:	mov    0x1a0(%rsp),%rdx
 2a0626f:	mov    %edx,0x128(%rsp)
 2a06276:	mov    0x1c8(%rsp),%rsi
 2a0627e:	mov    %esi,0x90(%rsp)
 2a06285:	mov    0x1d0(%rsp),%rcx
 2a0628d:	mov    %ecx,0xc8(%rsp)
 2a06294:	mov    %r13d,0x88(%rsp)
 2a0629c:	mov    %r11d,0x110(%rsp)
 2a062a4:	mov    %eax,0xd8(%rsp)
 2a062ab:	mov    %edi,0x130(%rsp)
 2a062b2:	mov    %r8d,0xa0(%rsp)
 2a062ba:	mov    %r9d,0x118(%rsp)
 2a062c2:	mov    $0x27c,%edx
 2a062c7:	mov    0x190(%rsp),%rsi
 2a062cf:	mov    0x190(%rsp),%rdi
 2a062d7:	call   2f4f240 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 2a062dc:	mov    %eax,0x100(%rsp)
 2a062e3:	xor    %ebx,%ebx
 2a062e5:	test   %eax,%eax
 2a062e7:	je     2a19260 <wasm[0]::function[1015]::helper::object_read+0x1b100>
 2a062ed:	movl   $0x0,0x138(%rsp)
 2a062f8:	mov    0x128(%rsp),%edx
 2a062ff:	mov    %rdx,0x1d8(%rsp)
 2a06307:	mov    0x90(%rsp),%esi
 2a0630e:	mov    %rsi,0x1e0(%rsp)
 2a06316:	mov    0xc8(%rsp),%edi
 2a0631d:	mov    %rdi,0x1e8(%rsp)
 2a06325:	mov    0x88(%rsp),%r8d
 2a0632d:	mov    %r8,0x1f0(%rsp)
 2a06335:	mov    0x110(%rsp),%r8d
 2a0633d:	mov    0xd8(%rsp),%r9d
 2a06345:	mov    0x130(%rsp),%r10d
 2a0634d:	mov    0xa0(%rsp),%r11d
 2a06355:	mov    0x118(%rsp),%edx
 2a0635c:	xor    %r15,%r15
 2a0635f:	mov    0x2a0(%rsp),%rax
 2a06367:	mov    0x2a0(%rsp),%rcx
 2a0636f:	test   %al,%cl
 2a06371:	jne    2a06397 <wasm[0]::function[1015]::helper::object_read+0x8237>
 2a06377:	mov    0x1d8(%rsp),%rax
 2a0637f:	mov    %rbx,%r13
 2a06382:	mov    %r15,0x260(%rsp)
 2a0638a:	mov    %rbx,0x268(%rsp)
 2a06392:	jmp    2a0704d <wasm[0]::function[1015]::helper::object_read+0x8eed>
 2a06397:	mov    0x128(%rsp),%r8d
 2a0639f:	mov    0x2b8(%rsp),%rcx
 2a063a7:	mov    0x2a8(%rsp),%rdx
 2a063af:	mov    0x190(%rsp),%rsi
 2a063b7:	mov    0x190(%rsp),%rdi
 2a063bf:	call   2a7c940 <wasm[0]::function[1039]::helper::object_header_projection>
 2a063c4:	mov    %eax,0x108(%rsp)
 2a063cb:	test   %eax,%eax
 2a063cd:	je     2a19262 <wasm[0]::function[1015]::helper::object_read+0x1b102>
 2a063d3:	test   %eax,%eax
 2a063d5:	je     2a19264 <wasm[0]::function[1015]::helper::object_read+0x1b104>
 2a063db:	mov    0x2e0(%rsp),%r14
 2a063e3:	mov    0x28(%r14),%rcx
 2a063e7:	mov    0x20(%r14),%rsi
 2a063eb:	mov    %eax,%edx
 2a063ed:	lea    (%rsi,%rdx,1),%rax
 2a063f1:	xor    %rsi,%rsi
 2a063f4:	cmp    %rcx,%rdx
 2a063f7:	cmova  %rsi,%rax
 2a063fb:	mov    0x14(%rax),%eax
 2a063fe:	mov    %eax,0x120(%rsp)
 2a06405:	test   %eax,%eax
 2a06407:	je     2a19266 <wasm[0]::function[1015]::helper::object_read+0x1b106>
 2a0640d:	mov    0x120(%rsp),%ecx
 2a06414:	xor    %eax,%eax
 2a06416:	test   $0x1,%ecx
 2a0641c:	jne    2a06474 <wasm[0]::function[1015]::helper::object_read+0x8314>
 2a06422:	mov    0x2e0(%rsp),%r14
 2a0642a:	mov    0x28(%r14),%rax
 2a0642e:	mov    0x20(%r14),%rsi
 2a06432:	mov    %ecx,%edx
 2a06434:	lea    0x4(%rsi,%rdx,1),%rcx
 2a06439:	xor    %rsi,%rsi
 2a0643c:	cmp    %rax,%rdx
 2a0643f:	cmova  %rsi,%rcx
 2a06443:	mov    (%rcx),%esi
 2a06445:	mov    0x190(%rsp),%rcx
 2a0644d:	mov    0x28(%rcx),%rax
 2a06451:	mov    0x158(%rax),%edx
 2a06457:	cmp    %edx,%esi
 2a06459:	sete   %al
 2a0645c:	movzbl %al,%eax
 2a0645f:	cmp    %edx,%esi
 2a06461:	je     2a06474 <wasm[0]::function[1015]::helper::object_read+0x8314>
 2a06467:	mov    0x190(%rsp),%rdi
 2a0646f:	call   3039cc5 <wasmtime_builtin_is_subtype>
 2a06474:	test   %eax,%eax
 2a06476:	jne    2a066f5 <wasm[0]::function[1015]::helper::object_read+0x8595>
 2a0647c:	mov    0x108(%rsp),%edx
 2a06483:	xor    %r12d,%r12d
 2a06486:	test   %edx,%edx
 2a06488:	je     2a19268 <wasm[0]::function[1015]::helper::object_read+0x1b108>
 2a0648e:	mov    0x100(%rsp),%r9d
 2a06496:	mov    $0x4,%ecx
 2a0649b:	xor    %r8,%r8
 2a0649e:	mov    0x190(%rsp),%rsi
 2a064a6:	mov    0x190(%rsp),%rdi
 2a064ae:	call   2a76140 <wasm[0]::function[1032]::helper::ordinary_property_find>
 2a064b3:	test   %eax,%eax
 2a064b5:	je     2a064ee <wasm[0]::function[1015]::helper::object_read+0x838e>
 2a064bb:	test   %eax,%eax
 2a064bd:	je     2a1926a <wasm[0]::function[1015]::helper::object_read+0x1b10a>
 2a064c3:	test   %eax,%eax
 2a064c5:	je     2a1926c <wasm[0]::function[1015]::helper::object_read+0x1b10c>
 2a064cb:	mov    0x2e0(%rsp),%r14
 2a064d3:	mov    0x28(%r14),%rcx
 2a064d7:	mov    %eax,%edx
 2a064d9:	mov    %rdx,%rax
 2a064dc:	add    0x20(%r14),%rax
 2a064e0:	xor    %rsi,%rsi
 2a064e3:	cmp    %rcx,%rdx
 2a064e6:	cmova  %rsi,%rax
 2a064ea:	mov    0x14(%rax),%r12d
 2a064ee:	mov    0x138(%rsp),%r13d
 2a064f6:	xor    %r15,%r15
 2a064f9:	xor    %ebx,%ebx
 2a064fb:	test   %r12d,%r12d
 2a064fe:	je     2a0667c <wasm[0]::function[1015]::helper::object_read+0x851c>
 2a06504:	test   %r12d,%r12d
 2a06507:	je     2a1926e <wasm[0]::function[1015]::helper::object_read+0x1b10e>
 2a0650d:	mov    0x2e0(%rsp),%r14
 2a06515:	mov    0x28(%r14),%rdx
 2a06519:	mov    0x20(%r14),%rdi
 2a0651d:	mov    %r12d,%esi
 2a06520:	lea    (%rdi,%rsi,1),%rax
 2a06524:	xor    %r15,%r15
 2a06527:	cmp    %rdx,%rsi
 2a0652a:	cmova  %r15,%rax
 2a0652e:	mov    0x10(%rax),%esi
 2a06531:	mov    0x138(%rsp),%r13d
 2a06539:	xor    %ebx,%ebx
 2a0653b:	test   $0x1,%esi
 2a06541:	jne    2a0667c <wasm[0]::function[1015]::helper::object_read+0x851c>
 2a06547:	mov    0x14(%rax),%edx
 2a0654a:	test   %edx,%edx
 2a0654c:	je     2a19270 <wasm[0]::function[1015]::helper::object_read+0x1b110>
 2a06552:	xor    %ecx,%ecx
 2a06554:	test   $0x1,%edx
 2a0655a:	jne    2a0659c <wasm[0]::function[1015]::helper::object_read+0x843c>
 2a06560:	mov    0x2e0(%rsp),%r14
 2a06568:	mov    0x28(%r14),%rax
 2a0656c:	mov    0x20(%r14),%rsi
 2a06570:	mov    %edx,%ecx
 2a06572:	lea    0x4(%rsi,%rcx,1),%r9
 2a06577:	xor    %rsi,%rsi
 2a0657a:	cmp    %rax,%rcx
 2a0657d:	cmova  %rsi,%r9
 2a06581:	mov    (%r9),%eax
 2a06584:	mov    0x190(%rsp),%rcx
 2a0658c:	mov    0x28(%rcx),%rcx
 2a06590:	cmp    0x120(%rcx),%eax
 2a06596:	sete   %al
 2a06599:	movzbl %al,%ecx
 2a0659c:	test   %ecx,%ecx
 2a0659e:	jne    2a065f9 <wasm[0]::function[1015]::helper::object_read+0x8499>
 2a065a4:	mov    0x190(%rsp),%rsi
 2a065ac:	mov    0x190(%rsp),%rdi
 2a065b4:	call   2a1eec0 <wasm[0]::function[1024]::helper::property_value_resolve>
 2a065b9:	test   %eax,%eax
 2a065bb:	je     2a19272 <wasm[0]::function[1015]::helper::object_read+0x1b112>
 2a065c1:	test   %eax,%eax
 2a065c3:	je     2a19274 <wasm[0]::function[1015]::helper::object_read+0x1b114>
 2a065c9:	mov    0x2e0(%rsp),%r14
 2a065d1:	mov    0x28(%r14),%rcx
 2a065d5:	mov    0x20(%r14),%rsi
 2a065d9:	mov    %eax,%edx
 2a065db:	lea    (%rsi,%rdx,1),%rax
 2a065df:	xor    %rsi,%rsi
 2a065e2:	cmp    %rcx,%rdx
 2a065e5:	cmova  %rsi,%rax
 2a065e9:	mov    0x18(%rax),%ebx
 2a065ec:	mov    0x10(%rax),%r15
 2a065f0:	mov    0x1c(%rax),%r13d
 2a065f4:	jmp    2a0667c <wasm[0]::function[1015]::helper::object_read+0x851c>
 2a065f9:	xor    %eax,%eax
 2a065fb:	test   $0x1,%edx
 2a06601:	jne    2a06642 <wasm[0]::function[1015]::helper::object_read+0x84e2>
 2a06607:	mov    0x2e0(%rsp),%r14
 2a0660f:	mov    0x28(%r14),%rax
 2a06613:	mov    0x20(%r14),%rcx
 2a06617:	mov    %edx,%esi
 2a06619:	lea    0x4(%rcx,%rsi,1),%rcx
 2a0661e:	xor    %rdi,%rdi
 2a06621:	cmp    %rax,%rsi
 2a06624:	cmova  %rdi,%rcx
 2a06628:	mov    (%rcx),%eax
 2a0662a:	mov    0x190(%rsp),%rcx
 2a06632:	mov    0x28(%rcx),%rcx
 2a06636:	cmp    0x120(%rcx),%eax
 2a0663c:	sete   %al
 2a0663f:	movzbl %al,%eax
 2a06642:	test   %eax,%eax
 2a06644:	je     2a19276 <wasm[0]::function[1015]::helper::object_read+0x1b116>
 2a0664a:	test   %edx,%edx
 2a0664c:	je     2a19278 <wasm[0]::function[1015]::helper::object_read+0x1b118>
 2a06652:	mov    0x2e0(%rsp),%r14
 2a0665a:	mov    0x28(%r14),%rcx
 2a0665e:	mov    0x20(%r14),%rax
 2a06662:	mov    %edx,%edx
 2a06664:	add    %rdx,%rax
 2a06667:	xor    %rsi,%rsi
 2a0666a:	cmp    %rcx,%rdx
 2a0666d:	cmova  %rsi,%rax
 2a06671:	mov    0x18(%rax),%ebx
 2a06674:	mov    0x10(%rax),%r15
 2a06678:	mov    0x1c(%rax),%r13d
 2a0667c:	mov    0x128(%rsp),%edx
 2a06683:	mov    %rdx,0x1d8(%rsp)
 2a0668b:	mov    0x90(%rsp),%esi
 2a06692:	mov    %rsi,0x1e0(%rsp)
 2a0669a:	mov    0xc8(%rsp),%edi
 2a066a1:	mov    %rdi,0x1e8(%rsp)
 2a066a9:	mov    0x88(%rsp),%r8d
 2a066b1:	mov    %r8,0x1f0(%rsp)
 2a066b9:	mov    0x110(%rsp),%r8d
 2a066c1:	mov    0xd8(%rsp),%r9d
 2a066c9:	mov    0x130(%rsp),%r10d
 2a066d1:	mov    0xa0(%rsp),%r11d
 2a066d9:	mov    0x118(%rsp),%edx
 2a066e0:	mov    %r15,0x260(%rsp)
 2a066e8:	mov    %rbx,0x268(%rsp)
 2a066f0:	jmp    2a07045 <wasm[0]::function[1015]::helper::object_read+0x8ee5>
 2a066f5:	mov    0x120(%rsp),%eax
 2a066fc:	test   %eax,%eax
 2a066fe:	je     2a1927a <wasm[0]::function[1015]::helper::object_read+0x1b11a>
 2a06704:	mov    0x120(%rsp),%ecx
 2a0670b:	xor    %eax,%eax
 2a0670d:	test   $0x1,%ecx
 2a06713:	jne    2a0676b <wasm[0]::function[1015]::helper::object_read+0x860b>
 2a06719:	mov    0x2e0(%rsp),%r14
 2a06721:	mov    0x28(%r14),%rax
 2a06725:	mov    0x20(%r14),%rsi
 2a06729:	mov    %ecx,%edx
 2a0672b:	lea    0x4(%rsi,%rdx,1),%rcx
 2a06730:	xor    %rsi,%rsi
 2a06733:	cmp    %rax,%rdx
 2a06736:	cmova  %rsi,%rcx
 2a0673a:	mov    (%rcx),%esi
 2a0673c:	mov    0x190(%rsp),%rcx
 2a06744:	mov    0x28(%rcx),%rax
 2a06748:	mov    0x158(%rax),%edx
 2a0674e:	cmp    %edx,%esi
 2a06750:	sete   %al
 2a06753:	movzbl %al,%eax
 2a06756:	cmp    %edx,%esi
 2a06758:	je     2a0676b <wasm[0]::function[1015]::helper::object_read+0x860b>
 2a0675e:	mov    0x190(%rsp),%rdi
 2a06766:	call   3039cc5 <wasmtime_builtin_is_subtype>
 2a0676b:	test   %eax,%eax
 2a0676d:	je     2a1927c <wasm[0]::function[1015]::helper::object_read+0x1b11c>
 2a06773:	mov    0x120(%rsp),%r12d
 2a0677b:	mov    0x128(%rsp),%edx
 2a06782:	mov    %rdx,0x1d8(%rsp)
 2a0678a:	mov    0x90(%rsp),%esi
 2a06791:	mov    %rsi,0x1e0(%rsp)
 2a06799:	mov    0xc8(%rsp),%edi
 2a067a0:	mov    %rdi,0x1e8(%rsp)
 2a067a8:	mov    0x88(%rsp),%r8d
 2a067b0:	mov    %r8,0x1f0(%rsp)
 2a067b8:	mov    0x138(%rsp),%r13d
 2a067c0:	mov    0x110(%rsp),%r8d
 2a067c8:	mov    0xd8(%rsp),%r9d
 2a067d0:	mov    0x130(%rsp),%r10d
 2a067d8:	mov    0xa0(%rsp),%r11d
 2a067e0:	mov    0x118(%rsp),%edx
 2a067e7:	xor    %ecx,%ecx
 2a067e9:	mov    %rcx,0x1f8(%rsp)
 2a067f1:	test   %r12d,%r12d
 2a067f4:	je     2a1927e <wasm[0]::function[1015]::helper::object_read+0x1b11e>
 2a067fa:	test   %r12d,%r12d
 2a067fd:	je     2a19280 <wasm[0]::function[1015]::helper::object_read+0x1b120>
 2a06803:	mov    0x2e0(%rsp),%r14
 2a0680b:	mov    0x28(%r14),%rax
 2a0680f:	mov    0x20(%r14),%rcx
 2a06813:	mov    %r12d,%ebx
 2a06816:	lea    (%rcx,%rbx,1),%rsi
 2a0681a:	xor    %r14,%r14
 2a0681d:	cmp    %rax,%rbx
 2a06820:	cmova  %r14,%rsi
 2a06824:	mov    0x10(%rsi),%esi
 2a06827:	test   %esi,%esi
 2a06829:	je     2a19282 <wasm[0]::function[1015]::helper::object_read+0x1b122>
 2a0682f:	test   %esi,%esi
 2a06831:	je     2a19284 <wasm[0]::function[1015]::helper::object_read+0x1b124>
 2a06837:	mov    %esi,%ebx
 2a06839:	lea    (%rcx,%rbx,1),%rsi
 2a0683d:	cmp    %rax,%rbx
 2a06840:	cmova  %r14,%rsi
 2a06844:	mov    0x10(%rsi),%ebx
 2a06847:	test   %ebx,%ebx
 2a06849:	je     2a19286 <wasm[0]::function[1015]::helper::object_read+0x1b126>
 2a0684f:	test   %ebx,%ebx
 2a06851:	je     2a19288 <wasm[0]::function[1015]::helper::object_read+0x1b128>
 2a06857:	mov    %ebx,%r15d
 2a0685a:	lea    0x10(%rcx,%r15,1),%rsi
 2a0685f:	cmp    %rax,%r15
 2a06862:	cmova  %r14,%rsi
 2a06866:	mov    (%rsi),%r15d
 2a06869:	mov    %r15,0x208(%rsp)
 2a06871:	mov    0x100(%rsp),%r14d
 2a06879:	mov    0x190(%rsp),%rcx
 2a06881:	mov    0x28(%rcx),%rdi
 2a06885:	mov    0x234(%rdi),%r15d
 2a0688c:	mov    0x1f8(%rsp),%rax
 2a06894:	mov    %rax,0x1d0(%rsp)
 2a0689c:	mov    %ebx,0x108(%rsp)
 2a068a3:	mov    %r14d,0x118(%rsp)
 2a068ab:	mov    %r12d,0xa0(%rsp)
 2a068b3:	mov    0x1d8(%rsp),%rcx
 2a068bb:	mov    %ecx,0x130(%rsp)
 2a068c2:	mov    0x1e0(%rsp),%rsi
 2a068ca:	mov    %esi,0xd8(%rsp)
 2a068d1:	mov    0x1e8(%rsp),%rdi
 2a068d9:	mov    %edi,0x110(%rsp)
 2a068e0:	mov    0x1f0(%rsp),%rax
 2a068e8:	mov    %eax,0x138(%rsp)
 2a068ef:	mov    %r13d,0x88(%rsp)
 2a068f7:	mov    %r8d,0xc8(%rsp)
 2a068ff:	mov    %r9d,0x90(%rsp)
 2a06907:	mov    %r10d,0x128(%rsp)
 2a0690f:	mov    %r11d,0x120(%rsp)
 2a06917:	mov    %edx,0x100(%rsp)
 2a0691e:	mov    0x2e8(%rsp),%r8
 2a06926:	mov    (%r8),%rcx
 2a06929:	mov    0x228(%rsp),%rax
 2a06931:	cmp    %rax,%rcx
 2a06934:	jae    2a17d86 <wasm[0]::function[1015]::helper::object_read+0x19c26>
 2a0693a:	mov    0xa0(%rsp),%r12d
 2a06942:	mov    0x130(%rsp),%edx
 2a06949:	mov    %rdx,0x1d8(%rsp)
 2a06951:	mov    0xd8(%rsp),%esi
 2a06958:	mov    %rsi,0x1e0(%rsp)
 2a06960:	mov    0x110(%rsp),%edi
 2a06967:	mov    %rdi,0x1e8(%rsp)
 2a0696f:	mov    0x138(%rsp),%r8d
 2a06977:	mov    %r8,0x1f0(%rsp)
 2a0697f:	mov    0x88(%rsp),%r13d
 2a06987:	mov    0xc8(%rsp),%r8d
 2a0698f:	mov    0x90(%rsp),%r9d
 2a06997:	mov    0x128(%rsp),%r10d
 2a0699f:	mov    0x120(%rsp),%r11d
 2a069a7:	mov    0x100(%rsp),%edx
 2a069ae:	mov    0x1f8(%rsp),%rcx
 2a069b6:	mov    0x208(%rsp),%rsi
 2a069be:	cmp    %esi,%ecx
 2a069c0:	jb     2a069d3 <wasm[0]::function[1015]::helper::object_read+0x8873>
 2a069c6:	mov    0x1d0(%rsp),%rax
 2a069ce:	jmp    2a06c11 <wasm[0]::function[1015]::helper::object_read+0x8ab1>
 2a069d3:	mov    0x108(%rsp),%eax
 2a069da:	test   %eax,%eax
 2a069dc:	je     2a1928a <wasm[0]::function[1015]::helper::object_read+0x1b12a>
 2a069e2:	test   %eax,%eax
 2a069e4:	je     2a1928c <wasm[0]::function[1015]::helper::object_read+0x1b12c>
 2a069ea:	mov    0x2e0(%rsp),%r14
 2a069f2:	mov    0x28(%r14),%rdx
 2a069f6:	mov    0x20(%r14),%rsi
 2a069fa:	mov    %eax,%r9d
 2a069fd:	lea    0x10(%rsi,%r9,1),%r8
 2a06a02:	xor    %rdi,%rdi
 2a06a05:	cmp    %rdx,%r9
 2a06a08:	cmova  %rdi,%r8
 2a06a0c:	mov    (%r8),%r8d
 2a06a0f:	cmp    %r8d,%ecx
 2a06a12:	jae    2a1928e <wasm[0]::function[1015]::helper::object_read+0x1b12e>
 2a06a18:	mov    %r8d,%r9d
 2a06a1b:	shl    $0x2,%r9
 2a06a1f:	shr    $0x20,%r9
 2a06a23:	test   %r9,%r9
 2a06a26:	jne    2a19290 <wasm[0]::function[1015]::helper::object_read+0x1b130>
 2a06a2c:	shl    $0x2,%r8d
 2a06a30:	add    $0x14,%r8d
 2a06a34:	jb     2a19292 <wasm[0]::function[1015]::helper::object_read+0x1b132>
 2a06a3a:	add    %r8d,%eax
 2a06a3d:	jb     2a19294 <wasm[0]::function[1015]::helper::object_read+0x1b134>
 2a06a43:	mov    %eax,%r9d
 2a06a46:	lea    (%rsi,%r9,1),%rax
 2a06a4a:	cmp    %rdx,%r9
 2a06a4d:	cmova  %rdi,%rax
 2a06a51:	mov    %rcx,%rdx
 2a06a54:	shl    $0x2,%edx
 2a06a57:	mov    %rcx,0x1f8(%rsp)
 2a06a5f:	lea    0x14(%rdx),%ecx
 2a06a62:	sub    %ecx,%r8d
 2a06a65:	sub    %r8,%rax
 2a06a68:	mov    (%rax),%edx
 2a06a6a:	test   %edx,%edx
 2a06a6c:	je     2a19296 <wasm[0]::function[1015]::helper::object_read+0x1b136>
 2a06a72:	mov    0x118(%rsp),%eax
 2a06a79:	cmp    %eax,%edx
 2a06a7b:	je     2a06b4e <wasm[0]::function[1015]::helper::object_read+0x89ee>
 2a06a81:	xor    %ecx,%ecx
 2a06a83:	test   %edx,%edx
 2a06a85:	je     2a06ac5 <wasm[0]::function[1015]::helper::object_read+0x8965>
 2a06a8b:	xor    %ecx,%ecx
 2a06a8d:	test   $0x1,%edx
 2a06a93:	jne    2a06ac5 <wasm[0]::function[1015]::helper::object_read+0x8965>
 2a06a99:	mov    0x2e0(%rsp),%r14
 2a06aa1:	mov    0x28(%r14),%rcx
 2a06aa5:	mov    0x20(%r14),%rsi
 2a06aa9:	mov    %edx,%edi
 2a06aab:	lea    0x4(%rsi,%rdi,1),%rsi
 2a06ab0:	xor    %r8,%r8
 2a06ab3:	cmp    %rcx,%rdi
 2a06ab6:	cmova  %r8,%rsi
 2a06aba:	mov    (%rsi),%ecx
 2a06abc:	cmp    %r15d,%ecx
 2a06abf:	sete   %cl
 2a06ac2:	movzbl %cl,%ecx
 2a06ac5:	test   %ecx,%ecx
 2a06ac7:	je     2a19298 <wasm[0]::function[1015]::helper::object_read+0x1b138>
 2a06acd:	xor    %ecx,%ecx
 2a06acf:	test   %eax,%eax
 2a06ad1:	je     2a06b1a <wasm[0]::function[1015]::helper::object_read+0x89ba>
 2a06ad7:	mov    0x118(%rsp),%esi
 2a06ade:	xor    %ecx,%ecx
 2a06ae0:	test   $0x1,%esi
 2a06ae6:	jne    2a06b1a <wasm[0]::function[1015]::helper::object_read+0x89ba>
 2a06aec:	mov    0x2e0(%rsp),%r14
 2a06af4:	mov    0x28(%r14),%rdi
 2a06af8:	mov    0x20(%r14),%r8
 2a06afc:	mov    %esi,%esi
 2a06afe:	lea    0x4(%r8,%rsi,1),%rcx
 2a06b03:	xor    %r8,%r8
 2a06b06:	cmp    %rdi,%rsi
 2a06b09:	cmova  %r8,%rcx
 2a06b0d:	mov    (%rcx),%esi
 2a06b0f:	cmp    %r15d,%esi
 2a06b12:	sete   %sil
 2a06b16:	movzbl %sil,%ecx
 2a06b1a:	test   %ecx,%ecx
 2a06b1c:	je     2a1929a <wasm[0]::function[1015]::helper::object_read+0x1b13a>
 2a06b22:	mov    0x118(%rsp),%ecx
 2a06b29:	xor    %r8d,%r8d
 2a06b2c:	test   %ecx,%ecx
 2a06b2e:	je     2a1929c <wasm[0]::function[1015]::helper::object_read+0x1b13c>
 2a06b34:	mov    0x190(%rsp),%rsi
 2a06b3c:	mov    0x190(%rsp),%rdi
 2a06b44:	call   2b02800 <wasm[0]::function[1057]::helper::string_equality>
 2a06b49:	jmp    2a06b56 <wasm[0]::function[1015]::helper::object_read+0x89f6>
 2a06b4e:	mov    0x278(%rsp),%rax
 2a06b56:	mov    0x108(%rsp),%ebx
 2a06b5d:	mov    0x118(%rsp),%r14d
 2a06b65:	mov    0xa0(%rsp),%r12d
 2a06b6d:	mov    0x130(%rsp),%edx
 2a06b74:	mov    %rdx,0x1d8(%rsp)
 2a06b7c:	mov    0xd8(%rsp),%esi
 2a06b83:	mov    %rsi,0x1e0(%rsp)
 2a06b8b:	mov    0x110(%rsp),%edi
 2a06b92:	mov    %rdi,0x1e8(%rsp)
 2a06b9a:	mov    0x138(%rsp),%r8d
 2a06ba2:	mov    %r8,0x1f0(%rsp)
 2a06baa:	mov    0x88(%rsp),%r13d
 2a06bb2:	mov    0xc8(%rsp),%r8d
 2a06bba:	mov    0x90(%rsp),%r9d
 2a06bc2:	mov    0x128(%rsp),%r10d
 2a06bca:	mov    0x120(%rsp),%r11d
 2a06bd2:	mov    0x100(%rsp),%edx
 2a06bd9:	test   %eax,%eax
 2a06bdb:	je     2a06bee <wasm[0]::function[1015]::helper::object_read+0x8a8e>
 2a06be1:	mov    0x1f8(%rsp),%rcx
 2a06be9:	jmp    2a06c11 <wasm[0]::function[1015]::helper::object_read+0x8ab1>
 2a06bee:	mov    0x1f8(%rsp),%rcx
 2a06bf6:	add    $0x1,%ecx
 2a06bfc:	mov    %rax,0x1d0(%rsp)
 2a06c04:	mov    %rcx,0x1f8(%rsp)
 2a06c0c:	jmp    2a0689c <wasm[0]::function[1015]::helper::object_read+0x873c>
 2a06c11:	xor    %r15,%r15
 2a06c14:	xor    %ebx,%ebx
 2a06c16:	test   %eax,%eax
 2a06c18:	jne    2a06c33 <wasm[0]::function[1015]::helper::object_read+0x8ad3>
 2a06c1e:	mov    %r15,0x260(%rsp)
 2a06c26:	mov    %rbx,0x268(%rsp)
 2a06c2e:	jmp    2a07045 <wasm[0]::function[1015]::helper::object_read+0x8ee5>
 2a06c33:	test   %r12d,%r12d
 2a06c36:	je     2a1929e <wasm[0]::function[1015]::helper::object_read+0x1b13e>
 2a06c3c:	xor    %eax,%eax
 2a06c3e:	test   $0x1,%r12d
 2a06c45:	jne    2a06c87 <wasm[0]::function[1015]::helper::object_read+0x8b27>
 2a06c4b:	mov    0x2e0(%rsp),%r14
 2a06c53:	mov    0x28(%r14),%rax
 2a06c57:	mov    0x20(%r14),%rsi
 2a06c5b:	mov    %r12d,%ebx
 2a06c5e:	lea    0x4(%rsi,%rbx,1),%rsi
 2a06c63:	xor    %r13,%r13
 2a06c66:	cmp    %rax,%rbx
 2a06c69:	cmova  %r13,%rsi
 2a06c6d:	mov    (%rsi),%eax
 2a06c6f:	mov    0x190(%rsp),%rsi
 2a06c77:	mov    0x28(%rsi),%rsi
 2a06c7b:	cmp    0x160(%rsi),%eax
 2a06c81:	sete   %al
 2a06c84:	movzbl %al,%eax
 2a06c87:	test   %eax,%eax
 2a06c89:	jne    2a06ed3 <wasm[0]::function[1015]::helper::object_read+0x8d73>
 2a06c8f:	xor    %eax,%eax
 2a06c91:	test   $0x1,%r12d
 2a06c98:	jne    2a06cda <wasm[0]::function[1015]::helper::object_read+0x8b7a>
 2a06c9e:	mov    0x2e0(%rsp),%r14
 2a06ca6:	mov    0x28(%r14),%rax
 2a06caa:	mov    0x20(%r14),%rsi
 2a06cae:	mov    %r12d,%ebx
 2a06cb1:	lea    0x4(%rsi,%rbx,1),%rsi
 2a06cb6:	xor    %r13,%r13
 2a06cb9:	cmp    %rax,%rbx
 2a06cbc:	cmova  %r13,%rsi
 2a06cc0:	mov    (%rsi),%eax
 2a06cc2:	mov    0x190(%rsp),%rsi
 2a06cca:	mov    0x28(%rsi),%rsi
 2a06cce:	cmp    0x15c(%rsi),%eax
 2a06cd4:	sete   %al
 2a06cd7:	movzbl %al,%eax
 2a06cda:	test   %eax,%eax
 2a06cdc:	je     2a192a0 <wasm[0]::function[1015]::helper::object_read+0x1b140>
 2a06ce2:	test   %r12d,%r12d
 2a06ce5:	je     2a192a2 <wasm[0]::function[1015]::helper::object_read+0x1b142>
 2a06ceb:	mov    0x2e0(%rsp),%r14
 2a06cf3:	mov    0x28(%r14),%rbx
 2a06cf7:	mov    0x20(%r14),%r13
 2a06cfb:	mov    %r12d,%eax
 2a06cfe:	lea    0x0(%r13,%rax,1),%rsi
 2a06d03:	xor    %r15,%r15
 2a06d06:	cmp    %rbx,%rax
 2a06d09:	cmova  %r15,%rsi
 2a06d0d:	mov    0x14(%rsi),%r14d
 2a06d11:	mov    0x18(%rsi),%eax
 2a06d14:	mov    0x1c(%rsi),%r12d
 2a06d18:	test   %r14d,%r14d
 2a06d1b:	je     2a192a4 <wasm[0]::function[1015]::helper::object_read+0x1b144>
 2a06d21:	test   %r14d,%r14d
 2a06d24:	je     2a192a6 <wasm[0]::function[1015]::helper::object_read+0x1b146>
 2a06d2a:	mov    %r14d,%edi
 2a06d2d:	lea    0x10(%r13,%rdi,1),%rsi
 2a06d32:	cmp    %rbx,%rdi
 2a06d35:	cmova  %r15,%rsi
 2a06d39:	mov    (%rsi),%esi
 2a06d3b:	cmp    %esi,%ecx
 2a06d3d:	jae    2a192a8 <wasm[0]::function[1015]::helper::object_read+0x1b148>
 2a06d43:	mov    %esi,%edi
 2a06d45:	shr    $0x20,%rdi
 2a06d49:	test   %rdi,%rdi
 2a06d4c:	jne    2a192aa <wasm[0]::function[1015]::helper::object_read+0x1b14a>
 2a06d52:	add    $0x14,%esi
 2a06d55:	jb     2a192ac <wasm[0]::function[1015]::helper::object_read+0x1b14c>
 2a06d5b:	add    %esi,%r14d
 2a06d5e:	jb     2a192ae <wasm[0]::function[1015]::helper::object_read+0x1b14e>
 2a06d64:	mov    %r14d,%edi
 2a06d67:	add    %rdi,%r13
 2a06d6a:	cmp    %rbx,%rdi
 2a06d6d:	cmova  %r15,%r13
 2a06d71:	lea    0x14(%rcx),%edi
 2a06d74:	sub    %edi,%esi
 2a06d76:	sub    %rsi,%r13
 2a06d79:	movzbq 0x0(%r13),%rsi
 2a06d7e:	mov    %rsi,0x208(%rsp)
 2a06d86:	test   %eax,%eax
 2a06d88:	je     2a06e11 <wasm[0]::function[1015]::helper::object_read+0x8cb1>
 2a06d8e:	test   %eax,%eax
 2a06d90:	je     2a192b0 <wasm[0]::function[1015]::helper::object_read+0x1b150>
 2a06d96:	test   %eax,%eax
 2a06d98:	je     2a192b2 <wasm[0]::function[1015]::helper::object_read+0x1b152>
 2a06d9e:	mov    0x2e0(%rsp),%r14
 2a06da6:	mov    0x28(%r14),%r13
 2a06daa:	mov    0x20(%r14),%r14
 2a06dae:	mov    %eax,%ebx
 2a06db0:	lea    0x10(%r14,%rbx,1),%rsi
 2a06db5:	xor    %r15,%r15
 2a06db8:	cmp    %r13,%rbx
 2a06dbb:	cmova  %r15,%rsi
 2a06dbf:	mov    (%rsi),%ebx
 2a06dc1:	cmp    %ebx,%ecx
 2a06dc3:	jae    2a192b4 <wasm[0]::function[1015]::helper::object_read+0x1b154>
 2a06dc9:	mov    %ebx,%esi
 2a06dcb:	shl    $0x3,%rsi
 2a06dcf:	shr    $0x20,%rsi
 2a06dd3:	test   %rsi,%rsi
 2a06dd6:	jne    2a192b6 <wasm[0]::function[1015]::helper::object_read+0x1b156>
 2a06ddc:	shl    $0x3,%ebx
 2a06ddf:	add    $0x18,%ebx
 2a06de2:	jb     2a192b8 <wasm[0]::function[1015]::helper::object_read+0x1b158>
 2a06de8:	add    %ebx,%eax
 2a06dea:	jb     2a192ba <wasm[0]::function[1015]::helper::object_read+0x1b15a>
 2a06df0:	mov    %eax,%eax
 2a06df2:	lea    (%r14,%rax,1),%rsi
 2a06df6:	cmp    %r13,%rax
 2a06df9:	cmova  %r15,%rsi
 2a06dfd:	mov    %rcx,%rax
 2a06e00:	shl    $0x3,%eax
 2a06e03:	add    $0x18,%eax
 2a06e09:	sub    %eax,%ebx
 2a06e0b:	sub    %rbx,%rsi
 2a06e0e:	mov    (%rsi),%r15
 2a06e11:	xor    %r13d,%r13d
 2a06e14:	test   %r12d,%r12d
 2a06e17:	jne    2a06e2a <wasm[0]::function[1015]::helper::object_read+0x8cca>
 2a06e1d:	mov    0x208(%rsp),%rsi
 2a06e25:	jmp    2a06eba <wasm[0]::function[1015]::helper::object_read+0x8d5a>
 2a06e2a:	test   %r12d,%r12d
 2a06e2d:	je     2a192bc <wasm[0]::function[1015]::helper::object_read+0x1b15c>
 2a06e33:	test   %r12d,%r12d
 2a06e36:	je     2a192be <wasm[0]::function[1015]::helper::object_read+0x1b15e>
 2a06e3c:	mov    0x2e0(%rsp),%r14
 2a06e44:	mov    0x28(%r14),%rax
 2a06e48:	mov    0x20(%r14),%rbx
 2a06e4c:	mov    %r12d,%r14d
 2a06e4f:	lea    0x10(%rbx,%r14,1),%rsi
 2a06e54:	xor    %r13,%r13
 2a06e57:	cmp    %rax,%r14
 2a06e5a:	cmova  %r13,%rsi
 2a06e5e:	mov    (%rsi),%r14d
 2a06e61:	cmp    %r14d,%ecx
 2a06e64:	jae    2a192c0 <wasm[0]::function[1015]::helper::object_read+0x1b160>
 2a06e6a:	mov    %r14d,%esi
 2a06e6d:	shl    $0x2,%rsi
 2a06e71:	shr    $0x20,%rsi
 2a06e75:	test   %rsi,%rsi
 2a06e78:	jne    2a192c2 <wasm[0]::function[1015]::helper::object_read+0x1b162>
 2a06e7e:	shl    $0x2,%r14d
 2a06e82:	add    $0x14,%r14d
 2a06e86:	jb     2a192c4 <wasm[0]::function[1015]::helper::object_read+0x1b164>
 2a06e8c:	add    %r14d,%r12d
 2a06e8f:	jb     2a192c6 <wasm[0]::function[1015]::helper::object_read+0x1b166>
 2a06e95:	mov    %r12d,%edi
 2a06e98:	lea    (%rbx,%rdi,1),%rsi
 2a06e9c:	cmp    %rax,%rdi
 2a06e9f:	cmova  %r13,%rsi
 2a06ea3:	shl    $0x2,%ecx
 2a06ea6:	lea    0x14(%rcx),%eax
 2a06ea9:	sub    %eax,%r14d
 2a06eac:	sub    %r14,%rsi
 2a06eaf:	mov    (%rsi),%r13d
 2a06eb2:	mov    0x208(%rsp),%rsi
 2a06eba:	movzbl %sil,%ebx
 2a06ebe:	mov    %r15,0x260(%rsp)
 2a06ec6:	mov    %rbx,0x268(%rsp)
 2a06ece:	jmp    2a07045 <wasm[0]::function[1015]::helper::object_read+0x8ee5>
 2a06ed3:	xor    %eax,%eax
 2a06ed5:	test   $0x1,%r12d
 2a06edc:	jne    2a06f1e <wasm[0]::function[1015]::helper::object_read+0x8dbe>
 2a06ee2:	mov    0x2e0(%rsp),%r14
 2a06eea:	mov    0x28(%r14),%rax
 2a06eee:	mov    0x20(%r14),%rsi
 2a06ef2:	mov    %r12d,%ebx
 2a06ef5:	lea    0x4(%rsi,%rbx,1),%rsi
 2a06efa:	xor    %r13,%r13
 2a06efd:	cmp    %rax,%rbx
 2a06f00:	cmova  %r13,%rsi
 2a06f04:	mov    (%rsi),%eax
 2a06f06:	mov    0x190(%rsp),%rsi
 2a06f0e:	mov    0x28(%rsi),%rsi
 2a06f12:	cmp    0x160(%rsi),%eax
 2a06f18:	sete   %al
 2a06f1b:	movzbl %al,%eax
 2a06f1e:	test   %eax,%eax
 2a06f20:	je     2a192c8 <wasm[0]::function[1015]::helper::object_read+0x1b168>
 2a06f26:	test   %r12d,%r12d
 2a06f29:	je     2a192ca <wasm[0]::function[1015]::helper::object_read+0x1b16a>
 2a06f2f:	mov    0x2e0(%rsp),%r14
 2a06f37:	mov    0x28(%r14),%rbx
 2a06f3b:	mov    0x20(%r14),%r13
 2a06f3f:	mov    %r12d,%eax
 2a06f42:	lea    0x0(%r13,%rax,1),%rsi
 2a06f47:	xor    %r12,%r12
 2a06f4a:	cmp    %rbx,%rax
 2a06f4d:	cmova  %r12,%rsi
 2a06f51:	mov    0x10(%rsi),%esi
 2a06f54:	test   %esi,%esi
 2a06f56:	je     2a192cc <wasm[0]::function[1015]::helper::object_read+0x1b16c>
 2a06f5c:	test   %esi,%esi
 2a06f5e:	je     2a192ce <wasm[0]::function[1015]::helper::object_read+0x1b16e>
 2a06f64:	mov    %esi,%edi
 2a06f66:	lea    0x0(%r13,%rdi,1),%rsi
 2a06f6b:	cmp    %rbx,%rdi
 2a06f6e:	cmova  %r12,%rsi
 2a06f72:	mov    0x10(%rsi),%esi
 2a06f75:	test   %esi,%esi
 2a06f77:	je     2a192d0 <wasm[0]::function[1015]::helper::object_read+0x1b170>
 2a06f7d:	test   %esi,%esi
 2a06f7f:	je     2a192d2 <wasm[0]::function[1015]::helper::object_read+0x1b172>
 2a06f85:	mov    %esi,%edi
 2a06f87:	lea    0x10(%r13,%rdi,1),%rsi
 2a06f8c:	cmp    %rbx,%rdi
 2a06f8f:	cmova  %r12,%rsi
 2a06f93:	cmp    (%rsi),%ecx
 2a06f95:	setae  %sil
 2a06f99:	cmp    $0x2,%ecx
 2a06f9c:	setae  %dil
 2a06fa0:	or     %edi,%esi
 2a06fa2:	test   %sil,%sil
 2a06fa5:	jne    2a192d4 <wasm[0]::function[1015]::helper::object_read+0x1b174>
 2a06fab:	mov    0x2e0(%rsp),%r14
 2a06fb3:	mov    0x28(%r14),%rbx
 2a06fb7:	mov    %rax,%rsi
 2a06fba:	add    0x20(%r14),%rsi
 2a06fbe:	xor    %r12,%r12
 2a06fc1:	cmp    %rbx,%rax
 2a06fc4:	cmova  %r12,%rsi
 2a06fc8:	mov    0x14(%rsi),%ebx
 2a06fcb:	test   %ecx,%ecx
 2a06fcd:	je     2a07005 <wasm[0]::function[1015]::helper::object_read+0x8ea5>
 2a06fd3:	mov    0x2e0(%rsp),%r14
 2a06fdb:	mov    0x28(%r14),%r12
 2a06fdf:	mov    0x20(%r14),%rsi
 2a06fe3:	add    %rax,%rsi
 2a06fe6:	xor    %r13,%r13
 2a06fe9:	cmp    %r12,%rax
 2a06fec:	cmova  %r13,%rsi
 2a06ff0:	mov    0x20(%rsi),%r15
 2a06ff4:	mov    0x2c(%rsi),%r13d
 2a06ff8:	mov    %r15,0x260(%rsp)
 2a07000:	jmp    2a07032 <wasm[0]::function[1015]::helper::object_read+0x8ed2>
 2a07005:	mov    0x2e0(%rsp),%r14
 2a0700d:	mov    0x28(%r14),%r12
 2a07011:	mov    0x20(%r14),%rsi
 2a07015:	add    %rax,%rsi
 2a07018:	xor    %r13,%r13
 2a0701b:	cmp    %r12,%rax
 2a0701e:	cmova  %r13,%rsi
 2a07022:	mov    0x18(%rsi),%r15
 2a07026:	mov    %r15,0x260(%rsp)
 2a0702e:	mov    0x28(%rsi),%r13d
 2a07032:	shl    $0x3,%ecx
 2a07035:	shr    %cl,%ebx
 2a07037:	and    $0xff,%ebx
 2a0703d:	mov    %rbx,0x268(%rsp)
 2a07045:	mov    0x1d8(%rsp),%rax
 2a0704d:	mov    %eax,0x90(%rsp)
 2a07054:	mov    0x1e0(%rsp),%rsi
 2a0705c:	mov    %esi,0xc8(%rsp)
 2a07063:	mov    0x1e8(%rsp),%rdi
 2a0706b:	mov    %edi,0x88(%rsp)
 2a07072:	mov    0x1f0(%rsp),%rax
 2a0707a:	mov    %eax,0x138(%rsp)
 2a07081:	mov    %r13d,0x110(%rsp)
 2a07089:	mov    %r8d,0xd8(%rsp)
 2a07091:	mov    %r9d,0x130(%rsp)
 2a07099:	mov    %r10d,0xa0(%rsp)
 2a070a1:	mov    %r11d,0x118(%rsp)
 2a070a9:	mov    %edx,0x108(%rsp)
 2a070b0:	mov    $0x286,%edx
 2a070b5:	mov    0x190(%rsp),%rsi
 2a070bd:	mov    0x190(%rsp),%rdi
 2a070c5:	call   2f4f240 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 2a070ca:	mov    %eax,0x128(%rsp)
 2a070d1:	xor    %r12d,%r12d
 2a070d4:	mov    %r12,0x1a0(%rsp)
 2a070dc:	test   %eax,%eax
 2a070de:	je     2a192d6 <wasm[0]::function[1015]::helper::object_read+0x1b176>
 2a070e4:	movl   $0x0,0x120(%rsp)
 2a070ef:	mov    0x90(%rsp),%edx
 2a070f6:	mov    %rdx,0x1f8(%rsp)
 2a070fe:	mov    0xc8(%rsp),%esi
 2a07105:	mov    %rsi,0x208(%rsp)
 2a0710d:	mov    0x88(%rsp),%edi
 2a07114:	mov    %rdi,0x218(%rsp)
 2a0711c:	mov    0x138(%rsp),%r11d
 2a07124:	mov    %r11,0x220(%rsp)
 2a0712c:	mov    0x110(%rsp),%r8d
 2a07134:	mov    %r8,0x198(%rsp)
 2a0713c:	mov    0xd8(%rsp),%r8d
 2a07144:	mov    0x130(%rsp),%r9d
 2a0714c:	mov    0xa0(%rsp),%edx
 2a07153:	mov    0x118(%rsp),%r10d
 2a0715b:	mov    0x108(%rsp),%ebx
 2a07162:	xor    %r12,%r12
 2a07165:	mov    0x2a0(%rsp),%rax
 2a0716d:	mov    0x2a0(%rsp),%rcx
 2a07175:	test   %al,%cl
 2a07177:	jne    2a0719a <wasm[0]::function[1015]::helper::object_read+0x903a>
 2a0717d:	mov    0x1f8(%rsp),%rax
 2a07185:	mov    0x1a0(%rsp),%r15
 2a0718d:	mov    %r12,0x1c8(%rsp)
 2a07195:	jmp    2a07ed8 <wasm[0]::function[1015]::helper::object_read+0x9d78>
 2a0719a:	mov    0x90(%rsp),%r8d
 2a071a2:	mov    0x2b8(%rsp),%rcx
 2a071aa:	mov    0x2a8(%rsp),%rdx
 2a071b2:	mov    0x190(%rsp),%rsi
 2a071ba:	mov    0x190(%rsp),%rdi
 2a071c2:	call   2a7c940 <wasm[0]::function[1039]::helper::object_header_projection>
 2a071c7:	mov    %eax,0x100(%rsp)
 2a071ce:	test   %eax,%eax
 2a071d0:	je     2a192d8 <wasm[0]::function[1015]::helper::object_read+0x1b178>
 2a071d6:	test   %eax,%eax
 2a071d8:	je     2a192da <wasm[0]::function[1015]::helper::object_read+0x1b17a>
 2a071de:	mov    0x2e0(%rsp),%r14
 2a071e6:	mov    0x28(%r14),%rcx
 2a071ea:	mov    0x20(%r14),%rsi
 2a071ee:	mov    %eax,%edx
 2a071f0:	lea    (%rsi,%rdx,1),%rax
 2a071f4:	xor    %rsi,%rsi
 2a071f7:	cmp    %rcx,%rdx
 2a071fa:	cmova  %rsi,%rax
 2a071fe:	mov    0x14(%rax),%eax
 2a07201:	mov    %eax,0xf8(%rsp)
 2a07208:	test   %eax,%eax
 2a0720a:	je     2a192dc <wasm[0]::function[1015]::helper::object_read+0x1b17c>
 2a07210:	mov    0xf8(%rsp),%ecx
 2a07217:	xor    %eax,%eax
 2a07219:	test   $0x1,%ecx
 2a0721f:	jne    2a07277 <wasm[0]::function[1015]::helper::object_read+0x9117>
 2a07225:	mov    0x2e0(%rsp),%r14
 2a0722d:	mov    0x28(%r14),%rax
 2a07231:	mov    0x20(%r14),%rsi
 2a07235:	mov    %ecx,%edx
 2a07237:	lea    0x4(%rsi,%rdx,1),%rcx
 2a0723c:	xor    %rsi,%rsi
 2a0723f:	cmp    %rax,%rdx
 2a07242:	cmova  %rsi,%rcx
 2a07246:	mov    (%rcx),%esi
 2a07248:	mov    0x190(%rsp),%rcx
 2a07250:	mov    0x28(%rcx),%rax
 2a07254:	mov    0x158(%rax),%edx
 2a0725a:	cmp    %edx,%esi
 2a0725c:	sete   %al
 2a0725f:	movzbl %al,%eax
 2a07262:	cmp    %edx,%esi
 2a07264:	je     2a07277 <wasm[0]::function[1015]::helper::object_read+0x9117>
 2a0726a:	mov    0x190(%rsp),%rdi
 2a07272:	call   3039cc5 <wasmtime_builtin_is_subtype>
 2a07277:	test   %eax,%eax
 2a07279:	jne    2a0752a <wasm[0]::function[1015]::helper::object_read+0x93ca>
 2a0727f:	mov    0x100(%rsp),%edx
 2a07286:	xor    %ebx,%ebx
 2a07288:	test   %edx,%edx
 2a0728a:	je     2a192de <wasm[0]::function[1015]::helper::object_read+0x1b17e>
 2a07290:	mov    0x128(%rsp),%r9d
 2a07298:	mov    $0x4,%ecx
 2a0729d:	xor    %r8,%r8
 2a072a0:	mov    0x190(%rsp),%rsi
 2a072a8:	mov    0x190(%rsp),%rdi
 2a072b0:	call   2a76140 <wasm[0]::function[1032]::helper::ordinary_property_find>
 2a072b5:	test   %eax,%eax
 2a072b7:	je     2a072ef <wasm[0]::function[1015]::helper::object_read+0x918f>
 2a072bd:	test   %eax,%eax
 2a072bf:	je     2a192e0 <wasm[0]::function[1015]::helper::object_read+0x1b180>
 2a072c5:	test   %eax,%eax
 2a072c7:	je     2a192e2 <wasm[0]::function[1015]::helper::object_read+0x1b182>
 2a072cd:	mov    0x2e0(%rsp),%r14
 2a072d5:	mov    0x28(%r14),%rcx
 2a072d9:	mov    %eax,%edx
 2a072db:	mov    %rdx,%rax
 2a072de:	add    0x20(%r14),%rax
 2a072e2:	xor    %rsi,%rsi
 2a072e5:	cmp    %rcx,%rdx
 2a072e8:	cmova  %rsi,%rax
 2a072ec:	mov    0x14(%rax),%ebx
 2a072ef:	mov    0x120(%rsp),%r15d
 2a072f7:	xor    %r12d,%r12d
 2a072fa:	mov    %r12,0x1a0(%rsp)
 2a07302:	xor    %r12,%r12
 2a07305:	test   %ebx,%ebx
 2a07307:	je     2a074aa <wasm[0]::function[1015]::helper::object_read+0x934a>
 2a0730d:	test   %ebx,%ebx
 2a0730f:	je     2a192e4 <wasm[0]::function[1015]::helper::object_read+0x1b184>
 2a07315:	mov    0x2e0(%rsp),%r14
 2a0731d:	mov    0x28(%r14),%rcx
 2a07321:	mov    0x20(%r14),%rax
 2a07325:	mov    %ebx,%edx
 2a07327:	add    %rdx,%rax
 2a0732a:	xor    %r12,%r12
 2a0732d:	cmp    %rcx,%rdx
 2a07330:	cmova  %r12,%rax
 2a07334:	mov    0x10(%rax),%ecx
 2a07337:	mov    0x120(%rsp),%r15d
 2a0733f:	mov    %rdx,%rsi
 2a07342:	mov    %rdx,0x1a0(%rsp)
 2a0734a:	xor    %esi,%edx
 2a0734c:	mov    %rdx,0x1a0(%rsp)
 2a07354:	test   $0x1,%ecx
 2a0735a:	jne    2a074aa <wasm[0]::function[1015]::helper::object_read+0x934a>
 2a07360:	mov    0x14(%rax),%edx
 2a07363:	test   %edx,%edx
 2a07365:	je     2a192e6 <wasm[0]::function[1015]::helper::object_read+0x1b186>
 2a0736b:	xor    %eax,%eax
 2a0736d:	test   $0x1,%edx
 2a07373:	jne    2a073b8 <wasm[0]::function[1015]::helper::object_read+0x9258>
 2a07379:	mov    0x2e0(%rsp),%r14
 2a07381:	mov    0x28(%r14),%rsi
 2a07385:	mov    0x20(%r14),%rdi
 2a07389:	mov    %edx,%r8d
 2a0738c:	lea    0x4(%rdi,%r8,1),%rdi
 2a07391:	xor    %r9,%r9
 2a07394:	cmp    %rsi,%r8
 2a07397:	cmova  %r9,%rdi
 2a0739b:	mov    (%rdi),%edi
 2a0739d:	mov    0x190(%rsp),%rcx
 2a073a5:	mov    0x28(%rcx),%r8
 2a073a9:	cmp    0x120(%r8),%edi
 2a073b0:	sete   %r8b
 2a073b4:	movzbl %r8b,%eax
 2a073b8:	test   %eax,%eax
 2a073ba:	jne    2a0741e <wasm[0]::function[1015]::helper::object_read+0x92be>
 2a073c0:	mov    0x190(%rsp),%rsi
 2a073c8:	mov    0x190(%rsp),%rdi
 2a073d0:	call   2a1eec0 <wasm[0]::function[1024]::helper::property_value_resolve>
 2a073d5:	test   %eax,%eax
 2a073d7:	je     2a192e8 <wasm[0]::function[1015]::helper::object_read+0x1b188>
 2a073dd:	test   %eax,%eax
 2a073df:	je     2a192ea <wasm[0]::function[1015]::helper::object_read+0x1b18a>
 2a073e5:	mov    0x2e0(%rsp),%r14
 2a073ed:	mov    0x28(%r14),%rcx
 2a073f1:	mov    0x20(%r14),%rsi
 2a073f5:	mov    %eax,%edx
 2a073f7:	lea    (%rsi,%rdx,1),%rax
 2a073fb:	xor    %rsi,%rsi
 2a073fe:	cmp    %rcx,%rdx
 2a07401:	cmova  %rsi,%rax
 2a07405:	mov    0x18(%rax),%r12d
 2a07409:	mov    %r12,0x1a0(%rsp)
 2a07411:	mov    0x10(%rax),%r12
 2a07415:	mov    0x1c(%rax),%r15d
 2a07419:	jmp    2a074aa <wasm[0]::function[1015]::helper::object_read+0x934a>
 2a0741e:	xor    %eax,%eax
 2a07420:	test   $0x1,%edx
 2a07426:	jne    2a07467 <wasm[0]::function[1015]::helper::object_read+0x9307>
 2a0742c:	mov    0x2e0(%rsp),%r14
 2a07434:	mov    0x28(%r14),%rax
 2a07438:	mov    0x20(%r14),%rcx
 2a0743c:	mov    %edx,%esi
 2a0743e:	lea    0x4(%rcx,%rsi,1),%rcx
 2a07443:	xor    %rdi,%rdi
 2a07446:	cmp    %rax,%rsi
 2a07449:	cmova  %rdi,%rcx
 2a0744d:	mov    (%rcx),%eax
 2a0744f:	mov    0x190(%rsp),%rcx
 2a07457:	mov    0x28(%rcx),%rcx
 2a0745b:	cmp    0x120(%rcx),%eax
 2a07461:	sete   %al
 2a07464:	movzbl %al,%eax
 2a07467:	test   %eax,%eax
 2a07469:	je     2a192ec <wasm[0]::function[1015]::helper::object_read+0x1b18c>
 2a0746f:	test   %edx,%edx
 2a07471:	je     2a192ee <wasm[0]::function[1015]::helper::object_read+0x1b18e>
 2a07477:	mov    0x2e0(%rsp),%r14
 2a0747f:	mov    0x28(%r14),%rcx
 2a07483:	mov    0x20(%r14),%rax
 2a07487:	mov    %edx,%edx
 2a07489:	add    %rdx,%rax
 2a0748c:	xor    %rsi,%rsi
 2a0748f:	cmp    %rcx,%rdx
 2a07492:	cmova  %rsi,%rax
 2a07496:	mov    0x18(%rax),%r12d
 2a0749a:	mov    %r12,0x1a0(%rsp)
 2a074a2:	mov    0x10(%rax),%r12
 2a074a6:	mov    0x1c(%rax),%r15d
 2a074aa:	mov    0x90(%rsp),%edx
 2a074b1:	mov    %rdx,0x1f8(%rsp)
 2a074b9:	mov    0xc8(%rsp),%esi
 2a074c0:	mov    %rsi,0x208(%rsp)
 2a074c8:	mov    0x88(%rsp),%edi
 2a074cf:	mov    %rdi,0x218(%rsp)
 2a074d7:	mov    0x138(%rsp),%r11d
 2a074df:	mov    %r11,0x220(%rsp)
 2a074e7:	mov    0x110(%rsp),%r8d
 2a074ef:	mov    %r8,0x198(%rsp)
 2a074f7:	mov    0xd8(%rsp),%r8d
 2a074ff:	mov    0x130(%rsp),%r9d
 2a07507:	mov    0xa0(%rsp),%edx
 2a0750e:	mov    0x118(%rsp),%r10d
 2a07516:	mov    0x108(%rsp),%ebx
 2a0751d:	mov    %r12,0x1c8(%rsp)
 2a07525:	jmp    2a07ed0 <wasm[0]::function[1015]::helper::object_read+0x9d70>
 2a0752a:	mov    0xf8(%rsp),%eax
 2a07531:	test   %eax,%eax
 2a07533:	je     2a192f0 <wasm[0]::function[1015]::helper::object_read+0x1b190>
 2a07539:	mov    0xf8(%rsp),%ecx
 2a07540:	xor    %eax,%eax
 2a07542:	test   $0x1,%ecx
 2a07548:	jne    2a075a0 <wasm[0]::function[1015]::helper::object_read+0x9440>
 2a0754e:	mov    0x2e0(%rsp),%r14
 2a07556:	mov    0x28(%r14),%rax
 2a0755a:	mov    0x20(%r14),%rsi
 2a0755e:	mov    %ecx,%edx
 2a07560:	lea    0x4(%rsi,%rdx,1),%rcx
 2a07565:	xor    %rsi,%rsi
 2a07568:	cmp    %rax,%rdx
 2a0756b:	cmova  %rsi,%rcx
 2a0756f:	mov    (%rcx),%esi
 2a07571:	mov    0x190(%rsp),%rcx
 2a07579:	mov    0x28(%rcx),%rax
 2a0757d:	mov    0x158(%rax),%edx
 2a07583:	cmp    %edx,%esi
 2a07585:	sete   %al
 2a07588:	movzbl %al,%eax
 2a0758b:	cmp    %edx,%esi
 2a0758d:	je     2a075a0 <wasm[0]::function[1015]::helper::object_read+0x9440>
 2a07593:	mov    0x190(%rsp),%rdi
 2a0759b:	call   3039cc5 <wasmtime_builtin_is_subtype>
 2a075a0:	test   %eax,%eax
 2a075a2:	je     2a192f2 <wasm[0]::function[1015]::helper::object_read+0x1b192>
 2a075a8:	mov    0xf8(%rsp),%r13d
 2a075b0:	mov    0x90(%rsp),%edx
 2a075b7:	mov    %rdx,0x1f8(%rsp)
 2a075bf:	mov    0xc8(%rsp),%esi
 2a075c6:	mov    %rsi,0x208(%rsp)
 2a075ce:	mov    0x120(%rsp),%r15d
 2a075d6:	mov    0x88(%rsp),%edi
 2a075dd:	mov    %rdi,0x218(%rsp)
 2a075e5:	mov    0x138(%rsp),%r11d
 2a075ed:	mov    %r11,0x220(%rsp)
 2a075f5:	mov    0x110(%rsp),%r8d
 2a075fd:	mov    %r8,0x198(%rsp)
 2a07605:	mov    0xd8(%rsp),%r8d
 2a0760d:	mov    0x130(%rsp),%r9d
 2a07615:	mov    0xa0(%rsp),%edx
 2a0761c:	mov    0x118(%rsp),%r10d
 2a07624:	mov    0x108(%rsp),%ebx
 2a0762b:	xor    %ecx,%ecx
 2a0762d:	mov    %rcx,0x2b0(%rsp)
 2a07635:	test   %r13d,%r13d
 2a07638:	je     2a192f4 <wasm[0]::function[1015]::helper::object_read+0x1b194>
 2a0763e:	test   %r13d,%r13d
 2a07641:	je     2a192f6 <wasm[0]::function[1015]::helper::object_read+0x1b196>
 2a07647:	mov    0x2e0(%rsp),%r14
 2a0764f:	mov    0x28(%r14),%rax
 2a07653:	mov    0x20(%r14),%rcx
 2a07657:	mov    %r13d,%edi
 2a0765a:	lea    (%rcx,%rdi,1),%rsi
 2a0765e:	xor    %r12,%r12
 2a07661:	cmp    %rax,%rdi
 2a07664:	cmova  %r12,%rsi
 2a07668:	mov    0x10(%rsi),%esi
 2a0766b:	test   %esi,%esi
 2a0766d:	je     2a192f8 <wasm[0]::function[1015]::helper::object_read+0x1b198>
 2a07673:	test   %esi,%esi
 2a07675:	je     2a192fa <wasm[0]::function[1015]::helper::object_read+0x1b19a>
 2a0767b:	mov    %esi,%edi
 2a0767d:	lea    (%rcx,%rdi,1),%rsi
 2a07681:	cmp    %rax,%rdi
 2a07684:	cmova  %r12,%rsi
 2a07688:	mov    0x10(%rsi),%esi
 2a0768b:	test   %esi,%esi
 2a0768d:	je     2a192fc <wasm[0]::function[1015]::helper::object_read+0x1b19c>
 2a07693:	test   %esi,%esi
 2a07695:	je     2a192fe <wasm[0]::function[1015]::helper::object_read+0x1b19e>
 2a0769b:	mov    %esi,%edi
 2a0769d:	lea    0x10(%rcx,%rdi,1),%rcx
 2a076a2:	cmp    %rax,%rdi
 2a076a5:	cmova  %r12,%rcx
 2a076a9:	mov    (%rcx),%ecx
 2a076ab:	mov    %rcx,0x1d0(%rsp)
 2a076b3:	mov    0x128(%rsp),%r14d
 2a076bb:	mov    0x190(%rsp),%rcx
 2a076c3:	mov    0x28(%rcx),%rcx
 2a076c7:	mov    0x234(%rcx),%r12d
 2a076ce:	mov    0x2b0(%rsp),%rax
 2a076d6:	mov    %rax,0x1f0(%rsp)
 2a076de:	mov    %esi,0x100(%rsp)
 2a076e5:	mov    %r14d,0x108(%rsp)
 2a076ed:	mov    %r13d,0x118(%rsp)
 2a076f5:	mov    0x1f8(%rsp),%rsi
 2a076fd:	mov    %esi,0xa0(%rsp)
 2a07704:	mov    0x208(%rsp),%rsi
 2a0770c:	mov    %esi,0x130(%rsp)
 2a07713:	mov    %r15d,0xd8(%rsp)
 2a0771b:	mov    0x218(%rsp),%rdi
 2a07723:	mov    %edi,0x110(%rsp)
 2a0772a:	mov    0x220(%rsp),%r11
 2a07732:	mov    %r11d,0x138(%rsp)
 2a0773a:	mov    0x198(%rsp),%rax
 2a07742:	mov    %eax,0x88(%rsp)
 2a07749:	mov    %r8d,0x120(%rsp)
 2a07751:	mov    %r9d,0xc8(%rsp)
 2a07759:	mov    %edx,0x90(%rsp)
 2a07760:	mov    %r10d,0xf8(%rsp)
 2a07768:	mov    %ebx,0x128(%rsp)
 2a0776f:	mov    0x2e8(%rsp),%r15
 2a07777:	mov    (%r15),%rcx
 2a0777a:	mov    0x228(%rsp),%rax
 2a07782:	cmp    %rax,%rcx
 2a07785:	jae    2a17dbd <wasm[0]::function[1015]::helper::object_read+0x19c5d>
 2a0778b:	mov    0x118(%rsp),%r13d
 2a07793:	mov    0xa0(%rsp),%edx
 2a0779a:	mov    %rdx,0x1f8(%rsp)
 2a077a2:	mov    0x130(%rsp),%esi
 2a077a9:	mov    %rsi,0x208(%rsp)
 2a077b1:	mov    0xd8(%rsp),%r15d
 2a077b9:	mov    0x110(%rsp),%edi
 2a077c0:	mov    %rdi,0x218(%rsp)
 2a077c8:	mov    0x138(%rsp),%r11d
 2a077d0:	mov    %r11,0x220(%rsp)
 2a077d8:	mov    0x88(%rsp),%r8d
 2a077e0:	mov    %r8,0x198(%rsp)
 2a077e8:	mov    0x120(%rsp),%r8d
 2a077f0:	mov    0xc8(%rsp),%r9d
 2a077f8:	mov    0x90(%rsp),%edx
 2a077ff:	mov    0xf8(%rsp),%r10d
 2a07807:	mov    0x128(%rsp),%ebx
 2a0780e:	mov    0x2b0(%rsp),%rcx
 2a07816:	mov    0x1d0(%rsp),%rsi
 2a0781e:	cmp    %esi,%ecx
 2a07820:	jb     2a07833 <wasm[0]::function[1015]::helper::object_read+0x96d3>
 2a07826:	mov    0x1f0(%rsp),%rax
 2a0782e:	jmp    2a07a7d <wasm[0]::function[1015]::helper::object_read+0x991d>
 2a07833:	mov    0x100(%rsp),%eax
 2a0783a:	test   %eax,%eax
 2a0783c:	je     2a19300 <wasm[0]::function[1015]::helper::object_read+0x1b1a0>
 2a07842:	test   %eax,%eax
 2a07844:	je     2a19302 <wasm[0]::function[1015]::helper::object_read+0x1b1a2>
 2a0784a:	mov    0x2e0(%rsp),%r14
 2a07852:	mov    0x28(%r14),%rdx
 2a07856:	mov    0x20(%r14),%rsi
 2a0785a:	mov    %eax,%r9d
 2a0785d:	lea    0x10(%rsi,%r9,1),%r8
 2a07862:	xor    %rdi,%rdi
 2a07865:	cmp    %rdx,%r9
 2a07868:	cmova  %rdi,%r8
 2a0786c:	mov    (%r8),%r8d
 2a0786f:	cmp    %r8d,%ecx
 2a07872:	jae    2a19304 <wasm[0]::function[1015]::helper::object_read+0x1b1a4>
 2a07878:	mov    %r8d,%r9d
 2a0787b:	shl    $0x2,%r9
 2a0787f:	shr    $0x20,%r9
 2a07883:	test   %r9,%r9
 2a07886:	jne    2a19306 <wasm[0]::function[1015]::helper::object_read+0x1b1a6>
 2a0788c:	shl    $0x2,%r8d
 2a07890:	add    $0x14,%r8d
 2a07894:	jb     2a19308 <wasm[0]::function[1015]::helper::object_read+0x1b1a8>
 2a0789a:	add    %r8d,%eax
 2a0789d:	jb     2a1930a <wasm[0]::function[1015]::helper::object_read+0x1b1aa>
 2a078a3:	mov    %eax,%r9d
 2a078a6:	lea    (%rsi,%r9,1),%rax
 2a078aa:	cmp    %rdx,%r9
 2a078ad:	cmova  %rdi,%rax
 2a078b1:	mov    %rcx,%rdx
 2a078b4:	shl    $0x2,%edx
 2a078b7:	mov    %rcx,0x2b0(%rsp)
 2a078bf:	lea    0x14(%rdx),%ecx
 2a078c2:	sub    %ecx,%r8d
 2a078c5:	sub    %r8,%rax
 2a078c8:	mov    (%rax),%edx
 2a078ca:	test   %edx,%edx
 2a078cc:	je     2a1930c <wasm[0]::function[1015]::helper::object_read+0x1b1ac>
 2a078d2:	mov    0x108(%rsp),%eax
 2a078d9:	cmp    %eax,%edx
 2a078db:	je     2a079ab <wasm[0]::function[1015]::helper::object_read+0x984b>
 2a078e1:	xor    %ecx,%ecx
 2a078e3:	test   %edx,%edx
 2a078e5:	je     2a07925 <wasm[0]::function[1015]::helper::object_read+0x97c5>
 2a078eb:	xor    %ecx,%ecx
 2a078ed:	test   $0x1,%edx
 2a078f3:	jne    2a07925 <wasm[0]::function[1015]::helper::object_read+0x97c5>
 2a078f9:	mov    0x2e0(%rsp),%r14
 2a07901:	mov    0x28(%r14),%rcx
 2a07905:	mov    0x20(%r14),%rsi
 2a07909:	mov    %edx,%edi
 2a0790b:	lea    0x4(%rsi,%rdi,1),%rsi
 2a07910:	xor    %r8,%r8
 2a07913:	cmp    %rcx,%rdi
 2a07916:	cmova  %r8,%rsi
 2a0791a:	mov    (%rsi),%ecx
 2a0791c:	cmp    %r12d,%ecx
 2a0791f:	sete   %cl
 2a07922:	movzbl %cl,%ecx
 2a07925:	test   %ecx,%ecx
 2a07927:	je     2a1930e <wasm[0]::function[1015]::helper::object_read+0x1b1ae>
 2a0792d:	xor    %ecx,%ecx
 2a0792f:	test   %eax,%eax
 2a07931:	je     2a07977 <wasm[0]::function[1015]::helper::object_read+0x9817>
 2a07937:	mov    0x108(%rsp),%eax
 2a0793e:	xor    %ecx,%ecx
 2a07940:	test   $0x1,%eax
 2a07945:	jne    2a07977 <wasm[0]::function[1015]::helper::object_read+0x9817>
 2a0794b:	mov    0x2e0(%rsp),%r14
 2a07953:	mov    0x28(%r14),%rcx
 2a07957:	mov    0x20(%r14),%rdi
 2a0795b:	mov    %eax,%esi
 2a0795d:	lea    0x4(%rdi,%rsi,1),%rax
 2a07962:	xor    %rdi,%rdi
 2a07965:	cmp    %rcx,%rsi
 2a07968:	cmova  %rdi,%rax
 2a0796c:	mov    (%rax),%eax
 2a0796e:	cmp    %r12d,%eax
 2a07971:	sete   %cl
 2a07974:	movzbl %cl,%ecx
 2a07977:	test   %ecx,%ecx
 2a07979:	je     2a19310 <wasm[0]::function[1015]::helper::object_read+0x1b1b0>
 2a0797f:	mov    0x108(%rsp),%ecx
 2a07986:	xor    %r8d,%r8d
 2a07989:	test   %ecx,%ecx
 2a0798b:	je     2a19312 <wasm[0]::function[1015]::helper::object_read+0x1b1b2>
 2a07991:	mov    0x190(%rsp),%rsi
 2a07999:	mov    0x190(%rsp),%rdi
 2a079a1:	call   2b02800 <wasm[0]::function[1057]::helper::string_equality>
 2a079a6:	jmp    2a079b3 <wasm[0]::function[1015]::helper::object_read+0x9853>
 2a079ab:	mov    0x278(%rsp),%rax
 2a079b3:	mov    0x100(%rsp),%esi
 2a079ba:	mov    0x108(%rsp),%r14d
 2a079c2:	mov    0x118(%rsp),%r13d
 2a079ca:	mov    0xa0(%rsp),%edx
 2a079d1:	mov    %rdx,0x1f8(%rsp)
 2a079d9:	mov    0x130(%rsp),%ecx
 2a079e0:	mov    %rcx,0x208(%rsp)
 2a079e8:	mov    0xd8(%rsp),%r15d
 2a079f0:	mov    0x110(%rsp),%edi
 2a079f7:	mov    %rdi,0x218(%rsp)
 2a079ff:	mov    0x138(%rsp),%r11d
 2a07a07:	mov    %r11,0x220(%rsp)
 2a07a0f:	mov    0x88(%rsp),%r8d
 2a07a17:	mov    %r8,0x198(%rsp)
 2a07a1f:	mov    0x120(%rsp),%r8d
 2a07a27:	mov    0xc8(%rsp),%r9d
 2a07a2f:	mov    0x90(%rsp),%edx
 2a07a36:	mov    0xf8(%rsp),%r10d
 2a07a3e:	mov    0x128(%rsp),%ebx
 2a07a45:	test   %eax,%eax
 2a07a47:	je     2a07a5a <wasm[0]::function[1015]::helper::object_read+0x98fa>
 2a07a4d:	mov    0x2b0(%rsp),%rcx
 2a07a55:	jmp    2a07a7d <wasm[0]::function[1015]::helper::object_read+0x991d>
 2a07a5a:	mov    0x2b0(%rsp),%rcx
 2a07a62:	add    $0x1,%ecx
 2a07a68:	mov    %rax,0x1f0(%rsp)
 2a07a70:	mov    %rcx,0x2b0(%rsp)
 2a07a78:	jmp    2a076de <wasm[0]::function[1015]::helper::object_read+0x957e>
 2a07a7d:	mov    %r12,%rsi
 2a07a80:	mov    %r12,0x1a0(%rsp)
 2a07a88:	xor    %esi,%r12d
 2a07a8b:	mov    %r12,0x1a0(%rsp)
 2a07a93:	xor    %r12,%r12
 2a07a96:	test   %eax,%eax
 2a07a98:	jne    2a07aab <wasm[0]::function[1015]::helper::object_read+0x994b>
 2a07a9e:	mov    %r12,0x1c8(%rsp)
 2a07aa6:	jmp    2a07ed0 <wasm[0]::function[1015]::helper::object_read+0x9d70>
 2a07aab:	test   %r13d,%r13d
 2a07aae:	je     2a19314 <wasm[0]::function[1015]::helper::object_read+0x1b1b4>
 2a07ab4:	xor    %eax,%eax
 2a07ab6:	test   $0x1,%r13d
 2a07abd:	jne    2a07aff <wasm[0]::function[1015]::helper::object_read+0x999f>
 2a07ac3:	mov    0x2e0(%rsp),%r14
 2a07acb:	mov    0x28(%r14),%rax
 2a07acf:	mov    0x20(%r14),%rsi
 2a07ad3:	mov    %r13d,%edi
 2a07ad6:	lea    0x4(%rsi,%rdi,1),%rsi
 2a07adb:	xor    %r12,%r12
 2a07ade:	cmp    %rax,%rdi
 2a07ae1:	cmova  %r12,%rsi
 2a07ae5:	mov    (%rsi),%eax
 2a07ae7:	mov    0x190(%rsp),%rsi
 2a07aef:	mov    0x28(%rsi),%rsi
 2a07af3:	cmp    0x160(%rsi),%eax
 2a07af9:	sete   %al
 2a07afc:	movzbl %al,%eax
 2a07aff:	test   %eax,%eax
 2a07b01:	jne    2a07d42 <wasm[0]::function[1015]::helper::object_read+0x9be2>
 2a07b07:	xor    %eax,%eax
 2a07b09:	test   $0x1,%r13d
 2a07b10:	jne    2a07b52 <wasm[0]::function[1015]::helper::object_read+0x99f2>
 2a07b16:	mov    0x2e0(%rsp),%r14
 2a07b1e:	mov    0x28(%r14),%rax
 2a07b22:	mov    0x20(%r14),%rsi
 2a07b26:	mov    %r13d,%edi
 2a07b29:	lea    0x4(%rsi,%rdi,1),%rsi
 2a07b2e:	xor    %r12,%r12
 2a07b31:	cmp    %rax,%rdi
 2a07b34:	cmova  %r12,%rsi
 2a07b38:	mov    (%rsi),%eax
 2a07b3a:	mov    0x190(%rsp),%rsi
 2a07b42:	mov    0x28(%rsi),%rsi
 2a07b46:	cmp    0x15c(%rsi),%eax
 2a07b4c:	sete   %al
 2a07b4f:	movzbl %al,%eax
 2a07b52:	test   %eax,%eax
 2a07b54:	je     2a19316 <wasm[0]::function[1015]::helper::object_read+0x1b1b6>
 2a07b5a:	test   %r13d,%r13d
 2a07b5d:	je     2a19318 <wasm[0]::function[1015]::helper::object_read+0x1b1b8>
 2a07b63:	mov    0x2e0(%rsp),%r14
 2a07b6b:	mov    0x28(%r14),%rsi
 2a07b6f:	mov    0x20(%r14),%r14
 2a07b73:	mov    %r13d,%eax
 2a07b76:	lea    (%r14,%rax,1),%rdi
 2a07b7a:	xor    %r12,%r12
 2a07b7d:	cmp    %rsi,%rax
 2a07b80:	cmova  %r12,%rdi
 2a07b84:	mov    0x14(%rdi),%r15d
 2a07b88:	mov    0x18(%rdi),%eax
 2a07b8b:	mov    0x1c(%rdi),%r13d
 2a07b8f:	test   %r15d,%r15d
 2a07b92:	je     2a1931a <wasm[0]::function[1015]::helper::object_read+0x1b1ba>
 2a07b98:	test   %r15d,%r15d
 2a07b9b:	je     2a1931c <wasm[0]::function[1015]::helper::object_read+0x1b1bc>
 2a07ba1:	mov    %r15d,%r11d
 2a07ba4:	lea    0x10(%r14,%r11,1),%rdi
 2a07ba9:	cmp    %rsi,%r11
 2a07bac:	cmova  %r12,%rdi
 2a07bb0:	mov    (%rdi),%edi
 2a07bb2:	cmp    %edi,%ecx
 2a07bb4:	jae    2a1931e <wasm[0]::function[1015]::helper::object_read+0x1b1be>
 2a07bba:	mov    %edi,%r11d
 2a07bbd:	shr    $0x20,%r11
 2a07bc1:	test   %r11,%r11
 2a07bc4:	jne    2a19320 <wasm[0]::function[1015]::helper::object_read+0x1b1c0>
 2a07bca:	add    $0x14,%edi
 2a07bcd:	jb     2a19322 <wasm[0]::function[1015]::helper::object_read+0x1b1c2>
 2a07bd3:	add    %edi,%r15d
 2a07bd6:	jb     2a19324 <wasm[0]::function[1015]::helper::object_read+0x1b1c4>
 2a07bdc:	mov    %r15d,%r11d
 2a07bdf:	add    %r11,%r14
 2a07be2:	cmp    %rsi,%r11
 2a07be5:	cmova  %r12,%r14
 2a07be9:	lea    0x14(%rcx),%esi
 2a07bec:	sub    %esi,%edi
 2a07bee:	sub    %rdi,%r14
 2a07bf1:	movzbq (%r14),%rsi
 2a07bf5:	mov    %rsi,%r11
 2a07bf8:	test   %eax,%eax
 2a07bfa:	je     2a07c8b <wasm[0]::function[1015]::helper::object_read+0x9b2b>
 2a07c00:	test   %eax,%eax
 2a07c02:	je     2a19326 <wasm[0]::function[1015]::helper::object_read+0x1b1c6>
 2a07c08:	test   %eax,%eax
 2a07c0a:	je     2a19328 <wasm[0]::function[1015]::helper::object_read+0x1b1c8>
 2a07c10:	mov    0x2e0(%rsp),%r14
 2a07c18:	mov    0x28(%r14),%rsi
 2a07c1c:	mov    0x20(%r14),%r12
 2a07c20:	mov    %eax,%r15d
 2a07c23:	lea    0x10(%r12,%r15,1),%rdi
 2a07c28:	xor    %r14,%r14
 2a07c2b:	cmp    %rsi,%r15
 2a07c2e:	cmova  %r14,%rdi
 2a07c32:	mov    (%rdi),%r15d
 2a07c35:	cmp    %r15d,%ecx
 2a07c38:	jae    2a1932a <wasm[0]::function[1015]::helper::object_read+0x1b1ca>
 2a07c3e:	mov    %r15d,%edi
 2a07c41:	shl    $0x3,%rdi
 2a07c45:	shr    $0x20,%rdi
 2a07c49:	test   %rdi,%rdi
 2a07c4c:	jne    2a1932c <wasm[0]::function[1015]::helper::object_read+0x1b1cc>
 2a07c52:	shl    $0x3,%r15d
 2a07c56:	add    $0x18,%r15d
 2a07c5a:	jb     2a1932e <wasm[0]::function[1015]::helper::object_read+0x1b1ce>
 2a07c60:	add    %r15d,%eax
 2a07c63:	jb     2a19330 <wasm[0]::function[1015]::helper::object_read+0x1b1d0>
 2a07c69:	mov    %eax,%edi
 2a07c6b:	lea    (%r12,%rdi,1),%rax
 2a07c6f:	cmp    %rsi,%rdi
 2a07c72:	cmova  %r14,%rax
 2a07c76:	mov    %rcx,%rsi
 2a07c79:	shl    $0x3,%esi
 2a07c7c:	add    $0x18,%esi
 2a07c82:	sub    %esi,%r15d
 2a07c85:	sub    %r15,%rax
 2a07c88:	mov    (%rax),%r12
 2a07c8b:	xor    %r15d,%r15d
 2a07c8e:	test   %r13d,%r13d
 2a07c91:	jne    2a07c9f <wasm[0]::function[1015]::helper::object_read+0x9b3f>
 2a07c97:	mov    %r11,%rax
 2a07c9a:	jmp    2a07d29 <wasm[0]::function[1015]::helper::object_read+0x9bc9>
 2a07c9f:	test   %r13d,%r13d
 2a07ca2:	je     2a19332 <wasm[0]::function[1015]::helper::object_read+0x1b1d2>
 2a07ca8:	test   %r13d,%r13d
 2a07cab:	je     2a19334 <wasm[0]::function[1015]::helper::object_read+0x1b1d4>
 2a07cb1:	mov    0x2e0(%rsp),%r14
 2a07cb9:	mov    0x28(%r14),%rax
 2a07cbd:	mov    0x20(%r14),%rsi
 2a07cc1:	mov    %r13d,%r15d
 2a07cc4:	lea    0x10(%rsi,%r15,1),%rdi
 2a07cc9:	xor    %r14,%r14
 2a07ccc:	cmp    %rax,%r15
 2a07ccf:	cmova  %r14,%rdi
 2a07cd3:	mov    (%rdi),%r15d
 2a07cd6:	cmp    %r15d,%ecx
 2a07cd9:	jae    2a19336 <wasm[0]::function[1015]::helper::object_read+0x1b1d6>
 2a07cdf:	mov    %r15d,%edi
 2a07ce2:	shl    $0x2,%rdi
 2a07ce6:	shr    $0x20,%rdi
 2a07cea:	test   %rdi,%rdi
 2a07ced:	jne    2a19338 <wasm[0]::function[1015]::helper::object_read+0x1b1d8>
 2a07cf3:	shl    $0x2,%r15d
 2a07cf7:	add    $0x14,%r15d
 2a07cfb:	jb     2a1933a <wasm[0]::function[1015]::helper::object_read+0x1b1da>
 2a07d01:	add    %r15d,%r13d
 2a07d04:	jb     2a1933c <wasm[0]::function[1015]::helper::object_read+0x1b1dc>
 2a07d0a:	mov    %r13d,%edi
 2a07d0d:	add    %rdi,%rsi
 2a07d10:	cmp    %rax,%rdi
 2a07d13:	cmova  %r14,%rsi
 2a07d17:	shl    $0x2,%ecx
 2a07d1a:	lea    0x14(%rcx),%eax
 2a07d1d:	sub    %eax,%r15d
 2a07d20:	sub    %r15,%rsi
 2a07d23:	mov    (%rsi),%r15d
 2a07d26:	mov    %r11,%rax
 2a07d29:	rex movzbl %al,%edi
 2a07d2d:	mov    %rdi,0x1a0(%rsp)
 2a07d35:	mov    %r12,0x1c8(%rsp)
 2a07d3d:	jmp    2a07ed0 <wasm[0]::function[1015]::helper::object_read+0x9d70>
 2a07d42:	xor    %esi,%esi
 2a07d44:	test   $0x1,%r13d
 2a07d4b:	jne    2a07d8e <wasm[0]::function[1015]::helper::object_read+0x9c2e>
 2a07d51:	mov    0x2e0(%rsp),%r14
 2a07d59:	mov    0x28(%r14),%rax
 2a07d5d:	mov    0x20(%r14),%rsi
 2a07d61:	mov    %r13d,%edi
 2a07d64:	lea    0x4(%rsi,%rdi,1),%rsi
 2a07d69:	xor    %r12,%r12
 2a07d6c:	cmp    %rax,%rdi
 2a07d6f:	cmova  %r12,%rsi
 2a07d73:	mov    (%rsi),%eax
 2a07d75:	mov    0x190(%rsp),%rsi
 2a07d7d:	mov    0x28(%rsi),%rsi
 2a07d81:	cmp    0x160(%rsi),%eax
 2a07d87:	sete   %al
 2a07d8a:	rex movzbl %al,%esi
 2a07d8e:	test   %esi,%esi
 2a07d90:	je     2a1933e <wasm[0]::function[1015]::helper::object_read+0x1b1de>
 2a07d96:	test   %r13d,%r13d
 2a07d99:	je     2a19340 <wasm[0]::function[1015]::helper::object_read+0x1b1e0>
 2a07d9f:	mov    0x2e0(%rsp),%r14
 2a07da7:	mov    0x28(%r14),%rsi
 2a07dab:	mov    0x20(%r14),%r12
 2a07daf:	mov    %r13d,%eax
 2a07db2:	lea    (%r12,%rax,1),%rdi
 2a07db6:	xor    %r13,%r13
 2a07db9:	cmp    %rsi,%rax
 2a07dbc:	cmova  %r13,%rdi
 2a07dc0:	mov    0x10(%rdi),%edi
 2a07dc3:	test   %edi,%edi
 2a07dc5:	je     2a19342 <wasm[0]::function[1015]::helper::object_read+0x1b1e2>
 2a07dcb:	test   %edi,%edi
 2a07dcd:	je     2a19344 <wasm[0]::function[1015]::helper::object_read+0x1b1e4>
 2a07dd3:	mov    %edi,%r11d
 2a07dd6:	lea    (%r12,%r11,1),%rdi
 2a07dda:	cmp    %rsi,%r11
 2a07ddd:	cmova  %r13,%rdi
 2a07de1:	mov    0x10(%rdi),%edi
 2a07de4:	test   %edi,%edi
 2a07de6:	je     2a19346 <wasm[0]::function[1015]::helper::object_read+0x1b1e6>
 2a07dec:	test   %edi,%edi
 2a07dee:	je     2a19348 <wasm[0]::function[1015]::helper::object_read+0x1b1e8>
 2a07df4:	mov    %edi,%r11d
 2a07df7:	lea    0x10(%r12,%r11,1),%rdi
 2a07dfc:	cmp    %rsi,%r11
 2a07dff:	cmova  %r13,%rdi
 2a07e03:	cmp    (%rdi),%ecx
 2a07e05:	setae  %sil
 2a07e09:	cmp    $0x2,%ecx
 2a07e0c:	setae  %dil
 2a07e10:	or     %edi,%esi
 2a07e12:	test   %sil,%sil
 2a07e15:	jne    2a1934a <wasm[0]::function[1015]::helper::object_read+0x1b1ea>
 2a07e1b:	mov    0x2e0(%rsp),%r14
 2a07e23:	mov    0x28(%r14),%rdi
 2a07e27:	mov    %rax,%rsi
 2a07e2a:	add    0x20(%r14),%rsi
 2a07e2e:	xor    %r12,%r12
 2a07e31:	cmp    %rdi,%rax
 2a07e34:	cmova  %r12,%rsi
 2a07e38:	mov    0x14(%rsi),%r12d
 2a07e3c:	mov    %r12,0x1a0(%rsp)
 2a07e44:	test   %ecx,%ecx
 2a07e46:	je     2a07e7e <wasm[0]::function[1015]::helper::object_read+0x9d1e>
 2a07e4c:	mov    0x2e0(%rsp),%r14
 2a07e54:	mov    0x28(%r14),%rdi
 2a07e58:	mov    0x20(%r14),%rsi
 2a07e5c:	add    %rax,%rsi
 2a07e5f:	xor    %r12,%r12
 2a07e62:	cmp    %rdi,%rax
 2a07e65:	cmova  %r12,%rsi
 2a07e69:	mov    0x20(%rsi),%r12
 2a07e6d:	mov    0x2c(%rsi),%r15d
 2a07e71:	mov    %r12,0x1c8(%rsp)
 2a07e79:	jmp    2a07eab <wasm[0]::function[1015]::helper::object_read+0x9d4b>
 2a07e7e:	mov    0x2e0(%rsp),%r14
 2a07e86:	mov    0x28(%r14),%rdi
 2a07e8a:	mov    0x20(%r14),%rsi
 2a07e8e:	add    %rax,%rsi
 2a07e91:	xor    %r12,%r12
 2a07e94:	cmp    %rdi,%rax
 2a07e97:	cmova  %r12,%rsi
 2a07e9b:	mov    0x18(%rsi),%r12
 2a07e9f:	mov    %r12,0x1c8(%rsp)
 2a07ea7:	mov    0x28(%rsi),%r15d
 2a07eab:	shl    $0x3,%ecx
 2a07eae:	mov    0x1a0(%rsp),%r12
 2a07eb6:	shr    %cl,%r12d
 2a07eb9:	mov    %r12,0x1a0(%rsp)
 2a07ec1:	and    $0xff,%r12d
 2a07ec8:	mov    %r12,0x1a0(%rsp)
 2a07ed0:	mov    0x1f8(%rsp),%rax
 2a07ed8:	mov    %eax,0xc8(%rsp)
 2a07edf:	mov    0x208(%rsp),%rsi
 2a07ee7:	mov    %esi,0x120(%rsp)
 2a07eee:	mov    %r15d,0x88(%rsp)
 2a07ef6:	mov    0x218(%rsp),%rdi
 2a07efe:	mov    %edi,0x138(%rsp)
 2a07f05:	mov    0x220(%rsp),%r11
 2a07f0d:	mov    %r11d,0x110(%rsp)
 2a07f15:	mov    0x198(%rsp),%rax
 2a07f1d:	mov    %eax,0xd8(%rsp)
 2a07f24:	mov    %r8d,0x130(%rsp)
 2a07f2c:	mov    %r9d,0xa0(%rsp)
 2a07f34:	mov    %edx,0x118(%rsp)
 2a07f3b:	mov    %r10d,0x108(%rsp)
 2a07f43:	mov    %ebx,0x100(%rsp)
 2a07f4a:	mov    $0x287,%edx
 2a07f4f:	mov    0x190(%rsp),%rsi
 2a07f57:	mov    0x190(%rsp),%rdi
 2a07f5f:	call   2f4f240 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 2a07f64:	mov    %eax,0x90(%rsp)
 2a07f6b:	xor    %edi,%edi
 2a07f6d:	test   %eax,%eax
 2a07f6f:	je     2a1934c <wasm[0]::function[1015]::helper::object_read+0x1b1ec>
 2a07f75:	movl   $0x0,0xf8(%rsp)
 2a07f80:	mov    0x120(%rsp),%r8d
 2a07f88:	mov    0x88(%rsp),%r9d
 2a07f90:	mov    0x138(%rsp),%r10d
 2a07f98:	mov    %r10,0x1d0(%rsp)
 2a07fa0:	mov    0x110(%rsp),%r11d
 2a07fa8:	mov    %r11,0x1d8(%rsp)
 2a07fb0:	mov    0xd8(%rsp),%r13d
 2a07fb8:	mov    %r13,0x1e0(%rsp)
 2a07fc0:	mov    0x130(%rsp),%r11d
 2a07fc8:	mov    %r11,0x1e8(%rsp)
 2a07fd0:	mov    0xa0(%rsp),%ebx
 2a07fd7:	mov    %rbx,0x1f0(%rsp)
 2a07fdf:	mov    0x118(%rsp),%ebx
 2a07fe6:	mov    0x108(%rsp),%r15d
 2a07fee:	mov    0x100(%rsp),%r12d
 2a07ff6:	xor    %rsi,%rsi
 2a07ff9:	mov    0x2a0(%rsp),%rcx
 2a08001:	mov    0x2a0(%rsp),%r10
 2a08009:	test   %r10b,%cl
 2a0800c:	jne    2a08022 <wasm[0]::function[1015]::helper::object_read+0x9ec2>
 2a08012:	mov    %rdi,%rdx
 2a08015:	mov    0x1d0(%rsp),%r10
 2a0801d:	jmp    2a08cf8 <wasm[0]::function[1015]::helper::object_read+0xab98>
 2a08022:	mov    0xc8(%rsp),%r8d
 2a0802a:	mov    0x2b8(%rsp),%rcx
 2a08032:	mov    0x2a8(%rsp),%rdx
 2a0803a:	mov    0x190(%rsp),%rsi
 2a08042:	mov    0x190(%rsp),%rdi
 2a0804a:	call   2a7c940 <wasm[0]::function[1039]::helper::object_header_projection>
 2a0804f:	mov    %eax,0xc8(%rsp)
 2a08056:	test   %eax,%eax
 2a08058:	je     2a1934e <wasm[0]::function[1015]::helper::object_read+0x1b1ee>
 2a0805e:	test   %eax,%eax
 2a08060:	je     2a19350 <wasm[0]::function[1015]::helper::object_read+0x1b1f0>
 2a08066:	mov    0x2e0(%rsp),%r14
 2a0806e:	mov    0x28(%r14),%rcx
 2a08072:	mov    0x20(%r14),%rsi
 2a08076:	mov    %eax,%edx
 2a08078:	lea    (%rsi,%rdx,1),%rax
 2a0807c:	xor    %rsi,%rsi
 2a0807f:	cmp    %rcx,%rdx
 2a08082:	cmova  %rsi,%rax
 2a08086:	mov    0x14(%rax),%eax
 2a08089:	mov    %eax,0x128(%rsp)
 2a08090:	test   %eax,%eax
 2a08092:	je     2a19352 <wasm[0]::function[1015]::helper::object_read+0x1b1f2>
 2a08098:	mov    0x128(%rsp),%ecx
 2a0809f:	xor    %eax,%eax
 2a080a1:	test   $0x1,%ecx
 2a080a7:	jne    2a080ff <wasm[0]::function[1015]::helper::object_read+0x9f9f>
 2a080ad:	mov    0x2e0(%rsp),%r14
 2a080b5:	mov    0x28(%r14),%rax
 2a080b9:	mov    0x20(%r14),%rsi
 2a080bd:	mov    %ecx,%edx
 2a080bf:	lea    0x4(%rsi,%rdx,1),%rcx
 2a080c4:	xor    %rsi,%rsi
 2a080c7:	cmp    %rax,%rdx
 2a080ca:	cmova  %rsi,%rcx
 2a080ce:	mov    (%rcx),%esi
 2a080d0:	mov    0x190(%rsp),%rcx
 2a080d8:	mov    0x28(%rcx),%rax
 2a080dc:	mov    0x158(%rax),%edx
 2a080e2:	cmp    %edx,%esi
 2a080e4:	sete   %al
 2a080e7:	movzbl %al,%eax
 2a080ea:	cmp    %edx,%esi
 2a080ec:	je     2a080ff <wasm[0]::function[1015]::helper::object_read+0x9f9f>
 2a080f2:	mov    0x190(%rsp),%rdi
 2a080fa:	call   3039cc5 <wasmtime_builtin_is_subtype>
 2a080ff:	test   %eax,%eax
 2a08101:	jne    2a0837b <wasm[0]::function[1015]::helper::object_read+0xa21b>
 2a08107:	mov    0xc8(%rsp),%edx
 2a0810e:	xor    %ebx,%ebx
 2a08110:	test   %edx,%edx
 2a08112:	je     2a19354 <wasm[0]::function[1015]::helper::object_read+0x1b1f4>
 2a08118:	mov    0x90(%rsp),%r9d
 2a08120:	mov    $0x4,%ecx
 2a08125:	xor    %r8,%r8
 2a08128:	mov    0x190(%rsp),%rsi
 2a08130:	mov    0x190(%rsp),%rdi
 2a08138:	call   2a76140 <wasm[0]::function[1032]::helper::ordinary_property_find>
 2a0813d:	test   %eax,%eax
 2a0813f:	je     2a08177 <wasm[0]::function[1015]::helper::object_read+0xa017>
 2a08145:	test   %eax,%eax
 2a08147:	je     2a19356 <wasm[0]::function[1015]::helper::object_read+0x1b1f6>
 2a0814d:	test   %eax,%eax
 2a0814f:	je     2a19358 <wasm[0]::function[1015]::helper::object_read+0x1b1f8>
 2a08155:	mov    0x2e0(%rsp),%r14
 2a0815d:	mov    0x28(%r14),%rcx
 2a08161:	mov    %eax,%edx
 2a08163:	mov    %rdx,%rax
 2a08166:	add    0x20(%r14),%rax
 2a0816a:	xor    %rsi,%rsi
 2a0816d:	cmp    %rcx,%rdx
 2a08170:	cmova  %rsi,%rax
 2a08174:	mov    0x14(%rax),%ebx
 2a08177:	mov    0xf8(%rsp),%edx
 2a0817e:	xor    %edi,%edi
 2a08180:	xor    %rsi,%rsi
 2a08183:	test   %ebx,%ebx
 2a08185:	je     2a08300 <wasm[0]::function[1015]::helper::object_read+0xa1a0>
 2a0818b:	test   %ebx,%ebx
 2a0818d:	je     2a1935a <wasm[0]::function[1015]::helper::object_read+0x1b1fa>
 2a08193:	mov    0x2e0(%rsp),%r14
 2a0819b:	mov    0x28(%r14),%rcx
 2a0819f:	mov    0x20(%r14),%rax
 2a081a3:	mov    %ebx,%edx
 2a081a5:	add    %rdx,%rax
 2a081a8:	xor    %rsi,%rsi
 2a081ab:	cmp    %rcx,%rdx
 2a081ae:	cmova  %rsi,%rax
 2a081b2:	mov    0x10(%rax),%ecx
 2a081b5:	mov    0xf8(%rsp),%edx
 2a081bc:	xor    %edi,%edi
 2a081be:	test   $0x1,%ecx
 2a081c4:	jne    2a08300 <wasm[0]::function[1015]::helper::object_read+0xa1a0>
 2a081ca:	mov    0x14(%rax),%edx
 2a081cd:	test   %edx,%edx
 2a081cf:	je     2a1935c <wasm[0]::function[1015]::helper::object_read+0x1b1fc>
 2a081d5:	xor    %eax,%eax
 2a081d7:	test   $0x1,%edx
 2a081dd:	jne    2a08220 <wasm[0]::function[1015]::helper::object_read+0xa0c0>
 2a081e3:	mov    0x2e0(%rsp),%r14
 2a081eb:	mov    0x28(%r14),%rsi
 2a081ef:	mov    0x20(%r14),%r8
 2a081f3:	mov    %edx,%edi
 2a081f5:	lea    0x4(%r8,%rdi,1),%rax
 2a081fa:	xor    %r8,%r8
 2a081fd:	cmp    %rsi,%rdi
 2a08200:	cmova  %r8,%rax
 2a08204:	mov    (%rax),%esi
 2a08206:	mov    0x190(%rsp),%rcx
 2a0820e:	mov    0x28(%rcx),%rdi
 2a08212:	cmp    0x120(%rdi),%esi
 2a08218:	sete   %sil
 2a0821c:	movzbl %sil,%eax
 2a08220:	test   %eax,%eax
 2a08222:	jne    2a0827e <wasm[0]::function[1015]::helper::object_read+0xa11e>
 2a08228:	mov    0x190(%rsp),%rsi
 2a08230:	mov    0x190(%rsp),%rdi
 2a08238:	call   2a1eec0 <wasm[0]::function[1024]::helper::property_value_resolve>
 2a0823d:	test   %eax,%eax
 2a0823f:	je     2a1935e <wasm[0]::function[1015]::helper::object_read+0x1b1fe>
 2a08245:	test   %eax,%eax
 2a08247:	je     2a19360 <wasm[0]::function[1015]::helper::object_read+0x1b200>
 2a0824d:	mov    0x2e0(%rsp),%r14
 2a08255:	mov    0x28(%r14),%r11
 2a08259:	mov    0x20(%r14),%rcx
 2a0825d:	mov    %eax,%eax
 2a0825f:	lea    (%rcx,%rax,1),%r8
 2a08263:	xor    %rcx,%rcx
 2a08266:	cmp    %r11,%rax
 2a08269:	cmova  %rcx,%r8
 2a0826d:	mov    0x18(%r8),%edi
 2a08271:	mov    0x10(%r8),%rsi
 2a08275:	mov    0x1c(%r8),%edx
 2a08279:	jmp    2a08300 <wasm[0]::function[1015]::helper::object_read+0xa1a0>
 2a0827e:	xor    %eax,%eax
 2a08280:	test   $0x1,%edx
 2a08286:	jne    2a082c7 <wasm[0]::function[1015]::helper::object_read+0xa167>
 2a0828c:	mov    0x2e0(%rsp),%r14
 2a08294:	mov    0x28(%r14),%rax
 2a08298:	mov    0x20(%r14),%rcx
 2a0829c:	mov    %edx,%esi
 2a0829e:	lea    0x4(%rcx,%rsi,1),%rcx
 2a082a3:	xor    %rdi,%rdi
 2a082a6:	cmp    %rax,%rsi
 2a082a9:	cmova  %rdi,%rcx
 2a082ad:	mov    (%rcx),%eax
 2a082af:	mov    0x190(%rsp),%rcx
 2a082b7:	mov    0x28(%rcx),%rcx
 2a082bb:	cmp    0x120(%rcx),%eax
 2a082c1:	sete   %al
 2a082c4:	movzbl %al,%eax
 2a082c7:	test   %eax,%eax
 2a082c9:	je     2a19362 <wasm[0]::function[1015]::helper::object_read+0x1b202>
 2a082cf:	test   %edx,%edx
 2a082d1:	je     2a19364 <wasm[0]::function[1015]::helper::object_read+0x1b204>
 2a082d7:	mov    0x2e0(%rsp),%r14
 2a082df:	mov    0x28(%r14),%rcx
 2a082e3:	mov    0x20(%r14),%rax
 2a082e7:	mov    %edx,%edx
 2a082e9:	add    %rdx,%rax
 2a082ec:	xor    %rsi,%rsi
 2a082ef:	cmp    %rcx,%rdx
 2a082f2:	cmova  %rsi,%rax
 2a082f6:	mov    0x18(%rax),%edi
 2a082f9:	mov    0x10(%rax),%rsi
 2a082fd:	mov    0x1c(%rax),%edx
 2a08300:	mov    0x120(%rsp),%r8d
 2a08308:	mov    0x88(%rsp),%r9d
 2a08310:	mov    0x138(%rsp),%r10d
 2a08318:	mov    %r10,0x1d0(%rsp)
 2a08320:	mov    0x110(%rsp),%r11d
 2a08328:	mov    %r11,0x1d8(%rsp)
 2a08330:	mov    0xd8(%rsp),%r13d
 2a08338:	mov    %r13,0x1e0(%rsp)
 2a08340:	mov    0x130(%rsp),%r11d
 2a08348:	mov    %r11,0x1e8(%rsp)
 2a08350:	mov    0xa0(%rsp),%ebx
 2a08357:	mov    %rbx,0x1f0(%rsp)
 2a0835f:	mov    0x118(%rsp),%ebx
 2a08366:	mov    0x108(%rsp),%r15d
 2a0836e:	mov    0x100(%rsp),%r12d
 2a08376:	jmp    2a08cf0 <wasm[0]::function[1015]::helper::object_read+0xab90>
 2a0837b:	mov    0x128(%rsp),%eax
 2a08382:	test   %eax,%eax
 2a08384:	je     2a19366 <wasm[0]::function[1015]::helper::object_read+0x1b206>
 2a0838a:	mov    0x128(%rsp),%ecx
 2a08391:	xor    %eax,%eax
 2a08393:	test   $0x1,%ecx
 2a08399:	jne    2a083f1 <wasm[0]::function[1015]::helper::object_read+0xa291>
 2a0839f:	mov    0x2e0(%rsp),%r14
 2a083a7:	mov    0x28(%r14),%rax
 2a083ab:	mov    0x20(%r14),%rsi
 2a083af:	mov    %ecx,%edx
 2a083b1:	lea    0x4(%rsi,%rdx,1),%rcx
 2a083b6:	xor    %rsi,%rsi
 2a083b9:	cmp    %rax,%rdx
 2a083bc:	cmova  %rsi,%rcx
 2a083c0:	mov    (%rcx),%esi
 2a083c2:	mov    0x190(%rsp),%rcx
 2a083ca:	mov    0x28(%rcx),%rax
 2a083ce:	mov    0x158(%rax),%edx
 2a083d4:	cmp    %edx,%esi
 2a083d6:	sete   %al
 2a083d9:	movzbl %al,%eax
 2a083dc:	cmp    %edx,%esi
 2a083de:	je     2a083f1 <wasm[0]::function[1015]::helper::object_read+0xa291>
 2a083e4:	mov    0x190(%rsp),%rdi
 2a083ec:	call   3039cc5 <wasmtime_builtin_is_subtype>
 2a083f1:	test   %eax,%eax
 2a083f3:	je     2a19368 <wasm[0]::function[1015]::helper::object_read+0x1b208>
 2a083f9:	mov    0x128(%rsp),%r10d
 2a08401:	mov    0x120(%rsp),%r8d
 2a08409:	mov    0x88(%rsp),%r9d
 2a08411:	mov    0xf8(%rsp),%edx
 2a08418:	mov    0x138(%rsp),%esi
 2a0841f:	mov    %rsi,0x1d0(%rsp)
 2a08427:	mov    0x110(%rsp),%r11d
 2a0842f:	mov    %r11,0x1d8(%rsp)
 2a08437:	mov    0xd8(%rsp),%r13d
 2a0843f:	mov    %r13,0x1e0(%rsp)
 2a08447:	mov    0x130(%rsp),%r11d
 2a0844f:	mov    %r11,0x1e8(%rsp)
 2a08457:	mov    0xa0(%rsp),%ebx
 2a0845e:	mov    %rbx,0x1f0(%rsp)
 2a08466:	mov    0x118(%rsp),%ebx
 2a0846d:	mov    0x108(%rsp),%r15d
 2a08475:	mov    0x100(%rsp),%r12d
 2a0847d:	xor    %ecx,%ecx
 2a0847f:	mov    %rcx,0x208(%rsp)
 2a08487:	test   %r10d,%r10d
 2a0848a:	je     2a1936a <wasm[0]::function[1015]::helper::object_read+0x1b20a>
 2a08490:	test   %r10d,%r10d
 2a08493:	je     2a1936c <wasm[0]::function[1015]::helper::object_read+0x1b20c>
 2a08499:	mov    0x2e0(%rsp),%r14
 2a084a1:	mov    0x28(%r14),%rax
 2a084a5:	mov    0x20(%r14),%rcx
 2a084a9:	mov    %r10d,%r13d
 2a084ac:	lea    (%rcx,%r13,1),%rsi
 2a084b0:	xor    %rdi,%rdi
 2a084b3:	cmp    %rax,%r13
 2a084b6:	cmova  %rdi,%rsi
 2a084ba:	mov    0x10(%rsi),%esi
 2a084bd:	test   %esi,%esi
 2a084bf:	je     2a1936e <wasm[0]::function[1015]::helper::object_read+0x1b20e>
 2a084c5:	test   %esi,%esi
 2a084c7:	je     2a19370 <wasm[0]::function[1015]::helper::object_read+0x1b210>
 2a084cd:	mov    %esi,%r13d
 2a084d0:	lea    (%rcx,%r13,1),%rsi
 2a084d4:	cmp    %rax,%r13
 2a084d7:	cmova  %rdi,%rsi
 2a084db:	mov    0x10(%rsi),%esi
 2a084de:	test   %esi,%esi
 2a084e0:	je     2a19372 <wasm[0]::function[1015]::helper::object_read+0x1b212>
 2a084e6:	test   %esi,%esi
 2a084e8:	je     2a19374 <wasm[0]::function[1015]::helper::object_read+0x1b214>
 2a084ee:	mov    %esi,%r13d
 2a084f1:	lea    0x10(%rcx,%r13,1),%rcx
 2a084f6:	cmp    %rax,%r13
 2a084f9:	cmova  %rdi,%rcx
 2a084fd:	mov    (%rcx),%r13d
 2a08500:	mov    %r13,0x220(%rsp)
 2a08508:	mov    0x90(%rsp),%edi
 2a0850f:	mov    0x190(%rsp),%rcx
 2a08517:	mov    0x28(%rcx),%rax
 2a0851b:	mov    0x234(%rax),%r13d
 2a08522:	mov    %r13,0x218(%rsp)
 2a0852a:	mov    0x208(%rsp),%rax
 2a08532:	mov    %rax,0x198(%rsp)
 2a0853a:	mov    %esi,0xc8(%rsp)
 2a08541:	mov    %edi,0x100(%rsp)
 2a08548:	mov    %r10d,0x108(%rsp)
 2a08550:	mov    %r8d,0x118(%rsp)
 2a08558:	mov    %r9d,0xa0(%rsp)
 2a08560:	mov    %edx,0x130(%rsp)
 2a08567:	mov    0x1d0(%rsp),%r10
 2a0856f:	mov    %r10d,0xd8(%rsp)
 2a08577:	mov    0x1d8(%rsp),%r11
 2a0857f:	mov    %r11d,0x110(%rsp)
 2a08587:	mov    0x1e0(%rsp),%r13
 2a0858f:	mov    %r13d,0x138(%rsp)
 2a08597:	mov    0x1e8(%rsp),%r11
 2a0859f:	mov    %r11d,0xf8(%rsp)
 2a085a7:	mov    0x1f0(%rsp),%rax
 2a085af:	mov    %eax,0x88(%rsp)
 2a085b6:	mov    %ebx,0x120(%rsp)
 2a085bd:	mov    %r15d,0x128(%rsp)
 2a085c5:	mov    %r12d,0x90(%rsp)
 2a085cd:	mov    0x2e8(%rsp),%r15
 2a085d5:	mov    (%r15),%rcx
 2a085d8:	mov    0x228(%rsp),%rax
 2a085e0:	cmp    %rax,%rcx
 2a085e3:	jae    2a17df4 <wasm[0]::function[1015]::helper::object_read+0x19c94>
 2a085e9:	mov    0x108(%rsp),%r10d
 2a085f1:	mov    0x118(%rsp),%r8d
 2a085f9:	mov    0xa0(%rsp),%r9d
 2a08601:	mov    0x130(%rsp),%edx
 2a08608:	mov    0xd8(%rsp),%ecx
 2a0860f:	mov    %rcx,0x1d0(%rsp)
 2a08617:	mov    0x110(%rsp),%r11d
 2a0861f:	mov    %r11,0x1d8(%rsp)
 2a08627:	mov    0x138(%rsp),%r13d
 2a0862f:	mov    %r13,0x1e0(%rsp)
 2a08637:	mov    0xf8(%rsp),%r11d
 2a0863f:	mov    %r11,0x1e8(%rsp)
 2a08647:	mov    0x88(%rsp),%ebx
 2a0864e:	mov    %rbx,0x1f0(%rsp)
 2a08656:	mov    0x120(%rsp),%ebx
 2a0865d:	mov    0x128(%rsp),%r15d
 2a08665:	mov    0x90(%rsp),%r12d
 2a0866d:	mov    0x208(%rsp),%rcx
 2a08675:	mov    0x220(%rsp),%rsi
 2a0867d:	cmp    %esi,%ecx
 2a0867f:	jb     2a08692 <wasm[0]::function[1015]::helper::object_read+0xa532>
 2a08685:	mov    0x198(%rsp),%rax
 2a0868d:	jmp    2a0890d <wasm[0]::function[1015]::helper::object_read+0xa7ad>
 2a08692:	mov    0xc8(%rsp),%r8d
 2a0869a:	test   %r8d,%r8d
 2a0869d:	je     2a19376 <wasm[0]::function[1015]::helper::object_read+0x1b216>
 2a086a3:	test   %r8d,%r8d
 2a086a6:	je     2a19378 <wasm[0]::function[1015]::helper::object_read+0x1b218>
 2a086ac:	mov    0x2e0(%rsp),%r14
 2a086b4:	mov    0x28(%r14),%rax
 2a086b8:	mov    0x20(%r14),%rdx
 2a086bc:	mov    %r8d,%r9d
 2a086bf:	lea    0x10(%rdx,%r9,1),%rdi
 2a086c4:	xor    %rsi,%rsi
 2a086c7:	cmp    %rax,%r9
 2a086ca:	cmova  %rsi,%rdi
 2a086ce:	mov    (%rdi),%edi
 2a086d0:	cmp    %edi,%ecx
 2a086d2:	jae    2a1937a <wasm[0]::function[1015]::helper::object_read+0x1b21a>
 2a086d8:	mov    %edi,%r9d
 2a086db:	shl    $0x2,%r9
 2a086df:	shr    $0x20,%r9
 2a086e3:	test   %r9,%r9
 2a086e6:	jne    2a1937c <wasm[0]::function[1015]::helper::object_read+0x1b21c>
 2a086ec:	shl    $0x2,%edi
 2a086ef:	add    $0x14,%edi
 2a086f2:	jb     2a1937e <wasm[0]::function[1015]::helper::object_read+0x1b21e>
 2a086f8:	add    %edi,%r8d
 2a086fb:	jb     2a19380 <wasm[0]::function[1015]::helper::object_read+0x1b220>
 2a08701:	mov    %r8d,%r8d
 2a08704:	add    %r8,%rdx
 2a08707:	cmp    %rax,%r8
 2a0870a:	cmova  %rsi,%rdx
 2a0870e:	mov    %rcx,%rax
 2a08711:	shl    $0x2,%eax
 2a08714:	mov    %rcx,0x208(%rsp)
 2a0871c:	add    $0x14,%eax
 2a08722:	sub    %eax,%edi
 2a08724:	sub    %rdi,%rdx
 2a08727:	mov    (%rdx),%edx
 2a08729:	test   %edx,%edx
 2a0872b:	je     2a19382 <wasm[0]::function[1015]::helper::object_read+0x1b222>
 2a08731:	mov    0x100(%rsp),%eax
 2a08738:	cmp    %eax,%edx
 2a0873a:	je     2a0882c <wasm[0]::function[1015]::helper::object_read+0xa6cc>
 2a08740:	xor    %ecx,%ecx
 2a08742:	test   %edx,%edx
 2a08744:	jne    2a08757 <wasm[0]::function[1015]::helper::object_read+0xa5f7>
 2a0874a:	mov    0x218(%rsp),%r13
 2a08752:	jmp    2a087a6 <wasm[0]::function[1015]::helper::object_read+0xa646>
 2a08757:	xor    %ecx,%ecx
 2a08759:	test   $0x1,%edx
 2a0875f:	je     2a08772 <wasm[0]::function[1015]::helper::object_read+0xa612>
 2a08765:	mov    0x218(%rsp),%r13
 2a0876d:	jmp    2a087a6 <wasm[0]::function[1015]::helper::object_read+0xa646>
 2a08772:	mov    0x2e0(%rsp),%r14
 2a0877a:	mov    0x28(%r14),%rcx
 2a0877e:	mov    0x20(%r14),%rsi
 2a08782:	mov    %edx,%edi
 2a08784:	lea    0x4(%rsi,%rdi,1),%rsi
 2a08789:	xor    %r8,%r8
 2a0878c:	cmp    %rcx,%rdi
 2a0878f:	cmova  %r8,%rsi
 2a08793:	mov    (%rsi),%ecx
 2a08795:	mov    0x218(%rsp),%r13
 2a0879d:	cmp    %r13d,%ecx
 2a087a0:	sete   %cl
 2a087a3:	movzbl %cl,%ecx
 2a087a6:	test   %ecx,%ecx
 2a087a8:	je     2a19384 <wasm[0]::function[1015]::helper::object_read+0x1b224>
 2a087ae:	xor    %ecx,%ecx
 2a087b0:	test   %eax,%eax
 2a087b2:	je     2a087f8 <wasm[0]::function[1015]::helper::object_read+0xa698>
 2a087b8:	mov    0x100(%rsp),%eax
 2a087bf:	xor    %ecx,%ecx
 2a087c1:	test   $0x1,%eax
 2a087c6:	jne    2a087f8 <wasm[0]::function[1015]::helper::object_read+0xa698>
 2a087cc:	mov    0x2e0(%rsp),%r14
 2a087d4:	mov    0x28(%r14),%rcx
 2a087d8:	mov    0x20(%r14),%rdi
 2a087dc:	mov    %eax,%esi
 2a087de:	lea    0x4(%rdi,%rsi,1),%rax
 2a087e3:	xor    %rdi,%rdi
 2a087e6:	cmp    %rcx,%rsi
 2a087e9:	cmova  %rdi,%rax
 2a087ed:	mov    (%rax),%eax
 2a087ef:	cmp    %r13d,%eax
 2a087f2:	sete   %al
 2a087f5:	movzbl %al,%ecx
 2a087f8:	test   %ecx,%ecx
 2a087fa:	je     2a19386 <wasm[0]::function[1015]::helper::object_read+0x1b226>
 2a08800:	mov    0x100(%rsp),%ecx
 2a08807:	xor    %r8d,%r8d
 2a0880a:	test   %ecx,%ecx
 2a0880c:	je     2a19388 <wasm[0]::function[1015]::helper::object_read+0x1b228>
 2a08812:	mov    0x190(%rsp),%rsi
 2a0881a:	mov    0x190(%rsp),%rdi
 2a08822:	call   2b02800 <wasm[0]::function[1057]::helper::string_equality>
 2a08827:	jmp    2a0883c <wasm[0]::function[1015]::helper::object_read+0xa6dc>
 2a0882c:	mov    0x218(%rsp),%r13
 2a08834:	mov    0x278(%rsp),%rax
 2a0883c:	mov    0xc8(%rsp),%esi
 2a08843:	mov    0x100(%rsp),%edi
 2a0884a:	mov    0x108(%rsp),%r10d
 2a08852:	mov    0x118(%rsp),%r8d
 2a0885a:	mov    0xa0(%rsp),%r9d
 2a08862:	mov    0x130(%rsp),%edx
 2a08869:	mov    0xd8(%rsp),%ecx
 2a08870:	mov    %rcx,0x1d0(%rsp)
 2a08878:	mov    0x110(%rsp),%r11d
 2a08880:	mov    %r11,0x1d8(%rsp)
 2a08888:	mov    0x138(%rsp),%ecx
 2a0888f:	mov    %rcx,0x1e0(%rsp)
 2a08897:	mov    0xf8(%rsp),%r11d
 2a0889f:	mov    %r11,0x1e8(%rsp)
 2a088a7:	mov    0x88(%rsp),%ebx
 2a088ae:	mov    %rbx,0x1f0(%rsp)
 2a088b6:	mov    0x120(%rsp),%ebx
 2a088bd:	mov    0x128(%rsp),%r15d
 2a088c5:	mov    0x90(%rsp),%r12d
 2a088cd:	test   %eax,%eax
 2a088cf:	je     2a088e2 <wasm[0]::function[1015]::helper::object_read+0xa782>
 2a088d5:	mov    0x208(%rsp),%rcx
 2a088dd:	jmp    2a0890d <wasm[0]::function[1015]::helper::object_read+0xa7ad>
 2a088e2:	mov    0x208(%rsp),%rcx
 2a088ea:	add    $0x1,%ecx
 2a088f0:	mov    %rax,0x198(%rsp)
 2a088f8:	mov    %rcx,0x208(%rsp)
 2a08900:	mov    %r13,0x218(%rsp)
 2a08908:	jmp    2a0853a <wasm[0]::function[1015]::helper::object_read+0xa3da>
 2a0890d:	xor    %edi,%edi
 2a0890f:	xor    %rsi,%rsi
 2a08912:	test   %eax,%eax
 2a08914:	je     2a08cf0 <wasm[0]::function[1015]::helper::object_read+0xab90>
 2a0891a:	test   %r10d,%r10d
 2a0891d:	je     2a1938a <wasm[0]::function[1015]::helper::object_read+0x1b22a>
 2a08923:	xor    %eax,%eax
 2a08925:	test   $0x1,%r10d
 2a0892c:	jne    2a0896e <wasm[0]::function[1015]::helper::object_read+0xa80e>
 2a08932:	mov    0x2e0(%rsp),%r14
 2a0893a:	mov    0x28(%r14),%rax
 2a0893e:	mov    0x20(%r14),%rdx
 2a08942:	mov    %r10d,%esi
 2a08945:	lea    0x4(%rdx,%rsi,1),%rdx
 2a0894a:	xor    %rdi,%rdi
 2a0894d:	cmp    %rax,%rsi
 2a08950:	cmova  %rdi,%rdx
 2a08954:	mov    (%rdx),%eax
 2a08956:	mov    0x190(%rsp),%r11
 2a0895e:	mov    0x28(%r11),%rdx
 2a08962:	cmp    0x160(%rdx),%eax
 2a08968:	sete   %al
 2a0896b:	movzbl %al,%eax
 2a0896e:	test   %eax,%eax
 2a08970:	jne    2a08b94 <wasm[0]::function[1015]::helper::object_read+0xaa34>
 2a08976:	xor    %eax,%eax
 2a08978:	test   $0x1,%r10d
 2a0897f:	jne    2a089c1 <wasm[0]::function[1015]::helper::object_read+0xa861>
 2a08985:	mov    0x2e0(%rsp),%r14
 2a0898d:	mov    0x28(%r14),%rax
 2a08991:	mov    0x20(%r14),%rdx
 2a08995:	mov    %r10d,%esi
 2a08998:	lea    0x4(%rdx,%rsi,1),%rdx
 2a0899d:	xor    %rdi,%rdi
 2a089a0:	cmp    %rax,%rsi
 2a089a3:	cmova  %rdi,%rdx
 2a089a7:	mov    (%rdx),%eax
 2a089a9:	mov    0x190(%rsp),%rdx
 2a089b1:	mov    0x28(%rdx),%rdx
 2a089b5:	cmp    0x15c(%rdx),%eax
 2a089bb:	sete   %al
 2a089be:	movzbl %al,%eax
 2a089c1:	test   %eax,%eax
 2a089c3:	je     2a1938c <wasm[0]::function[1015]::helper::object_read+0x1b22c>
 2a089c9:	test   %r10d,%r10d
 2a089cc:	je     2a1938e <wasm[0]::function[1015]::helper::object_read+0x1b22e>
 2a089d2:	mov    0x2e0(%rsp),%r14
 2a089da:	mov    0x28(%r14),%rdx
 2a089de:	mov    0x20(%r14),%r13
 2a089e2:	mov    %r10d,%eax
 2a089e5:	lea    0x0(%r13,%rax,1),%rdi
 2a089ea:	xor    %rsi,%rsi
 2a089ed:	cmp    %rdx,%rax
 2a089f0:	cmova  %rsi,%rdi
 2a089f4:	mov    0x14(%rdi),%r10d
 2a089f8:	mov    0x18(%rdi),%eax
 2a089fb:	mov    0x1c(%rdi),%edi
 2a089fe:	test   %r10d,%r10d
 2a08a01:	je     2a19390 <wasm[0]::function[1015]::helper::object_read+0x1b230>
 2a08a07:	test   %r10d,%r10d
 2a08a0a:	je     2a19392 <wasm[0]::function[1015]::helper::object_read+0x1b232>
 2a08a10:	mov    %r10d,%r11d
 2a08a13:	lea    0x10(%r13,%r11,1),%r14
 2a08a18:	cmp    %rdx,%r11
 2a08a1b:	cmova  %rsi,%r14
 2a08a1f:	mov    (%r14),%r14d
 2a08a22:	cmp    %r14d,%ecx
 2a08a25:	jae    2a19394 <wasm[0]::function[1015]::helper::object_read+0x1b234>
 2a08a2b:	mov    %r14d,%r11d
 2a08a2e:	shr    $0x20,%r11
 2a08a32:	test   %r11,%r11
 2a08a35:	jne    2a19396 <wasm[0]::function[1015]::helper::object_read+0x1b236>
 2a08a3b:	add    $0x14,%r14d
 2a08a3f:	jb     2a19398 <wasm[0]::function[1015]::helper::object_read+0x1b238>
 2a08a45:	add    %r14d,%r10d
 2a08a48:	jb     2a1939a <wasm[0]::function[1015]::helper::object_read+0x1b23a>
 2a08a4e:	mov    %r10d,%r11d
 2a08a51:	lea    0x0(%r13,%r11,1),%r10
 2a08a56:	cmp    %rdx,%r11
 2a08a59:	cmova  %rsi,%r10
 2a08a5d:	lea    0x14(%rcx),%edx
 2a08a60:	sub    %edx,%r14d
 2a08a63:	sub    %r14,%r10
 2a08a66:	movzbq (%r10),%r11
 2a08a6a:	test   %eax,%eax
 2a08a6c:	je     2a08afe <wasm[0]::function[1015]::helper::object_read+0xa99e>
 2a08a72:	test   %eax,%eax
 2a08a74:	je     2a1939c <wasm[0]::function[1015]::helper::object_read+0x1b23c>
 2a08a7a:	test   %eax,%eax
 2a08a7c:	je     2a1939e <wasm[0]::function[1015]::helper::object_read+0x1b23e>
 2a08a82:	mov    0x2e0(%rsp),%r14
 2a08a8a:	mov    0x28(%r14),%rdx
 2a08a8e:	mov    0x20(%r14),%rsi
 2a08a92:	mov    %eax,%r10d
 2a08a95:	lea    0x10(%rsi,%r10,1),%r14
 2a08a9a:	xor    %r13,%r13
 2a08a9d:	cmp    %rdx,%r10
 2a08aa0:	cmova  %r13,%r14
 2a08aa4:	mov    (%r14),%r14d
 2a08aa7:	cmp    %r14d,%ecx
 2a08aaa:	jae    2a193a0 <wasm[0]::function[1015]::helper::object_read+0x1b240>
 2a08ab0:	mov    %r14d,%r10d
 2a08ab3:	shl    $0x3,%r10
 2a08ab7:	shr    $0x20,%r10
 2a08abb:	test   %r10,%r10
 2a08abe:	jne    2a193a2 <wasm[0]::function[1015]::helper::object_read+0x1b242>
 2a08ac4:	shl    $0x3,%r14d
 2a08ac8:	add    $0x18,%r14d
 2a08acc:	jb     2a193a4 <wasm[0]::function[1015]::helper::object_read+0x1b244>
 2a08ad2:	add    %r14d,%eax
 2a08ad5:	jb     2a193a6 <wasm[0]::function[1015]::helper::object_read+0x1b246>
 2a08adb:	mov    %eax,%r10d
 2a08ade:	lea    (%rsi,%r10,1),%rax
 2a08ae2:	cmp    %rdx,%r10
 2a08ae5:	cmova  %r13,%rax
 2a08ae9:	mov    %rcx,%rdx
 2a08aec:	shl    $0x3,%edx
 2a08aef:	add    $0x18,%edx
 2a08af5:	sub    %edx,%r14d
 2a08af8:	sub    %r14,%rax
 2a08afb:	mov    (%rax),%rsi
 2a08afe:	xor    %edx,%edx
 2a08b00:	test   %edi,%edi
 2a08b02:	je     2a08b8b <wasm[0]::function[1015]::helper::object_read+0xaa2b>
 2a08b08:	test   %edi,%edi
 2a08b0a:	je     2a193a8 <wasm[0]::function[1015]::helper::object_read+0x1b248>
 2a08b10:	test   %edi,%edi
 2a08b12:	je     2a193aa <wasm[0]::function[1015]::helper::object_read+0x1b24a>
 2a08b18:	mov    0x2e0(%rsp),%r14
 2a08b20:	mov    0x28(%r14),%rax
 2a08b24:	mov    0x20(%r14),%rdx
 2a08b28:	mov    %edi,%r10d
 2a08b2b:	lea    0x10(%rdx,%r10,1),%r14
 2a08b30:	xor    %r13,%r13
 2a08b33:	cmp    %rax,%r10
 2a08b36:	cmova  %r13,%r14
 2a08b3a:	mov    (%r14),%r14d
 2a08b3d:	cmp    %r14d,%ecx
 2a08b40:	jae    2a193ac <wasm[0]::function[1015]::helper::object_read+0x1b24c>
 2a08b46:	mov    %r14d,%r10d
 2a08b49:	shl    $0x2,%r10
 2a08b4d:	shr    $0x20,%r10
 2a08b51:	test   %r10,%r10
 2a08b54:	jne    2a193ae <wasm[0]::function[1015]::helper::object_read+0x1b24e>
 2a08b5a:	shl    $0x2,%r14d
 2a08b5e:	add    $0x14,%r14d
 2a08b62:	jb     2a193b0 <wasm[0]::function[1015]::helper::object_read+0x1b250>
 2a08b68:	add    %r14d,%edi
 2a08b6b:	jb     2a193b2 <wasm[0]::function[1015]::helper::object_read+0x1b252>
 2a08b71:	mov    %edi,%edi
 2a08b73:	add    %rdi,%rdx
 2a08b76:	cmp    %rax,%rdi
 2a08b79:	cmova  %r13,%rdx
 2a08b7d:	shl    $0x2,%ecx
 2a08b80:	lea    0x14(%rcx),%eax
 2a08b83:	sub    %eax,%r14d
 2a08b86:	sub    %r14,%rdx
 2a08b89:	mov    (%rdx),%edx
 2a08b8b:	movzbl %r11b,%edi
 2a08b8f:	jmp    2a08cf0 <wasm[0]::function[1015]::helper::object_read+0xab90>
 2a08b94:	xor    %eax,%eax
 2a08b96:	test   $0x1,%r10d
 2a08b9d:	jne    2a08bdf <wasm[0]::function[1015]::helper::object_read+0xaa7f>
 2a08ba3:	mov    0x2e0(%rsp),%r14
 2a08bab:	mov    0x28(%r14),%rax
 2a08baf:	mov    0x20(%r14),%rdx
 2a08bb3:	mov    %r10d,%esi
 2a08bb6:	lea    0x4(%rdx,%rsi,1),%rdx
 2a08bbb:	xor    %rdi,%rdi
 2a08bbe:	cmp    %rax,%rsi
 2a08bc1:	cmova  %rdi,%rdx
 2a08bc5:	mov    (%rdx),%eax
 2a08bc7:	mov    0x190(%rsp),%rdx
 2a08bcf:	mov    0x28(%rdx),%rdx
 2a08bd3:	cmp    0x160(%rdx),%eax
 2a08bd9:	sete   %al
 2a08bdc:	movzbl %al,%eax
 2a08bdf:	test   %eax,%eax
 2a08be1:	je     2a193b4 <wasm[0]::function[1015]::helper::object_read+0x1b254>
 2a08be7:	test   %r10d,%r10d
 2a08bea:	je     2a193b6 <wasm[0]::function[1015]::helper::object_read+0x1b256>
 2a08bf0:	mov    0x2e0(%rsp),%r14
 2a08bf8:	mov    0x28(%r14),%rdx
 2a08bfc:	mov    0x20(%r14),%rsi
 2a08c00:	mov    %r10d,%eax
 2a08c03:	lea    (%rsi,%rax,1),%r10
 2a08c07:	xor    %rdi,%rdi
 2a08c0a:	cmp    %rdx,%rax
 2a08c0d:	cmova  %rdi,%r10
 2a08c11:	mov    0x10(%r10),%r10d
 2a08c15:	test   %r10d,%r10d
 2a08c18:	je     2a193b8 <wasm[0]::function[1015]::helper::object_read+0x1b258>
 2a08c1e:	test   %r10d,%r10d
 2a08c21:	je     2a193ba <wasm[0]::function[1015]::helper::object_read+0x1b25a>
 2a08c27:	mov    %r10d,%r11d
 2a08c2a:	lea    (%rsi,%r11,1),%r10
 2a08c2e:	cmp    %rdx,%r11
 2a08c31:	cmova  %rdi,%r10
 2a08c35:	mov    0x10(%r10),%r10d
 2a08c39:	test   %r10d,%r10d
 2a08c3c:	je     2a193bc <wasm[0]::function[1015]::helper::object_read+0x1b25c>
 2a08c42:	test   %r10d,%r10d
 2a08c45:	je     2a193be <wasm[0]::function[1015]::helper::object_read+0x1b25e>
 2a08c4b:	mov    %r10d,%r10d
 2a08c4e:	lea    0x10(%rsi,%r10,1),%rsi
 2a08c53:	cmp    %rdx,%r10
 2a08c56:	cmova  %rdi,%rsi
 2a08c5a:	cmp    (%rsi),%ecx
 2a08c5c:	setae  %dl
 2a08c5f:	cmp    $0x2,%ecx
 2a08c62:	setae  %sil
 2a08c66:	or     %esi,%edx
 2a08c68:	test   %dl,%dl
 2a08c6a:	jne    2a193c0 <wasm[0]::function[1015]::helper::object_read+0x1b260>
 2a08c70:	mov    0x2e0(%rsp),%r14
 2a08c78:	mov    0x28(%r14),%rsi
 2a08c7c:	mov    %rax,%rdx
 2a08c7f:	add    0x20(%r14),%rdx
 2a08c83:	xor    %rdi,%rdi
 2a08c86:	cmp    %rsi,%rax
 2a08c89:	cmova  %rdi,%rdx
 2a08c8d:	mov    0x14(%rdx),%edi
 2a08c90:	test   %ecx,%ecx
 2a08c92:	je     2a08cc1 <wasm[0]::function[1015]::helper::object_read+0xab61>
 2a08c98:	mov    0x2e0(%rsp),%r14
 2a08ca0:	mov    0x28(%r14),%rsi
 2a08ca4:	mov    0x20(%r14),%rdx
 2a08ca8:	add    %rax,%rdx
 2a08cab:	xor    %r10,%r10
 2a08cae:	cmp    %rsi,%rax
 2a08cb1:	cmova  %r10,%rdx
 2a08cb5:	mov    0x20(%rdx),%rsi
 2a08cb9:	mov    0x2c(%rdx),%edx
 2a08cbc:	jmp    2a08ce5 <wasm[0]::function[1015]::helper::object_read+0xab85>
 2a08cc1:	mov    0x2e0(%rsp),%r14
 2a08cc9:	mov    0x28(%r14),%rsi
 2a08ccd:	mov    0x20(%r14),%rdx
 2a08cd1:	add    %rax,%rdx
 2a08cd4:	xor    %r10,%r10
 2a08cd7:	cmp    %rsi,%rax
 2a08cda:	cmova  %r10,%rdx
 2a08cde:	mov    0x18(%rdx),%rsi
 2a08ce2:	mov    0x28(%rdx),%edx
 2a08ce5:	shl    $0x3,%ecx
 2a08ce8:	shr    %cl,%edi
 2a08cea:	and    $0xff,%edi
 2a08cf0:	mov    0x1d0(%rsp),%r10
 2a08cf8:	mov    %r10d,0x110(%rsp)
 2a08d00:	mov    0x1d8(%rsp),%r11
 2a08d08:	mov    %r11d,0xd8(%rsp)
 2a08d10:	mov    0x1e0(%rsp),%r13
 2a08d18:	mov    %r13d,0x130(%rsp)
 2a08d20:	mov    0x1e8(%rsp),%r11
 2a08d28:	mov    %r11d,0xa0(%rsp)
 2a08d30:	mov    0x1f0(%rsp),%rax
 2a08d38:	mov    %eax,0x118(%rsp)
 2a08d3f:	mov    %ebx,0x108(%rsp)
 2a08d46:	mov    %r15d,0x100(%rsp)
 2a08d4e:	mov    %r12d,0xc8(%rsp)
 2a08d56:	mov    0x230(%rsp),%rcx
 2a08d5e:	cmp    $0x2,%ecx
 2a08d61:	je     2a09087 <wasm[0]::function[1015]::helper::object_read+0xaf27>
 2a08d67:	cmp    $0x4,%ecx
 2a08d6a:	je     2a08fb9 <wasm[0]::function[1015]::helper::object_read+0xae59>
 2a08d70:	cmp    $0x3,%ecx
 2a08d73:	je     2a08f75 <wasm[0]::function[1015]::helper::object_read+0xae15>
 2a08d79:	cmp    $0xa,%ecx
 2a08d7c:	je     2a08eac <wasm[0]::function[1015]::helper::object_read+0xad4c>
 2a08d82:	test   %ecx,%ecx
 2a08d84:	sete   %r10b
 2a08d88:	cmp    $0x1,%ecx
 2a08d8b:	sete   %al
 2a08d8e:	or     %eax,%r10d
 2a08d91:	test   %r10b,%r10b
 2a08d94:	jne    2a08ea4 <wasm[0]::function[1015]::helper::object_read+0xad44>
 2a08d9a:	xor    %eax,%eax
 2a08d9c:	test   %r8d,%r8d
 2a08d9f:	je     2a08df0 <wasm[0]::function[1015]::helper::object_read+0xac90>
 2a08da5:	xor    %eax,%eax
 2a08da7:	test   $0x1,%r8d
 2a08dae:	jne    2a08df0 <wasm[0]::function[1015]::helper::object_read+0xac90>
 2a08db4:	mov    0x2e0(%rsp),%r14
 2a08dbc:	mov    0x28(%r14),%rax
 2a08dc0:	mov    0x20(%r14),%rcx
 2a08dc4:	mov    %r8d,%r10d
 2a08dc7:	lea    0x4(%rcx,%r10,1),%rcx
 2a08dcc:	xor    %r11,%r11
 2a08dcf:	cmp    %rax,%r10
 2a08dd2:	cmova  %r11,%rcx
 2a08dd6:	mov    (%rcx),%eax
 2a08dd8:	mov    0x190(%rsp),%rcx
 2a08de0:	mov    0x28(%rcx),%rcx
 2a08de4:	cmp    0x1d4(%rcx),%eax
 2a08dea:	sete   %al
 2a08ded:	movzbl %al,%eax
 2a08df0:	test   %eax,%eax
 2a08df2:	jne    2a08dff <wasm[0]::function[1015]::helper::object_read+0xac9f>
 2a08df8:	xor    %ecx,%ecx
 2a08dfa:	jmp    2a08e96 <wasm[0]::function[1015]::helper::object_read+0xad36>
 2a08dff:	xor    %r10d,%r10d
 2a08e02:	test   %r8d,%r8d
 2a08e05:	je     2a08e58 <wasm[0]::function[1015]::helper::object_read+0xacf8>
 2a08e0b:	xor    %r10d,%r10d
 2a08e0e:	test   $0x1,%r8d
 2a08e15:	jne    2a08e58 <wasm[0]::function[1015]::helper::object_read+0xacf8>
 2a08e1b:	mov    0x2e0(%rsp),%r14
 2a08e23:	mov    0x28(%r14),%rax
 2a08e27:	mov    0x20(%r14),%rcx
 2a08e2b:	mov    %r8d,%r10d
 2a08e2e:	lea    0x4(%rcx,%r10,1),%rcx
 2a08e33:	xor    %r11,%r11
 2a08e36:	cmp    %rax,%r10
 2a08e39:	cmova  %r11,%rcx
 2a08e3d:	mov    (%rcx),%eax
 2a08e3f:	mov    0x190(%rsp),%rcx
 2a08e47:	mov    0x28(%rcx),%rcx
 2a08e4b:	cmp    0x1d4(%rcx),%eax
 2a08e51:	sete   %al
 2a08e54:	movzbl %al,%r10d
 2a08e58:	test   %r10d,%r10d
 2a08e5b:	je     2a193c2 <wasm[0]::function[1015]::helper::object_read+0x1b262>
 2a08e61:	test   %r8d,%r8d
 2a08e64:	je     2a193c4 <wasm[0]::function[1015]::helper::object_read+0x1b264>
 2a08e6a:	test   %r8d,%r8d
 2a08e6d:	je     2a193c6 <wasm[0]::function[1015]::helper::object_read+0x1b266>
 2a08e73:	mov    0x2e0(%rsp),%r14
 2a08e7b:	mov    0x28(%r14),%rax
 2a08e7f:	mov    %r8d,%r8d
 2a08e82:	mov    %r8,%rcx
 2a08e85:	add    0x20(%r14),%rcx
 2a08e89:	xor    %r10,%r10
 2a08e8c:	cmp    %rax,%r8
 2a08e8f:	cmova  %r10,%rcx
 2a08e93:	mov    0x3c(%rcx),%ecx
 2a08e96:	test   %ecx,%ecx
 2a08e98:	sete   %al
 2a08e9b:	movzbl %al,%r13d
 2a08e9f:	jmp    2a0907a <wasm[0]::function[1015]::helper::object_read+0xaf1a>
 2a08ea4:	xor    %r13d,%r13d
 2a08ea7:	jmp    2a0907a <wasm[0]::function[1015]::helper::object_read+0xaf1a>
 2a08eac:	xor    %eax,%eax
 2a08eae:	test   %r8d,%r8d
 2a08eb1:	je     2a08f02 <wasm[0]::function[1015]::helper::object_read+0xada2>
 2a08eb7:	xor    %eax,%eax
 2a08eb9:	test   $0x1,%r8d
 2a08ec0:	jne    2a08f02 <wasm[0]::function[1015]::helper::object_read+0xada2>
 2a08ec6:	mov    0x2e0(%rsp),%r14
 2a08ece:	mov    0x28(%r14),%rax
 2a08ed2:	mov    0x20(%r14),%rcx
 2a08ed6:	mov    %r8d,%r10d
 2a08ed9:	lea    0x4(%rcx,%r10,1),%rcx
 2a08ede:	xor    %r11,%r11
 2a08ee1:	cmp    %rax,%r10
 2a08ee4:	cmova  %r11,%rcx
 2a08ee8:	mov    (%rcx),%eax
 2a08eea:	mov    0x190(%rsp),%rcx
 2a08ef2:	mov    0x28(%rcx),%rcx
 2a08ef6:	cmp    0x23c(%rcx),%eax
 2a08efc:	sete   %al
 2a08eff:	movzbl %al,%eax
 2a08f02:	test   %eax,%eax
 2a08f04:	je     2a193c8 <wasm[0]::function[1015]::helper::object_read+0x1b268>
 2a08f0a:	test   %r8d,%r8d
 2a08f0d:	je     2a193ca <wasm[0]::function[1015]::helper::object_read+0x1b26a>
 2a08f13:	test   %r8d,%r8d
 2a08f16:	je     2a193cc <wasm[0]::function[1015]::helper::object_read+0x1b26c>
 2a08f1c:	mov    0x2e0(%rsp),%r14
 2a08f24:	mov    0x28(%r14),%rax
 2a08f28:	mov    0x20(%r14),%rcx
 2a08f2c:	mov    %r8d,%r11d
 2a08f2f:	lea    (%rcx,%r11,1),%r10
 2a08f33:	xor    %r8,%r8
 2a08f36:	cmp    %rax,%r11
 2a08f39:	cmova  %r8,%r10
 2a08f3d:	mov    0x14(%r10),%r10d
 2a08f41:	test   %r10d,%r10d
 2a08f44:	je     2a193ce <wasm[0]::function[1015]::helper::object_read+0x1b26e>
 2a08f4a:	test   %r10d,%r10d
 2a08f4d:	je     2a193d0 <wasm[0]::function[1015]::helper::object_read+0x1b270>
 2a08f53:	mov    %r10d,%r11d
 2a08f56:	lea    0x10(%rcx,%r11,1),%r10
 2a08f5b:	cmp    %rax,%r11
 2a08f5e:	cmova  %r8,%r10
 2a08f62:	mov    (%r10),%r8d
 2a08f65:	test   %r8d,%r8d
 2a08f68:	setne  %r8b
 2a08f6c:	movzbl %r8b,%r13d
 2a08f70:	jmp    2a0907a <wasm[0]::function[1015]::helper::object_read+0xaf1a>
 2a08f75:	mov    0x238(%rsp),%rcx
 2a08f7d:	movq   %rcx,%xmm0
 2a08f82:	ucomisd 0x10c56(%rip),%xmm0        # 2a19be0 <wasm[0]::function[1015]::helper::object_read+0x1ba80>
 2a08f8a:	setnp  %r8b
 2a08f8e:	sete   %r10b
 2a08f92:	and    %r10d,%r8d
 2a08f95:	ucomisd %xmm0,%xmm0
 2a08f99:	setp   %r11b
 2a08f9d:	setne  %al
 2a08fa0:	or     %eax,%r11d
 2a08fa3:	or     %r11d,%r8d
 2a08fa6:	movzbl %r8b,%r11d
 2a08faa:	test   %r11d,%r11d
 2a08fad:	sete   %al
 2a08fb0:	movzbl %al,%r13d
 2a08fb4:	jmp    2a0907a <wasm[0]::function[1015]::helper::object_read+0xaf1a>
 2a08fb9:	xor    %eax,%eax
 2a08fbb:	test   %r8d,%r8d
 2a08fbe:	je     2a0900f <wasm[0]::function[1015]::helper::object_read+0xaeaf>
 2a08fc4:	xor    %eax,%eax
 2a08fc6:	test   $0x1,%r8d
 2a08fcd:	jne    2a0900f <wasm[0]::function[1015]::helper::object_read+0xaeaf>
 2a08fd3:	mov    0x2e0(%rsp),%r14
 2a08fdb:	mov    0x28(%r14),%rax
 2a08fdf:	mov    0x20(%r14),%rcx
 2a08fe3:	mov    %r8d,%r10d
 2a08fe6:	lea    0x4(%rcx,%r10,1),%rcx
 2a08feb:	xor    %r11,%r11
 2a08fee:	cmp    %rax,%r10
 2a08ff1:	cmova  %r11,%rcx
 2a08ff5:	mov    (%rcx),%eax
 2a08ff7:	mov    0x190(%rsp),%rcx
 2a08fff:	mov    0x28(%rcx),%rcx
 2a09003:	cmp    0x234(%rcx),%eax
 2a09009:	sete   %al
 2a0900c:	movzbl %al,%eax
 2a0900f:	test   %eax,%eax
 2a09011:	je     2a193d2 <wasm[0]::function[1015]::helper::object_read+0x1b272>
 2a09017:	test   %r8d,%r8d
 2a0901a:	je     2a193d4 <wasm[0]::function[1015]::helper::object_read+0x1b274>
 2a09020:	test   %r8d,%r8d
 2a09023:	je     2a193d6 <wasm[0]::function[1015]::helper::object_read+0x1b276>
 2a09029:	mov    0x2e0(%rsp),%r14
 2a09031:	mov    0x28(%r14),%rax
 2a09035:	mov    0x20(%r14),%rcx
 2a09039:	mov    %r8d,%r11d
 2a0903c:	lea    (%rcx,%r11,1),%r10
 2a09040:	xor    %r8,%r8
 2a09043:	cmp    %rax,%r11
 2a09046:	cmova  %r8,%r10
 2a0904a:	mov    0x10(%r10),%r10d
 2a0904e:	test   %r10d,%r10d
 2a09051:	je     2a193d8 <wasm[0]::function[1015]::helper::object_read+0x1b278>
 2a09057:	test   %r10d,%r10d
 2a0905a:	je     2a193da <wasm[0]::function[1015]::helper::object_read+0x1b27a>
 2a09060:	mov    %r10d,%r10d
 2a09063:	lea    0x10(%rcx,%r10,1),%rcx
 2a09068:	cmp    %rax,%r10
 2a0906b:	cmova  %r8,%rcx
 2a0906f:	mov    (%rcx),%eax
 2a09071:	test   %eax,%eax
 2a09073:	setne  %al
 2a09076:	movzbl %al,%r13d
 2a0907a:	mov    0x1a0(%rsp),%r12
 2a09082:	jmp    2a090a1 <wasm[0]::function[1015]::helper::object_read+0xaf41>
 2a09087:	mov    0x238(%rsp),%rcx
 2a0908f:	test   %rcx,%rcx
 2a09092:	setne  %al
 2a09095:	movzbl %al,%r13d
 2a09099:	mov    0x1a0(%rsp),%r12
 2a090a1:	mov    0x1a0(%rsp),%r12
 2a090a9:	cmp    $0x2,%r12d
 2a090ad:	je     2a093f3 <wasm[0]::function[1015]::helper::object_read+0xb293>
 2a090b3:	mov    0x1a0(%rsp),%r12
 2a090bb:	cmp    $0x4,%r12d
 2a090bf:	je     2a0932a <wasm[0]::function[1015]::helper::object_read+0xb1ca>
 2a090c5:	mov    0x1a0(%rsp),%r12
 2a090cd:	cmp    $0x3,%r12d
 2a090d1:	je     2a092ec <wasm[0]::function[1015]::helper::object_read+0xb18c>
 2a090d7:	mov    0x1a0(%rsp),%r12
 2a090df:	cmp    $0xa,%r12d
 2a090e3:	je     2a09226 <wasm[0]::function[1015]::helper::object_read+0xb0c6>
 2a090e9:	mov    0x1a0(%rsp),%rax
 2a090f1:	mov    0x1a0(%rsp),%r12
 2a090f9:	test   %eax,%r12d
 2a090fc:	sete   %al
 2a090ff:	cmp    $0x1,%r12d
 2a09103:	sete   %cl
 2a09106:	or     %ecx,%eax
 2a09108:	test   %al,%al
 2a0910a:	jne    2a0921e <wasm[0]::function[1015]::helper::object_read+0xb0be>
 2a09110:	xor    %r11d,%r11d
 2a09113:	test   %r9d,%r9d
 2a09116:	je     2a09169 <wasm[0]::function[1015]::helper::object_read+0xb009>
 2a0911c:	xor    %r11d,%r11d
 2a0911f:	test   $0x1,%r9d
 2a09126:	jne    2a09169 <wasm[0]::function[1015]::helper::object_read+0xb009>
 2a0912c:	mov    0x2e0(%rsp),%r14
 2a09134:	mov    0x28(%r14),%rax
 2a09138:	mov    0x20(%r14),%rcx
 2a0913c:	mov    %r9d,%r8d
 2a0913f:	lea    0x4(%rcx,%r8,1),%rcx
 2a09144:	xor    %r10,%r10
 2a09147:	cmp    %rax,%r8
 2a0914a:	cmova  %r10,%rcx
 2a0914e:	mov    (%rcx),%eax
 2a09150:	mov    0x190(%rsp),%rcx
 2a09158:	mov    0x28(%rcx),%rcx
 2a0915c:	cmp    0x1d4(%rcx),%eax
 2a09162:	sete   %al
 2a09165:	movzbl %al,%r11d
 2a09169:	test   %r11d,%r11d
 2a0916c:	jne    2a09179 <wasm[0]::function[1015]::helper::object_read+0xb019>
 2a09172:	xor    %eax,%eax
 2a09174:	jmp    2a09210 <wasm[0]::function[1015]::helper::object_read+0xb0b0>
 2a09179:	xor    %eax,%eax
 2a0917b:	test   %r9d,%r9d
 2a0917e:	je     2a091d3 <wasm[0]::function[1015]::helper::object_read+0xb073>
 2a09184:	xor    %eax,%eax
 2a09186:	test   $0x1,%r9d
 2a0918d:	jne    2a091d3 <wasm[0]::function[1015]::helper::object_read+0xb073>
 2a09193:	mov    0x2e0(%rsp),%r14
 2a0919b:	mov    0x28(%r14),%r8
 2a0919f:	mov    0x20(%r14),%r10
 2a091a3:	mov    %r9d,%r11d
 2a091a6:	lea    0x4(%r10,%r11,1),%r10
 2a091ab:	xor    %rax,%rax
 2a091ae:	cmp    %r8,%r11
 2a091b1:	cmova  %rax,%r10
 2a091b5:	mov    (%r10),%r8d
 2a091b8:	mov    0x190(%rsp),%rcx
 2a091c0:	mov    0x28(%rcx),%r10
 2a091c4:	cmp    0x1d4(%r10),%r8d
 2a091cb:	sete   %r10b
 2a091cf:	movzbl %r10b,%eax
 2a091d3:	test   %eax,%eax
 2a091d5:	je     2a193dc <wasm[0]::function[1015]::helper::object_read+0x1b27c>
 2a091db:	test   %r9d,%r9d
 2a091de:	je     2a193de <wasm[0]::function[1015]::helper::object_read+0x1b27e>
 2a091e4:	test   %r9d,%r9d
 2a091e7:	je     2a193e0 <wasm[0]::function[1015]::helper::object_read+0x1b280>
 2a091ed:	mov    0x2e0(%rsp),%r14
 2a091f5:	mov    0x28(%r14),%rax
 2a091f9:	mov    %r9d,%r8d
 2a091fc:	mov    %r8,%rcx
 2a091ff:	add    0x20(%r14),%rcx
 2a09203:	xor    %r9,%r9
 2a09206:	cmp    %rax,%r8
 2a09209:	cmova  %r9,%rcx
 2a0920d:	mov    0x3c(%rcx),%eax
 2a09210:	test   %eax,%eax
 2a09212:	sete   %al
 2a09215:	movzbl %al,%r12d
 2a09219:	jmp    2a09405 <wasm[0]::function[1015]::helper::object_read+0xb2a5>
 2a0921e:	xor    %r12d,%r12d
 2a09221:	jmp    2a09405 <wasm[0]::function[1015]::helper::object_read+0xb2a5>
 2a09226:	xor    %eax,%eax
 2a09228:	test   %r9d,%r9d
 2a0922b:	je     2a0927c <wasm[0]::function[1015]::helper::object_read+0xb11c>
 2a09231:	xor    %eax,%eax
 2a09233:	test   $0x1,%r9d
 2a0923a:	jne    2a0927c <wasm[0]::function[1015]::helper::object_read+0xb11c>
 2a09240:	mov    0x2e0(%rsp),%r14
 2a09248:	mov    0x28(%r14),%rax
 2a0924c:	mov    0x20(%r14),%rcx
 2a09250:	mov    %r9d,%r8d
 2a09253:	lea    0x4(%rcx,%r8,1),%rcx
 2a09258:	xor    %r10,%r10
 2a0925b:	cmp    %rax,%r8
 2a0925e:	cmova  %r10,%rcx
 2a09262:	mov    (%rcx),%eax
 2a09264:	mov    0x190(%rsp),%rcx
 2a0926c:	mov    0x28(%rcx),%rcx
 2a09270:	cmp    0x23c(%rcx),%eax
 2a09276:	sete   %al
 2a09279:	movzbl %al,%eax
 2a0927c:	test   %eax,%eax
 2a0927e:	je     2a193e2 <wasm[0]::function[1015]::helper::object_read+0x1b282>
 2a09284:	test   %r9d,%r9d
 2a09287:	je     2a193e4 <wasm[0]::function[1015]::helper::object_read+0x1b284>
 2a0928d:	test   %r9d,%r9d
 2a09290:	je     2a193e6 <wasm[0]::function[1015]::helper::object_read+0x1b286>
 2a09296:	mov    0x2e0(%rsp),%r14
 2a0929e:	mov    0x28(%r14),%rax
 2a092a2:	mov    0x20(%r14),%rcx
 2a092a6:	mov    %r9d,%r10d
 2a092a9:	lea    (%rcx,%r10,1),%r9
 2a092ad:	xor    %r8,%r8
 2a092b0:	cmp    %rax,%r10
 2a092b3:	cmova  %r8,%r9
 2a092b7:	mov    0x14(%r9),%r9d
 2a092bb:	test   %r9d,%r9d
 2a092be:	je     2a193e8 <wasm[0]::function[1015]::helper::object_read+0x1b288>
 2a092c4:	test   %r9d,%r9d
 2a092c7:	je     2a193ea <wasm[0]::function[1015]::helper::object_read+0x1b28a>
 2a092cd:	mov    %r9d,%r9d
 2a092d0:	lea    0x10(%rcx,%r9,1),%rcx
 2a092d5:	cmp    %rax,%r9
 2a092d8:	cmova  %r8,%rcx
 2a092dc:	mov    (%rcx),%eax
 2a092de:	test   %eax,%eax
 2a092e0:	setne  %al
 2a092e3:	movzbl %al,%r12d
 2a092e7:	jmp    2a09405 <wasm[0]::function[1015]::helper::object_read+0xb2a5>
 2a092ec:	mov    0x1c8(%rsp),%rcx
 2a092f4:	movq   %rcx,%xmm0
 2a092f9:	ucomisd 0x108ef(%rip),%xmm0        # 2a19bf0 <wasm[0]::function[1015]::helper::object_read+0x1ba90>
 2a09301:	setnp  %al
 2a09304:	sete   %cl
 2a09307:	and    %ecx,%eax
 2a09309:	ucomisd %xmm0,%xmm0
 2a0930d:	setp   %cl
 2a09310:	setne  %r8b
 2a09314:	or     %r8d,%ecx
 2a09317:	or     %ecx,%eax
 2a09319:	movzbl %al,%eax
 2a0931c:	test   %eax,%eax
 2a0931e:	sete   %al
 2a09321:	movzbl %al,%r12d
 2a09325:	jmp    2a09405 <wasm[0]::function[1015]::helper::object_read+0xb2a5>
 2a0932a:	xor    %eax,%eax
 2a0932c:	test   %r9d,%r9d
 2a0932f:	je     2a09380 <wasm[0]::function[1015]::helper::object_read+0xb220>
 2a09335:	xor    %eax,%eax
 2a09337:	test   $0x1,%r9d
 2a0933e:	jne    2a09380 <wasm[0]::function[1015]::helper::object_read+0xb220>
 2a09344:	mov    0x2e0(%rsp),%r14
 2a0934c:	mov    0x28(%r14),%rax
 2a09350:	mov    0x20(%r14),%rcx
 2a09354:	mov    %r9d,%r8d
 2a09357:	lea    0x4(%rcx,%r8,1),%rcx
 2a0935c:	xor    %r10,%r10
 2a0935f:	cmp    %rax,%r8
 2a09362:	cmova  %r10,%rcx
 2a09366:	mov    (%rcx),%eax
 2a09368:	mov    0x190(%rsp),%rcx
 2a09370:	mov    0x28(%rcx),%rcx
 2a09374:	cmp    0x234(%rcx),%eax
 2a0937a:	sete   %al
 2a0937d:	movzbl %al,%eax
 2a09380:	test   %eax,%eax
 2a09382:	je     2a193ec <wasm[0]::function[1015]::helper::object_read+0x1b28c>
 2a09388:	test   %r9d,%r9d
 2a0938b:	je     2a193ee <wasm[0]::function[1015]::helper::object_read+0x1b28e>
 2a09391:	test   %r9d,%r9d
 2a09394:	je     2a193f0 <wasm[0]::function[1015]::helper::object_read+0x1b290>
 2a0939a:	mov    0x2e0(%rsp),%r14
 2a093a2:	mov    0x28(%r14),%r8
 2a093a6:	mov    0x20(%r14),%r10
 2a093aa:	mov    %r9d,%r11d
 2a093ad:	lea    (%r10,%r11,1),%rax
 2a093b1:	xor    %r9,%r9
 2a093b4:	cmp    %r8,%r11
 2a093b7:	cmova  %r9,%rax
 2a093bb:	mov    0x10(%rax),%r11d
 2a093bf:	test   %r11d,%r11d
 2a093c2:	je     2a193f2 <wasm[0]::function[1015]::helper::object_read+0x1b292>
 2a093c8:	test   %r11d,%r11d
 2a093cb:	je     2a193f4 <wasm[0]::function[1015]::helper::object_read+0x1b294>
 2a093d1:	mov    %r11d,%r11d
 2a093d4:	lea    0x10(%r10,%r11,1),%r10
 2a093d9:	cmp    %r8,%r11
 2a093dc:	cmova  %r9,%r10
 2a093e0:	mov    (%r10),%r9d
 2a093e3:	test   %r9d,%r9d
 2a093e6:	setne  %r10b
 2a093ea:	movzbl %r10b,%r12d
 2a093ee:	jmp    2a09405 <wasm[0]::function[1015]::helper::object_read+0xb2a5>
 2a093f3:	mov    0x1c8(%rsp),%rcx
 2a093fb:	test   %rcx,%rcx
 2a093fe:	setne  %al
 2a09401:	movzbl %al,%r12d
 2a09405:	cmp    $0x2,%edi
 2a09408:	je     2a096f6 <wasm[0]::function[1015]::helper::object_read+0xb596>
 2a0940e:	cmp    $0x4,%edi
 2a09411:	je     2a09632 <wasm[0]::function[1015]::helper::object_read+0xb4d2>
 2a09417:	cmp    $0x3,%edi
 2a0941a:	je     2a095ff <wasm[0]::function[1015]::helper::object_read+0xb49f>
 2a09420:	cmp    $0xa,%edi
 2a09423:	je     2a09541 <wasm[0]::function[1015]::helper::object_read+0xb3e1>
 2a09429:	test   %edi,%edi
 2a0942b:	sete   %al
 2a0942e:	cmp    $0x1,%edi
 2a09431:	sete   %cl
 2a09434:	or     %ecx,%eax
 2a09436:	test   %al,%al
 2a09438:	jne    2a0953a <wasm[0]::function[1015]::helper::object_read+0xb3da>
 2a0943e:	xor    %eax,%eax
 2a09440:	test   %edx,%edx
 2a09442:	je     2a09491 <wasm[0]::function[1015]::helper::object_read+0xb331>
 2a09448:	xor    %eax,%eax
 2a0944a:	test   $0x1,%edx
 2a09450:	jne    2a09491 <wasm[0]::function[1015]::helper::object_read+0xb331>
 2a09456:	mov    0x2e0(%rsp),%r14
 2a0945e:	mov    0x28(%r14),%rax
 2a09462:	mov    0x20(%r14),%rcx
 2a09466:	mov    %edx,%esi
 2a09468:	lea    0x4(%rcx,%rsi,1),%rcx
 2a0946d:	xor    %rdi,%rdi
 2a09470:	cmp    %rax,%rsi
 2a09473:	cmova  %rdi,%rcx
 2a09477:	mov    (%rcx),%eax
 2a09479:	mov    0x190(%rsp),%rcx
 2a09481:	mov    0x28(%rcx),%rcx
 2a09485:	cmp    0x1d4(%rcx),%eax
 2a0948b:	sete   %al
 2a0948e:	movzbl %al,%eax
 2a09491:	test   %eax,%eax
 2a09493:	jne    2a094a0 <wasm[0]::function[1015]::helper::object_read+0xb340>
 2a09499:	xor    %eax,%eax
 2a0949b:	jmp    2a0952d <wasm[0]::function[1015]::helper::object_read+0xb3cd>
 2a094a0:	xor    %eax,%eax
 2a094a2:	test   %edx,%edx
 2a094a4:	je     2a094f3 <wasm[0]::function[1015]::helper::object_read+0xb393>
 2a094aa:	xor    %eax,%eax
 2a094ac:	test   $0x1,%edx
 2a094b2:	jne    2a094f3 <wasm[0]::function[1015]::helper::object_read+0xb393>
 2a094b8:	mov    0x2e0(%rsp),%r14
 2a094c0:	mov    0x28(%r14),%rax
 2a094c4:	mov    0x20(%r14),%rcx
 2a094c8:	mov    %edx,%esi
 2a094ca:	lea    0x4(%rcx,%rsi,1),%rcx
 2a094cf:	xor    %rdi,%rdi
 2a094d2:	cmp    %rax,%rsi
 2a094d5:	cmova  %rdi,%rcx
 2a094d9:	mov    (%rcx),%eax
 2a094db:	mov    0x190(%rsp),%rcx
 2a094e3:	mov    0x28(%rcx),%rcx
 2a094e7:	cmp    0x1d4(%rcx),%eax
 2a094ed:	sete   %al
 2a094f0:	movzbl %al,%eax
 2a094f3:	test   %eax,%eax
 2a094f5:	je     2a193f6 <wasm[0]::function[1015]::helper::object_read+0x1b296>
 2a094fb:	test   %edx,%edx
 2a094fd:	je     2a193f8 <wasm[0]::function[1015]::helper::object_read+0x1b298>
 2a09503:	test   %edx,%edx
 2a09505:	je     2a193fa <wasm[0]::function[1015]::helper::object_read+0x1b29a>
 2a0950b:	mov    0x2e0(%rsp),%r14
 2a09513:	mov    0x28(%r14),%rax
 2a09517:	mov    %edx,%edx
 2a09519:	mov    %rdx,%rcx
 2a0951c:	add    0x20(%r14),%rcx
 2a09520:	xor    %rsi,%rsi
 2a09523:	cmp    %rax,%rdx
 2a09526:	cmova  %rsi,%rcx
 2a0952a:	mov    0x3c(%rcx),%eax
 2a0952d:	test   %eax,%eax
 2a0952f:	sete   %al
 2a09532:	movzbl %al,%ebx
 2a09535:	jmp    2a096e9 <wasm[0]::function[1015]::helper::object_read+0xb589>
 2a0953a:	xor    %ebx,%ebx
 2a0953c:	jmp    2a096e9 <wasm[0]::function[1015]::helper::object_read+0xb589>
 2a09541:	xor    %eax,%eax
 2a09543:	test   %edx,%edx
 2a09545:	je     2a09596 <wasm[0]::function[1015]::helper::object_read+0xb436>
 2a0954b:	xor    %eax,%eax
 2a0954d:	test   $0x1,%edx
 2a09553:	jne    2a09596 <wasm[0]::function[1015]::helper::object_read+0xb436>
 2a09559:	mov    0x2e0(%rsp),%r14
 2a09561:	mov    0x28(%r14),%rsi
 2a09565:	mov    0x20(%r14),%r8
 2a09569:	mov    %edx,%edi
 2a0956b:	lea    0x4(%r8,%rdi,1),%rax
 2a09570:	xor    %r8,%r8
 2a09573:	cmp    %rsi,%rdi
 2a09576:	cmova  %r8,%rax
 2a0957a:	mov    (%rax),%esi
 2a0957c:	mov    0x190(%rsp),%rcx
 2a09584:	mov    0x28(%rcx),%rdi
 2a09588:	cmp    0x23c(%rdi),%esi
 2a0958e:	sete   %sil
 2a09592:	movzbl %sil,%eax
 2a09596:	test   %eax,%eax
 2a09598:	je     2a193fc <wasm[0]::function[1015]::helper::object_read+0x1b29c>
 2a0959e:	test   %edx,%edx
 2a095a0:	je     2a193fe <wasm[0]::function[1015]::helper::object_read+0x1b29e>
 2a095a6:	test   %edx,%edx
 2a095a8:	je     2a19400 <wasm[0]::function[1015]::helper::object_read+0x1b2a0>
 2a095ae:	mov    0x2e0(%rsp),%r14
 2a095b6:	mov    0x28(%r14),%r11
 2a095ba:	mov    0x20(%r14),%rax
 2a095be:	mov    %edx,%edx
 2a095c0:	lea    (%rax,%rdx,1),%r8
 2a095c4:	xor    %rcx,%rcx
 2a095c7:	cmp    %r11,%rdx
 2a095ca:	cmova  %rcx,%r8
 2a095ce:	mov    0x14(%r8),%edx
 2a095d2:	test   %edx,%edx
 2a095d4:	je     2a19402 <wasm[0]::function[1015]::helper::object_read+0x1b2a2>
 2a095da:	test   %edx,%edx
 2a095dc:	je     2a19404 <wasm[0]::function[1015]::helper::object_read+0x1b2a4>
 2a095e2:	mov    %edx,%edx
 2a095e4:	lea    0x10(%rax,%rdx,1),%rax
 2a095e9:	cmp    %r11,%rdx
 2a095ec:	cmova  %rcx,%rax
 2a095f0:	mov    (%rax),%eax
 2a095f2:	test   %eax,%eax
 2a095f4:	setne  %al
 2a095f7:	movzbl %al,%ebx
 2a095fa:	jmp    2a096e9 <wasm[0]::function[1015]::helper::object_read+0xb589>
 2a095ff:	movq   %rsi,%xmm0
 2a09604:	ucomisd 0x105f4(%rip),%xmm0        # 2a19c00 <wasm[0]::function[1015]::helper::object_read+0x1baa0>
 2a0960c:	setnp  %al
 2a0960f:	sete   %cl
 2a09612:	and    %ecx,%eax
 2a09614:	ucomisd %xmm0,%xmm0
 2a09618:	setp   %cl
 2a0961b:	setne  %dl
 2a0961e:	or     %edx,%ecx
 2a09620:	or     %ecx,%eax
 2a09622:	movzbl %al,%eax
 2a09625:	test   %eax,%eax
 2a09627:	sete   %al
 2a0962a:	movzbl %al,%ebx
 2a0962d:	jmp    2a096e9 <wasm[0]::function[1015]::helper::object_read+0xb589>
 2a09632:	xor    %esi,%esi
 2a09634:	test   %edx,%edx
 2a09636:	je     2a09686 <wasm[0]::function[1015]::helper::object_read+0xb526>
 2a0963c:	xor    %esi,%esi
 2a0963e:	test   $0x1,%edx
 2a09644:	jne    2a09686 <wasm[0]::function[1015]::helper::object_read+0xb526>
 2a0964a:	mov    0x2e0(%rsp),%r14
 2a09652:	mov    0x28(%r14),%rax
 2a09656:	mov    0x20(%r14),%rcx
 2a0965a:	mov    %edx,%esi
 2a0965c:	lea    0x4(%rcx,%rsi,1),%rcx
 2a09661:	xor    %rdi,%rdi
 2a09664:	cmp    %rax,%rsi
 2a09667:	cmova  %rdi,%rcx
 2a0966b:	mov    (%rcx),%eax
 2a0966d:	mov    0x190(%rsp),%rcx
 2a09675:	mov    0x28(%rcx),%rcx
 2a09679:	cmp    0x234(%rcx),%eax
 2a0967f:	sete   %al
 2a09682:	rex movzbl %al,%esi
 2a09686:	test   %esi,%esi
 2a09688:	je     2a19406 <wasm[0]::function[1015]::helper::object_read+0x1b2a6>
 2a0968e:	test   %edx,%edx
 2a09690:	je     2a19408 <wasm[0]::function[1015]::helper::object_read+0x1b2a8>
 2a09696:	test   %edx,%edx
 2a09698:	je     2a1940a <wasm[0]::function[1015]::helper::object_read+0x1b2aa>
 2a0969e:	mov    0x2e0(%rsp),%r14
 2a096a6:	mov    0x28(%r14),%rax
 2a096aa:	mov    0x20(%r14),%rcx
 2a096ae:	mov    %edx,%edi
 2a096b0:	lea    (%rcx,%rdi,1),%rsi
 2a096b4:	xor    %rdx,%rdx
 2a096b7:	cmp    %rax,%rdi
 2a096ba:	cmova  %rdx,%rsi
 2a096be:	mov    0x10(%rsi),%esi
 2a096c1:	test   %esi,%esi
 2a096c3:	je     2a1940c <wasm[0]::function[1015]::helper::object_read+0x1b2ac>
 2a096c9:	test   %esi,%esi
 2a096cb:	je     2a1940e <wasm[0]::function[1015]::helper::object_read+0x1b2ae>
 2a096d1:	mov    %esi,%esi
 2a096d3:	lea    0x10(%rcx,%rsi,1),%rcx
 2a096d8:	cmp    %rax,%rsi
 2a096db:	cmova  %rdx,%rcx
 2a096df:	mov    (%rcx),%eax
 2a096e1:	test   %eax,%eax
 2a096e3:	setne  %al
 2a096e6:	movzbl %al,%ebx
 2a096e9:	mov    0x2c0(%rsp),%rsi
 2a096f1:	jmp    2a09707 <wasm[0]::function[1015]::helper::object_read+0xb5a7>
 2a096f6:	test   %rsi,%rsi
 2a096f9:	setne  %al
 2a096fc:	movzbl %al,%ebx
 2a096ff:	mov    0x2c0(%rsp),%rsi
 2a09707:	mov    0x2c0(%rsp),%rsi
 2a0970f:	mov    (%rsi),%eax
 2a09711:	mov    %eax,%edx
 2a09713:	lea    0x20(%rdx),%rcx
 2a09717:	mov    0x4(%rsi),%esi
 2a0971a:	cmp    %rsi,%rcx
 2a0971d:	ja     2a17e2b <wasm[0]::function[1015]::helper::object_read+0x19ccb>
 2a09723:	lea    0x20(%rax),%ecx
 2a09726:	mov    0x2c0(%rsp),%rsi
 2a0972e:	mov    %ecx,(%rsi)
 2a09730:	mov    0x2e0(%rsp),%r14
 2a09738:	mov    0x20(%r14),%rsi
 2a0973c:	lea    (%rsi,%rdx,1),%rcx
 2a09740:	movl   $0xb0000042,(%rsi,%rdx,1)
 2a09747:	mov    0x190(%rsp),%rdi
 2a0974f:	mov    0x28(%rdi),%rdi
 2a09753:	mov    0x120(%rdi),%edi
 2a09759:	mov    %edi,0x4(%rsi,%rdx,1)
 2a0975d:	mov    0x2c8(%rsp),%rdi
 2a09765:	mov    %edi,0x8(%rsi,%rdx,1)
 2a09769:	mov    %eax,0x138(%rsp)
 2a09770:	mov    0x240(%rsp),%rsi
 2a09778:	mov    %rsi,0x10(%rcx)
 2a0977c:	mov    0x248(%rsp),%r11
 2a09784:	mov    %r11d,0x18(%rcx)
 2a09788:	mov    0x110(%rsp),%eax
 2a0978f:	mov    %eax,0x1c(%rcx)
 2a09792:	mov    0x2c0(%rsp),%rsi
 2a0979a:	mov    (%rsi),%eax
 2a0979c:	mov    %eax,%edx
 2a0979e:	lea    0x20(%rdx),%rcx
 2a097a2:	mov    0x4(%rsi),%esi
 2a097a5:	cmp    %rsi,%rcx
 2a097a8:	ja     2a17e6d <wasm[0]::function[1015]::helper::object_read+0x19d0d>
 2a097ae:	lea    0x20(%rax),%esi
 2a097b1:	mov    0x2c0(%rsp),%rcx
 2a097b9:	mov    %esi,(%rcx)
 2a097bb:	mov    0x2e0(%rsp),%r14
 2a097c3:	mov    0x20(%r14),%rsi
 2a097c7:	lea    (%rsi,%rdx,1),%rcx
 2a097cb:	movl   $0xb0000042,(%rsi,%rdx,1)
 2a097d2:	mov    0x190(%rsp),%rdi
 2a097da:	mov    0x28(%rdi),%rdi
 2a097de:	mov    0x120(%rdi),%edi
 2a097e4:	mov    %edi,0x4(%rsi,%rdx,1)
 2a097e8:	mov    0x2c8(%rsp),%rdi
 2a097f0:	mov    %edi,0x8(%rsi,%rdx,1)
 2a097f4:	mov    %eax,0x110(%rsp)
 2a097fb:	mov    0x250(%rsp),%rax
 2a09803:	mov    %rax,0x10(%rcx)
 2a09807:	mov    0x258(%rsp),%rsi
 2a0980f:	mov    %esi,0x18(%rcx)
 2a09812:	mov    0xd8(%rsp),%r11d
 2a0981a:	mov    %r11d,0x1c(%rcx)
 2a0981e:	mov    0x2c0(%rsp),%rsi
 2a09826:	mov    (%rsi),%eax
 2a09828:	mov    %eax,%edx
 2a0982a:	lea    0x20(%rdx),%rcx
 2a0982e:	mov    0x4(%rsi),%esi
 2a09831:	cmp    %rsi,%rcx
 2a09834:	ja     2a17eaf <wasm[0]::function[1015]::helper::object_read+0x19d4f>
 2a0983a:	lea    0x20(%rax),%ecx
 2a0983d:	mov    0x2c0(%rsp),%rsi
 2a09845:	mov    %ecx,(%rsi)
 2a09847:	mov    0x2e0(%rsp),%r14
 2a0984f:	mov    0x20(%r14),%rsi
 2a09853:	lea    (%rsi,%rdx,1),%rcx
 2a09857:	movl   $0xb0000042,(%rsi,%rdx,1)
 2a0985e:	mov    0x190(%rsp),%rdi
 2a09866:	mov    0x28(%rdi),%rdi
 2a0986a:	mov    0x120(%rdi),%edi
 2a09870:	mov    %edi,0x4(%rsi,%rdx,1)
 2a09874:	mov    0x2c8(%rsp),%rdi
 2a0987c:	mov    %edi,0x8(%rsi,%rdx,1)
 2a09880:	mov    %eax,0xd8(%rsp)
 2a09887:	mov    0x260(%rsp),%rdx
 2a0988f:	mov    %rdx,0x10(%rcx)
 2a09893:	mov    0x268(%rsp),%r8
 2a0989b:	mov    %r8d,0x18(%rcx)
 2a0989f:	mov    0x130(%rsp),%edx
 2a098a6:	mov    %edx,0x1c(%rcx)
 2a098a9:	mov    0x270(%rsp),%rcx
 2a098b1:	mov    0x270(%rsp),%rdx
 2a098b9:	test   %edx,%ecx
 2a098bb:	jne    2a09999 <wasm[0]::function[1015]::helper::object_read+0xb839>
 2a098c1:	mov    0x138(%rsp),%ecx
 2a098c8:	test   %ecx,%ecx
 2a098ca:	je     2a19410 <wasm[0]::function[1015]::helper::object_read+0x1b2b0>
 2a098d0:	mov    0x110(%rsp),%ecx
 2a098d7:	test   %ecx,%ecx
 2a098d9:	je     2a19412 <wasm[0]::function[1015]::helper::object_read+0x1b2b2>
 2a098df:	test   %eax,%eax
 2a098e1:	je     2a19414 <wasm[0]::function[1015]::helper::object_read+0x1b2b4>
 2a098e7:	mov    0x2c0(%rsp),%rsi
 2a098ef:	mov    (%rsi),%eax
 2a098f1:	mov    %eax,%ecx
 2a098f3:	lea    0x20(%rcx),%rdx
 2a098f7:	mov    0x4(%rsi),%esi
 2a098fa:	cmp    %rsi,%rdx
 2a098fd:	ja     2a17ef1 <wasm[0]::function[1015]::helper::object_read+0x19d91>
 2a09903:	lea    0x20(%rax),%edx
 2a09906:	mov    0x2c0(%rsp),%rsi
 2a0990e:	mov    %edx,(%rsi)
 2a09910:	mov    0x2e0(%rsp),%r14
 2a09918:	mov    0x20(%r14),%rsi
 2a0991c:	lea    (%rsi,%rcx,1),%rdx
 2a09920:	movl   $0xb0000072,(%rsi,%rcx,1)
 2a09927:	mov    0x190(%rsp),%rdi
 2a0992f:	mov    0x28(%rdi),%rdi
 2a09933:	mov    0x13c(%rdi),%edi
 2a09939:	mov    %edi,0x4(%rsi,%rcx,1)
 2a0993d:	mov    0x2c8(%rsp),%rdi
 2a09945:	mov    %edi,0x8(%rsi,%rcx,1)
 2a09949:	test   %r13d,%r13d
 2a0994c:	setne  %cl
 2a0994f:	movzbl %cl,%ecx
 2a09952:	shl    $0x2,%ecx
 2a09955:	test   %r12d,%r12d
 2a09958:	setne  %sil
 2a0995c:	movzbl %sil,%esi
 2a09960:	shl    $0x3,%esi
 2a09963:	or     %esi,%ecx
 2a09965:	test   %ebx,%ebx
 2a09967:	setne  %sil
 2a0996b:	movzbl %sil,%esi
 2a0996f:	shl    $1,%esi
 2a09971:	or     %esi,%ecx
 2a09973:	mov    %ecx,0x10(%rdx)
 2a09976:	mov    0x138(%rsp),%ecx
 2a0997d:	mov    %ecx,0x14(%rdx)
 2a09980:	mov    0x110(%rsp),%ecx
 2a09987:	mov    %ecx,0x18(%rdx)
 2a0998a:	mov    0xd8(%rsp),%ecx
 2a09991:	mov    %ecx,0x1c(%rdx)
 2a09994:	jmp    2a09a5f <wasm[0]::function[1015]::helper::object_read+0xb8ff>
 2a09999:	mov    0x138(%rsp),%ecx
 2a099a0:	test   %ecx,%ecx
 2a099a2:	je     2a19416 <wasm[0]::function[1015]::helper::object_read+0x1b2b6>
 2a099a8:	mov    0x110(%rsp),%ecx
 2a099af:	test   %ecx,%ecx
 2a099b1:	je     2a19418 <wasm[0]::function[1015]::helper::object_read+0x1b2b8>
 2a099b7:	test   %eax,%eax
 2a099b9:	je     2a1941a <wasm[0]::function[1015]::helper::object_read+0x1b2ba>
 2a099bf:	mov    0x2c0(%rsp),%rsi
 2a099c7:	mov    (%rsi),%eax
 2a099c9:	mov    %eax,%edx
 2a099cb:	lea    0x20(%rdx),%rcx
 2a099cf:	mov    0x4(%rsi),%esi
 2a099d2:	cmp    %rsi,%rcx
 2a099d5:	ja     2a17f33 <wasm[0]::function[1015]::helper::object_read+0x19dd3>
 2a099db:	lea    0x20(%rax),%ecx
 2a099de:	mov    0x2c0(%rsp),%rsi
 2a099e6:	mov    %ecx,(%rsi)
 2a099e8:	mov    0x2e0(%rsp),%r14
 2a099f0:	mov    0x20(%r14),%rsi
 2a099f4:	lea    (%rsi,%rdx,1),%rcx
 2a099f8:	movl   $0xb0000072,(%rsi,%rdx,1)
 2a099ff:	mov    0x190(%rsp),%rdi
 2a09a07:	mov    0x28(%rdi),%rdi
 2a09a0b:	mov    0x13c(%rdi),%edi
 2a09a11:	mov    %edi,0x4(%rsi,%rdx,1)
 2a09a15:	mov    0x2c8(%rsp),%rdi
 2a09a1d:	mov    %edi,0x8(%rsi,%rdx,1)
 2a09a21:	test   %r12d,%r12d
 2a09a24:	setne  %dl
 2a09a27:	movzbl %dl,%edx
 2a09a2a:	shl    $0x3,%edx
 2a09a2d:	or     $0x1,%edx
 2a09a30:	test   %ebx,%ebx
 2a09a32:	setne  %sil
 2a09a36:	movzbl %sil,%esi
 2a09a3a:	shl    $1,%esi
 2a09a3c:	or     %esi,%edx
 2a09a3e:	mov    %edx,0x10(%rcx)
 2a09a41:	mov    0x138(%rsp),%edx
 2a09a48:	mov    %edx,0x14(%rcx)
 2a09a4b:	mov    0x110(%rsp),%esi
 2a09a52:	mov    %esi,0x18(%rcx)
 2a09a55:	mov    0xd8(%rsp),%esi
 2a09a5c:	mov    %esi,0x1c(%rcx)
 2a09a5f:	mov    0xa0(%rsp),%esi
 2a09a66:	mov    0x118(%rsp),%edi
 2a09a6d:	mov    0x108(%rsp),%r8d
 2a09a75:	mov    0x100(%rsp),%edx
 2a09a7c:	mov    0xc8(%rsp),%ecx
 2a09a83:	mov    %rax,%r15
 2a09a86:	jmp    2a0c6b0 <wasm[0]::function[1015]::helper::object_read+0xe550>
 2a09a8b:	mov    0xb0(%rsp),%edx
 2a09a92:	mov    0x2a8(%rsp),%rax
 2a09a9a:	mov    0x2b8(%rsp),%rcx
 2a09aa2:	mov    0x2f0(%rsp),%rbx
 2a09aaa:	mov    0x2f8(%rsp),%r12
 2a09ab2:	mov    0x300(%rsp),%r13
 2a09aba:	mov    0x308(%rsp),%r14
 2a09ac2:	mov    0x310(%rsp),%r15
 2a09aca:	add    $0x320,%rsp
 2a09ad1:	mov    %rbp,%rsp
 2a09ad4:	pop    %rbp
 2a09ad5:	ret    $0x40
 2a09ad8:	xor    %r8d,%r8d
 2a09adb:	mov    0x210(%rsp),%rax
 2a09ae3:	mov    0x210(%rsp),%rdx
 2a09aeb:	test   %eax,%edx
 2a09aed:	je     2a09b4e <wasm[0]::function[1015]::helper::object_read+0xb9ee>
 2a09af3:	xor    %r8d,%r8d
 2a09af6:	mov    0x210(%rsp),%rdx
 2a09afe:	test   $0x1,%edx
 2a09b04:	jne    2a09b4e <wasm[0]::function[1015]::helper::object_read+0xb9ee>
 2a09b0a:	mov    0x2e0(%rsp),%r14
 2a09b12:	mov    0x28(%r14),%rax
 2a09b16:	mov    0x20(%r14),%rcx
 2a09b1a:	mov    0x210(%rsp),%rdx
 2a09b22:	mov    %edx,%edx
 2a09b24:	lea    0x4(%rcx,%rdx,1),%rcx
 2a09b29:	xor    %rsi,%rsi
 2a09b2c:	cmp    %rax,%rdx
 2a09b2f:	cmova  %rsi,%rcx
 2a09b33:	mov    (%rcx),%eax
 2a09b35:	mov    0x190(%rsp),%rcx
 2a09b3d:	mov    0x28(%rcx),%rcx
 2a09b41:	cmp    0x254(%rcx),%eax
 2a09b47:	sete   %al
 2a09b4a:	movzbl %al,%r8d
 2a09b4e:	test   %r8d,%r8d
 2a09b51:	je     2a1941c <wasm[0]::function[1015]::helper::object_read+0x1b2bc>
 2a09b57:	mov    0x210(%rsp),%rax
 2a09b5f:	mov    0x210(%rsp),%rdx
 2a09b67:	test   %eax,%edx
 2a09b69:	je     2a1941e <wasm[0]::function[1015]::helper::object_read+0x1b2be>
 2a09b6f:	test   %eax,%edx
 2a09b71:	je     2a19420 <wasm[0]::function[1015]::helper::object_read+0x1b2c0>
 2a09b77:	mov    0x2e0(%rsp),%r14
 2a09b7f:	mov    0x28(%r14),%rax
 2a09b83:	mov    0x20(%r14),%rcx
 2a09b87:	mov    %edx,%edx
 2a09b89:	add    %rdx,%rcx
 2a09b8c:	xor    %rsi,%rsi
 2a09b8f:	cmp    %rax,%rdx
 2a09b92:	cmova  %rsi,%rcx
 2a09b96:	mov    0x10(%rcx),%edx
 2a09b99:	test   %edx,%edx
 2a09b9b:	je     2a19422 <wasm[0]::function[1015]::helper::object_read+0x1b2c2>
 2a09ba1:	mov    0x1b8(%rsp),%rcx
 2a09ba9:	mov    0x190(%rsp),%rsi
 2a09bb1:	mov    0x190(%rsp),%rdi
 2a09bb9:	mov    0x1c0(%rsp),%r8
 2a09bc1:	call   2a1cf20 <wasm[0]::function[1019]::helper::ordinary_own_descriptor>
 2a09bc6:	mov    %rax,%r11
 2a09bc9:	mov    0x78(%rsp),%eax
 2a09bcd:	mov    %rax,%r15
 2a09bd0:	mov    0x58(%rsp),%ecx
 2a09bd4:	mov    0xa8(%rsp),%edx
 2a09bdb:	mov    0xb8(%rsp),%edi
 2a09be2:	mov    0x48(%rsp),%r8d
 2a09be7:	mov    0x80(%rsp),%esi
 2a09bee:	mov    %r11,%rax
 2a09bf1:	test   %eax,%eax
 2a09bf3:	jne    2a0bf6a <wasm[0]::function[1015]::helper::object_read+0xde0a>
 2a09bf9:	xor    %r9d,%r9d
 2a09bfc:	mov    0x1b8(%rsp),%r10
 2a09c04:	cmp    $0x4,%r10d
 2a09c08:	je     2a09c16 <wasm[0]::function[1015]::helper::object_read+0xbab6>
 2a09c0e:	mov    %r8,%r10
 2a09c11:	jmp    2a09fcf <wasm[0]::function[1015]::helper::object_read+0xbe6f>
 2a09c16:	xor    %r9d,%r9d
 2a09c19:	test   %esi,%esi
 2a09c1b:	je     2a09c70 <wasm[0]::function[1015]::helper::object_read+0xbb10>
 2a09c21:	xor    %r9d,%r9d
 2a09c24:	test   $0x1,%esi
 2a09c2a:	jne    2a09c70 <wasm[0]::function[1015]::helper::object_read+0xbb10>
 2a09c30:	mov    0x2e0(%rsp),%r14
 2a09c38:	mov    0x28(%r14),%r9
 2a09c3c:	mov    0x20(%r14),%r10
 2a09c40:	mov    %esi,%r11d
 2a09c43:	lea    0x4(%r10,%r11,1),%r10
 2a09c48:	xor    %rbx,%rbx
 2a09c4b:	cmp    %r9,%r11
 2a09c4e:	cmova  %rbx,%r10
 2a09c52:	mov    (%r10),%r9d
 2a09c55:	mov    0x190(%rsp),%r10
 2a09c5d:	mov    0x28(%r10),%r10
 2a09c61:	cmp    0x234(%r10),%r9d
 2a09c68:	sete   %r9b
 2a09c6c:	movzbl %r9b,%r9d
 2a09c70:	test   %r9d,%r9d
 2a09c73:	je     2a19424 <wasm[0]::function[1015]::helper::object_read+0x1b2c4>
 2a09c79:	test   %esi,%esi
 2a09c7b:	je     2a19426 <wasm[0]::function[1015]::helper::object_read+0x1b2c6>
 2a09c81:	test   %esi,%esi
 2a09c83:	je     2a19428 <wasm[0]::function[1015]::helper::object_read+0x1b2c8>
 2a09c89:	mov    0x2e0(%rsp),%r14
 2a09c91:	mov    0x28(%r14),%r10
 2a09c95:	mov    0x20(%r14),%r11
 2a09c99:	mov    %esi,%r12d
 2a09c9c:	lea    (%r11,%r12,1),%r9
 2a09ca0:	xor    %rbx,%rbx
 2a09ca3:	cmp    %r10,%r12
 2a09ca6:	cmova  %rbx,%r9
 2a09caa:	mov    0x10(%r9),%r12d
 2a09cae:	mov    %r12d,0xb0(%rsp)
 2a09cb6:	xor    %r9d,%r9d
 2a09cb9:	test   %r12d,%r12d
 2a09cbc:	je     2a1942a <wasm[0]::function[1015]::helper::object_read+0x1b2ca>
 2a09cc2:	test   %r12d,%r12d
 2a09cc5:	je     2a1942c <wasm[0]::function[1015]::helper::object_read+0x1b2cc>
 2a09ccb:	mov    %r12d,%r12d
 2a09cce:	lea    0x10(%r11,%r12,1),%r11
 2a09cd3:	cmp    %r10,%r12
 2a09cd6:	cmova  %rbx,%r11
 2a09cda:	mov    (%r11),%ebx
 2a09cdd:	test   %ebx,%ebx
 2a09cdf:	sete   %r10b
 2a09ce3:	cmp    $0xa,%ebx
 2a09ce6:	seta   %r11b
 2a09cea:	or     %r11d,%r10d
 2a09ced:	test   %r10b,%r10b
 2a09cf0:	je     2a09cfe <wasm[0]::function[1015]::helper::object_read+0xbb9e>
 2a09cf6:	mov    %r8,%r10
 2a09cf9:	jmp    2a09fcf <wasm[0]::function[1015]::helper::object_read+0xbe6f>
 2a09cfe:	mov    0xb0(%rsp),%ecx
 2a09d05:	test   %ecx,%ecx
 2a09d07:	je     2a1942e <wasm[0]::function[1015]::helper::object_read+0x1b2ce>
 2a09d0d:	test   %ecx,%ecx
 2a09d0f:	je     2a19430 <wasm[0]::function[1015]::helper::object_read+0x1b2d0>
 2a09d15:	mov    0x2e0(%rsp),%r14
 2a09d1d:	mov    0x28(%r14),%rdx
 2a09d21:	mov    0x20(%r14),%rsi
 2a09d25:	mov    %ecx,%r9d
 2a09d28:	lea    0x10(%rsi,%r9,1),%r8
 2a09d2d:	xor    %rdi,%rdi
 2a09d30:	cmp    %rdx,%r9
 2a09d33:	cmova  %rdi,%r8
 2a09d37:	mov    (%r8),%r8d
 2a09d3a:	test   %r8d,%r8d
 2a09d3d:	je     2a19432 <wasm[0]::function[1015]::helper::object_read+0x1b2d2>
 2a09d43:	mov    %r8d,%r9d
 2a09d46:	shl    $1,%r9
 2a09d49:	shr    $0x20,%r9
 2a09d4d:	test   %r9,%r9
 2a09d50:	jne    2a19434 <wasm[0]::function[1015]::helper::object_read+0x1b2d4>
 2a09d56:	add    %r8d,%r8d
 2a09d59:	add    $0x14,%r8d
 2a09d5d:	jb     2a19436 <wasm[0]::function[1015]::helper::object_read+0x1b2d6>
 2a09d63:	add    %r8d,%ecx
 2a09d66:	jb     2a19438 <wasm[0]::function[1015]::helper::object_read+0x1b2d8>
 2a09d6c:	mov    %ecx,%r9d
 2a09d6f:	add    %r9,%rsi
 2a09d72:	cmp    %rdx,%r9
 2a09d75:	cmova  %rdi,%rsi
 2a09d79:	sub    $0x14,%r8d
 2a09d7d:	sub    %r8,%rsi
 2a09d80:	movzwl (%rsi),%r9d
 2a09d84:	cmp    $0x30,%r9d
 2a09d88:	je     2a09f86 <wasm[0]::function[1015]::helper::object_read+0xbe26>
 2a09d8e:	mov    0x48(%rsp),%r10d
 2a09d93:	mov    0x80(%rsp),%esi
 2a09d9a:	mov    0x78(%rsp),%r9d
 2a09d9f:	mov    %r9,%r15
 2a09da2:	mov    0x58(%rsp),%ecx
 2a09da6:	mov    0xa8(%rsp),%edx
 2a09dad:	mov    0xb8(%rsp),%edi
 2a09db4:	xor    %r13d,%r13d
 2a09db7:	xor    %r12,%r12
 2a09dba:	mov    %r10,%r8
 2a09dbd:	mov    %r10d,0x138(%rsp)
 2a09dc5:	mov    %esi,0x110(%rsp)
 2a09dcc:	mov    %eax,0xd8(%rsp)
 2a09dd3:	mov    %r15,%rax
 2a09dd6:	mov    %eax,0xc8(%rsp)
 2a09ddd:	mov    %ecx,0x100(%rsp)
 2a09de4:	mov    %edx,0x108(%rsp)
 2a09deb:	mov    %edi,0x118(%rsp)
 2a09df2:	mov    %r8d,0xa0(%rsp)
 2a09dfa:	mov    0x2e8(%rsp),%r15
 2a09e02:	mov    (%r15),%rax
 2a09e05:	mov    0x228(%rsp),%rcx
 2a09e0d:	cmp    %rcx,%rax
 2a09e10:	jae    2a17f75 <wasm[0]::function[1015]::helper::object_read+0x19e15>
 2a09e16:	mov    0xb0(%rsp),%r11d
 2a09e1e:	xor    %r9d,%r9d
 2a09e21:	test   %r11d,%r11d
 2a09e24:	je     2a1943a <wasm[0]::function[1015]::helper::object_read+0x1b2da>
 2a09e2a:	test   %r11d,%r11d
 2a09e2d:	je     2a1943c <wasm[0]::function[1015]::helper::object_read+0x1b2dc>
 2a09e33:	mov    0x2e0(%rsp),%r14
 2a09e3b:	mov    0x28(%r14),%rax
 2a09e3f:	mov    0x20(%r14),%rcx
 2a09e43:	mov    %r11d,%edi
 2a09e46:	lea    0x10(%rcx,%rdi,1),%rsi
 2a09e4b:	xor    %rdx,%rdx
 2a09e4e:	cmp    %rax,%rdi
 2a09e51:	cmova  %rdx,%rsi
 2a09e55:	mov    (%rsi),%esi
 2a09e57:	cmp    %esi,%r13d
 2a09e5a:	jae    2a1943e <wasm[0]::function[1015]::helper::object_read+0x1b2de>
 2a09e60:	mov    %esi,%edi
 2a09e62:	shl    $1,%rdi
 2a09e65:	shr    $0x20,%rdi
 2a09e69:	test   %rdi,%rdi
 2a09e6c:	jne    2a19440 <wasm[0]::function[1015]::helper::object_read+0x1b2e0>
 2a09e72:	add    %esi,%esi
 2a09e74:	add    $0x14,%esi
 2a09e77:	jb     2a19442 <wasm[0]::function[1015]::helper::object_read+0x1b2e2>
 2a09e7d:	add    %esi,%r11d
 2a09e80:	jb     2a19444 <wasm[0]::function[1015]::helper::object_read+0x1b2e4>
 2a09e86:	mov    %r11d,%edi
 2a09e89:	add    %rdi,%rcx
 2a09e8c:	cmp    %rax,%rdi
 2a09e8f:	cmova  %rdx,%rcx
 2a09e93:	lea    0x14(%r13,%r13,1),%eax
 2a09e98:	sub    %eax,%esi
 2a09e9a:	sub    %rsi,%rcx
 2a09e9d:	movzwq (%rcx),%r11
 2a09ea1:	mov    0x138(%rsp),%r10d
 2a09ea9:	mov    0x110(%rsp),%esi
 2a09eb0:	mov    0xd8(%rsp),%eax
 2a09eb7:	mov    0xc8(%rsp),%ecx
 2a09ebe:	mov    %rcx,%r15
 2a09ec1:	mov    0x100(%rsp),%ecx
 2a09ec8:	mov    0x108(%rsp),%edx
 2a09ecf:	mov    0x118(%rsp),%edi
 2a09ed6:	mov    0xa0(%rsp),%r8d
 2a09ede:	movzwl %r11w,%r11d
 2a09ee2:	mov    %r11,%r14
 2a09ee5:	sub    $0x30,%r14d
 2a09ee9:	cmp    $0x9,%r14d
 2a09eed:	ja     2a09fcf <wasm[0]::function[1015]::helper::object_read+0xbe6f>
 2a09ef3:	mov    0x138(%rsp),%r10d
 2a09efb:	mov    0x110(%rsp),%esi
 2a09f02:	mov    0xd8(%rsp),%eax
 2a09f09:	mov    0xc8(%rsp),%ecx
 2a09f10:	mov    %rcx,%r15
 2a09f13:	mov    0x100(%rsp),%ecx
 2a09f1a:	mov    0x108(%rsp),%edx
 2a09f21:	mov    0x118(%rsp),%edi
 2a09f28:	mov    0xa0(%rsp),%r8d
 2a09f30:	add    $0x1,%r13d
 2a09f37:	imul   $0xa,%r12,%r9
 2a09f3b:	mov    %r11,%r14
 2a09f3e:	sub    $0x30,%r14d
 2a09f42:	add    %r9,%r14
 2a09f45:	cmp    %ebx,%r13d
 2a09f48:	jae    2a09f56 <wasm[0]::function[1015]::helper::object_read+0xbdf6>
 2a09f4e:	mov    %r14,%r12
 2a09f51:	jmp    2a09dbd <wasm[0]::function[1015]::helper::object_read+0xbc5d>
 2a09f56:	xor    %r9d,%r9d
 2a09f59:	cmp    0xfc78(%rip),%r14        # 2a19bd8 <wasm[0]::function[1015]::helper::object_read+0x1ba78>
 2a09f60:	jae    2a09fcf <wasm[0]::function[1015]::helper::object_read+0xbe6f>
 2a09f66:	imul   $0xa,%r12d,%r9d
 2a09f6a:	sub    $0x30,%r11d
 2a09f6e:	add    %r11d,%r9d
 2a09f71:	mov    %r9,0x200(%rsp)
 2a09f79:	mov    0x278(%rsp),%r9
 2a09f81:	jmp    2a09fcf <wasm[0]::function[1015]::helper::object_read+0xbe6f>
 2a09f86:	mov    0x48(%rsp),%r10d
 2a09f8b:	mov    0x80(%rsp),%esi
 2a09f92:	mov    0x78(%rsp),%ecx
 2a09f96:	mov    %rcx,%r15
 2a09f99:	mov    0x58(%rsp),%ecx
 2a09f9d:	mov    0xa8(%rsp),%edx
 2a09fa4:	mov    0xb8(%rsp),%edi
 2a09fab:	cmp    $0x1,%ebx
 2a09fae:	sete   %r8b
 2a09fb2:	movzbl %r8b,%r9d
 2a09fb6:	mov    %r8,%r11
 2a09fb9:	mov    %r8,0x200(%rsp)
 2a09fc1:	xor    %r11d,%r8d
 2a09fc4:	mov    %r8,0x200(%rsp)
 2a09fcc:	mov    %r10,%r8
 2a09fcf:	mov    %r10d,0xa0(%rsp)
 2a09fd7:	mov    %esi,0x118(%rsp)
 2a09fde:	mov    %eax,0x108(%rsp)
 2a09fe5:	mov    %r15,%rax
 2a09fe8:	mov    %eax,0x100(%rsp)
 2a09fef:	mov    %ecx,0xc8(%rsp)
 2a09ff6:	mov    %edx,0xd8(%rsp)
 2a09ffd:	mov    %edi,0x110(%rsp)
 2a0a004:	mov    %r8d,0x138(%rsp)
 2a0a00c:	test   %r9d,%r9d
 2a0a00f:	jne    2a0a999 <wasm[0]::function[1015]::helper::object_read+0xc839>
 2a0a015:	mov    $0x8c,%edx
 2a0a01a:	mov    0x190(%rsp),%rsi
 2a0a022:	mov    0x190(%rsp),%rdi
 2a0a02a:	call   2f4f240 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 2a0a02f:	test   %eax,%eax
 2a0a031:	je     2a19446 <wasm[0]::function[1015]::helper::object_read+0x1b2e6>
 2a0a037:	mov    0x1b8(%rsp),%rcx
 2a0a03f:	cmp    $0x4,%ecx
 2a0a042:	je     2a0a093 <wasm[0]::function[1015]::helper::object_read+0xbf33>
 2a0a048:	mov    0xa0(%rsp),%ecx
 2a0a04f:	mov    0x108(%rsp),%eax
 2a0a056:	mov    %rax,%r11
 2a0a059:	mov    0x100(%rsp),%esi
 2a0a060:	mov    0xc8(%rsp),%edi
 2a0a067:	mov    0xd8(%rsp),%r8d
 2a0a06f:	mov    0x110(%rsp),%r9d
 2a0a077:	mov    0x138(%rsp),%r10d
 2a0a07f:	mov    0x118(%rsp),%edx
 2a0a086:	xor    %eax,%eax
 2a0a088:	mov    %rax,%r13
 2a0a08b:	mov    %r11,%rax
 2a0a08e:	jmp    2a0a762 <wasm[0]::function[1015]::helper::object_read+0xc602>
 2a0a093:	mov    0x1b8(%rsp),%rcx
 2a0a09b:	cmp    $0x3,%ecx
 2a0a09e:	je     2a0a6d9 <wasm[0]::function[1015]::helper::object_read+0xc579>
 2a0a0a4:	mov    0x1b8(%rsp),%rcx
 2a0a0ac:	cmp    $0x4,%ecx
 2a0a0af:	je     2a0a586 <wasm[0]::function[1015]::helper::object_read+0xc426>
 2a0a0b5:	mov    0x1b8(%rsp),%rcx
 2a0a0bd:	cmp    $0xa,%ecx
 2a0a0c0:	je     2a0a17f <wasm[0]::function[1015]::helper::object_read+0xc01f>
 2a0a0c6:	mov    0x1b8(%rsp),%rcx
 2a0a0ce:	mov    0x1b8(%rsp),%rdx
 2a0a0d6:	test   %edx,%ecx
 2a0a0d8:	sete   %r11b
 2a0a0dc:	cmp    $0x1,%ecx
 2a0a0df:	sete   %cl
 2a0a0e2:	or     %ecx,%r11d
 2a0a0e5:	test   %r11b,%r11b
 2a0a0e8:	jne    2a0a137 <wasm[0]::function[1015]::helper::object_read+0xbfd7>
 2a0a0ee:	mov    0x1b8(%rsp),%rcx
 2a0a0f6:	cmp    $0x2,%ecx
 2a0a0f9:	je     2a0a116 <wasm[0]::function[1015]::helper::object_read+0xbfb6>
 2a0a0ff:	mov    0x118(%rsp),%ecx
 2a0a106:	cmp    %eax,%ecx
 2a0a108:	sete   %al
 2a0a10b:	movzbl %al,%eax
 2a0a10e:	mov    %rax,%r13
 2a0a111:	jmp    2a0a13f <wasm[0]::function[1015]::helper::object_read+0xbfdf>
 2a0a116:	mov    0x1c0(%rsp),%r8
 2a0a11e:	mov    0x1c0(%rsp),%r9
 2a0a126:	test   %r9,%r8
 2a0a129:	sete   %al
 2a0a12c:	movzbl %al,%eax
 2a0a12f:	mov    %rax,%r13
 2a0a132:	jmp    2a0a13f <wasm[0]::function[1015]::helper::object_read+0xbfdf>
 2a0a137:	mov    0x278(%rsp),%r13
 2a0a13f:	mov    0xa0(%rsp),%ecx
 2a0a146:	mov    0x108(%rsp),%eax
 2a0a14d:	mov    0x100(%rsp),%esi
 2a0a154:	mov    0xc8(%rsp),%edi
 2a0a15b:	mov    0xd8(%rsp),%r8d
 2a0a163:	mov    0x110(%rsp),%r9d
 2a0a16b:	mov    0x138(%rsp),%r10d
 2a0a173:	mov    0x118(%rsp),%edx
 2a0a17a:	jmp    2a0a762 <wasm[0]::function[1015]::helper::object_read+0xc602>
 2a0a17f:	mov    0x118(%rsp),%edx
 2a0a186:	xor    %ecx,%ecx
 2a0a188:	test   %edx,%edx
 2a0a18a:	je     2a0a1d9 <wasm[0]::function[1015]::helper::object_read+0xc079>
 2a0a190:	xor    %ecx,%ecx
 2a0a192:	test   $0x1,%edx
 2a0a198:	jne    2a0a1d9 <wasm[0]::function[1015]::helper::object_read+0xc079>
 2a0a19e:	mov    0x2e0(%rsp),%r14
 2a0a1a6:	mov    0x28(%r14),%rcx
 2a0a1aa:	mov    0x20(%r14),%rdi
 2a0a1ae:	mov    %edx,%esi
 2a0a1b0:	lea    0x4(%rdi,%rsi,1),%rdx
 2a0a1b5:	xor    %rdi,%rdi
 2a0a1b8:	cmp    %rcx,%rsi
 2a0a1bb:	cmova  %rdi,%rdx
 2a0a1bf:	mov    (%rdx),%ecx
 2a0a1c1:	mov    0x190(%rsp),%rdx
 2a0a1c9:	mov    0x28(%rdx),%rdx
 2a0a1cd:	cmp    0x23c(%rdx),%ecx
 2a0a1d3:	sete   %cl
 2a0a1d6:	movzbl %cl,%ecx
 2a0a1d9:	test   %ecx,%ecx
 2a0a1db:	je     2a19448 <wasm[0]::function[1015]::helper::object_read+0x1b2e8>
 2a0a1e1:	xor    %ecx,%ecx
 2a0a1e3:	test   %eax,%eax
 2a0a1e5:	je     2a0a233 <wasm[0]::function[1015]::helper::object_read+0xc0d3>
 2a0a1eb:	xor    %ecx,%ecx
 2a0a1ed:	test   $0x1,%eax
 2a0a1f2:	jne    2a0a233 <wasm[0]::function[1015]::helper::object_read+0xc0d3>
 2a0a1f8:	mov    0x2e0(%rsp),%r14
 2a0a200:	mov    0x28(%r14),%rcx
 2a0a204:	mov    0x20(%r14),%rdx
 2a0a208:	mov    %eax,%esi
 2a0a20a:	lea    0x4(%rdx,%rsi,1),%rdx
 2a0a20f:	xor    %rdi,%rdi
 2a0a212:	cmp    %rcx,%rsi
 2a0a215:	cmova  %rdi,%rdx
 2a0a219:	mov    (%rdx),%ecx
 2a0a21b:	mov    0x190(%rsp),%r10
 2a0a223:	mov    0x28(%r10),%rdx
 2a0a227:	cmp    0x23c(%rdx),%ecx
 2a0a22d:	sete   %cl
 2a0a230:	movzbl %cl,%ecx
 2a0a233:	test   %ecx,%ecx
 2a0a235:	je     2a1944a <wasm[0]::function[1015]::helper::object_read+0x1b2ea>
 2a0a23b:	mov    0x118(%rsp),%edx
 2a0a242:	test   %edx,%edx
 2a0a244:	je     2a1944c <wasm[0]::function[1015]::helper::object_read+0x1b2ec>
 2a0a24a:	test   %edx,%edx
 2a0a24c:	je     2a1944e <wasm[0]::function[1015]::helper::object_read+0x1b2ee>
 2a0a252:	mov    0x2e0(%rsp),%r14
 2a0a25a:	mov    0x28(%r14),%rcx
 2a0a25e:	mov    0x20(%r14),%rsi
 2a0a262:	mov    %edx,%r9d
 2a0a265:	lea    (%rsi,%r9,1),%r8
 2a0a269:	xor    %rdi,%rdi
 2a0a26c:	cmp    %rcx,%r9
 2a0a26f:	cmova  %rdi,%r8
 2a0a273:	mov    0x10(%r8),%r11d
 2a0a277:	test   %eax,%eax
 2a0a279:	je     2a19450 <wasm[0]::function[1015]::helper::object_read+0x1b2f0>
 2a0a27f:	mov    %eax,%r9d
 2a0a282:	lea    (%rsi,%r9,1),%rax
 2a0a286:	cmp    %rcx,%r9
 2a0a289:	cmova  %rdi,%rax
 2a0a28d:	mov    0x10(%rax),%r12d
 2a0a291:	mov    0x14(%r8),%r8d
 2a0a295:	mov    %r8d,0xb0(%rsp)
 2a0a29d:	mov    0x14(%rax),%eax
 2a0a2a0:	mov    %eax,0x130(%rsp)
 2a0a2a7:	test   %r8d,%r8d
 2a0a2aa:	je     2a19452 <wasm[0]::function[1015]::helper::object_read+0x1b2f2>
 2a0a2b0:	test   %r8d,%r8d
 2a0a2b3:	je     2a19454 <wasm[0]::function[1015]::helper::object_read+0x1b2f4>
 2a0a2b9:	mov    %r8d,%r9d
 2a0a2bc:	lea    0x10(%rsi,%r9,1),%r8
 2a0a2c1:	cmp    %rcx,%r9
 2a0a2c4:	cmova  %rdi,%r8
 2a0a2c8:	mov    (%r8),%ebx
 2a0a2cb:	test   %eax,%eax
 2a0a2cd:	je     2a19456 <wasm[0]::function[1015]::helper::object_read+0x1b2f6>
 2a0a2d3:	test   %eax,%eax
 2a0a2d5:	je     2a19458 <wasm[0]::function[1015]::helper::object_read+0x1b2f8>
 2a0a2db:	mov    %eax,%r8d
 2a0a2de:	lea    0x10(%rsi,%r8,1),%rsi
 2a0a2e3:	cmp    %rcx,%r8
 2a0a2e6:	cmova  %rdi,%rsi
 2a0a2ea:	mov    (%rsi),%r13d
 2a0a2ed:	mov    0xa0(%rsp),%ecx
 2a0a2f4:	mov    0x108(%rsp),%eax
 2a0a2fb:	mov    0x100(%rsp),%esi
 2a0a302:	mov    0xc8(%rsp),%edi
 2a0a309:	mov    0xd8(%rsp),%r8d
 2a0a311:	mov    0x110(%rsp),%r9d
 2a0a319:	mov    0x138(%rsp),%r10d
 2a0a321:	cmp    %r12d,%r11d
 2a0a324:	sete   %r11b
 2a0a328:	cmp    %r13d,%ebx
 2a0a32b:	sete   %r12b
 2a0a32f:	mov    %r11,%r13
 2a0a332:	and    %r12d,%r13d
 2a0a335:	movzbl %r13b,%r13d
 2a0a339:	test   %r11b,%r12b
 2a0a33c:	je     2a0a762 <wasm[0]::function[1015]::helper::object_read+0xc602>
 2a0a342:	mov    0xa0(%rsp),%esi
 2a0a349:	mov    0x108(%rsp),%edi
 2a0a350:	mov    0x100(%rsp),%r8d
 2a0a358:	mov    0xc8(%rsp),%r9d
 2a0a360:	mov    0xd8(%rsp),%r11d
 2a0a368:	mov    0x110(%rsp),%ecx
 2a0a36f:	mov    0x138(%rsp),%edx
 2a0a376:	mov    0x118(%rsp),%r10d
 2a0a37e:	xor    %r12d,%r12d
 2a0a381:	mov    %esi,0xe0(%rsp)
 2a0a388:	mov    %edi,0x98(%rsp)
 2a0a38f:	mov    %r8d,0xc0(%rsp)
 2a0a397:	mov    %r9d,0x90(%rsp)
 2a0a39f:	mov    %r11d,0x128(%rsp)
 2a0a3a7:	mov    %ecx,0x120(%rsp)
 2a0a3ae:	mov    %edx,0x88(%rsp)
 2a0a3b5:	mov    %r10d,0xf8(%rsp)
 2a0a3bd:	mov    0x2e8(%rsp),%r15
 2a0a3c5:	mov    (%r15),%rcx
 2a0a3c8:	mov    0x228(%rsp),%rax
 2a0a3d0:	cmp    %rax,%rcx
 2a0a3d3:	jae    2a17fac <wasm[0]::function[1015]::helper::object_read+0x19e4c>
 2a0a3d9:	cmp    %ebx,%r12d
 2a0a3dc:	jae    2a0a546 <wasm[0]::function[1015]::helper::object_read+0xc3e6>
 2a0a3e2:	mov    0xb0(%rsp),%edi
 2a0a3e9:	test   %edi,%edi
 2a0a3eb:	je     2a1945a <wasm[0]::function[1015]::helper::object_read+0x1b2fa>
 2a0a3f1:	test   %edi,%edi
 2a0a3f3:	je     2a1945c <wasm[0]::function[1015]::helper::object_read+0x1b2fc>
 2a0a3f9:	mov    0x2e0(%rsp),%r14
 2a0a401:	mov    0x28(%r14),%rcx
 2a0a405:	mov    0x20(%r14),%rdx
 2a0a409:	mov    %edi,%r9d
 2a0a40c:	lea    0x10(%rdx,%r9,1),%r8
 2a0a411:	xor    %rsi,%rsi
 2a0a414:	cmp    %rcx,%r9
 2a0a417:	cmova  %rsi,%r8
 2a0a41b:	mov    (%r8),%r9d
 2a0a41e:	cmp    %r9d,%r12d
 2a0a421:	jae    2a1945e <wasm[0]::function[1015]::helper::object_read+0x1b2fe>
 2a0a427:	mov    %r9d,%r8d
 2a0a42a:	shl    $0x3,%r8
 2a0a42e:	shr    $0x20,%r8
 2a0a432:	test   %r8,%r8
 2a0a435:	jne    2a19460 <wasm[0]::function[1015]::helper::object_read+0x1b300>
 2a0a43b:	shl    $0x3,%r9d
 2a0a43f:	add    $0x18,%r9d
 2a0a443:	jb     2a19462 <wasm[0]::function[1015]::helper::object_read+0x1b302>
 2a0a449:	add    %r9d,%edi
 2a0a44c:	jb     2a19464 <wasm[0]::function[1015]::helper::object_read+0x1b304>
 2a0a452:	mov    %edi,%r8d
 2a0a455:	lea    (%rdx,%r8,1),%rdi
 2a0a459:	cmp    %rcx,%r8
 2a0a45c:	cmova  %rsi,%rdi
 2a0a460:	mov    %r12,%rax
 2a0a463:	shl    $0x3,%eax
 2a0a466:	lea    0x18(%rax),%r8d
 2a0a46a:	sub    %r8d,%r9d
 2a0a46d:	sub    %r9,%rdi
 2a0a470:	mov    (%rdi),%rdi
 2a0a473:	mov    0x130(%rsp),%r9d
 2a0a47b:	test   %r9d,%r9d
 2a0a47e:	je     2a19466 <wasm[0]::function[1015]::helper::object_read+0x1b306>
 2a0a484:	test   %r9d,%r9d
 2a0a487:	je     2a19468 <wasm[0]::function[1015]::helper::object_read+0x1b308>
 2a0a48d:	mov    %r9d,%r11d
 2a0a490:	lea    0x10(%rdx,%r11,1),%r10
 2a0a495:	cmp    %rcx,%r11
 2a0a498:	cmova  %rsi,%r10
 2a0a49c:	mov    (%r10),%r10d
 2a0a49f:	cmp    %r10d,%r12d
 2a0a4a2:	jae    2a1946a <wasm[0]::function[1015]::helper::object_read+0x1b30a>
 2a0a4a8:	mov    %r10d,%r11d
 2a0a4ab:	shl    $0x3,%r11
 2a0a4af:	shr    $0x20,%r11
 2a0a4b3:	test   %r11,%r11
 2a0a4b6:	jne    2a1946c <wasm[0]::function[1015]::helper::object_read+0x1b30c>
 2a0a4bc:	shl    $0x3,%r10d
 2a0a4c0:	add    $0x18,%r10d
 2a0a4c4:	jb     2a1946e <wasm[0]::function[1015]::helper::object_read+0x1b30e>
 2a0a4ca:	add    %r10d,%r9d
 2a0a4cd:	jb     2a19470 <wasm[0]::function[1015]::helper::object_read+0x1b310>
 2a0a4d3:	mov    %r9d,%r9d
 2a0a4d6:	add    %r9,%rdx
 2a0a4d9:	cmp    %rcx,%r9
 2a0a4dc:	cmova  %rsi,%rdx
 2a0a4e0:	sub    %r8d,%r10d
 2a0a4e3:	sub    %r10,%rdx
 2a0a4e6:	mov    (%rdx),%rcx
 2a0a4e9:	cmp    %rcx,%rdi
 2a0a4ec:	sete   %al
 2a0a4ef:	movzbl %al,%edx
 2a0a4f2:	mov    %rdx,%r13
 2a0a4f5:	cmp    %rcx,%rdi
 2a0a4f8:	jne    2a0a546 <wasm[0]::function[1015]::helper::object_read+0xc3e6>
 2a0a4fe:	mov    0xe0(%rsp),%esi
 2a0a505:	mov    0x98(%rsp),%edi
 2a0a50c:	mov    0xc0(%rsp),%r8d
 2a0a514:	mov    0x90(%rsp),%r9d
 2a0a51c:	mov    0x128(%rsp),%r11d
 2a0a524:	mov    0x120(%rsp),%ecx
 2a0a52b:	mov    0x88(%rsp),%edx
 2a0a532:	mov    0xf8(%rsp),%r10d
 2a0a53a:	add    $0x1,%r12d
 2a0a541:	jmp    2a0a381 <wasm[0]::function[1015]::helper::object_read+0xc221>
 2a0a546:	mov    0xe0(%rsp),%ecx
 2a0a54d:	mov    0x98(%rsp),%eax
 2a0a554:	mov    0xc0(%rsp),%esi
 2a0a55b:	mov    0x90(%rsp),%edi
 2a0a562:	mov    0x128(%rsp),%r8d
 2a0a56a:	mov    0x120(%rsp),%r9d
 2a0a572:	mov    0x88(%rsp),%r10d
 2a0a57a:	mov    0xf8(%rsp),%edx
 2a0a581:	jmp    2a0a762 <wasm[0]::function[1015]::helper::object_read+0xc602>
 2a0a586:	mov    0x118(%rsp),%ecx
 2a0a58d:	cmp    %eax,%ecx
 2a0a58f:	je     2a0a691 <wasm[0]::function[1015]::helper::object_read+0xc531>
 2a0a595:	xor    %edx,%edx
 2a0a597:	test   %ecx,%ecx
 2a0a599:	je     2a0a5ea <wasm[0]::function[1015]::helper::object_read+0xc48a>
 2a0a59f:	xor    %edx,%edx
 2a0a5a1:	test   $0x1,%ecx
 2a0a5a7:	jne    2a0a5ea <wasm[0]::function[1015]::helper::object_read+0xc48a>
 2a0a5ad:	mov    0x2e0(%rsp),%r14
 2a0a5b5:	mov    0x28(%r14),%rsi
 2a0a5b9:	mov    0x20(%r14),%r8
 2a0a5bd:	mov    %ecx,%edi
 2a0a5bf:	lea    0x4(%r8,%rdi,1),%rdx
 2a0a5c4:	xor    %r8,%r8
 2a0a5c7:	cmp    %rsi,%rdi
 2a0a5ca:	cmova  %r8,%rdx
 2a0a5ce:	mov    (%rdx),%esi
 2a0a5d0:	mov    0x190(%rsp),%rcx
 2a0a5d8:	mov    0x28(%rcx),%rdi
 2a0a5dc:	cmp    0x234(%rdi),%esi
 2a0a5e2:	sete   %dil
 2a0a5e6:	movzbl %dil,%edx
 2a0a5ea:	test   %edx,%edx
 2a0a5ec:	je     2a19472 <wasm[0]::function[1015]::helper::object_read+0x1b312>
 2a0a5f2:	xor    %ecx,%ecx
 2a0a5f4:	test   %eax,%eax
 2a0a5f6:	jne    2a0a604 <wasm[0]::function[1015]::helper::object_read+0xc4a4>
 2a0a5fc:	mov    %rax,%rdi
 2a0a5ff:	jmp    2a0a657 <wasm[0]::function[1015]::helper::object_read+0xc4f7>
 2a0a604:	xor    %ecx,%ecx
 2a0a606:	test   $0x1,%eax
 2a0a60b:	je     2a0a619 <wasm[0]::function[1015]::helper::object_read+0xc4b9>
 2a0a611:	mov    %rax,%rdi
 2a0a614:	jmp    2a0a657 <wasm[0]::function[1015]::helper::object_read+0xc4f7>
 2a0a619:	mov    0x2e0(%rsp),%r14
 2a0a621:	mov    0x28(%r14),%rcx
 2a0a625:	mov    0x20(%r14),%rsi
 2a0a629:	mov    %eax,%edx
 2a0a62b:	mov    %rax,%rdi
 2a0a62e:	lea    0x4(%rsi,%rdx,1),%rax
 2a0a633:	xor    %rsi,%rsi
 2a0a636:	cmp    %rcx,%rdx
 2a0a639:	cmova  %rsi,%rax
 2a0a63d:	mov    (%rax),%eax
 2a0a63f:	mov    0x190(%rsp),%rcx
 2a0a647:	mov    0x28(%rcx),%rcx
 2a0a64b:	cmp    0x234(%rcx),%eax
 2a0a651:	sete   %al
 2a0a654:	movzbl %al,%ecx
 2a0a657:	test   %ecx,%ecx
 2a0a659:	je     2a19474 <wasm[0]::function[1015]::helper::object_read+0x1b314>
 2a0a65f:	mov    0x118(%rsp),%edx
 2a0a666:	xor    %r8d,%r8d
 2a0a669:	test   %edx,%edx
 2a0a66b:	je     2a19476 <wasm[0]::function[1015]::helper::object_read+0x1b316>
 2a0a671:	mov    %rdi,%rcx
 2a0a674:	mov    0x190(%rsp),%rsi
 2a0a67c:	mov    0x190(%rsp),%rdi
 2a0a684:	call   2b02800 <wasm[0]::function[1057]::helper::string_equality>
 2a0a689:	mov    %rax,%r13
 2a0a68c:	jmp    2a0a699 <wasm[0]::function[1015]::helper::object_read+0xc539>
 2a0a691:	mov    0x278(%rsp),%r13
 2a0a699:	mov    0xa0(%rsp),%ecx
 2a0a6a0:	mov    0x108(%rsp),%eax
 2a0a6a7:	mov    0x100(%rsp),%esi
 2a0a6ae:	mov    0xc8(%rsp),%edi
 2a0a6b5:	mov    0xd8(%rsp),%r8d
 2a0a6bd:	mov    0x110(%rsp),%r9d
 2a0a6c5:	mov    0x138(%rsp),%r10d
 2a0a6cd:	mov    0x118(%rsp),%edx
 2a0a6d4:	jmp    2a0a762 <wasm[0]::function[1015]::helper::object_read+0xc602>
 2a0a6d9:	mov    0xa0(%rsp),%ecx
 2a0a6e0:	mov    0x108(%rsp),%eax
 2a0a6e7:	mov    0x100(%rsp),%esi
 2a0a6ee:	mov    0xc8(%rsp),%edi
 2a0a6f5:	mov    0xd8(%rsp),%r8d
 2a0a6fd:	mov    0x110(%rsp),%r9d
 2a0a705:	mov    0x138(%rsp),%r10d
 2a0a70d:	mov    0x118(%rsp),%edx
 2a0a714:	xor    %r12,%r12
 2a0a717:	mov    0x1c0(%rsp),%rbx
 2a0a71f:	mov    0x1c0(%rsp),%r11
 2a0a727:	test   %rbx,%r11
 2a0a72a:	sete   %r11b
 2a0a72e:	movq   %rbx,%xmm0
 2a0a733:	ucomisd %xmm0,%xmm0
 2a0a737:	setp   %bl
 2a0a73a:	setne  %r13b
 2a0a73e:	or     %r13d,%ebx
 2a0a741:	movq   %r12,%xmm0
 2a0a746:	ucomisd %xmm0,%xmm0
 2a0a74a:	setp   %r12b
 2a0a74e:	setne  %r13b
 2a0a752:	or     %r13d,%r12d
 2a0a755:	and    %r12d,%ebx
 2a0a758:	or     %ebx,%r11d
 2a0a75b:	movzbl %r11b,%r11d
 2a0a75f:	mov    %r11,%r13
 2a0a762:	mov    %esi,0x128(%rsp)
 2a0a769:	mov    %edi,0x90(%rsp)
 2a0a770:	mov    %r8d,0xc0(%rsp)
 2a0a778:	mov    %r9d,0x98(%rsp)
 2a0a780:	mov    %r10d,0xe0(%rsp)
 2a0a788:	mov    %edx,0x108(%rsp)
 2a0a78f:	mov    %r13,%r10
 2a0a792:	mov    %r13,%r11
 2a0a795:	test   %r10d,%r11d
 2a0a798:	je     2a0a965 <wasm[0]::function[1015]::helper::object_read+0xc805>
 2a0a79e:	test   %ecx,%ecx
 2a0a7a0:	je     2a19478 <wasm[0]::function[1015]::helper::object_read+0x1b318>
 2a0a7a6:	test   %ecx,%ecx
 2a0a7a8:	je     2a1947a <wasm[0]::function[1015]::helper::object_read+0x1b31a>
 2a0a7ae:	mov    0x2e0(%rsp),%r14
 2a0a7b6:	mov    0x28(%r14),%rdx
 2a0a7ba:	mov    0x20(%r14),%rax
 2a0a7be:	mov    %ecx,%ecx
 2a0a7c0:	add    %rcx,%rax
 2a0a7c3:	xor    %rsi,%rsi
 2a0a7c6:	cmp    %rdx,%rcx
 2a0a7c9:	cmova  %rsi,%rax
 2a0a7cd:	mov    0x18(%rax),%r14
 2a0a7d1:	movl   $0x0,0x120(%rsp)
 2a0a7dc:	mov    $0x20,%r12d
 2a0a7e2:	mov    0x20(%rax),%ebx
 2a0a7e5:	mov    0x190(%rsp),%rcx
 2a0a7ed:	mov    0x20(%rcx),%r13
 2a0a7f1:	mov    0x0(%r13),%eax
 2a0a7f5:	mov    %eax,%ecx
 2a0a7f7:	lea    0x20(%rcx),%rdx
 2a0a7fb:	mov    0x4(%r13),%esi
 2a0a7ff:	cmp    %rsi,%rdx
 2a0a802:	ja     2a17fe3 <wasm[0]::function[1015]::helper::object_read+0x19e83>
 2a0a808:	lea    0x20(%rax),%edx
 2a0a80b:	mov    %edx,0x0(%r13)
 2a0a80f:	mov    0x2e0(%rsp),%rdx
 2a0a817:	mov    0x20(%rdx),%rdx
 2a0a81b:	lea    (%rdx,%rcx,1),%rdi
 2a0a81f:	movl   $0xb0000042,(%rdx,%rcx,1)
 2a0a826:	mov    0x190(%rsp),%rsi
 2a0a82e:	mov    0x28(%rsi),%rsi
 2a0a832:	mov    0x120(%rsi),%esi
 2a0a838:	mov    %esi,0x4(%rdx,%rcx,1)
 2a0a83c:	mov    %r12d,0x8(%rdx,%rcx,1)
 2a0a841:	mov    %eax,0x88(%rsp)
 2a0a848:	cmp    $0x0,%r14
 2a0a84c:	jl     2a0a85c <wasm[0]::function[1015]::helper::object_read+0xc6fc>
 2a0a852:	cvtsi2sd %r14,%xmm0
 2a0a857:	jmp    2a0a876 <wasm[0]::function[1015]::helper::object_read+0xc716>
 2a0a85c:	mov    %r14,%rdx
 2a0a85f:	shr    $0x1,%rdx
 2a0a863:	mov    %r14,%rcx
 2a0a866:	and    $0x1,%rcx
 2a0a86a:	or     %rdx,%rcx
 2a0a86d:	cvtsi2sd %rcx,%xmm0
 2a0a872:	addsd  %xmm0,%xmm0
 2a0a876:	movq   %xmm0,%rcx
 2a0a87b:	mov    %rcx,0x10(%rdi)
 2a0a87f:	movl   $0x3,0x18(%rdi)
 2a0a886:	mov    0x120(%rsp),%ecx
 2a0a88d:	mov    %ecx,0x1c(%rdi)
 2a0a890:	mov    0x190(%rsp),%rcx
 2a0a898:	mov    0xa20(%rcx),%ecx
 2a0a89e:	mov    %ecx,0x120(%rsp)
 2a0a8a5:	test   %eax,%eax
 2a0a8a7:	je     2a1947c <wasm[0]::function[1015]::helper::object_read+0x1b31c>
 2a0a8ad:	test   %ecx,%ecx
 2a0a8af:	je     2a1947e <wasm[0]::function[1015]::helper::object_read+0x1b31e>
 2a0a8b5:	mov    0x0(%r13),%eax
 2a0a8b9:	mov    %eax,%edx
 2a0a8bb:	lea    0x20(%rdx),%rcx
 2a0a8bf:	mov    0x4(%r13),%esi
 2a0a8c3:	cmp    %rsi,%rcx
 2a0a8c6:	ja     2a18025 <wasm[0]::function[1015]::helper::object_read+0x19ec5>
 2a0a8cc:	lea    0x20(%rax),%esi
 2a0a8cf:	mov    %esi,0x0(%r13)
 2a0a8d3:	mov    0x2e0(%rsp),%r14
 2a0a8db:	mov    0x20(%r14),%rsi
 2a0a8df:	lea    (%rsi,%rdx,1),%rcx
 2a0a8e3:	movl   $0xb0000072,(%rsi,%rdx,1)
 2a0a8ea:	mov    0x190(%rsp),%rdi
 2a0a8f2:	mov    0x28(%rdi),%rdi
 2a0a8f6:	mov    0x13c(%rdi),%edi
 2a0a8fc:	mov    %edi,0x4(%rsi,%rdx,1)
 2a0a900:	mov    %r12d,0x8(%rsi,%rdx,1)
 2a0a905:	movl   $0x4,0x10(%rcx)
 2a0a90c:	mov    0x88(%rsp),%r8d
 2a0a914:	mov    %r8d,0x14(%rcx)
 2a0a918:	mov    0x120(%rsp),%r9d
 2a0a920:	mov    %r9d,0x18(%rcx)
 2a0a924:	mov    %r9d,0x1c(%rcx)
 2a0a928:	test   %eax,%eax
 2a0a92a:	je     2a19480 <wasm[0]::function[1015]::helper::object_read+0x1b320>
 2a0a930:	test   %eax,%eax
 2a0a932:	je     2a19482 <wasm[0]::function[1015]::helper::object_read+0x1b322>
 2a0a938:	mov    0x2e0(%rsp),%r14
 2a0a940:	mov    0x28(%r14),%rcx
 2a0a944:	test   %ebx,%ebx
 2a0a946:	setne  %dl
 2a0a949:	movzbl %dl,%edx
 2a0a94c:	shl    $0x2,%edx
 2a0a94f:	mov    %eax,%edi
 2a0a951:	mov    %rdi,%rsi
 2a0a954:	add    0x20(%r14),%rsi
 2a0a958:	xor    %r8,%r8
 2a0a95b:	cmp    %rcx,%rdi
 2a0a95e:	cmova  %r8,%rsi
 2a0a962:	mov    %edx,0x10(%rsi)
 2a0a965:	mov    0x128(%rsp),%r11d
 2a0a96d:	mov    %r11,%r15
 2a0a970:	mov    0x90(%rsp),%ecx
 2a0a977:	mov    0xc0(%rsp),%edx
 2a0a97e:	mov    0x98(%rsp),%edi
 2a0a985:	mov    0xe0(%rsp),%r8d
 2a0a98d:	mov    0x108(%rsp),%esi
 2a0a994:	jmp    2a0bf6a <wasm[0]::function[1015]::helper::object_read+0xde0a>
 2a0a999:	test   %r10d,%r10d
 2a0a99c:	je     2a19484 <wasm[0]::function[1015]::helper::object_read+0x1b324>
 2a0a9a2:	test   %r10d,%r10d
 2a0a9a5:	je     2a19486 <wasm[0]::function[1015]::helper::object_read+0x1b326>
 2a0a9ab:	mov    0x2e0(%rsp),%r14
 2a0a9b3:	mov    0x28(%r14),%r9
 2a0a9b7:	mov    0x20(%r14),%r11
 2a0a9bb:	mov    %r10d,%ebx
 2a0a9be:	lea    (%r11,%rbx,1),%rax
 2a0a9c2:	xor    %r10,%r10
 2a0a9c5:	cmp    %r9,%rbx
 2a0a9c8:	cmova  %r10,%rax
 2a0a9cc:	mov    0x14(%rax),%eax
 2a0a9cf:	mov    %eax,0xa0(%rsp)
 2a0a9d6:	test   %eax,%eax
 2a0a9d8:	je     2a19488 <wasm[0]::function[1015]::helper::object_read+0x1b328>
 2a0a9de:	test   %eax,%eax
 2a0a9e0:	je     2a1948a <wasm[0]::function[1015]::helper::object_read+0x1b32a>
 2a0a9e6:	mov    %eax,%ebx
 2a0a9e8:	add    %rbx,%r11
 2a0a9eb:	cmp    %r9,%rbx
 2a0a9ee:	cmova  %r10,%r11
 2a0a9f2:	mov    0x24(%r11),%r10d
 2a0a9f6:	cmp    $0x4,%r10d
 2a0a9fa:	sete   %r9b
 2a0a9fe:	cmp    $0x2,%r10d
 2a0aa02:	sete   %r11b
 2a0aa06:	or     %r11d,%r9d
 2a0aa09:	cmp    $0x3,%r10d
 2a0aa0d:	sete   %r10b
 2a0aa11:	or     %r10d,%r9d
 2a0aa14:	test   %r9b,%r9b
 2a0aa17:	je     2a0bbcc <wasm[0]::function[1015]::helper::object_read+0xda6c>
 2a0aa1d:	mov    0xa0(%rsp),%eax
 2a0aa24:	test   %eax,%eax
 2a0aa26:	je     2a1948c <wasm[0]::function[1015]::helper::object_read+0x1b32c>
 2a0aa2c:	test   %eax,%eax
 2a0aa2e:	je     2a1948e <wasm[0]::function[1015]::helper::object_read+0x1b32e>
 2a0aa34:	mov    0x2e0(%rsp),%r14
 2a0aa3c:	mov    0x28(%r14),%rcx
 2a0aa40:	mov    %eax,%edx
 2a0aa42:	mov    %rdx,%rax
 2a0aa45:	add    0x20(%r14),%rax
 2a0aa49:	xor    %rsi,%rsi
 2a0aa4c:	cmp    %rcx,%rdx
 2a0aa4f:	cmova  %rsi,%rax
 2a0aa53:	mov    0x24(%rax),%eax
 2a0aa56:	cmp    $0x3,%eax
 2a0aa59:	je     2a0ac1c <wasm[0]::function[1015]::helper::object_read+0xcabc>
 2a0aa5f:	mov    0xa0(%rsp),%eax
 2a0aa66:	test   %eax,%eax
 2a0aa68:	je     2a19490 <wasm[0]::function[1015]::helper::object_read+0x1b330>
 2a0aa6e:	test   %eax,%eax
 2a0aa70:	je     2a19492 <wasm[0]::function[1015]::helper::object_read+0x1b332>
 2a0aa76:	mov    0x2e0(%rsp),%r14
 2a0aa7e:	mov    0x28(%r14),%rcx
 2a0aa82:	mov    %eax,%edx
 2a0aa84:	mov    %rdx,%rax
 2a0aa87:	add    0x20(%r14),%rax
 2a0aa8b:	xor    %rsi,%rsi
 2a0aa8e:	cmp    %rcx,%rdx
 2a0aa91:	cmova  %rsi,%rax
 2a0aa95:	mov    0x24(%rax),%eax
 2a0aa98:	cmp    $0x4,%eax
 2a0aa9b:	je     2a0abbf <wasm[0]::function[1015]::helper::object_read+0xca5f>
 2a0aaa1:	mov    0xa0(%rsp),%eax
 2a0aaa8:	xor    %r9d,%r9d
 2a0aaab:	test   %eax,%eax
 2a0aaad:	je     2a19494 <wasm[0]::function[1015]::helper::object_read+0x1b334>
 2a0aab3:	test   %eax,%eax
 2a0aab5:	je     2a19496 <wasm[0]::function[1015]::helper::object_read+0x1b336>
 2a0aabb:	mov    0x2e0(%rsp),%r14
 2a0aac3:	mov    0x28(%r14),%rcx
 2a0aac7:	mov    0x20(%r14),%rdx
 2a0aacb:	mov    %eax,%edi
 2a0aacd:	lea    (%rdx,%rdi,1),%rax
 2a0aad1:	xor    %rsi,%rsi
 2a0aad4:	cmp    %rcx,%rdi
 2a0aad7:	cmova  %rsi,%rax
 2a0aadb:	mov    0x28(%rax),%edi
 2a0aade:	mov    0x2c(%rax),%eax
 2a0aae1:	test   %edi,%edi
 2a0aae3:	je     2a19498 <wasm[0]::function[1015]::helper::object_read+0x1b338>
 2a0aae9:	test   %edi,%edi
 2a0aaeb:	je     2a1949a <wasm[0]::function[1015]::helper::object_read+0x1b33a>
 2a0aaf1:	mov    %edi,%edi
 2a0aaf3:	lea    0x10(%rdx,%rdi,1),%rdx
 2a0aaf8:	cmp    %rcx,%rdi
 2a0aafb:	cmova  %rsi,%rdx
 2a0aaff:	mov    0x200(%rsp),%rcx
 2a0ab07:	mov    %ecx,%ecx
 2a0ab09:	mov    (%rdx),%edx
 2a0ab0b:	cmp    %rdx,%rcx
 2a0ab0e:	jae    2a0ad1b <wasm[0]::function[1015]::helper::object_read+0xcbbb>
 2a0ab14:	xor    %r9d,%r9d
 2a0ab17:	test   %eax,%eax
 2a0ab19:	je     2a1949c <wasm[0]::function[1015]::helper::object_read+0x1b33c>
 2a0ab1f:	test   %eax,%eax
 2a0ab21:	je     2a1949e <wasm[0]::function[1015]::helper::object_read+0x1b33e>
 2a0ab27:	mov    0x2e0(%rsp),%r14
 2a0ab2f:	mov    0x28(%r14),%rsi
 2a0ab33:	mov    0x20(%r14),%rdi
 2a0ab37:	mov    %eax,%r10d
 2a0ab3a:	lea    0x10(%rdi,%r10,1),%rdx
 2a0ab3f:	xor    %r8,%r8
 2a0ab42:	cmp    %rsi,%r10
 2a0ab45:	cmova  %r8,%rdx
 2a0ab49:	mov    (%rdx),%ecx
 2a0ab4b:	mov    0x200(%rsp),%rdx
 2a0ab53:	shr    $0x6,%edx
 2a0ab56:	cmp    %ecx,%edx
 2a0ab58:	jae    2a194a0 <wasm[0]::function[1015]::helper::object_read+0x1b340>
 2a0ab5e:	mov    %ecx,%r10d
 2a0ab61:	shl    $0x3,%r10
 2a0ab65:	shr    $0x20,%r10
 2a0ab69:	test   %r10,%r10
 2a0ab6c:	jne    2a194a2 <wasm[0]::function[1015]::helper::object_read+0x1b342>
 2a0ab72:	shl    $0x3,%ecx
 2a0ab75:	add    $0x18,%ecx
 2a0ab78:	jb     2a194a4 <wasm[0]::function[1015]::helper::object_read+0x1b344>
 2a0ab7e:	add    %ecx,%eax
 2a0ab80:	jb     2a194a6 <wasm[0]::function[1015]::helper::object_read+0x1b346>
 2a0ab86:	mov    %eax,%eax
 2a0ab88:	add    %rax,%rdi
 2a0ab8b:	cmp    %rsi,%rax
 2a0ab8e:	cmova  %r8,%rdi
 2a0ab92:	shl    $0x3,%edx
 2a0ab95:	lea    0x18(%rdx),%eax
 2a0ab98:	sub    %eax,%ecx
 2a0ab9a:	sub    %rcx,%rdi
 2a0ab9d:	mov    (%rdi),%rax
 2a0aba0:	mov    0x200(%rsp),%rcx
 2a0aba8:	bt     %rcx,%rax
 2a0abac:	jae    2a0ad1b <wasm[0]::function[1015]::helper::object_read+0xcbbb>
 2a0abb2:	mov    0x278(%rsp),%r9
 2a0abba:	jmp    2a0ad1b <wasm[0]::function[1015]::helper::object_read+0xcbbb>
 2a0abbf:	mov    0xa0(%rsp),%eax
 2a0abc6:	xor    %r9d,%r9d
 2a0abc9:	test   %eax,%eax
 2a0abcb:	je     2a194a8 <wasm[0]::function[1015]::helper::object_read+0x1b348>
 2a0abd1:	test   %eax,%eax
 2a0abd3:	je     2a194aa <wasm[0]::function[1015]::helper::object_read+0x1b34a>
 2a0abd9:	mov    0x2e0(%rsp),%r14
 2a0abe1:	mov    0x28(%r14),%rcx
 2a0abe5:	mov    %eax,%edx
 2a0abe7:	mov    %rdx,%rax
 2a0abea:	add    0x20(%r14),%rax
 2a0abee:	xor    %rsi,%rsi
 2a0abf1:	cmp    %rcx,%rdx
 2a0abf4:	cmova  %rsi,%rax
 2a0abf8:	mov    0x18(%rax),%rax
 2a0abfc:	mov    0x200(%rsp),%rcx
 2a0ac04:	mov    %ecx,%ecx
 2a0ac06:	cmp    %rax,%rcx
 2a0ac09:	jae    2a0ad1b <wasm[0]::function[1015]::helper::object_read+0xcbbb>
 2a0ac0f:	mov    0x278(%rsp),%r9
 2a0ac17:	jmp    2a0ad1b <wasm[0]::function[1015]::helper::object_read+0xcbbb>
 2a0ac1c:	mov    0xa0(%rsp),%eax
 2a0ac23:	xor    %r9d,%r9d
 2a0ac26:	test   %eax,%eax
 2a0ac28:	je     2a194ac <wasm[0]::function[1015]::helper::object_read+0x1b34c>
 2a0ac2e:	test   %eax,%eax
 2a0ac30:	je     2a194ae <wasm[0]::function[1015]::helper::object_read+0x1b34e>
 2a0ac36:	mov    0x2e0(%rsp),%r14
 2a0ac3e:	mov    0x28(%r14),%rcx
 2a0ac42:	mov    0x20(%r14),%rdx
 2a0ac46:	mov    %eax,%edi
 2a0ac48:	lea    (%rdx,%rdi,1),%rax
 2a0ac4c:	xor    %rsi,%rsi
 2a0ac4f:	cmp    %rcx,%rdi
 2a0ac52:	cmova  %rsi,%rax
 2a0ac56:	mov    0x30(%rax),%eax
 2a0ac59:	test   %eax,%eax
 2a0ac5b:	je     2a194b0 <wasm[0]::function[1015]::helper::object_read+0x1b350>
 2a0ac61:	test   %eax,%eax
 2a0ac63:	je     2a194b2 <wasm[0]::function[1015]::helper::object_read+0x1b352>
 2a0ac69:	mov    %eax,%r8d
 2a0ac6c:	lea    0x10(%rdx,%r8,1),%rdx
 2a0ac71:	cmp    %rcx,%r8
 2a0ac74:	cmova  %rsi,%rdx
 2a0ac78:	mov    0x200(%rsp),%rcx
 2a0ac80:	mov    %ecx,%ecx
 2a0ac82:	mov    (%rdx),%edx
 2a0ac84:	cmp    %rdx,%rcx
 2a0ac87:	jae    2a0ad1b <wasm[0]::function[1015]::helper::object_read+0xcbbb>
 2a0ac8d:	mov    0x2e0(%rsp),%r14
 2a0ac95:	mov    0x28(%r14),%rcx
 2a0ac99:	mov    0x20(%r14),%rdi
 2a0ac9d:	lea    0x10(%rdi,%r8,1),%rsi
 2a0aca2:	xor    %rdx,%rdx
 2a0aca5:	cmp    %rcx,%r8
 2a0aca8:	cmova  %rdx,%rsi
 2a0acac:	mov    (%rsi),%esi
 2a0acae:	mov    0x200(%rsp),%r9
 2a0acb6:	cmp    %esi,%r9d
 2a0acb9:	jae    2a194b4 <wasm[0]::function[1015]::helper::object_read+0x1b354>
 2a0acbf:	mov    %esi,%r8d
 2a0acc2:	shl    $0x2,%r8
 2a0acc6:	shr    $0x20,%r8
 2a0acca:	test   %r8,%r8
 2a0accd:	jne    2a194b6 <wasm[0]::function[1015]::helper::object_read+0x1b356>
 2a0acd3:	shl    $0x2,%esi
 2a0acd6:	add    $0x14,%esi
 2a0acd9:	jb     2a194b8 <wasm[0]::function[1015]::helper::object_read+0x1b358>
 2a0acdf:	add    %esi,%eax
 2a0ace1:	jb     2a194ba <wasm[0]::function[1015]::helper::object_read+0x1b35a>
 2a0ace7:	mov    %eax,%r8d
 2a0acea:	lea    (%rdi,%r8,1),%rax
 2a0acee:	cmp    %rcx,%r8
 2a0acf1:	cmova  %rdx,%rax
 2a0acf5:	mov    %r9,%rcx
 2a0acf8:	shl    $0x2,%ecx
 2a0acfb:	add    $0x14,%ecx
 2a0ad01:	sub    %ecx,%esi
 2a0ad03:	sub    %rsi,%rax
 2a0ad06:	mov    (%rax),%eax
 2a0ad08:	xor    %r9d,%r9d
 2a0ad0b:	test   %eax,%eax
 2a0ad0d:	je     2a0ad1b <wasm[0]::function[1015]::helper::object_read+0xcbbb>
 2a0ad13:	mov    0x278(%rsp),%r9
 2a0ad1b:	mov    0xa0(%rsp),%eax
 2a0ad22:	mov    0x100(%rsp),%ecx
 2a0ad29:	mov    %rcx,%r15
 2a0ad2c:	mov    0xc8(%rsp),%ecx
 2a0ad33:	mov    0xd8(%rsp),%edx
 2a0ad3a:	mov    0x110(%rsp),%edi
 2a0ad41:	mov    0x138(%rsp),%r8d
 2a0ad49:	mov    0x118(%rsp),%esi
 2a0ad50:	test   %r9d,%r9d
 2a0ad53:	je     2a0bbcc <wasm[0]::function[1015]::helper::object_read+0xda6c>
 2a0ad59:	mov    0xa0(%rsp),%eax
 2a0ad60:	test   %eax,%eax
 2a0ad62:	je     2a194bc <wasm[0]::function[1015]::helper::object_read+0x1b35c>
 2a0ad68:	test   %eax,%eax
 2a0ad6a:	je     2a194be <wasm[0]::function[1015]::helper::object_read+0x1b35e>
 2a0ad70:	mov    0x2e0(%rsp),%r14
 2a0ad78:	mov    0x28(%r14),%rcx
 2a0ad7c:	mov    %eax,%edx
 2a0ad7e:	mov    %rdx,%rax
 2a0ad81:	add    0x20(%r14),%rax
 2a0ad85:	xor    %rsi,%rsi
 2a0ad88:	cmp    %rcx,%rdx
 2a0ad8b:	cmova  %rsi,%rax
 2a0ad8f:	mov    0x24(%rax),%edx
 2a0ad92:	cmp    $0x3,%edx
 2a0ad95:	je     2a0b5db <wasm[0]::function[1015]::helper::object_read+0xd47b>
 2a0ad9b:	mov    0xa0(%rsp),%eax
 2a0ada2:	test   %eax,%eax
 2a0ada4:	je     2a194c0 <wasm[0]::function[1015]::helper::object_read+0x1b360>
 2a0adaa:	test   %eax,%eax
 2a0adac:	je     2a194c2 <wasm[0]::function[1015]::helper::object_read+0x1b362>
 2a0adb2:	mov    0x2e0(%rsp),%r14
 2a0adba:	mov    0x28(%r14),%r8
 2a0adbe:	mov    0x20(%r14),%r10
 2a0adc2:	mov    %eax,%r9d
 2a0adc5:	lea    (%r10,%r9,1),%rsi
 2a0adc9:	xor    %r10,%r10
 2a0adcc:	cmp    %r8,%r9
 2a0adcf:	cmova  %r10,%rsi
 2a0add3:	mov    0x24(%rsi),%r9d
 2a0add7:	mov    0x100(%rsp),%ecx
 2a0adde:	mov    %rcx,%r15
 2a0ade1:	mov    0xc8(%rsp),%ecx
 2a0ade8:	mov    0xd8(%rsp),%edx
 2a0adef:	mov    0x110(%rsp),%edi
 2a0adf6:	mov    0x138(%rsp),%r8d
 2a0adfe:	mov    0x118(%rsp),%esi
 2a0ae05:	cmp    $0x4,%r9d
 2a0ae09:	sete   %r10b
 2a0ae0d:	cmp    $0x2,%r9d
 2a0ae11:	sete   %r11b
 2a0ae15:	or     %r11d,%r10d
 2a0ae18:	test   %r10b,%r10b
 2a0ae1b:	je     2a0bbcc <wasm[0]::function[1015]::helper::object_read+0xda6c>
 2a0ae21:	mov    0xa0(%rsp),%edx
 2a0ae28:	test   %edx,%edx
 2a0ae2a:	je     2a194c4 <wasm[0]::function[1015]::helper::object_read+0x1b364>
 2a0ae30:	test   %edx,%edx
 2a0ae32:	je     2a194c6 <wasm[0]::function[1015]::helper::object_read+0x1b366>
 2a0ae38:	mov    0x2e0(%rsp),%r14
 2a0ae40:	mov    0x28(%r14),%rax
 2a0ae44:	mov    0x20(%r14),%rcx
 2a0ae48:	mov    %edx,%esi
 2a0ae4a:	lea    (%rcx,%rsi,1),%rdi
 2a0ae4e:	xor    %rdx,%rdx
 2a0ae51:	cmp    %rax,%rsi
 2a0ae54:	cmova  %rdx,%rdi
 2a0ae58:	mov    0x28(%rdi),%esi
 2a0ae5b:	mov    %esi,0x128(%rsp)
 2a0ae62:	mov    0x2c(%rdi),%edi
 2a0ae65:	mov    %edi,0x90(%rsp)
 2a0ae6c:	test   %esi,%esi
 2a0ae6e:	je     2a194c8 <wasm[0]::function[1015]::helper::object_read+0x1b368>
 2a0ae74:	test   %esi,%esi
 2a0ae76:	je     2a194ca <wasm[0]::function[1015]::helper::object_read+0x1b36a>
 2a0ae7c:	mov    %esi,%esi
 2a0ae7e:	lea    0x10(%rcx,%rsi,1),%rcx
 2a0ae83:	cmp    %rax,%rsi
 2a0ae86:	cmova  %rdx,%rcx
 2a0ae8a:	mov    (%rcx),%eax
 2a0ae8c:	mov    %eax,%r15d
 2a0ae8f:	mov    %r15,%rbx
 2a0ae92:	shl    $0x2,%rbx
 2a0ae96:	mov    $0x20,%ecx
 2a0ae9b:	mov    %rcx,0x1f8(%rsp)
 2a0aea3:	mov    %rbx,%rcx
 2a0aea6:	shr    $0x20,%rcx
 2a0aeaa:	test   %rcx,%rcx
 2a0aead:	jne    2a194cc <wasm[0]::function[1015]::helper::object_read+0x1b36c>
 2a0aeb3:	mov    %rax,%rcx
 2a0aeb6:	shl    $0x2,%ecx
 2a0aeb9:	mov    %rax,0x208(%rsp)
 2a0aec1:	add    $0x14,%ecx
 2a0aec4:	jb     2a194ce <wasm[0]::function[1015]::helper::object_read+0x1b36e>
 2a0aeca:	mov    0x190(%rsp),%rax
 2a0aed2:	mov    0x20(%rax),%r13
 2a0aed6:	mov    0x0(%r13),%eax
 2a0aeda:	mov    %eax,%edx
 2a0aedc:	mov    %ecx,%esi
 2a0aede:	lea    0xf(%rsi),%r11
 2a0aee2:	mov    %r11,%rsi
 2a0aee5:	and    $0xfffffffffffffff0,%rsi
 2a0aee9:	add    %rdx,%rsi
 2a0aeec:	mov    0x4(%r13),%edi
 2a0aef0:	cmp    %rdi,%rsi
 2a0aef3:	ja     2a18067 <wasm[0]::function[1015]::helper::object_read+0x19f07>
 2a0aef9:	add    $0xf,%ecx
 2a0aeff:	and    $0xfffffff0,%ecx
 2a0af02:	add    %eax,%ecx
 2a0af04:	mov    %ecx,0x0(%r13)
 2a0af08:	mov    0x2e0(%rsp),%r14
 2a0af10:	mov    0x20(%r14),%rcx
 2a0af14:	lea    (%rcx,%rdx,1),%rsi
 2a0af18:	movl   $0xa800000e,(%rcx,%rdx,1)
 2a0af1f:	mov    0x190(%rsp),%rdi
 2a0af27:	mov    0x28(%rdi),%rdi
 2a0af2b:	mov    0x194(%rdi),%edi
 2a0af31:	mov    %edi,0x4(%rcx,%rdx,1)
 2a0af35:	and    $0xfffffffffffffff0,%r11
 2a0af39:	mov    %r11d,0x8(%rcx,%rdx,1)
 2a0af3e:	mov    %eax,0xc0(%rsp)
 2a0af45:	mov    0x208(%rsp),%r12
 2a0af4d:	mov    %r12d,0x10(%rsi)
 2a0af51:	test   %eax,%eax
 2a0af53:	je     2a194d0 <wasm[0]::function[1015]::helper::object_read+0x1b370>
 2a0af59:	mov    0x2e0(%rsp),%r14
 2a0af61:	mov    0x28(%r14),%rcx
 2a0af65:	mov    0x20(%r14),%rdx
 2a0af69:	mov    %eax,%eax
 2a0af6b:	lea    (%rdx,%rax,1),%r14
 2a0af6f:	lea    0x10(%rdx,%rax,1),%rsi
 2a0af74:	xor    %rdi,%rdi
 2a0af77:	cmp    %rcx,%rax
 2a0af7a:	cmova  %rdi,%rsi
 2a0af7e:	mov    (%rsi),%esi
 2a0af80:	cmp    %rsi,%r15
 2a0af83:	ja     2a194d2 <wasm[0]::function[1015]::helper::object_read+0x1b372>
 2a0af89:	lea    0x14(%rdx,%rax,1),%r12
 2a0af8e:	mov    %r12,%rax
 2a0af91:	add    %rbx,%rax
 2a0af94:	jb     2a194d4 <wasm[0]::function[1015]::helper::object_read+0x1b374>
 2a0af9a:	add    %rdx,%rcx
 2a0af9d:	cmp    %rcx,%rax
 2a0afa0:	ja     2a194d6 <wasm[0]::function[1015]::helper::object_read+0x1b376>
 2a0afa6:	mov    0xa0(%rsp),%r11d
 2a0afae:	mov    0x90(%rsp),%r10d
 2a0afb6:	mov    0x128(%rsp),%eax
 2a0afbd:	mov    0x100(%rsp),%ecx
 2a0afc4:	mov    0xc8(%rsp),%edx
 2a0afcb:	mov    0xd8(%rsp),%esi
 2a0afd2:	mov    0x110(%rsp),%edi
 2a0afd9:	mov    0x138(%rsp),%r8d
 2a0afe1:	mov    0x118(%rsp),%r9d
 2a0afe9:	lea    0x14(%r14,%r15,4),%rbx
 2a0afee:	test   %r15,%r15
 2a0aff1:	je     2a0b0b1 <wasm[0]::function[1015]::helper::object_read+0xcf51>
 2a0aff7:	mov    %r11d,0xb0(%rsp)
 2a0afff:	mov    %r10d,0xf8(%rsp)
 2a0b007:	mov    %eax,0x88(%rsp)
 2a0b00e:	mov    %ecx,0x120(%rsp)
 2a0b015:	mov    %edx,0x108(%rsp)
 2a0b01c:	mov    %esi,0xe0(%rsp)
 2a0b023:	mov    %edi,0x98(%rsp)
 2a0b02a:	mov    %r8d,0x128(%rsp)
 2a0b032:	mov    %r9d,0x90(%rsp)
 2a0b03a:	mov    0x2e8(%rsp),%r15
 2a0b042:	mov    (%r15),%rax
 2a0b045:	mov    0x228(%rsp),%rcx
 2a0b04d:	cmp    %rcx,%rax
 2a0b050:	jae    2a180a4 <wasm[0]::function[1015]::helper::object_read+0x19f44>
 2a0b056:	movl   $0x0,(%r12)
 2a0b05e:	mov    0xb0(%rsp),%r11d
 2a0b066:	mov    0xf8(%rsp),%r10d
 2a0b06e:	mov    0x88(%rsp),%eax
 2a0b075:	mov    0x120(%rsp),%ecx
 2a0b07c:	mov    0x108(%rsp),%edx
 2a0b083:	mov    0xe0(%rsp),%esi
 2a0b08a:	mov    0x98(%rsp),%edi
 2a0b091:	mov    0x128(%rsp),%r8d
 2a0b099:	mov    0x90(%rsp),%r9d
 2a0b0a1:	add    $0x4,%r12
 2a0b0a8:	cmp    %rbx,%r12
 2a0b0ab:	jne    2a0aff7 <wasm[0]::function[1015]::helper::object_read+0xce97>
 2a0b0b1:	mov    %r11d,0x88(%rsp)
 2a0b0b9:	mov    %r10d,0xf8(%rsp)
 2a0b0c1:	mov    %eax,0xb0(%rsp)
 2a0b0c8:	xor    %r15d,%r15d
 2a0b0cb:	mov    $0xb0000042,%ebx
 2a0b0d0:	mov    0x190(%rsp),%rax
 2a0b0d8:	mov    %rbx,0x1f0(%rsp)
 2a0b0e0:	mov    0x28(%rax),%rax
 2a0b0e4:	mov    0x120(%rax),%ebx
 2a0b0ea:	mov    %rbx,0x1e8(%rsp)
 2a0b0f2:	mov    $0x20,%r12d
 2a0b0f8:	mov    %r12,0x1e0(%rsp)
 2a0b100:	mov    $0x10,%ebx
 2a0b105:	mov    %rbx,0x1d8(%rsp)
 2a0b10d:	mov    $0xb0000072,%r10d
 2a0b113:	mov    %r10,0x1d0(%rsp)
 2a0b11b:	mov    0x13c(%rax),%eax
 2a0b121:	mov    %rax,%rbx
 2a0b124:	mov    %ecx,0x90(%rsp)
 2a0b12b:	mov    %edx,0x128(%rsp)
 2a0b132:	mov    %esi,0x98(%rsp)
 2a0b139:	mov    %edi,0xe0(%rsp)
 2a0b140:	mov    %r8d,0x108(%rsp)
 2a0b148:	mov    %r9d,0x120(%rsp)
 2a0b150:	mov    0x2e8(%rsp),%rax
 2a0b158:	mov    (%rax),%rax
 2a0b15b:	mov    0x228(%rsp),%rcx
 2a0b163:	cmp    %rcx,%rax
 2a0b166:	jae    2a180db <wasm[0]::function[1015]::helper::object_read+0x19f7b>
 2a0b16c:	mov    0x208(%rsp),%r10
 2a0b174:	jmp    2a0b181 <wasm[0]::function[1015]::helper::object_read+0xd021>
 2a0b179:	mov    0x208(%rsp),%r10
 2a0b181:	cmp    %r10d,%r15d
 2a0b184:	jae    2a0b527 <wasm[0]::function[1015]::helper::object_read+0xd3c7>
 2a0b18a:	mov    0x88(%rsp),%eax
 2a0b191:	test   %eax,%eax
 2a0b193:	je     2a194d8 <wasm[0]::function[1015]::helper::object_read+0x1b378>
 2a0b199:	test   %eax,%eax
 2a0b19b:	je     2a194da <wasm[0]::function[1015]::helper::object_read+0x1b37a>
 2a0b1a1:	mov    0x2e0(%rsp),%r14
 2a0b1a9:	mov    0x28(%r14),%rcx
 2a0b1ad:	mov    %eax,%edx
 2a0b1af:	mov    %rdx,%rax
 2a0b1b2:	add    0x20(%r14),%rax
 2a0b1b6:	xor    %rsi,%rsi
 2a0b1b9:	cmp    %rcx,%rdx
 2a0b1bc:	cmova  %rsi,%rax
 2a0b1c0:	mov    0x24(%rax),%eax
 2a0b1c3:	cmp    $0x4,%eax
 2a0b1c6:	je     2a0b26c <wasm[0]::function[1015]::helper::object_read+0xd10c>
 2a0b1cc:	mov    0xf8(%rsp),%eax
 2a0b1d3:	test   %eax,%eax
 2a0b1d5:	je     2a194dc <wasm[0]::function[1015]::helper::object_read+0x1b37c>
 2a0b1db:	test   %eax,%eax
 2a0b1dd:	je     2a194de <wasm[0]::function[1015]::helper::object_read+0x1b37e>
 2a0b1e3:	mov    0x2e0(%rsp),%r14
 2a0b1eb:	mov    0x28(%r14),%rcx
 2a0b1ef:	mov    0x20(%r14),%rdx
 2a0b1f3:	mov    %eax,%r8d
 2a0b1f6:	lea    0x10(%rdx,%r8,1),%rdi
 2a0b1fb:	xor    %rsi,%rsi
 2a0b1fe:	cmp    %rcx,%r8
 2a0b201:	cmova  %rsi,%rdi
 2a0b205:	mov    (%rdi),%edi
 2a0b207:	mov    %r15,%r8
 2a0b20a:	shr    $0x6,%r8d
 2a0b20e:	cmp    %edi,%r8d
 2a0b211:	jae    2a194e0 <wasm[0]::function[1015]::helper::object_read+0x1b380>
 2a0b217:	mov    %edi,%r9d
 2a0b21a:	shl    $0x3,%r9
 2a0b21e:	shr    $0x20,%r9
 2a0b222:	test   %r9,%r9
 2a0b225:	jne    2a194e2 <wasm[0]::function[1015]::helper::object_read+0x1b382>
 2a0b22b:	shl    $0x3,%edi
 2a0b22e:	add    $0x18,%edi
 2a0b231:	jb     2a194e4 <wasm[0]::function[1015]::helper::object_read+0x1b384>
 2a0b237:	add    %edi,%eax
 2a0b239:	jb     2a194e6 <wasm[0]::function[1015]::helper::object_read+0x1b386>
 2a0b23f:	mov    %eax,%r9d
 2a0b242:	lea    (%rdx,%r9,1),%rax
 2a0b246:	cmp    %rcx,%r9
 2a0b249:	cmova  %rsi,%rax
 2a0b24d:	shl    $0x3,%r8d
 2a0b251:	lea    0x18(%r8),%ecx
 2a0b255:	sub    %ecx,%edi
 2a0b257:	sub    %rdi,%rax
 2a0b25a:	mov    (%rax),%rax
 2a0b25d:	bt     %r15,%rax
 2a0b261:	setb   %al
 2a0b264:	movzbl %al,%eax
 2a0b267:	jmp    2a0b2af <wasm[0]::function[1015]::helper::object_read+0xd14f>
 2a0b26c:	mov    0x88(%rsp),%eax
 2a0b273:	test   %eax,%eax
 2a0b275:	je     2a194e8 <wasm[0]::function[1015]::helper::object_read+0x1b388>
 2a0b27b:	test   %eax,%eax
 2a0b27d:	je     2a194ea <wasm[0]::function[1015]::helper::object_read+0x1b38a>
 2a0b283:	mov    0x2e0(%rsp),%r14
 2a0b28b:	mov    0x28(%r14),%rcx
 2a0b28f:	mov    %eax,%edx
 2a0b291:	mov    %rdx,%rax
 2a0b294:	add    0x20(%r14),%rax
 2a0b298:	xor    %rsi,%rsi
 2a0b29b:	cmp    %rcx,%rdx
 2a0b29e:	cmova  %rsi,%rax
 2a0b2a2:	mov    %r15d,%ecx
 2a0b2a5:	cmp    0x18(%rax),%rcx
 2a0b2a9:	setb   %al
 2a0b2ac:	movzbl %al,%eax
 2a0b2af:	test   %eax,%eax
 2a0b2b1:	jne    2a0b2c4 <wasm[0]::function[1015]::helper::object_read+0xd164>
 2a0b2b7:	mov    0x1f8(%rsp),%r12
 2a0b2bf:	jmp    2a0b4e7 <wasm[0]::function[1015]::helper::object_read+0xd387>
 2a0b2c4:	mov    0xb0(%rsp),%eax
 2a0b2cb:	test   %eax,%eax
 2a0b2cd:	je     2a194ec <wasm[0]::function[1015]::helper::object_read+0x1b38c>
 2a0b2d3:	test   %eax,%eax
 2a0b2d5:	je     2a194ee <wasm[0]::function[1015]::helper::object_read+0x1b38e>
 2a0b2db:	mov    0x2e0(%rsp),%r14
 2a0b2e3:	mov    0x28(%r14),%rcx
 2a0b2e7:	mov    0x20(%r14),%rdx
 2a0b2eb:	mov    %eax,%r8d
 2a0b2ee:	lea    0x10(%rdx,%r8,1),%rdi
 2a0b2f3:	xor    %rsi,%rsi
 2a0b2f6:	cmp    %rcx,%r8
 2a0b2f9:	cmova  %rsi,%rdi
 2a0b2fd:	mov    (%rdi),%edi
 2a0b2ff:	cmp    %edi,%r15d
 2a0b302:	jae    2a194f0 <wasm[0]::function[1015]::helper::object_read+0x1b390>
 2a0b308:	mov    %edi,%r8d
 2a0b30b:	shl    $0x3,%r8
 2a0b30f:	shr    $0x20,%r8
 2a0b313:	test   %r8,%r8
 2a0b316:	jne    2a194f2 <wasm[0]::function[1015]::helper::object_read+0x1b392>
 2a0b31c:	shl    $0x3,%edi
 2a0b31f:	add    $0x18,%edi
 2a0b322:	jb     2a194f4 <wasm[0]::function[1015]::helper::object_read+0x1b394>
 2a0b328:	add    %edi,%eax
 2a0b32a:	jb     2a194f6 <wasm[0]::function[1015]::helper::object_read+0x1b396>
 2a0b330:	mov    %eax,%r8d
 2a0b333:	add    %r8,%rdx
 2a0b336:	cmp    %rcx,%r8
 2a0b339:	cmova  %rsi,%rdx
 2a0b33d:	mov    %r15,%r8
 2a0b340:	shl    $0x3,%r8d
 2a0b344:	add    $0x18,%r8d
 2a0b34b:	sub    %r8d,%edi
 2a0b34e:	sub    %rdi,%rdx
 2a0b351:	mov    (%rdx),%r14
 2a0b354:	movl   $0x0,0x130(%rsp)
 2a0b35f:	mov    0x0(%r13),%eax
 2a0b363:	mov    %eax,%r9d
 2a0b366:	lea    0x20(%r9),%r10
 2a0b36a:	mov    0x4(%r13),%r11d
 2a0b36e:	cmp    %r11,%r10
 2a0b371:	ja     2a1811a <wasm[0]::function[1015]::helper::object_read+0x19fba>
 2a0b377:	lea    0x20(%rax),%ecx
 2a0b37a:	mov    %ecx,0x0(%r13)
 2a0b37e:	mov    0x2e0(%rsp),%rsi
 2a0b386:	mov    0x20(%rsi),%rdx
 2a0b38a:	lea    (%rdx,%r9,1),%rcx
 2a0b38e:	movl   $0xb0000042,(%rdx,%r9,1)
 2a0b396:	mov    0x1e8(%rsp),%rsi
 2a0b39e:	mov    %esi,0x4(%rdx,%r9,1)
 2a0b3a3:	mov    0x1f8(%rsp),%r12
 2a0b3ab:	mov    %r12d,0x8(%rdx,%r9,1)
 2a0b3b0:	mov    %eax,0xd0(%rsp)
 2a0b3b7:	mov    %r14,0x10(%rcx)
 2a0b3bb:	movl   $0x3,0x18(%rcx)
 2a0b3c2:	mov    0x130(%rsp),%edx
 2a0b3c9:	mov    %edx,0x1c(%rcx)
 2a0b3cc:	mov    0x190(%rsp),%rcx
 2a0b3d4:	mov    0xa20(%rcx),%ecx
 2a0b3da:	mov    %ecx,0x130(%rsp)
 2a0b3e1:	test   %eax,%eax
 2a0b3e3:	je     2a194f8 <wasm[0]::function[1015]::helper::object_read+0x1b398>
 2a0b3e9:	test   %ecx,%ecx
 2a0b3eb:	je     2a194fa <wasm[0]::function[1015]::helper::object_read+0x1b39a>
 2a0b3f1:	mov    0x0(%r13),%eax
 2a0b3f5:	mov    %eax,%edx
 2a0b3f7:	lea    0x20(%rdx),%rcx
 2a0b3fb:	mov    0x4(%r13),%esi
 2a0b3ff:	cmp    %rsi,%rcx
 2a0b402:	ja     2a18162 <wasm[0]::function[1015]::helper::object_read+0x1a002>
 2a0b408:	lea    0x20(%rax),%ecx
 2a0b40b:	mov    %ecx,0x0(%r13)
 2a0b40f:	mov    0x2e0(%rsp),%r14
 2a0b417:	mov    0x20(%r14),%rsi
 2a0b41b:	lea    (%rsi,%rdx,1),%rcx
 2a0b41f:	movl   $0xb0000072,(%rsi,%rdx,1)
 2a0b426:	mov    %ebx,0x4(%rsi,%rdx,1)
 2a0b42a:	mov    %r12d,0x8(%rsi,%rdx,1)
 2a0b42f:	movl   $0xe,0x10(%rcx)
 2a0b436:	mov    0xd0(%rsp),%edx
 2a0b43d:	mov    %edx,0x14(%rcx)
 2a0b440:	mov    0x130(%rsp),%edx
 2a0b447:	mov    %edx,0x18(%rcx)
 2a0b44a:	mov    %edx,0x1c(%rcx)
 2a0b44d:	mov    0xc0(%rsp),%ecx
 2a0b454:	test   %ecx,%ecx
 2a0b456:	je     2a194fc <wasm[0]::function[1015]::helper::object_read+0x1b39c>
 2a0b45c:	test   %eax,%eax
 2a0b45e:	je     2a194fe <wasm[0]::function[1015]::helper::object_read+0x1b39e>
 2a0b464:	test   %ecx,%ecx
 2a0b466:	je     2a19500 <wasm[0]::function[1015]::helper::object_read+0x1b3a0>
 2a0b46c:	mov    0x2e0(%rsp),%r14
 2a0b474:	mov    0x28(%r14),%rdx
 2a0b478:	mov    0x20(%r14),%rsi
 2a0b47c:	mov    %ecx,%r9d
 2a0b47f:	lea    0x10(%rsi,%r9,1),%r8
 2a0b484:	xor    %rdi,%rdi
 2a0b487:	cmp    %rdx,%r9
 2a0b48a:	cmova  %rdi,%r8
 2a0b48e:	mov    (%r8),%r8d
 2a0b491:	cmp    %r8d,%r15d
 2a0b494:	jae    2a19502 <wasm[0]::function[1015]::helper::object_read+0x1b3a2>
 2a0b49a:	mov    %r8d,%r9d
 2a0b49d:	shl    $0x2,%r9
 2a0b4a1:	shr    $0x20,%r9
 2a0b4a5:	test   %r9,%r9
 2a0b4a8:	jne    2a19504 <wasm[0]::function[1015]::helper::object_read+0x1b3a4>
 2a0b4ae:	shl    $0x2,%r8d
 2a0b4b2:	add    $0x14,%r8d
 2a0b4b6:	jb     2a19506 <wasm[0]::function[1015]::helper::object_read+0x1b3a6>
 2a0b4bc:	add    %r8d,%ecx
 2a0b4bf:	jb     2a19508 <wasm[0]::function[1015]::helper::object_read+0x1b3a8>
 2a0b4c5:	mov    %ecx,%r9d
 2a0b4c8:	lea    (%rsi,%r9,1),%rcx
 2a0b4cc:	cmp    %rdx,%r9
 2a0b4cf:	cmova  %rdi,%rcx
 2a0b4d3:	mov    %r15,%rdx
 2a0b4d6:	shl    $0x2,%edx
 2a0b4d9:	add    $0x14,%edx
 2a0b4df:	sub    %edx,%r8d
 2a0b4e2:	sub    %r8,%rcx
 2a0b4e5:	mov    %eax,(%rcx)
 2a0b4e7:	mov    0x90(%rsp),%ecx
 2a0b4ee:	mov    0x128(%rsp),%edx
 2a0b4f5:	mov    0x98(%rsp),%esi
 2a0b4fc:	mov    0xe0(%rsp),%edi
 2a0b503:	mov    0x108(%rsp),%r8d
 2a0b50b:	mov    0x120(%rsp),%r9d
 2a0b513:	add    $0x1,%r15d
 2a0b51a:	mov    %r12,0x1f8(%rsp)
 2a0b522:	jmp    2a0b124 <wasm[0]::function[1015]::helper::object_read+0xcfc4>
 2a0b527:	mov    0x88(%rsp),%eax
 2a0b52e:	test   %eax,%eax
 2a0b530:	je     2a1950a <wasm[0]::function[1015]::helper::object_read+0x1b3aa>
 2a0b536:	mov    0xc0(%rsp),%edx
 2a0b53d:	test   %edx,%edx
 2a0b53f:	je     2a1950c <wasm[0]::function[1015]::helper::object_read+0x1b3ac>
 2a0b545:	test   %eax,%eax
 2a0b547:	je     2a1950e <wasm[0]::function[1015]::helper::object_read+0x1b3ae>
 2a0b54d:	mov    0x2e0(%rsp),%r14
 2a0b555:	mov    0x28(%r14),%rsi
 2a0b559:	mov    0x20(%r14),%rcx
 2a0b55d:	mov    %eax,%edi
 2a0b55f:	add    %rdi,%rcx
 2a0b562:	xor    %r8,%r8
 2a0b565:	cmp    %rsi,%rdi
 2a0b568:	cmova  %r8,%rcx
 2a0b56c:	mov    %edx,0x20(%rcx)
 2a0b56f:	mov    0x190(%rsp),%rdx
 2a0b577:	mov    0xa00(%rdx),%esi
 2a0b57d:	mov    0xa10(%rdx),%edx
 2a0b583:	test   %esi,%esi
 2a0b585:	je     2a19510 <wasm[0]::function[1015]::helper::object_read+0x1b3b0>
 2a0b58b:	mov    %esi,0x28(%rcx)
 2a0b58e:	test   %edx,%edx
 2a0b590:	je     2a19512 <wasm[0]::function[1015]::helper::object_read+0x1b3b2>
 2a0b596:	mov    %edx,0x2c(%rcx)
 2a0b599:	movl   $0x0,0x30(%rcx)
 2a0b5a0:	movl   $0x0,0x24(%rcx)
 2a0b5a7:	mov    0x90(%rsp),%r10d
 2a0b5af:	mov    %r10,%r15
 2a0b5b2:	mov    0x128(%rsp),%ecx
 2a0b5b9:	mov    0x98(%rsp),%edx
 2a0b5c0:	mov    0xe0(%rsp),%edi
 2a0b5c7:	mov    0x108(%rsp),%r8d
 2a0b5cf:	mov    0x120(%rsp),%esi
 2a0b5d6:	jmp    2a0bbcc <wasm[0]::function[1015]::helper::object_read+0xda6c>
 2a0b5db:	mov    0xa0(%rsp),%r10d
 2a0b5e3:	test   %r10d,%r10d
 2a0b5e6:	je     2a19514 <wasm[0]::function[1015]::helper::object_read+0x1b3b4>
 2a0b5ec:	test   %r10d,%r10d
 2a0b5ef:	je     2a19516 <wasm[0]::function[1015]::helper::object_read+0x1b3b6>
 2a0b5f5:	mov    0x2e0(%rsp),%r14
 2a0b5fd:	mov    0x28(%r14),%rax
 2a0b601:	mov    0x20(%r14),%rcx
 2a0b605:	mov    %r10d,%esi
 2a0b608:	lea    (%rcx,%rsi,1),%r11
 2a0b60c:	xor    %rdx,%rdx
 2a0b60f:	cmp    %rax,%rsi
 2a0b612:	cmova  %rdx,%r11
 2a0b616:	mov    0x30(%r11),%esi
 2a0b61a:	mov    %esi,0x88(%rsp)
 2a0b621:	test   %esi,%esi
 2a0b623:	je     2a19518 <wasm[0]::function[1015]::helper::object_read+0x1b3b8>
 2a0b629:	test   %esi,%esi
 2a0b62b:	je     2a1951a <wasm[0]::function[1015]::helper::object_read+0x1b3ba>
 2a0b631:	mov    %esi,%esi
 2a0b633:	lea    0x10(%rcx,%rsi,1),%rcx
 2a0b638:	cmp    %rax,%rsi
 2a0b63b:	cmova  %rdx,%rcx
 2a0b63f:	mov    (%rcx),%eax
 2a0b641:	mov    %eax,%ebx
 2a0b643:	mov    %rbx,%r15
 2a0b646:	shl    $0x2,%r15
 2a0b64a:	mov    $0x20,%ecx
 2a0b64f:	mov    %rcx,0x1c8(%rsp)
 2a0b657:	mov    %r15,%rcx
 2a0b65a:	shr    $0x20,%rcx
 2a0b65e:	test   %rcx,%rcx
 2a0b661:	jne    2a1951c <wasm[0]::function[1015]::helper::object_read+0x1b3bc>
 2a0b667:	mov    %rax,%rcx
 2a0b66a:	shl    $0x2,%ecx
 2a0b66d:	mov    %rax,0x1d0(%rsp)
 2a0b675:	add    $0x14,%ecx
 2a0b678:	jb     2a1951e <wasm[0]::function[1015]::helper::object_read+0x1b3be>
 2a0b67e:	mov    0x190(%rsp),%rax
 2a0b686:	mov    0x20(%rax),%r13
 2a0b68a:	mov    0x0(%r13),%eax
 2a0b68e:	mov    %eax,%edx
 2a0b690:	mov    %ecx,%esi
 2a0b692:	add    $0xf,%rsi
 2a0b699:	mov    %rsi,%rdi
 2a0b69c:	and    $0xfffffffffffffff0,%rdi
 2a0b6a0:	add    %rdx,%rdi
 2a0b6a3:	mov    0x4(%r13),%r8d
 2a0b6a7:	cmp    %r8,%rdi
 2a0b6aa:	ja     2a1819d <wasm[0]::function[1015]::helper::object_read+0x1a03d>
 2a0b6b0:	add    $0xf,%ecx
 2a0b6b6:	and    $0xfffffff0,%ecx
 2a0b6b9:	add    %eax,%ecx
 2a0b6bb:	mov    %ecx,0x0(%r13)
 2a0b6bf:	mov    0x2e0(%rsp),%r14
 2a0b6c7:	mov    0x20(%r14),%rdi
 2a0b6cb:	lea    (%rdi,%rdx,1),%rcx
 2a0b6cf:	movl   $0xa800000e,(%rdi,%rdx,1)
 2a0b6d6:	mov    0x190(%rsp),%r8
 2a0b6de:	mov    0x28(%r8),%r8
 2a0b6e2:	mov    0x194(%r8),%r8d
 2a0b6e9:	mov    %r8d,0x4(%rdi,%rdx,1)
 2a0b6ee:	and    $0xfffffffffffffff0,%rsi
 2a0b6f2:	mov    %esi,0x8(%rdi,%rdx,1)
 2a0b6f6:	mov    %eax,0x90(%rsp)
 2a0b6fd:	mov    0x1d0(%rsp),%rdx
 2a0b705:	mov    %edx,0x10(%rcx)
 2a0b708:	test   %eax,%eax
 2a0b70a:	je     2a19520 <wasm[0]::function[1015]::helper::object_read+0x1b3c0>
 2a0b710:	mov    0x2e0(%rsp),%r14
 2a0b718:	mov    0x28(%r14),%rcx
 2a0b71c:	mov    0x20(%r14),%rdx
 2a0b720:	mov    %eax,%eax
 2a0b722:	lea    (%rdx,%rax,1),%r11
 2a0b726:	lea    0x10(%rdx,%rax,1),%rsi
 2a0b72b:	xor    %rdi,%rdi
 2a0b72e:	cmp    %rcx,%rax
 2a0b731:	cmova  %rdi,%rsi
 2a0b735:	mov    (%rsi),%esi
 2a0b737:	cmp    %rsi,%rbx
 2a0b73a:	ja     2a19522 <wasm[0]::function[1015]::helper::object_read+0x1b3c2>
 2a0b740:	lea    0x14(%rdx,%rax,1),%r12
 2a0b745:	mov    %r12,%rax
 2a0b748:	add    %r15,%rax
 2a0b74b:	jb     2a19524 <wasm[0]::function[1015]::helper::object_read+0x1b3c4>
 2a0b751:	add    %rdx,%rcx
 2a0b754:	cmp    %rcx,%rax
 2a0b757:	ja     2a19526 <wasm[0]::function[1015]::helper::object_read+0x1b3c6>
 2a0b75d:	mov    0x88(%rsp),%ecx
 2a0b764:	mov    0xa0(%rsp),%eax
 2a0b76b:	mov    0x100(%rsp),%edx
 2a0b772:	mov    0xc8(%rsp),%esi
 2a0b779:	mov    0xd8(%rsp),%edi
 2a0b780:	mov    0x110(%rsp),%r8d
 2a0b788:	mov    0x138(%rsp),%r9d
 2a0b790:	mov    0x118(%rsp),%r10d
 2a0b798:	lea    0x14(%r11,%rbx,4),%r15
 2a0b79d:	test   %rbx,%rbx
 2a0b7a0:	je     2a0b850 <wasm[0]::function[1015]::helper::object_read+0xd6f0>
 2a0b7a6:	mov    %ecx,0x118(%rsp)
 2a0b7ad:	mov    %eax,0x138(%rsp)
 2a0b7b4:	mov    %edx,0x110(%rsp)
 2a0b7bb:	mov    %esi,0xd8(%rsp)
 2a0b7c2:	mov    %edi,0xc8(%rsp)
 2a0b7c9:	mov    %r8d,0x100(%rsp)
 2a0b7d1:	mov    %r9d,0xa0(%rsp)
 2a0b7d9:	mov    %r10d,0x88(%rsp)
 2a0b7e1:	mov    0x2e8(%rsp),%rdx
 2a0b7e9:	mov    (%rdx),%rax
 2a0b7ec:	mov    0x228(%rsp),%rdi
 2a0b7f4:	cmp    %rdi,%rax
 2a0b7f7:	jae    2a181da <wasm[0]::function[1015]::helper::object_read+0x1a07a>
 2a0b7fd:	movl   $0x0,(%r12)
 2a0b805:	mov    0x118(%rsp),%ecx
 2a0b80c:	mov    0x138(%rsp),%eax
 2a0b813:	mov    0x110(%rsp),%edx
 2a0b81a:	mov    0xd8(%rsp),%esi
 2a0b821:	mov    0xc8(%rsp),%edi
 2a0b828:	mov    0x100(%rsp),%r8d
 2a0b830:	mov    0xa0(%rsp),%r9d
 2a0b838:	mov    0x88(%rsp),%r10d
 2a0b840:	add    $0x4,%r12
 2a0b847:	cmp    %r15,%r12
 2a0b84a:	jne    2a0b7a6 <wasm[0]::function[1015]::helper::object_read+0xd646>
 2a0b850:	mov    %ecx,0x118(%rsp)
 2a0b857:	mov    0x190(%rsp),%rcx
 2a0b85f:	mov    0xa20(%rcx),%r11d
 2a0b866:	mov    %r11d,0x138(%rsp)
 2a0b86e:	xor    %r12d,%r12d
 2a0b871:	mov    $0xb0000072,%r15d
 2a0b877:	mov    %r15,0x1a0(%rsp)
 2a0b87f:	mov    0x28(%rcx),%r11
 2a0b883:	mov    0x13c(%r11),%ebx
 2a0b88a:	mov    $0x20,%r15d
 2a0b890:	mov    %r15,0x198(%rsp)
 2a0b898:	mov    $0x10,%r11d
 2a0b89e:	mov    %r11,0x2a8(%rsp)
 2a0b8a6:	mov    %eax,0x128(%rsp)
 2a0b8ad:	mov    %edx,0x88(%rsp)
 2a0b8b4:	mov    %esi,0xa0(%rsp)
 2a0b8bb:	mov    %edi,0x100(%rsp)
 2a0b8c2:	mov    %r8d,0xc8(%rsp)
 2a0b8ca:	mov    %r9d,0xd8(%rsp)
 2a0b8d2:	mov    %r10d,0x110(%rsp)
 2a0b8da:	mov    0x2e8(%rsp),%r15
 2a0b8e2:	mov    (%r15),%rax
 2a0b8e5:	mov    0x228(%rsp),%rcx
 2a0b8ed:	cmp    %rcx,%rax
 2a0b8f0:	jae    2a18214 <wasm[0]::function[1015]::helper::object_read+0x1a0b4>
 2a0b8f6:	mov    0x1d0(%rsp),%rcx
 2a0b8fe:	jmp    2a0b90b <wasm[0]::function[1015]::helper::object_read+0xd7ab>
 2a0b903:	mov    0x1d0(%rsp),%rcx
 2a0b90b:	cmp    %ecx,%r12d
 2a0b90e:	jae    2a0bb16 <wasm[0]::function[1015]::helper::object_read+0xd9b6>
 2a0b914:	mov    0x118(%rsp),%r8d
 2a0b91c:	test   %r8d,%r8d
 2a0b91f:	je     2a19528 <wasm[0]::function[1015]::helper::object_read+0x1b3c8>
 2a0b925:	test   %r8d,%r8d
 2a0b928:	je     2a1952a <wasm[0]::function[1015]::helper::object_read+0x1b3ca>
 2a0b92e:	mov    0x2e0(%rsp),%r14
 2a0b936:	mov    0x28(%r14),%rax
 2a0b93a:	mov    0x20(%r14),%rcx
 2a0b93e:	mov    %r8d,%edi
 2a0b941:	lea    0x10(%rcx,%rdi,1),%rsi
 2a0b946:	xor    %rdx,%rdx
 2a0b949:	cmp    %rax,%rdi
 2a0b94c:	cmova  %rdx,%rsi
 2a0b950:	mov    (%rsi),%esi
 2a0b952:	cmp    %esi,%r12d
 2a0b955:	jae    2a1952c <wasm[0]::function[1015]::helper::object_read+0x1b3cc>
 2a0b95b:	mov    %esi,%edi
 2a0b95d:	shl    $0x2,%rdi
 2a0b961:	shr    $0x20,%rdi
 2a0b965:	test   %rdi,%rdi
 2a0b968:	jne    2a1952e <wasm[0]::function[1015]::helper::object_read+0x1b3ce>
 2a0b96e:	shl    $0x2,%esi
 2a0b971:	add    $0x14,%esi
 2a0b974:	jb     2a19530 <wasm[0]::function[1015]::helper::object_read+0x1b3d0>
 2a0b97a:	add    %esi,%r8d
 2a0b97d:	jb     2a19532 <wasm[0]::function[1015]::helper::object_read+0x1b3d2>
 2a0b983:	mov    %r8d,%edi
 2a0b986:	add    %rdi,%rcx
 2a0b989:	cmp    %rax,%rdi
 2a0b98c:	cmova  %rdx,%rcx
 2a0b990:	mov    %r12,%r15
 2a0b993:	shl    $0x2,%r15d
 2a0b997:	lea    0x14(%r15),%eax
 2a0b99b:	sub    %eax,%esi
 2a0b99d:	sub    %rsi,%rcx
 2a0b9a0:	mov    (%rcx),%eax
 2a0b9a2:	mov    %eax,0x98(%rsp)
 2a0b9a9:	test   %eax,%eax
 2a0b9ab:	jne    2a0b9be <wasm[0]::function[1015]::helper::object_read+0xd85e>
 2a0b9b1:	mov    0x1c8(%rsp),%rcx
 2a0b9b9:	jmp    2a0bace <wasm[0]::function[1015]::helper::object_read+0xd96e>
 2a0b9be:	test   %eax,%eax
 2a0b9c0:	je     2a19534 <wasm[0]::function[1015]::helper::object_read+0x1b3d4>
 2a0b9c6:	mov    0x138(%rsp),%eax
 2a0b9cd:	test   %eax,%eax
 2a0b9cf:	je     2a19536 <wasm[0]::function[1015]::helper::object_read+0x1b3d6>
 2a0b9d5:	mov    0x0(%r13),%eax
 2a0b9d9:	mov    %eax,%edx
 2a0b9db:	lea    0x20(%rdx),%rcx
 2a0b9df:	mov    0x4(%r13),%esi
 2a0b9e3:	cmp    %rsi,%rcx
 2a0b9e6:	ja     2a18253 <wasm[0]::function[1015]::helper::object_read+0x1a0f3>
 2a0b9ec:	lea    0x20(%rax),%ecx
 2a0b9ef:	mov    %ecx,0x0(%r13)
 2a0b9f3:	mov    0x2e0(%rsp),%r14
 2a0b9fb:	mov    0x20(%r14),%rsi
 2a0b9ff:	lea    (%rsi,%rdx,1),%r8
 2a0ba03:	movl   $0xb0000072,(%rsi,%rdx,1)
 2a0ba0a:	mov    %ebx,0x4(%rsi,%rdx,1)
 2a0ba0e:	mov    0x1c8(%rsp),%rcx
 2a0ba16:	mov    %ecx,0x8(%rsi,%rdx,1)
 2a0ba1a:	movl   $0xe,0x10(%r8)
 2a0ba22:	mov    0x98(%rsp),%edx
 2a0ba29:	mov    %edx,0x14(%r8)
 2a0ba2d:	mov    0x138(%rsp),%edx
 2a0ba34:	mov    %edx,0x18(%r8)
 2a0ba38:	mov    %edx,0x1c(%r8)
 2a0ba3c:	mov    0x90(%rsp),%edx
 2a0ba43:	test   %edx,%edx
 2a0ba45:	je     2a19538 <wasm[0]::function[1015]::helper::object_read+0x1b3d8>
 2a0ba4b:	test   %eax,%eax
 2a0ba4d:	je     2a1953a <wasm[0]::function[1015]::helper::object_read+0x1b3da>
 2a0ba53:	test   %edx,%edx
 2a0ba55:	je     2a1953c <wasm[0]::function[1015]::helper::object_read+0x1b3dc>
 2a0ba5b:	mov    0x2e0(%rsp),%r14
 2a0ba63:	mov    0x28(%r14),%rsi
 2a0ba67:	mov    0x20(%r14),%rdi
 2a0ba6b:	mov    %edx,%r10d
 2a0ba6e:	lea    0x10(%rdi,%r10,1),%r9
 2a0ba73:	xor    %r8,%r8
 2a0ba76:	cmp    %rsi,%r10
 2a0ba79:	cmova  %r8,%r9
 2a0ba7d:	mov    (%r9),%r9d
 2a0ba80:	cmp    %r9d,%r12d
 2a0ba83:	jae    2a1953e <wasm[0]::function[1015]::helper::object_read+0x1b3de>
 2a0ba89:	mov    %r9d,%r10d
 2a0ba8c:	shl    $0x2,%r10
 2a0ba90:	shr    $0x20,%r10
 2a0ba94:	test   %r10,%r10
 2a0ba97:	jne    2a19540 <wasm[0]::function[1015]::helper::object_read+0x1b3e0>
 2a0ba9d:	shl    $0x2,%r9d
 2a0baa1:	add    $0x14,%r9d
 2a0baa5:	jb     2a19542 <wasm[0]::function[1015]::helper::object_read+0x1b3e2>
 2a0baab:	add    %r9d,%edx
 2a0baae:	jb     2a19544 <wasm[0]::function[1015]::helper::object_read+0x1b3e4>
 2a0bab4:	mov    %edx,%r10d
 2a0bab7:	lea    (%rdi,%r10,1),%rdx
 2a0babb:	cmp    %rsi,%r10
 2a0babe:	cmova  %r8,%rdx
 2a0bac2:	lea    0x14(%r15),%esi
 2a0bac6:	sub    %esi,%r9d
 2a0bac9:	sub    %r9,%rdx
 2a0bacc:	mov    %eax,(%rdx)
 2a0bace:	mov    0x128(%rsp),%eax
 2a0bad5:	mov    0x88(%rsp),%edx
 2a0badc:	mov    0xa0(%rsp),%esi
 2a0bae3:	mov    0x100(%rsp),%edi
 2a0baea:	mov    0xc8(%rsp),%r8d
 2a0baf2:	mov    0xd8(%rsp),%r9d
 2a0bafa:	mov    0x110(%rsp),%r10d
 2a0bb02:	add    $0x1,%r12d
 2a0bb09:	mov    %rcx,0x1c8(%rsp)
 2a0bb11:	jmp    2a0b8a6 <wasm[0]::function[1015]::helper::object_read+0xd746>
 2a0bb16:	mov    0x128(%rsp),%eax
 2a0bb1d:	test   %eax,%eax
 2a0bb1f:	je     2a19546 <wasm[0]::function[1015]::helper::object_read+0x1b3e6>
 2a0bb25:	mov    0x90(%rsp),%r10d
 2a0bb2d:	test   %r10d,%r10d
 2a0bb30:	je     2a19548 <wasm[0]::function[1015]::helper::object_read+0x1b3e8>
 2a0bb36:	test   %eax,%eax
 2a0bb38:	je     2a1954a <wasm[0]::function[1015]::helper::object_read+0x1b3ea>
 2a0bb3e:	mov    0x2e0(%rsp),%r14
 2a0bb46:	mov    0x28(%r14),%rcx
 2a0bb4a:	mov    0x20(%r14),%rsi
 2a0bb4e:	mov    %eax,%edx
 2a0bb50:	lea    (%rsi,%rdx,1),%r11
 2a0bb54:	xor    %rsi,%rsi
 2a0bb57:	cmp    %rcx,%rdx
 2a0bb5a:	cmova  %rsi,%r11
 2a0bb5e:	mov    %r10d,0x20(%r11)
 2a0bb62:	mov    0x190(%rsp),%rcx
 2a0bb6a:	mov    0xa00(%rcx),%edx
 2a0bb70:	mov    0xa10(%rcx),%ecx
 2a0bb76:	test   %edx,%edx
 2a0bb78:	je     2a1954c <wasm[0]::function[1015]::helper::object_read+0x1b3ec>
 2a0bb7e:	mov    %edx,0x28(%r11)
 2a0bb82:	test   %ecx,%ecx
 2a0bb84:	je     2a1954e <wasm[0]::function[1015]::helper::object_read+0x1b3ee>
 2a0bb8a:	mov    %ecx,0x2c(%r11)
 2a0bb8e:	movl   $0x0,0x30(%r11)
 2a0bb96:	movl   $0x0,0x24(%r11)
 2a0bb9e:	mov    0x88(%rsp),%esi
 2a0bba5:	mov    %rsi,%r15
 2a0bba8:	mov    0xa0(%rsp),%ecx
 2a0bbaf:	mov    0x100(%rsp),%edx
 2a0bbb6:	mov    0xc8(%rsp),%edi
 2a0bbbd:	mov    0xd8(%rsp),%r8d
 2a0bbc5:	mov    0x110(%rsp),%esi
 2a0bbcc:	test   %eax,%eax
 2a0bbce:	je     2a19550 <wasm[0]::function[1015]::helper::object_read+0x1b3f0>
 2a0bbd4:	test   %eax,%eax
 2a0bbd6:	je     2a19552 <wasm[0]::function[1015]::helper::object_read+0x1b3f2>
 2a0bbdc:	mov    0x2e0(%rsp),%r14
 2a0bbe4:	mov    0x28(%r14),%r10
 2a0bbe8:	mov    0x20(%r14),%r12
 2a0bbec:	mov    %eax,%eax
 2a0bbee:	lea    (%r12,%rax,1),%rbx
 2a0bbf2:	xor    %r13,%r13
 2a0bbf5:	cmp    %r10,%rax
 2a0bbf8:	cmova  %r13,%rbx
 2a0bbfc:	mov    0x10(%rbx),%r9d
 2a0bc00:	test   %r9d,%r9d
 2a0bc03:	je     2a19554 <wasm[0]::function[1015]::helper::object_read+0x1b3f4>
 2a0bc09:	test   %r9d,%r9d
 2a0bc0c:	je     2a19556 <wasm[0]::function[1015]::helper::object_read+0x1b3f6>
 2a0bc12:	mov    %r9d,%r11d
 2a0bc15:	lea    0x10(%r12,%r11,1),%r12
 2a0bc1a:	cmp    %r10,%r11
 2a0bc1d:	cmova  %r13,%r12
 2a0bc21:	mov    (%r12),%r12d
 2a0bc25:	mov    0x24(%rbx),%r10d
 2a0bc29:	test   %r10d,%r10d
 2a0bc2c:	je     2a0be80 <wasm[0]::function[1015]::helper::object_read+0xdd20>
 2a0bc32:	xor    %eax,%eax
 2a0bc34:	test   %r12d,%r12d
 2a0bc37:	je     2a0bf6a <wasm[0]::function[1015]::helper::object_read+0xde0a>
 2a0bc3d:	mov    0x2e0(%rsp),%r14
 2a0bc45:	mov    0x28(%r14),%rax
 2a0bc49:	mov    0x20(%r14),%rbx
 2a0bc4d:	lea    0x10(%rbx,%r11,1),%r13
 2a0bc52:	xor    %r10,%r10
 2a0bc55:	cmp    %rax,%r11
 2a0bc58:	cmova  %r10,%r13
 2a0bc5c:	mov    0x0(%r13),%r11d
 2a0bc60:	mov    0x200(%rsp),%r13
 2a0bc68:	shr    $0x10,%r13d
 2a0bc6c:	mov    0x200(%rsp),%r14
 2a0bc74:	xor    %r13d,%r14d
 2a0bc77:	imul   $0x7feb352d,%r14d,%r13d
 2a0bc7e:	mov    %r13,%r14
 2a0bc81:	shr    $0xf,%r14d
 2a0bc85:	xor    %r14d,%r13d
 2a0bc88:	imul   $0x846ca68b,%r13d,%r13d
 2a0bc8f:	mov    %r13,%r14
 2a0bc92:	shr    $0x10,%r14d
 2a0bc96:	xor    %r14d,%r13d
 2a0bc99:	sub    $0x1,%r12d
 2a0bc9d:	and    %r12d,%r13d
 2a0bca0:	cmp    %r11d,%r13d
 2a0bca3:	jae    2a19558 <wasm[0]::function[1015]::helper::object_read+0x1b3f8>
 2a0bca9:	mov    %r11d,%r12d
 2a0bcac:	shl    $0x2,%r12
 2a0bcb0:	shr    $0x20,%r12
 2a0bcb4:	test   %r12,%r12
 2a0bcb7:	jne    2a1955a <wasm[0]::function[1015]::helper::object_read+0x1b3fa>
 2a0bcbd:	shl    $0x2,%r11d
 2a0bcc1:	add    $0x14,%r11d
 2a0bcc5:	jb     2a1955c <wasm[0]::function[1015]::helper::object_read+0x1b3fc>
 2a0bccb:	add    %r11d,%r9d
 2a0bcce:	jb     2a1955e <wasm[0]::function[1015]::helper::object_read+0x1b3fe>
 2a0bcd4:	mov    %r9d,%r12d
 2a0bcd7:	lea    (%rbx,%r12,1),%r9
 2a0bcdb:	cmp    %rax,%r12
 2a0bcde:	cmova  %r10,%r9
 2a0bce2:	shl    $0x2,%r13d
 2a0bce6:	lea    0x14(%r13),%eax
 2a0bcea:	sub    %eax,%r11d
 2a0bced:	sub    %r11,%r9
 2a0bcf0:	mov    (%r9),%eax
 2a0bcf3:	xor    %r9d,%r9d
 2a0bcf6:	mov    0x200(%rsp),%r10
 2a0bcfe:	mov    %r10d,%ebx
 2a0bd01:	mov    %eax,0x90(%rsp)
 2a0bd08:	mov    %r9d,0x110(%rsp)
 2a0bd10:	mov    %r15,%rax
 2a0bd13:	mov    %eax,0xd8(%rsp)
 2a0bd1a:	mov    %ecx,0xc8(%rsp)
 2a0bd21:	mov    %edx,0x100(%rsp)
 2a0bd28:	mov    %edi,0xa0(%rsp)
 2a0bd2f:	mov    %r8d,0x88(%rsp)
 2a0bd37:	mov    %esi,0x128(%rsp)
 2a0bd3e:	mov    0x2e8(%rsp),%r15
 2a0bd46:	mov    (%r15),%rax
 2a0bd49:	mov    0x228(%rsp),%rcx
 2a0bd51:	cmp    %rcx,%rax
 2a0bd54:	jae    2a18297 <wasm[0]::function[1015]::helper::object_read+0x1a137>
 2a0bd5a:	mov    0x90(%rsp),%esi
 2a0bd61:	mov    0x110(%rsp),%eax
 2a0bd68:	test   %esi,%esi
 2a0bd6a:	je     2a0be4d <wasm[0]::function[1015]::helper::object_read+0xdced>
 2a0bd70:	mov    0x90(%rsp),%esi
 2a0bd77:	test   %esi,%esi
 2a0bd79:	je     2a19560 <wasm[0]::function[1015]::helper::object_read+0x1b400>
 2a0bd7f:	mov    0x2e0(%rsp),%r14
 2a0bd87:	mov    0x28(%r14),%r8
 2a0bd8b:	mov    %esi,%r9d
 2a0bd8e:	mov    %r9,%rsi
 2a0bd91:	add    0x20(%r14),%rsi
 2a0bd95:	xor    %r10,%r10
 2a0bd98:	cmp    %r8,%r9
 2a0bd9b:	cmova  %r10,%rsi
 2a0bd9f:	mov    0x10(%rsi),%r9
 2a0bda3:	cmp    %rbx,%r9
 2a0bda6:	je     2a0be1c <wasm[0]::function[1015]::helper::object_read+0xdcbc>
 2a0bdac:	mov    0x90(%rsp),%r11d
 2a0bdb4:	test   %r11d,%r11d
 2a0bdb7:	je     2a19562 <wasm[0]::function[1015]::helper::object_read+0x1b402>
 2a0bdbd:	mov    0x2e0(%rsp),%r14
 2a0bdc5:	mov    0x28(%r14),%rax
 2a0bdc9:	mov    %r11d,%ecx
 2a0bdcc:	mov    %rcx,%r10
 2a0bdcf:	add    0x20(%r14),%r10
 2a0bdd3:	xor    %rdx,%rdx
 2a0bdd6:	cmp    %rax,%rcx
 2a0bdd9:	cmova  %rdx,%r10
 2a0bddd:	mov    0x1c(%r10),%eax
 2a0bde1:	mov    0x110(%rsp),%r9d
 2a0bde9:	mov    0xd8(%rsp),%ecx
 2a0bdf0:	mov    %rcx,%r15
 2a0bdf3:	mov    0xc8(%rsp),%ecx
 2a0bdfa:	mov    0x100(%rsp),%edx
 2a0be01:	mov    0xa0(%rsp),%edi
 2a0be08:	mov    0x88(%rsp),%r8d
 2a0be10:	mov    0x128(%rsp),%esi
 2a0be17:	jmp    2a0bd01 <wasm[0]::function[1015]::helper::object_read+0xdba1>
 2a0be1c:	mov    0x90(%rsp),%ecx
 2a0be23:	test   %ecx,%ecx
 2a0be25:	je     2a19564 <wasm[0]::function[1015]::helper::object_read+0x1b404>
 2a0be2b:	mov    0x2e0(%rsp),%r14
 2a0be33:	mov    0x28(%r14),%rax
 2a0be37:	mov    %ecx,%edx
 2a0be39:	mov    %rdx,%rcx
 2a0be3c:	add    0x20(%r14),%rcx
 2a0be40:	xor    %rsi,%rsi
 2a0be43:	cmp    %rax,%rdx
 2a0be46:	cmova  %rsi,%rcx
 2a0be4a:	mov    0x18(%rcx),%eax
 2a0be4d:	mov    0xd8(%rsp),%ecx
 2a0be54:	mov    %rcx,%r15
 2a0be57:	mov    0xc8(%rsp),%ecx
 2a0be5e:	mov    0x100(%rsp),%edx
 2a0be65:	mov    0xa0(%rsp),%edi
 2a0be6c:	mov    0x88(%rsp),%r8d
 2a0be74:	mov    0x128(%rsp),%esi
 2a0be7b:	jmp    2a0bf6a <wasm[0]::function[1015]::helper::object_read+0xde0a>
 2a0be80:	mov    0x2e0(%rsp),%r14
 2a0be88:	mov    0x28(%r14),%r10
 2a0be8c:	mov    0x20(%r14),%rbx
 2a0be90:	lea    (%rbx,%rax,1),%r9
 2a0be94:	xor    %r11,%r11
 2a0be97:	cmp    %r10,%rax
 2a0be9a:	cmova  %r11,%r9
 2a0be9e:	mov    0x20(%r9),%r9d
 2a0bea2:	xor    %eax,%eax
 2a0bea4:	test   %r9d,%r9d
 2a0bea7:	je     2a19566 <wasm[0]::function[1015]::helper::object_read+0x1b406>
 2a0bead:	test   %r9d,%r9d
 2a0beb0:	je     2a19568 <wasm[0]::function[1015]::helper::object_read+0x1b408>
 2a0beb6:	mov    %r9d,%r12d
 2a0beb9:	lea    0x10(%rbx,%r12,1),%rbx
 2a0bebe:	cmp    %r10,%r12
 2a0bec1:	cmova  %r11,%rbx
 2a0bec5:	mov    0x200(%rsp),%r10
 2a0becd:	mov    %r10d,%r10d
 2a0bed0:	mov    (%rbx),%r11d
 2a0bed3:	cmp    %r11,%r10
 2a0bed6:	jae    2a0bf6a <wasm[0]::function[1015]::helper::object_read+0xde0a>
 2a0bedc:	mov    0x2e0(%rsp),%r14
 2a0bee4:	mov    0x28(%r14),%rax
 2a0bee8:	mov    0x20(%r14),%rbx
 2a0beec:	lea    0x10(%rbx,%r12,1),%r11
 2a0bef1:	xor    %r10,%r10
 2a0bef4:	cmp    %rax,%r12
 2a0bef7:	cmova  %r10,%r11
 2a0befb:	mov    (%r11),%r11d
 2a0befe:	mov    0x200(%rsp),%r12
 2a0bf06:	cmp    %r11d,%r12d
 2a0bf09:	jae    2a1956a <wasm[0]::function[1015]::helper::object_read+0x1b40a>
 2a0bf0f:	mov    %r11d,%r12d
 2a0bf12:	shl    $0x2,%r12
 2a0bf16:	shr    $0x20,%r12
 2a0bf1a:	test   %r12,%r12
 2a0bf1d:	jne    2a1956c <wasm[0]::function[1015]::helper::object_read+0x1b40c>
 2a0bf23:	shl    $0x2,%r11d
 2a0bf27:	add    $0x14,%r11d
 2a0bf2b:	jb     2a1956e <wasm[0]::function[1015]::helper::object_read+0x1b40e>
 2a0bf31:	add    %r11d,%r9d
 2a0bf34:	jb     2a19570 <wasm[0]::function[1015]::helper::object_read+0x1b410>
 2a0bf3a:	mov    %r9d,%r12d
 2a0bf3d:	lea    (%rbx,%r12,1),%r9
 2a0bf41:	cmp    %rax,%r12
 2a0bf44:	cmova  %r10,%r9
 2a0bf48:	mov    0x200(%rsp),%rax
 2a0bf50:	shl    $0x2,%eax
 2a0bf53:	mov    %rax,0x200(%rsp)
 2a0bf5b:	add    $0x14,%eax
 2a0bf61:	sub    %eax,%r11d
 2a0bf64:	sub    %r11,%r9
 2a0bf67:	mov    (%r9),%eax
 2a0bf6a:	mov    %ecx,0x88(%rsp)
 2a0bf71:	mov    %edx,0xa0(%rsp)
 2a0bf78:	mov    %edi,0x100(%rsp)
 2a0bf7f:	mov    %r8d,0xc8(%rsp)
 2a0bf87:	mov    %esi,0xd8(%rsp)
 2a0bf8e:	test   %eax,%eax
 2a0bf90:	je     2a0c2a5 <wasm[0]::function[1015]::helper::object_read+0xe145>
 2a0bf96:	test   %eax,%eax
 2a0bf98:	jne    2a0bfa6 <wasm[0]::function[1015]::helper::object_read+0xde46>
 2a0bf9e:	xor    %r13d,%r13d
 2a0bfa1:	jmp    2a0bfdd <wasm[0]::function[1015]::helper::object_read+0xde7d>
 2a0bfa6:	test   %eax,%eax
 2a0bfa8:	je     2a19572 <wasm[0]::function[1015]::helper::object_read+0x1b412>
 2a0bfae:	mov    0x2e0(%rsp),%r14
 2a0bfb6:	mov    0x28(%r14),%rcx
 2a0bfba:	mov    %eax,%esi
 2a0bfbc:	mov    %rsi,%rdx
 2a0bfbf:	add    0x20(%r14),%rdx
 2a0bfc3:	xor    %rdi,%rdi
 2a0bfc6:	cmp    %rcx,%rsi
 2a0bfc9:	cmova  %rdi,%rdx
 2a0bfcd:	mov    0x10(%rdx),%ecx
 2a0bfd0:	test   $0x4,%ecx
 2a0bfd6:	setne  %cl
 2a0bfd9:	movzbl %cl,%r13d
 2a0bfdd:	test   %eax,%eax
 2a0bfdf:	jne    2a0bfec <wasm[0]::function[1015]::helper::object_read+0xde8c>
 2a0bfe5:	xor    %ebx,%ebx
 2a0bfe7:	jmp    2a0c022 <wasm[0]::function[1015]::helper::object_read+0xdec2>
 2a0bfec:	test   %eax,%eax
 2a0bfee:	je     2a19574 <wasm[0]::function[1015]::helper::object_read+0x1b414>
 2a0bff4:	mov    0x2e0(%rsp),%r14
 2a0bffc:	mov    0x28(%r14),%rcx
 2a0c000:	mov    %eax,%esi
 2a0c002:	mov    %rsi,%rdx
 2a0c005:	add    0x20(%r14),%rdx
 2a0c009:	xor    %rdi,%rdi
 2a0c00c:	cmp    %rcx,%rsi
 2a0c00f:	cmova  %rdi,%rdx
 2a0c013:	mov    0x10(%rdx),%ecx
 2a0c016:	test   $0x8,%ecx
 2a0c01c:	setne  %dl
 2a0c01f:	movzbl %dl,%ebx
 2a0c022:	test   %eax,%eax
 2a0c024:	jne    2a0c032 <wasm[0]::function[1015]::helper::object_read+0xded2>
 2a0c02a:	xor    %r12d,%r12d
 2a0c02d:	jmp    2a0c06d <wasm[0]::function[1015]::helper::object_read+0xdf0d>
 2a0c032:	test   %eax,%eax
 2a0c034:	je     2a19576 <wasm[0]::function[1015]::helper::object_read+0x1b416>
 2a0c03a:	mov    0x2e0(%rsp),%r14
 2a0c042:	mov    0x28(%r14),%r8
 2a0c046:	mov    %eax,%r9d
 2a0c049:	mov    %r9,%rsi
 2a0c04c:	add    0x20(%r14),%rsi
 2a0c050:	xor    %r10,%r10
 2a0c053:	cmp    %r8,%r9
 2a0c056:	cmova  %r10,%rsi
 2a0c05a:	mov    0x10(%rsi),%r9d
 2a0c05e:	test   $0x2,%r9d
 2a0c065:	setne  %r10b
 2a0c069:	movzbl %r10b,%r12d
 2a0c06d:	test   %eax,%eax
 2a0c06f:	je     2a19578 <wasm[0]::function[1015]::helper::object_read+0x1b418>
 2a0c075:	mov    0x2e0(%rsp),%r14
 2a0c07d:	mov    0x28(%r14),%rdx
 2a0c081:	mov    0x20(%r14),%rsi
 2a0c085:	mov    %eax,%ecx
 2a0c087:	lea    (%rsi,%rcx,1),%r10
 2a0c08b:	xor    %rsi,%rsi
 2a0c08e:	cmp    %rdx,%rcx
 2a0c091:	cmova  %rsi,%r10
 2a0c095:	mov    0x14(%r10),%edx
 2a0c099:	mov    %edx,0x128(%rsp)
 2a0c0a0:	mov    0x18(%r10),%edx
 2a0c0a4:	mov    %edx,0x90(%rsp)
 2a0c0ab:	mov    0x1c(%r10),%edx
 2a0c0af:	mov    %edx,0x110(%rsp)
 2a0c0b6:	test   %eax,%eax
 2a0c0b8:	jne    2a0c0c6 <wasm[0]::function[1015]::helper::object_read+0xdf66>
 2a0c0be:	xor    %r11d,%r11d
 2a0c0c1:	jmp    2a0c0f2 <wasm[0]::function[1015]::helper::object_read+0xdf92>
 2a0c0c6:	mov    0x2e0(%rsp),%r14
 2a0c0ce:	mov    0x28(%r14),%rdx
 2a0c0d2:	mov    %rcx,%rax
 2a0c0d5:	add    0x20(%r14),%rax
 2a0c0d9:	xor    %rsi,%rsi
 2a0c0dc:	cmp    %rdx,%rcx
 2a0c0df:	cmova  %rsi,%rax
 2a0c0e3:	mov    0x10(%rax),%eax
 2a0c0e6:	test   $0x1,%eax
 2a0c0eb:	setne  %al
 2a0c0ee:	movzbl %al,%r11d
 2a0c0f2:	test   %r11d,%r11d
 2a0c0f5:	jne    2a0c1d8 <wasm[0]::function[1015]::helper::object_read+0xe078>
 2a0c0fb:	mov    0x128(%rsp),%eax
 2a0c102:	test   %eax,%eax
 2a0c104:	je     2a1957a <wasm[0]::function[1015]::helper::object_read+0x1b41a>
 2a0c10a:	mov    0x90(%rsp),%eax
 2a0c111:	test   %eax,%eax
 2a0c113:	je     2a1957c <wasm[0]::function[1015]::helper::object_read+0x1b41c>
 2a0c119:	mov    0x110(%rsp),%eax
 2a0c120:	test   %eax,%eax
 2a0c122:	je     2a1957e <wasm[0]::function[1015]::helper::object_read+0x1b41e>
 2a0c128:	mov    0x190(%rsp),%rcx
 2a0c130:	mov    0x20(%rcx),%rax
 2a0c134:	mov    (%rax),%ecx
 2a0c136:	mov    %rcx,%r15
 2a0c139:	mov    %ecx,%ecx
 2a0c13b:	mov    $0x20,%edx
 2a0c140:	lea    0x20(%rcx),%rsi
 2a0c144:	mov    0x4(%rax),%edi
 2a0c147:	cmp    %rdi,%rsi
 2a0c14a:	ja     2a182ce <wasm[0]::function[1015]::helper::object_read+0x1a16e>
 2a0c150:	mov    %r15,%rsi
 2a0c153:	add    $0x20,%esi
 2a0c159:	mov    %esi,(%rax)
 2a0c15b:	mov    0x2e0(%rsp),%r14
 2a0c163:	mov    0x20(%r14),%rsi
 2a0c167:	lea    (%rsi,%rcx,1),%rax
 2a0c16b:	movl   $0xb0000072,(%rsi,%rcx,1)
 2a0c172:	mov    0x190(%rsp),%rdi
 2a0c17a:	mov    0x28(%rdi),%rdi
 2a0c17e:	mov    0x13c(%rdi),%edi
 2a0c184:	mov    %edi,0x4(%rsi,%rcx,1)
 2a0c188:	mov    %edx,0x8(%rsi,%rcx,1)
 2a0c18c:	test   %r13d,%r13d
 2a0c18f:	setne  %cl
 2a0c192:	movzbl %cl,%ecx
 2a0c195:	shl    $0x2,%ecx
 2a0c198:	test   %ebx,%ebx
 2a0c19a:	setne  %dl
 2a0c19d:	movzbl %dl,%edx
 2a0c1a0:	shl    $0x3,%edx
 2a0c1a3:	or     %edx,%ecx
 2a0c1a5:	test   %r12d,%r12d
 2a0c1a8:	setne  %dl
 2a0c1ab:	movzbl %dl,%edx
 2a0c1ae:	shl    $1,%edx
 2a0c1b0:	or     %edx,%ecx
 2a0c1b2:	mov    %ecx,0x10(%rax)
 2a0c1b5:	mov    0x128(%rsp),%ecx
 2a0c1bc:	mov    %ecx,0x14(%rax)
 2a0c1bf:	mov    0x90(%rsp),%ecx
 2a0c1c6:	mov    %ecx,0x18(%rax)
 2a0c1c9:	mov    0x110(%rsp),%ecx
 2a0c1d0:	mov    %ecx,0x1c(%rax)
 2a0c1d3:	jmp    2a0c2a5 <wasm[0]::function[1015]::helper::object_read+0xe145>
 2a0c1d8:	mov    0x128(%rsp),%eax
 2a0c1df:	test   %eax,%eax
 2a0c1e1:	je     2a19580 <wasm[0]::function[1015]::helper::object_read+0x1b420>
 2a0c1e7:	mov    0x90(%rsp),%eax
 2a0c1ee:	test   %eax,%eax
 2a0c1f0:	je     2a19582 <wasm[0]::function[1015]::helper::object_read+0x1b422>
 2a0c1f6:	mov    0x110(%rsp),%eax
 2a0c1fd:	test   %eax,%eax
 2a0c1ff:	je     2a19584 <wasm[0]::function[1015]::helper::object_read+0x1b424>
 2a0c205:	mov    0x190(%rsp),%rcx
 2a0c20d:	mov    0x20(%rcx),%rax
 2a0c211:	mov    (%rax),%ecx
 2a0c213:	mov    %rcx,%r15
 2a0c216:	mov    %ecx,%ecx
 2a0c218:	mov    $0x20,%edx
 2a0c21d:	lea    0x20(%rcx),%rsi
 2a0c221:	mov    0x4(%rax),%edi
 2a0c224:	cmp    %rdi,%rsi
 2a0c227:	ja     2a18313 <wasm[0]::function[1015]::helper::object_read+0x1a1b3>
 2a0c22d:	mov    %r15,%rsi
 2a0c230:	add    $0x20,%esi
 2a0c236:	mov    %esi,(%rax)
 2a0c238:	mov    0x2e0(%rsp),%r14
 2a0c240:	mov    0x20(%r14),%rsi
 2a0c244:	lea    (%rsi,%rcx,1),%rax
 2a0c248:	movl   $0xb0000072,(%rsi,%rcx,1)
 2a0c24f:	mov    0x190(%rsp),%rdi
 2a0c257:	mov    0x28(%rdi),%rdi
 2a0c25b:	mov    0x13c(%rdi),%edi
 2a0c261:	mov    %edi,0x4(%rsi,%rcx,1)
 2a0c265:	mov    %edx,0x8(%rsi,%rcx,1)
 2a0c269:	test   %ebx,%ebx
 2a0c26b:	setne  %cl
 2a0c26e:	movzbl %cl,%ecx
 2a0c271:	shl    $0x3,%ecx
 2a0c274:	or     $0x1,%ecx
 2a0c277:	test   %r12d,%r12d
 2a0c27a:	setne  %dl
 2a0c27d:	movzbl %dl,%edx
 2a0c280:	shl    $1,%edx
 2a0c282:	or     %edx,%ecx
 2a0c284:	mov    %ecx,0x10(%rax)
 2a0c287:	mov    0x128(%rsp),%ecx
 2a0c28e:	mov    %ecx,0x14(%rax)
 2a0c291:	mov    0x90(%rsp),%edx
 2a0c298:	mov    %edx,0x18(%rax)
 2a0c29b:	mov    0x110(%rsp),%esi
 2a0c2a2:	mov    %esi,0x1c(%rax)
 2a0c2a5:	mov    0x88(%rsp),%esi
 2a0c2ac:	mov    0xa0(%rsp),%edi
 2a0c2b3:	mov    0x100(%rsp),%r8d
 2a0c2bb:	mov    0xc8(%rsp),%edx
 2a0c2c2:	mov    0xd8(%rsp),%ecx
 2a0c2c9:	jmp    2a0c6b0 <wasm[0]::function[1015]::helper::object_read+0xe550>
 2a0c2ce:	xor    %eax,%eax
 2a0c2d0:	mov    0x210(%rsp),%rcx
 2a0c2d8:	mov    0x210(%rsp),%rdx
 2a0c2e0:	test   %ecx,%edx
 2a0c2e2:	je     2a0c342 <wasm[0]::function[1015]::helper::object_read+0xe1e2>
 2a0c2e8:	xor    %eax,%eax
 2a0c2ea:	mov    0x210(%rsp),%rdx
 2a0c2f2:	test   $0x1,%edx
 2a0c2f8:	jne    2a0c342 <wasm[0]::function[1015]::helper::object_read+0xe1e2>
 2a0c2fe:	mov    0x2e0(%rsp),%r14
 2a0c306:	mov    0x28(%r14),%rax
 2a0c30a:	mov    0x20(%r14),%rdx
 2a0c30e:	mov    0x210(%rsp),%rcx
 2a0c316:	mov    %ecx,%ecx
 2a0c318:	lea    0x4(%rdx,%rcx,1),%r11
 2a0c31d:	xor    %rdx,%rdx
 2a0c320:	cmp    %rax,%rcx
 2a0c323:	cmova  %rdx,%r11
 2a0c327:	mov    (%r11),%eax
 2a0c32a:	mov    0x190(%rsp),%rcx
 2a0c332:	mov    0x28(%rcx),%rcx
 2a0c336:	cmp    0x138(%rcx),%eax
 2a0c33c:	sete   %al
 2a0c33f:	movzbl %al,%eax
 2a0c342:	test   %eax,%eax
 2a0c344:	je     2a19586 <wasm[0]::function[1015]::helper::object_read+0x1b426>
 2a0c34a:	mov    0x210(%rsp),%rdx
 2a0c352:	mov    0x210(%rsp),%rsi
 2a0c35a:	test   %esi,%edx
 2a0c35c:	je     2a19588 <wasm[0]::function[1015]::helper::object_read+0x1b428>
 2a0c362:	mov    0x1b8(%rsp),%rcx
 2a0c36a:	mov    0x190(%rsp),%rsi
 2a0c372:	mov    0x190(%rsp),%rdi
 2a0c37a:	mov    0x1c0(%rsp),%r8
 2a0c382:	call   2a1cf20 <wasm[0]::function[1019]::helper::ordinary_own_descriptor>
 2a0c387:	mov    0x78(%rsp),%ecx
 2a0c38b:	mov    %rcx,%r15
 2a0c38e:	test   %eax,%eax
 2a0c390:	je     2a0c692 <wasm[0]::function[1015]::helper::object_read+0xe532>
 2a0c396:	test   %eax,%eax
 2a0c398:	jne    2a0c3a5 <wasm[0]::function[1015]::helper::object_read+0xe245>
 2a0c39e:	xor    %ebx,%ebx
 2a0c3a0:	jmp    2a0c3db <wasm[0]::function[1015]::helper::object_read+0xe27b>
 2a0c3a5:	test   %eax,%eax
 2a0c3a7:	je     2a1958a <wasm[0]::function[1015]::helper::object_read+0x1b42a>
 2a0c3ad:	mov    0x2e0(%rsp),%r14
 2a0c3b5:	mov    0x28(%r14),%rcx
 2a0c3b9:	mov    %eax,%esi
 2a0c3bb:	mov    %rsi,%rdx
 2a0c3be:	add    0x20(%r14),%rdx
 2a0c3c2:	xor    %rdi,%rdi
 2a0c3c5:	cmp    %rcx,%rsi
 2a0c3c8:	cmova  %rdi,%rdx
 2a0c3cc:	mov    0x10(%rdx),%ecx
 2a0c3cf:	test   $0x4,%ecx
 2a0c3d5:	setne  %cl
 2a0c3d8:	movzbl %cl,%ebx
 2a0c3db:	test   %eax,%eax
 2a0c3dd:	jne    2a0c3eb <wasm[0]::function[1015]::helper::object_read+0xe28b>
 2a0c3e3:	xor    %r13d,%r13d
 2a0c3e6:	jmp    2a0c422 <wasm[0]::function[1015]::helper::object_read+0xe2c2>
 2a0c3eb:	test   %eax,%eax
 2a0c3ed:	je     2a1958c <wasm[0]::function[1015]::helper::object_read+0x1b42c>
 2a0c3f3:	mov    0x2e0(%rsp),%r14
 2a0c3fb:	mov    0x28(%r14),%rcx
 2a0c3ff:	mov    %eax,%esi
 2a0c401:	mov    %rsi,%rdx
 2a0c404:	add    0x20(%r14),%rdx
 2a0c408:	xor    %rdi,%rdi
 2a0c40b:	cmp    %rcx,%rsi
 2a0c40e:	cmova  %rdi,%rdx
 2a0c412:	mov    0x10(%rdx),%ecx
 2a0c415:	test   $0x8,%ecx
 2a0c41b:	setne  %cl
 2a0c41e:	movzbl %cl,%r13d
 2a0c422:	test   %eax,%eax
 2a0c424:	jne    2a0c432 <wasm[0]::function[1015]::helper::object_read+0xe2d2>
 2a0c42a:	xor    %r12d,%r12d
 2a0c42d:	jmp    2a0c469 <wasm[0]::function[1015]::helper::object_read+0xe309>
 2a0c432:	test   %eax,%eax
 2a0c434:	je     2a1958e <wasm[0]::function[1015]::helper::object_read+0x1b42e>
 2a0c43a:	mov    0x2e0(%rsp),%r14
 2a0c442:	mov    0x28(%r14),%rcx
 2a0c446:	mov    %eax,%esi
 2a0c448:	mov    %rsi,%rdx
 2a0c44b:	add    0x20(%r14),%rdx
 2a0c44f:	xor    %rdi,%rdi
 2a0c452:	cmp    %rcx,%rsi
 2a0c455:	cmova  %rdi,%rdx
 2a0c459:	mov    0x10(%rdx),%ecx
 2a0c45c:	test   $0x2,%ecx
 2a0c462:	setne  %cl
 2a0c465:	movzbl %cl,%r12d
 2a0c469:	test   %eax,%eax
 2a0c46b:	je     2a19590 <wasm[0]::function[1015]::helper::object_read+0x1b430>
 2a0c471:	mov    0x2e0(%rsp),%r14
 2a0c479:	mov    0x28(%r14),%rsi
 2a0c47d:	mov    0x20(%r14),%rdx
 2a0c481:	mov    %eax,%ecx
 2a0c483:	add    %rcx,%rdx
 2a0c486:	xor    %rdi,%rdi
 2a0c489:	cmp    %rsi,%rcx
 2a0c48c:	cmova  %rdi,%rdx
 2a0c490:	mov    0x14(%rdx),%esi
 2a0c493:	mov    %esi,0x78(%rsp)
 2a0c497:	mov    0x18(%rdx),%esi
 2a0c49a:	mov    %esi,0x88(%rsp)
 2a0c4a1:	mov    0x1c(%rdx),%edx
 2a0c4a4:	mov    %edx,0xa0(%rsp)
 2a0c4ab:	test   %eax,%eax
 2a0c4ad:	jne    2a0c4ba <wasm[0]::function[1015]::helper::object_read+0xe35a>
 2a0c4b3:	xor    %eax,%eax
 2a0c4b5:	jmp    2a0c4e5 <wasm[0]::function[1015]::helper::object_read+0xe385>
 2a0c4ba:	mov    0x2e0(%rsp),%r14
 2a0c4c2:	mov    0x28(%r14),%rdx
 2a0c4c6:	mov    %rcx,%rax
 2a0c4c9:	add    0x20(%r14),%rax
 2a0c4cd:	xor    %rsi,%rsi
 2a0c4d0:	cmp    %rdx,%rcx
 2a0c4d3:	cmova  %rsi,%rax
 2a0c4d7:	mov    0x10(%rax),%eax
 2a0c4da:	test   $0x1,%eax
 2a0c4df:	setne  %al
 2a0c4e2:	movzbl %al,%eax
 2a0c4e5:	test   %eax,%eax
 2a0c4e7:	jne    2a0c5ca <wasm[0]::function[1015]::helper::object_read+0xe46a>
 2a0c4ed:	mov    0x78(%rsp),%eax
 2a0c4f1:	test   %eax,%eax
 2a0c4f3:	je     2a19592 <wasm[0]::function[1015]::helper::object_read+0x1b432>
 2a0c4f9:	mov    0x88(%rsp),%ecx
 2a0c500:	test   %ecx,%ecx
 2a0c502:	je     2a19594 <wasm[0]::function[1015]::helper::object_read+0x1b434>
 2a0c508:	mov    0xa0(%rsp),%esi
 2a0c50f:	test   %esi,%esi
 2a0c511:	je     2a19596 <wasm[0]::function[1015]::helper::object_read+0x1b436>
 2a0c517:	mov    0x190(%rsp),%rcx
 2a0c51f:	mov    0x20(%rcx),%r8
 2a0c523:	mov    (%r8),%eax
 2a0c526:	mov    %rax,%r15
 2a0c529:	mov    %eax,%esi
 2a0c52b:	mov    $0x20,%edi
 2a0c530:	lea    0x20(%rsi),%r9
 2a0c534:	mov    0x4(%r8),%r10d
 2a0c538:	cmp    %r10,%r9
 2a0c53b:	ja     2a18358 <wasm[0]::function[1015]::helper::object_read+0x1a1f8>
 2a0c541:	mov    %r15,%rax
 2a0c544:	lea    0x20(%rax),%r9d
 2a0c548:	mov    %r9d,(%r8)
 2a0c54b:	mov    0x2e0(%rsp),%r14
 2a0c553:	mov    0x20(%r14),%r9
 2a0c557:	lea    (%r9,%rsi,1),%rax
 2a0c55b:	movl   $0xb0000072,(%r9,%rsi,1)
 2a0c563:	mov    0x190(%rsp),%rcx
 2a0c56b:	mov    0x28(%rcx),%r10
 2a0c56f:	mov    0x13c(%r10),%r10d
 2a0c576:	mov    %r10d,0x4(%r9,%rsi,1)
 2a0c57b:	mov    %edi,0x8(%r9,%rsi,1)
 2a0c580:	test   %ebx,%ebx
 2a0c582:	setne  %cl
 2a0c585:	rex movzbl %cl,%esi
 2a0c589:	shl    $0x2,%esi
 2a0c58c:	test   %r13d,%r13d
 2a0c58f:	setne  %cl
 2a0c592:	movzbl %cl,%ecx
 2a0c595:	shl    $0x3,%ecx
 2a0c598:	or     %ecx,%esi
 2a0c59a:	test   %r12d,%r12d
 2a0c59d:	setne  %cl
 2a0c5a0:	movzbl %cl,%ecx
 2a0c5a3:	shl    $1,%ecx
 2a0c5a5:	or     %ecx,%esi
 2a0c5a7:	mov    %esi,0x10(%rax)
 2a0c5aa:	mov    0x78(%rsp),%ecx
 2a0c5ae:	mov    %ecx,0x14(%rax)
 2a0c5b1:	mov    0x88(%rsp),%ecx
 2a0c5b8:	mov    %ecx,0x18(%rax)
 2a0c5bb:	mov    0xa0(%rsp),%ecx
 2a0c5c2:	mov    %ecx,0x1c(%rax)
 2a0c5c5:	jmp    2a0c692 <wasm[0]::function[1015]::helper::object_read+0xe532>
 2a0c5ca:	mov    0x78(%rsp),%eax
 2a0c5ce:	test   %eax,%eax
 2a0c5d0:	je     2a19598 <wasm[0]::function[1015]::helper::object_read+0x1b438>
 2a0c5d6:	mov    0x88(%rsp),%eax
 2a0c5dd:	test   %eax,%eax
 2a0c5df:	je     2a1959a <wasm[0]::function[1015]::helper::object_read+0x1b43a>
 2a0c5e5:	mov    0xa0(%rsp),%eax
 2a0c5ec:	test   %eax,%eax
 2a0c5ee:	je     2a1959c <wasm[0]::function[1015]::helper::object_read+0x1b43c>
 2a0c5f4:	mov    0x190(%rsp),%rcx
 2a0c5fc:	mov    0x20(%rcx),%rax
 2a0c600:	mov    (%rax),%ecx
 2a0c602:	mov    %rcx,%r15
 2a0c605:	mov    %ecx,%ecx
 2a0c607:	mov    $0x20,%edx
 2a0c60c:	lea    0x20(%rcx),%rsi
 2a0c610:	mov    0x4(%rax),%edi
 2a0c613:	cmp    %rdi,%rsi
 2a0c616:	ja     2a1839d <wasm[0]::function[1015]::helper::object_read+0x1a23d>
 2a0c61c:	mov    %r15,%rsi
 2a0c61f:	add    $0x20,%esi
 2a0c625:	mov    %esi,(%rax)
 2a0c627:	mov    0x2e0(%rsp),%r14
 2a0c62f:	mov    0x20(%r14),%rsi
 2a0c633:	lea    (%rsi,%rcx,1),%rax
 2a0c637:	movl   $0xb0000072,(%rsi,%rcx,1)
 2a0c63e:	mov    0x190(%rsp),%r11
 2a0c646:	mov    0x28(%r11),%rdi
 2a0c64a:	mov    0x13c(%rdi),%edi
 2a0c650:	mov    %edi,0x4(%rsi,%rcx,1)
 2a0c654:	mov    %edx,0x8(%rsi,%rcx,1)
 2a0c658:	test   %r13d,%r13d
 2a0c65b:	setne  %cl
 2a0c65e:	movzbl %cl,%ecx
 2a0c661:	shl    $0x3,%ecx
 2a0c664:	or     $0x1,%ecx
 2a0c667:	test   %r12d,%r12d
 2a0c66a:	setne  %dl
 2a0c66d:	movzbl %dl,%edx
 2a0c670:	shl    $1,%edx
 2a0c672:	or     %edx,%ecx
 2a0c674:	mov    %ecx,0x10(%rax)
 2a0c677:	mov    0x78(%rsp),%ecx
 2a0c67b:	mov    %ecx,0x14(%rax)
 2a0c67e:	mov    0x88(%rsp),%ecx
 2a0c685:	mov    %ecx,0x18(%rax)
 2a0c688:	mov    0xa0(%rsp),%ecx
 2a0c68f:	mov    %ecx,0x1c(%rax)
 2a0c692:	mov    0x58(%rsp),%esi
 2a0c696:	mov    0xa8(%rsp),%edi
 2a0c69d:	mov    0xb8(%rsp),%r8d
 2a0c6a5:	mov    0x48(%rsp),%edx
 2a0c6a9:	mov    0x80(%rsp),%ecx
 2a0c6b0:	mov    %esi,0x80(%rsp)
 2a0c6b7:	mov    %edi,0x48(%rsp)
 2a0c6bb:	mov    %r8d,0xb8(%rsp)
 2a0c6c3:	mov    %edx,0xa8(%rsp)
 2a0c6ca:	mov    %ecx,0x58(%rsp)
 2a0c6ce:	mov    %r15,%rax
 2a0c6d1:	mov    %r15,%rsi
 2a0c6d4:	test   %esi,%eax
 2a0c6d6:	jne    2a0cbeb <wasm[0]::function[1015]::helper::object_read+0xea8b>
 2a0c6dc:	xor    %esi,%esi
 2a0c6de:	test   %edx,%edx
 2a0c6e0:	je     2a0c730 <wasm[0]::function[1015]::helper::object_read+0xe5d0>
 2a0c6e6:	xor    %esi,%esi
 2a0c6e8:	test   $0x1,%edx
 2a0c6ee:	jne    2a0c730 <wasm[0]::function[1015]::helper::object_read+0xe5d0>
 2a0c6f4:	mov    0x2e0(%rsp),%r14
 2a0c6fc:	mov    0x28(%r14),%rax
 2a0c700:	mov    0x20(%r14),%rdi
 2a0c704:	mov    %edx,%esi
 2a0c706:	lea    0x4(%rdi,%rsi,1),%rdx
 2a0c70b:	xor    %rdi,%rdi
 2a0c70e:	cmp    %rax,%rsi
 2a0c711:	cmova  %rdi,%rdx
 2a0c715:	mov    (%rdx),%eax
 2a0c717:	mov    0x190(%rsp),%rsi
 2a0c71f:	mov    0x28(%rsi),%rdx
 2a0c723:	cmp    0x26c(%rdx),%eax
 2a0c729:	sete   %al
 2a0c72c:	rex movzbl %al,%esi
 2a0c730:	xor    %eax,%eax
 2a0c732:	test   %esi,%esi
 2a0c734:	je     2a0c879 <wasm[0]::function[1015]::helper::object_read+0xe719>
 2a0c73a:	xor    %eax,%eax
 2a0c73c:	mov    0x1b8(%rsp),%rdx
 2a0c744:	cmp    $0x4,%edx
 2a0c747:	jne    2a0c879 <wasm[0]::function[1015]::helper::object_read+0xe719>
 2a0c74d:	xor    %eax,%eax
 2a0c74f:	test   %ecx,%ecx
 2a0c751:	je     2a0c7a5 <wasm[0]::function[1015]::helper::object_read+0xe645>
 2a0c757:	xor    %eax,%eax
 2a0c759:	test   $0x1,%ecx
 2a0c75f:	jne    2a0c7a5 <wasm[0]::function[1015]::helper::object_read+0xe645>
 2a0c765:	mov    0x2e0(%rsp),%r14
 2a0c76d:	mov    0x28(%r14),%r9
 2a0c771:	mov    0x20(%r14),%r11
 2a0c775:	mov    %ecx,%r10d
 2a0c778:	lea    0x4(%r11,%r10,1),%rsi
 2a0c77d:	xor    %r11,%r11
 2a0c780:	cmp    %r9,%r10
 2a0c783:	cmova  %r11,%rsi
 2a0c787:	mov    (%rsi),%r10d
 2a0c78a:	mov    0x190(%rsp),%rcx
 2a0c792:	mov    0x28(%rcx),%r11
 2a0c796:	cmp    0x234(%r11),%r10d
 2a0c79d:	sete   %r11b
 2a0c7a1:	movzbl %r11b,%eax
 2a0c7a5:	test   %eax,%eax
 2a0c7a7:	je     2a1959e <wasm[0]::function[1015]::helper::object_read+0x1b43e>
 2a0c7ad:	mov    $0xb,%edx
 2a0c7b2:	mov    0x190(%rsp),%rsi
 2a0c7ba:	mov    0x190(%rsp),%rdi
 2a0c7c2:	call   2f4f240 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 2a0c7c7:	mov    0x58(%rsp),%edx
 2a0c7cb:	xor    %r8d,%r8d
 2a0c7ce:	test   %edx,%edx
 2a0c7d0:	je     2a195a0 <wasm[0]::function[1015]::helper::object_read+0x1b440>
 2a0c7d6:	test   %eax,%eax
 2a0c7d8:	je     2a195a2 <wasm[0]::function[1015]::helper::object_read+0x1b442>
 2a0c7de:	mov    %rax,%rcx
 2a0c7e1:	mov    0x190(%rsp),%rsi
 2a0c7e9:	mov    0x190(%rsp),%rdi
 2a0c7f1:	call   2b02800 <wasm[0]::function[1057]::helper::string_equality>
 2a0c7f6:	test   %eax,%eax
 2a0c7f8:	jne    2a0c871 <wasm[0]::function[1015]::helper::object_read+0xe711>
 2a0c7fe:	mov    0x58(%rsp),%edx
 2a0c802:	xor    %r8d,%r8d
 2a0c805:	mov    %r8,%rbx
 2a0c808:	test   %edx,%edx
 2a0c80a:	je     2a195a4 <wasm[0]::function[1015]::helper::object_read+0x1b444>
 2a0c810:	mov    0x190(%rsp),%rsi
 2a0c818:	mov    0x190(%rsp),%rdi
 2a0c820:	call   2b09c60 <wasm[0]::function[1060]::helper::string_to_number>
 2a0c825:	mov    %rax,%rdx
 2a0c828:	mov    0x190(%rsp),%rsi
 2a0c830:	mov    0x190(%rsp),%rdi
 2a0c838:	call   2b03080 <wasm[0]::function[1059]::helper::number_to_string>
 2a0c83d:	mov    0x58(%rsp),%edx
 2a0c841:	test   %edx,%edx
 2a0c843:	je     2a195a6 <wasm[0]::function[1015]::helper::object_read+0x1b446>
 2a0c849:	test   %eax,%eax
 2a0c84b:	je     2a195a8 <wasm[0]::function[1015]::helper::object_read+0x1b448>
 2a0c851:	mov    %rax,%rcx
 2a0c854:	mov    %rbx,%r8
 2a0c857:	mov    0x190(%rsp),%rsi
 2a0c85f:	mov    0x190(%rsp),%rdi
 2a0c867:	call   2b02800 <wasm[0]::function[1057]::helper::string_equality>
 2a0c86c:	jmp    2a0c879 <wasm[0]::function[1015]::helper::object_read+0xe719>
 2a0c871:	mov    0x278(%rsp),%rax
 2a0c879:	test   %eax,%eax
 2a0c87b:	jne    2a0cba3 <wasm[0]::function[1015]::helper::object_read+0xea43>
 2a0c881:	mov    0xa8(%rsp),%r8d
 2a0c889:	mov    0x2d8(%rsp),%rcx
 2a0c891:	mov    0x2d0(%rsp),%rdx
 2a0c899:	mov    0x190(%rsp),%rsi
 2a0c8a1:	mov    0x190(%rsp),%rdi
 2a0c8a9:	call   2a7c940 <wasm[0]::function[1039]::helper::object_header_projection>
 2a0c8ae:	xor    %ecx,%ecx
 2a0c8b0:	test   %eax,%eax
 2a0c8b2:	je     2a195aa <wasm[0]::function[1015]::helper::object_read+0x1b44a>
 2a0c8b8:	test   %eax,%eax
 2a0c8ba:	je     2a195ac <wasm[0]::function[1015]::helper::object_read+0x1b44c>
 2a0c8c0:	mov    0x2e0(%rsp),%r14
 2a0c8c8:	mov    0x28(%r14),%rdx
 2a0c8cc:	mov    0x20(%r14),%rdi
 2a0c8d0:	mov    %eax,%esi
 2a0c8d2:	lea    (%rdi,%rsi,1),%rax
 2a0c8d6:	xor    %rdi,%rdi
 2a0c8d9:	cmp    %rdx,%rsi
 2a0c8dc:	cmova  %rdi,%rax
 2a0c8e0:	mov    0x10(%rax),%r8d
 2a0c8e4:	test   %r8d,%r8d
 2a0c8e7:	jne    2a0c8fd <wasm[0]::function[1015]::helper::object_read+0xe79d>
 2a0c8ed:	mov    0x278(%rsp),%rdx
 2a0c8f5:	mov    %rcx,%r8
 2a0c8f8:	jmp    2a0cac3 <wasm[0]::function[1015]::helper::object_read+0xe963>
 2a0c8fd:	xor    %esi,%esi
 2a0c8ff:	test   %r8d,%r8d
 2a0c902:	je     2a0c954 <wasm[0]::function[1015]::helper::object_read+0xe7f4>
 2a0c908:	xor    %esi,%esi
 2a0c90a:	test   $0x1,%r8d
 2a0c911:	jne    2a0c954 <wasm[0]::function[1015]::helper::object_read+0xe7f4>
 2a0c917:	mov    0x2e0(%rsp),%r14
 2a0c91f:	mov    0x28(%r14),%rax
 2a0c923:	mov    0x20(%r14),%rcx
 2a0c927:	mov    %r8d,%edx
 2a0c92a:	lea    0x4(%rcx,%rdx,1),%rcx
 2a0c92f:	xor    %rsi,%rsi
 2a0c932:	cmp    %rax,%rdx
 2a0c935:	cmova  %rsi,%rcx
 2a0c939:	mov    (%rcx),%eax
 2a0c93b:	mov    0x190(%rsp),%rcx
 2a0c943:	mov    0x28(%rcx),%rcx
 2a0c947:	cmp    0x1d4(%rcx),%eax
 2a0c94d:	sete   %al
 2a0c950:	rex movzbl %al,%esi
 2a0c954:	mov    $0x6,%edx
 2a0c959:	mov    %rdx,0x278(%rsp)
 2a0c961:	test   %esi,%esi
 2a0c963:	je     2a0c976 <wasm[0]::function[1015]::helper::object_read+0xe816>
 2a0c969:	mov    $0x8,%edx
 2a0c96e:	mov    %rdx,0x278(%rsp)
 2a0c976:	xor    %eax,%eax
 2a0c978:	test   %r8d,%r8d
 2a0c97b:	je     2a0c9cc <wasm[0]::function[1015]::helper::object_read+0xe86c>
 2a0c981:	xor    %eax,%eax
 2a0c983:	test   $0x1,%r8d
 2a0c98a:	jne    2a0c9cc <wasm[0]::function[1015]::helper::object_read+0xe86c>
 2a0c990:	mov    0x2e0(%rsp),%r14
 2a0c998:	mov    0x28(%r14),%rax
 2a0c99c:	mov    0x20(%r14),%rcx
 2a0c9a0:	mov    %r8d,%edx
 2a0c9a3:	lea    0x4(%rcx,%rdx,1),%rcx
 2a0c9a8:	xor    %rsi,%rsi
 2a0c9ab:	cmp    %rax,%rdx
 2a0c9ae:	cmova  %rsi,%rcx
 2a0c9b2:	mov    (%rcx),%eax
 2a0c9b4:	mov    0x190(%rsp),%rcx
 2a0c9bc:	mov    0x28(%rcx),%rcx
 2a0c9c0:	cmp    0x1e4(%rcx),%eax
 2a0c9c6:	sete   %al
 2a0c9c9:	movzbl %al,%eax
 2a0c9cc:	test   %eax,%eax
 2a0c9ce:	je     2a0c9e1 <wasm[0]::function[1015]::helper::object_read+0xe881>
 2a0c9d4:	mov    $0x8,%edx
 2a0c9d9:	mov    %rdx,0x278(%rsp)
 2a0c9e1:	xor    %esi,%esi
 2a0c9e3:	test   %r8d,%r8d
 2a0c9e6:	je     2a0ca3b <wasm[0]::function[1015]::helper::object_read+0xe8db>
 2a0c9ec:	xor    %esi,%esi
 2a0c9ee:	test   $0x1,%r8d
 2a0c9f5:	jne    2a0ca3b <wasm[0]::function[1015]::helper::object_read+0xe8db>
 2a0c9fb:	mov    0x2e0(%rsp),%r14
 2a0ca03:	mov    0x28(%r14),%r9
 2a0ca07:	mov    0x20(%r14),%r11
 2a0ca0b:	mov    %r8d,%r10d
 2a0ca0e:	lea    0x4(%r11,%r10,1),%rsi
 2a0ca13:	xor    %r11,%r11
 2a0ca16:	cmp    %r9,%r10
 2a0ca19:	cmova  %r11,%rsi
 2a0ca1d:	mov    (%rsi),%r10d
 2a0ca20:	mov    0x190(%rsp),%rcx
 2a0ca28:	mov    0x28(%rcx),%r11
 2a0ca2c:	cmp    0x1f0(%r11),%r10d
 2a0ca33:	sete   %r11b
 2a0ca37:	movzbl %r11b,%esi
 2a0ca3b:	test   %esi,%esi
 2a0ca3d:	je     2a0ca50 <wasm[0]::function[1015]::helper::object_read+0xe8f0>
 2a0ca43:	mov    $0x9,%edx
 2a0ca48:	mov    %rdx,0x278(%rsp)
 2a0ca50:	xor    %eax,%eax
 2a0ca52:	test   %r8d,%r8d
 2a0ca55:	je     2a0caa6 <wasm[0]::function[1015]::helper::object_read+0xe946>
 2a0ca5b:	xor    %eax,%eax
 2a0ca5d:	test   $0x1,%r8d
 2a0ca64:	jne    2a0caa6 <wasm[0]::function[1015]::helper::object_read+0xe946>
 2a0ca6a:	mov    0x2e0(%rsp),%r14
 2a0ca72:	mov    0x28(%r14),%rax
 2a0ca76:	mov    0x20(%r14),%rcx
 2a0ca7a:	mov    %r8d,%edx
 2a0ca7d:	lea    0x4(%rcx,%rdx,1),%rcx
 2a0ca82:	xor    %rsi,%rsi
 2a0ca85:	cmp    %rax,%rdx
 2a0ca88:	cmova  %rsi,%rcx
 2a0ca8c:	mov    (%rcx),%eax
 2a0ca8e:	mov    0x190(%rsp),%rcx
 2a0ca96:	mov    0x28(%rcx),%rcx
 2a0ca9a:	cmp    0x254(%rcx),%eax
 2a0caa0:	sete   %al
 2a0caa3:	movzbl %al,%eax
 2a0caa6:	test   %eax,%eax
 2a0caa8:	je     2a0cabb <wasm[0]::function[1015]::helper::object_read+0xe95b>
 2a0caae:	mov    $0x7,%edx
 2a0cab3:	mov    %rdx,0x278(%rsp)
 2a0cabb:	mov    0x278(%rsp),%rdx
 2a0cac3:	cmp    $0x1,%edx
 2a0cac6:	je     2a0cb5b <wasm[0]::function[1015]::helper::object_read+0xe9fb>
 2a0cacc:	mov    0xb8(%rsp),%eax
 2a0cad3:	test   %eax,%eax
 2a0cad5:	je     2a195ae <wasm[0]::function[1015]::helper::object_read+0x1b44e>
 2a0cadb:	mov    0x80(%rsp),%edi
 2a0cae2:	mov    0x58(%rsp),%edx
 2a0cae6:	mov    0x48(%rsp),%esi
 2a0caea:	xor    %rcx,%rcx
 2a0caed:	mov    0x1b0(%rsp),%r13
 2a0caf5:	mov    %r13,(%rsp)
 2a0caf9:	mov    %edi,0x8(%rsp)
 2a0cafd:	mov    0x1b8(%rsp),%rdi
 2a0cb05:	mov    %edi,0x10(%rsp)
 2a0cb09:	mov    0x1c0(%rsp),%rdi
 2a0cb11:	mov    %rdi,0x18(%rsp)
 2a0cb16:	mov    %edx,0x20(%rsp)
 2a0cb1a:	mov    %esi,0x28(%rsp)
 2a0cb1e:	mov    %eax,0x30(%rsp)
 2a0cb22:	mov    0x278(%rsp),%rdx
 2a0cb2a:	mov    0x190(%rsp),%rsi
 2a0cb32:	mov    0x1a8(%rsp),%r9
 2a0cb3a:	mov    %rsi,%rdi
 2a0cb3d:	call   29fe160 <wasm[0]::function[1015]::helper::object_read>
 2a0cb42:	sub    $0x40,%rsp
 2a0cb46:	mov    %rax,0x280(%rsp)
 2a0cb4e:	mov    %rcx,0x288(%rsp)
 2a0cb56:	jmp    2a0cf9a <wasm[0]::function[1015]::helper::object_read+0xee3a>
 2a0cb5b:	mov    %rax,%rcx
 2a0cb5e:	mov    %rax,0x280(%rsp)
 2a0cb66:	xor    %ecx,%eax
 2a0cb68:	mov    %rax,0x280(%rsp)
 2a0cb70:	mov    %rcx,%rax
 2a0cb73:	mov    %rcx,0x288(%rsp)
 2a0cb7b:	xor    %rax,%rcx
 2a0cb7e:	mov    %rcx,0x288(%rsp)
 2a0cb86:	mov    0x280(%rsp),%rdx
 2a0cb8e:	mov    0x280(%rsp),%rsi
 2a0cb96:	mov    0x280(%rsp),%rdi
 2a0cb9e:	jmp    2a0cf9a <wasm[0]::function[1015]::helper::object_read+0xee3a>
 2a0cba3:	mov    %rax,%rcx
 2a0cba6:	mov    %rax,0x280(%rsp)
 2a0cbae:	xor    %ecx,%eax
 2a0cbb0:	mov    %rax,0x280(%rsp)
 2a0cbb8:	mov    %rcx,%rsi
 2a0cbbb:	mov    %rcx,0x288(%rsp)
 2a0cbc3:	xor    %rsi,%rcx
 2a0cbc6:	mov    %rcx,0x288(%rsp)
 2a0cbce:	mov    0x280(%rsp),%rdx
 2a0cbd6:	mov    0x280(%rsp),%rsi
 2a0cbde:	mov    0x280(%rsp),%rdi
 2a0cbe6:	jmp    2a0cf9a <wasm[0]::function[1015]::helper::object_read+0xee3a>
 2a0cbeb:	mov    %r15,%rax
 2a0cbee:	mov    %r15,%rcx
 2a0cbf1:	mov    0x1a8(%rsp),%r9
 2a0cbf9:	mov    0x1b0(%rsp),%r13
 2a0cc01:	test   %ecx,%eax
 2a0cc03:	jne    2a0cc10 <wasm[0]::function[1015]::helper::object_read+0xeab0>
 2a0cc09:	xor    %ecx,%ecx
 2a0cc0b:	jmp    2a0cc4b <wasm[0]::function[1015]::helper::object_read+0xeaeb>
 2a0cc10:	mov    %r15,%rax
 2a0cc13:	mov    %r15,%rcx
 2a0cc16:	test   %ecx,%eax
 2a0cc18:	je     2a195b0 <wasm[0]::function[1015]::helper::object_read+0x1b450>
 2a0cc1e:	mov    0x2e0(%rsp),%r14
 2a0cc26:	mov    0x28(%r14),%rax
 2a0cc2a:	mov    %ecx,%edx
 2a0cc2c:	mov    %rdx,%rcx
 2a0cc2f:	add    0x20(%r14),%rcx
 2a0cc33:	xor    %rsi,%rsi
 2a0cc36:	cmp    %rax,%rdx
 2a0cc39:	cmova  %rsi,%rcx
 2a0cc3d:	mov    0x10(%rcx),%eax
 2a0cc40:	test   $0x1,%eax
 2a0cc45:	setne  %al
 2a0cc48:	movzbl %al,%ecx
 2a0cc4b:	test   %ecx,%ecx
 2a0cc4d:	jne    2a0ce24 <wasm[0]::function[1015]::helper::object_read+0xecc4>
 2a0cc53:	mov    %rax,%rcx
 2a0cc56:	mov    %rax,0x280(%rsp)
 2a0cc5e:	xor    %ecx,%eax
 2a0cc60:	mov    %rax,0x280(%rsp)
 2a0cc68:	mov    %rcx,%rax
 2a0cc6b:	mov    %rcx,0x288(%rsp)
 2a0cc73:	xor    %rax,%rcx
 2a0cc76:	mov    %rcx,0x288(%rsp)
 2a0cc7e:	mov    %r15,%rcx
 2a0cc81:	mov    %r15,%rax
 2a0cc84:	test   %ecx,%eax
 2a0cc86:	jne    2a0cc99 <wasm[0]::function[1015]::helper::object_read+0xeb39>
 2a0cc8c:	mov    0x280(%rsp),%rdx
 2a0cc94:	jmp    2a0ce1a <wasm[0]::function[1015]::helper::object_read+0xecba>
 2a0cc99:	mov    %r15,%rax
 2a0cc9c:	mov    %r15,%rdx
 2a0cc9f:	test   %edx,%eax
 2a0cca1:	je     2a195b2 <wasm[0]::function[1015]::helper::object_read+0x1b452>
 2a0cca7:	mov    0x2e0(%rsp),%r14
 2a0ccaf:	mov    0x28(%r14),%rax
 2a0ccb3:	mov    0x20(%r14),%rcx
 2a0ccb7:	mov    %r15,%r8
 2a0ccba:	mov    %r8d,%edx
 2a0ccbd:	add    %rdx,%rcx
 2a0ccc0:	xor    %rsi,%rsi
 2a0ccc3:	cmp    %rax,%rdx
 2a0ccc6:	cmova  %rsi,%rcx
 2a0ccca:	mov    0x14(%rcx),%edx
 2a0cccd:	test   %edx,%edx
 2a0cccf:	je     2a195b4 <wasm[0]::function[1015]::helper::object_read+0x1b454>
 2a0ccd5:	xor    %eax,%eax
 2a0ccd7:	test   $0x1,%edx
 2a0ccdd:	jne    2a0cd20 <wasm[0]::function[1015]::helper::object_read+0xebc0>
 2a0cce3:	mov    0x2e0(%rsp),%r14
 2a0cceb:	mov    0x28(%r14),%rcx
 2a0ccef:	mov    0x20(%r14),%rdi
 2a0ccf3:	mov    %edx,%esi
 2a0ccf5:	lea    0x4(%rdi,%rsi,1),%rax
 2a0ccfa:	xor    %rdi,%rdi
 2a0ccfd:	cmp    %rcx,%rsi
 2a0cd00:	cmova  %rdi,%rax
 2a0cd04:	mov    (%rax),%esi
 2a0cd06:	mov    0x190(%rsp),%rax
 2a0cd0e:	mov    0x28(%rax),%rdi
 2a0cd12:	cmp    0x120(%rdi),%esi
 2a0cd18:	sete   %sil
 2a0cd1c:	movzbl %sil,%eax
 2a0cd20:	test   %eax,%eax
 2a0cd22:	jne    2a0cd88 <wasm[0]::function[1015]::helper::object_read+0xec28>
 2a0cd28:	mov    0x190(%rsp),%rsi
 2a0cd30:	mov    %rsi,%rdi
 2a0cd33:	call   2a1eec0 <wasm[0]::function[1024]::helper::property_value_resolve>
 2a0cd38:	test   %eax,%eax
 2a0cd3a:	je     2a195b6 <wasm[0]::function[1015]::helper::object_read+0x1b456>
 2a0cd40:	test   %eax,%eax
 2a0cd42:	je     2a195b8 <wasm[0]::function[1015]::helper::object_read+0x1b458>
 2a0cd48:	mov    0x2e0(%rsp),%r14
 2a0cd50:	mov    0x28(%r14),%r10
 2a0cd54:	mov    0x20(%r14),%rcx
 2a0cd58:	mov    %eax,%r11d
 2a0cd5b:	lea    (%rcx,%r11,1),%rdi
 2a0cd5f:	xor    %rax,%rax
 2a0cd62:	cmp    %r10,%r11
 2a0cd65:	cmova  %rax,%rdi
 2a0cd69:	mov    0x18(%rdi),%eax
 2a0cd6c:	mov    %rax,0x280(%rsp)
 2a0cd74:	mov    0x10(%rdi),%rcx
 2a0cd78:	mov    %rcx,0x288(%rsp)
 2a0cd80:	mov    0x1c(%rdi),%edx
 2a0cd83:	jmp    2a0ce1a <wasm[0]::function[1015]::helper::object_read+0xecba>
 2a0cd88:	xor    %eax,%eax
 2a0cd8a:	test   $0x1,%edx
 2a0cd90:	jne    2a0cdd1 <wasm[0]::function[1015]::helper::object_read+0xec71>
 2a0cd96:	mov    0x2e0(%rsp),%r14
 2a0cd9e:	mov    0x28(%r14),%rax
 2a0cda2:	mov    0x20(%r14),%rcx
 2a0cda6:	mov    %edx,%esi
 2a0cda8:	lea    0x4(%rcx,%rsi,1),%rcx
 2a0cdad:	xor    %rdi,%rdi
 2a0cdb0:	cmp    %rax,%rsi
 2a0cdb3:	cmova  %rdi,%rcx
 2a0cdb7:	mov    (%rcx),%eax
 2a0cdb9:	mov    0x190(%rsp),%rsi
 2a0cdc1:	mov    0x28(%rsi),%rcx
 2a0cdc5:	cmp    0x120(%rcx),%eax
 2a0cdcb:	sete   %al
 2a0cdce:	movzbl %al,%eax
 2a0cdd1:	test   %eax,%eax
 2a0cdd3:	je     2a195ba <wasm[0]::function[1015]::helper::object_read+0x1b45a>
 2a0cdd9:	test   %edx,%edx
 2a0cddb:	je     2a195bc <wasm[0]::function[1015]::helper::object_read+0x1b45c>
 2a0cde1:	mov    0x2e0(%rsp),%r14
 2a0cde9:	mov    0x28(%r14),%rcx
 2a0cded:	mov    0x20(%r14),%rax
 2a0cdf1:	mov    %edx,%edx
 2a0cdf3:	add    %rdx,%rax
 2a0cdf6:	xor    %rsi,%rsi
 2a0cdf9:	cmp    %rcx,%rdx
 2a0cdfc:	cmova  %rsi,%rax
 2a0ce00:	mov    0x18(%rax),%ecx
 2a0ce03:	mov    %rcx,0x280(%rsp)
 2a0ce0b:	mov    0x10(%rax),%rcx
 2a0ce0f:	mov    %rcx,0x288(%rsp)
 2a0ce17:	mov    0x1c(%rax),%edx
 2a0ce1a:	xor    %esi,%esi
 2a0ce1c:	mov    %rsi,%rdi
 2a0ce1f:	jmp    2a0cf9a <wasm[0]::function[1015]::helper::object_read+0xee3a>
 2a0ce24:	xor    %edx,%edx
 2a0ce26:	xor    %rcx,%rcx
 2a0ce29:	mov    %r15,%rax
 2a0ce2c:	mov    %r15,%rsi
 2a0ce2f:	test   %esi,%eax
 2a0ce31:	jne    2a0ce3f <wasm[0]::function[1015]::helper::object_read+0xecdf>
 2a0ce37:	mov    %rdx,%r8
 2a0ce3a:	jmp    2a0ce9b <wasm[0]::function[1015]::helper::object_read+0xed3b>
 2a0ce3f:	mov    %r15,%rax
 2a0ce42:	mov    %r15,%rcx
 2a0ce45:	test   %ecx,%eax
 2a0ce47:	je     2a195be <wasm[0]::function[1015]::helper::object_read+0x1b45e>
 2a0ce4d:	mov    0x2e0(%rsp),%r14
 2a0ce55:	mov    0x28(%r14),%rax
 2a0ce59:	mov    0x20(%r14),%rcx
 2a0ce5d:	mov    %r15,%rdx
 2a0ce60:	mov    %edx,%edi
 2a0ce62:	lea    (%rcx,%rdi,1),%rsi
 2a0ce66:	xor    %rdx,%rdx
 2a0ce69:	cmp    %rax,%rdi
 2a0ce6c:	cmova  %rdx,%rsi
 2a0ce70:	mov    0x18(%rsi),%esi
 2a0ce73:	test   %esi,%esi
 2a0ce75:	je     2a195c0 <wasm[0]::function[1015]::helper::object_read+0x1b460>
 2a0ce7b:	test   %esi,%esi
 2a0ce7d:	je     2a195c2 <wasm[0]::function[1015]::helper::object_read+0x1b462>
 2a0ce83:	mov    %esi,%edi
 2a0ce85:	lea    (%rcx,%rdi,1),%rsi
 2a0ce89:	cmp    %rax,%rdi
 2a0ce8c:	cmova  %rdx,%rsi
 2a0ce90:	mov    0x18(%rsi),%edx
 2a0ce93:	mov    0x10(%rsi),%rcx
 2a0ce97:	mov    0x1c(%rsi),%r8d
 2a0ce9b:	test   %edx,%edx
 2a0ce9d:	je     2a0cf57 <wasm[0]::function[1015]::helper::object_read+0xedf7>
 2a0cea3:	mov    0x190(%rsp),%rsi
 2a0ceab:	mov    0x9a0(%rsi),%eax
 2a0ceb1:	mov    0x8c0(%rsi),%esi
 2a0ceb7:	mov    %esi,0x58(%rsp)
 2a0cebb:	test   %esi,%esi
 2a0cebd:	je     2a195c4 <wasm[0]::function[1015]::helper::object_read+0x1b464>
 2a0cec3:	test   %eax,%eax
 2a0cec5:	je     2a195c6 <wasm[0]::function[1015]::helper::object_read+0x1b466>
 2a0cecb:	mov    0xb8(%rsp),%edi
 2a0ced2:	test   %edi,%edi
 2a0ced4:	je     2a195c8 <wasm[0]::function[1015]::helper::object_read+0x1b468>
 2a0ceda:	mov    0x80(%rsp),%r11d
 2a0cee2:	mov    0x48(%rsp),%r10d
 2a0cee7:	mov    %r13,(%rsp)
 2a0ceeb:	mov    %r11d,0x8(%rsp)
 2a0cef0:	mov    %eax,0x10(%rsp)
 2a0cef4:	mov    %esi,0x18(%rsp)
 2a0cef8:	mov    %r10d,0x20(%rsp)
 2a0cefd:	mov    %edi,0x28(%rsp)
 2a0cf01:	mov    0x190(%rsp),%rsi
 2a0cf09:	mov    0x190(%rsp),%rdi
 2a0cf11:	call   2afc220 <wasm[0]::function[1055]::helper::proxy_call>
 2a0cf16:	sub    $0x30,%rsp
 2a0cf1a:	mov    %rax,0x280(%rsp)
 2a0cf22:	mov    %rcx,0x288(%rsp)
 2a0cf2a:	mov    0x58(%rsp),%eax
 2a0cf2e:	test   %eax,%eax
 2a0cf30:	je     2a195ca <wasm[0]::function[1015]::helper::object_read+0x1b46a>
 2a0cf36:	mov    0x190(%rsp),%rcx
 2a0cf3e:	mov    %eax,0x8c0(%rcx)
 2a0cf44:	cmp    $0x2,%esi
 2a0cf47:	jne    2a0cf9a <wasm[0]::function[1015]::helper::object_read+0xee3a>
 2a0cf4d:	xor    %esi,%esi
 2a0cf4f:	mov    %rsi,%rdi
 2a0cf52:	jmp    2a0cf9a <wasm[0]::function[1015]::helper::object_read+0xee3a>
 2a0cf57:	mov    %rax,%rcx
 2a0cf5a:	mov    %rax,0x280(%rsp)
 2a0cf62:	xor    %ecx,%eax
 2a0cf64:	mov    %rax,0x280(%rsp)
 2a0cf6c:	mov    %rcx,%rax
 2a0cf6f:	mov    %rcx,0x288(%rsp)
 2a0cf77:	xor    %rax,%rcx
 2a0cf7a:	mov    %rcx,0x288(%rsp)
 2a0cf82:	mov    0x280(%rsp),%rdx
 2a0cf8a:	mov    0x280(%rsp),%rsi
 2a0cf92:	mov    0x280(%rsp),%rdi
 2a0cf9a:	mov    %rdx,%rax
 2a0cf9d:	mov    %rdi,0x298(%rsp)
 2a0cfa5:	jmp    2a1776e <wasm[0]::function[1015]::helper::object_read+0x1960e>
 2a0cfaa:	mov    0x1b0(%rsp),%r13
 2a0cfb2:	xor    %eax,%eax
 2a0cfb4:	test   %edx,%edx
 2a0cfb6:	je     2a0d009 <wasm[0]::function[1015]::helper::object_read+0xeea9>
 2a0cfbc:	xor    %eax,%eax
 2a0cfbe:	test   $0x1,%edx
 2a0cfc4:	jne    2a0d009 <wasm[0]::function[1015]::helper::object_read+0xeea9>
 2a0cfca:	mov    0x2e0(%rsp),%r14
 2a0cfd2:	mov    0x28(%r14),%rsi
 2a0cfd6:	mov    0x20(%r14),%rdi
 2a0cfda:	mov    %edx,%r8d
 2a0cfdd:	lea    0x4(%rdi,%r8,1),%rdi
 2a0cfe2:	xor    %r9,%r9
 2a0cfe5:	cmp    %rsi,%r8
 2a0cfe8:	cmova  %r9,%rdi
 2a0cfec:	mov    (%rdi),%edi
 2a0cfee:	mov    0x190(%rsp),%rsi
 2a0cff6:	mov    0x28(%rsi),%r8
 2a0cffa:	cmp    0x1e8(%r8),%edi
 2a0d001:	sete   %r8b
 2a0d005:	movzbl %r8b,%eax
 2a0d009:	test   %eax,%eax
 2a0d00b:	je     2a195cc <wasm[0]::function[1015]::helper::object_read+0x1b46c>
 2a0d011:	test   %edx,%edx
 2a0d013:	je     2a195ce <wasm[0]::function[1015]::helper::object_read+0x1b46e>
 2a0d019:	test   %edx,%edx
 2a0d01b:	je     2a195d0 <wasm[0]::function[1015]::helper::object_read+0x1b470>
 2a0d021:	mov    0x2e0(%rsp),%r14
 2a0d029:	mov    0x28(%r14),%rax
 2a0d02d:	mov    0x20(%r14),%rcx
 2a0d031:	mov    %edx,%edi
 2a0d033:	lea    (%rcx,%rdi,1),%rsi
 2a0d037:	xor    %rdx,%rdx
 2a0d03a:	cmp    %rax,%rdi
 2a0d03d:	cmova  %rdx,%rsi
 2a0d041:	mov    0x14(%rsi),%edi
 2a0d044:	test   %edi,%edi
 2a0d046:	je     2a195d2 <wasm[0]::function[1015]::helper::object_read+0x1b472>
 2a0d04c:	test   %edi,%edi
 2a0d04e:	je     2a195d4 <wasm[0]::function[1015]::helper::object_read+0x1b474>
 2a0d054:	mov    %edi,%r8d
 2a0d057:	lea    (%rcx,%r8,1),%rdi
 2a0d05b:	cmp    %rax,%r8
 2a0d05e:	cmova  %rdx,%rdi
 2a0d062:	mov    0x18(%rdi),%r8d
 2a0d066:	mov    %r8,0x2a8(%rsp)
 2a0d06e:	mov    0x10(%rdi),%r8
 2a0d072:	mov    %r8,0x2a0(%rsp)
 2a0d07a:	mov    0x1c(%rdi),%edi
 2a0d07d:	mov    %edi,0x58(%rsp)
 2a0d081:	mov    0x18(%rsi),%esi
 2a0d084:	test   %esi,%esi
 2a0d086:	je     2a195d6 <wasm[0]::function[1015]::helper::object_read+0x1b476>
 2a0d08c:	test   %esi,%esi
 2a0d08e:	je     2a195d8 <wasm[0]::function[1015]::helper::object_read+0x1b478>
 2a0d094:	mov    %esi,%esi
 2a0d096:	add    %rsi,%rcx
 2a0d099:	cmp    %rax,%rsi
 2a0d09c:	cmova  %rdx,%rcx
 2a0d0a0:	mov    0x18(%rcx),%ebx
 2a0d0a3:	mov    0x10(%rcx),%r12
 2a0d0a7:	mov    0x1c(%rcx),%eax
 2a0d0aa:	mov    %eax,0x80(%rsp)
 2a0d0b1:	cmp    $0x1,%ebx
 2a0d0b4:	je     2a174c3 <wasm[0]::function[1015]::helper::object_read+0x19363>
 2a0d0ba:	mov    $0x27b,%edx
 2a0d0bf:	mov    %rdx,0x198(%rsp)
 2a0d0c7:	mov    0x190(%rsp),%rsi
 2a0d0cf:	mov    0x190(%rsp),%rdi
 2a0d0d7:	call   2f4f240 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 2a0d0dc:	test   %eax,%eax
 2a0d0de:	je     2a195da <wasm[0]::function[1015]::helper::object_read+0x1b47a>
 2a0d0e4:	mov    0x70(%rsp),%ecx
 2a0d0e8:	test   %ecx,%ecx
 2a0d0ea:	je     2a195dc <wasm[0]::function[1015]::helper::object_read+0x1b47c>
 2a0d0f0:	mov    0x80(%rsp),%r8d
 2a0d0f8:	mov    0x50(%rsp),%edx
 2a0d0fc:	mov    $0x4,%esi
 2a0d101:	xor    %rdi,%rdi
 2a0d104:	mov    %r12,(%rsp)
 2a0d108:	mov    %r8d,0x8(%rsp)
 2a0d10d:	mov    %esi,0x10(%rsp)
 2a0d111:	mov    %rdi,0x18(%rsp)
 2a0d116:	mov    %eax,0x20(%rsp)
 2a0d11a:	mov    %edx,0x28(%rsp)
 2a0d11e:	mov    %ecx,0x30(%rsp)
 2a0d122:	mov    %r12,%rcx
 2a0d125:	mov    %rbx,%rdx
 2a0d128:	mov    0x190(%rsp),%rsi
 2a0d130:	mov    0x190(%rsp),%rdi
 2a0d138:	mov    %rbx,%r9
 2a0d13b:	call   29fe160 <wasm[0]::function[1015]::helper::object_read>
 2a0d140:	sub    $0x40,%rsp
 2a0d144:	mov    %rcx,%r15
 2a0d147:	mov    %edx,0x48(%rsp)
 2a0d14b:	cmp    $0x1,%esi
 2a0d14e:	je     2a1749a <wasm[0]::function[1015]::helper::object_read+0x1933a>
 2a0d154:	test   %eax,%eax
 2a0d156:	sete   %cl
 2a0d159:	cmp    $0x1,%eax
 2a0d15c:	mov    %rax,0x270(%rsp)
 2a0d164:	sete   %al
 2a0d167:	or     %eax,%ecx
 2a0d169:	test   %cl,%cl
 2a0d16b:	jne    2a17401 <wasm[0]::function[1015]::helper::object_read+0x192a1>
 2a0d171:	xor    %ecx,%ecx
 2a0d173:	test   %edx,%edx
 2a0d175:	je     2a0d1c4 <wasm[0]::function[1015]::helper::object_read+0xf064>
 2a0d17b:	xor    %ecx,%ecx
 2a0d17d:	test   $0x1,%edx
 2a0d183:	jne    2a0d1c4 <wasm[0]::function[1015]::helper::object_read+0xf064>
 2a0d189:	mov    0x2e0(%rsp),%r14
 2a0d191:	mov    0x28(%r14),%rax
 2a0d195:	mov    0x20(%r14),%rcx
 2a0d199:	mov    %edx,%esi
 2a0d19b:	lea    0x4(%rcx,%rsi,1),%rcx
 2a0d1a0:	xor    %rdi,%rdi
 2a0d1a3:	cmp    %rax,%rsi
 2a0d1a6:	cmova  %rdi,%rcx
 2a0d1aa:	mov    (%rcx),%eax
 2a0d1ac:	mov    0x190(%rsp),%rsi
 2a0d1b4:	mov    0x28(%rsi),%rcx
 2a0d1b8:	cmp    0x1d4(%rcx),%eax
 2a0d1be:	sete   %al
 2a0d1c1:	movzbl %al,%ecx
 2a0d1c4:	xor    %eax,%eax
 2a0d1c6:	test   %edx,%edx
 2a0d1c8:	je     2a0d217 <wasm[0]::function[1015]::helper::object_read+0xf0b7>
 2a0d1ce:	xor    %eax,%eax
 2a0d1d0:	test   $0x1,%edx
 2a0d1d6:	jne    2a0d217 <wasm[0]::function[1015]::helper::object_read+0xf0b7>
 2a0d1dc:	mov    0x2e0(%rsp),%r14
 2a0d1e4:	mov    0x28(%r14),%rax
 2a0d1e8:	mov    0x20(%r14),%rsi
 2a0d1ec:	mov    %edx,%edi
 2a0d1ee:	lea    0x4(%rsi,%rdi,1),%rsi
 2a0d1f3:	xor    %r8,%r8
 2a0d1f6:	cmp    %rax,%rdi
 2a0d1f9:	cmova  %r8,%rsi
 2a0d1fd:	mov    (%rsi),%eax
 2a0d1ff:	mov    0x190(%rsp),%rsi
 2a0d207:	mov    0x28(%rsi),%rsi
 2a0d20b:	cmp    0x1e4(%rsi),%eax
 2a0d211:	sete   %al
 2a0d214:	movzbl %al,%eax
 2a0d217:	or     %eax,%ecx
 2a0d219:	test   %ecx,%ecx
 2a0d21b:	jne    2a0d322 <wasm[0]::function[1015]::helper::object_read+0xf1c2>
 2a0d221:	xor    %esi,%esi
 2a0d223:	test   %edx,%edx
 2a0d225:	je     2a0d279 <wasm[0]::function[1015]::helper::object_read+0xf119>
 2a0d22b:	xor    %esi,%esi
 2a0d22d:	test   $0x1,%edx
 2a0d233:	jne    2a0d279 <wasm[0]::function[1015]::helper::object_read+0xf119>
 2a0d239:	mov    0x2e0(%rsp),%r14
 2a0d241:	mov    0x28(%r14),%rdi
 2a0d245:	mov    0x20(%r14),%r9
 2a0d249:	mov    %edx,%r8d
 2a0d24c:	lea    0x4(%r9,%r8,1),%rsi
 2a0d251:	xor    %r9,%r9
 2a0d254:	cmp    %rdi,%r8
 2a0d257:	cmova  %r9,%rsi
 2a0d25b:	mov    (%rsi),%r8d
 2a0d25e:	mov    0x190(%rsp),%rsi
 2a0d266:	mov    0x28(%rsi),%r9
 2a0d26a:	cmp    0x1e8(%r9),%r8d
 2a0d271:	sete   %r9b
 2a0d275:	movzbl %r9b,%esi
 2a0d279:	test   %esi,%esi
 2a0d27b:	jne    2a0d288 <wasm[0]::function[1015]::helper::object_read+0xf128>
 2a0d281:	xor    %eax,%eax
 2a0d283:	jmp    2a0d32a <wasm[0]::function[1015]::helper::object_read+0xf1ca>
 2a0d288:	xor    %eax,%eax
 2a0d28a:	test   %edx,%edx
 2a0d28c:	je     2a0d2db <wasm[0]::function[1015]::helper::object_read+0xf17b>
 2a0d292:	xor    %eax,%eax
 2a0d294:	test   $0x1,%edx
 2a0d29a:	jne    2a0d2db <wasm[0]::function[1015]::helper::object_read+0xf17b>
 2a0d2a0:	mov    0x2e0(%rsp),%r14
 2a0d2a8:	mov    0x28(%r14),%rax
 2a0d2ac:	mov    0x20(%r14),%rcx
 2a0d2b0:	mov    %edx,%esi
 2a0d2b2:	lea    0x4(%rcx,%rsi,1),%rcx
 2a0d2b7:	xor    %rdi,%rdi
 2a0d2ba:	cmp    %rax,%rsi
 2a0d2bd:	cmova  %rdi,%rcx
 2a0d2c1:	mov    (%rcx),%eax
 2a0d2c3:	mov    0x190(%rsp),%rsi
 2a0d2cb:	mov    0x28(%rsi),%rcx
 2a0d2cf:	cmp    0x1e8(%rcx),%eax
 2a0d2d5:	sete   %al
 2a0d2d8:	movzbl %al,%eax
 2a0d2db:	test   %eax,%eax
 2a0d2dd:	je     2a195de <wasm[0]::function[1015]::helper::object_read+0x1b47e>
 2a0d2e3:	test   %edx,%edx
 2a0d2e5:	je     2a195e0 <wasm[0]::function[1015]::helper::object_read+0x1b480>
 2a0d2eb:	test   %edx,%edx
 2a0d2ed:	je     2a195e2 <wasm[0]::function[1015]::helper::object_read+0x1b482>
 2a0d2f3:	mov    0x2e0(%rsp),%r14
 2a0d2fb:	mov    0x28(%r14),%rax
 2a0d2ff:	mov    %edx,%edx
 2a0d301:	mov    %rdx,%rcx
 2a0d304:	add    0x20(%r14),%rcx
 2a0d308:	xor    %rsi,%rsi
 2a0d30b:	cmp    %rax,%rdx
 2a0d30e:	cmova  %rsi,%rcx
 2a0d312:	mov    0x1c(%rcx),%eax
 2a0d315:	test   %eax,%eax
 2a0d317:	setne  %al
 2a0d31a:	movzbl %al,%eax
 2a0d31d:	jmp    2a0d32a <wasm[0]::function[1015]::helper::object_read+0xf1ca>
 2a0d322:	mov    0x278(%rsp),%rax
 2a0d32a:	test   %eax,%eax
 2a0d32c:	je     2a1717b <wasm[0]::function[1015]::helper::object_read+0x1901b>
 2a0d332:	mov    0x190(%rsp),%rsi
 2a0d33a:	mov    0x20(%rsi),%rcx
 2a0d33e:	mov    (%rcx),%eax
 2a0d340:	mov    %eax,%edx
 2a0d342:	mov    $0x20,%esi
 2a0d347:	mov    %rsi,0x260(%rsp)
 2a0d34f:	lea    0x20(%rdx),%rsi
 2a0d353:	mov    0x4(%rcx),%edi
 2a0d356:	mov    %rcx,0x268(%rsp)
 2a0d35e:	cmp    %rdi,%rsi
 2a0d361:	ja     2a183e2 <wasm[0]::function[1015]::helper::object_read+0x1a282>
 2a0d367:	lea    0x20(%rax),%esi
 2a0d36a:	mov    0x268(%rsp),%rcx
 2a0d372:	mov    %esi,(%rcx)
 2a0d374:	mov    0x2e0(%rsp),%r14
 2a0d37c:	mov    0x20(%r14),%rdi
 2a0d380:	lea    (%rdi,%rdx,1),%rsi
 2a0d384:	movl   $0xb0000042,(%rdi,%rdx,1)
 2a0d38b:	mov    0x190(%rsp),%r8
 2a0d393:	mov    0x28(%r8),%r8
 2a0d397:	mov    0x120(%r8),%r8d
 2a0d39e:	mov    %r8d,0x4(%rdi,%rdx,1)
 2a0d3a3:	mov    0x260(%rsp),%r8
 2a0d3ab:	mov    %r8d,0x8(%rdi,%rdx,1)
 2a0d3b0:	mov    %eax,0xb8(%rsp)
 2a0d3b7:	mov    0x2a0(%rsp),%rax
 2a0d3bf:	mov    %rax,0x10(%rsi)
 2a0d3c3:	mov    0x2a8(%rsp),%rdx
 2a0d3cb:	mov    %edx,0x18(%rsi)
 2a0d3ce:	mov    0x58(%rsp),%eax
 2a0d3d2:	mov    %eax,0x1c(%rsi)
 2a0d3d5:	mov    (%rcx),%eax
 2a0d3d7:	mov    %eax,%edx
 2a0d3d9:	lea    0x20(%rdx),%rsi
 2a0d3dd:	mov    0x4(%rcx),%edi
 2a0d3e0:	mov    %rcx,0x268(%rsp)
 2a0d3e8:	cmp    %rdi,%rsi
 2a0d3eb:	ja     2a1842c <wasm[0]::function[1015]::helper::object_read+0x1a2cc>
 2a0d3f1:	lea    0x20(%rax),%ecx
 2a0d3f4:	mov    0x268(%rsp),%r10
 2a0d3fc:	mov    %ecx,(%r10)
 2a0d3ff:	mov    0x2e0(%rsp),%r14
 2a0d407:	mov    0x20(%r14),%rcx
 2a0d40b:	lea    (%rcx,%rdx,1),%r9
 2a0d40f:	movl   $0xb0000042,(%rcx,%rdx,1)
 2a0d416:	mov    0x190(%rsp),%rsi
 2a0d41e:	mov    0x28(%rsi),%rsi
 2a0d422:	mov    0x120(%rsi),%esi
 2a0d428:	mov    %esi,0x4(%rcx,%rdx,1)
 2a0d42c:	mov    0x260(%rsp),%rsi
 2a0d434:	mov    %esi,0x8(%rcx,%rdx,1)
 2a0d438:	mov    %eax,0xa8(%rsp)
 2a0d43f:	mov    0x1c0(%rsp),%r8
 2a0d447:	mov    %r8,0x10(%r9)
 2a0d44b:	mov    0x1b8(%rsp),%rcx
 2a0d453:	mov    %ecx,0x18(%r9)
 2a0d457:	mov    0x68(%rsp),%eax
 2a0d45b:	mov    %eax,0x1c(%r9)
 2a0d45f:	mov    0x268(%rsp),%rcx
 2a0d467:	mov    (%rcx),%eax
 2a0d469:	mov    %eax,%edx
 2a0d46b:	lea    0x20(%rdx),%rcx
 2a0d46f:	mov    0x268(%rsp),%rsi
 2a0d477:	mov    0x4(%rsi),%esi
 2a0d47a:	cmp    %rsi,%rcx
 2a0d47d:	ja     2a18467 <wasm[0]::function[1015]::helper::object_read+0x1a307>
 2a0d483:	lea    0x20(%rax),%ecx
 2a0d486:	mov    0x268(%rsp),%rsi
 2a0d48e:	mov    %ecx,(%rsi)
 2a0d490:	mov    0x2e0(%rsp),%r14
 2a0d498:	mov    0x20(%r14),%rsi
 2a0d49c:	lea    (%rsi,%rdx,1),%rcx
 2a0d4a0:	movl   $0xb0000042,(%rsi,%rdx,1)
 2a0d4a7:	mov    0x190(%rsp),%rdi
 2a0d4af:	mov    0x28(%rdi),%rdi
 2a0d4b3:	mov    0x120(%rdi),%edi
 2a0d4b9:	mov    %edi,0x4(%rsi,%rdx,1)
 2a0d4bd:	mov    0x260(%rsp),%rdi
 2a0d4c5:	mov    %edi,0x8(%rsi,%rdx,1)
 2a0d4c9:	mov    %eax,0xa0(%rsp)
 2a0d4d0:	mov    %r13,0x10(%rcx)
 2a0d4d4:	mov    0x1a8(%rsp),%r9
 2a0d4dc:	mov    %r9d,0x18(%rcx)
 2a0d4e0:	mov    0x60(%rsp),%edi
 2a0d4e4:	mov    %edi,0x1c(%rcx)
 2a0d4e7:	mov    0xb8(%rsp),%r8d
 2a0d4ef:	test   %r8d,%r8d
 2a0d4f2:	je     2a195e4 <wasm[0]::function[1015]::helper::object_read+0x1b484>
 2a0d4f8:	mov    0xa8(%rsp),%r10d
 2a0d500:	test   %r10d,%r10d
 2a0d503:	je     2a195e6 <wasm[0]::function[1015]::helper::object_read+0x1b486>
 2a0d509:	test   %eax,%eax
 2a0d50b:	je     2a195e8 <wasm[0]::function[1015]::helper::object_read+0x1b488>
 2a0d511:	mov    0x268(%rsp),%rcx
 2a0d519:	mov    (%rcx),%eax
 2a0d51b:	mov    %eax,%ecx
 2a0d51d:	lea    0x20(%rcx),%rdx
 2a0d521:	mov    0x268(%rsp),%rdi
 2a0d529:	mov    0x4(%rdi),%esi
 2a0d52c:	cmp    %rsi,%rdx
 2a0d52f:	ja     2a184a9 <wasm[0]::function[1015]::helper::object_read+0x1a349>
 2a0d535:	lea    0x20(%rax),%edx
 2a0d538:	mov    0x268(%rsp),%rsi
 2a0d540:	mov    %edx,(%rsi)
 2a0d542:	mov    0x2e0(%rsp),%r14
 2a0d54a:	mov    0x20(%r14),%rsi
 2a0d54e:	lea    (%rsi,%rcx,1),%rdx
 2a0d552:	movl   $0xa800000e,(%rsi,%rcx,1)
 2a0d559:	mov    0x190(%rsp),%rdi
 2a0d561:	mov    0x28(%rdi),%rdi
 2a0d565:	mov    0x1b4(%rdi),%edi
 2a0d56b:	mov    %edi,0x4(%rsi,%rcx,1)
 2a0d56f:	mov    0x260(%rsp),%rdi
 2a0d577:	mov    %edi,0x8(%rsi,%rcx,1)
 2a0d57b:	movl   $0x3,0x10(%rdx)
 2a0d582:	test   %eax,%eax
 2a0d584:	je     2a195ea <wasm[0]::function[1015]::helper::object_read+0x1b48a>
 2a0d58a:	mov    0x2e0(%rsp),%r14
 2a0d592:	mov    0x28(%r14),%rcx
 2a0d596:	mov    0x20(%r14),%rdx
 2a0d59a:	mov    %eax,%r8d
 2a0d59d:	lea    0x10(%rdx,%r8,1),%rdi
 2a0d5a2:	xor    %rsi,%rsi
 2a0d5a5:	cmp    %rcx,%r8
 2a0d5a8:	cmova  %rsi,%rdi
 2a0d5ac:	mov    (%rdi),%r8d
 2a0d5af:	test   %r8d,%r8d
 2a0d5b2:	je     2a195ec <wasm[0]::function[1015]::helper::object_read+0x1b48c>
 2a0d5b8:	mov    %r8d,%r9d
 2a0d5bb:	shl    $0x2,%r9
 2a0d5bf:	shr    $0x20,%r9
 2a0d5c3:	test   %r9,%r9
 2a0d5c6:	jne    2a195ee <wasm[0]::function[1015]::helper::object_read+0x1b48e>
 2a0d5cc:	shl    $0x2,%r8d
 2a0d5d0:	add    $0x14,%r8d
 2a0d5d4:	jb     2a195f0 <wasm[0]::function[1015]::helper::object_read+0x1b490>
 2a0d5da:	mov    %rax,%r10
 2a0d5dd:	add    %r8d,%r10d
 2a0d5e0:	jb     2a195f2 <wasm[0]::function[1015]::helper::object_read+0x1b492>
 2a0d5e6:	mov    0xb8(%rsp),%r9d
 2a0d5ee:	mov    %r10d,%r11d
 2a0d5f1:	lea    (%rdx,%r11,1),%r10
 2a0d5f5:	cmp    %rcx,%r11
 2a0d5f8:	cmova  %rsi,%r10
 2a0d5fc:	sub    $0x14,%r8d
 2a0d600:	sub    %r8,%r10
 2a0d603:	mov    %r9d,(%r10)
 2a0d606:	mov    (%rdi),%r8d
 2a0d609:	cmp    $0x1,%r8d
 2a0d60d:	jbe    2a195f4 <wasm[0]::function[1015]::helper::object_read+0x1b494>
 2a0d613:	mov    %r8d,%r9d
 2a0d616:	shl    $0x2,%r9
 2a0d61a:	shr    $0x20,%r9
 2a0d61e:	test   %r9,%r9
 2a0d621:	jne    2a195f6 <wasm[0]::function[1015]::helper::object_read+0x1b496>
 2a0d627:	shl    $0x2,%r8d
 2a0d62b:	add    $0x14,%r8d
 2a0d62f:	jb     2a195f8 <wasm[0]::function[1015]::helper::object_read+0x1b498>
 2a0d635:	mov    %rax,%r10
 2a0d638:	add    %r8d,%r10d
 2a0d63b:	jb     2a195fa <wasm[0]::function[1015]::helper::object_read+0x1b49a>
 2a0d641:	mov    0xa8(%rsp),%r9d
 2a0d649:	mov    %r10d,%r11d
 2a0d64c:	lea    (%rdx,%r11,1),%r10
 2a0d650:	cmp    %rcx,%r11
 2a0d653:	cmova  %rsi,%r10
 2a0d657:	sub    $0x18,%r8d
 2a0d65b:	sub    %r8,%r10
 2a0d65e:	mov    %r9d,(%r10)
 2a0d661:	mov    (%rdi),%edi
 2a0d663:	cmp    $0x2,%edi
 2a0d666:	jbe    2a195fc <wasm[0]::function[1015]::helper::object_read+0x1b49c>
 2a0d66c:	mov    %edi,%r8d
 2a0d66f:	shl    $0x2,%r8
 2a0d673:	shr    $0x20,%r8
 2a0d677:	test   %r8,%r8
 2a0d67a:	jne    2a195fe <wasm[0]::function[1015]::helper::object_read+0x1b49e>
 2a0d680:	shl    $0x2,%edi
 2a0d683:	add    $0x14,%edi
 2a0d686:	jb     2a19600 <wasm[0]::function[1015]::helper::object_read+0x1b4a0>
 2a0d68c:	mov    %rax,%r9
 2a0d68f:	add    %edi,%r9d
 2a0d692:	jb     2a19602 <wasm[0]::function[1015]::helper::object_read+0x1b4a2>
 2a0d698:	mov    0xa0(%rsp),%r8d
 2a0d6a0:	mov    %r9d,%r9d
 2a0d6a3:	add    %r9,%rdx
 2a0d6a6:	cmp    %rcx,%r9
 2a0d6a9:	cmova  %rsi,%rdx
 2a0d6ad:	mov    $0x1c,%r13d
 2a0d6b3:	sub    $0x1c,%edi
 2a0d6b6:	sub    %rdi,%rdx
 2a0d6b9:	mov    %r8d,(%rdx)
 2a0d6bc:	mov    0x190(%rsp),%rsi
 2a0d6c4:	mov    0x8c0(%rsi),%ecx
 2a0d6ca:	mov    %ecx,0xa0(%rsp)
 2a0d6d1:	test   %ecx,%ecx
 2a0d6d3:	je     2a19604 <wasm[0]::function[1015]::helper::object_read+0x1b4a4>
 2a0d6d9:	test   %eax,%eax
 2a0d6db:	je     2a19606 <wasm[0]::function[1015]::helper::object_read+0x1b4a6>
 2a0d6e1:	mov    0x70(%rsp),%edx
 2a0d6e5:	test   %edx,%edx
 2a0d6e7:	je     2a19608 <wasm[0]::function[1015]::helper::object_read+0x1b4a8>
 2a0d6ed:	mov    0x48(%rsp),%r8d
 2a0d6f2:	mov    0x80(%rsp),%edi
 2a0d6f9:	mov    0x50(%rsp),%esi
 2a0d6fd:	mov    %r12,(%rsp)
 2a0d701:	mov    %edi,0x8(%rsp)
 2a0d705:	mov    %eax,0x10(%rsp)
 2a0d709:	mov    %ecx,0x18(%rsp)
 2a0d70d:	mov    %esi,0x20(%rsp)
 2a0d711:	mov    %edx,0x28(%rsp)
 2a0d715:	mov    %r15,%rcx
 2a0d718:	mov    0x270(%rsp),%rdx
 2a0d720:	mov    %rbx,%r9
 2a0d723:	mov    0x190(%rsp),%rsi
 2a0d72b:	mov    0x190(%rsp),%rdi
 2a0d733:	call   2afc220 <wasm[0]::function[1055]::helper::proxy_call>
 2a0d738:	sub    $0x30,%rsp
 2a0d73c:	mov    %rax,0x280(%rsp)
 2a0d744:	mov    %rcx,0x288(%rsp)
 2a0d74c:	mov    %edx,0x80(%rsp)
 2a0d753:	mov    0xa0(%rsp),%eax
 2a0d75a:	test   %eax,%eax
 2a0d75c:	je     2a1960a <wasm[0]::function[1015]::helper::object_read+0x1b4aa>
 2a0d762:	mov    0x190(%rsp),%r8
 2a0d76a:	mov    %eax,0x8c0(%r8)
 2a0d771:	cmp    $0x2,%esi
 2a0d774:	jne    2a0d77f <wasm[0]::function[1015]::helper::object_read+0xf61f>
 2a0d77a:	xor    %esi,%esi
 2a0d77c:	mov    %rsi,%rdi
 2a0d77f:	cmp    $0x1,%esi
 2a0d782:	je     2a17164 <wasm[0]::function[1015]::helper::object_read+0x19004>
 2a0d788:	xor    %eax,%eax
 2a0d78a:	movl   $0x0,0xa0(%rsp)
 2a0d795:	mov    0x58(%rsp),%edx
 2a0d799:	test   %edx,%edx
 2a0d79b:	je     2a0d7eb <wasm[0]::function[1015]::helper::object_read+0xf68b>
 2a0d7a1:	xor    %eax,%eax
 2a0d7a3:	test   $0x1,%edx
 2a0d7a9:	jne    2a0d7eb <wasm[0]::function[1015]::helper::object_read+0xf68b>
 2a0d7af:	mov    0x2e0(%rsp),%r14
 2a0d7b7:	mov    0x28(%r14),%rax
 2a0d7bb:	mov    0x20(%r14),%rsi
 2a0d7bf:	mov    %edx,%ecx
 2a0d7c1:	lea    0x4(%rsi,%rcx,1),%r10
 2a0d7c6:	xor    %rsi,%rsi
 2a0d7c9:	cmp    %rax,%rcx
 2a0d7cc:	cmova  %rsi,%r10
 2a0d7d0:	mov    (%r10),%eax
 2a0d7d3:	mov    0x190(%rsp),%rsi
 2a0d7db:	mov    0x28(%rsi),%rcx
 2a0d7df:	cmp    0x138(%rcx),%eax
 2a0d7e5:	sete   %al
 2a0d7e8:	movzbl %al,%eax
 2a0d7eb:	test   %eax,%eax
 2a0d7ed:	jne    2a15f6e <wasm[0]::function[1015]::helper::object_read+0x17e0e>
 2a0d7f3:	xor    %eax,%eax
 2a0d7f5:	test   %edx,%edx
 2a0d7f7:	je     2a0d846 <wasm[0]::function[1015]::helper::object_read+0xf6e6>
 2a0d7fd:	xor    %eax,%eax
 2a0d7ff:	test   $0x1,%edx
 2a0d805:	jne    2a0d846 <wasm[0]::function[1015]::helper::object_read+0xf6e6>
 2a0d80b:	mov    0x2e0(%rsp),%r14
 2a0d813:	mov    0x28(%r14),%rax
 2a0d817:	mov    0x20(%r14),%rcx
 2a0d81b:	mov    %edx,%esi
 2a0d81d:	lea    0x4(%rcx,%rsi,1),%rcx
 2a0d822:	xor    %rdi,%rdi
 2a0d825:	cmp    %rax,%rsi
 2a0d828:	cmova  %rdi,%rcx
 2a0d82c:	mov    (%rcx),%eax
 2a0d82e:	mov    0x190(%rsp),%rsi
 2a0d836:	mov    0x28(%rsi),%rcx
 2a0d83a:	cmp    0x254(%rcx),%eax
 2a0d840:	sete   %al
 2a0d843:	movzbl %al,%eax
 2a0d846:	test   %eax,%eax
 2a0d848:	jne    2a13aca <wasm[0]::function[1015]::helper::object_read+0x1596a>
 2a0d84e:	mov    0x50(%rsp),%esi
 2a0d852:	mov    0x68(%rsp),%ecx
 2a0d856:	mov    0x70(%rsp),%edi
 2a0d85a:	mov    0x80(%rsp),%r8d
 2a0d862:	xor    %eax,%eax
 2a0d864:	mov    %rax,%r9
 2a0d867:	mov    %rsi,%r10
 2a0d86a:	mov    %rax,%r11
 2a0d86d:	mov    %esi,0x90(%rsp)
 2a0d874:	mov    %eax,0x110(%rsp)
 2a0d87b:	mov    %r11d,0xd8(%rsp)
 2a0d883:	mov    %edx,0xc8(%rsp)
 2a0d88a:	mov    %ecx,0x100(%rsp)
 2a0d891:	mov    %r10d,0x78(%rsp)
 2a0d896:	mov    %edi,0x88(%rsp)
 2a0d89d:	mov    %r8d,0xb8(%rsp)
 2a0d8a5:	mov    %r9d,0xa8(%rsp)
 2a0d8ad:	mov    0x2e8(%rsp),%r15
 2a0d8b5:	mov    (%r15),%rax
 2a0d8b8:	mov    0x228(%rsp),%rcx
 2a0d8c0:	cmp    %rcx,%rax
 2a0d8c3:	jae    2a184eb <wasm[0]::function[1015]::helper::object_read+0x1a38b>
 2a0d8c9:	mov    0x90(%rsp),%ecx
 2a0d8d0:	mov    0x110(%rsp),%eax
 2a0d8d7:	test   %ecx,%ecx
 2a0d8d9:	je     2a0d981 <wasm[0]::function[1015]::helper::object_read+0xf821>
 2a0d8df:	mov    0x90(%rsp),%ecx
 2a0d8e6:	test   %ecx,%ecx
 2a0d8e8:	je     2a1960c <wasm[0]::function[1015]::helper::object_read+0x1b4ac>
 2a0d8ee:	mov    0x2e0(%rsp),%r14
 2a0d8f6:	mov    0x28(%r14),%rax
 2a0d8fa:	mov    0x20(%r14),%rsi
 2a0d8fe:	mov    %ecx,%edx
 2a0d900:	lea    (%rsi,%rdx,1),%rcx
 2a0d904:	xor    %rsi,%rsi
 2a0d907:	cmp    %rax,%rdx
 2a0d90a:	cmova  %rsi,%rcx
 2a0d90e:	mov    0x10(%rcx),%eax
 2a0d911:	test   %eax,%eax
 2a0d913:	jne    2a0d981 <wasm[0]::function[1015]::helper::object_read+0xf821>
 2a0d919:	mov    0x90(%rsp),%edx
 2a0d920:	test   %edx,%edx
 2a0d922:	je     2a1960e <wasm[0]::function[1015]::helper::object_read+0x1b4ae>
 2a0d928:	mov    0x2e0(%rsp),%r14
 2a0d930:	mov    0x28(%r14),%rcx
 2a0d934:	mov    %edx,%esi
 2a0d936:	mov    %rsi,%rdx
 2a0d939:	add    0x20(%r14),%rdx
 2a0d93d:	xor    %rdi,%rdi
 2a0d940:	cmp    %rcx,%rsi
 2a0d943:	cmova  %rdi,%rdx
 2a0d947:	mov    0x1c(%rdx),%esi
 2a0d94a:	mov    0xd8(%rsp),%r11d
 2a0d952:	mov    0xc8(%rsp),%edx
 2a0d959:	mov    0x100(%rsp),%ecx
 2a0d960:	mov    0x78(%rsp),%r10d
 2a0d965:	mov    0x88(%rsp),%edi
 2a0d96c:	mov    0xb8(%rsp),%r8d
 2a0d974:	mov    0xa8(%rsp),%r9d
 2a0d97c:	jmp    2a0d86d <wasm[0]::function[1015]::helper::object_read+0xf70d>
 2a0d981:	test   %eax,%eax
 2a0d983:	jne    2a0d99f <wasm[0]::function[1015]::helper::object_read+0xf83f>
 2a0d989:	mov    0x190(%rsp),%rsi
 2a0d991:	mov    0x8c0(%rsi),%eax
 2a0d997:	test   %eax,%eax
 2a0d999:	je     2a19610 <wasm[0]::function[1015]::helper::object_read+0x1b4b0>
 2a0d99f:	mov    %eax,0x90(%rsp)
 2a0d9a6:	test   %eax,%eax
 2a0d9a8:	je     2a19612 <wasm[0]::function[1015]::helper::object_read+0x1b4b2>
 2a0d9ae:	test   %eax,%eax
 2a0d9b0:	je     2a19614 <wasm[0]::function[1015]::helper::object_read+0x1b4b4>
 2a0d9b6:	mov    0x2e0(%rsp),%r14
 2a0d9be:	mov    0x28(%r14),%rdi
 2a0d9c2:	mov    0x20(%r14),%r8
 2a0d9c6:	mov    %eax,%r10d
 2a0d9c9:	lea    (%r8,%r10,1),%rsi
 2a0d9cd:	xor    %r9,%r9
 2a0d9d0:	cmp    %rdi,%r10
 2a0d9d3:	cmova  %r9,%rsi
 2a0d9d7:	mov    0x2c(%rsi),%eax
 2a0d9da:	test   %eax,%eax
 2a0d9dc:	je     2a19616 <wasm[0]::function[1015]::helper::object_read+0x1b4b6>
 2a0d9e2:	test   %eax,%eax
 2a0d9e4:	je     2a19618 <wasm[0]::function[1015]::helper::object_read+0x1b4b8>
 2a0d9ea:	mov    %eax,%ecx
 2a0d9ec:	lea    0x10(%r8,%rcx,1),%r11
 2a0d9f1:	cmp    %rdi,%rcx
 2a0d9f4:	cmova  %r9,%r11
 2a0d9f8:	mov    (%r11),%esi
 2a0d9fb:	cmp    $0xd,%esi
 2a0d9fe:	jbe    2a1961a <wasm[0]::function[1015]::helper::object_read+0x1b4ba>
 2a0da04:	mov    %esi,%ecx
 2a0da06:	shl    $0x2,%rcx
 2a0da0a:	shr    $0x20,%rcx
 2a0da0e:	test   %rcx,%rcx
 2a0da11:	jne    2a1961c <wasm[0]::function[1015]::helper::object_read+0x1b4bc>
 2a0da17:	shl    $0x2,%esi
 2a0da1a:	add    $0x14,%esi
 2a0da1d:	jb     2a1961e <wasm[0]::function[1015]::helper::object_read+0x1b4be>
 2a0da23:	add    %esi,%eax
 2a0da25:	jb     2a19620 <wasm[0]::function[1015]::helper::object_read+0x1b4c0>
 2a0da2b:	mov    %eax,%ecx
 2a0da2d:	lea    (%r8,%rcx,1),%rax
 2a0da31:	cmp    %rdi,%rcx
 2a0da34:	cmova  %r9,%rax
 2a0da38:	sub    $0x48,%esi
 2a0da3b:	sub    %rsi,%rax
 2a0da3e:	mov    (%rax),%eax
 2a0da40:	test   %eax,%eax
 2a0da42:	je     2a19622 <wasm[0]::function[1015]::helper::object_read+0x1b4c2>
 2a0da48:	test   %eax,%eax
 2a0da4a:	je     2a19624 <wasm[0]::function[1015]::helper::object_read+0x1b4c4>
 2a0da50:	mov    %eax,%ecx
 2a0da52:	lea    (%r8,%rcx,1),%rax
 2a0da56:	cmp    %rdi,%rcx
 2a0da59:	cmova  %r9,%rax
 2a0da5d:	mov    0x18(%rax),%ecx
 2a0da60:	mov    0x10(%rax),%rdx
 2a0da64:	mov    0x1c(%rax),%eax
 2a0da67:	mov    %eax,0x110(%rsp)
 2a0da6e:	cmp    $0x6,%ecx
 2a0da71:	sete   %dl
 2a0da74:	cmp    $0x7,%ecx
 2a0da77:	sete   %sil
 2a0da7b:	or     %esi,%edx
 2a0da7d:	mov    $0x8,%ebx
 2a0da82:	cmp    $0x8,%ecx
 2a0da85:	sete   %sil
 2a0da89:	or     %esi,%edx
 2a0da8b:	cmp    $0x9,%ecx
 2a0da8e:	sete   %cl
 2a0da91:	or     %ecx,%edx
 2a0da93:	movzbl %dl,%ecx
 2a0da96:	test   %ecx,%ecx
 2a0da98:	je     2a19626 <wasm[0]::function[1015]::helper::object_read+0x1b4c6>
 2a0da9e:	xor    %esi,%esi
 2a0daa0:	test   %eax,%eax
 2a0daa2:	je     2a0daf1 <wasm[0]::function[1015]::helper::object_read+0xf991>
 2a0daa8:	xor    %esi,%esi
 2a0daaa:	test   $0x1,%eax
 2a0daaf:	jne    2a0daf1 <wasm[0]::function[1015]::helper::object_read+0xf991>
 2a0dab5:	mov    0x2e0(%rsp),%r14
 2a0dabd:	mov    0x28(%r14),%rcx
 2a0dac1:	mov    0x20(%r14),%rdx
 2a0dac5:	mov    %eax,%esi
 2a0dac7:	lea    0x4(%rdx,%rsi,1),%rdx
 2a0dacc:	xor    %rdi,%rdi
 2a0dacf:	cmp    %rcx,%rsi
 2a0dad2:	cmova  %rdi,%rdx
 2a0dad6:	mov    (%rdx),%ecx
 2a0dad8:	mov    0x190(%rsp),%rsi
 2a0dae0:	mov    0x28(%rsi),%rdx
 2a0dae4:	cmp    0x1d4(%rdx),%ecx
 2a0daea:	sete   %cl
 2a0daed:	rex movzbl %cl,%esi
 2a0daf1:	test   %esi,%esi
 2a0daf3:	je     2a19628 <wasm[0]::function[1015]::helper::object_read+0x1b4c8>
 2a0daf9:	test   %eax,%eax
 2a0dafb:	je     2a1962a <wasm[0]::function[1015]::helper::object_read+0x1b4ca>
 2a0db01:	movl   $0x0,0x128(%rsp)
 2a0db0c:	movl   $0x0,0x138(%rsp)
 2a0db17:	movl   $0x0,0x118(%rsp)
 2a0db22:	movl   $0x0,0x98(%rsp)
 2a0db2d:	movl   $0x0,0xe0(%rsp)
 2a0db38:	mov    $0x105,%edx
 2a0db3d:	mov    0x190(%rsp),%rsi
 2a0db45:	mov    0x190(%rsp),%rdi
 2a0db4d:	call   2f4f240 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 2a0db52:	test   %eax,%eax
 2a0db54:	je     2a1962c <wasm[0]::function[1015]::helper::object_read+0x1b4cc>
 2a0db5a:	mov    0x110(%rsp),%r8d
 2a0db62:	xor    %rcx,%rcx
 2a0db65:	movabs $0x4000000000000000,%rdx
 2a0db6f:	mov    %rdx,(%rsp)
 2a0db73:	mov    0x278(%rsp),%rdx
 2a0db7b:	mov    %edx,0x8(%rsp)
 2a0db7f:	mov    %rax,%r9
 2a0db82:	mov    %rbx,%rdx
 2a0db85:	mov    0x190(%rsp),%rsi
 2a0db8d:	mov    0x190(%rsp),%rdi
 2a0db95:	call   2a73380 <wasm[0]::function[1029]::helper::native_function_allocate>
 2a0db9a:	sub    $0x10,%rsp
 2a0db9e:	mov    %eax,0x110(%rsp)
 2a0dba5:	mov    $0x51,%esi
 2a0dbaa:	mov    0x190(%rsp),%rdi
 2a0dbb2:	call   3039b3e <wasmtime_builtin_ref_func>
 2a0dbb7:	mov    0x268(%rsp),%rcx
 2a0dbbf:	mov    %rax,%r15
 2a0dbc2:	mov    (%rcx),%eax
 2a0dbc4:	mov    %eax,%ecx
 2a0dbc6:	mov    $0x40,%r14d
 2a0dbcc:	lea    0x40(%rcx),%rdx
 2a0dbd0:	mov    0x268(%rsp),%r8
 2a0dbd8:	mov    0x4(%r8),%esi
 2a0dbdc:	cmp    %rsi,%rdx
 2a0dbdf:	ja     2a18522 <wasm[0]::function[1015]::helper::object_read+0x1a3c2>
 2a0dbe5:	lea    0x40(%rax),%edx
 2a0dbe8:	mov    0x268(%rsp),%rsi
 2a0dbf0:	mov    %edx,(%rsi)
 2a0dbf2:	mov    0x2e0(%rsp),%rdx
 2a0dbfa:	mov    0x20(%rdx),%rdx
 2a0dbfe:	lea    (%rdx,%rcx,1),%r12
 2a0dc02:	movl   $0xb0000002,(%rdx,%rcx,1)
 2a0dc09:	mov    0x190(%rsp),%rsi
 2a0dc11:	mov    0x28(%rsi),%rsi
 2a0dc15:	mov    0x1d0(%rsi),%esi
 2a0dc1b:	mov    %esi,0x4(%rdx,%rcx,1)
 2a0dc1f:	mov    %r14d,0x8(%rdx,%rcx,1)
 2a0dc24:	mov    %eax,0x108(%rsp)
 2a0dc2b:	movq   $0x51,0x10(%r12)
 2a0dc34:	movl   $0x1,0x18(%r12)
 2a0dc3d:	movl   $0xf,0x1c(%r12)
 2a0dc46:	movl   $0xffffffff,0x20(%r12)
 2a0dc4f:	movl   $0x0,0x24(%r12)
 2a0dc58:	movl   $0x0,0x28(%r12)
 2a0dc61:	mov    %r15,%rsi
 2a0dc64:	mov    0x190(%rsp),%rdi
 2a0dc6c:	call   3039c33 <wasmtime_builtin_intern_func_ref_for_gc_heap>
 2a0dc71:	mov    %eax,0x2c(%r12)
 2a0dc76:	xor    %rsi,%rsi
 2a0dc79:	mov    %rsi,%r15
 2a0dc7c:	mov    0x190(%rsp),%rdi
 2a0dc84:	call   3039c33 <wasmtime_builtin_intern_func_ref_for_gc_heap>
 2a0dc89:	mov    %eax,0x30(%r12)
 2a0dc8e:	mov    %r15,%rsi
 2a0dc91:	mov    0x190(%rsp),%rdi
 2a0dc99:	call   3039c33 <wasmtime_builtin_intern_func_ref_for_gc_heap>
 2a0dc9e:	mov    %eax,0x34(%r12)
 2a0dca3:	mov    %r15,%rsi
 2a0dca6:	mov    0x190(%rsp),%rdi
 2a0dcae:	call   3039c33 <wasmtime_builtin_intern_func_ref_for_gc_heap>
 2a0dcb3:	mov    %eax,0x38(%r12)
 2a0dcb8:	mov    %r15,%rsi
 2a0dcbb:	mov    0x190(%rsp),%rdi
 2a0dcc3:	call   3039c33 <wasmtime_builtin_intern_func_ref_for_gc_heap>
 2a0dcc8:	mov    %eax,0x3c(%r12)
 2a0dccd:	mov    0x190(%rsp),%rsi
 2a0dcd5:	mov    0xa20(%rsi),%eax
 2a0dcdb:	mov    %eax,0x120(%rsp)
 2a0dce2:	mov    0x90(%rsp),%ecx
 2a0dce9:	test   %ecx,%ecx
 2a0dceb:	je     2a1962e <wasm[0]::function[1015]::helper::object_read+0x1b4ce>
 2a0dcf1:	test   %eax,%eax
 2a0dcf3:	je     2a19630 <wasm[0]::function[1015]::helper::object_read+0x1b4d0>
 2a0dcf9:	mov    0x268(%rsp),%rcx
 2a0dd01:	mov    (%rcx),%eax
 2a0dd03:	mov    %eax,%ecx
 2a0dd05:	lea    0x40(%rcx),%rdx
 2a0dd09:	mov    0x268(%rsp),%rsi
 2a0dd11:	mov    0x4(%rsi),%esi
 2a0dd14:	cmp    %rsi,%rdx
 2a0dd17:	ja     2a18565 <wasm[0]::function[1015]::helper::object_read+0x1a405>
 2a0dd1d:	lea    0x40(%rax),%edx
 2a0dd20:	mov    0x268(%rsp),%rsi
 2a0dd28:	mov    %edx,(%rsi)
 2a0dd2a:	mov    0x2e0(%rsp),%rdi
 2a0dd32:	mov    0x20(%rdi),%rdx
 2a0dd36:	lea    (%rdx,%rcx,1),%r12
 2a0dd3a:	movl   $0xb0001ffa,(%rdx,%rcx,1)
 2a0dd41:	mov    0x190(%rsp),%rsi
 2a0dd49:	mov    0x28(%rsi),%rsi
 2a0dd4d:	mov    0x1e0(%rsi),%esi
 2a0dd53:	mov    %esi,0x4(%rdx,%rcx,1)
 2a0dd57:	mov    %r14d,0x8(%rdx,%rcx,1)
 2a0dd5c:	mov    %eax,0xc0(%rsp)
 2a0dd63:	mov    0x90(%rsp),%eax
 2a0dd6a:	mov    %eax,0x10(%r12)
 2a0dd6f:	mov    0x128(%rsp),%eax
 2a0dd76:	mov    %eax,0x14(%r12)
 2a0dd7b:	mov    0x138(%rsp),%eax
 2a0dd82:	mov    %eax,0x18(%r12)
 2a0dd87:	movl   $0x0,0x1c(%r12)
 2a0dd90:	mov    0x120(%rsp),%eax
 2a0dd97:	mov    %eax,0x20(%r12)
 2a0dd9c:	mov    0x118(%rsp),%eax
 2a0dda3:	mov    %eax,0x24(%r12)
 2a0dda8:	mov    0xe0(%rsp),%eax
 2a0ddaf:	mov    %eax,0x28(%r12)
 2a0ddb4:	mov    0xd8(%rsp),%eax
 2a0ddbb:	mov    %eax,0x2c(%r12)
 2a0ddc0:	mov    0x98(%rsp),%eax
 2a0ddc7:	mov    %eax,0x30(%r12)
 2a0ddcc:	movl   $0x0,0x34(%r12)
 2a0ddd5:	xor    %rsi,%rsi
 2a0ddd8:	mov    0x190(%rsp),%rdi
 2a0dde0:	call   3039c33 <wasmtime_builtin_intern_func_ref_for_gc_heap>
 2a0dde5:	mov    %eax,0x38(%r12)
 2a0ddea:	mov    $0xea5,%edx
 2a0ddef:	mov    0x190(%rsp),%rsi
 2a0ddf7:	mov    0x190(%rsp),%rdi
 2a0ddff:	call   2f4f240 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 2a0de04:	mov    %eax,0x98(%rsp)
 2a0de0b:	mov    0x190(%rsp),%rsi
 2a0de13:	mov    0xa20(%rsi),%ecx
 2a0de19:	mov    %ecx,0xd8(%rsp)
 2a0de20:	mov    0x110(%rsp),%edx
 2a0de27:	test   %edx,%edx
 2a0de29:	je     2a19632 <wasm[0]::function[1015]::helper::object_read+0x1b4d2>
 2a0de2f:	mov    0x108(%rsp),%edx
 2a0de36:	test   %edx,%edx
 2a0de38:	je     2a19634 <wasm[0]::function[1015]::helper::object_read+0x1b4d4>
 2a0de3e:	mov    0xc0(%rsp),%edx
 2a0de45:	test   %edx,%edx
 2a0de47:	je     2a19636 <wasm[0]::function[1015]::helper::object_read+0x1b4d6>
 2a0de4d:	test   %eax,%eax
 2a0de4f:	je     2a19638 <wasm[0]::function[1015]::helper::object_read+0x1b4d8>
 2a0de55:	test   %ecx,%ecx
 2a0de57:	je     2a1963a <wasm[0]::function[1015]::helper::object_read+0x1b4da>
 2a0de5d:	mov    0x268(%rsp),%rcx
 2a0de65:	mov    (%rcx),%eax
 2a0de67:	mov    %eax,%edx
 2a0de69:	mov    $0x50,%esi
 2a0de6e:	lea    0x50(%rdx),%rcx
 2a0de72:	mov    0x268(%rsp),%rdi
 2a0de7a:	mov    0x4(%rdi),%edi
 2a0de7d:	cmp    %rdi,%rcx
 2a0de80:	ja     2a185a8 <wasm[0]::function[1015]::helper::object_read+0x1a448>
 2a0de86:	lea    0x50(%rax),%ecx
 2a0de89:	mov    0x268(%rsp),%rdi
 2a0de91:	mov    %ecx,(%rdi)
 2a0de93:	mov    0x2e0(%rsp),%r14
 2a0de9b:	mov    0x20(%r14),%rdi
 2a0de9f:	lea    (%rdi,%rdx,1),%rcx
 2a0dea3:	movl   $0xb00300fa,(%rdi,%rdx,1)
 2a0deaa:	mov    0x190(%rsp),%r8
 2a0deb2:	mov    0x28(%r8),%r8
 2a0deb6:	mov    0x1d4(%r8),%r8d
 2a0debd:	mov    %r8d,0x4(%rdi,%rdx,1)
 2a0dec2:	mov    %esi,0x8(%rdi,%rdx,1)
 2a0dec6:	mov    %eax,0xe0(%rsp)
 2a0decd:	mov    0x110(%rsp),%edx
 2a0ded4:	mov    %edx,0x10(%rcx)
 2a0ded7:	mov    0x108(%rsp),%edx
 2a0dede:	mov    %edx,0x14(%rcx)
 2a0dee1:	mov    0xc0(%rsp),%edx
 2a0dee8:	mov    %edx,0x18(%rcx)
 2a0deeb:	mov    0x98(%rsp),%esi
 2a0def2:	mov    %esi,0x1c(%rcx)
 2a0def5:	mov    0xd8(%rsp),%esi
 2a0defc:	mov    %esi,0x20(%rcx)
 2a0deff:	movl   $0x1,0x24(%rcx)
 2a0df06:	movl   $0x0,0x28(%rcx)
 2a0df0d:	movl   $0x0,0x2c(%rcx)
 2a0df14:	movl   $0x0,0x30(%rcx)
 2a0df1b:	movl   $0x0,0x34(%rcx)
 2a0df22:	movl   $0x0,0x38(%rcx)
 2a0df29:	movl   $0x0,0x3c(%rcx)
 2a0df30:	movl   $0xffffffff,0x40(%rcx)
 2a0df37:	movl   $0x0,0x44(%rcx)
 2a0df3e:	movl   $0x0,0x48(%rcx)
 2a0df45:	test   %edx,%edx
 2a0df47:	je     2a1963c <wasm[0]::function[1015]::helper::object_read+0x1b4dc>
 2a0df4d:	test   %eax,%eax
 2a0df4f:	je     2a1963e <wasm[0]::function[1015]::helper::object_read+0x1b4de>
 2a0df55:	test   %edx,%edx
 2a0df57:	je     2a19640 <wasm[0]::function[1015]::helper::object_read+0x1b4e0>
 2a0df5d:	mov    0x2e0(%rsp),%r14
 2a0df65:	mov    0x28(%r14),%rcx
 2a0df69:	mov    %edx,%esi
 2a0df6b:	mov    %rsi,%rdx
 2a0df6e:	add    0x20(%r14),%rdx
 2a0df72:	xor    %rdi,%rdi
 2a0df75:	cmp    %rcx,%rsi
 2a0df78:	cmova  %rdi,%rdx
 2a0df7c:	mov    %eax,0x1c(%rdx)
 2a0df7f:	movl   $0x0,0xc0(%rsp)
 2a0df8a:	mov    0x268(%rsp),%rcx
 2a0df92:	mov    (%rcx),%eax
 2a0df94:	mov    %eax,%ecx
 2a0df96:	lea    0x20(%rcx),%rdx
 2a0df9a:	mov    0x268(%rsp),%rdi
 2a0dfa2:	mov    0x4(%rdi),%esi
 2a0dfa5:	cmp    %rsi,%rdx
 2a0dfa8:	ja     2a185ea <wasm[0]::function[1015]::helper::object_read+0x1a48a>
 2a0dfae:	lea    0x20(%rax),%edx
 2a0dfb1:	mov    0x268(%rsp),%rsi
 2a0dfb9:	mov    %edx,(%rsi)
 2a0dfbb:	mov    0x2e0(%rsp),%r14
 2a0dfc3:	mov    0x20(%r14),%rdx
 2a0dfc7:	lea    (%rdx,%rcx,1),%rsi
 2a0dfcb:	movl   $0xb0000042,(%rdx,%rcx,1)
 2a0dfd2:	mov    0x190(%rsp),%rdi
 2a0dfda:	mov    0x28(%rdi),%rdi
 2a0dfde:	mov    0x120(%rdi),%edi
 2a0dfe4:	mov    %edi,0x4(%rdx,%rcx,1)
 2a0dfe8:	mov    0x260(%rsp),%rdi
 2a0dff0:	mov    %edi,0x8(%rdx,%rcx,1)
 2a0dff4:	mov    %eax,0xd8(%rsp)
 2a0dffb:	mov    0x2a0(%rsp),%rcx
 2a0e003:	mov    %rcx,0x10(%rsi)
 2a0e007:	mov    0x2a8(%rsp),%rdx
 2a0e00f:	mov    %edx,0x18(%rsi)
 2a0e012:	mov    0xc8(%rsp),%eax
 2a0e019:	mov    %eax,0x1c(%rsi)
 2a0e01c:	mov    0x268(%rsp),%rcx
 2a0e024:	mov    (%rcx),%eax
 2a0e026:	mov    %eax,%edx
 2a0e028:	lea    0x20(%rdx),%rcx
 2a0e02c:	mov    0x268(%rsp),%rsi
 2a0e034:	mov    0x4(%rsi),%esi
 2a0e037:	cmp    %rsi,%rcx
 2a0e03a:	ja     2a1862c <wasm[0]::function[1015]::helper::object_read+0x1a4cc>
 2a0e040:	lea    0x20(%rax),%ecx
 2a0e043:	mov    0x268(%rsp),%rsi
 2a0e04b:	mov    %ecx,(%rsi)
 2a0e04d:	mov    0x2e0(%rsp),%r14
 2a0e055:	mov    0x20(%r14),%rsi
 2a0e059:	lea    (%rsi,%rdx,1),%rcx
 2a0e05d:	movl   $0xb0000042,(%rsi,%rdx,1)
 2a0e064:	mov    0x190(%rsp),%rdi
 2a0e06c:	mov    0x28(%rdi),%rdi
 2a0e070:	mov    0x120(%rdi),%edi
 2a0e076:	mov    %edi,0x4(%rsi,%rdx,1)
 2a0e07a:	mov    0x260(%rsp),%rdi
 2a0e082:	mov    %edi,0x8(%rsi,%rdx,1)
 2a0e086:	mov    %eax,0xc8(%rsp)
 2a0e08d:	mov    0x1c0(%rsp),%r8
 2a0e095:	mov    %r8,0x10(%rcx)
 2a0e099:	mov    0x1b8(%rsp),%rdx
 2a0e0a1:	mov    %edx,0x18(%rcx)
 2a0e0a4:	mov    0x100(%rsp),%edx
 2a0e0ab:	mov    %edx,0x1c(%rcx)
 2a0e0ae:	mov    0xd8(%rsp),%ecx
 2a0e0b5:	test   %ecx,%ecx
 2a0e0b7:	je     2a19642 <wasm[0]::function[1015]::helper::object_read+0x1b4e2>
 2a0e0bd:	test   %eax,%eax
 2a0e0bf:	je     2a19644 <wasm[0]::function[1015]::helper::object_read+0x1b4e4>
 2a0e0c5:	mov    0x268(%rsp),%rcx
 2a0e0cd:	mov    (%rcx),%eax
 2a0e0cf:	mov    %eax,%ecx
 2a0e0d1:	lea    0x20(%rcx),%rdx
 2a0e0d5:	mov    0x268(%rsp),%rsi
 2a0e0dd:	mov    0x4(%rsi),%esi
 2a0e0e0:	cmp    %rsi,%rdx
 2a0e0e3:	ja     2a1866e <wasm[0]::function[1015]::helper::object_read+0x1a50e>
 2a0e0e9:	lea    0x20(%rax),%edx
 2a0e0ec:	mov    0x268(%rsp),%rsi
 2a0e0f4:	mov    %edx,(%rsi)
 2a0e0f6:	mov    0x2e0(%rsp),%r14
 2a0e0fe:	mov    0x20(%r14),%rdx
 2a0e102:	lea    (%rdx,%rcx,1),%rsi
 2a0e106:	movl   $0xa800000e,(%rdx,%rcx,1)
 2a0e10d:	mov    0x190(%rsp),%rdi
 2a0e115:	mov    0x28(%rdi),%rdi
 2a0e119:	mov    0x1b4(%rdi),%edi
 2a0e11f:	mov    %edi,0x4(%rdx,%rcx,1)
 2a0e123:	mov    0x260(%rsp),%rdi
 2a0e12b:	mov    %edi,0x8(%rdx,%rcx,1)
 2a0e12f:	movl   $0x2,0x10(%rsi)
 2a0e136:	test   %eax,%eax
 2a0e138:	je     2a19646 <wasm[0]::function[1015]::helper::object_read+0x1b4e6>
 2a0e13e:	mov    0x2e0(%rsp),%r14
 2a0e146:	mov    0x28(%r14),%rdx
 2a0e14a:	mov    0x20(%r14),%rsi
 2a0e14e:	mov    %eax,%r8d
 2a0e151:	lea    0x10(%rsi,%r8,1),%rdi
 2a0e156:	xor    %rcx,%rcx
 2a0e159:	cmp    %rdx,%r8
 2a0e15c:	cmova  %rcx,%rdi
 2a0e160:	mov    (%rdi),%r8d
 2a0e163:	test   %r8d,%r8d
 2a0e166:	je     2a19648 <wasm[0]::function[1015]::helper::object_read+0x1b4e8>
 2a0e16c:	mov    %r8d,%r9d
 2a0e16f:	shl    $0x2,%r9
 2a0e173:	shr    $0x20,%r9
 2a0e177:	test   %r9,%r9
 2a0e17a:	jne    2a1964a <wasm[0]::function[1015]::helper::object_read+0x1b4ea>
 2a0e180:	shl    $0x2,%r8d
 2a0e184:	add    $0x14,%r8d
 2a0e188:	jb     2a1964c <wasm[0]::function[1015]::helper::object_read+0x1b4ec>
 2a0e18e:	mov    %rax,%r10
 2a0e191:	add    %r8d,%r10d
 2a0e194:	jb     2a1964e <wasm[0]::function[1015]::helper::object_read+0x1b4ee>
 2a0e19a:	mov    0xd8(%rsp),%r9d
 2a0e1a2:	mov    %r10d,%r11d
 2a0e1a5:	lea    (%rsi,%r11,1),%r10
 2a0e1a9:	cmp    %rdx,%r11
 2a0e1ac:	cmova  %rcx,%r10
 2a0e1b0:	sub    $0x14,%r8d
 2a0e1b4:	sub    %r8,%r10
 2a0e1b7:	mov    %r9d,(%r10)
 2a0e1ba:	mov    (%rdi),%edi
 2a0e1bc:	cmp    $0x1,%edi
 2a0e1bf:	jbe    2a19650 <wasm[0]::function[1015]::helper::object_read+0x1b4f0>
 2a0e1c5:	mov    %edi,%r8d
 2a0e1c8:	shl    $0x2,%r8
 2a0e1cc:	shr    $0x20,%r8
 2a0e1d0:	test   %r8,%r8
 2a0e1d3:	jne    2a19652 <wasm[0]::function[1015]::helper::object_read+0x1b4f2>
 2a0e1d9:	shl    $0x2,%edi
 2a0e1dc:	add    $0x14,%edi
 2a0e1df:	jb     2a19654 <wasm[0]::function[1015]::helper::object_read+0x1b4f4>
 2a0e1e5:	mov    %rax,%r10
 2a0e1e8:	add    %edi,%r10d
 2a0e1eb:	jb     2a19656 <wasm[0]::function[1015]::helper::object_read+0x1b4f6>
 2a0e1f1:	mov    0xc8(%rsp),%r11d
 2a0e1f9:	mov    %r10d,%r9d
 2a0e1fc:	lea    (%rsi,%r9,1),%r8
 2a0e200:	cmp    %rdx,%r9
 2a0e203:	cmova  %rcx,%r8
 2a0e207:	sub    $0x18,%edi
 2a0e20a:	sub    %rdi,%r8
 2a0e20d:	mov    %r11d,(%r8)
 2a0e210:	mov    0x190(%rsp),%rsi
 2a0e218:	mov    0x8c0(%rsi),%edx
 2a0e21e:	mov    %edx,0xc8(%rsp)
 2a0e225:	xor    %r9d,%r9d
 2a0e228:	test   %edx,%edx
 2a0e22a:	je     2a19658 <wasm[0]::function[1015]::helper::object_read+0x1b4f8>
 2a0e230:	test   %eax,%eax
 2a0e232:	je     2a1965a <wasm[0]::function[1015]::helper::object_read+0x1b4fa>
 2a0e238:	mov    0x88(%rsp),%esi
 2a0e23f:	test   %esi,%esi
 2a0e241:	je     2a1965c <wasm[0]::function[1015]::helper::object_read+0x1b4fc>
 2a0e247:	mov    0xe0(%rsp),%r8d
 2a0e24f:	mov    0xc0(%rsp),%r10d
 2a0e257:	mov    0x78(%rsp),%edi
 2a0e25b:	mov    %rcx,(%rsp)
 2a0e25f:	mov    %r10d,0x8(%rsp)
 2a0e264:	mov    %eax,0x10(%rsp)
 2a0e268:	mov    %edx,0x18(%rsp)
 2a0e26c:	mov    %edi,0x20(%rsp)
 2a0e270:	mov    %esi,0x28(%rsp)
 2a0e274:	mov    %rbx,%rdx
 2a0e277:	mov    0x190(%rsp),%rsi
 2a0e27f:	mov    0x190(%rsp),%rdi
 2a0e287:	call   2afc220 <wasm[0]::function[1055]::helper::proxy_call>
 2a0e28c:	sub    $0x30,%rsp
 2a0e290:	mov    %rax,0x250(%rsp)
 2a0e298:	mov    %rcx,0x258(%rsp)
 2a0e2a0:	mov    %edx,0xe0(%rsp)
 2a0e2a7:	mov    0xc8(%rsp),%eax
 2a0e2ae:	test   %eax,%eax
 2a0e2b0:	je     2a1965e <wasm[0]::function[1015]::helper::object_read+0x1b4fe>
 2a0e2b6:	mov    0x190(%rsp),%rcx
 2a0e2be:	mov    %eax,0x8c0(%rcx)
 2a0e2c4:	cmp    $0x2,%esi
 2a0e2c7:	jne    2a0e2d2 <wasm[0]::function[1015]::helper::object_read+0x10172>
 2a0e2cd:	xor    %esi,%esi
 2a0e2cf:	mov    %rsi,%rdi
 2a0e2d2:	cmp    $0x1,%esi
 2a0e2d5:	je     2a13a7d <wasm[0]::function[1015]::helper::object_read+0x1591d>
 2a0e2db:	mov    0xb8(%rsp),%eax
 2a0e2e2:	mov    0xa8(%rsp),%ecx
 2a0e2e9:	mov    %rcx,%r15
 2a0e2ec:	mov    0x78(%rsp),%ecx
 2a0e2f0:	mov    0x250(%rsp),%rdx
 2a0e2f8:	mov    0x250(%rsp),%rsi
 2a0e300:	test   %esi,%edx
 2a0e302:	je     2a16337 <wasm[0]::function[1015]::helper::object_read+0x181d7>
 2a0e308:	mov    $0x12b,%edx
 2a0e30d:	mov    0x190(%rsp),%rsi
 2a0e315:	mov    0x190(%rsp),%rdi
 2a0e31d:	call   2f4f240 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 2a0e322:	mov    %eax,0xa8(%rsp)
 2a0e329:	xor    %r10d,%r10d
 2a0e32c:	test   %eax,%eax
 2a0e32e:	je     2a19660 <wasm[0]::function[1015]::helper::object_read+0x1b500>
 2a0e334:	movl   $0x0,0xc8(%rsp)
 2a0e33f:	mov    0xe0(%rsp),%r11d
 2a0e347:	mov    0xb8(%rsp),%esi
 2a0e34e:	mov    0x78(%rsp),%edx
 2a0e352:	mov    0x250(%rsp),%rcx
 2a0e35a:	cmp    $0x6,%ecx
 2a0e35d:	sete   %cl
 2a0e360:	mov    0x250(%rsp),%rax
 2a0e368:	cmp    $0x7,%eax
 2a0e36b:	sete   %al
 2a0e36e:	or     %eax,%ecx
 2a0e370:	mov    0x250(%rsp),%rax
 2a0e378:	cmp    $0x8,%eax
 2a0e37b:	sete   %al
 2a0e37e:	or     %eax,%ecx
 2a0e380:	mov    0x250(%rsp),%rax
 2a0e388:	cmp    $0x9,%eax
 2a0e38b:	sete   %al
 2a0e38e:	or     %eax,%ecx
 2a0e390:	xor    %r8,%r8
 2a0e393:	test   %cl,%cl
 2a0e395:	mov    %rcx,0x248(%rsp)
 2a0e39d:	jne    2a0e3bb <wasm[0]::function[1015]::helper::object_read+0x1025b>
 2a0e3a3:	mov    %r10,%r9
 2a0e3a6:	mov    %r8,0x1f0(%rsp)
 2a0e3ae:	mov    %r10,0x1f8(%rsp)
 2a0e3b6:	jmp    2a0ee9f <wasm[0]::function[1015]::helper::object_read+0x10d3f>
 2a0e3bb:	mov    0xe0(%rsp),%r8d
 2a0e3c3:	mov    0x258(%rsp),%rcx
 2a0e3cb:	mov    0x250(%rsp),%rdx
 2a0e3d3:	mov    0x190(%rsp),%rsi
 2a0e3db:	mov    0x190(%rsp),%rdi
 2a0e3e3:	call   2a7c940 <wasm[0]::function[1039]::helper::object_header_projection>
 2a0e3e8:	mov    %eax,0xc0(%rsp)
 2a0e3ef:	test   %eax,%eax
 2a0e3f1:	je     2a19662 <wasm[0]::function[1015]::helper::object_read+0x1b502>
 2a0e3f7:	test   %eax,%eax
 2a0e3f9:	je     2a19664 <wasm[0]::function[1015]::helper::object_read+0x1b504>
 2a0e3ff:	mov    0x2e0(%rsp),%r14
 2a0e407:	mov    0x28(%r14),%rcx
 2a0e40b:	mov    0x20(%r14),%rsi
 2a0e40f:	mov    %eax,%edx
 2a0e411:	lea    (%rsi,%rdx,1),%rax
 2a0e415:	xor    %rsi,%rsi
 2a0e418:	cmp    %rcx,%rdx
 2a0e41b:	cmova  %rsi,%rax
 2a0e41f:	mov    0x14(%rax),%eax
 2a0e422:	mov    %eax,0x88(%rsp)
 2a0e429:	test   %eax,%eax
 2a0e42b:	je     2a19666 <wasm[0]::function[1015]::helper::object_read+0x1b506>
 2a0e431:	mov    0x88(%rsp),%ecx
 2a0e438:	xor    %eax,%eax
 2a0e43a:	test   $0x1,%ecx
 2a0e440:	jne    2a0e498 <wasm[0]::function[1015]::helper::object_read+0x10338>
 2a0e446:	mov    0x2e0(%rsp),%r14
 2a0e44e:	mov    0x28(%r14),%rax
 2a0e452:	mov    0x20(%r14),%rsi
 2a0e456:	mov    %ecx,%edx
 2a0e458:	lea    0x4(%rsi,%rdx,1),%rcx
 2a0e45d:	xor    %rsi,%rsi
 2a0e460:	cmp    %rax,%rdx
 2a0e463:	cmova  %rsi,%rcx
 2a0e467:	mov    (%rcx),%esi
 2a0e469:	mov    0x190(%rsp),%rax
 2a0e471:	mov    0x28(%rax),%rax
 2a0e475:	mov    0x158(%rax),%edx
 2a0e47b:	cmp    %edx,%esi
 2a0e47d:	sete   %al
 2a0e480:	movzbl %al,%eax
 2a0e483:	cmp    %edx,%esi
 2a0e485:	je     2a0e498 <wasm[0]::function[1015]::helper::object_read+0x10338>
 2a0e48b:	mov    0x190(%rsp),%rdi
 2a0e493:	call   3039cc5 <wasmtime_builtin_is_subtype>
 2a0e498:	test   %eax,%eax
 2a0e49a:	jne    2a0e6cb <wasm[0]::function[1015]::helper::object_read+0x1056b>
 2a0e4a0:	mov    0xc0(%rsp),%edx
 2a0e4a7:	xor    %r15d,%r15d
 2a0e4aa:	test   %edx,%edx
 2a0e4ac:	je     2a19668 <wasm[0]::function[1015]::helper::object_read+0x1b508>
 2a0e4b2:	mov    0xa8(%rsp),%r9d
 2a0e4ba:	mov    $0x4,%ecx
 2a0e4bf:	xor    %r8,%r8
 2a0e4c2:	mov    0x190(%rsp),%rsi
 2a0e4ca:	mov    0x190(%rsp),%rdi
 2a0e4d2:	call   2a76140 <wasm[0]::function[1032]::helper::ordinary_property_find>
 2a0e4d7:	test   %eax,%eax
 2a0e4d9:	je     2a0e512 <wasm[0]::function[1015]::helper::object_read+0x103b2>
 2a0e4df:	test   %eax,%eax
 2a0e4e1:	je     2a1966a <wasm[0]::function[1015]::helper::object_read+0x1b50a>
 2a0e4e7:	test   %eax,%eax
 2a0e4e9:	je     2a1966c <wasm[0]::function[1015]::helper::object_read+0x1b50c>
 2a0e4ef:	mov    0x2e0(%rsp),%r14
 2a0e4f7:	mov    0x28(%r14),%rcx
 2a0e4fb:	mov    %eax,%eax
 2a0e4fd:	mov    %rax,%r11
 2a0e500:	add    0x20(%r14),%r11
 2a0e504:	xor    %rdx,%rdx
 2a0e507:	cmp    %rcx,%rax
 2a0e50a:	cmova  %rdx,%r11
 2a0e50e:	mov    0x14(%r11),%r15d
 2a0e512:	mov    0xc8(%rsp),%r9d
 2a0e51a:	xor    %r8,%r8
 2a0e51d:	xor    %r10d,%r10d
 2a0e520:	test   %r15d,%r15d
 2a0e523:	je     2a0e6a3 <wasm[0]::function[1015]::helper::object_read+0x10543>
 2a0e529:	test   %r15d,%r15d
 2a0e52c:	je     2a1966e <wasm[0]::function[1015]::helper::object_read+0x1b50e>
 2a0e532:	mov    0x2e0(%rsp),%r14
 2a0e53a:	mov    0x28(%r14),%rcx
 2a0e53e:	mov    0x20(%r14),%rax
 2a0e542:	mov    %r15d,%edx
 2a0e545:	add    %rdx,%rax
 2a0e548:	xor    %r8,%r8
 2a0e54b:	cmp    %rcx,%rdx
 2a0e54e:	cmova  %r8,%rax
 2a0e552:	mov    0x10(%rax),%ecx
 2a0e555:	mov    0xc8(%rsp),%r9d
 2a0e55d:	xor    %r10d,%r10d
 2a0e560:	test   $0x1,%ecx
 2a0e566:	jne    2a0e6a3 <wasm[0]::function[1015]::helper::object_read+0x10543>
 2a0e56c:	mov    0x14(%rax),%edx
 2a0e56f:	test   %edx,%edx
 2a0e571:	je     2a19670 <wasm[0]::function[1015]::helper::object_read+0x1b510>
 2a0e577:	xor    %edi,%edi
 2a0e579:	test   $0x1,%edx
 2a0e57f:	jne    2a0e5c1 <wasm[0]::function[1015]::helper::object_read+0x10461>
 2a0e585:	mov    0x2e0(%rsp),%r14
 2a0e58d:	mov    0x28(%r14),%rax
 2a0e591:	mov    0x20(%r14),%rcx
 2a0e595:	mov    %edx,%esi
 2a0e597:	lea    0x4(%rcx,%rsi,1),%rcx
 2a0e59c:	xor    %rdi,%rdi
 2a0e59f:	cmp    %rax,%rsi
 2a0e5a2:	cmova  %rdi,%rcx
 2a0e5a6:	mov    (%rcx),%eax
 2a0e5a8:	mov    0x190(%rsp),%rsi
 2a0e5b0:	mov    0x28(%rsi),%rcx
 2a0e5b4:	cmp    0x120(%rcx),%eax
 2a0e5ba:	sete   %al
 2a0e5bd:	rex movzbl %al,%edi
 2a0e5c1:	test   %edi,%edi
 2a0e5c3:	jne    2a0e61f <wasm[0]::function[1015]::helper::object_read+0x104bf>
 2a0e5c9:	mov    0x190(%rsp),%rsi
 2a0e5d1:	mov    0x190(%rsp),%rdi
 2a0e5d9:	call   2a1eec0 <wasm[0]::function[1024]::helper::property_value_resolve>
 2a0e5de:	test   %eax,%eax
 2a0e5e0:	je     2a19672 <wasm[0]::function[1015]::helper::object_read+0x1b512>
 2a0e5e6:	test   %eax,%eax
 2a0e5e8:	je     2a19674 <wasm[0]::function[1015]::helper::object_read+0x1b514>
 2a0e5ee:	mov    0x2e0(%rsp),%r14
 2a0e5f6:	mov    0x28(%r14),%rcx
 2a0e5fa:	mov    0x20(%r14),%rsi
 2a0e5fe:	mov    %eax,%edx
 2a0e600:	lea    (%rsi,%rdx,1),%rax
 2a0e604:	xor    %rsi,%rsi
 2a0e607:	cmp    %rcx,%rdx
 2a0e60a:	cmova  %rsi,%rax
 2a0e60e:	mov    0x18(%rax),%r10d
 2a0e612:	mov    0x10(%rax),%r8
 2a0e616:	mov    0x1c(%rax),%r9d
 2a0e61a:	jmp    2a0e6a3 <wasm[0]::function[1015]::helper::object_read+0x10543>
 2a0e61f:	xor    %eax,%eax
 2a0e621:	test   $0x1,%edx
 2a0e627:	jne    2a0e668 <wasm[0]::function[1015]::helper::object_read+0x10508>
 2a0e62d:	mov    0x2e0(%rsp),%r14
 2a0e635:	mov    0x28(%r14),%rax
 2a0e639:	mov    0x20(%r14),%rcx
 2a0e63d:	mov    %edx,%esi
 2a0e63f:	lea    0x4(%rcx,%rsi,1),%rcx
 2a0e644:	xor    %rdi,%rdi
 2a0e647:	cmp    %rax,%rsi
 2a0e64a:	cmova  %rdi,%rcx
 2a0e64e:	mov    (%rcx),%eax
 2a0e650:	mov    0x190(%rsp),%rsi
 2a0e658:	mov    0x28(%rsi),%rcx
 2a0e65c:	cmp    0x120(%rcx),%eax
 2a0e662:	sete   %al
 2a0e665:	movzbl %al,%eax
 2a0e668:	test   %eax,%eax
 2a0e66a:	je     2a19676 <wasm[0]::function[1015]::helper::object_read+0x1b516>
 2a0e670:	test   %edx,%edx
 2a0e672:	je     2a19678 <wasm[0]::function[1015]::helper::object_read+0x1b518>
 2a0e678:	mov    0x2e0(%rsp),%r14
 2a0e680:	mov    0x28(%r14),%rcx
 2a0e684:	mov    0x20(%r14),%rax
 2a0e688:	mov    %edx,%edx
 2a0e68a:	add    %rdx,%rax
 2a0e68d:	xor    %rsi,%rsi
 2a0e690:	cmp    %rcx,%rdx
 2a0e693:	cmova  %rsi,%rax
 2a0e697:	mov    0x18(%rax),%r10d
 2a0e69b:	mov    0x10(%rax),%r8
 2a0e69f:	mov    0x1c(%rax),%r9d
 2a0e6a3:	mov    0xe0(%rsp),%r11d
 2a0e6ab:	mov    0xb8(%rsp),%esi
 2a0e6b2:	mov    0x78(%rsp),%edx
 2a0e6b6:	mov    %r8,0x1f0(%rsp)
 2a0e6be:	mov    %r10,0x1f8(%rsp)
 2a0e6c6:	jmp    2a0ee9f <wasm[0]::function[1015]::helper::object_read+0x10d3f>
 2a0e6cb:	mov    0x88(%rsp),%eax
 2a0e6d2:	test   %eax,%eax
 2a0e6d4:	je     2a1967a <wasm[0]::function[1015]::helper::object_read+0x1b51a>
 2a0e6da:	mov    0x88(%rsp),%ecx
 2a0e6e1:	xor    %eax,%eax
 2a0e6e3:	test   $0x1,%ecx
 2a0e6e9:	jne    2a0e743 <wasm[0]::function[1015]::helper::object_read+0x105e3>
 2a0e6ef:	mov    0x2e0(%rsp),%r14
 2a0e6f7:	mov    0x28(%r14),%rdx
 2a0e6fb:	mov    0x20(%r14),%rsi
 2a0e6ff:	mov    %ecx,%ecx
 2a0e701:	lea    0x4(%rsi,%rcx,1),%rax
 2a0e706:	xor    %rsi,%rsi
 2a0e709:	cmp    %rdx,%rcx
 2a0e70c:	cmova  %rsi,%rax
 2a0e710:	mov    (%rax),%esi
 2a0e712:	mov    0x190(%rsp),%rax
 2a0e71a:	mov    0x28(%rax),%rdx
 2a0e71e:	mov    0x158(%rdx),%edx
 2a0e724:	cmp    %edx,%esi
 2a0e726:	sete   %dil
 2a0e72a:	movzbl %dil,%eax
 2a0e72e:	cmp    %edx,%esi
 2a0e730:	je     2a0e743 <wasm[0]::function[1015]::helper::object_read+0x105e3>
 2a0e736:	mov    0x190(%rsp),%rdi
 2a0e73e:	call   3039cc5 <wasmtime_builtin_is_subtype>
 2a0e743:	test   %eax,%eax
 2a0e745:	je     2a1967c <wasm[0]::function[1015]::helper::object_read+0x1b51c>
 2a0e74b:	mov    0x88(%rsp),%edi
 2a0e752:	mov    0xe0(%rsp),%r11d
 2a0e75a:	mov    0xc8(%rsp),%r9d
 2a0e762:	mov    0xb8(%rsp),%esi
 2a0e769:	mov    0x78(%rsp),%edx
 2a0e76d:	xor    %ecx,%ecx
 2a0e76f:	mov    %rcx,%r13
 2a0e772:	test   %edi,%edi
 2a0e774:	je     2a1967e <wasm[0]::function[1015]::helper::object_read+0x1b51e>
 2a0e77a:	test   %edi,%edi
 2a0e77c:	je     2a19680 <wasm[0]::function[1015]::helper::object_read+0x1b520>
 2a0e782:	mov    0x2e0(%rsp),%r14
 2a0e78a:	mov    0x28(%r14),%rax
 2a0e78e:	mov    0x20(%r14),%rcx
 2a0e792:	mov    %edi,%r15d
 2a0e795:	lea    (%rcx,%r15,1),%r8
 2a0e799:	xor    %r10,%r10
 2a0e79c:	cmp    %rax,%r15
 2a0e79f:	cmova  %r10,%r8
 2a0e7a3:	mov    0x10(%r8),%r8d
 2a0e7a7:	test   %r8d,%r8d
 2a0e7aa:	je     2a19682 <wasm[0]::function[1015]::helper::object_read+0x1b522>
 2a0e7b0:	test   %r8d,%r8d
 2a0e7b3:	je     2a19684 <wasm[0]::function[1015]::helper::object_read+0x1b524>
 2a0e7b9:	mov    %r8d,%ebx
 2a0e7bc:	lea    (%rcx,%rbx,1),%r8
 2a0e7c0:	cmp    %rax,%rbx
 2a0e7c3:	cmova  %r10,%r8
 2a0e7c7:	mov    0x10(%r8),%r8d
 2a0e7cb:	test   %r8d,%r8d
 2a0e7ce:	je     2a19686 <wasm[0]::function[1015]::helper::object_read+0x1b526>
 2a0e7d4:	test   %r8d,%r8d
 2a0e7d7:	je     2a19688 <wasm[0]::function[1015]::helper::object_read+0x1b528>
 2a0e7dd:	mov    %r8d,%ebx
 2a0e7e0:	lea    0x10(%rcx,%rbx,1),%rcx
 2a0e7e5:	cmp    %rax,%rbx
 2a0e7e8:	cmova  %r10,%rcx
 2a0e7ec:	mov    (%rcx),%ebx
 2a0e7ee:	mov    0xa8(%rsp),%r10d
 2a0e7f6:	mov    0x190(%rsp),%rax
 2a0e7fe:	mov    0x28(%rax),%rax
 2a0e802:	mov    0x234(%rax),%r12d
 2a0e809:	mov    %r13,0x1c8(%rsp)
 2a0e811:	mov    %r8d,0xd8(%rsp)
 2a0e819:	mov    %r10d,0xc0(%rsp)
 2a0e821:	mov    %edi,0x78(%rsp)
 2a0e825:	mov    %r11d,0xb8(%rsp)
 2a0e82d:	mov    %r9d,0xc8(%rsp)
 2a0e835:	mov    %esi,0x88(%rsp)
 2a0e83c:	mov    %edx,0xa8(%rsp)
 2a0e843:	mov    0x2e8(%rsp),%r15
 2a0e84b:	mov    (%r15),%rcx
 2a0e84e:	mov    0x228(%rsp),%rax
 2a0e856:	cmp    %rax,%rcx
 2a0e859:	jae    2a186ae <wasm[0]::function[1015]::helper::object_read+0x1a54e>
 2a0e85f:	mov    0x78(%rsp),%edi
 2a0e863:	mov    0xb8(%rsp),%r11d
 2a0e86b:	mov    0xc8(%rsp),%r9d
 2a0e873:	mov    0x88(%rsp),%esi
 2a0e87a:	mov    0xa8(%rsp),%edx
 2a0e881:	mov    %r13,%rcx
 2a0e884:	cmp    %ebx,%ecx
 2a0e886:	jb     2a0e899 <wasm[0]::function[1015]::helper::object_read+0x10739>
 2a0e88c:	mov    0x1c8(%rsp),%rax
 2a0e894:	jmp    2a0ea73 <wasm[0]::function[1015]::helper::object_read+0x10913>
 2a0e899:	mov    0xd8(%rsp),%eax
 2a0e8a0:	test   %eax,%eax
 2a0e8a2:	je     2a1968a <wasm[0]::function[1015]::helper::object_read+0x1b52a>
 2a0e8a8:	test   %eax,%eax
 2a0e8aa:	je     2a1968c <wasm[0]::function[1015]::helper::object_read+0x1b52c>
 2a0e8b0:	mov    0x2e0(%rsp),%r14
 2a0e8b8:	mov    0x28(%r14),%rdx
 2a0e8bc:	mov    0x20(%r14),%rsi
 2a0e8c0:	mov    %eax,%r9d
 2a0e8c3:	lea    0x10(%rsi,%r9,1),%r8
 2a0e8c8:	xor    %rdi,%rdi
 2a0e8cb:	cmp    %rdx,%r9
 2a0e8ce:	cmova  %rdi,%r8
 2a0e8d2:	mov    (%r8),%r8d
 2a0e8d5:	cmp    %r8d,%ecx
 2a0e8d8:	jae    2a1968e <wasm[0]::function[1015]::helper::object_read+0x1b52e>
 2a0e8de:	mov    %r8d,%r9d
 2a0e8e1:	shl    $0x2,%r9
 2a0e8e5:	shr    $0x20,%r9
 2a0e8e9:	test   %r9,%r9
 2a0e8ec:	jne    2a19690 <wasm[0]::function[1015]::helper::object_read+0x1b530>
 2a0e8f2:	shl    $0x2,%r8d
 2a0e8f6:	add    $0x14,%r8d
 2a0e8fa:	jb     2a19692 <wasm[0]::function[1015]::helper::object_read+0x1b532>
 2a0e900:	add    %r8d,%eax
 2a0e903:	jb     2a19694 <wasm[0]::function[1015]::helper::object_read+0x1b534>
 2a0e909:	mov    %eax,%r9d
 2a0e90c:	lea    (%rsi,%r9,1),%rax
 2a0e910:	cmp    %rdx,%r9
 2a0e913:	cmova  %rdi,%rax
 2a0e917:	mov    %rcx,%rdx
 2a0e91a:	shl    $0x2,%edx
 2a0e91d:	mov    %rcx,%r13
 2a0e920:	lea    0x14(%rdx),%ecx
 2a0e923:	sub    %ecx,%r8d
 2a0e926:	sub    %r8,%rax
 2a0e929:	mov    (%rax),%edx
 2a0e92b:	test   %edx,%edx
 2a0e92d:	je     2a19696 <wasm[0]::function[1015]::helper::object_read+0x1b536>
 2a0e933:	mov    0xc0(%rsp),%eax
 2a0e93a:	cmp    %eax,%edx
 2a0e93c:	je     2a0ea10 <wasm[0]::function[1015]::helper::object_read+0x108b0>
 2a0e942:	xor    %ecx,%ecx
 2a0e944:	test   %edx,%edx
 2a0e946:	je     2a0e989 <wasm[0]::function[1015]::helper::object_read+0x10829>
 2a0e94c:	xor    %ecx,%ecx
 2a0e94e:	test   $0x1,%edx
 2a0e954:	jne    2a0e989 <wasm[0]::function[1015]::helper::object_read+0x10829>
 2a0e95a:	mov    0x2e0(%rsp),%r14
 2a0e962:	mov    0x28(%r14),%rsi
 2a0e966:	mov    0x20(%r14),%rdi
 2a0e96a:	mov    %edx,%r8d
 2a0e96d:	lea    0x4(%rdi,%r8,1),%rdi
 2a0e972:	xor    %r9,%r9
 2a0e975:	cmp    %rsi,%r8
 2a0e978:	cmova  %r9,%rdi
 2a0e97c:	mov    (%rdi),%edi
 2a0e97e:	cmp    %r12d,%edi
 2a0e981:	sete   %r8b
 2a0e985:	movzbl %r8b,%ecx
 2a0e989:	test   %ecx,%ecx
 2a0e98b:	je     2a19698 <wasm[0]::function[1015]::helper::object_read+0x1b538>
 2a0e991:	xor    %esi,%esi
 2a0e993:	test   %eax,%eax
 2a0e995:	je     2a0e9dc <wasm[0]::function[1015]::helper::object_read+0x1087c>
 2a0e99b:	mov    0xc0(%rsp),%eax
 2a0e9a2:	xor    %esi,%esi
 2a0e9a4:	test   $0x1,%eax
 2a0e9a9:	jne    2a0e9dc <wasm[0]::function[1015]::helper::object_read+0x1087c>
 2a0e9af:	mov    0x2e0(%rsp),%r14
 2a0e9b7:	mov    0x28(%r14),%rcx
 2a0e9bb:	mov    0x20(%r14),%rdi
 2a0e9bf:	mov    %eax,%esi
 2a0e9c1:	lea    0x4(%rdi,%rsi,1),%rax
 2a0e9c6:	xor    %rdi,%rdi
 2a0e9c9:	cmp    %rcx,%rsi
 2a0e9cc:	cmova  %rdi,%rax
 2a0e9d0:	mov    (%rax),%eax
 2a0e9d2:	cmp    %r12d,%eax
 2a0e9d5:	sete   %al
 2a0e9d8:	rex movzbl %al,%esi
 2a0e9dc:	test   %esi,%esi
 2a0e9de:	je     2a1969a <wasm[0]::function[1015]::helper::object_read+0x1b53a>
 2a0e9e4:	mov    0xc0(%rsp),%ecx
 2a0e9eb:	xor    %r8d,%r8d
 2a0e9ee:	test   %ecx,%ecx
 2a0e9f0:	je     2a1969c <wasm[0]::function[1015]::helper::object_read+0x1b53c>
 2a0e9f6:	mov    0x190(%rsp),%rsi
 2a0e9fe:	mov    0x190(%rsp),%rdi
 2a0ea06:	call   2b02800 <wasm[0]::function[1057]::helper::string_equality>
 2a0ea0b:	jmp    2a0ea18 <wasm[0]::function[1015]::helper::object_read+0x108b8>
 2a0ea10:	mov    0x278(%rsp),%rax
 2a0ea18:	mov    0xd8(%rsp),%r8d
 2a0ea20:	mov    0xc0(%rsp),%r10d
 2a0ea28:	mov    0x78(%rsp),%edi
 2a0ea2c:	mov    0xb8(%rsp),%r11d
 2a0ea34:	mov    0xc8(%rsp),%r9d
 2a0ea3c:	mov    0x88(%rsp),%esi
 2a0ea43:	mov    0xa8(%rsp),%edx
 2a0ea4a:	test   %eax,%eax
 2a0ea4c:	je     2a0ea5a <wasm[0]::function[1015]::helper::object_read+0x108fa>
 2a0ea52:	mov    %r13,%rcx
 2a0ea55:	jmp    2a0ea73 <wasm[0]::function[1015]::helper::object_read+0x10913>
 2a0ea5a:	mov    %r13,%rcx
 2a0ea5d:	add    $0x1,%ecx
 2a0ea63:	mov    %rcx,%r13
 2a0ea66:	mov    %rax,0x1c8(%rsp)
 2a0ea6e:	jmp    2a0e811 <wasm[0]::function[1015]::helper::object_read+0x106b1>
 2a0ea73:	xor    %r8,%r8
 2a0ea76:	xor    %r10d,%r10d
 2a0ea79:	test   %eax,%eax
 2a0ea7b:	jne    2a0ea96 <wasm[0]::function[1015]::helper::object_read+0x10936>
 2a0ea81:	mov    %r8,0x1f0(%rsp)
 2a0ea89:	mov    %r10,0x1f8(%rsp)
 2a0ea91:	jmp    2a0ee9f <wasm[0]::function[1015]::helper::object_read+0x10d3f>
 2a0ea96:	test   %edi,%edi
 2a0ea98:	je     2a1969e <wasm[0]::function[1015]::helper::object_read+0x1b53e>
 2a0ea9e:	xor    %eax,%eax
 2a0eaa0:	test   $0x1,%edi
 2a0eaa6:	jne    2a0eaea <wasm[0]::function[1015]::helper::object_read+0x1098a>
 2a0eaac:	mov    0x2e0(%rsp),%r14
 2a0eab4:	mov    0x28(%r14),%rax
 2a0eab8:	mov    0x20(%r14),%r8
 2a0eabc:	mov    %edi,%r9d
 2a0eabf:	lea    0x4(%r8,%r9,1),%r8
 2a0eac4:	xor    %r10,%r10
 2a0eac7:	cmp    %rax,%r9
 2a0eaca:	cmova  %r10,%r8
 2a0eace:	mov    (%r8),%eax
 2a0ead1:	mov    0x190(%rsp),%r8
 2a0ead9:	mov    0x28(%r8),%r8
 2a0eadd:	cmp    0x160(%r8),%eax
 2a0eae4:	sete   %al
 2a0eae7:	movzbl %al,%eax
 2a0eaea:	test   %eax,%eax
 2a0eaec:	jne    2a0ed24 <wasm[0]::function[1015]::helper::object_read+0x10bc4>
 2a0eaf2:	xor    %eax,%eax
 2a0eaf4:	test   $0x1,%edi
 2a0eafa:	jne    2a0eb3e <wasm[0]::function[1015]::helper::object_read+0x109de>
 2a0eb00:	mov    0x2e0(%rsp),%r14
 2a0eb08:	mov    0x28(%r14),%rax
 2a0eb0c:	mov    0x20(%r14),%r8
 2a0eb10:	mov    %edi,%r9d
 2a0eb13:	lea    0x4(%r8,%r9,1),%r8
 2a0eb18:	xor    %r10,%r10
 2a0eb1b:	cmp    %rax,%r9
 2a0eb1e:	cmova  %r10,%r8
 2a0eb22:	mov    (%r8),%eax
 2a0eb25:	mov    0x190(%rsp),%r8
 2a0eb2d:	mov    0x28(%r8),%r8
 2a0eb31:	cmp    0x15c(%r8),%eax
 2a0eb38:	sete   %al
 2a0eb3b:	movzbl %al,%eax
 2a0eb3e:	test   %eax,%eax
 2a0eb40:	je     2a196a0 <wasm[0]::function[1015]::helper::object_read+0x1b540>
 2a0eb46:	test   %edi,%edi
 2a0eb48:	je     2a196a2 <wasm[0]::function[1015]::helper::object_read+0x1b542>
 2a0eb4e:	mov    0x2e0(%rsp),%r14
 2a0eb56:	mov    0x28(%r14),%rax
 2a0eb5a:	mov    0x20(%r14),%r10
 2a0eb5e:	mov    %edi,%r9d
 2a0eb61:	lea    (%r10,%r9,1),%rdi
 2a0eb65:	xor    %r8,%r8
 2a0eb68:	cmp    %rax,%r9
 2a0eb6b:	cmova  %r8,%rdi
 2a0eb6f:	mov    0x14(%rdi),%ebx
 2a0eb72:	mov    0x18(%rdi),%r9d
 2a0eb76:	mov    0x1c(%rdi),%edi
 2a0eb79:	test   %ebx,%ebx
 2a0eb7b:	je     2a196a4 <wasm[0]::function[1015]::helper::object_read+0x1b544>
 2a0eb81:	test   %ebx,%ebx
 2a0eb83:	je     2a196a6 <wasm[0]::function[1015]::helper::object_read+0x1b546>
 2a0eb89:	mov    %ebx,%r13d
 2a0eb8c:	lea    0x10(%r10,%r13,1),%r12
 2a0eb91:	cmp    %rax,%r13
 2a0eb94:	cmova  %r8,%r12
 2a0eb98:	mov    (%r12),%r12d
 2a0eb9c:	cmp    %r12d,%ecx
 2a0eb9f:	jae    2a196a8 <wasm[0]::function[1015]::helper::object_read+0x1b548>
 2a0eba5:	mov    %r12d,%r13d
 2a0eba8:	shr    $0x20,%r13
 2a0ebac:	test   %r13,%r13
 2a0ebaf:	jne    2a196aa <wasm[0]::function[1015]::helper::object_read+0x1b54a>
 2a0ebb5:	add    $0x14,%r12d
 2a0ebb9:	jb     2a196ac <wasm[0]::function[1015]::helper::object_read+0x1b54c>
 2a0ebbf:	add    %r12d,%ebx
 2a0ebc2:	jb     2a196ae <wasm[0]::function[1015]::helper::object_read+0x1b54e>
 2a0ebc8:	mov    %ebx,%r13d
 2a0ebcb:	add    %r13,%r10
 2a0ebce:	cmp    %rax,%r13
 2a0ebd1:	cmova  %r8,%r10
 2a0ebd5:	lea    0x14(%rcx),%eax
 2a0ebd8:	sub    %eax,%r12d
 2a0ebdb:	sub    %r12,%r10
 2a0ebde:	movzbq (%r10),%r10
 2a0ebe2:	test   %r9d,%r9d
 2a0ebe5:	je     2a0ec79 <wasm[0]::function[1015]::helper::object_read+0x10b19>
 2a0ebeb:	test   %r9d,%r9d
 2a0ebee:	je     2a196b0 <wasm[0]::function[1015]::helper::object_read+0x1b550>
 2a0ebf4:	test   %r9d,%r9d
 2a0ebf7:	je     2a196b2 <wasm[0]::function[1015]::helper::object_read+0x1b552>
 2a0ebfd:	mov    0x2e0(%rsp),%r14
 2a0ec05:	mov    0x28(%r14),%rax
 2a0ec09:	mov    0x20(%r14),%r8
 2a0ec0d:	mov    %r9d,%r12d
 2a0ec10:	lea    0x10(%r8,%r12,1),%r13
 2a0ec15:	xor    %rbx,%rbx
 2a0ec18:	cmp    %rax,%r12
 2a0ec1b:	cmova  %rbx,%r13
 2a0ec1f:	mov    0x0(%r13),%r12d
 2a0ec23:	cmp    %r12d,%ecx
 2a0ec26:	jae    2a196b4 <wasm[0]::function[1015]::helper::object_read+0x1b554>
 2a0ec2c:	mov    %r12d,%r13d
 2a0ec2f:	shl    $0x3,%r13
 2a0ec33:	shr    $0x20,%r13
 2a0ec37:	test   %r13,%r13
 2a0ec3a:	jne    2a196b6 <wasm[0]::function[1015]::helper::object_read+0x1b556>
 2a0ec40:	shl    $0x3,%r12d
 2a0ec44:	add    $0x18,%r12d
 2a0ec48:	jb     2a196b8 <wasm[0]::function[1015]::helper::object_read+0x1b558>
 2a0ec4e:	add    %r12d,%r9d
 2a0ec51:	jb     2a196ba <wasm[0]::function[1015]::helper::object_read+0x1b55a>
 2a0ec57:	mov    %r9d,%r9d
 2a0ec5a:	add    %r9,%r8
 2a0ec5d:	cmp    %rax,%r9
 2a0ec60:	cmova  %rbx,%r8
 2a0ec64:	mov    %rcx,%rax
 2a0ec67:	shl    $0x3,%eax
 2a0ec6a:	add    $0x18,%eax
 2a0ec70:	sub    %eax,%r12d
 2a0ec73:	sub    %r12,%r8
 2a0ec76:	mov    (%r8),%r8
 2a0ec79:	xor    %r9d,%r9d
 2a0ec7c:	test   %edi,%edi
 2a0ec7e:	je     2a0ed0b <wasm[0]::function[1015]::helper::object_read+0x10bab>
 2a0ec84:	test   %edi,%edi
 2a0ec86:	je     2a196bc <wasm[0]::function[1015]::helper::object_read+0x1b55c>
 2a0ec8c:	test   %edi,%edi
 2a0ec8e:	je     2a196be <wasm[0]::function[1015]::helper::object_read+0x1b55e>
 2a0ec94:	mov    0x2e0(%rsp),%r14
 2a0ec9c:	mov    0x28(%r14),%rax
 2a0eca0:	mov    0x20(%r14),%r9
 2a0eca4:	mov    %edi,%r13d
 2a0eca7:	lea    0x10(%r9,%r13,1),%r12
 2a0ecac:	xor    %rbx,%rbx
 2a0ecaf:	cmp    %rax,%r13
 2a0ecb2:	cmova  %rbx,%r12
 2a0ecb6:	mov    (%r12),%r12d
 2a0ecba:	cmp    %r12d,%ecx
 2a0ecbd:	jae    2a196c0 <wasm[0]::function[1015]::helper::object_read+0x1b560>
 2a0ecc3:	mov    %r12d,%r13d
 2a0ecc6:	shl    $0x2,%r13
 2a0ecca:	shr    $0x20,%r13
 2a0ecce:	test   %r13,%r13
 2a0ecd1:	jne    2a196c2 <wasm[0]::function[1015]::helper::object_read+0x1b562>
 2a0ecd7:	shl    $0x2,%r12d
 2a0ecdb:	add    $0x14,%r12d
 2a0ecdf:	jb     2a196c4 <wasm[0]::function[1015]::helper::object_read+0x1b564>
 2a0ece5:	add    %r12d,%edi
 2a0ece8:	jb     2a196c6 <wasm[0]::function[1015]::helper::object_read+0x1b566>
 2a0ecee:	mov    %edi,%r13d
 2a0ecf1:	lea    (%r9,%r13,1),%rdi
 2a0ecf5:	cmp    %rax,%r13
 2a0ecf8:	cmova  %rbx,%rdi
 2a0ecfc:	shl    $0x2,%ecx
 2a0ecff:	lea    0x14(%rcx),%eax
 2a0ed02:	sub    %eax,%r12d
 2a0ed05:	sub    %r12,%rdi
 2a0ed08:	mov    (%rdi),%r9d
 2a0ed0b:	movzbl %r10b,%r10d
 2a0ed0f:	mov    %r8,0x1f0(%rsp)
 2a0ed17:	mov    %r10,0x1f8(%rsp)
 2a0ed1f:	jmp    2a0ee9f <wasm[0]::function[1015]::helper::object_read+0x10d3f>
 2a0ed24:	xor    %eax,%eax
 2a0ed26:	test   $0x1,%edi
 2a0ed2c:	jne    2a0ed70 <wasm[0]::function[1015]::helper::object_read+0x10c10>
 2a0ed32:	mov    0x2e0(%rsp),%r14
 2a0ed3a:	mov    0x28(%r14),%rax
 2a0ed3e:	mov    0x20(%r14),%r8
 2a0ed42:	mov    %edi,%r9d
 2a0ed45:	lea    0x4(%r8,%r9,1),%r8
 2a0ed4a:	xor    %r10,%r10
 2a0ed4d:	cmp    %rax,%r9
 2a0ed50:	cmova  %r10,%r8
 2a0ed54:	mov    (%r8),%eax
 2a0ed57:	mov    0x190(%rsp),%r8
 2a0ed5f:	mov    0x28(%r8),%r8
 2a0ed63:	cmp    0x160(%r8),%eax
 2a0ed6a:	sete   %al
 2a0ed6d:	movzbl %al,%eax
 2a0ed70:	test   %eax,%eax
 2a0ed72:	je     2a196c8 <wasm[0]::function[1015]::helper::object_read+0x1b568>
 2a0ed78:	test   %edi,%edi
 2a0ed7a:	je     2a196ca <wasm[0]::function[1015]::helper::object_read+0x1b56a>
 2a0ed80:	mov    0x2e0(%rsp),%r14
 2a0ed88:	mov    0x28(%r14),%rax
 2a0ed8c:	mov    0x20(%r14),%r8
 2a0ed90:	mov    %edi,%edi
 2a0ed92:	lea    (%r8,%rdi,1),%r10
 2a0ed96:	xor    %r9,%r9
 2a0ed99:	cmp    %rax,%rdi
 2a0ed9c:	cmova  %r9,%r10
 2a0eda0:	mov    0x10(%r10),%r10d
 2a0eda4:	test   %r10d,%r10d
 2a0eda7:	je     2a196cc <wasm[0]::function[1015]::helper::object_read+0x1b56c>
 2a0edad:	test   %r10d,%r10d
 2a0edb0:	je     2a196ce <wasm[0]::function[1015]::helper::object_read+0x1b56e>
 2a0edb6:	mov    %r10d,%ebx
 2a0edb9:	lea    (%r8,%rbx,1),%r10
 2a0edbd:	cmp    %rax,%rbx
 2a0edc0:	cmova  %r9,%r10
 2a0edc4:	mov    0x10(%r10),%r10d
 2a0edc8:	test   %r10d,%r10d
 2a0edcb:	je     2a196d0 <wasm[0]::function[1015]::helper::object_read+0x1b570>
 2a0edd1:	test   %r10d,%r10d
 2a0edd4:	je     2a196d2 <wasm[0]::function[1015]::helper::object_read+0x1b572>
 2a0edda:	mov    %r10d,%r10d
 2a0eddd:	lea    0x10(%r8,%r10,1),%r8
 2a0ede2:	cmp    %rax,%r10
 2a0ede5:	cmova  %r9,%r8
 2a0ede9:	cmp    (%r8),%ecx
 2a0edec:	setae  %al
 2a0edef:	cmp    $0x2,%ecx
 2a0edf2:	setae  %r8b
 2a0edf6:	or     %r8d,%eax
 2a0edf9:	test   %al,%al
 2a0edfb:	jne    2a196d4 <wasm[0]::function[1015]::helper::object_read+0x1b574>
 2a0ee01:	mov    0x2e0(%rsp),%r14
 2a0ee09:	mov    0x28(%r14),%r9
 2a0ee0d:	mov    %rdi,%r8
 2a0ee10:	add    0x20(%r14),%r8
 2a0ee14:	xor    %r10,%r10
 2a0ee17:	cmp    %r9,%rdi
 2a0ee1a:	cmova  %r10,%r8
 2a0ee1e:	mov    0x14(%r8),%r10d
 2a0ee22:	test   %ecx,%ecx
 2a0ee24:	je     2a0ee5c <wasm[0]::function[1015]::helper::object_read+0x10cfc>
 2a0ee2a:	mov    0x2e0(%rsp),%r14
 2a0ee32:	mov    0x28(%r14),%rax
 2a0ee36:	mov    0x20(%r14),%r9
 2a0ee3a:	add    %rdi,%r9
 2a0ee3d:	xor    %r8,%r8
 2a0ee40:	cmp    %rax,%rdi
 2a0ee43:	cmova  %r8,%r9
 2a0ee47:	mov    0x20(%r9),%r8
 2a0ee4b:	mov    0x2c(%r9),%r9d
 2a0ee4f:	mov    %r8,0x1f0(%rsp)
 2a0ee57:	jmp    2a0ee8a <wasm[0]::function[1015]::helper::object_read+0x10d2a>
 2a0ee5c:	mov    0x2e0(%rsp),%r14
 2a0ee64:	mov    0x28(%r14),%rax
 2a0ee68:	mov    0x20(%r14),%r8
 2a0ee6c:	lea    (%r8,%rdi,1),%r9
 2a0ee70:	xor    %r8,%r8
 2a0ee73:	cmp    %rax,%rdi
 2a0ee76:	cmova  %r8,%r9
 2a0ee7a:	mov    0x18(%r9),%r8
 2a0ee7e:	mov    %r8,0x1f0(%rsp)
 2a0ee86:	mov    0x28(%r9),%r9d
 2a0ee8a:	shl    $0x3,%ecx
 2a0ee8d:	shr    %cl,%r10d
 2a0ee90:	and    $0xff,%r10d
 2a0ee97:	mov    %r10,0x1f8(%rsp)
 2a0ee9f:	mov    %r11d,0xb8(%rsp)
 2a0eea7:	mov    %r9d,0x78(%rsp)
 2a0eeac:	mov    %esi,0xc0(%rsp)
 2a0eeb3:	mov    %edx,0xd8(%rsp)
 2a0eeba:	mov    $0x285,%edx
 2a0eebf:	mov    0x190(%rsp),%rsi
 2a0eec7:	mov    0x190(%rsp),%rdi
 2a0eecf:	call   2f4f240 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 2a0eed4:	mov    %eax,0xc8(%rsp)
 2a0eedb:	xor    %r11d,%r11d
 2a0eede:	test   %eax,%eax
 2a0eee0:	je     2a196d6 <wasm[0]::function[1015]::helper::object_read+0x1b576>
 2a0eee6:	movl   $0x0,0x88(%rsp)
 2a0eef1:	mov    0xb8(%rsp),%ebx
 2a0eef8:	mov    0x78(%rsp),%edi
 2a0eefc:	mov    0xc0(%rsp),%edx
 2a0ef03:	mov    0xd8(%rsp),%esi
 2a0ef0a:	xor    %r9,%r9
 2a0ef0d:	mov    0x248(%rsp),%rcx
 2a0ef15:	test   %cl,%cl
 2a0ef17:	jne    2a0ef35 <wasm[0]::function[1015]::helper::object_read+0x10dd5>
 2a0ef1d:	mov    %r11,%r10
 2a0ef20:	mov    %r11,0x1d0(%rsp)
 2a0ef28:	mov    %r9,0x1d8(%rsp)
 2a0ef30:	jmp    2a0fa74 <wasm[0]::function[1015]::helper::object_read+0x11914>
 2a0ef35:	mov    0xb8(%rsp),%r8d
 2a0ef3d:	mov    0x258(%rsp),%rcx
 2a0ef45:	mov    0x250(%rsp),%rdx
 2a0ef4d:	mov    0x190(%rsp),%rsi
 2a0ef55:	mov    0x190(%rsp),%rdi
 2a0ef5d:	call   2a7c940 <wasm[0]::function[1039]::helper::object_header_projection>
 2a0ef62:	mov    %eax,0xa8(%rsp)
 2a0ef69:	test   %eax,%eax
 2a0ef6b:	je     2a196d8 <wasm[0]::function[1015]::helper::object_read+0x1b578>
 2a0ef71:	test   %eax,%eax
 2a0ef73:	je     2a196da <wasm[0]::function[1015]::helper::object_read+0x1b57a>
 2a0ef79:	mov    0x2e0(%rsp),%r14
 2a0ef81:	mov    0x28(%r14),%rcx
 2a0ef85:	mov    0x20(%r14),%rsi
 2a0ef89:	mov    %eax,%edx
 2a0ef8b:	lea    (%rsi,%rdx,1),%rax
 2a0ef8f:	xor    %rsi,%rsi
 2a0ef92:	cmp    %rcx,%rdx
 2a0ef95:	cmova  %rsi,%rax
 2a0ef99:	mov    0x14(%rax),%eax
 2a0ef9c:	mov    %eax,0x90(%rsp)
 2a0efa3:	test   %eax,%eax
 2a0efa5:	je     2a196dc <wasm[0]::function[1015]::helper::object_read+0x1b57c>
 2a0efab:	mov    0x90(%rsp),%ecx
 2a0efb2:	xor    %eax,%eax
 2a0efb4:	test   $0x1,%ecx
 2a0efba:	jne    2a0f012 <wasm[0]::function[1015]::helper::object_read+0x10eb2>
 2a0efc0:	mov    0x2e0(%rsp),%r14
 2a0efc8:	mov    0x28(%r14),%rax
 2a0efcc:	mov    0x20(%r14),%rsi
 2a0efd0:	mov    %ecx,%edx
 2a0efd2:	lea    0x4(%rsi,%rdx,1),%rcx
 2a0efd7:	xor    %rsi,%rsi
 2a0efda:	cmp    %rax,%rdx
 2a0efdd:	cmova  %rsi,%rcx
 2a0efe1:	mov    (%rcx),%esi
 2a0efe3:	mov    0x190(%rsp),%rax
 2a0efeb:	mov    0x28(%rax),%rax
 2a0efef:	mov    0x158(%rax),%edx
 2a0eff5:	cmp    %edx,%esi
 2a0eff7:	sete   %al
 2a0effa:	movzbl %al,%eax
 2a0effd:	cmp    %edx,%esi
 2a0efff:	je     2a0f012 <wasm[0]::function[1015]::helper::object_read+0x10eb2>
 2a0f005:	mov    0x190(%rsp),%rdi
 2a0f00d:	call   3039cc5 <wasmtime_builtin_is_subtype>
 2a0f012:	test   %eax,%eax
 2a0f014:	jne    2a0f24c <wasm[0]::function[1015]::helper::object_read+0x110ec>
 2a0f01a:	mov    0xa8(%rsp),%edx
 2a0f021:	xor    %r12d,%r12d
 2a0f024:	test   %edx,%edx
 2a0f026:	je     2a196de <wasm[0]::function[1015]::helper::object_read+0x1b57e>
 2a0f02c:	mov    0xc8(%rsp),%r9d
 2a0f034:	mov    $0x4,%ecx
 2a0f039:	xor    %r8,%r8
 2a0f03c:	mov    0x190(%rsp),%rsi
 2a0f044:	mov    0x190(%rsp),%rdi
 2a0f04c:	call   2a76140 <wasm[0]::function[1032]::helper::ordinary_property_find>
 2a0f051:	test   %eax,%eax
 2a0f053:	je     2a0f08c <wasm[0]::function[1015]::helper::object_read+0x10f2c>
 2a0f059:	test   %eax,%eax
 2a0f05b:	je     2a196e0 <wasm[0]::function[1015]::helper::object_read+0x1b580>
 2a0f061:	test   %eax,%eax
 2a0f063:	je     2a196e2 <wasm[0]::function[1015]::helper::object_read+0x1b582>
 2a0f069:	mov    0x2e0(%rsp),%r14
 2a0f071:	mov    0x28(%r14),%rcx
 2a0f075:	mov    %eax,%edx
 2a0f077:	mov    %rdx,%rax
 2a0f07a:	add    0x20(%r14),%rax
 2a0f07e:	xor    %rsi,%rsi
 2a0f081:	cmp    %rcx,%rdx
 2a0f084:	cmova  %rsi,%rax
 2a0f088:	mov    0x14(%rax),%r12d
 2a0f08c:	mov    0x88(%rsp),%r10d
 2a0f094:	xor    %r11d,%r11d
 2a0f097:	xor    %r9,%r9
 2a0f09a:	test   %r12d,%r12d
 2a0f09d:	je     2a0f21e <wasm[0]::function[1015]::helper::object_read+0x110be>
 2a0f0a3:	test   %r12d,%r12d
 2a0f0a6:	je     2a196e4 <wasm[0]::function[1015]::helper::object_read+0x1b584>
 2a0f0ac:	mov    0x2e0(%rsp),%r14
 2a0f0b4:	mov    0x28(%r14),%rsi
 2a0f0b8:	mov    0x20(%r14),%r8
 2a0f0bc:	mov    %r12d,%edi
 2a0f0bf:	lea    (%r8,%rdi,1),%rax
 2a0f0c3:	xor    %r9,%r9
 2a0f0c6:	cmp    %rsi,%rdi
 2a0f0c9:	cmova  %r9,%rax
 2a0f0cd:	mov    0x10(%rax),%esi
 2a0f0d0:	mov    0x88(%rsp),%r10d
 2a0f0d8:	xor    %r11d,%r11d
 2a0f0db:	test   $0x1,%esi
 2a0f0e1:	jne    2a0f21e <wasm[0]::function[1015]::helper::object_read+0x110be>
 2a0f0e7:	mov    0x14(%rax),%edx
 2a0f0ea:	test   %edx,%edx
 2a0f0ec:	je     2a196e6 <wasm[0]::function[1015]::helper::object_read+0x1b586>
 2a0f0f2:	xor    %eax,%eax
 2a0f0f4:	test   $0x1,%edx
 2a0f0fa:	jne    2a0f13c <wasm[0]::function[1015]::helper::object_read+0x10fdc>
 2a0f100:	mov    0x2e0(%rsp),%r14
 2a0f108:	mov    0x28(%r14),%rax
 2a0f10c:	mov    0x20(%r14),%rsi
 2a0f110:	mov    %edx,%ecx
 2a0f112:	lea    0x4(%rsi,%rcx,1),%r10
 2a0f117:	xor    %rsi,%rsi
 2a0f11a:	cmp    %rax,%rcx
 2a0f11d:	cmova  %rsi,%r10
 2a0f121:	mov    (%r10),%eax
 2a0f124:	mov    0x190(%rsp),%rsi
 2a0f12c:	mov    0x28(%rsi),%rcx
 2a0f130:	cmp    0x120(%rcx),%eax
 2a0f136:	sete   %al
 2a0f139:	movzbl %al,%eax
 2a0f13c:	test   %eax,%eax
 2a0f13e:	jne    2a0f19a <wasm[0]::function[1015]::helper::object_read+0x1103a>
 2a0f144:	mov    0x190(%rsp),%rsi
 2a0f14c:	mov    0x190(%rsp),%rdi
 2a0f154:	call   2a1eec0 <wasm[0]::function[1024]::helper::property_value_resolve>
 2a0f159:	test   %eax,%eax
 2a0f15b:	je     2a196e8 <wasm[0]::function[1015]::helper::object_read+0x1b588>
 2a0f161:	test   %eax,%eax
 2a0f163:	je     2a196ea <wasm[0]::function[1015]::helper::object_read+0x1b58a>
 2a0f169:	mov    0x2e0(%rsp),%r14
 2a0f171:	mov    0x28(%r14),%rcx
 2a0f175:	mov    0x20(%r14),%rsi
 2a0f179:	mov    %eax,%edx
 2a0f17b:	lea    (%rsi,%rdx,1),%rax
 2a0f17f:	xor    %rsi,%rsi
 2a0f182:	cmp    %rcx,%rdx
 2a0f185:	cmova  %rsi,%rax
 2a0f189:	mov    0x18(%rax),%r11d
 2a0f18d:	mov    0x10(%rax),%r9
 2a0f191:	mov    0x1c(%rax),%r10d
 2a0f195:	jmp    2a0f21e <wasm[0]::function[1015]::helper::object_read+0x110be>
 2a0f19a:	xor    %eax,%eax
 2a0f19c:	test   $0x1,%edx
 2a0f1a2:	jne    2a0f1e3 <wasm[0]::function[1015]::helper::object_read+0x11083>
 2a0f1a8:	mov    0x2e0(%rsp),%r14
 2a0f1b0:	mov    0x28(%r14),%rax
 2a0f1b4:	mov    0x20(%r14),%rcx
 2a0f1b8:	mov    %edx,%esi
 2a0f1ba:	lea    0x4(%rcx,%rsi,1),%rcx
 2a0f1bf:	xor    %rdi,%rdi
 2a0f1c2:	cmp    %rax,%rsi
 2a0f1c5:	cmova  %rdi,%rcx
 2a0f1c9:	mov    (%rcx),%eax
 2a0f1cb:	mov    0x190(%rsp),%rsi
 2a0f1d3:	mov    0x28(%rsi),%rcx
 2a0f1d7:	cmp    0x120(%rcx),%eax
 2a0f1dd:	sete   %al
 2a0f1e0:	movzbl %al,%eax
 2a0f1e3:	test   %eax,%eax
 2a0f1e5:	je     2a196ec <wasm[0]::function[1015]::helper::object_read+0x1b58c>
 2a0f1eb:	test   %edx,%edx
 2a0f1ed:	je     2a196ee <wasm[0]::function[1015]::helper::object_read+0x1b58e>
 2a0f1f3:	mov    0x2e0(%rsp),%r14
 2a0f1fb:	mov    0x28(%r14),%rcx
 2a0f1ff:	mov    0x20(%r14),%rax
 2a0f203:	mov    %edx,%edx
 2a0f205:	add    %rdx,%rax
 2a0f208:	xor    %rsi,%rsi
 2a0f20b:	cmp    %rcx,%rdx
 2a0f20e:	cmova  %rsi,%rax
 2a0f212:	mov    0x18(%rax),%r11d
 2a0f216:	mov    0x10(%rax),%r9
 2a0f21a:	mov    0x1c(%rax),%r10d
 2a0f21e:	mov    0xb8(%rsp),%ebx
 2a0f225:	mov    0x78(%rsp),%edi
 2a0f229:	mov    0xc0(%rsp),%edx
 2a0f230:	mov    0xd8(%rsp),%esi
 2a0f237:	mov    %r11,0x1d0(%rsp)
 2a0f23f:	mov    %r9,0x1d8(%rsp)
 2a0f247:	jmp    2a0fa74 <wasm[0]::function[1015]::helper::object_read+0x11914>
 2a0f24c:	mov    0x90(%rsp),%eax
 2a0f253:	test   %eax,%eax
 2a0f255:	je     2a196f0 <wasm[0]::function[1015]::helper::object_read+0x1b590>
 2a0f25b:	mov    0x90(%rsp),%ecx
 2a0f262:	xor    %eax,%eax
 2a0f264:	test   $0x1,%ecx
 2a0f26a:	jne    2a0f2c2 <wasm[0]::function[1015]::helper::object_read+0x11162>
 2a0f270:	mov    0x2e0(%rsp),%r14
 2a0f278:	mov    0x28(%r14),%rax
 2a0f27c:	mov    0x20(%r14),%rsi
 2a0f280:	mov    %ecx,%edx
 2a0f282:	lea    0x4(%rsi,%rdx,1),%rcx
 2a0f287:	xor    %rsi,%rsi
 2a0f28a:	cmp    %rax,%rdx
 2a0f28d:	cmova  %rsi,%rcx
 2a0f291:	mov    (%rcx),%esi
 2a0f293:	mov    0x190(%rsp),%rax
 2a0f29b:	mov    0x28(%rax),%rax
 2a0f29f:	mov    0x158(%rax),%edx
 2a0f2a5:	cmp    %edx,%esi
 2a0f2a7:	sete   %al
 2a0f2aa:	movzbl %al,%eax
 2a0f2ad:	cmp    %edx,%esi
 2a0f2af:	je     2a0f2c2 <wasm[0]::function[1015]::helper::object_read+0x11162>
 2a0f2b5:	mov    0x190(%rsp),%rdi
 2a0f2bd:	call   3039cc5 <wasmtime_builtin_is_subtype>
 2a0f2c2:	test   %eax,%eax
 2a0f2c4:	je     2a196f2 <wasm[0]::function[1015]::helper::object_read+0x1b592>
 2a0f2ca:	mov    0x90(%rsp),%r8d
 2a0f2d2:	mov    0xb8(%rsp),%ebx
 2a0f2d9:	mov    0x88(%rsp),%r10d
 2a0f2e1:	mov    0x78(%rsp),%edi
 2a0f2e5:	mov    0xc0(%rsp),%edx
 2a0f2ec:	mov    0xd8(%rsp),%esi
 2a0f2f3:	xor    %ecx,%ecx
 2a0f2f5:	mov    %rcx,0x240(%rsp)
 2a0f2fd:	test   %r8d,%r8d
 2a0f300:	je     2a196f4 <wasm[0]::function[1015]::helper::object_read+0x1b594>
 2a0f306:	test   %r8d,%r8d
 2a0f309:	je     2a196f6 <wasm[0]::function[1015]::helper::object_read+0x1b596>
 2a0f30f:	mov    0x2e0(%rsp),%r14
 2a0f317:	mov    0x28(%r14),%rax
 2a0f31b:	mov    0x20(%r14),%rcx
 2a0f31f:	mov    %r8d,%r12d
 2a0f322:	lea    (%rcx,%r12,1),%r9
 2a0f326:	xor    %r11,%r11
 2a0f329:	cmp    %rax,%r12
 2a0f32c:	cmova  %r11,%r9
 2a0f330:	mov    0x10(%r9),%r9d
 2a0f334:	test   %r9d,%r9d
 2a0f337:	je     2a196f8 <wasm[0]::function[1015]::helper::object_read+0x1b598>
 2a0f33d:	test   %r9d,%r9d
 2a0f340:	je     2a196fa <wasm[0]::function[1015]::helper::object_read+0x1b59a>
 2a0f346:	mov    %r9d,%r12d
 2a0f349:	lea    (%rcx,%r12,1),%r9
 2a0f34d:	cmp    %rax,%r12
 2a0f350:	cmova  %r11,%r9
 2a0f354:	mov    0x10(%r9),%r9d
 2a0f358:	test   %r9d,%r9d
 2a0f35b:	je     2a196fc <wasm[0]::function[1015]::helper::object_read+0x1b59c>
 2a0f361:	test   %r9d,%r9d
 2a0f364:	je     2a196fe <wasm[0]::function[1015]::helper::object_read+0x1b59e>
 2a0f36a:	mov    %r9d,%r12d
 2a0f36d:	lea    0x10(%rcx,%r12,1),%rcx
 2a0f372:	cmp    %rax,%r12
 2a0f375:	cmova  %r11,%rcx
 2a0f379:	mov    (%rcx),%r12d
 2a0f37c:	mov    0xc8(%rsp),%r11d
 2a0f384:	mov    0x190(%rsp),%rax
 2a0f38c:	mov    0x28(%rax),%rax
 2a0f390:	mov    0x234(%rax),%r13d
 2a0f397:	mov    0x240(%rsp),%rax
 2a0f39f:	mov    %rax,0x1c8(%rsp)
 2a0f3a7:	mov    %r9d,0xa8(%rsp)
 2a0f3af:	mov    %r11d,0xd8(%rsp)
 2a0f3b7:	mov    %r8d,0xc0(%rsp)
 2a0f3bf:	mov    %ebx,0x78(%rsp)
 2a0f3c3:	mov    %r10d,0x88(%rsp)
 2a0f3cb:	mov    %edi,0xb8(%rsp)
 2a0f3d2:	mov    %edx,0x90(%rsp)
 2a0f3d9:	mov    %esi,0xc8(%rsp)
 2a0f3e0:	mov    0x2e8(%rsp),%r15
 2a0f3e8:	mov    (%r15),%rcx
 2a0f3eb:	mov    0x228(%rsp),%rax
 2a0f3f3:	cmp    %rax,%rcx
 2a0f3f6:	jae    2a186e5 <wasm[0]::function[1015]::helper::object_read+0x1a585>
 2a0f3fc:	mov    0xc0(%rsp),%r8d
 2a0f404:	mov    0x78(%rsp),%ebx
 2a0f408:	mov    0x88(%rsp),%r10d
 2a0f410:	mov    0xb8(%rsp),%edi
 2a0f417:	mov    0x90(%rsp),%edx
 2a0f41e:	mov    0xc8(%rsp),%esi
 2a0f425:	mov    0x240(%rsp),%rcx
 2a0f42d:	cmp    %r12d,%ecx
 2a0f430:	jb     2a0f443 <wasm[0]::function[1015]::helper::object_read+0x112e3>
 2a0f436:	mov    0x1c8(%rsp),%rax
 2a0f43e:	jmp    2a0f636 <wasm[0]::function[1015]::helper::object_read+0x114d6>
 2a0f443:	mov    0xa8(%rsp),%eax
 2a0f44a:	test   %eax,%eax
 2a0f44c:	je     2a19700 <wasm[0]::function[1015]::helper::object_read+0x1b5a0>
 2a0f452:	test   %eax,%eax
 2a0f454:	je     2a19702 <wasm[0]::function[1015]::helper::object_read+0x1b5a2>
 2a0f45a:	mov    0x2e0(%rsp),%r14
 2a0f462:	mov    0x28(%r14),%rdx
 2a0f466:	mov    0x20(%r14),%rsi
 2a0f46a:	mov    %eax,%r9d
 2a0f46d:	lea    0x10(%rsi,%r9,1),%r8
 2a0f472:	xor    %rdi,%rdi
 2a0f475:	cmp    %rdx,%r9
 2a0f478:	cmova  %rdi,%r8
 2a0f47c:	mov    (%r8),%r8d
 2a0f47f:	cmp    %r8d,%ecx
 2a0f482:	jae    2a19704 <wasm[0]::function[1015]::helper::object_read+0x1b5a4>
 2a0f488:	mov    %r8d,%r9d
 2a0f48b:	shl    $0x2,%r9
 2a0f48f:	shr    $0x20,%r9
 2a0f493:	test   %r9,%r9
 2a0f496:	jne    2a19706 <wasm[0]::function[1015]::helper::object_read+0x1b5a6>
 2a0f49c:	shl    $0x2,%r8d
 2a0f4a0:	add    $0x14,%r8d
 2a0f4a4:	jb     2a19708 <wasm[0]::function[1015]::helper::object_read+0x1b5a8>
 2a0f4aa:	add    %r8d,%eax
 2a0f4ad:	jb     2a1970a <wasm[0]::function[1015]::helper::object_read+0x1b5aa>
 2a0f4b3:	mov    %eax,%r9d
 2a0f4b6:	lea    (%rsi,%r9,1),%rax
 2a0f4ba:	cmp    %rdx,%r9
 2a0f4bd:	cmova  %rdi,%rax
 2a0f4c1:	mov    %rcx,%rdx
 2a0f4c4:	shl    $0x2,%edx
 2a0f4c7:	mov    %rcx,0x240(%rsp)
 2a0f4cf:	lea    0x14(%rdx),%ecx
 2a0f4d2:	sub    %ecx,%r8d
 2a0f4d5:	sub    %r8,%rax
 2a0f4d8:	mov    (%rax),%edx
 2a0f4da:	test   %edx,%edx
 2a0f4dc:	je     2a1970c <wasm[0]::function[1015]::helper::object_read+0x1b5ac>
 2a0f4e2:	mov    0xd8(%rsp),%eax
 2a0f4e9:	cmp    %eax,%edx
 2a0f4eb:	je     2a0f5bd <wasm[0]::function[1015]::helper::object_read+0x1145d>
 2a0f4f1:	xor    %ecx,%ecx
 2a0f4f3:	test   %edx,%edx
 2a0f4f5:	je     2a0f535 <wasm[0]::function[1015]::helper::object_read+0x113d5>
 2a0f4fb:	xor    %ecx,%ecx
 2a0f4fd:	test   $0x1,%edx
 2a0f503:	jne    2a0f535 <wasm[0]::function[1015]::helper::object_read+0x113d5>
 2a0f509:	mov    0x2e0(%rsp),%r14
 2a0f511:	mov    0x28(%r14),%rcx
 2a0f515:	mov    0x20(%r14),%rsi
 2a0f519:	mov    %edx,%edi
 2a0f51b:	lea    0x4(%rsi,%rdi,1),%rsi
 2a0f520:	xor    %r8,%r8
 2a0f523:	cmp    %rcx,%rdi
 2a0f526:	cmova  %r8,%rsi
 2a0f52a:	mov    (%rsi),%ecx
 2a0f52c:	cmp    %r13d,%ecx
 2a0f52f:	sete   %cl
 2a0f532:	movzbl %cl,%ecx
 2a0f535:	test   %ecx,%ecx
 2a0f537:	je     2a1970e <wasm[0]::function[1015]::helper::object_read+0x1b5ae>
 2a0f53d:	xor    %ecx,%ecx
 2a0f53f:	test   %eax,%eax
 2a0f541:	je     2a0f589 <wasm[0]::function[1015]::helper::object_read+0x11429>
 2a0f547:	mov    0xd8(%rsp),%eax
 2a0f54e:	xor    %ecx,%ecx
 2a0f550:	test   $0x1,%eax
 2a0f555:	jne    2a0f589 <wasm[0]::function[1015]::helper::object_read+0x11429>
 2a0f55b:	mov    0x2e0(%rsp),%r14
 2a0f563:	mov    0x28(%r14),%rcx
 2a0f567:	mov    0x20(%r14),%rdi
 2a0f56b:	mov    %eax,%esi
 2a0f56d:	lea    0x4(%rdi,%rsi,1),%rax
 2a0f572:	xor    %rdi,%rdi
 2a0f575:	cmp    %rcx,%rsi
 2a0f578:	cmova  %rdi,%rax
 2a0f57c:	mov    (%rax),%ecx
 2a0f57e:	cmp    %r13d,%ecx
 2a0f581:	sete   %sil
 2a0f585:	movzbl %sil,%ecx
 2a0f589:	test   %ecx,%ecx
 2a0f58b:	je     2a19710 <wasm[0]::function[1015]::helper::object_read+0x1b5b0>
 2a0f591:	mov    0xd8(%rsp),%ecx
 2a0f598:	xor    %r8d,%r8d
 2a0f59b:	test   %ecx,%ecx
 2a0f59d:	je     2a19712 <wasm[0]::function[1015]::helper::object_read+0x1b5b2>
 2a0f5a3:	mov    0x190(%rsp),%rsi
 2a0f5ab:	mov    0x190(%rsp),%rdi
 2a0f5b3:	call   2b02800 <wasm[0]::function[1057]::helper::string_equality>
 2a0f5b8:	jmp    2a0f5c5 <wasm[0]::function[1015]::helper::object_read+0x11465>
 2a0f5bd:	mov    0x278(%rsp),%rax
 2a0f5c5:	mov    0xa8(%rsp),%r9d
 2a0f5cd:	mov    0xd8(%rsp),%r11d
 2a0f5d5:	mov    0xc0(%rsp),%r8d
 2a0f5dd:	mov    0x78(%rsp),%ebx
 2a0f5e1:	mov    0x88(%rsp),%r10d
 2a0f5e9:	mov    0xb8(%rsp),%edi
 2a0f5f0:	mov    0x90(%rsp),%edx
 2a0f5f7:	mov    0xc8(%rsp),%esi
 2a0f5fe:	test   %eax,%eax
 2a0f600:	je     2a0f613 <wasm[0]::function[1015]::helper::object_read+0x114b3>
 2a0f606:	mov    0x240(%rsp),%rcx
 2a0f60e:	jmp    2a0f636 <wasm[0]::function[1015]::helper::object_read+0x114d6>
 2a0f613:	mov    0x240(%rsp),%rcx
 2a0f61b:	add    $0x1,%ecx
 2a0f621:	mov    %rax,0x1c8(%rsp)
 2a0f629:	mov    %rcx,0x240(%rsp)
 2a0f631:	jmp    2a0f3a7 <wasm[0]::function[1015]::helper::object_read+0x11247>
 2a0f636:	xor    %r11d,%r11d
 2a0f639:	xor    %r9,%r9
 2a0f63c:	test   %eax,%eax
 2a0f63e:	jne    2a0f659 <wasm[0]::function[1015]::helper::object_read+0x114f9>
 2a0f644:	mov    %r11,0x1d0(%rsp)
 2a0f64c:	mov    %r9,0x1d8(%rsp)
 2a0f654:	jmp    2a0fa74 <wasm[0]::function[1015]::helper::object_read+0x11914>
 2a0f659:	test   %r8d,%r8d
 2a0f65c:	je     2a19714 <wasm[0]::function[1015]::helper::object_read+0x1b5b4>
 2a0f662:	xor    %eax,%eax
 2a0f664:	test   $0x1,%r8d
 2a0f66b:	jne    2a0f6af <wasm[0]::function[1015]::helper::object_read+0x1154f>
 2a0f671:	mov    0x2e0(%rsp),%r14
 2a0f679:	mov    0x28(%r14),%rax
 2a0f67d:	mov    0x20(%r14),%r9
 2a0f681:	mov    %r8d,%r10d
 2a0f684:	lea    0x4(%r9,%r10,1),%r9
 2a0f689:	xor    %r11,%r11
 2a0f68c:	cmp    %rax,%r10
 2a0f68f:	cmova  %r11,%r9
 2a0f693:	mov    (%r9),%eax
 2a0f696:	mov    0x190(%rsp),%r9
 2a0f69e:	mov    0x28(%r9),%r9
 2a0f6a2:	cmp    0x160(%r9),%eax
 2a0f6a9:	sete   %al
 2a0f6ac:	movzbl %al,%eax
 2a0f6af:	test   %eax,%eax
 2a0f6b1:	jne    2a0f8f7 <wasm[0]::function[1015]::helper::object_read+0x11797>
 2a0f6b7:	xor    %r9d,%r9d
 2a0f6ba:	test   $0x1,%r8d
 2a0f6c1:	jne    2a0f706 <wasm[0]::function[1015]::helper::object_read+0x115a6>
 2a0f6c7:	mov    0x2e0(%rsp),%r14
 2a0f6cf:	mov    0x28(%r14),%rax
 2a0f6d3:	mov    0x20(%r14),%r9
 2a0f6d7:	mov    %r8d,%r10d
 2a0f6da:	lea    0x4(%r9,%r10,1),%r9
 2a0f6df:	xor    %r11,%r11
 2a0f6e2:	cmp    %rax,%r10
 2a0f6e5:	cmova  %r11,%r9
 2a0f6e9:	mov    (%r9),%eax
 2a0f6ec:	mov    0x190(%rsp),%r9
 2a0f6f4:	mov    0x28(%r9),%r9
 2a0f6f8:	cmp    0x15c(%r9),%eax
 2a0f6ff:	sete   %al
 2a0f702:	movzbl %al,%r9d
 2a0f706:	test   %r9d,%r9d
 2a0f709:	je     2a19716 <wasm[0]::function[1015]::helper::object_read+0x1b5b6>
 2a0f70f:	test   %r8d,%r8d
 2a0f712:	je     2a19718 <wasm[0]::function[1015]::helper::object_read+0x1b5b8>
 2a0f718:	mov    0x2e0(%rsp),%r14
 2a0f720:	mov    0x28(%r14),%rax
 2a0f724:	mov    0x20(%r14),%r11
 2a0f728:	mov    %r8d,%r10d
 2a0f72b:	lea    (%r11,%r10,1),%r8
 2a0f72f:	xor    %r9,%r9
 2a0f732:	cmp    %rax,%r10
 2a0f735:	cmova  %r9,%r8
 2a0f739:	mov    0x14(%r8),%r12d
 2a0f73d:	mov    0x18(%r8),%r10d
 2a0f741:	mov    0x1c(%r8),%r8d
 2a0f745:	test   %r12d,%r12d
 2a0f748:	je     2a1971a <wasm[0]::function[1015]::helper::object_read+0x1b5ba>
 2a0f74e:	test   %r12d,%r12d
 2a0f751:	je     2a1971c <wasm[0]::function[1015]::helper::object_read+0x1b5bc>
 2a0f757:	mov    %r12d,%r14d
 2a0f75a:	lea    0x10(%r11,%r14,1),%r13
 2a0f75f:	cmp    %rax,%r14
 2a0f762:	cmova  %r9,%r13
 2a0f766:	mov    0x0(%r13),%r13d
 2a0f76a:	cmp    %r13d,%ecx
 2a0f76d:	jae    2a1971e <wasm[0]::function[1015]::helper::object_read+0x1b5be>
 2a0f773:	mov    %r13d,%r14d
 2a0f776:	shr    $0x20,%r14
 2a0f77a:	test   %r14,%r14
 2a0f77d:	jne    2a19720 <wasm[0]::function[1015]::helper::object_read+0x1b5c0>
 2a0f783:	add    $0x14,%r13d
 2a0f787:	jb     2a19722 <wasm[0]::function[1015]::helper::object_read+0x1b5c2>
 2a0f78d:	add    %r13d,%r12d
 2a0f790:	jb     2a19724 <wasm[0]::function[1015]::helper::object_read+0x1b5c4>
 2a0f796:	mov    %r12d,%r12d
 2a0f799:	add    %r12,%r11
 2a0f79c:	cmp    %rax,%r12
 2a0f79f:	cmova  %r9,%r11
 2a0f7a3:	lea    0x14(%rcx),%eax
 2a0f7a6:	sub    %eax,%r13d
 2a0f7a9:	sub    %r13,%r11
 2a0f7ac:	movzbq (%r11),%r11
 2a0f7b0:	test   %r10d,%r10d
 2a0f7b3:	je     2a0f849 <wasm[0]::function[1015]::helper::object_read+0x116e9>
 2a0f7b9:	test   %r10d,%r10d
 2a0f7bc:	je     2a19726 <wasm[0]::function[1015]::helper::object_read+0x1b5c6>
 2a0f7c2:	test   %r10d,%r10d
 2a0f7c5:	je     2a19728 <wasm[0]::function[1015]::helper::object_read+0x1b5c8>
 2a0f7cb:	mov    0x2e0(%rsp),%r14
 2a0f7d3:	mov    0x28(%r14),%rax
 2a0f7d7:	mov    0x20(%r14),%r9
 2a0f7db:	mov    %r10d,%r14d
 2a0f7de:	lea    0x10(%r9,%r14,1),%r13
 2a0f7e3:	xor    %r12,%r12
 2a0f7e6:	cmp    %rax,%r14
 2a0f7e9:	cmova  %r12,%r13
 2a0f7ed:	mov    0x0(%r13),%r13d
 2a0f7f1:	cmp    %r13d,%ecx
 2a0f7f4:	jae    2a1972a <wasm[0]::function[1015]::helper::object_read+0x1b5ca>
 2a0f7fa:	mov    %r13d,%r14d
 2a0f7fd:	shl    $0x3,%r14
 2a0f801:	shr    $0x20,%r14
 2a0f805:	test   %r14,%r14
 2a0f808:	jne    2a1972c <wasm[0]::function[1015]::helper::object_read+0x1b5cc>
 2a0f80e:	shl    $0x3,%r13d
 2a0f812:	add    $0x18,%r13d
 2a0f816:	jb     2a1972e <wasm[0]::function[1015]::helper::object_read+0x1b5ce>
 2a0f81c:	add    %r13d,%r10d
 2a0f81f:	jb     2a19730 <wasm[0]::function[1015]::helper::object_read+0x1b5d0>
 2a0f825:	mov    %r10d,%r10d
 2a0f828:	add    %r10,%r9
 2a0f82b:	cmp    %rax,%r10
 2a0f82e:	cmova  %r12,%r9
 2a0f832:	mov    %rcx,%r10
 2a0f835:	shl    $0x3,%r10d
 2a0f839:	add    $0x18,%r10d
 2a0f840:	sub    %r10d,%r13d
 2a0f843:	sub    %r13,%r9
 2a0f846:	mov    (%r9),%r9
 2a0f849:	xor    %r10d,%r10d
 2a0f84c:	test   %r8d,%r8d
 2a0f84f:	je     2a0f8de <wasm[0]::function[1015]::helper::object_read+0x1177e>
 2a0f855:	test   %r8d,%r8d
 2a0f858:	je     2a19732 <wasm[0]::function[1015]::helper::object_read+0x1b5d2>
 2a0f85e:	test   %r8d,%r8d
 2a0f861:	je     2a19734 <wasm[0]::function[1015]::helper::object_read+0x1b5d4>
 2a0f867:	mov    0x2e0(%rsp),%r14
 2a0f86f:	mov    0x28(%r14),%rax
 2a0f873:	mov    0x20(%r14),%r10
 2a0f877:	mov    %r8d,%r13d
 2a0f87a:	lea    0x10(%r10,%r13,1),%r12
 2a0f87f:	xor    %r15,%r15
 2a0f882:	cmp    %rax,%r13
 2a0f885:	cmova  %r15,%r12
 2a0f889:	mov    (%r12),%r12d
 2a0f88d:	cmp    %r12d,%ecx
 2a0f890:	jae    2a19736 <wasm[0]::function[1015]::helper::object_read+0x1b5d6>
 2a0f896:	mov    %r12d,%r13d
 2a0f899:	shl    $0x2,%r13
 2a0f89d:	shr    $0x20,%r13
 2a0f8a1:	test   %r13,%r13
 2a0f8a4:	jne    2a19738 <wasm[0]::function[1015]::helper::object_read+0x1b5d8>
 2a0f8aa:	shl    $0x2,%r12d
 2a0f8ae:	add    $0x14,%r12d
 2a0f8b2:	jb     2a1973a <wasm[0]::function[1015]::helper::object_read+0x1b5da>
 2a0f8b8:	add    %r12d,%r8d
 2a0f8bb:	jb     2a1973c <wasm[0]::function[1015]::helper::object_read+0x1b5dc>
 2a0f8c1:	mov    %r8d,%r13d
 2a0f8c4:	lea    (%r10,%r13,1),%r8
 2a0f8c8:	cmp    %rax,%r13
 2a0f8cb:	cmova  %r15,%r8
 2a0f8cf:	shl    $0x2,%ecx
 2a0f8d2:	lea    0x14(%rcx),%eax
 2a0f8d5:	sub    %eax,%r12d
 2a0f8d8:	sub    %r12,%r8
 2a0f8db:	mov    (%r8),%r10d
 2a0f8de:	movzbl %r11b,%r11d
 2a0f8e2:	mov    %r11,0x1d0(%rsp)
 2a0f8ea:	mov    %r9,0x1d8(%rsp)
 2a0f8f2:	jmp    2a0fa74 <wasm[0]::function[1015]::helper::object_read+0x11914>
 2a0f8f7:	xor    %eax,%eax
 2a0f8f9:	test   $0x1,%r8d
 2a0f900:	jne    2a0f944 <wasm[0]::function[1015]::helper::object_read+0x117e4>
 2a0f906:	mov    0x2e0(%rsp),%r14
 2a0f90e:	mov    0x28(%r14),%rax
 2a0f912:	mov    0x20(%r14),%r9
 2a0f916:	mov    %r8d,%r10d
 2a0f919:	lea    0x4(%r9,%r10,1),%r9
 2a0f91e:	xor    %r11,%r11
 2a0f921:	cmp    %rax,%r10
 2a0f924:	cmova  %r11,%r9
 2a0f928:	mov    (%r9),%eax
 2a0f92b:	mov    0x190(%rsp),%r9
 2a0f933:	mov    0x28(%r9),%r9
 2a0f937:	cmp    0x160(%r9),%eax
 2a0f93e:	sete   %al
 2a0f941:	movzbl %al,%eax
 2a0f944:	test   %eax,%eax
 2a0f946:	je     2a1973e <wasm[0]::function[1015]::helper::object_read+0x1b5de>
 2a0f94c:	test   %r8d,%r8d
 2a0f94f:	je     2a19740 <wasm[0]::function[1015]::helper::object_read+0x1b5e0>
 2a0f955:	mov    0x2e0(%rsp),%r14
 2a0f95d:	mov    0x28(%r14),%rax
 2a0f961:	mov    0x20(%r14),%r9
 2a0f965:	mov    %r8d,%r8d
 2a0f968:	lea    (%r9,%r8,1),%r11
 2a0f96c:	xor    %r10,%r10
 2a0f96f:	cmp    %rax,%r8
 2a0f972:	cmova  %r10,%r11
 2a0f976:	mov    0x10(%r11),%r11d
 2a0f97a:	test   %r11d,%r11d
 2a0f97d:	je     2a19742 <wasm[0]::function[1015]::helper::object_read+0x1b5e2>
 2a0f983:	test   %r11d,%r11d
 2a0f986:	je     2a19744 <wasm[0]::function[1015]::helper::object_read+0x1b5e4>
 2a0f98c:	mov    %r11d,%r12d
 2a0f98f:	lea    (%r9,%r12,1),%r11
 2a0f993:	cmp    %rax,%r12
 2a0f996:	cmova  %r10,%r11
 2a0f99a:	mov    0x10(%r11),%r11d
 2a0f99e:	test   %r11d,%r11d
 2a0f9a1:	je     2a19746 <wasm[0]::function[1015]::helper::object_read+0x1b5e6>
 2a0f9a7:	test   %r11d,%r11d
 2a0f9aa:	je     2a19748 <wasm[0]::function[1015]::helper::object_read+0x1b5e8>
 2a0f9b0:	mov    %r11d,%r11d
 2a0f9b3:	lea    0x10(%r9,%r11,1),%r9
 2a0f9b8:	cmp    %rax,%r11
 2a0f9bb:	cmova  %r10,%r9
 2a0f9bf:	cmp    (%r9),%ecx
 2a0f9c2:	setae  %al
 2a0f9c5:	cmp    $0x2,%ecx
 2a0f9c8:	setae  %r9b
 2a0f9cc:	or     %r9d,%eax
 2a0f9cf:	test   %al,%al
 2a0f9d1:	jne    2a1974a <wasm[0]::function[1015]::helper::object_read+0x1b5ea>
 2a0f9d7:	mov    0x2e0(%rsp),%r14
 2a0f9df:	mov    0x28(%r14),%r9
 2a0f9e3:	mov    %r8,%rax
 2a0f9e6:	add    0x20(%r14),%rax
 2a0f9ea:	xor    %r10,%r10
 2a0f9ed:	cmp    %r9,%r8
 2a0f9f0:	cmova  %r10,%rax
 2a0f9f4:	mov    0x14(%rax),%r11d
 2a0f9f8:	test   %ecx,%ecx
 2a0f9fa:	je     2a0fa32 <wasm[0]::function[1015]::helper::object_read+0x118d2>
 2a0fa00:	mov    0x2e0(%rsp),%r14
 2a0fa08:	mov    0x28(%r14),%r9
 2a0fa0c:	mov    0x20(%r14),%rax
 2a0fa10:	add    %r8,%rax
 2a0fa13:	xor    %r10,%r10
 2a0fa16:	cmp    %r9,%r8
 2a0fa19:	cmova  %r10,%rax
 2a0fa1d:	mov    0x20(%rax),%r9
 2a0fa21:	mov    0x2c(%rax),%r10d
 2a0fa25:	mov    %r9,0x1d8(%rsp)
 2a0fa2d:	jmp    2a0fa5f <wasm[0]::function[1015]::helper::object_read+0x118ff>
 2a0fa32:	mov    0x2e0(%rsp),%r14
 2a0fa3a:	mov    0x28(%r14),%r9
 2a0fa3e:	mov    0x20(%r14),%rax
 2a0fa42:	add    %r8,%rax
 2a0fa45:	xor    %r10,%r10
 2a0fa48:	cmp    %r9,%r8
 2a0fa4b:	cmova  %r10,%rax
 2a0fa4f:	mov    0x18(%rax),%r9
 2a0fa53:	mov    %r9,0x1d8(%rsp)
 2a0fa5b:	mov    0x28(%rax),%r10d
 2a0fa5f:	shl    $0x3,%ecx
 2a0fa62:	shr    %cl,%r11d
 2a0fa65:	and    $0xff,%r11d
 2a0fa6c:	mov    %r11,0x1d0(%rsp)
 2a0fa74:	mov    %ebx,0x88(%rsp)
 2a0fa7b:	mov    %r10d,0x78(%rsp)
 2a0fa80:	mov    %edi,0xc0(%rsp)
 2a0fa87:	mov    %edx,0xd8(%rsp)
 2a0fa8e:	mov    %esi,0xa8(%rsp)
 2a0fa95:	mov    0x198(%rsp),%rdx
 2a0fa9d:	mov    0x190(%rsp),%rsi
 2a0faa5:	mov    0x190(%rsp),%rdi
 2a0faad:	call   2f4f240 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 2a0fab2:	mov    %eax,0xb8(%rsp)
 2a0fab9:	xor    %ecx,%ecx
 2a0fabb:	mov    %rcx,0x220(%rsp)
 2a0fac3:	test   %eax,%eax
 2a0fac5:	je     2a1974c <wasm[0]::function[1015]::helper::object_read+0x1b5ec>
 2a0facb:	movl   $0x0,0x90(%rsp)
 2a0fad6:	mov    0x88(%rsp),%eax
 2a0fadd:	mov    0x78(%rsp),%edx
 2a0fae1:	mov    0xc0(%rsp),%esi
 2a0fae8:	mov    0xd8(%rsp),%r11d
 2a0faf0:	mov    0xa8(%rsp),%edi
 2a0faf7:	xor    %r9,%r9
 2a0fafa:	mov    0x248(%rsp),%rcx
 2a0fb02:	mov    0x248(%rsp),%r8
 2a0fb0a:	test   %r8b,%cl
 2a0fb0d:	jne    2a0fb38 <wasm[0]::function[1015]::helper::object_read+0x119d8>
 2a0fb13:	mov    0x220(%rsp),%r10
 2a0fb1b:	mov    %r9,0x200(%rsp)
 2a0fb23:	mov    0x220(%rsp),%rcx
 2a0fb2b:	mov    %rcx,0x208(%rsp)
 2a0fb33:	jmp    2a10707 <wasm[0]::function[1015]::helper::object_read+0x125a7>
 2a0fb38:	mov    0x88(%rsp),%r8d
 2a0fb40:	mov    0x258(%rsp),%rcx
 2a0fb48:	mov    0x250(%rsp),%rdx
 2a0fb50:	mov    0x190(%rsp),%rsi
 2a0fb58:	mov    0x190(%rsp),%rdi
 2a0fb60:	call   2a7c940 <wasm[0]::function[1039]::helper::object_header_projection>
 2a0fb65:	mov    %eax,0xc8(%rsp)
 2a0fb6c:	test   %eax,%eax
 2a0fb6e:	je     2a1974e <wasm[0]::function[1015]::helper::object_read+0x1b5ee>
 2a0fb74:	test   %eax,%eax
 2a0fb76:	je     2a19750 <wasm[0]::function[1015]::helper::object_read+0x1b5f0>
 2a0fb7c:	mov    0x2e0(%rsp),%r14
 2a0fb84:	mov    0x28(%r14),%rcx
 2a0fb88:	mov    0x20(%r14),%rsi
 2a0fb8c:	mov    %eax,%edx
 2a0fb8e:	lea    (%rsi,%rdx,1),%rax
 2a0fb92:	xor    %rsi,%rsi
 2a0fb95:	cmp    %rcx,%rdx
 2a0fb98:	cmova  %rsi,%rax
 2a0fb9c:	mov    0x14(%rax),%eax
 2a0fb9f:	mov    %eax,0xb0(%rsp)
 2a0fba6:	test   %eax,%eax
 2a0fba8:	je     2a19752 <wasm[0]::function[1015]::helper::object_read+0x1b5f2>
 2a0fbae:	mov    0xb0(%rsp),%ecx
 2a0fbb5:	xor    %eax,%eax
 2a0fbb7:	test   $0x1,%ecx
 2a0fbbd:	jne    2a0fc15 <wasm[0]::function[1015]::helper::object_read+0x11ab5>
 2a0fbc3:	mov    0x2e0(%rsp),%r14
 2a0fbcb:	mov    0x28(%r14),%rax
 2a0fbcf:	mov    0x20(%r14),%rsi
 2a0fbd3:	mov    %ecx,%edx
 2a0fbd5:	lea    0x4(%rsi,%rdx,1),%rcx
 2a0fbda:	xor    %rsi,%rsi
 2a0fbdd:	cmp    %rax,%rdx
 2a0fbe0:	cmova  %rsi,%rcx
 2a0fbe4:	mov    (%rcx),%esi
 2a0fbe6:	mov    0x190(%rsp),%rax
 2a0fbee:	mov    0x28(%rax),%rax
 2a0fbf2:	mov    0x158(%rax),%edx
 2a0fbf8:	cmp    %edx,%esi
 2a0fbfa:	sete   %al
 2a0fbfd:	movzbl %al,%eax
 2a0fc00:	cmp    %edx,%esi
 2a0fc02:	je     2a0fc15 <wasm[0]::function[1015]::helper::object_read+0x11ab5>
 2a0fc08:	mov    0x190(%rsp),%rdi
 2a0fc10:	call   3039cc5 <wasmtime_builtin_is_subtype>
 2a0fc15:	test   %eax,%eax
 2a0fc17:	jne    2a0fe9d <wasm[0]::function[1015]::helper::object_read+0x11d3d>
 2a0fc1d:	mov    0xc8(%rsp),%edx
 2a0fc24:	xor    %ebx,%ebx
 2a0fc26:	test   %edx,%edx
 2a0fc28:	je     2a19754 <wasm[0]::function[1015]::helper::object_read+0x1b5f4>
 2a0fc2e:	mov    0xb8(%rsp),%r9d
 2a0fc36:	mov    $0x4,%ecx
 2a0fc3b:	xor    %r8,%r8
 2a0fc3e:	mov    0x190(%rsp),%rsi
 2a0fc46:	mov    0x190(%rsp),%rdi
 2a0fc4e:	call   2a76140 <wasm[0]::function[1032]::helper::ordinary_property_find>
 2a0fc53:	test   %eax,%eax
 2a0fc55:	je     2a0fc8d <wasm[0]::function[1015]::helper::object_read+0x11b2d>
 2a0fc5b:	test   %eax,%eax
 2a0fc5d:	je     2a19756 <wasm[0]::function[1015]::helper::object_read+0x1b5f6>
 2a0fc63:	test   %eax,%eax
 2a0fc65:	je     2a19758 <wasm[0]::function[1015]::helper::object_read+0x1b5f8>
 2a0fc6b:	mov    0x2e0(%rsp),%r14
 2a0fc73:	mov    0x28(%r14),%rcx
 2a0fc77:	mov    %eax,%edx
 2a0fc79:	mov    %rdx,%rax
 2a0fc7c:	add    0x20(%r14),%rax
 2a0fc80:	xor    %rsi,%rsi
 2a0fc83:	cmp    %rcx,%rdx
 2a0fc86:	cmova  %rsi,%rax
 2a0fc8a:	mov    0x14(%rax),%ebx
 2a0fc8d:	mov    0x90(%rsp),%r10d
 2a0fc95:	mov    %rax,%rcx
 2a0fc98:	mov    %rax,0x220(%rsp)
 2a0fca0:	xor    %ecx,%eax
 2a0fca2:	mov    %rax,0x220(%rsp)
 2a0fcaa:	xor    %r9,%r9
 2a0fcad:	test   %ebx,%ebx
 2a0fcaf:	jne    2a0fcc2 <wasm[0]::function[1015]::helper::object_read+0x11b62>
 2a0fcb5:	mov    0x220(%rsp),%rbx
 2a0fcbd:	jmp    2a0fe67 <wasm[0]::function[1015]::helper::object_read+0x11d07>
 2a0fcc2:	test   %ebx,%ebx
 2a0fcc4:	je     2a1975a <wasm[0]::function[1015]::helper::object_read+0x1b5fa>
 2a0fcca:	mov    0x2e0(%rsp),%r14
 2a0fcd2:	mov    0x28(%r14),%rcx
 2a0fcd6:	mov    0x20(%r14),%rax
 2a0fcda:	mov    %ebx,%edx
 2a0fcdc:	add    %rdx,%rax
 2a0fcdf:	xor    %r9,%r9
 2a0fce2:	cmp    %rcx,%rdx
 2a0fce5:	cmova  %r9,%rax
 2a0fce9:	mov    0x10(%rax),%ecx
 2a0fcec:	mov    0x90(%rsp),%r10d
 2a0fcf4:	mov    %rdx,%rsi
 2a0fcf7:	mov    %rdx,0x220(%rsp)
 2a0fcff:	xor    %esi,%edx
 2a0fd01:	mov    %rdx,0x220(%rsp)
 2a0fd09:	test   $0x1,%ecx
 2a0fd0f:	je     2a0fd22 <wasm[0]::function[1015]::helper::object_read+0x11bc2>
 2a0fd15:	mov    0x220(%rsp),%rbx
 2a0fd1d:	jmp    2a0fe67 <wasm[0]::function[1015]::helper::object_read+0x11d07>
 2a0fd22:	mov    0x14(%rax),%edx
 2a0fd25:	test   %edx,%edx
 2a0fd27:	je     2a1975c <wasm[0]::function[1015]::helper::object_read+0x1b5fc>
 2a0fd2d:	xor    %eax,%eax
 2a0fd2f:	test   $0x1,%edx
 2a0fd35:	jne    2a0fd76 <wasm[0]::function[1015]::helper::object_read+0x11c16>
 2a0fd3b:	mov    0x2e0(%rsp),%r14
 2a0fd43:	mov    0x28(%r14),%rax
 2a0fd47:	mov    0x20(%r14),%rcx
 2a0fd4b:	mov    %edx,%esi
 2a0fd4d:	lea    0x4(%rcx,%rsi,1),%rcx
 2a0fd52:	xor    %rdi,%rdi
 2a0fd55:	cmp    %rax,%rsi
 2a0fd58:	cmova  %rdi,%rcx
 2a0fd5c:	mov    (%rcx),%eax
 2a0fd5e:	mov    0x190(%rsp),%rsi
 2a0fd66:	mov    0x28(%rsi),%rcx
 2a0fd6a:	cmp    0x120(%rcx),%eax
 2a0fd70:	sete   %al
 2a0fd73:	movzbl %al,%eax
 2a0fd76:	test   %eax,%eax
 2a0fd78:	jne    2a0fdd3 <wasm[0]::function[1015]::helper::object_read+0x11c73>
 2a0fd7e:	mov    0x190(%rsp),%rsi
 2a0fd86:	mov    0x190(%rsp),%rdi
 2a0fd8e:	call   2a1eec0 <wasm[0]::function[1024]::helper::property_value_resolve>
 2a0fd93:	test   %eax,%eax
 2a0fd95:	je     2a1975e <wasm[0]::function[1015]::helper::object_read+0x1b5fe>
 2a0fd9b:	test   %eax,%eax
 2a0fd9d:	je     2a19760 <wasm[0]::function[1015]::helper::object_read+0x1b600>
 2a0fda3:	mov    0x2e0(%rsp),%r14
 2a0fdab:	mov    0x28(%r14),%rdi
 2a0fdaf:	mov    0x20(%r14),%rsi
 2a0fdb3:	mov    %eax,%r8d
 2a0fdb6:	add    %r8,%rsi
 2a0fdb9:	xor    %r9,%r9
 2a0fdbc:	cmp    %rdi,%r8
 2a0fdbf:	cmova  %r9,%rsi
 2a0fdc3:	mov    0x18(%rsi),%ebx
 2a0fdc6:	mov    0x10(%rsi),%r9
 2a0fdca:	mov    0x1c(%rsi),%r10d
 2a0fdce:	jmp    2a0fe57 <wasm[0]::function[1015]::helper::object_read+0x11cf7>
 2a0fdd3:	xor    %eax,%eax
 2a0fdd5:	test   $0x1,%edx
 2a0fddb:	jne    2a0fe1d <wasm[0]::function[1015]::helper::object_read+0x11cbd>
 2a0fde1:	mov    0x2e0(%rsp),%r14
 2a0fde9:	mov    0x28(%r14),%rax
 2a0fded:	mov    0x20(%r14),%rsi
 2a0fdf1:	mov    %edx,%ecx
 2a0fdf3:	lea    0x4(%rsi,%rcx,1),%r9
 2a0fdf8:	xor    %rsi,%rsi
 2a0fdfb:	cmp    %rax,%rcx
 2a0fdfe:	cmova  %rsi,%r9
 2a0fe02:	mov    (%r9),%eax
 2a0fe05:	mov    0x190(%rsp),%rsi
 2a0fe0d:	mov    0x28(%rsi),%rcx
 2a0fe11:	cmp    0x120(%rcx),%eax
 2a0fe17:	sete   %al
 2a0fe1a:	movzbl %al,%eax
 2a0fe1d:	test   %eax,%eax
 2a0fe1f:	je     2a19762 <wasm[0]::function[1015]::helper::object_read+0x1b602>
 2a0fe25:	test   %edx,%edx
 2a0fe27:	je     2a19764 <wasm[0]::function[1015]::helper::object_read+0x1b604>
 2a0fe2d:	mov    0x2e0(%rsp),%r14
 2a0fe35:	mov    0x28(%r14),%rcx
 2a0fe39:	mov    0x20(%r14),%rax
 2a0fe3d:	mov    %edx,%edx
 2a0fe3f:	add    %rdx,%rax
 2a0fe42:	xor    %rsi,%rsi
 2a0fe45:	cmp    %rcx,%rdx
 2a0fe48:	cmova  %rsi,%rax
 2a0fe4c:	mov    0x18(%rax),%ebx
 2a0fe4f:	mov    0x10(%rax),%r9
 2a0fe53:	mov    0x1c(%rax),%r10d
 2a0fe57:	mov    0x278(%rsp),%rax
 2a0fe5f:	mov    %rax,0x220(%rsp)
 2a0fe67:	mov    0x88(%rsp),%eax
 2a0fe6e:	mov    0x78(%rsp),%edx
 2a0fe72:	mov    0xc0(%rsp),%esi
 2a0fe79:	mov    0xd8(%rsp),%r11d
 2a0fe81:	mov    0xa8(%rsp),%edi
 2a0fe88:	mov    %r9,0x200(%rsp)
 2a0fe90:	mov    %rbx,0x208(%rsp)
 2a0fe98:	jmp    2a10707 <wasm[0]::function[1015]::helper::object_read+0x125a7>
 2a0fe9d:	mov    0xb0(%rsp),%eax
 2a0fea4:	test   %eax,%eax
 2a0fea6:	je     2a19766 <wasm[0]::function[1015]::helper::object_read+0x1b606>
 2a0feac:	mov    0xb0(%rsp),%ecx
 2a0feb3:	xor    %eax,%eax
 2a0feb5:	test   $0x1,%ecx
 2a0febb:	jne    2a0ff13 <wasm[0]::function[1015]::helper::object_read+0x11db3>
 2a0fec1:	mov    0x2e0(%rsp),%r14
 2a0fec9:	mov    0x28(%r14),%rax
 2a0fecd:	mov    0x20(%r14),%rsi
 2a0fed1:	mov    %ecx,%edx
 2a0fed3:	lea    0x4(%rsi,%rdx,1),%rcx
 2a0fed8:	xor    %rsi,%rsi
 2a0fedb:	cmp    %rax,%rdx
 2a0fede:	cmova  %rsi,%rcx
 2a0fee2:	mov    (%rcx),%esi
 2a0fee4:	mov    0x190(%rsp),%r9
 2a0feec:	mov    0x28(%r9),%rax
 2a0fef0:	mov    0x158(%rax),%edx
 2a0fef6:	cmp    %edx,%esi
 2a0fef8:	sete   %al
 2a0fefb:	movzbl %al,%eax
 2a0fefe:	cmp    %edx,%esi
 2a0ff00:	je     2a0ff13 <wasm[0]::function[1015]::helper::object_read+0x11db3>
 2a0ff06:	mov    0x190(%rsp),%rdi
 2a0ff0e:	call   3039cc5 <wasmtime_builtin_is_subtype>
 2a0ff13:	test   %eax,%eax
 2a0ff15:	je     2a19768 <wasm[0]::function[1015]::helper::object_read+0x1b608>
 2a0ff1b:	mov    0xb0(%rsp),%r8d
 2a0ff23:	mov    0x88(%rsp),%eax
 2a0ff2a:	mov    0x78(%rsp),%edx
 2a0ff2e:	mov    0xc0(%rsp),%esi
 2a0ff35:	mov    0x90(%rsp),%r10d
 2a0ff3d:	mov    0xd8(%rsp),%r11d
 2a0ff45:	mov    0xa8(%rsp),%edi
 2a0ff4c:	xor    %ecx,%ecx
 2a0ff4e:	mov    %rcx,0x240(%rsp)
 2a0ff56:	test   %r8d,%r8d
 2a0ff59:	je     2a1976a <wasm[0]::function[1015]::helper::object_read+0x1b60a>
 2a0ff5f:	test   %r8d,%r8d
 2a0ff62:	je     2a1976c <wasm[0]::function[1015]::helper::object_read+0x1b60c>
 2a0ff68:	mov    0x2e0(%rsp),%r14
 2a0ff70:	mov    0x28(%r14),%rcx
 2a0ff74:	mov    0x20(%r14),%rbx
 2a0ff78:	mov    %r8d,%r13d
 2a0ff7b:	lea    (%rbx,%r13,1),%r9
 2a0ff7f:	xor    %r12,%r12
 2a0ff82:	cmp    %rcx,%r13
 2a0ff85:	cmova  %r12,%r9
 2a0ff89:	mov    0x10(%r9),%r9d
 2a0ff8d:	test   %r9d,%r9d
 2a0ff90:	je     2a1976e <wasm[0]::function[1015]::helper::object_read+0x1b60e>
 2a0ff96:	test   %r9d,%r9d
 2a0ff99:	je     2a19770 <wasm[0]::function[1015]::helper::object_read+0x1b610>
 2a0ff9f:	mov    %r9d,%r13d
 2a0ffa2:	lea    (%rbx,%r13,1),%r9
 2a0ffa6:	cmp    %rcx,%r13
 2a0ffa9:	cmova  %r12,%r9
 2a0ffad:	mov    0x10(%r9),%r9d
 2a0ffb1:	test   %r9d,%r9d
 2a0ffb4:	je     2a19772 <wasm[0]::function[1015]::helper::object_read+0x1b612>
 2a0ffba:	test   %r9d,%r9d
 2a0ffbd:	je     2a19774 <wasm[0]::function[1015]::helper::object_read+0x1b614>
 2a0ffc3:	mov    %r9d,%r13d
 2a0ffc6:	lea    0x10(%rbx,%r13,1),%rbx
 2a0ffcb:	cmp    %rcx,%r13
 2a0ffce:	cmova  %r12,%rbx
 2a0ffd2:	mov    (%rbx),%ebx
 2a0ffd4:	mov    0xb8(%rsp),%r13d
 2a0ffdc:	mov    0x190(%rsp),%rcx
 2a0ffe4:	mov    0x28(%rcx),%rcx
 2a0ffe8:	mov    0x234(%rcx),%r12d
 2a0ffef:	mov    0x240(%rsp),%rcx
 2a0fff7:	mov    %rcx,0x220(%rsp)
 2a0ffff:	mov    %r9d,0xc8(%rsp)
 2a10007:	mov    %r13d,0xa8(%rsp)
 2a1000f:	mov    %r8d,0xd8(%rsp)
 2a10017:	mov    %eax,0x90(%rsp)
 2a1001e:	mov    %edx,0xc0(%rsp)
 2a10025:	mov    %esi,0x78(%rsp)
 2a10029:	mov    %r10d,0x88(%rsp)
 2a10031:	mov    %r11d,0xb0(%rsp)
 2a10039:	mov    %edi,0xb8(%rsp)
 2a10040:	mov    0x2e8(%rsp),%r15
 2a10048:	mov    (%r15),%rdx
 2a1004b:	mov    0x228(%rsp),%rax
 2a10053:	cmp    %rax,%rdx
 2a10056:	jae    2a1871c <wasm[0]::function[1015]::helper::object_read+0x1a5bc>
 2a1005c:	mov    0xd8(%rsp),%r8d
 2a10064:	mov    0x90(%rsp),%eax
 2a1006b:	mov    0xc0(%rsp),%edx
 2a10072:	mov    0x78(%rsp),%esi
 2a10076:	mov    0x88(%rsp),%r10d
 2a1007e:	mov    0xb0(%rsp),%r11d
 2a10086:	mov    0xb8(%rsp),%edi
 2a1008d:	mov    0x240(%rsp),%rcx
 2a10095:	cmp    %ebx,%ecx
 2a10097:	jae    2a102af <wasm[0]::function[1015]::helper::object_read+0x1214f>
 2a1009d:	mov    0xc8(%rsp),%eax
 2a100a4:	test   %eax,%eax
 2a100a6:	je     2a19776 <wasm[0]::function[1015]::helper::object_read+0x1b616>
 2a100ac:	test   %eax,%eax
 2a100ae:	je     2a19778 <wasm[0]::function[1015]::helper::object_read+0x1b618>
 2a100b4:	mov    0x2e0(%rsp),%r14
 2a100bc:	mov    0x28(%r14),%rdx
 2a100c0:	mov    0x20(%r14),%rsi
 2a100c4:	mov    %eax,%r9d
 2a100c7:	lea    0x10(%rsi,%r9,1),%r8
 2a100cc:	xor    %rdi,%rdi
 2a100cf:	cmp    %rdx,%r9
 2a100d2:	cmova  %rdi,%r8
 2a100d6:	mov    (%r8),%r8d
 2a100d9:	cmp    %r8d,%ecx
 2a100dc:	jae    2a1977a <wasm[0]::function[1015]::helper::object_read+0x1b61a>
 2a100e2:	mov    %r8d,%r9d
 2a100e5:	shl    $0x2,%r9
 2a100e9:	shr    $0x20,%r9
 2a100ed:	test   %r9,%r9
 2a100f0:	jne    2a1977c <wasm[0]::function[1015]::helper::object_read+0x1b61c>
 2a100f6:	shl    $0x2,%r8d
 2a100fa:	add    $0x14,%r8d
 2a100fe:	jb     2a1977e <wasm[0]::function[1015]::helper::object_read+0x1b61e>
 2a10104:	add    %r8d,%eax
 2a10107:	jb     2a19780 <wasm[0]::function[1015]::helper::object_read+0x1b620>
 2a1010d:	mov    %eax,%r9d
 2a10110:	lea    (%rsi,%r9,1),%rax
 2a10114:	cmp    %rdx,%r9
 2a10117:	cmova  %rdi,%rax
 2a1011b:	mov    %rcx,%rdx
 2a1011e:	shl    $0x2,%edx
 2a10121:	mov    %rcx,0x240(%rsp)
 2a10129:	lea    0x14(%rdx),%ecx
 2a1012c:	sub    %ecx,%r8d
 2a1012f:	sub    %r8,%rax
 2a10132:	mov    (%rax),%edx
 2a10134:	test   %edx,%edx
 2a10136:	je     2a19782 <wasm[0]::function[1015]::helper::object_read+0x1b622>
 2a1013c:	mov    0xa8(%rsp),%eax
 2a10143:	cmp    %eax,%edx
 2a10145:	je     2a1021d <wasm[0]::function[1015]::helper::object_read+0x120bd>
 2a1014b:	xor    %ecx,%ecx
 2a1014d:	test   %edx,%edx
 2a1014f:	je     2a1018f <wasm[0]::function[1015]::helper::object_read+0x1202f>
 2a10155:	xor    %ecx,%ecx
 2a10157:	test   $0x1,%edx
 2a1015d:	jne    2a1018f <wasm[0]::function[1015]::helper::object_read+0x1202f>
 2a10163:	mov    0x2e0(%rsp),%r14
 2a1016b:	mov    0x28(%r14),%rcx
 2a1016f:	mov    0x20(%r14),%rsi
 2a10173:	mov    %edx,%edi
 2a10175:	lea    0x4(%rsi,%rdi,1),%rsi
 2a1017a:	xor    %r8,%r8
 2a1017d:	cmp    %rcx,%rdi
 2a10180:	cmova  %r8,%rsi
 2a10184:	mov    (%rsi),%ecx
 2a10186:	cmp    %r12d,%ecx
 2a10189:	sete   %cl
 2a1018c:	movzbl %cl,%ecx
 2a1018f:	test   %ecx,%ecx
 2a10191:	je     2a19784 <wasm[0]::function[1015]::helper::object_read+0x1b624>
 2a10197:	xor    %ecx,%ecx
 2a10199:	test   %eax,%eax
 2a1019b:	je     2a101e1 <wasm[0]::function[1015]::helper::object_read+0x12081>
 2a101a1:	mov    0xa8(%rsp),%eax
 2a101a8:	xor    %ecx,%ecx
 2a101aa:	test   $0x1,%eax
 2a101af:	jne    2a101e1 <wasm[0]::function[1015]::helper::object_read+0x12081>
 2a101b5:	mov    0x2e0(%rsp),%r14
 2a101bd:	mov    0x28(%r14),%rcx
 2a101c1:	mov    0x20(%r14),%rdi
 2a101c5:	mov    %eax,%esi
 2a101c7:	lea    0x4(%rdi,%rsi,1),%rax
 2a101cc:	xor    %rdi,%rdi
 2a101cf:	cmp    %rcx,%rsi
 2a101d2:	cmova  %rdi,%rax
 2a101d6:	mov    (%rax),%eax
 2a101d8:	cmp    %r12d,%eax
 2a101db:	sete   %al
 2a101de:	movzbl %al,%ecx
 2a101e1:	test   %ecx,%ecx
 2a101e3:	je     2a19786 <wasm[0]::function[1015]::helper::object_read+0x1b626>
 2a101e9:	mov    0xa8(%rsp),%ecx
 2a101f0:	xor    %r8d,%r8d
 2a101f3:	test   %ecx,%ecx
 2a101f5:	je     2a19788 <wasm[0]::function[1015]::helper::object_read+0x1b628>
 2a101fb:	mov    0x190(%rsp),%rsi
 2a10203:	mov    0x190(%rsp),%rdi
 2a1020b:	call   2b02800 <wasm[0]::function[1057]::helper::string_equality>
 2a10210:	mov    %rax,0x220(%rsp)
 2a10218:	jmp    2a1022d <wasm[0]::function[1015]::helper::object_read+0x120cd>
 2a1021d:	mov    0x278(%rsp),%rax
 2a10225:	mov    %rax,0x220(%rsp)
 2a1022d:	mov    0xc8(%rsp),%r9d
 2a10235:	mov    0xa8(%rsp),%r13d
 2a1023d:	mov    0xd8(%rsp),%r8d
 2a10245:	mov    0x90(%rsp),%eax
 2a1024c:	mov    0xc0(%rsp),%edx
 2a10253:	mov    0x78(%rsp),%esi
 2a10257:	mov    0x88(%rsp),%r10d
 2a1025f:	mov    0xb0(%rsp),%r11d
 2a10267:	mov    0xb8(%rsp),%edi
 2a1026e:	mov    0x220(%rsp),%rcx
 2a10276:	mov    0x220(%rsp),%r14
 2a1027e:	test   %r14d,%ecx
 2a10281:	je     2a10294 <wasm[0]::function[1015]::helper::object_read+0x12134>
 2a10287:	mov    0x240(%rsp),%rcx
 2a1028f:	jmp    2a102af <wasm[0]::function[1015]::helper::object_read+0x1214f>
 2a10294:	mov    0x240(%rsp),%rcx
 2a1029c:	add    $0x1,%ecx
 2a102a2:	mov    %rcx,0x240(%rsp)
 2a102aa:	jmp    2a0ffff <wasm[0]::function[1015]::helper::object_read+0x11e9f>
 2a102af:	xor    %r9,%r9
 2a102b2:	xor    %ebx,%ebx
 2a102b4:	mov    0x220(%rsp),%r12
 2a102bc:	mov    0x220(%rsp),%r13
 2a102c4:	test   %r13d,%r12d
 2a102c7:	jne    2a102e2 <wasm[0]::function[1015]::helper::object_read+0x12182>
 2a102cd:	mov    %r9,0x200(%rsp)
 2a102d5:	mov    %rbx,0x208(%rsp)
 2a102dd:	jmp    2a10707 <wasm[0]::function[1015]::helper::object_read+0x125a7>
 2a102e2:	test   %r8d,%r8d
 2a102e5:	je     2a1978a <wasm[0]::function[1015]::helper::object_read+0x1b62a>
 2a102eb:	xor    %r9d,%r9d
 2a102ee:	test   $0x1,%r8d
 2a102f5:	jne    2a1033b <wasm[0]::function[1015]::helper::object_read+0x121db>
 2a102fb:	mov    0x2e0(%rsp),%r14
 2a10303:	mov    0x28(%r14),%r9
 2a10307:	mov    0x20(%r14),%r10
 2a1030b:	mov    %r8d,%r12d
 2a1030e:	lea    0x4(%r10,%r12,1),%r10
 2a10313:	xor    %r13,%r13
 2a10316:	cmp    %r9,%r12
 2a10319:	cmova  %r13,%r10
 2a1031d:	mov    (%r10),%r9d
 2a10320:	mov    0x190(%rsp),%r10
 2a10328:	mov    0x28(%r10),%r10
 2a1032c:	cmp    0x160(%r10),%r9d
 2a10333:	sete   %r9b
 2a10337:	movzbl %r9b,%r9d
 2a1033b:	test   %r9d,%r9d
 2a1033e:	jne    2a10584 <wasm[0]::function[1015]::helper::object_read+0x12424>
 2a10344:	xor    %r9d,%r9d
 2a10347:	test   $0x1,%r8d
 2a1034e:	jne    2a10394 <wasm[0]::function[1015]::helper::object_read+0x12234>
 2a10354:	mov    0x2e0(%rsp),%r14
 2a1035c:	mov    0x28(%r14),%r9
 2a10360:	mov    0x20(%r14),%r10
 2a10364:	mov    %r8d,%ebx
 2a10367:	lea    0x4(%r10,%rbx,1),%r10
 2a1036c:	xor    %r12,%r12
 2a1036f:	cmp    %r9,%rbx
 2a10372:	cmova  %r12,%r10
 2a10376:	mov    (%r10),%r9d
 2a10379:	mov    0x190(%rsp),%r10
 2a10381:	mov    0x28(%r10),%r10
 2a10385:	cmp    0x15c(%r10),%r9d
 2a1038c:	sete   %r9b
 2a10390:	movzbl %r9b,%r9d
 2a10394:	test   %r9d,%r9d
 2a10397:	je     2a1978c <wasm[0]::function[1015]::helper::object_read+0x1b62c>
 2a1039d:	test   %r8d,%r8d
 2a103a0:	je     2a1978e <wasm[0]::function[1015]::helper::object_read+0x1b62e>
 2a103a6:	mov    0x2e0(%rsp),%r14
 2a103ae:	mov    0x28(%r14),%rbx
 2a103b2:	mov    0x20(%r14),%r12
 2a103b6:	mov    %r8d,%r10d
 2a103b9:	lea    (%r12,%r10,1),%r8
 2a103bd:	xor    %r9,%r9
 2a103c0:	cmp    %rbx,%r10
 2a103c3:	cmova  %r9,%r8
 2a103c7:	mov    0x14(%r8),%r13d
 2a103cb:	mov    0x18(%r8),%r10d
 2a103cf:	mov    0x1c(%r8),%r8d
 2a103d3:	test   %r13d,%r13d
 2a103d6:	je     2a19790 <wasm[0]::function[1015]::helper::object_read+0x1b630>
 2a103dc:	test   %r13d,%r13d
 2a103df:	je     2a19792 <wasm[0]::function[1015]::helper::object_read+0x1b632>
 2a103e5:	mov    %r13d,%r15d
 2a103e8:	lea    0x10(%r12,%r15,1),%r14
 2a103ed:	cmp    %rbx,%r15
 2a103f0:	cmova  %r9,%r14
 2a103f4:	mov    (%r14),%r14d
 2a103f7:	cmp    %r14d,%ecx
 2a103fa:	jae    2a19794 <wasm[0]::function[1015]::helper::object_read+0x1b634>
 2a10400:	mov    %r14d,%r15d
 2a10403:	shr    $0x20,%r15
 2a10407:	test   %r15,%r15
 2a1040a:	jne    2a19796 <wasm[0]::function[1015]::helper::object_read+0x1b636>
 2a10410:	add    $0x14,%r14d
 2a10414:	jb     2a19798 <wasm[0]::function[1015]::helper::object_read+0x1b638>
 2a1041a:	add    %r14d,%r13d
 2a1041d:	jb     2a1979a <wasm[0]::function[1015]::helper::object_read+0x1b63a>
 2a10423:	mov    %r13d,%r13d
 2a10426:	add    %r13,%r12
 2a10429:	cmp    %rbx,%r13
 2a1042c:	cmova  %r9,%r12
 2a10430:	lea    0x14(%rcx),%ebx
 2a10433:	sub    %ebx,%r14d
 2a10436:	sub    %r14,%r12
 2a10439:	movzbq (%r12),%rbx
 2a1043e:	test   %r10d,%r10d
 2a10441:	je     2a104d7 <wasm[0]::function[1015]::helper::object_read+0x12377>
 2a10447:	test   %r10d,%r10d
 2a1044a:	je     2a1979c <wasm[0]::function[1015]::helper::object_read+0x1b63c>
 2a10450:	test   %r10d,%r10d
 2a10453:	je     2a1979e <wasm[0]::function[1015]::helper::object_read+0x1b63e>
 2a10459:	mov    0x2e0(%rsp),%r14
 2a10461:	mov    0x28(%r14),%r9
 2a10465:	mov    0x20(%r14),%r12
 2a10469:	mov    %r10d,%r15d
 2a1046c:	lea    0x10(%r12,%r15,1),%r14
 2a10471:	xor    %r13,%r13
 2a10474:	cmp    %r9,%r15
 2a10477:	cmova  %r13,%r14
 2a1047b:	mov    (%r14),%r14d
 2a1047e:	cmp    %r14d,%ecx
 2a10481:	jae    2a197a0 <wasm[0]::function[1015]::helper::object_read+0x1b640>
 2a10487:	mov    %r14d,%r15d
 2a1048a:	shl    $0x3,%r15
 2a1048e:	shr    $0x20,%r15
 2a10492:	test   %r15,%r15
 2a10495:	jne    2a197a2 <wasm[0]::function[1015]::helper::object_read+0x1b642>
 2a1049b:	shl    $0x3,%r14d
 2a1049f:	add    $0x18,%r14d
 2a104a3:	jb     2a197a4 <wasm[0]::function[1015]::helper::object_read+0x1b644>
 2a104a9:	add    %r14d,%r10d
 2a104ac:	jb     2a197a6 <wasm[0]::function[1015]::helper::object_read+0x1b646>
 2a104b2:	mov    %r10d,%r15d
 2a104b5:	lea    (%r12,%r15,1),%r10
 2a104b9:	cmp    %r9,%r15
 2a104bc:	cmova  %r13,%r10
 2a104c0:	mov    %rcx,%r9
 2a104c3:	shl    $0x3,%r9d
 2a104c7:	add    $0x18,%r9d
 2a104ce:	sub    %r9d,%r14d
 2a104d1:	sub    %r14,%r10
 2a104d4:	mov    (%r10),%r9
 2a104d7:	xor    %r10d,%r10d
 2a104da:	test   %r8d,%r8d
 2a104dd:	je     2a1056c <wasm[0]::function[1015]::helper::object_read+0x1240c>
 2a104e3:	test   %r8d,%r8d
 2a104e6:	je     2a197a8 <wasm[0]::function[1015]::helper::object_read+0x1b648>
 2a104ec:	test   %r8d,%r8d
 2a104ef:	je     2a197aa <wasm[0]::function[1015]::helper::object_read+0x1b64a>
 2a104f5:	mov    0x2e0(%rsp),%r14
 2a104fd:	mov    0x28(%r14),%r10
 2a10501:	mov    0x20(%r14),%r12
 2a10505:	mov    %r8d,%r15d
 2a10508:	lea    0x10(%r12,%r15,1),%r14
 2a1050d:	xor    %r13,%r13
 2a10510:	cmp    %r10,%r15
 2a10513:	cmova  %r13,%r14
 2a10517:	mov    (%r14),%r14d
 2a1051a:	cmp    %r14d,%ecx
 2a1051d:	jae    2a197ac <wasm[0]::function[1015]::helper::object_read+0x1b64c>
 2a10523:	mov    %r14d,%r15d
 2a10526:	shl    $0x2,%r15
 2a1052a:	shr    $0x20,%r15
 2a1052e:	test   %r15,%r15
 2a10531:	jne    2a197ae <wasm[0]::function[1015]::helper::object_read+0x1b64e>
 2a10537:	shl    $0x2,%r14d
 2a1053b:	add    $0x14,%r14d
 2a1053f:	jb     2a197b0 <wasm[0]::function[1015]::helper::object_read+0x1b650>
 2a10545:	add    %r14d,%r8d
 2a10548:	jb     2a197b2 <wasm[0]::function[1015]::helper::object_read+0x1b652>
 2a1054e:	mov    %r8d,%r15d
 2a10551:	lea    (%r12,%r15,1),%r8
 2a10555:	cmp    %r10,%r15
 2a10558:	cmova  %r13,%r8
 2a1055c:	shl    $0x2,%ecx
 2a1055f:	lea    0x14(%rcx),%r10d
 2a10563:	sub    %r10d,%r14d
 2a10566:	sub    %r14,%r8
 2a10569:	mov    (%r8),%r10d
 2a1056c:	movzbl %bl,%ebx
 2a1056f:	mov    %r9,0x200(%rsp)
 2a10577:	mov    %rbx,0x208(%rsp)
 2a1057f:	jmp    2a10707 <wasm[0]::function[1015]::helper::object_read+0x125a7>
 2a10584:	xor    %r9d,%r9d
 2a10587:	test   $0x1,%r8d
 2a1058e:	jne    2a105d4 <wasm[0]::function[1015]::helper::object_read+0x12474>
 2a10594:	mov    0x2e0(%rsp),%r14
 2a1059c:	mov    0x28(%r14),%r9
 2a105a0:	mov    0x20(%r14),%r10
 2a105a4:	mov    %r8d,%r14d
 2a105a7:	lea    0x4(%r10,%r14,1),%r10
 2a105ac:	xor    %r15,%r15
 2a105af:	cmp    %r9,%r14
 2a105b2:	cmova  %r15,%r10
 2a105b6:	mov    (%r10),%r9d
 2a105b9:	mov    0x190(%rsp),%r10
 2a105c1:	mov    0x28(%r10),%r10
 2a105c5:	cmp    0x160(%r10),%r9d
 2a105cc:	sete   %r9b
 2a105d0:	movzbl %r9b,%r9d
 2a105d4:	test   %r9d,%r9d
 2a105d7:	je     2a197b4 <wasm[0]::function[1015]::helper::object_read+0x1b654>
 2a105dd:	test   %r8d,%r8d
 2a105e0:	je     2a197b6 <wasm[0]::function[1015]::helper::object_read+0x1b656>
 2a105e6:	mov    0x2e0(%rsp),%r14
 2a105ee:	mov    0x28(%r14),%r9
 2a105f2:	mov    0x20(%r14),%r10
 2a105f6:	mov    %r8d,%r8d
 2a105f9:	lea    (%r10,%r8,1),%r12
 2a105fd:	xor    %rbx,%rbx
 2a10600:	cmp    %r9,%r8
 2a10603:	cmova  %rbx,%r12
 2a10607:	mov    0x10(%r12),%r12d
 2a1060c:	test   %r12d,%r12d
 2a1060f:	je     2a197b8 <wasm[0]::function[1015]::helper::object_read+0x1b658>
 2a10615:	test   %r12d,%r12d
 2a10618:	je     2a197ba <wasm[0]::function[1015]::helper::object_read+0x1b65a>
 2a1061e:	mov    %r12d,%r13d
 2a10621:	lea    (%r10,%r13,1),%r12
 2a10625:	cmp    %r9,%r13
 2a10628:	cmova  %rbx,%r12
 2a1062c:	mov    0x10(%r12),%r12d
 2a10631:	test   %r12d,%r12d
 2a10634:	je     2a197bc <wasm[0]::function[1015]::helper::object_read+0x1b65c>
 2a1063a:	test   %r12d,%r12d
 2a1063d:	je     2a197be <wasm[0]::function[1015]::helper::object_read+0x1b65e>
 2a10643:	mov    %r12d,%r12d
 2a10646:	lea    0x10(%r10,%r12,1),%r10
 2a1064b:	cmp    %r9,%r12
 2a1064e:	cmova  %rbx,%r10
 2a10652:	cmp    (%r10),%ecx
 2a10655:	setae  %r9b
 2a10659:	cmp    $0x2,%ecx
 2a1065c:	setae  %r10b
 2a10660:	or     %r10d,%r9d
 2a10663:	test   %r9b,%r9b
 2a10666:	jne    2a197c0 <wasm[0]::function[1015]::helper::object_read+0x1b660>
 2a1066c:	mov    0x2e0(%rsp),%r14
 2a10674:	mov    0x28(%r14),%r10
 2a10678:	mov    %r8,%r9
 2a1067b:	add    0x20(%r14),%r9
 2a1067f:	xor    %rbx,%rbx
 2a10682:	cmp    %r10,%r8
 2a10685:	cmova  %rbx,%r9
 2a10689:	mov    0x14(%r9),%ebx
 2a1068d:	test   %ecx,%ecx
 2a1068f:	je     2a106c7 <wasm[0]::function[1015]::helper::object_read+0x12567>
 2a10695:	mov    0x2e0(%rsp),%r14
 2a1069d:	mov    0x28(%r14),%r9
 2a106a1:	mov    0x20(%r14),%r10
 2a106a5:	add    %r8,%r10
 2a106a8:	xor    %r12,%r12
 2a106ab:	cmp    %r9,%r8
 2a106ae:	cmova  %r12,%r10
 2a106b2:	mov    0x20(%r10),%r9
 2a106b6:	mov    0x2c(%r10),%r10d
 2a106ba:	mov    %r9,0x200(%rsp)
 2a106c2:	jmp    2a106f4 <wasm[0]::function[1015]::helper::object_read+0x12594>
 2a106c7:	mov    0x2e0(%rsp),%r14
 2a106cf:	mov    0x28(%r14),%r9
 2a106d3:	mov    0x20(%r14),%r10
 2a106d7:	add    %r8,%r10
 2a106da:	xor    %r12,%r12
 2a106dd:	cmp    %r9,%r8
 2a106e0:	cmova  %r12,%r10
 2a106e4:	mov    0x18(%r10),%r9
 2a106e8:	mov    %r9,0x200(%rsp)
 2a106f0:	mov    0x28(%r10),%r10d
 2a106f4:	shl    $0x3,%ecx
 2a106f7:	shr    %cl,%ebx
 2a106f9:	and    $0xff,%ebx
 2a106ff:	mov    %rbx,0x208(%rsp)
 2a10707:	mov    %eax,0x78(%rsp)
 2a1070b:	mov    %edx,0xc0(%rsp)
 2a10712:	mov    %esi,0x90(%rsp)
 2a10719:	mov    %r10d,0xd8(%rsp)
 2a10721:	mov    %r11d,0xa8(%rsp)
 2a10729:	mov    %edi,0xc8(%rsp)
 2a10730:	mov    $0x27c,%edx
 2a10735:	mov    0x190(%rsp),%rsi
 2a1073d:	mov    0x190(%rsp),%rdi
 2a10745:	call   2f4f240 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 2a1074a:	mov    %eax,0x88(%rsp)
 2a10751:	xor    %ebx,%ebx
 2a10753:	test   %eax,%eax
 2a10755:	je     2a197c2 <wasm[0]::function[1015]::helper::object_read+0x1b662>
 2a1075b:	movl   $0x0,0xb0(%rsp)
 2a10766:	mov    0x78(%rsp),%r8d
 2a1076b:	mov    %r8,0x198(%rsp)
 2a10773:	mov    0xc0(%rsp),%r8d
 2a1077b:	mov    0x90(%rsp),%esi
 2a10782:	mov    0xd8(%rsp),%r9d
 2a1078a:	mov    0xa8(%rsp),%edx
 2a10791:	mov    0xc8(%rsp),%edi
 2a10798:	xor    %r11,%r11
 2a1079b:	mov    0x248(%rsp),%rax
 2a107a3:	mov    0x248(%rsp),%rcx
 2a107ab:	test   %al,%cl
 2a107ad:	jne    2a107d3 <wasm[0]::function[1015]::helper::object_read+0x12673>
 2a107b3:	mov    0x198(%rsp),%rax
 2a107bb:	mov    %rbx,%r13
 2a107be:	mov    %r11,0x210(%rsp)
 2a107c6:	mov    %rbx,0x218(%rsp)
 2a107ce:	jmp    2a11385 <wasm[0]::function[1015]::helper::object_read+0x13225>
 2a107d3:	mov    0x78(%rsp),%r8d
 2a107d8:	mov    0x258(%rsp),%rcx
 2a107e0:	mov    0x250(%rsp),%rdx
 2a107e8:	mov    0x190(%rsp),%rsi
 2a107f0:	mov    0x190(%rsp),%rdi
 2a107f8:	call   2a7c940 <wasm[0]::function[1039]::helper::object_header_projection>
 2a107fd:	mov    %eax,0xb8(%rsp)
 2a10804:	test   %eax,%eax
 2a10806:	je     2a197c4 <wasm[0]::function[1015]::helper::object_read+0x1b664>
 2a1080c:	test   %eax,%eax
 2a1080e:	je     2a197c6 <wasm[0]::function[1015]::helper::object_read+0x1b666>
 2a10814:	mov    0x2e0(%rsp),%r14
 2a1081c:	mov    0x28(%r14),%rsi
 2a10820:	mov    0x20(%r14),%r8
 2a10824:	mov    %eax,%edi
 2a10826:	lea    (%r8,%rdi,1),%rax
 2a1082a:	xor    %r8,%r8
 2a1082d:	cmp    %rsi,%rdi
 2a10830:	cmova  %r8,%rax
 2a10834:	mov    0x14(%rax),%esi
 2a10837:	mov    %esi,0xd0(%rsp)
 2a1083e:	test   %esi,%esi
 2a10840:	je     2a197c8 <wasm[0]::function[1015]::helper::object_read+0x1b668>
 2a10846:	mov    0xd0(%rsp),%r8d
 2a1084e:	xor    %eax,%eax
 2a10850:	test   $0x1,%r8d
 2a10857:	jne    2a108b1 <wasm[0]::function[1015]::helper::object_read+0x12751>
 2a1085d:	mov    0x2e0(%rsp),%r14
 2a10865:	mov    0x28(%r14),%r11
 2a10869:	mov    0x20(%r14),%rcx
 2a1086d:	mov    %r8d,%eax
 2a10870:	lea    0x4(%rcx,%rax,1),%r8
 2a10875:	xor    %rcx,%rcx
 2a10878:	cmp    %r11,%rax
 2a1087b:	cmova  %rcx,%r8
 2a1087f:	mov    (%r8),%esi
 2a10882:	mov    0x190(%rsp),%rax
 2a1088a:	mov    0x28(%rax),%rax
 2a1088e:	mov    0x158(%rax),%edx
 2a10894:	cmp    %edx,%esi
 2a10896:	sete   %al
 2a10899:	movzbl %al,%eax
 2a1089c:	cmp    %edx,%esi
 2a1089e:	je     2a108b1 <wasm[0]::function[1015]::helper::object_read+0x12751>
 2a108a4:	mov    0x190(%rsp),%rdi
 2a108ac:	call   3039cc5 <wasmtime_builtin_is_subtype>
 2a108b1:	test   %eax,%eax
 2a108b3:	jne    2a10aff <wasm[0]::function[1015]::helper::object_read+0x1299f>
 2a108b9:	mov    0xb8(%rsp),%edx
 2a108c0:	xor    %r12d,%r12d
 2a108c3:	test   %edx,%edx
 2a108c5:	je     2a197ca <wasm[0]::function[1015]::helper::object_read+0x1b66a>
 2a108cb:	mov    0x88(%rsp),%r9d
 2a108d3:	mov    $0x4,%ecx
 2a108d8:	xor    %r8,%r8
 2a108db:	mov    0x190(%rsp),%rsi
 2a108e3:	mov    0x190(%rsp),%rdi
 2a108eb:	call   2a76140 <wasm[0]::function[1032]::helper::ordinary_property_find>
 2a108f0:	test   %eax,%eax
 2a108f2:	je     2a1092b <wasm[0]::function[1015]::helper::object_read+0x127cb>
 2a108f8:	test   %eax,%eax
 2a108fa:	je     2a197cc <wasm[0]::function[1015]::helper::object_read+0x1b66c>
 2a10900:	test   %eax,%eax
 2a10902:	je     2a197ce <wasm[0]::function[1015]::helper::object_read+0x1b66e>
 2a10908:	mov    0x2e0(%rsp),%r14
 2a10910:	mov    0x28(%r14),%rcx
 2a10914:	mov    %eax,%edx
 2a10916:	mov    %rdx,%rax
 2a10919:	add    0x20(%r14),%rax
 2a1091d:	xor    %rsi,%rsi
 2a10920:	cmp    %rcx,%rdx
 2a10923:	cmova  %rsi,%rax
 2a10927:	mov    0x14(%rax),%r12d
 2a1092b:	mov    0xb0(%rsp),%r13d
 2a10933:	xor    %r11,%r11
 2a10936:	xor    %ebx,%ebx
 2a10938:	test   %r12d,%r12d
 2a1093b:	je     2a10ab8 <wasm[0]::function[1015]::helper::object_read+0x12958>
 2a10941:	test   %r12d,%r12d
 2a10944:	je     2a197d0 <wasm[0]::function[1015]::helper::object_read+0x1b670>
 2a1094a:	mov    0x2e0(%rsp),%r14
 2a10952:	mov    0x28(%r14),%rcx
 2a10956:	mov    0x20(%r14),%rax
 2a1095a:	mov    %r12d,%edx
 2a1095d:	add    %rdx,%rax
 2a10960:	xor    %r11,%r11
 2a10963:	cmp    %rcx,%rdx
 2a10966:	cmova  %r11,%rax
 2a1096a:	mov    0x10(%rax),%ecx
 2a1096d:	mov    0xb0(%rsp),%r13d
 2a10975:	xor    %ebx,%ebx
 2a10977:	test   $0x1,%ecx
 2a1097d:	jne    2a10ab8 <wasm[0]::function[1015]::helper::object_read+0x12958>
 2a10983:	mov    0x14(%rax),%edx
 2a10986:	test   %edx,%edx
 2a10988:	je     2a197d2 <wasm[0]::function[1015]::helper::object_read+0x1b672>
 2a1098e:	xor    %eax,%eax
 2a10990:	test   $0x1,%edx
 2a10996:	jne    2a109d7 <wasm[0]::function[1015]::helper::object_read+0x12877>
 2a1099c:	mov    0x2e0(%rsp),%r14
 2a109a4:	mov    0x28(%r14),%rax
 2a109a8:	mov    0x20(%r14),%rcx
 2a109ac:	mov    %edx,%esi
 2a109ae:	lea    0x4(%rcx,%rsi,1),%rcx
 2a109b3:	xor    %rdi,%rdi
 2a109b6:	cmp    %rax,%rsi
 2a109b9:	cmova  %rdi,%rcx
 2a109bd:	mov    (%rcx),%eax
 2a109bf:	mov    0x190(%rsp),%rsi
 2a109c7:	mov    0x28(%rsi),%rcx
 2a109cb:	cmp    0x120(%rcx),%eax
 2a109d1:	sete   %al
 2a109d4:	movzbl %al,%eax
 2a109d7:	test   %eax,%eax
 2a109d9:	jne    2a10a34 <wasm[0]::function[1015]::helper::object_read+0x128d4>
 2a109df:	mov    0x190(%rsp),%rsi
 2a109e7:	mov    0x190(%rsp),%rdi
 2a109ef:	call   2a1eec0 <wasm[0]::function[1024]::helper::property_value_resolve>
 2a109f4:	test   %eax,%eax
 2a109f6:	je     2a197d4 <wasm[0]::function[1015]::helper::object_read+0x1b674>
 2a109fc:	test   %eax,%eax
 2a109fe:	je     2a197d6 <wasm[0]::function[1015]::helper::object_read+0x1b676>
 2a10a04:	mov    0x2e0(%rsp),%r14
 2a10a0c:	mov    0x28(%r14),%rcx
 2a10a10:	mov    0x20(%r14),%rsi
 2a10a14:	mov    %eax,%edx
 2a10a16:	lea    (%rsi,%rdx,1),%rax
 2a10a1a:	xor    %rsi,%rsi
 2a10a1d:	cmp    %rcx,%rdx
 2a10a20:	cmova  %rsi,%rax
 2a10a24:	mov    0x18(%rax),%ebx
 2a10a27:	mov    0x10(%rax),%r11
 2a10a2b:	mov    0x1c(%rax),%r13d
 2a10a2f:	jmp    2a10ab8 <wasm[0]::function[1015]::helper::object_read+0x12958>
 2a10a34:	xor    %eax,%eax
 2a10a36:	test   $0x1,%edx
 2a10a3c:	jne    2a10a7d <wasm[0]::function[1015]::helper::object_read+0x1291d>
 2a10a42:	mov    0x2e0(%rsp),%r14
 2a10a4a:	mov    0x28(%r14),%rax
 2a10a4e:	mov    0x20(%r14),%rcx
 2a10a52:	mov    %edx,%esi
 2a10a54:	lea    0x4(%rcx,%rsi,1),%rcx
 2a10a59:	xor    %rdi,%rdi
 2a10a5c:	cmp    %rax,%rsi
 2a10a5f:	cmova  %rdi,%rcx
 2a10a63:	mov    (%rcx),%eax
 2a10a65:	mov    0x190(%rsp),%rsi
 2a10a6d:	mov    0x28(%rsi),%rcx
 2a10a71:	cmp    0x120(%rcx),%eax
 2a10a77:	sete   %al
 2a10a7a:	movzbl %al,%eax
 2a10a7d:	test   %eax,%eax
 2a10a7f:	je     2a197d8 <wasm[0]::function[1015]::helper::object_read+0x1b678>
 2a10a85:	test   %edx,%edx
 2a10a87:	je     2a197da <wasm[0]::function[1015]::helper::object_read+0x1b67a>
 2a10a8d:	mov    0x2e0(%rsp),%r14
 2a10a95:	mov    0x28(%r14),%rsi
 2a10a99:	mov    0x20(%r14),%r8
 2a10a9d:	mov    %edx,%edi
 2a10a9f:	lea    (%r8,%rdi,1),%rdx
 2a10aa3:	xor    %r8,%r8
 2a10aa6:	cmp    %rsi,%rdi
 2a10aa9:	cmova  %r8,%rdx
 2a10aad:	mov    0x18(%rdx),%ebx
 2a10ab0:	mov    0x10(%rdx),%r11
 2a10ab4:	mov    0x1c(%rdx),%r13d
 2a10ab8:	mov    0x78(%rsp),%r8d
 2a10abd:	mov    %r8,0x198(%rsp)
 2a10ac5:	mov    0xc0(%rsp),%r8d
 2a10acd:	mov    0x90(%rsp),%esi
 2a10ad4:	mov    0xd8(%rsp),%r9d
 2a10adc:	mov    0xa8(%rsp),%edx
 2a10ae3:	mov    0xc8(%rsp),%edi
 2a10aea:	mov    %r11,0x210(%rsp)
 2a10af2:	mov    %rbx,0x218(%rsp)
 2a10afa:	jmp    2a1137d <wasm[0]::function[1015]::helper::object_read+0x1321d>
 2a10aff:	mov    0xd0(%rsp),%r10d
 2a10b07:	test   %r10d,%r10d
 2a10b0a:	je     2a197dc <wasm[0]::function[1015]::helper::object_read+0x1b67c>
 2a10b10:	mov    0xd0(%rsp),%ecx
 2a10b17:	xor    %eax,%eax
 2a10b19:	test   $0x1,%ecx
 2a10b1f:	jne    2a10b77 <wasm[0]::function[1015]::helper::object_read+0x12a17>
 2a10b25:	mov    0x2e0(%rsp),%r14
 2a10b2d:	mov    0x28(%r14),%rax
 2a10b31:	mov    0x20(%r14),%rsi
 2a10b35:	mov    %ecx,%edx
 2a10b37:	lea    0x4(%rsi,%rdx,1),%rcx
 2a10b3c:	xor    %rsi,%rsi
 2a10b3f:	cmp    %rax,%rdx
 2a10b42:	cmova  %rsi,%rcx
 2a10b46:	mov    (%rcx),%esi
 2a10b48:	mov    0x190(%rsp),%rax
 2a10b50:	mov    0x28(%rax),%rax
 2a10b54:	mov    0x158(%rax),%edx
 2a10b5a:	cmp    %edx,%esi
 2a10b5c:	sete   %al
 2a10b5f:	movzbl %al,%eax
 2a10b62:	cmp    %edx,%esi
 2a10b64:	je     2a10b77 <wasm[0]::function[1015]::helper::object_read+0x12a17>
 2a10b6a:	mov    0x190(%rsp),%rdi
 2a10b72:	call   3039cc5 <wasmtime_builtin_is_subtype>
 2a10b77:	test   %eax,%eax
 2a10b79:	je     2a197de <wasm[0]::function[1015]::helper::object_read+0x1b67e>
 2a10b7f:	mov    0xd0(%rsp),%r10d
 2a10b87:	mov    0x78(%rsp),%r8d
 2a10b8c:	mov    %r8,0x198(%rsp)
 2a10b94:	mov    0xc0(%rsp),%r8d
 2a10b9c:	mov    0x90(%rsp),%esi
 2a10ba3:	mov    0xd8(%rsp),%r9d
 2a10bab:	mov    0xb0(%rsp),%r13d
 2a10bb3:	mov    0xa8(%rsp),%edx
 2a10bba:	mov    0xc8(%rsp),%edi
 2a10bc1:	xor    %ecx,%ecx
 2a10bc3:	mov    %rcx,0x240(%rsp)
 2a10bcb:	test   %r10d,%r10d
 2a10bce:	je     2a197e0 <wasm[0]::function[1015]::helper::object_read+0x1b680>
 2a10bd4:	test   %r10d,%r10d
 2a10bd7:	je     2a197e2 <wasm[0]::function[1015]::helper::object_read+0x1b682>
 2a10bdd:	mov    0x2e0(%rsp),%r14
 2a10be5:	mov    0x28(%r14),%rax
 2a10be9:	mov    0x20(%r14),%rcx
 2a10bed:	mov    %r10d,%r12d
 2a10bf0:	lea    (%rcx,%r12,1),%r11
 2a10bf4:	xor    %rbx,%rbx
 2a10bf7:	cmp    %rax,%r12
 2a10bfa:	cmova  %rbx,%r11
 2a10bfe:	mov    0x10(%r11),%r11d
 2a10c02:	test   %r11d,%r11d
 2a10c05:	je     2a197e4 <wasm[0]::function[1015]::helper::object_read+0x1b684>
 2a10c0b:	test   %r11d,%r11d
 2a10c0e:	je     2a197e6 <wasm[0]::function[1015]::helper::object_read+0x1b686>
 2a10c14:	mov    %r11d,%r12d
 2a10c17:	lea    (%rcx,%r12,1),%r11
 2a10c1b:	cmp    %rax,%r12
 2a10c1e:	cmova  %rbx,%r11
 2a10c22:	mov    0x10(%r11),%r11d
 2a10c26:	test   %r11d,%r11d
 2a10c29:	je     2a197e8 <wasm[0]::function[1015]::helper::object_read+0x1b688>
 2a10c2f:	test   %r11d,%r11d
 2a10c32:	je     2a197ea <wasm[0]::function[1015]::helper::object_read+0x1b68a>
 2a10c38:	mov    %r11d,%r12d
 2a10c3b:	lea    0x10(%rcx,%r12,1),%rcx
 2a10c40:	cmp    %rax,%r12
 2a10c43:	cmova  %rbx,%rcx
 2a10c47:	mov    (%rcx),%ebx
 2a10c49:	mov    0x88(%rsp),%r14d
 2a10c51:	mov    0x190(%rsp),%rax
 2a10c59:	mov    0x28(%rax),%rax
 2a10c5d:	mov    0x234(%rax),%r12d
 2a10c64:	mov    0x240(%rsp),%rax
 2a10c6c:	mov    %rax,0x1c8(%rsp)
 2a10c74:	mov    %r11d,0xb8(%rsp)
 2a10c7c:	mov    %r14d,0xc8(%rsp)
 2a10c84:	mov    %r10d,0xa8(%rsp)
 2a10c8c:	mov    0x198(%rsp),%r10
 2a10c94:	mov    %r10d,0xb0(%rsp)
 2a10c9c:	mov    %r8d,0xd8(%rsp)
 2a10ca4:	mov    %esi,0x90(%rsp)
 2a10cab:	mov    %r9d,0xc0(%rsp)
 2a10cb3:	mov    %r13d,0x78(%rsp)
 2a10cb8:	mov    %edx,0xd0(%rsp)
 2a10cbf:	mov    %edi,0x88(%rsp)
 2a10cc6:	mov    0x2e8(%rsp),%r15
 2a10cce:	mov    (%r15),%rcx
 2a10cd1:	mov    0x228(%rsp),%rax
 2a10cd9:	cmp    %rax,%rcx
 2a10cdc:	jae    2a18753 <wasm[0]::function[1015]::helper::object_read+0x1a5f3>
 2a10ce2:	mov    0xa8(%rsp),%r10d
 2a10cea:	mov    0xb0(%rsp),%r8d
 2a10cf2:	mov    %r8,0x198(%rsp)
 2a10cfa:	mov    0xd8(%rsp),%r8d
 2a10d02:	mov    0x90(%rsp),%esi
 2a10d09:	mov    0xc0(%rsp),%r9d
 2a10d11:	mov    0x78(%rsp),%r13d
 2a10d16:	mov    0xd0(%rsp),%edx
 2a10d1d:	mov    0x88(%rsp),%edi
 2a10d24:	mov    0x240(%rsp),%rcx
 2a10d2c:	cmp    %ebx,%ecx
 2a10d2e:	jb     2a10d41 <wasm[0]::function[1015]::helper::object_read+0x12be1>
 2a10d34:	mov    0x1c8(%rsp),%rax
 2a10d3c:	jmp    2a10f4a <wasm[0]::function[1015]::helper::object_read+0x12dea>
 2a10d41:	mov    0xb8(%rsp),%eax
 2a10d48:	test   %eax,%eax
 2a10d4a:	je     2a197ec <wasm[0]::function[1015]::helper::object_read+0x1b68c>
 2a10d50:	test   %eax,%eax
 2a10d52:	je     2a197ee <wasm[0]::function[1015]::helper::object_read+0x1b68e>
 2a10d58:	mov    0x2e0(%rsp),%r14
 2a10d60:	mov    0x28(%r14),%rsi
 2a10d64:	mov    0x20(%r14),%rdi
 2a10d68:	mov    %eax,%r9d
 2a10d6b:	lea    0x10(%rdi,%r9,1),%rdx
 2a10d70:	xor    %r8,%r8
 2a10d73:	cmp    %rsi,%r9
 2a10d76:	cmova  %r8,%rdx
 2a10d7a:	mov    (%rdx),%edx
 2a10d7c:	cmp    %edx,%ecx
 2a10d7e:	jae    2a197f0 <wasm[0]::function[1015]::helper::object_read+0x1b690>
 2a10d84:	mov    %edx,%r9d
 2a10d87:	shl    $0x2,%r9
 2a10d8b:	shr    $0x20,%r9
 2a10d8f:	test   %r9,%r9
 2a10d92:	jne    2a197f2 <wasm[0]::function[1015]::helper::object_read+0x1b692>
 2a10d98:	shl    $0x2,%edx
 2a10d9b:	add    $0x14,%edx
 2a10d9e:	jb     2a197f4 <wasm[0]::function[1015]::helper::object_read+0x1b694>
 2a10da4:	add    %edx,%eax
 2a10da6:	jb     2a197f6 <wasm[0]::function[1015]::helper::object_read+0x1b696>
 2a10dac:	mov    %eax,%r10d
 2a10daf:	add    %r10,%rdi
 2a10db2:	cmp    %rsi,%r10
 2a10db5:	cmova  %r8,%rdi
 2a10db9:	mov    %rcx,%r11
 2a10dbc:	shl    $0x2,%r11d
 2a10dc0:	mov    %rcx,0x240(%rsp)
 2a10dc8:	add    $0x14,%r11d
 2a10dcf:	sub    %r11d,%edx
 2a10dd2:	sub    %rdx,%rdi
 2a10dd5:	mov    (%rdi),%edx
 2a10dd7:	test   %edx,%edx
 2a10dd9:	je     2a197f8 <wasm[0]::function[1015]::helper::object_read+0x1b698>
 2a10ddf:	mov    0xc8(%rsp),%eax
 2a10de6:	cmp    %eax,%edx
 2a10de8:	je     2a10eb8 <wasm[0]::function[1015]::helper::object_read+0x12d58>
 2a10dee:	xor    %ecx,%ecx
 2a10df0:	test   %edx,%edx
 2a10df2:	je     2a10e32 <wasm[0]::function[1015]::helper::object_read+0x12cd2>
 2a10df8:	xor    %ecx,%ecx
 2a10dfa:	test   $0x1,%edx
 2a10e00:	jne    2a10e32 <wasm[0]::function[1015]::helper::object_read+0x12cd2>
 2a10e06:	mov    0x2e0(%rsp),%r14
 2a10e0e:	mov    0x28(%r14),%rcx
 2a10e12:	mov    0x20(%r14),%rsi
 2a10e16:	mov    %edx,%edi
 2a10e18:	lea    0x4(%rsi,%rdi,1),%rsi
 2a10e1d:	xor    %r8,%r8
 2a10e20:	cmp    %rcx,%rdi
 2a10e23:	cmova  %r8,%rsi
 2a10e27:	mov    (%rsi),%ecx
 2a10e29:	cmp    %r12d,%ecx
 2a10e2c:	sete   %cl
 2a10e2f:	movzbl %cl,%ecx
 2a10e32:	test   %ecx,%ecx
 2a10e34:	je     2a197fa <wasm[0]::function[1015]::helper::object_read+0x1b69a>
 2a10e3a:	xor    %ecx,%ecx
 2a10e3c:	test   %eax,%eax
 2a10e3e:	je     2a10e84 <wasm[0]::function[1015]::helper::object_read+0x12d24>
 2a10e44:	mov    0xc8(%rsp),%eax
 2a10e4b:	xor    %ecx,%ecx
 2a10e4d:	test   $0x1,%eax
 2a10e52:	jne    2a10e84 <wasm[0]::function[1015]::helper::object_read+0x12d24>
 2a10e58:	mov    0x2e0(%rsp),%r14
 2a10e60:	mov    0x28(%r14),%rcx
 2a10e64:	mov    0x20(%r14),%rdi
 2a10e68:	mov    %eax,%esi
 2a10e6a:	lea    0x4(%rdi,%rsi,1),%rax
 2a10e6f:	xor    %rdi,%rdi
 2a10e72:	cmp    %rcx,%rsi
 2a10e75:	cmova  %rdi,%rax
 2a10e79:	mov    (%rax),%eax
 2a10e7b:	cmp    %r12d,%eax
 2a10e7e:	sete   %al
 2a10e81:	movzbl %al,%ecx
 2a10e84:	test   %ecx,%ecx
 2a10e86:	je     2a197fc <wasm[0]::function[1015]::helper::object_read+0x1b69c>
 2a10e8c:	mov    0xc8(%rsp),%ecx
 2a10e93:	xor    %r8d,%r8d
 2a10e96:	test   %ecx,%ecx
 2a10e98:	je     2a197fe <wasm[0]::function[1015]::helper::object_read+0x1b69e>
 2a10e9e:	mov    0x190(%rsp),%rsi
 2a10ea6:	mov    0x190(%rsp),%rdi
 2a10eae:	call   2b02800 <wasm[0]::function[1057]::helper::string_equality>
 2a10eb3:	jmp    2a10ec0 <wasm[0]::function[1015]::helper::object_read+0x12d60>
 2a10eb8:	mov    0x278(%rsp),%rax
 2a10ec0:	mov    0xb8(%rsp),%r11d
 2a10ec8:	mov    0xc8(%rsp),%r14d
 2a10ed0:	mov    0xa8(%rsp),%r10d
 2a10ed8:	mov    0xb0(%rsp),%r8d
 2a10ee0:	mov    %r8,0x198(%rsp)
 2a10ee8:	mov    0xd8(%rsp),%r8d
 2a10ef0:	mov    0x90(%rsp),%esi
 2a10ef7:	mov    0xc0(%rsp),%r9d
 2a10eff:	mov    0x78(%rsp),%r13d
 2a10f04:	mov    0xd0(%rsp),%edx
 2a10f0b:	mov    0x88(%rsp),%edi
 2a10f12:	test   %eax,%eax
 2a10f14:	je     2a10f27 <wasm[0]::function[1015]::helper::object_read+0x12dc7>
 2a10f1a:	mov    0x240(%rsp),%rcx
 2a10f22:	jmp    2a10f4a <wasm[0]::function[1015]::helper::object_read+0x12dea>
 2a10f27:	mov    0x240(%rsp),%rcx
 2a10f2f:	add    $0x1,%ecx
 2a10f35:	mov    %rax,0x1c8(%rsp)
 2a10f3d:	mov    %rcx,0x240(%rsp)
 2a10f45:	jmp    2a10c74 <wasm[0]::function[1015]::helper::object_read+0x12b14>
 2a10f4a:	xor    %r11,%r11
 2a10f4d:	xor    %ebx,%ebx
 2a10f4f:	test   %eax,%eax
 2a10f51:	jne    2a10f6c <wasm[0]::function[1015]::helper::object_read+0x12e0c>
 2a10f57:	mov    %r11,0x210(%rsp)
 2a10f5f:	mov    %rbx,0x218(%rsp)
 2a10f67:	jmp    2a1137d <wasm[0]::function[1015]::helper::object_read+0x1321d>
 2a10f6c:	test   %r10d,%r10d
 2a10f6f:	je     2a19800 <wasm[0]::function[1015]::helper::object_read+0x1b6a0>
 2a10f75:	xor    %eax,%eax
 2a10f77:	test   $0x1,%r10d
 2a10f7e:	jne    2a10fc2 <wasm[0]::function[1015]::helper::object_read+0x12e62>
 2a10f84:	mov    0x2e0(%rsp),%r14
 2a10f8c:	mov    0x28(%r14),%rax
 2a10f90:	mov    0x20(%r14),%r11
 2a10f94:	mov    %r10d,%ebx
 2a10f97:	lea    0x4(%r11,%rbx,1),%r11
 2a10f9c:	xor    %r12,%r12
 2a10f9f:	cmp    %rax,%rbx
 2a10fa2:	cmova  %r12,%r11
 2a10fa6:	mov    (%r11),%eax
 2a10fa9:	mov    0x190(%rsp),%r11
 2a10fb1:	mov    0x28(%r11),%r11
 2a10fb5:	cmp    0x160(%r11),%eax
 2a10fbc:	sete   %al
 2a10fbf:	movzbl %al,%eax
 2a10fc2:	test   %eax,%eax
 2a10fc4:	jne    2a11202 <wasm[0]::function[1015]::helper::object_read+0x130a2>
 2a10fca:	xor    %eax,%eax
 2a10fcc:	test   $0x1,%r10d
 2a10fd3:	jne    2a11019 <wasm[0]::function[1015]::helper::object_read+0x12eb9>
 2a10fd9:	mov    0x2e0(%rsp),%r14
 2a10fe1:	mov    0x28(%r14),%r11
 2a10fe5:	mov    0x20(%r14),%rax
 2a10fe9:	mov    %r10d,%r12d
 2a10fec:	lea    0x4(%rax,%r12,1),%rax
 2a10ff1:	xor    %r13,%r13
 2a10ff4:	cmp    %r11,%r12
 2a10ff7:	cmova  %r13,%rax
 2a10ffb:	mov    (%rax),%r11d
 2a10ffe:	mov    0x190(%rsp),%rax
 2a11006:	mov    0x28(%rax),%rax
 2a1100a:	cmp    0x15c(%rax),%r11d
 2a11011:	sete   %r11b
 2a11015:	movzbl %r11b,%eax
 2a11019:	test   %eax,%eax
 2a1101b:	je     2a19802 <wasm[0]::function[1015]::helper::object_read+0x1b6a2>
 2a11021:	test   %r10d,%r10d
 2a11024:	je     2a19804 <wasm[0]::function[1015]::helper::object_read+0x1b6a4>
 2a1102a:	mov    0x2e0(%rsp),%r14
 2a11032:	mov    0x28(%r14),%rax
 2a11036:	mov    0x20(%r14),%r14
 2a1103a:	mov    %r10d,%ebx
 2a1103d:	lea    (%r14,%rbx,1),%r10
 2a11041:	xor    %r11,%r11
 2a11044:	cmp    %rax,%rbx
 2a11047:	cmova  %r11,%r10
 2a1104b:	mov    0x14(%r10),%r13d
 2a1104f:	mov    0x18(%r10),%r12d
 2a11053:	mov    0x1c(%r10),%r10d
 2a11057:	test   %r13d,%r13d
 2a1105a:	je     2a19806 <wasm[0]::function[1015]::helper::object_read+0x1b6a6>
 2a11060:	test   %r13d,%r13d
 2a11063:	je     2a19808 <wasm[0]::function[1015]::helper::object_read+0x1b6a8>
 2a11069:	mov    %r13d,%r15d
 2a1106c:	lea    0x10(%r14,%r15,1),%rbx
 2a11071:	cmp    %rax,%r15
 2a11074:	cmova  %r11,%rbx
 2a11078:	mov    (%rbx),%ebx
 2a1107a:	cmp    %ebx,%ecx
 2a1107c:	jae    2a1980a <wasm[0]::function[1015]::helper::object_read+0x1b6aa>
 2a11082:	mov    %ebx,%r15d
 2a11085:	shr    $0x20,%r15
 2a11089:	test   %r15,%r15
 2a1108c:	jne    2a1980c <wasm[0]::function[1015]::helper::object_read+0x1b6ac>
 2a11092:	add    $0x14,%ebx
 2a11095:	jb     2a1980e <wasm[0]::function[1015]::helper::object_read+0x1b6ae>
 2a1109b:	add    %ebx,%r13d
 2a1109e:	jb     2a19810 <wasm[0]::function[1015]::helper::object_read+0x1b6b0>
 2a110a4:	mov    %r13d,%r15d
 2a110a7:	lea    (%r14,%r15,1),%r13
 2a110ab:	cmp    %rax,%r15
 2a110ae:	cmova  %r11,%r13
 2a110b2:	lea    0x14(%rcx),%eax
 2a110b5:	sub    %eax,%ebx
 2a110b7:	sub    %rbx,%r13
 2a110ba:	movzbq 0x0(%r13),%r15
 2a110bf:	test   %r12d,%r12d
 2a110c2:	je     2a11155 <wasm[0]::function[1015]::helper::object_read+0x12ff5>
 2a110c8:	test   %r12d,%r12d
 2a110cb:	je     2a19812 <wasm[0]::function[1015]::helper::object_read+0x1b6b2>
 2a110d1:	test   %r12d,%r12d
 2a110d4:	je     2a19814 <wasm[0]::function[1015]::helper::object_read+0x1b6b4>
 2a110da:	mov    0x2e0(%rsp),%r14
 2a110e2:	mov    0x28(%r14),%rax
 2a110e6:	mov    0x20(%r14),%r11
 2a110ea:	mov    %r12d,%ebx
 2a110ed:	lea    0x10(%r11,%rbx,1),%r14
 2a110f2:	xor    %r13,%r13
 2a110f5:	cmp    %rax,%rbx
 2a110f8:	cmova  %r13,%r14
 2a110fc:	mov    (%r14),%r14d
 2a110ff:	cmp    %r14d,%ecx
 2a11102:	jae    2a19816 <wasm[0]::function[1015]::helper::object_read+0x1b6b6>
 2a11108:	mov    %r14d,%ebx
 2a1110b:	shl    $0x3,%rbx
 2a1110f:	shr    $0x20,%rbx
 2a11113:	test   %rbx,%rbx
 2a11116:	jne    2a19818 <wasm[0]::function[1015]::helper::object_read+0x1b6b8>
 2a1111c:	shl    $0x3,%r14d
 2a11120:	add    $0x18,%r14d
 2a11124:	jb     2a1981a <wasm[0]::function[1015]::helper::object_read+0x1b6ba>
 2a1112a:	add    %r14d,%r12d
 2a1112d:	jb     2a1981c <wasm[0]::function[1015]::helper::object_read+0x1b6bc>
 2a11133:	mov    %r12d,%ebx
 2a11136:	add    %rbx,%r11
 2a11139:	cmp    %rax,%rbx
 2a1113c:	cmova  %r13,%r11
 2a11140:	mov    %rcx,%rax
 2a11143:	shl    $0x3,%eax
 2a11146:	add    $0x18,%eax
 2a1114c:	sub    %eax,%r14d
 2a1114f:	sub    %r14,%r11
 2a11152:	mov    (%r11),%r11
 2a11155:	xor    %r13d,%r13d
 2a11158:	test   %r10d,%r10d
 2a1115b:	je     2a111e9 <wasm[0]::function[1015]::helper::object_read+0x13089>
 2a11161:	test   %r10d,%r10d
 2a11164:	je     2a1981e <wasm[0]::function[1015]::helper::object_read+0x1b6be>
 2a1116a:	test   %r10d,%r10d
 2a1116d:	je     2a19820 <wasm[0]::function[1015]::helper::object_read+0x1b6c0>
 2a11173:	mov    0x2e0(%rsp),%r14
 2a1117b:	mov    0x28(%r14),%rax
 2a1117f:	mov    0x20(%r14),%r12
 2a11183:	mov    %r10d,%ebx
 2a11186:	lea    0x10(%r12,%rbx,1),%r14
 2a1118b:	xor    %r13,%r13
 2a1118e:	cmp    %rax,%rbx
 2a11191:	cmova  %r13,%r14
 2a11195:	mov    (%r14),%r14d
 2a11198:	cmp    %r14d,%ecx
 2a1119b:	jae    2a19822 <wasm[0]::function[1015]::helper::object_read+0x1b6c2>
 2a111a1:	mov    %r14d,%ebx
 2a111a4:	shl    $0x2,%rbx
 2a111a8:	shr    $0x20,%rbx
 2a111ac:	test   %rbx,%rbx
 2a111af:	jne    2a19824 <wasm[0]::function[1015]::helper::object_read+0x1b6c4>
 2a111b5:	shl    $0x2,%r14d
 2a111b9:	add    $0x14,%r14d
 2a111bd:	jb     2a19826 <wasm[0]::function[1015]::helper::object_read+0x1b6c6>
 2a111c3:	add    %r14d,%r10d
 2a111c6:	jb     2a19828 <wasm[0]::function[1015]::helper::object_read+0x1b6c8>
 2a111cc:	mov    %r10d,%ebx
 2a111cf:	lea    (%r12,%rbx,1),%r10
 2a111d3:	cmp    %rax,%rbx
 2a111d6:	cmova  %r13,%r10
 2a111da:	shl    $0x2,%ecx
 2a111dd:	lea    0x14(%rcx),%eax
 2a111e0:	sub    %eax,%r14d
 2a111e3:	sub    %r14,%r10
 2a111e6:	mov    (%r10),%r13d
 2a111e9:	movzbl %r15b,%ebx
 2a111ed:	mov    %r11,0x210(%rsp)
 2a111f5:	mov    %rbx,0x218(%rsp)
 2a111fd:	jmp    2a1137d <wasm[0]::function[1015]::helper::object_read+0x1321d>
 2a11202:	xor    %eax,%eax
 2a11204:	test   $0x1,%r10d
 2a1120b:	jne    2a11251 <wasm[0]::function[1015]::helper::object_read+0x130f1>
 2a11211:	mov    0x2e0(%rsp),%r14
 2a11219:	mov    0x28(%r14),%r11
 2a1121d:	mov    0x20(%r14),%rax
 2a11221:	mov    %r10d,%ebx
 2a11224:	lea    0x4(%rax,%rbx,1),%rax
 2a11229:	xor    %r12,%r12
 2a1122c:	cmp    %r11,%rbx
 2a1122f:	cmova  %r12,%rax
 2a11233:	mov    (%rax),%r11d
 2a11236:	mov    0x190(%rsp),%rax
 2a1123e:	mov    0x28(%rax),%rax
 2a11242:	cmp    0x160(%rax),%r11d
 2a11249:	sete   %r11b
 2a1124d:	movzbl %r11b,%eax
 2a11251:	test   %eax,%eax
 2a11253:	je     2a1982a <wasm[0]::function[1015]::helper::object_read+0x1b6ca>
 2a11259:	test   %r10d,%r10d
 2a1125c:	je     2a1982c <wasm[0]::function[1015]::helper::object_read+0x1b6cc>
 2a11262:	mov    0x2e0(%rsp),%r14
 2a1126a:	mov    0x28(%r14),%r11
 2a1126e:	mov    0x20(%r14),%rax
 2a11272:	mov    %r10d,%r10d
 2a11275:	lea    (%rax,%r10,1),%r13
 2a11279:	xor    %r12,%r12
 2a1127c:	cmp    %r11,%r10
 2a1127f:	cmova  %r12,%r13
 2a11283:	mov    0x10(%r13),%r13d
 2a11287:	test   %r13d,%r13d
 2a1128a:	je     2a1982e <wasm[0]::function[1015]::helper::object_read+0x1b6ce>
 2a11290:	test   %r13d,%r13d
 2a11293:	je     2a19830 <wasm[0]::function[1015]::helper::object_read+0x1b6d0>
 2a11299:	mov    %r13d,%r14d
 2a1129c:	lea    (%rax,%r14,1),%r13
 2a112a0:	cmp    %r11,%r14
 2a112a3:	cmova  %r12,%r13
 2a112a7:	mov    0x10(%r13),%r14d
 2a112ab:	test   %r14d,%r14d
 2a112ae:	je     2a19832 <wasm[0]::function[1015]::helper::object_read+0x1b6d2>
 2a112b4:	test   %r14d,%r14d
 2a112b7:	je     2a19834 <wasm[0]::function[1015]::helper::object_read+0x1b6d4>
 2a112bd:	mov    %r14d,%ebx
 2a112c0:	lea    0x10(%rax,%rbx,1),%rax
 2a112c5:	cmp    %r11,%rbx
 2a112c8:	cmova  %r12,%rax
 2a112cc:	cmp    (%rax),%ecx
 2a112ce:	setae  %al
 2a112d1:	cmp    $0x2,%ecx
 2a112d4:	setae  %r11b
 2a112d8:	or     %r11d,%eax
 2a112db:	test   %al,%al
 2a112dd:	jne    2a19836 <wasm[0]::function[1015]::helper::object_read+0x1b6d6>
 2a112e3:	mov    0x2e0(%rsp),%r14
 2a112eb:	mov    0x28(%r14),%r11
 2a112ef:	mov    %r10,%rax
 2a112f2:	add    0x20(%r14),%rax
 2a112f6:	xor    %rbx,%rbx
 2a112f9:	cmp    %r11,%r10
 2a112fc:	cmova  %rbx,%rax
 2a11300:	mov    0x14(%rax),%ebx
 2a11303:	test   %ecx,%ecx
 2a11305:	je     2a1133d <wasm[0]::function[1015]::helper::object_read+0x131dd>
 2a1130b:	mov    0x2e0(%rsp),%r14
 2a11313:	mov    0x28(%r14),%r11
 2a11317:	mov    0x20(%r14),%rax
 2a1131b:	add    %r10,%rax
 2a1131e:	xor    %r12,%r12
 2a11321:	cmp    %r11,%r10
 2a11324:	cmova  %r12,%rax
 2a11328:	mov    0x20(%rax),%r11
 2a1132c:	mov    0x2c(%rax),%r13d
 2a11330:	mov    %r11,0x210(%rsp)
 2a11338:	jmp    2a1136a <wasm[0]::function[1015]::helper::object_read+0x1320a>
 2a1133d:	mov    0x2e0(%rsp),%r14
 2a11345:	mov    0x28(%r14),%r11
 2a11349:	mov    0x20(%r14),%rax
 2a1134d:	add    %r10,%rax
 2a11350:	xor    %r12,%r12
 2a11353:	cmp    %r11,%r10
 2a11356:	cmova  %r12,%rax
 2a1135a:	mov    0x18(%rax),%r11
 2a1135e:	mov    %r11,0x210(%rsp)
 2a11366:	mov    0x28(%rax),%r13d
 2a1136a:	shl    $0x3,%ecx
 2a1136d:	shr    %cl,%ebx
 2a1136f:	and    $0xff,%ebx
 2a11375:	mov    %rbx,0x218(%rsp)
 2a1137d:	mov    0x198(%rsp),%rax
 2a11385:	mov    %eax,0xc0(%rsp)
 2a1138c:	mov    %r8d,0x90(%rsp)
 2a11394:	mov    %esi,0xd8(%rsp)
 2a1139b:	mov    %r9d,0xb0(%rsp)
 2a113a3:	mov    %r13d,0xa8(%rsp)
 2a113ab:	mov    %edx,0xc8(%rsp)
 2a113b2:	mov    %edi,0xb8(%rsp)
 2a113b9:	mov    $0x286,%edx
 2a113be:	mov    0x190(%rsp),%rsi
 2a113c6:	mov    0x190(%rsp),%rdi
 2a113ce:	call   2f4f240 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 2a113d3:	mov    %eax,0x78(%rsp)
 2a113d7:	xor    %ebx,%ebx
 2a113d9:	test   %eax,%eax
 2a113db:	je     2a19838 <wasm[0]::function[1015]::helper::object_read+0x1b6d8>
 2a113e1:	movl   $0x0,0xd0(%rsp)
 2a113ec:	mov    0xc0(%rsp),%r10d
 2a113f4:	mov    %r10,0x1a0(%rsp)
 2a113fc:	mov    0x90(%rsp),%edx
 2a11403:	mov    %rdx,0x1c8(%rsp)
 2a1140b:	mov    0xd8(%rsp),%edx
 2a11412:	mov    0xb0(%rsp),%esi
 2a11419:	mov    0xa8(%rsp),%edi
 2a11420:	mov    0xc8(%rsp),%r8d
 2a11428:	mov    0xb8(%rsp),%r9d
 2a11430:	xor    %r12,%r12
 2a11433:	mov    0x248(%rsp),%rax
 2a1143b:	mov    0x248(%rsp),%rcx
 2a11443:	test   %al,%cl
 2a11445:	jne    2a1146b <wasm[0]::function[1015]::helper::object_read+0x1330b>
 2a1144b:	mov    0x1a0(%rsp),%r10
 2a11453:	mov    %rbx,%r13
 2a11456:	mov    %rbx,0x1e0(%rsp)
 2a1145e:	mov    %r12,0x1e8(%rsp)
 2a11466:	jmp    2a12097 <wasm[0]::function[1015]::helper::object_read+0x13f37>
 2a1146b:	mov    0xc0(%rsp),%r8d
 2a11473:	mov    0x258(%rsp),%rcx
 2a1147b:	mov    0x250(%rsp),%rdx
 2a11483:	mov    0x190(%rsp),%rsi
 2a1148b:	mov    0x190(%rsp),%rdi
 2a11493:	call   2a7c940 <wasm[0]::function[1039]::helper::object_header_projection>
 2a11498:	mov    %eax,0x88(%rsp)
 2a1149f:	test   %eax,%eax
 2a114a1:	je     2a1983a <wasm[0]::function[1015]::helper::object_read+0x1b6da>
 2a114a7:	test   %eax,%eax
 2a114a9:	je     2a1983c <wasm[0]::function[1015]::helper::object_read+0x1b6dc>
 2a114af:	mov    0x2e0(%rsp),%r14
 2a114b7:	mov    0x28(%r14),%rcx
 2a114bb:	mov    0x20(%r14),%rsi
 2a114bf:	mov    %eax,%edx
 2a114c1:	lea    (%rsi,%rdx,1),%rax
 2a114c5:	xor    %rsi,%rsi
 2a114c8:	cmp    %rcx,%rdx
 2a114cb:	cmova  %rsi,%rax
 2a114cf:	mov    0x14(%rax),%eax
 2a114d2:	mov    %eax,0xe8(%rsp)
 2a114d9:	test   %eax,%eax
 2a114db:	je     2a1983e <wasm[0]::function[1015]::helper::object_read+0x1b6de>
 2a114e1:	mov    0xe8(%rsp),%ecx
 2a114e8:	xor    %eax,%eax
 2a114ea:	test   $0x1,%ecx
 2a114f0:	jne    2a11548 <wasm[0]::function[1015]::helper::object_read+0x133e8>
 2a114f6:	mov    0x2e0(%rsp),%r14
 2a114fe:	mov    0x28(%r14),%rax
 2a11502:	mov    0x20(%r14),%rsi
 2a11506:	mov    %ecx,%edx
 2a11508:	lea    0x4(%rsi,%rdx,1),%rcx
 2a1150d:	xor    %rsi,%rsi
 2a11510:	cmp    %rax,%rdx
 2a11513:	cmova  %rsi,%rcx
 2a11517:	mov    (%rcx),%esi
 2a11519:	mov    0x190(%rsp),%rdi
 2a11521:	mov    0x28(%rdi),%rax
 2a11525:	mov    0x158(%rax),%edx
 2a1152b:	cmp    %edx,%esi
 2a1152d:	sete   %cl
 2a11530:	movzbl %cl,%eax
 2a11533:	cmp    %edx,%esi
 2a11535:	je     2a11548 <wasm[0]::function[1015]::helper::object_read+0x133e8>
 2a1153b:	mov    0x190(%rsp),%rdi
 2a11543:	call   3039cc5 <wasmtime_builtin_is_subtype>
 2a11548:	test   %eax,%eax
 2a1154a:	jne    2a117a4 <wasm[0]::function[1015]::helper::object_read+0x13644>
 2a11550:	mov    0x88(%rsp),%edx
 2a11557:	xor    %r14d,%r14d
 2a1155a:	test   %edx,%edx
 2a1155c:	je     2a19840 <wasm[0]::function[1015]::helper::object_read+0x1b6e0>
 2a11562:	mov    0x78(%rsp),%r9d
 2a11567:	mov    $0x4,%ecx
 2a1156c:	xor    %r8,%r8
 2a1156f:	mov    0x190(%rsp),%rsi
 2a11577:	mov    0x190(%rsp),%rdi
 2a1157f:	call   2a76140 <wasm[0]::function[1032]::helper::ordinary_property_find>
 2a11584:	test   %eax,%eax
 2a11586:	je     2a115bf <wasm[0]::function[1015]::helper::object_read+0x1345f>
 2a1158c:	test   %eax,%eax
 2a1158e:	je     2a19842 <wasm[0]::function[1015]::helper::object_read+0x1b6e2>
 2a11594:	test   %eax,%eax
 2a11596:	je     2a19844 <wasm[0]::function[1015]::helper::object_read+0x1b6e4>
 2a1159c:	mov    0x2e0(%rsp),%r14
 2a115a4:	mov    0x28(%r14),%rcx
 2a115a8:	mov    %eax,%edx
 2a115aa:	mov    %rdx,%rax
 2a115ad:	add    0x20(%r14),%rax
 2a115b1:	xor    %rsi,%rsi
 2a115b4:	cmp    %rcx,%rdx
 2a115b7:	cmova  %rsi,%rax
 2a115bb:	mov    0x14(%rax),%r14d
 2a115bf:	mov    0xd0(%rsp),%r13d
 2a115c7:	xor    %ebx,%ebx
 2a115c9:	xor    %r12,%r12
 2a115cc:	test   %r14d,%r14d
 2a115cf:	je     2a1174b <wasm[0]::function[1015]::helper::object_read+0x135eb>
 2a115d5:	test   %r14d,%r14d
 2a115d8:	je     2a19846 <wasm[0]::function[1015]::helper::object_read+0x1b6e6>
 2a115de:	mov    0x2e0(%rsp),%rax
 2a115e6:	mov    0x28(%rax),%rcx
 2a115ea:	mov    0x20(%rax),%rax
 2a115ee:	mov    %r14d,%edx
 2a115f1:	add    %rdx,%rax
 2a115f4:	xor    %r12,%r12
 2a115f7:	cmp    %rcx,%rdx
 2a115fa:	cmova  %r12,%rax
 2a115fe:	mov    0x10(%rax),%ecx
 2a11601:	mov    0xd0(%rsp),%r13d
 2a11609:	xor    %ebx,%ebx
 2a1160b:	test   $0x1,%ecx
 2a11611:	jne    2a1174b <wasm[0]::function[1015]::helper::object_read+0x135eb>
 2a11617:	mov    0x14(%rax),%edx
 2a1161a:	test   %edx,%edx
 2a1161c:	je     2a19848 <wasm[0]::function[1015]::helper::object_read+0x1b6e8>
 2a11622:	xor    %eax,%eax
 2a11624:	test   $0x1,%edx
 2a1162a:	jne    2a1166b <wasm[0]::function[1015]::helper::object_read+0x1350b>
 2a11630:	mov    0x2e0(%rsp),%r14
 2a11638:	mov    0x28(%r14),%rax
 2a1163c:	mov    0x20(%r14),%rcx
 2a11640:	mov    %edx,%esi
 2a11642:	lea    0x4(%rcx,%rsi,1),%rcx
 2a11647:	xor    %rdi,%rdi
 2a1164a:	cmp    %rax,%rsi
 2a1164d:	cmova  %rdi,%rcx
 2a11651:	mov    (%rcx),%eax
 2a11653:	mov    0x190(%rsp),%rsi
 2a1165b:	mov    0x28(%rsi),%rcx
 2a1165f:	cmp    0x120(%rcx),%eax
 2a11665:	sete   %al
 2a11668:	movzbl %al,%eax
 2a1166b:	test   %eax,%eax
 2a1166d:	jne    2a116c8 <wasm[0]::function[1015]::helper::object_read+0x13568>
 2a11673:	mov    0x190(%rsp),%rsi
 2a1167b:	mov    0x190(%rsp),%rdi
 2a11683:	call   2a1eec0 <wasm[0]::function[1024]::helper::property_value_resolve>
 2a11688:	test   %eax,%eax
 2a1168a:	je     2a1984a <wasm[0]::function[1015]::helper::object_read+0x1b6ea>
 2a11690:	test   %eax,%eax
 2a11692:	je     2a1984c <wasm[0]::function[1015]::helper::object_read+0x1b6ec>
 2a11698:	mov    0x2e0(%rsp),%r14
 2a116a0:	mov    0x28(%r14),%rcx
 2a116a4:	mov    0x20(%r14),%rsi
 2a116a8:	mov    %eax,%edx
 2a116aa:	lea    (%rsi,%rdx,1),%rax
 2a116ae:	xor    %rsi,%rsi
 2a116b1:	cmp    %rcx,%rdx
 2a116b4:	cmova  %rsi,%rax
 2a116b8:	mov    0x18(%rax),%ebx
 2a116bb:	mov    0x10(%rax),%r12
 2a116bf:	mov    0x1c(%rax),%r13d
 2a116c3:	jmp    2a1174b <wasm[0]::function[1015]::helper::object_read+0x135eb>
 2a116c8:	xor    %eax,%eax
 2a116ca:	test   $0x1,%edx
 2a116d0:	jne    2a11711 <wasm[0]::function[1015]::helper::object_read+0x135b1>
 2a116d6:	mov    0x2e0(%rsp),%r14
 2a116de:	mov    0x28(%r14),%rax
 2a116e2:	mov    0x20(%r14),%rcx
 2a116e6:	mov    %edx,%esi
 2a116e8:	lea    0x4(%rcx,%rsi,1),%rcx
 2a116ed:	xor    %rdi,%rdi
 2a116f0:	cmp    %rax,%rsi
 2a116f3:	cmova  %rdi,%rcx
 2a116f7:	mov    (%rcx),%eax
 2a116f9:	mov    0x190(%rsp),%rsi
 2a11701:	mov    0x28(%rsi),%rcx
 2a11705:	cmp    0x120(%rcx),%eax
 2a1170b:	sete   %al
 2a1170e:	movzbl %al,%eax
 2a11711:	test   %eax,%eax
 2a11713:	je     2a1984e <wasm[0]::function[1015]::helper::object_read+0x1b6ee>
 2a11719:	test   %edx,%edx
 2a1171b:	je     2a19850 <wasm[0]::function[1015]::helper::object_read+0x1b6f0>
 2a11721:	mov    0x2e0(%rsp),%r14
 2a11729:	mov    0x28(%r14),%rcx
 2a1172d:	mov    0x20(%r14),%rax
 2a11731:	mov    %edx,%edx
 2a11733:	add    %rdx,%rax
 2a11736:	xor    %rsi,%rsi
 2a11739:	cmp    %rcx,%rdx
 2a1173c:	cmova  %rsi,%rax
 2a11740:	mov    0x18(%rax),%ebx
 2a11743:	mov    0x10(%rax),%r12
 2a11747:	mov    0x1c(%rax),%r13d
 2a1174b:	mov    0xc0(%rsp),%r10d
 2a11753:	mov    %r10,0x1a0(%rsp)
 2a1175b:	mov    0x90(%rsp),%edx
 2a11762:	mov    %rdx,0x1c8(%rsp)
 2a1176a:	mov    0xd8(%rsp),%edx
 2a11771:	mov    0xb0(%rsp),%esi
 2a11778:	mov    0xa8(%rsp),%edi
 2a1177f:	mov    0xc8(%rsp),%r8d
 2a11787:	mov    0xb8(%rsp),%r9d
 2a1178f:	mov    %rbx,0x1e0(%rsp)
 2a11797:	mov    %r12,0x1e8(%rsp)
 2a1179f:	jmp    2a1208f <wasm[0]::function[1015]::helper::object_read+0x13f2f>
 2a117a4:	mov    0xe8(%rsp),%eax
 2a117ab:	test   %eax,%eax
 2a117ad:	je     2a19852 <wasm[0]::function[1015]::helper::object_read+0x1b6f2>
 2a117b3:	mov    0xe8(%rsp),%ecx
 2a117ba:	xor    %eax,%eax
 2a117bc:	test   $0x1,%ecx
 2a117c2:	jne    2a1181c <wasm[0]::function[1015]::helper::object_read+0x136bc>
 2a117c8:	mov    0x2e0(%rsp),%r14
 2a117d0:	mov    0x28(%r14),%rsi
 2a117d4:	mov    0x20(%r14),%r8
 2a117d8:	mov    %ecx,%edi
 2a117da:	lea    0x4(%r8,%rdi,1),%rcx
 2a117df:	xor    %r8,%r8
 2a117e2:	cmp    %rsi,%rdi
 2a117e5:	cmova  %r8,%rcx
 2a117e9:	mov    (%rcx),%esi
 2a117eb:	mov    0x190(%rsp),%rax
 2a117f3:	mov    0x28(%rax),%rdi
 2a117f7:	mov    0x158(%rdi),%edx
 2a117fd:	cmp    %edx,%esi
 2a117ff:	sete   %dil
 2a11803:	movzbl %dil,%eax
 2a11807:	cmp    %edx,%esi
 2a11809:	je     2a1181c <wasm[0]::function[1015]::helper::object_read+0x136bc>
 2a1180f:	mov    0x190(%rsp),%rdi
 2a11817:	call   3039cc5 <wasmtime_builtin_is_subtype>
 2a1181c:	test   %eax,%eax
 2a1181e:	je     2a19854 <wasm[0]::function[1015]::helper::object_read+0x1b6f4>
 2a11824:	mov    0xe8(%rsp),%r11d
 2a1182c:	mov    0xc0(%rsp),%r10d
 2a11834:	mov    %r10,0x1a0(%rsp)
 2a1183c:	mov    0x90(%rsp),%edx
 2a11843:	mov    %rdx,0x1c8(%rsp)
 2a1184b:	mov    0xd0(%rsp),%r13d
 2a11853:	mov    0xd8(%rsp),%edx
 2a1185a:	mov    0xb0(%rsp),%esi
 2a11861:	mov    0xa8(%rsp),%edi
 2a11868:	mov    0xc8(%rsp),%r8d
 2a11870:	mov    0xb8(%rsp),%r9d
 2a11878:	xor    %ecx,%ecx
 2a1187a:	mov    %rcx,0x238(%rsp)
 2a11882:	test   %r11d,%r11d
 2a11885:	je     2a19856 <wasm[0]::function[1015]::helper::object_read+0x1b6f6>
 2a1188b:	test   %r11d,%r11d
 2a1188e:	je     2a19858 <wasm[0]::function[1015]::helper::object_read+0x1b6f8>
 2a11894:	mov    0x2e0(%rsp),%r14
 2a1189c:	mov    0x28(%r14),%rax
 2a118a0:	mov    0x20(%r14),%rcx
 2a118a4:	mov    %r11d,%r12d
 2a118a7:	lea    (%rcx,%r12,1),%r15
 2a118ab:	xor    %rbx,%rbx
 2a118ae:	cmp    %rax,%r12
 2a118b1:	cmova  %rbx,%r15
 2a118b5:	mov    0x10(%r15),%r12d
 2a118b9:	test   %r12d,%r12d
 2a118bc:	je     2a1985a <wasm[0]::function[1015]::helper::object_read+0x1b6fa>
 2a118c2:	test   %r12d,%r12d
 2a118c5:	je     2a1985c <wasm[0]::function[1015]::helper::object_read+0x1b6fc>
 2a118cb:	mov    %r12d,%r14d
 2a118ce:	lea    (%rcx,%r14,1),%r12
 2a118d2:	cmp    %rax,%r14
 2a118d5:	cmova  %rbx,%r12
 2a118d9:	mov    0x10(%r12),%r14d
 2a118de:	test   %r14d,%r14d
 2a118e1:	je     2a1985e <wasm[0]::function[1015]::helper::object_read+0x1b6fe>
 2a118e7:	test   %r14d,%r14d
 2a118ea:	je     2a19860 <wasm[0]::function[1015]::helper::object_read+0x1b700>
 2a118f0:	mov    %r14d,%r12d
 2a118f3:	lea    0x10(%rcx,%r12,1),%rcx
 2a118f8:	cmp    %rax,%r12
 2a118fb:	cmova  %rbx,%rcx
 2a118ff:	mov    (%rcx),%r15d
 2a11902:	mov    %r15,0x240(%rsp)
 2a1190a:	mov    0x78(%rsp),%ebx
 2a1190e:	mov    0x190(%rsp),%rax
 2a11916:	mov    0x28(%rax),%rax
 2a1191a:	mov    0x234(%rax),%r12d
 2a11921:	mov    0x238(%rsp),%rax
 2a11929:	mov    %rax,0x198(%rsp)
 2a11931:	mov    %r14d,0x88(%rsp)
 2a11939:	mov    %ebx,0xb8(%rsp)
 2a11940:	mov    %r11d,0xc8(%rsp)
 2a11948:	mov    0x1a0(%rsp),%r10
 2a11950:	mov    %r10d,0xa8(%rsp)
 2a11958:	mov    0x1c8(%rsp),%rax
 2a11960:	mov    %eax,0xb0(%rsp)
 2a11967:	mov    %r13d,0xd8(%rsp)
 2a1196f:	mov    %edx,0xd0(%rsp)
 2a11976:	mov    %esi,0x90(%rsp)
 2a1197d:	mov    %edi,0xc0(%rsp)
 2a11984:	mov    %r8d,0xe8(%rsp)
 2a1198c:	mov    %r9d,0x78(%rsp)
 2a11991:	mov    0x2e8(%rsp),%r15
 2a11999:	mov    (%r15),%rcx
 2a1199c:	mov    0x228(%rsp),%rax
 2a119a4:	cmp    %rax,%rcx
 2a119a7:	jae    2a1878a <wasm[0]::function[1015]::helper::object_read+0x1a62a>
 2a119ad:	mov    0xc8(%rsp),%r11d
 2a119b5:	mov    0xa8(%rsp),%r10d
 2a119bd:	mov    %r10,0x1a0(%rsp)
 2a119c5:	mov    0xb0(%rsp),%edx
 2a119cc:	mov    %rdx,0x1c8(%rsp)
 2a119d4:	mov    0xd8(%rsp),%r13d
 2a119dc:	mov    0xd0(%rsp),%edx
 2a119e3:	mov    0x90(%rsp),%esi
 2a119ea:	mov    0xc0(%rsp),%edi
 2a119f1:	mov    0xe8(%rsp),%r8d
 2a119f9:	mov    0x78(%rsp),%r9d
 2a119fe:	mov    0x238(%rsp),%rcx
 2a11a06:	mov    0x240(%rsp),%r15
 2a11a0e:	cmp    %r15d,%ecx
 2a11a11:	jb     2a11a24 <wasm[0]::function[1015]::helper::object_read+0x138c4>
 2a11a17:	mov    0x198(%rsp),%rax
 2a11a1f:	jmp    2a11c3e <wasm[0]::function[1015]::helper::object_read+0x13ade>
 2a11a24:	mov    0x88(%rsp),%eax
 2a11a2b:	test   %eax,%eax
 2a11a2d:	je     2a19862 <wasm[0]::function[1015]::helper::object_read+0x1b702>
 2a11a33:	test   %eax,%eax
 2a11a35:	je     2a19864 <wasm[0]::function[1015]::helper::object_read+0x1b704>
 2a11a3b:	mov    0x2e0(%rsp),%r14
 2a11a43:	mov    0x28(%r14),%rdx
 2a11a47:	mov    0x20(%r14),%rsi
 2a11a4b:	mov    %eax,%r9d
 2a11a4e:	lea    0x10(%rsi,%r9,1),%r8
 2a11a53:	xor    %rdi,%rdi
 2a11a56:	cmp    %rdx,%r9
 2a11a59:	cmova  %rdi,%r8
 2a11a5d:	mov    (%r8),%r8d
 2a11a60:	cmp    %r8d,%ecx
 2a11a63:	jae    2a19866 <wasm[0]::function[1015]::helper::object_read+0x1b706>
 2a11a69:	mov    %r8d,%r9d
 2a11a6c:	shl    $0x2,%r9
 2a11a70:	shr    $0x20,%r9
 2a11a74:	test   %r9,%r9
 2a11a77:	jne    2a19868 <wasm[0]::function[1015]::helper::object_read+0x1b708>
 2a11a7d:	shl    $0x2,%r8d
 2a11a81:	add    $0x14,%r8d
 2a11a85:	jb     2a1986a <wasm[0]::function[1015]::helper::object_read+0x1b70a>
 2a11a8b:	add    %r8d,%eax
 2a11a8e:	jb     2a1986c <wasm[0]::function[1015]::helper::object_read+0x1b70c>
 2a11a94:	mov    %eax,%r9d
 2a11a97:	lea    (%rsi,%r9,1),%rax
 2a11a9b:	cmp    %rdx,%r9
 2a11a9e:	cmova  %rdi,%rax
 2a11aa2:	mov    %rcx,%rdx
 2a11aa5:	shl    $0x2,%edx
 2a11aa8:	mov    %rcx,0x238(%rsp)
 2a11ab0:	lea    0x14(%rdx),%ecx
 2a11ab3:	sub    %ecx,%r8d
 2a11ab6:	sub    %r8,%rax
 2a11ab9:	mov    (%rax),%edx
 2a11abb:	test   %edx,%edx
 2a11abd:	je     2a1986e <wasm[0]::function[1015]::helper::object_read+0x1b70e>
 2a11ac3:	mov    0xb8(%rsp),%esi
 2a11aca:	cmp    %esi,%edx
 2a11acc:	je     2a11b9e <wasm[0]::function[1015]::helper::object_read+0x13a3e>
 2a11ad2:	xor    %eax,%eax
 2a11ad4:	test   %edx,%edx
 2a11ad6:	je     2a11b17 <wasm[0]::function[1015]::helper::object_read+0x139b7>
 2a11adc:	xor    %eax,%eax
 2a11ade:	test   $0x1,%edx
 2a11ae4:	jne    2a11b17 <wasm[0]::function[1015]::helper::object_read+0x139b7>
 2a11aea:	mov    0x2e0(%rsp),%r14
 2a11af2:	mov    0x28(%r14),%rax
 2a11af6:	mov    0x20(%r14),%rdi
 2a11afa:	mov    %edx,%ecx
 2a11afc:	lea    0x4(%rdi,%rcx,1),%r10
 2a11b01:	xor    %rdi,%rdi
 2a11b04:	cmp    %rax,%rcx
 2a11b07:	cmova  %rdi,%r10
 2a11b0b:	mov    (%r10),%eax
 2a11b0e:	cmp    %r12d,%eax
 2a11b11:	sete   %al
 2a11b14:	movzbl %al,%eax
 2a11b17:	test   %eax,%eax
 2a11b19:	je     2a19870 <wasm[0]::function[1015]::helper::object_read+0x1b710>
 2a11b1f:	xor    %eax,%eax
 2a11b21:	test   %esi,%esi
 2a11b23:	je     2a11b6a <wasm[0]::function[1015]::helper::object_read+0x13a0a>
 2a11b29:	mov    0xb8(%rsp),%ecx
 2a11b30:	xor    %eax,%eax
 2a11b32:	test   $0x1,%ecx
 2a11b38:	jne    2a11b6a <wasm[0]::function[1015]::helper::object_read+0x13a0a>
 2a11b3e:	mov    0x2e0(%rsp),%r14
 2a11b46:	mov    0x28(%r14),%rax
 2a11b4a:	mov    0x20(%r14),%rdi
 2a11b4e:	mov    %ecx,%esi
 2a11b50:	lea    0x4(%rdi,%rsi,1),%rcx
 2a11b55:	xor    %rdi,%rdi
 2a11b58:	cmp    %rax,%rsi
 2a11b5b:	cmova  %rdi,%rcx
 2a11b5f:	mov    (%rcx),%eax
 2a11b61:	cmp    %r12d,%eax
 2a11b64:	sete   %al
 2a11b67:	movzbl %al,%eax
 2a11b6a:	test   %eax,%eax
 2a11b6c:	je     2a19872 <wasm[0]::function[1015]::helper::object_read+0x1b712>
 2a11b72:	mov    0xb8(%rsp),%ecx
 2a11b79:	xor    %r8d,%r8d
 2a11b7c:	test   %ecx,%ecx
 2a11b7e:	je     2a19874 <wasm[0]::function[1015]::helper::object_read+0x1b714>
 2a11b84:	mov    0x190(%rsp),%rsi
 2a11b8c:	mov    0x190(%rsp),%rdi
 2a11b94:	call   2b02800 <wasm[0]::function[1057]::helper::string_equality>
 2a11b99:	jmp    2a11ba6 <wasm[0]::function[1015]::helper::object_read+0x13a46>
 2a11b9e:	mov    0x278(%rsp),%rax
 2a11ba6:	mov    0x88(%rsp),%r14d
 2a11bae:	mov    0xb8(%rsp),%ebx
 2a11bb5:	mov    0xc8(%rsp),%r11d
 2a11bbd:	mov    0xa8(%rsp),%r10d
 2a11bc5:	mov    %r10,0x1a0(%rsp)
 2a11bcd:	mov    0xb0(%rsp),%edx
 2a11bd4:	mov    %rdx,0x1c8(%rsp)
 2a11bdc:	mov    0xd8(%rsp),%r13d
 2a11be4:	mov    0xd0(%rsp),%edx
 2a11beb:	mov    0x90(%rsp),%esi
 2a11bf2:	mov    0xc0(%rsp),%edi
 2a11bf9:	mov    0xe8(%rsp),%r8d
 2a11c01:	mov    0x78(%rsp),%r9d
 2a11c06:	test   %eax,%eax
 2a11c08:	je     2a11c1b <wasm[0]::function[1015]::helper::object_read+0x13abb>
 2a11c0e:	mov    0x238(%rsp),%rcx
 2a11c16:	jmp    2a11c3e <wasm[0]::function[1015]::helper::object_read+0x13ade>
 2a11c1b:	mov    0x238(%rsp),%rcx
 2a11c23:	add    $0x1,%ecx
 2a11c29:	mov    %rax,0x198(%rsp)
 2a11c31:	mov    %rcx,0x238(%rsp)
 2a11c39:	jmp    2a11931 <wasm[0]::function[1015]::helper::object_read+0x137d1>
 2a11c3e:	xor    %ebx,%ebx
 2a11c40:	xor    %r12,%r12
 2a11c43:	test   %eax,%eax
 2a11c45:	jne    2a11c60 <wasm[0]::function[1015]::helper::object_read+0x13b00>
 2a11c4b:	mov    %rbx,0x1e0(%rsp)
 2a11c53:	mov    %r12,0x1e8(%rsp)
 2a11c5b:	jmp    2a1208f <wasm[0]::function[1015]::helper::object_read+0x13f2f>
 2a11c60:	test   %r11d,%r11d
 2a11c63:	je     2a19876 <wasm[0]::function[1015]::helper::object_read+0x1b716>
 2a11c69:	xor    %eax,%eax
 2a11c6b:	test   $0x1,%r11d
 2a11c72:	jne    2a11cb5 <wasm[0]::function[1015]::helper::object_read+0x13b55>
 2a11c78:	mov    0x2e0(%rsp),%r14
 2a11c80:	mov    0x28(%r14),%rax
 2a11c84:	mov    0x20(%r14),%rbx
 2a11c88:	mov    %r11d,%r12d
 2a11c8b:	lea    0x4(%rbx,%r12,1),%rbx
 2a11c90:	xor    %r13,%r13
 2a11c93:	cmp    %rax,%r12
 2a11c96:	cmova  %r13,%rbx
 2a11c9a:	mov    (%rbx),%eax
 2a11c9c:	mov    0x190(%rsp),%r10
 2a11ca4:	mov    0x28(%r10),%r10
 2a11ca8:	cmp    0x160(%r10),%eax
 2a11caf:	sete   %al
 2a11cb2:	movzbl %al,%eax
 2a11cb5:	test   %eax,%eax
 2a11cb7:	jne    2a11f10 <wasm[0]::function[1015]::helper::object_read+0x13db0>
 2a11cbd:	xor    %eax,%eax
 2a11cbf:	test   $0x1,%r11d
 2a11cc6:	jne    2a11d09 <wasm[0]::function[1015]::helper::object_read+0x13ba9>
 2a11ccc:	mov    0x2e0(%rsp),%r14
 2a11cd4:	mov    0x28(%r14),%rax
 2a11cd8:	mov    0x20(%r14),%rbx
 2a11cdc:	mov    %r11d,%r12d
 2a11cdf:	lea    0x4(%rbx,%r12,1),%rbx
 2a11ce4:	xor    %r13,%r13
 2a11ce7:	cmp    %rax,%r12
 2a11cea:	cmova  %r13,%rbx
 2a11cee:	mov    (%rbx),%eax
 2a11cf0:	mov    0x190(%rsp),%r10
 2a11cf8:	mov    0x28(%r10),%r10
 2a11cfc:	cmp    0x15c(%r10),%eax
 2a11d03:	sete   %al
 2a11d06:	movzbl %al,%eax
 2a11d09:	test   %eax,%eax
 2a11d0b:	je     2a19878 <wasm[0]::function[1015]::helper::object_read+0x1b718>
 2a11d11:	test   %r11d,%r11d
 2a11d14:	je     2a1987a <wasm[0]::function[1015]::helper::object_read+0x1b71a>
 2a11d1a:	mov    0x2e0(%rsp),%r14
 2a11d22:	mov    0x28(%r14),%rbx
 2a11d26:	mov    0x20(%r14),%r13
 2a11d2a:	mov    %r11d,%eax
 2a11d2d:	lea    0x0(%r13,%rax,1),%r11
 2a11d32:	xor    %r12,%r12
 2a11d35:	cmp    %rbx,%rax
 2a11d38:	cmova  %r12,%r11
 2a11d3c:	mov    0x14(%r11),%r14d
 2a11d40:	mov    0x18(%r11),%eax
 2a11d44:	mov    0x1c(%r11),%r11d
 2a11d48:	test   %r14d,%r14d
 2a11d4b:	je     2a1987c <wasm[0]::function[1015]::helper::object_read+0x1b71c>
 2a11d51:	test   %r14d,%r14d
 2a11d54:	je     2a1987e <wasm[0]::function[1015]::helper::object_read+0x1b71e>
 2a11d5a:	mov    %r14d,%r10d
 2a11d5d:	lea    0x10(%r13,%r10,1),%r15
 2a11d62:	cmp    %rbx,%r10
 2a11d65:	cmova  %r12,%r15
 2a11d69:	mov    (%r15),%r15d
 2a11d6c:	cmp    %r15d,%ecx
 2a11d6f:	jae    2a19880 <wasm[0]::function[1015]::helper::object_read+0x1b720>
 2a11d75:	mov    %r15d,%r10d
 2a11d78:	shr    $0x20,%r10
 2a11d7c:	test   %r10,%r10
 2a11d7f:	jne    2a19882 <wasm[0]::function[1015]::helper::object_read+0x1b722>
 2a11d85:	add    $0x14,%r15d
 2a11d89:	jb     2a19884 <wasm[0]::function[1015]::helper::object_read+0x1b724>
 2a11d8f:	add    %r15d,%r14d
 2a11d92:	jb     2a19886 <wasm[0]::function[1015]::helper::object_read+0x1b726>
 2a11d98:	mov    %r14d,%r10d
 2a11d9b:	add    %r10,%r13
 2a11d9e:	cmp    %rbx,%r10
 2a11da1:	cmova  %r12,%r13
 2a11da5:	lea    0x14(%rcx),%r10d
 2a11da9:	sub    %r10d,%r15d
 2a11dac:	sub    %r15,%r13
 2a11daf:	movzbq 0x0(%r13),%r15
 2a11db4:	mov    %r15,0x240(%rsp)
 2a11dbc:	test   %eax,%eax
 2a11dbe:	je     2a11e4e <wasm[0]::function[1015]::helper::object_read+0x13cee>
 2a11dc4:	test   %eax,%eax
 2a11dc6:	je     2a19888 <wasm[0]::function[1015]::helper::object_read+0x1b728>
 2a11dcc:	test   %eax,%eax
 2a11dce:	je     2a1988a <wasm[0]::function[1015]::helper::object_read+0x1b72a>
 2a11dd4:	mov    0x2e0(%rsp),%r14
 2a11ddc:	mov    0x28(%r14),%r12
 2a11de0:	mov    0x20(%r14),%r13
 2a11de4:	mov    %eax,%r15d
 2a11de7:	lea    0x10(%r13,%r15,1),%rbx
 2a11dec:	xor    %r14,%r14
 2a11def:	cmp    %r12,%r15
 2a11df2:	cmova  %r14,%rbx
 2a11df6:	mov    (%rbx),%ebx
 2a11df8:	cmp    %ebx,%ecx
 2a11dfa:	jae    2a1988c <wasm[0]::function[1015]::helper::object_read+0x1b72c>
 2a11e00:	mov    %ebx,%r15d
 2a11e03:	shl    $0x3,%r15
 2a11e07:	shr    $0x20,%r15
 2a11e0b:	test   %r15,%r15
 2a11e0e:	jne    2a1988e <wasm[0]::function[1015]::helper::object_read+0x1b72e>
 2a11e14:	shl    $0x3,%ebx
 2a11e17:	add    $0x18,%ebx
 2a11e1a:	jb     2a19890 <wasm[0]::function[1015]::helper::object_read+0x1b730>
 2a11e20:	add    %ebx,%eax
 2a11e22:	jb     2a19892 <wasm[0]::function[1015]::helper::object_read+0x1b732>
 2a11e28:	mov    %eax,%r10d
 2a11e2b:	lea    0x0(%r13,%r10,1),%rax
 2a11e30:	cmp    %r12,%r10
 2a11e33:	cmova  %r14,%rax
 2a11e37:	mov    %rcx,%r10
 2a11e3a:	shl    $0x3,%r10d
 2a11e3e:	add    $0x18,%r10d
 2a11e45:	sub    %r10d,%ebx
 2a11e48:	sub    %rbx,%rax
 2a11e4b:	mov    (%rax),%r12
 2a11e4e:	xor    %r13d,%r13d
 2a11e51:	test   %r11d,%r11d
 2a11e54:	jne    2a11e67 <wasm[0]::function[1015]::helper::object_read+0x13d07>
 2a11e5a:	mov    0x240(%rsp),%r15
 2a11e62:	jmp    2a11ef7 <wasm[0]::function[1015]::helper::object_read+0x13d97>
 2a11e67:	test   %r11d,%r11d
 2a11e6a:	je     2a19894 <wasm[0]::function[1015]::helper::object_read+0x1b734>
 2a11e70:	test   %r11d,%r11d
 2a11e73:	je     2a19896 <wasm[0]::function[1015]::helper::object_read+0x1b736>
 2a11e79:	mov    0x2e0(%rsp),%r14
 2a11e81:	mov    0x28(%r14),%rax
 2a11e85:	mov    0x20(%r14),%rbx
 2a11e89:	mov    %r11d,%r15d
 2a11e8c:	lea    0x10(%rbx,%r15,1),%r14
 2a11e91:	xor    %r13,%r13
 2a11e94:	cmp    %rax,%r15
 2a11e97:	cmova  %r13,%r14
 2a11e9b:	mov    (%r14),%r14d
 2a11e9e:	cmp    %r14d,%ecx
 2a11ea1:	jae    2a19898 <wasm[0]::function[1015]::helper::object_read+0x1b738>
 2a11ea7:	mov    %r14d,%r15d
 2a11eaa:	shl    $0x2,%r15
 2a11eae:	shr    $0x20,%r15
 2a11eb2:	test   %r15,%r15
 2a11eb5:	jne    2a1989a <wasm[0]::function[1015]::helper::object_read+0x1b73a>
 2a11ebb:	shl    $0x2,%r14d
 2a11ebf:	add    $0x14,%r14d
 2a11ec3:	jb     2a1989c <wasm[0]::function[1015]::helper::object_read+0x1b73c>
 2a11ec9:	add    %r14d,%r11d
 2a11ecc:	jb     2a1989e <wasm[0]::function[1015]::helper::object_read+0x1b73e>
 2a11ed2:	mov    %r11d,%r10d
 2a11ed5:	lea    (%rbx,%r10,1),%r11
 2a11ed9:	cmp    %rax,%r10
 2a11edc:	cmova  %r13,%r11
 2a11ee0:	shl    $0x2,%ecx
 2a11ee3:	lea    0x14(%rcx),%eax
 2a11ee6:	sub    %eax,%r14d
 2a11ee9:	sub    %r14,%r11
 2a11eec:	mov    (%r11),%r13d
 2a11eef:	mov    0x240(%rsp),%r15
 2a11ef7:	movzbl %r15b,%ebx
 2a11efb:	mov    %rbx,0x1e0(%rsp)
 2a11f03:	mov    %r12,0x1e8(%rsp)
 2a11f0b:	jmp    2a1208f <wasm[0]::function[1015]::helper::object_read+0x13f2f>
 2a11f10:	xor    %eax,%eax
 2a11f12:	test   $0x1,%r11d
 2a11f19:	jne    2a11f5c <wasm[0]::function[1015]::helper::object_read+0x13dfc>
 2a11f1f:	mov    0x2e0(%rsp),%r14
 2a11f27:	mov    0x28(%r14),%rax
 2a11f2b:	mov    0x20(%r14),%r10
 2a11f2f:	mov    %r11d,%r12d
 2a11f32:	lea    0x4(%r10,%r12,1),%rbx
 2a11f37:	xor    %r13,%r13
 2a11f3a:	cmp    %rax,%r12
 2a11f3d:	cmova  %r13,%rbx
 2a11f41:	mov    (%rbx),%eax
 2a11f43:	mov    0x190(%rsp),%r10
 2a11f4b:	mov    0x28(%r10),%r10
 2a11f4f:	cmp    0x160(%r10),%eax
 2a11f56:	sete   %al
 2a11f59:	movzbl %al,%eax
 2a11f5c:	test   %eax,%eax
 2a11f5e:	je     2a198a0 <wasm[0]::function[1015]::helper::object_read+0x1b740>
 2a11f64:	test   %r11d,%r11d
 2a11f67:	je     2a198a2 <wasm[0]::function[1015]::helper::object_read+0x1b742>
 2a11f6d:	mov    0x2e0(%rsp),%r14
 2a11f75:	mov    0x28(%r14),%rbx
 2a11f79:	mov    0x20(%r14),%r12
 2a11f7d:	mov    %r11d,%eax
 2a11f80:	lea    (%r12,%rax,1),%r13
 2a11f84:	xor    %r11,%r11
 2a11f87:	cmp    %rbx,%rax
 2a11f8a:	cmova  %r11,%r13
 2a11f8e:	mov    0x10(%r13),%r13d
 2a11f92:	test   %r13d,%r13d
 2a11f95:	je     2a198a4 <wasm[0]::function[1015]::helper::object_read+0x1b744>
 2a11f9b:	test   %r13d,%r13d
 2a11f9e:	je     2a198a6 <wasm[0]::function[1015]::helper::object_read+0x1b746>
 2a11fa4:	mov    %r13d,%r10d
 2a11fa7:	lea    (%r12,%r10,1),%r13
 2a11fab:	cmp    %rbx,%r10
 2a11fae:	cmova  %r11,%r13
 2a11fb2:	mov    0x10(%r13),%r13d
 2a11fb6:	test   %r13d,%r13d
 2a11fb9:	je     2a198a8 <wasm[0]::function[1015]::helper::object_read+0x1b748>
 2a11fbf:	test   %r13d,%r13d
 2a11fc2:	je     2a198aa <wasm[0]::function[1015]::helper::object_read+0x1b74a>
 2a11fc8:	mov    %r13d,%r10d
 2a11fcb:	lea    0x10(%r12,%r10,1),%r12
 2a11fd0:	cmp    %rbx,%r10
 2a11fd3:	cmova  %r11,%r12
 2a11fd7:	cmp    (%r12),%ecx
 2a11fdb:	setae  %r11b
 2a11fdf:	cmp    $0x2,%ecx
 2a11fe2:	setae  %r10b
 2a11fe6:	or     %r10d,%r11d
 2a11fe9:	test   %r11b,%r11b
 2a11fec:	jne    2a198ac <wasm[0]::function[1015]::helper::object_read+0x1b74c>
 2a11ff2:	mov    0x2e0(%rsp),%r14
 2a11ffa:	mov    0x28(%r14),%r13
 2a11ffe:	mov    %rax,%r11
 2a12001:	add    0x20(%r14),%r11
 2a12005:	xor    %r14,%r14
 2a12008:	cmp    %r13,%rax
 2a1200b:	cmova  %r14,%r11
 2a1200f:	mov    0x14(%r11),%ebx
 2a12013:	test   %ecx,%ecx
 2a12015:	je     2a1204e <wasm[0]::function[1015]::helper::object_read+0x13eee>
 2a1201b:	mov    0x2e0(%rsp),%r14
 2a12023:	mov    0x28(%r14),%r12
 2a12027:	mov    0x20(%r14),%r10
 2a1202b:	lea    (%r10,%rax,1),%r11
 2a1202f:	xor    %r13,%r13
 2a12032:	cmp    %r12,%rax
 2a12035:	cmova  %r13,%r11
 2a12039:	mov    0x20(%r11),%r12
 2a1203d:	mov    0x2c(%r11),%r13d
 2a12041:	mov    %r12,0x1e8(%rsp)
 2a12049:	jmp    2a1207c <wasm[0]::function[1015]::helper::object_read+0x13f1c>
 2a1204e:	mov    0x2e0(%rsp),%r14
 2a12056:	mov    0x28(%r14),%r12
 2a1205a:	mov    0x20(%r14),%r10
 2a1205e:	lea    (%r10,%rax,1),%r11
 2a12062:	xor    %r13,%r13
 2a12065:	cmp    %r12,%rax
 2a12068:	cmova  %r13,%r11
 2a1206c:	mov    0x18(%r11),%r12
 2a12070:	mov    %r12,0x1e8(%rsp)
 2a12078:	mov    0x28(%r11),%r13d
 2a1207c:	shl    $0x3,%ecx
 2a1207f:	shr    %cl,%ebx
 2a12081:	and    $0xff,%ebx
 2a12087:	mov    %rbx,0x1e0(%rsp)
 2a1208f:	mov    0x1a0(%rsp),%r10
 2a12097:	mov    %r10d,0x90(%rsp)
 2a1209f:	mov    0x1c8(%rsp),%rax
 2a120a7:	mov    %eax,0xd0(%rsp)
 2a120ae:	mov    %r13d,0xd8(%rsp)
 2a120b6:	mov    %edx,0xb0(%rsp)
 2a120bd:	mov    %esi,0xa8(%rsp)
 2a120c4:	mov    %edi,0xc8(%rsp)
 2a120cb:	mov    %r8d,0xb8(%rsp)
 2a120d3:	mov    %r9d,0x88(%rsp)
 2a120db:	mov    $0x287,%edx
 2a120e0:	mov    0x190(%rsp),%rsi
 2a120e8:	mov    0x190(%rsp),%rdi
 2a120f0:	call   2f4f240 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 2a120f5:	mov    %eax,0xc0(%rsp)
 2a120fc:	xor    %esi,%esi
 2a120fe:	test   %eax,%eax
 2a12100:	je     2a198ae <wasm[0]::function[1015]::helper::object_read+0x1b74e>
 2a12106:	movl   $0x0,0xe8(%rsp)
 2a12111:	mov    0xd0(%rsp),%edi
 2a12118:	mov    0xd8(%rsp),%r13d
 2a12120:	mov    0xb0(%rsp),%r9d
 2a12128:	mov    %r9,0x198(%rsp)
 2a12130:	mov    0xa8(%rsp),%r10d
 2a12138:	mov    %r10,0x1a0(%rsp)
 2a12140:	mov    0xc8(%rsp),%r10d
 2a12148:	mov    0xb8(%rsp),%r11d
 2a12150:	mov    0x88(%rsp),%ebx
 2a12157:	xor    %r8,%r8
 2a1215a:	mov    0x248(%rsp),%rax
 2a12162:	mov    0x248(%rsp),%rcx
 2a1216a:	test   %al,%cl
 2a1216c:	jne    2a12182 <wasm[0]::function[1015]::helper::object_read+0x14022>
 2a12172:	mov    %rsi,%rdx
 2a12175:	mov    0x198(%rsp),%r9
 2a1217d:	jmp    2a12d51 <wasm[0]::function[1015]::helper::object_read+0x14bf1>
 2a12182:	mov    0x90(%rsp),%r8d
 2a1218a:	mov    0x258(%rsp),%rcx
 2a12192:	mov    0x250(%rsp),%rdx
 2a1219a:	mov    0x190(%rsp),%rsi
 2a121a2:	mov    0x190(%rsp),%rdi
 2a121aa:	call   2a7c940 <wasm[0]::function[1039]::helper::object_header_projection>
 2a121af:	mov    %eax,0x90(%rsp)
 2a121b6:	test   %eax,%eax
 2a121b8:	je     2a198b0 <wasm[0]::function[1015]::helper::object_read+0x1b750>
 2a121be:	test   %eax,%eax
 2a121c0:	je     2a198b2 <wasm[0]::function[1015]::helper::object_read+0x1b752>
 2a121c6:	mov    0x2e0(%rsp),%r14
 2a121ce:	mov    0x28(%r14),%rcx
 2a121d2:	mov    0x20(%r14),%rsi
 2a121d6:	mov    %eax,%edx
 2a121d8:	lea    (%rsi,%rdx,1),%rax
 2a121dc:	xor    %rsi,%rsi
 2a121df:	cmp    %rcx,%rdx
 2a121e2:	cmova  %rsi,%rax
 2a121e6:	mov    0x14(%rax),%eax
 2a121e9:	mov    %eax,0x78(%rsp)
 2a121ed:	test   %eax,%eax
 2a121ef:	je     2a198b4 <wasm[0]::function[1015]::helper::object_read+0x1b754>
 2a121f5:	mov    0x78(%rsp),%ecx
 2a121f9:	xor    %eax,%eax
 2a121fb:	test   $0x1,%ecx
 2a12201:	jne    2a12259 <wasm[0]::function[1015]::helper::object_read+0x140f9>
 2a12207:	mov    0x2e0(%rsp),%r14
 2a1220f:	mov    0x28(%r14),%rax
 2a12213:	mov    0x20(%r14),%rsi
 2a12217:	mov    %ecx,%edx
 2a12219:	lea    0x4(%rsi,%rdx,1),%rcx
 2a1221e:	xor    %rsi,%rsi
 2a12221:	cmp    %rax,%rdx
 2a12224:	cmova  %rsi,%rcx
 2a12228:	mov    (%rcx),%esi
 2a1222a:	mov    0x190(%rsp),%rax
 2a12232:	mov    0x28(%rax),%rax
 2a12236:	mov    0x158(%rax),%edx
 2a1223c:	cmp    %edx,%esi
 2a1223e:	sete   %al
 2a12241:	movzbl %al,%eax
 2a12244:	cmp    %edx,%esi
 2a12246:	je     2a12259 <wasm[0]::function[1015]::helper::object_read+0x140f9>
 2a1224c:	mov    0x190(%rsp),%rdi
 2a12254:	call   3039cc5 <wasmtime_builtin_is_subtype>
 2a12259:	test   %eax,%eax
 2a1225b:	jne    2a124a4 <wasm[0]::function[1015]::helper::object_read+0x14344>
 2a12261:	mov    0x90(%rsp),%edx
 2a12268:	xor    %ebx,%ebx
 2a1226a:	test   %edx,%edx
 2a1226c:	je     2a198b6 <wasm[0]::function[1015]::helper::object_read+0x1b756>
 2a12272:	mov    0xc0(%rsp),%r9d
 2a1227a:	mov    $0x4,%ecx
 2a1227f:	xor    %r8,%r8
 2a12282:	mov    0x190(%rsp),%rsi
 2a1228a:	mov    0x190(%rsp),%rdi
 2a12292:	call   2a76140 <wasm[0]::function[1032]::helper::ordinary_property_find>
 2a12297:	test   %eax,%eax
 2a12299:	je     2a122d2 <wasm[0]::function[1015]::helper::object_read+0x14172>
 2a1229f:	test   %eax,%eax
 2a122a1:	je     2a198b8 <wasm[0]::function[1015]::helper::object_read+0x1b758>
 2a122a7:	test   %eax,%eax
 2a122a9:	je     2a198ba <wasm[0]::function[1015]::helper::object_read+0x1b75a>
 2a122af:	mov    0x2e0(%rsp),%r14
 2a122b7:	mov    0x28(%r14),%rdi
 2a122bb:	mov    %eax,%r8d
 2a122be:	mov    %r8,%rsi
 2a122c1:	add    0x20(%r14),%rsi
 2a122c5:	xor    %r9,%r9
 2a122c8:	cmp    %rdi,%r8
 2a122cb:	cmova  %r9,%rsi
 2a122cf:	mov    0x14(%rsi),%ebx
 2a122d2:	mov    0xe8(%rsp),%edx
 2a122d9:	xor    %esi,%esi
 2a122db:	xor    %r8,%r8
 2a122de:	test   %ebx,%ebx
 2a122e0:	je     2a12459 <wasm[0]::function[1015]::helper::object_read+0x142f9>
 2a122e6:	test   %ebx,%ebx
 2a122e8:	je     2a198bc <wasm[0]::function[1015]::helper::object_read+0x1b75c>
 2a122ee:	mov    0x2e0(%rsp),%r14
 2a122f6:	mov    0x28(%r14),%rax
 2a122fa:	mov    0x20(%r14),%rdx
 2a122fe:	mov    %ebx,%ecx
 2a12300:	lea    (%rdx,%rcx,1),%r11
 2a12304:	xor    %r8,%r8
 2a12307:	cmp    %rax,%rcx
 2a1230a:	cmova  %r8,%r11
 2a1230e:	mov    0x10(%r11),%eax
 2a12312:	mov    0xe8(%rsp),%edx
 2a12319:	xor    %esi,%esi
 2a1231b:	test   $0x1,%eax
 2a12320:	jne    2a12459 <wasm[0]::function[1015]::helper::object_read+0x142f9>
 2a12326:	mov    0x14(%r11),%edx
 2a1232a:	test   %edx,%edx
 2a1232c:	je     2a198be <wasm[0]::function[1015]::helper::object_read+0x1b75e>
 2a12332:	xor    %eax,%eax
 2a12334:	test   $0x1,%edx
 2a1233a:	jne    2a1237b <wasm[0]::function[1015]::helper::object_read+0x1421b>
 2a12340:	mov    0x2e0(%rsp),%r14
 2a12348:	mov    0x28(%r14),%rax
 2a1234c:	mov    0x20(%r14),%rcx
 2a12350:	mov    %edx,%esi
 2a12352:	lea    0x4(%rcx,%rsi,1),%rcx
 2a12357:	xor    %rdi,%rdi
 2a1235a:	cmp    %rax,%rsi
 2a1235d:	cmova  %rdi,%rcx
 2a12361:	mov    (%rcx),%eax
 2a12363:	mov    0x190(%rsp),%rsi
 2a1236b:	mov    0x28(%rsi),%rcx
 2a1236f:	cmp    0x120(%rcx),%eax
 2a12375:	sete   %al
 2a12378:	movzbl %al,%eax
 2a1237b:	test   %eax,%eax
 2a1237d:	jne    2a123d7 <wasm[0]::function[1015]::helper::object_read+0x14277>
 2a12383:	mov    0x190(%rsp),%rsi
 2a1238b:	mov    0x190(%rsp),%rdi
 2a12393:	call   2a1eec0 <wasm[0]::function[1024]::helper::property_value_resolve>
 2a12398:	test   %eax,%eax
 2a1239a:	je     2a198c0 <wasm[0]::function[1015]::helper::object_read+0x1b760>
 2a123a0:	test   %eax,%eax
 2a123a2:	je     2a198c2 <wasm[0]::function[1015]::helper::object_read+0x1b762>
 2a123a8:	mov    0x2e0(%rsp),%r14
 2a123b0:	mov    0x28(%r14),%rcx
 2a123b4:	mov    0x20(%r14),%rsi
 2a123b8:	mov    %eax,%edx
 2a123ba:	lea    (%rsi,%rdx,1),%rax
 2a123be:	xor    %rsi,%rsi
 2a123c1:	cmp    %rcx,%rdx
 2a123c4:	cmova  %rsi,%rax
 2a123c8:	mov    0x18(%rax),%esi
 2a123cb:	mov    0x10(%rax),%r8
 2a123cf:	mov    0x1c(%rax),%edx
 2a123d2:	jmp    2a12459 <wasm[0]::function[1015]::helper::object_read+0x142f9>
 2a123d7:	xor    %eax,%eax
 2a123d9:	test   $0x1,%edx
 2a123df:	jne    2a12420 <wasm[0]::function[1015]::helper::object_read+0x142c0>
 2a123e5:	mov    0x2e0(%rsp),%r14
 2a123ed:	mov    0x28(%r14),%rax
 2a123f1:	mov    0x20(%r14),%rcx
 2a123f5:	mov    %edx,%esi
 2a123f7:	lea    0x4(%rcx,%rsi,1),%rcx
 2a123fc:	xor    %rdi,%rdi
 2a123ff:	cmp    %rax,%rsi
 2a12402:	cmova  %rdi,%rcx
 2a12406:	mov    (%rcx),%eax
 2a12408:	mov    0x190(%rsp),%rsi
 2a12410:	mov    0x28(%rsi),%rcx
 2a12414:	cmp    0x120(%rcx),%eax
 2a1241a:	sete   %al
 2a1241d:	movzbl %al,%eax
 2a12420:	test   %eax,%eax
 2a12422:	je     2a198c4 <wasm[0]::function[1015]::helper::object_read+0x1b764>
 2a12428:	test   %edx,%edx
 2a1242a:	je     2a198c6 <wasm[0]::function[1015]::helper::object_read+0x1b766>
 2a12430:	mov    0x2e0(%rsp),%r14
 2a12438:	mov    0x28(%r14),%rcx
 2a1243c:	mov    0x20(%r14),%rax
 2a12440:	mov    %edx,%edx
 2a12442:	add    %rdx,%rax
 2a12445:	xor    %rsi,%rsi
 2a12448:	cmp    %rcx,%rdx
 2a1244b:	cmova  %rsi,%rax
 2a1244f:	mov    0x18(%rax),%esi
 2a12452:	mov    0x10(%rax),%r8
 2a12456:	mov    0x1c(%rax),%edx
 2a12459:	mov    0xd0(%rsp),%edi
 2a12460:	mov    0xd8(%rsp),%r13d
 2a12468:	mov    0xb0(%rsp),%r9d
 2a12470:	mov    %r9,0x198(%rsp)
 2a12478:	mov    0xa8(%rsp),%r10d
 2a12480:	mov    %r10,0x1a0(%rsp)
 2a12488:	mov    0xc8(%rsp),%r10d
 2a12490:	mov    0xb8(%rsp),%r11d
 2a12498:	mov    0x88(%rsp),%ebx
 2a1249f:	jmp    2a12d49 <wasm[0]::function[1015]::helper::object_read+0x14be9>
 2a124a4:	mov    0x78(%rsp),%eax
 2a124a8:	test   %eax,%eax
 2a124aa:	je     2a198c8 <wasm[0]::function[1015]::helper::object_read+0x1b768>
 2a124b0:	mov    0x78(%rsp),%ecx
 2a124b4:	xor    %eax,%eax
 2a124b6:	test   $0x1,%ecx
 2a124bc:	jne    2a12514 <wasm[0]::function[1015]::helper::object_read+0x143b4>
 2a124c2:	mov    0x2e0(%rsp),%r14
 2a124ca:	mov    0x28(%r14),%rax
 2a124ce:	mov    0x20(%r14),%rsi
 2a124d2:	mov    %ecx,%edx
 2a124d4:	lea    0x4(%rsi,%rdx,1),%rcx
 2a124d9:	xor    %rsi,%rsi
 2a124dc:	cmp    %rax,%rdx
 2a124df:	cmova  %rsi,%rcx
 2a124e3:	mov    (%rcx),%esi
 2a124e5:	mov    0x190(%rsp),%rax
 2a124ed:	mov    0x28(%rax),%rax
 2a124f1:	mov    0x158(%rax),%edx
 2a124f7:	cmp    %edx,%esi
 2a124f9:	sete   %al
 2a124fc:	movzbl %al,%eax
 2a124ff:	cmp    %edx,%esi
 2a12501:	je     2a12514 <wasm[0]::function[1015]::helper::object_read+0x143b4>
 2a12507:	mov    0x190(%rsp),%rdi
 2a1250f:	call   3039cc5 <wasmtime_builtin_is_subtype>
 2a12514:	test   %eax,%eax
 2a12516:	je     2a198ca <wasm[0]::function[1015]::helper::object_read+0x1b76a>
 2a1251c:	mov    0x78(%rsp),%r15d
 2a12521:	mov    0xd0(%rsp),%edi
 2a12528:	mov    0xd8(%rsp),%r13d
 2a12530:	mov    0xe8(%rsp),%edx
 2a12537:	mov    0xb0(%rsp),%r9d
 2a1253f:	mov    %r9,0x198(%rsp)
 2a12547:	mov    0xa8(%rsp),%r10d
 2a1254f:	mov    %r10,0x1a0(%rsp)
 2a12557:	mov    0xc8(%rsp),%r10d
 2a1255f:	mov    0xb8(%rsp),%r11d
 2a12567:	mov    0x88(%rsp),%ebx
 2a1256e:	xor    %ecx,%ecx
 2a12570:	mov    %rcx,0x230(%rsp)
 2a12578:	test   %r15d,%r15d
 2a1257b:	je     2a198cc <wasm[0]::function[1015]::helper::object_read+0x1b76c>
 2a12581:	test   %r15d,%r15d
 2a12584:	je     2a198ce <wasm[0]::function[1015]::helper::object_read+0x1b76e>
 2a1258a:	mov    0x2e0(%rsp),%r14
 2a12592:	mov    0x28(%r14),%r8
 2a12596:	mov    0x20(%r14),%rax
 2a1259a:	mov    %r15d,%r12d
 2a1259d:	lea    (%rax,%r12,1),%rsi
 2a125a1:	xor    %rcx,%rcx
 2a125a4:	cmp    %r8,%r12
 2a125a7:	cmova  %rcx,%rsi
 2a125ab:	mov    0x10(%rsi),%esi
 2a125ae:	test   %esi,%esi
 2a125b0:	je     2a198d0 <wasm[0]::function[1015]::helper::object_read+0x1b770>
 2a125b6:	test   %esi,%esi
 2a125b8:	je     2a198d2 <wasm[0]::function[1015]::helper::object_read+0x1b772>
 2a125be:	mov    %esi,%r14d
 2a125c1:	lea    (%rax,%r14,1),%rsi
 2a125c5:	cmp    %r8,%r14
 2a125c8:	cmova  %rcx,%rsi
 2a125cc:	mov    0x10(%rsi),%esi
 2a125cf:	test   %esi,%esi
 2a125d1:	je     2a198d4 <wasm[0]::function[1015]::helper::object_read+0x1b774>
 2a125d7:	test   %esi,%esi
 2a125d9:	je     2a198d6 <wasm[0]::function[1015]::helper::object_read+0x1b776>
 2a125df:	mov    %esi,%r12d
 2a125e2:	lea    0x10(%rax,%r12,1),%rax
 2a125e7:	cmp    %r8,%r12
 2a125ea:	cmova  %rcx,%rax
 2a125ee:	mov    (%rax),%r12d
 2a125f1:	mov    %r12,0x238(%rsp)
 2a125f9:	mov    0xc0(%rsp),%r8d
 2a12601:	mov    0x190(%rsp),%rax
 2a12609:	mov    0x28(%rax),%rax
 2a1260d:	mov    0x234(%rax),%r12d
 2a12614:	mov    0x230(%rsp),%rax
 2a1261c:	mov    %rax,0x1c8(%rsp)
 2a12624:	mov    %esi,0x90(%rsp)
 2a1262b:	mov    %r8d,0x88(%rsp)
 2a12633:	mov    %r15d,0xb8(%rsp)
 2a1263b:	mov    %edi,0xc8(%rsp)
 2a12642:	mov    %r13d,0xa8(%rsp)
 2a1264a:	mov    %edx,0xb0(%rsp)
 2a12651:	mov    0x198(%rsp),%r9
 2a12659:	mov    %r9d,0xe8(%rsp)
 2a12661:	mov    0x1a0(%rsp),%r9
 2a12669:	mov    %r9d,0xd8(%rsp)
 2a12671:	mov    %r10d,0xd0(%rsp)
 2a12679:	mov    %r11d,0x78(%rsp)
 2a1267e:	mov    %ebx,0xc0(%rsp)
 2a12685:	mov    0x2e8(%rsp),%r15
 2a1268d:	mov    (%r15),%rcx
 2a12690:	mov    0x228(%rsp),%rax
 2a12698:	cmp    %rax,%rcx
 2a1269b:	jae    2a187c1 <wasm[0]::function[1015]::helper::object_read+0x1a661>
 2a126a1:	jmp    2a126ae <wasm[0]::function[1015]::helper::object_read+0x1454e>
 2a126a6:	mov    %rdx,0x228(%rsp)
 2a126ae:	mov    0xb8(%rsp),%r15d
 2a126b6:	mov    0xc8(%rsp),%edi
 2a126bd:	mov    0xa8(%rsp),%r13d
 2a126c5:	mov    0xb0(%rsp),%edx
 2a126cc:	mov    0xe8(%rsp),%r9d
 2a126d4:	mov    %r9,0x198(%rsp)
 2a126dc:	mov    0xd8(%rsp),%r10d
 2a126e4:	mov    %r10,0x1a0(%rsp)
 2a126ec:	mov    0xd0(%rsp),%r10d
 2a126f4:	mov    0x78(%rsp),%r11d
 2a126f9:	mov    0xc0(%rsp),%ebx
 2a12700:	mov    0x238(%rsp),%rax
 2a12708:	mov    0x230(%rsp),%rcx
 2a12710:	cmp    %eax,%ecx
 2a12712:	jb     2a12725 <wasm[0]::function[1015]::helper::object_read+0x145c5>
 2a12718:	mov    0x1c8(%rsp),%rax
 2a12720:	jmp    2a12945 <wasm[0]::function[1015]::helper::object_read+0x147e5>
 2a12725:	mov    0x90(%rsp),%eax
 2a1272c:	test   %eax,%eax
 2a1272e:	je     2a198d8 <wasm[0]::function[1015]::helper::object_read+0x1b778>
 2a12734:	test   %eax,%eax
 2a12736:	je     2a198da <wasm[0]::function[1015]::helper::object_read+0x1b77a>
 2a1273c:	mov    0x2e0(%rsp),%r14
 2a12744:	mov    0x28(%r14),%rdx
 2a12748:	mov    0x20(%r14),%rsi
 2a1274c:	mov    %eax,%r9d
 2a1274f:	lea    0x10(%rsi,%r9,1),%r8
 2a12754:	xor    %rdi,%rdi
 2a12757:	cmp    %rdx,%r9
 2a1275a:	cmova  %rdi,%r8
 2a1275e:	mov    (%r8),%r8d
 2a12761:	cmp    %r8d,%ecx
 2a12764:	jae    2a198dc <wasm[0]::function[1015]::helper::object_read+0x1b77c>
 2a1276a:	mov    %r8d,%r9d
 2a1276d:	shl    $0x2,%r9
 2a12771:	shr    $0x20,%r9
 2a12775:	test   %r9,%r9
 2a12778:	jne    2a198de <wasm[0]::function[1015]::helper::object_read+0x1b77e>
 2a1277e:	shl    $0x2,%r8d
 2a12782:	add    $0x14,%r8d
 2a12786:	jb     2a198e0 <wasm[0]::function[1015]::helper::object_read+0x1b780>
 2a1278c:	add    %r8d,%eax
 2a1278f:	jb     2a198e2 <wasm[0]::function[1015]::helper::object_read+0x1b782>
 2a12795:	mov    %eax,%r9d
 2a12798:	lea    (%rsi,%r9,1),%rax
 2a1279c:	cmp    %rdx,%r9
 2a1279f:	cmova  %rdi,%rax
 2a127a3:	mov    %rcx,%rdx
 2a127a6:	shl    $0x2,%edx
 2a127a9:	mov    %rcx,0x230(%rsp)
 2a127b1:	lea    0x14(%rdx),%ecx
 2a127b4:	sub    %ecx,%r8d
 2a127b7:	sub    %r8,%rax
 2a127ba:	mov    (%rax),%edx
 2a127bc:	test   %edx,%edx
 2a127be:	je     2a198e4 <wasm[0]::function[1015]::helper::object_read+0x1b784>
 2a127c4:	mov    0x88(%rsp),%eax
 2a127cb:	cmp    %eax,%edx
 2a127cd:	je     2a128a4 <wasm[0]::function[1015]::helper::object_read+0x14744>
 2a127d3:	xor    %ecx,%ecx
 2a127d5:	test   %edx,%edx
 2a127d7:	je     2a12819 <wasm[0]::function[1015]::helper::object_read+0x146b9>
 2a127dd:	xor    %ecx,%ecx
 2a127df:	test   $0x1,%edx
 2a127e5:	jne    2a12819 <wasm[0]::function[1015]::helper::object_read+0x146b9>
 2a127eb:	mov    0x2e0(%rsp),%r14
 2a127f3:	mov    0x28(%r14),%rsi
 2a127f7:	mov    0x20(%r14),%r8
 2a127fb:	mov    %edx,%edi
 2a127fd:	lea    0x4(%r8,%rdi,1),%rcx
 2a12802:	xor    %r8,%r8
 2a12805:	cmp    %rsi,%rdi
 2a12808:	cmova  %r8,%rcx
 2a1280c:	mov    (%rcx),%esi
 2a1280e:	cmp    %r12d,%esi
 2a12811:	sete   %sil
 2a12815:	movzbl %sil,%ecx
 2a12819:	test   %ecx,%ecx
 2a1281b:	je     2a198e6 <wasm[0]::function[1015]::helper::object_read+0x1b786>
 2a12821:	xor    %ecx,%ecx
 2a12823:	test   %eax,%eax
 2a12825:	je     2a12870 <wasm[0]::function[1015]::helper::object_read+0x14710>
 2a1282b:	mov    0x88(%rsp),%r11d
 2a12833:	xor    %ecx,%ecx
 2a12835:	test   $0x1,%r11d
 2a1283c:	jne    2a12870 <wasm[0]::function[1015]::helper::object_read+0x14710>
 2a12842:	mov    0x2e0(%rsp),%r14
 2a1284a:	mov    0x28(%r14),%rax
 2a1284e:	mov    0x20(%r14),%rsi
 2a12852:	mov    %r11d,%ecx
 2a12855:	lea    0x4(%rsi,%rcx,1),%r11
 2a1285a:	xor    %rsi,%rsi
 2a1285d:	cmp    %rax,%rcx
 2a12860:	cmova  %rsi,%r11
 2a12864:	mov    (%r11),%eax
 2a12867:	cmp    %r12d,%eax
 2a1286a:	sete   %al
 2a1286d:	movzbl %al,%ecx
 2a12870:	test   %ecx,%ecx
 2a12872:	je     2a198e8 <wasm[0]::function[1015]::helper::object_read+0x1b788>
 2a12878:	mov    0x88(%rsp),%ecx
 2a1287f:	xor    %r8d,%r8d
 2a12882:	test   %ecx,%ecx
 2a12884:	je     2a198ea <wasm[0]::function[1015]::helper::object_read+0x1b78a>
 2a1288a:	mov    0x190(%rsp),%rsi
 2a12892:	mov    0x190(%rsp),%rdi
 2a1289a:	call   2b02800 <wasm[0]::function[1057]::helper::string_equality>
 2a1289f:	jmp    2a128ac <wasm[0]::function[1015]::helper::object_read+0x1474c>
 2a128a4:	mov    0x278(%rsp),%rax
 2a128ac:	mov    0x90(%rsp),%esi
 2a128b3:	mov    0x88(%rsp),%r8d
 2a128bb:	mov    0xb8(%rsp),%r15d
 2a128c3:	mov    0xc8(%rsp),%edi
 2a128ca:	mov    0xa8(%rsp),%r13d
 2a128d2:	mov    0xb0(%rsp),%edx
 2a128d9:	mov    0xe8(%rsp),%r9d
 2a128e1:	mov    %r9,0x198(%rsp)
 2a128e9:	mov    0xd8(%rsp),%r10d
 2a128f1:	mov    %r10,0x1a0(%rsp)
 2a128f9:	mov    0xd0(%rsp),%r10d
 2a12901:	mov    0x78(%rsp),%r11d
 2a12906:	mov    0xc0(%rsp),%ebx
 2a1290d:	test   %eax,%eax
 2a1290f:	je     2a12922 <wasm[0]::function[1015]::helper::object_read+0x147c2>
 2a12915:	mov    0x230(%rsp),%rcx
 2a1291d:	jmp    2a12945 <wasm[0]::function[1015]::helper::object_read+0x147e5>
 2a12922:	mov    0x230(%rsp),%rcx
 2a1292a:	add    $0x1,%ecx
 2a12930:	mov    %rax,0x1c8(%rsp)
 2a12938:	mov    %rcx,0x230(%rsp)
 2a12940:	jmp    2a12624 <wasm[0]::function[1015]::helper::object_read+0x144c4>
 2a12945:	xor    %esi,%esi
 2a12947:	xor    %r8,%r8
 2a1294a:	test   %eax,%eax
 2a1294c:	je     2a12d49 <wasm[0]::function[1015]::helper::object_read+0x14be9>
 2a12952:	test   %r15d,%r15d
 2a12955:	je     2a198ec <wasm[0]::function[1015]::helper::object_read+0x1b78c>
 2a1295b:	xor    %eax,%eax
 2a1295d:	test   $0x1,%r15d
 2a12964:	jne    2a129a6 <wasm[0]::function[1015]::helper::object_read+0x14846>
 2a1296a:	mov    0x2e0(%rsp),%r14
 2a12972:	mov    0x28(%r14),%rax
 2a12976:	mov    0x20(%r14),%rdx
 2a1297a:	mov    %r15d,%esi
 2a1297d:	lea    0x4(%rdx,%rsi,1),%rdx
 2a12982:	xor    %r8,%r8
 2a12985:	cmp    %rax,%rsi
 2a12988:	cmova  %r8,%rdx
 2a1298c:	mov    (%rdx),%eax
 2a1298e:	mov    0x190(%rsp),%rsi
 2a12996:	mov    0x28(%rsi),%rdx
 2a1299a:	cmp    0x160(%rdx),%eax
 2a129a0:	sete   %al
 2a129a3:	movzbl %al,%eax
 2a129a6:	test   %eax,%eax
 2a129a8:	jne    2a12be9 <wasm[0]::function[1015]::helper::object_read+0x14a89>
 2a129ae:	xor    %eax,%eax
 2a129b0:	test   $0x1,%r15d
 2a129b7:	jne    2a129f9 <wasm[0]::function[1015]::helper::object_read+0x14899>
 2a129bd:	mov    0x2e0(%rsp),%r14
 2a129c5:	mov    0x28(%r14),%rax
 2a129c9:	mov    0x20(%r14),%rdx
 2a129cd:	mov    %r15d,%esi
 2a129d0:	lea    0x4(%rdx,%rsi,1),%rdx
 2a129d5:	xor    %r8,%r8
 2a129d8:	cmp    %rax,%rsi
 2a129db:	cmova  %r8,%rdx
 2a129df:	mov    (%rdx),%eax
 2a129e1:	mov    0x190(%rsp),%rsi
 2a129e9:	mov    0x28(%rsi),%rdx
 2a129ed:	cmp    0x15c(%rdx),%eax
 2a129f3:	sete   %al
 2a129f6:	movzbl %al,%eax
 2a129f9:	test   %eax,%eax
 2a129fb:	je     2a198ee <wasm[0]::function[1015]::helper::object_read+0x1b78e>
 2a12a01:	test   %r15d,%r15d
 2a12a04:	je     2a198f0 <wasm[0]::function[1015]::helper::object_read+0x1b790>
 2a12a0a:	mov    0x2e0(%rsp),%r14
 2a12a12:	mov    0x28(%r14),%rdx
 2a12a16:	mov    0x20(%r14),%r12
 2a12a1a:	mov    %r15d,%eax
 2a12a1d:	lea    (%r12,%rax,1),%rsi
 2a12a21:	xor    %r8,%r8
 2a12a24:	cmp    %rdx,%rax
 2a12a27:	cmova  %r8,%rsi
 2a12a2b:	mov    0x14(%rsi),%r14d
 2a12a2f:	mov    0x18(%rsi),%eax
 2a12a32:	mov    0x1c(%rsi),%esi
 2a12a35:	test   %r14d,%r14d
 2a12a38:	je     2a198f2 <wasm[0]::function[1015]::helper::object_read+0x1b792>
 2a12a3e:	test   %r14d,%r14d
 2a12a41:	je     2a198f4 <wasm[0]::function[1015]::helper::object_read+0x1b794>
 2a12a47:	mov    %r14d,%r9d
 2a12a4a:	lea    0x10(%r12,%r9,1),%r15
 2a12a4f:	cmp    %rdx,%r9
 2a12a52:	cmova  %r8,%r15
 2a12a56:	mov    (%r15),%r15d
 2a12a59:	cmp    %r15d,%ecx
 2a12a5c:	jae    2a198f6 <wasm[0]::function[1015]::helper::object_read+0x1b796>
 2a12a62:	mov    %r15d,%r9d
 2a12a65:	shr    $0x20,%r9
 2a12a69:	test   %r9,%r9
 2a12a6c:	jne    2a198f8 <wasm[0]::function[1015]::helper::object_read+0x1b798>
 2a12a72:	add    $0x14,%r15d
 2a12a76:	jb     2a198fa <wasm[0]::function[1015]::helper::object_read+0x1b79a>
 2a12a7c:	add    %r15d,%r14d
 2a12a7f:	jb     2a198fc <wasm[0]::function[1015]::helper::object_read+0x1b79c>
 2a12a85:	mov    %r14d,%r9d
 2a12a88:	add    %r9,%r12
 2a12a8b:	cmp    %rdx,%r9
 2a12a8e:	cmova  %r8,%r12
 2a12a92:	lea    0x14(%rcx),%r9d
 2a12a96:	sub    %r9d,%r15d
 2a12a99:	sub    %r15,%r12
 2a12a9c:	movzbq (%r12),%r9
 2a12aa1:	mov    %r9,0x238(%rsp)
 2a12aa9:	test   %eax,%eax
 2a12aab:	je     2a12b3e <wasm[0]::function[1015]::helper::object_read+0x149de>
 2a12ab1:	test   %eax,%eax
 2a12ab3:	je     2a198fe <wasm[0]::function[1015]::helper::object_read+0x1b79e>
 2a12ab9:	test   %eax,%eax
 2a12abb:	je     2a19900 <wasm[0]::function[1015]::helper::object_read+0x1b7a0>
 2a12ac1:	mov    0x2e0(%rsp),%r14
 2a12ac9:	mov    0x28(%r14),%rdx
 2a12acd:	mov    0x20(%r14),%r8
 2a12ad1:	mov    %eax,%r15d
 2a12ad4:	lea    0x10(%r8,%r15,1),%r12
 2a12ad9:	xor    %r14,%r14
 2a12adc:	cmp    %rdx,%r15
 2a12adf:	cmova  %r14,%r12
 2a12ae3:	mov    (%r12),%r12d
 2a12ae7:	cmp    %r12d,%ecx
 2a12aea:	jae    2a19902 <wasm[0]::function[1015]::helper::object_read+0x1b7a2>
 2a12af0:	mov    %r12d,%r15d
 2a12af3:	shl    $0x3,%r15
 2a12af7:	shr    $0x20,%r15
 2a12afb:	test   %r15,%r15
 2a12afe:	jne    2a19904 <wasm[0]::function[1015]::helper::object_read+0x1b7a4>
 2a12b04:	shl    $0x3,%r12d
 2a12b08:	add    $0x18,%r12d
 2a12b0c:	jb     2a19906 <wasm[0]::function[1015]::helper::object_read+0x1b7a6>
 2a12b12:	add    %r12d,%eax
 2a12b15:	jb     2a19908 <wasm[0]::function[1015]::helper::object_read+0x1b7a8>
 2a12b1b:	mov    %eax,%r9d
 2a12b1e:	lea    (%r8,%r9,1),%rax
 2a12b22:	cmp    %rdx,%r9
 2a12b25:	cmova  %r14,%rax
 2a12b29:	mov    %rcx,%rdx
 2a12b2c:	shl    $0x3,%edx
 2a12b2f:	add    $0x18,%edx
 2a12b35:	sub    %edx,%r12d
 2a12b38:	sub    %r12,%rax
 2a12b3b:	mov    (%rax),%r8
 2a12b3e:	xor    %edx,%edx
 2a12b40:	test   %esi,%esi
 2a12b42:	jne    2a12b55 <wasm[0]::function[1015]::helper::object_read+0x149f5>
 2a12b48:	mov    0x238(%rsp),%r9
 2a12b50:	jmp    2a12be0 <wasm[0]::function[1015]::helper::object_read+0x14a80>
 2a12b55:	test   %esi,%esi
 2a12b57:	je     2a1990a <wasm[0]::function[1015]::helper::object_read+0x1b7aa>
 2a12b5d:	test   %esi,%esi
 2a12b5f:	je     2a1990c <wasm[0]::function[1015]::helper::object_read+0x1b7ac>
 2a12b65:	mov    0x2e0(%rsp),%r14
 2a12b6d:	mov    0x28(%r14),%rax
 2a12b71:	mov    0x20(%r14),%rdx
 2a12b75:	mov    %esi,%r15d
 2a12b78:	lea    0x10(%rdx,%r15,1),%r14
 2a12b7d:	xor    %r12,%r12
 2a12b80:	cmp    %rax,%r15
 2a12b83:	cmova  %r12,%r14
 2a12b87:	mov    (%r14),%r14d
 2a12b8a:	cmp    %r14d,%ecx
 2a12b8d:	jae    2a1990e <wasm[0]::function[1015]::helper::object_read+0x1b7ae>
 2a12b93:	mov    %r14d,%r15d
 2a12b96:	shl    $0x2,%r15
 2a12b9a:	shr    $0x20,%r15
 2a12b9e:	test   %r15,%r15
 2a12ba1:	jne    2a19910 <wasm[0]::function[1015]::helper::object_read+0x1b7b0>
 2a12ba7:	shl    $0x2,%r14d
 2a12bab:	add    $0x14,%r14d
 2a12baf:	jb     2a19912 <wasm[0]::function[1015]::helper::object_read+0x1b7b2>
 2a12bb5:	add    %r14d,%esi
 2a12bb8:	jb     2a19914 <wasm[0]::function[1015]::helper::object_read+0x1b7b4>
 2a12bbe:	mov    %esi,%esi
 2a12bc0:	add    %rsi,%rdx
 2a12bc3:	cmp    %rax,%rsi
 2a12bc6:	cmova  %r12,%rdx
 2a12bca:	shl    $0x2,%ecx
 2a12bcd:	lea    0x14(%rcx),%eax
 2a12bd0:	sub    %eax,%r14d
 2a12bd3:	sub    %r14,%rdx
 2a12bd6:	mov    (%rdx),%edx
 2a12bd8:	mov    0x238(%rsp),%r9
 2a12be0:	movzbl %r9b,%esi
 2a12be4:	jmp    2a12d49 <wasm[0]::function[1015]::helper::object_read+0x14be9>
 2a12be9:	xor    %eax,%eax
 2a12beb:	test   $0x1,%r15d
 2a12bf2:	jne    2a12c34 <wasm[0]::function[1015]::helper::object_read+0x14ad4>
 2a12bf8:	mov    0x2e0(%rsp),%r14
 2a12c00:	mov    0x28(%r14),%rax
 2a12c04:	mov    0x20(%r14),%rdx
 2a12c08:	mov    %r15d,%esi
 2a12c0b:	lea    0x4(%rdx,%rsi,1),%rdx
 2a12c10:	xor    %r8,%r8
 2a12c13:	cmp    %rax,%rsi
 2a12c16:	cmova  %r8,%rdx
 2a12c1a:	mov    (%rdx),%eax
 2a12c1c:	mov    0x190(%rsp),%rsi
 2a12c24:	mov    0x28(%rsi),%rdx
 2a12c28:	cmp    0x160(%rdx),%eax
 2a12c2e:	sete   %al
 2a12c31:	movzbl %al,%eax
 2a12c34:	test   %eax,%eax
 2a12c36:	je     2a19916 <wasm[0]::function[1015]::helper::object_read+0x1b7b6>
 2a12c3c:	test   %r15d,%r15d
 2a12c3f:	je     2a19918 <wasm[0]::function[1015]::helper::object_read+0x1b7b8>
 2a12c45:	mov    0x2e0(%rsp),%r14
 2a12c4d:	mov    0x28(%r14),%rdx
 2a12c51:	mov    0x20(%r14),%rsi
 2a12c55:	mov    %r15d,%eax
 2a12c58:	lea    (%rsi,%rax,1),%r12
 2a12c5c:	xor    %r8,%r8
 2a12c5f:	cmp    %rdx,%rax
 2a12c62:	cmova  %r8,%r12
 2a12c66:	mov    0x10(%r12),%r12d
 2a12c6b:	test   %r12d,%r12d
 2a12c6e:	je     2a1991a <wasm[0]::function[1015]::helper::object_read+0x1b7ba>
 2a12c74:	test   %r12d,%r12d
 2a12c77:	je     2a1991c <wasm[0]::function[1015]::helper::object_read+0x1b7bc>
 2a12c7d:	mov    %r12d,%r9d
 2a12c80:	lea    (%rsi,%r9,1),%r12
 2a12c84:	cmp    %rdx,%r9
 2a12c87:	cmova  %r8,%r12
 2a12c8b:	mov    0x10(%r12),%r12d
 2a12c90:	test   %r12d,%r12d
 2a12c93:	je     2a1991e <wasm[0]::function[1015]::helper::object_read+0x1b7be>
 2a12c99:	test   %r12d,%r12d
 2a12c9c:	je     2a19920 <wasm[0]::function[1015]::helper::object_read+0x1b7c0>
 2a12ca2:	mov    %r12d,%r9d
 2a12ca5:	lea    0x10(%rsi,%r9,1),%rsi
 2a12caa:	cmp    %rdx,%r9
 2a12cad:	cmova  %r8,%rsi
 2a12cb1:	cmp    (%rsi),%ecx
 2a12cb3:	setae  %dl
 2a12cb6:	cmp    $0x2,%ecx
 2a12cb9:	setae  %sil
 2a12cbd:	or     %esi,%edx
 2a12cbf:	test   %dl,%dl
 2a12cc1:	jne    2a19922 <wasm[0]::function[1015]::helper::object_read+0x1b7c2>
 2a12cc7:	mov    0x2e0(%rsp),%r14
 2a12ccf:	mov    0x28(%r14),%rsi
 2a12cd3:	mov    %rax,%rdx
 2a12cd6:	add    0x20(%r14),%rdx
 2a12cda:	xor    %r8,%r8
 2a12cdd:	cmp    %rsi,%rax
 2a12ce0:	cmova  %r8,%rdx
 2a12ce4:	mov    0x14(%rdx),%esi
 2a12ce7:	test   %ecx,%ecx
 2a12ce9:	je     2a12d19 <wasm[0]::function[1015]::helper::object_read+0x14bb9>
 2a12cef:	mov    0x2e0(%rsp),%r14
 2a12cf7:	mov    0x28(%r14),%r8
 2a12cfb:	mov    0x20(%r14),%r9
 2a12cff:	lea    (%r9,%rax,1),%rdx
 2a12d03:	xor    %r12,%r12
 2a12d06:	cmp    %r8,%rax
 2a12d09:	cmova  %r12,%rdx
 2a12d0d:	mov    0x20(%rdx),%r8
 2a12d11:	mov    0x2c(%rdx),%edx
 2a12d14:	jmp    2a12d3e <wasm[0]::function[1015]::helper::object_read+0x14bde>
 2a12d19:	mov    0x2e0(%rsp),%r14
 2a12d21:	mov    0x28(%r14),%r8
 2a12d25:	mov    0x20(%r14),%r9
 2a12d29:	lea    (%r9,%rax,1),%rdx
 2a12d2d:	xor    %r12,%r12
 2a12d30:	cmp    %r8,%rax
 2a12d33:	cmova  %r12,%rdx
 2a12d37:	mov    0x18(%rdx),%r8
 2a12d3b:	mov    0x28(%rdx),%edx
 2a12d3e:	shl    $0x3,%ecx
 2a12d41:	shr    %cl,%esi
 2a12d43:	and    $0xff,%esi
 2a12d49:	mov    0x198(%rsp),%r9
 2a12d51:	mov    %r9d,0xa8(%rsp)
 2a12d59:	mov    0x1a0(%rsp),%rax
 2a12d61:	mov    %eax,0xc8(%rsp)
 2a12d68:	mov    %r10d,0xb8(%rsp)
 2a12d70:	mov    %r11d,0x88(%rsp)
 2a12d78:	mov    %ebx,0x90(%rsp)
 2a12d7f:	mov    0x1d0(%rsp),%rcx
 2a12d87:	cmp    $0x2,%ecx
 2a12d8a:	je     2a13093 <wasm[0]::function[1015]::helper::object_read+0x14f33>
 2a12d90:	cmp    $0x4,%ecx
 2a12d93:	je     2a12fca <wasm[0]::function[1015]::helper::object_read+0x14e6a>
 2a12d99:	cmp    $0x3,%ecx
 2a12d9c:	je     2a12f8e <wasm[0]::function[1015]::helper::object_read+0x14e2e>
 2a12da2:	cmp    $0xa,%ecx
 2a12da5:	je     2a12ec9 <wasm[0]::function[1015]::helper::object_read+0x14d69>
 2a12dab:	test   %ecx,%ecx
 2a12dad:	sete   %al
 2a12db0:	cmp    $0x1,%ecx
 2a12db3:	sete   %cl
 2a12db6:	or     %ecx,%eax
 2a12db8:	test   %al,%al
 2a12dba:	jne    2a12ec2 <wasm[0]::function[1015]::helper::object_read+0x14d62>
 2a12dc0:	xor    %r9d,%r9d
 2a12dc3:	test   %edi,%edi
 2a12dc5:	je     2a12e17 <wasm[0]::function[1015]::helper::object_read+0x14cb7>
 2a12dcb:	xor    %r9d,%r9d
 2a12dce:	test   $0x1,%edi
 2a12dd4:	jne    2a12e17 <wasm[0]::function[1015]::helper::object_read+0x14cb7>
 2a12dda:	mov    0x2e0(%rsp),%r14
 2a12de2:	mov    0x28(%r14),%rax
 2a12de6:	mov    0x20(%r14),%rcx
 2a12dea:	mov    %edi,%r9d
 2a12ded:	lea    0x4(%rcx,%r9,1),%rcx
 2a12df2:	xor    %r10,%r10
 2a12df5:	cmp    %rax,%r9
 2a12df8:	cmova  %r10,%rcx
 2a12dfc:	mov    (%rcx),%eax
 2a12dfe:	mov    0x190(%rsp),%rcx
 2a12e06:	mov    0x28(%rcx),%rcx
 2a12e0a:	cmp    0x1d4(%rcx),%eax
 2a12e10:	sete   %al
 2a12e13:	movzbl %al,%r9d
 2a12e17:	test   %r9d,%r9d
 2a12e1a:	jne    2a12e27 <wasm[0]::function[1015]::helper::object_read+0x14cc7>
 2a12e20:	xor    %eax,%eax
 2a12e22:	jmp    2a12eb5 <wasm[0]::function[1015]::helper::object_read+0x14d55>
 2a12e27:	xor    %eax,%eax
 2a12e29:	test   %edi,%edi
 2a12e2b:	je     2a12e7b <wasm[0]::function[1015]::helper::object_read+0x14d1b>
 2a12e31:	xor    %eax,%eax
 2a12e33:	test   $0x1,%edi
 2a12e39:	jne    2a12e7b <wasm[0]::function[1015]::helper::object_read+0x14d1b>
 2a12e3f:	mov    0x2e0(%rsp),%r14
 2a12e47:	mov    0x28(%r14),%rax
 2a12e4b:	mov    0x20(%r14),%rcx
 2a12e4f:	mov    %edi,%r9d
 2a12e52:	lea    0x4(%rcx,%r9,1),%rcx
 2a12e57:	xor    %r10,%r10
 2a12e5a:	cmp    %rax,%r9
 2a12e5d:	cmova  %r10,%rcx
 2a12e61:	mov    (%rcx),%eax
 2a12e63:	mov    0x190(%rsp),%r11
 2a12e6b:	mov    0x28(%r11),%rcx
 2a12e6f:	cmp    0x1d4(%rcx),%eax
 2a12e75:	sete   %al
 2a12e78:	movzbl %al,%eax
 2a12e7b:	test   %eax,%eax
 2a12e7d:	je     2a19924 <wasm[0]::function[1015]::helper::object_read+0x1b7c4>
 2a12e83:	test   %edi,%edi
 2a12e85:	je     2a19926 <wasm[0]::function[1015]::helper::object_read+0x1b7c6>
 2a12e8b:	test   %edi,%edi
 2a12e8d:	je     2a19928 <wasm[0]::function[1015]::helper::object_read+0x1b7c8>
 2a12e93:	mov    0x2e0(%rsp),%r14
 2a12e9b:	mov    0x28(%r14),%rax
 2a12e9f:	mov    %edi,%edi
 2a12ea1:	mov    %rdi,%rcx
 2a12ea4:	add    0x20(%r14),%rcx
 2a12ea8:	xor    %r9,%r9
 2a12eab:	cmp    %rax,%rdi
 2a12eae:	cmova  %r9,%rcx
 2a12eb2:	mov    0x3c(%rcx),%eax
 2a12eb5:	test   %eax,%eax
 2a12eb7:	sete   %al
 2a12eba:	movzbl %al,%ebx
 2a12ebd:	jmp    2a13086 <wasm[0]::function[1015]::helper::object_read+0x14f26>
 2a12ec2:	xor    %ebx,%ebx
 2a12ec4:	jmp    2a13086 <wasm[0]::function[1015]::helper::object_read+0x14f26>
 2a12ec9:	xor    %eax,%eax
 2a12ecb:	test   %edi,%edi
 2a12ecd:	je     2a12f21 <wasm[0]::function[1015]::helper::object_read+0x14dc1>
 2a12ed3:	xor    %eax,%eax
 2a12ed5:	test   $0x1,%edi
 2a12edb:	jne    2a12f21 <wasm[0]::function[1015]::helper::object_read+0x14dc1>
 2a12ee1:	mov    0x2e0(%rsp),%r14
 2a12ee9:	mov    0x28(%r14),%r9
 2a12eed:	mov    0x20(%r14),%r10
 2a12ef1:	mov    %edi,%r11d
 2a12ef4:	lea    0x4(%r10,%r11,1),%r10
 2a12ef9:	xor    %rax,%rax
 2a12efc:	cmp    %r9,%r11
 2a12eff:	cmova  %rax,%r10
 2a12f03:	mov    (%r10),%r9d
 2a12f06:	mov    0x190(%rsp),%rax
 2a12f0e:	mov    0x28(%rax),%r10
 2a12f12:	cmp    0x23c(%r10),%r9d
 2a12f19:	sete   %r9b
 2a12f1d:	movzbl %r9b,%eax
 2a12f21:	test   %eax,%eax
 2a12f23:	je     2a1992a <wasm[0]::function[1015]::helper::object_read+0x1b7ca>
 2a12f29:	test   %edi,%edi
 2a12f2b:	je     2a1992c <wasm[0]::function[1015]::helper::object_read+0x1b7cc>
 2a12f31:	test   %edi,%edi
 2a12f33:	je     2a1992e <wasm[0]::function[1015]::helper::object_read+0x1b7ce>
 2a12f39:	mov    0x2e0(%rsp),%r14
 2a12f41:	mov    0x28(%r14),%rax
 2a12f45:	mov    0x20(%r14),%rcx
 2a12f49:	mov    %edi,%r10d
 2a12f4c:	lea    (%rcx,%r10,1),%r9
 2a12f50:	xor    %rdi,%rdi
 2a12f53:	cmp    %rax,%r10
 2a12f56:	cmova  %rdi,%r9
 2a12f5a:	mov    0x14(%r9),%r9d
 2a12f5e:	test   %r9d,%r9d
 2a12f61:	je     2a19930 <wasm[0]::function[1015]::helper::object_read+0x1b7d0>
 2a12f67:	test   %r9d,%r9d
 2a12f6a:	je     2a19932 <wasm[0]::function[1015]::helper::object_read+0x1b7d2>
 2a12f70:	mov    %r9d,%r9d
 2a12f73:	lea    0x10(%rcx,%r9,1),%rcx
 2a12f78:	cmp    %rax,%r9
 2a12f7b:	cmova  %rdi,%rcx
 2a12f7f:	mov    (%rcx),%eax
 2a12f81:	test   %eax,%eax
 2a12f83:	setne  %al
 2a12f86:	movzbl %al,%ebx
 2a12f89:	jmp    2a13086 <wasm[0]::function[1015]::helper::object_read+0x14f26>
 2a12f8e:	mov    0x1d8(%rsp),%rcx
 2a12f96:	movq   %rcx,%xmm0
 2a12f9b:	ucomisd 0x6c6d(%rip),%xmm0        # 2a19c10 <wasm[0]::function[1015]::helper::object_read+0x1bab0>
 2a12fa3:	setnp  %al
 2a12fa6:	sete   %cl
 2a12fa9:	and    %ecx,%eax
 2a12fab:	ucomisd %xmm0,%xmm0
 2a12faf:	setp   %cl
 2a12fb2:	setne  %dil
 2a12fb6:	or     %edi,%ecx
 2a12fb8:	or     %ecx,%eax
 2a12fba:	movzbl %al,%eax
 2a12fbd:	test   %eax,%eax
 2a12fbf:	sete   %al
 2a12fc2:	movzbl %al,%ebx
 2a12fc5:	jmp    2a13086 <wasm[0]::function[1015]::helper::object_read+0x14f26>
 2a12fca:	xor    %eax,%eax
 2a12fcc:	test   %edi,%edi
 2a12fce:	je     2a1301e <wasm[0]::function[1015]::helper::object_read+0x14ebe>
 2a12fd4:	xor    %eax,%eax
 2a12fd6:	test   $0x1,%edi
 2a12fdc:	jne    2a1301e <wasm[0]::function[1015]::helper::object_read+0x14ebe>
 2a12fe2:	mov    0x2e0(%rsp),%r14
 2a12fea:	mov    0x28(%r14),%rax
 2a12fee:	mov    0x20(%r14),%rcx
 2a12ff2:	mov    %edi,%r9d
 2a12ff5:	lea    0x4(%rcx,%r9,1),%rcx
 2a12ffa:	xor    %r10,%r10
 2a12ffd:	cmp    %rax,%r9
 2a13000:	cmova  %r10,%rcx
 2a13004:	mov    (%rcx),%eax
 2a13006:	mov    0x190(%rsp),%r9
 2a1300e:	mov    0x28(%r9),%rcx
 2a13012:	cmp    0x234(%rcx),%eax
 2a13018:	sete   %al
 2a1301b:	movzbl %al,%eax
 2a1301e:	test   %eax,%eax
 2a13020:	je     2a19934 <wasm[0]::function[1015]::helper::object_read+0x1b7d4>
 2a13026:	test   %edi,%edi
 2a13028:	je     2a19936 <wasm[0]::function[1015]::helper::object_read+0x1b7d6>
 2a1302e:	test   %edi,%edi
 2a13030:	je     2a19938 <wasm[0]::function[1015]::helper::object_read+0x1b7d8>
 2a13036:	mov    0x2e0(%rsp),%r14
 2a1303e:	mov    0x28(%r14),%rax
 2a13042:	mov    0x20(%r14),%rcx
 2a13046:	mov    %edi,%r10d
 2a13049:	lea    (%rcx,%r10,1),%r9
 2a1304d:	xor    %rdi,%rdi
 2a13050:	cmp    %rax,%r10
 2a13053:	cmova  %rdi,%r9
 2a13057:	mov    0x10(%r9),%r9d
 2a1305b:	test   %r9d,%r9d
 2a1305e:	je     2a1993a <wasm[0]::function[1015]::helper::object_read+0x1b7da>
 2a13064:	test   %r9d,%r9d
 2a13067:	je     2a1993c <wasm[0]::function[1015]::helper::object_read+0x1b7dc>
 2a1306d:	mov    %r9d,%r9d
 2a13070:	lea    0x10(%rcx,%r9,1),%rcx
 2a13075:	cmp    %rax,%r9
 2a13078:	cmova  %rdi,%rcx
 2a1307c:	mov    (%rcx),%eax
 2a1307e:	test   %eax,%eax
 2a13080:	setne  %al
 2a13083:	movzbl %al,%ebx
 2a13086:	mov    0x1e0(%rsp),%r11
 2a1308e:	jmp    2a130ac <wasm[0]::function[1015]::helper::object_read+0x14f4c>
 2a13093:	mov    0x1d8(%rsp),%rcx
 2a1309b:	test   %rcx,%rcx
 2a1309e:	setne  %al
 2a130a1:	movzbl %al,%ebx
 2a130a4:	mov    0x1e0(%rsp),%r11
 2a130ac:	cmp    $0x2,%r11d
 2a130b0:	je     2a133ca <wasm[0]::function[1015]::helper::object_read+0x1526a>
 2a130b6:	cmp    $0x4,%r11d
 2a130ba:	je     2a13302 <wasm[0]::function[1015]::helper::object_read+0x151a2>
 2a130c0:	cmp    $0x3,%r11d
 2a130c4:	je     2a132c4 <wasm[0]::function[1015]::helper::object_read+0x15164>
 2a130ca:	cmp    $0xa,%r11d
 2a130ce:	je     2a131fe <wasm[0]::function[1015]::helper::object_read+0x1509e>
 2a130d4:	test   %r11d,%r11d
 2a130d7:	sete   %al
 2a130da:	cmp    $0x1,%r11d
 2a130de:	sete   %dil
 2a130e2:	or     %edi,%eax
 2a130e4:	test   %al,%al
 2a130e6:	jne    2a131f6 <wasm[0]::function[1015]::helper::object_read+0x15096>
 2a130ec:	xor    %eax,%eax
 2a130ee:	test   %r13d,%r13d
 2a130f1:	je     2a13143 <wasm[0]::function[1015]::helper::object_read+0x14fe3>
 2a130f7:	xor    %eax,%eax
 2a130f9:	test   $0x1,%r13d
 2a13100:	jne    2a13143 <wasm[0]::function[1015]::helper::object_read+0x14fe3>
 2a13106:	mov    0x2e0(%rsp),%r14
 2a1310e:	mov    0x28(%r14),%r11
 2a13112:	mov    0x20(%r14),%rcx
 2a13116:	mov    %r13d,%eax
 2a13119:	lea    0x4(%rcx,%rax,1),%r9
 2a1311e:	xor    %rcx,%rcx
 2a13121:	cmp    %r11,%rax
 2a13124:	cmova  %rcx,%r9
 2a13128:	mov    (%r9),%eax
 2a1312b:	mov    0x190(%rsp),%rcx
 2a13133:	mov    0x28(%rcx),%rcx
 2a13137:	cmp    0x1d4(%rcx),%eax
 2a1313d:	sete   %al
 2a13140:	movzbl %al,%eax
 2a13143:	test   %eax,%eax
 2a13145:	jne    2a13153 <wasm[0]::function[1015]::helper::object_read+0x14ff3>
 2a1314b:	xor    %r10d,%r10d
 2a1314e:	jmp    2a131e7 <wasm[0]::function[1015]::helper::object_read+0x15087>
 2a13153:	xor    %eax,%eax
 2a13155:	test   %r13d,%r13d
 2a13158:	je     2a131a9 <wasm[0]::function[1015]::helper::object_read+0x15049>
 2a1315e:	xor    %eax,%eax
 2a13160:	test   $0x1,%r13d
 2a13167:	jne    2a131a9 <wasm[0]::function[1015]::helper::object_read+0x15049>
 2a1316d:	mov    0x2e0(%rsp),%r14
 2a13175:	mov    0x28(%r14),%rax
 2a13179:	mov    0x20(%r14),%rcx
 2a1317d:	mov    %r13d,%edi
 2a13180:	lea    0x4(%rcx,%rdi,1),%rcx
 2a13185:	xor    %r9,%r9
 2a13188:	cmp    %rax,%rdi
 2a1318b:	cmova  %r9,%rcx
 2a1318f:	mov    (%rcx),%eax
 2a13191:	mov    0x190(%rsp),%rcx
 2a13199:	mov    0x28(%rcx),%rcx
 2a1319d:	cmp    0x1d4(%rcx),%eax
 2a131a3:	sete   %al
 2a131a6:	movzbl %al,%eax
 2a131a9:	test   %eax,%eax
 2a131ab:	je     2a1993e <wasm[0]::function[1015]::helper::object_read+0x1b7de>
 2a131b1:	test   %r13d,%r13d
 2a131b4:	je     2a19940 <wasm[0]::function[1015]::helper::object_read+0x1b7e0>
 2a131ba:	test   %r13d,%r13d
 2a131bd:	je     2a19942 <wasm[0]::function[1015]::helper::object_read+0x1b7e2>
 2a131c3:	mov    0x2e0(%rsp),%r14
 2a131cb:	mov    0x28(%r14),%rax
 2a131cf:	mov    %r13d,%edi
 2a131d2:	mov    %rdi,%rcx
 2a131d5:	add    0x20(%r14),%rcx
 2a131d9:	xor    %r9,%r9
 2a131dc:	cmp    %rax,%rdi
 2a131df:	cmova  %r9,%rcx
 2a131e3:	mov    0x3c(%rcx),%r10d
 2a131e7:	test   %r10d,%r10d
 2a131ea:	sete   %al
 2a131ed:	movzbl %al,%r12d
 2a131f1:	jmp    2a133dc <wasm[0]::function[1015]::helper::object_read+0x1527c>
 2a131f6:	xor    %r12d,%r12d
 2a131f9:	jmp    2a133dc <wasm[0]::function[1015]::helper::object_read+0x1527c>
 2a131fe:	xor    %eax,%eax
 2a13200:	test   %r13d,%r13d
 2a13203:	je     2a13254 <wasm[0]::function[1015]::helper::object_read+0x150f4>
 2a13209:	xor    %eax,%eax
 2a1320b:	test   $0x1,%r13d
 2a13212:	jne    2a13254 <wasm[0]::function[1015]::helper::object_read+0x150f4>
 2a13218:	mov    0x2e0(%rsp),%r14
 2a13220:	mov    0x28(%r14),%rax
 2a13224:	mov    0x20(%r14),%rcx
 2a13228:	mov    %r13d,%edi
 2a1322b:	lea    0x4(%rcx,%rdi,1),%rcx
 2a13230:	xor    %r9,%r9
 2a13233:	cmp    %rax,%rdi
 2a13236:	cmova  %r9,%rcx
 2a1323a:	mov    (%rcx),%eax
 2a1323c:	mov    0x190(%rsp),%rcx
 2a13244:	mov    0x28(%rcx),%rcx
 2a13248:	cmp    0x23c(%rcx),%eax
 2a1324e:	sete   %al
 2a13251:	movzbl %al,%eax
 2a13254:	test   %eax,%eax
 2a13256:	je     2a19944 <wasm[0]::function[1015]::helper::object_read+0x1b7e4>
 2a1325c:	test   %r13d,%r13d
 2a1325f:	je     2a19946 <wasm[0]::function[1015]::helper::object_read+0x1b7e6>
 2a13265:	test   %r13d,%r13d
 2a13268:	je     2a19948 <wasm[0]::function[1015]::helper::object_read+0x1b7e8>
 2a1326e:	mov    0x2e0(%rsp),%r14
 2a13276:	mov    0x28(%r14),%rax
 2a1327a:	mov    0x20(%r14),%rcx
 2a1327e:	mov    %r13d,%r10d
 2a13281:	lea    (%rcx,%r10,1),%r9
 2a13285:	xor    %rdi,%rdi
 2a13288:	cmp    %rax,%r10
 2a1328b:	cmova  %rdi,%r9
 2a1328f:	mov    0x14(%r9),%r9d
 2a13293:	test   %r9d,%r9d
 2a13296:	je     2a1994a <wasm[0]::function[1015]::helper::object_read+0x1b7ea>
 2a1329c:	test   %r9d,%r9d
 2a1329f:	je     2a1994c <wasm[0]::function[1015]::helper::object_read+0x1b7ec>
 2a132a5:	mov    %r9d,%r9d
 2a132a8:	lea    0x10(%rcx,%r9,1),%rcx
 2a132ad:	cmp    %rax,%r9
 2a132b0:	cmova  %rdi,%rcx
 2a132b4:	mov    (%rcx),%eax
 2a132b6:	test   %eax,%eax
 2a132b8:	setne  %al
 2a132bb:	movzbl %al,%r12d
 2a132bf:	jmp    2a133dc <wasm[0]::function[1015]::helper::object_read+0x1527c>
 2a132c4:	mov    0x1e8(%rsp),%r10
 2a132cc:	movq   %r10,%xmm0
 2a132d1:	ucomisd 0x6947(%rip),%xmm0        # 2a19c20 <wasm[0]::function[1015]::helper::object_read+0x1bac0>
 2a132d9:	setnp  %al
 2a132dc:	sete   %cl
 2a132df:	and    %ecx,%eax
 2a132e1:	ucomisd %xmm0,%xmm0
 2a132e5:	setp   %cl
 2a132e8:	setne  %dil
 2a132ec:	or     %edi,%ecx
 2a132ee:	or     %ecx,%eax
 2a132f0:	movzbl %al,%ecx
 2a132f3:	test   %ecx,%ecx
 2a132f5:	sete   %dil
 2a132f9:	movzbl %dil,%r12d
 2a132fd:	jmp    2a133dc <wasm[0]::function[1015]::helper::object_read+0x1527c>
 2a13302:	xor    %eax,%eax
 2a13304:	test   %r13d,%r13d
 2a13307:	je     2a1335a <wasm[0]::function[1015]::helper::object_read+0x151fa>
 2a1330d:	xor    %eax,%eax
 2a1330f:	test   $0x1,%r13d
 2a13316:	jne    2a1335a <wasm[0]::function[1015]::helper::object_read+0x151fa>
 2a1331c:	mov    0x2e0(%rsp),%r14
 2a13324:	mov    0x28(%r14),%r10
 2a13328:	mov    0x20(%r14),%rax
 2a1332c:	mov    %r13d,%r11d
 2a1332f:	lea    0x4(%rax,%r11,1),%rdi
 2a13334:	xor    %rax,%rax
 2a13337:	cmp    %r10,%r11
 2a1333a:	cmova  %rax,%rdi
 2a1333e:	mov    (%rdi),%r11d
 2a13341:	mov    0x190(%rsp),%rax
 2a13349:	mov    0x28(%rax),%rax
 2a1334d:	cmp    0x234(%rax),%r11d
 2a13354:	sete   %al
 2a13357:	movzbl %al,%eax
 2a1335a:	test   %eax,%eax
 2a1335c:	je     2a1994e <wasm[0]::function[1015]::helper::object_read+0x1b7ee>
 2a13362:	test   %r13d,%r13d
 2a13365:	je     2a19950 <wasm[0]::function[1015]::helper::object_read+0x1b7f0>
 2a1336b:	test   %r13d,%r13d
 2a1336e:	je     2a19952 <wasm[0]::function[1015]::helper::object_read+0x1b7f2>
 2a13374:	mov    0x2e0(%rsp),%r14
 2a1337c:	mov    0x28(%r14),%rax
 2a13380:	mov    0x20(%r14),%rcx
 2a13384:	mov    %r13d,%r10d
 2a13387:	lea    (%rcx,%r10,1),%r9
 2a1338b:	xor    %rdi,%rdi
 2a1338e:	cmp    %rax,%r10
 2a13391:	cmova  %rdi,%r9
 2a13395:	mov    0x10(%r9),%r9d
 2a13399:	test   %r9d,%r9d
 2a1339c:	je     2a19954 <wasm[0]::function[1015]::helper::object_read+0x1b7f4>
 2a133a2:	test   %r9d,%r9d
 2a133a5:	je     2a19956 <wasm[0]::function[1015]::helper::object_read+0x1b7f6>
 2a133ab:	mov    %r9d,%r9d
 2a133ae:	lea    0x10(%rcx,%r9,1),%rcx
 2a133b3:	cmp    %rax,%r9
 2a133b6:	cmova  %rdi,%rcx
 2a133ba:	mov    (%rcx),%eax
 2a133bc:	test   %eax,%eax
 2a133be:	setne  %al
 2a133c1:	movzbl %al,%r12d
 2a133c5:	jmp    2a133dc <wasm[0]::function[1015]::helper::object_read+0x1527c>
 2a133ca:	mov    0x1e8(%rsp),%r10
 2a133d2:	test   %r10,%r10
 2a133d5:	setne  %al
 2a133d8:	movzbl %al,%r12d
 2a133dc:	cmp    $0x2,%esi
 2a133df:	je     2a136d0 <wasm[0]::function[1015]::helper::object_read+0x15570>
 2a133e5:	cmp    $0x4,%esi
 2a133e8:	je     2a1360c <wasm[0]::function[1015]::helper::object_read+0x154ac>
 2a133ee:	cmp    $0x3,%esi
 2a133f1:	je     2a135d8 <wasm[0]::function[1015]::helper::object_read+0x15478>
 2a133f7:	cmp    $0xa,%esi
 2a133fa:	je     2a1351c <wasm[0]::function[1015]::helper::object_read+0x153bc>
 2a13400:	test   %esi,%esi
 2a13402:	sete   %al
 2a13405:	cmp    $0x1,%esi
 2a13408:	sete   %cl
 2a1340b:	or     %ecx,%eax
 2a1340d:	test   %al,%al
 2a1340f:	jne    2a13514 <wasm[0]::function[1015]::helper::object_read+0x153b4>
 2a13415:	xor    %eax,%eax
 2a13417:	test   %edx,%edx
 2a13419:	je     2a13468 <wasm[0]::function[1015]::helper::object_read+0x15308>
 2a1341f:	xor    %eax,%eax
 2a13421:	test   $0x1,%edx
 2a13427:	jne    2a13468 <wasm[0]::function[1015]::helper::object_read+0x15308>
 2a1342d:	mov    0x2e0(%rsp),%r14
 2a13435:	mov    0x28(%r14),%rax
 2a13439:	mov    0x20(%r14),%rcx
 2a1343d:	mov    %edx,%esi
 2a1343f:	lea    0x4(%rcx,%rsi,1),%rcx
 2a13444:	xor    %rdi,%rdi
 2a13447:	cmp    %rax,%rsi
 2a1344a:	cmova  %rdi,%rcx
 2a1344e:	mov    (%rcx),%eax
 2a13450:	mov    0x190(%rsp),%rsi
 2a13458:	mov    0x28(%rsi),%rcx
 2a1345c:	cmp    0x1d4(%rcx),%eax
 2a13462:	sete   %al
 2a13465:	movzbl %al,%eax
 2a13468:	test   %eax,%eax
 2a1346a:	jne    2a13477 <wasm[0]::function[1015]::helper::object_read+0x15317>
 2a13470:	xor    %eax,%eax
 2a13472:	jmp    2a13505 <wasm[0]::function[1015]::helper::object_read+0x153a5>
 2a13477:	xor    %eax,%eax
 2a13479:	test   %edx,%edx
 2a1347b:	je     2a134ca <wasm[0]::function[1015]::helper::object_read+0x1536a>
 2a13481:	xor    %eax,%eax
 2a13483:	test   $0x1,%edx
 2a13489:	jne    2a134ca <wasm[0]::function[1015]::helper::object_read+0x1536a>
 2a1348f:	mov    0x2e0(%rsp),%r14
 2a13497:	mov    0x28(%r14),%rax
 2a1349b:	mov    0x20(%r14),%rcx
 2a1349f:	mov    %edx,%esi
 2a134a1:	lea    0x4(%rcx,%rsi,1),%rcx
 2a134a6:	xor    %rdi,%rdi
 2a134a9:	cmp    %rax,%rsi
 2a134ac:	cmova  %rdi,%rcx
 2a134b0:	mov    (%rcx),%eax
 2a134b2:	mov    0x190(%rsp),%rsi
 2a134ba:	mov    0x28(%rsi),%rcx
 2a134be:	cmp    0x1d4(%rcx),%eax
 2a134c4:	sete   %al
 2a134c7:	movzbl %al,%eax
 2a134ca:	test   %eax,%eax
 2a134cc:	je     2a19958 <wasm[0]::function[1015]::helper::object_read+0x1b7f8>
 2a134d2:	test   %edx,%edx
 2a134d4:	je     2a1995a <wasm[0]::function[1015]::helper::object_read+0x1b7fa>
 2a134da:	test   %edx,%edx
 2a134dc:	je     2a1995c <wasm[0]::function[1015]::helper::object_read+0x1b7fc>
 2a134e2:	mov    0x2e0(%rsp),%r14
 2a134ea:	mov    0x28(%r14),%rsi
 2a134ee:	mov    %edx,%r8d
 2a134f1:	mov    %r8,%rdi
 2a134f4:	add    0x20(%r14),%rdi
 2a134f8:	xor    %r9,%r9
 2a134fb:	cmp    %rsi,%r8
 2a134fe:	cmova  %r9,%rdi
 2a13502:	mov    0x3c(%rdi),%eax
 2a13505:	test   %eax,%eax
 2a13507:	sete   %r9b
 2a1350b:	movzbl %r9b,%r13d
 2a1350f:	jmp    2a136c3 <wasm[0]::function[1015]::helper::object_read+0x15563>
 2a13514:	xor    %r13d,%r13d
 2a13517:	jmp    2a136c3 <wasm[0]::function[1015]::helper::object_read+0x15563>
 2a1351c:	xor    %eax,%eax
 2a1351e:	test   %edx,%edx
 2a13520:	je     2a1356f <wasm[0]::function[1015]::helper::object_read+0x1540f>
 2a13526:	xor    %eax,%eax
 2a13528:	test   $0x1,%edx
 2a1352e:	jne    2a1356f <wasm[0]::function[1015]::helper::object_read+0x1540f>
 2a13534:	mov    0x2e0(%rsp),%r14
 2a1353c:	mov    0x28(%r14),%rax
 2a13540:	mov    0x20(%r14),%rcx
 2a13544:	mov    %edx,%esi
 2a13546:	lea    0x4(%rcx,%rsi,1),%rcx
 2a1354b:	xor    %rdi,%rdi
 2a1354e:	cmp    %rax,%rsi
 2a13551:	cmova  %rdi,%rcx
 2a13555:	mov    (%rcx),%eax
 2a13557:	mov    0x190(%rsp),%rsi
 2a1355f:	mov    0x28(%rsi),%rcx
 2a13563:	cmp    0x23c(%rcx),%eax
 2a13569:	sete   %al
 2a1356c:	movzbl %al,%eax
 2a1356f:	test   %eax,%eax
 2a13571:	je     2a1995e <wasm[0]::function[1015]::helper::object_read+0x1b7fe>
 2a13577:	test   %edx,%edx
 2a13579:	je     2a19960 <wasm[0]::function[1015]::helper::object_read+0x1b800>
 2a1357f:	test   %edx,%edx
 2a13581:	je     2a19962 <wasm[0]::function[1015]::helper::object_read+0x1b802>
 2a13587:	mov    0x2e0(%rsp),%r14
 2a1358f:	mov    0x28(%r14),%rax
 2a13593:	mov    0x20(%r14),%rcx
 2a13597:	mov    %edx,%edi
 2a13599:	lea    (%rcx,%rdi,1),%rsi
 2a1359d:	xor    %rdx,%rdx
 2a135a0:	cmp    %rax,%rdi
 2a135a3:	cmova  %rdx,%rsi
 2a135a7:	mov    0x14(%rsi),%esi
 2a135aa:	test   %esi,%esi
 2a135ac:	je     2a19964 <wasm[0]::function[1015]::helper::object_read+0x1b804>
 2a135b2:	test   %esi,%esi
 2a135b4:	je     2a19966 <wasm[0]::function[1015]::helper::object_read+0x1b806>
 2a135ba:	mov    %esi,%esi
 2a135bc:	lea    0x10(%rcx,%rsi,1),%rcx
 2a135c1:	cmp    %rax,%rsi
 2a135c4:	cmova  %rdx,%rcx
 2a135c8:	mov    (%rcx),%eax
 2a135ca:	test   %eax,%eax
 2a135cc:	setne  %al
 2a135cf:	movzbl %al,%r13d
 2a135d3:	jmp    2a136c3 <wasm[0]::function[1015]::helper::object_read+0x15563>
 2a135d8:	movq   %r8,%xmm0
 2a135dd:	ucomisd 0x664b(%rip),%xmm0        # 2a19c30 <wasm[0]::function[1015]::helper::object_read+0x1bad0>
 2a135e5:	setnp  %al
 2a135e8:	sete   %cl
 2a135eb:	and    %ecx,%eax
 2a135ed:	ucomisd %xmm0,%xmm0
 2a135f1:	setp   %cl
 2a135f4:	setne  %dl
 2a135f7:	or     %edx,%ecx
 2a135f9:	or     %ecx,%eax
 2a135fb:	movzbl %al,%eax
 2a135fe:	test   %eax,%eax
 2a13600:	sete   %al
 2a13603:	movzbl %al,%r13d
 2a13607:	jmp    2a136c3 <wasm[0]::function[1015]::helper::object_read+0x15563>
 2a1360c:	xor    %eax,%eax
 2a1360e:	test   %edx,%edx
 2a13610:	je     2a1365f <wasm[0]::function[1015]::helper::object_read+0x154ff>
 2a13616:	xor    %eax,%eax
 2a13618:	test   $0x1,%edx
 2a1361e:	jne    2a1365f <wasm[0]::function[1015]::helper::object_read+0x154ff>
 2a13624:	mov    0x2e0(%rsp),%r14
 2a1362c:	mov    0x28(%r14),%rax
 2a13630:	mov    0x20(%r14),%rcx
 2a13634:	mov    %edx,%esi
 2a13636:	lea    0x4(%rcx,%rsi,1),%rcx
 2a1363b:	xor    %rdi,%rdi
 2a1363e:	cmp    %rax,%rsi
 2a13641:	cmova  %rdi,%rcx
 2a13645:	mov    (%rcx),%eax
 2a13647:	mov    0x190(%rsp),%rsi
 2a1364f:	mov    0x28(%rsi),%rcx
 2a13653:	cmp    0x234(%rcx),%eax
 2a13659:	sete   %al
 2a1365c:	movzbl %al,%eax
 2a1365f:	test   %eax,%eax
 2a13661:	je     2a19968 <wasm[0]::function[1015]::helper::object_read+0x1b808>
 2a13667:	test   %edx,%edx
 2a13669:	je     2a1996a <wasm[0]::function[1015]::helper::object_read+0x1b80a>
 2a1366f:	test   %edx,%edx
 2a13671:	je     2a1996c <wasm[0]::function[1015]::helper::object_read+0x1b80c>
 2a13677:	mov    0x2e0(%rsp),%r14
 2a1367f:	mov    0x28(%r14),%rax
 2a13683:	mov    0x20(%r14),%rcx
 2a13687:	mov    %edx,%edi
 2a13689:	lea    (%rcx,%rdi,1),%rsi
 2a1368d:	xor    %rdx,%rdx
 2a13690:	cmp    %rax,%rdi
 2a13693:	cmova  %rdx,%rsi
 2a13697:	mov    0x10(%rsi),%esi
 2a1369a:	test   %esi,%esi
 2a1369c:	je     2a1996e <wasm[0]::function[1015]::helper::object_read+0x1b80e>
 2a136a2:	test   %esi,%esi
 2a136a4:	je     2a19970 <wasm[0]::function[1015]::helper::object_read+0x1b810>
 2a136aa:	mov    %esi,%esi
 2a136ac:	lea    0x10(%rcx,%rsi,1),%rcx
 2a136b1:	cmp    %rax,%rsi
 2a136b4:	cmova  %rdx,%rcx
 2a136b8:	mov    (%rcx),%eax
 2a136ba:	test   %eax,%eax
 2a136bc:	setne  %al
 2a136bf:	movzbl %al,%r13d
 2a136c3:	mov    0x268(%rsp),%rcx
 2a136cb:	jmp    2a136e3 <wasm[0]::function[1015]::helper::object_read+0x15583>
 2a136d0:	test   %r8,%r8
 2a136d3:	setne  %sil
 2a136d7:	movzbl %sil,%r13d
 2a136db:	mov    0x268(%rsp),%rcx
 2a136e3:	mov    0x268(%rsp),%rcx
 2a136eb:	mov    (%rcx),%eax
 2a136ed:	mov    %eax,%esi
 2a136ef:	lea    0x20(%rsi),%rdi
 2a136f3:	mov    0x4(%rcx),%r8d
 2a136f7:	cmp    %r8,%rdi
 2a136fa:	ja     2a187f0 <wasm[0]::function[1015]::helper::object_read+0x1a690>
 2a13700:	lea    0x20(%rax),%edi
 2a13703:	mov    0x268(%rsp),%rcx
 2a1370b:	mov    %edi,(%rcx)
 2a1370d:	mov    0x2e0(%rsp),%r14
 2a13715:	mov    0x20(%r14),%r8
 2a13719:	lea    (%r8,%rsi,1),%rcx
 2a1371d:	movl   $0xb0000042,(%r8,%rsi,1)
 2a13725:	mov    0x190(%rsp),%rdx
 2a1372d:	mov    0x28(%rdx),%r9
 2a13731:	mov    0x120(%r9),%r9d
 2a13738:	mov    %r9d,0x4(%r8,%rsi,1)
 2a1373d:	mov    0x260(%rsp),%rdx
 2a13745:	mov    %edx,0x8(%r8,%rsi,1)
 2a1374a:	mov    %eax,0xb0(%rsp)
 2a13751:	mov    0x1f0(%rsp),%rdi
 2a13759:	mov    %rdi,0x10(%rcx)
 2a1375d:	mov    0x1f8(%rsp),%rsi
 2a13765:	mov    %esi,0x18(%rcx)
 2a13768:	mov    0xa8(%rsp),%eax
 2a1376f:	mov    %eax,0x1c(%rcx)
 2a13772:	mov    0x268(%rsp),%rcx
 2a1377a:	mov    (%rcx),%eax
 2a1377c:	mov    %eax,%edx
 2a1377e:	lea    0x20(%rdx),%rcx
 2a13782:	mov    0x268(%rsp),%rsi
 2a1378a:	mov    0x4(%rsi),%esi
 2a1378d:	cmp    %rsi,%rcx
 2a13790:	ja     2a18832 <wasm[0]::function[1015]::helper::object_read+0x1a6d2>
 2a13796:	lea    0x20(%rax),%ecx
 2a13799:	mov    0x268(%rsp),%rsi
 2a137a1:	mov    %ecx,(%rsi)
 2a137a3:	mov    0x2e0(%rsp),%r14
 2a137ab:	mov    0x20(%r14),%rsi
 2a137af:	lea    (%rsi,%rdx,1),%rcx
 2a137b3:	movl   $0xb0000042,(%rsi,%rdx,1)
 2a137ba:	mov    0x190(%rsp),%rdi
 2a137c2:	mov    0x28(%rdi),%rdi
 2a137c6:	mov    0x120(%rdi),%edi
 2a137cc:	mov    %edi,0x4(%rsi,%rdx,1)
 2a137d0:	mov    0x260(%rsp),%rdi
 2a137d8:	mov    %edi,0x8(%rsi,%rdx,1)
 2a137dc:	mov    %eax,0xa8(%rsp)
 2a137e3:	mov    0x200(%rsp),%rax
 2a137eb:	mov    %rax,0x10(%rcx)
 2a137ef:	mov    0x208(%rsp),%rax
 2a137f7:	mov    %eax,0x18(%rcx)
 2a137fa:	mov    0xc8(%rsp),%eax
 2a13801:	mov    %eax,0x1c(%rcx)
 2a13804:	mov    0x268(%rsp),%rcx
 2a1380c:	mov    (%rcx),%eax
 2a1380e:	mov    %eax,%edx
 2a13810:	lea    0x20(%rdx),%rcx
 2a13814:	mov    0x268(%rsp),%rsi
 2a1381c:	mov    0x4(%rsi),%esi
 2a1381f:	cmp    %rsi,%rcx
 2a13822:	ja     2a18874 <wasm[0]::function[1015]::helper::object_read+0x1a714>
 2a13828:	lea    0x20(%rax),%ecx
 2a1382b:	mov    0x268(%rsp),%rsi
 2a13833:	mov    %ecx,(%rsi)
 2a13835:	mov    0x2e0(%rsp),%r14
 2a1383d:	mov    0x20(%r14),%rsi
 2a13841:	lea    (%rsi,%rdx,1),%rcx
 2a13845:	movl   $0xb0000042,(%rsi,%rdx,1)
 2a1384c:	mov    0x190(%rsp),%rdi
 2a13854:	mov    0x28(%rdi),%rdi
 2a13858:	mov    0x120(%rdi),%edi
 2a1385e:	mov    %edi,0x4(%rsi,%rdx,1)
 2a13862:	mov    0x260(%rsp),%rdi
 2a1386a:	mov    %edi,0x8(%rsi,%rdx,1)
 2a1386e:	mov    %eax,0xc8(%rsp)
 2a13875:	mov    0x210(%rsp),%r10
 2a1387d:	mov    %r10,0x10(%rcx)
 2a13881:	mov    0x218(%rsp),%rdx
 2a13889:	mov    %edx,0x18(%rcx)
 2a1388c:	mov    0xb8(%rsp),%edx
 2a13893:	mov    %edx,0x1c(%rcx)
 2a13896:	mov    0x220(%rsp),%rcx
 2a1389e:	mov    0x220(%rsp),%rdx
 2a138a6:	test   %edx,%ecx
 2a138a8:	jne    2a13994 <wasm[0]::function[1015]::helper::object_read+0x15834>
 2a138ae:	mov    0xb0(%rsp),%ecx
 2a138b5:	test   %ecx,%ecx
 2a138b7:	je     2a19972 <wasm[0]::function[1015]::helper::object_read+0x1b812>
 2a138bd:	mov    0xa8(%rsp),%ecx
 2a138c4:	test   %ecx,%ecx
 2a138c6:	je     2a19974 <wasm[0]::function[1015]::helper::object_read+0x1b814>
 2a138cc:	test   %eax,%eax
 2a138ce:	je     2a19976 <wasm[0]::function[1015]::helper::object_read+0x1b816>
 2a138d4:	mov    0x268(%rsp),%rcx
 2a138dc:	mov    (%rcx),%eax
 2a138de:	mov    %rax,%r15
 2a138e1:	mov    %eax,%ecx
 2a138e3:	lea    0x20(%rcx),%rax
 2a138e7:	mov    0x268(%rsp),%rdx
 2a138ef:	mov    0x4(%rdx),%edx
 2a138f2:	cmp    %rdx,%rax
 2a138f5:	ja     2a188b6 <wasm[0]::function[1015]::helper::object_read+0x1a756>
 2a138fb:	mov    %r15,%rax
 2a138fe:	add    $0x20,%eax
 2a13904:	mov    0x268(%rsp),%rdx
 2a1390c:	mov    %eax,(%rdx)
 2a1390e:	mov    0x2e0(%rsp),%r14
 2a13916:	mov    0x20(%r14),%rdx
 2a1391a:	lea    (%rdx,%rcx,1),%rax
 2a1391e:	movl   $0xb0000072,(%rdx,%rcx,1)
 2a13925:	mov    0x190(%rsp),%rsi
 2a1392d:	mov    0x28(%rsi),%rsi
 2a13931:	mov    0x13c(%rsi),%esi
 2a13937:	mov    %esi,0x4(%rdx,%rcx,1)
 2a1393b:	mov    0x260(%rsp),%r8
 2a13943:	mov    %r8d,0x8(%rdx,%rcx,1)
 2a13948:	test   %ebx,%ebx
 2a1394a:	setne  %cl
 2a1394d:	movzbl %cl,%ecx
 2a13950:	shl    $0x2,%ecx
 2a13953:	test   %r12d,%r12d
 2a13956:	setne  %dl
 2a13959:	movzbl %dl,%edx
 2a1395c:	shl    $0x3,%edx
 2a1395f:	or     %edx,%ecx
 2a13961:	test   %r13d,%r13d
 2a13964:	setne  %dl
 2a13967:	movzbl %dl,%edx
 2a1396a:	shl    $1,%edx
 2a1396c:	or     %edx,%ecx
 2a1396e:	mov    %ecx,0x10(%rax)
 2a13971:	mov    0xb0(%rsp),%ecx
 2a13978:	mov    %ecx,0x14(%rax)
 2a1397b:	mov    0xa8(%rsp),%ecx
 2a13982:	mov    %ecx,0x18(%rax)
 2a13985:	mov    0xc8(%rsp),%ecx
 2a1398c:	mov    %ecx,0x1c(%rax)
 2a1398f:	jmp    2a13a6a <wasm[0]::function[1015]::helper::object_read+0x1590a>
 2a13994:	mov    0xb0(%rsp),%ecx
 2a1399b:	test   %ecx,%ecx
 2a1399d:	je     2a19978 <wasm[0]::function[1015]::helper::object_read+0x1b818>
 2a139a3:	mov    0xa8(%rsp),%esi
 2a139aa:	test   %esi,%esi
 2a139ac:	je     2a1997a <wasm[0]::function[1015]::helper::object_read+0x1b81a>
 2a139b2:	test   %eax,%eax
 2a139b4:	je     2a1997c <wasm[0]::function[1015]::helper::object_read+0x1b81c>
 2a139ba:	mov    0x268(%rsp),%rcx
 2a139c2:	mov    (%rcx),%eax
 2a139c4:	mov    %rax,%r15
 2a139c7:	mov    %eax,%edi
 2a139c9:	lea    0x20(%rdi),%r8
 2a139cd:	mov    0x4(%rcx),%r9d
 2a139d1:	cmp    %r9,%r8
 2a139d4:	ja     2a188fb <wasm[0]::function[1015]::helper::object_read+0x1a79b>
 2a139da:	mov    %r15,%rax
 2a139dd:	lea    0x20(%rax),%r10d
 2a139e1:	mov    0x268(%rsp),%rcx
 2a139e9:	mov    %r10d,(%rcx)
 2a139ec:	mov    0x2e0(%rsp),%r14
 2a139f4:	mov    0x20(%r14),%r11
 2a139f8:	lea    (%r11,%rdi,1),%rax
 2a139fc:	movl   $0xb0000072,(%r11,%rdi,1)
 2a13a04:	mov    0x190(%rsp),%rsi
 2a13a0c:	mov    0x28(%rsi),%rcx
 2a13a10:	mov    0x13c(%rcx),%ecx
 2a13a16:	mov    %ecx,0x4(%r11,%rdi,1)
 2a13a1b:	mov    0x260(%rsp),%rcx
 2a13a23:	mov    %ecx,0x8(%r11,%rdi,1)
 2a13a28:	test   %r12d,%r12d
 2a13a2b:	setne  %cl
 2a13a2e:	movzbl %cl,%r10d
 2a13a32:	shl    $0x3,%r10d
 2a13a36:	or     $0x1,%r10d
 2a13a3a:	test   %r13d,%r13d
 2a13a3d:	setne  %cl
 2a13a40:	movzbl %cl,%ecx
 2a13a43:	shl    $1,%ecx
 2a13a45:	or     %ecx,%r10d
 2a13a48:	mov    %r10d,0x10(%rax)
 2a13a4c:	mov    0xb0(%rsp),%ecx
 2a13a53:	mov    %ecx,0x14(%rax)
 2a13a56:	mov    0xa8(%rsp),%ecx
 2a13a5d:	mov    %ecx,0x18(%rax)
 2a13a60:	mov    0xc8(%rsp),%ecx
 2a13a67:	mov    %ecx,0x1c(%rax)
 2a13a6a:	mov    0x88(%rsp),%eax
 2a13a71:	mov    0x90(%rsp),%ecx
 2a13a78:	jmp    2a16337 <wasm[0]::function[1015]::helper::object_read+0x181d7>
 2a13a7d:	mov    0xe0(%rsp),%edx
 2a13a84:	mov    0x250(%rsp),%rax
 2a13a8c:	mov    0x258(%rsp),%rcx
 2a13a94:	mov    0x2f0(%rsp),%rbx
 2a13a9c:	mov    0x2f8(%rsp),%r12
 2a13aa4:	mov    0x300(%rsp),%r13
 2a13aac:	mov    0x308(%rsp),%r14
 2a13ab4:	mov    0x310(%rsp),%r15
 2a13abc:	add    $0x320,%rsp
 2a13ac3:	mov    %rbp,%rsp
 2a13ac6:	pop    %rbp
 2a13ac7:	ret    $0x40
 2a13aca:	xor    %eax,%eax
 2a13acc:	test   %edx,%edx
 2a13ace:	je     2a13b1d <wasm[0]::function[1015]::helper::object_read+0x159bd>
 2a13ad4:	xor    %eax,%eax
 2a13ad6:	test   $0x1,%edx
 2a13adc:	jne    2a13b1d <wasm[0]::function[1015]::helper::object_read+0x159bd>
 2a13ae2:	mov    0x2e0(%rsp),%r14
 2a13aea:	mov    0x28(%r14),%rax
 2a13aee:	mov    0x20(%r14),%rcx
 2a13af2:	mov    %edx,%esi
 2a13af4:	lea    0x4(%rcx,%rsi,1),%rcx
 2a13af9:	xor    %rdi,%rdi
 2a13afc:	cmp    %rax,%rsi
 2a13aff:	cmova  %rdi,%rcx
 2a13b03:	mov    (%rcx),%eax
 2a13b05:	mov    0x190(%rsp),%rsi
 2a13b0d:	mov    0x28(%rsi),%rcx
 2a13b11:	cmp    0x254(%rcx),%eax
 2a13b17:	sete   %al
 2a13b1a:	movzbl %al,%eax
 2a13b1d:	test   %eax,%eax
 2a13b1f:	je     2a1997e <wasm[0]::function[1015]::helper::object_read+0x1b81e>
 2a13b25:	test   %edx,%edx
 2a13b27:	je     2a19980 <wasm[0]::function[1015]::helper::object_read+0x1b820>
 2a13b2d:	test   %edx,%edx
 2a13b2f:	je     2a19982 <wasm[0]::function[1015]::helper::object_read+0x1b822>
 2a13b35:	mov    0x2e0(%rsp),%r14
 2a13b3d:	mov    0x28(%r14),%rax
 2a13b41:	mov    0x20(%r14),%rcx
 2a13b45:	mov    %edx,%edx
 2a13b47:	add    %rdx,%rcx
 2a13b4a:	xor    %rsi,%rsi
 2a13b4d:	cmp    %rax,%rdx
 2a13b50:	cmova  %rsi,%rcx
 2a13b54:	mov    0x10(%rcx),%edx
 2a13b57:	test   %edx,%edx
 2a13b59:	je     2a19984 <wasm[0]::function[1015]::helper::object_read+0x1b824>
 2a13b5f:	mov    0x68(%rsp),%r9d
 2a13b64:	mov    0x1b8(%rsp),%rcx
 2a13b6c:	mov    0x190(%rsp),%rsi
 2a13b74:	mov    0x190(%rsp),%rdi
 2a13b7c:	mov    0x1c0(%rsp),%r8
 2a13b84:	call   2a1cf20 <wasm[0]::function[1019]::helper::ordinary_own_descriptor>
 2a13b89:	mov    0x80(%rsp),%ecx
 2a13b90:	mov    0xa0(%rsp),%r10d
 2a13b98:	mov    %r10,%r15
 2a13b9b:	mov    0x50(%rsp),%edx
 2a13b9f:	test   %eax,%eax
 2a13ba1:	jne    2a15c23 <wasm[0]::function[1015]::helper::object_read+0x17ac3>
 2a13ba7:	mov    0x58(%rsp),%edi
 2a13bab:	mov    0x68(%rsp),%r8d
 2a13bb0:	xor    %r9d,%r9d
 2a13bb3:	mov    0x1b8(%rsp),%rsi
 2a13bbb:	cmp    $0x4,%esi
 2a13bbe:	je     2a13bcc <wasm[0]::function[1015]::helper::object_read+0x15a6c>
 2a13bc4:	mov    %r9,%rsi
 2a13bc7:	jmp    2a13f40 <wasm[0]::function[1015]::helper::object_read+0x15de0>
 2a13bcc:	xor    %esi,%esi
 2a13bce:	test   %r8d,%r8d
 2a13bd1:	je     2a13c26 <wasm[0]::function[1015]::helper::object_read+0x15ac6>
 2a13bd7:	xor    %esi,%esi
 2a13bd9:	test   $0x1,%r8d
 2a13be0:	jne    2a13c26 <wasm[0]::function[1015]::helper::object_read+0x15ac6>
 2a13be6:	mov    0x2e0(%rsp),%r14
 2a13bee:	mov    0x28(%r14),%rsi
 2a13bf2:	mov    0x20(%r14),%r9
 2a13bf6:	mov    %r8d,%r10d
 2a13bf9:	lea    0x4(%r9,%r10,1),%r9
 2a13bfe:	xor    %r11,%r11
 2a13c01:	cmp    %rsi,%r10
 2a13c04:	cmova  %r11,%r9
 2a13c08:	mov    (%r9),%esi
 2a13c0b:	mov    0x190(%rsp),%r9
 2a13c13:	mov    0x28(%r9),%r9
 2a13c17:	cmp    0x234(%r9),%esi
 2a13c1e:	sete   %sil
 2a13c22:	movzbl %sil,%esi
 2a13c26:	test   %esi,%esi
 2a13c28:	je     2a19986 <wasm[0]::function[1015]::helper::object_read+0x1b826>
 2a13c2e:	test   %r8d,%r8d
 2a13c31:	je     2a19988 <wasm[0]::function[1015]::helper::object_read+0x1b828>
 2a13c37:	test   %r8d,%r8d
 2a13c3a:	je     2a1998a <wasm[0]::function[1015]::helper::object_read+0x1b82a>
 2a13c40:	mov    0x2e0(%rsp),%r14
 2a13c48:	mov    0x28(%r14),%rsi
 2a13c4c:	mov    0x20(%r14),%r10
 2a13c50:	mov    %r8d,%ebx
 2a13c53:	lea    (%r10,%rbx,1),%r9
 2a13c57:	xor    %r11,%r11
 2a13c5a:	cmp    %rsi,%rbx
 2a13c5d:	cmova  %r11,%r9
 2a13c61:	mov    0x10(%r9),%ebx
 2a13c65:	mov    %ebx,0xe0(%rsp)
 2a13c6c:	xor    %r9d,%r9d
 2a13c6f:	test   %ebx,%ebx
 2a13c71:	je     2a1998c <wasm[0]::function[1015]::helper::object_read+0x1b82c>
 2a13c77:	test   %ebx,%ebx
 2a13c79:	je     2a1998e <wasm[0]::function[1015]::helper::object_read+0x1b82e>
 2a13c7f:	mov    %ebx,%r12d
 2a13c82:	lea    0x10(%r10,%r12,1),%r10
 2a13c87:	cmp    %rsi,%r12
 2a13c8a:	cmova  %r11,%r10
 2a13c8e:	mov    (%r10),%r12d
 2a13c91:	test   %r12d,%r12d
 2a13c94:	sete   %r10b
 2a13c98:	cmp    $0xa,%r12d
 2a13c9c:	seta   %r11b
 2a13ca0:	or     %r11d,%r10d
 2a13ca3:	test   %r10b,%r10b
 2a13ca6:	je     2a13cb4 <wasm[0]::function[1015]::helper::object_read+0x15b54>
 2a13cac:	mov    %r9,%rsi
 2a13caf:	jmp    2a13f40 <wasm[0]::function[1015]::helper::object_read+0x15de0>
 2a13cb4:	mov    0xe0(%rsp),%ecx
 2a13cbb:	test   %ecx,%ecx
 2a13cbd:	je     2a19990 <wasm[0]::function[1015]::helper::object_read+0x1b830>
 2a13cc3:	test   %ecx,%ecx
 2a13cc5:	je     2a19992 <wasm[0]::function[1015]::helper::object_read+0x1b832>
 2a13ccb:	mov    0x2e0(%rsp),%r14
 2a13cd3:	mov    0x28(%r14),%rdx
 2a13cd7:	mov    0x20(%r14),%rsi
 2a13cdb:	mov    %ecx,%r9d
 2a13cde:	lea    0x10(%rsi,%r9,1),%r8
 2a13ce3:	xor    %rdi,%rdi
 2a13ce6:	cmp    %rdx,%r9
 2a13ce9:	cmova  %rdi,%r8
 2a13ced:	mov    (%r8),%r8d
 2a13cf0:	test   %r8d,%r8d
 2a13cf3:	je     2a19994 <wasm[0]::function[1015]::helper::object_read+0x1b834>
 2a13cf9:	mov    %r8d,%r9d
 2a13cfc:	shl    $1,%r9
 2a13cff:	shr    $0x20,%r9
 2a13d03:	test   %r9,%r9
 2a13d06:	jne    2a19996 <wasm[0]::function[1015]::helper::object_read+0x1b836>
 2a13d0c:	add    %r8d,%r8d
 2a13d0f:	add    $0x14,%r8d
 2a13d13:	jb     2a19998 <wasm[0]::function[1015]::helper::object_read+0x1b838>
 2a13d19:	add    %r8d,%ecx
 2a13d1c:	jb     2a1999a <wasm[0]::function[1015]::helper::object_read+0x1b83a>
 2a13d22:	mov    %ecx,%r9d
 2a13d25:	lea    (%rsi,%r9,1),%rcx
 2a13d29:	cmp    %rdx,%r9
 2a13d2c:	cmova  %rdi,%rcx
 2a13d30:	sub    $0x14,%r8d
 2a13d34:	sub    %r8,%rcx
 2a13d37:	movzwl (%rcx),%ecx
 2a13d3a:	cmp    $0x30,%ecx
 2a13d3d:	je     2a13f14 <wasm[0]::function[1015]::helper::object_read+0x15db4>
 2a13d43:	mov    0x58(%rsp),%edi
 2a13d47:	mov    0x68(%rsp),%r8d
 2a13d4c:	mov    0x80(%rsp),%ecx
 2a13d53:	mov    0xa0(%rsp),%edx
 2a13d5a:	mov    %rdx,%r15
 2a13d5d:	mov    0x50(%rsp),%edx
 2a13d61:	xor    %r13d,%r13d
 2a13d64:	xor    %rbx,%rbx
 2a13d67:	mov    %edi,0xb8(%rsp)
 2a13d6e:	mov    %r8d,0xb0(%rsp)
 2a13d76:	mov    %eax,0xa8(%rsp)
 2a13d7d:	mov    %ecx,0xc8(%rsp)
 2a13d84:	mov    %r15,%rax
 2a13d87:	mov    %eax,0x90(%rsp)
 2a13d8e:	mov    %edx,0x88(%rsp)
 2a13d95:	mov    0x2e8(%rsp),%r15
 2a13d9d:	mov    (%r15),%rax
 2a13da0:	mov    0x228(%rsp),%rcx
 2a13da8:	cmp    %rcx,%rax
 2a13dab:	jae    2a18941 <wasm[0]::function[1015]::helper::object_read+0x1a7e1>
 2a13db1:	jmp    2a13dbe <wasm[0]::function[1015]::helper::object_read+0x15c5e>
 2a13db6:	mov    %rcx,0x228(%rsp)
 2a13dbe:	mov    0xe0(%rsp),%eax
 2a13dc5:	xor    %r9d,%r9d
 2a13dc8:	test   %eax,%eax
 2a13dca:	je     2a1999c <wasm[0]::function[1015]::helper::object_read+0x1b83c>
 2a13dd0:	test   %eax,%eax
 2a13dd2:	je     2a1999e <wasm[0]::function[1015]::helper::object_read+0x1b83e>
 2a13dd8:	mov    0x2e0(%rsp),%r14
 2a13de0:	mov    0x28(%r14),%rcx
 2a13de4:	mov    0x20(%r14),%rdx
 2a13de8:	mov    %eax,%r8d
 2a13deb:	lea    0x10(%rdx,%r8,1),%rdi
 2a13df0:	xor    %rsi,%rsi
 2a13df3:	cmp    %rcx,%r8
 2a13df6:	cmova  %rsi,%rdi
 2a13dfa:	mov    (%rdi),%edi
 2a13dfc:	cmp    %edi,%r13d
 2a13dff:	jae    2a199a0 <wasm[0]::function[1015]::helper::object_read+0x1b840>
 2a13e05:	mov    %edi,%r8d
 2a13e08:	shl    $1,%r8
 2a13e0b:	shr    $0x20,%r8
 2a13e0f:	test   %r8,%r8
 2a13e12:	jne    2a199a2 <wasm[0]::function[1015]::helper::object_read+0x1b842>
 2a13e18:	add    %edi,%edi
 2a13e1a:	add    $0x14,%edi
 2a13e1d:	jb     2a199a4 <wasm[0]::function[1015]::helper::object_read+0x1b844>
 2a13e23:	add    %edi,%eax
 2a13e25:	jb     2a199a6 <wasm[0]::function[1015]::helper::object_read+0x1b846>
 2a13e2b:	mov    %eax,%r8d
 2a13e2e:	lea    (%rdx,%r8,1),%rax
 2a13e32:	cmp    %rcx,%r8
 2a13e35:	cmova  %rsi,%rax
 2a13e39:	lea    0x14(%r13,%r13,1),%ecx
 2a13e3e:	sub    %ecx,%edi
 2a13e40:	sub    %rdi,%rax
 2a13e43:	movzwq (%rax),%rsi
 2a13e47:	mov    0xb8(%rsp),%edi
 2a13e4e:	mov    0xb0(%rsp),%r8d
 2a13e56:	mov    0xa8(%rsp),%eax
 2a13e5d:	mov    0xc8(%rsp),%ecx
 2a13e64:	mov    0x90(%rsp),%edx
 2a13e6b:	mov    %rdx,%r15
 2a13e6e:	mov    0x88(%rsp),%edx
 2a13e75:	movzwl %si,%esi
 2a13e78:	mov    %rsi,%r10
 2a13e7b:	sub    $0x30,%r10d
 2a13e7f:	cmp    $0x9,%r10d
 2a13e83:	jbe    2a13e91 <wasm[0]::function[1015]::helper::object_read+0x15d31>
 2a13e89:	mov    %r9,%rsi
 2a13e8c:	jmp    2a13f40 <wasm[0]::function[1015]::helper::object_read+0x15de0>
 2a13e91:	mov    0xb8(%rsp),%edi
 2a13e98:	mov    0xb0(%rsp),%r8d
 2a13ea0:	mov    0xa8(%rsp),%eax
 2a13ea7:	mov    0xc8(%rsp),%ecx
 2a13eae:	mov    0x90(%rsp),%edx
 2a13eb5:	mov    %rdx,%r15
 2a13eb8:	mov    0x88(%rsp),%edx
 2a13ebf:	add    $0x1,%r13d
 2a13ec6:	imul   $0xa,%rbx,%r9
 2a13eca:	mov    %rsi,%r10
 2a13ecd:	sub    $0x30,%r10d
 2a13ed1:	add    %r9,%r10
 2a13ed4:	cmp    %r12d,%r13d
 2a13ed7:	jae    2a13ee5 <wasm[0]::function[1015]::helper::object_read+0x15d85>
 2a13edd:	mov    %r10,%rbx
 2a13ee0:	jmp    2a13d67 <wasm[0]::function[1015]::helper::object_read+0x15c07>
 2a13ee5:	xor    %r9d,%r9d
 2a13ee8:	cmp    0x5ce9(%rip),%r10        # 2a19bd8 <wasm[0]::function[1015]::helper::object_read+0x1ba78>
 2a13eef:	jb     2a13efd <wasm[0]::function[1015]::helper::object_read+0x15d9d>
 2a13ef5:	mov    %r9,%rsi
 2a13ef8:	jmp    2a13f40 <wasm[0]::function[1015]::helper::object_read+0x15de0>
 2a13efd:	imul   $0xa,%ebx,%r9d
 2a13f01:	sub    $0x30,%esi
 2a13f04:	add    %r9d,%esi
 2a13f07:	mov    0x278(%rsp),%r9
 2a13f0f:	jmp    2a13f40 <wasm[0]::function[1015]::helper::object_read+0x15de0>
 2a13f14:	mov    0x58(%rsp),%edi
 2a13f18:	mov    0x68(%rsp),%r8d
 2a13f1d:	mov    0x80(%rsp),%ecx
 2a13f24:	mov    0xa0(%rsp),%edx
 2a13f2b:	mov    %rdx,%r15
 2a13f2e:	mov    0x50(%rsp),%edx
 2a13f32:	cmp    $0x1,%r12d
 2a13f36:	sete   %sil
 2a13f3a:	movzbl %sil,%r9d
 2a13f3e:	xor    %esi,%esi
 2a13f40:	mov    %edi,0x88(%rsp)
 2a13f47:	mov    %r8d,0x90(%rsp)
 2a13f4f:	mov    %eax,0xc8(%rsp)
 2a13f56:	mov    %ecx,0xa8(%rsp)
 2a13f5d:	mov    %r15,%rax
 2a13f60:	mov    %eax,0xb0(%rsp)
 2a13f67:	mov    %edx,0xb8(%rsp)
 2a13f6e:	test   %r9d,%r9d
 2a13f71:	jne    2a1481b <wasm[0]::function[1015]::helper::object_read+0x166bb>
 2a13f77:	mov    $0x8c,%edx
 2a13f7c:	mov    0x190(%rsp),%rsi
 2a13f84:	mov    0x190(%rsp),%rdi
 2a13f8c:	call   2f4f240 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 2a13f91:	test   %eax,%eax
 2a13f93:	je     2a199a8 <wasm[0]::function[1015]::helper::object_read+0x1b848>
 2a13f99:	mov    0x1b8(%rsp),%rcx
 2a13fa1:	cmp    $0x4,%ecx
 2a13fa4:	je     2a13fdd <wasm[0]::function[1015]::helper::object_read+0x15e7d>
 2a13faa:	mov    0x88(%rsp),%ecx
 2a13fb1:	mov    0xc8(%rsp),%eax
 2a13fb8:	mov    %rax,%r8
 2a13fbb:	mov    0xa8(%rsp),%edx
 2a13fc2:	mov    0xb0(%rsp),%esi
 2a13fc9:	mov    0xb8(%rsp),%edi
 2a13fd0:	xor    %eax,%eax
 2a13fd2:	mov    %rax,%r13
 2a13fd5:	mov    %r8,%rax
 2a13fd8:	jmp    2a145fd <wasm[0]::function[1015]::helper::object_read+0x1649d>
 2a13fdd:	mov    0x1b8(%rsp),%rcx
 2a13fe5:	cmp    $0x3,%ecx
 2a13fe8:	je     2a1458b <wasm[0]::function[1015]::helper::object_read+0x1642b>
 2a13fee:	mov    0x1b8(%rsp),%rcx
 2a13ff6:	cmp    $0x4,%ecx
 2a13ff9:	je     2a14451 <wasm[0]::function[1015]::helper::object_read+0x162f1>
 2a13fff:	mov    0x1b8(%rsp),%rcx
 2a14007:	cmp    $0xa,%ecx
 2a1400a:	je     2a140b7 <wasm[0]::function[1015]::helper::object_read+0x15f57>
 2a14010:	mov    0x1b8(%rsp),%rcx
 2a14018:	mov    0x1b8(%rsp),%r11
 2a14020:	test   %r11d,%ecx
 2a14023:	sete   %cl
 2a14026:	mov    0x1b8(%rsp),%rdx
 2a1402e:	cmp    $0x1,%edx
 2a14031:	sete   %dl
 2a14034:	or     %edx,%ecx
 2a14036:	test   %cl,%cl
 2a14038:	jne    2a14087 <wasm[0]::function[1015]::helper::object_read+0x15f27>
 2a1403e:	mov    0x1b8(%rsp),%rcx
 2a14046:	cmp    $0x2,%ecx
 2a14049:	je     2a14066 <wasm[0]::function[1015]::helper::object_read+0x15f06>
 2a1404f:	mov    0x90(%rsp),%ecx
 2a14056:	cmp    %eax,%ecx
 2a14058:	sete   %al
 2a1405b:	movzbl %al,%eax
 2a1405e:	mov    %rax,%r13
 2a14061:	jmp    2a1408f <wasm[0]::function[1015]::helper::object_read+0x15f2f>
 2a14066:	mov    0x1c0(%rsp),%rax
 2a1406e:	mov    0x1c0(%rsp),%r8
 2a14076:	test   %rax,%r8
 2a14079:	sete   %al
 2a1407c:	movzbl %al,%eax
 2a1407f:	mov    %rax,%r13
 2a14082:	jmp    2a1408f <wasm[0]::function[1015]::helper::object_read+0x15f2f>
 2a14087:	mov    0x278(%rsp),%r13
 2a1408f:	mov    0x88(%rsp),%ecx
 2a14096:	mov    0xc8(%rsp),%eax
 2a1409d:	mov    0xa8(%rsp),%edx
 2a140a4:	mov    0xb0(%rsp),%esi
 2a140ab:	mov    0xb8(%rsp),%edi
 2a140b2:	jmp    2a145fd <wasm[0]::function[1015]::helper::object_read+0x1649d>
 2a140b7:	mov    0x90(%rsp),%edx
 2a140be:	xor    %ecx,%ecx
 2a140c0:	test   %edx,%edx
 2a140c2:	je     2a14111 <wasm[0]::function[1015]::helper::object_read+0x15fb1>
 2a140c8:	xor    %ecx,%ecx
 2a140ca:	test   $0x1,%edx
 2a140d0:	jne    2a14111 <wasm[0]::function[1015]::helper::object_read+0x15fb1>
 2a140d6:	mov    0x2e0(%rsp),%r14
 2a140de:	mov    0x28(%r14),%rcx
 2a140e2:	mov    0x20(%r14),%rdi
 2a140e6:	mov    %edx,%esi
 2a140e8:	lea    0x4(%rdi,%rsi,1),%rdx
 2a140ed:	xor    %rdi,%rdi
 2a140f0:	cmp    %rcx,%rsi
 2a140f3:	cmova  %rdi,%rdx
 2a140f7:	mov    (%rdx),%ecx
 2a140f9:	mov    0x190(%rsp),%rsi
 2a14101:	mov    0x28(%rsi),%rdx
 2a14105:	cmp    0x23c(%rdx),%ecx
 2a1410b:	sete   %cl
 2a1410e:	movzbl %cl,%ecx
 2a14111:	test   %ecx,%ecx
 2a14113:	je     2a199aa <wasm[0]::function[1015]::helper::object_read+0x1b84a>
 2a14119:	xor    %ecx,%ecx
 2a1411b:	test   %eax,%eax
 2a1411d:	je     2a1416b <wasm[0]::function[1015]::helper::object_read+0x1600b>
 2a14123:	xor    %ecx,%ecx
 2a14125:	test   $0x1,%eax
 2a1412a:	jne    2a1416b <wasm[0]::function[1015]::helper::object_read+0x1600b>
 2a14130:	mov    0x2e0(%rsp),%r14
 2a14138:	mov    0x28(%r14),%rcx
 2a1413c:	mov    0x20(%r14),%rdx
 2a14140:	mov    %eax,%esi
 2a14142:	lea    0x4(%rdx,%rsi,1),%rdx
 2a14147:	xor    %rdi,%rdi
 2a1414a:	cmp    %rcx,%rsi
 2a1414d:	cmova  %rdi,%rdx
 2a14151:	mov    (%rdx),%ecx
 2a14153:	mov    0x190(%rsp),%rsi
 2a1415b:	mov    0x28(%rsi),%rdx
 2a1415f:	cmp    0x23c(%rdx),%ecx
 2a14165:	sete   %cl
 2a14168:	movzbl %cl,%ecx
 2a1416b:	test   %ecx,%ecx
 2a1416d:	je     2a199ac <wasm[0]::function[1015]::helper::object_read+0x1b84c>
 2a14173:	mov    0x90(%rsp),%esi
 2a1417a:	test   %esi,%esi
 2a1417c:	je     2a199ae <wasm[0]::function[1015]::helper::object_read+0x1b84e>
 2a14182:	test   %esi,%esi
 2a14184:	je     2a199b0 <wasm[0]::function[1015]::helper::object_read+0x1b850>
 2a1418a:	mov    0x2e0(%rsp),%r14
 2a14192:	mov    0x28(%r14),%rcx
 2a14196:	mov    0x20(%r14),%rdx
 2a1419a:	mov    %esi,%r8d
 2a1419d:	lea    (%rdx,%r8,1),%rdi
 2a141a1:	xor    %rsi,%rsi
 2a141a4:	cmp    %rcx,%r8
 2a141a7:	cmova  %rsi,%rdi
 2a141ab:	mov    0x10(%rdi),%r8d
 2a141af:	test   %eax,%eax
 2a141b1:	je     2a199b2 <wasm[0]::function[1015]::helper::object_read+0x1b852>
 2a141b7:	mov    %eax,%r9d
 2a141ba:	lea    (%rdx,%r9,1),%r11
 2a141be:	cmp    %rcx,%r9
 2a141c1:	cmova  %rsi,%r11
 2a141c5:	mov    0x10(%r11),%r9d
 2a141c9:	mov    0x14(%rdi),%r10d
 2a141cd:	mov    %r10d,0xe0(%rsp)
 2a141d5:	mov    0x14(%r11),%edi
 2a141d9:	mov    %edi,0xe8(%rsp)
 2a141e0:	test   %r10d,%r10d
 2a141e3:	je     2a199b4 <wasm[0]::function[1015]::helper::object_read+0x1b854>
 2a141e9:	test   %r10d,%r10d
 2a141ec:	je     2a199b6 <wasm[0]::function[1015]::helper::object_read+0x1b856>
 2a141f2:	mov    %r10d,%r11d
 2a141f5:	lea    0x10(%rdx,%r11,1),%r10
 2a141fa:	cmp    %rcx,%r11
 2a141fd:	cmova  %rsi,%r10
 2a14201:	mov    (%r10),%r12d
 2a14204:	test   %edi,%edi
 2a14206:	je     2a199b8 <wasm[0]::function[1015]::helper::object_read+0x1b858>
 2a1420c:	test   %edi,%edi
 2a1420e:	je     2a199ba <wasm[0]::function[1015]::helper::object_read+0x1b85a>
 2a14214:	mov    %edi,%edi
 2a14216:	lea    0x10(%rdx,%rdi,1),%rax
 2a1421b:	cmp    %rcx,%rdi
 2a1421e:	cmova  %rsi,%rax
 2a14222:	mov    (%rax),%r10d
 2a14225:	mov    0x88(%rsp),%ecx
 2a1422c:	mov    0xc8(%rsp),%eax
 2a14233:	mov    0xa8(%rsp),%edx
 2a1423a:	mov    0xb0(%rsp),%esi
 2a14241:	mov    0xb8(%rsp),%edi
 2a14248:	cmp    %r9d,%r8d
 2a1424b:	sete   %r8b
 2a1424f:	cmp    %r10d,%r12d
 2a14252:	sete   %r9b
 2a14256:	mov    %r8,%r10
 2a14259:	and    %r9d,%r10d
 2a1425c:	movzbl %r10b,%r10d
 2a14260:	mov    %r10,%r13
 2a14263:	test   %r8b,%r9b
 2a14266:	je     2a145fd <wasm[0]::function[1015]::helper::object_read+0x1649d>
 2a1426c:	mov    0x88(%rsp),%ecx
 2a14273:	mov    0xc8(%rsp),%edx
 2a1427a:	mov    0xa8(%rsp),%esi
 2a14281:	mov    0xb0(%rsp),%edi
 2a14288:	mov    0xb8(%rsp),%r8d
 2a14290:	xor    %ebx,%ebx
 2a14292:	mov    %ecx,0x98(%rsp)
 2a14299:	mov    %edx,0xc0(%rsp)
 2a142a0:	mov    %esi,0x78(%rsp)
 2a142a4:	mov    %edi,0xd0(%rsp)
 2a142ab:	mov    %r8d,0xd8(%rsp)
 2a142b3:	mov    0x2e8(%rsp),%r15
 2a142bb:	mov    (%r15),%rcx
 2a142be:	mov    0x228(%rsp),%rax
 2a142c6:	cmp    %rax,%rcx
 2a142c9:	jae    2a18970 <wasm[0]::function[1015]::helper::object_read+0x1a810>
 2a142cf:	jmp    2a142dc <wasm[0]::function[1015]::helper::object_read+0x1617c>
 2a142d4:	mov    %rdx,0x228(%rsp)
 2a142dc:	cmp    %r12d,%ebx
 2a142df:	jae    2a1442c <wasm[0]::function[1015]::helper::object_read+0x162cc>
 2a142e5:	mov    0xe0(%rsp),%edi
 2a142ec:	test   %edi,%edi
 2a142ee:	je     2a199bc <wasm[0]::function[1015]::helper::object_read+0x1b85c>
 2a142f4:	test   %edi,%edi
 2a142f6:	je     2a199be <wasm[0]::function[1015]::helper::object_read+0x1b85e>
 2a142fc:	mov    0x2e0(%rsp),%r14
 2a14304:	mov    0x28(%r14),%rcx
 2a14308:	mov    0x20(%r14),%rdx
 2a1430c:	mov    %edi,%r9d
 2a1430f:	lea    0x10(%rdx,%r9,1),%r8
 2a14314:	xor    %rsi,%rsi
 2a14317:	cmp    %rcx,%r9
 2a1431a:	cmova  %rsi,%r8
 2a1431e:	mov    (%r8),%r9d
 2a14321:	cmp    %r9d,%ebx
 2a14324:	jae    2a199c0 <wasm[0]::function[1015]::helper::object_read+0x1b860>
 2a1432a:	mov    %r9d,%r8d
 2a1432d:	shl    $0x3,%r8
 2a14331:	shr    $0x20,%r8
 2a14335:	test   %r8,%r8
 2a14338:	jne    2a199c2 <wasm[0]::function[1015]::helper::object_read+0x1b862>
 2a1433e:	shl    $0x3,%r9d
 2a14342:	add    $0x18,%r9d
 2a14346:	jb     2a199c4 <wasm[0]::function[1015]::helper::object_read+0x1b864>
 2a1434c:	add    %r9d,%edi
 2a1434f:	jb     2a199c6 <wasm[0]::function[1015]::helper::object_read+0x1b866>
 2a14355:	mov    %edi,%eax
 2a14357:	lea    (%rdx,%rax,1),%rdi
 2a1435b:	cmp    %rcx,%rax
 2a1435e:	cmova  %rsi,%rdi
 2a14362:	mov    %rbx,%rax
 2a14365:	shl    $0x3,%eax
 2a14368:	lea    0x18(%rax),%r8d
 2a1436c:	sub    %r8d,%r9d
 2a1436f:	sub    %r9,%rdi
 2a14372:	mov    (%rdi),%rdi
 2a14375:	mov    0xe8(%rsp),%r9d
 2a1437d:	test   %r9d,%r9d
 2a14380:	je     2a199c8 <wasm[0]::function[1015]::helper::object_read+0x1b868>
 2a14386:	test   %r9d,%r9d
 2a14389:	je     2a199ca <wasm[0]::function[1015]::helper::object_read+0x1b86a>
 2a1438f:	mov    %r9d,%eax
 2a14392:	lea    0x10(%rdx,%rax,1),%r10
 2a14397:	cmp    %rcx,%rax
 2a1439a:	cmova  %rsi,%r10
 2a1439e:	mov    (%r10),%r10d
 2a143a1:	cmp    %r10d,%ebx
 2a143a4:	jae    2a199cc <wasm[0]::function[1015]::helper::object_read+0x1b86c>
 2a143aa:	mov    %r10d,%r11d
 2a143ad:	shl    $0x3,%r11
 2a143b1:	shr    $0x20,%r11
 2a143b5:	test   %r11,%r11
 2a143b8:	jne    2a199ce <wasm[0]::function[1015]::helper::object_read+0x1b86e>
 2a143be:	shl    $0x3,%r10d
 2a143c2:	add    $0x18,%r10d
 2a143c6:	jb     2a199d0 <wasm[0]::function[1015]::helper::object_read+0x1b870>
 2a143cc:	add    %r10d,%r9d
 2a143cf:	jb     2a199d2 <wasm[0]::function[1015]::helper::object_read+0x1b872>
 2a143d5:	mov    %r9d,%eax
 2a143d8:	add    %rax,%rdx
 2a143db:	cmp    %rcx,%rax
 2a143de:	cmova  %rsi,%rdx
 2a143e2:	sub    %r8d,%r10d
 2a143e5:	sub    %r10,%rdx
 2a143e8:	mov    (%rdx),%rcx
 2a143eb:	cmp    %rcx,%rdi
 2a143ee:	sete   %al
 2a143f1:	movzbl %al,%eax
 2a143f4:	mov    %rax,%r13
 2a143f7:	cmp    %rcx,%rdi
 2a143fa:	jne    2a1442c <wasm[0]::function[1015]::helper::object_read+0x162cc>
 2a14400:	mov    0x98(%rsp),%ecx
 2a14407:	mov    0xc0(%rsp),%edx
 2a1440e:	mov    0x78(%rsp),%esi
 2a14412:	mov    0xd0(%rsp),%edi
 2a14419:	mov    0xd8(%rsp),%r8d
 2a14421:	add    $0x1,%ebx
 2a14427:	jmp    2a14292 <wasm[0]::function[1015]::helper::object_read+0x16132>
 2a1442c:	mov    0x98(%rsp),%ecx
 2a14433:	mov    0xc0(%rsp),%eax
 2a1443a:	mov    0x78(%rsp),%edx
 2a1443e:	mov    0xd0(%rsp),%esi
 2a14445:	mov    0xd8(%rsp),%edi
 2a1444c:	jmp    2a145fd <wasm[0]::function[1015]::helper::object_read+0x1649d>
 2a14451:	mov    0x90(%rsp),%esi
 2a14458:	cmp    %eax,%esi
 2a1445a:	je     2a1455b <wasm[0]::function[1015]::helper::object_read+0x163fb>
 2a14460:	xor    %ecx,%ecx
 2a14462:	test   %esi,%esi
 2a14464:	je     2a144b4 <wasm[0]::function[1015]::helper::object_read+0x16354>
 2a1446a:	xor    %ecx,%ecx
 2a1446c:	test   $0x1,%esi
 2a14472:	jne    2a144b4 <wasm[0]::function[1015]::helper::object_read+0x16354>
 2a14478:	mov    0x2e0(%rsp),%r14
 2a14480:	mov    0x28(%r14),%rcx
 2a14484:	mov    0x20(%r14),%rdi
 2a14488:	mov    %esi,%edx
 2a1448a:	lea    0x4(%rdi,%rdx,1),%r11
 2a1448f:	xor    %rsi,%rsi
 2a14492:	cmp    %rcx,%rdx
 2a14495:	cmova  %rsi,%r11
 2a14499:	mov    (%r11),%ecx
 2a1449c:	mov    0x190(%rsp),%rsi
 2a144a4:	mov    0x28(%rsi),%rdx
 2a144a8:	cmp    0x234(%rdx),%ecx
 2a144ae:	sete   %cl
 2a144b1:	movzbl %cl,%ecx
 2a144b4:	test   %ecx,%ecx
 2a144b6:	je     2a199d4 <wasm[0]::function[1015]::helper::object_read+0x1b874>
 2a144bc:	xor    %ecx,%ecx
 2a144be:	test   %eax,%eax
 2a144c0:	jne    2a144ce <wasm[0]::function[1015]::helper::object_read+0x1636e>
 2a144c6:	mov    %rax,%rdi
 2a144c9:	jmp    2a14521 <wasm[0]::function[1015]::helper::object_read+0x163c1>
 2a144ce:	xor    %ecx,%ecx
 2a144d0:	test   $0x1,%eax
 2a144d5:	je     2a144e3 <wasm[0]::function[1015]::helper::object_read+0x16383>
 2a144db:	mov    %rax,%rdi
 2a144de:	jmp    2a14521 <wasm[0]::function[1015]::helper::object_read+0x163c1>
 2a144e3:	mov    0x2e0(%rsp),%r14
 2a144eb:	mov    0x28(%r14),%rcx
 2a144ef:	mov    0x20(%r14),%rsi
 2a144f3:	mov    %eax,%edx
 2a144f5:	mov    %rax,%rdi
 2a144f8:	lea    0x4(%rsi,%rdx,1),%rax
 2a144fd:	xor    %rsi,%rsi
 2a14500:	cmp    %rcx,%rdx
 2a14503:	cmova  %rsi,%rax
 2a14507:	mov    (%rax),%eax
 2a14509:	mov    0x190(%rsp),%rsi
 2a14511:	mov    0x28(%rsi),%rcx
 2a14515:	cmp    0x234(%rcx),%eax
 2a1451b:	sete   %al
 2a1451e:	movzbl %al,%ecx
 2a14521:	test   %ecx,%ecx
 2a14523:	je     2a199d6 <wasm[0]::function[1015]::helper::object_read+0x1b876>
 2a14529:	mov    0x90(%rsp),%edx
 2a14530:	xor    %r8d,%r8d
 2a14533:	test   %edx,%edx
 2a14535:	je     2a199d8 <wasm[0]::function[1015]::helper::object_read+0x1b878>
 2a1453b:	mov    %rdi,%rcx
 2a1453e:	mov    0x190(%rsp),%rsi
 2a14546:	mov    0x190(%rsp),%rdi
 2a1454e:	call   2b02800 <wasm[0]::function[1057]::helper::string_equality>
 2a14553:	mov    %rax,%r13
 2a14556:	jmp    2a14563 <wasm[0]::function[1015]::helper::object_read+0x16403>
 2a1455b:	mov    0x278(%rsp),%r13
 2a14563:	mov    0x88(%rsp),%ecx
 2a1456a:	mov    0xc8(%rsp),%eax
 2a14571:	mov    0xa8(%rsp),%edx
 2a14578:	mov    0xb0(%rsp),%esi
 2a1457f:	mov    0xb8(%rsp),%edi
 2a14586:	jmp    2a145fd <wasm[0]::function[1015]::helper::object_read+0x1649d>
 2a1458b:	mov    0x88(%rsp),%ecx
 2a14592:	mov    0xc8(%rsp),%eax
 2a14599:	mov    0xa8(%rsp),%edx
 2a145a0:	mov    0xb0(%rsp),%esi
 2a145a7:	mov    0xb8(%rsp),%edi
 2a145ae:	xor    %r10,%r10
 2a145b1:	mov    0x1c0(%rsp),%r8
 2a145b9:	mov    0x1c0(%rsp),%r9
 2a145c1:	test   %r9,%r8
 2a145c4:	sete   %r8b
 2a145c8:	movq   %r9,%xmm0
 2a145cd:	ucomisd %xmm0,%xmm0
 2a145d1:	setp   %r9b
 2a145d5:	setne  %r11b
 2a145d9:	or     %r11d,%r9d
 2a145dc:	movq   %r10,%xmm0
 2a145e1:	ucomisd %xmm0,%xmm0
 2a145e5:	setp   %r10b
 2a145e9:	setne  %r11b
 2a145ed:	or     %r11d,%r10d
 2a145f0:	and    %r10d,%r9d
 2a145f3:	or     %r9d,%r8d
 2a145f6:	movzbl %r8b,%r8d
 2a145fa:	mov    %r8,%r13
 2a145fd:	mov    %edx,0x98(%rsp)
 2a14604:	mov    %esi,0x90(%rsp)
 2a1460b:	mov    %edi,0xc8(%rsp)
 2a14612:	mov    %r13,%rdx
 2a14615:	mov    %r13,%rsi
 2a14618:	test   %esi,%edx
 2a1461a:	je     2a147fd <wasm[0]::function[1015]::helper::object_read+0x1669d>
 2a14620:	test   %ecx,%ecx
 2a14622:	je     2a199da <wasm[0]::function[1015]::helper::object_read+0x1b87a>
 2a14628:	test   %ecx,%ecx
 2a1462a:	je     2a199dc <wasm[0]::function[1015]::helper::object_read+0x1b87c>
 2a14630:	mov    0x2e0(%rsp),%r14
 2a14638:	mov    0x28(%r14),%rdx
 2a1463c:	mov    0x20(%r14),%rax
 2a14640:	mov    %ecx,%ecx
 2a14642:	add    %rcx,%rax
 2a14645:	xor    %rsi,%rsi
 2a14648:	cmp    %rdx,%rcx
 2a1464b:	cmova  %rsi,%rax
 2a1464f:	mov    0x18(%rax),%r12
 2a14653:	movl   $0x0,0xc0(%rsp)
 2a1465e:	mov    0x20(%rax),%ebx
 2a14661:	mov    0x268(%rsp),%rcx
 2a14669:	mov    (%rcx),%eax
 2a1466b:	mov    %eax,%edx
 2a1466d:	lea    0x20(%rdx),%rcx
 2a14671:	mov    0x268(%rsp),%rsi
 2a14679:	mov    0x4(%rsi),%esi
 2a1467c:	cmp    %rsi,%rcx
 2a1467f:	ja     2a1899f <wasm[0]::function[1015]::helper::object_read+0x1a83f>
 2a14685:	lea    0x20(%rax),%ecx
 2a14688:	mov    0x268(%rsp),%rsi
 2a14690:	mov    %ecx,(%rsi)
 2a14692:	mov    0x2e0(%rsp),%r14
 2a1469a:	mov    0x20(%r14),%rsi
 2a1469e:	lea    (%rsi,%rdx,1),%rcx
 2a146a2:	movl   $0xb0000042,(%rsi,%rdx,1)
 2a146a9:	mov    0x190(%rsp),%rdi
 2a146b1:	mov    0x28(%rdi),%rdi
 2a146b5:	mov    0x120(%rdi),%edi
 2a146bb:	mov    %edi,0x4(%rsi,%rdx,1)
 2a146bf:	mov    0x260(%rsp),%rdi
 2a146c7:	mov    %edi,0x8(%rsi,%rdx,1)
 2a146cb:	mov    %eax,0x78(%rsp)
 2a146cf:	cmp    $0x0,%r12
 2a146d3:	jl     2a146e3 <wasm[0]::function[1015]::helper::object_read+0x16583>
 2a146d9:	cvtsi2sd %r12,%xmm0
 2a146de:	jmp    2a146fd <wasm[0]::function[1015]::helper::object_read+0x1659d>
 2a146e3:	mov    %r12,%rsi
 2a146e6:	shr    $0x1,%rsi
 2a146ea:	mov    %r12,%rdx
 2a146ed:	and    $0x1,%rdx
 2a146f1:	or     %rsi,%rdx
 2a146f4:	cvtsi2sd %rdx,%xmm0
 2a146f9:	addsd  %xmm0,%xmm0
 2a146fd:	movq   %xmm0,%rdx
 2a14702:	mov    %rdx,0x10(%rcx)
 2a14706:	movl   $0x3,0x18(%rcx)
 2a1470d:	mov    0xc0(%rsp),%edx
 2a14714:	mov    %edx,0x1c(%rcx)
 2a14717:	mov    0x190(%rsp),%rsi
 2a1471f:	mov    0xa20(%rsi),%ecx
 2a14725:	mov    %ecx,0xc0(%rsp)
 2a1472c:	test   %eax,%eax
 2a1472e:	je     2a199de <wasm[0]::function[1015]::helper::object_read+0x1b87e>
 2a14734:	test   %ecx,%ecx
 2a14736:	je     2a199e0 <wasm[0]::function[1015]::helper::object_read+0x1b880>
 2a1473c:	mov    0x268(%rsp),%rcx
 2a14744:	mov    (%rcx),%eax
 2a14746:	mov    %eax,%esi
 2a14748:	lea    0x20(%rsi),%rdi
 2a1474c:	mov    0x4(%rcx),%r8d
 2a14750:	cmp    %r8,%rdi
 2a14753:	ja     2a189e1 <wasm[0]::function[1015]::helper::object_read+0x1a881>
 2a14759:	lea    0x20(%rax),%r8d
 2a1475d:	mov    0x268(%rsp),%rcx
 2a14765:	mov    %r8d,(%rcx)
 2a14768:	mov    0x2e0(%rsp),%r14
 2a14770:	mov    0x20(%r14),%r9
 2a14774:	lea    (%r9,%rsi,1),%rcx
 2a14778:	movl   $0xb0000072,(%r9,%rsi,1)
 2a14780:	mov    0x190(%rsp),%rdx
 2a14788:	mov    0x28(%rdx),%r10
 2a1478c:	mov    0x13c(%r10),%r10d
 2a14793:	mov    %r10d,0x4(%r9,%rsi,1)
 2a14798:	mov    0x260(%rsp),%rdx
 2a147a0:	mov    %edx,0x8(%r9,%rsi,1)
 2a147a5:	movl   $0x4,0x10(%rcx)
 2a147ac:	mov    0x78(%rsp),%edx
 2a147b0:	mov    %edx,0x14(%rcx)
 2a147b3:	mov    0xc0(%rsp),%edx
 2a147ba:	mov    %edx,0x18(%rcx)
 2a147bd:	mov    %edx,0x1c(%rcx)
 2a147c0:	test   %eax,%eax
 2a147c2:	je     2a199e2 <wasm[0]::function[1015]::helper::object_read+0x1b882>
 2a147c8:	test   %eax,%eax
 2a147ca:	je     2a199e4 <wasm[0]::function[1015]::helper::object_read+0x1b884>
 2a147d0:	mov    0x2e0(%rsp),%r14
 2a147d8:	mov    0x28(%r14),%rcx
 2a147dc:	test   %ebx,%ebx
 2a147de:	setne  %dl
 2a147e1:	movzbl %dl,%edx
 2a147e4:	shl    $0x2,%edx
 2a147e7:	mov    %eax,%edi
 2a147e9:	mov    %rdi,%rsi
 2a147ec:	add    0x20(%r14),%rsi
 2a147f0:	xor    %r8,%r8
 2a147f3:	cmp    %rcx,%rdi
 2a147f6:	cmova  %r8,%rsi
 2a147fa:	mov    %edx,0x10(%rsi)
 2a147fd:	mov    0x98(%rsp),%ecx
 2a14804:	mov    0x90(%rsp),%r10d
 2a1480c:	mov    %r10,%r15
 2a1480f:	mov    0xc8(%rsp),%edx
 2a14816:	jmp    2a15c23 <wasm[0]::function[1015]::helper::object_read+0x17ac3>
 2a1481b:	test   %edi,%edi
 2a1481d:	je     2a199e6 <wasm[0]::function[1015]::helper::object_read+0x1b886>
 2a14823:	test   %edi,%edi
 2a14825:	je     2a199e8 <wasm[0]::function[1015]::helper::object_read+0x1b888>
 2a1482b:	mov    0x2e0(%rsp),%r14
 2a14833:	mov    0x28(%r14),%r8
 2a14837:	mov    0x20(%r14),%r9
 2a1483b:	mov    %edi,%r10d
 2a1483e:	lea    (%r9,%r10,1),%rax
 2a14842:	xor    %rdi,%rdi
 2a14845:	cmp    %r8,%r10
 2a14848:	cmova  %rdi,%rax
 2a1484c:	mov    0x14(%rax),%eax
 2a1484f:	mov    %eax,0x88(%rsp)
 2a14856:	test   %eax,%eax
 2a14858:	je     2a199ea <wasm[0]::function[1015]::helper::object_read+0x1b88a>
 2a1485e:	test   %eax,%eax
 2a14860:	je     2a199ec <wasm[0]::function[1015]::helper::object_read+0x1b88c>
 2a14866:	mov    %eax,%r10d
 2a14869:	add    %r10,%r9
 2a1486c:	cmp    %r8,%r10
 2a1486f:	cmova  %rdi,%r9
 2a14873:	mov    0x24(%r9),%r8d
 2a14877:	cmp    $0x4,%r8d
 2a1487b:	sete   %dil
 2a1487f:	cmp    $0x2,%r8d
 2a14883:	sete   %r9b
 2a14887:	or     %r9d,%edi
 2a1488a:	cmp    $0x3,%r8d
 2a1488e:	sete   %r8b
 2a14892:	or     %r8d,%edi
 2a14895:	test   %dil,%dil
 2a14898:	jne    2a148ab <wasm[0]::function[1015]::helper::object_read+0x1674b>
 2a1489e:	mov    %rsi,0x198(%rsp)
 2a148a6:	jmp    2a158fd <wasm[0]::function[1015]::helper::object_read+0x1779d>
 2a148ab:	mov    0x88(%rsp),%eax
 2a148b2:	test   %eax,%eax
 2a148b4:	je     2a199ee <wasm[0]::function[1015]::helper::object_read+0x1b88e>
 2a148ba:	test   %eax,%eax
 2a148bc:	je     2a199f0 <wasm[0]::function[1015]::helper::object_read+0x1b890>
 2a148c2:	mov    0x2e0(%rsp),%r14
 2a148ca:	mov    0x28(%r14),%rcx
 2a148ce:	mov    %eax,%edx
 2a148d0:	mov    %rdx,%rax
 2a148d3:	add    0x20(%r14),%rax
 2a148d7:	xor    %rdi,%rdi
 2a148da:	cmp    %rcx,%rdx
 2a148dd:	cmova  %rdi,%rax
 2a148e1:	mov    0x24(%rax),%eax
 2a148e4:	cmp    $0x3,%eax
 2a148e7:	je     2a14aa6 <wasm[0]::function[1015]::helper::object_read+0x16946>
 2a148ed:	mov    0x88(%rsp),%eax
 2a148f4:	test   %eax,%eax
 2a148f6:	je     2a199f2 <wasm[0]::function[1015]::helper::object_read+0x1b892>
 2a148fc:	test   %eax,%eax
 2a148fe:	je     2a199f4 <wasm[0]::function[1015]::helper::object_read+0x1b894>
 2a14904:	mov    0x2e0(%rsp),%r14
 2a1490c:	mov    0x28(%r14),%rcx
 2a14910:	mov    %eax,%edx
 2a14912:	mov    %rdx,%rax
 2a14915:	add    0x20(%r14),%rax
 2a14919:	xor    %rdi,%rdi
 2a1491c:	cmp    %rcx,%rdx
 2a1491f:	cmova  %rdi,%rax
 2a14923:	mov    0x24(%rax),%eax
 2a14926:	cmp    $0x4,%eax
 2a14929:	je     2a14a49 <wasm[0]::function[1015]::helper::object_read+0x168e9>
 2a1492f:	mov    0x88(%rsp),%eax
 2a14936:	xor    %r11d,%r11d
 2a14939:	test   %eax,%eax
 2a1493b:	je     2a199f6 <wasm[0]::function[1015]::helper::object_read+0x1b896>
 2a14941:	test   %eax,%eax
 2a14943:	je     2a199f8 <wasm[0]::function[1015]::helper::object_read+0x1b898>
 2a14949:	mov    0x2e0(%rsp),%r14
 2a14951:	mov    0x28(%r14),%rcx
 2a14955:	mov    0x20(%r14),%rdx
 2a14959:	mov    %eax,%r8d
 2a1495c:	lea    (%rdx,%r8,1),%rax
 2a14960:	xor    %rdi,%rdi
 2a14963:	cmp    %rcx,%r8
 2a14966:	cmova  %rdi,%rax
 2a1496a:	mov    0x28(%rax),%r8d
 2a1496e:	mov    0x2c(%rax),%eax
 2a14971:	test   %r8d,%r8d
 2a14974:	je     2a199fa <wasm[0]::function[1015]::helper::object_read+0x1b89a>
 2a1497a:	test   %r8d,%r8d
 2a1497d:	je     2a199fc <wasm[0]::function[1015]::helper::object_read+0x1b89c>
 2a14983:	mov    %r8d,%r8d
 2a14986:	lea    0x10(%rdx,%r8,1),%rdx
 2a1498b:	cmp    %rcx,%r8
 2a1498e:	cmova  %rdi,%rdx
 2a14992:	mov    %esi,%edi
 2a14994:	mov    (%rdx),%r8d
 2a14997:	cmp    %r8,%rdi
 2a1499a:	jae    2a14a99 <wasm[0]::function[1015]::helper::object_read+0x16939>
 2a149a0:	xor    %r11d,%r11d
 2a149a3:	test   %eax,%eax
 2a149a5:	je     2a199fe <wasm[0]::function[1015]::helper::object_read+0x1b89e>
 2a149ab:	test   %eax,%eax
 2a149ad:	je     2a19a00 <wasm[0]::function[1015]::helper::object_read+0x1b8a0>
 2a149b3:	mov    0x2e0(%rsp),%r14
 2a149bb:	mov    0x28(%r14),%rcx
 2a149bf:	mov    0x20(%r14),%rdx
 2a149c3:	mov    %eax,%r9d
 2a149c6:	lea    0x10(%rdx,%r9,1),%r8
 2a149cb:	xor    %rdi,%rdi
 2a149ce:	cmp    %rcx,%r9
 2a149d1:	cmova  %rdi,%r8
 2a149d5:	mov    (%r8),%r8d
 2a149d8:	mov    %rsi,%r9
 2a149db:	shr    $0x6,%r9d
 2a149df:	cmp    %r8d,%r9d
 2a149e2:	jae    2a19a02 <wasm[0]::function[1015]::helper::object_read+0x1b8a2>
 2a149e8:	mov    %r8d,%r10d
 2a149eb:	shl    $0x3,%r10
 2a149ef:	shr    $0x20,%r10
 2a149f3:	test   %r10,%r10
 2a149f6:	jne    2a19a04 <wasm[0]::function[1015]::helper::object_read+0x1b8a4>
 2a149fc:	shl    $0x3,%r8d
 2a14a00:	add    $0x18,%r8d
 2a14a04:	jb     2a19a06 <wasm[0]::function[1015]::helper::object_read+0x1b8a6>
 2a14a0a:	add    %r8d,%eax
 2a14a0d:	jb     2a19a08 <wasm[0]::function[1015]::helper::object_read+0x1b8a8>
 2a14a13:	mov    %eax,%r10d
 2a14a16:	lea    (%rdx,%r10,1),%rax
 2a14a1a:	cmp    %rcx,%r10
 2a14a1d:	cmova  %rdi,%rax
 2a14a21:	shl    $0x3,%r9d
 2a14a25:	lea    0x18(%r9),%ecx
 2a14a29:	sub    %ecx,%r8d
 2a14a2c:	sub    %r8,%rax
 2a14a2f:	mov    (%rax),%rax
 2a14a32:	bt     %rsi,%rax
 2a14a36:	jae    2a14a99 <wasm[0]::function[1015]::helper::object_read+0x16939>
 2a14a3c:	mov    0x278(%rsp),%r11
 2a14a44:	jmp    2a14a99 <wasm[0]::function[1015]::helper::object_read+0x16939>
 2a14a49:	mov    0x88(%rsp),%eax
 2a14a50:	xor    %r11d,%r11d
 2a14a53:	test   %eax,%eax
 2a14a55:	je     2a19a0a <wasm[0]::function[1015]::helper::object_read+0x1b8aa>
 2a14a5b:	test   %eax,%eax
 2a14a5d:	je     2a19a0c <wasm[0]::function[1015]::helper::object_read+0x1b8ac>
 2a14a63:	mov    0x2e0(%rsp),%r14
 2a14a6b:	mov    0x28(%r14),%rcx
 2a14a6f:	mov    %eax,%edx
 2a14a71:	mov    %rdx,%rax
 2a14a74:	add    0x20(%r14),%rax
 2a14a78:	xor    %rdi,%rdi
 2a14a7b:	cmp    %rcx,%rdx
 2a14a7e:	cmova  %rdi,%rax
 2a14a82:	mov    0x18(%rax),%rax
 2a14a86:	mov    %esi,%ecx
 2a14a88:	cmp    %rax,%rcx
 2a14a8b:	jae    2a14a99 <wasm[0]::function[1015]::helper::object_read+0x16939>
 2a14a91:	mov    0x278(%rsp),%r11
 2a14a99:	mov    %rsi,0x198(%rsp)
 2a14aa1:	jmp    2a14baa <wasm[0]::function[1015]::helper::object_read+0x16a4a>
 2a14aa6:	mov    0x88(%rsp),%eax
 2a14aad:	xor    %r11d,%r11d
 2a14ab0:	test   %eax,%eax
 2a14ab2:	je     2a19a0e <wasm[0]::function[1015]::helper::object_read+0x1b8ae>
 2a14ab8:	test   %eax,%eax
 2a14aba:	je     2a19a10 <wasm[0]::function[1015]::helper::object_read+0x1b8b0>
 2a14ac0:	mov    0x2e0(%rsp),%r14
 2a14ac8:	mov    0x28(%r14),%rcx
 2a14acc:	mov    0x20(%r14),%rdx
 2a14ad0:	mov    %eax,%r8d
 2a14ad3:	lea    (%rdx,%r8,1),%rax
 2a14ad7:	xor    %rdi,%rdi
 2a14ada:	cmp    %rcx,%r8
 2a14add:	cmova  %rdi,%rax
 2a14ae1:	mov    0x30(%rax),%eax
 2a14ae4:	test   %eax,%eax
 2a14ae6:	je     2a19a12 <wasm[0]::function[1015]::helper::object_read+0x1b8b2>
 2a14aec:	test   %eax,%eax
 2a14aee:	je     2a19a14 <wasm[0]::function[1015]::helper::object_read+0x1b8b4>
 2a14af4:	mov    %eax,%r9d
 2a14af7:	lea    0x10(%rdx,%r9,1),%rdx
 2a14afc:	cmp    %rcx,%r9
 2a14aff:	cmova  %rdi,%rdx
 2a14b03:	mov    %esi,%ecx
 2a14b05:	mov    (%rdx),%edx
 2a14b07:	cmp    %rdx,%rcx
 2a14b0a:	jb     2a14b1d <wasm[0]::function[1015]::helper::object_read+0x169bd>
 2a14b10:	mov    %rsi,0x198(%rsp)
 2a14b18:	jmp    2a14baa <wasm[0]::function[1015]::helper::object_read+0x16a4a>
 2a14b1d:	mov    0x2e0(%rsp),%r14
 2a14b25:	mov    0x28(%r14),%rcx
 2a14b29:	mov    0x20(%r14),%r8
 2a14b2d:	lea    0x10(%r8,%r9,1),%rdi
 2a14b32:	xor    %rdx,%rdx
 2a14b35:	cmp    %rcx,%r9
 2a14b38:	cmova  %rdx,%rdi
 2a14b3c:	mov    (%rdi),%edi
 2a14b3e:	cmp    %edi,%esi
 2a14b40:	jae    2a19a16 <wasm[0]::function[1015]::helper::object_read+0x1b8b6>
 2a14b46:	mov    %edi,%r9d
 2a14b49:	shl    $0x2,%r9
 2a14b4d:	shr    $0x20,%r9
 2a14b51:	test   %r9,%r9
 2a14b54:	jne    2a19a18 <wasm[0]::function[1015]::helper::object_read+0x1b8b8>
 2a14b5a:	shl    $0x2,%edi
 2a14b5d:	add    $0x14,%edi
 2a14b60:	jb     2a19a1a <wasm[0]::function[1015]::helper::object_read+0x1b8ba>
 2a14b66:	add    %edi,%eax
 2a14b68:	jb     2a19a1c <wasm[0]::function[1015]::helper::object_read+0x1b8bc>
 2a14b6e:	mov    %eax,%r9d
 2a14b71:	lea    (%r8,%r9,1),%rax
 2a14b75:	cmp    %rcx,%r9
 2a14b78:	cmova  %rdx,%rax
 2a14b7c:	mov    %rsi,%rcx
 2a14b7f:	shl    $0x2,%ecx
 2a14b82:	mov    %rsi,0x198(%rsp)
 2a14b8a:	add    $0x14,%ecx
 2a14b90:	sub    %ecx,%edi
 2a14b92:	sub    %rdi,%rax
 2a14b95:	mov    (%rax),%eax
 2a14b97:	xor    %r11d,%r11d
 2a14b9a:	test   %eax,%eax
 2a14b9c:	je     2a14baa <wasm[0]::function[1015]::helper::object_read+0x16a4a>
 2a14ba2:	mov    0x278(%rsp),%r11
 2a14baa:	mov    0x88(%rsp),%eax
 2a14bb1:	mov    0xa8(%rsp),%ecx
 2a14bb8:	mov    0xb0(%rsp),%edx
 2a14bbf:	mov    %rdx,%r15
 2a14bc2:	mov    0xb8(%rsp),%edx
 2a14bc9:	test   %r11d,%r11d
 2a14bcc:	je     2a158fd <wasm[0]::function[1015]::helper::object_read+0x1779d>
 2a14bd2:	mov    0x88(%rsp),%esi
 2a14bd9:	test   %esi,%esi
 2a14bdb:	je     2a19a1e <wasm[0]::function[1015]::helper::object_read+0x1b8be>
 2a14be1:	test   %esi,%esi
 2a14be3:	je     2a19a20 <wasm[0]::function[1015]::helper::object_read+0x1b8c0>
 2a14be9:	mov    0x2e0(%rsp),%r14
 2a14bf1:	mov    0x28(%r14),%rdi
 2a14bf5:	mov    %esi,%r8d
 2a14bf8:	mov    %r8,%rsi
 2a14bfb:	add    0x20(%r14),%rsi
 2a14bff:	xor    %r9,%r9
 2a14c02:	cmp    %rdi,%r8
 2a14c05:	cmova  %r9,%rsi
 2a14c09:	mov    0x24(%rsi),%r8d
 2a14c0d:	cmp    $0x3,%r8d
 2a14c11:	je     2a153b4 <wasm[0]::function[1015]::helper::object_read+0x17254>
 2a14c17:	mov    0x88(%rsp),%eax
 2a14c1e:	test   %eax,%eax
 2a14c20:	je     2a19a22 <wasm[0]::function[1015]::helper::object_read+0x1b8c2>
 2a14c26:	test   %eax,%eax
 2a14c28:	je     2a19a24 <wasm[0]::function[1015]::helper::object_read+0x1b8c4>
 2a14c2e:	mov    0x2e0(%rsp),%r14
 2a14c36:	mov    0x28(%r14),%rcx
 2a14c3a:	mov    0x20(%r14),%rsi
 2a14c3e:	mov    %eax,%edx
 2a14c40:	lea    (%rsi,%rdx,1),%r11
 2a14c44:	xor    %rsi,%rsi
 2a14c47:	cmp    %rcx,%rdx
 2a14c4a:	cmova  %rsi,%r11
 2a14c4e:	mov    0x24(%r11),%esi
 2a14c52:	mov    0xa8(%rsp),%ecx
 2a14c59:	mov    0xb0(%rsp),%edx
 2a14c60:	mov    %rdx,%r15
 2a14c63:	mov    0xb8(%rsp),%edx
 2a14c6a:	cmp    $0x4,%esi
 2a14c6d:	sete   %dil
 2a14c71:	cmp    $0x2,%esi
 2a14c74:	sete   %sil
 2a14c78:	or     %esi,%edi
 2a14c7a:	test   %dil,%dil
 2a14c7d:	je     2a158fd <wasm[0]::function[1015]::helper::object_read+0x1779d>
 2a14c83:	mov    0x88(%rsp),%edx
 2a14c8a:	test   %edx,%edx
 2a14c8c:	je     2a19a26 <wasm[0]::function[1015]::helper::object_read+0x1b8c6>
 2a14c92:	test   %edx,%edx
 2a14c94:	je     2a19a28 <wasm[0]::function[1015]::helper::object_read+0x1b8c8>
 2a14c9a:	mov    0x2e0(%rsp),%r14
 2a14ca2:	mov    0x28(%r14),%rax
 2a14ca6:	mov    0x20(%r14),%rcx
 2a14caa:	mov    %edx,%esi
 2a14cac:	lea    (%rcx,%rsi,1),%rdi
 2a14cb0:	xor    %rdx,%rdx
 2a14cb3:	cmp    %rax,%rsi
 2a14cb6:	cmova  %rdx,%rdi
 2a14cba:	mov    0x28(%rdi),%esi
 2a14cbd:	mov    %esi,0x98(%rsp)
 2a14cc4:	mov    0x2c(%rdi),%edi
 2a14cc7:	mov    %edi,0x90(%rsp)
 2a14cce:	test   %esi,%esi
 2a14cd0:	je     2a19a2a <wasm[0]::function[1015]::helper::object_read+0x1b8ca>
 2a14cd6:	test   %esi,%esi
 2a14cd8:	je     2a19a2c <wasm[0]::function[1015]::helper::object_read+0x1b8cc>
 2a14cde:	mov    %esi,%esi
 2a14ce0:	lea    0x10(%rcx,%rsi,1),%rcx
 2a14ce5:	cmp    %rax,%rsi
 2a14ce8:	cmova  %rdx,%rcx
 2a14cec:	mov    (%rcx),%eax
 2a14cee:	mov    %eax,%r13d
 2a14cf1:	mov    %r13,%rbx
 2a14cf4:	shl    $0x2,%rbx
 2a14cf8:	mov    %rbx,%rcx
 2a14cfb:	shr    $0x20,%rcx
 2a14cff:	test   %rcx,%rcx
 2a14d02:	jne    2a19a2e <wasm[0]::function[1015]::helper::object_read+0x1b8ce>
 2a14d08:	mov    %rax,%rcx
 2a14d0b:	shl    $0x2,%ecx
 2a14d0e:	mov    %rax,0x1e8(%rsp)
 2a14d16:	add    $0x14,%ecx
 2a14d19:	jb     2a19a30 <wasm[0]::function[1015]::helper::object_read+0x1b8d0>
 2a14d1f:	mov    0x268(%rsp),%rax
 2a14d27:	mov    (%rax),%eax
 2a14d29:	mov    %eax,%esi
 2a14d2b:	mov    %ecx,%edx
 2a14d2d:	add    $0xf,%rdx
 2a14d34:	mov    %rdx,%rdi
 2a14d37:	and    $0xfffffffffffffff0,%rdi
 2a14d3b:	add    %rsi,%rdi
 2a14d3e:	mov    0x268(%rsp),%r8
 2a14d46:	mov    0x4(%r8),%r8d
 2a14d4a:	cmp    %r8,%rdi
 2a14d4d:	ja     2a18a23 <wasm[0]::function[1015]::helper::object_read+0x1a8c3>
 2a14d53:	add    $0xf,%ecx
 2a14d59:	and    $0xfffffff0,%ecx
 2a14d5c:	add    %eax,%ecx
 2a14d5e:	mov    0x268(%rsp),%rdi
 2a14d66:	mov    %ecx,(%rdi)
 2a14d68:	mov    0x2e0(%rsp),%r14
 2a14d70:	mov    0x20(%r14),%rdi
 2a14d74:	lea    (%rdi,%rsi,1),%rcx
 2a14d78:	movl   $0xa800000e,(%rdi,%rsi,1)
 2a14d7f:	mov    0x190(%rsp),%r8
 2a14d87:	mov    0x28(%r8),%r8
 2a14d8b:	mov    0x194(%r8),%r8d
 2a14d92:	mov    %r8d,0x4(%rdi,%rsi,1)
 2a14d97:	and    $0xfffffffffffffff0,%rdx
 2a14d9b:	mov    %edx,0x8(%rdi,%rsi,1)
 2a14d9f:	mov    %eax,0xc8(%rsp)
 2a14da6:	mov    0x1e8(%rsp),%rdx
 2a14dae:	mov    %edx,0x10(%rcx)
 2a14db1:	test   %eax,%eax
 2a14db3:	je     2a19a32 <wasm[0]::function[1015]::helper::object_read+0x1b8d2>
 2a14db9:	mov    0x2e0(%rsp),%r14
 2a14dc1:	mov    0x28(%r14),%rcx
 2a14dc5:	mov    0x20(%r14),%rdx
 2a14dc9:	mov    %eax,%esi
 2a14dcb:	lea    (%rdx,%rsi,1),%rax
 2a14dcf:	lea    0x10(%rdx,%rsi,1),%rdi
 2a14dd4:	xor    %r8,%r8
 2a14dd7:	cmp    %rcx,%rsi
 2a14dda:	cmova  %r8,%rdi
 2a14dde:	mov    (%rdi),%edi
 2a14de0:	cmp    %rdi,%r13
 2a14de3:	ja     2a19a34 <wasm[0]::function[1015]::helper::object_read+0x1b8d4>
 2a14de9:	lea    0x14(%rdx,%rsi,1),%r12
 2a14dee:	mov    %r12,%rsi
 2a14df1:	add    %rbx,%rsi
 2a14df4:	jb     2a19a36 <wasm[0]::function[1015]::helper::object_read+0x1b8d6>
 2a14dfa:	add    %rdx,%rcx
 2a14dfd:	cmp    %rcx,%rsi
 2a14e00:	ja     2a19a38 <wasm[0]::function[1015]::helper::object_read+0x1b8d8>
 2a14e06:	mov    0x88(%rsp),%r9d
 2a14e0e:	mov    0x90(%rsp),%r8d
 2a14e16:	mov    0x98(%rsp),%edi
 2a14e1d:	mov    0xa8(%rsp),%ecx
 2a14e24:	mov    0xb0(%rsp),%edx
 2a14e2b:	mov    0xb8(%rsp),%esi
 2a14e32:	lea    0x14(%rax,%r13,4),%rbx
 2a14e37:	test   %r13,%r13
 2a14e3a:	je     2a14ed3 <wasm[0]::function[1015]::helper::object_read+0x16d73>
 2a14e40:	mov    %r9d,0xd8(%rsp)
 2a14e48:	mov    %r8d,0xd0(%rsp)
 2a14e50:	mov    %edi,0x78(%rsp)
 2a14e54:	mov    %ecx,0xc0(%rsp)
 2a14e5b:	mov    %edx,0x98(%rsp)
 2a14e62:	mov    %esi,0x90(%rsp)
 2a14e69:	mov    0x2e8(%rsp),%r15
 2a14e71:	mov    (%r15),%rcx
 2a14e74:	mov    0x228(%rsp),%rax
 2a14e7c:	cmp    %rax,%rcx
 2a14e7f:	jae    2a18a60 <wasm[0]::function[1015]::helper::object_read+0x1a900>
 2a14e85:	jmp    2a14e92 <wasm[0]::function[1015]::helper::object_read+0x16d32>
 2a14e8a:	mov    %rsi,0x228(%rsp)
 2a14e92:	movl   $0x0,(%r12)
 2a14e9a:	mov    0xd8(%rsp),%r9d
 2a14ea2:	mov    0xd0(%rsp),%r8d
 2a14eaa:	mov    0x78(%rsp),%edi
 2a14eae:	mov    0xc0(%rsp),%ecx
 2a14eb5:	mov    0x98(%rsp),%edx
 2a14ebc:	mov    0x90(%rsp),%esi
 2a14ec3:	add    $0x4,%r12
 2a14eca:	cmp    %rbx,%r12
 2a14ecd:	jne    2a14e40 <wasm[0]::function[1015]::helper::object_read+0x16ce0>
 2a14ed3:	mov    %r9d,0x78(%rsp)
 2a14ed8:	mov    %r8d,0xd0(%rsp)
 2a14ee0:	mov    %edi,0xd8(%rsp)
 2a14ee7:	xor    %r13d,%r13d
 2a14eea:	mov    $0xb0000042,%ebx
 2a14eef:	mov    0x190(%rsp),%rax
 2a14ef7:	mov    %rbx,0x1e0(%rsp)
 2a14eff:	mov    0x28(%rax),%rax
 2a14f03:	mov    0x120(%rax),%r12d
 2a14f0a:	mov    $0x20,%ebx
 2a14f0f:	mov    %rbx,0x1d8(%rsp)
 2a14f17:	mov    $0x10,%ebx
 2a14f1c:	mov    $0xb0000072,%edi
 2a14f21:	mov    %rdi,0x1d0(%rsp)
 2a14f29:	mov    0x13c(%rax),%r15d
 2a14f30:	mov    %ecx,0x90(%rsp)
 2a14f37:	mov    %edx,0x98(%rsp)
 2a14f3e:	mov    %esi,0xc0(%rsp)
 2a14f45:	mov    0x2e8(%rsp),%r11
 2a14f4d:	mov    (%r11),%rax
 2a14f50:	mov    0x228(%rsp),%rcx
 2a14f58:	cmp    %rcx,%rax
 2a14f5b:	jae    2a18a8f <wasm[0]::function[1015]::helper::object_read+0x1a92f>
 2a14f61:	mov    0x1e8(%rsp),%rcx
 2a14f69:	jmp    2a14f7e <wasm[0]::function[1015]::helper::object_read+0x16e1e>
 2a14f6e:	mov    %rcx,0x228(%rsp)
 2a14f76:	mov    0x1e8(%rsp),%rcx
 2a14f7e:	cmp    %ecx,%r13d
 2a14f81:	jae    2a15312 <wasm[0]::function[1015]::helper::object_read+0x171b2>
 2a14f87:	mov    0x78(%rsp),%eax
 2a14f8b:	test   %eax,%eax
 2a14f8d:	je     2a19a3a <wasm[0]::function[1015]::helper::object_read+0x1b8da>
 2a14f93:	test   %eax,%eax
 2a14f95:	je     2a19a3c <wasm[0]::function[1015]::helper::object_read+0x1b8dc>
 2a14f9b:	mov    0x2e0(%rsp),%r14
 2a14fa3:	mov    0x28(%r14),%rcx
 2a14fa7:	mov    %eax,%edx
 2a14fa9:	mov    %rdx,%rax
 2a14fac:	add    0x20(%r14),%rax
 2a14fb0:	xor    %rsi,%rsi
 2a14fb3:	cmp    %rcx,%rdx
 2a14fb6:	cmova  %rsi,%rax
 2a14fba:	mov    0x24(%rax),%eax
 2a14fbd:	cmp    $0x4,%eax
 2a14fc0:	je     2a15066 <wasm[0]::function[1015]::helper::object_read+0x16f06>
 2a14fc6:	mov    0xd0(%rsp),%eax
 2a14fcd:	test   %eax,%eax
 2a14fcf:	je     2a19a3e <wasm[0]::function[1015]::helper::object_read+0x1b8de>
 2a14fd5:	test   %eax,%eax
 2a14fd7:	je     2a19a40 <wasm[0]::function[1015]::helper::object_read+0x1b8e0>
 2a14fdd:	mov    0x2e0(%rsp),%r14
 2a14fe5:	mov    0x28(%r14),%rcx
 2a14fe9:	mov    0x20(%r14),%rdx
 2a14fed:	mov    %eax,%r8d
 2a14ff0:	lea    0x10(%rdx,%r8,1),%rdi
 2a14ff5:	xor    %rsi,%rsi
 2a14ff8:	cmp    %rcx,%r8
 2a14ffb:	cmova  %rsi,%rdi
 2a14fff:	mov    (%rdi),%edi
 2a15001:	mov    %r13,%r8
 2a15004:	shr    $0x6,%r8d
 2a15008:	cmp    %edi,%r8d
 2a1500b:	jae    2a19a42 <wasm[0]::function[1015]::helper::object_read+0x1b8e2>
 2a15011:	mov    %edi,%r9d
 2a15014:	shl    $0x3,%r9
 2a15018:	shr    $0x20,%r9
 2a1501c:	test   %r9,%r9
 2a1501f:	jne    2a19a44 <wasm[0]::function[1015]::helper::object_read+0x1b8e4>
 2a15025:	shl    $0x3,%edi
 2a15028:	add    $0x18,%edi
 2a1502b:	jb     2a19a46 <wasm[0]::function[1015]::helper::object_read+0x1b8e6>
 2a15031:	add    %edi,%eax
 2a15033:	jb     2a19a48 <wasm[0]::function[1015]::helper::object_read+0x1b8e8>
 2a15039:	mov    %eax,%r9d
 2a1503c:	lea    (%rdx,%r9,1),%rax
 2a15040:	cmp    %rcx,%r9
 2a15043:	cmova  %rsi,%rax
 2a15047:	shl    $0x3,%r8d
 2a1504b:	lea    0x18(%r8),%ecx
 2a1504f:	sub    %ecx,%edi
 2a15051:	sub    %rdi,%rax
 2a15054:	mov    (%rax),%rax
 2a15057:	bt     %r13,%rax
 2a1505b:	setb   %al
 2a1505e:	movzbl %al,%eax
 2a15061:	jmp    2a150a6 <wasm[0]::function[1015]::helper::object_read+0x16f46>
 2a15066:	mov    0x78(%rsp),%eax
 2a1506a:	test   %eax,%eax
 2a1506c:	je     2a19a4a <wasm[0]::function[1015]::helper::object_read+0x1b8ea>
 2a15072:	test   %eax,%eax
 2a15074:	je     2a19a4c <wasm[0]::function[1015]::helper::object_read+0x1b8ec>
 2a1507a:	mov    0x2e0(%rsp),%r14
 2a15082:	mov    0x28(%r14),%rcx
 2a15086:	mov    %eax,%edx
 2a15088:	mov    %rdx,%rax
 2a1508b:	add    0x20(%r14),%rax
 2a1508f:	xor    %rsi,%rsi
 2a15092:	cmp    %rcx,%rdx
 2a15095:	cmova  %rsi,%rax
 2a15099:	mov    %r13d,%ecx
 2a1509c:	cmp    0x18(%rax),%rcx
 2a150a0:	setb   %al
 2a150a3:	movzbl %al,%eax
 2a150a6:	test   %eax,%eax
 2a150a8:	je     2a152f1 <wasm[0]::function[1015]::helper::object_read+0x17191>
 2a150ae:	mov    0xd8(%rsp),%eax
 2a150b5:	test   %eax,%eax
 2a150b7:	je     2a19a4e <wasm[0]::function[1015]::helper::object_read+0x1b8ee>
 2a150bd:	test   %eax,%eax
 2a150bf:	je     2a19a50 <wasm[0]::function[1015]::helper::object_read+0x1b8f0>
 2a150c5:	mov    0x2e0(%rsp),%r14
 2a150cd:	mov    0x28(%r14),%rcx
 2a150d1:	mov    0x20(%r14),%rdx
 2a150d5:	mov    %eax,%r8d
 2a150d8:	lea    0x10(%rdx,%r8,1),%rdi
 2a150dd:	xor    %rsi,%rsi
 2a150e0:	cmp    %rcx,%r8
 2a150e3:	cmova  %rsi,%rdi
 2a150e7:	mov    (%rdi),%edi
 2a150e9:	cmp    %edi,%r13d
 2a150ec:	jae    2a19a52 <wasm[0]::function[1015]::helper::object_read+0x1b8f2>
 2a150f2:	mov    %edi,%r8d
 2a150f5:	shl    $0x3,%r8
 2a150f9:	shr    $0x20,%r8
 2a150fd:	test   %r8,%r8
 2a15100:	jne    2a19a54 <wasm[0]::function[1015]::helper::object_read+0x1b8f4>
 2a15106:	shl    $0x3,%edi
 2a15109:	add    $0x18,%edi
 2a1510c:	jb     2a19a56 <wasm[0]::function[1015]::helper::object_read+0x1b8f6>
 2a15112:	add    %edi,%eax
 2a15114:	jb     2a19a58 <wasm[0]::function[1015]::helper::object_read+0x1b8f8>
 2a1511a:	mov    %eax,%r8d
 2a1511d:	add    %r8,%rdx
 2a15120:	cmp    %rcx,%r8
 2a15123:	cmova  %rsi,%rdx
 2a15127:	mov    %r13,%r8
 2a1512a:	shl    $0x3,%r8d
 2a1512e:	add    $0x18,%r8d
 2a15135:	sub    %r8d,%edi
 2a15138:	sub    %rdi,%rdx
 2a1513b:	mov    (%rdx),%r14
 2a1513e:	movl   $0x0,0xe0(%rsp)
 2a15149:	mov    0x268(%rsp),%rcx
 2a15151:	mov    (%rcx),%eax
 2a15153:	mov    %eax,%r9d
 2a15156:	lea    0x20(%r9),%r10
 2a1515a:	mov    0x4(%rcx),%r11d
 2a1515e:	cmp    %r11,%r10
 2a15161:	ja     2a18ac6 <wasm[0]::function[1015]::helper::object_read+0x1a966>
 2a15167:	lea    0x20(%rax),%ecx
 2a1516a:	mov    0x268(%rsp),%rdx
 2a15172:	mov    %ecx,(%rdx)
 2a15174:	mov    0x2e0(%rsp),%rcx
 2a1517c:	mov    0x20(%rcx),%rdx
 2a15180:	lea    (%rdx,%r9,1),%rcx
 2a15184:	movl   $0xb0000042,(%rdx,%r9,1)
 2a1518c:	mov    %r12d,0x4(%rdx,%r9,1)
 2a15191:	mov    0x260(%rsp),%rsi
 2a15199:	mov    %esi,0x8(%rdx,%r9,1)
 2a1519e:	mov    %eax,0xe8(%rsp)
 2a151a5:	mov    %r14,0x10(%rcx)
 2a151a9:	movl   $0x3,0x18(%rcx)
 2a151b0:	mov    0xe0(%rsp),%edx
 2a151b7:	mov    %edx,0x1c(%rcx)
 2a151ba:	mov    0x190(%rsp),%rsi
 2a151c2:	mov    0xa20(%rsi),%ecx
 2a151c8:	mov    %ecx,0xe0(%rsp)
 2a151cf:	test   %eax,%eax
 2a151d1:	je     2a19a5a <wasm[0]::function[1015]::helper::object_read+0x1b8fa>
 2a151d7:	test   %ecx,%ecx
 2a151d9:	je     2a19a5c <wasm[0]::function[1015]::helper::object_read+0x1b8fc>
 2a151df:	mov    0x268(%rsp),%rcx
 2a151e7:	mov    (%rcx),%eax
 2a151e9:	mov    %eax,%ecx
 2a151eb:	lea    0x20(%rcx),%rdx
 2a151ef:	mov    0x268(%rsp),%rsi
 2a151f7:	mov    0x4(%rsi),%esi
 2a151fa:	cmp    %rsi,%rdx
 2a151fd:	ja     2a18afc <wasm[0]::function[1015]::helper::object_read+0x1a99c>
 2a15203:	lea    0x20(%rax),%edx
 2a15206:	mov    0x268(%rsp),%r11
 2a1520e:	mov    %edx,(%r11)
 2a15211:	mov    0x2e0(%rsp),%r14
 2a15219:	mov    0x20(%r14),%rdx
 2a1521d:	lea    (%rdx,%rcx,1),%rsi
 2a15221:	movl   $0xb0000072,(%rdx,%rcx,1)
 2a15228:	mov    %r15d,0x4(%rdx,%rcx,1)
 2a1522d:	mov    0x260(%rsp),%rdi
 2a15235:	mov    %edi,0x8(%rdx,%rcx,1)
 2a15239:	movl   $0xe,0x10(%rsi)
 2a15240:	mov    0xe8(%rsp),%ecx
 2a15247:	mov    %ecx,0x14(%rsi)
 2a1524a:	mov    0xe0(%rsp),%ecx
 2a15251:	mov    %ecx,0x18(%rsi)
 2a15254:	mov    %ecx,0x1c(%rsi)
 2a15257:	mov    0xc8(%rsp),%ecx
 2a1525e:	test   %ecx,%ecx
 2a15260:	je     2a19a5e <wasm[0]::function[1015]::helper::object_read+0x1b8fe>
 2a15266:	test   %eax,%eax
 2a15268:	je     2a19a60 <wasm[0]::function[1015]::helper::object_read+0x1b900>
 2a1526e:	test   %ecx,%ecx
 2a15270:	je     2a19a62 <wasm[0]::function[1015]::helper::object_read+0x1b902>
 2a15276:	mov    0x2e0(%rsp),%r14
 2a1527e:	mov    0x28(%r14),%rdx
 2a15282:	mov    0x20(%r14),%rsi
 2a15286:	mov    %ecx,%r9d
 2a15289:	lea    0x10(%rsi,%r9,1),%r8
 2a1528e:	xor    %rdi,%rdi
 2a15291:	cmp    %rdx,%r9
 2a15294:	cmova  %rdi,%r8
 2a15298:	mov    (%r8),%r8d
 2a1529b:	cmp    %r8d,%r13d
 2a1529e:	jae    2a19a64 <wasm[0]::function[1015]::helper::object_read+0x1b904>
 2a152a4:	mov    %r8d,%r9d
 2a152a7:	shl    $0x2,%r9
 2a152ab:	shr    $0x20,%r9
 2a152af:	test   %r9,%r9
 2a152b2:	jne    2a19a66 <wasm[0]::function[1015]::helper::object_read+0x1b906>
 2a152b8:	shl    $0x2,%r8d
 2a152bc:	add    $0x14,%r8d
 2a152c0:	jb     2a19a68 <wasm[0]::function[1015]::helper::object_read+0x1b908>
 2a152c6:	add    %r8d,%ecx
 2a152c9:	jb     2a19a6a <wasm[0]::function[1015]::helper::object_read+0x1b90a>
 2a152cf:	mov    %ecx,%r9d
 2a152d2:	lea    (%rsi,%r9,1),%rcx
 2a152d6:	cmp    %rdx,%r9
 2a152d9:	cmova  %rdi,%rcx
 2a152dd:	mov    %r13,%rdx
 2a152e0:	shl    $0x2,%edx
 2a152e3:	add    $0x14,%edx
 2a152e9:	sub    %edx,%r8d
 2a152ec:	sub    %r8,%rcx
 2a152ef:	mov    %eax,(%rcx)
 2a152f1:	mov    0x90(%rsp),%ecx
 2a152f8:	mov    0x98(%rsp),%edx
 2a152ff:	mov    0xc0(%rsp),%esi
 2a15306:	add    $0x1,%r13d
 2a1530d:	jmp    2a14f30 <wasm[0]::function[1015]::helper::object_read+0x16dd0>
 2a15312:	mov    0x78(%rsp),%eax
 2a15316:	test   %eax,%eax
 2a15318:	je     2a19a6c <wasm[0]::function[1015]::helper::object_read+0x1b90c>
 2a1531e:	mov    0xc8(%rsp),%edx
 2a15325:	test   %edx,%edx
 2a15327:	je     2a19a6e <wasm[0]::function[1015]::helper::object_read+0x1b90e>
 2a1532d:	test   %eax,%eax
 2a1532f:	je     2a19a70 <wasm[0]::function[1015]::helper::object_read+0x1b910>
 2a15335:	mov    0x2e0(%rsp),%r14
 2a1533d:	mov    0x28(%r14),%rsi
 2a15341:	mov    0x20(%r14),%rcx
 2a15345:	mov    %eax,%edi
 2a15347:	add    %rdi,%rcx
 2a1534a:	xor    %r8,%r8
 2a1534d:	cmp    %rsi,%rdi
 2a15350:	cmova  %r8,%rcx
 2a15354:	mov    %edx,0x20(%rcx)
 2a15357:	mov    0x190(%rsp),%rsi
 2a1535f:	mov    0xa00(%rsi),%esi
 2a15365:	mov    0x190(%rsp),%rdx
 2a1536d:	mov    0xa10(%rdx),%edx
 2a15373:	test   %esi,%esi
 2a15375:	je     2a19a72 <wasm[0]::function[1015]::helper::object_read+0x1b912>
 2a1537b:	mov    %esi,0x28(%rcx)
 2a1537e:	test   %edx,%edx
 2a15380:	je     2a19a74 <wasm[0]::function[1015]::helper::object_read+0x1b914>
 2a15386:	mov    %edx,0x2c(%rcx)
 2a15389:	movl   $0x0,0x30(%rcx)
 2a15390:	movl   $0x0,0x24(%rcx)
 2a15397:	mov    0x90(%rsp),%ecx
 2a1539e:	mov    0x98(%rsp),%edx
 2a153a5:	mov    %rdx,%r15
 2a153a8:	mov    0xc0(%rsp),%edx
 2a153af:	jmp    2a158fd <wasm[0]::function[1015]::helper::object_read+0x1779d>
 2a153b4:	mov    0x88(%rsp),%r10d
 2a153bc:	test   %r10d,%r10d
 2a153bf:	je     2a19a76 <wasm[0]::function[1015]::helper::object_read+0x1b916>
 2a153c5:	test   %r10d,%r10d
 2a153c8:	je     2a19a78 <wasm[0]::function[1015]::helper::object_read+0x1b918>
 2a153ce:	mov    0x2e0(%rsp),%r14
 2a153d6:	mov    0x28(%r14),%rax
 2a153da:	mov    0x20(%r14),%rcx
 2a153de:	mov    %r10d,%esi
 2a153e1:	lea    (%rcx,%rsi,1),%r11
 2a153e5:	xor    %rdx,%rdx
 2a153e8:	cmp    %rax,%rsi
 2a153eb:	cmova  %rdx,%r11
 2a153ef:	mov    0x30(%r11),%esi
 2a153f3:	mov    %esi,0x78(%rsp)
 2a153f7:	test   %esi,%esi
 2a153f9:	je     2a19a7a <wasm[0]::function[1015]::helper::object_read+0x1b91a>
 2a153ff:	test   %esi,%esi
 2a15401:	je     2a19a7c <wasm[0]::function[1015]::helper::object_read+0x1b91c>
 2a15407:	mov    %esi,%esi
 2a15409:	lea    0x10(%rcx,%rsi,1),%rcx
 2a1540e:	cmp    %rax,%rsi
 2a15411:	cmova  %rdx,%rcx
 2a15415:	mov    (%rcx),%r12d
 2a15418:	mov    %r12d,%ebx
 2a1541b:	mov    %rbx,%r14
 2a1541e:	shl    $0x2,%r14
 2a15422:	mov    %r14,%rax
 2a15425:	shr    $0x20,%rax
 2a15429:	test   %rax,%rax
 2a1542c:	jne    2a19a7e <wasm[0]::function[1015]::helper::object_read+0x1b91e>
 2a15432:	mov    %r12,%rcx
 2a15435:	shl    $0x2,%ecx
 2a15438:	add    $0x14,%ecx
 2a1543b:	jb     2a19a80 <wasm[0]::function[1015]::helper::object_read+0x1b920>
 2a15441:	mov    0x268(%rsp),%rsi
 2a15449:	mov    (%rsi),%eax
 2a1544b:	mov    %eax,%edx
 2a1544d:	mov    %ecx,%esi
 2a1544f:	add    $0xf,%rsi
 2a15456:	mov    %rsi,%rdi
 2a15459:	and    $0xfffffffffffffff0,%rdi
 2a1545d:	add    %rdx,%rdi
 2a15460:	mov    0x268(%rsp),%r8
 2a15468:	mov    0x4(%r8),%r8d
 2a1546c:	cmp    %r8,%rdi
 2a1546f:	ja     2a18b32 <wasm[0]::function[1015]::helper::object_read+0x1a9d2>
 2a15475:	add    $0xf,%ecx
 2a1547b:	and    $0xfffffff0,%ecx
 2a1547e:	add    %eax,%ecx
 2a15480:	mov    0x268(%rsp),%rdi
 2a15488:	mov    %ecx,(%rdi)
 2a1548a:	mov    0x2e0(%rsp),%rcx
 2a15492:	mov    0x20(%rcx),%rdi
 2a15496:	lea    (%rdi,%rdx,1),%rcx
 2a1549a:	movl   $0xa800000e,(%rdi,%rdx,1)
 2a154a1:	mov    0x190(%rsp),%r8
 2a154a9:	mov    0x28(%r8),%r8
 2a154ad:	mov    0x194(%r8),%r8d
 2a154b4:	mov    %r8d,0x4(%rdi,%rdx,1)
 2a154b9:	and    $0xfffffffffffffff0,%rsi
 2a154bd:	mov    %esi,0x8(%rdi,%rdx,1)
 2a154c1:	mov    %eax,0x90(%rsp)
 2a154c8:	mov    %r12d,0x10(%rcx)
 2a154cc:	test   %eax,%eax
 2a154ce:	je     2a19a82 <wasm[0]::function[1015]::helper::object_read+0x1b922>
 2a154d4:	mov    0x2e0(%rsp),%rcx
 2a154dc:	mov    0x28(%rcx),%rcx
 2a154e0:	mov    0x2e0(%rsp),%rdx
 2a154e8:	mov    0x20(%rdx),%rsi
 2a154ec:	mov    %eax,%eax
 2a154ee:	lea    (%rsi,%rax,1),%rdx
 2a154f2:	lea    0x10(%rsi,%rax,1),%rdi
 2a154f7:	xor    %r8,%r8
 2a154fa:	cmp    %rcx,%rax
 2a154fd:	cmova  %r8,%rdi
 2a15501:	mov    (%rdi),%edi
 2a15503:	cmp    %rdi,%rbx
 2a15506:	ja     2a19a84 <wasm[0]::function[1015]::helper::object_read+0x1b924>
 2a1550c:	lea    0x14(%rsi,%rax,1),%r13
 2a15511:	mov    %r13,%rax
 2a15514:	add    %r14,%rax
 2a15517:	jb     2a19a86 <wasm[0]::function[1015]::helper::object_read+0x1b926>
 2a1551d:	add    %rsi,%rcx
 2a15520:	cmp    %rcx,%rax
 2a15523:	ja     2a19a88 <wasm[0]::function[1015]::helper::object_read+0x1b928>
 2a15529:	mov    0x78(%rsp),%esi
 2a1552d:	mov    0x88(%rsp),%r8d
 2a15535:	mov    0xa8(%rsp),%r10d
 2a1553d:	mov    0xb0(%rsp),%eax
 2a15544:	mov    0xb8(%rsp),%ecx
 2a1554b:	lea    0x14(%rdx,%rbx,4),%r14
 2a15550:	test   %rbx,%rbx
 2a15553:	je     2a155de <wasm[0]::function[1015]::helper::object_read+0x1747e>
 2a15559:	mov    %esi,0xb8(%rsp)
 2a15560:	mov    %r8d,0xb0(%rsp)
 2a15568:	mov    %r10d,0xa8(%rsp)
 2a15570:	mov    %eax,0x88(%rsp)
 2a15577:	mov    %ecx,0x78(%rsp)
 2a1557b:	mov    0x2e8(%rsp),%r15
 2a15583:	mov    (%r15),%rax
 2a15586:	mov    0x228(%rsp),%rcx
 2a1558e:	cmp    %rcx,%rax
 2a15591:	jae    2a18b6f <wasm[0]::function[1015]::helper::object_read+0x1aa0f>
 2a15597:	jmp    2a155a4 <wasm[0]::function[1015]::helper::object_read+0x17444>
 2a1559c:	mov    %rcx,0x228(%rsp)
 2a155a4:	movl   $0x0,0x0(%r13)
 2a155ac:	mov    0xb8(%rsp),%esi
 2a155b3:	mov    0xb0(%rsp),%r8d
 2a155bb:	mov    0xa8(%rsp),%r10d
 2a155c3:	mov    0x88(%rsp),%eax
 2a155ca:	mov    0x78(%rsp),%ecx
 2a155ce:	add    $0x4,%r13
 2a155d5:	cmp    %r14,%r13
 2a155d8:	jne    2a15559 <wasm[0]::function[1015]::helper::object_read+0x173f9>
 2a155de:	mov    %esi,0xb8(%rsp)
 2a155e5:	mov    0x190(%rsp),%rsi
 2a155ed:	mov    0xa20(%rsi),%edx
 2a155f3:	mov    %edx,0xb0(%rsp)
 2a155fa:	xor    %ebx,%ebx
 2a155fc:	mov    $0xb0000072,%r15d
 2a15602:	mov    %r15,0x1d0(%rsp)
 2a1560a:	mov    0x28(%rsi),%rdx
 2a1560e:	mov    0x13c(%rdx),%r13d
 2a15615:	mov    $0x20,%edx
 2a1561a:	mov    %rdx,0x1c8(%rsp)
 2a15622:	mov    $0x10,%edx
 2a15627:	mov    %rdx,0x1a0(%rsp)
 2a1562f:	mov    %r8d,0x98(%rsp)
 2a15637:	mov    %r10d,0x78(%rsp)
 2a1563c:	mov    %eax,0x88(%rsp)
 2a15643:	mov    %ecx,0xa8(%rsp)
 2a1564a:	mov    0x2e8(%rsp),%r15
 2a15652:	mov    (%r15),%rdi
 2a15655:	mov    0x228(%rsp),%rax
 2a1565d:	cmp    %rax,%rdi
 2a15660:	jae    2a18b9e <wasm[0]::function[1015]::helper::object_read+0x1aa3e>
 2a15666:	jmp    2a15673 <wasm[0]::function[1015]::helper::object_read+0x17513>
 2a1566b:	mov    %r10,0x228(%rsp)
 2a15673:	cmp    %r12d,%ebx
 2a15676:	jae    2a15860 <wasm[0]::function[1015]::helper::object_read+0x17700>
 2a1567c:	mov    0xb8(%rsp),%edx
 2a15683:	test   %edx,%edx
 2a15685:	je     2a19a8a <wasm[0]::function[1015]::helper::object_read+0x1b92a>
 2a1568b:	test   %edx,%edx
 2a1568d:	je     2a19a8c <wasm[0]::function[1015]::helper::object_read+0x1b92c>
 2a15693:	mov    0x2e0(%rsp),%r14
 2a1569b:	mov    0x28(%r14),%rax
 2a1569f:	mov    0x20(%r14),%rcx
 2a156a3:	mov    %edx,%r8d
 2a156a6:	lea    0x10(%rcx,%r8,1),%rdi
 2a156ab:	xor    %rsi,%rsi
 2a156ae:	cmp    %rax,%r8
 2a156b1:	cmova  %rsi,%rdi
 2a156b5:	mov    (%rdi),%r9d
 2a156b8:	cmp    %r9d,%ebx
 2a156bb:	jae    2a19a8e <wasm[0]::function[1015]::helper::object_read+0x1b92e>
 2a156c1:	mov    %r9d,%edi
 2a156c4:	shl    $0x2,%rdi
 2a156c8:	shr    $0x20,%rdi
 2a156cc:	test   %rdi,%rdi
 2a156cf:	jne    2a19a90 <wasm[0]::function[1015]::helper::object_read+0x1b930>
 2a156d5:	shl    $0x2,%r9d
 2a156d9:	add    $0x14,%r9d
 2a156dd:	jb     2a19a92 <wasm[0]::function[1015]::helper::object_read+0x1b932>
 2a156e3:	add    %r9d,%edx
 2a156e6:	jb     2a19a94 <wasm[0]::function[1015]::helper::object_read+0x1b934>
 2a156ec:	mov    %edx,%edx
 2a156ee:	add    %rdx,%rcx
 2a156f1:	cmp    %rax,%rdx
 2a156f4:	cmova  %rsi,%rcx
 2a156f8:	mov    %rbx,%r15
 2a156fb:	shl    $0x2,%r15d
 2a156ff:	lea    0x14(%r15),%eax
 2a15703:	sub    %eax,%r9d
 2a15706:	sub    %r9,%rcx
 2a15709:	mov    (%rcx),%eax
 2a1570b:	mov    %eax,0xc0(%rsp)
 2a15712:	test   %eax,%eax
 2a15714:	je     2a1583a <wasm[0]::function[1015]::helper::object_read+0x176da>
 2a1571a:	test   %eax,%eax
 2a1571c:	je     2a19a96 <wasm[0]::function[1015]::helper::object_read+0x1b936>
 2a15722:	mov    0xb0(%rsp),%eax
 2a15729:	test   %eax,%eax
 2a1572b:	je     2a19a98 <wasm[0]::function[1015]::helper::object_read+0x1b938>
 2a15731:	mov    0x268(%rsp),%rcx
 2a15739:	mov    (%rcx),%eax
 2a1573b:	mov    %eax,%edx
 2a1573d:	lea    0x20(%rdx),%rcx
 2a15741:	mov    0x268(%rsp),%rsi
 2a15749:	mov    0x4(%rsi),%esi
 2a1574c:	cmp    %rsi,%rcx
 2a1574f:	ja     2a18bcd <wasm[0]::function[1015]::helper::object_read+0x1aa6d>
 2a15755:	lea    0x20(%rax),%ecx
 2a15758:	mov    0x268(%rsp),%rsi
 2a15760:	mov    %ecx,(%rsi)
 2a15762:	mov    0x2e0(%rsp),%r14
 2a1576a:	mov    0x20(%r14),%rsi
 2a1576e:	lea    (%rsi,%rdx,1),%rcx
 2a15772:	movl   $0xb0000072,(%rsi,%rdx,1)
 2a15779:	mov    %r13d,0x4(%rsi,%rdx,1)
 2a1577e:	mov    0x260(%rsp),%rdi
 2a15786:	mov    %edi,0x8(%rsi,%rdx,1)
 2a1578a:	movl   $0xe,0x10(%rcx)
 2a15791:	mov    0xc0(%rsp),%edx
 2a15798:	mov    %edx,0x14(%rcx)
 2a1579b:	mov    0xb0(%rsp),%edx
 2a157a2:	mov    %edx,0x18(%rcx)
 2a157a5:	mov    %edx,0x1c(%rcx)
 2a157a8:	mov    0x90(%rsp),%ecx
 2a157af:	test   %ecx,%ecx
 2a157b1:	je     2a19a9a <wasm[0]::function[1015]::helper::object_read+0x1b93a>
 2a157b7:	test   %eax,%eax
 2a157b9:	je     2a19a9c <wasm[0]::function[1015]::helper::object_read+0x1b93c>
 2a157bf:	test   %ecx,%ecx
 2a157c1:	je     2a19a9e <wasm[0]::function[1015]::helper::object_read+0x1b93e>
 2a157c7:	mov    0x2e0(%rsp),%r14
 2a157cf:	mov    0x28(%r14),%rdx
 2a157d3:	mov    0x20(%r14),%rsi
 2a157d7:	mov    %ecx,%r9d
 2a157da:	lea    0x10(%rsi,%r9,1),%r8
 2a157df:	xor    %rdi,%rdi
 2a157e2:	cmp    %rdx,%r9
 2a157e5:	cmova  %rdi,%r8
 2a157e9:	mov    (%r8),%r8d
 2a157ec:	cmp    %r8d,%ebx
 2a157ef:	jae    2a19aa0 <wasm[0]::function[1015]::helper::object_read+0x1b940>
 2a157f5:	mov    %r8d,%r9d
 2a157f8:	shl    $0x2,%r9
 2a157fc:	shr    $0x20,%r9
 2a15800:	test   %r9,%r9
 2a15803:	jne    2a19aa2 <wasm[0]::function[1015]::helper::object_read+0x1b942>
 2a15809:	shl    $0x2,%r8d
 2a1580d:	add    $0x14,%r8d
 2a15811:	jb     2a19aa4 <wasm[0]::function[1015]::helper::object_read+0x1b944>
 2a15817:	add    %r8d,%ecx
 2a1581a:	jb     2a19aa6 <wasm[0]::function[1015]::helper::object_read+0x1b946>
 2a15820:	mov    %ecx,%r9d
 2a15823:	lea    (%rsi,%r9,1),%rcx
 2a15827:	cmp    %rdx,%r9
 2a1582a:	cmova  %rdi,%rcx
 2a1582e:	lea    0x14(%r15),%edx
 2a15832:	sub    %edx,%r8d
 2a15835:	sub    %r8,%rcx
 2a15838:	mov    %eax,(%rcx)
 2a1583a:	mov    0x98(%rsp),%r8d
 2a15842:	mov    0x78(%rsp),%r10d
 2a15847:	mov    0x88(%rsp),%eax
 2a1584e:	mov    0xa8(%rsp),%ecx
 2a15855:	add    $0x1,%ebx
 2a1585b:	jmp    2a1562f <wasm[0]::function[1015]::helper::object_read+0x174cf>
 2a15860:	mov    0x98(%rsp),%eax
 2a15867:	test   %eax,%eax
 2a15869:	je     2a19aa8 <wasm[0]::function[1015]::helper::object_read+0x1b948>
 2a1586f:	mov    0x90(%rsp),%edi
 2a15876:	test   %edi,%edi
 2a15878:	je     2a19aaa <wasm[0]::function[1015]::helper::object_read+0x1b94a>
 2a1587e:	test   %eax,%eax
 2a15880:	je     2a19aac <wasm[0]::function[1015]::helper::object_read+0x1b94c>
 2a15886:	mov    0x2e0(%rsp),%r14
 2a1588e:	mov    0x28(%r14),%r8
 2a15892:	mov    0x20(%r14),%r10
 2a15896:	mov    %eax,%r9d
 2a15899:	lea    (%r10,%r9,1),%rsi
 2a1589d:	xor    %r10,%r10
 2a158a0:	cmp    %r8,%r9
 2a158a3:	cmova  %r10,%rsi
 2a158a7:	mov    %edi,0x20(%rsi)
 2a158aa:	mov    0x190(%rsp),%rdi
 2a158b2:	mov    0xa00(%rdi),%r11d
 2a158b9:	mov    0xa10(%rdi),%r10d
 2a158c0:	test   %r11d,%r11d
 2a158c3:	je     2a19aae <wasm[0]::function[1015]::helper::object_read+0x1b94e>
 2a158c9:	mov    %r11d,0x28(%rsi)
 2a158cd:	test   %r10d,%r10d
 2a158d0:	je     2a19ab0 <wasm[0]::function[1015]::helper::object_read+0x1b950>
 2a158d6:	mov    %r10d,0x2c(%rsi)
 2a158da:	movl   $0x0,0x30(%rsi)
 2a158e1:	movl   $0x0,0x24(%rsi)
 2a158e8:	mov    0x78(%rsp),%ecx
 2a158ec:	mov    0x88(%rsp),%edx
 2a158f3:	mov    %rdx,%r15
 2a158f6:	mov    0xa8(%rsp),%edx
 2a158fd:	test   %eax,%eax
 2a158ff:	je     2a19ab2 <wasm[0]::function[1015]::helper::object_read+0x1b952>
 2a15905:	test   %eax,%eax
 2a15907:	je     2a19ab4 <wasm[0]::function[1015]::helper::object_read+0x1b954>
 2a1590d:	mov    0x2e0(%rsp),%r14
 2a15915:	mov    0x28(%r14),%r8
 2a15919:	mov    0x20(%r14),%r10
 2a1591d:	mov    %eax,%eax
 2a1591f:	lea    (%r10,%rax,1),%r9
 2a15923:	xor    %r11,%r11
 2a15926:	cmp    %r8,%rax
 2a15929:	cmova  %r11,%r9
 2a1592d:	mov    0x10(%r9),%edi
 2a15931:	test   %edi,%edi
 2a15933:	je     2a19ab6 <wasm[0]::function[1015]::helper::object_read+0x1b956>
 2a15939:	test   %edi,%edi
 2a1593b:	je     2a19ab8 <wasm[0]::function[1015]::helper::object_read+0x1b958>
 2a15941:	mov    %edi,%esi
 2a15943:	lea    0x10(%r10,%rsi,1),%r10
 2a15948:	cmp    %r8,%rsi
 2a1594b:	cmova  %r11,%r10
 2a1594f:	mov    (%r10),%r11d
 2a15952:	mov    0x24(%r9),%r8d
 2a15956:	test   %r8d,%r8d
 2a15959:	je     2a15b57 <wasm[0]::function[1015]::helper::object_read+0x179f7>
 2a1595f:	xor    %eax,%eax
 2a15961:	test   %r11d,%r11d
 2a15964:	je     2a15c23 <wasm[0]::function[1015]::helper::object_read+0x17ac3>
 2a1596a:	mov    0x2e0(%rsp),%r14
 2a15972:	mov    0x28(%r14),%rax
 2a15976:	mov    0x20(%r14),%r10
 2a1597a:	lea    0x10(%r10,%rsi,1),%r9
 2a1597f:	xor    %r8,%r8
 2a15982:	cmp    %rax,%rsi
 2a15985:	cmova  %r8,%r9
 2a15989:	mov    (%r9),%r9d
 2a1598c:	mov    0x198(%rsp),%rsi
 2a15994:	mov    %rsi,%rbx
 2a15997:	shr    $0x10,%ebx
 2a1599a:	mov    %rsi,%r12
 2a1599d:	xor    %ebx,%r12d
 2a159a0:	imul   $0x7feb352d,%r12d,%ebx
 2a159a7:	mov    %rbx,%r12
 2a159aa:	shr    $0xf,%r12d
 2a159ae:	xor    %r12d,%ebx
 2a159b1:	imul   $0x846ca68b,%ebx,%ebx
 2a159b7:	mov    %rbx,%r12
 2a159ba:	shr    $0x10,%r12d
 2a159be:	xor    %r12d,%ebx
 2a159c1:	sub    $0x1,%r11d
 2a159c5:	and    %r11d,%ebx
 2a159c8:	cmp    %r9d,%ebx
 2a159cb:	jae    2a19aba <wasm[0]::function[1015]::helper::object_read+0x1b95a>
 2a159d1:	mov    %r9d,%r11d
 2a159d4:	shl    $0x2,%r11
 2a159d8:	shr    $0x20,%r11
 2a159dc:	test   %r11,%r11
 2a159df:	jne    2a19abc <wasm[0]::function[1015]::helper::object_read+0x1b95c>
 2a159e5:	shl    $0x2,%r9d
 2a159e9:	add    $0x14,%r9d
 2a159ed:	jb     2a19abe <wasm[0]::function[1015]::helper::object_read+0x1b95e>
 2a159f3:	add    %r9d,%edi
 2a159f6:	jb     2a19ac0 <wasm[0]::function[1015]::helper::object_read+0x1b960>
 2a159fc:	mov    %edi,%r11d
 2a159ff:	lea    (%r10,%r11,1),%rdi
 2a15a03:	cmp    %rax,%r11
 2a15a06:	cmova  %r8,%rdi
 2a15a0a:	shl    $0x2,%ebx
 2a15a0d:	lea    0x14(%rbx),%eax
 2a15a10:	sub    %eax,%r9d
 2a15a13:	sub    %r9,%rdi
 2a15a16:	mov    (%rdi),%eax
 2a15a18:	xor    %edi,%edi
 2a15a1a:	mov    %esi,%ebx
 2a15a1c:	mov    %eax,0x90(%rsp)
 2a15a23:	mov    %edi,0xa8(%rsp)
 2a15a2a:	mov    %ecx,0x88(%rsp)
 2a15a31:	mov    %r15,%rax
 2a15a34:	mov    %eax,0x78(%rsp)
 2a15a38:	mov    %edx,0x98(%rsp)
 2a15a3f:	mov    0x2e8(%rsp),%r15
 2a15a47:	mov    (%r15),%rax
 2a15a4a:	mov    0x228(%rsp),%rcx
 2a15a52:	cmp    %rcx,%rax
 2a15a55:	jae    2a18c08 <wasm[0]::function[1015]::helper::object_read+0x1aaa8>
 2a15a5b:	jmp    2a15a68 <wasm[0]::function[1015]::helper::object_read+0x17908>
 2a15a60:	mov    %rcx,0x228(%rsp)
 2a15a68:	mov    0x90(%rsp),%ecx
 2a15a6f:	mov    0xa8(%rsp),%eax
 2a15a76:	test   %ecx,%ecx
 2a15a78:	je     2a15b3d <wasm[0]::function[1015]::helper::object_read+0x179dd>
 2a15a7e:	mov    0x90(%rsp),%ecx
 2a15a85:	test   %ecx,%ecx
 2a15a87:	je     2a19ac2 <wasm[0]::function[1015]::helper::object_read+0x1b962>
 2a15a8d:	mov    0x2e0(%rsp),%r14
 2a15a95:	mov    0x28(%r14),%rax
 2a15a99:	mov    %ecx,%edx
 2a15a9b:	mov    %rdx,%rcx
 2a15a9e:	add    0x20(%r14),%rcx
 2a15aa2:	xor    %rsi,%rsi
 2a15aa5:	cmp    %rax,%rdx
 2a15aa8:	cmova  %rsi,%rcx
 2a15aac:	mov    0x10(%rcx),%rax
 2a15ab0:	cmp    %rbx,%rax
 2a15ab3:	je     2a15b0b <wasm[0]::function[1015]::helper::object_read+0x179ab>
 2a15ab9:	mov    0x90(%rsp),%edx
 2a15ac0:	test   %edx,%edx
 2a15ac2:	je     2a19ac4 <wasm[0]::function[1015]::helper::object_read+0x1b964>
 2a15ac8:	mov    0x2e0(%rsp),%r14
 2a15ad0:	mov    0x28(%r14),%rsi
 2a15ad4:	mov    %edx,%edi
 2a15ad6:	mov    %rdi,%rcx
 2a15ad9:	add    0x20(%r14),%rcx
 2a15add:	xor    %r8,%r8
 2a15ae0:	cmp    %rsi,%rdi
 2a15ae3:	cmova  %r8,%rcx
 2a15ae7:	mov    0x1c(%rcx),%eax
 2a15aea:	mov    0xa8(%rsp),%edi
 2a15af1:	mov    0x88(%rsp),%ecx
 2a15af8:	mov    0x78(%rsp),%edx
 2a15afc:	mov    %rdx,%r15
 2a15aff:	mov    0x98(%rsp),%edx
 2a15b06:	jmp    2a15a1c <wasm[0]::function[1015]::helper::object_read+0x178bc>
 2a15b0b:	mov    0x90(%rsp),%esi
 2a15b12:	test   %esi,%esi
 2a15b14:	je     2a19ac6 <wasm[0]::function[1015]::helper::object_read+0x1b966>
 2a15b1a:	mov    0x2e0(%rsp),%r14
 2a15b22:	mov    0x28(%r14),%r8
 2a15b26:	mov    %esi,%r9d
 2a15b29:	mov    %r9,%rsi
 2a15b2c:	add    0x20(%r14),%rsi
 2a15b30:	xor    %r10,%r10
 2a15b33:	cmp    %r8,%r9
 2a15b36:	cmova  %r10,%rsi
 2a15b3a:	mov    0x18(%rsi),%eax
 2a15b3d:	mov    0x88(%rsp),%ecx
 2a15b44:	mov    0x78(%rsp),%edx
 2a15b48:	mov    %rdx,%r15
 2a15b4b:	mov    0x98(%rsp),%edx
 2a15b52:	jmp    2a15c23 <wasm[0]::function[1015]::helper::object_read+0x17ac3>
 2a15b57:	mov    0x198(%rsp),%rsi
 2a15b5f:	mov    0x2e0(%rsp),%r14
 2a15b67:	mov    0x28(%r14),%r8
 2a15b6b:	mov    0x20(%r14),%r10
 2a15b6f:	lea    (%r10,%rax,1),%r11
 2a15b73:	xor    %r9,%r9
 2a15b76:	cmp    %r8,%rax
 2a15b79:	cmova  %r9,%r11
 2a15b7d:	mov    0x20(%r11),%edi
 2a15b81:	xor    %eax,%eax
 2a15b83:	test   %edi,%edi
 2a15b85:	je     2a19ac8 <wasm[0]::function[1015]::helper::object_read+0x1b968>
 2a15b8b:	test   %edi,%edi
 2a15b8d:	je     2a19aca <wasm[0]::function[1015]::helper::object_read+0x1b96a>
 2a15b93:	mov    %edi,%r11d
 2a15b96:	lea    0x10(%r10,%r11,1),%r10
 2a15b9b:	cmp    %r8,%r11
 2a15b9e:	cmova  %r9,%r10
 2a15ba2:	mov    %esi,%r8d
 2a15ba5:	mov    (%r10),%r9d
 2a15ba8:	cmp    %r9,%r8
 2a15bab:	jae    2a15c23 <wasm[0]::function[1015]::helper::object_read+0x17ac3>
 2a15bb1:	mov    0x2e0(%rsp),%r14
 2a15bb9:	mov    0x28(%r14),%rax
 2a15bbd:	mov    0x20(%r14),%r9
 2a15bc1:	lea    0x10(%r9,%r11,1),%r10
 2a15bc6:	xor    %r8,%r8
 2a15bc9:	cmp    %rax,%r11
 2a15bcc:	cmova  %r8,%r10
 2a15bd0:	mov    (%r10),%r10d
 2a15bd3:	cmp    %r10d,%esi
 2a15bd6:	jae    2a19acc <wasm[0]::function[1015]::helper::object_read+0x1b96c>
 2a15bdc:	mov    %r10d,%r11d
 2a15bdf:	shl    $0x2,%r11
 2a15be3:	shr    $0x20,%r11
 2a15be7:	test   %r11,%r11
 2a15bea:	jne    2a19ace <wasm[0]::function[1015]::helper::object_read+0x1b96e>
 2a15bf0:	shl    $0x2,%r10d
 2a15bf4:	add    $0x14,%r10d
 2a15bf8:	jb     2a19ad0 <wasm[0]::function[1015]::helper::object_read+0x1b970>
 2a15bfe:	add    %r10d,%edi
 2a15c01:	jb     2a19ad2 <wasm[0]::function[1015]::helper::object_read+0x1b972>
 2a15c07:	mov    %edi,%r11d
 2a15c0a:	lea    (%r9,%r11,1),%rdi
 2a15c0e:	cmp    %rax,%r11
 2a15c11:	cmova  %r8,%rdi
 2a15c15:	shl    $0x2,%esi
 2a15c18:	lea    0x14(%rsi),%eax
 2a15c1b:	sub    %eax,%r10d
 2a15c1e:	sub    %r10,%rdi
 2a15c21:	mov    (%rdi),%eax
 2a15c23:	mov    %ecx,0x78(%rsp)
 2a15c27:	mov    %edx,0x88(%rsp)
 2a15c2e:	test   %eax,%eax
 2a15c30:	je     2a15f5e <wasm[0]::function[1015]::helper::object_read+0x17dfe>
 2a15c36:	test   %eax,%eax
 2a15c38:	jne    2a15c46 <wasm[0]::function[1015]::helper::object_read+0x17ae6>
 2a15c3e:	xor    %r13d,%r13d
 2a15c41:	jmp    2a15c7d <wasm[0]::function[1015]::helper::object_read+0x17b1d>
 2a15c46:	test   %eax,%eax
 2a15c48:	je     2a19ad4 <wasm[0]::function[1015]::helper::object_read+0x1b974>
 2a15c4e:	mov    0x2e0(%rsp),%r14
 2a15c56:	mov    0x28(%r14),%rcx
 2a15c5a:	mov    %eax,%esi
 2a15c5c:	mov    %rsi,%rdx
 2a15c5f:	add    0x20(%r14),%rdx
 2a15c63:	xor    %rdi,%rdi
 2a15c66:	cmp    %rcx,%rsi
 2a15c69:	cmova  %rdi,%rdx
 2a15c6d:	mov    0x10(%rdx),%ecx
 2a15c70:	test   $0x4,%ecx
 2a15c76:	setne  %cl
 2a15c79:	movzbl %cl,%r13d
 2a15c7d:	test   %eax,%eax
 2a15c7f:	jne    2a15c8c <wasm[0]::function[1015]::helper::object_read+0x17b2c>
 2a15c85:	xor    %ebx,%ebx
 2a15c87:	jmp    2a15cc2 <wasm[0]::function[1015]::helper::object_read+0x17b62>
 2a15c8c:	test   %eax,%eax
 2a15c8e:	je     2a19ad6 <wasm[0]::function[1015]::helper::object_read+0x1b976>
 2a15c94:	mov    0x2e0(%rsp),%r14
 2a15c9c:	mov    0x28(%r14),%rcx
 2a15ca0:	mov    %eax,%esi
 2a15ca2:	mov    %rsi,%rdx
 2a15ca5:	add    0x20(%r14),%rdx
 2a15ca9:	xor    %rdi,%rdi
 2a15cac:	cmp    %rcx,%rsi
 2a15caf:	cmova  %rdi,%rdx
 2a15cb3:	mov    0x10(%rdx),%ecx
 2a15cb6:	test   $0x8,%ecx
 2a15cbc:	setne  %cl
 2a15cbf:	movzbl %cl,%ebx
 2a15cc2:	test   %eax,%eax
 2a15cc4:	jne    2a15cd2 <wasm[0]::function[1015]::helper::object_read+0x17b72>
 2a15cca:	xor    %r12d,%r12d
 2a15ccd:	jmp    2a15d09 <wasm[0]::function[1015]::helper::object_read+0x17ba9>
 2a15cd2:	test   %eax,%eax
 2a15cd4:	je     2a19ad8 <wasm[0]::function[1015]::helper::object_read+0x1b978>
 2a15cda:	mov    0x2e0(%rsp),%r14
 2a15ce2:	mov    0x28(%r14),%rcx
 2a15ce6:	mov    %eax,%esi
 2a15ce8:	mov    %rsi,%rdx
 2a15ceb:	add    0x20(%r14),%rdx
 2a15cef:	xor    %rdi,%rdi
 2a15cf2:	cmp    %rcx,%rsi
 2a15cf5:	cmova  %rdi,%rdx
 2a15cf9:	mov    0x10(%rdx),%ecx
 2a15cfc:	test   $0x2,%ecx
 2a15d02:	setne  %cl
 2a15d05:	movzbl %cl,%r12d
 2a15d09:	test   %eax,%eax
 2a15d0b:	je     2a19ada <wasm[0]::function[1015]::helper::object_read+0x1b97a>
 2a15d11:	mov    0x2e0(%rsp),%r14
 2a15d19:	mov    0x28(%r14),%rsi
 2a15d1d:	mov    0x20(%r14),%rdx
 2a15d21:	mov    %eax,%ecx
 2a15d23:	add    %rcx,%rdx
 2a15d26:	xor    %rdi,%rdi
 2a15d29:	cmp    %rsi,%rcx
 2a15d2c:	cmova  %rdi,%rdx
 2a15d30:	mov    0x14(%rdx),%esi
 2a15d33:	mov    %esi,0x98(%rsp)
 2a15d3a:	mov    0x18(%rdx),%esi
 2a15d3d:	mov    %esi,0x90(%rsp)
 2a15d44:	mov    0x1c(%rdx),%esi
 2a15d47:	mov    %esi,0xa8(%rsp)
 2a15d4e:	test   %eax,%eax
 2a15d50:	jne    2a15d5d <wasm[0]::function[1015]::helper::object_read+0x17bfd>
 2a15d56:	xor    %eax,%eax
 2a15d58:	jmp    2a15d8d <wasm[0]::function[1015]::helper::object_read+0x17c2d>
 2a15d5d:	mov    0x2e0(%rsp),%r14
 2a15d65:	mov    0x28(%r14),%r8
 2a15d69:	mov    %rcx,%rsi
 2a15d6c:	add    0x20(%r14),%rsi
 2a15d70:	xor    %r9,%r9
 2a15d73:	cmp    %r8,%rcx
 2a15d76:	cmova  %r9,%rsi
 2a15d7a:	mov    0x10(%rsi),%r9d
 2a15d7e:	test   $0x1,%r9d
 2a15d85:	setne  %r10b
 2a15d89:	movzbl %r10b,%eax
 2a15d8d:	test   %eax,%eax
 2a15d8f:	jne    2a15e82 <wasm[0]::function[1015]::helper::object_read+0x17d22>
 2a15d95:	mov    0x98(%rsp),%eax
 2a15d9c:	test   %eax,%eax
 2a15d9e:	je     2a19adc <wasm[0]::function[1015]::helper::object_read+0x1b97c>
 2a15da4:	mov    0x90(%rsp),%eax
 2a15dab:	test   %eax,%eax
 2a15dad:	je     2a19ade <wasm[0]::function[1015]::helper::object_read+0x1b97e>
 2a15db3:	mov    0xa8(%rsp),%eax
 2a15dba:	test   %eax,%eax
 2a15dbc:	je     2a19ae0 <wasm[0]::function[1015]::helper::object_read+0x1b980>
 2a15dc2:	mov    0x268(%rsp),%rcx
 2a15dca:	mov    (%rcx),%eax
 2a15dcc:	mov    %rax,%r15
 2a15dcf:	mov    %eax,%ecx
 2a15dd1:	lea    0x20(%rcx),%rax
 2a15dd5:	mov    0x268(%rsp),%r8
 2a15ddd:	mov    0x4(%r8),%edx
 2a15de1:	cmp    %rdx,%rax
 2a15de4:	ja     2a18c37 <wasm[0]::function[1015]::helper::object_read+0x1aad7>
 2a15dea:	mov    %r15,%rax
 2a15ded:	add    $0x20,%eax
 2a15df3:	mov    0x268(%rsp),%rdx
 2a15dfb:	mov    %eax,(%rdx)
 2a15dfd:	mov    0x2e0(%rsp),%r14
 2a15e05:	mov    0x20(%r14),%rdx
 2a15e09:	lea    (%rdx,%rcx,1),%rax
 2a15e0d:	movl   $0xb0000072,(%rdx,%rcx,1)
 2a15e14:	mov    0x190(%rsp),%rsi
 2a15e1c:	mov    0x28(%rsi),%rsi
 2a15e20:	mov    0x13c(%rsi),%esi
 2a15e26:	mov    %esi,0x4(%rdx,%rcx,1)
 2a15e2a:	mov    0x260(%rsp),%rsi
 2a15e32:	mov    %esi,0x8(%rdx,%rcx,1)
 2a15e36:	test   %r13d,%r13d
 2a15e39:	setne  %cl
 2a15e3c:	movzbl %cl,%ecx
 2a15e3f:	shl    $0x2,%ecx
 2a15e42:	test   %ebx,%ebx
 2a15e44:	setne  %dl
 2a15e47:	movzbl %dl,%edx
 2a15e4a:	shl    $0x3,%edx
 2a15e4d:	or     %edx,%ecx
 2a15e4f:	test   %r12d,%r12d
 2a15e52:	setne  %dl
 2a15e55:	movzbl %dl,%edx
 2a15e58:	shl    $1,%edx
 2a15e5a:	or     %edx,%ecx
 2a15e5c:	mov    %ecx,0x10(%rax)
 2a15e5f:	mov    0x98(%rsp),%ecx
 2a15e66:	mov    %ecx,0x14(%rax)
 2a15e69:	mov    0x90(%rsp),%ecx
 2a15e70:	mov    %ecx,0x18(%rax)
 2a15e73:	mov    0xa8(%rsp),%ecx
 2a15e7a:	mov    %ecx,0x1c(%rax)
 2a15e7d:	jmp    2a15f5e <wasm[0]::function[1015]::helper::object_read+0x17dfe>
 2a15e82:	mov    0x98(%rsp),%eax
 2a15e89:	test   %eax,%eax
 2a15e8b:	je     2a19ae2 <wasm[0]::function[1015]::helper::object_read+0x1b982>
 2a15e91:	mov    0x90(%rsp),%eax
 2a15e98:	test   %eax,%eax
 2a15e9a:	je     2a19ae4 <wasm[0]::function[1015]::helper::object_read+0x1b984>
 2a15ea0:	mov    0xa8(%rsp),%eax
 2a15ea7:	test   %eax,%eax
 2a15ea9:	je     2a19ae6 <wasm[0]::function[1015]::helper::object_read+0x1b986>
 2a15eaf:	mov    0x268(%rsp),%rcx
 2a15eb7:	mov    (%rcx),%eax
 2a15eb9:	mov    %rax,%r15
 2a15ebc:	mov    %eax,%ecx
 2a15ebe:	lea    0x20(%rcx),%rax
 2a15ec2:	mov    0x268(%rsp),%rsi
 2a15eca:	mov    0x4(%rsi),%edx
 2a15ecd:	cmp    %rdx,%rax
 2a15ed0:	ja     2a18c7c <wasm[0]::function[1015]::helper::object_read+0x1ab1c>
 2a15ed6:	mov    %r15,%rax
 2a15ed9:	add    $0x20,%eax
 2a15edf:	mov    0x268(%rsp),%rdx
 2a15ee7:	mov    %eax,(%rdx)
 2a15ee9:	mov    0x2e0(%rsp),%r14
 2a15ef1:	mov    0x20(%r14),%rdx
 2a15ef5:	lea    (%rdx,%rcx,1),%rax
 2a15ef9:	movl   $0xb0000072,(%rdx,%rcx,1)
 2a15f00:	mov    0x190(%rsp),%rsi
 2a15f08:	mov    0x28(%rsi),%rsi
 2a15f0c:	mov    0x13c(%rsi),%esi
 2a15f12:	mov    %esi,0x4(%rdx,%rcx,1)
 2a15f16:	mov    0x260(%rsp),%rsi
 2a15f1e:	mov    %esi,0x8(%rdx,%rcx,1)
 2a15f22:	test   %ebx,%ebx
 2a15f24:	setne  %cl
 2a15f27:	movzbl %cl,%ecx
 2a15f2a:	shl    $0x3,%ecx
 2a15f2d:	or     $0x1,%ecx
 2a15f30:	test   %r12d,%r12d
 2a15f33:	setne  %dl
 2a15f36:	movzbl %dl,%edx
 2a15f39:	shl    $1,%edx
 2a15f3b:	or     %edx,%ecx
 2a15f3d:	mov    %ecx,0x10(%rax)
 2a15f40:	mov    0x98(%rsp),%ecx
 2a15f47:	mov    %ecx,0x14(%rax)
 2a15f4a:	mov    0x90(%rsp),%ecx
 2a15f51:	mov    %ecx,0x18(%rax)
 2a15f54:	mov    0xa8(%rsp),%ecx
 2a15f5b:	mov    %ecx,0x1c(%rax)
 2a15f5e:	mov    0x78(%rsp),%eax
 2a15f62:	mov    0x88(%rsp),%ecx
 2a15f69:	jmp    2a16337 <wasm[0]::function[1015]::helper::object_read+0x181d7>
 2a15f6e:	xor    %eax,%eax
 2a15f70:	test   %edx,%edx
 2a15f72:	je     2a15fc3 <wasm[0]::function[1015]::helper::object_read+0x17e63>
 2a15f78:	xor    %eax,%eax
 2a15f7a:	test   $0x1,%edx
 2a15f80:	jne    2a15fc3 <wasm[0]::function[1015]::helper::object_read+0x17e63>
 2a15f86:	mov    0x2e0(%rsp),%r14
 2a15f8e:	mov    0x28(%r14),%rsi
 2a15f92:	mov    0x20(%r14),%r8
 2a15f96:	mov    %edx,%edi
 2a15f98:	lea    0x4(%r8,%rdi,1),%rax
 2a15f9d:	xor    %r8,%r8
 2a15fa0:	cmp    %rsi,%rdi
 2a15fa3:	cmova  %r8,%rax
 2a15fa7:	mov    (%rax),%esi
 2a15fa9:	mov    0x190(%rsp),%rdi
 2a15fb1:	mov    0x28(%rdi),%rdi
 2a15fb5:	cmp    0x138(%rdi),%esi
 2a15fbb:	sete   %sil
 2a15fbf:	movzbl %sil,%eax
 2a15fc3:	test   %eax,%eax
 2a15fc5:	je     2a19ae8 <wasm[0]::function[1015]::helper::object_read+0x1b988>
 2a15fcb:	test   %edx,%edx
 2a15fcd:	je     2a19aea <wasm[0]::function[1015]::helper::object_read+0x1b98a>
 2a15fd3:	mov    0x68(%rsp),%r9d
 2a15fd8:	mov    0x1b8(%rsp),%rcx
 2a15fe0:	mov    0x1c0(%rsp),%r8
 2a15fe8:	mov    0x190(%rsp),%rsi
 2a15ff0:	mov    0x190(%rsp),%rdi
 2a15ff8:	call   2a1cf20 <wasm[0]::function[1019]::helper::ordinary_own_descriptor>
 2a15ffd:	mov    0xa0(%rsp),%ecx
 2a16004:	mov    %rcx,%r15
 2a16007:	test   %eax,%eax
 2a16009:	je     2a1632c <wasm[0]::function[1015]::helper::object_read+0x181cc>
 2a1600f:	test   %eax,%eax
 2a16011:	jne    2a1601e <wasm[0]::function[1015]::helper::object_read+0x17ebe>
 2a16017:	xor    %ebx,%ebx
 2a16019:	jmp    2a16054 <wasm[0]::function[1015]::helper::object_read+0x17ef4>
 2a1601e:	test   %eax,%eax
 2a16020:	je     2a19aec <wasm[0]::function[1015]::helper::object_read+0x1b98c>
 2a16026:	mov    0x2e0(%rsp),%r14
 2a1602e:	mov    0x28(%r14),%rcx
 2a16032:	mov    %eax,%esi
 2a16034:	mov    %rsi,%rdx
 2a16037:	add    0x20(%r14),%rdx
 2a1603b:	xor    %rdi,%rdi
 2a1603e:	cmp    %rcx,%rsi
 2a16041:	cmova  %rdi,%rdx
 2a16045:	mov    0x10(%rdx),%ecx
 2a16048:	test   $0x4,%ecx
 2a1604e:	setne  %cl
 2a16051:	movzbl %cl,%ebx
 2a16054:	test   %eax,%eax
 2a16056:	jne    2a16064 <wasm[0]::function[1015]::helper::object_read+0x17f04>
 2a1605c:	xor    %r13d,%r13d
 2a1605f:	jmp    2a1609b <wasm[0]::function[1015]::helper::object_read+0x17f3b>
 2a16064:	test   %eax,%eax
 2a16066:	je     2a19aee <wasm[0]::function[1015]::helper::object_read+0x1b98e>
 2a1606c:	mov    0x2e0(%rsp),%r14
 2a16074:	mov    0x28(%r14),%rcx
 2a16078:	mov    %eax,%esi
 2a1607a:	mov    %rsi,%rdx
 2a1607d:	add    0x20(%r14),%rdx
 2a16081:	xor    %rdi,%rdi
 2a16084:	cmp    %rcx,%rsi
 2a16087:	cmova  %rdi,%rdx
 2a1608b:	mov    0x10(%rdx),%ecx
 2a1608e:	test   $0x8,%ecx
 2a16094:	setne  %cl
 2a16097:	movzbl %cl,%r13d
 2a1609b:	test   %eax,%eax
 2a1609d:	jne    2a160ab <wasm[0]::function[1015]::helper::object_read+0x17f4b>
 2a160a3:	xor    %r12d,%r12d
 2a160a6:	jmp    2a160e2 <wasm[0]::function[1015]::helper::object_read+0x17f82>
 2a160ab:	test   %eax,%eax
 2a160ad:	je     2a19af0 <wasm[0]::function[1015]::helper::object_read+0x1b990>
 2a160b3:	mov    0x2e0(%rsp),%r14
 2a160bb:	mov    0x28(%r14),%rcx
 2a160bf:	mov    %eax,%esi
 2a160c1:	mov    %rsi,%rdx
 2a160c4:	add    0x20(%r14),%rdx
 2a160c8:	xor    %rdi,%rdi
 2a160cb:	cmp    %rcx,%rsi
 2a160ce:	cmova  %rdi,%rdx
 2a160d2:	mov    0x10(%rdx),%ecx
 2a160d5:	test   $0x2,%ecx
 2a160db:	setne  %cl
 2a160de:	movzbl %cl,%r12d
 2a160e2:	test   %eax,%eax
 2a160e4:	je     2a19af2 <wasm[0]::function[1015]::helper::object_read+0x1b992>
 2a160ea:	mov    0x2e0(%rsp),%r14
 2a160f2:	mov    0x28(%r14),%rsi
 2a160f6:	mov    0x20(%r14),%rdx
 2a160fa:	mov    %eax,%ecx
 2a160fc:	add    %rcx,%rdx
 2a160ff:	xor    %rdi,%rdi
 2a16102:	cmp    %rsi,%rcx
 2a16105:	cmova  %rdi,%rdx
 2a16109:	mov    0x14(%rdx),%esi
 2a1610c:	mov    %esi,0xa0(%rsp)
 2a16113:	mov    0x18(%rdx),%esi
 2a16116:	mov    %esi,0x78(%rsp)
 2a1611a:	mov    0x1c(%rdx),%edx
 2a1611d:	mov    %edx,0x88(%rsp)
 2a16124:	test   %eax,%eax
 2a16126:	jne    2a16133 <wasm[0]::function[1015]::helper::object_read+0x17fd3>
 2a1612c:	xor    %eax,%eax
 2a1612e:	jmp    2a1615e <wasm[0]::function[1015]::helper::object_read+0x17ffe>
 2a16133:	mov    0x2e0(%rsp),%r14
 2a1613b:	mov    0x28(%r14),%rdx
 2a1613f:	mov    %rcx,%rax
 2a16142:	add    0x20(%r14),%rax
 2a16146:	xor    %rsi,%rsi
 2a16149:	cmp    %rdx,%rcx
 2a1614c:	cmova  %rsi,%rax
 2a16150:	mov    0x10(%rax),%eax
 2a16153:	test   $0x1,%eax
 2a16158:	setne  %al
 2a1615b:	movzbl %al,%eax
 2a1615e:	test   %eax,%eax
 2a16160:	jne    2a16250 <wasm[0]::function[1015]::helper::object_read+0x180f0>
 2a16166:	mov    0xa0(%rsp),%eax
 2a1616d:	test   %eax,%eax
 2a1616f:	je     2a19af4 <wasm[0]::function[1015]::helper::object_read+0x1b994>
 2a16175:	mov    0x78(%rsp),%eax
 2a16179:	test   %eax,%eax
 2a1617b:	je     2a19af6 <wasm[0]::function[1015]::helper::object_read+0x1b996>
 2a16181:	mov    0x88(%rsp),%eax
 2a16188:	test   %eax,%eax
 2a1618a:	je     2a19af8 <wasm[0]::function[1015]::helper::object_read+0x1b998>
 2a16190:	mov    0x268(%rsp),%rcx
 2a16198:	mov    (%rcx),%eax
 2a1619a:	mov    %rax,%r15
 2a1619d:	mov    %eax,%ecx
 2a1619f:	lea    0x20(%rcx),%rax
 2a161a3:	mov    0x268(%rsp),%rdx
 2a161ab:	mov    0x4(%rdx),%edx
 2a161ae:	cmp    %rdx,%rax
 2a161b1:	ja     2a18cc1 <wasm[0]::function[1015]::helper::object_read+0x1ab61>
 2a161b7:	mov    %r15,%rax
 2a161ba:	add    $0x20,%eax
 2a161c0:	mov    0x268(%rsp),%rdx
 2a161c8:	mov    %eax,(%rdx)
 2a161ca:	mov    0x2e0(%rsp),%r14
 2a161d2:	mov    0x20(%r14),%rdx
 2a161d6:	lea    (%rdx,%rcx,1),%rax
 2a161da:	movl   $0xb0000072,(%rdx,%rcx,1)
 2a161e1:	mov    0x190(%rsp),%rsi
 2a161e9:	mov    0x28(%rsi),%rsi
 2a161ed:	mov    0x13c(%rsi),%esi
 2a161f3:	mov    %esi,0x4(%rdx,%rcx,1)
 2a161f7:	mov    0x260(%rsp),%rsi
 2a161ff:	mov    %esi,0x8(%rdx,%rcx,1)
 2a16203:	test   %ebx,%ebx
 2a16205:	setne  %dl
 2a16208:	movzbl %dl,%ecx
 2a1620b:	shl    $0x2,%ecx
 2a1620e:	test   %r13d,%r13d
 2a16211:	setne  %sil
 2a16215:	movzbl %sil,%edx
 2a16219:	shl    $0x3,%edx
 2a1621c:	or     %edx,%ecx
 2a1621e:	test   %r12d,%r12d
 2a16221:	setne  %sil
 2a16225:	movzbl %sil,%esi
 2a16229:	shl    $1,%esi
 2a1622b:	or     %esi,%ecx
 2a1622d:	mov    %ecx,0x10(%rax)
 2a16230:	mov    0xa0(%rsp),%esi
 2a16237:	mov    %esi,0x14(%rax)
 2a1623a:	mov    0x78(%rsp),%esi
 2a1623e:	mov    %esi,0x18(%rax)
 2a16241:	mov    0x88(%rsp),%edi
 2a16248:	mov    %edi,0x1c(%rax)
 2a1624b:	jmp    2a1632c <wasm[0]::function[1015]::helper::object_read+0x181cc>
 2a16250:	mov    0xa0(%rsp),%r9d
 2a16258:	test   %r9d,%r9d
 2a1625b:	je     2a19afa <wasm[0]::function[1015]::helper::object_read+0x1b99a>
 2a16261:	mov    0x78(%rsp),%r11d
 2a16266:	test   %r11d,%r11d
 2a16269:	je     2a19afc <wasm[0]::function[1015]::helper::object_read+0x1b99c>
 2a1626f:	mov    0x88(%rsp),%eax
 2a16276:	test   %eax,%eax
 2a16278:	je     2a19afe <wasm[0]::function[1015]::helper::object_read+0x1b99e>
 2a1627e:	mov    0x268(%rsp),%rcx
 2a16286:	mov    (%rcx),%eax
 2a16288:	mov    %rax,%r15
 2a1628b:	mov    %eax,%ecx
 2a1628d:	lea    0x20(%rcx),%rax
 2a16291:	mov    0x268(%rsp),%rdx
 2a16299:	mov    0x4(%rdx),%edx
 2a1629c:	cmp    %rdx,%rax
 2a1629f:	ja     2a18cfe <wasm[0]::function[1015]::helper::object_read+0x1ab9e>
 2a162a5:	mov    %r15,%rax
 2a162a8:	add    $0x20,%eax
 2a162ae:	mov    0x268(%rsp),%r10
 2a162b6:	mov    %eax,(%r10)
 2a162b9:	mov    0x2e0(%rsp),%r14
 2a162c1:	mov    0x20(%r14),%rdx
 2a162c5:	lea    (%rdx,%rcx,1),%rax
 2a162c9:	movl   $0xb0000072,(%rdx,%rcx,1)
 2a162d0:	mov    0x190(%rsp),%rsi
 2a162d8:	mov    0x28(%rsi),%rsi
 2a162dc:	mov    0x13c(%rsi),%esi
 2a162e2:	mov    %esi,0x4(%rdx,%rcx,1)
 2a162e6:	mov    0x260(%rsp),%rsi
 2a162ee:	mov    %esi,0x8(%rdx,%rcx,1)
 2a162f2:	test   %r13d,%r13d
 2a162f5:	setne  %cl
 2a162f8:	movzbl %cl,%ecx
 2a162fb:	shl    $0x3,%ecx
 2a162fe:	or     $0x1,%ecx
 2a16301:	test   %r12d,%r12d
 2a16304:	setne  %dl
 2a16307:	movzbl %dl,%edx
 2a1630a:	shl    $1,%edx
 2a1630c:	or     %edx,%ecx
 2a1630e:	mov    %ecx,0x10(%rax)
 2a16311:	mov    0xa0(%rsp),%ecx
 2a16318:	mov    %ecx,0x14(%rax)
 2a1631b:	mov    0x78(%rsp),%ecx
 2a1631f:	mov    %ecx,0x18(%rax)
 2a16322:	mov    0x88(%rsp),%ecx
 2a16329:	mov    %ecx,0x1c(%rax)
 2a1632c:	mov    0x80(%rsp),%eax
 2a16333:	mov    0x50(%rsp),%ecx
 2a16337:	mov    %eax,0x78(%rsp)
 2a1633b:	mov    %ecx,0x88(%rsp)
 2a16342:	mov    %r15,%rax
 2a16345:	mov    %r15,%rdx
 2a16348:	test   %edx,%eax
 2a1634a:	jne    2a16357 <wasm[0]::function[1015]::helper::object_read+0x181f7>
 2a16350:	xor    %eax,%eax
 2a16352:	jmp    2a16396 <wasm[0]::function[1015]::helper::object_read+0x18236>
 2a16357:	mov    %r15,%rax
 2a1635a:	mov    %r15,%r9
 2a1635d:	test   %r9d,%eax
 2a16360:	je     2a19b00 <wasm[0]::function[1015]::helper::object_read+0x1b9a0>
 2a16366:	mov    0x2e0(%rsp),%r14
 2a1636e:	mov    0x28(%r14),%rax
 2a16372:	mov    %r15,%rcx
 2a16375:	mov    %ecx,%edx
 2a16377:	mov    %rdx,%rcx
 2a1637a:	add    0x20(%r14),%rcx
 2a1637e:	xor    %rsi,%rsi
 2a16381:	cmp    %rax,%rdx
 2a16384:	cmova  %rsi,%rcx
 2a16388:	mov    0x10(%rcx),%eax
 2a1638b:	test   $0x2,%eax
 2a16390:	setne  %al
 2a16393:	movzbl %al,%eax
 2a16396:	mov    0x78(%rsp),%edx
 2a1639a:	xor    %esi,%esi
 2a1639c:	mov    %r15,%rcx
 2a1639f:	mov    %r15,%rdi
 2a163a2:	test   %edi,%ecx
 2a163a4:	setne  %cl
 2a163a7:	test   %eax,%eax
 2a163a9:	sete   %al
 2a163ac:	test   %cl,%al
 2a163ae:	jne    2a163c1 <wasm[0]::function[1015]::helper::object_read+0x18261>
 2a163b4:	mov    %rsi,0x298(%rsp)
 2a163bc:	jmp    2a1715c <wasm[0]::function[1015]::helper::object_read+0x18ffc>
 2a163c1:	mov    %r15,%rax
 2a163c4:	mov    %r15,%rcx
 2a163c7:	test   %ecx,%eax
 2a163c9:	jne    2a163d6 <wasm[0]::function[1015]::helper::object_read+0x18276>
 2a163cf:	xor    %eax,%eax
 2a163d1:	jmp    2a16411 <wasm[0]::function[1015]::helper::object_read+0x182b1>
 2a163d6:	mov    %r15,%rax
 2a163d9:	mov    %r15,%rcx
 2a163dc:	test   %ecx,%eax
 2a163de:	je     2a19b02 <wasm[0]::function[1015]::helper::object_read+0x1b9a2>
 2a163e4:	mov    0x2e0(%rsp),%r14
 2a163ec:	mov    0x28(%r14),%rax
 2a163f0:	mov    %ecx,%edx
 2a163f2:	mov    %rdx,%rcx
 2a163f5:	add    0x20(%r14),%rcx
 2a163f9:	xor    %rsi,%rsi
 2a163fc:	cmp    %rax,%rdx
 2a163ff:	cmova  %rsi,%rcx
 2a16403:	mov    0x10(%rcx),%eax
 2a16406:	test   $0x1,%eax
 2a1640b:	setne  %al
 2a1640e:	movzbl %al,%eax
 2a16411:	test   %eax,%eax
 2a16413:	jne    2a16e3a <wasm[0]::function[1015]::helper::object_read+0x18cda>
 2a16419:	mov    %r15,%rax
 2a1641c:	mov    %r15,%rcx
 2a1641f:	test   %ecx,%eax
 2a16421:	jne    2a1642e <wasm[0]::function[1015]::helper::object_read+0x182ce>
 2a16427:	xor    %eax,%eax
 2a16429:	jmp    2a1646d <wasm[0]::function[1015]::helper::object_read+0x1830d>
 2a1642e:	mov    %r15,%rax
 2a16431:	mov    %r15,%r8
 2a16434:	test   %r8d,%eax
 2a16437:	je     2a19b04 <wasm[0]::function[1015]::helper::object_read+0x1b9a4>
 2a1643d:	mov    0x2e0(%rsp),%r14
 2a16445:	mov    0x28(%r14),%rax
 2a16449:	mov    %r15,%rcx
 2a1644c:	mov    %ecx,%edx
 2a1644e:	mov    %rdx,%rcx
 2a16451:	add    0x20(%r14),%rcx
 2a16455:	xor    %rsi,%rsi
 2a16458:	cmp    %rax,%rdx
 2a1645b:	cmova  %rsi,%rcx
 2a1645f:	mov    0x10(%rcx),%eax
 2a16462:	test   $0x4,%eax
 2a16467:	setne  %cl
 2a1646a:	movzbl %cl,%eax
 2a1646d:	mov    0x78(%rsp),%edx
 2a16471:	xor    %esi,%esi
 2a16473:	test   %eax,%eax
 2a16475:	je     2a16488 <wasm[0]::function[1015]::helper::object_read+0x18328>
 2a1647b:	mov    %rsi,0x298(%rsp)
 2a16483:	jmp    2a1715c <wasm[0]::function[1015]::helper::object_read+0x18ffc>
 2a16488:	xor    %edx,%edx
 2a1648a:	xor    %rax,%rax
 2a1648d:	mov    %r15,%rcx
 2a16490:	mov    %r15,%rsi
 2a16493:	test   %esi,%ecx
 2a16495:	jne    2a164ab <wasm[0]::function[1015]::helper::object_read+0x1834b>
 2a1649b:	mov    %rdx,%rcx
 2a1649e:	mov    0x280(%rsp),%r9
 2a164a6:	jmp    2a16614 <wasm[0]::function[1015]::helper::object_read+0x184b4>
 2a164ab:	mov    %r15,%rax
 2a164ae:	mov    %r15,%rcx
 2a164b1:	test   %ecx,%eax
 2a164b3:	je     2a19b06 <wasm[0]::function[1015]::helper::object_read+0x1b9a6>
 2a164b9:	mov    0x2e0(%rsp),%r14
 2a164c1:	mov    0x28(%r14),%r10
 2a164c5:	mov    0x20(%r14),%rax
 2a164c9:	mov    %ecx,%r11d
 2a164cc:	lea    (%rax,%r11,1),%rdi
 2a164d0:	xor    %rax,%rax
 2a164d3:	cmp    %r10,%r11
 2a164d6:	cmova  %rax,%rdi
 2a164da:	mov    0x14(%rdi),%edx
 2a164dd:	test   %edx,%edx
 2a164df:	je     2a19b08 <wasm[0]::function[1015]::helper::object_read+0x1b9a8>
 2a164e5:	xor    %edi,%edi
 2a164e7:	test   $0x1,%edx
 2a164ed:	jne    2a1652f <wasm[0]::function[1015]::helper::object_read+0x183cf>
 2a164f3:	mov    0x2e0(%rsp),%r14
 2a164fb:	mov    0x28(%r14),%rax
 2a164ff:	mov    0x20(%r14),%rcx
 2a16503:	mov    %edx,%esi
 2a16505:	lea    0x4(%rcx,%rsi,1),%rcx
 2a1650a:	xor    %rdi,%rdi
 2a1650d:	cmp    %rax,%rsi
 2a16510:	cmova  %rdi,%rcx
 2a16514:	mov    (%rcx),%eax
 2a16516:	mov    0x190(%rsp),%rsi
 2a1651e:	mov    0x28(%rsi),%rcx
 2a16522:	cmp    0x120(%rcx),%eax
 2a16528:	sete   %al
 2a1652b:	rex movzbl %al,%edi
 2a1652f:	test   %edi,%edi
 2a16531:	jne    2a1658a <wasm[0]::function[1015]::helper::object_read+0x1842a>
 2a16537:	mov    0x190(%rsp),%rsi
 2a1653f:	mov    0x190(%rsp),%rdi
 2a16547:	call   2a1eec0 <wasm[0]::function[1024]::helper::property_value_resolve>
 2a1654c:	test   %eax,%eax
 2a1654e:	je     2a19b0a <wasm[0]::function[1015]::helper::object_read+0x1b9aa>
 2a16554:	test   %eax,%eax
 2a16556:	je     2a19b0c <wasm[0]::function[1015]::helper::object_read+0x1b9ac>
 2a1655c:	mov    0x2e0(%rsp),%r14
 2a16564:	mov    0x28(%r14),%rdx
 2a16568:	mov    0x20(%r14),%rcx
 2a1656c:	mov    %eax,%eax
 2a1656e:	add    %rax,%rcx
 2a16571:	xor    %rsi,%rsi
 2a16574:	cmp    %rdx,%rax
 2a16577:	cmova  %rsi,%rcx
 2a1657b:	mov    0x18(%rcx),%edx
 2a1657e:	mov    0x10(%rcx),%rax
 2a16582:	mov    0x1c(%rcx),%ecx
 2a16585:	jmp    2a1660c <wasm[0]::function[1015]::helper::object_read+0x184ac>
 2a1658a:	xor    %eax,%eax
 2a1658c:	test   $0x1,%edx
 2a16592:	jne    2a165d3 <wasm[0]::function[1015]::helper::object_read+0x18473>
 2a16598:	mov    0x2e0(%rsp),%r14
 2a165a0:	mov    0x28(%r14),%rax
 2a165a4:	mov    0x20(%r14),%rcx
 2a165a8:	mov    %edx,%esi
 2a165aa:	lea    0x4(%rcx,%rsi,1),%rcx
 2a165af:	xor    %rdi,%rdi
 2a165b2:	cmp    %rax,%rsi
 2a165b5:	cmova  %rdi,%rcx
 2a165b9:	mov    (%rcx),%eax
 2a165bb:	mov    0x190(%rsp),%rsi
 2a165c3:	mov    0x28(%rsi),%rcx
 2a165c7:	cmp    0x120(%rcx),%eax
 2a165cd:	sete   %al
 2a165d0:	movzbl %al,%eax
 2a165d3:	test   %eax,%eax
 2a165d5:	je     2a19b0e <wasm[0]::function[1015]::helper::object_read+0x1b9ae>
 2a165db:	test   %edx,%edx
 2a165dd:	je     2a19b10 <wasm[0]::function[1015]::helper::object_read+0x1b9b0>
 2a165e3:	mov    0x2e0(%rsp),%r14
 2a165eb:	mov    0x28(%r14),%rax
 2a165ef:	mov    0x20(%r14),%rcx
 2a165f3:	mov    %edx,%edx
 2a165f5:	add    %rdx,%rcx
 2a165f8:	xor    %rsi,%rsi
 2a165fb:	cmp    %rax,%rdx
 2a165fe:	cmova  %rsi,%rcx
 2a16602:	mov    0x18(%rcx),%edx
 2a16605:	mov    0x10(%rcx),%rax
 2a16609:	mov    0x1c(%rcx),%ecx
 2a1660c:	mov    0x280(%rsp),%r9
 2a16614:	mov    0x280(%rsp),%r9
 2a1661c:	cmp    %edx,%r9d
 2a1661f:	je     2a16637 <wasm[0]::function[1015]::helper::object_read+0x184d7>
 2a16625:	mov    0x88(%rsp),%ecx
 2a1662c:	mov    0x78(%rsp),%edx
 2a16630:	xor    %eax,%eax
 2a16632:	jmp    2a16b90 <wasm[0]::function[1015]::helper::object_read+0x18a30>
 2a16637:	mov    0x280(%rsp),%rdx
 2a1663f:	cmp    $0x3,%edx
 2a16642:	je     2a16b3d <wasm[0]::function[1015]::helper::object_read+0x189dd>
 2a16648:	mov    0x280(%rsp),%rdx
 2a16650:	cmp    $0x4,%edx
 2a16653:	je     2a16a26 <wasm[0]::function[1015]::helper::object_read+0x188c6>
 2a16659:	mov    0x280(%rsp),%rdx
 2a16661:	cmp    $0xa,%edx
 2a16664:	je     2a166e0 <wasm[0]::function[1015]::helper::object_read+0x18580>
 2a1666a:	mov    0x280(%rsp),%rdx
 2a16672:	mov    0x280(%rsp),%rsi
 2a1667a:	test   %esi,%edx
 2a1667c:	sete   %dl
 2a1667f:	cmp    $0x1,%esi
 2a16682:	sete   %sil
 2a16686:	or     %esi,%edx
 2a16688:	test   %dl,%dl
 2a1668a:	jne    2a166c8 <wasm[0]::function[1015]::helper::object_read+0x18568>
 2a16690:	mov    0x280(%rsp),%rdx
 2a16698:	cmp    $0x2,%edx
 2a1669b:	je     2a166b2 <wasm[0]::function[1015]::helper::object_read+0x18552>
 2a166a1:	mov    0x78(%rsp),%eax
 2a166a5:	cmp    %ecx,%eax
 2a166a7:	sete   %al
 2a166aa:	movzbl %al,%eax
 2a166ad:	jmp    2a166d0 <wasm[0]::function[1015]::helper::object_read+0x18570>
 2a166b2:	mov    0x288(%rsp),%rcx
 2a166ba:	cmp    %rax,%rcx
 2a166bd:	sete   %al
 2a166c0:	movzbl %al,%eax
 2a166c3:	jmp    2a166d0 <wasm[0]::function[1015]::helper::object_read+0x18570>
 2a166c8:	mov    0x278(%rsp),%rax
 2a166d0:	mov    0x88(%rsp),%ecx
 2a166d7:	mov    0x78(%rsp),%edx
 2a166db:	jmp    2a16b90 <wasm[0]::function[1015]::helper::object_read+0x18a30>
 2a166e0:	mov    0x78(%rsp),%edx
 2a166e4:	xor    %esi,%esi
 2a166e6:	test   %edx,%edx
 2a166e8:	je     2a16745 <wasm[0]::function[1015]::helper::object_read+0x185e5>
 2a166ee:	mov    0x78(%rsp),%edi
 2a166f2:	xor    %esi,%esi
 2a166f4:	test   $0x1,%edi
 2a166fa:	jne    2a16745 <wasm[0]::function[1015]::helper::object_read+0x185e5>
 2a16700:	mov    0x78(%rsp),%r8d
 2a16705:	mov    0x2e0(%rsp),%r14
 2a1670d:	mov    0x28(%r14),%rdi
 2a16711:	mov    0x20(%r14),%r9
 2a16715:	mov    %r8d,%r8d
 2a16718:	lea    0x4(%r9,%r8,1),%rsi
 2a1671d:	xor    %r9,%r9
 2a16720:	cmp    %rdi,%r8
 2a16723:	cmova  %r9,%rsi
 2a16727:	mov    (%rsi),%r8d
 2a1672a:	mov    0x190(%rsp),%rsi
 2a16732:	mov    0x28(%rsi),%r9
 2a16736:	cmp    0x23c(%r9),%r8d
 2a1673d:	sete   %r9b
 2a16741:	movzbl %r9b,%esi
 2a16745:	test   %esi,%esi
 2a16747:	je     2a19b12 <wasm[0]::function[1015]::helper::object_read+0x1b9b2>
 2a1674d:	xor    %eax,%eax
 2a1674f:	test   %ecx,%ecx
 2a16751:	je     2a167a0 <wasm[0]::function[1015]::helper::object_read+0x18640>
 2a16757:	xor    %eax,%eax
 2a16759:	test   $0x1,%ecx
 2a1675f:	jne    2a167a0 <wasm[0]::function[1015]::helper::object_read+0x18640>
 2a16765:	mov    0x2e0(%rsp),%r14
 2a1676d:	mov    0x28(%r14),%rax
 2a16771:	mov    0x20(%r14),%rdx
 2a16775:	mov    %ecx,%esi
 2a16777:	lea    0x4(%rdx,%rsi,1),%rdx
 2a1677c:	xor    %rdi,%rdi
 2a1677f:	cmp    %rax,%rsi
 2a16782:	cmova  %rdi,%rdx
 2a16786:	mov    (%rdx),%eax
 2a16788:	mov    0x190(%rsp),%rsi
 2a16790:	mov    0x28(%rsi),%rdx
 2a16794:	cmp    0x23c(%rdx),%eax
 2a1679a:	sete   %al
 2a1679d:	movzbl %al,%eax
 2a167a0:	test   %eax,%eax
 2a167a2:	je     2a19b14 <wasm[0]::function[1015]::helper::object_read+0x1b9b4>
 2a167a8:	mov    0x78(%rsp),%edx
 2a167ac:	test   %edx,%edx
 2a167ae:	je     2a19b16 <wasm[0]::function[1015]::helper::object_read+0x1b9b6>
 2a167b4:	test   %edx,%edx
 2a167b6:	je     2a19b18 <wasm[0]::function[1015]::helper::object_read+0x1b9b8>
 2a167bc:	mov    0x2e0(%rsp),%r14
 2a167c4:	mov    0x28(%r14),%rax
 2a167c8:	mov    0x20(%r14),%rsi
 2a167cc:	mov    %edx,%r8d
 2a167cf:	lea    (%rsi,%r8,1),%r10
 2a167d3:	xor    %rdi,%rdi
 2a167d6:	cmp    %rax,%r8
 2a167d9:	cmova  %rdi,%r10
 2a167dd:	mov    0x10(%r10),%r8d
 2a167e1:	test   %ecx,%ecx
 2a167e3:	je     2a19b1a <wasm[0]::function[1015]::helper::object_read+0x1b9ba>
 2a167e9:	test   %ecx,%ecx
 2a167eb:	je     2a19b1c <wasm[0]::function[1015]::helper::object_read+0x1b9bc>
 2a167f1:	mov    %ecx,%r9d
 2a167f4:	lea    (%rsi,%r9,1),%rcx
 2a167f8:	cmp    %rax,%r9
 2a167fb:	cmova  %rdi,%rcx
 2a167ff:	mov    0x10(%rcx),%r9d
 2a16803:	mov    0x14(%r10),%r10d
 2a16807:	mov    %r10d,0xa0(%rsp)
 2a1680f:	mov    0x14(%rcx),%ecx
 2a16812:	mov    %ecx,0xa8(%rsp)
 2a16819:	test   %r10d,%r10d
 2a1681c:	je     2a19b1e <wasm[0]::function[1015]::helper::object_read+0x1b9be>
 2a16822:	test   %r10d,%r10d
 2a16825:	je     2a19b20 <wasm[0]::function[1015]::helper::object_read+0x1b9c0>
 2a1682b:	mov    %r10d,%r11d
 2a1682e:	lea    0x10(%rsi,%r11,1),%r10
 2a16833:	cmp    %rax,%r11
 2a16836:	cmova  %rdi,%r10
 2a1683a:	mov    (%r10),%r12d
 2a1683d:	test   %ecx,%ecx
 2a1683f:	je     2a19b22 <wasm[0]::function[1015]::helper::object_read+0x1b9c2>
 2a16845:	test   %ecx,%ecx
 2a16847:	je     2a19b24 <wasm[0]::function[1015]::helper::object_read+0x1b9c4>
 2a1684d:	mov    %ecx,%r10d
 2a16850:	lea    0x10(%rsi,%r10,1),%rcx
 2a16855:	cmp    %rax,%r10
 2a16858:	cmova  %rdi,%rcx
 2a1685c:	mov    (%rcx),%eax
 2a1685e:	mov    0x88(%rsp),%ecx
 2a16865:	cmp    %r9d,%r8d
 2a16868:	sete   %sil
 2a1686c:	cmp    %eax,%r12d
 2a1686f:	sete   %dil
 2a16873:	mov    %rsi,%rax
 2a16876:	and    %edi,%eax
 2a16878:	movzbl %al,%eax
 2a1687b:	mov    %rax,%r13
 2a1687e:	test   %sil,%dil
 2a16881:	jne    2a1688f <wasm[0]::function[1015]::helper::object_read+0x1872f>
 2a16887:	mov    %r13,%rax
 2a1688a:	jmp    2a16b90 <wasm[0]::function[1015]::helper::object_read+0x18a30>
 2a1688f:	mov    0x88(%rsp),%ecx
 2a16896:	mov    0x78(%rsp),%edx
 2a1689a:	xor    %ebx,%ebx
 2a1689c:	mov    %ecx,0x98(%rsp)
 2a168a3:	mov    %edx,0x90(%rsp)
 2a168aa:	mov    0x2e8(%rsp),%r15
 2a168b2:	mov    (%r15),%rcx
 2a168b5:	mov    0x228(%rsp),%rax
 2a168bd:	cmp    %rax,%rcx
 2a168c0:	jae    2a18d43 <wasm[0]::function[1015]::helper::object_read+0x1abe3>
 2a168c6:	jmp    2a168d3 <wasm[0]::function[1015]::helper::object_read+0x18773>
 2a168cb:	mov    %rdx,0x228(%rsp)
 2a168d3:	cmp    %r12d,%ebx
 2a168d6:	jb     2a168e4 <wasm[0]::function[1015]::helper::object_read+0x18784>
 2a168dc:	mov    %r13,%rax
 2a168df:	jmp    2a16a13 <wasm[0]::function[1015]::helper::object_read+0x188b3>
 2a168e4:	mov    0xa0(%rsp),%eax
 2a168eb:	test   %eax,%eax
 2a168ed:	je     2a19b26 <wasm[0]::function[1015]::helper::object_read+0x1b9c6>
 2a168f3:	test   %eax,%eax
 2a168f5:	je     2a19b28 <wasm[0]::function[1015]::helper::object_read+0x1b9c8>
 2a168fb:	mov    0x2e0(%rsp),%r14
 2a16903:	mov    0x28(%r14),%rsi
 2a16907:	mov    0x20(%r14),%rdi
 2a1690b:	mov    %eax,%r9d
 2a1690e:	lea    0x10(%rdi,%r9,1),%rcx
 2a16913:	xor    %r8,%r8
 2a16916:	cmp    %rsi,%r9
 2a16919:	cmova  %r8,%rcx
 2a1691d:	mov    (%rcx),%ecx
 2a1691f:	cmp    %ecx,%ebx
 2a16921:	jae    2a19b2a <wasm[0]::function[1015]::helper::object_read+0x1b9ca>
 2a16927:	mov    %ecx,%r9d
 2a1692a:	shl    $0x3,%r9
 2a1692e:	shr    $0x20,%r9
 2a16932:	test   %r9,%r9
 2a16935:	jne    2a19b2c <wasm[0]::function[1015]::helper::object_read+0x1b9cc>
 2a1693b:	shl    $0x3,%ecx
 2a1693e:	add    $0x18,%ecx
 2a16941:	jb     2a19b2e <wasm[0]::function[1015]::helper::object_read+0x1b9ce>
 2a16947:	add    %ecx,%eax
 2a16949:	jb     2a19b30 <wasm[0]::function[1015]::helper::object_read+0x1b9d0>
 2a1694f:	mov    %eax,%r11d
 2a16952:	lea    (%rdi,%r11,1),%r9
 2a16956:	cmp    %rsi,%r11
 2a16959:	cmova  %r8,%r9
 2a1695d:	mov    %rbx,%rax
 2a16960:	shl    $0x3,%eax
 2a16963:	add    $0x18,%eax
 2a16969:	sub    %eax,%ecx
 2a1696b:	sub    %rcx,%r9
 2a1696e:	mov    (%r9),%rcx
 2a16971:	mov    0xa8(%rsp),%edx
 2a16978:	test   %edx,%edx
 2a1697a:	je     2a19b32 <wasm[0]::function[1015]::helper::object_read+0x1b9d2>
 2a16980:	test   %edx,%edx
 2a16982:	je     2a19b34 <wasm[0]::function[1015]::helper::object_read+0x1b9d4>
 2a16988:	mov    %edx,%r10d
 2a1698b:	lea    0x10(%rdi,%r10,1),%r9
 2a16990:	cmp    %rsi,%r10
 2a16993:	cmova  %r8,%r9
 2a16997:	mov    (%r9),%r9d
 2a1699a:	cmp    %r9d,%ebx
 2a1699d:	jae    2a19b36 <wasm[0]::function[1015]::helper::object_read+0x1b9d6>
 2a169a3:	mov    %r9d,%r10d
 2a169a6:	shl    $0x3,%r10
 2a169aa:	shr    $0x20,%r10
 2a169ae:	test   %r10,%r10
 2a169b1:	jne    2a19b38 <wasm[0]::function[1015]::helper::object_read+0x1b9d8>
 2a169b7:	shl    $0x3,%r9d
 2a169bb:	add    $0x18,%r9d
 2a169bf:	jb     2a19b3a <wasm[0]::function[1015]::helper::object_read+0x1b9da>
 2a169c5:	add    %r9d,%edx
 2a169c8:	jb     2a19b3c <wasm[0]::function[1015]::helper::object_read+0x1b9dc>
 2a169ce:	mov    %edx,%r10d
 2a169d1:	lea    (%rdi,%r10,1),%rdx
 2a169d5:	cmp    %rsi,%r10
 2a169d8:	cmova  %r8,%rdx
 2a169dc:	sub    %eax,%r9d
 2a169df:	sub    %r9,%rdx
 2a169e2:	mov    (%rdx),%rdx
 2a169e5:	cmp    %rdx,%rcx
 2a169e8:	sete   %al
 2a169eb:	movzbl %al,%eax
 2a169ee:	cmp    %rdx,%rcx
 2a169f1:	jne    2a16a13 <wasm[0]::function[1015]::helper::object_read+0x188b3>
 2a169f7:	mov    0x98(%rsp),%ecx
 2a169fe:	mov    0x90(%rsp),%edx
 2a16a05:	add    $0x1,%ebx
 2a16a0b:	mov    %rax,%r13
 2a16a0e:	jmp    2a1689c <wasm[0]::function[1015]::helper::object_read+0x1873c>
 2a16a13:	mov    0x98(%rsp),%ecx
 2a16a1a:	mov    0x90(%rsp),%edx
 2a16a21:	jmp    2a16b90 <wasm[0]::function[1015]::helper::object_read+0x18a30>
 2a16a26:	mov    0x78(%rsp),%eax
 2a16a2a:	cmp    %ecx,%eax
 2a16a2c:	je     2a16b25 <wasm[0]::function[1015]::helper::object_read+0x189c5>
 2a16a32:	mov    0x78(%rsp),%edx
 2a16a36:	xor    %eax,%eax
 2a16a38:	test   %edx,%edx
 2a16a3a:	je     2a16a91 <wasm[0]::function[1015]::helper::object_read+0x18931>
 2a16a40:	mov    0x78(%rsp),%edx
 2a16a44:	xor    %eax,%eax
 2a16a46:	test   $0x1,%edx
 2a16a4c:	jne    2a16a91 <wasm[0]::function[1015]::helper::object_read+0x18931>
 2a16a52:	mov    0x78(%rsp),%edx
 2a16a56:	mov    0x2e0(%rsp),%r14
 2a16a5e:	mov    0x28(%r14),%rax
 2a16a62:	mov    0x20(%r14),%rdi
 2a16a66:	mov    %edx,%esi
 2a16a68:	lea    0x4(%rdi,%rsi,1),%rdx
 2a16a6d:	xor    %rdi,%rdi
 2a16a70:	cmp    %rax,%rsi
 2a16a73:	cmova  %rdi,%rdx
 2a16a77:	mov    (%rdx),%eax
 2a16a79:	mov    0x190(%rsp),%rsi
 2a16a81:	mov    0x28(%rsi),%rdx
 2a16a85:	cmp    0x234(%rdx),%eax
 2a16a8b:	sete   %al
 2a16a8e:	movzbl %al,%eax
 2a16a91:	test   %eax,%eax
 2a16a93:	je     2a19b3e <wasm[0]::function[1015]::helper::object_read+0x1b9de>
 2a16a99:	xor    %eax,%eax
 2a16a9b:	test   %ecx,%ecx
 2a16a9d:	je     2a16aec <wasm[0]::function[1015]::helper::object_read+0x1898c>
 2a16aa3:	xor    %eax,%eax
 2a16aa5:	test   $0x1,%ecx
 2a16aab:	jne    2a16aec <wasm[0]::function[1015]::helper::object_read+0x1898c>
 2a16ab1:	mov    0x2e0(%rsp),%r14
 2a16ab9:	mov    0x28(%r14),%rax
 2a16abd:	mov    0x20(%r14),%rdx
 2a16ac1:	mov    %ecx,%esi
 2a16ac3:	lea    0x4(%rdx,%rsi,1),%rdx
 2a16ac8:	xor    %rdi,%rdi
 2a16acb:	cmp    %rax,%rsi
 2a16ace:	cmova  %rdi,%rdx
 2a16ad2:	mov    (%rdx),%eax
 2a16ad4:	mov    0x190(%rsp),%rsi
 2a16adc:	mov    0x28(%rsi),%rdx
 2a16ae0:	cmp    0x234(%rdx),%eax
 2a16ae6:	sete   %al
 2a16ae9:	movzbl %al,%eax
 2a16aec:	test   %eax,%eax
 2a16aee:	je     2a19b40 <wasm[0]::function[1015]::helper::object_read+0x1b9e0>
 2a16af4:	mov    0x78(%rsp),%edx
 2a16af8:	xor    %r8d,%r8d
 2a16afb:	test   %edx,%edx
 2a16afd:	je     2a19b42 <wasm[0]::function[1015]::helper::object_read+0x1b9e2>
 2a16b03:	test   %ecx,%ecx
 2a16b05:	je     2a19b44 <wasm[0]::function[1015]::helper::object_read+0x1b9e4>
 2a16b0b:	mov    0x190(%rsp),%rsi
 2a16b13:	mov    0x190(%rsp),%rdi
 2a16b1b:	call   2b02800 <wasm[0]::function[1057]::helper::string_equality>
 2a16b20:	jmp    2a16b2d <wasm[0]::function[1015]::helper::object_read+0x189cd>
 2a16b25:	mov    0x278(%rsp),%rax
 2a16b2d:	mov    0x88(%rsp),%ecx
 2a16b34:	mov    0x78(%rsp),%edx
 2a16b38:	jmp    2a16b90 <wasm[0]::function[1015]::helper::object_read+0x18a30>
 2a16b3d:	mov    0x88(%rsp),%ecx
 2a16b44:	mov    0x78(%rsp),%edx
 2a16b48:	mov    0x288(%rsp),%rsi
 2a16b50:	cmp    %rax,%rsi
 2a16b53:	sete   %sil
 2a16b57:	mov    0x288(%rsp),%rdi
 2a16b5f:	movq   %rdi,%xmm2
 2a16b64:	ucomisd %xmm2,%xmm2
 2a16b68:	setp   %dil
 2a16b6c:	setne  %r8b
 2a16b70:	or     %r8d,%edi
 2a16b73:	movq   %rax,%xmm3
 2a16b78:	ucomisd %xmm3,%xmm3
 2a16b7c:	setp   %r8b
 2a16b80:	setne  %r9b
 2a16b84:	or     %r9d,%r8d
 2a16b87:	and    %r8d,%edi
 2a16b8a:	or     %edi,%esi
 2a16b8c:	movzbl %sil,%eax
 2a16b90:	xor    %esi,%esi
 2a16b92:	test   %eax,%eax
 2a16b94:	je     2a16ba7 <wasm[0]::function[1015]::helper::object_read+0x18a47>
 2a16b9a:	mov    %rsi,0x298(%rsp)
 2a16ba2:	jmp    2a1715c <wasm[0]::function[1015]::helper::object_read+0x18ffc>
 2a16ba7:	xor    %edx,%edx
 2a16ba9:	mov    %ecx,0x90(%rsp)
 2a16bb0:	mov    %edx,0x98(%rsp)
 2a16bb7:	mov    0x2e8(%rsp),%r15
 2a16bbf:	mov    (%r15),%rax
 2a16bc2:	mov    0x228(%rsp),%rcx
 2a16bca:	cmp    %rcx,%rax
 2a16bcd:	jae    2a18d72 <wasm[0]::function[1015]::helper::object_read+0x1ac12>
 2a16bd3:	jmp    2a16be0 <wasm[0]::function[1015]::helper::object_read+0x18a80>
 2a16bd8:	mov    %rcx,0x228(%rsp)
 2a16be0:	mov    0x90(%rsp),%eax
 2a16be7:	mov    0x98(%rsp),%edx
 2a16bee:	test   %eax,%eax
 2a16bf0:	je     2a16c66 <wasm[0]::function[1015]::helper::object_read+0x18b06>
 2a16bf6:	mov    0x90(%rsp),%ecx
 2a16bfd:	test   %ecx,%ecx
 2a16bff:	je     2a19b46 <wasm[0]::function[1015]::helper::object_read+0x1b9e6>
 2a16c05:	mov    0x2e0(%rsp),%r14
 2a16c0d:	mov    0x28(%r14),%rax
 2a16c11:	mov    0x20(%r14),%rsi
 2a16c15:	mov    %ecx,%edx
 2a16c17:	lea    (%rsi,%rdx,1),%rcx
 2a16c1b:	xor    %rsi,%rsi
 2a16c1e:	cmp    %rax,%rdx
 2a16c21:	cmova  %rsi,%rcx
 2a16c25:	mov    0x10(%rcx),%edx
 2a16c28:	test   %edx,%edx
 2a16c2a:	jne    2a16c66 <wasm[0]::function[1015]::helper::object_read+0x18b06>
 2a16c30:	mov    0x90(%rsp),%ecx
 2a16c37:	test   %ecx,%ecx
 2a16c39:	je     2a19b48 <wasm[0]::function[1015]::helper::object_read+0x1b9e8>
 2a16c3f:	mov    0x2e0(%rsp),%r14
 2a16c47:	mov    0x28(%r14),%rax
 2a16c4b:	mov    %ecx,%esi
 2a16c4d:	mov    %rsi,%rcx
 2a16c50:	add    0x20(%r14),%rcx
 2a16c54:	xor    %rdi,%rdi
 2a16c57:	cmp    %rax,%rsi
 2a16c5a:	cmova  %rdi,%rcx
 2a16c5e:	mov    0x1c(%rcx),%ecx
 2a16c61:	jmp    2a16ba9 <wasm[0]::function[1015]::helper::object_read+0x18a49>
 2a16c66:	test   %edx,%edx
 2a16c68:	jne    2a16c84 <wasm[0]::function[1015]::helper::object_read+0x18b24>
 2a16c6e:	mov    0x190(%rsp),%rsi
 2a16c76:	mov    0x8c0(%rsi),%edx
 2a16c7c:	test   %edx,%edx
 2a16c7e:	je     2a19b4a <wasm[0]::function[1015]::helper::object_read+0x1b9ea>
 2a16c84:	mov    %edx,0x90(%rsp)
 2a16c8b:	test   %edx,%edx
 2a16c8d:	je     2a19b4c <wasm[0]::function[1015]::helper::object_read+0x1b9ec>
 2a16c93:	mov    0x190(%rsp),%rsi
 2a16c9b:	mov    0x190(%rsp),%rdi
 2a16ca3:	call   2ae3360 <wasm[0]::function[1049]::helper::realm_ensure_errors>
 2a16ca8:	mov    0x90(%rsp),%edx
 2a16caf:	test   %edx,%edx
 2a16cb1:	je     2a19b4e <wasm[0]::function[1015]::helper::object_read+0x1b9ee>
 2a16cb7:	test   %edx,%edx
 2a16cb9:	je     2a19b50 <wasm[0]::function[1015]::helper::object_read+0x1b9f0>
 2a16cbf:	mov    0x2e0(%rsp),%r14
 2a16cc7:	mov    0x28(%r14),%rax
 2a16ccb:	mov    0x20(%r14),%rcx
 2a16ccf:	mov    %edx,%edi
 2a16cd1:	lea    (%rcx,%rdi,1),%rsi
 2a16cd5:	xor    %rdx,%rdx
 2a16cd8:	cmp    %rax,%rdi
 2a16cdb:	cmova  %rdx,%rsi
 2a16cdf:	mov    0x2c(%rsi),%esi
 2a16ce2:	test   %esi,%esi
 2a16ce4:	je     2a19b52 <wasm[0]::function[1015]::helper::object_read+0x1b9f2>
 2a16cea:	test   %esi,%esi
 2a16cec:	je     2a19b54 <wasm[0]::function[1015]::helper::object_read+0x1b9f4>
 2a16cf2:	mov    %esi,%r8d
 2a16cf5:	lea    0x10(%rcx,%r8,1),%rdi
 2a16cfa:	cmp    %rax,%r8
 2a16cfd:	cmova  %rdx,%rdi
 2a16d01:	mov    (%rdi),%edi
 2a16d03:	cmp    $0x3,%edi
 2a16d06:	jbe    2a19b56 <wasm[0]::function[1015]::helper::object_read+0x1b9f6>
 2a16d0c:	mov    %edi,%r8d
 2a16d0f:	shl    $0x2,%r8
 2a16d13:	shr    $0x20,%r8
 2a16d17:	test   %r8,%r8
 2a16d1a:	jne    2a19b58 <wasm[0]::function[1015]::helper::object_read+0x1b9f8>
 2a16d20:	shl    $0x2,%edi
 2a16d23:	add    $0x14,%edi
 2a16d26:	jb     2a19b5a <wasm[0]::function[1015]::helper::object_read+0x1b9fa>
 2a16d2c:	add    %edi,%esi
 2a16d2e:	jb     2a19b5c <wasm[0]::function[1015]::helper::object_read+0x1b9fc>
 2a16d34:	mov    %esi,%r8d
 2a16d37:	lea    (%rcx,%r8,1),%rsi
 2a16d3b:	cmp    %rax,%r8
 2a16d3e:	cmova  %rdx,%rsi
 2a16d42:	sub    $0x20,%edi
 2a16d45:	sub    %rdi,%rsi
 2a16d48:	mov    (%rsi),%esi
 2a16d4a:	test   %esi,%esi
 2a16d4c:	je     2a19b5e <wasm[0]::function[1015]::helper::object_read+0x1b9fe>
 2a16d52:	test   %esi,%esi
 2a16d54:	je     2a19b60 <wasm[0]::function[1015]::helper::object_read+0x1ba00>
 2a16d5a:	mov    %esi,%esi
 2a16d5c:	add    %rsi,%rcx
 2a16d5f:	cmp    %rax,%rsi
 2a16d62:	cmova  %rdx,%rcx
 2a16d66:	mov    0x18(%rcx),%r12d
 2a16d6a:	mov    0x10(%rcx),%rbx
 2a16d6e:	mov    0x1c(%rcx),%ecx
 2a16d71:	mov    %ecx,0x90(%rsp)
 2a16d78:	mov    $0x6,%eax
 2a16d7d:	mov    %rax,0x280(%rsp)
 2a16d85:	cmp    $0x6,%r12d
 2a16d89:	sete   %cl
 2a16d8c:	cmp    $0x7,%r12d
 2a16d90:	sete   %sil
 2a16d94:	or     %esi,%ecx
 2a16d96:	cmp    $0x8,%r12d
 2a16d9a:	sete   %sil
 2a16d9e:	or     %esi,%ecx
 2a16da0:	cmp    $0x9,%r12d
 2a16da4:	sete   %sil
 2a16da8:	or     %esi,%ecx
 2a16daa:	rex movzbl %cl,%esi
 2a16dae:	test   %esi,%esi
 2a16db0:	je     2a19b62 <wasm[0]::function[1015]::helper::object_read+0x1ba02>
 2a16db6:	mov    $0x998,%edx
 2a16dbb:	mov    0x190(%rsp),%rsi
 2a16dc3:	mov    0x190(%rsp),%rdi
 2a16dcb:	call   2f4f240 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 2a16dd0:	xor    %edi,%edi
 2a16dd2:	mov    %rdi,0x298(%rsp)
 2a16dda:	test   %eax,%eax
 2a16ddc:	je     2a19b64 <wasm[0]::function[1015]::helper::object_read+0x1ba04>
 2a16de2:	mov    0x90(%rsp),%r9d
 2a16dea:	mov    $0x5,%edx
 2a16def:	mov    %eax,(%rsp)
 2a16df2:	mov    %r12,%rcx
 2a16df5:	mov    0x190(%rsp),%rsi
 2a16dfd:	mov    %rbx,%r8
 2a16e00:	mov    %rsi,%rdi
 2a16e03:	call   2f4efa0 <wasm[0]::function[1101]::helper::runtime_error_for_throw>
 2a16e08:	sub    $0x10,%rsp
 2a16e0c:	test   %eax,%eax
 2a16e0e:	je     2a19b66 <wasm[0]::function[1015]::helper::object_read+0x1ba06>
 2a16e14:	mov    %rcx,%rdx
 2a16e17:	mov    %rcx,0x288(%rsp)
 2a16e1f:	xor    %rdx,%rcx
 2a16e22:	mov    %rcx,0x288(%rsp)
 2a16e2a:	mov    %rax,%rdx
 2a16e2d:	mov    0x278(%rsp),%rsi
 2a16e35:	jmp    2a1715c <wasm[0]::function[1015]::helper::object_read+0x18ffc>
 2a16e3a:	xor    %eax,%eax
 2a16e3c:	mov    %r15,%rcx
 2a16e3f:	mov    %r15,%rdx
 2a16e42:	test   %edx,%ecx
 2a16e44:	je     2a16ea4 <wasm[0]::function[1015]::helper::object_read+0x18d44>
 2a16e4a:	mov    %r15,%rax
 2a16e4d:	mov    %r15,%rcx
 2a16e50:	test   %ecx,%eax
 2a16e52:	je     2a19b68 <wasm[0]::function[1015]::helper::object_read+0x1ba08>
 2a16e58:	mov    0x2e0(%rsp),%r14
 2a16e60:	mov    0x28(%r14),%rax
 2a16e64:	mov    0x20(%r14),%rcx
 2a16e68:	mov    %r15,%rdx
 2a16e6b:	mov    %edx,%edi
 2a16e6d:	lea    (%rcx,%rdi,1),%rsi
 2a16e71:	xor    %rdx,%rdx
 2a16e74:	cmp    %rax,%rdi
 2a16e77:	cmova  %rdx,%rsi
 2a16e7b:	mov    0x18(%rsi),%esi
 2a16e7e:	test   %esi,%esi
 2a16e80:	je     2a19b6a <wasm[0]::function[1015]::helper::object_read+0x1ba0a>
 2a16e86:	test   %esi,%esi
 2a16e88:	je     2a19b6c <wasm[0]::function[1015]::helper::object_read+0x1ba0c>
 2a16e8e:	mov    %esi,%esi
 2a16e90:	add    %rsi,%rcx
 2a16e93:	cmp    %rax,%rsi
 2a16e96:	cmova  %rdx,%rcx
 2a16e9a:	mov    0x18(%rcx),%eax
 2a16e9d:	mov    0x10(%rcx),%rdx
 2a16ea1:	mov    0x1c(%rcx),%ecx
 2a16ea4:	mov    0x78(%rsp),%edx
 2a16ea8:	xor    %esi,%esi
 2a16eaa:	test   %eax,%eax
 2a16eac:	sete   %al
 2a16eaf:	mov    0x280(%rsp),%rcx
 2a16eb7:	mov    0x280(%rsp),%rdi
 2a16ebf:	test   %edi,%ecx
 2a16ec1:	setne  %cl
 2a16ec4:	test   %al,%cl
 2a16ec6:	jne    2a16ed9 <wasm[0]::function[1015]::helper::object_read+0x18d79>
 2a16ecc:	mov    %rsi,0x298(%rsp)
 2a16ed4:	jmp    2a1715c <wasm[0]::function[1015]::helper::object_read+0x18ffc>
 2a16ed9:	mov    0x88(%rsp),%eax
 2a16ee0:	xor    %edx,%edx
 2a16ee2:	mov    %eax,0x78(%rsp)
 2a16ee6:	mov    %edx,0x88(%rsp)
 2a16eed:	mov    0x2e8(%rsp),%r15
 2a16ef5:	mov    (%r15),%rax
 2a16ef8:	mov    0x228(%rsp),%rcx
 2a16f00:	cmp    %rcx,%rax
 2a16f03:	jae    2a18da1 <wasm[0]::function[1015]::helper::object_read+0x1ac41>
 2a16f09:	jmp    2a16f16 <wasm[0]::function[1015]::helper::object_read+0x18db6>
 2a16f0e:	mov    %rcx,0x228(%rsp)
 2a16f16:	mov    0x78(%rsp),%eax
 2a16f1a:	mov    0x88(%rsp),%edx
 2a16f21:	test   %eax,%eax
 2a16f23:	je     2a16f93 <wasm[0]::function[1015]::helper::object_read+0x18e33>
 2a16f29:	mov    0x78(%rsp),%ecx
 2a16f2d:	test   %ecx,%ecx
 2a16f2f:	je     2a19b6e <wasm[0]::function[1015]::helper::object_read+0x1ba0e>
 2a16f35:	mov    0x2e0(%rsp),%r14
 2a16f3d:	mov    0x28(%r14),%rax
 2a16f41:	mov    0x20(%r14),%rsi
 2a16f45:	mov    %ecx,%edx
 2a16f47:	lea    (%rsi,%rdx,1),%rcx
 2a16f4b:	xor    %rsi,%rsi
 2a16f4e:	cmp    %rax,%rdx
 2a16f51:	cmova  %rsi,%rcx
 2a16f55:	mov    0x10(%rcx),%edx
 2a16f58:	test   %edx,%edx
 2a16f5a:	jne    2a16f93 <wasm[0]::function[1015]::helper::object_read+0x18e33>
 2a16f60:	mov    0x78(%rsp),%ecx
 2a16f64:	test   %ecx,%ecx
 2a16f66:	je     2a19b70 <wasm[0]::function[1015]::helper::object_read+0x1ba10>
 2a16f6c:	mov    0x2e0(%rsp),%r14
 2a16f74:	mov    0x28(%r14),%rax
 2a16f78:	mov    %ecx,%esi
 2a16f7a:	mov    %rsi,%rcx
 2a16f7d:	add    0x20(%r14),%rcx
 2a16f81:	xor    %rdi,%rdi
 2a16f84:	cmp    %rax,%rsi
 2a16f87:	cmova  %rdi,%rcx
 2a16f8b:	mov    0x1c(%rcx),%eax
 2a16f8e:	jmp    2a16ee2 <wasm[0]::function[1015]::helper::object_read+0x18d82>
 2a16f93:	test   %edx,%edx
 2a16f95:	jne    2a16fb1 <wasm[0]::function[1015]::helper::object_read+0x18e51>
 2a16f9b:	mov    0x190(%rsp),%rsi
 2a16fa3:	mov    0x8c0(%rsi),%edx
 2a16fa9:	test   %edx,%edx
 2a16fab:	je     2a19b72 <wasm[0]::function[1015]::helper::object_read+0x1ba12>
 2a16fb1:	mov    %edx,0x78(%rsp)
 2a16fb5:	test   %edx,%edx
 2a16fb7:	je     2a19b74 <wasm[0]::function[1015]::helper::object_read+0x1ba14>
 2a16fbd:	mov    0x190(%rsp),%rsi
 2a16fc5:	mov    0x190(%rsp),%rdi
 2a16fcd:	call   2ae3360 <wasm[0]::function[1049]::helper::realm_ensure_errors>
 2a16fd2:	mov    0x78(%rsp),%esi
 2a16fd6:	test   %esi,%esi
 2a16fd8:	je     2a19b76 <wasm[0]::function[1015]::helper::object_read+0x1ba16>
 2a16fde:	test   %esi,%esi
 2a16fe0:	je     2a19b78 <wasm[0]::function[1015]::helper::object_read+0x1ba18>
 2a16fe6:	mov    0x2e0(%rsp),%r14
 2a16fee:	mov    0x28(%r14),%r8
 2a16ff2:	mov    0x20(%r14),%r9
 2a16ff6:	mov    %esi,%r11d
 2a16ff9:	lea    (%r9,%r11,1),%rsi
 2a16ffd:	xor    %r10,%r10
 2a17000:	cmp    %r8,%r11
 2a17003:	cmova  %r10,%rsi
 2a17007:	mov    0x2c(%rsi),%eax
 2a1700a:	test   %eax,%eax
 2a1700c:	je     2a19b7a <wasm[0]::function[1015]::helper::object_read+0x1ba1a>
 2a17012:	test   %eax,%eax
 2a17014:	je     2a19b7c <wasm[0]::function[1015]::helper::object_read+0x1ba1c>
 2a1701a:	mov    %eax,%edx
 2a1701c:	lea    0x10(%r9,%rdx,1),%rcx
 2a17021:	cmp    %r8,%rdx
 2a17024:	cmova  %r10,%rcx
 2a17028:	mov    (%rcx),%esi
 2a1702a:	cmp    $0x3,%esi
 2a1702d:	jbe    2a19b7e <wasm[0]::function[1015]::helper::object_read+0x1ba1e>
 2a17033:	mov    %esi,%ecx
 2a17035:	shl    $0x2,%rcx
 2a17039:	shr    $0x20,%rcx
 2a1703d:	test   %rcx,%rcx
 2a17040:	jne    2a19b80 <wasm[0]::function[1015]::helper::object_read+0x1ba20>
 2a17046:	shl    $0x2,%esi
 2a17049:	add    $0x14,%esi
 2a1704c:	jb     2a19b82 <wasm[0]::function[1015]::helper::object_read+0x1ba22>
 2a17052:	add    %esi,%eax
 2a17054:	jb     2a19b84 <wasm[0]::function[1015]::helper::object_read+0x1ba24>
 2a1705a:	mov    %eax,%ecx
 2a1705c:	lea    (%r9,%rcx,1),%rax
 2a17060:	cmp    %r8,%rcx
 2a17063:	cmova  %r10,%rax
 2a17067:	sub    $0x20,%esi
 2a1706a:	sub    %rsi,%rax
 2a1706d:	mov    (%rax),%eax
 2a1706f:	test   %eax,%eax
 2a17071:	je     2a19b86 <wasm[0]::function[1015]::helper::object_read+0x1ba26>
 2a17077:	test   %eax,%eax
 2a17079:	je     2a19b88 <wasm[0]::function[1015]::helper::object_read+0x1ba28>
 2a1707f:	mov    %eax,%ecx
 2a17081:	lea    (%r9,%rcx,1),%rax
 2a17085:	cmp    %r8,%rcx
 2a17088:	cmova  %r10,%rax
 2a1708c:	mov    0x18(%rax),%r12d
 2a17090:	mov    0x10(%rax),%rbx
 2a17094:	mov    0x1c(%rax),%eax
 2a17097:	mov    %eax,0x78(%rsp)
 2a1709b:	mov    $0x6,%eax
 2a170a0:	mov    %rax,0x280(%rsp)
 2a170a8:	cmp    $0x6,%r12d
 2a170ac:	sete   %cl
 2a170af:	cmp    $0x7,%r12d
 2a170b3:	sete   %al
 2a170b6:	or     %eax,%ecx
 2a170b8:	cmp    $0x8,%r12d
 2a170bc:	sete   %al
 2a170bf:	or     %eax,%ecx
 2a170c1:	cmp    $0x9,%r12d
 2a170c5:	sete   %al
 2a170c8:	or     %eax,%ecx
 2a170ca:	movzbl %cl,%eax
 2a170cd:	test   %eax,%eax
 2a170cf:	je     2a19b8a <wasm[0]::function[1015]::helper::object_read+0x1ba2a>
 2a170d5:	mov    $0x999,%edx
 2a170da:	mov    0x190(%rsp),%rsi
 2a170e2:	mov    0x190(%rsp),%rdi
 2a170ea:	call   2f4f240 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 2a170ef:	mov    %rdi,%rcx
 2a170f2:	mov    %rdi,0x298(%rsp)
 2a170fa:	xor    %ecx,%edi
 2a170fc:	mov    %rdi,0x298(%rsp)
 2a17104:	test   %eax,%eax
 2a17106:	je     2a19b8c <wasm[0]::function[1015]::helper::object_read+0x1ba2c>
 2a1710c:	mov    0x78(%rsp),%r9d
 2a17111:	mov    $0x5,%edx
 2a17116:	mov    %eax,(%rsp)
 2a17119:	mov    %r12,%rcx
 2a1711c:	mov    0x190(%rsp),%rsi
 2a17124:	mov    %rbx,%r8
 2a17127:	mov    %rsi,%rdi
 2a1712a:	call   2f4efa0 <wasm[0]::function[1101]::helper::runtime_error_for_throw>
 2a1712f:	sub    $0x10,%rsp
 2a17133:	test   %eax,%eax
 2a17135:	je     2a19b8e <wasm[0]::function[1015]::helper::object_read+0x1ba2e>
 2a1713b:	mov    %rcx,%rdx
 2a1713e:	mov    %rcx,0x288(%rsp)
 2a17146:	xor    %rdx,%rcx
 2a17149:	mov    %rcx,0x288(%rsp)
 2a17151:	mov    %rax,%rdx
 2a17154:	mov    0x278(%rsp),%rsi
 2a1715c:	mov    %rdx,%rax
 2a1715f:	jmp    2a1776e <wasm[0]::function[1015]::helper::object_read+0x1960e>
 2a17164:	mov    %rdi,0x298(%rsp)
 2a1716c:	mov    0x80(%rsp),%edx
 2a17173:	mov    %rdx,%rax
 2a17176:	jmp    2a1776e <wasm[0]::function[1015]::helper::object_read+0x1960e>
 2a1717b:	mov    0x50(%rsp),%eax
 2a1717f:	xor    %edx,%edx
 2a17181:	mov    %eax,0x78(%rsp)
 2a17185:	mov    %edx,0x80(%rsp)
 2a1718c:	mov    0x2e8(%rsp),%r15
 2a17194:	mov    (%r15),%rax
 2a17197:	mov    0x228(%rsp),%rsi
 2a1719f:	cmp    %rsi,%rax
 2a171a2:	jae    2a18dd0 <wasm[0]::function[1015]::helper::object_read+0x1ac70>
 2a171a8:	jmp    2a171b5 <wasm[0]::function[1015]::helper::object_read+0x19055>
 2a171ad:	mov    %rcx,0x228(%rsp)
 2a171b5:	mov    0x78(%rsp),%eax
 2a171b9:	mov    0x80(%rsp),%edx
 2a171c0:	test   %eax,%eax
 2a171c2:	je     2a17232 <wasm[0]::function[1015]::helper::object_read+0x190d2>
 2a171c8:	mov    0x78(%rsp),%ecx
 2a171cc:	test   %ecx,%ecx
 2a171ce:	je     2a19b90 <wasm[0]::function[1015]::helper::object_read+0x1ba30>
 2a171d4:	mov    0x2e0(%rsp),%r14
 2a171dc:	mov    0x28(%r14),%rax
 2a171e0:	mov    0x20(%r14),%rsi
 2a171e4:	mov    %ecx,%edx
 2a171e6:	lea    (%rsi,%rdx,1),%rcx
 2a171ea:	xor    %rsi,%rsi
 2a171ed:	cmp    %rax,%rdx
 2a171f0:	cmova  %rsi,%rcx
 2a171f4:	mov    0x10(%rcx),%edx
 2a171f7:	test   %edx,%edx
 2a171f9:	jne    2a17232 <wasm[0]::function[1015]::helper::object_read+0x190d2>
 2a171ff:	mov    0x78(%rsp),%eax
 2a17203:	test   %eax,%eax
 2a17205:	je     2a19b92 <wasm[0]::function[1015]::helper::object_read+0x1ba32>
 2a1720b:	mov    0x2e0(%rsp),%r14
 2a17213:	mov    0x28(%r14),%rsi
 2a17217:	mov    %eax,%edi
 2a17219:	mov    %rdi,%rax
 2a1721c:	add    0x20(%r14),%rax
 2a17220:	xor    %r8,%r8
 2a17223:	cmp    %rsi,%rdi
 2a17226:	cmova  %r8,%rax
 2a1722a:	mov    0x1c(%rax),%eax
 2a1722d:	jmp    2a17181 <wasm[0]::function[1015]::helper::object_read+0x19021>
 2a17232:	test   %edx,%edx
 2a17234:	jne    2a17250 <wasm[0]::function[1015]::helper::object_read+0x190f0>
 2a1723a:	mov    0x190(%rsp),%rsi
 2a17242:	mov    0x8c0(%rsi),%edx
 2a17248:	test   %edx,%edx
 2a1724a:	je     2a19b94 <wasm[0]::function[1015]::helper::object_read+0x1ba34>
 2a17250:	mov    %edx,0x78(%rsp)
 2a17254:	test   %edx,%edx
 2a17256:	je     2a19b96 <wasm[0]::function[1015]::helper::object_read+0x1ba36>
 2a1725c:	mov    0x190(%rsp),%rsi
 2a17264:	mov    0x190(%rsp),%rdi
 2a1726c:	call   2ae3360 <wasm[0]::function[1049]::helper::realm_ensure_errors>
 2a17271:	mov    0x78(%rsp),%edx
 2a17275:	test   %edx,%edx
 2a17277:	je     2a19b98 <wasm[0]::function[1015]::helper::object_read+0x1ba38>
 2a1727d:	test   %edx,%edx
 2a1727f:	je     2a19b9a <wasm[0]::function[1015]::helper::object_read+0x1ba3a>
 2a17285:	mov    0x2e0(%rsp),%r14
 2a1728d:	mov    0x28(%r14),%rax
 2a17291:	mov    0x20(%r14),%rcx
 2a17295:	mov    %edx,%edi
 2a17297:	lea    (%rcx,%rdi,1),%rsi
 2a1729b:	xor    %rdx,%rdx
 2a1729e:	cmp    %rax,%rdi
 2a172a1:	cmova  %rdx,%rsi
 2a172a5:	mov    0x2c(%rsi),%r9d
 2a172a9:	test   %r9d,%r9d
 2a172ac:	je     2a19b9c <wasm[0]::function[1015]::helper::object_read+0x1ba3c>
 2a172b2:	test   %r9d,%r9d
 2a172b5:	je     2a19b9e <wasm[0]::function[1015]::helper::object_read+0x1ba3e>
 2a172bb:	mov    %r9d,%edi
 2a172be:	lea    0x10(%rcx,%rdi,1),%rsi
 2a172c3:	cmp    %rax,%rdi
 2a172c6:	cmova  %rdx,%rsi
 2a172ca:	mov    (%rsi),%esi
 2a172cc:	cmp    $0x3,%esi
 2a172cf:	jbe    2a19ba0 <wasm[0]::function[1015]::helper::object_read+0x1ba40>
 2a172d5:	mov    %esi,%edi
 2a172d7:	shl    $0x2,%rdi
 2a172db:	shr    $0x20,%rdi
 2a172df:	test   %rdi,%rdi
 2a172e2:	jne    2a19ba2 <wasm[0]::function[1015]::helper::object_read+0x1ba42>
 2a172e8:	shl    $0x2,%esi
 2a172eb:	add    $0x14,%esi
 2a172ee:	jb     2a19ba4 <wasm[0]::function[1015]::helper::object_read+0x1ba44>
 2a172f4:	add    %esi,%r9d
 2a172f7:	jb     2a19ba6 <wasm[0]::function[1015]::helper::object_read+0x1ba46>
 2a172fd:	mov    %r9d,%r8d
 2a17300:	lea    (%rcx,%r8,1),%rdi
 2a17304:	cmp    %rax,%r8
 2a17307:	cmova  %rdx,%rdi
 2a1730b:	sub    $0x20,%esi
 2a1730e:	sub    %rsi,%rdi
 2a17311:	mov    (%rdi),%esi
 2a17313:	test   %esi,%esi
 2a17315:	je     2a19ba8 <wasm[0]::function[1015]::helper::object_read+0x1ba48>
 2a1731b:	test   %esi,%esi
 2a1731d:	je     2a19baa <wasm[0]::function[1015]::helper::object_read+0x1ba4a>
 2a17323:	mov    %esi,%esi
 2a17325:	add    %rsi,%rcx
 2a17328:	cmp    %rax,%rsi
 2a1732b:	cmova  %rdx,%rcx
 2a1732f:	mov    0x18(%rcx),%r12d
 2a17333:	mov    0x10(%rcx),%rbx
 2a17337:	mov    0x1c(%rcx),%eax
 2a1733a:	mov    %eax,0x78(%rsp)
 2a1733e:	mov    $0x6,%eax
 2a17343:	mov    %rax,0x280(%rsp)
 2a1734b:	cmp    $0x6,%r12d
 2a1734f:	sete   %cl
 2a17352:	cmp    $0x7,%r12d
 2a17356:	sete   %al
 2a17359:	or     %eax,%ecx
 2a1735b:	cmp    $0x8,%r12d
 2a1735f:	sete   %al
 2a17362:	or     %eax,%ecx
 2a17364:	cmp    $0x9,%r12d
 2a17368:	sete   %al
 2a1736b:	or     %eax,%ecx
 2a1736d:	movzbl %cl,%eax
 2a17370:	test   %eax,%eax
 2a17372:	je     2a19bac <wasm[0]::function[1015]::helper::object_read+0x1ba4c>
 2a17378:	mov    $0x997,%edx
 2a1737d:	mov    0x190(%rsp),%rsi
 2a17385:	mov    0x190(%rsp),%rdi
 2a1738d:	call   2f4f240 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 2a17392:	mov    %rdi,%rcx
 2a17395:	mov    %rdi,0x298(%rsp)
 2a1739d:	xor    %ecx,%edi
 2a1739f:	mov    %rdi,0x298(%rsp)
 2a173a7:	test   %eax,%eax
 2a173a9:	je     2a19bae <wasm[0]::function[1015]::helper::object_read+0x1ba4e>
 2a173af:	mov    0x78(%rsp),%r9d
 2a173b4:	mov    $0x5,%edx
 2a173b9:	mov    %eax,(%rsp)
 2a173bc:	mov    %r12,%rcx
 2a173bf:	mov    0x190(%rsp),%rsi
 2a173c7:	mov    %rbx,%r8
 2a173ca:	mov    %rsi,%rdi
 2a173cd:	call   2f4efa0 <wasm[0]::function[1101]::helper::runtime_error_for_throw>
 2a173d2:	sub    $0x10,%rsp
 2a173d6:	test   %eax,%eax
 2a173d8:	je     2a19bb0 <wasm[0]::function[1015]::helper::object_read+0x1ba50>
 2a173de:	mov    %rcx,%rdx
 2a173e1:	mov    %rcx,0x288(%rsp)
 2a173e9:	xor    %rdx,%rcx
 2a173ec:	mov    %rcx,0x288(%rsp)
 2a173f4:	mov    0x278(%rsp),%rsi
 2a173fc:	jmp    2a1776e <wasm[0]::function[1015]::helper::object_read+0x1960e>
 2a17401:	mov    0x2a0(%rsp),%rcx
 2a17409:	mov    0x2a8(%rsp),%rdx
 2a17411:	mov    0x1a8(%rsp),%r9
 2a17419:	mov    0x70(%rsp),%eax
 2a1741d:	test   %eax,%eax
 2a1741f:	je     2a19bb2 <wasm[0]::function[1015]::helper::object_read+0x1ba52>
 2a17425:	mov    0x58(%rsp),%r8d
 2a1742a:	mov    0x60(%rsp),%r10d
 2a1742f:	mov    0x68(%rsp),%esi
 2a17433:	mov    0x50(%rsp),%edi
 2a17437:	mov    %r13,(%rsp)
 2a1743b:	mov    %r10d,0x8(%rsp)
 2a17440:	mov    0x1b8(%rsp),%r10
 2a17448:	mov    %r10d,0x10(%rsp)
 2a1744d:	mov    0x1c0(%rsp),%r10
 2a17455:	mov    %r10,0x18(%rsp)
 2a1745a:	mov    %esi,0x20(%rsp)
 2a1745e:	mov    %edi,0x28(%rsp)
 2a17462:	mov    %eax,0x30(%rsp)
 2a17466:	mov    0x190(%rsp),%rsi
 2a1746e:	mov    %rsi,%rdi
 2a17471:	call   29fe160 <wasm[0]::function[1015]::helper::object_read>
 2a17476:	sub    $0x40,%rsp
 2a1747a:	mov    %rdi,0x298(%rsp)
 2a17482:	mov    %rcx,0x288(%rsp)
 2a1748a:	mov    %rax,0x280(%rsp)
 2a17492:	mov    %rdx,%rax
 2a17495:	jmp    2a1776e <wasm[0]::function[1015]::helper::object_read+0x1960e>
 2a1749a:	mov    %rdi,0x298(%rsp)
 2a174a2:	mov    %r15,%rcx
 2a174a5:	mov    %rax,%r8
 2a174a8:	mov    %rdx,%rax
 2a174ab:	mov    %r8,%rdx
 2a174ae:	mov    %rdx,0x280(%rsp)
 2a174b6:	mov    %rcx,0x288(%rsp)
 2a174be:	jmp    2a1776e <wasm[0]::function[1015]::helper::object_read+0x1960e>
 2a174c3:	mov    0x50(%rsp),%eax
 2a174c7:	xor    %edx,%edx
 2a174c9:	mov    %eax,0x48(%rsp)
 2a174cd:	mov    %edx,0x50(%rsp)
 2a174d1:	mov    0x2e8(%rsp),%r15
 2a174d9:	mov    (%r15),%rax
 2a174dc:	mov    0x228(%rsp),%rcx
 2a174e4:	cmp    %rcx,%rax
 2a174e7:	jae    2a18dff <wasm[0]::function[1015]::helper::object_read+0x1ac9f>
 2a174ed:	jmp    2a174fa <wasm[0]::function[1015]::helper::object_read+0x1939a>
 2a174f2:	mov    %rcx,0x228(%rsp)
 2a174fa:	mov    0x48(%rsp),%esi
 2a174fe:	mov    0x50(%rsp),%edx
 2a17502:	test   %esi,%esi
 2a17504:	je     2a17577 <wasm[0]::function[1015]::helper::object_read+0x19417>
 2a1750a:	mov    0x48(%rsp),%r8d
 2a1750f:	test   %r8d,%r8d
 2a17512:	je     2a19bb4 <wasm[0]::function[1015]::helper::object_read+0x1ba54>
 2a17518:	mov    0x2e0(%rsp),%r14
 2a17520:	mov    0x28(%r14),%r10
 2a17524:	mov    0x20(%r14),%rax
 2a17528:	mov    %r8d,%r11d
 2a1752b:	lea    (%rax,%r11,1),%rdi
 2a1752f:	xor    %rax,%rax
 2a17532:	cmp    %r10,%r11
 2a17535:	cmova  %rax,%rdi
 2a17539:	mov    0x10(%rdi),%edx
 2a1753c:	test   %edx,%edx
 2a1753e:	jne    2a17577 <wasm[0]::function[1015]::helper::object_read+0x19417>
 2a17544:	mov    0x48(%rsp),%ecx
 2a17548:	test   %ecx,%ecx
 2a1754a:	je     2a19bb6 <wasm[0]::function[1015]::helper::object_read+0x1ba56>
 2a17550:	mov    0x2e0(%rsp),%r14
 2a17558:	mov    0x28(%r14),%rax
 2a1755c:	mov    %ecx,%esi
 2a1755e:	mov    %rsi,%rcx
 2a17561:	add    0x20(%r14),%rcx
 2a17565:	xor    %rdi,%rdi
 2a17568:	cmp    %rax,%rsi
 2a1756b:	cmova  %rdi,%rcx
 2a1756f:	mov    0x1c(%rcx),%eax
 2a17572:	jmp    2a174c9 <wasm[0]::function[1015]::helper::object_read+0x19369>
 2a17577:	test   %edx,%edx
 2a17579:	jne    2a17595 <wasm[0]::function[1015]::helper::object_read+0x19435>
 2a1757f:	mov    0x190(%rsp),%rsi
 2a17587:	mov    0x8c0(%rsi),%edx
 2a1758d:	test   %edx,%edx
 2a1758f:	je     2a19bb8 <wasm[0]::function[1015]::helper::object_read+0x1ba58>
 2a17595:	mov    %edx,0x48(%rsp)
 2a17599:	test   %edx,%edx
 2a1759b:	je     2a19bba <wasm[0]::function[1015]::helper::object_read+0x1ba5a>
 2a175a1:	mov    0x190(%rsp),%rsi
 2a175a9:	mov    0x190(%rsp),%rdi
 2a175b1:	call   2ae3360 <wasm[0]::function[1049]::helper::realm_ensure_errors>
 2a175b6:	mov    0x48(%rsp),%edx
 2a175ba:	test   %edx,%edx
 2a175bc:	je     2a19bbc <wasm[0]::function[1015]::helper::object_read+0x1ba5c>
 2a175c2:	test   %edx,%edx
 2a175c4:	je     2a19bbe <wasm[0]::function[1015]::helper::object_read+0x1ba5e>
 2a175ca:	mov    0x2e0(%rsp),%r14
 2a175d2:	mov    0x28(%r14),%rax
 2a175d6:	mov    0x20(%r14),%rcx
 2a175da:	mov    %edx,%edi
 2a175dc:	lea    (%rcx,%rdi,1),%rsi
 2a175e0:	xor    %rdx,%rdx
 2a175e3:	cmp    %rax,%rdi
 2a175e6:	cmova  %rdx,%rsi
 2a175ea:	mov    0x2c(%rsi),%esi
 2a175ed:	test   %esi,%esi
 2a175ef:	je     2a19bc0 <wasm[0]::function[1015]::helper::object_read+0x1ba60>
 2a175f5:	test   %esi,%esi
 2a175f7:	je     2a19bc2 <wasm[0]::function[1015]::helper::object_read+0x1ba62>
 2a175fd:	mov    %esi,%r8d
 2a17600:	lea    0x10(%rcx,%r8,1),%rdi
 2a17605:	cmp    %rax,%r8
 2a17608:	cmova  %rdx,%rdi
 2a1760c:	mov    (%rdi),%edi
 2a1760e:	cmp    $0x3,%edi
 2a17611:	jbe    2a19bc4 <wasm[0]::function[1015]::helper::object_read+0x1ba64>
 2a17617:	mov    %edi,%r8d
 2a1761a:	shl    $0x2,%r8
 2a1761e:	shr    $0x20,%r8
 2a17622:	test   %r8,%r8
 2a17625:	jne    2a19bc6 <wasm[0]::function[1015]::helper::object_read+0x1ba66>
 2a1762b:	shl    $0x2,%edi
 2a1762e:	add    $0x14,%edi
 2a17631:	jb     2a19bc8 <wasm[0]::function[1015]::helper::object_read+0x1ba68>
 2a17637:	add    %edi,%esi
 2a17639:	jb     2a19bca <wasm[0]::function[1015]::helper::object_read+0x1ba6a>
 2a1763f:	mov    %esi,%r8d
 2a17642:	lea    (%rcx,%r8,1),%rsi
 2a17646:	cmp    %rax,%r8
 2a17649:	cmova  %rdx,%rsi
 2a1764d:	sub    $0x20,%edi
 2a17650:	sub    %rdi,%rsi
 2a17653:	mov    (%rsi),%esi
 2a17655:	test   %esi,%esi
 2a17657:	je     2a19bcc <wasm[0]::function[1015]::helper::object_read+0x1ba6c>
 2a1765d:	test   %esi,%esi
 2a1765f:	je     2a19bce <wasm[0]::function[1015]::helper::object_read+0x1ba6e>
 2a17665:	mov    %esi,%esi
 2a17667:	add    %rsi,%rcx
 2a1766a:	cmp    %rax,%rsi
 2a1766d:	cmova  %rdx,%rcx
 2a17671:	mov    0x18(%rcx),%r12d
 2a17675:	mov    0x10(%rcx),%rbx
 2a17679:	mov    0x1c(%rcx),%eax
 2a1767c:	mov    %eax,0x48(%rsp)
 2a17680:	mov    $0x6,%eax
 2a17685:	mov    %rax,0x280(%rsp)
 2a1768d:	cmp    $0x6,%r12d
 2a17691:	sete   %cl
 2a17694:	cmp    $0x7,%r12d
 2a17698:	sete   %al
 2a1769b:	or     %eax,%ecx
 2a1769d:	cmp    $0x8,%r12d
 2a176a1:	sete   %al
 2a176a4:	or     %eax,%ecx
 2a176a6:	cmp    $0x9,%r12d
 2a176aa:	sete   %al
 2a176ad:	or     %eax,%ecx
 2a176af:	movzbl %cl,%eax
 2a176b2:	test   %eax,%eax
 2a176b4:	je     2a19bd0 <wasm[0]::function[1015]::helper::object_read+0x1ba70>
 2a176ba:	mov    $0x9a6,%edx
 2a176bf:	mov    0x190(%rsp),%rsi
 2a176c7:	mov    0x190(%rsp),%rdi
 2a176cf:	call   2f4f240 <wasm[0]::function[1102]::helper::pooled_string_resolve>
 2a176d4:	mov    %rdi,%rcx
 2a176d7:	mov    %rdi,0x298(%rsp)
 2a176df:	xor    %ecx,%edi
 2a176e1:	mov    %rdi,0x298(%rsp)
 2a176e9:	test   %eax,%eax
 2a176eb:	je     2a19bd2 <wasm[0]::function[1015]::helper::object_read+0x1ba72>
 2a176f1:	mov    0x48(%rsp),%r9d
 2a176f6:	mov    $0x5,%edx
 2a176fb:	mov    %eax,(%rsp)
 2a176fe:	mov    %r12,%rcx
 2a17701:	mov    0x190(%rsp),%rsi
 2a17709:	mov    %rbx,%r8
 2a1770c:	mov    %rsi,%rdi
 2a1770f:	call   2f4efa0 <wasm[0]::function[1101]::helper::runtime_error_for_throw>
 2a17714:	sub    $0x10,%rsp
 2a17718:	test   %eax,%eax
 2a1771a:	je     2a19bd4 <wasm[0]::function[1015]::helper::object_read+0x1ba74>
 2a17720:	mov    %rcx,%rdx
 2a17723:	mov    %rcx,0x288(%rsp)
 2a1772b:	xor    %rdx,%rcx
 2a1772e:	mov    %rcx,0x288(%rsp)
 2a17736:	mov    0x278(%rsp),%rsi
 2a1773e:	jmp    2a1776e <wasm[0]::function[1015]::helper::object_read+0x1960e>
 2a17743:	mov    0x2d8(%rsp),%rcx
 2a1774b:	mov    %rdx,%rax
 2a1774e:	mov    0x2d0(%rsp),%rdx
 2a17756:	mov    %rdx,0x280(%rsp)
 2a1775e:	mov    %rcx,0x288(%rsp)
 2a17766:	mov    %rdi,0x298(%rsp)
 2a1776e:	mov    0x298(%rsp),%rdi
 2a17776:	mov    %rax,%rdx
 2a17779:	mov    0x288(%rsp),%rcx
 2a17781:	mov    0x280(%rsp),%rax
 2a17789:	mov    0x2f0(%rsp),%rbx
 2a17791:	mov    0x2f8(%rsp),%r12
 2a17799:	mov    0x300(%rsp),%r13
 2a177a1:	mov    0x308(%rsp),%r14
 2a177a9:	mov    0x310(%rsp),%r15
 2a177b1:	add    $0x320,%rsp
 2a177b8:	mov    %rbp,%rsp
 2a177bb:	pop    %rbp
 2a177bc:	ret    $0x40
 2a177bf:	mov    0x190(%rsp),%rdi
 2a177c7:	call   3039b69 <wasmtime_builtin_new_epoch>
 2a177cc:	mov    %rax,0x228(%rsp)
 2a177d4:	jmp    29fe269 <wasm[0]::function[1015]::helper::object_read+0x109>
 2a177d9:	mov    0x2e0(%rsp),%r14
 2a177e1:	mov    0x8(%r14),%rax
 2a177e5:	mov    %rax,0x228(%rsp)
 2a177ed:	cmp    %rax,%rsi
 2a177f0:	jb     29fe80e <wasm[0]::function[1015]::helper::object_read+0x6ae>
 2a177f6:	mov    0x190(%rsp),%rdi
 2a177fe:	call   3039b69 <wasmtime_builtin_new_epoch>
 2a17803:	mov    %rax,0x228(%rsp)
 2a1780b:	mov    0x238(%rsp),%r12
 2a17813:	jmp    29fe816 <wasm[0]::function[1015]::helper::object_read+0x6b6>
 2a17818:	mov    0x2e0(%rsp),%r14
 2a17820:	mov    0x8(%r14),%rax
 2a17824:	mov    %rax,0x228(%rsp)
 2a1782c:	cmp    %rax,%rcx
 2a1782f:	jb     29ff62a <wasm[0]::function[1015]::helper::object_read+0x14ca>
 2a17835:	mov    0x190(%rsp),%rdi
 2a1783d:	call   3039b69 <wasmtime_builtin_new_epoch>
 2a17842:	mov    %rax,0x228(%rsp)
 2a1784a:	jmp    29ff62a <wasm[0]::function[1015]::helper::object_read+0x14ca>
 2a1784f:	mov    0x2e0(%rsp),%r14
 2a17857:	mov    0x8(%r14),%rax
 2a1785b:	mov    %rax,0x228(%rsp)
 2a17863:	cmp    %rax,%rcx
 2a17866:	jb     2a00476 <wasm[0]::function[1015]::helper::object_read+0x2316>
 2a1786c:	mov    0x190(%rsp),%rdi
 2a17874:	call   3039b69 <wasmtime_builtin_new_epoch>
 2a17879:	mov    %rax,0x228(%rsp)
 2a17881:	jmp    2a00476 <wasm[0]::function[1015]::helper::object_read+0x2316>
 2a17886:	mov    0x2e0(%rsp),%r14
 2a1788e:	mov    0x8(%r14),%rcx
 2a17892:	mov    %rcx,0x228(%rsp)
 2a1789a:	cmp    %rcx,%rax
 2a1789d:	jb     2a00a37 <wasm[0]::function[1015]::helper::object_read+0x28d7>
 2a178a3:	mov    0x190(%rsp),%rdi
 2a178ab:	call   3039b69 <wasmtime_builtin_new_epoch>
 2a178b0:	mov    %rax,0x228(%rsp)
 2a178b8:	jmp    2a00a37 <wasm[0]::function[1015]::helper::object_read+0x28d7>
 2a178bd:	mov    $0xa800000e,%esi
 2a178c2:	mov    0x190(%rsp),%rax
 2a178ca:	mov    0x28(%rax),%rax
 2a178ce:	mov    0x194(%rax),%edx
 2a178d4:	mov    $0x10,%r8d
 2a178da:	mov    0x190(%rsp),%rdi
 2a178e2:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 2a178e7:	mov    %eax,%ecx
 2a178e9:	mov    0x2e0(%rsp),%r14
 2a178f1:	add    0x20(%r14),%rcx
 2a178f5:	jmp    2a01382 <wasm[0]::function[1015]::helper::object_read+0x3222>
 2a178fa:	mov    0x2e0(%rsp),%r14
 2a17902:	mov    0x8(%r14),%rax
 2a17906:	mov    %rax,0x228(%rsp)
 2a1790e:	cmp    %rax,%r8
 2a17911:	jb     2a014b9 <wasm[0]::function[1015]::helper::object_read+0x3359>
 2a17917:	mov    0x190(%rsp),%rdi
 2a1791f:	call   3039b69 <wasmtime_builtin_new_epoch>
 2a17924:	mov    %rax,0x228(%rsp)
 2a1792c:	jmp    2a014b9 <wasm[0]::function[1015]::helper::object_read+0x3359>
 2a17931:	mov    0x2e0(%rsp),%r14
 2a17939:	mov    0x8(%r14),%rcx
 2a1793d:	mov    %rcx,0x228(%rsp)
 2a17945:	cmp    %rcx,%rax
 2a17948:	jb     2a015ee <wasm[0]::function[1015]::helper::object_read+0x348e>
 2a1794e:	mov    0x190(%rsp),%rdi
 2a17956:	call   3039b69 <wasmtime_builtin_new_epoch>
 2a1795b:	mov    %rax,0x228(%rsp)
 2a17963:	mov    0x238(%rsp),%rdx
 2a1796b:	jmp    2a015f6 <wasm[0]::function[1015]::helper::object_read+0x3496>
 2a17970:	mov    $0xb0000042,%esi
 2a17975:	mov    $0x20,%ecx
 2a1797a:	mov    0x218(%rsp),%rdx
 2a17982:	mov    0x190(%rsp),%rdi
 2a1798a:	mov    0x1d8(%rsp),%r8
 2a17992:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 2a17997:	mov    %eax,%esi
 2a17999:	mov    0x2e0(%rsp),%r14
 2a179a1:	add    0x20(%r14),%rsi
 2a179a5:	mov    0x230(%rsp),%r15
 2a179ad:	jmp    2a01836 <wasm[0]::function[1015]::helper::object_read+0x36d6>
 2a179b2:	mov    $0xb0000072,%esi
 2a179b7:	mov    $0x20,%ecx
 2a179bc:	mov    0x1d0(%rsp),%r13
 2a179c4:	mov    %r13,%rdx
 2a179c7:	mov    0x190(%rsp),%rdi
 2a179cf:	mov    0x1d8(%rsp),%r8
 2a179d7:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 2a179dc:	mov    %eax,%ecx
 2a179de:	mov    0x2e0(%rsp),%r14
 2a179e6:	add    0x20(%r14),%rcx
 2a179ea:	jmp    2a018b9 <wasm[0]::function[1015]::helper::object_read+0x3759>
 2a179ef:	mov    $0xa800000e,%esi
 2a179f4:	mov    0x190(%rsp),%rax
 2a179fc:	mov    0x28(%rax),%rax
 2a17a00:	mov    0x194(%rax),%edx
 2a17a06:	mov    $0x10,%r8d
 2a17a0c:	mov    0x190(%rsp),%rdi
 2a17a14:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 2a17a19:	mov    %eax,%r11d
 2a17a1c:	mov    0x2e0(%rsp),%rcx
 2a17a24:	add    0x20(%rcx),%r11
 2a17a28:	jmp    2a01bcf <wasm[0]::function[1015]::helper::object_read+0x3a6f>
 2a17a2d:	mov    0x2e0(%rsp),%r14
 2a17a35:	mov    0x8(%r14),%rax
 2a17a39:	mov    %rax,0x228(%rsp)
 2a17a41:	cmp    %rax,%rsi
 2a17a44:	jb     2a01cf6 <wasm[0]::function[1015]::helper::object_read+0x3b96>
 2a17a4a:	mov    0x190(%rsp),%rdi
 2a17a52:	call   3039b69 <wasmtime_builtin_new_epoch>
 2a17a57:	mov    %rax,0x228(%rsp)
 2a17a5f:	jmp    2a01cf6 <wasm[0]::function[1015]::helper::object_read+0x3b96>
 2a17a64:	mov    0x2e0(%rsp),%r14
 2a17a6c:	mov    0x8(%r14),%rcx
 2a17a70:	mov    %rcx,0x228(%rsp)
 2a17a78:	cmp    %rcx,%rax
 2a17a7b:	jb     2a01e21 <wasm[0]::function[1015]::helper::object_read+0x3cc1>
 2a17a81:	mov    0x190(%rsp),%rdi
 2a17a89:	call   3039b69 <wasmtime_builtin_new_epoch>
 2a17a8e:	mov    %rax,0x228(%rsp)
 2a17a96:	mov    0x1d0(%rsp),%r9
 2a17a9e:	jmp    2a01e29 <wasm[0]::function[1015]::helper::object_read+0x3cc9>
 2a17aa3:	mov    0x198(%rsp),%rcx
 2a17aab:	mov    %rbx,%rdx
 2a17aae:	mov    0x1a0(%rsp),%rsi
 2a17ab6:	mov    0x190(%rsp),%rdi
 2a17abe:	mov    0x2c8(%rsp),%r8
 2a17ac6:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 2a17acb:	mov    %eax,%ecx
 2a17acd:	mov    0x2e0(%rsp),%r14
 2a17ad5:	add    0x20(%r14),%rcx
 2a17ad9:	jmp    2a01f2a <wasm[0]::function[1015]::helper::object_read+0x3dca>
 2a17ade:	mov    0x2e0(%rsp),%r14
 2a17ae6:	mov    0x8(%r14),%rcx
 2a17aea:	mov    %rcx,0x228(%rsp)
 2a17af2:	cmp    %rcx,%rax
 2a17af5:	jb     2a0229c <wasm[0]::function[1015]::helper::object_read+0x413c>
 2a17afb:	mov    0x190(%rsp),%rdi
 2a17b03:	call   3039b69 <wasmtime_builtin_new_epoch>
 2a17b08:	mov    %rax,0x228(%rsp)
 2a17b10:	jmp    2a0229c <wasm[0]::function[1015]::helper::object_read+0x413c>
 2a17b15:	mov    0x2e0(%rsp),%r14
 2a17b1d:	mov    0x8(%r14),%rsi
 2a17b21:	mov    %rsi,%r8
 2a17b24:	mov    %rsi,0x228(%rsp)
 2a17b2c:	cmp    %r8,%rax
 2a17b2f:	jb     2a03021 <wasm[0]::function[1015]::helper::object_read+0x4ec1>
 2a17b35:	mov    0x190(%rsp),%rdi
 2a17b3d:	call   3039b69 <wasmtime_builtin_new_epoch>
 2a17b42:	mov    %rax,0x228(%rsp)
 2a17b4a:	jmp    2a03021 <wasm[0]::function[1015]::helper::object_read+0x4ec1>
 2a17b4f:	mov    $0xb0000002,%esi
 2a17b54:	mov    0x190(%rsp),%rcx
 2a17b5c:	mov    0x28(%rcx),%rdi
 2a17b60:	mov    0x1d0(%rdi),%edx
 2a17b66:	mov    $0x40,%ecx
 2a17b6b:	mov    $0x10,%r8d
 2a17b71:	mov    0x190(%rsp),%rdi
 2a17b79:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 2a17b7e:	mov    %eax,%r12d
 2a17b81:	mov    0x2e0(%rsp),%r14
 2a17b89:	add    0x20(%r14),%r12
 2a17b8d:	jmp    2a033b1 <wasm[0]::function[1015]::helper::object_read+0x5251>
 2a17b92:	mov    $0xb0001ffa,%esi
 2a17b97:	mov    0x190(%rsp),%rcx
 2a17b9f:	mov    0x28(%rcx),%rax
 2a17ba3:	mov    0x1e0(%rax),%edx
 2a17ba9:	mov    $0x40,%ecx
 2a17bae:	mov    $0x10,%r8d
 2a17bb4:	mov    0x190(%rsp),%rdi
 2a17bbc:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 2a17bc1:	mov    %eax,%ebx
 2a17bc3:	mov    0x2e0(%rsp),%r14
 2a17bcb:	add    0x20(%r14),%rbx
 2a17bcf:	mov    %rax,%rdx
 2a17bd2:	jmp    2a034e8 <wasm[0]::function[1015]::helper::object_read+0x5388>
 2a17bd7:	mov    $0xb00300fa,%esi
 2a17bdc:	mov    0x190(%rsp),%rcx
 2a17be4:	mov    0x28(%rcx),%rax
 2a17be8:	mov    0x1d4(%rax),%edx
 2a17bee:	mov    $0x50,%ecx
 2a17bf3:	mov    $0x10,%r8d
 2a17bf9:	mov    0x190(%rsp),%rdi
 2a17c01:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 2a17c06:	mov    %eax,%r8d
 2a17c09:	mov    0x2e0(%rsp),%r14
 2a17c11:	add    0x20(%r14),%r8
 2a17c15:	jmp    2a03632 <wasm[0]::function[1015]::helper::object_read+0x54d2>
 2a17c1a:	mov    $0xb0000042,%esi
 2a17c1f:	mov    0x190(%rsp),%rcx
 2a17c27:	mov    0x28(%rcx),%rax
 2a17c2b:	mov    0x120(%rax),%edx
 2a17c31:	mov    $0x20,%ecx
 2a17c36:	mov    $0x10,%r8d
 2a17c3c:	mov    0x190(%rsp),%rdi
 2a17c44:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 2a17c49:	mov    %eax,%r9d
 2a17c4c:	mov    0x2e0(%rsp),%r14
 2a17c54:	add    0x20(%r14),%r9
 2a17c58:	jmp    2a0376f <wasm[0]::function[1015]::helper::object_read+0x560f>
 2a17c5d:	mov    $0xb0000042,%esi
 2a17c62:	mov    0x190(%rsp),%rcx
 2a17c6a:	mov    0x28(%rcx),%rax
 2a17c6e:	mov    0x120(%rax),%edx
 2a17c74:	mov    $0x20,%ecx
 2a17c79:	mov    $0x10,%r8d
 2a17c7f:	mov    0x190(%rsp),%rdi
 2a17c87:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 2a17c8c:	mov    %eax,%ecx
 2a17c8e:	mov    0x2e0(%rsp),%r14
 2a17c96:	add    0x20(%r14),%rcx
 2a17c9a:	jmp    2a037fb <wasm[0]::function[1015]::helper::object_read+0x569b>
 2a17c9f:	mov    $0xa800000e,%esi
 2a17ca4:	mov    0x190(%rsp),%rcx
 2a17cac:	mov    0x28(%rcx),%rax
 2a17cb0:	mov    0x1b4(%rax),%edx
 2a17cb6:	mov    $0x1c,%ecx
 2a17cbb:	mov    $0x10,%r8d
 2a17cc1:	mov    0x190(%rsp),%rdi
 2a17cc9:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 2a17cce:	mov    %eax,%edx
 2a17cd0:	mov    0x2e0(%rsp),%r14
 2a17cd8:	add    0x20(%r14),%rdx
 2a17cdc:	jmp    2a0389c <wasm[0]::function[1015]::helper::object_read+0x573c>
 2a17ce1:	mov    0x2e0(%rsp),%r14
 2a17ce9:	mov    0x8(%r14),%rax
 2a17ced:	mov    %rax,0x228(%rsp)
 2a17cf5:	cmp    %rax,%rcx
 2a17cf8:	jb     2a04084 <wasm[0]::function[1015]::helper::object_read+0x5f24>
 2a17cfe:	mov    0x190(%rsp),%rdi
 2a17d06:	call   3039b69 <wasmtime_builtin_new_epoch>
 2a17d0b:	mov    %rax,0x228(%rsp)
 2a17d13:	jmp    2a04084 <wasm[0]::function[1015]::helper::object_read+0x5f24>
 2a17d18:	mov    0x2e0(%rsp),%r14
 2a17d20:	mov    0x8(%r14),%rax
 2a17d24:	mov    %rax,0x228(%rsp)
 2a17d2c:	cmp    %rax,%rcx
 2a17d2f:	jb     2a04d7e <wasm[0]::function[1015]::helper::object_read+0x6c1e>
 2a17d35:	mov    0x190(%rsp),%rdi
 2a17d3d:	call   3039b69 <wasmtime_builtin_new_epoch>
 2a17d42:	mov    %rax,0x228(%rsp)
 2a17d4a:	jmp    2a04d7e <wasm[0]::function[1015]::helper::object_read+0x6c1e>
 2a17d4f:	mov    0x2e0(%rsp),%r14
 2a17d57:	mov    0x8(%r14),%rcx
 2a17d5b:	mov    %rcx,0x228(%rsp)
 2a17d63:	cmp    %rcx,%rax
 2a17d66:	jb     2a05b55 <wasm[0]::function[1015]::helper::object_read+0x79f5>
 2a17d6c:	mov    0x190(%rsp),%rdi
 2a17d74:	call   3039b69 <wasmtime_builtin_new_epoch>
 2a17d79:	mov    %rax,0x228(%rsp)
 2a17d81:	jmp    2a05b55 <wasm[0]::function[1015]::helper::object_read+0x79f5>
 2a17d86:	mov    0x2e0(%rsp),%r14
 2a17d8e:	mov    0x8(%r14),%rax
 2a17d92:	mov    %rax,0x228(%rsp)
 2a17d9a:	cmp    %rax,%rcx
 2a17d9d:	jb     2a0693a <wasm[0]::function[1015]::helper::object_read+0x87da>
 2a17da3:	mov    0x190(%rsp),%rdi
 2a17dab:	call   3039b69 <wasmtime_builtin_new_epoch>
 2a17db0:	mov    %rax,0x228(%rsp)
 2a17db8:	jmp    2a0693a <wasm[0]::function[1015]::helper::object_read+0x87da>
 2a17dbd:	mov    0x2e0(%rsp),%r14
 2a17dc5:	mov    0x8(%r14),%rax
 2a17dc9:	mov    %rax,0x228(%rsp)
 2a17dd1:	cmp    %rax,%rcx
 2a17dd4:	jb     2a0778b <wasm[0]::function[1015]::helper::object_read+0x962b>
 2a17dda:	mov    0x190(%rsp),%rdi
 2a17de2:	call   3039b69 <wasmtime_builtin_new_epoch>
 2a17de7:	mov    %rax,0x228(%rsp)
 2a17def:	jmp    2a0778b <wasm[0]::function[1015]::helper::object_read+0x962b>
 2a17df4:	mov    0x2e0(%rsp),%r14
 2a17dfc:	mov    0x8(%r14),%rax
 2a17e00:	mov    %rax,0x228(%rsp)
 2a17e08:	cmp    %rax,%rcx
 2a17e0b:	jb     2a085e9 <wasm[0]::function[1015]::helper::object_read+0xa489>
 2a17e11:	mov    0x190(%rsp),%rdi
 2a17e19:	call   3039b69 <wasmtime_builtin_new_epoch>
 2a17e1e:	mov    %rax,0x228(%rsp)
 2a17e26:	jmp    2a085e9 <wasm[0]::function[1015]::helper::object_read+0xa489>
 2a17e2b:	mov    $0xb0000042,%esi
 2a17e30:	mov    0x190(%rsp),%rcx
 2a17e38:	mov    0x28(%rcx),%rax
 2a17e3c:	mov    0x120(%rax),%edx
 2a17e42:	mov    $0x20,%ecx
 2a17e47:	mov    $0x10,%r8d
 2a17e4d:	mov    0x190(%rsp),%rdi
 2a17e55:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 2a17e5a:	mov    %eax,%ecx
 2a17e5c:	mov    0x2e0(%rsp),%r14
 2a17e64:	add    0x20(%r14),%rcx
 2a17e68:	jmp    2a09769 <wasm[0]::function[1015]::helper::object_read+0xb609>
 2a17e6d:	mov    $0xb0000042,%esi
 2a17e72:	mov    0x190(%rsp),%rcx
 2a17e7a:	mov    0x28(%rcx),%rdx
 2a17e7e:	mov    0x120(%rdx),%edx
 2a17e84:	mov    $0x20,%ecx
 2a17e89:	mov    $0x10,%r8d
 2a17e8f:	mov    0x190(%rsp),%rdi
 2a17e97:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 2a17e9c:	mov    %eax,%ecx
 2a17e9e:	mov    0x2e0(%rsp),%r14
 2a17ea6:	add    0x20(%r14),%rcx
 2a17eaa:	jmp    2a097f4 <wasm[0]::function[1015]::helper::object_read+0xb694>
 2a17eaf:	mov    $0xb0000042,%esi
 2a17eb4:	mov    0x190(%rsp),%rcx
 2a17ebc:	mov    0x28(%rcx),%rax
 2a17ec0:	mov    0x120(%rax),%edx
 2a17ec6:	mov    $0x20,%ecx
 2a17ecb:	mov    $0x10,%r8d
 2a17ed1:	mov    0x190(%rsp),%rdi
 2a17ed9:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 2a17ede:	mov    %eax,%ecx
 2a17ee0:	mov    0x2e0(%rsp),%r14
 2a17ee8:	add    0x20(%r14),%rcx
 2a17eec:	jmp    2a09880 <wasm[0]::function[1015]::helper::object_read+0xb720>
 2a17ef1:	mov    $0xb0000072,%esi
 2a17ef6:	mov    0x190(%rsp),%rcx
 2a17efe:	mov    0x28(%rcx),%rax
 2a17f02:	mov    0x13c(%rax),%edx
 2a17f08:	mov    $0x20,%ecx
 2a17f0d:	mov    $0x10,%r8d
 2a17f13:	mov    0x190(%rsp),%rdi
 2a17f1b:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 2a17f20:	mov    %eax,%edx
 2a17f22:	mov    0x2e0(%rsp),%r14
 2a17f2a:	add    0x20(%r14),%rdx
 2a17f2e:	jmp    2a09949 <wasm[0]::function[1015]::helper::object_read+0xb7e9>
 2a17f33:	mov    $0xb0000072,%esi
 2a17f38:	mov    0x190(%rsp),%rcx
 2a17f40:	mov    0x28(%rcx),%rax
 2a17f44:	mov    0x13c(%rax),%edx
 2a17f4a:	mov    $0x20,%ecx
 2a17f4f:	mov    $0x10,%r8d
 2a17f55:	mov    0x190(%rsp),%rdi
 2a17f5d:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 2a17f62:	mov    %eax,%ecx
 2a17f64:	mov    0x2e0(%rsp),%r14
 2a17f6c:	add    0x20(%r14),%rcx
 2a17f70:	jmp    2a09a21 <wasm[0]::function[1015]::helper::object_read+0xb8c1>
 2a17f75:	mov    0x2e0(%rsp),%r14
 2a17f7d:	mov    0x8(%r14),%rcx
 2a17f81:	mov    %rcx,0x228(%rsp)
 2a17f89:	cmp    %rcx,%rax
 2a17f8c:	jb     2a09e16 <wasm[0]::function[1015]::helper::object_read+0xbcb6>
 2a17f92:	mov    0x190(%rsp),%rdi
 2a17f9a:	call   3039b69 <wasmtime_builtin_new_epoch>
 2a17f9f:	mov    %rax,0x228(%rsp)
 2a17fa7:	jmp    2a09e16 <wasm[0]::function[1015]::helper::object_read+0xbcb6>
 2a17fac:	mov    0x2e0(%rsp),%r14
 2a17fb4:	mov    0x8(%r14),%rax
 2a17fb8:	mov    %rax,0x228(%rsp)
 2a17fc0:	cmp    %rax,%rcx
 2a17fc3:	jb     2a0a3d9 <wasm[0]::function[1015]::helper::object_read+0xc279>
 2a17fc9:	mov    0x190(%rsp),%rdi
 2a17fd1:	call   3039b69 <wasmtime_builtin_new_epoch>
 2a17fd6:	mov    %rax,0x228(%rsp)
 2a17fde:	jmp    2a0a3d9 <wasm[0]::function[1015]::helper::object_read+0xc279>
 2a17fe3:	mov    $0xb0000042,%esi
 2a17fe8:	mov    0x190(%rsp),%rcx
 2a17ff0:	mov    0x28(%rcx),%rax
 2a17ff4:	mov    0x120(%rax),%edx
 2a17ffa:	mov    $0x20,%ecx
 2a17fff:	mov    $0x10,%r8d
 2a18005:	mov    0x190(%rsp),%rdi
 2a1800d:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 2a18012:	mov    %eax,%edi
 2a18014:	mov    0x2e0(%rsp),%r8
 2a1801c:	add    0x20(%r8),%rdi
 2a18020:	jmp    2a0a841 <wasm[0]::function[1015]::helper::object_read+0xc6e1>
 2a18025:	mov    $0xb0000072,%esi
 2a1802a:	mov    0x190(%rsp),%rcx
 2a18032:	mov    0x28(%rcx),%rcx
 2a18036:	mov    0x13c(%rcx),%edx
 2a1803c:	mov    $0x20,%ecx
 2a18041:	mov    $0x10,%r8d
 2a18047:	mov    0x190(%rsp),%rdi
 2a1804f:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 2a18054:	mov    %eax,%ecx
 2a18056:	mov    0x2e0(%rsp),%r14
 2a1805e:	add    0x20(%r14),%rcx
 2a18062:	jmp    2a0a905 <wasm[0]::function[1015]::helper::object_read+0xc7a5>
 2a18067:	mov    $0xa800000e,%esi
 2a1806c:	mov    0x190(%rsp),%rax
 2a18074:	mov    0x28(%rax),%rax
 2a18078:	mov    0x194(%rax),%edx
 2a1807e:	mov    $0x10,%r8d
 2a18084:	mov    0x190(%rsp),%rdi
 2a1808c:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 2a18091:	mov    %eax,%esi
 2a18093:	mov    0x2e0(%rsp),%r14
 2a1809b:	add    0x20(%r14),%rsi
 2a1809f:	jmp    2a0af3e <wasm[0]::function[1015]::helper::object_read+0xcdde>
 2a180a4:	mov    0x2e0(%rsp),%r14
 2a180ac:	mov    0x8(%r14),%rcx
 2a180b0:	mov    %rcx,0x228(%rsp)
 2a180b8:	cmp    %rcx,%rax
 2a180bb:	jb     2a0b056 <wasm[0]::function[1015]::helper::object_read+0xcef6>
 2a180c1:	mov    0x190(%rsp),%rdi
 2a180c9:	call   3039b69 <wasmtime_builtin_new_epoch>
 2a180ce:	mov    %rax,0x228(%rsp)
 2a180d6:	jmp    2a0b056 <wasm[0]::function[1015]::helper::object_read+0xcef6>
 2a180db:	mov    0x2e0(%rsp),%r14
 2a180e3:	mov    0x8(%r14),%rcx
 2a180e7:	mov    %rcx,0x228(%rsp)
 2a180ef:	cmp    %rcx,%rax
 2a180f2:	jb     2a0b179 <wasm[0]::function[1015]::helper::object_read+0xd019>
 2a180f8:	mov    0x190(%rsp),%rdi
 2a18100:	call   3039b69 <wasmtime_builtin_new_epoch>
 2a18105:	mov    %rax,0x228(%rsp)
 2a1810d:	mov    0x208(%rsp),%r10
 2a18115:	jmp    2a0b181 <wasm[0]::function[1015]::helper::object_read+0xd021>
 2a1811a:	mov    0x1e0(%rsp),%rcx
 2a18122:	mov    0x1e8(%rsp),%rdx
 2a1812a:	mov    0x1f0(%rsp),%rsi
 2a18132:	mov    0x190(%rsp),%rdi
 2a1813a:	mov    0x1d8(%rsp),%r8
 2a18142:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 2a18147:	mov    %eax,%ecx
 2a18149:	mov    0x2e0(%rsp),%rdx
 2a18151:	add    0x20(%rdx),%rcx
 2a18155:	mov    0x1f8(%rsp),%r12
 2a1815d:	jmp    2a0b3b0 <wasm[0]::function[1015]::helper::object_read+0xd250>
 2a18162:	mov    0x1e0(%rsp),%rcx
 2a1816a:	mov    %rbx,%rdx
 2a1816d:	mov    0x1d0(%rsp),%rsi
 2a18175:	mov    0x190(%rsp),%rdi
 2a1817d:	mov    0x1d8(%rsp),%r8
 2a18185:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 2a1818a:	mov    %eax,%ecx
 2a1818c:	mov    0x2e0(%rsp),%r14
 2a18194:	add    0x20(%r14),%rcx
 2a18198:	jmp    2a0b42f <wasm[0]::function[1015]::helper::object_read+0xd2cf>
 2a1819d:	mov    $0xa800000e,%esi
 2a181a2:	mov    0x190(%rsp),%rax
 2a181aa:	mov    0x28(%rax),%rax
 2a181ae:	mov    0x194(%rax),%edx
 2a181b4:	mov    $0x10,%r8d
 2a181ba:	mov    0x190(%rsp),%rdi
 2a181c2:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 2a181c7:	mov    %eax,%ecx
 2a181c9:	mov    0x2e0(%rsp),%r14
 2a181d1:	add    0x20(%r14),%rcx
 2a181d5:	jmp    2a0b6f6 <wasm[0]::function[1015]::helper::object_read+0xd596>
 2a181da:	mov    0x2e0(%rsp),%r14
 2a181e2:	mov    0x8(%r14),%r11
 2a181e6:	mov    %r11,%rcx
 2a181e9:	mov    %r11,0x228(%rsp)
 2a181f1:	cmp    %rcx,%rax
 2a181f4:	jb     2a0b7fd <wasm[0]::function[1015]::helper::object_read+0xd69d>
 2a181fa:	mov    0x190(%rsp),%rdi
 2a18202:	call   3039b69 <wasmtime_builtin_new_epoch>
 2a18207:	mov    %rax,0x228(%rsp)
 2a1820f:	jmp    2a0b7fd <wasm[0]::function[1015]::helper::object_read+0xd69d>
 2a18214:	mov    0x2e0(%rsp),%r14
 2a1821c:	mov    0x8(%r14),%rcx
 2a18220:	mov    %rcx,0x228(%rsp)
 2a18228:	cmp    %rcx,%rax
 2a1822b:	jb     2a0b903 <wasm[0]::function[1015]::helper::object_read+0xd7a3>
 2a18231:	mov    0x190(%rsp),%rdi
 2a18239:	call   3039b69 <wasmtime_builtin_new_epoch>
 2a1823e:	mov    %rax,0x228(%rsp)
 2a18246:	mov    0x1d0(%rsp),%rcx
 2a1824e:	jmp    2a0b90b <wasm[0]::function[1015]::helper::object_read+0xd7ab>
 2a18253:	mov    0x198(%rsp),%rcx
 2a1825b:	mov    %rbx,%rdx
 2a1825e:	mov    0x1a0(%rsp),%rsi
 2a18266:	mov    0x190(%rsp),%rdi
 2a1826e:	mov    0x2a8(%rsp),%r8
 2a18276:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 2a1827b:	mov    %eax,%r8d
 2a1827e:	mov    0x2e0(%rsp),%r14
 2a18286:	add    0x20(%r14),%r8
 2a1828a:	mov    0x1c8(%rsp),%rcx
 2a18292:	jmp    2a0ba1a <wasm[0]::function[1015]::helper::object_read+0xd8ba>
 2a18297:	mov    0x2e0(%rsp),%r14
 2a1829f:	mov    0x8(%r14),%rcx
 2a182a3:	mov    %rcx,0x228(%rsp)
 2a182ab:	cmp    %rcx,%rax
 2a182ae:	jb     2a0bd5a <wasm[0]::function[1015]::helper::object_read+0xdbfa>
 2a182b4:	mov    0x190(%rsp),%rdi
 2a182bc:	call   3039b69 <wasmtime_builtin_new_epoch>
 2a182c1:	mov    %rax,0x228(%rsp)
 2a182c9:	jmp    2a0bd5a <wasm[0]::function[1015]::helper::object_read+0xdbfa>
 2a182ce:	mov    $0xb0000072,%esi
 2a182d3:	mov    0x190(%rsp),%rcx
 2a182db:	mov    0x28(%rcx),%rax
 2a182df:	mov    0x13c(%rax),%edx
 2a182e5:	mov    $0x20,%ecx
 2a182ea:	mov    $0x10,%r8d
 2a182f0:	mov    0x190(%rsp),%rdi
 2a182f8:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 2a182fd:	mov    %rax,%r15
 2a18300:	mov    %eax,%eax
 2a18302:	mov    0x2e0(%rsp),%r14
 2a1830a:	add    0x20(%r14),%rax
 2a1830e:	jmp    2a0c18c <wasm[0]::function[1015]::helper::object_read+0xe02c>
 2a18313:	mov    $0xb0000072,%esi
 2a18318:	mov    0x190(%rsp),%rcx
 2a18320:	mov    0x28(%rcx),%rax
 2a18324:	mov    0x13c(%rax),%edx
 2a1832a:	mov    $0x20,%ecx
 2a1832f:	mov    $0x10,%r8d
 2a18335:	mov    0x190(%rsp),%rdi
 2a1833d:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 2a18342:	mov    %rax,%r15
 2a18345:	mov    %eax,%eax
 2a18347:	mov    0x2e0(%rsp),%r14
 2a1834f:	add    0x20(%r14),%rax
 2a18353:	jmp    2a0c269 <wasm[0]::function[1015]::helper::object_read+0xe109>
 2a18358:	mov    $0xb0000072,%esi
 2a1835d:	mov    0x190(%rsp),%rcx
 2a18365:	mov    0x28(%rcx),%rdi
 2a18369:	mov    0x13c(%rdi),%edx
 2a1836f:	mov    $0x20,%ecx
 2a18374:	mov    $0x10,%r8d
 2a1837a:	mov    0x190(%rsp),%rdi
 2a18382:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 2a18387:	mov    %rax,%r15
 2a1838a:	mov    %eax,%eax
 2a1838c:	mov    0x2e0(%rsp),%r14
 2a18394:	add    0x20(%r14),%rax
 2a18398:	jmp    2a0c580 <wasm[0]::function[1015]::helper::object_read+0xe420>
 2a1839d:	mov    $0xb0000072,%esi
 2a183a2:	mov    0x190(%rsp),%rcx
 2a183aa:	mov    0x28(%rcx),%rax
 2a183ae:	mov    0x13c(%rax),%edx
 2a183b4:	mov    $0x20,%ecx
 2a183b9:	mov    $0x10,%r8d
 2a183bf:	mov    0x190(%rsp),%rdi
 2a183c7:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 2a183cc:	mov    %rax,%r15
 2a183cf:	mov    %eax,%eax
 2a183d1:	mov    0x2e0(%rsp),%r14
 2a183d9:	add    0x20(%r14),%rax
 2a183dd:	jmp    2a0c658 <wasm[0]::function[1015]::helper::object_read+0xe4f8>
 2a183e2:	mov    $0xb0000042,%esi
 2a183e7:	mov    0x190(%rsp),%rax
 2a183ef:	mov    0x28(%rax),%rax
 2a183f3:	mov    0x120(%rax),%edx
 2a183f9:	mov    $0x20,%ecx
 2a183fe:	mov    $0x10,%r8d
 2a18404:	mov    0x190(%rsp),%rdi
 2a1840c:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 2a18411:	mov    %eax,%esi
 2a18413:	mov    0x2e0(%rsp),%r14
 2a1841b:	add    0x20(%r14),%rsi
 2a1841f:	mov    0x268(%rsp),%rcx
 2a18427:	jmp    2a0d3b0 <wasm[0]::function[1015]::helper::object_read+0xf250>
 2a1842c:	mov    $0xb0000042,%esi
 2a18431:	mov    0x190(%rsp),%rdi
 2a18439:	mov    0x28(%rdi),%rax
 2a1843d:	mov    0x120(%rax),%edx
 2a18443:	mov    $0x20,%ecx
 2a18448:	mov    $0x10,%r8d
 2a1844e:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 2a18453:	mov    %eax,%r9d
 2a18456:	mov    0x2e0(%rsp),%r14
 2a1845e:	add    0x20(%r14),%r9
 2a18462:	jmp    2a0d438 <wasm[0]::function[1015]::helper::object_read+0xf2d8>
 2a18467:	mov    $0xb0000042,%esi
 2a1846c:	mov    0x190(%rsp),%rax
 2a18474:	mov    0x28(%rax),%rax
 2a18478:	mov    0x120(%rax),%edx
 2a1847e:	mov    $0x20,%ecx
 2a18483:	mov    $0x10,%r8d
 2a18489:	mov    0x190(%rsp),%rdi
 2a18491:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 2a18496:	mov    %eax,%ecx
 2a18498:	mov    0x2e0(%rsp),%r14
 2a184a0:	add    0x20(%r14),%rcx
 2a184a4:	jmp    2a0d4c9 <wasm[0]::function[1015]::helper::object_read+0xf369>
 2a184a9:	mov    $0xa800000e,%esi
 2a184ae:	mov    0x190(%rsp),%rax
 2a184b6:	mov    0x28(%rax),%rax
 2a184ba:	mov    0x1b4(%rax),%edx
 2a184c0:	mov    $0x20,%ecx
 2a184c5:	mov    $0x10,%r8d
 2a184cb:	mov    0x190(%rsp),%rdi
 2a184d3:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 2a184d8:	mov    %eax,%edx
 2a184da:	mov    0x2e0(%rsp),%r14
 2a184e2:	add    0x20(%r14),%rdx
 2a184e6:	jmp    2a0d57b <wasm[0]::function[1015]::helper::object_read+0xf41b>
 2a184eb:	mov    0x2e0(%rsp),%r14
 2a184f3:	mov    0x8(%r14),%rcx
 2a184f7:	mov    %rcx,0x228(%rsp)
 2a184ff:	cmp    %rcx,%rax
 2a18502:	jb     2a0d8c9 <wasm[0]::function[1015]::helper::object_read+0xf769>
 2a18508:	mov    0x190(%rsp),%rdi
 2a18510:	call   3039b69 <wasmtime_builtin_new_epoch>
 2a18515:	mov    %rax,0x228(%rsp)
 2a1851d:	jmp    2a0d8c9 <wasm[0]::function[1015]::helper::object_read+0xf769>
 2a18522:	mov    $0xb0000002,%esi
 2a18527:	mov    0x190(%rsp),%rax
 2a1852f:	mov    0x28(%rax),%rax
 2a18533:	mov    0x1d0(%rax),%edx
 2a18539:	mov    $0x40,%ecx
 2a1853e:	mov    $0x10,%r8d
 2a18544:	mov    0x190(%rsp),%rdi
 2a1854c:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 2a18551:	mov    %eax,%r12d
 2a18554:	mov    0x2e0(%rsp),%rcx
 2a1855c:	add    0x20(%rcx),%r12
 2a18560:	jmp    2a0dc24 <wasm[0]::function[1015]::helper::object_read+0xfac4>
 2a18565:	mov    $0xb0001ffa,%esi
 2a1856a:	mov    0x190(%rsp),%rax
 2a18572:	mov    0x28(%rax),%rax
 2a18576:	mov    0x1e0(%rax),%edx
 2a1857c:	mov    $0x40,%ecx
 2a18581:	mov    $0x10,%r8d
 2a18587:	mov    0x190(%rsp),%rdi
 2a1858f:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 2a18594:	mov    %eax,%r12d
 2a18597:	mov    0x2e0(%rsp),%r14
 2a1859f:	add    0x20(%r14),%r12
 2a185a3:	jmp    2a0dd5c <wasm[0]::function[1015]::helper::object_read+0xfbfc>
 2a185a8:	mov    $0xb00300fa,%esi
 2a185ad:	mov    0x190(%rsp),%rax
 2a185b5:	mov    0x28(%rax),%rax
 2a185b9:	mov    0x1d4(%rax),%edx
 2a185bf:	mov    $0x50,%ecx
 2a185c4:	mov    $0x10,%r8d
 2a185ca:	mov    0x190(%rsp),%rdi
 2a185d2:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 2a185d7:	mov    %eax,%ecx
 2a185d9:	mov    0x2e0(%rsp),%r14
 2a185e1:	add    0x20(%r14),%rcx
 2a185e5:	jmp    2a0dec6 <wasm[0]::function[1015]::helper::object_read+0xfd66>
 2a185ea:	mov    $0xb0000042,%esi
 2a185ef:	mov    0x190(%rsp),%rax
 2a185f7:	mov    0x28(%rax),%rax
 2a185fb:	mov    0x120(%rax),%edx
 2a18601:	mov    $0x20,%ecx
 2a18606:	mov    $0x10,%r8d
 2a1860c:	mov    0x190(%rsp),%rdi
 2a18614:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 2a18619:	mov    %eax,%esi
 2a1861b:	mov    0x2e0(%rsp),%r14
 2a18623:	add    0x20(%r14),%rsi
 2a18627:	jmp    2a0dff4 <wasm[0]::function[1015]::helper::object_read+0xfe94>
 2a1862c:	mov    $0xb0000042,%esi
 2a18631:	mov    0x190(%rsp),%rax
 2a18639:	mov    0x28(%rax),%rax
 2a1863d:	mov    0x120(%rax),%edx
 2a18643:	mov    $0x20,%ecx
 2a18648:	mov    $0x10,%r8d
 2a1864e:	mov    0x190(%rsp),%rdi
 2a18656:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 2a1865b:	mov    %eax,%ecx
 2a1865d:	mov    0x2e0(%rsp),%r14
 2a18665:	add    0x20(%r14),%rcx
 2a18669:	jmp    2a0e086 <wasm[0]::function[1015]::helper::object_read+0xff26>
 2a1866e:	mov    $0xa800000e,%esi
 2a18673:	mov    0x190(%rsp),%rax
 2a1867b:	mov    0x28(%rax),%rax
 2a1867f:	mov    0x1b4(%rax),%edx
 2a18685:	mov    $0x10,%r8d
 2a1868b:	mov    %r13,%rcx
 2a1868e:	mov    0x190(%rsp),%rdi
 2a18696:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 2a1869b:	mov    %eax,%esi
 2a1869d:	mov    0x2e0(%rsp),%r14
 2a186a5:	add    0x20(%r14),%rsi
 2a186a9:	jmp    2a0e12f <wasm[0]::function[1015]::helper::object_read+0xffcf>
 2a186ae:	mov    0x2e0(%rsp),%r14
 2a186b6:	mov    0x8(%r14),%rax
 2a186ba:	mov    %rax,0x228(%rsp)
 2a186c2:	cmp    %rax,%rcx
 2a186c5:	jb     2a0e85f <wasm[0]::function[1015]::helper::object_read+0x106ff>
 2a186cb:	mov    0x190(%rsp),%rdi
 2a186d3:	call   3039b69 <wasmtime_builtin_new_epoch>
 2a186d8:	mov    %rax,0x228(%rsp)
 2a186e0:	jmp    2a0e85f <wasm[0]::function[1015]::helper::object_read+0x106ff>
 2a186e5:	mov    0x2e0(%rsp),%r14
 2a186ed:	mov    0x8(%r14),%rax
 2a186f1:	mov    %rax,0x228(%rsp)
 2a186f9:	cmp    %rax,%rcx
 2a186fc:	jb     2a0f3fc <wasm[0]::function[1015]::helper::object_read+0x1129c>
 2a18702:	mov    0x190(%rsp),%rdi
 2a1870a:	call   3039b69 <wasmtime_builtin_new_epoch>
 2a1870f:	mov    %rax,0x228(%rsp)
 2a18717:	jmp    2a0f3fc <wasm[0]::function[1015]::helper::object_read+0x1129c>
 2a1871c:	mov    0x2e0(%rsp),%r14
 2a18724:	mov    0x8(%r14),%rax
 2a18728:	mov    %rax,0x228(%rsp)
 2a18730:	cmp    %rax,%rdx
 2a18733:	jb     2a1005c <wasm[0]::function[1015]::helper::object_read+0x11efc>
 2a18739:	mov    0x190(%rsp),%rdi
 2a18741:	call   3039b69 <wasmtime_builtin_new_epoch>
 2a18746:	mov    %rax,0x228(%rsp)
 2a1874e:	jmp    2a1005c <wasm[0]::function[1015]::helper::object_read+0x11efc>
 2a18753:	mov    0x2e0(%rsp),%r14
 2a1875b:	mov    0x8(%r14),%rax
 2a1875f:	mov    %rax,0x228(%rsp)
 2a18767:	cmp    %rax,%rcx
 2a1876a:	jb     2a10ce2 <wasm[0]::function[1015]::helper::object_read+0x12b82>
 2a18770:	mov    0x190(%rsp),%rdi
 2a18778:	call   3039b69 <wasmtime_builtin_new_epoch>
 2a1877d:	mov    %rax,0x228(%rsp)
 2a18785:	jmp    2a10ce2 <wasm[0]::function[1015]::helper::object_read+0x12b82>
 2a1878a:	mov    0x2e0(%rsp),%r14
 2a18792:	mov    0x8(%r14),%rax
 2a18796:	mov    %rax,0x228(%rsp)
 2a1879e:	cmp    %rax,%rcx
 2a187a1:	jb     2a119ad <wasm[0]::function[1015]::helper::object_read+0x1384d>
 2a187a7:	mov    0x190(%rsp),%rdi
 2a187af:	call   3039b69 <wasmtime_builtin_new_epoch>
 2a187b4:	mov    %rax,0x228(%rsp)
 2a187bc:	jmp    2a119ad <wasm[0]::function[1015]::helper::object_read+0x1384d>
 2a187c1:	mov    0x2e0(%rsp),%r14
 2a187c9:	mov    0x8(%r14),%rdx
 2a187cd:	cmp    %rdx,%rcx
 2a187d0:	jb     2a126a6 <wasm[0]::function[1015]::helper::object_read+0x14546>
 2a187d6:	mov    0x190(%rsp),%rdi
 2a187de:	call   3039b69 <wasmtime_builtin_new_epoch>
 2a187e3:	mov    %rax,0x228(%rsp)
 2a187eb:	jmp    2a126ae <wasm[0]::function[1015]::helper::object_read+0x1454e>
 2a187f0:	mov    $0xb0000042,%esi
 2a187f5:	mov    0x190(%rsp),%rax
 2a187fd:	mov    0x28(%rax),%rdi
 2a18801:	mov    0x120(%rdi),%edx
 2a18807:	mov    $0x20,%ecx
 2a1880c:	mov    $0x10,%r8d
 2a18812:	mov    0x190(%rsp),%rdi
 2a1881a:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 2a1881f:	mov    %eax,%ecx
 2a18821:	mov    0x2e0(%rsp),%r14
 2a18829:	add    0x20(%r14),%rcx
 2a1882d:	jmp    2a1374a <wasm[0]::function[1015]::helper::object_read+0x155ea>
 2a18832:	mov    $0xb0000042,%esi
 2a18837:	mov    0x190(%rsp),%rax
 2a1883f:	mov    0x28(%rax),%rax
 2a18843:	mov    0x120(%rax),%edx
 2a18849:	mov    $0x20,%ecx
 2a1884e:	mov    $0x10,%r8d
 2a18854:	mov    0x190(%rsp),%rdi
 2a1885c:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 2a18861:	mov    %eax,%ecx
 2a18863:	mov    0x2e0(%rsp),%r14
 2a1886b:	add    0x20(%r14),%rcx
 2a1886f:	jmp    2a137dc <wasm[0]::function[1015]::helper::object_read+0x1567c>
 2a18874:	mov    $0xb0000042,%esi
 2a18879:	mov    0x190(%rsp),%rax
 2a18881:	mov    0x28(%rax),%rax
 2a18885:	mov    0x120(%rax),%edx
 2a1888b:	mov    $0x20,%ecx
 2a18890:	mov    $0x10,%r8d
 2a18896:	mov    0x190(%rsp),%rdi
 2a1889e:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 2a188a3:	mov    %eax,%ecx
 2a188a5:	mov    0x2e0(%rsp),%r14
 2a188ad:	add    0x20(%r14),%rcx
 2a188b1:	jmp    2a1386e <wasm[0]::function[1015]::helper::object_read+0x1570e>
 2a188b6:	mov    $0xb0000072,%esi
 2a188bb:	mov    0x190(%rsp),%rax
 2a188c3:	mov    0x28(%rax),%rax
 2a188c7:	mov    0x13c(%rax),%edx
 2a188cd:	mov    $0x20,%ecx
 2a188d2:	mov    $0x10,%r8d
 2a188d8:	mov    0x190(%rsp),%rdi
 2a188e0:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 2a188e5:	mov    %rax,%r15
 2a188e8:	mov    %eax,%eax
 2a188ea:	mov    0x2e0(%rsp),%r14
 2a188f2:	add    0x20(%r14),%rax
 2a188f6:	jmp    2a13948 <wasm[0]::function[1015]::helper::object_read+0x157e8>
 2a188fb:	mov    $0xb0000072,%esi
 2a18900:	mov    0x190(%rsp),%rax
 2a18908:	mov    0x28(%rax),%r9
 2a1890c:	mov    0x13c(%r9),%edx
 2a18913:	mov    $0x20,%ecx
 2a18918:	mov    $0x10,%r8d
 2a1891e:	mov    0x190(%rsp),%rdi
 2a18926:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 2a1892b:	mov    %rax,%r15
 2a1892e:	mov    %eax,%eax
 2a18930:	mov    0x2e0(%rsp),%r14
 2a18938:	add    0x20(%r14),%rax
 2a1893c:	jmp    2a13a28 <wasm[0]::function[1015]::helper::object_read+0x158c8>
 2a18941:	mov    0x2e0(%rsp),%r14
 2a18949:	mov    0x8(%r14),%rcx
 2a1894d:	cmp    %rcx,%rax
 2a18950:	jb     2a13db6 <wasm[0]::function[1015]::helper::object_read+0x15c56>
 2a18956:	mov    0x190(%rsp),%rdi
 2a1895e:	call   3039b69 <wasmtime_builtin_new_epoch>
 2a18963:	mov    %rax,0x228(%rsp)
 2a1896b:	jmp    2a13dbe <wasm[0]::function[1015]::helper::object_read+0x15c5e>
 2a18970:	mov    0x2e0(%rsp),%r14
 2a18978:	mov    0x8(%r14),%rdx
 2a1897c:	cmp    %rdx,%rcx
 2a1897f:	jb     2a142d4 <wasm[0]::function[1015]::helper::object_read+0x16174>
 2a18985:	mov    0x190(%rsp),%rdi
 2a1898d:	call   3039b69 <wasmtime_builtin_new_epoch>
 2a18992:	mov    %rax,0x228(%rsp)
 2a1899a:	jmp    2a142dc <wasm[0]::function[1015]::helper::object_read+0x1617c>
 2a1899f:	mov    $0xb0000042,%esi
 2a189a4:	mov    0x190(%rsp),%rax
 2a189ac:	mov    0x28(%rax),%rax
 2a189b0:	mov    0x120(%rax),%edx
 2a189b6:	mov    $0x20,%ecx
 2a189bb:	mov    $0x10,%r8d
 2a189c1:	mov    0x190(%rsp),%rdi
 2a189c9:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 2a189ce:	mov    %eax,%ecx
 2a189d0:	mov    0x2e0(%rsp),%r14
 2a189d8:	add    0x20(%r14),%rcx
 2a189dc:	jmp    2a146cb <wasm[0]::function[1015]::helper::object_read+0x1656b>
 2a189e1:	mov    $0xb0000072,%esi
 2a189e6:	mov    0x190(%rsp),%rax
 2a189ee:	mov    0x28(%rax),%rdi
 2a189f2:	mov    0x13c(%rdi),%edx
 2a189f8:	mov    $0x20,%ecx
 2a189fd:	mov    $0x10,%r8d
 2a18a03:	mov    0x190(%rsp),%rdi
 2a18a0b:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 2a18a10:	mov    %eax,%ecx
 2a18a12:	mov    0x2e0(%rsp),%r14
 2a18a1a:	add    0x20(%r14),%rcx
 2a18a1e:	jmp    2a147a5 <wasm[0]::function[1015]::helper::object_read+0x16645>
 2a18a23:	mov    $0xa800000e,%esi
 2a18a28:	mov    0x190(%rsp),%rax
 2a18a30:	mov    0x28(%rax),%rax
 2a18a34:	mov    0x194(%rax),%edx
 2a18a3a:	mov    $0x10,%r8d
 2a18a40:	mov    0x190(%rsp),%rdi
 2a18a48:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 2a18a4d:	mov    %eax,%ecx
 2a18a4f:	mov    0x2e0(%rsp),%r14
 2a18a57:	add    0x20(%r14),%rcx
 2a18a5b:	jmp    2a14d9f <wasm[0]::function[1015]::helper::object_read+0x16c3f>
 2a18a60:	mov    0x2e0(%rsp),%r14
 2a18a68:	mov    0x8(%r14),%rsi
 2a18a6c:	cmp    %rsi,%rcx
 2a18a6f:	jb     2a14e8a <wasm[0]::function[1015]::helper::object_read+0x16d2a>
 2a18a75:	mov    0x190(%rsp),%rdi
 2a18a7d:	call   3039b69 <wasmtime_builtin_new_epoch>
 2a18a82:	mov    %rax,0x228(%rsp)
 2a18a8a:	jmp    2a14e92 <wasm[0]::function[1015]::helper::object_read+0x16d32>
 2a18a8f:	mov    0x2e0(%rsp),%r14
 2a18a97:	mov    0x8(%r14),%rcx
 2a18a9b:	cmp    %rcx,%rax
 2a18a9e:	jb     2a14f6e <wasm[0]::function[1015]::helper::object_read+0x16e0e>
 2a18aa4:	mov    0x190(%rsp),%rdi
 2a18aac:	call   3039b69 <wasmtime_builtin_new_epoch>
 2a18ab1:	mov    0x1e8(%rsp),%rcx
 2a18ab9:	mov    %rax,0x228(%rsp)
 2a18ac1:	jmp    2a14f7e <wasm[0]::function[1015]::helper::object_read+0x16e1e>
 2a18ac6:	mov    0x1d8(%rsp),%rcx
 2a18ace:	mov    %r12,%rdx
 2a18ad1:	mov    0x1e0(%rsp),%rsi
 2a18ad9:	mov    0x190(%rsp),%rdi
 2a18ae1:	mov    %rbx,%r8
 2a18ae4:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 2a18ae9:	mov    %eax,%ecx
 2a18aeb:	mov    0x2e0(%rsp),%rdx
 2a18af3:	add    0x20(%rdx),%rcx
 2a18af7:	jmp    2a1519e <wasm[0]::function[1015]::helper::object_read+0x1703e>
 2a18afc:	mov    0x1d8(%rsp),%rcx
 2a18b04:	mov    %r15,%rdx
 2a18b07:	mov    0x1d0(%rsp),%rsi
 2a18b0f:	mov    0x190(%rsp),%rdi
 2a18b17:	mov    %rbx,%r8
 2a18b1a:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 2a18b1f:	mov    %eax,%esi
 2a18b21:	mov    0x2e0(%rsp),%r14
 2a18b29:	add    0x20(%r14),%rsi
 2a18b2d:	jmp    2a15239 <wasm[0]::function[1015]::helper::object_read+0x170d9>
 2a18b32:	mov    $0xa800000e,%esi
 2a18b37:	mov    0x190(%rsp),%rax
 2a18b3f:	mov    0x28(%rax),%rax
 2a18b43:	mov    0x194(%rax),%edx
 2a18b49:	mov    $0x10,%r8d
 2a18b4f:	mov    0x190(%rsp),%rdi
 2a18b57:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 2a18b5c:	mov    %eax,%ecx
 2a18b5e:	mov    0x2e0(%rsp),%rdx
 2a18b66:	add    0x20(%rdx),%rcx
 2a18b6a:	jmp    2a154c1 <wasm[0]::function[1015]::helper::object_read+0x17361>
 2a18b6f:	mov    0x2e0(%rsp),%rcx
 2a18b77:	mov    0x8(%rcx),%rcx
 2a18b7b:	cmp    %rcx,%rax
 2a18b7e:	jb     2a1559c <wasm[0]::function[1015]::helper::object_read+0x1743c>
 2a18b84:	mov    0x190(%rsp),%rdi
 2a18b8c:	call   3039b69 <wasmtime_builtin_new_epoch>
 2a18b91:	mov    %rax,0x228(%rsp)
 2a18b99:	jmp    2a155a4 <wasm[0]::function[1015]::helper::object_read+0x17444>
 2a18b9e:	mov    0x2e0(%rsp),%r14
 2a18ba6:	mov    0x8(%r14),%r10
 2a18baa:	cmp    %r10,%rdi
 2a18bad:	jb     2a1566b <wasm[0]::function[1015]::helper::object_read+0x1750b>
 2a18bb3:	mov    0x190(%rsp),%rdi
 2a18bbb:	call   3039b69 <wasmtime_builtin_new_epoch>
 2a18bc0:	mov    %rax,0x228(%rsp)
 2a18bc8:	jmp    2a15673 <wasm[0]::function[1015]::helper::object_read+0x17513>
 2a18bcd:	mov    0x1c8(%rsp),%rcx
 2a18bd5:	mov    %r13,%rdx
 2a18bd8:	mov    0x1d0(%rsp),%rsi
 2a18be0:	mov    0x190(%rsp),%rdi
 2a18be8:	mov    0x1a0(%rsp),%r8
 2a18bf0:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 2a18bf5:	mov    %eax,%ecx
 2a18bf7:	mov    0x2e0(%rsp),%r14
 2a18bff:	add    0x20(%r14),%rcx
 2a18c03:	jmp    2a1578a <wasm[0]::function[1015]::helper::object_read+0x1762a>
 2a18c08:	mov    0x2e0(%rsp),%r14
 2a18c10:	mov    0x8(%r14),%rcx
 2a18c14:	cmp    %rcx,%rax
 2a18c17:	jb     2a15a60 <wasm[0]::function[1015]::helper::object_read+0x17900>
 2a18c1d:	mov    0x190(%rsp),%rdi
 2a18c25:	call   3039b69 <wasmtime_builtin_new_epoch>
 2a18c2a:	mov    %rax,0x228(%rsp)
 2a18c32:	jmp    2a15a68 <wasm[0]::function[1015]::helper::object_read+0x17908>
 2a18c37:	mov    $0xb0000072,%esi
 2a18c3c:	mov    0x190(%rsp),%rax
 2a18c44:	mov    0x28(%rax),%rax
 2a18c48:	mov    0x13c(%rax),%edx
 2a18c4e:	mov    $0x20,%ecx
 2a18c53:	mov    $0x10,%r8d
 2a18c59:	mov    0x190(%rsp),%rdi
 2a18c61:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 2a18c66:	mov    %rax,%r15
 2a18c69:	mov    %eax,%eax
 2a18c6b:	mov    0x2e0(%rsp),%r14
 2a18c73:	add    0x20(%r14),%rax
 2a18c77:	jmp    2a15e36 <wasm[0]::function[1015]::helper::object_read+0x17cd6>
 2a18c7c:	mov    $0xb0000072,%esi
 2a18c81:	mov    0x190(%rsp),%r8
 2a18c89:	mov    0x28(%r8),%rax
 2a18c8d:	mov    0x13c(%rax),%edx
 2a18c93:	mov    $0x20,%ecx
 2a18c98:	mov    $0x10,%r8d
 2a18c9e:	mov    0x190(%rsp),%rdi
 2a18ca6:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 2a18cab:	mov    %rax,%r15
 2a18cae:	mov    %eax,%eax
 2a18cb0:	mov    0x2e0(%rsp),%r14
 2a18cb8:	add    0x20(%r14),%rax
 2a18cbc:	jmp    2a15f22 <wasm[0]::function[1015]::helper::object_read+0x17dc2>
 2a18cc1:	mov    $0xb0000072,%esi
 2a18cc6:	mov    0x190(%rsp),%rdi
 2a18cce:	mov    0x28(%rdi),%rax
 2a18cd2:	mov    0x13c(%rax),%edx
 2a18cd8:	mov    $0x20,%ecx
 2a18cdd:	mov    $0x10,%r8d
 2a18ce3:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 2a18ce8:	mov    %rax,%r15
 2a18ceb:	mov    %eax,%eax
 2a18ced:	mov    0x2e0(%rsp),%r14
 2a18cf5:	add    0x20(%r14),%rax
 2a18cf9:	jmp    2a16203 <wasm[0]::function[1015]::helper::object_read+0x180a3>
 2a18cfe:	mov    $0xb0000072,%esi
 2a18d03:	mov    0x190(%rsp),%rax
 2a18d0b:	mov    0x28(%rax),%rax
 2a18d0f:	mov    0x13c(%rax),%edx
 2a18d15:	mov    $0x20,%ecx
 2a18d1a:	mov    $0x10,%r8d
 2a18d20:	mov    0x190(%rsp),%rdi
 2a18d28:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 2a18d2d:	mov    %rax,%r15
 2a18d30:	mov    %eax,%eax
 2a18d32:	mov    0x2e0(%rsp),%r14
 2a18d3a:	add    0x20(%r14),%rax
 2a18d3e:	jmp    2a162f2 <wasm[0]::function[1015]::helper::object_read+0x18192>
 2a18d43:	mov    0x2e0(%rsp),%r14
 2a18d4b:	mov    0x8(%r14),%rdx
 2a18d4f:	cmp    %rdx,%rcx
 2a18d52:	jb     2a168cb <wasm[0]::function[1015]::helper::object_read+0x1876b>
 2a18d58:	mov    0x190(%rsp),%rdi
 2a18d60:	call   3039b69 <wasmtime_builtin_new_epoch>
 2a18d65:	mov    %rax,0x228(%rsp)
 2a18d6d:	jmp    2a168d3 <wasm[0]::function[1015]::helper::object_read+0x18773>
 2a18d72:	mov    0x2e0(%rsp),%r14
 2a18d7a:	mov    0x8(%r14),%rcx
 2a18d7e:	cmp    %rcx,%rax
 2a18d81:	jb     2a16bd8 <wasm[0]::function[1015]::helper::object_read+0x18a78>
 2a18d87:	mov    0x190(%rsp),%rdi
 2a18d8f:	call   3039b69 <wasmtime_builtin_new_epoch>
 2a18d94:	mov    %rax,0x228(%rsp)
 2a18d9c:	jmp    2a16be0 <wasm[0]::function[1015]::helper::object_read+0x18a80>
 2a18da1:	mov    0x2e0(%rsp),%r14
 2a18da9:	mov    0x8(%r14),%rcx
 2a18dad:	cmp    %rcx,%rax
 2a18db0:	jb     2a16f0e <wasm[0]::function[1015]::helper::object_read+0x18dae>
 2a18db6:	mov    0x190(%rsp),%rdi
 2a18dbe:	call   3039b69 <wasmtime_builtin_new_epoch>
 2a18dc3:	mov    %rax,0x228(%rsp)
 2a18dcb:	jmp    2a16f16 <wasm[0]::function[1015]::helper::object_read+0x18db6>
 2a18dd0:	mov    0x2e0(%rsp),%r14
 2a18dd8:	mov    0x8(%r14),%rcx
 2a18ddc:	cmp    %rcx,%rax
 2a18ddf:	jb     2a171ad <wasm[0]::function[1015]::helper::object_read+0x1904d>
 2a18de5:	mov    0x190(%rsp),%rdi
 2a18ded:	call   3039b69 <wasmtime_builtin_new_epoch>
 2a18df2:	mov    %rax,0x228(%rsp)
 2a18dfa:	jmp    2a171b5 <wasm[0]::function[1015]::helper::object_read+0x19055>
 2a18dff:	mov    0x2e0(%rsp),%r14
 2a18e07:	mov    0x8(%r14),%rcx
 2a18e0b:	cmp    %rcx,%rax
 2a18e0e:	jb     2a174f2 <wasm[0]::function[1015]::helper::object_read+0x19392>
 2a18e14:	mov    0x190(%rsp),%rdi
 2a18e1c:	call   3039b69 <wasmtime_builtin_new_epoch>
 2a18e21:	mov    %rax,0x228(%rsp)
 2a18e29:	jmp    2a174fa <wasm[0]::function[1015]::helper::object_read+0x1939a>
 2a18e2e:	ud2
 2a18e30:	ud2
 2a18e32:	ud2
 2a18e34:	ud2
 2a18e36:	ud2
 2a18e38:	ud2
 2a18e3a:	ud2
 2a18e3c:	ud2
 2a18e3e:	ud2
 2a18e40:	ud2
 2a18e42:	ud2
 2a18e44:	ud2
 2a18e46:	ud2
 2a18e48:	ud2
 2a18e4a:	ud2
 2a18e4c:	ud2
 2a18e4e:	ud2
 2a18e50:	ud2
 2a18e52:	ud2
 2a18e54:	ud2
 2a18e56:	ud2
 2a18e58:	ud2
 2a18e5a:	ud2
 2a18e5c:	ud2
 2a18e5e:	ud2
 2a18e60:	ud2
 2a18e62:	ud2
 2a18e64:	ud2
 2a18e66:	ud2
 2a18e68:	ud2
 2a18e6a:	ud2
 2a18e6c:	ud2
 2a18e6e:	ud2
 2a18e70:	ud2
 2a18e72:	ud2
 2a18e74:	ud2
 2a18e76:	ud2
 2a18e78:	ud2
 2a18e7a:	ud2
 2a18e7c:	ud2
 2a18e7e:	ud2
 2a18e80:	ud2
 2a18e82:	ud2
 2a18e84:	ud2
 2a18e86:	ud2
 2a18e88:	ud2
 2a18e8a:	ud2
 2a18e8c:	ud2
 2a18e8e:	ud2
 2a18e90:	ud2
 2a18e92:	ud2
 2a18e94:	ud2
 2a18e96:	ud2
 2a18e98:	ud2
 2a18e9a:	ud2
 2a18e9c:	ud2
 2a18e9e:	ud2
 2a18ea0:	ud2
 2a18ea2:	ud2
 2a18ea4:	ud2
 2a18ea6:	ud2
 2a18ea8:	ud2
 2a18eaa:	ud2
 2a18eac:	ud2
 2a18eae:	ud2
 2a18eb0:	ud2
 2a18eb2:	ud2
 2a18eb4:	ud2
 2a18eb6:	ud2
 2a18eb8:	ud2
 2a18eba:	ud2
 2a18ebc:	ud2
 2a18ebe:	ud2
 2a18ec0:	ud2
 2a18ec2:	ud2
 2a18ec4:	ud2
 2a18ec6:	ud2
 2a18ec8:	ud2
 2a18eca:	ud2
 2a18ecc:	ud2
 2a18ece:	ud2
 2a18ed0:	ud2
 2a18ed2:	ud2
 2a18ed4:	ud2
 2a18ed6:	ud2
 2a18ed8:	ud2
 2a18eda:	ud2
 2a18edc:	ud2
 2a18ede:	ud2
 2a18ee0:	ud2
 2a18ee2:	ud2
 2a18ee4:	ud2
 2a18ee6:	ud2
 2a18ee8:	ud2
 2a18eea:	ud2
 2a18eec:	ud2
 2a18eee:	ud2
 2a18ef0:	ud2
 2a18ef2:	ud2
 2a18ef4:	ud2
 2a18ef6:	ud2
 2a18ef8:	ud2
 2a18efa:	ud2
 2a18efc:	ud2
 2a18efe:	ud2
 2a18f00:	ud2
 2a18f02:	ud2
 2a18f04:	ud2
 2a18f06:	ud2
 2a18f08:	ud2
 2a18f0a:	ud2
 2a18f0c:	ud2
 2a18f0e:	ud2
 2a18f10:	ud2
 2a18f12:	ud2
 2a18f14:	ud2
 2a18f16:	ud2
 2a18f18:	ud2
 2a18f1a:	ud2
 2a18f1c:	ud2
 2a18f1e:	ud2
 2a18f20:	ud2
 2a18f22:	ud2
 2a18f24:	ud2
 2a18f26:	ud2
 2a18f28:	ud2
 2a18f2a:	ud2
 2a18f2c:	ud2
 2a18f2e:	ud2
 2a18f30:	ud2
 2a18f32:	ud2
 2a18f34:	ud2
 2a18f36:	ud2
 2a18f38:	ud2
 2a18f3a:	ud2
 2a18f3c:	ud2
 2a18f3e:	ud2
 2a18f40:	ud2
 2a18f42:	ud2
 2a18f44:	ud2
 2a18f46:	ud2
 2a18f48:	ud2
 2a18f4a:	ud2
 2a18f4c:	ud2
 2a18f4e:	ud2
 2a18f50:	ud2
 2a18f52:	ud2
 2a18f54:	ud2
 2a18f56:	ud2
 2a18f58:	ud2
 2a18f5a:	ud2
 2a18f5c:	ud2
 2a18f5e:	ud2
 2a18f60:	ud2
 2a18f62:	ud2
 2a18f64:	ud2
 2a18f66:	ud2
 2a18f68:	ud2
 2a18f6a:	ud2
 2a18f6c:	ud2
 2a18f6e:	ud2
 2a18f70:	ud2
 2a18f72:	ud2
 2a18f74:	ud2
 2a18f76:	ud2
 2a18f78:	ud2
 2a18f7a:	ud2
 2a18f7c:	ud2
 2a18f7e:	ud2
 2a18f80:	ud2
 2a18f82:	ud2
 2a18f84:	ud2
 2a18f86:	ud2
 2a18f88:	ud2
 2a18f8a:	ud2
 2a18f8c:	ud2
 2a18f8e:	ud2
 2a18f90:	ud2
 2a18f92:	ud2
 2a18f94:	ud2
 2a18f96:	ud2
 2a18f98:	ud2
 2a18f9a:	ud2
 2a18f9c:	ud2
 2a18f9e:	ud2
 2a18fa0:	ud2
 2a18fa2:	ud2
 2a18fa4:	ud2
 2a18fa6:	ud2
 2a18fa8:	ud2
 2a18faa:	ud2
 2a18fac:	ud2
 2a18fae:	ud2
 2a18fb0:	ud2
 2a18fb2:	ud2
 2a18fb4:	ud2
 2a18fb6:	ud2
 2a18fb8:	ud2
 2a18fba:	ud2
 2a18fbc:	ud2
 2a18fbe:	ud2
 2a18fc0:	ud2
 2a18fc2:	ud2
 2a18fc4:	ud2
 2a18fc6:	ud2
 2a18fc8:	ud2
 2a18fca:	ud2
 2a18fcc:	ud2
 2a18fce:	ud2
 2a18fd0:	ud2
 2a18fd2:	ud2
 2a18fd4:	ud2
 2a18fd6:	ud2
 2a18fd8:	ud2
 2a18fda:	ud2
 2a18fdc:	ud2
 2a18fde:	ud2
 2a18fe0:	ud2
 2a18fe2:	ud2
 2a18fe4:	ud2
 2a18fe6:	ud2
 2a18fe8:	ud2
 2a18fea:	ud2
 2a18fec:	ud2
 2a18fee:	ud2
 2a18ff0:	ud2
 2a18ff2:	ud2
 2a18ff4:	ud2
 2a18ff6:	ud2
 2a18ff8:	ud2
 2a18ffa:	ud2
 2a18ffc:	ud2
 2a18ffe:	ud2
 2a19000:	ud2
 2a19002:	ud2
 2a19004:	ud2
 2a19006:	ud2
 2a19008:	ud2
 2a1900a:	ud2
 2a1900c:	ud2
 2a1900e:	ud2
 2a19010:	ud2
 2a19012:	ud2
 2a19014:	ud2
 2a19016:	ud2
 2a19018:	ud2
 2a1901a:	ud2
 2a1901c:	ud2
 2a1901e:	ud2
 2a19020:	ud2
 2a19022:	ud2
 2a19024:	ud2
 2a19026:	ud2
 2a19028:	ud2
 2a1902a:	ud2
 2a1902c:	ud2
 2a1902e:	ud2
 2a19030:	ud2
 2a19032:	ud2
 2a19034:	ud2
 2a19036:	ud2
 2a19038:	ud2
 2a1903a:	ud2
 2a1903c:	ud2
 2a1903e:	ud2
 2a19040:	ud2
 2a19042:	ud2
 2a19044:	ud2
 2a19046:	ud2
 2a19048:	ud2
 2a1904a:	ud2
 2a1904c:	ud2
 2a1904e:	ud2
 2a19050:	ud2
 2a19052:	ud2
 2a19054:	ud2
 2a19056:	ud2
 2a19058:	ud2
 2a1905a:	ud2
 2a1905c:	ud2
 2a1905e:	ud2
 2a19060:	ud2
 2a19062:	ud2
 2a19064:	ud2
 2a19066:	ud2
 2a19068:	ud2
 2a1906a:	ud2
 2a1906c:	ud2
 2a1906e:	ud2
 2a19070:	ud2
 2a19072:	ud2
 2a19074:	ud2
 2a19076:	ud2
 2a19078:	ud2
 2a1907a:	ud2
 2a1907c:	ud2
 2a1907e:	ud2
 2a19080:	ud2
 2a19082:	ud2
 2a19084:	ud2
 2a19086:	ud2
 2a19088:	ud2
 2a1908a:	ud2
 2a1908c:	ud2
 2a1908e:	ud2
 2a19090:	ud2
 2a19092:	ud2
 2a19094:	ud2
 2a19096:	ud2
 2a19098:	ud2
 2a1909a:	ud2
 2a1909c:	ud2
 2a1909e:	ud2
 2a190a0:	ud2
 2a190a2:	ud2
 2a190a4:	ud2
 2a190a6:	ud2
 2a190a8:	ud2
 2a190aa:	ud2
 2a190ac:	ud2
 2a190ae:	ud2
 2a190b0:	ud2
 2a190b2:	ud2
 2a190b4:	ud2
 2a190b6:	ud2
 2a190b8:	ud2
 2a190ba:	ud2
 2a190bc:	ud2
 2a190be:	ud2
 2a190c0:	ud2
 2a190c2:	ud2
 2a190c4:	ud2
 2a190c6:	ud2
 2a190c8:	ud2
 2a190ca:	ud2
 2a190cc:	ud2
 2a190ce:	ud2
 2a190d0:	ud2
 2a190d2:	ud2
 2a190d4:	ud2
 2a190d6:	ud2
 2a190d8:	ud2
 2a190da:	ud2
 2a190dc:	ud2
 2a190de:	ud2
 2a190e0:	ud2
 2a190e2:	ud2
 2a190e4:	ud2
 2a190e6:	ud2
 2a190e8:	ud2
 2a190ea:	ud2
 2a190ec:	ud2
 2a190ee:	ud2
 2a190f0:	ud2
 2a190f2:	ud2
 2a190f4:	ud2
 2a190f6:	ud2
 2a190f8:	ud2
 2a190fa:	ud2
 2a190fc:	ud2
 2a190fe:	ud2
 2a19100:	ud2
 2a19102:	ud2
 2a19104:	ud2
 2a19106:	ud2
 2a19108:	ud2
 2a1910a:	ud2
 2a1910c:	ud2
 2a1910e:	ud2
 2a19110:	ud2
 2a19112:	ud2
 2a19114:	ud2
 2a19116:	ud2
 2a19118:	ud2
 2a1911a:	ud2
 2a1911c:	ud2
 2a1911e:	ud2
 2a19120:	ud2
 2a19122:	ud2
 2a19124:	ud2
 2a19126:	ud2
 2a19128:	ud2
 2a1912a:	ud2
 2a1912c:	ud2
 2a1912e:	ud2
 2a19130:	ud2
 2a19132:	ud2
 2a19134:	ud2
 2a19136:	ud2
 2a19138:	ud2
 2a1913a:	ud2
 2a1913c:	ud2
 2a1913e:	ud2
 2a19140:	ud2
 2a19142:	ud2
 2a19144:	ud2
 2a19146:	ud2
 2a19148:	ud2
 2a1914a:	ud2
 2a1914c:	ud2
 2a1914e:	ud2
 2a19150:	ud2
 2a19152:	ud2
 2a19154:	ud2
 2a19156:	ud2
 2a19158:	ud2
 2a1915a:	ud2
 2a1915c:	ud2
 2a1915e:	ud2
 2a19160:	ud2
 2a19162:	ud2
 2a19164:	ud2
 2a19166:	ud2
 2a19168:	ud2
 2a1916a:	ud2
 2a1916c:	ud2
 2a1916e:	ud2
 2a19170:	ud2
 2a19172:	ud2
 2a19174:	ud2
 2a19176:	ud2
 2a19178:	ud2
 2a1917a:	ud2
 2a1917c:	ud2
 2a1917e:	ud2
 2a19180:	ud2
 2a19182:	ud2
 2a19184:	ud2
 2a19186:	ud2
 2a19188:	ud2
 2a1918a:	ud2
 2a1918c:	ud2
 2a1918e:	ud2
 2a19190:	ud2
 2a19192:	ud2
 2a19194:	ud2
 2a19196:	ud2
 2a19198:	ud2
 2a1919a:	ud2
 2a1919c:	ud2
 2a1919e:	ud2
 2a191a0:	ud2
 2a191a2:	ud2
 2a191a4:	ud2
 2a191a6:	ud2
 2a191a8:	ud2
 2a191aa:	ud2
 2a191ac:	ud2
 2a191ae:	ud2
 2a191b0:	ud2
 2a191b2:	ud2
 2a191b4:	ud2
 2a191b6:	ud2
 2a191b8:	ud2
 2a191ba:	ud2
 2a191bc:	ud2
 2a191be:	ud2
 2a191c0:	ud2
 2a191c2:	ud2
 2a191c4:	ud2
 2a191c6:	ud2
 2a191c8:	ud2
 2a191ca:	ud2
 2a191cc:	ud2
 2a191ce:	ud2
 2a191d0:	ud2
 2a191d2:	ud2
 2a191d4:	ud2
 2a191d6:	ud2
 2a191d8:	ud2
 2a191da:	ud2
 2a191dc:	ud2
 2a191de:	ud2
 2a191e0:	ud2
 2a191e2:	ud2
 2a191e4:	ud2
 2a191e6:	ud2
 2a191e8:	ud2
 2a191ea:	ud2
 2a191ec:	ud2
 2a191ee:	ud2
 2a191f0:	ud2
 2a191f2:	ud2
 2a191f4:	ud2
 2a191f6:	ud2
 2a191f8:	ud2
 2a191fa:	ud2
 2a191fc:	ud2
 2a191fe:	ud2
 2a19200:	ud2
 2a19202:	ud2
 2a19204:	ud2
 2a19206:	ud2
 2a19208:	ud2
 2a1920a:	ud2
 2a1920c:	ud2
 2a1920e:	ud2
 2a19210:	ud2
 2a19212:	ud2
 2a19214:	ud2
 2a19216:	ud2
 2a19218:	ud2
 2a1921a:	ud2
 2a1921c:	ud2
 2a1921e:	ud2
 2a19220:	ud2
 2a19222:	ud2
 2a19224:	ud2
 2a19226:	ud2
 2a19228:	ud2
 2a1922a:	ud2
 2a1922c:	ud2
 2a1922e:	ud2
 2a19230:	ud2
 2a19232:	ud2
 2a19234:	ud2
 2a19236:	ud2
 2a19238:	ud2
 2a1923a:	ud2
 2a1923c:	ud2
 2a1923e:	ud2
 2a19240:	ud2
 2a19242:	ud2
 2a19244:	ud2
 2a19246:	ud2
 2a19248:	ud2
 2a1924a:	ud2
 2a1924c:	ud2
 2a1924e:	ud2
 2a19250:	ud2
 2a19252:	ud2
 2a19254:	ud2
 2a19256:	ud2
 2a19258:	ud2
 2a1925a:	ud2
 2a1925c:	ud2
 2a1925e:	ud2
 2a19260:	ud2
 2a19262:	ud2
 2a19264:	ud2
 2a19266:	ud2
 2a19268:	ud2
 2a1926a:	ud2
 2a1926c:	ud2
 2a1926e:	ud2
 2a19270:	ud2
 2a19272:	ud2
 2a19274:	ud2
 2a19276:	ud2
 2a19278:	ud2
 2a1927a:	ud2
 2a1927c:	ud2
 2a1927e:	ud2
 2a19280:	ud2
 2a19282:	ud2
 2a19284:	ud2
 2a19286:	ud2
 2a19288:	ud2
 2a1928a:	ud2
 2a1928c:	ud2
 2a1928e:	ud2
 2a19290:	ud2
 2a19292:	ud2
 2a19294:	ud2
 2a19296:	ud2
 2a19298:	ud2
 2a1929a:	ud2
 2a1929c:	ud2
 2a1929e:	ud2
 2a192a0:	ud2
 2a192a2:	ud2
 2a192a4:	ud2
 2a192a6:	ud2
 2a192a8:	ud2
 2a192aa:	ud2
 2a192ac:	ud2
 2a192ae:	ud2
 2a192b0:	ud2
 2a192b2:	ud2
 2a192b4:	ud2
 2a192b6:	ud2
 2a192b8:	ud2
 2a192ba:	ud2
 2a192bc:	ud2
 2a192be:	ud2
 2a192c0:	ud2
 2a192c2:	ud2
 2a192c4:	ud2
 2a192c6:	ud2
 2a192c8:	ud2
 2a192ca:	ud2
 2a192cc:	ud2
 2a192ce:	ud2
 2a192d0:	ud2
 2a192d2:	ud2
 2a192d4:	ud2
 2a192d6:	ud2
 2a192d8:	ud2
 2a192da:	ud2
 2a192dc:	ud2
 2a192de:	ud2
 2a192e0:	ud2
 2a192e2:	ud2
 2a192e4:	ud2
 2a192e6:	ud2
 2a192e8:	ud2
 2a192ea:	ud2
 2a192ec:	ud2
 2a192ee:	ud2
 2a192f0:	ud2
 2a192f2:	ud2
 2a192f4:	ud2
 2a192f6:	ud2
 2a192f8:	ud2
 2a192fa:	ud2
 2a192fc:	ud2
 2a192fe:	ud2
 2a19300:	ud2
 2a19302:	ud2
 2a19304:	ud2
 2a19306:	ud2
 2a19308:	ud2
 2a1930a:	ud2
 2a1930c:	ud2
 2a1930e:	ud2
 2a19310:	ud2
 2a19312:	ud2
 2a19314:	ud2
 2a19316:	ud2
 2a19318:	ud2
 2a1931a:	ud2
 2a1931c:	ud2
 2a1931e:	ud2
 2a19320:	ud2
 2a19322:	ud2
 2a19324:	ud2
 2a19326:	ud2
 2a19328:	ud2
 2a1932a:	ud2
 2a1932c:	ud2
 2a1932e:	ud2
 2a19330:	ud2
 2a19332:	ud2
 2a19334:	ud2
 2a19336:	ud2
 2a19338:	ud2
 2a1933a:	ud2
 2a1933c:	ud2
 2a1933e:	ud2
 2a19340:	ud2
 2a19342:	ud2
 2a19344:	ud2
 2a19346:	ud2
 2a19348:	ud2
 2a1934a:	ud2
 2a1934c:	ud2
 2a1934e:	ud2
 2a19350:	ud2
 2a19352:	ud2
 2a19354:	ud2
 2a19356:	ud2
 2a19358:	ud2
 2a1935a:	ud2
 2a1935c:	ud2
 2a1935e:	ud2
 2a19360:	ud2
 2a19362:	ud2
 2a19364:	ud2
 2a19366:	ud2
 2a19368:	ud2
 2a1936a:	ud2
 2a1936c:	ud2
 2a1936e:	ud2
 2a19370:	ud2
 2a19372:	ud2
 2a19374:	ud2
 2a19376:	ud2
 2a19378:	ud2
 2a1937a:	ud2
 2a1937c:	ud2
 2a1937e:	ud2
 2a19380:	ud2
 2a19382:	ud2
 2a19384:	ud2
 2a19386:	ud2
 2a19388:	ud2
 2a1938a:	ud2
 2a1938c:	ud2
 2a1938e:	ud2
 2a19390:	ud2
 2a19392:	ud2
 2a19394:	ud2
 2a19396:	ud2
 2a19398:	ud2
 2a1939a:	ud2
 2a1939c:	ud2
 2a1939e:	ud2
 2a193a0:	ud2
 2a193a2:	ud2
 2a193a4:	ud2
 2a193a6:	ud2
 2a193a8:	ud2
 2a193aa:	ud2
 2a193ac:	ud2
 2a193ae:	ud2
 2a193b0:	ud2
 2a193b2:	ud2
 2a193b4:	ud2
 2a193b6:	ud2
 2a193b8:	ud2
 2a193ba:	ud2
 2a193bc:	ud2
 2a193be:	ud2
 2a193c0:	ud2
 2a193c2:	ud2
 2a193c4:	ud2
 2a193c6:	ud2
 2a193c8:	ud2
 2a193ca:	ud2
 2a193cc:	ud2
 2a193ce:	ud2
 2a193d0:	ud2
 2a193d2:	ud2
 2a193d4:	ud2
 2a193d6:	ud2
 2a193d8:	ud2
 2a193da:	ud2
 2a193dc:	ud2
 2a193de:	ud2
 2a193e0:	ud2
 2a193e2:	ud2
 2a193e4:	ud2
 2a193e6:	ud2
 2a193e8:	ud2
 2a193ea:	ud2
 2a193ec:	ud2
 2a193ee:	ud2
 2a193f0:	ud2
 2a193f2:	ud2
 2a193f4:	ud2
 2a193f6:	ud2
 2a193f8:	ud2
 2a193fa:	ud2
 2a193fc:	ud2
 2a193fe:	ud2
 2a19400:	ud2
 2a19402:	ud2
 2a19404:	ud2
 2a19406:	ud2
 2a19408:	ud2
 2a1940a:	ud2
 2a1940c:	ud2
 2a1940e:	ud2
 2a19410:	ud2
 2a19412:	ud2
 2a19414:	ud2
 2a19416:	ud2
 2a19418:	ud2
 2a1941a:	ud2
 2a1941c:	ud2
 2a1941e:	ud2
 2a19420:	ud2
 2a19422:	ud2
 2a19424:	ud2
 2a19426:	ud2
 2a19428:	ud2
 2a1942a:	ud2
 2a1942c:	ud2
 2a1942e:	ud2
 2a19430:	ud2
 2a19432:	ud2
 2a19434:	ud2
 2a19436:	ud2
 2a19438:	ud2
 2a1943a:	ud2
 2a1943c:	ud2
 2a1943e:	ud2
 2a19440:	ud2
 2a19442:	ud2
 2a19444:	ud2
 2a19446:	ud2
 2a19448:	ud2
 2a1944a:	ud2
 2a1944c:	ud2
 2a1944e:	ud2
 2a19450:	ud2
 2a19452:	ud2
 2a19454:	ud2
 2a19456:	ud2
 2a19458:	ud2
 2a1945a:	ud2
 2a1945c:	ud2
 2a1945e:	ud2
 2a19460:	ud2
 2a19462:	ud2
 2a19464:	ud2
 2a19466:	ud2
 2a19468:	ud2
 2a1946a:	ud2
 2a1946c:	ud2
 2a1946e:	ud2
 2a19470:	ud2
 2a19472:	ud2
 2a19474:	ud2
 2a19476:	ud2
 2a19478:	ud2
 2a1947a:	ud2
 2a1947c:	ud2
 2a1947e:	ud2
 2a19480:	ud2
 2a19482:	ud2
 2a19484:	ud2
 2a19486:	ud2
 2a19488:	ud2
 2a1948a:	ud2
 2a1948c:	ud2
 2a1948e:	ud2
 2a19490:	ud2
 2a19492:	ud2
 2a19494:	ud2
 2a19496:	ud2
 2a19498:	ud2
 2a1949a:	ud2
 2a1949c:	ud2
 2a1949e:	ud2
 2a194a0:	ud2
 2a194a2:	ud2
 2a194a4:	ud2
 2a194a6:	ud2
 2a194a8:	ud2
 2a194aa:	ud2
 2a194ac:	ud2
 2a194ae:	ud2
 2a194b0:	ud2
 2a194b2:	ud2
 2a194b4:	ud2
 2a194b6:	ud2
 2a194b8:	ud2
 2a194ba:	ud2
 2a194bc:	ud2
 2a194be:	ud2
 2a194c0:	ud2
 2a194c2:	ud2
 2a194c4:	ud2
 2a194c6:	ud2
 2a194c8:	ud2
 2a194ca:	ud2
 2a194cc:	ud2
 2a194ce:	ud2
 2a194d0:	ud2
 2a194d2:	ud2
 2a194d4:	ud2
 2a194d6:	ud2
 2a194d8:	ud2
 2a194da:	ud2
 2a194dc:	ud2
 2a194de:	ud2
 2a194e0:	ud2
 2a194e2:	ud2
 2a194e4:	ud2
 2a194e6:	ud2
 2a194e8:	ud2
 2a194ea:	ud2
 2a194ec:	ud2
 2a194ee:	ud2
 2a194f0:	ud2
 2a194f2:	ud2
 2a194f4:	ud2
 2a194f6:	ud2
 2a194f8:	ud2
 2a194fa:	ud2
 2a194fc:	ud2
 2a194fe:	ud2
 2a19500:	ud2
 2a19502:	ud2
 2a19504:	ud2
 2a19506:	ud2
 2a19508:	ud2
 2a1950a:	ud2
 2a1950c:	ud2
 2a1950e:	ud2
 2a19510:	ud2
 2a19512:	ud2
 2a19514:	ud2
 2a19516:	ud2
 2a19518:	ud2
 2a1951a:	ud2
 2a1951c:	ud2
 2a1951e:	ud2
 2a19520:	ud2
 2a19522:	ud2
 2a19524:	ud2
 2a19526:	ud2
 2a19528:	ud2
 2a1952a:	ud2
 2a1952c:	ud2
 2a1952e:	ud2
 2a19530:	ud2
 2a19532:	ud2
 2a19534:	ud2
 2a19536:	ud2
 2a19538:	ud2
 2a1953a:	ud2
 2a1953c:	ud2
 2a1953e:	ud2
 2a19540:	ud2
 2a19542:	ud2
 2a19544:	ud2
 2a19546:	ud2
 2a19548:	ud2
 2a1954a:	ud2
 2a1954c:	ud2
 2a1954e:	ud2
 2a19550:	ud2
 2a19552:	ud2
 2a19554:	ud2
 2a19556:	ud2
 2a19558:	ud2
 2a1955a:	ud2
 2a1955c:	ud2
 2a1955e:	ud2
 2a19560:	ud2
 2a19562:	ud2
 2a19564:	ud2
 2a19566:	ud2
 2a19568:	ud2
 2a1956a:	ud2
 2a1956c:	ud2
 2a1956e:	ud2
 2a19570:	ud2
 2a19572:	ud2
 2a19574:	ud2
 2a19576:	ud2
 2a19578:	ud2
 2a1957a:	ud2
 2a1957c:	ud2
 2a1957e:	ud2
 2a19580:	ud2
 2a19582:	ud2
 2a19584:	ud2
 2a19586:	ud2
 2a19588:	ud2
 2a1958a:	ud2
 2a1958c:	ud2
 2a1958e:	ud2
 2a19590:	ud2
 2a19592:	ud2
 2a19594:	ud2
 2a19596:	ud2
 2a19598:	ud2
 2a1959a:	ud2
 2a1959c:	ud2
 2a1959e:	ud2
 2a195a0:	ud2
 2a195a2:	ud2
 2a195a4:	ud2
 2a195a6:	ud2
 2a195a8:	ud2
 2a195aa:	ud2
 2a195ac:	ud2
 2a195ae:	ud2
 2a195b0:	ud2
 2a195b2:	ud2
 2a195b4:	ud2
 2a195b6:	ud2
 2a195b8:	ud2
 2a195ba:	ud2
 2a195bc:	ud2
 2a195be:	ud2
 2a195c0:	ud2
 2a195c2:	ud2
 2a195c4:	ud2
 2a195c6:	ud2
 2a195c8:	ud2
 2a195ca:	ud2
 2a195cc:	ud2
 2a195ce:	ud2
 2a195d0:	ud2
 2a195d2:	ud2
 2a195d4:	ud2
 2a195d6:	ud2
 2a195d8:	ud2
 2a195da:	ud2
 2a195dc:	ud2
 2a195de:	ud2
 2a195e0:	ud2
 2a195e2:	ud2
 2a195e4:	ud2
 2a195e6:	ud2
 2a195e8:	ud2
 2a195ea:	ud2
 2a195ec:	ud2
 2a195ee:	ud2
 2a195f0:	ud2
 2a195f2:	ud2
 2a195f4:	ud2
 2a195f6:	ud2
 2a195f8:	ud2
 2a195fa:	ud2
 2a195fc:	ud2
 2a195fe:	ud2
 2a19600:	ud2
 2a19602:	ud2
 2a19604:	ud2
 2a19606:	ud2
 2a19608:	ud2
 2a1960a:	ud2
 2a1960c:	ud2
 2a1960e:	ud2
 2a19610:	ud2
 2a19612:	ud2
 2a19614:	ud2
 2a19616:	ud2
 2a19618:	ud2
 2a1961a:	ud2
 2a1961c:	ud2
 2a1961e:	ud2
 2a19620:	ud2
 2a19622:	ud2
 2a19624:	ud2
 2a19626:	ud2
 2a19628:	ud2
 2a1962a:	ud2
 2a1962c:	ud2
 2a1962e:	ud2
 2a19630:	ud2
 2a19632:	ud2
 2a19634:	ud2
 2a19636:	ud2
 2a19638:	ud2
 2a1963a:	ud2
 2a1963c:	ud2
 2a1963e:	ud2
 2a19640:	ud2
 2a19642:	ud2
 2a19644:	ud2
 2a19646:	ud2
 2a19648:	ud2
 2a1964a:	ud2
 2a1964c:	ud2
 2a1964e:	ud2
 2a19650:	ud2
 2a19652:	ud2
 2a19654:	ud2
 2a19656:	ud2
 2a19658:	ud2
 2a1965a:	ud2
 2a1965c:	ud2
 2a1965e:	ud2
 2a19660:	ud2
 2a19662:	ud2
 2a19664:	ud2
 2a19666:	ud2
 2a19668:	ud2
 2a1966a:	ud2
 2a1966c:	ud2
 2a1966e:	ud2
 2a19670:	ud2
 2a19672:	ud2
 2a19674:	ud2
 2a19676:	ud2
 2a19678:	ud2
 2a1967a:	ud2
 2a1967c:	ud2
 2a1967e:	ud2
 2a19680:	ud2
 2a19682:	ud2
 2a19684:	ud2
 2a19686:	ud2
 2a19688:	ud2
 2a1968a:	ud2
 2a1968c:	ud2
 2a1968e:	ud2
 2a19690:	ud2
 2a19692:	ud2
 2a19694:	ud2
 2a19696:	ud2
 2a19698:	ud2
 2a1969a:	ud2
 2a1969c:	ud2
 2a1969e:	ud2
 2a196a0:	ud2
 2a196a2:	ud2
 2a196a4:	ud2
 2a196a6:	ud2
 2a196a8:	ud2
 2a196aa:	ud2
 2a196ac:	ud2
 2a196ae:	ud2
 2a196b0:	ud2
 2a196b2:	ud2
 2a196b4:	ud2
 2a196b6:	ud2
 2a196b8:	ud2
 2a196ba:	ud2
 2a196bc:	ud2
 2a196be:	ud2
 2a196c0:	ud2
 2a196c2:	ud2
 2a196c4:	ud2
 2a196c6:	ud2
 2a196c8:	ud2
 2a196ca:	ud2
 2a196cc:	ud2
 2a196ce:	ud2
 2a196d0:	ud2
 2a196d2:	ud2
 2a196d4:	ud2
 2a196d6:	ud2
 2a196d8:	ud2
 2a196da:	ud2
 2a196dc:	ud2
 2a196de:	ud2
 2a196e0:	ud2
 2a196e2:	ud2
 2a196e4:	ud2
 2a196e6:	ud2
 2a196e8:	ud2
 2a196ea:	ud2
 2a196ec:	ud2
 2a196ee:	ud2
 2a196f0:	ud2
 2a196f2:	ud2
 2a196f4:	ud2
 2a196f6:	ud2
 2a196f8:	ud2
 2a196fa:	ud2
 2a196fc:	ud2
 2a196fe:	ud2
 2a19700:	ud2
 2a19702:	ud2
 2a19704:	ud2
 2a19706:	ud2
 2a19708:	ud2
 2a1970a:	ud2
 2a1970c:	ud2
 2a1970e:	ud2
 2a19710:	ud2
 2a19712:	ud2
 2a19714:	ud2
 2a19716:	ud2
 2a19718:	ud2
 2a1971a:	ud2
 2a1971c:	ud2
 2a1971e:	ud2
 2a19720:	ud2
 2a19722:	ud2
 2a19724:	ud2
 2a19726:	ud2
 2a19728:	ud2
 2a1972a:	ud2
 2a1972c:	ud2
 2a1972e:	ud2
 2a19730:	ud2
 2a19732:	ud2
 2a19734:	ud2
 2a19736:	ud2
 2a19738:	ud2
 2a1973a:	ud2
 2a1973c:	ud2
 2a1973e:	ud2
 2a19740:	ud2
 2a19742:	ud2
 2a19744:	ud2
 2a19746:	ud2
 2a19748:	ud2
 2a1974a:	ud2
 2a1974c:	ud2
 2a1974e:	ud2
 2a19750:	ud2
 2a19752:	ud2
 2a19754:	ud2
 2a19756:	ud2
 2a19758:	ud2
 2a1975a:	ud2
 2a1975c:	ud2
 2a1975e:	ud2
 2a19760:	ud2
 2a19762:	ud2
 2a19764:	ud2
 2a19766:	ud2
 2a19768:	ud2
 2a1976a:	ud2
 2a1976c:	ud2
 2a1976e:	ud2
 2a19770:	ud2
 2a19772:	ud2
 2a19774:	ud2
 2a19776:	ud2
 2a19778:	ud2
 2a1977a:	ud2
 2a1977c:	ud2
 2a1977e:	ud2
 2a19780:	ud2
 2a19782:	ud2
 2a19784:	ud2
 2a19786:	ud2
 2a19788:	ud2
 2a1978a:	ud2
 2a1978c:	ud2
 2a1978e:	ud2
 2a19790:	ud2
 2a19792:	ud2
 2a19794:	ud2
 2a19796:	ud2
 2a19798:	ud2
 2a1979a:	ud2
 2a1979c:	ud2
 2a1979e:	ud2
 2a197a0:	ud2
 2a197a2:	ud2
 2a197a4:	ud2
 2a197a6:	ud2
 2a197a8:	ud2
 2a197aa:	ud2
 2a197ac:	ud2
 2a197ae:	ud2
 2a197b0:	ud2
 2a197b2:	ud2
 2a197b4:	ud2
 2a197b6:	ud2
 2a197b8:	ud2
 2a197ba:	ud2
 2a197bc:	ud2
 2a197be:	ud2
 2a197c0:	ud2
 2a197c2:	ud2
 2a197c4:	ud2
 2a197c6:	ud2
 2a197c8:	ud2
 2a197ca:	ud2
 2a197cc:	ud2
 2a197ce:	ud2
 2a197d0:	ud2
 2a197d2:	ud2
 2a197d4:	ud2
 2a197d6:	ud2
 2a197d8:	ud2
 2a197da:	ud2
 2a197dc:	ud2
 2a197de:	ud2
 2a197e0:	ud2
 2a197e2:	ud2
 2a197e4:	ud2
 2a197e6:	ud2
 2a197e8:	ud2
 2a197ea:	ud2
 2a197ec:	ud2
 2a197ee:	ud2
 2a197f0:	ud2
 2a197f2:	ud2
 2a197f4:	ud2
 2a197f6:	ud2
 2a197f8:	ud2
 2a197fa:	ud2
 2a197fc:	ud2
 2a197fe:	ud2
 2a19800:	ud2
 2a19802:	ud2
 2a19804:	ud2
 2a19806:	ud2
 2a19808:	ud2
 2a1980a:	ud2
 2a1980c:	ud2
 2a1980e:	ud2
 2a19810:	ud2
 2a19812:	ud2
 2a19814:	ud2
 2a19816:	ud2
 2a19818:	ud2
 2a1981a:	ud2
 2a1981c:	ud2
 2a1981e:	ud2
 2a19820:	ud2
 2a19822:	ud2
 2a19824:	ud2
 2a19826:	ud2
 2a19828:	ud2
 2a1982a:	ud2
 2a1982c:	ud2
 2a1982e:	ud2
 2a19830:	ud2
 2a19832:	ud2
 2a19834:	ud2
 2a19836:	ud2
 2a19838:	ud2
 2a1983a:	ud2
 2a1983c:	ud2
 2a1983e:	ud2
 2a19840:	ud2
 2a19842:	ud2
 2a19844:	ud2
 2a19846:	ud2
 2a19848:	ud2
 2a1984a:	ud2
 2a1984c:	ud2
 2a1984e:	ud2
 2a19850:	ud2
 2a19852:	ud2
 2a19854:	ud2
 2a19856:	ud2
 2a19858:	ud2
 2a1985a:	ud2
 2a1985c:	ud2
 2a1985e:	ud2
 2a19860:	ud2
 2a19862:	ud2
 2a19864:	ud2
 2a19866:	ud2
 2a19868:	ud2
 2a1986a:	ud2
 2a1986c:	ud2
 2a1986e:	ud2
 2a19870:	ud2
 2a19872:	ud2
 2a19874:	ud2
 2a19876:	ud2
 2a19878:	ud2
 2a1987a:	ud2
 2a1987c:	ud2
 2a1987e:	ud2
 2a19880:	ud2
 2a19882:	ud2
 2a19884:	ud2
 2a19886:	ud2
 2a19888:	ud2
 2a1988a:	ud2
 2a1988c:	ud2
 2a1988e:	ud2
 2a19890:	ud2
 2a19892:	ud2
 2a19894:	ud2
 2a19896:	ud2
 2a19898:	ud2
 2a1989a:	ud2
 2a1989c:	ud2
 2a1989e:	ud2
 2a198a0:	ud2
 2a198a2:	ud2
 2a198a4:	ud2
 2a198a6:	ud2
 2a198a8:	ud2
 2a198aa:	ud2
 2a198ac:	ud2
 2a198ae:	ud2
 2a198b0:	ud2
 2a198b2:	ud2
 2a198b4:	ud2
 2a198b6:	ud2
 2a198b8:	ud2
 2a198ba:	ud2
 2a198bc:	ud2
 2a198be:	ud2
 2a198c0:	ud2
 2a198c2:	ud2
 2a198c4:	ud2
 2a198c6:	ud2
 2a198c8:	ud2
 2a198ca:	ud2
 2a198cc:	ud2
 2a198ce:	ud2
 2a198d0:	ud2
 2a198d2:	ud2
 2a198d4:	ud2
 2a198d6:	ud2
 2a198d8:	ud2
 2a198da:	ud2
 2a198dc:	ud2
 2a198de:	ud2
 2a198e0:	ud2
 2a198e2:	ud2
 2a198e4:	ud2
 2a198e6:	ud2
 2a198e8:	ud2
 2a198ea:	ud2
 2a198ec:	ud2
 2a198ee:	ud2
 2a198f0:	ud2
 2a198f2:	ud2
 2a198f4:	ud2
 2a198f6:	ud2
 2a198f8:	ud2
 2a198fa:	ud2
 2a198fc:	ud2
 2a198fe:	ud2
 2a19900:	ud2
 2a19902:	ud2
 2a19904:	ud2
 2a19906:	ud2
 2a19908:	ud2
 2a1990a:	ud2
 2a1990c:	ud2
 2a1990e:	ud2
 2a19910:	ud2
 2a19912:	ud2
 2a19914:	ud2
 2a19916:	ud2
 2a19918:	ud2
 2a1991a:	ud2
 2a1991c:	ud2
 2a1991e:	ud2
 2a19920:	ud2
 2a19922:	ud2
 2a19924:	ud2
 2a19926:	ud2
 2a19928:	ud2
 2a1992a:	ud2
 2a1992c:	ud2
 2a1992e:	ud2
 2a19930:	ud2
 2a19932:	ud2
 2a19934:	ud2
 2a19936:	ud2
 2a19938:	ud2
 2a1993a:	ud2
 2a1993c:	ud2
 2a1993e:	ud2
 2a19940:	ud2
 2a19942:	ud2
 2a19944:	ud2
 2a19946:	ud2
 2a19948:	ud2
 2a1994a:	ud2
 2a1994c:	ud2
 2a1994e:	ud2
 2a19950:	ud2
 2a19952:	ud2
 2a19954:	ud2
 2a19956:	ud2
 2a19958:	ud2
 2a1995a:	ud2
 2a1995c:	ud2
 2a1995e:	ud2
 2a19960:	ud2
 2a19962:	ud2
 2a19964:	ud2
 2a19966:	ud2
 2a19968:	ud2
 2a1996a:	ud2
 2a1996c:	ud2
 2a1996e:	ud2
 2a19970:	ud2
 2a19972:	ud2
 2a19974:	ud2
 2a19976:	ud2
 2a19978:	ud2
 2a1997a:	ud2
 2a1997c:	ud2
 2a1997e:	ud2
 2a19980:	ud2
 2a19982:	ud2
 2a19984:	ud2
 2a19986:	ud2
 2a19988:	ud2
 2a1998a:	ud2
 2a1998c:	ud2
 2a1998e:	ud2
 2a19990:	ud2
 2a19992:	ud2
 2a19994:	ud2
 2a19996:	ud2
 2a19998:	ud2
 2a1999a:	ud2
 2a1999c:	ud2
 2a1999e:	ud2
 2a199a0:	ud2
 2a199a2:	ud2
 2a199a4:	ud2
 2a199a6:	ud2
 2a199a8:	ud2
 2a199aa:	ud2
 2a199ac:	ud2
 2a199ae:	ud2
 2a199b0:	ud2
 2a199b2:	ud2
 2a199b4:	ud2
 2a199b6:	ud2
 2a199b8:	ud2
 2a199ba:	ud2
 2a199bc:	ud2
 2a199be:	ud2
 2a199c0:	ud2
 2a199c2:	ud2
 2a199c4:	ud2
 2a199c6:	ud2
 2a199c8:	ud2
 2a199ca:	ud2
 2a199cc:	ud2
 2a199ce:	ud2
 2a199d0:	ud2
 2a199d2:	ud2
 2a199d4:	ud2
 2a199d6:	ud2
 2a199d8:	ud2
 2a199da:	ud2
 2a199dc:	ud2
 2a199de:	ud2
 2a199e0:	ud2
 2a199e2:	ud2
 2a199e4:	ud2
 2a199e6:	ud2
 2a199e8:	ud2
 2a199ea:	ud2
 2a199ec:	ud2
 2a199ee:	ud2
 2a199f0:	ud2
 2a199f2:	ud2
 2a199f4:	ud2
 2a199f6:	ud2
 2a199f8:	ud2
 2a199fa:	ud2
 2a199fc:	ud2
 2a199fe:	ud2
 2a19a00:	ud2
 2a19a02:	ud2
 2a19a04:	ud2
 2a19a06:	ud2
 2a19a08:	ud2
 2a19a0a:	ud2
 2a19a0c:	ud2
 2a19a0e:	ud2
 2a19a10:	ud2
 2a19a12:	ud2
 2a19a14:	ud2
 2a19a16:	ud2
 2a19a18:	ud2
 2a19a1a:	ud2
 2a19a1c:	ud2
 2a19a1e:	ud2
 2a19a20:	ud2
 2a19a22:	ud2
 2a19a24:	ud2
 2a19a26:	ud2
 2a19a28:	ud2
 2a19a2a:	ud2
 2a19a2c:	ud2
 2a19a2e:	ud2
 2a19a30:	ud2
 2a19a32:	ud2
 2a19a34:	ud2
 2a19a36:	ud2
 2a19a38:	ud2
 2a19a3a:	ud2
 2a19a3c:	ud2
 2a19a3e:	ud2
 2a19a40:	ud2
 2a19a42:	ud2
 2a19a44:	ud2
 2a19a46:	ud2
 2a19a48:	ud2
 2a19a4a:	ud2
 2a19a4c:	ud2
 2a19a4e:	ud2
 2a19a50:	ud2
 2a19a52:	ud2
 2a19a54:	ud2
 2a19a56:	ud2
 2a19a58:	ud2
 2a19a5a:	ud2
 2a19a5c:	ud2
 2a19a5e:	ud2
 2a19a60:	ud2
 2a19a62:	ud2
 2a19a64:	ud2
 2a19a66:	ud2
 2a19a68:	ud2
 2a19a6a:	ud2
 2a19a6c:	ud2
 2a19a6e:	ud2
 2a19a70:	ud2
 2a19a72:	ud2
 2a19a74:	ud2
 2a19a76:	ud2
 2a19a78:	ud2
 2a19a7a:	ud2
 2a19a7c:	ud2
 2a19a7e:	ud2
 2a19a80:	ud2
 2a19a82:	ud2
 2a19a84:	ud2
 2a19a86:	ud2
 2a19a88:	ud2
 2a19a8a:	ud2
 2a19a8c:	ud2
 2a19a8e:	ud2
 2a19a90:	ud2
 2a19a92:	ud2
 2a19a94:	ud2
 2a19a96:	ud2
 2a19a98:	ud2
 2a19a9a:	ud2
 2a19a9c:	ud2
 2a19a9e:	ud2
 2a19aa0:	ud2
 2a19aa2:	ud2
 2a19aa4:	ud2
 2a19aa6:	ud2
 2a19aa8:	ud2
 2a19aaa:	ud2
 2a19aac:	ud2
 2a19aae:	ud2
 2a19ab0:	ud2
 2a19ab2:	ud2
 2a19ab4:	ud2
 2a19ab6:	ud2
 2a19ab8:	ud2
 2a19aba:	ud2
 2a19abc:	ud2
 2a19abe:	ud2
 2a19ac0:	ud2
 2a19ac2:	ud2
 2a19ac4:	ud2
 2a19ac6:	ud2
 2a19ac8:	ud2
 2a19aca:	ud2
 2a19acc:	ud2
 2a19ace:	ud2
 2a19ad0:	ud2
 2a19ad2:	ud2
 2a19ad4:	ud2
 2a19ad6:	ud2
 2a19ad8:	ud2
 2a19ada:	ud2
 2a19adc:	ud2
 2a19ade:	ud2
 2a19ae0:	ud2
 2a19ae2:	ud2
 2a19ae4:	ud2
 2a19ae6:	ud2
 2a19ae8:	ud2
 2a19aea:	ud2
 2a19aec:	ud2
 2a19aee:	ud2
 2a19af0:	ud2
 2a19af2:	ud2
 2a19af4:	ud2
 2a19af6:	ud2
 2a19af8:	ud2
 2a19afa:	ud2
 2a19afc:	ud2
 2a19afe:	ud2
 2a19b00:	ud2
 2a19b02:	ud2
 2a19b04:	ud2
 2a19b06:	ud2
 2a19b08:	ud2
 2a19b0a:	ud2
 2a19b0c:	ud2
 2a19b0e:	ud2
 2a19b10:	ud2
 2a19b12:	ud2
 2a19b14:	ud2
 2a19b16:	ud2
 2a19b18:	ud2
 2a19b1a:	ud2
 2a19b1c:	ud2
 2a19b1e:	ud2
 2a19b20:	ud2
 2a19b22:	ud2
 2a19b24:	ud2
 2a19b26:	ud2
 2a19b28:	ud2
 2a19b2a:	ud2
 2a19b2c:	ud2
 2a19b2e:	ud2
 2a19b30:	ud2
 2a19b32:	ud2
 2a19b34:	ud2
 2a19b36:	ud2
 2a19b38:	ud2
 2a19b3a:	ud2
 2a19b3c:	ud2
 2a19b3e:	ud2
 2a19b40:	ud2
 2a19b42:	ud2
 2a19b44:	ud2
 2a19b46:	ud2
 2a19b48:	ud2
 2a19b4a:	ud2
 2a19b4c:	ud2
 2a19b4e:	ud2
 2a19b50:	ud2
 2a19b52:	ud2
 2a19b54:	ud2
 2a19b56:	ud2
 2a19b58:	ud2
 2a19b5a:	ud2
 2a19b5c:	ud2
 2a19b5e:	ud2
 2a19b60:	ud2
 2a19b62:	ud2
 2a19b64:	ud2
 2a19b66:	ud2
 2a19b68:	ud2
 2a19b6a:	ud2
 2a19b6c:	ud2
 2a19b6e:	ud2
 2a19b70:	ud2
 2a19b72:	ud2
 2a19b74:	ud2
 2a19b76:	ud2
 2a19b78:	ud2
 2a19b7a:	ud2
 2a19b7c:	ud2
 2a19b7e:	ud2
 2a19b80:	ud2
 2a19b82:	ud2
 2a19b84:	ud2
 2a19b86:	ud2
 2a19b88:	ud2
 2a19b8a:	ud2
 2a19b8c:	ud2
 2a19b8e:	ud2
 2a19b90:	ud2
 2a19b92:	ud2
 2a19b94:	ud2
 2a19b96:	ud2
 2a19b98:	ud2
 2a19b9a:	ud2
 2a19b9c:	ud2
 2a19b9e:	ud2
 2a19ba0:	ud2
 2a19ba2:	ud2
 2a19ba4:	ud2
 2a19ba6:	ud2
 2a19ba8:	ud2
 2a19baa:	ud2
 2a19bac:	ud2
 2a19bae:	ud2
 2a19bb0:	ud2
 2a19bb2:	ud2
 2a19bb4:	ud2
 2a19bb6:	ud2
 2a19bb8:	ud2
 2a19bba:	ud2
 2a19bbc:	ud2
 2a19bbe:	ud2
 2a19bc0:	ud2
 2a19bc2:	ud2
 2a19bc4:	ud2
 2a19bc6:	ud2
 2a19bc8:	ud2
 2a19bca:	ud2
 2a19bcc:	ud2
 2a19bce:	ud2
 2a19bd0:	ud2
 2a19bd2:	ud2
 2a19bd4:	ud2
 2a19bd6:	add    %al,(%rax)
 2a19bd8:	(bad)
 2a19bd9:	(bad)
 2a19bda:	(bad)
 2a19bdb:	incl   (%rax)
	...
