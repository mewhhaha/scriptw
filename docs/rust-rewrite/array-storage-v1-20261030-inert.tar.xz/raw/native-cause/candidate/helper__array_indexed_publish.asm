
/workspace/scriptw/target/performance-dense-numbers-20261030/native-cause/candidate/runtime-portable.elf:     file format elf64-x86-64


Disassembly of section .text:

00000000029f6be0 <wasm[0]::function[1013]::helper::array_indexed_publish>:
 29f6be0:	push   %rbp
 29f6be1:	mov    %rsp,%rbp
 29f6be4:	mov    0x8(%rdi),%r10
 29f6be8:	mov    0x18(%r10),%r10
 29f6bec:	add    $0x120,%r10
 29f6bf3:	cmp    %rsp,%r10
 29f6bf6:	ja     29fc64c <wasm[0]::function[1013]::helper::array_indexed_publish+0x5a6c>
 29f6bfc:	sub    $0x110,%rsp
 29f6c03:	mov    %rbx,0xe0(%rsp)
 29f6c0b:	mov    %r12,0xe8(%rsp)
 29f6c13:	mov    %r13,0xf0(%rsp)
 29f6c1b:	mov    %r14,0xf8(%rsp)
 29f6c23:	mov    %r15,0x100(%rsp)
 29f6c2b:	mov    %rcx,0x68(%rsp)
 29f6c30:	mov    %edx,0x28(%rsp)
 29f6c34:	mov    %r8d,(%rsp)
 29f6c38:	movl   $0x0,0x20(%rsp)
 29f6c40:	mov    0x18(%rdi),%rax
 29f6c44:	mov    (%rax),%rcx
 29f6c47:	mov    %rax,0xd0(%rsp)
 29f6c4f:	mov    0x8(%rdi),%rdx
 29f6c53:	mov    %rdi,0x60(%rsp)
 29f6c58:	mov    0x8(%rdx),%rax
 29f6c5c:	mov    %rdx,0xc8(%rsp)
 29f6c64:	cmp    %rax,%rcx
 29f6c67:	jae    29fba19 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4e39>
 29f6c6d:	mov    0x68(%rsp),%rcx
 29f6c72:	mov    %rax,0xa8(%rsp)
 29f6c7a:	cmp    0x5d1f(%rip),%rcx        # 29fc9a0 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5dc0>
 29f6c81:	mov    %rcx,0x68(%rsp)
 29f6c86:	jae    29fc64e <wasm[0]::function[1013]::helper::array_indexed_publish+0x5a6e>
 29f6c8c:	mov    0x28(%rsp),%edx
 29f6c90:	xor    %r10d,%r10d
 29f6c93:	test   %edx,%edx
 29f6c95:	je     29fc650 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5a70>
 29f6c9b:	test   %edx,%edx
 29f6c9d:	je     29fc652 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5a72>
 29f6ca3:	mov    0xc8(%rsp),%rsi
 29f6cab:	mov    0x28(%rsi),%rax
 29f6caf:	mov    0x20(%rsi),%rdi
 29f6cb3:	mov    %edx,%r8d
 29f6cb6:	mov    %rdx,0x70(%rsp)
 29f6cbb:	xor    %rdx,%rdx
 29f6cbe:	add    %r8,%rdi
 29f6cc1:	cmp    %rax,%r8
 29f6cc4:	cmova  %rdx,%rdi
 29f6cc8:	mov    0x24(%rdi),%eax
 29f6ccb:	mov    (%rsp),%edx
 29f6cce:	cmp    $0x4,%eax
 29f6cd1:	sete   %dil
 29f6cd5:	cmp    $0x2,%eax
 29f6cd8:	sete   %r8b
 29f6cdc:	or     %r8d,%edi
 29f6cdf:	cmp    $0x3,%eax
 29f6ce2:	sete   %al
 29f6ce5:	or     %eax,%edi
 29f6ce7:	test   %dil,%dil
 29f6cea:	jne    29f6cfd <wasm[0]::function[1013]::helper::array_indexed_publish+0x11d>
 29f6cf0:	mov    %rsi,0xc8(%rsp)
 29f6cf8:	jmp    29f9f97 <wasm[0]::function[1013]::helper::array_indexed_publish+0x33b7>
 29f6cfd:	mov    (%rsp),%edx
 29f6d00:	xor    %r10d,%r10d
 29f6d03:	test   %edx,%edx
 29f6d05:	je     29fc654 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5a74>
 29f6d0b:	test   %edx,%edx
 29f6d0d:	je     29fc656 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5a76>
 29f6d13:	mov    0x28(%rsi),%rax
 29f6d17:	mov    %edx,%edi
 29f6d19:	mov    %rdi,%rcx
 29f6d1c:	add    0x20(%rsi),%rcx
 29f6d20:	xor    %r8,%r8
 29f6d23:	cmp    %rax,%rdi
 29f6d26:	cmova  %r8,%rcx
 29f6d2a:	mov    0x10(%rcx),%edi
 29f6d2d:	mov    0x28(%rsp),%eax
 29f6d31:	mov    %rax,0x70(%rsp)
 29f6d36:	cmp    $0xe,%edi
 29f6d39:	je     29f6d51 <wasm[0]::function[1013]::helper::array_indexed_publish+0x171>
 29f6d3f:	mov    0x70(%rsp),%rax
 29f6d44:	mov    %rsi,0xc8(%rsp)
 29f6d4c:	jmp    29f93ab <wasm[0]::function[1013]::helper::array_indexed_publish+0x27cb>
 29f6d51:	mov    (%rsp),%edi
 29f6d54:	test   %edi,%edi
 29f6d56:	je     29fc658 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5a78>
 29f6d5c:	test   %edi,%edi
 29f6d5e:	je     29fc65a <wasm[0]::function[1013]::helper::array_indexed_publish+0x5a7a>
 29f6d64:	mov    0x28(%rsi),%r8
 29f6d68:	mov    0x20(%rsi),%r10
 29f6d6c:	mov    %edi,%r9d
 29f6d6f:	lea    (%r10,%r9,1),%rdi
 29f6d73:	xor    %r10,%r10
 29f6d76:	cmp    %r8,%r9
 29f6d79:	cmova  %r10,%rdi
 29f6d7d:	mov    0x14(%rdi),%edx
 29f6d80:	test   %edx,%edx
 29f6d82:	je     29fc65c <wasm[0]::function[1013]::helper::array_indexed_publish+0x5a7c>
 29f6d88:	xor    %eax,%eax
 29f6d8a:	test   $0x1,%edx
 29f6d90:	je     29f6da3 <wasm[0]::function[1013]::helper::array_indexed_publish+0x1c3>
 29f6d96:	mov    %rsi,0xc8(%rsp)
 29f6d9e:	jmp    29f6ddb <wasm[0]::function[1013]::helper::array_indexed_publish+0x1fb>
 29f6da3:	mov    0x28(%rsi),%rax
 29f6da7:	mov    0x20(%rsi),%rcx
 29f6dab:	mov    %rsi,0xc8(%rsp)
 29f6db3:	mov    %edx,%esi
 29f6db5:	lea    0x4(%rcx,%rsi,1),%rcx
 29f6dba:	xor    %rdi,%rdi
 29f6dbd:	cmp    %rax,%rsi
 29f6dc0:	cmova  %rdi,%rcx
 29f6dc4:	mov    (%rcx),%eax
 29f6dc6:	mov    0x60(%rsp),%rdi
 29f6dcb:	mov    0x28(%rdi),%rcx
 29f6dcf:	cmp    0x120(%rcx),%eax
 29f6dd5:	sete   %al
 29f6dd8:	movzbl %al,%eax
 29f6ddb:	test   %eax,%eax
 29f6ddd:	jne    29f6e42 <wasm[0]::function[1013]::helper::array_indexed_publish+0x262>
 29f6de3:	mov    0x60(%rsp),%rsi
 29f6de8:	mov    0x60(%rsp),%rdi
 29f6ded:	call   2a1eec0 <wasm[0]::function[1024]::helper::property_value_resolve>
 29f6df2:	test   %eax,%eax
 29f6df4:	je     29fc65e <wasm[0]::function[1013]::helper::array_indexed_publish+0x5a7e>
 29f6dfa:	test   %eax,%eax
 29f6dfc:	je     29fc660 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5a80>
 29f6e02:	mov    0xc8(%rsp),%rbx
 29f6e0a:	mov    0x28(%rbx),%rcx
 29f6e0e:	mov    0x20(%rbx),%rsi
 29f6e12:	mov    %eax,%edx
 29f6e14:	lea    (%rsi,%rdx,1),%rax
 29f6e18:	xor    %rsi,%rsi
 29f6e1b:	cmp    %rcx,%rdx
 29f6e1e:	cmova  %rsi,%rax
 29f6e22:	mov    0x18(%rax),%r12d
 29f6e26:	mov    %r12,0x98(%rsp)
 29f6e2e:	mov    0x10(%rax),%r13
 29f6e32:	mov    %r13,0x90(%rsp)
 29f6e3a:	mov    0x1c(%rax),%esi
 29f6e3d:	jmp    29f6ed2 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2f2>
 29f6e42:	xor    %eax,%eax
 29f6e44:	test   $0x1,%edx
 29f6e4a:	jne    29f6e88 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2a8>
 29f6e50:	mov    0xc8(%rsp),%rbx
 29f6e58:	mov    0x28(%rbx),%rax
 29f6e5c:	mov    0x20(%rbx),%rcx
 29f6e60:	mov    %edx,%esi
 29f6e62:	lea    0x4(%rcx,%rsi,1),%rcx
 29f6e67:	xor    %rdi,%rdi
 29f6e6a:	cmp    %rax,%rsi
 29f6e6d:	cmova  %rdi,%rcx
 29f6e71:	mov    (%rcx),%eax
 29f6e73:	mov    0x60(%rsp),%rdi
 29f6e78:	mov    0x28(%rdi),%rcx
 29f6e7c:	cmp    0x120(%rcx),%eax
 29f6e82:	sete   %al
 29f6e85:	movzbl %al,%eax
 29f6e88:	test   %eax,%eax
 29f6e8a:	je     29fc662 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5a82>
 29f6e90:	test   %edx,%edx
 29f6e92:	je     29fc664 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5a84>
 29f6e98:	mov    0xc8(%rsp),%rbx
 29f6ea0:	mov    0x28(%rbx),%rcx
 29f6ea4:	mov    0x20(%rbx),%rax
 29f6ea8:	mov    %edx,%edx
 29f6eaa:	add    %rdx,%rax
 29f6ead:	xor    %rsi,%rsi
 29f6eb0:	cmp    %rcx,%rdx
 29f6eb3:	cmova  %rsi,%rax
 29f6eb7:	mov    0x18(%rax),%r12d
 29f6ebb:	mov    %r12,0x98(%rsp)
 29f6ec3:	mov    0x10(%rax),%r13
 29f6ec7:	mov    %r13,0x90(%rsp)
 29f6ecf:	mov    0x1c(%rax),%esi
 29f6ed2:	mov    0x28(%rsp),%edx
 29f6ed6:	mov    %rdx,0x70(%rsp)
 29f6edb:	xor    %r10d,%r10d
 29f6ede:	mov    0x70(%rsp),%rax
 29f6ee3:	test   %eax,%edx
 29f6ee5:	je     29fc666 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5a86>
 29f6eeb:	mov    0x70(%rsp),%rdi
 29f6ef0:	test   %edi,%edx
 29f6ef2:	je     29fc668 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5a88>
 29f6ef8:	mov    0xc8(%rsp),%rbx
 29f6f00:	mov    0x28(%rbx),%rax
 29f6f04:	mov    0x20(%rbx),%rdx
 29f6f08:	mov    0x70(%rsp),%r8
 29f6f0d:	mov    %r8d,%edi
 29f6f10:	add    %rdi,%rdx
 29f6f13:	xor    %r13,%r13
 29f6f16:	cmp    %rax,%rdi
 29f6f19:	cmova  %r13,%rdx
 29f6f1d:	mov    0x24(%rdx),%r8d
 29f6f21:	mov    0x20(%rsp),%eax
 29f6f25:	mov    %rax,0x78(%rsp)
 29f6f2a:	mov    (%rsp),%edx
 29f6f2d:	cmp    $0x4,%r8d
 29f6f31:	sete   %al
 29f6f34:	cmp    $0x2,%r8d
 29f6f38:	sete   %r8b
 29f6f3c:	or     %r8d,%eax
 29f6f3f:	mov    0x98(%rsp),%r12
 29f6f47:	cmp    $0x3,%r12d
 29f6f4b:	sete   %cl
 29f6f4e:	test   %al,%cl
 29f6f50:	jne    29f6f68 <wasm[0]::function[1013]::helper::array_indexed_publish+0x388>
 29f6f56:	mov    0x70(%rsp),%rax
 29f6f5b:	mov    %r13,0x88(%rsp)
 29f6f63:	jmp    29f83bc <wasm[0]::function[1013]::helper::array_indexed_publish+0x17dc>
 29f6f68:	mov    0x28(%rsp),%edx
 29f6f6c:	mov    %rdx,0x70(%rsp)
 29f6f71:	xor    %r10d,%r10d
 29f6f74:	mov    0x70(%rsp),%rax
 29f6f79:	test   %eax,%edx
 29f6f7b:	je     29fc66a <wasm[0]::function[1013]::helper::array_indexed_publish+0x5a8a>
 29f6f81:	test   %eax,%edx
 29f6f83:	je     29fc66c <wasm[0]::function[1013]::helper::array_indexed_publish+0x5a8c>
 29f6f89:	mov    0xc8(%rsp),%rbx
 29f6f91:	mov    0x28(%rbx),%rax
 29f6f95:	mov    0x20(%rbx),%rdi
 29f6f99:	mov    %edx,%r8d
 29f6f9c:	lea    (%rdi,%r8,1),%rdx
 29f6fa0:	xor    %r11,%r11
 29f6fa3:	cmp    %rax,%r8
 29f6fa6:	cmova  %r11,%rdx
 29f6faa:	mov    0x28(%rdx),%r8d
 29f6fae:	mov    0x2c(%rdx),%r9d
 29f6fb2:	test   %r8d,%r8d
 29f6fb5:	je     29fc66e <wasm[0]::function[1013]::helper::array_indexed_publish+0x5a8e>
 29f6fbb:	test   %r8d,%r8d
 29f6fbe:	je     29fc670 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5a90>
 29f6fc4:	mov    %r8d,%ebx
 29f6fc7:	lea    0x10(%rdi,%rbx,1),%rdi
 29f6fcc:	cmp    %rax,%rbx
 29f6fcf:	cmova  %r11,%rdi
 29f6fd3:	mov    (%rdi),%r14d
 29f6fd6:	mov    0x18(%rdx),%r13
 29f6fda:	mov    0x20(%rsp),%eax
 29f6fde:	mov    %rax,0x78(%rsp)
 29f6fe3:	mov    (%rsp),%edx
 29f6fe6:	mov    %r14d,%r12d
 29f6fe9:	mov    0x68(%rsp),%rcx
 29f6fee:	cmp    %r12,%rcx
 29f6ff1:	setb   %al
 29f6ff4:	cmp    $0x100000,%rcx
 29f6ffb:	setb   %r11b
 29f6fff:	lea    0x8(%r13,%r13,1),%rcx
 29f7004:	mov    0x68(%rsp),%rdi
 29f7009:	mov    %r13,0x88(%rsp)
 29f7011:	cmp    %rcx,%rdi
 29f7014:	setbe  %bl
 29f7017:	and    %ebx,%r11d
 29f701a:	or     %r11d,%eax
 29f701d:	test   %al,%al
 29f701f:	je     29f83b7 <wasm[0]::function[1013]::helper::array_indexed_publish+0x17d7>
 29f7025:	mov    0x28(%rsp),%edx
 29f7029:	mov    %rdx,0x70(%rsp)
 29f702e:	mov    0x20(%rsp),%eax
 29f7032:	mov    %rax,0x78(%rsp)
 29f7037:	mov    (%rsp),%edx
 29f703a:	mov    0x68(%rsp),%rcx
 29f703f:	cmp    %r12,%rcx
 29f7042:	jae    29f7052 <wasm[0]::function[1013]::helper::array_indexed_publish+0x472>
 29f7048:	mov    0x70(%rsp),%rax
 29f704d:	jmp    29f7bff <wasm[0]::function[1013]::helper::array_indexed_publish+0x101f>
 29f7052:	test   %r14d,%r14d
 29f7055:	jne    29f7061 <wasm[0]::function[1013]::helper::array_indexed_publish+0x481>
 29f705b:	mov    $0x4,%r14d
 29f7061:	mov    %r8d,0x30(%rsp)
 29f7066:	mov    0x70(%rsp),%rax
 29f706b:	mov    %eax,0x8(%rsp)
 29f706f:	mov    %r9d,0x58(%rsp)
 29f7074:	mov    0x78(%rsp),%rax
 29f7079:	mov    %eax,(%rsp)
 29f707c:	mov    %esi,0x20(%rsp)
 29f7080:	mov    %edx,0x28(%rsp)
 29f7084:	mov    0xd0(%rsp),%r13
 29f708c:	mov    0x0(%r13),%rax
 29f7090:	mov    0xa8(%rsp),%rsi
 29f7098:	cmp    %rsi,%rax
 29f709b:	jae    29fba35 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4e55>
 29f70a1:	mov    %r14d,%r15d
 29f70a4:	mov    0x68(%rsp),%rcx
 29f70a9:	cmp    %r15,%rcx
 29f70ac:	jb     29f70dd <wasm[0]::function[1013]::helper::array_indexed_publish+0x4fd>
 29f70b2:	mov    0x30(%rsp),%r8d
 29f70b7:	mov    0x8(%rsp),%edx
 29f70bb:	mov    %rdx,0x70(%rsp)
 29f70c0:	mov    0x58(%rsp),%r9d
 29f70c5:	mov    (%rsp),%esi
 29f70c8:	mov    %rsi,0x78(%rsp)
 29f70cd:	mov    0x20(%rsp),%esi
 29f70d1:	mov    0x28(%rsp),%edx
 29f70d5:	shl    $1,%r14d
 29f70d8:	jmp    29f7061 <wasm[0]::function[1013]::helper::array_indexed_publish+0x481>
 29f70dd:	mov    %r15,%rcx
 29f70e0:	shl    $0x3,%rcx
 29f70e4:	mov    %rcx,%rax
 29f70e7:	shr    $0x20,%rax
 29f70eb:	mov    %rcx,%r13
 29f70ee:	test   %rax,%rax
 29f70f1:	jne    29fc672 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5a92>
 29f70f7:	mov    %r14,%rcx
 29f70fa:	shl    $0x3,%ecx
 29f70fd:	add    $0x18,%ecx
 29f7100:	jb     29fc674 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5a94>
 29f7106:	mov    0x60(%rsp),%rdi
 29f710b:	mov    0x20(%rdi),%rdi
 29f710f:	mov    (%rdi),%eax
 29f7111:	mov    %eax,%edx
 29f7113:	mov    %ecx,%esi
 29f7115:	add    $0xf,%rsi
 29f711c:	mov    %rsi,%r8
 29f711f:	and    $0xfffffffffffffff0,%r8
 29f7123:	add    %rdx,%r8
 29f7126:	mov    0x4(%rdi),%r9d
 29f712a:	mov    %rdi,0xb0(%rsp)
 29f7132:	cmp    %r9,%r8
 29f7135:	ja     29fba6c <wasm[0]::function[1013]::helper::array_indexed_publish+0x4e8c>
 29f713b:	add    $0xf,%ecx
 29f7141:	and    $0xfffffff0,%ecx
 29f7144:	lea    (%rax,%rcx,1),%edi
 29f7147:	mov    0xb0(%rsp),%rcx
 29f714f:	mov    %edi,(%rcx)
 29f7151:	mov    0xc8(%rsp),%rbx
 29f7159:	mov    0x20(%rbx),%rdi
 29f715d:	lea    (%rdi,%rdx,1),%rcx
 29f7161:	movl   $0xa8000006,(%rdi,%rdx,1)
 29f7168:	mov    0x60(%rsp),%r8
 29f716d:	mov    0x28(%r8),%r8
 29f7171:	mov    0x1a0(%r8),%r8d
 29f7178:	mov    %r8d,0x4(%rdi,%rdx,1)
 29f717d:	and    $0xfffffffffffffff0,%rsi
 29f7181:	mov    %esi,0x8(%rdi,%rdx,1)
 29f7185:	mov    %eax,0x10(%rsp)
 29f7189:	mov    %r14d,0x10(%rcx)
 29f718d:	test   %eax,%eax
 29f718f:	je     29fc676 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5a96>
 29f7195:	mov    0xc8(%rsp),%rbx
 29f719d:	mov    0x28(%rbx),%rcx
 29f71a1:	mov    0x20(%rbx),%rdx
 29f71a5:	mov    %eax,%eax
 29f71a7:	lea    0x10(%rdx,%rax,1),%rsi
 29f71ac:	xor    %rdi,%rdi
 29f71af:	cmp    %rcx,%rax
 29f71b2:	cmova  %rdi,%rsi
 29f71b6:	mov    (%rsi),%esi
 29f71b8:	cmp    %rsi,%r15
 29f71bb:	ja     29fc678 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5a98>
 29f71c1:	lea    0x18(%rdx,%rax,1),%rsi
 29f71c6:	mov    %r13,%r9
 29f71c9:	mov    %rsi,%rax
 29f71cc:	add    %r9,%rax
 29f71cf:	mov    %rsi,%r15
 29f71d2:	jb     29fc67a <wasm[0]::function[1013]::helper::array_indexed_publish+0x5a9a>
 29f71d8:	add    %rdx,%rcx
 29f71db:	cmp    %rcx,%rax
 29f71de:	ja     29fc67c <wasm[0]::function[1013]::helper::array_indexed_publish+0x5a9c>
 29f71e4:	mov    0x30(%rsp),%r8d
 29f71e9:	mov    0x8(%rsp),%edi
 29f71ed:	mov    0x58(%rsp),%esi
 29f71f1:	mov    (%rsp),%edx
 29f71f4:	mov    0x20(%rsp),%ecx
 29f71f8:	mov    0x28(%rsp),%eax
 29f71fc:	cmp    $0x8000000,%r9
 29f7203:	jbe    29f7293 <wasm[0]::function[1013]::helper::array_indexed_publish+0x6b3>
 29f7209:	mov    %r8d,0x28(%rsp)
 29f720e:	mov    %edi,0x20(%rsp)
 29f7212:	mov    %esi,(%rsp)
 29f7215:	mov    %edx,0x58(%rsp)
 29f7219:	mov    %ecx,0x8(%rsp)
 29f721d:	mov    %eax,0x30(%rsp)
 29f7221:	mov    0xd0(%rsp),%rax
 29f7229:	mov    (%rax),%rax
 29f722c:	mov    0xa8(%rsp),%rcx
 29f7234:	cmp    %rcx,%rax
 29f7237:	jae    29fba9e <wasm[0]::function[1013]::helper::array_indexed_publish+0x4ebe>
 29f723d:	xor    %edx,%edx
 29f723f:	mov    $0x8000000,%ecx
 29f7244:	mov    %r15,%rsi
 29f7247:	mov    0x60(%rsp),%rdi
 29f724c:	call   3039b13 <wasmtime_builtin_memory_fill>
 29f7251:	mov    0x28(%rsp),%r8d
 29f7256:	mov    0x20(%rsp),%edi
 29f725a:	mov    (%rsp),%esi
 29f725d:	mov    0x58(%rsp),%edx
 29f7261:	mov    0x8(%rsp),%ecx
 29f7265:	mov    0x30(%rsp),%eax
 29f7269:	mov    %r13,%r9
 29f726c:	sub    $0x8000000,%r9
 29f7273:	mov    %r9,%r13
 29f7276:	mov    %r15,%r9
 29f7279:	add    $0x8000000,%r9
 29f7280:	mov    %r9,%r15
 29f7283:	mov    %r13,%r9
 29f7286:	cmp    $0x8000000,%r9
 29f728d:	ja     29f7209 <wasm[0]::function[1013]::helper::array_indexed_publish+0x629>
 29f7293:	mov    %r8d,0x30(%rsp)
 29f7298:	mov    %edi,0x8(%rsp)
 29f729c:	mov    %esi,0x58(%rsp)
 29f72a0:	mov    %edx,(%rsp)
 29f72a3:	mov    %ecx,0x20(%rsp)
 29f72a7:	mov    %eax,0x28(%rsp)
 29f72ab:	mov    0xd0(%rsp),%rax
 29f72b3:	mov    (%rax),%rax
 29f72b6:	mov    0xa8(%rsp),%rsi
 29f72be:	cmp    %rsi,%rax
 29f72c1:	jae    29fbad2 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4ef2>
 29f72c7:	xor    %edx,%edx
 29f72c9:	mov    %r13,%rcx
 29f72cc:	mov    %r15,%rsi
 29f72cf:	mov    0x60(%rsp),%rdi
 29f72d4:	call   3039b13 <wasmtime_builtin_memory_fill>
 29f72d9:	mov    0x10(%rsp),%edx
 29f72dd:	test   %edx,%edx
 29f72df:	je     29fc67e <wasm[0]::function[1013]::helper::array_indexed_publish+0x5a9e>
 29f72e5:	mov    0x30(%rsp),%ecx
 29f72e9:	test   %ecx,%ecx
 29f72eb:	je     29fc680 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5aa0>
 29f72f1:	test   %edx,%edx
 29f72f3:	je     29fc682 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5aa2>
 29f72f9:	mov    0xc8(%rsp),%rbx
 29f7301:	mov    0x28(%rbx),%rax
 29f7305:	mov    0x20(%rbx),%r9
 29f7309:	mov    %edx,%r10d
 29f730c:	lea    (%r9,%r10,1),%r11
 29f7310:	lea    0x10(%r9,%r10,1),%rsi
 29f7315:	xor    %rdx,%rdx
 29f7318:	cmp    %rax,%r10
 29f731b:	cmova  %rdx,%rsi
 29f731f:	mov    (%rsi),%esi
 29f7321:	cmp    %rsi,%r12
 29f7324:	ja     29fc684 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5aa4>
 29f732a:	test   %ecx,%ecx
 29f732c:	je     29fc686 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5aa6>
 29f7332:	mov    %ecx,%ebx
 29f7334:	lea    (%r9,%rbx,1),%r15
 29f7338:	lea    0x10(%r9,%rbx,1),%rcx
 29f733d:	cmp    %rax,%rbx
 29f7340:	cmova  %rdx,%rcx
 29f7344:	mov    (%rcx),%ecx
 29f7346:	cmp    %rcx,%r12
 29f7349:	ja     29fc688 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5aa8>
 29f734f:	lea    0x18(%r9,%r10,1),%rcx
 29f7354:	mov    %r12,%r13
 29f7357:	shl    $0x3,%r13
 29f735b:	mov    %rcx,%rdx
 29f735e:	add    %r13,%rdx
 29f7361:	jb     29fc68a <wasm[0]::function[1013]::helper::array_indexed_publish+0x5aaa>
 29f7367:	add    %r9,%rax
 29f736a:	cmp    %rax,%rdx
 29f736d:	ja     29fc68c <wasm[0]::function[1013]::helper::array_indexed_publish+0x5aac>
 29f7373:	lea    0x18(%r9,%rbx,1),%rdx
 29f7378:	mov    %rdx,%rsi
 29f737b:	add    %r13,%rsi
 29f737e:	jb     29fc68e <wasm[0]::function[1013]::helper::array_indexed_publish+0x5aae>
 29f7384:	cmp    %rax,%rsi
 29f7387:	ja     29fc690 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5ab0>
 29f738d:	cmp    %rcx,%rdx
 29f7390:	ja     29f74a7 <wasm[0]::function[1013]::helper::array_indexed_publish+0x8c7>
 29f7396:	mov    0x8(%rsp),%eax
 29f739a:	mov    0x58(%rsp),%ecx
 29f739e:	mov    0x10(%rsp),%edx
 29f73a2:	mov    (%rsp),%esi
 29f73a5:	mov    0x20(%rsp),%edi
 29f73a9:	mov    0x28(%rsp),%r8d
 29f73ae:	lea    0x18(%r11,%r12,8),%r9
 29f73b3:	mov    %r9,0x80(%rsp)
 29f73bb:	lea    0x18(%r15,%r12,8),%r9
 29f73c0:	mov    %r9,%r15
 29f73c3:	cmp    $0x8000000,%r13
 29f73ca:	mov    %r13,%r12
 29f73cd:	ja     29f73e3 <wasm[0]::function[1013]::helper::array_indexed_publish+0x803>
 29f73d3:	mov    0x80(%rsp),%r9
 29f73db:	mov    %r12,%r11
 29f73de:	jmp    29f748b <wasm[0]::function[1013]::helper::array_indexed_publish+0x8ab>
 29f73e3:	mov    %eax,0x18(%rsp)
 29f73e7:	mov    %ecx,0x50(%rsp)
 29f73eb:	mov    %edx,0x48(%rsp)
 29f73ef:	mov    %esi,0x40(%rsp)
 29f73f3:	mov    %edi,0x38(%rsp)
 29f73f7:	mov    %r8d,0x30(%rsp)
 29f73fc:	mov    0xd0(%rsp),%rax
 29f7404:	mov    (%rax),%rax
 29f7407:	mov    0xa8(%rsp),%rcx
 29f740f:	cmp    %rcx,%rax
 29f7412:	jae    29fbb09 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4f29>
 29f7418:	mov    $0x8000000,%ecx
 29f741d:	mov    0x80(%rsp),%rsi
 29f7425:	sub    $0x8000000,%rsi
 29f742c:	mov    %r15,%rdx
 29f742f:	mov    %rsi,0x80(%rsp)
 29f7437:	sub    $0x8000000,%rdx
 29f743e:	mov    %rdx,%r15
 29f7441:	mov    0x60(%rsp),%rdi
 29f7446:	call   3039aea <wasmtime_builtin_memory_copy>
 29f744b:	mov    0x18(%rsp),%eax
 29f744f:	mov    0x50(%rsp),%ecx
 29f7453:	mov    0x48(%rsp),%edx
 29f7457:	mov    0x40(%rsp),%esi
 29f745b:	mov    0x38(%rsp),%edi
 29f745f:	mov    0x30(%rsp),%r8d
 29f7464:	mov    %r12,%r11
 29f7467:	sub    $0x8000000,%r11
 29f746e:	cmp    $0x8000000,%r11
 29f7475:	jbe    29f7483 <wasm[0]::function[1013]::helper::array_indexed_publish+0x8a3>
 29f747b:	mov    %r11,%r12
 29f747e:	jmp    29f73e3 <wasm[0]::function[1013]::helper::array_indexed_publish+0x803>
 29f7483:	mov    0x80(%rsp),%r9
 29f748b:	sub    %r11,%r9
 29f748e:	mov    %r9,0x80(%rsp)
 29f7496:	mov    %r15,%r9
 29f7499:	sub    %r11,%r9
 29f749c:	mov    %r9,%r15
 29f749f:	mov    %r11,%r12
 29f74a2:	jmp    29f758e <wasm[0]::function[1013]::helper::array_indexed_publish+0x9ae>
 29f74a7:	mov    %r13,%r11
 29f74aa:	mov    0x8(%rsp),%eax
 29f74ae:	mov    0x58(%rsp),%ecx
 29f74b2:	mov    0x10(%rsp),%edx
 29f74b6:	mov    (%rsp),%esi
 29f74b9:	mov    0x20(%rsp),%edi
 29f74bd:	mov    0x28(%rsp),%r8d
 29f74c2:	lea    0x18(%r9,%r10,1),%r10
 29f74c7:	mov    %r10,0x80(%rsp)
 29f74cf:	lea    0x18(%r9,%rbx,1),%r9
 29f74d4:	mov    %r9,%r15
 29f74d7:	cmp    $0x8000000,%r11
 29f74de:	mov    %r11,%r12
 29f74e1:	jbe    29f758e <wasm[0]::function[1013]::helper::array_indexed_publish+0x9ae>
 29f74e7:	mov    %eax,0x28(%rsp)
 29f74eb:	mov    %ecx,0x20(%rsp)
 29f74ef:	mov    %edx,(%rsp)
 29f74f2:	mov    %esi,0x10(%rsp)
 29f74f6:	mov    %edi,0x58(%rsp)
 29f74fa:	mov    %r8d,0x8(%rsp)
 29f74ff:	mov    0xd0(%rsp),%rax
 29f7507:	mov    (%rax),%rax
 29f750a:	mov    0xa8(%rsp),%rsi
 29f7512:	cmp    %rsi,%rax
 29f7515:	jae    29fbb3d <wasm[0]::function[1013]::helper::array_indexed_publish+0x4f5d>
 29f751b:	mov    $0x8000000,%ecx
 29f7520:	mov    %r15,%rdx
 29f7523:	mov    0x80(%rsp),%rsi
 29f752b:	mov    0x60(%rsp),%rdi
 29f7530:	call   3039aea <wasmtime_builtin_memory_copy>
 29f7535:	mov    0x28(%rsp),%eax
 29f7539:	mov    0x20(%rsp),%ecx
 29f753d:	mov    (%rsp),%edx
 29f7540:	mov    0x10(%rsp),%esi
 29f7544:	mov    0x58(%rsp),%edi
 29f7548:	mov    0x8(%rsp),%r8d
 29f754d:	mov    %r12,%r9
 29f7550:	sub    $0x8000000,%r9
 29f7557:	mov    %r9,%r12
 29f755a:	mov    0x80(%rsp),%r9
 29f7562:	add    $0x8000000,%r9
 29f7569:	mov    %r9,0x80(%rsp)
 29f7571:	mov    %r15,%r9
 29f7574:	add    $0x8000000,%r9
 29f757b:	mov    %r9,%r15
 29f757e:	mov    %r12,%r9
 29f7581:	cmp    $0x8000000,%r9
 29f7588:	ja     29f74e7 <wasm[0]::function[1013]::helper::array_indexed_publish+0x907>
 29f758e:	mov    %eax,0x8(%rsp)
 29f7592:	mov    %ecx,0x58(%rsp)
 29f7596:	mov    %edx,0x10(%rsp)
 29f759a:	mov    %esi,(%rsp)
 29f759d:	mov    %edi,0x20(%rsp)
 29f75a1:	mov    %r8d,0x28(%rsp)
 29f75a6:	mov    0xd0(%rsp),%rax
 29f75ae:	mov    (%rax),%rax
 29f75b1:	mov    0xa8(%rsp),%rcx
 29f75b9:	cmp    %rcx,%rax
 29f75bc:	jae    29fbb74 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4f94>
 29f75c2:	mov    %r12,%rcx
 29f75c5:	mov    %r15,%rdx
 29f75c8:	mov    0x80(%rsp),%rsi
 29f75d0:	jmp    29f75e3 <wasm[0]::function[1013]::helper::array_indexed_publish+0xa03>
 29f75d5:	mov    %r12,%rcx
 29f75d8:	mov    %r15,%rdx
 29f75db:	mov    0x80(%rsp),%rsi
 29f75e3:	mov    %r12,%rcx
 29f75e6:	mov    %r15,%rdx
 29f75e9:	mov    0x80(%rsp),%rsi
 29f75f1:	mov    0x60(%rsp),%rdi
 29f75f6:	call   3039aea <wasmtime_builtin_memory_copy>
 29f75fb:	mov    0x8(%rsp),%edx
 29f75ff:	mov    %rdx,%rax
 29f7602:	mov    %rdx,0x70(%rsp)
 29f7607:	test   %eax,%edx
 29f7609:	je     29fc692 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5ab2>
 29f760f:	mov    0x70(%rsp),%rax
 29f7614:	test   %eax,%edx
 29f7616:	je     29fc694 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5ab4>
 29f761c:	mov    0xc8(%rsp),%rbx
 29f7624:	mov    0x28(%rbx),%rax
 29f7628:	mov    %edx,%esi
 29f762a:	mov    %rsi,%rdx
 29f762d:	add    0x20(%rbx),%rdx
 29f7631:	xor    %rdi,%rdi
 29f7634:	cmp    %rax,%rsi
 29f7637:	cmova  %rdi,%rdx
 29f763b:	mov    0x24(%rdx),%eax
 29f763e:	mov    0x10(%rsp),%r8d
 29f7643:	mov    0x58(%rsp),%r9d
 29f7648:	mov    (%rsp),%esi
 29f764b:	mov    %rsi,0x78(%rsp)
 29f7650:	mov    0x20(%rsp),%esi
 29f7654:	mov    0x28(%rsp),%edx
 29f7658:	cmp    $0x2,%eax
 29f765b:	je     29f7670 <wasm[0]::function[1013]::helper::array_indexed_publish+0xa90>
 29f7661:	mov    0x70(%rsp),%rax
 29f7666:	mov    0x70(%rsp),%rcx
 29f766b:	jmp    29f7bb4 <wasm[0]::function[1013]::helper::array_indexed_publish+0xfd4>
 29f7670:	lea    0x3f(%r14),%ebx
 29f7674:	shr    $0x6,%ebx
 29f7677:	mov    %rbx,%rcx
 29f767a:	shl    $0x3,%rcx
 29f767e:	mov    %rcx,%rax
 29f7681:	shr    $0x20,%rax
 29f7685:	mov    %rcx,%r13
 29f7688:	test   %rax,%rax
 29f768b:	jne    29fc696 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5ab6>
 29f7691:	mov    %rbx,%rcx
 29f7694:	shl    $0x3,%ecx
 29f7697:	add    $0x18,%ecx
 29f769a:	jb     29fc698 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5ab8>
 29f76a0:	mov    0xb0(%rsp),%r12
 29f76a8:	mov    (%r12),%eax
 29f76ac:	mov    %eax,%edx
 29f76ae:	mov    %ecx,%esi
 29f76b0:	add    $0xf,%rsi
 29f76b7:	and    $0xfffffffffffffff0,%rsi
 29f76bb:	lea    (%rdx,%rsi,1),%rdi
 29f76bf:	mov    0x4(%r12),%r8d
 29f76c4:	cmp    %r8,%rdi
 29f76c7:	ja     29fbbb6 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4fd6>
 29f76cd:	add    $0xf,%ecx
 29f76d3:	and    $0xfffffff0,%ecx
 29f76d6:	add    %eax,%ecx
 29f76d8:	mov    %ecx,(%r12)
 29f76dc:	mov    0xc8(%rsp),%rcx
 29f76e4:	mov    0x20(%rcx),%rdi
 29f76e8:	lea    (%rdi,%rdx,1),%rcx
 29f76ec:	movl   $0xa8000006,(%rdi,%rdx,1)
 29f76f3:	mov    0x60(%rsp),%r9
 29f76f8:	mov    0x28(%r9),%r8
 29f76fc:	mov    0x1a4(%r8),%r8d
 29f7703:	mov    %r8d,0x4(%rdi,%rdx,1)
 29f7708:	mov    %esi,0x8(%rdi,%rdx,1)
 29f770c:	mov    %eax,0x18(%rsp)
 29f7710:	mov    %ebx,0x10(%rcx)
 29f7713:	test   %eax,%eax
 29f7715:	je     29fc69a <wasm[0]::function[1013]::helper::array_indexed_publish+0x5aba>
 29f771b:	mov    0xc8(%rsp),%rcx
 29f7723:	mov    0x28(%rcx),%rcx
 29f7727:	mov    0xc8(%rsp),%rdx
 29f772f:	mov    0x20(%rdx),%rdx
 29f7733:	mov    %eax,%eax
 29f7735:	lea    0x10(%rdx,%rax,1),%rsi
 29f773a:	xor    %rdi,%rdi
 29f773d:	cmp    %rcx,%rax
 29f7740:	cmova  %rdi,%rsi
 29f7744:	mov    (%rsi),%esi
 29f7746:	cmp    %rsi,%rbx
 29f7749:	ja     29fc69c <wasm[0]::function[1013]::helper::array_indexed_publish+0x5abc>
 29f774f:	lea    0x18(%rdx,%rax,1),%rax
 29f7754:	mov    %r13,%r9
 29f7757:	mov    %rax,%rsi
 29f775a:	add    %r9,%rsi
 29f775d:	mov    %rax,%r12
 29f7760:	jb     29fc69e <wasm[0]::function[1013]::helper::array_indexed_publish+0x5abe>
 29f7766:	lea    (%rdx,%rcx,1),%rdi
 29f776a:	cmp    %rdi,%rsi
 29f776d:	ja     29fc6a0 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5ac0>
 29f7773:	mov    0x58(%rsp),%r8d
 29f7778:	mov    0x8(%rsp),%edi
 29f777c:	mov    0x10(%rsp),%esi
 29f7780:	mov    (%rsp),%edx
 29f7783:	mov    0x20(%rsp),%ecx
 29f7787:	mov    0x28(%rsp),%eax
 29f778b:	cmp    $0x8000000,%r9
 29f7792:	jbe    29f7822 <wasm[0]::function[1013]::helper::array_indexed_publish+0xc42>
 29f7798:	mov    %r8d,0x28(%rsp)
 29f779d:	mov    %edi,0x20(%rsp)
 29f77a1:	mov    %esi,(%rsp)
 29f77a4:	mov    %edx,0x10(%rsp)
 29f77a8:	mov    %ecx,0x8(%rsp)
 29f77ac:	mov    %eax,0x58(%rsp)
 29f77b0:	mov    0xd0(%rsp),%rax
 29f77b8:	mov    (%rax),%rax
 29f77bb:	mov    0xa8(%rsp),%rcx
 29f77c3:	cmp    %rcx,%rax
 29f77c6:	jae    29fbbe8 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5008>
 29f77cc:	xor    %edx,%edx
 29f77ce:	mov    $0x8000000,%ecx
 29f77d3:	mov    %r12,%rsi
 29f77d6:	mov    0x60(%rsp),%rdi
 29f77db:	call   3039b13 <wasmtime_builtin_memory_fill>
 29f77e0:	mov    0x28(%rsp),%r8d
 29f77e5:	mov    0x20(%rsp),%edi
 29f77e9:	mov    (%rsp),%esi
 29f77ec:	mov    0x10(%rsp),%edx
 29f77f0:	mov    0x8(%rsp),%ecx
 29f77f4:	mov    0x58(%rsp),%eax
 29f77f8:	mov    %r13,%r9
 29f77fb:	sub    $0x8000000,%r9
 29f7802:	mov    %r9,%r13
 29f7805:	mov    %r12,%r9
 29f7808:	add    $0x8000000,%r9
 29f780f:	mov    %r9,%r12
 29f7812:	mov    %r13,%r9
 29f7815:	cmp    $0x8000000,%r9
 29f781c:	ja     29f7798 <wasm[0]::function[1013]::helper::array_indexed_publish+0xbb8>
 29f7822:	mov    %r8d,0x58(%rsp)
 29f7827:	mov    %edi,0x8(%rsp)
 29f782b:	mov    %esi,0x10(%rsp)
 29f782f:	mov    %edx,(%rsp)
 29f7832:	mov    %ecx,0x20(%rsp)
 29f7836:	mov    %eax,0x28(%rsp)
 29f783a:	mov    0xd0(%rsp),%rax
 29f7842:	mov    (%rax),%rax
 29f7845:	mov    0xa8(%rsp),%rcx
 29f784d:	cmp    %rcx,%rax
 29f7850:	jae    29fbc1c <wasm[0]::function[1013]::helper::array_indexed_publish+0x503c>
 29f7856:	xor    %edx,%edx
 29f7858:	mov    %r13,%rcx
 29f785b:	mov    %r12,%rsi
 29f785e:	mov    0x60(%rsp),%rdi
 29f7863:	call   3039b13 <wasmtime_builtin_memory_fill>
 29f7868:	mov    0x58(%rsp),%ecx
 29f786c:	test   %ecx,%ecx
 29f786e:	je     29fc6a2 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5ac2>
 29f7874:	test   %ecx,%ecx
 29f7876:	je     29fc6a4 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5ac4>
 29f787c:	mov    0xc8(%rsp),%rbx
 29f7884:	mov    0x28(%rbx),%rax
 29f7888:	mov    0x20(%rbx),%r9
 29f788c:	mov    %ecx,%r10d
 29f788f:	lea    (%r9,%r10,1),%r11
 29f7893:	lea    0x10(%r9,%r10,1),%rdx
 29f7898:	xor    %rcx,%rcx
 29f789b:	cmp    %rax,%r10
 29f789e:	cmova  %rcx,%rdx
 29f78a2:	mov    (%rdx),%edx
 29f78a4:	mov    0x18(%rsp),%esi
 29f78a8:	test   %esi,%esi
 29f78aa:	je     29fc6a6 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5ac6>
 29f78b0:	test   %esi,%esi
 29f78b2:	je     29fc6a8 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5ac8>
 29f78b8:	mov    %esi,%ebx
 29f78ba:	lea    (%r9,%rbx,1),%r12
 29f78be:	lea    0x10(%r9,%rbx,1),%rsi
 29f78c3:	cmp    %rax,%rbx
 29f78c6:	cmova  %rcx,%rsi
 29f78ca:	mov    %edx,%r13d
 29f78cd:	mov    (%rsi),%ecx
 29f78cf:	cmp    %rcx,%r13
 29f78d2:	ja     29fc6aa <wasm[0]::function[1013]::helper::array_indexed_publish+0x5aca>
 29f78d8:	lea    0x18(%r9,%rbx,1),%rcx
 29f78dd:	mov    %r13,%r14
 29f78e0:	shl    $0x3,%r14
 29f78e4:	mov    %rcx,%rdx
 29f78e7:	add    %r14,%rdx
 29f78ea:	jb     29fc6ac <wasm[0]::function[1013]::helper::array_indexed_publish+0x5acc>
 29f78f0:	add    %r9,%rax
 29f78f3:	cmp    %rax,%rdx
 29f78f6:	ja     29fc6ae <wasm[0]::function[1013]::helper::array_indexed_publish+0x5ace>
 29f78fc:	lea    0x18(%r9,%r10,1),%rdx
 29f7901:	mov    %rdx,%rsi
 29f7904:	add    %r14,%rsi
 29f7907:	jb     29fc6b0 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5ad0>
 29f790d:	cmp    %rax,%rsi
 29f7910:	ja     29fc6b2 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5ad2>
 29f7916:	cmp    %rcx,%rdx
 29f7919:	ja     29f7a12 <wasm[0]::function[1013]::helper::array_indexed_publish+0xe32>
 29f791f:	mov    0x8(%rsp),%eax
 29f7923:	mov    0x18(%rsp),%ecx
 29f7927:	mov    0x10(%rsp),%edx
 29f792b:	mov    (%rsp),%esi
 29f792e:	mov    0x20(%rsp),%edi
 29f7932:	mov    0x28(%rsp),%r8d
 29f7937:	lea    0x18(%r12,%r13,8),%r9
 29f793c:	mov    %r9,%r15
 29f793f:	lea    0x18(%r11,%r13,8),%r9
 29f7944:	mov    %r9,%r13
 29f7947:	cmp    $0x8000000,%r14
 29f794e:	mov    %r14,%r12
 29f7951:	ja     29f7962 <wasm[0]::function[1013]::helper::array_indexed_publish+0xd82>
 29f7957:	mov    %r15,%r9
 29f795a:	mov    %r12,%r11
 29f795d:	jmp    29f79fb <wasm[0]::function[1013]::helper::array_indexed_publish+0xe1b>
 29f7962:	mov    %eax,0x30(%rsp)
 29f7966:	mov    %ecx,0x38(%rsp)
 29f796a:	mov    %edx,0x40(%rsp)
 29f796e:	mov    %esi,0x48(%rsp)
 29f7972:	mov    %edi,0x50(%rsp)
 29f7976:	mov    %r8d,0x58(%rsp)
 29f797b:	mov    0xd0(%rsp),%rax
 29f7983:	mov    (%rax),%r8
 29f7986:	mov    0xa8(%rsp),%rax
 29f798e:	cmp    %rax,%r8
 29f7991:	jae    29fbc50 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5070>
 29f7997:	mov    $0x8000000,%ecx
 29f799c:	mov    %r15,%rsi
 29f799f:	sub    $0x8000000,%rsi
 29f79a6:	mov    %r13,%rdx
 29f79a9:	mov    %rsi,%r15
 29f79ac:	sub    $0x8000000,%rdx
 29f79b3:	mov    %rdx,%r13
 29f79b6:	mov    0x60(%rsp),%rdi
 29f79bb:	call   3039aea <wasmtime_builtin_memory_copy>
 29f79c0:	mov    0x30(%rsp),%eax
 29f79c4:	mov    0x38(%rsp),%ecx
 29f79c8:	mov    0x40(%rsp),%edx
 29f79cc:	mov    0x48(%rsp),%esi
 29f79d0:	mov    0x50(%rsp),%edi
 29f79d4:	mov    0x58(%rsp),%r8d
 29f79d9:	mov    %r12,%r11
 29f79dc:	sub    $0x8000000,%r11
 29f79e3:	cmp    $0x8000000,%r11
 29f79ea:	jbe    29f79f8 <wasm[0]::function[1013]::helper::array_indexed_publish+0xe18>
 29f79f0:	mov    %r11,%r12
 29f79f3:	jmp    29f7962 <wasm[0]::function[1013]::helper::array_indexed_publish+0xd82>
 29f79f8:	mov    %r15,%r9
 29f79fb:	sub    %r11,%r9
 29f79fe:	mov    %r9,%r15
 29f7a01:	mov    %r13,%r9
 29f7a04:	sub    %r11,%r9
 29f7a07:	mov    %r9,%r13
 29f7a0a:	mov    %r11,%r12
 29f7a0d:	jmp    29f7ae5 <wasm[0]::function[1013]::helper::array_indexed_publish+0xf05>
 29f7a12:	mov    %r14,%r11
 29f7a15:	mov    0x8(%rsp),%eax
 29f7a19:	mov    0x18(%rsp),%ecx
 29f7a1d:	mov    0x10(%rsp),%edx
 29f7a21:	mov    (%rsp),%esi
 29f7a24:	mov    0x20(%rsp),%edi
 29f7a28:	mov    0x28(%rsp),%r8d
 29f7a2d:	lea    0x18(%r9,%rbx,1),%rbx
 29f7a32:	mov    %rbx,%r15
 29f7a35:	lea    0x18(%r9,%r10,1),%r9
 29f7a3a:	mov    %r9,%r13
 29f7a3d:	cmp    $0x8000000,%r11
 29f7a44:	mov    %r11,%r12
 29f7a47:	jbe    29f7ae5 <wasm[0]::function[1013]::helper::array_indexed_publish+0xf05>
 29f7a4d:	mov    %eax,0x28(%rsp)
 29f7a51:	mov    %ecx,0x20(%rsp)
 29f7a55:	mov    %edx,(%rsp)
 29f7a58:	mov    %esi,0x10(%rsp)
 29f7a5c:	mov    %edi,0x18(%rsp)
 29f7a60:	mov    %r8d,0x8(%rsp)
 29f7a65:	mov    0xd0(%rsp),%rax
 29f7a6d:	mov    (%rax),%rax
 29f7a70:	mov    0xa8(%rsp),%rcx
 29f7a78:	cmp    %rcx,%rax
 29f7a7b:	jae    29fbc84 <wasm[0]::function[1013]::helper::array_indexed_publish+0x50a4>
 29f7a81:	mov    $0x8000000,%ecx
 29f7a86:	mov    %r13,%rdx
 29f7a89:	mov    %r15,%rsi
 29f7a8c:	mov    0x60(%rsp),%rdi
 29f7a91:	call   3039aea <wasmtime_builtin_memory_copy>
 29f7a96:	mov    0x28(%rsp),%eax
 29f7a9a:	mov    0x20(%rsp),%ecx
 29f7a9e:	mov    (%rsp),%edx
 29f7aa1:	mov    0x10(%rsp),%esi
 29f7aa5:	mov    0x18(%rsp),%edi
 29f7aa9:	mov    0x8(%rsp),%r8d
 29f7aae:	mov    %r12,%r9
 29f7ab1:	sub    $0x8000000,%r9
 29f7ab8:	mov    %r9,%r12
 29f7abb:	mov    %r15,%r9
 29f7abe:	add    $0x8000000,%r9
 29f7ac5:	mov    %r9,%r15
 29f7ac8:	mov    %r13,%r9
 29f7acb:	add    $0x8000000,%r9
 29f7ad2:	mov    %r9,%r13
 29f7ad5:	mov    %r12,%r9
 29f7ad8:	cmp    $0x8000000,%r9
 29f7adf:	ja     29f7a4d <wasm[0]::function[1013]::helper::array_indexed_publish+0xe6d>
 29f7ae5:	mov    %eax,0x8(%rsp)
 29f7ae9:	mov    %ecx,0x18(%rsp)
 29f7aed:	mov    %edx,0x10(%rsp)
 29f7af1:	mov    %esi,(%rsp)
 29f7af4:	mov    %edi,0x20(%rsp)
 29f7af8:	mov    %r8d,0x28(%rsp)
 29f7afd:	mov    0xd0(%rsp),%rax
 29f7b05:	mov    (%rax),%rax
 29f7b08:	mov    0xa8(%rsp),%rcx
 29f7b10:	cmp    %rcx,%rax
 29f7b13:	jae    29fbcbb <wasm[0]::function[1013]::helper::array_indexed_publish+0x50db>
 29f7b19:	mov    %r12,%rcx
 29f7b1c:	mov    %r13,%rdx
 29f7b1f:	mov    %r15,%rsi
 29f7b22:	jmp    29f7b30 <wasm[0]::function[1013]::helper::array_indexed_publish+0xf50>
 29f7b27:	mov    %r12,%rcx
 29f7b2a:	mov    %r13,%rdx
 29f7b2d:	mov    %r15,%rsi
 29f7b30:	mov    %r12,%rcx
 29f7b33:	mov    %r13,%rdx
 29f7b36:	mov    %r15,%rsi
 29f7b39:	mov    0x60(%rsp),%rdi
 29f7b3e:	call   3039aea <wasmtime_builtin_memory_copy>
 29f7b43:	mov    0x8(%rsp),%edx
 29f7b47:	mov    %rdx,%rax
 29f7b4a:	mov    %rdx,0x70(%rsp)
 29f7b4f:	test   %eax,%edx
 29f7b51:	je     29fc6b4 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5ad4>
 29f7b57:	mov    0x18(%rsp),%r9d
 29f7b5c:	test   %r9d,%r9d
 29f7b5f:	je     29fc6b6 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5ad6>
 29f7b65:	mov    0x70(%rsp),%rax
 29f7b6a:	test   %eax,%edx
 29f7b6c:	je     29fc6b8 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5ad8>
 29f7b72:	mov    0xc8(%rsp),%rbx
 29f7b7a:	mov    0x28(%rbx),%rax
 29f7b7e:	mov    %edx,%esi
 29f7b80:	mov    %rsi,%rdx
 29f7b83:	add    0x20(%rbx),%rdx
 29f7b87:	xor    %rdi,%rdi
 29f7b8a:	cmp    %rax,%rsi
 29f7b8d:	cmova  %rdi,%rdx
 29f7b91:	mov    %r9d,0x2c(%rdx)
 29f7b95:	mov    0x10(%rsp),%r8d
 29f7b9a:	mov    (%rsp),%esi
 29f7b9d:	mov    %rsi,0x78(%rsp)
 29f7ba2:	mov    0x20(%rsp),%esi
 29f7ba6:	mov    0x28(%rsp),%edx
 29f7baa:	mov    0x70(%rsp),%rax
 29f7baf:	mov    0x70(%rsp),%rcx
 29f7bb4:	test   %ecx,%eax
 29f7bb6:	je     29fc6ba <wasm[0]::function[1013]::helper::array_indexed_publish+0x5ada>
 29f7bbc:	test   %r8d,%r8d
 29f7bbf:	je     29fc6bc <wasm[0]::function[1013]::helper::array_indexed_publish+0x5adc>
 29f7bc5:	mov    0x70(%rsp),%rax
 29f7bca:	mov    0x70(%rsp),%rcx
 29f7bcf:	test   %ecx,%eax
 29f7bd1:	je     29fc6be <wasm[0]::function[1013]::helper::array_indexed_publish+0x5ade>
 29f7bd7:	mov    0xc8(%rsp),%rbx
 29f7bdf:	mov    0x28(%rbx),%r10
 29f7be3:	mov    %eax,%eax
 29f7be5:	mov    %rax,%r11
 29f7be8:	add    0x20(%rbx),%r11
 29f7bec:	xor    %r12,%r12
 29f7bef:	cmp    %r10,%rax
 29f7bf2:	cmova  %r12,%r11
 29f7bf6:	mov    %r8d,0x28(%r11)
 29f7bfa:	mov    0x70(%rsp),%rax
 29f7bff:	mov    %eax,0x20(%rsp)
 29f7c03:	mov    %r8d,(%rsp)
 29f7c07:	mov    0x78(%rsp),%rax
 29f7c0c:	mov    %eax,0x18(%rsp)
 29f7c10:	mov    %esi,0x10(%rsp)
 29f7c14:	mov    %edx,0x8(%rsp)
 29f7c18:	mov    0x68(%rsp),%rcx
 29f7c1d:	mov    0x88(%rsp),%r10
 29f7c25:	cmp    %r10,%rcx
 29f7c28:	ja     29f7c3d <wasm[0]::function[1013]::helper::array_indexed_publish+0x105d>
 29f7c2e:	mov    0x70(%rsp),%rax
 29f7c33:	mov    0x70(%rsp),%rcx
 29f7c38:	jmp    29f80ea <wasm[0]::function[1013]::helper::array_indexed_publish+0x150a>
 29f7c3d:	mov    0x70(%rsp),%rax
 29f7c42:	mov    0x70(%rsp),%rcx
 29f7c47:	test   %ecx,%eax
 29f7c49:	je     29fc6c0 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5ae0>
 29f7c4f:	test   %ecx,%eax
 29f7c51:	je     29fc6c2 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5ae2>
 29f7c57:	mov    0xc8(%rsp),%rbx
 29f7c5f:	mov    0x28(%rbx),%rax
 29f7c63:	mov    %ecx,%r11d
 29f7c66:	mov    %r11,%r10
 29f7c69:	add    0x20(%rbx),%r10
 29f7c6d:	xor    %rbx,%rbx
 29f7c70:	cmp    %rax,%r11
 29f7c73:	cmova  %rbx,%r10
 29f7c77:	mov    0x24(%r10),%eax
 29f7c7b:	cmp    $0x4,%eax
 29f7c7e:	jne    29f80e0 <wasm[0]::function[1013]::helper::array_indexed_publish+0x1500>
 29f7c84:	mov    (%rsp),%eax
 29f7c87:	test   %eax,%eax
 29f7c89:	je     29fc6c4 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5ae4>
 29f7c8f:	test   %eax,%eax
 29f7c91:	je     29fc6c6 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5ae6>
 29f7c97:	mov    0xc8(%rsp),%rbx
 29f7c9f:	mov    0x28(%rbx),%rcx
 29f7ca3:	mov    0x20(%rbx),%rsi
 29f7ca7:	mov    %eax,%edx
 29f7ca9:	lea    0x10(%rsi,%rdx,1),%rax
 29f7cae:	xor    %rsi,%rsi
 29f7cb1:	cmp    %rcx,%rdx
 29f7cb4:	cmova  %rsi,%rax
 29f7cb8:	mov    (%rax),%eax
 29f7cba:	lea    0x3f(%rax),%ebx
 29f7cbd:	shr    $0x6,%ebx
 29f7cc0:	mov    %rbx,%rcx
 29f7cc3:	shl    $0x3,%rcx
 29f7cc7:	mov    %rcx,%rax
 29f7cca:	shr    $0x20,%rax
 29f7cce:	mov    %rcx,%r13
 29f7cd1:	test   %rax,%rax
 29f7cd4:	jne    29fc6c8 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5ae8>
 29f7cda:	mov    %rbx,%rcx
 29f7cdd:	shl    $0x3,%ecx
 29f7ce0:	add    $0x18,%ecx
 29f7ce3:	jb     29fc6ca <wasm[0]::function[1013]::helper::array_indexed_publish+0x5aea>
 29f7ce9:	mov    0x60(%rsp),%rdi
 29f7cee:	mov    0x20(%rdi),%rdi
 29f7cf2:	mov    (%rdi),%eax
 29f7cf4:	mov    %eax,%edx
 29f7cf6:	mov    %ecx,%esi
 29f7cf8:	add    $0xf,%rsi
 29f7cff:	mov    %rsi,%r8
 29f7d02:	and    $0xfffffffffffffff0,%r8
 29f7d06:	add    %rdx,%r8
 29f7d09:	mov    0x4(%rdi),%r9d
 29f7d0d:	cmp    %r9,%r8
 29f7d10:	ja     29fbcf8 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5118>
 29f7d16:	add    $0xf,%ecx
 29f7d1c:	and    $0xfffffff0,%ecx
 29f7d1f:	add    %eax,%ecx
 29f7d21:	mov    %ecx,(%rdi)
 29f7d23:	mov    0xc8(%rsp),%rcx
 29f7d2b:	mov    0x20(%rcx),%rdi
 29f7d2f:	lea    (%rdi,%rdx,1),%rcx
 29f7d33:	movl   $0xa8000006,(%rdi,%rdx,1)
 29f7d3a:	mov    0x60(%rsp),%r8
 29f7d3f:	mov    0x28(%r8),%r8
 29f7d43:	mov    0x1a4(%r8),%r8d
 29f7d4a:	mov    %r8d,0x4(%rdi,%rdx,1)
 29f7d4f:	and    $0xfffffffffffffff0,%rsi
 29f7d53:	mov    %esi,0x8(%rdi,%rdx,1)
 29f7d57:	mov    %eax,0x28(%rsp)
 29f7d5b:	mov    %ebx,0x10(%rcx)
 29f7d5e:	test   %eax,%eax
 29f7d60:	je     29fc6cc <wasm[0]::function[1013]::helper::array_indexed_publish+0x5aec>
 29f7d66:	mov    0xc8(%rsp),%rcx
 29f7d6e:	mov    0x28(%rcx),%rcx
 29f7d72:	mov    0xc8(%rsp),%rdx
 29f7d7a:	mov    0x20(%rdx),%rdx
 29f7d7e:	mov    %eax,%eax
 29f7d80:	lea    0x10(%rdx,%rax,1),%rsi
 29f7d85:	xor    %rdi,%rdi
 29f7d88:	cmp    %rcx,%rax
 29f7d8b:	cmova  %rdi,%rsi
 29f7d8f:	mov    (%rsi),%esi
 29f7d91:	cmp    %rsi,%rbx
 29f7d94:	ja     29fc6ce <wasm[0]::function[1013]::helper::array_indexed_publish+0x5aee>
 29f7d9a:	lea    0x18(%rdx,%rax,1),%rsi
 29f7d9f:	mov    %r13,%r8
 29f7da2:	mov    %rsi,%rax
 29f7da5:	add    %r8,%rax
 29f7da8:	mov    %rsi,%r14
 29f7dab:	jb     29fc6d0 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5af0>
 29f7db1:	add    %rdx,%rcx
 29f7db4:	cmp    %rcx,%rax
 29f7db7:	ja     29fc6d2 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5af2>
 29f7dbd:	mov    0x20(%rsp),%edi
 29f7dc1:	mov    (%rsp),%esi
 29f7dc4:	mov    0x18(%rsp),%edx
 29f7dc8:	mov    0x10(%rsp),%ecx
 29f7dcc:	mov    0x8(%rsp),%eax
 29f7dd0:	mov    $0x8000000,%ebx
 29f7dd5:	cmp    $0x8000000,%r8
 29f7ddc:	jbe    29f7e60 <wasm[0]::function[1013]::helper::array_indexed_publish+0x1280>
 29f7de2:	mov    %edi,0x8(%rsp)
 29f7de6:	mov    %esi,0x10(%rsp)
 29f7dea:	mov    %edx,0x18(%rsp)
 29f7dee:	mov    %ecx,(%rsp)
 29f7df1:	mov    %eax,0x20(%rsp)
 29f7df5:	mov    0xd0(%rsp),%rax
 29f7dfd:	mov    (%rax),%rax
 29f7e00:	mov    0xa8(%rsp),%r11
 29f7e08:	cmp    %r11,%rax
 29f7e0b:	jae    29fbd2a <wasm[0]::function[1013]::helper::array_indexed_publish+0x514a>
 29f7e11:	xor    %edx,%edx
 29f7e13:	mov    %rbx,%rcx
 29f7e16:	mov    %r14,%rsi
 29f7e19:	mov    0x60(%rsp),%rdi
 29f7e1e:	call   3039b13 <wasmtime_builtin_memory_fill>
 29f7e23:	mov    0x8(%rsp),%edi
 29f7e27:	mov    0x10(%rsp),%esi
 29f7e2b:	mov    0x18(%rsp),%edx
 29f7e2f:	mov    (%rsp),%ecx
 29f7e32:	mov    0x20(%rsp),%eax
 29f7e36:	mov    %r13,%r8
 29f7e39:	sub    $0x8000000,%r8
 29f7e40:	mov    %r8,%r13
 29f7e43:	mov    %r14,%r8
 29f7e46:	add    $0x8000000,%r8
 29f7e4d:	mov    %r8,%r14
 29f7e50:	mov    %r13,%r8
 29f7e53:	cmp    $0x8000000,%r8
 29f7e5a:	ja     29f7de2 <wasm[0]::function[1013]::helper::array_indexed_publish+0x1202>
 29f7e60:	mov    %edi,0x20(%rsp)
 29f7e64:	mov    %esi,(%rsp)
 29f7e67:	mov    %edx,0x18(%rsp)
 29f7e6b:	mov    %ecx,0x10(%rsp)
 29f7e6f:	mov    %eax,0x8(%rsp)
 29f7e73:	mov    0xd0(%rsp),%rax
 29f7e7b:	mov    (%rax),%rax
 29f7e7e:	mov    0xa8(%rsp),%rcx
 29f7e86:	cmp    %rcx,%rax
 29f7e89:	jae    29fbd5e <wasm[0]::function[1013]::helper::array_indexed_publish+0x517e>
 29f7e8f:	xor    %r12d,%r12d
 29f7e92:	mov    %r13,%rcx
 29f7e95:	mov    %r14,%rsi
 29f7e98:	mov    %r12,%rdx
 29f7e9b:	mov    0x60(%rsp),%rdi
 29f7ea0:	call   3039b13 <wasmtime_builtin_memory_fill>
 29f7ea5:	mov    0x20(%rsp),%ecx
 29f7ea9:	mov    (%rsp),%edx
 29f7eac:	mov    0x18(%rsp),%esi
 29f7eb0:	mov    0x10(%rsp),%edi
 29f7eb4:	mov    0x8(%rsp),%r8d
 29f7eb9:	mov    0x88(%rsp),%r13
 29f7ec1:	mov    %r13,%rbx
 29f7ec4:	shr    $0x6,%rbx
 29f7ec8:	mov    %ecx,0x8(%rsp)
 29f7ecc:	mov    %edx,0x10(%rsp)
 29f7ed0:	mov    %esi,0x18(%rsp)
 29f7ed4:	mov    %edi,(%rsp)
 29f7ed7:	mov    %r8d,0x20(%rsp)
 29f7edc:	mov    0xd0(%rsp),%rax
 29f7ee4:	mov    (%rax),%rcx
 29f7ee7:	mov    0xa8(%rsp),%rax
 29f7eef:	cmp    %rax,%rcx
 29f7ef2:	jae    29fbd92 <wasm[0]::function[1013]::helper::array_indexed_publish+0x51b2>
 29f7ef8:	cmp    %ebx,%r12d
 29f7efb:	jae    29f7fb2 <wasm[0]::function[1013]::helper::array_indexed_publish+0x13d2>
 29f7f01:	mov    0x28(%rsp),%ecx
 29f7f05:	test   %ecx,%ecx
 29f7f07:	je     29fc6d4 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5af4>
 29f7f0d:	test   %ecx,%ecx
 29f7f0f:	je     29fc6d6 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5af6>
 29f7f15:	mov    0xc8(%rsp),%rax
 29f7f1d:	mov    0x28(%rax),%rdx
 29f7f21:	mov    0x20(%rax),%rsi
 29f7f25:	mov    %ecx,%r9d
 29f7f28:	lea    0x10(%rsi,%r9,1),%r8
 29f7f2d:	xor    %rdi,%rdi
 29f7f30:	cmp    %rdx,%r9
 29f7f33:	cmova  %rdi,%r8
 29f7f37:	mov    (%r8),%r8d
 29f7f3a:	cmp    %r8d,%r12d
 29f7f3d:	jae    29fc6d8 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5af8>
 29f7f43:	mov    %r8d,%r9d
 29f7f46:	shl    $0x3,%r9
 29f7f4a:	shr    $0x20,%r9
 29f7f4e:	test   %r9,%r9
 29f7f51:	jne    29fc6da <wasm[0]::function[1013]::helper::array_indexed_publish+0x5afa>
 29f7f57:	shl    $0x3,%r8d
 29f7f5b:	add    $0x18,%r8d
 29f7f5f:	jb     29fc6dc <wasm[0]::function[1013]::helper::array_indexed_publish+0x5afc>
 29f7f65:	add    %r8d,%ecx
 29f7f68:	jb     29fc6de <wasm[0]::function[1013]::helper::array_indexed_publish+0x5afe>
 29f7f6e:	mov    %ecx,%r9d
 29f7f71:	lea    (%rsi,%r9,1),%rcx
 29f7f75:	cmp    %rdx,%r9
 29f7f78:	cmova  %rdi,%rcx
 29f7f7c:	mov    %r12,%rax
 29f7f7f:	shl    $0x3,%eax
 29f7f82:	lea    0x18(%rax),%edx
 29f7f85:	sub    %edx,%r8d
 29f7f88:	sub    %r8,%rcx
 29f7f8b:	movq   $0xffffffffffffffff,(%rcx)
 29f7f92:	mov    0x8(%rsp),%ecx
 29f7f96:	mov    0x10(%rsp),%edx
 29f7f9a:	mov    0x18(%rsp),%esi
 29f7f9e:	mov    (%rsp),%edi
 29f7fa1:	mov    0x20(%rsp),%r8d
 29f7fa6:	add    $0x1,%r12d
 29f7fad:	jmp    29f7ec8 <wasm[0]::function[1013]::helper::array_indexed_publish+0x12e8>
 29f7fb2:	mov    0x88(%rsp),%r13
 29f7fba:	test   $0x3f,%r13
 29f7fc1:	je     29f8070 <wasm[0]::function[1013]::helper::array_indexed_publish+0x1490>
 29f7fc7:	mov    0x28(%rsp),%r10d
 29f7fcc:	test   %r10d,%r10d
 29f7fcf:	je     29fc6e0 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5b00>
 29f7fd5:	test   %r10d,%r10d
 29f7fd8:	je     29fc6e2 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5b02>
 29f7fde:	mov    0xc8(%rsp),%rsi
 29f7fe6:	mov    0x28(%rsi),%rdx
 29f7fea:	mov    0x20(%rsi),%rsi
 29f7fee:	mov    %r10d,%r9d
 29f7ff1:	lea    0x10(%rsi,%r9,1),%r8
 29f7ff6:	xor    %rdi,%rdi
 29f7ff9:	cmp    %rdx,%r9
 29f7ffc:	cmova  %rdi,%r8
 29f8000:	mov    (%r8),%r8d
 29f8003:	cmp    %r8d,%ebx
 29f8006:	jae    29fc6e4 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5b04>
 29f800c:	mov    %r8d,%r9d
 29f800f:	shl    $0x3,%r9
 29f8013:	shr    $0x20,%r9
 29f8017:	test   %r9,%r9
 29f801a:	jne    29fc6e6 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5b06>
 29f8020:	shl    $0x3,%r8d
 29f8024:	add    $0x18,%r8d
 29f8028:	jb     29fc6e8 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5b08>
 29f802e:	add    %r8d,%r10d
 29f8031:	jb     29fc6ea <wasm[0]::function[1013]::helper::array_indexed_publish+0x5b0a>
 29f8037:	mov    $0x1,%r9d
 29f803d:	mov    0x88(%rsp),%r13
 29f8045:	mov    %r13,%rcx
 29f8048:	and    $0x3f,%rcx
 29f804c:	shl    %cl,%r9
 29f804f:	sub    $0x1,%r9
 29f8053:	mov    %r10d,%r10d
 29f8056:	lea    (%rsi,%r10,1),%rcx
 29f805a:	cmp    %rdx,%r10
 29f805d:	cmova  %rdi,%rcx
 29f8061:	shl    $0x3,%ebx
 29f8064:	lea    0x18(%rbx),%esi
 29f8067:	sub    %esi,%r8d
 29f806a:	sub    %r8,%rcx
 29f806d:	mov    %r9,(%rcx)
 29f8070:	mov    0x8(%rsp),%edx
 29f8074:	mov    %rdx,%rax
 29f8077:	mov    %rdx,0x70(%rsp)
 29f807c:	test   %eax,%edx
 29f807e:	je     29fc6ec <wasm[0]::function[1013]::helper::array_indexed_publish+0x5b0c>
 29f8084:	mov    0x28(%rsp),%r9d
 29f8089:	test   %r9d,%r9d
 29f808c:	je     29fc6ee <wasm[0]::function[1013]::helper::array_indexed_publish+0x5b0e>
 29f8092:	mov    0x70(%rsp),%rsi
 29f8097:	test   %esi,%edx
 29f8099:	je     29fc6f0 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5b10>
 29f809f:	mov    0xc8(%rsp),%rbx
 29f80a7:	mov    0x28(%rbx),%rax
 29f80ab:	mov    0x20(%rbx),%rsi
 29f80af:	mov    %edx,%edx
 29f80b1:	lea    (%rsi,%rdx,1),%r11
 29f80b5:	xor    %rsi,%rsi
 29f80b8:	cmp    %rax,%rdx
 29f80bb:	cmova  %rsi,%r11
 29f80bf:	mov    %r9d,0x2c(%r11)
 29f80c3:	movl   $0x2,0x24(%r11)
 29f80cb:	mov    0x10(%rsp),%r8d
 29f80d0:	mov    0x18(%rsp),%esi
 29f80d4:	mov    %rsi,0x78(%rsp)
 29f80d9:	mov    (%rsp),%esi
 29f80dc:	mov    0x20(%rsp),%edx
 29f80e0:	mov    0x70(%rsp),%rax
 29f80e5:	mov    0x70(%rsp),%rcx
 29f80ea:	test   %ecx,%eax
 29f80ec:	je     29fc6f2 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5b12>
 29f80f2:	mov    0x70(%rsp),%rax
 29f80f7:	mov    0x70(%rsp),%rcx
 29f80fc:	test   %ecx,%eax
 29f80fe:	je     29fc6f4 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5b14>
 29f8104:	mov    0xc8(%rsp),%rbx
 29f810c:	mov    0x28(%rbx),%r10
 29f8110:	mov    %eax,%eax
 29f8112:	mov    %rax,%r11
 29f8115:	add    0x20(%rbx),%r11
 29f8119:	xor    %rbx,%rbx
 29f811c:	cmp    %r10,%rax
 29f811f:	cmova  %rbx,%r11
 29f8123:	mov    0x24(%r11),%ecx
 29f8127:	cmp    $0x4,%ecx
 29f812a:	je     29f82cb <wasm[0]::function[1013]::helper::array_indexed_publish+0x16eb>
 29f8130:	test   %r9d,%r9d
 29f8133:	je     29fc6f6 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5b16>
 29f8139:	test   %r9d,%r9d
 29f813c:	je     29fc6f8 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5b18>
 29f8142:	mov    0xc8(%rsp),%rbx
 29f814a:	mov    0x28(%rbx),%rbx
 29f814e:	mov    0xc8(%rsp),%rcx
 29f8156:	mov    0x20(%rcx),%r12
 29f815a:	mov    %r9d,%r10d
 29f815d:	lea    0x10(%r12,%r10,1),%r11
 29f8162:	xor    %r13,%r13
 29f8165:	cmp    %rbx,%r10
 29f8168:	cmova  %r13,%r11
 29f816c:	mov    (%r11),%r14d
 29f816f:	mov    0x68(%rsp),%rcx
 29f8174:	mov    %rcx,%r11
 29f8177:	shr    $0x6,%r11d
 29f817b:	cmp    %r14d,%r11d
 29f817e:	jae    29fc6fa <wasm[0]::function[1013]::helper::array_indexed_publish+0x5b1a>
 29f8184:	mov    %r14d,%r15d
 29f8187:	shl    $0x3,%r15
 29f818b:	shr    $0x20,%r15
 29f818f:	test   %r15,%r15
 29f8192:	jne    29fc6fc <wasm[0]::function[1013]::helper::array_indexed_publish+0x5b1c>
 29f8198:	shl    $0x3,%r14d
 29f819c:	add    $0x18,%r14d
 29f81a0:	jb     29fc6fe <wasm[0]::function[1013]::helper::array_indexed_publish+0x5b1e>
 29f81a6:	mov    %r9,%r15
 29f81a9:	add    %r14d,%r15d
 29f81ac:	jb     29fc700 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5b20>
 29f81b2:	mov    %r15d,%edi
 29f81b5:	lea    (%r12,%rdi,1),%r15
 29f81b9:	cmp    %rbx,%rdi
 29f81bc:	cmova  %r13,%r15
 29f81c0:	mov    %r11,%rdi
 29f81c3:	shl    $0x3,%edi
 29f81c6:	mov    %rdi,%rbx
 29f81c9:	lea    0x18(%rbx),%edi
 29f81cc:	mov    %rbx,0x80(%rsp)
 29f81d4:	sub    %edi,%r14d
 29f81d7:	sub    %r14,%r15
 29f81da:	mov    (%r15),%r13
 29f81dd:	mov    $0x1,%r14d
 29f81e3:	shl    %cl,%r14
 29f81e6:	bt     %rcx,%r13
 29f81ea:	jae    29f81fd <wasm[0]::function[1013]::helper::array_indexed_publish+0x161d>
 29f81f0:	mov    0xc8(%rsp),%rbx
 29f81f8:	jmp    29f824a <wasm[0]::function[1013]::helper::array_indexed_publish+0x166a>
 29f81fd:	mov    0xc8(%rsp),%rbx
 29f8205:	mov    0x28(%rbx),%rbx
 29f8209:	mov    0x88(%rsp),%rcx
 29f8211:	lea    0x1(%rcx),%rdi
 29f8215:	mov    %rdi,0x88(%rsp)
 29f821d:	mov    0xc8(%rsp),%rdi
 29f8225:	mov    %rax,%r15
 29f8228:	add    0x20(%rdi),%r15
 29f822c:	xor    %r12,%r12
 29f822f:	cmp    %rbx,%rax
 29f8232:	cmova  %r12,%r15
 29f8236:	mov    0x88(%rsp),%rax
 29f823e:	mov    %rax,0x18(%r15)
 29f8242:	mov    0xc8(%rsp),%rbx
 29f824a:	mov    0xc8(%rsp),%rbx
 29f8252:	mov    0x28(%rbx),%rax
 29f8256:	mov    0x20(%rbx),%r15
 29f825a:	lea    0x10(%r15,%r10,1),%r12
 29f825f:	xor    %rbx,%rbx
 29f8262:	cmp    %rax,%r10
 29f8265:	cmova  %rbx,%r12
 29f8269:	mov    (%r12),%r10d
 29f826d:	cmp    %r10d,%r11d
 29f8270:	jae    29fc702 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5b22>
 29f8276:	mov    %r10d,%r11d
 29f8279:	shl    $0x3,%r11
 29f827d:	shr    $0x20,%r11
 29f8281:	test   %r11,%r11
 29f8284:	jne    29fc704 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5b24>
 29f828a:	shl    $0x3,%r10d
 29f828e:	add    $0x18,%r10d
 29f8292:	jb     29fc706 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5b26>
 29f8298:	add    %r10d,%r9d
 29f829b:	jb     29fc708 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5b28>
 29f82a1:	or     %r14,%r13
 29f82a4:	mov    %r9d,%edi
 29f82a7:	lea    (%r15,%rdi,1),%r9
 29f82ab:	cmp    %rax,%rdi
 29f82ae:	cmova  %rbx,%r9
 29f82b2:	mov    0x80(%rsp),%rdi
 29f82ba:	lea    0x18(%rdi),%eax
 29f82bd:	sub    %eax,%r10d
 29f82c0:	sub    %r10,%r9
 29f82c3:	mov    %r13,(%r9)
 29f82c6:	jmp    29f8319 <wasm[0]::function[1013]::helper::array_indexed_publish+0x1739>
 29f82cb:	mov    0x68(%rsp),%rcx
 29f82d0:	mov    0x88(%rsp),%r13
 29f82d8:	cmp    %r13,%rcx
 29f82db:	jne    29f8319 <wasm[0]::function[1013]::helper::array_indexed_publish+0x1739>
 29f82e1:	mov    0xc8(%rsp),%rbx
 29f82e9:	mov    0x28(%rbx),%r9
 29f82ed:	mov    0x88(%rsp),%r13
 29f82f5:	add    $0x1,%r13
 29f82fc:	mov    %r13,0x88(%rsp)
 29f8304:	mov    %rax,%r10
 29f8307:	add    0x20(%rbx),%r10
 29f830b:	xor    %r11,%r11
 29f830e:	cmp    %r9,%rax
 29f8311:	cmova  %r11,%r10
 29f8315:	mov    %r13,0x18(%r10)
 29f8319:	test   %r8d,%r8d
 29f831c:	je     29fc70a <wasm[0]::function[1013]::helper::array_indexed_publish+0x5b2a>
 29f8322:	test   %r8d,%r8d
 29f8325:	je     29fc70c <wasm[0]::function[1013]::helper::array_indexed_publish+0x5b2c>
 29f832b:	mov    0xc8(%rsp),%rbx
 29f8333:	mov    0x28(%rbx),%r9
 29f8337:	mov    0x20(%rbx),%r10
 29f833b:	mov    %r8d,%ebx
 29f833e:	lea    0x10(%r10,%rbx,1),%rax
 29f8343:	xor    %r11,%r11
 29f8346:	cmp    %r9,%rbx
 29f8349:	cmova  %r11,%rax
 29f834d:	mov    (%rax),%eax
 29f834f:	mov    0x68(%rsp),%rcx
 29f8354:	cmp    %eax,%ecx
 29f8356:	jae    29fc70e <wasm[0]::function[1013]::helper::array_indexed_publish+0x5b2e>
 29f835c:	mov    %eax,%ebx
 29f835e:	shl    $0x3,%rbx
 29f8362:	shr    $0x20,%rbx
 29f8366:	test   %rbx,%rbx
 29f8369:	jne    29fc710 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5b30>
 29f836f:	shl    $0x3,%eax
 29f8372:	add    $0x18,%eax
 29f8375:	jb     29fc712 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5b32>
 29f837b:	add    %eax,%r8d
 29f837e:	jb     29fc714 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5b34>
 29f8384:	mov    %r8d,%edi
 29f8387:	lea    (%r10,%rdi,1),%r8
 29f838b:	cmp    %r9,%rdi
 29f838e:	cmova  %r11,%r8
 29f8392:	mov    %rcx,%r10
 29f8395:	shl    $0x3,%r10d
 29f8399:	add    $0x18,%r10d
 29f83a0:	sub    %r10d,%eax
 29f83a3:	sub    %rax,%r8
 29f83a6:	mov    0x90(%rsp),%rdi
 29f83ae:	mov    %rdi,(%r8)
 29f83b1:	mov    $0x1,%r10d
 29f83b7:	mov    0x70(%rsp),%rax
 29f83bc:	mov    %eax,0x18(%rsp)
 29f83c0:	mov    0x78(%rsp),%rax
 29f83c5:	mov    %eax,0x10(%rsp)
 29f83c9:	mov    %esi,0x28(%rsp)
 29f83cd:	mov    %edx,0x8(%rsp)
 29f83d1:	test   %r10d,%r10d
 29f83d4:	mov    %r10,0xa0(%rsp)
 29f83dc:	je     29f83ef <wasm[0]::function[1013]::helper::array_indexed_publish+0x180f>
 29f83e2:	mov    0xa0(%rsp),%r10
 29f83ea:	jmp    29f93a6 <wasm[0]::function[1013]::helper::array_indexed_publish+0x27c6>
 29f83ef:	mov    0x70(%rsp),%rax
 29f83f4:	mov    0x70(%rsp),%rcx
 29f83f9:	test   %ecx,%eax
 29f83fb:	je     29fc716 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5b36>
 29f8401:	test   %ecx,%eax
 29f8403:	je     29fc718 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5b38>
 29f8409:	mov    0xc8(%rsp),%rbx
 29f8411:	mov    0x28(%rbx),%rax
 29f8415:	mov    0x20(%rbx),%rdi
 29f8419:	mov    %ecx,%r8d
 29f841c:	add    %r8,%rdi
 29f841f:	xor    %r9,%r9
 29f8422:	cmp    %rax,%r8
 29f8425:	cmova  %r9,%rdi
 29f8429:	mov    0x24(%rdi),%edi
 29f842c:	cmp    $0x4,%edi
 29f842f:	sete   %al
 29f8432:	cmp    $0x2,%edi
 29f8435:	sete   %dil
 29f8439:	or     %edi,%eax
 29f843b:	mov    0x98(%rsp),%r12
 29f8443:	cmp    $0x3,%r12d
 29f8447:	setne  %cl
 29f844a:	test   %al,%cl
 29f844c:	jne    29f8461 <wasm[0]::function[1013]::helper::array_indexed_publish+0x1881>
 29f8452:	mov    0x70(%rsp),%rdi
 29f8457:	mov    0x70(%rsp),%r8
 29f845c:	jmp    29f8c3a <wasm[0]::function[1013]::helper::array_indexed_publish+0x205a>
 29f8461:	mov    0x18(%rsp),%edx
 29f8465:	mov    %rdx,%rax
 29f8468:	mov    %rdx,0x70(%rsp)
 29f846d:	test   %eax,%edx
 29f846f:	je     29fc71a <wasm[0]::function[1013]::helper::array_indexed_publish+0x5b3a>
 29f8475:	mov    0x70(%rsp),%rax
 29f847a:	test   %eax,%edx
 29f847c:	je     29fc71c <wasm[0]::function[1013]::helper::array_indexed_publish+0x5b3c>
 29f8482:	mov    0xc8(%rsp),%rbx
 29f848a:	mov    0x28(%rbx),%rax
 29f848e:	mov    0x20(%rbx),%rsi
 29f8492:	mov    %edx,%r8d
 29f8495:	lea    (%rsi,%r8,1),%rdx
 29f8499:	xor    %rdi,%rdi
 29f849c:	cmp    %rax,%r8
 29f849f:	cmova  %rdi,%rdx
 29f84a3:	mov    0x28(%rdx),%r8d
 29f84a7:	mov    0x2c(%rdx),%ecx
 29f84aa:	test   %r8d,%r8d
 29f84ad:	je     29fc71e <wasm[0]::function[1013]::helper::array_indexed_publish+0x5b3e>
 29f84b3:	test   %r8d,%r8d
 29f84b6:	je     29fc720 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5b40>
 29f84bc:	mov    %r8d,%r8d
 29f84bf:	lea    0x10(%rsi,%r8,1),%rsi
 29f84c4:	cmp    %rax,%r8
 29f84c7:	cmova  %rdi,%rsi
 29f84cb:	mov    (%rsi),%edi
 29f84cd:	mov    0x18(%rdx),%rax
 29f84d1:	mov    0x28(%rsp),%esi
 29f84d5:	mov    0x8(%rsp),%edx
 29f84d9:	mov    %edi,%ecx
 29f84db:	mov    0x68(%rsp),%r11
 29f84e0:	cmp    %rcx,%r11
 29f84e3:	setb   %dil
 29f84e7:	mov    0x68(%rsp),%rcx
 29f84ec:	cmp    $0x100000,%rcx
 29f84f3:	setb   %r8b
 29f84f7:	lea    0x8(%rax,%rax,1),%rax
 29f84fc:	cmp    %rax,%rcx
 29f84ff:	setbe  %al
 29f8502:	and    %eax,%r8d
 29f8505:	or     %r8d,%edi
 29f8508:	test   %dil,%dil
 29f850b:	je     29f8c30 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2050>
 29f8511:	mov    0x18(%rsp),%edx
 29f8515:	test   %edx,%edx
 29f8517:	je     29fc722 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5b42>
 29f851d:	test   %edx,%edx
 29f851f:	je     29fc724 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5b44>
 29f8525:	mov    0xc8(%rsp),%rbx
 29f852d:	mov    0x28(%rbx),%rax
 29f8531:	mov    0x20(%rbx),%rcx
 29f8535:	mov    %edx,%edi
 29f8537:	lea    (%rcx,%rdi,1),%rsi
 29f853b:	xor    %rdx,%rdx
 29f853e:	cmp    %rax,%rdi
 29f8541:	cmova  %rdx,%rsi
 29f8545:	mov    0x28(%rsi),%edi
 29f8548:	mov    0x2c(%rsi),%esi
 29f854b:	test   %edi,%edi
 29f854d:	je     29fc726 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5b46>
 29f8553:	test   %edi,%edi
 29f8555:	je     29fc728 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5b48>
 29f855b:	mov    %edi,%esi
 29f855d:	lea    0x10(%rcx,%rsi,1),%rcx
 29f8562:	cmp    %rax,%rsi
 29f8565:	cmova  %rdx,%rcx
 29f8569:	mov    (%rcx),%eax
 29f856b:	mov    %eax,%ebx
 29f856d:	mov    %rbx,%r12
 29f8570:	shl    $0x2,%r12
 29f8574:	mov    $0x20,%ecx
 29f8579:	mov    %rcx,0x78(%rsp)
 29f857e:	mov    %r12,%rcx
 29f8581:	shr    $0x20,%rcx
 29f8585:	test   %rcx,%rcx
 29f8588:	jne    29fc72a <wasm[0]::function[1013]::helper::array_indexed_publish+0x5b4a>
 29f858e:	mov    %rax,%rcx
 29f8591:	shl    $0x2,%ecx
 29f8594:	mov    %rax,0x80(%rsp)
 29f859c:	add    $0x14,%ecx
 29f859f:	jb     29fc72c <wasm[0]::function[1013]::helper::array_indexed_publish+0x5b4c>
 29f85a5:	mov    0x60(%rsp),%rdi
 29f85aa:	mov    0x20(%rdi),%r13
 29f85ae:	mov    0x0(%r13),%eax
 29f85b2:	mov    %eax,%edx
 29f85b4:	mov    %ecx,%esi
 29f85b6:	add    $0xf,%rsi
 29f85bd:	mov    %rsi,%rdi
 29f85c0:	and    $0xfffffffffffffff0,%rdi
 29f85c4:	add    %rdx,%rdi
 29f85c7:	mov    0x4(%r13),%r8d
 29f85cb:	cmp    %r8,%rdi
 29f85ce:	ja     29fbdc6 <wasm[0]::function[1013]::helper::array_indexed_publish+0x51e6>
 29f85d4:	add    $0xf,%ecx
 29f85da:	and    $0xfffffff0,%ecx
 29f85dd:	add    %eax,%ecx
 29f85df:	mov    %ecx,0x0(%r13)
 29f85e3:	mov    0xc8(%rsp),%rcx
 29f85eb:	mov    0x20(%rcx),%rdi
 29f85ef:	lea    (%rdi,%rdx,1),%rcx
 29f85f3:	movl   $0xa800000e,(%rdi,%rdx,1)
 29f85fa:	mov    0x60(%rsp),%r8
 29f85ff:	mov    0x28(%r8),%r8
 29f8603:	mov    0x19c(%r8),%r8d
 29f860a:	mov    %r8d,0x4(%rdi,%rdx,1)
 29f860f:	and    $0xfffffffffffffff0,%rsi
 29f8613:	mov    %esi,0x8(%rdi,%rdx,1)
 29f8617:	mov    %eax,(%rsp)
 29f861a:	mov    0x80(%rsp),%rdx
 29f8622:	mov    %edx,0x10(%rcx)
 29f8625:	test   %eax,%eax
 29f8627:	je     29fc72e <wasm[0]::function[1013]::helper::array_indexed_publish+0x5b4e>
 29f862d:	mov    0xc8(%rsp),%rcx
 29f8635:	mov    0x28(%rcx),%r10
 29f8639:	mov    0x20(%rcx),%r11
 29f863d:	mov    %eax,%eax
 29f863f:	lea    (%r11,%rax,1),%r9
 29f8643:	lea    0x10(%r11,%rax,1),%rsi
 29f8648:	xor    %rcx,%rcx
 29f864b:	cmp    %r10,%rax
 29f864e:	cmova  %rcx,%rsi
 29f8652:	mov    (%rsi),%ecx
 29f8654:	cmp    %rcx,%rbx
 29f8657:	ja     29fc730 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5b50>
 29f865d:	lea    0x14(%r11,%rax,1),%r14
 29f8662:	mov    %r14,%rax
 29f8665:	add    %r12,%rax
 29f8668:	jb     29fc732 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5b52>
 29f866e:	lea    (%r11,%r10,1),%rcx
 29f8672:	cmp    %rcx,%rax
 29f8675:	ja     29fc734 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5b54>
 29f867b:	mov    0x18(%rsp),%ecx
 29f867f:	mov    0x10(%rsp),%eax
 29f8683:	mov    0x28(%rsp),%edx
 29f8687:	mov    0x8(%rsp),%esi
 29f868b:	lea    0x14(%r9,%rbx,4),%r15
 29f8690:	test   %rbx,%rbx
 29f8693:	je     29f86ec <wasm[0]::function[1013]::helper::array_indexed_publish+0x1b0c>
 29f8699:	mov    %ecx,0x8(%rsp)
 29f869d:	mov    %eax,0x28(%rsp)
 29f86a1:	mov    %edx,0x10(%rsp)
 29f86a5:	mov    %esi,0x18(%rsp)
 29f86a9:	mov    0xd0(%rsp),%rax
 29f86b1:	mov    (%rax),%rax
 29f86b4:	mov    0xa8(%rsp),%rsi
 29f86bc:	cmp    %rsi,%rax
 29f86bf:	jae    29fbdf8 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5218>
 29f86c5:	movl   $0x0,(%r14)
 29f86cc:	mov    0x8(%rsp),%ecx
 29f86d0:	mov    0x28(%rsp),%eax
 29f86d4:	mov    0x10(%rsp),%edx
 29f86d8:	mov    0x18(%rsp),%esi
 29f86dc:	add    $0x4,%r14
 29f86e3:	cmp    %r15,%r14
 29f86e6:	jne    29f8699 <wasm[0]::function[1013]::helper::array_indexed_publish+0x1ab9>
 29f86ec:	mov    %ecx,0x8(%rsp)
 29f86f0:	xor    %r14d,%r14d
 29f86f3:	mov    $0x1,%r12d
 29f86f9:	mov    0x60(%rsp),%rdi
 29f86fe:	mov    %r12,0xc0(%rsp)
 29f8706:	mov    0x28(%rdi),%rcx
 29f870a:	mov    0x120(%rcx),%r12d
 29f8711:	mov    %r12,0xb8(%rsp)
 29f8719:	mov    $0x10,%r12d
 29f871f:	mov    %r12,0xb0(%rsp)
 29f8727:	mov    %r14,%r12
 29f872a:	mov    %eax,0x18(%rsp)
 29f872e:	mov    %edx,0x10(%rsp)
 29f8732:	mov    %esi,0x28(%rsp)
 29f8736:	mov    0xd0(%rsp),%rax
 29f873e:	mov    (%rax),%rax
 29f8741:	mov    0xa8(%rsp),%rcx
 29f8749:	cmp    %rcx,%rax
 29f874c:	jae    29fbe2f <wasm[0]::function[1013]::helper::array_indexed_publish+0x524f>
 29f8752:	mov    0x80(%rsp),%rcx
 29f875a:	jmp    29f8767 <wasm[0]::function[1013]::helper::array_indexed_publish+0x1b87>
 29f875f:	mov    0x80(%rsp),%rcx
 29f8767:	cmp    %ecx,%r14d
 29f876a:	jae    29f8ba4 <wasm[0]::function[1013]::helper::array_indexed_publish+0x1fc4>
 29f8770:	mov    0x8(%rsp),%eax
 29f8774:	test   %eax,%eax
 29f8776:	je     29fc736 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5b56>
 29f877c:	test   %eax,%eax
 29f877e:	je     29fc738 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5b58>
 29f8784:	mov    0xc8(%rsp),%rbx
 29f878c:	mov    0x28(%rbx),%rcx
 29f8790:	mov    %eax,%edx
 29f8792:	mov    %rdx,%rax
 29f8795:	add    0x20(%rbx),%rax
 29f8799:	xor    %rsi,%rsi
 29f879c:	cmp    %rcx,%rdx
 29f879f:	cmova  %rsi,%rax
 29f87a3:	mov    0x24(%rax),%eax
 29f87a6:	cmp    $0x4,%eax
 29f87a9:	je     29f894d <wasm[0]::function[1013]::helper::array_indexed_publish+0x1d6d>
 29f87af:	mov    0x8(%rsp),%ecx
 29f87b3:	xor    %r9d,%r9d
 29f87b6:	test   %ecx,%ecx
 29f87b8:	je     29fc73a <wasm[0]::function[1013]::helper::array_indexed_publish+0x5b5a>
 29f87be:	test   %ecx,%ecx
 29f87c0:	je     29fc73c <wasm[0]::function[1013]::helper::array_indexed_publish+0x5b5c>
 29f87c6:	mov    0xc8(%rsp),%rbx
 29f87ce:	mov    0x28(%rbx),%rax
 29f87d2:	mov    0x20(%rbx),%rdi
 29f87d6:	mov    %ecx,%ecx
 29f87d8:	lea    (%rdi,%rcx,1),%rdx
 29f87dc:	xor    %r8,%r8
 29f87df:	cmp    %rax,%rcx
 29f87e2:	cmova  %r8,%rdx
 29f87e6:	mov    0x28(%rdx),%ecx
 29f87e9:	mov    0x2c(%rdx),%esi
 29f87ec:	test   %ecx,%ecx
 29f87ee:	je     29fc73e <wasm[0]::function[1013]::helper::array_indexed_publish+0x5b5e>
 29f87f4:	test   %ecx,%ecx
 29f87f6:	je     29fc740 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5b60>
 29f87fc:	mov    %ecx,%edx
 29f87fe:	lea    0x10(%rdi,%rdx,1),%rdi
 29f8803:	cmp    %rax,%rdx
 29f8806:	cmova  %r8,%rdi
 29f880a:	mov    (%rdi),%edi
 29f880c:	mov    0x18(%rsp),%eax
 29f8810:	mov    %r14d,%r8d
 29f8813:	mov    %edi,%edi
 29f8815:	cmp    %rdi,%r8
 29f8818:	jae    29f8a5e <wasm[0]::function[1013]::helper::array_indexed_publish+0x1e7e>
 29f881e:	xor    %r9d,%r9d
 29f8821:	test   %esi,%esi
 29f8823:	je     29fc742 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5b62>
 29f8829:	test   %esi,%esi
 29f882b:	je     29fc744 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5b64>
 29f8831:	mov    0xc8(%rsp),%rbx
 29f8839:	mov    0x28(%rbx),%r10
 29f883d:	mov    0x20(%rbx),%r11
 29f8841:	mov    %esi,%r8d
 29f8844:	lea    0x10(%r11,%r8,1),%rdi
 29f8849:	xor    %rax,%rax
 29f884c:	cmp    %r10,%r8
 29f884f:	cmova  %rax,%rdi
 29f8853:	mov    (%rdi),%edi
 29f8855:	mov    %r14,%r8
 29f8858:	shr    $0x6,%r8d
 29f885c:	cmp    %edi,%r8d
 29f885f:	jae    29fc746 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5b66>
 29f8865:	mov    %edi,%r15d
 29f8868:	shl    $0x3,%r15
 29f886c:	shr    $0x20,%r15
 29f8870:	test   %r15,%r15
 29f8873:	jne    29fc748 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5b68>
 29f8879:	shl    $0x3,%edi
 29f887c:	add    $0x18,%edi
 29f887f:	jb     29fc74a <wasm[0]::function[1013]::helper::array_indexed_publish+0x5b6a>
 29f8885:	add    %edi,%esi
 29f8887:	jb     29fc74c <wasm[0]::function[1013]::helper::array_indexed_publish+0x5b6c>
 29f888d:	mov    %esi,%ebx
 29f888f:	lea    (%r11,%rbx,1),%rsi
 29f8893:	cmp    %r10,%rbx
 29f8896:	cmova  %rax,%rsi
 29f889a:	shl    $0x3,%r8d
 29f889e:	lea    0x18(%r8),%eax
 29f88a2:	sub    %eax,%edi
 29f88a4:	sub    %rdi,%rsi
 29f88a7:	mov    (%rsi),%rsi
 29f88aa:	mov    0x18(%rsp),%eax
 29f88ae:	bt     %r14,%rsi
 29f88b2:	jae    29f8a5e <wasm[0]::function[1013]::helper::array_indexed_publish+0x1e7e>
 29f88b8:	mov    0xc8(%rsp),%rbx
 29f88c0:	mov    0x28(%rbx),%rax
 29f88c4:	mov    0x20(%rbx),%rdi
 29f88c8:	lea    0x10(%rdi,%rdx,1),%r8
 29f88cd:	xor    %rsi,%rsi
 29f88d0:	cmp    %rax,%rdx
 29f88d3:	cmova  %rsi,%r8
 29f88d7:	mov    (%r8),%r9d
 29f88da:	cmp    %r9d,%r14d
 29f88dd:	jae    29fc74e <wasm[0]::function[1013]::helper::array_indexed_publish+0x5b6e>
 29f88e3:	mov    %r9d,%edx
 29f88e6:	shl    $0x3,%rdx
 29f88ea:	shr    $0x20,%rdx
 29f88ee:	test   %rdx,%rdx
 29f88f1:	jne    29fc750 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5b70>
 29f88f7:	mov    $0x3,%r12d
 29f88fd:	shl    $0x3,%r9d
 29f8901:	add    $0x18,%r9d
 29f8905:	jb     29fc752 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5b72>
 29f890b:	add    %r9d,%ecx
 29f890e:	jb     29fc754 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5b74>
 29f8914:	mov    %ecx,%edx
 29f8916:	lea    (%rdi,%rdx,1),%rcx
 29f891a:	cmp    %rax,%rdx
 29f891d:	cmova  %rsi,%rcx
 29f8921:	mov    %r14,%rax
 29f8924:	shl    $0x3,%eax
 29f8927:	add    $0x18,%eax
 29f892d:	sub    %eax,%r9d
 29f8930:	sub    %r9,%rcx
 29f8933:	mov    (%rcx),%rax
 29f8936:	mov    %rax,0x88(%rsp)
 29f893e:	xor    %eax,%eax
 29f8940:	mov    0xc0(%rsp),%r9
 29f8948:	jmp    29f8a5e <wasm[0]::function[1013]::helper::array_indexed_publish+0x1e7e>
 29f894d:	mov    0x8(%rsp),%eax
 29f8951:	xor    %r9d,%r9d
 29f8954:	test   %eax,%eax
 29f8956:	je     29fc756 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5b76>
 29f895c:	test   %eax,%eax
 29f895e:	je     29fc758 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5b78>
 29f8964:	mov    0xc8(%rsp),%rbx
 29f896c:	mov    0x28(%rbx),%rcx
 29f8970:	mov    %eax,%edx
 29f8972:	mov    %rdx,%rax
 29f8975:	add    0x20(%rbx),%rax
 29f8979:	xor    %rsi,%rsi
 29f897c:	cmp    %rcx,%rdx
 29f897f:	cmova  %rsi,%rax
 29f8983:	mov    0x18(%rax),%rcx
 29f8987:	mov    0x18(%rsp),%eax
 29f898b:	mov    %r14d,%edx
 29f898e:	cmp    %rcx,%rdx
 29f8991:	jae    29f8a5e <wasm[0]::function[1013]::helper::array_indexed_publish+0x1e7e>
 29f8997:	mov    0x8(%rsp),%esi
 29f899b:	xor    %eax,%eax
 29f899d:	test   %esi,%esi
 29f899f:	je     29fc75a <wasm[0]::function[1013]::helper::array_indexed_publish+0x5b7a>
 29f89a5:	test   %esi,%esi
 29f89a7:	je     29fc75c <wasm[0]::function[1013]::helper::array_indexed_publish+0x5b7c>
 29f89ad:	mov    0xc8(%rsp),%rbx
 29f89b5:	mov    0x28(%rbx),%rcx
 29f89b9:	mov    0x20(%rbx),%rdx
 29f89bd:	mov    %esi,%r8d
 29f89c0:	lea    (%rdx,%r8,1),%rdi
 29f89c4:	xor    %rsi,%rsi
 29f89c7:	cmp    %rcx,%r8
 29f89ca:	cmova  %rsi,%rdi
 29f89ce:	mov    0x28(%rdi),%edi
 29f89d1:	test   %edi,%edi
 29f89d3:	je     29fc75e <wasm[0]::function[1013]::helper::array_indexed_publish+0x5b7e>
 29f89d9:	test   %edi,%edi
 29f89db:	je     29fc760 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5b80>
 29f89e1:	mov    %edi,%r9d
 29f89e4:	lea    0x10(%rdx,%r9,1),%r8
 29f89e9:	cmp    %rcx,%r9
 29f89ec:	cmova  %rsi,%r8
 29f89f0:	mov    (%r8),%r8d
 29f89f3:	cmp    %r8d,%r14d
 29f89f6:	jae    29fc762 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5b82>
 29f89fc:	mov    %r8d,%r9d
 29f89ff:	shl    $0x3,%r9
 29f8a03:	shr    $0x20,%r9
 29f8a07:	test   %r9,%r9
 29f8a0a:	jne    29fc764 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5b84>
 29f8a10:	mov    $0x3,%r12d
 29f8a16:	shl    $0x3,%r8d
 29f8a1a:	add    $0x18,%r8d
 29f8a1e:	jb     29fc766 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5b86>
 29f8a24:	add    %r8d,%edi
 29f8a27:	jb     29fc768 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5b88>
 29f8a2d:	mov    %edi,%edi
 29f8a2f:	add    %rdi,%rdx
 29f8a32:	cmp    %rcx,%rdi
 29f8a35:	cmova  %rsi,%rdx
 29f8a39:	mov    %r14,%rcx
 29f8a3c:	shl    $0x3,%ecx
 29f8a3f:	add    $0x18,%ecx
 29f8a45:	sub    %ecx,%r8d
 29f8a48:	sub    %r8,%rdx
 29f8a4b:	mov    (%rdx),%rcx
 29f8a4e:	mov    %rcx,0x88(%rsp)
 29f8a56:	mov    0xc0(%rsp),%r9
 29f8a5e:	mov    %eax,0x18(%rsp)
 29f8a62:	test   %r9d,%r9d
 29f8a65:	jne    29f8a7d <wasm[0]::function[1013]::helper::array_indexed_publish+0x1e9d>
 29f8a6b:	mov    0x78(%rsp),%rcx
 29f8a70:	mov    0xb8(%rsp),%r15
 29f8a78:	jmp    29f8b7f <wasm[0]::function[1013]::helper::array_indexed_publish+0x1f9f>
 29f8a7d:	mov    0x0(%r13),%eax
 29f8a81:	mov    %eax,%edx
 29f8a83:	lea    0x20(%rdx),%rcx
 29f8a87:	mov    0x4(%r13),%esi
 29f8a8b:	cmp    %rsi,%rcx
 29f8a8e:	ja     29fbe6b <wasm[0]::function[1013]::helper::array_indexed_publish+0x528b>
 29f8a94:	mov    0xb8(%rsp),%r15
 29f8a9c:	lea    0x20(%rax),%esi
 29f8a9f:	mov    %esi,0x0(%r13)
 29f8aa3:	mov    0xc8(%rsp),%rbx
 29f8aab:	mov    0x20(%rbx),%rdi
 29f8aaf:	lea    (%rdi,%rdx,1),%rsi
 29f8ab3:	movl   $0xb0000042,(%rdi,%rdx,1)
 29f8aba:	mov    %r15d,0x4(%rdi,%rdx,1)
 29f8abf:	mov    0x78(%rsp),%rcx
 29f8ac4:	mov    %ecx,0x8(%rdi,%rdx,1)
 29f8ac8:	mov    0x88(%rsp),%rdx
 29f8ad0:	mov    0x88(%rsp),%rdx
 29f8ad8:	mov    %rdx,0x10(%rsi)
 29f8adc:	mov    %r12d,0x18(%rsi)
 29f8ae0:	mov    0x18(%rsp),%r10d
 29f8ae5:	mov    %r10d,0x1c(%rsi)
 29f8ae9:	mov    (%rsp),%edx
 29f8aec:	test   %edx,%edx
 29f8aee:	je     29fc76a <wasm[0]::function[1013]::helper::array_indexed_publish+0x5b8a>
 29f8af4:	test   %eax,%eax
 29f8af6:	je     29fc76c <wasm[0]::function[1013]::helper::array_indexed_publish+0x5b8c>
 29f8afc:	test   %edx,%edx
 29f8afe:	je     29fc76e <wasm[0]::function[1013]::helper::array_indexed_publish+0x5b8e>
 29f8b04:	mov    0xc8(%rsp),%rbx
 29f8b0c:	mov    0x28(%rbx),%rsi
 29f8b10:	mov    0x20(%rbx),%rdi
 29f8b14:	mov    %edx,%r10d
 29f8b17:	lea    0x10(%rdi,%r10,1),%r9
 29f8b1c:	xor    %r8,%r8
 29f8b1f:	cmp    %rsi,%r10
 29f8b22:	cmova  %r8,%r9
 29f8b26:	mov    (%r9),%r9d
 29f8b29:	cmp    %r9d,%r14d
 29f8b2c:	jae    29fc770 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5b90>
 29f8b32:	mov    %r9d,%r10d
 29f8b35:	shl    $0x2,%r10
 29f8b39:	shr    $0x20,%r10
 29f8b3d:	test   %r10,%r10
 29f8b40:	jne    29fc772 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5b92>
 29f8b46:	shl    $0x2,%r9d
 29f8b4a:	add    $0x14,%r9d
 29f8b4e:	jb     29fc774 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5b94>
 29f8b54:	add    %r9d,%edx
 29f8b57:	jb     29fc776 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5b96>
 29f8b5d:	mov    %edx,%r10d
 29f8b60:	lea    (%rdi,%r10,1),%rdx
 29f8b64:	cmp    %rsi,%r10
 29f8b67:	cmova  %r8,%rdx
 29f8b6b:	mov    %r14,%rsi
 29f8b6e:	shl    $0x2,%esi
 29f8b71:	add    $0x14,%esi
 29f8b77:	sub    %esi,%r9d
 29f8b7a:	sub    %r9,%rdx
 29f8b7d:	mov    %eax,(%rdx)
 29f8b7f:	mov    0x18(%rsp),%eax
 29f8b83:	mov    0x10(%rsp),%edx
 29f8b87:	mov    0x28(%rsp),%esi
 29f8b8b:	add    $0x1,%r14d
 29f8b92:	mov    %rcx,0x78(%rsp)
 29f8b97:	mov    %r15,0xb8(%rsp)
 29f8b9f:	jmp    29f872a <wasm[0]::function[1013]::helper::array_indexed_publish+0x1b4a>
 29f8ba4:	mov    0x60(%rsp),%rdi
 29f8ba9:	mov    0xa00(%rdi),%edx
 29f8baf:	mov    0xa10(%rdi),%eax
 29f8bb5:	mov    0x8(%rsp),%ecx
 29f8bb9:	mov    %rcx,%rsi
 29f8bbc:	mov    %rcx,0x70(%rsp)
 29f8bc1:	test   %esi,%ecx
 29f8bc3:	je     29fc778 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5b98>
 29f8bc9:	test   %edx,%edx
 29f8bcb:	je     29fc77a <wasm[0]::function[1013]::helper::array_indexed_publish+0x5b9a>
 29f8bd1:	mov    0x70(%rsp),%rsi
 29f8bd6:	test   %esi,%ecx
 29f8bd8:	je     29fc77c <wasm[0]::function[1013]::helper::array_indexed_publish+0x5b9c>
 29f8bde:	mov    0xc8(%rsp),%rbx
 29f8be6:	mov    0x28(%rbx),%rdi
 29f8bea:	mov    0x20(%rbx),%rsi
 29f8bee:	mov    %ecx,%r8d
 29f8bf1:	add    %r8,%rsi
 29f8bf4:	xor    %r9,%r9
 29f8bf7:	cmp    %rdi,%r8
 29f8bfa:	cmova  %r9,%rsi
 29f8bfe:	mov    %edx,0x28(%rsi)
 29f8c01:	test   %eax,%eax
 29f8c03:	je     29fc77e <wasm[0]::function[1013]::helper::array_indexed_publish+0x5b9e>
 29f8c09:	mov    %eax,0x2c(%rsi)
 29f8c0c:	movl   $0x0,0x30(%rsi)
 29f8c13:	mov    (%rsp),%eax
 29f8c16:	test   %eax,%eax
 29f8c18:	je     29fc780 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5ba0>
 29f8c1e:	mov    %eax,0x30(%rsi)
 29f8c21:	movl   $0x3,0x24(%rsi)
 29f8c28:	mov    0x10(%rsp),%esi
 29f8c2c:	mov    0x28(%rsp),%edx
 29f8c30:	mov    0x70(%rsp),%rdi
 29f8c35:	mov    0x70(%rsp),%r8
 29f8c3a:	test   %r8d,%edi
 29f8c3d:	je     29fc782 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5ba2>
 29f8c43:	mov    0x70(%rsp),%rdi
 29f8c48:	mov    0x70(%rsp),%r8
 29f8c4d:	test   %r8d,%edi
 29f8c50:	je     29fc784 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5ba4>
 29f8c56:	mov    0xc8(%rsp),%rbx
 29f8c5e:	mov    0x28(%rbx),%rax
 29f8c62:	mov    0x70(%rsp),%r11
 29f8c67:	mov    %r11d,%edi
 29f8c6a:	mov    %rdi,%r8
 29f8c6d:	add    0x20(%rbx),%r8
 29f8c71:	xor    %r9,%r9
 29f8c74:	cmp    %rax,%rdi
 29f8c77:	cmova  %r9,%r8
 29f8c7b:	mov    0x24(%r8),%eax
 29f8c7f:	cmp    $0x3,%eax
 29f8c82:	je     29f8c95 <wasm[0]::function[1013]::helper::array_indexed_publish+0x20b5>
 29f8c88:	mov    0xa0(%rsp),%r10
 29f8c90:	jmp    29f93a6 <wasm[0]::function[1013]::helper::array_indexed_publish+0x27c6>
 29f8c95:	mov    0xc8(%rsp),%rbx
 29f8c9d:	mov    0x28(%rbx),%r8
 29f8ca1:	mov    0x20(%rbx),%r10
 29f8ca5:	lea    (%r10,%rdi,1),%rax
 29f8ca9:	xor    %r9,%r9
 29f8cac:	cmp    %r8,%rdi
 29f8caf:	cmova  %r9,%rax
 29f8cb3:	mov    0x30(%rax),%edi
 29f8cb6:	test   %edi,%edi
 29f8cb8:	je     29fc786 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5ba6>
 29f8cbe:	test   %edi,%edi
 29f8cc0:	je     29fc788 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5ba8>
 29f8cc6:	mov    %edi,%r11d
 29f8cc9:	lea    0x10(%r10,%r11,1),%r10
 29f8cce:	cmp    %r8,%r11
 29f8cd1:	cmova  %r9,%r10
 29f8cd5:	mov    (%r10),%ebx
 29f8cd8:	mov    %rbx,0x80(%rsp)
 29f8ce0:	mov    0x18(%rax),%r14
 29f8ce4:	mov    %r14,0x88(%rsp)
 29f8cec:	mov    %ebx,%r12d
 29f8cef:	mov    0x68(%rsp),%rcx
 29f8cf4:	cmp    %r12,%rcx
 29f8cf7:	setb   %al
 29f8cfa:	cmp    $0x100000,%rcx
 29f8d01:	setb   %r8b
 29f8d05:	lea    0x8(%r14,%r14,1),%rcx
 29f8d0a:	mov    0x68(%rsp),%r9
 29f8d0f:	cmp    %rcx,%r9
 29f8d12:	setbe  %r9b
 29f8d16:	and    %r9d,%r8d
 29f8d19:	or     %r8d,%eax
 29f8d1c:	test   %al,%al
 29f8d1e:	jne    29f8d31 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2151>
 29f8d24:	mov    0xa0(%rsp),%r10
 29f8d2c:	jmp    29f93a6 <wasm[0]::function[1013]::helper::array_indexed_publish+0x27c6>
 29f8d31:	mov    0x68(%rsp),%rcx
 29f8d36:	cmp    %r12,%rcx
 29f8d39:	jb     29f918b <wasm[0]::function[1013]::helper::array_indexed_publish+0x25ab>
 29f8d3f:	mov    0x80(%rsp),%rcx
 29f8d47:	mov    0x80(%rsp),%rbx
 29f8d4f:	test   %ecx,%ebx
 29f8d51:	je     29f8d64 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2184>
 29f8d57:	mov    0x80(%rsp),%rbx
 29f8d5f:	jmp    29f8d69 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2189>
 29f8d64:	mov    $0x4,%ebx
 29f8d69:	mov    %edi,(%rsp)
 29f8d6c:	mov    0x70(%rsp),%rax
 29f8d71:	mov    %eax,0x28(%rsp)
 29f8d75:	mov    %esi,0x10(%rsp)
 29f8d79:	mov    %edx,0x8(%rsp)
 29f8d7d:	mov    0xd0(%rsp),%rax
 29f8d85:	mov    (%rax),%rax
 29f8d88:	mov    0xa8(%rsp),%rcx
 29f8d90:	cmp    %rcx,%rax
 29f8d93:	jae    29fbeb2 <wasm[0]::function[1013]::helper::array_indexed_publish+0x52d2>
 29f8d99:	mov    %ebx,%r15d
 29f8d9c:	mov    0x68(%rsp),%rcx
 29f8da1:	cmp    %r15,%rcx
 29f8da4:	jb     29f8dc5 <wasm[0]::function[1013]::helper::array_indexed_publish+0x21e5>
 29f8daa:	mov    (%rsp),%edi
 29f8dad:	mov    0x28(%rsp),%edx
 29f8db1:	mov    %rdx,0x70(%rsp)
 29f8db6:	mov    0x10(%rsp),%esi
 29f8dba:	mov    0x8(%rsp),%edx
 29f8dbe:	shl    $1,%ebx
 29f8dc0:	jmp    29f8d69 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2189>
 29f8dc5:	mov    %r15,%r13
 29f8dc8:	shl    $0x2,%r13
 29f8dcc:	mov    %r13,%rax
 29f8dcf:	shr    $0x20,%rax
 29f8dd3:	test   %rax,%rax
 29f8dd6:	jne    29fc78a <wasm[0]::function[1013]::helper::array_indexed_publish+0x5baa>
 29f8ddc:	mov    %rbx,%rcx
 29f8ddf:	shl    $0x2,%ecx
 29f8de2:	add    $0x14,%ecx
 29f8de5:	jb     29fc78c <wasm[0]::function[1013]::helper::array_indexed_publish+0x5bac>
 29f8deb:	mov    0x60(%rsp),%rdi
 29f8df0:	mov    0x20(%rdi),%rsi
 29f8df4:	mov    (%rsi),%eax
 29f8df6:	mov    %eax,%edx
 29f8df8:	mov    %ecx,%edi
 29f8dfa:	lea    0xf(%rdi),%r10
 29f8dfe:	mov    %r10,%rdi
 29f8e01:	and    $0xfffffffffffffff0,%rdi
 29f8e05:	add    %rdx,%rdi
 29f8e08:	mov    0x4(%rsi),%r8d
 29f8e0c:	cmp    %r8,%rdi
 29f8e0f:	ja     29fbee6 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5306>
 29f8e15:	add    $0xf,%ecx
 29f8e1b:	and    $0xfffffff0,%ecx
 29f8e1e:	add    %eax,%ecx
 29f8e20:	mov    %ecx,(%rsi)
 29f8e22:	mov    0xc8(%rsp),%rcx
 29f8e2a:	mov    0x20(%rcx),%rsi
 29f8e2e:	lea    (%rsi,%rdx,1),%rcx
 29f8e32:	movl   $0xa800000e,(%rsi,%rdx,1)
 29f8e39:	mov    0x60(%rsp),%rdi
 29f8e3e:	mov    0x28(%rdi),%rdi
 29f8e42:	mov    0x19c(%rdi),%edi
 29f8e48:	mov    %edi,0x4(%rsi,%rdx,1)
 29f8e4c:	and    $0xfffffffffffffff0,%r10
 29f8e50:	mov    %r10d,0x8(%rsi,%rdx,1)
 29f8e55:	mov    %eax,0x18(%rsp)
 29f8e59:	mov    %ebx,0x10(%rcx)
 29f8e5c:	test   %eax,%eax
 29f8e5e:	je     29fc78e <wasm[0]::function[1013]::helper::array_indexed_publish+0x5bae>
 29f8e64:	mov    0xc8(%rsp),%rbx
 29f8e6c:	mov    0x28(%rbx),%rcx
 29f8e70:	mov    0x20(%rbx),%rdx
 29f8e74:	mov    %eax,%eax
 29f8e76:	lea    (%rdx,%rax,1),%rdi
 29f8e7a:	lea    0x10(%rdx,%rax,1),%rsi
 29f8e7f:	xor    %r8,%r8
 29f8e82:	cmp    %rcx,%rax
 29f8e85:	cmova  %r8,%rsi
 29f8e89:	mov    (%rsi),%esi
 29f8e8b:	cmp    %rsi,%r15
 29f8e8e:	ja     29fc790 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5bb0>
 29f8e94:	lea    0x14(%rdx,%rax,1),%r14
 29f8e99:	mov    %r14,%rax
 29f8e9c:	add    %r13,%rax
 29f8e9f:	jb     29fc792 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5bb2>
 29f8ea5:	add    %rdx,%rcx
 29f8ea8:	cmp    %rcx,%rax
 29f8eab:	ja     29fc794 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5bb4>
 29f8eb1:	mov    (%rsp),%eax
 29f8eb4:	mov    0x28(%rsp),%edx
 29f8eb8:	mov    %rdx,0x70(%rsp)
 29f8ebd:	mov    0x10(%rsp),%esi
 29f8ec1:	mov    0x8(%rsp),%edx
 29f8ec5:	lea    0x14(%rdi,%r15,4),%rbx
 29f8eca:	test   %r15,%r15
 29f8ecd:	je     29f8f2e <wasm[0]::function[1013]::helper::array_indexed_publish+0x234e>
 29f8ed3:	mov    %eax,0x8(%rsp)
 29f8ed7:	mov    0x70(%rsp),%rax
 29f8edc:	mov    %eax,0x10(%rsp)
 29f8ee0:	mov    %esi,0x28(%rsp)
 29f8ee4:	mov    %edx,(%rsp)
 29f8ee7:	mov    0xd0(%rsp),%rax
 29f8eef:	mov    (%rax),%rax
 29f8ef2:	mov    0xa8(%rsp),%rdx
 29f8efa:	cmp    %rdx,%rax
 29f8efd:	jae    29fbf18 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5338>
 29f8f03:	movl   $0x0,(%r14)
 29f8f0a:	mov    0x8(%rsp),%eax
 29f8f0e:	mov    0x10(%rsp),%edx
 29f8f12:	mov    %rdx,0x70(%rsp)
 29f8f17:	mov    0x28(%rsp),%esi
 29f8f1b:	mov    (%rsp),%edx
 29f8f1e:	add    $0x4,%r14
 29f8f25:	cmp    %rbx,%r14
 29f8f28:	jne    29f8ed3 <wasm[0]::function[1013]::helper::array_indexed_publish+0x22f3>
 29f8f2e:	mov    0x18(%rsp),%edi
 29f8f32:	test   %edi,%edi
 29f8f34:	je     29fc796 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5bb6>
 29f8f3a:	test   %eax,%eax
 29f8f3c:	je     29fc798 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5bb8>
 29f8f42:	test   %edi,%edi
 29f8f44:	je     29fc79a <wasm[0]::function[1013]::helper::array_indexed_publish+0x5bba>
 29f8f4a:	mov    0xc8(%rsp),%rbx
 29f8f52:	mov    0x28(%rbx),%r11
 29f8f56:	mov    0x20(%rbx),%r10
 29f8f5a:	mov    %edi,%r13d
 29f8f5d:	lea    (%r10,%r13,1),%r9
 29f8f61:	lea    0x10(%r10,%r13,1),%r8
 29f8f66:	xor    %r15,%r15
 29f8f69:	cmp    %r11,%r13
 29f8f6c:	cmova  %r15,%r8
 29f8f70:	mov    (%r8),%ecx
 29f8f73:	cmp    %rcx,%r12
 29f8f76:	ja     29fc79c <wasm[0]::function[1013]::helper::array_indexed_publish+0x5bbc>
 29f8f7c:	test   %eax,%eax
 29f8f7e:	je     29fc79e <wasm[0]::function[1013]::helper::array_indexed_publish+0x5bbe>
 29f8f84:	mov    %eax,%r14d
 29f8f87:	lea    (%r10,%r14,1),%r8
 29f8f8b:	lea    0x10(%r10,%r14,1),%rbx
 29f8f90:	cmp    %r11,%r14
 29f8f93:	cmova  %r15,%rbx
 29f8f97:	mov    (%rbx),%ecx
 29f8f99:	cmp    %rcx,%r12
 29f8f9c:	ja     29fc7a0 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5bc0>
 29f8fa2:	lea    0x14(%r10,%r13,1),%r13
 29f8fa7:	mov    %r12,%rbx
 29f8faa:	shl    $0x2,%rbx
 29f8fae:	mov    %r13,%r15
 29f8fb1:	add    %rbx,%r15
 29f8fb4:	jb     29fc7a2 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5bc2>
 29f8fba:	add    %r10,%r11
 29f8fbd:	cmp    %r11,%r15
 29f8fc0:	ja     29fc7a4 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5bc4>
 29f8fc6:	lea    0x14(%r10,%r14,1),%r15
 29f8fcb:	mov    %r15,%r10
 29f8fce:	add    %rbx,%r10
 29f8fd1:	jb     29fc7a6 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5bc6>
 29f8fd7:	cmp    %r11,%r10
 29f8fda:	ja     29fc7a8 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5bc8>
 29f8fe0:	mov    0x80(%rsp),%rcx
 29f8fe8:	mov    0x80(%rsp),%rbx
 29f8ff0:	test   %ecx,%ebx
 29f8ff2:	jne    29f9007 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2427>
 29f8ff8:	mov    0x70(%rsp),%rax
 29f8ffd:	mov    0x70(%rsp),%rcx
 29f9002:	jmp    29f9145 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2565>
 29f9007:	mov    0x18(%rsp),%r10d
 29f900c:	xor    %r14d,%r14d
 29f900f:	lea    0x14(%r9,%r12,4),%rbx
 29f9014:	lea    0x14(%r8,%r12,4),%r12
 29f9019:	cmp    %r15,%r13
 29f901c:	jae    29f902a <wasm[0]::function[1013]::helper::array_indexed_publish+0x244a>
 29f9022:	mov    %r10,%rdi
 29f9025:	jmp    29f90c0 <wasm[0]::function[1013]::helper::array_indexed_publish+0x24e0>
 29f902a:	mov    %r10,%rdi
 29f902d:	mov    %r10d,0x20(%rsp)
 29f9032:	mov    %eax,(%rsp)
 29f9035:	mov    0x70(%rsp),%rax
 29f903a:	mov    %eax,0x28(%rsp)
 29f903e:	mov    %edi,0x10(%rsp)
 29f9042:	mov    %esi,0x8(%rsp)
 29f9046:	mov    %edx,0x18(%rsp)
 29f904a:	mov    0xd0(%rsp),%rax
 29f9052:	mov    (%rax),%rax
 29f9055:	mov    0xa8(%rsp),%rcx
 29f905d:	cmp    %rcx,%rax
 29f9060:	jae    29fbf4f <wasm[0]::function[1013]::helper::array_indexed_publish+0x536f>
 29f9066:	sub    $0x4,%r12
 29f906a:	mov    (%r12),%eax
 29f906e:	sub    $0x4,%rbx
 29f9072:	mov    %eax,(%rbx)
 29f9074:	mov    0x28(%rsp),%edx
 29f9078:	mov    %rdx,0x70(%rsp)
 29f907d:	mov    0x10(%rsp),%edi
 29f9081:	mov    0x8(%rsp),%esi
 29f9085:	mov    0x18(%rsp),%edx
 29f9089:	mov    0x20(%rsp),%r10d
 29f908e:	mov    (%rsp),%eax
 29f9091:	mov    0x80(%rsp),%rcx
 29f9099:	mov    %rcx,%r8
 29f909c:	sub    $0x1,%r8d
 29f90a0:	mov    %r8,0x80(%rsp)
 29f90a8:	cmp    %r15,%r12
 29f90ab:	jne    29f902d <wasm[0]::function[1013]::helper::array_indexed_publish+0x244d>
 29f90b1:	mov    0x70(%rsp),%rax
 29f90b6:	mov    0x70(%rsp),%rcx
 29f90bb:	jmp    29f9145 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2565>
 29f90c0:	mov    %r10d,(%rsp)
 29f90c4:	mov    %eax,0x20(%rsp)
 29f90c8:	mov    0x70(%rsp),%rax
 29f90cd:	mov    %eax,0x18(%rsp)
 29f90d1:	mov    %edi,0x8(%rsp)
 29f90d5:	mov    %esi,0x10(%rsp)
 29f90d9:	mov    %edx,0x28(%rsp)
 29f90dd:	mov    0xd0(%rsp),%rax
 29f90e5:	mov    (%rax),%rax
 29f90e8:	mov    0xa8(%rsp),%rcx
 29f90f0:	cmp    %rcx,%rax
 29f90f3:	jae    29fbf83 <wasm[0]::function[1013]::helper::array_indexed_publish+0x53a3>
 29f90f9:	mov    (%r15),%eax
 29f90fc:	mov    %eax,0x0(%r13)
 29f9100:	mov    0x18(%rsp),%edx
 29f9104:	mov    %rdx,0x70(%rsp)
 29f9109:	mov    0x8(%rsp),%edi
 29f910d:	mov    0x10(%rsp),%esi
 29f9111:	mov    0x28(%rsp),%edx
 29f9115:	mov    (%rsp),%r10d
 29f9119:	mov    0x20(%rsp),%eax
 29f911d:	add    $0x4,%r15
 29f9124:	add    $0x4,%r13
 29f912b:	add    $0x1,%r14d
 29f9132:	cmp    %r12,%r15
 29f9135:	jne    29f90c0 <wasm[0]::function[1013]::helper::array_indexed_publish+0x24e0>
 29f913b:	mov    0x70(%rsp),%rax
 29f9140:	mov    0x70(%rsp),%rcx
 29f9145:	test   %ecx,%eax
 29f9147:	je     29fc7aa <wasm[0]::function[1013]::helper::array_indexed_publish+0x5bca>
 29f914d:	test   %edi,%edi
 29f914f:	je     29fc7ac <wasm[0]::function[1013]::helper::array_indexed_publish+0x5bcc>
 29f9155:	mov    0x70(%rsp),%rax
 29f915a:	mov    0x70(%rsp),%rcx
 29f915f:	test   %ecx,%eax
 29f9161:	je     29fc7ae <wasm[0]::function[1013]::helper::array_indexed_publish+0x5bce>
 29f9167:	mov    0xc8(%rsp),%rbx
 29f916f:	mov    0x28(%rbx),%r9
 29f9173:	mov    %eax,%r10d
 29f9176:	mov    %r10,%r8
 29f9179:	add    0x20(%rbx),%r8
 29f917d:	xor    %r11,%r11
 29f9180:	cmp    %r9,%r10
 29f9183:	cmova  %r11,%r8
 29f9187:	mov    %edi,0x30(%r8)
 29f918b:	mov    %esi,0x28(%rsp)
 29f918f:	mov    %edi,0x10(%rsp)
 29f9193:	mov    0x70(%rsp),%r9
 29f9198:	mov    %r9d,0x8(%rsp)
 29f919d:	mov    %edx,0x18(%rsp)
 29f91a1:	mov    0x60(%rsp),%rdi
 29f91a6:	mov    0x20(%rdi),%rsi
 29f91aa:	mov    (%rsi),%eax
 29f91ac:	mov    %eax,%ecx
 29f91ae:	mov    $0x20,%edx
 29f91b3:	lea    0x20(%rcx),%rdi
 29f91b7:	mov    0x4(%rsi),%r8d
 29f91bb:	cmp    %r8,%rdi
 29f91be:	ja     29fbfb7 <wasm[0]::function[1013]::helper::array_indexed_publish+0x53d7>
 29f91c4:	lea    0x20(%rax),%edi
 29f91c7:	mov    %edi,(%rsi)
 29f91c9:	mov    0xc8(%rsp),%rbx
 29f91d1:	mov    0x20(%rbx),%rdi
 29f91d5:	lea    (%rdi,%rcx,1),%rsi
 29f91d9:	movl   $0xb0000042,(%rdi,%rcx,1)
 29f91e0:	mov    0x60(%rsp),%r8
 29f91e5:	mov    0x28(%r8),%r8
 29f91e9:	mov    0x120(%r8),%r8d
 29f91f0:	mov    %r8d,0x4(%rdi,%rcx,1)
 29f91f5:	mov    %edx,0x8(%rdi,%rcx,1)
 29f91f9:	mov    0x90(%rsp),%rdi
 29f9201:	mov    0x90(%rsp),%rdi
 29f9209:	mov    %rdi,0x10(%rsi)
 29f920d:	mov    0x98(%rsp),%r13
 29f9215:	mov    %r13d,0x18(%rsi)
 29f9219:	mov    0x28(%rsp),%ecx
 29f921d:	mov    %ecx,0x1c(%rsi)
 29f9220:	mov    0x10(%rsp),%ecx
 29f9224:	test   %ecx,%ecx
 29f9226:	je     29fc7b0 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5bd0>
 29f922c:	test   %ecx,%ecx
 29f922e:	je     29fc7b2 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5bd2>
 29f9234:	mov    0xc8(%rsp),%rbx
 29f923c:	mov    0x28(%rbx),%rdx
 29f9240:	mov    0x20(%rbx),%rsi
 29f9244:	mov    %ecx,%r9d
 29f9247:	lea    0x10(%rsi,%r9,1),%r8
 29f924c:	xor    %rdi,%rdi
 29f924f:	cmp    %rdx,%r9
 29f9252:	cmova  %rdi,%r8
 29f9256:	mov    (%r8),%r8d
 29f9259:	mov    0x68(%rsp),%r9
 29f925e:	cmp    %r8d,%r9d
 29f9261:	jae    29fc7b4 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5bd4>
 29f9267:	mov    %r8d,%r9d
 29f926a:	shl    $0x2,%r9
 29f926e:	shr    $0x20,%r9
 29f9272:	test   %r9,%r9
 29f9275:	jne    29fc7b6 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5bd6>
 29f927b:	shl    $0x2,%r8d
 29f927f:	add    $0x14,%r8d
 29f9283:	jb     29fc7b8 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5bd8>
 29f9289:	add    %r8d,%ecx
 29f928c:	jb     29fc7ba <wasm[0]::function[1013]::helper::array_indexed_publish+0x5bda>
 29f9292:	mov    %ecx,%ecx
 29f9294:	add    %rcx,%rsi
 29f9297:	cmp    %rdx,%rcx
 29f929a:	cmova  %rdi,%rsi
 29f929e:	mov    0x68(%rsp),%rcx
 29f92a3:	shl    $0x2,%ecx
 29f92a6:	lea    0x14(%rcx),%edx
 29f92a9:	sub    %edx,%r8d
 29f92ac:	sub    %r8,%rsi
 29f92af:	mov    (%rsi),%edx
 29f92b1:	test   %edx,%edx
 29f92b3:	jne    29f92fd <wasm[0]::function[1013]::helper::array_indexed_publish+0x271d>
 29f92b9:	mov    0x8(%rsp),%edx
 29f92bd:	test   %edx,%edx
 29f92bf:	je     29fc7bc <wasm[0]::function[1013]::helper::array_indexed_publish+0x5bdc>
 29f92c5:	test   %edx,%edx
 29f92c7:	je     29fc7be <wasm[0]::function[1013]::helper::array_indexed_publish+0x5bde>
 29f92cd:	mov    0xc8(%rsp),%rbx
 29f92d5:	mov    0x28(%rbx),%rdi
 29f92d9:	mov    0x88(%rsp),%r14
 29f92e1:	lea    0x1(%r14),%rsi
 29f92e5:	mov    %edx,%r8d
 29f92e8:	mov    %r8,%rdx
 29f92eb:	add    0x20(%rbx),%rdx
 29f92ef:	xor    %r9,%r9
 29f92f2:	cmp    %rdi,%r8
 29f92f5:	cmova  %r9,%rdx
 29f92f9:	mov    %rsi,0x18(%rdx)
 29f92fd:	mov    0x10(%rsp),%edx
 29f9301:	test   %edx,%edx
 29f9303:	je     29fc7c0 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5be0>
 29f9309:	test   %eax,%eax
 29f930b:	je     29fc7c2 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5be2>
 29f9311:	test   %edx,%edx
 29f9313:	je     29fc7c4 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5be4>
 29f9319:	mov    0xc8(%rsp),%rbx
 29f9321:	mov    0x28(%rbx),%rsi
 29f9325:	mov    0x20(%rbx),%rdi
 29f9329:	mov    %edx,%r10d
 29f932c:	lea    0x10(%rdi,%r10,1),%r9
 29f9331:	xor    %r8,%r8
 29f9334:	cmp    %rsi,%r10
 29f9337:	cmova  %r8,%r9
 29f933b:	mov    (%r9),%r9d
 29f933e:	mov    0x68(%rsp),%r10
 29f9343:	cmp    %r9d,%r10d
 29f9346:	jae    29fc7c6 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5be6>
 29f934c:	mov    %r9d,%r10d
 29f934f:	shl    $0x2,%r10
 29f9353:	shr    $0x20,%r10
 29f9357:	test   %r10,%r10
 29f935a:	jne    29fc7c8 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5be8>
 29f9360:	shl    $0x2,%r9d
 29f9364:	add    $0x14,%r9d
 29f9368:	jb     29fc7ca <wasm[0]::function[1013]::helper::array_indexed_publish+0x5bea>
 29f936e:	add    %r9d,%edx
 29f9371:	jb     29fc7cc <wasm[0]::function[1013]::helper::array_indexed_publish+0x5bec>
 29f9377:	mov    %edx,%r10d
 29f937a:	lea    (%rdi,%r10,1),%rdx
 29f937e:	cmp    %rsi,%r10
 29f9381:	cmova  %r8,%rdx
 29f9385:	add    $0x14,%ecx
 29f938b:	sub    %ecx,%r9d
 29f938e:	sub    %r9,%rdx
 29f9391:	mov    %eax,(%rdx)
 29f9393:	mov    0x8(%rsp),%edx
 29f9397:	mov    %rdx,0x70(%rsp)
 29f939c:	mov    0x18(%rsp),%edx
 29f93a0:	mov    $0x1,%r10d
 29f93a6:	mov    0x70(%rsp),%rax
 29f93ab:	mov    %eax,0x18(%rsp)
 29f93af:	mov    %edx,0x8(%rsp)
 29f93b3:	test   %r10d,%r10d
 29f93b6:	mov    %r10,0xa0(%rsp)
 29f93be:	jne    29f9f8f <wasm[0]::function[1013]::helper::array_indexed_publish+0x33af>
 29f93c4:	mov    0x70(%rsp),%rax
 29f93c9:	mov    0x70(%rsp),%rdx
 29f93ce:	test   %eax,%edx
 29f93d0:	je     29fc7ce <wasm[0]::function[1013]::helper::array_indexed_publish+0x5bee>
 29f93d6:	test   %eax,%edx
 29f93d8:	je     29fc7d0 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5bf0>
 29f93de:	mov    0xc8(%rsp),%rbx
 29f93e6:	mov    0x28(%rbx),%rax
 29f93ea:	mov    %edx,%ecx
 29f93ec:	mov    %rcx,%r11
 29f93ef:	add    0x20(%rbx),%r11
 29f93f3:	xor    %rdx,%rdx
 29f93f6:	cmp    %rax,%rcx
 29f93f9:	cmova  %rdx,%r11
 29f93fd:	mov    0x24(%r11),%eax
 29f9401:	cmp    $0x3,%eax
 29f9404:	je     29f9ae9 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2f09>
 29f940a:	mov    0x18(%rsp),%edx
 29f940e:	mov    %rdx,%rax
 29f9411:	mov    %rdx,0x70(%rsp)
 29f9416:	test   %eax,%edx
 29f9418:	je     29fc7d2 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5bf2>
 29f941e:	mov    0x70(%rsp),%rax
 29f9423:	test   %eax,%edx
 29f9425:	je     29fc7d4 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5bf4>
 29f942b:	mov    0xc8(%rsp),%rbx
 29f9433:	mov    0x28(%rbx),%rax
 29f9437:	mov    0x20(%rbx),%rdx
 29f943b:	mov    0x70(%rsp),%rcx
 29f9440:	mov    %ecx,%esi
 29f9442:	add    %rsi,%rdx
 29f9445:	xor    %rdi,%rdi
 29f9448:	cmp    %rax,%rsi
 29f944b:	cmova  %rdi,%rdx
 29f944f:	mov    0x24(%rdx),%eax
 29f9452:	mov    0x8(%rsp),%edx
 29f9456:	cmp    $0x4,%eax
 29f9459:	sete   %sil
 29f945d:	cmp    $0x2,%eax
 29f9460:	sete   %al
 29f9463:	or     %eax,%esi
 29f9465:	test   %sil,%sil
 29f9468:	je     29f9f8f <wasm[0]::function[1013]::helper::array_indexed_publish+0x33af>
 29f946e:	mov    0x18(%rsp),%edx
 29f9472:	test   %edx,%edx
 29f9474:	je     29fc7d6 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5bf6>
 29f947a:	test   %edx,%edx
 29f947c:	je     29fc7d8 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5bf8>
 29f9482:	mov    0xc8(%rsp),%rbx
 29f948a:	mov    0x28(%rbx),%rax
 29f948e:	mov    0x20(%rbx),%rcx
 29f9492:	mov    %edx,%esi
 29f9494:	lea    (%rcx,%rsi,1),%rdi
 29f9498:	xor    %rdx,%rdx
 29f949b:	cmp    %rax,%rsi
 29f949e:	cmova  %rdx,%rdi
 29f94a2:	mov    0x28(%rdi),%esi
 29f94a5:	mov    %esi,0x10(%rsp)
 29f94a9:	mov    0x2c(%rdi),%edi
 29f94ac:	mov    %edi,0x28(%rsp)
 29f94b0:	test   %esi,%esi
 29f94b2:	je     29fc7da <wasm[0]::function[1013]::helper::array_indexed_publish+0x5bfa>
 29f94b8:	test   %esi,%esi
 29f94ba:	je     29fc7dc <wasm[0]::function[1013]::helper::array_indexed_publish+0x5bfc>
 29f94c0:	mov    %esi,%esi
 29f94c2:	lea    0x10(%rcx,%rsi,1),%rcx
 29f94c7:	cmp    %rax,%rsi
 29f94ca:	cmova  %rdx,%rcx
 29f94ce:	mov    (%rcx),%eax
 29f94d0:	mov    %eax,%ebx
 29f94d2:	mov    %rbx,%r12
 29f94d5:	shl    $0x2,%r12
 29f94d9:	mov    $0x20,%ecx
 29f94de:	mov    %rcx,0x78(%rsp)
 29f94e3:	mov    %r12,%rcx
 29f94e6:	shr    $0x20,%rcx
 29f94ea:	test   %rcx,%rcx
 29f94ed:	jne    29fc7de <wasm[0]::function[1013]::helper::array_indexed_publish+0x5bfe>
 29f94f3:	mov    %rax,%rcx
 29f94f6:	shl    $0x2,%ecx
 29f94f9:	mov    %rax,0x80(%rsp)
 29f9501:	add    $0x14,%ecx
 29f9504:	jb     29fc7e0 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5c00>
 29f950a:	mov    0x60(%rsp),%rdi
 29f950f:	mov    0x20(%rdi),%r15
 29f9513:	mov    (%r15),%eax
 29f9516:	mov    %eax,%edx
 29f9518:	mov    %ecx,%esi
 29f951a:	add    $0xf,%rsi
 29f9521:	mov    %rsi,%rdi
 29f9524:	and    $0xfffffffffffffff0,%rdi
 29f9528:	add    %rdx,%rdi
 29f952b:	mov    0x4(%r15),%r8d
 29f952f:	cmp    %r8,%rdi
 29f9532:	ja     29fbff6 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5416>
 29f9538:	add    $0xf,%ecx
 29f953e:	and    $0xfffffff0,%ecx
 29f9541:	add    %eax,%ecx
 29f9543:	mov    %ecx,(%r15)
 29f9546:	mov    0xc8(%rsp),%rcx
 29f954e:	mov    0x20(%rcx),%rdi
 29f9552:	lea    (%rdi,%rdx,1),%rcx
 29f9556:	movl   $0xa800000e,(%rdi,%rdx,1)
 29f955d:	mov    0x60(%rsp),%r8
 29f9562:	mov    0x28(%r8),%r8
 29f9566:	mov    0x194(%r8),%r8d
 29f956d:	mov    %r8d,0x4(%rdi,%rdx,1)
 29f9572:	and    $0xfffffffffffffff0,%rsi
 29f9576:	mov    %esi,0x8(%rdi,%rdx,1)
 29f957a:	mov    %eax,(%rsp)
 29f957d:	mov    0x80(%rsp),%r13
 29f9585:	mov    %r13d,0x10(%rcx)
 29f9589:	test   %eax,%eax
 29f958b:	je     29fc7e2 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5c02>
 29f9591:	mov    0xc8(%rsp),%r11
 29f9599:	mov    0x28(%r11),%rdx
 29f959d:	mov    0xc8(%rsp),%rcx
 29f95a5:	mov    0x20(%rcx),%rsi
 29f95a9:	mov    %eax,%eax
 29f95ab:	lea    (%rsi,%rax,1),%rcx
 29f95af:	lea    0x10(%rsi,%rax,1),%rdi
 29f95b4:	xor    %r8,%r8
 29f95b7:	cmp    %rdx,%rax
 29f95ba:	cmova  %r8,%rdi
 29f95be:	mov    (%rdi),%edi
 29f95c0:	cmp    %rdi,%rbx
 29f95c3:	ja     29fc7e4 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5c04>
 29f95c9:	lea    0x14(%rsi,%rax,1),%r13
 29f95ce:	mov    %r13,%rax
 29f95d1:	add    %r12,%rax
 29f95d4:	jb     29fc7e6 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5c06>
 29f95da:	add    %rsi,%rdx
 29f95dd:	cmp    %rdx,%rax
 29f95e0:	ja     29fc7e8 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5c08>
 29f95e6:	mov    0x18(%rsp),%edi
 29f95ea:	mov    0x28(%rsp),%esi
 29f95ee:	mov    0x10(%rsp),%edx
 29f95f2:	mov    0x8(%rsp),%eax
 29f95f6:	lea    0x14(%rcx,%rbx,4),%r12
 29f95fb:	test   %rbx,%rbx
 29f95fe:	je     29f9658 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2a78>
 29f9604:	mov    %edi,0x30(%rsp)
 29f9608:	mov    %esi,0x20(%rsp)
 29f960c:	mov    %edx,0x10(%rsp)
 29f9610:	mov    %eax,0x28(%rsp)
 29f9614:	mov    0xd0(%rsp),%rax
 29f961c:	mov    (%rax),%rsi
 29f961f:	mov    0xa8(%rsp),%rax
 29f9627:	cmp    %rax,%rsi
 29f962a:	jae    29fc028 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5448>
 29f9630:	movl   $0x0,0x0(%r13)
 29f9638:	mov    0x30(%rsp),%edi
 29f963c:	mov    0x20(%rsp),%esi
 29f9640:	mov    0x10(%rsp),%edx
 29f9644:	mov    0x28(%rsp),%eax
 29f9648:	add    $0x4,%r13
 29f964f:	cmp    %r12,%r13
 29f9652:	jne    29f9604 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2a24>
 29f9658:	mov    %edi,0x10(%rsp)
 29f965c:	mov    %esi,0x20(%rsp)
 29f9660:	mov    %edx,0x30(%rsp)
 29f9664:	xor    %r12d,%r12d
 29f9667:	mov    $0xb0000042,%r14d
 29f966d:	mov    0x60(%rsp),%rdi
 29f9672:	mov    %r14,0xc0(%rsp)
 29f967a:	mov    0x28(%rdi),%rcx
 29f967e:	mov    0x120(%rcx),%r13d
 29f9685:	mov    %r13,0xb8(%rsp)
 29f968d:	mov    $0x20,%r14d
 29f9693:	mov    %r14,0xb0(%rsp)
 29f969b:	mov    $0x10,%r13d
 29f96a1:	mov    %r13,0x98(%rsp)
 29f96a9:	mov    0x13c(%rcx),%ecx
 29f96af:	mov    %rcx,0x90(%rsp)
 29f96b7:	mov    %eax,0x28(%rsp)
 29f96bb:	mov    0xd0(%rsp),%rax
 29f96c3:	mov    (%rax),%rax
 29f96c6:	mov    0xa8(%rsp),%rcx
 29f96ce:	cmp    %rcx,%rax
 29f96d1:	jae    29fc05c <wasm[0]::function[1013]::helper::array_indexed_publish+0x547c>
 29f96d7:	mov    0x80(%rsp),%rcx
 29f96df:	jmp    29f96ec <wasm[0]::function[1013]::helper::array_indexed_publish+0x2b0c>
 29f96e4:	mov    0x80(%rsp),%rcx
 29f96ec:	cmp    %ecx,%r12d
 29f96ef:	jae    29f9a52 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2e72>
 29f96f5:	mov    0x10(%rsp),%eax
 29f96f9:	test   %eax,%eax
 29f96fb:	je     29fc7ea <wasm[0]::function[1013]::helper::array_indexed_publish+0x5c0a>
 29f9701:	test   %eax,%eax
 29f9703:	je     29fc7ec <wasm[0]::function[1013]::helper::array_indexed_publish+0x5c0c>
 29f9709:	mov    0xc8(%rsp),%rbx
 29f9711:	mov    0x28(%rbx),%rcx
 29f9715:	mov    %eax,%edx
 29f9717:	mov    %rdx,%rax
 29f971a:	add    0x20(%rbx),%rax
 29f971e:	xor    %rsi,%rsi
 29f9721:	cmp    %rcx,%rdx
 29f9724:	cmova  %rsi,%rax
 29f9728:	mov    0x24(%rax),%eax
 29f972b:	cmp    $0x4,%eax
 29f972e:	je     29f97d1 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2bf1>
 29f9734:	mov    0x20(%rsp),%eax
 29f9738:	test   %eax,%eax
 29f973a:	je     29fc7ee <wasm[0]::function[1013]::helper::array_indexed_publish+0x5c0e>
 29f9740:	test   %eax,%eax
 29f9742:	je     29fc7f0 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5c10>
 29f9748:	mov    0xc8(%rsp),%rbx
 29f9750:	mov    0x28(%rbx),%rcx
 29f9754:	mov    0x20(%rbx),%rdx
 29f9758:	mov    %eax,%r8d
 29f975b:	lea    0x10(%rdx,%r8,1),%rdi
 29f9760:	xor    %rsi,%rsi
 29f9763:	cmp    %rcx,%r8
 29f9766:	cmova  %rsi,%rdi
 29f976a:	mov    (%rdi),%edi
 29f976c:	mov    %r12,%r8
 29f976f:	shr    $0x6,%r8d
 29f9773:	cmp    %edi,%r8d
 29f9776:	jae    29fc7f2 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5c12>
 29f977c:	mov    %edi,%r9d
 29f977f:	shl    $0x3,%r9
 29f9783:	shr    $0x20,%r9
 29f9787:	test   %r9,%r9
 29f978a:	jne    29fc7f4 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5c14>
 29f9790:	shl    $0x3,%edi
 29f9793:	add    $0x18,%edi
 29f9796:	jb     29fc7f6 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5c16>
 29f979c:	add    %edi,%eax
 29f979e:	jb     29fc7f8 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5c18>
 29f97a4:	mov    %eax,%r9d
 29f97a7:	lea    (%rdx,%r9,1),%rax
 29f97ab:	cmp    %rcx,%r9
 29f97ae:	cmova  %rsi,%rax
 29f97b2:	shl    $0x3,%r8d
 29f97b6:	lea    0x18(%r8),%ecx
 29f97ba:	sub    %ecx,%edi
 29f97bc:	sub    %rdi,%rax
 29f97bf:	mov    (%rax),%rax
 29f97c2:	bt     %r12,%rax
 29f97c6:	setb   %al
 29f97c9:	movzbl %al,%eax
 29f97cc:	jmp    29f9811 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2c31>
 29f97d1:	mov    0x10(%rsp),%eax
 29f97d5:	test   %eax,%eax
 29f97d7:	je     29fc7fa <wasm[0]::function[1013]::helper::array_indexed_publish+0x5c1a>
 29f97dd:	test   %eax,%eax
 29f97df:	je     29fc7fc <wasm[0]::function[1013]::helper::array_indexed_publish+0x5c1c>
 29f97e5:	mov    0xc8(%rsp),%rbx
 29f97ed:	mov    0x28(%rbx),%rcx
 29f97f1:	mov    %eax,%edx
 29f97f3:	mov    %rdx,%rax
 29f97f6:	add    0x20(%rbx),%rax
 29f97fa:	xor    %rsi,%rsi
 29f97fd:	cmp    %rcx,%rdx
 29f9800:	cmova  %rsi,%rax
 29f9804:	mov    %r12d,%ecx
 29f9807:	cmp    0x18(%rax),%rcx
 29f980b:	setb   %al
 29f980e:	movzbl %al,%eax
 29f9811:	test   %eax,%eax
 29f9813:	jne    29f982b <wasm[0]::function[1013]::helper::array_indexed_publish+0x2c4b>
 29f9819:	mov    0x90(%rsp),%r13
 29f9821:	mov    0x78(%rsp),%r14
 29f9826:	jmp    29f9a35 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2e55>
 29f982b:	mov    0x30(%rsp),%eax
 29f982f:	test   %eax,%eax
 29f9831:	je     29fc7fe <wasm[0]::function[1013]::helper::array_indexed_publish+0x5c1e>
 29f9837:	test   %eax,%eax
 29f9839:	je     29fc800 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5c20>
 29f983f:	mov    0xc8(%rsp),%rbx
 29f9847:	mov    0x28(%rbx),%rsi
 29f984b:	mov    0x20(%rbx),%rdi
 29f984f:	mov    %eax,%r9d
 29f9852:	lea    0x10(%rdi,%r9,1),%rcx
 29f9857:	xor    %r8,%r8
 29f985a:	cmp    %rsi,%r9
 29f985d:	cmova  %r8,%rcx
 29f9861:	mov    (%rcx),%ecx
 29f9863:	cmp    %ecx,%r12d
 29f9866:	jae    29fc802 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5c22>
 29f986c:	mov    %ecx,%r9d
 29f986f:	shl    $0x3,%r9
 29f9873:	shr    $0x20,%r9
 29f9877:	test   %r9,%r9
 29f987a:	jne    29fc804 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5c24>
 29f9880:	shl    $0x3,%ecx
 29f9883:	add    $0x18,%ecx
 29f9886:	jb     29fc806 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5c26>
 29f988c:	add    %ecx,%eax
 29f988e:	jb     29fc808 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5c28>
 29f9894:	mov    %eax,%r10d
 29f9897:	add    %r10,%rdi
 29f989a:	cmp    %rsi,%r10
 29f989d:	cmova  %r8,%rdi
 29f98a1:	mov    %r12,%r11
 29f98a4:	shl    $0x3,%r11d
 29f98a8:	add    $0x18,%r11d
 29f98af:	sub    %r11d,%ecx
 29f98b2:	sub    %rcx,%rdi
 29f98b5:	mov    (%rdi),%r13
 29f98b8:	movl   $0x0,0x38(%rsp)
 29f98c0:	mov    (%r15),%eax
 29f98c3:	mov    %eax,%edx
 29f98c5:	lea    0x20(%rdx),%rcx
 29f98c9:	mov    0x4(%r15),%esi
 29f98cd:	cmp    %rsi,%rcx
 29f98d0:	ja     29fc098 <wasm[0]::function[1013]::helper::array_indexed_publish+0x54b8>
 29f98d6:	lea    0x20(%rax),%ecx
 29f98d9:	mov    %ecx,(%r15)
 29f98dc:	mov    0xc8(%rsp),%rbx
 29f98e4:	mov    0x20(%rbx),%rsi
 29f98e8:	lea    (%rsi,%rdx,1),%rcx
 29f98ec:	movl   $0xb0000042,(%rsi,%rdx,1)
 29f98f3:	mov    0xb8(%rsp),%rdi
 29f98fb:	mov    %edi,0x4(%rsi,%rdx,1)
 29f98ff:	mov    0x78(%rsp),%r14
 29f9904:	mov    %r14d,0x8(%rsi,%rdx,1)
 29f9909:	mov    %eax,0x40(%rsp)
 29f990d:	mov    %r13,0x10(%rcx)
 29f9911:	movl   $0x3,0x18(%rcx)
 29f9918:	mov    0x38(%rsp),%edx
 29f991c:	mov    %edx,0x1c(%rcx)
 29f991f:	mov    0x60(%rsp),%rdi
 29f9924:	mov    0xa20(%rdi),%ecx
 29f992a:	mov    %ecx,0x38(%rsp)
 29f992e:	test   %eax,%eax
 29f9930:	je     29fc80a <wasm[0]::function[1013]::helper::array_indexed_publish+0x5c2a>
 29f9936:	test   %ecx,%ecx
 29f9938:	je     29fc80c <wasm[0]::function[1013]::helper::array_indexed_publish+0x5c2c>
 29f993e:	mov    (%r15),%eax
 29f9941:	mov    %eax,%ecx
 29f9943:	lea    0x20(%rcx),%rdx
 29f9947:	mov    0x4(%r15),%esi
 29f994b:	cmp    %rsi,%rdx
 29f994e:	ja     29fc0da <wasm[0]::function[1013]::helper::array_indexed_publish+0x54fa>
 29f9954:	mov    0x90(%rsp),%r13
 29f995c:	lea    0x20(%rax),%edx
 29f995f:	mov    %edx,(%r15)
 29f9962:	mov    0xc8(%rsp),%rbx
 29f996a:	mov    0x20(%rbx),%rdx
 29f996e:	lea    (%rdx,%rcx,1),%r11
 29f9972:	movl   $0xb0000072,(%rdx,%rcx,1)
 29f9979:	mov    %r13d,0x4(%rdx,%rcx,1)
 29f997e:	mov    %r14d,0x8(%rdx,%rcx,1)
 29f9983:	movl   $0xe,0x10(%r11)
 29f998b:	mov    0x40(%rsp),%ecx
 29f998f:	mov    %ecx,0x14(%r11)
 29f9993:	mov    0x38(%rsp),%ecx
 29f9997:	mov    %ecx,0x18(%r11)
 29f999b:	mov    %ecx,0x1c(%r11)
 29f999f:	mov    (%rsp),%ecx
 29f99a2:	test   %ecx,%ecx
 29f99a4:	je     29fc80e <wasm[0]::function[1013]::helper::array_indexed_publish+0x5c2e>
 29f99aa:	test   %eax,%eax
 29f99ac:	je     29fc810 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5c30>
 29f99b2:	test   %ecx,%ecx
 29f99b4:	je     29fc812 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5c32>
 29f99ba:	mov    0xc8(%rsp),%rbx
 29f99c2:	mov    0x28(%rbx),%rdx
 29f99c6:	mov    0x20(%rbx),%rsi
 29f99ca:	mov    %ecx,%r9d
 29f99cd:	lea    0x10(%rsi,%r9,1),%r8
 29f99d2:	xor    %rdi,%rdi
 29f99d5:	cmp    %rdx,%r9
 29f99d8:	cmova  %rdi,%r8
 29f99dc:	mov    (%r8),%r8d
 29f99df:	cmp    %r8d,%r12d
 29f99e2:	jae    29fc814 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5c34>
 29f99e8:	mov    %r8d,%r9d
 29f99eb:	shl    $0x2,%r9
 29f99ef:	shr    $0x20,%r9
 29f99f3:	test   %r9,%r9
 29f99f6:	jne    29fc816 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5c36>
 29f99fc:	shl    $0x2,%r8d
 29f9a00:	add    $0x14,%r8d
 29f9a04:	jb     29fc818 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5c38>
 29f9a0a:	add    %r8d,%ecx
 29f9a0d:	jb     29fc81a <wasm[0]::function[1013]::helper::array_indexed_publish+0x5c3a>
 29f9a13:	mov    %ecx,%r9d
 29f9a16:	lea    (%rsi,%r9,1),%rcx
 29f9a1a:	cmp    %rdx,%r9
 29f9a1d:	cmova  %rdi,%rcx
 29f9a21:	mov    %r12,%rdx
 29f9a24:	shl    $0x2,%edx
 29f9a27:	add    $0x14,%edx
 29f9a2d:	sub    %edx,%r8d
 29f9a30:	sub    %r8,%rcx
 29f9a33:	mov    %eax,(%rcx)
 29f9a35:	mov    0x28(%rsp),%eax
 29f9a39:	add    $0x1,%r12d
 29f9a40:	mov    %r14,0x78(%rsp)
 29f9a45:	mov    %r13,0x90(%rsp)
 29f9a4d:	jmp    29f96b7 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2ad7>
 29f9a52:	mov    0x10(%rsp),%edx
 29f9a56:	mov    %rdx,%rax
 29f9a59:	mov    %rdx,0x70(%rsp)
 29f9a5e:	test   %eax,%edx
 29f9a60:	je     29fc81c <wasm[0]::function[1013]::helper::array_indexed_publish+0x5c3c>
 29f9a66:	mov    (%rsp),%edx
 29f9a69:	test   %edx,%edx
 29f9a6b:	je     29fc81e <wasm[0]::function[1013]::helper::array_indexed_publish+0x5c3e>
 29f9a71:	mov    0x70(%rsp),%rax
 29f9a76:	mov    0x70(%rsp),%rcx
 29f9a7b:	test   %ecx,%eax
 29f9a7d:	je     29fc820 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5c40>
 29f9a83:	mov    0xc8(%rsp),%rbx
 29f9a8b:	mov    0x28(%rbx),%rsi
 29f9a8f:	mov    0x20(%rbx),%r8
 29f9a93:	mov    %eax,%edi
 29f9a95:	lea    (%r8,%rdi,1),%rax
 29f9a99:	xor    %r8,%r8
 29f9a9c:	cmp    %rsi,%rdi
 29f9a9f:	cmova  %r8,%rax
 29f9aa3:	mov    %edx,0x20(%rax)
 29f9aa6:	mov    0x60(%rsp),%rdi
 29f9aab:	mov    0xa00(%rdi),%edi
 29f9ab1:	mov    0x60(%rsp),%rsi
 29f9ab6:	mov    0xa10(%rsi),%esi
 29f9abc:	test   %edi,%edi
 29f9abe:	je     29fc822 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5c42>
 29f9ac4:	mov    %edi,0x28(%rax)
 29f9ac7:	test   %esi,%esi
 29f9ac9:	je     29fc824 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5c44>
 29f9acf:	mov    %esi,0x2c(%rax)
 29f9ad2:	movl   $0x0,0x30(%rax)
 29f9ad9:	movl   $0x0,0x24(%rax)
 29f9ae0:	mov    0x28(%rsp),%edx
 29f9ae4:	jmp    29f9f8f <wasm[0]::function[1013]::helper::array_indexed_publish+0x33af>
 29f9ae9:	mov    0x18(%rsp),%edx
 29f9aed:	test   %edx,%edx
 29f9aef:	je     29fc826 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5c46>
 29f9af5:	test   %edx,%edx
 29f9af7:	je     29fc828 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5c48>
 29f9afd:	mov    0xc8(%rsp),%rbx
 29f9b05:	mov    0x28(%rbx),%rax
 29f9b09:	mov    0x20(%rbx),%rcx
 29f9b0d:	mov    %edx,%edi
 29f9b0f:	lea    (%rcx,%rdi,1),%rsi
 29f9b13:	xor    %rdx,%rdx
 29f9b16:	cmp    %rax,%rdi
 29f9b19:	cmova  %rdx,%rsi
 29f9b1d:	mov    0x30(%rsi),%esi
 29f9b20:	mov    %esi,0x10(%rsp)
 29f9b24:	test   %esi,%esi
 29f9b26:	je     29fc82a <wasm[0]::function[1013]::helper::array_indexed_publish+0x5c4a>
 29f9b2c:	test   %esi,%esi
 29f9b2e:	je     29fc82c <wasm[0]::function[1013]::helper::array_indexed_publish+0x5c4c>
 29f9b34:	mov    %esi,%esi
 29f9b36:	lea    0x10(%rcx,%rsi,1),%rcx
 29f9b3b:	cmp    %rax,%rsi
 29f9b3e:	cmova  %rdx,%rcx
 29f9b42:	mov    (%rcx),%eax
 29f9b44:	mov    %eax,%ebx
 29f9b46:	mov    %rbx,%r12
 29f9b49:	shl    $0x2,%r12
 29f9b4d:	mov    $0x20,%ecx
 29f9b52:	mov    %rcx,0x88(%rsp)
 29f9b5a:	mov    %r12,%rcx
 29f9b5d:	shr    $0x20,%rcx
 29f9b61:	test   %rcx,%rcx
 29f9b64:	jne    29fc82e <wasm[0]::function[1013]::helper::array_indexed_publish+0x5c4e>
 29f9b6a:	mov    %rax,%rcx
 29f9b6d:	shl    $0x2,%ecx
 29f9b70:	mov    %rax,0x90(%rsp)
 29f9b78:	add    $0x14,%ecx
 29f9b7b:	jb     29fc830 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5c50>
 29f9b81:	mov    0x60(%rsp),%rdi
 29f9b86:	mov    0x20(%rdi),%r14
 29f9b8a:	mov    (%r14),%eax
 29f9b8d:	mov    %eax,%edx
 29f9b8f:	mov    %ecx,%esi
 29f9b91:	lea    0xf(%rsi),%r9
 29f9b95:	mov    %r9,%rsi
 29f9b98:	and    $0xfffffffffffffff0,%rsi
 29f9b9c:	add    %rdx,%rsi
 29f9b9f:	mov    0x4(%r14),%edi
 29f9ba3:	cmp    %rdi,%rsi
 29f9ba6:	ja     29fc118 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5538>
 29f9bac:	add    $0xf,%ecx
 29f9bb2:	and    $0xfffffff0,%ecx
 29f9bb5:	add    %eax,%ecx
 29f9bb7:	mov    %ecx,(%r14)
 29f9bba:	mov    0xc8(%rsp),%rcx
 29f9bc2:	mov    0x20(%rcx),%rsi
 29f9bc6:	lea    (%rsi,%rdx,1),%rcx
 29f9bca:	movl   $0xa800000e,(%rsi,%rdx,1)
 29f9bd1:	mov    0x60(%rsp),%rdi
 29f9bd6:	mov    0x28(%rdi),%rdi
 29f9bda:	mov    0x194(%rdi),%edi
 29f9be0:	mov    %edi,0x4(%rsi,%rdx,1)
 29f9be4:	and    $0xfffffffffffffff0,%r9
 29f9be8:	mov    %r9d,0x8(%rsi,%rdx,1)
 29f9bed:	mov    %eax,0x28(%rsp)
 29f9bf1:	mov    0x90(%rsp),%r13
 29f9bf9:	mov    %r13d,0x10(%rcx)
 29f9bfd:	test   %eax,%eax
 29f9bff:	je     29fc832 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5c52>
 29f9c05:	mov    0xc8(%rsp),%rcx
 29f9c0d:	mov    0x28(%rcx),%rdx
 29f9c11:	mov    0x20(%rcx),%rsi
 29f9c15:	mov    %eax,%eax
 29f9c17:	lea    (%rsi,%rax,1),%rcx
 29f9c1b:	lea    0x10(%rsi,%rax,1),%rdi
 29f9c20:	xor    %r8,%r8
 29f9c23:	cmp    %rdx,%rax
 29f9c26:	cmova  %r8,%rdi
 29f9c2a:	mov    (%rdi),%edi
 29f9c2c:	cmp    %rdi,%rbx
 29f9c2f:	ja     29fc834 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5c54>
 29f9c35:	lea    0x14(%rsi,%rax,1),%r13
 29f9c3a:	mov    %r13,%rax
 29f9c3d:	add    %r12,%rax
 29f9c40:	jb     29fc836 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5c56>
 29f9c46:	add    %rsi,%rdx
 29f9c49:	cmp    %rdx,%rax
 29f9c4c:	ja     29fc838 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5c58>
 29f9c52:	mov    0x10(%rsp),%esi
 29f9c56:	mov    0x18(%rsp),%eax
 29f9c5a:	mov    0x8(%rsp),%edx
 29f9c5e:	lea    0x14(%rcx,%rbx,4),%r12
 29f9c63:	test   %rbx,%rbx
 29f9c66:	je     29f9cb8 <wasm[0]::function[1013]::helper::array_indexed_publish+0x30d8>
 29f9c6c:	mov    %esi,0x8(%rsp)
 29f9c70:	mov    %eax,0x18(%rsp)
 29f9c74:	mov    %edx,0x10(%rsp)
 29f9c78:	mov    0xd0(%rsp),%rax
 29f9c80:	mov    (%rax),%rax
 29f9c83:	mov    0xa8(%rsp),%rsi
 29f9c8b:	cmp    %rsi,%rax
 29f9c8e:	jae    29fc14a <wasm[0]::function[1013]::helper::array_indexed_publish+0x556a>
 29f9c94:	movl   $0x0,0x0(%r13)
 29f9c9c:	mov    0x8(%rsp),%esi
 29f9ca0:	mov    0x18(%rsp),%eax
 29f9ca4:	mov    0x10(%rsp),%edx
 29f9ca8:	add    $0x4,%r13
 29f9caf:	cmp    %r12,%r13
 29f9cb2:	jne    29f9c6c <wasm[0]::function[1013]::helper::array_indexed_publish+0x308c>
 29f9cb8:	mov    %esi,0x8(%rsp)
 29f9cbc:	mov    0x60(%rsp),%rdi
 29f9cc1:	mov    0xa20(%rdi),%esi
 29f9cc7:	mov    %esi,0x18(%rsp)
 29f9ccb:	xor    %r15d,%r15d
 29f9cce:	mov    $0xb0000072,%esi
 29f9cd3:	mov    %rsi,0x80(%rsp)
 29f9cdb:	mov    0x28(%rdi),%rsi
 29f9cdf:	mov    0x13c(%rsi),%r13d
 29f9ce6:	mov    $0x20,%esi
 29f9ceb:	mov    %rsi,0x78(%rsp)
 29f9cf0:	mov    $0x10,%esi
 29f9cf5:	mov    %rsi,0xc0(%rsp)
 29f9cfd:	mov    %eax,(%rsp)
 29f9d00:	mov    %edx,0x10(%rsp)
 29f9d04:	mov    0xd0(%rsp),%rax
 29f9d0c:	mov    (%rax),%rsi
 29f9d0f:	mov    0xa8(%rsp),%rax
 29f9d17:	cmp    %rax,%rsi
 29f9d1a:	jae    29fc181 <wasm[0]::function[1013]::helper::array_indexed_publish+0x55a1>
 29f9d20:	mov    0x90(%rsp),%rcx
 29f9d28:	jmp    29f9d35 <wasm[0]::function[1013]::helper::array_indexed_publish+0x3155>
 29f9d2d:	mov    0x90(%rsp),%rcx
 29f9d35:	cmp    %ecx,%r15d
 29f9d38:	jae    29f9f00 <wasm[0]::function[1013]::helper::array_indexed_publish+0x3320>
 29f9d3e:	mov    0x8(%rsp),%ecx
 29f9d42:	test   %ecx,%ecx
 29f9d44:	je     29fc83a <wasm[0]::function[1013]::helper::array_indexed_publish+0x5c5a>
 29f9d4a:	test   %ecx,%ecx
 29f9d4c:	je     29fc83c <wasm[0]::function[1013]::helper::array_indexed_publish+0x5c5c>
 29f9d52:	mov    0xc8(%rsp),%rbx
 29f9d5a:	mov    0x28(%rbx),%rax
 29f9d5e:	mov    0x20(%rbx),%rdx
 29f9d62:	mov    %ecx,%r8d
 29f9d65:	lea    0x10(%rdx,%r8,1),%rdi
 29f9d6a:	xor    %rsi,%rsi
 29f9d6d:	cmp    %rax,%r8
 29f9d70:	cmova  %rsi,%rdi
 29f9d74:	mov    (%rdi),%r8d
 29f9d77:	cmp    %r8d,%r15d
 29f9d7a:	jae    29fc83e <wasm[0]::function[1013]::helper::array_indexed_publish+0x5c5e>
 29f9d80:	mov    %r8d,%edi
 29f9d83:	shl    $0x2,%rdi
 29f9d87:	shr    $0x20,%rdi
 29f9d8b:	test   %rdi,%rdi
 29f9d8e:	jne    29fc840 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5c60>
 29f9d94:	shl    $0x2,%r8d
 29f9d98:	add    $0x14,%r8d
 29f9d9c:	jb     29fc842 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5c62>
 29f9da2:	add    %r8d,%ecx
 29f9da5:	jb     29fc844 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5c64>
 29f9dab:	mov    %ecx,%edi
 29f9dad:	lea    (%rdx,%rdi,1),%rcx
 29f9db1:	cmp    %rax,%rdi
 29f9db4:	cmova  %rsi,%rcx
 29f9db8:	mov    %r15,%r12
 29f9dbb:	shl    $0x2,%r12d
 29f9dbf:	lea    0x14(%r12),%eax
 29f9dc4:	sub    %eax,%r8d
 29f9dc7:	sub    %r8,%rcx
 29f9dca:	mov    (%rcx),%eax
 29f9dcc:	mov    %eax,0x20(%rsp)
 29f9dd0:	test   %eax,%eax
 29f9dd2:	jne    29f9de5 <wasm[0]::function[1013]::helper::array_indexed_publish+0x3205>
 29f9dd8:	mov    0x88(%rsp),%rcx
 29f9de0:	jmp    29f9ee5 <wasm[0]::function[1013]::helper::array_indexed_publish+0x3305>
 29f9de5:	test   %eax,%eax
 29f9de7:	je     29fc846 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5c66>
 29f9ded:	mov    0x18(%rsp),%eax
 29f9df1:	test   %eax,%eax
 29f9df3:	je     29fc848 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5c68>
 29f9df9:	mov    (%r14),%eax
 29f9dfc:	mov    %eax,%esi
 29f9dfe:	lea    0x20(%rsi),%rcx
 29f9e02:	mov    0x4(%r14),%edx
 29f9e06:	cmp    %rdx,%rcx
 29f9e09:	ja     29fc1bd <wasm[0]::function[1013]::helper::array_indexed_publish+0x55dd>
 29f9e0f:	lea    0x20(%rax),%ecx
 29f9e12:	mov    %ecx,(%r14)
 29f9e15:	mov    0xc8(%rsp),%rbx
 29f9e1d:	mov    0x20(%rbx),%rdi
 29f9e21:	lea    (%rdi,%rsi,1),%rdx
 29f9e25:	movl   $0xb0000072,(%rdi,%rsi,1)
 29f9e2c:	mov    %r13d,0x4(%rdi,%rsi,1)
 29f9e31:	mov    0x88(%rsp),%rcx
 29f9e39:	mov    %ecx,0x8(%rdi,%rsi,1)
 29f9e3d:	movl   $0xe,0x10(%rdx)
 29f9e44:	mov    0x20(%rsp),%esi
 29f9e48:	mov    %esi,0x14(%rdx)
 29f9e4b:	mov    0x18(%rsp),%esi
 29f9e4f:	mov    %esi,0x18(%rdx)
 29f9e52:	mov    %esi,0x1c(%rdx)
 29f9e55:	mov    0x28(%rsp),%edx
 29f9e59:	test   %edx,%edx
 29f9e5b:	je     29fc84a <wasm[0]::function[1013]::helper::array_indexed_publish+0x5c6a>
 29f9e61:	test   %eax,%eax
 29f9e63:	je     29fc84c <wasm[0]::function[1013]::helper::array_indexed_publish+0x5c6c>
 29f9e69:	test   %edx,%edx
 29f9e6b:	je     29fc84e <wasm[0]::function[1013]::helper::array_indexed_publish+0x5c6e>
 29f9e71:	mov    0xc8(%rsp),%rbx
 29f9e79:	mov    0x28(%rbx),%rsi
 29f9e7d:	mov    0x20(%rbx),%rdi
 29f9e81:	mov    %edx,%r10d
 29f9e84:	lea    0x10(%rdi,%r10,1),%r9
 29f9e89:	xor    %r8,%r8
 29f9e8c:	cmp    %rsi,%r10
 29f9e8f:	cmova  %r8,%r9
 29f9e93:	mov    (%r9),%r9d
 29f9e96:	cmp    %r9d,%r15d
 29f9e99:	jae    29fc850 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5c70>
 29f9e9f:	mov    %r9d,%r10d
 29f9ea2:	shl    $0x2,%r10
 29f9ea6:	shr    $0x20,%r10
 29f9eaa:	test   %r10,%r10
 29f9ead:	jne    29fc852 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5c72>
 29f9eb3:	shl    $0x2,%r9d
 29f9eb7:	add    $0x14,%r9d
 29f9ebb:	jb     29fc854 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5c74>
 29f9ec1:	add    %r9d,%edx
 29f9ec4:	jb     29fc856 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5c76>
 29f9eca:	mov    %edx,%r10d
 29f9ecd:	lea    (%rdi,%r10,1),%rdx
 29f9ed1:	cmp    %rsi,%r10
 29f9ed4:	cmova  %r8,%rdx
 29f9ed8:	lea    0x14(%r12),%esi
 29f9edd:	sub    %esi,%r9d
 29f9ee0:	sub    %r9,%rdx
 29f9ee3:	mov    %eax,(%rdx)
 29f9ee5:	mov    (%rsp),%eax
 29f9ee8:	mov    0x10(%rsp),%edx
 29f9eec:	add    $0x1,%r15d
 29f9ef3:	mov    %rcx,0x88(%rsp)
 29f9efb:	jmp    29f9cfd <wasm[0]::function[1013]::helper::array_indexed_publish+0x311d>
 29f9f00:	mov    (%rsp),%edx
 29f9f03:	mov    %rdx,%rax
 29f9f06:	mov    %rdx,0x70(%rsp)
 29f9f0b:	test   %eax,%edx
 29f9f0d:	je     29fc858 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5c78>
 29f9f13:	mov    0x28(%rsp),%edi
 29f9f17:	test   %edi,%edi
 29f9f19:	je     29fc85a <wasm[0]::function[1013]::helper::array_indexed_publish+0x5c7a>
 29f9f1f:	mov    0x70(%rsp),%rax
 29f9f24:	test   %eax,%edx
 29f9f26:	je     29fc85c <wasm[0]::function[1013]::helper::array_indexed_publish+0x5c7c>
 29f9f2c:	mov    0xc8(%rsp),%rbx
 29f9f34:	mov    0x28(%rbx),%r8
 29f9f38:	mov    0x20(%rbx),%r10
 29f9f3c:	mov    %edx,%r9d
 29f9f3f:	lea    (%r10,%r9,1),%rsi
 29f9f43:	xor    %r10,%r10
 29f9f46:	cmp    %r8,%r9
 29f9f49:	cmova  %r10,%rsi
 29f9f4d:	mov    %edi,0x20(%rsi)
 29f9f50:	mov    0x60(%rsp),%rdi
 29f9f55:	mov    0xa00(%rdi),%r10d
 29f9f5c:	mov    0xa10(%rdi),%r9d
 29f9f63:	test   %r10d,%r10d
 29f9f66:	je     29fc85e <wasm[0]::function[1013]::helper::array_indexed_publish+0x5c7e>
 29f9f6c:	mov    %r10d,0x28(%rsi)
 29f9f70:	test   %r9d,%r9d
 29f9f73:	je     29fc860 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5c80>
 29f9f79:	mov    %r9d,0x2c(%rsi)
 29f9f7d:	movl   $0x0,0x30(%rsi)
 29f9f84:	movl   $0x0,0x24(%rsi)
 29f9f8b:	mov    0x10(%rsp),%edx
 29f9f8f:	mov    0xa0(%rsp),%r10
 29f9f97:	test   %r10d,%r10d
 29f9f9a:	je     29f9faa <wasm[0]::function[1013]::helper::array_indexed_publish+0x33ca>
 29f9fa0:	mov    0x70(%rsp),%rax
 29f9fa5:	jmp    29fac25 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4045>
 29f9faa:	xor    %r10d,%r10d
 29f9fad:	mov    0x70(%rsp),%rax
 29f9fb2:	mov    0x70(%rsp),%rcx
 29f9fb7:	test   %ecx,%eax
 29f9fb9:	je     29fc862 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5c82>
 29f9fbf:	test   %ecx,%eax
 29f9fc1:	je     29fc864 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5c84>
 29f9fc7:	mov    0xc8(%rsp),%rbx
 29f9fcf:	mov    0x28(%rbx),%rax
 29f9fd3:	mov    %ecx,%esi
 29f9fd5:	mov    %rsi,%rdi
 29f9fd8:	add    0x20(%rbx),%rdi
 29f9fdc:	xor    %r8,%r8
 29f9fdf:	cmp    %rax,%rsi
 29f9fe2:	cmova  %r8,%rdi
 29f9fe6:	mov    0x24(%rdi),%eax
 29f9fe9:	test   %eax,%eax
 29f9feb:	jne    29fac20 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4040>
 29f9ff1:	mov    0xc8(%rsp),%rbx
 29f9ff9:	mov    0x28(%rbx),%rdi
 29f9ffd:	mov    0x20(%rbx),%r9
 29fa001:	lea    (%r9,%rsi,1),%rax
 29fa005:	xor    %r8,%r8
 29fa008:	cmp    %rdi,%rsi
 29fa00b:	cmova  %r8,%rax
 29fa00f:	mov    $0x20,%r14d
 29fa015:	mov    %r14,0xc0(%rsp)
 29fa01d:	mov    0x20(%rax),%esi
 29fa020:	test   %esi,%esi
 29fa022:	je     29fc866 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5c86>
 29fa028:	test   %esi,%esi
 29fa02a:	je     29fc868 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5c88>
 29fa030:	mov    %esi,%r10d
 29fa033:	lea    0x10(%r9,%r10,1),%r9
 29fa038:	cmp    %rdi,%r10
 29fa03b:	cmova  %r8,%r9
 29fa03f:	mov    (%r9),%r15d
 29fa042:	mov    0x18(%rax),%r13
 29fa046:	mov    %r15d,%r12d
 29fa049:	mov    0x68(%rsp),%rcx
 29fa04e:	mov    %r15,0x78(%rsp)
 29fa053:	cmp    %r12,%rcx
 29fa056:	setb   %al
 29fa059:	cmp    $0x100000,%rcx
 29fa060:	setb   %dil
 29fa064:	lea    0x8(%r13,%r13,1),%rcx
 29fa069:	mov    0x68(%rsp),%r8
 29fa06e:	cmp    %rcx,%r8
 29fa071:	setbe  %r8b
 29fa075:	and    %r8d,%edi
 29fa078:	or     %edi,%eax
 29fa07a:	test   %al,%al
 29fa07c:	jne    29fa62d <wasm[0]::function[1013]::helper::array_indexed_publish+0x3a4d>
 29fa082:	mov    $0x8,%edi
 29fa087:	mov    %rdi,0x98(%rsp)
 29fa08f:	shl    $0x2,%r13
 29fa093:	mov    %esi,0x28(%rsp)
 29fa097:	mov    0x70(%rsp),%rax
 29fa09c:	mov    %eax,0x10(%rsp)
 29fa0a0:	mov    %edx,(%rsp)
 29fa0a3:	mov    0xd0(%rsp),%rax
 29fa0ab:	mov    (%rax),%rax
 29fa0ae:	mov    0xa8(%rsp),%rdx
 29fa0b6:	cmp    %rdx,%rax
 29fa0b9:	jae    29fc1fa <wasm[0]::function[1013]::helper::array_indexed_publish+0x561a>
 29fa0bf:	mov    0x98(%rsp),%rdi
 29fa0c7:	jmp    29fa0d4 <wasm[0]::function[1013]::helper::array_indexed_publish+0x34f4>
 29fa0cc:	mov    0x98(%rsp),%rdi
 29fa0d4:	mov    %edi,%ebx
 29fa0d6:	imul   $0x3,%rbx,%rax
 29fa0da:	cmp    %rax,%r13
 29fa0dd:	mov    %r13,0xb8(%rsp)
 29fa0e5:	jbe    29fa112 <wasm[0]::function[1013]::helper::array_indexed_publish+0x3532>
 29fa0eb:	mov    0x28(%rsp),%esi
 29fa0ef:	mov    0x10(%rsp),%edx
 29fa0f3:	mov    %rdx,0x70(%rsp)
 29fa0f8:	mov    (%rsp),%edx
 29fa0fb:	shl    $1,%edi
 29fa0fd:	mov    0xb8(%rsp),%r13
 29fa105:	mov    %rdi,0x98(%rsp)
 29fa10d:	jmp    29fa093 <wasm[0]::function[1013]::helper::array_indexed_publish+0x34b3>
 29fa112:	mov    %rbx,%r12
 29fa115:	shl    $0x2,%r12
 29fa119:	mov    %r12,%rax
 29fa11c:	shr    $0x20,%rax
 29fa120:	test   %rax,%rax
 29fa123:	jne    29fc86a <wasm[0]::function[1013]::helper::array_indexed_publish+0x5c8a>
 29fa129:	mov    %rdi,%rcx
 29fa12c:	shl    $0x2,%ecx
 29fa12f:	mov    %rdi,0x98(%rsp)
 29fa137:	add    $0x14,%ecx
 29fa13a:	jb     29fc86c <wasm[0]::function[1013]::helper::array_indexed_publish+0x5c8c>
 29fa140:	mov    0x60(%rsp),%rdi
 29fa145:	mov    0x20(%rdi),%rdi
 29fa149:	mov    (%rdi),%eax
 29fa14b:	mov    %eax,%edx
 29fa14d:	mov    %ecx,%esi
 29fa14f:	add    $0xf,%rsi
 29fa156:	mov    %rsi,%r8
 29fa159:	and    $0xfffffffffffffff0,%r8
 29fa15d:	add    %rdx,%r8
 29fa160:	mov    0x4(%rdi),%r9d
 29fa164:	mov    %rdi,0xb0(%rsp)
 29fa16c:	cmp    %r9,%r8
 29fa16f:	ja     29fc239 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5659>
 29fa175:	add    $0xf,%ecx
 29fa17b:	and    $0xfffffff0,%ecx
 29fa17e:	lea    (%rax,%rcx,1),%edi
 29fa181:	mov    0xb0(%rsp),%rcx
 29fa189:	mov    %edi,(%rcx)
 29fa18b:	mov    0xc8(%rsp),%rcx
 29fa193:	mov    0x20(%rcx),%rdi
 29fa197:	lea    (%rdi,%rdx,1),%rcx
 29fa19b:	movl   $0xa800000e,(%rdi,%rdx,1)
 29fa1a2:	mov    0x60(%rsp),%r8
 29fa1a7:	mov    0x28(%r8),%r8
 29fa1ab:	mov    0x1ac(%r8),%r8d
 29fa1b2:	mov    %r8d,0x4(%rdi,%rdx,1)
 29fa1b7:	and    $0xfffffffffffffff0,%rsi
 29fa1bb:	mov    %esi,0x8(%rdi,%rdx,1)
 29fa1bf:	mov    %eax,0x18(%rsp)
 29fa1c3:	mov    0x98(%rsp),%r13
 29fa1cb:	mov    %r13d,0x10(%rcx)
 29fa1cf:	test   %eax,%eax
 29fa1d1:	je     29fc86e <wasm[0]::function[1013]::helper::array_indexed_publish+0x5c8e>
 29fa1d7:	mov    0xc8(%rsp),%r9
 29fa1df:	mov    0x28(%r9),%r9
 29fa1e3:	mov    0xc8(%rsp),%r11
 29fa1eb:	mov    0x20(%r11),%r10
 29fa1ef:	mov    %eax,%r11d
 29fa1f2:	lea    (%r10,%r11,1),%r8
 29fa1f6:	lea    0x10(%r10,%r11,1),%rsi
 29fa1fb:	xor    %rax,%rax
 29fa1fe:	cmp    %r9,%r11
 29fa201:	cmova  %rax,%rsi
 29fa205:	mov    (%rsi),%eax
 29fa207:	cmp    %rax,%rbx
 29fa20a:	ja     29fc870 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5c90>
 29fa210:	lea    0x14(%r10,%r11,1),%r15
 29fa215:	mov    %r15,%r11
 29fa218:	add    %r12,%r11
 29fa21b:	jb     29fc872 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5c92>
 29fa221:	lea    (%r10,%r9,1),%rax
 29fa225:	cmp    %rax,%r11
 29fa228:	ja     29fc874 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5c94>
 29fa22e:	mov    0x28(%rsp),%ecx
 29fa232:	mov    0x10(%rsp),%eax
 29fa236:	mov    (%rsp),%esi
 29fa239:	lea    0x14(%r8,%rbx,4),%r14
 29fa23e:	test   %rbx,%rbx
 29fa241:	je     29fa290 <wasm[0]::function[1013]::helper::array_indexed_publish+0x36b0>
 29fa247:	mov    %ecx,(%rsp)
 29fa24a:	mov    %eax,0x10(%rsp)
 29fa24e:	mov    %esi,0x28(%rsp)
 29fa252:	mov    0xd0(%rsp),%rax
 29fa25a:	mov    (%rax),%rax
 29fa25d:	mov    0xa8(%rsp),%rcx
 29fa265:	cmp    %rcx,%rax
 29fa268:	jae    29fc26b <wasm[0]::function[1013]::helper::array_indexed_publish+0x568b>
 29fa26e:	movl   $0x0,(%r15)
 29fa275:	mov    (%rsp),%ecx
 29fa278:	mov    0x10(%rsp),%eax
 29fa27c:	mov    0x28(%rsp),%esi
 29fa280:	add    $0x4,%r15
 29fa287:	cmp    %r14,%r15
 29fa28a:	jne    29fa247 <wasm[0]::function[1013]::helper::array_indexed_publish+0x3667>
 29fa290:	mov    %ecx,(%rsp)
 29fa293:	xor    %r12d,%r12d
 29fa296:	mov    $0x10,%ecx
 29fa29b:	mov    0x60(%rsp),%rdi
 29fa2a0:	mov    %rcx,0x80(%rsp)
 29fa2a8:	mov    0x28(%rdi),%rcx
 29fa2ac:	mov    0x1a8(%rcx),%r15d
 29fa2b3:	mov    %r15,0x90(%rsp)
 29fa2bb:	mov    $0x20,%ecx
 29fa2c0:	mov    %rcx,0x88(%rsp)
 29fa2c8:	mov    %eax,0x28(%rsp)
 29fa2cc:	mov    %esi,0x10(%rsp)
 29fa2d0:	mov    0xd0(%rsp),%rax
 29fa2d8:	mov    (%rax),%rax
 29fa2db:	mov    0xa8(%rsp),%rsi
 29fa2e3:	cmp    %rsi,%rax
 29fa2e6:	jae    29fc29f <wasm[0]::function[1013]::helper::array_indexed_publish+0x56bf>
 29fa2ec:	mov    0x78(%rsp),%rcx
 29fa2f1:	jmp    29fa2fb <wasm[0]::function[1013]::helper::array_indexed_publish+0x371b>
 29fa2f6:	mov    0x78(%rsp),%rcx
 29fa2fb:	cmp    %ecx,%r12d
 29fa2fe:	mov    %rcx,0x78(%rsp)
 29fa303:	jae    29fa5b8 <wasm[0]::function[1013]::helper::array_indexed_publish+0x39d8>
 29fa309:	mov    (%rsp),%eax
 29fa30c:	test   %eax,%eax
 29fa30e:	je     29fc876 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5c96>
 29fa314:	test   %eax,%eax
 29fa316:	je     29fc878 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5c98>
 29fa31c:	mov    0xc8(%rsp),%rbx
 29fa324:	mov    0x28(%rbx),%rcx
 29fa328:	mov    0x20(%rbx),%rdx
 29fa32c:	mov    %eax,%r8d
 29fa32f:	lea    0x10(%rdx,%r8,1),%rdi
 29fa334:	xor    %rsi,%rsi
 29fa337:	cmp    %rcx,%r8
 29fa33a:	cmova  %rsi,%rdi
 29fa33e:	mov    (%rdi),%edi
 29fa340:	cmp    %edi,%r12d
 29fa343:	jae    29fc87a <wasm[0]::function[1013]::helper::array_indexed_publish+0x5c9a>
 29fa349:	mov    %edi,%r8d
 29fa34c:	shl    $0x2,%r8
 29fa350:	shr    $0x20,%r8
 29fa354:	test   %r8,%r8
 29fa357:	jne    29fc87c <wasm[0]::function[1013]::helper::array_indexed_publish+0x5c9c>
 29fa35d:	shl    $0x2,%edi
 29fa360:	add    $0x14,%edi
 29fa363:	jb     29fc87e <wasm[0]::function[1013]::helper::array_indexed_publish+0x5c9e>
 29fa369:	add    %edi,%eax
 29fa36b:	jb     29fc880 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5ca0>
 29fa371:	mov    %eax,%r8d
 29fa374:	lea    (%rdx,%r8,1),%rax
 29fa378:	cmp    %rcx,%r8
 29fa37b:	cmova  %rsi,%rax
 29fa37f:	mov    %r12,%rcx
 29fa382:	shl    $0x2,%ecx
 29fa385:	add    $0x14,%ecx
 29fa38b:	sub    %ecx,%edi
 29fa38d:	sub    %rdi,%rax
 29fa390:	mov    (%rax),%eax
 29fa392:	mov    %eax,0x8(%rsp)
 29fa396:	test   %eax,%eax
 29fa398:	jne    29fa3bb <wasm[0]::function[1013]::helper::array_indexed_publish+0x37db>
 29fa39e:	mov    0xc0(%rsp),%rcx
 29fa3a6:	mov    0x90(%rsp),%rdx
 29fa3ae:	mov    0xb0(%rsp),%r15
 29fa3b6:	jmp    29fa58c <wasm[0]::function[1013]::helper::array_indexed_publish+0x39ac>
 29fa3bb:	mov    0x18(%rsp),%ecx
 29fa3bf:	test   %ecx,%ecx
 29fa3c1:	je     29fc882 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5ca2>
 29fa3c7:	test   %ecx,%ecx
 29fa3c9:	je     29fc884 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5ca4>
 29fa3cf:	mov    0xc8(%rsp),%rbx
 29fa3d7:	mov    0x28(%rbx),%rsi
 29fa3db:	mov    0x20(%rbx),%rdi
 29fa3df:	mov    %ecx,%r9d
 29fa3e2:	lea    0x10(%rdi,%r9,1),%rdx
 29fa3e7:	xor    %r8,%r8
 29fa3ea:	cmp    %rsi,%r9
 29fa3ed:	cmova  %r8,%rdx
 29fa3f1:	mov    (%rdx),%edx
 29fa3f3:	mov    %r12,%r9
 29fa3f6:	shr    $0x10,%r9d
 29fa3fa:	mov    %r12,%r10
 29fa3fd:	xor    %r9d,%r10d
 29fa400:	imul   $0x7feb352d,%r10d,%r9d
 29fa407:	mov    %r9,%r10
 29fa40a:	shr    $0xf,%r10d
 29fa40e:	xor    %r10d,%r9d
 29fa411:	imul   $0x846ca68b,%r9d,%r13d
 29fa418:	mov    %r13,%r9
 29fa41b:	shr    $0x10,%r9d
 29fa41f:	xor    %r9d,%r13d
 29fa422:	mov    0x98(%rsp),%r9
 29fa42a:	sub    $0x1,%r9d
 29fa42e:	and    %r9d,%r13d
 29fa431:	cmp    %edx,%r13d
 29fa434:	jae    29fc886 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5ca6>
 29fa43a:	mov    %edx,%r9d
 29fa43d:	shl    $0x2,%r9
 29fa441:	shr    $0x20,%r9
 29fa445:	test   %r9,%r9
 29fa448:	jne    29fc888 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5ca8>
 29fa44e:	shl    $0x2,%edx
 29fa451:	add    $0x14,%edx
 29fa454:	jb     29fc88a <wasm[0]::function[1013]::helper::array_indexed_publish+0x5caa>
 29fa45a:	add    %edx,%ecx
 29fa45c:	jb     29fc88c <wasm[0]::function[1013]::helper::array_indexed_publish+0x5cac>
 29fa462:	mov    %ecx,%r10d
 29fa465:	add    %r10,%rdi
 29fa468:	cmp    %rsi,%r10
 29fa46b:	cmova  %r8,%rdi
 29fa46f:	mov    %r13,%r14
 29fa472:	shl    $0x2,%r14d
 29fa476:	lea    0x14(%r14),%r11d
 29fa47a:	sub    %r11d,%edx
 29fa47d:	sub    %rdx,%rdi
 29fa480:	mov    (%rdi),%r11d
 29fa483:	mov    %r11d,0x20(%rsp)
 29fa488:	test   %eax,%eax
 29fa48a:	je     29fc88e <wasm[0]::function[1013]::helper::array_indexed_publish+0x5cae>
 29fa490:	mov    0xb0(%rsp),%r15
 29fa498:	mov    (%r15),%eax
 29fa49b:	mov    %eax,%edi
 29fa49d:	lea    0x20(%rdi),%rcx
 29fa4a1:	mov    0x4(%r15),%edx
 29fa4a5:	cmp    %rdx,%rcx
 29fa4a8:	ja     29fc2db <wasm[0]::function[1013]::helper::array_indexed_publish+0x56fb>
 29fa4ae:	lea    0x20(%rax),%ecx
 29fa4b1:	mov    %ecx,(%r15)
 29fa4b4:	mov    0xc8(%rsp),%rbx
 29fa4bc:	mov    0x20(%rbx),%r8
 29fa4c0:	lea    (%r8,%rdi,1),%rsi
 29fa4c4:	movl   $0xb0000062,(%r8,%rdi,1)
 29fa4cc:	mov    0x90(%rsp),%rdx
 29fa4d4:	mov    %edx,0x4(%r8,%rdi,1)
 29fa4d9:	mov    0xc0(%rsp),%rcx
 29fa4e1:	mov    %ecx,0x8(%r8,%rdi,1)
 29fa4e6:	mov    %r12d,%edi
 29fa4e9:	mov    %rdi,0x10(%rsi)
 29fa4ed:	mov    0x8(%rsp),%edi
 29fa4f1:	mov    %edi,0x18(%rsi)
 29fa4f4:	mov    0x20(%rsp),%edi
 29fa4f8:	mov    %edi,0x1c(%rsi)
 29fa4fb:	mov    0x18(%rsp),%r11d
 29fa500:	test   %r11d,%r11d
 29fa503:	je     29fc890 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5cb0>
 29fa509:	test   %eax,%eax
 29fa50b:	je     29fc892 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5cb2>
 29fa511:	test   %r11d,%r11d
 29fa514:	je     29fc894 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5cb4>
 29fa51a:	mov    0xc8(%rsp),%rbx
 29fa522:	mov    0x28(%rbx),%rsi
 29fa526:	mov    0x20(%rbx),%rdi
 29fa52a:	mov    %r11d,%r10d
 29fa52d:	lea    0x10(%rdi,%r10,1),%r9
 29fa532:	xor    %r8,%r8
 29fa535:	cmp    %rsi,%r10
 29fa538:	cmova  %r8,%r9
 29fa53c:	mov    (%r9),%r9d
 29fa53f:	cmp    %r9d,%r13d
 29fa542:	jae    29fc896 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5cb6>
 29fa548:	mov    %r9d,%r10d
 29fa54b:	shl    $0x2,%r10
 29fa54f:	shr    $0x20,%r10
 29fa553:	test   %r10,%r10
 29fa556:	jne    29fc898 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5cb8>
 29fa55c:	shl    $0x2,%r9d
 29fa560:	add    $0x14,%r9d
 29fa564:	jb     29fc89a <wasm[0]::function[1013]::helper::array_indexed_publish+0x5cba>
 29fa56a:	add    %r9d,%r11d
 29fa56d:	jb     29fc89c <wasm[0]::function[1013]::helper::array_indexed_publish+0x5cbc>
 29fa573:	mov    %r11d,%r10d
 29fa576:	add    %r10,%rdi
 29fa579:	cmp    %rsi,%r10
 29fa57c:	cmova  %r8,%rdi
 29fa580:	lea    0x14(%r14),%esi
 29fa584:	sub    %esi,%r9d
 29fa587:	sub    %r9,%rdi
 29fa58a:	mov    %eax,(%rdi)
 29fa58c:	mov    0x28(%rsp),%eax
 29fa590:	mov    0x10(%rsp),%esi
 29fa594:	add    $0x1,%r12d
 29fa59b:	mov    %rdx,0x90(%rsp)
 29fa5a3:	mov    %r15,0xb0(%rsp)
 29fa5ab:	mov    %rcx,0xc0(%rsp)
 29fa5b3:	jmp    29fa2c8 <wasm[0]::function[1013]::helper::array_indexed_publish+0x36e8>
 29fa5b8:	mov    0x60(%rsp),%rdi
 29fa5bd:	mov    0x9f0(%rdi),%eax
 29fa5c3:	mov    0x28(%rsp),%edx
 29fa5c7:	mov    %rdx,0x70(%rsp)
 29fa5cc:	xor    %r10d,%r10d
 29fa5cf:	mov    0x70(%rsp),%rcx
 29fa5d4:	test   %ecx,%edx
 29fa5d6:	je     29fc89e <wasm[0]::function[1013]::helper::array_indexed_publish+0x5cbe>
 29fa5dc:	test   %eax,%eax
 29fa5de:	je     29fc8a0 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5cc0>
 29fa5e4:	test   %ecx,%edx
 29fa5e6:	je     29fc8a2 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5cc2>
 29fa5ec:	mov    0xc8(%rsp),%rbx
 29fa5f4:	mov    0x28(%rbx),%rsi
 29fa5f8:	mov    0x20(%rbx),%rdx
 29fa5fc:	mov    %ecx,%edi
 29fa5fe:	add    %rdi,%rdx
 29fa601:	xor    %r8,%r8
 29fa604:	cmp    %rsi,%rdi
 29fa607:	cmova  %r8,%rdx
 29fa60b:	mov    %eax,0x20(%rdx)
 29fa60e:	mov    0x18(%rsp),%eax
 29fa612:	test   %eax,%eax
 29fa614:	je     29fc8a4 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5cc4>
 29fa61a:	mov    %eax,0x10(%rdx)
 29fa61d:	movl   $0x1,0x24(%rdx)
 29fa624:	mov    0x10(%rsp),%edx
 29fa628:	jmp    29fac20 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4040>
 29fa62d:	mov    0x68(%rsp),%rcx
 29fa632:	mov    %r13,0xb8(%rsp)
 29fa63a:	cmp    %r12,%rcx
 29fa63d:	jb     29faac1 <wasm[0]::function[1013]::helper::array_indexed_publish+0x3ee1>
 29fa643:	mov    0x78(%rsp),%rax
 29fa648:	mov    0x78(%rsp),%rbx
 29fa64d:	test   %eax,%ebx
 29fa64f:	je     29fa65f <wasm[0]::function[1013]::helper::array_indexed_publish+0x3a7f>
 29fa655:	mov    0x78(%rsp),%r15
 29fa65a:	jmp    29fa665 <wasm[0]::function[1013]::helper::array_indexed_publish+0x3a85>
 29fa65f:	mov    $0x8,%r15d
 29fa665:	mov    %esi,0x18(%rsp)
 29fa669:	mov    0x70(%rsp),%rax
 29fa66e:	mov    %eax,0x10(%rsp)
 29fa672:	mov    %edx,0x28(%rsp)
 29fa676:	mov    0xd0(%rsp),%rax
 29fa67e:	mov    (%rax),%rsi
 29fa681:	mov    0xa8(%rsp),%rax
 29fa689:	cmp    %rax,%rsi
 29fa68c:	jae    29fc325 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5745>
 29fa692:	mov    %r15d,%r14d
 29fa695:	mov    0x68(%rsp),%rcx
 29fa69a:	cmp    %r14,%rcx
 29fa69d:	jb     29fa6bc <wasm[0]::function[1013]::helper::array_indexed_publish+0x3adc>
 29fa6a3:	mov    0x18(%rsp),%esi
 29fa6a7:	mov    0x10(%rsp),%edx
 29fa6ab:	mov    %rdx,0x70(%rsp)
 29fa6b0:	mov    0x28(%rsp),%edx
 29fa6b4:	shl    $1,%r15d
 29fa6b7:	jmp    29fa665 <wasm[0]::function[1013]::helper::array_indexed_publish+0x3a85>
 29fa6bc:	mov    %r14,%r13
 29fa6bf:	shl    $0x2,%r13
 29fa6c3:	mov    %r13,%rax
 29fa6c6:	shr    $0x20,%rax
 29fa6ca:	test   %rax,%rax
 29fa6cd:	jne    29fc8a6 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5cc6>
 29fa6d3:	mov    %r15,%rcx
 29fa6d6:	shl    $0x2,%ecx
 29fa6d9:	add    $0x14,%ecx
 29fa6dc:	jb     29fc8a8 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5cc8>
 29fa6e2:	mov    0x60(%rsp),%rdi
 29fa6e7:	mov    0x20(%rdi),%rdi
 29fa6eb:	mov    (%rdi),%eax
 29fa6ed:	mov    %eax,%edx
 29fa6ef:	mov    %ecx,%esi
 29fa6f1:	add    $0xf,%rsi
 29fa6f8:	mov    %rsi,%r8
 29fa6fb:	and    $0xfffffffffffffff0,%r8
 29fa6ff:	add    %rdx,%r8
 29fa702:	mov    0x4(%rdi),%r9d
 29fa706:	cmp    %r9,%r8
 29fa709:	ja     29fc359 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5779>
 29fa70f:	add    $0xf,%ecx
 29fa715:	and    $0xfffffff0,%ecx
 29fa718:	add    %eax,%ecx
 29fa71a:	mov    %ecx,(%rdi)
 29fa71c:	mov    0xc8(%rsp),%rbx
 29fa724:	mov    0x20(%rbx),%rcx
 29fa728:	lea    (%rcx,%rdx,1),%rdi
 29fa72c:	movl   $0xa800000e,(%rcx,%rdx,1)
 29fa733:	mov    0x60(%rsp),%r8
 29fa738:	mov    0x28(%r8),%r8
 29fa73c:	mov    0x194(%r8),%r8d
 29fa743:	mov    %r8d,0x4(%rcx,%rdx,1)
 29fa748:	and    $0xfffffffffffffff0,%rsi
 29fa74c:	mov    %esi,0x8(%rcx,%rdx,1)
 29fa750:	mov    %eax,(%rsp)
 29fa753:	mov    %r15d,0x10(%rdi)
 29fa757:	test   %eax,%eax
 29fa759:	je     29fc8aa <wasm[0]::function[1013]::helper::array_indexed_publish+0x5cca>
 29fa75f:	mov    0xc8(%rsp),%rbx
 29fa767:	mov    0x28(%rbx),%rcx
 29fa76b:	mov    0x20(%rbx),%rdx
 29fa76f:	mov    %eax,%eax
 29fa771:	lea    (%rdx,%rax,1),%rsi
 29fa775:	lea    0x10(%rdx,%rax,1),%rdi
 29fa77a:	xor    %r8,%r8
 29fa77d:	cmp    %rcx,%rax
 29fa780:	cmova  %r8,%rdi
 29fa784:	mov    (%rdi),%edi
 29fa786:	cmp    %rdi,%r14
 29fa789:	ja     29fc8ac <wasm[0]::function[1013]::helper::array_indexed_publish+0x5ccc>
 29fa78f:	lea    0x14(%rdx,%rax,1),%r15
 29fa794:	mov    %r15,%rdi
 29fa797:	add    %r13,%rdi
 29fa79a:	jb     29fc8ae <wasm[0]::function[1013]::helper::array_indexed_publish+0x5cce>
 29fa7a0:	lea    (%rdx,%rcx,1),%rax
 29fa7a4:	cmp    %rax,%rdi
 29fa7a7:	ja     29fc8b0 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5cd0>
 29fa7ad:	mov    0x18(%rsp),%edi
 29fa7b1:	mov    0x10(%rsp),%edx
 29fa7b5:	mov    %rdx,0x70(%rsp)
 29fa7ba:	mov    0x28(%rsp),%edx
 29fa7be:	lea    0x14(%rsi,%r14,4),%rbx
 29fa7c3:	test   %r14,%r14
 29fa7c6:	je     29fa821 <wasm[0]::function[1013]::helper::array_indexed_publish+0x3c41>
 29fa7cc:	mov    %edi,0x28(%rsp)
 29fa7d0:	mov    0x70(%rsp),%rax
 29fa7d5:	mov    %eax,0x10(%rsp)
 29fa7d9:	mov    %edx,0x18(%rsp)
 29fa7dd:	mov    0xd0(%rsp),%rax
 29fa7e5:	mov    (%rax),%rcx
 29fa7e8:	mov    0xa8(%rsp),%rax
 29fa7f0:	cmp    %rax,%rcx
 29fa7f3:	jae    29fc38b <wasm[0]::function[1013]::helper::array_indexed_publish+0x57ab>
 29fa7f9:	movl   $0x0,(%r15)
 29fa800:	mov    0x28(%rsp),%edi
 29fa804:	mov    0x10(%rsp),%edx
 29fa808:	mov    %rdx,0x70(%rsp)
 29fa80d:	mov    0x18(%rsp),%edx
 29fa811:	add    $0x4,%r15
 29fa818:	cmp    %rbx,%r15
 29fa81b:	jne    29fa7cc <wasm[0]::function[1013]::helper::array_indexed_publish+0x3bec>
 29fa821:	mov    (%rsp),%esi
 29fa824:	test   %esi,%esi
 29fa826:	je     29fc8b2 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5cd2>
 29fa82c:	test   %edi,%edi
 29fa82e:	je     29fc8b4 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5cd4>
 29fa834:	test   %esi,%esi
 29fa836:	je     29fc8b6 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5cd6>
 29fa83c:	mov    0xc8(%rsp),%rbx
 29fa844:	mov    0x28(%rbx),%r10
 29fa848:	mov    0x20(%rbx),%rax
 29fa84c:	mov    %rax,0x88(%rsp)
 29fa854:	mov    %esi,%eax
 29fa856:	mov    0x88(%rsp),%r9
 29fa85e:	lea    (%r9,%rax,1),%r8
 29fa862:	mov    %r9,%rcx
 29fa865:	lea    0x10(%rcx,%rax,1),%r9
 29fa86a:	xor    %r11,%r11
 29fa86d:	cmp    %r10,%rax
 29fa870:	cmova  %r11,%r9
 29fa874:	mov    (%r9),%ecx
 29fa877:	cmp    %rcx,%r12
 29fa87a:	ja     29fc8b8 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5cd8>
 29fa880:	test   %edi,%edi
 29fa882:	je     29fc8ba <wasm[0]::function[1013]::helper::array_indexed_publish+0x5cda>
 29fa888:	mov    %edi,%r14d
 29fa88b:	mov    0x88(%rsp),%rcx
 29fa893:	mov    %r14,%rbx
 29fa896:	lea    (%rcx,%rbx,1),%r9
 29fa89a:	mov    %rbx,0x80(%rsp)
 29fa8a2:	lea    0x10(%rcx,%r14,1),%rbx
 29fa8a7:	mov    0x80(%rsp),%r14
 29fa8af:	cmp    %r10,%r14
 29fa8b2:	cmova  %r11,%rbx
 29fa8b6:	mov    (%rbx),%r11d
 29fa8b9:	cmp    %r11,%r12
 29fa8bc:	ja     29fc8bc <wasm[0]::function[1013]::helper::array_indexed_publish+0x5cdc>
 29fa8c2:	mov    0x88(%rsp),%r11
 29fa8ca:	lea    0x14(%r11,%rax,1),%rbx
 29fa8cf:	mov    %r12,%r11
 29fa8d2:	shl    $0x2,%r11
 29fa8d6:	add    %r11,%rbx
 29fa8d9:	jb     29fc8be <wasm[0]::function[1013]::helper::array_indexed_publish+0x5cde>
 29fa8df:	add    %rcx,%r10
 29fa8e2:	cmp    %r10,%rbx
 29fa8e5:	ja     29fc8c0 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5ce0>
 29fa8eb:	lea    0x14(%rcx,%r14,1),%r13
 29fa8f0:	add    %r11,%r13
 29fa8f3:	jb     29fc8c2 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5ce2>
 29fa8f9:	cmp    %r10,%r13
 29fa8fc:	ja     29fc8c4 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5ce4>
 29fa902:	mov    0x78(%rsp),%rcx
 29fa907:	mov    0x78(%rsp),%rbx
 29fa90c:	test   %ecx,%ebx
 29fa90e:	jne    29fa923 <wasm[0]::function[1013]::helper::array_indexed_publish+0x3d43>
 29fa914:	mov    0x70(%rsp),%rax
 29fa919:	mov    0x70(%rsp),%rcx
 29fa91e:	jmp    29faa7c <wasm[0]::function[1013]::helper::array_indexed_publish+0x3e9c>
 29fa923:	mov    (%rsp),%r10d
 29fa927:	mov    0x88(%rsp),%rcx
 29fa92f:	lea    0x14(%rcx,%rax,1),%r13
 29fa934:	mov    0x88(%rsp),%rax
 29fa93c:	mov    0x80(%rsp),%r14
 29fa944:	lea    0x14(%rax,%r14,1),%r14
 29fa949:	xor    %ebx,%ebx
 29fa94b:	lea    0x14(%r8,%r12,4),%r15
 29fa950:	lea    0x14(%r9,%r12,4),%r12
 29fa955:	cmp    %r14,%r13
 29fa958:	jae    29fa966 <wasm[0]::function[1013]::helper::array_indexed_publish+0x3d86>
 29fa95e:	mov    %r10,%rsi
 29fa961:	jmp    29faa00 <wasm[0]::function[1013]::helper::array_indexed_publish+0x3e20>
 29fa966:	mov    %r10,%rsi
 29fa969:	mov    %r10d,0x20(%rsp)
 29fa96e:	mov    %edi,0x18(%rsp)
 29fa972:	mov    0x70(%rsp),%rax
 29fa977:	mov    %eax,0x10(%rsp)
 29fa97b:	mov    %esi,0x28(%rsp)
 29fa97f:	mov    %edx,(%rsp)
 29fa982:	mov    0xd0(%rsp),%rax
 29fa98a:	mov    (%rax),%rax
 29fa98d:	mov    0xa8(%rsp),%r8
 29fa995:	cmp    %r8,%rax
 29fa998:	jae    29fc3bf <wasm[0]::function[1013]::helper::array_indexed_publish+0x57df>
 29fa99e:	sub    $0x4,%r12
 29fa9a2:	mov    (%r12),%eax
 29fa9a6:	sub    $0x4,%r15
 29fa9aa:	mov    %eax,(%r15)
 29fa9ad:	mov    0x10(%rsp),%edx
 29fa9b1:	mov    %rdx,0x70(%rsp)
 29fa9b6:	mov    0x28(%rsp),%esi
 29fa9ba:	mov    (%rsp),%edx
 29fa9bd:	mov    0x20(%rsp),%r10d
 29fa9c2:	mov    0x18(%rsp),%edi
 29fa9c6:	mov    0x88(%rsp),%rax
 29fa9ce:	mov    0x80(%rsp),%r14
 29fa9d6:	lea    0x14(%rax,%r14,1),%rax
 29fa9db:	mov    0x78(%rsp),%rbx
 29fa9e0:	sub    $0x1,%ebx
 29fa9e3:	mov    %rbx,0x78(%rsp)
 29fa9e8:	cmp    %rax,%r12
 29fa9eb:	jne    29fa969 <wasm[0]::function[1013]::helper::array_indexed_publish+0x3d89>
 29fa9f1:	mov    0x70(%rsp),%rax
 29fa9f6:	mov    0x70(%rsp),%rcx
 29fa9fb:	jmp    29faa7c <wasm[0]::function[1013]::helper::array_indexed_publish+0x3e9c>
 29faa00:	mov    %r10d,0x18(%rsp)
 29faa05:	mov    %edi,0x20(%rsp)
 29faa09:	mov    0x70(%rsp),%rax
 29faa0e:	mov    %eax,(%rsp)
 29faa11:	mov    %esi,0x28(%rsp)
 29faa15:	mov    %edx,0x10(%rsp)
 29faa19:	mov    0xd0(%rsp),%rax
 29faa21:	mov    (%rax),%rcx
 29faa24:	mov    0xa8(%rsp),%rax
 29faa2c:	cmp    %rax,%rcx
 29faa2f:	jae    29fc3f3 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5813>
 29faa35:	mov    (%r14),%eax
 29faa38:	mov    %eax,0x0(%r13)
 29faa3c:	mov    (%rsp),%edx
 29faa3f:	mov    %rdx,0x70(%rsp)
 29faa44:	mov    0x28(%rsp),%esi
 29faa48:	mov    0x10(%rsp),%edx
 29faa4c:	mov    0x18(%rsp),%r10d
 29faa51:	mov    0x20(%rsp),%edi
 29faa55:	add    $0x4,%r14
 29faa5c:	add    $0x4,%r13
 29faa63:	add    $0x1,%ebx
 29faa69:	cmp    %r12,%r14
 29faa6c:	jne    29faa00 <wasm[0]::function[1013]::helper::array_indexed_publish+0x3e20>
 29faa72:	mov    0x70(%rsp),%rax
 29faa77:	mov    0x70(%rsp),%rcx
 29faa7c:	test   %ecx,%eax
 29faa7e:	je     29fc8c6 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5ce6>
 29faa84:	test   %esi,%esi
 29faa86:	je     29fc8c8 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5ce8>
 29faa8c:	mov    0x70(%rsp),%rax
 29faa91:	mov    0x70(%rsp),%rcx
 29faa96:	test   %ecx,%eax
 29faa98:	je     29fc8ca <wasm[0]::function[1013]::helper::array_indexed_publish+0x5cea>
 29faa9e:	mov    0xc8(%rsp),%rbx
 29faaa6:	mov    0x28(%rbx),%rax
 29faaaa:	mov    %ecx,%r8d
 29faaad:	mov    %r8,%rdi
 29faab0:	add    0x20(%rbx),%rdi
 29faab4:	xor    %r9,%r9
 29faab7:	cmp    %rax,%r8
 29faaba:	cmova  %r9,%rdi
 29faabe:	mov    %esi,0x20(%rdi)
 29faac1:	test   %esi,%esi
 29faac3:	je     29fc8cc <wasm[0]::function[1013]::helper::array_indexed_publish+0x5cec>
 29faac9:	test   %esi,%esi
 29faacb:	je     29fc8ce <wasm[0]::function[1013]::helper::array_indexed_publish+0x5cee>
 29faad1:	mov    0xc8(%rsp),%rbx
 29faad9:	mov    0x28(%rbx),%r8
 29faadd:	mov    0x20(%rbx),%r9
 29faae1:	mov    %esi,%edi
 29faae3:	lea    0x10(%r9,%rdi,1),%rax
 29faae8:	xor    %r10,%r10
 29faaeb:	cmp    %r8,%rdi
 29faaee:	cmova  %r10,%rax
 29faaf2:	mov    (%rax),%eax
 29faaf4:	mov    0x68(%rsp),%rcx
 29faaf9:	cmp    %eax,%ecx
 29faafb:	jae    29fc8d0 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5cf0>
 29fab01:	mov    %eax,%r11d
 29fab04:	shl    $0x2,%r11
 29fab08:	shr    $0x20,%r11
 29fab0c:	test   %r11,%r11
 29fab0f:	jne    29fc8d2 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5cf2>
 29fab15:	shl    $0x2,%eax
 29fab18:	add    $0x14,%eax
 29fab1b:	jb     29fc8d4 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5cf4>
 29fab21:	mov    %rsi,%r11
 29fab24:	add    %eax,%r11d
 29fab27:	jb     29fc8d6 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5cf6>
 29fab2d:	mov    %r11d,%r12d
 29fab30:	lea    (%r9,%r12,1),%r11
 29fab34:	cmp    %r8,%r12
 29fab37:	cmova  %r10,%r11
 29fab3b:	mov    %rcx,%r9
 29fab3e:	shl    $0x2,%r9d
 29fab42:	add    $0x14,%r9d
 29fab49:	sub    %r9d,%eax
 29fab4c:	sub    %rax,%r11
 29fab4f:	mov    (%r11),%r10d
 29fab52:	test   %r10d,%r10d
 29fab55:	jne    29faba5 <wasm[0]::function[1013]::helper::array_indexed_publish+0x3fc5>
 29fab5b:	mov    0x70(%rsp),%rax
 29fab60:	mov    0x70(%rsp),%rcx
 29fab65:	test   %ecx,%eax
 29fab67:	je     29fc8d8 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5cf8>
 29fab6d:	test   %ecx,%eax
 29fab6f:	je     29fc8da <wasm[0]::function[1013]::helper::array_indexed_publish+0x5cfa>
 29fab75:	mov    0xc8(%rsp),%rbx
 29fab7d:	mov    0x28(%rbx),%r8
 29fab81:	mov    0xb8(%rsp),%r13
 29fab89:	lea    0x1(%r13),%rax
 29fab8d:	mov    %ecx,%r11d
 29fab90:	mov    %r11,%r10
 29fab93:	add    0x20(%rbx),%r10
 29fab97:	xor    %rbx,%rbx
 29fab9a:	cmp    %r8,%r11
 29fab9d:	cmova  %rbx,%r10
 29faba1:	mov    %rax,0x18(%r10)
 29faba5:	test   %edx,%edx
 29faba7:	je     29fc8dc <wasm[0]::function[1013]::helper::array_indexed_publish+0x5cfc>
 29fabad:	mov    0xc8(%rsp),%rbx
 29fabb5:	mov    0x28(%rbx),%rax
 29fabb9:	mov    0x20(%rbx),%r10
 29fabbd:	lea    0x10(%r10,%rdi,1),%r11
 29fabc2:	xor    %r8,%r8
 29fabc5:	cmp    %rax,%rdi
 29fabc8:	cmova  %r8,%r11
 29fabcc:	mov    (%r11),%edi
 29fabcf:	mov    0x68(%rsp),%rcx
 29fabd4:	cmp    %edi,%ecx
 29fabd6:	jae    29fc8de <wasm[0]::function[1013]::helper::array_indexed_publish+0x5cfe>
 29fabdc:	mov    %edi,%r11d
 29fabdf:	shl    $0x2,%r11
 29fabe3:	shr    $0x20,%r11
 29fabe7:	test   %r11,%r11
 29fabea:	jne    29fc8e0 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5d00>
 29fabf0:	shl    $0x2,%edi
 29fabf3:	add    $0x14,%edi
 29fabf6:	jb     29fc8e2 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5d02>
 29fabfc:	add    %edi,%esi
 29fabfe:	jb     29fc8e4 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5d04>
 29fac04:	mov    %esi,%r11d
 29fac07:	lea    (%r10,%r11,1),%rsi
 29fac0b:	cmp    %rax,%r11
 29fac0e:	cmova  %r8,%rsi
 29fac12:	sub    %r9d,%edi
 29fac15:	sub    %rdi,%rsi
 29fac18:	mov    %edx,(%rsi)
 29fac1a:	mov    $0x1,%r10d
 29fac20:	mov    0x70(%rsp),%rax
 29fac25:	mov    %eax,0x28(%rsp)
 29fac29:	mov    %edx,(%rsp)
 29fac2c:	test   %r10d,%r10d
 29fac2f:	jne    29fb9e5 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4e05>
 29fac35:	mov    0x70(%rsp),%rax
 29fac3a:	mov    0x70(%rsp),%rcx
 29fac3f:	test   %ecx,%eax
 29fac41:	je     29fc8e6 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5d06>
 29fac47:	test   %ecx,%eax
 29fac49:	je     29fc8e8 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5d08>
 29fac4f:	mov    0xc8(%rsp),%rbx
 29fac57:	mov    0x28(%rbx),%rax
 29fac5b:	mov    0x20(%rbx),%rdi
 29fac5f:	mov    %ecx,%r9d
 29fac62:	lea    (%rdi,%r9,1),%rsi
 29fac66:	xor    %r8,%r8
 29fac69:	cmp    %rax,%r9
 29fac6c:	cmova  %r8,%rsi
 29fac70:	mov    0x10(%rsi),%esi
 29fac73:	test   %esi,%esi
 29fac75:	je     29fc8ea <wasm[0]::function[1013]::helper::array_indexed_publish+0x5d0a>
 29fac7b:	test   %esi,%esi
 29fac7d:	je     29fc8ec <wasm[0]::function[1013]::helper::array_indexed_publish+0x5d0c>
 29fac83:	mov    %esi,%r9d
 29fac86:	lea    0x10(%rdi,%r9,1),%rdi
 29fac8b:	cmp    %rax,%r9
 29fac8e:	cmova  %r8,%rdi
 29fac92:	mov    (%rdi),%edi
 29fac94:	test   %edi,%edi
 29fac96:	je     29faca9 <wasm[0]::function[1013]::helper::array_indexed_publish+0x40c9>
 29fac9c:	mov    %rdi,0x80(%rsp)
 29faca4:	jmp    29fb109 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4529>
 29faca9:	mov    0x28(%rsp),%eax
 29facad:	test   %eax,%eax
 29facaf:	je     29fc8ee <wasm[0]::function[1013]::helper::array_indexed_publish+0x5d0e>
 29facb5:	test   %eax,%eax
 29facb7:	je     29fc8f0 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5d10>
 29facbd:	mov    0xc8(%rsp),%rbx
 29facc5:	mov    0x28(%rbx),%rcx
 29facc9:	mov    %eax,%edx
 29faccb:	mov    %rdx,%rax
 29facce:	add    0x20(%rbx),%rax
 29facd2:	xor    %rsi,%rsi
 29facd5:	cmp    %rcx,%rdx
 29facd8:	cmova  %rsi,%rax
 29facdc:	mov    0x10(%rax),%eax
 29facdf:	mov    %eax,0x10(%rsp)
 29face3:	mov    0x60(%rsp),%rdi
 29face8:	mov    0x20(%rdi),%rdx
 29facec:	mov    (%rdx),%eax
 29facee:	mov    %eax,%ecx
 29facf0:	lea    0x40(%rcx),%rsi
 29facf4:	mov    0x4(%rdx),%edi
 29facf7:	cmp    %rdi,%rsi
 29facfa:	ja     29fc427 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5847>
 29fad00:	lea    0x40(%rax),%esi
 29fad03:	mov    %esi,(%rdx)
 29fad05:	mov    0xc8(%rsp),%rbx
 29fad0d:	mov    0x20(%rbx),%rsi
 29fad11:	lea    (%rsi,%rcx,1),%rdx
 29fad15:	movl   $0xa800000e,(%rsi,%rcx,1)
 29fad1c:	mov    0x60(%rsp),%rdi
 29fad21:	mov    0x28(%rdi),%rdi
 29fad25:	mov    0x1ac(%rdi),%edi
 29fad2b:	mov    %edi,0x4(%rsi,%rcx,1)
 29fad2f:	mov    $0x40,%edi
 29fad34:	mov    %edi,0x8(%rsi,%rcx,1)
 29fad38:	mov    %eax,0x18(%rsp)
 29fad3c:	mov    $0x8,%edi
 29fad41:	mov    %rdi,0x80(%rsp)
 29fad49:	movl   $0x8,0x10(%rdx)
 29fad50:	test   %eax,%eax
 29fad52:	je     29fc8f2 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5d12>
 29fad58:	mov    0xc8(%rsp),%rbx
 29fad60:	mov    0x28(%rbx),%rsi
 29fad64:	mov    0x20(%rbx),%r14
 29fad68:	mov    %eax,%r12d
 29fad6b:	lea    0x10(%r14,%r12,1),%rdi
 29fad70:	xor    %r8,%r8
 29fad73:	cmp    %rsi,%r12
 29fad76:	cmova  %r8,%rdi
 29fad7a:	mov    (%rdi),%edi
 29fad7c:	cmp    $0x8,%rdi
 29fad80:	jb     29fc8f4 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5d14>
 29fad86:	lea    0x14(%r14,%r12,1),%r13
 29fad8b:	mov    %r13,%r9
 29fad8e:	add    $0x20,%r9
 29fad92:	jb     29fc8f6 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5d16>
 29fad98:	lea    (%r14,%rsi,1),%r10
 29fad9c:	cmp    %r10,%r9
 29fad9f:	ja     29fc8f8 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5d18>
 29fada5:	mov    0x10(%rsp),%ecx
 29fada9:	mov    0x28(%rsp),%edx
 29fadad:	mov    (%rsp),%esi
 29fadb0:	mov    %ecx,(%rsp)
 29fadb3:	mov    %edx,0x28(%rsp)
 29fadb7:	mov    %esi,0x10(%rsp)
 29fadbb:	mov    0xd0(%rsp),%rax
 29fadc3:	mov    (%rax),%rax
 29fadc6:	mov    0xa8(%rsp),%rcx
 29fadce:	cmp    %rcx,%rax
 29fadd1:	jae    29fc45e <wasm[0]::function[1013]::helper::array_indexed_publish+0x587e>
 29fadd7:	movl   $0x0,0x0(%r13)
 29faddf:	mov    (%rsp),%ecx
 29fade2:	mov    0x28(%rsp),%edx
 29fade6:	mov    0x10(%rsp),%esi
 29fadea:	lea    0x30(%r14,%r12,1),%rdi
 29fadef:	lea    0x4(%r13),%rax
 29fadf3:	cmp    %rdi,%r13
 29fadf6:	je     29fae04 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4224>
 29fadfc:	mov    %rax,%r13
 29fadff:	jmp    29fadb0 <wasm[0]::function[1013]::helper::array_indexed_publish+0x41d0>
 29fae04:	xor    %r12d,%r12d
 29fae07:	test   %ecx,%ecx
 29fae09:	je     29fc8fa <wasm[0]::function[1013]::helper::array_indexed_publish+0x5d1a>
 29fae0f:	test   %ecx,%ecx
 29fae11:	je     29fc8fc <wasm[0]::function[1013]::helper::array_indexed_publish+0x5d1c>
 29fae17:	mov    0xc8(%rsp),%rbx
 29fae1f:	mov    0x28(%rbx),%rdi
 29fae23:	mov    0x20(%rbx),%r8
 29fae27:	mov    %ecx,%r9d
 29fae2a:	lea    0x10(%r8,%r9,1),%r8
 29fae2f:	xor    %r10,%r10
 29fae32:	cmp    %rdi,%r9
 29fae35:	cmova  %r10,%r8
 29fae39:	mov    (%r8),%eax
 29fae3c:	mov    %rax,0x98(%rsp)
 29fae44:	mov    %ecx,0x10(%rsp)
 29fae48:	mov    %edx,0x28(%rsp)
 29fae4c:	mov    %esi,(%rsp)
 29fae4f:	mov    0xd0(%rsp),%rax
 29fae57:	mov    (%rax),%rcx
 29fae5a:	mov    0xa8(%rsp),%rax
 29fae62:	cmp    %rax,%rcx
 29fae65:	jae    29fc492 <wasm[0]::function[1013]::helper::array_indexed_publish+0x58b2>
 29fae6b:	mov    0x98(%rsp),%rax
 29fae73:	jmp    29fae80 <wasm[0]::function[1013]::helper::array_indexed_publish+0x42a0>
 29fae78:	mov    0x98(%rsp),%rax
 29fae80:	cmp    %eax,%r12d
 29fae83:	mov    %rax,0x98(%rsp)
 29fae8b:	jae    29fb0b7 <wasm[0]::function[1013]::helper::array_indexed_publish+0x44d7>
 29fae91:	mov    0x10(%rsp),%edx
 29fae95:	test   %edx,%edx
 29fae97:	je     29fc8fe <wasm[0]::function[1013]::helper::array_indexed_publish+0x5d1e>
 29fae9d:	test   %edx,%edx
 29fae9f:	je     29fc900 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5d20>
 29faea5:	mov    0xc8(%rsp),%rbx
 29faead:	mov    0x28(%rbx),%rcx
 29faeb1:	mov    0x20(%rbx),%rsi
 29faeb5:	mov    %edx,%r9d
 29faeb8:	lea    0x10(%rsi,%r9,1),%r8
 29faebd:	xor    %rdi,%rdi
 29faec0:	cmp    %rcx,%r9
 29faec3:	cmova  %rdi,%r8
 29faec7:	mov    (%r8),%r8d
 29faeca:	cmp    %r8d,%r12d
 29faecd:	jae    29fc902 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5d22>
 29faed3:	mov    %r8d,%r9d
 29faed6:	shl    $0x2,%r9
 29faeda:	shr    $0x20,%r9
 29faede:	test   %r9,%r9
 29faee1:	jne    29fc904 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5d24>
 29faee7:	shl    $0x2,%r8d
 29faeeb:	add    $0x14,%r8d
 29faeef:	jb     29fc906 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5d26>
 29faef5:	mov    %rdx,%r9
 29faef8:	add    %r8d,%r9d
 29faefb:	jb     29fc908 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5d28>
 29faf01:	mov    %r9d,%r9d
 29faf04:	add    %r9,%rsi
 29faf07:	cmp    %rcx,%r9
 29faf0a:	cmova  %rdi,%rsi
 29faf0e:	mov    %r12,%rax
 29faf11:	shl    $0x2,%eax
 29faf14:	lea    0x14(%rax),%ecx
 29faf17:	sub    %ecx,%r8d
 29faf1a:	sub    %r8,%rsi
 29faf1d:	mov    (%rsi),%ecx
 29faf1f:	mov    0x28(%rsp),%esi
 29faf23:	mov    (%rsp),%edi
 29faf26:	mov    %ecx,0x30(%rsp)
 29faf2a:	mov    %edx,0x8(%rsp)
 29faf2e:	mov    %esi,0x20(%rsp)
 29faf32:	mov    %edi,0x10(%rsp)
 29faf36:	mov    0xd0(%rsp),%rax
 29faf3e:	mov    (%rax),%rcx
 29faf41:	mov    0xa8(%rsp),%rax
 29faf49:	cmp    %rax,%rcx
 29faf4c:	jae    29fc4ce <wasm[0]::function[1013]::helper::array_indexed_publish+0x58ee>
 29faf52:	mov    0x30(%rsp),%esi
 29faf56:	test   %esi,%esi
 29faf58:	je     29fb09f <wasm[0]::function[1013]::helper::array_indexed_publish+0x44bf>
 29faf5e:	mov    0x30(%rsp),%r8d
 29faf63:	test   %r8d,%r8d
 29faf66:	je     29fc90a <wasm[0]::function[1013]::helper::array_indexed_publish+0x5d2a>
 29faf6c:	mov    0xc8(%rsp),%rbx
 29faf74:	mov    0x28(%rbx),%r10
 29faf78:	mov    0x20(%rbx),%r11
 29faf7c:	mov    %r8d,%ecx
 29faf7f:	lea    (%r11,%rcx,1),%rdi
 29faf83:	xor    %rdx,%rdx
 29faf86:	cmp    %r10,%rcx
 29faf89:	cmova  %rdx,%rdi
 29faf8d:	mov    0x1c(%rdi),%ecx
 29faf90:	mov    0x10(%rdi),%r13
 29faf94:	mov    0x18(%rsp),%esi
 29faf98:	test   %esi,%esi
 29faf9a:	je     29fc90c <wasm[0]::function[1013]::helper::array_indexed_publish+0x5d2c>
 29fafa0:	test   %esi,%esi
 29fafa2:	je     29fc90e <wasm[0]::function[1013]::helper::array_indexed_publish+0x5d2e>
 29fafa8:	mov    %esi,%r15d
 29fafab:	lea    0x10(%r11,%r15,1),%r9
 29fafb0:	cmp    %r10,%r15
 29fafb3:	cmova  %rdx,%r9
 29fafb7:	mov    (%r9),%ebx
 29fafba:	mov    %r13,%r14
 29fafbd:	shr    $0x10,%r14d
 29fafc1:	xor    %r14d,%r13d
 29fafc4:	imul   $0x7feb352d,%r13d,%r14d
 29fafcb:	mov    %r14,%r13
 29fafce:	shr    $0xf,%r13d
 29fafd2:	xor    %r13d,%r14d
 29fafd5:	imul   $0x846ca68b,%r14d,%r13d
 29fafdc:	mov    %r13,%r14
 29fafdf:	shr    $0x10,%r14d
 29fafe3:	xor    %r14d,%r13d
 29fafe6:	and    $0x7,%r13d
 29fafea:	cmp    %ebx,%r13d
 29fafed:	jae    29fc910 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5d30>
 29faff3:	mov    %ebx,%r14d
 29faff6:	shl    $0x2,%r14
 29faffa:	shr    $0x20,%r14
 29faffe:	test   %r14,%r14
 29fb001:	jne    29fc912 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5d32>
 29fb007:	shl    $0x2,%ebx
 29fb00a:	add    $0x14,%ebx
 29fb00d:	jb     29fc914 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5d34>
 29fb013:	mov    %rsi,%r14
 29fb016:	add    %ebx,%r14d
 29fb019:	jb     29fc916 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5d36>
 29fb01f:	mov    %r14d,%r14d
 29fb022:	lea    (%r11,%r14,1),%r15
 29fb026:	cmp    %r10,%r14
 29fb029:	cmova  %rdx,%r15
 29fb02d:	mov    %r13,%rax
 29fb030:	shl    $0x2,%eax
 29fb033:	lea    0x14(%rax),%r14d
 29fb037:	sub    %r14d,%ebx
 29fb03a:	sub    %rbx,%r15
 29fb03d:	mov    (%r15),%eax
 29fb040:	mov    %eax,0x1c(%rdi)
 29fb043:	mov    (%r9),%edi
 29fb046:	cmp    %edi,%r13d
 29fb049:	jae    29fc918 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5d38>
 29fb04f:	mov    %edi,%r9d
 29fb052:	shl    $0x2,%r9
 29fb056:	shr    $0x20,%r9
 29fb05a:	test   %r9,%r9
 29fb05d:	jne    29fc91a <wasm[0]::function[1013]::helper::array_indexed_publish+0x5d3a>
 29fb063:	shl    $0x2,%edi
 29fb066:	add    $0x14,%edi
 29fb069:	jb     29fc91c <wasm[0]::function[1013]::helper::array_indexed_publish+0x5d3c>
 29fb06f:	add    %edi,%esi
 29fb071:	jb     29fc91e <wasm[0]::function[1013]::helper::array_indexed_publish+0x5d3e>
 29fb077:	mov    %esi,%r9d
 29fb07a:	lea    (%r11,%r9,1),%rsi
 29fb07e:	cmp    %r10,%r9
 29fb081:	cmova  %rdx,%rsi
 29fb085:	sub    %r14d,%edi
 29fb088:	sub    %rdi,%rsi
 29fb08b:	mov    %r8d,(%rsi)
 29fb08e:	mov    0x8(%rsp),%edx
 29fb092:	mov    0x20(%rsp),%esi
 29fb096:	mov    0x10(%rsp),%edi
 29fb09a:	jmp    29faf26 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4346>
 29fb09f:	mov    0x8(%rsp),%ecx
 29fb0a3:	mov    0x20(%rsp),%edx
 29fb0a7:	mov    0x10(%rsp),%esi
 29fb0ab:	add    $0x1,%r12d
 29fb0b2:	jmp    29fae44 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4264>
 29fb0b7:	mov    0x28(%rsp),%edx
 29fb0bb:	mov    %rdx,%rdi
 29fb0be:	mov    %rdx,0x70(%rsp)
 29fb0c3:	test   %edi,%edx
 29fb0c5:	je     29fc920 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5d40>
 29fb0cb:	mov    0x18(%rsp),%esi
 29fb0cf:	test   %esi,%esi
 29fb0d1:	je     29fc922 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5d42>
 29fb0d7:	mov    0x70(%rsp),%rax
 29fb0dc:	test   %eax,%edx
 29fb0de:	je     29fc924 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5d44>
 29fb0e4:	mov    0xc8(%rsp),%rbx
 29fb0ec:	mov    0x28(%rbx),%rax
 29fb0f0:	mov    %edx,%edi
 29fb0f2:	mov    %rdi,%rdx
 29fb0f5:	add    0x20(%rbx),%rdx
 29fb0f9:	xor    %r8,%r8
 29fb0fc:	cmp    %rax,%rdi
 29fb0ff:	cmova  %r8,%rdx
 29fb103:	mov    %esi,0x10(%rdx)
 29fb106:	mov    (%rsp),%edx
 29fb109:	mov    %edx,(%rsp)
 29fb10c:	test   %esi,%esi
 29fb10e:	je     29fc926 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5d46>
 29fb114:	test   %esi,%esi
 29fb116:	je     29fc928 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5d48>
 29fb11c:	mov    0xc8(%rsp),%rbx
 29fb124:	mov    0x28(%rbx),%rax
 29fb128:	mov    0x20(%rbx),%rdx
 29fb12c:	mov    %esi,%r9d
 29fb12f:	lea    0x10(%rdx,%r9,1),%r8
 29fb134:	xor    %rdi,%rdi
 29fb137:	cmp    %rax,%r9
 29fb13a:	cmova  %rdi,%r8
 29fb13e:	mov    (%r8),%r8d
 29fb141:	mov    $0x10,%ecx
 29fb146:	mov    %rcx,0x98(%rsp)
 29fb14e:	mov    0x68(%rsp),%rcx
 29fb153:	mov    %rcx,%r9
 29fb156:	shr    $0x10,%r9d
 29fb15a:	xor    %r9d,%ecx
 29fb15d:	imul   $0x7feb352d,%ecx,%r9d
 29fb164:	mov    %r9,%r10
 29fb167:	shr    $0xf,%r10d
 29fb16b:	xor    %r10d,%r9d
 29fb16e:	imul   $0x846ca68b,%r9d,%r13d
 29fb175:	mov    %r13,%r9
 29fb178:	shr    $0x10,%r9d
 29fb17c:	xor    %r9d,%r13d
 29fb17f:	mov    0x80(%rsp),%r10
 29fb187:	mov    %r10,%r9
 29fb18a:	sub    $0x1,%r9d
 29fb18e:	mov    %r13,%r12
 29fb191:	and    %r9d,%r12d
 29fb194:	mov    %r13,0x78(%rsp)
 29fb199:	cmp    %r8d,%r12d
 29fb19c:	jae    29fc92a <wasm[0]::function[1013]::helper::array_indexed_publish+0x5d4a>
 29fb1a2:	mov    %r8d,%r9d
 29fb1a5:	shl    $0x2,%r9
 29fb1a9:	mov    $0x20,%r14d
 29fb1af:	mov    %r14,0x90(%rsp)
 29fb1b7:	shr    $0x20,%r9
 29fb1bb:	test   %r9,%r9
 29fb1be:	jne    29fc92c <wasm[0]::function[1013]::helper::array_indexed_publish+0x5d4c>
 29fb1c4:	shl    $0x2,%r8d
 29fb1c8:	add    $0x14,%r8d
 29fb1cc:	jb     29fc92e <wasm[0]::function[1013]::helper::array_indexed_publish+0x5d4e>
 29fb1d2:	mov    %rsi,%r9
 29fb1d5:	add    %r8d,%r9d
 29fb1d8:	jb     29fc930 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5d50>
 29fb1de:	mov    %r9d,%r9d
 29fb1e1:	add    %r9,%rdx
 29fb1e4:	cmp    %rax,%r9
 29fb1e7:	cmova  %rdi,%rdx
 29fb1eb:	mov    %r12,%rax
 29fb1ee:	shl    $0x2,%eax
 29fb1f1:	add    $0x14,%eax
 29fb1f7:	sub    %eax,%r8d
 29fb1fa:	sub    %r8,%rdx
 29fb1fd:	mov    (%rdx),%eax
 29fb1ff:	mov    %eax,0x8(%rsp)
 29fb203:	mov    0x70(%rsp),%rdx
 29fb208:	mov    %edx,0x18(%rsp)
 29fb20c:	mov    %esi,0x28(%rsp)
 29fb210:	mov    0xd0(%rsp),%rax
 29fb218:	mov    (%rax),%rax
 29fb21b:	mov    0xa8(%rsp),%rcx
 29fb223:	cmp    %rcx,%rax
 29fb226:	jae    29fc502 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5922>
 29fb22c:	mov    0x8(%rsp),%esi
 29fb230:	test   %esi,%esi
 29fb232:	je     29fb2f8 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4718>
 29fb238:	mov    0x8(%rsp),%esi
 29fb23c:	test   %esi,%esi
 29fb23e:	je     29fc932 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5d52>
 29fb244:	mov    0xc8(%rsp),%rbx
 29fb24c:	mov    0x28(%rbx),%r8
 29fb250:	mov    %esi,%r9d
 29fb253:	mov    %r9,%rsi
 29fb256:	add    0x20(%rbx),%rsi
 29fb25a:	xor    %r10,%r10
 29fb25d:	cmp    %r8,%r9
 29fb260:	cmova  %r10,%rsi
 29fb264:	mov    0x10(%rsi),%r9
 29fb268:	mov    0x68(%rsp),%rcx
 29fb26d:	cmp    %rcx,%r9
 29fb270:	je     29fb2ba <wasm[0]::function[1013]::helper::array_indexed_publish+0x46da>
 29fb276:	mov    0x8(%rsp),%r11d
 29fb27b:	test   %r11d,%r11d
 29fb27e:	je     29fc934 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5d54>
 29fb284:	mov    0xc8(%rsp),%rbx
 29fb28c:	mov    0x28(%rbx),%rax
 29fb290:	mov    %r11d,%ecx
 29fb293:	mov    %rcx,%r10
 29fb296:	add    0x20(%rbx),%r10
 29fb29a:	xor    %rdx,%rdx
 29fb29d:	cmp    %rax,%rcx
 29fb2a0:	cmova  %rdx,%r10
 29fb2a4:	mov    0x1c(%r10),%eax
 29fb2a8:	mov    0x18(%rsp),%edx
 29fb2ac:	mov    %rdx,0x70(%rsp)
 29fb2b1:	mov    0x28(%rsp),%esi
 29fb2b5:	jmp    29fb1ff <wasm[0]::function[1013]::helper::array_indexed_publish+0x461f>
 29fb2ba:	mov    (%rsp),%eax
 29fb2bd:	test   %eax,%eax
 29fb2bf:	je     29fc936 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5d56>
 29fb2c5:	mov    0x8(%rsp),%edx
 29fb2c9:	test   %edx,%edx
 29fb2cb:	je     29fc938 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5d58>
 29fb2d1:	mov    0xc8(%rsp),%rbx
 29fb2d9:	mov    0x28(%rbx),%rcx
 29fb2dd:	mov    %edx,%esi
 29fb2df:	mov    %rsi,%rdx
 29fb2e2:	add    0x20(%rbx),%rdx
 29fb2e6:	xor    %rdi,%rdi
 29fb2e9:	cmp    %rcx,%rsi
 29fb2ec:	cmova  %rdi,%rdx
 29fb2f0:	mov    %eax,0x18(%rdx)
 29fb2f3:	jmp    29fb9e5 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4e05>
 29fb2f8:	mov    0x18(%rsp),%edx
 29fb2fc:	test   %edx,%edx
 29fb2fe:	je     29fc93a <wasm[0]::function[1013]::helper::array_indexed_publish+0x5d5a>
 29fb304:	test   %edx,%edx
 29fb306:	je     29fc93c <wasm[0]::function[1013]::helper::array_indexed_publish+0x5d5c>
 29fb30c:	mov    0xc8(%rsp),%rbx
 29fb314:	mov    0x28(%rbx),%rax
 29fb318:	mov    0x20(%rbx),%rcx
 29fb31c:	mov    %edx,%esi
 29fb31e:	add    %rsi,%rcx
 29fb321:	xor    %rdi,%rdi
 29fb324:	cmp    %rax,%rsi
 29fb327:	cmova  %rdi,%rcx
 29fb32b:	mov    0x18(%rcx),%rcx
 29fb32f:	mov    0x28(%rsp),%eax
 29fb333:	mov    (%rsp),%esi
 29fb336:	lea    0x1(%rcx),%rdi
 29fb33a:	mov    %rcx,0x88(%rsp)
 29fb342:	shl    $0x2,%rdi
 29fb346:	mov    0x80(%rsp),%rcx
 29fb34e:	mov    %ecx,%r8d
 29fb351:	imul   $0x3,%r8,%r8
 29fb355:	cmp    %r8,%rdi
 29fb358:	ja     29fb366 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4786>
 29fb35e:	mov    %r12,%r13
 29fb361:	jmp    29fb80f <wasm[0]::function[1013]::helper::array_indexed_publish+0x4c2f>
 29fb366:	cmp    $0x80000000,%ecx
 29fb36c:	jae    29fc93e <wasm[0]::function[1013]::helper::array_indexed_publish+0x5d5e>
 29fb372:	mov    0x18(%rsp),%eax
 29fb376:	test   %eax,%eax
 29fb378:	je     29fc940 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5d60>
 29fb37e:	test   %eax,%eax
 29fb380:	je     29fc942 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5d62>
 29fb386:	mov    0xc8(%rsp),%rbx
 29fb38e:	mov    0x28(%rbx),%rdx
 29fb392:	mov    %eax,%esi
 29fb394:	mov    %rsi,%rax
 29fb397:	add    0x20(%rbx),%rax
 29fb39b:	xor    %rdi,%rdi
 29fb39e:	cmp    %rdx,%rsi
 29fb3a1:	cmova  %rdi,%rax
 29fb3a5:	mov    0x10(%rax),%eax
 29fb3a8:	mov    %eax,0x28(%rsp)
 29fb3ac:	mov    %rcx,%r15
 29fb3af:	shl    $1,%r15d
 29fb3b2:	mov    %r15,%r12
 29fb3b5:	shl    $0x2,%r12
 29fb3b9:	mov    %r12,%rax
 29fb3bc:	shr    $0x20,%rax
 29fb3c0:	test   %rax,%rax
 29fb3c3:	jne    29fc944 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5d64>
 29fb3c9:	shl    $0x3,%ecx
 29fb3cc:	add    $0x14,%ecx
 29fb3cf:	jb     29fc946 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5d66>
 29fb3d5:	mov    0x60(%rsp),%rdi
 29fb3da:	mov    0x20(%rdi),%rdi
 29fb3de:	mov    (%rdi),%eax
 29fb3e0:	mov    %eax,%edx
 29fb3e2:	mov    %ecx,%esi
 29fb3e4:	add    $0xf,%rsi
 29fb3eb:	mov    %rsi,%r8
 29fb3ee:	and    $0xfffffffffffffff0,%r8
 29fb3f2:	add    %rdx,%r8
 29fb3f5:	mov    0x4(%rdi),%r9d
 29fb3f9:	cmp    %r9,%r8
 29fb3fc:	ja     29fc536 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5956>
 29fb402:	add    $0xf,%ecx
 29fb408:	and    $0xfffffff0,%ecx
 29fb40b:	add    %eax,%ecx
 29fb40d:	mov    %ecx,(%rdi)
 29fb40f:	mov    0xc8(%rsp),%rbx
 29fb417:	mov    0x20(%rbx),%rdi
 29fb41b:	lea    (%rdi,%rdx,1),%rcx
 29fb41f:	movl   $0xa800000e,(%rdi,%rdx,1)
 29fb426:	mov    0x60(%rsp),%r8
 29fb42b:	mov    0x28(%r8),%r8
 29fb42f:	mov    0x1ac(%r8),%r8d
 29fb436:	mov    %r8d,0x4(%rdi,%rdx,1)
 29fb43b:	and    $0xfffffffffffffff0,%rsi
 29fb43f:	mov    %esi,0x8(%rdi,%rdx,1)
 29fb443:	mov    %eax,0x8(%rsp)
 29fb447:	mov    %r15d,0x10(%rcx)
 29fb44b:	test   %eax,%eax
 29fb44d:	je     29fc948 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5d68>
 29fb453:	mov    0xc8(%rsp),%rbx
 29fb45b:	mov    0x28(%rbx),%rcx
 29fb45f:	mov    0x20(%rbx),%rdx
 29fb463:	mov    %eax,%eax
 29fb465:	lea    (%rdx,%rax,1),%rsi
 29fb469:	lea    0x10(%rdx,%rax,1),%rdi
 29fb46e:	xor    %r8,%r8
 29fb471:	cmp    %rcx,%rax
 29fb474:	cmova  %r8,%rdi
 29fb478:	mov    (%rdi),%edi
 29fb47a:	cmp    %rdi,%r15
 29fb47d:	ja     29fc94a <wasm[0]::function[1013]::helper::array_indexed_publish+0x5d6a>
 29fb483:	lea    0x14(%rdx,%rax,1),%rbx
 29fb488:	mov    %rbx,%rax
 29fb48b:	add    %r12,%rax
 29fb48e:	jb     29fc94c <wasm[0]::function[1013]::helper::array_indexed_publish+0x5d6c>
 29fb494:	add    %rdx,%rcx
 29fb497:	cmp    %rcx,%rax
 29fb49a:	ja     29fc94e <wasm[0]::function[1013]::helper::array_indexed_publish+0x5d6e>
 29fb4a0:	mov    0x28(%rsp),%eax
 29fb4a4:	mov    0x18(%rsp),%ecx
 29fb4a8:	mov    (%rsp),%edx
 29fb4ab:	lea    0x14(%rsi,%r15,4),%r12
 29fb4b0:	test   %r15,%r15
 29fb4b3:	je     29fb501 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4921>
 29fb4b9:	mov    %eax,(%rsp)
 29fb4bc:	mov    %ecx,0x18(%rsp)
 29fb4c0:	mov    %edx,0x28(%rsp)
 29fb4c4:	mov    0xd0(%rsp),%rax
 29fb4cc:	mov    (%rax),%rsi
 29fb4cf:	mov    0xa8(%rsp),%rax
 29fb4d7:	cmp    %rax,%rsi
 29fb4da:	jae    29fc56a <wasm[0]::function[1013]::helper::array_indexed_publish+0x598a>
 29fb4e0:	movl   $0x0,(%rbx)
 29fb4e6:	mov    (%rsp),%eax
 29fb4e9:	mov    0x18(%rsp),%ecx
 29fb4ed:	mov    0x28(%rsp),%edx
 29fb4f1:	add    $0x4,%rbx
 29fb4f8:	cmp    %r12,%rbx
 29fb4fb:	jne    29fb4b9 <wasm[0]::function[1013]::helper::array_indexed_publish+0x48d9>
 29fb501:	xor    %r12d,%r12d
 29fb504:	test   %eax,%eax
 29fb506:	je     29fc950 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5d70>
 29fb50c:	test   %eax,%eax
 29fb50e:	je     29fc952 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5d72>
 29fb514:	mov    0xc8(%rsp),%rbx
 29fb51c:	mov    0x28(%rbx),%rsi
 29fb520:	mov    0x20(%rbx),%rdi
 29fb524:	mov    %eax,%r8d
 29fb527:	lea    0x10(%rdi,%r8,1),%rdi
 29fb52c:	xor    %r9,%r9
 29fb52f:	cmp    %rsi,%r8
 29fb532:	cmova  %r9,%rdi
 29fb536:	mov    (%rdi),%esi
 29fb538:	mov    %rsi,0x80(%rsp)
 29fb540:	mov    %eax,0x28(%rsp)
 29fb544:	mov    %ecx,0x18(%rsp)
 29fb548:	mov    %edx,(%rsp)
 29fb54b:	mov    0xd0(%rsp),%rax
 29fb553:	mov    (%rax),%rax
 29fb556:	mov    0xa8(%rsp),%rcx
 29fb55e:	cmp    %rcx,%rax
 29fb561:	jae    29fc59e <wasm[0]::function[1013]::helper::array_indexed_publish+0x59be>
 29fb567:	mov    0x80(%rsp),%rax
 29fb56f:	jmp    29fb57c <wasm[0]::function[1013]::helper::array_indexed_publish+0x499c>
 29fb574:	mov    0x80(%rsp),%rax
 29fb57c:	cmp    %eax,%r12d
 29fb57f:	mov    %rax,0x80(%rsp)
 29fb587:	jae    29fb7be <wasm[0]::function[1013]::helper::array_indexed_publish+0x4bde>
 29fb58d:	mov    0x28(%rsp),%eax
 29fb591:	test   %eax,%eax
 29fb593:	je     29fc954 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5d74>
 29fb599:	test   %eax,%eax
 29fb59b:	je     29fc956 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5d76>
 29fb5a1:	mov    0xc8(%rsp),%rbx
 29fb5a9:	mov    0x28(%rbx),%rcx
 29fb5ad:	mov    0x20(%rbx),%rdx
 29fb5b1:	mov    %eax,%r8d
 29fb5b4:	lea    0x10(%rdx,%r8,1),%rdi
 29fb5b9:	xor    %rsi,%rsi
 29fb5bc:	cmp    %rcx,%r8
 29fb5bf:	cmova  %rsi,%rdi
 29fb5c3:	mov    (%rdi),%edi
 29fb5c5:	cmp    %edi,%r12d
 29fb5c8:	jae    29fc958 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5d78>
 29fb5ce:	mov    %edi,%r8d
 29fb5d1:	shl    $0x2,%r8
 29fb5d5:	shr    $0x20,%r8
 29fb5d9:	test   %r8,%r8
 29fb5dc:	jne    29fc95a <wasm[0]::function[1013]::helper::array_indexed_publish+0x5d7a>
 29fb5e2:	shl    $0x2,%edi
 29fb5e5:	add    $0x14,%edi
 29fb5e8:	jb     29fc95c <wasm[0]::function[1013]::helper::array_indexed_publish+0x5d7c>
 29fb5ee:	mov    %rax,%r8
 29fb5f1:	add    %edi,%r8d
 29fb5f4:	jb     29fc95e <wasm[0]::function[1013]::helper::array_indexed_publish+0x5d7e>
 29fb5fa:	mov    %r8d,%r8d
 29fb5fd:	add    %r8,%rdx
 29fb600:	cmp    %rcx,%r8
 29fb603:	cmova  %rsi,%rdx
 29fb607:	mov    %r12,%rcx
 29fb60a:	shl    $0x2,%ecx
 29fb60d:	add    $0x14,%ecx
 29fb613:	sub    %ecx,%edi
 29fb615:	sub    %rdi,%rdx
 29fb618:	mov    (%rdx),%edx
 29fb61a:	mov    0x18(%rsp),%ecx
 29fb61e:	mov    (%rsp),%esi
 29fb621:	mov    %edx,0x30(%rsp)
 29fb625:	mov    %eax,0x10(%rsp)
 29fb629:	mov    %ecx,0x20(%rsp)
 29fb62d:	mov    %esi,0x28(%rsp)
 29fb631:	mov    0xd0(%rsp),%rax
 29fb639:	mov    (%rax),%rax
 29fb63c:	mov    0xa8(%rsp),%rcx
 29fb644:	cmp    %rcx,%rax
 29fb647:	jae    29fc5da <wasm[0]::function[1013]::helper::array_indexed_publish+0x59fa>
 29fb64d:	mov    0x30(%rsp),%eax
 29fb651:	test   %eax,%eax
 29fb653:	je     29fb7a6 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4bc6>
 29fb659:	mov    0x30(%rsp),%ecx
 29fb65d:	test   %ecx,%ecx
 29fb65f:	je     29fc960 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5d80>
 29fb665:	mov    0xc8(%rsp),%rbx
 29fb66d:	mov    0x28(%rbx),%rsi
 29fb671:	mov    0x20(%rbx),%rdi
 29fb675:	mov    %ecx,%eax
 29fb677:	lea    (%rdi,%rax,1),%r9
 29fb67b:	xor    %r8,%r8
 29fb67e:	cmp    %rsi,%rax
 29fb681:	cmova  %r8,%r9
 29fb685:	mov    0x1c(%r9),%edx
 29fb689:	mov    0x10(%r9),%rbx
 29fb68d:	mov    0x8(%rsp),%eax
 29fb691:	test   %eax,%eax
 29fb693:	je     29fc962 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5d82>
 29fb699:	test   %eax,%eax
 29fb69b:	je     29fc964 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5d84>
 29fb6a1:	mov    %eax,%r11d
 29fb6a4:	lea    0x10(%rdi,%r11,1),%r10
 29fb6a9:	cmp    %rsi,%r11
 29fb6ac:	cmova  %r8,%r10
 29fb6b0:	mov    (%r10),%r11d
 29fb6b3:	mov    %rbx,%r13
 29fb6b6:	shr    $0x10,%r13d
 29fb6ba:	xor    %r13d,%ebx
 29fb6bd:	imul   $0x7feb352d,%ebx,%ebx
 29fb6c3:	mov    %rbx,%r13
 29fb6c6:	shr    $0xf,%r13d
 29fb6ca:	xor    %r13d,%ebx
 29fb6cd:	imul   $0x846ca68b,%ebx,%ebx
 29fb6d3:	mov    %rbx,%r13
 29fb6d6:	shr    $0x10,%r13d
 29fb6da:	xor    %r13d,%ebx
 29fb6dd:	mov    %r15,%r13
 29fb6e0:	sub    $0x1,%r13d
 29fb6e4:	and    %r13d,%ebx
 29fb6e7:	cmp    %r11d,%ebx
 29fb6ea:	jae    29fc966 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5d86>
 29fb6f0:	mov    %r11d,%r13d
 29fb6f3:	shl    $0x2,%r13
 29fb6f7:	shr    $0x20,%r13
 29fb6fb:	test   %r13,%r13
 29fb6fe:	jne    29fc968 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5d88>
 29fb704:	shl    $0x2,%r11d
 29fb708:	add    $0x14,%r11d
 29fb70c:	jb     29fc96a <wasm[0]::function[1013]::helper::array_indexed_publish+0x5d8a>
 29fb712:	mov    %rax,%r13
 29fb715:	add    %r11d,%r13d
 29fb718:	jb     29fc96c <wasm[0]::function[1013]::helper::array_indexed_publish+0x5d8c>
 29fb71e:	mov    %r13d,%r14d
 29fb721:	lea    (%rdi,%r14,1),%r13
 29fb725:	cmp    %rsi,%r14
 29fb728:	cmova  %r8,%r13
 29fb72c:	mov    %rbx,%r14
 29fb72f:	shl    $0x2,%r14d
 29fb733:	add    $0x14,%r14d
 29fb73a:	sub    %r14d,%r11d
 29fb73d:	sub    %r11,%r13
 29fb740:	mov    0x0(%r13),%r11d
 29fb744:	mov    %r11d,0x1c(%r9)
 29fb748:	mov    (%r10),%r9d
 29fb74b:	cmp    %r9d,%ebx
 29fb74e:	jae    29fc96e <wasm[0]::function[1013]::helper::array_indexed_publish+0x5d8e>
 29fb754:	mov    %r9d,%r10d
 29fb757:	shl    $0x2,%r10
 29fb75b:	shr    $0x20,%r10
 29fb75f:	test   %r10,%r10
 29fb762:	jne    29fc970 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5d90>
 29fb768:	shl    $0x2,%r9d
 29fb76c:	add    $0x14,%r9d
 29fb770:	jb     29fc972 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5d92>
 29fb776:	add    %r9d,%eax
 29fb779:	jb     29fc974 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5d94>
 29fb77f:	mov    %eax,%r10d
 29fb782:	lea    (%rdi,%r10,1),%rax
 29fb786:	cmp    %rsi,%r10
 29fb789:	cmova  %r8,%rax
 29fb78d:	sub    %r14d,%r9d
 29fb790:	sub    %r9,%rax
 29fb793:	mov    %ecx,(%rax)
 29fb795:	mov    0x10(%rsp),%eax
 29fb799:	mov    0x20(%rsp),%ecx
 29fb79d:	mov    0x28(%rsp),%esi
 29fb7a1:	jmp    29fb621 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4a41>
 29fb7a6:	mov    0x10(%rsp),%eax
 29fb7aa:	mov    0x20(%rsp),%ecx
 29fb7ae:	mov    0x28(%rsp),%edx
 29fb7b2:	add    $0x1,%r12d
 29fb7b9:	jmp    29fb540 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4960>
 29fb7be:	mov    0x18(%rsp),%edx
 29fb7c2:	test   %edx,%edx
 29fb7c4:	je     29fc976 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5d96>
 29fb7ca:	mov    0x8(%rsp),%eax
 29fb7ce:	test   %eax,%eax
 29fb7d0:	je     29fc978 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5d98>
 29fb7d6:	test   %edx,%edx
 29fb7d8:	je     29fc97a <wasm[0]::function[1013]::helper::array_indexed_publish+0x5d9a>
 29fb7de:	mov    0xc8(%rsp),%rbx
 29fb7e6:	mov    0x28(%rbx),%rcx
 29fb7ea:	mov    %edx,%edi
 29fb7ec:	mov    %rdi,%rsi
 29fb7ef:	add    0x20(%rbx),%rsi
 29fb7f3:	xor    %r8,%r8
 29fb7f6:	cmp    %rcx,%rdi
 29fb7f9:	cmova  %r8,%rsi
 29fb7fd:	mov    %eax,0x10(%rsi)
 29fb800:	mov    (%rsp),%esi
 29fb803:	sub    $0x1,%r15d
 29fb807:	mov    0x78(%rsp),%r13
 29fb80c:	and    %r15d,%r13d
 29fb80f:	mov    %eax,0x8(%rsp)
 29fb813:	mov    %esi,0x18(%rsp)
 29fb817:	mov    %edx,(%rsp)
 29fb81a:	test   %eax,%eax
 29fb81c:	je     29fc97c <wasm[0]::function[1013]::helper::array_indexed_publish+0x5d9c>
 29fb822:	test   %eax,%eax
 29fb824:	je     29fc97e <wasm[0]::function[1013]::helper::array_indexed_publish+0x5d9e>
 29fb82a:	mov    0xc8(%rsp),%rbx
 29fb832:	mov    0x28(%rbx),%rcx
 29fb836:	mov    0x20(%rbx),%rdx
 29fb83a:	mov    %eax,%r9d
 29fb83d:	lea    0x10(%rdx,%r9,1),%r8
 29fb842:	xor    %rdi,%rdi
 29fb845:	cmp    %rcx,%r9
 29fb848:	cmova  %rdi,%r8
 29fb84c:	mov    (%r8),%r8d
 29fb84f:	cmp    %r8d,%r13d
 29fb852:	jae    29fc980 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5da0>
 29fb858:	mov    %r8d,%r9d
 29fb85b:	shl    $0x2,%r9
 29fb85f:	shr    $0x20,%r9
 29fb863:	test   %r9,%r9
 29fb866:	jne    29fc982 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5da2>
 29fb86c:	shl    $0x2,%r8d
 29fb870:	add    $0x14,%r8d
 29fb874:	jb     29fc984 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5da4>
 29fb87a:	add    %r8d,%eax
 29fb87d:	jb     29fc986 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5da6>
 29fb883:	mov    %eax,%r9d
 29fb886:	lea    (%rdx,%r9,1),%rax
 29fb88a:	cmp    %rcx,%r9
 29fb88d:	cmova  %rdi,%rax
 29fb891:	mov    %r13,%r12
 29fb894:	shl    $0x2,%r12d
 29fb898:	lea    0x14(%r12),%ecx
 29fb89d:	sub    %ecx,%r8d
 29fb8a0:	sub    %r8,%rax
 29fb8a3:	mov    (%rax),%eax
 29fb8a5:	mov    %eax,0x10(%rsp)
 29fb8a9:	test   %esi,%esi
 29fb8ab:	je     29fc988 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5da8>
 29fb8b1:	mov    0x60(%rsp),%rdi
 29fb8b6:	mov    0x20(%rdi),%rcx
 29fb8ba:	mov    (%rcx),%eax
 29fb8bc:	mov    %eax,%edx
 29fb8be:	lea    0x20(%rdx),%rsi
 29fb8c2:	mov    0x4(%rcx),%edi
 29fb8c5:	cmp    %rdi,%rsi
 29fb8c8:	ja     29fc60e <wasm[0]::function[1013]::helper::array_indexed_publish+0x5a2e>
 29fb8ce:	lea    0x20(%rax),%esi
 29fb8d1:	mov    %esi,(%rcx)
 29fb8d3:	mov    0xc8(%rsp),%rbx
 29fb8db:	mov    0x20(%rbx),%rsi
 29fb8df:	lea    (%rsi,%rdx,1),%rcx
 29fb8e3:	movl   $0xb0000062,(%rsi,%rdx,1)
 29fb8ea:	mov    0x60(%rsp),%rdi
 29fb8ef:	mov    0x28(%rdi),%rdi
 29fb8f3:	mov    0x1a8(%rdi),%edi
 29fb8f9:	mov    %edi,0x4(%rsi,%rdx,1)
 29fb8fd:	mov    0x90(%rsp),%r14
 29fb905:	mov    %r14d,0x8(%rsi,%rdx,1)
 29fb90a:	mov    0x68(%rsp),%rdx
 29fb90f:	mov    0x68(%rsp),%rdx
 29fb914:	mov    %rdx,0x10(%rcx)
 29fb918:	mov    0x18(%rsp),%edx
 29fb91c:	mov    %edx,0x18(%rcx)
 29fb91f:	mov    0x10(%rsp),%edx
 29fb923:	mov    %edx,0x1c(%rcx)
 29fb926:	mov    0x8(%rsp),%ecx
 29fb92a:	test   %ecx,%ecx
 29fb92c:	je     29fc98a <wasm[0]::function[1013]::helper::array_indexed_publish+0x5daa>
 29fb932:	test   %eax,%eax
 29fb934:	je     29fc98c <wasm[0]::function[1013]::helper::array_indexed_publish+0x5dac>
 29fb93a:	test   %ecx,%ecx
 29fb93c:	je     29fc98e <wasm[0]::function[1013]::helper::array_indexed_publish+0x5dae>
 29fb942:	mov    0xc8(%rsp),%rbx
 29fb94a:	mov    0x28(%rbx),%rsi
 29fb94e:	mov    0x20(%rbx),%rdi
 29fb952:	mov    %ecx,%r9d
 29fb955:	lea    0x10(%rdi,%r9,1),%rdx
 29fb95a:	xor    %r8,%r8
 29fb95d:	cmp    %rsi,%r9
 29fb960:	cmova  %r8,%rdx
 29fb964:	mov    (%rdx),%edx
 29fb966:	cmp    %edx,%r13d
 29fb969:	jae    29fc990 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5db0>
 29fb96f:	mov    %edx,%r9d
 29fb972:	shl    $0x2,%r9
 29fb976:	shr    $0x20,%r9
 29fb97a:	test   %r9,%r9
 29fb97d:	jne    29fc992 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5db2>
 29fb983:	shl    $0x2,%edx
 29fb986:	add    $0x14,%edx
 29fb989:	jb     29fc994 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5db4>
 29fb98f:	add    %edx,%ecx
 29fb991:	jb     29fc996 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5db6>
 29fb997:	mov    %ecx,%r11d
 29fb99a:	lea    (%rdi,%r11,1),%r9
 29fb99e:	cmp    %rsi,%r11
 29fb9a1:	cmova  %r8,%r9
 29fb9a5:	lea    0x14(%r12),%ecx
 29fb9aa:	sub    %ecx,%edx
 29fb9ac:	sub    %rdx,%r9
 29fb9af:	mov    %eax,(%r9)
 29fb9b2:	mov    (%rsp),%eax
 29fb9b5:	test   %eax,%eax
 29fb9b7:	je     29fc998 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5db8>
 29fb9bd:	test   %eax,%eax
 29fb9bf:	je     29fc99a <wasm[0]::function[1013]::helper::array_indexed_publish+0x5dba>
 29fb9c5:	mov    0x88(%rsp),%rcx
 29fb9cd:	add    $0x1,%rcx
 29fb9d4:	mov    %eax,%edx
 29fb9d6:	lea    (%rdi,%rdx,1),%rax
 29fb9da:	cmp    %rsi,%rdx
 29fb9dd:	cmova  %r8,%rax
 29fb9e1:	mov    %rcx,0x18(%rax)
 29fb9e5:	mov    0xe0(%rsp),%rbx
 29fb9ed:	mov    0xe8(%rsp),%r12
 29fb9f5:	mov    0xf0(%rsp),%r13
 29fb9fd:	mov    0xf8(%rsp),%r14
 29fba05:	mov    0x100(%rsp),%r15
 29fba0d:	add    $0x110,%rsp
 29fba14:	mov    %rbp,%rsp
 29fba17:	pop    %rbp
 29fba18:	ret
 29fba19:	mov    0x60(%rsp),%rdi
 29fba1e:	call   3039b69 <wasmtime_builtin_new_epoch>
 29fba23:	mov    %rax,0xa8(%rsp)
 29fba2b:	mov    0x68(%rsp),%rcx
 29fba30:	jmp    29f6c7a <wasm[0]::function[1013]::helper::array_indexed_publish+0x9a>
 29fba35:	mov    0xc8(%rsp),%rbx
 29fba3d:	mov    0x8(%rbx),%rdi
 29fba41:	mov    %rdi,%r9
 29fba44:	mov    %rdi,0xa8(%rsp)
 29fba4c:	cmp    %r9,%rax
 29fba4f:	jb     29f70a1 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4c1>
 29fba55:	mov    0x60(%rsp),%rdi
 29fba5a:	call   3039b69 <wasmtime_builtin_new_epoch>
 29fba5f:	mov    %rax,0xa8(%rsp)
 29fba67:	jmp    29f70a1 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4c1>
 29fba6c:	mov    $0xa8000006,%esi
 29fba71:	mov    0x60(%rsp),%rdi
 29fba76:	mov    0x28(%rdi),%rax
 29fba7a:	mov    0x1a0(%rax),%edx
 29fba80:	mov    $0x10,%r8d
 29fba86:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 29fba8b:	mov    %eax,%ecx
 29fba8d:	mov    0xc8(%rsp),%rbx
 29fba95:	add    0x20(%rbx),%rcx
 29fba99:	jmp    29f7185 <wasm[0]::function[1013]::helper::array_indexed_publish+0x5a5>
 29fba9e:	mov    0xc8(%rsp),%rbx
 29fbaa6:	mov    0x8(%rbx),%rcx
 29fbaaa:	mov    %rcx,0xa8(%rsp)
 29fbab2:	cmp    %rcx,%rax
 29fbab5:	jb     29f723d <wasm[0]::function[1013]::helper::array_indexed_publish+0x65d>
 29fbabb:	mov    0x60(%rsp),%rdi
 29fbac0:	call   3039b69 <wasmtime_builtin_new_epoch>
 29fbac5:	mov    %rax,0xa8(%rsp)
 29fbacd:	jmp    29f723d <wasm[0]::function[1013]::helper::array_indexed_publish+0x65d>
 29fbad2:	mov    0xc8(%rsp),%rbx
 29fbada:	mov    0x8(%rbx),%rdi
 29fbade:	mov    %rdi,%r9
 29fbae1:	mov    %rdi,0xa8(%rsp)
 29fbae9:	cmp    %r9,%rax
 29fbaec:	jb     29f72c7 <wasm[0]::function[1013]::helper::array_indexed_publish+0x6e7>
 29fbaf2:	mov    0x60(%rsp),%rdi
 29fbaf7:	call   3039b69 <wasmtime_builtin_new_epoch>
 29fbafc:	mov    %rax,0xa8(%rsp)
 29fbb04:	jmp    29f72c7 <wasm[0]::function[1013]::helper::array_indexed_publish+0x6e7>
 29fbb09:	mov    0xc8(%rsp),%rbx
 29fbb11:	mov    0x8(%rbx),%rcx
 29fbb15:	mov    %rcx,0xa8(%rsp)
 29fbb1d:	cmp    %rcx,%rax
 29fbb20:	jb     29f7418 <wasm[0]::function[1013]::helper::array_indexed_publish+0x838>
 29fbb26:	mov    0x60(%rsp),%rdi
 29fbb2b:	call   3039b69 <wasmtime_builtin_new_epoch>
 29fbb30:	mov    %rax,0xa8(%rsp)
 29fbb38:	jmp    29f7418 <wasm[0]::function[1013]::helper::array_indexed_publish+0x838>
 29fbb3d:	mov    0xc8(%rsp),%rbx
 29fbb45:	mov    0x8(%rbx),%r10
 29fbb49:	mov    %r10,%rcx
 29fbb4c:	mov    %r10,0xa8(%rsp)
 29fbb54:	cmp    %rcx,%rax
 29fbb57:	jb     29f751b <wasm[0]::function[1013]::helper::array_indexed_publish+0x93b>
 29fbb5d:	mov    0x60(%rsp),%rdi
 29fbb62:	call   3039b69 <wasmtime_builtin_new_epoch>
 29fbb67:	mov    %rax,0xa8(%rsp)
 29fbb6f:	jmp    29f751b <wasm[0]::function[1013]::helper::array_indexed_publish+0x93b>
 29fbb74:	mov    0xc8(%rsp),%rbx
 29fbb7c:	mov    0x8(%rbx),%rcx
 29fbb80:	mov    %rcx,0xa8(%rsp)
 29fbb88:	cmp    %rcx,%rax
 29fbb8b:	jb     29f75d5 <wasm[0]::function[1013]::helper::array_indexed_publish+0x9f5>
 29fbb91:	mov    0x60(%rsp),%rdi
 29fbb96:	call   3039b69 <wasmtime_builtin_new_epoch>
 29fbb9b:	mov    %rax,0xa8(%rsp)
 29fbba3:	mov    %r12,%rcx
 29fbba6:	mov    %r15,%rdx
 29fbba9:	mov    0x80(%rsp),%rsi
 29fbbb1:	jmp    29f75e3 <wasm[0]::function[1013]::helper::array_indexed_publish+0xa03>
 29fbbb6:	mov    $0xa8000006,%esi
 29fbbbb:	mov    0x60(%rsp),%rdi
 29fbbc0:	mov    0x28(%rdi),%rax
 29fbbc4:	mov    0x1a4(%rax),%edx
 29fbbca:	mov    $0x10,%r8d
 29fbbd0:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 29fbbd5:	mov    %eax,%ecx
 29fbbd7:	mov    0xc8(%rsp),%rdx
 29fbbdf:	add    0x20(%rdx),%rcx
 29fbbe3:	jmp    29f770c <wasm[0]::function[1013]::helper::array_indexed_publish+0xb2c>
 29fbbe8:	mov    0xc8(%rsp),%rbx
 29fbbf0:	mov    0x8(%rbx),%rcx
 29fbbf4:	mov    %rcx,0xa8(%rsp)
 29fbbfc:	cmp    %rcx,%rax
 29fbbff:	jb     29f77cc <wasm[0]::function[1013]::helper::array_indexed_publish+0xbec>
 29fbc05:	mov    0x60(%rsp),%rdi
 29fbc0a:	call   3039b69 <wasmtime_builtin_new_epoch>
 29fbc0f:	mov    %rax,0xa8(%rsp)
 29fbc17:	jmp    29f77cc <wasm[0]::function[1013]::helper::array_indexed_publish+0xbec>
 29fbc1c:	mov    0xc8(%rsp),%rbx
 29fbc24:	mov    0x8(%rbx),%rsi
 29fbc28:	mov    %rsi,0xa8(%rsp)
 29fbc30:	cmp    %rsi,%rax
 29fbc33:	jb     29f7856 <wasm[0]::function[1013]::helper::array_indexed_publish+0xc76>
 29fbc39:	mov    0x60(%rsp),%rdi
 29fbc3e:	call   3039b69 <wasmtime_builtin_new_epoch>
 29fbc43:	mov    %rax,0xa8(%rsp)
 29fbc4b:	jmp    29f7856 <wasm[0]::function[1013]::helper::array_indexed_publish+0xc76>
 29fbc50:	mov    0xc8(%rsp),%rbx
 29fbc58:	mov    0x8(%rbx),%rax
 29fbc5c:	mov    %rax,0xa8(%rsp)
 29fbc64:	cmp    %rax,%r8
 29fbc67:	jb     29f7997 <wasm[0]::function[1013]::helper::array_indexed_publish+0xdb7>
 29fbc6d:	mov    0x60(%rsp),%rdi
 29fbc72:	call   3039b69 <wasmtime_builtin_new_epoch>
 29fbc77:	mov    %rax,0xa8(%rsp)
 29fbc7f:	jmp    29f7997 <wasm[0]::function[1013]::helper::array_indexed_publish+0xdb7>
 29fbc84:	mov    0xc8(%rsp),%rbx
 29fbc8c:	mov    0x8(%rbx),%rsi
 29fbc90:	mov    %rsi,%rdi
 29fbc93:	mov    %rsi,0xa8(%rsp)
 29fbc9b:	cmp    %rdi,%rax
 29fbc9e:	jb     29f7a81 <wasm[0]::function[1013]::helper::array_indexed_publish+0xea1>
 29fbca4:	mov    0x60(%rsp),%rdi
 29fbca9:	call   3039b69 <wasmtime_builtin_new_epoch>
 29fbcae:	mov    %rax,0xa8(%rsp)
 29fbcb6:	jmp    29f7a81 <wasm[0]::function[1013]::helper::array_indexed_publish+0xea1>
 29fbcbb:	mov    0xc8(%rsp),%rbx
 29fbcc3:	mov    0x8(%rbx),%rcx
 29fbcc7:	mov    %rcx,0xa8(%rsp)
 29fbccf:	cmp    %rcx,%rax
 29fbcd2:	jb     29f7b27 <wasm[0]::function[1013]::helper::array_indexed_publish+0xf47>
 29fbcd8:	mov    0x60(%rsp),%rdi
 29fbcdd:	call   3039b69 <wasmtime_builtin_new_epoch>
 29fbce2:	mov    %rax,0xa8(%rsp)
 29fbcea:	mov    %r12,%rcx
 29fbced:	mov    %r13,%rdx
 29fbcf0:	mov    %r15,%rsi
 29fbcf3:	jmp    29f7b30 <wasm[0]::function[1013]::helper::array_indexed_publish+0xf50>
 29fbcf8:	mov    $0xa8000006,%esi
 29fbcfd:	mov    0x60(%rsp),%rdi
 29fbd02:	mov    0x28(%rdi),%rax
 29fbd06:	mov    0x1a4(%rax),%edx
 29fbd0c:	mov    $0x10,%r8d
 29fbd12:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 29fbd17:	mov    %eax,%ecx
 29fbd19:	mov    0xc8(%rsp),%rdx
 29fbd21:	add    0x20(%rdx),%rcx
 29fbd25:	jmp    29f7d57 <wasm[0]::function[1013]::helper::array_indexed_publish+0x1177>
 29fbd2a:	mov    0xc8(%rsp),%rcx
 29fbd32:	mov    0x8(%rcx),%rcx
 29fbd36:	mov    %rcx,0xa8(%rsp)
 29fbd3e:	cmp    %rcx,%rax
 29fbd41:	jb     29f7e11 <wasm[0]::function[1013]::helper::array_indexed_publish+0x1231>
 29fbd47:	mov    0x60(%rsp),%rdi
 29fbd4c:	call   3039b69 <wasmtime_builtin_new_epoch>
 29fbd51:	mov    %rax,0xa8(%rsp)
 29fbd59:	jmp    29f7e11 <wasm[0]::function[1013]::helper::array_indexed_publish+0x1231>
 29fbd5e:	mov    0xc8(%rsp),%rbx
 29fbd66:	mov    0x8(%rbx),%rcx
 29fbd6a:	mov    %rcx,0xa8(%rsp)
 29fbd72:	cmp    %rcx,%rax
 29fbd75:	jb     29f7e8f <wasm[0]::function[1013]::helper::array_indexed_publish+0x12af>
 29fbd7b:	mov    0x60(%rsp),%rdi
 29fbd80:	call   3039b69 <wasmtime_builtin_new_epoch>
 29fbd85:	mov    %rax,0xa8(%rsp)
 29fbd8d:	jmp    29f7e8f <wasm[0]::function[1013]::helper::array_indexed_publish+0x12af>
 29fbd92:	mov    0xc8(%rsp),%rsi
 29fbd9a:	mov    0x8(%rsi),%rax
 29fbd9e:	mov    %rax,0xa8(%rsp)
 29fbda6:	cmp    %rax,%rcx
 29fbda9:	jb     29f7ef8 <wasm[0]::function[1013]::helper::array_indexed_publish+0x1318>
 29fbdaf:	mov    0x60(%rsp),%rdi
 29fbdb4:	call   3039b69 <wasmtime_builtin_new_epoch>
 29fbdb9:	mov    %rax,0xa8(%rsp)
 29fbdc1:	jmp    29f7ef8 <wasm[0]::function[1013]::helper::array_indexed_publish+0x1318>
 29fbdc6:	mov    $0xa800000e,%esi
 29fbdcb:	mov    0x60(%rsp),%rdi
 29fbdd0:	mov    0x28(%rdi),%rax
 29fbdd4:	mov    0x19c(%rax),%edx
 29fbdda:	mov    $0x10,%r8d
 29fbde0:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 29fbde5:	mov    %eax,%ecx
 29fbde7:	mov    0xc8(%rsp),%rdx
 29fbdef:	add    0x20(%rdx),%rcx
 29fbdf3:	jmp    29f8617 <wasm[0]::function[1013]::helper::array_indexed_publish+0x1a37>
 29fbdf8:	mov    0xc8(%rsp),%rbx
 29fbe00:	mov    0x8(%rbx),%r10
 29fbe04:	mov    %r10,%rcx
 29fbe07:	mov    %r10,0xa8(%rsp)
 29fbe0f:	cmp    %rcx,%rax
 29fbe12:	jb     29f86c5 <wasm[0]::function[1013]::helper::array_indexed_publish+0x1ae5>
 29fbe18:	mov    0x60(%rsp),%rdi
 29fbe1d:	call   3039b69 <wasmtime_builtin_new_epoch>
 29fbe22:	mov    %rax,0xa8(%rsp)
 29fbe2a:	jmp    29f86c5 <wasm[0]::function[1013]::helper::array_indexed_publish+0x1ae5>
 29fbe2f:	mov    0xc8(%rsp),%rbx
 29fbe37:	mov    0x8(%rbx),%rcx
 29fbe3b:	mov    %rcx,0xa8(%rsp)
 29fbe43:	cmp    %rcx,%rax
 29fbe46:	jb     29f875f <wasm[0]::function[1013]::helper::array_indexed_publish+0x1b7f>
 29fbe4c:	mov    0x60(%rsp),%rdi
 29fbe51:	call   3039b69 <wasmtime_builtin_new_epoch>
 29fbe56:	mov    %rax,0xa8(%rsp)
 29fbe5e:	mov    0x80(%rsp),%rcx
 29fbe66:	jmp    29f8767 <wasm[0]::function[1013]::helper::array_indexed_publish+0x1b87>
 29fbe6b:	mov    $0xb0000042,%esi
 29fbe70:	mov    $0x20,%ecx
 29fbe75:	mov    0xb8(%rsp),%r15
 29fbe7d:	mov    %r15,%rdx
 29fbe80:	mov    0x60(%rsp),%rdi
 29fbe85:	mov    0xb0(%rsp),%r8
 29fbe8d:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 29fbe92:	mov    %eax,%esi
 29fbe94:	mov    0xc8(%rsp),%rbx
 29fbe9c:	add    0x20(%rbx),%rsi
 29fbea0:	mov    0x78(%rsp),%rcx
 29fbea5:	mov    0x88(%rsp),%rdx
 29fbead:	jmp    29f8ad0 <wasm[0]::function[1013]::helper::array_indexed_publish+0x1ef0>
 29fbeb2:	mov    0xc8(%rsp),%rsi
 29fbeba:	mov    0x8(%rsi),%rcx
 29fbebe:	mov    %rcx,0xa8(%rsp)
 29fbec6:	cmp    %rcx,%rax
 29fbec9:	jb     29f8d99 <wasm[0]::function[1013]::helper::array_indexed_publish+0x21b9>
 29fbecf:	mov    0x60(%rsp),%rdi
 29fbed4:	call   3039b69 <wasmtime_builtin_new_epoch>
 29fbed9:	mov    %rax,0xa8(%rsp)
 29fbee1:	jmp    29f8d99 <wasm[0]::function[1013]::helper::array_indexed_publish+0x21b9>
 29fbee6:	mov    $0xa800000e,%esi
 29fbeeb:	mov    0x60(%rsp),%rdi
 29fbef0:	mov    0x28(%rdi),%rax
 29fbef4:	mov    0x19c(%rax),%edx
 29fbefa:	mov    $0x10,%r8d
 29fbf00:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 29fbf05:	mov    %eax,%ecx
 29fbf07:	mov    0xc8(%rsp),%rdx
 29fbf0f:	add    0x20(%rdx),%rcx
 29fbf13:	jmp    29f8e55 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2275>
 29fbf18:	mov    0xc8(%rsp),%rcx
 29fbf20:	mov    0x8(%rcx),%rsi
 29fbf24:	mov    %rsi,%r8
 29fbf27:	mov    %rsi,0xa8(%rsp)
 29fbf2f:	cmp    %r8,%rax
 29fbf32:	jb     29f8f03 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2323>
 29fbf38:	mov    0x60(%rsp),%rdi
 29fbf3d:	call   3039b69 <wasmtime_builtin_new_epoch>
 29fbf42:	mov    %rax,0xa8(%rsp)
 29fbf4a:	jmp    29f8f03 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2323>
 29fbf4f:	mov    0xc8(%rsp),%rcx
 29fbf57:	mov    0x8(%rcx),%rcx
 29fbf5b:	mov    %rcx,0xa8(%rsp)
 29fbf63:	cmp    %rcx,%rax
 29fbf66:	jb     29f9066 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2486>
 29fbf6c:	mov    0x60(%rsp),%rdi
 29fbf71:	call   3039b69 <wasmtime_builtin_new_epoch>
 29fbf76:	mov    %rax,0xa8(%rsp)
 29fbf7e:	jmp    29f9066 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2486>
 29fbf83:	mov    0xc8(%rsp),%rbx
 29fbf8b:	mov    0x8(%rbx),%rcx
 29fbf8f:	mov    %rcx,0xa8(%rsp)
 29fbf97:	cmp    %rcx,%rax
 29fbf9a:	jb     29f90f9 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2519>
 29fbfa0:	mov    0x60(%rsp),%rdi
 29fbfa5:	call   3039b69 <wasmtime_builtin_new_epoch>
 29fbfaa:	mov    %rax,0xa8(%rsp)
 29fbfb2:	jmp    29f90f9 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2519>
 29fbfb7:	mov    $0xb0000042,%esi
 29fbfbc:	mov    0x60(%rsp),%rdi
 29fbfc1:	mov    0x28(%rdi),%rax
 29fbfc5:	mov    0x120(%rax),%edx
 29fbfcb:	mov    $0x20,%ecx
 29fbfd0:	mov    $0x10,%r8d
 29fbfd6:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 29fbfdb:	mov    %eax,%esi
 29fbfdd:	mov    0xc8(%rsp),%rbx
 29fbfe5:	add    0x20(%rbx),%rsi
 29fbfe9:	mov    0x90(%rsp),%rdi
 29fbff1:	jmp    29f9201 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2621>
 29fbff6:	mov    $0xa800000e,%esi
 29fbffb:	mov    0x60(%rsp),%rdi
 29fc000:	mov    0x28(%rdi),%rax
 29fc004:	mov    0x194(%rax),%edx
 29fc00a:	mov    $0x10,%r8d
 29fc010:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 29fc015:	mov    %eax,%ecx
 29fc017:	mov    0xc8(%rsp),%rdx
 29fc01f:	add    0x20(%rdx),%rcx
 29fc023:	jmp    29f957a <wasm[0]::function[1013]::helper::array_indexed_publish+0x299a>
 29fc028:	mov    0xc8(%rsp),%rbx
 29fc030:	mov    0x8(%rbx),%rax
 29fc034:	mov    %rax,0xa8(%rsp)
 29fc03c:	cmp    %rax,%rsi
 29fc03f:	jb     29f9630 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2a50>
 29fc045:	mov    0x60(%rsp),%rdi
 29fc04a:	call   3039b69 <wasmtime_builtin_new_epoch>
 29fc04f:	mov    %rax,0xa8(%rsp)
 29fc057:	jmp    29f9630 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2a50>
 29fc05c:	mov    0xc8(%rsp),%rbx
 29fc064:	mov    0x8(%rbx),%rcx
 29fc068:	mov    %rcx,0xa8(%rsp)
 29fc070:	cmp    %rcx,%rax
 29fc073:	jb     29f96e4 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2b04>
 29fc079:	mov    0x60(%rsp),%rdi
 29fc07e:	call   3039b69 <wasmtime_builtin_new_epoch>
 29fc083:	mov    %rax,0xa8(%rsp)
 29fc08b:	mov    0x80(%rsp),%rcx
 29fc093:	jmp    29f96ec <wasm[0]::function[1013]::helper::array_indexed_publish+0x2b0c>
 29fc098:	mov    0xb0(%rsp),%rcx
 29fc0a0:	mov    0xb8(%rsp),%rdx
 29fc0a8:	mov    0xc0(%rsp),%rsi
 29fc0b0:	mov    0x60(%rsp),%rdi
 29fc0b5:	mov    0x98(%rsp),%r8
 29fc0bd:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 29fc0c2:	mov    %eax,%ecx
 29fc0c4:	mov    0xc8(%rsp),%rbx
 29fc0cc:	add    0x20(%rbx),%rcx
 29fc0d0:	mov    0x78(%rsp),%r14
 29fc0d5:	jmp    29f9909 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2d29>
 29fc0da:	mov    $0xb0000072,%esi
 29fc0df:	mov    0x90(%rsp),%r13
 29fc0e7:	mov    0xb0(%rsp),%rcx
 29fc0ef:	mov    %r13,%rdx
 29fc0f2:	mov    0x60(%rsp),%rdi
 29fc0f7:	mov    0x98(%rsp),%r8
 29fc0ff:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 29fc104:	mov    %eax,%r11d
 29fc107:	mov    0xc8(%rsp),%rbx
 29fc10f:	add    0x20(%rbx),%r11
 29fc113:	jmp    29f9983 <wasm[0]::function[1013]::helper::array_indexed_publish+0x2da3>
 29fc118:	mov    $0xa800000e,%esi
 29fc11d:	mov    0x60(%rsp),%rdi
 29fc122:	mov    0x28(%rdi),%rax
 29fc126:	mov    0x194(%rax),%edx
 29fc12c:	mov    $0x10,%r8d
 29fc132:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 29fc137:	mov    %eax,%ecx
 29fc139:	mov    0xc8(%rsp),%rdx
 29fc141:	add    0x20(%rdx),%rcx
 29fc145:	jmp    29f9bed <wasm[0]::function[1013]::helper::array_indexed_publish+0x300d>
 29fc14a:	mov    0xc8(%rsp),%rbx
 29fc152:	mov    0x8(%rbx),%r9
 29fc156:	mov    %r9,%r11
 29fc159:	mov    %r9,0xa8(%rsp)
 29fc161:	cmp    %r11,%rax
 29fc164:	jb     29f9c94 <wasm[0]::function[1013]::helper::array_indexed_publish+0x30b4>
 29fc16a:	mov    0x60(%rsp),%rdi
 29fc16f:	call   3039b69 <wasmtime_builtin_new_epoch>
 29fc174:	mov    %rax,0xa8(%rsp)
 29fc17c:	jmp    29f9c94 <wasm[0]::function[1013]::helper::array_indexed_publish+0x30b4>
 29fc181:	mov    0xc8(%rsp),%rbx
 29fc189:	mov    0x8(%rbx),%rax
 29fc18d:	mov    %rax,0xa8(%rsp)
 29fc195:	cmp    %rax,%rsi
 29fc198:	jb     29f9d2d <wasm[0]::function[1013]::helper::array_indexed_publish+0x314d>
 29fc19e:	mov    0x60(%rsp),%rdi
 29fc1a3:	call   3039b69 <wasmtime_builtin_new_epoch>
 29fc1a8:	mov    %rax,0xa8(%rsp)
 29fc1b0:	mov    0x90(%rsp),%rcx
 29fc1b8:	jmp    29f9d35 <wasm[0]::function[1013]::helper::array_indexed_publish+0x3155>
 29fc1bd:	mov    0x78(%rsp),%rcx
 29fc1c2:	mov    %r13,%rdx
 29fc1c5:	mov    0x80(%rsp),%rsi
 29fc1cd:	mov    0x60(%rsp),%rdi
 29fc1d2:	mov    0xc0(%rsp),%r8
 29fc1da:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 29fc1df:	mov    %eax,%edx
 29fc1e1:	mov    0xc8(%rsp),%rbx
 29fc1e9:	add    0x20(%rbx),%rdx
 29fc1ed:	mov    0x88(%rsp),%rcx
 29fc1f5:	jmp    29f9e3d <wasm[0]::function[1013]::helper::array_indexed_publish+0x325d>
 29fc1fa:	mov    0xc8(%rsp),%rbx
 29fc202:	mov    0x8(%rbx),%rsi
 29fc206:	mov    %rsi,%r8
 29fc209:	mov    %rsi,0xa8(%rsp)
 29fc211:	cmp    %r8,%rax
 29fc214:	jb     29fa0cc <wasm[0]::function[1013]::helper::array_indexed_publish+0x34ec>
 29fc21a:	mov    0x60(%rsp),%rdi
 29fc21f:	call   3039b69 <wasmtime_builtin_new_epoch>
 29fc224:	mov    %rax,0xa8(%rsp)
 29fc22c:	mov    0x98(%rsp),%rdi
 29fc234:	jmp    29fa0d4 <wasm[0]::function[1013]::helper::array_indexed_publish+0x34f4>
 29fc239:	mov    $0xa800000e,%esi
 29fc23e:	mov    0x60(%rsp),%rdi
 29fc243:	mov    0x28(%rdi),%rax
 29fc247:	mov    0x1ac(%rax),%edx
 29fc24d:	mov    $0x10,%r8d
 29fc253:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 29fc258:	mov    %eax,%ecx
 29fc25a:	mov    0xc8(%rsp),%rdx
 29fc262:	add    0x20(%rdx),%rcx
 29fc266:	jmp    29fa1bf <wasm[0]::function[1013]::helper::array_indexed_publish+0x35df>
 29fc26b:	mov    0xc8(%rsp),%rbx
 29fc273:	mov    0x8(%rbx),%rcx
 29fc277:	mov    %rcx,0xa8(%rsp)
 29fc27f:	cmp    %rcx,%rax
 29fc282:	jb     29fa26e <wasm[0]::function[1013]::helper::array_indexed_publish+0x368e>
 29fc288:	mov    0x60(%rsp),%rdi
 29fc28d:	call   3039b69 <wasmtime_builtin_new_epoch>
 29fc292:	mov    %rax,0xa8(%rsp)
 29fc29a:	jmp    29fa26e <wasm[0]::function[1013]::helper::array_indexed_publish+0x368e>
 29fc29f:	mov    0xc8(%rsp),%rbx
 29fc2a7:	mov    0x8(%rbx),%rdi
 29fc2ab:	mov    %rdi,%r9
 29fc2ae:	mov    %rdi,0xa8(%rsp)
 29fc2b6:	cmp    %r9,%rax
 29fc2b9:	jb     29fa2f6 <wasm[0]::function[1013]::helper::array_indexed_publish+0x3716>
 29fc2bf:	mov    0x60(%rsp),%rdi
 29fc2c4:	call   3039b69 <wasmtime_builtin_new_epoch>
 29fc2c9:	mov    %rax,0xa8(%rsp)
 29fc2d1:	mov    0x78(%rsp),%rcx
 29fc2d6:	jmp    29fa2fb <wasm[0]::function[1013]::helper::array_indexed_publish+0x371b>
 29fc2db:	mov    $0xb0000062,%esi
 29fc2e0:	mov    0x88(%rsp),%rcx
 29fc2e8:	mov    0x90(%rsp),%rdx
 29fc2f0:	mov    0x60(%rsp),%rdi
 29fc2f5:	mov    0x80(%rsp),%r8
 29fc2fd:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 29fc302:	mov    %eax,%esi
 29fc304:	mov    0xc8(%rsp),%rbx
 29fc30c:	add    0x20(%rbx),%rsi
 29fc310:	mov    0xc0(%rsp),%rcx
 29fc318:	mov    0x90(%rsp),%rdx
 29fc320:	jmp    29fa4e6 <wasm[0]::function[1013]::helper::array_indexed_publish+0x3906>
 29fc325:	mov    0xc8(%rsp),%rbx
 29fc32d:	mov    0x8(%rbx),%rax
 29fc331:	mov    %rax,0xa8(%rsp)
 29fc339:	cmp    %rax,%rsi
 29fc33c:	jb     29fa692 <wasm[0]::function[1013]::helper::array_indexed_publish+0x3ab2>
 29fc342:	mov    0x60(%rsp),%rdi
 29fc347:	call   3039b69 <wasmtime_builtin_new_epoch>
 29fc34c:	mov    %rax,0xa8(%rsp)
 29fc354:	jmp    29fa692 <wasm[0]::function[1013]::helper::array_indexed_publish+0x3ab2>
 29fc359:	mov    $0xa800000e,%esi
 29fc35e:	mov    0x60(%rsp),%rdi
 29fc363:	mov    0x28(%rdi),%rax
 29fc367:	mov    0x194(%rax),%edx
 29fc36d:	mov    $0x10,%r8d
 29fc373:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 29fc378:	mov    %eax,%edi
 29fc37a:	mov    0xc8(%rsp),%rbx
 29fc382:	add    0x20(%rbx),%rdi
 29fc386:	jmp    29fa750 <wasm[0]::function[1013]::helper::array_indexed_publish+0x3b70>
 29fc38b:	mov    0xc8(%rsp),%rsi
 29fc393:	mov    0x8(%rsi),%rax
 29fc397:	mov    %rax,0xa8(%rsp)
 29fc39f:	cmp    %rax,%rcx
 29fc3a2:	jb     29fa7f9 <wasm[0]::function[1013]::helper::array_indexed_publish+0x3c19>
 29fc3a8:	mov    0x60(%rsp),%rdi
 29fc3ad:	call   3039b69 <wasmtime_builtin_new_epoch>
 29fc3b2:	mov    %rax,0xa8(%rsp)
 29fc3ba:	jmp    29fa7f9 <wasm[0]::function[1013]::helper::array_indexed_publish+0x3c19>
 29fc3bf:	mov    0xc8(%rsp),%rbx
 29fc3c7:	mov    0x8(%rbx),%rcx
 29fc3cb:	mov    %rcx,0xa8(%rsp)
 29fc3d3:	cmp    %rcx,%rax
 29fc3d6:	jb     29fa99e <wasm[0]::function[1013]::helper::array_indexed_publish+0x3dbe>
 29fc3dc:	mov    0x60(%rsp),%rdi
 29fc3e1:	call   3039b69 <wasmtime_builtin_new_epoch>
 29fc3e6:	mov    %rax,0xa8(%rsp)
 29fc3ee:	jmp    29fa99e <wasm[0]::function[1013]::helper::array_indexed_publish+0x3dbe>
 29fc3f3:	mov    0xc8(%rsp),%rax
 29fc3fb:	mov    0x8(%rax),%rax
 29fc3ff:	mov    %rax,0xa8(%rsp)
 29fc407:	cmp    %rax,%rcx
 29fc40a:	jb     29faa35 <wasm[0]::function[1013]::helper::array_indexed_publish+0x3e55>
 29fc410:	mov    0x60(%rsp),%rdi
 29fc415:	call   3039b69 <wasmtime_builtin_new_epoch>
 29fc41a:	mov    %rax,0xa8(%rsp)
 29fc422:	jmp    29faa35 <wasm[0]::function[1013]::helper::array_indexed_publish+0x3e55>
 29fc427:	mov    $0xa800000e,%esi
 29fc42c:	mov    0x60(%rsp),%rdi
 29fc431:	mov    0x28(%rdi),%rax
 29fc435:	mov    0x1ac(%rax),%edx
 29fc43b:	mov    $0x34,%ecx
 29fc440:	mov    $0x10,%r8d
 29fc446:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 29fc44b:	mov    %eax,%edx
 29fc44d:	mov    0xc8(%rsp),%rbx
 29fc455:	add    0x20(%rbx),%rdx
 29fc459:	jmp    29fad38 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4158>
 29fc45e:	mov    0xc8(%rsp),%rbx
 29fc466:	mov    0x8(%rbx),%rcx
 29fc46a:	mov    %rcx,0xa8(%rsp)
 29fc472:	cmp    %rcx,%rax
 29fc475:	jb     29fadd7 <wasm[0]::function[1013]::helper::array_indexed_publish+0x41f7>
 29fc47b:	mov    0x60(%rsp),%rdi
 29fc480:	call   3039b69 <wasmtime_builtin_new_epoch>
 29fc485:	mov    %rax,0xa8(%rsp)
 29fc48d:	jmp    29fadd7 <wasm[0]::function[1013]::helper::array_indexed_publish+0x41f7>
 29fc492:	mov    0xc8(%rsp),%rbx
 29fc49a:	mov    0x8(%rbx),%rax
 29fc49e:	mov    %rax,0xa8(%rsp)
 29fc4a6:	cmp    %rax,%rcx
 29fc4a9:	jb     29fae78 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4298>
 29fc4af:	mov    0x60(%rsp),%rdi
 29fc4b4:	call   3039b69 <wasmtime_builtin_new_epoch>
 29fc4b9:	mov    %rax,0xa8(%rsp)
 29fc4c1:	mov    0x98(%rsp),%rax
 29fc4c9:	jmp    29fae80 <wasm[0]::function[1013]::helper::array_indexed_publish+0x42a0>
 29fc4ce:	mov    0xc8(%rsp),%rbx
 29fc4d6:	mov    0x8(%rbx),%rax
 29fc4da:	mov    %rax,0xa8(%rsp)
 29fc4e2:	cmp    %rax,%rcx
 29fc4e5:	jb     29faf52 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4372>
 29fc4eb:	mov    0x60(%rsp),%rdi
 29fc4f0:	call   3039b69 <wasmtime_builtin_new_epoch>
 29fc4f5:	mov    %rax,0xa8(%rsp)
 29fc4fd:	jmp    29faf52 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4372>
 29fc502:	mov    0xc8(%rsp),%rbx
 29fc50a:	mov    0x8(%rbx),%rcx
 29fc50e:	mov    %rcx,0xa8(%rsp)
 29fc516:	cmp    %rcx,%rax
 29fc519:	jb     29fb22c <wasm[0]::function[1013]::helper::array_indexed_publish+0x464c>
 29fc51f:	mov    0x60(%rsp),%rdi
 29fc524:	call   3039b69 <wasmtime_builtin_new_epoch>
 29fc529:	mov    %rax,0xa8(%rsp)
 29fc531:	jmp    29fb22c <wasm[0]::function[1013]::helper::array_indexed_publish+0x464c>
 29fc536:	mov    $0xa800000e,%esi
 29fc53b:	mov    0x60(%rsp),%rdi
 29fc540:	mov    0x28(%rdi),%rax
 29fc544:	mov    0x1ac(%rax),%edx
 29fc54a:	mov    0x98(%rsp),%r8
 29fc552:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 29fc557:	mov    %eax,%ecx
 29fc559:	mov    0xc8(%rsp),%rbx
 29fc561:	add    0x20(%rbx),%rcx
 29fc565:	jmp    29fb443 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4863>
 29fc56a:	mov    0xc8(%rsp),%rax
 29fc572:	mov    0x8(%rax),%rax
 29fc576:	mov    %rax,0xa8(%rsp)
 29fc57e:	cmp    %rax,%rsi
 29fc581:	jb     29fb4e0 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4900>
 29fc587:	mov    0x60(%rsp),%rdi
 29fc58c:	call   3039b69 <wasmtime_builtin_new_epoch>
 29fc591:	mov    %rax,0xa8(%rsp)
 29fc599:	jmp    29fb4e0 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4900>
 29fc59e:	mov    0xc8(%rsp),%rbx
 29fc5a6:	mov    0x8(%rbx),%rcx
 29fc5aa:	mov    %rcx,0xa8(%rsp)
 29fc5b2:	cmp    %rcx,%rax
 29fc5b5:	jb     29fb574 <wasm[0]::function[1013]::helper::array_indexed_publish+0x4994>
 29fc5bb:	mov    0x60(%rsp),%rdi
 29fc5c0:	call   3039b69 <wasmtime_builtin_new_epoch>
 29fc5c5:	mov    %rax,0xa8(%rsp)
 29fc5cd:	mov    0x80(%rsp),%rax
 29fc5d5:	jmp    29fb57c <wasm[0]::function[1013]::helper::array_indexed_publish+0x499c>
 29fc5da:	mov    0xc8(%rsp),%rbx
 29fc5e2:	mov    0x8(%rbx),%rcx
 29fc5e6:	mov    %rcx,0xa8(%rsp)
 29fc5ee:	cmp    %rcx,%rax
 29fc5f1:	jb     29fb64d <wasm[0]::function[1013]::helper::array_indexed_publish+0x4a6d>
 29fc5f7:	mov    0x60(%rsp),%rdi
 29fc5fc:	call   3039b69 <wasmtime_builtin_new_epoch>
 29fc601:	mov    %rax,0xa8(%rsp)
 29fc609:	jmp    29fb64d <wasm[0]::function[1013]::helper::array_indexed_publish+0x4a6d>
 29fc60e:	mov    $0xb0000062,%esi
 29fc613:	mov    0x60(%rsp),%rdi
 29fc618:	mov    0x28(%rdi),%rax
 29fc61c:	mov    0x1a8(%rax),%edx
 29fc622:	mov    $0x20,%ecx
 29fc627:	mov    0x98(%rsp),%r8
 29fc62f:	call   3039bca <wasmtime_builtin_gc_alloc_raw>
 29fc634:	mov    %eax,%ecx
 29fc636:	mov    0xc8(%rsp),%rbx
 29fc63e:	add    0x20(%rbx),%rcx
 29fc642:	mov    0x68(%rsp),%rdx
 29fc647:	jmp    29fb90f <wasm[0]::function[1013]::helper::array_indexed_publish+0x4d2f>
 29fc64c:	ud2
 29fc64e:	ud2
 29fc650:	ud2
 29fc652:	ud2
 29fc654:	ud2
 29fc656:	ud2
 29fc658:	ud2
 29fc65a:	ud2
 29fc65c:	ud2
 29fc65e:	ud2
 29fc660:	ud2
 29fc662:	ud2
 29fc664:	ud2
 29fc666:	ud2
 29fc668:	ud2
 29fc66a:	ud2
 29fc66c:	ud2
 29fc66e:	ud2
 29fc670:	ud2
 29fc672:	ud2
 29fc674:	ud2
 29fc676:	ud2
 29fc678:	ud2
 29fc67a:	ud2
 29fc67c:	ud2
 29fc67e:	ud2
 29fc680:	ud2
 29fc682:	ud2
 29fc684:	ud2
 29fc686:	ud2
 29fc688:	ud2
 29fc68a:	ud2
 29fc68c:	ud2
 29fc68e:	ud2
 29fc690:	ud2
 29fc692:	ud2
 29fc694:	ud2
 29fc696:	ud2
 29fc698:	ud2
 29fc69a:	ud2
 29fc69c:	ud2
 29fc69e:	ud2
 29fc6a0:	ud2
 29fc6a2:	ud2
 29fc6a4:	ud2
 29fc6a6:	ud2
 29fc6a8:	ud2
 29fc6aa:	ud2
 29fc6ac:	ud2
 29fc6ae:	ud2
 29fc6b0:	ud2
 29fc6b2:	ud2
 29fc6b4:	ud2
 29fc6b6:	ud2
 29fc6b8:	ud2
 29fc6ba:	ud2
 29fc6bc:	ud2
 29fc6be:	ud2
 29fc6c0:	ud2
 29fc6c2:	ud2
 29fc6c4:	ud2
 29fc6c6:	ud2
 29fc6c8:	ud2
 29fc6ca:	ud2
 29fc6cc:	ud2
 29fc6ce:	ud2
 29fc6d0:	ud2
 29fc6d2:	ud2
 29fc6d4:	ud2
 29fc6d6:	ud2
 29fc6d8:	ud2
 29fc6da:	ud2
 29fc6dc:	ud2
 29fc6de:	ud2
 29fc6e0:	ud2
 29fc6e2:	ud2
 29fc6e4:	ud2
 29fc6e6:	ud2
 29fc6e8:	ud2
 29fc6ea:	ud2
 29fc6ec:	ud2
 29fc6ee:	ud2
 29fc6f0:	ud2
 29fc6f2:	ud2
 29fc6f4:	ud2
 29fc6f6:	ud2
 29fc6f8:	ud2
 29fc6fa:	ud2
 29fc6fc:	ud2
 29fc6fe:	ud2
 29fc700:	ud2
 29fc702:	ud2
 29fc704:	ud2
 29fc706:	ud2
 29fc708:	ud2
 29fc70a:	ud2
 29fc70c:	ud2
 29fc70e:	ud2
 29fc710:	ud2
 29fc712:	ud2
 29fc714:	ud2
 29fc716:	ud2
 29fc718:	ud2
 29fc71a:	ud2
 29fc71c:	ud2
 29fc71e:	ud2
 29fc720:	ud2
 29fc722:	ud2
 29fc724:	ud2
 29fc726:	ud2
 29fc728:	ud2
 29fc72a:	ud2
 29fc72c:	ud2
 29fc72e:	ud2
 29fc730:	ud2
 29fc732:	ud2
 29fc734:	ud2
 29fc736:	ud2
 29fc738:	ud2
 29fc73a:	ud2
 29fc73c:	ud2
 29fc73e:	ud2
 29fc740:	ud2
 29fc742:	ud2
 29fc744:	ud2
 29fc746:	ud2
 29fc748:	ud2
 29fc74a:	ud2
 29fc74c:	ud2
 29fc74e:	ud2
 29fc750:	ud2
 29fc752:	ud2
 29fc754:	ud2
 29fc756:	ud2
 29fc758:	ud2
 29fc75a:	ud2
 29fc75c:	ud2
 29fc75e:	ud2
 29fc760:	ud2
 29fc762:	ud2
 29fc764:	ud2
 29fc766:	ud2
 29fc768:	ud2
 29fc76a:	ud2
 29fc76c:	ud2
 29fc76e:	ud2
 29fc770:	ud2
 29fc772:	ud2
 29fc774:	ud2
 29fc776:	ud2
 29fc778:	ud2
 29fc77a:	ud2
 29fc77c:	ud2
 29fc77e:	ud2
 29fc780:	ud2
 29fc782:	ud2
 29fc784:	ud2
 29fc786:	ud2
 29fc788:	ud2
 29fc78a:	ud2
 29fc78c:	ud2
 29fc78e:	ud2
 29fc790:	ud2
 29fc792:	ud2
 29fc794:	ud2
 29fc796:	ud2
 29fc798:	ud2
 29fc79a:	ud2
 29fc79c:	ud2
 29fc79e:	ud2
 29fc7a0:	ud2
 29fc7a2:	ud2
 29fc7a4:	ud2
 29fc7a6:	ud2
 29fc7a8:	ud2
 29fc7aa:	ud2
 29fc7ac:	ud2
 29fc7ae:	ud2
 29fc7b0:	ud2
 29fc7b2:	ud2
 29fc7b4:	ud2
 29fc7b6:	ud2
 29fc7b8:	ud2
 29fc7ba:	ud2
 29fc7bc:	ud2
 29fc7be:	ud2
 29fc7c0:	ud2
 29fc7c2:	ud2
 29fc7c4:	ud2
 29fc7c6:	ud2
 29fc7c8:	ud2
 29fc7ca:	ud2
 29fc7cc:	ud2
 29fc7ce:	ud2
 29fc7d0:	ud2
 29fc7d2:	ud2
 29fc7d4:	ud2
 29fc7d6:	ud2
 29fc7d8:	ud2
 29fc7da:	ud2
 29fc7dc:	ud2
 29fc7de:	ud2
 29fc7e0:	ud2
 29fc7e2:	ud2
 29fc7e4:	ud2
 29fc7e6:	ud2
 29fc7e8:	ud2
 29fc7ea:	ud2
 29fc7ec:	ud2
 29fc7ee:	ud2
 29fc7f0:	ud2
 29fc7f2:	ud2
 29fc7f4:	ud2
 29fc7f6:	ud2
 29fc7f8:	ud2
 29fc7fa:	ud2
 29fc7fc:	ud2
 29fc7fe:	ud2
 29fc800:	ud2
 29fc802:	ud2
 29fc804:	ud2
 29fc806:	ud2
 29fc808:	ud2
 29fc80a:	ud2
 29fc80c:	ud2
 29fc80e:	ud2
 29fc810:	ud2
 29fc812:	ud2
 29fc814:	ud2
 29fc816:	ud2
 29fc818:	ud2
 29fc81a:	ud2
 29fc81c:	ud2
 29fc81e:	ud2
 29fc820:	ud2
 29fc822:	ud2
 29fc824:	ud2
 29fc826:	ud2
 29fc828:	ud2
 29fc82a:	ud2
 29fc82c:	ud2
 29fc82e:	ud2
 29fc830:	ud2
 29fc832:	ud2
 29fc834:	ud2
 29fc836:	ud2
 29fc838:	ud2
 29fc83a:	ud2
 29fc83c:	ud2
 29fc83e:	ud2
 29fc840:	ud2
 29fc842:	ud2
 29fc844:	ud2
 29fc846:	ud2
 29fc848:	ud2
 29fc84a:	ud2
 29fc84c:	ud2
 29fc84e:	ud2
 29fc850:	ud2
 29fc852:	ud2
 29fc854:	ud2
 29fc856:	ud2
 29fc858:	ud2
 29fc85a:	ud2
 29fc85c:	ud2
 29fc85e:	ud2
 29fc860:	ud2
 29fc862:	ud2
 29fc864:	ud2
 29fc866:	ud2
 29fc868:	ud2
 29fc86a:	ud2
 29fc86c:	ud2
 29fc86e:	ud2
 29fc870:	ud2
 29fc872:	ud2
 29fc874:	ud2
 29fc876:	ud2
 29fc878:	ud2
 29fc87a:	ud2
 29fc87c:	ud2
 29fc87e:	ud2
 29fc880:	ud2
 29fc882:	ud2
 29fc884:	ud2
 29fc886:	ud2
 29fc888:	ud2
 29fc88a:	ud2
 29fc88c:	ud2
 29fc88e:	ud2
 29fc890:	ud2
 29fc892:	ud2
 29fc894:	ud2
 29fc896:	ud2
 29fc898:	ud2
 29fc89a:	ud2
 29fc89c:	ud2
 29fc89e:	ud2
 29fc8a0:	ud2
 29fc8a2:	ud2
 29fc8a4:	ud2
 29fc8a6:	ud2
 29fc8a8:	ud2
 29fc8aa:	ud2
 29fc8ac:	ud2
 29fc8ae:	ud2
 29fc8b0:	ud2
 29fc8b2:	ud2
 29fc8b4:	ud2
 29fc8b6:	ud2
 29fc8b8:	ud2
 29fc8ba:	ud2
 29fc8bc:	ud2
 29fc8be:	ud2
 29fc8c0:	ud2
 29fc8c2:	ud2
 29fc8c4:	ud2
 29fc8c6:	ud2
 29fc8c8:	ud2
 29fc8ca:	ud2
 29fc8cc:	ud2
 29fc8ce:	ud2
 29fc8d0:	ud2
 29fc8d2:	ud2
 29fc8d4:	ud2
 29fc8d6:	ud2
 29fc8d8:	ud2
 29fc8da:	ud2
 29fc8dc:	ud2
 29fc8de:	ud2
 29fc8e0:	ud2
 29fc8e2:	ud2
 29fc8e4:	ud2
 29fc8e6:	ud2
 29fc8e8:	ud2
 29fc8ea:	ud2
 29fc8ec:	ud2
 29fc8ee:	ud2
 29fc8f0:	ud2
 29fc8f2:	ud2
 29fc8f4:	ud2
 29fc8f6:	ud2
 29fc8f8:	ud2
 29fc8fa:	ud2
 29fc8fc:	ud2
 29fc8fe:	ud2
 29fc900:	ud2
 29fc902:	ud2
 29fc904:	ud2
 29fc906:	ud2
 29fc908:	ud2
 29fc90a:	ud2
 29fc90c:	ud2
 29fc90e:	ud2
 29fc910:	ud2
 29fc912:	ud2
 29fc914:	ud2
 29fc916:	ud2
 29fc918:	ud2
 29fc91a:	ud2
 29fc91c:	ud2
 29fc91e:	ud2
 29fc920:	ud2
 29fc922:	ud2
 29fc924:	ud2
 29fc926:	ud2
 29fc928:	ud2
 29fc92a:	ud2
 29fc92c:	ud2
 29fc92e:	ud2
 29fc930:	ud2
 29fc932:	ud2
 29fc934:	ud2
 29fc936:	ud2
 29fc938:	ud2
 29fc93a:	ud2
 29fc93c:	ud2
 29fc93e:	ud2
 29fc940:	ud2
 29fc942:	ud2
 29fc944:	ud2
 29fc946:	ud2
 29fc948:	ud2
 29fc94a:	ud2
 29fc94c:	ud2
 29fc94e:	ud2
 29fc950:	ud2
 29fc952:	ud2
 29fc954:	ud2
 29fc956:	ud2
 29fc958:	ud2
 29fc95a:	ud2
 29fc95c:	ud2
 29fc95e:	ud2
 29fc960:	ud2
 29fc962:	ud2
 29fc964:	ud2
 29fc966:	ud2
 29fc968:	ud2
 29fc96a:	ud2
 29fc96c:	ud2
 29fc96e:	ud2
 29fc970:	ud2
 29fc972:	ud2
 29fc974:	ud2
 29fc976:	ud2
 29fc978:	ud2
 29fc97a:	ud2
 29fc97c:	ud2
 29fc97e:	ud2
 29fc980:	ud2
 29fc982:	ud2
 29fc984:	ud2
 29fc986:	ud2
 29fc988:	ud2
 29fc98a:	ud2
 29fc98c:	ud2
 29fc98e:	ud2
 29fc990:	ud2
 29fc992:	ud2
 29fc994:	ud2
 29fc996:	ud2
 29fc998:	ud2
 29fc99a:	ud2
 29fc99c:	add    %al,(%rax)
 29fc99e:	add    %al,(%rax)
 29fc9a0:	(bad)
 29fc9a1:	(bad)
 29fc9a2:	(bad)
 29fc9a3:	incl   (%rax)
 29fc9a5:	add    %al,(%rax)
	...
