"""Derive a local comparison from exact raw commands, receipts and samples."""
from pathlib import Path
import hashlib,json,sys
ROOT=Path('/workspace/scriptw'); WORK=ROOT/'target/performance-dense-numbers-20261030'
sys.path.insert(0,str(ROOT/'scripts'))
from precompiled_comparison import image_metadata

def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(v):return json.dumps(v,indent=2)+'\n'
def sections(path):
    value=path.read_bytes();assert value[:8]==b'\0asm\1\0\0\0';i=8;out={}
    while i<len(value):
        tag=value[i];i+=1;n=shift=0
        while True:
            v=value[i];i+=1;n|=(v&127)<<shift;shift+=7
            if v<128:break
        assert i+n<=len(value)
        if tag:out[tag]={'bytes':n,'sha256':hashlib.sha256(value[i:i+n]).hexdigest()}
        i+=n
    return out

analysis=load(WORK/'analysis.json')
identities={label:load(WORK/label/'identity.json') for label in ('baseline','candidate')}
producers={label:{c['file']:c for c in load(WORK/(label+'-images')/'producer.json')['cases']} for label in identities}
artifacts=[];ordinary=[]
for row in analysis['workloads']:
    name=row['file']
    if row['original_17_case_fixture']:
        item={'file':name,'products':{}}
        for label in identities:
            producer=producers[label][name]
            image=WORK/(label+'-images')/producer['image']
            metadata=image_metadata(image.read_bytes(),'scriptw',identities[label]['source_fingerprint'])
            assert metadata['sha256']==producer['image_sha256'] and metadata['program_wasm_sha256']==producer['program_wasm_sha256']
            item['products'][label]={'image':metadata,'source_sha256':producer['original_source_sha256'],'derived_source_sha256':producer['derived_source_sha256'],'preparation_phases_ns':producer['phases_ns']}
        artifacts.append(item)
    records=[]
    for r,label in enumerate(analysis['order']):
        path=WORK/f'round-{r}-ordinary-wasm'/(name+'.wasm')
        case=load(WORK/f'round-{r}-{label}-ordinary-{name}.stdout')['cases'][0]
        assert sha(path)==case['wasm_sha256']
        records.append({'round':r,'product':label,'program_sha256':case['wasm_sha256'],'sections':sections(path),'linked_runtime':case['linked_runtime'],'footprint':case['footprint']})
    first=records[0]['sections']
    ordinary.append({'file':name,'all_code_sections_identical':all(r['sections'].get(10)==first.get(10) for r in records),'different_standard_sections':sorted({int(k) for r in records for k in first.keys()|r['sections'].keys() if first.get(k)!=r['sections'].get(k)}),'rounds':records})
(WORK/'artifact-metadata.json').write_text(dump(artifacts))
(WORK/'ordinary-image-comparison.json').write_text(dump(ordinary))

flags=[]
for row in analysis['workloads']:
    for boundary in ('retained','ordinary'):
        if boundary in row and all(g['change_percent']>5 for g in row[boundary]['balanced_orders']):
            flags.append({'file':row['file'],'boundary':boundary,'balanced_orders':row[boundary]['balanced_orders']})
if all(g['change_percent']>5 for g in analysis['startup']['balanced_orders']):
    flags.append({'file':'startup.js','boundary':'whole CLI','balanced_orders':analysis['startup']['balanced_orders']})
(WORK/'measurement-flags.json').write_text(dump({'threshold_percent':5,'rule':'Above5% slowdown in both balanced orders triggers confirmatory repeat; flags do not decide attribution or acceptance.','flags':flags}))
print('Artifact framing and ordinary code comparisons derived. Confirmation flags:',[(r['file'],r['boundary']) for r in flags])

import statistics
phase_rows=[]
for row in analysis['workloads']:
    name=row['file']; products={}
    for label in identities:
        ordinary_cases=[]; ordinary_obs=[]; retained=[]
        for r,product in enumerate(analysis['order']):
            if product!=label: continue
            case=load(WORK/f'round-{r}-{label}-ordinary-{name}.stdout')['cases'][0]
            ordinary_cases.append(case)
            ordinary_obs.extend(o for o in case['observations'] if not o['warmup'])
            if row['original_17_case_fixture']:
                retained.append(load(WORK/f'round-{r}-{label}-retained-{name}.stdout'))
        def med(values): return statistics.median(values) if values else None
        item={'ordinary_compilation_median_ns':{k:med([c['compilation_ns'][k] for c in ordinary_cases]) for k in ordinary_cases[0]['compilation_ns']},
              'ordinary_nonwarmup_phase_median_ns':{k:med([o['phases_ns'][k] for o in ordinary_obs]) for k in ordinary_obs[0]['phases_ns']},
              'ordinary_gc_capacity_median_bytes':{k:med([o['memory'][k] for o in ordinary_obs]) for k in ['gc_capacity_before_bytes','gc_capacity_after_bytes']},
              'ordinary_sampled_rss_median_bytes':{k:med([o['memory']['process_rss'][k] for o in ordinary_obs if o['memory']['process_rss'].get('status')=='sampled']) for k in ['initial_rss_bytes','final_rss_bytes','maximum_rss_bytes']}}
        if retained:
            item['retained_per_process_phase_median_ns']={k:med([v['phases_ns'][k] for v in retained]) for k in retained[0]['phases_ns']}
        products[label]=item
    phase_rows.append({'file':name,'products':products})
(WORK/'boundary-phases.json').write_text(dump({'scope':'Phase diagnostics only. Ordinary source compilation occurs once per process; measured invocation phases exclude ten warmups. Retained admission/setup/initialization occurs once per process outside the call timer. RSS is sampled process residency and GC capacity is not live JS bytes.','workloads':phase_rows}))
