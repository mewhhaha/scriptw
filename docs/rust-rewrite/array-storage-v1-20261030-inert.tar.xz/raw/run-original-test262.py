"""Replay original pinned join families on both frozen products; no publication."""
from pathlib import Path
import hashlib,json,re,subprocess,sys
ROOT=Path('/workspace/scriptw'); WORK=ROOT/'target/performance-dense-numbers-20261030'
SCOPES=[('array-literal','language/expressions/array'),('array-push','built-ins/Array/prototype/push'),('array-pop','built-ins/Array/prototype/pop'),('array-sort','built-ins/Array/prototype/sort'),('array-reverse','built-ins/Array/prototype/reverse'),('array-join','built-ins/Array/prototype/join'),('array-to-sorted','built-ins/Array/prototype/toSorted'),('array-length','built-ins/Array/length'),('array-copy-within','built-ins/Array/prototype/copyWithin'),('object-keys','built-ins/Object/keys'),('reflect-ownkeys','built-ins/Reflect/ownKeys')]
rows=[]
for label in sys.argv[1:]:
    cli=WORK/label/'scriptw'
    for name,scope in SCOPES:
        argv=[str(cli),'--jobs','1','test262','run',scope,'--execution-backend','wasm-aot','--suite-root','test262/vendor/test262','--snapshot-dir',str(WORK/('test262-'+label)),'--snapshot-name','dense-numbers-'+label+'-'+name,'--threads','1','--timeout-ms','60000','--reuse-case-workers']
        print('START',label,name,flush=True)
        log=WORK/('test262-'+label+'-'+name+'.log')
        with log.open('xb') as output:
            result=subprocess.run(argv,cwd=ROOT,stdout=output,stderr=subprocess.STDOUT)
        text=log.read_text(); total=re.search(r'^total: (\d+)$',text,re.M); passed=re.search(r'^passed: (\d+)$',text,re.M)
        assert total and int(total[1])>0 and passed
        row={'product':label,'scope':scope,'argv':argv,'exit_code':result.returncode,'total':int(total[1]),'passed':int(passed[1]),'raw':log.name,'executable_sha256':hashlib.sha256(cli.read_bytes()).hexdigest()}
        (WORK/('test262-'+label+'-'+name+'.receipt.json')).write_text(json.dumps(row,indent=2)+'\n')
        rows.append(row); (WORK/('test262-'+label+'-summary.json')).write_text(json.dumps({'scope':'Eleven selected original pinned families; not full-suite or publication','runs':rows},indent=2)+'\n')
        print('END',label,name,row['passed'],'/',row['total'],'exit',result.returncode,flush=True)
