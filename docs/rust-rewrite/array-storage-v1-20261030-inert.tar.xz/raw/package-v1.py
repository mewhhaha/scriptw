"""Seal the rejected v1 cohort as inert provenance, excluding native payloads."""
from pathlib import Path
import hashlib
import io
import json
import os
import tarfile

ROOT=Path('/workspace/scriptw')
BASE=Path(__file__).resolve().parent
OUT=BASE/'v1-inert.tar.xz'
assert not OUT.exists()
allowed={'.json','.jsonl','.log','.stdout','.stderr','.py','.patch','.js','.mjs','.rs','.txt','.md','.asm'}
files=[]
for current,dirs,names in os.walk(BASE,followlinks=False):
    parent=Path(current)
    dirs[:]=[name for name in dirs if name not in {'cache','v2','__pycache__'} and not (parent/name).is_symlink()]
    for name in names:
        path=parent/name
        if path.is_symlink() or not path.is_file():continue
        if path.suffix not in allowed and not name.endswith(('.build.jsonl.gz','.build.stderr.gz')):continue
        files.append(path)
index=[]
with tarfile.open(OUT,'w:xz',preset=6) as archive:
    for path in sorted(files):
        relative=path.relative_to(BASE)
        digest=hashlib.file_digest(path.open('rb'),'sha256').hexdigest()
        index.append({'path':str(relative),'bytes':path.stat().st_size,'sha256':digest})
        archive.add(path,arcname='raw/'+str(relative),recursive=False)
    data=(json.dumps({'scope':'Rejected dense-number v1, original and opposite-order confirmation, native code and construction isolation. No executable/native/wasm payloads; hashes bind provenance only.','mapping':'raw/ maps to target/performance-dense-numbers-20261030. immutable-v1-native holds transcript copies bound by v1-native-transcript-map.json. Shared confirmation inputs are the original frozen products/images; symlink directories are omitted.','members':index},indent=2)+'\n').encode()
    entry=tarfile.TarInfo('evidence-index.json');entry.size=len(data);entry.mode=0o644
    archive.addfile(entry,io.BytesIO(data))
result={'archive':OUT.name,'sha256':hashlib.file_digest(OUT.open('rb'),'sha256').hexdigest(),'bytes':OUT.stat().st_size,'members':len(index)+1,'expanded_member_bytes':sum(p['bytes'] for p in index)+len(data),'native_payloads_archived':False}
(BASE/'v1-archive.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2),flush=True)
