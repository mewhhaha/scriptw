//! Dense Number storage owns the exact prefix [0, COUNT), independently of
//! Array.length. Its shared empty presence backing is never read or mutated.
use super::*;

impl FunctionBuilder<'_> {
    /// The only transition from a dense prefix to holey Number storage. Publish
    /// the complete capacity-sized bitmap before changing the closed mode;
    /// Number bits and COUNT remain unchanged and strongly rooted throughout.
    pub(super) fn emit_number_bitmap_for_holes(
        &mut self,
        storage: &GcLocal<ArrayIndexStorage>,
        numbers: &GcLocal<NumberBitsI64Array>,
        presence: &GcLocal<NumberPresenceU64Array>,
        count: I64Local,
        f: &mut Function,
    ) {
        let s = self.runtime_schema();
        s.array_storage_mode_is(storage, ArrayIndexedStorageMode::DenseNumbers, f);
        self.open_frame(ControlFrameKind::If, f);
        let words = s.reserve_i32_local(f);
        s.array_type::<NumberBitsI64Array>().length(numbers, s, f);
        f.instruction(&Instruction::I32Const(63));
        f.instruction(&Instruction::I32Add);
        f.instruction(&Instruction::I32Const(6));
        f.instruction(&Instruction::I32ShrU);
        words.store(f);
        let next = s.reserve_gc_local(f).initialize(
            s.array_type::<NumberPresenceU64Array>()
                .filled(GcOperand::i64(0), words, f),
            f,
        );
        let complete = s.reserve_i32_local(f);
        count.load(f);
        f.instruction(&Instruction::I64Const(6));
        f.instruction(&Instruction::I64ShrU);
        f.instruction(&Instruction::I32WrapI64);
        complete.store(f);
        let word = s.reserve_i32_local(f);
        word.set_constant(0, f);
        let exit = self.open_frame(ControlFrameKind::Block, f);
        let repeat = self.open_frame(ControlFrameKind::Loop, f);
        word.load(f);
        complete.load(f);
        f.instruction(&Instruction::I32GeU);
        self.emit_branch_if_to_target(exit, f);
        s.array_type::<NumberPresenceU64Array>()
            .write(&next, word, GcOperand::i64(-1), s, f);
        word.load(f);
        f.instruction(&Instruction::I32Const(1));
        f.instruction(&Instruction::I32Add);
        word.store(f);
        self.emit_branch_to_target(repeat, f);
        self.pop_control(ControlFrameKind::Loop);
        f.instruction(&Instruction::End);
        self.pop_control(ControlFrameKind::Block);
        f.instruction(&Instruction::End);
        let remainder = s.reserve_i64_local(f);
        count.load(f);
        f.instruction(&Instruction::I64Const(63));
        f.instruction(&Instruction::I64And);
        remainder.store(f);
        remainder.load(f);
        f.instruction(&Instruction::I64Eqz);
        f.instruction(&Instruction::I32Eqz);
        self.open_frame(ControlFrameKind::If, f);
        let bits = s.reserve_i64_local(f);
        f.instruction(&Instruction::I64Const(1));
        remainder.load(f);
        f.instruction(&Instruction::I64Shl);
        f.instruction(&Instruction::I64Const(1));
        f.instruction(&Instruction::I64Sub);
        bits.store(f);
        s.array_type::<NumberPresenceU64Array>().write(
            &next,
            complete,
            GcOperand::i64_local(bits),
            s,
            f,
        );
        s.release_i64_local(bits, f);
        self.pop_control(ControlFrameKind::If);
        f.instruction(&Instruction::End);
        s.field(ArrayIndexStorageSchema::NUMBER_PRESENT).write(
            storage,
            GcOperand::reference(&next, s),
            s,
            f,
        );
        presence.replace(next.load(s, f), f);
        s.set_array_storage_mode(storage, ArrayIndexedStorageMode::PackedNumbers, f);
        next.clear(f);
        s.release_i64_local(remainder, f);
        for local in [word, complete, words] {
            s.release_i32_local(local, f);
        }
        self.pop_control(ControlFrameKind::If);
        f.instruction(&Instruction::End);
    }

    /// Cold consumers can enumerate/materialize dense and holey Number stores
    /// without allocating a bitmap merely to discover the dense prefix.
    pub(super) fn emit_numeric_presence_condition(
        &mut self,
        storage: &GcLocal<ArrayIndexStorage>,
        presence: &GcLocal<NumberPresenceU64Array>,
        slot: I32Local,
        word: I32Local,
        mask: I64Local,
        bits: I64Local,
        f: &mut Function,
    ) {
        let s = self.runtime_schema();
        let present = s.reserve_i32_local(f);
        s.array_storage_mode_is(storage, ArrayIndexedStorageMode::DenseNumbers, f);
        self.open_frame(ControlFrameKind::If, f);
        slot.load(f);
        f.instruction(&Instruction::I64ExtendI32U);
        s.field(ArrayIndexStorageSchema::COUNT).read(storage, s, f);
        f.instruction(&Instruction::I64LtU);
        present.store(f);
        f.instruction(&Instruction::Else);
        self.packed_presence(presence, slot, word, mask, bits, f);
        bits.load(f);
        mask.load(f);
        f.instruction(&Instruction::I64And);
        f.instruction(&Instruction::I64Eqz);
        f.instruction(&Instruction::I32Eqz);
        present.store(f);
        self.pop_control(ControlFrameKind::If);
        f.instruction(&Instruction::End);
        present.load(f);
        s.release_i32_local(present, f);
    }

    pub(super) fn emit_dense_number_delete(
        &mut self,
        storage: &GcLocal<ArrayIndexStorage>,
        index: I64Local,
        handled: I32Local,
        f: &mut Function,
    ) {
        let s = self.runtime_schema();
        s.array_storage_mode_is(storage, ArrayIndexedStorageMode::DenseNumbers, f);
        self.open_frame(ControlFrameKind::If, f);
        // Every missing index is a successful packed deletion, including
        // indices in stale capacity after shrink or logical length extension.
        handled.set_constant(1, f);
        let count = s.reserve_i64_local(f);
        s.field(ArrayIndexStorageSchema::COUNT)
            .read(storage, s, f)
            .store_i64(count, f);
        index.load(f);
        count.load(f);
        f.instruction(&Instruction::I64LtU);
        self.open_frame(ControlFrameKind::If, f);
        let (numbers, presence) = self.packed_backings(storage, f);
        index.load(f);
        f.instruction(&Instruction::I64Const(1));
        f.instruction(&Instruction::I64Add);
        count.load(f);
        f.instruction(&Instruction::I64Eq);
        self.open_frame(ControlFrameKind::If, f);
        // Deleting the own prefix tail preserves density even when the Array
        // has a longer logical length. Its numeric capacity may be reused.
        count.load(f);
        f.instruction(&Instruction::I64Const(1));
        f.instruction(&Instruction::I64Sub);
        count.store(f);
        s.field(ArrayIndexStorageSchema::COUNT)
            .write(storage, GcOperand::i64_local(count), s, f);
        let slot = s.reserve_i32_local(f);
        index.load(f);
        f.instruction(&Instruction::I32WrapI64);
        slot.store(f);
        s.array_type::<NumberBitsI64Array>()
            .write(&numbers, slot, GcOperand::i64(0), s, f);
        count.load(f);
        f.instruction(&Instruction::I64Eqz);
        self.open_frame(ControlFrameKind::If, f);
        self.clear_packed_backings(storage, f);
        self.pop_control(ControlFrameKind::If);
        f.instruction(&Instruction::End);
        s.release_i32_local(slot, f);
        f.instruction(&Instruction::Else);
        // The caller's existing holey deletion runs after this transition.
        self.emit_number_bitmap_for_holes(storage, &numbers, &presence, count, f);
        self.pop_control(ControlFrameKind::If);
        f.instruction(&Instruction::End);
        presence.clear(f);
        numbers.clear(f);
        self.pop_control(ControlFrameKind::If);
        f.instruction(&Instruction::End);
        s.release_i64_local(count, f);
        self.pop_control(ControlFrameKind::If);
        f.instruction(&Instruction::End);
    }
}
