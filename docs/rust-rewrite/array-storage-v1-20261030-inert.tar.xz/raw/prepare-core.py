from pathlib import Path
ROOT=Path('/workspace/scriptw')
OUT=ROOT/'target/performance-dense-numbers-20261030/core-staging'
P=ROOT/'crates/scriptw-aot-wasm/src'

def write(name,text):
 p=OUT/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)

def replace_once(t,a,b):
 assert t.count(a)==1,(a[:100],t.count(a));return t.replace(a,b)

name='objects/packed_array_index.rs'
t=(P/name).read_text()
t=t.replace('//! Packed ordinary data uses Number bits/presence or nullable immutable value','//! Packed ordinary data uses dense Number prefixes, holey Number bits/presence,\n//! or nullable immutable value')
# All primary numeric mutation/materialization admissions accept both modes.
t=t.replace('s.array_storage_mode_is(storage, ArrayIndexedStorageMode::PackedNumbers, f);','s.array_storage_is_numeric(storage, f);')
# Dense probe directly proves a valid own Number index from COUNT; bitmap arm
# retains its original separate capacity and presence proofs.
a='''        let (numbers, presence) = self.packed_backings(storage, f);
        index.load(f);
        s.array_type::<NumberBitsI64Array>().length(&numbers, s, f);
        f.instruction(&Instruction::I64ExtendI32U);
        f.instruction(&Instruction::I64LtU);
        self.open_frame(ControlFrameKind::If, f);
        let slot = s.reserve_i32_local(f);'''
b='''        let (numbers, presence) = self.packed_backings(storage, f);
        s.array_storage_mode_is(storage, ArrayIndexedStorageMode::DenseNumbers, f);
        self.open_frame(ControlFrameKind::If, f);
        index.load(f);
        s.field(ArrayIndexStorageSchema::COUNT).read(storage, s, f);
        f.instruction(&Instruction::I64LtU);
        self.open_frame(ControlFrameKind::If, f);
        if let Some(output) = output {
            let slot = s.reserve_i32_local(f);
            let bits = s.reserve_i64_local(f);
            index.load(f);
            f.instruction(&Instruction::I32WrapI64);
            slot.store(f);
            s.array_type::<NumberBitsI64Array>()
                .read(&numbers, slot, s, f)
                .store_i64(bits, f);
            output.set_number(bits, f);
            s.release_i64_local(bits, f);
            s.release_i32_local(slot, f);
        }
        found.set_constant(1, f);
        self.pop_control(ControlFrameKind::If);
        f.instruction(&Instruction::End);
        f.instruction(&Instruction::Else);
        index.load(f);
        s.array_type::<NumberBitsI64Array>().length(&numbers, s, f);
        f.instruction(&Instruction::I64ExtendI32U);
        f.instruction(&Instruction::I64LtU);
        self.open_frame(ControlFrameKind::If, f);
        let slot = s.reserve_i32_local(f);'''
start=t.index('    fn emit_packed_number_probe(');end=t.index('    /// Private publication primitive:',start)
probe=t[start:end];probe=replace_once(probe,a,b)
probe=replace_once(probe,'''        presence.clear(f);
        numbers.clear(f);''','''        self.pop_control(ControlFrameKind::If);
        f.instruction(&Instruction::End);
        presence.clear(f);
        numbers.clear(f);''')
t=t[:start]+probe+t[end:]
# Keep the original growth policy as sole admission owner.
start=t.index('    fn packed_number_only_write(');end=t.index('    /// All descriptor consumers',start)
mutation=t[start:end]
a='''        // Existing capacity may retain holes; new capacity is occupancy driven
        // and bounded independently of Array.length and distant index values.
        index.load(f);
        capacity.load(f);
        f.instruction(&Instruction::I64ExtendI32U);
        f.instruction(&Instruction::I64LtU);
        index.load(f);
        f.instruction(&Instruction::I64Const(PACKED_INDEX_LIMIT));
        f.instruction(&Instruction::I64LtU);
        index.load(f);
        count.load(f);
        f.instruction(&Instruction::I64Const(2));
        f.instruction(&Instruction::I64Mul);
        f.instruction(&Instruction::I64Const(8));
        f.instruction(&Instruction::I64Add);
        f.instruction(&Instruction::I64LeU);
        f.instruction(&Instruction::I32And);
        f.instruction(&Instruction::I32Or);
        self.open_frame(ControlFrameKind::If, f);'''
b='''        // No mode or backing mutation occurs until the unchanged bounded
        // capacity/occupancy policy has admitted this exact publication.
        self.emit_packed_capacity_admission(index, capacity, count, f);
        self.open_frame(ControlFrameKind::If, f);
        index.load(f);
        count.load(f);
        f.instruction(&Instruction::I64GtU);
        self.open_frame(ControlFrameKind::If, f);
        self.emit_number_bitmap_for_holes(storage, &numbers, &presence, count, f);
        self.pop_control(ControlFrameKind::If);
        f.instruction(&Instruction::End);'''
mutation=replace_once(mutation,a,b)
# Allocate/copy the private bitmap during growth only in the holey mode.
a='''        let words = s.reserve_i32_local(f);
        grown.load(f);'''
b='''        s.array_storage_mode_is(storage, ArrayIndexedStorageMode::PackedNumbers, f);
        self.open_frame(ControlFrameKind::If, f);
        let words = s.reserve_i32_local(f);
        grown.load(f);'''
mutation=replace_once(mutation,a,b)
a='''        // Both complete allocations exist before publication. All old/new
        // backing references remain strong roots across the second allocation.
        s.field(ArrayIndexStorageSchema::NUMBERS).write(
            storage,
            GcOperand::reference(&new_numbers, s),
            s,
            f,
        );
        s.field(ArrayIndexStorageSchema::NUMBER_PRESENT).write('''
b='''        // The new Number backing remains rooted across this second allocation.
        // No allocation/user code occurs between the publication writes.
        s.field(ArrayIndexStorageSchema::NUMBER_PRESENT).write('''
mutation=replace_once(mutation,a,b)
a='''        numbers.replace(new_numbers.load(s, f), f);
        presence.replace(new_presence.load(s, f), f);
        new_presence.clear(f);
        new_numbers.clear(f);
        s.release_i32_local(words, f);
        s.release_i32_local(grown, f);'''
b='''        presence.replace(new_presence.load(s, f), f);
        new_presence.clear(f);
        s.release_i32_local(words, f);
        self.pop_control(ControlFrameKind::If);
        f.instruction(&Instruction::End);
        s.field(ArrayIndexStorageSchema::NUMBERS).write(
            storage,
            GcOperand::reference(&new_numbers, s),
            s,
            f,
        );
        numbers.replace(new_numbers.load(s, f), f);
        new_numbers.clear(f);
        s.release_i32_local(grown, f);'''
mutation=replace_once(mutation,a,b)
# Common numeric payload write; occupancy updates split by validated mode.
a='''        let word = s.reserve_i32_local(f);
        let mask = s.reserve_i64_local(f);
        let bits = s.reserve_i64_local(f);
        self.packed_presence(&presence, slot, word, mask, bits, f);'''
b='''        s.array_storage_mode_is(storage, ArrayIndexedStorageMode::DenseNumbers, f);
        self.open_frame(ControlFrameKind::If, f);
        index.load(f);
        count.load(f);
        f.instruction(&Instruction::I64Eq);
        self.open_frame(ControlFrameKind::If, f);
        count.load(f);
        f.instruction(&Instruction::I64Const(1));
        f.instruction(&Instruction::I64Add);
        count.store(f);
        s.field(ArrayIndexStorageSchema::COUNT)
            .write(storage, GcOperand::i64_local(count), s, f);
        self.pop_control(ControlFrameKind::If);
        f.instruction(&Instruction::End);
        f.instruction(&Instruction::Else);
        let word = s.reserve_i32_local(f);
        let mask = s.reserve_i64_local(f);
        let bits = s.reserve_i64_local(f);
        self.packed_presence(&presence, slot, word, mask, bits, f);'''
mutation=replace_once(mutation,a,b)
a='''        s.array_type::<NumberBitsI64Array>().write(
            &numbers,
            slot,
            GcOperand::i64_local(value.scalar()),
            s,
            f,
        );
'''
mutation=replace_once(mutation,a,'')
a='''        handled.set_constant(1, f);
        s.release_i64_local(bits, f);
        s.release_i64_local(mask, f);
        s.release_i32_local(word, f);
        s.release_i32_local(slot, f);'''
b='''        s.release_i64_local(bits, f);
        s.release_i64_local(mask, f);
        s.release_i32_local(word, f);
        self.pop_control(ControlFrameKind::If);
        f.instruction(&Instruction::End);
        s.array_type::<NumberBitsI64Array>().write(
            &numbers,
            slot,
            GcOperand::i64_local(value.scalar()),
            s,
            f,
        );
        handled.set_constant(1, f);
        s.release_i32_local(slot, f);'''
mutation=replace_once(mutation,a,b)
t=t[:start]+mutation+t[end:]
# Cold consumers test the representation invariant without allocating a bitmap.
a='''        self.packed_presence(&presence, slot, word, mask, bits, f);
        bits.load(f);
        mask.load(f);
        f.instruction(&Instruction::I64And);
        f.instruction(&Instruction::I64Eqz);
        f.instruction(&Instruction::I32Eqz);
        self.open_frame(ControlFrameKind::If, f);'''
b='''        self.emit_numeric_presence_condition(storage, &presence, slot, word, mask, bits, f);
        self.open_frame(ControlFrameKind::If, f);'''
for fn,endmarker in [('    fn emit_materialize_packed_numbers(', '    fn clear_packed_backings('),('    fn emit_packed_number_keys(', '\n}\n\nmod values;')]:
 start=t.index(fn);end=t.index(endmarker,start);piece=t[start:end];piece=replace_once(piece,a,b);t=t[:start]+piece+t[end:]
# Dense deletion runs first. An interior deletion transitions and falls through
# to the unchanged bitmap algorithm; other dense deletions are already complete.
start=t.index('    fn emit_packed_number_delete(');end=t.index('    fn emit_packed_number_keys(',start)
piece=t[start:end]
piece=replace_once(piece,'''        let handled = s.reserve_i32_local(f);
        s.array_storage_is_numeric(storage, f);
        handled.store(f);
        handled.load(f);
        self.open_frame(ControlFrameKind::If, f);''','''        let handled = s.reserve_i32_local(f);
        handled.set_constant(0, f);
        self.emit_dense_number_delete(storage, index, handled, f);
        s.array_storage_mode_is(storage, ArrayIndexedStorageMode::PackedNumbers, f);
        self.open_frame(ControlFrameKind::If, f);
        handled.set_constant(1, f);''')
piece=replace_once(piece,'''        self.clear_packed_backings(storage, f);''','''        self.clear_packed_backings(storage, f);
        s.set_array_storage_mode(storage, ArrayIndexedStorageMode::DenseNumbers, f);''')
t=t[:start]+piece+t[end:]
t=t.replace('\nmod values;','\nmod dense_numbers;\nmod values;')
write(name,t)
write('objects/packed_array_index/dense_numbers.rs',(ROOT/'target/performance-dense-numbers-20261030/dense_numbers.rs').read_text())
name='objects/packed_array_index/values.rs';t=(P/name).read_text();t=t.replace('s.array_storage_mode_is(storage, ArrayIndexedStorageMode::PackedNumbers, f);','s.array_storage_is_numeric(storage, f);');t=t.replace('s.set_array_storage_mode(storage, ArrayIndexedStorageMode::PackedNumbers, f);','s.set_array_storage_mode(storage, ArrayIndexedStorageMode::DenseNumbers, f);');write(name,t)
name='objects/packed_array_builtin/numeric_sort.rs';t=(P/name).read_text().replace('s.array_storage_mode_is(&packed.storage, ArrayIndexedStorageMode::PackedNumbers, f);','s.array_storage_is_numeric(&packed.storage, f);');write(name,t)
name='builtins/array/literal/numeric.rs';t=(P/name).read_text().replace('use crate::gc_types::{ArrayIndexStorageSchema, NumberBitsI64Array, NumberPresenceU64Array};','use crate::gc_types::{ArrayIndexStorageSchema, NumberBitsI64Array};')
a='''        let presence = s.reserve_gc_local(f).initialize(
            s.array_type::<NumberPresenceU64Array>()
                .fixed([GcOperand::i64((1_i64 << source.length()) - 1)], f),
            f,
        );
''';t=replace_once(t,a,'')
a='''        // FreshArrayLiteral alone owns this initially empty PackedNumbers
        // store. Both complete backings are rooted before any field changes;
        // these writes allocate nothing and cannot expose partial state.''';b='''        // FreshArrayLiteral alone owns this initially empty DenseNumbers
        // store. Its shared empty presence array remains unchanged: COUNT
        // denotes the exact prefix. These writes allocate nothing.''';t=replace_once(t,a,b)
a='''        s.field(ArrayIndexStorageSchema::NUMBER_PRESENT).write(
            &storage,
            GcOperand::reference(&presence, s),
            s,
            f,
        );
''';t=replace_once(t,a,'');t=replace_once(t,'        presence.clear(f);\n','');write(name,t)
