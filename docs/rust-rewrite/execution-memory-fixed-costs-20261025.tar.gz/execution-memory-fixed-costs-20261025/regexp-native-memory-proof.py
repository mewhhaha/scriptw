#!/usr/bin/env python3
"""Cold-cache child-only RSS proof for one actual final native RegExp test.

Never builds, retries, changes test sources, or contributes scored workloads.
Run after the complete 31-target native inventory, through outer run_check.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import sys
import time

from campaign_identity import (BASE, candidate_source, digest, environment_receipt,
                               frozen_product, ordinary_environment, read, require,
                               validate_environment)
from analyze import resources

REPO = BASE.parent.parent
LABEL = 'regexp-native-memory-proof'
OUTPUT = BASE / (LABEL + '-data')
ANALYSIS = BASE / (LABEL + '-analysis.json')
DRIVER = Path(__file__).resolve()
CASE = 'aot_regexp_iv_class_strings::property_and_direct_strings_fold_circled_m_before_algebra'
TEST_SOURCE = REPO / 'crates/scriptw-engine/tests/aot_regexp/aot_regexp_iv_class_strings.rs'
INVENTORY = BASE / 'broad-25-scriptw-engine-aot_regexp-inventory.json'
DEFAULT_TIME = REPO / 'target/memory-execution-20261025/tool-bin/gtime'
TIME_FORMAT = ('scriptw-gnu-time-v1\nelapsed_seconds=%e\nuser_cpu_seconds=%U\n'
               'system_cpu_seconds=%S\nmaximum_rss_kib=%M\nexit_status=%x')
EMPTY = hashlib.sha256(b'').hexdigest()
LIMIT = 4 * 1024**3
sys.path.insert(0, str(REPO / 'scripts'))
from limited_verification import require_kernel_budget


def stamp():
    return datetime.now(timezone.utc).isoformat()


def native_authority():
    """Bind this child to the complete final native inventory's actual ELF."""
    closed_path = BASE / 'native-closed.json'
    closed, scopes = read(closed_path), read(BASE / 'native-scopes.json')
    source = candidate_source()
    require(closed.get('complete') is True and closed.get('source') == source
            and len(closed['targets']) == len(scopes) == 31
            and closed['total'] == sum(len(row['inventory']) for row in closed['targets']),
            'all 31 final native target inventories must close before this diagnostic')
    for row, scope in zip(closed['targets'], scopes):
        require(all(row.get(key) == value for key, value in scope.items())
                and row['exit_code'] == 0 and row['source_head'] == source
                and row['source_patch_sha256'] == EMPTY, 'closed native target/source differs')
    rows = [row for row in closed['targets'] if row['package'] == 'scriptw-engine'
            and row['kind'] == '--test' and row['name'] == 'aot_regexp']
    require(len(rows) == 1, 'one closed aot_regexp target required')
    row = rows[0]
    inventory = read(INVENTORY)
    log = BASE / inventory['log']
    require(inventory['label'] == 'broad-25-scriptw-engine-aot_regexp-inventory'
            and inventory['source_head'] == source and inventory['source_patch_sha256'] == EMPTY
            and inventory['exit_code'] == 0 and digest(log) == inventory['log_sha256'],
            'actual final native inventory receipt/log changed')
    names = sorted(re.findall(r'^([^\s]+): test$', log.read_text(), re.M))
    require(len(names) == len(set(names)) == 152 and names.count(CASE) == 1
            and row['inventory'] == names
            and row['inventory_sha256'] == hashlib.sha256(('\n'.join(names) + '\n').encode()).hexdigest(),
            'actual 152-case native inventory changed')
    broad = BASE / (row['label'] + '.json')
    broad_receipt = read(broad)
    require(broad_receipt['executables'] == inventory['executables'] == row['executables']
            and broad_receipt['test_results'] == [['ok', '152', '0', '0', '0', '0']]
            and digest(BASE / broad_receipt['log']) == broad_receipt['log_sha256'],
            'closed native execution/ELF authority differs')
    require(len(inventory['executables']) == 1, 'one actual aot_regexp test ELF required')
    executable = inventory['executables'][0]
    binary = Path(executable['path'])
    require(binary.is_file() and not binary.is_symlink() and binary.name.startswith('aot_regexp-')
            and binary.stat().st_size == executable['bytes'] and digest(binary) == executable['sha256'],
            'actual final native ELF bytes changed')
    identity, products = frozen_product('candidate')
    require(identity['source_revision'] == {'kind': 'git-commit', 'commit': source},
            'actual frozen compiler identity differs from the native source')
    return dict(source_commit=source, compiler_identity=identity, frozen_product_sha256=products,
                native_closed_sha256=digest(closed_path), native_target_count=31,
                native_inventory_receipt_sha256=digest(INVENTORY), inventory_log_sha256=digest(log),
                native_target_receipt_sha256=digest(broad), executable=executable)


def test_source_identity():
    text = TEST_SOURCE.read_text()
    name = CASE.split('::')[1]
    found = re.findall(r'^fn ' + re.escape(name) + r'\(\) \{(.*?)^\}', text, re.M | re.S)
    require(len(found) == 1 and found[0].count('.test(') == 10
            and 'for directive in ["", "\\\"use strict\\\";\\n"]' in text
            and 'backend: ExecutionBackend::WasmAot' in text,
            'original ten-pattern sloppy/strict Wasm test source changed')
    return dict(path=str(TEST_SOURCE.relative_to(REPO)), sha256=digest(TEST_SOURCE),
                native_case=CASE, regex_test_expressions=10, javascript_modes=['sloppy', 'strict'])


def parse_result(text):
    cases = re.findall(r'^test (.+) \.\.\. (ok|FAILED|ignored)$', text, re.M)
    results = re.findall(r'^test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; '
                         r'(\d+) measured; (\d+) filtered out; finished in ([0-9.]+)s$', text, re.M)
    require(cases == [(CASE, 'ok')] and len(results) == 1
            and results[0][:6] == ('ok', '1', '0', '0', '0', '151'),
            'actual exact-case result must be 1 pass, 151 filtered, no other outcomes')
    return dict(passed=1, failed=0, ignored=0, measured=0, filtered=151,
                libtest_elapsed_seconds=float(results[0][6]))


def parse_accounting(raw):
    lines = raw.splitlines()
    require(lines and lines[0] == 'scriptw-gnu-time-v1', 'GNU time accounting header differs')
    pairs = [line.split('=', 1) for line in lines[1:]]
    require(all(len(pair) == 2 for pair in pairs) and len(pairs) == 5
            and len({pair[0] for pair in pairs}) == 5, 'GNU time accounting framing differs')
    fields = dict(pairs)
    require(set(fields) == {'elapsed_seconds', 'user_cpu_seconds', 'system_cpu_seconds',
                            'maximum_rss_kib', 'exit_status'}
            and fields['exit_status'] == '0' and fields['maximum_rss_kib'].isdecimal(),
            'GNU time exit or RSS counter differs')
    for key in ('elapsed_seconds', 'user_cpu_seconds', 'system_cpu_seconds'):
        require(re.fullmatch(r'[0-9]+(?:\.[0-9]+)?', fields[key]) is not None,
                'GNU time duration is malformed')
    peak = int(fields['maximum_rss_kib']) * 1024
    require(0 < peak <= LIMIT, 'actual child RSS is absent or exceeds its kernel budget')
    return dict(child_peak_rss_kib=int(fields['maximum_rss_kib']), child_peak_rss_bytes=peak,
                elapsed_seconds=float(fields['elapsed_seconds']),
                user_cpu_seconds=float(fields['user_cpu_seconds']),
                system_cpu_seconds=float(fields['system_cpu_seconds']), exit_status=0,
                memory_scope='GNU-time %M maximum RSS of the actual native test child; '
                             'includes its compiler/Wasmtime/JS work; excludes Cargo, rustc/LLVM, Python launcher and earlier pipeline work')


def budget_snapshot():
    for line in Path('/proc/self/cgroup').read_text().splitlines():
        if line.startswith('0::'):
            directory = Path('/sys/fs/cgroup') / line[3:].lstrip('/')
            return {name: (directory / name).read_text().strip()
                    for name in ('memory.max', 'memory.swap.max', 'memory.oom.group')}
    raise ValueError('unified kernel cgroup budget is required')


def run(time_binary):
    require_kernel_budget(LIMIT)
    require(sorted(os.sched_getaffinity(0)) == [0], 'one inherited CPU0 required')
    authority, source = native_authority(), test_source_identity()
    actual_time = Path(time_binary).resolve(strict=True)
    require(actual_time.is_file(), 'actual GNU time binary required')
    OUTPUT.mkdir(exist_ok=False)
    cache = OUTPUT / 'cold-execution-cache'
    cache.mkdir(exist_ok=False)
    require(list(cache.iterdir()) == [], 'native diagnostic cache must start empty')
    shutil.copyfile(TEST_SOURCE, OUTPUT / 'test-source.rs')
    environment = ordinary_environment()
    environment['SCRIPTW_CACHE_DIR'] = str(cache)
    environment['LC_ALL'] = 'C'
    dependencies = [BASE / 'campaign_identity.py', BASE / 'analyze.py', REPO / 'scripts/limited_verification.py']
    report = dict(schema='scriptw-regexp-native-memory-proof-v1', complete=False, label=LABEL,
                  excluded_from_scored_cohorts=True, authority=authority, test_source=source,
                  driver_sha256=digest(DRIVER),
                  dependencies={str(path.relative_to(REPO)): digest(path) for path in dependencies},
                  affinity=sorted(os.sched_getaffinity(0)), environment=environment_receipt(environment),
                  cache_directory=str(cache), cache_initial_entries=[], cache_created_new=True,
                  cache_scope='New empty Scriptw disk cache in a fresh native process; OS page cache is not flushed.',
                  accounting_locale='C', additional_native_cases_counted=0,
                  requested_time_binary=str(time_binary), time_binary=dict(path=str(actual_time), sha256=digest(actual_time)),
                  budget=budget_snapshot(), started_at=stamp(), loadavg_start=list(os.getloadavg()),
                  scope='Separate single native-test process after all31 final native targets. Fresh empty Scriptw disk cache; '
                        'no Cargo/build process inside the GNU time interval. Kernel cgroup lifetime peak may include earlier '
                        'compiles and is not this child-only RSS counter. No contribution to either17-case scored cohort.')

    def save():
        pending = OUTPUT / 'report.pending'
        pending.write_text(json.dumps(report, indent=2) + '\n')
        pending.replace(OUTPUT / 'report.json')

    save()
    try:
        with (OUTPUT / 'time-version.stdout').open('xb') as out, (OUTPUT / 'time-version.stderr').open('xb') as err:
            version = subprocess.run([str(actual_time), '--version'], cwd=REPO, env=environment,
                                     stdout=out, stderr=err, timeout=10)
        version_text = (OUTPUT / 'time-version.stdout').read_text()
        report['time_version'] = dict(command=[str(actual_time), '--version'], exit_code=version.returncode,
                                    stdout_sha256=digest(OUTPUT / 'time-version.stdout'),
                                    stderr_sha256=digest(OUTPUT / 'time-version.stderr'), text=version_text)
        save()
        require(version.returncode == 0 and re.search(r'\(GNU Time\) 1\.9(?:\s|$)', version_text),
                'actual accounting binary must identify GNU Time1.9')
        child_command = [authority['executable']['path'], CASE, '--exact', '--test-threads=1', '--include-ignored']
        command = [str(actual_time), '-q', '-f', TIME_FORMAT, '-o', str(OUTPUT / 'gtime.txt'), '--', *child_command]
        report.update(command=command, child_command=child_command, child_started_at=stamp())
        save()
        started = time.monotonic()
        with (OUTPUT / 'child.stdout').open('xb') as out, (OUTPUT / 'child.stderr').open('xb') as err:
            child = subprocess.Popen(command, cwd=REPO, env=environment, stdout=out, stderr=err,
                                     start_new_session=True)
            try:
                child.wait(timeout=180)
                report.update(exit_code=child.returncode, timed_out=False)
            except BaseException as error:
                # GNU time supervises a native child; killing only the wrapper
                # would leave that process running after a timeout/interruption.
                try:
                    os.killpg(child.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                child.wait()
                if isinstance(error, subprocess.TimeoutExpired):
                    report.update(exit_code=child.returncode, timed_out=True)
                else:
                    raise
        report.update(child_finished_at=stamp(), elapsed_seconds=time.monotonic() - started,
                      stdout_sha256=digest(OUTPUT / 'child.stdout'), stderr_sha256=digest(OUTPUT / 'child.stderr'))
        save()
        require(report['exit_code'] == 0 and not report['timed_out'], 'actual native test child failed')
        report['result'] = parse_result((OUTPUT / 'child.stdout').read_text())
        report['accounting'] = parse_accounting((OUTPUT / 'gtime.txt').read_text())
        report['gtime_sha256'] = digest(OUTPUT / 'gtime.txt')
        require(native_authority() == authority and test_source_identity() == source
                and digest(actual_time) == report['time_binary']['sha256']
                and budget_snapshot() == report['budget'], 'actual ELF/source/accounting tool/budget changed during child')
        report.update(complete=True, finished_at=stamp(), loadavg_end=list(os.getloadavg()))
    except BaseException as error:
        report['failure'] = str(error)
        raise
    finally:
        save()


def build_report():
    """Read-only rederivation; never starts a native executable or test."""
    path = OUTPUT / 'report.json'
    report = read(path)
    require(report.get('schema') == 'scriptw-regexp-native-memory-proof-v1' and report.get('complete') is True
            and report.get('label') == LABEL and report.get('excluded_from_scored_cohorts') is True,
            'missing/partial/mislabelled native RegExp memory proof')
    authority = native_authority()
    require(report['authority'] == authority and report['test_source'] == test_source_identity()
            and digest(OUTPUT / 'test-source.rs') == report['test_source']['sha256']
            and report['driver_sha256'] == digest(DRIVER), 'actual native proof authority/source/driver differs')
    dependencies = [BASE / 'campaign_identity.py', BASE / 'analyze.py', REPO / 'scripts/limited_verification.py']
    require(report['dependencies'] == {str(item.relative_to(REPO)): digest(item) for item in dependencies},
            'native diagnostic admission dependencies changed')
    validate_environment(report['environment'])
    require(report['affinity'] == [0] and report['budget'] == {'memory.max': str(LIMIT), 'memory.swap.max': '0',
                                                             'memory.oom.group': '1'}
            and report['cache_directory'] == str(OUTPUT / 'cold-execution-cache')
            and report['cache_created_new'] is True and report['cache_initial_entries'] == []
            and report['accounting_locale'] == 'C' and report['additional_native_cases_counted'] == 0,
            'actual serial/cold-cache/kernel budget plan differs')
    accounting_binary = Path(report['time_binary']['path'])
    require(accounting_binary.is_file() and not accounting_binary.is_symlink()
            and digest(accounting_binary) == report['time_binary']['sha256'], 'actual GNU time binary changed')
    version = report['time_version']
    require(version['command'] == [str(accounting_binary), '--version'] and version['exit_code'] == 0
            and digest(OUTPUT / 'time-version.stdout') == version['stdout_sha256']
            and digest(OUTPUT / 'time-version.stderr') == version['stderr_sha256']
            and (OUTPUT / 'time-version.stdout').read_text() == version['text']
            and re.search(r'\(GNU Time\) 1\.9(?:\s|$)', version['text']), 'actual GNU time version proof differs')
    child = [authority['executable']['path'], CASE, '--exact', '--test-threads=1', '--include-ignored']
    require(report['child_command'] == child and report['command'] ==
            [str(accounting_binary), '-q', '-f', TIME_FORMAT, '-o', str(OUTPUT / 'gtime.txt'), '--', *child]
            and report['exit_code'] == 0 and report['timed_out'] is False, 'actual GNU time/exact native command differs')
    require(digest(OUTPUT / 'child.stdout') == report['stdout_sha256']
            and digest(OUTPUT / 'child.stderr') == report['stderr_sha256']
            and digest(OUTPUT / 'gtime.txt') == report['gtime_sha256'], 'raw native accounting/streams changed')
    result = parse_result((OUTPUT / 'child.stdout').read_text())
    accounting = parse_accounting((OUTPUT / 'gtime.txt').read_text())
    require(result == report['result'] and accounting == report['accounting'], 'derived native result/accounting differs')
    receipt_path = BASE / (LABEL + '.json')
    receipt = read(receipt_path)
    resources(receipt, LABEL)
    command = receipt['command']
    arguments = command[1:]
    if arguments[:1] == ['-B']:
        arguments = arguments[1:]
    require(len(arguments) in (2, 4) and arguments[0] in (str(DRIVER), str(DRIVER.relative_to(REPO)))
            and arguments[1] == '--run'
            and (len(arguments) == 2 or arguments[2:] == ['--time-binary', report['requested_time_binary']])
            and Path(shutil.which(command[0]) or command[0]).resolve() == Path(sys.executable).resolve()
            and receipt['source_head'] == authority['source_commit'] and receipt['source_patch_sha256'] == EMPTY
            and receipt['label'] == LABEL, 'outer native-proof driver/source receipt differs')
    times = [report[key] for key in ('started_at', 'child_started_at', 'child_finished_at', 'finished_at')]
    moments = [datetime.fromisoformat(value) for value in [*times, receipt['date']]]
    require(all(value.utcoffset() is not None for value in moments) and moments == sorted(moments),
            'actual native diagnostic timestamps differ')
    return dict(schema='scriptw-regexp-native-memory-analysis-v1', complete=True, excluded_from_scored_cohorts=True,
                source_commit=authority['source_commit'], compiler_identity=authority['compiler_identity'],
                native_test_executable=authority['executable'], case=CASE, test_source=report['test_source'],
                cold_cache=True, cache_scope=report['cache_scope'], additional_native_cases_counted=0,
                native_target_count=31, result=result, accounting=accounting,
                report_sha256=digest(path), receipt_sha256=digest(receipt_path), scope=report['scope'],
                note='This actual test child compiles and executes ten regexp test expressions in both sloppy and strict JavaScript. '
                     'GNU time measures its complete process high-water RSS, not live JS heap or isolated guest execution. '
                     'The earlier compile-inclusive cgroup peak remains separate; this proof does not replace native totals.')


def evidence_files():
    report = read(OUTPUT / 'report.json')
    receipt = read(BASE / (LABEL + '.json'))
    inventory = read(INVENTORY)
    broad = read(BASE / 'broad-25-scriptw-engine-aot_regexp.json')
    paths = {DRIVER, BASE / 'campaign_identity.py', BASE / 'analyze.py', BASE / 'campaign.json',
             BASE / 'candidate/identity.json', BASE / 'frozen-products.json', BASE / 'native-closed.json',
             BASE / 'native-scopes.json', INVENTORY, BASE / inventory['log'],
             BASE / 'broad-25-scriptw-engine-aot_regexp.json', BASE / broad['log'], TEST_SOURCE,
             REPO / 'scripts/limited_verification.py', BASE / (LABEL + '.json'), BASE / receipt['log']}
    paths.update(OUTPUT / name for name in ('report.json', 'test-source.rs', 'time-version.stdout',
                                          'time-version.stderr', 'child.stdout', 'child.stderr', 'gtime.txt'))
    require(all(item.is_file() and not item.is_symlink() for item in paths), 'native memory proof evidence missing/symlinked')
    return sorted(paths)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', action='store_true')
    parser.add_argument('--check', action='store_true')
    parser.add_argument('--time-binary', type=Path, default=DEFAULT_TIME)
    args = parser.parse_args()
    require(not (args.run and args.check), 'choose native recording or pure checking')
    if args.run:
        run(args.time_binary)
    else:
        result = build_report()
        if args.check:
            require(read(ANALYSIS) == result, 'saved native memory proof differs from raw rederivation')
        else:
            with ANALYSIS.open('x') as stream:
                stream.write(json.dumps(result, indent=2) + '\n')
        print(json.dumps(dict(complete=True, analysis=str(ANALYSIS), checked=args.check,
                              child_peak_rss_bytes=result['accounting']['child_peak_rss_bytes'])))


if __name__ == '__main__':
    try:
        main()
    except (KeyError, ValueError, OSError, TypeError, subprocess.SubprocessError) as error:
        raise SystemExit('RegExp native memory proof refused: ' + str(error))
