"""Focused semantic/admission regressions, overlapping the broad inventory."""
import json
import pathlib
import subprocess
import sys

root = pathlib.Path(__file__).resolve().parent
checks = [
    ('focused-regexp-program-data', 'scriptw-aot-wasm', ['--lib'], 'large_static_regexp_programs_keep_literal_and_constructor_bodies_bounded'),
    ('focused-regexp-r-prefix', 'scriptw-aot-wasm', ['--lib'], 'regexp_literals_and_static_constructors_copy_an_r_descriptor_once_into_p'),
    ('focused-regexp-oom-case', 'scriptw-engine', ['--test', 'aot_regexp'], 'aot_regexp_iv_class_strings::property_and_direct_strings_fold_circled_m_before_algebra'),
    ('focused-regexp-corruption-boundary', 'scriptw-engine', ['--lib'], 'regexp_program_boundary_tests::'),
    ('focused-runtime-admission', 'scriptw-aot-wasm', ['--lib'], 'runtime_artifact::'),
    ('focused-string-descriptors', 'scriptw-aot-wasm', ['--lib'], 'data::runtime_string_descriptors::tests'),
    ('focused-string-bootstrap', 'scriptw-aot-wasm', ['--test', 'runtime_link'], 'pooled_string_data'),
    ('focused-lazy-intl', 'scriptw-engine', ['--lib'], 'intl_data_images::deferred::tests'),
    ('focused-native-backing', 'scriptw-engine', ['--lib'], 'embedded_runtime::native_backing::tests'),
    ('focused-native-admission', 'scriptw-engine', ['--lib'], 'embedded_runtime::tests'),
    ('focused-intl-compilation', 'scriptw-intl', ['--lib'], 'compilation_data::tests'),
]
selected_checks = checks[:4] if '--regexp-only' in sys.argv[1:] else checks
for label, package, target, pattern in selected_checks:
    command = ['cargo', 'test', '--locked', '--offline', '--release', '--jobs', '1', '-p', package, *target, pattern, '--', '--test-threads=1', '--include-ignored']
    receipt_path = root / (label + '.json')
    if receipt_path.exists():
        import hashlib
        previous = json.loads(receipt_path.read_text())
        source = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
        if previous['source_head'] != source or previous['command'] != command or previous['exit_code'] != 0 or previous['log_sha256'] != hashlib.sha256((root / previous['log']).read_bytes()).hexdigest():
            raise RuntimeError('incompatible existing focused observation: ' + label)
        continue
    code = subprocess.call([sys.executable, '-B', str(root / 'run_check.py'), label, *command])
    if code:
        sys.exit(code)
    receipt = json.loads((root / (label + '.json')).read_text())
    if not receipt['test_results'] or sum(int(row[1]) for row in receipt['test_results']) == 0:
        raise RuntimeError('focused regression filter executed no tests: ' + label)
