#!/usr/bin/env python3
"""Validate closed native, selected Test262 and balanced runtime evidence.

Default mode reads only. --publish writes one new documentation checkpoint.
No product, test or compiler executable is invoked by this tool.
"""
from __future__ import annotations

import argparse
import ast
import gzip
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import re
import subprocess
import sys
sys.dont_write_bytecode = True
import tarfile
import types
from collections import Counter
from datetime import datetime, timezone
from statistics import median

BASE = Path(__file__).resolve().parent
REPO = BASE.parent.parent
sys.path.insert(0, str(BASE))
from campaign_identity import candidate_source, product_directory, HISTORY, ALLOCATION_HELPER
BASELINE_SOURCE = "9b7746531c4b3bff0ecbb863d7d70dfead12455b"
BASELINE_PATCH = hashlib.sha256(b"").hexdigest()
EMPTY_PATCH = hashlib.sha256(b"").hexdigest()
STEM = "execution-memory-fixed-costs-20261025"
PREFIX = STEM + "/"
BUDGET = 4 * 1024**3
REGEXP_STAGE = REPO / 'target/memory-fixed-costs-final-20261025'
REGEXP_STAGE_SOURCE = '3914e89fd5f601c98f19a2b03d783e38afcd673d'
SUMMARY_RE = re.compile(r"test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out")
KNOWN = {
    "sloppy-script:annexB/language/function-code/block-decl-func-skip-arguments.js",
    "sloppy-script:intl402/Temporal/ZonedDateTime/links.js",
    "strict-script:intl402/Temporal/ZonedDateTime/links.js",
    "sloppy-script:staging/sm/lexical-environment/block-scoped-functions-annex-b-label.js",
}
ROUNDS = ["baseline-round-a-data", "candidate-round-b-data", "candidate-round-c-data", "baseline-round-d-data"]
CALL_ROUNDS = ["baseline-calls-round-a-data", "candidate-calls-round-b-data", "candidate-calls-round-c-data", "baseline-calls-round-d-data"]
EXPECTED_SCOPES = [
    ("scriptw-aot-wasm", "--lib", None),
    *[("scriptw-aot-wasm", "--test", name) for name in ["emission", "modules_realms", "runtime_link", "structure_async", "structure_builtins", "structure_language"]],
    ("scriptw-engine", "--lib", None),
    *[("scriptw-engine", "--test", name) for name in ["aot_async", "aot_async_generator_returns", "aot_builtins", "aot_gc_entries", "aot_generators", "aot_language", "aot_native_program_templates", "aot_realm_modules", "runtime_cache", "structure", "weak_gc_facility"]],
    ("scriptw-runtime-image", "--lib", None), ("scriptw-ir", "--lib", None),
    ("scriptw-cli", "--example", "runtime_baseline"), ("scriptw-cli", "--example", "runtime_boundaries"),
    *[("scriptw-engine", "--test", name) for name in ["aot_intl", "aot_module_sources", "aot_regexp", "aot_temporal"]],
    ("scriptw-intl", "--lib", None), ("scriptw-intl", "--test", "calendar_domain"),
    ("scriptw-intl", "--test", "datetime_calendar16"), ("scriptw-intl-build-data", "--lib", None),
]


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def read_json(path):
    path = Path(path)
    require(path.is_file() and not path.is_symlink(), f"missing or symlinked evidence: {path}")
    return json.loads(path.read_text())


def observation_path(name):
    """Resolve exact prior authorities without copying/relabeling old receipts."""
    name = Path(name)
    require(not name.is_absolute() and '..' not in name.parts, 'unsafe observation reference')
    current = BASE / name
    return current if current.is_file() else HISTORY / name


def member_path(path):
    path = Path(path)
    require(path.is_file() and not path.is_symlink(), f"missing or symlinked archive input: {path}")
    resolved = path.resolve()
    require(resolved.is_relative_to(REPO), f"archive input escaped repository: {path}")
    require(path.stat().st_size < 64 * 1024**2, f"oversized evidence input: {path}")
    require(path.suffix not in {".swbundle", ".v8cache"}, f"session bundle/cache payload excluded: {path}")
    require(path.suffix not in {'.rlib', '.rmeta', '.a', '.o', '.so', '.tar'} and not path.name.endswith('.tar.gz'),
            f'build/archive payload excluded: {path}')
    with path.open("rb") as stream:
        require(stream.read(4) != b"\x7fELF", f"binaries excluded from evidence archive: {path}")
    relative = resolved.relative_to(BASE) if resolved.is_relative_to(BASE) else Path("reproduction") / resolved.relative_to(REPO)
    require(not any(part in {"cache", "execution-cache", "native-cache", "tmp", "__pycache__", ".git"} for part in relative.parts), f"temporary/cache input excluded: {path}")
    require(not any(part in {'frozen-9b-link-inputs', 'frozen-candidate-link-inputs', 'baseline-source-guards'}
                    for part in relative.parts), f'frozen build/source payload excluded: {path}')
    return PREFIX + relative.as_posix()


class Evidence:
    def __init__(self, base=BASE):
        self.base = Path(base)
        self.paths = {}
        self.virtual = {}
        self.resources = []
        self.lossless_wrappers = {}
        self.lossless_sources = {}

    def add(self, path):
        path = Path(path)
        name = member_path(path)
        if path.resolve() in {HISTORY / 'cargo-product.jsonl', REGEXP_STAGE / 'cargo-product.jsonl'}:
            return self.add_lossless_gzip(path, name)
        require(name not in self.paths or self.paths[name].resolve() == path.resolve(), f"conflicting archive name: {name}")
        self.paths[name] = path
        return name

    def add_lossless_gzip(self, path, logical_name):
        """Preserve every raw byte, while bounding historical producer archive size."""
        name = logical_name + '.gz'
        raw_bytes, raw_sha256 = path.stat().st_size, digest(path)
        existing = self.lossless_wrappers.get(logical_name)
        if existing is not None:
            require(existing['decoded_bytes'] == raw_bytes and existing['decoded_sha256'] == raw_sha256,
                    'historical raw Cargo transcript changed after lossless wrapping')
            return name
        require(logical_name not in self.paths and name not in self.paths and name not in self.virtual,
                'lossless wrapper conflicts with another evidence member')
        compressed = io.BytesIO()
        with path.open('rb') as raw, gzip.GzipFile(fileobj=compressed, mode='wb', filename='', mtime=0, compresslevel=6) as encoded:
            while chunk := raw.read(256 * 1024):
                encoded.write(chunk)
        data = compressed.getvalue()
        decoded = hashlib.sha256()
        length = 0
        with gzip.GzipFile(fileobj=io.BytesIO(data), mode='rb') as stream:
            while chunk := stream.read(256 * 1024):
                decoded.update(chunk); length += len(chunk)
                require(length <= raw_bytes, 'lossless Cargo wrapper expands beyond its raw source')
        require(length == raw_bytes and decoded.hexdigest() == raw_sha256
                and path.stat().st_size == raw_bytes and digest(path) == raw_sha256,
                'lossless Cargo wrapper did not preserve the original raw bytes')
        self.virtual[name] = data
        self.lossless_sources[name] = path
        self.lossless_wrappers[logical_name] = dict(logical_path=logical_name, archive_member=name,
            encoding='gzip', gzip_mtime=0, decoded_bytes=raw_bytes, decoded_sha256=raw_sha256,
            encoded_bytes=len(data), encoded_sha256=hashlib.sha256(data).hexdigest(),
            reproduction='Decompress the archive_member with gzip to recover the complete original logical_path; no rows or fields were removed.')
        return name

    def add_bytes(self, name, data):
        require(isinstance(data, bytes) and len(data) < 64 * 1024**2
                and not Path(name).is_absolute() and '..' not in Path(name).parts,
                'invalid generated provenance member')
        name = PREFIX + name
        require(name not in self.paths and (name not in self.virtual or self.virtual[name] == data),
                'conflicting generated provenance member')
        self.virtual[name] = data

    def resource(self, row, label):
        require(row.get("cpu_affinity") == [0], f"{label}: expected observed one-CPU affinity")
        require(str(row.get("memory.max")) == str(BUDGET) and str(row.get("memory.swap.max")) == "0", f"{label}: missing exact 4-GiB/no-swap cap")
        require(str(row.get("memory.oom.group")) == "1", f"{label}: missing grouped OOM policy")
        events = dict(line.split() for line in row.get("memory.events", "").splitlines())
        require(all(events.get(name) == "0" for name in ["oom", "oom_kill", "oom_group_kill"]), f"{label}: accepted receipt records OOM or missing observations")
        peak = int(row.get("memory.peak", -1))
        require(0 <= peak <= BUDGET, f"{label}: invalid cumulative cgroup peak")
        env = row.get("resource_environment", {})
        for name in ["CARGO_BUILD_JOBS", "SCRIPTW_JOBS", "RUST_TEST_THREADS", "RAYON_NUM_THREADS", "SCRIPTW_MODULE_MEMORY_CACHE_ENTRIES"]:
            require(env.get(name) == "1", f"{label}: nonserial or unbounded retained-cache environment")
        require(env.get("SCRIPTW_MODULE_MEMORY_CACHE_LIMIT_BYTES") == str(64 * 1024**2), f"{label}: cache image limit differs")
        completed_at = datetime.fromisoformat(row.get('date', ''))
        require(completed_at.utcoffset() is not None, f'{label}: actual completion timestamp lacks a timezone')
        self.resources.append({"label": label, "memory_peak_bytes": peak, "memory_events": events,
                               "cpu_affinity": row["cpu_affinity"], "completed_at": row['date']})

    def receipt(self, label, *, exit_code=0, checkout_source=None, clean_source=True):
        require(re.fullmatch(r"[A-Za-z0-9_-]+", label) is not None, "invalid receipt label")
        path = self.base / (label + ".json")
        row = read_json(path)
        require(row.get("label") == label and row.get("exit_code") == exit_code, f"{label}: actual receipt label/exit disagrees")
        checkout_source = candidate_source() if checkout_source is None else checkout_source
        require(row.get("source_head") == checkout_source, f"{label}: receipt checkout source differs")
        if clean_source:
            require(row.get("source_patch_sha256") == EMPTY_PATCH, f"{label}: product source was dirty")
        else:
            require(re.fullmatch(r"[0-9a-f]{64}", row.get("source_patch_sha256", "")) is not None, f"{label}: missing checkout patch observation")
        require(isinstance(row.get("command"), list) and row["command"], f"{label}: missing actual command")
        require(row.get("log") == label + ".log", f"{label}: log path differs")
        log = self.base / row["log"]
        require(digest(log) == row.get("log_sha256"), f"{label}: log hash differs")
        self.resource(row, label)
        self.add(path)
        self.add(log)
        return row, log.read_text(errors="replace")


def current_source():
    actual = subprocess.check_output(["git", "rev-parse", candidate_source() + "^{commit}"], cwd=REPO, text=True).strip()
    require(actual == candidate_source(), "candidate product source is unavailable")
    difference = subprocess.check_output(["git", "diff", "--binary", candidate_source(), "--", "crates", "Cargo.toml", "Cargo.lock"], cwd=REPO)
    require(difference == b"", "product inputs differ from the measured source commit")
    require(subprocess.check_output(["git", "ls-files", "--others", "--exclude-standard", "--", "crates", "Cargo.toml", "Cargo.lock"], cwd=REPO) == b"", "untracked product files are outside measured authority")


def inventory_names(log, *, allow_empty=False):
    names = sorted(re.findall(r"^([^\s]+): test$", log, re.M))
    require(len(set(names)) == len(names)
            and (bool(names) or allow_empty and re.findall(r'^0 tests, 0 benchmarks$', log, re.M) == ['0 tests, 0 benchmarks']),
            "native inventory is empty or repeated without an explicit zero-case target")
    return names


def observed_names(log):
    return [(name.removesuffix(" - should panic"), status) for name, status in re.findall(r"^test (.+) \.\.\. (ok|FAILED|ignored)$", log, re.M)]


def closed_native_log(row, log, inventory, *, filtered=0):
    observed = observed_names(log)
    require(sorted(name for name, _ in observed) == sorted(inventory) and all(status == "ok" for _, status in observed), f'{row["label"]}: native transcript lost, repeated, failed or ignored an identity')
    expected = [("ok", str(len(inventory)), "0", "0", "0", str(filtered))]
    require(SUMMARY_RE.findall(log) == expected and row.get("test_results") == [list(expected[0])], f'{row["label"]}: terminal counts do not reconcile to exact inventory')


def engine_native(evidence, scope, recorded):
    path = BASE / "engine-accepted.json"
    aggregate = read_json(path)
    manifest_path = BASE / "engine-batches.json"
    manifest = read_json(manifest_path)
    require(aggregate == recorded and aggregate.get("source_head") == candidate_source() and aggregate.get("source_patch_sha256") == EMPTY_PATCH, "engine aggregate source differs")
    require(aggregate.get("complete") is True and aggregate.get("exit_code") == 0 and manifest.get("complete") is True and manifest.get("source_head") == candidate_source(), "engine aggregate or exact batch manifest is incomplete")
    require("log" not in aggregate and "test_results" not in aggregate and "no synthetic single-process transcript" in aggregate.get("aggregation", ""), "engine observations must remain an explicit aggregate")
    inventory = manifest.get("inventory", [])
    require(inventory and sorted(set(inventory)) == inventory and aggregate.get("inventory") == inventory and aggregate.get("passed") == len(inventory), "engine denominator differs")
    enumerated, enumeration_log = evidence.receipt("engine-batches-inventory")
    require(enumerated["command"] == [manifest["binary"], "--list", "--include-ignored"] or Path(enumerated["command"][0]).resolve() == Path(manifest["binary"]).resolve() and enumerated["command"][1:] == ["--list", "--include-ignored"], "engine inventory invocation differs")
    require(inventory_names(enumeration_log) == inventory, "engine inventory does not match actual native enumeration")
    require(len(enumerated.get("executables", [])) == 1, "engine executable identity is missing")
    binary = enumerated["executables"]
    seen = []
    labels = []
    for index, batch in enumerate(manifest.get("batches", [])):
        label = f"engine-batch-{index:03d}"
        require(batch.get("label") == label and set(batch) == {"label", "inventory"}, "engine batch metadata differs")
        names = batch["inventory"]
        require(isinstance(names, list) and 1 <= len(names) <= 32 and len(set(names)) == len(names) and set(names).issubset(inventory), f"{label}: invalid bounded inventory")
        if any(name.startswith("runtime_profile::") or "capacity" in name or "inlining" in name for name in names):
            require(len(names) == 1, f"{label}: capacity/inlining/profile case was not isolated")
        row, log = evidence.receipt(label)
        require(Path(row["command"][0]).resolve() == Path(manifest["binary"]).resolve() and row["command"][1:] == names + ["--exact", "--test-threads=1", "--include-ignored"], f"{label}: exact-name invocation differs")
        require(row.get("executables") == binary, f"{label}: executed engine binary differs from complete enumeration")
        closed_native_log(row, log, names, filtered=len(inventory) - len(names))
        seen.extend(names)
        labels.append(label + ".json")
    require(sorted(seen) == inventory and len(set(seen)) == len(seen), "engine batch union omits or repeats native identities")
    require(aggregate.get("batch_manifest") == manifest_path.name, "engine aggregate names another manifest")
    require(len(inventory) == 1032, "complete actual engine inventory differs from1032")
    evidence.receipt("engine-batches-build")
    for extra in [path, manifest_path]:
        evidence.add(extra)
    return {**scope, "passed": len(inventory), "inventory_sha256": hashlib.sha256(("\n".join(inventory) + "\n").encode()).hexdigest(), "verification": "exact disjoint bounded native process observations", "aggregate_receipt": path.name, "manifest": manifest_path.name, "batch_count": len(labels), "receipts": labels, "executables": binary}


def native(evidence):
    scopes = read_json(BASE / "native-scopes.json")
    closed = read_json(BASE / "native-closed.json")
    require([(s["package"], s["kind"], s["name"]) for s in scopes] == EXPECTED_SCOPES, "complete affected31-target inventory changed")
    require(closed.get("source") == candidate_source() and closed.get("complete") is True and len(closed.get("targets", [])) == len(scopes), "native target manifest is incomplete or stale")
    total, qualified, targets = 0, [], []
    for index, (scope, recorded) in enumerate(zip(scopes, closed["targets"])):
        if scope["package"] == "scriptw-engine" and scope["kind"] == "--lib":
            result = engine_native(evidence, scope, recorded)
            names = recorded["inventory"]
        else:
            label = f'broad-{index:02d}-{scope["package"]}-{scope["name"] or "lib"}'
            row, log = evidence.receipt(label)
            enumerated, enumeration_log = evidence.receipt(label + "-inventory")
            command = ["cargo", "test", "--locked", "--offline", "--release", "--jobs", "1", "-p", scope["package"], scope["kind"]]
            if scope["name"] is not None:
                command.append(scope["name"])
            require(row["command"] == command + ["--", "--test-threads=1", "--include-ignored"] and enumerated["command"] == command + ["--", "--list", "--include-ignored"], f"{label}: broad/inventory commands contain filters or changed policy")
            zero_case_target = scope == dict(package='scriptw-intl-build-data', kind='--lib', name=None)
            names = inventory_names(enumeration_log, allow_empty=zero_case_target)
            if scope['package'] == 'scriptw-aot-wasm' and scope['kind'] == '--lib':
                require(len(names) == 478, 'actual final AOT library must include both new regressions (478 identities)')
            if scope['package'] == 'scriptw-engine' and scope['name'] == 'aot_regexp':
                require(len(names) == 152, 'actual complete RegExp target must close all152 identities in its whole-target run')
            closed_native_log(row, log, names)
            require(row.get("executables") and row["executables"] == enumerated.get("executables"), f"{label}: enumerated and executed native binaries differ")
            inventory_sha = hashlib.sha256(("\n".join(names) + "\n").encode()).hexdigest()
            require(recorded == dict(row, **scope, inventory=names, inventory_sha256=inventory_sha), f"{label}: closed manifest differs from actual native evidence")
            result = {**scope, "passed": len(names), "inventory_sha256": inventory_sha, "run_receipt": label + ".json", "inventory_receipt": label + "-inventory.json", "executables": row["executables"]}
        total += len(names)
        qualified.extend(f'{scope["package"]}:{scope["kind"]}:{scope["name"] or "lib"}:{name}' for name in names)
        targets.append(result)
    require(total == closed.get("total") and len(qualified) == len(set(qualified)), "native totals or qualified identity union differs")
    for package in sorted({scope["package"] for scope in scopes}):
        label = next((value for value in [f"frozen-build-final-{package}", f"frozen-build-{package}"] if (BASE / (value + ".json")).is_file()), None)
        require(label is not None, f"missing final serial native build: {package}")
        row, _ = evidence.receipt(label)
        expected = ["cargo", "test", "--locked", "--offline", "--release", "--jobs", "1", "-p", package, "--no-run"]
        for scope in scopes:
            if scope["package"] == package:
                expected.append(scope["kind"])
                if scope["name"]:
                    expected.append(scope["name"])
        require(row["command"] == expected, f"{label}: native build omitted a selected target or changed policy")
    focused = []
    for label, planned_package, planned_target, planned_pattern in focused_checks():
        path = BASE / (label + '.json')
        row, log = evidence.receipt(path.stem)
        names = [name for name, status in observed_names(log) if status == "ok"]
        command = row["command"]
        require(command == ['cargo', 'test', '--locked', '--offline', '--release', '--jobs', '1', '-p', planned_package,
                            *planned_target, planned_pattern, '--', '--test-threads=1', '--include-ignored'],
                'actual focused command differs from the complete eleven-group plan')
        package = command[command.index("-p") + 1]
        kind = next(flag for flag in ["--lib", "--test", "--example"] if flag in command)
        name = None if kind == "--lib" else command[command.index(kind) + 1]
        selected = next(item for item in closed["targets"] if (item["package"], item["kind"], item["name"]) == (package, kind, name))
        require(names and set(names).issubset(selected["inventory"]), f'{row["label"]}: focused identities are absent from the complete target')
        closed_native_log(row, log, names, filtered=len(selected["inventory"]) - len(names))
        focused.append({"receipt": path.name, "passed": len(names), "overlaps_complete_targets": True, "added_to_total": False})
    for path in [BASE / "native-scopes.json", BASE / "native-closed.json"]:
        evidence.add(path)
    return {"complete": True, "target_count": len(targets), "passed": total, "failed": 0, "ignored": 0,
            "nonempty_target_count": sum(row['passed'] > 0 for row in targets),
            "zero_case_targets": [dict(package=row['package'], kind=row['kind'], name=row['name'])
                                  for row in targets if row['passed'] == 0],
            "inventory_sha256": hashlib.sha256(("\n".join(sorted(qualified)) + "\n").encode()).hexdigest(), "targets": targets, "focused": focused}


def selected_scopes(evidence, summary, batches):
    plan_path = BASE / 'selected-scopes.json'
    plan = read_json(plan_path)
    controls_path = BASE / 'selected.ids'
    controls = controls_path.read_text().splitlines()
    require(plan.get('complete') is True and plan.get('selected_total') == 7746
            and plan.get('source_inventory_reused_for_scope_planning_only') is True
            and plan.get('require_current_compiler_inventory_exact_match_before_execution') is True,
            'scope plan lost its planning-only/current-admission boundary')
    require(len(controls) == len(set(controls)) == 7746 and controls == sorted(controls),
            'exact sorted7746-execution input changed')
    replay = BASE / 'conformance'
    inventory = summary['native_inventory']
    require(inventory.get('command') == [summary['binary'], '--jobs', '1', 'test262', 'list-all',
                                       '--suite-root', summary['suite_root']], 'final inventory command differs')
    inventory_path = replay / inventory['stdout']
    require(Path(inventory['stdout']).name == inventory['stdout']
            and digest(inventory_path) == inventory.get('stdout_sha256'), 'final native inventory hash differs')
    current = batches.native_inventory(inventory_path.read_text())
    require(len(current) == plan.get('source_inventory_execution_count') == 102994
            and digest(inventory_path) == plan.get('source_inventory_sha256'),
            'final full pinned inventory differs from planning authority')
    precheck_path = BASE / 'conformance-inventory-validated.json'
    precheck = read_json(precheck_path)
    enumerated, enumeration_log = evidence.receipt('conformance-inventory-final')
    require(enumerated['command'] == [str(BASE / 'candidate/scriptw'), '--jobs', '1', 'test262',
            'list-all', '--suite-root', 'test262/vendor/test262'], 'pre-execution compiler inventory differs')
    require(digest(BASE / enumerated['log']) == digest(inventory_path)
            and batches.native_inventory(enumeration_log) == current, 'precheck/replay inventories disagree')
    expected_precheck = dict(complete=True, source_head=candidate_source(), compiler_identity=summary['compiler_identity'],
        receipt='conformance-inventory-final.json', inventory_sha256=digest(inventory_path), total=len(current),
        selected_total=len(controls), selected_ids_sha256=digest(controls_path), scope_plan_sha256=digest(plan_path))
    require(precheck == expected_precheck, 'pre-execution inventory admission changed')
    required = {'language/module-code/': 602, 'built-ins/Function/prototype/apply/': 88,
                'built-ins/Function/prototype/bind/': 200, 'built-ins/Function/prototype/call/': 90, 'intl402/': 6764}
    require({row['prefix']: row['count'] for row in plan['scopes']} == required
            and len(plan['scopes']) == len(required), 'complete selected family plan differs')
    union, scopes = set(), []
    for scope in plan['scopes']:
        prefix = scope['prefix']
        actual = sorted(value for value in current if value.split(':', 1)[1].startswith(prefix))
        require(actual == sorted(scope['execution_ids']) and len(actual) == scope['count']
                , 'final selected family omits or adds cases: ' + prefix)
        union.update(actual)
        scopes.append({'prefix': prefix, 'count': len(actual)})
    require(set(plan['known_failure_controls']) == KNOWN and len(plan['known_failure_controls']) == 4,
            'known failure controls changed')
    union.update(KNOWN)
    require(union == set(controls), 'selected families/controls do not exactly form all requested IDs')
    for path in [plan_path, controls_path, inventory_path, precheck_path]:
        evidence.add(path)
    return controls, dict(complete=True, pre_execution_admission=precheck,
        final_full_inventory_sha256=digest(inventory_path), final_full_inventory_total=len(current),
        scopes=scopes, known_failure_controls=sorted(KNOWN), execution_ids_sha256=digest(controls_path))


def performance(evidence, product_report):
    module_path = BASE / "analyze.py"
    spec = importlib.util.spec_from_file_location("execution_performance_analysis", module_path)
    analysis = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(analysis)
    require(callable(getattr(analysis, "build_report", None)), "analysis tool must expose read-only build_report()")
    actual = analysis.build_report()
    path = BASE / "analysis.json"
    require(read_json(path) == actual and actual.get("complete") is True and actual.get("round_order") == ROUNDS, "comparison summary differs from validated actual observations")
    require(len(actual.get("cases", [])) == 17, "balanced comparison did not finish all17 exact workloads")
    rows = []
    for index, label in enumerate(ROUNDS):
        product = "baseline" if index in [0, 3] else "candidate"
        report = read_json(BASE / label / "report.json")
        identity = product_report[product]["compiler_identity"]
        require(report.get("compiler_identity") == identity and report.get("runtime_runner_sha256") == product_report[product]["runtime_runner_sha256"], f"{label}: measured binary/source identity differs")
        receipt_label = label.removesuffix("-data")
        receipt, _ = evidence.receipt(receipt_label)
        require(report.get("samples") == 7 and report.get("warmups") == 10 and report.get("complete") is True, f"{label}: incomplete sample/warmup policy")
        for item in (BASE / label).iterdir():
            if item.is_file() and (item.name == "report.json" or item.suffix in {".stdout", ".stderr"}):
                evidence.add(item)
            elif item.is_dir() and item.name.endswith("-wasm"):
                for artifact in item.iterdir():
                    require(artifact.is_file() and artifact.suffix == ".wasm", "unexpected measured artifact member")
                    evidence.add(artifact)
    for case in actual["cases"]:
        before = case["pooled"]["baseline"]["wasmtime"]["median_execution_ns"]
        after = case["pooled"]["candidate"]["wasmtime"]["median_execution_ns"]
        v8 = case["pooled"]["candidate"]["v8"]["median_execution_ns"]
        rows.append({"file": case["file"], "baseline_ms": before / 1e6, "candidate_ms": after / 1e6, "change_percent": 100 * (after / before - 1), "paired_candidate_v8_ms": v8 / 1e6, "candidate_over_paired_v8": after / v8})
    for extra in [module_path, path, REPO / "crates/scriptw-cli/tests/fixtures/v8_baseline/node-runtime.cjs"]:
        evidence.add(extra)
    for extra in analysis.evidence_files():
        evidence.add(extra)
    fixtures = REPO / "crates/scriptw-cli/tests/fixtures/v8_execution_hotpaths"
    for path in fixtures.iterdir():
        require(path.is_file() and path.suffix in {".js", ".json"}, "unexpected workload fixture member")
        evidence.add(path)
    return {"complete": True, "balanced_observations": actual, "table": rows, "rss_table": ordinary_rss_table(actual),
            "rss_table_statistic": "Median of the14 validated post-execution process endpoints per product/runtime: Wasmtime final sampler read while Store remains alive; V8 after-execution snapshot while context remains alive. Before/after are9b/actual candidate; V8 is paired with the candidate. Not live JS heap or whole-child high-water RSS.",
            "table_statistic": "median of14 measured samples per product, pooled from two fresh process rounds of7 measured samples after10 warmups each; per-round medians and adjacent comparisons retained", "policy": "unchanged default Fast P and optimized Portable R, 16-MiB initial GC capacity; one CPU, fresh Store/Realm or V8 context; execution+completion includes construction and checksums", "interpretation": "descriptive paired measurements, not a statistical significance test or a universal V8-parity claim", "ambient_load_limit": "unrelated CPU-active processes and desktop activity were observed on the shared host; loadavg start/end is retained for every round; this is not an otherwise-idle or isolated causal measurement and cannot certify idle-machine repeatability", "historical_readme_graph_refreshed": False}


def ordinary_rss_table(analysis):
    """Rederive endpoint medians from the admitted fresh-analysis value arrays."""
    cases = analysis['cases']
    require(len(cases) == len({case['file'] for case in cases}) == 17,
            'ordinary RSS table requires all17 unique fresh cases')
    rows = []
    for case in cases:
        values = {}
        for name, product, runtime, field in [
            ('baseline_rss_bytes', 'baseline', 'wasmtime', 'final_rss_bytes'),
            ('candidate_rss_bytes', 'candidate', 'wasmtime', 'final_rss_bytes'),
            ('paired_candidate_v8_rss_bytes', 'candidate', 'v8', 'rss_after_execution_bytes'),
        ]:
            summary = case['pooled'][product][runtime]['memory_observations'][field]
            observed = summary['values']
            require(len(observed) == 14 and all(type(value) is int and 0 < value <= BUDGET for value in observed)
                    and median(observed) == summary['median'], 'ordinary endpoint RSS values/median differ')
            values[name] = median(observed)
        rows.append(dict(file=case['file'], **values))
    return rows


def performance_calls(evidence, product_report):
    """Keep callback-delimited calls separate from ordinary entry execution."""
    sys.path.insert(0, str(BASE))
    module_path = BASE / "analysis_calls.py"
    spec = importlib.util.spec_from_file_location("execution_performance_call_analysis", module_path)
    analysis = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(analysis)
    actual = analysis.build_report()
    path = BASE / "analysis_calls.json"
    require(read_json(path) == actual, "existing-Realm comparison differs from actual checked sessions")
    require(actual.get("schema") == "scriptw-execution-same-realm-comparison-v1" and actual.get("complete") is True and actual.get("round_order") == CALL_ROUNDS, "existing-Realm ABBA cohort is partial, reordered or mislabeled")
    require(actual.get("case_count") == 17 and actual.get("samples_per_session") == 7 and actual.get("guest_warmups") == 10 and actual.get("sessions_per_product") == 2 and actual.get("pooled_samples_per_product") == 14, "existing-Realm session/call/warmup denominator changed")
    fixtures = REPO / "crates/scriptw-cli/tests/fixtures/v8_execution_hotpaths"
    expected_cases = read_json(fixtures / "manifest.json")["execution"]
    require([case["file"] for case in actual["cases"]] == [case["file"] for case in expected_cases], "existing-Realm cohort does not preserve the exact17 original workloads")
    for index, label in enumerate(CALL_ROUNDS):
        product = "baseline" if index in [0, 3] else "candidate"
        round_report = read_json(BASE / label / "report.json")
        require(round_report.get("compiler_identity") == product_report[product]["compiler_identity"] and round_report.get("runtime_boundaries_sha256") == product_report[product]["runtime_boundaries_sha256"], f"{label}: callback observer product/source differs from frozen authority")
        receipt, _ = evidence.receipt(label.removesuffix("-data"))
        command = receipt["command"]
        require(any(Path(part).name == "measure_calls.py" for part in command) and product in command and label in command, f"{label}: actual call measurement command differs")
    rows = []
    for case in actual["cases"]:
        require(case["original_source_sha256"] == digest(fixtures / case["file"]), "existing-Realm original workload source changed")
        before = case["pooled"]["baseline"]["wasmtime"]["median_ns"]
        after = case["pooled"]["candidate"]["wasmtime"]["median_ns"]
        v8 = case["pooled"]["candidate"]["v8"]["median_ns"]
        rows.append({"file": case["file"], "baseline_ms": before / 1e6, "candidate_ms": after / 1e6, "change_percent": 100 * (after / before - 1), "paired_candidate_v8_ms": v8 / 1e6, "candidate_over_paired_v8": after / v8})
    evidence.add(path)
    for extra in analysis.evidence_files():
        evidence.add(extra)
    return {"complete": True, "balanced_observations": actual, "table": rows, "table_statistic": "median of14 elapsed callback intervals per product, pooled from two existing-Realm sessions of7 calls after10 guest warmups each", "measurement": "elapsed wall time between actual callback exit/entry timestamps; not a measured CPU clock; includes workload construction/checksum and marker overhead; excludes setup/bootstrap, warmups, checksum printing, bundle/cache admission and native compilation; no empty subtraction", "source_cohort": "separate generated wrapper: original workload IIFE body becomes batch(seed), sole final print expression becomes return expression; original inputs and explicit String(checksum) conversions retained; exact result checked outside every interval", "archive_exclusions": "session Portable P/R bundles, V8 cachedData, executables and native caches excluded; actual payload hashes/framing, regeneration commands, transformed sources and harness snapshots retained", "ambient_load_limit": "shared-host CPU/desktop activity and raw load averages retained; descriptive observations cannot certify idle-machine repeatability, causal significance or universal V8 parity"}


def pinned_fixtures(summary, controls):
    """Bind observed fixture SHA-256s to blobs in the exact pinned Git tree."""
    pins_path = REPO / "crates/scriptw-test262/src/source-pins.json"
    pins = read_json(pins_path)
    tree = subprocess.check_output(["git", "rev-parse", candidate_source() + ":test262/vendor/test262"], cwd=REPO, text=True).strip()
    require(tree == pins["test262_tree"], "source commit does not contain the pinned Test262 tree")
    paths = {execution.split(":", 1)[1] for execution in controls}
    require(set(summary.get("fixture_sha256", {})) == paths, "fixture digest inventory does not cover exactly the requested paths")
    tree_entries = subprocess.check_output(["git", "ls-tree", "-r", "-z", candidate_source() + ":test262/vendor/test262/test"], cwd=REPO)
    blobs = {}
    for entry in tree_entries.split(b"\0"):
        if not entry: continue
        header, name = entry.split(b"\t", 1)
        name = name.decode()
        if name in paths:
            _, kind, oid = header.split()
            require(kind == b"blob", "requested fixture is not a pinned Git blob")
            blobs[name] = oid.decode()
    require(set(blobs) == paths, "requested fixture is missing from the pinned tree")
    ordered = sorted(blobs)
    process = subprocess.run(["git", "cat-file", "--batch"], input=("\n".join(blobs[name] for name in ordered) + "\n").encode(), stdout=subprocess.PIPE, stderr=subprocess.PIPE, cwd=REPO, check=True)
    content, offset = process.stdout, 0
    for name in ordered:
        end = content.index(b"\n", offset)
        oid, kind, length = content[offset:end].split()
        require(oid.decode() == blobs[name] and kind == b"blob", "Git returned another fixture object")
        start, size = end + 1, int(length)
        data = content[start:start + size]
        require(len(data) == size and content[start + size:start + size + 1] == b"\n", "pinned fixture batch is truncated")
        require(hashlib.sha256(data).hexdigest() == summary["fixture_sha256"][name], f"observed fixture differs from pinned Git bytes: {name}")
        offset = start + size + 1
    require(offset == len(content), "unexpected trailing Git fixture data")
    return {"source_tree": tree, "fixture_count": len(paths), "fixture_hashes": summary["fixture_sha256"]}

def cargo_products(path):
    rows, finished = {}, []
    names = {'scriptw', 'runtime_baseline', 'runtime_boundaries'}
    require(path.stat().st_size < 64 * 1024**2, 'Cargo product transcript exceeds publication budget')
    for line in path.read_text().splitlines():
        row = json.loads(line)
        if row.get('reason') == 'build-finished':
            finished.append(row.get('success'))
        if row.get('reason') != 'compiler-artifact' or not row.get('executable'):
            continue
        name = Path(row['executable']).name
        if name not in names:
            continue
        require(name not in rows, 'duplicate final Cargo executable: ' + name)
        kind = 'bin' if name == 'scriptw' else 'example'
        require(row.get('features') == [] and row['profile']['opt_level'] == '3'
                and row['profile']['test'] is False and row['target']['name'] == name
                and kind in row['target']['kind']
                and Path(row['manifest_path']).resolve() == REPO / 'crates/scriptw-cli/Cargo.toml',
                'Cargo executable lacks its actual ordinary default-feature release producer: ' + name)
        rows[name] = row
    require(finished == [True] and set(rows) == names, 'Cargo product build omitted/failed an ordinary executable')
    return rows

def additional_observations(evidence):
    extra = []
    accepted = {path.resolve() for path in evidence.paths.values()}
    for log in sorted(BASE.glob('*.log')):
        if log.resolve() in accepted:
            continue
        receipt_path = log.with_suffix('.json')
        item = {'log': log.name, 'log_sha256': digest(log),
                'included_in_accepted_totals': False}
        if receipt_path.is_file():
            receipt = read_json(receipt_path)
            require(receipt.get('log') == log.name and receipt.get('log_sha256') == digest(log),
                    'extra diagnostic receipt/transcript differs: ' + log.name)
            item.update(status='terminal-observation-outside-accepted-inputs',
                        actual_receipt=receipt)
            evidence.add(receipt_path)
        else:
            item['status'] = 'partial-observation-without-terminal-receipt'
        evidence.add(log)
        extra.append(item)
    return {'observations': extra, 'interpretation': 'Actual additional/partial/failing observations are preserved under their original identities. They do not enter accepted native/performance totals or acquire retroactive kernel-resource claims.'}


def products(evidence):
    """Admit prior published 9b bytes without rehashing overwritten old outputs."""
    from campaign_identity import frozen_product
    old_path = REPO / 'docs/rust-rewrite/execution-memory-20261025.json'
    old = read_json(old_path)
    require(old['source_commit'] == BASELINE_SOURCE and old['complete'] is True,
            'prior baseline checkpoint source differs')
    old_product = old['products']['candidate']
    old_root = REPO / 'target/memory-execution-20261025'
    old_release_path = old_root / 'release-final.json'
    old_release = read_json(old_release_path)
    require(old_release['source_head'] == BASELINE_SOURCE and old_release['source_patch_sha256'] == EMPTY_PATCH
            and old_release['exit_code'] == 0, 'baseline lacks its actual clean release receipt')
    old_archive = old_path.parent / old['archive']['file']
    require(digest(old_archive) == old['archive']['sha256'], 'prior publication archive changed')
    prefix = old_archive.name.removesuffix('.tar.gz') + '/'
    with tarfile.open(old_archive, 'r:gz') as bundle:
        member = bundle.getmember(prefix + 'archive-members.json')
        require(member.isfile() and member.size < 4 * 1024**2, 'prior build manifest is invalid')
        manifest_bytes = bundle.extractfile(member).read()
    require(hashlib.sha256(manifest_bytes).hexdigest() == old['archive']['manifest_sha256'],
            'prior published manifest hash differs')
    manifest = json.loads(manifest_bytes)
    require(manifest['source_commit'] == BASELINE_SOURCE, 'prior manifest source differs')
    declared = {item['path']: item for item in manifest['members']}
    old_cargo_path = old_root / 'cargo-product.jsonl'
    for name, path in [('cargo-product.jsonl', old_cargo_path), ('release-final.json', old_release_path),
                       ('release-final.log', old_root / old_release['log'])]:
        item = declared[prefix + name]
        require(path.stat().st_size == item['bytes'] and digest(path) == item['sha256'],
                'prior immutable build evidence changed: ' + name)
        evidence.add(path)
    require(digest(old_root / old_release['log']) == old_release['log_sha256'], 'baseline release log changed')
    evidence.resource(old_release, 'baseline-original-release')
    baseline, baseline_hashes = frozen_product('baseline')
    require(baseline == old_product['compiler_identity']
            and baseline_hashes['runtime_baseline'] == old_product['runtime_runner_sha256']
            and baseline_hashes['runtime_boundaries'] == old_product['runtime_boundaries_sha256'],
            'frozen baseline differs from actually published 9b bytes')
    candidate, candidate_hashes = frozen_product('candidate')
    require(candidate['source_revision'] == {'kind': 'git-commit', 'commit': candidate_source()}, 'candidate source differs')
    release, _ = evidence.receipt('release-products')
    require(Path(release['command'][-1]).resolve() == BASE / 'build_product.py', 'actual product builder differs')
    cargo_path = BASE / 'cargo-product.jsonl'
    actual = cargo_products(cargo_path)
    frozen_path = BASE / 'frozen-products.json'
    frozen = read_json(frozen_path)
    require(frozen['source_commit'] == candidate_source() and set(frozen['products']) == set(actual),
            'frozen candidate product manifest differs')
    for name, producer in actual.items():
        item = frozen['products'][name]
        require(item['cargo_producer'] == producer and item['actual_cargo_product'] == producer['executable']
                and item['sha256'] == candidate_hashes[name] == digest(producer['executable'])
                and item['bytes'] == (BASE / 'candidate' / name).stat().st_size,
                'candidate no longer matches actual completed Cargo producer: ' + name)
    for path in [old_path, product_directory('baseline') / 'identity.json', BASE / 'candidate/identity.json', frozen_path,
                 cargo_path, BASE / 'cargo-product.stderr']:
        evidence.add(path)
    evidence.add_bytes('baseline/published-build-members.json', manifest_bytes)
    return dict(
        baseline=dict(compiler_identity=baseline, runtime_runner_sha256=baseline_hashes['runtime_baseline'],
                      runtime_boundaries_sha256=baseline_hashes['runtime_boundaries'], actual_build_source=BASELINE_SOURCE,
                      actual_source_patch_sha256=EMPTY_PATCH,
                      published_checkpoint=dict(path=str(old_path.relative_to(REPO)), sha256=digest(old_path)),
                      original_release_receipt=dict(path=str(old_release_path.relative_to(REPO)), sha256=digest(old_release_path)),
                      original_cargo_products=dict(path=str(old_cargo_path.relative_to(REPO)), sha256=digest(old_cargo_path),
                                                   producers=cargo_products(old_cargo_path)),
                      provenance='Actual prior clean 9b release, published archive and independent frozen ELF hashes; '
                                 'old mutable Cargo executable paths are not relabelled or rehashed as baseline products.'),
        candidate=dict(compiler_identity=candidate, runtime_runner_sha256=candidate_hashes['runtime_baseline'],
                       runtime_boundaries_sha256=candidate_hashes['runtime_boundaries'], source_tree_clean=True,
                       release_receipt='release-products.json', cargo_producers=actual))


def conformance(evidence):
    """Derive every actual selected outcome; never manufacture a pass total."""
    sys.path.insert(0, str(REPO / 'scripts'))
    import test262_execution_batches as batches
    replay = BASE / 'conformance'
    summary = read_json(replay / 'summary.json')
    controls, scopes = selected_scopes(evidence, summary, batches)
    identity = summary['compiler_identity']
    require(identity == read_json(BASE / 'candidate/identity.json')
            and identity['source_revision'] == {'kind': 'git-commit', 'commit': candidate_source()}, 'conformance compiler differs')
    results = summary.get('results', [])
    require(summary.get('complete') is not False and len(results) == len(controls) == 7746
            and len({row['execution_id'] for row in results}) == len(results)
            and {row['execution_id'] for row in results} == set(controls), 'actual selected results are incomplete')
    counts = Counter(row['outcome'] for row in results)
    require(set(counts) <= {'Success', 'Bug', 'Crash', 'NotImplemented'}, 'unknown selected outcome')
    outcomes = {name: counts[name] for name in ['Success', 'Bug', 'Crash', 'NotImplemented']}
    unexpected = [row['execution_id'] for row in results if row['outcome'] != 'Success' and row['execution_id'] not in KNOWN]
    require(not unexpected, 'actual selected replay has new non-success executions; preserve and investigate before scoring')
    require(summary.get('outcomes') == outcomes and summary.get('total') == len(controls)
            and summary.get('replay_mode') == 'native-execution-list-v1'
            and summary.get('absent_executions') == [] and summary.get('batch_threads') == 1
            and sorted(summary.get('batch_executions', [])) == controls,
            'selected aggregate is not its actual exact result union')
    actual_exit = 0 if outcomes['Success'] == len(controls) else 1
    receipt, _ = evidence.receipt('conformance-final', exit_code=actual_exit)
    command = receipt['command']
    require('--workers' in command and command[command.index('--workers') + 1] == '1'
            and '--reuse-case-workers' in command
            and any(Path(part).name == 'replay-test262-executions.py' for part in command)
            and any(Path(part).resolve() == BASE / 'selected.ids' for part in command),
            'actual replay launcher changed source, serial workers or native worker reuse')
    binary = Path(summary['binary'])
    require(binary.resolve().is_relative_to(replay.resolve())
            and digest(binary) == summary['binary_sha256'] == identity['executable_sha256'], 'replayed binary differs')
    require((replay / 'executions').read_bytes() == (BASE / 'selected.ids').read_bytes()
            and digest(replay / 'executions') == summary['execution_list_sha256'], 'frozen selected list differs')
    fixtures = pinned_fixtures(summary, controls)
    options = types.SimpleNamespace(output_dir=replay)
    snapshots, invocations = {}, {}
    for row in results:
        require(row.get('protocol') == 'native-execution-list-v1' and 'infrastructure_error' not in row,
                'selected verdict lacks completed native evidence')
        batches.verify_saved_result(row, summary, options, snapshots)
        require(row['exit_code'] == (0 if row['outcome'] == 'Success' else 1), 'result exit differs from verdict')
        path = replay / (hashlib.sha256(row['execution_id'].encode()).hexdigest() + '.json')
        require(read_json(path) == row, 'individual result differs from actual summary')
        evidence.add(path)
        for name in [row['transcript'], row['native_snapshot']['path'], row['invocation']]:
            require(Path(name).name == name, 'selected evidence path escaped its directory')
            evidence.add(replay / name)
        invocation_path = replay / row['invocation']
        if invocation_path not in invocations:
            invocation = read_json(invocation_path)
            args = invocation['command']
            require(invocation['exit_code'] in [0, 1] and 'run-list' in args and '--threads' in args
                    and args[args.index('--threads') + 1] == '1' and '--timeout-ms' in args
                    and args[args.index('--timeout-ms') + 1] == '60000', 'native replay worker/deadline differs')
            for stream in ['stdout', 'stderr']:
                raw = batches.owned_file(options, invocation[stream])
                require(digest(raw) == invocation[stream + '_sha256'], 'native invocation stream changed')
                evidence.add(raw)
            invocations[invocation_path] = invocation
    pins = read_json(REPO / 'crates/scriptw-test262/src/source-pins.json')
    timeout_ids, failures = set(), []
    for path in snapshots:
        snapshot = read_json(path)
        require(snapshot['pinned_revisions'] == {'ecma262': pins['ecma262'], 'test262': pins['test262_tree']},
                'actual selected snapshot changed suite pins')
        timeout_ids.update(snapshot.get('timeout_test_ids', []))
        failures.extend(snapshot.get('failures', []))
    require(not timeout_ids, 'selected execution has actual timeouts; preserve evidence before resolving them')
    for name in ['summary.json', 'run.json', 'executions', 'batch-executions', 'compiler-identity.stdout',
                 'compiler-identity.stderr', 'native-inventory.stderr']:
        evidence.add(replay / name)
    require(read_json(replay / 'run.json')['compiler_identity'] == identity
            and digest(replay / 'batch-executions') == summary['batch_execution_list_sha256'],
            'actual native replay identity/list changed')
    unique_failures = {json.dumps(row, sort_keys=True): row for row in failures}
    baseline_path = REPO / 'docs/rust-rewrite/execution-memory-20261025.json'
    baseline = read_json(baseline_path)
    require(baseline['complete'] is True and baseline['source_commit'] == BASELINE_SOURCE,
            'known-failure authority is not the published9b checkpoint')
    reference = baseline['test262']['known_failure_reference']
    reference_relative = Path(reference['path'])
    require(not reference_relative.is_absolute() and '..' not in reference_relative.parts,
            'known-failure authority path escaped the repository')
    reference_path = REPO / reference_relative
    require(digest(reference_path) == reference['sha256'], 'published9b failure-signature authority bytes changed')
    original_snapshot = read_json(reference_path)['conformance']['native_snapshot']
    signature = lambda row: (row['test_id'], row['kind'], row['outcome'], row['detail_hash'])
    original_signatures = sorted({signature(row) for row in original_snapshot['failures']})
    actual_signatures = sorted({signature(row) for row in unique_failures.values()})
    require([list(row) for row in original_signatures] == reference['signatures']
            and [row[0] for row in original_signatures] == sorted(KNOWN)
            and actual_signatures == original_signatures
            and original_snapshot['pinned_revisions'] == {'ecma262': pins['ecma262'], 'test262': pins['test262_tree']}
            and outcomes == {'Success': len(controls) - 4, 'Bug': 4, 'Crash': 0, 'NotImplemented': 0},
            'actual known failure kind/detail signatures or outcomes differ from the published9b authority')
    evidence.add(baseline_path); evidence.add(reference_path)
    return dict(complete=True, total=len(results), passed=outcomes['Success'], bug=outcomes['Bug'],
                crash=outcomes['Crash'], not_implemented=outcomes['NotImplemented'], timeout=len(timeout_ids),
                outcomes=outcomes, actual_command_exit=receipt['exit_code'], scope=scopes,
                execution_ids=controls, compiler_identity=identity, pinned_fixtures=fixtures,
                failures=list(unique_failures.values()),
                known_failure_reference=dict(path=str(reference_relative), sha256=digest(reference_path),
                    published_baseline_checkpoint=str(baseline_path.relative_to(REPO)),
                    published_baseline_checkpoint_sha256=digest(baseline_path),
                    signatures=[list(row) for row in actual_signatures]),
                original_control_outcomes={row['execution_id']: row['outcome'] for row in results
                                           if row['execution_id'] in KNOWN},
                additional_non_success_executions=[row['execution_id'] for row in results
                                                  if row['outcome'] != 'Success' and row['execution_id'] not in KNOWN],
                native_snapshots=[dict(path=str(path.relative_to(BASE)), sha256=digest(path)) for path in snapshots],
                invocations=list(invocations.values()), full_test262_chart_refreshed=False,
                interpretation='Complete actual selected-family results, not a full pinned Test262 refresh; '
                               'all verdicts are rederived from actual native snapshots and saved execution receipts.')


PHASES = ('before_engine', 'after_engine', 'after_compilation', 'guest_start_1', 'guest_body_finished_1',
          'after_execution_1', 'after_dropping_profile_1', 'guest_start_2', 'guest_body_finished_2',
          'after_execution_2', 'after_dropping_profile_2', 'after_dropping_artifact', 'after_dropping_engine')
COUNTERS = ('requested_live_bytes', 'peak_tracked_requested_live_bytes', 'interval_peak_tracked_requested_live_bytes',
            'total_successful_request_bytes', 'total_released_request_bytes', 'alloc_calls', 'alloc_zeroed_calls',
            'realloc_calls', 'dealloc_calls')


def checked_u64(value):
    require(type(value) is int and 0 <= value < 2**64, 'invalid finite unsigned allocation/RSS counter')
    return value


def diagnostic(evidence, product, product_report):
    sys.path.insert(0, str(BASE))
    sys.path.insert(0, str(REPO / 'scripts'))
    from process_memory_maps import parse_smaps
    name = 'engine_allocation_diagnostic' if product == 'baseline' else 'candidate_engine_allocation_diagnostic'
    if product == 'baseline':
        spec = importlib.util.spec_from_file_location('original_9b_allocation_driver', HISTORY / (name + '.py'))
        module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    else:
        module = importlib.import_module(name)
    inputs, engine = module.validate_inputs()  # Pure: validates independent frozen bytes; invokes no product.
    directory = HISTORY / 'engine-allocation-probe' if product == 'baseline' else BASE / 'candidate-engine-allocation-probe'
    path = directory / 'report.json'
    report = read_json(path)
    identity = product_report[product]['compiler_identity']
    require(report.get('schema') == 'scriptw-engine-allocation-link-v1' and report.get('complete') is True
            and report.get('executed') is True and report.get('cpu_affinity') == [0]
            and report['source_commit'] == identity['source_revision']['commit']
            and report['source_fingerprint'] == identity['source_fingerprint'], 'allocation helper source/completion differs')
    source = ALLOCATION_HELPER
    driver = (HISTORY if product == 'baseline' else BASE) / (name + '.py')
    require(report['helper_source'] == dict(path=str(source), sha256=digest(source))
            and report['driver'] == dict(path=str(driver), sha256=digest(driver)), 'closed allocation source/driver changed')
    manifest = HISTORY / 'frozen-9b-link-inputs.json' if product == 'baseline' else BASE / 'frozen-candidate-link-inputs.json'
    require(report['frozen_inputs'] == dict(path=str(manifest), sha256=digest(manifest), **inputs),
            'actual frozen diagnostic inputs differ')
    require(tuple(module.PHASES) == PHASES and len(report['commands']) == 2, 'allocation protocol changed')
    binary = Path(report['binary']['path'])
    require(binary == directory / 'engine_allocation_diagnostic' and binary.stat().st_size == report['binary']['bytes']
            and digest(binary) == report['binary']['sha256'], 'actual allocation helper ELF changed')
    expected_compile = [report['rustc']['invoker_path'], '--edition=2021', '--crate-name=scriptw_engine_allocation_diagnostic',
                        '--crate-type=bin', '-Copt-level=3', '-Cdebuginfo=0', '-Ccodegen-units=1',
                        '-Ldependency=' + str(engine.parent)]
    expected_compile += ['-Lnative=' + str((HISTORY if product == 'baseline' else BASE) / item) for item in inputs['native_search_paths']]
    expected_compile += ['--extern', 'scriptw_engine=' + str(engine), str(source), '-o', str(binary)]
    for event, expected in zip(report['commands'], [[report['rustc']['invoker_path'], '-vV'], expected_compile]):
        require(event['command'] == expected and event['cwd'] == str(REPO)
                and event['state'] == 'closed' and event['exit_code'] == 0 and event['timed_out'] is False,
                'actual diagnostic link/version command differs')
        for stream in ['stdout', 'stderr']:
            raw = directory / event[stream + '_file']
            require(raw.parent == directory and digest(raw) == event[stream + '_sha256'], 'diagnostic command stream changed')
            evidence.add(raw)
    require((directory / 'rustc-version.stdout').read_text() == report['rustc']['version'], 'diagnostic rustc version differs')
    require([case['case'] for case in report['cases']] == ['scalar', 'print', 'retained'], 'diagnostic case inventory differs')
    cases, count = [], 0
    for case in report['cases']:
        case_name = case['case']
        expected = list(PHASES) if case_name != 'scalar' else [phase for phase in PHASES if not phase.startswith('guest_')]
        require(case['state'] == 'closed' and case['exit_code'] == 0 and case['command'] == [str(binary), case_name],
                'actual allocation case failed/changed command')
        observation = case['observation']
        require(observation['schema'] == 'scriptw-engine-requested-allocation-diagnostic-v1'
                and observation['case'] == case_name and observation['compiler_source'] == report['source_commit']
                and observation['source_fingerprint'] == report['source_fingerprint']
                and observation['helper_executable_sha256'] == report['binary']['sha256']
                and observation['invocations'] == 2 and observation['linked_runtime'] == (case_name != 'scalar'),
                'actual allocation helper/body identity differs')
        require([row['phase'] for row in observation['snapshots']] == expected
                and [row['phase'] for row in case['snapshots']] == expected, 'allocation/maps boundaries differ')
        stdout, stderr = directory / case_name / 'stdout.log', directory / case_name / 'stderr.log'
        require(digest(stdout) == case['stdout_sha256'] and digest(stderr) == case['stderr_sha256'],
                'actual allocation case stream changed')
        lines = stdout.read_text().splitlines()
        require(lines[:-1] == ['SNAP ' + phase for phase in expected] and lines[-1].startswith('RESULT ')
                and json.loads(lines[-1][7:]) == observation, 'raw callbacks/final result differ')
        evidence.add(stdout)
        evidence.add(stderr)
        phases = []
        previous = None
        for counters, mapping in zip(observation['snapshots'], case['snapshots']):
            for field in COUNTERS:
                checked_u64(counters[field])
            require(counters['total_successful_request_bytes'] - counters['total_released_request_bytes']
                    == counters['requested_live_bytes']
                    and counters['peak_tracked_requested_live_bytes'] >= counters['requested_live_bytes']
                    and counters['interval_peak_tracked_requested_live_bytes'] >= counters['requested_live_bytes'],
                    'actual requested/released/live/peak counters do not reconcile')
            if previous is not None:
                require(all(counters[field] >= previous[field] for field in COUNTERS
                            if field not in ['requested_live_bytes', 'interval_peak_tracked_requested_live_bytes']),
                        'cumulative allocation counters decreased')
            previous = counters
            cache = counters['module_cache']
            require(cache['entry_limit'] == 1 and cache['image_byte_limit'] == 64 * 1024**2
                    and 0 <= cache['retained_entries'] <= 1 and 0 <= cache['retained_image_bytes'] <= 64 * 1024**2,
                    'actual diagnostic cache policy changed')
            raw = directory / mapping['raw']
            require(raw.resolve().is_relative_to(directory.resolve()) and digest(raw) == mapping['raw_sha256'],
                    'raw smaps path/hash changed')
            parsed = parse_smaps(raw.read_text())
            require(all(mapping[field] == parsed[field] for field in ['scope', 'totals', 'groups', 'mappings']),
                    'saved smaps differs from actual raw mapping counters')
            evidence.add(raw)
            phases.append(dict(phase=counters['phase'], allocation=counters, residency=parsed['totals'],
                               groups=parsed['groups'], raw_smaps=member_path(raw), raw_smaps_sha256=digest(raw)))
            count += 1
        cases.append(dict(case=case_name, phases=phases, program_wasm_bytes=observation['program_wasm_bytes'],
                          runtime_wasm_bytes=observation['runtime_wasm_bytes'], linked_runtime=observation['linked_runtime'],
                          counter_scope=observation['counter_scope'], peak_scope=observation['peak_scope']))
    require(count == 35, 'each actual helper must contain all35 closed allocation/residency pairs')
    outer = None
    if product == 'candidate':
        outer, _ = evidence.receipt('allocation-diagnostic-candidate')
        require(Path(outer['command'][-2]).resolve() == driver and outer['command'][-1] == '--run',
                'candidate outer allocation command differs')
    else:
        require(not (HISTORY / 'allocation-diagnostic-baseline.json').exists(),
                'baseline outer receipt authority changed; review new observation explicitly')
        log = HISTORY / 'allocation-diagnostic-baseline.log'
        text = log.read_text()
        require('confirmed kernel memory cap 4096 MiB' in text and report['binary']['sha256'] in text,
                'baseline saved console provenance differs')
        evidence.add(log)
    for item in [path, manifest, driver, source, HISTORY / 'CANDIDATE-ALLOCATION-DIAGNOSTIC.md']:
        evidence.add(item)
    # All large rlibs/native archives/ELFs remain hash-only. Cargo producers and
    # input hashes are already retained in these closed report/manifest files.
    return dict(complete=True, source_commit=report['source_commit'], source_fingerprint=report['source_fingerprint'],
                helper_executable_sha256=report['binary']['sha256'], helper_source_sha256=digest(source),
                driver_sha256=digest(driver), report=dict(path=member_path(path), sha256=digest(path)),
                frozen_inputs=dict(path=member_path(manifest), sha256=digest(manifest), engine_rlib_sha256=inputs['engine_rlib_sha256']),
                phase_count=count, outer_resource_receipt=outer,
                outer_resource_scope='Actual closed candidate receipt.' if outer else
                    'No saved baseline outer JSON receipt. Original limited-verification console confirmation retained; '
                    'no fabricated cgroup peak, source receipt or retroactive accepted-resource claim.', cases=cases)


def allocation_comparison(evidence, product_report):
    products_ = {role: diagnostic(evidence, role, product_report) for role in ['baseline', 'candidate']}
    require(products_['baseline']['helper_source_sha256'] == products_['candidate']['helper_source_sha256'],
            'comparison does not use byte-identical helper body/callbacks')
    comparisons = []
    for before, after in zip(products_['baseline']['cases'], products_['candidate']['cases']):
        require(before['case'] == after['case'], 'allocation comparison case changed')
        phases = []
        for a, b in zip(before['phases'], after['phases']):
            require(a['phase'] == b['phase'], 'allocation comparison phase changed')
            values = {}
            for field, old, new in [
                ('requested_live_bytes', a['allocation']['requested_live_bytes'], b['allocation']['requested_live_bytes']),
                ('peak_tracked_requested_live_bytes', a['allocation']['peak_tracked_requested_live_bytes'], b['allocation']['peak_tracked_requested_live_bytes']),
                ('rss_bytes', a['residency']['rss_bytes'], b['residency']['rss_bytes']),
                ('pss_bytes', a['residency']['pss_bytes'], b['residency']['pss_bytes']),
            ]:
                values[field] = dict(baseline=old, candidate=new, delta=new - old,
                                     change_percent=(new / old - 1) * 100 if old else None)
            phases.append(dict(phase=a['phase'], metrics=values))
        comparisons.append(dict(case=before['case'], phases=phases))
    return dict(schema='scriptw-engine-allocation-comparison-v1', complete=True, products=products_,
                paired_phase_count=35, raw_snapshot_count=70, cases=comparisons,
                scope='One distinct standalone helper process per product/case, two invocations, identical source/callbacks; '
                      'diagnostic requested Rust bytes and acknowledged process residency, not ordinary performance scores.',
                caveats=['Requested Rust GlobalAlloc sizes exclude allocator usable/resident bytes and native allocations bypassing GlobalAlloc.',
                         'Anonymous mappings do not identify live JavaScript or Intl ownership; no exact causal subtraction between counters.',
                         'Private file-backed native mappings change residency/reclaimability; cold-file/page-cache state and shared pages affect RSS/PSS.',
                         'Baseline has no saved outer JSON cap receipt; original console policy confirmation remains explicit.',
                         'One-entry/64MiB module cache cannot retain the full R image; default SDK512MiB retention differs.',
                         'Native perf-map hashing is disabled. RSS/capacity/virtual address space, logical requested peaks and guest live memory remain distinct.'])


def allocation_markdown(report):
    lines = ['# Fixed runtime allocation diagnostic comparison', '', report['scope'], '',
             'Each value is MiB (1,048,576 bytes). Every phase pair comes from the actual closed helper reports; '
             'this table is separate from ordinary README benchmark scores.', '',
             '| Case / phase | Requested Rust live before → after | Process RSS before → after | RSS change |',
             '| --- | ---: | ---: | ---: |']
    for case in report['cases']:
        for phase in case['phases']:
            live, rss = phase['metrics']['requested_live_bytes'], phase['metrics']['rss_bytes']
            lines.append(f"| {case['case']} / {phase['phase']} | {live['baseline']/2**20:.3f} → {live['candidate']/2**20:.3f} | "
                         f"{rss['baseline']/2**20:.3f} → {rss['candidate']/2**20:.3f} | {rss['change_percent']:+.2f}% |")
    lines += ['', 'The complete 35 phase pairs retain raw smaps, coherent requested/released/live counters, both invocations, '
              f"source/rlib/helper hashes and all commands. Baseline source is{report['products']['baseline']['source_commit']}; "
              f"candidate source is{report['products']['candidate']['source_commit']}. "
              'The helper source is byte-identical. All reductions remain observational; the counters do not by themselves '
              'assign each saved page or allocation to a component.', '']
    lines.extend('- ' + caveat for caveat in report['caveats'])
    return '\n'.join(lines) + '\n'


def tooling(evidence):
    """Retain actual red source checks, including their exact committed control."""
    path = BASE / 'module-boundaries-final-current-comparison.json'
    comparison = read_json(path)
    committed = read_json(BASE / 'campaign.json')['source_commit']
    require(subprocess.check_output(['git', 'rev-parse', committed + '^{commit}'], cwd=REPO, text=True).strip() == committed,
            'source-tooling campaign commit is unavailable')
    require(comparison['current_source'] == committed and comparison['full_tooling_passed'] is False
            and comparison['new_observed_prefixed_failure_lines'] == []
            and comparison['terminal_exactly_reproduces_committed_baseline'] is True,
            'source-tooling comparison changed; never promote it to full tooling green')
    baseline_path = HISTORY / 'baseline-source-guards-complete.json'
    baseline = read_json(baseline_path)
    current_path = BASE / 'module-boundaries-final-current.json'
    current = read_json(current_path)
    for item in comparison['receipts']:
        actual_path = Path(item['path']) if 'path' in item else observation_path(item['file'])
        require(actual_path.resolve().is_relative_to(REPO) and digest(actual_path) == item['sha256'],
                'tooling control receipt hash changed')
        evidence.add(actual_path)
    for row, prefix, owner in [(baseline, 'baseline', baseline_path.parent), (current, 'current', current_path.parent)]:
        require(row['exit_code'] == 1 and row['cpu_affinity'] == [0]
                and row['source_head'] == comparison[prefix + '_source'], 'source guard control identity differs')
        if prefix == 'baseline':
            require(row['source_patch_sha256'] == EMPTY_PATCH, 'committed baseline source control was dirty')
        else:
            manifest_path = BASE / row['input_manifest']
            manifest = read_json(manifest_path)
            dirty = ['docs/rust-rewrite/contracts/performance-history.md', 'scripts/execution_chart_data.py',
                     'scripts/render-execution-performance.py']
            require(digest(manifest_path) == row['input_manifest_sha256']
                    and manifest['schema'] == 'scriptw-source-guard-input-manifest-v1'
                    and manifest['source_head'] == committed and manifest['stable_after_command'] is True
                    and row['input_manifest_stable_before_after'] is True
                    and row['source_patch_sha256'] == row['source_patch_sha256_after']
                    and row['source_head'] == row['source_head_after']
                    and manifest['files_sha256'] == row['actual_source_files_sha256']
                    and row['working_files_different_from_head'] == manifest['working_files_different_from_head'] == dirty,
                    'actual aggregate source snapshot or explicit graph/documentation differences changed')
            evidence.add(manifest_path)
        log = owner / row['log']
        require(log.parent == owner and digest(log) == row['log_sha256'], 'source guard transcript changed')
        failures = [line for line in log.read_text().splitlines() if line.startswith('check-module-boundaries:')]
        require(failures == row['guard_failures'] and len(failures) == row['guard_failure_count']
                == comparison[prefix + '_aggregate_prefixed_failures'], 'source guard failure inventory changed')
        evidence.add(log)
    require(set(current['guard_failures']) <= set(baseline['guard_failures'])
            and current['new_exact_failure_lines'] == [], 'new source guard failure cannot be called preexisting')
    terminal = []
    for role in ['baseline', 'current']:
        control_path = (HISTORY if role == 'baseline' else BASE) / ('native-template-' + role + '-source-control-final.json')
        control = read_json(control_path)
        require(control['source_head'] == comparison[role + '_source'] and control['exit_code'] == 1
                and control['source_files_verified_against_git'] == 74
                and control['cpu_affinity'] == [0], 'isolated terminal source control differs')
        if role == 'baseline':
            require(control['source_patch_sha256'] == EMPTY_PATCH, 'baseline isolated control was dirty')
        else:
            manifest_path = BASE / control['source_inputs']
            manifest = read_json(manifest_path)
            require(digest(manifest_path) == control['source_inputs_sha256']
                    and manifest['source_head'] == committed and manifest['source_files_verified_against_git'] == 74
                    and control['read_source_differs_from_head'] == []
                    and manifest['files_sha256'] == control['source_files_sha256'],
                    'isolated current read sources must match all74 committed inputs')
            evidence.add(manifest_path)
        log = control_path.parent / control['log']
        require(log.parent == control_path.parent and digest(log) == control['log_sha256']
                and log.read_text().splitlines() == control['diagnostic_lines'] == comparison['terminal_diagnostic'],
                'isolated terminal control transcript changed')
        evidence.add(control_path); evidence.add(log)
        terminal.append(control)
    require(terminal[0]['guard_script_sha256'] == terminal[1]['guard_script_sha256']
            == digest(REPO / 'scripts/check-native-program-templates.py'), 'terminal source guard script changed')
    script = REPO / 'scripts/check-native-program-templates.py'
    spec = importlib.util.spec_from_file_location('fixed_memory_native_template_source_guard', script)
    guard = importlib.util.module_from_spec(spec); spec.loader.exec_module(guard)
    require(len(guard.FILES) == len(set(guard.FILES)) == 73, 'terminal source-input inventory changed')
    for role, control in zip(['baseline', 'current'], terminal):
        names = [*guard.FILES, 'scripts/check-native-program-templates.py']
        git_sources = git_blob_sources(control['source_head'], names)
        require(hashlib.sha256(git_sources['scripts/check-native-program-templates.py']).hexdigest()
                == control['guard_script_sha256'], 'recorded source guard differs from its exact Git blob')
        actual = guard.check({name: git_sources[name].decode() for name in guard.FILES})
        require(['native program templates: ' + name for name in actual] == control['diagnostic_lines'],
                'terminal diagnostic does not reproduce from the actual74 committed source blobs')
        evidence.add_bytes('tooling/native-template-' + role + '-git-inputs.json', (json.dumps(dict(
            source_commit=control['source_head'], source_files=[dict(path=name, sha256=hashlib.sha256(git_sources[name]).hexdigest())
                for name in names], guard_script_sha256=control['guard_script_sha256'], actual_diagnostic_lines=control['diagnostic_lines']), indent=2) + '\n').encode())
    evidence.add(REPO / 'scripts/check-native-program-templates.py')
    evidence.add(path); evidence.add(baseline_path); evidence.add(current_path)
    return dict(complete=True, full_tooling_passed=False, comparison=comparison,
                interpretation='Aggregate source guard remains exit1. All9 current prefixed failures are exact members of '
                               'the18 committed-baseline failures; the separately isolated terminal failure also reproduces '
                               'the exact baseline. The stable aggregate input manifest records three pending graph/documentation '
                               'edits explicitly; all74 isolated read inputs match the committed source. '
                               'This is no-new-observed-diagnostic evidence, not full tooling acceptance.')


def git_blob_sources(source, names):
    """Read a bounded explicit source inventory in one read-only Git batch."""
    request = ''.join(source + ':' + name + '\n' for name in names).encode()
    process = subprocess.run(['git', 'cat-file', '--batch'], cwd=REPO, input=request,
                             stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True)
    raw, offset, sources = process.stdout, 0, {}
    require(len(raw) <= 8 * 1024**2, 'explicit source-control blob inventory exceeds8MiB')
    for name in names:
        end = raw.index(b'\n', offset)
        header = raw[offset:end].split()
        require(len(header) == 3 and header[1] == b'blob', 'source-control input is missing or not a Git blob')
        size = int(header[2]); start = end + 1
        data = raw[start:start + size]
        require(len(data) == size and raw[start + size:start + size + 1] == b'\n', 'source-control blob batch is truncated')
        sources[name] = data; offset = start + size + 1
    require(offset == len(raw), 'extra source-control blob output')
    return sources


def extra_acceptance(evidence, native_report):
    expected_focus = {row[0] for row in focused_checks()}
    require({Path(row['receipt']).stem for row in native_report['focused']} == expected_focus,
            'actual eleven nonzero focused regression groups are incomplete')
    doc, log = evidence.receipt('trust-token-doctest')
    expected = ['cargo', 'test', '--locked', '--offline', '--release', '--jobs', '1', '-p', 'scriptw-intl-build-data', '--doc']
    require(doc['command'] == expected and SUMMARY_RE.findall(log) == [('ok', '1', '0', '0', '0', '0')]
            and len(observed_names(log)) == 1 and all(status == 'ok' for _, status in observed_names(log)),
            'authority-token compile-fail doctest is not the actual nonzero passed control')
    built, _ = evidence.receipt('embedding-examples-build')
    require(built['command'] == ['cargo', 'build', '--locked', '--offline', '--release', '--jobs', '1', '-p', 'scriptw-engine',
                                 '--example', 'foreign_modules', '--example', 'retained_embedding'],
            'real embedding examples were not built under the ordinary default profile')
    examples = []
    for name in ['foreign_modules', 'retained_embedding']:
        row, output = evidence.receipt('example-' + name)
        require(len(row['command']) == 1 and Path(row['command'][0]).name == name and len(row['executables']) == 1
                and Path(row['executables'][0]['path']).resolve() == Path(row['command'][0]).resolve(),
                'actual real embedding example identity differs')
        examples.append(dict(name=name, receipt='example-' + name + '.json', executable=row['executables'][0],
                             stdout=output, added_to_native_target_total=False))
        evidence.add(REPO / 'crates/scriptw-engine/examples' / (name + '.rs'))
    for name in ['focused_acceptance.py', 'extra_acceptance.py', 'finish_campaign.py']:
        evidence.add(BASE / name)
    return dict(complete=True, trust_token_doctest=dict(passed=1, receipt='trust-token-doctest.json',
                added_to_native_target_total=False), embedding_examples=examples,
                focused_overlaps='All eleven actual nonzero filters overlap the31 complete target identities; never added again.')


def focused_checks():
    """Read the literal final plan; importing that executable would run Cargo."""
    tree = ast.parse((BASE / 'focused_acceptance.py').read_text())
    definitions = [node.value for node in tree.body if isinstance(node, ast.Assign)
                   and any(isinstance(target, ast.Name) and target.id == 'checks' for target in node.targets)]
    require(len(definitions) == 1, 'focused plan is not one explicit literal check list')
    checks = ast.literal_eval(definitions[0])
    original = {'focused-runtime-admission', 'focused-string-descriptors', 'focused-string-bootstrap',
                'focused-lazy-intl', 'focused-native-backing', 'focused-native-admission', 'focused-intl-compilation'}
    regexp = {'focused-regexp-program-data', 'focused-regexp-r-prefix', 'focused-regexp-oom-case',
              'focused-regexp-corruption-boundary'}
    require(isinstance(checks, list) and len(checks) == 11 and all(len(row) == 4 for row in checks)
            and {row[0] for row in checks} == original | regexp
            and all('regexp' in (row[0] + row[3]).lower() for row in checks if row[0] not in original),
            'complete eleven-group plan must retain seven original groups and four RegExp regressions')
    return checks


def code_size(evidence, product_report):
    """Admit deliberately faulted native maps as code-size evidence only."""
    sys.path.insert(0, str(REPO / 'scripts'))
    from process_memory_maps import parse_smaps
    from profile_memory_maps import native_ranges, prepare_case
    outer, _ = evidence.receipt('candidate-code-size')
    require(any(Path(part).name == 'profile_memory_maps.py' for part in outer['command']), 'code-size observer command differs')
    directory = BASE / 'candidate-code-size-data'
    path = directory / 'report.json'
    report = read_json(path)
    identity = product_report['candidate']['compiler_identity']
    require(report['schema'] == 'scriptw-process-memory-maps-v1' and report['complete'] is True
            and report['samples'] == 3 and report['warmups'] == 1 and report['cpu_affinity'] == [0]
            and report['runner_sha256'] == product_report['candidate']['runtime_runner_sha256']
            and report['runner'] == str(BASE / 'candidate/runtime_baseline')
            and [row['file'] for row in report['cases']] == ['startup.js'], 'code-size source/sampling cohort differs')
    case = report['cases'][0]
    fixtures = REPO / 'crates/scriptw-cli/tests/fixtures/v8_execution_hotpaths'
    original = read_json(fixtures / 'manifest.json')['startup']
    source, expected = prepare_case((fixtures / 'startup.js').read_text(), original['stdout'])
    require((directory / 'fixtures/startup.js').read_text() == source
            and report['sources'] == [dict(file='startup.js', original_path=str(fixtures / 'startup.js'),
                                          original_sha256=digest(fixtures / 'startup.js'),
                                          source_sha256=digest(directory / 'fixtures/startup.js'))], 'code-size workload transform changed')
    require(case['exit_code'] == 0 and case['compiler_source'] == candidate_source()
            and case['source_fingerprint'] == identity['source_fingerprint']
            and case['runner_sha256'] == report['runner_sha256'] and len(case['observations']) == 6,
            'actual code-size observer identity/boundary count differs')
    child_dir = directory / 'startup.js'
    stdout = child_dir / 'stdout.json'
    child = read_json(stdout)
    require(digest(stdout) == case['stdout_sha256'] and digest(child_dir / 'stderr.log') == case['stderr_sha256']
            and child['source_commit'] == candidate_source() and child['source_fingerprint'] == identity['source_fingerprint']
            and child['executable_sha256'] == report['runner_sha256']
            and child['samples'] == 3 and child['warmups'] == 1
            and len(child['cases']) == 1 and len(child['cases'][0]['observations']) == 4
            and all(row['stdout'] == expected for row in child['cases'][0]['observations']),
            'actual observer stdout/output/provenance differs')
    raw_program = child_dir / 'artifacts/startup.js.wasm'
    require(raw_program.stat().st_size == child['cases'][0]['wasm_bytes']
            and digest(raw_program) == child['cases'][0]['wasm_sha256'], 'actual observer raw P payload differs')
    evidence.add(stdout); evidence.add(child_dir / 'stderr.log')
    text_sizes = {'R': set(), 'P': set()}
    function_sizes = {}
    identities = []
    for index, observation in enumerate(case['observations']):
        sample, phase = divmod(index, 2)
        label = 'guest-start' if phase == 0 else 'guest-body-finished'
        require(observation['sample'] == sample and observation['phase'] == label, 'code-size boundary ordering differs')
        raw = child_dir / observation['raw']
        require(raw.parent == child_dir and digest(raw) == observation['raw_sha256'], 'code-size raw smaps changed')
        parsed = parse_smaps(raw.read_text())
        require(all(parsed[field] == observation[field] for field in ['scope', 'totals', 'groups', 'mappings']),
                'code-size raw map accounting differs')
        native_map = child_dir / observation['native_map']
        require(native_map.parent == child_dir and digest(native_map) == observation['native_map_sha256'], 'native perf map changed')
        native_identity = child_dir / (f'{sample:02}-' + label + '.native-identity')
        text = native_identity.read_text()
        require(text.startswith(f"scriptw-perf-map-v1 pid={observation['pid']} ")
                and 'map_sha256=' + observation['native_map_sha256'] + '\n' in text,
                'actual native map identity/PID changed')
        ranges = native_ranges(text)
        require(ranges == observation['native_ranges'], 'actual R/P text ranges differ')
        for region in ranges:
            text_sizes[region['module']].add(region['end'] - region['start'])
            if region['module'] == 'P':
                require(region['wasm_sha256'] == child['cases'][0]['wasm_sha256'], 'observed native P belongs to another Wasm')
            else:
                require(region['wasm_sha256'] == child['cases'][0]['linked_runtime']['wasm_sha256'], 'observed native R belongs to another Wasm')
        for symbol, size in native_function_sizes(native_map.read_text(), ranges).items():
            function_sizes.setdefault(symbol, set()).add(size)
        identities.append(dict(sample=sample, phase=label, native_ranges=ranges,
                               identity_sha256=digest(native_identity), native_map_sha256=digest(native_map)))
        for item in [raw, native_map, native_identity]: evidence.add(item)
    require(all(len(values) == 1 for values in text_sizes.values()), 'same observer module text extent changed')
    evidence.add(path); evidence.add(directory / 'fixtures/startup.js'); evidence.add(directory / 'fixtures/manifest.json')
    evidence.add(REPO / 'scripts/profile_memory_maps.py')
    # Prior accepted mapping report is preserved under actual9b identity. Only
    # native text extents/identities are compared, never its instrumented RSS.
    old_path = REPO / 'target/memory-execution-20261025/candidate-maps-round-b-data/report.json'
    old = read_json(old_path)
    published_old = read_json(REPO / 'docs/rust-rewrite/execution-memory-20261025.json')
    require(published_old['complete'] is True and published_old['source_commit'] == BASELINE_SOURCE,
            'prior native size authority is not the actual published9b checkpoint')
    published_round = next(row for row in published_old['memory_maps']['rounds'] if row['label'] == 'candidate-maps-round-b')
    old_archive = REPO / 'docs/rust-rewrite' / published_old['archive']['file']
    require(digest(old_archive) == published_old['archive']['sha256'], 'prior native size archive changed')
    prefix = old_archive.name.removesuffix('.tar.gz') + '/'
    with tarfile.open(old_archive, 'r:gz') as bundle:
        manifest_bytes = bundle.extractfile(prefix + 'archive-members.json').read()
        require(hashlib.sha256(manifest_bytes).hexdigest() == published_old['archive']['manifest_sha256'],
                'prior native size archive manifest changed')
        manifest = json.loads(manifest_bytes)
        require(manifest['source_commit'] == BASELINE_SOURCE, 'prior native size manifest source differs')
        declared = next(row for row in manifest['members'] if row['path'] == prefix + 'candidate-maps-round-b-data/report.json')
        require(declared['bytes'] == old_path.stat().st_size and declared['sha256'] == digest(old_path),
                'prior raw native size report differs from its published archive')
    # The earlier publisher added two derived fields to its in-memory copy.
    # Reconstruct exactly that admitted view; the raw JSON remains unchanged.
    old_derived_cases = []
    for old_case_row in old['cases']:
        case_directory = old_path.parent / old_case_row['file']
        old_stdout, old_stderr = case_directory / 'stdout.json', case_directory / 'stderr.log'
        require(digest(old_stdout) == old_case_row['stdout_sha256']
                and digest(old_stderr) == old_case_row['stderr_sha256'],
                'prior native size raw child streams changed')
        old_child = read_json(old_stdout)
        require(old_child['source_commit'] == BASELINE_SOURCE
                and old_child['executable_sha256'] == product_report['baseline']['runtime_runner_sha256']
                and len(old_child['cases']) == 1 and old_child['cases'][0]['file'] == old_case_row['file'],
                'prior native size child source/runner/case differs')
        linked = old_child['cases'][0]['linked_runtime']
        native_lengths = sorted({int(value) for value in re.findall(
            r'runtime-native-bundle hit: (\d+) bytes \(runtime: size-optimized, execution: fast, source: Portable\)',
            old_stderr.read_text())})
        require(native_lengths and all(value > 0 for value in native_lengths) and linked['wasm_bytes'] > 0,
                'prior native size child lacks actual decoded-native/runtime lengths')
        old_derived_cases.append(dict(old_case_row, actual_portable_native_image_bytes=native_lengths,
                                      actual_runtime_wasm_bytes=linked['wasm_bytes']))
        evidence.add(old_stdout); evidence.add(old_stderr)
    require(published_round['report'] == dict(old, cases=old_derived_cases),
            'prior derived native size report differs from its published authority')
    require(old['complete'] is True and old['runner_sha256'] == product_report['baseline']['runtime_runner_sha256'],
            'prior actual9b mapped observer differs')
    old_case = next(row for row in old['cases'] if row['file'] == 'startup.js')
    old_sizes = {module: sorted({r['end'] - r['start'] for row in old_case['observations']
                               for r in row['native_ranges'] if r['module'] == module}) for module in ['R', 'P']}
    require(all(len(values) == 1 for values in old_sizes.values()), 'prior native text sizes differ across samples')
    first = old_case['observations'][0]
    old_map = old_path.parent / 'startup.js' / first['native_map']
    require(digest(old_map) == first['native_map_sha256'], 'prior actual native function map changed')
    baseline_functions = native_function_sizes(old_map.read_text(), first['native_ranges'])
    require(all(len(sizes) == 1 for sizes in function_sizes.values()), 'native named function size changed across observer samples')
    functions = {}
    for name in ['R:helper::pooled_strings_initialize', 'R:helper::realm_initialize_intrinsics']:
        before, after = baseline_functions.get(name), function_sizes.get(name)
        after = next(iter(after)) if after else None
        functions[name] = dict(baseline_bytes=before, candidate_bytes=after,
                               delta=after - before if before is not None and after is not None else None,
                               change_percent=(after / before - 1) * 100 if before and after is not None else None)
    evidence.add(old_map)
    evidence.add(old_path)
    return dict(complete=True, instrumented=True, ordinary_rss_eligible=False, measured_source=candidate_source(),
                native_text_bytes={module: next(iter(values)) for module, values in text_sizes.items()},
                baseline_native_text_bytes={module: values[0] for module, values in old_sizes.items()}, identities=identities,
                named_native_function_sizes=functions,
                report=dict(path=member_path(path), sha256=digest(path)),
                interpretation='Size attribution only: SCRIPTW_PERF_MAP_DIR hashes/faults full Module.text(), so all RSS and timing '
                               'observations here are excluded from ordinary scores/graph. Native text hashes may differ after relocation. '
                               'Generated large raw Wasm artifacts are excluded; actual P/R lengths and SHA values remain in child stdout.')


def native_function_sizes(text, ranges):
    """Read actual symbol intervals without interpreting/touching native code."""
    by_module = {row['module']: row for row in ranges}
    found = {}
    for line in text.splitlines():
        match = re.fullmatch(r'([0-9a-f]+) ([0-9a-f]+) scriptw:(R|P):f([0-9]+):(.*)', line)
        require(match is not None, 'unrecognized native perf-map row')
        address, size, module, index, name = match.groups()
        address, size = int(address, 16), int(size, 16)
        region = by_module[module]
        require(size > 0 and region['start'] <= address <= address + size <= region['end'],
                'native symbol interval escaped its actual module text')
        if name in ['helper::pooled_strings_initialize', 'helper::realm_initialize_intrinsics']:
            key = module + ':' + name
            require(key not in found, 'named helper is not unique in the native map')
            found[key] = size
    return found


def intl_first_use(evidence, product_report):
    """Separate first-operation evidence; never append to either scored corpus."""
    sys.path.insert(0, str(BASE))
    import analyze_intl_first_use as analysis
    actual = analysis.build_report()
    require(actual['schema'] == 'scriptw-intl-first-use-analysis-v1' and actual['complete'] is True
            and actual['excluded_from_scored_cohorts'] is True and actual['campaign_source'] == candidate_source()
            and actual['samples'] == 7 and actual['warmups'] == 10,
            'separate Intl first-use cohort completion/source/denominator differs')
    require(read_json(analysis.ANALYSIS) == actual, 'saved Intl first-use analysis differs from raw rederivation')
    outer, _ = evidence.receipt('intl-first-use')
    require(digest(BASE / 'intl-first-use.json') == actual['receipt_sha256'], 'Intl diagnostic outer receipt differs')
    rows = []
    for product in ['baseline', 'candidate']:
        observed = actual['products'][product]
        require(observed['compiler_identity'] == product_report[product]['compiler_identity'],
                'Intl diagnostic product differs from the exact frozen campaign identity')
        for runtime in ['wasmtime', 'v8']:
            values = observed['runtimes'][runtime]
            first, steady = values['first_warmup'], values['steady']
            require(first['observation_index'] == 0 and first['warmup'] is True
                    and len(values['remaining_warmups']) == 9 and len(steady['observations']) == 7
                    and steady['observation_indices'] == list(range(10, 17)),
                    'first-use and steady observations were mixed or omitted')
            rows.append(dict(product=product, runtime=runtime, first_warmup=first,
                             steady_summary=steady['summary'], scored_case_count_contribution=0))
    evidence.add(analysis.ANALYSIS)
    for path in analysis.evidence_files(): evidence.add(path)
    return dict(complete=True, excluded_from_scored_cohorts=True, scored_case_count_contribution=0,
                observations=actual, table=rows,
                interpretation='One separate Intl.NumberFormat fixture per fresh child process; first warmup and seven steady '
                               'observations remain outside both17-case scored cohorts. The first-use endpoint change includes '
                               'runtime mapping/setup and provider/process state; it is not an isolated provider heap counter '
                               'or an exact causal subtraction. Full provider construction on first use can still retain host data.')


def regexp_memory(evidence, product_report):
    """An exact repeated native case, outside acceptance/performance denominators."""
    driver = BASE / 'regexp-native-memory-proof.py'
    spec = importlib.util.spec_from_file_location('regexp_native_memory_proof', driver)
    analysis = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(analysis)
    actual = analysis.build_report()
    require(actual['schema'] == 'scriptw-regexp-native-memory-analysis-v1' and actual['complete'] is True
            and actual['source_commit'] == candidate_source()
            and actual['compiler_identity'] == product_report['candidate']['compiler_identity']
            and actual['excluded_from_scored_cohorts'] is True
            and actual['additional_native_cases_counted'] == 0
            and actual['native_target_count'] == 31 and actual['cold_cache'] is True,
            'separate native RegExp memory proof identity/count/scope differs')
    require(read_json(analysis.ANALYSIS) == actual, 'saved native RegExp memory analysis differs from raw rederivation')
    evidence.receipt(analysis.LABEL)
    require(digest(BASE / (analysis.LABEL + '.json')) == actual['receipt_sha256'],
            'native RegExp memory proof outer receipt differs')
    evidence.add(analysis.ANALYSIS)
    for path in analysis.evidence_files(): evidence.add(path)
    return dict(complete=True, excluded_from_scored_cohorts=True, scored_case_count_contribution=0,
                additional_native_cases_counted=0, observation=actual,
                interpretation='One exact already-accepted RegExp native case is repeated in a fresh process with a new '
                               'empty Scriptw disk cache; the OS page cache is not flushed. GNU time1.9 reports the actual '
                               'child-process high-water RSS, including its in-process compilation and execution, without '
                               'Cargo/LLVM build work. The earlier356d aggregate and isolated4GiB cgroup OOM kills remain '
                               'development failures; their compile-inclusive cgroup peaks are different accounting scopes. '
                               'This proof adds no cases to the31-target native total or either17-case performance cohort.')


def development_history(evidence):
    """Preserve real356d results and failures without promoting them to final acceptance."""
    original_source = '356d1dc7bbbf507b363ec9411148e4c008d4e084'
    failure_path = HISTORY / 'regexp-resource-failure-observations.json'
    failures = read_json(failure_path)
    require(failures['source_commit'] == original_source and failures['aggregate_prefix_is_not_final_accepted_union'] is True,
            'earlier resource-failure authority changed')
    native_path = HISTORY / 'native-closed.json'
    partial_native = read_json(native_path)
    targets = partial_native['targets']
    total = sum(len(row['inventory']) for row in targets)
    require(partial_native['source'] == original_source and partial_native['complete'] is False
            and total == partial_native['total'] == failures['native_accepted_prefix']['passed']
            and len(targets) == failures['native_accepted_prefix']['targets'],
            'earlier actual native prefix changed or was relabelled complete')
    aggregate_path = HISTORY / 'broad-25-scriptw-engine-aot_regexp.log'
    aggregate = aggregate_path.read_text()
    prefix = observed_names(aggregate)
    require(len(prefix) == failures['aggregate_completed_case_prefix']
            and all(status == 'ok' for _, status in prefix) and SUMMARY_RE.findall(aggregate) == []
            and failures['active_case'] in aggregate.splitlines()[-1],
            'earlier failed aggregate prefix/unfinished case changed')
    require(len(failures['observations']) == 2, 'both original OOM attempts must remain visible')
    for observation in failures['observations']:
        journal = HISTORY / observation['journal']
        text = journal.read_text()
        require(journal.parent == HISTORY and digest(journal) == observation['journal_sha256']
                and observation['unit'] in text and "result 'oom-kill'" in text
                and observation['kernel_oom_confirmed'] is True
                and observation['kernel_limit_bytes'] == BUDGET
                and observation['actual_launcher_exit'] == 137
                and observation['run_check_terminal_receipt_exists'] is False,
                'own-scope historical OOM observation changed')
    rejection_path = HISTORY / 'cleanup-auto-review-rejection.json'
    rejection = read_json(rejection_path)
    require(rejection['source_commit'] == original_source and rejection['deletions_performed'] == 0
            and rejection['earlier_actual_attempts_deleted_files'] == 0
            and 'rejected' in rejection['approval_review'] and 'beforeprocesslaunch' in rejection['approval_review'],
            'abandoned cleanup review/action history changed')
    cache_change_path = HISTORY / 'external-build-cache-disappearance.json'
    cache_change = read_json(cache_change_path)
    require(cache_change['schema'] == 'scriptw-external-build-cache-disappearance-observation-v1'
            and cache_change['cache_deletions_performed_by_assistant'] == 0
            and len(cache_change['actual_attempts']) == 3 and cache_change['all_preserved_dirs_exist'] is True,
            'external cache disappearance observation changed')
    for attempt in cache_change['actual_attempts']:
        record = read_json(HISTORY / attempt['receipt'])
        require(record['source_head'] == attempt['source_head'] and record['exit_code'] == attempt['exit_code'] == 1
                and attempt['deletions_performed'] == 0, 'cache observation relabelled a failed zero-deletion attempt')
    cleanup_attempts = []
    for path in sorted(HISTORY.glob('obsolete-test-cleanup-apply-*.jsonl')):
        rows = [json.loads(line) for line in path.read_text().splitlines() if line.strip()]
        require(rows and all(row['schema'] == 'scriptw-obsolete-test-harness-cleanup-receipt-v1' for row in rows)
                and rows[-1]['record_kind'] == 'final' and rows[-1]['complete'] is False
                and rows[-1]['deletions_performed'] == 0
                and not any(row['record_kind'] == 'file_outcome' for row in rows),
                'historical cleanup must retain its actual failed zero-deletion outcome')
        cleanup_attempts.append(dict(path=member_path(path), sha256=digest(path), complete=False, deletions_performed=0))
    approved_path = HISTORY / 'cleanup-user-approved-old-tests.json'
    approved = read_json(approved_path)
    approved_log = HISTORY / approved['log']
    require(approved['exit_code'] == 1 and digest(approved_log) == approved['log_sha256'],
            'later user-approved cleanup attempt changed its actual failed outcome')
    approved_result = json.loads(approved_log.read_text())
    require(approved_result['mode'] == 'apply' and approved_result['complete'] is False
            and approved_result['deletions_performed'] == 0 and approved_result['receipt'] is None
            and 'FileNotFoundError' in approved_result['error'] and '/build/release' in approved_result['error'],
            'approved attempt must retain its missing-cache zero-deletion result')
    # Record the356d diagnostic under its actual old paths and source, never as
    # the final candidate. No old mutable Cargo executable path is rehashed.
    mid_dir = HISTORY / 'candidate-engine-allocation-probe'
    mid_path = mid_dir / 'report.json'
    mid = read_json(mid_path)
    require(mid['complete'] is True and mid['executed'] is True and mid['source_commit'] == original_source
            and mid['helper_source']['path'] == str(ALLOCATION_HELPER)
            and mid['helper_source']['sha256'] == digest(ALLOCATION_HELPER), 'mid-source diagnostic identity changed')
    phase_count = 0
    for case in mid['cases']:
        expected = list(PHASES) if case['case'] != 'scalar' else [p for p in PHASES if not p.startswith('guest_')]
        require(case['exit_code'] == 0 and [row['phase'] for row in case['observation']['snapshots']] == expected
                and [row['phase'] for row in case['snapshots']] == expected, 'mid-source diagnostic lost a boundary')
        for row in case['observation']['snapshots']:
            require(row['total_successful_request_bytes'] - row['total_released_request_bytes'] == row['requested_live_bytes'],
                    'mid-source diagnostic counters do not reconcile')
        for row in case['snapshots']:
            raw = mid_dir / row['raw']
            require(raw.resolve().is_relative_to(mid_dir.resolve()) and digest(raw) == row['raw_sha256'],
                    'mid-source raw smaps changed')
            evidence.add(raw); phase_count += 1
        for name in ['stdout.log', 'stderr.log']:
            raw = mid_dir / case['case'] / name
            require(digest(raw) == case[name.split('.')[0] + '_sha256'], 'mid-source diagnostic stream changed')
            evidence.add(raw)
    require(phase_count == 35, 'mid-source diagnostic omitted actual observations')
    for path in [mid_path, HISTORY / 'candidate/identity.json']:
        evidence.add(path)
    for name in ['compile.stdout', 'compile.stderr', 'rustc-version.stdout', 'rustc-version.stderr']:
        evidence.add(mid_dir / name)
    # Original top-level data are development observations. This explicit
    # metadata/source whitelist excludes all payload trees, ELF/rlib files and
    # large source snapshots. It never imports or invokes cleanup executors.
    for pattern in ['*.json', '*.jsonl', '*.log']:
        for path in sorted(HISTORY.glob(pattern)):
            evidence.add(path)
    for path in sorted(HISTORY.glob('*.py')):
        evidence.add(path)
    stage = regexp_fixture_stage(evidence)
    return dict(source_commit=original_source, included_in_final_native_or_performance_totals=False,
                complete_native_acceptance=False,
                earlier_closed_native_prefix=dict(targets=len(targets), passed=total, complete=False),
                partial_aggregate_completed_test_lines=len(prefix), partial_prefix_added_to_final_total=False,
                oom_incident_count=len(failures['observations']), actual_oom_observations=failures,
                mid_source_allocation_diagnostic=dict(path=member_path(mid_path), sha256=digest(mid_path),
                                                      source_commit=original_source, phase_count=35),
                cleanup_abandoned=True, cleanup_auto_review_rejection=rejection, cleanup_attempts=cleanup_attempts,
                external_build_cache_disappearance=cache_change,
                later_user_approved_attempt=dict(receipt=member_path(approved_path), receipt_sha256=digest(approved_path),
                    actual_checkout_source=approved['source_head'], actual_checkout_patch_sha256=approved['source_patch_sha256'],
                    actual_exit_code=approved['exit_code'], deletions_performed=0, actual_error=approved_result['error'],
                    interpretation='After explicit user approval, the attempt found the shared release directory already absent. '
                                   'No deletion was performed; this observation does not attribute the directory disappearance '
                                   'or subsequent free-space change to our actions.'),
                cleanup_ever_automatically_retried=False, cleanup_deletions_performed=0,
                regexp_fixture_stage=stage,
                interpretation='Real earlier aggregate and isolated attempts were kernel-OOM-killed at4GiB; '
                               'their64 completed prefix lines and6029/25 target results are development observations, not final accepted union. '
                               'Earlier optional deletion attempts removed nothing and automatic approval rejected the relaxed-liveness action before launch. '
                               'The later explicitly approved attempt also removed nothing because the release directory was already absent. '
                               'The final pipeline checks free space and never invokes an executor. '
                               'Final accepted zero-OOM receipts do not erase these two real historical OOM incidents.')


def regexp_fixture_stage(evidence):
    """Keep the failed3914 fixture stage distinct from final accepted products."""
    stage = REGEXP_STAGE
    historical = Evidence(stage)  # Its resource samples never enter final accepted resources.
    manifest_path = stage / 'engine-batches.json'
    manifest = read_json(manifest_path)
    require(manifest['source_head'] == REGEXP_STAGE_SOURCE and manifest['complete'] is False,
            '3914 native prefix was relabelled complete or attributed to another source')
    inventory = manifest['inventory']
    require(inventory == sorted(set(inventory)) and len(inventory) == 1032,
            '3914 actual engine inventory differs')
    enumerated, inventory_log = historical.receipt('engine-batches-inventory', checkout_source=REGEXP_STAGE_SOURCE)
    require(inventory_names(inventory_log) == inventory and len(enumerated['executables']) == 1,
            '3914 engine enumeration differs from the actual prefix inventory')
    seen = []
    for index, batch in enumerate(manifest['batches']):
        label = f'engine-batch-{index:03d}'
        names = batch['inventory']
        row, log = historical.receipt(label, checkout_source=REGEXP_STAGE_SOURCE)
        require(batch == dict(label=label, inventory=names) and names and len(names) <= 32
                and set(names).issubset(inventory) and not set(names).intersection(seen)
                and row['command'][1:] == names + ['--exact', '--test-threads=1', '--include-ignored']
                and row['executables'] == enumerated['executables'],
                '3914 successful prefix changed its exact inventory/command/executable')
        closed_native_log(row, log, names, filtered=len(inventory) - len(names))
        seen.extend(names)
    label = f'engine-batch-{len(manifest["batches"]):03d}'
    require(label == 'engine-batch-011', '3914 failed-stage position changed')
    failed, failed_log = historical.receipt(label, exit_code=101, checkout_source=REGEXP_STAGE_SOURCE)
    observed = observed_names(failed_log)
    failed_names = sorted(name for name, state in observed if state == 'FAILED')
    expected_failures = ['regexp_program_boundary_tests::' + name for name in [
        'admitted_capture_only_body_preserves_a_later_replay_failure_and_last_index',
        'admitted_greedy_shape_cannot_hide_capture_writes_from_required_replay',
        'admitted_named_reference_body_preserves_second_iteration_ambiguity_and_last_index',
        'corrupt_program_sections_throw_without_reading_neighboring_data_or_changing_last_index',
        'malformed_backreference_operands_are_rejected_even_for_empty_captures',
    ]]
    expected_summary = [('FAILED', '3', '5', '0', '0', '1024')]
    require(failed_names == expected_failures and len(observed) == len(set(name for name, _ in observed)) == 8
            and all(state in ['ok', 'FAILED'] for _, state in observed)
            and SUMMARY_RE.findall(failed_log) == expected_summary
            and failed['test_results'] == [list(expected_summary[0])]
            and failed['executables'] == enumerated['executables']
            and failed['command'][1:] == [name for name, _ in observed] + ['--exact', '--test-threads=1', '--include-ignored']
            and not set(name for name, _ in observed).intersection(seen)
            and failed_log.count('descriptor must reach a physical GC initializer') == 5,
            '3914 actual five fixture-construction failures differ from the retained transcript')
    old_source_path = 'crates/scriptw-engine/src/regexp_program_boundary_tests.rs'
    old_source = subprocess.check_output(['git', 'show', REGEXP_STAGE_SOURCE + ':' + old_source_path], cwd=REPO)
    require(b'descriptor must reach a physical GC initializer' in old_source,
            '3914 original source does not contain the observed fixture construction assertion')
    evidence.add_bytes('development-3914-source/' + old_source_path, old_source)
    repair, repair_log = historical.receipt('fixture-repair-development', checkout_source=REGEXP_STAGE_SOURCE, clean_source=False)
    repair_patch_path = stage / 'regexp-fixture-repair-development.patch'
    repair_patch_sha256 = '03435bfaa280871eb75cc5b202709d6b9149be529f953bccebdcf2b4fdbd3754'
    repair_commit = '44e17ee4c73eeab6cc970804199109aa2aee51a9'
    repair_diff = subprocess.check_output(['git', 'diff', '--binary', REGEXP_STAGE_SOURCE, repair_commit,
                                           '--', 'crates', 'Cargo.toml', 'Cargo.lock'], cwd=REPO)
    repair_source = subprocess.check_output(['git', 'show', repair_commit + ':' + old_source_path], cwd=REPO)
    repair_names = [name for name, state in observed_names(repair_log) if state == 'ok']
    require(repair['source_patch_sha256'] == digest(repair_patch_path) == repair_patch_sha256
            and repair_diff == repair_patch_path.read_bytes()
            and old_source[old_source.index(b'#[test]'):] == repair_source[repair_source.index(b'#[test]'):]
            and len(repair_names) == len(set(repair_names)) == 6
            and all(name.startswith('regexp_program_boundary_tests::') for name in repair_names)
            and set(repair_names).issubset(inventory)
            and set(failed_names).issubset(repair_names)
            and repair['command'] == ['cargo', 'test', '--locked', '--offline', '--release', '--jobs', '1',
                '-p', 'scriptw-engine', '--lib', 'regexp_program_boundary_tests::', '--', '--test-threads=1', '--include-ignored'],
            'historical repaired-fixture run lost its exact3914+patch authority or unchanged six semantic bodies')
    closed_native_log(repair, repair_log, repair_names, filtered=len(inventory) - len(repair_names))
    evidence.add(repair_patch_path)
    report_path = stage / 'candidate-engine-allocation-probe/report.json'
    report = read_json(report_path)
    identity_path = stage / 'candidate/identity.json'
    identity = read_json(identity_path)
    require(report['complete'] is True and report['executed'] is True
            and report['source_commit'] == identity['source_revision']['commit'] == REGEXP_STAGE_SOURCE
            and report['source_fingerprint'] == identity['source_fingerprint']
            and report['helper_source'] == dict(path=str(ALLOCATION_HELPER), sha256=digest(ALLOCATION_HELPER)),
            '3914 historical allocation identity changed')
    phase_count = 0
    sys.path.insert(0, str(REPO / 'scripts'))
    from process_memory_maps import parse_smaps
    for case in report['cases']:
        expected = list(PHASES) if case['case'] != 'scalar' else [p for p in PHASES if not p.startswith('guest_')]
        require(case['state'] == 'closed' and case['exit_code'] == 0
                and [row['phase'] for row in case['observation']['snapshots']] == expected
                and [row['phase'] for row in case['snapshots']] == expected, '3914 allocation boundaries differ')
        for counters, maps in zip(case['observation']['snapshots'], case['snapshots']):
            require(counters['total_successful_request_bytes'] - counters['total_released_request_bytes']
                    == counters['requested_live_bytes'], '3914 allocation counters do not reconcile')
            raw = report_path.parent / maps['raw']
            require(raw.resolve().is_relative_to(report_path.parent.resolve()) and digest(raw) == maps['raw_sha256'],
                    '3914 historical raw smaps path/hash changed')
            parsed = parse_smaps(raw.read_text())
            require(all(parsed[key] == maps[key] for key in ['scope', 'totals', 'groups', 'mappings']),
                    '3914 saved mapping counters differ from their actual raw maps')
            evidence.add(raw); phase_count += 1
        for stream in ['stdout', 'stderr']:
            raw = report_path.parent / case['case'] / (stream + '.log')
            require(digest(raw) == case[stream + '_sha256'], '3914 allocation stream changed')
            evidence.add(raw)
    require(phase_count == 35, '3914 historical allocation phase count differs')
    historical.receipt('allocation-diagnostic-candidate', checkout_source=REGEXP_STAGE_SOURCE)
    for path in [manifest_path, report_path, identity_path, stage / 'frozen-products.json']:
        evidence.add(path)
    for name in ['compile.stdout', 'compile.stderr', 'rustc-version.stdout', 'rustc-version.stderr']:
        evidence.add(report_path.parent / name)
    for pattern in ['*.json', '*.jsonl', '*.log', '*.py', '*.md']:
        for path in sorted(stage.glob(pattern)): evidence.add(path)
    for path in historical.paths.values(): evidence.add(path)
    return dict(source_commit=REGEXP_STAGE_SOURCE, included_in_final_native_or_performance_totals=False,
                complete_native_acceptance=False, successful_engine_prefix_checks=len(seen),
                successful_engine_prefix_batches=len(manifest['batches']),
                failed_batch=dict(receipt=member_path(stage / (label + '.json')), exit_code=failed['exit_code'],
                                  passed=3, failed=len(failed_names), failed_identities=failed_names,
                                  actual_log_sha256=digest(stage / (label + '.log'))),
                allocation_diagnostic=dict(report=member_path(report_path), sha256=digest(report_path), paired_boundaries=phase_count),
                original_fixture_source_sha256=hashlib.sha256(old_source).hexdigest(),
                test_fixture_repair_development=dict(actual_checkout_source=repair['source_head'],
                    actual_checkout_patch_sha256=repair['source_patch_sha256'], patch=member_path(repair_patch_path),
                    receipt=member_path(stage / 'fixture-repair-development.json'), actual_exit_code=repair['exit_code'],
                    passed=len(repair_names), unchanged_semantic_test_bodies=True,
                    equivalent_committed_test_repair=repair_commit, added_to_final_total=False),
                native_or_scored_case_count_contribution=0, final_accepted_resource_count_contribution=0,
                interpretation='The3914 run stopped on five test-fixture construction assertions that expected the old '
                               'per-byte GC initializer. These failures did not reach the intended semantic comparisons. '
                               'The source/product identities, actual failed receipt/transcript, successful prefix and35 '
                               'allocation boundaries remain historical evidence. Final source is verified independently; '
                               'no3914 products, measurements, successful checks or resource receipts enter final accepted totals.')


def archive(evidence, output):
    rows = [dict(path=name, bytes=path.stat().st_size, sha256=digest(path)) for name, path in sorted(evidence.paths.items())]
    rows += [dict(path=name, bytes=len(data), sha256=hashlib.sha256(data).hexdigest()) for name, data in sorted(evidence.virtual.items())]
    rows.sort(key=lambda row: row['path'])
    wrappers = sorted(evidence.lossless_wrappers.values(), key=lambda row: row['logical_path'])
    wrappers_by_member = {row['archive_member']: row for row in wrappers}
    require(len(wrappers) == len(wrappers_by_member)
            and all(row['archive_member'] in evidence.virtual and row['logical_path'] not in evidence.paths
                    for row in wrappers), 'lossless Cargo wrapper/archive mapping differs')
    for wrapper in wrappers:
        source = evidence.lossless_sources[wrapper['archive_member']]
        require(source.stat().st_size == wrapper['decoded_bytes'] and digest(source) == wrapper['decoded_sha256'],
                'original raw historical Cargo JSONL changed before archiving')
    manifest = dict(schema='scriptw-execution-performance-archive-v1', source_commit=candidate_source(), members=rows,
                    lossless_file_wrappers=wrappers,
                    excluded='Product/test/helper ELFs, rlibs/native archives, caches, baseline source-guard snapshots/tars, '
                             'large Portable bundles and V8 cachedData are excluded. Actual producer/hash provenance, code and raw observations remain. '
                             'The two historical Cargo producer JSONLs are retained in complete deterministic gzip members; '
                             'lossless_file_wrappers gives original logical paths, decoded lengths and SHA-256 identities.')
    encoded = (json.dumps(manifest, indent=2) + '\n').encode()
    temporary = output.with_suffix(output.suffix + '.pending')
    require(not output.exists() and not temporary.exists(), 'refusing to overwrite complete/partial archive')
    with temporary.open('xb') as raw, gzip.GzipFile(fileobj=raw, mode='wb', filename='', mtime=0, compresslevel=6) as compressed, tarfile.open(fileobj=compressed, mode='w') as bundle:
        for row in rows:
            if row['path'] in evidence.virtual:
                stream = io.BytesIO(evidence.virtual[row['path']])
            else:
                path = evidence.paths[row['path']]
                require(path.stat().st_size == row['bytes'] and digest(path) == row['sha256'], 'evidence changed while archiving')
                stream = path.open('rb')
            with stream:
                info = tarfile.TarInfo(row['path']); info.size = row['bytes']; info.mode = 0o644
                bundle.addfile(info, stream)
        info = tarfile.TarInfo(PREFIX + 'archive-members.json'); info.size = len(encoded); info.mode = 0o644
        bundle.addfile(info, io.BytesIO(encoded))
    expected, seen = {row['path']: row for row in rows}, set()
    with tarfile.open(temporary, 'r:gz') as bundle:
        for member in bundle:
            require(member.isfile() and member.name not in seen, 'archive has a repeated/nonfile member')
            seen.add(member.name)
            stream = bundle.extractfile(member)
            if member.name == PREFIX + 'archive-members.json':
                require(stream.read() == encoded, 'archive manifest round-trip differs')
            else:
                row = expected[member.name]
                require(member.size == row['bytes'] and hashlib.file_digest(stream, 'sha256').hexdigest() == row['sha256'],
                        'archive member round-trip differs')
                if member.name in wrappers_by_member:
                    wrapper = wrappers_by_member[member.name]
                    decoded, length = hashlib.sha256(), 0
                    with bundle.extractfile(member) as raw, gzip.GzipFile(fileobj=raw, mode='rb') as plain:
                        while chunk := plain.read(256 * 1024):
                            decoded.update(chunk); length += len(chunk)
                            require(length <= wrapper['decoded_bytes'], 'archived Cargo wrapper exceeds its declared raw source')
                    require(length == wrapper['decoded_bytes'] and decoded.hexdigest() == wrapper['decoded_sha256'],
                            'archived Cargo wrapper lost or modified original producer bytes')
    expanded = sum(row['bytes'] for row in rows) + len(encoded)
    require(seen == set(expected) | {PREFIX + 'archive-members.json'} and len(seen) <= 32768
            and temporary.stat().st_size <= 32 * 1024**2 and expanded <= 256 * 1024**2,
            'archive exceeds explicitly bounded graph-reader budget; do not silently drop evidence')
    temporary.replace(output)
    return dict(file=output.name, sha256=digest(output), bytes=output.stat().st_size, member_count=len(seen),
                manifest_sha256=hashlib.sha256(encoded).hexdigest(), expanded_bytes=expanded,
                lossless_file_wrappers=wrappers)


def evidence_closing_time(evidence):
    """Use admitted actual receipt completion times, never publication wall time."""
    require(bool(evidence.resources), 'checkpoint has no admitted closing evidence')
    moments = [datetime.fromisoformat(row['completed_at']) for row in evidence.resources]
    require(all(moment.utcoffset() is not None for moment in moments), 'closing receipt timestamp lacks a timezone')
    return max(moments).astimezone(timezone.utc)


def markdown(report):
    diagnostic_ = report['execution_allocation_diagnostic']
    tests = report['test262']
    source = report['source_commit']
    lines = [f"# Fixed runtime memory checkpoint — {report['refresh_date']}", '',
             f"Actual candidate [{source[:9]}](https://github.com/mewhhaha/scriptw/commit/{source}) versus published clean baseline "
             f"[{BASELINE_SOURCE[:9]}](https://github.com/mewhhaha/scriptw/commit/{BASELINE_SOURCE}).", '',
             'Minimal Intl providers initialize on first use. Compilation uses build-admitted metadata; Cargo native images use '
             'bounded compressed storage and, on supported filesystems, private file-backed mappings. Constant-string bootstrap '
             'uses a descriptor loop, and static RegExp descriptors copy from checked program data. '
             'The [runtime byte-ownership contract](contracts/runtime-byte-ownership.md) records those boundaries.', '',
             'Ordinary fresh Store/Realm execution and transformed-source existing-Realm calls each contain all 17 workloads, '
             'two ABBA rounds per product, seven samples after ten warmups. Construction/checksums stay inside timed execution. '
             'V8 is paired with the candidate rounds. Shared-host results are descriptive; every slowdown remains visible.', '',
             '| Workload | Scriptw before ms | Scriptw after ms | Change | Paired V8 ms |', '| --- | ---: | ---: | ---: | ---: |']
    for row in report['performance']['table']:
        lines.append(f"| {row['file']} | {row['baseline_ms']:.3f} | {row['candidate_ms']:.3f} | {row['change_percent']:+.1f}% | {row['paired_candidate_v8_ms']:.3f} |")
    lines += ['', 'The README graph uses only latest Scriptw versus paired V8 elapsed time and post-execution process RSS. '
              'Invocation RSS includes runtime/setup and retained warmup effects; it is neither live JavaScript memory nor a peak. '
              'Sampled maxima, GC capacity and every raw timing stay in machine-readable evidence.', '',
              'Ordinary post-execution process RSS, in MiB; each entry is rederived as the median of 14 endpoints from the '
              'validated fresh analysis. Wasmtime reads its final sampler while the Store remains alive; V8 reads after '
              'execution while its context remains alive. The independent allocation diagnostic below also records '
              'post-return snapshots after its Store has dropped.', '',
              '| Workload | Scriptw before MiB | Scriptw after MiB | Paired V8 MiB |',
              '| --- | ---: | ---: | ---: |']
    for row in report['performance']['rss_table']:
        lines.append(f"| {row['file']} | {row['baseline_rss_bytes']/2**20:.3f} | "
                     f"{row['candidate_rss_bytes']/2**20:.3f} | {row['paired_candidate_v8_rss_bytes']/2**20:.3f} |")
    lines += ['',
              'Separate existing-Realm calls:', '', '| Workload | Before ms | After ms | Change | Paired V8 ms |',
              '| --- | ---: | ---: | ---: | ---: |']
    for row in report['same_realm_performance']['table']:
        lines.append(f"| {row['file']} | {row['baseline_ms']:.3f} | {row['candidate_ms']:.3f} | {row['change_percent']:+.1f}% | {row['paired_candidate_v8_ms']:.3f} |")
    lines += ['', 'A separate Intl.NumberFormat first-use fixture is excluded from both 17-case scored cohorts. '
              'It retains observation 0 as the first warmup, nine further warmups and seven steady observations. '
              'First actual use constructs the whole selected Minimal provider; its shared data can remain owned afterward. '
              'Wasmtime endpoints include invocation admission, native mapping, setup and execution; V8 endpoints bracket '
              'JavaScript execution. Their changes are not an isolated Intl heap size or synchronized live-heap measurement.', '',
              '| Intl diagnostic | First warmup RSS MiB before → after | Steady median RSS MiB after |',
              '| --- | ---: | ---: |']
    for row in report['intl_first_use_diagnostic']['table']:
        first, steady = row['first_warmup'], row['steady_summary']
        lines.append(f"| {row['product']} / {row['runtime']} | {first['rss_before_bytes']/2**20:.3f} → "
                     f"{first['rss_after_bytes']/2**20:.3f} | {steady['rss_after_bytes']['median']/2**20:.3f} |")
    lines += ['', 'The allocation diagnostic uses the exact same helper source with distinct linked ELFs per source, three fresh '
              'case processes and two invocations per case. All 35 phase pairs (70 raw snapshots) are retained. '
              'It explains fixed host requested-byte liveness and process residency separately from ordinary timing/graph scores.', '',
              '| Diagnostic case / phase | Requested Rust live MiB before → after | RSS MiB before → after |',
              '| --- | ---: | ---: |']
    for case in diagnostic_['cases']:
        wanted = {'after_compilation', 'guest_start_1', 'guest_body_finished_1', 'after_execution_1', 'after_dropping_engine'}
        for row in case['phases']:
            if row['phase'] in wanted:
                live, rss = row['metrics']['requested_live_bytes'], row['metrics']['rss_bytes']
                lines.append(f"| {case['case']} / {row['phase']} | {live['baseline']/2**20:.3f} → {live['candidate']/2**20:.3f} | "
                             f"{rss['baseline']/2**20:.3f} → {rss['candidate']/2**20:.3f} |")
    regexp = report['regexp_native_memory_diagnostic']
    lines += ['', f"A separate exact RegExp native-test child passed with {regexp['observation']['accounting']['child_peak_rss_bytes']/2**20:.3f} MiB "
              'GNU time 1.9 high-water RSS in a fresh process and empty Scriptw disk cache. The OS page cache was not flushed. '
              'This interval includes the child’s in-process compilation and execution, excludes Cargo/LLVM build work, '
              'and contributes zero new native or scored performance cases. The earlier 356d aggregate and isolated 4 GiB '
              'kernel-OOM kills remain archived development failures with a different, compile-inclusive cgroup accounting scope.']
    caveats = [value.replace('64MiB', '64 MiB').replace('SDK512MiB', 'SDK 512 MiB') for value in diagnostic_['caveats']]
    lines += ['', *caveats, '',
              f"Actual native verification passed {report['native']['passed']:,} checks across {report['native']['target_count']} "
              'complete targets, including 1,032 exact engine identities in disjoint fresh processes. Focused overlaps are not added.', '',
              f"There are {report['native']['nonempty_target_count']} nonempty native targets. The scriptw-intl-build-data unit "
              'target explicitly enumerates and runs zero cases; its separate authority-token compile-fail doctest passes one case '
              'and is reported outside the native-check total.', '',
              f"Selected Test262 replay executed {tests['total']:,}: {tests['passed']:,} Success, {tests['bug']:,} Bug, "
              f"{tests['crash']:,} Crash, {tests['not_implemented']:,} NotImplemented, {tests['timeout']:,} timeouts; "
              f"actual launcher exit {tests['actual_command_exit']}. This is the complete selected Intl402/module-code/Function-family union "
              'and original controls, not a full pinned Test262 refresh. Actual failure identities/details and pins remain in the evidence.', '',
              'Full tooling remains red: the current aggregate module-boundary guard exits 1 with 9 exact members of the '
              'committed baseline’s 18 prefixed failures, plus an isolated terminal source-guard failure that also reproduces '
              'the baseline. All 74 source-control files were verified against their committed Git blobs. This establishes '
              'no new observed diagnostic; it does not establish full tooling acceptance. Pre-existing/failed foundation '
              'observations and the first missing-vendor-input attempt remain archived outside accepted totals. '
              'Large source snapshots are excluded. The earlier 356d development campaign suffered two real 4 GiB kernel-OOM kills '
              '(aggregate and isolated RegExp compilation). Its 6,029 checks across 25 closed targets and 64 partial aggregate '
              'test lines are preserved without entering final counts. The 3914 development stage stopped on five RegExp '
              'test-fixture construction failures before the intended semantic comparisons. Its failed receipt, successful '
              'Engine prefix and 35 allocation boundaries remain historical. The development repair filter passed all six '
              'unchanged semantic test bodies under actual 3914 plus the retained exact patch; final clean-commit verification '
              'runs independently. These development observations add zero final native, performance or accepted-resource cases.', '',
              'Every optional cleanup attempt deleted zero files. Automatic approval review rejected a relaxed-liveness '
              'deletion action before launch. The user later explicitly approved the 22 targets, but that attempt found the '
              'shared build directory independently missing and failed before deletion. Its disappearance has an unknown '
              'actor and is not attributed to these cleanup attempts. Final orchestration never invokes cleanup.', '',
              'The separate candidate native-map observer is code-size attribution only: it hashes/faults the entire native '
              'text. Its timing and RSS never enter the ordinary performance tables or README graph. Actual R/P text extents, '
              'raw maps, native identities and observer stdout remain archived; generated large raw Wasm payloads are excluded.', '',
              f"[Machine-readable checkpoint]({STEM}.json) · [Raw evidence and reproduction code]({STEM}.tar.gz). "
              f"Archive SHA-256: `{report['archive']['sha256']}`.", '',
              'Reproduce with the archived serial native/product/freeze plans, full native inventory admission and selected.ids replay '
              'under the one-CPU, 4 GiB, no-swap scope. Run the separate allocation freezer/driver and `measure_all.py`, then rederive '
              '`analyze.py` and `analysis_calls.py`. `publish_evidence.py` validates read-only by default; `--publish` requires all '
              'closed inputs and refuses overwrite. The archive includes ALLOCATION-COMPARISON.md/json for all diagnostic phases. '
              'Both historical Cargo producer JSONLs are complete deterministic gzip members; archive lossless_file_wrappers '
              'records their original logical paths, decoded byte lengths and SHA-256 values for exact recovery.']
    return '\n'.join(lines) + '\n'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--publish', action='store_true')
    parser.add_argument('--section', choices=['products', 'allocation', 'native', 'conformance', 'performance', 'tooling', 'code-size', 'intl-first-use', 'regexp-memory', 'storage'])
    parser.add_argument('--write-allocation-comparison', action='store_true', help='create new ignored derived allocation tables only')
    args = parser.parse_args()
    require(not (args.publish and args.section), 'partial sections cannot publish a complete checkpoint')
    os.sched_setaffinity(0, {min(os.sched_getaffinity(0))})
    sys.path.insert(0, str(BASE))
    current_source()
    evidence = Evidence()
    product_report = products(evidence)
    if args.section == 'products':
        print(json.dumps(dict(validated=True, section='products', products=product_report), indent=2)); return
    if args.section == 'native':
        result = native(evidence)
        print(json.dumps(dict(validated=True, section='native', passed=result['passed'], targets=result['target_count']), indent=2)); return
    if args.section == 'conformance':
        result = conformance(evidence)
        print(json.dumps(dict(validated=True, section='conformance', total=result['total'], outcomes=result['outcomes']), indent=2)); return
    if args.section == 'tooling':
        result = tooling(evidence)
        print(json.dumps(dict(validated=True, section='tooling', full_tooling_passed=result['full_tooling_passed'],
                              comparison=result['comparison']), indent=2)); return
    if args.section == 'code-size':
        result = code_size(evidence, product_report)
        print(json.dumps(dict(validated=True, section='code-size', native_text_bytes=result['native_text_bytes'],
                              ordinary_rss_eligible=False), indent=2)); return
    if args.section == 'intl-first-use':
        result = intl_first_use(evidence, product_report)
        print(json.dumps(dict(validated=True, section='intl-first-use', diagnostic_rows=len(result['table']),
                              scored_case_count_contribution=0), indent=2)); return
    if args.section == 'regexp-memory':
        result = regexp_memory(evidence, product_report)
        print(json.dumps(dict(validated=True, section='regexp-memory',
                              child_peak_rss_bytes=result['observation']['accounting']['child_peak_rss_bytes'],
                              additional_native_cases_counted=0, scored_case_count_contribution=0), indent=2)); return
    if args.section == 'storage':
        print(json.dumps(dict(validated=True, section='storage', auxiliary=development_history(evidence)), indent=2)); return
    diagnostic_ = allocation_comparison(evidence, product_report)
    comparison_path, comparison_md = BASE / 'allocation-comparison.json', BASE / 'ALLOCATION-COMPARISON.md'
    if args.write_allocation_comparison:
        require(not comparison_path.exists() and not comparison_md.exists(), 'refusing to overwrite a derived allocation comparison')
        comparison_path.write_text(json.dumps(diagnostic_, indent=2) + '\n')
        comparison_md.write_text(allocation_markdown(diagnostic_))
    if args.section == 'allocation':
        print(json.dumps(dict(validated=True, section='allocation', paired_phases=diagnostic_['paired_phase_count'],
                              raw_snapshots=diagnostic_['raw_snapshot_count'],
                              comparison_written=args.write_allocation_comparison), indent=2)); return
    require(read_json(comparison_path) == diagnostic_ and comparison_md.read_text() == allocation_markdown(diagnostic_),
            'derived allocation comparison differs from actual closed reports')
    evidence.add(comparison_path); evidence.add(comparison_md)
    performance_report = performance(evidence, product_report)
    calls_report = performance_calls(evidence, product_report)
    if args.section == 'performance':
        print(json.dumps(dict(validated=True, section='performance', fresh_cases=len(performance_report['table']),
                              call_cases=len(calls_report['table'])), indent=2)); return
    native_report = native(evidence)
    conformance_report = conformance(evidence)
    tooling_report = tooling(evidence)
    extra_report = extra_acceptance(evidence, native_report)
    code_size_report = code_size(evidence, product_report)
    intl_report = intl_first_use(evidence, product_report)
    regexp_memory_report = regexp_memory(evidence, product_report)
    for name in ['publish_evidence.py', 'baseline-reference.json', 'native_final.py', 'engine_batches.py', 'accept_native.py', 'build_native.py',
                 'build_product.py', 'freeze_candidate.py', 'freeze_candidate_link_inputs.py', 'campaign_identity.py',
                 'measure.py', 'measure_calls.py', 'measure_all.py', 'analyze.py', 'analysis_calls.py', 'run_check.py',
                 'validate_inventory.py', 'campaign.json', 'MEASUREMENT-PLAN.md']:
        evidence.add(BASE / name)
    for name in ['ALLOCATION-DIAGNOSTIC.md', 'ALLOCATION-FINDINGS.md']:
        evidence.add(HISTORY / name)
    for name in ['limited_verification.py', 'resource_numbers.py', 'replay-test262-executions.py',
                 'test262_execution_batches.py', 'process_memory_maps.py']:
        evidence.add(REPO / 'scripts' / name)
    observations = additional_observations(evidence)
    storage_report = development_history(evidence)
    closing_time = evidence_closing_time(evidence)
    report = dict(schema='scriptw-execution-performance-checkpoint-v1', refresh_date=closing_time.date().isoformat(),
                  evidence_completed_at=closing_time.isoformat(), complete=True,
                  source_commit=candidate_source(), campaign=read_json(BASE / 'campaign.json'), products=product_report,
                  native=native_report, test262=conformance_report, performance=performance_report,
                  same_realm_performance=calls_report, execution_allocation_diagnostic=diagnostic_,
                  source_tooling=tooling_report, extra_acceptance=extra_report, native_code_size=code_size_report,
                  intl_first_use_diagnostic=intl_report,
                  regexp_native_memory_diagnostic=regexp_memory_report,
                  additional_observations=observations,
                  development_observations=storage_report,
                  resources=dict(cpus=1, memory_limit_bytes=BUDGET, swap_limit_bytes=0, accepted_oom_events=0,
                                 maximum_cgroup_peak_bytes=max(row['memory_peak_bytes'] for row in evidence.resources),
                                 field_provenance=evidence.resources,
                                 development_oom_incident_count=storage_report['oom_incident_count'],
                                 scope='Only actual final accepted outer resource receipts; baseline allocation helper lacks an outer JSON receipt. Two earlier356d OOM incidents and the3914 five-failure fixture stage remain in development_observations.'))
    require(report['campaign']['source_commit'] == candidate_source() and report['campaign']['baseline_source'] == BASELINE_SOURCE
            and report['campaign']['baseline_exact_patch_sha256'] == EMPTY_PATCH, 'campaign authority changed')
    if not args.publish:
        print(json.dumps(dict(validated=True, native_passed=native_report['passed'], native_targets=native_report['target_count'],
                              selected_test262=conformance_report['total'], actual_outcomes=conformance_report['outcomes'],
                              fresh_cases=17, call_cases=17, allocation_pairs=35,
                              archive_members=len(evidence.paths) + len(evidence.virtual) + 1,
                              publication='not requested'), indent=2)); return
    output = REPO / 'docs/rust-rewrite'
    paths = [output / (STEM + suffix) for suffix in ['.md', '.json', '.tar.gz']]
    require(not any(path.exists() for path in paths), 'refusing to overwrite a published checkpoint')
    require(len(json.dumps(report, indent=2).encode()) + 4096 <= 16 * 1024**2, 'checkpoint exceeds16MiB graph-reader budget')
    report['archive'] = archive(evidence, paths[2])
    data = (json.dumps(report, indent=2) + '\n').encode()
    require(len(data) <= 16 * 1024**2, 'checkpoint exceeds16MiB graph-reader budget')
    paths[1].write_bytes(data); paths[0].write_text(markdown(report))
    print(json.dumps(dict(published=[str(path.relative_to(REPO)) for path in paths], archive=report['archive']), indent=2))


if __name__ == '__main__':
    try:
        main()
    except (KeyError, ValueError, OSError, TypeError, StopIteration) as error:
        print('Evidence publication refused: ' + str(error), file=sys.stderr)
        raise SystemExit(1)


