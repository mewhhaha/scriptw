import collections, hashlib, json, pathlib, re, subprocess, sys
root=pathlib.Path(__file__).resolve().parent
if subprocess.check_output(['git','diff','--binary','HEAD','--','crates','Cargo.toml','Cargo.lock']): raise RuntimeError('commit coherent source before final native work')
source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
scopes=json.loads((root/'native-scopes.json').read_text())
groups=collections.OrderedDict()
for item in scopes: groups.setdefault(item['package'],[]).append(item)
def check(label,command):
 code=subprocess.call([sys.executable,'-B',str(root/'run_check.py'),label,*command])
 if code: sys.exit(code)
 return json.loads((root/(label+'.json')).read_text())
for package,items in groups.items():
 command=['cargo','test','--locked','--offline','--release','--jobs','1','-p',package,'--no-run']
 for item in items:
  command.append(item['kind'])
  if item['name']: command.append(item['name'])
 label='frozen-build-'+package
 receipt=root/(label+'.json')
 if receipt.exists():
  previous=json.loads(receipt.read_text())
  if previous.get('source_head')==source and previous['exit_code']==0 and previous['command']==command: continue
  label='frozen-build-final-'+package
 check(label,command)
