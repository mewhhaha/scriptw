"""Close one serial verification and measurement campaign; stop on any surprise."""
import importlib.util
import json
import pathlib
import subprocess
import sys

root = pathlib.Path(__file__).resolve().parent

def run(command, expected=0):
    code = subprocess.call(command)
    if code != expected:
        raise RuntimeError('unexpected exit ' + str(code) + ': ' + repr(command))

for name in ['focused_acceptance.py', 'accept_native.py', 'extra_acceptance.py', 'validate_inventory.py']:
    run([sys.executable, '-B', str(root / name)])
run([sys.executable, '-B', str(root / 'run_check.py'), 'regexp-native-memory-proof',
     sys.executable, '-B', str(root / 'regexp-native-memory-proof.py'), '--run'])
run([sys.executable, '-B', str(root / 'regexp-native-memory-proof.py')])
native = json.loads((root / 'native-closed.json').read_text())
if not native['complete'] or len(native['targets']) != 31:
    raise RuntimeError('complete native target inventory required')
command = [sys.executable, '-B', 'scripts/replay-test262-executions.py', str(root / 'selected.ids'),
           '--binary', str(root / 'candidate/scriptw'), '--suite-root', 'test262/vendor/test262',
           '--output-dir', str(root / 'conformance'), '--workers', '1', '--reuse-case-workers']
run([sys.executable, '-B', str(root / 'run_check.py'), 'conformance-final', *command], expected=1)
spec = importlib.util.spec_from_file_location('fixed_memory_publication', root / 'publish_evidence.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
result = module.conformance(module.Evidence())
if result['total'] != 7746 or result['bug'] != 4 or result['crash'] or result['not_implemented'] or result['timeout']:
    raise RuntimeError('selected conformance changed; preserve results for investigation')
print('Selected conformance reconciled', result['passed'], '/', result['total'], flush=True)
# This optional map run hashes/faults native text. Its only role in this batch
# is code-size attribution; its residency never enters the ordinary RSS graph.
run([sys.executable, '-B', str(root / 'run_check.py'), 'candidate-code-size', sys.executable, '-B',
     'scripts/profile_memory_maps.py', '--runner', str(root / 'candidate/runtime_baseline'),
     '--output', str(root / 'candidate-code-size-data'), '--case', 'startup.js', '--samples', '3', '--warmups', '1'])
run([sys.executable, '-B', str(root / 'measure_all.py')])
run([sys.executable, '-B', str(root / 'run_check.py'), 'intl-first-use', sys.executable, '-B', str(root / 'measure_intl_first_use.py')])
run([sys.executable, '-B', str(root / 'analyze_intl_first_use.py')])
print('ALL FINAL VERIFICATION AND ORDINARY COHORTS CLOSED', flush=True)
