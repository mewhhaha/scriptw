import hashlib,json,pathlib,re,subprocess,sys
root=pathlib.Path(__file__).resolve().parent
if subprocess.check_output(['git','diff','--binary','HEAD','--','crates','Cargo.toml','Cargo.lock']): raise RuntimeError('commit coherent source before final native work')
source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
def check(label,command):
 receipt=root/(label+'.json')
 if receipt.exists():
  row=json.loads(receipt.read_text())
  if row['exit_code']!=0 or row['command']!=command or row.get('source_head')!=source or row['log_sha256']!=hashlib.sha256((root/row['log']).read_bytes()).hexdigest(): raise RuntimeError('incompatible receipt '+label)
  return row
 code=subprocess.call([sys.executable,'-B',str(root/'run_check.py'),label,*command])
 if code:sys.exit(code)
 return json.loads(receipt.read_text())
built=check('engine-batches-build',['cargo','test','--locked','--offline','--release','--jobs','1','-p','scriptw-engine','--lib','--no-run'])
text=(root/built['log']).read_text()
binaries=re.findall(r'Executable unittests src/lib.rs \(([^)]+)\)',text)
if len(binaries)!=1:raise RuntimeError('expected actual engine executable')
binary=binaries[0]
check('engine-batches-inventory',[binary,'--list','--include-ignored'])
inventory=sorted(re.findall(r'^([^\s]+): test$',(root/'engine-batches-inventory.log').read_text(),re.M))
original=sorted(re.findall(r'^([^\s]+): test$',pathlib.Path('target/memory-execution-20261025/engine-batches-inventory.log').read_text(),re.M))
added={'embedded_runtime::native_backing::tests::private_inode_has_no_name_and_module_owns_its_lifetime','intl_data_images::deferred::tests::hostless_module_has_no_provider_or_fabricated_identity','intl_data_images::deferred::tests::metadata_and_fixed_zones_stay_deferred_until_shared_first_use'}
if set(inventory)!=set(original)|added or len(inventory)!=1032:raise RuntimeError('engine denominator changed beyond the three new controls')
chunks=[];current=[]
for name in inventory:
 if name.startswith('runtime_profile::') or 'capacity' in name or 'inlining' in name:
  if current: chunks.append(current);current=[]
  chunks.append([name])
 else:
  current.append(name)
  if len(current)==32: chunks.append(current);current=[]
if current:chunks.append(current)
manifest={'source_head':source,'complete':False,'inventory':inventory,'batches':[],'binary':str(pathlib.Path(binary).resolve())}
for index,selected in enumerate(chunks):
 label=f'engine-batch-{index:03d}'
 row=check(label,[binary,*selected,'--exact','--test-threads=1','--include-ignored'])
 transcript=(root/row['log']).read_text()
 observed=[name.removesuffix(' - should panic') for name,status in re.findall(r'^test (.+) \.\.\. (ok|FAILED|ignored)$',transcript,re.M) if status=='ok']
 if sorted(observed)!=sorted(selected) or row['test_results']!=[['ok',str(len(selected)),'0','0','0',str(len(inventory)-len(selected))]]:raise RuntimeError('exact batch did not pass '+label)
 manifest['batches'].append({'label':label,'inventory':selected})
 manifest['complete']=index+1==len(chunks)
 (root/'engine-batches.json').write_text(json.dumps(manifest,indent=2)+'\n')
 print('Closed engine inventory',sum(len(x['inventory']) for x in manifest['batches']),'/',len(inventory),flush=True)
seen=[name for batch in manifest['batches'] for name in batch['inventory']]
if sorted(seen)!=inventory or len(seen)!=len(set(seen)):raise RuntimeError('engine union lost/repeated an ID')
aggregate={'label':'broad-07-scriptw-engine-lib-batched','source_head':source,'source_patch_sha256':built['source_patch_sha256'],'package':'scriptw-engine','kind':'--lib','name':None,'inventory':inventory,'batch_manifest':'engine-batches.json','exit_code':0,'complete':True,'passed':len(inventory),'aggregation':'disjoint exact native libtest batch observations; no synthetic single-process transcript'}
(root/'engine-accepted.json').write_text(json.dumps(aggregate,indent=2)+'\n')
print('ALL1032 EXACT ENGINE CHECKS PASSED IN FRESH BOUNDED BATCHES',flush=True)
