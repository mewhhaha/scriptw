import hashlib,json,pathlib,subprocess,sys
root=pathlib.Path(__file__).resolve().parent
binary=root/'candidate/scriptw'
command=[str(binary),'--jobs','1','test262','list-all','--suite-root','test262/vendor/test262']
code=subprocess.call([sys.executable,'-B',str(root/'run_check.py'),'conformance-inventory-final',*command])
if code:sys.exit(code)
plan=json.loads((root/'selected-scopes.json').read_text());data=(root/'conformance-inventory-final.log').read_bytes()
digest=hashlib.sha256(data).hexdigest()
assert digest==plan['source_inventory_sha256'],'full native inventory changed'
sys.path.insert(0,'scripts');import test262_execution_batches as b
ids=b.native_inventory(data.decode());assert len(ids)==102994
selected=set()
for scope in plan['scopes']:
 actual=sorted(x for x in ids if x.split(':',1)[1].startswith(scope['prefix']))
 assert actual==sorted(scope['execution_ids']) and len(actual)==scope['count']
 assert not selected.intersection(actual);selected.update(actual)
selected.update(plan['known_failure_controls'])
assert selected==set((root/'selected.ids').read_text().splitlines()) and len(selected)==7746
report={'complete':True,'source_head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'compiler_identity':json.loads((root/'candidate/identity.json').read_text()),'receipt':'conformance-inventory-final.json','inventory_sha256':digest,'total':len(ids),'selected_total':len(selected),'selected_ids_sha256':hashlib.sha256((root/'selected.ids').read_bytes()).hexdigest(),'scope_plan_sha256':hashlib.sha256((root/'selected-scopes.json').read_bytes()).hexdigest()}
(root/'conformance-inventory-validated.json').write_text(json.dumps(report,indent=2)+'\n');print('FINAL FULL102994 INVENTORY AND ALL7746 SELECTED IDS VERIFIED',flush=True)
