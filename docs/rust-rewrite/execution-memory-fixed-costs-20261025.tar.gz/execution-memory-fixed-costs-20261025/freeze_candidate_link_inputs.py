#!/usr/bin/env python3
"""Freeze completed candidate Cargo link inputs for the allocation helper.

No Cargo/rustc/product command is invoked. --freeze requires the successful
closed release receipt, final Cargo build-finished event and real frozen product
identities. Independent reflink-only copies preserve mutable Cargo outputs.
The default validates already frozen inputs; --plan-only reads no build input.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

BASE = Path(__file__).resolve().parent
ROOT = BASE.parent.parent
HISTORY = ROOT / 'target/memory-fixed-costs-20261025'
MANIFEST = BASE / 'frozen-candidate-link-inputs.json'
DIRECTORY = BASE / 'frozen-candidate-link-inputs'
EMPTY_SHA = hashlib.sha256(b'').hexdigest()
LIMIT = 4 * 1024**3
MAX_LOG_BYTES = 64 * 1024**2


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def pin(path):
    path = Path(path)
    return dict(path=str(path), sha256=digest(path), bytes=path.stat().st_size)


def stamp():
    return datetime.now(timezone.utc).isoformat()


def products_path():
    candidates = [BASE / 'candidate/frozen-products.json', BASE / 'frozen-products.json']
    present = [path for path in candidates if path.is_file()]
    require(present, 'actual frozen-products.json is not yet available')
    if len(present) == 2:
        require(read(present[0]) == read(present[1]), 'two product manifests disagree')
    return present[0]


def closed_authority(*, verify_mutable_products=False):
    # Check the terminal receipt before opening a potentially partial Cargo log.
    release_path = BASE / 'release-products.json'
    release = read(release_path)
    require(release.get('label') == 'release-products' and release.get('exit_code') == 0,
            'release-products receipt is not closed successfully')
    identity_path = BASE / 'candidate/identity.json'
    identity = read(identity_path)
    revision = identity.get('source_revision', {})
    source = revision.get('commit', '')
    fingerprint = identity.get('source_fingerprint', '')
    require(revision.get('kind') == 'git-commit' and re.fullmatch(r'(?:[0-9a-f]{40}|[0-9a-f]{64})', source)
            and re.fullmatch(r'[0-9a-f]{64}', fingerprint)
            and identity.get('source_fingerprint_scheme') == 'scriptw-program-cache-compiler-v3',
            'candidate has no actual validated source identity')
    campaign_path = BASE / 'campaign.json'
    campaign = read(campaign_path)
    require(campaign.get('source_commit') == source
            and campaign.get('baseline_source') == '9b7746531c4b3bff0ecbb863d7d70dfead12455b'
            and source != campaign['baseline_source'], 'candidate and campaign identity disagree')
    require(release.get('source_head') == source and release.get('source_patch_sha256') == EMPTY_SHA,
            'release receipt is not the actual clean candidate source')
    require(release.get('cpu_affinity') and len(release['cpu_affinity']) == 1
            and str(release.get('memory.max')) == str(LIMIT)
            and str(release.get('memory.swap.max')) == '0'
            and str(release.get('memory.oom.group')) == '1'
            and 0 <= int(release.get('memory.peak', -1)) <= LIMIT,
            'closed release resource receipt differs from one-CPU/4GiB/no-swap policy')
    events = dict(line.split() for line in release['memory.events'].splitlines())
    require(all(events.get(name) == '0' for name in ['oom', 'oom_kill', 'oom_group_kill']),
            'closed release reported OOM events')
    release_log = BASE / release['log']
    require(release_log.is_relative_to(BASE) and digest(release_log) == release['log_sha256'],
            'closed release transcript changed')
    command = release.get('command', [])
    require(command and Path(command[-1]).resolve() == BASE / 'build_product.py',
            'release receipt did not run the actual product builder')
    cargo_path = BASE / 'cargo-product.jsonl'
    with cargo_path.open('rb') as stream:
        raw = stream.read(MAX_LOG_BYTES + 1)
    require(len(raw) <= MAX_LOG_BYTES, 'Cargo producer log exceeds 64MiB reading budget')
    rows = [json.loads(line) for line in raw.splitlines()]
    require(rows and rows[-1] == {'reason': 'build-finished', 'success': True}
            and sum(row.get('reason') == 'build-finished' for row in rows) == 1,
            'actual Cargo product log is partial or unsuccessful')
    frozen_path = products_path()
    frozen = read(frozen_path)
    require(frozen.get('source_commit') == source and set(frozen['products'])
            == {'scriptw', 'runtime_baseline', 'runtime_boundaries'},
            'frozen product inventory/source differs')
    for name, item in frozen['products'].items():
        producer = item['cargo_producer']
        require(producer in rows and producer['profile']['opt_level'] == '3'
                and producer['profile']['test'] is False and producer['features'] == [],
                'frozen product does not name an actual opt3/default Cargo producer')
        path = BASE / 'candidate' / name
        require(Path(item['path']) == path and path.is_file() and not path.is_symlink()
                and path.stat().st_nlink == 1 and path.stat().st_size == item['bytes']
                and digest(path) == item['sha256'], 'frozen candidate product identity changed: ' + name)
        require(item['actual_cargo_product'] == producer['executable'], 'Cargo executable path differs')
        if verify_mutable_products:
            require(digest(item['actual_cargo_product']) == item['sha256'],
                    'mutable Cargo output no longer matches the just-closed product: ' + name)
    require(identity['executable_sha256'] == frozen['products']['scriptw']['sha256'],
            'candidate CLI identity differs from actual frozen product')
    baseline_report_path = HISTORY / 'engine-allocation-probe/report.json'
    baseline_report = read(baseline_report_path)
    helper = HISTORY / 'engine_allocation_diagnostic.rs'
    require(baseline_report['complete'] is True and baseline_report['executed'] is True
            and digest(helper) == baseline_report['helper_source']['sha256'],
            'comparison helper source differs from the closed baseline diagnostic')
    authority = dict(source_commit=source, source_fingerprint=fingerprint,
                     candidate_identity=pin(identity_path), frozen_products=pin(frozen_path),
                     campaign=pin(campaign_path), release_receipt=pin(release_path),
                     release_transcript=pin(release_log), cargo_log=pin(cargo_path),
                     baseline_diagnostic=pin(baseline_report_path), helper_source=pin(helper))
    require(hashlib.sha256(raw).hexdigest() == authority['cargo_log']['sha256'],
            'Cargo log changed while reading authority')
    return authority, rows


def engine_producer(rows):
    found = {}
    for row in rows:
        if (row.get('reason') == 'compiler-artifact' and row.get('target', {}).get('name') == 'scriptw_engine'
                and row['target']['kind'] == ['lib'] and row['profile']['opt_level'] == '3'
                and row['profile']['test'] is False and row['features'] == []):
            require(Path(row['manifest_path']).resolve() == ROOT / 'crates/scriptw-engine/Cargo.toml',
                    'engine producer belongs to another source tree')
            libraries = [Path(path) for path in row['filenames'] if path.endswith('.rlib')]
            require(len(libraries) == 1, 'actual engine producer needs one rlib')
            found[str(libraries[0].resolve())] = (row, libraries[0])
    require(len(found) == 1, 'exactly one completed opt3/default engine rlib required')
    return next(iter(found.values()))


def freeze():
    require(len(os.sched_getaffinity(0)) == 1, 'freeze requires inherited one-CPU affinity')
    authority, rows = closed_authority(verify_mutable_products=True)
    producer, engine = engine_producer(rows)
    require(not DIRECTORY.exists() and not MANIFEST.exists(), 'refusing to overwrite frozen or partial candidate inputs')
    DIRECTORY.mkdir()
    (DIRECTORY / 'deps').mkdir()
    manifest = dict(schema='scriptw-frozen-engine-link-inputs-v1', complete=False,
                    source_commit=authority['source_commit'], source_fingerprint=authority['source_fingerprint'],
                    prepared_at=stamp(), authority=authority, cargo_log=authority['cargo_log'],
                    freezer=pin(__file__), files=[], native_search_paths=[],
                    copy_policy='Independent reflink-only CoW files, never hardlinks; actual closed opt3/default '
                                'engine producer and available Cargo dependency search set. No compilation or product execution.')

    def save():
        pending = MANIFEST.with_suffix('.pending')
        pending.write_text(json.dumps(manifest, indent=2) + '\n')
        pending.replace(MANIFEST)

    def copy(original, target, row):
        require(original.is_file() and not target.exists(), 'missing/duplicate actual link input: ' + str(original))
        target.parent.mkdir(parents=True, exist_ok=True)
        subprocess.run(['cp', '--reflink=always', '--', str(original), str(target)], check=True)
        sha = digest(target)
        require(digest(original) == sha and target.stat().st_nlink == 1,
                'copy differs from actual Cargo link input or is hardlinked')
        manifest['files'].append(dict(original_path=str(original), resolved_original_path=str(original.resolve()),
                                      frozen_path=str(target.relative_to(BASE)), sha256=sha,
                                      bytes=target.stat().st_size, cargo_producer=row))
        if original.resolve() == engine.resolve():
            require(row == producer, 'engine rlib producer changed')
            manifest['engine_rlib'] = str(target.relative_to(BASE))
            manifest['engine_rlib_sha256'] = sha

    save()
    seen = set()
    for row in rows:
        if row.get('reason') != 'compiler-artifact' or row.get('profile', {}).get('test'):
            continue
        for name in row.get('filenames', []):
            original = Path(name)
            if original.suffix not in ['.rlib', '.so'] or str(original.resolve()) in seen:
                continue
            seen.add(str(original.resolve()))
            copy(original, DIRECTORY / 'deps' / original.name, row)
    # Match baseline search ordering: product Wasmtime producer before the
    # earlier host build-script helper producer. Keep distinct native owners.
    native = [row for row in rows if row.get('reason') == 'build-script-executed' and row.get('linked_paths')]
    seen_native = set()
    for row in reversed(native):
        for value in row['linked_paths']:
            kind, equals, name = value.partition('=')
            require(equals and kind == 'native', 'unreviewed native link search kind')
            original = Path(name)
            if str(original.resolve()) in seen_native:
                continue
            seen_native.add(str(original.resolve()))
            target = DIRECTORY / 'native' / original.parent.name
            require(not target.exists(), 'distinct native producers collide')
            target.mkdir(parents=True)
            manifest['native_search_paths'].append(str(target.relative_to(BASE)))
            for archive in sorted(original.glob('*.a')):
                copy(archive, target / archive.name, row)
    require('engine_rlib' in manifest, 'frozen input inventory omitted the actual engine')
    after, _ = closed_authority(verify_mutable_products=True)
    require(after == authority, 'closed authority changed while freezing inputs')
    manifest.update(complete=True, bytes=sum(item['bytes'] for item in manifest['files']), finished_at=stamp())
    save()
    validate_frozen_inputs()
    print(json.dumps(dict(frozen=True, source_commit=manifest['source_commit'], files=len(manifest['files']),
                          logical_bytes=manifest['bytes'], engine_rlib_sha256=manifest['engine_rlib_sha256'],
                          manifest=str(MANIFEST), native_execution=False)))


def validate_frozen_inputs():
    authority, rows = closed_authority()
    inputs = read(MANIFEST)
    require(inputs.get('schema') == 'scriptw-frozen-engine-link-inputs-v1' and inputs.get('complete') is True
            and inputs['source_commit'] == authority['source_commit']
            and inputs['source_fingerprint'] == authority['source_fingerprint']
            and inputs['authority'] == authority and inputs['cargo_log'] == authority['cargo_log'],
            'frozen candidate input authority changed or remains partial')
    require(digest(inputs['freezer']['path']) == inputs['freezer']['sha256'], 'recorded freezer source changed')
    producer, original_engine = engine_producer(rows)
    engine = BASE / inputs['engine_rlib']
    seen, engines = set(), []
    for item in inputs['files']:
        path = BASE / item['frozen_path']
        require(path.is_relative_to(DIRECTORY) and path not in seen and path.is_file() and not path.is_symlink()
                and path.stat().st_nlink == 1 and path.stat().st_size == item['bytes']
                and digest(path) == item['sha256'] and item['cargo_producer'] in rows,
                'frozen candidate link input differs: ' + str(path))
        seen.add(path)
        if path == engine:
            engines.append(item)
    require(len(engines) == 1 and engines[0]['cargo_producer'] == producer
            and engines[0]['original_path'] == str(original_engine)
            and engines[0]['sha256'] == inputs['engine_rlib_sha256']
            and sum(item['bytes'] for item in inputs['files']) == inputs['bytes'],
            'frozen actual engine producer/bytes do not reconcile')
    require(all((BASE / name).is_relative_to(DIRECTORY / 'native') and (BASE / name).is_dir()
                for name in inputs['native_search_paths']), 'native frozen search path escaped owner')
    # Original Cargo products/rlibs are mutable after the freeze. Validation
    # intentionally hashes independent frozen copies, not overwritten outputs.
    return inputs, engine


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--freeze', action='store_true')
    parser.add_argument('--plan-only', action='store_true')
    args = parser.parse_args()
    require(not (args.freeze and args.plan_only), 'choose freeze or plan-only')
    if args.plan_only:
        print(json.dumps(dict(prepared=True, native_execution=False, mutation=False,
                              requires=['closed successful release-products.json', 'terminal successful cargo-product.jsonl',
                                        'actual candidate/identity.json', 'actual frozen-products.json', 'campaign.json'],
                              destination=str(DIRECTORY), manifest=str(MANIFEST))))
    elif args.freeze:
        freeze()
    else:
        inputs, _ = validate_frozen_inputs()
        print(json.dumps(dict(validated=True, source_commit=inputs['source_commit'], native_execution=False)))


if __name__ == '__main__':
    try:
        main()
    except (KeyError, ValueError, OSError, TypeError, subprocess.SubprocessError) as error:
        raise SystemExit('candidate link input freezer refused: ' + str(error))
