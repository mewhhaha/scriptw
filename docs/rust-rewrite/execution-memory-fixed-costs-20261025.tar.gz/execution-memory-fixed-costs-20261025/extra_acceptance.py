"""Run the authority-token doctest and real embedding examples serially."""
import pathlib
import subprocess
import sys

root = pathlib.Path(__file__).resolve().parent
checks = [
    ('trust-token-doctest', ['cargo', 'test', '--locked', '--offline', '--release', '--jobs', '1', '-p', 'scriptw-intl-build-data', '--doc']),
    ('embedding-examples-build', ['cargo', 'build', '--locked', '--offline', '--release', '--jobs', '1', '-p', 'scriptw-engine', '--example', 'foreign_modules', '--example', 'retained_embedding']),
]
for label, command in checks:
    code = subprocess.call([sys.executable, '-B', str(root / 'run_check.py'), label, *command])
    if code:
        sys.exit(code)
target = pathlib.Path('/tmp/scriptw-v8-target-20261024/release/examples')
for name in ['foreign_modules', 'retained_embedding']:
    code = subprocess.call([sys.executable, '-B', str(root / 'run_check.py'), 'example-' + name, str(target / name)])
    if code:
        sys.exit(code)
