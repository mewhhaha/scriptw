This final campaign is prepared as source and small metadata only. It has no
candidate commit placeholder. Actual execution requires campaign.json and the
new candidate/identity.json to agree on the real committed candidate source.
Root owns product/native builds, candidate freezing and all native execution.

The baseline remains the exact published clean 9b compiler. Its three frozen
products, identity and closed allocation diagnostic are external authorities at
their original paths under target/memory-fixed-costs-20261025. The small
baseline-reference.json pins those paths and bytes. No ELF, rlib, native archive
or closed baseline report was copied, rewritten or relabelled for this campaign.

The score remains two separate complete cohorts: 17 original fresh-Store/context
fixtures, and 17 strictly transformed existing-Realm call fixtures. Each has
baseline/candidate/candidate/baseline rounds, seven measured samples after ten
warmups, and alternating runtime order. --plan-only on measure.py,
measure_calls.py or measure_all.py runs no compiler/workload and needs no future
candidate identity. All ordinary child environments remove native perf-map,
row-phase and debug instrumentation; policies and actual binary/harness hashes
are retained. The separate one-case Intl first-use diagnostic never enters the
17-case scores or graph.

After root's successful closed release-products.json and actual candidate
product freeze, the prepared freeze_candidate_link_inputs.py can independently
reflink the new actual Cargo link inputs. The candidate allocation driver uses
the exact original helper .rs, with the same three cases, two invocations and
35 acknowledged boundaries. Its source/fingerprint comes only from the actual
closed candidate authority. The legitimate 9b baseline report remains external
and untouched. The full new diagnostic still requires actual root execution.

measure_all.py has no cleanup invocation, import or --apply path. It checks at
least 5 GiB free before creating any scored round and refuses overwrite of
closed or partial observations. An optional deletion action was initially
rejected before launch. After the user explicitly approved the exact 22 targets,
the approved attempt found the shared release directory already absent and
removed nothing. These facts remain development history; no automatic cleanup
is permitted or needed here.

The publisher is read-only by default and keeps conformance(Evidence()) usable
without any future performance outputs. Candidate source is resolved lazily
from actual frozen identity. It requires all 31 complete final native targets,
all eleven nonzero focused regression groups (overlaps are never added),
the full selected 7,746-case native replay, both actual 17-case ABBA comparisons,
the allocation pairs, separate Intl diagnostic and size-only native-map probe.
It also requires a separate GNU time1.9 exact RegExp child-memory proof with a
fresh empty Scriptw disk cache (the OS page cache is not flushed). This repeats
an accepted case and adds zero native/performance cases.
The README chart schemas stay unchanged; instrumented map RSS is never used as
ordinary execution memory. --publish refuses to overwrite a checkpoint.

The earlier 356d campaign is preserved at its original location, including
6,029 successful checks across 25 closed targets, 64 completed lines in a failed
aggregate, its aggregate and isolated kernel OOM observations, the mid-source
allocation measurements and abandoned cleanup attempts. These are development
observations, not accepted final native/performance totals. Final accepted
zero-OOM receipts cannot erase the two actual historical OOM incidents.

The separate 3914 campaign is also preserved at its original paths under
target/memory-fixed-costs-final-20261025. Engine batch011 actually returned101
with three passes and five failures in the old RegExp corruption-fixture
initializer lookup; those assertions ran before the intended semantic checks.
Its successful Engine prefix, failed transcript, frozen product identities and
35 allocation boundaries are development evidence only. The actual repaired
commit must produce its own frozen products, complete native verification,
allocation diagnostic and scored measurements here. No 3914 observation is
relabelled as the repaired source or added to final acceptance/resources.
The actual development repair filter passed all six unchanged semantic test
bodies under source 3914 plus exact patch03435bfaa280871eb75cc5b202709d6b9149be529f953bccebdcf2b4fdbd3754;
that original receipt and patch remain outside final acceptance.

The two historical Cargo producer JSONLs are archived losslessly as individual
deterministic gzip members. The manifest and checkpoint record their original
logical paths, decoded lengths/raw SHA-256 and encoded SHA-256. Validators still
read and verify the original raw files, then verify gzip recovery before and
after archiving. No producer row or field is selected away. The graph-reader
32 MiB compressed/256 MiB expanded/64 MiB member/16 MiB selected budgets remain
unchanged; historical wrapped producer logs are not selected chart reports.

Preparation checks parsed all new Python files, verified the external 9b
reference, checked the 17/17/8 pure plans, imported the publisher without a future
candidate, and reconciled the original development observations. No native
commands, executor modes, builds or workloads ran during this preparation.
