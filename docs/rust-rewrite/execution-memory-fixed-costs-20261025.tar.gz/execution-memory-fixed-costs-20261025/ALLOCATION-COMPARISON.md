# Fixed runtime allocation diagnostic comparison

One distinct standalone helper process per product/case, two invocations, identical source/callbacks; diagnostic requested Rust bytes and acknowledged process residency, not ordinary performance scores.

Each value is MiB (1,048,576 bytes). Every phase pair comes from the actual closed helper reports; this table is separate from ordinary README benchmark scores.

| Case / phase | Requested Rust live before → after | Process RSS before → after | RSS change |
| --- | ---: | ---: | ---: |
| scalar / before_engine | 0.001 → 0.001 | 5.004 → 4.922 | -1.64% |
| scalar / after_engine | 0.001 → 0.001 | 5.133 → 5.051 | -1.60% |
| scalar / after_compilation | 6.301 → 6.359 | 28.504 → 28.605 | +0.36% |
| scalar / after_execution_1 | 64.766 → 6.759 | 135.652 → 35.492 | -73.84% |
| scalar / after_dropping_profile_1 | 64.765 → 6.759 | 135.652 → 35.492 | -73.84% |
| scalar / after_execution_2 | 64.766 → 6.759 | 135.652 → 35.492 | -73.84% |
| scalar / after_dropping_profile_2 | 64.765 → 6.759 | 135.652 → 35.492 | -73.84% |
| scalar / after_dropping_artifact | 63.699 → 5.635 | 135.117 → 34.930 | -74.15% |
| scalar / after_dropping_engine | 63.699 → 5.635 | 135.117 → 34.930 | -74.15% |
| print / before_engine | 0.001 → 0.001 | 4.961 → 4.762 | -4.02% |
| print / after_engine | 0.001 → 0.001 | 5.152 → 4.953 | -3.87% |
| print / after_compilation | 64.784 → 6.723 | 179.305 → 72.699 | -59.45% |
| print / guest_start_1 | 66.930 → 8.866 | 291.332 → 117.043 | -59.82% |
| print / guest_body_finished_1 | 66.930 → 8.866 | 291.332 → 117.293 | -59.74% |
| print / after_execution_1 | 66.074 → 8.010 | 208.508 → 105.980 | -49.17% |
| print / after_dropping_profile_1 | 66.073 → 8.009 | 208.508 → 105.980 | -49.17% |
| print / guest_start_2 | 66.930 → 8.866 | 291.254 → 116.965 | -59.84% |
| print / guest_body_finished_2 | 66.930 → 8.866 | 291.254 → 117.215 | -59.76% |
| print / after_execution_2 | 66.074 → 8.010 | 208.508 → 105.980 | -49.17% |
| print / after_dropping_profile_2 | 66.073 → 8.009 | 208.508 → 105.980 | -49.17% |
| print / after_dropping_artifact | 65.913 → 7.849 | 208.508 → 105.902 | -49.21% |
| print / after_dropping_engine | 65.913 → 7.849 | 208.508 → 105.902 | -49.21% |
| retained / before_engine | 0.001 → 0.001 | 5.043 → 4.820 | -4.42% |
| retained / after_engine | 0.001 → 0.001 | 5.172 → 4.949 | -4.31% |
| retained / after_compilation | 64.784 → 6.723 | 180.961 → 74.574 | -58.79% |
| retained / guest_start_1 | 66.903 → 8.840 | 292.824 → 120.172 | -58.96% |
| retained / guest_body_finished_1 | 66.904 → 8.841 | 318.824 → 149.672 | -53.06% |
| retained / after_execution_1 | 66.048 → 7.984 | 210.000 → 109.109 | -48.04% |
| retained / after_dropping_profile_1 | 66.047 → 7.983 | 210.000 → 109.109 | -48.04% |
| retained / guest_start_2 | 66.903 → 8.840 | 292.773 → 120.121 | -58.97% |
| retained / guest_body_finished_2 | 66.904 → 8.841 | 318.781 → 149.629 | -53.06% |
| retained / after_execution_2 | 66.048 → 7.984 | 210.000 → 109.109 | -48.04% |
| retained / after_dropping_profile_2 | 66.047 → 7.983 | 210.000 → 109.109 | -48.04% |
| retained / after_dropping_artifact | 65.886 → 7.823 | 210.000 → 109.008 | -48.09% |
| retained / after_dropping_engine | 65.886 → 7.822 | 210.000 → 109.008 | -48.09% |

The complete 35 phase pairs retain raw smaps, coherent requested/released/live counters, both invocations, source/rlib/helper hashes and all commands. Baseline source is9b7746531c4b3bff0ecbb863d7d70dfead12455b; candidate source is44e17ee4c73eeab6cc970804199109aa2aee51a9. The helper source is byte-identical. All reductions remain observational; the counters do not by themselves assign each saved page or allocation to a component.

- Requested Rust GlobalAlloc sizes exclude allocator usable/resident bytes and native allocations bypassing GlobalAlloc.
- Anonymous mappings do not identify live JavaScript or Intl ownership; no exact causal subtraction between counters.
- Private file-backed native mappings change residency/reclaimability; cold-file/page-cache state and shared pages affect RSS/PSS.
- Baseline has no saved outer JSON cap receipt; original console policy confirmation remains explicit.
- One-entry/64MiB module cache cannot retain the full R image; default SDK512MiB retention differs.
- Native perf-map hashing is disabled. RSS/capacity/virtual address space, logical requested peaks and guest live memory remain distinct.
