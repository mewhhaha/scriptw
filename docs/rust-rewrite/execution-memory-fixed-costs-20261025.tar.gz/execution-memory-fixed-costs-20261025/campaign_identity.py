"""Pure identity admission for the ignored fixed-cost memory campaign.

Candidate authority is intentionally unresolved until real frozen products and
campaign.json exist. Importing this module never invents a candidate revision.
"""
import hashlib
import json
import os
from pathlib import Path
import re

BASE = Path(__file__).resolve().parent
REPO = BASE.parent.parent
HISTORY = REPO / 'target/memory-fixed-costs-20261025'
BASELINE_DIRECTORY = HISTORY / 'baseline'
BASELINE_DIAGNOSTIC_DIRECTORY = HISTORY / 'engine-allocation-probe'
ALLOCATION_HELPER = HISTORY / 'engine_allocation_diagnostic.rs'

def product_directory(product):
    require(product in ['baseline', 'candidate'], 'unknown frozen product')
    return BASELINE_DIRECTORY if product == 'baseline' else BASE / 'candidate'

BASELINE_SOURCE = '9b7746531c4b3bff0ecbb863d7d70dfead12455b'
BASELINE_FINGERPRINT = '63e8809064ad0b52eed24e836fe5fb5bfdc97c2a23df9399601694d790ec88b1'
BASELINE_PRODUCTS = {
    'scriptw': '88403c2980cfbcdc0cc902bed8fca9078b7281e49ff249e2ca5729a078bd10a1',
    'runtime_baseline': '038c895a67df861288a5d9166098fc3a545a6afd51326849546dc6e1e4043f7d',
    'runtime_boundaries': '966daad5e898b9d483c3042762d5ce4a1430880cf53d30a6ebc8dc07a31355b6',
}
INSTRUMENTATION = (
    'SCRIPTW_PERF_MAP_DIR', 'SCRIPTW_WASM_TRACE', 'SCRIPTW_WASM_TRACE_DUMP',
    'SCRIPTW_EMIT_SIZE_REPORT', 'SCRIPTW_ROW_PERF_CONTROL', 'SCRIPTW_ROW_PERF_ACK',
    'SCRIPTW_ROW_PERF_REGION', 'SCRIPTW_BOUNDARY_READY_FD', 'SCRIPTW_BOUNDARY_READY_NONCE',
)


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def baseline_authority():
    reference = read(BASE / 'baseline-reference.json')
    require(reference.get('schema') == 'scriptw-external-baseline-reference-v1'
            and reference.get('baseline_source') == BASELINE_SOURCE
            and reference.get('product_directory') == str(BASELINE_DIRECTORY)
            and reference.get('development_campaign_directory') == str(HISTORY),
            'external baseline reference changed')
    expected = {'identity': BASELINE_DIRECTORY / 'identity.json',
                'allocation_report': BASELINE_DIAGNOSTIC_DIRECTORY / 'report.json',
                'helper_source': ALLOCATION_HELPER}
    for key, path in expected.items():
        require(reference[key]['path'] == str(path) and digest(path) == reference[key]['sha256'],
                'external baseline authority bytes changed: ' + key)
    return reference


def checked_identity(product):
    require(product in ['baseline', 'candidate'], 'unknown frozen product')
    identity = read(product_directory(product) / 'identity.json')
    require(identity.get('source_fingerprint_scheme') == 'scriptw-program-cache-compiler-v3'
            and re.fullmatch(r'[0-9a-f]{64}', identity.get('source_fingerprint', ''))
            and re.fullmatch(r'[0-9a-f]{64}', identity.get('executable_sha256', '')),
            product + ': malformed actual compiler identity')
    revision = identity.get('source_revision', {})
    require(revision.get('kind') == 'git-commit'
            and re.fullmatch(r'(?:[0-9a-f]{40}|[0-9a-f]{64})', revision.get('commit', '')),
            product + ': missing actual Git source identity')
    if product == 'baseline':
        baseline_authority()
        require(revision['commit'] == BASELINE_SOURCE
                and identity['source_fingerprint'] == BASELINE_FINGERPRINT
                and identity['executable_sha256'] == BASELINE_PRODUCTS['scriptw'],
                'baseline differs from the published clean 9b product')
    else:
        require(revision['commit'] != BASELINE_SOURCE, 'candidate cannot silently reuse baseline source identity')
    return identity


def candidate_source():
    campaign = read(BASE / 'campaign.json')
    identity = checked_identity('candidate')
    source = identity['source_revision']['commit']
    require(campaign.get('source_commit') == source and campaign.get('baseline_source') == BASELINE_SOURCE,
            'campaign source identities differ from actual frozen products')
    return source


def product_source(product):
    source = checked_identity(product)['source_revision']['commit']
    require(source == (BASELINE_SOURCE if product == 'baseline' else candidate_source()),
            'frozen product source differs from campaign')
    return source


def frozen_product(product):
    identity = checked_identity(product)
    # All accepted rounds launch from the actual clean candidate checkout.
    # This does not relabel the separately frozen 9b baseline compiler.
    candidate_source()
    directory = product_directory(product)
    hashes = {}
    for name in ['scriptw', 'runtime_baseline', 'runtime_boundaries']:
        path = directory / name
        require(path.is_file() and not path.is_symlink() and path.stat().st_nlink == 1,
                'missing/symlinked/hardlinked frozen product: ' + str(path))
        hashes[name] = digest(path)
        if product == 'baseline':
            require(hashes[name] == BASELINE_PRODUCTS[name], 'baseline product changed: ' + name)
    require(hashes['scriptw'] == identity['executable_sha256'], 'frozen CLI bytes differ from identity')
    return identity, hashes


def ordinary_environment(environment=None):
    result = dict(os.environ if environment is None else environment)
    for name in INSTRUMENTATION:
        result.pop(name, None)
    result.pop('NODE_OPTIONS', None)
    result.pop('NODE_COMPILE_CACHE', None)
    result['NODE_DISABLE_COMPILE_CACHE'] = '1'
    result['SCRIPTW_COMPILER_CACHE_IMAGE_HASH'] = 'sha256'
    result.update(CARGO_BUILD_JOBS='1', SCRIPTW_JOBS='1', RUST_TEST_THREADS='1', RAYON_NUM_THREADS='1',
                  SCRIPTW_MODULE_MEMORY_CACHE_ENTRIES='1',
                  SCRIPTW_MODULE_MEMORY_CACHE_LIMIT_BYTES=str(64 * 1024**2))
    return result


def environment_receipt(environment):
    keys = [*INSTRUMENTATION, 'NODE_OPTIONS', 'NODE_COMPILE_CACHE', 'NODE_DISABLE_COMPILE_CACHE',
            'SCRIPTW_COMPILER_CACHE_IMAGE_HASH', 'CARGO_BUILD_JOBS', 'SCRIPTW_JOBS', 'RUST_TEST_THREADS',
            'RAYON_NUM_THREADS', 'SCRIPTW_MODULE_MEMORY_CACHE_ENTRIES', 'SCRIPTW_MODULE_MEMORY_CACHE_LIMIT_BYTES']
    return {name: environment.get(name) for name in keys}


def validate_environment(environment):
    expected = environment_receipt(ordinary_environment({}))
    require(environment == expected, 'ordinary environment/cache policy or disabled instrumentation differs')
