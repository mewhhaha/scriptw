from pathlib import Path
import hashlib,json,struct,sys
ROOT=Path(__file__).resolve().parents[2];SOURCE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'scripts'))
from benchmark_metrics import digest,measure_process
from limited_verification import limited_environment,require_kernel_budget
require_kernel_budget(4*1024**3)
label=sys.argv[1];host=Path(sys.argv[2]).resolve(strict=True)
OUT=ROOT/'target/native-depth-index-20261102';OUT.mkdir(exist_ok=True)
work=OUT/label;work.mkdir();(work/'tmp').mkdir();(work/'cache').mkdir()
wasm=SOURCE/'ssr-cpp-prepared/react-ssr.js.wasm'
env=limited_environment();env.update(TMPDIR=str(work/'tmp'),SCRIPTW_CACHE_DIR=str(work/'cache'),SCRIPTW_JOBS='1')
argv=[str(host),'prepare-wasi',str(wasm),str(work/'native.image')]
print(label,'START',flush=True)
with (work/'stdout').open('xb') as stdout,(work/'stderr').open('xb') as stderr:
    resources=measure_process(argv,cwd=ROOT,env=env,stdout=stdout,stderr=stderr,timeout=60,time_binary=ROOT/'target/performance-worker-cpu/tools/time')
result=dict(label=label,purpose='Compile-only frozen Wasm diagnostic using existing producer; no WASI instantiation or cross-engine score',argv=argv,wasm_sha256=digest(wasm),executable_sha256=digest(host),resources=resources,stdout_sha256=digest(work/'stdout'),stderr_sha256=digest(work/'stderr'))
if resources['exit_code']==0 and not resources['timed_out']:
    report=json.loads((work/'stdout').read_text());result['report']=report
    image=(work/'native.image').read_bytes();assert image[:8]==b'SCRWWA01'
    wasm_bytes,native_bytes=struct.unpack_from('<QQ',image,40)
    assert image[56:56+wasm_bytes]==wasm.read_bytes()
    native=image[56+wasm_bytes:56+wasm_bytes+native_bytes];assert native[:6]==b'\x7fELF\x02\x01'
    shoff=struct.unpack_from('<Q',native,40)[0];entsize,count,names=struct.unpack_from('<HHH',native,58)
    sections=[struct.unpack_from('<IIQQQQIIQQ',native,shoff+i*entsize) for i in range(count)]
    table=sections[names];strings=native[table[4]:table[4]+table[5]]
    hashes={}
    for section in sections:
        name=strings[section[0]:].split(b'\0',1)[0].decode()
        if section[1]!=8:hashes[name]={'bytes':section[5],'sha256':hashlib.sha256(native[section[4]:section[4]+section[5]]).hexdigest()}
    result['native_sha256']=hashlib.sha256(native).hexdigest();result['native_sections']=hashes
    assert '.text' in hashes
(work/'result.json').write_text(json.dumps(result,indent=2)+'\n')
print(label,resources['exit_code'],resources['elapsed_ns']/1e9,result.get('report',{}).get('phases_ns'),flush=True)
