# Local patch

Upstream: `cranelift-codegen` 0.134.0 from crates.io, licensed
`Apache-2.0 WITH LLVM-exception`; the original `LICENSE` is included.
Published archive SHA-256:
`dce9c62e5e11d12f4a8f5f939f29899f32002d38193b47491e2539705a1d447e`.

Only `src/ctxhash.rs` differs from the published source. Cached hashes remain
`u32`; each hash passed to hashbrown's table, including both rehash callbacks,
expands to `u64::from(hash) | (u64::from(hash) << 32)`. This supplies hashbrown
0.17's seven-bit control tags on 64-bit hosts instead of making every tag zero.
The low 32 primary-bucket bits, bucket layout, contextual equality and existing
entry rehash recomputation remain unchanged. Primary bucket selection is
preserved for tables with at most 2^32 buckets. No ordering guarantee is added.

Unit regressions cover tag bits and contextual aliases across growth through
both insertion APIs. Production performance requires measurement of this exact
patched build; the change alone establishes no React compilation speedup.
