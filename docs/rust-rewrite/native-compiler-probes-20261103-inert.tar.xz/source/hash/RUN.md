Source-only candidate for cranelift-codegen 0.134.0 `src/ctxhash.rs`.
No builds or test executions were performed by the authoring agent.

Apply `candidate.patch` with the vendored crate as the working directory (`patch -p1`).
It includes the conversion at every HashTable hash input and both rehash closures,
plus tag-bit and contextual-alias/growth regressions. Its entry rehash closure
continues to recompute contextual hashes, matching the original semantics.

The isolated package uses the exact cached hashbrown 0.17.1 and rustc-hash 2.1.2
versions, with the same selected features as cranelift-codegen. Its library is a
copy of the pinned ctxhash source plus the patch; the extra `probe_counts` module
compares legacy and candidate raw predicate counts and physical bucket indices.
This synthetic collision cohort diagnoses SwissTable tag filtering; it is not a
React/native-codegen performance measurement. It checks no wall-clock threshold.

From the workspace root, after obtaining the exclusive verification CPU lane:

```sh
python3 -B scripts/limited_verification.py -- cargo test --offline --manifest-path target/native-hash-tags-20261102/Cargo.toml --target-dir target/native-hash-tags-20261102/build -- --test-threads=1 --nocapture
```

The command should select four tests: existing basic test, cached-tag-bit test,
mixed insert/entry growth test, and raw probe-count test. On 32-bit hosts the last
one is deliberately absent because hashbrown already uses the cached hash's high
seven bits there. Report actual counts only after execution.

Risks and preserved properties:

- Cached hashes stay u32, key/value layout and contextual equality are unchanged.
- All table operations and rehash callbacks must use the same expansion. Mixing
  zero-extended and replicated hashes makes keys unreachable after lookup/growth.
- The low 32 bits and hence physical bucket starts stay unchanged for tables of
  at most 2^32 buckets; the helper changes 64-bit primary-hash bits above that.
  Such enormous tables are outside practical use but the claim is bounded.
- CtxHashMap exposes no iterator. The isolated probe checks HashTable bucket
  indices and iteration order for this cohort. Do not infer a public ordering
  contract from it, or claim every possible rehash layout is proven unchanged.
- Equal contextual keys still need equal/stable contextual hashes as before.
  This patch intentionally preserves the original entry closure's recomputation
  rather than introducing a separate cache/lifecycle behavior change.
