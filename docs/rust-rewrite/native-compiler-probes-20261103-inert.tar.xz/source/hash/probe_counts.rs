//! Count raw hash-table predicate visits, rather than timing or CtxEq calls.
//! CtxHashMap's cached-u32 guard prevents most visits from reaching CtxEq.

use hashbrown::HashTable;
use std::cell::Cell;

fn zero_extend(hash: u32) -> u64 {
    u64::from(hash)
}

fn make_table(expand: fn(u32) -> u64) -> HashTable<u32> {
    let mut table = HashTable::with_capacity(256);
    // Same primary bucket on any realistic table, distinct seven-bit tags.
    // Leave tag 127 absent so the missing query scans the occupied probe chain.
    for tag in 0..127 {
        let hash = (tag << 25) | 7;
        table.insert_unique(expand(hash), hash, |stored| expand(*stored));
    }
    table
}

fn find_count(table: &HashTable<u32>, hash: u32, expand: fn(u32) -> u64) -> (bool, usize) {
    let count = Cell::new(0);
    let found = table
        .find(expand(hash), |stored| {
            count.set(count.get() + 1);
            *stored == hash
        })
        .is_some();
    (found, count.get())
}

#[test]
#[cfg(target_pointer_width = "64")]
fn probe_counts() {
    let legacy = make_table(zero_extend);
    let candidate = make_table(crate::table_hash);
    assert_eq!(legacy.len(), candidate.len());
    assert_eq!(
        legacy.iter().copied().collect::<Vec<_>>(),
        candidate.iter().copied().collect::<Vec<_>>()
    );

    let mut legacy_hits = 0;
    let mut candidate_hits = 0;
    for tag in 0..127 {
        let hash = (tag << 25) | 7;
        let (legacy_found, legacy_count) = find_count(&legacy, hash, zero_extend);
        let (candidate_found, candidate_count) = find_count(&candidate, hash, crate::table_hash);
        assert!(legacy_found);
        assert!(candidate_found);
        legacy_hits += legacy_count;
        candidate_hits += candidate_count;
        assert_eq!(candidate_count, 1);
        assert_eq!(
            legacy.find_bucket_index(zero_extend(hash), |stored| *stored == hash),
            candidate.find_bucket_index(crate::table_hash(hash), |stored| *stored == hash)
        );
    }
    let missing_hash = (127 << 25) | 7;
    let (legacy_found, legacy_miss) = find_count(&legacy, missing_hash, zero_extend);
    let (candidate_found, candidate_miss) = find_count(&candidate, missing_hash, crate::table_hash);
    assert!(!legacy_found);
    assert!(!candidate_found);
    assert_eq!(candidate_miss, 0);
    assert!(legacy_miss >= 127);
    assert!(legacy_hits > candidate_hits * 32);

    println!("127 occupied keys; all share initial bucket; distinct cached-hash tags");
    println!(
        "raw predicate calls across 127 successful lookups: legacy={legacy_hits} candidate={candidate_hits}"
    );
    println!(
        "raw predicate calls for one missing tag: legacy={legacy_miss} candidate={candidate_miss}"
    );
}
