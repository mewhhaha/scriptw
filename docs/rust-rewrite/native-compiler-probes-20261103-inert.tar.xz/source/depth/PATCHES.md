# Indexed GVN scope depths

This is the crates.io `cranelift-codegen` 0.134.0 release, retaining its
Apache-2.0 WITH LLVM-exception license. The original crate checksum is
`dce9c62e5e11d12f4a8f5f939f29899f32002d38193b47491e2539705a1d447e`.
Its upstream commit is `39d67168cdb6911ffdc961381314b6fed62e3c93`, path
`cranelift/codegen`. Registry installation/checksum markers are omitted.

The only modified upstream source is `src/egraph/mod.rs`. The new private
`src/egraph/gvn_scope.rs` pairs the existing active dominator-block stack with
a block-indexed depth table. Push and pop maintain both together; lookups retain
the exact previous zero-based stack index, including index zero for the entry
block. Popped scopes are invalidated before sibling traversal.

This replaces a reverse stack scan for each newly optimized pure instruction
with an indexed lookup. GVN keys, scoped-map generations, traversal order,
optimization rules, compiler settings and native-code policy are unchanged.
The additional table uses one `usize` per allocated block index encountered.
The contextual hash table is unchanged.

The focused unit filter is `egraph::gvn_scope::tests::`. It covers root/nested
indices, sibling replacement, inactive and duplicate scopes, and the real
dominator traversal of a 2,048-block success-continuation spine. It has no
timing assertions. Native-code identity and compilation-time effects require
separate comparison using identical Wasm inputs and compiler settings.
