//! Active dominator scopes and their exact indices in the GVN block stack.

use crate::ir::Block;
use alloc::vec::Vec;
use cranelift_entity::SecondaryMap;

const INACTIVE: usize = usize::MAX;

/// Keep the lookup index with its stack owner so sibling scopes cannot retain
/// stale depths. These are zero-based block-stack indices, not the scoped
/// hash map's depth, which includes an additional initial generation level.
pub(crate) struct GvnScopeStack {
    blocks: Vec<Block>,
    depth_by_block: SecondaryMap<Block, usize>,
}

impl GvnScopeStack {
    pub(super) fn new() -> Self {
        Self {
            blocks: Vec::new(),
            depth_by_block: SecondaryMap::with_default(INACTIVE),
        }
    }

    pub(super) fn push(&mut self, block: Block) {
        assert_eq!(
            self.depth_by_block[block], INACTIVE,
            "GVN scope is already active"
        );
        self.depth_by_block[block] = self.blocks.len();
        self.blocks.push(block);
    }

    pub(super) fn pop(&mut self) -> Option<Block> {
        let block = self.blocks.pop()?;
        self.depth_by_block[block] = INACTIVE;
        Some(block)
    }

    pub(super) fn last(&self) -> Option<&Block> {
        self.blocks.last()
    }

    pub(super) fn blocks(&self) -> &[Block] {
        &self.blocks
    }

    pub(super) fn depth(&self, block: Block) -> usize {
        let depth = self.depth_by_block[block];
        assert_ne!(depth, INACTIVE, "GVN scope is not active");
        debug_assert_eq!(self.blocks.get(depth), Some(&block));
        depth
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::cursor::{Cursor, FuncCursor};
    use crate::dominator_tree::DominatorTree;
    use crate::egraph::EgraphBlockIter;
    use crate::flowgraph::ControlFlowGraph;
    use crate::ir::{AbiParam, Function, InstBuilder, TrapCode, types};
    use cranelift_entity::EntityRef;

    #[test]
    fn scope_indices_follow_active_path_through_siblings() {
        let root = Block::new(40);
        let child = Block::new(7);
        let grandchild = Block::new(100);
        let sibling = Block::new(3);
        let mut scopes = GvnScopeStack::new();
        scopes.push(root);
        scopes.push(child);
        scopes.push(grandchild);
        assert_eq!(scopes.depth(root), 0);
        assert_eq!(scopes.depth(child), 1);
        assert_eq!(scopes.depth(grandchild), 2);
        assert_eq!(scopes.pop(), Some(grandchild));
        assert_eq!(scopes.pop(), Some(child));
        scopes.push(sibling);
        assert_eq!(scopes.blocks(), &[root, sibling]);
        assert_eq!(scopes.depth(root), 0);
        assert_eq!(scopes.depth(sibling), 1);
        assert_eq!(scopes.pop(), Some(sibling));
        assert_eq!(scopes.pop(), Some(root));
        assert_eq!(scopes.pop(), None);
        assert_eq!(scopes.last(), None);
        // Retiring a scope also permits a fresh traversal to reuse the owner.
        scopes.push(root);
        assert_eq!(scopes.depth(root), 0);
    }

    #[test]
    #[should_panic(expected = "GVN scope is not active")]
    fn popped_block_cannot_reuse_sibling_depth() {
        let mut scopes = GvnScopeStack::new();
        scopes.push(Block::new(0));
        scopes.push(Block::new(1));
        scopes.pop();
        scopes.push(Block::new(2));
        scopes.depth(Block::new(1));
    }

    #[test]
    #[should_panic(expected = "GVN scope is already active")]
    fn active_block_cannot_be_entered_twice() {
        let mut scopes = GvnScopeStack::new();
        scopes.push(Block::new(0));
        scopes.push(Block::new(0));
    }

    #[test]
    fn deep_dominator_spine_keeps_exact_stack_indices() {
        let mut function = Function::new();
        function.signature.params.push(AbiParam::new(types::I32));
        function.signature.returns.push(AbiParam::new(types::I32));
        let spine: Vec<_> = (0..2048).map(|_| function.dfg.make_block()).collect();
        let failure = function.dfg.make_block();
        let input = function.dfg.append_block_param(spine[0], types::I32);
        let mut cursor = FuncCursor::new(&mut function);
        for (index, &block) in spine.iter().enumerate() {
            cursor.insert_block(block);
            if let Some(&next) = spine.get(index + 1) {
                // Distinct pure expressions are available in the entry block
                // while their uses form a long chain of success continuations.
                let check = cursor.ins().iadd_imm(input, index as i64);
                cursor.ins().brif(check, next, &[], failure, &[]);
            } else {
                cursor.ins().return_(&[input]);
            }
        }
        cursor.insert_block(failure);
        cursor.ins().trap(TrapCode::unwrap_user(1));
        let cfg = ControlFlowGraph::with_function(cursor.func);
        let domtree = DominatorTree::with_function(cursor.func, &cfg);
        let mut scopes = GvnScopeStack::new();
        let mut visited = 0;
        let mut maximum_depth = 0;
        for block in EgraphBlockIter::new(&domtree) {
            while scopes
                .last()
                .is_some_and(|&parent| domtree.idom(block) != Some(parent))
            {
                scopes.pop();
            }
            scopes.push(block);
            assert_eq!(scopes.depth(spine[0]), 0);
            let depth = scopes.depth(block);
            assert_eq!(scopes.blocks()[depth], block);
            if block == failure {
                assert_eq!(depth, 1);
            }
            maximum_depth = maximum_depth.max(depth);
            visited += 1;
        }
        assert_eq!(visited, spine.len() + 1);
        assert_eq!(maximum_depth, spine.len() - 1);
    }
}
