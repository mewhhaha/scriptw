function joined(a, steps) {
  "use strict";
  var s = 0;
  for (var i = 0; i < steps; i++) s += a.join(",").length;
  return s;
}
var a = [];
for (var i = 0; i < 257; i++) a.push("x");
var total = 0;
for (var repeat = 0; repeat < 64; repeat++) total += joined(a, 1);
print(total);
