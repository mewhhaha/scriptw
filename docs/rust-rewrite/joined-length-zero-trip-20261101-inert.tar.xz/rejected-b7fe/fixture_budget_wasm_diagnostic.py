"""Read core Wasm code-body sizes from frozen old-compiler output, then discard images."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
CLI = ROOT / "target/performance-numeric-array-binding/candidate/scriptw"
IDENTITY = json.loads((CLI.parent / "identity.json").read_text())
SOURCES = OUT / "semantic-sources"
DEST = OUT / "fixture-budget-wasm-diagnostic"
LIMIT = 128 * 1024
EXPECTED = {
    "dense_number_chunks_preserve_sequential_writes_rounding_and_counter_sign.js",
    "exact_sum_accepts_safe_positive_and_negative_prefixes.js",
    "exact_sum_preserves_seed_boundaries_and_rounding_misses.js",
    "exact_sum_preserves_signed_zero_nonfinite_and_zero_trip_values.js",
    "exact_sum_retains_unsafe_intermediates_and_observable_coercions.js",
    "joined_length_preflight_keeps_late_coercions_holes_and_caps_observable.js",
    "joined_length_region_misses_preserve_live_methods_and_read_order.js",
    "joined_length_regions_preserve_utf16_and_number_arithmetic.js",
}


def u32(data, offset):
    value = 0
    shift = 0
    while True:
        byte = data[offset]
        offset += 1
        value |= (byte & 0x7f) << shift
        if byte < 0x80:
            return value, offset
        shift += 7
        if shift > 35:
            raise ValueError("invalid u32 LEB128")


def largest_body(path):
    data = path.read_bytes()
    assert data[:8] == b"\0asm\x01\0\0\0"
    offset = 8
    while offset < len(data):
        section_id = data[offset]
        section_size, payload = u32(data, offset + 1)
        end = payload + section_size
        if section_id == 10:
            count, cursor = u32(data, payload)
            sizes = []
            for _ in range(count):
                size, cursor = u32(data, cursor)
                sizes.append(size)
                cursor += size
            assert cursor == end
            return max(sizes, default=0), count
        offset = end
    raise ValueError("no core Wasm code section")


def sha(path):
    return hashlib.file_digest(path.open("rb"), "sha256").hexdigest()


def main():
    sources = sorted(SOURCES.glob("*.js"))
    assert {p.name for p in sources} == EXPECTED
    assert CLI.is_file() and os.access(CLI, os.X_OK)
    DEST.mkdir(parents=True, exist_ok=False)
    env = dict(os.environ)
    env.pop("SCRIPTW_WASM_TRACE", None)
    env.pop("SCRIPTW_WASM_DUMP", None)
    records = []
    for source in sources:
        stem = source.stem
        wasm = DEST / f"{stem}.wasm"
        stdout = DEST / f"{stem}.stdout"
        stderr = DEST / f"{stem}.stderr"
        env["SCRIPTW_WASM_DUMP"] = str(wasm)
        argv = [str(CLI), "--jobs", "1", "--host-surface", "test262", "build", "wasm", str(source)]
        started = time.perf_counter_ns()
        timed_out = False
        code = None
        with stdout.open("xb") as out, stderr.open("xb") as err:
            try:
                code = subprocess.run(argv, cwd=ROOT, env=env, stdout=out, stderr=err,
                    timeout=60, check=False).returncode
            except subprocess.TimeoutExpired:
                timed_out = True
        elapsed_ns = time.perf_counter_ns() - started
        runtime = Path(str(wasm) + ".runtime.wasm")
        body_bytes = None
        function_count = None
        wasm_sha = None
        if code == 0 and not timed_out and wasm.is_file():
            body_bytes, function_count = largest_body(wasm)
            wasm_sha = sha(wasm)
        for image in (wasm, runtime):
            if image.exists():
                image.unlink()
        record = dict(file=source.name, source_sha256=sha(source), argv=argv,
            compiler_sha256=sha(CLI), source_commit=IDENTITY["source_commit"],
            source_fingerprint=IDENTITY["source_fingerprint"], exit_code=code,
            timed_out=timed_out, elapsed_ns=elapsed_ns,
            largest_core_code_body_bytes=body_bytes, core_function_count=function_count,
            wasm_sha256=wasm_sha, stdout=stdout.name, stdout_sha256=sha(stdout),
            stderr=stderr.name, stderr_sha256=sha(stderr))
        (DEST / f"{stem}.receipt.json").write_text(json.dumps(record, indent=2) + "\n")
        records.append(record)
        print(source.name, code, body_bytes, flush=True)
    oversized = [r["file"] for r in records if r["largest_core_code_body_bytes"] is not None
        and r["largest_core_code_body_bytes"] > LIMIT]
    incomplete = [r["file"] for r in records if r["exit_code"] != 0 or r["timed_out"]
        or r["largest_core_code_body_bytes"] is None]
    summary = dict(status="complete" if not incomplete else "incomplete",
        purpose="old rejected12 compiler source-size diagnostic only; not candidate correctness evidence",
        compiler=str(CLI), compiler_sha256=sha(CLI), largest_core_code_body_limit_bytes=LIMIT,
        source_commit=IDENTITY["source_commit"], source_fingerprint=IDENTITY["source_fingerprint"],
        fixture_count=len(records), records=records, oversized_fixtures=oversized,
        incomplete_fixtures=incomplete,
        disposition="split oversized fixtures before compile" if oversized else "all fixtures within 128 KiB" if not incomplete else "incomplete")
    (DEST / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(dict(status=summary["status"], oversized_fixtures=oversized,
        incomplete_fixtures=incomplete, summary=str(DEST / "summary.json")), indent=2))


if __name__ == "__main__":
    main()
