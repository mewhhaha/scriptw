"""Create the inert UTF-8 evidence bundle and rejected zero-trip report."""
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import re
import stat
import tarfile

ROOT = Path(__file__).resolve().parents[2]
COHORT = ROOT / "target/performance-scalar-regions-next"
BOUNDARY = COHORT / "join-boundary"
REPORT = ROOT / "docs/rust-rewrite/joined-length-zero-trip-20261101.json"
ARCHIVE = REPORT.with_name("joined-length-zero-trip-20261101-inert.tar.xz")
EXTENSIONS = {".json", ".jsonl", ".log", ".stdout", ".stderr", ".py", ".patch",
    ".txt", ".csv", ".map", ".js", ".mjs", ".inventory", ".md", ".rs", ".html", ".wat"}
SKIP_PARTS = {"cache", "artifacts", "runtime-build", "verification-cache", "node_modules", ".git"}
MAX_BODY = 128 * 1024


def load(path):
    return json.loads(Path(path).read_text())


def sha(data):
    return hashlib.sha256(data).hexdigest()


def add(records, archive_path, path):
    path = Path(path)
    if not path.exists() or path.suffix.lower() not in EXTENSIONS:
        return
    mode = path.lstat().st_mode
    if path.is_symlink() or not stat.S_ISREG(mode) or mode & 0o111:
        raise ValueError(f"non-regular or executable evidence refused: {path}")
    payload = path.read_bytes()
    if payload.startswith((b"\x7fELF", b"\x00asm", b"MZ")):
        raise ValueError(f"binary payload refused: {path}")
    payload.decode("utf-8", errors="strict")
    pure = PurePosixPath(archive_path)
    if pure.is_absolute() or ".." in pure.parts:
        raise ValueError(f"unsafe member path: {archive_path}")
    if archive_path in records:
        raise ValueError(f"duplicate archive member: {archive_path}")
    records[archive_path] = payload


def add_tree(records, prefix, root):
    root = Path(root)
    if not root.exists():
        return
    for path in sorted(root.rglob("*")):
        if path.is_symlink() or not path.is_file():
            continue
        rel = path.relative_to(root)
        if any(part in SKIP_PARTS for part in rel.parts):
            continue
        if path.suffix.lower() == ".wat" and (root.name != "program-inspection" or path.name == "runtime.wat"):
            continue
        add(records, f"rejected-b7fe/{prefix}/{rel.as_posix()}", path)


def metric_rows(analysis):
    result = []
    for item in analysis["comparisons"]:
        result.append({"case": item["case"], "control": item["control"], "blocks": [
            {"block": row["block"], "median_change_percent": row["change_percent"]["block_median_of_invocation_medians_percent"],
             "mean_change_percent": row["change_percent"]["block_mean_of_invocation_means_percent"]}
            for row in item["blocks"]]})
    return result


def validate():
    candidate = load(COHORT / "candidate/identity.json")
    hosts = load(COHORT / "candidate/host-products.json")
    assert candidate["source_commit"] == "aeb7b0c31ac303f7462f9081e51760922a9495f9"
    assert candidate["source_fingerprint"] == "b7fe482be872af94a11247a63df4f306acbbf5799eba6da446b1bc393aaae544"
    assert candidate["executable_sha256"] == hosts["compiler_precompiled_baseline"]["sha256"]
    assert hosts["runtime_baseline"]["sha256"] == "2320792f8f184a3c022304062fc7fe23f2982f3ac576294607bccbd19dd6a0a6"

    analysis_path = BOUNDARY / "runs/20261101T014322Z-candidate-screen/analysis.json"
    analysis = load(analysis_path)
    assert analysis["status"] == "complete" and len(analysis["rows"]) == 160
    assert all(len(row["times_ns"]) == 21 for row in analysis["rows"])
    rows = {row["case"]: row for row in metric_rows(analysis)}
    zero = rows["join-boundary-256-trip0.js"]
    assert abs(zero["blocks"][0]["median_change_percent"] - 31.59942631449595) < 1e-10
    assert abs(zero["blocks"][0]["mean_change_percent"] - 30.50468659740144) < 1e-10
    assert abs(zero["blocks"][1]["median_change_percent"] - 29.815074871321933) < 1e-10
    assert abs(zero["blocks"][1]["mean_change_percent"] - 29.76394805930451) < 1e-10
    assert analysis["controls_vetoed_in_both_blocks"] == ["join-boundary-256-trip0.js"]
    assert set(analysis["targets_not_improved_both_blocks"]) == set()

    aa = load(COHORT / "aa-analysis.json")
    assert aa["status"] == "complete" and len(aa["comparisons"]) == 12
    aa_run = COHORT / aa["analysis"]
    aa_analysis = load(aa_run)
    assert sum(item["invocation_count"] for row in aa_analysis["comparisons"]
        for block in row["blocks"] for item in block["products"].values()) == 192

    source_guard = (COHORT / "source-guards.log").read_text()
    counts = [int(n) for n in re.findall(r"test result: ok\. (\d+) passed; 0 failed;", source_guard)]
    assert sum(counts) == 359, (counts, sum(counts))
    focused = load(COHORT / "native-focused/receipt.json")
    focused_passed = sum(len(row["selected_inventory"]) for row in focused)
    assert focused_passed == 62
    oracle_lines = [line for line in (COHORT / "v8-oracle.log").read_text().splitlines()
        if line.endswith(" true")]
    assert len(oracle_lines) == 8

    generic = load(COHORT / "fixture-budget-diagnostic/summary.json")
    concrete = load(COHORT / "fixture-budget-wasm-diagnostic/summary.json")
    assert generic["status"] == "incomplete" and len(generic["incomplete_fixtures"]) == 8
    bodies = {row["file"]: row["largest_core_code_body_bytes"] for row in concrete["records"]}
    assert len(bodies) == 8 and max(bodies.values()) == 111031 and max(bodies.values()) < MAX_BODY
    assert concrete["largest_core_body"]["fixture"] == "dense_number_chunks_preserve_sequential_writes_rounding_and_counter_sign.js"
    return candidate, hosts, analysis, aa_analysis, counts, focused_passed, oracle_lines, generic, concrete, rows


def build_report(candidate, hosts, analysis, aa, guard_counts, focused_passed, oracle_lines, generic, concrete, rows):
    invariance = load(COHORT / "runtime-invariance.json")
    wasm_profiles = [dict(artifact=name, runtime_abi=value["runtime_abi"],
        identical_to_baseline=value["runtime_wasm_identical"], bytes=value["runtime_wasm_bytes"],
        sha256=value["runtime_wasm_sha256"])
        for name,value in invariance.items() if "runtime_abi" in value]
    native_profiles = [dict(artifact=name, identical_to_baseline=value["native_identical"],
        bytes=value["bytes"], sha256=value["sha256"])
        for name,value in invariance.items() if "native_identical" in value]
    assert len(wasm_profiles)==2 and len(native_profiles)==2
    assert all(row["runtime_abi"]==42 and row["identical_to_baseline"] for row in wasm_profiles)
    assert all(row["identical_to_baseline"] for row in native_profiles)
    aa_measured = sum(len(row["times_ns"]) for row in aa["rows"])
    boundary_measured = sum(len(row["times_ns"]) for row in analysis["rows"])
    report = dict(
        schema="scriptw-joined-length-zero-trip-rejection-v1", date="2026-11-01",
        title="Joined-length preflight: zero-trip boundary rejects the broad candidate",
        decision=dict(status="rejected-screen", promotion="joined-length preflight is not promoted",
            candidate_source_commit=candidate["source_commit"], candidate_source_fingerprint=candidate["source_fingerprint"],
            reason="join-boundary-256-trip0.js is the sole persistent control veto: +31.599426% median/+30.504687% mean in block 0, then +29.815075% median/+29.763948% mean in block 1.",
            interpretation="Preflighting array length imposes substantial work when the loop has zero trips. The measured one-trip and larger boundary controls do not justify admitting the candidate under the predeclared no-control-regression gate."),
        identities=dict(baseline=dict(source_commit=load(COHORT/"baseline/identity.json")["source_commit"],
                source_fingerprint=load(COHORT/"baseline/identity.json")["source_fingerprint"],
                runtime_baseline_sha256=load(COHORT/"baseline/host-products.json")["runtime_baseline"]["sha256"]),
            candidate=dict(source_commit=candidate["source_commit"], source_fingerprint=candidate["source_fingerprint"],
                compiler_precompiled_identity_sha256=candidate["executable_sha256"],
                ordinary_runtime_baseline_sha256=hosts["runtime_baseline"]["sha256"],
                identity_note="The compiler-precompiled identity is a source/configuration binder. Ordinary timing used runtime_baseline; each host report separately records and is checked against its runtime executable SHA.")),
        measurement=dict(executed_host="runtime_baseline", samples_per_invocation=21, warmups_per_invocation=10,
            block_order="two case-local balanced blocks; four independent process invocations per product per block",
            experimental_unit="process invocation; gate aggregates four invocation medians and four invocation means per block",
            boundary_screen=dict(analysis="target/performance-scalar-regions-next/join-boundary/runs/20261101T014322Z-candidate-screen/analysis.json",
                cases=analysis["cases"], invocations=len(analysis["rows"]), measured_observations=boundary_measured,
                warmups=len(analysis["rows"])*10, scope_clarification="The immutable analysis has a stale prose target_rule saying nine targets. Actual row classification and pre-run study plan are three canonical joins as targets plus six extent/trip controls and retained-objects as seven controls."),
            aa=dict(analysis="target/performance-scalar-regions-next/aa-analysis.json", cases=len(aa["comparisons"]),
                invocations=192, measured_observations=aa_measured, warmups=192*10,
                persistent_control_vetoes=aa["controls_vetoed_in_both_blocks"])),
        case_results=rows,
        gate=dict(targets=["join-empty-1024.js", "join-singleton-1024.js", "join-small-1024.js"],
            targets_improved_in_median_both_blocks=True,
            controls=[f"join-boundary-{n}-trip{t}.js" for n in (256,257,4096) for t in (0,1)]+["retained-objects.js"],
            veto="any control slowing by at least 3% in both block median and block mean in both blocks",
            vetoes=analysis["controls_vetoed_in_both_blocks"]),
        prebuild_fixture_budget=dict(
            generic_cli_diagnostic=dict(status=generic["status"], successful_builds=8,
                largest_function_metric="unavailable: frozen CLI printed only direct-js-to-wasm module; retained as incomplete, not a size pass"),
            wasm_body_diagnostic=dict(status=concrete["status"], compiler_source_fingerprint=concrete["source_fingerprint"],
                core_code_body_limit_bytes=MAX_BODY, largest_core_body=concrete["largest_core_body"],
                bodies_by_fixture={name:size for name,size in sorted({r["file"]:r["largest_core_code_body_bytes"] for r in concrete["records"]}.items())}),
            coverage="eight semantic fixture builds under the old rejected compiler only; not correctness evidence for b7fe"),
        verification=dict(source_only_guards=dict(passed=sum(guard_counts), suites=guard_counts),
            focused_native=dict(passed=focused_passed, scope="62 focused tests only; do not present aggregate/broad test totals"),
            v8_semantic_oracles=dict(passed=8, total=8, records=oracle_lines),
            runtime_invariance=dict(wasm=wasm_profiles,native=native_profiles),
            not_run_after_failed_boundary=["main nine-target screen", "full17 ordinary run", "derived kernels", "Test262", "V8/Scriptc performance references", "native broad suite"]),
        evidence=dict(archive_path="docs/rust-rewrite/joined-length-zero-trip-20261101-inert.tar.xz"))
    return report


def gather():
    records = {}
    # Root-level provenance, source/build logs, source plan and driver text.
    for path in sorted(COHORT.iterdir()):
        if path.is_file() and path.name != "report-draft.json":
            add(records, f"rejected-b7fe/{path.name}", path)
    for label in ("baseline", "baseline-aa", "candidate"):
        for name in ("identity.json", "products.json", "host-products.json", "source.json",
                     "source.patch", "source-files.json", "identity.stdout", "identity.stderr"):
            add(records, f"rejected-b7fe/{label}/{name}", COHORT / label / name)
    for name in ("sources", "retained-sources", "expected", "kernels", "semantic-sources",
                 "fixture-budget-diagnostic", "fixture-budget-wasm-diagnostic", "runs",
                 "native-focused", "native-broad", "test262-sort", "test262-to-sorted",
                 "raw", "reference-raw", "program-inspection"):
        add_tree(records, name, COHORT / name)
    for path in sorted(BOUNDARY.iterdir()):
        if path.is_file():
            add(records, f"rejected-b7fe/join-boundary/{path.name}", path)
    for name in ("corpus", "runs"):
        add_tree(records, f"join-boundary/{name}", BOUNDARY / name)
    if not records:
        raise ValueError("no allowlisted evidence files collected")
    return records


def main():
    validated = validate()
    report = build_report(*validated)
    records = gather()
    index_rows = [dict(path=name, bytes=len(data), sha256=sha(data)) for name,data in sorted(records.items())]
    index = dict(schema="scriptw-joined-length-inert-evidence-v1", member_count=len(index_rows),
        expanded_bytes=sum(row["bytes"] for row in index_rows), files=index_rows,
        policy="UTF-8 non-executable text only. Wasm/native images, caches, toolchains, raw binaries and full runtime WAT are excluded.")
    records["evidence-index.json"] = (json.dumps(index,indent=2)+"\n").encode()
    ARCHIVE.parent.mkdir(parents=True,exist_ok=True)
    with tarfile.open(ARCHIVE,"w:xz",preset=3,format=tarfile.PAX_FORMAT) as tar:
        for name,data in sorted(records.items()):
            info=tarfile.TarInfo(name); info.size=len(data); info.mode=0o644; info.mtime=0
            tar.addfile(info,io.BytesIO(data))
    with tarfile.open(ARCHIVE,"r:xz") as tar:
        members=tar.getmembers()
        assert len(members)==len(records)
        for member in members:
            pure=PurePosixPath(member.name)
            assert member.isreg() and not pure.is_absolute() and ".." not in pure.parts and not member.mode & 0o111
            assert tar.extractfile(member).read()==records[member.name]
    report["evidence"].update(archive_sha256=hashlib.file_digest(ARCHIVE.open("rb"),"sha256").hexdigest(),
        archive_bytes=ARCHIVE.stat().st_size, member_count=len(records), expanded_bytes=sum(map(len,records.values())),
        index_sha256=sha(records["evidence-index.json"]))
    REPORT.parent.mkdir(parents=True,exist_ok=True)
    REPORT.write_text(json.dumps(report,indent=2)+"\n")
    print(json.dumps(report["evidence"],indent=2))


if __name__ == "__main__":
    main()
