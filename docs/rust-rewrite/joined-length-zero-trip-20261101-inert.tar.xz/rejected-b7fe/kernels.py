"""Derived checksum sizes; keep separate from the unchanged original17."""
import json
import statistics
from pathlib import Path
from run import OUT, SCHEDULES, cache_metadata, check_product, digest, invoke, load, save_new, verify_observations

sources = OUT / 'kernels'
folder = OUT / 'kernels-run'
folder.mkdir()
cases = load(sources / 'manifest.json')['execution']
hashes = {p.name: digest(p) for p in sources.iterdir() if p.suffix == '.js'}
save_new(folder / 'plan.json', dict(source_hashes=hashes, cache=cache_metadata(),
    samples=21, warmups=10, schedules=SCHEDULES, gate=load(sources / 'plan.json'),
    boundary='ordinary runtime_baseline; fresh entry, default automatic policy; source compilation/setup excluded'))
rows = []
for case in cases:
    name = case['file']
    for block, order in SCHEDULES:
        for index, product in enumerate(order):
            stem = f'{block}-{index}-{product}-{name}'
            artifacts = folder / 'artifacts' / stem
            artifacts.mkdir(parents=True)
            invoke(folder, stem, [OUT / product / 'runtime_baseline', sources, '21', '10', name, artifacts])
            times = verify_observations(folder, stem, product, case, 21, 10)
            raw = load(folder / 'raw' / (stem + '.stdout'))
            assert raw['executable_sha256'] == load(OUT / product / 'host-products.json')['runtime_baseline']['sha256']
            rows.append(dict(case=name, block=block, product=product, raw=stem,
                             samples_ns=times, median_ns=statistics.median(times), mean_ns=statistics.mean(times)))
    print(name, 'complete', flush=True)
comparisons = []
for case in cases:
    item = dict(case=case['file'], blocks=[])
    for block, _ in SCHEDULES:
        aggregates = {}
        for product in ['baseline', 'candidate']:
            selected = [row for row in rows if row['case'] == case['file'] and row['block'] == block and row['product'] == product]
            assert len(selected) == 4
            aggregates[product] = dict(median_ns=statistics.median(row['median_ns'] for row in selected),
                                       mean_ns=statistics.mean(row['mean_ns'] for row in selected))
        changes = {key: 100 * (aggregates['candidate'][key] / aggregates['baseline'][key] - 1) for key in ['median_ns', 'mean_ns']}
        item['blocks'].append(dict(block=block, products=aggregates, change_percent=changes))
    comparisons.append(item)
tiny = {'checksum-0.js', 'checksum-1.js'}
vetoes = [row['case'] for row in comparisons if row['case'] in tiny and all(
    b['change_percent']['median_ns'] >= 3 and b['change_percent']['mean_ns'] >= 3 for b in row['blocks'])]
misses = [row['case'] for row in comparisons if row['case'] not in tiny and any(
    b['change_percent']['median_ns'] >= 0 for b in row['blocks'])]
assert all(digest(sources / name) == expected for name, expected in hashes.items())
save_new(folder / 'analysis.json', dict(scope='Derived kernels, never pooled with original17', rows=rows,
    comparisons=comparisons, tiny_control_vetoes=vetoes, large_targets_not_improved=misses))
print(json.dumps(dict(tiny_control_vetoes=vetoes, large_targets_not_improved=misses)))
