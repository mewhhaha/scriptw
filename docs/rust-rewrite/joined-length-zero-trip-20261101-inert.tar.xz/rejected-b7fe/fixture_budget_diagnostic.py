"""Bounded source-size diagnostic using the frozen rejected compiler only."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import time

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
CLI = ROOT / "target/performance-numeric-array-binding/candidate/scriptw"
IDENTITY = CLI.parent / "identity.json"
SOURCES = OUT / "semantic-sources"
DEST = OUT / "fixture-budget-diagnostic"
EXPECTED = {
    "dense_number_chunks_preserve_sequential_writes_rounding_and_counter_sign.js",
    "exact_sum_accepts_safe_positive_and_negative_prefixes.js",
    "exact_sum_preserves_seed_boundaries_and_rounding_misses.js",
    "exact_sum_preserves_signed_zero_nonfinite_and_zero_trip_values.js",
    "exact_sum_retains_unsafe_intermediates_and_observable_coercions.js",
    "joined_length_preflight_keeps_late_coercions_holes_and_caps_observable.js",
    "joined_length_region_misses_preserve_live_methods_and_read_order.js",
    "joined_length_regions_preserve_utf16_and_number_arithmetic.js",
}
LARGEST_RE = re.compile(r"largest emitted function: wasm\[0\]::function\[\d+\] \((\d+) bytes,")
LIMIT_BYTES = 128 * 1024


def sha256(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def main():
    sources = sorted(path for path in SOURCES.glob("*.js"))
    names = {path.name for path in sources}
    assert names == EXPECTED, (sorted(names - EXPECTED), sorted(EXPECTED - names))
    assert CLI.is_file() and os.access(CLI, os.X_OK)
    identity = json.loads(IDENTITY.read_text())
    DEST.mkdir(parents=True, exist_ok=False)
    env = dict(os.environ)
    env.pop("SCRIPTW_WASM_DUMP", None)
    env.pop("SCRIPTW_WASM_TRACE", None)
    assert not env.get("SCRIPTW_WASM_DUMP")
    records = []
    for source in sources:
        stem = source.stem
        stdout_path = DEST / f"{stem}.stdout"
        stderr_path = DEST / f"{stem}.stderr"
        argv = [str(CLI), "--jobs", "1", "--host-surface", "test262", "build", "wasm", str(source)]
        started = time.perf_counter_ns()
        timed_out = False
        exit_code = None
        with stdout_path.open("xb") as stdout, stderr_path.open("xb") as stderr:
            try:
                result = subprocess.run(argv, cwd=ROOT, env=env, stdout=stdout, stderr=stderr,
                    timeout=60, check=False)
                exit_code = result.returncode
            except subprocess.TimeoutExpired:
                timed_out = True
        elapsed_ns = time.perf_counter_ns() - started
        output = stdout_path.read_text(errors="replace") + "\n" + stderr_path.read_text(errors="replace")
        match = LARGEST_RE.search(output)
        largest_bytes = int(match.group(1)) if match else None
        record = dict(file=source.name, source_sha256=sha256(source), argv=argv,
            host_sha256=sha256(CLI), exit_code=exit_code, timed_out=timed_out,
            source_commit=identity["source_commit"], source_fingerprint=identity["source_fingerprint"],
            elapsed_ns=elapsed_ns, largest_emitted_function_bytes=largest_bytes,
            artifact_description=match.group(0) if match else None,
            stdout=stdout_path.name, stdout_sha256=sha256(stdout_path),
            stderr=stderr_path.name, stderr_sha256=sha256(stderr_path))
        (DEST / f"{stem}.receipt.json").write_text(json.dumps(record, indent=2) + "\n")
        records.append(record)
        print(source.name, exit_code, largest_bytes, flush=True)
    oversized = [r["file"] for r in records
        if r["largest_emitted_function_bytes"] is not None
        and r["largest_emitted_function_bytes"] > LIMIT_BYTES]
    missing = [r["file"] for r in records
        if r["exit_code"] != 0 or r["timed_out"] or r["largest_emitted_function_bytes"] is None]
    summary = dict(status="complete" if not missing else "incomplete",
        purpose="source-size diagnostic under frozen rejected12 compiler; not candidate correctness evidence",
        compiler=str(CLI), compiler_sha256=sha256(CLI), largest_function_limit_bytes=LIMIT_BYTES,
        source_commit=identity["source_commit"], source_fingerprint=identity["source_fingerprint"],
        fixture_count=len(records), records=records, oversized_fixtures=oversized,
        incomplete_fixtures=missing,
        disposition="split oversized fixtures before next compiler build" if oversized else "all largest functions within 128 KiB")
    (DEST / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(dict(status=summary["status"], oversized_fixtures=oversized,
        incomplete_fixtures=missing, summary=str((DEST / "summary.json").relative_to(OUT))), indent=2))


if __name__ == "__main__":
    main()
