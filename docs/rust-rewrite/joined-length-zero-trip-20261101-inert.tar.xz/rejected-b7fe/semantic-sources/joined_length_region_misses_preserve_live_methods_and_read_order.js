
function joined(a, steps) {
  'use strict';var total=0;
  for(var i=0;i<steps;i++)total+=a.join(',').length;
  return total;
}
var log=[], own=['a','b'];own.join=function(){log.push('own');return 'abcdef';};
if(joined(own,2)!==12 || log.join('|')!=='own|own')throw 'own method';
log=[];
var proxy=new Proxy(['a','b'],{get(target,key,receiver){log.push(key);return Reflect.get(target,key,receiver);}});
if(joined(proxy,2)!==6 || log.join('|')!=='join|length|0|1|join|length|0|1')throw 'Proxy order';
var original=Object.getOwnPropertyDescriptor(Array.prototype,'join'), events='';
Object.defineProperty(Array.prototype,'join',{configurable:true,get(){events+='get|';return function(){events+='call|';return 'abc';};}});
if(joined(['a'],0)!==0 || events!=='')throw 'zero trip getter';
var override=joined(['a'],2);
Object.defineProperty(Array.prototype,'join',original);
if(override!==6 || events!=='get|call|get|call|')throw 'prototype getter';
var caught=false;
delete Array.prototype.join;
try{joined(['a'],1);}catch(error){caught=error instanceof TypeError;}
Object.defineProperty(Array.prototype,'join',original);
if(!caught)throw 'deleted method';
var inherited=Object.create(Array.prototype), reads=0;
Object.defineProperty(inherited,'join',{get(){reads++;return function(){return 'xy';};}});
var custom=['a'];Object.setPrototypeOf(custom,inherited);
joined(custom,2)===4 && reads===2;
