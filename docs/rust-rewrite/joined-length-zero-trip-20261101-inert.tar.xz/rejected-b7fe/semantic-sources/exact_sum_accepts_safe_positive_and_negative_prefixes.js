
function positive(seed) {
  'use strict'; var total=seed;
  for(var i=3;(i+0)<23;i++) total+=i*3+1;
  return [total,i];
}
function negative(seed) {
  'use strict'; var total=seed;
  for(var i=2;i<7;i++) total=total+(1-i*3);
  return [total,i];
}
var a=positive(0), b=positive(9007199254740221), c=positive(-770);
var d=negative(55), e=negative(0), f=negative(-9007199254740936);
a[0]===770 && a[1]===23 && b[0]===9007199254740991 && b[1]===23 &&
Object.is(c[0],0) && c[1]===23 && Object.is(d[0],0) && d[1]===7 &&
e[0]===-55 && e[1]===7 && f[0]===-9007199254740991 && f[1]===7;
