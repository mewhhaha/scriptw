
function positive(seed) {
  'use strict';var total=seed;
  for(var i=3;(i+0)<23;i++)total+=i*3+1;
  return [total,i];
}
function negative(seed) {
  'use strict';var total=seed;
  for(var i=2;i<7;i++)total=total+(1-i*3);
  return [total,i];
}
function crossing(seed) {
  'use strict';var total=seed;
  for(var i=0;i<5;i++)total+=i-2;
  return [total,i];
}
var low=positive(-9007199254740991), upper=negative(9007199254740991);
var outsidePositive=positive(9007199254740223), outsideNegative=negative(-9007199254740938);
var crossed=crossing(-0);
low[0]===-9007199254740221 && low[1]===23 && upper[0]===9007199254740936 && upper[1]===7 &&
outsidePositive[0]===9007199254740992 && outsidePositive[1]===23 &&
outsideNegative[0]===-9007199254740992 && outsideNegative[1]===7 &&
Object.is(crossed[0],0) && crossed[1]===5;
