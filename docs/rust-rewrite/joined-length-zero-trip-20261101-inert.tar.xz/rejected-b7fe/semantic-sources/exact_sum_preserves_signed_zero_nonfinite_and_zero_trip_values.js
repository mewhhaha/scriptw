
function three(seed) {
  'use strict'; var total=seed;
  for(var i=0;(i+0)<3;i++) total+=i;
  return [total,i];
}
function zeros(seed) {
  'use strict'; var total=seed;
  for(var i=0;i<3;i++) total+=-0;
  return total;
}
function empty(seed) {
  'use strict'; var total=seed;
  for(var i=3;i<3;i++) total+=i;
  return [total,i];
}
var rounded=three(9007199254740992), fractional=three(0.25);
var infinite=three(Infinity), nan=three(NaN), untouched=empty(-0);
rounded[0]===9007199254740994 && rounded[1]===3 &&
fractional[0]===3.25 && fractional[1]===3 &&
infinite[0]===Infinity && infinite[1]===3 && Number.isNaN(nan[0]) && nan[1]===3 &&
Object.is(zeros(-0),-0) && Object.is(zeros(0),0) &&
Object.is(untouched[0],-0) && untouched[1]===3;
