
function cancellation() {
  'use strict';var total=0;
  for(var i=0;(i+0)<3;i++) total+=(i+9007199254740991)-9007199254740991;
  return total;
}
function masked() {
  'use strict';var total=0;
  for(var i=0;i<3;i++) total+=((i+9007199254740991)-9007199254740991)*0;
  return total;
}
function coerced(seed) {
  'use strict';var total=seed;
  for(var i=0;(i+0)<3;i++) total+=i;
  return [total,i];
}
var hits=0, object=coerced({valueOf(){hits++;return 4;}}), string=coerced('v');
var symbolError=false,bigintError=false;
try{coerced(Symbol());}catch(e){symbolError=e instanceof TypeError;}
try{coerced(1n);}catch(e){bigintError=e instanceof TypeError;}
cancellation()===2 && Object.is(masked(),0) && object[0]===7 && object[1]===3 &&
hits===1 && string[0]==='v012' && string[1]===3 && symbolError && bigintError;
