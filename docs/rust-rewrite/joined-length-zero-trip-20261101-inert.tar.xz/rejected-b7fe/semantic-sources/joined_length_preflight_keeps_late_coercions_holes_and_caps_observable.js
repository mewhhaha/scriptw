
function joined(a, steps) {
  'use strict';var total=0;
  for(var i=0;i<steps;i++)total+=a.join(',').length;
  return total;
}
function separated(a, steps, separator) {
  'use strict';var total=0;
  for(var i=0;i<steps;i++)total+=a.join(separator).length;
  return total;
}
var events='', late=['a','b',{toString(){events+='convert|';late[3]='long';gc();return 'x';}},'d'];
if(joined(late,2)!==20 || events!=='convert|convert|')throw 'late conversion';
events='';var holey=['x',,'z'];
Object.defineProperty(Array.prototype,'1',{configurable:true,get(){events+='hole|';holey[2]='zz';return 'y';}});
var holes=joined(holey,2);
delete Array.prototype[1];
if(holes!==12 || events!=='hole|hole|')throw 'live hole';
events='';var separator={toString(){events+='separator|';return '|';}};
if(separated([],3,separator)!==0 || events!=='separator|separator|separator|')throw 'empty separator coercion';
if(joined([1,2],2)!==6 || joined([1n,2n],2)!==6)throw 'non String slots';
var caught=false;try{joined(['a',Symbol()],1);}catch(error){caught=error instanceof TypeError;}
if(!caught || joined(['a',Symbol()],0)!==0)throw 'Symbol conversion';
for(var size=256;size<=257;size++){
  var a=[];for(var j=0;j<size;j++)a.push('x');
  if(joined(a,0)!==0 || joined(a,1)!==size*2-1)throw 'preflight cap';
}
var large=[];for(var j=0;j<4096;j++)large.push('x');
joined(large,0)===0 && joined(large,1)===8191;
