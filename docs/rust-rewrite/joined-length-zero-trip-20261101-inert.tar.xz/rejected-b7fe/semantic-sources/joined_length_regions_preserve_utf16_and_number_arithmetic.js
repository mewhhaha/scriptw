
function joined(a, steps, seed) {
  'use strict';var total=seed;
  for(var i=0;i<steps;i++)total+=a.join('\ud800\u0000\udfff').length;
  return [total,i];
}
var strings=joined(['','\ud800','\udfff','😀'],5,0);
var lone=joined(['\ud800','\udfff'],3,0.25);
var empty=joined([],0,-0), zeros=joined([],3,-0);
var frozen=joined(Object.freeze(['a','bc']),4,0);
var sealed=joined(Object.seal(['a','bc']),4,0);
var derived=class extends Array {};
var subclass=joined(new derived('a','bc'),4,0);
var nan=joined(['x'],4,NaN), infinity=joined(['x'],4,Infinity);
strings[0]===65 && strings[1]===5 && lone[0]===15.25 && lone[1]===3 &&
Object.is(empty[0],-0) && empty[1]===0 && Object.is(zeros[0],0) && zeros[1]===3 &&
frozen[0]===24 && sealed[0]===24 && subclass[0]===24 &&
Number.isNaN(nan[0]) && nan[1]===4 && infinity[0]===Infinity && infinity[1]===4;
