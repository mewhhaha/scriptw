
function chunked(a, start, seed) {
  'use strict';var sum=seed, last=seed;
  for(var i=start;i<a.length;i++){sum+=a[i];last=sum;sum+=i*a[i];}
  return [sum,i,last];
}
function reference(a, start, seed) {
  'use strict';var sum=seed, last=seed;
  function value(){return sum;}
  for(var i=start;i<a.length;i++){sum+=a[i];last=sum;sum+=i*a[i];}
  return [value(),i,last];
}
function reciprocal(a, start) {
  'use strict';var sum=0;
  for(var i=start;i<a.length;i++)sum+=(1/i)*a[i];
  return [sum,i];
}
var sizes=[0,1,2,3,4,5,6,7,8,9,15,16,17,65,129];
var pattern=[1e16,1,-1e16,-0,3,-2,0.5], seeds=[0,-0,NaN,Infinity,-Infinity,9007199254740991];
for(var n=0;n<sizes.length;n++){
  var a=[];for(var j=0;j<sizes[n];j++)a.push(pattern[j%pattern.length]);
  for(var start=0;start<6;start++)for(var k=0;k<seeds.length;k++){
    var initial=start;if(start===0)initial=-0;
    var actual=chunked(a,initial,seeds[k]), expected=reference(a,initial,seeds[k]);
    for(var p=0;p<3;p++)if(!Object.is(actual[p],expected[p]))throw 'sequential dense chunk';
  }
}
var signed=reciprocal([1,1,1,1,1],-0), positive=reciprocal([1,1,1,1,1],0);
var empty=[1];empty.length=0;
var untouched=chunked(empty,-0,-0);
signed[0]===-Infinity && signed[1]===5 && positive[0]===Infinity && positive[1]===5 &&
Object.is(untouched[0],-0) && Object.is(untouched[1],-0) && Object.is(untouched[2],-0);
