var values, seed;
export function prepare(input) {
  seed = input;
  var object = {value: input};
  if (input & 2) object = null;
  var callable = function value() {};
  if (input & 2) {
    callable = callable.bind(null);
  } else {
    var revoked = Proxy.revocable(callable, {});
    callable = revoked.proxy;
    revoked.revoke();
  }
  values = [undefined, object, false, 17, 23n, 'value', Symbol('kind'), callable];
}
export function run() {
  var sum = seed;
  for (var i = 0; i < 4096; i++) {
    var value = values[(i + seed) & 7];
    if (typeof value === 'undefined') sum += 1;
    else if (typeof value == 'object') sum += 2;
    else if ('boolean' === typeof value) sum += 3;
    else if (typeof value == 'number') sum += 4;
    else if (typeof value === 'bigint') sum += 5;
    else if (typeof value == 'string') sum += 6;
    else if (typeof value === 'symbol') sum += 7;
    else if ('function' == typeof value) sum += 8;
    else sum -= 1000;
  }
  print(sum);
}
