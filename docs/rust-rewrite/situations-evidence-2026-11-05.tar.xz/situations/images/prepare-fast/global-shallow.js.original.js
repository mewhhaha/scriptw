var savedMap = Map;
var savedSet = Set;
var savedUint8Array = Uint8Array;
var savedDataView = DataView;
var savedDate = Date;
var savedNumber = Number;
var worker, expectedMap, mapValue, getterCount;
function alternateMap() {}
function make(input) {
  var padding = input * 8 + 36;
var eMap = expectedMap;
var eSet = savedSet;
var eUint8Array = savedUint8Array;
var eDataView = savedDataView;
var eDate = savedDate;
var eNumber = savedNumber;
  return function () {
var sum = 0;
    for (var i = 0; i < 1024; i++) {
      sum += padding;
      if (Map === eMap) sum++;
      if (Set === eSet) sum++;
      if (Uint8Array === eUint8Array) sum++;
      if (DataView === eDataView) sum++;
      if (Date === eDate) sum++;
      if (Number === eNumber) sum++;
    }
    return sum;
  };
}
export function prepare(input) {
  expectedMap = savedMap;
  worker = make(input);
}
export function run() {
  print(worker());
}
