var rows, seed;
export function prepare(input) {
  seed = input;
  var targets = [Array, Map, Set, Date, Number, String, Boolean, Uint8Array];
  rows = [];
  for (var i = 0; i < 64; i++) rows.push(targets[(input + i) & 7]);
}
export function run() {
  var sum = seed;
  for (var i = 0; i < 8192; i++) {
    var row = rows[i & 63];
    sum += row.length + row.name.length;
  }
  print(sum);
}
