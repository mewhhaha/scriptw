var values, seed;
export function prepare(input) {
  seed = input;
  var object = {value: input};
  if (input & 2) object = false;
  var callable = function value() {};
  if (input & 2) {
    callable = callable.bind(null);
  } else {
    var revoked = Proxy.revocable(callable, {});
    callable = revoked.proxy;
    revoked.revoke();
  }
  values = [void 0, null, object, 17, 23n, 'value', Symbol('kind'), callable];
}
export function run() {
  var sum = seed;
  for (var i = 0; i < 4096; i++) {
    var value = values[(i + seed) & 7];
    if (value === null) sum += 1;
    else sum += 2;
    if (value !== null) sum += 4;
    else sum += 8;
    if (value === void 0) sum += 16;
    else sum += 32;
    if (value !== void 0) sum += 64;
    else sum += 128;
  }
  print(sum);
}
