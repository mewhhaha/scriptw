var savedMap = Map;
var savedSet = Set;
var savedUint8Array = Uint8Array;
var savedDataView = DataView;
var savedDate = Date;
var savedNumber = Number;
var worker, expectedMap, mapValue, getterCount;
function alternateMap() {}
function make(input) {
var p1 = input + 1;
return (function () {
var p2 = input + 2;
return (function () {
var p3 = input + 3;
return (function () {
var p4 = input + 4;
return (function () {
var p5 = input + 5;
return (function () {
var p6 = input + 6;
return (function () {
var p7 = input + 7;
return (function () {
var p8 = input + 8;
var eMap = expectedMap;
var eSet = savedSet;
var eUint8Array = savedUint8Array;
var eDataView = savedDataView;
var eDate = savedDate;
var eNumber = savedNumber;
return function () {
    var sum = 0;
    for (var i = 0; i < 1024; i++) {
      sum += p1 + p2 + p3 + p4 + p5 + p6 + p7 + p8;
      if (Map === eMap) sum++;
      if (Set === eSet) sum++;
      if (Uint8Array === eUint8Array) sum++;
      if (DataView === eDataView) sum++;
      if (Date === eDate) sum++;
      if (Number === eNumber) sum++;
    }
    return sum;
  };
})();
})();
})();
})();
})();
})();
})();
}
export function prepare(input) {
  mapValue = savedMap;
  if (input & 2) mapValue = alternateMap;
  expectedMap = mapValue;
  getterCount = 0;
  Object.defineProperty(globalThis, 'Map', {
    configurable: true,
    get: function () { getterCount++; return mapValue; }
  });
  worker = make(input);
}
export function run() {
  var sum = worker();
  print(sum + getterCount);
}
