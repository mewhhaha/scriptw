var savedMap = Map;
var savedSet = Set;
var savedUint8Array = Uint8Array;
var savedDataView = DataView;
var savedDate = Date;
var savedNumber = Number;
var worker, expectedMap, mapValue, getterCount;
function alternateMap() {}
function make(input) {
var p1 = input + 1;
return (function () {
var p2 = input + 2;
return (function () {
var p3 = input + 3;
return (function () {
var p4 = input + 4;
return (function () {
var p5 = input + 5;
return (function () {
var p6 = input + 6;
return (function () {
var p7 = input + 7;
return (function () {
var p8 = input + 8;
var eMap = expectedMap;
var bMap = eMap;
var eSet = savedSet;
var bSet = eSet;
var eUint8Array = savedUint8Array;
var bUint8Array = eUint8Array;
var eDataView = savedDataView;
var bDataView = eDataView;
var eDate = savedDate;
var bDate = eDate;
var eNumber = savedNumber;
var bNumber = eNumber;
return function () {
    var sum = 0;
    for (var i = 0; i < 1024; i++) {
      sum += p1 + p2 + p3 + p4 + p5 + p6 + p7 + p8;
      if (bMap === eMap) sum++;
      if (bSet === eSet) sum++;
      if (bUint8Array === eUint8Array) sum++;
      if (bDataView === eDataView) sum++;
      if (bDate === eDate) sum++;
      if (bNumber === eNumber) sum++;
    }
    return sum;
  };
})();
})();
})();
})();
})();
})();
})();
}
export function prepare(input) {
  expectedMap = savedMap;
  worker = make(input);
}
export function run() {
  print(worker());
}
