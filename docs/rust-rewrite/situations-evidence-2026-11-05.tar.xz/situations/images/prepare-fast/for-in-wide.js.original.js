var row, seed;
export function prepare(input) {
  seed = input;
  row = {};
  for (var i = 0; i < 64; i++) row['key' + i] = (i * 13 + input) & 255;
}
export function run() {
  var sum = seed;
  for (var pass = 0; pass < 16; pass++) {
    for (var key in row) sum += row[key];
  }
  print(sum);
}
