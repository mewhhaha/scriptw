var rows, steps;
export function prepare(input) {
  rows = [];
  for (var i = 0; i < 64; i++) {
    rows.push({x: input + i, y: input * 3 + i * 2, mask: (input + i) & 3});
  }
  var tick = input;
  steps = [function (row) {
    tick = (tick + 1) & 255;
    var value = row.x + tick;
    if (row.mask & 1) value = value ^ row.y;
    return value & 1023;
  }, function (row) {
    tick = (tick + 3) & 255;
    var value = row.y + tick;
    if (row.mask & 2) value = value ^ row.x;
    return value & 1023;
  }];
}
function frame(index, row) {
  switch (index & 31) {
    case 0: return steps[0](row);
    case 1: return steps[1](row);
    case 2: return steps[0](row);
    case 3: return steps[1](row);
    case 4: return steps[0](row);
    case 5: return steps[1](row);
    case 6: return steps[0](row);
    case 7: return steps[1](row);
    case 8: return steps[0](row);
    case 9: return steps[1](row);
    case 10: return steps[0](row);
    case 11: return steps[1](row);
    case 12: return steps[0](row);
    case 13: return steps[1](row);
    case 14: return steps[0](row);
    case 15: return steps[1](row);
    case 16: return steps[0](row);
    case 17: return steps[1](row);
    case 18: return steps[0](row);
    case 19: return steps[1](row);
    case 20: return steps[0](row);
    case 21: return steps[1](row);
    case 22: return steps[0](row);
    case 23: return steps[1](row);
    case 24: return steps[0](row);
    case 25: return steps[1](row);
    case 26: return steps[0](row);
    case 27: return steps[1](row);
    case 28: return steps[0](row);
    case 29: return steps[1](row);
    case 30: return steps[0](row);
    case 31: return steps[1](row);
  }
}
export function run() {
  var sum = 0;
  for (var call = 0; call < 16; call++) {
    for (var i = 0; i < 512; i++) sum += frame(i, rows[i & 63]);
  }
  print(sum);
}
