var input;
export function prepare(value) { input = value; }
export function run() { print(input); }
