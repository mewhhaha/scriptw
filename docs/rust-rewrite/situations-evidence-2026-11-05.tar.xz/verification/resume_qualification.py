import hashlib,json,pathlib,re,subprocess,time
from datetime import datetime,timezone
root=pathlib.Path.cwd();b=pathlib.Path(__file__).resolve().parent;logs=b/'verification'
r=json.loads((b/'native-verification-current.json').read_text());assert not r['complete']
assert json.loads((b/'output-restoration.json').read_text())['complete']
assert subprocess.check_output(['git','diff','--binary','HEAD','--','crates','docs/rust-rewrite/contracts'])==(b/'source/tracked.patch').read_bytes()
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
manifest=json.loads((b/'source/manifest.json').read_text())
for name,digest in manifest['files'].items():assert sha(root/name)==digest,name
r['interruptions']=[json.loads((b/'qualification-interruption.json').read_text())]
# Preserve the exact incomplete scope; it contributes no successful count.
for suffix in ['stdout','stderr']:(logs/('aot_language.'+suffix)).rename(logs/('before-shmem-oom-aot_language.'+suffix))
events=[json.loads(line) for line in (logs/'native-build.stdout').read_text().splitlines()]
assert any(e.get('reason')=='build-finished' and e['success'] for e in events)
native={e['target']['name']:e for e in events if e.get('reason')=='compiler-artifact' and e.get('executable') and e['profile']['test']}
names=['aot_language','aot_builtins','aot_async','aot_realm_modules']
assert not any(s['label'] in names for s in r['scopes'])
pins={name:sha(pathlib.Path(native[name]['executable'])) for name in names}
(b/'runtime-resume-binaries.json').write_text(json.dumps(pins,indent=2)+'\n')
for name in names:
 argv=[native[name]['executable'],'--test-threads=1'];assert sha(pathlib.Path(argv[0]))==pins[name]
 print('START',name,flush=True);start=time.monotonic_ns()
 with (logs/(name+'.stdout')).open('xb') as out,(logs/(name+'.stderr')).open('xb') as err:p=subprocess.run(argv,stdout=out,stderr=err,timeout=1800)
 matches=re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;',(logs/(name+'.stdout')).read_text());assert len(matches)==1,(name,p.returncode)
 state,passed,failed,ignored=matches[0]
 row=dict(label=name,argv=argv,exit_code=p.returncode,elapsed_ns=time.monotonic_ns()-start,source_manifest_sha256=r['source_manifest_sha256'],stdout='verification/'+name+'.stdout',stderr='verification/'+name+'.stderr',package='scriptw-engine',target=name,executable_sha256=pins[name],outcomes=dict(state=state,passed=int(passed),failed=int(failed),ignored=int(ignored)))
 r['scopes'].append(row);r['recorded_at']=datetime.now(timezone.utc).isoformat();(b/'native-verification-current.json').write_text(json.dumps(r,indent=2)+'\n')
 print('END',name,p.returncode,flush=True);assert p.returncode==0 and state=='ok' and int(passed)>0 and failed==ignored=='0',name
r['complete']=True;(b/'native-verification-current.json').write_text(json.dumps(r,indent=2)+'\n');print('ALL FROZEN NATIVE SCOPES COMPLETE',flush=True)
