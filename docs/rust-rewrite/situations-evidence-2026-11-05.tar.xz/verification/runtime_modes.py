import pathlib,subprocess,json,time,os,hashlib
b=pathlib.Path(__file__).resolve().parent;rows=[]
for mode in ('fast','speed'):
 label='diagnostic-'+mode;binary=b/'frozen/rsc_baseline';argv=[str(binary),'target/application-benchmarks-20261102/generated-v2/rsc.js','target/application-benchmarks-20261102/generated-v2/support.json',str(b/(label+'.json')),'3','3',mode];started=time.monotonic_ns()
 print('START',label,flush=True)
 with (b/(label+'.stdout')).open('xb') as out,(b/(label+'.stderr')).open('xb') as err:
  r=subprocess.run(argv,env=os.environ|{'SCRIPTW_WASM_TRACE':'1'},stdout=out,stderr=err,timeout=600)
 trace=(b/(label+'.stderr')).read_text();rows.append(dict(label=label,argv=argv,exit_code=r.returncode,elapsed_ns=time.monotonic_ns()-started,executable_sha256=hashlib.file_digest(binary.open('rb'),'sha256').hexdigest(),native_bundle_trace=[line for line in trace.splitlines() if 'runtime-native-bundle' in line],scope='UNSCORED diagnostic, changes P optimization; shared R already built SpeedAndSize/Backtracking. Not a matched cohort or R-only causal claim.'))
 (b/'runtime-mode-receipt.json').write_text(json.dumps(rows,indent=2)+'\n');print('END',label,r.returncode,flush=True)
 if r.returncode:break
