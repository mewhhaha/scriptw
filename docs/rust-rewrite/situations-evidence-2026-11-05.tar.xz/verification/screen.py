import hashlib,json,pathlib,shutil,subprocess,time
root=pathlib.Path.cwd();base=pathlib.Path(__file__).resolve().parent;commands=[]
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
manifest=sha(base/'source/manifest.json')
def check_source():
 assert subprocess.check_output(['git','diff','--binary','HEAD','--','crates','docs/rust-rewrite/contracts'])==(base/'source/tracked.patch').read_bytes()
 for name,value in json.loads((base/'source/manifest.json').read_text())['files'].items():assert sha(root/name)==value,name
def run(label,argv,timeout=1800):
 check_source();print('START',label,flush=True);start=time.monotonic_ns()
 with (base/(label+'.stdout')).open('xb') as out,(base/(label+'.stderr')).open('xb') as err:p=subprocess.run(argv,stdout=out,stderr=err,timeout=timeout)
 commands.append(dict(label=label,argv=argv,source_manifest_sha256=manifest,exit=p.returncode,elapsed_ns=time.monotonic_ns()-start));(base/'screen-receipt.json').write_text(json.dumps(commands,indent=2)+'\n');print('END',label,p.returncode,flush=True);assert p.returncode==0,label
def artifacts(path):
 rows=[json.loads(line) for line in path.read_text().splitlines()]
 assert any(r.get('reason')=='build-finished' and r['success'] for r in rows)
 return rows
node='/home/jacobt/.local/share/fnm/node-versions/v24.12.0/installation/bin/node'
timer=str(root/'target/performance-worker-cpu/tools/time')
prior=root/'target/performance-v8-climb-20261104/for-in-copy'
common=['python3','-B','scripts/benchmark-situations.py','--fixtures',str(base/'fixtures'),'--node',node,'--time',timer]
selected=['control-empty.js','metadata-ordinary.js','metadata-function.js','metadata-intrinsic.js']
args=common+['--host',str(prior/'frozen/compiler_precompiled_baseline'),'--producer-log',str(prior/'build.stdout'),'--output',str(base/'baseline-screen')]
for name in selected:args+=['--case',name]
run('source-guards-final',['python3','-B','scripts/check-source-guards.py','--output',str(base/'source-guards-final')])
run('emission-build',['cargo','test','--release','--locked','-p','scriptw-aot-wasm','--test','emission','--no-run','--message-format=json-render-diagnostics'])
rows=artifacts(base/'emission-build.stdout');selected=[r for r in rows if r.get('reason')=='compiler-artifact' and r['target']['name']=='emission' and r.get('executable')];assert len(selected)==1
binary=selected[0]['executable'];(base/'emission-producer.json').write_text(json.dumps(dict(artifact=selected[0],sha256=sha(pathlib.Path(binary)),source_manifest_sha256=manifest),indent=2)+'\n')
run('emission',[binary,'--test-threads=1'])
run('build',['cargo','build','--release','--locked','-p','scriptw-cli','--example','compiler_precompiled_baseline','--example','rsc_baseline','--message-format=json-render-diagnostics'])
rows=artifacts(base/'build.stdout');engines=[r for r in rows if r.get('reason')=='compiler-artifact' and r['target']['name']=='scriptw_engine'];assert len(engines)==1
rlibs=[pathlib.Path(p) for p in engines[0]['filenames'] if p.endswith('.rlib')];assert len(rlibs)==1
linked=sorted({p for r in rows if r.get('reason')=='build-script-executed' for p in r.get('linked_paths',[])})
for name,fixtures in [('aot_typed_number_inputs',['typed_number_inputs.js']),('aot_simple_parameters',['simple_parameters.js']),('aot_computed_key_projection',['computed_key_projection.js']),('aot_scalar_row_projection',['scalar_row_projection.js','scalar_row_projection_realms.js']),('aot_scalar_dictionary_rows',['scalar_dictionary_rows.js']),('aot_scalar_masked_rows',['scalar_masked_rows.js']),('aot_callable_capture_lifecycle',['retained_operands.js']),('aot_compact_row_regions',[])]:
 test=root/'crates/scriptw-engine/tests/aot_language'/(name+'.rs');output=base/name
 argv=['rustc','--edition=2021','--test',str(test),'-L','dependency=target/release/deps','--extern','scriptw_engine='+str(rlibs[0]),'-C','link-arg=-fuse-ld=lld','-o',str(output)]
 for path in linked:argv+=['-L',path]
 (base/(name+'-producer.json')).write_text(json.dumps(dict(artifact=engines[0],rlib_sha256=sha(rlibs[0]),test_sha256=sha(test),fixture_sha256={n:sha(root/'crates/scriptw-engine/tests/fixtures'/n) for n in fixtures},linked_paths=linked,source_manifest_sha256=manifest,argv=argv),indent=2)+'\n')
 run(name+'-build',argv)
 run(name,[str(output),'--test-threads=1'])
f=base/'frozen';f.mkdir()
for name in ('rsc_baseline','compiler_precompiled_baseline'):
 selected=[r for r in rows if r.get('reason')=='compiler-artifact' and r['target']['name']==name and r.get('executable')];assert len(selected)==1
 a=selected[0];p=pathlib.Path(a['executable']);shutil.copy2(p,f/name);(f/(name+'-producer.json')).write_text(json.dumps(dict(artifact=a,sha256=sha(p),source_manifest_sha256=manifest),indent=2)+'\n')
import tempfile
scratch=pathlib.Path(tempfile.mkdtemp(prefix='scriptw-row-preflight-',dir='/tmp'))
(base/'tmpfs-path.json').write_text(json.dumps(dict(scratch=str(scratch),filesystem=subprocess.check_output(['stat','-f','-c','%T',str(scratch)],text=True).strip(),boundary='All 504 scored children and precompiled images use this same tmpfs scratch; raw reports copied byte-for-byte after completion; Btrfs atomic progress replacement exhaustedmetadata in prior experiment'),indent=2)+'\n')
args=common+['--host',str(f/'compiler_precompiled_baseline'),'--producer-log',str(base/'build.stdout'),'--producer-receipt',str(f/'compiler_precompiled_baseline-producer.json'),'--output',str(scratch/'campaign')]
run('situations',args)
shutil.copytree(scratch/'campaign',base/'campaign')
for p in (scratch/'campaign').rglob('*'):
 if p.is_file():assert sha(p)==sha(base/'campaign'/p.relative_to(scratch/'campaign'))
(base/'tmpfs-copy-receipt.json').write_text(json.dumps(dict(original=str(scratch/'campaign'),retained=str(base/'campaign'),copied_files=sum(p.is_file() for p in (scratch/'campaign').rglob('*')),all_file_hashes_equal=True),indent=2)+'\n')
for rep in range(2):
 for actor in (['baseline','candidate'] if rep==0 else ['candidate','baseline']):
  binary=root/'target/performance-v8-climb-20261104/typed-region/frozen/rsc_baseline'
  if actor=='candidate':binary=f/'rsc_baseline'
  run(f'rsc-{rep}-{actor}',[str(binary),'target/application-benchmarks-20261102/generated-v2/rsc.js','target/application-benchmarks-20261102/generated-v2/support.json',str(base/f'rsc-{rep}-{actor}.json'),'7','3','fast'])
check_source();print('TYPED NUMBER BRANCH SCREEN COMPLETE',flush=True)
