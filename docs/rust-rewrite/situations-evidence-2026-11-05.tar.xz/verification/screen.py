import hashlib,json,pathlib,subprocess,time,shutil,tempfile
root=pathlib.Path.cwd();b=pathlib.Path(__file__).resolve().parent;rows=[]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
manifest=sha(b/'source/manifest.json')
def check():
 assert subprocess.check_output(['git','diff','--binary','HEAD','--','crates','docs/rust-rewrite/contracts'])==(b/'source/tracked.patch').read_bytes()
 for p,expected in json.loads((b/'source/manifest.json').read_text())['files'].items():assert sha(root/p)==expected,p
def run(label,argv,timeout=1800):
 check();print('START',label,flush=True);started=time.monotonic_ns()
 with (b/(label+'.stdout')).open('xb') as out,(b/(label+'.stderr')).open('xb') as err:p=subprocess.run(argv,stdout=out,stderr=err,timeout=timeout)
 rows.append(dict(label=label,argv=argv,source_manifest_sha256=manifest,exit=p.returncode,elapsed_ns=time.monotonic_ns()-started));(b/'screen-receipt.json').write_text(json.dumps(rows,indent=2)+'\n');print('END',label,p.returncode,flush=True)
 if p.returncode:print((b/(label+'.stderr')).read_text()[-5000:])
 assert p.returncode==0,label
run('source-guards-final',['python3','-B','scripts/check-source-guards.py','--output',str(b/'source-guards-final')])
run('build',['cargo','build','--release','--locked','-p','scriptw-cli','-p','scriptw-aot-wasm','--test','emission','--example','compiler_precompiled_baseline','--example','rsc_baseline','--message-format=json-render-diagnostics'])
events=[json.loads(line) for line in (b/'build.stdout').read_text().splitlines()];assert any(e.get('reason')=='build-finished' and e['success'] for e in events)
def artifact(name):
 matches=[r for r in events if r.get('reason')=='compiler-artifact' and r['target']['name']==name];assert len(matches)==1,name;return matches[0]
emission=artifact('emission');(b/'emission-producer.json').write_text(json.dumps(dict(artifact=emission,sha256=sha(pathlib.Path(emission['executable'])),source_manifest_sha256=manifest),indent=2)+'\n');run('emission',[emission['executable'],'--test-threads=1'])
engine=artifact('scriptw_engine');rlibs=[pathlib.Path(p) for p in engine['filenames'] if p.endswith('.rlib')];assert len(rlibs)==1
linked=sorted({p for r in events if r.get('reason')=='build-script-executed' for p in r.get('linked_paths',[])})
for name,fixtures in [('aot_packed_array_descriptor_reads',['packed_array_descriptor_reads.js']),('aot_typed_number_inputs',['typed_number_inputs.js']),('aot_simple_parameters',['simple_parameters.js']),('aot_computed_key_projection',['computed_key_projection.js']),('aot_scalar_row_projection',['scalar_row_projection.js','scalar_row_projection_realms.js']),('aot_scalar_dictionary_rows',['scalar_dictionary_rows.js']),('aot_scalar_masked_rows',['scalar_masked_rows.js']),('aot_callable_capture_lifecycle',['retained_operands.js']),('aot_compact_row_regions',[])]:
 test=root/'crates/scriptw-engine/tests/aot_language'/(name+'.rs');output=b/name;argv=['rustc','--edition=2021','--test',str(test),'-L','dependency=target/release/deps','--extern','scriptw_engine='+str(rlibs[0]),'-C','link-arg=-fuse-ld=lld','-o',str(output)]
 for path in linked:argv+=['-L',path]
 (b/(name+'-producer.json')).write_text(json.dumps(dict(artifact=engine,rlib_sha256=sha(rlibs[0]),test_sha256=sha(test),fixture_sha256={n:sha(root/'crates/scriptw-engine/tests/fixtures'/n) for n in fixtures},linked_paths=linked,source_manifest_sha256=manifest,argv=argv),indent=2)+'\n');run(name+'-build',argv);run(name,[str(output),'--test-threads=1'])
f=b/'frozen';f.mkdir()
for name in ['compiler_precompiled_baseline','rsc_baseline']:
 a=artifact(name);p=pathlib.Path(a['executable']);shutil.copy2(p,f/name);(f/(name+'-producer.json')).write_text(json.dumps(dict(artifact=a,sha256=sha(p),source_manifest_sha256=manifest),indent=2)+'\n')
run('rsc-exact-smoke',[str(f/'rsc_baseline'),'target/application-benchmarks-20261102/generated-v2/rsc.js','target/application-benchmarks-20261102/generated-v2/support.json',str(b/'rsc-exact-smoke.json'),'7','3','fast'])
scratch=pathlib.Path(tempfile.mkdtemp(prefix='scriptw-packed-bitset-',dir='/tmp'));argv=['python3','-B','scripts/benchmark-situations.py','--fixtures',str(b/'fixtures'),'--host',str(f/'compiler_precompiled_baseline'),'--producer-log',str(b/'build.stdout'),'--producer-receipt',str(f/'compiler_precompiled_baseline-producer.json'),'--node','/home/jacobt/.local/share/fnm/node-versions/v24.12.0/installation/bin/node','--time',str(root/'target/performance-worker-cpu/tools/time'),'--output',str(scratch/'campaign')]
(b/'tmpfs-path.json').write_text(json.dumps(dict(scratch=str(scratch),boundary='Scored source/native images and all504children share tmpfs scratch; copied byte-for-byte to persistent evidence. No native Cargo outputs on tmpfs.'),indent=2)+'\n');run('situations',argv,3600);shutil.copytree(scratch/'campaign',b/'campaign')
for p in (scratch/'campaign').rglob('*'):
 if p.is_file():assert sha(p)==sha(b/'campaign'/p.relative_to(scratch/'campaign'))
(b/'tmpfs-copy-receipt.json').write_text(json.dumps(dict(all_file_hashes_equal=True,original=str(scratch/'campaign'),retained=str(b/'campaign')),indent=2)+'\n');check();print('CANDIDATE SCREEN COMPLETE',flush=True)
