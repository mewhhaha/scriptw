import pathlib,subprocess,json,time,tempfile,hashlib,shutil
root=pathlib.Path.cwd();b=pathlib.Path(__file__).resolve().parent;rows=[]
assert json.loads((b/'fast-comparison-campaign/campaign.json').read_text())['status']=='complete'
assert (b/'profile/diagnosis.json').is_file()
def run(label,argv,timeout=7200):
 print('START',label,flush=True);started=time.monotonic_ns()
 with (b/(label+'.stdout')).open('xb') as out,(b/(label+'.stderr')).open('xb') as err:r=subprocess.run(argv,stdout=out,stderr=err,timeout=timeout)
 rows.append(dict(label=label,argv=argv,exit_code=r.returncode,elapsed_ns=time.monotonic_ns()-started));(b/'qualification-sequence.json').write_text(json.dumps(rows,indent=2)+'\n');print('END',label,r.returncode,flush=True);assert r.returncode==0,label
run('source-audits',['python3','-B',str(b/'check_final.py')])
# This ordinary Engine-test graph uses the known other runtime-image producer.
out=root/'target/release/build/scriptw-runtime-image-4c5e86983b783f60/out'
if out.is_dir() and not out.is_symlink():
 backup=out.with_name('out-before-row-preflight-qualification');assert not backup.exists();out.rename(backup);shadow=pathlib.Path(tempfile.mkdtemp(prefix='scriptw-qualified-runtime-',dir='/tmp'));out.symlink_to(shadow,target_is_directory=True)
 (b/'qualification-runtime-staging.json').write_text(json.dumps(dict(canonical=str(out),backup=str(backup),shadow=str(shadow),restore_real_directory_before_delivery=True),indent=2)+'\n')
run('native-qualification',['python3','-B',str(b/'qualify.py')])
print('FINAL FROZEN QUALIFICATION COMPLETE',flush=True)
