import pathlib,subprocess,json,time
b=pathlib.Path(__file__).resolve().parent;rows=[]
assert json.loads((b/'fast-comparison-campaign/campaign.json').read_text())['status']=='complete'
assert (b/'profile/summary.json').is_file()
# Source audits already ran before the expensive build on these exact frozen inputs.
import hashlib
assert json.loads((b/'final-checks.json').read_text())['source_manifest_sha256']==hashlib.sha256((b/'source/manifest.json').read_bytes()).hexdigest()
assert subprocess.check_output(['git','diff','--binary','HEAD','--','crates','docs/rust-rewrite/contracts'])==(b/'source/tracked.patch').read_bytes()
for label,script,timeout in [('native-qualification','qualify.py',7200)]:
 print('START',label,flush=True);start=time.monotonic_ns()
 with (b/(label+'.stdout')).open('xb') as out,(b/(label+'.stderr')).open('xb') as err:r=subprocess.run(['python3','-B',str(b/script)],stdout=out,stderr=err,timeout=timeout)
 rows.append(dict(label=label,exit_code=r.returncode,elapsed_ns=time.monotonic_ns()-start));(b/'qualification-sequence.json').write_text(json.dumps(rows,indent=2)+'\n');print('END',label,r.returncode,flush=True);assert r.returncode==0,label
print('CURRENT FROZEN QUALIFICATION COMPLETE',flush=True)
