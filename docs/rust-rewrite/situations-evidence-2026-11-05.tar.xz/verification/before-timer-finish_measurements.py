import pathlib,subprocess,json,time,os,hashlib
root=pathlib.Path.cwd();b=pathlib.Path(__file__).resolve().parent;rows=[]
def run(label,argv,timeout=1800,env=None):
 print('START',label,flush=True);started=time.monotonic_ns()
 with (b/(label+'.stdout')).open('xb') as out,(b/(label+'.stderr')).open('xb') as err:r=subprocess.run(argv,stdout=out,stderr=err,timeout=timeout,env=env)
 rows.append(dict(label=label,argv=argv,exit_code=r.returncode,elapsed_ns=time.monotonic_ns()-started));(b/'measurements-receipt.json').write_text(json.dumps(rows,indent=2)+'\n');print('END',label,r.returncode,flush=True);assert r.returncode==0,label
assert json.loads((b/'campaign/report.json').read_text())['complete']
env=os.environ|{'SCRIPTW_SITUATIONS_NODE':'/home/jacobt/.local/share/fnm/node-versions/v24.12.0/installation/bin/node','PYTHONPATH':str(root/'scripts/tests')}
run('node-goldens-final',['python3','-B','-m','unittest','test_performance_situations.SituationTests.test_all_seed_checksums_on_pinned_node'],env=env)
run('runtime-modes',['python3','-B',str(b/'runtime_modes.py')])
run('rsc-balanced',['python3','-B',str(b/'measure_rsc.py'),'--candidate',str(b/'frozen/rsc_baseline')])
run('pmu',['python3','-B',str(b/'profile_candidate.py')])
run('static-size',['python3','-B',str(b/'size/static_and_publish.py')])
for row in json.loads((b/'profile/commands.json').read_text()):
 label='sampling-'+row['name'];print('START',label,flush=True);started=time.monotonic_ns()
 with pathlib.Path(row['stdout']).open('xb') as out,pathlib.Path(row['stderr']).open('xb') as err:r=subprocess.run(row['argv'],stdout=out,stderr=err,timeout=900)
 rows.append(dict(label=label,argv=row['argv'],exit_code=r.returncode,elapsed_ns=time.monotonic_ns()-started,stdout=row['stdout'],stderr=row['stderr']));(b/'measurements-receipt.json').write_text(json.dumps(rows,indent=2)+'\n');print('END',label,r.returncode,flush=True);assert r.returncode==0,label
run('prefix',['python3','-B',str(b/'capture_current_prefix.py')])
run('profile-diagnosis',['python3','-B',str(b/'profile/diagnose.py')])
print('FINAL MEASUREMENTS COMPLETE',flush=True)
