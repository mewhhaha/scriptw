import hashlib,json,pathlib,shutil,subprocess,tempfile,time
root=pathlib.Path.cwd();b=pathlib.Path(__file__).resolve().parent
assert json.loads((b/'native-verification-current.json').read_text())['complete']
assert json.loads((b/'source-guards-warmed/receipt.json').read_text())['passed']
assert 'OK (skipped=1)' in (b/'tooling-warmed-tests.stderr').read_text()
assert subprocess.check_output(['git','diff','--binary','HEAD','--','crates','docs/rust-rewrite/contracts'])==(b/'source/tracked.patch').read_bytes()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for path,expected in json.loads((b/'source/manifest.json').read_text())['files'].items():assert sha(root/path)==expected,path
scratch=pathlib.Path(tempfile.mkdtemp(prefix='scriptw-warmed-matrix-',dir='/tmp'))
argv=['python3','-B','scripts/benchmark-situations.py','--fixtures',str(b/'fixtures'),'--node','/home/jacobt/.local/share/fnm/node-versions/v24.12.0/installation/bin/node','--time',str(root/'target/performance-worker-cpu/tools/time'),'--host',str(b/'frozen/compiler_precompiled_baseline'),'--producer-log',str(b/'build.stdout'),'--producer-receipt',str(b/'frozen/compiler_precompiled_baseline-producer.json'),'--output',str(scratch/'campaign')]
receipt=dict(argv=argv,scratch=str(scratch),source_manifest_sha256=sha(b/'source/manifest.json'),original_short_protocol_report_sha256=sha(b/'campaign/report.json'),warmups=100,samples=21,source_qualification='Compiler and workload bytes unchanged from completed native qualification; benchmark protocol/tools changed and source/tooling checks rerun.')
(b/'warmed-matrix-prepared.json').write_text(json.dumps(receipt,indent=2)+'\n')
started=time.monotonic_ns();print('START 504-process warmed matrix',flush=True)
with (b/'warmed-matrix.stdout').open('xb') as a,(b/'warmed-matrix.stderr').open('xb') as z:p=subprocess.run(argv,cwd=root,stdout=a,stderr=z,timeout=3600)
receipt.update(exit_code=p.returncode,elapsed_ns=time.monotonic_ns()-started)
(b/'warmed-matrix-execution.json').write_text(json.dumps(receipt,indent=2)+'\n');assert p.returncode==0
r=json.loads((scratch/'campaign/report.json').read_text());assert r['complete'] and len(r['rows'])==504 and r['policy']['warmups']==100 and r['policy']['samples']==21
destination=b/'campaign-warmed';shutil.copytree(scratch/'campaign',destination)
copied=0
for path in sorted((scratch/'campaign').rglob('*')):
 if path.is_file():assert sha(path)==sha(destination/path.relative_to(scratch/'campaign'));copied+=1
receipt.update(complete=True,retained=str(destination),retained_files=copied,all_file_hashes_equal=True,checked_invocations=504*121)
(b/'warmed-matrix-execution.json').write_text(json.dumps(receipt,indent=2)+'\n')
old=b/'campaign';evidence=b/'short-warmup-evidence';evidence.mkdir()
files=[old/'report.json']
for directory in ['sources','tooling','logs','build','manifests']:files.extend(p for p in (old/directory).rglob('*') if p.is_file())
files.extend(p for p in (old/'images').rglob('*') if p.is_file() and p.suffix in ['.js','.mjs','.json'])
for path in files:
 data=path.read_bytes();data.decode('utf-8');assert b'\x00' not in data
 target=evidence/path.relative_to(old);target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
(evidence/'boundary.json').write_text(json.dumps(dict(role='Preserved completed 3-warmup/7-sample current-compiler campaign; superseded for chart publication by the100-warmup/21-sample cohort. Source/native identities retain their original values.',report_sha256=sha(old/'report.json'),native_images_excluded=True,complete=True),indent=2)+'\n')
print('WARMED MATRIX COMPLETE: 504 processes,60,984 checked calls; old cohort preserved.',flush=True)
