import pathlib,subprocess,json,time,hashlib,sys
b=pathlib.Path(__file__).resolve().parent;rows=[]
def run(label,argv,timeout=1800):
 print('START',label,flush=True);start=time.monotonic_ns()
 with (b/(label+'.stdout')).open('xb') as out,(b/(label+'.stderr')).open('xb') as err:r=subprocess.run(argv,stdout=out,stderr=err,timeout=timeout)
 rows.append(dict(label=label,argv=argv,exit_code=r.returncode,elapsed_ns=time.monotonic_ns()-start));(b/'measurements-receipt.json').write_text(json.dumps(rows,indent=2)+'\n');print('END',label,r.returncode,flush=True);assert r.returncode==0,label
assert json.loads((b/'campaign/report.json').read_text())['complete']
run('runtime-modes',['python3','-B',str(b/'runtime_modes.py')])
run('rsc-balanced',['python3','-B',str(b/'measure_rsc.py'),'--candidate',str(b/'frozen/rsc_baseline')])
run('pmu',['python3','-B',str(b/'profile_candidate.py')])
run('static-size',['python3','-B',str(b/'size/static_and_publish.py')])
p=b/'profile'
def pin(path):
 with path.open('rb') as f:h=hashlib.file_digest(f,'sha256').hexdigest()
 return dict(path=str(path),sha256=h,bytes=path.stat().st_size)
prepared=dict(status='Prepared before fresh sampling.',copies=[pin(p/name) for name in ['profile_rsc_prefix.py','symbolize_fp.py','diagnose.py','reduce.py']],source_manifest=pin(b/'source/manifest.json'),commands=pin(p/'commands.json'),baseline=pin(b/'fast-comparison-campaign/block-0-0-candidate/report.json'),binary=pin(b/'frozen/rsc_baseline'),limits='CPU1/4GiB unscored user-cycle samples; frame-pointer chains may be incomplete. No allocation or causal gain claim.')
(p/'prepared.json').write_text(json.dumps(prepared,indent=2)+'\n')
for row in json.loads((p/'commands.json').read_text()):
 label='sampling-'+row['name'];print('START',label,flush=True);start=time.monotonic_ns()
 with pathlib.Path(row['stdout']).open('xb') as out,pathlib.Path(row['stderr']).open('xb') as err:r=subprocess.run(row['argv'],stdout=out,stderr=err,timeout=900)
 rows.append(dict(label=label,argv=row['argv'],exit_code=r.returncode,elapsed_ns=time.monotonic_ns()-start,stdout=row['stdout'],stderr=row['stderr']));(b/'measurements-receipt.json').write_text(json.dumps(rows,indent=2)+'\n');print('END',label,r.returncode,flush=True);assert r.returncode==0,label
run('prefix',['python3','-B',str(b/'capture_current_prefix.py')])
print('ALL MEASUREMENTS COMPLETE',flush=True)
