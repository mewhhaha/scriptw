import json,pathlib,statistics
root=pathlib.Path.cwd();base=pathlib.Path(__file__).resolve().parent;docs=root/'docs/rust-rewrite'
r=json.loads((base/'campaign/report.json').read_text());assert r['complete'] and len(r['rows'])==504
cases={c['file']:c for c in r['cases']}
def score(name,actor):return cases[name]['runtimes'][actor]['median_ns']/1e6
aggregate=json.loads((base/'fast-comparison-campaign/aggregate.json').read_text());candidate=aggregate['engines']['candidate'];v8=aggregate['engines']['v8']
def request(engine,mode):return statistics.median(engine['cases']['rsc-'+mode])/1e6
def phase(name):return statistics.median(p[name] for p in candidate['phase_processes'])
size=json.loads((base/'size/attribution.json').read_text());assert size['program_wasm_sha256']==candidate['identity']['program_wasm_sha256']
code=next(s['total_bytes'] for s in size['sections'] if s['id']==10);data=next(s['total_bytes'] for s in size['sections'] if s['id']==11)
pbytes=size['program_wasm_bytes'];rbytes=candidate['identity']['runtime']['wasm_bytes'];mi=1048576
pmu=json.loads((base/'publication-reviewed/react-attribution-current.json').read_text())['pmu']['cohorts']
def instructions(engine,mode):return pmu['candidate-'+engine+'-'+mode]['median_of_process_median_raw_counts_per_request']['instructions:u']/1e6
verification=json.loads((base/'native-verification-current.json').read_text());assert verification['complete']
verified={row['label']:row['outcomes']['passed'] for row in verification['scopes'] if 'outcomes' in row}
engine_total=sum(verified[k] for k in ('aot_language','aot_builtins','aot_async','aot_realm_modules'))
structural_total=sum(verified[k] for k in ('structure_language','modules_realms','runtime_link','structure_builtins','structure_async','intl_temporal'))
fp=r['source_identity']['source_fingerprint']
sampling=json.loads((base/'profile/owner-tables.json').read_text())
probes=json.loads((base/'profile/diagnosis.json').read_text())['profiles']
property_owners={'wasm:helper::object_read','wasm:helper::for_in_advance','wasm:helper::ordinary_property_find','wasm:helper::intrinsic_property_find','wasm:helper::ordinary_own_descriptor','wasm:helper::object_own_keys'}
def property_share(mode):return 100*sum(row['sample_share'] for row in sampling[mode+'-current']['own'] if row['owner'] in property_owners)
rows='\n'.join(f"| `{c['file']}` | {score(c['file'],'scriptw-fast'):.3f} | {score(c['file'],'scriptw-speed'):.3f} | {score(c['file'],'v8'):.3f} |" for c in r['cases'])
p512={p['actor'].removeprefix('scriptw-'):next(c for c in p['cases'] if c['file']=='frame-branches512.js') for p in r['preparations']}
identity_note=''
control=aggregate['engines']['baseline']['identity']
if control['program_wasm_sha256']==candidate['identity']['program_wasm_sha256'] and control['runtime']==candidate['identity']['runtime']:
 identity_note='Program and runtime Wasm are byte-identical to the control; this checkpoint establishes no React execution improvement.'
text=f'''## React Server Components

Measured **2026-11-05**, React **19.3.1**, compiler `{fp[:12]}`
(base `cff119329` plus the archived source patch).
Both sync and async Flight outputs match Node exactly.

| Engine | Sync · ms | Async · ms |
| --- | ---: | ---: |
| Scriptw | {request(candidate,'sync'):.3f} | {request(candidate,'async'):.3f} |
| Node 24.12.0 / V8 | {request(v8,'sync'):.3f} | {request(v8,'async'):.3f} |

![Retained RSC request timings](assets/rsc-current/runtime.svg)

Each engine uses eight fresh processes across two balanced blocks, with three
checked warmups and seven measured requests per mode. A process retains one
Module/Realm and runs sync then async. Requests include full Flight serialization
and consumption; JSON encoding and exact-output checks follow timing. Values
are medians of process medians. The frozen prior-build control stays in the
receipts; chart bars show the latest compiler and V8. Scriptc's React build
remains unqualified; client React/DOM is a separate open scope.
{identity_note}

Cold Scriptw setup is **{phase('source_to_wasm')/1e9:.3f} s JavaScript → Wasm**,
**{phase('native_preparation')/1e9:.3f} s native preparation**, and
**{phase('module_initialization')/1e6:.3f} ms module initialization**.
Program Wasm is **{pbytes:,} B** ({code:,} B code; {data:,} B data);
shared runtime Wasm is **{rbytes:,} B**. All setup precedes request timing.
Child peak RSS includes compilation and process history; it is not live guest heap.

![RSC cold compilation phases](assets/rsc-current/compilation.svg)

Scriptw compiles P with Wasmtime 47 **Fast / OptLevel::None / SinglePass**.
Shared R is built with **SpeedAndSize / Backtracking**. Its successful native
bundle admission is silent; absence of a hit trace does not establish fallback. The cohort uses
a generic target, one CPU, 16-MiB copying GC and the recorded stack/deadline/cache settings.
The [hardware-counter diagnostic](react-attribution-current.json) records
100 checked requests after three warmups in each of three fresh processes per
engine/mode. Scriptw retires **{instructions('scriptw','sync'):.2f} million sync /
{instructions('scriptw','async'):.2f} million async user instructions per request**;
Node retires **{instructions('node','sync'):.2f} / {instructions('node','async'):.2f} million**.
Counters run without multiplexing. They count Scriptw's execution worker and
Node's main thread, including Node barrier/Promise-return edges; background
compilation/GC threads are excluded. These are unscored counts, not causal shares.

The emitted program shares immutable birth layouts and cached-read code in the
existing runtime. Strict arguments elision walks complete ordinary operands;
eval, capture and resumable refusals remain. Literal typeof and strict
null/undefined comparisons use runtime predicates while preserving operand work
and Throws. Visited-key extension copies existing immutable snapshots and boxes only the new key.
Closed numeric row loops can borrow authenticated captured arrays, use masked
indices and read own Number fields and primitive String lengths. Complete live
guards retain the original loop and completed-prefix fallback; no calls or
allocations enter the admitted loop.
Function own-data probes use the current ordinary dictionary without the
former storage gate. The seven infallible Boolean operations publish directly.
Retained private operands use initialized compiler storage; source lexical TDZ
and suspended reference owners retain their protocols.
Cached literal reads retain their original twelve-input/five-result boundary.
Closed row loops can borrow current dictionary data after checking live
extent, current key/descriptor/value and complete field guards. For repeated
low-bit masked rows with Number/string-length leaves, canonical own-data
reads validate a complete read-only period before any source body and copy its
leaves to one existing numeric array. A second authenticated dense array may
supply primitive String keys; both masks define one combined period. Unsupported
keys, holes, accessors and Proxies decline before source work. A miss resumes the whole original loop; a successful preflight uses
numeric-only loads with the original arithmetic and row identity. Other admitted
rows retain compact/dictionary guarded backedges and completed-prefix fallback.
Recipes, accessors, Proxies and incomplete regions keep their original semantics.
Scratch roots clear before the generic continuation. Projection allocates one
numeric array. Canonical recipe reads can also allocate or normalize intrinsic metadata without invoking JavaScript; rejected preflight
work remains an explicit cost.
Closed numeric branches can borrow one or two current dense Number arrays with
a proven bounded masked index. Entry validates the phase and both backings;
the body preserves each original comparison, branch and arithmetic operation.
Unsupported values and effects retain the original loop.
Local argument entries retain their two-formal bound. Runtime value,
environment, descriptor and call-transport costs remain; V8 parity is open.

Fresh user-cycle sampling attributes **{property_share('sync'):.2f}% sync /
{property_share('async'):.2f}% async** to six property/enumeration helpers' disjoint
own samples. The `vn`/`ft` page-touch loops account for
**{probes['sync-current']['probe_sample_share']*100:.2f}% /
{probes['async-current']['probe_sample_share']*100:.2f}%**. Each mode has one
sampled process and 200 checked requests after three warmups. Frame-pointer
chains can truncate; inclusive caller shares overlap. These observations do not
partition wall time or predict a change's gain. The linked diagnostic retains
raw samples, source identities and same-process prefixes.

Older allocator controls, source screens and rejected experiments retain their
own source/binary identities in the inert archive. The allocator census found
most SinglePass spill capacity in cross-block/edge homes; strictly block-local
reuse was rejected as the main hill. Entry stack budgets are distinct from spill
capacity, executed spill traffic and allocation counts. Total executed guest
allocation remains unmeasured.

Runtime ABI 51 supplies bounded UTF-8 codecs, byte streams with default readers,
events, abort signals and tasks for these fixtures. Fetch/Request/URL, DOM nodes
and full WHATWG conformance remain unsupported or unverified.

[Current report and process receipts](rsc-current.json) ·
[Size accounting](rsc-wasm-size-current.json) ·
[Inert evidence](situations-evidence-2026-11-05.tar.xz).

## Focused performance situations

Measured **2026-11-05**: **21** standalone Module programs, compiler `{fp[:12]}`,
Node **24.12.0 / V8 13.6.233.17-node.37**, Rust **1.97.1**.
Each program has its own score; no aggregate combines arbitrary operation counts.

| Program · retained call | Scriptw Fast · ms | Scriptw Speed · ms | V8 · ms |
| --- | ---: | ---: | ---: |
{rows}

Each value is the median of eight fresh-process medians across two balanced
blocks. Every process initializes one Module/Realm, then runs three checked
warmups and seven measured calls. Four inputs rotate identically in every actor;
every call checks an independent integer checksum. Bars show current configurations;
whiskers span process medians. Block medians and process summaries remain in the
[data](situations-current.json).

**Fast = None / SinglePass**, **Speed = Speed / Backtracking**. Both use Wasmtime
47, a generic target, one CPU, 16-MiB copying GC, a 4-GiB cap and no swap.
The labels select P compilation; shared R is built with SpeedAndSize /
Backtracking and uses its recorded native-image admission path.
Compilation, initialization and `prepare(input)` precede the public `run()` clock.
Wasmtime consumers have their compiler disabled. Node uses the same source in
`vm.SourceTextModule`, with normal JIT and natural GC; three warmups do not prove
optimized steady state. Timings include the public bridge and print conversion;
output draining and validation follow timing. Setup can influence timed GC/JIT.
The empty control is shown without subtraction. Benchmark scratch and prepared\nimages used tmpfs after Btrfs exhausted metadata reservations; completed raw files\nwere copied byte-for-byte into the evidence tree. File preparation remains untimed.

### Global lookup

Six constructor values are read over 1,024 passes. Deep lookup retains eight
padding captures; bound aliases sit beside the worker. Shallow/deep also differ
in padding arithmetic, and V8 may hoist aliases or global reads. Getter controls
include calls and counter increments. These differences are not isolated lookup costs.

![Global lookup](assets/situations-current/global-lookup.svg)

### Control-flow and call-site scaling

All programs make 8,192 entries and exercise every selected site with matching
checksums. Compact dispatch uses one polymorphic site and a dynamic key; switch
arms use constant keys and separate sites. This does not isolate stack-probe cost.
The 512-site native P image is **{p512['fast']['native_serialized_bytes']/mi:.2f} MiB Fast /
{p512['speed']['native_serialized_bytes']/mi:.2f} MiB Speed**;
portable P is **{p512['fast']['program_wasm_bytes']/mi:.2f} MiB**.
Native serialized sizes include metadata and data.

![Call-site scaling](assets/situations-current/frame-size.svg)

![Native program image growth](assets/situations-current/frame-native-image.svg)

### Arguments observation

Both programs make 1,024 strict calls, reassign a formal and compute the same
result. The observed case additionally reads the original arguments and length.
The difference includes that timed work and is not an allocation count.

![Arguments observation](assets/situations-current/arguments-observation.svg)

### Property mutation history

Both programs make 8,192 variable-key reads over 64 records. Untimed mutation
adds an accessor, deletes properties and restores values. Reads retain live
storage guards and complete conversion/accessor/prototype/Proxy fallback.
Indexing, key production and record reads all contribute to the score.

![Property mutation history](assets/situations-current/property-mutation-history.svg)

### Function property reads

Each program reads own length, own name and the name string's length over 8,192
passes and eight targets. Ordinary records, JavaScript functions and native
constructors have matching values/checksums. Array indexing, object-kind dispatch,
string reads and V8 feedback remain part of these scores.

![Function property reads](assets/situations-current/function-properties.svg)

### Type classification

The typeof program performs 18,432 literal comparisons across 4,096 mixed-value
passes. The strict singleton program performs 16,384 null/undefined comparisons.
Inputs cover primitive and object values, bound functions and revoked callable
Proxies. Array access, branches and loop arithmetic remain timed. All earlier
program sources and checksums are unchanged. Independent semantic controls also
cover operand Throws/TDZ and HTMLDDA, outside these timed programs.

![Type classification](assets/situations-current/type-tests.svg)

### Dynamic strict equality

Both programs execute 8,192 strict comparisons over prepared pairs. Number pairs
include NaN, signed zero and infinities. Mixed pairs cover String/BigInt content,
Symbol and object identity, boxed values, functions and revoked Proxies. Operand
coercion must not run. Preparation precedes timing; pair indexing, branches and
checksum arithmetic remain timed. Independent models check every input.

![Dynamic strict equality](assets/situations-current/strict-equality.svg)

### Enumeration

Sixteen for-in loops visit all 64 own enumerable properties of a prepared ordinary
record, checking 1,024 yielded keys and numeric value reads. Inherited nonenumerable
processing is included. Immutable visited-key snapshots are copied without
reboxing; prefix reference copying and membership comparisons remain quadratic.
Mutation, Proxy and suspension controls run separately as semantic regressions.

![For-in enumeration](assets/situations-current/enumeration.svg)

### Public-call control and verification

![Public-call control](assets/situations-current/control.svg)

All **504** situation processes and **5,040** calls passed exact checks.
The balanced RSC campaign adds 24 processes and 480 exact Flight checks.
Fresh scoped verification passes **{engine_total:,} Engine**, **{verified['emission-screen']} emission**,
**{structural_total} structural** and **380 source-guard** checks. The **769 IR** cases
reuse their original passing binary/receipts with unchanged IR/front-end inputs.
AOT units pass **{verified['aot-full']}** cases; four known bootstrap assertions remain failures.
Full workspace CI and pinned Test262 were not rerun. Eleven unchanged workspace
formatting failures and fourteen stale Intl recipes remain [owned](current-inventory.md).

[Generate/run a hill](../../CONTRIBUTING.md#focused-performance-situations) with
`--case <file.js>` and optional `--policies fast` or `speed`. Scriptc has no matched
retained-Module consumer here. These scores are separate from RSC and the older
fresh-entry kernels; they do not partition each mechanism's share of RSC cost.

'''
p=docs/'benchmarks.md';old=p.read_text();start=old.index('## React Server Components');end=old.index('<!-- runtime-comparison-details:start -->');p.write_text(old[:start]+text+old[end:])
p=root/'README.md';s=p.read_text().replace('2026-11-04','2026-11-05');start=s.index('| Sync |');end=s.index('\n\n![Retained RSC requests]',start)
s=s[:start]+f"| Sync | {request(candidate,'sync'):.2f} ms | {request(v8,'sync'):.3f} ms |\n| Async | {request(candidate,'async'):.2f} ms | {request(v8,'async'):.3f} ms |"+s[end:]
start=s.index('Cold Scriptw setup:');end=s.index('\n\n**Focused performance situations',start)
s=s[:start]+f'''Cold Scriptw setup: **{phase('source_to_wasm')/1e9:.2f} s JavaScript → Wasm**, **{phase('native_preparation')/1e9:.2f} s native preparation**,
and **{phase('module_initialization')/1e6:.2f} ms module initialization**. Program Wasm is **{pbytes/mi:.2f} MiB** ({code/mi:.2f} MiB
code, {data/mi:.2f} MiB data); shared runtime Wasm is **{rbytes/mi:.2f} MiB**.
[Size breakdown](docs/rust-rewrite/rsc-wasm-size-current.json) ·
[Benchmark details and caveats](docs/rust-rewrite/benchmarks.md) ·
[Recorded RSC build](docs/rust-rewrite/rsc-current.json).'''+s[end:]
s=s.replace('19 checked programs compare\nglobal lookup, call-site scaling, arguments, mutation, metadata, type tests and enumeration', '21 checked programs compare\nglobal lookup, calls, arguments, mutation, metadata, type tests, equality and enumeration')
start=s.index('Latest scoped verification');end=s.index('\n\n## Caveats',start)
s=s[:start]+f'''Latest scoped verification (**2026-11-05**): {engine_total:,} Engine cases,
{verified['emission-screen']} Wasm-emission, {structural_total} structural and
380 source-guard checks pass; 769 IR cases reuse unchanged inputs and original receipts.
AOT units pass {verified['aot-full']} cases; four known bootstrap assertions still fail.
The focused benchmarks passed 5,040 checked calls; React RSC passed 480 exact
Flight checks. These scopes do not replace the published full Test262 run.
Full workspace CI was not rerun; eleven formatting failures and fourteen stale
Intl recipes remain [owned](docs/rust-rewrite/current-inventory.md).'''+s[end:]
p.write_text(s)
print('Updated latest README and detail tables; pinned Test262 blocks untouched')
