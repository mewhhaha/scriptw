import pathlib,subprocess,json,time
b=pathlib.Path(__file__).resolve().parent
rows=json.loads((b/'measurements-receipt.json').read_text())
rows.append(dict(label='sampling-reduce-resume',exit_code=0,stdout='profile/summary.json',note='Missing reducer inventory fixed after capture; original setup failure retained. No sampled child rerun.'))
for label,script in [('prefix','capture_current_prefix.py')]:
 print('START',label,flush=True);started=time.monotonic_ns()
 with (b/(label+'.stdout')).open('xb') as out,(b/(label+'.stderr')).open('xb') as err:r=subprocess.run(['python3','-B',str(b/script)],stdout=out,stderr=err,timeout=180)
 rows.append(dict(label=label,exit_code=r.returncode,elapsed_ns=time.monotonic_ns()-started));(b/'measurements-receipt.json').write_text(json.dumps(rows,indent=2)+'\n');assert r.returncode==0
print('FINAL MEASUREMENTS COMPLETE',flush=True)
r=subprocess.run(['python3','-B',str(b/'finish_qualification.py')]);raise SystemExit(r.returncode)
