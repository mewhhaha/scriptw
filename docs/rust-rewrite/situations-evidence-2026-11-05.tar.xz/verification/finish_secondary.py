"""Serial post-qualification sensitivity and physical-type diagnostics."""
import hashlib,json,os,pathlib,subprocess,time
b=pathlib.Path(__file__).resolve().parent;stage=b.parent/'allocation-expanded-labels-staged'
assert json.loads((b/'native-verification-current.json').read_text())['complete']
rows=[]
def run(label,argv,cwd,env,out,err):
 print('START',label,flush=True);started=time.monotonic_ns()
 with pathlib.Path(out).open('xb') as a,pathlib.Path(err).open('xb') as z:p=subprocess.run(argv,cwd=cwd,env=os.environ|env,stdout=a,stderr=z,timeout=900)
 row=dict(label=label,argv=argv,cwd=cwd,environment_overrides=env,stdout=str(out),stderr=str(err),exit_code=p.returncode,elapsed_ns=time.monotonic_ns()-started)
 rows.append(row);(b/'secondary-diagnostics.json').write_text(json.dumps(rows,indent=2)+'\n')
 print('END',label,p.returncode,flush=True)
 if p.returncode:print(pathlib.Path(err).read_text()[-4000:])
 assert p.returncode==0,label
run('warmup-sensitivity',['python3','-B',str(b/'warmup_sensitivity.py')],str(pathlib.Path.cwd()),{},b/'warmup-sensitivity.stdout',b/'warmup-sensitivity.stderr')
for row in json.loads((stage/'commands.json').read_text()):
 run(row['label'],row['argv'],row['cwd'],row.get('env',{}),row['stdout'],row['stderr'])
row=json.loads((stage/'reducer-commands.json').read_text())
run('expanded-reduction',row['argv'],str(pathlib.Path.cwd()),{},stage/'reduction.stdout',stage/'reduction.stderr')
evidence=stage/'reduction/publication-evidence/root-execution';evidence.mkdir()
files=[pathlib.Path(__file__),b/'secondary-diagnostics.json',stage/'commands.json',stage/'reducer-commands.json']
for row in rows:
 if row['label']!='warmup-sensitivity':files.extend([pathlib.Path(row['stdout']),pathlib.Path(row['stderr'])])
inventory=[]
for index,p in enumerate(files):
 data=p.read_bytes();data.decode('utf-8');assert b'\x00' not in data
 name=f'{index}-{p.name}';(evidence/name).write_bytes(data);inventory.append(dict(file=name,original=str(p),sha256=hashlib.sha256(data).hexdigest()))
(evidence/'inventory.json').write_text(json.dumps(inventory,indent=2)+'\n')
print('SECONDARY DIAGNOSTICS COMPLETE',flush=True)
