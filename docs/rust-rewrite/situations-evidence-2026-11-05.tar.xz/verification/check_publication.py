"""Check the delivered ABI51 reports, preserved status, charts and evidence."""
import argparse
import gzip
import hashlib
import json
from pathlib import Path
import re
import subprocess
import tarfile
from publication_contract import ALLOCATION_EVIDENCE, ALLOCATION_REPORT, BASE, PRIOR, ROOT, allocation_report, candidate_identity, digest, native_counts, read, validate_allocation_evidence


def old(path):
    return subprocess.check_output(['git', 'show', PRIOR + ':' + path], cwd=ROOT)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--allocation-report', type=Path, default=ALLOCATION_REPORT)
    parser.add_argument('--allocation-evidence', type=Path, default=ALLOCATION_EVIDENCE)
    args = parser.parse_args()
    docs = ROOT / 'docs/rust-rewrite'
    identity = candidate_identity()
    counts = native_counts(read(BASE / 'native-verification-current.json'))
    readme, before = (ROOT / 'README.md').read_bytes(), old('README.md')
    for marker in ('runtime-comparison', 'application-benchmarks', 'scriptw-status', 'scriptw-test-graph'):
        pattern = re.compile(rb'<!-- ' + marker.encode() + rb':start -->.*?<!-- ' + marker.encode() + rb':end -->', re.S)
        assert pattern.search(readme).group() == pattern.search(before).group(), marker
    for path in ('docs/rust-rewrite/test262-current.md', 'docs/rust-rewrite/assets/test262-status.svg'):
        assert (ROOT / path).read_bytes() == old(path), path
    situations, rsc = read(docs / 'situations-current.json'), read(docs / 'rsc-current.json')
    assert len(situations['cases']) == 21
    assert situations['publication']['coverage']['fresh_execution_processes'] == 504
    assert situations['publication']['coverage']['checked_invocations'] == 60984
    assert rsc['engines']['candidate']['identity'] == identity
    metadata = situations['evidence_archive']
    assert rsc['evidence_archive'] == metadata
    archive = ROOT / metadata['file']
    assert archive.name == 'situations-evidence-2026-11-05.tar.xz'
    assert digest(archive) == metadata['sha256'] and archive.stat().st_size == metadata['bytes']
    current = read(docs / 'react-allocation-current.json')
    checked = allocation_report(docs / 'react-allocation-current.json', identity)
    expected = allocation_report(args.allocation_report, identity)
    assert all(checked[key] == value for key, value in expected.items()), 'current allocation values changed during publication'
    assert current['evidence_archive'] == metadata
    prior = read(BASE / 'baseline-react-allocation-current.json')
    assert (BASE / 'baseline-react-allocation-current.json').read_bytes() == old('docs/rust-rewrite/react-allocation-current.json')
    assert current['prior_diagnostic']['scored_baseline'] == prior['scored_baseline']
    assert prior['scored_baseline']['runtime_sha256'] != identity['runtime']['wasm_sha256']
    evidence = args.allocation_evidence.resolve(strict=True)
    prefix = 'additional-evidence/' + evidence.relative_to(ROOT).as_posix() + '/'
    assert current['evidence_prefix'] == prefix
    evidence_files = [path for path in evidence.rglob('*') if path.is_file()]
    assert evidence_files, 'fresh allocation evidence tree is empty'
    validate_allocation_evidence(evidence, current)
    reports = ('situations-current.json', 'rsc-current.json', 'react-attribution-current.json', 'react-allocation-current.json')
    with tarfile.open(archive, 'r:xz') as packed:
        index_bytes = packed.extractfile('INDEX.json').read()
        sha = lambda data: hashlib.sha256(data).hexdigest()
        assert packed.extractfile('INDEX.json.sha256').read().decode().strip() == sha(index_bytes) + '  INDEX.json'
        index = json.loads(index_bytes)
        members = packed.getmembers()
        assert len(members) == len(index['members']) + 2
        assert {member.name for member in members} == {row['path'] for row in index['members']} | {'INDEX.json', 'INDEX.json.sha256'}
        assert all(member.isfile() and member.mode == 0o644 for member in members)
        for row in index['members']:
            value = packed.extractfile(row['path']).read()
            assert len(value) == row['bytes'] and sha(value) == row['sha256'] and b'\0' not in value
            value.decode('utf-8', errors='strict')
        for name in reports:
            public = read(docs / name)
            assert public.pop('evidence_archive') == metadata
            assert json.loads(packed.extractfile('reports/' + name).read()) == public
        assert packed.extractfile('baseline/reports/react-allocation-current.json').read() == old('docs/rust-rewrite/react-allocation-current.json')
        for path in evidence_files:
            relative = path.relative_to(evidence).as_posix()
            value = path.read_bytes()
            member = prefix + relative
            if path.suffix == '.gz':
                value = gzip.decompress(value)
                member = member[:-3]
            value.decode('utf-8', errors='strict')
            assert b'\0' not in value
            assert packed.extractfile(member).read() == value, relative
    old_archive = BASE / 'baseline-situations-evidence-2026-11-05.tar.xz'
    assert old_archive.read_bytes() == old('docs/rust-rewrite/situations-evidence-2026-11-05.tar.xz')
    folders = ('docs/rust-rewrite/assets/situations-current', 'docs/rust-rewrite/assets/rsc-current')
    expected_svgs = {path for path in subprocess.check_output(['git', 'ls-tree', '-r', '--name-only', PRIOR, '--', *folders], cwd=ROOT).decode().splitlines() if path.endswith('.svg')}
    actual_svgs = {path.relative_to(ROOT).as_posix() for folder in folders for path in (ROOT / folder).glob('*.svg')}
    assert len(actual_svgs) == 12 and actual_svgs == expected_svgs, 'current chart set changed'
    for folder in ('deps', 'examples'):
        path = ROOT / 'target/release' / folder
        assert path.is_dir() and not path.is_symlink()
        assert all(not item.resolve(strict=True).is_relative_to('/tmp') for item in path.iterdir())
    for path in (ROOT / 'target/release/build').glob('scriptw-runtime-image-*/out'):
        assert not path.is_symlink()
    receipt = dict(complete=True, preserved_published_blocks=4, pinned_test262_unchanged=True,
        charts=len(actual_svgs), evidence=metadata, allocation_census_artifacts_match=True,
        allocation_census_evidence_files=len(evidence_files), prior_allocation_is_baseline=True,
        canonical_build_outputs_persistent=True, full_native_targets={name: row for name, row in counts.items()})
    (BASE / 'publication-checks.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt))


if __name__ == '__main__':
    main()
