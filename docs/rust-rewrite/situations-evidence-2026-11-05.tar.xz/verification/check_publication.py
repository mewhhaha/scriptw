import hashlib,json,pathlib,re,subprocess
root=pathlib.Path.cwd();b=pathlib.Path(__file__).resolve().parent;docs=root/'docs/rust-rewrite';prior='cff1193296b63317839e1a689583a0600953035a'
def digest(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def old(path):return subprocess.check_output(['git','show',prior+':'+path])
readme=(root/'README.md').read_bytes();before=old('README.md')
for marker in ['runtime-comparison','application-benchmarks','scriptw-status','scriptw-test-graph']:
 pattern=re.compile(rb'<!-- '+marker.encode()+rb':start -->.*?<!-- '+marker.encode()+rb':end -->',re.S)
 assert pattern.search(readme).group()==pattern.search(before).group(),marker
for path in ['docs/rust-rewrite/test262-current.md','docs/rust-rewrite/assets/test262-status.svg']:
 assert (root/path).read_bytes()==old(path),path
situations=json.loads((docs/'situations-current.json').read_text());rsc=json.loads((docs/'rsc-current.json').read_text())
assert len(situations['cases'])==21 and situations['publication']['coverage']['fresh_execution_processes']==504
assert situations['publication']['coverage']['checked_invocations']==5040
meta=situations['evidence_archive'];assert rsc['evidence_archive']==meta
archive=root/meta['file'];assert archive.is_file() and digest(archive)==meta['sha256']
assert archive.name=='situations-evidence-2026-11-05.tar.xz'
# Prior current archive is preserved byte-for-byte and remains reachable in Git.
old_archive=b/'baseline-situations-evidence-2026-11-05.tar.xz'
assert old_archive.read_bytes()==old('docs/rust-rewrite/situations-evidence-2026-11-05.tar.xz')
svgs=sorted((docs/'assets/situations-current').glob('*.svg'))+sorted((docs/'assets/rsc-current').glob('*.svg'))
assert len(svgs)==12,len(svgs)
assert not any('situations-evidence-2026-11-04.tar.xz' in (root/p).read_text() for p in ['README.md','docs/rust-rewrite/benchmarks.md'])
for name in ['deps','examples']:
 p=root/'target/release'/name;assert p.is_dir() and not p.is_symlink()
 assert all(not f.resolve(strict=True).is_relative_to('/tmp') for f in p.iterdir())
for p in (root/'target/release/build').glob('scriptw-runtime-image-*/out'):assert not p.is_symlink()
receipt=dict(complete=True,preserved_published_blocks=4,pinned_test262_unchanged=True,charts=len(svgs),evidence=meta,canonical_build_outputs_persistent=True)
(b/'publication-checks.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
