import pathlib,hashlib,json,shutil,subprocess
root=pathlib.Path.cwd();b=pathlib.Path(__file__).resolve().parent;old=b.parent/'strict-predicate'
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert head=='f267e94cf25b6de0dcf5a4d14e1b2d7d09616664'
oldpath=str(old.relative_to(root));newpath=str(b.relative_to(root));earlier='target/performance-v8-climb-20261104/typed-region'
for name in ['measure_rsc.py','qualify.py','profile_candidate.py','runtime_modes.py','capture_current_prefix.py','prefix_capture.py','publish.py','publish_current.py','check_publication.py','update_docs.py','finish_measurements.py','finish_qualification.py']:
 s=(old/name).read_text().replace(oldpath,newpath)
 if name=='measure_rsc.py':s=s.replace(earlier,oldpath).replace('6c20f2fa7cb9aed32c37281a8d876e417a871ce39f6b91f76d11fbac187f4d02','1f29203f93acdfc2e816edbf65b70b951cc0322707a57e71bf6fe6141052f474')
 if name=='qualify.py':s=s.replace("for label in ('emission-build','build'):","for label in ('build',):")
 (b/name).write_text(s)
for folder,names in [('size',['static_and_publish.py','dump_rsc.rs','analyze.py']),('profile',['profile_rsc_prefix.py','symbolize_fp.py','diagnose.py','reduce.py','commands.json'])]:
 (b/folder).mkdir()
 for name in names:(b/folder/name).write_text((old/folder/name).read_text().replace(oldpath,newpath))
for folder in ['fixtures','source-ir-reused']:shutil.copytree(old/folder,b/folder)
shutil.copy2(old/'ir-full.json',b/'ir-full.json')
for name in ['situations-current.json','rsc-current.json','rsc-wasm-size-current.json','react-attribution-current.json','react-allocation-current.json','situations-evidence-2026-11-05.tar.xz']:shutil.copy2(root/'docs/rust-rewrite'/name,b/('baseline-'+name))
source=b/'source';source.mkdir();patch=subprocess.check_output(['git','diff','--binary','HEAD','--','crates','docs/rust-rewrite/contracts']);(source/'tracked.patch').write_bytes(patch);files={}
for name in subprocess.check_output(['git','ls-files','--others','--exclude-standard','--','crates','docs/rust-rewrite/contracts']).decode().splitlines():
 p=root/name;d=source/name;d.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,d);files[name]=hashlib.sha256(p.read_bytes()).hexdigest()
m=dict(base_commit=head,tracked_patch_sha256=hashlib.sha256(patch).hexdigest(),files=files);(source/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');h=hashlib.sha256((source/'manifest.json').read_bytes()).hexdigest()
r=json.loads((old/'ir-source-equivalence.json').read_text());r.update(final_manifest_sha256=h,final_base=head);(b/'ir-source-equivalence.json').write_text(json.dumps(r,indent=2)+'\n')
print('FROZEN SOURCE',h)
