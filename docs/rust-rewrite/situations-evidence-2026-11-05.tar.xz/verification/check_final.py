import hashlib,json,pathlib,re,subprocess,time
root=pathlib.Path.cwd();b=pathlib.Path(__file__).resolve().parent;rows=[]
changed=subprocess.check_output(['git','diff','--name-only','HEAD','--','crates'],text=True).splitlines()+subprocess.check_output(['git','ls-files','--others','--exclude-standard','--','crates'],text=True).splitlines();changed=sorted(p for p in changed if p.endswith('.rs'))
def run(label,argv,allowed=(0,)):
 started=time.monotonic_ns()
 with (b/(label+'.stdout')).open('xb') as out,(b/(label+'.stderr')).open('xb') as err:r=subprocess.run(argv,stdout=out,stderr=err,timeout=120)
 rows.append(dict(label=label,argv=argv,exit_code=r.returncode,elapsed_ns=time.monotonic_ns()-started));assert r.returncode in allowed,label
run('format-changed',['rustfmt','--check','--edition','2021','--config','skip_children=true',*changed])
run('format-workspace',['cargo','fmt','--all','--','--check'],(1,))
run('ownership-final',['python3','-B','scripts/conformance_owners.py'])
run('product-graph-final',['./scripts/check-no-interpreter-in-product-graph.sh'])
run('intl-identities-final',['python3','-B','scripts/intl_source_identities.py'],(1,))
run('diff-final',['git','diff','--check'])
old=json.loads((b.parent/'strict-predicate/final-checks.json').read_text());formatted=sorted(set(re.findall(r'Diff in (.+?):\d+', (b/'format-workspace.stdout').read_text())));formatted=[str(pathlib.Path(p).relative_to(root)) for p in formatted]
assert formatted==old['workspace_format_failures'],formatted
stale=[line for line in (b/'intl-identities-final.stdout').read_text().splitlines() if line.startswith('FAIL ')];assert stale==old['stale_intl_recipes'],stale
r=dict(source_manifest_sha256=hashlib.sha256((b/'source/manifest.json').read_bytes()).hexdigest(),changed_rust_files=changed,workspace_format_failures=formatted,stale_intl_recipes=stale,commands=rows,limits='Changed Rust clean; same11workspace formatting failures/14staleIntlrecipes remain owned. Product/compiler source frozen; no full workspace CI or pinnedTest262 rerun.')
(b/'final-checks.json').write_text(json.dumps(r,indent=2)+'\n');print('SOURCE CHECKS PASSED')
