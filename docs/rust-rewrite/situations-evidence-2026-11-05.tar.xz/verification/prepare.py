import pathlib,hashlib,json,shutil,subprocess
root=pathlib.Path.cwd();b=pathlib.Path(__file__).resolve().parent;old=b.parent/'typed-region';prior=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert prior=='086fe17fa1f0c59e5a29bf37704ba8675de252b0'
oldpath=str(old.relative_to(root));newpath=str(b.relative_to(root));older='target/performance-v8-climb-20261104/cyclic-projection'
for name in ['screen.py','measure_rsc.py','qualify.py','check_final.py','profile_candidate.py','runtime_modes.py','capture_current_prefix.py','prefix_capture.py','publish.py','publish_current.py','check_publication.py','update_docs.py','finish_measurements.py','finish_qualification.py']:
 s=(old/name).read_text().replace(oldpath,newpath)
 if name in ['measure_rsc.py','screen.py']:s=s.replace(older+'/frozen/rsc_baseline',oldpath+'/frozen/rsc_baseline').replace(older+'/fast-comparison-campaign/',oldpath+'/fast-comparison-campaign/')
 if name=='measure_rsc.py':s=s.replace('142eb280817c6e302f130ccec6f0c2b3fc0a96f31f430dc5aea69862c9b36d20','6c20f2fa7cb9aed32c37281a8d876e417a871ce39f6b91f76d11fbac187f4d02')
 if name in ['publish.py','check_publication.py']:s=s.replace('cff1193296b63317839e1a689583a0600953035a',prior)
 if name=='publish_current.py':
  s=s.replace(older+'/candidate-pmu-receipt.json',oldpath+'/candidate-pmu-receipt.json')
  s=s.replace("root/'target/performance-v8-climb-20261104/typed-region-staged'","root/'target/performance-v8-climb-20261104/strict-predicate-staged'")
 if name=='update_docs.py':
  s=s.replace('cff119329',prior[:9])
  s=s.replace('Closed numeric branches can borrow one or two current dense Number arrays with\na proven bounded masked index. Entry validates the phase and both backings;\nthe body preserves each original comparison, branch and arithmetic operation.\nUnsupported values and effects retain the original loop.', 'Closed strict comparisons can precompute a pure repeating input period from\ntwo current dense arrays through the canonical equality kernel. One private\nnumeric buffer and a bounded integer induction retain the original branches,\narithmetic order and publication. Strings, BigInts and references keep exact\nsemantics. Unsupported values and effects retain the original loop.')
 (b/name).write_text(s)
for folder,names in [('size',['static_and_publish.py','dump_rsc.rs','analyze.py']),('profile',['profile_rsc_prefix.py','symbolize_fp.py','diagnose.py','reduce.py','commands.json'])]:
 (b/folder).mkdir()
 for name in names:(b/folder/name).write_text((old/folder/name).read_text().replace(oldpath,newpath))
for folder in ['fixtures','source-ir-reused']:shutil.copytree(old/folder,b/folder)
shutil.copy2(old/'ir-full.json',b/'ir-full.json')
for name in ['situations-current.json','rsc-current.json','rsc-wasm-size-current.json','react-attribution-current.json','situations-evidence-2026-11-05.tar.xz']:shutil.copy2(root/'docs/rust-rewrite'/name,b/('baseline-'+name))
s=b/'source';s.mkdir();patch=subprocess.check_output(['git','diff','--binary','HEAD','--','crates','docs/rust-rewrite/contracts']);(s/'tracked.patch').write_bytes(patch);files={}
for name in subprocess.check_output(['git','ls-files','--others','--exclude-standard','--','crates','docs/rust-rewrite/contracts']).decode().splitlines():
 p=root/name;d=s/name;d.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,d);files[name]=hashlib.sha256(p.read_bytes()).hexdigest()
m=dict(base_commit=prior,tracked_patch_sha256=hashlib.sha256(patch).hexdigest(),files=files);(s/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');h=hashlib.sha256((s/'manifest.json').read_bytes()).hexdigest()
r=json.loads((old/'ir-source-equivalence.json').read_text());r['final_manifest_sha256']=h;(b/'ir-source-equivalence.json').write_text(json.dumps(r,indent=2)+'\n');print(h)
