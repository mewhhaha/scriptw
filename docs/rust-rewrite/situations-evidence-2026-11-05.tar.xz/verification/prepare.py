import pathlib,hashlib,json,shutil,subprocess
root=pathlib.Path.cwd();b=pathlib.Path(__file__).resolve().parent;old=b.parent/'key-and-parameter';prior=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert prior=='2d8b5896c4d61528a0e802906b1d016118475ce8'
for name in ['screen.py','measure_rsc.py','qualify.py','check_final.py','profile_candidate.py','runtime_modes.py','capture_current_prefix.py','prefix_capture.py','publish.py','publish_current.py','update_docs.py','finish_measurements.py','finish_qualification.py']:
 s=(old/name).read_text().replace('target/performance-v8-climb-20261104/key-and-parameter','target/performance-v8-climb-20261104/cyclic-projection')
 if name=='publish.py':s=s.replace("('emission', 64)","('emission', 63)").replace("                        'Strict simple private formals use initialized source storage; eval-visible/captured/non-simple formals retain checked owners.',\n",'')
 if name=='update_docs.py':
  s=s.replace('Retained private operands use initialized compiler storage. Proven strict simple\nlocal formals use initialized source storage; non-simple parameters, captured\ncells, source lexical TDZ and suspended reference owners retain their protocols.','Retained private operands use initialized compiler storage; source lexical TDZ\nand suspended reference owners retain their protocols.')
 if name=='publish_current.py':
  a=s.index('for p in (b/');z=s.index(':\n argv+=',a)
  s=s[:a]+"for p in (b/'size',b/'profile',root/'target/performance-v8-climb-20261104/key-and-parameter',root/'target/performance-v8-climb-20261104/computed-only-staged',root/'target/performance-v8-climb-20261104/computed-key-projection-staged')"+s[z:]
 (b/name).write_text(s)
for folder,names in [('size',['static_and_publish.py','dump_rsc.rs','analyze.py']),('profile',['profile_rsc_prefix.py','symbolize_fp.py','diagnose.py','reduce.py','commands.json'])]:
 (b/folder).mkdir()
 for name in names:(b/folder/name).write_text((old/folder/name).read_text().replace('target/performance-v8-climb-20261104/key-and-parameter','target/performance-v8-climb-20261104/cyclic-projection'))
for folder in ['fixtures','source-ir-reused']:shutil.copytree(old/folder,b/folder)
for name in ['ir-full.json']:shutil.copy2(old/name,b/name)
for name in ['situations-current.json','rsc-current.json','rsc-wasm-size-current.json','react-attribution-current.json','situations-evidence-2026-11-05.tar.xz']:shutil.copy2(root/'docs/rust-rewrite'/name,b/('baseline-'+name))
s=b/'source';s.mkdir();patch=subprocess.check_output(['git','diff','--binary','HEAD','--','crates','docs/rust-rewrite/contracts']);(s/'tracked.patch').write_bytes(patch);files={}
for name in subprocess.check_output(['git','ls-files','--others','--exclude-standard','--','crates','docs/rust-rewrite/contracts']).decode().splitlines():
 p=root/name;d=s/name;d.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,d);files[name]=hashlib.sha256(p.read_bytes()).hexdigest()
m=dict(base_commit=prior,tracked_patch_sha256=hashlib.sha256(patch).hexdigest(),files=files);(s/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');h=hashlib.sha256((s/'manifest.json').read_bytes()).hexdigest()
r=json.loads((old/'ir-source-equivalence.json').read_text());r['final_manifest_sha256']=h;(b/'ir-source-equivalence.json').write_text(json.dumps(r,indent=2)+'\n')
(b/'retention-decision.json').write_text(json.dumps(dict(source_manifest_sha256=h,rejected_parameter_source_manifest_sha256='ba97cfdac85064d7f08ecf1b592fa8b08d1b7da1fe729d5ebee523d31c1edde2',reason='Computed-key projection is a large measured win. Extra parameter proof has only ~0.5 percent RSC instruction reduction and no clear workload gain; do not retain unproven machinery. Separate-cohort frame differences are not attributed causally.',kept_semantic_parameter_tests=2,source_base=prior),indent=2)+'\n');print(h)
