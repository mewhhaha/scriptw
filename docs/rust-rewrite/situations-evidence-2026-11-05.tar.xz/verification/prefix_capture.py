"""Optional four fresh diagnostic children; capture 192-byte prefixes, no perf sampling."""
import ctypes
import hashlib
import json
from pathlib import Path
import re
import socket
import subprocess
import time

ROOT = Path.cwd()
OUT = Path(__file__).resolve().parent


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def capture(plan, built, reference, binary, env, validate):
    folder = OUT / 'prefixes'
    folder.mkdir(exist_ok=False)
    result = {'schema': 'scriptw-rsc-four-quadrant-prefixes-v1', 'unscored': True, 'status': 'incomplete', 'limits': 'Separate prefix-only diagnostic children, not timing cohort. No perf sampling. Native stack-check immediate includes ABI/alignment overhead and is not a spill-only measurement.', 'modes': {}}
    try:
        for mode in plan['modes']:
            print('START prefix', mode, flush=True)
            here = folder / mode
            here.mkdir()
            parent, child_socket = socket.socketpair()
            nonce = __import__('os').urandom(16).hex()
            child_env = dict(env)
            child_env.update(SCRIPTW_RSC_PROFILE_FD=str(child_socket.fileno()), SCRIPTW_RSC_PROFILE_NONCE=nonce, SCRIPTW_RSC_PROFILE_MODE='sync')
            report = here / 'observations.json'
            argv = [str(binary), reference['inputs']['source'], reference['inputs']['support'], str(report), '1', '1', mode]
            child = None
            record = {'argv': argv, 'status': 'incomplete'}
            started = time.monotonic()
            deadline = started + 180
            try:
                with (here / 'host.stdout').open('xb') as out, (here / 'host.stderr').open('xb') as err:
                    child = subprocess.Popen(argv, cwd=ROOT, env=child_env, stdout=out, stderr=err, stdin=subprocess.DEVNULL, pass_fds=(child_socket.fileno(),))
                    child_socket.close()
                    for phase in ['ready', 'done']:
                        parent.settimeout(max(0.1, deadline - time.monotonic()))
                        expected = f'SWRSC1 {nonce} {phase} sync 1\n'.encode()
                        event = b''
                        while len(event) < len(expected):
                            part = parent.recv(len(expected) - len(event))
                            assert part, ('closed barrier', phase, child.poll())
                            event += part
                        assert event == expected, (event, expected)
                        if phase == 'ready':
                            perf_map = Path(f'/tmp/perf-{child.pid}.map')
                            (here / 'perf.map').write_bytes(perf_map.read_bytes())
                            (here / 'maps.txt').write_text(Path(f'/proc/{child.pid}/maps').read_text())
                            class IOVec(ctypes.Structure):
                                _fields_ = [('base', ctypes.c_void_p), ('length', ctypes.c_size_t)]
                            libc = ctypes.CDLL(None, use_errno=True)
                            libc.process_vm_readv.restype = ctypes.c_ssize_t
                            prefixes = []
                            for line in perf_map.read_text().splitlines():
                                address, length, name = line.split(maxsplit=2)
                                if name not in ['js::vn#f133', 'js::ft#f123']:
                                    continue
                                address, length = int(address, 16), int(length, 16)
                                buffer = ctypes.create_string_buffer(192)
                                local = IOVec(ctypes.cast(buffer, ctypes.c_void_p), 192)
                                remote = IOVec(address, 192)
                                count = libc.process_vm_readv(child.pid, ctypes.byref(local), 1, ctypes.byref(remote), 1, 0)
                                assert count == 192, (count, ctypes.get_errno(), name)
                                data = bytes(buffer)
                                stem = name.split('::')[1].split('#')[0]
                                prefix = here / (stem + '-prefix.bin')
                                prefix.write_bytes(data)
                                with (here / (stem + '-prefix.asm')).open('xb') as asm, (here / (stem + '-objdump.stderr')).open('xb') as err:
                                    decoded = subprocess.run(['/usr/bin/objdump', '-D', '-b', 'binary', '-m', 'i386:x86-64', str(prefix)], stdout=asm, stderr=err, timeout=5)
                                assert decoded.returncode == 0
                                asm = (here / (stem + '-prefix.asm')).read_text()
                                match = re.search(r'add\s+\$0x([0-9a-f]+),%r10', asm)
                                assert match, ('stack-check immediate not found', mode, name)
                                prefixes.append({'name': name, 'address': address, 'native_bytes': length, 'prefix_sha256': hashlib.sha256(data).hexdigest(), 'prefix_hex': data.hex(), 'entry_stack_check_budget_bytes': int(match[1], 16)})
                            assert len(prefixes) == 2, prefixes
                            record.update(pid=child.pid, functions=prefixes, provenance='Own-child process_vm_readv during ready barrier before measured call; optional profiler enables PerfMap only; no sampler/debugger.')
                        parent.sendall(expected.replace(b'SWRSC1', b'SWACK1', 1))
                    record['exit_code'] = child.wait(timeout=max(0.1, deadline - time.monotonic()))
                assert record['exit_code'] == 0
                row = json.loads(report.read_text())
                validate(row, reference, mode, plan, cases=1, samples=1, warmups=1)
                assert row['executable_sha256'] == built['executable_sha256']
                assert row['profiling']['nonce'] == nonce and row['profiling']['excluded_from_scored_cohorts'] is True
                record.update(status='complete', report_sha256=hashlib.sha256(report.read_bytes()).hexdigest())
            except BaseException as error:
                record.update(status='failed', error=repr(error))
                raise
            finally:
                if child is not None and child.poll() is None:
                    child.kill()
                    child.wait(timeout=5)
                parent.close()
                child_socket.close()
                record['elapsed_seconds'] = time.monotonic() - started
                save(here / 'receipt.json', record)
                result['modes'][mode] = record
                save(folder / 'receipt.json', result)
            print('END prefix', mode, flush=True)
        result['status'] = 'complete'
    except BaseException as error:
        result.update(status='failed', error=repr(error))
        raise
    finally:
        save(folder / 'receipt.json', result)
