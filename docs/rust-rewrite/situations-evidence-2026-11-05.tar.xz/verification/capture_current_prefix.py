import hashlib,json,pathlib,sys
root=pathlib.Path.cwd(); b=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(root/'scripts'))
from limited_verification import limited_environment,require_kernel_budget
from prefix_capture import capture
require_kernel_budget(4*1024**3)
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
refpath=b/'fast-comparison-campaign/block-0-0-candidate/report.json'
reference=json.loads(refpath.read_text());binary=b/'frozen/rsc_baseline'
assert reference['executable_sha256']==sha(binary)
plan=dict(modes=['fast'],source_manifest_sha256=sha(b/'source/manifest.json'),reference_sha256=sha(refpath),driver_sha256=sha(b/'prefix_capture.py'),limits='Separate unscored prefix-only child; two exact Flight checks, no sampling. Entry budget is not spill-only capacity.')
(b/'prefix-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
def validate(row,ref,mode,plan,cases,samples,warmups):
 assert row['status']=='complete'
 for key in ['program_wasm_sha256','program_wasm_bytes','runtime','inputs','source_fingerprint','source_commit','toolchain','compiler_identity_scheme','configuration','native_mode']:
  assert row[key]==ref[key],key
 assert mode=='fast' and len(row['cases'])==cases==1
 refs={c['case']:c for c in ref['cases']}
 for c in row['cases']:
  assert c['exact_node_output_checked'] is True
  assert c['samples']==samples==1 and c['warmups']==warmups==1 and len(c['observations'])==2
  assert sum(not o['warmup'] for o in c['observations'])==1
  for key in ['expected_json_sha256','expected_json_bytes']:assert c[key]==refs[c['case']][key]
capture(plan,{'executable_sha256':sha(binary)},reference,binary,limited_environment(),validate)
