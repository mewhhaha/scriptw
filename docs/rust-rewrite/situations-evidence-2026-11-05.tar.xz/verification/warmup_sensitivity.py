"""Unscored warmup sensitivity using unchanged frozen hosts and native images."""
import hashlib,json,os,pathlib,shutil,statistics,subprocess,time
b=pathlib.Path(__file__).resolve().parent;root=pathlib.Path.cwd();campaign=b/'campaign'
r=json.loads((campaign/'report.json').read_text());assert r['complete']
out=b/'warmup-sensitivity';out.mkdir();shutil.copyfile(__file__,out/'driver.py');rows=[];samples=21;warmups=100
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
host=campaign/r['tools']['host']['path'];node=pathlib.Path(r['tools']['node']['path'])
assert sha(host)==r['tools']['host']['sha256'] and sha(node)==r['tools']['node']['sha256']
adapter=campaign/'tooling/crates/scriptw-cli/tests/fixtures/v8_baseline/node-situations.cjs'
source=campaign/'sources';cases=['strict-equality-numbers.js','strict-equality-mixed.js']
pins={str(p):sha(p) for p in [host,node,adapter,source/'manifest.json',b/'source/manifest.json',pathlib.Path(__file__)]}
for case in cases:
 entry=next(c for c in r['workloads'] if c['file']==case)
 assert sha(source/case)==entry['source_sha256'];pins[str(source/case)]=sha(source/case)
for block,actors in enumerate([['scriptw-fast','scriptw-speed','v8'],['v8','scriptw-speed','scriptw-fast']]):
 for round_ in range(2):
  for case in cases:
   entry=next(c for c in r['workloads'] if c['file']==case)
   for actor in actors:
    label=f'{block}-{round_}-{actor}-{case}';directory=out/label;directory.mkdir()
    if actor=='v8':argv=[str(node),'--experimental-vm-modules','--no-warnings',str(adapter),str(source),case,str(samples),str(warmups)]
    else:
     preparation=next(p for p in r['preparations'] if p['actor']==actor and case in p['selected'])
     producer=next(p for p in preparation['cases'] if p['file']==case)
     image=campaign/producer['image_path'];assert sha(image)==producer['image_sha256'];pins[str(image)]=sha(image)
     expected_producer=next(row['raw']['producer'] for row in r['rows'] if row['file']==case and row['actor']==actor)
     assert json.loads(image.with_suffix('.json').read_text())==expected_producer
     argv=[str(host),'execute-retained',str(image),entry['stdout'],str(samples),str(warmups)]
    environment=os.environ|{'SCRIPTW_JOBS':'1','SCRIPTW_MODULE_MEMORY_CACHE_ENTRIES':'1','SCRIPTW_MODULE_MEMORY_CACHE_LIMIT_BYTES':'67108864','NODE_DISABLE_COMPILE_CACHE':'1'}
    command=['python3','-B','scripts/limited_verification.py','--',*argv]
    started=time.monotonic_ns()
    with (directory/'stdout').open('xb') as a,(directory/'stderr').open('xb') as z:p=subprocess.run(command,cwd=root,env=environment,stdout=a,stderr=z,timeout=120)
    receipt=dict(block=block,round=round_,case=case,actor=actor,argv=command,exit_code=p.returncode,elapsed_ns=time.monotonic_ns()-started)
    (directory/'process.json').write_text(json.dumps(receipt,indent=2)+'\n');assert p.returncode==0,label
    actual=json.loads((directory/'stdout').read_text());assert actual['samples']==samples and actual['warmups']==warmups
    assert len(actual['observations'])==samples+warmups
    if actor=='v8':assert actual['execution_policy']==dict(jit='normal',gc='natural') and actual['source_sha256']==entry['source_sha256']
    else:
     assert actual['producer']==expected_producer and actual['initialization_count']==1 and actual['compiler_enabled'] is False
     assert actual['executable_sha256']==pins[str(host)] and actual['producer']['original_source_sha256']==entry['source_sha256']
    times=[]
    for index,observation in enumerate(actual['observations']):
     invocation=entry['invocations'][index%4]
     assert observation['index']==index and observation['warmup']==(index<warmups)
     assert observation['invocation_index']==index%4 and observation['input']==invocation['input']
     assert observation['matched'] is True and observation['stdout']==invocation['stdout']
     if index>=warmups:times.append(observation['call_ns'])
    rows.append(dict(receipt,median_ns=statistics.median(times),samples_ns=times,stdout_sha256=sha(directory/'stdout')))
    print(label,statistics.median(times)/1e6,flush=True)
assert all(sha(pathlib.Path(path))==digest for path,digest in pins.items())
summary={case:{actor:dict(median_of_process_medians_ns=statistics.median(row['median_ns'] for row in rows if row['case']==case and row['actor']==actor),process_medians_ns=[row['median_ns'] for row in rows if row['case']==case and row['actor']==actor]) for actor in actors} for case in cases}
(out/'summary.json').write_text(json.dumps(dict(complete=True,excluded_from_scored_cohorts=True,warmups=warmups,samples=samples,fresh_processes=len(rows),checked_invocations=len(rows)*(samples+warmups),pins=pins,cases=summary,rows=rows,limits='Warmup sensitivity only. Four fresh processes per actor/case, normal V8 JIT and natural GC. Native consumers and all source/image bytes unchanged; preparation remains outside run timing. One hundred warmups do not prove optimized steady state. Main published 3-warmup/7-sample cohort remains separate.'),indent=2)+'\n')
print('WARMUP SENSITIVITY COMPLETE',flush=True)
