"""Synthetic in-memory producer/consumer schema controls; never execute a guest."""
import contextlib
import copy
import io
import importlib.util
import json
from pathlib import Path
import tempfile
import runpy
import sys
from publication_contract import ALLOCATION_BASE, BASE, PROGRAM, RUNTIME, SOURCE, allocation_report, candidate_identity, digest, read, validate_allocation


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def main():
    builder_path = ALLOCATION_BASE / 'build_public_report.py'
    reducer_path = ALLOCATION_BASE / 'reduce_physical_types.py'
    verifier_path = ALLOCATION_BASE / 'labels/verify.py'
    identities = {str(path): digest(path) for path in (builder_path, reducer_path, verifier_path, BASE / 'publication_contract.py')}
    builder = module('allocation_report_builder', builder_path)
    reducer = module('allocation_physical_reducer', reducer_path)
    identity = candidate_identity()
    names = ('StoredValue', 'BindingCell', 'StringValue', 'CodeUnitArray', 'ValueArray',
        'PropertyKeyTable', 'ForInEnumerationRecord', 'OrdinaryObject', 'OrdinaryPropertyStorage',
        'PropertyTable', 'OrdinaryPropertyIndex', 'PropertyEntry', 'PropertyDescriptor')
    # These synthetic ordinals/counts test schema wiring only. They are never
    # evidence about actual heap types or allocations and cannot be published.
    labels = [[kind, str(100 + index), name] for kind in ('P', 'R') for index, name in enumerate(names)]
    metadata = {name: dict(kind_bits=0, wasm_aliases=[['P', 100 + index], ['R', 100 + index]],
        semantic_labels=[name], unresolved_kind_bucket=False) for index, name in enumerate(names)}
    physical_cases, payload_cases = {}, {}
    for case in ('rsc-sync', 'rsc-async'):
        physical_cases[case], payload_cases[case] = {}, {}
        for partition, public_partition, samples in (('warmup', 'warmups', 3), ('measured', 'measured', 7)):
            physical_cases[case][partition], payload_cases[case][public_partition] = {}, {}
            for boundary in ('request', 'with_validation_cumulative', 'validation_increment'):
                groups = []
                for process in range(2):
                    observations = []
                    for sample in range(samples):
                        counts = {}
                        for index, name in enumerate(names):
                            request = index + process + sample + 1
                            increment = index % 2
                            if name == 'BindingCell':
                                increment = 0
                            value = request
                            if boundary == 'validation_increment':
                                value = increment
                            if boundary == 'with_validation_cumulative':
                                value = request + increment
                            counts[name] = [value, value * 32]
                        observations.append(dict(collections=0, objects=sum(row[0] for row in counts.values()),
                            bytes=sum(row[1] for row in counts.values()), types=counts))
                    groups.append(observations)
                reduced = reducer.reduce_groups(groups, metadata)
                physical_cases[case][partition][boundary] = reduced
                if boundary != 'validation_increment':
                    stored = next(row for row in reduced['physical_types'] if 'StoredValue' in row['semantic_labels'])['objects']
                    payload_cases[case][public_partition][boundary] = dict(observations=reduced['observations'],
                        processes=2, stored_values=stored, tags={'Number': copy.deepcopy(stored)},
                        number_categories={'signed31_integer': copy.deepcopy(stored)})
    pins = read(ALLOCATION_BASE / 'current-pins.json')
    scored = dict(P_sha256=PROGRAM, R_sha256=RUNTIME)
    size = read(BASE / 'size/attribution.json')
    proof = dict(admitted=True, scored_baseline=scored, P={'bytes': size['program_wasm_bytes']},
                 R={'bytes': identity['runtime']['wasm_bytes']})
    validation = dict(complete=True, exact_flight_outputs=80, valid_on_request_epochs=40, identity=identity)
    physical = dict(complete=True, exact_flight_checks=80, valid_on_request_epochs=40,
        scored_baseline=scored, scored_source_manifest_sha256=SOURCE,
        labels=labels, expanded_physical_types=physical_cases)
    payload = dict(scored_baseline=scored, scored_source_manifest_sha256=SOURCE, cases=payload_cases,
        tag_schema={'source_only_schema_fixture': True, 'mapping': {'fixture-tag': 'Number'}},
        limits=['Synthetic schema fixture; these counts are not measurements.'])
    result = json.loads(json.dumps(builder.build_report(pins, proof, validation, physical, payload)))
    result['source_only_schema_fixture'] = True
    validate_allocation(result, identity)
    checks = ['actual-pure-builder-to-consumer', 'all13-labels', 'warmups-and-measured',
              'request-cumulative-and-increment', 'physical-payload-StoredValue-equality']

    def rejects(name, change):
        changed = copy.deepcopy(result)
        change(changed)
        try:
            validate_allocation(changed, identity)
        except (RuntimeError, KeyError, ValueError, TypeError):
            checks.append(name)
        else:
            raise AssertionError('invalid synthetic schema admitted: ' + name)

    rejects('old-runtime-rejected', lambda report: report['scored_baseline'].update(runtime_sha256='3e6493ab4c88e59e46ae481f89cb44e52b4b462c62cb6cf7adeeae8af0ac3b53'))
    rejects('old-flat-totals-rejected', lambda report: report['cases']['rsc-sync']['request_allocations']['measured'].pop('totals'))
    rejects('missing-warmup-boundary-rejected', lambda report: report['cases']['rsc-sync']['with_validation_allocations'].pop('warmups'))
    rejects('unauthenticated-type-label-rejected', lambda report: report['expanded_physical_types']['boundary_cases']['rsc-sync']['measured']['request']['physical_types'][0]['semantic_labels'].append('unverified-label'))
    def wrong_payload(report):
        row = report['cases']['rsc-sync']['stored_value_payload']['measured']['request']['stored_values']
        row.update(median_of_process_medians=row['median_of_process_medians'] + 1,
            process_medians=[value + 1 for value in row['process_medians']],
            minimum=row['minimum'] + 1, maximum=row['maximum'] + 1)
    rejects('payload-physical-count-mismatch-rejected', wrong_payload)
    with tempfile.TemporaryDirectory(prefix='synthetic-allocation-schema-', dir=BASE) as temporary:
        path = Path(temporary) / 'synthetic-schema.json'
        path.write_text(json.dumps(result))
        try:
            allocation_report(path, identity)
        except RuntimeError:
            checks.append('synthetic-fixture-publication-rejected')
        else:
            raise AssertionError('synthetic schema fixture could be published')
    # Exercise the exact Python verifier with throwaway text fixtures only.
    # No label reader, Wasm module, or guest is executed by these controls.
    with tempfile.TemporaryDirectory(prefix='synthetic-label-schema-', dir=BASE) as temporary:
        stage = Path(temporary)
        verifier = stage / 'verify.py'
        verifier.write_bytes(verifier_path.read_bytes())
        executable = stage / 'synthetic-reader.txt'
        executable.write_text('Synthetic text standing in for a hashed input; never executable.\n')
        label_file = stage / 'type-labels.tsv'
        producer_path = stage / 'producer-prepared.json'
        producer = dict(input_sha256={str(executable): digest(executable), str(verifier): digest(verifier)},
            reference_sha256={}, outputs=dict(executable=str(executable), labels=str(label_file)))
        producer_path.write_text(json.dumps(producer))

        def verify(mode, failure=False):
            original = sys.argv
            sys.argv = [str(verifier), mode]
            failed = False
            try:
                with contextlib.redirect_stdout(io.StringIO()):
                    runpy.run_path(str(verifier), run_name='__main__')
            except (AssertionError, KeyError, ValueError):
                failed = True
            finally:
                sys.argv = original
            assert failed == failure, ('label source fixture result differs', mode, failure)

        verify('inputs')
        checks.append('actual-label-verifier-input-pins')
        label_text = 'module\twasm_type_index\tlabel\n' + ''.join('\t'.join(row) + '\n' for row in labels)
        label_file.write_text(label_text)
        verify('inputs', failure=True)
        checks.append('existing-label-output-rejected')
        verify('output')
        checked_labels = json.loads((stage / 'receipt.json').read_text())
        assert checked_labels['labels'] == labels and checked_labels['producer_sha256'] == digest(producer_path)
        checks.append('actual-label-verifier26-witness-receipt')
        executable.write_text('changed synthetic input\n')
        verify('inputs', failure=True)
        checks.append('changed-label-producer-input-rejected')
        executable.write_text('Synthetic text standing in for a hashed input; never executable.\n')
        label_file.write_text('\n'.join(label_text.splitlines()[:-1]) + '\n')
        verify('output', failure=True)
        checks.append('missing-label-witness-rejected')
        label_file.unlink()
        producer['input_sha256'].pop(str(executable))
        producer_path.write_text(json.dumps(producer))
        verify('inputs', failure=True)
        checks.append('unpinned-label-reader-rejected')
    assert all(digest(Path(path)) == value for path, value in identities.items()), 'schema source changed during controls'
    receipt = dict(complete=True, source_only=True, synthetic_data=True, guest_workloads=0,
        public_reports_written=0, source_identities=identities, checks=checks,
        limits='Synthetic producer/consumer and label-verifier controls only. Temporary text inputs and counts/type ordinals are not measurement evidence; no native or guest execution.')
    (BASE / 'allocation-schema-checks.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt, indent=2))


if __name__ == '__main__':
    main()
