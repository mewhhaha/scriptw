"""Publish the verified current ABI51 batch when its fresh allocation run is ready."""
import argparse
import json
from pathlib import Path
import shutil
import subprocess
import time
from publication_contract import ALLOCATION_EVIDENCE, ALLOCATION_REPORT, BASE, ROOT, allocation_report, candidate_identity, digest, native_counts, read, validate_allocation_evidence


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--allocation-report', type=Path, default=ALLOCATION_REPORT)
    parser.add_argument('--allocation-evidence', type=Path, default=ALLOCATION_EVIDENCE)
    parser.add_argument('--output-dir', type=Path, default=BASE / 'publication-reviewed-final')
    args = parser.parse_args()
    # Resolve every external prerequisite before staging or changing canonical docs.
    identity = candidate_identity()
    native_counts(read(BASE / 'native-verification-current.json'))
    census = allocation_report(args.allocation_report, identity)
    validate_allocation_evidence(args.allocation_evidence, census)
    assert args.allocation_evidence.is_dir(), 'Fresh allocation evidence is missing'
    assert not args.output_dir.exists(), 'Publication stage already exists'
    size = read(BASE / 'size/attribution.json')
    assert size['program_wasm_sha256'] == identity['program_wasm_sha256']
    assert size['runtime_wasm_sha256'] == identity['runtime']['wasm_sha256']
    rows = []

    def run(label, argv, timeout=900):
        print('START', label, flush=True)
        start = time.monotonic_ns()
        with (BASE / ('final-' + label + '.stdout')).open('xb') as out, (BASE / ('final-' + label + '.stderr')).open('xb') as err:
            result = subprocess.run(argv, stdout=out, stderr=err, timeout=timeout)
        rows.append(dict(label=label, argv=argv, exit_code=result.returncode, elapsed_ns=time.monotonic_ns() - start))
        (BASE / 'publication-final-receipt.json').write_text(json.dumps(rows, indent=2) + '\n')
        print('END', label, result.returncode, flush=True)
        assert result.returncode == 0, label

    argv = ['python3', '-B', str(BASE / 'publish.py'), '--output-dir', str(args.output_dir),
        '--native-report', str(BASE / 'native-verification-current.json'),
        '--situations', str(BASE / 'campaign'), '--source-guards', str(BASE / 'source-guards-final.stdout'),
        '--baseline-pmu-receipt', 'target/performance-v8-climb-20261104/strict-predicate/candidate-pmu-receipt.json',
        '--candidate-pmu-receipt', str(BASE / 'candidate-pmu-receipt.json'),
        '--allocation-report', str(args.allocation_report), '--allocation-evidence', str(args.allocation_evidence)]
    for path in (BASE / 'size', BASE / 'profile', BASE / 'source-guards-final'):
        argv += ['--extra-text-evidence', str(path)]
    supporting_receipts = []
    for name in ('descriptor-scaling', 'numeric-paired'):
        supporting = BASE / name
        report_path = supporting / 'report.json'
        if not report_path.is_file():
            continue
        diagnostic = read(report_path)
        if diagnostic.get('complete') is not True:
            continue
        if name == 'descriptor-scaling':
            assert diagnostic['status'] == 'complete'
            assert all(row['status'] == 'ok' for row in diagnostic['rows'])
            assert diagnostic['source_identity']['source_fingerprint'] == read(BASE / 'campaign/report.json')['source_identity']['source_fingerprint']
        else:
            actors = {'baseline-fast', 'candidate-fast', 'baseline-speed', 'candidate-speed', 'v8'}
            cases = {'strict-equality-numbers.js', 'strict-equality-mixed.js'}
            assert len(diagnostic['rows']) == 80 and diagnostic['checked_invocations'] == 9680
            assert diagnostic['policy']['warmups'] == 100 and diagnostic['policy']['samples'] == 21
            assert diagnostic['policy']['blocks'] == 2
            assert {row['file'] for row in diagnostic['rows']} == cases
            assert {row['actor'] for row in diagnostic['rows']} == actors
            assert next(row for row in diagnostic['sources'] if row['name'] == 'candidate')['report_sha256'] == digest(BASE / 'campaign/report.json')
            assert diagnostic['tooling_sha256'] == digest(BASE / 'numeric_paired.py')
            for case in cases:
                for actor in actors:
                    selected = [row for row in diagnostic['rows'] if row['file'] == case and row['actor'] == actor]
                    assert len(selected) == 8
                    assert all(sum(row['block'] == block for row in selected) == 4 for block in (0, 1))
            for row in diagnostic['rows']:
                assert row['accounting']['exit_code'] == 0 and not row['accounting']['timed_out']
                assert len(row['samples_ns']) == 21
                stdout = supporting / row['stdout']
                assert digest(stdout) == row['stdout_sha256']
                assert digest(stdout.with_suffix('.stderr')) == row['stderr_sha256']
        argv += ['--extra-text-evidence', str(supporting)]
        if name == 'numeric-paired':
            argv += ['--extra-text-evidence', str(BASE / 'numeric_paired.py')]
        supporting_receipts.append(dict(name=name, report_sha256=digest(report_path),
            complete=True, archive_prefix='additional-evidence/' + supporting.relative_to(ROOT).as_posix() + '/',
            scope='Supporting evidence only; excluded from the 21-case chart matrix.'))
    (BASE / 'supporting-evidence-receipt.json').write_text(json.dumps(supporting_receipts, indent=2) + '\n')
    run('publication-stage', argv, timeout=1800)
    # All current report bodies, including newly admitted allocation counts,
    # share this verified inert archive. Historical allocation counts stay baseline.
    for name in ('situations-evidence-2026-11-05.tar.xz', 'situations-current.json', 'rsc-current.json',
                 'react-attribution-current.json', 'react-allocation-current.json'):
        shutil.copy2(args.output_dir / name, ROOT / 'docs/rust-rewrite' / name)
    shutil.copy2(BASE / 'size/attribution.json', ROOT / 'docs/rust-rewrite/rsc-wasm-size-current.json')
    run('docs-update', ['python3', '-B', str(BASE / 'update_docs.py')])
    python = str(ROOT / 'target/readme-chart-env/bin/python')
    common = ['scripts/render-situation-benchmarks.py', '--report', 'docs/rust-rewrite/situations-current.json',
              '--output-dir', 'docs/rust-rewrite/assets/situations-current']
    run('situations-render', [python, '-B', *common, '--preview-dir', str(BASE / 'previews/situations')])
    run('situations-render-check', [python, '-B', *common, '--check'])
    common = ['scripts/render-application-benchmarks.py', '--rsc-json', 'docs/rust-rewrite/rsc-current.json']
    run('rsc-render', [python, '-B', *common, '--preview-dir', str(BASE / 'previews/rsc')])
    run('rsc-render-check', [python, '-B', *common, '--check'])
    run('publication-check', ['python3', '-B', str(BASE / 'check_publication.py'),
        '--allocation-report', str(args.allocation_report), '--allocation-evidence', str(args.allocation_evidence)])
    run('diff-publication', ['git', 'diff', '--check'])
    print('CURRENT VERIFIED ABI51 PUBLICATION COPIED AND CHARTS RENDERED', flush=True)


if __name__ == '__main__':
    main()
