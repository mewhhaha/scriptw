import pathlib,subprocess,json,shutil,time
root=pathlib.Path.cwd();b=pathlib.Path(__file__).resolve().parent;rows=[]
verified=json.loads((b/'native-verification-current.json').read_text());assert verified['complete']
def run(label,argv,timeout=900):
 print('START',label,flush=True);start=time.monotonic_ns()
 with (b/('final-'+label+'.stdout')).open('xb') as out,(b/('final-'+label+'.stderr')).open('xb') as err:r=subprocess.run(argv,stdout=out,stderr=err,timeout=timeout)
 rows.append(dict(label=label,argv=argv,exit_code=r.returncode,elapsed_ns=time.monotonic_ns()-start));(b/'publication-final-receipt.json').write_text(json.dumps(rows,indent=2)+'\n');print('END',label,r.returncode,flush=True);assert r.returncode==0,label
out=b/'publication-reviewed-final'
argv=['python3','-B',str(b/'publish.py'),'--output-dir',str(out),'--native-report',str(b/'native-verification-current.json'),'--situations',str(b/'campaign-warmed'),'--source-guards',str(b/'source-guards-warmed.stdout'),'--baseline-pmu-receipt','target/performance-v8-climb-20261104/typed-region/candidate-pmu-receipt.json','--candidate-pmu-receipt',str(b/'candidate-pmu-receipt.json')]
for p in (b/'size',b/'profile',b/'warmup-sensitivity',b/'short-warmup-evidence',b/'source-guards-warmed',root/'target/performance-v8-climb-20261104/strict-predicate-staged',root/'target/performance-v8-climb-20261104/allocation-census-next/publication-evidence',root/'target/performance-v8-climb-20261104/allocation-expanded-labels-staged/reduction/publication-evidence',root/'target/performance-v8-climb-20261104/entry-breakpoints-staged'):
 argv+=['--extra-text-evidence',str(p)]
run('publication-stage',argv,timeout=1800)
# Preserve full byte identities before placing only the inert publication in docs.
for name in ('situations-evidence-2026-11-05.tar.xz','situations-current.json','rsc-current.json','react-attribution-current.json'):
 shutil.copy2(out/name,root/'docs/rust-rewrite'/name)
shutil.copy2(b/'size/attribution.json',root/'docs/rust-rewrite/rsc-wasm-size-current.json')
census=json.loads((root/'target/performance-v8-climb-20261104/allocation-census-next/public-current.json').read_text())
expanded=root/'target/performance-v8-climb-20261104/allocation-expanded-labels-staged'
extension=json.loads((expanded/'reduction/public-extension.json').read_text())
assert extension['program_wasm_sha256']==census['scored_baseline']['program_sha256']
assert extension['runtime']==census['diagnostic_identity']['runtime']
census['expanded_physical_types']=extension
census['labels']=json.loads((expanded/'receipt.json').read_text())['labels']
census['expanded_label_evidence_prefix']='additional-evidence/target/performance-v8-climb-20261104/allocation-expanded-labels-staged/reduction/publication-evidence/'
census['limits']=[p for p in census['limits'] if not p.startswith('Only StoredValue and BindingCell')]
census['limits'].append('Thirteen physical labels are authenticated by exact helper signatures/field graphs. Other aliases/raw IDs remain explicit. Type labels do not identify allocation origins.')
entries=json.loads((root/'target/performance-v8-climb-20261104/entry-breakpoints-staged/public-current.json').read_text())
assert entries['complete'] and entries['identity']['program_wasm_sha256']==census['scored_baseline']['program_sha256']
assert entries['identity']['runtime']==census['diagnostic_identity']['runtime']
census['source_entry_diagnostic']=entries
latest_rsc=json.loads((root/'docs/rust-rewrite/rsc-current.json').read_text())
assert census['scored_baseline']['program_sha256']==latest_rsc['engines']['candidate']['identity']['program_wasm_sha256']
assert census['scored_baseline']['runtime_sha256']==latest_rsc['engines']['candidate']['identity']['runtime']['wasm_sha256']
census['evidence_archive']=json.loads((root/'docs/rust-rewrite/situations-current.json').read_text())['evidence_archive']
(root/'docs/rust-rewrite/react-allocation-current.json').write_text(json.dumps(census,indent=2)+'\n')
run('docs-update',['python3','-B',str(b/'update_docs.py')])
python=str(root/'target/readme-chart-env/bin/python')
common=['scripts/render-situation-benchmarks.py','--report','docs/rust-rewrite/situations-current.json','--output-dir','docs/rust-rewrite/assets/situations-current']
run('situations-render',[python,'-B',*common,'--preview-dir',str(b/'previews/situations')])
run('situations-render-check',[python,'-B',*common,'--check'])
common=['scripts/render-application-benchmarks.py','--rsc-json','docs/rust-rewrite/rsc-current.json']
run('rsc-render',[python,'-B',*common,'--preview-dir',str(b/'previews/rsc')])
run('rsc-render-check',[python,'-B',*common,'--check'])
run('diff-publication',['git','diff','--check'])
print('CURRENT VERIFIED PUBLICATION COPIED AND CHARTS RENDERED',flush=True)
