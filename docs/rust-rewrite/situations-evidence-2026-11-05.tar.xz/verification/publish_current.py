import pathlib,subprocess,json,shutil,time
root=pathlib.Path.cwd();b=pathlib.Path(__file__).resolve().parent;rows=[]
verified=json.loads((b/'native-verification-current.json').read_text());assert verified['complete']
def run(label,argv,timeout=900):
 print('START',label,flush=True);start=time.monotonic_ns()
 with (b/(label+'.stdout')).open('xb') as out,(b/(label+'.stderr')).open('xb') as err:r=subprocess.run(argv,stdout=out,stderr=err,timeout=timeout)
 rows.append(dict(label=label,argv=argv,exit_code=r.returncode,elapsed_ns=time.monotonic_ns()-start));(b/'publication-receipt.json').write_text(json.dumps(rows,indent=2)+'\n');print('END',label,r.returncode,flush=True);assert r.returncode==0,label
out=b/'publication-reviewed'
argv=['python3','-B',str(b/'publish.py'),'--output-dir',str(out),'--native-report',str(b/'native-verification-current.json'),'--source-guards',str(b/'source-guards-final.stdout'),'--baseline-pmu-receipt','target/performance-v8-climb-20261104/cyclic-projection/candidate-pmu-receipt.json','--candidate-pmu-receipt',str(b/'candidate-pmu-receipt.json')]
for p in (b/'size',b/'profile',root/'target/performance-v8-climb-20261104/typed-region-staged'):
 argv+=['--extra-text-evidence',str(p)]
run('publication-stage',argv,timeout=1800)
# Preserve full byte identities before placing only the inert publication in docs.
for name in ('situations-evidence-2026-11-05.tar.xz','situations-current.json','rsc-current.json','react-attribution-current.json'):
 shutil.copy2(out/name,root/'docs/rust-rewrite'/name)
shutil.copy2(b/'size/attribution.json',root/'docs/rust-rewrite/rsc-wasm-size-current.json')
run('docs-update',['python3','-B',str(b/'update_docs.py')])
python=str(root/'target/readme-chart-env/bin/python')
common=['scripts/render-situation-benchmarks.py','--report','docs/rust-rewrite/situations-current.json','--output-dir','docs/rust-rewrite/assets/situations-current']
run('situations-render',[python,'-B',*common,'--preview-dir',str(b/'previews/situations')])
run('situations-render-check',[python,'-B',*common,'--check'])
common=['scripts/render-application-benchmarks.py','--rsc-json','docs/rust-rewrite/rsc-current.json']
run('rsc-render',[python,'-B',*common,'--preview-dir',str(b/'previews/rsc')])
run('rsc-render-check',[python,'-B',*common,'--check'])
run('diff-publication',['git','diff','--check'])
print('CURRENT VERIFIED PUBLICATION COPIED AND CHARTS RENDERED',flush=True)
