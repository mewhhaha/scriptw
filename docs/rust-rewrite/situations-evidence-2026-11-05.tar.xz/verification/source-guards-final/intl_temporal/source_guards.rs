#[path = "/home/jacobt/src/scriptw/crates/scriptw-aot-wasm/tests/intl_temporal/intl_canonical_locale_tag_invocation_structure.rs"]
mod intl_canonical_locale_tag_invocation_structure;
#[path = "/home/jacobt/src/scriptw/crates/scriptw-aot-wasm/tests/intl_temporal/intl_locale_string_slot_domain_structure.rs"]
mod intl_locale_string_slot_domain_structure;
#[path = "/home/jacobt/src/scriptw/crates/scriptw-aot-wasm/tests/intl_temporal/intl_namespace_plan_structure.rs"]
mod intl_namespace_plan_structure;
#[path = "/home/jacobt/src/scriptw/crates/scriptw-aot-wasm/tests/intl_temporal/intl_supported_values_structure.rs"]
mod intl_supported_values_structure;
#[path = "/home/jacobt/src/scriptw/crates/scriptw-aot-wasm/tests/intl_temporal/temporal_calendar_canonicalization_context_structure.rs"]
mod temporal_calendar_canonicalization_context_structure;
#[path = "/home/jacobt/src/scriptw/crates/scriptw-aot-wasm/tests/intl_temporal/temporal_calendar_carrier_privacy_structure.rs"]
mod temporal_calendar_carrier_privacy_structure;
#[path = "/home/jacobt/src/scriptw/crates/scriptw-aot-wasm/tests/intl_temporal/temporal_conversion_overflow_options_structure.rs"]
mod temporal_conversion_overflow_options_structure;
#[path = "/home/jacobt/src/scriptw/crates/scriptw-aot-wasm/tests/intl_temporal/temporal_date_field_read_mode_structure.rs"]
mod temporal_date_field_read_mode_structure;
#[path = "/home/jacobt/src/scriptw/crates/scriptw-aot-wasm/tests/intl_temporal/temporal_duration_arithmetic_operation_structure.rs"]
mod temporal_duration_arithmetic_operation_structure;
#[path = "/home/jacobt/src/scriptw/crates/scriptw-aot-wasm/tests/intl_temporal/temporal_duration_field_transform_structure.rs"]
mod temporal_duration_field_transform_structure;
#[path = "/home/jacobt/src/scriptw/crates/scriptw-aot-wasm/tests/intl_temporal/temporal_duration_number_fields_structure.rs"]
mod temporal_duration_number_fields_structure;
#[path = "/home/jacobt/src/scriptw/crates/scriptw-aot-wasm/tests/intl_temporal/temporal_field_offset_table_privacy_structure.rs"]
mod temporal_field_offset_table_privacy_structure;
#[path = "/home/jacobt/src/scriptw/crates/scriptw-aot-wasm/tests/intl_temporal/temporal_instant_diagnostic_privacy_structure.rs"]
mod temporal_instant_diagnostic_privacy_structure;
#[path = "/home/jacobt/src/scriptw/crates/scriptw-aot-wasm/tests/intl_temporal/temporal_instant_epoch_proof_structure.rs"]
mod temporal_instant_epoch_proof_structure;
#[path = "/home/jacobt/src/scriptw/crates/scriptw-aot-wasm/tests/intl_temporal/temporal_instant_methods_structure.rs"]
mod temporal_instant_methods_structure;
#[path = "/home/jacobt/src/scriptw/crates/scriptw-aot-wasm/tests/intl_temporal/temporal_namespace_plan_structure.rs"]
mod temporal_namespace_plan_structure;
#[path = "/home/jacobt/src/scriptw/crates/scriptw-aot-wasm/tests/intl_temporal/temporal_plain_arithmetic_operation_structure.rs"]
mod temporal_plain_arithmetic_operation_structure;
#[path = "/home/jacobt/src/scriptw/crates/scriptw-aot-wasm/tests/intl_temporal/temporal_plain_date_time_component_structure.rs"]
mod temporal_plain_date_time_component_structure;
#[path = "/home/jacobt/src/scriptw/crates/scriptw-aot-wasm/tests/intl_temporal/temporal_plain_date_time_field_read_mode_structure.rs"]
mod temporal_plain_date_time_field_read_mode_structure;
#[path = "/home/jacobt/src/scriptw/crates/scriptw-aot-wasm/tests/intl_temporal/temporal_plain_difference_operation_structure.rs"]
mod temporal_plain_difference_operation_structure;
#[path = "/home/jacobt/src/scriptw/crates/scriptw-aot-wasm/tests/intl_temporal/temporal_plain_month_day_parsed_year_privacy_structure.rs"]
mod temporal_plain_month_day_parsed_year_privacy_structure;
#[path = "/home/jacobt/src/scriptw/crates/scriptw-aot-wasm/tests/intl_temporal/temporal_plain_time_field_authority_structure.rs"]
mod temporal_plain_time_field_authority_structure;
#[path = "/home/jacobt/src/scriptw/crates/scriptw-aot-wasm/tests/intl_temporal/temporal_plain_year_month_field_read_mode_structure.rs"]
mod temporal_plain_year_month_field_read_mode_structure;
#[path = "/home/jacobt/src/scriptw/crates/scriptw-aot-wasm/tests/intl_temporal/temporal_unit_option_property_domain_structure.rs"]
mod temporal_unit_option_property_domain_structure;
#[path = "/home/jacobt/src/scriptw/crates/scriptw-aot-wasm/tests/intl_temporal/temporal_zoned_date_time_calendar_coercion_structure.rs"]
mod temporal_zoned_date_time_calendar_coercion_structure;
#[path = "/home/jacobt/src/scriptw/crates/scriptw-aot-wasm/tests/intl_temporal/temporal_zoned_date_time_difference_defaults_structure.rs"]
mod temporal_zoned_date_time_difference_defaults_structure;
#[path = "/home/jacobt/src/scriptw/crates/scriptw-aot-wasm/tests/intl_temporal/temporal_zoned_date_time_dispatch_structure.rs"]
mod temporal_zoned_date_time_dispatch_structure;
