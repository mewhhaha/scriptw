#[path = "/home/jacobt/src/scriptw/crates/scriptw-aot-wasm/tests/runtime_link/host_import_function_indices_structure.rs"]
mod host_import_function_indices_structure;
#[path = "/home/jacobt/src/scriptw/crates/scriptw-aot-wasm/tests/runtime_link/runtime_error_active_handler_structure.rs"]
mod runtime_error_active_handler_structure;
#[path = "/home/jacobt/src/scriptw/crates/scriptw-aot-wasm/tests/runtime_link/runtime_regexp_entry_kind_structure.rs"]
mod runtime_regexp_entry_kind_structure;
#[path = "/home/jacobt/src/scriptw/crates/scriptw-aot-wasm/tests/runtime_link/thrown_error_diagnostic_kind_authority_structure.rs"]
mod thrown_error_diagnostic_kind_authority_structure;
#[path = "/home/jacobt/src/scriptw/crates/scriptw-aot-wasm/tests/runtime_link/unhandled_rejection_reporting_structure.rs"]
mod unhandled_rejection_reporting_structure;
