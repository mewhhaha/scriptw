"""Restore ordinary persistent Cargo directories after the frozen qualification."""
import hashlib,json,os,pathlib,shutil,time,subprocess
root=pathlib.Path.cwd();base=pathlib.Path(__file__).resolve().parent
qualification=json.loads((base/'native-verification-current.json').read_text())
assert any(row['label']=='native-build' and row['exit_code']==0 for row in qualification['producer_commands'])
assert not qualification['complete'], 'Restore after completed native build, before resuming interrupted runtime scopes'
assert subprocess.check_output(['git','diff','--binary','HEAD','--','crates','docs/rust-rewrite/contracts'])==(base/'source/tracked.patch').read_bytes()
rows=[];inode_copies={}
def digest(p):
 with p.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def pin(p):return dict(bytes=p.stat().st_size,sha256=digest(p))
def save():
 (base/'output-restoration.json').write_text(json.dumps(dict(complete=False,rows=rows),indent=2)+'\n')
for name in ['deps','examples']:
 canonical=root/'target/release'/name
 assert canonical.is_symlink(),str(canonical)
 shadow=canonical.resolve(strict=True);assert shadow.is_relative_to('/tmp/scriptw-cargo-output-4b6dt124')
 fresh=canonical.with_name(name+'-persistent-row-preflight');fresh.mkdir()
 records=[]
 for path in sorted(shadow.iterdir()):
  source=path.resolve(strict=True);assert source.is_file(),str(source)
  target=fresh/path.name
  if source.is_relative_to('/tmp'):
   key=(source.stat().st_dev,source.stat().st_ino)
   before=pin(source)
   if key in inode_copies:os.link(inode_copies[key],target)
   else:shutil.copy2(source,target);inode_copies[key]=target
   assert pin(target)==before
   records.append(dict(name=path.name,kind='materialized',original=str(source),**before))
  else:
   target.symlink_to(source)
   # Source paths remain persistent and unchanged; original build directories
   # stay intact. No need to hash the unchanged dependency graph a third time.
   assert target.resolve(strict=True)==source
   records.append(dict(name=path.name,kind='persistent-link',target=str(source),bytes=source.stat().st_size))
 row=dict(canonical=str(canonical),temporary_source=str(shadow),files=records)
 rows.append(row);save()
 retired=canonical.with_name(name+'-tmpfs-link-row-preflight');canonical.rename(retired);fresh.rename(canonical)
 assert canonical.is_dir() and not canonical.is_symlink()
 for key,value in list(inode_copies.items()):
  if value.is_relative_to(fresh):inode_copies[key]=canonical/value.relative_to(fresh)
 for record in records:
  path=canonical/record['name'];assert not path.resolve(strict=True).is_relative_to('/tmp')
  if record['kind']=='materialized':assert pin(path)=={key:record[key] for key in ['bytes','sha256']}
 retired.unlink()
 print('RESTORED',canonical,flush=True)
for canonical in sorted((root/'target/release/build').glob('scriptw-runtime-image-*/out')):
 if not canonical.is_symlink():continue
 shadow=canonical.resolve(strict=True);assert shadow.parent==pathlib.Path('/tmp') and shadow.name.startswith('scriptw-')
 fresh=canonical.with_name('out-persistent-row-preflight');shutil.copytree(shadow,fresh,copy_function=shutil.copy2)
 before={p.relative_to(shadow).as_posix():pin(p) for p in shadow.rglob('*') if p.is_file()}
 after={p.relative_to(fresh).as_posix():pin(p) for p in fresh.rglob('*') if p.is_file()}
 assert before==after and before,'Runtime output must be complete and nonempty'
 rows.append(dict(canonical=str(canonical),temporary_source=str(shadow),files=before));save()
 retired=canonical.with_name('out-tmpfs-link-row-preflight');canonical.rename(retired);fresh.rename(canonical);retired.unlink()
 assert not canonical.is_symlink();print('RESTORED',canonical,flush=True)
# Frozen hosts and freshly qualified executables retain exactly their bytes.
for receipt in ['situations-producer.json','rsc-producer.json','aot-producer.json']:
 path=base/receipt
 if not path.is_file():continue
 r=json.loads(path.read_text());exe=pathlib.Path(r['artifact']['executable']);assert digest(exe)==r['sha256'],receipt
for n in ['deps','examples']:
 p=root/'target/release'/n;assert p.is_dir() and not p.is_symlink()
 assert all(not f.resolve(strict=True).is_relative_to('/tmp') for f in p.iterdir())
for p in (root/'target/release/build').glob('scriptw-runtime-image-*/out'):assert not p.is_symlink(),str(p)
(base/'output-restoration.json').write_text(json.dumps(dict(complete=True,rows=rows,limits='Copied temporary regular files with equal streaming SHA-256 and metadata; unchanged dependency links resolve to original persistent files. All canonical Cargo directories and runtime OUT_DIRs are real directories. Temporary copies retained until independent review.'),indent=2)+'\n')
print('ALL CARGO OUTPUT DIRECTORIES PERSISTENT',flush=True)
