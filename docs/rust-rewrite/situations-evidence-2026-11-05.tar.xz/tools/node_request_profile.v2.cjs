'use strict';
// Diagnostic copy of react-driver.cjs retainedModule: same context/wrapper.
// The source bundle and golden support are supplied by the frozen report.
const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const {webcrypto, createHash} = require('node:crypto');
const {MessageChannel} = require('node:worker_threads');
const hash = value => createHash('sha256').update(value).digest('hex');
const WRAPPER = '\nexport const run = globalThis.applicationRun;\nexport function encode(value) { return JSON.stringify(value); }\n';
function exchange(fd, nonce, phase, mode, index) {
  const suffix = `${nonce} ${phase} ${mode} ${index}\n`;
  const sent = Buffer.from('SWRSC1 '+suffix);
  assert.equal(fs.writeSync(fd, sent), sent.length);
  let reply = '';
  const byte = Buffer.alloc(1);
  while (!reply.endsWith('\n')) {
    assert.equal(fs.readSync(fd, byte), 1);
    reply += byte.toString('ascii');
    assert(reply.length <= 256);
  }
  assert.equal(reply, 'SWACK1 '+suffix);
}
(async () => {
  const [sourcePath, supportPath, outputPath, sampleText, warmupText] = process.argv.slice(2);
  const samples = Number(sampleText), warmups = Number(warmupText);
  assert(Number.isInteger(samples) && samples >= 1 && samples <= 200);
  assert(Number.isInteger(warmups) && warmups >= 0 && warmups <= 20);
  const fd = Number(process.env.SCRIPTW_RSC_PROFILE_FD);
  const nonce = process.env.SCRIPTW_RSC_PROFILE_NONCE;
  const mode = process.env.SCRIPTW_RSC_PROFILE_MODE;
  const emptyWindow = process.env.SCRIPTW_RSC_PROFILE_EMPTY_WINDOW === '1';
  assert(Number.isInteger(fd) && fd >= 3 && fs.fstatSync(fd).isSocket());
  assert(/^[0-9a-f]{32}$/.test(nonce));
  assert(['sync','async'].includes(mode));
  const source = fs.readFileSync(sourcePath, 'utf8');
  const supportBytes = fs.readFileSync(supportPath);
  const support = JSON.parse(supportBytes);
  assert.equal(support.versions.react, '19.3.1');
  assert.equal(support.versions['react-server-dom-webpack'], '19.3.1');
  const realm = vm.createContext({console, TextEncoder, TextDecoder, ReadableStream, TransformStream,
    Request, Response, Headers, URL, AbortController, AbortSignal, Blob, FormData,
    MessageChannel, queueMicrotask, setTimeout, clearTimeout,
    performance, crypto:webcrypto, print:() => {}});
  const module = new vm.SourceTextModule(source+WRAPPER, {context:realm, identifier:'rsc.js'});
  await module.link(() => {throw new Error('RSC bundle unexpectedly imports a dependency');});
  await module.evaluate();
  const {run, encode} = module.namespace;
  assert.equal(typeof run, 'function');
  assert.equal(typeof encode, 'function');
  const name = 'rsc-'+mode;
  const expected = support.expected[name];
  assert.equal(typeof expected, 'string');
  const observations = [];
  for (let index=0; index<samples+warmups; index++) {
    let result;
    if (index < warmups) {
      result = await run(mode);
    } else {
      exchange(fd, nonce, 'ready', mode, index);
      if (emptyWindow) result = null;
      else result = await run(mode);
      exchange(fd, nonce, 'done', mode, index);
    }
    const stdout = encode(result)+'\n';
    let golden = expected;
    let kind = 'flight';
    if (emptyWindow && index >= warmups) {
      golden = 'null\n';
      kind = 'empty-window-calibration';
    }
    assert.equal(stdout, golden, 'retained-module diagnostic output changed: '+name);
    observations.push({index, warmup:index<warmups, kind, exact_golden_output_checked:true,
      output_sha256:hash(stdout), output_bytes:Buffer.byteLength(stdout)});
  }
  let schema = 'scriptw-rsc-node-pmu-v1';
  let caseName = name;
  if (emptyWindow) {
    schema = 'scriptw-rsc-node-empty-window-calibration-v1';
    caseName += '-empty-window-calibration';
  }
  fs.writeFileSync(outputPath, JSON.stringify({schema,
    excluded_from_scored_cohorts:true, node:process.versions, main_thread_pid:process.pid,
    inputs:{source:sourcePath,source_sha256:hash(source),wrapper:WRAPPER,
      adapted_source_sha256:hash(source+WRAPPER),support:supportPath,support_sha256:hash(supportBytes)},
    profiling:{nonce,windows:samples,excluded_from_scored_cohorts:true,
      empty_window_calibration:emptyWindow},
    cases:[{case:caseName,samples,warmups,exact_node_output_checked:!emptyWindow,
      genuine_flight_warmups_checked:true,literal_empty_result_checked:emptyWindow,observations}]},null,2)+'\n');
})().then(() => process.exit(0)).catch(error => {console.error(error.stack);process.exit(1);});
