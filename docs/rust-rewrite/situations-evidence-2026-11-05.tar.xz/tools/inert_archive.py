#!/usr/bin/env python3
"""Create an inert UTF-8 archive of final React Flight evidence."""
import argparse
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import tarfile

ROOT = Path(__file__).resolve().parents[2]
BASE = ROOT / 'target/react-performance-20261103'
FIXTURES = ROOT / 'target/application-benchmarks-20261102/generated-v2'
DRIVER = ROOT / 'crates/scriptw-cli/tests/fixtures/edge_rendering/react-driver.cjs'
SOURCE_DIR = DRIVER.parent
ARCHIVE_LIMIT = 5 * 1024**2
FILE_LIMIT = 64 * 1024**2
EXPANDED_LIMIT = 512 * 1024**2
EXCLUDED_NAMES = {'node_modules', 'cache', 'tmp', '__pycache__'}
EXCLUDED_SUFFIXES = {'.wasm', '.so', '.a', '.rlib', '.rmeta', '.o', '.dylib', '.dll', '.exe'}


def need(ok, reason):
    if not ok:
        raise RuntimeError(reason)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def json_bytes(value):
    return (json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + '\n').encode()


class Archive:
    def __init__(self):
        self.files = {}

    def add_bytes(self, member, value):
        path = PurePosixPath(member)
        need(path.parts and not path.is_absolute() and '..' not in path.parts
             and str(path) == member and '\\' not in member and ':' not in member,
             'unsafe archive member: ' + member)
        need(member not in ('INDEX.json', 'INDEX.json.sha256') and member not in self.files,
             'duplicate or reserved archive member: ' + member)
        need(len(value) <= FILE_LIMIT, 'archive file exceeds 64 MiB: ' + member)
        value.decode('utf-8', errors='strict')
        need(b'\0' not in value, 'binary/NUL file rejected: ' + member)
        self.files[member] = value

    def add_file(self, member, source):
        source = Path(source)
        info = source.lstat()
        need(source.is_file() and not source.is_symlink(), 'non-regular source rejected: ' + str(source))
        need(info.st_size <= FILE_LIMIT, 'archive file exceeds 64 MiB: ' + str(source))
        self.add_bytes(member, source.read_bytes())

    def add_if_file(self, member, source):
        source = Path(source)
        if source.is_file() and not source.is_symlink():
            self.add_file(member, source)

    def add_tree(self, source, member_prefix):
        source = Path(source)
        need(source.is_dir() and not source.is_symlink(), 'evidence directory missing: ' + str(source))
        for path in sorted(source.rglob('*')):
            if path.is_dir():
                need(not path.is_symlink(), 'symlink directory in evidence: ' + str(path))
                continue
            need(path.is_file() and not path.is_symlink(), 'non-regular evidence file: ' + str(path))
            relative = path.relative_to(source)
            if any(part in EXCLUDED_NAMES for part in relative.parts):
                continue
            if path.suffix.lower() in EXCLUDED_SUFFIXES or path.name == 'perf.data':
                continue
            if path.read_bytes()[:4] in (b'\x7fELF', b'\x00asm'):
                continue
            self.add_file(member_prefix.rstrip('/') + '/' + relative.as_posix(), path)

    def add_profile(self, folder, member_prefix):
        folder = Path(folder).resolve(strict=True)
        need(folder.is_dir() and not folder.is_symlink(), 'profile directory missing')
        for name in ('plan.json', 'receipt.json', 'observations.json', 'host.stdout', 'host.stderr',
                     'perf.stdout', 'perf.stderr', 'samples.txt', 'samples.stderr',
                     'maps-before.txt', 'maps-after.txt', 'perf-before.map', 'perf.map'):
            self.add_if_file(member_prefix + '/' + name, folder / name)
        symbols_path = folder / 'symbols.json'
        if symbols_path.is_file():
            symbols = json.loads(symbols_path.read_text())
            need(symbols.get('unscored') is True and isinstance(symbols.get('top'), list),
                 'invalid unscored profile summary')
            compact = {key: symbols[key] for key in ('unscored', 'samples', 'period_sum', 'limits')
                       if key in symbols}
            compact['top'] = symbols['top'][:40]
            compact['omitted_owner_rows'] = max(0, len(symbols['top']) - len(compact['top']))
            self.add_bytes(member_prefix + '/top-symbols.json', json_bytes(compact))

    def add_campaign(self, folder):
        folder = Path(folder).resolve(strict=True)
        campaign_path = folder / 'campaign.json'
        campaign = json.loads(campaign_path.read_text())
        need(campaign.get('schema') == 'scriptw-rsc-fast-campaign-v1'
             and campaign.get('status') == 'complete'
             and len(campaign.get('processes', [])) == 24,
             'require 24 completed Fast comparison processes')
        self.add_file('campaign/campaign.json', campaign_path)
        for index, row in enumerate(campaign['processes']):
            need(row.get('status') == 'complete', f'incomplete process row {index}')
            directory = PurePosixPath(row['stdout']).parent
            members = (row['report'], row['stdout'], row['stderr'],
                       (directory / 'resources.json').as_posix())
            for relative in members:
                source = folder / relative
                self.add_file('campaign/' + relative, source)
        aggregate_path = folder / 'aggregate.json'
        aggregate = json.loads(aggregate_path.read_text())
        need(aggregate.get('schema') == 'scriptw-rsc-fast-comparison-v1',
             'missing validated Fast comparison aggregate')
        self.add_file('reports/fast-comparison-aggregate.json', aggregate_path)
        for name in ('measure_fast_comparison.py', 'react-driver.cjs', 'baseline-identity-report.json'):
            self.add_if_file('campaign/' + name, folder / name)
        return campaign, aggregate

    def add_prior_source_reference(self, report_path, baseline_identity):
        report_path = Path(report_path).resolve(strict=True)
        report = json.loads(report_path.read_text())
        source = report.get('source_identity', {}).get('candidate_measured_source', {})
        evidence = report.get('evidence_archive', {})
        prior_candidate = report.get('engines', {}).get('candidate', {}).get('identity', {})
        identity_fields = ('executable_sha256', 'source_fingerprint', 'program_wasm_sha256',
                           'configuration', 'inputs', 'source_commit')
        need(all(prior_candidate.get(name) == baseline_identity.get(name) for name in identity_fields),
             'new Fast baseline does not match prior public candidate identity')
        archive_name = evidence.get('file')
        need(isinstance(archive_name, str) and Path(archive_name).name == archive_name,
             'initial report does not identify a local prior evidence archive')
        archive_path = report_path.parent / archive_name
        need(archive_path.is_file() and sha(archive_path.read_bytes()) == evidence.get('sha256')
             and archive_path.stat().st_size == evidence.get('bytes'),
             'prior evidence archive does not match the initial report hash/size')
        prefix = source.get('archive_prefix')
        manifest_sha = source.get('manifest_sha256')
        need(isinstance(prefix, str) and isinstance(manifest_sha, str),
             'initial report lacks its measured source archive identity')
        with tarfile.open(archive_path, 'r:xz') as old_archive:
            index_bytes = old_archive.extractfile('INDEX.json').read()
            sidecar = old_archive.extractfile('INDEX.json.sha256').read().decode().strip()
            need(sidecar == sha(index_bytes) + '  INDEX.json', 'prior archive index sidecar differs')
            index = json.loads(index_bytes)
            members = {row['path']: row['sha256'] for row in index['members']}
        expected_manifest = members.get(prefix + 'manifest.json')
        need(expected_manifest == manifest_sha,
             'prior archive source manifest differs from the initial report identity')
        self.add_bytes('reports/prior-source-evidence-reference.json', json_bytes({
            'archive_path': str(archive_path.relative_to(ROOT)),
            'archive_sha256': evidence['sha256'], 'archive_bytes': evidence['bytes'],
            'initial_report_sha256': sha(report_path.read_bytes()),
            'source_manifest_path': prefix + 'manifest.json',
            'source_manifest_sha256': expected_manifest,
            'source_base_commit': source.get('base_commit'),
            'source_role': source.get('role'),
            'baseline_executable_sha256': baseline_identity['executable_sha256'],
            'baseline_identity_matches_prior_public_candidate': True,
            'note': 'The new Fast baseline identity matches the prior public candidate; its measured source reconstruction is retained inside this verified prior UTF-8 evidence archive and referenced by archive and manifest hashes.'
        }))

    def add_snapshot(self, folder, prefix):
        folder = Path(folder).resolve(strict=True)
        manifest_path = folder / 'manifest.json'
        manifest_bytes = manifest_path.read_bytes()
        manifest = json.loads(manifest_bytes)
        listed = manifest.get('files')
        need(isinstance(listed, dict) and listed, 'source snapshot manifest is incomplete')
        actual = {}
        for path in sorted(folder.rglob('*')):
            if path.is_dir():
                need(not path.is_symlink(), 'symlink in source snapshot')
                continue
            need(path.is_file() and not path.is_symlink(), 'non-regular source snapshot file')
            relative = path.relative_to(folder).as_posix()
            data = path.read_bytes()
            if relative != 'manifest.json':
                actual[relative] = data
                need(sha(data) == listed.get(relative), 'source manifest hash mismatch: ' + relative)
            self.add_file(prefix + '/' + relative, path)
        need(set(actual) == set(listed), 'source snapshot files differ from manifest')
        return dict(archive_prefix=prefix + '/', manifest_sha256=sha(manifest_bytes),
                    base_commit=manifest.get('base_commit'), role=manifest.get('role'),
                    files=len(listed))

    def add_control_outputs(self, base):
        report_path = base / 'cli-controls.json'
        report = json.loads(report_path.read_text())
        need(isinstance(report, list) and len(report) == 9
             and all(row.get('guest_output_and_backend_outcome_match') is True for row in report),
             'require nine exact CLI control passes')
        self.add_file('controls/cli-controls.json', report_path)
        folder = base / 'cli-controls'
        need(folder.is_dir(), 'CLI control raw output directory missing')
        cases = [path for path in folder.iterdir() if path.is_dir()]
        need(len(cases) == 9, 'CLI control raw output inventory differs')
        for case in cases:
            for name in ('stdout', 'stderr'):
                self.add_file('controls/raw/' + case.name + '/' + name, case / name)

    def add_standard_evidence(self, base, archive_prefix):
        # Receipts and compact source/test summaries; bulky Cargo JSON streams
        # are represented by the artifact metadata and hashes in build-freeze.
        names = (
            'build-freeze.json', 'cli-build.json', 'rsc-build.json',
            'cli-identity.json', 'cli-producer.json', 'rsc-producer.json',
            'diagnostic-fast-receipt.json', 'diagnostic-speed-0-receipt.json',
            'candidate-fast-0.json', 'candidate-speed-0.json',
            'source-ready.json', 'aot-verification.json', 'engine-focus.json', 'engine-broad.json',
            'cell-encoded.stdout', 'cell-encoded.stderr', 'aot_builtins.stdout', 'aot_builtins.stderr',
            'aot_async.stdout', 'aot_async.stderr', 'aot_realm_modules.stdout', 'aot_realm_modules.stderr',
            'emission.stdout', 'emission.stderr', 'source-guards.stdout', 'source-guards.stderr',
            'ir-tests.stdout', 'ir-tests.stderr', 'module-cells.stdout', 'module-cells.stderr',
            'codecs.stdout', 'codecs.stderr', 'events.stdout', 'events.stderr',
            'streams.stdout', 'streams.stderr', 'tasks.stdout', 'tasks.stderr',
            'candidate-controls.json', 'candidate-cli-feature-comparison.json',
            'candidate-diagnostic.json', 'format-receipt.json', 'no-interpreter.stdout',
            'no-interpreter.stderr', 'intl-source-identities.stdout',
            'intl-source-identities.stderr',
        )
        for name in names:
            self.add_if_file(archive_prefix + '/' + name, base / name)
        for folder_name in ('frozen',):
            frozen = base / folder_name
            if frozen.is_dir():
                for path in sorted(frozen.iterdir()):
                    if path.is_file() and path.suffix == '.json':
                        self.add_file(archive_prefix + '/' + folder_name.replace('/', '-') + '/' + path.name, path)

        # Retain initial inline-cell trial and final candidate diagnostics when present.
        for candidate_base, prefix in ((base, 'first-trial'), (base / 'promoted', 'final')):
            for name in ('candidate-fast-0.json', 'candidate-speed-0.json',
                         'diagnostic-fast-receipt.json', 'diagnostic-speed-0-receipt.json'):
                self.add_if_file(archive_prefix + '/' + prefix + '/' + name, candidate_base / name)
            for dirname in ('diagnostic-fast', 'diagnostic-speed-0'):
                folder = candidate_base / dirname
                if folder.is_dir():
                    for name in ('stdout', 'stderr'):
                        self.add_if_file(archive_prefix + '/' + prefix + '/' + dirname + '/' + name,
                                         folder / name)

        size = base / 'size'
        if size.is_dir():
            for name in ('measured-input.json', 'capture.json', 'functions.txt', 'attribution.json',
                         'functions.json', 'function-deltas.json', 'receipt.json',
                         'analysis.stdout', 'analysis.stderr'):
                self.add_if_file(archive_prefix + '/size/' + name, size / name)

        historical = ROOT / 'target/rsc-platform-work'
        historical_names = (
            'candidate-source-guards.stdout', 'candidate-source-guards.stderr',
            'candidate-focused-native.json', 'broad-native.json', 'candidate-emission.stdout',
            'candidate-emission.stderr', 'emission-release.stdout', 'emission-release.stderr',
            'capture-ir-tests.stdout', 'capture-ir-tests.stderr', 'broad-aot_builtins.stdout',
            'broad-aot_builtins.stderr', 'broad-aot_async.stdout', 'broad-aot_async.stderr',
            'broad-aot_realm_modules.stdout', 'broad-aot_realm_modules.stderr',
        )
        for name in historical_names:
            self.add_if_file(archive_prefix + '/historical-checkpoints/' + name, historical / name)

    def add_sources(self, base):
        for name in ('rsc.js', 'support.json', 'manifest.json'):
            self.add_file('fixtures/' + name, FIXTURES / name)
        for name in ('react-rsc.entry.js', 'react-driver.cjs'):
            self.add_file('fixtures/' + name, SOURCE_DIR / name)
        self.add_file('sources/rsc_baseline.rs', ROOT / 'crates/scriptw-cli/examples/rsc_baseline.rs')
        self.add_file('sources/react-driver.cjs', DRIVER)
        self.add_file('sources/archive_final.py', Path(__file__).resolve())
        self.add_if_file('sources/measure_fast_comparison.py', base / 'measure_fast_comparison.py')
        self.add_if_file('sources/build_freeze.py', base / 'build_freeze.py')
        self.add_if_file('sources/check_candidate_controls.py', base / 'check_candidate_controls.py')
        self.add_if_file('sources/make_public_report.py', base / 'make_public_report.py')
        for name in ('build_freeze.py', 'check_candidate_controls.py', 'verify_aot.py', 'verify_engine.py'):
            self.add_if_file('sources/promoted/' + name, base / 'promoted' / name)
        self.add_if_file('sources/size/analyze.py', base / 'size/analyze.py')
        self.add_if_file('sources/promoted/size/analyze.py', base / 'promoted/size/analyze.py')
        for name in ('benchmark_metrics.py', 'limited_verification.py', 'application_benchmarks.py'):
            self.add_file('sources/scripts/' + name, ROOT / 'scripts' / name)
        packages = ROOT / 'target/application-benchmarks-20261102/tools/node_modules/.pnpm'
        license_paths = {
            'react': packages / 'react@19.3.1/node_modules/react/LICENSE',
            'react-dom': packages / 'react-dom@19.3.1_react@19.3.1/node_modules/react-dom/LICENSE',
            'react-server-dom-webpack': next(packages.glob(
                'react-server-dom-webpack@19.3.1*/node_modules/react-server-dom-webpack/LICENSE')),
        }
        for name, path in license_paths.items():
            self.add_file('licenses/' + name + '-LICENSE', path)

    def add_evidence_arg(self, path):
        path = Path(path).resolve(strict=True)
        if path.is_file():
            member = 'additional-evidence/' + path.relative_to(ROOT).as_posix()
            self.add_file(member, path)
        elif path.is_dir():
            self.add_tree(path, 'additional-evidence/' + path.relative_to(ROOT).as_posix())
        else:
            raise RuntimeError('unsupported evidence argument: ' + str(path))

    def write(self, destination):
        expanded = sum(map(len, self.files.values()))
        need(len(self.files) <= 20_000 and expanded <= EXPANDED_LIMIT,
             'archive inventory/expanded size limit exceeded')
        index = {'schema': 'scriptw-inert-evidence-index-v1',
                 'members': [{'path': name, 'bytes': len(value), 'sha256': sha(value)}
                             for name, value in sorted(self.files.items())]}
        index_bytes = json_bytes(index)
        all_files = dict(self.files)
        all_files['INDEX.json'] = index_bytes
        all_files['INDEX.json.sha256'] = (sha(index_bytes) + '  INDEX.json\n').encode()
        temporary = destination.with_suffix(destination.suffix + '.tmp')
        need(not destination.exists() and not temporary.exists(), 'refusing to overwrite archive')
        with tarfile.open(temporary, 'w:xz', preset=6) as archive:
            for name, value in sorted(all_files.items()):
                info = tarfile.TarInfo(name)
                info.size = len(value)
                info.mtime = 0
                info.uid = info.gid = 0
                info.uname = info.gname = ''
                info.mode = 0o644
                archive.addfile(info, io.BytesIO(value))
        os.replace(temporary, destination)
        return dict(file=str(destination.relative_to(ROOT)), sha256=sha(destination.read_bytes()),
                    bytes=destination.stat().st_size, regular_utf8_members=len(self.files) + 2,
                    expanded_utf8_bytes=expanded + len(index_bytes) + len(all_files['INDEX.json.sha256']))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--campaign', type=Path, required=True,
                        help='completed 24-process balanced Fast campaign directory')
    parser.add_argument('--report', type=Path,
                        help='final machine-readable report to preserve, without archive metadata')
    parser.add_argument('--initial-report', type=Path,
                        default=ROOT / 'docs/rust-rewrite/rsc-initial-20261103.json')
    parser.add_argument('--first-trial-source', type=Path, default=BASE / 'candidate-measured-source')
    parser.add_argument('--final-source', type=Path, default=BASE / 'promoted/candidate-measured-source')
    parser.add_argument('--first-trial-evidence', type=Path, default=BASE)
    parser.add_argument('--final-evidence', type=Path, default=BASE / 'promoted')
    parser.add_argument('--controls', type=Path, default=BASE / 'promoted')
    parser.add_argument('--evidence', type=Path, action='append', default=[],
                        help='additional file/directory of small UTF-8 evidence; may be repeated')
    parser.add_argument('--profile', type=Path, action='append', default=[],
                        help='profile evidence directory; may be repeated, raw perf.data is excluded')
    parser.add_argument('--output', type=Path,
                        default=ROOT / 'docs/rust-rewrite/rsc-final-evidence-2026-11-03.tar.xz')
    args = parser.parse_args()

    archive = Archive()
    campaign, aggregate = archive.add_campaign(args.campaign)
    campaign_path = args.campaign.resolve() / 'campaign.json'
    archive.add_bytes('reports/fast-comparison-campaign-input.json', json_bytes({
        'campaign_sha256': sha(campaign_path.read_bytes()),
        'aggregate_sha256': sha((args.campaign.resolve() / 'aggregate.json').read_bytes()),
        'campaign_schema': campaign['schema'], 'aggregate_schema': aggregate['schema'],
    }))

    if args.report is not None:
        report_path = args.report.resolve(strict=True)
        archive.add_file('reports/final-report.json', report_path)
    initial_path = args.initial_report
    if initial_path.is_file():
        archive.add_file('reports/initial-public-report.json', initial_path)
        archive.add_bytes('reports/initial-public-report-sha256.txt',
                          (sha(initial_path.read_bytes()) + '  initial-public-report.json\n').encode())
        archive.add_prior_source_reference(initial_path, aggregate['engines']['baseline']['identity'])
    else:
        need(args.initial_report == ROOT / 'docs/rust-rewrite/rsc-initial-20261103.json',
             'explicit initial report path does not exist')

    snapshots = {
        'source/first-trial-measured/': archive.add_snapshot(args.first_trial_source,
                                                              'source/first-trial-measured'),
        'source/final-measured/': archive.add_snapshot(args.final_source, 'source/final-measured'),
    }
    archive.add_bytes('source/source-snapshots.json', json_bytes(snapshots))
    archive.add_control_outputs(args.controls)
    archive.add_standard_evidence(args.first_trial_evidence, 'verification/first-trial')
    archive.add_standard_evidence(args.final_evidence, 'verification/final')
    archive.add_sources(BASE)
    for path in args.evidence:
        archive.add_evidence_arg(path)
    for index, path in enumerate(args.profile):
        archive.add_profile(path, f'profiles/profile-{index}')
    archive.add_bytes('README.txt', (
        'Final React Server Components performance evidence. Includes the completed matched Fast '
        'campaign, exact output/resource receipts, the prior public report, and a hash-verified reference '
        'to its original baseline source reconstruction. The first trial and final promoted source '
        'reconstructions, selected verification summaries, nine CLI controls, and first/final '
        'native-policy diagnostics when present. All archived members are inert UTF-8 text. '
        'Executables, Wasm payloads, caches, node_modules, and perf.data are excluded. '
        'Speed/Backtracking observations are unscored diagnostics and are separate from the Fast cohort.\n'
    ).encode())
    destination = args.output if args.output.is_absolute() else ROOT / args.output
    metadata = archive.write(destination)
    metadata['over_5mb'] = metadata['bytes'] > ARCHIVE_LIMIT
    print(json.dumps(metadata, sort_keys=True))


if __name__ == '__main__':
    main()
