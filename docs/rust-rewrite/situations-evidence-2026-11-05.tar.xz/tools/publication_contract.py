"""Identity gates shared by the ABI51 publication scripts."""
import copy
import hashlib
import json
import math
from pathlib import Path
import statistics

ROOT = Path.cwd()
BASE = Path(__file__).resolve().parent
PRIOR = 'f267e94cf25b6de0dcf5a4d14e1b2d7d09616664'
SOURCE = '91d2ea976a9a89308fb69221325859af4f3d5d3ecd2421a46d961cac585871c5'
PROGRAM = '19d2643a0889ee0de5ed99c1677c0d2bd2df2bfe77356a4e54f4a11793bb1541'
RUNTIME = '2a60a584a47f10a0679b4772a1cf4bd9545baf69ad6ba19d566cfbcfca95e66b'
ALLOCATION_BASE = ROOT / 'target/performance-v8-climb-20261104/allocation-packed-readonly-staged'
ALLOCATION_REPORT = ALLOCATION_BASE / 'public-current.json'
ALLOCATION_EVIDENCE = ALLOCATION_BASE / 'publication-evidence'
ENGINE_TARGETS = ('aot_language', 'aot_builtins', 'aot_async', 'aot_realm_modules')
STRUCTURAL_TARGETS = ('structure_language', 'modules_realms', 'runtime_link', 'structure_builtins', 'structure_async', 'intl_temporal')


def need(condition, reason):
    if not condition:
        raise RuntimeError(reason)


def read(path):
    return json.loads(Path(path).read_text())


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def candidate_identity():
    need(digest(BASE / 'source/manifest.json') == SOURCE, 'ABI51 frozen source manifest differs')
    identity = read(BASE / 'fast-comparison-campaign/aggregate.json')['engines']['candidate']['identity']
    need(identity['program_wasm_sha256'] == PROGRAM and identity['runtime']['wasm_sha256'] == RUNTIME,
         'ABI51 current program/runtime identity differs')
    return identity


def _reduction(row, processes):
    medians = row['process_medians']
    values = [row['median_of_process_medians'], row['minimum'], row['maximum'], *medians]
    need(len(medians) == processes and all(type(value) in (int, float)
         and math.isfinite(value) and value >= 0 for value in values), 'allocation reduction contains invalid values')
    need(statistics.median(medians) == row['median_of_process_medians']
         and row['minimum'] <= min(medians) <= max(medians) <= row['maximum'], 'allocation reduction is inconsistent')


def validate_allocation(report, identity):
    """Validate producer data in memory; source schema controls can call this."""
    need(report['schema'] == 'scriptw-allocation-packed-readonly-current-v1'
         and report.get('complete') is True and report['exact_flight_checks'] == 80
         and report['valid_on_request_epochs'] == 40, 'fresh allocation request census is incomplete')
    need(report['scored_source_manifest_sha256'] == SOURCE, 'allocation census names a different scored source')
    scored, observed = report['scored_baseline'], report['diagnostic_identity']
    need(scored['program_sha256'] == identity['program_wasm_sha256'] == PROGRAM
         and scored['runtime_sha256'] == identity['runtime']['wasm_sha256'] == RUNTIME,
         'old or different P/R allocation counts cannot be published as current')
    need(observed['program_wasm_sha256'] == PROGRAM and observed['runtime'] == identity['runtime'],
         'allocation diagnostic did not admit the actual current P/R')
    need(scored['runtime_bytes'] == identity['runtime']['wasm_bytes'] and scored['program_bytes'] > 0,
         'allocation admitted byte sizes differ')
    for field in ('configuration', 'inputs'):
        need(observed[field] == identity[field], 'allocation diagnostic input/configuration differs')
    expanded = report['expanded_physical_types']
    need(expanded['program_wasm_sha256'] == PROGRAM and expanded['runtime'] == identity['runtime'],
         'expanded physical labels/counts belong to a different runtime')
    labels = expanded['labels']
    expected_labels = {'StoredValue', 'BindingCell', 'StringValue', 'CodeUnitArray', 'ValueArray',
        'PropertyKeyTable', 'ForInEnumerationRecord', 'OrdinaryObject', 'OrdinaryPropertyStorage',
        'PropertyTable', 'OrdinaryPropertyIndex', 'PropertyEntry', 'PropertyDescriptor'}
    need(len(labels) == 26 and {row[2] for row in labels} == expected_labels
         and all(row[0] in ('P', 'R') and int(row[1]) >= 0 for row in labels), 'fresh13 physical-label evidence is incomplete')
    need(all({row[2] for row in labels if row[0] == module} == expected_labels for module in ('P', 'R')),
         'P/R physical-label witnesses differ')
    authenticated = {}
    for module, ordinal, label in labels:
        authenticated.setdefault((module, int(ordinal)), set()).add(label)
    boundaries = {'request_allocations': 'request', 'with_validation_allocations': 'with_validation_cumulative',
                  'validation_increment_allocations': 'validation_increment'}
    for case in ('rsc-sync', 'rsc-async'):
        all_boundaries = expanded['boundary_cases'][case]
        need(expanded['cases'][case] == all_boundaries['measured']['request'], 'measured physical request view differs')
        for partition, physical_partition, count in (('warmups', 'warmup', 6), ('measured', 'measured', 14)):
            for name, physical_boundary in boundaries.items():
                view = report['cases'][case][name][partition]
                physical = all_boundaries[physical_partition][physical_boundary]
                need(view['observations'] == physical['observations'] == count
                     and view['processes'] == physical['processes'] == 2, 'allocation counted process/request boundary coverage differs')
                need(view['collections'] == physical['collections'], 'collection boundary reduction differs')
                _reduction(view['collections'], 2)
                need(view['totals']['All GC allocations'] == {'objects': physical['objects'], 'bytes': physical['bytes']}, 'physical total view differs')
                for label in ('All GC allocations', 'StoredValue', 'BindingCell'):
                    for metric in ('objects', 'bytes'):
                        _reduction(view['totals'][label][metric], 2)
                for row in physical['physical_types']:
                    _reduction(row['objects'], 2)
                    _reduction(row['bytes'], 2)
                    names = set().union(*(authenticated.get((module, int(ordinal)), set()) for module, ordinal in row['wasm_aliases']))
                    need(set(row['semantic_labels']) == names, 'physical type label is not authenticated by its P/R aliases')
                for label in ('StoredValue', 'BindingCell'):
                    rows = [row for row in physical['physical_types'] if label in row['semantic_labels']]
                    need(len(rows) == 1 and view['totals'][label] == {metric: rows[0][metric] for metric in ('objects', 'bytes')}, 'physical label total view differs')
                payload = report['cases'][case]['stored_value_payload'][partition]
                if physical_boundary in payload:
                    observed_payload = payload[physical_boundary]
                    need(observed_payload['observations'] == count and observed_payload['processes'] == 2, 'payload request/validation partition coverage differs')
                    _reduction(observed_payload['stored_values'], 2)
                    need(observed_payload['stored_values'] == view['totals']['StoredValue']['objects'], 'payload/physical StoredValue reduction differs')
                    for value in (*observed_payload['tags'].values(), *observed_payload['number_categories'].values()):
                        _reduction(value, 2)
                else:
                    need(physical_boundary == 'validation_increment', 'required payload boundary missing')
    need(report['stored_value_payload_schema']['tag_schema'] and report['stored_value_payload_schema']['limits'],
         'payload interpretation/source schema is missing')
    entries = report.get('source_entry_diagnostic')
    if entries is not None:
        need(entries['complete'] and entries['identity']['program_wasm_sha256'] == PROGRAM
             and entries['identity']['runtime'] == identity['runtime'], 'old entry diagnostics must stay baseline, not current')
    result = copy.deepcopy(report)
    result.pop('evidence_archive', None)
    return result


def allocation_report(path, identity):
    path = Path(path)
    need(path.is_file(), 'Fresh ABI51 allocation report is missing: ' + str(path))
    report = read(path)
    need(not report.get('source_only_schema_fixture'), 'synthetic schema fixtures cannot be published')
    return validate_allocation(report, identity)


def validate_allocation_evidence(folder, report):
    """Check the full inert evidence inventory before any canonical write."""
    folder = Path(folder).resolve(strict=True)
    index = read(folder / 'inventory.json')
    need(index['schema'] == 'scriptw-allocation-packed-readonly-evidence-v1'
         and index['inert_utf8_text_only'] is True, 'allocation evidence inventory schema differs')
    files = index['files']
    paths = {row['path'] for row in files}
    need(len(paths) == len(files), 'allocation evidence has duplicate paths')
    actual = set()
    for path in folder.rglob('*'):
        need(not path.is_symlink(), 'allocation evidence contains a symlink')
        if path.is_file():
            actual.add(path.relative_to(folder).as_posix())
    need(actual == paths | {'inventory.json'}, 'allocation evidence inventory differs from actual files')
    sources = {}
    for row in files:
        relative = Path(row['path'])
        need(not relative.is_absolute() and '..' not in relative.parts, 'unsafe allocation evidence path')
        path = folder / relative
        value = path.read_bytes()
        value.decode('utf-8', errors='strict')
        need(b'\0' not in value and hashlib.sha256(value).hexdigest() == row['sha256']
             and len(value) == row['bytes'], 'allocation evidence text/hash differs: ' + row['path'])
        need(row['source'] not in sources, 'allocation source was copied ambiguously')
        sources[row['source']] = row
    required = {'stage/current-pins.json', 'stage/preparation.json', 'stage/diagnostic-artifact-proof.json',
        'stage/commands.json', 'stage/requests/validation.json', 'stage/requests/receipts.json',
        'stage/physical-reduction/public-physical.json', 'stage/physical-reduction/summary.json',
        'stage/physical-reduction/normalized-observations.json', 'stage/physical-reduction/receipt.json',
        'stage/public-current.json', 'stage/payload-public.json', 'stage/summary.json', 'stage/labels/receipt.json',
        'stage/labels/type-labels.tsv', 'stage/labels/producer-prepared.json', 'stage/labels/verify.py',
        'producer/host-producer.json', 'producer/diagnostic-host-build.stdout', 'producer/diagnostic-host-build.stderr',
        'producer/diagnostic-host-build-receipt.json', 'producer/reference-emitter-command.json',
        'producer/reference-emitter.stdout', 'producer/reference-emitter.stderr',
        'producer/diagnostic-emission-identity.json', 'producer/diagnostic-emission.stdout', 'producer/diagnostic-emission.stderr',
        'producer/diagnostic-host-main.rs', 'producer/diagnostic-engine-embedding.rs'}
    required |= {f'requests/{index}-{mode}/{name}' for index, mode in enumerate(('off', 'on', 'on', 'off'))
                 for name in ('report.json', 'stdout', 'stderr', 'process.json')}
    need(required <= paths, 'allocation evidence omits raw requests/producers: ' + ','.join(sorted(required - paths)))
    pins = read(folder / 'stage/current-pins.json')
    need(pins['current_source_manifest']['sha256'] == SOURCE, 'allocation source pin differs')
    manifest = sources[pins['current_source_manifest']['path']]
    need(manifest['sha256'] == SOURCE, 'allocation frozen manifest copy differs')
    prepared = read(folder / 'stage/preparation.json')
    need(prepared['source_manifest_sha256'] == SOURCE
         and prepared['tracked_patch_matches_canonical_diff'] is True, 'diagnostic source preparation differs')
    for source, expected in prepared['wasmtime_patched_source_sha256'].items():
        need(sources[source]['sha256'] == expected, 'current diagnostic Wasmtime source copy differs')
    label_receipt = read(folder / 'stage/labels/receipt.json')
    label_data = (folder / 'stage/labels/type-labels.tsv').read_text().splitlines()
    need(label_data[0] == 'module\twasm_type_index\tlabel'
         and [line.split('\t') for line in label_data[1:]] == report['expanded_physical_types']['labels'] == label_receipt['labels']
         and digest(folder / 'stage/labels/type-labels.tsv') == label_receipt['outputs']['labels']['sha256']
         and digest(folder / 'stage/labels/producer-prepared.json') == label_receipt['producer_sha256'],
         'current physical label producer/witness differs')
    assembled = allocation_report(folder / 'stage/public-current.json', candidate_identity())
    need(all(report[key] == value for key, value in assembled.items()), 'allocation evidence public body differs')
    physical = read(folder / 'stage/physical-reduction/public-physical.json')
    need(physical['labels'] == report['expanded_physical_types']['labels']
         and physical['expanded_physical_types'] == report['expanded_physical_types']['boundary_cases'],
         'allocation evidence physical reduction differs')
    payload = read(folder / 'stage/payload-public.json')
    need(all(payload['cases'][case] == report['cases'][case]['stored_value_payload'] for case in ('rsc-sync', 'rsc-async'))
         and report['stored_value_payload_schema'] == {'tag_schema': payload['tag_schema'], 'limits': payload['limits']},
         'allocation evidence payload reduction differs')
    proof = read(folder / 'stage/diagnostic-artifact-proof.json')
    need(proof['admitted'] is True and proof['scored_source_manifest_sha256'] == SOURCE,
         'allocation exact-artifact admission is missing')
    for role, expected, size in (('P', PROGRAM, report['scored_baseline']['program_bytes']),
                                 ('R', RUNTIME, report['scored_baseline']['runtime_bytes'])):
        need(proof[role]['sha256'] == expected and proof[role]['bytes'] == size
             and proof[role]['comparison']['admitted'] is True, 'allocation full-byte artifact proof differs')
    receipts = read(folder / 'stage/requests/receipts.json')
    need([row['mode'] for row in receipts] == ['off', 'on', 'on', 'off'], 'allocation process order differs')
    for index, row in enumerate(receipts):
        prefix = folder / f"requests/{index}-{row['mode']}"
        observed = read(prefix / 'report.json')
        process = read(prefix / 'process.json')
        need(all(row[key] == value for key, value in process.items()), 'raw allocation process receipt differs')
        need(row['index'] == index and row['exit_code'] == 0 and row['validated_flight_outputs'] == 20
             and row['report_sha256'] == digest(prefix / 'report.json')
             and row['binary_sha256'] == proof['binary']['sha256'], 'allocation request receipt differs')
        need(observed['schema'] == 'scriptw-copying-allocation-payload-v1' and observed['status'] == 'complete' and observed['excluded_from_scored_cohorts'] is True
             and observed['allocation_census_enabled'] == (row['mode'] == 'on')
             and observed['executable_sha256'] == proof['binary']['sha256'], 'allocation raw report is incomplete')
        need(observed['payload_labels']['sha256'] == label_receipt['outputs']['labels']['sha256'], 'request used a different physical label witness')
        need(all(observed[key] == value for key, value in report['diagnostic_identity'].items()), 'allocation raw request identity differs')
        need([case['case'] for case in observed['cases']] == ['rsc-sync', 'rsc-async']
             and all(case['exact_node_output_checked'] is True and case['samples'] == 7
                     and case['warmups'] == 3 and len(case['observations']) == 10 for case in observed['cases']),
             'allocation raw exact-output request coverage differs')
    controls = 0
    for source, expected in pins['reused_control_source_inputs'].items():
        need(sources[source]['sha256'] == expected, 'prior control source copy is missing or changed')
    for rows in pins['prior_control_receipts'].values():
        for row in rows:
            need(sources[row['path']]['sha256'] == row['sha256'], 'prior control receipt copy differs')
            for state, passed, failed, ignored in row['test_summaries']:
                need(state == 'ok' and int(failed) == int(ignored) == 0, 'prior control receipt is not passing')
                controls += int(passed)
    need(controls == 8, 'prior independent control scope differs')
    return dict(files=len(files), inventory_sha256=digest(folder / 'inventory.json'),
                current_requests=80, prior_independent_controls=controls)


def native_counts(report):
    need(report.get('complete') is True and report['source_manifest_sha256'] == SOURCE,
         'current ABI51 native qualification is incomplete')
    scopes = [row for row in report['scopes'] if 'outcomes' in row]
    by_target = {}
    for target in (*ENGINE_TARGETS, *STRUCTURAL_TARGETS, 'emission', 'scriptw_ir_integration', 'scriptw_aot_wasm'):
        rows = [row for row in scopes if row['target'] == target
                and not any(not arg.startswith('-') for arg in row['argv'][1:])]
        need(len(rows) == 1, 'full native target is missing or ambiguous: ' + target)
        by_target[target] = rows[0]['outcomes']
    need(sum(by_target[t]['passed'] for t in ENGINE_TARGETS) == 1771, 'current Engine total differs')
    need(sum(by_target[t]['passed'] for t in STRUCTURAL_TARGETS) == 637, 'current structural total differs')
    need(by_target['emission']['passed'] == 67 and by_target['scriptw_ir_integration']['passed'] == 769,
         'emission/IR count differs')
    need(by_target['scriptw_aot_wasm']['failed'] == 4, 'known AOT failure count differs')
    return by_target
