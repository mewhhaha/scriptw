#!/usr/bin/env python3
"""Unscored Linux PMU group census of checked retained Flight request windows.

Run through scripts/limited_verification.py; no profiler timings are scored.
The native perf_event group read retains raw counts and both kernel durations.
"""
import argparse
import ctypes
import fcntl
import hashlib
import json
import os
from pathlib import Path
import platform
import socket
import statistics
import struct
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / 'scripts'))
from limited_verification import kernel_group, limited_environment, require_kernel_budget
sys.path.insert(0, str(ROOT / 'target/performance-intrinsic-array-reads-v2-20261102'))
from mixed_worker_samples import line, thread_record

EVENTS = [('cycles:u',0),('instructions:u',1),('branches:u',4),('branch-misses:u',5)]
FIELDS = ['memory.max','memory.swap.max','memory.oom.group','cpu.max','memory.events']
BASELINE = ROOT/'target/react-performance-20261103/promoted/candidate-fast-0.json'
DEFAULT_BINARY = ROOT/'target/react-performance-20261103/promoted/frozen/rsc_baseline'
NODE_DRIVER = Path(__file__).with_name('node_request_profile.v2.cjs')

def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda:stream.read(1024*1024), b''):
            h.update(chunk)
    return h.hexdigest()

def save(path, value):
    with path.open('x') as stream:
        json.dump(value,stream,indent=2)
        stream.write('\n')

class Counters:
    def __init__(self, tid):
        assert platform.machine() == 'x86_64', 'syscall number is pinned to Linux x86_64'
        self.fds, self.names = [], {}
        libc = ctypes.CDLL(None, use_errno=True)
        libc.syscall.restype = ctypes.c_long
        try:
            for name, config in EVENTS:
                # PERF_TYPE_HARDWARE; VER0 size64. Disabled group, user-only,
                # no inheritance. Group read: nr, enabled, running, value/id.
                attr = struct.pack('<IIQQQQQIIQ',0,64,config,0,0,15,1|(1<<5)|(1<<6),0,0,0)
                assert len(attr) == 64
                data = ctypes.create_string_buffer(attr)
                leader = -1
                if self.fds:
                    leader = self.fds[0]
                fd = libc.syscall(298,ctypes.byref(data),tid,-1,leader,8)
                if fd == -1:
                    raise OSError(ctypes.get_errno(), f'perf_event_open({name},tid={tid})')
                self.fds.append(fd)
                event_id = bytearray(8)
                fcntl.ioctl(fd,0x80082407,event_id,True) # PERF_EVENT_IOC_ID
                self.names[struct.unpack('<Q',event_id)[0]] = name
            self.disable()
            fcntl.ioctl(self.fds[0],0x2403,1) # RESET, PERF_IOC_FLAG_GROUP
            self.previous = self.read()
        except BaseException:
            self.close()
            raise

    def enable(self):
        fcntl.ioctl(self.fds[0],0x2400,1)

    def disable(self):
        fcntl.ioctl(self.fds[0],0x2401,1)

    def read(self):
        raw = os.read(self.fds[0],24+16*len(EVENTS))
        assert len(raw) == 24+16*len(EVENTS), raw.hex()
        values = struct.unpack('<'+'Q'*(len(raw)//8),raw)
        assert values[0] == len(EVENTS)
        counts = {self.names[values[i+1]]:values[i] for i in range(3,len(values),2)}
        return {'time_enabled_ns':values[1],'time_running_ns':values[2],'raw_counts':counts,
                'kernel_group_read_hex':raw.hex()}

    def window(self):
        current = self.read()
        enabled = current['time_enabled_ns']-self.previous['time_enabled_ns']
        running = current['time_running_ns']-self.previous['time_running_ns']
        assert 0 < running <= enabled, (enabled,running)
        counts = {name:current['raw_counts'][name]-self.previous['raw_counts'][name] for name,_ in EVENTS}
        self.previous = current
        return {'time_enabled_ns':enabled,'time_running_ns':running,
                'running_fraction':running/enabled,'raw_counts':counts,
                'multiplex_scaled_counts':{name:value*enabled/running for name,value in counts.items()},
                'cumulative_read':current}

    def close(self):
        for fd in self.fds:
            os.close(fd)
        self.fds = []

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('output',type=Path)
    parser.add_argument('--engine',choices=['scriptw','node'],required=True)
    parser.add_argument('--mode',choices=['sync','async'],required=True)
    parser.add_argument('--binary',type=Path,default=DEFAULT_BINARY)
    parser.add_argument('--node',default='node')
    parser.add_argument('--native-mode',choices=['fast','speed'],default='fast')
    parser.add_argument('--empty-window-calibration',action='store_true',
                        help='Node only: genuine Flight warmups, then checked literal-null empty windows; no subtraction')
    parser.add_argument('--baseline-json',type=Path,default=BASELINE)
    parser.add_argument('--samples',type=int,default=100)
    parser.add_argument('--warmups',type=int,default=3)
    args = parser.parse_args()
    assert 1 <= args.samples <= 200 and 0 <= args.warmups <= 20
    assert not args.empty_window_calibration or args.engine == 'node'
    assert args.engine != 'node' or args.native_mode == 'fast'
    if args.empty_window_calibration:
        assert args.warmups == 3, 'empty-window calibration retains exactly three genuine Flight warmups'
    require_kernel_budget(4*1024**3)
    assert len(os.sched_getaffinity(0)) == 1
    baseline_path = args.baseline_json.resolve(strict=True)
    baseline = json.loads(baseline_path.read_text())
    source,support = (Path(baseline['inputs'][name]) for name in ('source','support'))
    assert digest(source) == baseline['inputs']['source_sha256']
    assert digest(support) == baseline['inputs']['support_sha256']
    folder = args.output.resolve()
    folder.mkdir(exist_ok=False)
    (folder/'tmp').mkdir()
    nonce = os.urandom(16).hex()
    parent,child_socket = socket.socketpair()
    env = limited_environment()
    assert not any(key.startswith('SCRIPTW_RSC_PROFILE_') for key in env)
    assert 'LD_PRELOAD' not in env and 'LD_AUDIT' not in env
    env.update(TMPDIR=str(folder/'tmp'),SCRIPTW_RSC_PROFILE_FD=str(child_socket.fileno()),
               SCRIPTW_RSC_PROFILE_NONCE=nonce,SCRIPTW_RSC_PROFILE_MODE=args.mode)
    if args.empty_window_calibration:
        env['SCRIPTW_RSC_PROFILE_EMPTY_WINDOW'] = '1'
    executable = args.binary.resolve(strict=True)
    argv = [str(executable)]
    if args.engine == 'node':
        import shutil
        executable = Path(shutil.which(args.node)).resolve(strict=True)
        argv = [str(executable),'--experimental-vm-modules',str(NODE_DRIVER)]
    else:
        assert digest(executable) == baseline['executable_sha256']
    argv += [str(source),str(support),str(folder/'observations.json'),str(args.samples),str(args.warmups)]
    if args.engine == 'scriptw':
        argv.append(args.native_mode)
    result = {'schema':'scriptw-rsc-pmu-v2','adapter_version':2,'status':'incomplete','excluded_from_scored_cohorts':True,
              'engine':args.engine,'mode':args.mode,'argv':argv,'samples':args.samples,'warmups':args.warmups,
              'native_mode':args.native_mode,'empty_window_calibration':args.empty_window_calibration,
              'executable_sha256':digest(executable),'baseline_report_sha256':digest(baseline_path),
              'source_sha256':digest(source),'support_sha256':digest(support),
              'adapter_sha256':digest(Path(__file__)),'node_driver_sha256':digest(NODE_DRIVER),
              'counter_policy':'One user-only hardware group, targeted TID, no inheritance; exact kernel enabled/running ns and raw counts retained. Scaled counts explicitly separate.',
              'limits':'Unscored diagnostic. Node main-thread barrier and Promise-return edge instructions are inside counter bounds; Scriptw barriers run on its coordinator thread. Node background compiler/GC threads and Scriptw other threads are excluded. Initialization, warmups, JSON encoding and output checks excluded. No request timing or wall-time speedup claim.',
              'resources_before':{name:(kernel_group()/name).read_text() for name in FIELDS},'events':[],'windows':[]}
    if args.empty_window_calibration:
        result['schema'] = 'scriptw-rsc-empty-window-calibration-pmu-v1'
        result['limits'] = ('Node barrier calibration only, not qualified rendering. Three genuine Flight warmups are gold checked outside counters; measured windows only assign literal null, whose encoded literal golden is checked outside counters. Raw counts retained, no subtraction. '+result['limits'])
    save(folder/'plan.json',result)
    child = counters = None
    deadline = time.monotonic()+180
    try:
        with (folder/'host.stdout').open('xb') as out,(folder/'host.stderr').open('xb') as err:
            child = subprocess.Popen(argv,cwd=ROOT,env=env,stdin=subprocess.DEVNULL,
                                     stdout=out,stderr=err,pass_fds=(child_socket.fileno(),))
            child_socket.close()
            result['pid'] = child.pid
            for index in range(args.warmups,args.warmups+args.samples):
                for phase in ('ready','done'):
                    event = line(parent.fileno(),min(60,deadline-time.monotonic()))
                    expected = f'SWRSC1 {nonce} {phase} {args.mode} {index}\n'
                    assert event == expected,(event,expected)
                    result['events'].append({'phase':phase,'index':index,'monotonic_ns':time.monotonic_ns()})
                    if counters is None:
                        worker = thread_record(child.pid,child.pid)
                        if args.engine == 'scriptw':
                            workers = [thread_record(child.pid,int(path.name)) for path in Path(f'/proc/{child.pid}/task').iterdir()
                                       if (path/'comm').read_text().strip() == 'scriptw-execution'[:15]]
                            assert len(workers) == 1
                            worker = workers[0]
                            assert worker['tid'] != child.pid
                        result['worker_before'] = worker
                        counters = Counters(worker['tid'])
                    if phase == 'ready':
                        counters.enable()
                    else:
                        counters.disable()
                        window = counters.window()
                        window['index'] = index
                        result['windows'].append(window)
                        after = thread_record(child.pid,worker['tid'])
                        assert after['starttime_ticks'] == worker['starttime_ticks']
                        result['worker_after'] = after
                    parent.sendall(expected.replace('SWRSC1','SWACK1',1).encode())
            result['host_exit_code'] = child.wait(timeout=30)
        assert result['host_exit_code'] == 0
        report = json.loads((folder/'observations.json').read_text())
        assert report['profiling']['nonce'] == nonce
        assert report['profiling']['windows'] == args.samples
        assert report['profiling']['excluded_from_scored_cohorts'] is True
        assert report['inputs']['source_sha256'] == baseline['inputs']['source_sha256']
        assert report['inputs']['support_sha256'] == baseline['inputs']['support_sha256']
        assert len(report['cases']) == 1
        case = report['cases'][0]
        expected_case = 'rsc-'+args.mode
        if args.empty_window_calibration:
            expected_case += '-empty-window-calibration'
            assert case['exact_node_output_checked'] is False
            assert case['genuine_flight_warmups_checked'] is True
            assert case['literal_empty_result_checked'] is True
            assert report['profiling']['empty_window_calibration'] is True
            assert all(o['exact_golden_output_checked'] for o in case['observations'])
            assert all(o['kind'] == 'flight' for o in case['observations'][:args.warmups])
            assert all(o['kind'] == 'empty-window-calibration' for o in case['observations'][args.warmups:])
        else:
            assert case['exact_node_output_checked'] is True
        assert case['case'] == expected_case
        assert len(case['observations']) == args.samples+args.warmups
        if args.engine == 'scriptw':
            for name in ('program_wasm_sha256','runtime'):
                assert report[name] == baseline[name]
            expected_configuration = dict(baseline['configuration'])
            if args.native_mode == 'speed':
                expected_configuration.update(cranelift_opt_level='Speed',register_allocation='Backtracking')
            assert report['configuration'] == expected_configuration
            assert report['native_mode'] == args.native_mode
            result['actual_configuration'] = report['configuration']
        else:
            assert report['inputs']['adapted_source_sha256'] == baseline['inputs']['adapted_source_sha256']
            assert report['main_thread_pid'] == child.pid
        result['summary'] = {'raw_counts':{name:sum(w['raw_counts'][name] for w in result['windows']) for name,_ in EVENTS},
                             'minimum_running_fraction':min(w['running_fraction'] for w in result['windows']),
                             'multiplex_scaled_median_counts':{name:statistics.median(w['multiplex_scaled_counts'][name] for w in result['windows']) for name,_ in EVENTS}}
        result['status'] = 'captured'
    except BaseException as error:
        result['status'] = 'failed'
        result['error'] = repr(error)
        raise
    finally:
        if counters is not None:
            counters.close()
        if child is not None and child.poll() is None:
            child.kill()
            child.wait(timeout=5)
        parent.close()
        child_socket.close()
        result['resources_after'] = {name:(kernel_group()/name).read_text() for name in FIELDS}
        result['raw_files'] = {path.name:{'sha256':digest(path),'bytes':path.stat().st_size} for path in folder.iterdir() if path.is_file()}
        save(folder/'receipt.json',result)
    print(json.dumps({'status':result['status'],'output':str(folder),'summary':result.get('summary')}))

if __name__ == '__main__':
    main()
