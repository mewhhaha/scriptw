"""Derive the local summary from preserved raw evidence; does not publish."""
from pathlib import Path
import hashlib
import json

ROOT = Path('/workspace/scriptw')
WORK = ROOT / 'target/performance-module-locals'
def load(path): return json.loads(path.read_text())
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
a = load(WORK / 'analysis.json')
repeat = load(WORK / 'repeat-analysis.json')
archive = ROOT / 'docs/rust-rewrite/module-local-performance-20261030-inert.tar.gz'
identities = {label: load(WORK / label / 'identity.json') for label in ('baseline', 'candidate')}
producers = {label: {c['file']: c for c in load(WORK / (label + '-images') / 'producer.json')['cases']} for label in identities}
for row in a['workloads']:
    row['retained_preparation'] = {}
    for label in identities:
        p = producers[label][row['file']]
        fields = ('derived_source_sha256', 'program_wasm_sha256', 'image_sha256', 'image_bytes', 'phases_ns', 'runtime_key')
        row['retained_preparation'][label] = {k: p[k] for k in fields}
        row['retained_preparation'][label]['program_wasm_bytes'] = (WORK / (label + '-images') / (row['file'] + '.retained.wasm')).stat().st_size
        row['retained_preparation'][label]['source_and_native_preparation_are_outside_call_timer'] = True
section = load(WORK / 'ordinary-image-identities.json')
snapshot = load(next((WORK / 'test262').glob('module-locals-module-code-*.json')))
report = {
    'schema': 'scriptw-module-local-performance-diagnostic-v1',
    'measured_date_utc': '2026-10-30',
    'change': 'Keep proven uncaptured activation var bindings and simple parameters in strict ordinary reusable module functions in private storage; preserve actual capture cells, live Realm/nonlocal lookup and conservative eval, arguments and surrounding-with fallbacks.',
    'scope': 'Same-machine before/after diagnostic of 17 original fixtures and strict derived retained-call modules. Retained calls are excluded from ordinary and published scored cohorts. No V8/Scriptc parity or full-suite acceptance claim.',
    'sources': {
        'head': identities['baseline']['source_commit'], 'baseline_clean': True,
        'candidate': 'Uncommitted compiler/test/doc patch on the same HEAD; published environment and status were not changed.',
        'compiler_identity_scheme': identities['candidate']['compiler_identity_scheme'],
        'compiler_source_fingerprints': {label: i['source_fingerprint'] for label, i in identities.items()},
        'compiled_patch_in_archive': 'raw/candidate-final.patch',
        'compiled_patch_sha256': sha(WORK / 'candidate-final.patch'),
        'final_review_patch_in_archive': 'raw/candidate-review.patch',
        'final_review_patch_sha256': sha(WORK / 'candidate-review.patch'),
        'production_and_tests_match_compiled_patch': True,
    },
    'machine': load(WORK / 'machine.json'),
    'resource_policy': {
        'cloud_memory_bytes': 34359738368, 'cloud_memory_swap_max': 'max', 'cloud_memory_oom_group': 0,
        'cloud_cpu_quota': 4, 'measurement_cpu_affinity': [0], 'build_and_tests_idle_during_measurement': True,
        'cargo_and_libtest_serial': True, 'retained_module_cache_entries': 512,
        'retained_module_cache_image_bytes': 2147483648,
        'cgroup_after': load(WORK / 'final-inputs.json')['cgroup_after'],
        'note': 'Inherited finite cloud budget; not the local 4-GiB/no-swap/grouped-OOM policy.',
    },
    'artifacts': {label: load(WORK / label / 'products.json') for label in identities},
    'retained_configuration': identities['candidate']['shared_configuration'],
    'retained_call_boundary': 'Public EmbeddedInstance::call includes worker dispatch, guest execution, output capture and completion; excludes per-call output draining/checksum validation; natural GC; same retained function/Store/Realm after one module initialization. Source and native preparation, admission, initialization and setup are separately retained.',
    'ordinary_boundary': 'Original scripts through runtime_baseline with default automatic native policy, fresh Store/Realm per observation and warm module/host-import caches. Raw records separate source compilation, admission, setup, execution, sampled process RSS and GC capacity.',
    'measurement': a,
    'ordinary_identity_control': {
        'all_17_complete_program_and_linked_runtime_wasm_identical_across_original_four_rounds': True,
        'raw': 'raw/ordinary-image-identities.json', 'section_detail': 'raw/ordinary-section-comparison.json',
        'workloads': [{'file': r['file'], 'program_wasm_sha256': r['rounds'][0]['program_wasm_sha256'], 'linked_runtime': r['rounds'][0]['linked_runtime']} for r in section],
    },
    'opposite_order_control_repeat': repeat,
    'verification': load(WORK / 'validation.json'),
    'selected_original_test262': {
        'pinned_revisions': snapshot['pinned_revisions'], 'execution_backend': 'wasm-aot',
        'jobs': 1, 'test_threads': 1, 'reuse_case_workers': True, 'deadline_ms': 60000,
        **load(WORK / 'test262-summary.json'),
        'failure_owner': 'scriptw-aot-wasm local-storage initialization / function hoisting; crates/scriptw-aot-wasm/src/environments.rs:671. No skip or expected-failure change.',
    },
    'limitations': [
        'Affected default-release native targets and five selected pinned Test262 families only; full current-source default/all-feature/optimized acceptance remains open.',
        'Whole-workspace formatting check still fails on the same 18 files as the initially clean baseline; no newly affected file.',
        'Two original Test262 function-code crashes reproduce on the preserved baseline and remain counted.',
        'Ordinary controls vary and include persistent slower results; this diagnostic does not refresh published comparison cohorts.',
    ],
    'harness_diagnostics': [
        {'raw': 'raw/startup-format-probe/', 'result': 'The first unscored startup probe exited successfully with correct output but orchestration expected the wrong debug completion string. Preserved separately; no scored samples were collected before restarting the complete ABBA sequence.'},
        {'raw': 'raw/measurement.log', 'result': 'All ABBA invocations and checksum checks succeeded; aggregation then failed on a variable-name collision. Corrected analysis reads the same saved samples, with no timing rerun or sample removal.'},
        {'raw': 'raw/native/receipt.json', 'result': 'Original source-guard/namespace expectation failures, one invalid Realm fixture and three socket sandbox denials are retained; affected test-only corrections and socket-capable reruns are recorded separately.'},
    ],
    'evidence': {
        'archive': archive.name, 'archive_sha256': sha(archive), 'archive_bytes': archive.stat().st_size,
        'index': 'evidence-index.json',
        'path_mapping': 'raw/ entries map to target/performance-module-locals; watched/ contains native transcripts at the mapped original receipt paths. Archive members are inert regular files with byte hashes.',
        'excluded': ['native executables', 'serialized native images', 'emitted Wasm', 'runtime caches', 'toolchain'],
        'reproduce': 'Use the recorded HEAD and candidate-final.patch, the same Rust toolchain and Cargo producers/profiles. Existing compiler_precompiled_baseline prepare-retained/execute-retained and runtime_baseline hosts plus raw/measure.py and raw/repeat-controls.py retain exact commands, output checks, orders and analysis. Rebuild missing native artifacts; recorded digests are provenance, not permission to deserialize external native images.',
    },
}
retained_examples = []
for name in ('numeric-loop-50000.js', 'sort-reverse-512.js'):
    row = next(r for r in a['workloads'] if r['file'] == name)
    p = row['retained']['products']
    retained_examples.append({'file': name, 'baseline_ms': p['baseline']['median_ns'] / 1e6, 'candidate_ms': p['candidate']['median_ns'] / 1e6, 'speedup': p['baseline']['median_ns'] / p['candidate']['median_ns']})
slower = []
for name in ('sort-reverse-512.js', 'join-4096.js'):
    original = next(r for r in a['workloads'] if r['file'] == name)
    opposite = next(r for r in repeat['workloads'] if r['file'] == name)
    slower.append({'file': name, 'initial_change_percent': original['ordinary']['change_percent'], 'repeat_change_percent': opposite['change_percent']})
report['interpretation'] = {
    'retained_call_median_reduction_percent_range': [min(-r['retained']['change_percent'] for r in a['workloads']), max(-r['retained']['change_percent'] for r in a['workloads'])],
    'retained_calls': 'All 17 retained-call medians decreased in the original ABBA diagnostic. These are derived strict module workloads, not ordinary invocation scores.',
    'retained_examples': retained_examples,
    'ordinary_controls': 'All original slower scores are retained. Opposite-order controls reverse retained-objects and startup slowdowns. Identical complete program/runtime Wasm rules out a changed emitted ordinary program but does not establish absence of a native-host or measurement regression. The two persistently slower controls below remain unresolved; no general ordinary-script speed claim.',
    'persistently_slower_ordinary_controls': slower,
    'memory': 'Whole-child high-water RSS includes loading, setup, warmups and calls; not live JavaScript memory or per-call memory. Preserve both per-product peaks for every workload. Retained join-4096 peaks slightly increase; no across-the-board memory reduction claim.',
    'statistics': 'Seven measured observations after ten warmups per process, two processes per product in balanced ABBA; medians pool 14 observations, with per-round medians retained. Selected ordinary/startup controls repeat in BAAB. No statistical significance claim.',
}
out = ROOT / 'docs/rust-rewrite/module-local-performance-20261030.json'
out.write_text(json.dumps(report, indent=2) + '\n')
print(out, out.stat().st_size)
