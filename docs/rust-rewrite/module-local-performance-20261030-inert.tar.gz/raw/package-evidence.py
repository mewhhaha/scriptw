"""Freeze inert local diagnostic evidence; no publication or native payloads."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import subprocess
import tarfile

ROOT = Path('/workspace/scriptw')
WORK = ROOT / 'target/performance-module-locals'
DEST = ROOT / 'docs/rust-rewrite/module-local-performance-20261030-inert.tar.gz'

def digest(data): return hashlib.sha256(data).hexdigest()
def dump(value): return (json.dumps(value, indent=2) + '\n').encode()
def load(path): return json.loads(path.read_text())

# Confirm all compiled production and test changes still match their frozen input.
subprocess.run(['git', 'apply', '--reverse', '--check', '--include=crates/**', str(WORK / 'candidate-final.patch')], cwd=ROOT, check=True)
subprocess.run(['git', 'diff', '--check'], cwd=ROOT, check=True)
patch = subprocess.check_output(['git', 'diff', '--binary', '--', 'crates', 'README.md', 'docs/performance-hills.md', 'docs/rust-rewrite/current-inventory.md', 'docs/rust-rewrite/contracts/execution-hotpaths.md'], cwd=ROOT)
extra = subprocess.run(['git', 'diff', '--no-index', '--binary', '--', '/dev/null', 'crates/scriptw-ir/src/analysis/module_locals.rs'], cwd=ROOT, capture_output=True)
assert extra.returncode == 1 and not extra.stderr
(WORK / 'candidate-review.patch').write_bytes(patch + extra.stdout)

# Check complete ordinary P/R identities across the original four rounds.
analysis = load(WORK / 'analysis.json')
ordinary = []
for row in analysis['workloads']:
    values = []
    for r, label in enumerate(analysis['order']):
        c = load(WORK / f'round-{r}-{label}-ordinary-{row["file"]}.stdout')['cases'][0]
        path = WORK / f'round-{r}-ordinary-wasm' / (row['file'] + '.wasm')
        assert digest(path.read_bytes()) == c['wasm_sha256']
        values.append({'round': r, 'product': label, 'program_wasm_sha256': c['wasm_sha256'], 'linked_runtime': c['linked_runtime'], 'footprint': c['footprint']})
    assert len({v['program_wasm_sha256'] for v in values}) == 1
    assert all(v['linked_runtime'] == values[0]['linked_runtime'] for v in values)
    ordinary.append({'file': row['file'], 'all_four_program_and_runtime_wasm_equal': True, 'rounds': values})
(WORK / 'ordinary-image-identities.json').write_bytes(dump(ordinary))

final = {'production_and_tests_match_compiled_patch': True, 'compiled_patch': 'candidate-final.patch', 'compiled_patch_sha256': digest((WORK / 'candidate-final.patch').read_bytes()), 'final_review_patch': 'candidate-review.patch', 'final_review_patch_sha256': digest((WORK / 'candidate-review.patch').read_bytes()), 'cgroup_after': {n: (Path('/sys/fs/cgroup') / n).read_text().strip() for n in ['memory.max', 'memory.swap.max', 'memory.oom.group', 'memory.events', 'cpu.max']}, 'executable_hashes_rechecked': {label: {name: digest((WORK / label / name).read_bytes()) for name in ['scriptw', 'runtime_baseline', 'compiler_precompiled_baseline']} for label in ['baseline', 'candidate']}}
for label, products in final['executable_hashes_rechecked'].items():
    assert all(value == load(WORK / label / 'products.json')[name]['sha256'] for name, value in products.items())
(WORK / 'final-inputs.json').write_bytes(dump(final))

# Seal large Cargo streams separately, retaining both compressed and original digests.
sealed = WORK / 'sealed-cargo'
sealed.mkdir(exist_ok=True)
seals = []
for source in sorted(WORK.glob('*.jsonl')):
    value = source.read_bytes()
    compressed = gzip.compress(value, compresslevel=9, mtime=0)
    output = sealed / (source.name + '.gz')
    output.write_bytes(compressed)
    seals.append({'original': source.name, 'original_bytes': len(value), 'original_sha256': digest(value), 'sealed': str(output.relative_to(WORK)), 'sealed_bytes': len(compressed), 'sealed_sha256': digest(compressed)})
(sealed / 'index.json').write_bytes(dump(seals))

allowed = {'.json', '.jsonl', '.log', '.txt', '.py', '.patch', '.stdout', '.stderr', '.exit', '.js', '.mjs', '.gz'}
folders = {'baseline', 'candidate', 'baseline-images', 'candidate-images', 'native', 'native-correction', 'realm-control', 'test262', 'test262-baseline', 'startup-format-probe', 'sealed-cargo'}
members = {}
for path in sorted(WORK.rglob('*')):
    if not path.is_file() or path.is_symlink(): continue
    rel = path.relative_to(WORK)
    if len(rel.parts) > 1 and rel.parts[0] not in folders: continue
    if path.suffix not in allowed or path.suffix == '.jsonl' or path.name in {'evidence-index.json', 'package.log'}: continue
    members['raw/' + rel.as_posix()] = path.read_bytes()
transcripts = []
for folder in ['native', 'native-correction']:
    for case in load(WORK / folder / 'receipt.json')['cases']:
        source = ROOT / case['transcript_log']
        name = 'watched/' + source.name
        value = source.read_bytes()
        assert name not in members
        members[name] = value
        transcripts.append({'original_path': case['transcript_log'], 'archive_path': name, 'sha256': digest(value)})
fixtures = ROOT / 'crates/scriptw-cli/tests/fixtures/v8_execution_hotpaths'
manifest = load(fixtures / 'manifest.json')
for name in ['manifest.json', manifest['startup']['file']]: members['fixtures/' + name] = (fixtures / name).read_bytes()
failure = 'language/function-code/S10.2.1_A4_T2.js'
members['fixtures/' + failure] = (ROOT / 'test262/vendor/test262/test' / failure).read_bytes()
index = {'schema': 'scriptw-module-local-inert-evidence-v1', 'path_mapping': 'raw/ paths are relative to the original /workspace/scriptw/target/performance-module-locals work directory; original absolute command paths are preserved, not executable archive instructions.', 'excluded': ['native executable files', 'serialized .swpc images', 'emitted .wasm files', 'runtime caches', 'toolchain'], 'sealed_cargo': seals, 'transcript_path_mapping': transcripts, 'members': [{'path': name, 'bytes': len(value), 'sha256': digest(value)} for name, value in sorted(members.items())]}
index_bytes = dump(index)
(WORK / 'evidence-index.json').write_bytes(index_bytes)
members['evidence-index.json'] = index_bytes
with DEST.open('wb') as output:
    with gzip.GzipFile(fileobj=output, mode='wb', filename='', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w', format=tarfile.PAX_FORMAT) as archive:
            for name, value in sorted(members.items()):
                entry = tarfile.TarInfo(name); entry.size = len(value); entry.mode = 0o644
                archive.addfile(entry, io.BytesIO(value))
# Re-read every archive member; reject links, duplicate paths and digest changes.
with tarfile.open(DEST, 'r:gz') as archive:
    entries = archive.getmembers()
    assert len(entries) == len(members) and len({e.name for e in entries}) == len(entries)
    for entry in entries:
        assert entry.isfile() and not Path(entry.name).is_absolute() and '..' not in Path(entry.name).parts
        assert archive.extractfile(entry).read() == members[entry.name]
print(json.dumps({'archive': str(DEST.relative_to(ROOT)), 'sha256': digest(DEST.read_bytes()), 'bytes': DEST.stat().st_size, 'members': len(members), 'uncompressed_member_bytes': sum(map(len, members.values()))}, indent=2))
