export function sum(stop) {
  var total = 0;
  for (var index = 0; index < stop; index++) total += index;
  return total + offset;
}
export function replace(next) { offset = next; return offset; }
