"""Opposite-order diagnostic for slower unchanged ordinary-script controls."""
from measure import WORK, FIXTURES, PLAN, invoke, digest
from pathlib import Path
import hashlib
import json
import os
import statistics

ORDER = ('candidate', 'baseline', 'baseline', 'candidate')
NAMES = ('sort-reverse-128.js', 'sort-reverse-512.js', 'join-4096.js', 'numeric-loop-50000.js', 'retained-objects.js')
EXPECTED = {c['file']: c['stdout'] for c in PLAN['execution']}
resources = {'affinity': sorted(os.sched_getaffinity(0)), 'order': ORDER, 'rounds': []}
for r, label in enumerate(ORDER):
    entry = {'round': r, 'product': label, 'load_average_before': os.getloadavg()}
    images = WORK / f'repeat-{r}-ordinary-wasm'
    images.mkdir()
    for i in range(17):
        invoke(f'repeat-{r}-{label}-startup-{i}',
               [WORK / label / 'scriptw', 'run', FIXTURES / PLAN['startup']['file']], timeout=60,
               expected=PLAN['startup']['stdout'] + 'run outcome: RunOutcome { backend_used: WasmAot, note: "wasm-aot completion: undefined(undefined)" }\n')
    for name in NAMES:
        invoke(f'repeat-{r}-{label}-ordinary-{name}',
               [WORK / label / 'runtime_baseline', FIXTURES, '7', '10', name, images])
    entry['load_average_after'] = os.getloadavg()
    resources['rounds'].append(entry)
    (WORK / 'repeat-resources.json').write_text(json.dumps(resources, indent=2) + '\n')
rows = []
for name in NAMES:
    row = {'file': name, 'products': {}}
    for label in ('baseline', 'candidate'):
        samples = []; medians = []; raw = []
        identity = json.loads((WORK / label / 'identity.json').read_text())
        products = json.loads((WORK / label / 'products.json').read_text())
        for r, product in enumerate(ORDER):
            if product != label: continue
            stem = f'repeat-{r}-{label}-ordinary-{name}'
            value = json.loads((WORK / (stem + '.stdout')).read_text())
            assert value['executable_sha256'] == products['runtime_baseline']['sha256']
            assert value['source_fingerprint'] == identity['source_fingerprint']
            case = value['cases'][0]
            assert len(case['observations']) == 17
            assert all(o['stdout'] == EXPECTED[name] for o in case['observations'])
            values = [o['execution_ns'] for o in case['observations'] if not o['warmup']]
            assert len(values) == 7
            samples.extend(values); medians.append(statistics.median(values)); raw.append(stem + '.stdout')
            original = WORK / f'round-{0 if label == "baseline" else 1}-ordinary-wasm' / (name + '.wasm')
            assert digest(images.parent / f'repeat-{r}-ordinary-wasm' / (name + '.wasm')) == digest(original)
        row['products'][label] = {'median_ns': statistics.median(samples), 'round_median_ns': medians, 'raw': raw}
    row['change_percent'] = 100 * (row['products']['candidate']['median_ns'] / row['products']['baseline']['median_ns'] - 1)
    rows.append(row)
startup = {}
for label in ('baseline', 'candidate'):
    samples = []; medians = []
    for r, product in enumerate(ORDER):
        if product != label: continue
        values = [json.loads((WORK / f'repeat-{r}-{label}-startup-{i}.command.json').read_text())['elapsed_ns'] for i in range(10, 17)]
        samples.extend(values); medians.append(statistics.median(values))
    startup[label] = {'median_whole_cli_ns': statistics.median(samples), 'round_median_ns': medians}
summary = {'reason': 'Initial ordinary controls had slower candidate scores despite identical complete P and linked R Wasm hashes; repeat in opposite balanced order with the same frozen native hosts.', 'order': ORDER, 'warmups_per_round': 10, 'samples_per_round': 7, 'workloads': rows, 'startup': startup, 'all_repeat_program_wasm_equal_to_original': True}
(WORK / 'repeat-analysis.json').write_text(json.dumps(summary, indent=2) + '\n')
for row in rows: print(row['file'], round(row['change_percent'], 1), flush=True)
print('startup', startup, flush=True)
