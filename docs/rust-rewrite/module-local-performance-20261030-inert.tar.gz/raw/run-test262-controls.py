from pathlib import Path
import hashlib,json,re,subprocess

root=Path('/workspace/scriptw/target/performance-module-locals')
cli=root/'candidate/scriptw'
scopes=[('function-code','language/function-code'),
        ('variable','language/statements/variable'),
        ('eval-code','language/eval-code'),
        ('shadowrealm-import','built-ins/ShadowRealm/prototype/importValue')]
failed=False
for name,scope in scopes:
    argv=[str(cli),'--jobs','1','test262','run',scope,'--execution-backend','wasm-aot',
          '--suite-root','test262/vendor/test262','--snapshot-dir',str(root/'test262'),
          '--snapshot-name','module-locals-'+name,'--threads','1','--timeout-ms','60000','--reuse-case-workers']
    print('START',name,flush=True)
    with (root/('test262-'+name+'.log')).open('xb') as log:
        result=subprocess.run(argv,cwd='/workspace/scriptw',stdout=log,stderr=subprocess.STDOUT)
    text=(root/('test262-'+name+'.log')).read_text()
    total=re.search(r'^total: (\d+)$',text,re.M)
    receipt=dict(argv=argv,exit_code=result.returncode,total=int(total[1]) if total else None,
                 executable_sha256=hashlib.sha256(cli.read_bytes()).hexdigest())
    (root/('test262-'+name+'.receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n')
    failed |= result.returncode!=0 or not total or int(total[1])==0
    print('END',name,'exit',result.returncode,flush=True)
    print('\n'.join(text.splitlines()[-16:]),flush=True)
raise SystemExit(1 if failed else 0)
