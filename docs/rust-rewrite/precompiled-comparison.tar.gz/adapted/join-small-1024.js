function print(value) { console.log(String(value)); }
(function workload(){
var a=["a","b","c","d"],s=0;for(var i=0;i<1024;i++)s+=a.join(",").length;print(s);
})();
