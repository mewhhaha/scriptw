"""Compile all affected target harnesses serially; actual counts come later."""
from collections import OrderedDict
from campaign_runtime import actual_source,require_scope,read,BASE,check


def main():
    actual_source();require_scope();groups=OrderedDict()
    for scope in read(BASE/'native-scopes.json'):groups.setdefault(scope['package'],[]).append(scope)
    for package,scopes in groups.items():
        command=['cargo','test','--locked','--offline','--release','--jobs','1','-p',package,'--no-run']
        for scope in scopes:
            command.append(scope['kind'])
            if scope['name'] is not None:command.append(scope['name'])
        check('frozen-build-'+package,command)


if __name__=='__main__':main()
