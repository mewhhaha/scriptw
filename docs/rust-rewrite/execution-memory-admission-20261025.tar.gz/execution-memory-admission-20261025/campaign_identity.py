"""Pure actual identities for the ignored runtime-admission memory campaign.

The published44e frozen products remain external authorities. Candidate source
is unresolved until real campaign.json and candidate/identity.json agree.
Importing this module runs no compiler, native test or workload.
"""
import hashlib
import json
import os
from pathlib import Path
import re

BASE = Path(__file__).resolve().parent
REPO = BASE.parent.parent
PRIOR = REPO / 'target/memory-fixed-costs-verified-20261025'
BASELINE_DIRECTORY = PRIOR / 'candidate'
BASELINE_DIAGNOSTIC_DIRECTORY = PRIOR / 'candidate-engine-allocation-probe'
ALLOCATION_HELPER = REPO / 'target/memory-fixed-costs-20261025/engine_allocation_diagnostic.rs'
BASELINE_SOURCE = '44e17ee4c73eeab6cc970804199109aa2aee51a9'
BASELINE_FINGERPRINT = 'b0cc78cfa75c838ab680844681b2043a05ff1a8a32474c8ea75c9b97212dbe94'
BASELINE_PRODUCTS = {
    'scriptw': '5eeabd2b155daf0df12d55ac48a0bb02cdd33ff3a83da29b3fc0902ea81d700c',
    'runtime_baseline': 'f4dfb1306f513cc5af1678d8cc1f8460787abbf503fc8cbbc80f1a347c88b21f',
    'runtime_boundaries': 'a701bd387bb9868f84c36321cfe7ada3b5c0075cc2a58522d7823d9c8a1b70af',
}
INSTRUMENTATION = (
    'SCRIPTW_PERF_MAP_DIR', 'SCRIPTW_WASM_TRACE', 'SCRIPTW_WASM_TRACE_DUMP',
    'SCRIPTW_EMIT_SIZE_REPORT', 'SCRIPTW_ROW_PERF_CONTROL', 'SCRIPTW_ROW_PERF_ACK',
    'SCRIPTW_ROW_PERF_REGION', 'SCRIPTW_BOUNDARY_READY_FD', 'SCRIPTW_BOUNDARY_READY_NONCE',
)


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def read(path):
    path = Path(path)
    require(path.is_file() and not path.is_symlink(), 'missing/symlinked actual authority: ' + str(path))
    return json.loads(path.read_text())


def product_directory(product):
    require(product in ['baseline', 'candidate'], 'unknown frozen product')
    return BASELINE_DIRECTORY if product == 'baseline' else BASE / 'candidate'


def baseline_authority():
    reference = read(BASE / 'baseline-reference.json')
    require(reference['schema'] == 'scriptw-memory-admission-baseline-reference-v1'
            and reference['baseline_source'] == BASELINE_SOURCE, 'baseline reference source/schema changed')
    expected = {'identity': BASELINE_DIRECTORY / 'identity.json', 'frozen_products': PRIOR / 'frozen-products.json',
                'source_checkpoint': REPO / 'docs/rust-rewrite/execution-memory-fixed-costs-20261025.json',
                'allocation_report': BASELINE_DIAGNOSTIC_DIRECTORY / 'report.json'}
    for name, path in expected.items():
        require(reference[name]['path'] == str(path) and digest(path) == reference[name]['sha256'],
                'published baseline authority bytes changed: ' + name)
    report = read(expected['source_checkpoint'])
    require(report['complete'] is True and report['source_commit'] == BASELINE_SOURCE
            and report['products']['candidate']['compiler_identity'] == read(expected['identity']),
            'baseline checkpoint does not admit the frozen44e identity')
    return reference


def checked_identity(product):
    identity = read(product_directory(product) / 'identity.json')
    require(identity.get('source_fingerprint_scheme') == 'scriptw-program-cache-compiler-v3'
            and re.fullmatch(r'[0-9a-f]{64}', identity.get('source_fingerprint', ''))
            and re.fullmatch(r'[0-9a-f]{64}', identity.get('executable_sha256', '')),
            product + ': malformed compiler identity')
    revision = identity.get('source_revision', {})
    require(revision.get('kind') == 'git-commit' and re.fullmatch(r'[0-9a-f]{40}', revision.get('commit', '')),
            product + ': no actual committed source')
    if product == 'baseline':
        baseline_authority()
        require(revision['commit'] == BASELINE_SOURCE and identity['source_fingerprint'] == BASELINE_FINGERPRINT
                and identity['executable_sha256'] == BASELINE_PRODUCTS['scriptw'],
                'baseline is not the exact published44e product')
    else:
        require(revision['commit'] != BASELINE_SOURCE, 'candidate must not silently reuse the old baseline source')
    return identity


def candidate_source():
    campaign = read(BASE / 'campaign.json')
    source = checked_identity('candidate')['source_revision']['commit']
    require(campaign['source_commit'] == source and campaign['baseline_source'] == BASELINE_SOURCE,
            'candidate source and actual campaign differ')
    return source


def product_source(product):
    source = checked_identity(product)['source_revision']['commit']
    require(source == (BASELINE_SOURCE if product == 'baseline' else candidate_source()),
            'product source and actual authority differ')
    return source


def frozen_product(product):
    identity = checked_identity(product)
    candidate_source()
    reference = baseline_authority() if product == 'baseline' else None
    hashes = {}
    for name in ['scriptw', 'runtime_baseline', 'runtime_boundaries']:
        path = product_directory(product) / name
        require(path.is_file() and not path.is_symlink() and path.stat().st_nlink == 1,
                'missing/symlinked/hardlinked frozen product: ' + str(path))
        hashes[name] = digest(path)
        if product == 'baseline':
            require(hashes[name] == BASELINE_PRODUCTS[name] == reference['products'][name]['sha256']
                    and reference['products'][name]['path'] == str(path), 'independent baseline changed: ' + name)
    require(hashes['scriptw'] == identity['executable_sha256'], 'actual frozen CLI identity differs')
    return identity, hashes


def ordinary_environment(environment=None):
    result = dict(os.environ if environment is None else environment)
    for name in INSTRUMENTATION:
        result.pop(name, None)
    result.pop('NODE_OPTIONS', None)
    result.pop('NODE_COMPILE_CACHE', None)
    result['NODE_DISABLE_COMPILE_CACHE'] = '1'
    result['SCRIPTW_COMPILER_CACHE_IMAGE_HASH'] = 'sha256'
    result.update(CARGO_BUILD_JOBS='1', SCRIPTW_JOBS='1', RUST_TEST_THREADS='1', RAYON_NUM_THREADS='1',
                  SCRIPTW_MODULE_MEMORY_CACHE_ENTRIES='1', SCRIPTW_MODULE_MEMORY_CACHE_LIMIT_BYTES=str(64 * 1024**2))
    return result


def environment_receipt(environment):
    names = [*INSTRUMENTATION, 'NODE_OPTIONS', 'NODE_COMPILE_CACHE', 'NODE_DISABLE_COMPILE_CACHE',
             'SCRIPTW_COMPILER_CACHE_IMAGE_HASH', 'CARGO_BUILD_JOBS', 'SCRIPTW_JOBS', 'RUST_TEST_THREADS',
             'RAYON_NUM_THREADS', 'SCRIPTW_MODULE_MEMORY_CACHE_ENTRIES', 'SCRIPTW_MODULE_MEMORY_CACHE_LIMIT_BYTES']
    return {name: environment.get(name) for name in names}


def validate_environment(environment):
    require(environment == environment_receipt(ordinary_environment({})),
            'ordinary serial/cache policy or disabled instrumentation differs')
