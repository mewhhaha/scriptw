# Fixed runtime allocation diagnostic comparison

One distinct standalone helper process per product/case, two invocations, identical source/callbacks; diagnostic requested Rust bytes and acknowledged process residency, not ordinary performance scores.

Each value is MiB (1,048,576 bytes). Every phase pair comes from the actual closed helper reports; this table is separate from ordinary README benchmark scores.

| Case / phase | Requested Rust live before → after | Process RSS before → after | RSS change |
| --- | ---: | ---: | ---: |
| scalar / before_engine | 0.001 → 0.001 | 4.922 → 4.949 | +0.56% |
| scalar / after_engine | 0.001 → 0.001 | 5.051 → 5.141 | +1.78% |
| scalar / after_compilation | 6.359 → 6.359 | 28.605 → 28.488 | -0.41% |
| scalar / after_execution_1 | 6.759 → 6.759 | 35.492 → 35.539 | +0.13% |
| scalar / after_dropping_profile_1 | 6.759 → 6.759 | 35.492 → 35.539 | +0.13% |
| scalar / after_execution_2 | 6.759 → 6.759 | 35.492 → 35.539 | +0.13% |
| scalar / after_dropping_profile_2 | 6.759 → 6.759 | 35.492 → 35.539 | +0.13% |
| scalar / after_dropping_artifact | 5.635 → 5.635 | 34.930 → 34.977 | +0.13% |
| scalar / after_dropping_engine | 5.635 → 5.635 | 34.930 → 34.977 | +0.13% |
| print / before_engine | 0.001 → 0.001 | 4.762 → 4.859 | +2.05% |
| print / after_engine | 0.001 → 0.001 | 4.953 → 5.113 | +3.23% |
| print / after_compilation | 6.723 → 6.720 | 72.699 → 34.367 | -52.73% |
| print / guest_start_1 | 8.866 → 8.850 | 117.043 → 77.492 | -33.79% |
| print / guest_body_finished_1 | 8.866 → 8.850 | 117.293 → 77.992 | -33.51% |
| print / after_execution_1 | 8.010 → 7.994 | 105.980 → 67.105 | -36.68% |
| print / after_dropping_profile_1 | 8.009 → 7.994 | 105.980 → 67.105 | -36.68% |
| print / guest_start_2 | 8.866 → 8.850 | 116.965 → 77.414 | -33.81% |
| print / guest_body_finished_2 | 8.866 → 8.850 | 117.215 → 77.914 | -33.53% |
| print / after_execution_2 | 8.010 → 7.994 | 105.980 → 67.105 | -36.68% |
| print / after_dropping_profile_2 | 8.009 → 7.994 | 105.980 → 67.105 | -36.68% |
| print / after_dropping_artifact | 7.849 → 7.833 | 105.902 → 67.027 | -36.71% |
| print / after_dropping_engine | 7.849 → 7.833 | 105.902 → 67.027 | -36.71% |
| retained / before_engine | 0.001 → 0.001 | 4.820 → 4.957 | +2.84% |
| retained / after_engine | 0.001 → 0.001 | 4.949 → 5.148 | +4.03% |
| retained / after_compilation | 6.723 → 6.720 | 74.574 → 36.156 | -51.52% |
| retained / guest_start_1 | 8.840 → 8.833 | 120.172 → 80.906 | -32.67% |
| retained / guest_body_finished_1 | 8.841 → 8.834 | 149.672 → 98.906 | -33.92% |
| retained / after_execution_1 | 7.984 → 7.977 | 109.109 → 70.520 | -35.37% |
| retained / after_dropping_profile_1 | 7.983 → 7.976 | 109.109 → 70.520 | -35.37% |
| retained / guest_start_2 | 8.840 → 8.833 | 120.121 → 80.855 | -32.69% |
| retained / guest_body_finished_2 | 8.841 → 8.834 | 149.629 → 98.863 | -33.93% |
| retained / after_execution_2 | 7.984 → 7.977 | 109.109 → 70.520 | -35.37% |
| retained / after_dropping_profile_2 | 7.983 → 7.976 | 109.109 → 70.520 | -35.37% |
| retained / after_dropping_artifact | 7.823 → 7.816 | 109.008 → 70.418 | -35.40% |
| retained / after_dropping_engine | 7.822 → 7.816 | 109.008 → 70.418 | -35.40% |

The complete 35 phase pairs retain raw smaps, coherent requested/released/live counters, both invocations, source/rlib/helper hashes and all commands. Baseline source is 44e17ee4c73eeab6cc970804199109aa2aee51a9; candidate source is 25909ef750d487e8ae257cdce909635d64196995. The helper source is byte-identical. All reductions remain observational; the counters do not by themselves assign each saved page or allocation to a component.

- Requested Rust GlobalAlloc sizes exclude allocator usable/resident bytes and native allocations bypassing GlobalAlloc.
- Anonymous mappings do not identify live JavaScript or Intl ownership; no exact causal subtraction between counters.
- Private file-backed native mappings change residency/reclaimability; cold-file/page-cache state and shared pages affect RSS/PSS.
- Baseline retains its original actual44e outer receipt; no baseline run is relabelled as the new source.
- Diagnostic module cache is one entry/64MiB; default SDK512MiB retention differs.
- Native perf-map hashing is disabled. RSS/capacity/virtual address space, logical requested peaks and guest live memory remain distinct.
