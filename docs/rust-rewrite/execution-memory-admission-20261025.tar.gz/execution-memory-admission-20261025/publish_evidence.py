#!/usr/bin/env python3
"""Read-only evidence admission; --publish creates one new immutable checkpoint.
No compiler, native test, helper or JavaScript workload is invoked here.
"""
from __future__ import annotations
import argparse,ast,gzip,hashlib,importlib,importlib.util,io,json,os,re,subprocess,sys,tarfile,types
from pathlib import Path
from collections import Counter
from datetime import datetime,timezone
from statistics import median
sys.dont_write_bytecode=True
BASE=Path(__file__).resolve().parent
REPO=BASE.parent.parent
sys.path.insert(0,str(BASE))
from campaign_identity import candidate_source,product_directory,BASELINE_SOURCE,PRIOR,ALLOCATION_HELPER,baseline_authority
CHECKPOINT=REPO/'docs/rust-rewrite/execution-memory-fixed-costs-20261025.json'
BASELINE_PATCH=EMPTY_PATCH=hashlib.sha256(b'').hexdigest()
STEM='execution-memory-admission-20261025'
PREFIX=STEM+'/'
BUDGET=4*1024**3
SUMMARY_RE=re.compile(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out')
KNOWN={'sloppy-script:annexB/language/function-code/block-decl-func-skip-arguments.js',
 'sloppy-script:intl402/Temporal/ZonedDateTime/links.js','strict-script:intl402/Temporal/ZonedDateTime/links.js',
 'sloppy-script:staging/sm/lexical-environment/block-scoped-functions-annex-b-label.js'}
ROUNDS=['baseline-round-a-data','candidate-round-b-data','candidate-round-c-data','baseline-round-d-data']
CALL_ROUNDS=['baseline-calls-round-a-data','candidate-calls-round-b-data','candidate-calls-round-c-data','baseline-calls-round-d-data']
PHASES=('before_engine','after_engine','after_compilation','guest_start_1','guest_body_finished_1','after_execution_1',
 'after_dropping_profile_1','guest_start_2','guest_body_finished_2','after_execution_2','after_dropping_profile_2','after_dropping_artifact','after_dropping_engine')
COUNTERS=('requested_live_bytes','peak_tracked_requested_live_bytes','interval_peak_tracked_requested_live_bytes',
 'total_successful_request_bytes','total_released_request_bytes','alloc_calls','alloc_zeroed_calls','realloc_calls','dealloc_calls')
EXPECTED_SCOPES = [
    ("scriptw-aot-wasm", "--lib", None),
    *[("scriptw-aot-wasm", "--test", name) for name in ["emission", "modules_realms", "runtime_link", "structure_async", "structure_builtins", "structure_language"]],
    ("scriptw-engine", "--lib", None),
    *[("scriptw-engine", "--test", name) for name in ["aot_async", "aot_async_generator_returns", "aot_builtins", "aot_gc_entries", "aot_generators", "aot_language", "aot_native_program_templates", "aot_realm_modules", "runtime_cache", "structure", "weak_gc_facility"]],
    ("scriptw-runtime-image", "--lib", None), ("scriptw-ir", "--lib", None),
    ("scriptw-cli", "--example", "runtime_baseline"), ("scriptw-cli", "--example", "runtime_boundaries"),
    *[("scriptw-engine", "--test", name) for name in ["aot_intl", "aot_module_sources", "aot_regexp", "aot_temporal"]],
    ("scriptw-intl", "--lib", None), ("scriptw-intl", "--test", "calendar_domain"),
    ("scriptw-intl", "--test", "datetime_calendar16"), ("scriptw-intl-build-data", "--lib", None),
]

def require(condition, message):
    if not condition:
        raise ValueError(message)

def digest(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()

def read_json(path):
    path = Path(path)
    require(path.is_file() and not path.is_symlink(), f"missing or symlinked evidence: {path}")
    return json.loads(path.read_text())

def member_path(path):
    path = Path(path)
    require(path.is_file() and not path.is_symlink(), f"missing or symlinked archive input: {path}")
    resolved = path.resolve()
    require(resolved.is_relative_to(REPO), f"archive input escaped repository: {path}")
    require(path.stat().st_size < 64 * 1024**2, f"oversized evidence input: {path}")
    require(path.suffix not in {".swbundle", ".v8cache"}, f"session bundle/cache payload excluded: {path}")
    require(path.suffix not in {'.rlib', '.rmeta', '.a', '.o', '.so', '.tar'} and not path.name.endswith('.tar.gz'),
            f'build/archive payload excluded: {path}')
    with path.open("rb") as stream:
        require(stream.read(4) != b"\x7fELF", f"binaries excluded from evidence archive: {path}")
    relative = resolved.relative_to(BASE) if resolved.is_relative_to(BASE) else Path("reproduction") / resolved.relative_to(REPO)
    require(not any(part in {"cache", "execution-cache", "native-cache", "tmp", "__pycache__", ".git"} for part in relative.parts), f"temporary/cache input excluded: {path}")
    require(not any(part in {'frozen-9b-link-inputs', 'frozen-candidate-link-inputs', 'baseline-source-guards'}
                    for part in relative.parts), f'frozen build/source payload excluded: {path}')
    return PREFIX + relative.as_posix()

class Evidence:
    def __init__(self, base=BASE):
        self.base = Path(base)
        self.paths = {}
        self.virtual = {}
        self.resources = []
        self.lossless_wrappers = {}
        self.lossless_sources = {}

    def add(self, path):
        path = Path(path)
        name = member_path(path)
        if path.resolve() == BASE / 'cargo-product.jsonl':
            return self.add_lossless_gzip(path, name)
        require(name not in self.paths or self.paths[name].resolve() == path.resolve(), f"conflicting archive name: {name}")
        self.paths[name] = path
        return name

    def add_lossless_gzip(self, path, logical_name):
        """Preserve every raw byte, while bounding historical producer archive size."""
        name = logical_name + '.gz'
        raw_bytes, raw_sha256 = path.stat().st_size, digest(path)
        existing = self.lossless_wrappers.get(logical_name)
        if existing is not None:
            require(existing['decoded_bytes'] == raw_bytes and existing['decoded_sha256'] == raw_sha256,
                    'historical raw Cargo transcript changed after lossless wrapping')
            return name
        require(logical_name not in self.paths and name not in self.paths and name not in self.virtual,
                'lossless wrapper conflicts with another evidence member')
        compressed = io.BytesIO()
        with path.open('rb') as raw, gzip.GzipFile(fileobj=compressed, mode='wb', filename='', mtime=0, compresslevel=6) as encoded:
            while chunk := raw.read(256 * 1024):
                encoded.write(chunk)
        data = compressed.getvalue()
        decoded = hashlib.sha256()
        length = 0
        with gzip.GzipFile(fileobj=io.BytesIO(data), mode='rb') as stream:
            while chunk := stream.read(256 * 1024):
                decoded.update(chunk); length += len(chunk)
                require(length <= raw_bytes, 'lossless Cargo wrapper expands beyond its raw source')
        require(length == raw_bytes and decoded.hexdigest() == raw_sha256
                and path.stat().st_size == raw_bytes and digest(path) == raw_sha256,
                'lossless Cargo wrapper did not preserve the original raw bytes')
        self.virtual[name] = data
        self.lossless_sources[name] = path
        self.lossless_wrappers[logical_name] = dict(logical_path=logical_name, archive_member=name,
            encoding='gzip', gzip_mtime=0, decoded_bytes=raw_bytes, decoded_sha256=raw_sha256,
            encoded_bytes=len(data), encoded_sha256=hashlib.sha256(data).hexdigest(),
            reproduction='Decompress the archive_member with gzip to recover the complete original logical_path; no rows or fields were removed.')
        return name

    def add_bytes(self, name, data):
        require(isinstance(data, bytes) and len(data) < 64 * 1024**2
                and not Path(name).is_absolute() and '..' not in Path(name).parts,
                'invalid generated provenance member')
        name = PREFIX + name
        require(name not in self.paths and (name not in self.virtual or self.virtual[name] == data),
                'conflicting generated provenance member')
        self.virtual[name] = data

    def resource(self, row, label):
        require(row.get("cpu_affinity") == [0], f"{label}: expected observed one-CPU affinity")
        require(str(row.get("memory.max")) == str(BUDGET) and str(row.get("memory.swap.max")) == "0", f"{label}: missing exact 4-GiB/no-swap cap")
        require(str(row.get("memory.oom.group")) == "1", f"{label}: missing grouped OOM policy")
        events = dict(line.split() for line in row.get("memory.events", "").splitlines())
        require(all(events.get(name) == "0" for name in ["oom", "oom_kill", "oom_group_kill"]), f"{label}: accepted receipt records OOM or missing observations")
        peak = int(row.get("memory.peak", -1))
        require(0 <= peak <= BUDGET, f"{label}: invalid cumulative cgroup peak")
        env = row.get("resource_environment", {})
        for name in ["CARGO_BUILD_JOBS", "SCRIPTW_JOBS", "RUST_TEST_THREADS", "RAYON_NUM_THREADS", "SCRIPTW_MODULE_MEMORY_CACHE_ENTRIES"]:
            require(env.get(name) == "1", f"{label}: nonserial or unbounded retained-cache environment")
        require(env.get("SCRIPTW_MODULE_MEMORY_CACHE_LIMIT_BYTES") == str(64 * 1024**2), f"{label}: cache image limit differs")
        completed_at = datetime.fromisoformat(row.get('date', ''))
        require(completed_at.utcoffset() is not None, f'{label}: actual completion timestamp lacks a timezone')
        self.resources.append({"label": label, "memory_peak_bytes": peak, "memory_events": events,
                               "cpu_affinity": row["cpu_affinity"], "completed_at": row['date']})

    def receipt(self, label, *, exit_code=0, checkout_source=None, clean_source=True):
        require(re.fullmatch(r"[A-Za-z0-9_-]+", label) is not None, "invalid receipt label")
        path = self.base / (label + ".json")
        row = read_json(path)
        require(row.get("label") == label and row.get("exit_code") == exit_code, f"{label}: actual receipt label/exit disagrees")
        checkout_source = candidate_source() if checkout_source is None else checkout_source
        require(row.get("source_head") == checkout_source, f"{label}: receipt checkout source differs")
        if clean_source:
            require(row.get("source_patch_sha256") == EMPTY_PATCH, f"{label}: product source was dirty")
        else:
            require(re.fullmatch(r"[0-9a-f]{64}", row.get("source_patch_sha256", "")) is not None, f"{label}: missing checkout patch observation")
        require(isinstance(row.get("command"), list) and row["command"], f"{label}: missing actual command")
        require(row.get("log") == label + ".log", f"{label}: log path differs")
        log = self.base / row["log"]
        require(digest(log) == row.get("log_sha256"), f"{label}: log hash differs")
        self.resource(row, label)
        self.add(path)
        self.add(log)
        return row, log.read_text(errors="replace")

def current_source():
    actual = subprocess.check_output(["git", "rev-parse", candidate_source() + "^{commit}"], cwd=REPO, text=True).strip()
    require(actual == candidate_source(), "candidate product source is unavailable")
    difference = subprocess.check_output(["git", "diff", "--binary", candidate_source(), "--", "crates", "Cargo.toml", "Cargo.lock"], cwd=REPO)
    require(difference == b"", "product inputs differ from the measured source commit")
    require(subprocess.check_output(["git", "ls-files", "--others", "--exclude-standard", "--", "crates", "Cargo.toml", "Cargo.lock"], cwd=REPO) == b"", "untracked product files are outside measured authority")

def inventory_names(log, *, allow_empty=False):
    names = sorted(re.findall(r"^([^\s]+): test$", log, re.M))
    require(len(set(names)) == len(names)
            and (bool(names) or allow_empty and re.findall(r'^0 tests, 0 benchmarks$', log, re.M) == ['0 tests, 0 benchmarks']),
            "native inventory is empty or repeated without an explicit zero-case target")
    return names

def observed_names(log):
    return [(name.removesuffix(" - should panic"), status) for name, status in re.findall(r"^test (.+) \.\.\. (ok|FAILED|ignored)$", log, re.M)]

def closed_native_log(row, log, inventory, *, filtered=0):
    observed = observed_names(log)
    require(sorted(name for name, _ in observed) == sorted(inventory) and all(status == "ok" for _, status in observed), f'{row["label"]}: native transcript lost, repeated, failed or ignored an identity')
    expected = [("ok", str(len(inventory)), "0", "0", "0", str(filtered))]
    require(SUMMARY_RE.findall(log) == expected and row.get("test_results") == [list(expected[0])], f'{row["label"]}: terminal counts do not reconcile to exact inventory')

def engine_native(evidence, scope, recorded):
    path = BASE / "engine-accepted.json"
    aggregate = read_json(path)
    manifest_path = BASE / "engine-batches.json"
    manifest = read_json(manifest_path)
    require(aggregate == recorded and aggregate.get("source_head") == candidate_source() and aggregate.get("source_patch_sha256") == EMPTY_PATCH, "engine aggregate source differs")
    require(aggregate.get("complete") is True and aggregate.get("exit_code") == 0 and manifest.get("complete") is True and manifest.get("source_head") == candidate_source(), "engine aggregate or exact batch manifest is incomplete")
    require("log" not in aggregate and "test_results" not in aggregate and "no synthetic single-process transcript" in aggregate.get("aggregation", ""), "engine observations must remain an explicit aggregate")
    inventory = manifest.get("inventory", [])
    require(inventory and sorted(set(inventory)) == inventory and aggregate.get("inventory") == inventory and aggregate.get("passed") == len(inventory), "engine denominator differs")
    enumerated, enumeration_log = evidence.receipt("engine-batches-inventory")
    require(enumerated["command"] == [manifest["binary"], "--list", "--include-ignored"] or Path(enumerated["command"][0]).resolve() == Path(manifest["binary"]).resolve() and enumerated["command"][1:] == ["--list", "--include-ignored"], "engine inventory invocation differs")
    require(inventory_names(enumeration_log) == inventory, "engine inventory does not match actual native enumeration")
    require(len(enumerated.get("executables", [])) == 1, "engine executable identity is missing")
    binary = enumerated["executables"]
    seen = []
    labels = []
    for index, batch in enumerate(manifest.get("batches", [])):
        label = f"engine-batch-{index:03d}"
        require(batch.get("label") == label and set(batch) == {"label", "inventory"}, "engine batch metadata differs")
        names = batch["inventory"]
        require(isinstance(names, list) and 1 <= len(names) <= 32 and len(set(names)) == len(names) and set(names).issubset(inventory), f"{label}: invalid bounded inventory")
        if any(name.startswith("runtime_profile::") or "capacity" in name or "inlining" in name for name in names):
            require(len(names) == 1, f"{label}: capacity/inlining/profile case was not isolated")
        row, log = evidence.receipt(label)
        require(Path(row["command"][0]).resolve() == Path(manifest["binary"]).resolve() and row["command"][1:] == names + ["--exact", "--test-threads=1", "--include-ignored"], f"{label}: exact-name invocation differs")
        require(row.get("executables") == binary, f"{label}: executed engine binary differs from complete enumeration")
        closed_native_log(row, log, names, filtered=len(inventory) - len(names))
        seen.extend(names)
        labels.append(label + ".json")
    require(sorted(seen) == inventory and len(set(seen)) == len(seen), "engine batch union omits or repeats native identities")
    require(aggregate.get("batch_manifest") == manifest_path.name, "engine aggregate names another manifest")
    evidence.receipt("engine-batches-build")
    for extra in [path, manifest_path]:
        evidence.add(extra)
    return {**scope, "passed": len(inventory), "inventory_sha256": hashlib.sha256(("\n".join(inventory) + "\n").encode()).hexdigest(), "verification": "exact disjoint bounded native process observations", "aggregate_receipt": path.name, "manifest": manifest_path.name, "batch_count": len(labels), "receipts": labels, "executables": binary}

def native(evidence):
    scopes = read_json(BASE / "native-scopes.json")
    closed = read_json(BASE / "native-closed.json")
    require([(s["package"], s["kind"], s["name"]) for s in scopes] == EXPECTED_SCOPES, "complete affected31-target inventory changed")
    require(closed.get("source") == candidate_source() and closed.get("complete") is True and len(closed.get("targets", [])) == len(scopes), "native target manifest is incomplete or stale")
    total, qualified, targets = 0, [], []
    for index, (scope, recorded) in enumerate(zip(scopes, closed["targets"])):
        if scope["package"] == "scriptw-engine" and scope["kind"] == "--lib":
            result = engine_native(evidence, scope, recorded)
            names = recorded["inventory"]
        else:
            label = f'broad-{index:02d}-{scope["package"]}-{scope["name"] or "lib"}'
            row, log = evidence.receipt(label)
            enumerated, enumeration_log = evidence.receipt(label + "-inventory")
            command = ["cargo", "test", "--locked", "--offline", "--release", "--jobs", "1", "-p", scope["package"], scope["kind"]]
            if scope["name"] is not None:
                command.append(scope["name"])
            require(row["command"] == command + ["--", "--test-threads=1", "--include-ignored"] and enumerated["command"] == command + ["--", "--list", "--include-ignored"], f"{label}: broad/inventory commands contain filters or changed policy")
            zero_case_target = scope == dict(package='scriptw-intl-build-data', kind='--lib', name=None)
            names = inventory_names(enumeration_log, allow_empty=zero_case_target)
            closed_native_log(row, log, names)
            require(row.get("executables") and row["executables"] == enumerated.get("executables"), f"{label}: enumerated and executed native binaries differ")
            inventory_sha = hashlib.sha256(("\n".join(names) + "\n").encode()).hexdigest()
            require(recorded == dict(row, **scope, inventory=names, inventory_sha256=inventory_sha), f"{label}: closed manifest differs from actual native evidence")
            result = {**scope, "passed": len(names), "inventory_sha256": inventory_sha, "run_receipt": label + ".json", "inventory_receipt": label + "-inventory.json", "executables": row["executables"]}
        total += len(names)
        qualified.extend(f'{scope["package"]}:{scope["kind"]}:{scope["name"] or "lib"}:{name}' for name in names)
        targets.append(result)
    require(total == closed.get("total") and len(qualified) == len(set(qualified)), "native totals or qualified identity union differs")
    for package in sorted({scope["package"] for scope in scopes}):
        label = next((value for value in [f"frozen-build-final-{package}", f"frozen-build-{package}"] if (BASE / (value + ".json")).is_file()), None)
        require(label is not None, f"missing final serial native build: {package}")
        row, _ = evidence.receipt(label)
        expected = ["cargo", "test", "--locked", "--offline", "--release", "--jobs", "1", "-p", package, "--no-run"]
        for scope in scopes:
            if scope["package"] == package:
                expected.append(scope["kind"])
                if scope["name"]:
                    expected.append(scope["name"])
        require(row["command"] == expected, f"{label}: native build omitted a selected target or changed policy")
    focused = []
    for label, planned_package, planned_target, planned_pattern in focused_checks():
        path = BASE / (label + '.json')
        row, log = evidence.receipt(path.stem)
        names = [name for name, status in observed_names(log) if status == "ok"]
        command = row["command"]
        require(command == ['cargo', 'test', '--locked', '--offline', '--release', '--jobs', '1', '-p', planned_package,
                            *planned_target, planned_pattern, '--', '--test-threads=1', '--include-ignored'],
                'actual focused command differs from the reviewed complete focused plan')
        package = command[command.index("-p") + 1]
        kind = next(flag for flag in ["--lib", "--test", "--example"] if flag in command)
        name = None if kind == "--lib" else command[command.index(kind) + 1]
        selected = next(item for item in closed["targets"] if (item["package"], item["kind"], item["name"]) == (package, kind, name))
        require(names and set(names).issubset(selected["inventory"]), f'{row["label"]}: focused identities are absent from the complete target')
        closed_native_log(row, log, names, filtered=len(selected["inventory"]) - len(names))
        focused.append({"receipt": path.name, "passed": len(names), "overlaps_complete_targets": True, "added_to_total": False})
    for path in [BASE / "native-scopes.json", BASE / "native-closed.json"]:
        evidence.add(path)
    return {"complete": True, "target_count": len(targets), "passed": total, "failed": 0, "ignored": 0,
            "nonempty_target_count": sum(row['passed'] > 0 for row in targets),
            "zero_case_targets": [dict(package=row['package'], kind=row['kind'], name=row['name'])
                                  for row in targets if row['passed'] == 0],
            "inventory_sha256": hashlib.sha256(("\n".join(sorted(qualified)) + "\n").encode()).hexdigest(), "targets": targets, "focused": focused}

def selected_scopes(evidence, summary, batches):
    plan_path = BASE / 'selected-scopes.json'
    plan = read_json(plan_path)
    controls_path = BASE / 'selected.ids'
    controls = controls_path.read_text().splitlines()
    require(plan.get('complete') is True and plan.get('selected_total') == 13862
            and plan.get('source_inventory_reused_for_scope_planning_only') is True
            and plan.get('require_current_compiler_inventory_exact_match_before_execution') is True,
            'scope plan lost its planning-only/current-admission boundary')
    require(len(controls) == len(set(controls)) == 13862 and controls == sorted(controls),
            'exact sorted13862-execution input changed')
    replay = BASE / 'conformance'
    inventory = summary['native_inventory']
    require(inventory.get('command') == [summary['binary'], '--jobs', '1', 'test262', 'list-all',
                                       '--suite-root', summary['suite_root']], 'final inventory command differs')
    inventory_path = replay / inventory['stdout']
    require(Path(inventory['stdout']).name == inventory['stdout']
            and digest(inventory_path) == inventory.get('stdout_sha256'), 'final native inventory hash differs')
    current = batches.native_inventory(inventory_path.read_text())
    require(len(current) == plan.get('source_inventory_execution_count') == 102994
            and digest(inventory_path) == plan.get('source_inventory_sha256'),
            'final full pinned inventory differs from planning authority')
    precheck_path = BASE / 'conformance-inventory-validated.json'
    precheck = read_json(precheck_path)
    enumerated, enumeration_log = evidence.receipt('conformance-inventory-final')
    require(enumerated['command'] == [str(BASE / 'candidate/scriptw'), '--jobs', '1', 'test262',
            'list-all', '--suite-root', 'test262/vendor/test262'], 'pre-execution compiler inventory differs')
    require(digest(BASE / enumerated['log']) == digest(inventory_path)
            and batches.native_inventory(enumeration_log) == current, 'precheck/replay inventories disagree')
    expected_precheck = dict(complete=True, source_head=candidate_source(), compiler_identity=summary['compiler_identity'],
        receipt='conformance-inventory-final.json', inventory_sha256=digest(inventory_path), total=len(current),
        selected_total=len(controls), selected_ids_sha256=digest(controls_path), scope_plan_sha256=digest(plan_path))
    require(precheck == expected_precheck, 'pre-execution inventory admission changed')
    from campaign import PREFIXES
    require([row['prefix'] for row in plan['scopes']] == PREFIXES, 'complete affected family plan changed')
    union, scopes = set(), []
    for scope in plan['scopes']:
        prefix = scope['prefix']
        actual = sorted(value for value in current if value.split(':', 1)[1].startswith(prefix))
        require(actual == sorted(scope['execution_ids']) and len(actual) == scope['count']
                , 'final selected family omits or adds cases: ' + prefix)
        union.update(actual)
        scopes.append({'prefix': prefix, 'count': len(actual)})
    require(set(plan['known_failure_controls']) == KNOWN and len(plan['known_failure_controls']) == 4,
            'known failure controls changed')
    union.update(KNOWN)
    require(union == set(controls), 'selected families/controls do not exactly form all requested IDs')
    for path in [plan_path, controls_path, inventory_path, precheck_path]:
        evidence.add(path)
    return controls, dict(complete=True, pre_execution_admission=precheck,
        final_full_inventory_sha256=digest(inventory_path), final_full_inventory_total=len(current),
        scopes=scopes, known_failure_controls=sorted(KNOWN), execution_ids_sha256=digest(controls_path))

def performance(evidence, product_report):
    module_path = BASE / "analyze.py"
    spec = importlib.util.spec_from_file_location("execution_performance_analysis", module_path)
    analysis = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(analysis)
    require(callable(getattr(analysis, "build_report", None)), "analysis tool must expose read-only build_report()")
    actual = analysis.build_report()
    path = BASE / "analysis.json"
    require(read_json(path) == actual and actual.get("complete") is True and actual.get("round_order") == ROUNDS, "comparison summary differs from validated actual observations")
    require(len(actual.get("cases", [])) == 17, "balanced comparison did not finish all17 exact workloads")
    rows = []
    for index, label in enumerate(ROUNDS):
        product = "baseline" if index in [0, 3] else "candidate"
        report = read_json(BASE / label / "report.json")
        identity = product_report[product]["compiler_identity"]
        require(report.get("compiler_identity") == identity and report.get("runtime_runner_sha256") == product_report[product]["runtime_runner_sha256"], f"{label}: measured binary/source identity differs")
        receipt_label = label.removesuffix("-data")
        receipt, _ = evidence.receipt(receipt_label)
        require(report.get("samples") == 7 and report.get("warmups") == 10 and report.get("complete") is True, f"{label}: incomplete sample/warmup policy")
        for item in (BASE / label).iterdir():
            if item.is_file() and (item.name == "report.json" or item.suffix in {".stdout", ".stderr"}):
                evidence.add(item)
            elif item.is_dir() and item.name.endswith("-wasm"):
                for artifact in item.iterdir():
                    require(artifact.is_file() and artifact.suffix == ".wasm", "unexpected measured artifact member")
                    evidence.add(artifact)
    for case in actual["cases"]:
        before = case["pooled"]["baseline"]["wasmtime"]["median_execution_ns"]
        after = case["pooled"]["candidate"]["wasmtime"]["median_execution_ns"]
        v8 = case["pooled"]["candidate"]["v8"]["median_execution_ns"]
        rows.append({"file": case["file"], "baseline_ms": before / 1e6, "candidate_ms": after / 1e6, "change_percent": 100 * (after / before - 1), "paired_candidate_v8_ms": v8 / 1e6, "candidate_over_paired_v8": after / v8})
    for extra in [module_path, path, REPO / "crates/scriptw-cli/tests/fixtures/v8_baseline/node-runtime.cjs"]:
        evidence.add(extra)
    for extra in analysis.evidence_files():
        evidence.add(extra)
    fixtures = REPO / "crates/scriptw-cli/tests/fixtures/v8_execution_hotpaths"
    for path in fixtures.iterdir():
        require(path.is_file() and path.suffix in {".js", ".json"}, "unexpected workload fixture member")
        evidence.add(path)
    return {"complete": True, "balanced_observations": actual, "table": rows, "rss_table": ordinary_rss_table(actual),
            "rss_table_statistic": "Median of the14 validated post-execution process endpoints per product/runtime: Wasmtime final sampler read while Store remains alive; V8 after-execution snapshot while context remains alive. Before/after are9b/actual candidate; V8 is paired with the candidate. Not live JS heap or whole-child high-water RSS.",
            "table_statistic": "median of14 measured samples per product, pooled from two fresh process rounds of7 measured samples after10 warmups each; per-round medians and adjacent comparisons retained", "policy": "unchanged default Fast P and optimized Portable R, 16-MiB initial GC capacity; one CPU, fresh Store/Realm or V8 context; execution+completion includes construction and checksums", "interpretation": "descriptive paired measurements, not a statistical significance test or a universal V8-parity claim", "ambient_load_limit": "unrelated CPU-active processes and desktop activity were observed on the shared host; loadavg start/end is retained for every round; this is not an otherwise-idle or isolated causal measurement and cannot certify idle-machine repeatability", "historical_readme_graph_refreshed": False}

def ordinary_rss_table(analysis):
    """Rederive endpoint medians from the admitted fresh-analysis value arrays."""
    cases = analysis['cases']
    require(len(cases) == len({case['file'] for case in cases}) == 17,
            'ordinary RSS table requires all17 unique fresh cases')
    rows = []
    for case in cases:
        values = {}
        for name, product, runtime, field in [
            ('baseline_rss_bytes', 'baseline', 'wasmtime', 'final_rss_bytes'),
            ('candidate_rss_bytes', 'candidate', 'wasmtime', 'final_rss_bytes'),
            ('paired_candidate_v8_rss_bytes', 'candidate', 'v8', 'rss_after_execution_bytes'),
        ]:
            summary = case['pooled'][product][runtime]['memory_observations'][field]
            observed = summary['values']
            require(len(observed) == 14 and all(type(value) is int and 0 < value <= BUDGET for value in observed)
                    and median(observed) == summary['median'], 'ordinary endpoint RSS values/median differ')
            values[name] = median(observed)
        rows.append(dict(file=case['file'], **values))
    return rows

def performance_calls(evidence, product_report):
    """Keep callback-delimited calls separate from ordinary entry execution."""
    sys.path.insert(0, str(BASE))
    module_path = BASE / "analysis_calls.py"
    spec = importlib.util.spec_from_file_location("execution_performance_call_analysis", module_path)
    analysis = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(analysis)
    actual = analysis.build_report()
    path = BASE / "analysis_calls.json"
    require(read_json(path) == actual, "existing-Realm comparison differs from actual checked sessions")
    require(actual.get("schema") == "scriptw-execution-same-realm-comparison-v1" and actual.get("complete") is True and actual.get("round_order") == CALL_ROUNDS, "existing-Realm ABBA cohort is partial, reordered or mislabeled")
    require(actual.get("case_count") == 17 and actual.get("samples_per_session") == 7 and actual.get("guest_warmups") == 10 and actual.get("sessions_per_product") == 2 and actual.get("pooled_samples_per_product") == 14, "existing-Realm session/call/warmup denominator changed")
    fixtures = REPO / "crates/scriptw-cli/tests/fixtures/v8_execution_hotpaths"
    expected_cases = read_json(fixtures / "manifest.json")["execution"]
    require([case["file"] for case in actual["cases"]] == [case["file"] for case in expected_cases], "existing-Realm cohort does not preserve the exact17 original workloads")
    for index, label in enumerate(CALL_ROUNDS):
        product = "baseline" if index in [0, 3] else "candidate"
        round_report = read_json(BASE / label / "report.json")
        require(round_report.get("compiler_identity") == product_report[product]["compiler_identity"] and round_report.get("runtime_boundaries_sha256") == product_report[product]["runtime_boundaries_sha256"], f"{label}: callback observer product/source differs from frozen authority")
        receipt, _ = evidence.receipt(label.removesuffix("-data"))
        command = receipt["command"]
        require(any(Path(part).name == "measure_calls.py" for part in command) and product in command and label in command, f"{label}: actual call measurement command differs")
    rows = []
    for case in actual["cases"]:
        require(case["original_source_sha256"] == digest(fixtures / case["file"]), "existing-Realm original workload source changed")
        before = case["pooled"]["baseline"]["wasmtime"]["median_ns"]
        after = case["pooled"]["candidate"]["wasmtime"]["median_ns"]
        v8 = case["pooled"]["candidate"]["v8"]["median_ns"]
        rows.append({"file": case["file"], "baseline_ms": before / 1e6, "candidate_ms": after / 1e6, "change_percent": 100 * (after / before - 1), "paired_candidate_v8_ms": v8 / 1e6, "candidate_over_paired_v8": after / v8})
    evidence.add(path)
    for extra in analysis.evidence_files():
        evidence.add(extra)
    return {"complete": True, "balanced_observations": actual, "table": rows, "table_statistic": "median of14 elapsed callback intervals per product, pooled from two existing-Realm sessions of7 calls after10 guest warmups each", "measurement": "elapsed wall time between actual callback exit/entry timestamps; not a measured CPU clock; includes workload construction/checksum and marker overhead; excludes setup/bootstrap, warmups, checksum printing, bundle/cache admission and native compilation; no empty subtraction", "source_cohort": "separate generated wrapper: original workload IIFE body becomes batch(seed), sole final print expression becomes return expression; original inputs and explicit String(checksum) conversions retained; exact result checked outside every interval", "archive_exclusions": "session Portable P/R bundles, V8 cachedData, executables and native caches excluded; actual payload hashes/framing, regeneration commands, transformed sources and harness snapshots retained", "ambient_load_limit": "shared-host CPU/desktop activity and raw load averages retained; descriptive observations cannot certify idle-machine repeatability, causal significance or universal V8 parity"}

def pinned_fixtures(summary, controls):
    """Bind observed fixture SHA-256s to blobs in the exact pinned Git tree."""
    pins_path = REPO / "crates/scriptw-test262/src/source-pins.json"
    pins = read_json(pins_path)
    tree = subprocess.check_output(["git", "rev-parse", candidate_source() + ":test262/vendor/test262"], cwd=REPO, text=True).strip()
    require(tree == pins["test262_tree"], "source commit does not contain the pinned Test262 tree")
    paths = {execution.split(":", 1)[1] for execution in controls}
    require(set(summary.get("fixture_sha256", {})) == paths, "fixture digest inventory does not cover exactly the requested paths")
    tree_entries = subprocess.check_output(["git", "ls-tree", "-r", "-z", candidate_source() + ":test262/vendor/test262/test"], cwd=REPO)
    blobs = {}
    for entry in tree_entries.split(b"\0"):
        if not entry: continue
        header, name = entry.split(b"\t", 1)
        name = name.decode()
        if name in paths:
            _, kind, oid = header.split()
            require(kind == b"blob", "requested fixture is not a pinned Git blob")
            blobs[name] = oid.decode()
    require(set(blobs) == paths, "requested fixture is missing from the pinned tree")
    ordered = sorted(blobs)
    process = subprocess.run(["git", "cat-file", "--batch"], input=("\n".join(blobs[name] for name in ordered) + "\n").encode(), stdout=subprocess.PIPE, stderr=subprocess.PIPE, cwd=REPO, check=True)
    content, offset = process.stdout, 0
    for name in ordered:
        end = content.index(b"\n", offset)
        oid, kind, length = content[offset:end].split()
        require(oid.decode() == blobs[name] and kind == b"blob", "Git returned another fixture object")
        start, size = end + 1, int(length)
        data = content[start:start + size]
        require(len(data) == size and content[start + size:start + size + 1] == b"\n", "pinned fixture batch is truncated")
        require(hashlib.sha256(data).hexdigest() == summary["fixture_sha256"][name], f"observed fixture differs from pinned Git bytes: {name}")
        offset = start + size + 1
    require(offset == len(content), "unexpected trailing Git fixture data")
    return {"source_tree": tree, "fixture_count": len(paths), "fixture_hashes": summary["fixture_sha256"]}

def cargo_products(path):
    rows, finished = {}, []
    names = {'scriptw', 'runtime_baseline', 'runtime_boundaries'}
    require(path.stat().st_size < 64 * 1024**2, 'Cargo product transcript exceeds publication budget')
    for line in path.read_text().splitlines():
        row = json.loads(line)
        if row.get('reason') == 'build-finished':
            finished.append(row.get('success'))
        if row.get('reason') != 'compiler-artifact' or not row.get('executable'):
            continue
        name = Path(row['executable']).name
        if name not in names:
            continue
        require(name not in rows, 'duplicate final Cargo executable: ' + name)
        kind = 'bin' if name == 'scriptw' else 'example'
        require(row.get('features') == [] and row['profile']['opt_level'] == '3'
                and row['profile']['test'] is False and row['target']['name'] == name
                and kind in row['target']['kind']
                and Path(row['manifest_path']).resolve() == REPO / 'crates/scriptw-cli/Cargo.toml',
                'Cargo executable lacks its actual ordinary default-feature release producer: ' + name)
        rows[name] = row
    require(finished == [True] and set(rows) == names, 'Cargo product build omitted/failed an ordinary executable')
    return rows

def additional_observations(evidence):
    extra = []
    accepted = {path.resolve() for path in evidence.paths.values()}
    for log in sorted(BASE.glob('*.log')):
        if log.resolve() in accepted:
            continue
        receipt_path = log.with_suffix('.json')
        item = {'log': log.name, 'log_sha256': digest(log),
                'included_in_accepted_totals': False}
        if receipt_path.is_file():
            receipt = read_json(receipt_path)
            require(receipt.get('log') == log.name and receipt.get('log_sha256') == digest(log),
                    'extra diagnostic receipt/transcript differs: ' + log.name)
            item.update(status='terminal-observation-outside-accepted-inputs',
                        actual_receipt=receipt)
            evidence.add(receipt_path)
        else:
            item['status'] = 'partial-observation-without-terminal-receipt'
        evidence.add(log)
        extra.append(item)
    return {'observations': extra, 'interpretation': 'Actual additional/partial/failing observations are preserved under their original identities. They do not enter accepted native/performance totals or acquire retroactive kernel-resource claims.'}

def conformance(evidence):
    """Derive every actual selected outcome; never manufacture a pass total."""
    sys.path.insert(0, str(REPO / 'scripts'))
    import test262_execution_batches as batches
    replay = BASE / 'conformance'
    summary = read_json(replay / 'summary.json')
    controls, scopes = selected_scopes(evidence, summary, batches)
    identity = summary['compiler_identity']
    require(identity == read_json(BASE / 'candidate/identity.json')
            and identity['source_revision'] == {'kind': 'git-commit', 'commit': candidate_source()}, 'conformance compiler differs')
    results = summary.get('results', [])
    require(summary.get('complete') is not False and len(results) == len(controls) == 13862
            and len({row['execution_id'] for row in results}) == len(results)
            and {row['execution_id'] for row in results} == set(controls), 'actual selected results are incomplete')
    counts = Counter(row['outcome'] for row in results)
    require(set(counts) <= {'Success', 'Bug', 'Crash', 'NotImplemented'}, 'unknown selected outcome')
    outcomes = {name: counts[name] for name in ['Success', 'Bug', 'Crash', 'NotImplemented']}
    unexpected = [row['execution_id'] for row in results if row['outcome'] != 'Success' and row['execution_id'] not in KNOWN]
    require(not unexpected, 'actual selected replay has new non-success executions; preserve and investigate before scoring')
    require(summary.get('outcomes') == outcomes and summary.get('total') == len(controls)
            and summary.get('replay_mode') == 'native-execution-list-v1'
            and summary.get('absent_executions') == [] and summary.get('batch_threads') == 1
            and sorted(summary.get('batch_executions', [])) == controls,
            'selected aggregate is not its actual exact result union')
    actual_exit = 0 if outcomes['Success'] == len(controls) else 1
    receipt, _ = evidence.receipt('conformance-final', exit_code=actual_exit)
    command = receipt['command']
    require('--workers' in command and command[command.index('--workers') + 1] == '1'
            and '--reuse-case-workers' in command
            and any(Path(part).name == 'replay-test262-executions.py' for part in command)
            and any(Path(part).resolve() == BASE / 'selected.ids' for part in command),
            'actual replay launcher changed source, serial workers or native worker reuse')
    binary = Path(summary['binary'])
    require(binary.resolve().is_relative_to(replay.resolve())
            and digest(binary) == summary['binary_sha256'] == identity['executable_sha256'], 'replayed binary differs')
    require((replay / 'executions').read_bytes() == (BASE / 'selected.ids').read_bytes()
            and digest(replay / 'executions') == summary['execution_list_sha256'], 'frozen selected list differs')
    fixtures = pinned_fixtures(summary, controls)
    options = types.SimpleNamespace(output_dir=replay)
    snapshots, invocations = {}, {}
    for row in results:
        require(row.get('protocol') == 'native-execution-list-v1' and 'infrastructure_error' not in row,
                'selected verdict lacks completed native evidence')
        batches.verify_saved_result(row, summary, options, snapshots)
        require(row['exit_code'] == (0 if row['outcome'] == 'Success' else 1), 'result exit differs from verdict')
        path = replay / (hashlib.sha256(row['execution_id'].encode()).hexdigest() + '.json')
        require(read_json(path) == row, 'individual result differs from actual summary')
        evidence.add(path)
        for name in [row['transcript'], row['native_snapshot']['path'], row['invocation']]:
            require(Path(name).name == name, 'selected evidence path escaped its directory')
            evidence.add(replay / name)
        invocation_path = replay / row['invocation']
        if invocation_path not in invocations:
            invocation = read_json(invocation_path)
            args = invocation['command']
            require(invocation['exit_code'] in [0, 1] and 'run-list' in args and '--threads' in args
                    and args[args.index('--threads') + 1] == '1' and '--timeout-ms' in args
                    and args[args.index('--timeout-ms') + 1] == '60000', 'native replay worker/deadline differs')
            for stream in ['stdout', 'stderr']:
                raw = batches.owned_file(options, invocation[stream])
                require(digest(raw) == invocation[stream + '_sha256'], 'native invocation stream changed')
                evidence.add(raw)
            invocations[invocation_path] = invocation
    pins = read_json(REPO / 'crates/scriptw-test262/src/source-pins.json')
    timeout_ids, failures = set(), []
    for path in snapshots:
        snapshot = read_json(path)
        require(snapshot['pinned_revisions'] == {'ecma262': pins['ecma262'], 'test262': pins['test262_tree']},
                'actual selected snapshot changed suite pins')
        timeout_ids.update(snapshot.get('timeout_test_ids', []))
        failures.extend(snapshot.get('failures', []))
    require(not timeout_ids, 'selected execution has actual timeouts; preserve evidence before resolving them')
    for name in ['summary.json', 'run.json', 'executions', 'batch-executions', 'compiler-identity.stdout',
                 'compiler-identity.stderr', 'native-inventory.stderr']:
        evidence.add(replay / name)
    require(read_json(replay / 'run.json')['compiler_identity'] == identity
            and digest(replay / 'batch-executions') == summary['batch_execution_list_sha256'],
            'actual native replay identity/list changed')
    unique_failures = {json.dumps(row, sort_keys=True): row for row in failures}
    reference = known_failure_authority(evidence)
    actual_signatures = sorted({(row['test_id'], row['kind'], row['outcome'], row['detail_hash']) for row in unique_failures.values()})
    require([list(row) for row in actual_signatures] == reference['signatures']
            and outcomes == {'Success': len(controls)-4, 'Bug': 4, 'Crash': 0, 'NotImplemented': 0},
            'actual known failure kind/detail signatures or outcomes differ from published44e authority')
    return dict(complete=True, total=len(results), passed=outcomes['Success'], bug=outcomes['Bug'],
                crash=outcomes['Crash'], not_implemented=outcomes['NotImplemented'], timeout=len(timeout_ids),
                outcomes=outcomes, actual_command_exit=receipt['exit_code'], scope=scopes,
                execution_ids=controls, compiler_identity=identity, pinned_fixtures=fixtures,
                failures=list(unique_failures.values()),
                known_failure_reference=reference,
                original_control_outcomes={row['execution_id']: row['outcome'] for row in results
                                           if row['execution_id'] in KNOWN},
                additional_non_success_executions=[row['execution_id'] for row in results
                                                  if row['outcome'] != 'Success' and row['execution_id'] not in KNOWN],
                native_snapshots=[dict(path=str(path.relative_to(BASE)), sha256=digest(path)) for path in snapshots],
                invocations=list(invocations.values()), full_test262_chart_refreshed=False,
                interpretation='Complete actual selected-family results, not a full pinned Test262 refresh; '
                               'all verdicts are rederived from actual native snapshots and saved execution receipts.')

def checked_u64(value):
    require(type(value) is int and 0 <= value < 2**64, 'invalid finite unsigned allocation/RSS counter')
    return value

def diagnostic(evidence, product, product_report):
    sys.path.insert(0, str(BASE))
    sys.path.insert(0, str(REPO / 'scripts'))
    from process_memory_maps import parse_smaps
    name = 'candidate_engine_allocation_diagnostic'
    if product == 'baseline':
        directory = PRIOR / 'candidate-engine-allocation-probe'
        inputs = read_json(PRIOR / 'frozen-candidate-link-inputs.json')
        admitted = read_json(CHECKPOINT)['execution_allocation_diagnostic']['products']['candidate']
        require(digest(directory / 'report.json') == admitted['report']['sha256']
                and digest(PRIOR / 'frozen-candidate-link-inputs.json') == admitted['frozen_inputs']['sha256'],
                'closed44e baseline allocation authority changed')
        engine = PRIOR / inputs['engine_rlib']
        module = types.SimpleNamespace(PHASES=PHASES)
    else:
        module = importlib.import_module(name)
        inputs, engine = module.validate_inputs()
        directory = BASE / 'candidate-engine-allocation-probe'
    path = directory / 'report.json'
    report = read_json(path)
    identity = product_report[product]['compiler_identity']
    require(report.get('schema') == 'scriptw-engine-allocation-link-v1' and report.get('complete') is True
            and report.get('executed') is True and report.get('cpu_affinity') == [0]
            and report['source_commit'] == identity['source_revision']['commit']
            and report['source_fingerprint'] == identity['source_fingerprint'], 'allocation helper source/completion differs')
    source = ALLOCATION_HELPER
    driver = (PRIOR if product == 'baseline' else BASE) / (name + '.py')
    require(report['helper_source'] == dict(path=str(source), sha256=digest(source))
            and report['driver'] == dict(path=str(driver), sha256=digest(driver)), 'closed allocation source/driver changed')
    manifest = (PRIOR if product == 'baseline' else BASE) / 'frozen-candidate-link-inputs.json'
    require(report['frozen_inputs'] == dict(path=str(manifest), sha256=digest(manifest), **inputs),
            'actual frozen diagnostic inputs differ')
    require(tuple(module.PHASES) == PHASES and len(report['commands']) == 2, 'allocation protocol changed')
    binary = Path(report['binary']['path'])
    require(binary == directory / 'engine_allocation_diagnostic' and binary.stat().st_size == report['binary']['bytes']
            and digest(binary) == report['binary']['sha256'], 'actual allocation helper ELF changed')
    expected_compile = [report['rustc']['invoker_path'], '--edition=2021', '--crate-name=scriptw_engine_allocation_diagnostic',
                        '--crate-type=bin', '-Copt-level=3', '-Cdebuginfo=0', '-Ccodegen-units=1',
                        '-Ldependency=' + str(engine.parent)]
    expected_compile += ['-Lnative=' + str((PRIOR if product == 'baseline' else BASE) / item) for item in inputs['native_search_paths']]
    expected_compile += ['--extern', 'scriptw_engine=' + str(engine), str(source), '-o', str(binary)]
    for event, expected in zip(report['commands'], [[report['rustc']['invoker_path'], '-vV'], expected_compile]):
        require(event['command'] == expected and event['cwd'] == str(REPO)
                and event['state'] == 'closed' and event['exit_code'] == 0 and event['timed_out'] is False,
                'actual diagnostic link/version command differs')
        for stream in ['stdout', 'stderr']:
            raw = directory / event[stream + '_file']
            require(raw.parent == directory and digest(raw) == event[stream + '_sha256'], 'diagnostic command stream changed')
            evidence.add(raw)
    require((directory / 'rustc-version.stdout').read_text() == report['rustc']['version'], 'diagnostic rustc version differs')
    require([case['case'] for case in report['cases']] == ['scalar', 'print', 'retained'], 'diagnostic case inventory differs')
    cases, count = [], 0
    for case in report['cases']:
        case_name = case['case']
        expected = list(PHASES) if case_name != 'scalar' else [phase for phase in PHASES if not phase.startswith('guest_')]
        require(case['state'] == 'closed' and case['exit_code'] == 0 and case['command'] == [str(binary), case_name],
                'actual allocation case failed/changed command')
        observation = case['observation']
        require(observation['schema'] == 'scriptw-engine-requested-allocation-diagnostic-v1'
                and observation['case'] == case_name and observation['compiler_source'] == report['source_commit']
                and observation['source_fingerprint'] == report['source_fingerprint']
                and observation['helper_executable_sha256'] == report['binary']['sha256']
                and observation['invocations'] == 2 and observation['linked_runtime'] == (case_name != 'scalar'),
                'actual allocation helper/body identity differs')
        require([row['phase'] for row in observation['snapshots']] == expected
                and [row['phase'] for row in case['snapshots']] == expected, 'allocation/maps boundaries differ')
        stdout, stderr = directory / case_name / 'stdout.log', directory / case_name / 'stderr.log'
        require(digest(stdout) == case['stdout_sha256'] and digest(stderr) == case['stderr_sha256'],
                'actual allocation case stream changed')
        lines = stdout.read_text().splitlines()
        require(lines[:-1] == ['SNAP ' + phase for phase in expected] and lines[-1].startswith('RESULT ')
                and json.loads(lines[-1][7:]) == observation, 'raw callbacks/final result differ')
        evidence.add(stdout)
        evidence.add(stderr)
        phases = []
        previous = None
        for counters, mapping in zip(observation['snapshots'], case['snapshots']):
            for field in COUNTERS:
                checked_u64(counters[field])
            require(counters['total_successful_request_bytes'] - counters['total_released_request_bytes']
                    == counters['requested_live_bytes']
                    and counters['peak_tracked_requested_live_bytes'] >= counters['requested_live_bytes']
                    and counters['interval_peak_tracked_requested_live_bytes'] >= counters['requested_live_bytes'],
                    'actual requested/released/live/peak counters do not reconcile')
            if previous is not None:
                require(all(counters[field] >= previous[field] for field in COUNTERS
                            if field not in ['requested_live_bytes', 'interval_peak_tracked_requested_live_bytes']),
                        'cumulative allocation counters decreased')
            previous = counters
            cache = counters['module_cache']
            require(cache['entry_limit'] == 1 and cache['image_byte_limit'] == 64 * 1024**2
                    and 0 <= cache['retained_entries'] <= 1 and 0 <= cache['retained_image_bytes'] <= 64 * 1024**2,
                    'actual diagnostic cache policy changed')
            raw = directory / mapping['raw']
            require(raw.resolve().is_relative_to(directory.resolve()) and digest(raw) == mapping['raw_sha256'],
                    'raw smaps path/hash changed')
            parsed = parse_smaps(raw.read_text())
            require(all(mapping[field] == parsed[field] for field in ['scope', 'totals', 'groups', 'mappings']),
                    'saved smaps differs from actual raw mapping counters')
            evidence.add(raw)
            phases.append(dict(phase=counters['phase'], allocation=counters, residency=parsed['totals'],
                               groups=parsed['groups'], raw_smaps=member_path(raw), raw_smaps_sha256=digest(raw)))
            count += 1
        cases.append(dict(case=case_name, phases=phases, program_wasm_bytes=observation['program_wasm_bytes'],
                          runtime_wasm_bytes=observation['runtime_wasm_bytes'], linked_runtime=observation['linked_runtime'],
                          counter_scope=observation['counter_scope'], peak_scope=observation['peak_scope']))
    require(count == 35, 'each actual helper must contain all35 closed allocation/residency pairs')
    if product == 'candidate':
        outer, _ = evidence.receipt('allocation-diagnostic-candidate')
    else:
        original = Evidence(PRIOR)
        outer, _ = original.receipt('allocation-diagnostic-candidate', checkout_source=BASELINE_SOURCE)
        for item in original.paths.values(): evidence.add(item)
    require(Path(outer['command'][-2]).resolve() == driver and outer['command'][-1] == '--run',
            'actual allocation outer command differs')
    for item in [path, manifest, driver, source]: evidence.add(item)
    # All large rlibs/native archives/ELFs remain hash-only. Cargo producers and
    # input hashes are already retained in these closed report/manifest files.
    return dict(complete=True, source_commit=report['source_commit'], source_fingerprint=report['source_fingerprint'],
                helper_executable_sha256=report['binary']['sha256'], helper_source_sha256=digest(source),
                driver_sha256=digest(driver), report=dict(path=member_path(path), sha256=digest(path)),
                frozen_inputs=dict(path=member_path(manifest), sha256=digest(manifest), engine_rlib_sha256=inputs['engine_rlib_sha256']),
                phase_count=count, outer_resource_receipt=outer,
                outer_resource_scope='Actual original closed baseline receipt; excluded from new campaign resource aggregate.' if product == 'baseline' else 'Actual new candidate closed receipt.', cases=cases)

def allocation_comparison(evidence, product_report):
    products_ = {role: diagnostic(evidence, role, product_report) for role in ['baseline', 'candidate']}
    require(products_['baseline']['helper_source_sha256'] == products_['candidate']['helper_source_sha256'],
            'comparison does not use byte-identical helper body/callbacks')
    comparisons = []
    for before, after in zip(products_['baseline']['cases'], products_['candidate']['cases']):
        require(before['case'] == after['case'], 'allocation comparison case changed')
        phases = []
        for a, b in zip(before['phases'], after['phases']):
            require(a['phase'] == b['phase'], 'allocation comparison phase changed')
            values = {}
            for field, old, new in [
                ('requested_live_bytes', a['allocation']['requested_live_bytes'], b['allocation']['requested_live_bytes']),
                ('peak_tracked_requested_live_bytes', a['allocation']['peak_tracked_requested_live_bytes'], b['allocation']['peak_tracked_requested_live_bytes']),
                ('rss_bytes', a['residency']['rss_bytes'], b['residency']['rss_bytes']),
                ('pss_bytes', a['residency']['pss_bytes'], b['residency']['pss_bytes']),
            ]:
                values[field] = dict(baseline=old, candidate=new, delta=new - old,
                                     change_percent=(new / old - 1) * 100 if old else None)
            phases.append(dict(phase=a['phase'], metrics=values))
        comparisons.append(dict(case=before['case'], phases=phases))
    return dict(schema='scriptw-engine-allocation-comparison-v1', complete=True, products=products_,
                paired_phase_count=35, raw_snapshot_count=70, cases=comparisons,
                scope='One distinct standalone helper process per product/case, two invocations, identical source/callbacks; '
                      'diagnostic requested Rust bytes and acknowledged process residency, not ordinary performance scores.',
                caveats=['Requested Rust GlobalAlloc sizes exclude allocator usable/resident bytes and native allocations bypassing GlobalAlloc.',
                         'Anonymous mappings do not identify live JavaScript or Intl ownership; no exact causal subtraction between counters.',
                         'Private file-backed native mappings change residency/reclaimability; cold-file/page-cache state and shared pages affect RSS/PSS.',
                         'Baseline retains its original actual44e outer receipt; no baseline run is relabelled as the new source.',
                         'Diagnostic module cache is one entry/64MiB; default SDK512MiB retention differs.',
                         'Native perf-map hashing is disabled. RSS/capacity/virtual address space, logical requested peaks and guest live memory remain distinct.'])

def allocation_markdown(report):
    lines = ['# Fixed runtime allocation diagnostic comparison', '', report['scope'], '',
             'Each value is MiB (1,048,576 bytes). Every phase pair comes from the actual closed helper reports; '
             'this table is separate from ordinary README benchmark scores.', '',
             '| Case / phase | Requested Rust live before → after | Process RSS before → after | RSS change |',
             '| --- | ---: | ---: | ---: |']
    for case in report['cases']:
        for phase in case['phases']:
            live, rss = phase['metrics']['requested_live_bytes'], phase['metrics']['rss_bytes']
            lines.append(f"| {case['case']} / {phase['phase']} | {live['baseline']/2**20:.3f} → {live['candidate']/2**20:.3f} | "
                         f"{rss['baseline']/2**20:.3f} → {rss['candidate']/2**20:.3f} | {rss['change_percent']:+.2f}% |")
    lines += ['', 'The complete 35 phase pairs retain raw smaps, coherent requested/released/live counters, both invocations, '
              f"source/rlib/helper hashes and all commands. Baseline source is {report['products']['baseline']['source_commit']}; "
              f"candidate source is {report['products']['candidate']['source_commit']}. "
              'The helper source is byte-identical. All reductions remain observational; the counters do not by themselves '
              'assign each saved page or allocation to a component.', '']
    lines.extend('- ' + caveat for caveat in report['caveats'])
    return '\n'.join(lines) + '\n'

def git_blob_sources(source, names):
    """Read a bounded explicit source inventory in one read-only Git batch."""
    request = ''.join(source + ':' + name + '\n' for name in names).encode()
    process = subprocess.run(['git', 'cat-file', '--batch'], cwd=REPO, input=request,
                             stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True)
    raw, offset, sources = process.stdout, 0, {}
    require(len(raw) <= 8 * 1024**2, 'explicit source-control blob inventory exceeds8MiB')
    for name in names:
        end = raw.index(b'\n', offset)
        header = raw[offset:end].split()
        require(len(header) == 3 and header[1] == b'blob', 'source-control input is missing or not a Git blob')
        size = int(header[2]); start = end + 1
        data = raw[start:start + size]
        require(len(data) == size and raw[start + size:start + size + 1] == b'\n', 'source-control blob batch is truncated')
        sources[name] = data; offset = start + size + 1
    require(offset == len(raw), 'extra source-control blob output')
    return sources

def intl_first_use(evidence, product_report):
    """Separate first-operation evidence; never append to either scored corpus."""
    sys.path.insert(0, str(BASE))
    import analyze_intl_first_use as analysis
    actual = analysis.build_report()
    require(actual['schema'] == 'scriptw-intl-first-use-analysis-v1' and actual['complete'] is True
            and actual['excluded_from_scored_cohorts'] is True and actual['campaign_source'] == candidate_source()
            and actual['samples'] == 7 and actual['warmups'] == 10,
            'separate Intl first-use cohort completion/source/denominator differs')
    require(read_json(analysis.ANALYSIS) == actual, 'saved Intl first-use analysis differs from raw rederivation')
    outer, _ = evidence.receipt('intl-first-use')
    require(digest(BASE / 'intl-first-use.json') == actual['receipt_sha256'], 'Intl diagnostic outer receipt differs')
    rows = []
    for product in ['baseline', 'candidate']:
        observed = actual['products'][product]
        require(observed['compiler_identity'] == product_report[product]['compiler_identity'],
                'Intl diagnostic product differs from the exact frozen campaign identity')
        for runtime in ['wasmtime', 'v8']:
            values = observed['runtimes'][runtime]
            first, steady = values['first_warmup'], values['steady']
            require(first['observation_index'] == 0 and first['warmup'] is True
                    and len(values['remaining_warmups']) == 9 and len(steady['observations']) == 7
                    and steady['observation_indices'] == list(range(10, 17)),
                    'first-use and steady observations were mixed or omitted')
            rows.append(dict(product=product, runtime=runtime, first_warmup=first,
                             steady_summary=steady['summary'], scored_case_count_contribution=0))
    evidence.add(analysis.ANALYSIS)
    for path in analysis.evidence_files(): evidence.add(path)
    return dict(complete=True, excluded_from_scored_cohorts=True, scored_case_count_contribution=0,
                observations=actual, table=rows,
                interpretation='One separate Intl.NumberFormat fixture per fresh child process; first warmup and seven steady '
                               'observations remain outside both17-case scored cohorts. The first-use endpoint change includes '
                               'runtime mapping/setup and provider/process state; it is not an isolated provider heap counter '
                               'or an exact causal subtraction. Operation-specific typed initialization and any fallback provider construction remain included in the observed process endpoints.')

def archive(evidence, output):
    rows = [dict(path=name, bytes=path.stat().st_size, sha256=digest(path)) for name, path in sorted(evidence.paths.items())]
    rows += [dict(path=name, bytes=len(data), sha256=hashlib.sha256(data).hexdigest()) for name, data in sorted(evidence.virtual.items())]
    rows.sort(key=lambda row: row['path'])
    wrappers = sorted(evidence.lossless_wrappers.values(), key=lambda row: row['logical_path'])
    wrappers_by_member = {row['archive_member']: row for row in wrappers}
    require(len(wrappers) == len(wrappers_by_member)
            and all(row['archive_member'] in evidence.virtual and row['logical_path'] not in evidence.paths
                    for row in wrappers), 'lossless Cargo wrapper/archive mapping differs')
    for wrapper in wrappers:
        source = evidence.lossless_sources[wrapper['archive_member']]
        require(source.stat().st_size == wrapper['decoded_bytes'] and digest(source) == wrapper['decoded_sha256'],
                'original raw historical Cargo JSONL changed before archiving')
    manifest = dict(schema='scriptw-execution-performance-archive-v1', source_commit=candidate_source(), members=rows,
                    lossless_file_wrappers=wrappers,
                    excluded='Product/test/helper ELFs, rlibs/native archives, caches, baseline source-guard snapshots/tars, '
                             'large Portable bundles and V8 cachedData are excluded. Actual producer/hash provenance, code and raw observations remain. '
                             'The complete current Cargo producer JSONL are retained in complete deterministic gzip members; '
                             'lossless_file_wrappers gives original logical paths, decoded lengths and SHA-256 identities.')
    encoded = (json.dumps(manifest, indent=2) + '\n').encode()
    temporary = output.with_suffix(output.suffix + '.pending')
    require(not output.exists() and not temporary.exists(), 'refusing to overwrite complete/partial archive')
    with temporary.open('xb') as raw, gzip.GzipFile(fileobj=raw, mode='wb', filename='', mtime=0, compresslevel=6) as compressed, tarfile.open(fileobj=compressed, mode='w') as bundle:
        for row in rows:
            if row['path'] in evidence.virtual:
                stream = io.BytesIO(evidence.virtual[row['path']])
            else:
                path = evidence.paths[row['path']]
                require(path.stat().st_size == row['bytes'] and digest(path) == row['sha256'], 'evidence changed while archiving')
                stream = path.open('rb')
            with stream:
                info = tarfile.TarInfo(row['path']); info.size = row['bytes']; info.mode = 0o644
                bundle.addfile(info, stream)
        info = tarfile.TarInfo(PREFIX + 'archive-members.json'); info.size = len(encoded); info.mode = 0o644
        bundle.addfile(info, io.BytesIO(encoded))
    expected, seen = {row['path']: row for row in rows}, set()
    with tarfile.open(temporary, 'r:gz') as bundle:
        for member in bundle:
            require(member.isfile() and member.name not in seen, 'archive has a repeated/nonfile member')
            seen.add(member.name)
            stream = bundle.extractfile(member)
            if member.name == PREFIX + 'archive-members.json':
                require(stream.read() == encoded, 'archive manifest round-trip differs')
            else:
                row = expected[member.name]
                require(member.size == row['bytes'] and hashlib.file_digest(stream, 'sha256').hexdigest() == row['sha256'],
                        'archive member round-trip differs')
                if member.name in wrappers_by_member:
                    wrapper = wrappers_by_member[member.name]
                    decoded, length = hashlib.sha256(), 0
                    with bundle.extractfile(member) as raw, gzip.GzipFile(fileobj=raw, mode='rb') as plain:
                        while chunk := plain.read(256 * 1024):
                            decoded.update(chunk); length += len(chunk)
                            require(length <= wrapper['decoded_bytes'], 'archived Cargo wrapper exceeds its declared raw source')
                    require(length == wrapper['decoded_bytes'] and decoded.hexdigest() == wrapper['decoded_sha256'],
                            'archived Cargo wrapper lost or modified original producer bytes')
    expanded = sum(row['bytes'] for row in rows) + len(encoded)
    require(seen == set(expected) | {PREFIX + 'archive-members.json'} and len(seen) <= 32768
            and temporary.stat().st_size <= 32 * 1024**2 and expanded <= 256 * 1024**2,
            'archive exceeds explicitly bounded graph-reader budget; do not silently drop evidence')
    temporary.replace(output)
    return dict(file=output.name, sha256=digest(output), bytes=output.stat().st_size, member_count=len(seen),
                manifest_sha256=hashlib.sha256(encoded).hexdigest(), expanded_bytes=expanded,
                lossless_file_wrappers=wrappers)

def evidence_closing_time(evidence):
    """Use admitted actual receipt completion times, never publication wall time."""
    require(bool(evidence.resources), 'checkpoint has no admitted closing evidence')
    moments = [datetime.fromisoformat(row['completed_at']) for row in evidence.resources]
    require(all(moment.utcoffset() is not None for moment in moments), 'closing receipt timestamp lacks a timezone')
    return max(moments).astimezone(timezone.utc)


def prior_authority(evidence=None):
    reference=baseline_authority();old=read_json(CHECKPOINT)
    relative=str(CHECKPOINT.relative_to(REPO))
    require(subprocess.check_output(['git','show',reference['checkpoint_git_commit']+':'+relative],cwd=REPO)==CHECKPOINT.read_bytes(),
            'baseline checkpoint differs from its exact committed authority')
    require(old['complete'] is True and old['source_commit']==BASELINE_SOURCE
            and digest(CHECKPOINT)==reference['source_checkpoint']['sha256']
            and old['archive']['sha256']==reference['prior_archive']['sha256'], 'prior checkpoint/archive reference changed')
    archive=Path(reference['prior_archive']['path'])
    require(digest(archive)==old['archive']['sha256'],'prior published archive bytes changed')
    if evidence is not None:evidence.add(BASE/'baseline-reference.json')
    return reference,old


def products(evidence):
    from campaign_identity import frozen_product
    reference,old=prior_authority(evidence)
    baseline,baseline_hashes=frozen_product('baseline')
    require(baseline==old['products']['candidate']['compiler_identity'],'frozen44e baseline identity differs')
    original=read_json(PRIOR/'frozen-products.json')
    for name,item in original['products'].items():
        require(item['sha256']==baseline_hashes[name] and item['cargo_producer']==old['products']['candidate']['cargo_producers'][name],
                'baseline producer/frozen product differs from its admitted prior checkpoint')
    candidate,hashes=frozen_product('candidate')
    receipt,_=evidence.receipt('release-products')
    require(receipt['command']==[sys.executable,'-B',str(BASE/'build_product.py')],'actual new product builder command differs')
    actual=cargo_products(BASE/'cargo-product.jsonl');frozen=read_json(BASE/'frozen-products.json')
    require(frozen['source_commit']==candidate_source() and set(frozen['products'])==set(actual),'actual candidate freeze differs')
    for name,row in actual.items():
        item=frozen['products'][name]
        require(item['cargo_producer']==row and item['actual_cargo_product']==row['executable']
                and item['sha256']==hashes[name]==digest(row['executable'])
                and item['bytes']==(BASE/'candidate'/name).stat().st_size,'new candidate differs from its actual Cargo producer')
    for path in [product_directory('baseline')/'identity.json',BASE/'candidate/identity.json',BASE/'frozen-products.json',
                 BASE/'cargo-product.jsonl',BASE/'cargo-product.stderr']:evidence.add(path)
    return dict(baseline=dict(compiler_identity=baseline,runtime_runner_sha256=baseline_hashes['runtime_baseline'],
        runtime_boundaries_sha256=baseline_hashes['runtime_boundaries'],actual_build_source=BASELINE_SOURCE,
        actual_source_patch_sha256=EMPTY_PATCH,prior_committed_checkpoint=reference['source_checkpoint'],
        checkpoint_git_commit=reference['checkpoint_git_commit'],prior_archive=reference['prior_archive'],
        provenance='Actual published44e independent frozen products. Prior raw authorities are referenced by committed checkpoint/archive SHA; '
                   'no prior31MB archive, historical development campaigns or mutable old Cargo output is copied/relabelled.'),
        candidate=dict(compiler_identity=candidate,runtime_runner_sha256=hashes['runtime_baseline'],
            runtime_boundaries_sha256=hashes['runtime_boundaries'],source_tree_clean=True,release_receipt='release-products.json',cargo_producers=actual))


def known_failure_authority(evidence):
    reference,old=prior_authority(evidence)
    signatures=old['test262']['known_failure_reference']['signatures']
    require([row[0] for row in signatures]==sorted(KNOWN) and all(row[1:3]==['Runtime','Bug'] for row in signatures),
            'prior44e known failure signature set differs')
    path='crates/scriptw-test262/src/source-pins.json'
    prior_pins=json.loads(subprocess.check_output(['git','show',reference['checkpoint_git_commit']+':'+path],cwd=REPO))
    current=read_json(REPO/path)
    require({key:prior_pins[key] for key in ['ecma262','test262_tree']}=={key:current[key] for key in ['ecma262','test262_tree']},
            'pinned source revisions differ from the prior accepted signature authority')
    return dict(path=str(CHECKPOINT.relative_to(REPO)),sha256=digest(CHECKPOINT),git_commit=reference['checkpoint_git_commit'],
                signatures=signatures,pinned_revisions=dict(ecma262=current['ecma262'],test262=current['test262_tree']),
                scope='Committed prior44e authority reference; raw historical campaigns are not nested in this archive.')


def focused_checks():
    plan=read_json(BASE/'focused-plan.json')
    require(plan['complete'] is True and not plan['pending_confirmation'],'focused selectors remain unconfirmed')
    rows=[(item['label'],item['package'],item['target'],item['pattern']) for item in plan['checks']]
    require(len(rows)==len({row[0] for row in rows})==6,'all six reviewed affected focused groups are required')
    return rows


def extra_acceptance(evidence,native_report):
    require({Path(row['receipt']).stem for row in native_report['focused']}=={row[0] for row in focused_checks()},'focused overlaps differ')
    docs=[]
    for label,package,needle in [('receipt-authority-doctest','scriptw-aot-wasm','with_immutable_minimal_build'),
                                 ('typed-number-doctest','scriptw-intl','MinimalNumberProvider'),
                                 ('trust-token-doctest','scriptw-intl-build-data','ImmutableIntlBuildData')]:
        row,text=evidence.receipt(label)
        require(row['command']==['cargo','test','--locked','--offline','--release','--jobs','1','-p',package,'--doc'],
                'complete rustdoc scope changed')
        names=observed_names(text);summary=SUMMARY_RE.findall(text)
        require(names and len(names)==len({name for name,_ in names}) and all(status=='ok' for _,status in names)
                and summary==[('ok',str(len(names)),'0','0','0','0')]
                and any('compile fail' in name and needle in name for name,_ in names),
                'actual full rustdoc observations lack the intended passed compile-fail control')
        docs.append(dict(label=label,package=package,passed=len(names),identities=[name for name,_ in names],added_to_native_total=False))
    built,_=evidence.receipt('embedding-examples-build')
    require(built['command']==['cargo','build','--locked','--offline','--release','--jobs','1','-p','scriptw-engine',
        '--example','foreign_modules','--example','retained_embedding'],'embedding product build differs')
    examples=[]
    for name in ['foreign_modules','retained_embedding']:
        row,text=evidence.receipt('example-'+name)
        require(len(row['command'])==len(row['executables'])==1 and Path(row['command'][0]).name==name
                and Path(row['command'][0]).resolve()==Path(row['executables'][0]['path']).resolve(),'actual embedding child identity differs')
        examples.append(dict(name=name,stdout=text,executable=row['executables'][0],added_to_native_total=False))
        evidence.add(REPO/'crates/scriptw-engine/examples'/(name+'.rs'))
    return dict(complete=True,compile_fail_doctest_scopes=docs,embedding_examples=examples,focused_overlaps_added=0)


def tooling(evidence):
    path=BASE/'source-tooling.json';result=read_json(path)
    require(result['complete'] is True and result['candidate_source']==candidate_source()
            and result['baseline_source']=='86f2b4f4bf6fee158de681790b136ebcaa9b27a2','source-tooling source authority differs')
    outer,_=evidence.receipt('source-guards')
    require(outer['command']==[sys.executable,'-B',str(BASE/'source_guards.py')],'source guard driver command differs')
    sets={}
    for role in ['baseline','current']:
        source=result['baseline_source'] if role=='baseline' else candidate_source()
        sets[role]={}
        for kind in ['aggregate','terminal']:
            row=result['observations'][role][kind]
            record=BASE/(f'source-guard-{role}-{kind}.json')
            require(read_json(record)==row and row['source_commit']==source and row['stable_before_after'] is True
                    and row['actual_exit_code'] in [0,1],'actual source-only guard observation differs')
            log=BASE/row['log'];inputs=BASE/row['source_inputs'];manifest=read_json(inputs)
            require(digest(log)==row['log_sha256'] and digest(inputs)==row['source_inputs_sha256']
                    and manifest['source_commit']==source and manifest['stable_before_after'] is True,'source guard raw inputs/log differ')
            diagnostics=[line for line in log.read_text().splitlines() if line.startswith(('check-module-boundaries:','native program templates:'))
                         and line!='check-module-boundaries: ok']
            require(diagnostics==row['diagnostics'] and (row['actual_exit_code']==0 or diagnostics),'source guard diagnostic inventory differs')
            sets[role][kind]=set(diagnostics)
            for item in [record,log,inputs]:evidence.add(item)
            if kind=='terminal':
                script='scripts/check-native-program-templates.py'
                script_data=git_blob_sources(source,[script])[script]
                namespace={'__name__':'source_guard_rederivation','__file__':str(REPO/script)}
                exec(compile(script_data,str(REPO/script),'exec'),namespace)
                names=[*namespace['FILES'],script];data=git_blob_sources(source,names)
                require(all(manifest['files'][name]['sha256']==hashlib.sha256(data[name]).hexdigest() for name in names),
                        'isolated source control input differs from its committed Git blob')
                actual=['native program templates: '+name for name in namespace['check']({name:data[name].decode() for name in namespace['FILES']})]
                require(actual==diagnostics,'isolated source diagnostic cannot be reproduced from exact committed inputs')
    aggregate=sorted(sets['current']['aggregate']-sets['baseline']['aggregate'])
    terminal=sorted(sets['current']['terminal']-sets['baseline']['terminal'])
    passed=all(row['actual_exit_code']==0 for row in result['observations']['current'].values())
    require(not aggregate and not terminal and result['new_aggregate_diagnostics']==aggregate and result['new_terminal_diagnostics']==terminal
            and result['no_new_observed_diagnostics'] is True and result['full_tooling_passed']==passed,
            'new source-tooling diagnostics cannot be labelled inherited/full acceptance')
    evidence.add(path);evidence.add(BASE/'source_guards.py')
    return result


def markdown(report):
    source=report['source_commit'];tests=report['test262'];native_=report['native']
    lines=[f"# Runtime-admission memory checkpoint — {report['refresh_date']}",'',
        f"Actual candidate [{source[:9]}](https://github.com/mewhhaha/scriptw/commit/{source}) versus published clean baseline "
        f"[{BASELINE_SOURCE[:9]}](https://github.com/mewhhaha/scriptw/commit/{BASELINE_SOURCE}).",'',
        'The batch uses compact immutable Cargo runtime metadata, typed Locale/NumberFormat/PluralRules consumers, and '
        'shared immutable undefined values for native defaults. External/custom inputs retain checked admission, and source '
        'methods retain their home-object identity. The [byte-ownership contract](contracts/runtime-byte-ownership.md) describes the boundaries.','',
        'Each ordinary cohort contains all 17 workloads, with two rounds per product in ABBA order and seven measured '
        'observations after ten warmups. Fresh Store/Realm execution and existing-Realm calls remain separate. '
        'Construction/checksums stay inside execution; V8 is paired with candidate rounds. Shared-host observations are descriptive.','',
        '| Workload | Scriptw before ms | Scriptw after ms | Change | Paired V8 ms |','| --- | ---: | ---: | ---: | ---: |']
    for row in report['performance']['table']:
        lines.append(f"| {row['file']} | {row['baseline_ms']:.3f} | {row['candidate_ms']:.3f} | {row['change_percent']:+.1f}% | {row['paired_candidate_v8_ms']:.3f} |")
    lines+=['','Ordinary post-execution process RSS, median of 14 endpoints per product/runtime. Wasmtime samples while the '
            'Store remains alive; V8 samples after execution while its context remains alive. Host/runtime, setup and retained '
            'warmup effects remain included. These are neither live JavaScript heap bytes nor whole-child high-water RSS.','',
            '| Workload | Before MiB | After MiB | Paired V8 MiB |','| --- | ---: | ---: | ---: |']
    for row in report['performance']['rss_table']:
        lines.append(f"| {row['file']} | {row['baseline_rss_bytes']/2**20:.3f} | {row['candidate_rss_bytes']/2**20:.3f} | {row['paired_candidate_v8_rss_bytes']/2**20:.3f} |")
    lines+=['','Separate existing-Realm calls; all slowdowns remain visible.','',
            '| Workload | Before ms | After ms | Change | Paired V8 ms |','| --- | ---: | ---: | ---: | ---: |']
    for row in report['same_realm_performance']['table']:
        lines.append(f"| {row['file']} | {row['baseline_ms']:.3f} | {row['candidate_ms']:.3f} | {row['change_percent']:+.1f}% | {row['paired_candidate_v8_ms']:.3f} |")
    lines+=['','A separate Intl.NumberFormat first-use fixture contributes zero scored cases. Observation 0 is the first '
            'warmup, followed by nine warmups and seven steady observations. The baseline initialized its whole selected Minimal '
            'provider; the candidate uses typed consumers for 11 operations (three Locale transforms, four NumberFormat and four PluralRules), ' 
            'while the remaining 35 operations still initialize the complete provider. '
            'Wasmtime endpoints bracket invocation admission/mapping/setup and execution; V8 endpoints bracket JavaScript. '
            'Endpoint changes do not isolate provider heap bytes or establish synchronized live-heap usage.','',
            '| Intl diagnostic | First warmup RSS MiB before → after | Steady median RSS MiB after |','| --- | ---: | ---: |']
    for row in report['intl_first_use_diagnostic']['table']:
        a,b=row['first_warmup'],row['steady_summary']
        lines.append(f"| {row['product']} / {row['runtime']} | {a['rss_before_bytes']/2**20:.3f} → {a['rss_after_bytes']/2**20:.3f} | {b['rss_after_bytes']['median']/2**20:.3f} |")
    lines+=['','The standalone allocation diagnostic uses byte-identical helper source, separately linked for each compiler revision, ' 
            'and retains 35 phase pairs and 70 raw maps, including both invocations. '
            'Requested Rust allocation liveness, process residency and ordinary benchmark endpoints remain separate. '
            'Post-return helper phases occur after their Store drops; Rust GlobalAlloc counters exclude Wasmtime/native mappings, '
            'allocator usable/resident sizes and live JavaScript bytes. Native perf-map hashing is disabled for these observations. '
            'All phases and cache/identity limits are in ALLOCATION-COMPARISON.md/JSON in the archive.','',
            f"Native verification passed {native_['passed']:,} checks across {native_['target_count']} complete targets "
            f"({native_['nonempty_target_count']} nonempty). Counts come from fresh complete inventories and disjoint Engine batches. "
            'Focused overlaps, three complete rustdoc scopes and both real embedding examples are reported separately.','',
            f"Selected Test262 replay: {tests['passed']:,} / {tests['total']:,} Success, {tests['bug']} Bug, {tests['crash']} Crash, "
            f"{tests['not_implemented']} NotImplemented, {tests['timeout']} timeouts; actual launcher exit {tests['actual_command_exit']}. "
            'The four failure kind/detail signatures match the prior committed authority. Complete affected families and all '
            'controls are retained; this is not a full pinned Test262 refresh.','',
            f"Full source tooling passed: {str(report['source_tooling']['full_tooling_passed']).lower()}. "
            'Fresh source-guard baseline 86f and current aggregate/isolated source diagnostics, raw logs and stable input hashes are retained. '
            'Inherited failures remain counted; no-new-observed-diagnostic evidence does not establish full tooling acceptance.','',
            'The old checkpoint remains a committed SHA reference, including its historical OOM and source-tooling context. '
            'Its prior archive and three development campaigns are not copied into this archive. Baseline products/diagnostic '
            'keep their original paths and source identity; no old run is relabelled as the candidate. No cleanup is part of this campaign.','',
            f"[Machine-readable checkpoint]({STEM}.json) · [Raw evidence and reproduction code]({STEM}.tar.gz). "
            f"Archive SHA-256: `{report['archive']['sha256']}`.",'',
            'Reproduce with the archived run_campaign.py and explicit actual clean campaign source under the one-CPU, 4 GiB, '
            'no-swap scope. Reuse the exact prior frozen baseline or reconstruct its committed authority independently. '
            'The publisher validates read-only by default and refuses overwrite on --publish. Complete Cargo producer rows '
            'are retained losslessly in mapped gzip members with decoded byte length/SHA.']
    return '\n'.join(lines)+'\n'


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--publish',action='store_true')
    parser.add_argument('--section',choices=['products','native','extra','conformance','allocation','tooling','performance','intl-first-use'])
    parser.add_argument('--write-allocation-comparison',action='store_true')
    args=parser.parse_args();require(not(args.publish and args.section),'partial admission cannot publish a complete checkpoint')
    os.sched_setaffinity(0,{0});current_source();evidence=Evidence();product_report=products(evidence)
    if args.section=='products':print(json.dumps(dict(validated=True,section='products',source=candidate_source())));return
    if args.section in ['native','extra']:
        result=native(evidence)
        if args.section=='extra':result=extra_acceptance(evidence,result)
        print(json.dumps(dict(validated=True,section=args.section,result=result),indent=2));return
    if args.section=='conformance':
        result=conformance(evidence);print(json.dumps(dict(validated=True,total=result['total'],outcomes=result['outcomes'])));return
    if args.section=='tooling':
        result=tooling(evidence);print(json.dumps(dict(validated=True,full_tooling_passed=result['full_tooling_passed'])));return
    if args.section=='intl-first-use':
        result=intl_first_use(evidence,product_report);print(json.dumps(dict(validated=True,rows=len(result['table']))));return
    allocation=allocation_comparison(evidence,product_report)
    comparison,description=BASE/'allocation-comparison.json',BASE/'ALLOCATION-COMPARISON.md'
    if args.write_allocation_comparison:
        require(not comparison.exists() and not description.exists(),'derived allocation comparison cannot overwrite prior observations')
        comparison.write_text(json.dumps(allocation,indent=2)+'\n');description.write_text(allocation_markdown(allocation))
    if args.section=='allocation':
        if comparison.exists() or description.exists():
            require(read_json(comparison)==allocation and description.read_text()==allocation_markdown(allocation),
                    'existing or partial derived allocation support differs from the closed actual reports')
        print(json.dumps(dict(validated=True,pairs=allocation['paired_phase_count'],snapshots=allocation['raw_snapshot_count'])));return
    require(read_json(comparison)==allocation and description.read_text()==allocation_markdown(allocation),'derived allocation support differs')
    evidence.add(comparison);evidence.add(description)
    performance_report=performance(evidence,product_report);calls=performance_calls(evidence,product_report)
    if args.section=='performance':print(json.dumps(dict(validated=True,fresh=17,calls=17)));return
    native_report=native(evidence);test262=conformance(evidence);source_tooling=tooling(evidence)
    extra=extra_acceptance(evidence,native_report);intl=intl_first_use(evidence,product_report)
    for path in BASE.glob('*.py'):evidence.add(path)
    for name in ['baseline-reference.json','campaign.json','campaign-plan.json','selected-scopes.json','selected.ids','native-scopes.json','focused-plan.json','PLAN.md']:
        evidence.add(BASE/name)
    for name in ['limited_verification.py','resource_numbers.py','process_memory_maps.py','test262_execution_batches.py','replay-test262-executions.py']:
        evidence.add(REPO/'scripts'/name)
    additional=additional_observations(evidence);closing=evidence_closing_time(evidence)
    report=dict(schema='scriptw-execution-performance-checkpoint-v1',complete=True,source_commit=candidate_source(),
        refresh_date=closing.date().isoformat(),evidence_completed_at=closing.isoformat(),campaign=read_json(BASE/'campaign.json'),
        products=product_report,native=native_report,test262=test262,performance=performance_report,same_realm_performance=calls,
        execution_allocation_diagnostic=allocation,intl_first_use_diagnostic=intl,source_tooling=source_tooling,
        extra_acceptance=extra,additional_observations=additional,
        resources=dict(cpus=1,memory_limit_bytes=BUDGET,swap_limit_bytes=0,accepted_oom_events=0,
            maximum_cgroup_peak_bytes=max(row['memory_peak_bytes'] for row in evidence.resources),field_provenance=evidence.resources,
            scope='Actual new accepted outer receipts only. Prior baseline diagnostic keeps its original receipt outside this aggregate. '
                  'Historical prior incidents remain in the committed older checkpoint reference.'))
    if not args.publish:
        print(json.dumps(dict(validated=True,source=candidate_source(),native_passed=native_report['passed'],native_targets=31,
            selected_test262=test262['total'],outcomes=test262['outcomes'],fresh_cases=17,call_cases=17,allocation_pairs=35,
            archive_members=len(evidence.paths)+len(evidence.virtual)+1,publication='not requested'),indent=2));return
    output=REPO/'docs/rust-rewrite';paths=[output/(STEM+suffix) for suffix in ['.md','.json','.tar.gz']]
    require(not any(path.exists() for path in paths),'published checkpoint cannot be overwritten')
    require(len(json.dumps(report,indent=2).encode())+16384<=16*1024**2,'checkpoint exceeds16MiB selected-report budget')
    report['archive']=archive(evidence,paths[2]);data=(json.dumps(report,indent=2)+'\n').encode()
    require(len(data)<=16*1024**2,'checkpoint exceeds16MiB report budget')
    paths[1].write_bytes(data);paths[0].write_text(markdown(report))
    print(json.dumps(dict(published=[str(path) for path in paths],archive=report['archive']),indent=2))


if __name__=='__main__':
    try:main()
    except (ValueError,KeyError,OSError,TypeError,StopIteration,subprocess.SubprocessError) as error:
        print('Evidence admission refused: '+str(error),file=sys.stderr);raise SystemExit(1)

