"""Capture one actual bounded child and its immutable receipt; no import work."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import resource
import subprocess
import sys
import time

from campaign_runtime import BASE, REPO, actual_source, require_scope, require, digest, save_new


def main():
    require(len(sys.argv) >= 3, 'usage: run_check.py LABEL COMMAND...')
    label, command = sys.argv[1], sys.argv[2:]
    require(re.fullmatch(r'[A-Za-z0-9_-]+', label), 'invalid resource receipt label')
    source = actual_source(); require_scope()
    log, receipt = BASE / (label + '.log'), BASE / (label + '.json')
    require(not log.exists() and not receipt.exists(), 'refusing overwrite of complete/partial actual observations')
    started_at = datetime.now(timezone.utc).isoformat(); start = time.monotonic()
    with log.open('x') as out:
        result = subprocess.run(command, cwd=REPO, stdout=out, stderr=subprocess.STDOUT)
    text = log.read_text(errors='replace')
    row = dict(source_head=source, source_patch_sha256=hashlib.sha256(b'').hexdigest(), label=label, command=command,
               exit_code=result.returncode, started_at=started_at, seconds=time.monotonic()-start,
               date=datetime.now(timezone.utc).isoformat(), child_maxrss_kib=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,
               cpu_affinity=sorted(os.sched_getaffinity(0)), log=log.name, log_sha256=digest(log),
               test_results=re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out', text),
               resource_environment={name:os.environ.get(name) for name in ['CARGO_BUILD_JOBS','SCRIPTW_JOBS','RUST_TEST_THREADS',
                    'RAYON_NUM_THREADS','SCRIPTW_MODULE_MEMORY_CACHE_ENTRIES','SCRIPTW_MODULE_MEMORY_CACHE_LIMIT_BYTES']}, executables=[])
    paths = re.findall(r'Running [^\n]*\((/[^)]+)\)', text)
    if Path(command[0]).is_file(): paths.append(command[0])
    for name in sorted(set(paths)):
        path = Path(name).resolve()
        if path.is_file(): row['executables'].append(dict(path=str(path), sha256=digest(path), bytes=path.stat().st_size))
    for line in Path('/proc/self/cgroup').read_text().splitlines():
        if line.startswith('0::'):
            cgroup = Path('/sys/fs/cgroup') / line[3:].lstrip('/')
            for name in ['memory.max','memory.swap.max','memory.peak','memory.events','memory.oom.group','cpuset.cpus.effective']:
                row[name] = (cgroup/name).read_text().strip()
    try:
        row['source_head_after'] = actual_source()
    except (ValueError, OSError, subprocess.SubprocessError) as error:
        row['source_changed_after_child'] = str(error)
    save_new(receipt,row)
    print(json.dumps(row,indent=2),flush=True)
    print('\n'.join(text.splitlines()[-16:]),flush=True)
    require('source_changed_after_child' not in row, 'child ran across a source change; receipt retained outside acceptance')
    raise SystemExit(result.returncode)


if __name__ == '__main__':
    main()
