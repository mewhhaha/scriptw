#!/usr/bin/env python3
"""Prepare a read-only campaign plan; never build or run native workloads.

Default prints the plan. --write-plan creates new small metadata/source lists
and refuses overwrite. An actual --candidate-source may be supplied only after
the coherent code batch is committed cleanly; no candidate hash is invented.
Root owns the bounded serial build, freeze, native verification and measurement.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys

BASE = Path(__file__).resolve().parent
REPO = BASE.parent.parent
PRIOR = REPO / 'target/memory-fixed-costs-verified-20261025'
CHECKPOINT = REPO / 'docs/rust-rewrite/execution-memory-fixed-costs-20261025.json'
BASELINE_SOURCE = '44e17ee4c73eeab6cc970804199109aa2aee51a9'
LIMIT = 4 * 1024**3
EMPTY = hashlib.sha256(b'').hexdigest()
PREFIXES = [
    'intl402/',
    'built-ins/Function/',
    'language/module-code/',
    'language/expressions/super/',
    'language/expressions/object/method-definition/',
    'built-ins/Object/defineProperty/',
    'built-ins/Object/defineProperties/',
    'built-ins/Object/getOwnPropertyDescriptor/',
    'built-ins/Object/getOwnPropertyDescriptors/',
    'built-ins/Object/create/',
    'built-ins/Reflect/defineProperty/',
    'built-ins/Reflect/getOwnPropertyDescriptor/',
]
RATIONALES = {
    'intl402/': 'All Intl operations remain covered while Locale/NumberFormat/PluralRules take typed fast paths and other operations retain fallback admission.',
    'built-ins/Function/': 'Function name/length/constructor/call descriptors and independent mutation of shared native metadata.',
    'language/module-code/': 'Module execution, retained compiled owners and cross-program runtime admission.',
    'language/expressions/super/': 'Source-home identity must survive native-only undefined home-value sharing.',
    'language/expressions/object/method-definition/': 'Source method home-object identity, descriptor flags and super resolution.',
    'built-ins/Object/defineProperty/': 'Independent data/accessor descriptor redefinition around canonical undefined values.',
    'built-ins/Object/defineProperties/': 'Multiple descriptor conversion and publication must not mutate shared values.',
    'built-ins/Object/getOwnPropertyDescriptor/': 'Own data/accessor descriptor values and property flags remain exact.',
    'built-ins/Object/getOwnPropertyDescriptors/': 'Bulk descriptor reads preserve individual values and flags.',
    'built-ins/Object/create/': 'Descriptor-driven object creation and prototype identity preserve canonical undefined ownership.',
    'built-ins/Reflect/defineProperty/': 'Reflect descriptor publication and mutation retain property semantics.',
    'built-ins/Reflect/getOwnPropertyDescriptor/': 'Reflect own descriptor reads preserve property flags and values.',
}


def require(value, message):
    if not value:
        raise ValueError(message)


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def read(path):
    path = Path(path)
    require(path.is_file() and not path.is_symlink(), 'missing/symlinked authority: ' + str(path))
    return json.loads(path.read_text())


def pin(path):
    return dict(path=str(path), sha256=digest(path), bytes=path.stat().st_size)


def git(*arguments):
    return subprocess.check_output(['git', *arguments], cwd=REPO)


def baseline_reference():
    report = read(CHECKPOINT)
    require(report['complete'] is True and report['source_commit'] == BASELINE_SOURCE,
            'baseline must be the actual published44e checkpoint')
    authority_commit = git('rev-parse', 'HEAD').decode().strip()
    relative = str(CHECKPOINT.relative_to(REPO))
    require(git('show', authority_commit + ':' + relative) == CHECKPOINT.read_bytes(),
            'baseline checkpoint is not the committed prior authority')
    identity_path = PRIOR / 'candidate/identity.json'
    identity = read(identity_path)
    require(identity == report['products']['candidate']['compiler_identity']
            and identity['source_revision'] == dict(kind='git-commit', commit=BASELINE_SOURCE),
            'external frozen baseline identity differs from the published product')
    frozen_path = PRIOR / 'frozen-products.json'
    frozen = read(frozen_path)
    require(frozen['source_commit'] == BASELINE_SOURCE, 'external product freeze has another source')
    hashes = dict(scriptw=identity['executable_sha256'],
                  runtime_baseline=report['products']['candidate']['runtime_runner_sha256'],
                  runtime_boundaries=report['products']['candidate']['runtime_boundaries_sha256'])
    products = {}
    for name, expected in hashes.items():
        path = PRIOR / 'candidate' / name
        entry = frozen['products'][name]
        require(path.is_file() and not path.is_symlink() and path.stat().st_nlink == 1
                and str(path) == entry['path'] and path.stat().st_size == entry['bytes']
                and digest(path) == expected == entry['sha256'], 'independent frozen baseline changed: ' + name)
        products[name] = dict(path=str(path), sha256=expected, bytes=entry['bytes'], independent_frozen_file=True)
    archive = CHECKPOINT.parent / report['archive']['file']
    require(archive.stat().st_size == report['archive']['bytes'] and digest(archive) == report['archive']['sha256'],
            'prior committed evidence archive changed')
    release_path = PRIOR / 'release-products.json'
    release = read(release_path)
    require(release['source_head'] == BASELINE_SOURCE and release['source_patch_sha256'] == EMPTY
            and release['exit_code'] == 0, 'original baseline release receipt differs')
    allocation = PRIOR / 'candidate-engine-allocation-probe/report.json'
    allocation_report = read(allocation)
    require(allocation_report['source_commit'] == BASELINE_SOURCE and allocation_report['complete'] is True,
            'external baseline allocation diagnostic differs')
    return dict(schema='scriptw-memory-admission-baseline-reference-v1', baseline_source=BASELINE_SOURCE,
                source_checkpoint=pin(CHECKPOINT), checkpoint_git_commit=authority_commit,
                checkpoint_git_blob=git('rev-parse', authority_commit + ':' + relative).decode().strip(),
                prior_archive=dict(**pin(archive), copied_into_new_archive=False),
                identity=pin(identity_path), frozen_products=pin(frozen_path), products=products,
                original_release_receipt=pin(release_path), allocation_report=pin(allocation),
                allocation_outer_receipt=pin(PRIOR / 'allocation-diagnostic-candidate.json'),
                scope='The actual44e frozen products and closed receipts remain at their original independent paths. '
                      'No ELF, rlib, cache, old development campaign or31MB prior archive is copied or relabelled. '
                      'The new archive references the committed checkpoint/archive SHA authority.')


def selected_plan(reference):
    sys.path.insert(0, str(REPO / 'scripts'))
    from test262_execution_batches import native_inventory
    inventory_path = PRIOR / 'conformance-inventory-final.log'
    inventory = native_inventory(inventory_path.read_text())
    previous = read(PRIOR / 'selected-scopes.json')
    require(len(inventory) == 102994 and digest(inventory_path) == previous['source_inventory_sha256'],
            'prior actual full inventory differs from its admitted authority')
    report = read(CHECKPOINT)
    signatures = report['test262']['known_failure_reference']['signatures']
    controls = [row[0] for row in signatures]
    require(len(controls) == len(set(controls)) == 4 and set(controls).issubset(inventory),
            'all four real known failures must remain controls')
    scopes, selected = [], set()
    for prefix in PREFIXES:
        names = sorted(name for name in inventory if name.split(':', 1)[1].startswith(prefix))
        require(names and not selected.intersection(names), 'missing or overlapping complete family: ' + prefix)
        selected.update(names)
        scopes.append(dict(prefix=prefix, count=len(names), execution_ids=names, rationale=RATIONALES[prefix]))
    selected.update(controls)
    names = sorted(selected)
    return dict(schema='scriptw-memory-admission-selected-scopes-v1', complete=True,
                source_inventory=pin(inventory_path), source_inventory_sha256=digest(inventory_path),
                source_inventory_execution_count=len(inventory), source_inventory_compiler_commit=BASELINE_SOURCE,
                source_inventory_reused_for_scope_planning_only=True,
                require_current_compiler_inventory_exact_match_before_execution=True,
                scope_policy='Complete Intl402, Function, module-code, super and object-method namespaces plus seven complete '
                             'descriptor-specific Object/Reflect families and four unwaived known failures. '
                             'No generic property algorithm changes are planned, so unrelated Object/Reflect families are not selected. '
                             'No individual test filter replaces complete affected families.',
                scopes=scopes, known_failure_controls=controls, known_failure_signatures=signatures,
                selected_total=len(names), selected_execution_count=len(names)), names


def candidate_commit(value):
    if value is None:
        return None
    actual = git('rev-parse', '--verify', value + '^{commit}').decode().strip()
    require(actual == value and actual != BASELINE_SOURCE, 'candidate must name its actual complete new commit')
    require(git('rev-parse', 'HEAD').decode().strip() == actual,
            'candidate plan must use the actual current committed checkout')
    require(git('diff', '--binary', actual, '--', 'crates', 'Cargo.toml', 'Cargo.lock') == b''
            and git('ls-files', '--others', '--exclude-standard', '--', 'crates', 'Cargo.toml', 'Cargo.lock') == b'',
            'candidate product source is not yet clean and complete')
    return actual


def command_plan(selected_total):
    python = sys.executable
    def own(name, *arguments):
        return [python, '-B', str(BASE / name), *arguments]
    return [
        dict(stage='resource scope', command=[python, 'scripts/limited_verification.py', '--', *own('run_campaign.py','--run')],
             state='reviewed future command; root must supply the local one-CPU/4GiB/no-swap/grouped-OOM scope'),
        dict(stage='source freeze and release', commands=[own('run_check.py', 'release-products', *own('build_product.py')),
             own('run_check.py', 'freeze-candidate', *own('freeze_candidate.py'))],
             gate='Actual clean committed candidate + terminal successful Cargo producers; freeze independent products only afterward.'),
        dict(stage='allocation', commands=[own('run_check.py', 'freeze-candidate-allocation-inputs', *own('freeze_candidate_link_inputs.py', '--freeze')),
             own('run_check.py', 'allocation-diagnostic-candidate', *own('candidate_engine_allocation_diagnostic.py', '--run'))],
             gate='Reuse closed44e baseline helper evidence by original path; identical helper body; compare35 acknowledged boundaries.'),
        dict(stage='native', commands=[own('build_native.py'), own('focused_acceptance.py'), own('accept_native.py'), own('extra_acceptance.py')],
             gate='All31 affected complete target inventories with actual new test counts, disjoint Engine batches, exact focused overlaps, '
                  'doctest and embedding examples. Stop on failure; no invented complete receipt.'),
        dict(stage='selected inventory and replay', commands=[own('validate_inventory.py'),
             own('run_check.py', 'conformance-final', python, '-B', 'scripts/replay-test262-executions.py', str(BASE / 'selected.ids'),
                 '--binary', str(BASE / 'candidate/scriptw'), '--suite-root', 'test262/vendor/test262',
                 '--output-dir', str(BASE / 'conformance'), '--workers', '1', '--reuse-case-workers')],
             gate=f'Fresh candidate full102994 inventory/SHA and exact{selected_total} selected union; actual exit1 only for four identical '
                  'published known Bug signatures; zeroCrash/NI/timeouts. Preserve any surprise and stop.'),
        dict(stage='ordinary scores', command=own('measure_all.py'),
             gate='Two separate17-workload cohorts: fresh Store/Realm and existing-Realm calls, ABBA order, '
                  'two rounds/product,7 measured after10 warmups; native-map/row/debug instrumentation OFF.'),
        dict(stage='separate Intl diagnostic', commands=[own('run_check.py', 'intl-first-use', *own('measure_intl_first_use.py')),
             own('analyze_intl_first_use.py')], gate='Never enter the17 scored cases; preserve first-use and steady observations and endpoint limits.'),
        dict(stage='pure admission', commands=[own('analyze.py', '--check'), own('analysis_calls.py', '--check'), own('publish_evidence.py')],
             gate='Read-only default; no overwrite; no publication until all closed actual authorities reconcile.'),
        dict(stage='publication', command=own('publish_evidence.py', '--publish'),
             gate='Final review; archive <32MiB compressed/256MiB expanded/64MiB each and report <16MiB, <=32768 members. '
                  'Losslessly gzip full current Cargo rows if needed; reference the old checkpoint/archive instead of nesting historical payloads.'),
    ]


def build_plan(source=None):
    baseline = baseline_reference()
    selected, ids = selected_plan(baseline)
    source = candidate_commit(source)
    return dict(schema='scriptw-memory-admission-campaign-plan-v1', prepared_at=datetime.now(timezone.utc).isoformat(),
                candidate_source_commit=source, candidate_state='actual clean source supplied; frozen identity still required' if source else
                    'unresolved until root commits the coherent code batch and freezes actual products',
                baseline=baseline, selected_scope=selected,
                resources=dict(cpus=1, memory_limit_bytes=LIMIT, swap_limit_bytes=0, grouped_oom=True,
                               cargo_jobs=1, native_test_threads=1, replay_workers=1, module_cache_entries=1,
                               module_cache_limit_bytes=64 * 1024**2),
                commands=command_plan(len(ids)),
                implementation_state='Plan-only entrypoint; generic execution/native/publisher drivers must be reviewed and adapted '
                                     'to this actual baseline and selected manifest before root execution.'), selected, ids


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--candidate-source', help='Actual clean current committed source; omit while implementation is in progress')
    parser.add_argument('--write-plan', action='store_true', help='Create new small plan/reference/scope files only; no child execution')
    parser.add_argument('--write-campaign',action='store_true',help='Create actual campaign.json after the clean candidate commit; no build/execution')
    args = parser.parse_args()
    require(not(args.write_plan and args.write_campaign),'choose initial plan or actual committed campaign metadata')
    if args.write_campaign:
        source=candidate_commit(args.candidate_source)
        require(source is not None,'actual candidate source is required; no placeholder is admitted')
        reference=read(BASE/'baseline-reference.json')
        require(reference['baseline_source']==BASELINE_SOURCE and digest(CHECKPOINT)==reference['source_checkpoint']['sha256'],
                'prepared prior baseline checkpoint authority changed')
        path=BASE/'campaign.json'
        with path.open('x') as stream:
            stream.write(json.dumps(dict(schema='scriptw-runtime-admission-memory-campaign-v1',source_commit=source,
                baseline_source=BASELINE_SOURCE,baseline_exact_patch_sha256=EMPTY,created_at=datetime.now(timezone.utc).isoformat(),
                resources=dict(cpus=1,memory_limit_bytes=LIMIT,swap_limit_bytes=0,module_memory_cache_entries=1,
                               module_memory_cache_limit_bytes=64*1024**2),
                scope='Immutable Cargo R metadata, canonical undefined defaults, typed Locale/NumberFormat/PluralRules operation consumers; '
                      'actual dynamic complete31 native inventories and selected13862 affected Test262 union; separate17fresh/17calls/Intl.'),indent=2)+'\n')
        print(json.dumps(dict(prepared_actual_campaign=True,source_commit=source,native_commands_invoked=0,path=str(path))));return
    plan, selected, ids = build_plan(args.candidate_source)
    if args.write_plan:
        outputs = {BASE / 'campaign-plan.json': json.dumps(plan, indent=2) + '\n',
                   BASE / 'baseline-reference.json': json.dumps(plan['baseline'], indent=2) + '\n',
                   BASE / 'selected-scopes.json': json.dumps(selected, indent=2) + '\n',
                   BASE / 'selected.ids': '\n'.join(ids) + '\n'}
        require(not any(path.exists() for path in outputs), 'refusing to overwrite a closed or partial campaign plan')
        for path, data in outputs.items():
            with path.open('x') as stream:
                stream.write(data)
        print(json.dumps(dict(prepared=True, candidate_source=plan['candidate_source_commit'], selected_total=len(ids),
                              products_copied=0, native_commands_invoked=0, files=[str(path) for path in outputs]), indent=2))
    else:
        print(json.dumps(plan, indent=2))


if __name__ == '__main__':
    try:
        main()
    except (KeyError, ValueError, OSError, subprocess.SubprocessError) as error:
        print('Campaign preparation refused: ' + str(error), file=sys.stderr)
        raise SystemExit(1)
