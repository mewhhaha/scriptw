"""Run all31 whole native targets, deriving counts from actual enumeration."""
import hashlib
from campaign_runtime import BASE,actual_source,require_scope,read,check,require,cargo_target,inventory,native_result,progress


def main():
    source=actual_source();require_scope();scopes=read(BASE/'native-scopes.json');closed=[]
    require(len(scopes)==31,'review the affected complete target scope before execution')
    for index,scope in enumerate(scopes):
        if scope['package']=='scriptw-engine' and scope['kind']=='--lib':
            result=read(BASE/'engine-accepted.json')
            require(result['complete'] is True and result['source_head']==source and result['inventory'], 'Engine exact union is incomplete')
        else:
            label=f'broad-{index:02d}-{scope["package"]}-{scope["name"] or "lib"}'
            command=cargo_target(scope)
            enum=check(label+'-inventory',command+['--','--list','--include-ignored'])
            zero=scope==dict(package='scriptw-intl-build-data',kind='--lib',name=None)
            names=inventory((BASE/enum['log']).read_text(),allow_zero=zero)
            row=check(label,command+['--','--test-threads=1','--include-ignored'])
            require(row['executables']==enum['executables'],'enumerated/executed native target binaries differ')
            native_result(row,names)
            result=dict(row,**scope,inventory=names,inventory_sha256=hashlib.sha256(('\n'.join(names)+'\n').encode()).hexdigest())
        closed.append(result)
        progress(BASE/'native-closed.json',dict(source=source,complete=len(closed)==len(scopes),
            total=sum(len(row['inventory']) for row in closed),targets=closed))
    print('ALL COMPLETE ACTUAL NATIVE TARGETS PASSED',sum(len(row['inventory']) for row in closed),'/',len(scopes),flush=True)


if __name__=='__main__':main()
