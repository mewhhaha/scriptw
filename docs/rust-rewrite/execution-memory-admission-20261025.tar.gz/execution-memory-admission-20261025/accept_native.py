"""Close Engine batches then all complete affected targets, serially."""
import subprocess
from campaign_runtime import own,REPO,actual_source,require_scope,require


def main():
    actual_source();require_scope()
    for name in ['engine_batches.py','native_final.py']:
        code=subprocess.call(own(name),cwd=REPO)
        require(code==0,'native stage failed; preserve actual receipts: '+name)


if __name__=='__main__':main()
