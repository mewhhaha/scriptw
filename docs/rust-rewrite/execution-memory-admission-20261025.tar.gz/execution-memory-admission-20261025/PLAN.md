# Runtime-admission memory campaign preparation

This directory contains a metadata-only plan and reusable measurement templates.
No compiler, native test, helper or JavaScript workload has run. `campaign.py`
has no execution mode. Root owns the later serial one-CPU/4-GiB/no-swap scope.

The baseline is the published clean `44e17ee4c73eeab6cc970804199109aa2aee51a9`
product, independently frozen in the prior verified campaign. The preparation
verified all three frozen hashes, the committed checkpoint bytes and the actual
prior archive SHA. It copied no product, library, cache or closed receipt.
The new archive should retain the small baseline reference/required authority
metadata and reference the committed older checkpoint/archive SHA. It must not
nest the old 31-MB archive or the older three development campaigns.

The exact selected union is **13,862** executions from the prior admitted full
102,994-case inventory. Complete namespaces are Intl402 (6,764), Function (893),
module-code (602), super (184), and object method-definition (557). Descriptor
coverage uses complete Object.defineProperty (2,250), defineProperties (1,264),
getOwnPropertyDescriptor (620), getOwnPropertyDescriptors (36), create (640),
Reflect.defineProperty (24), and getOwnPropertyDescriptor (26) families. The four
known failures stay explicit; the two Temporal controls are already in Intl402,
and the other two add the final two union members. Every family records its
reason and exact IDs in `selected-scopes.json`. No generic property algorithm
change is planned, so unrelated Object/Reflect namespaces were not selected.

The candidate must freshly enumerate the complete pinned inventory, match its
actual SHA and all selected families before replay. Actual outcomes, exit code,
four original failure kind/detail hashes and zero timeout observations must be
reconciled. This selected replay does not refresh the full Test262 chart.

The reusable `measure.py`/`analyze.py` and `measure_calls.py`/`analysis_calls.py`
keep all 17 fixtures in separate fresh-Store/Realm and existing-Realm cohorts.
Each cohort uses baseline/candidate/candidate/baseline rounds, seven measured
observations after ten warmups, with all native-map/row/debug instrumentation
off. `measure_all.py --plan-only` invokes no workload and resolves no candidate.
The separate Intl first-use driver retains its first warmup and steady
observations outside both scored cohorts; it remains useful when the new typed
Intl paths change first-use provider admission.

All imports and pure plans must work before a candidate exists. No source hash
is invented: `campaign-plan.json` records candidate `null` during implementation.
Root must create the real clean-commit `campaign.json`, complete the ordinary
Cargo product build, and independently freeze the three actual candidate ELFs.
Only then may runtime/analysis identity admission proceed. The generic native,
allocation freezer and publisher execution drivers are prepared and import-safe;
root must review them before actual execution against the new candidate. They
derive new test counts from complete fresh inventories.

`run_campaign.py --plan-only` (also its default) reviews the concrete execution
stages without launching work. Root must explicitly use `--run` inside the
bounded scope. Source guards first compare fresh baseline `86f2b4f4` and current
aggregate/isolated controls. The six focused groups cover receipt metadata,
bootstrap undefined values, independent cross-realm descriptors/source homes,
typed Minimal consumers, failed selected-image publication and typed Intl host
calls. Complete AOT/Intl/trust-leaf rustdoc scopes include the intended three
compile-fail controls and any other existing doctests; actual counts are derived.
Native/selected admission closes before the eight ordinary rounds. No unchanged
RegExp or instrumented code-size workload is rerun; the prior checkpoint remains
their original historical authority.

After the actual source is committed, root can create the new metadata using
`campaign.py --candidate-source ACTUAL_COMMIT --write-campaign`. This mode reads
the real clean checkout and refuses overwrite; it never builds or freezes an ELF.
The final orchestration runs full read-only publisher admission and stops there.
`--publish` remains a separate final action.

Review the concrete staged commands in `campaign-plan.json`. Later execution
must preserve no-overwrite receipts, stop on failures and keep actual partial
observations. Native counts come from fresh complete target inventories, not the
old 7,077 count. The same 31 affected targets are planned, plus meaningful
focused regressions, the authority doctest and embedding examples. No cache
cleanup or automatic deletion is part of this campaign.

Publication stays read-only by default. Keep the existing 32-MiB compressed,
256-MiB expanded, 64-MiB per-member, 16-MiB report and 32,768-member budgets.
Complete current Cargo JSONLs can use explicitly mapped deterministic gzip
members with decoded byte length/SHA and verified lossless recovery. Older
historical payloads are referenced by their committed checkpoint authority.
