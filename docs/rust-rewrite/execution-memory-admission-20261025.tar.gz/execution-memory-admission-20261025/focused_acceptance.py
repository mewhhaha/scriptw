"""Run only reviewed, nonempty focused regressions; broad31 counts stay separate."""
import argparse
from campaign_runtime import BASE,actual_source,require_scope,read,check,require,SUMMARY


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--plan-only',action='store_true');args=parser.parse_args()
    plan=read(BASE/'focused-plan.json')
    if args.plan_only:
        import json
        print(json.dumps(plan,indent=2));return
    actual_source();require_scope()
    require(plan['complete'] is True and not plan.get('pending_confirmation'), 'confirm all implementation-owned native selectors before focused execution')
    for item in plan['checks']:
        command=['cargo','test','--locked','--offline','--release','--jobs','1','-p',item['package'],
                 *item['target'],item['pattern'],'--','--test-threads=1','--include-ignored']
        row=check(item['label'],command)
        matches=SUMMARY.findall((BASE/row['log']).read_text())
        require(matches and all(x[0]=='ok' and int(x[1])>0 and x[2:5]==('0','0','0') for x in matches),
                'focused filter failed or enumerated zero checks: '+item['label'])


if __name__=='__main__':main()
