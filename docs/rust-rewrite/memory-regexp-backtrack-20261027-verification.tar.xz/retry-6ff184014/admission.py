"""Admit actual probe binary through final committed compile-input equivalence."""
import hashlib,json,subprocess

def admit(base,root):
 def sha(p):
  with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
 def read(p):return json.loads(p.read_text())
 def git(*args):return subprocess.check_output(['git',*args],cwd=root)
 final='6ff1840146c312d3564b322fe13e4bbf0f97527e'
 prior='1c4f0e3341ef2a223f00b16d849d44b93ae829fc'
 original='a26f8c9796d3d7284f5bc0537df1dd336c1641b6'
 file='crates/scriptw-aot-wasm/tests/emission/regexp_shared_recovery.rs'
 assert git('rev-parse','HEAD').decode().strip()==final
 assert not git('diff','HEAD','--','crates','vendor','scripts','Cargo.toml','Cargo.lock')
 assert git('diff','--name-only',original,final,'--').decode().splitlines()==[file]
 assert git('diff','--name-only',prior,final,'--').decode().splitlines()==[file]
 probe_dir=base.parent/'probe-shared-region';probe_path=probe_dir/'receipt.json';probe=read(probe_path)
 assert probe['complete'] is True and probe['diagnostic_dirty_test'] is True and probe['verified_source_claim'] is False
 assert probe['head_commit']==prior and probe['test_path']==file
 assert (probe['passed'],probe['failed'],probe['filtered_out'])==(1,0,32)
 assert hashlib.sha256(git('show',final+':'+file)).hexdigest()==probe['test_source_sha256']
 patch=probe_dir/probe['patch']['path']
 assert sha(patch)==probe['patch']['sha256'] and patch.stat().st_size==probe['patch']['bytes']
 assert git('diff','--binary',prior,final,'--',file)==patch.read_bytes()
 assert [(r['label'],r.get('exit_code')) for r in probe['commands']]==[('cargo-emission',0),('focused',0)]
 for r in probe['commands']:
  for stream in ('stdout','stderr'):assert sha(probe_dir/r[stream])==r[stream+'_sha256']
 binary=probe_dir/probe['binary']['path'];assert sha(binary)==probe['binary']['sha256'] and binary.stat().st_size==probe['binary']['bytes']
 for moment in ('before','after'):
  r=probe[moment];assert r['memory.max']=='4294967296' and r['memory.swap.max']=='0' and r['memory.oom.group']=='1'
 events=[dict(line.split() for line in probe[m]['memory.events'].splitlines()) for m in ('before','after')]
 assert all(events[0][k]==events[1][k] for k in ('oom','oom_kill','oom_group_kill'))
 # The second stopped attempt remains raw and incomplete, like the original.
 stopped=base.parent/'retry-1c4f0e334';v=read(stopped/'verification.json');n=read(stopped/'native/report.json');c=read(stopped/'check.json')
 assert v['source_commit']==n['source_commit']==c['source_commit']==prior
 assert not v['complete'] and not n['complete'] and 'after' not in v and 'after' not in n
 assert c['complete'] is True and c['exit_code']==0 and sha(stopped/'cargo-check.jsonl')==c['stdout_sha256']
 assert len(n['scopes'])==1 and not n['scopes'][0]['complete'] and not n['scopes'][0].get('passed')
 assert [(r['label'],r.get('exit_code')) for r in v['commands']]==[('cheap-main-driver',0),('cargo-check-driver',0),('native-driver',1)]
 assert [(r['label'],r.get('exit_code')) for r in n['commands']]==[('cargo-native',0),('scriptw-aot-wasm-emission-inventory',0),('scriptw-aot-wasm-emission-focused-00',101)]
 from native_test_protocol import result_summaries
 assert result_summaries((stopped/'native/scriptw-aot-wasm-emission-focused-00.stdout').read_text())==[('FAILED','0','1','0','0','32')]
 for record,folder in ((v,stopped),(n,stopped/'native')):
  for r in record['commands']:
   for stream in ('stdout','stderr'):assert sha(folder/r[stream])==r[stream+'_sha256']
 assert not any((stopped/p).exists() for p in ('conformance','conformance-unicode','conformance-regexp','conformance-regexp-full','conformance-array-from-async'))
 proof=base/'source-bindings-closure-equivalence.json';closure=read(proof)
 assert closure['test_only_repair'] is True and len(closure['rows'])==6
 for mode in (False,True):
  rows=[r for r in closure['rows'] if r['extra_ignored_regress_lock']==mode]
  assert len(rows)==3 and {r['revision'] for r in rows}=={original,prior,final}
  assert len({(r['source_fingerprint'],r['files'],r['bytes']) for r in rows})==1
 return dict(kind='final-committed-input-equivalence-to-diagnostic-probe',probe_receipt_sha256=sha(probe_path),probe_verified_source_claim=False,final_test_source_sha256=probe['test_source_sha256'],patch_sha256=sha(patch),emission_binary_sha256=sha(binary),closure_proof_sha256=sha(proof),stopped_1c_verification_sha256=sha(stopped/'verification.json'),stopped_1c_native_report_sha256=sha(stopped/'native/report.json'),stopped_1c_focused_passed=0,stopped_1c_focused_failed=1,stopped_1c_completed_scopes=0)
