"""Private scored raw-copy/preview/check receipt. Does not publish."""
import os,sys,json,hashlib,subprocess,time,shutil
from pathlib import Path
BASE=Path(__file__).resolve().parent;ROOT=BASE.parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from limited_verification import require_kernel_budget,kernel_group
require_kernel_budget(1024**3);assert sorted(os.sched_getaffinity(0))==[0]
RUN='40568638008';SOURCE='a26f8c9796d3d7284f5bc0537df1dd336c1641b6'
group=kernel_group()
def counters():return {k:(group/k).read_text().strip() for k in ['memory.max','memory.swap.max','memory.oom.group','memory.peak','memory.events']}
def sha(path):
 with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
receipt=BASE/'preview-processing.json';assert not receipt.exists()
processing=BASE/f'ci-processing-{RUN}.json';checked=json.loads(processing.read_text());assert checked['complete'] and checked['run']==RUN and checked['source_commit']==SOURCE
report=BASE/f'github-{RUN}/precompiled-measurements/precompiled-evidence/report.json'
summary=json.loads((BASE/'measured-summary.json').read_text());assert summary['source']==SOURCE and summary['report_sha256']==sha(report)
record=dict(source_commit=SOURCE,run=RUN,complete=False,scored_mutations=False,cpu_affinity=[0],ci_processing_sha256=sha(processing),before=counters(),commands=[])
def save():receipt.write_text(json.dumps(record,indent=2)+'\n')
def run(label,args):
 out=BASE/(label+'.stdout');err=BASE/(label+'.stderr');start=time.monotonic()
 with out.open('xb') as a,err.open('xb') as b:r=subprocess.run(args,cwd=ROOT,stdout=a,stderr=b,timeout=300)
 record['commands'].append(dict(label=label,args=[str(v) for v in args],exit_code=r.returncode,seconds=time.monotonic()-start,stdout=out.name,stdout_sha256=sha(out),stderr=err.name,stderr_sha256=sha(err)));record['after']=counters();save()
 if r.returncode:raise SystemExit(r.returncode)
save();os.environ['MPLCONFIGDIR']=str(BASE/'mplconfig')
raw=BASE/f'ci-scored-{RUN}-raw-report.json';assert not raw.exists();shutil.copyfile(report,raw);assert sha(raw)==sha(report)
record['raw_scored_report']=dict(path=raw.name,sha256=sha(raw),bytes=raw.stat().st_size);save()
run('render-previews',[sys.executable,'-B',str(BASE/'render-previews.py')])
run('canonical-p-check',[sys.executable,'-B',str(ROOT/'scripts/precompiled_comparison.py'),'check',str(ROOT/'docs/rust-rewrite/precompiled-comparison.json')])
record['complete']=True;record['after']=counters();save()
