# Shared matcher backtrack owner (source-only design)

Current inspected source: a960f50acea8bd3a1de0a2c391bbb09b88f2ee4d.
No implementation, builds, probes or guest execution. Current owned native
regexp_matcher symbol is 4,634,312 bytes; that is an enclosing static-size ceiling,
not a predicted reduction or resident-memory claim.

## Decision

Prefer one shared **in-function** recovery block. MatcherWorkspace owns more than
16 mutable scalar locals, its scratch-tail/checkpoint lease, active counted-run
positions and capture/repeat snapshots. A separate R helper would need either a
new workspace representation or a large input/result tuple carrying every mutated
field and all failures. It would also have to propagate existing workspace.fail
function returns and preserve lease retirement. That is substantially broader
than removing these repeated instruction sequences.

There are **25** call sites, not 24: 24 in regexp.rs and one in counted.rs:549.
All pass the same workspace, match_byte, match_utf16, pc and
match_on_low_surrogate. Only caller_block_depth differs (0..3). Counted End's
optional-empty failure must reach this same recovery owner.

## Exact CFG seam

Place the new frames immediately AFTER the candidate capture-reset loop and
BEFORE the existing inner candidate-failed Block/instruction Loop (~regexp.rs700).
Do not move candidate cursor initialization, pc=0, choices.reset, reset_repeats
or capture -1 initialization inside the new retry loop.

```
Block attempt_done:                         // new, real typed target
  Loop recovery_retry:                      // new, real typed target
    Block request_backtrack:                // new, real typed target
      Block original_candidate_failed:      // keep original pair intact
        Loop original_instruction_dispatch:
          original opcode dispatch
          each mismatch condition -> br_if request_backtrack
          existing success/continue branches stay within original pair
        End
      End
      br attempt_done                       // original pair's normal fallthrough
    End request_backtrack
    shared choice-recovery loop:
      empty choices -> br attempt_done
      inspect existing top entry
      RequiredRun:
        same restore_required_run operation
        not selected -> continue shared choice-recovery loop
        selected -> br recovery_retry
      other entries:
        same LazyProgressAttempt discard-and-continue
        same LazyProgressChoice activation / ordinary discard
        same restore_fallback(pc), restore_cursor, restore_state
        br recovery_retry
  End recovery_retry
End attempt_done
original sticky/candidate advancement and final NoMatch handling
```

The explicit fallthrough branch after the original pair is essential: candidate
exhaustion must skip recovery, not attempt to inspect an empty or obsolete choice.
Recovery retry enters only the original pc validation/dispatch, exactly matching
the old successful restore branch. Exhaustion reaches exactly the original
post-instruction-loop candidate handling. No new search policy is introduced.

Putting frames OUTSIDE the existing pair avoids inserting an extra label between
existing opcode branches and their instruction-loop/candidate-fail targets. Still
audit every escaping raw Br/BrIf and called emitter before implementation: any
branch targeting beyond that pair needs conversion to its explicit semantic target.
Local loops/ifs and their branches should remain untouched. counted.rs:642's
continue through its two dispatch If frames targets the original instruction loop.
Resource/corrupt-program failures use function Return and preserve that behavior.

## Typed control/lifecycle boundary

Use existing FunctionBuilder::open_frame and ControlTarget. Its label is obtained
from Function::label_depth; branch_to_label/branch_if_to_label calculate depth from
all actual instructions, INCLUDING untracked raw frames (code_sink.rs). This is
already the mechanism needed here; do not retain caller_block_depth or add offsets.

Expose a private BacktrackRequest target wrapper to mismatch callers, rather than
an arbitrary ControlTarget: it can name only the request block. Thread a borrowed
request into emit_regexp_counted_dispatch (or its local context), including the
optional-empty End path. Replace emit_regexp_backtrack_or_fail's signature with
request-if: it consumes the existing mismatch I32 through an exact typed br_if.
No restore work or locals are emitted at a mismatch site.

A small consumed compile-time scope can enforce lifecycle: opening the three new
frames yields a request scope; closing that request scope after the original pair
emits the fallthrough branch/End and returns a recovery scope containing only the
retry/exhausted targets. The restoration emitter consumes the recovery scope and
closes the outer loop/block. This makes restoration-before-request-closure and
reusing one restoration owner after consumption unrepresentable. It adds no Wasm
state or object model. Recovery has only ResumeDispatch and Exhausted routes;
resource/corruption keeps the original immediate function-return route.

## Complete integration inventory

regexp.rs call sites (current source lines): 873,920,1423,1495,1540,1734,2077,
2146,2276,2336,2365,2400,2426,2612,2624,2659,2733,2769,2853,2882,2903,
2931,2947,2959. Plus counted.rs549. The old heavy emitter at regexp.rs3154 is
replaced by the single recovery owner and the request-only adapter. Existing
required_run/logical.rs644 restore_required_run and choice-entry implementations
remain algorithms owned by the same workspace, called once in emitted recovery.

## Invariants and focused acceptance

Keep exact choice order and discard/activation order, required-run selected=false
retry, fallback PC, forward/reverse UTF16 and low-surrogate cursors, live captures,
repeat counters, nullable-attempt progress snapshots, named-group snapshots and
private workspace growth/retirement. Do not make failures reset a candidate early.
All existing immutable GC program/string parameters remain live throughout; no
GC root is replaced with a raw address. No helper boundary or additional scratch
lease is introduced. Branches skip only the same scalar temporary retirement
bookkeeping as before; check any future GC temporary owner at the boundary.

Focused cases should force multiple successive alternatives and exhausted search,
sticky failure versus advancing search, nested greedy/lazy bounded and unbounded
empty repeats, RequiredRun selected=false playback, positive/negative lookaround,
lookbehind/capture rollback, case-insensitive backreferences, named-group state,
Unicode astral and legacy low-surrogate starts, and GC/reentrant RegExp calls from
outer JS. Include the existing counted nullable-progress/required-run cohorts.
Validate emitted Wasm and retain existing original Test262 IDs. Static owned-image
comparison can subsequently measure matcher shrink; do not claim a per-tail byte
size now. The source-proven removable duplication model is 24*B minus new branch
plumbing, where B is the presently unmeasured repeated recovery body.
