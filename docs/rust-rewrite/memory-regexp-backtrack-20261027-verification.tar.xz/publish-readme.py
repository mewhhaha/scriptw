"""Private gated prose publisher; canonical p.publish and visual review come first."""
import hashlib,json,sys
from pathlib import Path
BASE=Path(__file__).resolve().parent;ROOT=BASE.parents[1];DEST=ROOT/'docs/rust-rewrite';STEM='memory-regexp-backtrack-20261027';SOURCE='9001324dc52ce583e7b95a1292f317796d415c01';MEASURED='80b842693e964634f378d5813f6db684ee7d255b'
sys.path.insert(0,str(ROOT/'scripts'))
import precompiled_comparison as p

def sha(path):
 with path.open('rb')as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
r=json.loads((DEST/(STEM+'.json')).read_text());assert r['verified_source_commit']==SOURCE and r['measured_source_commit']==MEASURED and r['native']['passed_disjoint_scopes']==4889 and r['unique_selected_executions']==6307
assert sha(DEST/r['archive']['file'])==r['archive']['sha256']
report,rows=p.load_report(DEST/'precompiled-comparison.json',DEST/'precompiled-comparison.tar.gz');assert report['source_commit']==MEASURED and len(rows)==17 and report['source_fingerprint']==r['source_bindings'][0]['source_fingerprint']
for metric,chart in p.CHARTS.items():assert p.render(report,rows,metric,BASE/f'preview-publication-{metric}.png')==(DEST/'assets'/chart['filename']).read_bytes()
ratios=[row['runtimes']['scriptw']['rss_mib']/row['runtimes']['scriptc']['rss_mib']for row in rows];selected={row['file']:row for row in rows};run=r['measurement']['run']
lines=[f'**Measured 2026-10-27 on one GitHub Actions runner**, compiler `{MEASURED[:9]}`.',
'The [precompiled benchmark workflow](docs/rust-rewrite/contracts/precompiled-comparison.md)',
'compares Scriptw and Scriptc in the same Wasmtime executable. Compilation runs',
'in separate producer processes; measured consumers disable compilation and use',
'identical native optimization and runtime settings. Both passed the original',
'checksums on **17/17 workloads** across two rounds.',
f"Scriptw's median post-execution process RSS remains **{min(ratios):.3f}–{max(ratios):.3f}× Scriptc's**:",'',
'| Workload | Scriptw RSS | Scriptc RSS |','| --- | ---: | ---: |']
for file,label in [('integer.js','Integer'),('objects.js','Objects'),('retained-objects.js','Retained objects')]:
 row=selected[file];lines.append(f"| {label} | {row['runtimes']['scriptw']['rss_mib']:.1f} MiB | {row['runtimes']['scriptc']['rss_mib']:.1f} MiB |")
lines+=['','These are medians of 14 measured samples per runtime and workload after ten',
'checked warmups per round, with each Store still alive. RSS includes code,',
'runtime and allocator history; it is neither live JS heap nor peak memory.',
'Scriptc parity remains open. RegExp recovery and Array.fromAsync fulfilled',
'continuations now share existing in-function paths while retaining state and',
'observable ordering. Cross-runner comparisons do not establish causal savings.','',
f'[Verification](docs/rust-rewrite/{STEM}.md): **4,889 native cases and 6,307 unique',
'original pinned Test262 executions passed**: 2,365 prior selected executions,',
'3,756 RegExp executions and 186 Array.fromAsync executions. The narrower 32-case',
'RegExp and 16-case Unicode selections overlap RegExp and are not additional',
'unique passes. This is not a full pinned-suite refresh. Verification used one',
'CPU, a 4-GiB process-tree cap, no swap and bounded module retention; original',
'executions ran in fresh batches of at most 16.','',
'Paused lifecycle maps remain unscored and separate from canonical graphs.',
'The [phase method](docs/rust-rewrite/memory-phase-boundaries-20261027.md) does',
'not identify heap ownership, peak memory or causal function attribution.','',
'[Execution timing](docs/rust-rewrite/assets/precompiled-execution.svg) ·',
f'[CI run](https://github.com/mewhhaha/scriptw/actions/runs/{run}).','']
readme=ROOT/'README.md';old=readme.read_text();start=old.index('**Measured 2026-10-27 on one GitHub Actions runner**, compiler `a960f50ac`.');end=old.index('\n## Benchmarks',start)
new=old[:start]+'\n'.join(lines)+old[end:];assert new[new.index('\n## Benchmarks'):]==old[end:]
pending='''The RegExp matcher shares one in-function backtracking body while preserving
choice restoration, cursor/capture state and candidate retry order. The
Array.fromAsync fulfilled continuation shares its mapper and commit/drive paths
while retaining await and iterator-close ordering. Verification and measurements
for this pass are pending; see the'''
assert pending in new;new=new.replace(pending,'''The RegExp matcher shares one in-function backtracking body while preserving
choice restoration, cursor/capture state and candidate retry order. The
Array.fromAsync fulfilled continuation shares its mapper and commit/drive paths
while retaining await and iterator-close ordering. See the
[source-bound checkpoint](docs/rust-rewrite/'''+STEM+'''.md), the''',1)
contracts=[]
for name in ['regexp-shared-backtrack.md','array-from-async-shared-fulfilled.md']:
 path=DEST/'contracts'/name;text=path.read_text()
 if name=='regexp-shared-backtrack.md':
  pending='''Compilation, semantic verification
and matched measurements for this batch remain pending.'''
 else:
  pending='''Whole-batch compilation, semantic
verification and matched measurements remain pending.'''
 assert pending in text
 text=text.replace(pending,'The [source-bound checkpoint](../'+STEM+'.md) records successful compilation, 4,889 native cases, 6,307 unique selected original executions and the matched 17-workload cohort. This is not a full pinned-suite refresh.',1)
 text=text.replace('These are verification targets, not reported results.','The checkpoint above records the completed selection; overlap is not counted twice.')
 contracts.append((path,text))
checkpoint=DEST/(STEM+'.md');assert not checkpoint.exists()
text=f'''# Shared RegExp recovery and Array.fromAsync continuation checkpoint

Verified source `{SOURCE}`, measured source `{MEASURED}` (equal compiler inputs; excluded structure-test fixture repair), runtime layout 28, [CI run {run}](https://github.com/mewhhaha/scriptw/actions/runs/{run}).

RegExp's 25 mismatch routes converge on one in-function choice recovery owner. Required/lazy choices, snapshots, byte/UTF-16/low-surrogate cursors and candidate advancement retain their existing state and ordering. Array.fromAsync's closed fulfilled stages converge on one mapper/await path and one commit/drive tail, retaining await-once behavior, indexed writes, defining Realm/program and saved-error/IteratorClose precedence. No additional runtime representation or helper ABI is introduced.

The [static artifact inspection]({STEM}.json) records identical helper extents in Portable and NativeHost modes: RegExp matcher 4,634,312 → 1,243,784 bytes (−3,390,528), and Array.fromAsync Fulfilled 1,302,880 → 511,392 bytes (−791,488). The Portable native image is 72,143,200 → 67,307,296 bytes (−4,835,904); raw Wasm and package sizes each fall by 747,642 bytes. Exact measured-source receipts bind freshly inspected packages and native images; retained historical payload identity does not assert compiler-fingerprint equivalence. These are static code/artifact sizes, not RSS, residency, live heap, or causal memory/timing savings. The initial read-only prior-outdir fingerprint refusal and successful retry streams remain retained, together with six 173-byte source-binding manifests (four historical and two exact measured-source manifests); executable/native-image payloads are excluded.

The [verification record]({STEM}.json) binds the prior accessor checkpoint and every retained native inventory: 4,889 native cases across 19 targets passed. Selected original pinned Test262 coverage is 6,307 unique executions: 2,365 prior selections, all 3,756 RegExp executions and all 186 Array.fromAsync executions. The narrower targeted 32 and Unicode 16 selections are RegExp subsets, not additional unique results. This is not a full pinned-suite refresh. Two focused physical-emission attempts failed stale structural assertions before other native/conformance execution; both stopped reports and streams remain retained, with no invented after snapshots. A successful dirty-test diagnostic probe is separately identified; its receipt is not final-source verification or binary reuse authority. A later cache-test failure and a compile-only fixture typo failure are also retained. All dirty diagnostic probes stay distinct. Final native admission binds only the equal 80b/900 compiler inputs: eight completed 80b scopes contribute 2,172 exact retained cases, the repaired structure probe contributes its full 166-case inventory through committed test-content proof, and ten remaining frozen 80b binaries execute their complete inventories in the final retry. Distinct execution/resource origins are retained. The outer orchestration process stopped while its bounded native child continued; the original incomplete receipt has no invented exit status or after snapshot. A separate continuation receipt binds completed native evidence and records only the remaining CLI build and conformance stages in its own resource scope. The stopped 80b structure attempt (165 passed, one failed) is not counted as a completed scope. Older differing compiler fingerprints are not declared equivalent. Failed/stopped evidence remains in the bounded lossless archive and is not included as successful execution.

Local verification used one CPU, a 4-GiB process-tree cap, no swap and bounded retained-module caches. Original cases ran in fresh batches of at most 16. CI processing and graph review have separate source-bound receipts. The archive excludes native executables/images and duplicate GitHub downloads; its exact byte inventory and roundtrip limits are retained.

The canonical paired report validates all 17 workload checksums over two rounds with separate compilation producers and compiler-disabled consumers in the same Wasmtime executable/configuration. RSS is process residency with Store alive, not live JS heap or peak memory. Cross-runner changes cannot establish causal RSS or timing savings; Scriptc parity remains open. Paused phase captures stay unscored and cannot enter canonical graphs.
'''
checkpoint.write_text(text);readme.write_text(new)
for path,text in contracts:path.write_text(text)
print(json.dumps(dict(source=SOURCE,checkpoint=checkpoint.name)))
