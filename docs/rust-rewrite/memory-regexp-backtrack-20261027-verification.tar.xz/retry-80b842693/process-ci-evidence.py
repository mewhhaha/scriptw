"""Process already-downloaded inert CI evidence in a required LOCAL scope only."""
import argparse,hashlib,json,os,subprocess,sys,time
from pathlib import Path
BASE=Path(__file__).resolve().parent;ROOT=BASE.parents[2]
sys.path.insert(0,str(ROOT/'scripts'))
import precompiled_comparison as p
from limited_verification import require_kernel_budget,kernel_group
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('run');parser.add_argument('--source',required=True)
a=parser.parse_args();assert a.run.isdecimal() and a.source=='80b842693e964634f378d5813f6db684ee7d255b'
require_kernel_budget(4*1024**3);assert sorted(os.sched_getaffinity(0))==[0]
group=kernel_group()
def budget():return {k:(group/k).read_text().strip()for k in ['memory.max','memory.swap.max','memory.oom.group','memory.peak','memory.events']}
def sha(path):
 with path.open('rb')as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
record=dict(source_commit=a.source,run=a.run,complete=False,scored_mutations=False,cpu_affinity=[0],before=budget(),commands=[])
report_path=BASE/f'ci-processing-{a.run}.json';assert not report_path.exists()
def save():report_path.write_text(json.dumps(record,indent=2)+'\n')
def run(name,argv):
 stdout=BASE/f'{name}-{a.run}.stdout';stderr=BASE/f'{name}-{a.run}.stderr';start=time.monotonic()
 with stdout.open('xb')as out,stderr.open('xb')as err:r=subprocess.run([sys.executable,'-B',str(BASE/name),*map(str,argv)],cwd=ROOT,stdout=out,stderr=err,timeout=300)
 record['commands'].append(dict(script=name,args=list(map(str,argv)),exit_code=r.returncode,seconds=time.monotonic()-start,stdout=stdout.name,stdout_sha256=sha(stdout),stderr=stderr.name,stderr_sha256=sha(stderr)));record['after']=budget();save();return r.returncode
save()
code=run('validate-measured.py',[a.run,'--source',a.source]);assert code==0,'scored evidence validation failed; raw attempts retained'
scored=BASE.parent/f'github-{a.run}/precompiled-measurements/precompiled-evidence/report.json';diagnostic=BASE.parent/f'github-{a.run}/precompiled-mapping-diagnostic-unscored'
report,_=p.load_report(scored)
code=run('analyze-phase-maps.py',['--diagnostic',diagnostic,'--scored-report',scored,'--run',a.run,'--expected-source',a.source,'--expected-fingerprint',report['source_fingerprint'],'--expected-executable-sha256',report['tools']['consumer']['sha256'],'--output',BASE/f'ci-phase-components-{a.run}.json'])
record['phase_analysis_status']='validated'if code==0 else 'unavailable-validation-failed';save()
retained=run('retain-phase-raw.py',[a.run,'--source',a.source,'--diagnostic',diagnostic,'--scored-report',scored]);record['raw_retention_status']='validated'if retained==0 else 'unavailable-validation-failed'
record.update(complete=True,after=budget());save()
# Diagnostic failure is separate from a validated scored report; no score mutation.
print(json.dumps(dict(scored_validated=True,phase_analysis_status=record['phase_analysis_status'],raw_retention_status=record['raw_retention_status']),indent=2))
