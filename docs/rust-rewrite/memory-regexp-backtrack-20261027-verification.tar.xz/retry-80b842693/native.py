"""Build affected scopes together, then verify exact native inventories serially."""
from datetime import datetime,timezone
import hashlib,json,os,re,shutil,subprocess,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'scripts'))
from limited_verification import require_kernel_budget,kernel_group
from native_test_protocol import parse_inventory,result_summaries
require_kernel_budget(4*1024**3);assert sorted(os.sched_getaffinity(0))==[0]
SOURCE=os.environ['SCRIPTW_EXPECTED_SOURCE']
assert SOURCE=='80b842693e964634f378d5813f6db684ee7d255b'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==SOURCE
assert os.environ['SCRIPTW_REQUIRED_REPAIR_SOURCE']=='54231ef4d3eb1fa6e1a39f34698d3d0f3668d1b1'
assert subprocess.run(['git','merge-base','--is-ancestor',os.environ['SCRIPTW_REQUIRED_REPAIR_SOURCE'],SOURCE],cwd=ROOT).returncode==0
assert subprocess.run(['git','merge-base','--is-ancestor','00fcf97fbffde8137a67d6ed7ed4803e86384ef1',SOURCE],cwd=ROOT).returncode==0
assert os.environ['SCRIPTW_MODULE_MEMORY_CACHE_ENTRIES']=='1'
assert os.environ['SCRIPTW_MODULE_MEMORY_CACHE_LIMIT_BYTES']==str(64*1024**2)

OUT=BASE/'native';OUT.mkdir(exist_ok=False)
BUILD=ROOT/'target/performance-work-20261024/build'
PLAN=[('scriptw-aot-wasm','scriptw_aot_wasm','lib'),('scriptw-aot-wasm','runtime_link','test'),('scriptw-aot-wasm','structure_builtins','test'),('scriptw-aot-wasm','structure_language','test'),('scriptw-engine','scriptw_engine','lib')]
PLAN += [('scriptw-aot-wasm',name,'test') for name in ['emission','modules_realms','intl_temporal','structure_async']]
PLAN += [('scriptw-engine',name,'test') for name in ['aot_builtins','aot_gc_entries','aot_realm_modules','aot_language','aot_async','aot_generators','aot_regexp','aot_intl','aot_temporal','structure']]
gc_scope=('scriptw-engine','aot_gc_entries','test')
PLAN.remove(gc_scope);PLAN.insert(2,gc_scope)
engine_scope=('scriptw-engine','scriptw_engine','lib')
PLAN.remove(engine_scope);PLAN.insert(1,engine_scope)
# Run the new recovery controls before adjacent exact inventories.
for name in reversed(['emission','modules_realms','intl_temporal']):
 scope=('scriptw-aot-wasm',name,'test');PLAN.remove(scope);PLAN.insert(0,scope)
PLAN.remove(gc_scope); PLAN.insert(0,gc_scope)
for scope in reversed([('scriptw-aot-wasm','emission','test'),('scriptw-engine','aot_regexp','test')]):
 PLAN.remove(scope);PLAN.insert(0,scope)
# Isolate the repaired cache contract before any full scope.
PLAN.remove(engine_scope);PLAN.insert(0,engine_scope)
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def stamp():return datetime.now(timezone.utc).isoformat()
group=kernel_group()
def budget():return {k:(group/k).read_text().strip() for k in ['memory.max','memory.swap.max','memory.oom.group','memory.peak','memory.events']}
report=dict(source_commit=SOURCE,complete=False,started_at=stamp(),cpu_affinity=sorted(os.sched_getaffinity(0)),before=budget(),commands=[],scopes=[])
def save():(OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n')
def source():
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==SOURCE
 assert not subprocess.check_output(['git','diff','--binary','HEAD','--','crates','vendor','scripts','Cargo.toml','Cargo.lock'],cwd=ROOT)
def run(label,args,cwd=ROOT):
 source();row=dict(label=label,command=list(map(str,args)),cwd=str(cwd),started_at=stamp(),stdout=label+'.stdout',stderr=label+'.stderr')
 report['commands'].append(row);save();print(label,'started',flush=True);start=time.monotonic()
 with (OUT/row['stdout']).open('xb') as out,(OUT/row['stderr']).open('xb') as err:
  child=subprocess.run(row['command'],cwd=cwd,stdout=out,stderr=err,timeout=3600)
 row.update(exit_code=child.returncode,seconds=time.monotonic()-start,stdout_sha256=sha(OUT/row['stdout']),stderr_sha256=sha(OUT/row['stderr']));save()
 assert child.returncode==0,label+' failed; original streams retained'
 return (OUT/row['stdout']).read_text()
args=['cargo','test','--locked','--offline','--release','--jobs','1','--target-dir',BUILD,'-p','scriptw-engine','-p','scriptw-aot-wasm','--lib']
for name in sorted({n for _,n,k in PLAN if k=='test'}):args+=['--test',name]
args+=['--no-run','--message-format=json']
text=run('cargo-native',args);cargo=[json.loads(x) for x in text.splitlines()]
assert cargo[-1]==dict(reason='build-finished',success=True)
for package,name,kind in PLAN:
 producers=[r for r in cargo if r.get('reason')=='compiler-artifact' and r.get('executable') and r['target']['name']==name and r['target']['kind']==[kind] and r['profile']['test']]
 assert len(producers)==1,(package,name)
 producer=producers[0];original=Path(producer['executable']);folder=OUT/(package+'-'+name);folder.mkdir()
 binary=folder/'tests';shutil.copy2(original,binary);assert sha(binary)==sha(original) and binary.stat().st_nlink==1
 scope=dict(package=package,target=name,kind=kind,executable_sha256=sha(binary),cargo_producer=producer,complete=False)
 report['scopes'].append(scope);save()
 inventory=parse_inventory(run(package+'-'+name+'-inventory',[binary,'--list'],ROOT/'crates'/package));scope['inventory']=inventory;save()
 baseline=json.loads((ROOT/'target/memory-eager-accessors-20261027-evidence/retry-00fcf97fb/native/report.json').read_text())
 assert baseline['complete'] and len(baseline['scopes'])==19 and baseline['passed_disjoint_scopes']==4881
 assert baseline['source_commit']=='00fcf97fbffde8137a67d6ed7ed4803e86384ef1'
 previous=[s for s in baseline['scopes'] if s['package']==package and s['target']==name];assert len(previous)==1
 assert set(previous[0]['inventory'])<=set(inventory),'no previously verified native ID may disappear'
 if name=='scriptw_engine':
  cache_case='runtime_profile::native_mode_cohort_tests::forced_modes_are_reported_exactly_and_reuse_only_their_own_cached_modules'
  assert cache_case in inventory
  focused_text=run(package+'-'+name+'-cache-focused',[binary,'--exact','--include-ignored','--test-threads=1',cache_case],ROOT/'crates'/package)
  assert result_summaries(focused_text)==[('ok','1','0','0','0',str(len(inventory)-1))]
  assert re.findall(r'^test ([^\r\n]+) \.\.\. ok$',focused_text,re.M)==[cache_case]
  scope['cache_focused_overlap']=[cache_case];save()
 if name in ('emission','aot_regexp','scriptw_aot_wasm','aot_gc_entries'):
  focused=[n for n in inventory if any(part in n for part in ('regexp_shared_recovery::','aot_regexp_shared_recovery::','array_from_async_shared_tail::','aot_gc_array_from_async_shared_tail::'))]
  assert len(focused)==(1 if name in ('emission','scriptw_aot_wasm') else 3)
  assert focused,(package,name)
  focus_chunks=[focused[i:i+8] for i in range(0,len(focused),8)] if name in ('scriptw_engine','aot_gc_entries') else [focused]
  for focus_index,focus_chunk in enumerate(focus_chunks):
   focused_text=run(package+'-'+name+f'-focused-{focus_index:02d}',[binary,'--exact','--include-ignored','--test-threads=1',*focus_chunk],ROOT/'crates'/package)
   focused_names=[n.removesuffix(' - should panic') for n in re.findall(r'^test ([^\r\n]+) \.\.\. ok$',focused_text,re.M)]
   assert len(focused_names)==len(focus_chunk) and set(focused_names)==set(focus_chunk)
  scope['focused_overlap']=focused;save()
 chunks=[inventory[i:i+8] for i in range(0,len(inventory),8)] if name in ('scriptw_engine','aot_gc_entries') else [inventory]
 passed=set()
 for index,chunk in enumerate(chunks):
  label=package+'-'+name+f'-part-{index:03d}'
  # Explicit exact names allow small processes without reducing scope or skipping ignored cases.
  text=run(label,[binary,'--exact','--include-ignored','--test-threads=1',*chunk],ROOT/'crates'/package)
  names=[n.removesuffix(' - should panic') for n in re.findall(r'^test ([^\r\n]+) \.\.\. ok$',text,re.M)]
  assert len(names)==len(chunk) and set(names)==set(chunk) and not passed.intersection(names),(label,names,chunk)
  assert result_summaries(text)==[('ok',str(len(chunk)),'0','0','0',str(len(inventory)-len(chunk)))],label
  passed.update(names);scope['passed']=len(passed);save()
 assert passed==set(inventory) and sha(binary)==scope['executable_sha256']
 scope['complete']=True;save();print(package,name,len(passed),'passed',flush=True)
assert len(report['scopes'])==len(PLAN)==19
assert sum(x['passed'] for x in report['scopes'])==4889
report.update(complete=True,finished_at=stamp(),after=budget(),passed_disjoint_scopes=sum(x['passed'] for x in report['scopes']));save()
print('complete',report['passed_disjoint_scopes'],'native cases',flush=True)
