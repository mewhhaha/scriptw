"""Source-bound 80b static evidence; no compiler-fingerprint equivalence claim."""
from pathlib import Path
import importlib.util,json,hashlib,struct
BASE=Path(__file__).resolve().parent;OLD=BASE.parent;ROOT=BASE.parents[2]
SOURCE='80b842693e964634f378d5813f6db684ee7d255b'
def read(p):return json.loads(p.read_text())
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
check=read(BASE/'check.json');assert check['complete'] is True and check['exit_code']==0 and check['source_commit']==SOURCE
log=BASE/'cargo-check.jsonl';assert sha(log)==check['stdout_sha256']
producers=[r for line in log.read_bytes().splitlines() if line.startswith(b'{') for r in [json.loads(line)] if r.get('reason')=='build-script-executed' and r.get('package_id')=='path+file:///home/mewhhaha/src/porffor/crates/scriptw-runtime-image#0.1.0'];assert len(producers)==1
bindings=read(BASE/'source-bindings-computed.json');local=next(r for r in bindings if r['revision']==SOURCE and r['extra_ignored_regress_lock'])
assert local['source_fingerprint']=='389b93f714f9942334916c2c1673a158182962e5594384c27333235ac3aaaf46'
prior_path=OLD/'owned-r-static.json';prior=read(prior_path);assert prior['source_commit']=='a26f8c9796d3d7284f5bc0537df1dd336c1641b6'
priorcheck=Path(prior['current_check']['path']);assert sha(priorcheck)==prior['current_check']['sha256']
assert read(priorcheck)['complete'] is True and read(priorcheck)['exit_code']==0
spec=importlib.util.spec_from_file_location('owned_static_reader',OLD/'inspect-owned-r-static.py');reader=importlib.util.module_from_spec(spec);spec.loader.exec_module(reader);reader.BASE=BASE
variants={}
for portable in (True,False):
 mode='Portable' if portable else 'NativeHost';old=prior['variants'][mode]
 assert old['available']
 # Before facts remain the retained source-bound inspection; never pretend
 # that an overwritten Cargo outdir still contains the old source's bytes.
 for label in ('prior','current'):
  row=old[label];stream=row['symbol_command']
  assert sha(OLD/stream['stdout'])==stream['stdout_sha256'] and sha(OLD/stream['stderr'])==stream['stderr_sha256']
  assert sha(OLD/row['manifest']['retained_copy'])==row['manifest']['sha256']
 current=reader.inspect('current80-'+mode,Path(producers[0]['out_dir']),local['source_fingerprint'],28,portable)
 for k in ('configuration','modes','target'):assert current['manifest'][k]==old['current']['manifest'][k]
 raw=Path(current['package']['path']).read_bytes();wasm=raw[136:-32];assert len(wasm)==current['package']['wasm_bytes']
 assert hashlib.sha256(struct.pack('<I',28)+wasm).hexdigest()==current['manifest']['runtime_key']
 # Reconstruct only the historical header/footer, and compare its digest to
 # the previously inspected package. This proves the remaining payload bytes
 # under the retained SHA authority; it is not a fresh historical inspection.
 reconstructed=bytearray(raw);reconstructed[12:44]=bytes.fromhex(old['current']['package']['source_fingerprint']);reconstructed[-32:]=hashlib.sha256(reconstructed[:-32]).digest()
 reconstructed_sha=hashlib.sha256(reconstructed).hexdigest();assert reconstructed_sha==old['current']['package']['sha256']
 assert current['manifest']['runtime_key']==old['current']['manifest']['runtime_key']
 assert current['native']['sha256']==old['current']['native']['sha256']
 assert current['helper_native_bytes']==old['current']['helper_native_bytes']
 manifest_path=BASE/('current80-'+mode+'-manifest.bin');assert not manifest_path.exists();manifest_path.write_bytes(Path(current['manifest']['path']).read_bytes());current['manifest']['retained_copy']=manifest_path.name
 baseline=old['prior']
 variants[mode]=dict(current=current,wasm_sha256=hashlib.sha256(wasm).hexdigest(),a26_retained_fact=old['current'],a26_payload_identity=dict(proof='current package with historical fingerprint/header digest reconstructed matches retained actual a26 package SHA; matching runtime-key additionally binds layout+Wasm',reconstructed_a26_package_sha256=reconstructed_sha,native_elf_sha256_equal=True,helper_sizes_equal=True),prior_accessor_retained_fact=baseline,deltas_from_accessor=dict(raw_wasm_bytes=current['package']['wasm_bytes']-baseline['package']['wasm_bytes'],native_image_bytes=current['native']['bytes']-baseline['native']['bytes'],helper_native_bytes={k:current['helper_native_bytes'][k]-baseline['helper_native_bytes'][k] for k in baseline['helper_native_bytes']}))
result=dict(source_commit=SOURCE,source_fingerprint=local['source_fingerprint'],compiler_fingerprint_equivalence_claim=False,scored=False,scope='Static owned package/Wasm/native ELF evidence only; not RSS or causal memory savings. No compilation/deserialization/native execution.',check=dict(path=str(BASE/'check.json'),sha256=sha(BASE/'check.json'),stdout_sha256=sha(log)),cargo_producer=producers[0],source_bindings_sha256=sha(BASE/'source-bindings-computed.json'),retained_a26_static_proof=dict(path=str(prior_path),sha256=sha(prior_path)),variants=variants)
out=BASE/'owned-r-static.json';assert not out.exists();out.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({m:dict(native_elf_sha256=v['current']['native']['sha256'],helper_native_bytes=v['current']['helper_native_bytes'],deltas_from_accessor=v['deltas_from_accessor'],a26_payload_identity=v['a26_payload_identity']) for m,v in variants.items()},indent=2))
