"""Render source-validated scored evidence into private previews only."""
import json,os,sys,subprocess
from pathlib import Path
BASE=Path(__file__).resolve().parent;ROOT=BASE.parents[2]
sys.path.insert(0,str(ROOT/'scripts'))
import precompiled_comparison as p
from limited_verification import require_kernel_budget
require_kernel_budget(1024**3);assert sorted(os.sched_getaffinity(0))==[0]
report,rows=p.load_report(BASE.parent/'github-40578330181/precompiled-measurements/precompiled-evidence/report.json')
summary=json.loads((BASE/'measured-summary.json').read_text())
assert summary['run']=='40578330181' and report['source_commit']==summary['source']=='80b842693e964634f378d5813f6db684ee7d255b'
assert p.digest(BASE.parent/'github-40578330181/precompiled-measurements/precompiled-evidence/report.json')==summary['report_sha256']
for metric in p.CHARTS:
 svg=BASE/('preview-'+metric+'.svg');png=svg.with_suffix('.png');assert not svg.exists() and not png.exists()
 svg.write_bytes(p.render(report,rows,metric))
 subprocess.run(['rsvg-convert','-o',str(png),str(svg)],check=True,timeout=60)
 print(svg.name,p.digest(svg),png.name,p.digest(png),flush=True)
