"""Validate and describe inert phase-barrier CI evidence; never execute images.

Requires the integrated diagnostic-v2 reader. All authority arguments are supplied
when actual CI evidence arrives; this file contains no assumed run/source IDs.
Raw smaps and streams remain lossless in the original diagnostic directory.
"""
import argparse
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import re
import stat
import sys

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[2]
sys.path.insert(0, str(ROOT/'scripts'))
import precompiled_comparison as p

PHASES = ('after_transport_drop', 'after_instantiate', 'after_execution', 'after_store_drop')
OBSERVATION = 16
MAX_READ = 2*1024**2
MAX_TOTAL = 64*1024**2
MAX_CONTROL = 1024
TIMING_FLAG = 'diagnostic_total_timings_include_barrier_waits'


def require(value, reason):
    p.require(value, reason)


def safe_bytes(folder, name, maximum):
    require(isinstance(name, str) and Path(name).name == name and name not in ('.', '..'), 'unsafe evidence filename')
    path = folder/name
    info = path.lstat()
    require(stat.S_ISREG(info.st_mode) and not path.is_symlink() and info.st_size <= maximum,
            'nonregular/symlinked/oversized evidence')
    raw = path.read_bytes()
    require(len(raw) == info.st_size, 'evidence extent changed while reading')
    return raw


def checked_bytes(folder, row, maximum):
    raw = safe_bytes(folder, row['path'], maximum)
    require(type(row['bytes']) is int and row['bytes'] == len(raw)
            and hashlib.sha256(raw).hexdigest() == row['sha256'], 'raw evidence length/hash mismatch')
    return raw


def group_rows(rows, host, inode):
    grouped = {}
    named = {}
    counters = (('rss_bytes', 'Rss'), ('pss_bytes', 'Pss'),
                ('private_dirty_bytes', 'Private_Dirty'), ('anonymous_bytes', 'Anonymous'),
                ('anon_huge_bytes', 'AnonHugePages'))
    for row in rows:
        path, permissions = row['path'], row['permissions']
        host_mapping = path == host and row['inode'] == inode
        if host_mapping:
            category = 'exact_host_' + ('rx' if permissions == 'r-xp' else 'ro' if permissions == 'r--p' else 'other')
        elif path.startswith('[stack'):
            category = 'stack'
        elif path in ('[vdso]', '[vvar]', '[vvar_vclock]', '[vsyscall]'):
            category = 'named_kernel'
        elif 'x' in permissions:
            category = 'other_rx'
        elif permissions.startswith('r--'):
            category = 'other_ro'
        elif 'w' in permissions:
            category = 'file_rw' if row['inode'] != 0 or path.startswith('/') else 'anonymous_rw'
        else:
            category = 'other_permissions'
        group = grouped.setdefault(category, dict(mappings=0, virtual_bytes=0,
            **{target: 0 for target, _ in counters}))
        group['mappings'] += 1
        group['virtual_bytes'] += row['end']-row['start']
        for target, field in counters:
            group[target] += row.get(field, 0)
        if path:
            key = (path, row['inode'], tuple(row['device']), permissions)
            entry = named.setdefault(key, dict(path=path, inode=row['inode'], device=row['device'],
                permissions=permissions, rss_bytes=0, private_dirty_bytes=0))
            entry['rss_bytes'] += row['Rss']
            entry['private_dirty_bytes'] += row.get('Private_Dirty', 0)
    require(sum(row['rss_bytes'] for row in grouped.values()) == sum(row['Rss'] for row in rows),
            'mapping partition lost RSS')
    return grouped, sorted(named.values(), key=lambda row: (row['path'], row['inode'], row['permissions']))


def check_presence(snapshot, rows, host):
    presence = snapshot.get('executable_presence')
    if presence is None:
        return
    if presence.get('status') == 'unavailable':
        require(set(presence) == {'status', 'error'} and isinstance(presence['error'], str),
                'invalid unavailable presence metadata')
        return
    require(set(presence) == {'status', 'mappings'} and presence['status'] == 'present-bits-only-no-PFNs',
            'unexpected pagemap data; only present bits are admitted')
    selected = [row for row in rows if row['path'] == host and row['permissions'] in ('r--p', 'r-xp')]
    require(len(presence['mappings']) == len(selected), 'presence mapping set differs')
    pages = 0
    for value, mapping in zip(presence['mappings'], selected):
        require(set(value) == {'file_offset', 'permissions', 'page_bytes', 'pages', 'present_bits_lsb_hex'},
                'presence has extra fields')
        page = value['page_bytes']
        count = value['pages']
        require(type(page) is int and page > 0 and page & (page-1) == 0
                and type(count) is int and count >= 0
                and mapping['end']-mapping['start'] == count*page
                and value['file_offset'] == mapping['file_offset']
                and value['permissions'] == mapping['permissions'], 'presence extent differs')
        require(isinstance(value['present_bits_lsb_hex'], str)
                and re.fullmatch('[0-9a-f]*', value['present_bits_lsb_hex']) is not None, 'invalid presence encoding')
        bits = bytes.fromhex(value['present_bits_lsb_hex'])
        require(len(bits) == (count+7)//8 and (not count % 8 or bits[-1] >> (count % 8) == 0),
                'invalid presence bit extent/padding')
        pages += count
    require(pages <= 65536, 'presence page bound exceeded')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--diagnostic', required=True, type=Path, help='inert v2 artifact directory')
    parser.add_argument('--scored-report', required=True, type=Path, help='actual admitted paired CI report')
    parser.add_argument('--scored-archive', type=Path, help='optional raw paired report archive')
    parser.add_argument('--run', required=True)
    parser.add_argument('--expected-source', required=True)
    parser.add_argument('--expected-fingerprint', required=True)
    parser.add_argument('--expected-executable-sha256', required=True)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    require(args.run.isdecimal() and re.fullmatch('[0-9a-f]{40}', args.expected_source), 'invalid expected run/source')
    require(all(re.fullmatch('[0-9a-f]{64}', value) for value in
                (args.expected_fingerprint, args.expected_executable_sha256)), 'invalid expected identities')
    folder = args.diagnostic.resolve(strict=True)
    spec = importlib.util.spec_from_file_location('phase_diagnostic_reader', ROOT/'scripts/diagnose-precompiled-mappings.py')
    d = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(d)
    require(tuple(d.PHASES) == PHASES and d.MAX_SNAPSHOTS == 4, 'requires integrated diagnostic-v2 reader')
    scored, scored_rows = p.load_report(args.scored_report, args.scored_archive)
    require(scored['github_run_url'].endswith('/actions/runs/'+args.run), 'CI run differs')
    require(scored['source_commit'] == args.expected_source
            and scored['source_fingerprint'] == args.expected_fingerprint
            and scored['tools']['consumer']['sha256'] == args.expected_executable_sha256,
            'scored source/executable authority differs')
    require(scored['warmups'] == 10 and scored['samples'] == 7 and scored['rounds'] == 2
            and len(scored_rows) == 17
            and all(row['runtimes'][runtime]['status'] == 'ok' for row in scored_rows for runtime in p.RUNTIMES),
            'scored campaign is not the complete matched cohort')
    raw_report = safe_bytes(folder, 'report.json', MAX_TOTAL)
    report = d.unique_json(raw_report)
    require(report['schema'] == 'scriptw-precompiled-mapping-diagnostic-v2'
            and report['status'] == 'captured' and report['scored'] is False
            and report['excluded_from_scored_cohorts'] is True, 'incomplete/scored/non-v2 diagnostic')
    require(report['limits'] == dict(deadline_seconds_per_case=120, snapshots_per_case=4,
            raw_smaps_total_bytes=MAX_TOTAL, stream_bytes_per_case=MAX_READ, control_bytes_per_case=MAX_CONTROL),
            'diagnostic capture limits differ')
    require(report['source_commit'] == scored['source_commit']
            and report['source_fingerprint'] == scored['source_fingerprint']
            and report['executable_sha256'] == scored['tools']['consumer']['sha256']
            and report['scored_report_sha256'] == p.digest(args.scored_report)
            and report['shared_configuration'] == scored['shared_configuration'], 'diagnostic campaign binding differs')
    for moment in ('before', 'after'):
        budget = report['resources'][moment]
        require(len(budget['cpu_affinity']) == 1, 'not one CPU')
        counters = budget['counters']
        require(counters['memory.max'] == '4294967296' and counters['memory.swap.max'] == '0'
                and counters['memory.oom.group'] == '1', 'resource scope differs')
    before = dict(line.split() for line in report['resources']['before']['counters']['memory.events'].splitlines())
    after = dict(line.split() for line in report['resources']['after']['counters']['memory.events'].splitlines())
    require(all(before[key] == after[key] for key in ('oom', 'oom_kill', 'oom_group_kill')), 'diagnostic scope OOM events')
    expected = {(runtime, name) for runtime in p.RUNTIMES for name in ('integer.js', 'retained-objects.js')}
    require(len(report['cases']) == 4 and {(row['runtime'], row['file']) for row in report['cases']} == expected,
            'diagnostic case set differs')
    result = dict(schema='scriptw-precompiled-phase-mapping-analysis-v1', scored=False,
        excluded_from_scored_cohorts=True, run=args.run, github_run_url=scored['github_run_url'],
        source_commit=scored['source_commit'], source_fingerprint=scored['source_fingerprint'],
        executable_sha256=report['executable_sha256'], scored_report_sha256=report['scored_report_sha256'],
        diagnostic_report_sha256=hashlib.sha256(raw_report).hexdigest(), observation_index=OBSERVATION,
        interpretation=('Paused, unscored phase-aligned process mappings, neither live JS allocation ownership nor peak RSS. '
          'The loading capture precedes all observations. Instantiate/execution/drop captures select observation 16, '
          'after 16 earlier invocations. Loading-to-warmed-setup includes warmup/allocator/history effects and cannot '
          'identify pure instantiation cost. No wait is subtracted and no diagnostic timing enters scored cohorts. '
          'Mapping groups describe permissions and recorded paths only; names do not establish allocation owners.'),
        cases=[], phase_comparison=[])
    total = 0
    inodes = set()
    nonces = set()
    for case in report['cases']:
        require(case['status'] == 'captured' and type(case['returncode']) is int and case['returncode'] == 0
                and case['endpoint_stdout_validated'] is True and case['phase_attribution_validated'] is True
                and type(case['observation_index']) is int and case['observation_index'] == OBSERVATION
                and case['completed_phases'] == list(PHASES), 'case not finally admitted')
        nonce = case['nonce']
        require(re.fullmatch('[0-9a-f]{32}', nonce) is not None and nonce not in nonces, 'invalid/reused capture nonce')
        nonces.add(nonce)
        attempt = next(row for row in scored['attempts'] if row['runtime'] == case['runtime'] and row['file'] == case['file'] and row['round'] == 0)
        command = next(row for row in scored['commands'] if row['id'] == attempt['consumer_id'])
        require(case['argv'] == command['argv'] and case['image_sha256'] == attempt['image']['sha256'], 'case command/image binding differs')
        host = scored['tools']['consumer']['path']
        require(case['argv'][0] == host, 'case executable path differs')
        directory = folder/(case['runtime']+'-'+case['file'])
        require(not directory.is_symlink() and directory.resolve().parent == folder, 'unsafe case folder')
        streams = {name: checked_bytes(directory, case[name], MAX_CONTROL if name == 'control' else MAX_READ)
                   for name in ('stdout', 'stderr', 'control')}
        require(sum(len(streams[name]) for name in ('stdout', 'stderr')) <= MAX_READ, 'combined stream bound exceeded')
        expected_control = ''.join(f'SWPHASE1 {nonce} {seq} {phase} {OBSERVATION}\n' for seq, phase in enumerate(PHASES, 1)).encode()
        require(streams['control'] == expected_control, 'raw control transcript differs')
        workload = next(row for row in scored['workloads'] if row['file'] == case['file'])
        d.validate_endpoint(streams['stdout'], scored, attempt['image'], workload, case['runtime'], nonce, OBSERVATION)
        endpoint = d.unique_json(streams['stdout'])
        require(endpoint[TIMING_FLAG] is True, 'diagnostic waits not honestly labeled')
        require(len(case['snapshots']) == 4, 'not four phase captures')
        entry = dict(runtime=case['runtime'], file=case['file'], nonce=nonce, phases=[])
        for seq, (phase, snapshot) in enumerate(zip(PHASES, case['snapshots']), 1):
            require(snapshot['phase'] == phase and type(snapshot['sequence']) is int and snapshot['sequence'] == seq
                    and type(snapshot['observation_index']) is int and snapshot['observation_index'] == OBSERVATION and snapshot['nonce'] == nonce,
                    'snapshot phase/index/nonce/order differs')
            raw = checked_bytes(directory, snapshot, MAX_READ)
            total += len(raw)
            require(total <= MAX_TOTAL, 'smaps total bound exceeded')
            rows = d.mappings(raw)
            require(all(set(('Rss', 'Pss', 'Private_Dirty', 'Anonymous', 'AnonHugePages', 'KernelPageSize')) <= set(row) for row in rows),
                    'missing grouped smaps counters')
            require(all(left['end'] <= right['start'] for left, right in zip(rows, rows[1:])), 'overlapping/unordered smaps')
            require(rows == snapshot['mappings'] and sum(row['Rss'] for row in rows) == snapshot['rss_bytes'], 'smaps rederivation differs')
            inode = snapshot['proc_exe']['inode']
            require(type(inode) is int and inode > 0
                    and any(row['path'] == host and row['inode'] == inode and row['permissions'] == 'r-xp' for row in rows),
                    'snapshot executable identity proof differs')
            inodes.add(inode)
            check_presence(snapshot, rows, host)
            require(type(snapshot['unscored_capture_seconds']) in (int, float)
                    and math.isfinite(snapshot['unscored_capture_seconds']) and snapshot['unscored_capture_seconds'] >= 0,
                    'invalid unscored capture duration')
            groups, named = group_rows(rows, host, inode)
            entry['phases'].append(dict(phase=phase, rss_bytes=snapshot['rss_bytes'], rss_mib=snapshot['rss_bytes']/2**20,
                groups=groups, named_mapping_evidence=named,
                raw_smaps=dict(case_directory=directory.name, path=snapshot['path'], bytes=len(raw), sha256=snapshot['sha256'])))
        result['cases'].append(entry)
    require(len(inodes) == 1, 'case executable inode changed')
    for name in ('integer.js', 'retained-objects.js'):
        for phase in PHASES:
            row = dict(file=name, phase=phase)
            for runtime in p.RUNTIMES:
                case = next(case for case in result['cases'] if case['file'] == name and case['runtime'] == runtime)
                sample = next(sample for sample in case['phases'] if sample['phase'] == phase)
                row[runtime+'_rss_mib'] = sample['rss_mib']
            result['phase_comparison'].append(row)
    result['validated_raw_smaps_bytes'] = total
    # Preserve all raw inputs in place. Output is a separate inert summary.
    require(not args.output.exists() and args.output.resolve() != folder/'report.json', 'output would overwrite evidence')
    with args.output.open('x') as stream:
        stream.write(json.dumps(result, indent=2)+'\n')
    print(json.dumps(dict(run=args.run, source=result['source_commit'], phase_comparison=result['phase_comparison']), indent=2))


if __name__ == '__main__':
    main()
