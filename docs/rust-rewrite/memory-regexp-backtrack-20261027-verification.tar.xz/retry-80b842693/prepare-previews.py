"""Private scored raw-copy/preview/check receipt. Does not publish."""
import os,sys,json,hashlib,subprocess,time,shutil
from pathlib import Path
BASE=Path(__file__).resolve().parent;ROOT=BASE.parents[2]
sys.path.insert(0,str(ROOT/'scripts'))
from limited_verification import require_kernel_budget,kernel_group
require_kernel_budget(1024**3);assert sorted(os.sched_getaffinity(0))==[0]
RUN='40578330181';SOURCE='80b842693e964634f378d5813f6db684ee7d255b'
group=kernel_group()
def counters():return {k:(group/k).read_text().strip() for k in ['memory.max','memory.swap.max','memory.oom.group','memory.peak','memory.events']}
def sha(path):
 with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
receipt=BASE/'preview-processing.json';assert not receipt.exists()
processing=BASE/f'ci-processing-{RUN}.json';checked=json.loads(processing.read_text());assert checked['complete'] and checked['run']==RUN and checked['source_commit']==SOURCE
assert checked['scored_mutations'] is False and checked['cpu_affinity']==[0]
assert len(checked['commands'])==3 and checked['commands'][0]['script']=='validate-measured.py' and checked['commands'][0]['exit_code']==0
for command in checked['commands']:
 for channel in ['stdout','stderr']:assert sha(BASE/command[channel])==command[channel+'_sha256']
for moment in ['before','after']:
 values=checked[moment];assert 0<int(values['memory.max'])<=4*1024**3 and values['memory.swap.max']=='0' and values['memory.oom.group']=='1'
events=[dict(line.split() for line in checked[m]['memory.events'].splitlines()) for m in ['before','after']]
assert all(events[0][key]==events[1][key] for key in ['oom','oom_kill','oom_group_kill'])
report=BASE.parent/f'github-{RUN}/precompiled-measurements/precompiled-evidence/report.json'
summary=json.loads((BASE/'measured-summary.json').read_text());assert summary['source']==SOURCE and summary['run']==RUN and summary['report_sha256']==sha(report)
github=BASE.parent/f'github-run-{RUN}.json';metadata=json.loads(github.read_text());assert metadata['databaseId']==int(RUN) and metadata['headSha']==SOURCE and metadata['status']=='completed' and metadata['conclusion']=='success'
record=dict(source_commit=SOURCE,run=RUN,complete=False,scored_mutations=False,cpu_affinity=[0],ci_processing_sha256=sha(processing),github_run_sha256=sha(github),before=counters(),commands=[])
def save():receipt.write_text(json.dumps(record,indent=2)+'\n')
def run(label,args):
 out=BASE/(label+'.stdout');err=BASE/(label+'.stderr');start=time.monotonic()
 with out.open('xb') as a,err.open('xb') as b:r=subprocess.run(args,cwd=ROOT,stdout=a,stderr=b,timeout=300)
 record['commands'].append(dict(label=label,args=[str(v) for v in args],exit_code=r.returncode,seconds=time.monotonic()-start,stdout=out.name,stdout_sha256=sha(out),stderr=err.name,stderr_sha256=sha(err)));record['after']=counters();save()
 if r.returncode:raise SystemExit(r.returncode)
save();os.environ['MPLCONFIGDIR']=str(BASE/'mplconfig')
raw=BASE/f'ci-scored-{RUN}-raw-report.json';assert not raw.exists();shutil.copyfile(report,raw);assert sha(raw)==sha(report)
record['raw_scored_report']=dict(path=raw.name,sha256=sha(raw),bytes=raw.stat().st_size);save()
run('render-previews',[sys.executable,'-B',str(BASE/'render-previews.py')])
run('canonical-p-check',[sys.executable,'-B',str(ROOT/'scripts/precompiled_comparison.py'),'check',str(ROOT/'docs/rust-rewrite/precompiled-comparison.json')])
record['complete']=True;record['after']=counters();save()
