from datetime import datetime,timezone
import hashlib,json,os,subprocess,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'scripts'))
from limited_verification import require_kernel_budget,kernel_group
require_kernel_budget(4*1024**3);assert sorted(os.sched_getaffinity(0))==[0]
SOURCE=os.environ['SCRIPTW_EXPECTED_SOURCE']
assert SOURCE=='1c4f0e3341ef2a223f00b16d849d44b93ae829fc'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==SOURCE
assert os.environ['SCRIPTW_REQUIRED_REPAIR_SOURCE']=='54231ef4d3eb1fa6e1a39f34698d3d0f3668d1b1'
assert subprocess.run(['git','merge-base','--is-ancestor',os.environ['SCRIPTW_REQUIRED_REPAIR_SOURCE'],SOURCE],cwd=ROOT).returncode==0
assert subprocess.run(['git','merge-base','--is-ancestor','00fcf97fbffde8137a67d6ed7ed4803e86384ef1',SOURCE],cwd=ROOT).returncode==0
assert os.environ['SCRIPTW_MODULE_MEMORY_CACHE_ENTRIES']=='1'
assert os.environ['SCRIPTW_MODULE_MEMORY_CACHE_LIMIT_BYTES']==str(64*1024**2)

group=kernel_group()
def budget():return {k:(group/k).read_text().strip() for k in ['memory.max','memory.swap.max','memory.oom.group','memory.peak','memory.events']}
command=['cargo','check','--locked','--offline','--release','--workspace','--all-targets','--jobs','1','--target-dir',str(ROOT/'target/performance-work-20261024/build'),'--message-format=json']
report=dict(source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),complete=False,command=command,before=budget(),cpu_affinity=sorted(os.sched_getaffinity(0)),started_at=datetime.now(timezone.utc).isoformat())
assert not subprocess.check_output(['git','diff','HEAD','--','crates','vendor','scripts','Cargo.toml','Cargo.lock'],cwd=ROOT)
out=BASE/'cargo-check.jsonl';err=BASE/'cargo-check.stderr'
(BASE/'check.json').write_text(json.dumps(report,indent=2)+'\n');start=time.monotonic()
with out.open('xb') as stdout,err.open('xb') as stderr:r=subprocess.run(command,cwd=ROOT,stdout=stdout,stderr=stderr,timeout=7200)
report.update(exit_code=r.returncode,complete=r.returncode==0,seconds=time.monotonic()-start,after=budget(),stdout_sha256=hashlib.sha256(out.read_bytes()).hexdigest(),stderr_sha256=hashlib.sha256(err.read_bytes()).hexdigest())
(BASE/'check.json').write_text(json.dumps(report,indent=2)+'\n');print('cargo check finished',r.returncode,flush=True)
if r.returncode:print(err.read_text()[-12000:],flush=True)
raise SystemExit(r.returncode)
