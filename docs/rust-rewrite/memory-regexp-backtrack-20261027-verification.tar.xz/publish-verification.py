"""Private gated publisher for shared RegExp/Array.fromAsync construction paths."""
import argparse,hashlib,json,lzma,re,subprocess,sys,tarfile
from datetime import datetime,timezone
from pathlib import Path,PurePosixPath
BASE=Path(__file__).resolve().parent;ROOT=BASE.parents[1];DEST=ROOT/'docs/rust-rewrite';STEM='memory-regexp-backtrack-20261027';SOURCE='9001324dc52ce583e7b95a1292f317796d415c01';MEASURED='80b842693e964634f378d5813f6db684ee7d255b';RETRY=BASE/'retry-9001324dc';MEASURED_BASE=BASE/'retry-80b842693'
sys.path.insert(0,str(ROOT/'scripts'))
import precompiled_comparison as p
from native_test_protocol import result_summaries
def read(path):
    return json.loads(path.read_text())

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def streams(directory, commands):
    for row in commands:
        assert row.get('exit_code', row.get('returncode')) == 0
        for key in ('stdout', 'stderr'):
            assert sha(directory/row[key]) == row[key+'_sha256']

def resource(report):
    # Nested conformance reports inherit the driver scope and omit affinity.
    if 'cpu_affinity' in report:
        assert report['cpu_affinity'] == [0]
    for moment in ('before', 'after'):
        values = report[moment]
        assert values['memory.max'] == '4294967296'
        assert values['memory.swap.max'] == '0' and values['memory.oom.group'] == '1'
    before = dict(line.split() for line in report['before']['memory.events'].splitlines())
    after = dict(line.split() for line in report['after']['memory.events'].splitlines())
    assert all(before[key] == after[key] for key in ('oom', 'oom_kill', 'oom_group_kill'))

def conformance(directory, source):
    report = read(directory/'report.json')
    assert report['complete'] and report['source_commit'] == source and report['batch_limit'] == 16
    resource(report)
    streams(directory, report['commands'])
    listing = directory/'executions'
    assert sha(listing) == report['execution_list_sha256']
    selected = listing.read_text().splitlines()
    assert selected and len(selected) == len(set(selected)) == report['selected_executions']
    actual = []
    for part in report['batches']:
        ids_file, snapshot_file = directory/part['list_file'], directory/part['snapshot_file']
        assert sha(ids_file) == part['list_sha256'] and sha(snapshot_file) == part['snapshot_sha256']
        ids = ids_file.read_text().splitlines()
        snapshot = read(snapshot_file)
        assert 0 < len(ids) <= 16 and len(ids) == len(set(ids)) == part['passed'] == snapshot['total'] == snapshot['passed']
        assert snapshot['compiler_identity'] == report['compiler']['identity']
        assert set(snapshot['completed_test_ids']) == set(ids)
        assert not snapshot['failures'] and not snapshot['timeout_test_ids']
        assert snapshot['counts_per_outcome'] == dict(Bug=0, Crash=0, NotImplemented=0, Success=len(ids))
        actual.extend(ids)
    assert len(actual) == len(set(actual)) == report['total'] == report['passed'] == len(selected)
    assert set(actual) == set(selected)
    assert report['compiler']['identity']['source_revision'] == dict(kind='git-commit', commit=source)
    assert report['compiler']['identity']['executable_sha256'] == report['compiler']['sha256']
    return report, set(selected)

parser=argparse.ArgumentParser();parser.add_argument('run');args=parser.parse_args();source=SOURCE
assert args.run=='40578330181'
RECOVERY=BASE/'recovery-parent-20261027'
check=read(RETRY/'check.json');verification=read(RETRY/'verification.json');native=read(RETRY/'native/report.json');cheap=read(RETRY/'cheap-verified/cheap-main.json');continuation=read(RECOVERY/'continuation.json')
for report in [check,native,continuation]:assert report['complete'] and report['source_commit']==source;resource(report)
# The vanished outer driver never reaped native.py or recorded its after counters.
# Its immutable incomplete receipt is lineage, not a successful resource interval.
assert verification['source_commit']==source and verification['complete'] is False and 'after' not in verification
assert verification['cpu_affinity']==[0]
assert verification['before']['memory.max']=='4294967296' and verification['before']['memory.swap.max']=='0' and verification['before']['memory.oom.group']=='1'
assert [(c['label'],c.get('exit_code')) for c in verification['commands']]==[('cheap-main-driver',0),('cargo-check-driver',0),('native-driver',None)]
pending=verification['commands'][2]
assert not any(key in pending for key in ['exit_code','seconds','stdout_sha256','stderr_sha256'])
assert continuation['schema']=='scriptw-outer-verification-continuation-v1'
assert continuation['original_verification']==dict(path=str(RETRY/'verification.json'),sha256=sha(RETRY/'verification.json'),complete=False,resource_after_available=False,native_driver_exit_status_available=False)
completion=continuation['native_completion']
assert completion['path']==str(RETRY/'native/report.json') and completion['sha256']==sha(RETRY/'native/report.json')
assert completion['complete'] is True and completion['passed_disjoint_scopes']==4889 and completion['driver_exit_status_available'] is False
assert completion['resource_origin']=='native/report.json before/after cover its resumed native commands only; inherited native scopes retain their original resource receipts'
for channel in ['stdout','stderr']:
 assert completion['driver_streams'][channel]==dict(path=str(RETRY/pending[channel]),sha256=sha(RETRY/pending[channel]))
assert (RETRY/pending['stdout']).read_text().rstrip().endswith('complete4889: inherited2338 + resumed2551')
assert 'Original outer-driver after counters and native-driver exit status are unavailable' in continuation['resource_scope']
assert continuation['full_regexp_requested'] is True and continuation['full_array_from_async_requested'] is True and continuation['unique_selected_executions']==6307
build=ROOT/'target/performance-work-20261024/build'
expected_plan=[('cargo-products',['cargo','build','--locked','--offline','--release','--jobs','1','--target-dir',str(build),'-p','scriptw-cli','--bin','scriptw','--example','compiler_precompiled_baseline','--message-format=json'])]
for label,flags in [('test262-driver',[]),('test262-unicode-driver',['--unicode']),('test262-regexp-driver',['--regexp']),('test262-regexp-full-driver',['--regexp-full']),('test262-array-from-async-driver',['--array-from-async-full'])]:
 expected_plan.append((label,[pending['command'][0],'-B',str(RETRY/'test262.py'),*flags]))
assert [(c['label'],c['command']) for c in continuation['commands']]==expected_plan
for command in continuation['commands']:
 suffix='.jsonl' if command['label']=='cargo-products' else '.stdout'
 assert (RECOVERY/command['stdout']).resolve()==RETRY/(command['label']+suffix)
 assert (RECOVERY/command['stderr']).resolve()==RETRY/(command['label']+'.stderr')
assert check['exit_code']==0
for key,name in [('stdout','cargo-check.jsonl'),('stderr','cargo-check.stderr')]:assert sha(RETRY/name)==check[key+'_sha256']
streams(RETRY,verification['commands'][:2]);streams(RECOVERY,continuation['commands']);streams(RETRY/'native',native['commands']);streams(RETRY/'native',native['inherited_commands']);streams(RETRY/'cheap-verified',cheap['commands'])
assert cheap['complete'] and cheap['base_commit']==source
assert 'const LAYOUT_VERSION: u32 = 28;'in subprocess.check_output(['git','show',source+':crates/scriptw-aot-wasm/src/runtime_artifact.rs'],cwd=ROOT,text=True)
prior_path=DEST/'memory-eager-accessors-20261027.json';prior=read(prior_path)
assert prior['verified_source_commit']=='00fcf97fbffde8137a67d6ed7ed4803e86384ef1' and prior['native']['passed_disjoint_scopes']==4881
assert len(native['scopes'])==19 and native['passed_disjoint_scopes']==4889
old={(s['package'],s['target']):set(s['inventory'])for s in prior['native']['scopes']}
assert len({(scope['package'],scope['target']) for scope in native['scopes']})==19 and {(scope['package'],scope['target']) for scope in native['scopes']}==set(old)
for scope in native['scopes']:
 inventory=scope['inventory'];assert scope['complete'] and len(inventory)==len(set(inventory))==scope['passed'] and old[(scope['package'],scope['target'])]<=set(inventory)
 prefix=scope['package']+'-'+scope['target']+'-part-';actual=[]
 for command in native['commands']+native['inherited_commands']:
  if not (command['label'].startswith(prefix) or scope['target']=='structure_builtins' and command['label']=='scriptw-aot-wasm-structure_builtins-probe-full-exact'):continue
  raw=(RETRY/'native'/command['stdout']).read_text();names=[n.removesuffix(' - should panic')for n in re.findall(r'^test ([^\r\n]+) \.\.\. ok$',raw,re.M)]
  assert result_summaries(raw)==[('ok',str(len(names)),'0','0','0',str(len(inventory)-len(names)))];actual+=names
 assert len(actual)==len(set(actual))==len(inventory) and set(actual)==set(inventory)
reports={};selections={}
for name,count in [('conformance',2365),('conformance-regexp-full',3756),('conformance-array-from-async',186),('conformance-regexp',32),('conformance-unicode',16)]:
 report,ids=conformance(RETRY/name,source);assert report['total']==count
 reports[name]=report;selections[name]=ids
original=selections['conformance'];regexp=selections['conformance-regexp-full'];array=selections['conformance-array-from-async']
assert original.isdisjoint(regexp) and original.isdisjoint(array) and regexp.isdisjoint(array)
assert len(original|regexp|array)==6307
assert selections['conformance-regexp']<=regexp and selections['conformance-unicode']<=regexp
assert original==set((ROOT/'target/memory-regexp-unicode-data-20261027-evidence/conformance/executions').read_text().splitlines())
for directory,selection in [('conformance-regexp-full','regexp-full-selection.json'),('conformance-array-from-async','array-from-async-full-selection.json')]:
 assert selections[directory]==set(read(RETRY/selection)['expected_executions'])
bindings=read(RETRY/'source-bindings-computed.json');assert len(bindings)==2 and all(row['revision']==source for row in bindings)
clean,local=bindings;assert clean['extra_ignored_regress_lock'] is False and local['extra_ignored_regress_lock'] is True
equivalence=read(RETRY/'source-bindings-closure-equivalence.json');assert equivalence['test_only_repair'] is True and len(equivalence['rows'])==4
assert {(row['revision'],row['extra_ignored_regress_lock']) for row in equivalence['rows']}=={(revision,mode) for revision in [SOURCE,MEASURED] for mode in [False,True]}
for binding in bindings:
 assert all(tuple(row[k] for k in ['source_fingerprint','files','bytes'])==tuple(binding[k] for k in ['source_fingerprint','files','bytes']) for row in equivalence['rows'] if row['extra_ignored_regress_lock']==binding['extra_ignored_regress_lock'])
# Every retry rebuilt from a new exact source fingerprint. No binary reuse.
previous=BASE/'retry-6ff184014'
v=json.loads((previous/'verification.json').read_text());n=json.loads((previous/'native/report.json').read_text());c=json.loads((previous/'check.json').read_text())
assert v['source_commit']==n['source_commit']==c['source_commit']=='6ff1840146c312d3564b322fe13e4bbf0f97527e'
assert not v['complete'] and not n['complete'] and 'after' not in v and 'after' not in n
assert c['complete'] is True and c['exit_code']==0 and sha(previous/'cargo-check.jsonl')==c['stdout_sha256']
assert [(r['label'],r.get('exit_code')) for r in v['commands']]==[('cheap-main-driver',0),('cargo-check-driver',0),('native-driver',1)]
assert [(r['label'],r.get('exit_code')) for r in n['commands'] if r.get('exit_code')]==[('scriptw-engine-scriptw_engine-part-031',101)]
assert len(n['scopes'])==7 and sum(s.get('passed',0) for s in n['scopes'])==1337
assert sum(s['complete'] for s in n['scopes'])==6
assert n['scopes'][-1]['target']=='scriptw_engine' and n['scopes'][-1]['passed']==248 and not n['scopes'][-1]['complete']
from native_test_protocol import result_summaries
assert result_summaries((previous/'native/scriptw-engine-scriptw_engine-part-031.stdout').read_text())==[('FAILED','7','1','0','0','1045')]
for record,folder in ((v,previous),(n,previous/'native')):
 for r in record['commands']:
  for stream in ('stdout','stderr'):assert sha(folder/r[stream])==r[stream+'_sha256']
assert not any((previous/x).exists() for x in ('conformance','conformance-unicode','conformance-regexp','conformance-regexp-full','conformance-array-from-async'))
# Preserve both prior physical-test failures and the successful dirty diagnostic
# probe separately; neither is reinterpreted as a verified source execution.
history={}
for label,folder in [('a26',BASE),('1c4',BASE/'retry-1c4f0e334')]:
 oldv=json.loads((folder/'verification.json').read_text());oldn=json.loads((folder/'native/report.json').read_text());oldc=json.loads((folder/'check.json').read_text())
 assert oldc['complete'] is True and oldc['exit_code']==0 and sha(folder/'cargo-check.jsonl')==oldc['stdout_sha256']
 assert not oldv['complete'] and not oldn['complete'] and 'after' not in oldv and 'after' not in oldn
 assert len(oldn['scopes'])==1 and not oldn['scopes'][0]['complete'] and not oldn['scopes'][0].get('passed')
 assert result_summaries((folder/'native/scriptw-aot-wasm-emission-focused-00.stdout').read_text())==[('FAILED','0','1','0','0','32')]
 for record,subfolder in ((oldv,folder),(oldn,folder/'native')):
  for r in record['commands']:
   for stream in ('stdout','stderr'):assert sha(subfolder/r[stream])==r[stream+'_sha256']
 assert not any((folder/x).exists() for x in ('conformance','conformance-unicode','conformance-regexp','conformance-regexp-full','conformance-array-from-async'))
 history[label]=dict(check_sha256=sha(folder/'check.json'),verification_sha256=sha(folder/'verification.json'),native_report_sha256=sha(folder/'native/report.json'),passed=0,failed=1,completed_scopes=0)
probe_path=BASE/'probe-shared-region/receipt.json';probe=json.loads(probe_path.read_text())
assert probe['complete'] is True and probe['diagnostic_dirty_test'] is True and probe['verified_source_claim'] is False and probe['passed']==1 and probe['filtered_out']==32
for r in probe['commands']:
 for stream in ('stdout','stderr'):assert sha(probe_path.parent/r[stream])==r[stream+'_sha256']
assert sha(probe_path.parent/probe['binary']['path'])==probe['binary']['sha256']
assert sha(probe_path.parent/probe['patch']['path'])==probe['patch']['sha256']
bindings_path=RETRY/'source-bindings-computed.json';bindings=json.loads(bindings_path.read_text())
assert len(bindings)==2 and all(r['revision']==SOURCE for r in bindings)
priorbindings=json.loads((previous/'source-bindings-computed.json').read_text())
for mode in (False,True):
 now=next(r for r in bindings if r['extra_ignored_regress_lock']==mode)
 old=next(r for r in priorbindings if r['extra_ignored_regress_lock']==mode)
 assert now['source_fingerprint']!=old['source_fingerprint'], 'production-file footprint requires fresh closure'
# The field-access compile failure and successful dirty probe remain separate.
failed95=BASE/'retry-95b84740a'
f95=json.loads((failed95/'verification.json').read_text());c95=json.loads((failed95/'check.json').read_text())
assert f95['source_commit']==c95['source_commit']=='95b84740a0c61a2b1cd05eaa2fbd2ce2cf9b35a0'
assert not f95['complete'] and 'after' not in f95 and not c95['complete'] and c95['exit_code']==101
assert [(r['label'],r.get('exit_code')) for r in f95['commands']]==[('cheap-main-driver',0),('cargo-check-driver',101)]
for r in f95['commands']:
 for stream in ('stdout','stderr'):assert sha(failed95/r[stream])==r[stream+'_sha256']
assert sha(failed95/'cargo-check.jsonl')==c95['stdout_sha256'] and sha(failed95/'cargo-check.stderr')==c95['stderr_sha256']
assert not any((failed95/x).exists() for x in ('native','conformance','conformance-unicode','conformance-regexp','conformance-regexp-full','conformance-array-from-async'))
compile_messages=[json.loads(line) for line in (failed95/'cargo-check.jsonl').read_text().splitlines() if line.startswith('{')]
errors=[r['message'] for r in compile_messages if r.get('reason')=='compiler-message' and r['message']['level']=='error']
assert len(errors)==1 and errors[0]['code']['code']=='E0599' and 'runtime' in errors[0]['message']
assert errors[0]['message']=='no method named `runtime` found for struct `Artifact` in the current scope'
assert [(span['file_name'],span['line_start']) for span in errors[0]['spans'] if span['is_primary']]==[('crates/scriptw-engine/src/runtime_profile.rs',599)]
mode_path=BASE/'probe-mode-cache/receipt.json';mode=json.loads(mode_path.read_text())
assert mode['complete'] is True and mode['diagnostic_dirty_test'] is True and mode['verified_source_claim'] is False
assert mode['head_commit']=='95b84740a0c61a2b1cd05eaa2fbd2ce2cf9b35a0' and (mode['passed'],mode['failed'],mode['filtered_out'])==(1,0,1052)
file='crates/scriptw-engine/src/runtime_profile.rs';assert mode['test_path']==file
assert hashlib.sha256(subprocess.check_output(['git','show',SOURCE+':'+file],cwd=ROOT)).hexdigest()==mode['test_source_sha256']
patch=mode_path.parent/mode['patch']['path'];assert sha(patch)==mode['patch']['sha256']
assert subprocess.check_output(['git','diff','--binary',mode['head_commit'],SOURCE,'--',file],cwd=ROOT)==patch.read_bytes()
assert subprocess.check_output(['git','diff','--name-only',mode['head_commit'],MEASURED],cwd=ROOT).decode().splitlines()==[file]
assert sha(mode_path.parent/mode['binary']['path'])==mode['binary']['sha256']
for r in mode['commands']:
 for stream in ('stdout','stderr'):assert sha(mode_path.parent/r[stream])==r[stream+'_sha256']
physical_probe=probe;mode_probe=mode
assert verification['fresh_all19_native_build'] is False and verification['no_native_compilation'] is True and verification['source_bindings_sha256']==sha(RETRY/'source-bindings-computed.json')
assert verification['prior_physical_failures']==history and verification['dirty_probe_receipt_sha256']==sha(probe_path)
assert verification['predecessor_cache_failure']==dict(verification_sha256=sha(previous/'verification.json'),native_report_sha256=sha(previous/'native/report.json'),tracked_passes=1337,completed_scopes=6,partial_engine_passes=248,failed_chunk_passed=7,failed_chunk_failed=1,conformance_executed=False)
assert verification['failed95_check']==dict(verification_sha256=sha(failed95/'verification.json'),check_sha256=sha(failed95/'check.json'),exit_code=101,error='E0599',native_executed=False,conformance_executed=False)
assert verification['mode_cache_diagnostic_probe']==dict(receipt_sha256=sha(mode_path),verified_source_claim=False,final_file_sha256=mode_probe['test_source_sha256'],patch_sha256=sha(patch),passed=1,filtered_out=1052,binary_reused=False)
assert native['native_compilation_executed'] is False
old80=MEASURED_BASE;stopped80=read(old80/'native/report.json');stopped80verification=read(old80/'verification.json')
assert stopped80['source_commit']==stopped80verification['source_commit']==MEASURED and not stopped80['complete'] and not stopped80verification['complete']
assert 'after' not in stopped80 and 'after' not in stopped80verification
for report,folder in [(stopped80,old80/'native'),(stopped80verification,old80)]:
 for command in report['commands']:
  for channel in ['stdout','stderr']:assert sha(folder/command[channel])==command[channel+'_sha256']
assert result_summaries((old80/'native/scriptw-aot-wasm-structure_builtins-part-000.stdout').read_text())==[('FAILED','165','1','0','0','0')]
assert len(stopped80['scopes'])==9 and len([scope for scope in stopped80['scopes'] if scope['complete']])==8 and sum(scope.get('passed',0) for scope in stopped80['scopes'])==2172
assert not any((old80/name).exists() for name in ['conformance','conformance-regexp','conformance-unicode','conformance-regexp-full','conformance-array-from-async'])
structure_dir=BASE/'probe-structure-recovery';structure_probe=read(structure_dir/'receipt.json')
assert structure_probe['complete'] is True and structure_probe['diagnostic_dirty_test'] is True and structure_probe['verified_source_claim'] is False
assert structure_probe['head_commit']==MEASURED and (structure_probe['passed'],structure_probe['failed'],structure_probe['filtered_out'],structure_probe['full_passed'])==(1,0,165,166)
structure_file='crates/scriptw-aot-wasm/tests/structure_builtins/regexp_nullable_quantifier_progress_structure.rs'
assert structure_probe['test_path']==structure_file and subprocess.check_output(['git','diff','--name-only',MEASURED,SOURCE],cwd=ROOT,text=True).splitlines()==[structure_file]
assert hashlib.sha256(subprocess.check_output(['git','show',SOURCE+':'+structure_file],cwd=ROOT)).hexdigest()==structure_probe['test_source_sha256']
structure_patch=structure_dir/structure_probe['patch']['path'];assert sha(structure_patch)==structure_probe['patch']['sha256']
assert subprocess.check_output(['git','diff','--binary',MEASURED,SOURCE,'--',structure_file],cwd=ROOT)==structure_patch.read_bytes()
resource(structure_probe);streams(structure_dir,structure_probe['commands'])
assert [(c['label'],c['exit_code']) for c in structure_probe['commands']]==[('cargo-structure',0),('inventory',0),('focused',0),('full-exact',0)]
assert result_summaries((structure_dir/'focused.stdout').read_text())==[('ok','1','0','0','0','165')]
assert result_summaries((structure_dir/'full-exact.stdout').read_text())==[('ok','166','0','0','0','0')]
admission=dict(kind='verified-prefix-plus-final-content-equivalent-diagnostic-full-scope',closure_proof_sha256=sha(RETRY/'source-bindings-closure-equivalence.json'),stopped80_verification_sha256=sha(old80/'verification.json'),stopped80_native_report_sha256=sha(old80/'native/report.json'),stopped80_passed=165,stopped80_failed=1,inherited_prefix_scopes=8,inherited_prefix_passed=2172,probe_receipt_sha256=sha(structure_dir/'receipt.json'),probe_verified_source_claim=False,final_structure_file_sha256=structure_probe['test_source_sha256'],probe_patch_sha256=sha(structure_patch),probe_binary_sha256=structure_probe['binary']['sha256'],inherited_probe_scope_passed=166,inherited_total_passed=2338,inherited_total_scopes=9,resumed_scopes=10,old_native_after_available=False)
assert verification['native_resume_admission']==native['native_resume_admission']==admission
assert (native['inherited_scopes'],native['inherited_disjoint_passes'],native['executed_scopes'],native['executed_disjoint_passes'])==(9,2338,10,2551)
assert [sum(scope['execution']==kind for scope in native['scopes']) for kind in ['inherited-verified-prefix','inherited-diagnostic-full-scope-after-final-content-admission','executed-in-this-resume']]==[8,1,10]
assert 'resumed commands only' in native['resource_scope']
cache_focus=[c for c in native['inherited_commands'] if c['label']=='scriptw-engine-scriptw_engine-cache-focused'];assert len(cache_focus)==1
assert result_summaries((RETRY/'native'/cache_focus[0]['stdout']).read_text())==[('ok','1','0','0','0','1052')]
frozen=read(RETRY/'frozen-native-binaries.json');assert frozen['source_commit']==MEASURED and len(frozen['binaries'])==19 and frozen['native_report_sha256']==sha(old80/'native/report.json') and frozen['cargo_stdout_sha256']==sha(old80/'native/cargo-native.stdout')
for scope in native['scopes']:
 key=(scope['package'],scope['target']);binary=next(b for b in frozen['binaries'] if (b['package'],b['target'])==key)
 assert scope['executable_sha256']==binary['sha256'] and scope['cargo_producer']==binary['cargo_producer']
 if scope['execution']=='inherited-verified-prefix':
  previous_scope=next(s for s in stopped80['scopes'] if (s['package'],s['target'])==key)
  assert previous_scope['complete'] and all(scope[k]==previous_scope[k] for k in ['inventory','passed','executable_sha256','cargo_producer'])
  origin=scope['origin'];assert origin['source_commit']==MEASURED and origin['native_report_sha256']==sha(old80/'native/report.json') and origin['resource_before']==stopped80['before'] and origin['resource_after_available'] is False and 'resource_after' not in origin
 elif scope['execution']=='inherited-diagnostic-full-scope-after-final-content-admission':
  assert key==('scriptw-aot-wasm','structure_builtins') and scope['inventory']==structure_probe['inventory'] and scope['passed']==166 and scope['executable_sha256']==structure_probe['binary']['sha256']
  origin=scope['origin'];assert origin['verified_source_claim'] is False and origin['receipt_sha256']==sha(structure_dir/'receipt.json') and origin['resource_before']==structure_probe['before'] and origin['resource_after']==structure_probe['after'] and origin['final_source_content_admission']==admission
 else:
  assert scope['execution']=='executed-in-this-resume' and scope['binary_origin_source_commit']==MEASURED
for command in native['inherited_commands']:
 origin=command['origin'];assert origin['executed_in_this_resume'] is False
 for channel in ['stdout','stderr']:
  assert sha(Path(origin[channel]))==command[channel+'_sha256']==sha(RETRY/'native'/command[channel])
for report in reports.values():assert report['compiler']['identity']['source_fingerprint']==local['source_fingerprint']
static=read(MEASURED_BASE/'owned-r-static.json');historical_static=read(BASE/'owned-r-static.json')
assert static['source_commit']==MEASURED and static['source_fingerprint']==local['source_fingerprint'] and static['scored'] is False and static['compiler_fingerprint_equivalence_claim'] is False
assert static['check']['sha256']==sha(MEASURED_BASE/'check.json') and static['check']['stdout_sha256']==sha(MEASURED_BASE/'cargo-check.jsonl')
assert static['source_bindings_sha256']==sha(MEASURED_BASE/'source-bindings-computed.json') and static['retained_a26_static_proof']['sha256']==sha(BASE/'owned-r-static.json')
prior_static=ROOT/'target/memory-eager-accessors-20261027-evidence/owned-r-static.json'
assert historical_static['prior_published_static']['sha256']==sha(prior_static)
assert any(row['path']=='owned-r-static.json' and row['sha256']==sha(prior_static) for row in prior['retained_files'])
manifest_files=set()
for mode in ['Portable','NativeHost']:
 variant=static['variants'][mode];old=historical_static['variants'][mode]
 assert variant['a26_retained_fact']==old['current'] and variant['prior_accessor_retained_fact']==old['prior']
 for phase in ['prior','current']:
  manifest=old[phase]['manifest'];name=f'{phase}-{mode}-manifest.bin';manifest_files.add(name)
  assert (BASE/name).stat().st_size==173 and sha(BASE/name)==manifest['sha256']
  command=old[phase]['symbol_command'];assert command['returncode']==0
  for channel in ['stdout','stderr']:assert sha(BASE/command[channel])==command[channel+'_sha256']
 owned=variant['current'];manifest=owned['manifest'];name=f'current80-{mode}-manifest.bin';manifest_files.add('retry-80b842693/'+name)
 assert manifest['retained_copy']==name and (MEASURED_BASE/name).stat().st_size==173 and sha(MEASURED_BASE/name)==manifest['sha256']
 assert manifest['source_fingerprint']==owned['package']['source_fingerprint']==local['source_fingerprint']
 assert manifest['package_digest']==owned['package']['sha256'] and manifest['native_digest']==owned['native']['sha256']
 command=owned['symbol_command'];assert command['returncode']==0
 for channel in ['stdout','stderr']:assert sha(MEASURED_BASE/command[channel])==command[channel+'_sha256']
 assert owned['helper_native_bytes']=={'helper::regexp_matcher':1243784,'builtin::Array.fromAsync?Fulfilled?Function':511392}
 assert variant['deltas_from_accessor']['raw_wasm_bytes']==-747642
 assert variant['a26_payload_identity']['native_elf_sha256_equal'] is True and variant['a26_payload_identity']['helper_sizes_equal'] is True
 assert owned['native']['sha256']==old['current']['native']['sha256']
 assert variant['a26_payload_identity']['reconstructed_a26_package_sha256']==old['current']['package']['sha256']
portable=static['variants']['Portable'];assert portable['prior_accessor_retained_fact']['native']['bytes']==72143200 and portable['current']['native']['bytes']==67307296 and portable['deltas_from_accessor']['native_image_bytes']==-4835904
initial=(BASE/'inspect-owned-r-static.stderr').read_text()
assert 'assert raw[12:44].hex() == fingerprint' in initial and initial.rstrip().endswith('AssertionError')
assert not (BASE/'inspect-owned-r-static-retry.stderr').read_bytes()
assert read(BASE/'inspect-owned-r-static-retry.stdout')=={mode:historical_static['variants'][mode]['deltas'] for mode in ['Portable','NativeHost']}
static_lineage=dict(initial_result='Read-only prior-outdir source-fingerprint guard refusal; not a successful inspection.',retry_result='Source-bound static inspection completed for both modes.',files=[dict(path=name,sha256=sha(BASE/name),bytes=(BASE/name).stat().st_size) for name in ['inspect-owned-r-static.py','inspect-owned-r-static.stdout','inspect-owned-r-static.stderr','inspect-owned-r-static-retry.stdout','inspect-owned-r-static-retry.stderr']])
measured,rows=p.load_report(BASE/('github-'+args.run)/'precompiled-measurements/precompiled-evidence/report.json')
assert measured['source_commit']==MEASURED and measured['source_fingerprint']==clean['source_fingerprint'] and len(rows)==17
processing=read(MEASURED_BASE/('ci-processing-'+args.run+'.json'));assert processing['complete'] and processing['source_commit']==MEASURED and processing['run']==args.run and processing['scored_mutations'] is False
assert processing['cpu_affinity']==[0] and len(processing['commands'])>=3
streams(MEASURED_BASE,processing['commands'])
for moment in ['before','after']:
 values=processing[moment];assert 0<int(values['memory.max'])<=4*1024**3 and values['memory.swap.max']=='0' and values['memory.oom.group']=='1'
events=[dict(line.split()for line in processing[m]['memory.events'].splitlines())for m in ['before','after']]
assert all(events[0][key]==events[1][key]for key in ['oom','oom_kill','oom_group_kill'])
preview_processing=read(MEASURED_BASE/'preview-processing.json');assert preview_processing['complete'] and preview_processing['source_commit']==MEASURED and preview_processing['run']==args.run and preview_processing['scored_mutations'] is False
assert preview_processing['cpu_affinity']==[0] and preview_processing['ci_processing_sha256']==sha(MEASURED_BASE/('ci-processing-'+args.run+'.json'))
assert [(c['label'],c['exit_code']) for c in preview_processing['commands']]==[('render-previews',0),('canonical-p-check',0)]
streams(MEASURED_BASE,preview_processing['commands'])
for moment in ['before','after']:
 values=preview_processing[moment];assert 0<int(values['memory.max'])<=1024**3 and values['memory.swap.max']=='0' and values['memory.oom.group']=='1'
preview_events=[dict(line.split()for line in preview_processing[m]['memory.events'].splitlines())for m in ['before','after']]
assert all(preview_events[0][key]==preview_events[1][key]for key in ['oom','oom_kill','oom_group_kill'])
raw_scored=preview_processing['raw_scored_report'];assert raw_scored['path']=='ci-scored-'+args.run+'-raw-report.json' and sha(MEASURED_BASE/raw_scored['path'])==raw_scored['sha256']==sha(BASE/('github-'+args.run)/'precompiled-measurements/precompiled-evidence/report.json') and (MEASURED_BASE/raw_scored['path']).stat().st_size==raw_scored['bytes']
run=read(BASE/('github-run-'+args.run+'.json'));assert run['databaseId']==int(args.run) and run['headSha']==MEASURED and run['status']=='completed' and run['conclusion']=='success'
visual=read(MEASURED_BASE/'visual-review.json');assert visual['source_commit']==MEASURED and visual['run']==args.run and visual['png_images_viewed'] is True
visual_names={row['path']for row in visual['files']};assert visual_names=={'preview-memory.svg','preview-memory.png','preview-execution.svg','preview-execution.png'}
for row in visual['files']:assert (MEASURED_BASE/row['path']).stat().st_size==row['bytes'] and sha(MEASURED_BASE/row['path'])==row['sha256']
visual_files={'retry-80b842693/'+name for name in visual_names}
historical_ci=BASE/'ci-scored-40568638008-raw-report.json';historical_report=read(historical_ci)
assert historical_report['source_commit']=='a26f8c9796d3d7284f5bc0537df1dd336c1641b6'
historical_ci_record=dict(run='40568638008',source_commit=historical_report['source_commit'],raw_report_sha256=sha(historical_ci),final_cohort=False)
files=[]
for path in sorted(BASE.rglob('*')):
 if not path.is_file():continue
 rel=path.relative_to(BASE).as_posix();parts=PurePosixPath(rel).parts
 if (parts[0].startswith('github-') and len(parts)>1) or 'images'in parts or 'mplconfig'in parts or (path.name.startswith(('preview-','publication.')) and rel not in visual_files):continue
 if rel not in manifest_files and path.suffix not in ['.py','.json','.jsonl','.stdout','.stderr','.txt','.smaps','.md','.patch','.lock','.png','.svg'] and path.name not in ['executions','stdout','stderr','control']:continue
 assert not path.is_symlink() and '..'not in parts and path.stat().st_size<=128*1024**2
 with path.open('rb')as stream:assert not stream.read(8).startswith((b'\x7fELF',b'MZ',b'SCRWEP',b'SCRWWA'))
 files.append(dict(path=rel,bytes=path.stat().st_size,sha256=sha(path)))
assert visual_files|manifest_files<={row['path']for row in files}
expanded=sum(row['bytes']for row in files);assert expanded<=2*1024**3
archive=DEST/(STEM+'-verification.tar.xz');target=DEST/(STEM+'.json');assert not archive.exists() and not target.exists()
with archive.open('xb')as output,lzma.LZMAFile(output,'w',filters=[dict(id=lzma.FILTER_LZMA2,preset=1,dict_size=64*1024**2)])as compressed:
 with tarfile.open(fileobj=compressed,mode='w|')as tar:
  for row in files:
   member=tarfile.TarInfo(row['path']);member.size=row['bytes'];member.mode=0o644
   with (BASE/row['path']).open('rb')as stream:tar.addfile(member,stream)
assert archive.stat().st_size<=32*1024**2
expected={row['path']:row for row in files};seen=set();total=0
with tarfile.open(archive,'r|xz')as tar:
 for member in tar:
  assert member.isfile() and member.name in expected and member.name not in seen
  row=expected[member.name];assert member.size==row['bytes']<=128*1024**2
  assert hashlib.file_digest(tar.extractfile(member),'sha256').hexdigest()==row['sha256'];seen.add(member.name);total+=member.size;assert total<=2*1024**3
assert seen==set(expected) and total==expanded
record=dict(schema='scriptw-shared-recovery-verification-v1',recorded_at=datetime.now(timezone.utc).isoformat(),verified_source_commit=source,measured_source_commit=MEASURED,runtime_layout=28,source_bindings=bindings,fresh_all19_native_build=False,native_resume_admission=admission,compiler_input_equivalence=equivalence,historical_ci=historical_ci_record,historical_failures=dict(physical=history,cache=verification['predecessor_cache_failure'],failed95_check=verification['failed95_check'],stopped80_structure=admission),diagnostic_probes=dict(physical=physical_probe,mode_cache=mode_probe,structure=structure_probe),static_code=static,static_inspection_lineage=static_lineage,native=native,conformance=reports,unique_selected_executions=6307,overlap_interpretation='2365 original +3756 RegExp +186 Array.fromAsync are disjoint; targeted32 and Unicode16 are subsets of RegExp, not additional unique passes.',checkpoints=dict(check=check,verification=verification,continuation=continuation,cheap=cheap),resource_origins=dict(original_outer_driver=dict(path=str(RETRY/'verification.json'),sha256=sha(RETRY/'verification.json'),complete=False,after_available=False,native_driver_exit_status_available=False),native=dict(path=str(RETRY/'native/report.json'),sha256=sha(RETRY/'native/report.json'),scope=native['resource_scope']),continuation=dict(path=str(RECOVERY/'continuation.json'),sha256=sha(RECOVERY/'continuation.json'),scope=continuation['resource_scope'])),ci_processing=processing,preview_processing=preview_processing,github_run=run,visual_review=visual,prior_checkpoint=dict(file=prior_path.name,sha256=sha(prior_path)),measurement=dict(run=args.run,report_sha256=sha(BASE/('github-'+args.run)/'precompiled-measurements/precompiled-evidence/report.json')),archive=dict(file=archive.name,sha256=sha(archive),bytes=archive.stat().st_size,expanded_bytes=expanded,member_count=len(files),max_member_bytes=128*1024**2,max_expanded_bytes=2*1024**3),retained_files=files,interpretation='One in-function RegExp recovery owner and one fulfilled Array.fromAsync map/commit path preserve existing state and ordering. Complete selected inventories passed; not a full pinned-suite refresh. Cross-runner metrics are descriptive and do not establish causal RSS/timing savings. Paused maps never enter canonical cohorts. Any failed/stopped attempts remain retained as raw evidence and are not counted as successful executions.')
target.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record['archive']))
