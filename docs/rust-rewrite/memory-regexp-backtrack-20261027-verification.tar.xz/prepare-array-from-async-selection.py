"""Inert pinned metadata inventory; owned CLI discovery must confirm before execution."""
import collections,hashlib,json,re
from pathlib import Path
BASE=Path(__file__).resolve().parent;ROOT=BASE.parents[1]
tests=ROOT/'test262/vendor/test262/test';rows=[];ids=[];modes=collections.Counter()
for p in sorted((tests/'built-ins/Array/fromAsync').rglob('*.js')):
 rel=p.relative_to(tests).as_posix()
 if '_FIXTURE'in rel:continue
 raw=p.read_bytes();metadata=raw.decode().split('/*---',1)[1].split('---*/',1)[0]
 flags=re.findall(r'^flags:\s*(.*)$',metadata,re.M);assert len(flags)<=1
 assert not flags or re.fullmatch(r'\[[^\]]*\]',flags[0])
 flags=set(x.strip()for x in flags[0][1:-1].split(','))if flags else set()
 assert not flags&{'raw','module'} and not {'noStrict','onlyStrict'}<=flags
 variants=['strict-script']if'onlyStrict'in flags else ['sloppy-script']if'noStrict'in flags else ['sloppy-script','strict-script']
 modes['/'.join(variants)]+=1;ids.extend(f'{mode}:{rel}'for mode in variants)
 rows.append(dict(path='test/'+rel,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),flags=sorted(flags)))
assert len(rows)==95 and len(ids)==len(set(ids))==186
original=(ROOT/'target/memory-regexp-unicode-data-20261027-evidence/conformance/executions').read_text().splitlines()
regexp=json.loads((BASE/'regexp-full-selection.json').read_text())
assert not set(ids)&(set(original)|set(regexp['expected_executions']))
result=dict(scope='Complete pinned built-ins/Array/fromAsync subtree; no feature/outcome filtering. Owned CLI list-all must confirm every metadata-derived ID.',filter='built-ins/Array/fromAsync/',expected_count=186,source_files=95,modes=dict(modes),files=rows,expected_executions=sorted(ids),fresh_batches_at_most_16=12,original_overlap=0,regexp_overlap=0,unique_with_original_and_full_regexp=6307,execution_plan_source='crates/scriptw-test262/src/lib.rs:TestExecutionPlan::from_flags and scan_tests',execution_plan_source_sha256=hashlib.sha256((ROOT/'crates/scriptw-test262/src/lib.rs').read_bytes()).hexdigest())
(BASE/'array-from-async-full-selection.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items()if k not in('files','expected_executions')},indent=2))
