# Unscored phase mapping comparison

Current source a26f8c9796d3d7284f5bc0537df1dd336c1641b6 / run40568638008 (`ci-phase-components-40568638008.json`), compared descriptively with accessor source a960 / run40552965169 (`../memory-eager-accessors-20261027-evidence/phase-map-analysis.json`). These are independent runner processes, not a controlled causal comparison. Mapping group names identify recorded paths and permissions only. They do not identify allocation ownership or executed functions.

| Current phase | Integer SW/SC MiB | Retained SW/SC MiB |
|---|---:|---:|
| Loading, before all observations |13.520 /10.293|13.629 /11.133|
| Warm instantiate, observation16 |18.000 /11.496|19.055 /12.113|
| After execution, observation16 |18.449 /13.582|24.605 /20.086|
| After Store drop, observation16 |17.637 /11.496|18.691 /12.117|

At warm instantiate/execution/drop, current integer exact-host RX stays7.566MiB, other RX4.012 and other RO1.441; retained exact-host RX7.406, other RX4.488 and other RO2.199. These groups do not increase during the selected execution or shrink at Store drop. Anonymous RW changes integer1.598→2.047→1.234MiB; retained1.605→7.156→1.242MiB. Current post-drop paired gaps6.141/6.574MiB include exact-host RX2.582/2.547, other RX1.520/1.500, other RO0.703/1.332, exact-host RO0.543/0.414 and anonymous RW0.797/0.781MiB respectively.

Compared with prior accessor captures, current Scriptw integer warm instantiate/execution/drop RSS is each0.039MiB lower; retained each0.191MiB lower. Anonymous RW values are identical at all four phases in both cohorts. Integer exact-host RX is unchanged7.566MiB; retained declines7.594→7.406MiB. Other RX increases3.973→4.012 integer /4.414→4.488 retained; other RO falls1.504→1.441 /2.262→2.199. Thus static image shrink does not imply resident-page reduction. The main remaining observed paired gap persists after Store drop in RX/RO mapping categories, with a smaller anonymous RW remainder. This supports further ownership/introspection investigation, not attribution to particular functions or a specific optimization.

Loading precedes every invocation; the other captures follow16 earlier observations. Their difference includes allocator/code/warmup history and is not pure instantiation cost. Paused maps are unscored and excluded from canonical graphs; neither timings nor waits are subtracted. No live heap/peak/RSS improvement claim follows from these samples.
