"""Diagnostic dirty-test probe only; no verified source-closure claim."""
from pathlib import Path
import hashlib,json,os,re,shutil,subprocess,sys,time
BASE=Path(__file__).resolve().parent;ROOT=BASE.parents[2]
sys.path.insert(0,str(ROOT/'scripts'))
from limited_verification import require_kernel_budget,kernel_group
from native_test_protocol import result_summaries,parse_inventory
require_kernel_budget(4*1024**3);assert sorted(os.sched_getaffinity(0))==[0]
HEAD='80b842693e964634f378d5813f6db684ee7d255b'
FILE='crates/scriptw-aot-wasm/tests/structure_builtins/regexp_nullable_quantifier_progress_structure.rs'
CASE='regexp_nullable_quantifier_progress_structure::matcher_frames_preserve_ordered_backtracking_and_exact_progress_identity'
def sha(path):
 with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT)
def dirty():
 assert git('rev-parse','HEAD').decode().strip()==HEAD
 # Only the tracked test and no untracked compiler inputs may differ.
 # Unrelated protected workspace files are not inspected.
 assert git('diff','--name-only','HEAD','-z').split(b'\0')==[FILE.encode(),b'']
 assert not git('ls-files','--others','--exclude-standard','-z','--','crates','vendor','scripts','Cargo.toml','Cargo.lock')
 return git('diff','--binary','HEAD','--',FILE)
patch=dirty();assert patch
out=BASE/'receipt.json';assert not out.exists()
patch_path=BASE/'dirty-test.patch';assert not patch_path.exists();patch_path.write_bytes(patch)
source_sha=sha(ROOT/FILE);patch_sha=sha(patch_path)
group=kernel_group()
def budget():return {k:(group/k).read_text().strip() for k in ['memory.max','memory.swap.max','memory.oom.group','memory.peak','memory.events']}
record=dict(schema='scriptw-dirty-test-focused-probe-v1',diagnostic_dirty_test=True,verified_source_claim=False,head_commit=HEAD,complete=False,test_path=FILE,test_source_sha256=source_sha,patch=dict(path=patch_path.name,sha256=patch_sha,bytes=len(patch)),cpu_affinity=sorted(os.sched_getaffinity(0)),before=budget(),commands=[])
def save():out.write_text(json.dumps(record,indent=2)+'\n')
def unchanged():
 assert dirty()==patch and sha(ROOT/FILE)==source_sha and sha(patch_path)==patch_sha

def run(label,command):
 unchanged();stdout=BASE/(label+'.stdout');stderr=BASE/(label+'.stderr')
 row=dict(label=label,command=list(map(str,command)),stdout=stdout.name,stderr=stderr.name)
 record['commands'].append(row);save();started=time.monotonic()
 try:
  with stdout.open('xb') as a,stderr.open('xb') as b:
   child=subprocess.run(row['command'],cwd=ROOT,stdout=a,stderr=b,timeout=3600)
  row['exit_code']=child.returncode
 finally:
  row['seconds']=time.monotonic()-started
  for name,path in [('stdout',stdout),('stderr',stderr)]:
   if path.exists():row[name+'_sha256']=sha(path)
  record['after']=budget();save()
 assert child.returncode==0,label+' failed; original streams retained'
 unchanged();return stdout
save()
try:
 log=run('cargo-structure',['cargo','test','--locked','--offline','--release','--jobs','1','--target-dir',ROOT/'target/performance-work-20261024/build','-p','scriptw-aot-wasm','--test','structure_builtins','--no-run','--message-format=json'])
 cargo=[json.loads(line) for line in log.read_text().splitlines()]
 assert cargo[-1]==dict(reason='build-finished',success=True)
 producers=[r for r in cargo if r.get('reason')=='compiler-artifact' and r.get('executable') and r['target']['name']=='structure_builtins' and r['target']['kind']==['test'] and r['profile']['test']]
 assert len(producers)==1
 producer=producers[0];original=Path(producer['executable']);binary=BASE/'structure-builtin-tests';assert not binary.exists()
 shutil.copy2(original,binary);assert binary.stat().st_nlink==1 and sha(binary)==sha(original)
 record['binary']=dict(path=binary.name,sha256=sha(binary),bytes=binary.stat().st_size,cargo_producer=producer);save()
 inventory=parse_inventory(run('inventory',[binary,'--list']).read_text())
 assert len(inventory)==166 and CASE in inventory
 record['inventory']=inventory;save()
 text=run('focused',[binary,'--exact','--include-ignored','--test-threads=1',CASE]).read_text()
 assert result_summaries(text)==[('ok','1','0','0','0','165')]
 assert re.findall(r'^test ([^\r\n]+) \.\.\. ok$',text,re.M)==[CASE]
 full=run('full-exact',[binary,'--exact','--include-ignored','--test-threads=1',*inventory]).read_text()
 assert result_summaries(full)==[('ok','166','0','0','0','0')]
 names=re.findall(r'^test ([^\r\n]+) \.\.\. ok$',full,re.M)
 assert len(names)==166 and set(names)==set(inventory)
 record['full_passed']=166;record['focused_overlap']=[CASE]
 assert sha(binary)==record['binary']['sha256'];unchanged()
 before=dict(line.split() for line in record['before']['memory.events'].splitlines())
 after=dict(line.split() for line in budget()['memory.events'].splitlines())
 assert all(before[k]==after[k] for k in ('oom','oom_kill','oom_group_kill'))
 require_kernel_budget(4*1024**3);assert sorted(os.sched_getaffinity(0))==[0]
 record.update(complete=True,passed=1,failed=0,filtered_out=165)
finally:
 record['after']=budget();save()
print(json.dumps(dict(complete=True,diagnostic_dirty_test=True,passed=1,filtered_out=165)))
