"""Continue the vanished outer driver after independent native completion.

Never rerun native tests or repair the interrupted outer verification receipt.
Run only after native.py has finished, in a fresh capped CPU-0 scope.
"""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

OUT = Path(__file__).resolve().parent
EVIDENCE = OUT.parent
ROOT = EVIDENCE.parents[1]
RETRY = EVIDENCE / 'retry-9001324dc'
SOURCE = '9001324dc52ce583e7b95a1292f317796d415c01'
REPAIR = '54231ef4d3eb1fa6e1a39f34698d3d0f3668d1b1'
sys.path.insert(0, str(ROOT / 'scripts'))
from limited_verification import require_kernel_budget, kernel_group


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def read(path):
    return json.loads(path.read_text())


def stamp():
    return datetime.now(timezone.utc).isoformat()


def source():
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == SOURCE
    assert not subprocess.check_output(['git', 'diff', '--binary', 'HEAD', '--', 'crates', 'vendor', 'scripts', 'Cargo.toml', 'Cargo.lock'], cwd=ROOT)


def streams(folder, commands):
    for row in commands:
        assert row['exit_code'] == 0
        for channel in ('stdout', 'stderr'):
            assert sha(folder / row[channel]) == row[channel + '_sha256']


require_kernel_budget(4 * 1024**3)
assert sorted(os.sched_getaffinity(0)) == [0]
assert os.environ['SCRIPTW_EXPECTED_SOURCE'] == SOURCE
assert os.environ['SCRIPTW_REQUIRED_REPAIR_SOURCE'] == REPAIR
assert os.environ['SCRIPTW_MODULE_MEMORY_CACHE_ENTRIES'] == '1'
assert os.environ['SCRIPTW_MODULE_MEMORY_CACHE_LIMIT_BYTES'] == str(64 * 1024**2)
assert os.environ['CARGO_BUILD_JOBS'] == os.environ['RUST_TEST_THREADS'] == '1'
source()
assert subprocess.run(['git', 'merge-base', '--is-ancestor', REPAIR, SOURCE], cwd=ROOT).returncode == 0
assert not (OUT / 'continuation.json').exists(), 'fresh continuation receipt required'
original_path = RETRY / 'verification.json'
original = read(original_path)
original_sha = sha(original_path)
assert original['source_commit'] == SOURCE and original['complete'] is False and 'after' not in original
assert [(r['label'], r.get('exit_code')) for r in original['commands']] == [('cheap-main-driver', 0), ('cargo-check-driver', 0), ('native-driver', None)]
assert original['full_regexp_requested'] is True and original['full_array_from_async_requested'] is True
streams(RETRY, original['commands'][:2])
pending = original['commands'][2]
assert sys.executable == pending['command'][0], 'use the original Python executable for exact command provenance'
assert not any(k in pending for k in ('exit_code', 'seconds', 'stdout_sha256', 'stderr_sha256'))
native_path = RETRY / 'native/report.json'
native = read(native_path)
assert native['complete'] is True, 'native is still running or incomplete; leave it untouched and wait'
assert native['source_commit'] == SOURCE and native['passed_disjoint_scopes'] == 4889
assert len(native['scopes']) == 19 and all(s['complete'] and len(s['inventory']) == len(set(s['inventory'])) == s['passed'] for s in native['scopes'])
assert (native['inherited_scopes'], native['inherited_disjoint_passes'], native['executed_scopes'], native['executed_disjoint_passes']) == (9, 2338, 10, 2551)
assert native['native_compilation_executed'] is False
assert native['native_resume_admission'] == original['native_resume_admission']
streams(RETRY / 'native', native['commands'])
streams(RETRY / 'native', native['inherited_commands'])
assert 'after' in native and native['cpu_affinity'] == [0]
for moment in ('before', 'after'):
    values = native[moment]
    assert values['memory.max'] == '4294967296' and values['memory.swap.max'] == '0' and values['memory.oom.group'] == '1'
events = [dict(line.split() for line in native[m]['memory.events'].splitlines()) for m in ('before', 'after')]
assert all(events[0][key] == events[1][key] for key in ('oom', 'oom_kill', 'oom_group_kill'))
assert (RETRY / pending['stdout']).read_text().rstrip().endswith('complete4889: inherited2338 + resumed2551'), 'wait for native driver final output'
native_sha = sha(native_path)
native_driver_streams = {channel: dict(path=str(RETRY / pending[channel]), sha256=sha(RETRY / pending[channel])) for channel in ('stdout', 'stderr')}
group = kernel_group()


def budget():
    return {k: (group / k).read_text().strip() for k in ('memory.max', 'memory.swap.max', 'memory.oom.group', 'memory.peak', 'memory.events')}


build = ROOT / 'target/performance-work-20261024/build'
plan = [('cargo-products', ['cargo', 'build', '--locked', '--offline', '--release', '--jobs', '1', '--target-dir', str(build), '-p', 'scriptw-cli', '--bin', 'scriptw', '--example', 'compiler_precompiled_baseline', '--message-format=json'])]
for label, flags in [('test262-driver', []), ('test262-unicode-driver', ['--unicode']), ('test262-regexp-driver', ['--regexp']), ('test262-regexp-full-driver', ['--regexp-full']), ('test262-array-from-async-driver', ['--array-from-async-full'])]:
    plan.append((label, [sys.executable, '-B', str(RETRY / 'test262.py'), *flags]))
for label, _ in plan:
    assert not (RETRY / (label + ('.jsonl' if label == 'cargo-products' else '.stdout'))).exists()
    assert not (RETRY / (label + '.stderr')).exists()
for directory in ('conformance', 'conformance-unicode', 'conformance-regexp', 'conformance-regexp-full', 'conformance-array-from-async'):
    assert not (RETRY / directory).exists(), 'fresh conformance output required'
report = dict(schema='scriptw-outer-verification-continuation-v1', source_commit=SOURCE, complete=False, started_at=stamp(), cpu_affinity=sorted(os.sched_getaffinity(0)), before=budget(), resource_scope='This fresh invocation covers only CLI products and five conformance selections. Original outer-driver after counters and native-driver exit status are unavailable; native completion is established independently by its own receipt and streams.', original_verification=dict(path=str(original_path), sha256=original_sha, complete=False, resource_after_available=False, native_driver_exit_status_available=False), native_completion=dict(path=str(native_path), sha256=native_sha, complete=True, passed_disjoint_scopes=4889, driver_streams=native_driver_streams, driver_exit_status_available=False, resource_origin='native/report.json before/after cover its resumed native commands only; inherited native scopes retain their original resource receipts'), full_regexp_requested=True, full_array_from_async_requested=True, commands=[])


def save():
    (OUT / 'continuation.json').write_text(json.dumps(report, indent=2) + '\n')


def origins():
    assert sha(original_path) == original_sha and sha(native_path) == native_sha
    for channel, row in native_driver_streams.items():
        assert sha(Path(row['path'])) == row['sha256']


save()
for label, args in plan:
    source()
    origins()
    output = RETRY / (label + ('.jsonl' if label == 'cargo-products' else '.stdout'))
    error = RETRY / (label + '.stderr')
    row = dict(label=label, command=args, started_at=stamp(), stdout=os.path.relpath(output, OUT), stderr=os.path.relpath(error, OUT))
    report['commands'].append(row)
    save()
    print(label, 'started', flush=True)
    started = time.monotonic()
    with output.open('xb') as stdout, error.open('xb') as stderr:
        result = subprocess.run(args, cwd=ROOT, stdout=stdout, stderr=stderr, timeout=10800)
    row.update(exit_code=result.returncode, seconds=time.monotonic() - started, finished_at=stamp(), stdout_sha256=sha(output), stderr_sha256=sha(error))
    save()
    print(label, 'finished', result.returncode, flush=True)
    if result.returncode:
        print(error.read_text()[-12000:], flush=True)
        raise SystemExit(result.returncode)

selected = {}
for directory, expected in [('conformance', 2365), ('conformance-unicode', 16), ('conformance-regexp', 32), ('conformance-regexp-full', 3756), ('conformance-array-from-async', 186)]:
    result = read(RETRY / directory / 'report.json')
    assert result['complete'] is True and result['all_passed'] is True and result['source_commit'] == SOURCE
    assert result['selected_executions'] == result['total'] == result['passed'] == expected
    listing = RETRY / directory / 'executions'
    assert sha(listing) == result['execution_list_sha256']
    ids = listing.read_text().splitlines()
    assert len(ids) == len(set(ids)) == expected
    selected[directory] = set(ids)
original_ids, regexp_ids, array_ids = (selected[k] for k in ('conformance', 'conformance-regexp-full', 'conformance-array-from-async'))
assert original_ids.isdisjoint(regexp_ids) and original_ids.isdisjoint(array_ids) and regexp_ids.isdisjoint(array_ids)
assert len(original_ids | regexp_ids | array_ids) == 6307
assert selected['conformance-unicode'] <= regexp_ids and selected['conformance-regexp'] <= regexp_ids
source()
origins()
after = budget()
events = [dict(line.split() for line in values['memory.events'].splitlines()) for values in (report['before'], after)]
assert all(events[0][key] == events[1][key] for key in ('oom', 'oom_kill', 'oom_group_kill'))
report.update(complete=True, finished_at=stamp(), after=after, unique_selected_executions=6307, overlap_interpretation='2365 original +3756 RegExp +186 Array.fromAsync are disjoint; targeted32 and Unicode16 are RegExp subsets, not additional unique passes.')
save()
print('continuation complete: native independently complete4889; conformance6307 unique selected passes', flush=True)
