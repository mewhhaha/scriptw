"""Observe the existing native process, then exec the independent continuation."""
import json
import os
from pathlib import Path
import sys
import time

BASE = Path(__file__).resolve().parent
RETRY = BASE.parent / 'retry-9001324dc'
PID = 2703321
PROCESS = Path('/proc') / str(PID)
NATIVE = str(RETRY / 'native.py')
deadline = time.monotonic() + 3600


def identity():
    try:
        command = (PROCESS / 'cmdline').read_bytes().split(b'\0')
        stat = (PROCESS / 'stat').read_text().rsplit(')', 1)[1].split()
    except FileNotFoundError:
        return None
    if stat[0] == 'Z':
        return None
    assert command[:3] == [b'/usr/bin/python3', b'-B', NATIVE.encode()], 'native PID identity changed'
    return stat[19]  # field 22: start time, after PID and parenthesized comm


initial = identity()
state = dict(native_pid=PID, native_start_ticks=initial, complete=False,
             purpose='Read-only wait; no native restart or repeated execution.')
status = BASE / 'wait-status.json'
assert not status.exists()
status.write_text(json.dumps(state, indent=2) + '\n')
while True:
    assert time.monotonic() < deadline, 'native observation deadline; leave original run untouched'
    try:
        report = json.loads((RETRY / 'native/report.json').read_text())
    except json.JSONDecodeError:
        time.sleep(1)
        continue
    current = identity()
    if report['complete'] is True:
        assert report['passed_disjoint_scopes'] == 4889
        if current is None:
            break
    else:
        assert initial is not None and current == initial, 'native stopped incomplete; inspect retained evidence'
    time.sleep(5)
state.update(complete=True, native_report_complete=True, native_process_exited=True)
status.write_text(json.dumps(state, indent=2) + '\n')
os.execv('/usr/bin/python3', ['/usr/bin/python3', '-B', str(BASE / 'continue.py')])
