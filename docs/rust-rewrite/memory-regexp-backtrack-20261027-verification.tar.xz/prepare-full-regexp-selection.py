"""Read pinned metadata using discovery's closed execution-plan rules; execute nothing."""
import collections,hashlib,json,re
from pathlib import Path
BASE=Path(__file__).resolve().parent;ROOT=BASE.parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
tests=ROOT/'test262/vendor/test262/test';files=[];ids=[];modes=collections.Counter()
for p in sorted((tests/'built-ins/RegExp').rglob('*.js')):
 rel=p.relative_to(tests).as_posix()
 if '_FIXTURE' in rel:continue
 raw=p.read_bytes();meta=raw.decode().split('/*---',1)[1].split('---*/',1)[0]
 rows=re.findall(r'^flags:\s*(.*)$',meta,re.M);assert len(rows)<=1
 assert not rows or re.fullmatch(r'\[[^\]]*\]',rows[0]),'unsupported metadata spelling; stop rather than guess'
 flags=set(x.strip()for x in rows[0][1:-1].split(','))if rows else set()
 assert not(flags&{'raw','module'}),'this inventory currently has neither raw nor module cases'
 assert not {'onlyStrict','noStrict'}<=flags
 variants=['strict-script']if'onlyStrict'in flags else ['sloppy-script']if'noStrict'in flags else ['sloppy-script','strict-script']
 modes['/'.join(variants)]+=1;ids.extend(f'{mode}:{rel}'for mode in variants)
 files.append(dict(path='test/'+rel,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),flags=sorted(flags)))
assert len(files)==1879 and len(ids)==len(set(ids))==3756
focused=json.loads((BASE/'regexp-selection.json').read_text());unicode=(ROOT/'target/memory-regexp-unicode-data-20261027-evidence/conformance-unicode/executions').read_text().splitlines();original=(ROOT/'target/memory-regexp-unicode-data-20261027-evidence/conformance/executions').read_text().splitlines()
assert set(focused['expected_executions'])<=set(ids) and set(unicode)<=set(ids) and not set(ids)&set(original)
recheck=ROOT/'docs/rust-rewrite/remaining-four-recheck-20261021.json';old=json.loads(recheck.read_text())['results']['original-four'];assert old['total']==4 and len(old['execution_ids'])==4
assert not set(old['execution_ids'])&set(ids)
record=dict(scope='Complete pinned built-ins/RegExp subtree, with every metadata-planned execution; no feature/outcome filtering. Actual owned CLI list-all must exactly confirm this inert metadata inventory before execution.',filter='built-ins/RegExp/',expected_count=3756,source_files=1879,execution_plan_source='crates/scriptw-test262/src/lib.rs:TestExecutionPlan::from_flags and scan_tests',execution_plan_source_sha256=sha(ROOT/'crates/scriptw-test262/src/lib.rs'),modes=dict(modes),files=files,expected_executions=sorted(ids),focused_overlap=32,unicode_overlap=16,original_overlap=0,unique_including_original=6121,fresh_batches_at_most_16=235,historical_remaining_four=dict(source=str(recheck.relative_to(ROOT)),sha256=sha(recheck),execution_ids=old['execution_ids'],regexp_overlap=0,owners=['Annex B implicit arguments/block function binding (Test262 upstream5113/fix5112)','Temporal named-timezone identity/country-preserving zone rules (ECMA402806)','Annex B labelled block-function visibility']),interpretation='Metadata-derived count, not an executed result. CLI list-all is the runtime inventory authority; unsupported/failed cases remain explicit outcomes, never omitted. Targeted32 and Unicode16 are focused overlap, not extra unique passes.')
(BASE/'regexp-full-selection.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:v for k,v in record.items()if k not in ('files','expected_executions')},indent=2))
