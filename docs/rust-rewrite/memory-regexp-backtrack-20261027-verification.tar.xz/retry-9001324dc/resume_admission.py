"""Validate actual completed evidence without inventing new executions."""
import hashlib,json,re,subprocess
from native_test_protocol import parse_inventory,result_summaries

def admit(base,root):
 def sha(p):
  with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
 def read(p):return json.loads(p.read_text())
 def names(text):return [x.removesuffix(' - should panic') for x in re.findall(r'^test ([^\r\n]+) \.\.\. ok$',text,re.M)]
 def git(*args):return subprocess.check_output(['git',*args],cwd=root)
 final='9001324dc52ce583e7b95a1292f317796d415c01';oldsource='80b842693e964634f378d5813f6db684ee7d255b'
 assert git('rev-parse','HEAD').decode().strip()==final
 assert not git('diff','HEAD','--','crates','vendor','scripts','Cargo.toml','Cargo.lock')
 old=base.parent/'retry-80b842693';v=read(old/'verification.json');n=read(old/'native/report.json');c=read(old/'check.json')
 assert v['source_commit']==n['source_commit']==c['source_commit']==oldsource
 assert not v['complete'] and not n['complete'] and 'after' not in v and 'after' not in n
 assert c['complete'] is True and c['exit_code']==0 and sha(old/'cargo-check.jsonl')==c['stdout_sha256']
 assert [(r['label'],r.get('exit_code')) for r in v['commands']]==[('cheap-main-driver',0),('cargo-check-driver',0),('native-driver',1)]
 assert [(r['label'],r.get('exit_code')) for r in n['commands'] if r.get('exit_code')]==[('scriptw-aot-wasm-structure_builtins-part-000',101)]
 for record,folder in ((v,old),(n,old/'native')):
  for r in record['commands']:
   for stream in ('stdout','stderr'):assert sha(folder/r[stream])==r[stream+'_sha256']
 assert not any((old/p).exists() for p in ('conformance','conformance-unicode','conformance-regexp','conformance-regexp-full','conformance-array-from-async'))
 prefix=[s for s in n['scopes'] if s['complete']]
 assert len(prefix)==8 and sum(s['passed'] for s in prefix)==2172 and len(n['scopes'])==9
 assert n['scopes'][-1]['target']=='structure_builtins' and not n['scopes'][-1]['complete']
 assert result_summaries((old/'native/scriptw-aot-wasm-structure_builtins-part-000.stdout').read_text())==[('FAILED','165','1','0','0','0')]
 for scope in prefix:
  label=scope['package']+'-'+scope['target'];binary=old/'native'/label/'tests'
  assert sha(binary)==scope['executable_sha256']
  inventory=parse_inventory((old/'native'/(label+'-inventory.stdout')).read_text());assert inventory==scope['inventory']
  chunks=[r for r in n['commands'] if r['label'].startswith(label+'-part-')];seen=set()
  for r in chunks:
   assert r['exit_code']==0
   text=(old/'native'/r['stdout']).read_text();passed=names(text)
   assert len(passed)==len(set(passed)) and not seen.intersection(passed)
   assert result_summaries(text)==[('ok',str(len(passed)),'0','0','0',str(len(inventory)-len(passed)))]
   seen.update(passed)
  assert seen==set(inventory) and len(seen)==scope['passed']
 probe_dir=base.parent/'probe-structure-recovery';probe_path=probe_dir/'receipt.json';probe=read(probe_path)
 assert probe['complete'] is True and probe['diagnostic_dirty_test'] is True and probe['verified_source_claim'] is False
 assert probe['head_commit']==oldsource and (probe['passed'],probe['failed'],probe['filtered_out'],probe['full_passed'])==(1,0,165,166)
 file='crates/scriptw-aot-wasm/tests/structure_builtins/regexp_nullable_quantifier_progress_structure.rs';assert probe['test_path']==file
 assert git('diff','--name-only',oldsource,final).decode().splitlines()==[file]
 assert hashlib.sha256(git('show',final+':'+file)).hexdigest()==probe['test_source_sha256']
 patch=probe_dir/probe['patch']['path'];assert sha(patch)==probe['patch']['sha256'] and git('diff','--binary',oldsource,final,'--',file)==patch.read_bytes()
 assert [(r['label'],r.get('exit_code')) for r in probe['commands']]==[('cargo-structure',0),('inventory',0),('focused',0),('full-exact',0)]
 for r in probe['commands']:
  for stream in ('stdout','stderr'):assert sha(probe_dir/r[stream])==r[stream+'_sha256']
 assert sha(probe_dir/probe['binary']['path'])==probe['binary']['sha256']
 inv=parse_inventory((probe_dir/'inventory.stdout').read_text());assert inv==probe['inventory'] and len(inv)==166
 full=(probe_dir/'full-exact.stdout').read_text();assert result_summaries(full)==[('ok','166','0','0','0','0')] and len(names(full))==166 and set(names(full))==set(inv)
 assert result_summaries((probe_dir/'focused.stdout').read_text())==[('ok','1','0','0','0','165')]
 proof=base/'source-bindings-closure-equivalence.json';closure=read(proof)
 assert closure['test_only_repair'] is True and len(closure['rows'])==4
 for mode in (False,True):
  rows=[r for r in closure['rows'] if r['extra_ignored_regress_lock']==mode]
  assert len(rows)==2 and {r['revision'] for r in rows}=={oldsource,final}
  assert len({(r['source_fingerprint'],r['files'],r['bytes']) for r in rows})==1
 frozen=read(base/'frozen-native-binaries.json');assert len(frozen['binaries'])==19 and frozen['source_commit']==oldsource
 assert frozen['cargo_stdout_sha256']==sha(old/'native/cargo-native.stdout') and frozen['native_report_sha256']==sha(old/'native/report.json')
 for r in frozen['binaries']:assert sha(__import__('pathlib').Path(r['path']))==r['sha256']
 return dict(kind='verified-prefix-plus-final-content-equivalent-diagnostic-full-scope',closure_proof_sha256=sha(proof),stopped80_verification_sha256=sha(old/'verification.json'),stopped80_native_report_sha256=sha(old/'native/report.json'),stopped80_passed=165,stopped80_failed=1,inherited_prefix_scopes=8,inherited_prefix_passed=2172,probe_receipt_sha256=sha(probe_path),probe_verified_source_claim=False,final_structure_file_sha256=probe['test_source_sha256'],probe_patch_sha256=sha(patch),probe_binary_sha256=probe['binary']['sha256'],inherited_probe_scope_passed=166,inherited_total_passed=2338,inherited_total_scopes=9,resumed_scopes=10,old_native_after_available=False)
