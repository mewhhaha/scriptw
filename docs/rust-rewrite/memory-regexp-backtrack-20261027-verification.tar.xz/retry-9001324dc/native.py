"""Inherit validated completed scopes, then execute the ten remaining scopes."""
from datetime import datetime,timezone
import hashlib,json,os,re,shutil,subprocess,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'scripts'))
from limited_verification import require_kernel_budget,kernel_group
from native_test_protocol import parse_inventory,result_summaries
from resume_admission import admit
require_kernel_budget(4*1024**3);assert sorted(os.sched_getaffinity(0))==[0]
SOURCE='9001324dc52ce583e7b95a1292f317796d415c01';assert os.environ['SCRIPTW_EXPECTED_SOURCE']==SOURCE
assert os.environ['SCRIPTW_REQUIRED_REPAIR_SOURCE']=='54231ef4d3eb1fa6e1a39f34698d3d0f3668d1b1'
assert os.environ['SCRIPTW_MODULE_MEMORY_CACHE_ENTRIES']=='1' and os.environ['SCRIPTW_MODULE_MEMORY_CACHE_LIMIT_BYTES']==str(64*1024**2)
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def stamp():return datetime.now(timezone.utc).isoformat()
def source():
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==SOURCE
 assert not subprocess.check_output(['git','diff','HEAD','--','crates','vendor','scripts','Cargo.toml','Cargo.lock'],cwd=ROOT)
source();admission=admit(BASE,ROOT)
OUT=BASE/'native';OUT.mkdir(exist_ok=False)
group=kernel_group()
def budget():return {k:(group/k).read_text().strip() for k in ['memory.max','memory.swap.max','memory.oom.group','memory.peak','memory.events']}
report=dict(source_commit=SOURCE,complete=False,started_at=stamp(),cpu_affinity=sorted(os.sched_getaffinity(0)),before=budget(),resource_scope='current invocation before/after covers resumed commands only; inherited resources remain in origin receipts',commands=[],inherited_commands=[],scopes=[],native_resume_admission=admission,native_compilation_executed=False)
def save():(OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n')
def run(label,args,cwd):
 source();row=dict(label=label,command=list(map(str,args)),cwd=str(cwd),started_at=stamp(),stdout=label+'.stdout',stderr=label+'.stderr');report['commands'].append(row);save();print(label,'started',flush=True);start=time.monotonic()
 with (OUT/row['stdout']).open('xb') as a,(OUT/row['stderr']).open('xb') as b:child=subprocess.run(row['command'],cwd=cwd,stdout=a,stderr=b,timeout=3600)
 row.update(exit_code=child.returncode,seconds=time.monotonic()-start,stdout_sha256=sha(OUT/row['stdout']),stderr_sha256=sha(OUT/row['stderr']));save()
 assert child.returncode==0,label+' failed; original streams retained'
 return (OUT/row['stdout']).read_text()
def copy_streams(row,folder,origin,label=None):
 inherited=dict(row);inherited['label']=label or row['label'];inherited['origin']=dict(origin,original_label=row['label'],executed_in_this_resume=False)
 for stream in ('stdout','stderr'):
  src=folder/row[stream];assert sha(src)==row[stream+'_sha256'];name=inherited['label']+'.'+stream
  shutil.copyfile(src,OUT/name);assert sha(OUT/name)==row[stream+'_sha256']
  inherited[stream]=name;inherited['origin'][stream]=str(src)
 report['inherited_commands'].append(inherited)
def copy_binary(row):
 folder=OUT/(row['package']+'-'+row['target']);folder.mkdir();binary=folder/'tests';original=Path(row['path']);assert sha(original)==row['sha256']
 shutil.copy2(original,binary);assert sha(binary)==row['sha256'] and binary.stat().st_nlink==1
 return binary
frozen=json.loads((BASE/'frozen-native-binaries.json').read_text());old=BASE.parent/'retry-80b842693';oldnative=json.loads((old/'native/report.json').read_text())
origin=dict(source_commit=oldnative['source_commit'],native_report_path=str(old/'native/report.json'),native_report_sha256=sha(old/'native/report.json'),resource_before=oldnative['before'],resource_after_available=False)
for previous in [s for s in oldnative['scopes'] if s['complete']]:
 row=next(r for r in frozen['binaries'] if r['package']==previous['package'] and r['target']==previous['target']);copy_binary(row)
 scope=dict(previous);scope['execution']='inherited-verified-prefix';scope['origin']=origin.copy();report['scopes'].append(scope)
 prefix=previous['package']+'-'+previous['target']+'-'
 for command in oldnative['commands']:
  if command['label'].startswith(prefix):copy_streams(command,old/'native',origin)
 save()
assert len(report['scopes'])==8 and sum(s['passed'] for s in report['scopes'])==2172
probe_dir=BASE.parent/'probe-structure-recovery';probe=json.loads((probe_dir/'receipt.json').read_text());row=next(r for r in frozen['binaries'] if r['target']=='structure_builtins');copy_binary(row)
probe_origin=dict(diagnostic_dirty_test=True,verified_source_claim=False,head_commit=probe['head_commit'],receipt_path=str(probe_dir/'receipt.json'),receipt_sha256=sha(probe_dir/'receipt.json'),resource_before=probe['before'],resource_after=probe['after'],final_source_content_admission=admission)
for command in probe['commands']:copy_streams(command,probe_dir,probe_origin,'scriptw-aot-wasm-structure_builtins-probe-'+command['label'])
report['scopes'].append(dict(package='scriptw-aot-wasm',target='structure_builtins',kind='test',executable_sha256=row['sha256'],cargo_producer=row['cargo_producer'],complete=True,inventory=probe['inventory'],passed=166,focused_overlap=probe['focused_overlap'],execution='inherited-diagnostic-full-scope-after-final-content-admission',origin=probe_origin));save()
inherited={(s['package'],s['target']) for s in report['scopes']};remaining=[r for r in frozen['binaries'] if (r['package'],r['target']) not in inherited];assert len(remaining)==10
for row in remaining:
 package,name,kind=row['package'],row['target'],row['kind'];binary=copy_binary(row)
 scope=dict(package=package,target=name,kind=kind,executable_sha256=row['sha256'],cargo_producer=row['cargo_producer'],complete=False,execution='executed-in-this-resume',binary_origin_source_commit=frozen['source_commit']);report['scopes'].append(scope);save()
 inventory=parse_inventory(run(package+'-'+name+'-inventory',[binary,'--list'],ROOT/'crates'/package));scope['inventory']=inventory;save()
 chunks=[inventory[i:i+8] for i in range(0,len(inventory),8)] if name in ('scriptw_engine','aot_gc_entries') else [inventory];passed=set()
 for index,chunk in enumerate(chunks):
  text=run(package+'-'+name+f'-part-{index:03d}',[binary,'--exact','--include-ignored','--test-threads=1',*chunk],ROOT/'crates'/package)
  names=[n.removesuffix(' - should panic') for n in re.findall(r'^test ([^\r\n]+) \.\.\. ok$',text,re.M)]
  assert len(names)==len(chunk) and set(names)==set(chunk) and not passed.intersection(names)
  assert result_summaries(text)==[('ok',str(len(chunk)),'0','0','0',str(len(inventory)-len(chunk)))]
  passed.update(names);scope['passed']=len(passed);save()
 assert passed==set(inventory) and sha(binary)==scope['executable_sha256'];scope['complete']=True;save()
baseline=json.loads((ROOT/'target/memory-eager-accessors-20261027-evidence/retry-00fcf97fb/native/report.json').read_text());assert baseline['complete'] and baseline['passed_disjoint_scopes']==4881
assert len(report['scopes'])==19 and all(s['complete'] for s in report['scopes'])
for scope in report['scopes']:
 oldscope=next(s for s in baseline['scopes'] if s['package']==scope['package'] and s['target']==scope['target']);assert set(oldscope['inventory'])<=set(scope['inventory'])
 assert sha(OUT/(scope['package']+'-'+scope['target'])/'tests')==scope['executable_sha256']
assert sum(s['passed'] for s in report['scopes'])==4889
report.update(complete=True,finished_at=stamp(),after=budget(),passed_disjoint_scopes=4889,inherited_disjoint_passes=2338,inherited_scopes=9,executed_disjoint_passes=sum(s['passed'] for s in report['scopes'] if s['execution']=='executed-in-this-resume'),executed_scopes=10);save()
print('complete4889: inherited2338 + resumed2551',flush=True)
