import hashlib,json,os,subprocess,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]
BASE=Path(__file__).resolve().parent/'cheap-verified'
SOURCE=os.environ['SCRIPTW_EXPECTED_SOURCE']
assert SOURCE=='9001324dc52ce583e7b95a1292f317796d415c01'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==SOURCE
assert os.environ['SCRIPTW_REQUIRED_REPAIR_SOURCE']=='54231ef4d3eb1fa6e1a39f34698d3d0f3668d1b1'
assert subprocess.run(['git','merge-base','--is-ancestor',os.environ['SCRIPTW_REQUIRED_REPAIR_SOURCE'],SOURCE],cwd=ROOT).returncode==0
assert subprocess.run(['git','merge-base','--is-ancestor','00fcf97fbffde8137a67d6ed7ed4803e86384ef1',SOURCE],cwd=ROOT).returncode==0
assert os.environ['SCRIPTW_MODULE_MEMORY_CACHE_ENTRIES']=='1'
assert os.environ['SCRIPTW_MODULE_MEMORY_CACHE_LIMIT_BYTES']==str(64*1024**2)

BASE.mkdir(exist_ok=False)
report=dict(complete=False,base_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),commands=[])
def save():(BASE/'cheap-main.json').write_text(json.dumps(report,indent=2)+'\n')
paths=subprocess.check_output(['git','diff','--name-only','00fcf97fbffde8137a67d6ed7ed4803e86384ef1','HEAD'],cwd=ROOT,text=True).splitlines()
rust=sorted({p for p in paths if p.endswith('.rs')})
plan=[('source-guards-main',[sys.executable,'-B','scripts/check-source-guards.py','--output',str(BASE/'source-guards-main')]),('identities-final',[sys.executable,'-B','scripts/intl_source_identities.py']),('runtime-profile-final',[sys.executable,'-B','scripts/check-runtime-source-compilation-profile.py']),('immutable-pool-final',[sys.executable,'-B','scripts/check-immutable-compiler-pool.py']),('retired-js-final',['bash','scripts/check-no-legacy-js.sh'])]
for edition,selection in [('2021',[p for p in rust if not p.startswith('vendor/')]),('2024',[p for p in rust if p.startswith('vendor/')])]:
 if selection:plan.append(('rustfmt-'+edition,['rustfmt','--edition',edition,'--config','skip_children=true','--check',*selection]))
plan.append(('diff-final',['git','diff','--check']))
for label,args in plan:
 label='main-'+label
 row=dict(label=label,command=args,stdout=label+'.stdout',stderr=label+'.stderr');report['commands'].append(row);save();print(label,'started',flush=True);start=time.monotonic()
 with (BASE/row['stdout']).open('xb') as out,(BASE/row['stderr']).open('xb') as err:r=subprocess.run(args,cwd=ROOT,stdout=out,stderr=err,timeout=600)
 row.update(returncode=r.returncode,seconds=time.monotonic()-start,stdout_sha256=hashlib.sha256((BASE/row['stdout']).read_bytes()).hexdigest(),stderr_sha256=hashlib.sha256((BASE/row['stderr']).read_bytes()).hexdigest());save();print(label,'finished',r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
report['complete']=True;save()
