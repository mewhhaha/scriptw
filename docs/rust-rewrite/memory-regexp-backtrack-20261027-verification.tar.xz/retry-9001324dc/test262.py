"""Repeat exact 2365 pinned executions in fresh batches of at most 16; no status publish."""
from datetime import datetime,timezone
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parents[3]
BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'scripts'))
from limited_verification import require_kernel_budget,kernel_group
from precompiled_comparison import digest
require_kernel_budget(4*1024**3)
assert sorted(os.sched_getaffinity(0))==[0]
SOURCE=os.environ['SCRIPTW_EXPECTED_SOURCE']
assert SOURCE=='9001324dc52ce583e7b95a1292f317796d415c01'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==SOURCE
assert os.environ['SCRIPTW_REQUIRED_REPAIR_SOURCE']=='54231ef4d3eb1fa6e1a39f34698d3d0f3668d1b1'
assert subprocess.run(['git','merge-base','--is-ancestor',os.environ['SCRIPTW_REQUIRED_REPAIR_SOURCE'],SOURCE],cwd=ROOT).returncode==0
assert subprocess.run(['git','merge-base','--is-ancestor','00fcf97fbffde8137a67d6ed7ed4803e86384ef1',SOURCE],cwd=ROOT).returncode==0
assert os.environ['SCRIPTW_MODULE_MEMORY_CACHE_ENTRIES']=='1'
assert os.environ['SCRIPTW_MODULE_MEMORY_CACHE_LIMIT_BYTES']==str(64*1024**2)

assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==SOURCE
build=[json.loads(x) for x in (BASE/'cargo-products.jsonl').read_text().splitlines()]
assert build[-1]==dict(reason='build-finished',success=True)
records=[x for x in build if x.get('reason')=='compiler-artifact' and x.get('executable')
         and x['target']['name']=='scriptw' and x['target']['kind']==['bin'] and not x['profile']['test']]
assert len(records)==1
unicode_only=sys.argv[1:]==['--unicode']
regexp_only=sys.argv[1:]==['--regexp']
regexp_full=sys.argv[1:]==['--regexp-full']
from_async_full=sys.argv[1:]==['--array-from-async-full']
assert not sys.argv[1:] or unicode_only or regexp_only or regexp_full or from_async_full, 'unsupported conformance selection option'
output=BASE/('conformance-array-from-async' if from_async_full else 'conformance-regexp-full' if regexp_full else 'conformance-regexp' if regexp_only else 'conformance-unicode' if unicode_only else 'conformance')
output.mkdir(exist_ok=False)
compiler=output/'compiler'
shutil.copy2(records[0]['executable'],compiler)
assert digest(compiler)==digest(records[0]['executable']) and compiler.stat().st_nlink==1
group=kernel_group()
def budget():
 return {k:(group/k).read_text().strip() for k in ('memory.max','memory.swap.max','memory.oom.group','memory.peak','memory.events')}
def stamp():return datetime.now(timezone.utc).isoformat()
report=dict(source_commit=SOURCE,complete=False,started_at=stamp(),commands=[],before=budget(),
 compiler=dict(path=str(compiler),sha256=digest(compiler),cargo_producer=records[0]),
 scope='Exact original pinned Function/AsyncFunction/GeneratorFunction/AsyncGeneratorFunction, eval/ShadowRealm, Array length/push/sort/join, Proxy and Object/Reflect descriptor executions. Not a full-suite status refresh.')
def save():(output/'report.json').write_text(json.dumps(report,indent=2)+'\n')
def invoke(label,args,timeout=3600,allow_failed_cases=False):
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==SOURCE
 assert not subprocess.check_output(['git','diff','--binary','HEAD','--','crates','vendor','scripts','Cargo.toml','Cargo.lock'],cwd=ROOT)
 event=dict(label=label,command=[str(compiler),'--jobs','1',*map(str,args)],started_at=stamp(),
            stdout=label+'.stdout',stderr=label+'.stderr')
 report['commands'].append(event);save()
 started=time.monotonic()
 with (output/event['stdout']).open('xb') as out,(output/event['stderr']).open('xb') as err:
  process=subprocess.Popen(event['command'],cwd=ROOT,stdout=out,stderr=err,start_new_session=True)
  try:code=process.wait(timeout=timeout)
  except BaseException:
   if process.poll() is None:os.killpg(process.pid,signal.SIGKILL)
   process.wait();raise
 event.update(returncode=code,finished_at=stamp(),seconds=time.monotonic()-started,
  stdout_sha256=digest(output/event['stdout']),stderr_sha256=digest(output/event['stderr']))
 save()
 assert code==0 or (allow_failed_cases and code==1),label+' failed; original streams retained'
 return (output/event['stdout']).read_text()
identity=json.loads(invoke('identity',['compiler-identity']))
assert identity['source_revision']==dict(kind='git-commit',commit=SOURCE)
assert identity['executable_sha256']==report['compiler']['sha256']
report['compiler']['identity']=identity;save()
suite=ROOT/'test262/vendor/test262'
filters=[
 'built-ins/Function/',
 'built-ins/AsyncFunction/',
 'built-ins/GeneratorFunction/',
 'built-ins/AsyncGeneratorFunction/',
 'built-ins/eval/',
 'built-ins/ShadowRealm/',
 'built-ins/Array/prototype/push/',
 'built-ins/Array/length/',
 'built-ins/Proxy/defineProperty/',
 'built-ins/Array/prototype/sort/',
 'built-ins/Array/prototype/join/',
 'built-ins/Proxy/getOwnPropertyDescriptor/',
 'built-ins/Proxy/get/',
 'built-ins/Proxy/set/',
 'built-ins/Proxy/has/',
 'built-ins/Proxy/deleteProperty/',
 'built-ins/Reflect/set/',
 'built-ins/Object/getOwnPropertyDescriptor/',
 'built-ins/Reflect/getOwnPropertyDescriptor/',
]
if unicode_only:
 filters=['built-ins/RegExp/property-escapes/generated/ASCII.js', 'built-ins/RegExp/property-escapes/generated/Script_-_Greek.js', 'built-ins/RegExp/property-escapes/loose-matching-01.js', 'built-ins/RegExp/property-escapes/non-existent-property-value-Script.js', 'built-ins/RegExp/unicodeSets/generated/character-property-escape-difference-property-of-strings-escape.js', 'built-ins/RegExp/unicodeSets/generated/character-class-intersection-character-property-escape.js', 'built-ins/RegExp/unicodeSets/generated/property-of-strings-escape-difference-character-property-escape.js', 'built-ins/RegExp/unicodeSets/generated/character-class-union-property-of-strings-escape.js']
 report['scope']='Separate bounded original Unicode property-escape selection; code-point properties, Script, invalid property spellings, and v-mode code-point/string-property set operations. No overlap with original 2365.'
 selected_paths=[suite/'test'/pattern for pattern in filters]
 assert all(path.is_file() for path in selected_paths)
 report['selected_source_files']=[dict(path=str(path.relative_to(suite)),sha256=digest(path),bytes=path.stat().st_size) for path in selected_paths]
if regexp_only:
 selection=json.loads((BASE/'regexp-selection.json').read_text())
 assert selection['expected_count']==32 and len(selection['files'])==16
 filters=[row['path'].removeprefix('test/') for row in selection['files']]
 for row in selection['files']:
  path=suite/row['path'];assert path.stat().st_size==row['bytes'] and digest(path)==row['sha256']
 report['scope']=selection['scope']
 report['selected_source_files']=selection['files']
if regexp_full:
 selection=json.loads((BASE/'regexp-full-selection.json').read_text())
 assert selection['expected_count']==3756 and len(selection['files'])==1879
 filters=['built-ins/RegExp/']
 for row in selection['files']:
  path=suite/row['path'];assert path.stat().st_size==row['bytes'] and digest(path)==row['sha256']
 report['scope']=selection['scope']
 report['selected_source_files']=selection['files']
 report['focused_overlap']=32
 report['unicode_overlap']=16
 report['unique_including_original']=6121
if from_async_full:
 selection=json.loads((BASE/'array-from-async-full-selection.json').read_text())
 assert selection['expected_count']==186 and len(selection['files'])==95
 filters=['built-ins/Array/fromAsync/']
 for row in selection['files']:
  path=suite/row['path'];assert path.stat().st_size==row['bytes'] and digest(path)==row['sha256']
 report['scope']=selection['scope']
 report['selected_source_files']=selection['files']
 report['unique_with_original_and_full_regexp']=6307
selected=[]
for index,pattern in enumerate(filters):
 text=invoke(f'inventory-{index:02d}',['test262','list-all',pattern,'--suite-root',suite],180)
 lines=text.splitlines()
 assert lines and lines[0].startswith('count: ')
 ids=lines[1:]
 assert ids and len(ids)==int(lines[0].removeprefix('count: ')),pattern
 assert all(re.fullmatch(r'(?:sloppy-script|strict-script|module):[^\r\n]+',s) for s in ids)
 selected.extend(ids)
original_ids=set((ROOT/'target/memory-regexp-unicode-data-20261027-evidence/conformance/executions').read_text().splitlines())
if from_async_full:
 assert len(selected)==len(set(selected))==186 and set(selected)==set(selection['expected_executions'])
 assert not set(selected).intersection(original_ids)
 regexp_ids=set(json.loads((BASE/'regexp-full-selection.json').read_text())['expected_executions'])
 assert not set(selected).intersection(regexp_ids)
elif regexp_full:
 assert len(selected)==len(set(selected))==3756 and set(selected)==set(selection['expected_executions'])
 assert not set(selected).intersection(original_ids)
 focused=json.loads((BASE/'regexp-selection.json').read_text())
 assert set(focused['expected_executions'])<=set(selected)
 unicode_ids=set((ROOT/'target/memory-regexp-unicode-data-20261027-evidence/conformance-unicode/executions').read_text().splitlines())
 assert len(unicode_ids)==16 and unicode_ids<=set(selected)
elif regexp_only:
 assert len(selected)==len(set(selected))==32 and set(selected)==set(selection['expected_executions'])
 assert not set(selected).intersection(original_ids)
 unicode_ids=set((ROOT/'target/memory-regexp-unicode-data-20261027-evidence/conformance-unicode/executions').read_text().splitlines())
 assert not set(selected).intersection(unicode_ids)
 report['separate_from_original_executions']=2365
 report['separate_from_unicode_executions']=16
elif unicode_only:
 assert selected and len(selected)==len(set(selected)) and not set(selected).intersection(original_ids)
 assert len(selected)==16, 'retain the exact separate Unicode selection'
 assert set(selected)==set((ROOT/'target/memory-regexp-unicode-data-20261027-evidence/conformance-unicode/executions').read_text().splitlines())
 report['separate_from_original_executions']=2365
else:
 assert len(selected)==len(set(selected))==2365 and set(selected)==original_ids,'retain all original pinned execution IDs'
execution_list=output/'executions'
execution_list.write_text('\n'.join(sorted(selected))+'\n')
report.update(selected_executions=len(selected),execution_list_sha256=digest(execution_list))
save();print('selected',len(selected),'original executions',flush=True)
selected = sorted(selected)
report['batch_limit'] = 16
report['batches'] = []
counts=dict(Bug=0,Crash=0,NotImplemented=0,Success=0)
failures=[];timeouts=[]
for offset in range(0,len(selected),16):
 ids=selected[offset:offset+16];label=f'execute-{offset//16:03d}'
 listing=output/(label+'.executions');listing.write_text('\n'.join(ids)+'\n')
 text=invoke(label,['test262','run-list',listing,'--execution-backend','wasm-aot',
  '--suite-root',suite,'--snapshot-dir',output/'snapshots'/label,'--snapshot-name',label,
  '--threads','1','--timeout-ms','60000','--reuse-case-workers'],allow_failed_cases=regexp_full or from_async_full)
 assert re.findall(r'^total: (\d+)$',text,re.M)==[str(len(ids))]
 snapshot,=(output/'snapshots'/label).glob('*.json');snap=json.loads(snapshot.read_text())
 assert snap['total']==len(ids) and set(snap['completed_test_ids'])==set(ids)
 assert snap['compiler_identity']==identity
 assert set(snap['counts_per_outcome'])==set(counts) and sum(snap['counts_per_outcome'].values())==len(ids)
 assert snap['passed']==snap['counts_per_outcome']['Success']
 if not (regexp_full or from_async_full):
  assert snap['passed']==len(ids) and not snap['failures'] and not snap['timeout_test_ids']
  assert snap['counts_per_outcome']==dict(Bug=0,Crash=0,NotImplemented=0,Success=len(ids))
 for key in counts:counts[key]+=snap['counts_per_outcome'][key]
 failures.extend(snap['failures']);timeouts.extend(snap['timeout_test_ids'])
 report['batches'].append(dict(list_file=listing.name,list_sha256=digest(listing),snapshot_file=str(snapshot.relative_to(output)),snapshot_sha256=digest(snapshot),passed=snap['passed'],total=snap['total'],counts_per_outcome=snap['counts_per_outcome']))
 report.update(counts_per_outcome=counts,failures=failures,timeout_test_ids=timeouts)
 save();print('completed',offset+len(ids),'/',len(selected),'executions; passed',counts['Success'],flush=True)
assert digest(compiler)==report['compiler']['sha256']
report.update(complete=True,finished_at=stamp(),after=budget(),total=len(selected),passed=counts['Success'],all_passed=counts['Success']==len(selected),
 snapshots=[dict(file=str(p.relative_to(output)),sha256=digest(p),bytes=p.stat().st_size)
            for p in sorted((output/'snapshots').rglob('*.json'))])
save();print('completed',len(selected),'executions; passed',counts['Success'],flush=True)
if counts['Success']!=len(selected):raise SystemExit(1)
