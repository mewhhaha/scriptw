from datetime import datetime,timezone
import hashlib,json,os,subprocess,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'scripts'))
from limited_verification import require_kernel_budget,kernel_group
import argparse
arguments=argparse.ArgumentParser(description='Verify the complete shared RegExp recovery batch; preserve exact accessor inventories.')
arguments.add_argument('--expected-source',required=True)
arguments.add_argument('--required-repair-source',required=True)
arguments.add_argument('--full-array-from-async',action='store_true',help='also run all186 pinned Array.fromAsync executions in fresh batches<=16')
arguments.add_argument('--full-regexp',action='store_true',help='also run all3756 pinned RegExp executions after targeted32; overlap is not additional unique passes')
options=arguments.parse_args()
assert options.expected_source=='9001324dc52ce583e7b95a1292f317796d415c01'
assert options.full_regexp and options.full_array_from_async, 'full6307 campaign required'
assert options.required_repair_source=='54231ef4d3eb1fa6e1a39f34698d3d0f3668d1b1'
os.environ['SCRIPTW_EXPECTED_SOURCE']=options.expected_source
os.environ['SCRIPTW_REQUIRED_REPAIR_SOURCE']=options.required_repair_source
os.environ['CARGO_BUILD_JOBS']='1'
os.environ['RUST_TEST_THREADS']='1'

require_kernel_budget(4*1024**3);assert sorted(os.sched_getaffinity(0))==[0]
SOURCE=os.environ['SCRIPTW_EXPECTED_SOURCE']
assert SOURCE=='9001324dc52ce583e7b95a1292f317796d415c01'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==SOURCE
assert os.environ['SCRIPTW_REQUIRED_REPAIR_SOURCE']=='54231ef4d3eb1fa6e1a39f34698d3d0f3668d1b1'
assert subprocess.run(['git','merge-base','--is-ancestor',os.environ['SCRIPTW_REQUIRED_REPAIR_SOURCE'],SOURCE],cwd=ROOT).returncode==0
assert subprocess.run(['git','merge-base','--is-ancestor','00fcf97fbffde8137a67d6ed7ed4803e86384ef1',SOURCE],cwd=ROOT).returncode==0
assert os.environ['SCRIPTW_MODULE_MEMORY_CACHE_ENTRIES']=='1'
assert os.environ['SCRIPTW_MODULE_MEMORY_CACHE_LIMIT_BYTES']==str(64*1024**2)

group=kernel_group()
def budget():return {k:(group/k).read_text().strip() for k in ['memory.max','memory.swap.max','memory.oom.group','memory.peak','memory.events']}
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
assert not (BASE/'verification.json').exists(), 'fresh evidence directory required'
baseline_path=ROOT/'target/memory-eager-accessors-20261027-evidence/retry-00fcf97fb/native/report.json'
baseline=json.loads(baseline_path.read_text())
assert baseline['complete'] and baseline['source_commit']=='00fcf97fbffde8137a67d6ed7ed4803e86384ef1' and baseline['passed_disjoint_scopes']==4881 and len(baseline['scopes'])==19
# Every retry rebuilt from a new exact source fingerprint. No binary reuse.
previous=BASE.parent/'retry-6ff184014'
v=json.loads((previous/'verification.json').read_text());n=json.loads((previous/'native/report.json').read_text());c=json.loads((previous/'check.json').read_text())
assert v['source_commit']==n['source_commit']==c['source_commit']=='6ff1840146c312d3564b322fe13e4bbf0f97527e'
assert not v['complete'] and not n['complete'] and 'after' not in v and 'after' not in n
assert c['complete'] is True and c['exit_code']==0 and sha(previous/'cargo-check.jsonl')==c['stdout_sha256']
assert [(r['label'],r.get('exit_code')) for r in v['commands']]==[('cheap-main-driver',0),('cargo-check-driver',0),('native-driver',1)]
assert [(r['label'],r.get('exit_code')) for r in n['commands'] if r.get('exit_code')]==[('scriptw-engine-scriptw_engine-part-031',101)]
assert len(n['scopes'])==7 and sum(s.get('passed',0) for s in n['scopes'])==1337
assert sum(s['complete'] for s in n['scopes'])==6
assert n['scopes'][-1]['target']=='scriptw_engine' and n['scopes'][-1]['passed']==248 and not n['scopes'][-1]['complete']
from native_test_protocol import result_summaries
assert result_summaries((previous/'native/scriptw-engine-scriptw_engine-part-031.stdout').read_text())==[('FAILED','7','1','0','0','1045')]
for record,folder in ((v,previous),(n,previous/'native')):
 for r in record['commands']:
  for stream in ('stdout','stderr'):assert sha(folder/r[stream])==r[stream+'_sha256']
assert not any((previous/x).exists() for x in ('conformance','conformance-unicode','conformance-regexp','conformance-regexp-full','conformance-array-from-async'))
# Preserve both prior physical-test failures and the successful dirty diagnostic
# probe separately; neither is reinterpreted as a verified source execution.
history={}
for label,folder in [('a26',BASE.parent),('1c4',BASE.parent/'retry-1c4f0e334')]:
 oldv=json.loads((folder/'verification.json').read_text());oldn=json.loads((folder/'native/report.json').read_text());oldc=json.loads((folder/'check.json').read_text())
 assert oldc['complete'] is True and oldc['exit_code']==0 and sha(folder/'cargo-check.jsonl')==oldc['stdout_sha256']
 assert not oldv['complete'] and not oldn['complete'] and 'after' not in oldv and 'after' not in oldn
 assert len(oldn['scopes'])==1 and not oldn['scopes'][0]['complete'] and not oldn['scopes'][0].get('passed')
 assert result_summaries((folder/'native/scriptw-aot-wasm-emission-focused-00.stdout').read_text())==[('FAILED','0','1','0','0','32')]
 for record,subfolder in ((oldv,folder),(oldn,folder/'native')):
  for r in record['commands']:
   for stream in ('stdout','stderr'):assert sha(subfolder/r[stream])==r[stream+'_sha256']
 assert not any((folder/x).exists() for x in ('conformance','conformance-unicode','conformance-regexp','conformance-regexp-full','conformance-array-from-async'))
 history[label]=dict(check_sha256=sha(folder/'check.json'),verification_sha256=sha(folder/'verification.json'),native_report_sha256=sha(folder/'native/report.json'),passed=0,failed=1,completed_scopes=0)
probe_path=BASE.parent/'probe-shared-region/receipt.json';probe=json.loads(probe_path.read_text())
assert probe['complete'] is True and probe['diagnostic_dirty_test'] is True and probe['verified_source_claim'] is False and probe['passed']==1 and probe['filtered_out']==32
for r in probe['commands']:
 for stream in ('stdout','stderr'):assert sha(probe_path.parent/r[stream])==r[stream+'_sha256']
assert sha(probe_path.parent/probe['binary']['path'])==probe['binary']['sha256']
assert sha(probe_path.parent/probe['patch']['path'])==probe['patch']['sha256']
bindings_path=BASE/'source-bindings-computed.json';bindings=json.loads(bindings_path.read_text())
assert len(bindings)==2 and all(r['revision']==SOURCE for r in bindings)
priorbindings=json.loads((previous/'source-bindings-computed.json').read_text())
for mode in (False,True):
 now=next(r for r in bindings if r['extra_ignored_regress_lock']==mode)
 old=next(r for r in priorbindings if r['extra_ignored_regress_lock']==mode)
 assert now['source_fingerprint']!=old['source_fingerprint'], 'production-file footprint requires fresh closure'
# The field-access compile failure and successful dirty probe remain separate.
failed95=BASE.parent/'retry-95b84740a'
f95=json.loads((failed95/'verification.json').read_text());c95=json.loads((failed95/'check.json').read_text())
assert f95['source_commit']==c95['source_commit']=='95b84740a0c61a2b1cd05eaa2fbd2ce2cf9b35a0'
assert not f95['complete'] and 'after' not in f95 and not c95['complete'] and c95['exit_code']==101
assert [(r['label'],r.get('exit_code')) for r in f95['commands']]==[('cheap-main-driver',0),('cargo-check-driver',101)]
for r in f95['commands']:
 for stream in ('stdout','stderr'):assert sha(failed95/r[stream])==r[stream+'_sha256']
assert sha(failed95/'cargo-check.jsonl')==c95['stdout_sha256'] and sha(failed95/'cargo-check.stderr')==c95['stderr_sha256']
assert not any((failed95/x).exists() for x in ('native','conformance','conformance-unicode','conformance-regexp','conformance-regexp-full','conformance-array-from-async'))
compile_messages=[json.loads(line) for line in (failed95/'cargo-check.jsonl').read_text().splitlines() if line.startswith('{')]
errors=[r['message'] for r in compile_messages if r.get('reason')=='compiler-message' and r['message']['level']=='error']
assert len(errors)==1 and errors[0]['code']['code']=='E0599' and 'runtime' in errors[0]['message']
mode_path=BASE.parent/'probe-mode-cache/receipt.json';mode=json.loads(mode_path.read_text())
assert mode['complete'] is True and mode['diagnostic_dirty_test'] is True and mode['verified_source_claim'] is False
assert mode['head_commit']=='95b84740a0c61a2b1cd05eaa2fbd2ce2cf9b35a0' and (mode['passed'],mode['failed'],mode['filtered_out'])==(1,0,1052)
file='crates/scriptw-engine/src/runtime_profile.rs';assert mode['test_path']==file
assert hashlib.sha256(subprocess.check_output(['git','show',SOURCE+':'+file],cwd=ROOT)).hexdigest()==mode['test_source_sha256']
patch=mode_path.parent/mode['patch']['path'];assert sha(patch)==mode['patch']['sha256']
assert subprocess.check_output(['git','diff','--binary',mode['head_commit'],SOURCE,'--',file],cwd=ROOT)==patch.read_bytes()
assert subprocess.check_output(['git','diff','--name-only',mode['head_commit'],'80b842693e964634f378d5813f6db684ee7d255b'],cwd=ROOT).decode().splitlines()==[file]
assert sha(mode_path.parent/mode['binary']['path'])==mode['binary']['sha256']
for r in mode['commands']:
 for stream in ('stdout','stderr'):assert sha(mode_path.parent/r[stream])==r[stream+'_sha256']
from resume_admission import admit
resume_admission=admit(BASE,ROOT)
report=dict(native_resume_admission=resume_admission,measured_source_commit="80b842693e964634f378d5813f6db684ee7d255b",failed95_check=dict(verification_sha256=sha(failed95/"verification.json"),check_sha256=sha(failed95/"check.json"),exit_code=101,error="E0599",native_executed=False,conformance_executed=False),mode_cache_diagnostic_probe=dict(receipt_sha256=sha(mode_path),verified_source_claim=False,final_file_sha256=mode["test_source_sha256"],patch_sha256=sha(patch),passed=1,filtered_out=1052,binary_reused=False),fresh_all19_native_build=False,no_native_compilation=True,source_bindings_sha256=sha(bindings_path),prior_physical_failures=history,dirty_probe_receipt_sha256=sha(probe_path),predecessor_cache_failure=dict(verification_sha256=sha(previous/"verification.json"),native_report_sha256=sha(previous/"native/report.json"),tracked_passes=1337,completed_scopes=6,partial_engine_passes=248,failed_chunk_passed=7,failed_chunk_failed=1,conformance_executed=False),full_array_from_async_requested=options.full_array_from_async,full_regexp_requested=options.full_regexp,native_baseline=dict(path=str(baseline_path),sha256=sha(baseline_path),source_commit=baseline['source_commit'],passed=4881),required_repair_source=options.required_repair_source,source_commit=SOURCE,complete=False,started_at=datetime.now(timezone.utc).isoformat(),before=budget(),cpu_affinity=sorted(os.sched_getaffinity(0)),commands=[])
def save():(BASE/'verification.json').write_text(json.dumps(report,indent=2)+'\n')
build=ROOT/'target/performance-work-20261024/build'
plan=[('cheap-main-driver',[sys.executable,'-B',str(BASE/'cheap-main-current.py')]),('cargo-check-driver',[sys.executable,'-B',str(BASE/'check.py')]),('native-driver',[sys.executable,'-B',str(BASE/'native.py')]),('cargo-products',['cargo','build','--locked','--offline','--release','--jobs','1','--target-dir',str(build),'-p','scriptw-cli','--bin','scriptw','--example','compiler_precompiled_baseline','--message-format=json']),('test262-driver',[sys.executable,'-B',str(BASE/'test262.py')]),('test262-unicode-driver',[sys.executable,'-B',str(BASE/'test262.py'),'--unicode']),('test262-regexp-driver',[sys.executable,'-B',str(BASE/'test262.py'),'--regexp'])]
if options.full_regexp:plan.append(('test262-regexp-full-driver',[sys.executable,'-B',str(BASE/'test262.py'),'--regexp-full']))
if options.full_array_from_async:plan.append(('test262-array-from-async-driver',[sys.executable,'-B',str(BASE/'test262.py'),'--array-from-async-full']))
save()
for label,args in plan:
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==SOURCE
 assert not subprocess.check_output(['git','diff','--binary','HEAD','--','crates','vendor','scripts','Cargo.toml','Cargo.lock'],cwd=ROOT)
 print(label,'started',flush=True);out=BASE/(label+('.jsonl' if label=='cargo-products' else '.stdout'));err=BASE/(label+'.stderr');row=dict(label=label,command=args,stdout=out.name,stderr=err.name);report['commands'].append(row);save();start=time.monotonic()
 with out.open('xb') as stdout,err.open('xb') as stderr:r=subprocess.run(args,cwd=ROOT,stdout=stdout,stderr=stderr,timeout=10800)
 row.update(exit_code=r.returncode,seconds=time.monotonic()-start,stdout_sha256=sha(out),stderr_sha256=sha(err));save();print(label,'finished',r.returncode,flush=True)
 if r.returncode:
  print(err.read_text()[-12000:],flush=True);raise SystemExit(r.returncode)
report.update(complete=True,finished_at=datetime.now(timezone.utc).isoformat(),after=budget());save();print('verification complete',flush=True)
