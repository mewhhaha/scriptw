from datetime import datetime,timezone
import hashlib,json,os,subprocess,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'scripts'))
from limited_verification import require_kernel_budget,kernel_group
import argparse
arguments=argparse.ArgumentParser(description='Verify the complete shared RegExp recovery batch; preserve exact accessor inventories.')
arguments.add_argument('--expected-source',required=True)
arguments.add_argument('--required-repair-source',required=True)
arguments.add_argument('--full-array-from-async',action='store_true',help='also run all186 pinned Array.fromAsync executions in fresh batches<=16')
arguments.add_argument('--full-regexp',action='store_true',help='also run all3756 pinned RegExp executions after targeted32; overlap is not additional unique passes')
options=arguments.parse_args()
assert len(options.expected_source)==40 and all(c in '0123456789abcdef' for c in options.expected_source)
assert options.required_repair_source=='54231ef4d3eb1fa6e1a39f34698d3d0f3668d1b1'
os.environ['SCRIPTW_EXPECTED_SOURCE']=options.expected_source
os.environ['SCRIPTW_REQUIRED_REPAIR_SOURCE']=options.required_repair_source
os.environ['CARGO_BUILD_JOBS']='1'
os.environ['RUST_TEST_THREADS']='1'

require_kernel_budget(4*1024**3);assert sorted(os.sched_getaffinity(0))==[0]
SOURCE=os.environ['SCRIPTW_EXPECTED_SOURCE']
assert len(SOURCE)==40 and all(c in '0123456789abcdef' for c in SOURCE)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==SOURCE
assert os.environ['SCRIPTW_REQUIRED_REPAIR_SOURCE']=='54231ef4d3eb1fa6e1a39f34698d3d0f3668d1b1'
assert subprocess.run(['git','merge-base','--is-ancestor',os.environ['SCRIPTW_REQUIRED_REPAIR_SOURCE'],SOURCE],cwd=ROOT).returncode==0
assert subprocess.run(['git','merge-base','--is-ancestor','00fcf97fbffde8137a67d6ed7ed4803e86384ef1',SOURCE],cwd=ROOT).returncode==0
assert os.environ['SCRIPTW_MODULE_MEMORY_CACHE_ENTRIES']=='1'
assert os.environ['SCRIPTW_MODULE_MEMORY_CACHE_LIMIT_BYTES']==str(64*1024**2)

group=kernel_group()
def budget():return {k:(group/k).read_text().strip() for k in ['memory.max','memory.swap.max','memory.oom.group','memory.peak','memory.events']}
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
assert not (BASE/'verification.json').exists(), 'fresh evidence directory required'
baseline_path=ROOT/'target/memory-eager-accessors-20261027-evidence/retry-00fcf97fb/native/report.json'
baseline=json.loads(baseline_path.read_text())
assert baseline['complete'] and baseline['source_commit']=='00fcf97fbffde8137a67d6ed7ed4803e86384ef1' and baseline['passed_disjoint_scopes']==4881 and len(baseline['scopes'])==19
report=dict(full_array_from_async_requested=options.full_array_from_async,full_regexp_requested=options.full_regexp,native_baseline=dict(path=str(baseline_path),sha256=sha(baseline_path),source_commit=baseline['source_commit'],passed=4881),required_repair_source=options.required_repair_source,source_commit=SOURCE,complete=False,started_at=datetime.now(timezone.utc).isoformat(),before=budget(),cpu_affinity=sorted(os.sched_getaffinity(0)),commands=[])
def save():(BASE/'verification.json').write_text(json.dumps(report,indent=2)+'\n')
build=ROOT/'target/performance-work-20261024/build'
plan=[('cheap-main-driver',[sys.executable,'-B',str(BASE/'cheap-main-current.py')]),('cargo-check-driver',[sys.executable,'-B',str(BASE/'check.py')]),('native-driver',[sys.executable,'-B',str(BASE/'native.py')]),('cargo-products',['cargo','build','--locked','--offline','--release','--jobs','1','--target-dir',str(build),'-p','scriptw-cli','--bin','scriptw','--example','compiler_precompiled_baseline','--message-format=json']),('test262-driver',[sys.executable,'-B',str(BASE/'test262.py')]),('test262-unicode-driver',[sys.executable,'-B',str(BASE/'test262.py'),'--unicode']),('test262-regexp-driver',[sys.executable,'-B',str(BASE/'test262.py'),'--regexp'])]
if options.full_regexp:plan.append(('test262-regexp-full-driver',[sys.executable,'-B',str(BASE/'test262.py'),'--regexp-full']))
if options.full_array_from_async:plan.append(('test262-array-from-async-driver',[sys.executable,'-B',str(BASE/'test262.py'),'--array-from-async-full']))
save()
for label,args in plan:
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==SOURCE
 assert not subprocess.check_output(['git','diff','--binary','HEAD','--','crates','vendor','scripts','Cargo.toml','Cargo.lock'],cwd=ROOT)
 print(label,'started',flush=True);out=BASE/(label+('.jsonl' if label=='cargo-products' else '.stdout'));err=BASE/(label+'.stderr');row=dict(label=label,command=args,stdout=out.name,stderr=err.name);report['commands'].append(row);save();start=time.monotonic()
 with out.open('xb') as stdout,err.open('xb') as stderr:r=subprocess.run(args,cwd=ROOT,stdout=stdout,stderr=stderr,timeout=10800)
 row.update(exit_code=r.returncode,seconds=time.monotonic()-start,stdout_sha256=sha(out),stderr_sha256=sha(err));save();print(label,'finished',r.returncode,flush=True)
 if r.returncode:
  print(err.read_text()[-12000:],flush=True);raise SystemExit(r.returncode)
report.update(complete=True,finished_at=datetime.now(timezone.utc).isoformat(),after=budget());save();print('verification complete',flush=True)
