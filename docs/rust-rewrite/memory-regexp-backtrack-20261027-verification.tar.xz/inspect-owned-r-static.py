"""Static inspection of owned Cargo outputs; no compilation/deserialization/execution."""
import hashlib
import json
from pathlib import Path
import stat
import struct
import subprocess
import os

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
SOURCE = 'a26f8c9796d3d7284f5bc0537df1dd336c1641b6'
PRIOR = '38c25942b63a752ce5db46b6cb42b46ed98f9a57'
OLD = ROOT/'target/memory-phase-boundaries-20261027-evidence'
RETRY = BASE/'retry-a960f50ac'


def read(path):
    return json.loads(path.read_text())


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def owned(path, maximum):
    info = path.lstat()
    assert stat.S_ISREG(info.st_mode) and info.st_uid == os.getuid() and info.st_size <= maximum
    return info


def package(path, fingerprint, layout):
    owned(path, 128*1024**2)
    raw = path.read_bytes()
    assert raw[:8] == b'SCRWRB01' and struct.unpack_from('<I', raw, 8)[0] == layout
    assert raw[12:44].hex() == fingerprint
    assert hashlib.sha256(raw[:-32]).digest() == raw[-32:]
    static, utf16, strings, wasm = struct.unpack_from('<QQIQ', raw, 108)
    assert wasm == len(raw)-168 and raw[136:144] == b'\0asm\1\0\0\0'
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest(),
                wasm_bytes=wasm, static_bytes=static, pooled_utf16_bytes=utf16, strings=strings, layout=layout,
                source_fingerprint=fingerprint)


def inspect(label, directory, fingerprint, layout, portable):
    prefix = "scriptw-runtime-portable" if portable else "scriptw-runtime"
    path = directory/(prefix+'-package.bin')
    result = package(path, fingerprint, layout)
    native = directory/(prefix+'-native.bin')
    manifest = directory/(prefix+'-manifest.bin')
    owned(native, 256*1024**2)
    owned(manifest, 4096)
    raw = manifest.read_bytes()
    assert raw[:8] == b'SCRWNR01' and struct.unpack_from('<I', raw, 8)[0] == 5
    target_length = struct.unpack_from('<H', raw, 19)[0]
    assert 0 < target_length <= 256 and len(raw) == 21+target_length+128
    target = raw[21:21+target_length].decode('ascii')
    offset = 21+target_length
    source, key, package_digest, native_digest = [raw[offset+i*32:offset+(i+1)*32].hex() for i in range(4)]
    assert source == fingerprint and package_digest == result['sha256'] and native_digest == sha(native)
    with native.open('rb') as stream:
        assert stream.read(4) == b'\x7fELF'
    argv = ['nm', '--print-size', '--size-sort', '--defined-only', str(native)]
    completed = subprocess.run(argv, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False, timeout=30)
    assert completed.returncode == 0 and len(completed.stdout) < 4*1024**2 and len(completed.stderr) < 4096
    (BASE/(label+'-r-symbols.stdout')).write_bytes(completed.stdout)
    (BASE/(label+'-r-symbols.stderr')).write_bytes(completed.stderr)
    helpers = {}
    for name in ('helper::regexp_matcher', 'builtin::Array.fromAsync?Fulfilled?Function'):
        rows = [line.split() for line in completed.stdout.decode().splitlines() if line.split() and line.split()[-1].endswith('::'+name)]
        assert len(rows) == 1, (label, name, rows)
        helpers[name] = None if not rows else int(rows[0][1], 16)
    assert sha(native) == native_digest and sha(path) == result['sha256']
    return dict(package=result, manifest=dict(path=str(manifest), sha256=sha(manifest), source_fingerprint=source,
        target=target, configuration=struct.unpack_from('<I',raw,12)[0], modes=list(raw[16:19]), runtime_key=key,
        package_digest=package_digest,native_digest=native_digest),
        native=dict(path=str(native), bytes=native.stat().st_size,sha256=native_digest),
        symbol_command=dict(argv=argv,returncode=0,stdout=label+'-r-symbols.stdout',stderr=label+'-r-symbols.stderr',
            stdout_sha256=hashlib.sha256(completed.stdout).hexdigest(),stderr_sha256=hashlib.sha256(completed.stderr).hexdigest()),
        helper_native_bytes=helpers)


def main():
    # This gate precedes any generated-artifact read or nm invocation.
    check_path = BASE/'check.json'
    check = read(check_path)
    assert check.get('complete') is True and check.get('exit_code') == 0 and check['source_commit'] == SOURCE
    log = BASE/'cargo-check.jsonl'
    assert sha(log) == check['stdout_sha256']
    producers = [r for line in log.read_bytes().splitlines() if line.startswith(b'{') for r in [json.loads(line)]
        if r.get('reason') == 'build-script-executed' and r.get('package_id') == 'path+file:///home/mewhhaha/src/porffor/crates/scriptw-runtime-image#0.1.0']
    assert len(producers) == 1
    oldbase = ROOT/'target/memory-eager-accessors-20261027-evidence'
    published = read(ROOT/'docs/rust-rewrite/memory-eager-accessors-20261027.json')
    oldpath = oldbase/'owned-r-static.json'
    retained = {r['path']:r for r in published['retained_files']}
    assert sha(oldpath) == retained['owned-r-static.json']['sha256']
    old = read(oldpath)
    assert old['source_commit'] == 'a960f50acea8bd3a1de0a2c391bbb09b88f2ee4d'
    # Cargo may reuse an outdir. Recover only a byte-identical owned prior
    # package, with all manifest/native checks still performed below.
    old_candidates = list((ROOT/'target/performance-work-20261024/build/release/build').glob('scriptw-runtime-image-*/out/scriptw-runtime-portable-package.bin'))
    old_candidates = [p for p in old_candidates if sha(p) == old['current']['package']['sha256']]
    assert old_candidates, 'no exact published prior package remains'
    olddir = sorted(old_candidates)[0].parent
    bindings_path = BASE/'source-bindings-computed.json'
    local = [r for r in read(bindings_path) if r['revision'] == SOURCE and r['extra_ignored_regress_lock']]
    assert len(local) == 1
    currentdir = Path(producers[0]['out_dir'])
    variants = {}
    for portable in (True, False):
        mode = 'Portable' if portable else 'NativeHost'
        prefix = 'scriptw-runtime-portable' if portable else 'scriptw-runtime'
        if not all((d/(prefix+'-native.bin')).is_file() for d in (olddir,currentdir)):
            variants[mode] = {'available':False};continue
        before = inspect('prior-'+mode, olddir, old['current']['package']['source_fingerprint'], 28, portable)
        after = inspect('current-'+mode, currentdir, local[0]['source_fingerprint'], 28, portable)
        if portable:
            assert before['package']['sha256'] == old['current']['package']['sha256']
            assert before['native']['sha256'] == old['current']['native']['sha256']
        for key in ('target','configuration','modes'):
            assert before['manifest'][key] == after['manifest'][key]
        variants[mode] = dict(available=True,prior=before,current=after,deltas=dict(
            package_bytes=after['package']['bytes']-before['package']['bytes'],
            raw_wasm_bytes=after['package']['wasm_bytes']-before['package']['wasm_bytes'],
            native_image_bytes=after['native']['bytes']-before['native']['bytes'],
            helper_native_bytes={k:after['helper_native_bytes'][k]-before['helper_native_bytes'][k] for k in before['helper_native_bytes']}))
    result = dict(source_commit=SOURCE,prior_source_commit=old['source_commit'],scored=False,
        scope='Static owned Cargo package and native ELF sizes only. Not RSS, residency, live heap, or causal memory savings. No compilation/deserialization/native execution.',
        current_check=dict(path=str(check_path),sha256=sha(check_path),stdout_sha256=sha(log)),
        cargo_producer=producers[0],source_bindings=dict(path=str(bindings_path),sha256=sha(bindings_path)),
        prior_published_static=dict(path=str(oldpath),sha256=sha(oldpath)),variants=variants)
    output=BASE/'owned-r-static.json';assert not output.exists()
    output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v.get('deltas',v) for k,v in variants.items()},indent=2))

if __name__ == '__main__': main()
