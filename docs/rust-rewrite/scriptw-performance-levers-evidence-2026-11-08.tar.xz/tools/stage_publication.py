#!/usr/bin/env python3
"""Stage current RSC/situation reports and a text-only evidence archive."""
import argparse
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT / 'target/performance-levers-20261108'
ARCHIVER = ROOT / 'target/react-performance-20261103/archive_final.py'
RSC_RENDERER = ROOT / 'scripts/render-application-benchmarks.py'
SITUATION_RENDERER = ROOT / 'scripts/render-situation-benchmarks.py'
sys.path.insert(0, str(ROOT / 'scripts'))
TEXT_SUFFIXES = {'.json', '.jsonl', '.receipt', '.stdout', '.stderr', '.list', '.txt', '.map', '.rs',
                 '.js', '.cjs', '.mjs', '.py', '.md', '.toml', '.patch', '.snap', '.csv', '.svg', '.sh', '.log'}
FORBIDDEN_NAMES = {'perf.data', 'callchains.json'}
FORBIDDEN_SUFFIXES = {'.wasm', '.so', '.a', '.rlib', '.rmeta', '.o', '.dylib', '.dll', '.exe', '.bin', '.xz', '.zst', '.zip'}
INTERNAL_TEST_ONLY_FILE = 'crates/scriptw-aot-wasm/src/tests/local_argument_calls.rs'
MIXED_CFG_TEST_FILE = 'crates/scriptw-aot-wasm/src/functions/numeric_body.rs'
COMPILER_TEST_EXCLUSION_FILE = 'crates/scriptw-engine/compiler_fingerprint.rs'
TEST_MODULE_FILE = 'crates/scriptw-aot-wasm/src/tests.rs'
TEST_GATE_FILE = 'crates/scriptw-aot-wasm/src/lib.rs'


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def encoded(value):
    return (json.dumps(value, indent=2, allow_nan=False) + '\n').encode()


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def require_text_file(path):
    path = Path(path).resolve(strict=True)
    assert path.is_file() and not path.is_symlink(), f'not a regular evidence file: {path}'
    assert path.name not in FORBIDDEN_NAMES and path.suffix.lower() not in FORBIDDEN_SUFFIXES, path
    assert path.suffix.lower() in TEXT_SUFFIXES or path.name in {'stdout', 'stderr'}, (
        f'not an admitted text evidence type: {path}')
    data = path.read_bytes()
    assert b'\0' not in data and data[:4] not in (b'\x7fELF', b'\x00asm'), f'binary evidence rejected: {path}'
    data.decode('utf-8')
    return path


def add_evidence_tree(archive, source, prefix):
    source = Path(source).resolve(strict=True)
    assert source.is_relative_to(ROOT) and source.is_dir() and not source.is_symlink()
    for path in sorted(source.rglob('*')):
        if path.is_dir():
            assert not path.is_symlink(), f'symlink in evidence tree: {path}'
            continue
        if path.name in FORBIDDEN_NAMES or path.suffix.lower() in FORBIDDEN_SUFFIXES:
            continue
        if path.suffix.lower() not in TEXT_SUFFIXES and path.name not in {'stdout', 'stderr'}:
            continue
        path = require_text_file(path)
        member = prefix.rstrip('/') + '/' + path.relative_to(source).as_posix()
        archive.add_file(member, path)


def add_source_snapshot(archive, manifest_path, prefix='source/current'):
    root = Path(manifest_path).parent
    manifest = read(manifest_path)
    listed = manifest['files']
    archive.add_file(prefix + '/manifest.json', require_text_file(manifest_path))
    archive.add_file(prefix + '/tracked.patch', require_text_file(root / 'tracked.patch'))
    archive.add_file(prefix + '/baseline/rsc-current.json',
                     require_text_file(root / 'baseline/rsc-current.json'))
    for relative, record in sorted(listed.items()):
        source = require_text_file(root / 'files' / relative)
        assert sha(source) == record['sha256'], f'frozen source snapshot hash mismatch: {relative}'
        archive.add_file(prefix + '/files/' + relative, source)
    present = {p.relative_to(root / 'files').as_posix() for p in (root / 'files').rglob('*') if p.is_file()}
    assert present == set(listed), 'frozen source snapshot inventory differs from manifest'


def add_rsc_campaign(archive, campaign_path, aggregate_path):
    root = Path(campaign_path).parent
    campaign = read(campaign_path)
    aggregate = read(aggregate_path)
    archive.add_file('rsc/campaign.json', require_text_file(campaign_path))
    archive.add_file('rsc/aggregate.json', require_text_file(aggregate_path))
    for path in sorted((root / 'inputs').rglob('*')):
        if path.is_file():
            source = require_text_file(path)
            archive.add_file('rsc/inputs/' + path.relative_to(root / 'inputs').as_posix(), source)
    for row in campaign['processes']:
        assert row['status'] == 'complete'
        for field in ('report', 'stdout', 'stderr'):
            relative = Path(row[field])
            assert not relative.is_absolute() and '..' not in relative.parts
            source = require_text_file(root / relative)
            assert sha(source) == row[field + '_sha256'], f'campaign {field} hash mismatch: {relative}'
            archive.add_file('rsc/' + relative.as_posix(), source)


def validate_campaign(campaign_path, aggregate_path, manifest_path):
    campaign, aggregate = read(campaign_path), read(aggregate_path)
    manifest = read(manifest_path)
    assert campaign['schema'] == 'scriptw-rsc-levers-campaign-v1'
    assert campaign['status'] == 'complete' and len(campaign['processes']) == 32
    assert aggregate['schema'] == 'scriptw-rsc-levers-aggregate-v1'
    assert aggregate['source_manifest_sha256'] == sha(manifest_path)
    assert campaign['source_manifest_sha256'] == sha(manifest_path)
    assert manifest['base_git'] == '7b98415010501ab7c8f78dbf81661c06a9cb20bf'
    assert manifest['runtime_abi'] == 53
    assert aggregate['runtime_abi'] == 53
    assert aggregate['measurement']['campaign_sha256'] == sha(campaign_path)
    assert aggregate['measurement']['checked_flight_calls'] == 640
    assert aggregate['measurement']['actors'] == ['baseline', 'candidate', 'candidate-speed', 'v8']
    assert campaign['policy']['actors'] == aggregate['measurement']['actors']
    assert campaign['policy']['blocks'] == 2
    assert campaign['policy']['processes_per_actor_per_block'] == 4
    assert campaign['policy']['samples'] == 7 and campaign['policy']['warmups'] == 3
    for actor in campaign['policy']['actors']:
        rows = [row for row in campaign['processes'] if row['actor'] == actor]
        assert len(rows) == 8 and all(row['status'] == 'complete' for row in rows), actor
        engine = aggregate['engines'][actor]
        assert set(engine['cases']) == {'rsc-sync', 'rsc-async'}
        assert all(len(values) == 8 and all(type(v) is int and v > 0 for v in values)
                   for values in engine['cases'].values())
        if actor != 'v8':
            assert len(engine['phase_processes']) == 8
    fast = aggregate['engines']['candidate']['identity']
    speed = aggregate['engines']['candidate-speed']['identity']
    for key in ('source_fingerprint', 'source_commit', 'executable_sha256', 'program_wasm_sha256',
                'runtime', 'inputs'):
        assert fast[key] == speed[key], f'Fast/Speed identity mismatch: {key}'
    assert fast['configuration']['cranelift_opt_level'] == 'None'
    assert fast['configuration']['register_allocation'] == 'SinglePass'
    assert speed['configuration']['cranelift_opt_level'] == 'Speed'
    assert speed['configuration']['register_allocation'] == 'Backtracking'
    assert campaign['candidate']['sha256'] == fast['executable_sha256']
    baseline_identity = campaign['baseline']['identity']
    measured_baseline = aggregate['engines']['baseline']['identity']
    for key in ('source_fingerprint', 'source_commit', 'executable_sha256', 'compiler_identity_scheme',
                'toolchain', 'configuration', 'program_wasm_sha256', 'runtime', 'inputs'):
        assert baseline_identity[key] == measured_baseline[key], f'baseline identity mismatch: {key}'
    return campaign, aggregate, manifest


def make_rsc_report(campaign_path, aggregate_path, manifest_path):
    campaign, aggregate, manifest = validate_campaign(campaign_path, aggregate_path, manifest_path)
    template_path = Path(manifest_path).parent / 'baseline/rsc-current.json'
    report = read(template_path)
    assert report['schema'] == 'scriptw-rsc-current-v1'
    report['schema'] = 'scriptw-rsc-current-v2'
    report['date'] = aggregate['date']
    report['caveat'] = aggregate['caveat']
    report['source_manifest_sha256'] = sha(manifest_path)
    report['baseline'] = campaign['baseline']
    report['candidate'] = campaign['candidate']
    report['candidate_speed'] = {
        'path': campaign['candidate']['path'],
        'sha256': campaign['candidate']['sha256'],
        'cargo_producer': campaign['candidate']['cargo_producer'],
        'cargo_producer_sha256': campaign['candidate']['cargo_producer_sha256'],
        'configuration': aggregate['engines']['candidate-speed']['identity']['configuration'],
        'native_mode': 'speed',
        'scope': 'separately scored native compilation policy',
    }
    policy = campaign['policy']
    measurement = copy.deepcopy(aggregate['measurement'])
    measurement.update({
        'processes_per_engine_per_block': policy['processes_per_actor_per_block'],
        'clock': policy['clock'],
        'process_order': policy['process_order'],
        'execution_processes': len(campaign['processes']),
        'exact_output': 'Both RSC cases were checked against the shared Node-generated JSON golden.',
    })
    report['measurement'] = measurement
    report['engines'] = aggregate['engines']
    report['inputs'] = campaign['inputs']
    candidate_source = {
        'source_commit': aggregate['engines']['candidate']['identity']['source_commit'],
        'source_fingerprint': aggregate['engines']['candidate']['identity']['source_fingerprint'],
        'manifest_path': str(Path(manifest_path).relative_to(ROOT)),
        'manifest_sha256': sha(manifest_path),
        'runtime_abi': manifest['runtime_abi'],
        'archive_prefix': 'source/current/',
        'manifest_member': 'source/current/manifest.json',
    }
    report['source_identity'] = {
        'git_revision_role': 'base Git revision with a frozen dirty source batch',
        'baseline_source': {
            'identity': campaign['baseline']['identity'],
            'executable': campaign['baseline']['path'],
            'executable_sha256': campaign['baseline']['sha256'],
            'report': campaign['baseline']['report'],
            'report_sha256': campaign['baseline']['report_sha256'],
            'published_report_sha256': campaign['baseline']['published_report_sha256'],
        },
        'candidate_measured_source': candidate_source,
        'candidate_build': {
            'path': campaign['candidate']['path'],
            'executable_sha256': campaign['candidate']['sha256'],
            'cargo_producer': campaign['candidate']['cargo_producer'],
            'cargo_producer_sha256': campaign['candidate']['cargo_producer_sha256'],
            'qualified_reuse': campaign['candidate']['qualified_reuse'],
            'compiler_source_identity': campaign['candidate']['compiler_source_identity'],
        },
        'candidate_speed_policy': aggregate['engines']['candidate-speed']['identity']['configuration'],
        'runtime_abi': manifest['runtime_abi'],
    }
    report['producer_receipts'] = {
        'baseline': {
            'path': campaign['baseline']['producer'],
            'sha256': campaign['baseline']['producer_sha256'],
        },
        'candidate': {
        'cargo_producer': campaign['candidate']['cargo_producer'],
        'cargo_producer_sha256': campaign['candidate']['cargo_producer_sha256'],
        'qualified_reuse': campaign['candidate']['qualified_reuse'],
        },
        'candidate_speed': {
            'cargo_producer': campaign['candidate']['cargo_producer'],
            'cargo_producer_sha256': campaign['candidate']['cargo_producer_sha256'],
            'native_configuration': aggregate['engines']['candidate-speed']['identity']['configuration'],
        },
    }
    report.pop('evidence_archive', None)
    report.pop('complete_archived_report', None)
    report['publication'] = {
        'date': aggregate['date'], 'status': 'staged-ready-for-review',
        'measured_source': candidate_source,
        'baseline': {'identity': campaign['baseline']['identity'],
                     'reference_campaign_sha256': campaign['baseline']['reference_campaign_sha256'],
                     'reference_aggregate_sha256': campaign['baseline']['reference_aggregate_sha256']},
        'speed_policy': campaign['policy']['speed_scope'],
        'archive_prefix': 'source/current/',
    }
    report.pop('baseline_diagnostics', None)
    report.pop('evidence_archive', None)
    report['staging'] = {
        'status': 'ready-for-review', 'canonical_files_written': False,
        'archive_created': False, 'charts_rendered': False,
        'limits': aggregate['caveat'],
    }
    return report, campaign, aggregate


def compact_situations(path, candidate_identity, historical_path, measured_manifest_sha256):
    outer = read(path)
    qualification = None
    if outer.get('schema') == 'scriptw-situation-benchmarks-v1':
        report = outer
        full_report_path = Path(path)
    else:
        assert outer['complete'] is True and isinstance(outer.get('report'), dict)
        full_report_path = Path(outer['report']['path']).resolve(strict=True)
        assert sha(full_report_path) == outer['report']['sha256']
        report = read(full_report_path)
        assert outer['actual_source_fingerprint'] == candidate_identity['source_fingerprint']
        assert report['source_identity']['source_fingerprint'] == candidate_identity['source_fingerprint']
        assert outer['consumer_processes'] == 504 and outer['checked_invocations'] == 60984
        assert outer['rerun_native_measurements'] is False
        assert outer['source_manifest_sha256'] == measured_manifest_sha256
        qualification = {
            'path': str(Path(path).relative_to(ROOT)), 'sha256': sha(path),
            'source_manifest_sha256': outer['source_manifest_sha256'],
            'original_orchestrator': outer['original_orchestrator'],
            'rerun_native_measurements': False,
        }
    renderer = load_module('scriptw_situation_renderer', SITUATION_RENDERER)
    cases = renderer.validate(report)
    assert report['status'] == 'complete' and len(cases) == 21
    policy = report['policy']
    assert policy['actors'] == ['scriptw-fast', 'scriptw-speed', 'v8']
    assert policy['blocks'] == 2 and policy['processes_per_actor_per_block'] == 4
    assert policy['samples'] == 21 and policy['warmups'] == 100
    assert all(runtime['status'] in ('ok', 'complete') for case in cases
               for runtime in case['runtimes'].values())
    identity = report['source_identity']
    assert identity['source_commit'] == candidate_identity['source_commit']
    assert identity['source_fingerprint'] == candidate_identity['source_fingerprint']
    historical = read(historical_path)
    old = historical.get('historical_width_identity', {})
    archive = old.get('evidence_archive', historical.get('evidence_archive', {}))
    assert old.get('source_fingerprint', '').startswith('0ca455c')
    assert isinstance(archive.get('sha256'), str) and len(archive['sha256']) == 64
    compact = {key: copy.deepcopy(value) for key, value in report.items()
               if key not in {'rows', 'commands', 'retained_files'}}
    compact.pop('evidence_archive', None)
    compact.pop('complete_archived_report', None)
    compact['historical_width_identity'] = copy.deepcopy(old)
    compact['publication'] = {
        'status': 'staged-ready-for-review',
        'full_report': {'archive_member': 'situations/full-report.json', 'sha256': sha(full_report_path)},
        'consumer_processes': len(cases) * 3 * 8,
        'checked_invocations': len(cases) * 3 * 8 * (policy['samples'] + policy['warmups']),
        'canonical_files_written': False,
    }
    if qualification is not None:
        compact['publication']['qualification_wrapper'] = qualification
    return compact, qualification, full_report_path


def validate_attribution(path, campaign_path, aggregate_path, manifest_path, candidate_identity):
    report = read(path)
    assert report['schema'] == 'scriptw-react-attribution-current-v5'
    assert report['status'] == 'captured' and report['excluded_from_scored_cohorts'] is True
    assert report['source_manifest']['sha256'] == sha(manifest_path)
    assert report['candidate_identity'] == candidate_identity
    scored = report['scored_rsc_evidence']
    assert scored['campaign']['sha256'] == sha(campaign_path)
    assert scored['aggregate']['sha256'] == sha(aggregate_path)
    assert report['sampling']['fresh'] is False
    assert report['sampling']['historical']['source_fingerprint'].startswith('5aa48ad8')
    assert report['physical_allocation_census']['fresh'] is False
    return report


def validate_qualified_reuse(measured_manifest_path, verification_manifest_path, reuse_path, candidate,
                             candidate_build, qualification_path=None):
    measured_manifest_path = Path(measured_manifest_path).resolve(strict=True)
    verification_manifest_path = Path(verification_manifest_path).resolve(strict=True)
    reuse_path = Path(reuse_path).resolve(strict=True)
    common = load_module('levers_source_snapshot_common', BASE / 'tools/common.py')
    measured = common.validate_snapshot(measured_manifest_path)
    verification = common.validate_snapshot(verification_manifest_path)
    receipt = read(reuse_path)
    assert receipt['schema'] == 'scriptw-rsc-levers-qualified-candidate-reuse-v1' and receipt['complete']
    assert receipt['previous_source']['path'] == str(Path(measured_manifest_path).resolve())
    assert receipt['previous_source']['sha256'] == sha(measured_manifest_path)
    assert receipt['current_source']['path'] == str(Path(verification_manifest_path).resolve())
    assert receipt['current_source']['sha256'] == sha(verification_manifest_path)
    assert measured['base_git'] == verification['base_git'] and measured['runtime_abi'] == verification['runtime_abi']
    assert receipt['previous_fresh'] is False and receipt['current_fresh'] is True
    assert receipt['producer_inputs_identical'] is True
    assert receipt['binary']['sha256'] == candidate['executable_sha256']
    assert receipt['previous_producer']['path'] == candidate_build['cargo_producer']
    assert receipt['previous_producer']['sha256'] == candidate_build['cargo_producer_sha256']
    previous_artifact, current_artifact = receipt['previous_artifact'], receipt['current_artifact']
    assert previous_artifact['fresh'] is False and current_artifact['fresh'] is True
    previous_artifact = dict(previous_artifact, fresh=None)
    current_artifact = dict(current_artifact, fresh=None)
    assert previous_artifact == current_artifact

    def compiler_source_identity(path):
        rows = [json.loads(line) for line in Path(path).read_text().splitlines() if line]
        identities = set()
        for row in rows:
            if row.get('reason') != 'build-script-executed':
                continue
            environment = dict(row.get('env', []))
            fingerprint = environment.get('SCRIPTW_COMPILER_FINGERPRINT')
            revision = environment.get('SCRIPTW_COMPILER_SOURCE_REVISION')
            if fingerprint and revision:
                identities.add((fingerprint, revision))
        assert len(identities) == 1
        return next(iter(identities))

    previous_source_identity = compiler_source_identity(receipt['previous_producer']['path'])
    current_source_identity = compiler_source_identity(receipt['current_producer']['path'])
    assert previous_source_identity == current_source_identity
    assert previous_source_identity[0] == candidate_build['compiler_source_identity']['source_fingerprint']
    assert previous_source_identity[1] == candidate_build['compiler_source_identity']['source_revision']

    changed = set()
    measured_files, verification_files = measured['files'], verification['files']
    for relative in set(measured_files) | set(verification_files):
        before, after = measured_files.get(relative), verification_files.get(relative)
        if before != after:
            changed.add(relative)
    assert sorted(changed) == receipt['allowed_changed_files']
    assert changed
    external_changed = set()
    internal_changed = set()
    for relative in changed:
        path = Path(relative)
        if len(path.parts) >= 4 and path.parts[0] == 'crates' and path.parts[2] == 'tests' and path.suffix == '.rs':
            external_changed.add(relative)
            continue
        if relative == INTERNAL_TEST_ONLY_FILE:
            internal_changed.add(relative)
            continue
        raise AssertionError(f'unapproved reuse source change: {relative}')
    assert internal_changed in (set(), {INTERNAL_TEST_ONLY_FILE})
    test_only_gate_files = []
    if internal_changed:
        evidence = receipt['test_only_evidence']
        assert evidence['path'] == INTERNAL_TEST_ONLY_FILE
        assert evidence['product_compiler_source_fingerprint'] == candidate['source_fingerprint']
        assert evidence['product_binaries_identical'] is True
        gate_contents = {}
        for relative in (COMPILER_TEST_EXCLUSION_FILE, TEST_GATE_FILE, TEST_MODULE_FILE):
            path = ROOT / relative
            data = path.read_bytes()
            digest = hashlib.sha256(data).hexdigest()
            gate_contents[relative] = data.decode('utf-8')
            test_only_gate_files.append({'path': relative, 'sha256': digest,
                                         'archive_member': 'verification/test-only-gate/' + relative})
        compiler_fingerprint = gate_contents[COMPILER_TEST_EXCLUSION_FILE]
        lib = gate_contents[TEST_GATE_FILE]
        tests = gate_contents[TEST_MODULE_FILE]
        assert evidence['fingerprint_exclusion'] == {
            'path': COMPILER_TEST_EXCLUSION_FILE,
            'sha256': hashlib.sha256((ROOT / COMPILER_TEST_EXCLUSION_FILE).read_bytes()).hexdigest(),
            'excluded_directory': 'crates/scriptw-aot-wasm/src/tests',
        }
        assert evidence['cfg_test_registration'] == {
            'path': TEST_GATE_FILE,
            'sha256': hashlib.sha256((ROOT / TEST_GATE_FILE).read_bytes()).hexdigest(),
            'pattern': '#[cfg(test)]\nmod tests;',
        }
        assert evidence['test_module_registration'] == {
            'path': TEST_MODULE_FILE,
            'sha256': hashlib.sha256((ROOT / TEST_MODULE_FILE).read_bytes()).hexdigest(),
            'pattern': 'mod local_argument_calls;',
        }
        assert 'const TEST_ONLY_INPUTS: &[&str]' in compiler_fingerprint
        assert '"crates/scriptw-aot-wasm/src/tests"' in compiler_fingerprint
        assert 'input_files(workspace, COMPILER_INPUTS, TEST_ONLY_INPUTS)' in compiler_fingerprint
        assert 'fn excluded_input(workspace: &Path, path: &Path, excluded: &[&str]) -> bool' in compiler_fingerprint
        assert 'any(|input| path.starts_with(workspace.join(input)))' in compiler_fingerprint
        assert '#[cfg(test)]\nmod tests;' in lib
        assert 'mod local_argument_calls;' in tests
        assert INTERNAL_TEST_ONLY_FILE in changed
    assert set(measured['deleted_files']) == set(verification['deleted_files']) == set()
    qualification = None
    prior_verification_manifest_path = None
    if qualification_path is not None:
        qualification_path = Path(qualification_path).resolve(strict=True)
        qualification = read(qualification_path)
        assert qualification['complete'] is True
        assert qualification['measured_source_manifest_sha256'] == sha(measured_manifest_path)
        prior_verification_manifest_path = (BASE / 'tools/source-outlined-4/manifest.json').resolve(strict=True)
        prior_verification = common.validate_snapshot(prior_verification_manifest_path)
        assert qualification['previous_verification_manifest_sha256'] == sha(prior_verification_manifest_path)
        assert qualification['source_manifest_sha256'] == sha(verification_manifest_path)
        assert qualification['qualified_reuse']['path'] == str(reuse_path)
        assert qualification['qualified_reuse']['sha256'] == sha(reuse_path)
        assert qualification['test_only_evidence'] == receipt['test_only_evidence']
        assert len(qualification['unchanged_binaries']) == 14
        assert all(sha(item['path']) == item['sha256'] for item in qualification['unchanged_binaries'])
        assert qualification['retained_broad']['passed'] == 2550
        assert sha(qualification['retained_broad']['path']) == qualification['retained_broad']['sha256']
        prior_changed = {
            relative for relative in set(prior_verification['files']) | set(verification['files'])
            if prior_verification['files'].get(relative) != verification['files'].get(relative)
        }
        assert prior_changed == {INTERNAL_TEST_ONLY_FILE}
        assert set(prior_verification['deleted_files']) == set(verification['deleted_files']) == set()
    if internal_changed:
        assert qualification is not None, 'internal cfg(test) correction needs a qualification receipt'
    return {
        'schema': 'scriptw-performance-levers-test-only-reuse-v2',
        'measured_source': {'path': str(Path(measured_manifest_path).relative_to(ROOT)),
                            'sha256': sha(measured_manifest_path), 'source_fingerprint': candidate['source_fingerprint']},
        'verification_source': {'path': str(Path(verification_manifest_path).relative_to(ROOT)),
                                 'sha256': sha(verification_manifest_path),
                                 'archive_prefix': 'verification/source-current/',
                                 'manifest_member': 'verification/source-current/manifest.json'},
        'reuse_receipt': {'path': str(Path(reuse_path).relative_to(ROOT)), 'sha256': sha(reuse_path),
                          'archive_member': 'verification/test-only-reuse-receipt.json'},
        'qualification_receipt': ({'path': str(qualification_path.relative_to(ROOT)),
                                   'sha256': sha(qualification_path),
                                   'archive_member': 'verification/test-only-qualification.json'}
                                  if qualification_path else None),
        'prior_verification_source': ({'path': str(prior_verification_manifest_path.relative_to(ROOT)),
                                       'sha256': sha(prior_verification_manifest_path),
                                       'archive_prefix': 'verification/source-previous/',
                                       'manifest_member': 'verification/source-previous/manifest.json'}
                                      if prior_verification_manifest_path else None),
        'binary_sha256': receipt['binary']['sha256'],
        'changed_external_test_files': sorted(external_changed),
        'changed_cfg_test_file': sorted(internal_changed),
        'test_only_gate_files': test_only_gate_files,
        'compiler_source_identity': {'source_fingerprint': previous_source_identity[0],
                                     'source_revision': previous_source_identity[1]},
        'qualification': 'Changed inputs are limited to listed external tests and at most the single explicitly excluded cfg(test) module. Compiler source identity and Cargo inputs match; the frozen production executable SHA is unchanged.',
    }


def validate_mixed_cfg_test_change(previous_manifest_path, current_manifest_path, qualification_path,
                                   previous_reuse_path):
    """Validate the one production file whose cfg(test) suffix changed after scoring."""
    previous_manifest_path = Path(previous_manifest_path).resolve(strict=True)
    current_manifest_path = Path(current_manifest_path).resolve(strict=True)
    qualification_path = Path(qualification_path).resolve(strict=True)
    previous_reuse_path = Path(previous_reuse_path).resolve(strict=True)
    common = load_module('levers_source_snapshot_common', BASE / 'tools/common.py')
    previous = common.validate_snapshot(previous_manifest_path)
    current = common.validate_snapshot(current_manifest_path)
    qualification = read(qualification_path)
    reuse = read(previous_reuse_path)

    assert previous['base_git'] == current['base_git']
    assert previous['runtime_abi'] == current['runtime_abi']
    assert qualification['schema'] == 'scriptw-performance-levers-mixed-cfg-test-qualification-v1'
    assert qualification['complete'] is True
    assert qualification['measured_source_manifest_sha256'] == reuse['previous_source']['sha256']
    assert qualification['measured_source_fingerprint'] == reuse['test_only_evidence']['product_compiler_source_fingerprint']
    assert qualification['previous_verification_manifest_sha256'] == sha(previous_manifest_path)
    assert qualification['source_manifest_sha256'] == sha(current_manifest_path)
    prior_link = qualification['previous_qualified_reuse']
    assert prior_link['path'] == str(previous_reuse_path)
    assert prior_link['sha256'] == sha(previous_reuse_path)
    assert prior_link['previous_qualification_path'] == str((BASE / 'qualification-outlined-5.json').resolve())
    assert prior_link['previous_qualification_sha256'] == sha(BASE / 'qualification-outlined-5.json')
    prior_proof = prior_link['proof']
    assert prior_proof['schema'] == 'scriptw-performance-levers-test-only-reuse-v2'
    assert prior_proof['measured_source']['sha256'] == reuse['previous_source']['sha256']
    assert prior_proof['verification_source']['sha256'] == sha(previous_manifest_path)
    assert len(prior_proof['changed_external_test_files']) == 14
    assert prior_proof['changed_cfg_test_file'] == [INTERNAL_TEST_ONLY_FILE]

    changed = {
        relative for relative in set(previous['files']) | set(current['files'])
        if previous['files'].get(relative) != current['files'].get(relative)
    }


    assert changed == {MIXED_CFG_TEST_FILE}
    assert set(previous['deleted_files']) == set(current['deleted_files']) == set()
    previous_file = previous_manifest_path.parent / 'files' / MIXED_CFG_TEST_FILE
    current_file = current_manifest_path.parent / 'files' / MIXED_CFG_TEST_FILE
    previous_bytes = previous_file.read_bytes()
    current_bytes = current_file.read_bytes()
    marker = b'#[cfg(test)]\nmod tests {'
    assert previous_bytes.count(marker) == current_bytes.count(marker) == 1
    previous_cut = previous_bytes.find(marker)
    current_cut = current_bytes.find(marker)
    assert previous_cut >= 0 and current_cut == previous_cut
    previous_prefix, previous_suffix = previous_bytes[:previous_cut], previous_bytes[previous_cut:]
    current_prefix, current_suffix = current_bytes[:current_cut], current_bytes[current_cut:]
    assert previous_prefix == current_prefix
    old_literal = b'export function step(row,i,extra){tick=tick+1;return row.x+i;}'
    new_literal = b'export function step(row,i,a,b,c,extra){tick=tick+1;return row.x+i;}'
    assert previous_suffix.count(old_literal) == 1 and previous_suffix.count(new_literal) == 0
    assert current_suffix.count(old_literal) == 0 and current_suffix.count(new_literal) == 1
    assert previous_suffix.replace(old_literal, new_literal, 1) == current_suffix

    change = qualification['mixed_test_only_change']
    expected_change = {
        'path': MIXED_CFG_TEST_FILE,
        'previous_file_sha256': sha(previous_file),
        'current_file_sha256': sha(current_file),
        'production_prefix_sha256': hashlib.sha256(previous_prefix).hexdigest(),
        'previous_test_suffix_sha256': hashlib.sha256(previous_suffix).hexdigest(),
        'current_test_suffix_sha256': hashlib.sha256(current_suffix).hexdigest(),
        'previous_test_literal': old_literal.decode(),
        'current_test_literal': new_literal.decode(),
    }
    assert change == expected_change
    def compiler_source_identity(path):
        rows = [json.loads(line) for line in Path(path).read_text().splitlines() if line]
        identities = set()
        for row in rows:
            if row.get('reason') != 'build-script-executed':
                continue
            environment = dict(row.get('env', []))
            fingerprint = environment.get('SCRIPTW_COMPILER_FINGERPRINT')
            revision = environment.get('SCRIPTW_COMPILER_SOURCE_REVISION')
            if fingerprint and revision:
                identities.add((fingerprint, revision))
        assert len(identities) == 1
        return next(iter(identities))

    previous_producer = reuse['current_producer']
    current_producer = qualification['current_producer']
    assert previous_producer['sha256'] == sha(previous_producer['path'])
    assert current_producer['sha256'] == sha(current_producer['path'])
    previous_identity = compiler_source_identity(previous_producer['path'])
    current_identity = compiler_source_identity(current_producer['path'])
    assert qualification['previous_compiler_source_identity'] == {
        'source_fingerprint': previous_identity[0], 'source_revision': previous_identity[1]}
    assert qualification['current_compiler_source_identity'] == {
        'source_fingerprint': current_identity[0], 'source_revision': current_identity[1]}
    return {
        'schema': 'scriptw-performance-levers-mixed-cfg-test-change-v1',
        'previous_verification_source': {'path': str(previous_manifest_path.relative_to(ROOT)),
                                         'sha256': sha(previous_manifest_path),
                                         'archive_prefix': 'verification/mixed-cfg/source-previous/',
                                         'manifest_member': 'verification/mixed-cfg/source-previous/manifest.json'},
        'current_verification_source': {'path': str(current_manifest_path.relative_to(ROOT)),
                                        'sha256': sha(current_manifest_path),
                                        'archive_prefix': 'verification/mixed-cfg/source-current/',
                                        'manifest_member': 'verification/mixed-cfg/source-current/manifest.json'},
        'qualification_receipt': {'path': str(qualification_path.relative_to(ROOT)),
                                  'sha256': sha(qualification_path),
                                  'archive_member': 'verification/mixed-cfg-test-qualification.json'},
        'previous_producer': {'path': str(Path(previous_producer['path']).resolve().relative_to(ROOT)),
                              'sha256': previous_producer['sha256'],
                              'archive_member': 'verification/mixed-cfg/previous-cargo-producer.stdout'},
        'current_producer': {'path': str(Path(current_producer['path']).resolve().relative_to(ROOT)),
                             'sha256': current_producer['sha256'],
                             'archive_member': 'verification/mixed-cfg/current-cargo-producer.stdout'},
        'change': expected_change,
        'previous_compiler_source_identity': {'source_fingerprint': previous_identity[0],
                                              'source_revision': previous_identity[1]},
        'current_compiler_source_identity': {'source_fingerprint': current_identity[0],
                                             'source_revision': current_identity[1]},
        'product_binary_identity': 'separate verification build; no binary-equality claim',
        'qualification': 'Only the cfg(test) suffix changed in this fingerprinted mixed source file; the production prefix is byte-identical. The verification build has a separately recorded compiler identity and is not treated as the measured binary.',
    }


def validate_format_only_test_change(previous_manifest_path, current_manifest_path, qualification_path,
                                     mixed_qualification_path):
    previous_manifest_path = Path(previous_manifest_path).resolve(strict=True)
    current_manifest_path = Path(current_manifest_path).resolve(strict=True)
    qualification_path = Path(qualification_path).resolve(strict=True)
    mixed_qualification_path = Path(mixed_qualification_path).resolve(strict=True)
    common = load_module('levers_source_snapshot_common', BASE / 'tools/common.py')
    previous = common.validate_snapshot(previous_manifest_path)
    current = common.validate_snapshot(current_manifest_path)
    qualification = read(qualification_path)
    mixed = read(mixed_qualification_path)
    replacement_module = load_module('levers_format_qualification_builder',
                                     BASE / 'publication-tools/build_format_only_qualification.py')
    replacements = replacement_module.REPLACEMENTS
    assert qualification['schema'] == 'scriptw-performance-levers-format-only-test-qualification-v1'
    assert qualification['complete'] is True
    assert previous['base_git'] == current['base_git'] and previous['runtime_abi'] == current['runtime_abi']
    assert qualification['measured_source_manifest_sha256'] == mixed['measured_source_manifest_sha256']
    assert qualification['measured_source_fingerprint'] == mixed['measured_source_fingerprint']
    assert qualification['previous_verification_manifest_sha256'] == sha(previous_manifest_path)
    assert qualification['source_manifest_sha256'] == sha(current_manifest_path)
    assert qualification['previous_mixed_cfg_qualification'] == {
        'path': str(mixed_qualification_path), 'sha256': sha(mixed_qualification_path)}
    assert qualification['current_compiler_source_identity'] == mixed['current_compiler_source_identity']
    assert qualification['current_product_producer'] == mixed['current_producer']
    assert qualification['binary_identity_comparison'] == 'not-claimed; no source7 product build was run'

    changed = {
        relative for relative in set(previous['files']) | set(current['files'])
        if previous['files'].get(relative) != current['files'].get(relative)
    }
    assert changed == set(replacements)
    assert set(previous['deleted_files']) == set(current['deleted_files']) == set()
    expected_records = []
    for relative, imports in sorted(replacements.items()):
        old_path = previous_manifest_path.parent / 'files' / relative
        new_path = current_manifest_path.parent / 'files' / relative
        before, after = old_path.read_bytes(), new_path.read_bytes()
        expected = before
        change_records = []
        for old, new in imports:
            old_bytes, new_bytes = old.encode(), new.encode()
            assert expected.count(old_bytes) == 1 and expected.count(new_bytes) == 0
            expected = expected.replace(old_bytes, new_bytes, 1)
            change_records.append({'previous_import': old, 'current_import': new})
        assert expected == after
        expected_records.append({'path': relative, 'previous_file_sha256': sha(old_path),
                                 'current_file_sha256': sha(new_path), 'replacements': change_records})
    assert qualification['format_only_files'] == expected_records

    compiler_path = ROOT / 'crates/scriptw-engine/compiler_fingerprint.rs'
    compiler_text = compiler_path.read_text()
    assert qualification['compiler_fingerprint_exclusion'] == {
        'path': 'crates/scriptw-engine/compiler_fingerprint.rs',
        'sha256': sha(compiler_path),
        'excluded_external_test_directory': 'crates/scriptw-aot-wasm/tests',
    }
    assert '"crates/scriptw-aot-wasm/tests"' in compiler_text
    assert qualification['current_product_producer']['sha256'] == sha(
        qualification['current_product_producer']['path'])
    return {
        'schema': 'scriptw-performance-levers-format-only-test-proof-v1',
        'previous_verification_source': {'path': str(previous_manifest_path.relative_to(ROOT)),
                                         'sha256': sha(previous_manifest_path),
                                         'archive_prefix': 'verification/import-format/source-previous/',
                                         'manifest_member': 'verification/import-format/source-previous/manifest.json'},
        'current_verification_source': {'path': str(current_manifest_path.relative_to(ROOT)),
                                        'sha256': sha(current_manifest_path),
                                        'archive_prefix': 'verification/import-format/source-current/',
                                        'manifest_member': 'verification/import-format/source-current/manifest.json'},
        'qualification_receipt': {'path': str(qualification_path.relative_to(ROOT)),
                                  'sha256': sha(qualification_path),
                                  'archive_member': 'verification/import-format-qualification.json'},
        'mixed_cfg_qualification': {'path': str(mixed_qualification_path.relative_to(ROOT)),
                                    'sha256': sha(mixed_qualification_path)},
        'format_only_files': expected_records,
        'compiler_source_identity': qualification['current_compiler_source_identity'],
        'current_product_producer': qualification['current_product_producer'],
        'compiler_fingerprint_exclusion': {
            'path': 'crates/scriptw-engine/compiler_fingerprint.rs',
            'sha256': sha(ROOT / 'crates/scriptw-engine/compiler_fingerprint.rs'),
            'archive_member': 'verification/import-format/compiler_fingerprint.rs',
        },
        'binary_identity_comparison': qualification['binary_identity_comparison'],
        'qualification': qualification['qualification_scope'],
    }


def add_diagnostic_campaigns(archive, report, candidate_identity):
    for name, record in report['diagnostic_campaigns'].items():
        assert name in {'census', 'pmu'}
        campaign_path = require_text_file(record['path'])
        assert sha(campaign_path) == record['sha256']
        campaign = read(campaign_path)
        assert campaign['complete'] and campaign['status'] == 'complete'
        assert campaign['source_fingerprint'] == candidate_identity['source_fingerprint']
        folder = campaign_path.parent
        add_evidence_tree(archive, folder, 'diagnostics/' + name)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--campaign', type=Path, required=True)
    parser.add_argument('--aggregate', type=Path, required=True)
    parser.add_argument('--source-manifest', type=Path, required=True,
                        help='final frozen source manifest for the measured campaign')
    parser.add_argument('--verification-manifest', type=Path,
                        help='optional later source snapshot used only by test-only qualified reuse')
    parser.add_argument('--verification-reuse-receipt', type=Path,
                        help='required with --verification-manifest; pins identical Cargo producer inputs and binary')
    parser.add_argument('--verification-qualification-receipt', type=Path,
                        help='required when later verification adds the one permitted cfg(test) source file')
    parser.add_argument('--mixed-cfg-source-manifest', type=Path,
                        help='later verification snapshot with only the permitted numeric_body cfg(test) suffix correction')
    parser.add_argument('--mixed-cfg-qualification-receipt', type=Path,
                        help='required with --mixed-cfg-source-manifest; binds both producer identities')
    parser.add_argument('--format-only-source-manifest', type=Path,
                        help='later source snapshot containing only the six qualified import-order corrections')
    parser.add_argument('--format-only-qualification-receipt', type=Path,
                        help='required with --format-only-source-manifest; binds exact file replacements')
    parser.add_argument('--situations-report', type=Path)
    parser.add_argument('--attribution-report', type=Path,
                        help='optional current v5 PMU and helper-entry summary')
    parser.add_argument('--historical-situations', type=Path,
                        default=ROOT / 'docs/rust-rewrite/situations-current.json')
    parser.add_argument('--evidence', type=Path, action='append', default=[],
                        help='additional completed UTF-8 file/directory; repeat as needed')
    parser.add_argument('--output-dir', type=Path, required=True,
                        help='new isolated directory under target')
    parser.add_argument('--archive-name', default='scriptw-performance-levers-evidence-2026-11-08.tar.xz')
    args = parser.parse_args()

    output = args.output_dir.resolve()
    assert output.is_relative_to(ROOT / 'target') and not output.exists()
    campaign_path = args.campaign.resolve(strict=True)
    aggregate_path = args.aggregate.resolve(strict=True)
    manifest_path = args.source_manifest.resolve(strict=True)
    rsc, campaign, aggregate = make_rsc_report(campaign_path, aggregate_path, manifest_path)
    assert bool(args.verification_manifest) == bool(args.verification_reuse_receipt)
    verification_proof = None
    verification_manifest_path = None
    reuse_path = None
    mixed_cfg_proof = None
    mixed_cfg_manifest_path = None
    mixed_cfg_qualification_path = None
    format_only_proof = None
    format_only_manifest_path = None
    format_only_qualification_path = None
    if args.verification_manifest:
        verification_manifest_path = args.verification_manifest.resolve(strict=True)
        reuse_path = args.verification_reuse_receipt.resolve(strict=True)
        qualification_path = (args.verification_qualification_receipt.resolve(strict=True)
                              if args.verification_qualification_receipt else None)
        verification_proof = validate_qualified_reuse(
            manifest_path, verification_manifest_path, reuse_path,
            aggregate['engines']['candidate']['identity'], campaign['candidate'], qualification_path)
        rsc['source_identity']['verification_source'] = verification_proof
        rsc['publication']['verification_source'] = verification_proof
    assert bool(args.mixed_cfg_source_manifest) == bool(args.mixed_cfg_qualification_receipt)
    if args.mixed_cfg_source_manifest:
        assert verification_manifest_path is not None and reuse_path is not None
        mixed_cfg_manifest_path = args.mixed_cfg_source_manifest.resolve(strict=True)
        mixed_cfg_qualification_path = args.mixed_cfg_qualification_receipt.resolve(strict=True)
        mixed_cfg_proof = validate_mixed_cfg_test_change(
            verification_manifest_path, mixed_cfg_manifest_path, mixed_cfg_qualification_path, reuse_path)
        rsc['source_identity']['mixed_cfg_verification'] = mixed_cfg_proof
        rsc['publication']['mixed_cfg_verification'] = mixed_cfg_proof
    assert bool(args.format_only_source_manifest) == bool(args.format_only_qualification_receipt)
    if args.format_only_source_manifest:
        assert mixed_cfg_manifest_path is not None and mixed_cfg_qualification_path is not None
        format_only_manifest_path = args.format_only_source_manifest.resolve(strict=True)
        format_only_qualification_path = args.format_only_qualification_receipt.resolve(strict=True)
        format_only_proof = validate_format_only_test_change(
            mixed_cfg_manifest_path, format_only_manifest_path, format_only_qualification_path,
            mixed_cfg_qualification_path)
        rsc['source_identity']['format_only_test_verification'] = format_only_proof
        rsc['publication']['format_only_test_verification'] = format_only_proof
    chart_module = load_module('scriptw_rsc_renderer', RSC_RENDERER)
    with tempfile.TemporaryDirectory(prefix='rsc-v2-', dir=BASE) as temporary_dir:
        temporary = Path(temporary_dir) / 'report.json'
        temporary.write_bytes(encoded(rsc))
        chart_module.rsc_report(temporary)

    situations = None
    situations_qualification = None
    situations_full_path = None
    if args.situations_report:
        situations_path = args.situations_report.resolve(strict=True)
        situations, situations_qualification, situations_full_path = compact_situations(
            situations_path, aggregate['engines']['candidate']['identity'],
            args.historical_situations.resolve(strict=True), sha(manifest_path))
    else:
        situations_path = None
    attribution_path = args.attribution_report.resolve(strict=True) if args.attribution_report else None
    attribution = None
    if attribution_path:
        attribution = validate_attribution(attribution_path, campaign_path, aggregate_path, manifest_path,
                                           aggregate['engines']['candidate']['identity'])

    output.mkdir(parents=True)
    (output / 'reports').mkdir()
    (output / 'reports/rsc-current.json').write_bytes(encoded(rsc))
    if situations is not None:
        (output / 'reports/situations-current.json').write_bytes(encoded(situations))
    if attribution is not None:
        (output / 'reports/react-attribution-current.json').write_bytes(encoded(attribution))

    archiver = load_module('scriptw_inert_archive', ARCHIVER)
    archive = archiver.Archive()
    add_source_snapshot(archive, manifest_path)
    if verification_manifest_path is not None:
        add_source_snapshot(archive, verification_manifest_path, 'verification/source-current')
        if verification_proof['prior_verification_source']:
            prior_manifest = BASE / 'tools/source-outlined-4/manifest.json'
            add_source_snapshot(archive, prior_manifest, 'verification/source-previous')
        archive.add_file('verification/test-only-reuse-receipt.json', reuse_path)
        if qualification_path is not None:
            archive.add_file('verification/test-only-qualification.json', qualification_path)
        if verification_proof['test_only_gate_files']:
            for item in verification_proof['test_only_gate_files']:
                archive.add_file('verification/test-only-gate/' + item['path'], ROOT / item['path'])
    if mixed_cfg_manifest_path is not None:
        add_source_snapshot(archive, verification_manifest_path, 'verification/mixed-cfg/source-previous')
        add_source_snapshot(archive, mixed_cfg_manifest_path, 'verification/mixed-cfg/source-current')
        archive.add_file('verification/mixed-cfg-test-qualification.json', mixed_cfg_qualification_path)
        mixed_previous_producer = read(reuse_path)['current_producer']['path']
        mixed_current_producer = read(mixed_cfg_qualification_path)['current_producer']['path']
        archive.add_file('verification/mixed-cfg/previous-cargo-producer.stdout', mixed_previous_producer)
        archive.add_file('verification/mixed-cfg/current-cargo-producer.stdout', mixed_current_producer)
    if format_only_manifest_path is not None:
        add_source_snapshot(archive, mixed_cfg_manifest_path, 'verification/import-format/source-previous')
        add_source_snapshot(archive, format_only_manifest_path, 'verification/import-format/source-current')
        archive.add_file('verification/import-format-qualification.json', format_only_qualification_path)
        archive.add_file('verification/import-format/compiler_fingerprint.rs',
                         ROOT / 'crates/scriptw-engine/compiler_fingerprint.rs')
    add_rsc_campaign(archive, campaign_path, aggregate_path)
    archive.add_file('reports/rsc-current-prearchive.json', output / 'reports/rsc-current.json')
    archive.add_file('inputs/baseline-public-report.json', manifest_path.parent / 'baseline/rsc-current.json')
    archive.add_file('tools/stage_publication.py', Path(__file__).resolve())
    for index, path in enumerate(args.evidence):
        path = path.resolve(strict=True)
        if path.is_dir():
            add_evidence_tree(archive, path, f'verification/extra-{index}')
        else:
            path = require_text_file(path)
            assert path.is_relative_to(ROOT)
            archive.add_file(f'verification/extra-{index}/{path.name}', path)
    if situations_path is not None:
        archive.add_file('situations/qualified-wrapper.json', situations_path) if situations_qualification else None
        archive.add_file('situations/full-report.json', situations_full_path)
        archive.add_file('reports/situations-current-prearchive.json', output / 'reports/situations-current.json')
        archive.add_file('inputs/historical-situations-current.json', args.historical_situations.resolve(strict=True))
    if attribution_path is not None:
        archive.add_file('reports/react-attribution-current-prearchive.json', attribution_path)
        add_diagnostic_campaigns(archive, attribution, aggregate['engines']['candidate']['identity'])
    archive.add_file('tools/render-application-benchmarks.py', RSC_RENDERER)
    archive.add_file('tools/render-situation-benchmarks.py', SITUATION_RENDERER)
    archive.add_bytes('README.txt', (
        'Scriptw performance levers evidence. Members are inert UTF-8 text with an SHA-256 index. '
        'Executables, Wasm payloads, native libraries, perf.data, and binary artifacts are excluded. '
        'The RSC campaign contains 32 fresh-process observations and 640 exact-checked Flight calls. '
        'Candidate Fast and Speed are separately scored native policies sharing source, host, Wasm, '
        'runtime and request inputs. No Test262 or universal-performance claim is implied.\n'
    ).encode())
    archive_path = output / args.archive_name
    raw_archive_meta = archive.write(archive_path)
    archive_meta = {key: value for key, value in raw_archive_meta.items() if key != 'file'}
    archive_meta.update({'file': args.archive_name,
                         'canonical_file': 'docs/rust-rewrite/' + args.archive_name,
                         'staged_file': str(archive_path.relative_to(ROOT))})
    import tarfile
    with tarfile.open(archive_path, 'r:xz') as packed:
        index = json.load(packed.extractfile('INDEX.json'))
    member_hashes = {item['path']: item['sha256'] for item in index['members']}

    reports = {'rsc-current.json': rsc}
    if situations is not None:
        reports['situations-current.json'] = situations
    if attribution is not None:
        reports['react-attribution-current.json'] = attribution
    for name, value in reports.items():
        value['evidence_archive'] = archive_meta
        value.setdefault('publication', {})['evidence_archive'] = archive_meta
        value['complete_archived_report'] = {
            'archive_member': 'reports/' + name.removesuffix('.json') + '-prearchive.json',
            'sha256': member_hashes['reports/' + name.removesuffix('.json') + '-prearchive.json'],
        }
        value['staging'] = {'status': 'ready-for-review', 'canonical_files_written': False,
                            'evidence_archive_created': True, 'charts_rendered': False}
        if name == 'react-attribution-current.json':
            value['source_manifest_member'] = 'source/current/manifest.json'
            value['publication'] = {'status': 'staged-ready-for-review', 'evidence_archive': archive_meta}
        (output / 'reports' / name).write_bytes(encoded(value))

    ready = {
        'schema': 'scriptw-performance-levers-publication-stage-v1',
        'complete': True, 'canonical_files_written': False, 'charts_rendered': False,
        'source_manifest': {'path': str(manifest_path.relative_to(ROOT)), 'sha256': sha(manifest_path),
                            'base_git': read(manifest_path)['base_git'],
                            'runtime_abi': read(manifest_path)['runtime_abi']},
        'verification_source': verification_proof,
        'campaign_sha256': sha(campaign_path), 'aggregate_sha256': sha(aggregate_path),
        'reports': {name: sha(output / 'reports' / name) for name in reports},
        'situation_report_sha256': sha(situations_path) if situations_path else None,
        'evidence_archive': archive_meta,
        'evidence_members': len(member_hashes),
        'limits': 'Staged only. Review staged reports and charts, then run publication checks before copying to canonical docs.',
    }
    (output / 'publication-ready.json').write_bytes(encoded(ready))
    print(output / 'publication-ready.json')


if __name__ == '__main__':
    main()
