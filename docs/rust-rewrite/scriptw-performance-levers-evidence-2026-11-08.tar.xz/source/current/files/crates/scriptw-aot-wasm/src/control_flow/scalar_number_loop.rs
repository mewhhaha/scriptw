//! Closed Number loops retain their live values in primitive Wasm locals.
//!
//! The checked plan contains the entire test/body/update region. No admitted
//! operation can call source code, observe a deferred store, or leave the loop
//! abruptly. Entry misses keep the original loop. Compact row misses publish
//! the completed prefix and resume its original coercions/completion handling.
use super::*;
use crate::emit::LocalBindingId;

mod statements;
use statements::NumberStatement;
mod number_inputs;
use number_inputs::{StrictPairInputs, StrictPairProjection};
mod dense_array;
use dense_array::{ArrayRead, ArrayReadBorrow, ArrayReadLoop, PropertyReadView};
mod compact_path;
use compact_path::{
    CompactPathBorrow, CompactPathId, CompactReadPath, PreparedCompactRows, RowLoopKind,
    RowStorageKind,
};
mod joined_length;
use joined_length::{JoinedLengthFact, JoinedStringArrayLength};

mod invariant_imul;
use invariant_imul::InvariantImul;
mod chunked;
use chunked::ChunkedLoop;
mod whole_trip;
use whole_trip::WholeTrip;
mod captured_calls;
pub(crate) use captured_calls::CapturedCallSource;
use captured_calls::{CapturedCallRoots, CapturedCalls};

const MAX_NODES: usize = 256;
const MAX_DEPTH: usize = 64;
const MAX_BINDINGS: usize = 16;
const MAX_SAFE_INTEGER: i64 = (1_i64 << 53) - 1;

#[derive(Clone, Copy)]
enum NumberArithmetic {
    Add,
    Sub,
    Mul,
    Div,
}

impl NumberArithmetic {
    fn new(op: ArithmeticBinaryOp) -> Option<Self> {
        Some(match op {
            ArithmeticBinaryOp::Add => Self::Add,
            ArithmeticBinaryOp::Sub => Self::Sub,
            ArithmeticBinaryOp::Mul => Self::Mul,
            ArithmeticBinaryOp::Div => Self::Div,
            ArithmeticBinaryOp::Mod | ArithmeticBinaryOp::Exp => return None,
        })
    }

    fn emit(self, function: &mut Function) {
        function.instruction(&match self {
            Self::Add => Instruction::F64Add,
            Self::Sub => Instruction::F64Sub,
            Self::Mul => Instruction::F64Mul,
            Self::Div => Instruction::F64Div,
        });
    }
}

#[derive(Clone)]
enum NumberExpression {
    Constant(u64),
    Binding(usize),
    ArrayLength,
    ArrayElement,
    MaskedInputIndex,
    CompactPath(CompactPathId),
    JoinedLength,
    Negate(Box<Self>),
    Arithmetic(NumberArithmetic, Box<Self>, Box<Self>),
    Bitwise(BitwiseBinaryOp, Box<Self>, Box<Self>),
    Complement(Box<Self>),
    Imul(Box<Self>, Box<Self>),
    Assign(usize, Box<Self>),
    Compound(usize, NumberArithmetic, Box<Self>),
    Update(usize, NumericUpdateOp, UpdateReturnMode),
    Comma(Box<Self>, Box<Self>),
    Call(usize),
    CallSlot(usize),
    AssignCallSlot(usize, Box<Self>),
    SelectCall(Box<Self>, Vec<usize>),
}

/// These expression facts establish exact conversion ranges, independently of
/// mutable local values. Full Number consumers always keep binary64 arithmetic;
/// residue consumers may wrap exact integral addition and subtraction in i32.
#[derive(Clone, Copy, PartialEq, Eq)]
enum NumberDomain {
    Number,
    Signed32,
    Unsigned32,
    SafeInteger,
}

enum NumberPredicate {
    Boolean(bool),
    Truthy(NumberExpression),
    Not(Box<Self>),
    Compare(RelationalBinaryOp, NumberExpression, NumberExpression),
    Equal(bool, NumberExpression, NumberExpression),
    ProjectedStrict(bool),
}

struct NumberBinding {
    id: LocalBindingId,
    written: bool,
    initialized_in_body: bool,
    domain: NumberDomain,
}

#[derive(Clone, Copy)]
enum LoopLocal {
    Number(F64Local),
    Signed32(I32Local),
    Unsigned32(I32Local),
}

impl LoopLocal {
    fn load_number(self, function: &mut Function) {
        match self {
            Self::Number(value) => value.load(function),
            Self::Signed32(value) => {
                value.load(function);
                function.instruction(&Instruction::F64ConvertI32S);
            }
            Self::Unsigned32(value) => {
                value.load(function);
                function.instruction(&Instruction::F64ConvertI32U);
            }
        }
    }

    fn store(self, function: &mut Function) {
        match self {
            Self::Number(value) => value.store(function),
            Self::Signed32(value) | Self::Unsigned32(value) => value.store(function),
        }
    }
}

struct LoopLocals<'a> {
    bindings: &'a [NumberBinding],
    values: Vec<LoopLocal>,
    invariant: Option<&'a RegionFact<'a>>,
    calls: Option<(&'a CapturedCalls, &'a CapturedCallRoots)>,
}

impl LoopLocals<'_> {
    fn strict_pair(&self) -> &StrictPairProjection {
        let Some(RegionFact::StrictPairInputs(inputs)) = self.invariant else {
            unreachable!("strict predicates require their sealed projection");
        };
        inputs
    }

    fn array(&self) -> &ArrayReadBorrow<'_> {
        let Some(RegionFact::ArrayReads(borrow)) = self.invariant else {
            unreachable!("dense reads require their matching entry fact");
        };
        borrow
    }

    fn joined(&self) -> &JoinedLengthFact {
        let Some(RegionFact::JoinedStringLength(length)) = self.invariant else {
            unreachable!("joined length requires its matching entry fact");
        };
        length
    }
}

/// One region owns one closed fact. Conflicting receivers/operations decline.
enum RegionInvariant {
    ArrayReads(ArrayReadLoop),
    StrictPairInputs(StrictPairInputs),
    JoinedStringLength(JoinedStringArrayLength),
}

impl RegionInvariant {
    fn is_receiver(&self, id: LocalBindingId) -> bool {
        match self {
            Self::ArrayReads(array) => array.is_array(id),
            Self::StrictPairInputs(inputs) => inputs.is_receiver(id),
            Self::JoinedStringLength(joined) => joined.receiver() == id,
        }
    }
}

enum RegionFact<'a> {
    ArrayReads(ArrayReadBorrow<'a>),
    StrictPairInputs(StrictPairProjection),
    JoinedStringLength(JoinedLengthFact),
}

impl RegionFact<'_> {
    fn release(self, builder: &FunctionBuilder<'_>, function: &mut Function) {
        match self {
            Self::ArrayReads(array) => array.release(builder, function),
            Self::StrictPairInputs(inputs) => inputs.release(builder, function),
            Self::JoinedStringLength(length) => length.release(builder, function),
        }
    }
}

/// Construction seals the complete operation and binding set before emission.
pub(super) struct ScalarNumberLoop {
    bindings: Vec<NumberBinding>,
    test: NumberPredicate,
    body: Vec<NumberStatement>,
    update: Option<NumberExpression>,
    imul: Vec<InvariantImul>,
    invariant: Option<RegionInvariant>,
    dense_four_step: bool,
    whole_trip: Option<WholeTrip>,
    calls: CapturedCalls,
}

/// Carries the actual guarded roots until either loop path has completed.
pub(super) struct ScalarNumberLoopEntry<'a> {
    fact: Option<RegionFact<'a>>,
    calls: Option<CapturedCallRoots>,
}

impl<'a> ScalarNumberLoopEntry<'a> {
    pub(super) fn compact_fallback(
        &self,
        builder: &FunctionBuilder<'_>,
        function: &mut Function,
    ) -> Option<CompactLoopFallback<'_, 'a>> {
        let Some(RegionFact::ArrayReads(array)) = &self.fact else {
            return None;
        };
        if !array.is_compact() {
            return None;
        }
        let needed = builder.runtime_schema().reserve_i32_local(function);
        needed.set_constant(1, function);
        Some(CompactLoopFallback { array, needed })
    }

    pub(super) fn release(self, builder: &FunctionBuilder<'_>, function: &mut Function) {
        if let Some(calls) = self.calls {
            calls.release(builder, function);
        }
        if let Some(fact) = self.fact {
            fact.release(builder, function);
        }
    }
}

/// The caller owns the original loop. A completed compact prefix reaches the
/// existing scalar publication tail, then this same borrow selects continuation.
pub(super) struct CompactLoopFallback<'a, 'p> {
    array: &'a ArrayReadBorrow<'p>,
    needed: I32Local,
}

impl CompactLoopFallback<'_, '_> {
    pub(super) fn capture_remaining(&self, function: &mut Function) {
        self.array.emit_test(function);
        self.needed.store(function);
    }

    pub(super) fn load_and_release(self, builder: &FunctionBuilder<'_>, function: &mut Function) {
        self.needed.load(function);
        builder
            .runtime_schema()
            .release_i32_local(self.needed, function);
    }
}

struct LoopProof<'a, 'b> {
    builder: &'a FunctionBuilder<'b>,
    bindings: Vec<NumberBinding>,
    remaining: usize,
    imul: Vec<InvariantImul>,
    invariant: Option<RegionInvariant>,
    row_alias_initialized: bool,
    number_index_initialized: bool,
    calls: CapturedCalls,
}

impl ScalarNumberLoop {
    fn emit_body(
        &self,
        builder: &mut FunctionBuilder<'_>,
        locals: &LoopLocals<'_>,
        value: Option<LoopLocal>,
        function: &mut Function,
    ) {
        NumberStatement::emit_list(&self.body, builder, locals, value, function);
    }

    fn emit_iteration(
        &self,
        builder: &mut FunctionBuilder<'_>,
        locals: &LoopLocals<'_>,
        value: Option<LoopLocal>,
        iterated: I32Local,
        function: &mut Function,
    ) {
        self.emit_body(builder, locals, value, function);
        iterated.set_constant(1, function);
        if let Some(RegionFact::StrictPairInputs(inputs)) = locals.invariant {
            inputs.advance(locals, function);
        } else {
            if let Some(update) = &self.update {
                update.emit_discard(builder, locals, function);
            }
            if let Some(RegionFact::ArrayReads(array)) = locals.invariant {
                array.advance(function);
            }
        }
    }

    pub(super) fn new(
        builder: &FunctionBuilder<'_>,
        init: Option<&ForInitIr>,
        test: Option<&TypedExpr>,
        update: Option<&TypedExpr>,
        body: &StatementIr,
    ) -> Option<Self> {
        // Source globals, resumable activations and runtime bodies have their
        // own environment/completion lifetimes and never enter this region.
        if !builder.has_source_execution_environment()
            || !builder.current_function_meta().is_some_and(|meta| {
                meta.protocol().execution_kind() == FunctionExecutionKind::Ordinary
            })
            || builder.statement_list_value_context.is_some()
        {
            return None;
        }
        let source_test = test?;
        let mut proof = LoopProof {
            builder,
            bindings: Vec::new(),
            remaining: MAX_NODES,
            imul: Vec::new(),
            invariant: ArrayReadLoop::new(builder, init, source_test, update, body)
                .map(RegionInvariant::ArrayReads)
                .or_else(|| {
                    StrictPairInputs::new(builder, init, source_test, update, body)
                        .map(RegionInvariant::StrictPairInputs)
                }),
            row_alias_initialized: false,
            number_index_initialized: false,
            calls: CapturedCalls::default(),
        };
        let test = proof.predicate(source_test, MAX_DEPTH)?;
        let mut expressions = Vec::new();
        proof.statement(body, &mut expressions, MAX_DEPTH)?;
        let update = match update {
            Some(expression) => Some(proof.expression(expression, MAX_DEPTH)?),
            None => None,
        };
        // Captured writes are deferred only while every row is preflighted.
        // Streaming or non-array loops retain the ordinary call boundaries.
        if !proof.calls.is_empty() {
            let Some(RegionInvariant::ArrayReads(array)) = &proof.invariant else {
                return None;
            };
            if !array.has_complete_projection() || !proof.imul.is_empty() {
                return None;
            }
        }
        if let Some(RegionInvariant::ArrayReads(array)) = &proof.invariant {
            if !array.body_preserves_counter(&proof.bindings, &expressions) {
                return None;
            }
        }
        if (matches!(
            proof.invariant.as_ref(),
            Some(RegionInvariant::JoinedStringLength(_))
        ) || matches!(proof.invariant.as_ref(), Some(RegionInvariant::ArrayReads(array)) if array.is_compact()))
            && !proof.imul.is_empty()
        {
            return None;
        }
        if proof.imul.iter().any(|guard| {
            guard.local_receiver().is_some_and(|id| {
                proof
                    .bindings
                    .iter()
                    .any(|binding| binding.id == id && binding.written)
            })
        }) {
            return None;
        }
        // Every write establishes its range without a loop-carried range
        // assumption. Runtime entry checks establish the induction's base case.
        let mut writes = vec![None; proof.bindings.len()];
        test.collect_writes(&mut writes);
        for expression in &expressions {
            expression.collect_writes(&mut writes);
        }
        if let Some(update) = &update {
            update.collect_writes(&mut writes);
        }
        for (binding, domain) in proof.bindings.iter_mut().zip(writes) {
            binding.domain = domain.unwrap_or(NumberDomain::Number);
        }
        if let Some(RegionInvariant::StrictPairInputs(inputs)) = &proof.invariant {
            // This complete induction proof additionally seals the counter's
            // range through its final Increment, independently of input values.
            if !inputs.complete(&mut proof.bindings, &expressions) {
                return None;
            }
        }
        // This conservative budget includes test and update proof nodes too;
        // four body expansions therefore never exceed MAX_NODES source nodes.
        let dense_four_step = matches!(
            proof.invariant.as_ref(),
            Some(RegionInvariant::ArrayReads(array)) if !array.is_compact()
        ) && MAX_NODES - proof.remaining <= MAX_NODES / 4;
        let mut plan = Self {
            bindings: proof.bindings,
            test,
            body: expressions,
            update,
            imul: proof.imul,
            invariant: proof.invariant,
            dense_four_step,
            whole_trip: None,
            calls: proof.calls,
        };
        // Declining this narrower proof keeps the existing scalar plan intact.
        if plan.calls.is_empty() {
            plan.whole_trip = WholeTrip::new(builder, init, source_test, &plan);
        }
        Some(plan)
    }

    pub(super) fn emit_entry_guard(
        &self,
        builder: &mut FunctionBuilder<'_>,
        function: &mut Function,
    ) -> Result<ScalarNumberLoopEntry<'_>, EmitError> {
        function.instruction(&Instruction::I32Const(1));
        for binding in &self.bindings {
            if binding.initialized_in_body {
                continue;
            }
            let source = builder.local_binding(binding.id);
            source.value().tag().load(function);
            function.instruction(&Instruction::I32Const(WasmRuntimeValueTag::Number.tag()));
            function.instruction(&Instruction::I32Eq);
            function.instruction(&Instruction::I32And);
            if let Some(initialized) = source.initialization_check() {
                initialized.load(function);
                function.instruction(&Instruction::I32And);
            }
            let range = match binding.domain {
                NumberDomain::Number => None,
                NumberDomain::Signed32 => Some((i32::MIN as f64, i32::MAX as f64)),
                NumberDomain::Unsigned32 => Some((0.0, u32::MAX as f64)),
                NumberDomain::SafeInteger => {
                    Some((-(MAX_SAFE_INTEGER as f64), MAX_SAFE_INTEGER as f64))
                }
            };
            if let Some((lower, upper)) = range {
                for (bound, comparison) in
                    [(lower, Instruction::F64Ge), (upper, Instruction::F64Le)]
                {
                    source.value().scalar().load(function);
                    function.instruction(&Instruction::F64ReinterpretI64);
                    function.instruction(&Instruction::F64Const(Ieee64::from(bound)));
                    function.instruction(&comparison);
                    function.instruction(&Instruction::I32And);
                }
                source.value().scalar().load(function);
                function.instruction(&Instruction::F64ReinterpretI64);
                source.value().scalar().load(function);
                function.instruction(&Instruction::F64ReinterpretI64);
                function.instruction(&Instruction::F64Trunc);
                function.instruction(&Instruction::F64Eq);
                function.instruction(&Instruction::I32And);
                // Integer locals cannot preserve the sign of zero, including
                // a written binding in a loop whose first test is false.
                source.value().scalar().load(function);
                function.instruction(&Instruction::I64Const(i64::MIN));
                function.instruction(&Instruction::I64Ne);
                function.instruction(&Instruction::I32And);
            }
        }
        let mut fact = None;
        let mut calls = None;
        if !self.imul.is_empty() || self.invariant.is_some() {
            let schema = builder.runtime_schema();
            let accepted = schema.reserve_i32_local(function);
            accepted.store(function);
            for guard in &self.imul {
                accepted.load(function);
                builder.open_frame(ControlFrameKind::If, function);
                guard.emit_guard(builder, accepted, function)?;
                builder.pop_control(ControlFrameKind::If);
                function.instruction(&Instruction::End);
            }
            if let Some(invariant) = &self.invariant {
                fact = Some(match invariant {
                    RegionInvariant::ArrayReads(plan) => RegionFact::ArrayReads(
                        ArrayReadBorrow::new(plan, builder, accepted, function),
                    ),
                    RegionInvariant::StrictPairInputs(plan) => {
                        RegionFact::StrictPairInputs(plan.guard(builder, accepted, function)?)
                    }
                    RegionInvariant::JoinedStringLength(plan) => {
                        // Speculate only after Number/initialization admission.
                        // This view proves a repeated false entry test has no
                        // source write, coercion, property read or call.
                        let compare = match &self.test {
                            NumberPredicate::Compare(
                                op,
                                left @ (NumberExpression::Binding(_)
                                | NumberExpression::Constant(_)),
                                right @ (NumberExpression::Binding(_)
                                | NumberExpression::Constant(_)),
                            ) => Some((*op, left, right)),
                            _ => None,
                        };
                        if let Some((op, left, right)) = compare {
                            accepted.load(function);
                            builder.open_frame(ControlFrameKind::If, function);
                            for operand in [left, right] {
                                match operand {
                                    NumberExpression::Binding(index) => {
                                        builder
                                            .local_binding(self.bindings[*index].id)
                                            .value()
                                            .scalar()
                                            .load(function);
                                        function.instruction(&Instruction::F64ReinterpretI64);
                                    }
                                    NumberExpression::Constant(bits) => {
                                        function.instruction(&Instruction::F64Const(Ieee64::from(
                                            f64::from_bits(*bits),
                                        )));
                                    }
                                    _ => unreachable!(
                                        "the entry comparison view admits only primitive operands"
                                    ),
                                }
                            }
                            function.instruction(&match op {
                                RelationalBinaryOp::LessThan => Instruction::F64Lt,
                                RelationalBinaryOp::LessThanOrEqual => Instruction::F64Le,
                                RelationalBinaryOp::GreaterThan => Instruction::F64Gt,
                                RelationalBinaryOp::GreaterThanOrEqual => Instruction::F64Ge,
                            });
                            accepted.store(function);
                            builder.pop_control(ControlFrameKind::If);
                            function.instruction(&Instruction::End);
                        }
                        RegionFact::JoinedStringLength(
                            plan.emit_guard(builder, accepted, function)?,
                        )
                    }
                });
            }
            if !self.calls.is_empty() {
                calls = Some(self.calls.guard(builder, accepted, function)?);
            }
            accepted.load(function);
            schema.release_i32_local(accepted, function);
        }
        Ok(ScalarNumberLoopEntry { fact, calls })
    }
}

impl LoopProof<'_, '_> {
    fn visit(&mut self, depth: usize) -> Option<usize> {
        self.remaining = self.remaining.checked_sub(1)?;
        depth.checked_sub(1)
    }

    fn binding(&mut self, name: &str, written: bool) -> Option<usize> {
        // Captured cells and actual global mirrors keep their observable owner.
        let id = self.builder.private_local_binding(name)?;
        self.binding_id(id, written)
    }

    fn binding_id(&mut self, id: LocalBindingId, written: bool) -> Option<usize> {
        // A receiver cannot also become a deferred Number binding, even in
        // syntax whose result would be discarded or whose branch never runs.
        if self
            .invariant
            .as_ref()
            .is_some_and(|fact| fact.is_receiver(id))
        {
            return None;
        }
        if let Some(index) = self.bindings.iter().position(|binding| binding.id == id) {
            self.bindings[index].written |= written;
            return Some(index);
        }
        if self.bindings.len() == MAX_BINDINGS {
            return None;
        }
        let index = self.bindings.len();
        self.bindings.push(NumberBinding {
            id,
            written,
            initialized_in_body: false,
            domain: NumberDomain::Number,
        });
        Some(index)
    }

    fn expression(&mut self, value: &TypedExpr, depth: usize) -> Option<NumberExpression> {
        let depth = self.visit(depth)?;
        if captured_calls::is_call(value) {
            return captured_calls::compile(self, value, depth);
        }
        if let Some(joined) = JoinedStringArrayLength::of_length(value, self.builder) {
            if self
                .bindings
                .iter()
                .any(|binding| binding.id == joined.receiver())
            {
                return None;
            }
            match &self.invariant {
                None => self.invariant = Some(RegionInvariant::JoinedStringLength(joined)),
                Some(RegionInvariant::JoinedStringLength(existing)) if existing == &joined => {}
                Some(_) => return None,
            }
            return Some(NumberExpression::JoinedLength);
        }
        if let Some(read) = PropertyReadView::of(value) {
            let Some(RegionInvariant::ArrayReads(array)) = self.invariant.as_mut() else {
                return None;
            };
            if array.row_alias().is_some() && !self.row_alias_initialized {
                return None;
            }
            let (read, column) = array.read(self.builder, read)?;
            if let Some(column) = column {
                self.binding_id(column, false)?;
            }
            return Some(match read {
                ArrayRead::Length => NumberExpression::ArrayLength,
                ArrayRead::Element => NumberExpression::ArrayElement,
                ArrayRead::CompactPath(path) => NumberExpression::CompactPath(path),
            });
        }
        Some(match &value.expr {
            ExprIr::Number(bits) => NumberExpression::Constant(*bits),
            ExprIr::Identifier(name) => NumberExpression::Binding(self.binding(name, false)?),
            ExprIr::UnaryPlus { expr } => return self.expression(expr, depth),
            ExprIr::UnaryMinusNumeric { expr } => {
                NumberExpression::Negate(Box::new(self.expression(expr, depth)?))
            }
            ExprIr::BinaryNumber { op, lhs, rhs }
            | ExprIr::CoerciveBinaryNumber { op, lhs, rhs } => NumberExpression::Arithmetic(
                NumberArithmetic::new(*op)?,
                Box::new(self.expression(lhs, depth)?),
                Box::new(self.expression(rhs, depth)?),
            ),
            ExprIr::CoerciveAdd { lhs, rhs } => NumberExpression::Arithmetic(
                NumberArithmetic::Add,
                Box::new(self.expression(lhs, depth)?),
                Box::new(self.expression(rhs, depth)?),
            ),
            ExprIr::BitwiseNumeric { op, lhs, rhs } => NumberExpression::Bitwise(
                *op,
                Box::new(self.expression(lhs, depth)?),
                Box::new(self.expression(rhs, depth)?),
            ),
            ExprIr::UnaryBitwiseNumeric { op, expr } => match op {
                UnaryBitwiseOp::Complement => {
                    NumberExpression::Complement(Box::new(self.expression(expr, depth)?))
                }
            },
            ExprIr::AssignIdentifier { name, value } => NumberExpression::Assign(
                self.binding(name, true)?,
                Box::new(self.expression(value, depth)?),
            ),
            ExprIr::CompoundAssignIdentifier { name, op, value } => NumberExpression::Compound(
                self.binding(name, true)?,
                NumberArithmetic::new(*op)?,
                Box::new(self.expression(value, depth)?),
            ),
            ExprIr::UpdateIdentifier {
                name,
                op,
                return_mode,
                value_kind,
            } if !matches!(value_kind, NumericUpdateValueKind::BigInt) => {
                NumberExpression::Update(self.binding(name, true)?, *op, *return_mode)
            }
            ExprIr::Comma { lhs, rhs } => NumberExpression::Comma(
                Box::new(self.expression(lhs, depth)?),
                Box::new(self.expression(rhs, depth)?),
            ),
            ExprIr::MaterializeBinding { .. } => {
                let (guard, left, right) = InvariantImul::of_call(value, self.builder)?;
                let left = self.expression(left, depth)?;
                let right = self.expression(right, depth)?;
                if !self.imul.contains(&guard) {
                    if self.imul.len() == 4 {
                        return None;
                    }
                    self.imul.push(guard);
                }
                NumberExpression::Imul(Box::new(left), Box::new(right))
            }
            // No call/property/environment/coercion observer can be hidden in
            // a Number kind hint: the complete concrete tree must be admitted.
            _ => return None,
        })
    }

    fn predicate(&mut self, value: &TypedExpr, depth: usize) -> Option<NumberPredicate> {
        let depth = self.visit(depth)?;
        // Only direct strict pairs enter the mixed-value preflight. Numeric
        // equality, including loose equality, keeps its separate Number proof.
        let strict = match &value.expr {
            ExprIr::StrictEquality { op, lhs, rhs }
                if matches!(
                    op,
                    EqualityBinaryOp::StrictEqual | EqualityBinaryOp::StrictNotEqual
                ) =>
            {
                Some((
                    matches!(op, EqualityBinaryOp::StrictEqual),
                    lhs.as_ref(),
                    rhs.as_ref(),
                ))
            }
            ExprIr::SpecOperation {
                operation: SpecOperationIr::StrictEqualityComparison,
                operands,
            } => {
                let [left, right] = operands.as_slice() else {
                    return None;
                };
                Some((true, left, right))
            }
            _ => None,
        };
        if let (Some((equal, left, right)), Some(RegionInvariant::StrictPairInputs(inputs))) =
            (strict, &mut self.invariant)
        {
            if self.number_index_initialized && inputs.pair(self.builder, left, right).is_some() {
                return Some(NumberPredicate::ProjectedStrict(equal));
            }
        }
        Some(match &value.expr {
            ExprIr::Boolean(value) => NumberPredicate::Boolean(*value),
            ExprIr::LogicalNot { expr } => {
                NumberPredicate::Not(Box::new(self.predicate(expr, depth)?))
            }
            ExprIr::CompareNumber { op, lhs, rhs } | ExprIr::CompareValue { op, lhs, rhs } => {
                NumberPredicate::Compare(
                    *op,
                    self.expression(lhs, depth)?,
                    self.expression(rhs, depth)?,
                )
            }
            ExprIr::StrictEquality { op, lhs, rhs } | ExprIr::LooseEquality { op, lhs, rhs } => {
                NumberPredicate::Equal(
                    matches!(
                        op,
                        EqualityBinaryOp::StrictEqual | EqualityBinaryOp::LooseEqual
                    ),
                    self.expression(lhs, depth)?,
                    self.expression(rhs, depth)?,
                )
            }
            ExprIr::SpecOperation {
                operation: SpecOperationIr::StrictEqualityComparison,
                operands,
            } if matches!(self.invariant, Some(RegionInvariant::StrictPairInputs(_))) => {
                let [left, right] = operands.as_slice() else {
                    return None;
                };
                NumberPredicate::Equal(
                    true,
                    self.expression(left, depth)?,
                    self.expression(right, depth)?,
                )
            }
            _ => NumberPredicate::Truthy(self.expression(value, depth)?),
        })
    }

    fn statement(
        &mut self,
        statement: &StatementIr,
        expressions: &mut Vec<NumberStatement>,
        depth: usize,
    ) -> Option<()> {
        let depth = self.visit(depth)?;
        match statement {
            StatementIr::Empty => {}
            StatementIr::Expression(value) => {
                expressions.push(NumberStatement::Expression(self.expression(value, depth)?))
            }
            StatementIr::If {
                condition,
                then_branch,
                else_branch,
            } if matches!(self.invariant, Some(RegionInvariant::StrictPairInputs(_))) => {
                let test = self.predicate(condition, depth)?;
                let mut consequent = Vec::new();
                let mut alternate = Vec::new();
                self.statement(then_branch, &mut consequent, depth)?;
                self.statement(else_branch.as_deref()?, &mut alternate, depth)?;
                // Each accepted branch returns a Number statement value; no
                // Empty/Undefined completion is invented at an If join.
                if !consequent.last()?.has_value() || !alternate.last()?.has_value() {
                    return None;
                }
                expressions.push(NumberStatement::If {
                    test,
                    consequent,
                    alternate,
                });
            }
            StatementIr::Var(declarations)
                if expressions.is_empty()
                    && !self.number_index_initialized
                    && matches!(self.invariant, Some(RegionInvariant::StrictPairInputs(_))) =>
            {
                let Some(RegionInvariant::StrictPairInputs(inputs)) = &self.invariant else {
                    unreachable!()
                };
                let [declaration] = declarations.as_slice() else {
                    return None;
                };
                if self.builder.private_local_binding(&declaration.name) != Some(inputs.index()) {
                    return None;
                }
                let index = self.binding_id(inputs.index(), true)?;
                self.bindings[index].initialized_in_body = true;
                self.number_index_initialized = true;
                expressions.push(NumberStatement::Initialize(NumberExpression::Assign(
                    index,
                    Box::new(NumberExpression::MaskedInputIndex),
                )));
            }
            StatementIr::Var(declarations)
                if expressions.is_empty() && !self.row_alias_initialized =>
            {
                let Some(RegionInvariant::ArrayReads(array)) = &self.invariant else {
                    return None;
                };
                array.accept_row_declaration(self.builder, declarations)?;
                self.row_alias_initialized = true;
            }
            StatementIr::Block(block) if block.lexical_environment.is_none() => {
                for statement in &block.statements {
                    self.statement(statement, expressions, depth)?;
                }
            }
            // Declining declarations also keeps const/TDZ prefixes, shadowing,
            // fresh per-iteration cells, and disposable scopes on their owner.
            _ => return None,
        }
        Some(())
    }
}

impl NumberExpression {
    fn intrinsic_domain(&self) -> NumberDomain {
        match self {
            Self::Constant(bits) => {
                let value = f64::from_bits(*bits);
                if *bits == (-0.0_f64).to_bits() {
                    NumberDomain::Number
                } else if value.fract() == 0.0
                    && (i32::MIN as f64..=i32::MAX as f64).contains(&value)
                {
                    NumberDomain::Signed32
                } else if value.fract() == 0.0 && (0.0..=u32::MAX as f64).contains(&value) {
                    NumberDomain::Unsigned32
                } else if value.fract() == 0.0 && value.abs() <= MAX_SAFE_INTEGER as f64 {
                    NumberDomain::SafeInteger
                } else {
                    NumberDomain::Number
                }
            }
            Self::MaskedInputIndex => NumberDomain::Signed32,
            Self::ArrayLength | Self::Bitwise(BitwiseBinaryOp::UShr, _, _) => {
                NumberDomain::Unsigned32
            }
            Self::Bitwise(_, _, _) | Self::Complement(_) | Self::Imul(_, _) => {
                NumberDomain::Signed32
            }
            Self::Assign(_, value) | Self::Comma(_, value) => value.intrinsic_domain(),
            Self::Arithmetic(op, lhs, rhs) => Self::arithmetic_domain(
                *op,
                lhs,
                lhs.intrinsic_domain(),
                rhs,
                rhs.intrinsic_domain(),
            ),
            Self::Binding(_)
            | Self::Call(_)
            | Self::CallSlot(_)
            | Self::SelectCall(_, _)
            | Self::ArrayElement
            | Self::CompactPath(_)
            | Self::JoinedLength
            | Self::Negate(_)
            | Self::Compound(_, _, _)
            | Self::Update(_, _, _) => NumberDomain::Number,
            Self::AssignCallSlot(_, value) => value.intrinsic_domain(),
        }
    }

    fn domain(&self, locals: &LoopLocals<'_>) -> NumberDomain {
        self.binding_domain(locals.bindings)
    }

    fn binding_domain(&self, bindings: &[NumberBinding]) -> NumberDomain {
        match self {
            Self::Binding(index) => bindings[*index].domain,
            Self::Assign(_, value) | Self::Comma(_, value) => value.binding_domain(bindings),
            Self::Arithmetic(op, lhs, rhs) => Self::arithmetic_domain(
                *op,
                lhs,
                lhs.binding_domain(bindings),
                rhs,
                rhs.binding_domain(bindings),
            ),
            _ => self.intrinsic_domain(),
        }
    }

    fn integer_bounds(&self, domain: NumberDomain) -> Option<(i64, i64)> {
        if let Self::Constant(bits) = self {
            let value = f64::from_bits(*bits);
            if *bits != (-0.0_f64).to_bits()
                && value.fract() == 0.0
                && value.abs() <= MAX_SAFE_INTEGER as f64
            {
                let integer = value as i64;
                return Some((integer, integer));
            }
        }
        Some(match domain {
            NumberDomain::Number => return None,
            NumberDomain::Signed32 => (i32::MIN as i64, i32::MAX as i64),
            NumberDomain::Unsigned32 => (0, u32::MAX as i64),
            NumberDomain::SafeInteger => (-MAX_SAFE_INTEGER, MAX_SAFE_INTEGER),
        })
    }

    fn arithmetic_domain(
        op: NumberArithmetic,
        lhs: &Self,
        left: NumberDomain,
        rhs: &Self,
        right: NumberDomain,
    ) -> NumberDomain {
        let bounds = || {
            let (left_min, left_max) = lhs.integer_bounds(left)?;
            let (right_min, right_max) = rhs.integer_bounds(right)?;
            let (lower, upper) = match op {
                NumberArithmetic::Add => (
                    left_min.checked_add(right_min)?,
                    left_max.checked_add(right_max)?,
                ),
                NumberArithmetic::Sub => (
                    left_min.checked_sub(right_max)?,
                    left_max.checked_sub(right_min)?,
                ),
                NumberArithmetic::Mul | NumberArithmetic::Div => return None,
            };
            (lower >= -MAX_SAFE_INTEGER && upper <= MAX_SAFE_INTEGER).then_some(())
        };
        // Every result in these bounds is an exact integral Number. Its low
        // bits may be computed with wrapping i32 Add/Sub when only ToUint32
        // observes the result. Full Number consumers still emit f64 Add/Sub.
        // Larger or fractional ranges retain the arbitrary-Number modulo owner.
        if bounds().is_some() {
            NumberDomain::SafeInteger
        } else {
            NumberDomain::Number
        }
    }

    fn collect_writes(&self, writes: &mut [Option<NumberDomain>]) {
        fn record(writes: &mut [Option<NumberDomain>], index: usize, domain: NumberDomain) {
            writes[index] = Some(match writes[index] {
                None => domain,
                Some(old) if old == domain => domain,
                Some(_) => NumberDomain::Number,
            });
        }
        match self {
            Self::Assign(index, value) => {
                record(writes, *index, value.intrinsic_domain());
                value.collect_writes(writes);
            }
            Self::Compound(index, _, value) => {
                record(writes, *index, NumberDomain::Number);
                value.collect_writes(writes);
            }
            Self::Update(index, _, _) => record(writes, *index, NumberDomain::Number),
            Self::Negate(value) | Self::Complement(value) => value.collect_writes(writes),
            Self::AssignCallSlot(_, value) | Self::SelectCall(value, _) => {
                value.collect_writes(writes)
            }
            Self::Arithmetic(_, lhs, rhs)
            | Self::Bitwise(_, lhs, rhs)
            | Self::Imul(lhs, rhs)
            | Self::Comma(lhs, rhs) => {
                lhs.collect_writes(writes);
                rhs.collect_writes(writes);
            }
            Self::Constant(_)
            | Self::Call(_)
            | Self::CallSlot(_)
            | Self::Binding(_)
            | Self::ArrayLength
            | Self::ArrayElement
            | Self::MaskedInputIndex
            | Self::CompactPath(_)
            | Self::JoinedLength => {}
        }
    }

    fn emit_uint32(
        &self,
        builder: &mut FunctionBuilder<'_>,
        locals: &LoopLocals<'_>,
        function: &mut Function,
    ) {
        match self {
            Self::Constant(bits) if self.intrinsic_domain() != NumberDomain::Number => {
                function.instruction(&Instruction::I32Const(f64::from_bits(*bits) as i64 as i32));
            }
            Self::Binding(index) => match locals.values[*index] {
                LoopLocal::Signed32(value) | LoopLocal::Unsigned32(value) => {
                    value.load(function);
                }
                LoopLocal::Number(_) => {
                    self.emit(builder, locals, function);
                    self.emit_number_to_uint32(builder, locals, function);
                }
            },
            Self::MaskedInputIndex => locals.strict_pair().emit_index(locals, function),
            Self::Bitwise(op, lhs, rhs) => {
                lhs.emit_uint32(builder, locals, function);
                rhs.emit_uint32(builder, locals, function);
                function.instruction(&match op {
                    BitwiseBinaryOp::And => Instruction::I32And,
                    BitwiseBinaryOp::Or => Instruction::I32Or,
                    BitwiseBinaryOp::Xor => Instruction::I32Xor,
                    BitwiseBinaryOp::Shl => Instruction::I32Shl,
                    BitwiseBinaryOp::Shr => Instruction::I32ShrS,
                    BitwiseBinaryOp::UShr => Instruction::I32ShrU,
                });
            }
            Self::Complement(value) => {
                value.emit_uint32(builder, locals, function);
                function.instruction(&Instruction::I32Const(-1));
                function.instruction(&Instruction::I32Xor);
            }
            Self::Imul(lhs, rhs) => {
                lhs.emit_uint32(builder, locals, function);
                rhs.emit_uint32(builder, locals, function);
                function.instruction(&Instruction::I32Mul);
            }
            Self::Arithmetic(op, lhs, rhs) if self.domain(locals) == NumberDomain::SafeInteger => {
                lhs.emit_uint32(builder, locals, function);
                rhs.emit_uint32(builder, locals, function);
                function.instruction(&match op {
                    NumberArithmetic::Add => Instruction::I32Add,
                    NumberArithmetic::Sub => Instruction::I32Sub,
                    // Only exact integral Add/Sub establish SafeInteger.
                    NumberArithmetic::Mul | NumberArithmetic::Div => unreachable!(),
                });
            }
            Self::Assign(index, value) => match locals.values[*index] {
                LoopLocal::Signed32(target) | LoopLocal::Unsigned32(target) => {
                    value.emit_uint32(builder, locals, function);
                    target.store(function);
                    target.load(function);
                }
                LoopLocal::Number(target) => {
                    // This assignment is observable after the enclosing residue
                    // is consumed. Store its full Number exactly once first.
                    value.emit(builder, locals, function);
                    target.store(function);
                    target.load(function);
                    self.emit_number_to_uint32(builder, locals, function);
                }
            },
            Self::Comma(lhs, rhs) => {
                lhs.emit_discard(builder, locals, function);
                rhs.emit_uint32(builder, locals, function);
            }
            _ => {
                self.emit(builder, locals, function);
                self.emit_number_to_uint32(builder, locals, function);
            }
        }
    }

    fn emit_number_to_uint32(
        &self,
        builder: &mut FunctionBuilder<'_>,
        locals: &LoopLocals<'_>,
        function: &mut Function,
    ) {
        match self.domain(locals) {
            NumberDomain::Signed32 => {
                function.instruction(&Instruction::I32TruncSatF64S);
            }
            NumberDomain::Unsigned32 => {
                function.instruction(&Instruction::I32TruncSatF64U);
            }
            NumberDomain::SafeInteger => {
                function.instruction(&Instruction::I64TruncSatF64S);
                function.instruction(&Instruction::I32WrapI64);
            }
            NumberDomain::Number => {
                let schema = builder.runtime_schema();
                let bits = schema.reserve_i64_local(function);
                function.instruction(&Instruction::I64ReinterpretF64);
                bits.store(function);
                builder.emit_to_uint32_i64_from_number_payload(bits, bits, function);
                bits.load(function);
                function.instruction(&Instruction::I32WrapI64);
                schema.release_i64_local(bits, function);
            }
        }
    }

    fn emit_into(
        &self,
        builder: &mut FunctionBuilder<'_>,
        locals: &LoopLocals<'_>,
        target: LoopLocal,
        function: &mut Function,
    ) {
        match target {
            LoopLocal::Number(_) => self.emit(builder, locals, function),
            LoopLocal::Signed32(_) | LoopLocal::Unsigned32(_) => {
                self.emit_uint32(builder, locals, function);
            }
        }
        target.store(function);
    }

    fn emit_discard(
        &self,
        builder: &mut FunctionBuilder<'_>,
        locals: &LoopLocals<'_>,
        function: &mut Function,
    ) {
        match self.domain(locals) {
            NumberDomain::Signed32 | NumberDomain::Unsigned32 => {
                self.emit_uint32(builder, locals, function);
            }
            NumberDomain::Number | NumberDomain::SafeInteger => {
                self.emit(builder, locals, function)
            }
        }
        function.instruction(&Instruction::Drop);
    }

    /// The Wasm stack snapshots the complete left Number before evaluating
    /// the right expression, including assignments to any left-hand binding.
    fn emit(
        &self,
        builder: &mut FunctionBuilder<'_>,
        locals: &LoopLocals<'_>,
        function: &mut Function,
    ) {
        match self {
            Self::Constant(bits) => {
                function.instruction(&Instruction::F64Const(Ieee64::from(f64::from_bits(*bits))));
            }
            Self::Binding(index) => locals.values[*index].load_number(function),
            Self::Call(index) => {
                let (plan, roots) = locals.calls.expect("sealed captured call owner");
                plan.emit_call(*index, roots, builder, locals, function);
            }
            Self::CallSlot(index) => locals
                .calls
                .expect("sealed call slot")
                .1
                .load(*index, function),
            Self::AssignCallSlot(index, value) => {
                value.emit(builder, locals, function);
                let (plan, roots) = locals.calls.expect("sealed call slot");
                roots.store(*index, plan, builder, function);
                roots.load(*index, function);
            }
            Self::SelectCall(index, sites) => {
                index.emit_uint32(builder, locals, function);
                let (plan, roots) = locals.calls.expect("sealed call selection");
                plan.emit_selection(sites, roots, builder, locals, function);
            }
            Self::ArrayLength => locals.array().emit_length(function),
            Self::ArrayElement => locals.array().emit_element(builder, function),
            Self::MaskedInputIndex => {
                locals.strict_pair().emit_index(locals, function);
                function.instruction(&Instruction::F64ConvertI32S);
            }
            Self::CompactPath(path) => locals.array().emit_compact_path(*path, function),
            Self::JoinedLength => locals.joined().emit(function),
            Self::Negate(value) => {
                value.emit(builder, locals, function);
                function.instruction(&Instruction::F64Neg);
            }
            Self::Arithmetic(op, lhs, rhs) => {
                lhs.emit(builder, locals, function);
                rhs.emit(builder, locals, function);
                op.emit(function);
            }
            Self::Bitwise(_, _, _) | Self::Complement(_) | Self::Imul(_, _) => {
                self.emit_uint32(builder, locals, function);
                function.instruction(&if self.domain(locals) == NumberDomain::Unsigned32 {
                    Instruction::F64ConvertI32U
                } else {
                    Instruction::F64ConvertI32S
                });
            }
            Self::Assign(index, value) => {
                value.emit_into(builder, locals, locals.values[*index], function);
                locals.values[*index].load_number(function);
            }
            Self::Compound(index, op, value) => {
                locals.values[*index].load_number(function);
                value.emit(builder, locals, function);
                op.emit(function);
                let LoopLocal::Number(target) = locals.values[*index] else {
                    unreachable!("compound/update writes require Number locals")
                };
                target.store(function);
                locals.values[*index].load_number(function);
            }
            Self::Update(index, op, mode) => {
                if *mode == UpdateReturnMode::Postfix {
                    locals.values[*index].load_number(function);
                }
                locals.values[*index].load_number(function);
                function.instruction(&Instruction::F64Const(Ieee64::from(1.0)));
                match op {
                    NumericUpdateOp::Increment => function.instruction(&Instruction::F64Add),
                    NumericUpdateOp::Decrement => function.instruction(&Instruction::F64Sub),
                };
                let LoopLocal::Number(target) = locals.values[*index] else {
                    unreachable!("compound/update writes require Number locals")
                };
                target.store(function);
                if *mode == UpdateReturnMode::Prefix {
                    locals.values[*index].load_number(function);
                }
            }
            Self::Comma(lhs, rhs) => {
                lhs.emit_discard(builder, locals, function);
                rhs.emit(builder, locals, function);
            }
        }
    }
}

impl NumberPredicate {
    fn collect_writes(&self, writes: &mut [Option<NumberDomain>]) {
        match self {
            Self::Boolean(_) | Self::ProjectedStrict(_) => {}
            Self::Truthy(value) => value.collect_writes(writes),
            Self::Not(value) => value.collect_writes(writes),
            Self::Compare(_, lhs, rhs) | Self::Equal(_, lhs, rhs) => {
                lhs.collect_writes(writes);
                rhs.collect_writes(writes);
            }
        }
    }

    fn emit(
        &self,
        builder: &mut FunctionBuilder<'_>,
        locals: &LoopLocals<'_>,
        function: &mut Function,
    ) {
        match self {
            Self::Boolean(value) => {
                function.instruction(&Instruction::I32Const(i32::from(*value)));
            }
            Self::ProjectedStrict(equal) => {
                locals
                    .strict_pair()
                    .emit_predicate(locals, builder, function);
                if !equal {
                    function.instruction(&Instruction::I32Eqz);
                }
            }
            Self::Truthy(value) => {
                let schema = builder.runtime_schema();
                let evaluated = schema.reserve_f64_local(function);
                value.emit(builder, locals, function);
                evaluated.store(function);
                evaluated.load(function);
                function.instruction(&Instruction::F64Const(Ieee64::from(0.0)));
                function.instruction(&Instruction::F64Ne);
                evaluated.load(function);
                evaluated.load(function);
                function.instruction(&Instruction::F64Eq);
                function.instruction(&Instruction::I32And);
                schema.release_f64_local(evaluated, function);
            }
            Self::Not(value) => {
                value.emit(builder, locals, function);
                function.instruction(&Instruction::I32Eqz);
            }
            Self::Compare(op, lhs, rhs) => {
                lhs.emit(builder, locals, function);
                rhs.emit(builder, locals, function);
                function.instruction(&match op {
                    RelationalBinaryOp::LessThan => Instruction::F64Lt,
                    RelationalBinaryOp::LessThanOrEqual => Instruction::F64Le,
                    RelationalBinaryOp::GreaterThan => Instruction::F64Gt,
                    RelationalBinaryOp::GreaterThanOrEqual => Instruction::F64Ge,
                });
            }
            Self::Equal(equal, lhs, rhs) => {
                lhs.emit(builder, locals, function);
                rhs.emit(builder, locals, function);
                function.instruction(&if *equal {
                    Instruction::F64Eq
                } else {
                    Instruction::F64Ne
                });
            }
        }
    }
}

impl FunctionBuilder<'_> {
    pub(super) fn compile_scalar_number_loop(
        &mut self,
        plan: &ScalarNumberLoop,
        entry: &ScalarNumberLoopEntry<'_>,
        function: &mut Function,
    ) -> Result<(), EmitError> {
        let schema = self.runtime_schema();
        let values = plan
            .bindings
            .iter()
            .map(|binding| {
                if binding.initialized_in_body {
                    function.instruction(&Instruction::F64Const(Ieee64::from(0.0)));
                } else {
                    self.local_binding(binding.id)
                        .value()
                        .scalar()
                        .load(function);
                    function.instruction(&Instruction::F64ReinterpretI64);
                }
                let local = match binding.domain {
                    NumberDomain::Number | NumberDomain::SafeInteger => {
                        LoopLocal::Number(schema.reserve_f64_local(function))
                    }
                    NumberDomain::Signed32 => {
                        function.instruction(&Instruction::I32TruncSatF64S);
                        LoopLocal::Signed32(schema.reserve_i32_local(function))
                    }
                    NumberDomain::Unsigned32 => {
                        function.instruction(&Instruction::I32TruncSatF64U);
                        LoopLocal::Unsigned32(schema.reserve_i32_local(function))
                    }
                };
                local.store(function);
                local
            })
            .collect();
        let locals = LoopLocals {
            bindings: &plan.bindings,
            values,
            invariant: entry.fact.as_ref(),
            calls: entry.calls.as_ref().map(|roots| (&plan.calls, roots)),
        };
        // The body's last value is independent of later update/final-test
        // writes. Keep its proven representation until loop exit, too.
        let value = plan
            .body
            .last()
            .and_then(|statement| statement.domain(&locals))
            .map(|domain| match domain {
                NumberDomain::Number | NumberDomain::SafeInteger => {
                    LoopLocal::Number(schema.reserve_f64_local(function))
                }
                NumberDomain::Signed32 => LoopLocal::Signed32(schema.reserve_i32_local(function)),
                NumberDomain::Unsigned32 => {
                    LoopLocal::Unsigned32(schema.reserve_i32_local(function))
                }
            });
        let iterated = schema.reserve_i32_local(function);
        iterated.set_constant(0, function);
        let iterations_done = plan.whole_trip.as_ref().map(|whole_trip| {
            let done = self.open_frame(ControlFrameKind::Block, function);
            whole_trip.emit_guarded(
                self,
                &locals,
                value.expect("whole-trip assignment has a body value"),
                iterated,
                done,
                function,
            );
            done
        });
        if let Some(chunked) = ChunkedLoop::new(plan) {
            chunked.emit(self, plan, &locals, value, iterated, function);
        }
        if plan.dense_four_step {
            let array = locals.array();
            let done = self.open_frame(ControlFrameKind::Block, function);
            let next = self.open_frame(ControlFrameKind::Loop, function);
            array.emit_four_step_test(function);
            function.instruction(&Instruction::I32Eqz);
            self.emit_branch_if_to_target(done, function);
            for _ in 0..4 {
                plan.emit_iteration(self, &locals, value, iterated, function);
            }
            self.emit_branch_to_target(next, function);
            self.pop_control(ControlFrameKind::Loop);
            function.instruction(&Instruction::End);
            self.pop_control(ControlFrameKind::Block);
            function.instruction(&Instruction::End);
        }
        let done = self.open_frame(ControlFrameKind::Block, function);
        let compact = match locals.invariant {
            Some(RegionFact::ArrayReads(array)) => {
                array.prepare_compact_loop(done, self, function)?
            }
            _ => None,
        };
        if let Some(compact) = compact.as_ref().filter(|rows| rows.is_projected()) {
            self.emit_scalar_number_loop_iterations(
                plan,
                &locals,
                value,
                iterated,
                Some((compact, RowLoopKind::Projected)),
                done,
                function,
            );
        } else if let Some(compact) = &compact {
            // First-row preparation fixes the storage mode. Emit each backedge
            // with its own guards/scratch, sharing arithmetic and prefix exit.
            compact.emit_dictionary_mode(function);
            self.open_frame(ControlFrameKind::If, function);
            self.emit_scalar_number_loop_iterations(
                plan,
                &locals,
                value,
                iterated,
                Some((compact, RowLoopKind::Guarded(RowStorageKind::Dictionary))),
                done,
                function,
            );
            function.instruction(&Instruction::Else);
            self.emit_scalar_number_loop_iterations(
                plan,
                &locals,
                value,
                iterated,
                Some((compact, RowLoopKind::Guarded(RowStorageKind::Inline))),
                done,
                function,
            );
            self.pop_control(ControlFrameKind::If);
            function.instruction(&Instruction::End);
        } else {
            self.emit_scalar_number_loop_iterations(
                plan, &locals, value, iterated, None, done, function,
            );
        }
        self.pop_control(ControlFrameKind::Block);
        function.instruction(&Instruction::End);
        if iterations_done.is_some() {
            self.pop_control(ControlFrameKind::Block);
            function.instruction(&Instruction::End);
        }
        for (binding, local) in plan.bindings.iter().zip(&locals.values) {
            if binding.written {
                if binding.initialized_in_body {
                    iterated.load(function);
                    self.open_frame(ControlFrameKind::If, function);
                }
                local.load_number(function);
                function.instruction(&Instruction::I64ReinterpretF64);
                self.local_binding(binding.id)
                    .value()
                    .scalar()
                    .store(function);
                if binding.initialized_in_body {
                    let value = self.local_binding(binding.id).value();
                    value.set_number(value.scalar(), function);
                    self.pop_control(ControlFrameKind::If);
                    function.instruction(&Instruction::End);
                }
            }
        }
        if let Some(RegionFact::ArrayReads(array)) = locals.invariant {
            array.publish_row_alias(iterated, self, function);
        }
        if let Some((plan, roots)) = locals.calls {
            roots.publish(plan, self, function);
        }
        if let Some(value) = value {
            iterated.load(function);
            self.open_frame(ControlFrameKind::If, function);
            value.load_number(function);
            function.instruction(&Instruction::I64ReinterpretF64);
            self.completion().value().scalar().store(function);
            self.completion()
                .value()
                .set_number(self.completion().value().scalar(), function);
            self.pop_control(ControlFrameKind::If);
            function.instruction(&Instruction::End);
        }
        schema.release_i32_local(iterated, function);
        for local in value.into_iter().chain(locals.values.into_iter().rev()) {
            match local {
                LoopLocal::Number(value) => schema.release_f64_local(value, function),
                LoopLocal::Signed32(value) | LoopLocal::Unsigned32(value) => {
                    schema.release_i32_local(value, function);
                }
            }
        }
        Ok(())
    }

    fn emit_scalar_number_loop_iterations(
        &mut self,
        plan: &ScalarNumberLoop,
        locals: &LoopLocals<'_>,
        value: Option<LoopLocal>,
        iterated: I32Local,
        compact: Option<(&PreparedCompactRows<'_, '_>, RowLoopKind)>,
        done: ControlTarget,
        function: &mut Function,
    ) {
        let next = self.open_frame(ControlFrameKind::Loop, function);
        if compact.is_none() {
            match locals.invariant {
                Some(RegionFact::ArrayReads(array)) => array.emit_test(function),
                Some(RegionFact::StrictPairInputs(inputs)) => inputs.emit_test(locals, function),
                _ => plan.test.emit(self, locals, function),
            }
            function.instruction(&Instruction::I32Eqz);
            self.emit_branch_if_to_target(done, function);
        }
        plan.emit_iteration(self, locals, value, iterated, function);
        if let Some((compact, kind)) = compact {
            compact.prepare_next(kind, self, function);
        }
        self.emit_branch_to_target(next, function);
        self.pop_control(ControlFrameKind::Loop);
        function.instruction(&Instruction::End);
    }
}
