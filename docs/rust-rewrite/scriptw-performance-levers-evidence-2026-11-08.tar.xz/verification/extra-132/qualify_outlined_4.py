"""Bind ABI witness updates to unchanged measured product executables."""
import json,subprocess,sys
from pathlib import Path
R=Path.cwd();B=R/'target/performance-levers-20261108';sys.path[:0]=[str(B/'tools'),str(R/'scripts')]
from common import check_source,validate_snapshot,digest,save
from measure_rsc import cargo_source_identity
from limited_verification import require_kernel_budget
from native_test_protocol import parse_inventory,result_summaries
require_kernel_budget(4*1024**3)
s0=B/'tools/source-outlined-1/manifest.json';s1=B/'tools/source-outlined-4/manifest.json';old=validate_snapshot(s0);new=check_source(s1)
changed=[n for n in sorted(set(old['files'])|set(new['files'])) if old['files'].get(n)!=new['files'].get(n)]
assert len(changed)==14 and all(n.startswith('crates/scriptw-aot-wasm/tests/') and n.endswith('.rs') for n in changed),changed
p0=B/'build-outlined-1.stdout';p1=B/'build-outlined-4.stdout'
rows=lambda p:[json.loads(l) for l in p.read_text().splitlines() if l.startswith('{')]
a0=rows(p0);a1=rows(p1);assert [r['success'] for r in a1 if r.get('reason')=='build-finished']==[True]
artifact=lambda rows,n:next(r for r in rows if r.get('reason')=='compiler-artifact' and r['target']['name']==n and r.get('executable'))
assert cargo_source_identity(p0)==cargo_source_identity(p1)
assert cargo_source_identity(p1)[0]=='2255a0080df2d4f1c503ebc3dcd44fa1431c135a97c3412adc641b17ccac52c4'
out=B/'frozen-outlined-4';out.mkdir(exist_ok=False);unchanged=[]
for n in ['emission','structure_builtins','structure_language','structure_async','runtime_link','modules_realms','intl_temporal','structure','aot_builtins','aot_language','aot_async','aot_realm_modules','rsc_baseline','compiler_precompiled_baseline']:
 prev=artifact(a0,n);cur=artifact(a1,n)
 if n not in ['emission','structure_async']:
  assert cur['fresh'] and {**prev,'fresh':None}=={**cur,'fresh':None},n
  assert digest(cur['executable'])==digest(B/'frozen-outlined-1'/n),n
  unchanged.append(dict(target=n,sha256=digest(B/'frozen-outlined-1'/n)))
 else:
  binary=out/n;subprocess.run(['cp','--reflink=auto',cur['executable'],str(binary)],check=True);assert digest(binary)==digest(cur['executable'])
  if n=='emission':assert cur['fresh'] and digest(binary)==digest(B/'frozen-outlined-3/emission')
  save(out/(n+'-producer.json'),dict(artifact=cur,sha256=digest(binary),source_manifest_sha256=digest(s1),cargo_stdout=str(p1),cargo_stdout_sha256=digest(p1),frozen_path=str(binary)))
n='rsc_baseline';reuse=dict(schema='scriptw-rsc-levers-qualified-candidate-reuse-v1',complete=True,allowed_changed_files=changed,previous_source=dict(path=str(s0),sha256=digest(s0)),current_source=dict(path=str(s1),sha256=digest(s1)),previous_producer=dict(path=str(p0),sha256=digest(p0)),current_producer=dict(path=str(p1),sha256=digest(p1)),binary=dict(path=str(B/'frozen-outlined-1'/n),sha256=digest(B/'frozen-outlined-1'/n)),previous_fresh=False,current_fresh=True,producer_inputs_identical=True,previous_artifact=artifact(a0,n),current_artifact=artifact(a1,n))
save(B/'external-test-reuse-outlined-4.json',reuse)
focus=B/'focused-outlined-4';focus.mkdir(exist_ok=False);binary=out/'structure_async';listed=subprocess.run([str(binary),'--list'],capture_output=True,text=True,check=True);(focus/'structure_async.list').write_text(listed.stdout);inventory=parse_inventory(listed.stdout);argv=[str(binary),'--test-threads=1']
with (focus/'structure_async.stdout').open('wb') as o,(focus/'structure_async.stderr').open('wb') as e:r=subprocess.run(argv,stdout=o,stderr=e,timeout=600)
summary=result_summaries((focus/'structure_async.stdout').read_text());assert summary==[('ok','116','0','0','0','0')],summary;assert r.returncode==0 and len(inventory)==116
proof=dict(complete=True,source_manifest_sha256=digest(s1),measured_source_manifest_sha256=digest(s0),source_fingerprint=cargo_source_identity(p1)[0],qualified_reuse=dict(path=str(B/'external-test-reuse-outlined-4.json'),sha256=digest(B/'external-test-reuse-outlined-4.json')),unchanged_binaries=unchanged,structure_async=dict(target='structure_async',argv=argv,exit_code=r.returncode,summary=summary[0],inventory=len(inventory),inventory_sha256=digest(focus/'structure_async.list'),binary_sha256=digest(binary),stdout_sha256=digest(focus/'structure_async.stdout'),stderr_sha256=digest(focus/'structure_async.stderr')),emission_reuse=dict(binary_sha256=digest(out/'emission'),passing_receipt=str(B/'broad-final/receipt.json')),limits='Only external ABI witnesses changed. Measured source/hosts stay immutable; all product and unaffected test executables are identical. Original failed test results retained; complete 116 async structure checks rerun.')
save(focus/'receipt.json',proof);check_source(s1);print('QUALIFIED 116 ASYNC STRUCTURE CHECKS; PRODUCT BINARIES IDENTICAL',flush=True)
