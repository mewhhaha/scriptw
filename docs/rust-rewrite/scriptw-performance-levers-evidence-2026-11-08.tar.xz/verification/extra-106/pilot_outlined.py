"""Small unscored balanced screen before spending a full RSC campaign."""
import json,os,statistics,sys
from pathlib import Path
R=Path.cwd();B=R/'target/performance-levers-20261108';sys.path[:0]=[str(B/'tools'),str(R/'scripts')]
from common import check_source,digest,read,save
from limited_verification import limited_environment,require_kernel_budget
from measure_rsc import checked_scriptw,resources,check_resources,cargo_source_identity
from benchmark_metrics import measure_process
require_kernel_budget(4*1024**3)
source=B/'tools/source-outlined-1/manifest.json';check_source(source)
cdir=B/'tools/rsc-campaign-1';campaign=read(cdir/'campaign.json');assert campaign['status']=='complete'
reference=read(cdir/'block-0-rep-0-baseline/report.json');v8=read(cdir/'block-0-rep-0-v8/report.json');goldens={r['case']:r['stdout'] for r in v8['observations']}
hosts={'baseline':Path(campaign['baseline']['path']),'candidate':B/'frozen-outlined-1/rsc_baseline'}
fp=cargo_source_identity(B/'build-outlined-1.stdout')[0];pins={str(p):digest(p) for p in [*hosts.values(),source,B/'build-outlined-1.stdout',Path(__file__)]}
out=B/'pilot-outlined-1';out.mkdir(exist_ok=False);report=dict(complete=False,unscored=True,source_manifest_sha256=digest(source),pins=pins,rows=[],limits='Two balanced process pairs are a screen only; final scores require full four-actor campaign.')
envbase=limited_environment()
for key in list(envbase):
 if key.startswith(('SCRIPTW_','SCRIPTC_','ZIG_')) or key=='NODE_COMPILE_CACHE':del envbase[key]
for i,actor in enumerate(['baseline','candidate','candidate','baseline']):
 check_source(source)
 for p,h in pins.items():assert digest(p)==h
 work=out/(str(i)+'-'+actor);work.mkdir();(work/'tmp').mkdir();(work/'cache').mkdir()
 env=dict(envbase,TMPDIR=str(work/'tmp'),NODE_DISABLE_COMPILE_CACHE='1',SCRIPTW_CACHE_DIR=str(work/'cache'),SCRIPTW_JOBS='1',SCRIPTW_MODULE_MEMORY_CACHE_ENTRIES='1',SCRIPTW_MODULE_MEMORY_CACHE_LIMIT_BYTES=str(64*1024**2))
 raw=work/'report.json';argv=[str(hosts[actor]),reference['inputs']['source'],reference['inputs']['support'],str(raw),'7','3','fast'];before=resources()
 with (work/'stdout').open('xb') as stdout,(work/'stderr').open('xb') as stderr:res=measure_process(argv,cwd=R,env=env,stdout=stdout,stderr=stderr,timeout=60,time_binary=R/'target/performance-worker-cpu/tools/time')
 check_resources(before,resources());assert res['exit_code']==0 and not res['timed_out'] and not (work/'stderr').read_bytes()
 value=read(raw);assert read(work/'stdout')==value
 medians=checked_scriptw(value,hosts[actor],reference['inputs'],goldens,'fast',reference['configuration'])
 if actor=='candidate':assert value['source_fingerprint']==fp
 else:assert value['source_fingerprint']==reference['source_fingerprint']
 row=dict(actor=actor,argv=argv,resources=res,report_sha256=digest(raw),medians_ns=medians,program_wasm_bytes=value['program_wasm_bytes'],runtime=value['runtime']);report['rows'].append(row);save(out/'receipt.json',report);print(actor,medians,'P',value['program_wasm_bytes'],flush=True)
report['medians_ns']={a:{case:statistics.median(r['medians_ns'][case] for r in report['rows'] if r['actor']==a) for case in ['rsc-sync','rsc-async']} for a in hosts};report['complete']=True;save(out/'receipt.json',report);check_source(source)
print('PILOT COMPLETE',report['medians_ns'],flush=True)
