import hashlib,json,subprocess,sys
from pathlib import Path
R=Path.cwd();B=R/'target/performance-levers-20261108';sys.path[:0]=[str(B/'tools'),str(R/'scripts')]
from common import check_source,validate_snapshot
from native_test_protocol import result_summaries
from limited_verification import require_kernel_budget
require_kernel_budget(4*1024**3)
sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
s0=B/'tools/source-outlined-1/manifest.json';s1=B/'tools/source-outlined-2/manifest.json';old=validate_snapshot(s0);new=check_source(s1)
changed=[n for n in sorted(set(old['files'])|set(new['files'])) if old['files'].get(n)!=new['files'].get(n)]
assert changed==['crates/scriptw-aot-wasm/tests/emission/row_loop_operators.rs','crates/scriptw-aot-wasm/tests/emission/scalar_row_modes.rs'],changed
p0=B/'build-outlined-1.stdout';p1=B/'build-outlined-2.stdout'
rows=lambda p:[json.loads(l) for l in p.read_text().splitlines() if l.startswith('{')]
a0=rows(p0);a1=rows(p1);assert [r['success'] for r in a1 if r.get('reason')=='build-finished']==[True]
artifact=lambda rows,n:next(r for r in rows if r.get('reason')=='compiler-artifact' and r['target']['name']==n and r.get('executable'))
out=B/'frozen-outlined-2';out.mkdir(exist_ok=False)
for n in ['emission','structure_builtins','structure_language','structure_async','runtime_link','modules_realms','intl_temporal','structure','aot_builtins','aot_language','aot_async','aot_realm_modules','rsc_baseline','compiler_precompiled_baseline']:
 prev=artifact(a0,n);cur=artifact(a1,n)
 if n!='emission':
  assert cur['fresh'] and {**prev,'fresh':None}=={**cur,'fresh':None},n
  assert sha(cur['executable'])==sha(B/'frozen-outlined-1'/n),n
 else:
  binary=out/n;subprocess.run(['cp','--reflink=auto',cur['executable'],str(binary)],check=True)
  assert sha(binary)==sha(cur['executable'])
  (out/(n+'-producer.json')).write_text(json.dumps(dict(artifact=cur,sha256=sha(binary),source_manifest_sha256=sha(s1),cargo_stdout=str(p1),cargo_stdout_sha256=sha(p1),frozen_path=str(binary)),indent=2)+'\n')
n='rsc_baseline';reuse=dict(schema='scriptw-rsc-levers-qualified-candidate-reuse-v1',complete=True,allowed_changed_files=changed,previous_source=dict(path=str(s0),sha256=sha(s0)),current_source=dict(path=str(s1),sha256=sha(s1)),previous_producer=dict(path=str(p0),sha256=sha(p0)),current_producer=dict(path=str(p1),sha256=sha(p1)),binary=dict(path=str(B/'frozen-outlined-1'/n),sha256=sha(B/'frozen-outlined-1'/n)),previous_fresh=False,current_fresh=True,producer_inputs_identical=True,previous_artifact=artifact(a0,n),current_artifact=artifact(a1,n))
(B/'external-test-reuse-outlined-2.json').write_text(json.dumps(reuse,indent=2)+'\n')
from measure_rsc import cargo_source_identity
assert cargo_source_identity(p0)==cargo_source_identity(p1)
assert cargo_source_identity(p1)[0]=='2255a0080df2d4f1c503ebc3dcd44fa1431c135a97c3412adc641b17ccac52c4'
focus=B/'focused-outlined-2';focus.mkdir(exist_ok=False)
argv=[str(out/'emission'),'scalar_row_modes::','--test-threads=1']
with (focus/'scalar_row_modes.stdout').open('wb') as o,(focus/'scalar_row_modes.stderr').open('wb') as e:r=subprocess.run(argv,stdout=o,stderr=e,timeout=600)
summary=result_summaries((focus/'scalar_row_modes.stdout').read_text());assert summary==[('ok','1','0','0','0','73')],summary
assert r.returncode==0
proof=dict(complete=True,source_manifest_sha256=sha(s1),measured_source_manifest_sha256=sha(s0),source_fingerprint=cargo_source_identity(p1)[0],qualified_reuse=dict(path=str(B/'external-test-reuse-outlined-2.json'),sha256=sha(B/'external-test-reuse-outlined-2.json')),corrected_emission=dict(argv=argv,exit_code=r.returncode,summary=summary[0],binary_sha256=sha(out/'emission'),stdout_sha256=sha(focus/'scalar_row_modes.stdout'),stderr_sha256=sha(focus/'scalar_row_modes.stderr')),original_broad=dict(path=str(B/'broad/receipt.json'),sha256=sha(B/'broad/receipt.json'),passed=73,failed=1),limits='Only external emission witnesses changed. Product hosts and all other native test binaries remain byte-identical; original failed fixture result retained. Complete emission and remaining broader scopes run separately.')
(focus/'receipt.json').write_text(json.dumps(proof,indent=2)+'\n');check_source(s1);print('QUALIFIED EXTERNAL TEST CORRECTION; PRODUCT BINARIES IDENTICAL',flush=True)
