"""Run all 21 retained situations with the already frozen initial host."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE / 'tools'))
sys.path.insert(0, str(ROOT / 'scripts'))
from common import check_source, validate_snapshot
from limited_verification import limited_environment, require_kernel_budget
from measure_rsc import resources, check_resources


def load(path):
    return json.loads(Path(path).read_text())


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def main():
    require_kernel_budget(4 * 1024**3)
    assert len(os.sched_getaffinity(0)) == 1
    source = BASE / 'tools/source-outlined-1/manifest.json'
    check_source(source)
    initial = BASE / 'tools/source-outlined-1/manifest.json'
    validate_snapshot(initial)
    previous = ROOT / 'docs/rust-rewrite/situations-current.json'
    summary = load(previous)
    assert summary['complete'] and len(summary['workloads']) == 21
    fixtures = Path(summary['inputs'][0]['original']).parent
    manifest = load(fixtures / 'manifest.json')
    assert len(manifest['execution']) == 21
    assert {case['file'] for case in manifest['execution']} == {case['file'] for case in summary['workloads']}
    for item in summary['inputs']:
        assert sha(item['original']) == item['sha256']
    host = BASE / 'frozen-outlined-1/compiler_precompiled_baseline'
    receipt_path = host.with_name(host.name + '-producer.json')
    receipt = load(receipt_path)
    producer = Path(receipt['cargo_stdout'])
    assert sha(host) == receipt['sha256']
    assert sha(producer) == receipt['cargo_stdout_sha256']
    assert sha(initial) == receipt['source_manifest_sha256']
    assert receipt['artifact'] in [json.loads(line) for line in producer.read_text().splitlines() if line.startswith('{')]
    node, timer = (Path(summary['tools'][name]['path']) for name in ('node', 'time'))
    for name, path in [('node', node), ('time', timer)]:
        assert sha(path) == summary['tools'][name]['sha256']
    paths = [Path(__file__), source, initial, previous, host, receipt_path, producer, node, timer,
             ROOT / 'scripts/benchmark-situations.py', ROOT / 'scripts/limited_verification.py',
             BASE / 'tools/common.py', BASE / 'tools/measure_rsc.py']
    pins = {str(path): sha(path) for path in paths}
    output = BASE / 'situations-full-1'
    assert not output.exists()
    argv = [sys.executable, '-B', str(ROOT / 'scripts/benchmark-situations.py'),
            '--host', str(host), '--producer-log', str(producer), '--producer-receipt', str(receipt_path),
            '--fixtures', str(fixtures), '--output', str(output), '--node', str(node), '--time', str(timer)]
    record = {'complete': False, 'status': 'running', 'argv': argv, 'pins': pins,
              'resources_before': resources(), 'situations': 21, 'policies': ['fast', 'speed'],
              'expected_consumer_processes': 504,
              'limits': 'Current fast/speed/V8 cohorts use the existing checked retained-module protocol. '
              'The old published panel is a separately frozen compiler cohort, not a fresh paired control.'}
    record_path = BASE / 'situations-command.json'
    assert not record_path.exists()

    def save():
        record_path.write_text(json.dumps(record, indent=2) + '\n')

    save()
    started = time.monotonic_ns()
    try:
        with (BASE / 'situations.stdout').open('xb') as out, (BASE / 'situations.stderr').open('xb') as err:
            child = subprocess.run(argv, cwd=ROOT, env=limited_environment(), stdin=subprocess.DEVNULL,
                                   stdout=out, stderr=err, timeout=7200)
        record['exit_code'] = child.returncode
        assert child.returncode == 0
        result = load(output / 'report.json')
        assert result['complete'] and result['status'] == 'complete'
        assert len(result['cases']) == 21 and len(result['workloads']) == 21
        assert result['policy']['native_policies'] == ['fast', 'speed']
        assert result['source_identity']['source_fingerprint'] == '5aa48ad8a545934f090cc46c13e18d6e56ac76098bbfe8e0a56eb345b9677044'
        assert result['source_identity']['executable_sha256'] == receipt['sha256']
        record['report_sha256'] = sha(output / 'report.json')
        record.update(complete=True, status='complete')
    except BaseException as error:
        record.update(status='failed', error=repr(error))
        raise
    finally:
        record['elapsed_ns'] = time.monotonic_ns() - started
        record['resources_after'] = resources()
        try:
            check_source(source)
            for path, expected in pins.items():
                assert sha(path) == expected, path
            check_resources(record['resources_before'], record['resources_after'])
        except BaseException as error:
            record.update(complete=False, status='failed', terminal_verification_error=repr(error))
            raise
        finally:
            save()
    print('FULL 21 SITUATIONS COMPLETE', output / 'report.json', flush=True)


if __name__ == '__main__':
    main()
