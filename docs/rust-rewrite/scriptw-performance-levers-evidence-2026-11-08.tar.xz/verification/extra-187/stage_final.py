"""Prepare measured current reports, inert evidence and review drafts after verification."""
import json,subprocess,sys,hashlib
from pathlib import Path
ROOT=Path.cwd();BASE=ROOT/'target/performance-levers-20261108'
sys.path.insert(0,str(ROOT/'scripts'))
from limited_verification import require_kernel_budget
require_kernel_budget(4*1024**3)
def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
units=read(BASE/'units-cli-complete/receipt.json');assert units['complete'] and units['cli_smoke_passed']==8 and units['ordinary_aot_failures']==4
checks=read(BASE/'remaining-source-checks-2/receipt.json');assert checks['complete']
cheap=read(BASE/'cheap-final-7/receipt.json');assert cheap['complete']
broad=read(BASE/'broad-complete/receipt.json');assert broad['complete']
assert len(broad['targets'])==12 and sum(int(r['summary'][1]) for r in broad['targets'])==2550
assert all(r['exit_code']==0 and r['summary'][0]=='ok' and r['summary'][2:]==['0','0','0','0'] and r['inventory']==int(r['summary'][1]) for r in broad['targets'])
feature=read(BASE/'product-feature-comparison.json');assert feature['complete']
scopes={r['target']:{'passed':r['passed'],'failed':r['failed']} for r in units['unit_scopes']}
assert scopes=={'scriptw_aot_wasm':{'passed':671,'failed':4},'scriptw_engine':{'passed':1093,'failed':0}}
coverage={'schema':'scriptw-performance-levers-coverage-v1','date':'2026-11-08','source_fingerprint':'2255a0080df2d4f1c503ebc3dcd44fa1431c135a97c3412adc641b17ccac52c4','full_workspace_ci_rerun':False,'full_test262_rerun':False,'format_failures':len(cheap['format_files']),'stale_intl_recipes':len(cheap['stale_intl_recipes']),'scopes':{'broad':{'passed':2550,'scopes':12},'units':{'passed':1764,'failed':4,'targets':scopes},'source_guards':{'passed':380},'production_cli':{'passed':8},'situations':{'processes':504,'checked_calls':60984,'samples':21,'warmups':100},'rsc':{'processes':32,'checked_calls':640}},'receipts':{str(p.relative_to(ROOT)):sha(p) for p in [BASE/'units-cli-complete/receipt.json',BASE/'remaining-source-checks-2/receipt.json',BASE/'cheap-final-7/receipt.json',BASE/'broad-complete/receipt.json',BASE/'source-guards-outlined-1/receipt.json',BASE/'product-feature-comparison.json']}}
coverage_path=BASE/'coverage-summary.json';assert not coverage_path.exists();coverage_path.write_text(json.dumps(coverage,indent=2)+'\n')
args=[sys.executable,'-B',str(BASE/'publication-tools/stage_publication.py'),'--campaign',str(BASE/'tools/rsc-campaign-2/campaign.json'),'--aggregate',str(BASE/'tools/rsc-campaign-2/aggregate.json'),'--source-manifest',str(BASE/'tools/source-outlined-1/manifest.json'),'--verification-manifest',str(BASE/'tools/source-outlined-5/manifest.json'),'--verification-reuse-receipt',str(BASE/'test-only-reuse-outlined-5.json'),'--verification-qualification-receipt',str(BASE/'qualification-outlined-5.json'),'--mixed-cfg-source-manifest',str(BASE/'tools/source-outlined-6/manifest.json'),'--mixed-cfg-qualification-receipt',str(BASE/'qualification-outlined-6.json'),'--format-only-source-manifest',str(BASE/'tools/source-outlined-7/manifest.json'),'--format-only-qualification-receipt',str(BASE/'qualification-outlined-7.json'),'--situations-report',str(BASE/'situations-qualified.json'),'--attribution-report',str(BASE/'attribution-stage/react-attribution-current.json'),'--output-dir',str(BASE/'publication-stage')]
# Preserve experiment failures and selected-scope outcomes, never binaries or Wasm payloads.
evidence=[]
for pattern in ('*.py','*.json','*.stdout','*.stderr'):
 evidence.extend(sorted(BASE.glob(pattern)))
for name in ('tools','publication-tools','candidate-diagnostics-1','baseline-entries-control','baseline-entries-sync','baseline-entries-async','focused-outlined-1','focused-outlined-3','focused-outlined-4','source-guards-outlined-1','broad-final','broad-complete','structure-rest','units-and-cli','units-and-cli-final','units-cli-complete','remaining-source-checks','remaining-source-checks-2','cheap-final-6','cheap-final-7','pilot-slim-1','pilot-outlined-1','frozen-outlined-1','frozen-outlined-3','frozen-outlined-4','situations-full-1/build','situations-full-1/logs','situations-full-1/manifests','situations-full-1/sources','situations-full-1/tooling'):
 evidence.append(BASE/name)
for path in sorted(set(evidence)):
 assert path.exists(),path
 args.extend(['--evidence',str(path)])
subprocess.run(args,cwd=ROOT,check=True)
subprocess.run([sys.executable,'-B',str(BASE/'publication-tools/stage_docs.py'),'--rsc-report',str(BASE/'publication-stage/reports/rsc-current.json'),'--situations-report',str(BASE/'situations-qualified.json'),'--coverage-summary',str(coverage_path),'--attribution-summary',str(BASE/'attribution-stage/docs-snippet.json'),'--output-dir',str(BASE/'docs-stage')],cwd=ROOT,check=True)
print('STAGED REPORTS, ARCHIVE AND DOCS; CANONICAL FILES UNCHANGED',flush=True)
