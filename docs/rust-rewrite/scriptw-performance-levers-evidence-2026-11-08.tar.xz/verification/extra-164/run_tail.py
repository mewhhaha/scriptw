"""Selected-source measurements and qualification, one root-owned process at a time."""
import subprocess,sys,time,json
from pathlib import Path
R=Path.cwd();B=R/'target/performance-levers-20261108';sys.path[:0]=[str(B/'tools'),str(R/'scripts')]
from common import check_source,digest,save
from limited_verification import require_kernel_budget
from measure_rsc import resources,check_resources
require_kernel_budget(4*1024**3)
source=B/'tools/source-outlined-1/manifest.json';check_source(source)
assert json.loads((B/'tools/rsc-campaign-2/campaign.json').read_text())['status']=='complete'
commands=[('situations-runner',[sys.executable,'-B',str(B/'run_situations_outlined.py')]),('diagnostics-final',[sys.executable,'-B',str(B/'candidate_diagnostics.py'),'--phase','all','--source',str(source),'--campaign',str(B/'tools/rsc-campaign-2/campaign.json'),'--fingerprint','2255a0080df2d4f1c503ebc3dcd44fa1431c135a97c3412adc641b17ccac52c4','--output',str(B/'final-diagnostics')]),('broad',[sys.executable,'-B',str(B/'run_broad_outlined.py')]),('units-cli-runner',[sys.executable,'-B',str(B/'run_units_and_cli_outlined.py')]),('features',[sys.executable,'-B',str(B/'audit_product_features_outlined.py')]),('cheap-final',[sys.executable,'-B',str(B/'run_cheap_final_outlined.py')])]
report=dict(complete=False,source_manifest_sha256=digest(source),runs=[],resources_before=resources())
save(B/'tail-receipt.json',report)
for name,argv in commands:
 check_source(source);before=resources();started=time.monotonic_ns();row=dict(name=name,argv=argv,status='running');report['runs'].append(row);save(B/'tail-receipt.json',report);print('START',name,flush=True)
 with (B/(name+'.stdout')).open('xb') as o,(B/(name+'.stderr')).open('xb') as e:r=subprocess.run(argv,cwd=R,stdout=o,stderr=e,timeout=7200)
 row.update(status='finished',exit_code=r.returncode,elapsed_ns=time.monotonic_ns()-started,stdout_sha256=digest(B/(name+'.stdout')),stderr_sha256=digest(B/(name+'.stderr')));save(B/'tail-receipt.json',report);check_source(source);check_resources(before,resources());print('END',name,r.returncode,flush=True);assert r.returncode==0,name
report.update(complete=True,resources_after=resources());check_resources(report['resources_before'],report['resources_after']);save(B/'tail-receipt.json',report);print('TAIL COMPLETE',flush=True)
