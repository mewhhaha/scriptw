import json,subprocess,sys,time
from pathlib import Path
R=Path.cwd();B=R/'target/performance-levers-20261108';sys.path[:0]=[str(B/'tools'),str(R/'scripts')]
from common import check_source,digest,save
from limited_verification import require_kernel_budget
from native_test_protocol import parse_inventory,result_summaries
from measure_rsc import resources,check_resources
require_kernel_budget(4*1024**3)
source=B/'tools/source-outlined-4/manifest.json';check_source(source)
out=B/'broad-complete';out.mkdir(exist_ok=False)
prior=json.loads((B/'broad-final/receipt.json').read_text());rest=json.loads((B/'structure-rest/receipt.json').read_text());async_proof=json.loads((B/'focused-outlined-4/receipt.json').read_text());assert async_proof['complete']
kept=[r for r in prior['targets'] if r['summary'][0]=='ok']+rest['targets']+[async_proof['structure_async']]
assert len(kept)==8 and sum(int(r['summary'][1]) for r in kept)==748
report=dict(complete=False,source_manifest_sha256=digest(source),measured_source_manifest_sha256=async_proof['measured_source_manifest_sha256'],qualified_reuse=async_proof['qualified_reuse'],targets=kept,preserved_receipts=[dict(path=str(p),sha256=digest(p)) for p in [B/'broad-final/receipt.json',B/'structure-rest/receipt.json',B/'focused-outlined-4/receipt.json']],resources_before=resources())
save(out/'receipt.json',report)
for target in ['aot_builtins','aot_language','aot_async','aot_realm_modules']:
 check_source(source);binary=B/'frozen-outlined-1'/target;h=digest(binary);listed=subprocess.run([str(binary),'--list'],capture_output=True,text=True,check=True);(out/(target+'.list')).write_text(listed.stdout);inventory=parse_inventory(listed.stdout);argv=[str(binary),'--test-threads=1'];print('START',target,len(inventory),flush=True);started=time.monotonic_ns()
 with (out/(target+'.stdout')).open('xb') as o,(out/(target+'.stderr')).open('xb') as e:r=subprocess.run(argv,stdout=o,stderr=e,timeout=2400)
 sums=result_summaries((out/(target+'.stdout')).read_text());assert len(sums)==1;status,passed,failed,ignored,measured,filtered=sums[0];assert int(passed)+int(failed)+int(ignored)==len(inventory) and measured==filtered=='0'
 row=dict(target=target,argv=argv,binary_sha256=h,inventory=len(inventory),inventory_sha256=digest(out/(target+'.list')),exit_code=r.returncode,summary=sums[0],elapsed_ns=time.monotonic_ns()-started,stdout_sha256=digest(out/(target+'.stdout')),stderr_sha256=digest(out/(target+'.stderr')));report['targets'].append(row);save(out/'receipt.json',report);assert digest(binary)==h;print('END',target,sums[0],flush=True);assert r.returncode==0 and status=='ok' and failed==ignored=='0';check_source(source)
assert len({r['target'] for r in report['targets']})==12
report.update(complete=True,passed=sum(int(r['summary'][1]) for r in report['targets']),resources_after=resources());check_resources(report['resources_before'],report['resources_after']);save(out/'receipt.json',report);print('BROAD COMPLETE',report['passed'],flush=True)
