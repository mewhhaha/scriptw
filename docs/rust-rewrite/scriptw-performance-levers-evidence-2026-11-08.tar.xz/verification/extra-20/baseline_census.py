"""Excluded baseline source/helper entry counts on the previous frozen host."""
import hashlib,json,subprocess,sys,time
from pathlib import Path
ROOT=Path.cwd();BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'scripts'))
from limited_verification import require_kernel_budget
require_kernel_budget(4*1024**3)
old=ROOT/'target/rsc-property-kernels-20261107';campaign_path=old/'tools/rsc-campaign-1/campaign.json';c=json.loads(campaign_path.read_text());row=next(r for r in c['processes'] if r['engine']=='candidate');reference=campaign_path.parent/row['report'];binary=old/'frozen-initial/rsc_baseline'
driver=ROOT/'target/rsc-attribution-20261107/tools/count_source_entries.py'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(binary)==c['candidate']['sha256'] and sha(reference)==row['report_sha256']
report={'complete':False,'baseline_fingerprint':row['identity']['source_fingerprint'],'binary_sha256':sha(binary),'reference_sha256':sha(reference),'driver_sha256':sha(driver),'runs':[]}
def save():(BASE/'baseline-census.json').write_text(json.dumps(report,indent=2)+'\n')
for mode in ['control','sync','async']:
 output=BASE/('baseline-entries-'+mode);argv=[sys.executable,'-B',str(driver),'--mode',mode,'--binary',str(binary),'--baseline-json',str(reference),'--output',str(output)]
 if mode!='control':
  argv+=['--samples','7','--controls-receipt',str(BASE/'baseline-entries-control/receipt.json')]
  for target in ['js::vn#f133','js::ft#f123','helper::function_call','helper::cached_property_read']:argv+=['--target',target]
 print('START',mode,flush=True);started=time.monotonic_ns()
 with (BASE/('baseline-'+mode+'.stdout')).open('xb') as out,(BASE/('baseline-'+mode+'.stderr')).open('xb') as err:r=subprocess.run(argv,cwd=ROOT,stdout=out,stderr=err,timeout=600)
 report['runs'].append({'mode':mode,'argv':argv,'exit_code':r.returncode,'elapsed_ns':time.monotonic_ns()-started});save();assert r.returncode==0
 assert sha(driver)==report['driver_sha256'] and sha(binary)==report['binary_sha256'] and sha(reference)==report['reference_sha256']
report['complete']=True;save();print('BASELINE SOURCE CENSUS COMPLETE',flush=True)
