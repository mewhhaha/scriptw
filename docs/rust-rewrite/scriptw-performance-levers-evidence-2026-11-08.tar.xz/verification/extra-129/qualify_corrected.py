import hashlib,json,subprocess,sys
from pathlib import Path
R=Path.cwd();B=R/'target/performance-levers-20261108';sys.path[:0]=[str(B/'tools'),str(R/'scripts')]
from common import check_source,validate_snapshot
from native_test_protocol import result_summaries
from limited_verification import require_kernel_budget
require_kernel_budget(4*1024**3)
sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
s0=B/'tools/source-initial/manifest.json';s1=B/'tools/source-corrected-2/manifest.json';old=validate_snapshot(s0);new=check_source(s1)
changed=[n for n in sorted(set(old['files'])|set(new['files'])) if old['files'].get(n)!=new['files'].get(n)]
assert changed==['crates/scriptw-aot-wasm/tests/emission/binding_cell_payload.rs'],changed
p0=B/'build-initial.stdout';p1=B/'build-corrected-2.stdout'
rows=lambda p:[json.loads(l) for l in p.read_text().splitlines() if l.startswith('{')]
a0=rows(p0);a1=rows(p1);assert [r['success'] for r in a1 if r.get('reason')=='build-finished']==[True]
artifact=lambda rows,n:next(r for r in rows if r.get('reason')=='compiler-artifact' and r['target']['name']==n and r.get('executable'))
out=B/'frozen-corrected-2';out.mkdir(exist_ok=False)
for n in ['emission','structure_builtins','structure_language','structure_async','runtime_link','modules_realms','intl_temporal','structure','aot_builtins','aot_language','aot_async','aot_realm_modules','rsc_baseline','compiler_precompiled_baseline']:
 prev=artifact(a0,n);cur=artifact(a1,n)
 if n!='emission':
  assert cur['fresh'] and {**prev,'fresh':None}=={**cur,'fresh':None},n
  assert sha(cur['executable'])==sha(B/'frozen-initial'/n),n
 else:
  binary=out/n;subprocess.run(['cp','--reflink=auto',cur['executable'],str(binary)],check=True)
  assert sha(binary)==sha(cur['executable'])
  (out/(n+'-producer.json')).write_text(json.dumps(dict(artifact=cur,sha256=sha(binary),source_manifest_sha256=sha(s1),cargo_stdout=str(p1),cargo_stdout_sha256=sha(p1),frozen_path=str(binary)),indent=2)+'\n')
n='rsc_baseline';reuse=dict(schema='scriptw-rsc-levers-qualified-candidate-reuse-v1',complete=True,allowed_changed_files=changed,previous_source=dict(path=str(s0),sha256=sha(s0)),current_source=dict(path=str(s1),sha256=sha(s1)),previous_producer=dict(path=str(p0),sha256=sha(p0)),current_producer=dict(path=str(p1),sha256=sha(p1)),binary=dict(path=str(B/'frozen-initial'/n),sha256=sha(B/'frozen-initial'/n)),previous_fresh=False,current_fresh=True,producer_inputs_identical=True,previous_artifact=artifact(a0,n),current_artifact=artifact(a1,n))
(B/'candidate-reuse.json').write_text(json.dumps(reuse,indent=2)+'\n')
focus=B/'focused-corrected-2';focus.mkdir();argv=[str(out/'emission'),'binding_cell_payload::','--test-threads=1']
with (focus/'cell.stdout').open('wb') as o,(focus/'cell.stderr').open('wb') as e:child=subprocess.run(argv,stdout=o,stderr=e,timeout=600)
summaries=result_summaries((focus/'cell.stdout').read_text());assert summaries==[('ok','1','0','0','0','73')],summaries
assert child.returncode==0
prior=json.loads((B/'focused-initial/receipt.json').read_text());remaining=json.loads((B/'focused-remaining/receipt.json').read_text())
receipt=dict(complete=True,source_manifest_sha256=sha(s1),passed=33,runtime_passed=24,emission_passed=9,qualified_reuse= dict(path=str(B/'candidate-reuse.json'),sha256=sha(B/'candidate-reuse.json')),preserved=[dict(path=str(B/'focused-initial/receipt.json'),sha256=sha(B/'focused-initial/receipt.json'),scope='first four passing runtime scopes; original failed overbroad witness retained'),dict(path=str(B/'focused-remaining/receipt.json'),sha256=sha(B/'focused-remaining/receipt.json'),scope='all eight unaffected emission checks')],corrected_cell=dict(argv=argv,exit_code=child.returncode,summary=summaries[0],binary_sha256=sha(out/'emission'),stdout_sha256=sha(focus/'cell.stdout'),stderr_sha256=sha(focus/'cell.stderr')))
(focus/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');check_source(s1);print('QUALIFIED',33)
