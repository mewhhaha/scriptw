"""Qualify completed observations after an obsolete orchestration-only fingerprint assertion."""
import json,sys
from pathlib import Path
R=Path.cwd();B=R/'target/performance-levers-20261108';sys.path[:0]=[str(B/'tools'),str(R/'scripts')]
from common import check_source,digest,save
from measure_rsc import cargo_source_identity,check_resources
from limited_verification import require_kernel_budget
require_kernel_budget(4*1024**3)
source=B/'tools/source-outlined-1/manifest.json';check_source(source)
oldpath=B/'situations-command.json';old=json.loads(oldpath.read_text());assert old['exit_code']==0 and not old['complete'] and old['error']=='AssertionError()'
for p,h in old['pins'].items():assert digest(p)==h,p
check_resources(old['resources_before'],old['resources_after'])
p=B/'situations-full-1/report.json';d=json.loads(p.read_text());fp,rev=cargo_source_identity(B/'build-outlined-1.stdout')
assert fp=='2255a0080df2d4f1c503ebc3dcd44fa1431c135a97c3412adc641b17ccac52c4'
assert d['source_identity']['source_fingerprint']==fp and d['source_identity']['source_commit']==rev.removeprefix('git:')
assert d['complete'] and d['status']=='complete' and len(d['cases'])==len(d['workloads'])==21
assert d['policy']['native_policies']==['fast','speed'] and len(d['rows'])==504 and all(r['status']=='ok' for r in d['rows'])
assert all(c['status']=='ok' for c in d['commands'])
host=json.loads((B/'frozen-outlined-1/compiler_precompiled_baseline-producer.json').read_text());assert d['source_identity']['executable_sha256']==host['sha256']==digest(B/'frozen-outlined-1/compiler_precompiled_baseline')
assert all(len(r['samples_ns'])==21 for r in d['rows'])
proof=dict(complete=True,source_manifest_sha256=digest(source),report=dict(path=str(p),sha256=digest(p)),original_orchestrator=dict(path=str(oldpath),sha256=digest(oldpath),status='failed at stale 5aa orchestration assertion; underlying campaign complete and all pins/resources retained'),actual_source_fingerprint=fp,producer_source_revision=rev,consumer_processes=504,checked_invocations=60984,rerun_native_measurements=False)
save(B/'situations-qualified.json',proof);print('QUALIFIED 21 CASES / 504 PROCESSES / 60984 CHECKS',flush=True)
