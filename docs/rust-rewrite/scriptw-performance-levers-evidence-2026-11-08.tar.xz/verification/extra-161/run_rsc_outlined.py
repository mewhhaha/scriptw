import json,subprocess,sys
from pathlib import Path
R=Path.cwd();B=R/'target/performance-levers-20261108';old=R/'target/rsc-property-kernels-20261107'
build=['cargo','--config','build.jobs=1','build','--release','--locked','-p','scriptw-cli','-p','scriptw-aot-wasm','-p','scriptw-engine']
for t in ['emission','structure_builtins','structure_language','structure_async','runtime_link','modules_realms','intl_temporal','structure','aot_builtins','aot_language','aot_async','aot_realm_modules']:build+=['--test',t]
build+=['--example','rsc_baseline','--example','compiler_precompiled_baseline','--message-format=json-render-diagnostics']
argv=[sys.executable,'-B',str(B/'tools/measure_rsc.py'),'--source-manifest',str(B/'tools/source-outlined-1/manifest.json'),'--candidate-host',str(B/'frozen-outlined-1/rsc_baseline'),'--candidate-producer',str(B/'build-outlined-1.stdout'),'--candidate-build-argv',json.dumps(build),'--baseline-host',str(old/'frozen-initial/rsc_baseline'),'--baseline-producer',str(old/'frozen-initial/rsc_baseline-producer.json'),'--focused-receipt',str(B/'focused-outlined-1/receipt.json'),'--output',str(B/'tools/rsc-campaign-2')]
subprocess.run(argv,check=True)
