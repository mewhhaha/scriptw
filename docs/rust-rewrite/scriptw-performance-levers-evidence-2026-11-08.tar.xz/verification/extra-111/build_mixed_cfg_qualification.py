#!/usr/bin/env python3
"""Create a source-bound proof for the one mixed cfg(test) suffix correction."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT / 'target/performance-levers-20261108'
PUBLICATION_TOOLS = BASE / 'publication-tools'
MEASURED_MANIFEST = BASE / 'tools/source-outlined-1/manifest.json'
PREVIOUS_MANIFEST = BASE / 'tools/source-outlined-5/manifest.json'
CURRENT_MANIFEST = BASE / 'tools/source-outlined-6/manifest.json'
CAMPAIGN = BASE / 'tools/rsc-campaign-2/campaign.json'
AGGREGATE = BASE / 'tools/rsc-campaign-2/aggregate.json'
REUSE_RECEIPT = BASE / 'test-only-reuse-outlined-5.json'
PREVIOUS_QUALIFICATION = BASE / 'qualification-outlined-5.json'
OUTPUT = BASE / 'qualification-outlined-6.json'
MIXED_FILE = 'crates/scriptw-aot-wasm/src/functions/numeric_body.rs'
OLD_LITERAL = b'export function step(row,i,extra){tick=tick+1;return row.x+i;}'
NEW_LITERAL = b'export function step(row,i,a,b,c,extra){tick=tick+1;return row.x+i;}'
TEST_MARKER = b'#[cfg(test)]\nmod tests {'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def compiler_source_identity(path):
    rows = [json.loads(line) for line in Path(path).read_text().splitlines() if line]
    identities = set()
    for row in rows:
        if row.get('reason') != 'build-script-executed':
            continue
        environment = dict(row.get('env', []))
        fingerprint = environment.get('SCRIPTW_COMPILER_FINGERPRINT')
        revision = environment.get('SCRIPTW_COMPILER_SOURCE_REVISION')
        if fingerprint and revision:
            identities.add((fingerprint, revision))
    assert len(identities) == 1, f'expected one compiler identity in Cargo producer {path}'
    fingerprint, revision = next(iter(identities))
    return {'source_fingerprint': fingerprint, 'source_revision': revision}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--current-producer', type=Path, required=True,
                        help='Cargo JSON producer log for the fresh ordinary CLI verification build')
    parser.add_argument('--output', type=Path, default=OUTPUT)
    args = parser.parse_args()

    common = load_module('levers_source_snapshot_common', BASE / 'tools/common.py')
    measured = common.validate_snapshot(MEASURED_MANIFEST)
    previous = common.validate_snapshot(PREVIOUS_MANIFEST)
    current = common.validate_snapshot(CURRENT_MANIFEST)
    assert measured['base_git'] == previous['base_git'] == current['base_git']
    assert measured['runtime_abi'] == previous['runtime_abi'] == current['runtime_abi']

    # Preserve the existing qualified measured cohort and binary proof as a separate link.
    stage = load_module('stage_publication_receipt_builder', PUBLICATION_TOOLS / 'stage_publication.py')
    candidate = read(AGGREGATE)['engines']['candidate']['identity']
    campaign_candidate = read(CAMPAIGN)['candidate']
    reuse_proof = stage.validate_qualified_reuse(
        MEASURED_MANIFEST, PREVIOUS_MANIFEST, REUSE_RECEIPT,
        candidate, campaign_candidate, PREVIOUS_QUALIFICATION)

    changed = {
        relative for relative in set(previous['files']) | set(current['files'])
        if previous['files'].get(relative) != current['files'].get(relative)
    }
    assert changed == {MIXED_FILE}
    assert set(previous['deleted_files']) == set(current['deleted_files']) == set()
    previous_file = PREVIOUS_MANIFEST.parent / 'files' / MIXED_FILE
    current_file = CURRENT_MANIFEST.parent / 'files' / MIXED_FILE
    previous_bytes, current_bytes = previous_file.read_bytes(), current_file.read_bytes()
    assert previous_bytes.count(TEST_MARKER) == current_bytes.count(TEST_MARKER) == 1
    previous_cut, current_cut = previous_bytes.find(TEST_MARKER), current_bytes.find(TEST_MARKER)
    assert previous_cut >= 0 and previous_cut == current_cut
    previous_prefix, previous_suffix = previous_bytes[:previous_cut], previous_bytes[previous_cut:]
    current_prefix, current_suffix = current_bytes[:current_cut], current_bytes[current_cut:]
    assert previous_prefix == current_prefix
    assert previous_suffix.count(OLD_LITERAL) == 1 and previous_suffix.count(NEW_LITERAL) == 0
    assert current_suffix.count(OLD_LITERAL) == 0 and current_suffix.count(NEW_LITERAL) == 1
    assert previous_suffix.replace(OLD_LITERAL, NEW_LITERAL, 1) == current_suffix

    reuse = read(REUSE_RECEIPT)
    previous_producer = reuse['current_producer']
    current_producer_path = args.current_producer.resolve(strict=True)
    previous_identity = compiler_source_identity(previous_producer['path'])
    current_identity = compiler_source_identity(current_producer_path)
    source_change = {
        'path': MIXED_FILE,
        'previous_file_sha256': sha(previous_file),
        'current_file_sha256': sha(current_file),
        'production_prefix_sha256': hashlib.sha256(previous_prefix).hexdigest(),
        'previous_test_suffix_sha256': hashlib.sha256(previous_suffix).hexdigest(),
        'current_test_suffix_sha256': hashlib.sha256(current_suffix).hexdigest(),
        'previous_test_literal': OLD_LITERAL.decode(),
        'current_test_literal': NEW_LITERAL.decode(),
    }
    result = {
        'schema': 'scriptw-performance-levers-mixed-cfg-test-qualification-v1',
        'complete': True,
        'measured_source_manifest_sha256': sha(MEASURED_MANIFEST),
        'measured_source_fingerprint': candidate['source_fingerprint'],
        'previous_verification_manifest_sha256': sha(PREVIOUS_MANIFEST),
        'source_manifest_sha256': sha(CURRENT_MANIFEST),
        'previous_qualified_reuse': {
            'path': str(REUSE_RECEIPT.resolve()), 'sha256': sha(REUSE_RECEIPT),
            'previous_qualification_path': str(PREVIOUS_QUALIFICATION.resolve()),
            'previous_qualification_sha256': sha(PREVIOUS_QUALIFICATION),
            'proof': reuse_proof,
        },
        'mixed_test_only_change': source_change,
        'previous_compiler_source_identity': previous_identity,
        'current_compiler_source_identity': current_identity,
        'previous_producer': {'path': str(Path(previous_producer['path']).resolve()),
                              'sha256': sha(previous_producer['path'])},
        'current_producer': {'path': str(current_producer_path), 'sha256': sha(current_producer_path)},
        'product_binary_identity_comparison': 'not-claimed; this is a separate verification build',
        'qualification_scope': 'The measured source1/source fingerprint and 32-process RSC cohort remain unchanged. Source5 to source6 changes only one inline cfg(test) literal after a byte-identical production prefix. The source6 ordinary CLI build has its own compiler identity; it is not substituted into the measured cohort.',
    }
    output = args.output.resolve()
    assert output.is_relative_to(ROOT / 'target') and not output.exists()
    output.write_text(json.dumps(result, indent=2) + '\n')
    print(output)


if __name__ == '__main__':
    main()
