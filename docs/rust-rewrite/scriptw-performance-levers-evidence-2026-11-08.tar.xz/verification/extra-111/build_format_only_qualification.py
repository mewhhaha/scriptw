#!/usr/bin/env python3
"""Record the exact source6→7 import-only test formatting correction."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT / 'target/performance-levers-20261108'
MEASURED_MANIFEST = BASE / 'tools/source-outlined-1/manifest.json'
PREVIOUS_MANIFEST = BASE / 'tools/source-outlined-6/manifest.json'
CURRENT_MANIFEST = BASE / 'tools/source-outlined-7/manifest.json'
MIXED_QUALIFICATION = BASE / 'qualification-outlined-6.json'
OUTPUT = BASE / 'qualification-outlined-7.json'
FINGERPRINT_FILE = 'crates/scriptw-engine/compiler_fingerprint.rs'
REPLACEMENTS = {
    'crates/scriptw-aot-wasm/tests/emission/scalar_row_modes.rs': [
        ('use scriptw_aot_wasm::{GcSnapshotLayout, PromiseRejectionPolicy, emit_with_rooted_snapshot};',
         'use scriptw_aot_wasm::{emit_with_rooted_snapshot, GcSnapshotLayout, PromiseRejectionPolicy};'),
        ('use scriptw_front::{ParseOptions, parse};', 'use scriptw_front::{parse, ParseOptions};'),
    ],
    **{
        f'crates/scriptw-aot-wasm/tests/structure_async/{name}': [
            ('use scriptw_front::{ParseOptions, parse};', 'use scriptw_front::{parse, ParseOptions};'),
            ('use scriptw_ir::{HostSurfacePolicy, lower_with_host_surface_policy};',
             'use scriptw_ir::{lower_with_host_surface_policy, HostSurfacePolicy};'),
        ]
        for name in (
            'async_array_destructuring_structure.rs',
            'async_for_in_enumeration_structure.rs',
            'async_generator_for_in_structure.rs',
            'generator_array_destructuring_structure.rs',
            'generator_for_in_enumeration_structure.rs',
        )
    },
}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=OUTPUT)
    args = parser.parse_args()
    common = load_module('levers_source_snapshot_common', BASE / 'tools/common.py')
    measured = common.validate_snapshot(MEASURED_MANIFEST)
    previous = common.validate_snapshot(PREVIOUS_MANIFEST)
    current = common.validate_snapshot(CURRENT_MANIFEST)
    assert measured['base_git'] == previous['base_git'] == current['base_git']
    assert measured['runtime_abi'] == previous['runtime_abi'] == current['runtime_abi']
    mixed = read(MIXED_QUALIFICATION)
    assert mixed['complete'] is True
    assert mixed['measured_source_manifest_sha256'] == sha(MEASURED_MANIFEST)
    assert mixed['source_manifest_sha256'] == sha(PREVIOUS_MANIFEST)

    changed = {
        relative for relative in set(previous['files']) | set(current['files'])
        if previous['files'].get(relative) != current['files'].get(relative)
    }
    assert changed == set(REPLACEMENTS)
    assert set(previous['deleted_files']) == set(current['deleted_files']) == set()
    records = []
    for relative, replacements in sorted(REPLACEMENTS.items()):
        old_path = PREVIOUS_MANIFEST.parent / 'files' / relative
        new_path = CURRENT_MANIFEST.parent / 'files' / relative
        old_bytes, new_bytes = old_path.read_bytes(), new_path.read_bytes()
        expected = old_bytes
        changes = []
        for old, new in replacements:
            old_bytes_literal = old.encode()
            new_bytes_literal = new.encode()
            assert expected.count(old_bytes_literal) == 1
            assert expected.count(new_bytes_literal) == 0
            expected = expected.replace(old_bytes_literal, new_bytes_literal, 1)
            changes.append({'previous_import': old, 'current_import': new})
        assert expected == new_bytes, relative
        records.append({
            'path': relative,
            'previous_file_sha256': sha(old_path),
            'current_file_sha256': sha(new_path),
            'replacements': changes,
        })

    fingerprint_file = ROOT / FINGERPRINT_FILE
    fingerprint_source = fingerprint_file.read_text()
    assert '"crates/scriptw-aot-wasm/tests"' in fingerprint_source
    identity = mixed['current_compiler_source_identity']
    producer = mixed['current_producer']
    assert sha(producer['path']) == producer['sha256']

    result = {
        'schema': 'scriptw-performance-levers-format-only-test-qualification-v1',
        'complete': True,
        'measured_source_manifest_sha256': sha(MEASURED_MANIFEST),
        'measured_source_fingerprint': mixed['measured_source_fingerprint'],
        'previous_verification_manifest_sha256': sha(PREVIOUS_MANIFEST),
        'source_manifest_sha256': sha(CURRENT_MANIFEST),
        'previous_mixed_cfg_qualification': {
            'path': str(MIXED_QUALIFICATION.resolve()), 'sha256': sha(MIXED_QUALIFICATION)},
        'current_compiler_source_identity': identity,
        'current_product_producer': producer,
        'compiler_fingerprint_exclusion': {
            'path': FINGERPRINT_FILE,
            'sha256': sha(fingerprint_file),
            'excluded_external_test_directory': 'crates/scriptw-aot-wasm/tests',
        },
        'format_only_files': records,
        'binary_identity_comparison': 'not-claimed; no source7 product build was run',
        'qualification_scope': 'Source6 to source7 changes only import ordering in six external test files. The measured source1 cohort and source6 CLI identity remain separately pinned; no product binary identity is inferred and no tests are claimed as rerun by this receipt.',
    }
    output = args.output.resolve()
    assert output.is_relative_to(ROOT / 'target') and not output.exists()
    output.write_text(json.dumps(result, indent=2) + '\n')
    print(output)


if __name__ == '__main__':
    main()
