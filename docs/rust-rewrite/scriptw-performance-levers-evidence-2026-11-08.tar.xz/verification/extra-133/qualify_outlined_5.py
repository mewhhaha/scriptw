import json,subprocess,sys
from pathlib import Path
R=Path.cwd();B=R/'target/performance-levers-20261108';sys.path[:0]=[str(B/'tools'),str(R/'scripts')]
from common import check_source,validate_snapshot,digest,save
from measure_rsc import cargo_source_identity
from limited_verification import require_kernel_budget
require_kernel_budget(4*1024**3)
s0=B/'tools/source-outlined-1/manifest.json';s4=B/'tools/source-outlined-4/manifest.json';s1=B/'tools/source-outlined-5/manifest.json';old=validate_snapshot(s0);prior=validate_snapshot(s4);new=check_source(s1)
changed=[n for n in sorted(set(old['files'])|set(new['files'])) if old['files'].get(n)!=new['files'].get(n)]
internal='crates/scriptw-aot-wasm/src/tests/local_argument_calls.rs';assert len(changed)==15 and internal in changed
assert all(n==internal or n.startswith('crates/scriptw-aot-wasm/tests/') and n.endswith('.rs') for n in changed)
assert [n for n in sorted(set(prior['files'])|set(new['files'])) if prior['files'].get(n)!=new['files'].get(n)]==[internal]
def source_bytes(manifest,path):
 if path in manifest['files']:return (s0.parent/'files'/path).read_bytes()
 return subprocess.check_output(['git','show',manifest['base_git']+':'+path],cwd=R)
fp_path=R/'crates/scriptw-engine/compiler_fingerprint.rs';lib=R/'crates/scriptw-aot-wasm/src/lib.rs';tests=R/'crates/scriptw-aot-wasm/src/tests.rs'
assert '"crates/scriptw-aot-wasm/src/tests",' in fp_path.read_text()
assert '#[cfg(test)]\nmod tests;' in lib.read_text() and 'mod local_argument_calls;' in tests.read_text()
for p in [fp_path,lib,tests]:assert p.read_bytes()==source_bytes(old,str(p.relative_to(R)))
p0=B/'build-outlined-1.stdout';p1=B/'build-outlined-5.stdout';p4=B/'build-outlined-4.stdout'
rows=lambda p:[json.loads(l) for l in p.read_text().splitlines() if l.startswith('{')]
a0,a1,a4=rows(p0),rows(p1),rows(p4);assert [r['success'] for r in a1 if r.get('reason')=='build-finished']==[True]
artifact=lambda rows,n:next(r for r in rows if r.get('reason')=='compiler-artifact' and r['target']['name']==n and r.get('executable'))
assert cargo_source_identity(p0)==cargo_source_identity(p1)
unchanged=[]
for n in ['emission','structure_builtins','structure_language','structure_async','runtime_link','modules_realms','intl_temporal','structure','aot_builtins','aot_language','aot_async','aot_realm_modules','rsc_baseline','compiler_precompiled_baseline']:
 prev=artifact(a4,n);cur=artifact(a1,n);assert cur['fresh'] and {**prev,'fresh':None}=={**cur,'fresh':None}
 frozen=B/'frozen-outlined-1'/n
 if n in ['emission','structure_async']:frozen=B/'frozen-outlined-4'/n
 assert digest(cur['executable'])==digest(frozen);unchanged.append(dict(target=n,path=str(frozen),sha256=digest(frozen)))
n='rsc_baseline';test_evidence=dict(path=internal,fingerprint_exclusion=dict(path=str(fp_path.relative_to(R)),sha256=digest(fp_path),excluded_directory='crates/scriptw-aot-wasm/src/tests'),cfg_test_registration=dict(path=str(lib.relative_to(R)),sha256=digest(lib),pattern='#[cfg(test)]\nmod tests;'),test_module_registration=dict(path=str(tests.relative_to(R)),sha256=digest(tests),pattern='mod local_argument_calls;'),product_compiler_source_fingerprint=cargo_source_identity(p1)[0],product_binaries_identical=True)
reuse=dict(schema='scriptw-rsc-levers-qualified-candidate-reuse-v1',complete=True,allowed_changed_files=changed,previous_source=dict(path=str(s0),sha256=digest(s0)),current_source=dict(path=str(s1),sha256=digest(s1)),previous_producer=dict(path=str(p0),sha256=digest(p0)),current_producer=dict(path=str(p1),sha256=digest(p1)),binary=dict(path=str(B/'frozen-outlined-1'/n),sha256=digest(B/'frozen-outlined-1'/n)),previous_fresh=False,current_fresh=True,producer_inputs_identical=True,previous_artifact=artifact(a0,n),current_artifact=artifact(a1,n),test_only_evidence=test_evidence)
save(B/'test-only-reuse-outlined-5.json',reuse)
broad=B/'broad-complete/receipt.json';d=json.loads(broad.read_text());assert d['complete'] and d['passed']==2550 and d['source_manifest_sha256']==digest(s4)
save(B/'qualification-outlined-5.json',dict(complete=True,measured_source_manifest_sha256=digest(s0),previous_verification_manifest_sha256=digest(s4),source_manifest_sha256=digest(s1),qualified_reuse=dict(path=str(B/'test-only-reuse-outlined-5.json'),sha256=digest(B/'test-only-reuse-outlined-5.json')),unchanged_binaries=unchanged,retained_broad=dict(path=str(broad),sha256=digest(broad),passed=2550),test_only_evidence=test_evidence))
print('QUALIFIED CFG-TEST FIX; ALL FOURTEEN EXECUTABLES IDENTICAL',flush=True)
