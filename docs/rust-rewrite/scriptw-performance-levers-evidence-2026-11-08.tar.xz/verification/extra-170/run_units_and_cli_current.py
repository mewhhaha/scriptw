"""Fresh full AOT/Engine units, followed by a separate production-only CLI graph."""
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
BASE = Path(__file__).resolve().parent
sys.path[:0] = [str(BASE / 'tools'), str(ROOT / 'scripts')]
from common import check_source
from limited_verification import limited_environment, require_kernel_budget
from measure_rsc import resources, check_resources, cargo_source_identity
from native_test_protocol import parse_inventory, result_summaries

KNOWN_AOT_FAILURES = {
    'tests::bootstrap_compact_metadata::native_bootstrap_uses_complete_constructor_layouts_and_compact_remaining_native_metadata',
    'tests::error_demand_initialization::canonical_runtime_defers_the_complete_error_graph_with_a_void_realm_abi',
    'tests::intrinsic_property_layout_allocation::fresh_intrinsic_bootstrap_allocates_layout_records_not_per_property_records',
    'tests::ordered_bootstrap_allocation::eager_layout_births_keep_demand_recipe_and_constructor_allocation_owners',
}


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def cargo_rows(path):
    return [json.loads(line) for line in path.read_text().splitlines() if line.startswith('{')]


def main():
    require_kernel_budget(4 * 1024**3)
    assert len(os.sched_getaffinity(0)) == 1
    source = BASE / 'tools/source-outlined-5/manifest.json'
    check_source(source)
    output = BASE / 'units-and-cli-final'
    output.mkdir(exist_ok=False)
    (output / 'frozen').mkdir()
    report = {'complete': False, 'passed': False, 'source_manifest_sha256': sha(source),
              'known_aot_failures_remain_failures': sorted(KNOWN_AOT_FAILURES),
              'runner_sha256': sha(__file__), 'commands': [], 'unit_scopes': [],
              'resources_before': resources()}

    def save():
        (output / 'receipt.json').write_text(json.dumps(report, indent=2) + '\n')

    def run(name, argv, timeout=2400):
        check_source(source)
        assert sha(source) == report['source_manifest_sha256']
        assert sha(__file__) == report['runner_sha256']
        row = {'name': name, 'argv': argv, 'status': 'running', 'resources_before': resources()}
        report['commands'].append(row)
        save()
        print('START', name, flush=True)
        started = time.monotonic_ns()
        try:
            with (output / (name + '.stdout')).open('xb') as out, (output / (name + '.stderr')).open('xb') as err:
                child = subprocess.run(argv, cwd=ROOT, env=limited_environment(), stdin=subprocess.DEVNULL,
                                       stdout=out, stderr=err, timeout=timeout)
            row.update(exit_code=child.returncode, status='finished')
        except BaseException as error:
            row.update(status='failed', error=repr(error))
            raise
        finally:
            row['elapsed_ns'] = time.monotonic_ns() - started
            row['resources_after'] = resources()
            try:
                check_source(source)
                assert sha(source) == report['source_manifest_sha256']
                assert sha(__file__) == report['runner_sha256']
                check_resources(row['resources_before'], row['resources_after'])
            finally:
                for suffix in ('stdout', 'stderr'):
                    path = output / (name + '.' + suffix)
                    if path.exists():
                        row[suffix + '_sha256'] = sha(path)
                save()
        print('END', name, row['exit_code'], flush=True)
        return row

    def freeze(artifact, producer, name):
        original = Path(artifact['executable'])
        digest = sha(original)
        binary = output / 'frozen' / name
        shutil.copy2(original, binary)
        assert sha(binary) == digest == sha(original)
        receipt = {'artifact': artifact, 'sha256': digest, 'frozen_path': str(binary),
                   'source_manifest_sha256': sha(source), 'cargo_stdout': str(producer),
                   'cargo_stdout_sha256': sha(producer)}
        (binary.parent / (name + '-producer.json')).write_text(json.dumps(receipt, indent=2) + '\n')
        return binary, digest

    save()
    try:
        build = ['cargo', '--config', 'build.jobs=1', 'test', '--release', '--locked',
                 '-p', 'scriptw-aot-wasm', '-p', 'scriptw-engine', '--lib', '--no-run',
                 '--message-format=json-render-diagnostics']
        assert run('units-build', build)['exit_code'] == 0
        producer = output / 'units-build.stdout'
        rows = cargo_rows(producer)
        assert any(row.get('reason') == 'build-finished' and row['success'] for row in rows)
        for target in ('scriptw_aot_wasm', 'scriptw_engine'):
            matches = [row for row in rows if row.get('reason') == 'compiler-artifact'
                       and row['target']['name'] == target and row['profile']['test'] and row.get('executable')]
            assert len(matches) == 1
            artifact = matches[0]
            expected_features = []
            if target == 'scriptw_engine':
                expected_features = ['default', 'native-source-compiler']
            assert artifact['target']['kind'] == ['lib'] and artifact['features'] == expected_features
            assert artifact['profile']['opt_level'] == '3'
            binary, digest = freeze(artifact, producer, target)
            listed = run(target + '-list', [str(binary), '--list'], timeout=60)
            assert listed['exit_code'] == 0
            inventory = parse_inventory((output / (target + '-list.stdout')).read_text())
            command = run(target, [str(binary), '--test-threads=1'])
            stdout = (output / (target + '.stdout')).read_text()
            summaries = result_summaries(stdout)
            assert len(summaries) == 1
            status, passed, failed, ignored, measured, filtered = summaries[0]
            failures = set(re.findall(r'^test (.+) \.\.\. FAILED$', stdout, re.M))
            executed = [name.removesuffix(' - should panic') for name in
                        re.findall(r'^test (.+) \.\.\. (?:ok|FAILED|ignored)$', stdout, re.M)]
            scope = {'target': target, 'binary_sha256': digest, 'inventory': len(inventory),
                     'inventory_sha256': listed['stdout_sha256'], 'summary': summaries[0],
                     'failures': sorted(failures), 'exit_code': command['exit_code']}
            report['unit_scopes'].append(scope)
            save()
            assert int(passed) + int(failed) + int(ignored) == len(inventory)
            assert len(executed) == len(inventory) and set(executed) == set(inventory)
            assert ignored == measured == filtered == '0'
            assert sha(binary) == digest
            if target == 'scriptw_aot_wasm':
                assert command['exit_code'] == 101 and status == 'FAILED' and failed == '4'
                assert failures == KNOWN_AOT_FAILURES
                scope['ordinary_failures_retained'] = True
            else:
                assert command['exit_code'] == 0 and status == 'ok' and failed == '0' and not failures
            save()

        # Keep ordinary product dependency features separate from every example/test build.
        build = ['cargo', '--config', 'build.jobs=1', 'build', '--release', '--locked',
                 '-p', 'scriptw-cli', '--bin', 'scriptw', '--message-format=json-render-diagnostics']
        assert run('production-cli-build', build)['exit_code'] == 0
        producer = output / 'production-cli-build.stdout'
        rows = cargo_rows(producer)
        assert any(row.get('reason') == 'build-finished' and row['success'] for row in rows)
        matches = [row for row in rows if row.get('reason') == 'compiler-artifact'
                   and row['target']['name'] == 'scriptw' and row.get('executable')]
        assert len(matches) == 1
        artifact = matches[0]
        assert artifact['target']['kind'] == ['bin'] and artifact['features'] == []
        assert artifact['profile']['opt_level'] == '3' and not artifact['profile']['test']
        engine = [row for row in rows if row.get('reason') == 'compiler-artifact' and row['target']['name'] == 'scriptw_engine']
        assert len(engine) == 1 and engine[0]['features'] == ['default', 'native-source-compiler']
        assert not any('boa_engine' in row.get('package_id', '') for row in rows)
        binary, digest = freeze(artifact, producer, 'scriptw')
        identity = run('production-cli-identity', [str(binary), 'compiler-identity'], timeout=60)
        assert identity['exit_code'] == 0
        compiler = json.loads((output / 'production-cli-identity.stdout').read_text())
        assert compiler['source_fingerprint'] == cargo_source_identity(BASE / 'build-outlined-1.stdout')[0]
        assert compiler['executable_sha256'] == digest
        contract = (ROOT / 'crates/scriptw-cli/tests/product_artifact_execution.rs').read_text()
        completion = json.loads(re.search(r'const WASM_COMPLETION: &str = (".*");', contract)[1])
        fixtures = ROOT / 'crates/scriptw-cli/tests/fixtures'
        smoke = run('production-default-hello', [str(binary), 'run', str(fixtures / 'hello.js')], timeout=180)
        assert smoke['exit_code'] == 0
        assert (output / 'production-default-hello.stdout').read_text() == 'grug\n' + completion
        for fixture in ('wasm_ordinary_set_outlined_receiver', 'wasm_proxy_reflect_set_handler_protocol',
                        'wasm_proxy_get_direct_descriptor_invariants', 'wasm_object_prevent_extensions_missing_writes',
                        'wasm_boxed_builtins', 'wasm_for_in_prototype_order', 'wasm_for_in_array_define_property_order'):
            command = run(fixture, [str(binary), 'run', '--execution-backend', 'wasm',
                          '--host-surface', 'test262', str(fixtures / (fixture + '.js'))], timeout=180)
            assert command['exit_code'] == 0
            assert (output / (fixture + '.stdout')).read_text() == completion.replace('undefined(undefined)', 'boolean(true)')
            assert sha(binary) == digest
        report.update(complete=True, passed=False, ordinary_aot_failures=4,
                      cli_smoke_passed=True, limits='Complete unit inventories retain four ordinary failing AOT assertions; no expected-pass conversion. Engine units and production CLI smoke must pass. No full Test262 claim.')
    except BaseException as error:
        report['error'] = repr(error)
        raise
    finally:
        report['resources_after'] = resources()
        try:
            check_source(source)
            check_resources(report['resources_before'], report['resources_after'])
        except BaseException as error:
            report.update(complete=False, terminal_verification_error=repr(error))
            raise
        finally:
            save()
    print('UNITS QUALIFIED WITH FOUR AOT FAILURES; PRODUCTION CLI SMOKE PASSED', output, flush=True)


if __name__ == '__main__':
    main()
