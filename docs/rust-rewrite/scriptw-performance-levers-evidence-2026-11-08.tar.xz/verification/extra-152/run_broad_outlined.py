"""Run the built backend and runtime scopes serially with exact inventories."""
import hashlib,json,subprocess,sys,time
from pathlib import Path
ROOT=Path.cwd();BASE=ROOT/'target/performance-levers-20261108';sys.path[:0]=[str(ROOT/'scripts'),str(BASE/'tools')]
from common import check_source
from native_test_protocol import parse_inventory,result_summaries
from limited_verification import kernel_group,require_kernel_budget
require_kernel_budget(4*1024**3)
manifest=BASE/'tools/source-outlined-1/manifest.json';check_source(manifest)
sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
output=BASE/'broad';output.mkdir(exist_ok=False)
targets=['emission','structure_builtins','structure_language','structure_async','runtime_link','modules_realms','intl_temporal','structure','aot_builtins','aot_language','aot_async','aot_realm_modules']
report={'schema':'scriptw-property-kernel-native-verification-v1','complete':False,'source_manifest_sha256':sha(manifest),'targets':[],'resources_before':{n:(kernel_group()/n).read_text() for n in ['memory.max','memory.swap.max','memory.oom.group','cpu.max','memory.events']}}
def save():(output/'receipt.json').write_text(json.dumps(report,indent=2)+'\n')
save()
for target in targets:
 check_source(manifest);binary=BASE/'frozen-outlined-1'/target
 digest=sha(binary);listed=subprocess.run([str(binary),'--list'],cwd=ROOT,capture_output=True,text=True,timeout=60);assert listed.returncode==0
 (output/(target+'.list')).write_text(listed.stdout);inventory=parse_inventory(listed.stdout)
 print('START',target,len(inventory),flush=True);started=time.monotonic_ns()
 argv=[str(binary),'--test-threads=1']
 with (output/(target+'.stdout')).open('xb') as out,(output/(target+'.stderr')).open('xb') as err:
  child=subprocess.run(argv,cwd=ROOT,stdout=out,stderr=err,timeout=2400)
 summaries=result_summaries((output/(target+'.stdout')).read_text());assert len(summaries)==1
 status,passed,failed,ignored,measured,filtered=summaries[0];assert int(passed)+int(failed)+int(ignored)==len(inventory) and measured==filtered=='0'
 row={'target':target,'argv':argv,'binary_sha256':digest,'inventory':len(inventory),'inventory_sha256':sha(output/(target+'.list')),'exit_code':child.returncode,'summary':summaries[0],'elapsed_ns':time.monotonic_ns()-started,'stdout_sha256':sha(output/(target+'.stdout')),'stderr_sha256':sha(output/(target+'.stderr'))}
 report['targets'].append(row);save();assert sha(binary)==digest
 print('END',target,summaries[0],flush=True)
 assert child.returncode==0 and status=='ok' and failed==ignored=='0',target
 check_source(manifest)
report['resources_after']={n:(kernel_group()/n).read_text() for n in report['resources_before']}
def events(x):return dict(line.split() for line in x.splitlines())
assert all(events(report['resources_before']['memory.events']).get(k)==events(report['resources_after']['memory.events']).get(k) for k in ['oom','oom_kill','oom_group_kill'])
report['passed']=sum(int(r['summary'][1]) for r in report['targets']);report['complete']=True;save();print('BROAD COMPLETE',report['passed'],flush=True)
