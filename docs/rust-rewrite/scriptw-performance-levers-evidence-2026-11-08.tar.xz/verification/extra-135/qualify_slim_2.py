import hashlib,json,subprocess,sys
from pathlib import Path
R=Path.cwd();B=R/'target/performance-levers-20261108';sys.path[:0]=[str(B/'tools'),str(R/'scripts')]
from common import check_source,validate_snapshot
from native_test_protocol import result_summaries
from limited_verification import require_kernel_budget
require_kernel_budget(4*1024**3)
sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
s0=B/'tools/source-slim-1/manifest.json';s1=B/'tools/source-slim-2/manifest.json';old=validate_snapshot(s0);new=check_source(s1)
changed=[n for n in sorted(set(old['files'])|set(new['files'])) if old['files'].get(n)!=new['files'].get(n)]
assert changed==['crates/scriptw-aot-wasm/tests/emission/property_read_plans.rs'],changed
p0=B/'build-slim-1.stdout';p1=B/'build-slim-2.stdout'
rows=lambda p:[json.loads(l) for l in p.read_text().splitlines() if l.startswith('{')]
a0=rows(p0);a1=rows(p1);assert [r['success'] for r in a1 if r.get('reason')=='build-finished']==[True]
artifact=lambda rows,n:next(r for r in rows if r.get('reason')=='compiler-artifact' and r['target']['name']==n and r.get('executable'))
out=B/'frozen-slim-2';out.mkdir(exist_ok=False)
for n in ['emission','structure_builtins','structure_language','structure_async','runtime_link','modules_realms','intl_temporal','structure','aot_builtins','aot_language','aot_async','aot_realm_modules','rsc_baseline','compiler_precompiled_baseline']:
 prev=artifact(a0,n);cur=artifact(a1,n)
 if n!='emission':
  assert cur['fresh'] and {**prev,'fresh':None}=={**cur,'fresh':None},n
  assert sha(cur['executable'])==sha(B/'frozen-slim-1'/n),n
 else:
  binary=out/n;subprocess.run(['cp','--reflink=auto',cur['executable'],str(binary)],check=True)
  assert sha(binary)==sha(cur['executable'])
  (out/(n+'-producer.json')).write_text(json.dumps(dict(artifact=cur,sha256=sha(binary),source_manifest_sha256=sha(s1),cargo_stdout=str(p1),cargo_stdout_sha256=sha(p1),frozen_path=str(binary)),indent=2)+'\n')
n='rsc_baseline';reuse=dict(schema='scriptw-rsc-levers-qualified-candidate-reuse-v1',complete=True,allowed_changed_files=changed,previous_source=dict(path=str(s0),sha256=sha(s0)),current_source=dict(path=str(s1),sha256=sha(s1)),previous_producer=dict(path=str(p0),sha256=sha(p0)),current_producer=dict(path=str(p1),sha256=sha(p1)),binary=dict(path=str(B/'frozen-slim-1'/n),sha256=sha(B/'frozen-slim-1'/n)),previous_fresh=False,current_fresh=True,producer_inputs_identical=True,previous_artifact=artifact(a0,n),current_artifact=artifact(a1,n))
(B/'candidate-reuse-slim-2.json').write_text(json.dumps(reuse,indent=2)+'\n')
focus=B/'focused-slim-2';focus.mkdir(exist_ok=False)
prior_path=B/'focused-slim-1/receipt.json';prior=json.loads(prior_path.read_text());runtime=prior['runs'][:4]
assert len(runtime)==4 and all(r['target']=='aot_language' and r['exit_code']==0 and r['summary'][0]=='ok' for r in runtime)
assert sum(int(r['summary'][1]) for r in runtime)==24
receipt=dict(complete=False,source_manifest_sha256=sha(s1),qualified_reuse=dict(path=str(B/'candidate-reuse-slim-2.json'),sha256=sha(B/'candidate-reuse-slim-2.json')),preserved=dict(path=str(prior_path),sha256=sha(prior_path),scopes=[r['filter'] for r in runtime],passed=24),runs=[])
def save():(focus/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
save()
for name in ['binding_cell_payload','captured_call_regions','property_read_plans','numeric_body','arguments_elision','has_instance_helper','strict_arguments_projection']:
 argv=[str(out/'emission'),name+'::','--test-threads=1']
 with (focus/(name+'.stdout')).open('wb') as o,(focus/(name+'.stderr')).open('wb') as e:child=subprocess.run(argv,stdout=o,stderr=e,timeout=600)
 summaries=result_summaries((focus/(name+'.stdout')).read_text());assert len(summaries)==1
 row=dict(filter=name+'::',argv=argv,exit_code=child.returncode,summary=summaries[0],binary_sha256=sha(out/'emission'),stdout_sha256=sha(focus/(name+'.stdout')),stderr_sha256=sha(focus/(name+'.stderr')));receipt['runs'].append(row);save();print(name,summaries[0],flush=True)
 status,passed,failed,ignored,measured,filtered=summaries[0];assert child.returncode==0 and status=='ok' and int(passed)>0 and failed==ignored==measured=='0'
 check_source(s1)
receipt.update(complete=True,runtime_passed=24,emission_passed=sum(int(r['summary'][1]) for r in receipt['runs']));receipt['passed']=receipt['runtime_passed']+receipt['emission_passed'];assert receipt['passed']==33;save();print('QUALIFIED',receipt['passed'],flush=True)
