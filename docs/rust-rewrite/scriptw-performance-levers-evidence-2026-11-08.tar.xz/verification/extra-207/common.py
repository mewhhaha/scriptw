"""Freeze and validate the complete dirty 2026-11-08 source batch."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[3]
PINNED_HEAD = "7b98415010501ab7c8f78dbf81661c06a9cb20bf"
BASE_RUNTIME_ABI = 52
RUNTIME_ABI = 53
ABI_CHANGE = "ABI 53 admits direct BindingCell payload fields and wide-entry layout changes in this batch."
TARGET = ROOT / "target/performance-levers-20261108/tools"
PUBLIC_REPORT = ROOT / "docs/rust-rewrite/rsc-current.json"


def digest(path):
    value = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def save(path, value):
    path = Path(path)
    temporary = path.with_name(path.name + ".writing")
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")
    temporary.replace(path)


def git(*args):
    return subprocess.check_output(["git", *args], cwd=ROOT)


def changed_paths():
    tracked = git("diff", "--name-only", "-z", "HEAD").decode().split("\0")
    untracked = git("ls-files", "--others", "--exclude-standard", "-z").decode().split("\0")
    return sorted(path for path in tracked if path), sorted(path for path in untracked if path)


def source_inputs():
    tracked, untracked = changed_paths()
    rows = {}
    deleted = []
    all_paths = [(name, "tracked") for name in tracked] + [(name, "untracked") for name in untracked]
    for relative, origin in all_paths:
        path = ROOT / relative
        if not path.exists():
            assert origin == "tracked", f"untracked source disappeared: {relative}"
            deleted.append(relative)
            continue
        assert path.is_file() and not path.is_symlink(), f"source input is not a regular file: {relative}"
        rows[relative] = {"origin": origin, "sha256": digest(path), "bytes": path.stat().st_size}
    return tracked, untracked, deleted, rows


def pinned_public_identity(raw_bytes):
    public = json.loads(raw_bytes)
    assert public["schema"] == "scriptw-rsc-current-v1"
    identity = public["engines"]["candidate"]["identity"]
    assert identity["source_fingerprint"].startswith("5aa48ad8")
    assert public["source_identity"]["runtime_abi"] == BASE_RUNTIME_ABI
    return identity


def make_manifest(output):
    head = git("rev-parse", "HEAD").decode().strip()
    assert head == PINNED_HEAD, f"unexpected source base {head}"
    tracked, untracked, deleted, files = source_inputs()
    assert tracked or untracked, "the intended product batch must be captured before build"
    patch = git("diff", "--binary", "HEAD")
    baseline_public = git("show", PINNED_HEAD + ":docs/rust-rewrite/rsc-current.json")
    baseline_identity = pinned_public_identity(baseline_public)
    output = Path(output).resolve()
    assert output.is_relative_to(TARGET) and not output.exists(), (
        "source snapshot output must be new and under the isolated tools directory"
    )
    output.mkdir(parents=True)
    (output / "files").mkdir()
    (output / "baseline").mkdir()
    (output / "tracked.patch").write_bytes(patch)
    for relative in files:
        destination = output / "files" / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes((ROOT / relative).read_bytes())
    (output / "baseline/rsc-current.json").write_bytes(baseline_public)
    manifest = {
        "schema": "scriptw-rsc-levers-source-v1",
        "created_at": datetime.now(timezone.utc).isoformat(),
        "base_git": head,
        "base_runtime_abi": BASE_RUNTIME_ABI,
        "runtime_abi": RUNTIME_ABI,
        "abi_change": ABI_CHANGE,
        "tracked_patch_sha256": digest(output / "tracked.patch"),
        "tracked_files": tracked,
        "untracked_files": untracked,
        "deleted_files": deleted,
        "files": files,
        "published_rsc_current_sha256": digest(output / "baseline/rsc-current.json"),
        "baseline_identity": baseline_identity,
    }
    save(output / "manifest.json", manifest)
    check_source(output / "manifest.json")
    return output / "manifest.json"


def check_source(manifest_path):
    manifest_path = Path(manifest_path).resolve(strict=True)
    manifest = validate_snapshot(manifest_path)
    assert manifest["base_git"] == PINNED_HEAD
    assert git("rev-parse", "HEAD").decode().strip() == PINNED_HEAD
    assert git("diff", "--binary", "HEAD") == (manifest_path.parent / "tracked.patch").read_bytes()
    tracked, untracked = changed_paths()
    assert tracked == manifest["tracked_files"]
    assert untracked == manifest["untracked_files"]
    for relative, record in manifest["files"].items():
        path = ROOT / relative
        assert path.is_file() and not path.is_symlink(), f"source input is missing or changed kind: {relative}"
        assert digest(path) == record["sha256"], f"source input changed: {relative}"
        assert path.stat().st_size == record["bytes"], f"source input size changed: {relative}"
        assert digest(manifest_path.parent / "files" / relative) == record["sha256"]
    for relative in manifest["deleted_files"]:
        assert not (ROOT / relative).exists(), f"deleted source file reappeared: {relative}"
    public = git("show", PINNED_HEAD + ":docs/rust-rewrite/rsc-current.json")
    assert hashlib.sha256(public).hexdigest() == manifest["published_rsc_current_sha256"]
    assert digest(manifest_path.parent / "baseline/rsc-current.json") == manifest["published_rsc_current_sha256"]
    assert pinned_public_identity(public) == manifest["baseline_identity"]
    return manifest


def validate_snapshot(manifest_path):
    """Validate a saved snapshot without comparing it to live checkout files."""
    manifest_path = Path(manifest_path).resolve(strict=True)
    manifest = read(manifest_path)
    assert manifest["schema"] == "scriptw-rsc-levers-source-v1"
    assert manifest["base_git"] == PINNED_HEAD
    assert manifest["base_runtime_abi"] == BASE_RUNTIME_ABI
    assert manifest["runtime_abi"] == RUNTIME_ABI and manifest["abi_change"] == ABI_CHANGE
    tracked = manifest["tracked_files"]
    untracked = manifest["untracked_files"]
    deleted = manifest["deleted_files"]
    files = manifest["files"]
    assert tracked == sorted(set(tracked)) and untracked == sorted(set(untracked))
    assert not set(tracked) & set(untracked)
    assert set(tracked) | set(untracked) == set(files) | set(deleted)
    assert not set(files) & set(deleted)
    patch = manifest_path.parent / "tracked.patch"
    assert digest(patch) == manifest["tracked_patch_sha256"]
    for relative, record in files.items():
        name = Path(relative)
        assert not name.is_absolute() and ".." not in name.parts and relative == name.as_posix()
        frozen = manifest_path.parent / "files" / relative
        assert frozen.is_file() and not frozen.is_symlink()
        assert digest(frozen) == record["sha256"] and frozen.stat().st_size == record["bytes"]
        expected_origin = "untracked" if relative in untracked else "tracked"
        assert record["origin"] == expected_origin
    for relative in deleted:
        assert not (manifest_path.parent / "files" / relative).exists()
    public = manifest_path.parent / "baseline/rsc-current.json"
    assert digest(public) == manifest["published_rsc_current_sha256"]
    assert pinned_public_identity(public.read_bytes()) == manifest["baseline_identity"]
    return manifest
