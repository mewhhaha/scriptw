set pagination off
set confirm off
set breakpoint pending off
break _RNvMNtNtCs2hMLkaS3iul_8wasmtime7compile12code_builderNtB2_11CodeBuilder19wasm_binary_or_text
commands
silent
python
import gdb, hashlib, pathlib, json
length=int(gdb.parse_and_eval('$rdx'))
address=int(gdb.parse_and_eval('$rsi'))
print('wasm-input bytes='+str(length),flush=True)
if length != 7653675:
    raise gdb.GdbError('Unexpected first Wasmtime input length; refusing native compile')
blob=bytes(gdb.selected_inferior().read_memory(address,length))
digest=hashlib.sha256(blob).hexdigest()
if digest != 'a19779bb0a6df8782d895c346c1b9e3e1e1e9ffbab48222d5f59257a9daa140d':
    raise gdb.GdbError('Input does not match measured P: '+digest)
out=pathlib.Path('/home/jacobt/src/scriptw/target/rsc-wasm-size-20261103')
(out/'program.wasm').write_bytes(blob)
(out/'capture.json').write_text(json.dumps(dict(bytes=length,sha256=digest,stop='CodeBuilder::wasm_binary_or_text entry before native compilation'),indent=2)+'\n')
print('Exact measured program captured before native compilation',flush=True)
end
quit
end
run
