"""Read exact retained P bytes; no emission or native compilation."""
from pathlib import Path
from collections import defaultdict
import hashlib
import json
import re
import struct

OUT = Path(__file__).resolve().parent
blob = (OUT / "program.wasm").read_bytes()
assert blob[:8] == b"\0asm\1\0\0\0"


def uleb(position):
    value = shift = 0
    while True:
        byte = blob[position]
        position += 1
        value |= (byte & 127) << shift
        shift += 7
        if byte < 128:
            return value, position


sections = []
segments = []
bodies = []
position = 8
while position < len(blob):
    start = position
    kind = blob[position]
    size, position = uleb(position + 1)
    end = position + size
    row = dict(id=kind, start=start, payload_start=position,
               payload_bytes=size, total_bytes=end - start)
    if kind == 0:
        length, cursor = uleb(position)
        row["name"] = blob[cursor:cursor + length].decode()
        row["data_bytes"] = end - cursor - length
    if kind == 10:
        count, cursor = uleb(position)
        for ordinal in range(count):
            length, cursor = uleb(cursor)
            bodies.append(dict(ordinal=ordinal, start=cursor,
                               end=cursor + length, bytes=length))
            cursor += length
        assert cursor == end
    if kind == 11:
        count, cursor = uleb(position)
        for ordinal in range(count):
            flag, cursor = uleb(cursor)
            assert flag == 1, "P owns passive data only"
            length, cursor = uleb(cursor)
            segments.append(blob[cursor:cursor + length])
            cursor += length
        assert cursor == end
    sections.append(row)
    position = end

strings = []
for index, offset, units in struct.iter_unpack("<III", segments[2]):
    text = segments[0][offset:offset + units * 2].decode("utf-16-le", "surrogatepass")
    strings.append(dict(index=index, offset=offset, bytes=units * 2, text=text))
strings.sort(key=lambda row: row["offset"])
encoded = b"".join(row["text"].encode("utf-8", "surrogatepass") for row in strings)
assert segments[1].startswith(encoded)
assert sum(row["bytes"] for row in strings) == len(segments[0])

functions = []
pattern = re.compile(r"emitted function: index=(\d+) bytes=(\d+) locals=(\d+) kind=(\S+) name=(.+)")
for line in (OUT / "functions.txt").read_text().splitlines():
    index, size, locals_count, category, name = pattern.fullmatch(line).groups()
    functions.append(dict(index=int(index), bytes=int(size), locals=int(locals_count),
                          kind=category, name=name))
ordered = sorted(functions, key=lambda row: row["index"])
assert len(ordered) == len(bodies)
for function, body in zip(ordered, bodies):
    assert function["bytes"] == body["bytes"]
    function.update(body)
categories = defaultdict(lambda: dict(functions=0, body_bytes=0))
for row in functions:
    categories[row["kind"]]["functions"] += 1
    categories[row["kind"]]["body_bytes"] += row["bytes"]

named = []
for function in functions:
    match = re.fullmatch(r"js::([^#]+)#f\d+", function["name"])
    if not match:
        continue
    candidates = [row for row in strings if row["text"].startswith("function " + match[1] + "(")]
    if len(candidates) == 1:
        row = candidates[0]
        source_bytes = len(row["text"].encode())
        named.append(dict(function=function["name"], wasm_body_bytes=function["bytes"],
                          source_utf8_bytes=source_bytes, pool_string_index=row["index"],
                          wasm_source_ratio=function["bytes"] / source_bytes))

# A static redundancy diagnostic only, not an implementation or size prediction.
# Exact substring containment can preserve every original descriptor's contents.
maximal = []
contained = []
for row in sorted(strings, key=lambda row: row["bytes"], reverse=True):
    owner = next((candidate for candidate in maximal if row["text"] in candidate["text"]), None)
    if owner is None:
        maximal.append(row)
    else:
        contained.append(dict(index=row["index"], owner=owner["index"], bytes=row["bytes"]))

roles = ["pooled UTF-16", "metadata including byte-oriented string image",
         "literal descriptors", "compact array recipes"]
top_strings = []
for row in sorted(strings, key=lambda row: row["bytes"], reverse=True)[:12]:
    top_strings.append({key: value for key, value in row.items() if key != "text"}
                       | dict(prefix=row["text"][:140]))
report = dict(
    schema="scriptw-rsc-size-diagnostic-v1",
    program_bytes=len(blob), program_sha256=hashlib.sha256(blob).hexdigest(),
    measured_inputs=json.loads((OUT / "measured-input.json").read_text()),
    sections=sections, defined_functions=len(functions),
    imported_functions=min(row["index"] for row in functions),
    body_bytes=sum(row["bytes"] for row in functions), categories=dict(categories),
    data_segments=[dict(index=index, bytes=len(segment), role=roles[index])
                   for index, segment in enumerate(segments)],
    string_pool=dict(count=len(strings), utf16_bytes=len(segments[0]),
                     utf8_wtf8_bytes=len(encoded),
                     other_metadata_bytes=len(segments[1]) - len(encoded),
                     top_strings=top_strings,
                     exact_substring_redundancy=dict(
                         retained_strings=len(maximal), contained_strings=len(contained),
                         maximal_utf16_bytes=sum(row["bytes"] for row in maximal),
                         contained_utf16_bytes=sum(row["bytes"] for row in contained),
                         caveat="Static exact containment only; no compiler change or compressed size claim.")),
    largest_functions=functions[:25], named_function_source_ratios=named[:20],
    limits="Static encoded bytes and source spans only; not runtime time shares, reachability proof, or removable-byte guarantees. Exact measured P captured before native compilation.")
(OUT / "attribution.json").write_text(json.dumps(report, indent=2) + "\n")
(OUT / "functions.json").write_text(json.dumps(functions, indent=2) + "\n")
print(json.dumps({key: report[key] for key in ("program_bytes", "body_bytes", "categories")}, indent=2))
print(json.dumps(report["string_pool"]["exact_substring_redundancy"], indent=2))
