# Future idle inert-runtime audit

`inspect-runtime-code.py` is source-only and unexecuted. No product, identity,
ELF or image was opened/hashed during preparation. No extractor, objdump, native,
Wasm, Node, build or live-profile command ran.

After root authorizes the idle audit and freezes/prepares the candidate:

    python3 -B scripts/limited_verification.py --cloud -- python3 -B target/performance-append-key-lazy-summary-20261031/inspect-runtime-code.py --candidate-fingerprint EXACT_FROZEN_LAZY_FINGERPRINT

The explicit fingerprint must differ from accepted Date and sealed v1. The
driver binds the candidate to accepted parent a9d31bddb and the18-input snapshot,
and records manifest/patch hashes. Baseline remains the actual a35 Date producer
from7c47e38274/ABI42; candidate must have ABI44. Root owns full source/build-input
verification and any test-only continuation proof.

The existing bounded own-host extractor verifies frozen host hashes before/after,
metadata agreement, execution receipt, source fingerprint, packed framing,
decompressed native length/SHA and ELF extents/symbols. No image is loaded.
Actual native bytes, `.text`, fixed push1/2/3, general push, property append,
native constructor allocator and resolver symbol sizes retain the APP report
schema. Push1/append entry reads and objdump captures are bounded to256 bytes per
side; missing frame patterns remain unknown. No frame equality is assumed.

Outputs are `runtime-code-size.json` and private `code-size-private/{baseline,
candidate}`. Existing output directories cause refusal rather than overwrite.
Extracted ELF/native products must remain excluded from the archive by suffix,
magic and regular-file policy. There is no executed-code, residency, RSS,
causal-timing or GC-byte claim.

`inert-audit-plan.json` and `inert-audit-draft.json` describe this prepared source.
The current measurement harness still matches its previous source-only receipt;
both isolated cache namespaces point to LAZY/normal-cache. No cache filesystem
or child policy was queried during this sanity check.
