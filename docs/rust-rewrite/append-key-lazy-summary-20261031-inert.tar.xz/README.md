# Separate candidate: lazy dictionary append-key summary

The ABI43 / fingerprint6610 candidate is rejected in `../performance-append-key-summary-20261031/decision.json`. Seal its exact source, products and all cohorts before replacement. This source-only plan defines a distinct ABI44 experiment against the accepted Date/a35 baseline. No tracked source was changed and no native/Node command was run by this reviewer.

## Why this is worth a bounded experiment

The rejected candidate classifies every newly inserted key of a still-clear dictionary, including bootstrap/native constructor keys in objects never used as prototypes by packed push. Unknown state can defer those String-tag/unit reads until an actual push asks for an absence proof, without exempting static keys or weakening mutation handling. An untouched Object.prototype has ten method rows plus __proto__ and constructor, twelve keys under current installation source, so its first query fits a general 64-slot bound. The scan touches raw key records only and does not materialize method recipes.

This is an allocation/CPU scheduling hypothesis, not a proven cause of the rejected regressions. New insertion still reads/tests one state field. The bounded scan adds R code and GC-root locals in four emitted push bodies. Retained singleton has no push and little or no named insertion in its warm loop; this revision does not directly explain its repeated slowdown. Require new measurements including that control. Do not attach the rejected candidate's target gains or passing tests to this source as fresh acceptance.

## Closed state and invariant

Replace the bool field with `INDEXED_KEY_SUMMARY: OrdinaryIndexedKeySummary` at the same ordinal3. Define the domain using existing runtime_scalar_domain! in heap.rs, register storage through closed_scalar_storage! in gc_types/layouts.rs, and register encoding through the existing word_i32_codec! in gc_types/value.rs. This makes .word() the single encoding authority; declaration alone does not implement GcI32Constant. The existing GcI32DomainLocal APIs new/set_constant/load/operand/store_domain/clear then apply unchanged:

| State | Word | Meaning |
|---|---:|---|
| Unknown | 0 | No absence proof; live keys may include anything. |
| NoIndexed | 1 | No current live String key begins ASCII 0–9; all later new keys must preserve or invalidate this proof. |
| MayIndexed | 2 | Conservative unknown/positive; always use original descriptor fallback. Sticky. |

Only exact NoIndexed admits the skip. Remove the old bool Eqz interpretation; Unknown=0 is deliberately unsafe for bypass. Use GcI32DomainLocal/typed constants and exact equality rather than unrelated truthiness. Rename the schema field to make stale bool consumers fail to compile. No new Wasm storage mode, helper/export, global or GC edge is needed. ABI44 is mandatory despite the unchanged i32 layout: ABI43 images encode different state meaning. Accepted baseline remains ABI42.

All three production dictionary constructors and the schema witness initialize Unknown. Compact promotion inserts every key through the existing seam while Unknown, then publishes its dictionary normally. Unknown is not an invalid transitional state: it may remain forever for a dictionary never queried by packed push. Empty dictionary construction is not a speculative NoIndexed exception.

At emit_ordinary_insert_in_dictionary, retain exactly one insertion owner. Only state NoIndexed runs the existing canonical String/nonempty/unsigned(first-unit-48)<=9 classifier. A digit-leading new key changes state to MayIndexed BEFORE publishing the PropertyTable entry. Unknown and MayIndexed skip all key-tag/String/unit work. Every dynamic or static key obeys this same runtime rule. Replacements do not change immutable keys. Deletion, rejected definitions, growth and compaction never reset state. NoIndexed survives deletion; MayIndexed remains conservative forever; Unknown remains unknown until queried.

Note the revised invariant is about current live keys, not keys ever historically inserted: an Unknown dictionary may have had an indexed key deleted before its first scan and may then legitimately become NoIndexed. This distinction must appear in documentation and history tests.

## First-query scan at the existing guard

Keep concrete receiver/prototype and Array COUNT/depth/proxy/exotic checks unchanged. Only a currently admitted ordinary prototype whose current PROPERTIES is OrdinaryPropertyStorage can query this state.

- NoIndexed: accept this prototype level immediately.
- MayIndexed: keep the original IntegerDecimalString/OrdinaryOwnDescriptor loop.
- Unknown: read physical LENGTH. If LENGTH >64 unsigned, write MayIndexed and fall back without reading any entry. Never scan an unbounded backing capacity or use a live-count bound while walking arbitrarily many tombstones.
- Unknown with LENGTH<=64: read ENTRIES and inspect exactly positions0..LENGTH. Null entries are tombstones and are skipped. For each live entry, read immutable PropertyEntry.KEY (nonnull StoredValue), then its tag/reference, and only for nonempty String keys read UTF16 unit0. Symbols skip the String cast. A digit-leading key selects MayIndexed; otherwise exhaustion selects NoIndexed. At most64 physical entries and64 first code units are inspected.
- Publish the selected state only after the completed scan/early positive selection. Then clear table/entry/key/text/unit roots and branch from the resulting exact state into the existing per-level skip or old descriptor loop. Both converge into the current header.PROTOTYPE load and existing bounded walk.

Use a private Rust emitter in objects/property_storage.rs if useful, callable by objects/packed_array_builtin.rs; this is emission factoring, not a new runtime helper. The classifier may share one primitive emission predicate with insertion. Prefer a private typed &GcLocal<StringValue> -> I32Local emitter for nonempty/first-unit ASCII-digit testing; insertion and scan each retain the String-tag guard before casting. It allocates only emitter locals, clears its CodeUnitArray root and returns a scalar result. A ValueLocals-based private predicate is also safe only if it itself performs the String guard before any cast and is used solely at these canonical-key owners; do not expose unchecked String authority. It must not manufacture arbitrary PropertyKeyLocals: scan keys already have canonical StoredValue provenance from PropertyEntry, and existing StoredValue::read_into is allocation-free if ValueLocals are reused. Do not read/resolve descriptors or property values, hash or coerce names, invoke a getter, allocate a GC record, call a runtime helper or promote compact storage during scan.

All scan roots are current invocation locals. Avoid jumping out of inner frames before clearing per-entry roots; set the selected state/flag, clear roots, then take the bounded-loop exit. No callback or allocation occurs between scan and cached-state publication, nor between NoIndexed admission and canonical append. Every later insertion into NoIndexed invalidates before publication, and every later push reads current storage/prototypes after callee/argument effects. Prototype replacement needs no watcher. Ordinary GC moving objects preserves the field with its actual record.

## Exact source/test owners

Root production: objects/property_storage.rs, objects/packed_array_builtin.rs, runtime_artifact.rs. Schema/domain owner (numeric agent): heap.rs, gc_types/layouts.rs, gc_types/value.rs codec, objects/allocation.rs, objects/native_constructor.rs, objects/compact_data.rs, gc_types/type_registration_tests.rs, and its compact_records.rs layout/domain proof. AOT structural owner: tests/emission/guarded_push.rs. Engine owner: existing tests/aot_builtins/aot_array_private_buffers.rs. Documentation owner (root): README.md plus compact-ordinary-data-storage.md, runtime-byte-ownership.md, current-inventory.md; preserve rejected6610 report/link and all previous rejection limits. Agree shared file ownership before changes; complete the coherent batch before compiling.

Reuse the actual 32-byte/16-alignment/two-edge layout proof with four-field prefix unchanged. Add exact closed word mapping and prove the three constructors emit Unknown. Update the existing actual encoded guard test rather than a second decoder. It must distinguish Unknown and NoIndexed (zero is not success), follow the physical LENGTH<=64 branch and bounded table loop, prove no entry read on cap decline, prove null-entry and String/nonempty guards before projection, cache only NoIndexed/MayIndexed, and retain original descriptor calls/common prototype continuation. Unknown/MayIndexed insertion paths must contain no key or UTF16 reads; only NoIndexed can reach the existing invalidation predicate. Check all fixed1/2/3 and general push emissions. Pin absence of helper calls/GC allocations in the complete unknown-scan and cached-NoIndexed paths. Do not weaken original actual callee/Realm, argument-evaluation and canonical publication tests.

Retain all existing ABI43 Engine fixtures: successful append then late setter/nonwrite insertion, callee/argument effects, compact-to-dictionary promotion, false-positive keys, numeric -0, deletion/reinsertion/compaction, forced GC, later programs, NativeHost sloppy/strict and Portable prepared eval. Add bounded cases to these owners:

1. Unknown empty and Unknown named/Symbol-only dictionaries become eligible at first use; a later numeric insertion must invalidate and invoke setter/throw correctly.
2. Unknown dictionary already containing a numeric accessor/nonwrite key must fall back on its FIRST push. Include a compact numeric key promoted before any push.
3. Exactly64 physical insertions with a blocking numeric key at slot63 detects the last slot; 65 physical insertions declines before scan. Use Object.create(null) prototypes and Array.prototype.push.call so prototype method absence does not alter the slot count. Named fillers and explicit digit key make the physical count deterministic; no huge arrays.
4. More than64 insertion history with most entries deleted remains conservative until ordinary table compaction; deletion is not a live-count permission to walk unbounded history. All resulting Set behavior remains correct.
5. Unknown history with a deleted numeric key then first query may safely become NoIndexed; later reinsertion must invalidate. NoIndexed and MayIndexed histories survive compaction, GC, integrity changes and subsequent programs.

JS alone cannot prove the exact cap or internal cache state, so encoded/state-transition tests must carry those implementation invariants. Do not add a product-visible test hook or snapshot API just to observe state.

## Verification and measurement gate

Normal two-package native union; same selected owners as ABI43 with new actual inventories, AOT lib/emission/runtime_link and Engine aot_array_private_buffers, aot_compact_intrinsic_installation, aot_gc_compact_data_storage, aot_compact_native_metadata. Reuse the 36-source original Test262 manifest (complete push24 plus explicit adjacent12); run actual variants and preserve native image identities. No old6610 exact-source acceptance claim. Existing semantic corpus remains valid; no new giant test family is needed for internal cached-state semantics.

Freeze new source/products once, compare against accepted a35 with the same mandatory normal-overlay cache and explicit admission. Keep original, ordinary and retained boundaries separate. Use existing driver and all21 controls initially; future expected counts are not passing receipts. Array-building targets must retain useful gains; integer original/ordinary and singleton original/retained are mandatory veto controls from the rejected gate, alongside folded, startup, Date and numeric controls. Record R native/text size and affected frame sizes; source-local scan code can change them. No code-placement, fixed-RSS or live-JS-memory causal claim without separate evidence. If this new candidate repeats material control regressions, reject it rather than adding a static-key bypass or unbounded scan in place.

## Freeze and review status

Root reports v1 archive sealed before implementation: 2,051,420 bytes / 3,162 inert members; preserve its complete digest in its own report. No v1 production source or identity is promoted. This packet is implementation-ready from a source review, pending independent authored chunks and their fresh validation. The actual accepted parent remains a9/a35. Old-candidate timing is closed. `plan.json` carries the disjoint ownership and gate; `source-identities.json` distinguishes accepted Git blobs from reviewed rejected working-source hashes.
