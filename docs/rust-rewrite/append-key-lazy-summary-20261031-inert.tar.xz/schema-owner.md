Lazy append-key schema chunk

Eight owned paths and exact before/after hashes are in schema-owner-inputs.json. The accepted parent remains a9d31bddb/a35 ABI42. The starting working tree contained sealed, unpromoted v1 ABI43 source; none of its frozen products or artifacts was modified. schema-owner.patch is the coherent owned-path diff against accepted HEAD.

OrdinaryIndexedKeySummary is a closed runtime scalar domain Unknown=0/NoIndexed=1/MayIndexed=2. closed_scalar_storage gives its actual i32 field contract; word_i32_codec uses the enum's .word() authority without duplicated variant codes. Mutable INDEXED_KEY_SUMMARY replaces the v1 bool at field3, preserving existing prefix0/1/2 and the same GC type/edge set. All three empty production dictionaries and the schema witness start Unknown. No generic reset API/helper/storage mode was added.

The closed-domain wire test checks exact variants, words and scalar codec agreement. The adapted dictionary layout test still consumes the actual emitted four-field declaration through pinned CopyingTypeLayouts and asserts32B size/16B alignment, offsets16/20/24/28 and two GC edges. These native tests are implemented, not executed yet. date_structural owns the shared full-R producer/state assertions.

Eight-file rustfmt2021(skip_children=true) and git diff --check passed. No build/native/Node execution, package mutation, stage or commit occurred. Root owns the bounded Unknown scan, NoIndexed-only insertion classifier and ABI44/docs.
