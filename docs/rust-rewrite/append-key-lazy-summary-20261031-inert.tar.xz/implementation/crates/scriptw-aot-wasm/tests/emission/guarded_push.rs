//! Fixed push entries retain real code/Realm proofs and allocate argv only on
//! the saved-operand fallback, with canonical packed publication in R.
use super::property_read_plans::{calls, Module};
use scriptw_aot_wasm::{
    emit_with_rooted_snapshot, GcSnapshotField, GcSnapshotLayout, PromiseRejectionPolicy,
    WasmRuntimeValueTag,
};
use scriptw_front::{parse, ParseOptions};
use scriptw_ir::lower;
use wasmparser::{
    CompositeInnerType, HeapType, Operator, StorageType, UnpackedIndex, ValType, Validator,
    WasmFeatures,
};

fn frame_end(body: &[Operator<'_>], start: usize) -> usize {
    let mut depth = 1;
    for (offset, op) in body[start + 1..].iter().enumerate() {
        match op {
            Operator::If { .. }
            | Operator::Block { .. }
            | Operator::Loop { .. }
            | Operator::TryTable { .. }
            | Operator::Try { .. } => depth += 1,
            Operator::End => {
                depth -= 1;
                if depth == 0 {
                    return start + 1 + offset;
                }
            }
            _ => {}
        }
    }
    panic!("encoded control frame is balanced");
}

fn indexed_key_summary_field(runtime: &Module<'_>, dictionary: u32) -> u32 {
    let CompositeInnerType::Struct(storage) =
        &runtime.types[dictionary as usize].composite_type.inner
    else {
        panic!("the snapshot dictionary witness names its actual struct");
    };
    let summary = storage
        .fields
        .iter()
        .enumerate()
        .filter_map(|(index, field)| {
            (field.mutable
                && field.element_type == StorageType::Val(ValType::I32)
                && index as u32 != GcSnapshotField::PropertiesLength.index())
            .then_some(index as u32)
        })
        .collect::<Vec<_>>();
    assert_eq!(
        summary.len(),
        1,
        "the dictionary has one mutable scalar summary distinct from its declaration-owned length"
    );
    summary[0]
}

fn dictionary_producers_initialize_unknown_summary(
    runtime: &Module<'_>,
    dictionary: u32,
    summary: u32,
) {
    let CompositeInnerType::Struct(storage) =
        &runtime.types[dictionary as usize].composite_type.inner
    else {
        unreachable!();
    };
    for owner in [
        "helper::ordinary_object_allocate",
        "helper::native_constructor_header_allocate",
        "helper::ordinary_property_storage_ensure",
    ] {
        let (_, body) = runtime.named(owner);
        let allocations = body
            .iter()
            .enumerate()
            .filter_map(|(position, op)| {
                matches!(op,
            Operator::StructNew { struct_type_index } if *struct_type_index == dictionary)
                .then_some(position)
            })
            .collect::<Vec<_>>();
        assert_eq!(
            allocations.len(),
            1,
            "{owner} has one actual dictionary producer"
        );
        let operand = body[..allocations[0]]
            .iter()
            .rev()
            .filter(|op| !matches!(op, Operator::RefAsNonNull))
            .nth(storage.fields.len() - 1 - summary as usize)
            .unwrap();
        assert!(
            matches!(operand, Operator::I32Const { value: 0 }),
            "{owner} initializes the actual summary operand to Unknown (0)"
        );
    }
}

fn frames_at(body: &[Operator<'_>], position: usize) -> Vec<usize> {
    let mut frames = Vec::new();
    for (index, op) in body[..position].iter().enumerate() {
        match op {
            Operator::If { .. }
            | Operator::Block { .. }
            | Operator::Loop { .. }
            | Operator::TryTable { .. }
            | Operator::Try { .. } => frames.push(index),
            Operator::End => {
                frames
                    .pop()
                    .expect("every inner End closes an actual frame");
            }
            _ => {}
        }
    }
    frames
}

fn frame_else(body: &[Operator<'_>], start: usize) -> Option<usize> {
    (start + 1..frame_end(body, start)).find(|&position| {
        matches!(body[position], Operator::Else) && frames_at(body, position).last() == Some(&start)
    })
}

fn reference_operand(body: &[Operator<'_>], before: usize) -> u32 {
    let operand = body[..before]
        .iter()
        .rev()
        .find(|op| !matches!(op, Operator::RefAsNonNull))
        .unwrap();
    let Operator::LocalGet { local_index } = operand else {
        panic!("the actual reference operand remains rooted");
    };
    *local_index
}

fn reference_producer(body: &[Operator<'_>], before: usize, root: u32) -> usize {
    let assignment = body[..before].iter().rposition(|op| matches!(op,
        Operator::LocalSet { local_index } | Operator::LocalTee { local_index } if *local_index == root))
        .expect("the inspected root has an actual producer");
    let producer = (0..assignment)
        .rev()
        .find(|&position| {
            !matches!(
                body[position],
                Operator::RefAsNonNull | Operator::RefCastNonNull { .. }
            )
        })
        .unwrap();
    if let Operator::LocalGet { local_index } = body[producer] {
        reference_producer(body, producer, local_index)
    } else {
        producer
    }
}

fn branch_target(body: &[Operator<'_>], position: usize, depth: u32) -> usize {
    let frames = frames_at(body, position);
    frames[frames.len() - 1 - depth as usize]
}

fn scalar_constant(body: &[Operator<'_>], before: usize, root: u32) -> i32 {
    let assignment = body[..before].iter().rposition(|op| matches!(op,
        Operator::LocalSet { local_index } | Operator::LocalTee { local_index } if *local_index == root)).unwrap();
    let Operator::I32Const { value } = body[assignment - 1] else {
        panic!("the inspected scalar has a constant producer")
    };
    value
}

fn primitive_only(body: &[Operator<'_>]) -> bool {
    !body.iter().any(|op| {
        matches!(
            op,
            Operator::Call { .. }
                | Operator::ReturnCall { .. }
                | Operator::CallRef { .. }
                | Operator::ReturnCallRef { .. }
                | Operator::CallIndirect { .. }
                | Operator::ReturnCallIndirect { .. }
                | Operator::StructNew { .. }
                | Operator::StructNewDefault { .. }
                | Operator::ArrayNew { .. }
                | Operator::ArrayNewDefault { .. }
                | Operator::ArrayNewFixed { .. }
                | Operator::ArrayNewData { .. }
                | Operator::ArrayNewElem { .. }
        )
    })
}

fn root_retired_before(body: &[Operator<'_>], before: usize, root: u32) {
    let assignment = body[..before]
        .iter()
        .rposition(|op| {
            matches!(op,
        Operator::LocalSet { local_index } if *local_index == root)
        })
        .unwrap();
    assert!(
        matches!(body[assignment - 1], Operator::RefNull { .. }),
        "each temporary GC root retires before an early scan exit"
    );
}

struct DigitPrefix {
    tag_if: usize,
    tag: u32,
    text: u32,
    units: u32,
    result: u32,
}

fn guarded_digit_prefix(
    runtime: &Module<'_>,
    body: &[Operator<'_>],
    unit_read: usize,
) -> DigitPrefix {
    let string = runtime.witness_type(GcSnapshotLayout::String);
    let units_type = runtime.witness_type(GcSnapshotLayout::CodeUnits);
    assert!(
        matches!(body[unit_read], Operator::ArrayGetU { array_type_index } if array_type_index == units_type)
    );
    let Operator::LocalGet { local_index: zero } = body[unit_read - 1] else {
        panic!("the prefix read names its actual index")
    };
    assert_eq!(
        scalar_constant(body, unit_read, zero),
        0,
        "only UTF-16 unit zero is inspected"
    );
    let units = reference_operand(body, unit_read - 1);
    let projection = reference_producer(body, unit_read, units);
    assert!(
        matches!(body[projection], Operator::StructGet { struct_type_index, field_index }
        if struct_type_index == string && field_index == GcSnapshotField::StringUnits.index())
    );
    let text = reference_operand(body, projection);
    let frames = frames_at(body, unit_read);
    let nonempty = frames
        .iter()
        .copied()
        .rev()
        .find(|&frame| {
            matches!(body[frame], Operator::If { .. })
                && matches!(body[frame - 1], Operator::ArrayLen)
        })
        .expect("unit zero is guarded by actual nonempty String units");
    assert_eq!(reference_operand(body, nonempty - 1), units);
    let tag_if = frames.iter().copied().rev().find(|&frame| matches!(&body[frame - 3..=frame],
        [Operator::LocalGet { .. }, Operator::I32Const { value }, Operator::I32Eq, Operator::If { .. }]
            if *value == WasmRuntimeValueTag::String.tag())).expect("only a proven String reaches its unit projection");
    assert!(tag_if < nonempty && tag_if < projection);
    let Operator::LocalGet { local_index: tag } = body[tag_if - 3] else {
        unreachable!()
    };
    let text_assignment = body[..projection]
        .iter()
        .rposition(|op| {
            matches!(op,
        Operator::LocalSet { local_index } if *local_index == text)
        })
        .unwrap();
    assert!(
        tag_if < text_assignment
            && matches!(body[text_assignment - 1], Operator::RefCastNonNull {
        hty: HeapType::Concrete(UnpackedIndex::Module(index)) } if index == string)
    );
    let [Operator::I32Const { value: 48 }, Operator::I32Sub, Operator::I32Const { value: 9 }, Operator::I32LeU, Operator::LocalSet {
        local_index: result,
    }] = body[unit_read + 1..unit_read + 6]
    else {
        panic!("unsigned first-unit subtraction admits precisely ASCII zero through nine");
    };
    assert_eq!(
        scalar_constant(body, nonempty, result),
        0,
        "empty String units keep the predicate false"
    );
    DigitPrefix {
        tag_if,
        tag,
        text,
        units,
        result,
    }
}

fn bounded_unknown_dictionary_scan(
    runtime: &Module<'_>,
    body: &[Operator<'_>],
    read: usize,
    no_test: usize,
    (dictionary, summary): (u32, u32),
) {
    let Operator::LocalSet { local_index: state } = body[read + 1] else {
        unreachable!()
    };
    let unknown = (read + 2..no_test).find(|&position| matches!(&body[position - 3..=position],
        [Operator::LocalGet { local_index }, Operator::I32Const { value: 0 }, Operator::I32Eq, Operator::If { .. }]
            if *local_index == state)).expect("only exact Unknown enters the first-query scan");
    let unknown_end = frame_end(body, unknown);
    assert!(
        unknown_end < no_test && frame_else(body, unknown).is_none(),
        "cached NoIndexed/MayIndexed skip the complete cold scan and state write"
    );
    let dictionary_root = reference_operand(body, read);
    let cap = (unknown + 1..unknown_end)
        .find(|&position| {
            matches!(
                &body[position - 3..=position],
                [
                    Operator::LocalGet { .. },
                    Operator::I32Const { value: 64 },
                    Operator::I32LeU,
                    Operator::If { .. }
                ]
            )
        })
        .expect("a physical extent of at most 64 controls the complete entry scan");
    assert!(frame_else(body, cap).is_none());
    let cap_end = frame_end(body, cap);
    let Operator::LocalGet {
        local_index: length,
    } = body[cap - 3]
    else {
        unreachable!()
    };
    let length_read = reference_producer(body, cap, length);
    assert!(
        matches!(body[length_read], Operator::StructGet { struct_type_index, field_index }
        if struct_type_index == dictionary && field_index == GcSnapshotField::PropertiesLength.index())
    );
    assert_eq!(
        reference_operand(body, length_read),
        dictionary_root,
        "the bound uses this dictionary's physical LENGTH, including tombstones"
    );
    let selected = body[unknown + 1..unknown_end]
        .iter()
        .enumerate()
        .filter_map(|(offset, op)| {
            if matches!(op, Operator::LocalSet { local_index } if *local_index == state) {
                let position = unknown + 1 + offset;
                let Operator::I32Const { value } = body[position - 1] else {
                    panic!("selected states remain in the closed scalar domain")
                };
                Some((position, value))
            } else {
                None
            }
        })
        .collect::<Vec<_>>();
    assert_eq!(selected.iter().map(|(_, value)| *value).collect::<Vec<_>>(), [2, 1, 2],
        "cap decline starts MayIndexed; bounded exhaustion starts NoIndexed; only an observed digit restores MayIndexed");
    assert!(
        unknown < selected[0].0
            && selected[0].0 < cap
            && cap < selected[1].0
            && selected[1].0 < selected[2].0
            && selected[2].0 < cap_end
    );
    let writes = body[unknown + 1..unknown_end].iter().enumerate().filter_map(|(offset, op)| matches!(op,
        Operator::StructSet { struct_type_index, field_index } if *struct_type_index == dictionary && *field_index == summary)
        .then_some(unknown + 1 + offset)).collect::<Vec<_>>();
    assert_eq!(
        writes.len(),
        1,
        "one completed cold selection updates the canonical dictionary"
    );
    let write = writes[0];
    assert!(
        cap_end < write
            && matches!(body[write - 1], Operator::LocalGet { local_index } if local_index == state)
    );
    assert_eq!(reference_operand(body, write - 1), dictionary_root);
    assert!(
        primitive_only(&body[unknown + 1..unknown_end]),
        "the complete cold scan cannot call, allocate or materialize a recipe"
    );
    let table = runtime.witness_type(GcSnapshotLayout::Properties);
    let entry_type = runtime.witness_type(GcSnapshotLayout::Property);
    let stored_type = runtime.witness_type(GcSnapshotLayout::Stored);
    let descriptor = runtime.witness_type(GcSnapshotLayout::Descriptor);
    let unit_type = runtime.witness_type(GcSnapshotLayout::CodeUnits);
    let entries = (unknown + 1..unknown_end)
        .filter(|&position| {
            matches!(body[position],
        Operator::StructGet { struct_type_index, field_index } if struct_type_index == dictionary
            && field_index == GcSnapshotField::PropertiesEntries.index())
        })
        .collect::<Vec<_>>();
    assert_eq!(entries.len(), 1);
    assert!(
        cap < entries[0] && entries[0] < cap_end,
        "over-cap dictionaries never even read ENTRIES"
    );
    let table_reads = (unknown + 1..unknown_end)
        .filter(|&position| {
            matches!(body[position],
        Operator::ArrayGet { array_type_index } if array_type_index == table)
        })
        .collect::<Vec<_>>();
    assert_eq!(table_reads.len(), 1);
    let entry_read = table_reads[0];
    assert!(cap < entry_read && entry_read < cap_end);
    let Operator::LocalGet {
        local_index: position,
    } = body[entry_read - 1]
    else {
        panic!("the scan names one physical cursor")
    };
    assert_eq!(
        reference_producer(body, entry_read, reference_operand(body, entry_read - 1)),
        entries[0]
    );
    let scan = frames_at(body, entry_read)
        .into_iter()
        .rev()
        .find(|&frame| matches!(body[frame], Operator::Loop { .. }))
        .unwrap();
    assert_eq!(scalar_constant(body, scan, position), 0);
    let bounded_exit = (scan + 1..entry_read).find(|&offset| matches!(&body[offset - 3..=offset],
        [Operator::LocalGet { local_index: cursor }, Operator::LocalGet { local_index: extent }, Operator::I32GeU, Operator::BrIf { .. }]
            if *cursor == position && *extent == length)).expect("every slot load is dominated by physical cursor < LENGTH");
    let Operator::BrIf { relative_depth } = body[bounded_exit] else {
        unreachable!()
    };
    let scanned = branch_target(body, bounded_exit, relative_depth);
    assert!(matches!(body[scanned], Operator::Block { .. }) && scanned < scan);
    let Operator::LocalSet { local_index: maybe } = body[entry_read + 1] else {
        panic!("nullable entry stays rooted")
    };
    let key_reads = (unknown + 1..unknown_end).filter(|&offset| matches!(body[offset], Operator::StructGet {
        struct_type_index, field_index } if struct_type_index == entry_type && field_index == GcSnapshotField::PropertyKey.index())).collect::<Vec<_>>();
    assert_eq!(key_reads.len(), 1);
    let key_read = key_reads[0];
    assert!(entry_read < key_read && key_read < cap_end);
    let live = frames_at(body, key_read).into_iter().rev().find(|&frame| matches!(&body[frame - 3..=frame],
        [Operator::LocalGet { local_index }, Operator::RefIsNull, Operator::I32Eqz, Operator::If { .. }]
            if *local_index == maybe)).expect("null table tombstones skip the entire raw-key projection");
    assert!(frame_else(body, live).is_none());
    assert_eq!(
        reference_producer(body, key_read, reference_operand(body, key_read)),
        entry_read
    );
    assert!(body[unknown + 1..unknown_end].iter().all(|op| !matches!(op,
        Operator::StructGet { struct_type_index, field_index } if *struct_type_index == descriptor
            || (*struct_type_index == entry_type && *field_index != GcSnapshotField::PropertyKey.index()))),
        "the scan reads immutable entry keys, never descriptor/value/recipe edges");
    let unit_reads = (unknown + 1..unknown_end)
        .filter(|&offset| {
            matches!(body[offset],
        Operator::ArrayGetU { array_type_index } if array_type_index == unit_type)
        })
        .collect::<Vec<_>>();
    assert_eq!(unit_reads.len(), 1);
    let unit_read = unit_reads[0];
    assert!(key_read < unit_read && unit_read < cap_end);
    let prefix = guarded_digit_prefix(runtime, body, unit_read);
    assert!(live < prefix.tag_if);
    let tag_read = reference_producer(body, prefix.tag_if, prefix.tag);
    assert!(
        matches!(body[tag_read], Operator::StructGet { struct_type_index, field_index }
        if struct_type_index == stored_type && field_index == GcSnapshotField::StoredTag.index())
    );
    let key = reference_operand(body, tag_read);
    assert_eq!(reference_producer(body, tag_read, key), key_read);
    let reference_read = reference_producer(body, unit_read, prefix.text);
    assert!(
        matches!(body[reference_read], Operator::StructGet { struct_type_index, field_index }
        if struct_type_index == stored_type && field_index == GcSnapshotField::StoredRef.index())
    );
    assert_eq!(
        reference_operand(body, reference_read),
        key,
        "String tag and reference come from the same immutable raw entry key"
    );
    let Operator::LocalSet {
        local_index: value_reference,
    } = body[reference_read + 1]
    else {
        panic!("raw key reference remains rooted")
    };
    let indexed_store = (unit_read + 6..frame_end(body, prefix.tag_if)).find(|&offset| matches!(&body[offset - 1..=offset],
        [Operator::LocalGet { local_index }, Operator::LocalSet { .. }] if *local_index == prefix.result)).unwrap();
    let Operator::LocalSet {
        local_index: indexed,
    } = body[indexed_store]
    else {
        unreachable!()
    };
    assert_eq!(
        scalar_constant(body, entry_read, indexed),
        0,
        "tombstone/Symbol/non-digit paths remain negative per slot"
    );
    let digit = frames_at(body, selected[2].0).last().copied().unwrap();
    assert!(
        matches!(&body[digit - 1..=digit], [Operator::LocalGet { local_index }, Operator::If { .. }] if *local_index == indexed)
    );
    for root in [
        maybe,
        key,
        reference_operand(body, key_read),
        prefix.text,
        prefix.units,
        value_reference,
    ] {
        root_retired_before(body, digit, root);
    }
    let early = (selected[2].0 + 1..frame_end(body, digit))
        .find(|&offset| matches!(body[offset], Operator::Br { .. }))
        .unwrap();
    let Operator::Br { relative_depth } = body[early] else {
        unreachable!()
    };
    assert_eq!(
        branch_target(body, early, relative_depth),
        scanned,
        "a positive key exits only after selecting MayIndexed and clearing its roots"
    );
    let exits = (scan + 1..frame_end(body, scan))
        .filter(|&offset| match body[offset] {
            Operator::Br { relative_depth } | Operator::BrIf { relative_depth } => {
                branch_target(body, offset, relative_depth) == scanned
            }
            _ => false,
        })
        .collect::<Vec<_>>();
    assert_eq!(exits, [bounded_exit, early],
        "NoIndexed can escape only after physical exhaustion; the only early exit first selects MayIndexed");
    let increment = (frame_end(body, digit) + 1..frame_end(body, scan)).find(|&offset| matches!(&body[offset - 3..=offset],
        [Operator::LocalGet { local_index: previous }, Operator::I32Const { value: 1 }, Operator::I32Add, Operator::LocalSet { local_index: next }]
            if *previous == position && *next == position)).unwrap();
    let Operator::Br { relative_depth } = body[increment + 1] else {
        panic!("the sole cursor increment continues the counted loop")
    };
    assert_eq!(branch_target(body, increment + 1, relative_depth), scan);
    assert_eq!(body[scan + 1..frame_end(body, scan)].iter().filter(|op| matches!(op,
        Operator::LocalSet { local_index } | Operator::LocalTee { local_index } if *local_index == position)).count(), 1,
        "the bounded scan advances each physical slot exactly once");
    root_retired_before(body, write, reference_operand(body, entry_read - 1));
}

fn insertion_invalidates_only_established_absence(
    runtime: &Module<'_>,
    (dictionary, summary): (u32, u32),
) {
    let (_, body) = runtime.named("helper::ordinary_property_append");
    let states = body.iter().enumerate().filter_map(|(position, op)| matches!(op,
        Operator::StructGet { struct_type_index, field_index } if *struct_type_index == dictionary && *field_index == summary)
        .then_some(position)).collect::<Vec<_>>();
    assert_eq!(
        states.len(),
        1,
        "the sole append publisher reads one maintenance state"
    );
    let read = states[0];
    assert!(
        matches!(
            &body[read + 1..read + 4],
            [
                Operator::I32Const { value: 1 },
                Operator::I32Eq,
                Operator::If { .. }
            ]
        ),
        "Unknown (0) and MayIndexed (2) skip the complete new-key classification prefix"
    );
    let classified = read + 3;
    let end = frame_end(body, classified);
    assert!(frame_else(body, classified).is_none());
    assert!(
        primitive_only(&body[read..end]),
        "proof maintenance performs no helper call, allocation or callback"
    );
    let writes = body.iter().enumerate().filter_map(|(position, op)| matches!(op,
        Operator::StructSet { struct_type_index, field_index } if *struct_type_index == dictionary && *field_index == summary)
        .then_some(position)).collect::<Vec<_>>();
    assert_eq!(
        writes.len(),
        1,
        "insertion can only make the existing absence proof sticky MayIndexed"
    );
    let write = writes[0];
    assert!(
        classified < write
            && write < end
            && matches!(body[write - 1], Operator::I32Const { value: 2 })
    );
    assert_eq!(
        reference_operand(body, write - 1),
        reference_operand(body, read),
        "insertion invalidates the same dictionary whose NoIndexed state was checked"
    );
    let units = runtime.witness_type(GcSnapshotLayout::CodeUnits);
    let unit_reads = (classified + 1..end)
        .filter(|&position| {
            matches!(body[position],
        Operator::ArrayGetU { array_type_index } if array_type_index == units)
        })
        .collect::<Vec<_>>();
    assert_eq!(unit_reads.len(), 1);
    let prefix = guarded_digit_prefix(runtime, body, unit_reads[0]);
    assert!(classified < prefix.tag_if);
    let digit = frames_at(body, write).last().copied().unwrap();
    assert!(
        matches!(&body[digit - 1..=digit], [Operator::LocalGet { local_index }, Operator::If { .. }]
        if *local_index == prefix.result),
        "only the guarded digit-prefix result selects MayIndexed"
    );
    let entry = runtime.witness_type(GcSnapshotLayout::Property);
    let table = runtime.witness_type(GcSnapshotLayout::Properties);
    let allocation = body
        .iter()
        .position(|op| {
            matches!(op, Operator::StructNew { struct_type_index }
        if *struct_type_index == entry)
        })
        .unwrap();
    let publication = body
        .iter()
        .position(|op| {
            matches!(op, Operator::ArraySet { array_type_index }
        if *array_type_index == table)
        })
        .unwrap();
    assert!(end < allocation && allocation < publication,
        "MayIndexed maintenance completes before the new immutable entry is allocated and published");
}

fn no_indexed_summary_skips_only_this_prototype_level(
    runtime: &Module<'_>,
    body: &[Operator<'_>],
    first_publication: usize,
    (dictionary, summary): (u32, u32),
    decimal: u32,
    descriptor: u32,
) {
    let array = runtime.witness_type(GcSnapshotLayout::Array);
    let object = runtime.witness_type(GcSnapshotLayout::Object);
    let reads = body[..first_publication]
        .iter()
        .enumerate()
        .filter_map(|(position, op)| {
            matches!(op,
        Operator::StructGet { struct_type_index, field_index }
            if *struct_type_index == dictionary && *field_index == summary)
            .then_some(position)
        })
        .collect::<Vec<_>>();
    assert_eq!(
        reads.len(),
        1,
        "each append entry rereads its current dictionary state once"
    );
    let read = reads[0];
    let Operator::LocalSet { local_index: state } = body[read + 1] else {
        panic!("the closed summary state is rooted in its own scalar local")
    };
    let no_test = (read + 2..first_publication).find(|&position| matches!(&body[position..position + 4],
        [Operator::LocalGet { local_index }, Operator::I32Const { value: 1 }, Operator::I32Eq, Operator::LocalSet { .. }]
            if *local_index == state)).expect("only exact NoIndexed (1), never Unknown=0 truthiness, permits bypass");
    let [Operator::LocalSet {
        local_index: result,
    }, Operator::LocalGet {
        local_index: returned,
    }, Operator::LocalSet {
        local_index: acceptable,
    }] = body[no_test + 3..no_test + 6]
    else {
        panic!("the caller retains the exact state==NoIndexed result");
    };
    assert_eq!(result, returned);
    let dictionary_if = frames_at(body, read)
        .into_iter()
        .rev()
        .find(|&frame| {
            matches!(body[frame], Operator::If { .. })
                && matches!(body[frame - 1],
            Operator::RefTestNonNull { hty: HeapType::Concrete(UnpackedIndex::Module(index)) }
                if index == dictionary)
        })
        .expect("only a proven actual dictionary may supply the NoIndexed proof");
    let dictionary_else =
        frame_else(body, dictionary_if).expect("compact storage retains an explicit fallback arm");
    let dictionary_end = frame_end(body, dictionary_if);
    assert!(dictionary_if < read && read < no_test && no_test < dictionary_else);
    bounded_unknown_dictionary_scan(runtime, body, read, no_test, (dictionary, summary));
    assert_eq!(body[..first_publication].iter().filter(|op| matches!(op,
        Operator::StructSet { struct_type_index, field_index } if *struct_type_index == dictionary && *field_index == summary)).count(), 1,
        "only the Unknown-owned completed scan can publish a cached summary");
    assert!(
        matches!(&body[dictionary_else + 1..dictionary_end],
        [Operator::I32Const { value: 0 }, Operator::LocalSet { local_index }] if *local_index == acceptable),
        "a non-dictionary prototype cannot authorize the summary bypass"
    );
    let dictionary_root = reference_operand(body, read);
    let properties = reference_producer(body, read, dictionary_root);
    assert!(
        matches!(body[properties], Operator::StructGet { struct_type_index, field_index }
        if struct_type_index == object && field_index == GcSnapshotField::ObjectProperties.index()),
        "the tested dictionary is the actual current ordinary header's storage"
    );
    let tested_root = reference_operand(body, dictionary_if - 1);
    assert_eq!(
        reference_producer(body, dictionary_if - 1, tested_root),
        properties,
        "the type test and flag read use the same current storage record"
    );
    let header = reference_operand(body, properties);
    let bypass = (dictionary_end + 1..first_publication)
        .find(|&position| {
            matches!(&body[position - 1..=position],
        [Operator::LocalGet { local_index }, Operator::BrIf { .. }] if *local_index == acceptable)
        })
        .expect("the NoIndexed result controls an actual conditional branch");
    let Operator::BrIf { relative_depth } = body[bypass] else {
        unreachable!()
    };
    root_retired_before(body, bypass, dictionary_root);
    root_retired_before(body, bypass, tested_root);
    let proof_writes = body[no_test + 6..bypass].iter().enumerate().filter_map(|(offset, op)| matches!(op,
        Operator::LocalSet { local_index } | Operator::LocalTee { local_index } if *local_index == acceptable)
        .then_some(no_test + 6 + offset)).collect::<Vec<_>>();
    assert_eq!(
        proof_writes,
        [dictionary_else + 2],
        "only the explicit compact-storage else arm changes the NoIndexed result before its branch"
    );
    let frames = frames_at(body, bypass);
    let checked = frames[frames.len() - 1 - relative_depth as usize];
    assert!(matches!(body[checked], Operator::Block { .. }));
    let checked_end = frame_end(body, checked);
    assert!(
        checked < properties
            && properties < dictionary_if
            && dictionary_end < bypass
            && bypass < checked_end
            && checked_end < first_publication,
        "NoIndexed dictionaries jump past this level's complete descriptor loop"
    );
    assert!(primitive_only(&body[checked + 1..=bypass]),
        "the cold scan and cached-NoIndexed path use primitive reads/control with no calls or allocations");
    let fallback = &body[bypass + 1..checked_end];
    for target in [decimal, descriptor] {
        assert_eq!(
            fallback
                .iter()
                .filter(|op| matches!(op, Operator::Call { function_index }
            if *function_index == target))
                .count(),
            1,
            "the unchanged uncertain/compact fallback still owns the actual helper call"
        );
    }
    assert!(
        fallback
            .iter()
            .any(|op| matches!(op, Operator::Loop { .. })),
        "Unknown/MayIndexed or compact storage still checks the full appended index range"
    );
    let ordinary = body[..checked]
        .windows(3)
        .enumerate()
        .rfind(|(_, ops)| {
            matches!(ops,
        [Operator::RefTestNonNull { hty: HeapType::Concrete(UnpackedIndex::Module(index)) },
         Operator::I32Eqz, Operator::BrIf { .. }] if *index == object)
        })
        .map(|(position, _)| position)
        .expect("ordinary concrete-object admission precedes any storage proof");
    let header_store = body[..properties].iter().rposition(|op| matches!(op,
        Operator::LocalSet { local_index } | Operator::LocalTee { local_index } if *local_index == header)).unwrap();
    assert!(ordinary + 2 < header_store && header_store < checked);
    assert!(matches!(body[header_store - 1], Operator::RefCastNonNull {
        hty: HeapType::Concrete(UnpackedIndex::Module(index)) } if index == object));
    assert_eq!(
        reference_operand(body, header_store - 1),
        reference_operand(body, ordinary),
        "the guarded concrete prototype supplies the actual header whose storage is inspected"
    );
    let array_if = frames_at(body, ordinary)
        .into_iter()
        .rev()
        .find(|&frame| {
            matches!(body[frame], Operator::If { .. })
                && matches!(body[frame - 1],
            Operator::RefTestNonNull { hty: HeapType::Concrete(UnpackedIndex::Module(index)) }
                if index == array)
        })
        .expect("prototype Arrays retain their separate concrete arm");
    let array_else = frame_else(body, array_if).unwrap();
    assert!(array_else < ordinary && ordinary < checked);
    assert!(
        body[array_if + 1..array_else].iter().any(|op| matches!(op,
        Operator::StructGet { struct_type_index, field_index }
            if *struct_type_index == array && *field_index == GcSnapshotField::ArrayCount.index())),
        "Array prototype occupancy remains checked before ordinary dictionary admission"
    );
    let follow = (checked_end + 1..first_publication).find(|&position| matches!(body[position],
        Operator::StructGet { struct_type_index, field_index }
            if struct_type_index == object && field_index == GcSnapshotField::ObjectPrototype.index()))
        .expect("both branches merge into the common live prototype read");
    assert!(frame_end(body, array_if) < follow);
    assert_eq!(
        reference_operand(body, follow),
        header,
        "both paths advance from the same current ordinary header"
    );
    assert!(!body[properties + 1..follow].iter().any(|op| matches!(op,
        Operator::LocalSet { local_index } | Operator::LocalTee { local_index } if *local_index == header)),
        "the proof does not switch headers before following the prototype");
    let prototype_loop = frames_at(body, checked)
        .into_iter()
        .rev()
        .find(|&frame| matches!(body[frame], Operator::Loop { .. }))
        .unwrap();
    assert!(
        body[prototype_loop + 1..array_if]
            .windows(3)
            .any(|ops| matches!(
                ops,
                [
                    Operator::I32Const { value: 8 },
                    Operator::I32GeU,
                    Operator::BrIf { .. }
                ]
            )),
        "the existing chain depth cap still precedes every prototype type/storage proof"
    );
    assert!(
        body[follow + 1..frame_end(body, prototype_loop)]
            .iter()
            .enumerate()
            .any(|(offset, op)| {
                let Operator::Br { relative_depth } = op else {
                    return false;
                };
                let frames = frames_at(body, follow + 1 + offset);
                frames[frames.len() - 1 - *relative_depth as usize] == prototype_loop
            }),
        "the common join continues the same bounded prototype walk"
    );
}

fn argv_allocation(op: &Operator<'_>, array: u32) -> bool {
    matches!(op, Operator::ArrayNew { array_type_index }
        | Operator::ArrayNewDefault { array_type_index }
        | Operator::ArrayNewFixed { array_type_index, .. }
        if *array_type_index == array)
}

fn incoming_empty_argv_allocation(
    body: &[Operator<'_>],
    signature: &wasmparser::FuncType,
    argv: u32,
) -> usize {
    let vectors = signature
        .params()
        .iter()
        .enumerate()
        .filter_map(|(index, ty)| {
            matches!(ty, ValType::Ref(reference) if reference.is_nullable()
            && reference.heap_type() == HeapType::Concrete(UnpackedIndex::Module(argv)))
            .then_some(index as u32)
        })
        .collect::<Vec<_>>();
    assert_eq!(
        vectors.len(),
        1,
        "the source entry owns one nullable incoming argument List"
    );
    let vector = vectors[0];
    let count = vector
        .checked_sub(1)
        .expect("the incoming count precedes its vector");
    assert_eq!(signature.params()[count as usize], ValType::I64);
    let allocations = body
        .windows(14)
        .enumerate()
        .filter_map(|(start, ops)| {
            matches!(ops,
            [Operator::LocalGet { local_index: parameter }, Operator::LocalSet { local_index: saved },
             Operator::LocalGet { local_index: supplied }, Operator::RefIsNull, Operator::If { .. },
             Operator::LocalGet { local_index: supplied_count }, Operator::I64Eqz, Operator::I32Eqz,
             Operator::If { .. }, Operator::Unreachable, Operator::End,
             Operator::ArrayNewFixed { array_type_index, array_size: 0 },
             Operator::LocalSet { local_index: normalized }, Operator::Else]
                if *parameter == vector && saved == supplied && supplied == normalized
                    && *supplied_count == count && *array_type_index == argv)
            .then_some(start + 11)
        })
        .collect::<Vec<_>>();
    assert_eq!(allocations.len(), 1,
        "only a null incoming vector with zero declared arguments constructs the entry's empty List");
    allocations[0]
}

#[test]
fn fixed_push_proves_actual_native_then_keeps_argument_allocations_in_fallback() {
    std::thread::Builder::new()
        .name("guarded-push-emission".into())
        .stack_size(64 * 1024 * 1024)
        .spawn(|| {
            let lowered = lower(&parse(
                "function one(v){var a=[];var result=a.push(v);return result;} \
                 function two(v){var a=[];var result=a.push(v,v);return result;} \
                 function three(v){var a=[];var result=a.push(v,v,v);return result;} \
                 function control(v){var a=[];return a;} \
                 function zero(v){var a=[];var result=a.push();return result;} \
                 function four(v){var a=[];var result=a.push(v,v,v,v);return result;} \
                 function evaluated(arg){var a=[];var result=a.push(arg(1),arg(2));return result;} \
                 [one,two,three,control,zero,four,evaluated];",
                ParseOptions::script(),
            ).unwrap());
            let artifact = emit_with_rooted_snapshot(
                &lowered,
                PromiseRejectionPolicy::Ignore,
                &scriptw_intl::IntlCompilationProfile::Minimal,
            ).unwrap();
            let runtime_bytes = artifact.runtime().unwrap().bytes();
            for bytes in [&artifact.bytes[..], runtime_bytes] {
                Validator::new_with_features(WasmFeatures::all())
                    .validate_all(bytes).unwrap();
            }
            let runtime = Module::read(runtime_bytes, true);
            let program = Module::read(&artifact.bytes, true);
            let stored = runtime.witness_type(GcSnapshotLayout::Stored);
            let array = runtime.witness_type(GcSnapshotLayout::Array);
            let storage = runtime.witness_type(GcSnapshotLayout::Array);
            let object = runtime.witness_type(GcSnapshotLayout::Object);
            let dictionary = runtime.witness_type(GcSnapshotLayout::PropertyStorage);
            let summary = indexed_key_summary_field(&runtime, dictionary);
            dictionary_producers_initialize_unknown_summary(&runtime, dictionary, summary);
            insertion_invalidates_only_established_absence(&runtime, (dictionary, summary));
            let code = runtime.witness_type(GcSnapshotLayout::Code);
            let context = runtime.witness_type(GcSnapshotLayout::Context);
            let (dispatch, _) = runtime.named("helper::proxy_call");
            // Nominal GC arrays can share an element layout. Bind the actual
            // JS dispatch operand, rather than guessing its type by shape.
            let signature = runtime.function_type(dispatch);
            let ValType::Ref(arguments) = signature.params()[6] else {
                panic!("two value triples precede the actual dispatch argument List");
            };
            assert!(!arguments.is_nullable(), "dispatch requires an actual argument List");
            let HeapType::Concrete(UnpackedIndex::Module(argv)) = arguments.heap_type() else {
                panic!("dispatch arguments retain their nominal GC array type");
            };
            let CompositeInnerType::Array(slots) = &runtime.types[argv as usize].composite_type.inner else {
                panic!("the actual dispatch argument operand is a GC array");
            };
            let StorageType::Val(ValType::Ref(element)) = slots.0.element_type else {
                panic!("the actual argument List contains typed GC references");
            };
            assert!(slots.0.mutable && !element.is_nullable()
                && element.heap_type() == HeapType::Concrete(UnpackedIndex::Module(stored)),
                "the actual dispatch List owns non-null canonical StoredValue entries");
            let dispatch = program.imported_runtime_function(&runtime, dispatch);
            let (publish, _) = runtime.named("helper::array_indexed_publish_default_data");
            let (descriptor, _) = runtime.named("helper::ordinary_own_descriptor");
            let (decimal, _) = runtime.named("helper::integer_decimal_string");
            let (_, control) = program.named("js::control#");
            let source_allocations = |body: &[Operator<'_>]| body.iter().filter(|op| matches!(op,
                Operator::StructNew { struct_type_index } if *struct_type_index == stored)).count();
            let mut kernels = Vec::new();
            for (name, arity) in [("one", 1), ("two", 2), ("three", 3)] {
                let (definition, kernel) = runtime.named(&format!("helper::array_packed_push{arity}"));
                let imported = program.imported_runtime_function(&runtime, definition);
                kernels.push(imported);
                let (source, body) = program.named(&format!("js::{name}#"));
                let direct = body.iter().position(|op| matches!(op,
                    Operator::Call { function_index } if *function_index == imported))
                    .expect("the source call reaches its fixed-arity native entry");
                assert!(body[..direct].iter().filter(|op| matches!(op,
                    Operator::StructGet { struct_type_index, .. } if *struct_type_index == code)).count() >= 2,
                    "actual immutable code kind and builtin identity guard the native entry");
                assert!(body[..direct].iter().any(|op| matches!(op,
                    Operator::StructGet { struct_type_index, field_index }
                        if *struct_type_index == context && *field_index == GcSnapshotField::ContextRealm.index())),
                    "the saved actual callable supplies the execution Realm");
                assert!(body[..direct].iter().any(|op| matches!(op, Operator::RefEq)),
                    "the actual execution Realm is compared with the caller Realm");
                assert_eq!(source_allocations(&body[..direct]), source_allocations(control),
                    "successful fixed push allocates no per-argument StoredValue snapshots");
                let entry_argv = incoming_empty_argv_allocation(body, program.function_type(source), argv);
                let before_push = body[..direct].iter().enumerate()
                    .filter_map(|(index, op)| argv_allocation(op, argv).then_some(index))
                    .collect::<Vec<_>>();
                assert_eq!(before_push, [entry_argv],
                    "the source entry alone normalizes incoming null argv; successful fixed push creates no argument List");
                let fallback = body.windows(3).enumerate().find_map(|(start, ops)| {
                    let [Operator::LocalGet { .. }, Operator::I32Eqz, Operator::If { .. }] = ops else { return None; };
                    let end = frame_end(body, start + 2);
                    (start > direct && calls(&body[start + 3..end], dispatch))
                        .then_some(&body[start + 3..end])
                }).expect("a failed handled flag owns the ordinary saved-operand fallback");
                assert_eq!(source_allocations(fallback), arity,
                    "only fallback snapshots each once-evaluated argument");
                assert!(fallback.iter().any(|op| argv_allocation(op, argv)),
                    "the fallback alone materializes the ordinary argument List");
                let first_publication = kernel.iter().position(|op| matches!(op,
                    Operator::Call { function_index } if *function_index == publish)).unwrap();
                assert_eq!(kernel.iter().filter(|op| matches!(op,
                    Operator::Call { function_index } if *function_index == publish)).count(), arity,
                    "the native entry publishes each rooted operand through the canonical owner");
                assert!(kernel[..first_publication].iter().any(|op| matches!(op,
                    Operator::RefTestNonNull { hty: HeapType::Concrete(UnpackedIndex::Module(index)) }
                        if *index == array)), "actual concrete Array admission precedes publication");
                for (owner, field) in [(array, GcSnapshotField::ArrayLengthWritable),
                    (storage, GcSnapshotField::ArrayCount),
                    (object, GcSnapshotField::ObjectExtensible)] {
                    assert!(kernel[..first_publication].iter().any(|op| matches!(op,
                        Operator::StructGet { struct_type_index, field_index }
                            if *struct_type_index == owner && *field_index == field.index())),
                        "live {field:?} is checked before publication");
                }
                assert!(calls(&kernel[..first_publication], descriptor),
                    "prototype indexed descriptors remain part of shared admission");
                no_indexed_summary_skips_only_this_prototype_level(&runtime, kernel, first_publication,
                    (dictionary, summary), decimal, descriptor);
                assert!(!kernel.iter().any(|op| argv_allocation(op, argv)),
                    "the native entry does not rebuild an argument vector internally");
            }
            let (_, general) = runtime.named("builtin::Array.prototype.push");
            let general_publication = general.iter().position(|op| matches!(op,
                Operator::Call { function_index } if *function_index == publish))
                .expect("general Array.push retains the canonical packed publication owner");
            no_indexed_summary_skips_only_this_prototype_level(&runtime, general, general_publication,
                (dictionary, summary), decimal, descriptor);
            let (_, evaluated) = program.named("js::evaluated#");
            let direct = evaluated.iter().position(|op| matches!(op,
                Operator::Call { function_index } if *function_index == kernels[1])).unwrap();
            assert_eq!(evaluated[..direct].iter().filter(|op| matches!(op,
                Operator::Call { function_index } if *function_index == dispatch)).count(), 2,
                "both argument callbacks finish once before the native entry rereads current prototypes and storage");
            for name in ["js::zero#", "js::four#"] {
                let (_, body) = program.named(name);
                assert!(kernels.iter().all(|kernel| !calls(body, *kernel)),
                    "unsupported fixed arities retain the general call from the start");
                assert!(calls(body, dispatch));
            }
        }).unwrap().join().unwrap();
}
