# Lazy append-key-summary measurement preparation

Source only. No LAZY binding, preparation, product/identity/image read or hash,
native/Node/build execution, cache-filesystem query or historical full replay was
performed. The candidate fingerprint remains an explicit future bind argument.

The21 exact source cases are copied byte-for-byte from sealed APP measurement:
canonical17, startup, and the same three deterministic Date controls. Manifest,
source hashes and golden derivation are unchanged. The repeated Date control
still performs513 public Date reads; no source or golden was regenerated.

Baseline remains the accepted DATE-parent products in
`target/performance-date-demand-20261031/candidate`: fingerprint
`a35adbcb61dbc57b4ee44dd1527019358deb137b11ae559de7d0d4b4a860b480`, embedded
producer source commit `7c47e38274c9645b6701552c87d38362b2bfbcd5`, ABI42, reused by
accepted parent `a9d31bddb6fa2efc81315e46d1798d78b1d314b6`. Candidate cohort is
LAZY, reserved at `target/performance-append-key-lazy-summary-20261031/candidate`,
with expected ABI44 and the exact frozen fingerprint supplied by root. Sealed
unpromoted APP/ABI43 results are a separate experiment, not this baseline.

Normal overlay backing is mandatory. Root must create the canonical nonsymlink
directory and set the environment before any future bind/prepare/measure/Node
command:

    export SCRIPTW_CACHE_DIR=/workspace/scriptw/target/performance-append-key-lazy-summary-20261031/normal-cache

`cohort.py` requires this exact path and `overlayfs:794c7630`, records cache root,
resolved environment path and filesystem before/after preparation and cohorts,
and records `SCRIPTW_CACHE_DIR` in every child's before/after environment.
Analysis compares every child resource policy to its cohort policy. Tmpfs,
ramfs, another cache directory/substrate, and changed child environment cannot
qualify. Caches are never relocated or created automatically by this driver.

Root must finish source/tests/docs, freeze the candidate, provide LAZY's accepted
baseline identity/reuse receipt, and finish unrelated native jobs before running:

    python3 -B scripts/limited_verification.py --cloud -- python3 -B target/performance-append-key-lazy-summary-20261031/measurement/cohort.py bind --candidate-fingerprint EXACT_LAZY_FINGERPRINT
    python3 -B scripts/limited_verification.py --cloud -- python3 -B target/performance-append-key-lazy-summary-20261031/measurement/cohort.py prepare baseline
    python3 -B scripts/limited_verification.py --cloud -- python3 -B target/performance-append-key-lazy-summary-20261031/measurement/cohort.py prepare candidate
    python3 -B scripts/limited_verification.py --cloud -- python3 -B target/performance-append-key-lazy-summary-20261031/measurement/cohort.py measure balanced --order eight

The inherited sample/worker/resource policy is unchanged:21 measured observations
and10 checked warmups per child; three separate original, ordinary and retained
boundaries; eight balanced ABBA+BAAB rounds, with separately named groups also
available. All21 cases retain raw argv/output/resources, per-round/group/pooled
medians/means, original post-execution RSS and process peaks. Retained Date
measurements are Ready after checked warmups. No boundary subtraction or live-JS,
RSS-benefit, universal non-regression or published-chart claim is implied.

The existing retained helper's17-entry admission remains intact: canonical17 in
one source input, Date3/startup plus13 preparation-only canonical fillers in the
second. Only the four extras use the second image set during timing. Each frozen
side prepares its own fresh images; product/source/producer/image/sidecar/runtime
key validators are unchanged. No native image is copied or loaded from an archive.

`source-draft-audit.json` records only source AST/path and synthetic pure-cache
checks. It confirms21 unchanged critical validator bodies and correct LAZY globals
in both the measured driver's and historical auditor's isolated namespaces. It
does not import the cohort module or invoke its environment/product entrypoints.

`date-inert-compatibility.json` is the exact inherited APP receipt, deliberately
unmodified. It records prior Date protocol/golden schema compatibility, not a
fresh LAZY replay or normal-overlay result. The optional historical auditor is
copied with its cache namespace pointing to LAZY; its default output is a new
`date-inert-compatibility-fresh.json` so it cannot overwrite inherited evidence.
No full504-record audit was needed or run in this preparation. Optional fresh
Node verification stays separate from native timing; no new Node command ran.

`plan.json` and `draft-receipt.json` bind only these source/harness inputs. Root
owns the later exact candidate binding and measured gate.
