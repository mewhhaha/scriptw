
function check(ok,label){if(!ok)throw label;}
function rejects(action,label){
  var caught=false;try{action();}catch(error){caught=error instanceof TypeError;}
  check(caught,label);
}
function padded(count){
  var prototype=Object.create(Array.prototype);
  for(var i=0;i<count;i++)prototype['padding'+i]=i;
  return prototype;
}
var marker={};
// The index is inserted while the dictionary has never been an append prototype.
// At64 entries it is the last entry in the bounded scan; at65 it follows all64
// leading named keys and cannot be covered by a truncated scan declared clean.
for(var extent of [64,65]){
  var cold=padded(extent-1),receiver=[],writes=0,setterThis;
  Object.defineProperty(cold,'0',{configurable:true,set:function(value){
    writes++;setterThis=this;check(value===marker,'cold indexed setter value');gc();
  }});
  Object.setPrototypeOf(receiver,cold);gc();
  check(receiver.push(marker)===1 && receiver.length===1 && writes===1 &&
    setterThis===receiver && !Object.hasOwn(receiver,'0'),
    'cold indexed descriptor at extent '+extent+' cannot be admitted as absent');
  Object.defineProperty(cold,'0',{value:'readonly',writable:false,configurable:true});
  var blocked=[];
  Object.setPrototypeOf(blocked,cold);gc();
  rejects(function(){blocked.push(marker);},'cached conservative state keeps the cold indexed restriction');
  check(blocked.length===0 && !Object.hasOwn(blocked,'0') && writes===1,
    'readonly replacement preserves the rejected receiver at extent '+extent);
}

var clean=padded(64),cleanArray=[],namedReads=0;
Object.defineProperty(clean,'padding0',{configurable:true,get:function(){
  namedReads++;throw 'scanning keys must not Get a named accessor';
}});
Object.setPrototypeOf(cleanArray,clean);
check(cleanArray.push(marker)===1 && cleanArray[0]===marker && namedReads===0,
  'clean64 first use inspects keys without observing property values');
gc();
var afterCleanWrites=0,afterCleanThis;
Object.defineProperty(clean,'1',{configurable:true,set:function(value){
  afterCleanWrites++;afterCleanThis=this;check(value===17,'post-clean indexed setter value');gc();
}});
check(cleanArray.push((gc(),17))===2 && afterCleanWrites===1 &&
  afterCleanThis===cleanArray && !Object.hasOwn(cleanArray,'1') && cleanArray[0]===marker &&
  namedReads===0,'an index inserted after clean first use and GC invalidates the live absence proof');

// Keep the sole live index beyond a deleted prefix longer than the scan cap.
// No insertion follows deletion: collection must not turn live-key count into
// the physical ordered-table bound or let an early64-slot scan miss this index.
var tombstones=padded(96),tombstoneArray=[],indexedReads=0;
Object.defineProperty(tombstones,'0',{configurable:true,get:function(){
  indexedReads++;throw 'readonly indexed getter must not be invoked by Set or key scanning';
}});
for(var i=0;i<96;i++)delete tombstones['padding'+i];
Object.setPrototypeOf(tombstoneArray,tombstones);gc();
rejects(function(){tombstoneArray.push(marker);},
  'a late index after96 tombstones requires the full descriptor fallback');
check(tombstoneArray.length===0 && !Object.hasOwn(tombstoneArray,'0') && indexedReads===0 &&
  Reflect.ownKeys(tombstones).join('|')==='0',
  'physical history cannot be replaced by the one live key when classifying a cold prototype');
delete tombstones[0];gc();
check(tombstoneArray.push(marker)===1 && tombstoneArray[0]===marker && indexedReads===0,
  'the conservative large-history fallback still permits append after deletion');
Object.defineProperty(tombstones,'1',{value:'blocked',writable:false,configurable:true});gc();
rejects(function(){tombstoneArray.push(23);},'later insertion after conservative fallback stays observable');
check(tombstoneArray.length===1 && tombstoneArray[0]===marker && !Object.hasOwn(tombstoneArray,'1'),
  'large-history reuse preserves existing data and rejected length');
print('array-push-lazy-key-summary:ok');262;
