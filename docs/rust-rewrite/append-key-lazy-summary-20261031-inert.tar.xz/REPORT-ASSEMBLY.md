# LAZY inert report preparation

build-report.py and package-inert.py are source-only templates. No broad helper,
report main or packager has run during the active native batch.

The assembler binds the 18-file compiled-inputs snapshot, ABI44 and
native-plan.json plus native-final-summary.json. All seven exact normal-two-package scopes must complete with
fresh nonzero matching inventories/transcripts. Counts are derived from those
records; rejected-v1 counts or anticipated new totals are never adopted.
The two builtins filters retain/use/retire the same exact Cargo selector image,
with SHA/size/path/source-map continuity checked. New collector, closed wire
domain, encoded append and lazy lifecycle proof names must actually pass.
The initial native-attempt1.log plan-schema KeyError is preserved as a pre-Cargo
setup attempt, with no native execution verdict.

The final union selects original 00..03 and exact 04..06 "-resume" directories.
Original native 04's storage-deferred receipt is retained as a zero-process
workload-policy event, alongside incomplete start0 and completed start4 summaries.
Source maps must stay identical across the seven actual executions. The
03-to04-resume image chain must preserve exact SHA/size/path/selector before final
retirement. cargo-rlib-cache-relocation.json is a source-unchanged regenerable
Cargo storage event; its recorded byte/hash/path metadata is retained without
opening rlibs or moving/qualifying the scored normal benchmark cache.

Baseline stays Date/a35/ABI42 with its actual 7c47 producer identity and accepted
a9d31 committed-parent 61-input proof. Candidate must be a different fresh own
producer from both that baseline and rejected 6610; ABI44 is bound to its frozen
source. prior-rejection-evidence.json is checked as a separate historical
reference to unchanged public v1 JSON/inert tar hashes, outside the 18 source
inputs and outside new-candidate acceptance. The old artifacts are not rewritten,
retagged, treated as baseline, or nested into the new archive.

The full 21-source/all 3-boundary/eight-round 504-child normal-overlay cohort,
fresh LAZY Node 21 goldens, 36-original Test262 actual variants, own candidate
identity/products/build and explicit Astra status/reviewer/basis/limits/next
decision are required. The original strict analyzer is reused through pure
functions only. Source/producers/sidecars/argv/resources/normal cache/output and
all raw round/group/pooled samples, means, medians and original RSS are checked;
native product/image bytes are never opened or hashed.

A follow-up is optional and not assumed. If Astra later approves one, create
followup-predeclaration.json before timing with:

    {"status":"approved","reviewer":"Astra xhigh","selected_cases":["..."],"followup_driver_sha256":"..."}

At most eight unique original sources are admitted. All three
measurement/controls-normal-{plan,complete,analysis}.json inputs must then exist,
match that approval and the frozen targeted-normal-controls.py hash, and retain
the full cohort's own products/images/cache. The analyzer independently rebuilds
that subset; the wrapper's literal scope annotation is read as inert AST.
Partial/unapproved follow-up evidence fails assembly. No cross-cohort pooling or
replacement is allowed.

The lifecycle contract is Unknown0 initially; only NoIndexed1 bypasses/classifies
later inserts; MayIndexed2 is conservative/sticky. First-use raw-key scan is
bounded by physical LENGTH 64 including tombstones; larger histories cache May
and retain old fallback without entry reads. Dictionary32B/two-edge claims are
recorded only after the actual new collector test passes. The two decimal-key
records per checked index/clear ordinary level remain conditional route
accounting, with no short-string byte, causal RSS or parity inference.

The packager retains inert raw/source/metadata and raw Wasm as data, while pruning
cache/caches/normal-cache/tmp/candidate/failed-native/__pycache__, next drafts,
symlinks and native payload suffix/mode/magic. Prior Date and v1 archives remain
unchanged. Deferred commands, only when root declares inputs/timings complete:

    python3 -B target/performance-append-key-lazy-summary-20261031/build-report.py
    python3 -B scripts/limited_verification.py --cloud -- python3 -B target/performance-append-key-lazy-summary-20261031/package-inert.py append-key-lazy-summary-20261031

report-draft-receipt.json records tiny source hashes and AST checks. Actual
native/Test262/Node/measurement helpers remain unexecuted by this preparation.
