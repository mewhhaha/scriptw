"""Save the existing cheap checks without changing their ordinary failure verdicts."""
import hashlib,json,re,subprocess,sys,time
from pathlib import Path
ROOT=Path.cwd();BASE=ROOT/'target/rsc-property-kernels-20261107'
sys.path[:0]=[str(BASE/'tools'),str(ROOT/'scripts')]
from common import check_source
from limited_verification import require_kernel_budget
from measure_rsc import resources,check_resources
require_kernel_budget(4*1024**3)
source=BASE/'tools/source-corrected-5/manifest.json';check_source(source)
output=BASE/'cheap-final';output.mkdir(exist_ok=False)
report={'complete':False,'all_passed':False,'source_manifest_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'commands':[],'resources_before':resources()}
def save():(output/'receipt.json').write_text(json.dumps(report,indent=2)+'\n')
for name,argv in [('owners',[sys.executable,'-B','scripts/conformance_owners.py']),('format',['cargo','fmt','--all','--','--check']),('intl',[sys.executable,'-B','scripts/intl_source_identities.py']),('diff',['git','diff','--check'])]:
 check_source(source);started=time.monotonic_ns()
 with (output/(name+'.stdout')).open('xb') as out,(output/(name+'.stderr')).open('xb') as err:
  child=subprocess.run(argv,cwd=ROOT,stdout=out,stderr=err,timeout=180)
 row={'name':name,'argv':argv,'exit_code':child.returncode,'elapsed_ns':time.monotonic_ns()-started}
 for suffix in ['stdout','stderr']:row[suffix+'_sha256']=hashlib.sha256((output/(name+'.'+suffix)).read_bytes()).hexdigest()
 report['commands'].append(row);save();print(name,child.returncode,flush=True)
check_source(source);report['resources_after']=resources();check_resources(report['resources_before'],report['resources_after'])
report['format_files']=sorted(set(re.findall(r'^Diff in (.+):\d+:$',(output/'format.stdout').read_text(),re.M)))
report['stale_intl_recipes']=re.findall(r'^FAIL (.+)$',(output/'intl.stdout').read_text(),re.M)
assert [r['exit_code'] for r in report['commands']]==[0,1,1,0]
assert len(report['format_files'])==11 and len(report['stale_intl_recipes'])==14
report['complete']=True;save()
print('OWNERS AND DIFF PASS; ELEVEN FORMATTING FILES AND FOURTEEN STALE INTL RECIPES REMAIN FAILURES',flush=True)
