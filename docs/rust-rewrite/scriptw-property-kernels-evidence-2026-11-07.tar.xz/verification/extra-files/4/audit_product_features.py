"""Compare complete ordinary dependency feature multisets by producer role."""
import collections
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
BASE = Path(__file__).resolve().parent
sys.path[:0] = [str(BASE / 'tools'), str(ROOT / 'scripts')]
from common import check_source, digest, save
from limited_verification import require_kernel_budget


def inventory(path):
    rows = [json.loads(line) for line in path.read_text().splitlines() if line.strip()]
    assert [row['success'] for row in rows if row.get('reason') == 'build-finished'] == [True]
    ordinary = collections.Counter()
    excluded = collections.Counter()
    for row in rows:
        if row.get('reason') != 'compiler-artifact':
            continue
        record = dict(package=row['package_id'], target=row['target'],
                      profile=row['profile'], features=row['features'])
        key = json.dumps(record, sort_keys=True)
        assert type(row['profile']['test']) is bool
        if row['profile']['test'] is True:
            excluded[key] += 1
        else:
            ordinary[key] += 1
    assert ordinary
    return ordinary, excluded


def decoded(counter):
    return [dict(json.loads(key), count=value) for key, value in sorted(counter.items())]


def main():
    require_kernel_budget(4 * 1024**3)
    source = BASE / 'tools/source-corrected-5/manifest.json'
    manifest = check_source(source)
    old = ROOT / 'target/performance-v8-climb-20261104/for-in-set-execution'
    roles = [
        ('ordinary-examples', old / 'build-final-3/pilot-build.stdout', BASE / 'build-initial.stdout'),
        ('ordinary-cli', old / 'build-final-3/cli-only-build.stdout',
         BASE / 'units-and-cli/production-cli-build.stdout'),
    ]
    old_source = old / 'source-final-3/manifest.json'
    paths = [Path(__file__), source, old_source, BASE / 'tools/common.py']
    paths.extend(path for _, before, after in roles for path in (before, after))
    pins = {str(path): digest(path) for path in paths}
    output = BASE / 'product-feature-comparison.json'
    assert not output.exists()
    proof = {'schema': 'scriptw-property-product-feature-comparison-v1', 'complete': False,
             'source_manifest': {'path': str(source), 'sha256': digest(source),
                                 'base_git': manifest['base_git']},
             'baseline_source_manifest': {'path': str(old_source), 'sha256': digest(old_source)},
             'pins': pins, 'roles': [],
             'exclusion_policy': 'Only Cargo artifacts with explicit profile.test=true are excluded on both sides; every excluded package/target/profile/features multiset is retained. All non-test artifacts, including build scripts, dependencies and examples, must match exactly.',
             'limits': 'This compares Cargo package/target/profile/feature multisets by producer role. Source/compiler, executable bytes and test outcomes remain separately qualified identities; matching dependency features does not prove their equality.'}
    save(output, proof)
    try:
        for role, baseline, candidate in roles:
            before, excluded_before = inventory(baseline)
            after, excluded_after = inventory(candidate)
            missing, additional = before - after, after - before
            row = {'role': role,
                   'baseline': {'path': str(baseline), 'sha256': digest(baseline)},
                   'candidate': {'path': str(candidate), 'sha256': digest(candidate)},
                   'baseline_ordinary_artifacts': sum(before.values()),
                   'candidate_ordinary_artifacts': sum(after.values()),
                   'baseline_ordinary_inventory': decoded(before),
                   'candidate_ordinary_inventory': decoded(after),
                   'baseline_excluded_test_inventory': decoded(excluded_before),
                   'candidate_excluded_test_inventory': decoded(excluded_after),
                   'baseline_only': decoded(missing), 'candidate_only': decoded(additional),
                   'ordinary_multiset_matches': not missing and not additional}
            proof['roles'].append(row)
            save(output, proof)
            assert row['ordinary_multiset_matches'], role + ': ordinary dependency feature inventory differs'
        check_source(source)
        for path, expected in pins.items():
            assert digest(path) == expected, 'feature comparison input changed: ' + path
        proof['complete'] = True
    except BaseException as error:
        proof['error'] = repr(error)
        raise
    finally:
        try:
            check_source(source)
            for path, expected in pins.items():
                assert digest(path) == expected, 'feature comparison input changed: ' + path
        except BaseException as error:
            proof.update(complete=False, terminal_verification_error=repr(error))
            raise
        finally:
            save(output, proof)
    print('ORDINARY EXAMPLE AND SEPARATE PRODUCT CLI DEPENDENCY FEATURES MATCH', output, flush=True)


if __name__ == '__main__':
    main()
