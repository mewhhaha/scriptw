"""Qualify the existing inert archive recipe and publish this measured batch."""
import hashlib,json,re,shutil,subprocess,sys,tarfile
from pathlib import Path,PurePosixPath
ROOT=Path(__file__).resolve().parents[3];BASE=ROOT/'target/rsc-property-kernels-20261107';HERE=Path(__file__).resolve().parent
sys.path[:0]=[str(BASE/'tools'),str(ROOT/'scripts')]
from common import check_source
from limited_verification import require_kernel_budget
require_kernel_budget(4*1024**3)
load=lambda p:json.loads(Path(p).read_text())
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def encoded(d):return (json.dumps(d,indent=2,allow_nan=False)+'\n').encode()
source=BASE/'tools/source-corrected-5/manifest.json';manifest=check_source(source)
broad=load(BASE/'broad/receipt.json');units=load(BASE/'units-and-cli/receipt.json');guards=load(BASE/'source-guards-final/receipt.json');cheap=load(BASE/'cheap-final/receipt.json')
assert broad['complete'] and broad['passed']==2535 and broad['source_manifest_sha256']==sha(source)
assert units['complete'] and units['cli_smoke_passed'] and units['ordinary_aot_failures']==4
assert sum(int(s['summary'][1]) for s in units['unit_scopes'])==1757
assert guards['passed'] and sum(len(load(BASE/'source-guards-final'/r['receipt'])['test_inventory']) for r in guards['targets'])==380
assert cheap['complete'] and len(cheap['format_files'])==11 and len(cheap['stale_intl_recipes'])==14
assert load(BASE/'product-feature-comparison.json')['complete']
stage=HERE/'evidence-stage-5'
argv=[sys.executable,'-B',str(HERE/'stage_evidence.py'),'--output-dir',str(stage),'--diagnostics-summary',str(HERE/'attribution-measurement.json'),'--situations-report',str(BASE/'situations-full-1/report.json'),'--situations-dir',str(HERE/'situation-stage'),'--unit-cli-report',str(BASE/'units-and-cli/receipt.json')]
for name in ['sources','tooling','build','logs','manifests']:argv+=['--evidence-dir',str(BASE/'situations-full-1'/name)]
for folder in [BASE/'source-guards-final',BASE/'cheap-final',BASE/'focused-initial',BASE/'frozen-initial',HERE/'docs-stage']:argv+=['--evidence-dir',str(folder)]
for p in [BASE/'frozen-corrected-5/emission-producer.json',BASE/'product-feature-comparison.json',BASE/'run_cheap_final.py',BASE/'run_broad.py',BASE/'audit_product_features.py',Path(__file__)]:argv+=['--evidence-file',str(p)]
subprocess.run(argv,cwd=ROOT,check=True)
ready=load(stage/'publication-ready.json');assert ready['complete'];meta=ready['evidence_archive'];archive=ROOT/meta['file'];assert sha(archive)==meta['sha256'] and archive.stat().st_size==meta['bytes']<128*1024**2
seen=set();index={};reports={};expanded=0;index_bytes=None;sidecar=None
with tarfile.open(archive,'r|xz') as packed:
 for m in packed:
  p=PurePosixPath(m.name);assert m.isfile() and not p.is_absolute() and '..' not in p.parts and str(p)==m.name and '\\' not in m.name and m.name not in seen
  assert m.size<=64*1024**2 and len(seen)<20000;seen.add(m.name);expanded+=m.size;assert expanded<=512*1024**2
  value=packed.extractfile(m).read();value.decode('utf-8');assert b'\0' not in value
  if m.name=='INDEX.json':
   index_bytes=value;d=json.loads(value);assert d['schema']=='scriptw-inert-evidence-index-v1';index={r['path']:r for r in d['members']};assert len(index)==len(d['members'])
  elif m.name=='INDEX.json.sha256':sidecar=value
  else:
   r=index[m.name];assert len(value)==r['bytes'] and hashlib.sha256(value).hexdigest()==r['sha256']
   assert not any(s in m.name for s in ['disk-space-audit','cleanup-1.json','perf.data','callchains.json'])
   if m.name.startswith('reports/'):reports[m.name]=json.loads(value)
assert seen==set(index)|{'INDEX.json','INDEX.json.sha256'}
assert sidecar==(hashlib.sha256(index_bytes).hexdigest()+'  INDEX.json\n').encode()
assert len(seen)==meta['regular_utf8_members'] and expanded==meta['expanded_utf8_bytes']
def reference(path):
 h=sha(path);names=sorted(n for n,r in index.items() if r['sha256']==h);assert names
 return {'archive_member':names[0],'sha256':h}
coverage={'broad':{'passed':2535,'scopes':12,**reference(BASE/'broad/receipt.json')},'units':{'passed':1757,'failed':4,**reference(BASE/'units-and-cli/receipt.json')},'source_guards':{'passed':380,**reference(BASE/'source-guards-final/receipt.json')},'production_cli_smokes':8,'dependency_features':reference(BASE/'product-feature-comparison.json'),'formatting_failed_files':11,'stale_intl_recipes':14,'cheap_checks':reference(BASE/'cheap-final/receipt.json'),'full_workspace_ci_rerun':False,'full_test262_rerun':False}
canonical_meta={k:v for k,v in meta.items() if k!='canonical_file'};canonical_meta['file']=meta['canonical_file']
dest=ROOT/canonical_meta['file'];assert not dest.exists();shutil.copyfile(archive,dest);assert sha(dest)==meta['sha256']
for name in ready['reports']:
 d=load(stage/name);assert sha(stage/name)==ready['reports'][name]
 raw=reports['reports/'+name]
 for k,v in raw.items():assert d[k]==v
 d.pop('staging',None);d['evidence_archive']=canonical_meta
 pub=d.setdefault('publication',{});pub['status']='published-measurements';pub['evidence_archive']=canonical_meta;pub['verification']=coverage
 d['complete_archived_report']={'archive_member':'reports/'+name,'sha256':index['reports/'+name]['sha256']}
 (ROOT/'docs/rust-rewrite'/name).write_bytes(encoded(d))
base=manifest['base_git']
before=subprocess.check_output(['git','show',base+':README.md'],cwd=ROOT)
after=(HERE/'docs-stage/README.md').read_bytes()
for marker in ['runtime-comparison','application-benchmarks','scriptw-status','scriptw-test-graph']:
 pattern=re.compile(rb'<!-- '+marker.encode()+rb':start -->.*?<!-- '+marker.encode()+rb':end -->',re.S);assert pattern.search(before).group()==pattern.search(after).group()
for staged,canonical in [('README.md','README.md'),('benchmarks.md','docs/rust-rewrite/benchmarks.md'),('current-inventory.md','docs/rust-rewrite/current-inventory.md')]:shutil.copyfile(HERE/'docs-stage'/staged,ROOT/canonical)
for relative,record in manifest['files'].items():
 if relative.startswith('crates/'):assert sha(ROOT/relative)==record['sha256']
for relative in ['docs/rust-rewrite/test262-current.md','docs/rust-rewrite/assets/test262-status.svg','docs/rust-rewrite/for-in-width-current.json','docs/rust-rewrite/assets/situations-current/enumeration-width.svg','docs/rust-rewrite/react-allocation-current.json','docs/rust-rewrite/rsc-wasm-size-current.json']:
 assert (ROOT/relative).read_bytes()==subprocess.check_output(['git','show',base+':'+relative],cwd=ROOT)
receipt={'complete':True,'archive':canonical_meta,'reports':{name:sha(ROOT/'docs/rust-rewrite'/name) for name in ready['reports']},'source_manifest_sha256':sha(source),'coverage':coverage,'charts_pending':True}
(HERE/'canonical-publication.json').write_bytes(encoded(receipt));print(json.dumps({'complete':True,'archive':canonical_meta,'native_passed':4292,'known_unit_failures':4},indent=2))
