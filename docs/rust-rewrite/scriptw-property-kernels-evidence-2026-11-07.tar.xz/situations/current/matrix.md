# Focused situation score matrix (staged)

Measured 2026-11-07 on source fingerprint `5aa48ad8a545934f090cc46c13e18d6e56ac76098bbfe8e0a56eb345b9677044`. The fresh report has 21 standalone Wasm programs, 504 processes across Fast, Speed and V8, 60,984 checked invocations, 100 warmups and 21 measured samples per process. Each score is the median of eight process medians; parenthesized bounds are the low and high process medians.

| Program · retained call | Fast · ms (min–max) | Speed · ms (min–max) | V8 · ms (min–max) |
| --- | ---: | ---: | ---: |
| `control-empty.js` | 0.005746 (0.005511–0.005821) | 0.005666 (0.00547–0.008076) | 0.000396 (0.00032–0.000651) |
| `global-shallow.js` | 2.46178 (2.35319–2.53774) | 1.92994 (1.8843–2.05057) | 1.04968 (1.00612–1.12646) |
| `global-deep8.js` | 3.03218 (2.90592–4.70527) | 2.23049 (2.15686–3.49229) | 1.04976 (1.01969–1.06661) |
| `global-bound-deep.js` | 0.744395 (0.734556–1.18857) | 0.250296 (0.246549–0.386234) | 0.0043885 (0.004057–0.004569) |
| `global-getter-deep.js` | 3.24457 (3.20062–3.41698) | 2.37507 (2.3347–3.76318) | 1.06291 (1.01748–1.65908) |
| `frame-compact.js` | 8.7721 (8.53053–8.99351) | 6.30566 (5.90659–6.3776) | 0.062223 (0.058031–0.065795) |
| `frame-branches32.js` | 8.84522 (8.37242–9.05276) | 6.22213 (6.14695–6.72681) | 0.0877265 (0.083689–0.094289) |
| `frame-branches128.js` | 9.32291 (8.88799–9.566) | 6.39185 (6.09376–6.49944) | 0.119502 (0.116472–0.122052) |
| `frame-branches512.js` | 13.9557 (12.7559–15.659) | 6.72274 (6.28497–6.9875) | 0.191324 (0.187367–0.206001) |
| `args-unused.js` | 0.694215 (0.68355–0.717826) | 0.401548 (0.395523–0.409358) | 0.003367 (0.003316–0.008437) |
| `args-observed.js` | 1.20796 (1.17583–1.70244) | 0.845263 (0.826983–0.89376) | 0.003271 (0.003256–0.003336) |
| `property-stable.js` | 0.163932 (0.16316–0.165434) | 0.0779335 (0.076976–0.15254) | 0.0773925 (0.076636–0.147881) |
| `property-mutated.js` | 0.162504 (0.160385–0.167318) | 0.0791355 (0.078109–0.081075) | 0.0670225 (0.066015–0.070364) |
| `metadata-ordinary.js` | 0.214107 (0.211732–0.215971) | 0.088013 (0.086234–0.08928) | 0.013155 (0.013054–0.016411) |
| `metadata-function.js` | 0.210325 (0.20501–0.215871) | 0.087962 (0.085483–0.08911) | 0.220034 (0.219618–0.223996) |
| `metadata-intrinsic.js` | 0.228174 (0.210661–0.24165) | 0.0911485 (0.083779–0.092616) | 0.235277 (0.224116–0.253031) |
| `typeof-dispatch.js` | 1.03294 (0.96748–1.24739) | 0.405637 (0.390803–0.413266) | 0.014878 (0.013976–0.028053) |
| `singleton-dispatch.js` | 0.978796 (0.972228–1.35512) | 0.427288 (0.418355–0.595803) | 0.0114165 (0.006783–0.013836) |
| `strict-equality-numbers.js` | 0.0873505 (0.085994–0.08909) | 0.03674 (0.036059–0.037551) | 0.0128545 (0.011782–0.013406) |
| `strict-equality-mixed.js` | 0.095011 (0.093829–0.097125) | 0.0418195 (0.040767–0.069382) | 0.03692 (0.036329–0.038112) |
| `for-in-wide.js` | 0.690513 (0.67816–1.01317) | 0.609815 (0.589922–0.853833) | 0.039831 (0.038583–0.044915) |

These charts use only the current Fast, Speed and V8 actors; they do not show a before/after series.
The fixed-yield for-in width panel is historical and retains its earlier source/archive identity; it was not rerun on this source.

No broad conformance or pinned Test262 claim follows from this focused situation matrix.
