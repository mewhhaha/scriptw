#!/usr/bin/env python3
"""Excluded Linux x86-64 task-bound instruction-entry counts; no guest mutation."""
import argparse
import ctypes
import fcntl
import hashlib
import json
import os
from pathlib import Path
import platform
import socket
import struct
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'scripts'))
from limited_verification import kernel_group, limited_environment, require_kernel_budget
from request_profile_support import line, thread_record
from profile_thread import barrier_caller

ORIGINAL = ROOT / 'target/performance-v8-climb-20261104/entry-breakpoints-staged'
ADAPTATION = HERE / 'count_source_entries.adaptation.json'

CONTROLS = [('direct', [37, 0]), ('indirect', [17, 0]), ('recursive', [66, 0]),
            ('tail', [13, 13]), ('two_addresses', [24, 17]), ('zero', [0, 0]),
            ('disabled', [0, 0]), ('burst', [4096, 0])]


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def load(path):
    return json.loads(Path(path).read_text())


def save(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


class Breakpoint:
    def __init__(self, tid, address):
        # Pinned Linux perf_event_attr v1 (72 bytes), x86-64 syscall 298.
        # sample_period=0: count only; no mmap/ringbuffer/per-hit records.
        # disabled, pinned, exclude_kernel, exclude_hv; inherit/freq/sigtrap=0.
        flags = (1 << 0) | (1 << 2) | (1 << 5) | (1 << 6)
        self.attr = struct.pack('<IIQQQQQIIQQ', 5, 72, 0, 0, 0, 3, flags, 0, 4, address, ctypes.sizeof(ctypes.c_long))
        assert len(self.attr) == 72
        libc = ctypes.CDLL(None, use_errno=True)
        libc.syscall.restype = ctypes.c_long
        buffer = ctypes.create_string_buffer(self.attr)
        fd = libc.syscall(ctypes.c_long(298), ctypes.byref(buffer), ctypes.c_int(tid),
                          ctypes.c_int(-1), ctypes.c_int(-1), ctypes.c_ulong(8))
        if fd < 0:
            error = ctypes.get_errno()
            raise OSError(error, os.strerror(error), 'perf_event_open hardware execute breakpoint')
        self.fd = fd

    def read(self):
        raw = os.read(self.fd, 24)
        assert len(raw) == 24, 'unscheduled/error-state pinned breakpoint'
        return list(struct.unpack('<QQQ', raw))

    def start(self, enabled):
        fcntl.ioctl(self.fd, 0x2401, 0)  # DISABLE
        fcntl.ioctl(self.fd, 0x2403, 0)  # RESET count; times remain cumulative
        self.before = self.read()
        assert self.before[0] == 0
        if enabled:
            fcntl.ioctl(self.fd, 0x2400, 0)  # ENABLE

    def stop(self, enabled):
        fcntl.ioctl(self.fd, 0x2401, 0)
        after = self.read()
        elapsed = [after[index] - self.before[index] for index in range(3)]
        assert min(elapsed) >= 0
        count, active, running = elapsed
        assert active == running, 'multiplexed/unscheduled event; never scale counts'
        if enabled:
            assert running > 0, 'event never ran'
        else:
            assert elapsed == [0, 0, 0], 'disabled event changed'
        return {'count': count, 'time_enabled_ns': active, 'time_running_ns': running,
                'before': self.before, 'after': after}

    def close(self):
        os.close(self.fd)


def executable_mapping(pid, address):
    matches = []
    for raw in Path(f'/proc/{pid}/maps').read_text().splitlines():
        interval, permissions, *_ = raw.split()
        start, end = [int(value, 16) for value in interval.split('-')]
        if start <= address < end:
            assert 'x' in permissions, ('entry address is not executable', raw)
            matches.append(raw)
    assert len(matches) == 1
    return matches[0]


def prefix(pid, address):
    class IOVec(ctypes.Structure):
        _fields_ = [('base', ctypes.c_void_p), ('length', ctypes.c_size_t)]
    data = ctypes.create_string_buffer(32)
    local = IOVec(ctypes.cast(data, ctypes.c_void_p), len(data))
    remote = IOVec(address, len(data))
    libc = ctypes.CDLL(None, use_errno=True)
    libc.process_vm_readv.restype = ctypes.c_ssize_t
    count = libc.process_vm_readv(pid, ctypes.byref(local), 1, ctypes.byref(remote), 1, 0)
    assert count == len(data), ('cannot authenticate own child entry bytes', ctypes.get_errno())
    return bytes(data).hex()


def source_entries(pid, folder, phase, targets, started_ns):
    path = Path(f'/tmp/perf-{pid}.map')
    assert path.stat().st_mtime_ns >= started_ns, 'stale perf map'
    raw = path.read_bytes()
    (folder / f'perf-{phase}.map').write_bytes(raw)
    entries = []
    for row in raw.decode().splitlines():
        address, size, name = row.split(maxsplit=2)
        entries.append({'address': int(address, 16), 'size': int(size, 16), 'name': name})
    selected = []
    for name in targets:
        family = [entry for entry in entries if entry['name'] == name or
                  entry['name'].startswith(name + '.') or entry['name'].startswith(name + ' ')]
        assert len(family) == 1 and family[0]['name'] == name, ('entry aliases/clones require a new plan', family)
        entry = family[0]
        assert entry['size'] > 0
        overlaps = [other for other in entries if
                    other['address'] < entry['address'] + entry['size'] and
                    entry['address'] < other['address'] + other['size']]
        assert overlaps == [entry], ('ambiguous perf map entry', overlaps)
        selected.append(entry | {'mapping': executable_mapping(pid, entry['address']),
                                 'prefix_hex': prefix(pid, entry['address'])})
    assert len({entry['address'] for entry in selected}) == len(targets)
    return selected


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--mode', choices=['control', 'sync', 'async'], required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--binary', type=Path, required=True)
    parser.add_argument('--baseline-json', type=Path, required=True)
    parser.add_argument('--target', action='append', default=[])
    parser.add_argument('--controls-receipt', type=Path)
    parser.add_argument('--samples', type=int, default=7)
    return parser.parse_args()


def run(args):
    assert platform.system() == 'Linux' and platform.machine() == 'x86_64'
    require_kernel_budget(4 * 1024**3)
    assert len(os.sched_getaffinity(0)) == 1
    assert 1 <= args.samples <= 20
    controls = args.mode == 'control'
    if not controls:
        assert 1 <= len(args.target) <= 4 and len(set(args.target)) == len(args.target)
        assert all(name.startswith(('helper::', 'builtin::', 'js::')) and not any(c.isspace() for c in name) for name in args.target)
    adaptation = load(ADAPTATION)
    assert digest(__file__) == adaptation['adapted_sha256']
    for name, expected in adaptation['original_files_sha256'].items():
        assert digest(ORIGINAL / name) == expected, name
    pins = load(ORIGINAL / 'prepared.json')
    control_producer = load(ORIGINAL / 'control-producer.json')
    assert control_producer['exit_code'] == 0
    assert control_producer['prepared_sha256'] == digest(ORIGINAL / 'prepared.json')
    assert control_producer['source_sha256'] == digest(ORIGINAL / 'controls.rs')
    assert control_producer['binary_sha256'] == digest(ORIGINAL / 'controls')
    for name in ('count_entries.py', 'controls.rs', 'build_controls.py'):
        assert pins['sha256'][str(ORIGINAL / name)] == digest(ORIGINAL / name)
    assert Path('/sys/bus/event_source/devices/breakpoint/type').read_text().strip() == '5'
    baseline_path = args.baseline_json.resolve(strict=True)
    baseline = load(baseline_path)
    executable = args.binary.resolve(strict=True)
    assert digest(executable) == baseline['executable_sha256']
    for name in ('source', 'support'):
        assert digest(baseline['inputs'][name]) == baseline['inputs'][name + '_sha256']
    if not controls:
        assert args.controls_receipt is not None, 'fresh controls receipt required'
        passed = load(args.controls_receipt)
        assert passed['status'] == 'complete' and passed['complete'] is True and passed['known_count_windows'] == 8
        assert passed['driver_sha256'] == digest(__file__)
        assert passed['kernel_release'] == platform.release()
        assert passed['kernel_boot_id'] == Path('/proc/sys/kernel/random/boot_id').read_text().strip()
        assert passed['control_binary_sha256'] == control_producer['binary_sha256']
        assert passed['control_producer_sha256'] == digest(ORIGINAL / 'control-producer.json')
        assert passed['execution_target'] == 'authenticated-caller-socket'
    folder = args.output.resolve()
    folder.mkdir(exist_ok=False)
    nonce = os.urandom(16).hex()
    parent, child_socket = socket.socketpair()
    control_fd, control_inode = child_socket.fileno(), os.fstat(child_socket.fileno()).st_ino
    env = limited_environment()
    assert not any(key.startswith('SCRIPTW_RSC_PROFILE_') for key in env)
    assert 'LD_PRELOAD' not in env and 'LD_AUDIT' not in env
    env.update(SCRIPTW_RSC_PROFILE_FD=str(child_socket.fileno()), SCRIPTW_RSC_PROFILE_NONCE=nonce)
    samples, warmups = args.samples, 3
    if controls:
        binary = ORIGINAL / 'controls'
        samples, warmups = len(CONTROLS), 0
        argv = [str(binary), str(folder / 'observations.json')]
    else:
        binary = executable
        env['SCRIPTW_RSC_PROFILE_MODE'] = args.mode
        argv = [str(binary), baseline['inputs']['source'], baseline['inputs']['support'],
                str(folder / 'observations.json'), str(samples), str(warmups), baseline['native_mode']]
    controls_receipt_sha256 = None
    if args.controls_receipt is not None:
        controls_receipt_sha256 = digest(args.controls_receipt)
    result = {'complete': False, 'status': 'incomplete', 'unscored': True, 'mode': args.mode,
              'driver_sha256': digest(__file__), 'prepared_sha256': digest(ORIGINAL / 'prepared.json'),
              'kernel_release': platform.release(), 'kernel_boot_id': Path('/proc/sys/kernel/random/boot_id').read_text().strip(),
              'control_producer_sha256': digest(ORIGINAL / 'control-producer.json'),
              'baseline_sha256': digest(baseline_path), 'targets': args.target,
              'controls_receipt_sha256': controls_receipt_sha256,
              'execution_target': 'authenticated-caller-socket',
              'thread_authenticator_sha256': digest(HERE / 'profile_thread.py'),
              'protocol_helpers_sha256': digest(HERE / 'request_profile_support.py'),
              'nonce': nonce, 'argv': argv,
              'binary_sha256': digest(binary), 'windows': [],
              'event': {'type': 5, 'bp_type': 4, 'bp_len': ctypes.sizeof(ctypes.c_long), 'sample_period': 0,
                        'pinned': True, 'inherit': False, 'user_only': True, 'cpu': -1},
              'limits': 'Only authenticated caller TID; no inherited threads. Control socket edges are within the window. Excluded counting experiment; #DB per entry perturbs execution. No timing, allocation or speedup claim. Counts are attempted native entries, including proper-tail entries; no extrapolation to actual argument boxing.',
              'environment': {name: Path(path).read_text().strip() for name, path in {
                  'perf_event_paranoid': '/proc/sys/kernel/perf_event_paranoid',
                  'nmi_watchdog': '/proc/sys/kernel/nmi_watchdog'}.items()},
              'resources_before': {name: (kernel_group() / name).read_text() for name in
                                   ['memory.max', 'memory.swap.max', 'memory.oom.group', 'cpu.max', 'memory.events']}}
    child, events = None, []
    deadline = time.monotonic() + 600
    preexisting_maps = set(Path('/tmp').glob('perf-*.map'))
    try:
        with (folder / 'host.stdout').open('xb') as out, (folder / 'host.stderr').open('xb') as err:
            started_ns = time.time_ns()
            child = subprocess.Popen(argv, cwd=ROOT, env=env, stdin=subprocess.DEVNULL,
                                     stdout=out, stderr=err, pass_fds=(child_socket.fileno(),))
            child_socket.close()
            result['pid'] = child.pid
            assert Path(f'/tmp/perf-{child.pid}.map') not in preexisting_maps, 'preexisting PID perf map'
            metadata = None
            if controls:
                raw = line(parent.fileno(), 30)
                words = raw.strip().split()
                assert len(words) == 6 and words[:2] == ['SWBP1', nonce]
                assert int(words[2]) == child.pid
                metadata = {'tid': int(words[3]), 'addresses': [int(word, 16) for word in words[4:]]}
                assert len(set(metadata['addresses'])) == 2
                result['control_metadata'] = metadata
            for index in range(warmups, warmups + samples):
                enabled = True
                if controls and CONTROLS[index][0] == 'disabled':
                    enabled = False
                for phase in ['ready', 'done']:
                    timeout = min(60, deadline - time.monotonic())
                    assert timeout > 0
                    raw = line(parent.fileno(), timeout)
                    expected = f'SWRSC1 {nonce} {phase} {args.mode} {index}\n'
                    assert raw == expected, (raw, expected)
                    if not events:
                        actual_worker = barrier_caller(child.pid, control_fd, control_inode, thread_record)
                        result['worker_before'] = actual_worker
                        (folder / 'maps-before.txt').write_text(Path(f'/proc/{child.pid}/maps').read_text())
                        if controls:
                            assert metadata['tid'] == actual_worker['tid']
                            entries = [{'name': name, 'address': address,
                                        'mapping': executable_mapping(child.pid, address),
                                        'prefix_hex': prefix(child.pid, address)}
                                       for name, address in zip(['breakpoint_a', 'breakpoint_b'], metadata['addresses'])]
                        else:
                            entries = source_entries(child.pid, folder, 'before', args.target, started_ns)
                        result['entries'] = entries
                        for entry in entries:
                            event = Breakpoint(actual_worker['tid'], entry['address'])
                            events.append(event)
                            entry['perf_attr_hex'] = event.attr.hex()
                    authenticated = barrier_caller(child.pid, control_fd, control_inode, thread_record)
                    assert authenticated['tid'] == actual_worker['tid']
                    assert authenticated['starttime_ticks'] == actual_worker['starttime_ticks']
                    result.setdefault('barriers', []).append({'phase': phase, 'index': index, 'caller': authenticated})
                    if phase == 'ready':
                        for event in events:
                            event.start(enabled)
                    else:
                        counts = [event.stop(enabled) for event in events]
                        window = {'index': index, 'enabled': enabled, 'events': counts}
                        result['windows'].append(window)
                        if controls:
                            name, wanted = CONTROLS[index]
                            window.update(name=name, expected_counts=wanted)
                            assert [event['count'] for event in counts] == wanted, window
                        if index + 1 == warmups + samples:
                            after = barrier_caller(child.pid, control_fd, control_inode, thread_record)
                            assert after['tid'] == actual_worker['tid']
                            assert after['starttime_ticks'] == actual_worker['starttime_ticks']
                            result['worker_after'] = after
                            (folder / 'maps-after.txt').write_text(Path(f'/proc/{child.pid}/maps').read_text())
                            if controls:
                                after_entries = [{'name': entry['name'], 'address': entry['address'],
                                                  'mapping': executable_mapping(child.pid, entry['address']),
                                                  'prefix_hex': prefix(child.pid, entry['address'])} for entry in entries]
                                result['entries_after'] = after_entries
                                assert after_entries == [{key: value for key, value in entry.items() if key != 'perf_attr_hex'} for entry in entries]
                            if not controls:
                                after_entries = source_entries(child.pid, folder, 'after', args.target, started_ns)
                                result['entries_after'] = after_entries
                                assert after_entries == [{key: value for key, value in entry.items()
                                                          if key != 'perf_attr_hex'} for entry in entries]
                    parent.sendall(expected.replace('SWRSC1', 'SWACK1', 1).encode())
            result['exit_code'] = child.wait(timeout=max(1, min(30, deadline - time.monotonic())))
        assert result['exit_code'] == 0
        report = load(folder / 'observations.json')
        if controls:
            assert report == {'complete': True, 'windows': 8, 'checksums_checked': 8}
            result['known_count_windows'] = 8
            result['control_binary_sha256'] = digest(binary)
        else:
            assert report['profiling']['nonce'] == nonce
            assert report['profiling']['windows'] == samples
            assert report['profiling']['excluded_from_scored_cohorts'] is True
            for key in ['inputs', 'program_wasm_sha256', 'program_wasm_bytes', 'runtime', 'configuration',
                        'source_fingerprint', 'executable_sha256', 'native_mode']:
                assert report[key] == baseline[key], key
            assert len(report['cases']) == 1
            case = report['cases'][0]
            assert case['case'] == 'rsc-' + args.mode and case['exact_node_output_checked']
            assert case['samples'] == samples and case['warmups'] == warmups
            assert len(case['observations']) == samples + warmups
            golden = next(item for item in baseline['cases'] if item['case'] == case['case'])
            for key in ('expected_json_sha256', 'expected_json_bytes'):
                assert case[key] == golden[key], key
            for index, observation in enumerate(case['observations']):
                assert observation['index'] == index and observation['warmup'] == (index < warmups)
            result['exact_flight_checks'] = len(case['observations'])
            result['program_wasm_sha256'] = report['program_wasm_sha256']
            result['runtime'] = report['runtime']
            result['source_fingerprint'] = report['source_fingerprint']
        assert digest(executable) == baseline['executable_sha256']
        for name in ('source', 'support'):
            assert digest(baseline['inputs'][name]) == baseline['inputs'][name + '_sha256']
        result['complete'] = True
        result['status'] = 'complete'
    except BaseException as error:
        result['error'] = repr(error)
        result['status'] = 'failed'
        raise
    finally:
        for event in events:
            event.close()
        if child is not None and child.poll() is None:
            child.kill()
            child.wait(timeout=5)
        parent.close()
        child_socket.close()
        result['resources_after'] = {name: (kernel_group() / name).read_text() for name in
                                     ['memory.events', 'memory.current']}
        result['raw_files'] = {path.name: {'sha256': digest(path), 'bytes': path.stat().st_size}
                               for path in folder.iterdir() if path.is_file()}
        save(folder / 'receipt.json', result)
    print(json.dumps({'status': result['status'], 'output': str(folder)}))


def main():
    args = parse_args()
    folder = args.output.resolve()
    owned_output = not folder.exists()
    try:
        assert owned_output, 'output directory already exists'
        run(args)
    except BaseException as error:
        if owned_output:
            folder.mkdir(exist_ok=True)
            if not (folder / 'receipt.json').exists():
                save(folder / 'receipt.json', {'complete': False, 'status': 'failed',
                     'unscored': True, 'mode': args.mode, 'driver_sha256': digest(__file__),
                     'error': repr(error), 'phase': 'preflight'})
        raise


if __name__ == '__main__':
    main()
