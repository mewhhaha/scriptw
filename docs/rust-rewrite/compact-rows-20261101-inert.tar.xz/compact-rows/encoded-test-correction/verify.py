from pathlib import Path
import json,subprocess,sys,time
root=Path.cwd();out=root/'target/performance-compact-rows';d=out/'encoded-test-correction';sys.path.insert(0,str(root/'scripts'))
from benchmark_metrics import digest
from native_test_protocol import parse_inventory,result_summaries
rows=[json.loads(line) for line in (d/'build.jsonl').read_text().splitlines()];assert rows[-1]=={'reason':'build-finished','success':True}
producer=next(r for r in rows if r.get('reason')=='compiler-artifact' and r.get('executable') and r['profile']['test'] and r['target']['name']=='scriptw_aot_wasm');exe=Path(producer['executable']);exe_sha=digest(exe);inventory=parse_inventory(subprocess.check_output([exe,'--list'],text=True));correction=json.loads((d/'correction.json').read_text());records=[]
for index,name in enumerate(correction['corrected_exact_tests']):
 assert name in inventory
 argv=[str(exe),'--exact',name,'--test-threads=1','--nocapture'];stdout=d/f'corrected-{index}.stdout';stderr=d/f'corrected-{index}.stderr';started=time.monotonic()
 with stdout.open('xb') as a,stderr.open('xb') as b:result=subprocess.run(argv,stdout=a,stderr=b,timeout=600)
 summaries=result_summaries(stdout.read_text());passed=result.returncode==0 and summaries==[('ok','1','0','0','0',str(len(inventory)-1))]
 records.append(dict(target='scriptw_aot_wasm',selected_inventory=[name],executable=str(exe),executable_sha256=exe_sha,producer=producer,argv=argv,stdout=str(stdout),stderr=str(stderr),exit_code=result.returncode,timed_out=False,summaries=summaries,passed=passed,elapsed_seconds=time.monotonic()-started))
 (d/'corrected-receipt.json').write_text(json.dumps(records,indent=2)+'\n');print(name,passed,summaries,flush=True)
subprocess.run(['cp','--reflink=auto',str(exe),str(d/'corrected-backend-tests')],check=True);assert digest(d/'corrected-backend-tests')==exe_sha
source=json.loads((out/'pre-build-sources.json').read_text())['files'];changed=[p for p,h in source.items() if digest(root/p)!=h];assert changed==[correction['file']];assert digest(root/correction['file'])==correction['corrected_sha256']
for key,row in json.loads((out/'candidate/products.json').read_text()).items():assert digest(out/'candidate'/key)==row['sha256']
(d/'production-reuse.json').write_text(json.dumps(dict(status='unchanged production; one excluded test-only classifier correction',source_fingerprint=correction['candidate_source_fingerprint'],changed_source_paths=changed,excluded_by='compiler_fingerprint.rs TEST_ONLY_INPUTS crates/scriptw-aot-wasm/src/tests',corrected_source_sha256=correction['corrected_sha256']),indent=2)+'\n')
assert all(r['passed'] for r in records)
