"""Freeze the four candidate hosts and require unchanged ABI-42 R modules."""
import hashlib
import json
from pathlib import Path
import struct
import subprocess

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load(path):
    return json.loads(Path(path).read_text())


def save_new(path, value):
    with Path(path).open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")


def package_details(path, expected_fingerprint):
    package = Path(path).read_bytes()
    assert package[:8] == b"SCRWRB01"
    assert struct.unpack_from("<I", package, 8)[0] == 42
    assert package[12:44].hex() == expected_fingerprint
    module = package[136:-32]
    assert len(module) == struct.unpack_from("<Q", package, 128)[0]
    assert hashlib.sha256(package[:-32]).digest() == package[-32:]
    return dict(package_sha256=hashlib.sha256(package).hexdigest(), package_bytes=len(package),
        runtime_abi=42, runtime_wasm_sha256=hashlib.sha256(module).hexdigest(),
        runtime_wasm_bytes=len(module)), module


def find_candidate_runtime_build(fingerprint):
    candidates = []
    for output in (ROOT / "target/release/build").glob("scriptw-runtime-image-*/out"):
        package = output / "scriptw-runtime-package.bin"
        portable = output / "scriptw-runtime-portable-package.bin"
        if not package.is_file() or not portable.is_file():
            continue
        try:
            standard = package.read_bytes()
            portable_bytes = portable.read_bytes()
        except OSError:
            continue
        if (standard[:8] == b"SCRWRB01" and standard[12:44].hex() == fingerprint
            and portable_bytes[:8] == b"SCRWRB01" and portable_bytes[12:44].hex() == fingerprint):
            candidates.append(output)
    assert len(candidates) == 1, f"expected one candidate runtime build directory, found {candidates}"
    return candidates[0]


def main():
    destination = OUT / "candidate"
    assert not destination.exists(), "candidate freeze is single-use; preserve any previous output"
    destination.mkdir()
    products = {}
    for name in ["scriptw", "runtime_baseline", "compiler_precompiled_baseline", "wasi_baseline"]:
        source = ROOT / "target/release/examples" / name
        if name == "scriptw":
            source = ROOT / "target/release/scriptw"
        path = destination / name
        subprocess.run(["cp", "--reflink=auto", "--preserve=mode,timestamps", source, path], check=True)
        assert path.is_file() and not path.is_symlink() and path.stat().st_nlink == 1
        products[name] = dict(sha256=digest(path), bytes=path.stat().st_size)
    with (destination / "identity.stdout").open("xb") as stdout, (destination / "identity.stderr").open("xb") as stderr:
        subprocess.run([destination / "compiler_precompiled_baseline", "identity"], cwd=ROOT,
            stdout=stdout, stderr=stderr, check=True)
    identity = load(destination / "identity.stdout")
    assert identity["executable_sha256"] == products["compiler_precompiled_baseline"]["sha256"]
    save_new(destination / "identity.json", identity)
    save_new(destination / "products.json", products)
    save_new(destination / "host-products.json", products)

    source_record = load(OUT / "pre-build-sources.json")
    for name, expected in source_record["files"].items():
        assert digest(ROOT / name) == expected, f"build input changed since preflight: {name}"
    patch = subprocess.check_output(["git", "diff", "HEAD", "--binary"], cwd=ROOT)
    for name in source_record["files"]:
        tracked = subprocess.run(["git", "ls-files", "--error-unmatch", "--", name],
            cwd=ROOT, capture_output=True)
        if tracked.returncode:
            added = subprocess.run(["git", "diff", "--no-index", "--binary", "--", "/dev/null", name],
                cwd=ROOT, capture_output=True)
            assert added.returncode == 1, f"could not capture untracked source: {name}"
            patch += added.stdout
    (destination / "source.patch").write_bytes(patch)
    save_new(destination / "source.json", dict(head=identity["source_commit"],
        patch_sha256=hashlib.sha256(patch).hexdigest(), fingerprint=identity["source_fingerprint"]))
    save_new(destination / "source-files.json", source_record["files"])

    output = find_candidate_runtime_build(identity["source_fingerprint"])
    frozen_runtime = destination / "runtime-build"
    frozen_runtime.mkdir()
    baseline_runtime = OUT / "baseline/runtime-build"
    profiles = {}
    for profile, package_name, native_name in [
        ("standard", "scriptw-runtime-package.bin", "scriptw-runtime-native.bin"),
        ("portable", "scriptw-runtime-portable-package.bin", "scriptw-runtime-portable-native.bin"),
    ]:
        source_package = output / package_name
        source_native = output / native_name
        assert source_package.is_file() and source_native.is_file()
        for name, source in [(package_name, source_package), (native_name, source_native)]:
            subprocess.run(["cp", "--reflink=auto", source, frozen_runtime / name], check=True)
        candidate_package, candidate_wasm = package_details(frozen_runtime / package_name,
            identity["source_fingerprint"])
        baseline_package, baseline_wasm = package_details(baseline_runtime / package_name,
            load(OUT / "baseline/identity.json")["source_fingerprint"])
        assert candidate_wasm == baseline_wasm, f"R Wasm changed in {profile} profile"
        profiles[profile] = dict(runtime_abi=42,
            candidate_package=candidate_package, baseline_package=baseline_package,
            runtime_wasm_identical=True,
            candidate_native_sha256=digest(frozen_runtime / native_name),
            baseline_native_sha256=digest(baseline_runtime / native_name),
            native_identical=digest(frozen_runtime / native_name) == digest(baseline_runtime / native_name))
    save_new(OUT / "runtime-invariance.json", dict(status="verified",
        baseline_source_fingerprint=load(OUT / "baseline/identity.json")["source_fingerprint"],
        candidate_source_fingerprint=identity["source_fingerprint"], profiles={
            profile: dict(runtime_abi=row["runtime_abi"],
                baseline_wasm_sha256=row["baseline_package"]["runtime_wasm_sha256"],
                candidate_wasm_sha256=row["candidate_package"]["runtime_wasm_sha256"],
                runtime_wasm_identical=row["runtime_wasm_identical"],
                baseline_package=row["baseline_package"], candidate_package=row["candidate_package"],
                native_identical=row["native_identical"],
                baseline_native_sha256=row["baseline_native_sha256"],
                candidate_native_sha256=row["candidate_native_sha256"])
            for profile, row in profiles.items()},
        candidate_runtime_build_dir=str(output.relative_to(ROOT))))
    print(json.dumps(dict(source_fingerprint=identity["source_fingerprint"],
        products=products, runtime_invariance=profiles), indent=2))


if __name__ == "__main__":
    main()
