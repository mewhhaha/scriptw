function sum(rows) { 'use strict'; var total=0; for (var i=0; i<rows.length; i++) total += rows[i].values[0]; return total; }
var rows=[{values:[1]}, {values:new Array(1)}, {values:[3]}];
print(Number.isNaN(sum(rows)));
