function makeRow(x) { return {x:x, y:1}; }
function sum(rows) { 'use strict'; var total=0; for (var i=0; i<rows.length; i++) total += rows[i].x + rows[i].y; return total; }
var rows=[]; for (var i=0; i<512; i++) rows.push(makeRow(i)); rows[511]={x:511,y:1,z:0};
print(sum(rows) === 131328);
