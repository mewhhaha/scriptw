function makeRow(x) { return {x:x, y:1}; }
function sum(rows) { 'use strict'; var total=0; for (var i=0; i<rows.length; i++) total += rows[i].x + rows[i].y; return total; }
print(sum([makeRow(4)]) === 5);
