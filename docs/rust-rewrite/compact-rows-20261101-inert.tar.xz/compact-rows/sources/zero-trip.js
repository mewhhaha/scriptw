function sum(rows, start) { 'use strict'; var total=0; for (var i=start; i<rows.length; i++) total += rows[i].x + rows[i].y; return total; }
print(sum([], 0) === 0);
