function sum(rows, column) { 'use strict'; var total=0; for (var i=0; i<rows.length; i++) total += rows[i].values[column]; return total; }
var rows=[{values:[1,2]}, {values:[3,4]}, {values:[5,6]}];
print(Number.isNaN(sum(rows, 'missing')));
