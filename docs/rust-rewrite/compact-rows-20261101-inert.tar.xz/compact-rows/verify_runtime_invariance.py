"""Require ABI-42 R modules to remain byte-identical before candidate timing."""
import hashlib
import json
import struct
from pathlib import Path

OUT = Path(__file__).resolve().parent


def sha(data):
    return hashlib.sha256(data).hexdigest()


def runtime_module(product, package_name):
    folder = OUT / product
    package_path = folder / "runtime-build" / package_name
    package = package_path.read_bytes()
    identity = json.loads((folder / "identity.json").read_text())
    assert package[:8] == b"SCRWRB01"
    assert struct.unpack_from("<I", package, 8)[0] == 42
    assert package[12:44].hex() == identity["source_fingerprint"]
    module = package[136:-32]
    assert len(module) == struct.unpack_from("<Q", package, 128)[0]
    assert hashlib.sha256(package[:-32]).digest() == package[-32:]
    return dict(package_path=str(package_path.relative_to(OUT)),
        package_sha256=sha(package), package_bytes=len(package),
        runtime_abi=42, runtime_wasm_sha256=sha(module), runtime_wasm_bytes=len(module),
        source_fingerprint=identity["source_fingerprint"]), module


def main():
    profiles = {}
    for profile, package_name in [
        ("standard", "scriptw-runtime-package.bin"),
        ("portable", "scriptw-runtime-portable-package.bin"),
    ]:
        baseline, baseline_module = runtime_module("baseline", package_name)
        candidate, candidate_module = runtime_module("candidate", package_name)
        equal = baseline_module == candidate_module
        profiles[profile] = dict(
            runtime_abi=42,
            baseline_package=baseline,
            candidate_package=candidate,
            baseline_wasm_sha256=baseline["runtime_wasm_sha256"],
            candidate_wasm_sha256=candidate["runtime_wasm_sha256"],
            runtime_wasm_byte_identical=equal,
        )
        assert equal, f"R Wasm changed in {profile} profile"
    record = dict(
        status="verified",
        baseline_source_fingerprint=profiles["standard"]["baseline_package"]["source_fingerprint"],
        candidate_source_fingerprint=profiles["standard"]["candidate_package"]["source_fingerprint"],
        profiles=profiles,
        requirement="Both ABI-42 runtime profiles are byte-identical before any candidate timing.",
    )
    (OUT / "runtime-invariance-recheck.json").write_text(json.dumps(record, indent=2) + "\n")
    print(json.dumps(record, indent=2))


if __name__ == "__main__":
    main()
