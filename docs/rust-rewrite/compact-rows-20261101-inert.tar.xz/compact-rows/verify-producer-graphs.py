from pathlib import Path
import json,hashlib
out=Path(__file__).resolve().parent
owners={}
for label in ['native','product']:
 rows=[json.loads(l) for l in (out/(label+'-build.jsonl')).read_text().splitlines()]
 selected=[r for r in rows if r.get('reason')=='build-script-executed' and r.get('package_id','').endswith('/crates/scriptw-runtime-image#0.1.0')]
 assert len(selected)==1
 owners[label]=selected[0]
record=dict(status='verified',source_fingerprint=json.loads((out/'candidate/identity.json').read_text())['source_fingerprint'],owners=owners,files={})
for name in ['scriptw-runtime-package.bin','scriptw-runtime-portable-package.bin','scriptw-runtime-native.bin','scriptw-runtime-portable-native.bin']:
 paths=[Path(owners[label]['out_dir'])/name for label in ['native','product']]
 rows=[]
 for p in paths:
  with p.open('rb') as f:digest=hashlib.file_digest(f,'sha256').hexdigest()
  rows.append(dict(path=str(p),sha256=digest,bytes=p.stat().st_size))
 assert rows[0]['sha256']==rows[1]['sha256'] and rows[0]['bytes']==rows[1]['bytes']
 with paths[0].open('rb') as a,paths[1].open('rb') as b:
  while True:
   left,right=a.read(1<<20),b.read(1<<20);assert left==right
   if not left:break
 with (out/'candidate/runtime-build'/name).open('rb') as f:assert hashlib.file_digest(f,'sha256').hexdigest()==rows[1]['sha256']
 record['files'][name]=dict(native=rows[0],product=rows[1],frozen_matches=True,byte_identical=True)
(out/'producer-graph-equality.json').write_text(json.dumps(record,indent=2)+'\n')
print('Both actual Cargo graphs and the frozen R copies match exactly for all four files')
