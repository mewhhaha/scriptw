from pathlib import Path
import sys,json
root=Path.cwd();out=root/'target/performance-compact-rows';sys.path.insert(0,str(out));import run
folder=out/'product-semantics';sources=folder/'sources';artifacts=folder/'artifacts';artifacts.mkdir();records=[]
name='prefix-type-transitions.js';source_sha=run.digest(sources/name);identity=run.load(out/'candidate/identity.json');products=run.load(out/'candidate/products.json')
for stem,argv in [
 ('node',["node",root/'crates/scriptw-cli/tests/fixtures/v8_baseline/node-runtime.cjs',sources,'1','0',name]),
 ('cli',[out/'candidate/scriptw','--jobs','1','run',sources/name]),
 ('portable',[out/'candidate/runtime_baseline',sources,'1','0',name,artifacts]),
 ('no-interpreter',['sh','scripts/check-no-interpreter-in-product-graph.sh'])]:
 event=run.invoke(folder,stem,argv);stdout=(folder/'raw'/(stem+'.stdout')).read_text()
 if stem=='cli':assert stdout.startswith('true\n') and 'boolean(true)' in stdout
 if stem in ['node','portable']:
  report=json.loads(stdout);case=report['cases'][0];assert case['source_sha256']==source_sha and len(case['observations'])==1 and case['observations'][0]['stdout']=='true\n'
  if stem=='portable':assert report['source_fingerprint']==identity['source_fingerprint'] and report['executable_sha256']==products['runtime_baseline']['sha256'] and case['source_compilation_profile']=='portable'
 records.append(dict(label=stem,argv=list(map(str,argv)),exit_code=event['exit_code'],source_sha256=source_sha,source_fingerprint=identity['source_fingerprint'],scope='Frozen product semantic/type-transition control; timings are diagnostic and excluded from all scored cohorts'))
 (folder/'receipt.json').write_text(json.dumps(records,indent=2)+'\n');print(stem,'PASS',flush=True)
for name,row in products.items():assert run.digest(out/'candidate'/name)==row['sha256']
