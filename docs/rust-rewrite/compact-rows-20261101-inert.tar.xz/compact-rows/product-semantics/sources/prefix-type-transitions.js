function row(x, y) { return {x: x, y: y}; }
function sum(rows) {
  'use strict';
  var total = 0;
  for (var index = 0; index < rows.length; index++) total += rows[index].x + rows[index].y;
  return [total, index];
}
function gridRow(values) { return {name: 'row', values: values}; }
function grid(rows, column) {
  'use strict';
  var total = 0;
  for (var index = 0; index < rows.length; index++) total += rows[index].values[column];
  return [total, index];
}
function caught(rows) {
  'use strict';
  var total = 0, index = 0;
  try {
    for (; index < rows.length; index++) total += rows[index].x + rows[index].y;
  } catch (error) { return [total, index, error instanceof TypeError]; }
  return [total, index, false];
}
var strings = sum([row(1, 2), row('4', 5), row(6, 7)]);
var nested = grid([gridRow([3]), gridRow(['a']), gridRow([7])], 0);
var bigint = caught([row(1, 2), row(4n, 5), row(6, 7)]);
var calls = 0, rows = [row(1, 2), row(null, 3), row(4, 5)];
rows[1].x = {valueOf: function () { calls++; rows[2].x = 40; return 2; }};
var converted = sum(rows);
var okay = strings[0] === '34513' && strings[1] === 3 && nested[0] === '3a7' && nested[1] === 3 &&
  bigint[0] === 3 && bigint[1] === 1 && bigint[2] && converted[0] === 53 && converted[1] === 3 && calls === 1;
print(String(okay));
okay;
