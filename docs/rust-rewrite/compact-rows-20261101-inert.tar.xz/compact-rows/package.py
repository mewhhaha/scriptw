"""Finalize compact-row evidence only after campaigns/audits finish.

Prepare-only until explicitly invoked with --finalize --status accepted|rejected
under limited_verification. No build/test/measurement/reference replay occurs.
"""
import argparse
import collections
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import statistics
import tarfile

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
DOCS = ROOT / "docs/rust-rewrite"
STEM = "compact-rows-20261101"
BASELINE_FP = "5b20fafcf08ed06d495ffb4f3a980fcc65e819ebfcc9bf597754ef4c6300ab75"
ACCEPTED_BASELINE = "c5586f330d57a8fa70a97836b4d0a8c5cda201d0"
COMPILED_BASELINE = "259d4c4a644006acaa1e648616007406658a796d"
SOURCE_PARENT = "d1bf33a43bb2dc65afcc2d017a0e3633630d161e"
COUNTS = dict(aa=400, ordinary=400, cp_control=400)
TEXT_SUFFIXES = {
    ".json", ".jsonl", ".py", ".log", ".stdout", ".stderr", ".inventory",
    ".rs", ".patch", ".wat", ".wat-fragment", ".script", ".map",
    ".identity", ".js", ".md", ".txt", ".toml", ".lock", ".csv",
}
TEXT_DIRS = {
    "baseline", "baseline-aa", "candidate", "native", "runs", "cp-control",
    "test262-compact-rows", "fixture-output-diagnostic", "program-inspection",
    "product-semantics", "raw", "sources", "retained-sources", "adapted-scriptc", "expected",
    "freeze-first-attempt", "native-continuation-correction", "encoded-test-correction",
    "audit-preparation-original",
}
FORBIDDEN_DIRS = {"tools", "toolchain", "node_modules", ".git", "__pycache__", "cache", ".cache"}
MAX_FILE, MAX_TOTAL, MAX_MEMBERS, MAX_ARCHIVE = 64 << 20, 512 << 20, 20000, 128 << 20


def load(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))

def file_hash(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()

def native_coverage(audit, fingerprint):
    audited = audit["native_coverage"]
    chain = audited["test_only_correction"]
    assert chain["metadata"]["candidate_source_fingerprint"] == fingerprint
    failed = set(chain["original_failed_tests"])
    assert len(failed) == 3 and failed == set(chain["corrected_passes"])
    retained = load(BASE / "native/retained-focus-passes.json")
    assert retained["candidate_source_fingerprint"] == fingerprint and retained["retained_pass_count"] == 40
    assert set(retained["pending_tests"]) == failed
    unions, scopes, stage_counts = collections.defaultdict(set), [], collections.Counter()
    for stage in ["focus", "remaining"]:
        receipt = load(BASE / "native" / (stage + "-receipt.json"))
        expected_status = "complete"
        if stage == "focus":
            expected_status = "failed"
            assert receipt == load(BASE / "encoded-test-correction/original-focus-receipt.json")
        assert receipt["status"] == expected_status and receipt["stage"] == stage
        assert receipt["candidate_source_fingerprint"] == fingerprint
        for row in receipt["scopes"]:
            assert not row["timed_out"] and row["candidate_source_fingerprint"] == fingerprint
            assert len(row["summaries"]) == 1
            result, names = row["summaries"][0], set(row["selected_inventory"])
            if stage == "focus" and row["target"] == "scriptw_aot_wasm":
                assert not row["passed"] and row["exit_code"] == 101
                assert row["executable_sha256"] == chain["original_backend_sha256"]
                assert failed <= names and result[0] == "FAILED" and int(result[1]) == 17 and int(result[2]) == 3 and int(result[3]) == 0
                names -= failed
            else:
                assert row["passed"] and row["exit_code"] == 0 and result[0] == "ok"
                assert int(result[1]) == len(names) and int(result[2]) == int(result[3]) == 0
            if stage == "focus":
                assert names == set(retained["retained_passes"][row["target"]])
            assert not (names & unions[row["target"]])
            unions[row["target"]].update(names)
            stage_counts[stage] += len(names)
            scopes.append(dict(stage=stage, target=row["target"], filter=row["filter"], passed=len(names),
                original_failures=sorted(set(row["selected_inventory"]) - names),
                executable_sha256=row["executable_sha256"]))
    replayed = set()
    for row in load(BASE / "encoded-test-correction/corrected-receipt.json"):
        assert row["target"] == "scriptw_aot_wasm" and row["exit_code"] == 0 and not row["timed_out"]
        assert row["executable_sha256"] == chain["corrected_backend_sha256"]
        assert len(row["selected_inventory"]) == 1 and len(row["summaries"]) == 1
        result, names = row["summaries"][0], set(row["selected_inventory"])
        assert result[0] == "ok" and int(result[1]) == 1 and int(result[2]) == int(result[3]) == 0
        assert not replayed.intersection(names)
        replayed.update(names)
    assert replayed == failed and not replayed.intersection(unions["scriptw_aot_wasm"])
    unions["scriptw_aot_wasm"].update(replayed)
    assert dict(stage_counts) == dict(focus=40, remaining=1445)
    assert chain["counts"] == dict(retained_focus=40, remaining=1445, corrected_exact=3)
    reuse = load(BASE / "encoded-test-correction/production-reuse.json")
    assert reuse["source_fingerprint"] == fingerprint
    assert reuse["changed_source_paths"] == [chain["metadata"]["file"]]
    counts = {target: len(names) for target, names in unions.items()}
    assert counts == audited["selected_counts"] and sum(counts.values()) == audited["unique_selected_total"] == 1488
    assert {target: sorted(names) for target, names in unions.items()} == audited["selected_tests"]
    assert counts["scriptw_engine"] == 38, "selected Engine coverage is not the full Engine suite"
    guards = (BASE / "guards.stdout").read_text(encoding="utf-8")
    totals = re.findall(r"test result: ok\. (\d+) passed; 0 failed; 0 ignored;", guards)
    assert sum(map(int, totals)) == 359
    return dict(native_distinct=sum(counts.values()), native_by_target=counts, native_scopes=scopes,
        native_audit=audited, source_guards=359, test_correction_chains=[chain], full_engine_suite=False,
        boundary="40 named original focus passes +1445 remaining +3 corrected exact passes. "
            "Original failed classifier assertions/binary/receipts remain preserved; production inputs unchanged. "
            "No full rerun is claimed. Engine coverage is38 selected tests; source-only guards are separate.")


def references(analysis, audit, fingerprint):
    assert audit["status"] == "audited" and audit["attempts"] == 136
    assert {label: row["source_fingerprint"] for label, row in audit["hosts"].items()} == dict(baseline=BASELINE_FP, candidate=fingerprint)
    groups = collections.defaultdict(list)
    seen = set()
    for row in analysis["attempts"]:
        key = (row["file"], row["runtime"], row["round"])
        assert row["status"] == "ok" and key not in seen and len(row["times_ns"]) == 21
        seen.add(key)
        groups[key[:2]].append(row["times_ns"])
    assert len(seen) == 136 and len(groups) == 68 and all(len(v) == 2 for v in groups.values())
    cases = sorted({name for name, _ in groups})
    assert len(cases) == len(analysis["compilation"]) == audit["scriptc_compilations"] == 17
    primary, median_wins, mean_wins = [], dict(v8=[], scriptc=[]), dict(v8=[], scriptc=[])
    for name in cases:
        stats = {runtime: dict(median_ns=statistics.median(statistics.median(v) for v in groups[name, runtime]),
            mean_ns=statistics.mean(statistics.mean(v) for v in groups[name, runtime]))
            for runtime in ["baseline", "candidate", "v8", "scriptc"]}
        for runtime in median_wins:
            if stats["candidate"]["median_ns"] < stats[runtime]["median_ns"]:
                median_wins[runtime].append(name)
            if stats["candidate"]["mean_ns"] < stats[runtime]["mean_ns"]:
                mean_wins[runtime].append(name)
        primary.append(dict(case=name, runtimes=stats))
    assert {k: sorted(v) for k, v in audit["median_wins"].items()} == median_wins
    return dict(scope=analysis["policy"], tools=analysis["tools"], attempts=len(seen),
        measured_observations=len(seen) * 21, warmups=len(seen) * 10,
        scriptc_compilations=len(analysis["compilation"]), median_wins=median_wins, mean_wins=mean_wins,
        experimental_unit="Independent process; median of two process medians and mean of two process means.",
        process_statistics=primary, pooled_statistics_descriptive=analysis["summary"],
        boundary="V8 context creation is outside execution timing; Scriptw Realm/bootstrap/completion remains inside. "
            "Scriptc Store/instantiation is outside, _start/output extraction inside. "
            "Descriptive existing boundaries, not equal end-to-end Realm costs. Endpoint RSS is not peak/live JS memory.")

def conformance(receipt, fingerprint):
    assert receipt["status"] in {"complete", "failed"} and receipt["source_fingerprint"] == fingerprint
    assert receipt["cli_sha256"] == load(BASE / "candidate/products.json")["scriptw"]["sha256"]
    assert receipt["source_commit"] == load(BASE / "candidate/identity.json")["source_commit"]
    rows = []
    for scope in receipt["scopes"]:
        assert not scope["timed_out"] and scope["launch_error"] is None and len(scope["snapshots"]) == 1
        snapshot = scope["snapshots"][0]
        assert snapshot["source_fingerprint_matches"] and snapshot["total"] > 0
        rows.append(dict(selection=scope["selection"], scope_pass=scope["scope_pass"], exit_code=scope["exit_code"],
            passed=snapshot["passed"], total=snapshot["total"], pinned_revisions=snapshot["pinned_revisions"],
            completed_test_ids_sha256=snapshot["completed_test_ids_sha256"],
            failures=snapshot["failures"], timeout_test_ids=snapshot["timeout_test_ids"]))
    assert len(rows) == 3 and len({r["selection"] for r in rows}) == 3
    return dict(status=receipt["status"], passed=sum(r["passed"] for r in rows),
        total=sum(r["total"] for r in rows), scopes=rows, full_Test262_or_release_acceptance=False)

def text_members():
    total, selected, excluded = 0, [], []
    for folder, dirs, names in os.walk(BASE, followlinks=False):
        folder = Path(folder)
        kept = []
        for name in sorted(dirs):
            path = folder / name
            if path.is_symlink() or name in FORBIDDEN_DIRS or name.endswith("-cache") or name.startswith("cache-"):
                excluded.append(str(path.relative_to(BASE)))
            elif folder != BASE or name in TEXT_DIRS:
                kept.append(name)
            else:
                excluded.append(str(path.relative_to(BASE)))
        dirs[:] = kept
        for name in sorted(names):
            path = folder / name
            relative = path.relative_to(BASE)
            if path.is_symlink() or not path.is_file() or path.suffix not in TEXT_SUFFIXES:
                excluded.append(str(relative))
                continue
            size = path.stat().st_size
            assert size <= MAX_FILE, f"oversized allowlisted text: {relative}"
            total += size
            assert total <= MAX_TOTAL and len(selected) + 2 < MAX_MEMBERS
            raw = path.read_bytes()
            raw.decode("utf-8")  # Unexpected binary under a text suffix fails closed.
            assert not raw.startswith((b"\0asm", b"\x7fELF", b"SCRWRB01")), f"binary magic in text member: {relative}"
            member = "compact-rows/" + relative.as_posix()
            assert not PurePosixPath(member).is_absolute() and ".." not in PurePosixPath(member).parts
            selected.append((member, raw))
    return selected, excluded

def archive_text(destination):
    selected, excluded = text_members()
    notice = ("Inert UTF-8 evidence only. No binary executables, Wasm modules, native images, toolchains, "
        "caches or symlinks. Scripts are recorded workflow text, not an archive execution interface. "
        "Hashes of producer outputs do not authorize loading native code.\n").encode()
    inventory = dict(members=[dict(path=name, bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
        for name, raw in selected], excluded=excluded,
        limits=dict(file_bytes=MAX_FILE, total_bytes=MAX_TOTAL, members=MAX_MEMBERS, archive_bytes=MAX_ARCHIVE))
    members = [("EVIDENCE.txt", notice), ("EVIDENCE.json", (json.dumps(inventory, indent=2) + "\n").encode())] + selected
    assert len(members) <= MAX_MEMBERS and sum(len(raw) for _, raw in members) <= MAX_TOTAL
    temporary = destination.with_name(destination.name + ".tmp")
    assert not destination.exists() and not temporary.exists(), "preserve previous packages"
    with tarfile.open(temporary, "w:xz", preset=6) as archive:
        for name, raw in members:
            info = tarfile.TarInfo(name)
            info.size, info.mode, info.mtime = len(raw), 0o644, 0
            archive.addfile(info, io.BytesIO(raw))
    assert temporary.stat().st_size <= MAX_ARCHIVE
    with tarfile.open(temporary, "r:xz") as archive:
        actual = archive.getmembers()
        assert [m.name for m in actual] == [name for name, _ in members]
        for member, (_, expected) in zip(actual, members):
            assert member.isfile() and member.mode == 0o644 and not member.issym() and not member.islnk()
            raw = archive.extractfile(member).read()
            raw.decode("utf-8")
            assert raw == expected
    temporary.replace(destination)
    return dict(path=destination.name, sha256=file_hash(destination), bytes=destination.stat().st_size,
        utf8_members=len(members), expanded_utf8_bytes=sum(len(raw) for _, raw in members),
        contains_native_or_wasm_binaries=False, excluded_path_count=len(excluded))

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--finalize", action="store_true", required=True)
    parser.add_argument("--status", choices=["accepted", "rejected"], required=True)
    parser.add_argument("--audit", type=Path, default=BASE / "independent-audit.json")
    parser.add_argument("--reference-analysis", type=Path, default=BASE / "reference-analysis.json")
    parser.add_argument("--reference-audit", type=Path, default=BASE / "reference-audit.json")
    args = parser.parse_args()
    audit, study = load(args.audit), load(BASE / "study-plan.json")
    baseline, candidate = load(BASE / "baseline/identity.json"), load(BASE / "candidate/identity.json")
    fingerprint = candidate["source_fingerprint"]
    assert len(fingerprint) == 64 and all(c in "0123456789abcdef" for c in fingerprint)
    assert fingerprint != BASELINE_FP and candidate["source_commit"] == SOURCE_PARENT
    assert baseline["source_fingerprint"] == BASELINE_FP and baseline["source_commit"] == COMPILED_BASELINE
    assert audit["status"] == "audited" and audit["baseline_accepted_commit"] == ACCEPTED_BASELINE
    assert audit["products"]["candidate"]["identity"] == candidate
    assert audit["total_raw_invocations"] == 1200
    assert {k: v["raw_invocations"] for k, v in audit["cohorts"].items()} == COUNTS
    assert audit["measured_observations"] == 25200 and audit["warmup_observations"] == 12000
    manifest = load(BASE / "sources/manifest.json")
    assert len(manifest["execution"]) == 25 and set(study["targets"]) == {"objects.js", "retained-objects.js"}
    assert len({row["file"] for row in manifest["execution"]} - set(study["targets"])) == 23
    runtime = load(BASE / "runtime-invariance.json")
    assert runtime["status"] == "verified" and runtime["candidate_source_fingerprint"] == fingerprint
    assert runtime["baseline_source_fingerprint"] == BASELINE_FP and len(runtime["profiles"]) == 2
    for row in runtime["profiles"].values():
        assert row["runtime_abi"] == 42 and row["runtime_wasm_identical"]
        assert row["baseline_wasm_sha256"] == row["candidate_wasm_sha256"]
        assert isinstance(row["native_identical"], bool)  # Native equality is recorded separately.
    verification = native_coverage(audit, fingerprint)
    verification["full_Test262_or_release_acceptance"] = False
    verification["setup_corrections"] = audit["setup_corrections"]
    verification["toolchain"] = load(BASE / "toolchain.json")
    semantics = load(BASE / "product-semantics/receipt.json")
    assert {row["label"] for row in semantics} == {"node", "cli", "portable", "no-interpreter"}
    assert all(row["exit_code"] == 0 and row["source_fingerprint"] == fingerprint for row in semantics)
    setup = load(BASE / "product-semantics/setup-attempt-1/correction.json")
    assert setup["candidate_executions_in_first_attempt"] == 0
    verification["product_semantics"] = dict(receipt=semantics, initial_setup=setup,
        scope="Unscored prefix/type-transition semantic controls. The initial Node1-sample/0-warmup request "
            "was rejected before source or candidate execution; the supported3/1 diagnostic and original setup are retained. "
            "No cohort observations replaced.")
    conformance_receipt = BASE / "test262-compact-rows/test262-compact-rows-receipt.json"
    inspection_path = BASE / "program-inspection/identity.json"
    if args.status == "accepted":
        assert all(audit["cohorts"][name]["gate_pass"] for name in ["ordinary", "cp_control"])
        verification["pinned_test262"] = conformance(load(conformance_receipt), fingerprint)
        assert verification["pinned_test262"]["status"] == "complete"
        reference = references(load(args.reference_analysis), load(args.reference_audit), fingerprint)
        inspection = load(inspection_path)
        assert inspection["source_fingerprint"] == fingerprint and len(inspection["products"]) == 6
        reference_boundary = "136 direct-reference processes are separate from the1200 gated cohort processes."
    else:
        assert any(not audit["cohorts"][name]["gate_pass"] for name in ["ordinary", "cp_control"])
        assert not conformance_receipt.exists() and not args.reference_analysis.exists() and not args.reference_audit.exists()
        reason = "not run: predeclared performance gate vetoed candidate"
        verification["pinned_test262"] = dict(status=reason, scopes_run=0, planned_scopes=3,
            full_Test262_or_release_acceptance=False)
        reference = dict(status=reason, attempts=0, planned_attempts=136, planned_scriptc_compilations=17)
        inspection = dict(status=reason, planned_P_modules=6)
        if inspection_path.is_file():
            inspection = load(inspection_path)
            assert inspection["source_fingerprint"] == fingerprint
        reference_boundary = "The planned136 reference processes,17 Scriptc compilations and three selected Test262 scopes were not run after the performance veto."
    summary = dict(schema="scriptw-compact-rows-checkpoint-v1", date="2026-11-01", status=args.status,
        source_parent_commit=SOURCE_PARENT, candidate_source_fingerprint=fingerprint,
        baseline_accepted_commit=ACCEPTED_BASELINE, baseline_binary_source_commit=COMPILED_BASELINE,
        baseline_source_fingerprint=BASELINE_FP, products=load(BASE / "candidate/products.json"),
        candidate_changes=["P-only read paths for canonical two-slot compact rows and readonly dense Number columns.",
            "One row's complete shape/tag/bounds proof precedes its exact arithmetic; a miss publishes the completed prefix and resumes the original current iteration.",
            "Private binding IDs, f64 counter semantics, i32 induction mirror and original fallback/completion ownership remain explicit. No new heap, runtime helper or schema."],
        runtime_abi=42, runtime_invariance=runtime,
        cohort_counts=COUNTS, cohorts=audit["cohorts"],
        corpus=dict(manifest_sha256=file_hash(BASE / "sources/manifest.json"), predeclared=study["corpus"],
            original_cases=17, added_controls=8, cases=25, targets=study["targets"], controls=23),
        audit=dict(total_raw_invocations=1200, measured_observations=25200, warmups=12000,
            maximum_statistical_discrepancy=audit["maximum_recomputed_statistic_discrepancy"],
            P_footprints=audit["P_footprints"]),
        reference=reference, verification=verification, wasm_inspection=inspection,
        limitations=["Full release/Test262 acceptance and every-case V8/Scriptc parity remain open.",
            "The separate direct-reference objects mean regresses9.02% (956.308us versus877.183us), despite its lower median. "
            "Retained-object reference medians14.520ms versus20.380ms accompany means18.102ms versus20.610ms. "
            "Both process rounds, including the sizeable mean spread, remain included; these are distinct from the paired gate blocks.",
            "A/A400 + ordinary400 + CP400 =1200 process inputs, each21 measured samples and10 warmups. Pooled observations are descriptive.",
            reference_boundary,
            "Both ABI42 R Wasm modules are byte-identical; fingerprint-bound package metadata and native-image identity are recorded independently.",
            "Hot-R compiler-disabled SizeOptimized/backtracking differs from ordinary Fast execution; do not subtract lanes for attribution.",
            "Slower control blocks and A/A outliers are retained; no samples trimmed or gates relaxed.",
            "Cache/RSS endpoints do not identify GC, page faults or scheduler causes."] + audit["limitations"])
    if args.status == "rejected":
        summary["production_retained"] = dict(accepted_commit=ACCEPTED_BASELINE, source_fingerprint=BASELINE_FP, runtime_abi=42)
        summary["rejection"] = {name: audit["cohorts"][name] for name in ["ordinary", "cp_control"]
            if not audit["cohorts"][name]["gate_pass"]}
    for name in ["format-classification.json", "runtime-invariance-recheck.json", "product-semantics/cache-proof.json", "post-audit-docs.json", "producer-graph-equality.json"]:
        path = BASE / name
        if path.is_file():
            summary.setdefault("additional_receipts", {})[name] = load(path)
    destination, summary_path = DOCS / (STEM + "-inert.tar.xz"), DOCS / (STEM + ".json")
    assert not summary_path.exists(), "preserve prior summary"
    summary["evidence"] = archive_text(destination)
    summary_path.write_text(json.dumps(summary, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps(summary["evidence"], indent=2))


if __name__ == "__main__":
    main()

