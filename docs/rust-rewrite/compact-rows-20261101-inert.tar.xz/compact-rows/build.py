"""Prepare the compact-row source receipt, then build products without running tests."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time
import shutil
import sys

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "scripts"))
from limited_verification import kernel_group, require_kernel_budget


def git_lines(*args):
    return subprocess.check_output(["git", *args], cwd=ROOT, text=True).splitlines()


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def source_inputs():
    paths = set(git_lines("diff", "--name-only", "HEAD"))
    paths.update(git_lines("ls-files", "--others", "--exclude-standard"))
    return sorted(path for path in paths if (ROOT / path).is_file())


def snapshot_sources():
    path = OUT / "pre-build-sources.json"
    assert not path.exists(), "retain the prior source receipt and start a separately named build attempt"
    files = source_inputs()
    assert "crates/scriptw-aot-wasm/src/control_flow/scalar_number_loop/compact_path.rs" in files
    assert "crates/scriptw-engine/tests/aot_language/aot_compact_row_regions.rs" in files
    record = dict(captured_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        git_head=git_lines("rev-parse", "HEAD")[0],
        purpose="all visible tracked changes and untracked source/tests captured immediately before compile",
        files={name: digest(ROOT / name) for name in files})
    path.write_text(json.dumps(record, indent=2) + "\n")
    return record


def main():
    require_kernel_budget(4 * 1024 * 1024 * 1024)
    assert len(os.sched_getaffinity(0)) == 1, "run under the one-CPU limited-verification policy"
    if os.environ.get("NODE_OPTIONS"):
        raise SystemExit("NODE_OPTIONS must be unset")
    sources = snapshot_sources()
    rust = [name for name in sources["files"] if name.endswith(".rs")]
    commands = [
        ("rustfmt", ["rustfmt", "--edition", "2021", "--config", "skip_children=true", "--check", *rust]),
        ("guards", ["python3", "-B", "scripts/check-source-guards.py"]),
        ("native-build", ["cargo", "test", "--release", "--locked", "-p", "scriptw-aot-wasm",
            "-p", "scriptw-engine", "--lib", "--test", "structure_language", "--test",
            "emission", "--test", "aot_language", "--test", "aot_gc_entries", "--no-run",
            "--message-format=json", "--timings"]),
        ("product-build", ["cargo", "build", "--release", "--locked", "-p", "scriptw-cli",
            "--bin", "scriptw", "--example", "runtime_baseline", "--example",
            "compiler_precompiled_baseline", "--example", "wasi_baseline", "--message-format=json", "--timings"]),
    ]
    receipt = dict(status="running", source_receipt="pre-build-sources.json", commands=[])
    (OUT / "build-receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
    for label, argv in commands:
        started = time.monotonic()
        stdout_path = OUT / f"{label}.stdout"
        stderr_path = OUT / f"{label}.stderr"
        with stdout_path.open("xb") as stdout, stderr_path.open("xb") as stderr:
            result = subprocess.run(argv, cwd=ROOT, stdout=stdout, stderr=stderr,
                timeout=3600, check=False)
        row = dict(label=label, argv=argv, exit_code=result.returncode,
            elapsed_seconds=time.monotonic() - started,
            stdout=stdout_path.name, stdout_sha256=digest(stdout_path),
            stderr=stderr_path.name, stderr_sha256=digest(stderr_path))
        receipt["commands"].append(row)
        receipt["status"] = "failed" if result.returncode else "running"
        (OUT / "build-receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
        if label in ("native-build", "product-build"):
            shutil.copyfile(stdout_path, OUT / f"{label}.jsonl")
        if result.returncode:
            raise SystemExit(result.returncode)
    receipt["status"] = "complete"
    (OUT / "build-receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")


if __name__ == "__main__":
    main()
