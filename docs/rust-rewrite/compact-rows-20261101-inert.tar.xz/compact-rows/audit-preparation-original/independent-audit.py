"""Read-only raw audit; run under limited_verification after cohorts finish.

Adapted from the successful performance-deferred-namespaces raw audit.
Both profiles remain ABI42; AA25, ordinary25 and CP25 control cohorts.
Candidate fingerprint and completed run directories are explicit inputs.
No benchmark invocation, build, statistical exclusion, or acceptance override.
"""
import argparse
import collections
import difflib
import hashlib
import json
import math
from pathlib import Path
import statistics
import struct

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
CORPUS = BASE / 'sources'
ORIGINAL_CORPUS = ROOT / 'crates/scriptw-cli/tests/fixtures/v8_execution_hotpaths'
BASELINE_FP = '5b20fafcf08ed06d495ffb4f3a980fcc65e819ebfcc9bf597754ef4c6300ab75'
BASELINE_HOST = '3de9b9fb1a733348c671acfed689e25a527d6a331131f21b0388aa2c15cbe0f7'
BASELINE_COMMIT = '259d4c4a644006acaa1e648616007406658a796d'
BASELINE_ACCEPTED_COMMIT = 'c5586f330d57a8fa70a97836b4d0a8c5cda201d0'
PRIMARY_TARGETS = {'objects.js', 'retained-objects.js'}
EXPECTED_NATIVE_COUNTS = dict(scriptw_engine=38, scriptw_aot_wasm=582,
    structure_language=152, emission=41, aot_language=412, aot_gc_entries=263)
SCHEDULES = {
    'block0': ['baseline', 'candidate', 'candidate', 'baseline',
               'candidate', 'baseline', 'baseline', 'candidate'],
    'block1': ['candidate', 'baseline', 'baseline', 'candidate',
               'baseline', 'candidate', 'candidate', 'baseline'],
}
MEMORY, IMAGE_LIMIT = 4294967296, 67108864
HASHED = {}
P_IDENTITIES = collections.defaultdict(set)
P_CODE = {}
MAX_RSS = 0
MAX_DISCREPANCY = 0.0


def load(path):
    return json.loads(Path(path).read_text())


def digest(data):
    return hashlib.sha256(data).hexdigest()


def file_hash(path):
    path = Path(path).resolve()
    if path not in HASHED:
        with path.open('rb') as stream:
            HASHED[path] = hashlib.file_digest(stream, 'sha256').hexdigest()
    return HASHED[path]


def close(actual, reported):
    global MAX_DISCREPANCY
    assert math.isfinite(actual) and math.isfinite(reported)
    discrepancy = abs(actual - reported)
    MAX_DISCREPANCY = max(MAX_DISCREPANCY, discrepancy)
    assert discrepancy <= 1e-7, (actual, reported, discrepancy)


def uleb(data, position):
    value = shift = 0
    while True:
        byte = data[position]
        position += 1
        value |= (byte & 127) << shift
        if byte < 128:
            return value, position
        shift += 7
        assert shift < 64


def wasm_code(data):
    assert data[:8] == b'\0asm\x01\0\0\0'
    position = 8
    result = (0, 0, 0, b'')
    found = False
    while position < len(data):
        kind = data[position]
        length, position = uleb(data, position + 1)
        end = position + length
        assert end <= len(data)
        if kind == 10:
            assert not found
            found = True
            code = data[position:end]
            count, position = uleb(data, position)
            sizes = []
            for _ in range(count):
                size, position = uleb(data, position)
                sizes.append(size)
                position += size
                assert position <= end
            assert position == end
            result = (count, sum(sizes), max(sizes, default=0), code)
        position = end
    assert position == len(data)
    return result


def corpus():
    record = load(BASE / 'corpus.json')
    assert file_hash(CORPUS / 'manifest.json') == record['manifest_sha256']
    assert load(CORPUS / 'manifest.json') == record['manifest']
    for name, expected in record['files_sha256'].items():
        assert file_hash(CORPUS / name) == expected
    cases = record['manifest']['execution']
    assert len(cases) == 25 and len({row['file'] for row in cases}) == 25
    original = load(ORIGINAL_CORPUS / 'manifest.json')
    assert file_hash(ORIGINAL_CORPUS / 'manifest.json') == record['original_manifest_sha256']
    original_cases = original['execution']
    assert len(original_cases) == 17 and cases[:17] == original_cases
    for case in original_cases:
        assert file_hash(CORPUS / case['file']) == file_hash(ORIGINAL_CORPUS / case['file'])
    assert set(record['predeclared_targets']) == PRIMARY_TARGETS
    assert set(record['predeclared_controls']) == {row['file'] for row in cases} - PRIMARY_TARGETS
    return record, cases


def products():
    result = {}
    for label in ['baseline', 'baseline-aa', 'candidate']:
        directory = BASE / label
        identity = load(directory / 'identity.json')
        hosts = load(directory / 'host-products.json')
        original = load(directory / 'products.json')
        for name, row in hosts.items():
            path = directory / name
            assert path.is_file() and not path.is_symlink() and path.stat().st_nlink == 1
            assert path.stat().st_size == row['bytes']
            assert file_hash(path) == row['sha256'] == original[name]['sha256']
        assert identity['executable_sha256'] == hosts['compiler_precompiled_baseline']['sha256']
        if label != 'candidate':
            assert identity['source_fingerprint'] == BASELINE_FP
            assert identity['source_commit'] == BASELINE_COMMIT
            assert hosts['runtime_baseline']['sha256'] == BASELINE_HOST
        result[label] = dict(identity=identity, hosts=hosts)
    source = load(BASE / 'candidate/source.json')
    assert source['head'] == result['candidate']['identity']['source_commit']
    assert source['fingerprint'] == result['candidate']['identity']['source_fingerprint']
    assert source['patch_sha256'] == file_hash(BASE / 'candidate/source.patch')
    # These hashes bind the build inputs, not the later checkout state.
    build_source = load(BASE / 'pre-build-sources.json')
    built = build_source['files']
    assert source['head'] == build_source['git_head']
    frozen = load(BASE / 'candidate/source-files.json')
    assert frozen == built
    assert all(file_hash(ROOT / name) == expected for name, expected in built.items())
    for name in ['crates/scriptw-aot-wasm/src/control_flow/scalar_number_loop/compact_path.rs',
                 'crates/scriptw-engine/tests/aot_language/aot_compact_row_regions.rs']:
        assert name in built and name in frozen, 'new source must be a frozen build input'
    return result


def native_test_outcomes(row, stdout):
    results = {}
    for line in stdout.read_text().splitlines():
        if not line.startswith('test ') or ' ... ' not in line:
            continue
        name, status = line[5:].rsplit(' ... ', 1)
        name = name.removesuffix(' - should panic')
        if status in ['ok', 'FAILED']:
            assert name not in results
            results[name] = status
    assert set(results) == set(row['selected_inventory'])
    assert len(row['summaries']) == 1
    summary = row['summaries'][0]
    passed = {name for name, status in results.items() if status == 'ok'}
    failed = set(results) - passed
    assert int(summary[1]) == len(passed) and int(summary[2]) == len(failed)
    assert int(summary[3]) == int(summary[4]) == 0
    assert summary[0] == ('FAILED' if failed else 'ok')
    assert row['exit_code'] == (101 if failed else 0)
    return passed, failed


def resource_check(command):
    global MAX_RSS
    assert command['exit_code'] == 0 and command['timed_out'] is False
    assert command['affinity'] == [0]
    assert 0 < command['peak_rss_bytes'] <= MEMORY
    MAX_RSS = max(MAX_RSS, command['peak_rss_bytes'])
    before, after = command['resources_before'], command['resources_after']
    for snapshot in [before, after]:
        assert snapshot['memory.max'].strip() == str(MEMORY)
        assert snapshot['memory.swap.max'].strip() == '0'
        assert snapshot['memory.oom.group'].strip() == '1'
        events = dict(line.split() for line in snapshot['memory.events'].splitlines())
        assert all(int(value) == 0 for value in events.values()), events
    assert before == after, 'resource policy or memory events changed'


def verify_identity(report, label, records, host):
    expected = records[label]
    identity = expected['identity']
    assert report['source_commit'] == identity['source_commit']
    assert report['source_fingerprint'] == identity['source_fingerprint']
    assert report['executable_sha256'] == expected['hosts'][host]['sha256']


def observations(report, expected_stdout, cp=False):
    obs = report['observations']
    assert len(obs) == 31
    assert [row['warmup'] for row in obs] == [True] * 10 + [False] * 21
    assert all(row['stdout'] == expected_stdout for row in obs)
    timings = [row['phases_ns']['execution'] if cp else row['execution_ns'] for row in obs]
    assert all(type(value) is int and value > 0 for value in timings)
    values = timings[10:]
    return dict(times=values, median=statistics.median(values), mean=statistics.mean(values))


def compare(analysis, groups, cases, aa, cp, targets):
    results, vetoes, targets_failed, any_blocks, repeated_all = [], [], [], [], []
    assert len(analysis['comparisons']) == len(cases)
    indexed = {row['case']: row for row in analysis['comparisons']}
    assert set(indexed) == {row['file'] for row in cases}
    other = 'baseline-aa' if aa else 'candidate'
    for case in cases:
        name = case['file']
        recorded = indexed[name]
        control = cp or name not in targets
        if not cp:
            assert recorded['control'] == control
        blocks = []
        assert [row['block'] for row in recorded['blocks']] == list(SCHEDULES)
        for block in recorded['blocks']:
            block_name = block['block']
            stats = {}
            for product in ['baseline', other]:
                rows = groups[(name, block_name, product)]
                assert len(rows) == 4
                pooled = [value for row in rows for value in row['times']]
                actual = [statistics.median(row['median'] for row in rows),
                          statistics.mean(row['mean'] for row in rows),
                          statistics.median(pooled), statistics.mean(pooled)]
                published = block['products'][product]
                fields = ['block_median_ns', 'block_mean_ns'] if cp else [
                    'block_median_of_invocation_medians_ns', 'block_mean_of_invocation_means_ns',
                    'pooled_sample_median_ns', 'pooled_sample_mean_ns']
                for field, value in zip(fields, actual):
                    close(value, published[field])
                if not cp:
                    assert published['invocation_count'] == 4 and published['sample_count'] == 84
                refs = {row['raw']: row for row in published['invocations']}
                assert set(refs) == {row['raw'] for row in rows}
                for row in rows:
                    close(row['median'], refs[row['raw']]['median_ns'])
                    close(row['mean'], refs[row['raw']]['mean_ns'])
                    assert row['process_elapsed_ns'] == refs[row['raw']]['process_elapsed_ns']
                stats[product] = actual
            changes = [100 * (b / a - 1) for a, b in zip(stats['baseline'], stats[other])]
            fields = ['median_percent', 'mean_percent'] if cp else [
                'block_median_of_invocation_medians_percent', 'block_mean_of_invocation_means_percent',
                'pooled_sample_median_percent', 'pooled_sample_mean_percent']
            for field, value in zip(fields, changes):
                close(value, block['change_percent'][field])
            blocks.append(dict(block=block_name, process_median_percent=changes[0],
                process_mean_percent=changes[1], pooled_median_percent=changes[2],
                pooled_mean_percent=changes[3], absolute_stats_ns=stats))
            if control and changes[0] >= 3 and changes[1] >= 3:
                any_blocks.append((name, block_name))
        repeated = all(row['process_median_percent'] >= 3 and row['process_mean_percent'] >= 3 for row in blocks)
        if repeated:
            repeated_all.append(name)
            if control:
                vetoes.append(name)
        if not aa and not cp and not control and any(row['process_median_percent'] >= 0 for row in blocks):
            targets_failed.append(name)
        results.append(dict(case=name, control=control, blocks=blocks))
    reported_veto = 'vetoed_cases_both_blocks' if cp else 'controls_vetoed_in_both_blocks'
    assert sorted(vetoes) == analysis[reported_veto]
    assert set(any_blocks) == {(row['case'], row['block']) for row in analysis['vetoed_control_blocks']}
    if cp:
        assert sorted({name for name, _ in any_blocks}) == analysis['vetoed_cases_any_block']
    else:
        assert sorted(targets_failed) == analysis['targets_not_improved_both_blocks']
    return dict(comparisons=results, vetoed_controls_both_blocks=sorted(vetoes),
        targets_not_improved_both_blocks=sorted(targets_failed),
        repeated_slowdowns_all_cases=sorted(repeated_all),
        gate_pass=not vetoes and not targets_failed)


def ordinary(root, cases, records, runtime_records, targets, aa=False, corpus_dir=CORPUS):
    root, corpus_dir = root.resolve(), corpus_dir.resolve()
    count = len(cases) * 16
    analysis, plan = load(root / 'analysis.json'), load(root / 'plan.json')
    assert analysis['status'] == 'complete'
    assert plan['samples'] == 21 and plan['warmups'] == 10
    assert plan['cases'] == [row['file'] for row in cases]
    assert {row['block']: row['order'] for row in plan['schedules']} == SCHEDULES
    assert plan['corpus_sha256'] == file_hash(corpus_dir / 'manifest.json')
    policy = plan['resource_policy']
    assert policy['memory_bytes'] == MEMORY and policy['swap_bytes'] == 0 and policy['affinity'] == [0]
    assert int(policy['module_cache_entries']) == 1 and int(policy['module_cache_bytes']) == IMAGE_LIMIT
    assert plan['cache']['limit_bytes'] == 1073741824
    assert file_hash(plan['process_accounting']['supervisor']) == plan['process_accounting']['supervisor_sha256']
    runner = BASE / 'run.py'
    assert file_hash(runner) == plan['runner_sha256']
    if aa:
        assert plan['runtime_invariance'] is None
    else:
        assert plan['runtime_invariance'] == load(BASE / 'runtime-invariance.json')
    published_rows = {row['raw']: row for row in analysis['rows']}
    assert len(published_rows) == len(analysis['rows']) == count
    groups, expected_stems = collections.defaultdict(list), set()
    diagnostics = collections.defaultdict(collections.Counter)
    retention_images = collections.defaultdict(set)
    for index, case in enumerate(cases):
        name = case['file']
        for block, schedule in SCHEDULES.items():
            for ordinal, original_label in enumerate(schedule):
                label = 'baseline-aa' if aa and original_label == 'candidate' else original_label
                stem = f'{block}-case{index:02}-{ordinal}-{label}-{name}'
                expected_stems.add(stem)
                row = published_rows[stem]
                assert (row['case'], row['block'], row['round'], row['product']) == (name, block, ordinal, label)
                report = load(root / 'raw' / (stem + '.stdout'))
                command = load(root / 'raw' / (stem + '.command.json'))
                resource_check(command)
                argv = command['argv']
                assert len(argv) == 6 and Path(argv[0]).resolve() == BASE / label / 'runtime_baseline'
                assert Path(argv[1]).resolve() == corpus_dir and argv[2:5] == ['21', '10', name]
                verify_identity(report, label, records, 'runtime_baseline')
                planned = plan['product_identities'][label]
                for key in ['source_commit', 'source_fingerprint']:
                    assert planned[key] == report[key]
                assert planned['executed_host_sha256'] == report['executable_sha256']
                assert report['schema'] == 'scriptw-wasmtime-baseline-v2'
                assert report['requested_native_policy'] is None and report['samples'] == 21 and report['warmups'] == 10
                assert len(report['cases']) == 1
                actual = report['cases'][0]
                assert actual['file'] == name and actual['source_compilation_profile'] == 'portable'
                assert actual['source_sha256'] == file_hash(corpus_dir / name)
                runtime = runtime_records[label]['-portable']
                assert actual['linked_runtime']['wasm_sha256'] == runtime['wasm_sha256']
                assert actual['linked_runtime']['wasm_bytes'] == runtime['wasm_bytes']
                assert actual['linked_runtime']['key'] == runtime['runtime_key']
                artifact = Path(argv[5]) / (name + '.wasm')
                assert artifact.resolve() == root / 'artifacts' / stem / (name + '.wasm')
                data = artifact.read_bytes()
                assert len(data) == actual['wasm_bytes'] and digest(data) == actual['wasm_sha256']
                functions, code_bytes, largest, code = wasm_code(data)
                assert (functions, code_bytes, largest) == tuple(actual['footprint'][key] for key in
                    ['defined_functions', 'code_body_bytes', 'largest_code_body_bytes'])
                identity = (actual['source_sha256'], actual['wasm_sha256'], len(data), code_bytes, largest, digest(code))
                P_IDENTITIES[(name, label)].add(identity)
                P_CODE[(name, label)] = code
                for number, observation in enumerate(actual['observations']):
                    diagnostics[label + ':P_cache'][observation['module_cache']] += 1
                    if label in records:
                        loading, retention = observation['module_loading'], observation['module_retention']
                        for field in ['runtime_ns', 'program_ns']:
                            assert type(loading[field]) is int and loading[field] >= 0
                        embedded = loading['embedded_image_ns']
                        if embedded is not None:
                            assert set(embedded) == {'admission', 'native_backing_preparation',
                                'native_lease_decode_and_digest', 'deserialize'}
                            assert all(type(value) is int and value >= 0 for value in embedded.values())
                        assert loading['runtime_cache'] in ['Hit', 'Miss', 'Bypassed']
                        assert retention['entry_limit'] == 1 and retention['image_byte_limit'] == IMAGE_LIMIT
                        assert type(retention['entries']) is int and 0 <= retention['entries'] <= 1
                        assert type(retention['image_bytes']) is int and 0 <= retention['image_bytes'] <= IMAGE_LIMIT
                        assert (retention['entries'] == 0) == (retention['image_bytes'] == 0)
                        diagnostics[label + ':R_cache'][loading['runtime_cache']] += 1
                        if number >= 10:
                            diagnostics[label + ':measured_R_cache'][loading['runtime_cache']] += 1
                        retention_images[label].add((retention['entries'], retention['image_bytes']))
                stats = observations(actual, case['stdout'])
                assert stats['times'] == row['times_ns']
                close(stats['median'], row['invocation_median_ns'])
                close(stats['mean'], row['invocation_mean_ns'])
                assert row['process_elapsed_ns'] == command['elapsed_ns']
                stats.update(raw=stem, process_elapsed_ns=command['elapsed_ns'])
                groups[(name, block, label)].append(stats)
    assert {path.name.removesuffix('.stdout') for path in (root / 'raw').glob('*.stdout')} == expected_stems
    assert set(published_rows) == expected_stems
    post = load(root / 'post-product-hash.json')
    assert post['status'] == 'verified'
    labels = ['baseline', 'baseline-aa'] if aa else ['baseline', 'candidate']
    expected = {f'{label}/{name}': row['sha256'] for label in labels
                for name, row in records[label]['hosts'].items()}
    assert post['hashes'] == expected
    assert analysis['frozen_product_hash_check']['hashes'] == expected
    assert analysis['frozen_product_hash_check']['preflight'] == 'verified'
    assert analysis['frozen_product_hash_check']['post_run'] == 'verified'
    assert analysis['frozen_product_hash_check']['runner_sha256'] == plan['runner_sha256']
    result = compare(analysis, groups, cases, aa, False, targets)
    result.update(path=str(root), raw_invocations=count, measured_observations=count * 21, warmups=count * 10,
        actual_P_artifacts_hashed=count, diagnostic_counts=dict(diagnostics),
        retention_image_observations={key: sorted(value) for key, value in retention_images.items()},
        hash_audit='Frozen preflight identities, child-reported hosts and complete post-product hashes independently checked',
        analysis_sha256=file_hash(root / 'analysis.json'), plan_sha256=file_hash(root / 'plan.json'))
    return result


def cp_configuration(config):
    assert config['native_compilation_mode'] == 'size-optimized'
    assert config['register_allocation'] == 'backtracking'
    assert config['consumer_compiler_enabled'] is False
    assert config['gc_initial_bytes'] == 16777216 and config['wasmtime_version'] == '47.0.0'
    assert config['collector'] == 'copying'
    assert config['max_wasm_stack_bytes'] == 33554432 and config['worker_stack_bytes'] == 67108864
    assert config['runtime_policy'] == 'scriptw-required-wasmtime-experimental-v1'


def cp_control(root, cases, records, runtime_records, targets):
    root = root.resolve()
    lane = BASE / 'cp-control'
    plan, analysis = load(root / 'plan.json'), load(root / 'analysis.json')
    assert analysis['status'] == 'complete' and plan['samples'] == 21 and plan['warmups'] == 10
    assert plan['cases'] == [row['file'] for row in cases]
    assert {row['block']: row['order'] for row in plan['schedules']} == SCHEDULES
    policy = plan['resource_policy']
    assert policy['memory_bytes'] == MEMORY and policy['swap_bytes'] == 0 and policy['affinity'] == [0]
    assert policy['module_cache_entries'] == 1 and policy['module_cache_bytes'] == IMAGE_LIMIT
    assert plan['prepared_sha256'] == file_hash(lane / 'prepared.json') == analysis['prepared_sha256']
    assert plan['runtime_invariance_sha256'] == file_hash(BASE / 'runtime-invariance.json')
    prepared = load(lane / 'prepared.json')
    assert prepared['status'] == 'complete' and prepared['manifest_sha256'] == file_hash(CORPUS / 'manifest.json')
    groups, stems, images, receipts = collections.defaultdict(list), set(), {}, {}
    producers = {}
    for label in ['baseline', 'candidate']:
        path = lane / 'prepared' / label / 'producer-receipt.json'
        receipt = load(path)
        producers[label] = receipt
        receipts[label] = file_hash(path)
        assert receipts[label] == plan['producer_receipt_hashes'][label]
        assert receipts[label] == prepared['products'][label]['producer_receipt_sha256']
        verify_identity(receipt['producer'], label, records, 'compiler_precompiled_baseline')
        verify_identity(plan['product_identities'][label], label, records, 'compiler_precompiled_baseline')
        verify_identity(analysis['product_identities'][label], label, records, 'compiler_precompiled_baseline')
        resource_check(receipt['producer_command'])
        cp_configuration(receipt['producer_configuration'])
        assert receipt['producer_configuration'] == records[label]['identity']['shared_configuration']
        assert receipt['producer_configuration_sha256'] == digest(json.dumps(
            receipt['producer_configuration'], sort_keys=True, separators=(',', ':')).encode())
        assert receipt['producer']['compiler_enabled'] is True
        assert receipt['producer']['manifest_sha256'] == file_hash(CORPUS / 'manifest.json')
        producer_raw = lane / 'prepare-run/raw' / f'prepare-{label}'
        assert file_hash(str(producer_raw) + '.stdout') == receipt['producer_stdout_sha256']
        assert file_hash(str(producer_raw) + '.stderr') == receipt['producer_stderr_sha256']
        assert load(str(producer_raw) + '.stdout') == receipt['producer']
        assert load(str(producer_raw) + '.command.json') == receipt['producer_command']
        argv = receipt['producer_command']['argv']
        assert len(argv) == 4 and Path(argv[0]).resolve() == BASE / label / 'compiler_precompiled_baseline'
        assert argv[1] == 'prepare-scriptw' and Path(argv[2]).resolve() == CORPUS
        assert Path(argv[3]).resolve() == lane / 'prepared' / label
        produced_cases = {row['file']: row for row in receipt['producer']['cases']}
        assert set(produced_cases) == {row['file'] for row in cases}
        for case in cases:
            assert receipt['source_hashes'][case['file']] == file_hash(CORPUS / case['file'])
            assert produced_cases[case['file']]['stdout'] == case['stdout']
        for name, image in receipt['image_files'].items():
            path = lane / 'prepared' / label / image['path']
            assert path.is_file() and not path.is_symlink() and path.stat().st_nlink == 1
            assert path.stat().st_size == image['bytes'] and file_hash(path) == image['sha256']
            assert image['runtime_key'] == runtime_records[label]['-portable']['runtime_key']
            assert produced_cases[name]['image_sha256'] == image['sha256']
            assert produced_cases[name]['program_wasm_sha256'] == image['program_wasm_sha256']
            images[f'{label}/{name}'] = image['sha256']
    assert images == plan['prepared_image_hashes']
    for index, case in enumerate(cases):
        name = case['file']
        for block, schedule in SCHEDULES.items():
            for ordinal, label in enumerate(schedule):
                stem = f'{block}-case{index:02}-{ordinal}-{label}-{name}'
                stems.add(stem)
                report = load(root / 'raw' / (stem + '.stdout'))
                command = load(root / 'raw' / (stem + '.command.json'))
                resource_check(command)
                verify_identity(report, label, records, 'compiler_precompiled_baseline')
                receipt = producers[label]
                image = receipt['image_files'][name]
                argv = command['argv']
                assert len(argv) == 6 and Path(argv[0]).resolve() == BASE / label / 'compiler_precompiled_baseline'
                assert argv[1] == 'execute-scriptw' and argv[3:] == [case['stdout'], '21', '10']
                assert Path(argv[2]).resolve() == lane / 'prepared' / label / image['path']
                assert report['schema'] == 'scriptw-precompiled-execution-v1'
                assert report['samples'] == 21 and report['warmups'] == 10
                assert report['adapter'] == 'scriptw' and report['compiler_enabled'] is False
                assert report['comparison_cohort'] == 'scriptw-precompiled-comparison-v1'
                assert report['excluded_from_ordinary_cohorts'] is True
                assert report['shared_configuration'] == receipt['producer_configuration']
                for field in ['runtime_key', 'program_wasm_sha256', 'execution_facts_sha256']:
                    assert report[field] == image[field]
                assert report['image_sha256'] == image['sha256']
                assert all(row['matched'] is True for row in report['observations'])
                assert all(row['completion'] == 'normal' and row['stderr'] == '' for row in report['observations'])
                assert [row['index'] for row in report['observations']] == list(range(31))
                stats = observations(report, case['stdout'], cp=True)
                stats.update(raw=stem, process_elapsed_ns=command['elapsed_ns'])
                groups[(name, block, label)].append(stats)
    assert {path.name.removesuffix('.stdout') for path in (root / 'raw').glob('*.stdout')} == stems
    post = load(root / 'post-input-hashes.json')
    assert post['status'] == 'verified' and post['prepared_images'] == images
    assert post['producer_receipts'] == receipts and post['prepared_manifest_sha256'] == plan['prepared_sha256']
    assert post['host_products'] == {f'{label}/{name}': row['sha256'] for label in ['baseline', 'candidate']
                                   for name, row in records[label]['hosts'].items()}
    result = compare(analysis, groups, cases, False, True, targets)
    result.update(path=str(root), raw_invocations=len(cases)*16, measured_observations=len(cases)*16*21, warmups=len(cases)*16*10,
        compiler_preparations=2, prepared_image_files_hashed=len(images),
        timing_field='observations[].phases_ns.execution',
        runner_sha256=file_hash(lane / 'cp_control.py'),
        fresh_preparation=True,
        scope='Separate hot-R precompiled consumer veto lane; no independent promotion claim',
        analysis_sha256=file_hash(root / 'analysis.json'), plan_sha256=file_hash(root / 'plan.json'))
    return result



def runtimes(product_records):
    record = load(BASE / 'runtime-invariance.json')
    assert record['status'] == 'verified'
    assert record['baseline_source_fingerprint'] == product_records['baseline']['identity']['source_fingerprint']
    assert record['candidate_source_fingerprint'] == product_records['candidate']['identity']['source_fingerprint']
    assert set(record['profiles']) == {'standard', 'portable'}
    result, modules = {}, {}
    for label in ['baseline', 'candidate']:
        profiles = {}
        directory = BASE / label / 'runtime-build'
        for suffix, profile in [('', 'standard'), ('-portable', 'portable')]:
            path = directory / f'scriptw-runtime{suffix}-package.bin'
            package = path.read_bytes()
            assert package[:8] == b'SCRWRB01' and struct.unpack_from('<I', package, 8)[0] == 42
            assert package[12:44].hex() == product_records[label]['identity']['source_fingerprint']
            wasm = package[136:-32]
            assert len(wasm) == struct.unpack_from('<Q', package, 128)[0]
            assert digest(package[:-32]) == package[-32:].hex()
            row = record['profiles'][profile]
            expected = row[label + '_package']
            assert expected['runtime_abi'] == row['runtime_abi'] == 42
            assert expected['runtime_wasm_sha256'] == row[label + '_wasm_sha256'] == digest(wasm)
            assert expected['runtime_wasm_bytes'] == len(wasm)
            assert expected['package_sha256'] == file_hash(path) and expected['package_bytes'] == len(package)
            native = directory / f'scriptw-runtime{suffix}-native.bin'
            assert file_hash(native) == row[label + '_native_sha256']
            profiles[suffix or 'native'] = dict(runtime_key=package[76:108].hex(),
                wasm_sha256=digest(wasm), wasm_bytes=len(wasm), abi=42,
                package_sha256=file_hash(path), package_bytes=len(package),
                native_sha256=file_hash(native), native_bytes=native.stat().st_size)
            modules[(label, profile)] = wasm
        result[label] = profiles
    for suffix, profile in [('', 'standard'), ('-portable', 'portable')]:
        key = suffix or 'native'
        assert modules[('baseline', profile)] == modules[('candidate', profile)], 'P-only candidate changed R Wasm'
        assert record['profiles'][profile]['runtime_wasm_identical'] is True
        assert record['profiles'][profile]['native_identical'] == (result['baseline'][key]['native_sha256'] == result['candidate'][key]['native_sha256'])
    result['baseline-aa'] = result['baseline']
    return result


def native_coverage(product_records):
    folder = BASE / 'native'
    build = [json.loads(line) for line in (BASE / 'native-build.jsonl').read_text().splitlines()]
    assert build[-1] == {'reason': 'build-finished', 'success': True}
    fingerprint = product_records['candidate']['identity']['source_fingerprint']
    unions, binaries, inventories, receipts = {}, {}, {}, {}
    focus_sets = collections.defaultdict(set)
    for stage in ['focus', 'remaining']:
        path = folder / (stage + '-receipt.json')
        receipt = load(path)
        assert receipt['status'] == 'complete' and receipt['stage'] == stage
        assert receipt['candidate_source_fingerprint'] == fingerprint
        receipts[stage] = file_hash(path)
        assert len(receipt['scopes']) == (3 if stage == 'focus' else 8)
        for row in receipt['scopes']:
            target = row['target']
            assert target in EXPECTED_NATIVE_COUNTS and row['candidate_source_fingerprint'] == fingerprint
            assert row['producer'] in build and row['producer']['target']['name'] == target
            assert row['producer']['profile']['test'] is True
            assert row['executable'] == row['producer']['executable']
            assert file_hash(row['executable']) == row['executable_sha256']
            assert binaries.setdefault(target, row['executable_sha256']) == row['executable_sha256']
            assert row['passed'] is True and row['timed_out'] is False
            stem = target
            if row['filter'] is not None:
                stem += '-' + row['filter'].replace('::', '_').strip('_')
            listing = folder / (stem + '.inventory')
            inventory = {line.removesuffix(': test') for line in listing.read_text().splitlines() if line.endswith(': test')}
            assert inventories.setdefault(target, inventory) == inventory
            expected_skips = focus_sets[target] if stage == 'remaining' else set()
            assert set(row['skipped_inventory']) == expected_skips
            selected = {name for name in inventory if (row['filter'] is None or row['filter'] in name) and name not in expected_skips}
            assert selected == set(row['selected_inventory']) and len(selected) == len(row['selected_inventory'])
            expected_argv = [row['executable'], '--test-threads=1']
            if row['filter'] is not None:
                expected_argv += [row['filter'], '--nocapture']
            for name in sorted(expected_skips):
                expected_argv += ['--skip', name]
            assert row['argv'] == expected_argv
            assert load(folder / (stage + '-' + stem + '.json')) == row
            stdout, stderr = folder / row['stdout'], folder / row['stderr']
            passed, failed = native_test_outcomes(row, stdout)
            assert not failed and passed == selected
            assert not unions.setdefault(target, set()).intersection(passed)
            unions[target].update(passed)
            if stage == 'focus':
                focus_sets[target].update(passed)
            file_hash(listing); file_hash(stdout); file_hash(stderr)
    assert {target: len(names) for target, names in unions.items()} == EXPECTED_NATIVE_COUNTS
    for target, names in unions.items():
        if target != 'scriptw_engine':
            assert names == inventories[target]
    return dict(source_fingerprint=fingerprint, native_build_sha256=file_hash(BASE / 'native-build.jsonl'),
        receipts_sha256=receipts, binaries_sha256=binaries,
        selected_counts={target: len(names) for target, names in unions.items()},
        unique_selected_total=sum(map(len, unions.values())),
        selected_tests={target: sorted(names) for target, names in unions.items()},
        scope='Focused and remaining named inventories are disjoint. Engine coverage is38 selected cache/link/profile tests, not the full Engine suite. No full-release or Test262 claim.')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--ordinary', required=True, type=Path)
    parser.add_argument('--aa', type=Path)
    parser.add_argument('--cp', required=True, type=Path)
    parser.add_argument('--candidate-fingerprint', required=True)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    assert len(args.candidate_fingerprint) == 64 and all(c in '0123456789abcdef' for c in args.candidate_fingerprint)
    assert not args.output.exists(), 'preserve prior audit output'
    inputs = load(BASE / 'independent-audit-inputs.json')
    for name, expected in inputs['files_sha256'].items():
        assert file_hash(BASE / name) == expected, f'bound audit input changed: {name}'
    record, cases = corpus()
    study = load(BASE / 'study-plan.json')
    assert study['baseline']['source_fingerprint'] == BASELINE_FP
    assert study['baseline']['source_commit'] == BASELINE_COMMIT
    assert study['baseline']['accepted_at_commit'] == BASELINE_ACCEPTED_COMMIT[:9]
    assert set(study['targets']) == PRIMARY_TARGETS
    controls = set(study['controls']['original']) | set(study['controls']['compact_row'])
    assert len(study['controls']['original']) == 15 and len(study['controls']['compact_row']) == 8
    assert controls == {row['file'] for row in cases} - PRIMARY_TARGETS
    records = products()
    assert records['candidate']['identity']['source_fingerprint'] == args.candidate_fingerprint
    runtime_records = runtimes(records)
    native = native_coverage(records)
    aa = args.aa or (BASE / load(BASE / 'aa-analysis.json')['analysis']).parent
    cohorts = dict(aa=ordinary(aa, cases, records, runtime_records, PRIMARY_TARGETS, aa=True),
        ordinary=ordinary(args.ordinary, cases, records, runtime_records, PRIMARY_TARGETS),
        cp_control=cp_control(args.cp, cases, records, runtime_records, PRIMARY_TARGETS))
    assert all(len(value) == 1 for value in P_IDENTITIES.values())
    footprints = []
    original_names = {row['file'] for row in load(ORIGINAL_CORPUS / 'manifest.json')['execution']}
    for case in cases:
        name = case['file']
        identities = {label: next(iter(P_IDENTITIES[(name, label)])) for label in ['baseline', 'baseline-aa', 'candidate']}
        assert identities['baseline'] == identities['baseline-aa'], 'A/A P copies differ'
        footprints.append(dict(case=name, original=name in original_names, identities=identities,
            P_bytes_equal=identities['baseline'][1] == identities['candidate'][1],
            exact_code_section_equal=P_CODE[(name, 'baseline')] == P_CODE[(name, 'candidate')]))
    assert sum(row['raw_invocations'] for row in cohorts.values()) == 1200
    report = dict(status='audited', audit_script_sha256=file_hash(__file__),
        corpus_sha256=record['manifest_sha256'], products=records, runtimes=runtime_records,
        pre_measurement_audit_inputs=inputs, baseline_accepted_commit=BASELINE_ACCEPTED_COMMIT,
        native_coverage=native, cohorts=cohorts,
        P_footprint_fields=['source_sha256','wasm_sha256','wasm_bytes','code_body_bytes','largest_body_bytes','code_section_sha256'],
        P_footprints=footprints, total_raw_invocations=1200, measured_observations=25200, warmup_observations=12000,
        maximum_recomputed_statistic_discrepancy=MAX_DISCREPANCY, peak_child_rss_bytes=MAX_RSS,
        hashed_files={str(path): value for path,value in HASHED.items()},
        limitations=[
            'Existing artifacts only; no new measurements, builds, tests, conformance or reference replay.',
            'Both ABI42 R Wasm modules must be byte-identical. Packages are separately fingerprint-bound; native image equality is described independently.',
            'All25cases and all observations retained. A/A block1 nested-hole and bad-column swings remain unexplained process variation; no observations are trimmed or used to relax gates.',
            'Runtime cache and RSS diagnostics do not identify GC pauses, page faults, allocator causes or scheduler causes.',
            'Native selected coverage is a disjoint focus/remaining union, including38Engine tests rather than the full Engine suite; no correction chain is assumed.',
            'CP preparation is outside consumer execution. Its native images are byte-hashed and P identities checked against producer receipts, not re-extracted.',
            'The experimental unit is an independent process; pooled samples are descriptive. Ordinary targets are2; all23ordinary controls and all25CP cases retain repeated3percent median-and-mean vetoes.'
        ])
    with args.output.open('x') as stream:
        json.dump(report, stream, indent=2); stream.write('\n')
    print(json.dumps(dict(output=str(args.output),raw_invocations=1200,gates={k:v['gate_pass'] for k,v in cohorts.items()},maximum_statistic_discrepancy=MAX_DISCREPANCY),indent=2))


if __name__ == '__main__':
    main()
