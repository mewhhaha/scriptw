"""Run focused and remaining native scopes from the no-run build, preserving every result."""
import argparse
import json
import os
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
FOLDER = OUT / "native"
sys.path.insert(0, str(ROOT / "scripts"))
from benchmark_metrics import digest
from limited_verification import require_kernel_budget
from native_test_protocol import parse_inventory, result_summaries

FOCUSED = [
    ("scriptw_aot_wasm", "tests::scalar_regions::"),
    ("aot_language", "aot_compact_row_regions::"),
    ("aot_gc_entries", "aot_gc_compact_data_storage::"),
]
FULL_SCOPES = [
    ("scriptw_aot_wasm", None),
    ("scriptw_engine", "memory_module_cache::"),
    ("scriptw_engine", "wasm_runtime_link::tests::"),
    ("scriptw_engine", "runtime_profile::"),
    ("structure_language", None),
    ("emission", None),
    ("aot_language", None),
    ("aot_gc_entries", None),
]


def artifact_rows():
    rows = {}
    for line in (OUT / "native-build.jsonl").read_text().splitlines():
        row = json.loads(line)
        if row.get("reason") == "compiler-artifact" and row.get("executable") and row["profile"]["test"]:
            rows[row["target"]["name"]] = row
    return rows


def save(path, receipt):
    Path(path).write_text(json.dumps(receipt, indent=2) + "\n")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--stage", choices=("focus", "remaining", "all"), default="focus")
    parser.add_argument("--continue-passing-focus", action="store_true", help="retain named passing scopes while failed encoded tests await exact correction")
    args = parser.parse_args()
    require_kernel_budget(4 * 1024 * 1024 * 1024)
    assert len(os.sched_getaffinity(0)) == 1, "run serially under limited_verification"
    FOLDER.mkdir(exist_ok=True)
    artifacts = artifact_rows()
    frozen = json.loads((OUT / "candidate/identity.json").read_text())
    skips = {}
    prior_focus = FOLDER / "focus-receipt.json"
    if args.stage == "remaining":
        assert prior_focus.is_file(), "focused scopes must finish first"
        focus = json.loads(prior_focus.read_text())
        if focus["status"] != "complete":
            assert args.continue_passing_focus and focus["status"] == "failed"
            failed_rows = [row for row in focus["scopes"] if not row["passed"]]
            assert len(failed_rows) == 1 and failed_rows[0]["target"] == "scriptw_aot_wasm"
            row = failed_rows[0]
            assert row["exit_code"] == 101 and row["summaries"] == [["FAILED", "17", "3", "0", "0", "562"]]
            pending = {"tests::scalar_regions::" + name for name in [
                "compact_read_regions_require_closed_paths_and_private_unchanged_inputs",
                "compact_row_misses_exit_before_body_effects_and_release_roots_before_resume",
                "original_object_checksums_have_one_guarded_compact_read_loop"]}
            output = (FOLDER / row["stdout"]).read_text()
            actual = {line.removeprefix("test ").removesuffix(" ... FAILED")
                for line in output.splitlines() if line.startswith("test ") and line.endswith(" ... FAILED")}
            assert actual == pending
            passed_names = {line.removeprefix("test ").removesuffix(" ... ok").removesuffix(" - should panic")
                for line in output.splitlines() if line.startswith("test ") and line.endswith(" ... ok")}
            assert passed_names | pending == set(row["selected_inventory"]) and len(passed_names) == 17
            save(FOLDER / "retained-focus-passes.json", dict(status="partial focus retained; three failed encoded tests remain pending",
                candidate_source_fingerprint=frozen["source_fingerprint"],
                retained_passes={r["target"]: (sorted(passed_names) if r["target"] == "scriptw_aot_wasm" else r["selected_inventory"]) for r in focus["scopes"]},
                pending_tests=sorted(pending), retained_pass_count=40))
        assert focus["candidate_source_fingerprint"] == frozen["source_fingerprint"]
        for row in focus["scopes"]:
            skips.setdefault(row["target"], set()).update(row["selected_inventory"])
        scopes = FULL_SCOPES
        receipt_path = FOLDER / "remaining-receipt.json"
    elif args.stage == "focus":
        scopes = FOCUSED
        receipt_path = prior_focus
    else:
        scopes = FULL_SCOPES
        receipt_path = FOLDER / "all-receipt.json"

    rows = []
    for target, filter_text in scopes:
        producer = artifacts[target]
        executable = Path(producer["executable"])
        executable_sha256 = digest(executable)
        listing = subprocess.check_output([executable, "--list"], text=True)
        inventory = parse_inventory(listing)
        selected = [name for name in inventory
            if (filter_text is None or filter_text in name) and name not in skips.get(target, set())]
        assert selected, f"empty native test scope: {target} {filter_text}"
        stem = target + ("-" + filter_text.replace("::", "_").strip("_") if filter_text else "")
        (FOLDER / f"{stem}.inventory").write_text(listing)
        argv = [str(executable), "--test-threads=1"]
        if filter_text is not None:
            argv.extend([filter_text, "--nocapture"])
        for name in sorted(skips.get(target, set())):
            argv.extend(["--skip", name])
        stdout_path = FOLDER / f"{args.stage}-{stem}.stdout"
        stderr_path = FOLDER / f"{args.stage}-{stem}.stderr"
        started = time.monotonic()
        with stdout_path.open("xb") as stdout, stderr_path.open("xb") as stderr:
            try:
                result = subprocess.run(argv, cwd=ROOT, stdout=stdout, stderr=stderr,
                    timeout=3600, check=False)
                timed_out = False
                exit_code = result.returncode
            except subprocess.TimeoutExpired:
                timed_out = True
                exit_code = 124
        summaries = result_summaries(stdout_path.read_text())
        passed = (exit_code == 0 and not timed_out and len(summaries) == 1
            and summaries[0][0] == "ok" and int(summaries[0][1]) == len(selected)
            and int(summaries[0][2]) == int(summaries[0][3]) == 0)
        row = dict(target=target, filter=filter_text, producer=producer,
            executable=str(executable), executable_sha256=executable_sha256,
            candidate_source_fingerprint=frozen["source_fingerprint"],
            selected_inventory=selected, skipped_inventory=sorted(skips.get(target, set())),
            argv=argv, exit_code=exit_code, timed_out=timed_out, summaries=summaries,
            stdout=stdout_path.name, stderr=stderr_path.name,
            elapsed_seconds=time.monotonic() - started, passed=passed)
        (FOLDER / f"{args.stage}-{stem}.json").write_text(json.dumps(row, indent=2) + "\n")
        rows.append(row)
        receipt = dict(status="running", stage=args.stage,
            candidate_source_fingerprint=frozen["source_fingerprint"], scopes=rows)
        save(receipt_path, receipt)
        print(stem, len(selected), "PASS" if passed else "FAIL", summaries, flush=True)
        assert digest(executable) == executable_sha256, f"test binary changed: {target}"
    receipt["status"] = "complete" if all(row["passed"] for row in rows) else "failed"
    save(receipt_path, receipt)
    if receipt["status"] != "complete":
        raise SystemExit(1)


if __name__ == "__main__":
    main()
