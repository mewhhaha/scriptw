"""Inspect six existing, identity-bound P modules after all campaigns finish.

No compilation, measurements, runtime replay, or native-image loading occurs.
The exact named source fragments include guards and generic continuations;
encoded tests, not textual marker counts, establish compiler admission.
"""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
CASES = ["objects.js", "retained-objects.js", "numeric-loop-50000.js"]
MAX_WAT, MAX_FRAGMENT = 64 << 20, 8 << 20


def load(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def source_fragments(wat, destination):
    lines = wat.read_text(encoding="utf-8").splitlines(keepends=True)
    records, current, first = [], [], None
    for index, line in enumerate(lines, 1):
        if line.startswith("  (func $js::workload#"):
            assert first is None
            first, current = index, []
        if first is None:
            continue
        current.append(line)
        if line.rstrip() != "  )":
            continue
        text = "".join(current)
        assert len(text.encode()) <= MAX_FRAGMENT
        path = destination / (wat.stem + f"-workload-{len(records)}.wat-fragment")
        path.write_text(text, encoding="utf-8")
        instructions = [line.strip() for line in current]
        bounds = [first + offset for offset in range(len(instructions) - 3)
            if instructions[offset:offset + 3] == ["i32.wrap_i64", "i32.lt_u", "i32.eqz"]
            and instructions[offset + 3].startswith("br_if ")]
        records.append(dict(path=path.name, sha256=sha(path), bytes=path.stat().st_size,
            function_header=current[0].strip(), wat_first_line=first, wat_last_line=index,
            indexed_bound_marker_lines=bounds,
            scope="Exact complete named source body, including guard/publication/fallback instructions. "
                "Marker lines locate indexed bounds only; they are not a semantic admission proof."))
        first = None
    assert first is None and records, "actual workload function bodies must be named"
    return records


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--finalize", action="store_true", required=True)
    parser.add_argument("--ordinary", type=Path, required=True)
    parser.add_argument("--wasm-tools", type=Path,
        default=ROOT / "target/performance-fresh-sort/tools/wasm-tools")
    args = parser.parse_args()
    run = args.ordinary.resolve()
    assert run.is_relative_to(BASE)
    analysis, reference = load(run / "analysis.json"), load(BASE / "reference-analysis.json")
    identity, products = load(BASE / "candidate/identity.json"), load(BASE / "candidate/products.json")
    assert analysis["status"] == "complete"
    assert reference["samples"] == 21 and reference["warmups"] == 10
    invariance = load(BASE / "runtime-invariance.json")
    assert invariance["status"] == "verified" and invariance["candidate_source_fingerprint"] == identity["source_fingerprint"]
    assert all(row["runtime_abi"] == 42 and row["runtime_wasm_identical"] for row in invariance["profiles"].values())
    folder = BASE / "program-inspection"
    folder.mkdir(exist_ok=False)
    records = []
    for case in CASES:
        source = BASE / "sources" / case
        source_hash = sha(source)
        assert source_hash == sha(ROOT / "crates/scriptw-cli/tests/fixtures/v8_execution_hotpaths" / case)
        row = next(row for row in analysis["rows"] if row["case"] == case and row["product"] == "candidate")
        report = load(run / "raw" / (row["raw"] + ".stdout"))
        assert report["source_fingerprint"] == identity["source_fingerprint"]
        assert report["executable_sha256"] == products["runtime_baseline"]["sha256"]
        actual = report["cases"][0]
        assert actual["file"] == case and actual["source_sha256"] == source_hash
        scriptw = run / "artifacts" / row["raw"] / (case + ".wasm")
        scriptc = BASE / "scriptc-wasm" / (case + ".wasm")
        for label, path, expected in [("scriptw", scriptw, actual["wasm_sha256"]),
            ("scriptc", scriptc, reference["compilation"][case]["wasm_sha256"])]:
            assert path.is_file() and not path.is_symlink() and sha(path) == expected
            assert path.read_bytes()[:8] == b"\0asm\x01\0\0\0"
            wat = folder / (label + "-" + case + ".wat")
            with wat.open("xb") as stdout:
                subprocess.run([str(args.wasm_tools), "print", str(path)], stdout=stdout,
                    check=True, timeout=120)
            assert wat.stat().st_size <= MAX_WAT
            wat.read_text(encoding="utf-8")
            record = dict(product=label, case=case, original_source_sha256=source_hash,
                source_wasm=str(path.relative_to(BASE)), wasm_sha256=expected, wasm_bytes=path.stat().st_size,
                wat=wat.name, wat_sha256=sha(wat), wat_bytes=wat.stat().st_size)
            if label == "scriptw":
                record.update(source_commit=identity["source_commit"], source_fingerprint=identity["source_fingerprint"],
                    measured_raw=row["raw"], source_compilation_profile=actual["source_compilation_profile"],
                    source_functions=source_fragments(wat, folder))
            else:
                record.update(adapted_source_sha256=sha(BASE / "adapted-scriptc" / case),
                    compiler=reference["tools"]["scriptc"], compilation_receipt=reference["compilation"][case])
            records.append(record)
    assert len(records) == 6
    result = dict(schema="scriptw-compact-row-wasm-inspection-v1", source_commit=identity["source_commit"],
        source_fingerprint=identity["source_fingerprint"], ordinary_run=str(run.relative_to(BASE)),
        tool_version=subprocess.check_output([str(args.wasm_tools), "--version"], text=True).strip(),
        tool_sha256=sha(args.wasm_tools), products=records,
        runtime_invariance=dict(path="runtime-invariance.json", sha256=sha(BASE / "runtime-invariance.json"),
            record=invariance),
        scope="Six actual P modules. R byte equality comes from its separate checked producer record; "
            "no R/native image was printed, loaded, or recompiled by this helper.")
    (folder / "identity.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print("Inspected six frozen P modules and exact named Scriptw workload bodies.")


if __name__ == "__main__":
    main()
