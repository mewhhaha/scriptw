"""Check local workload stdout oracles with system Node; this is not Scriptw coverage."""
import hashlib
import json
import shutil
import subprocess
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
SOURCE_ROOT = OUT / "sources"
RESULTS = OUT / "fixture-output-diagnostic"
NODE = shutil.which("node")
WRAPPER = "globalThis.print = value => console.log(String(value)); require(process.argv[1]);"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    assert NODE, "system Node is required for the standalone oracle check"
    RESULTS.mkdir(exist_ok=True)
    manifest = json.loads((SOURCE_ROOT / "manifest.json").read_text())
    receipt = dict(status="running", oracle="system Node with a print-to-console adapter",
        node_path=str(Path(NODE).resolve()), node_version=subprocess.check_output([NODE, "--version"], text=True).strip(),
        node_executable_sha256=sha(Path(NODE).resolve().read_bytes()), cases=[])
    for case in manifest["execution"]:
        source_path = SOURCE_ROOT / case["file"]
        source_hash = sha(source_path.read_bytes())
        argv = [NODE, "-e", WRAPPER, str(source_path)]
        try:
            result = subprocess.run(argv, cwd=ROOT, capture_output=True, timeout=60, check=False)
            exit_code = result.returncode
            stdout = result.stdout
            stderr = result.stderr
            timed_out = False
        except subprocess.TimeoutExpired as error:
            exit_code = 124
            stdout = error.stdout or b""
            stderr = error.stderr or b""
            timed_out = True
        (RESULTS / (case["file"] + ".stdout")).write_bytes(stdout)
        (RESULTS / (case["file"] + ".stderr")).write_bytes(stderr)
        expected = case["stdout"].encode()
        row = dict(file=case["file"], argv=argv, source_sha256=source_hash,
            expected_stdout=case["stdout"], actual_stdout=stdout.decode("utf-8", errors="replace"),
            stdout_sha256=sha(stdout), stderr_sha256=sha(stderr), exit_code=exit_code,
            timed_out=timed_out,
            matched=(exit_code == 0 and not timed_out and stdout == expected and not stderr))
        receipt["cases"].append(row)
        receipt["status"] = "running"
        (RESULTS / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
        print(case["file"], "PASS" if row["matched"] else "FAIL", flush=True)
    receipt["status"] = "complete" if all(row["matched"] for row in receipt["cases"]) else "failed"
    (RESULTS / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
    if receipt["status"] != "complete":
        raise SystemExit(1)


if __name__ == "__main__":
    main()
