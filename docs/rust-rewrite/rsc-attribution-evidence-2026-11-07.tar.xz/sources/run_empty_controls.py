"""Unscored Node empty-window protocol calibration; never subtract from render."""
import json,subprocess
from pathlib import Path
ROOT=Path.cwd();BASE=ROOT/'target/rsc-attribution-20261107'
folder=BASE/'empty-controls';folder.mkdir(exist_ok=False)
rows=[]
for i in range(3):
 for mode in ['sync','async']:
  name=f'{mode}-{i}'
  argv=['python3','-B',str(BASE/'tools/count_request_pmu.py'),str(folder/name),'--engine','node','--mode',mode,'--binary',str(ROOT/'target/performance-v8-climb-20261104/for-in-set-execution/build-final-3/frozen/rsc_baseline'),'--node','/home/jacobt/.local/share/fnm/node-versions/v24.12.0/installation/bin/node','--baseline-json',str(ROOT/'target/performance-v8-climb-20261104/for-in-set-execution/rsc-final-3/block-0-0-candidate/report.json'),'--samples','100','--warmups','3','--empty-window-calibration']
  with (folder/(name+'.stdout')).open('xb') as out,(folder/(name+'.stderr')).open('xb') as err:
   child=subprocess.run(argv,stdout=out,stderr=err,timeout=100)
  rows.append({'name':name,'mode':mode,'argv':argv,'exit_code':child.returncode})
  (folder/'campaign.json').write_text(json.dumps({'complete':False,'runs':rows},indent=2)+'\n')
  assert child.returncode==0,name
  print('END',name,flush=True)
(folder/'campaign.json').write_text(json.dumps({'complete':True,'runs':rows},indent=2)+'\n')
