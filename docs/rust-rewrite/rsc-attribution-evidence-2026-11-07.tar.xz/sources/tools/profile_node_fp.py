#!/usr/bin/env python3
"""Unscored, checked Node Flight sampling over authenticated request windows."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import signal
import socket
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
TOOLS = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "scripts"))
from limited_verification import kernel_group, limited_environment, require_kernel_budget
from request_profile_support import line, perf_ack, thread_record
from symbolize_fp import symbolize

DRIVER = TOOLS / "node_request_profile.v2.cjs"
PROBE = TOOLS / "perf-probe.json"
ADAPTATION = TOOLS / "node-sampler-adaptation.json"
FIELDS = ("memory.max", "memory.swap.max", "memory.oom.group", "cpu.max", "memory.events")
EVENT = "cycles:u"
PERIOD = 250000
NODE_FLAGS = (
    "--experimental-vm-modules",
    "--no-warnings",
    "--perf-basic-prof-only-functions",
    "--interpreted-frames-native-stack",
)


def digest(path):
    value = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for data in iter(lambda: stream.read(1024 * 1024), b""):
            value.update(data)
    return value.hexdigest()


def load(path):
    return json.loads(Path(path).read_text())


def save(path, value):
    with Path(path).open("x") as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write("\n")


def resources():
    group = kernel_group()
    return {name: (group / name).read_text() for name in FIELDS}


def resources_unchanged(before, after):
    for name in FIELDS:
        if name != "memory.events":
            assert before[name] == after[name], f"resource policy changed: {name}"
    parse = lambda value: dict(line.split() for line in value.splitlines())
    first, last = map(parse, (before["memory.events"], after["memory.events"]))
    for key in ("oom", "oom_kill", "oom_group_kill"):
        assert first.get(key) == last.get(key), f"cgroup OOM event: {key}"


def authenticate_main(pid, fd, socket_inode):
    """Require the Node main TID blocked reading this inherited socket."""
    link = f"socket:[{socket_inode}]"
    assert os.readlink(f"/proc/{pid}/fd/{fd}") == link
    task = Path(f"/proc/{pid}/task/{pid}")
    assert task.is_dir(), "Node PID is not its main TID"
    deadline = time.monotonic() + 2
    last = None
    while time.monotonic() < deadline:
        try:
            syscall = (task / "syscall").read_text().strip()
            fields = syscall.split()
            last = syscall
            if len(fields) >= 2 and fields[0] != "running":
                number, descriptor = int(fields[0], 0), int(fields[1], 0)
                if number in (0, 45, 47) and descriptor == fd:
                    record = thread_record(pid, pid)
                    record["barrier_authentication"] = {
                        "control_fd": fd,
                        "socket_inode": socket_inode,
                        "socket_link": link,
                        "syscall": syscall,
                        "policy": "Node main TID uniquely blocked in read/recv of the exact inherited control socket while the parent withholds ACK.",
                    }
                    return record
        except FileNotFoundError:
            pass
        time.sleep(0.005)
    raise RuntimeError(f"Node main TID did not block on authenticated socket; last syscall={last!r}")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--node", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--mode", choices=("sync", "async"), required=True)
    parser.add_argument("--baseline-json", type=Path, required=True)
    parser.add_argument("--samples", type=int, default=100)
    parser.add_argument("--warmups", type=int, default=3)
    args = parser.parse_args()
    assert 1 <= args.samples <= 200 and args.warmups == 3, "Node cohort requires 1-200 samples and exactly three warmups"
    require_kernel_budget(4 * 1024**3)
    affinity = sorted(os.sched_getaffinity(0))
    assert len(affinity) == 1, "sampling requires one pinned CPU"

    adaptation = load(ADAPTATION)
    assert digest(Path(__file__)) == adaptation["sampler_sha256"], "Node sampler differs from adaptation pin"
    assert tuple(NODE_FLAGS) == tuple(adaptation["node_flags"]), "Node flags differ from adaptation pin"
    assert adaptation["sampling"]["event"] == EVENT and adaptation["sampling"]["period"] == PERIOD
    baseline_path = args.baseline_json.resolve(strict=True)
    baseline = load(baseline_path)
    assert baseline["status"] == "complete"
    inputs = baseline["inputs"]
    source, support = (Path(inputs[name]).resolve(strict=True) for name in ("source", "support"))
    assert digest(source) == inputs["source_sha256"]
    assert digest(support) == inputs["support_sha256"]
    node = args.node.resolve(strict=True)
    assert node == Path(adaptation["node"]["path"]), "Node path differs from adaptation pin"
    assert digest(node) == adaptation["node"]["sha256"], "Node executable differs from adaptation pin"
    assert digest(DRIVER) == adaptation["driver_sha256"], "Node request driver differs from adaptation pin"
    adapted_hash = hashlib.sha256(source.read_bytes() + inputs["wrapper"].encode()).hexdigest()
    assert adapted_hash == inputs["adapted_source_sha256"]
    input_pins = adaptation["input_pins"]
    assert input_pins["source_sha256"] == inputs["source_sha256"]
    assert input_pins["support_sha256"] == inputs["support_sha256"]
    assert input_pins["adapted_source_sha256"] == inputs["adapted_source_sha256"]
    assert input_pins["wrapper"] == inputs["wrapper"]
    assert input_pins["react_versions"] == inputs["versions"]

    probe = load(PROBE)
    perf = Path(probe["unpacked_executable"]).resolve(strict=True)
    assert digest(perf) == probe["unpacked_executable_sha256"]
    folder = args.output.resolve()
    assert folder.is_relative_to(ROOT / "target" / "rsc-attribution-20261107"), "output must stay under the isolated target evidence directory"
    folder.mkdir(parents=True, exist_ok=False)
    tmp = folder / "tmp"
    tmp.mkdir()

    nonce = os.urandom(16).hex()
    env = limited_environment()
    assert not any(key.startswith("SCRIPTW_RSC_PROFILE_") for key in env)
    assert not env.get("NODE_OPTIONS") and not env.get("LD_PRELOAD") and not env.get("LD_AUDIT")
    env.update(
        TMPDIR=str(tmp),
        SCRIPTW_RSC_PROFILE_FD="3",
        SCRIPTW_RSC_PROFILE_NONCE=nonce,
        SCRIPTW_RSC_PROFILE_MODE=args.mode,
    )
    perf_env = limited_environment()
    perf_env.update(TMPDIR=str(tmp), LD_LIBRARY_PATH=str(probe["unpacked_libdir"]))

    parent, child_socket = socket.socketpair()
    fd = child_socket.fileno()
    inode = os.fstat(fd).st_ino
    env["SCRIPTW_RSC_PROFILE_FD"] = str(fd)
    argv = [str(node), *NODE_FLAGS, f"--perf-basic-prof-path={tmp}", str(DRIVER),
            str(source), str(support), str(folder / "observations.json"), str(args.samples), str(args.warmups)]
    baseline_host = digest(node)
    result = {
        "schema": "scriptw-rsc-node-fp-perf-v1",
        "status": "incomplete",
        "unscored": True,
        "argv": argv,
        "node_sha256": baseline_host,
        "node_version": adaptation["node"]["version"],
        "node_flags": list(NODE_FLAGS),
        "mode": args.mode,
        "samples": args.samples,
        "warmups": args.warmups,
        "event": EVENT,
        "period": PERIOD,
        "call_graph": "fp",
        "callchain_scope": "user-only",
        "execution_target": "authenticated-node-main-tid",
        "control_edges_included": True,
        "nonce": nonce,
        "baseline_report_sha256": digest(baseline_path),
        "driver_sha256": digest(DRIVER),
        "source_sha256": digest(source),
        "support_sha256": digest(support),
        "adapted_source_sha256": adapted_hash,
        "perf_sha256": digest(perf),
        "sampler_sha256": digest(Path(__file__)),
        "symbolizer_sha256": digest(TOOLS / "symbolize_fp.py"),
        "tmpdir": str(tmp),
        "limits": "Unscored Node diagnostic. Compile/module initialization, three warmups, JSON encoding and output checks are outside perf windows. The main-thread synchronous barrier edges are included. Perf-map labels are V8 JIT code names; the shared resolver's wasm: prefix is generic and does not mean these addresses are Wasm. Background compiler/GC threads are excluded. No timing, allocation or speedup verdict.",
        "affinity": affinity,
        "resources_before": resources(),
        "events": [],
    }
    save(folder / "plan.json", result)

    child = sampler = None
    pipe_fds = []
    main_record = None
    deadline = time.monotonic() + 180
    map_path = None
    try:
        with (folder / "host.stdout").open("xb") as stdout, \
             (folder / "host.stderr").open("xb") as stderr, \
             (folder / "perf.stdout").open("xb") as perf_stdout, \
             (folder / "perf.stderr").open("xb") as perf_stderr:
            child = subprocess.Popen(argv, cwd=ROOT, env=env, stdin=subprocess.DEVNULL,
                                     stdout=stdout, stderr=stderr, pass_fds=(fd,))
            child_socket.close()
            result["pid"] = child.pid
            map_path = tmp / f"perf-{child.pid}.map"
            for index in range(args.warmups, args.warmups + args.samples):
                for phase in ("ready", "done"):
                    event = line(parent.fileno(), min(30, deadline - time.monotonic()))
                    expected = f"SWRSC1 {nonce} {phase} {args.mode} {index}\n"
                    assert event == expected, (event, expected)
                    result["events"].append({"phase": phase, "index": index, "monotonic_ns": time.monotonic_ns()})
                    if sampler is None:
                        main_record = authenticate_main(child.pid, fd, inode)
                        assert main_record["tid"] == child.pid
                        result["main_thread_before"] = main_record
                        (folder / "maps-before.txt").write_text(Path(f"/proc/{child.pid}/maps").read_text())
                        assert map_path.is_file(), f"V8 perf map missing before sampling: {map_path}"
                        (folder / "perf-before.map").write_bytes(map_path.read_bytes())
                        read_fd, write_fd = os.pipe()
                        ack_read, ack_write = os.pipe()
                        pipe_fds.extend((read_fd, write_fd, ack_read, ack_write))
                        sampler_argv = [str(perf), "record", "--no-buildid", "-e", EVENT, "-c", str(PERIOD),
                                        "-t", str(child.pid), "--delay=-1", "--call-graph", "fp",
                                        "--user-callchains", f"--control=fd:{read_fd},{ack_write}",
                                        "-o", str(folder / "perf.data")]
                        result["perf_argv"] = sampler_argv
                        sampler = subprocess.Popen(sampler_argv, cwd=ROOT, env=perf_env, stdin=subprocess.DEVNULL,
                                                   stdout=perf_stdout, stderr=perf_stderr,
                                                   pass_fds=(read_fd, ack_write))
                    command = b"enable\n" if phase == "ready" else b"disable\n"
                    os.write(write_fd, command)
                    perf_ack(ack_read, result)
                    if phase == "done":
                        after = authenticate_main(child.pid, fd, inode)
                        assert after["tid"] == main_record["tid"]
                        assert after["starttime_ticks"] == main_record["starttime_ticks"]
                        result["main_thread_after_window"] = after
                    if phase == "done" and index + 1 == args.warmups + args.samples:
                        (folder / "maps-after.txt").write_text(Path(f"/proc/{child.pid}/maps").read_text())
                        assert map_path.is_file(), f"V8 perf map disappeared: {map_path}"
                        (folder / "perf.map").write_bytes(map_path.read_bytes())
                        sampler.send_signal(signal.SIGINT)
                        result["perf_exit_code"] = sampler.wait(timeout=5)
                        assert result["perf_exit_code"] in (0, -signal.SIGINT)
                    parent.sendall(expected.replace("SWRSC1", "SWACK1", 1).encode())
            result["host_exit_code"] = child.wait(timeout=30)
        assert result["host_exit_code"] == 0
        assert (folder / "host.stderr").read_bytes() == b""
        report = load(folder / "observations.json")
        assert report["schema"] == "scriptw-rsc-node-pmu-v1"
        assert report["main_thread_pid"] == result["pid"]
        assert report["profiling"]["nonce"] == nonce
        assert report["profiling"]["windows"] == args.samples
        assert report["profiling"]["excluded_from_scored_cohorts"] is True
        assert report["inputs"]["source_sha256"] == inputs["source_sha256"]
        assert report["inputs"]["support_sha256"] == inputs["support_sha256"]
        assert report["inputs"]["adapted_source_sha256"] == inputs["adapted_source_sha256"]
        assert len(report["cases"]) == 1
        case = report["cases"][0]
        assert case["case"] == f"rsc-{args.mode}"
        assert case["exact_node_output_checked"] is True
        assert case["genuine_flight_warmups_checked"] is True
        assert len(case["observations"]) == args.samples + args.warmups
        result["node_versions"] = report["node"]
        resources_unchanged(result["resources_before"], resources())
        script_argv = [str(perf), "script", "-i", str(folder / "perf.data"), "-F",
                       "period,ip,sym,dso", "--no-inline", "--max-stack", "128"]
        result["perf_script_argv"] = script_argv
        with (folder / "samples.txt").open("xb") as out, (folder / "samples.stderr").open("xb") as err:
            parsed = subprocess.run(script_argv, cwd=ROOT, env=perf_env, stdin=subprocess.DEVNULL,
                                    stdout=out, stderr=err, timeout=30)
        assert parsed.returncode == 0
        symbolize(folder)
        result["status"] = "captured"
    except BaseException as error:
        result["status"] = "failed"
        result["error"] = repr(error)
        raise
    finally:
        for process in (sampler, child):
            if process is not None and process.poll() is None:
                process.kill()
                process.wait(timeout=5)
        parent.close()
        child_socket.close()
        for descriptor in pipe_fds:
            os.close(descriptor)
        result["resources_after"] = resources()
        result["raw_files"] = {
            str(path.relative_to(folder)): {"sha256": digest(path), "bytes": path.stat().st_size}
            for path in sorted(folder.rglob("*")) if path.is_file() and path.name != "receipt.json"
        }
        save(folder / "receipt.json", result)
    print(json.dumps({"status": result["status"], "output": str(folder)}), flush=True)


if __name__ == "__main__":
    main()
