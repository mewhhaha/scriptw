"""Fresh repeated unscored request-only hardware diagnostics of frozen RSC."""
import hashlib,json,os,subprocess,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
BASE=Path(__file__).resolve().parent
TOOLS=BASE/'tools'
BINARY=ROOT/'target/performance-v8-climb-20261104/for-in-set-execution/build-final-3/frozen/rsc_baseline'
REFERENCE=ROOT/'target/performance-v8-climb-20261104/for-in-set-execution/rsc-final-3/block-0-0-candidate/report.json'
NODE='/home/jacobt/.local/share/fnm/node-versions/v24.12.0/installation/bin/node'
sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
load=lambda p:json.loads(Path(p).read_text())
reference=load(REFERENCE)
pins={str(p):sha(p) for p in [BINARY,REFERENCE,Path(NODE),TOOLS/'count_request_pmu.py',TOOLS/'node_request_profile.v2.cjs',TOOLS/'request_profile_support.py',TOOLS/'profile_thread.py',ROOT/'scripts/limited_verification.py']}
output=BASE/'pmu';output.mkdir(exist_ok=False)
report={'schema':'scriptw-rsc-request-diagnostic-campaign-v1','complete':False,'samples':100,'warmups':3,'affinity':sorted(os.sched_getaffinity(0)),'pins':pins,'runs':[],'excluded_from_scored_cohorts':True,'limits':'User-only caller/main TID counters including control edges, excluding background threads. Speed is diagnostic, not a default policy. Frozen current published compiler and exact P/R checked. 100-request series has a different JIT/GC history from the scored seven-sample cohort.'}
def save(): (output/'campaign.json').write_text(json.dumps(report,indent=2)+'\n')
save()
for repetition in range(3):
 actors=['fast','speed','node']
 actors=actors[repetition:]+actors[:repetition]
 for mode in ['sync','async']:
  for actor in actors:
   assert all(sha(p)==h for p,h in pins.items())
   name=f'{actor}-{mode}-{repetition}'
   argv=['python3','-B',str(TOOLS/'count_request_pmu.py'),str(output/name),'--engine','node' if actor=='node' else 'scriptw','--mode',mode,'--binary',str(BINARY),'--node',NODE,'--baseline-json',str(REFERENCE),'--samples','100','--warmups','3']
   if actor=='speed': argv+=['--native-mode','speed']
   started=time.monotonic_ns();print('START',name,flush=True)
   with (output/(name+'.stdout')).open('xb') as out,(output/(name+'.stderr')).open('xb') as err:
    child=subprocess.run(argv,cwd=ROOT,stdout=out,stderr=err,timeout=200)
   row={'actor':actor,'mode':mode,'repetition':repetition,'name':name,'argv':argv,'exit_code':child.returncode,'elapsed_ns':time.monotonic_ns()-started}
   report['runs'].append(row);save()
   assert child.returncode==0,name
   receipt=load(output/name/'receipt.json');assert receipt['status']=='captured'
   assert receipt['summary']['minimum_running_fraction']==1
   row['receipt_sha256']=sha(output/name/'receipt.json');save()
   print('END',name,receipt['summary']['multiplex_scaled_median_counts'],flush=True)
assert all(sha(p)==h for p,h in pins.items())
report['complete']=True;save();print('PMU COMPLETE',flush=True)
