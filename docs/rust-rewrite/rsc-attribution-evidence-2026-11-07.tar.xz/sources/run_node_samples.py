"""Repeated Node/V8 request-window FP sampling; separate from timing/PMU."""
import hashlib,json,subprocess
from pathlib import Path
ROOT=Path.cwd();BASE=ROOT/'target/rsc-attribution-20261107';TOOLS=BASE/'tools'
output=BASE/'node-samples';output.mkdir(exist_ok=False)
files=[TOOLS/n for n in ['profile_node_fp.py','node-sampler-adaptation.json','symbolize_fp.py','node_request_profile.v2.cjs','request_profile_support.py']]
sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
pins={str(p):sha(p) for p in files}
report={'schema':'scriptw-rsc-node-sampling-campaign-v1','complete':False,'pins':pins,'runs':[],'limits':'Node V8 JIT-map and interpreter-stack diagnostic flags active; no timing or PMU comparison inferred from these samples. Main thread only. Fresh maps and input checks each process.'}
def save(): (output/'campaign.json').write_text(json.dumps(report,indent=2)+'\n')
save()
for i in range(3):
 for mode in ['sync','async']:
  assert all(sha(p)==h for p,h in pins.items())
  name=f'fp-{mode}-{i}'
  argv=['python3','-B',str(TOOLS/'profile_node_fp.py'),'--node','/home/jacobt/.local/share/fnm/node-versions/v24.12.0/installation/bin/node','--output',str(output/name),'--mode',mode,'--baseline-json',str(ROOT/'target/performance-v8-climb-20261104/for-in-set-execution/rsc-final-3/block-0-0-candidate/report.json'),'--samples','200','--warmups','3']
  print('START',name,flush=True)
  with (output/(name+'.stdout')).open('xb') as out,(output/(name+'.stderr')).open('xb') as err:
   child=subprocess.run(argv,stdout=out,stderr=err,timeout=200)
  row={'name':name,'mode':mode,'repetition':i,'argv':argv,'exit_code':child.returncode};report['runs'].append(row);save()
  assert child.returncode==0,name
  d=json.loads((output/name/'receipt.json').read_text());assert d['status']=='captured'
  row['receipt_sha256']=sha(output/name/'receipt.json');save();print('END',name,flush=True)
report['complete']=True;save();print('NODE SAMPLES COMPLETE',flush=True)
