"""Publish measured request attribution and an explicit inert evidence inventory."""
import hashlib,importlib.util,json,statistics,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];BASE=Path(__file__).resolve().parent
load=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
encoded=lambda value:(json.dumps(value,indent=2,allow_nan=False)+'\n').encode()
reference=ROOT/'target/performance-v8-climb-20261104/for-in-set-execution/rsc-final-3/block-0-0-candidate/report.json'
ref=load(reference);admission=load(BASE/'admission.json');pmu=load(BASE/'pmu/summary.json');leaf=load(BASE/'leaf-summary.json')
assert all(load(BASE/name)['complete'] for name in ['pmu/campaign.json','samples/campaign.json','node-samples/campaign.json','empty-controls/campaign.json'])
receipts=[];flight=0;empty=0;control_windows=0
for p in sorted(BASE.rglob('receipt.json')):
 if any(part in ['tools','sample-pilot-sync','pmu-pilot-scriptw-sync','node-pilot-sync-v2'] for part in p.relative_to(BASE).parts): continue
 d=load(p)
 if d.get('status')=='failed': continue
 assert d['status'] in ['captured','complete'],p
 if 'resources_before' in d and 'memory.events' in d['resources_before']:
  before=dict(line.split() for line in d['resources_before']['memory.events'].splitlines())
  after=dict(line.split() for line in d['resources_after']['memory.events'].splitlines())
  assert all(before.get(k)==after.get(k) for k in ['oom','oom_kill','oom_group_kill']),p
 if p.parent.name in ['entry-controls','entry-runtime-controls']:
  assert d['known_count_windows']==8;control_windows+=8
 else:
  obs=load(p.with_name('observations.json'))
  if d.get('empty_window_calibration'):
   flight+=d['warmups'];empty+=d['samples']
  else:
   flight+=sum(len(case['observations']) for case in obs['cases'])
 receipts.append({'path':str(p.relative_to(BASE)),'sha256':sha(p),'status':d['status']})
helper_counts={}
for mode in ['sync','async']:
 rows=[]
 for folder in [BASE/f'samples/entries-reads-{mode}',BASE/f'samples/entries-construction-{mode}',BASE/f'entries-roundtrip-v2-{mode}']:
  d=load(folder/'receipt.json');assert d['complete']
  for i,e in enumerate(d['entries']):
   values=[w['events'][i]['count'] for w in d['windows']];assert len(values)==7 and len(set(values))==1
   rows.append({'name':e['name'],'median_entries_per_request':statistics.median(values),'range':[min(values),max(values)],'requests':7,'receipt':str((folder/'receipt.json').relative_to(BASE))})
 helper_counts[mode]=rows
node={}
for mode in ['sync','async']:
 processes=[];owners=set()
 for i in range(3):
  p=BASE/f'node-samples/fp-{mode}-{i}/callchains.json';d=load(p);owners.update(r['owner'] for r in d['own'])
  processes.append({'samples':d['samples'],'shares':{r['owner']:r['sample_share'] for r in d['own']},'unavailable':d['unavailable_ip_or_callchain_samples']})
 rows=[{'owner':o.replace('wasm:','v8-jit:',1),'mean_share':statistics.mean(p['shares'].get(o,0) for p in processes)} for o in owners];rows.sort(key=lambda r:r['mean_share'],reverse=True)
 node[mode]={'samples':sum(p['samples'] for p in processes),'unavailable_samples':sum(p['unavailable'] for p in processes),'top_own':rows[:30],'limits':'V8 JIT map/interpreter-stack diagnostic flags active. Function-name leaves do not partition semantic origins. Native context/interceptor work is visible in this vm.Context reference. No main-isolate alternative measured.'}
empty_summary={}
for mode in ['sync','async']:
 values=[]
 for i in range(3):
  d=load(BASE/f'empty-controls/{mode}-{i}/receipt.json');assert d['summary']['minimum_running_fraction']==1
  values.append(statistics.median(w['raw_counts']['instructions:u'] for w in d['windows']))
 empty_summary[mode]={'process_instruction_medians':values,'median_instructions':statistics.median(values),'scope':'Three genuine checked Flight warmups, then 100 checked literal-null windows/process. Same control protocol; not a render and not subtracted from measured rendering counts.'}
identity={k:ref[k] for k in ['source_fingerprint','source_commit','executable_sha256','compiler_identity_scheme','toolchain','configuration','program_wasm_sha256','runtime','inputs']}
findings=[
 {'mechanism':'Internal descriptor-carrier round-trip','measured':'240/250 Reflect.defineProperty entries per sync/async request; observed inclusive caller slice 3.871/3.755 percent, excluding earlier carrier construction. Overlaps other helpers and predicts no gain.','source':['crates/scriptw-aot-wasm/src/objects.rs:2638','crates/scriptw-aot-wasm/src/builtins/reflect.rs:178'],'experiment':'Guard actual OrdinaryObject receivers and pass the validated partial descriptor to canonical ordinary definition; preserve exotic fallback. Replacing the general dispatcher inline would recurse through Proxy forwarding during Rust emission.'},
 {'mechanism':'Ordinary Get repeats an absence/accessor lookup','measured':'7823/8269 object_read entries, 10604/11187 ordinary_property_find entries and 9711/10207 ordinary_own_descriptor entries. These overlapping populations do not identify the duplicate fraction.','source':['crates/scriptw-aot-wasm/src/objects.rs:1849','crates/scriptw-aot-wasm/src/objects/compact_data.rs:762','crates/scriptw-aot-wasm/src/objects/proxy_target_descriptor.rs:358'],'experiment':'Retain a rooted absent/data/accessor result across the ordinary branch while preserving receiver, prototype walk and exotic semantics.'},
 {'mechanism':'Descriptor construction for scalar observations','measured':'262/266 for_in_advance entries; compact ordinary descriptor code constructs StoredValue/PropertyDescriptor even when the observer needs only presence/enumerability. Physical allocation origins were not counted on this compiler.','source':['crates/scriptw-aot-wasm/src/objects/compact_data.rs:961','crates/scriptw-aot-wasm/src/objects/proxy_target_descriptor.rs:158'],'experiment':'Use the existing observation-demand seam to return scalar facts directly; preserve live descriptors and Proxy fallback.'},
 {'mechanism':'Dynamic construction and generic transport','measured':'1707/1790 ordinary_property_append and 2743/2903 function_call entries. No ordinary_property_storage_ensure entries in measured windows; this does not rule out dictionary births or setup promotions.','source':['crates/scriptw-aot-wasm/src/objects/plain_data_literal.rs:59','crates/scriptw-aot-wasm/src/functions/local_argument_call.rs:28'],'experiment':'After narrower removals, measure guarded compact appends and effect-specific internal results. No blanket value/object-model rewrite is justified by these counts.'}]
report={'schema':'scriptw-react-attribution-current-v3','date':'2026-11-07','status':'captured','excluded_from_scored_cohorts':True,'admission':admission,'candidate_identity':identity,'pmu':{'processes':18,'processes_per_actor_mode':3,'samples_per_process':100,'warmups':3,'minimum_running_fraction':1,'events':['cycles:u','instructions:u','branches:u','branch-misses:u'],'policy':'Raw user-only hardware group on authenticated Scriptw caller or Node main TID; no inherited/background threads. Control edges included, compile/initialization/warmups/encode/exact-checks excluded. Median of process medians. Speed changes optimization AND register allocation, R unchanged.','cohorts':pmu,'empty_node_control':empty_summary},'sampling':{'scriptw_processes':6,'node_processes':6,'requests_per_process':200,'warmups':3,'event':'cycles:u','period':250000,'scriptw':leaf,'node':node},'helper_entry_counts':{'processes':6,'request_windows_per_process':7,'warmups':3,'control_known_count_windows':control_windows,'policy':'Pinned task-bound user-only hardware execute breakpoints at same-process authenticated unique entry addresses, 100 percent event running time; control zero/disabled/direct/indirect/recursive/tail/burst cases checked. Counts overlap, do not sum. Per-hit debug traps perturb execution; no timings scored.','modes':helper_counts},'findings':findings,'verification':{'qualified_flight_checks':flight,'checked_literal_null_windows':empty,'known_entry_control_windows':control_windows,'successful_process_receipts':len(receipts),'receipts':receipts,'scope':'Diagnostic producer/consumer qualification only. Runtime source unchanged; no new Test262 or broad semantic-suite result.'},'limits':['All samples/counters retain the current published compiler P/R identity. Frozen build-time Git revision differs from publication HEAD; changed compiler crate files were verified unchanged.','100/200-request diagnostics have different JIT/GC history from seven-sample scored requests. Do not substitute profiled timings into charts.','Leaf categories are disjoint code locations, not removable time or allocation origins. Inlined allocation/guards/value transport are charged to their containing bodies; GC support includes allocation and reference operations as well as collection.','Selected promise/stream/codec leaves exclude source async functions, other async helpers and transitive rendering; their small own share is not total async cost.','FP callchains can truncate; inclusive caller shares overlap. Unknown IPs/symbols remain explicit. Sampling has overhead; no causal gain prediction.','No fresh physical allocation census. External encode/check work occurs between requests in the retained Realm and can influence later timed GC.','Node FP diagnostics add V8 function-map and interpreter-stack flags, separate from PMU and scored timing. Node background compiler/GC threads remain excluded.'],'prior_attribution':{'git_commit':admission['git_head'],'path':'docs/rust-rewrite/react-attribution-current.json','sha256':sha(ROOT/'docs/rust-rewrite/react-attribution-current.json')},'evidence_policy':'Explicit UTF-8 source, counter receipts, emitted sample text, same-process maps and protocol outputs only. Executables, libraries, package payloads, perf.data and large derived callchain rows excluded; regenerate parsed rows with archived symbolizer.'}
(BASE/'measurement.json').write_bytes(encoded(report))
spec=importlib.util.spec_from_file_location('inert_archive',ROOT/'target/react-performance-20261103/archive_final.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);archive=module.Archive()
archive.add_file('reports/measurement.json',BASE/'measurement.json')
for name in ['admission.json','leaf-summary.json','run_pmu.py','run_samples.py','run_node_samples.py','run_roundtrip.py','run_roundtrip_v2.py','run_empty_controls.py','summarize.py','publish.py']:
 archive.add_file('sources/'+name,BASE/name)
for p in sorted((BASE/'tools').iterdir()):
 if p.is_file() and p.suffix in ['.py','.json','.cjs']:archive.add_file('sources/tools/'+p.name,p)
for folder in ['pmu','samples','node-samples','empty-controls']:
 base=BASE/folder
 archive.add_file('evidence/'+folder+'/campaign.json',base/'campaign.json')
 for p in sorted(base.iterdir()):
  if p.is_file() and p.name!='campaign.json':archive.add_file('evidence/'+folder+'/'+p.name,p)
  elif p.is_dir() and (p/'receipt.json').exists():archive.add_profile(p,'evidence/'+folder+'/'+p.name)
for folder in ['entry-controls','entry-runtime-controls','entries-roundtrip-sync','entries-roundtrip-v2-sync','entries-roundtrip-v2-async']:
 archive.add_profile(BASE/folder,'evidence/'+folder)
for name in ['roundtrip-sync.stdout','roundtrip-sync.stderr','roundtrip-v2-sync.stdout','roundtrip-v2-sync.stderr','roundtrip-v2-async.stdout','roundtrip-v2-async.stderr']:
 archive.add_if_file('evidence/'+name,BASE/name)
old=ROOT/'target/performance-v8-climb-20261104/entry-breakpoints-staged'
for name in ['count_entries.py','controls.rs','build_controls.py','prepared.json','control-producer.json']:
 archive.add_file('sources/original-controls/'+name,old/name)
archive.add_file('sources/original-archive.py',ROOT/'target/react-performance-20261103/archive_final.py')
archive.add_file('sources/original-protocol.py',BASE/'tools/mixed_worker_samples.py')
for name in ['crates/scriptw-cli/examples/rsc_baseline.rs','crates/scriptw-cli/tests/fixtures/edge_rendering/react-driver.cjs','crates/scriptw-cli/tests/fixtures/edge_rendering/react-rsc.entry.js','scripts/limited_verification.py']:
 archive.add_file('sources/'+name,ROOT/name)
for name in ['source','support']:archive.add_file('inputs/'+Path(ref['inputs'][name]).name,ref['inputs'][name])
archive.add_file('baseline/report.json',reference)
archive.add_file('baseline/rsc-current.json',ROOT/'docs/rust-rewrite/rsc-current.json')
archive.add_file('baseline/prior-attribution.json',ROOT/'docs/rust-rewrite/react-attribution-current.json')
archive.add_file('baseline/host-producer.json',ROOT/'target/performance-v8-climb-20261104/for-in-set-execution/build-final-3/frozen/rsc_baseline-producer.json')
archive.add_file('baseline/source-manifest.json',ROOT/'target/performance-v8-climb-20261104/for-in-set-execution/source-final-3/manifest.json')
archive.add_bytes('METHODS.txt',b'Unscored request-window diagnostics only. Archive members are inert UTF-8 evidence.\nThe source drivers need a separately built and qualified frozen host and matching baseline JSON; executables are not bundled.\nProfiling drivers and perf package identities are in sources/tools. All native executions use scripts/limited_verification.py.\nSampling text and same-process perf maps can regenerate parsed callchains with symbolize_fp.py.\nRaw binary perf.data and duplicated parsed callchain rows remain local and are excluded.\nRebuilding after a Git identity change requires a new baseline report, not impersonating this frozen source fingerprint.\n')
path=ROOT/'docs/rust-rewrite/rsc-attribution-evidence-2026-11-07.tar.xz'
evidence=archive.write(path);assert evidence['bytes']<128*1024**2
report['evidence_archive']=evidence
(ROOT/'docs/rust-rewrite/react-attribution-current.json').write_bytes(encoded(report))
(BASE/'publication.json').write_bytes(encoded({'complete':True,'archive':evidence,'measurement_sha256':sha(BASE/'measurement.json'),'published_report_sha256':sha(ROOT/'docs/rust-rewrite/react-attribution-current.json')}))
print(json.dumps({'flight_checks':flight,'literal_null_windows':empty,'entry_controls':control_windows,'successful_receipts':len(receipts),'archive':evidence},indent=2))
