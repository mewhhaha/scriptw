#!/usr/bin/env python3
"""Compile only the tiny known-count executable inside the parent-owned cap."""
import hashlib
import json
from pathlib import Path
import subprocess
import time

HERE = Path(__file__).resolve().parent


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


pins = json.loads((HERE / 'prepared.json').read_text())
for path, expected in pins['sha256'].items():
    assert digest(path) == expected, path
assert not (HERE / 'controls').exists()
result = {'argv': pins['rustc_argv'], 'prepared_sha256': digest(HERE / 'prepared.json'),
          'source_sha256': digest(HERE / 'controls.rs'), 'exit_code': None}
started = time.monotonic_ns()
try:
    with (HERE / 'control-build.stdout').open('xb') as out, (HERE / 'control-build.stderr').open('xb') as err:
        process = subprocess.run(pins['rustc_argv'], stdin=subprocess.DEVNULL,
                                 stdout=out, stderr=err, timeout=120, check=False)
    result['exit_code'] = process.returncode
    assert process.returncode == 0
    result['binary_sha256'] = digest(HERE / 'controls')
except Exception as error:
    result['error'] = repr(error)
    raise
finally:
    result['elapsed_ns_unscored'] = time.monotonic_ns() - started
    with (HERE / 'control-producer.json').open('x') as output:
        json.dump(result, output, indent=2)
        output.write('\n')
