//! Unscored real instruction-entry controls. No compiler-generated counters.
use std::arch::global_asm;
use std::hint::black_box;
use std::io::{Read, Write};
use std::os::fd::FromRawFd;
use std::os::unix::net::UnixStream;

// Explicit assembly keeps direct recursion and proper tail entry visible to
// hardware even when Rust's surrounding loops are optimized. SysV x86-64 ABI.
global_asm!(
    r#"
    .text
    .p2align 4
    .global breakpoint_a
    .type breakpoint_a,@function
breakpoint_a:
    test edi, edi
    jz 2f
    sub rsp, 8
    sub edi, 1
    call breakpoint_a
    add rsp, 8
    add eax, 1
    ret
2:
    mov eax, 1
    ret
    .size breakpoint_a, .-breakpoint_a
    .p2align 4
    .global breakpoint_b
    .type breakpoint_b,@function
breakpoint_b:
    jmp breakpoint_a
    .size breakpoint_b, .-breakpoint_b
"#
);

unsafe extern "C" {
    fn breakpoint_a(depth: u32) -> u32;
    fn breakpoint_b(depth: u32) -> u32;
    fn gettid() -> i32;
}

fn exchange(socket: &mut UnixStream, nonce: &str, phase: &str, index: usize) {
    let message = format!("SWRSC1 {nonce} {phase} control {index}\n");
    socket.write_all(message.as_bytes()).unwrap();
    let expected = message.replacen("SWRSC1", "SWACK1", 1);
    let mut response = vec![0; expected.len()];
    socket.read_exact(&mut response).unwrap();
    assert_eq!(response, expected.as_bytes());
}

fn main() {
    assert!(cfg!(all(target_os = "linux", target_arch = "x86_64")));
    let fd: i32 = std::env::var("SCRIPTW_RSC_PROFILE_FD")
        .unwrap()
        .parse()
        .unwrap();
    assert!(fd >= 3);
    let nonce = std::env::var("SCRIPTW_RSC_PROFILE_NONCE").unwrap();
    assert_eq!(nonce.len(), 32);
    assert!(nonce.bytes().all(|byte| byte.is_ascii_hexdigit()));
    let output = std::env::args().nth(1).unwrap();
    std::thread::Builder::new()
        .name("scriptw-execution".into())
        .spawn(move || {
            let mut socket = unsafe { UnixStream::from_raw_fd(fd) };
            socket
                .set_read_timeout(Some(std::time::Duration::from_secs(30)))
                .unwrap();
            socket
                .set_write_timeout(Some(std::time::Duration::from_secs(30)))
                .unwrap();
            let metadata = format!(
                "SWBP1 {nonce} {} {} {:x} {:x}\n",
                std::process::id(),
                unsafe { gettid() },
                breakpoint_a as *const () as usize,
                breakpoint_b as *const () as usize
            );
            socket.write_all(metadata.as_bytes()).unwrap();
            let names = [
                "direct",
                "indirect",
                "recursive",
                "tail",
                "two_addresses",
                "zero",
                "disabled",
                "burst",
            ];
            let expected = [37, 17, 66, 13, 24, 0, 24, 4096];
            for (index, name) in names.iter().enumerate() {
                exchange(&mut socket, &nonce, "ready", index);
                let mut checksum = 0;
                unsafe {
                    match *name {
                        "direct" => {
                            for _ in 0..37 {
                                checksum += breakpoint_a(black_box(0));
                            }
                        }
                        "indirect" => {
                            let call: unsafe extern "C" fn(u32) -> u32 = black_box(breakpoint_a);
                            for _ in 0..17 {
                                checksum += call(black_box(0));
                            }
                        }
                        "recursive" => {
                            for _ in 0..11 {
                                checksum += breakpoint_a(black_box(5));
                            }
                        }
                        "tail" => {
                            for _ in 0..13 {
                                checksum += breakpoint_b(black_box(0));
                            }
                        }
                        "two_addresses" | "disabled" => {
                            for _ in 0..7 {
                                checksum += breakpoint_a(black_box(0));
                            }
                            for _ in 0..17 {
                                checksum += breakpoint_b(black_box(0));
                            }
                        }
                        "zero" => {
                            black_box(0);
                        }
                        "burst" => {
                            for _ in 0..4096 {
                                checksum += breakpoint_a(black_box(0));
                            }
                        }
                        _ => unreachable!(),
                    }
                }
                exchange(&mut socket, &nonce, "done", index);
                assert_eq!(checksum, expected[index], "{name}");
                black_box(checksum);
            }
            let mut file = std::fs::OpenOptions::new()
                .write(true)
                .create_new(true)
                .open(output)
                .unwrap();
            writeln!(
                file,
                "{{\"complete\":true,\"windows\":8,\"checksums_checked\":8}}"
            )
            .unwrap();
        })
        .unwrap()
        .join()
        .unwrap();
}
