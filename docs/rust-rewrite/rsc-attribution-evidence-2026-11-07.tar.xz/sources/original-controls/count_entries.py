#!/usr/bin/env python3
"""Excluded Linux x86-64 task-bound instruction-entry counts; no guest mutation."""
import argparse
import ctypes
import fcntl
import hashlib
import json
import os
from pathlib import Path
import platform
import socket
import struct
import subprocess
import sys
import time

ROOT = Path.cwd()
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'scripts'))
from limited_verification import kernel_group, limited_environment, require_kernel_budget
sys.path.insert(0, str(ROOT / 'target/performance-intrinsic-array-reads-v2-20261102'))
from mixed_worker_samples import line, thread_record

CONTROLS = [('direct', [37, 0]), ('indirect', [17, 0]), ('recursive', [66, 0]),
            ('tail', [13, 13]), ('two_addresses', [24, 17]), ('zero', [0, 0]),
            ('disabled', [0, 0]), ('burst', [4096, 0])]
TARGETS = ['js::ft#f123', 'js::vn#f133']


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def load(path):
    return json.loads(Path(path).read_text())


def save(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


class Breakpoint:
    def __init__(self, tid, address):
        # Pinned Linux perf_event_attr v1 (72 bytes), x86-64 syscall 298.
        # sample_period=0: count only; no mmap/ringbuffer/per-hit records.
        # disabled, pinned, exclude_kernel, exclude_hv; inherit/freq/sigtrap=0.
        flags = (1 << 0) | (1 << 2) | (1 << 5) | (1 << 6)
        self.attr = struct.pack('<IIQQQQQIIQQ', 5, 72, 0, 0, 0, 3, flags, 0, 4, address, ctypes.sizeof(ctypes.c_long))
        assert len(self.attr) == 72
        libc = ctypes.CDLL(None, use_errno=True)
        libc.syscall.restype = ctypes.c_long
        buffer = ctypes.create_string_buffer(self.attr)
        fd = libc.syscall(ctypes.c_long(298), ctypes.byref(buffer), ctypes.c_int(tid),
                          ctypes.c_int(-1), ctypes.c_int(-1), ctypes.c_ulong(8))
        if fd < 0:
            error = ctypes.get_errno()
            raise OSError(error, os.strerror(error), 'perf_event_open hardware execute breakpoint')
        self.fd = fd

    def read(self):
        raw = os.read(self.fd, 24)
        assert len(raw) == 24, 'unscheduled/error-state pinned breakpoint'
        return list(struct.unpack('<QQQ', raw))

    def start(self, enabled):
        fcntl.ioctl(self.fd, 0x2401, 0)  # DISABLE
        fcntl.ioctl(self.fd, 0x2403, 0)  # RESET count; times remain cumulative
        self.before = self.read()
        assert self.before[0] == 0
        if enabled:
            fcntl.ioctl(self.fd, 0x2400, 0)  # ENABLE

    def stop(self, enabled):
        fcntl.ioctl(self.fd, 0x2401, 0)
        after = self.read()
        elapsed = [after[index] - self.before[index] for index in range(3)]
        assert min(elapsed) >= 0
        count, active, running = elapsed
        assert active == running, 'multiplexed/unscheduled event; never scale counts'
        if enabled:
            assert running > 0, 'event never ran'
        else:
            assert elapsed == [0, 0, 0], 'disabled event changed'
        return {'count': count, 'time_enabled_ns': active, 'time_running_ns': running,
                'before': self.before, 'after': after}

    def close(self):
        os.close(self.fd)


def worker(pid):
    workers = [thread_record(pid, int(task.name))
               for task in Path(f'/proc/{pid}/task').iterdir()
               if (task / 'comm').read_text().strip() == 'scriptw-execution'[:15]]
    assert len(workers) == 1, 'require exactly one retained guest worker'
    return workers[0]


def executable_mapping(pid, address):
    matches = []
    for raw in Path(f'/proc/{pid}/maps').read_text().splitlines():
        interval, permissions, *_ = raw.split()
        start, end = [int(value, 16) for value in interval.split('-')]
        if start <= address < end:
            assert 'x' in permissions, ('entry address is not executable', raw)
            matches.append(raw)
    assert len(matches) == 1
    return matches[0]


def prefix(pid, address):
    class IOVec(ctypes.Structure):
        _fields_ = [('base', ctypes.c_void_p), ('length', ctypes.c_size_t)]
    data = ctypes.create_string_buffer(32)
    local = IOVec(ctypes.cast(data, ctypes.c_void_p), len(data))
    remote = IOVec(address, len(data))
    libc = ctypes.CDLL(None, use_errno=True)
    libc.process_vm_readv.restype = ctypes.c_ssize_t
    count = libc.process_vm_readv(pid, ctypes.byref(local), 1, ctypes.byref(remote), 1, 0)
    assert count == len(data), ('cannot authenticate own child entry bytes', ctypes.get_errno())
    return bytes(data).hex()


def source_entries(pid, folder, phase):
    raw = Path(f'/tmp/perf-{pid}.map').read_bytes()
    (folder / f'perf-{phase}.map').write_bytes(raw)
    entries = []
    for row in raw.decode().splitlines():
        address, size, name = row.split(maxsplit=2)
        entries.append({'address': int(address, 16), 'size': int(size, 16), 'name': name})
    selected = []
    for name in TARGETS:
        source_id = name.split('#')[1]
        source_name = name.split('#')[0]
        family = [entry for entry in entries if source_id in entry['name'] or source_name in entry['name']]
        assert len(family) == 1 and family[0]['name'] == name, ('entry aliases/clones require a new plan', family)
        entry = family[0]
        overlaps = [other for other in entries
                    if other['address'] <= entry['address'] < other['address'] + other['size']]
        assert overlaps == [entry], ('ambiguous perf map entry', overlaps)
        selected.append(entry | {'mapping': executable_mapping(pid, entry['address']),
                                 'prefix_hex': prefix(pid, entry['address'])})
    assert selected[0]['address'] != selected[1]['address']
    return selected


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=['control', 'sync', 'async'])
    parser.add_argument('output', type=Path)
    parser.add_argument('--samples', type=int, default=7)
    args = parser.parse_args()
    assert platform.system() == 'Linux' and platform.machine() == 'x86_64'
    require_kernel_budget(4 * 1024**3)
    assert len(os.sched_getaffinity(0)) == 1
    assert 1 <= args.samples <= 20
    pins = load(HERE / 'prepared.json')
    for path, expected in pins['sha256'].items():
        assert digest(path) == expected, path
    assert Path('/sys/bus/event_source/devices/breakpoint/type').read_text().strip() == '5'
    baseline = load(pins['baseline'])
    control_producer = load(HERE / 'control-producer.json')
    assert control_producer['exit_code'] == 0
    assert control_producer['prepared_sha256'] == digest(HERE / 'prepared.json')
    assert control_producer['source_sha256'] == digest(HERE / 'controls.rs')
    assert control_producer['binary_sha256'] == digest(HERE / 'controls')
    controls = args.mode == 'control'
    if not controls:
        passed = load(HERE / 'controls-result/receipt.json')
        assert passed['status'] == 'complete' and passed['known_count_windows'] == 8
        assert passed['driver_sha256'] == digest(__file__)
        assert passed['kernel_release'] == platform.release()
        assert passed['control_binary_sha256'] == control_producer['binary_sha256']
    folder = args.output.resolve()
    assert folder.parent == HERE
    folder.mkdir(exist_ok=False)
    nonce = os.urandom(16).hex()
    parent, child_socket = socket.socketpair()
    env = limited_environment()
    assert not any(key.startswith('SCRIPTW_RSC_PROFILE_') for key in env)
    assert 'LD_PRELOAD' not in env and 'LD_AUDIT' not in env
    env.update(SCRIPTW_RSC_PROFILE_FD=str(child_socket.fileno()), SCRIPTW_RSC_PROFILE_NONCE=nonce)
    samples, warmups = args.samples, 3
    if controls:
        binary = HERE / 'controls'
        samples, warmups = len(CONTROLS), 0
        argv = [str(binary), str(folder / 'observations.json')]
    else:
        binary = Path(pins['binary'])
        env['SCRIPTW_RSC_PROFILE_MODE'] = args.mode
        argv = [str(binary), baseline['inputs']['source'], baseline['inputs']['support'],
                str(folder / 'observations.json'), str(samples), str(warmups)]
    result = {'status': 'incomplete', 'unscored': True, 'mode': args.mode,
              'driver_sha256': digest(__file__), 'prepared_sha256': digest(HERE / 'prepared.json'),
              'kernel_release': platform.release(), 'nonce': nonce, 'argv': argv,
              'binary_sha256': digest(binary), 'windows': [],
              'event': {'type': 5, 'bp_type': 4, 'bp_len': ctypes.sizeof(ctypes.c_long), 'sample_period': 0,
                        'pinned': True, 'inherit': False, 'user_only': True, 'cpu': -1},
              'limits': 'Excluded counting experiment; #DB per entry perturbs execution. No timing, allocation or speedup claim. Counts are attempted native entries, including proper-tail entries; no extrapolation to actual argument boxing.',
              'environment': {name: Path(path).read_text().strip() for name, path in {
                  'perf_event_paranoid': '/proc/sys/kernel/perf_event_paranoid',
                  'nmi_watchdog': '/proc/sys/kernel/nmi_watchdog'}.items()},
              'resources_before': {name: (kernel_group() / name).read_text() for name in
                                   ['memory.max', 'memory.swap.max', 'memory.oom.group', 'cpu.max', 'memory.events']}}
    child, events = None, []
    deadline = time.monotonic() + 180
    try:
        with (folder / 'host.stdout').open('xb') as out, (folder / 'host.stderr').open('xb') as err:
            child = subprocess.Popen(argv, cwd=ROOT, env=env, stdin=subprocess.DEVNULL,
                                     stdout=out, stderr=err, pass_fds=(child_socket.fileno(),))
            child_socket.close()
            result['pid'] = child.pid
            metadata = None
            if controls:
                raw = line(parent.fileno(), 30)
                words = raw.strip().split()
                assert len(words) == 6 and words[:2] == ['SWBP1', nonce]
                assert int(words[2]) == child.pid
                metadata = {'tid': int(words[3]), 'addresses': [int(word, 16) for word in words[4:]]}
                assert len(set(metadata['addresses'])) == 2
                result['control_metadata'] = metadata
            for index in range(warmups, warmups + samples):
                enabled = True
                if controls and CONTROLS[index][0] == 'disabled':
                    enabled = False
                for phase in ['ready', 'done']:
                    timeout = min(60, deadline - time.monotonic())
                    assert timeout > 0
                    raw = line(parent.fileno(), timeout)
                    expected = f'SWRSC1 {nonce} {phase} {args.mode} {index}\n'
                    assert raw == expected, (raw, expected)
                    if not events:
                        actual_worker = worker(child.pid)
                        result['worker_before'] = actual_worker
                        (folder / 'maps-before.txt').write_text(Path(f'/proc/{child.pid}/maps').read_text())
                        if controls:
                            assert metadata['tid'] == actual_worker['tid']
                            entries = [{'name': name, 'address': address,
                                        'mapping': executable_mapping(child.pid, address),
                                        'prefix_hex': prefix(child.pid, address)}
                                       for name, address in zip(['breakpoint_a', 'breakpoint_b'], metadata['addresses'])]
                        else:
                            entries = source_entries(child.pid, folder, 'before')
                        result['entries'] = entries
                        for entry in entries:
                            event = Breakpoint(actual_worker['tid'], entry['address'])
                            events.append(event)
                            entry['perf_attr_hex'] = event.attr.hex()
                    if phase == 'ready':
                        for event in events:
                            event.start(enabled)
                    else:
                        counts = [event.stop(enabled) for event in events]
                        window = {'index': index, 'enabled': enabled, 'events': counts}
                        result['windows'].append(window)
                        if controls:
                            name, wanted = CONTROLS[index]
                            window.update(name=name, expected_counts=wanted)
                            assert [event['count'] for event in counts] == wanted, window
                        if index + 1 == warmups + samples:
                            after = worker(child.pid)
                            assert after['tid'] == actual_worker['tid']
                            assert after['starttime_ticks'] == actual_worker['starttime_ticks']
                            result['worker_after'] = after
                            (folder / 'maps-after.txt').write_text(Path(f'/proc/{child.pid}/maps').read_text())
                            if not controls:
                                after_entries = source_entries(child.pid, folder, 'after')
                                assert after_entries == [{key: value for key, value in entry.items()
                                                          if key != 'perf_attr_hex'} for entry in entries]
                    parent.sendall(expected.replace('SWRSC1', 'SWACK1', 1).encode())
            result['exit_code'] = child.wait(timeout=max(1, min(30, deadline - time.monotonic())))
        assert result['exit_code'] == 0
        report = load(folder / 'observations.json')
        if controls:
            assert report == {'complete': True, 'windows': 8, 'checksums_checked': 8}
            result['known_count_windows'] = 8
            result['control_binary_sha256'] = digest(binary)
        else:
            assert report['profiling']['nonce'] == nonce
            assert report['profiling']['windows'] == samples
            assert report['profiling']['excluded_from_scored_cohorts'] is True
            for key in ['inputs', 'program_wasm_sha256', 'program_wasm_bytes', 'runtime', 'configuration',
                        'source_fingerprint', 'executable_sha256', 'native_mode']:
                assert report[key] == baseline[key], key
            assert len(report['cases']) == 1
            case = report['cases'][0]
            assert case['case'] == 'rsc-' + args.mode and case['exact_node_output_checked']
            assert case['samples'] == samples and case['warmups'] == warmups
            assert len(case['observations']) == samples + warmups
            result['exact_flight_checks'] = len(case['observations'])
            result['program_wasm_sha256'] = report['program_wasm_sha256']
            result['runtime'] = report['runtime']
            result['source_fingerprint'] = report['source_fingerprint']
        result['status'] = 'complete'
    except Exception as error:
        result['error'] = repr(error)
        result['status'] = 'failed'
        raise
    finally:
        for event in events:
            event.close()
        if child is not None and child.poll() is None:
            child.kill()
            child.wait(timeout=5)
        parent.close()
        child_socket.close()
        result['resources_after'] = {name: (kernel_group() / name).read_text() for name in
                                     ['memory.events', 'memory.current']}
        result['raw_files'] = {path.name: {'sha256': digest(path), 'bytes': path.stat().st_size}
                               for path in folder.iterdir() if path.is_file()}
        save(folder / 'receipt.json', result)
    print(json.dumps({'status': result['status'], 'output': str(folder)}))


if __name__ == '__main__':
    main()
