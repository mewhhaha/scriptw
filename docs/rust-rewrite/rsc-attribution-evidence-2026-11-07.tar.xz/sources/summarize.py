"""Disjoint named-function leaf attribution; inclusive callers remain separate."""
import collections,hashlib,json,statistics
from pathlib import Path
BASE=Path(__file__).resolve().parent
GROUPS=['Compiled JS bodies/adapters','Object/property/enumeration functions','Selected promise/stream/text-codec functions','Other compiled runtime functions','Wasmtime GC support routines','Wasmtime subtype routines','Other resolved host functions','Unresolved samples']
def category(owner):
 if owner.startswith(('wasm:js::','wasm:js-arguments-adapter::')): return GROUPS[0]
 if owner.startswith('wasm:'):
  name=owner.removeprefix('wasm:')
  if name.startswith('helper::') and name.removeprefix('helper::').startswith(('ordinary_','intrinsic_property_','object_','property_','for_in_','cached_property_','dynamic_property_','compact_')): return GROUPS[1]
  if name.startswith(('builtin::Reflect.','builtin::Object.')): return GROUPS[1]
  if name.startswith(('builtin::Promise','builtin::Readable','builtin::TextEncoder','builtin::TextDecoder','helper::promise_')): return GROUPS[2]
  return GROUPS[3]
 if 'gc::enabled::copying::' in owner: return GROUPS[4]
 if 'is_subtype' in owner or 'ModuleRuntimeInfo>::engine_type_index' in owner: return GROUPS[5]
 if '[unknown]' in owner or owner.startswith(('<unavailable','<zero IP>')): return GROUPS[7]
 return GROUPS[6]
result={'schema':'scriptw-rsc-exclusive-leaf-summary-v1','group_order':GROUPS,'aggregation':'Arithmetic mean of per-process leaf shares, three processes/mode, 200 request windows/process. This makes exhaustive disjoint groups sum to one; process ranges retained. Not wall time or origin attribution.','limits':'Function-name classification only: compiled JS and runtime bodies include inlined allocation, value transport and guards. Collector routines exclude inline allocation. Inclusive stacks overlap and may truncate. Unknown/unavailable samples remain explicit.','modes':{}}
for mode in ['sync','async']:
 processes=[];owners=set();members=collections.defaultdict(set)
 for i in range(3):
  path=BASE/f'samples/fp-{mode}-{i}/callchains.json';d=json.loads(path.read_text());receipt=json.loads(path.with_name('receipt.json').read_text());assert receipt['status']=='captured'
  rows={r['owner']:r['period_sum'] for r in d['own']};assert sum(rows.values())==d['period_sum']
  grouped=collections.Counter()
  for owner,weight in rows.items():
   group=category(owner);grouped[group]+=weight;members[group].add(owner)
  assert sum(grouped.values())==d['period_sum'];owners.update(rows)
  total=d['period_sum'];chains=d['rows'];reflect=[]
  reflect_weight=sum(s['period'] for s in chains if any(f['owner']=='wasm:builtin::Reflect.defineProperty' for f in s['resolved_chain']))
  processes.append({'source':str(path.relative_to(BASE)),'samples':d['samples'],'period_sum':total,'unavailable_samples':d['unavailable_ip_or_callchain_samples'],'group_shares':{g:grouped[g]/total for g in GROUPS},'own_shares':{o:w/total for o,w in rows.items()},'reflect_in_observed_chain_share':reflect_weight/total,'chain_depth_histogram':d['chain_depth_histogram']})
 shares={g:statistics.mean(p['group_shares'][g] for p in processes) for g in GROUPS};assert abs(sum(shares.values())-1)<1e-12
 own=[{'owner':o,'mean_share':statistics.mean(p['own_shares'].get(o,0) for p in processes),'range':[min(p['own_shares'].get(o,0) for p in processes),max(p['own_shares'].get(o,0) for p in processes)]} for o in owners];own.sort(key=lambda r:r['mean_share'],reverse=True)
 result['modes'][mode]={'samples':sum(p['samples'] for p in processes),'groups':{g:{'mean_share':shares[g],'range':[min(p['group_shares'][g] for p in processes),max(p['group_shares'][g] for p in processes)],'members':sorted(members[g])} for g in GROUPS},'top_own':own[:40],'processes':processes,'reflect_in_observed_chain_share':statistics.mean(p['reflect_in_observed_chain_share'] for p in processes)}
 print(mode,'samples',result['modes'][mode]['samples'])
 for g in GROUPS: print(g,round(shares[g]*100,2))
 print('Reflect inclusive',100*result['modes'][mode]['reflect_in_observed_chain_share'])
(BASE/'leaf-summary.json').write_text(json.dumps(result,indent=2)+'\n')
