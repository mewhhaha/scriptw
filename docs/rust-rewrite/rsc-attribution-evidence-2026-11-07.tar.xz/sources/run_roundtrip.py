"""Exact instruction-entry census of the internal descriptor-carrier path."""
import json,subprocess
from pathlib import Path
ROOT=Path.cwd();BASE=ROOT/'target/rsc-attribution-20261107';TOOLS=BASE/'tools'
assert json.loads((BASE/'samples/campaign.json').read_text())['complete']
for mode in ['sync','async']:
 folder=BASE/('entries-roundtrip-'+mode)
 argv=['python3','-B',str(TOOLS/'count_helper_entries.py'),'--binary',str(ROOT/'target/performance-v8-climb-20261104/for-in-set-execution/build-final-3/frozen/rsc_baseline'),'--baseline-json',str(ROOT/'target/performance-v8-climb-20261104/for-in-set-execution/rsc-final-3/block-0-0-candidate/report.json'),'--mode',mode,'--samples','7','--controls-receipt',str(BASE/'entry-controls/receipt.json'),'--output',str(folder)]
 for name in ['helper::ordinary_set_data_on_receiver','builtin::Reflect.defineProperty','helper::object_has_property','helper::function_call']: argv+=['--target',name]
 print('START',mode,flush=True)
 with (BASE/('roundtrip-'+mode+'.stdout')).open('xb') as out,(BASE/('roundtrip-'+mode+'.stderr')).open('xb') as err:
  child=subprocess.run(argv,stdout=out,stderr=err,timeout=200)
 assert child.returncode==0,mode
 print('END',mode,flush=True)
