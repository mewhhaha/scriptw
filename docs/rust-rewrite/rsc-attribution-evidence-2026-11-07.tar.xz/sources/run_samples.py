"""Repeated unscored leaf samples and exact helper-entry counts, serially."""
import hashlib,json,os,subprocess,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];BASE=Path(__file__).resolve().parent;TOOLS=BASE/'tools'
BINARY=ROOT/'target/performance-v8-climb-20261104/for-in-set-execution/build-final-3/frozen/rsc_baseline'
REFERENCE=ROOT/'target/performance-v8-climb-20261104/for-in-set-execution/rsc-final-3/block-0-0-candidate/report.json'
sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
load=lambda p:json.loads(Path(p).read_text())
assert load(BASE/'pmu/campaign.json')['complete']
output=BASE/'samples';output.mkdir(exist_ok=False)
pins={str(p):sha(p) for p in [BINARY,REFERENCE,TOOLS/'profile_rsc_fp.py',TOOLS/'count_helper_entries.py',TOOLS/'request_profile_support.py',TOOLS/'profile_thread.py',TOOLS/'symbolize_fp.py',TOOLS/'perf-probe.json',BASE/'entry-controls/receipt.json']}
probe=load(TOOLS/'perf-probe.json');pins[probe['unpacked_executable']]=sha(probe['unpacked_executable'])
report={'schema':'scriptw-rsc-sampling-entry-campaign-v1','complete':False,'pins':pins,'runs':[],'affinity':sorted(os.sched_getaffinity(0)),'limits':'Request-window user-cycle samples and separate hardware entry counts. Control edges included. No profiled timings are scores. Leaf samples disjoint; inclusive callers and helper entry populations overlap.'}
def save(): (output/'campaign.json').write_text(json.dumps(report,indent=2)+'\n')
def run(kind,name,argv):
 assert all(sha(p)==h for p,h in pins.items())
 started=time.monotonic_ns();print('START',name,flush=True)
 with (output/(name+'.stdout')).open('xb') as out,(output/(name+'.stderr')).open('xb') as err:
  child=subprocess.run(argv,cwd=ROOT,stdout=out,stderr=err,timeout=200)
 row={'kind':kind,'name':name,'argv':argv,'exit_code':child.returncode,'elapsed_ns':time.monotonic_ns()-started};report['runs'].append(row);save()
 assert child.returncode==0,name
 receipt=load(output/name/'receipt.json');assert receipt['status'] in ['complete','captured']
 row['receipt_sha256']=sha(output/name/'receipt.json');save();print('END',name,flush=True)
save()
for repetition in range(3):
 for mode in ['sync','async']:
  name=f'fp-{mode}-{repetition}'
  run('fp',name,['python3','-B',str(TOOLS/'profile_rsc_fp.py'),str(BINARY),str(output/name),'--mode',mode,'--samples','200','--warmups','3','--baseline-json',str(REFERENCE)])
groups={'reads':['object_read','ordinary_property_find','ordinary_own_descriptor','cached_property_read'],'construction':['ordinary_property_append','ordinary_property_storage_ensure','intrinsic_property_find','for_in_advance']}
for group,helpers in groups.items():
 for mode in ['sync','async']:
  name=f'entries-{group}-{mode}'
  argv=['python3','-B',str(TOOLS/'count_helper_entries.py'),'--binary',str(BINARY),'--baseline-json',str(REFERENCE),'--mode',mode,'--samples','7','--controls-receipt',str(BASE/'entry-controls/receipt.json'),'--output',str(output/name)]
  for helper in helpers: argv+=['--target','helper::'+helper]
  run('entries',name,argv)
assert all(sha(p)==h for p,h in pins.items())
report['complete']=True;save();print('SAMPLES AND COUNTS COMPLETE',flush=True)
