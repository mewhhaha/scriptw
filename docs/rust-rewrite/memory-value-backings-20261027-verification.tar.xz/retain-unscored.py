"""Retain inert mapping observations after their complete source-bound validation."""
import hashlib,json,shutil,sys
from pathlib import Path
BASE=Path(__file__).resolve().parent;run=sys.argv[1]
report=json.loads((BASE/f'ci-mapping-components-{run}.json').read_text())
assert report['source_commit']=='f3df68beb76f18506f070fe54b95e80fe2db22be'
source=BASE/f'github-{run}/precompiled-mapping-diagnostic-unscored'
target=BASE/f'ci-unscored-{run}';target.mkdir(exist_ok=False)
rows=[];total=0
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
for path in sorted(source.rglob('*')):
 assert not path.is_symlink()
 if not path.is_file():continue
 relative=path.relative_to(source);assert '..' not in relative.parts
 size=path.stat().st_size;total+=size;assert size<=16*1024**2 and total<=128*1024**2
 with path.open('rb') as stream:assert not stream.read(8).startswith((b'\x7fELF',b'MZ',b'SCRWEP01',b'SCRWEP02',b'SCRWWA01'))
 dest=target/relative;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(path,dest)
 assert sha(path)==sha(dest)
 rows.append(dict(path=relative.as_posix(),bytes=size,sha256=sha(dest)))
record=dict(source_commit=report['source_commit'],run=run,scored=False,files=rows,total_bytes=total,
 interpretation='Validated asynchronous mapping observations only; not canonical peaks, aligned phases, live heap or causal savings.')
(BASE/'ci-unscored-retention.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(dict(files=len(rows),bytes=total)))
