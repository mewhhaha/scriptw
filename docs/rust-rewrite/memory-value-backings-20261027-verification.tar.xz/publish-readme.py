"""Publish prose only after complete verification and paired measurement admission."""
import json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'scripts'))
import precompiled_comparison as p
stem='memory-value-backings-20261027'
record=json.loads((ROOT/'docs/rust-rewrite'/f'{stem}.json').read_text())
report,rows=p.load_report(ROOT/'docs/rust-rewrite/precompiled-comparison.json',ROOT/'docs/rust-rewrite/precompiled-comparison.tar.gz')
source='f3df68beb76f18506f070fe54b95e80fe2db22be'
assert report['source_commit']==record['measured_source_commit']==record['verified_source_commit']==source
assert record['test262']['total']==record['test262']['passed']==2365
assert record['native']['passed']>=4868 and len(rows)==17
summary=json.loads((Path(__file__).resolve().parent/'measured-summary.json').read_text())
assert summary['source']==source
table={r['file']:r for r in summary['table']}
ratio=f"{summary['ratio_min']:.1f}–{summary['ratio_max']:.1f}"
native=f"{record['native']['passed']:,}"
readme=ROOT/'README.md';s=readme.read_text()
start=s.index('**Measured 2026-10-27 on one GitHub Actions runner**, compiler `0bd2c2ea7`.')
end=s.index('\n## Benchmarks',start)
lines=[f'**Measured 2026-10-27 on one GitHub Actions runner**, compiler `{source[:9]}`.',
'The [precompiled benchmark workflow](docs/rust-rewrite/contracts/precompiled-comparison.md)',
'compares Scriptw and Scriptc in the same Wasmtime executable, with JavaScript',
'and Wasm compilation in separate producer processes. Both measured consumers',
'disable compilation and use identical native optimization and runtime settings.',
'Both passed the original checksums on **17/17 workloads** across two rounds.',
f"Scriptw's median post-execution process RSS remains **{ratio}× Scriptc's**:",'',
'| Workload | Scriptw RSS | Scriptc RSS |','| --- | ---: | ---: |']
for label,file in [('Integer','integer.js'),('Objects','objects.js'),('Retained objects','retained-objects.js')]:
 r=table[file];lines.append(f"| {label} | {r['scriptw_rss_mib']:.1f} MiB | {r['scriptc_rss_mib']:.1f} MiB |")
lines+=['',
'These are medians of 14 samples per runtime and workload, after ten checked',
'warmups per round, with each Store still alive. Process memory is sampled at',
'loading, setup, execution and Store-drop boundaries; RSS is neither live JS',
'heap nor peak memory. This cohort stays separate from the ordinary V8 comparison',
'below. The matched Scriptc footprint remains the execution-memory target, with',
'the same workloads, checksums and measurement boundaries.',
'The current pass packs default mixed Array values, allocates compact-object',
'reference backing on first nonnull payload, and shares intrinsic-method property',
'publication while preserving separate mutable descriptors for aliases.',
f'[Verification](docs/rust-rewrite/{stem}.md):',
f'**{native} native cases and 2,365 original pinned Test262 executions passed**.',
'Verification retained one CPU, a 4-GiB process-tree cap, no swap and bounded',
'module retention. Original conformance executions ran in fresh batches of at',
'most 16. Measured and verified product compiler inputs match. This selected',
'verification does not refresh the full pinned-suite status below.','',
'[All measurements and complete evidence](docs/rust-rewrite/precompiled-comparison.md) ·',
'[Precompiled execution-time graph](docs/rust-rewrite/assets/precompiled-execution.svg) ·',
f"[CI run]({record['measurement']['url']}).",'']
readme_text=s[:start]+'\n'.join(lines)+s[end:]
contract=ROOT/'docs/rust-rewrite/contracts/compact-value-backing.md'
text=contract.read_text()
assert 'pending' in text.lower(),text[-1500:]
# Keep implementation details and replace the existing explicit verification footer.
marker='Implementation, focused controls and documentation are being prepared together'
if marker not in text:
 raise AssertionError('Inspect exact pending contract footer before publication')
text=text[:text.index(marker)]+f'''The source-bound batch passed {native} native cases and 2,365 original pinned
Test262 executions. The matched 17-workload comparison remains {ratio}× Scriptc
process RSS. These runner observations do not isolate a causal saving from any
individual storage or publication change.
See [verification and measurements](../{stem}.md).
'''
contract_text=text
doc=f'''# Compact value backing memory checkpoint

Measured and verified product source `{source}`; refreshed 2026-10-27.
The original 17-workload matched comparison remains **{ratio}× Scriptc process
RSS**. Scriptc parity is still open. See the [complete comparison](precompiled-comparison.md)
and [measured CI run]({record['measurement']['url']}).

Default mixed Array data slots now use nullable immutable StoredValue references.
A null slot means a hole; stored Undefined remains present. Number-only storage
keeps its existing unboxed path. Promotion, growth, deletion, empty reset and
descriptor retirement preserve exact value tags, Number bits, occupancy, length,
GC roots, aliases and Array exotic behavior.

Compact plain objects allocate reference backing on their first nonnull payload.
Null backing represents null payloads, with tags retaining present Undefined,
Null, Number and Boolean distinctions. First allocation uses the complete shape
extent; later null overwrites clear strong reference edges. Native rooted snapshots
read both representations and validate active/inactive backing and occupancy.

A shared IntrinsicMethodPublish Wasm helper factors repeated property publication
from Realm bootstrap. Each alias still owns a fresh mutable descriptor, while
aliases share the same defining-Realm immutable function recipe. Flags, ordering,
reflection, mutation and deletion retain their existing semantics. These changes
use one Wasm GC object model and runtime layout25, with no fallback representation.
See the [storage contract](contracts/compact-value-backing.md).

The release workspace/all-target check and source, identity, runtime-profile,
immutable-pool, retired-JS and formatting guards passed. All **{native} native cases
across 19 complete disjoint target inventories** passed; every prior target's
test IDs remain present. Focused checks overlap these counts. All **2,365 exact
original pinned Test262 executions** passed in disjoint fresh processes of at
most16 IDs. This is selected verification, not a full pinned-suite refresh.

Ten new engine controls cover mixed tags and Number bits, holes versus present
Undefined, growth and cycles, receiver/prototype-setter behavior, descriptor and
sparse transitions, freeze, failed-shrink rollback, first reference writes,
reentrant keys, native graphs, empty reset/re-promotion, alias descriptor
independence and created-Realm identity. Nine source controls run in strict and
sloppy modes; the separate native graph control observes four storage states.
The batch was reviewed for allocation and GC-root ownership.

Verification retained one CPU,4GiB,no swap,grouped OOM and a one-entry/64-MiB
module cache. Exact raw resource counters are archived. Clean CI compiler inputs
fingerprint `6d7812c410263e87f5182ac0632a162b82e1d8e89e58f40428737b602ec20ed4`;
local inputs additionally include the retained ignored standalone regress lock,
fingerprint `b55f1ef7c4bee5f280503cec35f2c7eb87bca1733a43ddea7a457fd4780fcd45`.
Both input closures and that lock are retained explicitly.

Both runtimes passed all17 unchanged workloads and checksums, with identical
Wasmtime settings in one compiler-disabled host. Each runtime/workload has two
rounds,ten checked warmups per round and14 measured samples. The checked report
owns exact RSS/timing values and both regenerated figures. RSS is observed after
execution with each Store alive; it includes code, runtime and allocator history,
and is neither live JS heap nor peak memory. Different runner cohorts do not
establish causal savings. The ordinary V8 comparison stays separately dated.

The [preceding lifecycle diagnostic](memory-runtime-imports-20261027.md) found
resident runtime and host code after Store allocations were released. Follow-up
read-only reviews identify remaining publication sharing and accessor deferral
as candidates requiring measurement. Array header fusion saves only16–32
structural bytes per Array and requires a new nonallocating common base to keep
ordinary/exotic semantic dispatch correct; it is deferred. No such candidate is
implemented or counted as a measured saving in this checkpoint.

[Verification record]({stem}.json) · [Lossless raw archive]({stem}-verification.tar.xz).
The record enumerates hashes and bounded expansion sizes. Native executables and
serialized images are excluded. Regeneration commands for the graphs live in the
paired comparison report.
'''
assert summary['ratio_max']>1, 'Revise parity wording if the full matched target is achieved'
readme.write_text(readme_text)
contract.write_text(contract_text)
(ROOT/'docs/rust-rewrite'/f'{stem}.md').write_text(doc)
