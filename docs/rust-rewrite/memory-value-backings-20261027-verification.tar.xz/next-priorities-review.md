# Read-only Sol follow-up reviews at f3df68beb

The current batch still awaits native, Test262 and matched-workload verification.
No following candidate is implemented or counted as measured savings.

## Initialization and publication

The completed owned0bd integer lifecycle diagnostic separates exact API endpoints.
R RX residency is60KiB after admission,92KiB after instantiation and2460KiB after
initialize/evaluate. These mappings do not identify executed functions or removable
pages. Source independently routes body_compilation to bootstrap.init_runtime_roots
and RealmInitializeIntrinsics, which eagerly installs the full intrinsic graph.

The future/current IntrinsicMethodPublish helper already factors deferred method
descriptor publication. Do not count that again. Remaining eager data/accessor
publication in intrinsics/mod.rs and constructor bootstrap could share the final
publication algorithm while preserving fresh descriptors, flags, order and roots.

Noncanonical getter/setter functions are still eagerly materialized by
emit_install_intrinsic_accessor. Existing deferred recipes cover data VALUE only.
Accessor deferral would require a coordinated schema and GET/SET resolution change,
including invocation, descriptor reflection, snapshots, defining-Realm identity,
absence versus undefined, aliases, mutation and original-throw behavior. Canonical
slots and bootstrap-required functions need separate ownership analysis.

## Object header fusion

OrdinaryObject already bears plain-object identity. Concrete wrappers such as Array
own a separate OrdinaryObject through OBJECT. Under the pinned copying collector's
16-byte header/alignment and4-byte references, the reviewer computes48bytes for the
ordinary header and48bytes for Array payload:96bytes and two allocations. A fused
Array is80bytes with current tail order or64bytes with LENGTH before ELEMENTS.
Other backings remain. This is structural accounting, not RSS or benchmark evidence.

Arrays must not become subtypes of the existing OrdinaryObject: its concrete test
in objects/proxy_target_descriptor.rs selects ordinary semantics. A coherent design
would introduce a nonallocating ObjectHeader base, with final OrdinaryObject and
Array as separate children. Other wrappers could project owned ordinary headers
to that common base. Generic header operations consume ObjectHeader; semantic
dispatch continues to test final concrete types and JS identity remains the actual
concrete reference.

This needs inherited-field schema support, transitive subtype witnesses, new
allocation owners, helper signatures, snapshot projection and R/P/native ABI
regeneration. Mutable inherited fields retain exact types/offsets. Tests would
cover exotic dispatch, identity, prototype cycles, private brands, hash keys,
cross-Realm behavior and snapshots. Plain retained row objects gain nothing.
The reviewer recommends deferring this16–32byte-per-Array saving behind current
measurement priorities. No builds, probes or product edits ran for this review.
