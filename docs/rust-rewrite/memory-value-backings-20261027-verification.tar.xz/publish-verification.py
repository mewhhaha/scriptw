"""Publish completed exact-source verification, excluding executable/native payloads."""
from datetime import datetime,timezone
import hashlib,json,lzma,re,sys,tarfile
from pathlib import Path,PurePosixPath
BASE=Path(__file__).resolve().parent;ROOT=BASE.parents[1];DEST=ROOT/'docs/rust-rewrite'
sys.path.insert(0,str(ROOT/'scripts'))
import precompiled_comparison as p
from native_test_protocol import result_summaries
STEM='memory-value-backings-20261027'
SOURCE='f3df68beb76f18506f070fe54b95e80fe2db22be'
def read(path):return json.loads(path.read_text())
def sha(path):
 with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def streams(directory,commands):
 for row in commands:
  assert row.get('exit_code',row.get('returncode'))==0
  for key in ('stdout','stderr'):assert sha(directory/row[key])==row[key+'_sha256']
def resource(report):
 for moment in ('before','after'):
  value=report[moment];assert value['memory.max']=='4294967296' and value['memory.swap.max']=='0' and value['memory.oom.group']=='1'
 before=dict(line.split() for line in report['before']['memory.events'].splitlines());after=dict(line.split() for line in report['after']['memory.events'].splitlines())
 assert all(before[key]==after[key] for key in ('oom','oom_kill','oom_group_kill'))
native=read(BASE/'native/report.json');batch=read(BASE/'verification.json');conf=read(BASE/'conformance/report.json');check=read(BASE/'check.json');cheap=read(BASE/'cheap-main-fixtures/cheap-main.json')
assert all(row['complete'] and row['source_commit']==SOURCE for row in (native,batch,conf,check))
assert check['exit_code']==0 and cheap['complete'] and cheap['base_commit']==SOURCE
assert sha(BASE/'cargo-check.jsonl')==check['stdout_sha256'] and sha(BASE/'cargo-check.stderr')==check['stderr_sha256']
streams(BASE/'native',native['commands']);streams(BASE,batch['commands']);streams(BASE/'conformance',conf['commands']);streams(BASE/'cheap-main-fixtures',cheap['commands'])
for report in (native,batch,conf,check):resource(report)
selection=BASE/'conformance/executions';assert sha(selection)==conf['execution_list_sha256']
selected=selection.read_text().splitlines();actual=[]
assert conf['batch_limit']==16
for part in conf['batches']:
 directory=BASE/'conformance';listing=directory/part['list_file'];snapshot=directory/part['snapshot_file']
 assert sha(listing)==part['list_sha256'] and sha(snapshot)==part['snapshot_sha256']
 ids=listing.read_text().splitlines();snap=read(snapshot)
 assert 0<len(ids)<=16 and len(ids)==len(set(ids))==part['passed']==snap['total']==snap['passed']
 assert snap['compiler_identity']==conf['compiler']['identity'] and set(snap['completed_test_ids'])==set(ids)
 assert not snap['failures'] and not snap['timeout_test_ids'] and snap['counts_per_outcome']==dict(Bug=0,Crash=0,NotImplemented=0,Success=len(ids))
 actual+=ids
assert len(actual)==len(set(actual))==len(selected)==len(set(selected))==2365 and set(actual)==set(selected)
assert len(native['scopes'])==19 and len({(s['package'],s['target']) for s in native['scopes']})==19
assert {s['target'] for s in native['scopes'] if s['package']=='scriptw-aot-wasm'}=={'scriptw_aot_wasm','runtime_link','structure_builtins','structure_language','emission','modules_realms','intl_temporal','structure_async'}
prior=read(BASE/'prior-native-inventories.json');assert prior['source_commit']=='0bd2c2ea7a4a98146d3dac5734afa0f3812de5c3'
prior_scopes={(s['package'],s['target']):set(s['inventory']) for s in prior['scopes']}
assert set(prior_scopes)=={(s['package'],s['target']) for s in native['scopes']}
scopes=[]
for scope in native['scopes']:
 inventory=scope['inventory'];assert prior_scopes[scope['package'],scope['target']]<=set(inventory)
 assert scope['complete'] and len(inventory)==len(set(inventory))==scope['passed']
 prefix=scope['package']+'-'+scope['target']+'-part-'
 actual=[]
 for command in native['commands']:
  if not command['label'].startswith(prefix):continue
  raw=(BASE/'native'/command['stdout']).read_text();names=[n.removesuffix(' - should panic') for n in re.findall(r'^test ([^\r\n]+) \.\.\. ok$',raw,re.M)]
  assert result_summaries(raw)==[('ok',str(len(names)),'0','0','0',str(len(inventory)-len(names)))]
  if scope['target']=='scriptw_engine':assert 0<len(names)<=8
  actual+=names
 assert len(actual)==len(inventory) and set(actual)==set(inventory)
 scopes.append(dict(package=scope['package'],target=scope['target'],passed=scope['passed'],executable_sha256=scope['executable_sha256'],focused_overlap=scope.get('focused_overlap',[])))
assert sum(s['passed'] for s in scopes)==native['passed_disjoint_scopes']
assert conf['total']==conf['passed']>0
assert conf['compiler']['identity']['source_revision']==dict(kind='git-commit',commit=SOURCE)
bindings=read(BASE/'source-bindings-computed.json');assert len(bindings)==2 and all(b['revision']==SOURCE for b in bindings)
clean,local=bindings;assert not clean['extra_ignored_regress_lock'] and local['extra_ignored_regress_lock']
assert conf['compiler']['identity']['source_fingerprint']==local['source_fingerprint']
run=sys.argv[1];scored=BASE/('github-'+run)/'precompiled-measurements/precompiled-evidence'
measured,rows=p.load_report(scored/'report.json');assert measured['source_commit']==SOURCE and measured['source_fingerprint']==clean['source_fingerprint']
assert len(rows)==17 and all(row['runtimes'][rt]['status']=='ok' for row in rows for rt in p.RUNTIMES)
lock=ROOT/'vendor/regress-0.10.5/Cargo.lock';provenance=BASE/'provenance';provenance.mkdir(exist_ok=True);(provenance/'ignored-regress-Cargo.lock').write_bytes(lock.read_bytes())
files=[]
for path in sorted(BASE.rglob('*')):
 if not path.is_file():continue
 rel=path.relative_to(BASE).as_posix();parts=PurePosixPath(rel).parts
 if parts[0].startswith('github-') or 'images' in parts or path.name.startswith(('publication.','preview-')):continue
 if path.suffix not in ('.py','.json','.jsonl','.stdout','.stderr','.smaps','.txt','.lock','.md','.rs','.patch','.executions','.attempts') and path.name not in ('executions','stdout','stderr'):continue
 assert not path.is_symlink() and path.stat().st_size<=128*1024**2 and '..' not in parts and not PurePosixPath(rel).is_absolute()
 with path.open('rb') as f:assert not f.read(8).startswith((b'\x7fELF',b'MZ',b'SCRWEP01',b'SCRWEP02',b'SCRWWA01'))
 files.append(dict(path=rel,bytes=path.stat().st_size,sha256=sha(path)))
expanded=sum(row['bytes'] for row in files);assert expanded<=2*1024**3
archive=DEST/(STEM+'-verification.tar.xz');assert not archive.exists()
with archive.open('xb') as output,lzma.LZMAFile(output,'w',format=lzma.FORMAT_XZ,filters=[dict(id=lzma.FILTER_LZMA2,preset=1,dict_size=64*1024**2)]) as compressed:
 with tarfile.open(fileobj=compressed,mode='w|',format=tarfile.PAX_FORMAT) as tar:
  for row in files:
   member=tarfile.TarInfo(row['path']);member.size=row['bytes'];member.mode=0o644
   with (BASE/row['path']).open('rb') as stream:tar.addfile(member,stream)
assert archive.stat().st_size<=32*1024**2
inventory={row['path']:row for row in files};seen=set();roundtrip=0
with tarfile.open(archive,'r|xz') as tar:
 for member in tar:
  assert member.isfile() and member.name in inventory and member.name not in seen
  row=inventory[member.name];assert member.size==row['bytes']<=128*1024**2
  assert hashlib.file_digest(tar.extractfile(member),'sha256').hexdigest()==row['sha256']
  seen.add(member.name);roundtrip+=member.size;assert roundtrip<=2*1024**3
assert seen==set(inventory) and roundtrip==expanded
record=dict(schema='scriptw-value-backing-memory-verification-v1',recorded_at=datetime.now(timezone.utc).isoformat(),verified_source_commit=SOURCE,measured_source_commit=measured['source_commit'],source_bindings=bindings,native=dict(passed=native['passed_disjoint_scopes'],scopes=scopes,raw_report='native/report.json'),test262=dict(passed=conf['passed'],total=conf['total'],compiler=conf['compiler'],raw_report='conformance/report.json',batch_limit=16),measurement=dict(run=run,url=measured['github_run_url'],raw_report_sha256=sha(scored/'report.json')),interpretation='All19affected native inventories and exact original2365 selected Test262 executions in disjoint fresh batches of at most16. Focused checks overlap full inventories. No full pinned-suite refresh. Local inputs additionally fingerprint retained ignored standalone dependency lock; CI uses clean Git inputs. No native executables/images are archived.',archive=dict(file=archive.name,sha256=sha(archive),bytes=archive.stat().st_size,expanded_bytes=expanded,member_count=len(files),max_expanded_bytes=2*1024**3,max_member_bytes=128*1024**2),retained_files=files)
target=DEST/(STEM+'.json');assert not target.exists();target.write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(dict(native=native['passed_disjoint_scopes'],test262=conf['total'],archive=record['archive']),indent=2))
