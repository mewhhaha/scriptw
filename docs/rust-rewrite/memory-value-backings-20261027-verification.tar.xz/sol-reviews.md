# Isolated value-backing batch reviews

Allocation implementation: lazy compact references start null; first nonnull write allocates shape-sized backing; null overwrites clear strong edges; existing transition reads share the updated owner. Mutable/nullable type witness controls added.

GC implementation: PackedValues nullable StoredValue slots, Number promotion/growth/probes/deletion/key enumeration and one-way descriptor retirement; shared immutable value wrappers, distinct hole/presentUndefined. Inactive VALUES null, empty deletion returns PackedNumbers. No new helper ABI.

Cross review by GC reviewer: no blocker in lazy compact reference or parent snapshot adapter. Storage/input/backing rooted, no JS callback during publication; snapshots validate extents/occupancy/tags.

Cross review by allocation reviewer: found stray snapshot_fields macro row (parent removed); no further semantic/rooting blocker in PackedValues. Old/new arrays rooted across promotion/growth, correct count and deletion; exact receiver/present-own shortcut preserved.

Coverage additions: six broad strict+sloppy AOT controls, one native rooted graph control, plus holes-before-promotion and delete-all/Number-reset/re-promotion controls. Descriptor reads deferred; Reflect.ownKeys used for pre-transition census because Object.keys/positive HasProperty can materialize descriptors.

All reviews were read-only; agents ran scoped formatting/diff checks only. No Cargo compilation, semantic tests or memory measurements have run for this batch.

Deferred-method code review identified repeated emitted recipe/descriptor/header publication sequences. New future IntrinsicMethodPublish helper factors descriptor construction and existing append only; recipe creation remains caller-owned. Allocation cross-review found no blocker: two bool operands normalized, typed nonnull header/key/PropertyValue rooted, fresh descriptor per alias, canonical absent accessors allocation-free. Emitted-body control and one strict/sloppy real alias/descriptor/GC/cross-Realm test added (10 new engine controls total). No workload/compilation verification or measured saving from this change yet.
