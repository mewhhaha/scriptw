scriptc-wasi-ok
