console.log("scriptc-wasi-ok");
