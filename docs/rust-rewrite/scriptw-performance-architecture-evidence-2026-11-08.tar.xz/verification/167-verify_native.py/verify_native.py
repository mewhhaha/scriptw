"""Run source-bound frozen focused or complete native targets, serially."""
import argparse,json,re,subprocess,sys,time
from pathlib import Path
ROOT=Path.cwd();BASE=ROOT/'target/performance-architecture-20261108';sys.path[:0]=[str(BASE/'tools'),str(ROOT/'scripts')]
from common import check_source,digest,read,save,validate_snapshot
from limited_verification import require_kernel_budget,limited_environment
from measure_rsc import resources,check_resources
from native_test_protocol import parse_inventory,result_summaries
p=argparse.ArgumentParser();p.add_argument('--phase',choices=['focused','broad'],required=True);p.add_argument('--source-manifest',type=Path,required=True);p.add_argument('--qualification-receipt',type=Path,required=True);p.add_argument('--output-dir',type=Path);p.add_argument('--start-index',type=int,default=0);p.add_argument('--end-index',type=int);a=p.parse_args()
require_kernel_budget(4*1024**3);source=a.source_manifest.resolve(strict=True);current=check_source(source)
qualification_path=a.qualification_receipt.resolve(strict=True);qualification=read(qualification_path)
assert qualification['schema']=='scriptw-external-test-correction-qualified-reuse-v1'
assert qualification['current_source']['sha256']==digest(source)
previous_path=Path(qualification['previous_source']['manifest']).resolve(strict=True)
previous=validate_snapshot(previous_path);assert digest(previous_path)==qualification['previous_source']['sha256']
assert current['base_git']==previous['base_git'] and current['baseline_identity']==previous['baseline_identity']
allowed=set(qualification['allowed_external_tests']);changed=set(qualification['changed_source_files']);assert changed==allowed=={'crates/scriptw-aot-wasm/tests/emission/infallible_booleans.rs','crates/scriptw-aot-wasm/tests/emission/parameter_initialization.rs'}
assert qualification['corrected_target_build']['target']=='emission'
for name in previous['files']:
 if name not in allowed:assert previous['files'][name]==current['files'][name]
if a.phase=='focused':
 scopes=[('emission','infallible_booleans::'),('emission','parameter_initialization::'),('structure_language','may_throw_abrupt_route_ownership_structure::'),('structure_builtins','pending_to_primitive_operation_identity_structure::'),('aot_language','aot_simple_parameters::'),('aot_language','aot_completion_guard_continuations::')]
else:
 scopes=[(name,'') for name in ['emission','structure_builtins','structure_language','structure_async','runtime_link','modules_realms','intl_temporal','structure','aot_builtins','aot_language','aot_async','aot_realm_modules','aot_gc_entries']]
end=len(scopes) if a.end_index is None else a.end_index
assert 0<=a.start_index<end<=len(scopes)
out=(a.output_dir.resolve() if a.output_dir else BASE/a.phase);assert out.is_relative_to(BASE);out.mkdir(exist_ok=False);report={'complete':False,'start_index':a.start_index,'end_index':end,'source_manifest_sha256':digest(source),'qualification_receipt':str(qualification_path),'qualification_receipt_sha256':digest(qualification_path),'resources_before':resources(),'runs':[]}
def checkpoint():save(out/'receipt.json',report)
try:
 for index,(target,scope) in enumerate(scopes[a.start_index:end],start=a.start_index):
  check_source(source)
  if target=='emission':
   proof=qualification['corrected_target_build'];binary=Path(proof['host']).resolve(strict=True);producer_path=Path(proof['producer']).resolve(strict=True)
   assert proof['source_manifest_sha256']==digest(source) and digest(producer_path)==proof['producer_sha256']
   producer=read(producer_path);assert producer['sha256']==digest(binary)==proof['sha256'] and producer['source_manifest_sha256']==digest(source)
   assert producer['artifact']['target']['name']=='emission' and producer['artifact']['target']['kind']==['test']
   assert producer['artifact']['features']==[] and producer['artifact']['fresh'] is False
   corrected_cargo=Path(proof['cargo_log']).resolve(strict=True)
   assert digest(corrected_cargo)==proof['cargo_log_sha256']
   assert producer['cargo_stdout']==str(corrected_cargo) and producer['cargo_stdout_sha256']==proof['cargo_log_sha256']
   target_source='corrected-current-source'
  else:
   binary=BASE/'frozen'/target;producer_path=binary.parent/(target+'-producer.json');producer=read(producer_path)
   assert producer['sha256']==digest(binary) and producer['source_manifest_sha256']==digest(previous_path)
   assert producer['artifact']['target']['name']==target and producer['artifact']['target']['test'] is True
   assert digest(binary)==producer['sha256']
   proof={'sha256':producer['sha256'],'producer':str(producer_path),'producer_sha256':digest(producer_path)}
   target_source='qualified-unchanged-product-test-target'
  label=f'{index:02}-{target}-{scope.replace(":", "")}';argv=[str(binary)]
  if scope:argv.append(scope)
  argv+=['--test-threads=1'];listed=subprocess.run([*argv,'--list'],cwd=ROOT,env=limited_environment(),stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=60);assert listed.returncode==0
  (out/(label+'.list')).write_bytes(listed.stdout);inventory=parse_inventory(listed.stdout.decode());assert inventory
  row={'target':target,'filter':scope,'argv':argv,'inventory':len(inventory),'inventory_sha256':digest(out/(label+'.list')),'binary_sha256':proof['sha256'],'producer_path':str(producer_path),'producer_sha256':proof.get('producer_sha256',digest(producer_path)),'test_target_source':target_source,'resources_before':resources()};report['runs'].append(row);checkpoint();print('START',label,len(inventory),flush=True);t=time.monotonic_ns()
  with (out/(label+'.stdout')).open('xb') as so,(out/(label+'.stderr')).open('xb') as se:
   run=subprocess.run(argv,cwd=ROOT,env=limited_environment(),stdin=subprocess.DEVNULL,stdout=so,stderr=se,timeout=2400)
  row.update(exit_code=run.returncode,elapsed_ns=time.monotonic_ns()-t,resources_after=resources());row['stdout_sha256']=digest(out/(label+'.stdout'));row['stderr_sha256']=digest(out/(label+'.stderr'));row['summary']=result_summaries((out/(label+'.stdout')).read_text());checkpoint()
  summary_valid=len(row['summary'])==1
  if summary_valid:status,passed,failed,ignored,measured,filtered=row['summary'][0]
  executed=[name.removesuffix(' - should panic') for name in re.findall(r'^test (.+) \.\.\. (?:ok|FAILED|ignored)$',(out/(label+'.stdout')).read_text(),re.M)]
  execution_complete=len(executed)==len(inventory) and set(executed)==set(inventory)
  passed_validation=(summary_valid and execution_complete and run.returncode==0 and status=='ok' and int(passed)==len(inventory) and failed==ignored==measured=='0')
  if not scope and summary_valid:passed_validation=passed_validation and filtered=='0'
  assert digest(binary)==proof['sha256'];check_source(source);check_resources(row['resources_before'],row['resources_after']);print('END' if passed_validation else 'FAILED',label,flush=True)
  row['verified']=passed_validation
  if not passed_validation:row['verification_error']='native test process, test inventory, or summary did not match the complete, failure-free inventory'
  checkpoint()
 report['complete']=True;report['all_passed']=all(row['verified'] for row in report['runs'])
 report['status']='complete' if report['all_passed'] else 'completed_with_failures';checkpoint()
except BaseException as e:
 report['error']=repr(e);raise
finally:
 report['resources_after']=resources();check_resources(report['resources_before'],report['resources_after']);check_source(source);checkpoint()
print('VERIFIED' if report['all_passed'] else 'COMPLETED_WITH_FAILURES',a.phase,sum(int(r['summary'][0][1]) for r in report['runs'] if len(r['summary'])==1),flush=True)
if not report['all_passed']:raise SystemExit(1)
