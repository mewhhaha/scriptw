"""Aggregate completed qualified scopes without hiding the original failed test."""
from pathlib import Path
import sys
R=Path.cwd();B=R/'target/performance-architecture-20261108';sys.path.insert(0,str(B/'tools'))
from common import read,save,digest,check_source
from measure_rsc import cargo_source_identity
source=B/'tools/source-complete/manifest.json';check_source(source)
original_path=B/'broad/receipt.json';corrected_path=B/'emission-corrected/receipt.json';before=read(original_path);after=read(corrected_path)
assert before['complete'] and len(before['runs'])==13 and before['source_manifest_sha256']==digest(B/'tools/source-finished/manifest.json')
assert after['complete'] and after['all_passed'] and len(after['runs'])==1 and after['source_manifest_sha256']==digest(source)
old_emission=before['runs'][0];assert old_emission['target']=='emission' and old_emission['summary'][0][:3]==['FAILED','78','1']
runs=after['runs']+[r for r in before['runs'] if r['target']!='emission'];assert len(runs)==13 and all(r['verified'] for r in runs)
passed=0
for row in runs:
 assert len(row['summary'])==1;status,count,failed,ignored,measured,filtered=row['summary'][0]
 assert status=='ok' and int(count)==row['inventory'] and failed==ignored==measured==filtered=='0';passed+=int(count)
assert passed==2832
proof=read(B/'tools/postmeasurement-test-reuse.json');assert len(proof['reused_broad_targets'])==12 and all(r['verified'] for r in proof['reused_broad_targets'])
checks=read(B/'source-checks-complete/receipt.json');assert checks['complete'] and checks['source_manifest_sha256']==digest(source)
guards=B/'source-guards-complete';guard_receipt=read(guards/'receipt.json');assert guard_receipt['finished'] and guard_receipt['passed'];guard_count=0
for target in guard_receipt['targets']:
 item=read(guards/target['receipt']);assert item['finished'] and item['passed'] and item['exit_code']==0
 assert len(item['result_summaries'])==1;status,count,failed,ignored,measured,filtered=item['result_summaries'][0];assert status=='ok' and failed==ignored==measured==filtered=='0' and int(count)==len(item['test_inventory']);guard_count+=int(count)
assert guard_count==380
cli=read(B/'production-cli/receipt.json');assert cli['complete'] and cli['passed'] and cli['passed_smokes']==9 and cli['source_manifest_sha256']==digest(source)
features=read(B/'example-feature-comparison.json');assert features['complete'] and all(row['ordinary_multiset_matches'] for row in features['roles'])
batch=read(B/'post-verification-batch.json');assert batch['complete']
fp,rev=cargo_source_identity(B/'build.stdout');assert fp=='453a9074fcacb06fb5fc010a47eb443e4c1aa804e32afbd23e6e4e43d985610c'
paths=[original_path,corrected_path,B/'tools/postmeasurement-test-reuse.json',B/'source-checks-complete/receipt.json',guards/'receipt.json',B/'production-cli/receipt.json',B/'example-feature-comparison.json',B/'post-verification-batch.json',B/'tools/rsc-campaign-1/campaign.json',B/'tools/native-policy-2x2/campaign.json',B/'focused-complete/receipt.json']
summary={'schema':'scriptw-performance-architecture-coverage-v1','date':'2026-11-08','source_fingerprint':fp,'source_revision':rev,'source_manifest_sha256':digest(source),'measured_source_manifest_sha256':digest(B/'tools/source-finished/manifest.json'),'private_unit_suites_rerun':False,'full_workspace_ci_rerun':False,'full_test262_rerun':False,'scopes':{'broad':{'passed':passed,'scopes':len(runs),'scope_names':[r['target'] for r in runs]},'source_guards':{'passed':guard_count},'production_cli':{'passed':cli['passed_smokes']}},'qualification':{'original_broad_receipt_sha256':digest(original_path),'corrected_emission_receipt_sha256':digest(corrected_path),'reused_unchanged_broad_targets':12,'initial_failed_emission_test':'retained_operands::held_method_receivers_omit_private_tdz_checks_but_keep_source_checks','reason':'Older structural assertion expected body checks for already initialized ordinary parameters; corrected expectation keeps the lexical let control. Only the emission target was rebuilt and rerun. All original failures and producer identities remain retained.'},'owned_existing_failures':{'format_files':checks['format_files'],'stale_intl_recipes':checks['stale_intl_recipes'],'aot_private_unit_assertions':4,'aot_units_rerun':False},'receipts':{str(p.relative_to(R)):digest(p) for p in paths}}
save(B/'coverage-summary.json',summary);print('ACCEPTED',passed,'broad',guard_count,'guards',cli['passed_smokes'],'CLI')
