"""Run existing cheap gates before the single native build."""
from pathlib import Path
import hashlib,json,os,re,subprocess,sys,time
ROOT=Path.cwd();BASE=ROOT/'target/performance-architecture-20261108';sys.path[:0]=[str(BASE/'tools'),str(ROOT/'scripts')]
from common import check_source,digest
from limited_verification import require_kernel_budget,limited_environment
from measure_rsc import resources,check_resources
require_kernel_budget(4*1024**3);source=BASE/'tools/source-complete/manifest.json';check_source(source)
out=BASE/'source-checks-complete';out.mkdir(exist_ok=False)
report={'complete':False,'source_manifest_sha256':digest(source),'resources_before':resources(),'commands':[]}
def save():(out/'receipt.json').write_text(json.dumps(report,indent=2)+'\n')
try:
 for name,argv,expected in [
  ('owners',[sys.executable,'-B','scripts/conformance_owners.py'],0),
  ('format',['cargo','fmt','--all','--','--check'],1),
  ('intl',[sys.executable,'-B','scripts/intl_source_identities.py'],1),
  ('diff',['git','diff','--check'],0),
  ('guards',[sys.executable,'-B','scripts/check-source-guards.py','--output',str(BASE/'source-guards-complete')],0),
 ]:
  check_source(source);print('START',name,flush=True);t=time.monotonic_ns()
  with (out/(name+'.stdout')).open('xb') as so,(out/(name+'.stderr')).open('xb') as se:
   run=subprocess.run(argv,cwd=ROOT,env=limited_environment(),stdin=subprocess.DEVNULL,stdout=so,stderr=se,timeout=300)
  report['commands'].append({'name':name,'argv':argv,'exit_code':run.returncode,'elapsed_ns':time.monotonic_ns()-t,'stdout_sha256':digest(out/(name+'.stdout')),'stderr_sha256':digest(out/(name+'.stderr'))});save();print('END',name,run.returncode,flush=True);assert run.returncode==expected,name
 report['format_files']=sorted(set(re.findall(r'^Diff in (.+):\d+:$',(out/'format.stdout').read_text(),re.M)));assert len(report['format_files'])==11
 for name in report['format_files']:
  path=Path(name);assert path.read_bytes()==subprocess.check_output(['git','show','HEAD:'+str(path.relative_to(ROOT))])
 report['stale_intl_recipes']=re.findall(r'^FAIL (.+)$',(out/'intl.stdout').read_text(),re.M);assert len(report['stale_intl_recipes'])==14
 report['complete']=True
finally:
 report['resources_after']=resources();check_resources(report['resources_before'],report['resources_after']);check_source(source);save()
print('CHEAP GATES COMPLETE: EXISTING FORMAT/INTL FAILURES RETAINED',flush=True)
