import subprocess,sys
from pathlib import Path
BASE=Path.cwd()/'target/performance-architecture-20261108'
argv=[sys.executable,'-B',str(BASE/'tools/measure_rsc.py'),'--source-manifest',str(BASE/'tools/source-finished/manifest.json'),'--candidate-host',str(BASE/'frozen/rsc_baseline'),'--candidate-producer',str(BASE/'build.stdout'),'--candidate-build-argv-file',str(BASE/'build-argv.json'),'--candidate-reuse-receipt',str(BASE/'tools/external-test-reuse-finished.json'),'--focused-receipt',str(BASE/'focused-complete/receipt.json'),'--baseline-speed','--output',str(BASE/'tools/rsc-campaign-1')]
subprocess.run(argv,check=True)
