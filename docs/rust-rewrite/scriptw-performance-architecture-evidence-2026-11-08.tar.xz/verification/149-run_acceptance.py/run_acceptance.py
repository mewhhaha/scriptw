"""Run excluded architecture probes and acceptance serially under one capped tree."""
import subprocess,sys,time
from pathlib import Path
ROOT=Path.cwd();B=ROOT/'target/performance-architecture-20261108';OLD=ROOT/'target/performance-predicate-transport-20261108';sys.path[:0]=[str(B/'tools'),str(ROOT/'scripts')]
from common import check_source,digest,read,save
from measure_rsc import resources,check_resources
from limited_verification import limited_environment,require_kernel_budget
require_kernel_budget(4*1024**3);source=B/'tools/source-finished/manifest.json';check_source(source)
py=[sys.executable,'-B'];campaign=B/'tools/rsc-campaign-1/campaign.json';assert read(campaign)['status']=='complete'
anchor=campaign.parent/'block-0-rep-0-candidate/report.json';timer=ROOT/'target/performance-worker-cpu/tools/time';node=Path('/home/jacobt/.local/share/fnm/node-versions/v24.12.0/installation/bin/node')
phases=[]
for mode in ['fast','fast-backtracking','speed','speed-single-pass']:
 argv=py+[str(B/'capture_candidate.py'),'--mode',mode,'--anchor',str(anchor),'--campaign',str(campaign),'--source-manifest',str(source),'--candidate-host',str(B/'frozen/rsc_baseline'),'--output',str(B/('capture-final-'+mode+('-retry' if mode=='fast' else '')))]
 if mode!='fast':argv+=['--prior-program-wasm',str(B/'capture-final-fast-retry/program.wasm')]
 label='capture-final-'+mode
 if mode=='fast':label+='-retry'
 phases.append((label,argv))
for mode in ['control','sync','async']:
 argv=py+[str(B/'cache-census-tools/count_source_entries.py'),'--mode',mode,'--output',str(B/('cache-census/'+mode+'-5')),'--binary',str(OLD/'frozen/rsc_baseline'),'--baseline-json',str(OLD/'tools/rsc-campaign-1/block-0-rep-0-candidate/report.json')]
 if mode!='control':
  argv+=['--controls-receipt',str(B/'cache-census/control-5/receipt.json'),'--samples','7']
  for target in ['helperentry:cached','callsite:cached-fallback','callsite:object-self-0','callsite:object-self-1']:argv+=['--target',target]
 phases.append(('cache-census-'+mode+'-5',argv))
s=(B/'prepare_verification.py').read_text().replace("tools/source-current/manifest.json","tools/source-finished/manifest.json").replace("BASE/'source-checks'","BASE/'source-checks-finished'").replace("BASE/'source-guards'","BASE/'source-guards-finished'")
(B/'prepare_finished_verification.py').write_text(s)
phases.extend([
 ('source-finished-checks',py+[str(B/'prepare_finished_verification.py')]),
 ('broad',py+[str(B/'verify_native.py'),'--phase','broad','--source-manifest',str(source),'--qualification-receipt',str(B/'tools/external-test-reuse-finished.json')]),
 ('situations',py+['scripts/benchmark-situations.py','--host',str(B/'frozen/compiler_precompiled_baseline'),'--producer-log',str(B/'build.stdout'),'--producer-receipt',str(B/'frozen/compiler_precompiled_baseline-producer.json'),'--fixtures','target/performance-levers-20261108/situations-full-1/sources','--output',str(B/'situations-full'),'--node',str(node),'--time',str(timer)]),
 ('cli',py+[str(B/'verify_cli.py')]),
 ('features',py+[str(B/'audit_example_features.py')])])
report={'complete':False,'source_manifest_sha256':digest(source),'phases':[],'resources_before':resources()};save(B/'acceptance-batch.json',report)
try:
 for name,argv in phases:
  check_source(source);print('START',name,flush=True);row={'name':name,'argv':argv,'resources_before':resources()};report['phases'].append(row);save(B/'acceptance-batch.json',report);started=time.monotonic_ns()
  with (B/(name+'.stdout')).open('xb') as so,(B/(name+'.stderr')).open('xb') as se:run=subprocess.run(argv,cwd=ROOT,env=limited_environment(),stdin=subprocess.DEVNULL,stdout=so,stderr=se,timeout=5400)
  row.update(exit_code=run.returncode,elapsed_ns=time.monotonic_ns()-started,resources_after=resources());row.update({s+'_sha256':digest(B/(name+'.'+s)) for s in ['stdout','stderr']});save(B/'acceptance-batch.json',report);check_resources(row['resources_before'],row['resources_after']);check_source(source);assert run.returncode==0,name;print('END',name,flush=True)
 report['complete']=True
finally:
 report['resources_after']=resources();check_resources(report['resources_before'],report['resources_after']);check_source(source);save(B/'acceptance-batch.json',report)
