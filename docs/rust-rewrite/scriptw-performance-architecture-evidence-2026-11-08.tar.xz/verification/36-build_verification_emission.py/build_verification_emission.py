import json,subprocess,sys,time
from pathlib import Path
R=Path.cwd();B=R/'target/performance-architecture-20261108';sys.path[:0]=[str(B/'tools'),str(R/'scripts')]
from common import check_source,digest,read,save,validate_snapshot
from measure_rsc import resources,check_resources
from limited_verification import limited_environment,require_kernel_budget
require_kernel_budget(4*1024**3);source=B/'tools/source-complete/manifest.json';current=check_source(source);old=validate_snapshot(B/'tools/source-finished/manifest.json');extra='crates/scriptw-aot-wasm/tests/emission/retained_operands.rs';assert set(current['files'])==set(old['files'])|{extra}
for name in old['files']:assert current['files'][name]==old['files'][name]
argv=['cargo','--config','build.jobs=1','build','--release','--locked','-p','scriptw-aot-wasm','--test','emission','--message-format=json-render-diagnostics','--timings'];receipt={'complete':False,'argv':argv,'source_manifest_sha256':digest(source),'resources_before':resources()};started=time.monotonic_ns()
log=B/'emission-verification-build.stdout';err=B/'emission-verification-build.stderr'
try:
 with log.open('xb') as so,err.open('xb') as se:run=subprocess.run(argv,cwd=R,env=limited_environment(),stdin=subprocess.DEVNULL,stdout=so,stderr=se,timeout=900)
 receipt['exit_code']=run.returncode;assert run.returncode==0;check_source(source)
 rows=[json.loads(r) for r in log.read_text().splitlines() if r];assert [r for r in rows if r.get('reason')=='build-finished']==[{'reason':'build-finished','success':True}]
 artifacts=[r for r in rows if r.get('reason')=='compiler-artifact' and r.get('executable') and r['target']['name']=='emission'];assert len(artifacts)==1;artifact=artifacts[0];assert artifact['fresh'] is False
 original=Path(artifact['executable']);folder=B/'frozen-verification';folder.mkdir(exist_ok=False);binary=folder/'emission';subprocess.run(['cp','--reflink=auto',str(original),str(binary)],check=True);assert digest(binary)==digest(original)
 proof={'artifact':artifact,'sha256':digest(binary),'frozen_path':str(binary),'source_manifest_sha256':digest(source),'cargo_stdout':str(log),'cargo_stdout_sha256':digest(log),'cargo_stderr_sha256':digest(err),'build_argv':argv};save(folder/'emission-producer.json',proof);receipt['complete']=True;receipt['binary_sha256']=proof['sha256']
finally:
 receipt['elapsed_ns']=time.monotonic_ns()-started;receipt['resources_after']=resources();check_resources(receipt['resources_before'],receipt['resources_after']);check_source(source);save(B/'emission-verification-build-receipt.json',receipt)
