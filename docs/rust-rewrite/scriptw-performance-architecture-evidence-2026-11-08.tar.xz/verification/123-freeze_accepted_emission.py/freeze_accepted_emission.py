import json,subprocess,sys
from pathlib import Path
BASE=Path.cwd()/'target/performance-architecture-20261108';sys.path.insert(0,str(BASE/'tools'))
from common import check_source,digest,save
source=BASE/'tools/source-correct/manifest.json';check_source(source)
log=BASE/'emission-accepted-build.stdout';rows=[json.loads(r) for r in log.read_text().splitlines() if r]
assert [r for r in rows if r.get('reason')=='build-finished']==[{'reason':'build-finished','success':True}]
selected=[r for r in rows if r.get('reason')=='compiler-artifact' and r.get('executable') and r['target']['name']=='emission'];assert len(selected)==1
artifact=selected[0];assert artifact['fresh'] is False
original=Path(artifact['executable']);folder=BASE/'frozen-accepted';folder.mkdir(exist_ok=False);binary=folder/'emission';subprocess.run(['cp','--reflink=auto',str(original),str(binary)],check=True);assert digest(binary)==digest(original)
proof={'artifact':artifact,'sha256':digest(binary),'frozen_path':str(binary),'source_manifest_sha256':digest(source),'cargo_stdout':str(log),'cargo_stdout_sha256':digest(log),'cargo_stderr_sha256':digest(BASE/'emission-accepted-build.stderr'),'build_argv':['cargo','--config','build.jobs=1','build','--release','--locked','-p','scriptw-aot-wasm','--test','emission','--message-format=json-render-diagnostics','--timings'],'wrapper':['python3','-B','scripts/limited_verification.py','--']}
save(folder/'emission-producer.json',proof);print('FROZEN CORRECTED EMISSION',proof['sha256'])
