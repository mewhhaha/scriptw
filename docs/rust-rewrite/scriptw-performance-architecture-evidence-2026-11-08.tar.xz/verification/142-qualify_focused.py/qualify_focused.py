import json,sys
from pathlib import Path
B=Path.cwd()/'target/performance-architecture-20261108';sys.path.insert(0,str(B/'tools'))
from common import read,save,digest,check_source,validate_snapshot
source=B/'tools/source-finished/manifest.json';now=check_source(source);oldpath=B/'focused-accepted/receipt.json';old=read(oldpath);before=validate_snapshot(B/'tools/source-correct/manifest.json');assert old['complete'] and old['source_manifest_sha256']==digest(B/'tools/source-correct/manifest.json')
changed={p for p in now['files'] if now['files'][p]!=before['files'][p]};assert changed=={'crates/scriptw-aot-wasm/tests/emission/parameter_initialization.rs'}
rows=[dict(r,qualified_from_receipt=str(oldpath),qualified_from_receipt_sha256=digest(oldpath)) for r in old['runs'] if r['verified']];assert len(rows)==5 and sum(r['inventory'] for r in rows)==14
newpath=B/'parameter-complete/receipt.json';new=read(newpath);assert new['complete'] and new['all_passed'] and new['source_manifest_sha256']==digest(source) and len(new['runs'])==1 and new['runs'][0]['inventory']==1
rows+=new['runs'];assert len({(r['target'],r['filter']) for r in rows})==6
out=B/'focused-complete';out.mkdir();save(out/'receipt.json',{'complete':True,'all_passed':True,'source_manifest_sha256':digest(source),'source_fingerprint':'453a9074fcacb06fb5fc010a47eb443e4c1aa804e32afbd23e6e4e43d985610c','runs':rows,'passed':15,'qualified_reuse':'Only parameter_initialization.rs changed after 14 passed scoped checks; only that scope was rerun. Original binaries, sources, failed attempts and raw logs remain retained.','scope_receipts':[{'path':str(p),'sha256':digest(p)} for p in [oldpath,newpath]],'test_correction_receipt_sha256':digest(B/'tools/external-test-reuse-finished.json')});print('FOCUSED COMPLETE 15')
p=B/'run_rsc.py';s=p.read_text().replace('source-correct','source-finished').replace('external-test-reuse-accepted.json','external-test-reuse-finished.json').replace('focused-accepted/receipt.json','focused-complete/receipt.json');p.write_text(s)
p=B/'verify_cli.py';p.write_text(p.read_text().replace('source-correct','source-finished'))
