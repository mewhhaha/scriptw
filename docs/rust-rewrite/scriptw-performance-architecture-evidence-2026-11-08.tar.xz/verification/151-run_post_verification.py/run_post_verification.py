import subprocess,sys,time
from pathlib import Path
R=Path.cwd();B=R/'target/performance-architecture-20261108';sys.path[:0]=[str(B/'tools'),str(R/'scripts')]
from common import check_source,digest,save,read
from limited_verification import limited_environment,require_kernel_budget
from measure_rsc import resources,check_resources
require_kernel_budget(4*1024**3);source=B/'tools/source-complete/manifest.json';check_source(source)
corrected=read(B/'emission-corrected/receipt.json');assert corrected['complete'] and corrected['all_passed'] and corrected['runs'][0]['inventory']==79
py=[sys.executable,'-B'];phases=[
 ('postmeasurement-qualification',py+[str(B/'publication-tools/qualify_verification_correction.py'),'--current-emission-producer',str(B/'frozen-verification/emission-producer.json'),'--previous-broad-receipt',str(B/'broad/receipt.json'),'--corrected-emission-receipt',str(B/'emission-corrected/receipt.json'),'--output',str(B/'tools/postmeasurement-test-reuse.json')]),
 ('complete-source-checks',py+[str(B/'prepare_complete_verification.py')]),
 ('situations',py+['scripts/benchmark-situations.py','--host',str(B/'frozen/compiler_precompiled_baseline'),'--producer-log',str(B/'build.stdout'),'--producer-receipt',str(B/'frozen/compiler_precompiled_baseline-producer.json'),'--fixtures','target/performance-levers-20261108/situations-full-1/sources','--output',str(B/'situations-full'),'--node','/home/jacobt/.local/share/fnm/node-versions/v24.12.0/installation/bin/node','--time','target/performance-worker-cpu/tools/time']),
 ('cli',py+[str(B/'verify_cli.py')]),
 ('features',py+[str(B/'audit_example_features.py')])]
report={'complete':False,'source_manifest_sha256':digest(source),'phases':[],'resources_before':resources()};save(B/'post-verification-batch.json',report)
try:
 for name,argv in phases:
  check_source(source);print('START',name,flush=True);row={'name':name,'argv':argv,'resources_before':resources()};report['phases'].append(row);save(B/'post-verification-batch.json',report);started=time.monotonic_ns()
  with (B/(name+'.stdout')).open('xb') as so,(B/(name+'.stderr')).open('xb') as se:run=subprocess.run(argv,cwd=R,env=limited_environment(),stdin=subprocess.DEVNULL,stdout=so,stderr=se,timeout=3600)
  row.update(exit_code=run.returncode,elapsed_ns=time.monotonic_ns()-started,resources_after=resources());row.update({s+'_sha256':digest(B/(name+'.'+s)) for s in ['stdout','stderr']});save(B/'post-verification-batch.json',report);check_resources(row['resources_before'],row['resources_after']);check_source(source);assert run.returncode==0,name;print('END',name,flush=True)
 report['complete']=True
finally:
 report['resources_after']=resources();check_resources(report['resources_before'],report['resources_after']);check_source(source);save(B/'post-verification-batch.json',report)
