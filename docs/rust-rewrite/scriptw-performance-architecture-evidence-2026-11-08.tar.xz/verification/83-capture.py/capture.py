"""Read exact native entries and raw P from an owned, barrier-paused host."""
import argparse,ctypes,hashlib,json,os,socket,subprocess,sys,time
from pathlib import Path
ROOT=Path.cwd();BASE=ROOT/'target/performance-architecture-20261108';OLD=ROOT/'target/performance-predicate-transport-20261108'
sys.path[:0]=[str(OLD/'attribution-tools'),str(OLD/'tools'),str(ROOT/'scripts')]
from request_profile_support import line,thread_record
from profile_thread import barrier_caller
from common import digest,read,save
from limited_verification import limited_environment,require_kernel_budget
from measure_rsc import resources,check_resources
p=argparse.ArgumentParser();p.add_argument('--mode',choices=['fast','speed'],required=True);args=p.parse_args()
require_kernel_budget(4*1024**3);assert len(os.sched_getaffinity(0))==1
campaign=read(OLD/'tools/rsc-campaign-1/campaign.json');actor='candidate'
if args.mode=='speed':actor='candidate-speed'
row=next(r for r in campaign['processes'] if r['engine']==actor);anchor=OLD/'tools/rsc-campaign-1'/row['report'];assert digest(anchor)==row['report_sha256'];expected=read(anchor)
host=Path(campaign['candidate']['path']);assert digest(host)==expected['executable_sha256']
out=BASE/('capture-'+args.mode);out.mkdir(exist_ok=False);(out/'tmp').mkdir()
parent,child_socket=socket.socketpair();fd=child_socket.fileno();inode=os.fstat(fd).st_ino;nonce=os.urandom(16).hex();env=limited_environment();env.update(TMPDIR=str(out/'tmp'),SCRIPTW_RSC_PROFILE_FD=str(fd),SCRIPTW_RSC_PROFILE_NONCE=nonce,SCRIPTW_RSC_PROFILE_MODE='sync')
argv=[str(host),expected['inputs']['source'],expected['inputs']['support'],str(out/'report.json'),'1','3',args.mode]
class IOVec(ctypes.Structure):_fields_=[('base',ctypes.c_void_p),('length',ctypes.c_size_t)]
libc=ctypes.CDLL(None,use_errno=True);libc.process_vm_readv.restype=ctypes.c_ssize_t
child=None;report={'complete':False,'unscored':True,'argv':argv,'mode':args.mode,'anchor_sha256':digest(anchor),'host_sha256':digest(host),'source_fingerprint':expected['source_fingerprint'],'resources_before':resources(),'functions':[]};started=time.time_ns()
def memory(address,count):
 data=ctypes.create_string_buffer(count);local=IOVec(ctypes.cast(data,ctypes.c_void_p),count);remote=IOVec(address,count)
 n=libc.process_vm_readv(child.pid,ctypes.byref(local),1,ctypes.byref(remote),1,0)
 if n!=count:raise OSError(ctypes.get_errno(),f'owned-child read returned {n}/{count}')
 return data.raw
try:
 with (out/'host.stdout').open('xb') as so,(out/'host.stderr').open('xb') as se:
  child=subprocess.Popen(argv,cwd=ROOT,env=env,stdin=subprocess.DEVNULL,stdout=so,stderr=se,pass_fds=(fd,));child_socket.close();report['pid']=child.pid
  ready=f'SWRSC1 {nonce} ready sync 3\n';assert line(parent.fileno(),60)==ready
  report['caller']=barrier_caller(child.pid,fd,inode,thread_record)
  maps=Path(f'/proc/{child.pid}/maps').read_text();(out/'maps.txt').write_text(maps)
  perf=Path(f'/tmp/perf-{child.pid}.map');assert perf.stat().st_mtime_ns>=started;(out/'perf.map').write_bytes(perf.read_bytes())
  entries=[]
  for raw in perf.read_text().splitlines():
   address,size,name=raw.split(maxsplit=2);entries.append((int(address,16),int(size,16),name))
  for name in ['js::vn#f133','js::ft#f123']:
   selected=[r for r in entries if r[2]==name];assert len(selected)==1;address,size,_=selected[0];assert 0<size<4*1024**2
   data=memory(address,size);path=out/(name.split('::')[1].split('#')[0]+'.native');path.write_bytes(data)
   report['functions'].append({'name':name,'address':address,'bytes':size,'path':path.name,'sha256':digest(path)})
  # wasm_encoder's owned Vec is live until the host's final identity report.
  # Search bounded writable heap ranges; accept only the full recorded digest.
  wanted=expected['program_wasm_bytes'];wanted_sha=expected['program_wasm_sha256'];scanned=0;found=None;attempts=[]
  for raw in maps.splitlines():
   parts=raw.split();lo,hi=[int(s,16) for s in parts[0].split('-')];permissions=parts[1]
   if permissions!='rw-p' or hi-lo<wanted:continue
   if len(parts)>5 and parts[5]!='[heap]':continue
   if hi-lo>1024**3 or scanned+hi-lo>1024**3:continue
   previous=b''
   for address in range(lo,hi,1024**2):
    data=memory(address,min(1024**2,hi-address));scanned+=len(data);chunk=previous+data;cursor=0
    while True:
     index=chunk.find(b'\0asm\1\0\0\0',cursor)
     if index<0:break
     candidate=address-len(previous)+index;cursor=index+8
     if candidate+wanted>hi:continue
     full=memory(candidate,wanted);sha=hashlib.sha256(full).hexdigest();attempts.append({'address':candidate,'sha256':sha})
     if sha==wanted_sha:found=(candidate,full);break
    if found:break
    previous=chunk[-7:]
   if found:break
  report['wasm_scan']={'scanned_bytes':scanned,'attempts':attempts}
  if found:
   address,data=found;(out/'program.wasm').write_bytes(data);report['program_wasm']={'address':address,'bytes':len(data),'sha256':digest(out/'program.wasm')}
  parent.sendall(ready.replace('SWRSC1','SWACK1',1).encode());done=f'SWRSC1 {nonce} done sync 3\n';assert line(parent.fileno(),30)==done
  for f in report['functions']:assert hashlib.sha256(memory(f['address'],f['bytes'])).hexdigest()==f['sha256']
  if found:assert hashlib.sha256(memory(report['program_wasm']['address'],wanted)).hexdigest()==wanted_sha
  parent.sendall(done.replace('SWRSC1','SWACK1',1).encode());report['exit_code']=child.wait(timeout=30);assert report['exit_code']==0
 value=read(out/'report.json')
 for field in ['source_fingerprint','program_wasm_sha256','runtime','configuration','executable_sha256','inputs']:assert value[field]==expected[field],field
 assert value['profiling']['nonce']==nonce and value['profiling']['windows']==1 and value['cases'][0]['exact_node_output_checked']
 report['complete']=True
finally:
 if child is not None and child.poll() is None:child.kill();child.wait(timeout=5)
 parent.close();child_socket.close();report['resources_after']=resources();check_resources(report['resources_before'],report['resources_after']);report['tool_sha256']=digest(Path(__file__));save(out/'receipt.json',report)
print('CAPTURED',args.mode,'raw P',bool(found),'functions',[(r['name'],r['bytes']) for r in report['functions']],flush=True)
