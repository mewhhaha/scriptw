"""Read exact native entries and raw P from an owned, barrier-paused host."""
import argparse,ctypes,hashlib,json,os,shutil,socket,subprocess,sys,time
from pathlib import Path
ROOT=Path.cwd();BASE=ROOT/'target/performance-architecture-20261108';OLD=ROOT/'target/performance-predicate-transport-20261108'
sys.path[:0]=[str(BASE/'tools'),str(OLD/'attribution-tools'),str(ROOT/'scripts'),str(OLD/'tools')]
from request_profile_support import line,thread_record
from profile_thread import barrier_caller
from common import check_source,digest,read,save
from limited_verification import limited_environment,require_kernel_budget
from measure_rsc import CASES,resources,check_resources
p=argparse.ArgumentParser();p.add_argument('--mode',choices=['fast','fast-backtracking','speed','speed-single-pass'],required=True);p.add_argument('--anchor',type=Path,required=True);p.add_argument('--campaign',type=Path);p.add_argument('--source-manifest',type=Path,required=True);p.add_argument('--candidate-host',type=Path);p.add_argument('--output',type=Path,required=True);p.add_argument('--prior-program-wasm',type=Path);args=p.parse_args()
require_kernel_budget(4*1024**3);assert len(os.sched_getaffinity(0))==1
anchor=args.anchor.resolve(strict=True);expected=read(anchor)
campaign_path=args.campaign.resolve(strict=True) if args.campaign else anchor.parents[2]/'campaign.json'
campaign=read(campaign_path)
assert campaign['schema']=='scriptw-rsc-levers-campaign-v1' and campaign['status']=='complete'
source_manifest=args.source_manifest.resolve(strict=True);source_info=check_source(source_manifest)
assert campaign['source_manifest_sha256']==digest(source_manifest)
assert campaign['source_manifest']['path']==str(source_manifest)
row=next(r for r in campaign['processes'] if r['actor']=='candidate' and r['block']==0 and r['repetition']==0)
assert (campaign_path.parent/row['report']).resolve()==anchor and digest(anchor)==row['report_sha256']
assert expected['native_mode']=='fast'
host=Path(args.candidate_host).resolve(strict=True) if args.candidate_host else Path(campaign['candidate']['path']).resolve(strict=True)
assert host==Path(campaign['candidate']['path']).resolve(strict=True)
assert digest(host)==expected['executable_sha256']==campaign['candidate']['sha256']
assert expected['source_fingerprint']==campaign['candidate']['compiler_source_identity']['source_fingerprint']
assert expected['source_commit'].removeprefix('git:')==campaign['candidate']['compiler_source_identity']['source_revision'].removeprefix('git:')
reuse_info=campaign['candidate']['qualified_reuse'];reuse_path=None
if reuse_info is not None:
 reuse_path=Path(reuse_info['path']).resolve(strict=True);assert digest(reuse_path)==reuse_info['sha256']
mode_options={'fast':{},'fast-backtracking':{'cranelift_opt_level':'None','register_allocation':'Backtracking'},
              'speed':{'cranelift_opt_level':'Speed','register_allocation':'Backtracking'},
              'speed-single-pass':{'cranelift_opt_level':'Speed','register_allocation':'SinglePass'}}
expected_config=dict(expected['configuration']);expected_config.update(mode_options[args.mode])
prior_path=args.prior_program_wasm.resolve(strict=True) if args.prior_program_wasm else None
if prior_path is not None:assert prior_path.stat().st_size==expected['program_wasm_bytes'] and digest(prior_path)==expected['program_wasm_sha256']
out=args.output.resolve();assert out.is_relative_to(BASE) and not out.exists();out.mkdir(parents=True);(out/'tmp').mkdir()
parent,child_socket=socket.socketpair();fd=child_socket.fileno();inode=os.fstat(fd).st_ino;nonce=os.urandom(16).hex();env=limited_environment();env.update(TMPDIR=str(out/'tmp'),SCRIPTW_RSC_PROFILE_FD=str(fd),SCRIPTW_RSC_PROFILE_NONCE=nonce,SCRIPTW_RSC_PROFILE_MODE='sync')
argv=[str(host),expected['inputs']['source'],expected['inputs']['support'],str(out/'report.json'),'1','3',args.mode]
class IOVec(ctypes.Structure):_fields_=[('base',ctypes.c_void_p),('length',ctypes.c_size_t)]
libc=ctypes.CDLL(None,use_errno=True);libc.process_vm_readv.restype=ctypes.c_ssize_t
protocol={str(path.resolve(strict=True)):digest(path) for path in [Path(__file__),BASE/'tools/common.py',BASE/'tools/measure_rsc.py',OLD/'attribution-tools/profile_thread.py',OLD/'attribution-tools/request_profile_support.py']}
report_inputs={str(path):digest(path) for path in [anchor,campaign_path,source_manifest,host,*([prior_path] if prior_path else [])]}
child=None;report={'complete':False,'unscored':True,'argv':argv,'mode':args.mode,'anchor_path':str(anchor),'anchor_sha256':digest(anchor),'campaign_path':str(campaign_path),'campaign_sha256':digest(campaign_path),'source_manifest':{'path':str(source_manifest),'sha256':digest(source_manifest)},'candidate_qualified_reuse':reuse_info,'host_sha256':digest(host),'source_fingerprint':expected['source_fingerprint'],'tool_inputs':protocol,'inputs':report_inputs,'resources_before':resources(),'functions':[]};started=time.time_ns();found=None
def memory(address,count):
 data=ctypes.create_string_buffer(count);local=IOVec(ctypes.cast(data,ctypes.c_void_p),count);remote=IOVec(address,count)
 n=libc.process_vm_readv(child.pid,ctypes.byref(local),1,ctypes.byref(remote),1,0)
 if n!=count:raise OSError(ctypes.get_errno(),f'owned-child read returned {n}/{count}')
 return data.raw
try:
 with (out/'host.stdout').open('xb') as so,(out/'host.stderr').open('xb') as se:
  child=subprocess.Popen(argv,cwd=ROOT,env=env,stdin=subprocess.DEVNULL,stdout=so,stderr=se,pass_fds=(fd,));child_socket.close();report['pid']=child.pid
  ready=f'SWRSC1 {nonce} ready sync 3\n';assert line(parent.fileno(),60)==ready
  report['caller']=barrier_caller(child.pid,fd,inode,thread_record)
  maps=Path(f'/proc/{child.pid}/maps').read_text();(out/'maps.txt').write_text(maps)
  executable_maps_before=[line for line in maps.splitlines() if 'r-x' in line.split()[1]]
  perf=Path(f'/tmp/perf-{child.pid}.map');assert perf.stat().st_mtime_ns>=started;(out/'perf.map').write_bytes(perf.read_bytes());perf_bytes=perf.read_bytes()
  entries=[]
  for raw in perf.read_text().splitlines():
   address,size,name=raw.split(maxsplit=2);entries.append((int(address,16),int(size,16),name))
  for name in ['js::vn#f133','js::ft#f123']:
   selected=[r for r in entries if r[2]==name];assert len(selected)==1;address,size,_=selected[0];assert 0<size<4*1024**2
   data=memory(address,size);path=out/(name.split('::')[1].split('#')[0]+'.native');path.write_bytes(data)
   mapping=next(line for line in executable_maps_before if int(line.split()[0].split('-')[0],16)<=address<int(line.split()[0].split('-')[1],16))
   report['functions'].append({'name':name,'address':address,'bytes':size,'path':path.name,'sha256':digest(path),'mapping':mapping})
  # Reuse exact current P bytes by full hash when available; otherwise bounded scan.
  wanted=expected['program_wasm_bytes'];wanted_sha=expected['program_wasm_sha256']
  if prior_path:
   shutil.copyfile(prior_path,out/'program.wasm')
   report['program_wasm']={'bytes':wanted,'sha256':digest(out/'program.wasm'),'reused_path':str(prior_path),'reused_sha256':digest(prior_path)}
   report['wasm_scan']={'scanned_bytes':0,'attempts':[],'skipped':'full Wasm SHA-256 matched supplied artifact'}
  else:
   scanned=0;attempts=[]
   for raw in maps.splitlines():
    parts=raw.split();lo,hi=[int(s,16) for s in parts[0].split('-')];permissions=parts[1]
    if permissions!='rw-p' or hi-lo<wanted:continue
    if len(parts)>5 and parts[5]!='[heap]':continue
    if hi-lo>1024**3 or scanned+hi-lo>1024**3:continue
    previous=b''
    for address in range(lo,hi,1024**2):
     data=memory(address,min(1024**2,hi-address));scanned+=len(data);chunk=previous+data;cursor=0
     while True:
      index=chunk.find(b'\0asm\1\0\0\0',cursor)
      if index<0:break
      candidate=address-len(previous)+index;cursor=index+8
      if candidate+wanted>hi:continue
      full=memory(candidate,wanted);sha=hashlib.sha256(full).hexdigest();attempts.append({'address':candidate,'sha256':sha})
      if sha==wanted_sha:found=(candidate,full);break
     if found:break
     previous=chunk[-7:]
    if found:break
   report['wasm_scan']={'scanned_bytes':scanned,'attempts':attempts}
   assert found, 'bounded writable heap scan did not find the exact anchor P bytes'
   address,data=found;(out/'program.wasm').write_bytes(data);report['program_wasm']={'address':address,'bytes':len(data),'sha256':digest(out/'program.wasm')}
  parent.sendall(ready.replace('SWRSC1','SWACK1',1).encode());done=f'SWRSC1 {nonce} done sync 3\n';assert line(parent.fileno(),30)==done
  for f in report['functions']:assert hashlib.sha256(memory(f['address'],f['bytes'])).hexdigest()==f['sha256']
  if found:assert hashlib.sha256(memory(report['program_wasm']['address'],wanted)).hexdigest()==wanted_sha
  maps_after=Path(f'/proc/{child.pid}/maps').read_text();(out/'maps-after.txt').write_text(maps_after)
  executable_maps_after=[line for line in maps_after.splitlines() if 'r-x' in line.split()[1]]
  assert executable_maps_after==executable_maps_before
  assert perf.read_bytes()==perf_bytes
  parent.sendall(done.replace('SWRSC1','SWACK1',1).encode());report['exit_code']=child.wait(timeout=30);assert report['exit_code']==0
 value=read(out/'report.json')
 for field in ['source_fingerprint','source_commit','compiler_identity_scheme','toolchain','program_wasm_sha256','program_wasm_bytes','runtime','executable_sha256','inputs']:assert value[field]==expected[field],field
 assert value['configuration']==expected_config and value['native_mode']==args.mode
 assert value['profiling']['nonce']==nonce and value['profiling']['windows']==1
 assert [case['case'] for case in value['cases']]==[CASES[0]], 'sync-only diagnostic has one selected request mode'
 assert all(case['exact_node_output_checked'] is True for case in value['cases'])
 check_source(source_manifest)
 report['complete']=True;report['maps_before_sha256']=digest(out/'maps.txt');report['maps_after_sha256']=digest(out/'maps-after.txt');report['perf_map_sha256']=digest(out/'perf.map');report['raw_program_acquired']=bool((out/'program.wasm').is_file())
finally:
 if child is not None and child.poll() is None:child.kill();child.wait(timeout=5)
 parent.close();child_socket.close();report['resources_after']=resources();check_resources(report['resources_before'],report['resources_after'])
 check_source(source_manifest);assert digest(anchor)==report['anchor_sha256'];assert digest(campaign_path)==report['campaign_sha256'];assert digest(host)==report['host_sha256']
 if prior_path:assert digest(prior_path)==report['program_wasm']['reused_sha256']
 for path,expected_sha in report['tool_inputs'].items():assert digest(path)==expected_sha
 for path,expected_sha in report['inputs'].items():assert digest(path)==expected_sha
 report['tool_sha256']=digest(Path(__file__));save(out/'receipt.json',report)
print('CAPTURED',args.mode,'raw P',report.get('raw_program_acquired',False),'functions',[(r['name'],r['bytes']) for r in report['functions']],flush=True)
