"""One native producer invocation, frozen before any later Cargo graph."""
import json,os,subprocess,sys,time
from pathlib import Path
ROOT=Path.cwd();BASE=ROOT/'target/performance-architecture-20261108';sys.path[:0]=[str(BASE/'tools'),str(ROOT/'scripts')]
from common import check_source,digest
from measure_rsc import resources,check_resources,cargo_source_identity
from limited_verification import require_kernel_budget,limited_environment
require_kernel_budget(4*1024**3);assert len(os.sched_getaffinity(0))==1
source=BASE/'tools/source-final/manifest.json';check_source(source)
targets=['emission','structure_builtins','structure_language','structure_async','runtime_link','modules_realms','intl_temporal','structure','aot_builtins','aot_language','aot_async','aot_realm_modules','aot_gc_entries']
argv=['cargo','--config','build.jobs=1','build','--release','--locked','-p','scriptw-cli','-p','scriptw-aot-wasm','-p','scriptw-engine']
for name in targets:argv.extend(['--test',name])
argv.extend(['--example','rsc_baseline','--example','compiler_precompiled_baseline','--message-format=json-render-diagnostics','--timings'])
(BASE/'build-argv.json').write_text(json.dumps(argv,indent=2)+'\n');receipt={'complete':False,'argv':argv,'source_manifest_sha256':digest(source),'resources_before':resources()};start=time.monotonic_ns()
try:
 with (BASE/'build.stdout').open('xb') as so,(BASE/'build.stderr').open('xb') as se:
  run=subprocess.run(argv,cwd=ROOT,env=limited_environment(),stdout=so,stderr=se,stdin=subprocess.DEVNULL,timeout=1800)
 receipt['exit_code']=run.returncode;assert run.returncode==0
 check_source(source);rows=[json.loads(s) for s in (BASE/'build.stdout').read_text().splitlines() if s.startswith('{')];assert any(r.get('reason')=='build-finished' and r['success'] for r in rows)
 folder=BASE/'frozen';folder.mkdir(exist_ok=False);receipt['artifacts']=[]
 for target in targets+['rsc_baseline','compiler_precompiled_baseline']:
  selected=[r for r in rows if r.get('reason')=='compiler-artifact' and r.get('executable') and r['target']['name']==target];assert len(selected)==1,target
  artifact=selected[0];original=Path(artifact['executable']);expected=digest(original);binary=folder/target;subprocess.run(['cp','--reflink=auto',str(original),str(binary)],check=True);assert digest(binary)==digest(original)==expected
  proof={'artifact':artifact,'sha256':expected,'frozen_path':str(binary),'source_manifest_sha256':digest(source),'cargo_stdout':str(BASE/'build.stdout'),'cargo_stdout_sha256':digest(BASE/'build.stdout')}
  (folder/(target+'-producer.json')).write_text(json.dumps(proof,indent=2)+'\n');receipt['artifacts'].append({'target':target,'sha256':expected,'producer_sha256':digest(folder/(target+'-producer.json'))})
 receipt['compiler_source_identity']=cargo_source_identity(BASE/'build.stdout');receipt['complete']=True
finally:
 receipt['elapsed_ns']=time.monotonic_ns()-start;receipt['resources_after']=resources();check_resources(receipt['resources_before'],receipt['resources_after']);check_source(source)
 for suffix in ('stdout','stderr'):receipt[suffix+'_sha256']=digest(BASE/('build.'+suffix))
 (BASE/'build-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('FROZEN',len(receipt['artifacts']),'NATIVE TARGETS',receipt['compiler_source_identity'],flush=True)
