import subprocess,sys
from pathlib import Path
R=Path.cwd();B=R/'target/performance-architecture-20261108'
argv=[sys.executable,'-B',str(B/'publication-tools/stage_after_acceptance.py'),'--corrected-emission-receipt',str(B/'emission-corrected/receipt.json'),'--current-emission-producer',str(B/'frozen-verification/emission-producer.json'),'--verification-manifest',str(B/'tools/source-complete/manifest.json'),'--postmeasurement-qualification',str(B/'tools/postmeasurement-test-reuse.json'),'--cli-receipt',str(B/'production-cli/receipt.json'),'--output-dir',str(B/'publication-stage-2')]
paths=[B/'source-guards-complete',B/'source-checks-complete',B/'tools/external-test-reuse-finished.json',B/'tools/postmeasurement-source-reuse.json',B/'test-corrections',B/'tools/qualify_test_correction.py']
paths.extend(p for p in sorted(B.iterdir()) if p.is_file() and not p.name.startswith('publication') and p.suffix in {'.py','.json','.stdout','.stderr'})
for path in paths:argv+=['--evidence',str(path)]
subprocess.run(argv,cwd=R,check=True)
