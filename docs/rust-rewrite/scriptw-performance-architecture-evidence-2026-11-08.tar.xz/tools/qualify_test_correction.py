#!/usr/bin/env python3
"""Qualify one external-test-only source snapshot correction and target rebuild."""
import argparse
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT / "target/performance-architecture-20261108"
sys.path.insert(0, str(BASE / "tools"))
from common import digest, read, save, validate_snapshot

ALLOWED = {
    "crates/scriptw-aot-wasm/tests/emission/infallible_booleans.rs",
    "crates/scriptw-aot-wasm/tests/emission/parameter_initialization.rs",
}


def identities(cargo_log):
    pairs = set()
    for line in Path(cargo_log).read_text().splitlines():
        row = json.loads(line)
        if row.get("reason") != "build-script-executed":
            continue
        env = dict(row.get("env", []))
        fp = env.get("SCRIPTW_COMPILER_FINGERPRINT")
        revision = env.get("SCRIPTW_COMPILER_SOURCE_REVISION")
        if fp and revision:
            pairs.add((fp, revision))
    assert len(pairs) == 1, ("Cargo log needs one compiler-source identity", cargo_log, pairs)
    return next(iter(pairs))


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--previous-manifest", type=Path, required=True)
    p.add_argument("--current-manifest", type=Path, required=True)
    p.add_argument("--previous-rsc-producer", type=Path, required=True)
    p.add_argument("--current-emission-producer", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    a = p.parse_args()
    previous_path = a.previous_manifest.resolve(strict=True)
    current_path = a.current_manifest.resolve(strict=True)
    previous = validate_snapshot(previous_path)
    current = validate_snapshot(current_path)
    assert previous["base_git"] == current["base_git"]
    assert previous["runtime_abi"] == current["runtime_abi"]
    assert previous["baseline_identity"] == current["baseline_identity"]
    assert set(previous["files"]) == set(current["files"])
    changed = {name for name in previous["files"]
               if previous["files"][name] != current["files"][name]}
    assert changed == ALLOWED, ("correction must change only the two named external tests", changed)
    for name in previous["files"]:
        before = previous_path.parent / "files" / name
        after = current_path.parent / "files" / name
        if name not in ALLOWED:
            assert before.read_bytes() == after.read_bytes(), name
    for name in ALLOWED:
        old_test = previous_path.parent / "files" / name
        new_test = current_path.parent / "files" / name
        assert old_test.read_bytes() != new_test.read_bytes(), name

    old_producer_path = a.previous_rsc_producer.resolve(strict=True)
    old_producer = read(old_producer_path)
    old_host = Path(old_producer["frozen_path"]).resolve(strict=True)
    assert old_producer["sha256"] == digest(old_host)
    assert old_producer["source_manifest_sha256"] == digest(previous_path)
    assert old_producer["artifact"]["target"]["name"] == "rsc_baseline"
    assert old_producer["artifact"]["fresh"] is False
    old_cargo = Path(old_producer["cargo_stdout"]).resolve(strict=True)
    assert digest(old_cargo) == old_producer["cargo_stdout_sha256"]
    old_identity = identities(old_cargo)

    new_producer_path = a.current_emission_producer.resolve(strict=True)
    new_producer = read(new_producer_path)
    new_host = Path(new_producer["frozen_path"]).resolve(strict=True)
    assert new_producer["sha256"] == digest(new_host)
    assert new_producer["source_manifest_sha256"] == digest(current_path)
    assert new_producer["artifact"]["target"]["name"] == "emission"
    new_cargo = Path(new_producer["cargo_stdout"]).resolve(strict=True)
    assert digest(new_cargo) == new_producer["cargo_stdout_sha256"]
    new_artifact = new_producer["artifact"]
    assert new_artifact["package_id"].split("#", 1)[0].endswith("/crates/scriptw-aot-wasm")
    assert new_artifact["target"]["name"] == "emission"
    assert new_artifact["target"]["kind"] == ["test"] and new_artifact["target"]["test"] is True
    assert new_artifact["profile"]["test"] is True and new_artifact["profile"]["opt_level"] == "3"
    assert new_artifact["features"] == []
    assert new_artifact["fresh"] is False

    output = a.output.resolve()
    assert output.is_relative_to(BASE) and not output.exists()
    proof = {
        "schema": "scriptw-external-test-correction-qualified-reuse-v1",
        "allowed_external_tests": sorted(ALLOWED),
        "previous_source": {"manifest": str(previous_path), "sha256": digest(previous_path)},
        "current_source": {"manifest": str(current_path), "sha256": digest(current_path)},
        "changed_source_files": sorted(changed),
        "product_source_identity": {"fingerprint": old_identity[0], "revision": old_identity[1],
                                    "producer": str(old_producer_path),
                                    "producer_sha256": digest(old_producer_path)},
        "previous_build": {"host": str(old_host), "sha256": digest(old_host),
                           "producer": str(old_producer_path), "producer_sha256": digest(old_producer_path),
                           "cargo_log": str(old_cargo), "cargo_log_sha256": digest(old_cargo),
                           "artifact_fresh": False},
        "corrected_target_build": {"target": "emission", "host": str(new_host),
                                    "sha256": digest(new_host), "producer": str(new_producer_path),
                                    "producer_sha256": digest(new_producer_path),
                                    "cargo_log": str(new_cargo), "cargo_log_sha256": digest(new_cargo),
                                    "source_manifest_sha256": digest(current_path)},
        "qualification": "Two external integration tests changed. All non-test product/compiler source inputs are byte-identical. The compiler identity is pinned by the original engine-linked RSC producer; the corrected emission-only test crate does not emit an engine build-script identity. The corrected emission test artifact is pinned to the corrected source manifest.",
    }
    save(output, proof)
    print(json.dumps({"receipt": str(output), "sha256": digest(output),
                      "current_source": digest(current_path), "product_identity": old_identity,
                      "corrected_emission": digest(new_host)}, indent=2))


if __name__ == "__main__":
    main()
