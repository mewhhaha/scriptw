#!/usr/bin/env python3
"""Stage architecture evidence after complete broad inventory, corrected emission, full21 and CLI.

This runner preserves original failures as evidence and never promotes tracked
files. Root owns failure qualification, public prose and canonical promotion.
"""
import argparse
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT / 'target/performance-architecture-20261108'
HERE = Path(__file__).resolve().parent
sys.path[:0] = [str(BASE / 'tools'), str(ROOT / 'scripts')]
from common import digest, read, save
from limited_verification import limited_environment, require_kernel_budget


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--original-broad-receipt', type=Path, default=BASE / 'broad/receipt.json')
    p.add_argument('--corrected-emission-receipt', type=Path, required=True)
    p.add_argument('--current-emission-producer', type=Path, required=True)
    p.add_argument('--verification-manifest', type=Path, default=BASE / 'tools/source-complete/manifest.json')
    p.add_argument('--postmeasurement-qualification', type=Path,
                   default=BASE / 'tools/postmeasurement-test-reuse.json')
    p.add_argument('--cli-receipt', type=Path, required=True)
    p.add_argument('--situations-report', type=Path, default=BASE / 'situations-full/report.json')
    p.add_argument('--evidence', type=Path, action='append', default=[])
    p.add_argument('--output-dir', type=Path, default=BASE / 'publication-stage')
    p.add_argument('--review-dir', type=Path, default=BASE / 'publication-review')
    a = p.parse_args()
    require_kernel_budget(4 * 1024**3)
    broad_path = a.original_broad_receipt.resolve(strict=True)
    corrected_path = a.corrected_emission_receipt.resolve(strict=True)
    broad, corrected = read(broad_path), read(corrected_path)
    measured = BASE / 'tools/source-finished/manifest.json'
    assert broad['complete'] is True and len(broad['runs']) == 13
    assert broad['source_manifest_sha256'] == digest(measured)
    assert corrected['complete'] is True and corrected['all_passed'] is True
    assert len(corrected['runs']) == 1 and corrected['runs'][0]['target'] == 'emission'
    assert corrected['runs'][0]['verified'] is True and corrected['runs'][0]['inventory'] == 79
    assert corrected['source_manifest_sha256'] == digest(a.verification_manifest)
    cli_path = a.cli_receipt.resolve(strict=True)
    cli = read(cli_path)
    assert cli['complete'] is True and cli['passed'] is True and cli['passed_smokes'] == 9
    situations_path = a.situations_report.resolve(strict=True)
    situations = read(situations_path)
    assert situations['status'] == 'complete' and len(situations['cases']) == 21
    qualifier = a.postmeasurement_qualification.resolve()
    environment = limited_environment()
    commands = []
    def run(argv):
        commands.append(argv)
        subprocess.run(argv, cwd=ROOT, env=environment, stdin=subprocess.DEVNULL, check=True)
    if not qualifier.exists():
        run([sys.executable, '-B', str(HERE / 'qualify_verification_correction.py'),
             '--verification-manifest', str(a.verification_manifest.resolve(strict=True)),
             '--current-emission-producer', str(a.current_emission_producer.resolve(strict=True)),
             '--previous-broad-receipt', str(broad_path),
             '--corrected-emission-receipt', str(corrected_path), '--output', str(qualifier)])
    proof = read(qualifier)
    assert proof['measured_source']['sha256'] == digest(measured)
    assert proof['verification_source']['sha256'] == digest(a.verification_manifest)
    assert proof['corrected_emission_rerun']['sha256'] == digest(corrected_path)
    evidence = [broad_path.parent, corrected_path.parent, cli_path.parent,
                BASE / 'source-checks-finished', BASE / 'source-guards-finished']
    # Preserve every earlier failed/corrected focused witness and its producer.
    evidence.extend(path for path in BASE.iterdir() if path.is_dir() and
                    path.name.startswith(('focused', 'parameter-', 'frozen-')))
    evidence.extend(a.evidence)
    argv = [sys.executable, '-B', str(HERE / 'stage_publication.py'),
            '--campaign', str(BASE / 'tools/rsc-campaign-1/campaign.json'),
            '--aggregate', str(BASE / 'tools/rsc-campaign-1/aggregate.json'),
            '--source-manifest', str(measured),
            '--verification-source-manifest', str(measured),
            '--postmeasurement-verification-manifest', str(a.verification_manifest.resolve(strict=True)),
            '--postmeasurement-qualification', str(qualifier),
            '--situations-report', str(situations_path),
            '--test-only-qualification', str(BASE / 'tools/external-test-reuse-finished.json'),
            '--output-dir', str(a.output_dir.resolve())]
    diagnostics = [BASE / 'tools/native-policy-2x2', BASE / 'cache-census', BASE / 'cache-census-tools', BASE / 'astra', BASE / 'capture-fast', BASE / 'capture-speed', BASE / 'react-architecture-current.json', BASE / 'tools/build_react_architecture_data.py']
    diagnostics.extend(path for path in BASE.iterdir() if path.is_dir() and path.name.startswith('capture-final-'))
    for path in diagnostics:
        if path.exists():
            argv.extend(['--architecture-diagnostics', str(path.resolve(strict=True))])
    for path in dict.fromkeys(path.resolve(strict=True) for path in evidence):
        argv.extend(['--evidence', str(path)])
    run(argv)
    run([sys.executable, '-B', str(HERE / 'stage_docs.py'),
         '--rsc-report', str(a.output_dir.resolve() / 'reports/rsc-current.json'),
         '--situations-report', str(a.output_dir.resolve() / 'reports/situations-current.json'),
         '--output-dir', str(a.review_dir.resolve())])
    receipt = {'schema': 'scriptw-architecture-publication-runner-v1', 'complete': True,
               'canonical_files_written': False, 'commands': commands,
               'measured_source_sha256': digest(measured),
               'verification_source_sha256': digest(a.verification_manifest),
               'original_broad_receipt_sha256': digest(broad_path),
               'corrected_emission_receipt_sha256': digest(corrected_path),
               'original_broad_outcomes_preserved': True,
               'limits': 'Staging only; original failures stay visible and need explicit ownership in final prose.'}
    save(BASE / 'publication-runner-receipt.json', receipt)


if __name__ == '__main__':
    main()
