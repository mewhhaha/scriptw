#!/usr/bin/env python3
"""Bind one postmeasurement external-test correction without rerunning RSC."""
import argparse
import hashlib
import json
import subprocess
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT / 'target/performance-architecture-20261108'
sys.path.insert(0, str(BASE / 'tools'))
from common import digest, read, save, validate_snapshot
from qualify_test_correction import identities

INITIAL_TESTS = {
    'crates/scriptw-aot-wasm/tests/emission/infallible_booleans.rs',
    'crates/scriptw-aot-wasm/tests/emission/parameter_initialization.rs',
}
POSTMEASUREMENT_TEST = 'crates/scriptw-aot-wasm/tests/emission/retained_operands.rs'


def base_file(manifest, name):
    # Dirty snapshots omit unchanged tracked files. Resolve an exact newly
    # listed tracked input through the pinned base commit, never live HEAD.
    return subprocess.check_output(['git', 'show', f"{manifest['base_git']}:{name}"], cwd=ROOT)


def changed(before, after, added_tracked=()):
    additions = set(after['files']) - set(before['files'])
    assert additions == set(added_tracked), ('unexpected newly listed source files', additions)
    assert not set(before['files']) - set(after['files']), 'a measured dirty input disappeared'
    assert after['tracked_files'] == sorted(set(before['tracked_files']) | additions)
    assert before['untracked_files'] == after['untracked_files']
    assert before['deleted_files'] == after['deleted_files']
    for key in ('base_git', 'base_runtime_abi', 'runtime_abi', 'baseline_identity'):
        assert before[key] == after[key], key
    for name in additions:
        assert after['files'][name]['origin'] == 'tracked'
        previous = base_file(before, name)
        assert hashlib.sha256(previous).hexdigest() != after['files'][name]['sha256']
    return additions | {name for name in before['files'] if before['files'][name] != after['files'][name]}



def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--producer-manifest', type=Path, default=BASE / 'tools/source-final/manifest.json')
    p.add_argument('--measured-manifest', type=Path, default=BASE / 'tools/source-finished/manifest.json')
    p.add_argument('--verification-manifest', type=Path, default=BASE / 'tools/source-complete/manifest.json')
    p.add_argument('--measured-qualification', type=Path, default=BASE / 'tools/external-test-reuse-finished.json')
    p.add_argument('--rsc-producer', type=Path, default=BASE / 'frozen/rsc_baseline-producer.json')
    p.add_argument('--current-emission-producer', type=Path, required=True)
    p.add_argument('--campaign', type=Path, default=BASE / 'tools/rsc-campaign-1/campaign.json')
    p.add_argument('--aggregate', type=Path, default=BASE / 'tools/rsc-campaign-1/aggregate.json')
    p.add_argument('--previous-broad-receipt', type=Path, required=True)
    p.add_argument('--corrected-emission-receipt', type=Path,
                   help='optional completed rerun; absent means this receipt qualifies source/build reuse only')
    p.add_argument('--output', type=Path, required=True)
    a = p.parse_args()
    producer_path, measured_path, verification_path = (
        path.resolve(strict=True) for path in (a.producer_manifest, a.measured_manifest, a.verification_manifest))
    producer_source, measured, verification = (
        validate_snapshot(path) for path in (producer_path, measured_path, verification_path))
    assert changed(producer_source, measured) == INITIAL_TESTS
    assert changed(measured, verification, {POSTMEASUREMENT_TEST}) == {POSTMEASUREMENT_TEST}
    assert changed(producer_source, verification, {POSTMEASUREMENT_TEST}) == INITIAL_TESTS | {POSTMEASUREMENT_TEST}
    prior_qualification_path = a.measured_qualification.resolve(strict=True)
    prior_qualification = read(prior_qualification_path)
    assert prior_qualification['current_source']['sha256'] == digest(measured_path)
    assert prior_qualification['previous_source']['sha256'] == digest(producer_path)
    assert set(prior_qualification['changed_source_files']) == INITIAL_TESTS
    rsc_producer_path = a.rsc_producer.resolve(strict=True)
    rsc = read(rsc_producer_path)
    assert rsc['source_manifest_sha256'] == digest(producer_path)
    assert rsc['artifact']['target']['name'] == 'rsc_baseline'
    assert rsc['sha256'] == digest(rsc['frozen_path'])
    assert rsc['cargo_stdout_sha256'] == digest(rsc['cargo_stdout'])
    fingerprint, revision = identities(rsc['cargo_stdout'])
    campaign_path, aggregate_path = a.campaign.resolve(strict=True), a.aggregate.resolve(strict=True)
    campaign, aggregate = read(campaign_path), read(aggregate_path)
    assert campaign['status'] == 'complete'
    assert campaign['source_manifest_sha256'] == aggregate['source_manifest_sha256'] == digest(measured_path)
    assert aggregate['measurement']['campaign_sha256'] == digest(campaign_path)
    assert aggregate['engines']['candidate']['identity']['source_fingerprint'] == fingerprint
    assert campaign['candidate']['sha256'] == rsc['sha256']
    current_producer_path = a.current_emission_producer.resolve(strict=True)
    current = read(current_producer_path)
    assert current['source_manifest_sha256'] == digest(verification_path)
    assert current['sha256'] == digest(current['frozen_path'])
    assert current['cargo_stdout_sha256'] == digest(current['cargo_stdout'])
    artifact = current['artifact']
    assert artifact['target']['name'] == 'emission' and artifact['target']['kind'] == ['test']
    assert artifact['target']['test'] is True and artifact['profile']['test'] is True
    assert artifact['profile']['opt_level'] == '3' and artifact['features'] == []
    assert artifact['fresh'] is False
    previous_broad_path = a.previous_broad_receipt.resolve(strict=True)
    previous_broad = read(previous_broad_path)
    assert previous_broad['complete'] is True
    assert previous_broad['source_manifest_sha256'] == digest(measured_path)
    # Preserve the failed initial emission result. Only its other scopes are reusable.
    other_runs = [row for row in previous_broad['runs'] if row['target'] != 'emission']
    assert len(previous_broad['runs']) == 13 and len(other_runs) == 12
    assert all(row.get('exit_code') is not None and len(row.get('summary', [])) == 1 for row in other_runs)
    corrected = None
    if a.corrected_emission_receipt is not None:
        corrected_path = a.corrected_emission_receipt.resolve(strict=True)
        corrected = read(corrected_path)
        assert corrected['complete'] is True and corrected['all_passed'] is True
        assert corrected['source_manifest_sha256'] == digest(verification_path)
        assert len(corrected['runs']) == 1
        run = corrected['runs'][0]
        assert run['target'] == 'emission' and run['verified'] is True and run['inventory'] == 79
        assert run['binary_sha256'] == current['sha256']
        corrected = {'path': str(corrected_path), 'sha256': digest(corrected_path), 'inventory': 79}
    proof = {
        'schema': 'scriptw-postmeasurement-external-test-correction-v1',
        'allowed_external_tests': [POSTMEASUREMENT_TEST],
        'original_producer_source': {'manifest': str(producer_path), 'sha256': digest(producer_path)},
        'measured_source': {'manifest': str(measured_path), 'sha256': digest(measured_path)},
        'verification_source': {'manifest': str(verification_path), 'sha256': digest(verification_path)},
        'initial_test_qualification': {'path': str(prior_qualification_path), 'sha256': digest(prior_qualification_path)},
        'changed_since_measurement': [POSTMEASUREMENT_TEST],
        'newly_listed_tracked_file': {
            'path': POSTMEASUREMENT_TEST, 'base_git': measured['base_git'],
            'before_sha256': hashlib.sha256(base_file(measured, POSTMEASUREMENT_TEST)).hexdigest(),
            'after_sha256': verification['files'][POSTMEASUREMENT_TEST]['sha256'],
            'previous_bytes_role': 'unchanged tracked file omitted from measured dirty snapshot; read from pinned base commit'},
        'product_source_identity': {'fingerprint': fingerprint, 'revision': revision,
                                    'producer': str(rsc_producer_path), 'producer_sha256': digest(rsc_producer_path)},
        'measurement': {'campaign': str(campaign_path), 'campaign_sha256': digest(campaign_path),
                        'aggregate': str(aggregate_path), 'aggregate_sha256': digest(aggregate_path),
                        'rerun_required': False},
        'corrected_target_build': {'target': 'emission', 'host': current['frozen_path'],
            'sha256': current['sha256'], 'producer': str(current_producer_path),
            'producer_sha256': digest(current_producer_path), 'cargo_log': current['cargo_stdout'],
            'cargo_log_sha256': current['cargo_stdout_sha256'],
            'source_manifest_sha256': digest(verification_path)},
        'original_broad_receipt': {'path': str(previous_broad_path), 'sha256': digest(previous_broad_path)},
        'reused_broad_targets': [{'target': row['target'], 'verified': row['verified'],
                                  'exit_code': row['exit_code'], 'summary': row['summary'],
                                  'binary_sha256': row['binary_sha256'],
                                  'producer_sha256': row['producer_sha256']} for row in other_runs],
        'corrected_emission_rerun': corrected,
        'qualification': 'Only retained_operands.rs changed after the completed RSC campaign. All compiler/product inputs, other external test targets and original producer identities remain byte-identical. Original scope outcomes, including failures, are preserved explicitly; source reuse is not a claim that those scopes passed. RSC/native-policy evidence remains bound to source-finished; final verification is separately bound to source-complete. A missing corrected rerun field is not a test pass.',
    }
    output = a.output.resolve()
    assert output.is_relative_to(BASE) and not output.exists()
    save(output, proof)
    print(output)


if __name__ == '__main__':
    main()
