#!/usr/bin/env python3
"""Stage current RSC/situation reports and a text-only evidence archive."""
import argparse
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import subprocess

ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT / 'target/performance-architecture-20261108'
ARCHIVER = ROOT / 'target/react-performance-20261103/archive_final.py'
RSC_RENDERER = ROOT / 'scripts/render-application-benchmarks.py'
SITUATION_RENDERER = ROOT / 'scripts/render-situation-benchmarks.py'
sys.path.insert(0, str(ROOT / 'scripts'))
TEXT_SUFFIXES = {'.json', '.jsonl', '.receipt', '.stdout', '.stderr', '.list', '.txt', '.map', '.rs',
                 '.js', '.cjs', '.mjs', '.py', '.md', '.toml', '.patch', '.snap', '.csv', '.svg', '.sh', '.log', '.disasm'}
FORBIDDEN_NAMES = {'perf.data', 'callchains.json'}
FORBIDDEN_SUFFIXES = {'.wasm', '.so', '.a', '.rlib', '.rmeta', '.o', '.dylib', '.dll', '.exe', '.bin', '.xz', '.zst', '.zip'}
INTERNAL_TEST_ONLY_FILE = 'crates/scriptw-aot-wasm/src/tests/local_argument_calls.rs'
MIXED_CFG_TEST_FILE = 'crates/scriptw-aot-wasm/src/functions/numeric_body.rs'
COMPILER_TEST_EXCLUSION_FILE = 'crates/scriptw-engine/compiler_fingerprint.rs'
TEST_MODULE_FILE = 'crates/scriptw-aot-wasm/src/tests.rs'
TEST_GATE_FILE = 'crates/scriptw-aot-wasm/src/lib.rs'


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def encoded(value):
    return (json.dumps(value, indent=2, allow_nan=False) + '\n').encode()


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def require_text_file(path):
    path = Path(path).resolve(strict=True)
    assert path.is_file() and not path.is_symlink(), f'not a regular evidence file: {path}'
    assert path.name not in FORBIDDEN_NAMES and path.suffix.lower() not in FORBIDDEN_SUFFIXES, path
    assert path.suffix.lower() in TEXT_SUFFIXES or path.name in {'stdout', 'stderr'}, (
        f'not an admitted text evidence type: {path}')
    data = path.read_bytes()
    assert b'\0' not in data and data[:4] not in (b'\x7fELF', b'\x00asm'), f'binary evidence rejected: {path}'
    data.decode('utf-8')
    return path


def add_evidence_tree(archive, source, prefix):
    source = Path(source).resolve(strict=True)
    assert source.is_relative_to(ROOT) and source.is_dir() and not source.is_symlink()
    for path in sorted(source.rglob('*')):
        if path.is_dir():
            assert not path.is_symlink(), f'symlink in evidence tree: {path}'
            continue
        if path.name in FORBIDDEN_NAMES or path.suffix.lower() in FORBIDDEN_SUFFIXES:
            continue
        if path.suffix.lower() not in TEXT_SUFFIXES and path.name not in {'stdout', 'stderr'}:
            continue
        path = require_text_file(path)
        member = prefix.rstrip('/') + '/' + path.relative_to(source).as_posix()
        archive.add_file(member, path)


def add_source_snapshot(archive, manifest_path, prefix='source/current'):
    root = Path(manifest_path).parent
    manifest = read(manifest_path)
    listed = manifest['files']
    archive.add_file(prefix + '/manifest.json', require_text_file(manifest_path))
    archive.add_file(prefix + '/tracked.patch', require_text_file(root / 'tracked.patch'))
    archive.add_file(prefix + '/baseline/rsc-current.json',
                     require_text_file(root / 'baseline/rsc-current.json'))
    for relative, record in sorted(listed.items()):
        source = require_text_file(root / 'files' / relative)
        assert sha(source) == record['sha256'], f'frozen source snapshot hash mismatch: {relative}'
        archive.add_file(prefix + '/files/' + relative, source)
    present = {p.relative_to(root / 'files').as_posix() for p in (root / 'files').rglob('*') if p.is_file()}
    assert present == set(listed), 'frozen source snapshot inventory differs from manifest'


def add_rsc_campaign(archive, campaign_path, aggregate_path):
    root = Path(campaign_path).parent
    campaign = read(campaign_path)
    aggregate = read(aggregate_path)
    archive.add_file('rsc/campaign.json', require_text_file(campaign_path))
    archive.add_file('rsc/aggregate.json', require_text_file(aggregate_path))
    for path in sorted((root / 'inputs').rglob('*')):
        if path.is_file():
            if path.name == 'corrected-emission-test-host':
                producer = read(root / 'inputs/corrected-emission-producer.json')
                with path.open('rb') as stream:
                    assert stream.read(4) == b'\x7fELF'
                assert sha(path) == producer['sha256']
                archive.add_bytes('rsc/inputs/excluded-binaries.json', encoded({
                    path.name: {'sha256': sha(path), 'bytes': path.stat().st_size,
                                'producer': 'rsc/inputs/corrected-emission-producer.json',
                                'scope': 'local frozen test executable; binary excluded from inert text archive'}}))
                continue
            source = require_text_file(path)
            archive.add_file('rsc/inputs/' + path.relative_to(root / 'inputs').as_posix(), source)
    for row in campaign['processes']:
        assert row['status'] == 'complete'
        for field in ('report', 'stdout', 'stderr'):
            relative = Path(row[field])
            assert not relative.is_absolute() and '..' not in relative.parts
            source = require_text_file(root / relative)
            assert sha(source) == row[field + '_sha256'], f'campaign {field} hash mismatch: {relative}'
            archive.add_file('rsc/' + relative.as_posix(), source)


PUBLIC_ACTORS = ['baseline', 'candidate', 'candidate-speed', 'v8']
OPTIONAL_ACTORS = ['baseline', 'baseline-speed', 'candidate', 'candidate-speed', 'v8']
IDENTITY_FIELDS = ('source_fingerprint', 'source_commit', 'executable_sha256',
                   'compiler_identity_scheme', 'toolchain', 'program_wasm_bytes',
                   'program_wasm_sha256', 'runtime', 'inputs')


def validate_native_pair(engines, fast_name, speed_name):
    fast, speed = (engines[name]['identity'] for name in (fast_name, speed_name))
    for key in IDENTITY_FIELDS:
        assert fast[key] == speed[key], f'{fast_name}/{speed_name} identity mismatch: {key}'
    assert fast['configuration']['cranelift_opt_level'] == 'None'
    assert fast['configuration']['register_allocation'] == 'SinglePass'
    assert speed['configuration']['cranelift_opt_level'] == 'Speed'
    assert speed['configuration']['register_allocation'] == 'Backtracking'
    normalized = dict(speed['configuration'])
    normalized.update(cranelift_opt_level='None', register_allocation='SinglePass')
    assert normalized == fast['configuration'], 'native policies differ beyond their scored settings'


def validate_campaign(campaign_path, aggregate_path, manifest_path):
    campaign, aggregate = read(campaign_path), read(aggregate_path)
    common = load_module('architecture_saved_source', BASE / 'tools/common.py')
    manifest = common.validate_snapshot(manifest_path)
    assert campaign['schema'] == 'scriptw-rsc-levers-campaign-v1'
    assert campaign['status'] == 'complete'
    assert aggregate['schema'] == 'scriptw-rsc-levers-aggregate-v1'
    assert aggregate['source_manifest_sha256'] == campaign['source_manifest_sha256'] == sha(manifest_path)
    assert manifest['base_git'] == 'b8c7325438c48028866fc85a74f2115acd465731'
    assert manifest['base_runtime_abi'] == manifest['runtime_abi'] == aggregate['runtime_abi'] == 53
    assert aggregate['measurement']['campaign_sha256'] == sha(campaign_path)
    actors = campaign['policy']['actors']
    assert actors == PUBLIC_ACTORS or actors == OPTIONAL_ACTORS
    assert aggregate['measurement']['actors'] == actors
    assert set(aggregate['engines']) == set(actors)
    assert len(campaign['processes']) == len(actors) * 8
    checked_calls = len(actors) * 8 * 2 * (7 + 3)
    assert aggregate['measurement']['checked_flight_calls'] == checked_calls
    assert campaign['policy']['checked_flight_calls'] == checked_calls
    assert campaign['policy']['blocks'] == 2
    assert campaign['policy']['processes_per_actor_per_block'] == 4
    assert campaign['policy']['samples'] == 7 and campaign['policy']['warmups'] == 3
    assert campaign['source_base_git'] == manifest['base_git']
    assert campaign['runtime_abi'] == manifest['runtime_abi']
    public = read(Path(manifest_path).parent / 'baseline/rsc-current.json')
    assert public['schema'] == 'scriptw-rsc-current-v2'
    published_baseline = public['engines']['candidate']['identity']
    for key in IDENTITY_FIELDS + ('configuration',):
        assert campaign['baseline']['identity'][key] == published_baseline[key], (
            f'0c2c baseline differs from its original published identity: {key}')
    assert published_baseline['source_fingerprint'].startswith('0c2c10da')
    assert published_baseline['source_commit'] == 'dfefb3222737b067e1c98777161d95d42491df8f'
    fast = aggregate['engines']['candidate']['identity']
    assert fast['source_commit'] == manifest['base_git']
    producer = campaign['candidate']['compiler_source_identity']
    assert producer['source_revision'].removeprefix('git:') == manifest['base_git']
    assert producer['source_fingerprint'] == fast['source_fingerprint']
    for actor in actors:
        rows = [row for row in campaign['processes'] if row['actor'] == actor]
        assert len(rows) == 8 and all(row['status'] == 'complete' for row in rows), actor
        assert {row['block'] for row in rows} == {0, 1}
        assert all(sum(row['block'] == block for row in rows) == 4 for block in (0, 1))
        engine = aggregate['engines'][actor]
        assert set(engine['cases']) == {'rsc-sync', 'rsc-async'}
        assert all(len(values) == 8 and all(type(v) is int and v > 0 for v in values)
                   for values in engine['cases'].values())
        if actor != 'v8':
            assert len(engine['phase_processes']) == 8
    validate_native_pair(aggregate['engines'], 'candidate', 'candidate-speed')
    if 'baseline-speed' in actors:
        validate_native_pair(aggregate['engines'], 'baseline', 'baseline-speed')
    assert campaign['candidate']['sha256'] == fast['executable_sha256']
    assert campaign['candidate']['artifact']['fresh'] is False
    measured_baseline = aggregate['engines']['baseline']['identity']
    for key in IDENTITY_FIELDS + ('configuration',):
        assert campaign['baseline']['identity'][key] == measured_baseline[key], key
    return campaign, aggregate, manifest


def make_rsc_report(campaign_path, aggregate_path, manifest_path):
    campaign, aggregate, manifest = validate_campaign(campaign_path, aggregate_path, manifest_path)
    template_path = Path(manifest_path).parent / 'baseline/rsc-current.json'
    report = read(template_path)
    assert report['schema'] == 'scriptw-rsc-current-v2'
    report['date'] = aggregate['date']
    report['caveat'] = aggregate['caveat']
    report['source_manifest_sha256'] = sha(manifest_path)
    report['baseline'] = campaign['baseline']
    report['candidate'] = dict(campaign['candidate'])
    # Preserve the runner's explicit original-producer/test-only reuse qualification.
    report['candidate_speed'] = {
        'path': campaign['candidate']['path'],
        'sha256': campaign['candidate']['sha256'],
        'cargo_producer': campaign['candidate']['cargo_producer'],
        'cargo_producer_sha256': campaign['candidate']['cargo_producer_sha256'],
        'configuration': aggregate['engines']['candidate-speed']['identity']['configuration'],
        'native_mode': 'speed',
        'scope': 'separately scored native compilation policy',
    }
    policy = campaign['policy']
    measurement = copy.deepcopy(aggregate['measurement'])
    measurement.update({
        'processes_per_engine_per_block': policy['processes_per_actor_per_block'],
        'clock': policy['clock'],
        'process_order': policy['process_order'],
        'execution_processes': len(campaign['processes']),
        'exact_output': 'Both RSC cases were checked against the shared Node-generated JSON golden.',
    })
    report['measurement'] = measurement
    # The canonical renderer's inventory remains four; the optional prior-source
    # Speed control is retained outside that chart map and in the raw archive.
    report['engines'] = {actor: copy.deepcopy(aggregate['engines'][actor]) for actor in PUBLIC_ACTORS}
    report.pop('baseline_speed_control', None)
    if 'baseline-speed' in aggregate['engines']:
        report['baseline_speed_control'] = {
            **copy.deepcopy(aggregate['engines']['baseline-speed']),
            'actor': 'baseline-speed', 'scored_in_current_chart': False,
            'scope': 'separately measured prior-source Speed control; included in total process/call counts',
        }
    for key in ('attribution', 'current_attribution', 'profiles', 'profile_attribution',
                'architecture_diagnostics', 'baseline_diagnostics'):
        report.pop(key, None)
    report['inputs'] = campaign['inputs']
    candidate_source = {
        'source_commit': aggregate['engines']['candidate']['identity']['source_commit'],
        'source_fingerprint': aggregate['engines']['candidate']['identity']['source_fingerprint'],
        'manifest_path': str(Path(manifest_path).relative_to(ROOT)),
        'manifest_sha256': sha(manifest_path),
        'runtime_abi': manifest['runtime_abi'],
        'archive_prefix': 'source/current/',
        'manifest_member': 'source/current/manifest.json',
    }
    report['source_identity'] = {
        'git_revision_role': 'b8c parent with one frozen architecture source batch and separately qualified test-only witness correction',
        'baseline_source': {
            'identity': campaign['baseline']['identity'],
            'executable': campaign['baseline']['path'],
            'executable_sha256': campaign['baseline']['sha256'],
            'report': campaign['baseline']['report'],
            'report_sha256': campaign['baseline']['report_sha256'],
            'published_report_sha256': campaign['baseline']['published_report_sha256'],
        },
        'candidate_measured_source': candidate_source,
        'candidate_build': {
            'path': campaign['candidate']['path'],
            'executable_sha256': campaign['candidate']['sha256'],
            'cargo_producer': campaign['candidate']['cargo_producer'],
            'cargo_producer_sha256': campaign['candidate']['cargo_producer_sha256'],
            'build_producer_is_direct': True,
            'compiler_source_identity': campaign['candidate']['compiler_source_identity'],
            'qualified_reuse': campaign['candidate'].get('qualified_reuse'),
            'producer_role': 'direct original build, with separately qualified external-test correction',
        },
        'candidate_speed_policy': aggregate['engines']['candidate-speed']['identity']['configuration'],
        'runtime_abi': manifest['runtime_abi'],
    }
    report['producer_receipts'] = {
        'baseline': {
            'path': campaign['baseline']['producer'],
            'sha256': campaign['baseline']['producer_sha256'],
        },
        'candidate': {
        'cargo_producer': campaign['candidate']['cargo_producer'],
        'cargo_producer_sha256': campaign['candidate']['cargo_producer_sha256'],
            'build_producer_is_direct': True,
        },
        'candidate_speed': {
            'cargo_producer': campaign['candidate']['cargo_producer'],
            'cargo_producer_sha256': campaign['candidate']['cargo_producer_sha256'],
            'native_configuration': aggregate['engines']['candidate-speed']['identity']['configuration'],
        },
    }
    report.pop('evidence_archive', None)
    report.pop('complete_archived_report', None)
    report['publication'] = {
        'date': aggregate['date'], 'status': 'staged-ready-for-review',
        'measured_source': candidate_source,
        'baseline': {'identity': campaign['baseline']['identity'],
                     'reference_campaign_sha256': campaign['baseline']['reference_campaign_sha256'],
                     'reference_aggregate_sha256': campaign['baseline']['reference_aggregate_sha256']},
        'speed_policy': campaign['policy']['speed_scope'],
        'archive_prefix': 'source/current/',
    }
    report.pop('baseline_diagnostics', None)
    report.pop('test_only_qualifications', None)
    report.pop('source_witnesses', None)
    report.pop('evidence_archive', None)
    report['staging'] = {
        'status': 'ready-for-review', 'canonical_files_written': False,
        'archive_created': False, 'charts_rendered': False,
        'limits': aggregate['caveat'],
    }
    return report, campaign, aggregate


def compact_situations(path, candidate_identity, historical_path, measured_manifest_sha256):
    report = read(path)
    assert report.get('schema') == 'scriptw-situation-benchmarks-v1', (
        'publish the official raw full-21 report directly; wrappers need a separately justified qualification'
    )
    renderer = load_module('scriptw_situation_renderer', SITUATION_RENDERER)
    cases = renderer.validate(report)
    assert report['status'] == 'complete' and len(cases) == 21
    policy = report['policy']
    assert policy['actors'] == ['scriptw-fast', 'scriptw-speed', 'v8']
    assert policy['blocks'] == 2 and policy['processes_per_actor_per_block'] == 4
    assert policy['samples'] == 21 and policy['warmups'] == 100
    identity = report['source_identity']
    assert identity['source_commit'] == candidate_identity['source_commit']
    assert identity['source_fingerprint'] == candidate_identity['source_fingerprint']
    assert report['tools']['host']['sha256']
    historical = read(historical_path)
    old = historical.get('historical_width_identity', {})
    archive = old.get('evidence_archive', historical.get('evidence_archive', {}))
    assert old.get('source_fingerprint', '').startswith('0ca455c')
    assert isinstance(archive.get('sha256'), str) and len(archive['sha256']) == 64
    compact = {key: copy.deepcopy(value) for key, value in report.items()
               if key not in {'rows', 'commands', 'retained_files'}}
    compact.pop('evidence_archive', None)
    compact.pop('complete_archived_report', None)
    compact['historical_width_identity'] = copy.deepcopy(old)
    compact['publication'] = {
        'status': 'staged-ready-for-review',
        'full_report': {'archive_member': 'situations/full-report.json', 'sha256': sha(path)},
        'consumer_processes': len(cases) * 3 * 8,
        'checked_invocations': len(cases) * 3 * 8 * (policy['samples'] + policy['warmups']),
        'source_manifest_sha256': measured_manifest_sha256,
        'canonical_files_written': False,
    }
    return compact, None, Path(path)



def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--campaign', type=Path, required=True)
    parser.add_argument('--aggregate', type=Path, required=True)
    parser.add_argument('--source-manifest', type=Path, required=True,
                        help='single frozen source snapshot for the measured build')
    parser.add_argument('--producer-source-manifest', type=Path,
                        default=BASE / 'tools/source-final/manifest.json',
                        help='original measured build and pre-correction test witness snapshot')
    parser.add_argument('--verification-source-manifest', type=Path,
                        default=BASE / 'tools/source-finished/manifest.json',
                        help='final corrected external-test witness snapshot; not a replacement producer')
    parser.add_argument('--intermediate-source-manifest', type=Path, action='append', default=[],
                        help='additional premeasurement test-correction snapshot; saved defaults include all existing intermediates')
    parser.add_argument('--postmeasurement-verification-manifest', type=Path,
                        help='later verification-only snapshot; never replaces the measured campaign source')
    parser.add_argument('--postmeasurement-qualification', type=Path,
                        help='separate retained_operands-only source/build/rerun qualification')
    parser.add_argument('--test-only-qualification', type=Path, action='append', default=[],
                        help='receipt qualifying the corrected test-only witness; retained explicitly')
    parser.add_argument('--architecture-diagnostics', type=Path, action='append', default=[],
                        help='optional unscored diagnostic text, separate from current attribution')
    parser.add_argument('--situations-report', type=Path, required=True,
                        help='official raw full-21 situations report')
    parser.add_argument('--historical-situations', type=Path,
                        default=ROOT / 'docs/rust-rewrite/situations-current.json')
    parser.add_argument('--evidence', type=Path, action='append', default=[],
                        help='actual verification receipt/log text; repeat as needed')
    parser.add_argument('--output-dir', type=Path, required=True,
                        help='new isolated directory under target')
    parser.add_argument('--archive-name', default='scriptw-performance-architecture-evidence-2026-11-08.tar.xz')
    args = parser.parse_args()

    output = args.output_dir.resolve()
    assert output.is_relative_to(ROOT / 'target') and not output.exists()
    campaign_path = args.campaign.resolve(strict=True)
    aggregate_path = args.aggregate.resolve(strict=True)
    manifest_path = args.source_manifest.resolve(strict=True)
    situations_path = args.situations_report.resolve(strict=True)
    rsc, campaign, aggregate = make_rsc_report(campaign_path, aggregate_path, manifest_path)
    situations, _, situations_full_path = compact_situations(
        situations_path, aggregate['engines']['candidate']['identity'],
        args.historical_situations.resolve(strict=True), sha(manifest_path))

    chart_module = load_module('scriptw_rsc_renderer', RSC_RENDERER)
    with tempfile.TemporaryDirectory(prefix='rsc-v2-', dir=BASE) as temporary_dir:
        temporary = Path(temporary_dir) / 'report.json'
        temporary.write_bytes(encoded(rsc))
        chart_module.rsc_report(temporary)

    output.mkdir(parents=True)
    (output / 'reports').mkdir()
    (output / 'reports/rsc-current.json').write_bytes(encoded(rsc))
    (output / 'reports/situations-current.json').write_bytes(encoded(situations))

    archiver = load_module('scriptw_inert_archive', ARCHIVER)
    archive = archiver.Archive()
    add_source_snapshot(archive, manifest_path)
    common = load_module('architecture_archive_source', BASE / 'tools/common.py')
    producer_manifest = args.producer_source_manifest.resolve(strict=True)
    verification_manifest = args.verification_source_manifest.resolve(strict=True)
    intermediate_manifests = [BASE / 'tools' / name / 'manifest.json' for name in
                              ('source-verified', 'source-qualified', 'source-correct', 'source-accepted')]
    intermediate_manifests.extend(args.intermediate_source_manifest)
    intermediate_manifests = list(dict.fromkeys(path.resolve(strict=True) for path in intermediate_manifests))
    for source, prefix in ((producer_manifest, 'source/original-producer-pretest'),
                           (verification_manifest, 'source/corrected-test-verification')):
        common.validate_snapshot(source)
        add_source_snapshot(archive, source, prefix)
    for index, source in enumerate(intermediate_manifests):
        common.validate_snapshot(source)
        add_source_snapshot(archive, source, f'source/intermediate-{index:02}-{source.parent.name}')
    source_witnesses = {
        'measured': {'path': str(manifest_path.relative_to(ROOT)), 'sha256': sha(manifest_path),
                     'archive_prefix': 'source/current/'},
        'original_producer_pretest': {'path': str(producer_manifest.relative_to(ROOT)),
                     'sha256': sha(producer_manifest), 'archive_prefix': 'source/original-producer-pretest/'},
        'intermediate_test_verification': [
            {'path': str(source.relative_to(ROOT)), 'sha256': sha(source),
             'archive_prefix': f'source/intermediate-{index:02}-{source.parent.name}/'}
            for index, source in enumerate(intermediate_manifests)],
        'corrected_test_verification': {'path': str(verification_manifest.relative_to(ROOT)),
                     'sha256': sha(verification_manifest), 'archive_prefix': 'source/corrected-test-verification/'},
    }
    original = read(producer_manifest)
    corrected = read(verification_manifest)
    changed = sorted(name for name in set(original['files']) | set(corrected['files'])
                     if original['files'].get(name) != corrected['files'].get(name))
    allowed_tests = ['crates/scriptw-aot-wasm/tests/emission/infallible_booleans.rs',
                     'crates/scriptw-aot-wasm/tests/emission/parameter_initialization.rs']
    assert changed == allowed_tests, (
        'producer reuse is limited to the two separately corrected external emission witnesses', changed)
    assert sha(verification_manifest) == sha(manifest_path), 'premeasurement verification is the measured campaign snapshot'
    for source in intermediate_manifests:
        intermediate = read(source)
        assert set(original['files']) == set(intermediate['files'])
        intermediate_changed = {name for name in original['files']
                                if original['files'][name] != intermediate['files'][name]}
        assert intermediate_changed and intermediate_changed <= set(allowed_tests), (
            'an intermediate correction changed product inputs', source, intermediate_changed)
        assert original['deleted_files'] == intermediate['deleted_files']
    assert original['deleted_files'] == corrected['deleted_files']
    assert bool(args.postmeasurement_verification_manifest) == bool(args.postmeasurement_qualification)
    postmeasurement_qualification = None
    if args.postmeasurement_verification_manifest:
        later_path = args.postmeasurement_verification_manifest.resolve(strict=True)
        later = common.validate_snapshot(later_path)
        retained = 'crates/scriptw-aot-wasm/tests/emission/retained_operands.rs'
        assert set(later['files']) - set(corrected['files']) == {retained}
        assert not set(corrected['files']) - set(later['files'])
        assert later['tracked_files'] == sorted(set(corrected['tracked_files']) | {retained})
        assert later['untracked_files'] == corrected['untracked_files']
        assert later['deleted_files'] == corrected['deleted_files']
        assert later['base_git'] == corrected['base_git']
        assert later['files'][retained]['origin'] == 'tracked'
        assert all(later['files'][name] == corrected['files'][name] for name in corrected['files'])
        previous_retained = subprocess.check_output(
            ['git', 'show', f"{corrected['base_git']}:{retained}"], cwd=ROOT)
        previous_retained_sha256 = hashlib.sha256(previous_retained).hexdigest()
        assert previous_retained_sha256 != later['files'][retained]['sha256']
        proof_path = require_text_file(args.postmeasurement_qualification)
        proof = read(proof_path)
        assert proof['schema'] == 'scriptw-postmeasurement-external-test-correction-v1'
        assert proof['measured_source']['sha256'] == sha(manifest_path)
        assert proof['verification_source']['sha256'] == sha(later_path)
        assert proof['measurement']['campaign_sha256'] == sha(campaign_path)
        assert proof['measurement']['aggregate_sha256'] == sha(aggregate_path)
        assert proof['newly_listed_tracked_file'] == {
            'path': retained, 'base_git': corrected['base_git'],
            'before_sha256': previous_retained_sha256,
            'after_sha256': later['files'][retained]['sha256'],
            'previous_bytes_role': 'unchanged tracked file omitted from measured dirty snapshot; read from pinned base commit'}
        assert proof['corrected_emission_rerun'] is not None, 'final publication requires the actual complete 79-test rerun'
        archive.add_bytes('source/postmeasurement-before/retained_operands.rs', previous_retained)
        add_source_snapshot(archive, later_path, 'source/postmeasurement-verification')
        archive.add_file('verification/postmeasurement-test-qualification.json', proof_path)
        source_witnesses['postmeasurement_verification'] = {
            'path': str(later_path.relative_to(ROOT)), 'sha256': sha(later_path),
            'archive_prefix': 'source/postmeasurement-verification/'}
        postmeasurement_qualification = {'path': str(proof_path.relative_to(ROOT)),
            'sha256': sha(proof_path), 'archive_member': 'verification/postmeasurement-test-qualification.json'}
    assert args.test_only_qualification, 'archive the corrected-witness qualification receipt explicitly'
    build = read(BASE / 'build-receipt.json')
    assert build['complete'] is True and build['exit_code'] == 0
    assert build['source_manifest_sha256'] == sha(producer_manifest)
    producer = campaign['candidate']['compiler_source_identity']
    assert build['compiler_source_identity'] == [producer['source_fingerprint'], producer['source_revision']]
    assert sha(BASE / 'build.stdout') == build['stdout_sha256']
    assert sha(BASE / 'build.stderr') == build['stderr_sha256']
    qualifications = []
    for index, source in enumerate(args.test_only_qualification):
        source = require_text_file(source)
        member = f'verification/test-only-qualification-{index:02}-{source.name}'
        archive.add_file(member, source)
        qualifications.append({'path': str(source.relative_to(ROOT)), 'sha256': sha(source),
                               'archive_member': member})
    # These are original producer/build observations, not corrected-test reruns.
    for name in ('build-argv.json', 'build-receipt.json', 'build.stdout', 'build.stderr',
                 'build-driver.stdout', 'build-driver.stderr'):
        source = BASE / name
        if source.is_file():
            archive.add_file('original-build/' + name, require_text_file(source))
    add_evidence_tree(archive, BASE / 'frozen', 'original-build/frozen-producers')
    for value in (rsc, situations):
        value['source_witnesses'] = source_witnesses
        value['test_only_qualifications'] = qualifications
        value['postmeasurement_test_qualification'] = postmeasurement_qualification
    # Refresh the prearchive reports after adding their explicit witness bounds.
    for name, value in (('rsc-current.json', rsc), ('situations-current.json', situations)):
        (output / 'reports' / name).write_bytes(encoded(value))
    add_rsc_campaign(archive, campaign_path, aggregate_path)
    archive.add_file('reports/rsc-current-prearchive.json', output / 'reports/rsc-current.json')
    archive.add_file('reports/situations-current-prearchive.json', output / 'reports/situations-current.json')
    archive.add_file('situations/full-report.json', situations_full_path)
    archive.add_file('inputs/baseline-public-report.json', manifest_path.parent / 'baseline/rsc-current.json')
    archive.add_file('tools/stage_publication.py', Path(__file__).resolve())
    archive.add_file('tools/stage_docs.py', Path(__file__).with_name('stage_docs.py').resolve())
    archive.add_file('tools/stage_after_acceptance.py', Path(__file__).with_name('stage_after_acceptance.py').resolve())
    archive.add_file('tools/qualify_verification_correction.py', Path(__file__).with_name('qualify_verification_correction.py').resolve())
    archive.add_file('tools/qualify_test_correction.py', BASE / 'tools/qualify_test_correction.py')
    archive.add_file('tools/common.py', BASE / 'tools/common.py')
    archive.add_file('tools/freeze_source.py', BASE / 'tools/freeze_source.py')
    archive.add_file('tools/measure_rsc.py', BASE / 'tools/measure_rsc.py')
    archive.add_file('tools/benchmark-situations.py', ROOT / 'scripts/benchmark-situations.py')
    archive.add_file('tools/benchmark_metrics.py', ROOT / 'scripts/benchmark_metrics.py')
    archive.add_file('tools/limited_verification.py', ROOT / 'scripts/limited_verification.py')
    archive.add_file('tools/archive_final.py', ARCHIVER)
    archive.add_file('tools/render-application-benchmarks.py', RSC_RENDERER)
    archive.add_file('tools/render-situation-benchmarks.py', SITUATION_RENDERER)
    # No old profile or source attribution is promoted as current evidence.
    # Architecture diagnostics are optional and explicitly unscored.
    for index, path in enumerate(args.architecture_diagnostics):
        path = path.resolve(strict=True)
        if path.is_dir():
            add_evidence_tree(archive, path, f'unscored-architecture/{index:02}-{path.name}')
        else:
            archive.add_file(f'unscored-architecture/{index:02}-{path.name}', require_text_file(path))
    for index, path in enumerate(args.evidence):
        path = path.resolve(strict=True)
        if path.is_dir():
            add_evidence_tree(archive, path, f'verification/{index:02}-{path.name}')
        else:
            archive.add_file(f'verification/{index:02}-{path.name}/{require_text_file(path).name}', path)
    counts = rsc['measurement']
    archive.add_bytes('README.txt', (
        'Scriptw architecture performance evidence. All archive members are inert UTF-8 text with a SHA-256 index. '
        'Executables, Wasm/native payloads, perf.data, and other binary artifacts are excluded. '
        f"The full RSC campaign contains {counts['execution_processes']} processes and "
        f"{counts['checked_flight_calls']} exact-checked Flight calls. "
        'The canonical chart inventory remains prior-source Fast, current Fast, current Speed and V8; '
        'optional prior-source Speed is stored separately as baseline_speed_control and in the raw campaign. '
        'The full 21-workload situation report contains 504 processes and 60,984 checked invocations. '
        'The baseline is source0c2c under its original source/runtime identity; current architecture source is based on b8c. '
        'Measured source-finished, original-producer/pretest, intermediate-test and postmeasurement verification snapshots are labeled separately. '
        'Initial build receipts and frozen producer witnesses are retained; test-only correction qualifications are explicit. '
        'Architecture diagnostics are unscored and never current source-profile attribution. '
        'Full Test262 and universal performance claims are not implied.\n'
    ).encode())
    archive_path = output / args.archive_name
    raw_archive_meta = archive.write(archive_path)
    archive_meta = {key: value for key, value in raw_archive_meta.items() if key != 'file'}
    archive_meta.update({'file': args.archive_name,
                         'canonical_file': 'docs/rust-rewrite/' + args.archive_name,
                         'staged_file': str(archive_path.relative_to(ROOT))})
    import tarfile
    with tarfile.open(archive_path, 'r:xz') as packed:
        index = json.load(packed.extractfile('INDEX.json'))
    member_hashes = {item['path']: item['sha256'] for item in index['members']}

    reports = {'rsc-current.json': rsc, 'situations-current.json': situations}
    for name, value in reports.items():
        value['evidence_archive'] = archive_meta
        value.setdefault('publication', {})['evidence_archive'] = archive_meta
        member = 'reports/' + name.removesuffix('.json') + '-prearchive.json'
        value['complete_archived_report'] = {'archive_member': member,
                                             'sha256': member_hashes[member]}
        value['staging'] = {'status': 'ready-for-review', 'canonical_files_written': False,
                            'evidence_archive_created': True, 'charts_rendered': False}
        (output / 'reports' / name).write_bytes(encoded(value))

    ready = {
        'schema': 'scriptw-performance-architecture-publication-stage-v1',
        'complete': True, 'canonical_files_written': False, 'charts_rendered': False,
        'source_manifest': {'path': str(manifest_path.relative_to(ROOT)), 'sha256': sha(manifest_path),
                            'base_git': read(manifest_path)['base_git'],
                            'runtime_abi': read(manifest_path)['runtime_abi']},
        'campaign_sha256': sha(campaign_path), 'aggregate_sha256': sha(aggregate_path),
        'reports': {name: sha(output / 'reports' / name) for name in reports},
        'situation_report_sha256': sha(situations_path), 'evidence_archive': archive_meta,
        'evidence_members': len(member_hashes), 'source_witnesses': source_witnesses,
        'test_only_qualifications': qualifications,
        'postmeasurement_test_qualification': postmeasurement_qualification,
        'limits': 'Staged only; source0c2c prior-source controls remain distinct from the current b8c-based architecture build.',
    }
    (output / 'publication-ready.json').write_bytes(encoded(ready))
    print(output / 'publication-ready.json')


if __name__ == '__main__':
    main()
