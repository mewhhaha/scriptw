#!/usr/bin/env python3
"""Validate current architecture reports and stage review-only charts under target.

README and benchmark prose are owned by the publication reviewer. This helper
never rewrites tracked documents or promotes historical profiling attribution.
"""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT / 'target/performance-architecture-20261108'
sys.path.insert(0, str(ROOT / 'scripts'))


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--rsc-report', type=Path, required=True)
    parser.add_argument('--situations-report', type=Path, required=True)
    parser.add_argument('--output-dir', type=Path, required=True)
    args = parser.parse_args()
    output = args.output_dir.resolve()
    assert output.is_relative_to(ROOT / 'target') and not output.exists()
    rsc_path = args.rsc_report.resolve(strict=True)
    situation_path = args.situations_report.resolve(strict=True)
    rsc_renderer = load_module('architecture_rsc_renderer', ROOT / 'scripts/render-application-benchmarks.py')
    situation_renderer = load_module('architecture_situation_renderer', ROOT / 'scripts/render-situation-benchmarks.py')
    rsc = rsc_renderer.rsc_report(rsc_path)
    situations = read(situation_path)
    cases = situation_renderer.validate(situations)
    assert situations['status'] == 'complete' and len(cases) == 21
    actors = rsc['measurement']['actors']
    assert actors in (['baseline', 'candidate', 'candidate-speed', 'v8'],
                      ['baseline', 'baseline-speed', 'candidate', 'candidate-speed', 'v8'])
    assert rsc['measurement']['execution_processes'] == len(actors) * 8
    assert rsc['measurement']['checked_flight_calls'] == len(actors) * 8 * 2 * 10
    assert ('baseline_speed_control' in rsc) == ('baseline-speed' in actors)
    assert set(rsc['engines']) == {'baseline', 'candidate', 'candidate-speed', 'v8'}
    identity = rsc['engines']['candidate']['identity']
    for key in ('source_fingerprint', 'source_commit'):
        assert situations['source_identity'][key] == identity[key]
    outputs = {
        output / 'assets/rsc-current/runtime.svg': rsc_renderer.rsc_runtime_chart(
            rsc, output / 'previews/rsc-runtime.png'),
        output / 'assets/rsc-current/compilation.svg': rsc_renderer.rsc_compile_chart(
            rsc, output / 'previews/rsc-compilation.png'),
    }
    situation_sha = sha(situation_path)
    for category, title, ylabel, _ in situation_renderer.CATEGORIES:
        stem = category.replace(' ', '-')
        outputs[output / 'assets/situations-current' / (stem + '.svg')] = situation_renderer.runtime_chart(
            situations, situation_sha, cases, category, title, ylabel,
            output / 'previews/situations' / (stem + '.png'))
    outputs[output / 'assets/situations-current/frame-native-image.svg'] = situation_renderer.frame_image_chart(
        situations, situation_sha, output / 'previews/situations/frame-native-image.png')
    for path, value in outputs.items():
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(value)
    receipt = {
        'schema': 'scriptw-architecture-review-charts-v1', 'complete': True,
        'canonical_files_written': False, 'tracked_prose_written': False,
        'rsc_report_sha256': sha(rsc_path), 'situations_report_sha256': situation_sha,
        'chart_actors': ['current Fast', 'current Speed', 'V8'],
        'full_campaign_processes': rsc['measurement']['execution_processes'],
        'full_campaign_checked_flight_calls': rsc['measurement']['checked_flight_calls'],
        'files': {str(path.relative_to(output)): sha(path) for path in outputs},
        'limits': 'Review artifacts only. Historical profiling attribution is not current-source evidence.',
    }
    (output / 'charts-ready.json').write_text(json.dumps(receipt, indent=2, allow_nan=False) + '\n')
    print(output / 'charts-ready.json')


if __name__ == '__main__':
    main()
