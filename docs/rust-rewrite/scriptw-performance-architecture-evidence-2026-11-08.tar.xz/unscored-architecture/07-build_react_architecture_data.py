#!/usr/bin/env python3
"""Build a hash-bound, ignored proposal from completed architecture evidence."""
from pathlib import Path
import hashlib
import json
import statistics

ROOT=Path(__file__).resolve().parents[3]
BASE=ROOT/'target/performance-architecture-20261108'
TOOLS=BASE/'tools'
OUT=BASE/'react-architecture-current.json'
CURRENT_FP='453a9074fcacb06fb5fc010a47eb443e4c1aa804e32afbd23e6e4e43d985610c'
BASELINE_FP='0c2c10dac9c03a8c8b22c500f175ee190e97131e7d591f33760f1bafa602596b'

def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
    return h.hexdigest()

def read(path):return json.loads(Path(path).read_text())
def rel(path):return str(Path(path).resolve().relative_to(ROOT))
def pin(path):return {'path':rel(path),'sha256':sha(path)}

def process_pins(campaign,folder):
    rows=campaign['processes'];out=[]
    for row in rows:
        assert row['status']=='complete',row
        report=(Path(folder)/row['report']).resolve(strict=True)
        assert sha(report)==row['report_sha256'],row['label']
        out.append({'label':row.get('label',row.get('actor')),'report':rel(report),'sha256':row['report_sha256']})
    return out

def capture(mode,directory,source_fp,host_sha,wasm_sha):
    folder=BASE/directory;receipt_path=folder/'receipt.json';receipt=read(receipt_path)
    assert receipt['complete'] is True and receipt['unscored'] is True
    assert receipt['source_fingerprint']==source_fp and receipt['host_sha256']==host_sha
    assert receipt['mode']==mode
    report_path=Path(receipt['argv'][3]).resolve(strict=True);report=read(report_path)
    assert report['status']=='complete' and report['native_mode']==mode
    assert report['executable_sha256']==host_sha and report['program_wasm_sha256']==wasm_sha
    program=folder/'program.wasm';assert sha(program)==wasm_sha
    functions={row['name']:{'perfmap_extent_bytes':row['bytes'],'native_bytes':{'path':rel(folder/row['path']),'sha256':row['sha256']}}
               for row in receipt['functions']}
    maps_path=folder/'maps.txt';perf_path=folder/'perf.map'
    return {'receipt':pin(receipt_path),'report':pin(report_path),'mode':mode,
            'source_fingerprint':source_fp,'host_sha256':host_sha,'program_wasm_sha256':wasm_sha,
            'program_wasm_bytes':report['program_wasm_bytes'],
            'program_wasm':pin(program),'functions':functions,
            'maps_before_sha256':receipt.get('maps_before_sha256'),
            'maps_after_sha256':receipt.get('maps_after_sha256'),
            'maps_file':pin(maps_path) if maps_path.is_file() else None,
            'perf_map_sha256':receipt.get('perf_map_sha256'),
            'perf_map':pin(perf_path) if perf_path.is_file() else None}

def main():
    source_path=TOOLS/'source-finished/manifest.json';source=read(source_path)
    assert source['base_git']=='b8c7325438c48028866fc85a74f2115acd465731'
    source_hash=sha(source_path)
    current_host=BASE/'frozen/rsc_baseline';current_host_sha=sha(current_host)
    current_wasm='fef58c9a24bc24e438153a9d0936071e6a6947c86e09ad10dd1db6cc56aeba3f'
    baseline_host=ROOT/'target/performance-predicate-transport-20261108/frozen/rsc_baseline'
    baseline_host_sha=sha(baseline_host)
    assert source['baseline_identity']['source_fingerprint']==BASELINE_FP

    rsc_campaign_path=TOOLS/'rsc-campaign-1/campaign.json';rsc_campaign=read(rsc_campaign_path)
    rsc_aggregate_path=TOOLS/'rsc-campaign-1/aggregate.json';rsc=read(rsc_aggregate_path)
    assert rsc_campaign['status']=='complete' and len(rsc_campaign['processes'])==40
    assert rsc_campaign['policy']['checked_flight_calls']==800
    assert rsc_campaign['source_manifest_sha256']==source_hash and rsc['source_manifest_sha256']==source_hash
    assert rsc['measurement']['campaign_sha256']==sha(rsc_campaign_path)
    assert rsc['engines']['candidate']['identity']['source_fingerprint']==CURRENT_FP
    assert rsc['engines']['candidate-speed']['identity']['source_fingerprint']==CURRENT_FP
    assert rsc['engines']['baseline']['identity']['source_fingerprint']==BASELINE_FP
    assert rsc['engines']['baseline-speed']['identity']['source_fingerprint']==BASELINE_FP
    assert rsc['engines']['candidate']['identity']['executable_sha256']==current_host_sha
    assert rsc['engines']['baseline']['identity']['executable_sha256']==baseline_host_sha
    rsc_reports=process_pins(rsc_campaign,rsc_campaign_path.parent)
    actor_identity={'baseline':(BASELINE_FP,baseline_host_sha,'fast'),
                    'baseline-speed':(BASELINE_FP,baseline_host_sha,'speed'),
                    'candidate':(CURRENT_FP,current_host_sha,'fast'),
                    'candidate-speed':(CURRENT_FP,current_host_sha,'speed')}
    for row in rsc_campaign['processes']:
        if row['actor']=='v8':continue
        raw=read(rsc_campaign_path.parent/row['report']);fp,host,mode=actor_identity[row['actor']]
        assert raw['status']=='complete' and raw['source_fingerprint']==fp
        assert raw['executable_sha256']==host and raw['native_mode']==mode
        assert raw['program_wasm_sha256']==(current_wasm if row['actor'].startswith('candidate') else '8d69007a874b606b13d1e840b72c7f75b56fa8875c853e86d7efa47f422e637e')
        assert all(case['exact_node_output_checked'] is True for case in raw['cases'])
    score_engines={name:{'identity':rsc['engines'][name]['identity'],
                         'block_medians_ns':rsc['engines'][name]['block_medians'],
                         'process_medians_ns':rsc['engines'][name]['cases']}
                   for name in ('baseline','baseline-speed','candidate','candidate-speed','v8')}

    policy_path=TOOLS/'native-policy-2x2/campaign.json';policy=read(policy_path)
    assert policy['status']=='complete' and len(policy['processes'])==24
    assert policy['policy']['samples']==7 and policy['policy']['warmups']==3
    assert policy['candidate']['source_fingerprint']==CURRENT_FP
    assert policy['candidate']['sha256']==current_host_sha
    policy_reports=process_pins(policy,policy_path.parent)
    for row in policy['processes']:
        raw=read(policy_path.parent/row['report'])
        assert raw['status']=='complete' and raw['native_mode']==row['mode']
        assert raw['source_fingerprint']==CURRENT_FP and raw['executable_sha256']==current_host_sha
        assert raw['program_wasm_sha256']==current_wasm and raw['configuration']==row['configuration']
        assert all(case['exact_node_output_checked'] is True for case in raw['cases'])
        assert {case['case']:case['median_ns'] for case in raw['cases']}==row['median_ns']
    policy_medians={mode:[{'block':row['block'],'repetition':row['repetition'],'cases':row['median_ns'],
                           'report_sha256':row['report_sha256']}
                          for row in policy['processes'] if row['mode']==mode]
                    for mode in ('fast','fast-backtracking','speed','speed-single-pass')}
    assert all(len(rows)==6 for rows in policy_medians.values())

    current_capture_specs=[('fast','capture-final-fast-retry'),('fast-backtracking','capture-final-fast-backtracking'),
                           ('speed','capture-final-speed'),('speed-single-pass','capture-final-speed-single-pass')]
    current_captures={mode:capture(mode,directory,CURRENT_FP,current_host_sha,current_wasm)
                      for mode,directory in current_capture_specs}
    baseline_fast=capture('fast','capture-fast',BASELINE_FP,baseline_host_sha,'8d69007a874b606b13d1e840b72c7f75b56fa8875c853e86d7efa47f422e637e')
    baseline_speed=capture('speed','capture-speed',BASELINE_FP,baseline_host_sha,'8d69007a874b606b13d1e840b72c7f75b56fa8875c853e86d7efa47f422e637e')

    current_stack={
      'fast':{'vn':{'frame_bytes':213856,'probe_kind':'page-probe','probe_count':53},'ft':{'frame_bytes':85664,'probe_kind':'page-probe','probe_count':21}},
      'fast-backtracking':{'vn':{'frame_bytes':8736,'probe_kind':'unrolled-probe-store','probe_count':2},'ft':{'frame_bytes':2736,'probe_kind':'unrolled-probe-store','probe_count':0}},
      'speed':{'vn':{'frame_bytes':6656,'probe_kind':'unrolled-probe-store','probe_count':1},'ft':{'frame_bytes':2480,'probe_kind':'unrolled-probe-store','probe_count':0}},
      'speed-single-pass':{'vn':{'frame_bytes':171712,'probe_kind':'loop-probe','probe_count':42},'ft':{'frame_bytes':68976,'probe_kind':'loop-probe','probe_count':17}},
    }
    baseline_stack={'fast':{'vn':{'frame_bytes':244848,'probe_kind':'page-probe','probe_count':60},
                            'ft':{'frame_bytes':94032,'probe_kind':'page-probe','probe_count':23}},
                    'speed':{'vn':{'frame_bytes':3744,'probe_kind':'unrolled-probe-store','probe_count':0},
                             'ft':{'frame_bytes':2320,'probe_kind':'unrolled-probe-store','probe_count':0}}}
    for mode,values in current_stack.items():
        current_captures[mode]['native_stack_frame_analysis']=values
        current_captures[mode]['native_stack_frame_analysis_source']='Manual disassembly of the exact captured native bytes; distinct from perf-map function extents.'
    baseline_fast['native_stack_frame_analysis']=baseline_stack['fast']
    baseline_speed['native_stack_frame_analysis']=baseline_stack['speed']
    baseline_fast['native_stack_frame_analysis_source']='Manual disassembly of the historical 0c2c capture bytes; not current-source evidence.'
    baseline_speed['native_stack_frame_analysis_source']='Manual disassembly of the historical 0c2c capture bytes; not current-source evidence.'
    mode_source=ROOT/'crates/scriptw-cli/examples/rsc_baseline.rs'
    mode_configuration={
      'source':pin(mode_source),
      'modes':{
        'fast':{'cranelift_opt_level':'None','register_allocation':'SinglePass'},
        'fast-backtracking':{'cranelift_opt_level':'None','register_allocation':'Backtracking'},
        'speed':{'cranelift_opt_level':'Speed','register_allocation':'Backtracking'},
        'speed-single-pass':{'cranelift_opt_level':'Speed','register_allocation':'SinglePass'},
      },
      'interpretation':'Fast vs FastBacktracking and Speed vs SpeedSinglePass hold optimization level fixed and vary register allocation. The measured stack-frame changes align with the allocator choice; they do not establish that frame size caused RSC timing changes.'
    }

    static_current_path=BASE/'astra/source-expansion-counts-final-fast.json';static_current=read(static_current_path)
    static_base_path=BASE/'astra/source-expansion-counts.json';static_base=read(static_base_path)
    assert static_current['source_fingerprint']==CURRENT_FP and static_current['program_sha256']==current_wasm
    assert static_base['program_sha256']=='8d69007a874b606b13d1e840b72c7f75b56fa8875c853e86d7efa47f422e637e'

    cache={}
    for mode in ('sync','async'):
        folder=BASE/f'cache-census/{mode}-6';receipt_path=folder/'receipt.json';receipt=read(receipt_path)
        assert receipt['complete'] is True and receipt['mode']==mode
        assert receipt['source_fingerprint']==BASELINE_FP and receipt['binary_sha256']==baseline_host_sha
        assert receipt['program_wasm_sha256']==baseline_fast['program_wasm_sha256']
        windows=receipt['windows'];assert len(windows)==7 and windows[0]['index']==3
        vectors={target:[window['events'][i]['count'] for window in windows]
                 for i,target in enumerate(receipt['targets'])}
        assert all(len(set(v))==1 for v in vectors.values())
        parent=receipt['native_parents_before']['helper::object_read']
        sites=parent['direct_self_call_sites'];assert len(sites)==3
        assert [site['offset'] for site in sites]==[0x74fe,0x77e9,0xaa69]
        assert [site['counted'] for site in sites]==[True,True,False]
        raw=[]
        for name,item in receipt['raw_files'].items():
            raw_path=folder/name;assert sha(raw_path)==item['sha256']
            raw.append({'path':rel(raw_path),'sha256':item['sha256'],'bytes':item['bytes']})
        control_path=BASE/'cache-census/control-6/receipt.json'
        assert sha(control_path)==receipt['controls_receipt_sha256']
        cache[mode]={
          'receipt':pin(receipt_path),'source_fingerprint':receipt['source_fingerprint'],
          'baseline_host_sha256':receipt['binary_sha256'],'program_wasm_sha256':receipt['program_wasm_sha256'],
          'warmups':3,'sample_windows':7,'exact_flight_checks':receipt['exact_flight_checks'],
          'counts_per_window':vectors,'native_self_sites':[
             {'offset_hex':hex(site['offset']),'counted':site['counted'],'semantic_role':'unclassified'} for site in sites],
          'control_receipt':pin(control_path),'adaptation_sha256':receipt['adaptation_sha256'],
          'raw_files':raw,'limits':'Excluded breakpoint census. Entry/fallback counts do not prove cache hits; self-call sites have no prototype/proxy role or coverage claim.'
        }

    hist_summary_path=ROOT/'target/performance-predicate-transport-20261108/fresh-profiles/summary.json'
    hist_summary=read(hist_summary_path);assert hist_summary['source_fingerprint']==BASELINE_FP
    hist_diag_path=ROOT/'target/performance-predicate-transport-20261108/final-diagnostics/campaign.json'
    hist_diag=read(hist_diag_path);assert hist_diag['source_fingerprint']==BASELINE_FP

    proof_path=TOOLS/'external-test-reuse-finished.json';proof=read(proof_path)
    assert sha(proof_path)==policy['candidate']['qualified_reuse']['sha256']
    assert proof['current_source']['sha256']==source_hash
    assert len(proof['changed_source_files'])==2
    aggregate_score={'campaign':pin(rsc_campaign_path),'aggregate':pin(rsc_aggregate_path),
                     'measurement':rsc['measurement'],'source_fingerprint':CURRENT_FP,
                     'baseline_fingerprint':BASELINE_FP,'process_count':40,'checked_request_calls':800,
                     'samples_per_request':7,'warmups_per_process':3,'raw_process_reports':rsc_reports,
                     'engines':score_engines,
                     'scope':'Scored retained RSC request latency; source/host/Wasmtime policy pair is explicit per engine.'}
    native_diagnostics={'campaign':pin(policy_path),'process_count':24,'checked_request_calls':480,
                        'source_fingerprint':CURRENT_FP,'mode_medians_ns':policy_medians,
                        'raw_process_reports':policy_reports,'captures':current_captures,
                        'register_allocation_configuration':mode_configuration,
                        'scope':'Excluded native-policy and code-generation diagnostics; no timing score is promoted from captures.'}
    result={
      'schema':'scriptw-react-architecture-current-proposal-v1','status':'proposal','published':False,
      'date':'2026-11-08','source':{'base_git':source['base_git'],'source_fingerprint':CURRENT_FP,
        'runtime_abi':source['runtime_abi'],'manifest':pin(source_path),
        'qualified_external_test_correction':pin(proof_path),'host_sha256':current_host_sha,
        'host_producer':pin(BASE/'frozen/rsc_baseline-producer.json'),
        'compiler_source_identity':'Product host built from the preceding source snapshot; two external-test-only corrections are qualified separately.'},
      'scored_rsc':aggregate_score,
      'native_policy_diagnostics':native_diagnostics,
      'native_stack_frames':{'current':{mode:{'capture_receipt':current_captures[mode]['receipt'],
                                               'analysis_source':'Manual disassembly of exact current capture bytes.',**values}
                                         for mode,values in current_stack.items()},
                             'historical_baseline_0c2c':{
                               'fast':{'capture_receipt':baseline_fast['receipt'],
                                       'analysis_source':'Manual disassembly of exact historical 0c2c capture bytes.',**baseline_stack['fast']},
                               'speed':{'capture_receipt':baseline_speed['receipt'],
                                        'analysis_source':'Manual disassembly of exact historical 0c2c capture bytes.',**baseline_stack['speed']}},
                             'native_perfmap_extents_are_separate_from_stack_frame_bytes':True},
      'static_wasm':{'current_fast':{'report':pin(static_current_path),'source_fingerprint':CURRENT_FP,
                                     'program_sha256':static_current['program_sha256'],'program_bytes':static_current['program_bytes'],
                                     'functions':static_current['functions']},
                     'historical_baseline_0c2c':{'report':pin(static_base_path),
                                     'program_sha256':static_base['program_sha256'],'program_bytes':baseline_fast['program_wasm_bytes'],
                                     'functions':static_base['functions']}},
      'historical_cache_diagnostics_0c2c':cache,
      'historical_pmu_references_0c2c':{'source_fingerprint':BASELINE_FP,'optional_historical_only':True,
          'profile_summary':pin(hist_summary_path),'diagnostic_campaign':pin(hist_diag_path),
          'not_current_source_evidence':True},
      'limits':['No full unit suite, Test262, full CI, or four known AOT failure retest is claimed by this proposal.',
                'Cache census is from 0c2c and does not measure the current 453a source.',
                'Native stack-frame and perf-map extents are separate dimensions.',
                'PMU profiles are historical 0c2c-only references.'],
    }
    OUT.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    print(json.dumps({'proposal':rel(OUT),'sha256':sha(OUT),'source_fingerprint':CURRENT_FP,
                      'rsc_processes':len(rsc_reports),'policy_processes':len(policy_reports),
                      'capture_modes':list(current_captures),'cache_modes':list(cache)},indent=2))

if __name__=='__main__':main()
