#!/usr/bin/env python3
"""Excluded Linux x86-64 task-bound instruction-entry counts; no guest mutation."""
import argparse
import ctypes
import hashlib
import fcntl
import json
import os
from pathlib import Path
import platform
import re
import socket
import shutil
import struct
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'scripts'))
from limited_verification import kernel_group, limited_environment, require_kernel_budget
from request_profile_support import line, thread_record
from profile_thread import barrier_caller

ORIGINAL = ROOT / 'target/performance-v8-climb-20261104/entry-breakpoints-staged'
ADAPTATION = HERE / 'adaptation.json'
BASELINE_HOST = ROOT / 'target/performance-predicate-transport-20261108/frozen/rsc_baseline'
BASELINE_REPORT = ROOT / 'target/performance-predicate-transport-20261108/tools/rsc-campaign-1/block-0-rep-0-candidate/report.json'
CACHE_TARGETS = ('helperentry:cached', 'callsite:cached-fallback',
                 'callsite:object-self-0', 'callsite:object-self-1')
PARENTS = ('helper::cached_property_read', 'helper::object_read')
MAX_FUNCTION_BYTES = 2 * 1024 * 1024

CONTROLS = [('direct', [37, 0]), ('indirect', [17, 0]), ('recursive', [66, 0]),
            ('tail', [13, 13]), ('two_addresses', [24, 17]), ('zero', [0, 0]),
            ('disabled', [0, 0]), ('burst', [4096, 0])]


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def load(path):
    return json.loads(Path(path).read_text())


def save(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


class Breakpoint:
    def __init__(self, tid, address):
        # Pinned Linux perf_event_attr v1 (72 bytes), x86-64 syscall 298.
        # sample_period=0: count only; no mmap/ringbuffer/per-hit records.
        # disabled, pinned, exclude_kernel, exclude_hv; inherit/freq/sigtrap=0.
        flags = (1 << 0) | (1 << 2) | (1 << 5) | (1 << 6)
        self.attr = struct.pack('<IIQQQQQIIQQ', 5, 72, 0, 0, 0, 3, flags, 0, 4, address, ctypes.sizeof(ctypes.c_long))
        assert len(self.attr) == 72
        libc = ctypes.CDLL(None, use_errno=True)
        libc.syscall.restype = ctypes.c_long
        buffer = ctypes.create_string_buffer(self.attr)
        fd = libc.syscall(ctypes.c_long(298), ctypes.byref(buffer), ctypes.c_int(tid),
                          ctypes.c_int(-1), ctypes.c_int(-1), ctypes.c_ulong(8))
        if fd < 0:
            error = ctypes.get_errno()
            raise OSError(error, os.strerror(error), 'perf_event_open hardware execute breakpoint')
        self.fd = fd

    def read(self):
        raw = os.read(self.fd, 24)
        assert len(raw) == 24, 'unscheduled/error-state pinned breakpoint'
        return list(struct.unpack('<QQQ', raw))

    def start(self, enabled):
        fcntl.ioctl(self.fd, 0x2401, 0)  # DISABLE
        fcntl.ioctl(self.fd, 0x2403, 0)  # RESET count; times remain cumulative
        self.before = self.read()
        assert self.before[0] == 0
        if enabled:
            fcntl.ioctl(self.fd, 0x2400, 0)  # ENABLE

    def stop(self, enabled):
        fcntl.ioctl(self.fd, 0x2401, 0)
        after = self.read()
        elapsed = [after[index] - self.before[index] for index in range(3)]
        assert min(elapsed) >= 0
        count, active, running = elapsed
        assert active == running, 'multiplexed/unscheduled event; never scale counts'
        if enabled:
            assert running > 0, 'event never ran'
        else:
            assert elapsed == [0, 0, 0], 'disabled event changed'
        return {'count': count, 'time_enabled_ns': active, 'time_running_ns': running,
                'before': self.before, 'after': after}

    def close(self):
        os.close(self.fd)


def executable_mapping(pid, address):
    matches = []
    for raw in Path(f'/proc/{pid}/maps').read_text().splitlines():
        interval, permissions, *_ = raw.split()
        start, end = [int(value, 16) for value in interval.split('-')]
        if start <= address < end:
            assert 'x' in permissions, ('entry address is not executable', raw)
            matches.append(raw)
    assert len(matches) == 1
    return matches[0]


def prefix(pid, address):
    class IOVec(ctypes.Structure):
        _fields_ = [('base', ctypes.c_void_p), ('length', ctypes.c_size_t)]
    data = ctypes.create_string_buffer(32)
    local = IOVec(ctypes.cast(data, ctypes.c_void_p), len(data))
    remote = IOVec(address, len(data))
    libc = ctypes.CDLL(None, use_errno=True)
    libc.process_vm_readv.restype = ctypes.c_ssize_t
    count = libc.process_vm_readv(pid, ctypes.byref(local), 1, ctypes.byref(remote), 1, 0)
    assert count == len(data), ('cannot authenticate own child entry bytes', ctypes.get_errno())
    return bytes(data).hex()


def remote_bytes(pid, address, size):
    assert 0 < size < MAX_FUNCTION_BYTES, ('unexpectedly large native function', size)
    class IOVec(ctypes.Structure):
        _fields_ = [('base', ctypes.c_void_p), ('length', ctypes.c_size_t)]
    data = ctypes.create_string_buffer(size)
    local = IOVec(ctypes.cast(data, ctypes.c_void_p), size)
    remote = IOVec(address, size)
    libc = ctypes.CDLL(None, use_errno=True)
    libc.process_vm_readv.restype = ctypes.c_ssize_t
    count = libc.process_vm_readv(pid, ctypes.byref(local), 1, ctypes.byref(remote), 1, 0)
    assert count == size, ('cannot read complete JIT function bytes', address, size, count, ctypes.get_errno())
    return bytes(data)


def disassemble_function(pid, folder, phase, entry, objdump):
    address, size, name = entry['address'], entry['size'], entry['name']
    mapping = executable_mapping(pid, address)
    last_mapping = executable_mapping(pid, address + size - 1)
    assert mapping == last_mapping, ('function crosses executable mappings', name, mapping, last_mapping)
    code = remote_bytes(pid, address, size)
    stem = name.replace('::', '-').replace('#', '-')
    binary_path = folder / f'{stem}.{phase}.native'
    disassembly_path = folder / f'{stem}.{phase}.disasm'
    binary_path.write_bytes(code)
    command = [str(objdump), '-D', '--disassemble-zeroes', '-b', 'binary', '-m', 'i386:x86-64', '--insn-width=16',
               f'--adjust-vma={address:#x}', str(binary_path)]
    result = subprocess.run(command, cwd=ROOT, env=limited_environment(), stdin=subprocess.DEVNULL,
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=20)
    assert result.returncode == 0 and not result.stderr, (command, result.stderr.decode(errors='replace'))
    disassembly_path.write_bytes(result.stdout)
    instructions = []
    for raw in result.stdout.decode().splitlines():
        line_match = re.match(r'^\s*([0-9a-fA-F]+):\s*(.*)$', raw)
        if not line_match:
            continue
        tokens = line_match[2].split()
        byte_tokens = []
        while tokens and re.fullmatch(r'[0-9a-fA-F]{2}', tokens[0]):
            byte_tokens.append(tokens.pop(0))
        if not byte_tokens or not tokens:
            continue
        instructions.append({'address': int(line_match[1], 16), 'bytes': bytes.fromhex(''.join(byte_tokens)),
                             'mnemonic': tokens[0].lower(), 'operands': ' '.join(tokens[1:]), 'line': raw})
    assert instructions and instructions[0]['address'] == address
    linear_sweep_bytes = sum(len(item['bytes']) for item in instructions)
    assert linear_sweep_bytes == size, (
        'objdump linear sweep did not account for every bounded byte', name, size, linear_sweep_bytes)
    return {
        'name': name, 'base': address, 'size': size, 'mapping': mapping,
        'linear_sweep_bytes': linear_sweep_bytes,
        'disassembly_policy': 'objdump linear sweep; byte coverage includes native data and does not classify every byte as an instruction',
        'prefix_hex': prefix(pid, address), 'bytes_path': binary_path.name,
        'bytes_sha256': digest(binary_path), 'disassembly_path': disassembly_path.name,
        'disassembly_sha256': digest(disassembly_path),
        'normalized_disassembly_sha256': hashlib.sha256(re.sub(rb'^.*: +file format binary$', b'<native>: file format binary', result.stdout, flags=re.M)).hexdigest(),
    }, instructions


def direct_branch_target(instruction):
    data = instruction['bytes']
    mnemonic = instruction['mnemonic']
    if mnemonic.startswith('call') and len(data) == 5 and data[0] == 0xE8:
        return instruction['address'] + 5 + int.from_bytes(data[1:], 'little', signed=True)
    if mnemonic.startswith('jmp') and len(data) == 5 and data[0] == 0xE9:
        return instruction['address'] + 5 + int.from_bytes(data[1:], 'little', signed=True)
    if mnemonic.startswith('jmp') and len(data) == 2 and data[0] == 0xEB:
        return instruction['address'] + 2 + int.from_bytes(data[1:], 'little', signed=True)
    return None


def cache_path_entries(pid, folder, phase, started_ns, objdump):
    path = Path(f'/tmp/perf-{pid}.map')
    assert path.stat().st_mtime_ns >= started_ns, 'stale perf map'
    raw_map = path.read_bytes()
    (folder / f'perf-cache-{phase}.map').write_bytes(raw_map)
    entries = []
    for row in raw_map.decode().splitlines():
        address, size, name = row.split(maxsplit=2)
        entries.append({'address': int(address, 16), 'size': int(size, 16), 'name': name})

    parents, instructions = {}, {}
    for name in PARENTS:
        matches = [entry for entry in entries if entry['name'] == name or entry['name'].startswith(name + '.')
                   or entry['name'].startswith(name + ' ')]
        assert len(matches) == 1 and matches[0]['name'] == name, ('parent aliases/clones require a new plan', name, matches)
        entry = matches[0]
        assert entry['size'] > 0
        overlaps = [other for other in entries if other['address'] < entry['address'] + entry['size']
                    and entry['address'] < other['address'] + other['size']]
        assert overlaps == [entry], ('ambiguous parent perf map range', name, overlaps)
        parents[name], instructions[name] = disassemble_function(pid, folder, phase, entry, objdump)

    def exact_branches(parent_name, target_address):
        parent = parents[parent_name]
        branches = []
        for item in instructions[parent_name]:
            target = direct_branch_target(item)
            if target == target_address:
                branches.append(item | {'target': target})
        return sorted(branches, key=lambda item: item['address'])

    def callsite_record(parent_name, item, label):
        parent = parents[parent_name]
        offset = item['address'] - parent['base']
        return {'name': label, 'site_label': f'{parent_name}+0x{offset:x}',
                'parent': parent_name, 'parent_base': parent['base'],
                'parent_size': parent['size'], 'address': item['address'],
                'offset': offset, 'target': item['target'],
                'instruction_bytes_hex': item['bytes'].hex(), 'disassembly': item['line'],
                'mapping': executable_mapping(pid, item['address']),
                'prefix_hex': prefix(pid, item['address'])}

    cached = parents['helper::cached_property_read']
    object_read = parents['helper::object_read']
    cached_fallback = exact_branches(cached['name'], object_read['base'])
    object_self_calls = exact_branches(object_read['name'], object_read['base'])
    assert len(cached_fallback) == 1, ('cached_property_read must have one direct object_read fallback', cached_fallback)
    assert len(object_self_calls) == 3, ('object_read must have exactly three direct self-call sites', object_self_calls)
    self_call_records = []
    for index, item in enumerate(object_self_calls):
        record = callsite_record(object_read['name'], item, f'callsite:object-self-native-{index}')
        record['counted'] = index < 2
        record['counter_target'] = f'callsite:object-self-{index}' if index < 2 else None
        record['semantic_role'] = 'unclassified native call site'
        self_call_records.append(record)
    parents[object_read['name']]['direct_self_call_sites'] = self_call_records
    return [
        {'name': 'helperentry:cached', 'parent': cached['name'], 'parent_base': cached['base'],
         'parent_size': cached['size'], 'address': cached['base'], 'offset': 0,
         'target': cached['base'], 'mapping': cached['mapping'],
         'prefix_hex': cached['prefix_hex']},
        callsite_record(cached['name'], cached_fallback[0], 'callsite:cached-fallback'),
        callsite_record(object_read['name'], object_self_calls[0], 'callsite:object-self-0'),
        callsite_record(object_read['name'], object_self_calls[1], 'callsite:object-self-1'),
    ], parents, raw_map


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--mode', choices=['control', 'sync', 'async'], required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--binary', type=Path, required=True)
    parser.add_argument('--baseline-json', type=Path, required=True)
    parser.add_argument('--target', action='append', choices=CACHE_TARGETS, default=[])
    parser.add_argument('--controls-receipt', type=Path)
    parser.add_argument('--samples', type=int, default=7)
    return parser.parse_args()


def run(args):
    assert platform.system() == 'Linux' and platform.machine() == 'x86_64'
    require_kernel_budget(4 * 1024**3)
    assert len(os.sched_getaffinity(0)) == 1
    assert 1 <= args.samples <= 20
    controls = args.mode == 'control'
    if not controls:
        assert len(args.target) == len(CACHE_TARGETS) and set(args.target) == set(CACHE_TARGETS), (
            'cache path uses the fixed four-target plan', args.target)
    adaptation = load(ADAPTATION)
    assert digest(__file__) == adaptation['adapted_sha256']
    assert digest(ROOT / adaptation['original_driver_path']) == adaptation['original_driver_sha256']
    prior_adaptation = HERE / 'original-adaptation.json'
    assert digest(prior_adaptation) == adaptation['prior_adaptation_sha256']
    assert load(prior_adaptation)['adapted_sha256'] == adaptation['previous_adapter_sha256']
    assert adaptation['previous_adapter_sha256'] == adaptation['original_driver_sha256']
    assert digest(HERE / adaptation['patch_path']) == adaptation['patch_sha256']
    for name, expected in adaptation['original_files_sha256'].items():
        assert digest(ORIGINAL / name) == expected, name
    assert digest(HERE / 'profile_thread.py') == adaptation['protocol_helpers_sha256']['profile_thread.py']
    assert digest(HERE / 'request_profile_support.py') == adaptation['protocol_helpers_sha256']['request_profile_support.py']
    pins = load(ORIGINAL / 'prepared.json')
    control_producer = load(ORIGINAL / 'control-producer.json')
    assert control_producer['exit_code'] == 0
    assert control_producer['prepared_sha256'] == digest(ORIGINAL / 'prepared.json')
    assert control_producer['source_sha256'] == digest(ORIGINAL / 'controls.rs')
    assert control_producer['binary_sha256'] == digest(ORIGINAL / 'controls')
    for name in ('count_entries.py', 'controls.rs', 'build_controls.py'):
        assert pins['sha256'][str(ORIGINAL / name)] == digest(ORIGINAL / name)
    assert Path('/sys/bus/event_source/devices/breakpoint/type').read_text().strip() == '5'
    baseline_path = args.baseline_json.resolve(strict=True)
    baseline = load(baseline_path)
    executable = args.binary.resolve(strict=True)
    assert executable == BASELINE_HOST.resolve(strict=True)
    assert baseline_path == BASELINE_REPORT.resolve(strict=True)
    assert digest(executable) == adaptation['baseline_host_sha256']
    assert digest(baseline_path) == adaptation['baseline_report_sha256']
    assert baseline['schema'] == 'scriptw-react-retained-baseline-v1' and baseline['status'] == 'complete'
    assert baseline['native_mode'] == 'fast'
    assert baseline['program_wasm_sha256'] == adaptation['baseline_program_wasm_sha256']
    assert digest(executable) == baseline['executable_sha256']
    assert baseline['source_fingerprint'].startswith('0c2c10da')
    assert baseline['source_commit'] == 'dfefb3222737b067e1c98777161d95d42491df8f'
    objdump = Path(shutil.which('objdump')).resolve(strict=True)
    assert digest(objdump) == adaptation['objdump_sha256']
    objdump_version = subprocess.run([str(objdump), '--version'], stdout=subprocess.PIPE,
                                     stderr=subprocess.PIPE, timeout=10)
    assert objdump_version.returncode == 0
    assert hashlib.sha256(objdump_version.stdout).hexdigest() == adaptation['objdump_version_sha256']
    for name in ('source', 'support'):
        assert digest(baseline['inputs'][name]) == baseline['inputs'][name + '_sha256']
    if not controls:
        assert args.controls_receipt is not None, 'fresh controls receipt required'
        passed = load(args.controls_receipt)
        assert passed['status'] == 'complete' and passed['complete'] is True and passed['known_count_windows'] == 8
        assert passed['driver_sha256'] == digest(__file__)
        assert passed['kernel_release'] == platform.release()
        assert passed['kernel_boot_id'] == Path('/proc/sys/kernel/random/boot_id').read_text().strip()
        assert passed['control_binary_sha256'] == control_producer['binary_sha256']
        assert passed['control_producer_sha256'] == digest(ORIGINAL / 'control-producer.json')
        assert passed['execution_target'] == 'authenticated-caller-socket'
    folder = args.output.resolve()
    folder.mkdir(exist_ok=False)
    nonce = os.urandom(16).hex()
    parent, child_socket = socket.socketpair()
    control_fd, control_inode = child_socket.fileno(), os.fstat(child_socket.fileno()).st_ino
    env = limited_environment()
    assert not any(key.startswith('SCRIPTW_RSC_PROFILE_') for key in env)
    assert 'LD_PRELOAD' not in env and 'LD_AUDIT' not in env
    env.update(SCRIPTW_RSC_PROFILE_FD=str(child_socket.fileno()), SCRIPTW_RSC_PROFILE_NONCE=nonce)
    samples, warmups = args.samples, 3
    if controls:
        binary = ORIGINAL / 'controls'
        samples, warmups = len(CONTROLS), 0
        argv = [str(binary), str(folder / 'observations.json')]
    else:
        binary = executable
        env['SCRIPTW_RSC_PROFILE_MODE'] = args.mode
        argv = [str(binary), baseline['inputs']['source'], baseline['inputs']['support'],
                str(folder / 'observations.json'), str(samples), str(warmups), baseline['native_mode']]
    controls_receipt_sha256 = None
    if args.controls_receipt is not None:
        controls_receipt_sha256 = digest(args.controls_receipt)
    result = {'complete': False, 'status': 'incomplete', 'unscored': True, 'mode': args.mode,
              'driver_sha256': digest(__file__), 'prepared_sha256': digest(ORIGINAL / 'prepared.json'),
              'adaptation_sha256': digest(ADAPTATION), 'patch_sha256': digest(HERE / adaptation['patch_path']),
              'kernel_release': platform.release(), 'kernel_boot_id': Path('/proc/sys/kernel/random/boot_id').read_text().strip(),
              'control_producer_sha256': digest(ORIGINAL / 'control-producer.json'),
              'objdump_path': str(objdump), 'objdump_sha256': digest(objdump),
              'objdump_version_sha256': hashlib.sha256(objdump_version.stdout).hexdigest(),
              'cache_path_plan': list(CACHE_TARGETS) if not controls else [],
              'baseline_sha256': digest(baseline_path), 'targets': args.target,
              'controls_receipt_sha256': controls_receipt_sha256,
              'execution_target': 'authenticated-caller-socket',
              'thread_authenticator_sha256': digest(HERE / 'profile_thread.py'),
              'protocol_helpers_sha256': digest(HERE / 'request_profile_support.py'),
              'nonce': nonce, 'argv': argv,
              'binary_sha256': digest(binary), 'windows': [],
              'event': {'type': 5, 'bp_type': 4, 'bp_len': ctypes.sizeof(ctypes.c_long), 'sample_period': 0,
                        'pinned': True, 'inherit': False, 'user_only': True, 'cpu': -1},
              'limits': 'Only authenticated caller TID; no inherited threads. Control socket edges are within the window. Excluded counting experiment; #DB per entry perturbs execution. No timing, allocation or speedup claim. Cached-entry counts include ineligible, first, evicted, inherited, and early-exit paths; entry-minus-fallback is not a cache-hit count. The two object_read self sites are identified only by native offset, not prototype-versus-proxy role.',
              'environment': {name: Path(path).read_text().strip() for name, path in {
                  'perf_event_paranoid': '/proc/sys/kernel/perf_event_paranoid',
                  'nmi_watchdog': '/proc/sys/kernel/nmi_watchdog'}.items()},
              'resources_before': {name: (kernel_group() / name).read_text() for name in
                                   ['memory.max', 'memory.swap.max', 'memory.oom.group', 'cpu.max', 'memory.events']}}
    child, events = None, []
    deadline = time.monotonic() + 600
    preexisting_maps = set(Path('/tmp').glob('perf-*.map'))
    try:
        with (folder / 'host.stdout').open('xb') as out, (folder / 'host.stderr').open('xb') as err:
            started_ns = time.time_ns()
            child = subprocess.Popen(argv, cwd=ROOT, env=env, stdin=subprocess.DEVNULL,
                                     stdout=out, stderr=err, pass_fds=(child_socket.fileno(),))
            child_socket.close()
            result['pid'] = child.pid
            assert Path(f'/tmp/perf-{child.pid}.map') not in preexisting_maps, 'preexisting PID perf map'
            metadata = None
            if controls:
                raw = line(parent.fileno(), 30)
                words = raw.strip().split()
                assert len(words) == 6 and words[:2] == ['SWBP1', nonce]
                assert int(words[2]) == child.pid
                metadata = {'tid': int(words[3]), 'addresses': [int(word, 16) for word in words[4:]]}
                assert len(set(metadata['addresses'])) == 2
                result['control_metadata'] = metadata
            for index in range(warmups, warmups + samples):
                enabled = True
                if controls and CONTROLS[index][0] == 'disabled':
                    enabled = False
                for phase in ['ready', 'done']:
                    timeout = min(60, deadline - time.monotonic())
                    assert timeout > 0
                    raw = line(parent.fileno(), timeout)
                    expected = f'SWRSC1 {nonce} {phase} {args.mode} {index}\n'
                    assert raw == expected, (raw, expected)
                    if not events:
                        actual_worker = barrier_caller(child.pid, control_fd, control_inode, thread_record)
                        result['worker_before'] = actual_worker
                        maps_before_text = Path(f'/proc/{child.pid}/maps').read_text()
                        (folder / 'maps-before.txt').write_text(maps_before_text)
                        if controls:
                            assert metadata['tid'] == actual_worker['tid']
                            entries = [{'name': name, 'address': address,
                                        'mapping': executable_mapping(child.pid, address),
                                        'prefix_hex': prefix(child.pid, address)}
                                       for name, address in zip(['breakpoint_a', 'breakpoint_b'], metadata['addresses'])]
                        else:
                            entries, parents_before, map_before = cache_path_entries(
                                child.pid, folder, 'before', started_ns, objdump)
                            result['native_parents_before'] = parents_before
                            result['perf_map_before_sha256'] = hashlib.sha256(map_before).hexdigest()
                        result['entries'] = entries
                        for entry in entries:
                            event = Breakpoint(actual_worker['tid'], entry['address'])
                            events.append(event)
                            entry['perf_attr_hex'] = event.attr.hex()
                    authenticated = barrier_caller(child.pid, control_fd, control_inode, thread_record)
                    assert authenticated['tid'] == actual_worker['tid']
                    assert authenticated['starttime_ticks'] == actual_worker['starttime_ticks']
                    result.setdefault('barriers', []).append({'phase': phase, 'index': index, 'caller': authenticated})
                    if phase == 'ready':
                        for event in events:
                            event.start(enabled)
                    else:
                        counts = [event.stop(enabled) for event in events]
                        window = {'index': index, 'enabled': enabled, 'events': counts}
                        result['windows'].append(window)
                        if controls:
                            name, wanted = CONTROLS[index]
                            window.update(name=name, expected_counts=wanted)
                            assert [event['count'] for event in counts] == wanted, window
                        if index + 1 == warmups + samples:
                            after = barrier_caller(child.pid, control_fd, control_inode, thread_record)
                            assert after['tid'] == actual_worker['tid']
                            assert after['starttime_ticks'] == actual_worker['starttime_ticks']
                            result['worker_after'] = after
                            maps_after_text = Path(f'/proc/{child.pid}/maps').read_text()
                            (folder / 'maps-after.txt').write_text(maps_after_text)
                            if controls:
                                after_entries = [{'name': entry['name'], 'address': entry['address'],
                                                  'mapping': executable_mapping(child.pid, entry['address']),
                                                  'prefix_hex': prefix(child.pid, entry['address'])} for entry in entries]
                                result['entries_after'] = after_entries
                                assert after_entries == [{key: value for key, value in entry.items() if key != 'perf_attr_hex'} for entry in entries]
                            if not controls:
                                after_entries, parents_after, map_after = cache_path_entries(
                                    child.pid, folder, 'after', started_ns, objdump)
                                result['native_parents_after'] = parents_after
                                result['perf_map_after_sha256'] = hashlib.sha256(map_after).hexdigest()
                                assert map_before == map_after, 'perf map changed during the profiled child'
                                before_map_rows = maps_before_text.splitlines()
                                after_map_rows = maps_after_text.splitlines()
                                before_exec_rows = [line for line in before_map_rows if 'x' in line.split()[1]]
                                after_exec_rows = [line for line in after_map_rows if 'x' in line.split()[1]]
                                assert before_exec_rows == after_exec_rows, 'process executable mappings changed'
                                before_nonexec = set(before_map_rows) - set(before_exec_rows)
                                after_nonexec = set(after_map_rows) - set(after_exec_rows)
                                result['maps_change'] = {
                                    'full_maps_before_sha256': hashlib.sha256(maps_before_text.encode()).hexdigest(),
                                    'full_maps_after_sha256': hashlib.sha256(maps_after_text.encode()).hexdigest(),
                                    'executable_mappings_unchanged': True,
                                    'non_executable_before_only': sorted(before_nonexec - after_nonexec),
                                    'non_executable_after_only': sorted(after_nonexec - before_nonexec),
                                    'policy': 'non-executable mapping changes are recorded; every executable mapping must remain byte-identical',
                                }
                                for parent_name in PARENTS:
                                    before = parents_before[parent_name]
                                    after = parents_after[parent_name]
                                    assert before['base'] == after['base'] and before['size'] == after['size']
                                    assert before['bytes_sha256'] == after['bytes_sha256']
                                    assert before['normalized_disassembly_sha256'] == after['normalized_disassembly_sha256']
                                    assert (folder / before['bytes_path']).read_bytes() == \
                                           (folder / after['bytes_path']).read_bytes()
                                    assert re.sub(rb'^.*: +file format binary$', b'<native>: file format binary', (folder / before['disassembly_path']).read_bytes(), flags=re.M) == \
                                           re.sub(rb'^.*: +file format binary$', b'<native>: file format binary', (folder / after['disassembly_path']).read_bytes(), flags=re.M)
                                result['entries_after'] = after_entries
                                assert after_entries == [{key: value for key, value in entry.items()
                                                          if key != 'perf_attr_hex'} for entry in entries]
                    parent.sendall(expected.replace('SWRSC1', 'SWACK1', 1).encode())
            result['exit_code'] = child.wait(timeout=max(1, min(30, deadline - time.monotonic())))
        assert result['exit_code'] == 0
        report = load(folder / 'observations.json')
        if controls:
            assert report == {'complete': True, 'windows': 8, 'checksums_checked': 8}
            result['known_count_windows'] = 8
            result['control_binary_sha256'] = digest(binary)
        else:
            assert report['profiling']['nonce'] == nonce
            assert report['profiling']['windows'] == samples
            assert report['profiling']['excluded_from_scored_cohorts'] is True
            for key in ['inputs', 'program_wasm_sha256', 'program_wasm_bytes', 'runtime', 'configuration',
                        'source_fingerprint', 'executable_sha256', 'native_mode']:
                assert report[key] == baseline[key], key
            assert len(report['cases']) == 1
            case = report['cases'][0]
            assert case['case'] == 'rsc-' + args.mode and case['exact_node_output_checked']
            assert case['samples'] == samples and case['warmups'] == warmups
            assert len(case['observations']) == samples + warmups
            golden = next(item for item in baseline['cases'] if item['case'] == case['case'])
            for key in ('expected_json_sha256', 'expected_json_bytes'):
                assert case[key] == golden[key], key
            for index, observation in enumerate(case['observations']):
                assert observation['index'] == index and observation['warmup'] == (index < warmups)
            result['exact_flight_checks'] = len(case['observations'])
            result['program_wasm_sha256'] = report['program_wasm_sha256']
            result['runtime'] = report['runtime']
            result['source_fingerprint'] = report['source_fingerprint']
        assert digest(executable) == baseline['executable_sha256']
        for name in ('source', 'support'):
            assert digest(baseline['inputs'][name]) == baseline['inputs'][name + '_sha256']
        result['complete'] = True
        result['status'] = 'complete'
    except BaseException as error:
        result['error'] = repr(error)
        result['status'] = 'failed'
        raise
    finally:
        for event in events:
            event.close()
        if child is not None and child.poll() is None:
            child.kill()
            child.wait(timeout=5)
        parent.close()
        child_socket.close()
        result['resources_after'] = {name: (kernel_group() / name).read_text() for name in
                                     ['memory.events', 'memory.current']}
        result['raw_files'] = {path.name: {'sha256': digest(path), 'bytes': path.stat().st_size}
                               for path in folder.iterdir() if path.is_file()}
        save(folder / 'receipt.json', result)
    print(json.dumps({'status': result['status'], 'output': str(folder)}))


def main():
    args = parse_args()
    folder = args.output.resolve()
    owned_output = not folder.exists()
    try:
        assert owned_output, 'output directory already exists'
        run(args)
    except BaseException as error:
        if owned_output:
            folder.mkdir(exist_ok=True)
            if not (folder / 'receipt.json').exists():
                save(folder / 'receipt.json', {'complete': False, 'status': 'failed',
                     'unscored': True, 'mode': args.mode, 'driver_sha256': digest(__file__),
                     'error': repr(error), 'phase': 'preflight'})
        raise


if __name__ == '__main__':
    main()
