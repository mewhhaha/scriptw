"""Private serial CLI + exact original Iterator/Array-values Test262 tail.

Prepare/review/freeze before launch. No native test rerun or inherited JS pass
is credited. Fresh process batches contain at most 16 actual CLI-listed IDs.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import selectors
import shutil
import signal
import stat
import subprocess
import sys
import time

SOURCE = 'a036f1144ea3d3cf502d888b8a07f442837a857f'
FINGERPRINT = '2d3e3189d757b5bef454a23951d203cebf3c8282a0a8e45c8fd55ec58841a270'
NATIVE_SHA = '747bad48ffabcf859ca25a2b6cb81069b3c08b7f53bf53d7c00bc56466f76d73'
SUITE_TREE = '6a4268a9354a545d41c3b62efebc478ed8c521f4'
FAMILIES = ('built-ins/Iterator/prototype/constructor/', 'built-ins/Array/prototype/values/')
PINNED_FILES = {
    'test/built-ins/Iterator/prototype/constructor/prop-desc.js': '35370562b1f627dfafbd8a351f6d928ab0e1f2a08dcc56508666d70a4302e340',
    'test/built-ins/Iterator/prototype/constructor/weird-setter.js': '76155355da6ae233222b3e968ed540fc9ca769a2f01b2f434c017eaa19eed984',
    'test/built-ins/Array/prototype/values/iteration-mutable.js': '67ad35b891c3618c2e2492f09f4c8e9db9a16f33e9cde7bf4c63085c105590f6',
    'test/built-ins/Array/prototype/values/iteration.js': '7ef2335c3541a0651fdaf62dc41b0dc37e3e4160b1c816ae8f9ce657be9acab7',
    'test/built-ins/Array/prototype/values/length.js': '2133d016ea0a6bd58acd153600cc9a1719dbb4c808b0dcf3c1fb13a98407ef19',
    'test/built-ins/Array/prototype/values/name.js': '97532fc006f9e9ef2c33b738f331c038a03ddbc865d960b060379a39cdd684a0',
    'test/built-ins/Array/prototype/values/not-a-constructor.js': '63eeb7f80787220d426cdc4af5294edc5d36646538a18ead933d4c23d9088e06',
    'test/built-ins/Array/prototype/values/prop-desc.js': '59d94218ad8ea52a6554217745fdcbbbb0b38120f8a7e09c9ebb62d0f49cf880',
    'test/built-ins/Array/prototype/values/resizable-buffer-grow-mid-iteration.js': '85750109fe39a06fc07061591a616cb3a4e56327acf82657aa17a35cb16e3858',
    'test/built-ins/Array/prototype/values/resizable-buffer-shrink-mid-iteration.js': 'de381f006680402b748f6616cc872fbf25aa50ebee28921a0a06e2a8b0b55fd9',
    'test/built-ins/Array/prototype/values/resizable-buffer.js': 'a0032919c96ad87d6d4a7cb6ae682f06e3f198ca1b08e6999f9675fff5ecb5e1',
    'test/built-ins/Array/prototype/values/returns-iterator-from-object.js': '90a99df636460498d7358ea14b1f934bd5c5151215c1dc0c8d93feebd9513ded',
    'test/built-ins/Array/prototype/values/returns-iterator.js': '8db7d39dcef5af347042e0571f85b3980a96e410b4f74ea4b297b972dc7cb8f1',
    'test/built-ins/Array/prototype/values/this-val-non-obj-coercible.js': 'b1368dfa2a284cc09cc83017760bca8f09eeac1e14b3c0fb4a471d7abdd4d2f9',
    'harness/assert.js': '206e274ca325eb8a652e3911c3fbd090e2480d11ed7579dc17a5d17a2360ed48',
    'harness/sta.js': '1930c54af79455c484799f43e9a28e2b2f15c40d0917c9941ca54e26db243f35',
    'harness/doneprintHandle.js': '01282de15feb05d865dfc2cdfc68f59d8e760eb7d81a14ade3bc08cbc8520add',
    'harness/compareArray.js': '3330423fe116cd96db70077d194471319ae9767ba1c8e2f73d7c133c5204509d',
    'harness/resizableArrayBufferUtils.js': '029aa552050861eb85fe9d848a52716dfd24747dcaf06f2a8937cb510ab31f50',
    'harness/propertyHelper.js': '08bc29114d804c4f24f906bac950ee4dc9c93c659d93258e7b44a54283ba9bb8',
    'harness/isConstructor.js': '68e1a3e4565a8d33ea7fc918627fbbf446bcf14d7a939777616b2b545a5e7d32',
}
ROOT = Path.cwd().resolve()
BASE = ROOT / 'target/memory-ordered-bootstrap-20261027-evidence'
OUT = BASE / 'tail-main-a036f1144'
BUILD = ROOT / 'target/performance-work-20261024/build'
SUITE = ROOT / 'test262/vendor/test262'
NATIVE = BASE / 'native-main-a036f1144/report.json'
sys.path.insert(0, str(ROOT / 'scripts'))
from limited_verification import require_kernel_budget, kernel_group


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def stamp():
    return datetime.now(timezone.utc).isoformat()


def read_json(path, cap=16*1024**2):
    path = Path(path)
    assert not path.is_symlink() and stat.S_ISREG(path.lstat().st_mode) and path.stat().st_size <= cap
    return json.loads(path.read_text())


def budget(group):
    return {key:(group/key).read_text().strip() for key in
            ('memory.max', 'memory.swap.max', 'memory.oom.group', 'memory.peak', 'memory.events')}


def no_oom(before, after):
    for row in (before, after):
        assert row['memory.max'] == '4294967296' and row['memory.swap.max'] == '0' and row['memory.oom.group'] == '1'
    events = [dict(line.split() for line in row['memory.events'].splitlines()) for row in (before, after)]
    assert all(events[0][key] == events[1][key] == '0' for key in ('oom', 'oom_kill', 'oom_group_kill'))


def guard():
    assert subprocess.check_output(['git', 'rev-parse', '--show-toplevel'], cwd=ROOT, text=True).strip() == str(ROOT)
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == SOURCE
    assert not subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=no'], cwd=ROOT), 'tracked source/docs must stay clean'
    assert sha(NATIVE) == NATIVE_SHA, 'completed native checkpoint changed'
    assert sorted(os.sched_getaffinity(0)) == [0]
    assert os.environ['SCRIPTW_MODULE_MEMORY_CACHE_ENTRIES'] == '1'
    assert os.environ['SCRIPTW_MODULE_MEMORY_CACHE_LIMIT_BYTES'] == str(64*1024**2)
    for relative, expected in PINNED_FILES.items():
        path = SUITE / relative
        assert not path.is_symlink() and stat.S_ISREG(path.lstat().st_mode)
        assert path.stat().st_size <= 1024**2 and sha(path) == expected, relative
    for family in FAMILIES:
        actual = {path.relative_to(SUITE).as_posix() for path in (SUITE/'test'/family).rglob('*.js')}
        expected = {name for name in PINNED_FILES if name.startswith('test/'+family)}
        assert actual == expected and actual
    assert subprocess.check_output(['git', 'rev-parse', SOURCE+':test262/vendor/test262'], cwd=ROOT, text=True).strip() == SUITE_TREE


def save(report):
    (OUT/'report.json').write_text(json.dumps(report, indent=2)+'\n')


def invoke(report, label, command, timeout, stdout_cap=4*1024**2, allowed=(0,)):
    """Drain bounded pipes to retained files; kill/reap the process group on error."""
    guard()
    event = dict(label=label, command=list(map(str, command)), started_at=stamp(),
        stdout=label+'.stdout', stderr=label+'.stderr', timeout_seconds=timeout,
        stdout_limit_bytes=stdout_cap, stderr_limit_bytes=32*1024**2)
    report['commands'].append(event); save(report)
    started, process = time.monotonic(), None
    limits, totals = {'stdout':stdout_cap, 'stderr':32*1024**2}, {'stdout':0, 'stderr':0}
    try:
        with (OUT/event['stdout']).open('xb') as out, (OUT/event['stderr']).open('xb') as err:
            with selectors.DefaultSelector() as selector:
                process = subprocess.Popen(event['command'], cwd=ROOT, stdin=subprocess.DEVNULL,
                    stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True)
                for name, stream, target in [('stdout', process.stdout, out), ('stderr', process.stderr, err)]:
                    os.set_blocking(stream.fileno(), False)
                    selector.register(stream, selectors.EVENT_READ, (name, target))
                while selector.get_map():
                    remaining = timeout-(time.monotonic()-started)
                    if remaining <= 0:
                        event['timed_out'] = True
                        raise TimeoutError(label+' exceeded its command deadline')
                    for key, _ in selector.select(min(1, remaining)):
                        name, target = key.data
                        block = os.read(key.fd, 64*1024)
                        if not block:
                            selector.unregister(key.fileobj); key.fileobj.close(); continue
                        retained = block[:max(0, limits[name]-totals[name])]
                        target.write(retained); totals[name] += len(retained)
                        if len(retained) != len(block):
                            event['truncated_channel'] = name
                            raise ValueError(label+' '+name+' exceeded retained stream limit')
                event['returncode'] = process.wait(timeout=max(0.01, timeout-(time.monotonic()-started)))
    except BaseException as error:
        event['error'] = repr(error)
        if process is not None:
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            event['returncode'] = process.wait()
        raise
    finally:
        event.update(finished_at=stamp(), seconds=time.monotonic()-started)
        for channel in ('stdout', 'stderr'):
            path = OUT/event[channel]
            if path.exists():
                event[channel+'_sha256'] = sha(path)
                event[channel+'_bytes'] = path.stat().st_size
        save(report)
    assert event['returncode'] in allowed, label+' failed; raw streams retained'
    guard()
    return OUT/event['stdout']


def producer(log):
    found, terminal = [], []
    with log.open() as stream:
        for line in stream:
            assert len(line) <= 16*1024**2
            row = json.loads(line)
            if row.get('reason') == 'build-finished':
                terminal.append(row)
            if row.get('reason') == 'compiler-artifact' and row.get('executable') and row['target']['name'] == 'scriptw':
                found.append(row)
    assert terminal == [dict(reason='build-finished', success=True)] and len(found) == 1
    row = found[0]
    assert row['package_id'] == 'path+file://'+str(ROOT/'crates/scriptw-cli')+'#0.1.0'
    assert row['manifest_path'] == str(ROOT/'crates/scriptw-cli/Cargo.toml')
    assert row['target']['src_path'] == str(ROOT/'crates/scriptw-cli/src/main.rs')
    assert row['target']['kind'] == ['bin'] and row['target']['crate_types'] == ['bin']
    assert row['profile']['test'] is False and row['profile']['opt_level'] == '3' and row['features'] == []
    assert Path(row['executable']) == BUILD/'release/scriptw' and row['executable'] in row['filenames']
    return row


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--expected-source', required=True)
    args = parser.parse_args()
    assert args.expected_source == SOURCE and not OUT.exists()
    require_kernel_budget(4*1024**3)
    group = kernel_group()
    assert budget(group)['memory.max'] == '4294967296'
    os.environ['CARGO_BUILD_JOBS'] = '1'; os.environ['RUST_TEST_THREADS'] = '1'
    OUT.mkdir()
    report = dict(schema='scriptw-ordered-bootstrap-targeted-tail-v1', source_commit=SOURCE,
        complete=False, started_at=stamp(), before=budget(group), cpu_affinity=[0], commands=[], batches=[],
        driver=dict(path=str(Path(__file__).resolve()), sha256=sha(Path(__file__))),
        scope='Original pinned Iterator.prototype.constructor and Array.prototype.values families only; exact CLI-listed modes. Not full Test262, no inherited 6307 JS executions and no native test rerun.',
        native_predecessor=dict(path=str(NATIVE), sha256=NATIVE_SHA, credited_native_passes=0),
        expected_compiler_fingerprint=FINGERPRINT, batch_limit=16, inherited_js_executions=0)
    save(report)
    try:
        guard()
        native = read_json(NATIVE)
        assert native['complete'] is True and native['source_commit'] == SOURCE
        assert native['passed_disjoint_scopes'] == native['executed_disjoint_passes'] == 4894
        assert len(native['scopes']) == 19 and native['inherited_disjoint_passes'] == 0
        no_oom(native['before'], native['after'])
        report['native_predecessor'].update(complete=True, passed_disjoint_scopes=4894,
            interpretation='Completed checkpoint admission only; no native IDs are repeated or credited by this tail.')
        report['selected_files'] = []
        for relative, expected in sorted(PINNED_FILES.items()):
            source = SUITE/relative; retained = OUT/'pinned-inputs'/relative
            retained.parent.mkdir(parents=True, exist_ok=True)
            with source.open('rb') as src, retained.open('xb') as dst:
                shutil.copyfileobj(src, dst, 1024**2)
            assert sha(retained) == expected
            report['selected_files'].append(dict(path=relative, bytes=source.stat().st_size, sha256=expected,
                retained_file=retained.relative_to(OUT).as_posix()))
        report['suite_tree'] = SUITE_TREE; save(report)
        log = invoke(report, 'cargo-product', ['cargo', 'build', '--no-default-features', '--locked', '--offline',
            '--release', '--jobs', '1', '-p', 'scriptw-cli', '--bin', 'scriptw', '--target-dir', BUILD,
            '--message-format=json'], 7200, stdout_cap=128*1024**2)
        row = producer(log)
        original = Path(row['executable'])
        info = original.lstat()
        assert stat.S_ISREG(info.st_mode) and not original.is_symlink() and 0 < info.st_size <= 2*1024**3
        digest = sha(original); compiler = OUT/'compiler'
        with original.open('rb') as src, compiler.open('xb') as dst:
            shutil.copyfileobj(src, dst, 1024**2)
        compiler.chmod(0o500)
        frozen = compiler.stat()
        assert frozen.st_nlink == 1 and frozen.st_uid == os.getuid() and not frozen.st_mode & 0o222
        assert frozen.st_ino != info.st_ino or frozen.st_dev != info.st_dev
        assert frozen.st_size == info.st_size and sha(compiler) == sha(original) == digest
        report['compiler'] = dict(path=str(compiler), sha256=digest, bytes=frozen.st_size, cargo_producer=row,
            readonly=True, single_link=True, owner_uid=frozen.st_uid)
        save(report)
        identity = read_json(invoke(report, 'compiler-identity', [compiler, '--jobs', '1', 'compiler-identity'], 180), 4*1024**2)
        assert identity['source_revision'] == dict(kind='git-commit', commit=SOURCE)
        assert identity['source_fingerprint'] == FINGERPRINT
        assert identity['source_fingerprint_scheme'] == 'scriptw-program-cache-compiler-v3'
        assert identity['executable_sha256'] == digest
        report['compiler']['identity'] = identity; save(report)
        selected, family_rows = [], []
        for index, family in enumerate(FAMILIES):
            assert sha(compiler) == digest
            text = invoke(report, 'inventory-'+str(index), [compiler, '--jobs', '1', 'test262', 'list-all', family,
                '--suite-root', SUITE], 180).read_text()
            lines = text.splitlines()
            assert lines and re.fullmatch(r'count: [1-9][0-9]*', lines[0])
            ids = lines[1:]
            assert ids and len(ids) == len(set(ids)) == int(lines[0][7:])
            paths = set()
            for execution in ids:
                match = re.fullmatch(r'(sloppy-script|strict-script|module):([^\r\n]+)', execution)
                assert match and match[2].startswith(family)
                relative = 'test/'+match[2]
                assert relative in PINNED_FILES
                paths.add(relative)
            expected_files = {path for path in PINNED_FILES if path.startswith('test/'+family)}
            assert paths == expected_files and not set(ids).intersection(selected)
            selected.extend(ids)
            family_rows.append(dict(filter=family, source_files=len(paths), executions=len(ids)))
        selected.sort()
        assert selected and len(selected) == len(set(selected))
        execution_file = OUT/'executions'; execution_file.write_text('\n'.join(selected)+'\n')
        report.update(families=family_rows, selected_executions=len(selected),
            execution_list_sha256=sha(execution_file), total=len(selected), passed=0)
        counts = dict(Bug=0, Crash=0, NotImplemented=0, Success=0)
        pins = None
        save(report)
        for offset in range(0, len(selected), 16):
            ids = selected[offset:offset+16]; label = 'execute-'+format(offset//16, '03d')
            listing = OUT/(label+'.executions'); listing.write_text('\n'.join(ids)+'\n')
            snapshots = OUT/'snapshots'/label
            assert not snapshots.exists() and sha(compiler) == digest
            output = invoke(report, label, [compiler, '--jobs', '1', 'test262', 'run-list', listing,
                '--execution-backend', 'wasm-aot', '--suite-root', SUITE, '--snapshot-dir', snapshots,
                '--snapshot-name', label, '--threads', '1', '--timeout-ms', '60000', '--reuse-case-workers'],
                1800, allowed=(0, 1))
            candidates = list(snapshots.glob('*.json'))
            assert len(candidates) == 1
            snapshot = candidates[0]; value = read_json(snapshot)
            batch = dict(list_file=listing.name, list_sha256=sha(listing), snapshot_file=snapshot.relative_to(OUT).as_posix(),
                snapshot_sha256=sha(snapshot), snapshot_bytes=snapshot.stat().st_size)
            report['batches'].append(batch); save(report)
            assert re.findall(r'^total: (\d+)$', output.read_text(), re.M) == [str(len(ids))]
            assert value['snapshot_version'] == 8 and value['producer'] == 'scriptw'
            assert value['execution_backend'] == 'wasm-aot' and value['compiler_identity'] == identity
            completed = value['completed_test_ids']
            assert len(completed) == len(set(completed)) == len(ids) and set(completed) == set(ids)
            assert value['total'] == len(ids)
            assert value['pinned_revisions']['test262'] == SUITE_TREE
            if pins is None:
                pins = value['pinned_revisions']; report['pinned_revisions'] = pins
            assert value['pinned_revisions'] == pins
            batch.update(passed=value['passed'], total=value['total'], counts_per_outcome=value['counts_per_outcome'],
                failures=value['failures'], timeout_test_ids=value['timeout_test_ids'])
            save(report)
            assert value['passed'] == len(ids) and value['counts_per_outcome'] == dict(Bug=0, Crash=0, NotImplemented=0, Success=len(ids))
            assert not value['failures'] and not value['timeout_test_ids'] and all(count == 0 for count in value['counts_per_kind'].values())
            assert report['commands'][-1]['returncode'] == 0
            for key in counts:
                counts[key] += value['counts_per_outcome'][key]
            report.update(counts_per_outcome=counts, passed=counts['Success']); save(report)
            print('completed', offset+len(ids), '/', len(selected), 'selected executions', flush=True)
        guard()
        assert sha(compiler) == digest and counts == dict(Bug=0, Crash=0, NotImplemented=0, Success=len(selected))
        after = budget(group); no_oom(report['before'], after)
        report.update(complete=True, all_passed=True, counts_per_outcome=counts, passed=len(selected),
            after=after, finished_at=stamp(), native_tests_rerun=False, inherited_js_executions=0)
    except BaseException as error:
        report.update(error=repr(error), error_type=type(error).__name__, complete=False,
                      after=budget(group), finished_at=stamp())
        raise
    finally:
        save(report)
    print(json.dumps(dict(complete=True, source_commit=SOURCE, passed=report['passed'], total=report['total'], output=str(OUT))))


if __name__ == '__main__':
    main()
