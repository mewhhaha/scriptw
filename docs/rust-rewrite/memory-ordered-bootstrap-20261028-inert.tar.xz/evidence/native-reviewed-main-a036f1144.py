"""Private source-bound 19-target native verification; prepare, do not autorun.

One serial default-feature Cargo build produces every executable. Six focused
controls run first and count toward their full scopes, without duplicate runs.
All observed --list IDs run exactly once; the expected count is descriptive.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import selectors
import shutil
import signal
import stat
import subprocess
import sys
import time

BASE = Path(__file__).resolve().parent
REPOSITORY = BASE.parents[1]
ROOT = REPOSITORY / 'target/memory-ordered-bootstrap-20261027'
BUILD = REPOSITORY / 'target/performance-work-20261024/build'
BASELINE = REPOSITORY / 'target/memory-regexp-backtrack-20261027-evidence/retry-9001324dc/native/report.json'
SOURCE = '15edd3e3956f8587ad94663e4a20a7c81b862d97'
REVIEWED_SOURCE = SOURCE
BASELINE_SOURCE = '9001324dc52ce583e7b95a1292f317796d415c01'
MIB = 1024**2

# The same exact package/target/kind set as the complete 4889-case predecessor.
PLAN = [
    ('scriptw-aot-wasm', 'scriptw_aot_wasm', 'lib'),
    ('scriptw-engine', 'aot_realm_modules', 'test'),
    ('scriptw-engine', 'scriptw_engine', 'lib'),
    ('scriptw-aot-wasm', 'emission', 'test'),
    ('scriptw-engine', 'aot_regexp', 'test'),
    ('scriptw-engine', 'aot_gc_entries', 'test'),
    ('scriptw-aot-wasm', 'modules_realms', 'test'),
    ('scriptw-aot-wasm', 'intl_temporal', 'test'),
    ('scriptw-aot-wasm', 'runtime_link', 'test'),
    ('scriptw-aot-wasm', 'structure_builtins', 'test'),
    ('scriptw-engine', 'structure', 'test'),
    ('scriptw-engine', 'aot_language', 'test'),
    ('scriptw-engine', 'aot_generators', 'test'),
    ('scriptw-engine', 'aot_intl', 'test'),
    ('scriptw-engine', 'aot_builtins', 'test'),
    ('scriptw-engine', 'aot_temporal', 'test'),
    ('scriptw-engine', 'aot_async', 'test'),
    ('scriptw-aot-wasm', 'structure_language', 'test'),
    ('scriptw-aot-wasm', 'structure_async', 'test'),
]
AOT_IDS = [
    'data::pooled_literal_domain::tests::intrinsic_installation_keys_reject_program_literals_and_retain_symbol_identity',
    'functions::function_object_allocation::constructor_allocation::tests::shared_constructor_tail_requires_exact_native_entry_and_uniform_captures',
    'tests::ordered_bootstrap_allocation::ordered_realm_bootstrap_shares_real_recipe_and_constructor_allocation',
    'tests::bootstrap_compact_metadata::native_bootstrap_allocates_compact_metadata_without_eager_property_records',
]
REALM_IDS = [
    'aot_created_realm_array_iterator::ordered_deferred_installation_keeps_alias_descriptors_independent_across_gc',
    'aot_created_realm_array_iterator::shared_constructor_allocation_keeps_eager_realm_links_and_bootstrap_exceptions',
]
FOCUS = [(PLAN[0], AOT_IDS), (PLAN[1], REALM_IDS)]


def require(value, message):
    if not value:
        raise ValueError(message)


def stamp():
    return datetime.now(timezone.utc).isoformat()


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def source():
    require(subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == SOURCE,
            'isolated checkout differs from admitted source')
    require(not subprocess.check_output(['git', 'diff', '--binary', 'HEAD', '--'], cwd=ROOT),
            'tracked source changes are not admitted')


def scope():
    require_kernel_budget(4 * 1024**3)
    require(sorted(os.sched_getaffinity(0)) == [0], 'native verification requires CPU0')
    require(os.environ.get('CARGO_BUILD_JOBS') == os.environ.get('RUST_TEST_THREADS') == '1',
            'Cargo and libtest must remain serial')
    require(os.environ.get('SCRIPTW_JOBS') == os.environ.get('RAYON_NUM_THREADS') == '1',
            'native compilation workers must remain serial')
    require(os.environ.get('SCRIPTW_MODULE_MEMORY_CACHE_ENTRIES') == '1'
            and os.environ.get('SCRIPTW_MODULE_MEMORY_CACHE_LIMIT_BYTES') == str(64 * MIB),
            'retained module cache differs from one entry/64 MiB')
    require(os.environ.get('SCRIPTW_EXPECTED_SOURCE') == SOURCE, 'expected-source environment differs')


def budget():
    group = kernel_group()
    return {key: (group / key).read_text().strip() for key in
            ('memory.max', 'memory.swap.max', 'memory.oom.group', 'memory.peak', 'memory.events')}


def no_oom(before, after):
    events = [dict(line.split() for line in row['memory.events'].splitlines()) for row in (before, after)]
    require(all(events[0][key] == events[1][key] for key in ('oom', 'oom_kill', 'oom_group_kill')),
            'kernel OOM event occurred during verification')


def save(output, report):
    temporary = output / 'report.pending.json'
    temporary.write_text(json.dumps(report, indent=2) + '\n')
    temporary.replace(output / 'report.json')


def kill_owned(process):
    try:
        os.killpg(process.pid, signal.SIGKILL)
    except ProcessLookupError:
        pass


def run_command(row, output, *, timeout, stdout_limit, stderr_limit):
    """Drain bounded pipes; preserve metadata even on timeout/spawn/pipe errors."""
    started = time.monotonic()
    row.update(started_at=stamp(), timeout_seconds=timeout, stdout_limit_bytes=stdout_limit,
               stderr_limit_bytes=stderr_limit, timed_out=False, output_limit_exceeded=False)
    paths = {name: output / row[name] for name in ('stdout', 'stderr')}
    process = None
    try:
        with paths['stdout'].open('xb') as stdout, paths['stderr'].open('xb') as stderr:
            streams = dict(stdout=stdout, stderr=stderr)
            limits = dict(stdout=stdout_limit, stderr=stderr_limit)
            retained = dict(stdout=0, stderr=0)
            process = subprocess.Popen(row['command'], cwd=row['cwd'], stdin=subprocess.DEVNULL,
                                       stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True)
            row['owned_child_pid'] = process.pid
            deadline = started + timeout
            stopping = False
            with selectors.DefaultSelector() as selector:
                for name, pipe in [('stdout', process.stdout), ('stderr', process.stderr)]:
                    os.set_blocking(pipe.fileno(), False)
                    selector.register(pipe, selectors.EVENT_READ, name)
                while selector.get_map() or process.poll() is None:
                    if time.monotonic() >= deadline:
                        if stopping:
                            row['pipe_cleanup_incomplete'] = True
                            break
                        row['timed_out'] = True
                        stopping = True
                        deadline = time.monotonic() + 5
                        kill_owned(process)
                    for key, _ in selector.select(0.1):
                        try:
                            raw = os.read(key.fileobj.fileno(), 65536)
                        except BlockingIOError:
                            continue
                        if not raw:
                            selector.unregister(key.fileobj)
                            continue
                        name = key.data
                        keep = min(len(raw), limits[name] - retained[name])
                        streams[name].write(raw[:keep])
                        retained[name] += keep
                        if keep != len(raw) and not stopping:
                            row['output_limit_exceeded'] = True
                            stopping = True
                            deadline = time.monotonic() + 5
                            kill_owned(process)
                if process.poll() is None:
                    kill_owned(process)
                row['exit_code'] = process.wait(timeout=5)
    except BaseException as error:
        row.update(error=str(error), error_type=type(error).__name__)
        raise
    finally:
        try:
            if process is not None:
                if process.poll() is None:
                    kill_owned(process)
                    process.wait(timeout=5)
                row.setdefault('exit_code', process.returncode)
        finally:
            if process is not None:
                for pipe in (process.stdout, process.stderr):
                    if pipe is not None:
                        pipe.close()
            row.update(seconds=time.monotonic() - started, finished_at=stamp())
            for name, path in paths.items():
                if path.exists():
                    row[name + '_sha256'] = sha(path)
                    row[name + '_bytes'] = path.stat().st_size


def main():
    global ROOT, SOURCE, kernel_group, require_kernel_budget, parse_inventory, result_summaries
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--workspace', type=Path, default=ROOT,
                        help='selected clean checkout; defaults to isolated reviewed worktree')
    parser.add_argument('--expected-source', required=True,
                        help='exact reviewed source or descendant with identical product compiler inputs')
    parser.add_argument('--source-equivalence-proof', type=Path,
                        help='computed compiler-input rows for reviewed and selected source; required for a different commit')
    parser.add_argument('--output', type=Path, required=True, help='fresh directory below the private evidence parent')
    args = parser.parse_args()
    ROOT = args.workspace.resolve(strict=True)
    SOURCE = args.expected_source
    require(re.fullmatch('[0-9a-f]{40}', SOURCE) is not None, 'expected source must be an exact commit')
    sys.path.insert(0, str(ROOT / 'scripts'))
    from limited_verification import kernel_group, require_kernel_budget
    from native_test_protocol import parse_inventory, result_summaries
    output = args.output.resolve()
    require(output.is_relative_to(BASE) and output != BASE and not output.exists(), 'fresh private output required')
    output.mkdir(parents=True, exist_ok=False)
    report = dict(schema='scriptw-ordered-bootstrap-native-verification-v1', source_commit=SOURCE,
                  reviewed_source_commit=REVIEWED_SOURCE, source_checkout=str(ROOT), build_directory=str(BUILD), complete=False, started_at=stamp(),
                  commands=[], scopes=[], plan=[dict(package=p, target=t, kind=k) for p, t, k in PLAN],
                  features=[], predecessor_binary_reuse=False,
                  resource_scope='This invocation covers one serial Cargo build, actual inventories and every native ID in the same 19 affected targets. Six focused controls are included once in their full scopes; no inherited passes/binaries or pinned Test262 execution is claimed.',
                  expected_native_inventory_total=4894,
                  count_expectation='4889 predecessor +3 new AOT unit/emission IDs +2 new Realm IDs. Actual compiled --list inventories, not this expectation, determine executed and passed totals.')
    save(output, report)
    try:
        scope()
        source()
        report.update(cpu_affinity=[0], before=budget(), driver_sha256=sha(Path(__file__)))
        require(Path(subprocess.check_output(['git', 'rev-parse', '--show-toplevel'], cwd=ROOT, text=True).strip()).resolve() == ROOT,
                'workspace must name the checkout root')
        require(subprocess.run(['git', 'merge-base', '--is-ancestor', REVIEWED_SOURCE, SOURCE], cwd=ROOT).returncode == 0,
                'selected source does not include the reviewed ordered-bootstrap batch')
        fingerprint_owner_path = 'crates/scriptw-engine/compiler_fingerprint.rs'
        owner = subprocess.check_output(['git', 'show', REVIEWED_SOURCE + ':' + fingerprint_owner_path], cwd=ROOT).decode()
        def input_domain(name):
            block = owner.split('const ' + name + ': &[&str] = &[', 1)[1].split('];', 1)[0]
            result = re.findall(r'^\s*"([^"]+)",', block, re.M)
            require(result, 'reviewed fingerprint input domain is empty/malformed')
            return result
        compiler_inputs = input_domain('COMPILER_INPUTS')
        test_only_inputs = input_domain('TEST_ONLY_INPUTS')
        input_changes = subprocess.check_output(['git', 'diff', '--name-only', REVIEWED_SOURCE, SOURCE, '--', *compiler_inputs],
                                                cwd=ROOT, text=True).splitlines()
        product_changes = [path for path in input_changes if not any(path == excluded or path.startswith(excluded + '/')
                                                                    for excluded in test_only_inputs)]
        require(not product_changes, 'selected descendant changes reviewed product compiler/runtime inputs: ' + repr(product_changes))
        admission = dict(reviewed_source_commit=REVIEWED_SOURCE, selected_source_commit=SOURCE,
                         compiler_input_owner_path=fingerprint_owner_path,
                         compiler_input_owner_sha256=hashlib.sha256(owner.encode()).hexdigest(),
                         product_compiler_input_changes=product_changes,
                         excluded_test_only_changes=input_changes,
                         interpretation='Git-tree product compiler inputs equal the reviewed source under its explicit fingerprint input/exclusion domains. Actual native tests are always built and inventoried from the selected checkout.')
        equivalence_path = args.source_equivalence_proof.resolve(strict=True) if args.source_equivalence_proof is not None else None
        require(SOURCE == REVIEWED_SOURCE or equivalence_path is not None,
                'a different selected commit requires its computed source-equivalence proof')
        equivalence_sha = None
        if equivalence_path is not None:
            require(equivalence_path.is_file() and equivalence_path.stat().st_size <= MIB, 'missing/oversized equivalence proof')
            equivalence = json.loads(equivalence_path.read_text())
            require(equivalence['computed_compiler_inputs_equal'] is True, 'computed source-equivalence proof is not positive')
            for extra, expected_fp in [(False, '9c6ce32926290a0343955878c3d2e880f63559f6ee4afc7eb3bb6ce018c7b755'),
                                       (True, '2d3e3189d757b5bef454a23951d203cebf3c8282a0a8e45c8fd55ec58841a270')]:
                selected_rows = []
                for revision in {REVIEWED_SOURCE, SOURCE}:
                    rows = [row for row in equivalence['rows'] if row['revision'] == revision and row['extra_ignored_regress_lock'] is extra]
                    require(len(rows) == 1 and rows[0]['source_fingerprint'] == expected_fp, 'reviewed/selected fingerprint proof row differs')
                    selected_rows.append(rows[0])
                require(len({(row['source_fingerprint'], row['files'], row['bytes']) for row in selected_rows}) == 1,
                        'computed source-equivalence input inventory differs')
            equivalence_sha = sha(equivalence_path)
            admission['computed_proof'] = dict(path=str(equivalence_path), sha256=equivalence_sha)
        report['reviewed_source_admission'] = admission
        require(subprocess.run(['git', 'merge-base', '--is-ancestor', BASELINE_SOURCE, SOURCE], cwd=ROOT).returncode == 0,
                'baseline source is not an ancestor')
        baseline = json.loads(BASELINE.read_text())
        baseline_sha = sha(BASELINE)
        require(baseline['complete'] is True and baseline['source_commit'] == BASELINE_SOURCE
                and baseline['passed_disjoint_scopes'] == 4889 and len(baseline['scopes']) == 19,
                'complete 4889-case baseline required')
        baseline_scopes = {(s['package'], s['target'], s['kind']): s for s in baseline['scopes']}
        require(len(set(PLAN)) == 19 and set(baseline_scopes) == set(PLAN), 'exact predecessor 19-target inventory differs')
        for old in baseline_scopes.values():
            require(old['complete'] and len(old['inventory']) == len(set(old['inventory'])) == old['passed'],
                    'baseline target inventory is incomplete')
        report['baseline'] = dict(path=str(BASELINE), sha256=baseline_sha, source_commit=BASELINE_SOURCE,
                                  complete=True, passed_disjoint_scopes=4889, inherited_passes=0)
        save(output, report)

        def run(label, command, cwd=ROOT, *, timeout=3600, cargo=False, test_ids=None):
            source()
            scope()
            require(sha(BASELINE) == baseline_sha, 'baseline evidence changed')
            if equivalence_path is not None:
                require(sha(equivalence_path) == equivalence_sha, 'source-equivalence proof changed')
            row = dict(label=label, command=list(map(str, command)), cwd=str(cwd),
                       stdout=label + '.stdout', stderr=label + '.stderr')
            if test_ids is not None:
                row['expected_test_ids'] = list(test_ids)
            report['commands'].append(row)
            save(output, report)
            print(label, 'started', flush=True)
            try:
                run_command(row, output, timeout=timeout,
                            stdout_limit=(128 if cargo else 4) * MIB,
                            stderr_limit=(32 if cargo else 4) * MIB)
            finally:
                try:
                    if test_ids is not None and (output / row['stdout']).exists():
                        text = (output / row['stdout']).read_text()
                        row['reported_passing_test_ids'] = [name.removesuffix(' - should panic') for name in
                            re.findall(r'^test ([^\r\n]+) \.\.\. ok$', text, re.M)]
                        row['reported_result_summaries'] = result_summaries(text)
                finally:
                    save(output, report)
            source()
            scope()
            require(row.get('exit_code') == 0 and not row['timed_out'] and not row['output_limit_exceeded']
                    and not row.get('pipe_cleanup_incomplete'), label + ' failed; original streams retained')
            print(label, 'finished', row['exit_code'], flush=True)
            return row, (output / row['stdout']).read_text()

        command = ['cargo', 'test', '--locked', '--offline', '--release', '--jobs', '1', '--target-dir', BUILD,
                   '-p', 'scriptw-engine', '-p', 'scriptw-aot-wasm', '--lib']
        for name in sorted({name for _, name, kind in PLAN if kind == 'test'}):
            command += ['--test', name]
        command += ['--no-default-features', '--no-run', '--message-format=json']
        _, text = run('cargo-native', command, timeout=10800, cargo=True)
        cargo = [json.loads(line) for line in text.splitlines()]
        require(cargo and cargo[-1] == dict(reason='build-finished', success=True)
                and sum(r.get('reason') == 'build-finished' for r in cargo) == 1, 'Cargo build did not finish successfully')
        frozen = {}
        admitted_producers = []
        for package, name, kind in PLAN:
            crate = ROOT / 'crates' / package
            producer_path = 'path+file://' + str(crate) + '#'
            producers = [r for r in cargo if r.get('reason') == 'compiler-artifact' and r.get('executable')
                         and r['target']['name'] == name and r['target']['kind'] == [kind] and r['profile']['test']
                         and r['package_id'].startswith(producer_path)]
            require(len(producers) == 1, 'target lacks a unique actual isolated-source Cargo producer: ' + package + '/' + name)
            producer = producers[0]
            old = baseline_scopes[package, name, kind]
            old_crate = REPOSITORY / 'crates' / package
            expected_src = crate / Path(old['cargo_producer']['target']['src_path']).relative_to(old_crate)
            require(Path(producer['target']['src_path']).resolve() == expected_src
                    and producer['features'] == [] and producer['profile']['opt_level'] == '3',
                    'Cargo source/feature/release producer differs')
            original = Path(producer['executable'])
            info = original.lstat()
            require(original.resolve() == original and original.is_relative_to(BUILD)
                    and stat.S_ISREG(info.st_mode), 'Cargo executable is not a regular file in the admitted build directory')
            original_sha = sha(original)
            directory = output / (package + '-' + name)
            directory.mkdir()
            binary = directory / 'tests'
            with original.open('rb') as src, binary.open('xb') as dst:
                shutil.copyfileobj(src, dst)
            binary.chmod(0o500)
            require(sha(binary) == original_sha == sha(original) and binary.stat().st_nlink == 1
                    and binary.stat().st_mode & 0o222 == 0, 'private frozen executable copy differs/is writable')
            target = dict(package=package, target=name, kind=kind, cargo_producer=producer,
                          binary=str(binary.relative_to(output)), executable_sha256=original_sha,
                          baseline_inventory_count=len(old['inventory']), complete=False, passed=0,
                          passed_test_ids=[], focused_test_ids=[], broad_test_ids=[])
            report['scopes'].append(target)
            frozen[package, name, kind] = (target, binary)
            admitted_producers.append(producer)
            save(output, report)
        actual_target_producers = [r for r in cargo if r.get('reason') == 'compiler-artifact' and r.get('executable')
                                   and r['profile']['test'] and any(r['package_id'].startswith('path+file://' + str(ROOT / 'crates' / p) + '#')
                                   for p in ('scriptw-aot-wasm', 'scriptw-engine'))]
        require(actual_target_producers == [r for r in cargo if r in admitted_producers], 'unplanned native target producer')
        require(len(actual_target_producers) == 19, 'exact 19 Cargo native producers required')
        source()
        # Inventory every frozen executable before running any semantic control.
        for key in PLAN:
            target, binary = frozen[key]
            label = key[0] + '-' + key[1]
            _, text = run(label + '-inventory', [binary, '--list', '--color=never'], ROOT / 'crates' / key[0])
            inventory = parse_inventory(text)
            old_ids = set(baseline_scopes[key]['inventory'])
            require(old_ids <= set(inventory), 'previously verified native IDs disappeared: ' + label)
            target.update(inventory=inventory, added_test_ids=sorted(set(inventory) - old_ids), removed_test_ids=[])
            save(output, report)
        actual_total = sum(len(target['inventory']) for target, _ in frozen.values())
        report.update(observed_native_inventory_total=actual_total,
                      expected_native_inventory_total_matches=actual_total == report['expected_native_inventory_total'],
                      added_native_ids=sum(len(target['added_test_ids']) for target, _ in frozen.values()))
        save(output, report)

        def execute_ids(key, ids, label, phase):
            target, binary = frozen[key]
            require(ids and len(ids) == len(set(ids)) and set(ids) <= set(target['inventory']), 'exact ID chunk differs')
            require(not set(ids).intersection(target['passed_test_ids']), 'native ID would be executed twice')
            row, text = run(label, [binary, '--exact', '--include-ignored', '--test-threads=1', '--color=never', *ids],
                            ROOT / 'crates' / key[0], test_ids=ids)
            names = row['reported_passing_test_ids']
            require(len(names) == len(set(names)) == len(ids) and set(names) == set(ids), 'actual passing exact-name inventory differs')
            require(result_summaries(text) == [('ok', str(len(ids)), '0', '0', '0', str(len(target['inventory']) - len(ids)))],
                    'native terminal summary does not match the full target inventory')
            target['passed_test_ids'] += sorted(names)
            target[phase + '_test_ids'] += sorted(names)
            target['passed'] = len(target['passed_test_ids'])
            save(output, report)

        for key, ids in FOCUS:
            execute_ids(key, ids, key[0] + '-' + key[1] + '-focused', 'focused')
        report.update(focused_complete=True, focused_passed=6,
                      focused_interpretation='All six controls ran before broad semantic suites. They are credited once toward full target coverage and excluded from each broad remainder; focused overlap is not additional passes.')
        save(output, report)
        for key in PLAN:
            target, binary = frozen[key]
            focused_ids = set(target['focused_test_ids'])
            remainder = [name for name in target['inventory'] if name not in focused_ids]
            chunks = [remainder[i:i+8] for i in range(0, len(remainder), 8)] if key[1] in ('scriptw_engine', 'aot_gc_entries') else ([remainder] if remainder else [])
            for index, ids in enumerate(chunks):
                execute_ids(key, ids, key[0] + '-' + key[1] + f'-part-{index:03d}', 'broad')
            require(len(target['passed_test_ids']) == len(set(target['passed_test_ids'])) == len(target['inventory'])
                    and set(target['passed_test_ids']) == set(target['inventory'])
                    and sha(binary) == target['executable_sha256'], 'full target coverage or frozen executable changed')
            target['complete'] = True
            save(output, report)
            print(key[0], key[1], target['passed'], 'passed', flush=True)
        source()
        scope()
        require(sha(BASELINE) == baseline_sha and all(target['complete'] for target, _ in frozen.values())
                and len(report['scopes']) == 19, 'complete target/source/evidence closure differs')
        if equivalence_path is not None:
            require(sha(equivalence_path) == equivalence_sha, 'source-equivalence proof changed')
        passed = sum(target['passed'] for target, _ in frozen.values())
        require(passed == actual_total and sum(len(target['focused_test_ids']) for target, _ in frozen.values()) == 6,
                'actual disjoint native coverage differs')
        after = budget()
        report['after'] = after
        no_oom(report['before'], after)
        report.update(complete=True, finished_at=stamp(), passed_disjoint_scopes=passed,
                      executed_disjoint_passes=passed, inherited_disjoint_passes=0,
                      focused_passes_included=6, broad_remainder_passes=passed - 6,
                      repeated_native_test_ids=0)
        return 0
    except BaseException as error:
        report.update(error=str(error), error_type=type(error).__name__, finished_at=stamp())
        return 1
    finally:
        if 'before' in report and 'after' not in report:
            try:
                report['after'] = budget()
                no_oom(report['before'], report['after'])
            except (OSError, ValueError) as error:
                report['resource_after_error'] = str(error)
        save(output, report)
        print(json.dumps(dict(complete=report['complete'], passed=report.get('passed_disjoint_scopes'),
                              observed_inventory=report.get('observed_native_inventory_total'),
                              expected_count_matches=report.get('expected_native_inventory_total_matches'),
                              error=report.get('error'), output=str(output))), flush=True)


if __name__ == '__main__':
    raise SystemExit(main())
