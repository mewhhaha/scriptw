"""Private continuation after the successful CLI build / producer-path refusal.

Reuse the frozen 81455 driver definitions and its unchanged post-build ladder.
Only the producer src_path authority changes: tracked Cargo [[bin]] metadata.
No Cargo command or native test is executed by this continuation.
"""
import argparse
import ast
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import sys
import tomllib

ROOT = Path.cwd().resolve()
BASE = ROOT / 'target/memory-ordered-bootstrap-20261027-evidence'
sys.path.insert(0, str(ROOT / 'scripts'))
ORIGINAL = BASE / 'tail-reviewed-main-a036f1144.py'
ORIGINAL_SHA = '81455e5a7987e1f085bdc74dc69cb782982d0c155374c863e05b35e7d366d070'
ORIGIN = BASE / 'tail-main-a036f1144'
PREFIX_SHA = '416ae8f944a49b335c17de710fcb9f6ff35b9125160e976f6d490e675d86e56d'
CONTINUED = BASE / 'tail-continued-main-a036f1144'


def file_sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


assert file_sha(ORIGINAL) == ORIGINAL_SHA
original_text = ORIGINAL.read_text()
original_tree = ast.parse(original_text, filename=str(ORIGINAL))
definitions = [node for node in original_tree.body if isinstance(node, (ast.Import, ast.ImportFrom, ast.Assign, ast.FunctionDef))
               and not (isinstance(node, ast.FunctionDef) and node.name == 'main')]
producer_function = next(node for node in definitions if isinstance(node, ast.FunctionDef) and node.name == 'producer')
path_assertions = [node for node in ast.walk(producer_function) if isinstance(node, ast.Assert)
                   and ast.unparse(node.test) == "row['target']['src_path'] == str(ROOT / 'crates/scriptw-cli/src/main.rs')"]
assert len(path_assertions) == 1
path_assertions[0].test = ast.parse("row['target']['src_path'] == str(declared_bin_source)", mode='eval').body
exec(compile(ast.fix_missing_locations(ast.Module(body=definitions, type_ignores=[])), str(ORIGINAL)+':reused-definitions', 'exec'), globals())
OUT = CONTINUED


def declared_source():
    manifest = ROOT / 'crates/scriptw-cli/Cargo.toml'
    raw = manifest.read_bytes()
    assert raw == subprocess.check_output(['git', 'show', SOURCE+':crates/scriptw-cli/Cargo.toml'], cwd=ROOT)
    value = tomllib.loads(raw.decode())
    bins = [entry for entry in value['bin'] if entry['name'] == 'scriptw']
    assert len(bins) == 1 and isinstance(bins[0]['path'], str)
    relative = Path(bins[0]['path'])
    assert not relative.is_absolute() and '..' not in relative.parts
    path = (manifest.parent / relative).resolve()
    assert path.is_relative_to(manifest.parent) and path.is_file() and not path.is_symlink()
    tracked = path.relative_to(ROOT).as_posix()
    expected = subprocess.check_output(['git', 'show', SOURCE+':'+tracked], cwd=ROOT)
    assert path.read_bytes() == expected
    return path, dict(manifest=manifest.relative_to(ROOT).as_posix(), manifest_sha256=file_sha(manifest),
        declaration=bins[0], declared_source=tracked, declared_source_sha256=file_sha(path),
        authority='Exact tracked [[bin]] entry named scriptw; no filename inference.')


def main():
    global declared_bin_source
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--expected-source', required=True)
    parser.add_argument('--stopped-journal', type=Path, required=True)
    parser.add_argument('--stopped-journal-sha256', required=True)
    args = parser.parse_args()
    assert args.expected_source == SOURCE and not OUT.exists()
    require_kernel_budget(4*1024**3)
    group = kernel_group()
    assert budget(group)['memory.max'] == '4294967296'
    os.environ['CARGO_BUILD_JOBS'] = '1'; os.environ['RUST_TEST_THREADS'] = '1'
    OUT.mkdir()
    report = dict(schema='scriptw-ordered-bootstrap-targeted-tail-continuation-v1', source_commit=SOURCE,
        complete=False, started_at=stamp(), before=budget(group), cpu_affinity=[0], commands=[], batches=[],
        driver=dict(path=str(Path(__file__).resolve()), sha256=file_sha(Path(__file__))),
        scope='Remaining compiler identity + original Iterator.prototype.constructor and Array.prototype.values families only. Exact CLI-listed modes; no repeated CLI build, native test or inherited JS pass.',
        native_predecessor=dict(path=str(NATIVE), sha256=NATIVE_SHA, credited_native_passes=0),
        expected_compiler_fingerprint=FINGERPRINT, batch_limit=16, inherited_js_executions=0,
        resource_scope='Fresh continuation only. The stopped prefix retains its own authentic before/after and failure.')
    save(report)
    try:
        guard()
        assert file_sha(ORIGINAL) == ORIGINAL_SHA and file_sha(ORIGIN/'report.json') == PREFIX_SHA
        prefix = read_json(ORIGIN/'report.json')
        assert prefix['complete'] is False and prefix['source_commit'] == SOURCE
        assert prefix['driver'] == dict(path=str(ORIGINAL), sha256=ORIGINAL_SHA)
        assert prefix['error_type'] == 'AssertionError' and prefix['error'] == 'AssertionError()'
        assert len(prefix['commands']) == 1 and not prefix['batches'] and 'compiler' not in prefix
        no_oom(prefix['before'], prefix['after'])
        command = prefix['commands'][0]
        assert command['label'] == 'cargo-product' and command['returncode'] == 0
        assert command['command'] == list(map(str, ['cargo', 'build', '--no-default-features', '--locked', '--offline',
            '--release', '--jobs', '1', '-p', 'scriptw-cli', '--bin', 'scriptw', '--target-dir', BUILD, '--message-format=json']))
        assert command['stdout_sha256'] == 'e5b147755c4226c09760719c3cd79ab2adf41923aeafb5a40c119c5bcaabda16'
        assert command['stderr_sha256'] == '5280a21089a60faabc8260de70bee2434e8b1a373802b511ad35b549a9797395'
        for channel, cap in [('stdout',128*1024**2), ('stderr',32*1024**2)]:
            assert command[channel] == 'cargo-product.'+channel
            path = ORIGIN/command[channel]
            assert not path.is_symlink() and stat.S_ISREG(path.lstat().st_mode)
            assert path.stat().st_size == command[channel+'_bytes'] <= cap
            assert file_sha(path) == command[channel+'_sha256']
        journal = args.stopped_journal.resolve()
        assert journal.parent == BASE and not journal.is_symlink() and journal.stat().st_size <= 4*1024**2
        assert re.fullmatch('[0-9a-f]{64}', args.stopped_journal_sha256)
        assert file_sha(journal) == args.stopped_journal_sha256
        text = journal.read_text()
        assert 'line 178, in producer' in text and 'status=1/FAILURE' in text
        native = read_json(NATIVE)
        assert native['complete'] is True and native['source_commit'] == SOURCE
        assert native['passed_disjoint_scopes'] == native['executed_disjoint_passes'] == 4894
        assert len(native['scopes']) == 19 and native['inherited_disjoint_passes'] == 0
        no_oom(native['before'], native['after'])
        declared_bin_source, authority = declared_source()
        log = ORIGIN/command['stdout']
        row = producer(log)
        report.update(original_prefix=dict(path=str(ORIGIN/'report.json'), sha256=PREFIX_SHA, complete=False,
            before=prefix['before'], after=prefix['after'], build_returncode=0, parent_exit_code=1,
            parent_exit_origin='systemd journal', journal_sha256=args.stopped_journal_sha256,
            failure='Producer src_path assertion inferred src/main.rs instead of reading the explicit tracked [[bin]] path.',
            command=command), producer_authority=authority, selected_files=prefix['selected_files'], suite_tree=SUITE_TREE,
            original_driver=dict(path=str(ORIGINAL), sha256=ORIGINAL_SHA),
            reused_ladder='Original 81455 AST from original = Path(row[executable]) through terminal success; no Cargo statement included.')
        inherited = OUT/'inherited-prefix'; inherited.mkdir()
        copies = [(ORIGIN/'report.json', inherited/'report.json'), (ORIGINAL,inherited/'executed-driver.py'),
                  (journal,inherited/'journal.stdout')]
        copies.extend((ORIGIN/command[channel],inherited/command[channel]) for channel in ('stdout','stderr'))
        for selected in report['selected_files']:
            source = ORIGIN/selected['retained_file']
            assert file_sha(source) == selected['sha256']
            target = inherited/selected['retained_file']; target.parent.mkdir(parents=True, exist_ok=True)
            copies.append((source,target))
            selected['retained_file'] = target.relative_to(OUT).as_posix()
        for source, target in copies:
            with source.open('rb') as src, target.open('xb') as dst:
                shutil.copyfileobj(src,dst,1024**2)
            assert file_sha(source) == file_sha(target)
        save(report)
        original_main = next(node for node in original_tree.body if isinstance(node, ast.FunctionDef) and node.name == 'main')
        original_try = next(node for node in original_main.body if isinstance(node, ast.Try))
        start = next(index for index,node in enumerate(original_try.body)
            if isinstance(node,ast.Assign) and ast.unparse(node) == "original = Path(row['executable'])")
        tail = original_try.body[start:]
        assert not any(isinstance(node,ast.Call) and isinstance(node.func,ast.Name) and node.func.id == 'producer' for statement in tail for node in ast.walk(statement))
        globals().update(report=report,group=group,row=row)
        exec(compile(ast.Module(body=tail,type_ignores=[]), str(ORIGINAL)+':unchanged-post-build-ladder','exec'),globals())
        assert file_sha(ORIGIN/'report.json') == PREFIX_SHA and file_sha(ORIGINAL) == ORIGINAL_SHA
        report.update(cargo_build_rerun=False, native_tests_rerun=False)
    except BaseException as error:
        report.update(error=repr(error),error_type=type(error).__name__,complete=False,after=budget(group),finished_at=stamp())
        raise
    finally:
        save(report)
    print(json.dumps(dict(complete=True,source_commit=SOURCE,passed=report['passed'],total=report['total'],output=str(OUT))))


if __name__ == '__main__':
    main()
