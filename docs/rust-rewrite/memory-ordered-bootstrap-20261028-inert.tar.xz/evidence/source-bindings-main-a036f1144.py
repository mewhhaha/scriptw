"""Compare exact Git-tree compiler inputs with captured CI/local identities."""
import hashlib,json,re,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
ROOTS=['Cargo.toml','Cargo.lock','crates/scriptw-front','crates/scriptw-ir','crates/scriptw-aot-wasm','crates/scriptw-runtime','crates/scriptw-runtime-image','crates/scriptw-intl','crates/scriptw-intl-build-data','crates/scriptw-engine/Cargo.toml','crates/scriptw-engine/src','crates/scriptw-engine/build.rs','crates/scriptw-engine/compiler_fingerprint.rs','vendor']
def one(args):return subprocess.check_output(args,cwd=ROOT)
def fingerprint(revision,extra=False):
 source=one(['git','show',revision+':crates/scriptw-engine/compiler_fingerprint.rs']).decode()
 block=source.split('const TEST_ONLY_INPUTS: &[&str] = &[',1)[1].split('];',1)[0]
 excluded=re.findall(r'^\s*"([^"]+)",',block,re.M)
 items=[]
 for raw in one(['git','ls-tree','-r','-z',revision,'--',*ROOTS]).split(b'\0'):
  if not raw:continue
  fields,path=raw.split(b'\t',1);mode,kind,oid=fields.decode().split();path=path.decode()
  if any(path==x or path.startswith(x+'/') for x in excluded):continue
  assert kind=='blob' and mode=='100644',(mode,kind,path)
  items.append((path,oid))
 if extra:items.append(('vendor/regress-0.10.5/Cargo.lock',None))
 digest=hashlib.sha256(b'scriptw-program-cache-compiler-v3');total=0
 child=subprocess.Popen(['git','cat-file','--batch'],cwd=ROOT,stdin=subprocess.PIPE,stdout=subprocess.PIPE)
 try:
  for path,oid in sorted(items,key=lambda x:tuple(x[0].split('/'))):
   if oid is None:data=(ROOT/path).read_bytes()
   else:
    child.stdin.write((oid+'\n').encode());child.stdin.flush();header=child.stdout.readline().split();assert header[:2]==[oid.encode(),b'blob'];length=int(header[2]);data=child.stdout.read(length);assert len(data)==length and child.stdout.read(1)==b'\n'
   label=path.encode();digest.update(len(label).to_bytes(8,'little'));digest.update(label);digest.update(len(data).to_bytes(8,'little'));digest.update(data);total+=len(data)
 finally:child.stdin.close();child.stdout.close();assert child.wait()==0
 return dict(revision=one(['git','rev-parse',revision]).decode().strip(),extra_ignored_regress_lock=extra,source_fingerprint=digest.hexdigest(),files=len(items),bytes=total)

import os,sys
sys.path.insert(0,str(ROOT/'scripts'))
from limited_verification import require_kernel_budget,kernel_group
require_kernel_budget(256*1024**2)
assert sorted(os.sched_getaffinity(0))==[0]
main='a036f1144ea3d3cf502d888b8a07f442837a857f'
assert one(['git','rev-parse','HEAD']).decode().strip()==main
assert not one(['git','diff','--binary','HEAD'])
group=kernel_group()
def budget():return {k:(group/k).read_text().strip() for k in ['memory.max','memory.swap.max','memory.oom.group','memory.peak','memory.events']}
before=budget()
rows=[fingerprint(rev,extra) for rev in ['15edd3e3956f8587ad94663e4a20a7c81b862d97',main,'4f514410da1ee2db642ac39900a0b3a6bfbb3552'] for extra in [False,True]]
for extra,expected in [(False,'9c6ce32926290a0343955878c3d2e880f63559f6ee4afc7eb3bb6ce018c7b755'),(True,'2d3e3189d757b5bef454a23951d203cebf3c8282a0a8e45c8fd55ec58841a270')]:
 selected=[r for r in rows if r['extra_ignored_regress_lock']==extra]
 assert len(selected)==3 and {r['source_fingerprint'] for r in selected}=={expected}
 assert len({(r['files'],r['bytes']) for r in selected})==1
r=dict(main_source=main,reviewed_source='15edd3e3956f8587ad94663e4a20a7c81b862d97',probe_source='4f514410da1ee2db642ac39900a0b3a6bfbb3552',computed_compiler_inputs_equal=True,rows=rows,cpu_affinity=[0],before=before,after=budget())
counters=[dict(line.split() for line in r[k]['memory.events'].splitlines()) for k in ['before','after']]
assert all(counters[0][k]==counters[1][k] for k in ['oom','oom_kill','oom_group_kill'])
p=OUT/'source-bindings-main-a036f1144-equivalence.json'
with p.open('x') as f:f.write(json.dumps(r,indent=2)+'\n')
print(json.dumps(r))
