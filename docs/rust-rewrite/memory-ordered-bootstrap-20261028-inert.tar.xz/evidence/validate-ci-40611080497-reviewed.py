"""Inert admission of the ordered-bootstrap CI cohort, never native execution."""
import ast
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import stat
import struct
import subprocess
import sys
from types import SimpleNamespace

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
SOURCE = '1721e1b6daf39924dabee7e85112adc2ebed4c9d'
MAIN = 'a036f1144ea3d3cf502d888b8a07f442837a857f'
FEATURE = '15edd3e3956f8587ad94663e4a20a7c81b862d97'
FINGERPRINT = '9c6ce32926290a0343955878c3d2e880f63559f6ee4afc7eb3bb6ce018c7b755'
LOCAL_FINGERPRINT = '2d3e3189d757b5bef454a23951d203cebf3c8282a0a8e45c8fd55ec58841a270'
RUN = 40611080497
SCORED = BASE / 'github-40611080497-scored/precompiled-evidence/report.json'
CHECKS = BASE / 'github-40611080497-checks-static/ordered-bootstrap-verification'
STATIC = BASE / 'github-40611080497-checks-static/ordered-bootstrap-static'
DIAGNOSTIC = BASE / 'github-40611080497-diagnostic'
LOCAL = BASE / 'static-preflight-main-a036f1144'
OUT = BASE / 'ci-40611080497-validated'
PATTERN = ROOT / 'target/memory-module-ownership-20261027-evidence/validate-ci-40594118953.py'
PATTERN_SHA = '1455de1eb46d3190cafc4bf33150baa236e648287e1b31df404b55293e88a70b'
HELPERS = ('helper::realm_initialize_intrinsics', 'helper::intrinsic_constructor_allocate',
           'helper::deferred_intrinsic_install', 'helper::intrinsic_accessor_allocate')
EXPECTED_TESTS = [
    ['data::pooled_literal_domain::tests::intrinsic_installation_keys_reject_program_literals_and_retain_symbol_identity',
     'functions::function_object_allocation::constructor_allocation::tests::shared_constructor_tail_requires_exact_native_entry_and_uniform_captures',
     'tests::ordered_bootstrap_allocation::ordered_realm_bootstrap_shares_real_recipe_and_constructor_allocation',
     'tests::bootstrap_compact_metadata::native_bootstrap_allocates_compact_metadata_without_eager_property_records'],
    ['aot_created_realm_array_iterator::ordered_deferred_installation_keeps_alias_descriptors_independent_across_gc',
     'aot_created_realm_array_iterator::shared_constructor_allocation_keeps_eager_realm_links_and_bootstrap_exceptions']]
sys.path.insert(0, str(ROOT / 'scripts'))
import precompiled_comparison as p
import benchmark_module_images as m
from limited_verification import require_kernel_budget, kernel_group
from native_test_protocol import result_summaries
spec = importlib.util.spec_from_file_location('ordered_core_diagnostic_contract', ROOT/'scripts/diagnose-precompiled-mappings.py')
d = importlib.util.module_from_spec(spec); spec.loader.exec_module(d)
PHASES = list(d.PHASES)
EXPECTED_CASES = [(runtime,name) for name in ('integer.js','retained-objects.js') for runtime in ('scriptw','scriptc')]
INPUTS = {}
args = SimpleNamespace(scored_report=SCORED)


def file_sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()


# Reuse only inert definitions, never the old source-specific top-level driver.
assert file_sha(PATTERN) == PATTERN_SHA
tree = ast.parse(PATTERN.read_text(),filename=str(PATTERN))
definitions = [node for node in tree.body if isinstance(node,ast.FunctionDef)]
exec(compile(ast.Module(body=definitions,type_ignores=[]),str(PATTERN)+':inert-definitions','exec'),globals())


def metadata(path, maximum=64*1024**2, manifest=False):
    path = Path(path)
    info = path.lstat()
    assert stat.S_ISREG(info.st_mode) and not path.is_symlink() and path.resolve() == path and info.st_size <= maximum
    with path.open('rb') as stream:
        magic = stream.read(8)
    assert not magic.startswith((b'\x7fELF',b'MZ',b'SWRTZ001',b'SCRWRB',b'SCRWEP',b'SCRWWA'))
    if magic == b'SCRWNR01':
        assert manifest and info.st_size <= 4096
    INPUTS[str(path)] = dict(bytes=info.st_size,sha256=file_sha(path))
    return INPUTS[str(path)]


def json_input(path, maximum=16*1024**2):
    metadata(path,maximum)
    return p._json(Path(path).read_bytes())


def counters(group):
    return {key:(group/key).read_text().strip() for key in ('memory.max','memory.swap.max','memory.oom.group','memory.peak','memory.events')}


def resource_pair(value, maximum=4*1024**3):
    assert value['cpu_affinity'] == [0]
    for sample in (value['before'],value['after']):
        assert 0 < int(sample['memory.max']) <= maximum and sample['memory.swap.max'] == '0' and sample['memory.oom.group'] == '1'
    events = [dict(line.split() for line in sample['memory.events'].splitlines()) for sample in (value['before'],value['after'])]
    assert all(events[0][key] == events[1][key] == '0' for key in ('oom','oom_kill','oom_group_kill'))


def command_streams(directory, command, cap=32*1024**2):
    assert command['exit_code'] == 0 and command['timed_out'] is False and command['output_limit_exceeded'] is False
    assert not command.get('pipe_cleanup_incomplete')
    for channel in ('stdout','stderr'):
        assert p.safe_name(command[channel]) == command['label']+'.'+channel
        row = metadata(directory/command[channel],cap)
        assert row['bytes'] == command[channel+'_bytes'] and row['sha256'] == command[channel+'_sha256']


def focused():
    value = json_input(CHECKS/'report.json')
    assert value['complete'] is True and value['source_commit'] == SOURCE and value['passed'] == 6
    resource_pair(value)
    assert len(value['commands']) == len(value['scopes']) == 2
    for index,(command,scope) in enumerate(zip(value['commands'],value['scopes'])):
        expected = EXPECTED_TESTS[index]
        assert command['label'] == scope['label'] == ('aot-exact-four' if index == 0 else 'realm-exact-two')
        command_streams(CHECKS,command)
        text = (CHECKS/command['stdout']).read_text()
        passed = re.findall(r'^test ([^\r\n]+) \.\.\. ok$',text,re.M)
        assert len(passed) == len(set(passed)) == len(expected) and set(passed) == set(expected)
        assert command['expected_test_ids'] == scope['expected_test_ids'] == expected
        assert scope['passed_test_ids'] == passed and scope['passed'] == len(expected) and scope['complete'] is True
        summaries = result_summaries(text)
        assert len(summaries) == 1 and summaries[0][:5] == ('ok',str(len(expected)),'0','0','0')
        assert list(summaries[0]) == scope['summary']
        argv = command['command']; target = ['-p','scriptw-aot-wasm','--lib'] if index == 0 else ['-p','scriptw-engine','--features','benchmark-module-images','--test','aot_realm_modules']
        assert argv == ['cargo','test','--locked','--release','--jobs','1',*target,'--','--exact','--include-ignored','--test-threads=1','--color=never',*expected]
    return value


def cargo_producers(path):
    metadata(path,64*1024**2)
    rows,finished = [],[]
    with path.open() as stream:
        for line in stream:
            assert len(line) <= 16*1024**2
            value = json.loads(line)
            if value.get('reason') == 'build-finished':
                finished.append(value)
            elif value.get('reason') == 'build-script-executed' or value.get('reason') == 'compiler-artifact' and value.get('executable'):
                rows.append(value)
    assert finished == [dict(reason='build-finished',success=True)]
    return rows


def manifests(directory,mode,value,fingerprint):
    package,manifest,native = (value[key] for key in ('package','manifest','native'))
    path = directory/p.safe_name(manifest['retained_path'])
    actual = metadata(path,4096,manifest=True)
    raw = path.read_bytes()
    assert raw[:8] == b'SCRWNR01' and struct.unpack_from('<I',raw,8)[0] == manifest['version'] == 5
    n = struct.unpack_from('<H',raw,19)[0]
    assert 0 < n <= 256 and len(raw) == 21+n+128
    offset = 21+n
    source,key,pkg,native_sha = [raw[offset+i*32:offset+(i+1)*32].hex() for i in range(4)]
    assert actual['bytes'] == manifest['bytes'] == len(raw) and actual['sha256'] == manifest['sha256']
    assert source == manifest['source_fingerprint'] == package['source_fingerprint'] == fingerprint
    assert key == manifest['runtime_key'] == package['runtime_key']
    assert pkg == manifest['package_digest'] == package['sha256'] and native_sha == manifest['native_digest'] == native['sha256']
    assert struct.unpack_from('<I',raw,12)[0] == manifest['configuration'] == 4
    assert list(raw[16:19]) == manifest['modes'] == [1,3,1]
    assert raw[21:21+n].decode() == manifest['target'] == 'x86_64-unknown-linux-gnu'
    assert package['layout'] == 29 and package['bytes'] == package['wasm_bytes']+168 <= 64*1024**2
    assert 0 < native['bytes'] <= 128*1024**2
    assert all(re.fullmatch('[0-9a-f]{64}',package[key]) for key in ('sha256','wasm_sha256','runtime_key','runtime_identity_sha256'))
    command, = [row for row in json_input(directory/'report.json')['commands'] if row['label'] == mode+'-r-symbols']
    command_streams(directory,command)
    assert command['command'] == ['nm','--print-size','--size-sort','--defined-only',native['path']]
    lines = (directory/command['stdout']).read_bytes().splitlines()
    helpers = {}
    for name in HELPERS:
        candidates = [line.split() for line in lines if line.endswith(('::'+name).encode())]
        assert len(candidates) == 1 and len(candidates[0]) == 4
        address,size,kind,symbol = candidates[0]
        assert re.fullmatch(b'[0-9a-fA-F]{1,16}',address) and re.fullmatch(b'[0-9a-fA-F]{1,16}',size) and kind in (b't',b'T')
        address,size = int(address,16),int(size,16)
        assert 0 < size <= native['bytes'] and address <= native['bytes']-size
        helpers[name] = dict(native_bytes=size,address=address,symbol=symbol.decode())
    assert helpers == value['helper_symbols']
    assert value['new_shared_helpers_native_bytes'] == helpers[HELPERS[1]]['native_bytes']+helpers[HELPERS[2]]['native_bytes']
    assert value['initializer_plus_new_helpers_native_bytes'] == helpers[HELPERS[0]]['native_bytes']+value['new_shared_helpers_native_bytes']
    assert value['initializer_delta_from_reported_reference_bytes'] == helpers[HELPERS[0]]['native_bytes']-765194
    assert value['initializer_plus_new_helpers_delta_from_reported_reference_bytes'] == value['initializer_plus_new_helpers_native_bytes']-765194
    return helpers


def static(campaign):
    value = json_input(STATIC/'report.json')
    local = json_input(LOCAL/'report.json')
    assert value['complete'] is True and value['source_commit'] == SOURCE and value['scored'] is False
    assert local['complete'] is True and local['source_commit'] == MAIN
    resource_pair(value); resource_pair(local)
    assert value['compiler_inputs']['source_fingerprint'] == FINGERPRINT
    assert value['compiler_inputs']['scheme'] == 'scriptw-program-cache-compiler-v3'
    assert value['compiler_inputs']['implementation_sha256'] == file_sha(ROOT/'crates/scriptw-engine/compiler_fingerprint.rs')
    assert (value['compiler_inputs']['files'],value['compiler_inputs']['bytes']) == (2921,161537629)
    assert value['limits'] == dict(package_bytes=64*1024**2,native_bytes=128*1024**2,nm_stdout_bytes=32*1024**2,
        nm_stderr_bytes=1024**2,nm_timeout_seconds=60,cargo_log_bytes=64*1024**2)
    log = BASE/'github-40611080497-scored/precompiled-cargo.jsonl'
    rows = cargo_producers(log)
    assert INPUTS[str(log)]['bytes'] == value['cargo_log']['bytes'] and INPUTS[str(log)]['sha256'] == value['cargo_log']['sha256']
    for key in ('runtime_image_cargo_producer','shared_host_cargo_producer'):
        assert rows.count(value[key]) == 1
    runtime = [row for row in rows if row.get('reason') == 'build-script-executed' and row['package_id'].endswith('/crates/scriptw-runtime-image#0.1.0')]
    assert runtime == [value['runtime_image_cargo_producer']]
    assert runtime[0]['out_dir'] == value['runtime_out_dir']
    assert runtime[0]['linked_libs'] == ['static:-bundle=scriptw_runtime_images'] and runtime[0]['cfgs'] == ['scriptw_runtime_image']
    assert runtime[0]['linked_paths'] == ['native='+value['runtime_out_dir']]
    host = value['shared_host_cargo_producer']
    assert host == campaign['tools']['consumer']['cargo_producer']
    assert host['target']['kind'] == ['example'] and host['target']['name'] == 'compiler_precompiled_baseline'
    assert host['profile']['test'] is False and host['features'] == ['benchmark-module-images']
    assert set(value['variants']) == set(local['variants']) == {'Portable','NativeHost'}
    for mode,prefix in [('Portable','scriptw-runtime-portable'),('NativeHost','scriptw-runtime')]:
        variant = value['variants'][mode]; old = local['variants'][mode]
        for key,suffix in [('package','-package.bin'),('manifest','-manifest.bin'),('native','-native.bin')]:
            assert variant[key]['path'] == str(Path(value['runtime_out_dir'])/(prefix+suffix))
        manifests(STATIC,mode,variant,FINGERPRINT)
        manifests(LOCAL,mode,old,LOCAL_FINGERPRINT)
        assert variant['package']['wasm_sha256'] == old['package']['wasm_sha256']
        assert variant['package']['wasm_bytes'] == old['package']['wasm_bytes']
        assert variant['package']['runtime_key'] == old['package']['runtime_key']
        assert variant['package']['runtime_identity_sha256'] == old['package']['runtime_identity_sha256']
        variant['local_raw_wasm_sha256_equal'] = True
        variant['local_native_sha256_equal_observed'] = variant['native']['sha256'] == old['native']['sha256']
    return dict(ci=value,local_preflight_sha256=INPUTS[str(LOCAL/'report.json')]['sha256'],
        local_preflight_source=MAIN,raw_wasm_equal_both_modes=True,
        historical_failed_log_bound_preflight=local['ci_log_preflight'],
        interpretation='Compare actual raw-R Wasm digests computed by retained static receipts. Native images are not downloaded/read/executed here. Cross-runner native digest equality is neither required nor inferred; manifests and raw nm streams bind each runner separately.')


def budgets(diagnostic):
    results = []
    for name in ('integer.js','retained-objects.js'):
        sw,sc = [next(case for case in diagnostic['cases'] if case['runtime'] == runtime and case['file'] == name)
                 for runtime in ('scriptw','scriptc')]
        if sw['status'] != 'validated' or sc['status'] != 'validated':
            results.append(dict(file=name,status='unavailable',reason='Both unscored owner/host captures must be valid.')); continue
        owners = {item['role']:item for item in sw['module_attribution']['owners']}
        control = sc['module_attribution']['owners'][0]
        assert set(owners) == {'program','runtime'} and control['role'] == 'program'
        assert all(owner['relation'] == 'text-inside-image' for owner in [*owners.values(),control])
        phases = []
        for index,phase in enumerate(PHASES):
            r,p_row,c_row = owners['runtime']['phases'][index],owners['program']['phases'][index],control['phases'][index]
            assert r['phase'] == p_row['phase'] == c_row['phase'] == phase and r['page_bytes'] == p_row['page_bytes'] == c_row['page_bytes']
            page = r['page_bytes']
            module_union = r['union_present_pages']+p_row['union_present_pages']
            host_delta = sw['host_phases'][index]['present_host_rx_pages']-sc['host_phases'][index]['present_host_rx_pages']
            phases.append(dict(phase=phase,page_bytes=page,r_image_present_pages=r['image_present_pages'],
                r_text_present_pages=r['text_present_pages'],r_image_pages_without_text=r['image_present_pages']-r['text_present_pages'],
                p_union_present_pages=p_row['union_present_pages'],r_union_present_pages=r['union_present_pages'],
                scriptw_module_union_present_pages=module_union,scriptc_module_union_present_pages=c_row['union_present_pages'],
                extra_scriptw_module_present_bytes=(module_union-c_row['union_present_pages'])*page,
                scriptw_host_rx_present_pages=sw['host_phases'][index]['present_host_rx_pages'],
                scriptc_host_rx_present_pages=sc['host_phases'][index]['present_host_rx_pages'],
                extra_scriptw_host_rx_present_bytes=host_delta*page))
        results.append(dict(file=name,status='validated',phases=phases,
            r_transport_to_warm_present_page_growth_upper_bound=phases[1]['r_union_present_pages']-phases[0]['r_union_present_pages'],
            r_transport_to_warm_present_bytes_growth_upper_bound=(phases[1]['r_union_present_pages']-phases[0]['r_union_present_pages'])*phases[0]['page_bytes'],
            interpretation='Warm snapshots follow16 prior calls. Transport-to-warm growth is an upper bound on startup contribution, not a causal matched-intervention saving. Host RX and function overlaps are nonexclusive and separate from anonymous module pages.'))
    return results


def main():
    require_kernel_budget(1024**3)
    assert sorted(os.sched_getaffinity(0)) == [0] and not OUT.exists()
    group = kernel_group(); OUT.mkdir()
    report = dict(schema='scriptw-ordered-bootstrap-ci-validation-v1',complete=False,source_commit=SOURCE,
        feature_source_commit=FEATURE,main_source_commit=MAIN,source_fingerprint=FINGERPRINT,run=RUN,
        started_at=datetime.now(timezone.utc).isoformat(),cpu_affinity=[0],before=counters(group),
        driver_sha256=file_sha(Path(__file__)),reused_inert_validator_sha256=PATTERN_SHA)
    try:
        assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip() == MAIN
        assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=ROOT)
        for module,name in [(p,'precompiled_comparison.py'),(m,'benchmark_module_images.py'),(d,'diagnose-precompiled-mappings.py')]:
            path = ROOT/'scripts'/name
            assert Path(module.__file__).resolve() == path
            assert path.read_bytes() == subprocess.check_output(['git','show',SOURCE+':scripts/'+name],cwd=ROOT)
            metadata(path)
        for name in ('verify-ordered-bootstrap-ci.py','record-ordered-bootstrap-static.py'):
            raw = subprocess.check_output(['git','show',SOURCE+':scripts/'+name],cwd=ROOT)
            report.setdefault('ci_processor_sources',{})[name] = dict(source_commit=SOURCE,sha256=hashlib.sha256(raw).hexdigest())
            (OUT/name).write_bytes(raw)
        binding = json_input(BASE/'source-bindings-ci-log-bound-equivalence.json')
        main_binding = json_input(BASE/'source-bindings-main-a036f1144-equivalence.json')
        assert binding['probe_source'] == SOURCE and binding['compiler_feature_source'] == FEATURE
        assert binding['computed_compiler_inputs_equal'] is True and binding['probe_only_noncompiler_changes'] is True
        assert main_binding['main_source'] == MAIN and main_binding['reviewed_source'] == FEATURE
        assert main_binding['computed_compiler_inputs_equal'] is True
        for proof,revisions in [(binding,(SOURCE,FEATURE)),(main_binding,(MAIN,FEATURE))]:
            for revision in revisions:
                for ignored,fp in [(False,FINGERPRINT),(True,LOCAL_FINGERPRINT)]:
                    rows = [row for row in proof['rows'] if row['revision'] == revision and row['extra_ignored_regress_lock'] is ignored]
                    assert len(rows) == 1 and rows[0]['source_fingerprint'] == fp
        run = json_input(BASE/'github-run-40611080497.json')
        assert run['databaseId'] == RUN and run['headSha'] == SOURCE and run['status'] == 'completed' and run['conclusion'] == 'success'
        assert len(run['jobs']) == 1 and run['jobs'][0]['name'] == 'measure' and run['jobs'][0]['conclusion'] == 'success'
        for name in ('Verify and build the shared host','Verify ordered bootstrap regressions','Inspect owned runtime static metadata',
                     'Measure both compiler-free consumers','Observe unscored consumer mappings','Retain all raw observations and failures'):
            steps = [step for job in run['jobs'] for step in job['steps'] if step['name'] == name]
            assert len(steps) == 1 and steps[0]['conclusion'] == 'success'
        metadata(SCORED,p.MAX_REPORT)
        campaign,table = p.load_report(SCORED)
        assert campaign['source_commit'] == SOURCE and campaign['source_fingerprint'] == FINGERPRINT
        assert len(campaign['attempts']) == 68 and len(table) == 17 and all(row['status'] == 'ok' for row in campaign['attempts'])
        assert campaign['tools']['consumer']['cargo_producer']['features'] == ['benchmark-module-images']
        for row in campaign['retained_files']:
            actual = metadata(SCORED.parent/p.safe_name(row['path']))
            assert actual['bytes'] == row['bytes'] and actual['sha256'] == row['sha256']
        report.update(scored_admitted=True,scored_attempts=68,scored_workloads=17,scored_all_attempts_ok=True,
            scored_table=table,actual_shared_host_identity_confirmed=True,focused_native=focused())
        report['static'] = static(campaign)
        report['diagnostic'] = diagnostic(DIAGNOSTIC,campaign,run)
        report['page_budgets'] = budgets(report['diagnostic'])
        for case in report['diagnostic']['cases']:
            case.pop('host_function_overlap',None)
        report['interpretation'] = 'One source-bound current cohort only; unscored presence and nonexclusive function overlap do not establish execution or causal RSS savings. Runtime Wasm equality compares local/CI digest receipts, not native CPU artifact equality. No parity/full-Test262/project-completion claim. Section diagnostic CI40611737589 is separate and unused.'
        after = counters(group); resource_pair(dict(cpu_affinity=[0],before=report['before'],after=after),1024**3)
        report.update(complete=True,after=after,finished_at=datetime.now(timezone.utc).isoformat())
    except BaseException as error:
        report.update(error=repr(error),error_type=type(error).__name__,after=counters(group),finished_at=datetime.now(timezone.utc).isoformat())
        raise
    finally:
        report['inputs'] = INPUTS
        (OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n')
    lines = ['CI40611080497: 68/68 scored attempts,17 workload checksums and6 exact native controls admitted.',
        'Both runtime modes: layout29/manifests/Cargo producers/raw nm streams admitted; local and CI raw R Wasm SHA match. Native digests remain runner-specific.',
        'Unscored ownership/host metadata: '+report['diagnostic']['status']+'.','',
        '| Case | Phase | R text pages | R image pages without text | P+R union | Scriptc union | Extra module MiB | Extra host RX MiB |',
        '|---|---|---:|---:|---:|---:|---:|---:|']
    for case in report['page_budgets']:
        for phase in case.get('phases',[]):
            lines.append('| '+case['file']+' | '+phase['phase']+' | '+str(phase['r_text_present_pages'])+' | '+str(phase['r_image_pages_without_text'])+' | '+str(phase['scriptw_module_union_present_pages'])+' | '+str(phase['scriptc_module_union_present_pages'])+' | '+format(phase['extra_scriptw_module_present_bytes']/1024**2,'.6f')+' | '+format(phase['extra_scriptw_host_rx_present_bytes']/1024**2,'.6f')+' |')
    lines += ['','Warm observations follow16 prior calls. Transport-drop to warm growth only bounds startup contribution; it is not a causal saving. Image/text views and function/page overlaps are nonadditive. Raw host metadata remains inert; no native payload was retained/executed and no native/CLI/Test262 workload was repeated.']
    (OUT/'summary.md').write_text('\n'.join(lines)+'\n')
    print(json.dumps(dict(complete=True,scored_attempts=68,scored_workloads=17,focused_passes=6,diagnostic=report['diagnostic']['status'],output=str(OUT))))


if __name__ == '__main__':
    main()
