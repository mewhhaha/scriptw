CI40611080497: 68/68 scored attempts,17 workload checksums and6 exact native controls admitted.
Both runtime modes: layout29/manifests/Cargo producers/raw nm streams admitted; local and CI raw R Wasm SHA match. Native digests remain runner-specific.
Unscored ownership/host metadata: validated.

| Case | Phase | R text pages | R image pages without text | P+R union | Scriptc union | Extra module MiB | Extra host RX MiB |
|---|---|---:|---:|---:|---:|---:|---:|
| integer.js | after_transport_drop | 15 | 75 | 183 | 231 | -0.187500 | 2.132812 |
| integer.js | after_instantiate | 461 | 219 | 773 | 231 | 2.117188 | 2.332031 |
| integer.js | after_execution | 461 | 219 | 773 | 231 | 2.117188 | 2.332031 |
| integer.js | after_store_drop | 461 | 219 | 773 | 231 | 2.117188 | 2.332031 |
| retained-objects.js | after_transport_drop | 15 | 75 | 195 | 389 | -0.757812 | 1.953125 |
| retained-objects.js | after_instantiate | 557 | 411 | 1073 | 389 | 2.671875 | 2.328125 |
| retained-objects.js | after_execution | 557 | 411 | 1073 | 389 | 2.671875 | 2.328125 |
| retained-objects.js | after_store_drop | 557 | 411 | 1073 | 389 | 2.671875 | 2.328125 |

Warm observations follow16 prior calls. Transport-drop to warm growth only bounds startup contribution; it is not a causal saving. Image/text views and function/page overlaps are nonadditive. Raw host metadata remains inert; no native payload was retained/executed and no native/CLI/Test262 workload was repeated.
