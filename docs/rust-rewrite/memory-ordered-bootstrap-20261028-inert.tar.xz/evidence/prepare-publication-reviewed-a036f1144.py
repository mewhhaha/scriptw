"""Build private ordered-bootstrap publication candidates from inert receipts."""
from datetime import datetime, timezone
import hashlib
import json
import lzma
import os
from pathlib import Path
import re
import stat
import subprocess
import sys
import tarfile
import time

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
SOURCE = 'a036f1144ea3d3cf502d888b8a07f442837a857f'
MEASURED = '1721e1b6daf39924dabee7e85112adc2ebed4c9d'
FEATURE = '15edd3e3956f8587ad94663e4a20a7c81b862d97'
FP = '9c6ce32926290a0343955878c3d2e880f63559f6ee4afc7eb3bb6ce018c7b755'
LOCAL_FP = '2d3e3189d757b5bef454a23951d203cebf3c8282a0a8e45c8fd55ec58841a270'
NATIVE = BASE/'native-main-a036f1144'
TAIL = BASE/'tail-continued-main-a036f1144'
CI = BASE/'ci-40611080497-validated'
SCORED = BASE/'github-40611080497-scored/precompiled-evidence'
OUT = BASE/'publication-candidate-a036f1144'
STEM = 'memory-ordered-bootstrap-20261028'
PINS = {
    NATIVE/'report.json':'747bad48ffabcf859ca25a2b6cb81069b3c08b7f53bf53d7c00bc56466f76d73',
    TAIL/'report.json':'568c4cf00edde97bd12a3e2b093fc969ffacb47532bdb44def31a6bdc9d847eb',
    BASE/'tail-main-a036f1144/report.json':'416ae8f944a49b335c17de710fcb9f6ff35b9125160e976f6d490e675d86e56d',
    CI/'report.json':'8993659b61ac82a5b09a7a07df8f8502318c1855b710a649fb96402b40c255f4',
}
MAX_MEMBER,MAX_EXPANDED,MAX_COMPRESSED = 64*1024**2,768*1024**2,64*1024**2
sys.path.insert(0,str(ROOT/'scripts'))
import precompiled_comparison as p
from limited_verification import require_kernel_budget,kernel_group
from native_test_protocol import parse_inventory,result_summaries


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()


def read(path):
    path=Path(path)
    assert not path.is_symlink() and stat.S_ISREG(path.lstat().st_mode) and path.stat().st_size<=MAX_MEMBER
    return json.loads(path.read_text())


def budget(group):
    return {key:(group/key).read_text().strip() for key in ('memory.max','memory.swap.max','memory.oom.group','memory.peak','memory.events')}


def resources(value,maximum=4*1024**3):
    assert value['cpu_affinity']==[0]
    for row in (value['before'],value['after']):
        assert 0<int(row['memory.max'])<=maximum and row['memory.swap.max']=='0' and row['memory.oom.group']=='1'
    events=[dict(line.split() for line in row['memory.events'].splitlines()) for row in (value['before'],value['after'])]
    assert all(events[0][key]==events[1][key]=='0' for key in ('oom','oom_kill','oom_group_kill'))


def guard():
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==SOURCE
    assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=ROOT)
    assert all(sha(path)==digest for path,digest in PINS.items())


def streams(directory,commands):
    for row in commands:
        assert row.get('exit_code',row.get('returncode'))==0
        assert not row.get('timed_out') and not row.get('output_limit_exceeded') and not row.get('truncated_channel')
        for channel in ('stdout','stderr'):
            name=row[channel]
            assert p.safe_name(name)==row['label']+'.'+channel
            path=directory/name
            assert path.stat().st_size==row[channel+'_bytes']<=MAX_MEMBER and sha(path)==row[channel+'_sha256']


def native_admission(value):
    assert value['complete'] is True and value['source_commit']==SOURCE and value['features']==[]
    assert value['passed_disjoint_scopes']==value['executed_disjoint_passes']==value['observed_native_inventory_total']==4894
    assert value['inherited_disjoint_passes']==value['repeated_native_test_ids']==0
    assert len(value['scopes'])==len(value['plan'])==19
    resources(value); streams(NATIVE,value['commands'])
    total=0
    for scope in value['scopes']:
        label=Path(scope['binary']).parent.as_posix()
        inventory=parse_inventory((NATIVE/(label+'-inventory.stdout')).read_text())
        assert inventory==scope['inventory'] and scope['complete'] is True
        assert len(scope['passed_test_ids'])==len(set(scope['passed_test_ids']))==scope['passed']==len(inventory)
        assert set(scope['passed_test_ids'])==set(inventory)
        assert scope['cargo_producer']['features']==[] and scope['cargo_producer']['profile']['test'] is True
        executed=[]
        for command in value['commands']:
            if command['label']==label+'-focused' or command['label'].startswith(label+'-part-'):
                text=(NATIVE/command['stdout']).read_text()
                names=re.findall(r'^test ([^\r\n]+) \.\.\. ok$',text,re.M)
                expected=command['expected_test_ids']
                assert len(names)==len(set(names))==len(expected) and set(names)==set(expected)
                assert result_summaries(text)==[('ok',str(len(expected)),'0','0','0',str(len(inventory)-len(expected)))]
                assert not set(executed).intersection(names)
                executed.extend(names)
        assert len(executed)==len(inventory) and set(executed)==set(inventory)
        total+=len(inventory)
    assert total==4894


def tail_admission(value):
    assert value['source_commit']==SOURCE and value['complete'] is True and value['all_passed'] is True
    assert value['total']==value['passed']==value['selected_executions']==28 and value['inherited_js_executions']==0
    assert value['cargo_build_rerun'] is False and value['native_tests_rerun'] is False
    assert value['driver']['sha256']=='9a7a157528f81efba0f5f47457e285cac7099ef4931ad1796ed091d659bf78f6'
    assert sha(Path(value['driver']['path']))==value['driver']['sha256']
    assert value['compiler']['identity']['source_revision']==dict(kind='git-commit',commit=SOURCE)
    assert value['compiler']['identity']['source_fingerprint']==LOCAL_FP
    assert value['compiler']['identity']['executable_sha256']==value['compiler']['sha256']
    resources(value); streams(TAIL,value['commands'])
    prefix=read(BASE/'tail-main-a036f1144/report.json')
    assert prefix['complete'] is False and prefix['source_commit']==SOURCE and prefix['error_type']=='AssertionError'
    assert len(prefix['commands'])==1 and prefix['commands'][0]['label']=='cargo-product'
    resources(prefix); streams(BASE/'tail-main-a036f1144',prefix['commands'])
    ids=(TAIL/'executions').read_text().splitlines()
    assert len(ids)==len(set(ids))==28 and sha(TAIL/'executions')==value['execution_list_sha256']
    completed=[]
    for batch in value['batches']:
        listing=TAIL/batch['list_file']; snapshot=TAIL/batch['snapshot_file']
        assert sha(listing)==batch['list_sha256'] and sha(snapshot)==batch['snapshot_sha256']
        expected=listing.read_text().splitlines(); observed=read(snapshot)
        assert 0<len(expected)<=16 and len(expected)==len(set(expected))
        assert observed['compiler_identity']==value['compiler']['identity'] and observed['execution_backend']=='wasm-aot'
        assert len(observed['completed_test_ids'])==len(expected) and set(observed['completed_test_ids'])==set(expected)
        assert observed['total']==observed['passed']==len(expected) and not observed['failures'] and not observed['timeout_test_ids']
        assert observed['counts_per_outcome']==dict(Bug=0,Crash=0,NotImplemented=0,Success=len(expected))
        completed.extend(expected)
    assert len(completed)==len(set(completed))==28 and set(completed)==set(ids)
    assert len(value['selected_files'])==21
    for row in value['selected_files']:
        assert sha(TAIL/row['retained_file'])==row['sha256']
    repair=read(BASE/'tail-continuation-import-repair.json')
    assert repair['fixed_driver_sha256']==value['driver']['sha256']
    assert repair['failed_startup_receipt_created'] is False and repair['failed_startup_resource_after_available'] is False
    assert sha(BASE/'tail-continuation-import-failure.stdout')==repair['failed_startup_journal_sha256']
    return prefix,repair


def archive(files,out,start):
    total=sum(row['bytes'] for row in files.values())
    assert len(files)<=8192 and total<=MAX_EXPANDED
    path=out/(STEM+'-inert.tar.xz')
    with path.open('xb') as raw,lzma.LZMAFile(raw,'w',filters=[dict(id=lzma.FILTER_LZMA2,preset=1,dict_size=16*1024**2)]) as compressed:
        with tarfile.open(fileobj=compressed,mode='w|') as bundle:
            for name,row in sorted(files.items()):
                member=tarfile.TarInfo(name);member.mode=0o644;member.size=row['bytes']
                with row['source'].open('rb') as stream:
                    bundle.addfile(member,stream)
                assert time.monotonic()-start<=1800
    assert path.stat().st_size<=MAX_COMPRESSED
    seen,expanded=set(),0
    with tarfile.open(path,'r|xz') as bundle:
        for member in bundle:
            assert member.isfile() and member.name in files and member.name not in seen
            row=files[member.name]
            assert member.size==row['bytes']<=MAX_MEMBER
            expanded+=member.size;assert expanded<=MAX_EXPANDED
            with bundle.extractfile(member) as stream:
                assert hashlib.file_digest(stream,'sha256').hexdigest()==row['sha256']
            seen.add(member.name)
            assert time.monotonic()-start<=1800
    assert seen==set(files) and expanded==total
    return dict(file=path.name,sha256=sha(path),bytes=path.stat().st_size,expanded_bytes=expanded,member_count=len(files),
        max_member_bytes=MAX_MEMBER,max_expanded_bytes=MAX_EXPANDED,max_compressed_bytes=MAX_COMPRESSED,
        native_payloads_retained=False,roundtrip_hashes_verified=True,roundtrip_passes=1,
        retained_files=[dict(path=name,bytes=row['bytes'],sha256=row['sha256']) for name,row in sorted(files.items())])


def main():
    require_kernel_budget(1024**3)
    assert sorted(os.sched_getaffinity(0))==[0] and not OUT.exists()
    group=kernel_group();start=time.monotonic();OUT.mkdir()
    processing=dict(schema='scriptw-ordered-bootstrap-private-publication-v1',complete=False,source_commit=SOURCE,
        started_at=datetime.now(timezone.utc).isoformat(),cpu_affinity=[0],before=budget(group),
        driver=dict(path=str(Path(__file__).resolve()),sha256=sha(Path(__file__))),scope='Private inert candidate generation only; no source/docs/graphs/native execution.')
    try:
        guard()
        native,tail,ci=read(NATIVE/'report.json'),read(TAIL/'report.json'),read(CI/'report.json')
        native_admission(native);prefix,repair=tail_admission(tail)
        assert ci['complete'] is True and ci['source_commit']==MEASURED and ci['main_source_commit']==SOURCE
        assert ci['feature_source_commit']==FEATURE and ci['source_fingerprint']==FP
        assert ci['scored_all_attempts_ok'] is True and ci['scored_attempts']==68 and ci['scored_workloads']==17
        assert ci['diagnostic']['status']=='validated' and len(ci['diagnostic']['cases'])==4
        assert ci['static']['raw_wasm_equal_both_modes'] is True
        resources(ci,1024**3)
        campaign,table=p.load_report(SCORED/'report.json')
        assert campaign['source_commit']==MEASURED and campaign['source_fingerprint']==FP and table==ci['scored_table']
        assert len(campaign['attempts'])==68 and all(row['status']=='ok' for row in campaign['attempts'])
        for name,row in ci['inputs'].items():
            path=Path(name)
            assert path.stat().st_size==row['bytes'] and sha(path)==row['sha256']
        portable=ci['static']['ci']['variants']['Portable']
        assert portable['initializer_plus_new_helpers_native_bytes']==563304
        assert ci['static']['ci']['reported_reference']['realm_initializer_native_bytes']==765194
        ratios=[row['runtimes']['scriptw']['rss_mib']/row['runtimes']['scriptc']['rss_mib'] for row in table]
        files,excluded,aliases={},{},[]
        def add(name,path):
            path=Path(path)
            assert name not in files and not name.startswith('/') and '..' not in Path(name).parts
            assert not path.is_symlink() and stat.S_ISREG(path.lstat().st_mode)
            assert path.stat().st_size<=MAX_MEMBER
            with path.open('rb') as stream: magic=stream.read(8)
            assert not magic.startswith((b'\x7fELF',b'MZ',b'SWRTZ001',b'SCRWRB',b'SCRWEP',b'SCRWWA'))
            if magic==b'SCRWNR01':assert path.stat().st_size<=4096
            files[name]=dict(source=path,bytes=path.stat().st_size,sha256=sha(path))
        excluded_paths={NATIVE/scope['binary']:dict(reason='native test executable',sha256=scope['executable_sha256']) for scope in native['scopes']}
        excluded_paths[Path(tail['compiler']['path'])]=dict(reason='frozen CLI executable',sha256=tail['compiler']['sha256'])
        for directory,label in [(NATIVE,'native'),(TAIL,'tail')]:
            for path in sorted(directory.rglob('*')):
                if not path.is_file():continue
                if path in excluded_paths:
                    excluded[str(path.relative_to(BASE))]=dict(excluded_paths[path],bytes=path.stat().st_size);continue
                add(label+'/'+path.relative_to(directory).as_posix(),path)
        assert len(excluded)==20
        canonical_cargo=SCORED/'cargo.jsonl'
        for name,row in ci['inputs'].items():
            path=Path(name)
            if path==BASE/'github-40611080497-scored/precompiled-cargo.jsonl':
                assert sha(path)==sha(canonical_cargo)
                aliases.append(dict(original_path=name,archive_member='evidence/'+canonical_cargo.relative_to(BASE).as_posix(),bytes=row['bytes'],sha256=row['sha256']));continue
            alias='evidence/'+path.relative_to(BASE).as_posix() if path.is_relative_to(BASE) else 'reproduce/'+path.relative_to(ROOT).as_posix()
            add(alias,path)
        additions=['ci-40611080497-validated/report.json','ci-40611080497-validated/summary.md',
            'ci-40611080497-validated/verify-ordered-bootstrap-ci.py','ci-40611080497-validated/record-ordered-bootstrap-static.py',
            'validate-ci-40611080497-reviewed.py','validate-ci-40611080497-launch.json',
            'validate-ci-40611080497.stdout','validate-ci-40611080497.stderr','validate-ci-40611080497-retry.stdout','validate-ci-40611080497-retry.stderr',
            'native-reviewed-main-a036f1144.py','native-main-a036f1144-launch.json','native-main-a036f1144-journal.stdout',
            'tail-main-a036f1144-launch.json','tail-continued-main-a036f1144-launch.json','tail-final-main-a036f1144-launch.json',
            'continue-tail-reviewed-main-a036f1144.py','continue-tail-import-fixed-main-a036f1144.py',
            'tail-continuation-import-failure.stdout','tail-continuation-import-repair.json',
            'source-bindings-main-a036f1144.py','source-bindings-ci-log-bound.py',
            'github-run-40597276657-failed.json','ci-failed-40597276657.stdout','ci-failed-40597276657.stderr','ci-failed-40597276657-log-receipt.json',
            'github-run-40600270997-failed.json','ci-failed-40600270997.stdout','ci-failed-40600270997.stderr','ci-failed-40600270997-log-receipt.json',
            'github-run-40605789461-failed.json','ci-failed-40605789461.stdout','ci-failed-40605789461.stderr',
            'github-40605789461-checks-static/ordered-bootstrap-static/report.json']
        for name in additions:
            alias='evidence/'+name
            if alias not in files:add(alias,BASE/name)
        old_pattern=ROOT/'target/memory-module-ownership-20261027-evidence/validate-ci-40594118953.py'
        add('reproduce/ownership-validator-pattern.py',old_pattern)
        add('reproduce/publication-driver.py',Path(__file__).resolve())
        for name in ('native_test_protocol.py','limited_verification.py'):
            add('reproduce/scripts/'+name,ROOT/'scripts'/name)
        previous=ROOT/'docs/rust-rewrite/memory-module-ownership-20261027.json'
        previous_record=read(previous)
        reference=dict(file=previous.name,sha256=sha(previous),inherited_js_executions=0,
            interpretation='Historical diagnostic checkpoint only. Its6307 selected JS executions are not inherited or credited by this changed runtime batch.')
        add('reference/'+previous.name,previous)
        archive_record=archive(files,OUT,start)
        scopes=[dict(package=s['package'],target=s['target'],kind=s['kind'],passed=s['passed'],
            inventory_count=len(s['inventory']),executable_sha256=s['executable_sha256']) for s in native['scopes']]
        resources_origins=dict(native=dict(before=native['before'],after=native['after']),
            stopped_product_build=dict(complete=False,before=prefix['before'],after=prefix['after']),
            failed_continuation_import=dict(before=None,after=None,receipt_created=False,resource_after_available=False,journal_sha256=repair['failed_startup_journal_sha256']),
            completed_tail=dict(before=tail['before'],after=tail['after']),ci_inert_processing=dict(before=ci['before'],after=ci['after']))
        static_view=json.loads(json.dumps(ci['static']))
        for key in ('initializer_delta_from_reported_reference_bytes','initializer_plus_new_helpers_delta_from_reported_reference_bytes'):
            static_view['ci']['variants']['NativeHost'].pop(key,None)
        static_view['native_host_reference_comparison']='No historical NativeHost comparison is published; original static receipts remain unchanged in the archive.'
        document=dict(schema='scriptw-ordered-bootstrap-evidence-v1',recorded_at=datetime.now(timezone.utc).isoformat(),
            verified_source_commit=SOURCE,compiler_feature_source_commit=FEATURE,measured_source_commit=MEASURED,runtime_layout=29,
            source_bindings=dict(clean_compiler_fingerprint=FP,local_compiler_fingerprint=LOCAL_FP,
                main_equivalence_sha256=sha(BASE/'source-bindings-main-a036f1144-equivalence.json'),
                measured_equivalence_sha256=sha(BASE/'source-bindings-ci-log-bound-equivalence.json')),
            native=dict(report_sha256=PINS[NATIVE/'report.json'],passed=4894,targets=19,focused_passes_included=6,
                repeated_test_ids=0,inherited_passes=0,scopes=scopes),
            product_and_targeted_conformance=dict(stopped_build_report_sha256=PINS[BASE/'tail-main-a036f1144/report.json'],
                tail_report_sha256=PINS[TAIL/'report.json'],executed_tail_driver=tail['driver'],producer_authority=tail['producer_authority'],
                compiler=tail['compiler'],selected_families=tail['families'],source_files=14,pinned_inputs=21,
                selected_executions=28,passed=28,inherited_js_executions=0,full_test262_run=False,
                failures=dict(stopped_product_prefix=tail['original_prefix'],continuation_startup_repair=repair)),
            ci=dict(run=40611080497,validated_report_sha256=PINS[CI/'report.json'],scored_attempts=68,workloads=17,all_attempts_ok=True,
                scored_report_sha256=sha(SCORED/'report.json'),table=table,rss_ratio_min=min(ratios),rss_ratio_max=max(ratios)),
            static=static_view,diagnostic=ci['diagnostic'],page_budgets=ci['page_budgets'],
            static_portable_comparison=dict(current_initializer_plus_new_helpers_native_bytes=563304,historical_portable_initializer_native_bytes=765194,
                reduction_bytes=765194-563304,reduction_fraction=(765194-563304)/765194,
                scope='Portable static native symbol extents only; historical layout28 reference. No NativeHost baseline substitution or causal RSS/speed inference.'),
            resource_origins=resources_origins,prior_checkpoint=reference,archive=archive_record,input_content_aliases=aliases,
            historical_failures=[dict(run=run,metadata_sha256=sha(BASE/('github-run-'+str(run)+'-failed.json'))) for run in (40597276657,40600270997,40605789461)],
            interpretation='Native 4894 and original fresh 28 JS executions pass. Current CI 68 attempts/17 checksums and four unscored captures are separate evidence. Warm snapshots follow 16 prior calls; page and function overlaps are nonadditive. No full-Test262, inherited 6307, causal RSS/speed saving, parity or goal-completion claim. V8/status cohorts are separate and unchanged. Section diagnostic CI40611737589 is not included.')
        lines=['# Ordered Realm bootstrap checkpoint','',
            'Source `'+SOURCE+'` passes 4894 native tests across 19 affected targets and 28 fresh executions from the original Iterator.prototype.constructor and Array.prototype.values families. This is not a full Test262 run; no prior 6307 executions are inherited.','',
            'The default product CLI build passed. Its original receipt remains incomplete after a producer-path assertion; a separate startup import failure has no after counters. The completed continuation reads the tracked Cargo bin declaration and binds its actual executed frozen driver. All failed/incomplete receipts remain preserved.','',
            'CI40611080497 (`'+MEASURED+'`) passes 68/68 attempts across 17 paired workload checksums plus six exact native controls. Current RSS ratios are '+format(min(ratios),'.9f')+'–'+format(max(ratios),'.9f')+'. V8 figures/status are separate and unchanged.','',
            'Portable RealmInit plus its new constructor/deferred helpers occupies 563304 native bytes versus the historical Portable initializer 765194: 201890 bytes (26.4%) smaller. This static comparison establishes no causal RSS or speed saving. Both local/CI runtime modes have equal raw Wasm hashes; runner-specific native digests differ.','',
            '| Case | Warm R text pages | Warm R other image pages | Warm P+R union | Scriptc union | Extra module MiB | Extra host RX MiB |',
            '|---|---:|---:|---:|---:|---:|---:|']
        for case in ci['page_budgets']:
            warm=case['phases'][1]
            lines.append('| '+case['file']+' | '+str(warm['r_text_present_pages'])+' | '+str(warm['r_image_pages_without_text'])+' | '+str(warm['scriptw_module_union_present_pages'])+' | '+str(warm['scriptc_module_union_present_pages'])+' | '+format(warm['extra_scriptw_module_present_bytes']/1024**2,'.6f')+' | '+format(warm['extra_scriptw_host_rx_present_bytes']/1024**2,'.6f')+' |')
        lines+=['','Warm captures follow 16 prior calls; transport-drop-to-warm growth only bounds startup contribution. Shared boundary, image/text and function/page counts are nonadditive. Presence does not prove execution or causality.','',
            'The inert archive retains every current native/test inventory stream, targeted snapshot and pinned input, scored observation, four unscored ownership/symbol captures, manifests/nm output, source proofs, executed drivers and failure lineage. It excludes 19 native test executables, the frozen CLI and all packed/native runtime payloads. Public README/graphs/contracts remain unchanged by candidate generation.']
        guard()
        assert all(sha(row['source'])==row['sha256'] for row in files.values())
        after=budget(group);resources(dict(cpu_affinity=[0],before=processing['before'],after=after),1024**3)
        processing.update(complete=True,after=after,finished_at=datetime.now(timezone.utc).isoformat(),seconds=time.monotonic()-start,
            excluded_executables=excluded)
        document['publication_processing']=processing
        (OUT/(STEM+'.json')).write_text(json.dumps(document,indent=2)+'\n')
        (OUT/(STEM+'.md')).write_text('\n'.join(lines)+'\n')
    except BaseException as error:
        processing.update(error=repr(error),error_type=type(error).__name__,after=budget(group),finished_at=datetime.now(timezone.utc).isoformat())
        raise
    finally:
        (OUT/'processing.json').write_text(json.dumps(processing,indent=2)+'\n')
    print(json.dumps(dict(complete=True,output=str(OUT),archive_sha256=archive_record['sha256'],expanded_bytes=archive_record['expanded_bytes'])))


if __name__=='__main__':main()
