#!/usr/bin/env python3
"""Read historical Date JSON/source records; never invoke a product or Node."""
import argparse
import ast
import copy
import hashlib
import json
from pathlib import Path
import statistics

ROOT = Path('/workspace/scriptw')
OUT = Path(__file__).resolve().parent
DATE = ROOT / 'target/performance-date-demand-20261031/measurement'


def load(path):
    return json.loads(path.read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main(receipt_name):
    script = OUT / 'cohort.py'
    tree = ast.parse(script.read_text())
    names = {'require', 'check_report_identity', 'statistics_row', 'producer_header',
             'retained_wrapper', 'observations', 'image_group', 'score', 'validate_cache_policy'}
    definitions = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name in names]
    assert {node.name for node in definitions} == names
    namespace = dict(Path=Path, statistics=statistics, SAMPLES=21, WARMUPS=10,
                     NORMAL_CACHE=OUT.parent / 'normal-cache',
                     DATE_FILES=['date-first-descriptor.js', 'date-first-epoch.js', 'date-repeated-256.js'])
    exec(compile(ast.Module(body=definitions, type_ignores=[]), str(script), 'exec'), namespace)
    plan = load(OUT / 'sources/manifest.json')
    cases = [*plan['execution'], plan['startup']]
    hashes = load(OUT / 'source-hashes.json')
    assert hashes == load(DATE / 'source-hashes.json')
    for name, expected in hashes.items():
        assert sha(OUT / 'sources' / name) == expected
        assert (OUT / 'sources' / name).read_bytes() == (DATE / 'sources' / name).read_bytes()
    historical = load(DATE / 'product-lock.json')
    assert historical['source_hashes'] == hashes
    groups = dict(original=cases, **{'retained-canonical': plan['execution'][:17],
                                   'retained-date': [*plan['execution'][17:], plan['startup'], *plan['execution'][4:17]]})
    producers, producer_inputs = {}, []
    wrappers = 0
    for label in ['baseline', 'candidate']:
        for group, selected in groups.items():
            folder = DATE / f'images-{label}-{group}'
            report = load(folder / 'producer.json')
            namespace['producer_header'](report, label, group, historical, selected,
                                         sha(DATE / ('prepared-' + group) / 'manifest.json'))
            producer_inputs.append(str((folder / 'producer.json').relative_to(ROOT)))
            if group.startswith('retained-'):
                for case in report['cases']:
                    source, derived = folder / case['original_source_file'], folder / case['derived_source_file']
                    assert sha(source) == case['original_source_sha256'] == hashes[case['file']]
                    assert sha(derived) == case['derived_source_sha256']
                    assert derived.read_text() == namespace['retained_wrapper'](source.read_text())
                    assert load(folder / Path(case['image']).with_suffix('.json')) == case
                    wrappers += 1
            producers[label, group] = report
    namespace['producer'] = lambda label, group, lock: producers[label, group]
    order = ['baseline', 'candidate', 'candidate', 'baseline',
             'candidate', 'baseline', 'baseline', 'candidate']
    checked, parent_checked = 0, 0
    parent = dict(source_hashes=hashes, baseline=dict(
        identity=load(OUT.parent / 'baseline-identity.json'),
        products=load(OUT.parent / 'baseline-products.json')))
    assert parent['baseline']['identity'] == historical['candidate']['identity']
    for index, label in enumerate(order):
        for case in cases:
            for boundary in ['original', 'retained', 'ordinary']:
                path = DATE / f'balanced-r{index}-{label}-{boundary}-{case["file"]}.stdout'
                report = load(path)
                samples = namespace['observations'](report, boundary, case, label, historical)
                namespace['statistics_row']([namespace['score'](sample, boundary) for sample in samples])
                if boundary == 'original':
                    namespace['statistics_row']([sample['process_snapshots']['after_execution']['rss_bytes']
                                                 for sample in samples])
                checked += 1
                if label == 'candidate':
                    namespace['producer'] = lambda side, group, lock: producers['candidate', group]
                    namespace['observations'](report, boundary, case, 'baseline', parent)
                    parent_checked += 1
                    namespace['producer'] = lambda side, group, lock: producers[side, group]
    assert checked == 504 and parent_checked == 252
    policy = dict(path=str(OUT.parent / 'normal-cache'),
                  environment_cache_root=str(OUT.parent / 'normal-cache'),
                  resolved_scriptw_cache_dir=str(OUT.parent / 'normal-cache'),
                  filesystem='overlayfs:794c7630')
    namespace['validate_cache_policy'](policy)
    rejected = []
    for filesystem in ['tmpfs:1021994', 'ramfs:858458f6', 'ext2/ext3:ef53']:
        altered = copy.deepcopy(policy)
        altered['filesystem'] = filesystem
        try:
            namespace['validate_cache_policy'](altered)
        except ValueError:
            rejected.append(filesystem)
        else:
            raise AssertionError('non-overlay substrate admitted')
    old = load(DATE / 'balanced-r0-baseline-original-integer.js.stdout')
    case = next(case for case in cases if case['file'] == 'integer.js')
    try:
        namespace['observations'](old, 'original', case, 'baseline', parent)
    except ValueError:
        rejected.append('older c098 product as the new DATE-parent baseline')
    else:
        raise AssertionError('wrong accepted-parent fingerprint admitted')
    # Historical Node evidence is referenced as metadata only. No Node binary or
    # archived native payload is inspected, hashed, copied, loaded or executed.
    node = load(DATE / 'reference-node-verification.json')
    assert node['status'] == 'Independently verified' and node['source_hashes'] == hashes
    assert node['cases'] == [case['file'] for case in cases]
    assert Path(receipt_name).name == receipt_name and receipt_name.endswith('.json')
    receipt = dict(schema='scriptw-append-key-summary-inert-compatibility-v1',
                   status='passed historical JSON/source validator audit; LAZY preparation/measurement unexecuted',
                   driver_sha256=sha(script), source_hash_inventory=hashes,
                   historical_producer_json=producer_inputs, historical_consumer_records=checked,
                   existing_DATE_parent_records_checked_as_new_baseline=parent_checked,
                   retained_exact_wrappers_and_sidecars=wrappers,
                   normal_cache_policy_inert_checks=dict(valid=policy, rejected=rejected),
                   inherited_node_goldens=dict(path=str((DATE / 'reference-node-verification.json').relative_to(ROOT)),
                                              sha256=sha(DATE / 'reference-node-verification.json'),
                                              cases=21, new_node_execution=False),
                   limits='Historical Date/tmpfs records validate protocol and goldens only. They are not LAZY measurements, normal-overlay qualification, or timing baselines. No native product/image bytes read or hashed.')
    with (OUT / receipt_name).open('x') as stream:
        stream.write(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(dict(status=receipt['status'], historical_consumers=checked,
                          DATE_parent_records=parent_checked, wrappers=wrappers,
                          new_native_or_node_execution=False)))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', default='date-inert-compatibility-fresh.json')
    main(parser.parse_args().output)
