"""Source/policy-only draft check: no product, image, child, Node or cache probe."""
from pathlib import Path
import ast
import copy
import hashlib
import json
import statistics

ROOT = Path('/workspace/scriptw')
OUT = Path(__file__).resolve().parent
APP = ROOT / 'target/performance-append-key-lazy-summary-20261031/measurement'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def functions(tree):
    return {node.name: node for node in tree.body if isinstance(node, ast.FunctionDef)}


def main():
    script = OUT / 'cohort.py'
    tree = ast.parse(script.read_text())
    prior = functions(ast.parse((APP / 'cohort.py').read_text()))
    current = functions(tree)
    unchanged = ['plain_file', 'products', 'check_report_identity', 'statistics_row', 'inputs',
                 'source_groups', 'image_group', 'image_directory', 'retained_wrapper',
                 'producer_header', 'producer', 'arguments', 'observations', 'score',
                 'boundary_scope', 'policy_key', 'resources', 'invoke', 'prepare', 'measure',
                 'node_reference']
    for name in unchanged:
        assert ast.dump(prior[name], include_attributes=False) == ast.dump(current[name], include_attributes=False), name
    # Execute only literal/path assignments and three pure validator definitions.
    # Do not import the cohort module or invoke any environment/product function.
    namespace = dict(Path=Path, __file__=str(script), __name__='inert_source_namespace')
    assignments = [node for node in tree.body if isinstance(node, ast.Assign)]
    definitions = [current[name] for name in ['require', 'validate_cache_policy', 'policy_key']]
    exec(compile(ast.Module(body=assignments + definitions, type_ignores=[]), str(script), 'exec'), namespace)
    normal = OUT.parent / 'normal-cache'
    assert namespace['ROOT'] == ROOT and namespace['OUT'] == OUT
    assert namespace['SOURCES'] == OUT / 'sources'
    assert namespace['CANDIDATE'] == OUT.parent / 'candidate'
    assert namespace['BASELINE'] == ROOT / 'target/performance-date-demand-20261031/candidate'
    assert namespace['NORMAL_CACHE'] == normal
    assert namespace['DATE_PARENT'] == 'a35adbcb61dbc57b4ee44dd1527019358deb137b11ae559de7d0d4b4a860b480'
    assert namespace['DATE_PARENT_SOURCE_COMMIT'] == '7c47e38274c9645b6701552c87d38362b2bfbcd5'
    policy = dict(path=str(normal), environment_cache_root=str(normal),
                  resolved_scriptw_cache_dir=str(normal), filesystem='overlayfs:794c7630')
    namespace['validate_cache_policy'](policy)
    rejected = []
    for key, value in [('filesystem', 'tmpfs:1021994'), ('filesystem', 'ramfs:858458f6'),
                       ('filesystem', 'ext2/ext3:ef53'),
                       ('path', str(APP.parent / 'normal-cache')),
                       ('environment_cache_root', str(APP.parent / 'normal-cache')),
                       ('resolved_scriptw_cache_dir', str(APP.parent / 'normal-cache')),
                       ('environment_cache_root', 'normal-cache')]:
        altered = dict(policy, **{key: value})
        try:
            namespace['validate_cache_policy'](altered)
        except ValueError:
            rejected.append(dict(field=key, value=value))
        else:
            raise AssertionError(('wrong substrate/cache binding admitted', key, value))
    snapshot = dict(cloud_budget_bytes=32 * 1024**3, affinity=[0],
                    environment=dict(SCRIPTW_CACHE_DIR=str(normal)),
                    cgroup={key: 'same' for key in ['memory.max', 'memory.swap.max', 'memory.oom.group', 'cpu.max']})
    wrong_child = copy.deepcopy(snapshot)
    wrong_child['environment']['SCRIPTW_CACHE_DIR'] = str(APP.parent / 'normal-cache')
    assert namespace['policy_key'](snapshot) != namespace['policy_key'](wrong_child)
    # The optional historical auditor's isolated namespace must use I31 too.
    auditor_tree = ast.parse((OUT / 'audit-date-records.py').read_text())
    auditor_main = functions(auditor_tree)['main']
    isolated = next(node.value for node in auditor_main.body if isinstance(node, ast.Assign)
                    and any(isinstance(target, ast.Name) and target.id == 'namespace' for target in node.targets))
    auditor_namespace = eval(compile(ast.Expression(body=isolated), '<inert-auditor-namespace>', 'eval'),
                             dict(Path=Path, statistics=statistics, OUT=OUT))
    assert auditor_namespace['NORMAL_CACHE'] == normal
    expected = json.loads((OUT / 'source-hashes.json').read_text())
    assert set(expected) == {path.name for path in (OUT / 'sources').iterdir()}
    for name, digest in expected.items():
        assert sha(OUT / 'sources' / name) == sha(APP / 'sources' / name) == digest
    plan = json.loads((OUT / 'plan.json').read_text())
    assert plan['candidate']['cohort'] == 'I31' and plan['candidate']['expected_runtime_abi'] == 45
    assert plan['baseline']['expected_runtime_abi'] == 42
    assert plan['candidate']['directory'] == str(namespace['CANDIDATE'])
    assert plan['cache']['required_path'] == str(normal)
    inherited = json.loads((OUT / 'date-inert-compatibility.json').read_text())
    assert inherited['source_hash_inventory'] == expected
    assert sha(OUT / 'date-inert-compatibility.json') == sha(APP / 'date-inert-compatibility.json')
    record = dict(schema='scriptw-i31-presence-source-draft-audit-v1',
                  status='passed source-only AST/path/pure-policy checks',
                  unchanged_validator_function_bodies=unchanged,
                  namespace=dict(root=str(ROOT), out=str(OUT), candidate=str(namespace['CANDIDATE']),
                                 baseline=str(namespace['BASELINE']), normal_cache=str(normal),
                                 historical_auditor_normal_cache=str(auditor_namespace['NORMAL_CACHE'])),
                  pure_cache_policy=dict(valid=policy, rejected=rejected,
                                         wrong_child_cache_environment_detected=True),
                  inherited_APP_compatibility_receipt=dict(path='date-inert-compatibility.json',
                                                         sha256=sha(OUT / 'date-inert-compatibility.json')),
                  source_cases=21, source_files_with_manifest=22,
                  driver_sha256=sha(script),
                  limits='No cohort import/entrypoint, product/identity/image read or hash, native/Node child, filesystem/cache query, full historical replay or candidate binding/preparation. Pure synthetic policies check code only; they are not a normal-overlay qualification.')
    with (OUT / 'source-draft-audit.json').open('x') as stream:
        stream.write(json.dumps(record, indent=2) + '\n')
    print(json.dumps(dict(status=record['status'], source_cases=21,
                          unchanged_validators=len(unchanged), product_or_child_execution=False)))


if __name__ == '__main__':
    main()
