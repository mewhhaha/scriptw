export function run() {
(function workload() {
  var D = Date;
  var epoch = new D(0);
  var leap = new D(D.UTC(2004, 1, 29, 12, 34, 56, 789));
  print(String(epoch.getTime()));
  print(epoch.toUTCString());
  print(String(leap.getTime()));
  print(String(leap.getUTCFullYear()) + ":" + String(leap.getUTCMonth()) + ":" + String(leap.getUTCDate()) + ":" + String(leap.getUTCHours()) + ":" + String(leap.getUTCMinutes()) + ":" + String(leap.getUTCSeconds()) + ":" + String(leap.getUTCMilliseconds()));
})();

}
