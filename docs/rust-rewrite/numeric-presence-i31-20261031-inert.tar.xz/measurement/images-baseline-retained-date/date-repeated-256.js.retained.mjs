export function run() {
(function workload() {
  var sum = 0;
  for (var i = 0; i < 256; i++) {
    var stamp = Date.UTC(2000 + (i % 23), i % 12, 1 + (i % 28), i % 24, i % 60, i % 60, i);
    var value = new Date(stamp);
    sum += value.getUTCFullYear() + value.getUTCMonth() + value.getUTCDate() + value.getUTCHours() + value.getUTCMinutes() + value.getUTCSeconds() + value.getUTCMilliseconds();
  }
  print(String(sum));
  print(new Date(0).toUTCString());
})();

}
