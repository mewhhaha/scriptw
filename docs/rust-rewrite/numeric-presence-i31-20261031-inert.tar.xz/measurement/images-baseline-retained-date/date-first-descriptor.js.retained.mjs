export function run() {
(function workload() {
  var descriptor = Object.getOwnPropertyDescriptor(globalThis, "Date");
  var D = descriptor.value;
  print(D.name);
  print(String(D.length));
  print(String(descriptor.writable) + ":" + String(descriptor.enumerable) + ":" + String(descriptor.configurable));
  print(String(D.prototype.constructor === D));
  print(String(D.prototype.toUTCString === D.prototype.toGMTString));
})();

}
