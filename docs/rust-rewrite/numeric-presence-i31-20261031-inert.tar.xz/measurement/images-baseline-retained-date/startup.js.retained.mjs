export function run() {
print("scriptw-startup-ok");

}
