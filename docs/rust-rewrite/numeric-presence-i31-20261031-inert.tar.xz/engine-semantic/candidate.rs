use scriptw_engine::{
    CompileOptions, Engine, ExecutionBackend, HostSurfacePolicy, ObservedCompletion, RealmBuilder,
    RunOptions, SnapshotLimits, SnapshotOutcome,
};
use scriptw_runtime::rooted_snapshot::{SnapshotDescriptor, SnapshotKey, SnapshotValue};

fn check(source: &str) {
    scriptw_engine::configure_compilation_jobs(1).unwrap();
    for directive in ["", "'use strict';"] {
        let result = Engine::new(RealmBuilder::new().build())
            .observe_script(
                &format!("{directive}function assert(v,m){{if(!v)throw new Error(m);}}{source}"),
                CompileOptions {
                    host_surface_policy: HostSurfacePolicy::Test262,
                    ..CompileOptions::default()
                },
                RunOptions {
                    backend: ExecutionBackend::WasmAot,
                    timeout_ms: Some(30_000),
                    ..RunOptions::default()
                },
            )
            .unwrap();
        assert_eq!(result.backend_used, ExecutionBackend::WasmAot);
        assert!(
            matches!(result.completion, ObservedCompletion::Normal(_)),
            "{:?}\n{source}",
            result.completion
        );
    }
}

#[test]
fn number_bits_holes_and_bitmap_word_growth_remain_independent() {
    check(
        r#"
var a=[NaN,-0,Infinity,-Infinity,1.25,,7];
for(var i=7;i<258;i++)a[i]=i+0.5;
delete a[0];delete a[63];delete a[64];delete a[127];delete a[255];
assert(!(0 in a) && !(5 in a) && !(63 in a) && !(64 in a) && !(127 in a) && !(255 in a),'independent hole bitmap');
a[0]=NaN;a[64]=-0;a[127]=Infinity;a[255]=-Infinity;gc();
assert(Number.isNaN(a[0]) && Object.is(a[1],-0) && Object.is(a[64],-0),'all Number bits retained');
assert(a[2]===Infinity && a[3]===-Infinity && a[127]===Infinity && a[255]===-Infinity && a[257]===257.5,'growth and replacement');
assert(a.length===258 && !(63 in a),'delete never changes length');
var keys=Object.keys(a);assert(keys.length===256 && keys[0]==='0' && keys[keys.length-1]==='257','occupied keys only');
a[5]=undefined;assert(5 in a && a[5]===undefined && !(63 in a) && Object.is(a[64],-0),'nonnumber transition preserves present undefined and holes');
for(var j=0;j<258;j++)delete a[j];gc();a[0]=-0;assert(Object.is(a[0],-0) && Object.keys(a).join(',')==='0','reuse retired backing');
"#,
    );
}

#[test]
fn array_iteration_presence_keeps_live_own_and_inherited_semantics() {
    check(
        r#"
var a=[-0,1,2,,NaN], gets=0, seen=[], proto=Object.create(Array.prototype);
Object.defineProperty(proto,'2',{value:22,configurable:true});
Object.setPrototypeOf(a,proto);
var result=a.map(function(value,index){
  seen.push(index,value);
  if(index===0){
    Object.defineProperty(a,'1',{get:function(){gets++;gc();return undefined;},configurable:true});
    delete a[2];
  }
  return value;
});
assert(seen.length===8 && seen[0]===0 && Object.is(seen[1],-0),'first numeric own value');
assert(seen[2]===1 && seen[3]===undefined && gets===1,'accessor Get runs once after presence');
assert(seen[4]===2 && seen[5]===22 && seen[6]===4 && Number.isNaN(seen[7]),'later presence sees deletion and prototype');
assert(Object.is(result[0],-0) && 1 in result && result[1]===undefined && result[2]===22 && !(3 in result) && Number.isNaN(result[4]),'map preserves holes and Number bits');
var b=[-0,,NaN], bp=Object.create(Array.prototype);
Object.defineProperty(bp,'1',{value:7,configurable:true});Object.setPrototypeOf(b,bp);
var copy=b.slice();assert(Object.is(copy[0],-0) && copy[1]===7 && Number.isNaN(copy[2]),'slice copies inherited indices');
var holes=[1,,3].slice();assert(holes.length===3 && !(1 in holes),'slice retains an absent index');
var wide={length:4294967296};wide['4294967295']=17;
assert(Array.prototype.indexOf.call(wide,17,4294967295)===4294967295,'generic indices above Array index range');
"#,
    );
}

#[test]
fn array_iteration_presence_preserves_proxy_traps_and_own_shadowing() {
    check(
        r#"
var inheritedHas=[],a=[5,,7],proto=new Proxy(Array.prototype,{
  has:function(target,key){inheritedHas.push(key);return Reflect.has(target,key);}
});Object.setPrototypeOf(a,proto);
var calls=0;assert(a.every(function(){calls++;return true;}) && calls===2,'own data and hole iteration');
assert(inheritedHas.join(',')==='1','own indices never consult prototype has trap');
var events=[],target=[3,,5],proxy=new Proxy(target,{
  has:function(t,k){events.push('has:'+k);return Reflect.has(t,k);},
  get:function(t,k,r){if(k!=='length' && k!=='every')events.push('get:'+k);return Reflect.get(t,k,r);}
});
assert(Array.prototype.every.call(proxy,function(){return true;}),'Proxy array iteration result');
assert(events.join(',')==='has:0,get:0,has:1,has:2,get:2','Proxy has precedes Get and visits holes');
var error={},visited=0,abrupt=new Proxy([1,2],{
  has:function(t,k){if(k==='1')throw error;return Reflect.has(t,k);}
});
var caught=false;try{Array.prototype.every.call(abrupt,function(){visited++;return true;});}catch(e){caught=e===error;}
assert(caught && visited===1,'abrupt Proxy has propagates before callback');
"#,
    );
}

#[test]
fn inherited_setters_distinct_receivers_and_proxy_traps_keep_set_semantics() {
    check(
        r#"
var calls=[],a=[11],proto=Object.create(Array.prototype);
Object.defineProperty(proto,'1',{set:function(v){calls.push(this,v);gc();},configurable:true});Object.setPrototypeOf(a,proto);
assert(a.push(22)===2 && calls.length===2 && calls[0]===a && calls[1]===22 && !Object.prototype.hasOwnProperty.call(a,'1'),'push sees inherited setter');
var receiver={};assert(Reflect.set(a,'0',33,receiver) && receiver[0]===33 && a[0]===11,'distinct receiver is not direct own write');
var seen=[],p=new Proxy(a,{set:function(t,k,v,r){seen.push(k,v,r);return Reflect.set(t,k,v,r);},deleteProperty:function(t,k){seen.push('delete',k);return Reflect.deleteProperty(t,k);}});
p[0]=44;assert(a[0]===44 && seen[0]==='0' && seen[1]===44 && seen[2]===p,'actual proxy set trap');
delete p[0];assert(!(0 in a) && seen[3]==='delete' && seen[4]==='0','actual proxy delete trap');
var b=[1],key={};key[Symbol.toPrimitive]=function(h){assert(h==='string','key hint');b[0]={mark:7};gc();return '0';};
b[key]=5;assert(b[0]===5,'key effects precede storage guard');
var error={},c=[-0,NaN],cp=Object.create(Array.prototype);Object.defineProperty(cp,'2',{get:function(){gc();throw error;},configurable:true});Object.setPrototypeOf(c,cp);c.length=3;
var caught=false;try{c[2];}catch(e){caught=e===error;}assert(caught && Object.is(c[0],-0) && Number.isNaN(c[1]),'inherited abrupt getter preserves exception and packed roots');
"#,
    );
}

#[test]
fn cold_descriptors_accessors_freeze_and_shrink_keep_actual_mutable_records() {
    check(
        r#"
var token={},a=[0,1,2,3,4,5,6,7];Object.defineProperty(a,'3',{value:-0,writable:false,enumerable:false,configurable:false});
assert(Object.is(a[3],-0) && !Reflect.set(a,'3',8),'changed descriptor survives packed transition');
var receiver={token:token};Object.defineProperty(a,'6',{get:function(){gc();return this.token;},configurable:true,enumerable:true});
assert(Reflect.get(a,'6',receiver)===token,'cold accessor preserves receiver and GC roots');
var result=Reflect.defineProperty(a,'length',{value:1,writable:false});
assert(result===false && a.length===4 && !(4 in a) && !(6 in a) && Object.is(a[3],-0),'descending shrink rolls back at nonconfigurable entry');
assert(Object.getOwnPropertyDescriptor(a,'length').writable===false,'failed shrink final readonly length');
var b=[NaN,-0,2];Object.seal(b);assert(Reflect.set(b,'1',3) && !Reflect.deleteProperty(b,'1'),'seal retains writable only');
Object.freeze(b);assert(!Reflect.set(b,'1',4) && !Reflect.defineProperty(b,'0',{value:1}) && Number.isNaN(b[0]),'freeze prevents packed writes');
"#,
    );
}

#[test]
fn far_indices_and_whole_value_transitions_are_occupied_bounded_and_rooted() {
    check(
        r#"
var token={mark:9},symbol=Symbol('s'),a=new Array(4294967295);
a[0]=NaN;a[7]=-0;a[4294967294]=Infinity;gc();
assert(a.length===4294967295 && Number.isNaN(a[0]) && Object.is(a[7],-0) && a[4294967294]===Infinity,'far index transition never allocates logical extent');
a[7]=token;a[11]=symbol;a[13]=7n;gc();
assert(a[7]===token && a[11]===symbol && a[13]===7n && a[4294967294]===Infinity,'whole values remain strong roots');
assert(Object.keys(a).join(',')==='0,7,11,13,4294967294','sparse keys sorted after transition');
delete a[0];delete a[7];delete a[11];delete a[13];delete a[4294967294];gc();
assert(Object.keys(a).length===0 && a.length===4294967295,'final sparse deletion retires storage');
a[4294967294]=-0;assert(Object.is(a[4294967294],-0) && Object.keys(a).join(',')==='4294967294','empty sparse mode reinsertion');
"#,
    );
}

#[test]
fn graph_snapshot_reads_packed_numbers_and_empty_sparse_mode_without_mutation() {
    scriptw_engine::configure_compilation_jobs(1).unwrap();
    for (source, expected_keys) in [
        (
            "var a=[NaN,-0,,Infinity];gc();a;",
            vec!["0", "1", "3", "length"]
                .into_iter()
                .map(str::to_owned)
                .collect::<Vec<_>>(),
        ),
        (
            "var a=[];a[4294967294]=1;delete a[4294967294];gc();a;",
            vec!["length".to_owned()],
        ),
        (
            "var a=[];for(var i=0;i<130;i++)a.push(i+0.5);delete a[63];delete a[64];a.length=4294967295;gc();a;",
            (0..130)
                .filter(|index| *index != 63 && *index != 64)
                .map(|index| index.to_string())
                .chain(["length".to_owned()])
                .collect(),
        ),
    ] {
        let result = Engine::new(RealmBuilder::new().build())
            .observe_script_graph(
                source,
                CompileOptions {
                    host_surface_policy: HostSurfacePolicy::Test262,
                    ..CompileOptions::default()
                },
                RunOptions {
                    backend: ExecutionBackend::WasmAot,
                    timeout_ms: Some(30_000),
                    ..RunOptions::default()
                },
                SnapshotLimits::default(),
            )
            .unwrap();
        assert_eq!(result.backend_used, ExecutionBackend::WasmAot);
        let SnapshotOutcome::Captured { graph } = result.completion.outcome else {
            panic!("snapshot rejected");
        };
        let node = &graph.nodes()[0];
        let keys = node
            .properties
            .iter()
            .map(|property| match &property.key {
                SnapshotKey::String { units } => String::from_utf16(units.units()).unwrap(),
                _ => panic!("unexpected Symbol"),
            })
            .collect::<Vec<_>>();
        assert_eq!(keys, expected_keys);
        if source.contains("NaN") {
            assert!(
                matches!(&node.properties[0].descriptor, SnapshotDescriptor::Data {
                value: SnapshotValue::Number { bits }, writable: true, enumerable: true, configurable: true
            } if f64::from_bits(*bits).is_nan())
            );
            assert!(
                matches!(&node.properties[1].descriptor, SnapshotDescriptor::Data {
                value: SnapshotValue::Number { bits }, writable: true, enumerable: true, configurable: true
            } if *bits == (-0f64).to_bits())
            );
        } else if node.properties.len() > 1 {
            assert!(
                matches!(&node.properties[63].descriptor, SnapshotDescriptor::Data {
                value: SnapshotValue::Number { bits }, writable: true, enumerable: true, configurable: true
            } if *bits == 65.5f64.to_bits())
            );
            assert!(
                matches!(&node.properties.last().unwrap().descriptor, SnapshotDescriptor::Data {
                value: SnapshotValue::Number { bits }, writable: true, enumerable: false, configurable: false
            } if *bits == 4294967295f64.to_bits())
            );
        }
    }
}

#[test]
fn graph_snapshot_dense_prefix_ignores_spare_capacity_and_large_logical_length() {
    scriptw_engine::configure_compilation_jobs(1).unwrap();
    // A huge logical length must not size or scan the snapshot's indexed work.
    let limits = SnapshotLimits::new(512, 256, 16, 4096, 32768, 4096, 16384, 64).unwrap();
    for (source, expected_values, expected_length) in [
        (
            "var a=[NaN,-0,Infinity];gc();a;",
            vec![f64::NAN, -0.0, f64::INFINITY],
            3.0_f64,
        ),
        (
            "var a=[];for(var i=0;i<130;i++)a.push(i+0.5);a.length=4294967295;delete a[129];gc();a;",
            (0..129).map(|index| f64::from(index) + 0.5).collect(),
            4294967295.0,
        ),
        (
            "var a=[-0];a.length=4294967295;delete a[0];gc();a;",
            Vec::new(),
            4294967295.0,
        ),
    ] {
        let result = Engine::new(RealmBuilder::new().build())
            .observe_script_graph(
                source,
                CompileOptions {
                    host_surface_policy: HostSurfacePolicy::Test262,
                    ..CompileOptions::default()
                },
                RunOptions {
                    backend: ExecutionBackend::WasmAot,
                    timeout_ms: Some(30_000),
                    ..RunOptions::default()
                },
                limits,
            )
            .unwrap();
        assert_eq!(result.backend_used, ExecutionBackend::WasmAot);
        let SnapshotOutcome::Captured { graph } = result.completion.outcome else {
            panic!("dense prefix must fit the snapshot work budget: {source}");
        };
        let node = &graph.nodes()[0];
        let keys = node
            .properties
            .iter()
            .map(|property| match &property.key {
                SnapshotKey::String { units } => String::from_utf16(units.units()).unwrap(),
                _ => panic!("unexpected Symbol"),
            })
            .collect::<Vec<_>>();
        let expected_keys = (0..expected_values.len())
            .map(|index| index.to_string())
            .chain(["length".to_owned()])
            .collect::<Vec<_>>();
        assert_eq!(keys, expected_keys, "no stale capacity entries: {source}");
        for (property, expected) in node.properties.iter().zip(&expected_values) {
            let SnapshotDescriptor::Data {
                value: SnapshotValue::Number { bits },
                writable: true,
                enumerable: true,
                configurable: true,
            } = &property.descriptor
            else {
                panic!("dense Number retains its ordinary data descriptor");
            };
            if expected.is_nan() {
                assert!(f64::from_bits(*bits).is_nan());
            } else {
                assert_eq!(*bits, expected.to_bits(), "{source}");
            }
        }
        assert!(
            matches!(&node.properties.last().unwrap().descriptor, SnapshotDescriptor::Data {
            value: SnapshotValue::Number { bits }, writable: true, enumerable: false, configurable: false
        } if *bits == expected_length.to_bits())
        );
    }
}

#[test]
fn graph_snapshot_preserves_array_owner_cycles_after_header_and_descriptor_changes() {
    use scriptw_runtime::rooted_snapshot::SnapshotObjectKind;

    scriptw_engine::configure_compilation_jobs(1).unwrap();
    let observed = Engine::new(RealmBuilder::new().build())
        .observe_script_graph(
            r#"
var array=[0,-0,2,3],token=Object.create(null),prototype=Object.create(null);
token.owner=array;token.value=23;prototype.owner=array;
Object.setPrototypeOf(array,prototype);
array[2]=token;array[3]=array;delete array[0];
Object.defineProperty(array,'1',{writable:false,enumerable:false,configurable:false});
Object.defineProperty(array,'alias',{value:token,writable:false,enumerable:false,configurable:true});
array.length=4294967295;Object.defineProperty(array,'length',{writable:false});
Object.preventExtensions(array);gc();array;
"#,
            CompileOptions {
                host_surface_policy: HostSurfacePolicy::Test262,
                ..CompileOptions::default()
            },
            RunOptions {
                backend: ExecutionBackend::WasmAot,
                timeout_ms: Some(30_000),
                ..RunOptions::default()
            },
            SnapshotLimits::new(8, 16, 4, 128, 1024, 128, 1024, 16).unwrap(),
        )
        .unwrap();
    assert_eq!(observed.backend_used, ExecutionBackend::WasmAot);
    let SnapshotOutcome::Captured { graph } = observed.completion.outcome else {
        panic!("cyclic array snapshot must fit an occupied-property work budget");
    };
    assert_eq!(graph.root(), &SnapshotValue::Object { id: 0 });
    assert_eq!(graph.nodes().len(), 3);
    let array = &graph.nodes()[0];
    assert_eq!(array.kind, SnapshotObjectKind::Array {});
    assert!(!array.extensible);
    let keys = array
        .properties
        .iter()
        .map(|property| match &property.key {
            SnapshotKey::String { units } => String::from_utf16(units.units()).unwrap(),
            _ => panic!("unexpected Symbol"),
        })
        .collect::<Vec<_>>();
    assert_eq!(keys, ["1", "2", "3", "length", "alias"]);
    let data = |value, writable, enumerable, configurable| SnapshotDescriptor::Data {
        value,
        writable,
        enumerable,
        configurable,
    };
    let root = SnapshotValue::Object { id: 0 };
    let SnapshotDescriptor::Data {
        value: token @ SnapshotValue::Object { id: token_id },
        ..
    } = &array.properties[1].descriptor
    else {
        panic!("promoted index retains its object reference");
    };
    assert_eq!(
        array.properties[0].descriptor,
        data(
            SnapshotValue::Number {
                bits: (-0f64).to_bits()
            },
            false,
            false,
            false
        )
    );
    assert_eq!(
        array.properties[1].descriptor,
        data(token.clone(), true, true, true)
    );
    assert_eq!(
        array.properties[2].descriptor,
        data(root.clone(), true, true, true)
    );
    assert_eq!(
        array.properties[3].descriptor,
        data(
            SnapshotValue::Number {
                bits: 4294967295f64.to_bits()
            },
            false,
            false,
            false
        )
    );
    assert_eq!(
        array.properties[4].descriptor,
        data(token.clone(), false, false, true)
    );
    let token = &graph.nodes()[*token_id as usize];
    assert_eq!(token.prototype, SnapshotValue::Null {});
    assert_eq!(token.properties.len(), 2);
    assert_eq!(
        token.properties[0].descriptor,
        data(root.clone(), true, true, true)
    );
    assert_eq!(
        token.properties[1].descriptor,
        data(
            SnapshotValue::Number {
                bits: 23f64.to_bits()
            },
            true,
            true,
            true
        )
    );
    let SnapshotValue::Object { id: prototype_id } = &array.prototype else {
        panic!("mutated array prototype remains an ordinary object");
    };
    assert_ne!(prototype_id, token_id);
    let prototype = &graph.nodes()[*prototype_id as usize];
    assert_eq!(prototype.prototype, SnapshotValue::Null {});
    assert_eq!(prototype.properties.len(), 1);
    assert_eq!(
        prototype.properties[0].descriptor,
        data(root, true, true, true)
    );
}

#[test]
fn fresh_numeric_literal_padding_preserves_snapshot_capacity_and_occupied_keys() {
    scriptw_engine::configure_compilation_jobs(1).unwrap();
    for length in [3, 5, 6, 7] {
        let elements = vec!["value"; length].join(",");
        let source = format!(
            "function make(value) {{ return [{elements}]; }} var array=make(-0); gc(); array;"
        );
        let result = Engine::new(RealmBuilder::new().build())
            .observe_script_graph(
                &source,
                CompileOptions {
                    host_surface_policy: HostSurfacePolicy::Test262,
                    ..CompileOptions::default()
                },
                RunOptions {
                    backend: ExecutionBackend::WasmAot,
                    timeout_ms: Some(30_000),
                    ..RunOptions::default()
                },
                SnapshotLimits::default(),
            )
            .unwrap();
        let SnapshotOutcome::Captured { graph } = result.completion.outcome else {
            panic!("non-power-of-two literal must retain valid packed storage");
        };
        let node = &graph.nodes()[0];
        assert_eq!(
            node.properties.len(),
            length + 1,
            "padding is not an own property"
        );
        for (index, property) in node.properties[..length].iter().enumerate() {
            assert!(matches!(&property.key, SnapshotKey::String { units }
                if String::from_utf16(units.units()).unwrap() == index.to_string()));
            assert!(matches!(&property.descriptor, SnapshotDescriptor::Data {
                value: SnapshotValue::Number { bits }, writable: true, enumerable: true, configurable: true
            } if *bits == (-0f64).to_bits()));
        }
        assert!(
            matches!(&node.properties[length].descriptor, SnapshotDescriptor::Data {
            value: SnapshotValue::Number { bits }, writable: true, enumerable: false, configurable: false
        } if *bits == (length as f64).to_bits())
        );
    }
}

#[test]
fn four_element_capacity_growth_keeps_holes_and_number_bits() {
    check(
        r#"
var a=[0,-0,NaN,3];gc();
assert(a.length===4 && Object.is(a[1],-0) && Number.isNaN(a[2]),'four-element initial backing');
delete a[0];a[4]=Infinity;gc();
assert(!(0 in a) && Object.is(a[1],-0) && Number.isNaN(a[2]) && a[4]===Infinity,'first capacity growth preserves hole bitmap and bits');
a[7]=-Infinity;a[8]=8.5;delete a[3];gc();
assert(a.length===9 && !(3 in a) && a[7]===-Infinity && a[8]===8.5,'second growth preserves bitmap');
a[0]=0;a[1]=0;a[2]=-0;a[4]=NaN;gc();
assert(Object.is(a[0],0) && Object.is(a[1],0) && Object.is(a[2],-0) && Number.isNaN(a[4]),'replacement after growth');
a[15]=-0;delete a[15];gc();
assert(!(15 in a) && !(3 in a) && Object.is(a[2],-0),'delete publishes the high small-capacity bit');
for(var i=9;i<15;i++)a[i]=i+0.25;
a[15]=-0;a[16]=16.5;a[31]=31.5;gc();
assert(Object.is(a[15],-0) && a[16]===16.5 && a[31]===31.5 && !(3 in a) && !(5 in a),'nonprefix small mask survives growth to 32');
delete a[15];delete a[31];gc();a[15]=-0;a[31]=Infinity;a[32]=-Infinity;
for(var j=17;j<31;j++)a[j]=j+0.25;
a[63]=63.5;delete a[63];gc();a[63]=NaN;a[64]=-0;gc();
delete a[32];gc();a[32]=32.5;
// ownKeys checks occupancy without requesting occupied index descriptors.
assert(a.length===65 && Reflect.ownKeys(a).length===33 && !(3 in a) && !(5 in a) && !(6 in a),'occupied count differs from length through growth to 128');
assert(Object.is(a[15],-0) && a[31]===Infinity && a[32]===32.5 && Number.isNaN(a[63]) && Object.is(a[64],-0),'refill across word and capacity boundaries');
a.length=16;gc();a.length=65;gc();
assert(Object.is(a[15],-0) && !(16 in a) && !(31 in a) && !(32 in a) && !(63 in a) && !(64 in a),'shrink and regrow never resurrect presence bits');
a[31]=-0;a[32]=NaN;a[63]=Infinity;a[64]=-Infinity;gc();
assert(Object.is(a[31],-0) && Number.isNaN(a[32]) && a[63]===Infinity && a[64]===-Infinity,'refills after shrink');
// Shrink may materialize descriptors. Restart with numeric storage to exercise
// packed count-zero retirement independently of that fallback.
a=[0,-0,NaN,3];for(var r=4;r<65;r++)a[r]=r+0.5;gc();
for(var k=0;k<65;k++)delete a[k];gc();
assert(a.length===65 && Reflect.ownKeys(a).join(',')==='length','count-zero retirement preserves logical length');
a.length=4294967295;a[7]=-0;gc();
assert(Reflect.ownKeys(a).join(',')==='7,length' && Object.is(a[7],-0) && a.length===4294967295,'retired storage restarts small despite huge logical length');
delete a[7];gc();assert(Reflect.ownKeys(a).join(',')==='length','small count-zero retirement');
a[7]=-0;gc();
a[0]=0;a[8]=undefined;gc();
assert(Reflect.ownKeys(a).join(',')==='0,7,8,length' && a[8]===undefined && !(1 in a) && Object.is(a[7],-0),'value promotion preserves the restarted nonprefix mask');
Object.defineProperty(a,'7',{writable:false,enumerable:false,configurable:false});
assert(!Reflect.defineProperty(a,'length',{value:4,writable:false}),'nonconfigurable promoted index blocks shrink');gc();
var descriptor=Object.getOwnPropertyDescriptor(a,'7');
assert(a.length===8 && !(8 in a) && a[0]===0 && Object.is(descriptor.value,-0) && !descriptor.writable && !descriptor.enumerable && !descriptor.configurable && !Object.getOwnPropertyDescriptor(a,'length').writable,'descriptor promotion and failed shrink keep exact surviving entries');
"#,
    );
}

#[test]
fn graph_snapshot_keeps_presence_cycles_across_later_program_mutation_and_gc() {
    use scriptw_engine::{EmbeddedEvaluation, EmbeddedRuntime, JsCompletion, JsValue};
    use scriptw_runtime::rooted_snapshot::{SnapshotNode, SnapshotObjectKind};

    const PRELUDE: &str = r#"
function assert(value,label){if(!value)throw new Error(label);}
var root=Object.create(null),prototype=Object.create(null);
root.small=[-0,1,NaN,3];delete root.small[1];root.small.length=4294967295;
root.large=[0,1,2,3];
for(var i=4;i<65;i++){root.large[i]=i+0.5;if(i===4 || i===8 || i===16 || i===32 || i===64)gc();}
root.values=[NaN,-0,2,3];root.descriptors=[0,-0,2,3];root.alias=root.small;
prototype.owner=root;
for(var name of ['small','large','values','descriptors']){
  Object.setPrototypeOf(root[name],prototype);root[name].owner=root;
}
gc();
"#;
    const LATER: &str = r#"
delete root.small[2];root.small[1]=NaN;root.small[3]=-0;
delete root.large[0];root.large[15]=-0;root.large[31]=31.25;
delete root.large[32];root.large[63]=63.25;root.large[64]=Infinity;
delete root.values[0];root.values[2]=root;root.values[3]=root.values;
delete root.descriptors[0];
Object.defineProperty(root.descriptors,'1',{writable:false,enumerable:false,configurable:false});
root.descriptors[2]=root.small;root.descriptors[3]=root;
root.descriptors.length=4294967295;Object.defineProperty(root.descriptors,'length',{writable:false});
Object.preventExtensions(root.descriptors);gc();
function verifyPresenceGraph(){
  assert(root.alias===root.small && prototype.owner===root,'shared owner cycle');
  for(var name of ['small','large','values','descriptors'])
    assert(Object.getPrototypeOf(root[name])===prototype && root[name].owner===root,'array owner and prototype');
  assert(Reflect.ownKeys(root.small).join(',')==='0,1,3,length,owner' && root.small.length===4294967295 &&
    Object.is(root.small[0],-0) && Number.isNaN(root.small[1]) && !(2 in root.small) && Object.is(root.small[3],-0),'small nonprefix state');
  assert(root.large.length===65 && Reflect.ownKeys(root.large).length===65 && !(0 in root.large) && !(32 in root.large) &&
    Object.is(root.large[15],-0) && root.large[31]===31.25 && root.large[63]===63.25 && root.large[64]===Infinity,'large bitmap state');
  assert(!(0 in root.values) && Object.is(root.values[1],-0) && root.values[2]===root && root.values[3]===root.values,'promoted value cycles');
  var descriptor=Object.getOwnPropertyDescriptor(root.descriptors,'1');
  assert(!(0 in root.descriptors) && Object.is(descriptor.value,-0) && !descriptor.writable && !descriptor.enumerable && !descriptor.configurable &&
    root.descriptors[2]===root.small && root.descriptors[3]===root && !Object.isExtensible(root.descriptors) &&
    root.descriptors.length===4294967295 && !Object.getOwnPropertyDescriptor(root.descriptors,'length').writable,'descriptor cycles and flags');
  return true;
}
verifyPresenceGraph();
"#;

    fn keys(node: &SnapshotNode) -> Vec<String> {
        node.properties
            .iter()
            .map(|property| match &property.key {
                SnapshotKey::String { units } => String::from_utf16(units.units()).unwrap(),
                _ => panic!("fixture has only string keys"),
            })
            .collect()
    }
    fn property<'a>(node: &'a SnapshotNode, name: &str) -> &'a SnapshotDescriptor {
        &node
            .properties
            .iter()
            .find(|property| {
                matches!(&property.key, SnapshotKey::String { units }
                if units.units() == name.encode_utf16().collect::<Vec<_>>())
            })
            .unwrap_or_else(|| panic!("missing property {name}"))
            .descriptor
    }
    fn object_property(node: &SnapshotNode, name: &str) -> u32 {
        match property(node, name) {
            SnapshotDescriptor::Data {
                value: SnapshotValue::Object { id },
                writable: true,
                enumerable: true,
                configurable: true,
            } => *id,
            descriptor => panic!("expected ordinary object property {name}: {descriptor:?}"),
        }
    }
    fn number(descriptor: &SnapshotDescriptor, expected: f64, flags: (bool, bool, bool)) {
        let SnapshotDescriptor::Data {
            value: SnapshotValue::Number { bits },
            writable,
            enumerable,
            configurable,
        } = descriptor
        else {
            panic!("expected Number data descriptor: {descriptor:?}");
        };
        assert_eq!((*writable, *enumerable, *configurable), flags);
        if expected.is_nan() {
            assert!(f64::from_bits(*bits).is_nan());
        } else {
            assert_eq!(*bits, expected.to_bits());
        }
    }
    fn normal(completion: JsCompletion) -> JsValue {
        match completion {
            JsCompletion::Normal(value) => value,
            JsCompletion::Throw(value) => panic!("retained presence operation threw: {value:?}"),
        }
    }

    scriptw_engine::configure_compilation_jobs(1).unwrap();
    // The prelude and entry are separate parsed Programs in the same Realm.
    // Huge logical lengths must fit a budget for actual occupied properties.
    let observed = Engine::new(RealmBuilder::new().build())
        .observe_script_graph(
            &format!("{LATER}root;"),
            CompileOptions {
                host_surface_policy: HostSurfacePolicy::Test262,
                module_prelude: Some(PRELUDE.into()),
                ..CompileOptions::default()
            },
            RunOptions {
                backend: ExecutionBackend::WasmAot,
                timeout_ms: Some(30_000),
                ..RunOptions::default()
            },
            SnapshotLimits::new(8, 16, 4, 128, 1024, 128, 8192, 16).unwrap(),
        )
        .unwrap();
    assert_eq!(observed.backend_used, ExecutionBackend::WasmAot);
    let SnapshotOutcome::Captured { graph } = observed.completion.outcome else {
        panic!("cyclic presence graph must fit its occupied-property budget");
    };
    assert_eq!(graph.root(), &SnapshotValue::Object { id: 0 });
    assert_eq!(graph.nodes().len(), 6);
    let root = &graph.nodes()[0];
    assert_eq!(root.kind, SnapshotObjectKind::Ordinary {});
    assert!(root.extensible);
    assert_eq!(root.prototype, SnapshotValue::Null {});
    assert_eq!(
        keys(root),
        ["small", "large", "values", "descriptors", "alias"]
    );
    let ids = ["small", "large", "values", "descriptors"].map(|name| object_property(root, name));
    assert_eq!(object_property(root, "alias"), ids[0]);
    let mut distinct = ids.to_vec();
    distinct.sort_unstable();
    distinct.dedup();
    assert_eq!(distinct.len(), 4);
    let arrays = ids.map(|id| &graph.nodes()[id as usize]);
    let prototype = arrays[0].prototype.clone();
    for (index, array) in arrays.iter().enumerate() {
        assert_eq!(array.kind, SnapshotObjectKind::Array {});
        assert_eq!(array.extensible, index != 3);
        assert_eq!(array.prototype, prototype);
        assert_eq!(object_property(array, "owner"), 0);
    }
    let SnapshotValue::Object { id: prototype_id } = prototype else {
        panic!("arrays share the private ordinary prototype");
    };
    assert_ne!(prototype_id, 0);
    assert!(!ids.contains(&prototype_id));
    let prototype = &graph.nodes()[prototype_id as usize];
    assert_eq!(prototype.kind, SnapshotObjectKind::Ordinary {});
    assert!(prototype.extensible);
    assert_eq!(prototype.prototype, SnapshotValue::Null {});
    assert_eq!(keys(prototype), ["owner"]);
    assert_eq!(object_property(prototype, "owner"), 0);

    let [small, large, values, descriptors] = arrays;
    assert_eq!(keys(small), ["0", "1", "3", "length", "owner"]);
    for (key, value) in [("0", -0.0), ("1", f64::NAN), ("3", -0.0)] {
        number(property(small, key), value, (true, true, true));
    }
    number(
        property(small, "length"),
        4294967295.0,
        (true, false, false),
    );
    let mut large_keys = (1..65)
        .filter(|index| *index != 32)
        .map(|index| index.to_string())
        .collect::<Vec<_>>();
    large_keys.extend(["length".into(), "owner".into()]);
    assert_eq!(keys(large), large_keys);
    for index in (1..65).filter(|index| *index != 32) {
        let expected = match index {
            15 => -0.0,
            31 => 31.25,
            63 => 63.25,
            64 => f64::INFINITY,
            1..=3 => index as f64,
            _ => index as f64 + 0.5,
        };
        number(
            property(large, &index.to_string()),
            expected,
            (true, true, true),
        );
    }
    number(property(large, "length"), 65.0, (true, false, false));
    for array in [values, descriptors] {
        assert_eq!(keys(array), ["1", "2", "3", "length", "owner"]);
    }
    number(property(values, "1"), -0.0, (true, true, true));
    assert_eq!(object_property(values, "2"), 0);
    assert_eq!(object_property(values, "3"), ids[2]);
    number(property(values, "length"), 4.0, (true, false, false));
    number(property(descriptors, "1"), -0.0, (false, false, false));
    assert_eq!(object_property(descriptors, "2"), ids[0]);
    assert_eq!(object_property(descriptors, "3"), 0);
    number(
        property(descriptors, "length"),
        4294967295.0,
        (false, false, false),
    );

    // Standalone emission has no dynamic source requirement. Retained exports
    // cross host GC before another small-to-large transition and hole refill.
    let compiler = Engine::new(RealmBuilder::new().build());
    let unit = compiler
        .compile_module(
            &format!(
                r#"{LATER}
export function verify(){{return verifyPresenceGraph();}}
export function mutate(){{
  root.small[7]=7.5;root.small[15]=-0;root.small[16]=Infinity;
  delete root.small[7];delete root.large[63];gc();
  root.small[7]=NaN;root.large[32]=-0;root.large[63]=63.75;
  root.values[0]=root.large;gc();return true;
}}
export function after(){{
  assert(root.alias===root.small && prototype.owner===root && root.values[0]===root.large && root.values[3]===root.values,'retained owner cycles');
  assert(root.small.length===4294967295 && !(2 in root.small) && Object.is(root.small[0],-0) && Number.isNaN(root.small[1]) &&
    Object.is(root.small[3],-0) && Number.isNaN(root.small[7]) && Object.is(root.small[15],-0) && root.small[16]===Infinity,'later small-to-large transition');
  assert(Reflect.ownKeys(root.small).join(',')==='0,1,3,7,15,16,length,owner' && Object.is(root.large[32],-0) && root.large[63]===63.75,'later heap-word refill');
  assert(!Reflect.set(root.descriptors,'1',9) && !Reflect.set(root.descriptors,'length',4) && root.descriptors[2]===root.small,'promoted flags after host GC');
  return true;
}}
"#
            ),
            CompileOptions {
                host_surface_policy: HostSurfacePolicy::Test262,
                module_prelude: Some(PRELUDE.into()),
                ..CompileOptions::default()
            },
        )
        .unwrap();
    let artifact = compiler.emit_wasm(&unit).unwrap();
    let mut config = wasmtime::Config::new();
    scriptw_engine::configure_wasm_runtime(&mut config);
    let engine = wasmtime::Engine::new(&config).unwrap();
    let runtime = EmbeddedRuntime::compile(&engine, &artifact).unwrap();
    let state = runtime.new_state(RealmBuilder::new().build(), ()).unwrap();
    let mut store = wasmtime::Store::new(&engine, state);
    store.limiter(|state| state.limits_mut());
    store.set_epoch_deadline(u64::MAX / 2);
    let mut linker = wasmtime::Linker::new(&engine);
    runtime.register(&mut store, &mut linker).unwrap();
    let mut instance = runtime.instantiate(&mut store, &mut linker).unwrap();
    assert!(matches!(
        instance.initialize(&mut store).unwrap(),
        EmbeddedEvaluation::Settled(JsCompletion::Normal(_))
    ));
    let exports = ["verify", "mutate", "after"]
        .map(|name| normal(instance.get_export(&mut store, name).unwrap()));
    for callable in exports {
        store.gc(None).unwrap();
        assert_eq!(
            normal(instance.call(&mut store, &callable, None, &[]).unwrap()).as_boolean(),
            Some(true)
        );
    }
}
