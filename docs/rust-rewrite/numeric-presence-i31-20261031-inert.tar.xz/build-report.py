"""Assemble complete i31 Array-presence evidence from inert records only; never run products."""
from pathlib import Path
import ast
import datetime
import hashlib
import json
import re
import statistics

ROOT = Path('/workspace/scriptw')
OUT = Path(__file__).resolve().parent
PARENT = '6cec43bcd2dabfc26fcb42736925d4041e3fe9b5'
BASELINE = 'a35adbcb61dbc57b4ee44dd1527019358deb137b11ae559de7d0d4b4a860b480'
BASELINE_SOURCE = '7c47e38274c9645b6701552c87d38362b2bfbcd5'
ORDER = ['baseline', 'candidate', 'candidate', 'baseline',
         'candidate', 'baseline', 'baseline', 'candidate']
DATE_FILES = ['date-first-descriptor.js', 'date-first-epoch.js', 'date-repeated-256.js']


def require(value, message):
    if not value:
        raise ValueError(message)


def inert(path, limit=16 * 1024**2):
    path = Path(path)
    require(path.is_file() and not path.is_symlink() and path.stat().st_size <= limit,
            'missing, nonregular or oversized inert input: ' + str(path))
    require(path.suffix in {'.json', '.jsonl', '.log', '.stdout', '.stderr', '.gz',
                           '.rs', '.md', '.py', '.patch', '.js', '.mjs', '.cjs', '.txt'},
            'inert metadata/source/log required: ' + str(path))
    return path


def read(name):
    path = Path(name)
    return json.loads(inert(path if path.is_absolute() else OUT / path).read_text())


def digest(path):
    # Native product/image files are never opened; identities come from receipts.
    return hashlib.sha256(inert(path).read_bytes()).hexdigest()


def origin(path, expected_sha256=None, archive=False):
    path = Path(path)
    if not path.is_absolute():
        path = ROOT / path
    require(path.is_relative_to(ROOT), 'raw origin outside workspace')
    actual = digest(path)
    require(expected_sha256 is None or actual == expected_sha256, 'raw origin digest differs: ' + str(path))
    archived = path
    if archive and not path.is_relative_to(OUT):
        archived = OUT / 'raw-streams' / path.name
        archived.parent.mkdir(exist_ok=True)
        if archived.exists():
            require(digest(archived) == actual, 'archived raw stream differs')
        else:
            with archived.open('xb') as stream:
                stream.write(path.read_bytes())
    return dict(origin=str(path.relative_to(ROOT)), sha256=actual,
                archive_path=str(archived.relative_to(OUT)) if archived.is_relative_to(OUT) else None)


def native_case(directory, case):
    inventory = origin(case['inventory_log'], case['inventory_sha256'])
    inventory_text = (ROOT / inventory['origin']).read_text()
    names = re.findall(r'^(.+): test$', inventory_text, re.M)
    require(len(names) == len(set(names)) == case['inventoried_tests'] > 0,
            'native inventory differs: ' + directory)
    stream = origin(case['transcript_log'], case['transcript_sha256'], archive=True)
    text = (ROOT / stream['origin']).read_text()
    printed = re.findall(r'^test (.+) \.\.\. (ok|FAILED|ignored)$', text, re.M)
    # libtest annotates #[should_panic] execution labels, while --list emits the
    # canonical Rust test name without that suffix.
    actual = [(name.removesuffix(' - should panic'), status) for name, status in printed]
    require(len(actual) == len(names) and {name for name, _ in actual} == set(names),
            'native transcript does not cover its inventory: ' + directory)
    totals = dict(passed=sum(status == 'ok' for _, status in actual),
                  failed=sum(status == 'FAILED' for _, status in actual),
                  ignored=sum(status == 'ignored' for _, status in actual))
    require(case['outcomes'] == [totals] and totals['ignored'] == 0, 'native outcome differs')
    summaries = re.findall(r'^test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', text, re.M)
    require(summaries == [(str(totals['passed']), str(totals['failed']), '0')],
            'native summary differs')
    failed = totals['failed'] > 0
    require(case['build_exit'] == 0 and case['state'] == ('failed' if failed else 'passed') and
            case['exit_code'] == (101 if failed else 0) and case['inventory_matches'] is (not failed),
            'native completion/inventory state differs')
    for row in case['sealed_build_logs']:
        origin(row['path'], row['gzip_sha256'])
    keys = {(case['package'], case['target'], name): status for name, status in actual}
    return dict(receipt=directory + '/receipt.json', package=case['package'], target=case['target'],
                filter=case.get('native_filter'), outcomes=totals, inventory=inventory,
                failing_tests=[name for name, status in actual if status == 'FAILED'],
                transcript=stream, executable_sha256=case['executable_sha256'],
                executable_bytes=case['executable_bytes'],
                executable_released_by_driver=case['executable_released']), keys


def source_and_native():
    inputs, summary = read('compiled-inputs.json'), read('native-final-summary.json')
    native_plan = read('native-plan.json')
    new_modules = {'crates/scriptw-aot-wasm/src/gc_types/value/number_presence.rs',
                   'crates/scriptw-engine/src/wasm_rooted_snapshot/number_presence.rs'}
    require(len(inputs) == 16 and native_plan['accepted_parent'] == PARENT and
            {name for name, row in inputs.items() if row['untracked_new_module']} == new_modules,
            'frozen16-input/ABI45 source plan differs')
    for name, record in inputs.items():
        path = OUT / 'implementation' / name
        require(not Path(name).is_absolute() and '..' not in Path(name).parts and
                path.stat().st_size == record['bytes'] and digest(path) == record['sha256'],
                'frozen source snapshot differs: ' + name)
    runtime_source = OUT / 'implementation/crates/scriptw-aot-wasm/src/runtime_artifact.rs'
    require(re.search(r'const\s+LAYOUT_VERSION\s*:\s*u32\s*=\s*45\s*;', runtime_source.read_text()),
            'ABI45 source authority absent')
    expected = [('scriptw-aot-wasm', 'scriptw_aot_wasm', 'lib', None),
                ('scriptw-engine', 'scriptw_engine', 'lib', 'wasm_rooted_snapshot::'),
                ('scriptw-aot-wasm', 'runtime_link', 'test', None),
                ('scriptw-aot-wasm', 'emission', 'test', 'packed_array_storage::'),
                ('scriptw-aot-wasm', 'emission', 'test', 'property_read_plans::'),
                ('scriptw-engine', 'aot_gc_entries', 'test', 'aot_gc_packed_array_storage::'),
                ('scriptw-engine', 'aot_gc_entries', 'test', 'aot_gc_property_read_plans::'),
                ('scriptw-engine', 'aot_language', 'test', 'aot_compact_array_literals::'),
                ('scriptw-engine', 'aot_language', 'test', 'aot_packed_array_producers::'),
                ('scriptw-engine', 'aot_builtins', 'test', 'aot_array_private_buffers::')]
    require([(row['package'], row['target'], row['kind'], row['filter'])
             for row in native_plan['scopes']] == expected and
            summary['complete'] is True and summary['all_passed'] is True and
            len(summary['scopes']) == len(expected) and
            summary['source_snapshot'] == 'compiled-inputs.json' and
            summary['source_unchanged_every_scope'] is True,
            'fresh native ten-scope coverage incomplete')
    frozen = read('source-map-at-freeze.json')
    source_map = hashlib.sha256(json.dumps(frozen, sort_keys=True).encode()).hexdigest()
    require(frozen['head'] == PARENT, 'frozen source map parent differs')
    rows, selected, retained, chains, used_directories = [], {}, {}, [], set()
    for index, (planned, run) in enumerate(zip(native_plan['scopes'], summary['scopes'])):
        batch_index = 0 if index < 2 else index - 1
        batch_name = 'libraries' if index < 2 else planned['target']
        directory = run['label']
        require(re.fullmatch(r'native-batch-' + f'{batch_index:02d}-' + batch_name +
                             r'(?:-[A-Za-z0-9-]+)?', directory) is not None and
                run['index'] == index and run['batch_index'] == batch_index and
                run['package'] == planned['package'] and run['target'] == planned['target'] and
                run['filter'] == planned['filter'] and run['state'] == 'passed' and run['exit_code'] == 0,
                'native final union selector or original/resume directory differs')
        if index == 1:
            require(directory == rows[0]['receipt'].split('/')[0], 'library cases do not share one receipt')
        used_directories.add(directory)
        receipt = read(directory + '/receipt.json')
        require(receipt['head'] == PARENT and receipt['source_unchanged'] is True and
                receipt['shared_runtime_linker_unchanged'] is True and receipt['profile'] == 'release' and
                receipt['all_features'] is False and receipt['include_ignored'] is False and
                set(receipt['selected_workspace_packages']) == {'scriptw-aot-wasm', 'scriptw-engine'} and
                receipt['preserve_test_artifacts'] is True and receipt['selected_feature_roots'] is False,
                'native source/features/selection changed')
        expected_cases = expected[:2] if index < 2 else [expected[index]]
        require({(case['package'], case['target'], case['kind']) for case in receipt['cases']} ==
                {row[:3] for row in expected_cases} and len(receipt['cases']) == len(expected_cases),
                'native receipt has extra or missing selected cases')
        start = read(directory + '/source-start.json')
        require(start == frozen and receipt['source_map_sha256'] == source_map,
                'native source map differs across scopes')
        schedule = receipt['scheduling']
        require(schedule['cargo_jobs'] == schedule['test_processes'] == schedule['test_threads_per_process'] == 1,
                'native serial policy differs')
        case = next(case for case in receipt['cases'] if case['package'] == planned['package'] and
                    case['target'] == planned['target'])
        require(case['kind'] == planned['kind'] and case.get('native_filter') == planned['filter'],
                'native case selector differs')
        row, tests = native_case(directory, case)
        count = len(tests)
        require(count > 0 and row['outcomes'] == dict(passed=count, failed=0, ignored=0) and
                run['inventoried_tests'] == count and run['outcomes'] == case['outcomes'] and
                run['executable_sha256'] == case['executable_sha256'] and
                not (selected.keys() & tests.keys()), 'native fresh inventory is failing, empty or overlapping')
        lifecycle = read(directory + '/native-image-retirement.json')
        records = [record for record in lifecycle['records'] if record['selected']]
        require(lifecycle['exit_code'] == 0 and lifecycle['source_map_sha256'] == source_map and
                {(record['package'], record['target']) for record in records} ==
                {(other['package'], other['target']) for other in receipt['cases']} and
                len(records) == len(receipt['cases']), 'selected image lifecycle inventory differs')
        image = next(record for record in records if record['package'] == case['package'] and
                     record['target'] == case['target'])
        require(image['sha256'] == case['executable_sha256'] and image['bytes'] == case['executable_bytes'],
                'selected image lifecycle identity differs')
        selector = (case['package'], case['target'], tuple(case['selector']))
        if selector in retained:
            previous = retained.pop(selector)
            require(all(image[key] == previous['record'][key] for key in ['path', 'sha256', 'bytes']) and
                    previous['source_map_sha256'] == source_map,
                    'same-selector keep/use/retire chain differs')
            chains.append(dict(first=previous['receipt'], second=directory + '/receipt.json',
                               package=case['package'], target=case['target'], sha256=image['sha256'],
                               bytes=image['bytes'], source_map_sha256=source_map))
        future = any(other['package'] == planned['package'] and other['target'] == planned['target']
                     for other in native_plan['scopes'][index + 1:])
        expected_action = ('retained exact passing image for next filter in same Cargo selector' if future else
                           'retired exact passing image after complete source-bound transcript')
        require(image['action'] == expected_action, 'selected passing image keep/retire policy differs')
        if future:
            retained[selector] = dict(record=image, receipt=directory + '/receipt.json', source_map_sha256=source_map)
        row.update(source_map_sha256=source_map, source_start=start, scheduling=schedule,
                   selector=case['selector'], lifecycle=lifecycle, batch_index=batch_index)
        rows.append(row)
        selected.update(tests)
    require(not retained and len(used_directories) == 9 and len(chains) == 3 and
            selected and set(selected.values()) == {'ok'}, 'native union or image chains incomplete')
    require(summary.get('unique_passed', summary.get('actual_passed')) == len(selected),
            'final native union count differs from actual inventories')
    proof_tests = {
        'small_mask_domain': ('scriptw-aot-wasm', 'scriptw_aot_wasm',
            'gc_types::value::number_presence::tests::small_masks_admit_only_declared_capacities_and_complete_prefixes'),
        'array_layout': ('scriptw-aot-wasm', 'scriptw_aot_wasm',
            'gc_types::type_registration_tests::array_storage_fusion::encoded_actual_array_fits_one_64_byte_copying_collector_record'),
        'bitmap_allocation': ('scriptw-aot-wasm', 'scriptw_aot_wasm',
            'gc_types::type_registration_tests::array_storage_fusion::actual_nominal_presence_one_word_remains_a_32_byte_copying_allocation'),
        'encoded_presence': ('scriptw-aot-wasm', 'emission',
            'packed_array_storage::compiled_numbers_use_bitmap_arrays_and_keep_real_descriptor_fallback'),
        'encoded_property_read': ('scriptw-aot-wasm', 'emission',
            'property_read_plans::own_data_cache_and_numeric_array_reads_keep_guarded_loads_and_get_fallbacks'),
        'growth_lifecycle': ('scriptw-engine', 'aot_gc_entries',
            'aot_gc_packed_array_storage::four_element_capacity_growth_keeps_holes_and_number_bits'),
        'cyclic_snapshot_portable': ('scriptw-engine', 'aot_gc_entries',
            'aot_gc_packed_array_storage::graph_snapshot_keeps_presence_cycles_across_later_program_mutation_and_gc'),
    }
    for name in read('snapshot-owner/receipt.json')['new_private_tests']:
        proof_tests['decoder_' + name] = ('scriptw-engine', 'scriptw_engine',
                                         'wasm_rooted_snapshot::number_presence::tests::' + name)
    require(len([name for name in proof_tests if name.startswith('decoder_')]) == 4 and
            all(selected.get(key) == 'ok' for key in proof_tests.values()),
            'actual collector/domain/decoder/encoded/lifecycle proofs did not pass')
    owner = 'crates/scriptw-engine/tests/aot_gc_entries/aot_gc_packed_array_storage.rs'
    owner_tests = set(re.findall(r'(?m)^#\[test\]\nfn (\w+)\(', (OUT / 'implementation' / owner).read_text()))
    owner_actual = {key[2].removeprefix('aot_gc_packed_array_storage::') for key in selected
                    if key[:2] == ('scriptw-engine', 'aot_gc_entries') and
                    key[2].startswith('aot_gc_packed_array_storage::')}
    require(owner_tests == owner_actual and owner_tests, 'frozen Engine owner inventory not completely executed')
    layout = (OUT / 'implementation/crates/scriptw-aot-wasm/src/gc_types/type_registration_tests/array_storage_fusion.rs').read_text()
    flat = re.sub(r'\s+', '', layout)
    require('assert_eq!(layout.size,64);' in flat and 'assert_eq!(layout.align,16);' in flat and
            '[16,20,24,32,40,44,48,52,56,60]' in flat and
            'assert_eq!(layout.size_for_len(1),Some(32));' in flat and
            '.filter(|field|field.is_gc_ref).count(),6' in flat,
            'reported Array/bitmap layout differs from passing frozen source')
    historical = []
    for receipt_path in sorted(OUT.glob('native-batch-*/receipt.json')):
        directory = receipt_path.parent.name
        if directory in used_directories:
            continue
        receipt = read(receipt_path)
        cases = []
        for case in receipt['cases']:
            if case.get('transcript_log'):
                row, _ = native_case(directory, case)
                cases.append(row)
            else:
                require(not case.get('outcomes') and not case.get('exit_code'),
                        'unexecuted historical case claims a verdict')
                cases.append(dict(package=case['package'], target=case['target'], state=case.get('state'),
                                  qualification='No completed native transcript/verdict; not adopted as passing coverage.'))
        lifecycle = receipt_path.parent / 'native-image-retirement.json'
        historical.append(dict(receipt=origin(receipt_path), cases=cases,
                               image_policy=read(lifecycle) if lifecycle.exists() else None,
                               reused_as_passing_coverage=False))
    events = {path.name: read(path) for path in sorted(OUT.glob('*cache-relocation.json'))}
    return dict(inputs=inputs, snapshot='compiled-inputs.json', patch_sha256=digest(OUT / 'compile-inputs.patch'),
                source_map_sha256=source_map, scopes=rows, unique_passes=len(selected), failures=[], repairs=[],
                shared_image_chains=chains, final_union_summary=summary, actual_engine_owner_tests=len(owner_actual),
                array_layout=dict(bytes=64, alignment=16, potential_gc_slots=6,
                                  field_offsets=[16,20,24,32,40,44,48,52,56,60], result='passed'),
                nominal_bitmap_allocation=dict(one_word_bytes=32, alignment=16, result='passed',
                                               test=proof_tests['bitmap_allocation'][2]),
                new_proof_tests={name: key[2] for name, key in proof_tests.items()},
                historical_native_attempts=historical, resource_policy_events=events,
                scope='Actual fresh nonzero inventories from10 scopes in9 normal-two-package invocations; first2 library cases share one receipt, three filtered integration image chains are exact. No rejected43/44 coverage or full-workspace claim.')


def product_metadata():
    identities = {label: read('baseline-identity.json' if label == 'baseline' else 'candidate/identity.json')
                  for label in ['baseline', 'candidate']}
    products = {label: read('baseline-products.json' if label == 'baseline' else 'candidate/products.json')
                for label in identities}
    require(identities['baseline']['source_fingerprint'] == BASELINE and
            identities['baseline']['source_commit'] == BASELINE_SOURCE and
            re.fullmatch(r'[0-9a-f]{64}', identities['candidate']['source_fingerprint']) is not None and
            identities['candidate']['source_fingerprint'] != BASELINE and
            identities['candidate']['source_commit'] == PARENT, 'DATE-parent/I31 source identity differs')
    for label, identity in identities.items():
        require(set(products[label]) == {'scriptw', 'runtime_baseline', 'compiler_precompiled_baseline'} and
                products[label]['compiler_precompiled_baseline']['sha256'] == identity['executable_sha256'] and
                identity['shared_configuration'] == identities['baseline']['shared_configuration'],
                'frozen product metadata differs')
    build, reuse = read('candidate-build.json'), read('baseline-reuse-proof.json')
    matches = reuse['committed_parent_matches_all54_Date_published_non_markdown_inputs']
    markdown, differences = reuse['historical_markdown_inputs'], reuse['accepted_markdown_differences']
    require(build['exit_code'] == 0 and build['head'] == PARENT and build['source_map'] == read('source-map-at-freeze.json') and
            reuse['accepted_commit'] == PARENT and
            reuse['original_identity'] == identities['baseline'] and reuse['baseline_products'] == products['baseline'] and
            len(matches) == 54 and not any(name.endswith('.md') for name in matches) and
            len(markdown) == 7 and all(name.endswith('.md') for name in markdown) and
            differences == {name: row for name, row in markdown.items() if row['same'] is False} and
            len(differences) == 3 and all(row['same'] is
                (row['historical_published_identity'] == row['accepted_parent_identity']) for row in markdown.values()),
            'candidate build or accepted54-source/7-historical-Markdown Date reuse proof differs')
    return dict(identities=identities, products=products, candidate_build=build,
                accepted_baseline_reuse_proof=reuse,
                identity_note='Accepted6cec production equals a9 and reuses actual a35 Date products built at7c47 plus their original frozen patch. All54 non-Markdown published inputs match accepted Git blobs;7 historical Markdown identities and3 later differences stay explicit. Products are not retagged as a6cec build.')


def prior_rejection_evidence():
    rows = []
    for stem, abi in [('append-key-summary-20261031', 43), ('append-key-lazy-summary-20261031', 44)]:
        path = ROOT / 'docs/rust-rewrite' / (stem + '.json')
        prior = read(path)
        require(prior['status'].lower().startswith('rejected') and
                prior['change']['runtime_abi_after'] == abi and
                prior['source']['candidate_fingerprint'] != read('candidate/identity.json')['source_fingerprint'],
                'historical summary evidence is not a separate rejected candidate')
        archive = path.parent / prior['archive']['file']
        require(archive.name == stem + '-inert.tar.xz' and archive.is_file() and not archive.is_symlink() and
                archive.stat().st_size == prior['archive']['bytes'] <= 64 * 1024**2,
                'historical public inert archive size/path differs')
        # These are public inert archives, never products or native images.
        with archive.open('rb') as stream:
            archive_sha = hashlib.file_digest(stream, 'sha256').hexdigest()
        require(archive_sha == prior['archive']['sha256'], 'historical public inert archive differs')
        rows.append(dict(report=origin(path), runtime_abi=abi,
                         candidate_fingerprint=prior['source']['candidate_fingerprint'], status=prior['status'],
                         archive=dict(path=str(archive.relative_to(ROOT)), bytes=archive.stat().st_size,
                                      sha256=archive_sha), baseline=False, candidate_validation_reused=False))
    return dict(reports=rows,
                scope='Committed6cec ABI43 and44 rejected reports/archives are read-only historical references; no baseline, candidate validation, acceptance or performance credit is reused. Accepted measurement baseline remains Date/a35/ABI42.')


def optional_followup(directory, source_plan, cases, hashes, lock, validators, cache):
    predeclaration = OUT / 'followup-predeclaration.json'
    paths = [directory / ('controls-normal-' + suffix + '.json') for suffix in ['plan', 'complete', 'analysis']]
    if not predeclaration.exists() and not any(path.exists() for path in paths):
        return None
    require(predeclaration.is_file() and all(path.is_file() for path in paths),
            'predeclared optional follow-up incomplete or missing approval')
    review = read(predeclaration)
    require(isinstance(review.get('reviewer'), str) and 'astra' in review['reviewer'].lower() and
            isinstance(review.get('status'), str) and review['status'].lower().startswith('approved') and
            isinstance(review.get('selected_cases'), list), 'explicit Astra follow-up predeclaration required')
    wanted = review['selected_cases']
    require(1 <= len(wanted) <= 8 and len(set(wanted)) == len(wanted) and
            set(wanted) <= {case['file'] for case in cases}, 'follow-up is not a bounded original-source subset')
    selected = [case for case in cases if case['file'] in wanted]
    names = [case['file'] for case in selected]
    plan, complete, analysis = [read(path) for path in paths]
    wrapper = OUT / 'targeted-normal-controls.py'
    wrapper_sha = digest(wrapper)
    require(plan['selected_cases'] == complete['cases'] == analysis['selected_cases'] == names and
            plan['cache_policy_before'] == complete['cache_policy_after'] ==
            analysis['cache_policy_before'] == analysis['cache_policy_after'] == cache and
            plan['followup_driver_sha256'] == complete['followup_driver_sha256'] ==
            analysis['followup_driver_sha256'] == review['followup_driver_sha256'] == wrapper_sha,
            'predeclared follow-up selection/wrapper/cache policy differs')
    # Read the frozen wrapper's literal annotation without executing/importing
    # it. Statistics are always recomputed by the original strict analyzer.
    scope_values = [keyword.value.value
                    for node in ast.parse(wrapper.read_text()).body
                    if isinstance(node, ast.FunctionDef) and node.name == 'save_analysis'
                    for call in ast.walk(node) if isinstance(call, ast.Call)
                    for keyword in call.keywords if keyword.arg == 'scope' and
                    isinstance(keyword.value, ast.Constant) and isinstance(keyword.value.value, str)]
    require(len(scope_values) == 1, 'follow-up wrapper literal scope annotation changed')
    captured = {}
    validators['inputs'] = lambda: (source_plan, selected, hashes)

    def capture(path, value):
        require(Path(path).name == 'controls-normal-analysis.json', 'unexpected follow-up output')
        value.update(scope=scope_values[0], cache_policy_before=cache, cache_policy_after=cache,
                     selected_cases=names, followup_driver_sha256=wrapper_sha)
        captured[Path(path).name] = value

    validators['save'] = capture
    validators['analyze']('controls-normal', ORDER, lock)
    require(captured == {'controls-normal-analysis.json': analysis}, 'optional follow-up raw reconstruction differs')
    return dict(predeclaration=review, plan=plan, completion=complete, analysis=analysis,
                raw_children=len(selected) * 3 * len(ORDER), followup_driver_sha256=wrapper_sha,
                scope='One explicitly predeclared original-source subset; same own products/images/normal cache; independent full raw reconstruction with no pooling/replacement of the complete21 cohort.')


def test262_evidence(products):
    plan, summary = read('test262-selection.json'), read('test262-candidate-summary.json')
    entries = {row['path']: row for row in plan['entries']}
    require(len(entries) == plan['original_file_count'] == len(summary['runs']) == 24,
            'original24 Test262 selection incomplete')
    root = ROOT / plan['suite_root'] / 'test'
    push = {str(path.relative_to(root)) for path in (root / 'built-ins/Array/prototype/push').rglob('*.js')}
    require(len(push) == 24 and push == set(entries), 'complete24 original push family differs')
    actual, variants, raws = set(), 0, []
    for run in summary['runs']:
        name = run['scope']
        require(name in entries and name not in actual and run['product'] == 'candidate' and
                run['exit_code'] == 0 and run['total'] == run['passed'] > 0 and
                run['executable_sha256'] == products['products']['candidate']['scriptw']['sha256'],
                'Test262 run incomplete, duplicated or wrong product')
        path = root / name
        require(path.stat().st_size == entries[name]['bytes'] and digest(path) == entries[name]['sha256'],
                'original Test262 source differs')
        argv = run['argv']
        require(argv[0] == str(OUT / 'candidate/scriptw') and argv[argv.index('run') + 1] == name and
                argv[argv.index('--execution-backend') + 1] == 'wasm-aot' and
                Path(run['raw']).name == run['raw'], 'Test262 raw selector/backend differs')
        raw = inert(OUT / run['raw']).read_text()
        require(re.findall(r'^total: (\d+)$', raw, re.M) == [str(run['total'])] and
                re.findall(r'^passed: (\d+)$', raw, re.M) == [str(run['passed'])], 'Test262 raw totals differ')
        actual.add(name)
        variants += run['passed']
        raws.append(origin(OUT / run['raw']))
    require(actual == set(entries), 'Test262 original-file coverage differs')
    return dict(original_files=24, complete_push_files=24, adjoining_subset_files=0,
                actual_passing_variants=variants, selection=plan, summary=summary, raw_origins=raws,
                scope='Complete pinned24-file push family only; actual variants derive from completed raw runs. No complete Array/Object/Reflect/full-Test262 or status publication claim.')


def measurement_evidence(products):
    directory = OUT / 'measurement'
    lock = read(directory / 'product-lock.json')
    hashes, plan = read(directory / 'source-hashes.json'), read(directory / 'sources/manifest.json')
    canonical = ROOT / 'crates/scriptw-cli/tests/fixtures/v8_execution_hotpaths'
    canonical_plan = read(canonical / 'manifest.json')
    cases = [*plan['execution'], plan['startup']]
    require(len(cases) == len({case['file'] for case in cases}) == 21 and
            [case['file'] for case in plan['execution'][17:]] == DATE_FILES and lock['source_hashes'] == hashes,
            'measurement21 source inventory differs')
    require(plan['execution'][:17] == canonical_plan['execution'] and
            plan['startup'] == canonical_plan['startup'], 'canonical source gate changed')
    for case in [*canonical_plan['execution'], canonical_plan['startup']]:
        require(digest(directory / 'sources' / case['file']) == digest(canonical / case['file']),
                'canonical source copy changed: ' + case['file'])
    for name, sha in hashes.items():
        require(Path(name).name == name and digest(directory / 'sources' / name) == sha, 'measurement source changed')
    for name, sha in lock['support'].items():
        require(digest(ROOT / name) == sha, 'bound measurement validator/support changed')
    for label in ['baseline', 'candidate']:
        require(lock[label]['identity'] == products['identities'][label] and
                lock[label]['expected_runtime_abi'] == (42 if label == 'baseline' else 45), 'measurement product identity differs')
        for tool in ['compiler_precompiled_baseline', 'runtime_baseline']:
            require(lock[label]['products'][tool]['sha256'] == products['products'][label][tool]['sha256'] and
                    lock[label]['products'][tool]['bytes'] == products['products'][label][tool]['bytes'],
                    'measurement product metadata differs')
    # Reuse the measured driver's exact pure validators; never call its product
    # checks, native-image loader, prepare, invoke, measure or main functions.
    selected = {'require', 'check_report_identity', 'statistics_row', 'retained_wrapper', 'producer_header',
                'image_group', 'image_directory', 'arguments', 'observations', 'score',
                'boundary_scope', 'policy_key', 'validate_cache_policy', 'analyze'}
    tree = ast.parse((directory / 'cohort.py').read_text())
    definitions = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name in selected]
    require({node.name for node in definitions} == selected, 'measurement pure-validator interface changed')
    captured, producers = {}, {}
    namespace = dict(OUT=directory, ROOT=ROOT, Path=Path, statistics=statistics,
                     NORMAL_CACHE=OUT / 'normal-cache',
                     DATE_FILES=DATE_FILES, BOUNDARIES=['original', 'retained', 'ordinary'], SAMPLES=21, WARMUPS=10,
                     load=read, digest=digest, inputs=lambda: (plan, cases, hashes),
                     save=lambda path, value: captured.update({Path(path).name: value}))
    exec(compile(ast.Module(body=definitions, type_ignores=[]), str(directory / 'cohort.py'), 'exec'), namespace)
    groups = dict(original=cases, **{'retained-canonical': plan['execution'][:17],
                                   'retained-date': [*plan['execution'][17:], plan['startup'], *plan['execution'][4:17]]})
    for label in ['baseline', 'candidate']:
        for group, expected in groups.items():
            folder = directory / f'images-{label}-{group}'
            report = read(folder / 'producer.json')
            namespace['producer_header'](report, label, group, lock, expected,
                                         digest(directory / ('prepared-' + group) / 'manifest.json'))
            for case in report['cases']:
                if group.startswith('retained-'):
                    require(read(folder / Path(case['image']).with_suffix('.json')) == case,
                            'retained sidecar differs')
                    original, derived = folder / case['original_source_file'], folder / case['derived_source_file']
                    require(digest(original) == case['original_source_sha256'] and
                            digest(derived) == case['derived_source_sha256'] and
                            derived.read_text() == namespace['retained_wrapper'](original.read_text()),
                            'retained exact wrapper/provenance differs')
            producers[label, group] = report
    namespace['producer'] = lambda label, group, bound: producers[label, group]
    namespace['analyze']('balanced', ORDER, lock)
    analysis = read(directory / 'balanced-analysis.json')
    require(captured == {'balanced-analysis.json': analysis}, 'saved analysis differs from strict raw reassembly')
    require(lock['schema'] == 'scriptw-i31-presence-product-lock-v1' and
            lock['baseline']['cohort'] == 'DATE-parent' and lock['candidate']['cohort'] == 'I31',
            'measurement cohort labels/lock schema differ')
    namespace['validate_cache_policy'](lock['cache_policy_at_bind'])
    before, after = analysis['cache_policy_before'], analysis['cache_policy_after']
    require(before == after == lock['cache_policy_at_bind'], 'normal cache substrate changed after binding')
    followup = optional_followup(directory, plan, cases, hashes, lock, namespace, before)
    node = node_evidence(directory, cases, hashes, namespace)
    reference = node['verification']
    namespace['validate_cache_policy'](reference['cache_policy_before'])
    require(reference['cache_policy_before'] == reference['cache_policy_after'] == before,
            'fresh I31 Node command cache binding differs')
    return dict(directory='measurement', analysis_file='measurement/balanced-analysis.json',
                analysis_sha256=digest(directory / 'balanced-analysis.json'), product_lock=lock,
                plan=read(directory / 'balanced-plan.json'), completion=read(directory / 'balanced-complete.json'),
                analysis=analysis, raw_children=504, independent_node_goldens=node,
                targeted_followup=followup,
                raw_validation='Unchanged strict analyzer reconstructs the full504 children and any separately predeclared follow-up. Exact source/producers/sidecars/argv/identities/resources/normal-overlay cache/warmup/output/timing/RSS checked without native product/image reads.',
                scope='Complete21-source normal-overlay DATE-parent versus I31 cohort; optional predeclared follow-up stays separate with no pooling/replacement. Fresh original, ordinary and retained boundaries remain distinct; no subtraction, causal RSS benefit or parity inferred.')



def node_evidence(directory, cases, hashes, validators):
    reference = read(directory / 'reference-node-verification.json')
    require(reference['status'] == 'Independently verified' and
            reference['cases'] == [case['file'] for case in cases] and reference['source_hashes'] == hashes and
            reference['samples'] == 21 and reference['warmups_checked'] == 10,
            'independent Node reference scope differs')
    harness = ROOT / 'crates/scriptw-cli/tests/fixtures/v8_baseline/node-runtime.cjs'
    require(reference['harness_sha256'] == digest(harness), 'Node reference harness changed')
    raw = []
    for case in cases:
        stem = 'reference-node-' + case['file']
        report, command = read(directory / (stem + '.stdout')), read(directory / (stem + '.command.json'))
        require(command['argv'] == [reference['node'], str(harness), str(directory / 'prepared-original'),
                                    '21', '10', case['file']] and command['exit_code'] == 0 and
                command['timed_out'] is False and command['cwd'] == str(ROOT) and
                command['executable_sha256'] == reference['executable_sha256'] and
                command['resource_policy_unchanged'] is True and
                all(delta == 0 for delta in command['oom_event_delta'].values()) and
                validators['policy_key'](command['resources_before']) ==
                validators['policy_key'](command['resources_after']),
                'Node reference raw command/resources differ')
        require(report['schema'] == 'scriptw-v8-baseline-v2' and report['samples'] == 21 and
                report['warmups'] == 10 and len(report['cases']) == 1 and
                dict(node=report['node'], v8=report['v8']) == reference['versions'],
                'Node reference identity/counts differ')
        actual = report['cases'][0]
        require(actual['file'] == case['file'] and actual['source_sha256'] == hashes[case['file']] and
                len(actual['observations']) == 31 and all(
                    value['warmup'] is (index < 10) and value['stdout'] == case['stdout']
                    for index, value in enumerate(actual['observations'])), 'Node reference outputs differ')
        raw.extend(origin(directory / (stem + suffix), archive=True) for suffix in ['.stdout', '.stderr', '.command.json'])
    return dict(verification=reference, raw_origins=raw,
                scope='All21 original source goldens in the existing fresh-context Node/V8 harness; independent output/reference scope, not Scriptw native-cache admission or normal-substrate performance qualification.')


def main():
    required = ['decision.json', 'candidate/identity.json', 'candidate/products.json', 'candidate-build.json',
                'native-final-summary.json', 'native-plan.json', 'compiled-inputs.json', 'source-map-at-freeze.json',
                'test262-candidate-summary.json', 'measurement/product-lock.json',
                'measurement/balanced-plan.json', 'measurement/balanced-complete.json',
                'measurement/balanced-analysis.json', 'measurement/reference-node-verification.json']
    for name in required:
        inert(OUT / name)
    decision = read('decision.json')
    def narrative(value):
        return (isinstance(value, str) and bool(value.strip())) or (
            isinstance(value, list) and bool(value) and
            all(isinstance(item, str) and bool(item.strip()) for item in value))
    require(all(isinstance(decision.get(key), str) and decision[key].strip()
                for key in ['status', 'reviewer']) and 'astra' in decision['reviewer'].lower() and
            all(narrative(decision.get(key)) for key in ['basis', 'next']) and
            isinstance(decision.get('limits'), list) and decision['limits'] and
            all(isinstance(value, str) and value.strip() for value in decision['limits']) and
            decision['status'].lower().startswith(('accepted', 'rejected')),
            'explicit completed Astra decision required')
    products = product_metadata()
    require(decision['candidate_source_fingerprint'] == products['identities']['candidate']['source_fingerprint'] and
            decision['candidate_runtime_layout_abi'] == 45 and
            decision['baseline_source_fingerprint'] == BASELINE and
            decision['baseline_runtime_layout_abi'] == 42 and decision['accepted_parent'] == PARENT,
            'explicit decision source/ABI binding differs')
    native = source_and_native()
    suite = test262_evidence(products)
    measurement = measurement_evidence(products)
    prior = prior_rejection_evidence()
    report = dict(schema='scriptw-i31-presence-v1', complete=True,
                  recorded_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  status=decision['status'], decision=decision,
                  source=dict(parent_commit=PARENT, candidate_fingerprint=products['identities']['candidate']['source_fingerprint'],
                              **products, snapshot='compiled-inputs.json', inputs=native['inputs'],
                              patch_sha256=native['patch_sha256']),
                  change=dict(runtime_abi_before=42, runtime_abi_after=45, default_runtime_policy_changed=False,
                              behavior='Active packed numeric Arrays use closed i31 presence masks only at actual capacities4/8/16. Capacity-zero and inactive states retain the shared empty nominal bitmap; capacities32 and above retain nominal i64 bitmaps. Existing Number payloads, indexed modes, occupancy admission, capacity growth, literal evaluation order, holes, descriptors and JavaScript values remain. Immutable immediate writes synchronize the same retained Array owner and local capability; growth publishes complete backings.',
                              presence_domain=dict(immediate_capacities=[4,8,16], nominal_large_capacity_minimum=32,
                                                   empty_and_inactive='shared empty nominal bitmap',
                                                   shrink_to_immediate=False, new_indexed_modes=0,
                                                   new_runtime_globals=0, new_runtime_helpers=0),
                              array_layout=native['array_layout'],
                              nominal_bitmap_allocation=native['nominal_bitmap_allocation'],
                              allocation_accounting=dict(conditional_records_removed_per_active_small_numeric_array=1,
                                  record_kind='one-word nominal NumberPresenceU64Array',
                                  one_word_record_bytes=32, retained_objects_child_arrays=8192,
                                  conditional_records_removed=8192, conditional_live_bytes_removed=262144,
                                  qualification='Conditional encoded-route/collector accounting for8192 active four-number child Arrays. No whole-heap allocation census, fixed startup RSS reduction, causal measured-memory benefit or Scriptc parity is inferred. The64-byte Array owner and Number backing remain.')),
                  validation=dict(native=native, test262=suite),
                  measurement=measurement, prior_rejection_evidence=prior,
                  limits=[f"{native['unique_passes']} distinct fresh checks cover10 stated native scopes in9 invocations; filtered Engine scopes do not imply complete Engine/workspace coverage.",
                          'Both library cases share the original receipt. Three filtered integration targets retain an exact passing image for the second selector; SHA/size/path/source continuity and final retirement are recorded.',
                          'Test262 covers the complete24-file pinned push family only; actual variants derive from completed raw runs.',
                          'All21 source controls, all three actual boundaries and every slower round/group/sample remain visible; no boundary subtraction or inferred memory/parity claim.',
                          'At most one explicitly Astra-predeclared subset of at most8 original sources may be reconstructed separately on the same products/images/normal cache. It cannot replace or pool with the complete504 children.',
                          'Regenerable Cargo cache relocation/symlink events are distinct from mandatory I31 normal-overlay benchmark cache. Historical failures/deferrals, if any, remain recorded and are not passing coverage. Cache/symlink/native payloads are excluded from the archive.',
                          'Committed rejected ABI43 and44 reports/archives are unchanged historical references, never a baseline or reused candidate acceptance.',
                          'Native identities are read from frozen receipts; this assembler never reads, hashes or executes native products/images. Full-suite status, published charts and release acceptance are unchanged.'])
    with (OUT / 'report-core.json').open('x') as stream:
        stream.write(json.dumps(report, indent=2) + '\n')
    print(json.dumps(dict(output='report-core.json', status=report['status'], native_unique=native['unique_passes'],
                          test262_original_files=suite['original_files'],
                          test262_actual_variants=suite['actual_passing_variants'], workload_rows=21), indent=2))


if __name__ == '__main__':
    main()
