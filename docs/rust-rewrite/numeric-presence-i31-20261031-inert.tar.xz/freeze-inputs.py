"""Future one-shot source freeze; includes new Rust modules without staging Git."""
from pathlib import Path
import datetime
import hashlib
import json
import re
import subprocess
import sys

ROOT = Path('/workspace/scriptw')
OUT = Path(__file__).resolve().parent
DATE = ROOT / 'target/performance-date-demand-20261031'
LAZY = ROOT / 'target/performance-append-key-lazy-summary-20261031'
PARENT = '6cec43bcd2dabfc26fcb42736925d4041e3fe9b5'
sys.path.insert(0, str(ROOT / 'scripts'))
from verification_identity import source_map


def git(*arguments):
    return subprocess.check_output(['git', *arguments], cwd=ROOT)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def save(path, value):
    with path.open('x') as stream:
        stream.write(json.dumps(value, indent=2) + '\n')


def main():
    assert git('rev-parse', 'HEAD').decode().strip() == PARENT
    before = source_map(ROOT)
    assert not (OUT / 'implementation').exists()
    tracked = git('diff', 'HEAD', '--name-only', '-z').split(b'\0')
    untracked = git('ls-files', '--others', '--exclude-standard', '-z').split(b'\0')
    tracked = [path.decode() for path in tracked if path]
    untracked = [path.decode() for path in untracked if path]
    # Historical/public evidence committed in6cec is already a parent input,
    # not an untracked compiler source. New Rust children must be captured.
    assert all(name.endswith('.rs') and name.startswith('crates/') for name in untracked), untracked
    paths = sorted(set(tracked + untracked))
    assert paths and all(name.endswith(('.rs', '.md')) for name in paths), paths
    assert re.search(r'const\s+LAYOUT_VERSION\s*:\s*u32\s*=\s*45\s*;',
                     (ROOT / 'crates/scriptw-aot-wasm/src/runtime_artifact.rs').read_text())

    baseline_identity = json.loads((DATE / 'candidate/identity.json').read_text())
    baseline_products = json.loads((DATE / 'candidate/products.json').read_text())
    assert baseline_identity['source_fingerprint'] == 'a35adbcb61dbc57b4ee44dd1527019358deb137b11ae559de7d0d4b4a860b480'
    assert baseline_identity['source_commit'] == '7c47e38274c9645b6701552c87d38362b2bfbcd5'
    published = json.loads((LAZY / 'baseline-reuse-proof.json').read_text())[
        'committed_parent_matches_all61_Date_published_inputs']
    non_markdown, markdown, differences = {}, {}, {}
    for name, old in published.items():
        current = git('show', 'HEAD:' + name)
        actual = dict(sha256=sha(current), bytes=len(current))
        if name.endswith('.md'):
            markdown[name] = dict(historical_published_identity=old, accepted_parent_identity=actual,
                                  same=actual == old)
            if actual != old:
                differences[name] = markdown[name]
        else:
            assert actual == old, name
            non_markdown[name] = old
    assert len(non_markdown) == 54 and len(markdown) == 7 and len(differences) == 3
    proof = dict(accepted_commit=PARENT, original_identity=baseline_identity,
                 baseline_products=baseline_products,
                 committed_parent_matches_all54_Date_published_non_markdown_inputs=non_markdown,
                 historical_markdown_inputs=markdown, accepted_markdown_differences=differences,
                 identity_policy='Actual frozen Date products retain original7c47+exactpatch source identity. All54 non-Markdown Date published inputs match6cec Git blobs;7 historical Markdown identities and3 later documentation differences are bound separately. No producer is retagged as6cec.')

    rows = {}
    (OUT / 'implementation').mkdir()
    for name in paths:
        path = ROOT / name
        assert path.is_file() and not path.is_symlink()
        data = path.read_bytes()
        rows[name] = dict(sha256=sha(data), bytes=len(data), untracked_new_module=name in untracked)
        destination = OUT / 'implementation' / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        with destination.open('xb') as stream:
            stream.write(data)
    patch = git('diff', '--binary', 'HEAD', '--', *tracked)
    for name in untracked:
        result = subprocess.run(['git', 'diff', '--no-index', '--binary', '/dev/null', name],
                                cwd=ROOT, capture_output=True)
        assert result.returncode == 1 and result.stdout
        patch += result.stdout
    assert source_map(ROOT) == before
    save(OUT / 'compiled-inputs.json', rows)
    with (OUT / 'compile-inputs.patch').open('xb') as stream:
        stream.write(patch)
    save(OUT / 'source-map-at-freeze.json', before)
    save(OUT / 'baseline-identity.json', baseline_identity)
    save(OUT / 'baseline-products.json', baseline_products)
    save(OUT / 'baseline-reuse-proof.json', proof)
    save(OUT / 'state.json', dict(phase='Source frozen; no native/build/Node/measurement claim',
         parent=PARENT, baseline=baseline_identity['source_fingerprint'], layout_before=42,
         layout_after=45, updated_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
         compiled_input_files=len(rows), untracked_new_modules=untracked))
    print('Frozen', len(rows), 'inputs including', len(untracked), 'new Rust modules;54 source/7 historical Markdown baseline proof retained')


if __name__ == '__main__':
    main()
