# Closed i31 numeric presence structural owner

Owned tracked files: tests/emission/packed_array_storage.rs and property_read_plans.rs. Existing integration tests and their current R/P decoders/witnesses are reused; no production API or new target is added. Rejected summary candidates are unrelated.

The dynamic small-literal owner now requires the complete prefix RefI31 in its actual all-Number arm, excludes only nominal presence allocation on that arm, retains the actual Number backing and mixed canonical publisher fallback, and binds the immediate to the real Array presence field. Number/presence field publications target the same fresh Array without an intervening allocation/call. An added callback fixture proves Array/source-Realm prototype capture precedes effects, all four callbacks finish once before backing allocation, and runtime tag guards/fallback remain. Holes/empty/larger literal paths retain their prior checks.

The existing P/R computed numeric hit proof still forbids all allocation/calls and follows the exact fallback exit. Its presence decode must consume a checked i31 test, checked cast, unsigned i31.get_u and i64.extend_i32_u in one arm, and the exact existing nominal bitmap cast/array.get in the other. Both read the same rooted presence and merge into the same word local; immediate word indices other than zero trap. The preexisting actual Number/value/bitmap array.get assertions remain.

Actual shared runtime write/delete owners retain nominal bitmap array.set and must also update the complete OR/AND mask through RefI31, synchronize the live root and publish back to the same Array whose presence field was loaded. Both publication arms are callback/allocation free. Count-zero deletion restores the immutable shared nominal empty bitmap.

Growth selects small storage from the actual new Number backing length<=16. Its small arm carries the complete old presence or explicit zero for empty storage and allocates no bitmap. The large arm preserves zeroed ceil(capacity/64) words, unsigned complete old-i31 seed into word zero, and full nominal bitmap prefix copy. Both arms complete the same prepared root before companion Number/presence writes on the same owner; no allocation/callback intervenes and the live capability root synchronizes immediately.

Formatting and whitespace checks passed. No Cargo/native/Node build or execution, or product hashing, was performed by this owner. Root owns whole-batch compilation and focused native validation after source freeze. Source hashes and snapshots are in receipt.json and the two copied files.
