"""Retire only mutable Cargo aliases after independently freezing exact products."""
from pathlib import Path
import hashlib,json,shutil
ROOT=Path('/workspace/scriptw');OUT=Path(__file__).resolve().parent
receipt=OUT/'candidate-cargo-duplicate-retirement.json';assert not receipt.exists()
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
products=json.loads((OUT/'candidate/products.json').read_text());rows=[];before=shutil.disk_usage(ROOT).free
for name,item in products.items():
 frozen=OUT/'candidate'/name
 assert frozen.is_file() and not frozen.is_symlink() and frozen.stat().st_nlink==1
 assert sha(frozen)==item['sha256'] and frozen.stat().st_size==item['bytes']
 producer=Path(item['cargo_producer']['executable'])
 alias=ROOT/'target/release'/('' if name=='scriptw' else 'examples')/name
 paths=sorted(set([producer,alias]));records=[]
 for p in paths:
  assert p.is_relative_to(ROOT/'target/release') and p.is_file() and not p.is_symlink()
  assert sha(p)==item['sha256'] and p.stat().st_size==item['bytes'] and p.stat().st_ino!=frozen.stat().st_ino
  records.append(str(p))
 for p in paths:p.unlink()
 rows.append(dict(tool=name,sha256=item['sha256'],bytes=item['bytes'],aliases=records,basis='Successful source-bound build; independently owned exact frozen product retained; mutable Cargo duplicate aliases only.'))
receipt.write_text(json.dumps(dict(before_free=before,after_free=shutil.disk_usage(ROOT).free,records=rows),indent=2)+'\n')
print('retired only mutable Cargo duplicates; frozen trio retained')
