from pathlib import Path
import json,subprocess,sys
ROOT=Path('/workspace/scriptw');OUT=Path(__file__).resolve().parent
fp=json.loads((OUT/'candidate/identity.json').read_text())['source_fingerprint']
steps=[('bind',['python3','-B',str(OUT/'measurement/cohort.py'),'bind','--candidate-fingerprint',fp]),('verify-node',['python3','-B',str(OUT/'measurement/cohort.py'),'verify-node','reference']),('test262',['python3','-B',str(OUT/'run-original-test262.py'),'candidate']),('prepare-baseline',['python3','-B',str(OUT/'measurement/cohort.py'),'prepare','baseline']),('prepare-candidate',['python3','-B',str(OUT/'measurement/cohort.py'),'prepare','candidate'])]
rows=[]
for name,argv in steps:
 print('START',name,flush=True)
 with (OUT/('validation-'+name+'.log')).open('xb') as log:r=subprocess.run(argv,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT)
 rows.append(dict(step=name,argv=argv,exit_code=r.returncode))
 (OUT/'validation-prepare-progress.json').write_text(json.dumps(dict(candidate_fingerprint=fp,steps=rows,complete=len(rows)==len(steps) and r.returncode==0),indent=2)+'\n')
 print('END',name,r.returncode,flush=True)
 if r.returncode:sys.exit(r.returncode)
