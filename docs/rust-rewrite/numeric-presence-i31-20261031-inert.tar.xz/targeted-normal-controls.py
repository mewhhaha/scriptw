"""One approved I31 eight-source follow-up; separate from the full normal-overlay cohort."""
from pathlib import Path
import ast,hashlib,importlib.util,json,os,subprocess
ROOT=Path('/workspace/scriptw');OUT=Path(__file__).resolve().parent
script=OUT/'measurement/cohort.py';spec=importlib.util.spec_from_file_location('date_measurement',script);c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
normal=(OUT/'normal-cache').resolve();assert normal.is_dir() and Path(os.environ['SCRIPTW_CACHE_DIR']).resolve()==normal

def cache_policy():
 fs=subprocess.check_output(['stat','-f','--format=%T:%t',str(normal)],text=True).strip()
 assert fs=='overlayfs:794c7630',fs
 return dict(path=str(normal),filesystem=fs,environment_cache_root=os.environ['SCRIPTW_CACHE_DIR'])

wanted={'to-sorted-512.js','numeric-loop-10000.js','integer.js','retained-objects.js','join-empty-1024.js','join-singleton-1024.js','date-first-epoch.js','date-repeated-256.js'}
declaration=c.load(OUT/'followup-predeclaration.json')
assert declaration['status'].startswith('approved') and declaration['followup_driver_sha256']==c.digest(Path(__file__))
plan,all_cases,hashes=c.inputs();cases=[v for v in all_cases if v['file'] in wanted];assert len(cases)==len(wanted)==8
assert [v['file'] for v in cases]==declaration['selected_cases']
assert c.SAMPLES==declaration['samples']==21 and c.WARMUPS==declaration['warmups_checked']==10
assert c.BOUNDARIES==declaration['boundaries']
order=c.ORDERS['eight'];prefix='controls-normal';lock=c.checked_lock();before=c.cache_policy()
assert order==declaration['order'] and before==declaration['cache_policy']
assert c.digest(c.OUT/'product-lock.json')==declaration['product_lock_sha256']
for label in ['baseline','candidate']:
 assert lock[label]['identity']['source_fingerprint']==declaration['source_fingerprints'][label]
 assert lock[label]['expected_runtime_abi']==declaration['expected_runtime_abi'][label]
for label in ['baseline','candidate']:
 for group in c.source_groups():c.producer(label,group,lock)
c.save(c.OUT/(prefix+'-plan.json'),dict(order=order,samples=c.SAMPLES,warmups_checked=c.WARMUPS,boundaries=c.BOUNDARIES,product_lock_sha256=c.digest(c.OUT/'product-lock.json'),source_hashes=hashes,resources_before=c.resources(),cache_policy_before=before,selected_cases=[v['file'] for v in cases],followup_driver_sha256=c.digest(Path(__file__)),followup_predeclaration_sha256=c.digest(OUT/'followup-predeclaration.json'),scope='Astra predeclared I31 eight-source normal-overlay follow-up. Initial full21 normal-overlay cohort retained separately; no pooling or exclusions. Same frozen products and already prepared own images; all3 boundaries,21 measured and10 checked warmups, ABBA+BAAB. No acceptance before review.'))
for index,label in enumerate(order):
 (c.OUT/f'{prefix}-r{index}-{label}-ordinary-artifacts').mkdir()
 for case in cases if index%2==0 else list(reversed(cases)):
  for boundary in c.BOUNDARIES:
   assert Path(os.environ['SCRIPTW_CACHE_DIR']).resolve()==normal
   tool=lock[label]['products']['runtime_baseline' if boundary=='ordinary' else 'compiler_precompiled_baseline']
   report=c.invoke(f'{prefix}-r{index}-{label}-{boundary}-{case["file"]}',c.arguments(prefix,index,label,boundary,case,lock),tool['sha256'])
   c.observations(report,boundary,case,label,lock)
after=c.cache_policy();assert after==before
c.save(c.OUT/(prefix+'-complete.json'),dict(status='All8selectedsources matched all3boundaries',order=order,cases=[v['file'] for v in cases],boundaries=c.BOUNDARIES,resources_after=c.resources(),cache_policy_after=after,followup_driver_sha256=c.digest(Path(__file__))))
# Reuse the unchanged measured driver's exact validation/statistics body with an
# explicit selected-case input. Producer validators retain the full original
# inventories; no source/product/image admission or validation is weakened.
namespace=dict(c.__dict__);namespace['inputs']=lambda:(plan,cases,hashes)
def save_analysis(path,value):
 assert Path(path).name==prefix+'-analysis.json'
 value.update(scope='Eight predeclared unchanged I31 sources only; normal disk-backed overlay cache; all3 boundaries separate; no pooling with the initial full21 cohort, no universal performance or RSS claim.',cache_policy_before=before,cache_policy_after=after,selected_cases=[v['file'] for v in cases],followup_driver_sha256=c.digest(Path(__file__)))
 c.save(path,value)
namespace['save']=save_analysis
nodes=[n for n in ast.parse(script.read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='analyze'];assert len(nodes)==1
exec(compile(ast.Module(body=nodes,type_ignores=[]),str(script),'exec'),namespace)
namespace['analyze'](prefix,order,lock)
print('COMPLETE I31 normal-overlay eight-source follow-up; acceptance remains pending review',flush=True)
