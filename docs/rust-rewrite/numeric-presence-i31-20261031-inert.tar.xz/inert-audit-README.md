# ABI45 inert code audit: prepared, HOLD

`inspect-runtime-code.py` is adapted from the unchanged LAZY driver. It has only been parsed as Python source, never imported or executed. No product, identity, raw Wasm, native image, ELF or archive was opened for this preparation. No tracked file was edited. `inert-audit-source-draft.json` seals the prepared driver hash.

Root may run the exact driver only during its authorized idle audit window after fresh product preparation:

```sh
python3 -B scripts/limited_verification.py --cloud -- python3 -B target/performance-i31-presence-20261031/inspect-runtime-code.py --candidate-fingerprint <new-frozen-FP>
```

Optional `--source-manifest <local-json-name>` and `--source-patch <local-patch-name>` bind a documented test-only continuation without changing this driver. Defaults are compiled-inputs.json and compile-inputs.patch. The chosen snapshot must retain exactly16 inputs and the2 new Rust modules. Current crates Rust files must match the selected frozen snapshot; current Markdown need not match because measurement docs may change. Candidate receipts must identify source parent6cec and ABI45. Baseline Date retains fingerprint a35, ABI42 and its actual7c frozen producer; accepted a9 source identity is not substituted as its producer.

The audit reuses the existing bounded own-host extractor, validates host metadata/SHA before and after extraction, validates runtime framing/SHA/execution receipt and ELF extents, then records R serialized-native and .text sizes plus13 selected helper sizes. It includes known7 LAZY symbols, indexed default/descriptor publication/deletion, object/cached reads and packed join, plus optional Array constructor availability. GetV and the shared numeric probe are inline emission, not independent helper symbols. Source-control labels do not promise native byte identity.

Only publication, object_read and packed_push1 entries are disassembled, at most256 bytes each in each of2 products. Clear stack reservations/allowances and saved registers are observations; absent patterns mean unknown. Data remains inert; no payload loading, execution, live profiling, residency, RSS or native GC-allocation claim is allowed. Extracted ELF/native data stays private under code-size-private and must be excluded from archives by native suffix/magic/regular-file rules. runtime-code-size.json is create-only; preserve a failed attempt before rerunning.

`program-wasm-inspection-plan.json` separately bounds optional freshly prepared raw-P inspection. It distinguishes original objects.js (no child numeric literal) from retained-objects.js (one four-number literal site inside the source8192 loop), and original programs from derived retained-call wrappers. The existing Scriptc core-Wasm decoder rejects GC operators, so it cannot support a Scriptw allocation-site claim. A future semantic witness must use reliable complete GC decoding or report that inspection unavailable. No opaque opcode-byte counts are a substitute.
