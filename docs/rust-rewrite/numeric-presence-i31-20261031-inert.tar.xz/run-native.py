"""Future source-bound native batches; never execute during source preparation."""
from pathlib import Path
import argparse
import gzip
import hashlib
import json
import subprocess
import sys

ROOT = Path('/workspace/scriptw')
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'scripts'))
from verification_identity import source_map


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def save(path, value):
    with Path(path).open('x') as stream:
        stream.write(json.dumps(value, indent=2) + '\n')


def qualified(row):
    return row['package'] + ':' + row['target']


def build_batches(plan):
    scopes = plan['scopes']
    assert len(scopes) == 10
    assert [(row['package'], row['target']) for row in scopes[:2]] == [
        ('scriptw-aot-wasm', 'scriptw_aot_wasm'), ('scriptw-engine', 'scriptw_engine')]
    assert all(row['kind'] == 'lib' for row in scopes[:2])
    assert scopes[0]['filter'] is None and scopes[1]['filter'] == 'wasm_rooted_snapshot::'
    batches = [dict(index=0, name='libraries', scopes=[0, 1])]
    for index, row in enumerate(scopes[2:], 1):
        assert row['kind'] == 'test'
        batches.append(dict(index=index, name=row['target'], scopes=[index + 1]))
    return batches


def products_from_logs(directory):
    products = {}
    for path in directory.glob('*.build.jsonl*'):
        data = gzip.decompress(path.read_bytes()) if path.suffix == '.gz' else path.read_bytes()
        for line in data.splitlines():
            item = json.loads(line)
            if item.get('reason') == 'compiler-artifact' and item.get('executable'):
                products[Path(item['executable'])] = item
    return products


def retire_products(directory, receipt, future_targets, retained, argv, exit_code):
    """No passing/failing/unstarted verdict is inferred from a Cargo output."""
    records, found = [], set()
    cases = receipt['cases']
    for path, item in products_from_logs(directory).items():
        if not path.exists():
            continue
        if item['target']['kind'] == ['custom-build']:
            continue
        assert path.parent.resolve() in [(ROOT / 'target/release/deps').resolve(),
                                         (ROOT / 'target/release/examples').resolve()]
        actual, size = digest(path), path.stat().st_size
        matches = [case for case in cases if item['target']['name'] == case['target']
                   and item['target']['kind'] == [case['kind']] and item['profile']['test']]
        assert len(matches) <= 1
        case = matches[0] if matches else None
        record = dict(path=str(path), sha256=actual, bytes=size, selected=case is not None)
        if case is None:
            assert item['target']['kind'] in [['lib'], ['test'], ['example'], ['bin']]
            path.unlink()
            record['action'] = 'retired unselected Cargo output; no execution verdict'
        else:
            expected_id = 'path+' + (ROOT / 'crates' / case['package']).as_uri() + '#'
            assert item['package_id'].startswith(expected_id), item['package_id']
            target = qualified(case)
            record.update(package=case['package'], target=case['target'], state=case.get('state'))
            if case.get('executable_sha256') is None:
                # A built sibling may be deferred before inventory/execution.
                # Preserve it, with no test verdict and no fabricated pass count.
                record['action'] = 'retained selected unstarted Cargo output; no execution verdict'
            else:
                assert actual == case['executable_sha256'] and size == case['executable_bytes']
                found.add(target)
                if target in retained:
                    assert retained[target] == dict(path=str(path), sha256=actual, bytes=size)
                    record['same_selector_predecessor'] = retained[target]
                if case['state'] == 'passed':
                    assert case['exit_code'] == 0 and case['inventory_matches']
                    assert case['inventoried_tests'] > 0
                    if target in future_targets:
                        record['action'] = 'retained exact passing image for next filter in same Cargo selector'
                        retained[target] = dict(path=str(path), sha256=actual, bytes=size)
                    else:
                        path.unlink()
                        record['action'] = 'retired exact passing image after complete source-bound transcript'
                        retained.pop(target, None)
                else:
                    destination = OUT / 'failed-native' / directory.name / path.name
                    destination.parent.mkdir(parents=True, exist_ok=True)
                    assert not destination.exists()
                    path.rename(destination)
                    assert digest(destination) == actual
                    record.update(action='frozen selected non-passing image outside Cargo',
                                  frozen_path=str(destination))
        records.append(record)
    assert {qualified(case) for case in cases if case.get('executable_sha256')} <= found
    save(directory / 'native-image-retirement.json', dict(argv=argv, exit_code=exit_code, records=records,
         source_map_sha256=receipt['source_map_sha256'],
         policy='Exact Cargo-selected images only; preserve failed and unstarted selected outputs. Passing selected images retire only after complete source-bound inventory/transcript, except same-selector filters kept until the final use.'))
    return records


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--start-batch', type=int, default=0)
    parser.add_argument('--label-suffix', default='')
    args = parser.parse_args()
    assert not args.label_suffix or (args.label_suffix.startswith('-') and
                                    args.label_suffix.replace('-', '').isalnum())
    plan = json.loads((OUT / 'native-plan.json').read_text())
    batches = build_batches(plan)
    assert 0 <= args.start_batch < len(batches)
    frozen = json.loads((OUT / 'source-map-at-freeze.json').read_text())
    assert frozen['head'] == plan['accepted_parent'] == '6cec43bcd2dabfc26fcb42736925d4041e3fe9b5'
    assert source_map(ROOT) == frozen
    results, retained = [], {}
    for batch in batches[args.start_batch:]:
        label = f"native-batch-{batch['index']:02d}-{batch['name']}{args.label_suffix}"
        directory = OUT / label
        rows = [plan['scopes'][index] for index in batch['scopes']]
        argv = ['python3', '-B', 'scripts/run_workspace_tests.py', '--profile', 'release',
                '--packages', 'scriptw-aot-wasm', 'scriptw-engine', '--output', str(directory),
                '--test-processes', '1', '--no-test-incremental', '--idle-builds',
                '--preserve-test-artifacts', '--stop-on-build-failure', '--only-targets',
                *(qualified(row) for row in rows)]
        for row in rows:
            if row['filter']:
                argv.extend(['--native-filter', qualified(row) + '=' + row['filter']])
        print('START', label, [(qualified(row), row['filter']) for row in rows], flush=True)
        with (OUT / (label + '.log')).open('xb') as log:
            result = subprocess.run(argv, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
        receipt = json.loads((directory / 'receipt.json').read_text())
        assert receipt['source_unchanged'] and source_map(ROOT) == frozen
        assert json.loads((directory / 'source-start.json').read_text()) == frozen
        cases = receipt['cases']
        assert {(case['package'], case['target']) for case in cases} == {
            (row['package'], row['target']) for row in rows}
        assert len(cases) == len(rows)
        future = {qualified(row) for later in batches[batch['index'] + 1:]
                  for row in (plan['scopes'][index] for index in later['scopes'])}
        retire_products(directory, receipt, future, retained, argv, result.returncode)
        for index in batch['scopes']:
            row = plan['scopes'][index]
            case = next(case for case in cases if case['package'] == row['package']
                        and case['target'] == row['target'])
            results.append(dict(index=index, batch_index=batch['index'], label=label,
                                package=row['package'], target=row['target'], filter=row['filter'],
                                state=case.get('state'), exit_code=case.get('exit_code'),
                                inventoried_tests=case.get('inventoried_tests'),
                                outcomes=case.get('outcomes'),
                                executable_sha256=case.get('executable_sha256')))
        passed = result.returncode == 0 and all(case['state'] == 'passed' for case in cases)
        print('END', label, [(case['target'], case.get('state'), case.get('outcomes')) for case in cases], flush=True)
        if not passed:
            break
    expected = sum(len(batch['scopes']) for batch in batches[args.start_batch:])
    complete = len(results) == expected
    all_passed = bool(results) and all(row['state'] == 'passed' for row in results)
    save(OUT / f'native-summary-start{args.start_batch}{args.label_suffix}.json',
         dict(complete=complete, all_passed=all_passed, scopes=results,
              actual_passed=sum(outcome['passed'] for row in results
                                for outcome in row.get('outcomes') or []),
              source_snapshot='compiled-inputs.json', source_unchanged_every_scope=True,
              scope='Actual source-bound inventories from10 planned scopes in9 batches; combined two-library batch and eight focused integration invocations. Counts are actual, not predicted.'))
    raise SystemExit(0 if complete and all_passed else 1)


if __name__ == '__main__':
    main()
