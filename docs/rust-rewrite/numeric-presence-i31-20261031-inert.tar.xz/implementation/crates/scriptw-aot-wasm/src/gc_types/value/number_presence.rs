//! Closed numeric presence operands and owner-bound live mutations.
use super::*;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum SmallNumberCapacity {
    Four,
    Eight,
    Sixteen,
}

impl SmallNumberCapacity {
    pub(crate) const fn new(capacity: u32) -> Option<Self> {
        match capacity {
            4 => Some(Self::Four),
            8 => Some(Self::Eight),
            16 => Some(Self::Sixteen),
            _ => None,
        }
    }

    const fn slots(self) -> u32 {
        match self {
            Self::Four => 4,
            Self::Eight => 8,
            Self::Sixteen => 16,
        }
    }
}

/// Only a complete, validated literal prefix can create a constant mask.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) struct SmallNumberMask {
    bits: u32,
}

impl SmallNumberMask {
    pub(crate) const fn prefix(capacity: SmallNumberCapacity, length: u32) -> Option<Self> {
        if length > capacity.slots() {
            None
        } else {
            Some(Self {
                bits: (1_u32 << length) - 1,
            })
        }
    }
}

fn root(function: &mut Function) -> EqRefLocal {
    EqRefLocal {
        // Physical nullability permits explicit root retirement. Published
        // operands always refine this private local to nonnull.
        index: function.reserve_typed_local(ValType::Ref(RefType::EQREF)),
    }
}

fn clear_root(root: EqRefLocal, function: &mut Function) {
    root.clear(function);
    function.release_typed_local(root.index);
}

fn i31_type() -> HeapType {
    HeapType::Abstract {
        shared: false,
        ty: wasm_encoder::AbstractHeapType::I31,
    }
}

fn nonnull(root: &EqRefLocal, function: &mut Function) {
    root.load(function);
    function.instruction(&Instruction::RefAsNonNull);
}

fn immediate_test(root: &EqRefLocal, function: &mut Function) {
    root.load(function);
    function.instruction(&Instruction::RefTestNonNull(i31_type()));
}

fn immediate_word(root: &EqRefLocal, function: &mut Function) {
    nonnull(root, function);
    function.instruction(&Instruction::RefCastNonNull(i31_type()));
    function.instruction(&Instruction::I31GetU);
    function.instruction(&Instruction::I64ExtendI32U);
}

fn bitmap(
    root: &EqRefLocal,
    schema: &RuntimeSchema,
    function: &mut Function,
) -> GcLocal<NumberPresenceU64Array> {
    nonnull(root, function);
    function.instruction(&Instruction::RefCastNonNull(
        schema
            .reference_type::<NumberPresenceU64Array>(GcNullability::NonNullable)
            .heap_type,
    ));
    schema
        .reserve_gc_local(function)
        .initialize(GcStackReference::new(), function)
}

/// A rooted unpublished replacement. Public factories accept only an exact
/// nominal bitmap or a validated constant mask, never an arbitrary EqRef/word.
#[must_use = "publish or clear the prepared presence root"]
pub(crate) struct PreparedNumberPresence {
    root: EqRefLocal,
}

impl PreparedNumberPresence {
    pub(crate) fn from_bitmap(
        value: &GcLocal<NumberPresenceU64Array>,
        schema: &RuntimeSchema,
        function: &mut Function,
    ) -> Self {
        let result = Self {
            root: root(function),
        };
        let _ = value.load(schema, function);
        function.instruction(&Instruction::LocalSet(result.root.index));
        result
    }

    pub(crate) fn from_mask(
        mask: SmallNumberMask,
        _schema: &RuntimeSchema,
        function: &mut Function,
    ) -> Self {
        let result = Self {
            root: root(function),
        };
        function.instruction(&Instruction::I32Const(mask.bits as i32));
        function.instruction(&Instruction::RefI31);
        function.instruction(&Instruction::LocalSet(result.root.index));
        result
    }

    pub(crate) fn operand(&self) -> GcOperand<'_, NumberPresenceStorage, NonNullable> {
        GcOperand {
            source: OperandSource::NonNullLocal(self.root.index),
            shape: PhantomData,
        }
    }

    pub(crate) fn clear(self, function: &mut Function) {
        clear_root(self.root, function);
    }
}

/// Loaded only from its retained owner. No raw reference or independent local
/// replacement escapes; an immutable i31 replacement updates both roots.
#[must_use = "clear the owner-bound presence root before leaving its scope"]
pub(crate) struct NumberPresence<'owner> {
    owner: &'owner GcLocal<ArrayObject>,
    root: EqRefLocal,
}

impl RuntimeSchema {
    pub(crate) fn array_number_presence<'owner>(
        &self,
        owner: &'owner GcLocal<ArrayObject>,
        function: &mut Function,
    ) -> NumberPresence<'owner> {
        let result = NumberPresence {
            owner,
            root: root(function),
        };
        let _ = self
            .field(ArrayObjectSchema::NUMBER_PRESENT)
            .read(owner, self, function);
        function.instruction(&Instruction::LocalSet(result.root.index));
        result
    }
}

impl<'owner> NumberPresence<'owner> {
    /// Consume the already-emitted immediate test, merging either decoded
    /// representation into the caller's scalar output local.
    fn read_selected_word(
        &self,
        word: I32Local,
        output: I64Local,
        schema: &RuntimeSchema,
        function: &mut Function,
    ) {
        function.instruction(&Instruction::If(BlockType::Empty));
        // An immediate covers exactly word zero. Do not silently alias another
        // word if an internal caller loses its existing capacity guard.
        word.load(function);
        function.instruction(&Instruction::If(BlockType::Empty));
        function.instruction(&Instruction::Unreachable);
        function.instruction(&Instruction::End);
        immediate_word(&self.root, function);
        output.store(function);
        function.instruction(&Instruction::Else);
        let bitmap = bitmap(&self.root, schema, function);
        schema
            .array_type::<NumberPresenceU64Array>()
            .read(&bitmap, word, schema, function)
            .store_i64(output, function);
        bitmap.clear(function);
        function.instruction(&Instruction::End);
    }

    /// The caller retains its existing index/capacity proof. Empty nominal
    /// storage cannot be word-read; the nominal array.get preserves its trap.
    pub(crate) fn read_word(
        &self,
        word: I32Local,
        output: I64Local,
        schema: &RuntimeSchema,
        function: &mut Function,
    ) {
        immediate_test(&self.root, function);
        self.read_selected_word(word, output, schema, function);
    }

    pub(crate) fn bit<'presence>(
        &'presence mut self,
        index: I32Local,
        schema: &RuntimeSchema,
        function: &mut Function,
    ) -> NumberPresenceBit<'presence, 'owner> {
        // A bit writer, unlike read_word, must prove the exact owner capacity
        // before it can create a new complete immediate mask.
        let numbers = schema.reserve_gc_local(function).initialize(
            schema
                .field(ArrayObjectSchema::NUMBERS)
                .read(self.owner, schema, function)
                .reference(),
            function,
        );
        index.load(function);
        schema
            .array_type::<NumberBitsI64Array>()
            .length(&numbers, schema, function);
        function.instruction(&Instruction::I32GeU);
        function.instruction(&Instruction::If(BlockType::Empty));
        function.instruction(&Instruction::Unreachable);
        function.instruction(&Instruction::End);
        numbers.clear(function);
        let word = schema.reserve_i32_local(function);
        let mask = schema.reserve_i64_local(function);
        let bits = schema.reserve_i64_local(function);
        let immediate = schema.reserve_i32_local(function);
        index.load(function);
        function.instruction(&Instruction::I32Const(6));
        function.instruction(&Instruction::I32ShrU);
        word.store(function);
        function.instruction(&Instruction::I64Const(1));
        index.load(function);
        function.instruction(&Instruction::I64ExtendI32U);
        function.instruction(&Instruction::I64Shl);
        mask.store(function);
        immediate_test(&self.root, function);
        immediate.store(function);
        immediate.load(function);
        self.read_selected_word(word, bits, schema, function);
        NumberPresenceBit {
            presence: self,
            word,
            mask,
            bits,
            immediate,
        }
    }

    /// Derive both capacities from actual typed Number backings. Old/new roots
    /// survive all allocation; no field is published by this preparation.
    pub(crate) fn prepare_growth(
        &self,
        new_numbers: &GcLocal<NumberBitsI64Array>,
        schema: &RuntimeSchema,
        function: &mut Function,
    ) -> PreparedNumberPresence {
        let old_numbers = schema.reserve_gc_local(function).initialize(
            schema
                .field(ArrayObjectSchema::NUMBERS)
                .read(self.owner, schema, function)
                .reference(),
            function,
        );
        let old_capacity = schema.reserve_i32_local(function);
        let new_capacity = schema.reserve_i32_local(function);
        schema
            .array_type::<NumberBitsI64Array>()
            .length(&old_numbers, schema, function);
        old_capacity.store(function);
        schema
            .array_type::<NumberBitsI64Array>()
            .length(new_numbers, schema, function);
        new_capacity.store(function);
        // The existing growth owner selects a strictly larger power of two,
        // at least four. These checks enforce that closed internal contract.
        new_capacity.load(function);
        old_capacity.load(function);
        function.instruction(&Instruction::I32LeU);
        new_capacity.load(function);
        function.instruction(&Instruction::I32Const(4));
        function.instruction(&Instruction::I32LtU);
        function.instruction(&Instruction::I32Or);
        new_capacity.load(function);
        new_capacity.load(function);
        function.instruction(&Instruction::I32Const(1));
        function.instruction(&Instruction::I32Sub);
        function.instruction(&Instruction::I32And);
        function.instruction(&Instruction::I32Or);
        function.instruction(&Instruction::If(BlockType::Empty));
        function.instruction(&Instruction::Unreachable);
        function.instruction(&Instruction::End);
        let result = PreparedNumberPresence {
            root: root(function),
        };
        let word = schema.reserve_i32_local(function);
        let bits = schema.reserve_i64_local(function);
        word.set_constant(0, function);
        new_capacity.load(function);
        function.instruction(&Instruction::I32Const(16));
        function.instruction(&Instruction::I32LeU);
        function.instruction(&Instruction::If(BlockType::Empty));
        old_capacity.load(function);
        function.instruction(&Instruction::If(BlockType::Empty));
        self.read_word(word, bits, schema, function);
        function.instruction(&Instruction::Else);
        bits.set_constant(0, function);
        function.instruction(&Instruction::End);
        // Strict growth plus a new capacity4/8/16 proves the entire old mask
        // fits; this is not truncation of an arbitrary heap word.
        bits.load(function);
        function.instruction(&Instruction::I32WrapI64);
        function.instruction(&Instruction::RefI31);
        function.instruction(&Instruction::LocalSet(result.root.index));
        function.instruction(&Instruction::Else);
        let words = schema.reserve_i32_local(function);
        new_capacity.load(function);
        function.instruction(&Instruction::I32Const(63));
        function.instruction(&Instruction::I32Add);
        function.instruction(&Instruction::I32Const(6));
        function.instruction(&Instruction::I32ShrU);
        words.store(function);
        let replacement = schema.reserve_gc_local(function).initialize(
            schema.array_type::<NumberPresenceU64Array>().filled(
                GcOperand::i64(0),
                words,
                function,
            ),
            function,
        );
        old_capacity.load(function);
        function.instruction(&Instruction::If(BlockType::Empty));
        immediate_test(&self.root, function);
        function.instruction(&Instruction::If(BlockType::Empty));
        immediate_word(&self.root, function);
        bits.store(function);
        schema.array_type::<NumberPresenceU64Array>().write(
            &replacement,
            word,
            GcOperand::i64_local(bits),
            schema,
            function,
        );
        function.instruction(&Instruction::Else);
        let old_bitmap = bitmap(&self.root, schema, function);
        schema
            .array_type::<NumberPresenceU64Array>()
            .length(&old_bitmap, schema, function);
        words.store(function);
        schema
            .array_type::<NumberPresenceU64Array>()
            .copy_prefix_from(&replacement, &old_bitmap, words, schema, function);
        old_bitmap.clear(function);
        function.instruction(&Instruction::End);
        function.instruction(&Instruction::End);
        let _ = replacement.load(schema, function);
        function.instruction(&Instruction::LocalSet(result.root.index));
        replacement.clear(function);
        schema.release_i32_local(words, function);
        function.instruction(&Instruction::End);
        schema.release_i64_local(bits, function);
        schema.release_i32_local(word, function);
        schema.release_i32_local(new_capacity, function);
        schema.release_i32_local(old_capacity, function);
        old_numbers.clear(function);
        result
    }

    /// Called immediately after the companion Number field publication. No
    /// allocation/callback occurs between the owner and local writes here.
    pub(crate) fn replace_presence(
        &mut self,
        value: &PreparedNumberPresence,
        schema: &RuntimeSchema,
        function: &mut Function,
    ) {
        schema.field(ArrayObjectSchema::NUMBER_PRESENT).write(
            self.owner,
            value.operand(),
            schema,
            function,
        );
        value.operand().emit(function);
        function.instruction(&Instruction::LocalSet(self.root.index));
    }

    pub(crate) fn clear(self, function: &mut Function) {
        clear_root(self.root, function);
    }
}

/// A complete word plus one admitted in-capacity bit. No numeric local escapes
/// to a caller that could manufacture a truncated immediate replacement.
#[must_use = "release the complete word/bit capability after its callback-free use"]
pub(crate) struct NumberPresenceBit<'presence, 'owner> {
    presence: &'presence mut NumberPresence<'owner>,
    word: I32Local,
    mask: I64Local,
    bits: I64Local,
    immediate: I32Local,
}

impl NumberPresenceBit<'_, '_> {
    pub(crate) fn is_present(&self, function: &mut Function) {
        self.bits.load(function);
        self.mask.load(function);
        function.instruction(&Instruction::I64And);
        function.instruction(&Instruction::I64Eqz);
        function.instruction(&Instruction::I32Eqz);
    }

    pub(crate) fn set_present(&mut self, schema: &RuntimeSchema, function: &mut Function) {
        self.bits.load(function);
        self.mask.load(function);
        function.instruction(&Instruction::I64Or);
        self.bits.store(function);
        self.publish(schema, function);
    }

    pub(crate) fn clear_present(&mut self, schema: &RuntimeSchema, function: &mut Function) {
        self.bits.load(function);
        self.mask.load(function);
        function.instruction(&Instruction::I64Const(-1));
        function.instruction(&Instruction::I64Xor);
        function.instruction(&Instruction::I64And);
        self.bits.store(function);
        self.publish(schema, function);
    }

    fn publish(&mut self, schema: &RuntimeSchema, function: &mut Function) {
        self.immediate.load(function);
        function.instruction(&Instruction::If(BlockType::Empty));
        // The complete old mask plus/minus a validated in-capacity bit fits
        // at most16 bits. Only this private mutation owner emits ref.i31.
        self.bits.load(function);
        function.instruction(&Instruction::I32WrapI64);
        function.instruction(&Instruction::RefI31);
        function.instruction(&Instruction::LocalSet(self.presence.root.index));
        schema.field(ArrayObjectSchema::NUMBER_PRESENT).write(
            self.presence.owner,
            GcOperand {
                source: OperandSource::NonNullLocal(self.presence.root.index),
                shape: PhantomData,
            },
            schema,
            function,
        );
        function.instruction(&Instruction::Else);
        let bitmap = bitmap(&self.presence.root, schema, function);
        schema.array_type::<NumberPresenceU64Array>().write(
            &bitmap,
            self.word,
            GcOperand::i64_local(self.bits),
            schema,
            function,
        );
        bitmap.clear(function);
        function.instruction(&Instruction::End);
    }

    pub(crate) fn release(self, schema: &RuntimeSchema, function: &mut Function) {
        schema.release_i32_local(self.immediate, function);
        schema.release_i64_local(self.bits, function);
        schema.release_i64_local(self.mask, function);
        schema.release_i32_local(self.word, function);
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn small_masks_admit_only_declared_capacities_and_complete_prefixes() {
        for capacity in [0, 1, 2, 3, 5, 15, 17, 31, 32, 64, u32::MAX] {
            assert_eq!(SmallNumberCapacity::new(capacity), None);
        }
        for (capacity, length, expected) in [
            (SmallNumberCapacity::Four, 0, 0),
            (SmallNumberCapacity::Four, 4, 0xf),
            (SmallNumberCapacity::Eight, 8, 0xff),
            (SmallNumberCapacity::Sixteen, 15, 0x7fff),
            (SmallNumberCapacity::Sixteen, 16, 0xffff),
        ] {
            assert_eq!(
                SmallNumberMask::prefix(capacity, length).unwrap().bits,
                expected
            );
            assert!(SmallNumberMask::prefix(capacity, capacity.slots() + 1).is_none());
        }
    }
}
