//! Read-only validation of the Array-owned small mask / nominal bitmap domain.
use super::{invariant, SnapshotRejection};
use scriptw_aot_wasm::ArrayIndexedStorageMode;
use wasmtime::{ArrayRef, AsContextMut, EqRef, HeapType, Rooted, Val};

pub(super) enum NumberPresenceView {
    Small(u32),
    Bitmap { array: Rooted<ArrayRef>, words: u32 },
}

impl NumberPresenceView {
    pub(super) fn decode(
        store: &mut impl AsContextMut,
        reference: Option<Rooted<EqRef>>,
        expected_bitmap: &HeapType,
        mode: ArrayIndexedStorageMode,
        capacity: u32,
        count: i64,
        length: i64,
    ) -> Result<Self, SnapshotRejection> {
        let reference = reference.ok_or_else(|| invariant("required Array presence is null"))?;
        if count < 0 || !(0..=u32::MAX as i64).contains(&length) {
            return Err(invariant("invalid Array presence count/length"));
        }
        if mode == ArrayIndexedStorageMode::PackedNumbers {
            if capacity > (1 << 20)
                || (capacity != 0 && (capacity < 4 || !capacity.is_power_of_two()))
                || count as u64 > u64::from(capacity)
                || count > length
            {
                return Err(invariant("invalid packed Number Array capacity/count"));
            }
        } else if capacity != 0 {
            return Err(invariant("inactive Array Number backing is not empty"));
        }

        // Test the immediate before consulting the nominal array witness. An
        // unsigned decode preserves every admitted bit, including bit 15.
        if let Some(immediate) = reference.as_i31(&*store).map_err(invariant)? {
            if mode != ArrayIndexedStorageMode::PackedNumbers || !matches!(capacity, 4 | 8 | 16) {
                return Err(invariant(
                    "Array immediate presence has an invalid mode/capacity",
                ));
            }
            let bits = immediate.get_u32();
            if bits >> capacity != 0
                || i64::from(bits.count_ones()) != count
                || (bits != 0 && i64::from(31 - bits.leading_zeros()) >= length)
            {
                return Err(invariant(
                    "invalid Array immediate presence bits/count/length",
                ));
            }
            return Ok(Self::Small(bits));
        }

        let actual = reference.ty(&*store).map_err(invariant)?;
        if !HeapType::eq(&actual, expected_bitmap) {
            return Err(invariant("canonical ArrayNumberPresence type mismatch"));
        }
        let array = reference
            .as_array(&*store)
            .map_err(invariant)?
            .ok_or_else(|| invariant("Array presence is not an array"))?;
        let words = array.len(&*store).map_err(invariant)?;
        let expected_words = if mode == ArrayIndexedStorageMode::PackedNumbers && capacity != 0 {
            if capacity < 32 {
                return Err(invariant(
                    "small packed Number Array presence is not immediate",
                ));
            }
            capacity.div_ceil(64)
        } else {
            0
        };
        if words != expected_words {
            return Err(invariant("invalid Array presence bitmap extent"));
        }
        Ok(Self::Bitmap { array, words })
    }

    /// Small masks consume one virtual word of the same snapshot work budget
    /// as the former one-word bitmap. Empty/inactive bitmaps consume no words.
    pub(super) fn word_count(&self) -> u32 {
        match self {
            Self::Small(_) => 1,
            Self::Bitmap { words, .. } => *words,
        }
    }

    pub(super) fn word(
        &self,
        store: &mut impl AsContextMut,
        word: u32,
    ) -> Result<u64, SnapshotRejection> {
        if word >= self.word_count() {
            return Err(invariant("Array presence word is out of bounds"));
        }
        match self {
            Self::Small(bits) => Ok(u64::from(*bits)),
            Self::Bitmap { array, .. } => {
                let Val::I64(bits) = array.get(&mut *store, word).map_err(invariant)? else {
                    return Err(invariant("Array presence word is not I64"));
                };
                Ok(bits as u64)
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use wasmtime::{
        ArrayRefPre, ArrayType, FieldType, Mutability, StorageType, Store, ValType, I31,
    };

    struct Fixture {
        store: Store<()>,
        bitmap: ArrayType,
    }

    impl Fixture {
        fn new() -> Self {
            let engine = crate::shared_wasm_engine().unwrap();
            let bitmap = ArrayType::new(
                &engine,
                FieldType::new(Mutability::Var, StorageType::ValType(ValType::I64)),
            );
            Self {
                store: Store::new(&engine, ()),
                bitmap,
            }
        }
        fn immediate(&mut self, bits: u32) -> Rooted<EqRef> {
            EqRef::from_i31(&mut self.store, I31::new_u32(bits).unwrap())
        }
        fn bitmap(&mut self, words: &[i64]) -> Rooted<EqRef> {
            let pre = ArrayRefPre::new(&mut self.store, self.bitmap.clone());
            let words = words.iter().copied().map(Val::I64).collect::<Vec<_>>();
            ArrayRef::new_fixed(&mut self.store, &pre, &words)
                .unwrap()
                .to_eqref()
        }
        fn decode(
            &mut self,
            reference: Option<Rooted<EqRef>>,
            mode: ArrayIndexedStorageMode,
            capacity: u32,
            count: i64,
            length: i64,
        ) -> Result<NumberPresenceView, SnapshotRejection> {
            NumberPresenceView::decode(
                &mut self.store,
                reference,
                &HeapType::ConcreteArray(self.bitmap.clone()),
                mode,
                capacity,
                count,
                length,
            )
        }
    }

    fn rejects(result: Result<NumberPresenceView, SnapshotRejection>) {
        assert!(matches!(
            result,
            Err(SnapshotRejection::BackendInvariant { .. })
        ));
    }

    #[test]
    fn small_presence_preserves_zero_and_nonprefix_unsigned_masks() {
        let mut f = Fixture::new();
        for (capacity, bits, count, length) in [
            (4, 0, 0, u32::MAX as i64),
            (4, 0b0101, 2, 3),
            (8, 0b1000_0001, 2, 8),
            (16, (1 << 15) | (1 << 3), 2, 16),
        ] {
            let reference = f.immediate(bits);
            let view = f
                .decode(
                    Some(reference),
                    ArrayIndexedStorageMode::PackedNumbers,
                    capacity,
                    count,
                    length,
                )
                .unwrap();
            assert_eq!(view.word_count(), 1);
            assert_eq!(view.word(&mut f.store, 0).unwrap(), u64::from(bits));
            assert!(view.word(&mut f.store, 1).is_err());
        }
        rejects(f.decode(None, ArrayIndexedStorageMode::PackedNumbers, 4, 0, 4));
    }

    #[test]
    fn small_presence_rejects_wrong_domains_high_bits_and_occupancy() {
        let mut f = Fixture::new();
        for mode in [
            ArrayIndexedStorageMode::PackedValues,
            ArrayIndexedStorageMode::DenseDescriptors,
            ArrayIndexedStorageMode::SparseDescriptors,
        ] {
            let reference = f.immediate(0);
            rejects(f.decode(Some(reference), mode, 0, 0, 0));
        }
        for capacity in [0, 1, 2, 3, 5, 32, 64, 1 << 21] {
            let reference = f.immediate(0);
            rejects(f.decode(
                Some(reference),
                ArrayIndexedStorageMode::PackedNumbers,
                capacity,
                0,
                64,
            ));
        }
        for (bits, count, length) in [
            (1 << 4, 1, 5),
            (1 << 30, 1, 31),
            (1, -1, 4),
            (1, 2, 4),
            (1, 1, 0),
            (0, 0, -1),
            (0, 0, u32::MAX as i64 + 1),
        ] {
            let reference = f.immediate(bits);
            rejects(f.decode(
                Some(reference),
                ArrayIndexedStorageMode::PackedNumbers,
                4,
                count,
                length,
            ));
        }
    }

    #[test]
    fn nominal_presence_keeps_large_unsigned_words_and_inactive_empty_storage() {
        let mut f = Fixture::new();
        for (capacity, words, count, length) in [
            (0, vec![], 0, u32::MAX as i64),
            (32, vec![1_i64 << 31], 1, 32),
            (64, vec![i64::MIN], 1, 64),
            (128, vec![1, i64::MIN], 2, 128),
        ] {
            let reference = f.bitmap(&words);
            let view = f
                .decode(
                    Some(reference),
                    ArrayIndexedStorageMode::PackedNumbers,
                    capacity,
                    count,
                    length,
                )
                .unwrap();
            assert_eq!(view.word_count() as usize, words.len());
            for (index, expected) in words.iter().enumerate() {
                assert_eq!(
                    view.word(&mut f.store, index as u32).unwrap(),
                    *expected as u64
                );
            }
        }
        for mode in [
            ArrayIndexedStorageMode::PackedValues,
            ArrayIndexedStorageMode::DenseDescriptors,
            ArrayIndexedStorageMode::SparseDescriptors,
        ] {
            let reference = f.bitmap(&[]);
            let view = f.decode(Some(reference), mode, 0, 7, 7).unwrap();
            assert_eq!(view.word_count(), 0);
        }
    }

    #[test]
    fn nominal_presence_rejects_small_heap_extent_and_wrong_nominal_shapes() {
        let mut f = Fixture::new();
        for (capacity, words, count, length) in [
            (4, vec![1], 1, 4),
            (0, vec![0], 0, 0),
            (32, vec![], 0, 32),
            (128, vec![1], 1, 128),
            (33, vec![0], 0, 33),
            (32, vec![0], 33, 33),
            (32, vec![0], 1, 0),
        ] {
            let reference = f.bitmap(&words);
            rejects(f.decode(
                Some(reference),
                ArrayIndexedStorageMode::PackedNumbers,
                capacity,
                count,
                length,
            ));
        }
        let reference = f.bitmap(&[0]);
        rejects(f.decode(
            Some(reference),
            ArrayIndexedStorageMode::PackedValues,
            0,
            0,
            0,
        ));

        // Wasmtime canonicalizes structurally identical array types. Use a
        // genuinely different element type rather than another i64 ArrayType.
        let wrong = ArrayType::new(
            f.store.engine(),
            FieldType::new(Mutability::Var, StorageType::ValType(ValType::I32)),
        );
        let pre = ArrayRefPre::new(&mut f.store, wrong);
        let reference = ArrayRef::new_fixed(&mut f.store, &pre, &[Val::I32(0)])
            .unwrap()
            .to_eqref();
        rejects(f.decode(
            Some(reference),
            ArrayIndexedStorageMode::PackedNumbers,
            32,
            0,
            32,
        ));

        let wrong = wasmtime::StructType::new(f.store.engine(), []).unwrap();
        let pre = wasmtime::StructRefPre::new(&mut f.store, wrong);
        let reference = wasmtime::StructRef::new(&mut f.store, &pre, &[])
            .unwrap()
            .to_eqref();
        rejects(f.decode(
            Some(reference),
            ArrayIndexedStorageMode::PackedNumbers,
            32,
            0,
            32,
        ));
    }
}
