# Numeric Array presence schema/capability implementation

This owned chunk is installed in the working tree against accepted a9 production blobs, restored at HEAD 6cec43bcd2dabfc26fcb42736925d4041e3fe9b5. Root owns the ABI45 bump, producer/mutation changes and docs; sibling agents own host decode and encoded/behavioral integration. Only the five paths in implementation-receipt.json were edited by this owner. The combined owned patch includes the new untracked module. No staging/commit occurred.

`NumberPresenceStorage` is sealed and implements storage only for the nonnullable Array field. No AnyGcRef widening or generic abstract-reference conversion was added. The nominal large/empty bitmap type remains registered. The private nullable local permits explicit retirement; every field operand is nonnull.

## Final API

- `SmallNumberCapacity::new(u32) -> Option<Self>` admits only 4/8/16.
- `SmallNumberMask::prefix(SmallNumberCapacity, u32) -> Option<Self>` admits only a complete in-capacity prefix.
- `PreparedNumberPresence::from_bitmap(&GcLocal<NumberPresenceU64Array>, &RuntimeSchema, &mut Function) -> Self` and `from_mask(SmallNumberMask, &RuntimeSchema, &mut Function) -> Self` are the only public factories. `operand()` returns the exact field operand; `clear(self, &mut Function)` retires its private root.
- `RuntimeSchema::array_number_presence<'o>(&self, &'o GcLocal<ArrayObject>, &mut Function) -> NumberPresence<'o>` is the only live load.
- `NumberPresence::read_word(&self, I32Local, I64Local, &RuntimeSchema, &mut Function)` emits one direct i31 test/branch, unsigned i31 decode or exact nominal array.get, merging into the output local. Immediate word indices other than zero trap; existing caller capacity/admission proofs remain.
- `NumberPresence::bit<'p>(&'p mut self, I32Local, &RuntimeSchema, &mut Function) -> NumberPresenceBit<'p, 'o>` proves the bit is below actual owner NUMBERS length and retains one complete decoded word/mask plus one cached representation flag. `is_present(&self, &mut Function)` pushes an i32 boolean. `set_present`/`clear_present(&mut self, &RuntimeSchema, &mut Function)` publish through the same owner. `release(self, &RuntimeSchema, &mut Function)` releases scalar locals. Keep the capability within its callback-free mutation segment.
- `NumberPresence::prepare_growth(&self, &GcLocal<NumberBitsI64Array>, &RuntimeSchema, &mut Function) -> PreparedNumberPresence` derives actual old/new capacities, requiring a strictly growing power-of-two capacity >=4. Empty-to-small, small-to-small, empty/small-to-large and large-to-large are handled without reading an empty bitmap. New storage remains private; large storage is nominal and zero-filled, with old bits seeded/copied.
- `NumberPresence::replace_presence(&mut self, &PreparedNumberPresence, &RuntimeSchema, &mut Function)` writes owner and private root consecutively, with no allocation/callback; caller publishes companion NUMBERS immediately before it. `clear(self, &mut Function)` retires the root.

No arbitrary i64-to-i31 publication, caller-provided EqRef, raw local index or owner-independent mutable word API escapes. An immediate bit edit updates both local and owner; a nominal edit uses exact array.set. The prepared operand can wrap the shared nominal empty bitmap for the existing empty constructor/common clear.

## Verification boundary

Changed-file rustfmt (edition2021, skip_children), owned tracked diff whitespace and new-module whitespace checks passed. No builds or tests were run. New tests prove literal mask admission and, when executed, the actual pinned collector's nominal one-word bitmap32 layout. Adapted tests retain actual Array64, six potential GC fields, all existing offsets and concrete reference requirements for every field except the exact presence slot. No collector outcome or performance improvement is claimed before the whole-batch checks. Per-read discrimination/casts and per-write capacity validation add real work that must be measured.
