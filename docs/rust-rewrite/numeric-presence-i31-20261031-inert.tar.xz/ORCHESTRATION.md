# I31 source-only verification and measurement preparation

These scripts have not frozen source, built or run native products, read candidate
identities/images, bound products, probed a cache filesystem, or run Node. The
only executed checks are Python AST parsing and pure source/path/cache-policy
checks. Root owns review and the later semantic/resource gate.

Baseline is accepted main `6cec43bcd2dabfc26fcb42736925d4041e3fe9b5` with production
bytes identical to a9. Reuse the actual Date/a35 products at
`target/performance-date-demand-20261031/candidate`, retaining their original
`7c47e38274c9645b6701552c87d38362b2bfbcd5` plus frozen patch provenance and ABI42.
The future I31 candidate uses ABI45 and an exact future fingerprint, supplied
explicitly during binding. Rejected APP/ABI43 and LAZY/ABI44 are not baselines or
passing coverage for this experiment.

`freeze-inputs.py` is an unexecuted one-shot source freeze. It captures every
tracked working change and every untracked new Rust module, including complete
Git no-index patches without staging. It requires the reviewed ABI45 source and
accepted6cec parent. It copies baseline identity metadata without retagging and
proves all54 non-Markdown Date-published inputs match accepted HEAD Git blobs.
Seven historical Markdown identities and their accepted parent hashes are
recorded separately, with the three later documentation differences explicit.
The compiled input manifest and source map do not exist yet.

`native-plan.json` selects ten actual scopes in nine invocations. The first
invocation passes both AOT and Engine library target names to the existing
workspace runner, using the ordinary two-package union and one normal `--lib`
build. Full AOT library and Engine `wasm_rooted_snapshot::` inventories are kept
as separate cases in that shared receipt. Subsequent integrations are serial:
full runtime_link; two emission filters; two GC filters; two language filters;
and the Array private-buffer filter. No candidate test total is predicted.

`run-native.py` understands the multi-case library receipt, validates frozen
source continuity, and retains a passing integration image for the second
filter of its same Cargo selector. Both filtered receipts and exact image
SHA/size/path continuity are preserved before final retirement. Selected
non-passing images are frozen outside mutable Cargo output; selected built but
unstarted siblings are retained without a fabricated verdict. Only exact
passing or explicitly unselected Cargo aliases may retire. `--start-batch` and a
new `--label-suffix=-resume` preserve earlier completed scopes and receipts after
a deferral. Root must review the actual reason/source identity before reuse or
continuation; a test correction never silently adopts a new source identity.

After root finishes all source/tests/docs, cheap checks and source freeze, the
existing limited wrapper remains mandatory. The following commands are future
examples, not a record of execution:

    export SCRIPTW_CACHE_DIR=/tmp/scriptw-i31-presence-verification-cache-20261031
    export SCRIPTW_TEST_CODEGEN_JOBS=auto
    python3 -B scripts/limited_verification.py --cloud --cloud-cpus auto -- python3 -B target/performance-i31-presence-20261031/run-native.py
    python3 -B scripts/limited_verification.py --cloud --cloud-cpus auto -- python3 -B target/performance-i31-presence-20261031/build-candidate.py

`build-candidate.py` freezes independently owned static CLI and two benchmark
hosts after asserting the frozen source map is unchanged. The optional
`retire-cargo-product-duplicates.py` verifies those independently owned copies
before retiring only mutable Cargo aliases. Neither has run in this preparation.

The selected original Test262 manifest is the already source-read complete
24-file push family only. It is not the former36-file selection. The future
runner validates source hashes and records actual native runner variants; it
stops on any nonzero exit or incomplete pass count. There is no full Array or
Test262 status/publication claim.

`measurement/cohort.py` keeps exactly21 sources: canonical17, startup, and the
same three deterministic Date controls, including513 repeated public Date reads.
Sources, manifest, hashes and golden derivation are copied byte-for-byte from
LAZY. Its21 critical validator bodies are unchanged. Preparation still keeps
both17-entry retained groups and their13 preparation-only fillers intact.

Before any future bind/Node/preparation/measurement, root must create this exact
canonical nonsymlink normal overlay directory and set:

    export SCRIPTW_CACHE_DIR=/workspace/scriptw/target/performance-i31-presence-20261031/normal-cache

The source code requires `overlayfs:794c7630`, records path/filesystem and every
child's cache environment before/after, and refuses tmpfs/ramfs or another root.
No scored cache is created or relocated automatically. The unscored verification
cache above is a distinct scope. `validate-and-prepare.py` binds an exact future
candidate fingerprint, checks fresh Node21 goldens, replays the24 original files,
and prepares each side's own55 images. Native images from archives are never
copied or loaded.

Root may later run the unchanged full balanced cohort: all21 sources, original,
ordinary and retained boundaries, ABBA+BAAB eight rounds,21 observations and10
checked warmups per child,504 planned child processes. Preserve raw observations,
all groups, medians, means, RSS and every slower/outlier sample. No timing,
allocation/RSS saving, same-executable parity or published chart claim follows
from this source preparation. Any optional single bounded follow-up needs its
own predeclaration after the complete cohort; none is prepared or assumed here.
