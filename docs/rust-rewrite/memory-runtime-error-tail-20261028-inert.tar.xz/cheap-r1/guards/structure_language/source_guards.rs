#[path = "/home/mewhhaha/src/porffor/target/memory-calendar-rows-20261028/crates/scriptw-aot-wasm/tests/structure_language/accessor_descriptor_local_roles_structure.rs"]
mod accessor_descriptor_local_roles_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-calendar-rows-20261028/crates/scriptw-aot-wasm/tests/structure_language/append_target_scope_structure.rs"]
mod append_target_scope_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-calendar-rows-20261028/crates/scriptw-aot-wasm/tests/structure_language/arguments_binding_protocol_ownership_structure.rs"]
mod arguments_binding_protocol_ownership_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-calendar-rows-20261028/crates/scriptw-aot-wasm/tests/structure_language/arguments_callee_descriptor_structure.rs"]
mod arguments_callee_descriptor_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-calendar-rows-20261028/crates/scriptw-aot-wasm/tests/structure_language/arguments_index_descriptor_structure.rs"]
mod arguments_index_descriptor_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-calendar-rows-20261028/crates/scriptw-aot-wasm/tests/structure_language/completion_exit_structure.rs"]
mod completion_exit_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-calendar-rows-20261028/crates/scriptw-aot-wasm/tests/structure_language/completion_kind_registry_domain_structure.rs"]
mod completion_kind_registry_domain_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-calendar-rows-20261028/crates/scriptw-aot-wasm/tests/structure_language/conversion_abrupt_route_capability_structure.rs"]
mod conversion_abrupt_route_capability_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-calendar-rows-20261028/crates/scriptw-aot-wasm/tests/structure_language/descriptor_known_present_compatibility_structure.rs"]
mod descriptor_known_present_compatibility_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-calendar-rows-20261028/crates/scriptw-aot-wasm/tests/structure_language/destructuring_iterator_locals_ownership_structure.rs"]
mod destructuring_iterator_locals_ownership_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-calendar-rows-20261028/crates/scriptw-aot-wasm/tests/structure_language/destructuring_iterator_step_kind_structure.rs"]
mod destructuring_iterator_step_kind_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-calendar-rows-20261028/crates/scriptw-aot-wasm/tests/structure_language/may_throw_abrupt_route_ownership_structure.rs"]
mod may_throw_abrupt_route_ownership_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-calendar-rows-20261028/crates/scriptw-aot-wasm/tests/structure_language/numeric_update_value_kind_structure.rs"]
mod numeric_update_value_kind_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-calendar-rows-20261028/crates/scriptw-aot-wasm/tests/structure_language/object_environment_logical_assignment_structure.rs"]
mod object_environment_logical_assignment_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-calendar-rows-20261028/crates/scriptw-aot-wasm/tests/structure_language/object_literal_home_object_structure.rs"]
mod object_literal_home_object_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-calendar-rows-20261028/crates/scriptw-aot-wasm/tests/structure_language/object_method_arrow_super_structure.rs"]
mod object_method_arrow_super_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-calendar-rows-20261028/crates/scriptw-aot-wasm/tests/structure_language/obsolete_builtin_emitter_absence_structure.rs"]
mod obsolete_builtin_emitter_absence_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-calendar-rows-20261028/crates/scriptw-aot-wasm/tests/structure_language/obsolete_core_backend_api_absence_structure.rs"]
mod obsolete_core_backend_api_absence_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-calendar-rows-20261028/crates/scriptw-aot-wasm/tests/structure_language/obsolete_planning_analysis_absence_structure.rs"]
mod obsolete_planning_analysis_absence_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-calendar-rows-20261028/crates/scriptw-aot-wasm/tests/structure_language/obsolete_static_generator_backend_absence_structure.rs"]
mod obsolete_static_generator_backend_absence_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-calendar-rows-20261028/crates/scriptw-aot-wasm/tests/structure_language/ordinary_property_eager_compound_assignment_structure.rs"]
mod ordinary_property_eager_compound_assignment_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-calendar-rows-20261028/crates/scriptw-aot-wasm/tests/structure_language/ordinary_property_logical_assignment_structure.rs"]
mod ordinary_property_logical_assignment_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-calendar-rows-20261028/crates/scriptw-aot-wasm/tests/structure_language/ordinary_property_numeric_update_structure.rs"]
mod ordinary_property_numeric_update_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-calendar-rows-20261028/crates/scriptw-aot-wasm/tests/structure_language/ordinary_property_plain_assignment_structure.rs"]
mod ordinary_property_plain_assignment_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-calendar-rows-20261028/crates/scriptw-aot-wasm/tests/structure_language/ordinary_set_receiver_fallback_structure.rs"]
mod ordinary_set_receiver_fallback_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-calendar-rows-20261028/crates/scriptw-aot-wasm/tests/structure_language/prepared_destructuring_property_key_ownership_structure.rs"]
mod prepared_destructuring_property_key_ownership_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-calendar-rows-20261028/crates/scriptw-aot-wasm/tests/structure_language/prepared_destructuring_target_structure.rs"]
mod prepared_destructuring_target_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-calendar-rows-20261028/crates/scriptw-aot-wasm/tests/structure_language/private_element_entry_protocol_structure.rs"]
mod private_element_entry_protocol_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-calendar-rows-20261028/crates/scriptw-aot-wasm/tests/structure_language/shadowed_property_read_arm_absence_structure.rs"]
mod shadowed_property_read_arm_absence_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-calendar-rows-20261028/crates/scriptw-aot-wasm/tests/structure_language/shape_accessor_reference_selection_structure.rs"]
mod shape_accessor_reference_selection_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-calendar-rows-20261028/crates/scriptw-aot-wasm/tests/structure_language/spec_operation_object_target_kind_structure.rs"]
mod spec_operation_object_target_kind_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-calendar-rows-20261028/crates/scriptw-aot-wasm/tests/structure_language/stored_descriptor_role_relation_structure.rs"]
mod stored_descriptor_role_relation_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-calendar-rows-20261028/crates/scriptw-aot-wasm/tests/structure_language/stored_property_attributes_structure.rs"]
mod stored_property_attributes_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-calendar-rows-20261028/crates/scriptw-aot-wasm/tests/structure_language/strict_equality_static_kind_structure.rs"]
mod strict_equality_static_kind_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-calendar-rows-20261028/crates/scriptw-aot-wasm/tests/structure_language/super_property_reference_mutation_structure.rs"]
mod super_property_reference_mutation_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-calendar-rows-20261028/crates/scriptw-aot-wasm/tests/structure_language/try_clause_empty_completion_seed_structure.rs"]
mod try_clause_empty_completion_seed_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-calendar-rows-20261028/crates/scriptw-aot-wasm/tests/structure_language/typeof_static_kind_structure.rs"]
mod typeof_static_kind_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-calendar-rows-20261028/crates/scriptw-aot-wasm/tests/structure_language/unary_numeric_ir_structure.rs"]
mod unary_numeric_ir_structure;
#[path = "/home/mewhhaha/src/porffor/target/memory-calendar-rows-20261028/crates/scriptw-aot-wasm/tests/structure_language/with_environment_identifier_call_structure.rs"]
mod with_environment_identifier_call_structure;
