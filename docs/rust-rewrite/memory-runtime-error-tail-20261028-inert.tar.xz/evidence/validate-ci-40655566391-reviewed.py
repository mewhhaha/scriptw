"""UNLAUNCHABLE runtime-error-tail CI validator template.

Preparation only: replace the RUN assignment below with the assigned positive
GitHub run integer in a reviewed final copy. All artifact, metadata and output
paths then derive from RUN. This template refuses execution/import before any
project module import or output mutation. No future source or measurement pass
is claimed by its preparation. Execution later requires the reviewed 1 GiB,
CPU0, no-swap limited-verification wrapper.

Adapted from the validated inline-storage validator, SHA256 f6a6ffcc75dc79e0348a4c680cff38784f12483385c5ce827cafcda4ef1c9176.
"""
import ast
from datetime import datetime,timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import sys
from types import SimpleNamespace

BASE=Path(__file__).resolve().parent
ROOT=BASE.parents[1]
WORKTREE=ROOT
SCRIPTS=WORKTREE/'scripts'
SOURCE='68dae6ed898a5d31aed30f713df2c7b5add4c1e0'
FEATURE='6bc9d5d5c3ada9040468de07026deb23fb22f7e3'
VERIFIED='0658e6ae61981becc6dd338bcf1b1abd4b39feb3'
FINGERPRINT='b3d43fc17aca01dfc089129b33b4060cdbd7b096649a95a75119eadc24832889'
LOCAL_FP='db68aff1076fa41bc9fc22304c3a55c0205e5f059063169c1add92841dbcb956'
RUN = 40655566391
if type(RUN) is not int or RUN <= 0:
    raise SystemExit('UNLAUNCHABLE TEMPLATE: assign the reviewed GitHub run integer before use')
SCORED=BASE/f'github-{RUN}-scored/precompiled-evidence/report.json'
DIAGNOSTIC=BASE/f'github-{RUN}-diagnostic'
OUT=BASE/f'ci-{RUN}-validated'
PATTERN=ROOT/'target/memory-module-ownership-20261027-evidence/validate-ci-40594118953.py'
PATTERN_SHA='1455de1eb46d3190cafc4bf33150baa236e648287e1b31df404b55293e88a70b'
sys.path.insert(0,str(ROOT/'scripts'))
import precompiled_comparison as p
from limited_verification import require_kernel_budget,kernel_group
from native_test_protocol import result_summaries
sys.path.insert(0,str(SCRIPTS))
import benchmark_module_images as m
import benchmark_module_sections as sections
spec=importlib.util.spec_from_file_location('section_owned_endpoint_contract',SCRIPTS/'diagnose-precompiled-mappings.py')
d=importlib.util.module_from_spec(spec);spec.loader.exec_module(d)
PHASES=list(d.PHASES)
EXPECTED_CASES=[(runtime,name) for name in ('integer.js','retained-objects.js') for runtime in ('scriptw','scriptc')]
INPUTS={}
args=SimpleNamespace(scored_report=SCORED)


def file_sha(path):
    with Path(path).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()


assert file_sha(PATTERN)==PATTERN_SHA
tree=ast.parse(PATTERN.read_text(),filename=str(PATTERN))
exec(compile(ast.Module(body=[node for node in tree.body if isinstance(node,ast.FunctionDef)],type_ignores=[]),str(PATTERN)+':inert-definitions','exec'),globals())


def metadata(path,cap=64*1024**2):
    path=Path(path);info=path.lstat()
    assert stat.S_ISREG(info.st_mode) and not path.is_symlink() and path.resolve()==path and info.st_size<=cap
    with path.open('rb') as stream:magic=stream.read(8)
    assert not magic.startswith((b'\x7fELF',b'MZ',b'SWRTZ001',b'SCRWRB',b'SCRWEP',b'SCRWWA',b'SCRWNR'))
    INPUTS[str(path)]=dict(bytes=info.st_size,sha256=file_sha(path))
    return INPUTS[str(path)]


def json_input(path,cap=16*1024**2):
    metadata(path,cap);return p._json(Path(path).read_bytes())


def counters(group):
    return {key:(group/key).read_text().strip() for key in ('memory.max','memory.swap.max','memory.oom.group','memory.peak','memory.events')}


def no_oom(before,after,maximum):
    for row in (before,after):
        assert 0<int(row['memory.max'])<=maximum and row['memory.swap.max']=='0' and row['memory.oom.group']=='1'
    events=[dict(line.split() for line in row['memory.events'].splitlines()) for row in (before,after)]
    assert all(events[0][key]==events[1][key]=='0' for key in ('oom','oom_kill','oom_group_kill'))


def root_state():
    assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=ROOT)
    return subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()


def native_controls():
    directory=BASE/f'github-{RUN}-scored'
    out=directory/'module-sections-native.stdout';err=directory/'module-sections-native.stderr'
    metadata(out,32*1024**2);metadata(err,32*1024**2)
    expected={
        'embedding::benchmark_module_images::sections::tests::malformed_headers_extended_counts_and_table_extents_are_rejected',
        'embedding::benchmark_module_images::sections::tests::name_budget_is_aggregate_even_for_omitted_logical_sections',
        'embedding::benchmark_module_images::sections::tests::names_require_unique_bounded_terminated_utf8_and_in_table_offsets',
        'embedding::benchmark_module_images::sections::tests::relocatable_no_program_headers_yields_only_exact_file_backed_metadata',
        'embedding::benchmark_module_images::sections::tests::section_arithmetic_overlap_nobits_and_text_anchors_fail_closed',
        'embedding::tests::benchmark_module_images::diagnostic_images_match_actual_program_runtime_and_survive_store_drop'}
    text=out.read_text();names=re.findall(r'^test ([^\r\n]+) \.\.\. ok$',text,re.M)
    assert len(names)==len(set(names))==6 and set(names)==expected
    summary=result_summaries(text)
    assert len(summary)==1 and summary[0][:5]==('ok','6','0','0','0')
    return dict(status='validated',passed=6,test_ids=names,summary=summary,
        stdout_sha256=INPUTS[str(out)]['sha256'],stderr_sha256=INPUTS[str(err)]['sha256'])


def section_summary(diagnostic,campaign):
    summaries=[]
    for case in diagnostic.get('cases',[]):
        if case['runtime']!='scriptw':continue
        if case['status'] not in ('validated','module-ownership-validated'):continue
        runtime=next(owner for owner in case['module_attribution']['owners'] if owner['role']=='runtime')
        assert runtime['relation']=='text-inside-image'
        meta=runtime['section_metadata']
        assert meta['schema']=='scriptw-module-sections-v1' and meta['serialized_bytes']==runtime['image']['end']-runtime['image']['start']
        phases=[]
        for phase in runtime['phases']:
            value=phase['sections']
            assert value['image_present_pages']==phase['image_present_pages']
            assert value['nontext_image_present_pages']==phase['image_present_pages']-phase['text_present_pages']
            phases.append(dict(phase=phase['phase'],page_bytes=phase['page_bytes'],image_present_pages=phase['image_present_pages'],
                text_present_pages=phase['text_present_pages'],nontext_image_present_pages=value['nontext_image_present_pages'],
                section_union_present_pages=value['section_union_present_pages'],mixed_section_present_pages=value['mixed_section_present_pages'],
                section_boundary_present_pages=value['section_boundary_present_pages'],uncovered_present_image_pages=value['uncovered_present_image_pages'],
                elf_header_present_page_overlaps=value['elf_header_present_page_overlaps'],section_headers_present_page_overlaps=value['section_headers_present_page_overlaps'],
                nontext_sections=[row for row in value['sections'] if row['name']!='.text']))
        warm=phases[-1]
        ranked=sorted(warm['nontext_sections'],key=lambda row:(row['full_present_pages'],row['present_page_overlaps']),reverse=True)
        summaries.append(dict(file=case['file'],serialized_bytes=meta['serialized_bytes'],serialized_sha256=meta['serialized_sha256'],
            phases=phases,largest_warm_nontext_section_by_whole_present_pages=ranked[0],
            interpretation='after_store_drop is the retained warm endpoint at observation16, after16 earlier calls. Section overlaps share boundary pages; never sum overlap counts or prorate RSS.'))
    return summaries


def main():
    if not __debug__:raise SystemExit('admission requires Python assertions enabled')
    require_kernel_budget(1024**3)
    assert sorted(os.sched_getaffinity(0))==[0] and not OUT.exists()
    root_before=root_state();group=kernel_group();OUT.mkdir()
    report=dict(schema='scriptw-runtime-error-tail-ci-validation-v1',complete=False,source_commit=SOURCE,feature_source_commit=FEATURE,
        source_fingerprint=FINGERPRINT,run=RUN,processing_checkout_commit=root_before,started_at=datetime.now(timezone.utc).isoformat(),
        cpu_affinity=[0],before=counters(group),driver_sha256=file_sha(Path(__file__)),reused_validator_sha256=PATTERN_SHA)
    try:
        for module,name in [(m,'benchmark_module_images.py'),(sections,'benchmark_module_sections.py'),(d,'diagnose-precompiled-mappings.py')]:
            path=SCRIPTS/name
            assert Path(module.__file__).resolve()==path
            raw=path.read_bytes()
            assert raw==subprocess.check_output(['git','show','1fd6940fb3db57b999dc535595f5a185870cae69:scripts/'+name],cwd=ROOT)
            assert raw==subprocess.check_output(['git','show',FEATURE+':scripts/'+name],cwd=ROOT)
            assert raw==subprocess.check_output(['git','show',SOURCE+':scripts/'+name],cwd=ROOT)
            metadata(path)
            report.setdefault('validator_sources',{})[name]=dict(source_commit=FEATURE,sha256=file_sha(path))
        assert Path(m.module_sections.__file__).resolve()==SCRIPTS/'benchmark_module_sections.py'
        assert d.module_images is m
        assert (ROOT/'scripts/precompiled_comparison.py').read_bytes()==subprocess.check_output(['git','show',FEATURE+':scripts/precompiled_comparison.py'],cwd=ROOT)
        metadata(ROOT/'scripts/precompiled_comparison.py')
        binding_path=BASE/'source-bindings-final-local-probe.json'
        binding=json_input(binding_path)
        assert INPUTS[str(binding_path)]['sha256']=='90001950e410def818f805d08c69ee2b1e1307ebcec0af4163a7be04ab863149'
        assert binding['original_feature']==FEATURE and binding['verified_source']==VERIFIED and binding['probe']==SOURCE
        assert binding['prior_report_sha256']==metadata(BASE/'source-bindings-feature-probe.json')['sha256']=='d33b2a5a023902ee01533b5380f20ad98534cce5bc62de76b1dc6c2c8499a989'
        assert binding['computed_compiler_inputs_equal'] is True and len(binding['rows'])==6
        assert binding['cpu_affinity']==[0]
        no_oom(binding['before'],binding['after'],256*1024**2)
        assert subprocess.check_output(['git','diff','--name-only',FEATURE,SOURCE],cwd=ROOT,text=True).splitlines()==['.github/workflows/precompiled-benchmarks.yaml']
        assert subprocess.check_output(['git','diff','--name-only',FEATURE,VERIFIED],cwd=ROOT,text=True).splitlines()==[
            'crates/scriptw-engine/tests/aot_language/aot_runtime_error_for_throw.rs']
        report['source_bindings']=dict(feature=FEATURE,measured_probe=SOURCE,test_only_verified_final=VERIFIED,
            compiler_inputs_equal=True,clean_fingerprint=FINGERPRINT,ignored_regress_lock_fingerprint=LOCAL_FP,
            interpretation='The six-row source proof binds equal compiler inputs for feature, verified final and measured probe under both lockfile states. The verified final differs from the feature only in the pinned language-test file; its native verification is a separate receipt and is not inferred from this CI run.')
        for revision in (SOURCE,FEATURE,VERIFIED):
            for ignored,fp in [(False,FINGERPRINT),(True,LOCAL_FP)]:
                rows=[row for row in binding['rows'] if row['revision']==revision and row['extra_ignored_regress_lock'] is ignored]
                assert len(rows)==1 and rows[0]['source_fingerprint']==fp
                assert (rows[0]['files'],rows[0]['bytes'])==((2926,161602862) if ignored else (2925,161601631))
        run=json_input(BASE/f'github-run-{RUN}-completed.json')
        assert run['databaseId']==RUN and run['headSha']==SOURCE and run['status']=='completed' and run['conclusion']=='success'
        assert len(run['jobs'])==1 and run['jobs'][0]['name']=='measure' and run['jobs'][0]['conclusion']=='success'
        for name in ('Verify and build the shared host','Measure both compiler-free consumers','Observe unscored consumer mappings','Retain all raw observations and failures'):
            steps=[step for job in run['jobs'] for step in job['steps'] if step['name']==name]
            assert len(steps)==1 and steps[0]['conclusion']=='success'
        metadata(SCORED,p.MAX_REPORT)
        campaign,table=p.load_report(SCORED)
        assert campaign['source_commit']==SOURCE and campaign['source_fingerprint']==FINGERPRINT
        assert campaign['tools']['consumer']['cargo_producer']['features']==['benchmark-module-images']
        assert campaign['tools']['rustc']['version'].startswith('rustc 1.99.1 ')
        assert len(campaign['attempts'])==68 and len(table)==17 and all(row['status']=='ok' for row in campaign['attempts'])
        for row in campaign['retained_files']:
            value=metadata(SCORED.parent/p.safe_name(row['path']))
            assert value['bytes']==row['bytes'] and value['sha256']==row['sha256']
        report.update(scored_admitted=True,scored_attempts=68,scored_workloads=17,scored_all_attempts_ok=True,scored_table=table,
            native_controls=native_controls(),cli_example_controls=dict(status='raw-job-log-unavailable',exact_pass_count=None,
                ci_build_step_success=True,reason='Downloaded scored/native artifacts retain the six engine controls; no raw CLI example-test job log is present. No CLI example count is inferred.'))
        report['diagnostic']=diagnostic(DIAGNOSTIC,campaign,run)
        report['runtime_sections']=section_summary(report['diagnostic'],campaign)
        if report['diagnostic']['status']=='validated':
            assert len(report['diagnostic']['cases'])==4 and len(report['runtime_sections'])==2
        report['diagnostic_complete']=report['diagnostic']['status']=='validated'
        # A missing optional capture is not a failed scored attempt. Retain
        # scored_admitted and the exact diagnostic status in the failed receipt
        # while withholding this whole-batch diagnostic completion gate.
        assert report['diagnostic_complete'], 'required four-case v2 ownership gate incomplete; scored admission remains separate'
        assert {(case['runtime'],case['file']) for case in report['diagnostic']['cases']}==set(EXPECTED_CASES)
        keys={attempt['image']['runtime_key'] for attempt in campaign['attempts'] if attempt['runtime']=='scriptw'}
        assert len(keys)==1 and None not in keys
        layout_source=subprocess.check_output(['git','show',SOURCE+':crates/scriptw-aot-wasm/src/runtime_artifact.rs'],cwd=ROOT)
        assert re.findall(r'const LAYOUT_VERSION: u32 = (\d+);',layout_source.decode())==['32']
        (OUT/'runtime-artifact-layout-source.rs').write_bytes(layout_source)
        report['runtime_identity']=dict(layout=32,runtime_keys=sorted(keys),
            layout_origin='Exact producer Git source constant, bound through actual measured CLI source/fingerprint. No raw R package is retained by this CI artifact.',
            layout_source_sha256=hashlib.sha256(layout_source).hexdigest(),
            prior_runtime_key_equality_asserted=False,native_crossrunner_equality_asserted=False,
            interpretation='R changed in this batch. Record its new key independently; no prior-run runtime identity or causal memory-saving assumption.')
        for case in report['diagnostic'].get('cases',[]):case.pop('host_function_overlap',None)
        report['next_measurement_targets']=[dict(file=item['file'],section=item['largest_warm_nontext_section_by_whole_present_pages'],
            evidence='Largest nontext section by full present pages in this retained warm R observation.',
            constraint='Inspect required runtime data or GC metadata origins before a matched intervention. Presence does not identify live JS objects or authorize omitting globals/data/GC stack maps.') for item in report['runtime_sections']]
        assert root_state()==root_before
        after=counters(group);no_oom(report['before'],after,1024**3)
        report.update(complete=True,after=after,finished_at=datetime.now(timezone.utc).isoformat(),
            interpretation='Section evidence is unscored and separate from prior scored cohorts. Warm captures follow16 prior calls. Image/text/section boundaries and host function pages are nonadditive; presence is not execution or causal savings. No parity or goal-completion claim. The validator reads retained fixture text/metadata, reads no native image and executes no workload.')
    except BaseException as error:
        report.update(error=repr(error),error_type=type(error).__name__,after=counters(group),finished_at=datetime.now(timezone.utc).isoformat())
        raise
    finally:
        report['inputs']=INPUTS
        (OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n')
    lines=[f'CI{RUN}: 68/68 scored attempts,17 workload checksums and six actual engine controls validated. Required four-case v2 ownership status: '+report['diagnostic']['status']+'.',
        'Exact v2 parsers are bound to the unchanged section-parser source and this error-tail producer. Layout32 and the current R key are recorded independently; no prior-key or cross-runner native equality is asserted.',
        'CLI example-test raw job output is unavailable; no exact CLI example pass count is claimed.','',
        '| Case | R image pages | Text pages | Nontext image pages | Mixed | Boundary | Uncovered | Header overlap | Section-table overlap |',
        '|---|---:|---:|---:|---:|---:|---:|---:|---:|']
    for case in report['runtime_sections']:
        warm=case['phases'][-1]
        lines.append('| '+case['file']+' | '+' | '.join(str(warm[key]) for key in ('image_present_pages','text_present_pages','nontext_image_present_pages','mixed_section_present_pages','section_boundary_present_pages','uncovered_present_image_pages','elf_header_present_page_overlaps','section_headers_present_page_overlaps'))+' |')
    lines+=['','Retained warm after_store_drop at observation16; overlapping counts below must not be summed.','',
        '| Case | Nontext R section | Section bytes | Present-page overlaps | Full present pages |','|---|---|---:|---:|---:|']
    for case in report['runtime_sections']:
        for row in case['phases'][-1]['nontext_sections']:
            lines.append('| '+case['file']+' | '+row['name']+' | '+str(row['bytes'])+' | '+str(row['present_page_overlaps'])+' | '+str(row['full_present_pages'])+' |')
    lines+=['','Nontext leaders are derived per current case in next_measurement_targets; no section leader or reduction is assumed from a prior run. Inspect required data/GC metadata origins before a matched intervention; presence establishes no saving or live heap ownership and does not authorize dropping stack maps. Warm history contains16 earlier calls; no last-sample causal/bootstrap claim follows. Native payloads were not retained/executed.']
    (OUT/'summary.md').write_text('\n'.join(lines)+'\n')
    print(json.dumps(dict(complete=True,scored_attempts=68,workloads=17,native_controls=6,diagnostic=report['diagnostic']['status'],output=str(OUT))))


if __name__=='__main__':main()
