CI40655566391: 68/68 scored attempts,17 workload checksums and six actual engine controls validated. Required four-case v2 ownership status: validated.
Exact v2 parsers are bound to the unchanged section-parser source and this error-tail producer. Layout32 and the current R key are recorded independently; no prior-key or cross-runner native equality is asserted.
CLI example-test raw job output is unavailable; no exact CLI example pass count is claimed.

| Case | R image pages | Text pages | Nontext image pages | Mixed | Boundary | Uncovered | Header overlap | Section-table overlap |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| integer.js | 671 | 477 | 194 | 7 | 7 | 0 | 1 | 1 |
| retained-objects.js | 879 | 573 | 306 | 8 | 8 | 0 | 1 | 1 |

Retained warm after_store_drop at observation16; overlapping counts below must not be summed.

| Case | Nontext R section | Section bytes | Present-page overlaps | Full present pages |
|---|---|---:|---:|---:|
| integer.js | .wasmtime.engine | 1102 | 1 | 0 |
| integer.js | .wasmtime.bti | 1 | 1 | 0 |
| integer.js | .eh_frame | 107588 | 27 | 26 |
| integer.js | .wasmtime.addrmap | 6954061 | 8 | 7 |
| integer.js | .wasmtime.stackmap | 3719280 | 0 | 0 |
| integer.js | .wasmtime.traps | 2093690 | 6 | 5 |
| integer.js | .wasmtime.exceptions | 25592 | 7 | 5 |
| integer.js | .rodata.wasm | 2039616 | 101 | 100 |
| integer.js | .name.wasm | 38384 | 7 | 6 |
| integer.js | .wasmtime.info | 62404 | 17 | 15 |
| integer.js | .symtab | 54216 | 10 | 9 |
| integer.js | .strtab | 111870 | 15 | 14 |
| integer.js | .shstrtab | 187 | 1 | 0 |
| retained-objects.js | .wasmtime.engine | 1102 | 1 | 0 |
| retained-objects.js | .wasmtime.bti | 1 | 1 | 0 |
| retained-objects.js | .eh_frame | 107588 | 27 | 26 |
| retained-objects.js | .wasmtime.addrmap | 6954061 | 19 | 17 |
| retained-objects.js | .wasmtime.stackmap | 3719280 | 102 | 101 |
| retained-objects.js | .wasmtime.traps | 2093690 | 6 | 5 |
| retained-objects.js | .wasmtime.exceptions | 25592 | 7 | 5 |
| retained-objects.js | .rodata.wasm | 2039616 | 101 | 100 |
| retained-objects.js | .name.wasm | 38384 | 7 | 6 |
| retained-objects.js | .wasmtime.info | 62404 | 17 | 15 |
| retained-objects.js | .symtab | 54216 | 10 | 9 |
| retained-objects.js | .strtab | 111870 | 15 | 14 |
| retained-objects.js | .shstrtab | 187 | 1 | 0 |

Nontext leaders are derived per current case in next_measurement_targets; no section leader or reduction is assumed from a prior run. Inspect required data/GC metadata origins before a matched intervention; presence establishes no saving or live heap ownership and does not authorize dropping stack maps. Warm history contains16 earlier calls; no last-sample causal/bootstrap claim follows. Native payloads were not retained/executed.
