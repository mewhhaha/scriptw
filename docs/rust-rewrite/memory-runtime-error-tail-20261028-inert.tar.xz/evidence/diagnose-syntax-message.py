import hashlib,importlib.util,json,os,subprocess,sys
from pathlib import Path
base=Path(__file__).resolve().parent;repo=base.parents[1];root=repo/'target/memory-calendar-rows-20261028'
sys.path.insert(0,str(repo/'scripts'))
from limited_verification import require_kernel_budget,kernel_group
require_kernel_budget(4*1024**3);assert sorted(os.sched_getaffinity(0))==[0]
spec=importlib.util.spec_from_file_location('driver',base/'native-runtime-error-tail-r0.py');driver=importlib.util.module_from_spec(spec);spec.loader.exec_module(driver)
out=base/'syntax-message-diagnostic';out.mkdir()
def budget():return {k:(kernel_group()/k).read_text().strip() for k in ('memory.max','memory.swap.max','memory.oom.group','memory.peak','memory.events')}
row=dict(label='diagnostic-language',cwd=str(root),command=['cargo','test','--locked','--offline','--release','--jobs','1','--target-dir',str(repo/'target/performance-work-20261024/build'),'-p','scriptw-engine','--test','aot_language','--no-default-features','aot_runtime_error_for_throw::','--','--test-threads=1','--color=never'],stdout='cargo.stdout',stderr='cargo.stderr')
f=root/'crates/scriptw-engine/tests/aot_language/aot_runtime_error_for_throw.rs'
r=dict(purpose='capture exact SyntaxError text; not full native verification',source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),test_file_sha256=driver.sha(f),source_diff=subprocess.check_output(['git','diff'],cwd=root,text=True),before=budget(),commands=[row])
try:driver.run_command(row,out,timeout=1800,stdout_limit=2*1024**2,stderr_limit=2*1024**2)
finally:
 r['after']=budget();(out/'report.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(dict(exit_code=row.get('exit_code'),output=str(out))),flush=True)
