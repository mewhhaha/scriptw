import hashlib,json,os,subprocess,sys
from pathlib import Path
base=Path(__file__).resolve().parent;repo=base.parents[1]
ns={'__file__':str(base/'source-bindings.py')}
exec((base/'source-bindings.py').read_text().split('\nimport os,sys\n',1)[0],ns)
sys.path.insert(0,str(repo/'scripts'))
from limited_verification import require_kernel_budget,kernel_group
require_kernel_budget(256*1024**2);assert sorted(os.sched_getaffinity(0))==[0]
def budget():return {k:(kernel_group()/k).read_text().strip() for k in ('memory.max','memory.swap.max','memory.oom.group','memory.peak','memory.events')}
before=budget();original='6bc9d5d5c3ada9040468de07026deb23fb22f7e3';final='0658e6ae61981becc6dd338bcf1b1abd4b39feb3';probe='68dae6ed898a5d31aed30f713df2c7b5add4c1e0'
assert ns['one'](['git','diff','--name-only',original,final]).decode().splitlines()==['crates/scriptw-engine/tests/aot_language/aot_runtime_error_for_throw.rs']
prior=base/'source-bindings-feature-probe.json';previous=json.loads(prior.read_text());assert previous['feature']==original and previous['probe']==probe and previous['computed_compiler_inputs_equal']
rows=previous['rows']+[ns['fingerprint'](final,extra) for extra in (False,True)]
for extra in (False,True):assert len({(r['source_fingerprint'],r['files'],r['bytes']) for r in rows if r['extra_ignored_regress_lock']==extra})==1
after=budget();events=[dict(line.split() for line in b['memory.events'].splitlines()) for b in (before,after)];assert all(events[0][k]==events[1][k]=='0' for k in ('oom','oom_kill','oom_group_kill'))
r=dict(original_feature=original,verified_source=final,probe=probe,computed_compiler_inputs_equal=True,actual_cli_identity_confirmation_pending=True,prior_report_sha256=hashlib.sha256(prior.read_bytes()).hexdigest(),rows=rows,cpu_affinity=[0],before=before,after=after)
out=base/'source-bindings-final-local-probe.json';assert not out.exists();out.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
