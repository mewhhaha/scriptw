"""Prepare an inert candidate only; never build, execute workloads, or publish.

Run under the reviewed 1 GiB/no-swap/CPU0 limited-verification wrapper after
both final receipt hashes have been inspected. Output is exclusive-create.
The failed fixture run and diagnostic are retained with zero final credit.
All final 4917 native IDs must run freshly; the predecessor 4912 inventory is
only a disappearance/addition control, never inherited execution evidence.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import lzma
import os
from pathlib import Path
import re
import stat
import subprocess
import sys
import tarfile

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
SOURCE = '0658e6ae61981becc6dd338bcf1b1abd4b39feb3'
FEATURE = '6bc9d5d5c3ada9040468de07026deb23fb22f7e3'
MEASURED = '68dae6ed898a5d31aed30f713df2c7b5add4c1e0'
FP = 'b3d43fc17aca01dfc089129b33b4060cdbd7b096649a95a75119eadc24832889'
LOCAL_FP = 'db68aff1076fa41bc9fc22304c3a55c0205e5f059063169c1add92841dbcb956'
PROOF = BASE / 'source-bindings-final-local-probe.json'
PROOF_SHA = '90001950e410def818f805d08c69ee2b1e1307ebcec0af4163a7be04ab863149'
FAILED_SHA = '57b4f893a66f039ae4fe1e08c0fe308ee239a2387046406d03acbe575ddcef9a'
CHEAP_SHA = '68d3fc26abbc110743c7a1d6f8e21dc38168afe9a8c408a87c2a8474e48dd03e'
DRIVER_SHA = '194b6921c0312d51d69e0f78e1d616d9039e9b699c8c35643d039ea1953b6a43'
DIAGNOSTIC_SHA = 'f57d69ce0468872bc666d23769660a33f61905564d59c803a170a8d25f92d626'
DIAGNOSTIC_DRIVER_SHA = '8a6c52f4931523a9b107325ce75c7a3b8667e6695848c54db456c775f7344340'
BASELINE = ROOT / 'target/memory-ordered-bootstrap-20261027-evidence/native-main-a036f1144/report.json'
BASELINE_SHA = '747bad48ffabcf859ca25a2b6cb81069b3c08b7f53bf53d7c00bc56466f76d73'
BASELINE_SOURCE = 'a036f1144ea3d3cf502d888b8a07f442837a857f'
NATIVE = BASE / 'native-0658e6ae6'
FAILED = BASE / 'native-6bc9d5d5c'
SYNTAX = BASE / 'syntax-message-diagnostic'
OUT = BASE / 'publication-candidate-0658e6ae6'
STEM = 'memory-runtime-error-tail-20261028'
MIB = 1024**2
MAX_MEMBER, MAX_EXPANDED, MAX_COMPRESSED, MAX_FILES = 128*MIB, 512*MIB, 64*MIB, 4096
PREDECESSOR_SOURCE = 'fb41daeafb83ce25f7c1842f2e943eea54f9b347'
PREDECESSOR = ROOT/'target/memory-inline-compact-storage-20261028-evidence/native-fb41daeaf/report.json'
PREDECESSOR_SHA = 'd455639736ee0f275f0a785ec786f9aba3ee710b6338b276698111142ca8fa0b'
REPAIRS = ['crates/scriptw-engine/tests/aot_language/aot_runtime_error_for_throw.rs']
PLAN = [
    ('scriptw-aot-wasm', 'scriptw_aot_wasm', 'lib'),
    ('scriptw-engine', 'aot_realm_modules', 'test'),
    ('scriptw-engine', 'scriptw_engine', 'lib'),
    ('scriptw-aot-wasm', 'emission', 'test'),
    ('scriptw-engine', 'aot_regexp', 'test'),
    ('scriptw-engine', 'aot_gc_entries', 'test'),
    ('scriptw-aot-wasm', 'modules_realms', 'test'),
    ('scriptw-aot-wasm', 'intl_temporal', 'test'),
    ('scriptw-aot-wasm', 'runtime_link', 'test'),
    ('scriptw-aot-wasm', 'structure_builtins', 'test'),
    ('scriptw-engine', 'structure', 'test'),
    ('scriptw-engine', 'aot_language', 'test'),
    ('scriptw-engine', 'aot_generators', 'test'),
    ('scriptw-engine', 'aot_intl', 'test'),
    ('scriptw-engine', 'aot_builtins', 'test'),
    ('scriptw-engine', 'aot_temporal', 'test'),
    ('scriptw-engine', 'aot_async', 'test'),
    ('scriptw-aot-wasm', 'structure_language', 'test'),
    ('scriptw-aot-wasm', 'structure_async', 'test'),
]
FOCUS = {
    ('scriptw-aot-wasm', 'scriptw_aot_wasm', 'lib'): {
        'tests::runtime_error_for_throw::throwing_tail_uses_actual_r_export_and_compacted_p_import_with_caller_completion',
        'tests::runtime_error_for_throw::nine_kind_tail_allocates_before_names_publishes_supplied_message_and_traps_invalid_wire',
        'tests::runtime_error_for_throw::normal_cancellation_keeps_allocation_only_error_path_and_normal_completion',
    },
    ('scriptw-engine', 'aot_language', 'test'): {
        'aot_runtime_error_for_throw::repeated_throw_tails_replace_diagnostics_and_keep_program_messages_across_gc',
        'aot_runtime_error_for_throw::borrowed_and_explicit_realm_throw_tails_ignore_tampered_error_globals',
    },
    ('scriptw-engine', 'scriptw_engine', 'lib'): {
        'embedding::tests::async_operations::retained_async_calls_settle_on_store_pump_with_gc_microtasks_rejection_and_cancellation',
        'embedding::tests::realm_async::async_byte_fulfillment_rejection_and_cancellation_use_the_wrapper_realm',
    },
}
# The two existing engine controls are focused executions, not new inventory.
NEW_IDS = {key: names for key,names in FOCUS.items() if key[1] != 'scriptw_engine'}

sys.path.insert(0, str(ROOT / 'scripts'))
import precompiled_comparison as p
from limited_verification import require_kernel_budget, kernel_group
from native_test_protocol import parse_inventory, result_summaries


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def regular(path, cap=MAX_MEMBER):
    path = Path(path)
    info = path.lstat()
    assert path.is_absolute() and path.resolve(strict=True) == path
    assert stat.S_ISREG(info.st_mode) and not path.is_symlink() and info.st_size <= cap
    return info


def read(path, cap=16*MIB):
    regular(path, cap)
    return p._json(Path(path).read_bytes())


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)


def root_state():
    assert not git('status', '--porcelain', '--untracked-files=no')
    return git('rev-parse', 'HEAD').decode().strip()


def budget():
    group = kernel_group()
    return {key: (group/key).read_text().strip() for key in
            ('memory.max', 'memory.swap.max', 'memory.oom.group', 'memory.peak', 'memory.events')}


def resources(value, maximum=4*1024**3, cpu_recorded=True):
    if cpu_recorded:
        assert value['cpu_affinity'] == [0]
    events = []
    for row in (value['before'], value['after']):
        assert 0 < int(row['memory.max']) <= maximum
        assert row['memory.swap.max'] == '0' and row['memory.oom.group'] == '1'
        assert 0 <= int(row['memory.peak']) <= int(row['memory.max'])
        events.append(dict(line.split() for line in row['memory.events'].splitlines()))
    assert all(events[0][key] == events[1][key] == '0' for key in ('oom', 'oom_kill', 'oom_group_kill'))


def streams(directory, commands, failed=False):
    assert len({row['label'] for row in commands}) == len(commands)
    for row in commands:
        assert (row['exit_code'] == 101 if failed else row['exit_code'] == 0)
        assert not any(row.get(key, False) for key in ('timed_out', 'output_limit_exceeded', 'pipe_cleanup_incomplete'))
        for channel in ('stdout', 'stderr'):
            name = row.get(channel, row['label']+'.'+channel)
            assert p.safe_name(name) == row['label']+'.'+channel
            path = directory/name
            info = regular(path)
            assert sha(path) == row[channel+'_sha256']
            if channel+'_bytes' in row:
                assert info.st_size == row[channel+'_bytes']


def source_admission():
    assert sha(PROOF) == PROOF_SHA
    proof = read(PROOF)
    assert (proof['original_feature'],proof['verified_source'],proof['probe']) == (FEATURE,SOURCE,MEASURED)
    assert proof['computed_compiler_inputs_equal'] is True and len(proof['rows']) == 6
    resources(proof,256*MIB)
    prior = BASE/'source-bindings-feature-probe.json'
    assert proof['prior_report_sha256'] == sha(prior) == 'd33b2a5a023902ee01533b5380f20ad98534cce5bc62de76b1dc6c2c8499a989'
    for revision in (FEATURE,SOURCE,MEASURED):
        for ignored,expected in ((False,FP),(True,LOCAL_FP)):
            rows=[row for row in proof['rows'] if row['revision']==revision and row['extra_ignored_regress_lock'] is ignored]
            assert len(rows)==1 and rows[0]['source_fingerprint']==expected
            assert (rows[0]['files'],rows[0]['bytes'])==((2926,161602862) if ignored else (2925,161601631))
    assert git('diff','--name-only',FEATURE,SOURCE).decode().splitlines()==REPAIRS
    assert git('diff','--name-only',FEATURE,MEASURED).decode().splitlines()==['.github/workflows/precompiled-benchmarks.yaml']
    # Engine integration tests lie outside the compiler fingerprint roots. The
    # independently computed six-row proof binds both test-file revisions.
    assert REPAIRS[0].startswith('crates/scriptw-engine/tests/')
    for name in ('precompiled_comparison.py','benchmark_module_images.py','benchmark_module_sections.py',
                 'diagnose-precompiled-mappings.py','native_test_protocol.py','limited_verification.py'):
        path=ROOT/'scripts'/name
        regular(path)
        assert path.read_bytes()==git('show',FEATURE+':scripts/'+name)==git('show',SOURCE+':scripts/'+name)==git('show',MEASURED+':scripts/'+name)
    for revision in (FEATURE,SOURCE,MEASURED):
        assert re.findall(rb'const LAYOUT_VERSION: u32 = (\d+);',git('show',revision+':crates/scriptw-aot-wasm/src/runtime_artifact.rs'))==[b'32']
    return proof


def native_admission(native):
    assert native['schema'] == 'scriptw-runtime-error-tail-native-verification-v1'
    assert native['complete'] is True and native['source_commit'] == native['reviewed_source_commit'] == SOURCE
    assert native['features'] == [] and native['predecessor_binary_reuse'] is False
    assert [(row['package'], row['target'], row['kind']) for row in native['plan']] == PLAN
    assert [(row['package'], row['target'], row['kind']) for row in native['scopes']] == PLAN
    assert len(native['scopes']) == 19 and native['driver_sha256'] == DRIVER_SHA
    assert sha(BASE/'native-runtime-error-tail-r1.py') == DRIVER_SHA
    assert native['expected_native_inventory_total'] == native['observed_native_inventory_total'] == 4917
    assert native['expected_native_inventory_total_matches'] is True and native['added_native_ids'] == 23
    assert native['passed_disjoint_scopes'] == native['executed_disjoint_passes'] == 4917
    assert native['inherited_disjoint_passes'] == native['repeated_native_test_ids'] == 0
    assert native['focused_complete'] is True and native['focused_passed'] == native['focused_passes_included'] == 7
    assert native['broad_remainder_passes'] == 4910
    resources(native)
    streams(NATIVE, native['commands'])
    assert sha(BASELINE) == BASELINE_SHA
    baseline = read(BASELINE)
    assert baseline['complete'] is True and baseline['source_commit'] == BASELINE_SOURCE and baseline['passed_disjoint_scopes'] == 4894
    old = {(row['package'], row['target'], row['kind']): row for row in baseline['scopes']}
    assert set(old) == set(PLAN)
    assert native['baseline'] == dict(path=str(BASELINE), sha256=BASELINE_SHA, source_commit=BASELINE_SOURCE,
                                     complete=True, passed_disjoint_scopes=4894, inherited_passes=0)
    checkout = Path(native['source_checkout'])
    assert checkout == ROOT/'target/memory-calendar-rows-20261028'
    build = ROOT/'target/performance-work-20261024/build'
    assert native['build_directory'] == str(build)
    scopes = {str(NATIVE/row['binary']): row for row in native['scopes']}
    observed = {name: [] for name in scopes}
    command_focus = []
    expected_producers = [row['cargo_producer'] for row in native['scopes']]
    cargo_rows = []
    # Streaming the potentially large Cargo JSON log bounds parser retention.
    with (NATIVE/'cargo-native.stdout').open('rb') as stream:
        for line in stream:
            assert len(line) <= 16*MIB
            row = p._json(line)
            if row.get('reason') == 'build-finished':
                cargo_rows.append(row)
            elif row.get('reason') == 'compiler-artifact' and row.get('executable') and row['profile']['test']:
                if any(row['package_id'].startswith('path+file://'+str(checkout/'crates'/package)+'#') for package in ('scriptw-aot-wasm', 'scriptw-engine')):
                    cargo_rows.append(row)
    assert cargo_rows[-1] == dict(reason='build-finished', success=True)
    assert [row for row in cargo_rows if row.get('reason') == 'build-finished'] == [dict(reason='build-finished', success=True)]
    assert len(cargo_rows) == 20 and all(cargo_rows.count(row) == 1 for row in expected_producers)
    cargo_commands = [row for row in native['commands'] if row['label'] == 'cargo-native']
    assert len(cargo_commands) == 1 and native['commands'][0] is cargo_commands[0]
    cargo = cargo_commands[0]['command']
    assert cargo[:2] == ['cargo', 'test'] and cargo[-3:] == ['--no-default-features', '--no-run', '--message-format=json']
    assert '--locked' in cargo and '--offline' in cargo and '--release' in cargo
    assert cargo[cargo.index('--jobs')+1] == '1' and cargo[cargo.index('--target-dir')+1] == str(build)
    saw_broad = False
    for command in native['commands'][1:]:
        argv = command['command']
        assert argv[0] in scopes
        scope = scopes[argv[0]]
        key = scope['package'], scope['target'], scope['kind']
        assert command['cwd'] == str(checkout/'crates'/scope['package'])
        if 'expected_test_ids' not in command:
            assert command['label'] == scope['package']+'-'+scope['target']+'-inventory'
            assert argv[1:] == ['--list', '--color=never']
            assert parse_inventory((NATIVE/command['stdout']).read_text()) == scope['inventory']
            continue
        ids = command['expected_test_ids']
        assert argv[1:5] == ['--exact', '--include-ignored', '--test-threads=1', '--color=never'] and argv[5:] == ids
        assert ids and len(ids) == len(set(ids)) and set(ids) <= set(scope['inventory'])
        text = (NATIVE/command['stdout']).read_text()
        passed = [name.removesuffix(' - should panic') for name in re.findall(r'^test ([^\r\n]+) \.\.\. ok$', text, re.M)]
        assert len(passed) == len(set(passed)) == len(ids) and set(passed) == set(ids)
        summaries = [('ok', str(len(ids)), '0', '0', '0', str(len(scope['inventory'])-len(ids)))]
        assert result_summaries(text) == summaries
        assert command['reported_passing_test_ids'] == passed and command['reported_result_summaries'] == [list(row) for row in summaries]
        assert not set(ids).intersection(observed[argv[0]])
        observed[argv[0]] += ids
        if command['label'].endswith('-focused'):
            assert not saw_broad and set(ids) == FOCUS[key]
            command_focus += [(key, name) for name in ids]
        else:
            assert '-part-' in command['label']
            saw_broad = True
            if scope['target'] in ('scriptw_engine', 'aot_gc_entries'):
                assert len(ids) <= 8
    assert len(command_focus) == 7 and set(command_focus) == {(key, name) for key, names in FOCUS.items() for name in names}
    for scope in native['scopes']:
        key = scope['package'], scope['target'], scope['kind']
        assert scope['binary'] == scope['package']+'-'+scope['target']+'/tests'
        assert re.fullmatch('[0-9a-f]{64}', scope['executable_sha256'])
        producer = scope['cargo_producer']
        crate = checkout/'crates'/scope['package']
        assert producer['package_id'].startswith('path+file://'+str(crate)+'#')
        assert producer['manifest_path'] == str(crate/'Cargo.toml')
        assert producer['target']['name'] == scope['target'] and producer['target']['kind'] == [scope['kind']]
        expected_src = crate/Path(old[key]['cargo_producer']['target']['src_path']).relative_to(ROOT/'crates'/scope['package'])
        assert producer['target']['src_path'] == str(expected_src)
        assert producer['features'] == [] and producer['profile']['test'] is True and producer['profile']['opt_level'] == '3'
        assert Path(producer['executable']).is_relative_to(build)
        inventory = scope['inventory']
        assert scope['complete'] is True and len(inventory) == len(set(inventory)) == scope['passed']
        assert set(old[key]['inventory']) <= set(inventory) and scope['removed_test_ids'] == []
        assert scope['baseline_inventory_count'] == len(old[key]['inventory'])
        assert scope['added_test_ids'] == sorted(set(inventory)-set(old[key]['inventory']))
        assert len(observed[str(NATIVE/scope['binary'])]) == len(inventory)
        assert set(observed[str(NATIVE/scope['binary'])]) == set(inventory) == set(scope['passed_test_ids'])
        assert len(scope['passed_test_ids']) == len(set(scope['passed_test_ids']))
        assert set(scope['focused_test_ids']) == FOCUS.get(key, set())
        assert not set(scope['focused_test_ids']).intersection(scope['broad_test_ids'])
        assert set(scope['focused_test_ids']) | set(scope['broad_test_ids']) == set(inventory)
        inventories = [row for row in native['commands'] if row['label'] == scope['package']+'-'+scope['target']+'-inventory']
        assert len(inventories) == 1
    assert sum(row['passed'] for row in native['scopes']) == 4917
    assert next(row['passed'] for row in native['scopes'] if row['target'] == 'scriptw_engine') == 1056
    assert next(row['passed'] for row in native['scopes'] if row['target'] == 'scriptw_aot_wasm') == 520
    assert next(row['passed'] for row in native['scopes'] if row['target']=='aot_gc_entries')==234
    assert next(row['passed'] for row in native['scopes'] if row['target']=='aot_language')==353
    assert sha(PREDECESSOR)==PREDECESSOR_SHA
    predecessor=read(PREDECESSOR)
    assert predecessor['complete'] is True and predecessor['source_commit']==PREDECESSOR_SOURCE
    assert predecessor['passed_disjoint_scopes']==4912 and predecessor['inherited_disjoint_passes']==0
    previous={(row['package'],row['target'],row['kind']):row for row in predecessor['scopes']}
    assert set(previous)==set(PLAN)
    added=set()
    for scope in native['scopes']:
        key=scope['package'],scope['target'],scope['kind']
        old_scope=previous[key]
        assert old_scope['complete'] is True and old_scope['passed']==len(old_scope['inventory'])
        assert len(set(old_scope['inventory']))==len(old_scope['inventory'])
        assert set(old_scope['inventory'])<=set(scope['inventory'])
        difference=set(scope['inventory'])-set(old_scope['inventory'])
        assert difference==NEW_IDS.get(key,set())
        added.update((key,name) for name in difference)
    assert sum(len(row['inventory']) for row in previous.values())==4912
    assert added=={(key,name) for key,names in NEW_IDS.items() for name in names} and len(added)==5
    return dict(full_scopes=19,full_scope_passes=4917,fresh_executions=4917,inherited_passes=0,
                focused_included_once=7,broad_remainder=4910,full_engine_library=1056,aot_library=520,language_target=353,gc_target=234,
                predecessor_inventory=4912,exact_new_ids=5,predecessor_report_sha256=PREDECESSOR_SHA,
                baseline_inventory=4894,added_ids=23,original_js_test262_executions=0)


def cheap_admission():
    assert sha(BASE/'cheap-r1/report.json') == CHEAP_SHA
    cheap = read(BASE/'cheap-r1/report.json')
    assert cheap['complete'] is True and cheap['base']=='d5f1922876d48076d99a5e625629ce1a873dac48'
    resources(cheap, 1024**3)
    streams(BASE/'cheap-r1', cheap['commands'])
    assert [row['label'] for row in cheap['commands']] == ['guard-mutations','rustfmt','source-guards','immutable-pool','source-profile','identities','retired-js','diff']
    assert sha(BASE/'cheap-r1.py') == cheap['driver_sha256'] == '7f3551d8815cd53e97c02799c4cd6671b98aad424402d2e8932b862cc7b1530f'
    for name, expected in cheap['source_files'].items():
        assert hashlib.sha256(git('show', FEATURE+':'+name)).hexdigest() == expected
    assert len(cheap['source_files'])==47
    summary = result_summaries((BASE/'cheap-r1/source-guards.stdout').read_text())
    assert [row[:5] for row in summary] == [('ok','143','0','0','0'), ('ok','135','0','0','0')]
    mutation = (BASE/'cheap-r1/guard-mutations.stderr').read_text()
    assert re.findall(r'Ran (\d+) tests?', mutation) == ['15'] and re.search(r'^OK$', mutation, re.M)
    identities = (BASE/'cheap-r1/identities.stdout').read_text().splitlines()
    assert len(identities) == 15 and all(line.startswith('PASS ') for line in identities)
    return cheap


def failure_admission():
    assert sha(FAILED/'report.json')==FAILED_SHA
    r0=read(FAILED/'report.json')
    assert r0['complete'] is False and r0['source_commit']==r0['reviewed_source_commit']==FEATURE
    assert r0['driver_sha256']==sha(BASE/'native-runtime-error-tail-r0.py')=='8b459a3b9253792d19638ee267044acbf25afe1f01c27f482a646962a93d5c98'
    assert r0['error']=='scriptw-engine-aot_language-focused failed; original streams retained'
    assert not r0.get('passed_disjoint_scopes') and not r0.get('focused_complete')
    resources(r0)
    assert len(r0['commands'])==22 and len(r0['scopes'])==19 and not any(scope['complete'] for scope in r0['scopes'])
    streams(FAILED,r0['commands'][:-1]);streams(FAILED,[r0['commands'][-1]],failed=True)
    focuses=[row for row in r0['commands'] if 'expected_test_ids' in row]
    assert len(focuses)==2 and all(row['label'].endswith('-focused') for row in focuses)
    for row,key,count,failed,filtered in [(focuses[0],PLAN[0],3,0,517),
            (focuses[1],('scriptw-engine','aot_language','test'),0,2,351)]:
        assert set(row['expected_test_ids'])==FOCUS[key]
        text=(FAILED/row['stdout']).read_text()
        passing=[name.removesuffix(' - should panic') for name in re.findall(r'^test ([^\r\n]+) \.\.\. ok$',text,re.M)]
        assert len(passing)==len(set(passing))==count and passing==row['reported_passing_test_ids']
        status='FAILED' if failed else 'ok'
        summary=[(status,str(count),str(failed),'0','0',str(filtered))]
        assert result_summaries(text)==summary and row['reported_result_summaries']==[list(value) for value in summary]
    assert sha(SYNTAX/'report.json')==DIAGNOSTIC_SHA
    diagnostic=read(SYNTAX/'report.json')
    assert diagnostic['source_commit']==FEATURE and diagnostic['purpose']=='capture exact SyntaxError text; not full native verification'
    assert sha(BASE/'diagnose-syntax-message.py')==DIAGNOSTIC_DRIVER_SHA
    # This older diagnostic receipt lacks an affinity field. Its pinned driver
    # enforces CPU0; retain the missing field rather than inventing a receipt.
    assert 'cpu_affinity' not in diagnostic
    resources(diagnostic,4*1024**3,cpu_recorded=False)
    assert len(diagnostic['commands'])==1
    command=diagnostic['commands'][0]
    assert command['label']=='diagnostic-language' and command['exit_code']==101
    assert not any(command.get(key,False) for key in ('timed_out','output_limit_exceeded','pipe_cleanup_incomplete'))
    for channel in ('stdout','stderr'):
        assert command[channel]=='cargo.'+channel
        path=SYNTAX/command[channel]
        assert regular(path,2*MIB).st_size==command[channel+'_bytes'] and sha(path)==command[channel+'_sha256']
    text=(SYNTAX/'cargo.stdout').read_text()
    assert result_summaries(text)==[('FAILED','0','2','0','0','351')]
    assert set(re.findall(r'^test ([^\r\n]+) \.\.\. FAILED$',text,re.M))==FOCUS[('scriptw-engine','aot_language','test')]
    units=re.findall(r'completion: Throw\(String\((\[[0-9, ]+\])\)\)',text)
    assert len(units)==2
    messages=[]
    for value in units:
        assert len(value)<=8192
        codes=json.loads(value)
        assert len(codes)<=2048 and all(type(code) is int and 0<=code<=65535 for code in codes)
        messages.append(''.join(chr(code) for code in codes))
    assert all(message.endswith('parse error: lexical name declared multiple times at line 1, col 1') for message in messages)
    return r0,diagnostic


def archive(files):
    expanded = sum(row['bytes'] for row in files.values())
    assert expanded <= MAX_EXPANDED and 0 < len(files) <= MAX_FILES
    path = OUT/(STEM+'-inert.tar.xz')
    with path.open('xb') as raw, lzma.LZMAFile(raw, 'w', filters=[dict(id=lzma.FILTER_LZMA2,preset=1,dict_size=16*MIB)]) as compressed:
        with tarfile.open(fileobj=compressed, mode='w|') as bundle:
            for name, row in sorted(files.items()):
                member = tarfile.TarInfo(name)
                member.size, member.mode = row['bytes'], 0o644
                with row['source'].open('rb') as stream:
                    bundle.addfile(member, stream)
    assert path.stat().st_size <= MAX_COMPRESSED
    seen, total = set(), 0
    with tarfile.open(path, 'r|xz') as bundle:
        for member in bundle:
            assert member.isfile() and member.name in files and member.name not in seen
            row = files[member.name]
            assert member.size == row['bytes'] <= MAX_MEMBER
            total += member.size
            assert total <= MAX_EXPANDED
            with bundle.extractfile(member) as stream:
                assert hashlib.file_digest(stream,'sha256').hexdigest() == row['sha256']
            seen.add(member.name)
    assert seen == set(files) and total == expanded
    return dict(file=path.name,sha256=sha(path),bytes=path.stat().st_size,expanded_bytes=expanded,
                member_count=len(files),max_member_bytes=MAX_MEMBER,max_expanded_bytes=MAX_EXPANDED,
                max_compressed_bytes=MAX_COMPRESSED,max_members=MAX_FILES,roundtrip_sha256_verified=True,
                native_payloads_retained=False,members=[dict(path=name,bytes=row['bytes'],sha256=row['sha256']) for name,row in sorted(files.items())])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', type=int, required=True)
    parser.add_argument('--native-report-sha256', required=True)
    parser.add_argument('--ci-report-sha256', required=True)
    parser.add_argument('--ci-validator-path', type=Path, required=True)
    parser.add_argument('--ci-validator-sha256', required=True)
    args = parser.parse_args()
    assert __debug__ and args.run > 0
    assert all(re.fullmatch('[0-9a-f]{64}', value) for value in
               (args.native_report_sha256,args.ci_report_sha256,args.ci_validator_sha256))
    run_id = args.run
    ci_dir = BASE/f'ci-{run_id}-validated'
    scored = BASE/f'github-{run_id}-scored/precompiled-evidence'
    ci_driver = args.ci_validator_path
    regular(ci_driver)
    assert ci_driver.parent == BASE and sha(ci_driver) == args.ci_validator_sha256
    require_kernel_budget(1024**3)
    assert sorted(os.sched_getaffinity(0)) == [0] and not OUT.exists()
    # Both future completed receipts and reviewed hashes must exist before writes.
    assert sha(NATIVE/'report.json') == args.native_report_sha256
    assert sha(ci_dir/'report.json') == args.ci_report_sha256
    native, ci = read(NATIVE/'report.json'), read(ci_dir/'report.json')
    assert native['complete'] is ci['complete'] is True
    initial = root_state()
    processing = dict(complete=False,started_at=datetime.now(timezone.utc).isoformat(),cpu_affinity=[0],before=budget(),
                      driver=dict(path=str(Path(__file__).resolve()),sha256=sha(__file__)),processing_checkout=initial,
                      scope='Private inert candidate only. No compilation, native loading, workloads, source edits, publication or status refresh.')
    OUT.mkdir()
    try:
        proof = source_admission()
        coverage = native_admission(native)
        cheap = cheap_admission()
        failed, syntax = failure_admission()
        assert ci['schema'] == 'scriptw-runtime-error-tail-ci-validation-v1'
        assert ci['source_commit'] == MEASURED and ci['feature_source_commit'] == FEATURE
        assert ci['source_fingerprint'] == FP and ci['run'] == run_id
        assert ci['driver_sha256'] == args.ci_validator_sha256
        resources(ci, 1024**3)
        assert ci['scored_admitted'] is ci['scored_all_attempts_ok'] is True
        assert ci['scored_attempts'] == 68 and ci['scored_workloads'] == 17
        assert ci['native_controls']['status'] == 'validated' and ci['native_controls']['passed'] == 6
        controls = {
            'embedding::benchmark_module_images::sections::tests::malformed_headers_extended_counts_and_table_extents_are_rejected',
            'embedding::benchmark_module_images::sections::tests::name_budget_is_aggregate_even_for_omitted_logical_sections',
            'embedding::benchmark_module_images::sections::tests::names_require_unique_bounded_terminated_utf8_and_in_table_offsets',
            'embedding::benchmark_module_images::sections::tests::relocatable_no_program_headers_yields_only_exact_file_backed_metadata',
            'embedding::benchmark_module_images::sections::tests::section_arithmetic_overlap_nobits_and_text_anchors_fail_closed',
            'embedding::tests::benchmark_module_images::diagnostic_images_match_actual_program_runtime_and_survive_store_drop',
        }
        assert len(ci['native_controls']['test_ids']) == 6 and set(ci['native_controls']['test_ids']) == controls
        control_out = BASE/f'github-{run_id}-scored/module-sections-native.stdout'
        control_err = BASE/f'github-{run_id}-scored/module-sections-native.stderr'
        regular(control_out,32*MIB); regular(control_err,32*MIB)
        assert sha(control_out) == ci['native_controls']['stdout_sha256'] and sha(control_err) == ci['native_controls']['stderr_sha256']
        control_text = control_out.read_text()
        actual_controls = re.findall(r'^test ([^\r\n]+) \.\.\. ok$',control_text,re.M)
        assert len(actual_controls) == len(set(actual_controls)) == 6 and set(actual_controls) == controls
        assert len(result_summaries(control_text)) == 1 and result_summaries(control_text)[0][:5] == ('ok','6','0','0','0')
        assert ci['diagnostic_complete'] is True and ci['diagnostic']['status'] == 'validated'
        cases = ci['diagnostic']['cases']
        assert len(cases) == 4 and {(row['runtime'],row['file']) for row in cases} == {
            (runtime,name) for runtime in ('scriptw','scriptc') for name in ('integer.js','retained-objects.js')}
        assert len(ci['runtime_sections']) == 2 and ci['runtime_identity']['layout'] == 32
        assert ci['source_bindings']['test_only_verified_final'] == SOURCE
        layout_source = ci_dir/'runtime-artifact-layout-source.rs'
        regular(layout_source)
        assert sha(layout_source) == ci['runtime_identity']['layout_source_sha256']
        assert layout_source.read_bytes() == git('show', MEASURED+':crates/scriptw-aot-wasm/src/runtime_artifact.rs')
        campaign, table = p.load_report(scored/'report.json')
        assert campaign['source_commit'] == MEASURED and campaign['source_fingerprint'] == FP and table == ci['scored_table']
        assert campaign['tools']['consumer']['cargo_producer']['features'] == ['benchmark-module-images']
        assert campaign['tools']['rustc']['version'].startswith('rustc 1.99.1 ')
        assert len(campaign['attempts']) == 68 and len(table) == 17 and all(row['status'] == 'ok' for row in campaign['attempts'])
        keys = {row['image']['runtime_key'] for row in campaign['attempts'] if row['runtime'] == 'scriptw'}
        assert len(keys) == 1 and None not in keys and sorted(keys) == ci['runtime_identity']['runtime_keys']
        run = read(BASE/f'github-run-{run_id}-completed.json')
        assert run['databaseId'] == run_id and run['headSha'] == MEASURED and run['status'] == 'completed' and run['conclusion'] == 'success'
        assert len(run['jobs']) == 1 and run['jobs'][0]['name'] == 'measure' and run['jobs'][0]['conclusion'] == 'success'
        for name in ('Verify and build the shared host','Measure both compiler-free consumers','Observe unscored consumer mappings','Retain all raw observations and failures'):
            steps = [step for job in run['jobs'] for step in job['steps'] if step['name'] == name]
            assert len(steps) == 1 and steps[0]['conclusion'] == 'success'
        selected = {row['file']:{runtime:{key:values[key] for key in ('ms','rss_mib')}
            for runtime,values in row['runtimes'].items()} for row in table
            if row['file'] in ('integer.js','objects.js','retained-objects.js')}
        ratios = [row['runtimes']['scriptw']['rss_mib']/row['runtimes']['scriptc']['rss_mib'] for row in table]
        # These are private previews only. Publishing canonical latest-17 graphs
        # remains a separate action after this complete candidate is reviewed.
        charts = {}
        for metric in p.CHARTS:
            svg = OUT/('preview-'+str(run_id)+'-'+metric+'.svg')
            png = OUT/('preview-'+str(run_id)+'-'+metric+'.png')
            assert not svg.exists() and not png.exists()
            raw = p.render(campaign, table, metric, png)
            with svg.open('xb') as stream:
                stream.write(raw)
            charts[metric] = dict(svg=svg.name,svg_sha256=sha(svg),png=png.name,png_sha256=sha(png))
        files, excluded = {}, []
        def add(name, path, expected=None):
            path = Path(path)
            assert name not in files and not name.startswith('/') and '..' not in Path(name).parts
            assert name == Path(name).as_posix() and '\x00' not in name and '\n' not in name
            info = regular(path)
            with path.open('rb') as stream:
                magic = stream.read(8)
            if magic.startswith((b'\x7fELF',b'MZ',b'SWRTZ001',b'SCRWRB',b'SCRWEP',b'SCRWWA',b'SCRWNR')):
                assert expected is None, 'admitted inert CI input contains native payload'
                excluded.append(dict(path=name,bytes=info.st_size,reason='native executable or runtime/native package'))
                return
            row = dict(source=path,bytes=info.st_size,sha256=sha(path))
            if expected is not None:
                assert (row['bytes'],row['sha256']) == (expected['bytes'],expected['sha256'])
            files[name] = row
            assert len(files) <= MAX_FILES and sum(item['bytes'] for item in files.values()) <= MAX_EXPANDED
        frozen_binaries = {str(directory/scope['binary']) for directory,report in [(NATIVE,native),(FAILED,failed)] for scope in report['scopes']}
        for directory in (FAILED,NATIVE,SYNTAX,BASE/'cheap',BASE/'cheap-r1'):
            for path in sorted(directory.rglob('*')):
                if path.is_symlink():
                    raise ValueError('symlink in evidence tree: '+str(path))
                if not path.is_file():
                    continue
                alias = directory.name+'/'+path.relative_to(directory).as_posix()
                # Known large executables are excluded without reading payload.
                if str(path) in frozen_binaries or path.name == 'source-guards':
                    excluded.append(dict(path=alias,bytes=path.stat().st_size,reason='native executable; metadata identity retained in report'))
                    continue
                add(alias,path)
        for name, expected in ci['inputs'].items():
            path = Path(name)
            if path.is_relative_to(BASE):
                alias = 'evidence/'+path.relative_to(BASE).as_posix()
            else:
                assert path.is_relative_to(ROOT/'scripts')
                alias = 'reproduce/'+path.relative_to(ROOT).as_posix()
            add(alias,path,expected)
        explicit = [
            f'ci-{run_id}-validated/report.json',f'ci-{run_id}-validated/summary.md',
            f'ci-{run_id}-validated/runtime-artifact-layout-source.rs',
            'source-bindings-final-local-probe.json','source-bindings-final.py',
            'source-bindings-feature-probe.json','source-bindings.py',
            'native-runtime-error-tail-r0.py','native-runtime-error-tail-r1.py',
            'native-6bc9d5d5c-launch.json','native-0658e6ae6-launch.json',
            'launch-native-r0.py','launch-native-r1.py','diagnose-syntax-message.py',
            'cheap.py','cheap-r1.py',f'github-run-{run_id}-completed.json',
        ]
        for name in explicit:
            alias='evidence/'+name
            if alias not in files:add(alias,BASE/name)
        alias='evidence/'+ci_driver.name
        if alias not in files:add(alias,ci_driver)
        pattern = ROOT/'target/memory-module-ownership-20261027-evidence/validate-ci-40594118953.py'
        assert sha(pattern) == ci['reused_validator_sha256']
        add('reproduce/ownership-validator-pattern.py',pattern)
        add('reproduce/publication-driver.py',Path(__file__).resolve())
        add('reference/core-native-4894-report.json',BASELINE)
        add('reference/predecessor-native-4912-report.json',PREDECESSOR)
        for name in ('limited_verification.py','native_test_protocol.py','precompiled_comparison.py','benchmark_module_images.py','benchmark_module_sections.py','diagnose-precompiled-mappings.py'):
            alias = 'reproduce/scripts/'+name
            if alias not in files:
                add(alias,ROOT/'scripts'/name)
        previous = ROOT/'docs/rust-rewrite/memory-inline-compact-storage-20261028.json'
        add('reference/'+previous.name,previous)
        for name in ('crates/scriptw-aot-wasm/src/runtime_artifact.rs',
                     'crates/scriptw-aot-wasm/src/runtime_helpers.rs',
                     'crates/scriptw-aot-wasm/src/builtins/errors/runtime_error.rs',
                     'crates/scriptw-aot-wasm/src/tests/runtime_error_for_throw.rs',
                     'docs/rust-rewrite/contracts/runtime-error-for-throw.md',*REPAIRS):
            path = OUT/Path(name).name
            with path.open('xb') as stream:
                stream.write(git('show',SOURCE+':'+name))
            add('reproduce/source/'+name,path)
        patch=OUT/'test-only-repairs.patch'
        with patch.open('xb') as stream:stream.write(git('diff',FEATURE,SOURCE,'--',*REPAIRS))
        add('reproduce/test-only-repairs.patch',patch)
        for chart in charts.values():
            for kind in ('svg','png'):
                add('previews/'+chart[kind],OUT/chart[kind])
        retained = archive(files)
        assert all(sha(row['source']) == row['sha256'] for row in files.values())
        assert sha(NATIVE/'report.json') == args.native_report_sha256 and sha(ci_dir/'report.json') == args.ci_report_sha256
        assert sha(ci_driver) == args.ci_validator_sha256 and sha(PROOF) == PROOF_SHA and root_state() == initial
        after = budget()
        resources(dict(cpu_affinity=[0],before=processing['before'],after=after),1024**3)
        processing.update(complete=True,after=after,finished_at=datetime.now(timezone.utc).isoformat(),excluded_payloads=excluded)
        document = dict(schema='scriptw-runtime-error-tail-evidence-v1',recorded_at=datetime.now(timezone.utc).isoformat(),
            verified_source_commit=SOURCE,compiler_feature_source_commit=FEATURE,measured_source_commit=MEASURED,runtime_layout=32,
            compiler_change=dict(helper='RuntimeErrorForThrow',operand='Closed NativeErrorKind, rooted prototype Value and rooted message StringValue.',
                semantics='Caller resolves prototype then message; runtime helper allocates, clears only Name/Message diagnostics, resolves canonical R name, publishes name/message, returns original error. Caller owns completion/branch state.',
                preserved='Allocation-only RuntimeErrorObject, normal cancellation, message-less TypeErrors and native parser Syntax paths remain unchanged.'),
            source_bindings=dict(proof_sha256=PROOF_SHA,clean_fingerprint=FP,local_fingerprint=LOCAL_FP,rows=proof['rows']),
            native=dict(report_sha256=args.native_report_sha256,coverage=coverage,
                interpretation='All 19 affected full scopes ran freshly once. Seven focused controls count once, including two existing cancellation controls; no failed-prefix or predecessor passes are inherited. No original-JS or pinned Test262 execution is claimed.'),
            cheap_checkpoint=dict(report_sha256=CHEAP_SHA,rust_source_controls=278,guard_mutation_tests=15,current_intl_identities=15,
                source=FEATURE,scope='Exact pre-build feature source_files; the subsequent test-only fixture repair is separately bound and freshly covered.'),
            verification_only_repairs=[dict(source=SOURCE,file=REPAIRS[0],
                reason='Expect the exact prepared-source parser diagnostic rather than an identifier absent from its static message; retain prototype/Realm/GC/error-identity assertions.')],
            failure_lineage=dict(native_r0=dict(report_sha256=FAILED_SHA,source=FEATURE,complete=False,passing_rows=3,
                aot_passing_rows=3,language_failed_rows=2,credited_to_final=0,error=failed['error']),
                syntax_diagnostic=dict(report_sha256=DIAGNOSTIC_SHA,source=FEATURE,passing_rows=0,failed_rows=2,credited_to_final=0,
                    purpose=syntax['purpose'],cpu_affinity_receipt_recorded=False,driver_enforces_cpu0=True)),
            measurement=dict(run=run_id,validated_report_sha256=args.ci_report_sha256,validator_sha256=args.ci_validator_sha256,
                scored_report_sha256=sha(scored/'report.json'),attempts=68,workloads=17,all_attempts_ok=True,
                rss_ratio_min=min(ratios),rss_ratio_max=max(ratios),selected=selected,table=table,charts=charts),
            ci_native_controls=ci['native_controls'],ci_cli_example_controls=ci['cli_example_controls'],
            runtime_identity=ci['runtime_identity'],runtime_sections=ci['runtime_sections'],next_measurement_targets=ci['next_measurement_targets'],
            resource_origins=dict(source_binding=dict(before=proof['before'],after=proof['after']),
                cheap_r1=dict(before=cheap['before'],after=cheap['after']),
                native_r0=dict(before=failed['before'],after=failed['after'],complete=False),
                syntax_diagnostic=dict(before=syntax['before'],after=syntax['after'],cpu_affinity_receipt_recorded=False),
                native_r1=dict(before=native['before'],after=native['after']),
                ci_validation=dict(before=ci['before'],after=ci['after']),candidate_processing=dict(before=processing['before'],after=after)),
            prior_checkpoint=dict(file=previous.name,sha256=sha(previous),inherited_executions=0),archive=retained,publication_processing=processing,
            interpretation='Current layout32/key is recorded independently; no causal RSS/speed saving, parity, cross-runner native equality or prior-runtime-key equality is assumed. Warm observation16 follows16 earlier calls. Section/page overlaps are nonadditive and presence does not prove execution. Scored two-runtime results remain separate from V8/status and unscored ownership observations.')
        lines=['# Shared runtime error tail','',
            'Verified source `'+SOURCE+'`: 4,917 fresh native passes across 19 full scopes, including AOT 520, engine library 1,056, language 353 and GC 234. Seven focused controls count once. All 4,912 predecessor IDs remain present with exactly five new IDs. No earlier passes or original JS/Test262 execution are credited.','',
            'The first native run recorded three AOT passes and two language failures caused by the incorrect expected Syntax diagnostic. The separate instrumented diagnostic also failed both fixtures and recorded the actual static message. All receive zero final coverage credit. The final correction touches only the language-test file; the six-row compiler-input proof and all raw streams are retained.','',
            'The typed shared tail preserves allocation-only cancellation and caller Realm/message/completion ordering. Layout32 rejects old artifacts. No saving is inferred from source call counts.','',
            'CI '+str(run_id)+' (`'+MEASURED+'`):68/68 scored attempts across17 workload checksums, six observer controls and four separately validated unscored v2 captures. Current Scriptw/Scriptc RSS ratio range: '+format(min(ratios),'.9f')+'–'+format(max(ratios),'.9f')+'. No causal memory or speed saving is inferred.','',
            '| Workload | Scriptw ms | Scriptc ms | Scriptw RSS MiB | Scriptc RSS MiB |','|---|---:|---:|---:|---:|']
        for row in table:
            lines.append('| '+row['file']+' | '+' | '.join(format(row['runtimes'][runtime][metric],'.6f') for metric in ('ms','rss_mib') for runtime in ('scriptw','scriptc'))+' |')
        lines+=['','Cheap controls bind the exact feature files:278 Rust source controls,15 guard-mutation tests and15 current Intl identities. The later test-only fixture repair is independently source-bound and rerun in the full native checkpoint.','',
            'Private previews use current admitted absolute values. Canonical latest-17 graphs are published only after complete candidate review. Warm unscored observation16 follows16 prior calls; section overlaps must not be summed or prorated into RSS. Layout32/key is independent of prior and cross-runner native images.','',
            'The bounded inert archive retains current inventories/results, failed native and diagnostic streams, cheap controls, source/CI proofs, validators and scored/capture metadata. Native executables and runtime/native packages are excluded. Candidate generation changes no source, README, status, published graphs or external application.']
        with (OUT/(STEM+'.json')).open('x') as stream:
            stream.write(json.dumps(document,indent=2)+'\n')
        with (OUT/(STEM+'.md')).open('x') as stream:
            stream.write('\n'.join(lines)+'\n')
    except BaseException as error:
        processing.update(complete=False,error=repr(error),error_type=type(error).__name__,after=budget(),finished_at=datetime.now(timezone.utc).isoformat())
        raise
    finally:
        with (OUT/'processing.json').open('x') as stream:
            stream.write(json.dumps(processing,indent=2)+'\n')
    print(json.dumps(dict(complete=True,output=str(OUT),coverage=coverage,archive_sha256=retained['sha256'],expanded_bytes=retained['expanded_bytes'])))


if __name__ == '__main__':
    main()
