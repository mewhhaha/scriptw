import json,hashlib,subprocess,os,shutil,sys
from pathlib import Path
from datetime import datetime,timezone
BASE=Path(__file__).resolve().parent
REPO=BASE.parents[1]
ROOT=REPO/'target/memory-calendar-rows-20261028'
BUILD=REPO/'target/performance-work-20261024/build'
SOURCE='623f722a1d1be62bdf603f8d1f791f522f68efc4'
sys.path.insert(0,str(REPO/'scripts'))
from limited_verification import require_kernel_budget,kernel_group
from native_test_protocol import parse_inventory,result_summaries
require_kernel_budget(4*1024**3);assert sorted(os.sched_getaffinity(0))==[0]
out=BASE/'native-623f722a1';out.mkdir(exist_ok=False)
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def budget():return {k:(kernel_group()/k).read_text().strip() for k in ['memory.max','memory.swap.max','memory.oom.group','memory.peak','memory.events']}
def source():
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==SOURCE
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT)
r=dict(complete=False,source_commit=SOURCE,cpu_affinity=[0],before=budget(),commands=[],scope='18 full runtime_profile native IDs and the complete diagnostic example tests; no broad/Test262 claim')
def save():(out/'report.json').write_text(json.dumps(r,indent=2)+'\n')
def run(label,argv,cwd=ROOT,timeout=10800):
 source();row=dict(label=label,command=list(map(str,argv)),cwd=str(cwd));r['commands'].append(row);save();print(label,'started',flush=True)
 with (out/(label+'.stdout')).open('xb') as stdout,(out/(label+'.stderr')).open('xb') as stderr:
  p=subprocess.run(row['command'],cwd=cwd,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=timeout)
 row.update(exit_code=p.returncode,stdout_sha256=sha(out/(label+'.stdout')),stderr_sha256=sha(out/(label+'.stderr')));save();assert p.returncode==0,label
 print(label,'passed',flush=True);return (out/(label+'.stdout')).read_text()
def producer(text,package,name,kind,test):
 rows=[json.loads(x) for x in text.splitlines()];assert rows[-1]==dict(reason='build-finished',success=True)
 found=[x for x in rows if x.get('reason')=='compiler-artifact' and x.get('executable') and x['target']['name']==name and x['target']['kind']==[kind] and x['profile']['test']==test and x['package_id'].startswith('path+file://'+str(ROOT/'crates'/package)+'#')];assert len(found)==1
 x=found[0];assert x['features']==[] and x['profile']['opt_level']=='3';p=Path(x['executable']);assert p.is_relative_to(BUILD)
 dest=out/(name+('-tests' if test else ''));shutil.copyfile(p,dest);dest.chmod(0o500);assert sha(p)==sha(dest);return dest,x
try:
 source();save();common=['--locked','--offline','--release','--jobs','1','--target-dir',str(BUILD),'--no-default-features']
 a=run('cargo-engine',['cargo','test',*common,'-p','scriptw-engine','--lib','--no-run','--message-format=json'])
 engine,ep=producer(a,'scriptw-engine','scriptw_engine','lib',True);r['engine_producer']=ep
 a=run('cargo-example-tests',['cargo','test',*common,'-p','scriptw-cli','--example','runtime_baseline','--no-run','--message-format=json'])
 tests,tp=producer(a,'scriptw-cli','runtime_baseline','example',True);r['example_test_producer']=tp
 a=run('cargo-example',['cargo','build',*common,'-p','scriptw-cli','--example','runtime_baseline','--message-format=json'])
 binary,bp=producer(a,'scriptw-cli','runtime_baseline','example',False);r.update(example_producer=bp,runner=str(binary),runner_sha256=sha(binary));save()
 inv=parse_inventory(run('engine-inventory',[engine,'--list','--color=never']));ids=[i for i in inv if i.startswith('runtime_profile::')]
 old=json.loads((REPO/'target/memory-inline-compact-storage-20261028-evidence/native-fb41daeaf/report.json').read_text());prior=next(x for x in old['scopes'] if x['target']=='scriptw_engine');expected=[i for i in prior['inventory'] if i.startswith('runtime_profile::')];assert len(ids)==18 and ids==expected
 text=run('engine-profile-tests',[engine,'--exact','--include-ignored','--test-threads=1','--color=never',*ids],timeout=3600);assert result_summaries(text)==[('ok','18','0','0','0',str(len(inv)-18))]
 inv=parse_inventory(run('example-inventory',[tests,'--list','--color=never']));assert inv
 text=run('example-tests',[tests,'--include-ignored','--test-threads=1','--color=never'],timeout=1800);assert result_summaries(text)==[('ok',str(len(inv)),'0','0','0','0')]
 r.update(complete=True,engine_test_ids=ids,example_test_ids=inv,native_passes=18+len(inv))
except BaseException as e:r.update(error=str(e),error_type=type(e).__name__)
finally:
 r['after']=budget();ev=[dict(x.split() for x in v['memory.events'].splitlines()) for v in [r['before'],r['after']]];assert all(ev[0][k]==ev[1][k]=='0' for k in ['oom','oom_kill','oom_group_kill']);save();print(json.dumps(dict(complete=r['complete'],error=r.get('error'),native_passes=r.get('native_passes'))),flush=True)
raise SystemExit(0 if r['complete'] else 1)
