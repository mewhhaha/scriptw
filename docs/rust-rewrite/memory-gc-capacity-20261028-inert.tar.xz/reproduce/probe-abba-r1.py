import json,hashlib,subprocess,os,signal,statistics,sys
from pathlib import Path
BASE=Path(__file__).resolve().parent;REPO=BASE.parents[1];ROOT=REPO/'target/memory-calendar-rows-20261028'
SOURCE='623f722a1d1be62bdf603f8d1f791f522f68efc4'
sys.path.insert(0,str(REPO/'scripts'))
from limited_verification import require_kernel_budget,kernel_group
require_kernel_budget(4*1024**3);assert sorted(os.sched_getaffinity(0))==[0]
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def budget():return {k:(kernel_group()/k).read_text().strip() for k in ['memory.max','memory.swap.max','memory.oom.group','memory.peak','memory.events']}
def source():
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==SOURCE
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT)
verification=BASE/'native-623f722a1/report.json';assert sha(verification)=='6db1c40854066e3b19525a94f9ed4544b596c7c561b7c99e9f88b1819f29460e'
v=json.loads(verification.read_text());assert v['complete'] and v['native_passes']==25
runner=Path(v['runner']);assert sha(runner)==v['runner_sha256']=='4186e8bf1510f721d3f64dccbba3ebcb401c22fa460f8d7df6e83bba424971e0'
fixtures=ROOT/'crates/scriptw-cli/tests/fixtures/v8_execution_hotpaths';manifest=json.loads((fixtures/'manifest.json').read_text());cases=['integer.js','retained-objects.js','to-sorted-512.js'];expected={r['file']:r['stdout'] for r in manifest['execution']};inputs={name:sha(fixtures/name) for name in cases}
canonical=json.loads((REPO/'docs/rust-rewrite/precompiled-comparison.json').read_text())
for name in cases:
 matches=[x for x in canonical['retained_files'] if x['path']=='sources/'+name];assert len(matches)==1 and matches[0]['sha256']==inputs[name]
 assert next(x['stdout'] for x in canonical['workloads'] if x['file']==name)==expected[name]
out=BASE/'abba-16-8-8-16';out.mkdir(exist_ok=False)
r=dict(complete=False,source_commit=SOURCE,scope='Selected same-host matched diagnostic; compiler/serialized-image history is included. Not compiler-disabled Scriptw/Scriptc or live-heap RSS.',capacities=[16,8,8,16],samples=7,warmups=10,cpu_affinity=[0],before=budget(),runner_sha256=sha(runner),native_receipt_sha256=sha(verification),source_sha256=inputs,rows=[])
def save():(out/'report.json').write_text(json.dumps(r,indent=2)+'\n')
def summaries(values):return dict(samples=values,median=statistics.median(values),minimum=min(values),maximum=max(values))
try:
 source();save()
 for index,capacity in enumerate(r['capacities']):
  order=cases if index in [0,3] else list(reversed(cases))
  for name in order:
   source();assert sha(runner)==r['runner_sha256'] and sha(fixtures/name)==inputs[name]
   directory=out/(str(index)+'-'+str(capacity)+'-'+name);directory.mkdir();artifacts=directory/'artifacts';artifacts.mkdir()
   argv=[str(runner),str(fixtures),'7','10',name,str(artifacts),'--native-mode','size-optimized','--regalloc','backtracking','--gc-initial-mib',str(capacity)]
   row=dict(round=index,capacity_mib=capacity,file=name,command=argv,load_before=Path('/proc/loadavg').read_text().strip());r['rows'].append(row);save();print(index,capacity,name,'started',flush=True)
   with (directory/'stdout').open('xb') as stdout,(directory/'stderr').open('xb') as stderr:
    p=subprocess.Popen(argv,cwd=ROOT,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,start_new_session=True)
    try:code=p.wait(timeout=600)
    except BaseException:
     os.killpg(p.pid,signal.SIGKILL);p.wait();raise
   row.update(exit_code=code,stdout_sha256=sha(directory/'stdout'),stderr_sha256=sha(directory/'stderr'),load_after=Path('/proc/loadavg').read_text().strip());save();assert code==0,(directory/'stderr').read_text()[-2000:]
   assert (directory/'stdout').stat().st_size<32*1024**2 and (directory/'stderr').stat().st_size<4*1024**2
   d=json.loads((directory/'stdout').read_text());policy=dict(native_mode='size-optimized',gc_initial_mib=capacity,register_allocation='backtracking')
   assert d['schema']=='scriptw-wasmtime-policy-baseline-v1' and d['source_commit']==SOURCE and d['executable_sha256']==r['runner_sha256'] and d['samples']==7 and d['warmups']==10 and d['requested_native_policy']==policy
   assert len(d['cases'])==1;c=d['cases'][0];assert c['file']==name and c['source_sha256']==inputs[name] and sha(artifacts/(name+'.wasm'))==c['wasm_sha256'];obs=c['observations'];assert len(obs)==17 and [x['warmup'] for x in obs]==[True]*10+[False]*7
   for x in obs:
    assert x['stdout']==expected[name] and x['actual_native_policy']==policy and x['memory']['process_rss']['status']=='sampled'
    assert x['memory']['gc_capacity_after_bytes']>=capacity*1024**2
   measured=obs[10:];row.update(admitted=True,source_fingerprint=d['source_fingerprint'],program_wasm_sha256=c['wasm_sha256'],linked_runtime=c['linked_runtime'],execution_ns=summaries([x['execution_ns'] for x in measured]),final_rss_bytes=summaries([x['memory']['process_rss']['final_rss_bytes'] for x in measured]),maximum_sampled_rss_bytes=summaries([x['memory']['process_rss']['maximum_rss_bytes'] for x in measured]),gc_before_bytes=[x['memory']['gc_capacity_before_bytes'] for x in measured],gc_after_bytes=[x['memory']['gc_capacity_after_bytes'] for x in measured],matched_image_cache=[x['matched_runtime_image_cache'] for x in measured]);save();print(index,capacity,name,'admitted',flush=True)
 for name in cases:
  selected=[x for x in r['rows'] if x['file']==name];assert len(selected)==4 and len({x['program_wasm_sha256'] for x in selected})==1 and len({json.dumps(x['linked_runtime'],sort_keys=True) for x in selected})==1
 assert len({x['source_fingerprint'] for x in r['rows']})==1 and len(r['rows'])==12 and all(x['admitted'] for x in r['rows']);r['complete']=True
except BaseException as e:r.update(error=str(e),error_type=type(e).__name__)
finally:
 r['after']=budget();ev=[dict(x.split() for x in y['memory.events'].splitlines()) for y in [r['before'],r['after']]];assert all(ev[0][k]==ev[1][k]=='0' for k in ['oom','oom_kill','oom_group_kill']);save();print(json.dumps(dict(complete=r['complete'],error=r.get('error'),admitted=sum(bool(x.get('admitted')) for x in r['rows']))),flush=True)
raise SystemExit(0 if r['complete'] else 1)
