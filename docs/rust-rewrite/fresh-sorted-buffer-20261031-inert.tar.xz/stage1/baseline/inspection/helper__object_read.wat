  (func $helper::object_read (;1015;) (type 300) (param i32 i64 eqref i32 i64 eqref i32 i64 eqref (ref null 120) (ref 109)) (result i32 i64 eqref i32 i32)
    (local (ref null 120) (ref null 130) i32 i64 eqref i32 i32 i32 i64 eqref i32 i64 eqref i32 i64 eqref (ref null 120) (ref null 109) (ref null 109) i32 i64 eqref i32 i32 i32 i64 eqref i32 i64 eqref i32 i32 i32 i32 (ref null 131) (ref null 132) (ref null 131) i32 i64 eqref (ref null 131) (ref null 131) i32 i32 (ref null 133) (ref null 133) (ref null 137) (ref null 137) i32 i32 i32 i32 i64 i64 (ref null 161) (ref null 112) eqref (ref null 62) (ref null 120) (ref null 161) eqref (ref null 163) (ref null 220) i64 eqref i64 eqref i64 eqref (ref null 112) i32 i64 eqref (ref null 62) (ref null 62) (ref null 99) (ref null 70) (ref null 69) (ref null 70) i32 i32 (ref null 61) (ref null 139) i32 (ref null 139) (ref null 93) (ref null 94) (ref null 95) i64 (ref null 92) (ref null 70) i32 i32 i64 i32 i64 (ref null 94) (ref null 95) (ref null 97) (ref null 96) i32 eqref (ref null 70) (ref null 269) (ref null 107) (ref null 107) (ref null 130) (ref null 105) (ref null 167) (ref null 106) (ref null 40) (ref null 59) (ref null 110) (ref null 107) eqref eqref i64 eqref i64 eqref i32 i32 i32 i32 i32 i32 i64 eqref (ref null 76) (ref null 77) i32 (ref null 80) (ref null 83) i32 i32 i64 eqref i32 i32 i32 i32 i32 i32 i64 i64 (ref null 79) (ref null 78) (ref null 84) (ref null 85) (ref null 86) (ref null 85) (ref null 86) (ref null 74) (ref null 74) (ref null 69) (ref null 139) (ref null 60))
    ref.null 120
    local.set 11
    ref.null 130
    local.set 12
    i32.const 0
    local.set 13
    i64.const 0
    local.set 14
    ref.null eq
    local.set 15
    i32.const 0
    local.set 16
    i32.const 0
    local.set 17
    local.get 0
    local.set 18
    local.get 1
    local.set 19
    local.get 2
    local.set 20
    local.get 3
    local.set 21
    local.get 4
    local.set 22
    local.get 5
    local.set 23
    local.get 6
    local.set 24
    local.get 7
    local.set 25
    local.get 8
    local.set 26
    local.get 9
    local.set 27
    local.get 10
    local.set 28
    local.get 28
    ref.as_non_null
    local.set 29
    local.get 27
    local.set 11
    block ;; label = @1
      i32.const 0
      local.set 43
      local.get 18
      i32.const 4
      i32.eq
      if ;; label = @2
        i32.const 0
        local.set 44
        local.get 24
        i32.const 4
        i32.eq
        if ;; label = @3
          local.get 26
          ref.cast (ref 131)
          local.set 45
          local.get 45
          ref.as_non_null
          struct.get 131 0
          local.set 46
          local.get 46
          ref.as_non_null
          array.len
          i32.const 6
          i32.eq
          if ;; label = @4
            i32.const 140
            local.set 48
            local.get 48
            call $helper::pooled_string_resolve
            local.set 47
            i32.const 4
            local.set 48
            i64.const 0
            local.set 49
            local.get 47
            ref.as_non_null
            local.set 50
            local.get 24
            local.get 48
            i32.eq
            if (result i32) ;; label = @5
              local.get 24
              i32.const 3
              i32.eq
              if (result i32) ;; label = @6
                local.get 25
                local.get 49
                i64.eq
                local.get 25
                f64.reinterpret_i64
                local.get 25
                f64.reinterpret_i64
                f64.ne
                local.get 49
                f64.reinterpret_i64
                local.get 49
                f64.reinterpret_i64
                f64.ne
                i32.and
                i32.or
              else
                local.get 24
                i32.const 4
                i32.eq
                if (result i32) ;; label = @7
                  local.get 26
                  local.get 50
                  ref.eq
                  if (result i32) ;; label = @8
                    i32.const 1
                  else
                    local.get 26
                    ref.cast (ref 131)
                    local.set 51
                    local.get 50
                    ref.cast (ref 131)
                    local.set 52
                    i32.const 0
                    local.set 53
                    local.get 51
                    ref.as_non_null
                    local.get 52
                    ref.as_non_null
                    local.get 53
                    call $helper::string_equality
                    local.set 54
                    local.get 54
                    ref.null 131
                    local.set 52
                    ref.null 131
                    local.set 51
                  end
                else
                  local.get 24
                  i32.const 10
                  i32.eq
                  if (result i32) ;; label = @8
                    local.get 26
                    ref.cast (ref 133)
                    local.set 55
                    local.get 50
                    ref.cast (ref 133)
                    local.set 56
                    local.get 55
                    ref.as_non_null
                    struct.get 133 0
                    local.set 54
                    local.get 56
                    ref.as_non_null
                    struct.get 133 0
                    local.set 53
                    local.get 55
                    ref.as_non_null
                    struct.get 133 1
                    local.set 57
                    local.get 56
                    ref.as_non_null
                    struct.get 133 1
                    local.set 58
                    local.get 57
                    ref.as_non_null
                    array.len
                    local.set 59
                    local.get 58
                    ref.as_non_null
                    array.len
                    local.set 60
                    local.get 54
                    local.get 53
                    i32.eq
                    local.get 59
                    local.get 60
                    i32.eq
                    i32.and
                    local.set 62
                    local.get 62
                    if ;; label = @9
                      i32.const 0
                      local.set 61
                      block ;; label = @10
                        loop ;; label = @11
                          local.get 61
                          local.get 59
                          i32.ge_u
                          br_if 1 (;@10;)
                          local.get 57
                          ref.as_non_null
                          local.get 61
                          array.get 137
                          local.set 63
                          local.get 58
                          ref.as_non_null
                          local.get 61
                          array.get 137
                          local.set 64
                          local.get 63
                          local.get 64
                          i64.eq
                          local.set 62
                          local.get 62
                          i32.eqz
                          br_if 1 (;@10;)
                          local.get 61
                          i32.const 1
                          i32.add
                          local.set 61
                          br 0 (;@11;)
                        end
                      end
                    end
                    local.get 62
                    ref.null 137
                    local.set 58
                    ref.null 137
                    local.set 57
                    ref.null 133
                    local.set 56
                    ref.null 133
                    local.set 55
                  else
                    local.get 24
                    i32.const 0
                    i32.eq
                    local.get 24
                    i32.const 1
                    i32.eq
                    i32.or
                    if (result i32) ;; label = @9
                      i32.const 1
                    else
                      local.get 24
                      i32.const 2
                      i32.eq
                      if (result i32) ;; label = @10
                        local.get 25
                        local.get 49
                        i64.eq
                      else
                        local.get 26
                        local.get 50
                        ref.eq
                      end
                    end
                  end
                end
              end
            else
              i32.const 0
            end
            local.set 44
            ref.null eq
            local.set 50
            ref.null 131
            local.set 47
          end
          ref.null 132
          local.set 46
          ref.null 131
          local.set 45
        end
        local.get 44
        if ;; label = @3
          local.get 20
          ref.cast (ref 131)
          local.set 51
          local.get 51
          ref.as_non_null
          struct.get 131 0
          local.set 46
          local.get 46
          ref.as_non_null
          array.len
          i64.extend_i32_u
          local.set 64
          ref.null 132
          local.set 46
          local.get 64
          f64.convert_i64_u
          i64.reinterpret_f64
          local.set 64
          i32.const 3
          local.set 62
          local.get 64
          local.set 63
          ref.null eq
          local.set 50
          local.get 62
          local.set 30
          local.get 63
          local.set 31
          local.get 50
          local.set 32
          i32.const 0
          local.set 33
          i32.const 0
          local.set 34
          i32.const 1
          local.set 43
          ref.null eq
          local.set 50
          ref.null 131
          local.set 51
        end
      end
      local.get 43
      br_if 0 (;@1;)
      global.get 8
      ref.as_non_null
      local.set 65
      local.get 65
      ref.as_non_null
      local.get 18
      local.get 19
      local.get 20
      call $helper::value_to_object
      local.set 42
      local.set 41
      local.set 40
      local.set 39
      local.set 38
      ref.null 161
      local.set 65
      local.get 41
      i32.const 1
      i32.eq
      if ;; label = @2
        local.get 38
        local.set 30
        local.get 39
        local.set 31
        local.get 40
        local.set 32
        local.get 41
        local.set 33
        local.get 42
        local.set 34
        br 1 (;@1;)
      end
      local.get 38
      local.set 35
      local.get 39
      local.set 36
      local.get 40
      local.set 37
      local.get 37
      ref.test (ref 112)
      if ;; label = @2
        local.get 37
        ref.cast (ref 112)
        local.set 66
        local.get 66
        ref.as_non_null
        struct.get 112 1
        local.set 68
        local.get 68
        ref.as_non_null
        struct.get 62 1
        local.set 48
        local.get 68
        ref.as_non_null
        struct.get 62 0
        local.set 49
        local.get 68
        ref.as_non_null
        struct.get 62 2
        local.set 50
        ref.null 62
        local.set 68
        local.get 66
        ref.as_non_null
        struct.get 112 2
        local.set 68
        local.get 68
        ref.as_non_null
        struct.get 62 1
        local.set 61
        local.get 68
        ref.as_non_null
        struct.get 62 0
        local.set 64
        local.get 68
        ref.as_non_null
        struct.get 62 2
        local.set 67
        ref.null 62
        local.set 68
        i32.const 0
        local.set 30
        i64.const 0
        local.set 31
        ref.null eq
        local.set 32
        i32.const 0
        local.set 33
        i32.const 0
        local.set 34
        local.get 61
        i32.const 1
        i32.eq
        if ;; label = @3
          local.get 11
          local.set 69
          ref.null 161
          local.set 65
          block ;; label = @4
            loop ;; label = @5
              local.get 69
              ref.is_null
              br_if 1 (;@4;)
              local.get 69
              struct.get 120 0
              local.set 65
              local.get 65
              ref.is_null
              i32.eqz
              br_if 1 (;@4;)
              local.get 69
              struct.get 120 3
              local.set 69
              br 0 (;@5;)
            end
          end
          local.get 65
          ref.is_null
          if ;; label = @4
            global.get 8
            ref.as_non_null
            local.set 70
            local.get 70
            ref.as_non_null
            local.set 65
            ref.null 161
            local.set 70
          end
          local.get 65
          ref.as_non_null
          local.set 70
          ref.null 161
          local.set 65
          ref.null 120
          local.set 69
          local.get 70
          ref.as_non_null
          call $helper::realm_ensure_errors
          local.get 70
          ref.as_non_null
          struct.get 161 5
          local.set 72
          i32.const 3
          local.set 60
          local.get 72
          ref.as_non_null
          local.get 60
          array.get 163
          local.set 68
          ref.null 163
          local.set 72
          local.get 68
          ref.as_non_null
          struct.get 62 1
          local.set 62
          local.get 68
          ref.as_non_null
          struct.get 62 0
          local.set 63
          local.get 68
          ref.as_non_null
          struct.get 62 2
          local.set 71
          i32.const 0
          local.get 62
          i32.const 6
          i32.eq
          i32.or
          local.get 62
          i32.const 7
          i32.eq
          i32.or
          local.get 62
          i32.const 8
          i32.eq
          i32.or
          local.get 62
          i32.const 9
          i32.eq
          i32.or
          i32.eqz
          if ;; label = @4
            unreachable
          end
          ref.null 62
          local.set 68
          i32.const 2470
          local.set 59
          local.get 59
          call $helper::pooled_string_resolve
          local.set 45
          i32.const 5
          local.get 62
          local.get 63
          local.get 71
          local.get 45
          ref.as_non_null
          call $helper::runtime_error_for_throw
          local.set 73
          i32.const 6
          local.set 53
          i64.const 0
          local.set 74
          local.get 73
          ref.as_non_null
          local.set 75
          local.get 53
          local.set 30
          local.get 74
          local.set 31
          local.get 75
          local.set 32
          i32.const 1
          local.set 33
          i32.const 0
          local.set 34
          ref.null eq
          local.set 75
          ref.null 220
          local.set 73
          ref.null 131
          local.set 45
          ref.null eq
          local.set 71
          ref.null 161
          local.set 70
        else
          block ;; label = @4
            i32.const 635
            local.set 60
            local.get 60
            call $helper::pooled_string_resolve
            local.set 52
            i32.const 4
            local.set 60
            i64.const 0
            local.set 78
            local.get 52
            ref.as_non_null
            local.set 79
            ref.null 131
            local.set 52
            local.get 61
            local.get 64
            local.get 67
            local.get 61
            local.get 64
            local.get 67
            local.get 60
            local.get 78
            local.get 79
            local.get 11
            local.get 29
            ref.as_non_null
            call $helper::object_read
            local.set 62
            local.set 53
            local.set 77
            local.set 76
            local.set 44
            ref.null eq
            local.set 79
            local.get 53
            i32.const 1
            i32.eq
            if ;; label = @5
              local.get 44
              local.set 30
              local.get 76
              local.set 31
              local.get 77
              local.set 32
              local.get 53
              local.set 33
              local.get 62
              local.set 34
              br 1 (;@4;)
            end
            local.get 44
            local.set 59
            local.get 76
            local.set 74
            local.get 77
            local.set 75
            local.get 59
            i32.const 0
            i32.eq
            local.get 59
            i32.const 1
            i32.eq
            i32.or
            if ;; label = @5
              local.get 48
              local.get 49
              local.get 50
              local.get 21
              local.get 22
              local.get 23
              local.get 24
              local.get 25
              local.get 26
              local.get 11
              local.get 29
              ref.as_non_null
              call $helper::object_read
              local.set 34
              local.set 33
              local.set 32
              local.set 31
              local.set 30
              br 1 (;@4;)
            end
            local.get 75
            ref.test (ref 107)
            local.get 75
            ref.test (ref 111)
            i32.or
            if (result i32) ;; label = @5
              i32.const 1
            else
              local.get 75
              ref.test (ref 112)
              if (result i32) ;; label = @6
                local.get 75
                ref.cast (ref 112)
                local.set 80
                local.get 80
                ref.as_non_null
                struct.get 112 3
                local.set 60
                local.get 60
                i32.const 0
                i32.ne
                ref.null 112
                local.set 80
              else
                i32.const 0
              end
            end
            i32.eqz
            if ;; label = @5
              local.get 11
              local.set 69
              ref.null 161
              local.set 65
              block ;; label = @6
                loop ;; label = @7
                  local.get 69
                  ref.is_null
                  br_if 1 (;@6;)
                  local.get 69
                  struct.get 120 0
                  local.set 65
                  local.get 65
                  ref.is_null
                  i32.eqz
                  br_if 1 (;@6;)
                  local.get 69
                  struct.get 120 3
                  local.set 69
                  br 0 (;@7;)
                end
              end
              local.get 65
              ref.is_null
              if ;; label = @6
                global.get 8
                ref.as_non_null
                local.set 70
                local.get 70
                ref.as_non_null
                local.set 65
                ref.null 161
                local.set 70
              end
              local.get 65
              ref.as_non_null
              local.set 70
              ref.null 161
              local.set 65
              ref.null 120
              local.set 69
              local.get 70
              ref.as_non_null
              call $helper::realm_ensure_errors
              local.get 70
              ref.as_non_null
              struct.get 161 5
              local.set 72
              i32.const 3
              local.set 81
              local.get 72
              ref.as_non_null
              local.get 81
              array.get 163
              local.set 68
              ref.null 163
              local.set 72
              local.get 68
              ref.as_non_null
              struct.get 62 1
              local.set 60
              local.get 68
              ref.as_non_null
              struct.get 62 0
              local.set 78
              local.get 68
              ref.as_non_null
              struct.get 62 2
              local.set 79
              i32.const 0
              local.get 60
              i32.const 6
              i32.eq
              i32.or
              local.get 60
              i32.const 7
              i32.eq
              i32.or
              local.get 60
              i32.const 8
              i32.eq
              i32.or
              local.get 60
              i32.const 9
              i32.eq
              i32.or
              i32.eqz
              if ;; label = @6
                unreachable
              end
              ref.null 62
              local.set 68
              i32.const 2455
              local.set 81
              local.get 81
              call $helper::pooled_string_resolve
              local.set 45
              i32.const 5
              local.get 60
              local.get 78
              local.get 79
              local.get 45
              ref.as_non_null
              call $helper::runtime_error_for_throw
              local.set 73
              i32.const 6
              local.set 81
              i64.const 0
              local.set 82
              local.get 73
              ref.as_non_null
              local.set 83
              local.get 81
              local.set 30
              local.get 82
              local.set 31
              local.get 83
              local.set 32
              i32.const 1
              local.set 33
              i32.const 0
              local.set 34
              ref.null eq
              local.set 83
              ref.null 220
              local.set 73
              ref.null 131
              local.set 45
              ref.null eq
              local.set 79
              ref.null 161
              local.set 70
              br 1 (;@4;)
            end
            local.get 49
            local.get 48
            local.get 50
            struct.new 62
            local.set 68
            local.get 25
            local.get 24
            local.get 26
            struct.new 62
            local.set 84
            local.get 22
            local.get 21
            local.get 23
            struct.new 62
            local.set 85
            local.get 68
            ref.as_non_null
            local.get 84
            ref.as_non_null
            local.get 85
            ref.as_non_null
            array.new_fixed 99 3
            local.set 86
            ref.null 62
            local.set 85
            ref.null 62
            local.set 84
            ref.null 62
            local.set 68
            i32.const 0
            local.set 81
            i64.const 0
            local.set 82
            ref.null eq
            local.set 83
            global.get 8
            ref.as_non_null
            local.set 70
            local.get 59
            local.get 74
            local.get 75
            local.get 61
            local.get 64
            local.get 67
            local.get 86
            ref.as_non_null
            local.get 70
            ref.as_non_null
            local.get 11
            local.get 29
            ref.as_non_null
            call $helper::proxy_call
            local.set 62
            local.set 53
            local.set 77
            local.set 76
            local.set 44
            local.get 70
            ref.as_non_null
            global.set 8
            ref.null 161
            local.set 70
            local.get 53
            i32.const 2
            i32.eq
            if ;; label = @5
              local.get 44
              local.set 44
              local.get 76
              local.set 76
              local.get 77
              local.set 77
              i32.const 0
              local.set 53
              i32.const 0
              local.set 62
            end
            ref.null eq
            local.set 83
            ref.null 99
            local.set 86
            local.get 53
            i32.const 1
            i32.eq
            if ;; label = @5
              local.get 44
              local.set 30
              local.get 76
              local.set 31
              local.get 77
              local.set 32
              local.get 53
              local.set 33
              local.get 62
              local.set 34
              br 1 (;@4;)
            end
            local.get 44
            local.set 54
            local.get 76
            local.set 63
            local.get 77
            local.set 71
            ref.null 70
            local.set 87
            local.get 50
            ref.test (ref 69)
            if ;; label = @5
              local.get 50
              ref.cast (ref 69)
              local.set 88
              local.get 88
              ref.as_non_null
              local.get 24
              local.get 25
              local.get 26
              call $helper::ordinary_own_descriptor
              local.set 89
              local.get 89
              ref.is_null
              i32.eqz
              if ;; label = @6
                local.get 89
                ref.is_null
                i32.eqz
                if (result i32) ;; label = @7
                  local.get 89
                  struct.get 70 0
                  local.set 91
                  local.get 91
                  i32.const 4
                  i32.and
                  i32.eqz
                  i32.eqz
                else
                  i32.const 0
                end
                local.set 60
                local.get 89
                ref.is_null
                i32.eqz
                if (result i32) ;; label = @7
                  local.get 89
                  struct.get 70 0
                  local.set 91
                  local.get 91
                  i32.const 8
                  i32.and
                  i32.eqz
                  i32.eqz
                else
                  i32.const 0
                end
                local.set 81
                local.get 89
                ref.is_null
                i32.eqz
                if (result i32) ;; label = @7
                  local.get 89
                  struct.get 70 0
                  local.set 91
                  local.get 91
                  i32.const 2
                  i32.and
                  i32.eqz
                  i32.eqz
                else
                  i32.const 0
                end
                local.set 90
                local.get 89
                struct.get 70 1
                local.set 92
                local.get 89
                struct.get 70 2
                local.set 85
                local.get 89
                struct.get 70 3
                local.set 84
                local.get 89
                ref.is_null
                i32.eqz
                if (result i32) ;; label = @7
                  local.get 89
                  struct.get 70 0
                  local.set 91
                  local.get 91
                  i32.const 1
                  i32.and
                  i32.eqz
                  i32.eqz
                else
                  i32.const 0
                end
                if ;; label = @7
                  i32.const 1
                  local.get 81
                  i32.eqz
                  i32.eqz
                  i32.const 8
                  i32.mul
                  i32.or
                  local.get 90
                  i32.eqz
                  i32.eqz
                  i32.const 2
                  i32.mul
                  i32.or
                  local.get 92
                  ref.as_non_null
                  local.get 85
                  ref.as_non_null
                  local.get 84
                  ref.as_non_null
                  struct.new 70
                  local.set 87
                else
                  i32.const 0
                  local.get 60
                  i32.eqz
                  i32.eqz
                  i32.const 4
                  i32.mul
                  i32.or
                  local.get 81
                  i32.eqz
                  i32.eqz
                  i32.const 8
                  i32.mul
                  i32.or
                  local.get 90
                  i32.eqz
                  i32.eqz
                  i32.const 2
                  i32.mul
                  i32.or
                  local.get 92
                  ref.as_non_null
                  local.get 85
                  ref.as_non_null
                  local.get 84
                  ref.as_non_null
                  struct.new 70
                  local.set 87
                end
                ref.null 62
                local.set 84
                ref.null 62
                local.set 85
                ref.null 61
                local.set 92
              end
              ref.null 70
              local.set 89
              ref.null 69
              local.set 88
            else
              local.get 50
              ref.test (ref 139)
              if ;; label = @6
                local.get 50
                ref.cast (ref 139)
                local.set 93
                local.get 93
                ref.as_non_null
                struct.get 139 0
                local.set 88
                local.get 88
                ref.as_non_null
                local.get 24
                local.get 25
                local.get 26
                call $helper::ordinary_own_descriptor
                local.set 89
                local.get 89
                ref.is_null
                if ;; label = @7
                  i32.const 0
                  local.set 60
                  local.get 24
                  i32.const 4
                  i32.eq
                  if ;; label = @8
                    local.get 26
                    ref.cast (ref 131)
                    local.set 47
                    local.get 47
                    ref.as_non_null
                    struct.get 131 0
                    local.set 46
                    local.get 46
                    ref.as_non_null
                    array.len
                    local.set 90
                    block ;; label = @9
                      local.get 90
                      i32.eqz
                      local.get 90
                      i32.const 10
                      i32.gt_u
                      i32.or
                      br_if 0 (;@9;)
                      i32.const 0
                      local.set 81
                      local.get 46
                      ref.as_non_null
                      local.get 81
                      array.get_u 132
                      local.set 94
                      local.get 94
                      i32.const 48
                      i32.eq
                      if ;; label = @10
                        i32.const 0
                        local.set 91
                        local.get 90
                        i32.const 1
                        i32.eq
                        local.set 60
                        br 1 (;@9;)
                      end
                      i64.const 0
                      local.set 82
                      loop ;; label = @10
                        local.get 46
                        ref.as_non_null
                        local.get 81
                        array.get_u 132
                        local.set 94
                        local.get 94
                        i32.const 48
                        i32.sub
                        local.set 94
                        local.get 94
                        i32.const 9
                        i32.gt_u
                        br_if 1 (;@9;)
                        local.get 82
                        i64.const 10
                        i64.mul
                        local.get 94
                        i64.extend_i32_u
                        i64.add
                        local.set 82
                        local.get 81
                        i32.const 1
                        i32.add
                        local.set 81
                        local.get 81
                        local.get 90
                        i32.lt_u
                        br_if 0 (;@10;)
                      end
                      local.get 82
                      i64.const 4294967295
                      i64.lt_u
                      if ;; label = @10
                        local.get 82
                        i32.wrap_i64
                        local.set 91
                        i32.const 1
                        local.set 60
                      end
                    end
                    ref.null 132
                    local.set 46
                    ref.null 131
                    local.set 47
                  end
                  local.get 60
                  if ;; label = @8
                    local.get 91
                    i64.extend_i32_u
                    local.set 78
                    local.get 93
                    ref.as_non_null
                    local.set 95
                    local.get 95
                    ref.as_non_null
                    struct.get 139 6
                    i32.const 2
                    i32.eq
                    local.get 95
                    ref.as_non_null
                    struct.get 139 6
                    i32.const 3
                    i32.eq
                    i32.or
                    if ;; label = @9
                      i32.const 0
                      local.set 94
                      local.get 95
                      ref.as_non_null
                      struct.get 139 6
                      i32.const 3
                      i32.eq
                      if ;; label = @10
                        local.get 95
                        ref.as_non_null
                        struct.get 139 9
                        ref.as_non_null
                        local.set 96
                        local.get 78
                        local.get 96
                        ref.as_non_null
                        array.len
                        i64.extend_i32_u
                        i64.lt_u
                        if ;; label = @11
                          local.get 78
                          i32.wrap_i64
                          local.set 81
                          local.get 96
                          ref.as_non_null
                          local.get 81
                          array.get 93
                          local.set 85
                          local.get 85
                          ref.is_null
                          i32.eqz
                          if ;; label = @12
                            i32.const 1
                            local.set 94
                          end
                          ref.null 62
                          local.set 85
                        end
                        ref.null 93
                        local.set 96
                      else
                        local.get 95
                        ref.as_non_null
                        struct.get 139 7
                        local.set 97
                        local.get 95
                        ref.as_non_null
                        struct.get 139 8
                        local.set 98
                        local.get 78
                        local.get 97
                        ref.as_non_null
                        array.len
                        i64.extend_i32_u
                        i64.lt_u
                        if ;; label = @11
                          local.get 78
                          i32.wrap_i64
                          local.set 90
                          local.get 90
                          i32.const 6
                          i32.shr_u
                          local.set 81
                          i64.const 1
                          local.get 90
                          i64.extend_i32_u
                          i64.shl
                          local.set 82
                          local.get 98
                          ref.as_non_null
                          local.get 81
                          array.get 95
                          local.set 99
                          local.get 99
                          local.get 82
                          i64.and
                          i64.eqz
                          i32.eqz
                          if ;; label = @12
                            i32.const 1
                            local.set 94
                          end
                        end
                        ref.null 95
                        local.set 98
                        ref.null 94
                        local.set 97
                      end
                      local.get 94
                      if ;; label = @10
                        local.get 95
                        ref.as_non_null
                        struct.get 139 6
                        i32.const 3
                        i32.eq
                        if ;; label = @11
                          local.get 95
                          ref.as_non_null
                          struct.get 139 9
                          ref.as_non_null
                          local.set 96
                          local.get 96
                          ref.as_non_null
                          array.len
                          local.set 81
                          ref.null 70
                          local.get 81
                          array.new 92
                          local.set 100
                          i32.const 0
                          local.set 90
                          global.get 30
                          local.set 84
                          block ;; label = @12
                            loop ;; label = @13
                              local.get 90
                              local.get 81
                              i32.ge_u
                              br_if 1 (;@12;)
                              local.get 96
                              ref.as_non_null
                              local.get 90
                              array.get 93
                              local.set 68
                              local.get 68
                              ref.is_null
                              i32.eqz
                              if ;; label = @14
                                local.get 68
                                ref.as_non_null
                                local.set 85
                                i32.const 14
                                local.get 85
                                ref.as_non_null
                                local.get 84
                                ref.as_non_null
                                local.get 84
                                ref.as_non_null
                                struct.new 70
                                local.set 101
                                ref.null 62
                                local.set 85
                                local.get 100
                                ref.as_non_null
                                local.get 90
                                local.get 101
                                ref.as_non_null
                                array.set 92
                                ref.null 70
                                local.set 101
                              end
                              ref.null 62
                              local.set 68
                              local.get 90
                              i32.const 1
                              i32.add
                              local.set 90
                              br 0 (;@13;)
                            end
                          end
                          local.get 95
                          ref.as_non_null
                          local.get 100
                          ref.as_non_null
                          struct.set 139 5
                          global.get 28
                          local.set 97
                          global.get 29
                          local.set 98
                          local.get 95
                          ref.as_non_null
                          local.get 97
                          ref.as_non_null
                          struct.set 139 7
                          local.get 95
                          ref.as_non_null
                          local.get 98
                          ref.as_non_null
                          struct.set 139 8
                          local.get 95
                          ref.as_non_null
                          ref.null 93
                          struct.set 139 9
                          ref.null 95
                          local.set 98
                          ref.null 94
                          local.set 97
                          local.get 95
                          ref.as_non_null
                          i32.const 0
                          struct.set 139 6
                          ref.null 62
                          local.set 84
                          ref.null 92
                          local.set 100
                          ref.null 93
                          local.set 96
                        else
                          local.get 95
                          ref.as_non_null
                          struct.get 139 6
                          i32.const 2
                          i32.eq
                          if ;; label = @12
                            local.get 95
                            ref.as_non_null
                            struct.get 139 7
                            local.set 97
                            local.get 95
                            ref.as_non_null
                            struct.get 139 8
                            local.set 98
                            local.get 97
                            ref.as_non_null
                            array.len
                            local.set 90
                            ref.null 70
                            local.get 90
                            array.new 92
                            local.set 100
                            i32.const 0
                            local.set 81
                            i32.const 0
                            local.set 105
                            i64.const 0
                            local.set 106
                            ref.null eq
                            local.set 79
                            block ;; label = @13
                              loop ;; label = @14
                                local.get 81
                                local.get 90
                                i32.ge_u
                                br_if 1 (;@13;)
                                local.get 81
                                i32.const 6
                                i32.shr_u
                                local.set 102
                                i64.const 1
                                local.get 81
                                i64.extend_i32_u
                                i64.shl
                                local.set 82
                                local.get 98
                                ref.as_non_null
                                local.get 102
                                array.get 95
                                local.set 99
                                local.get 99
                                local.get 82
                                i64.and
                                i64.eqz
                                i32.eqz
                                if ;; label = @15
                                  local.get 97
                                  ref.as_non_null
                                  local.get 81
                                  array.get 94
                                  local.set 99
                                  i32.const 3
                                  local.set 103
                                  local.get 99
                                  local.set 104
                                  ref.null eq
                                  local.set 83
                                  local.get 104
                                  local.get 103
                                  local.get 83
                                  struct.new 62
                                  local.set 68
                                  global.get 30
                                  local.set 84
                                  i32.const 14
                                  local.get 68
                                  ref.as_non_null
                                  local.get 84
                                  ref.as_non_null
                                  local.get 84
                                  ref.as_non_null
                                  struct.new 70
                                  local.set 101
                                  ref.null 62
                                  local.set 84
                                  ref.null 62
                                  local.set 68
                                  local.get 100
                                  ref.as_non_null
                                  local.get 81
                                  local.get 101
                                  ref.as_non_null
                                  array.set 92
                                  ref.null 70
                                  local.set 101
                                end
                                local.get 81
                                i32.const 1
                                i32.add
                                local.set 81
                                br 0 (;@14;)
                              end
                            end
                            local.get 95
                            ref.as_non_null
                            local.get 100
                            ref.as_non_null
                            struct.set 139 5
                            global.get 28
                            local.set 107
                            global.get 29
                            local.set 108
                            local.get 95
                            ref.as_non_null
                            local.get 107
                            ref.as_non_null
                            struct.set 139 7
                            local.get 95
                            ref.as_non_null
                            local.get 108
                            ref.as_non_null
                            struct.set 139 8
                            local.get 95
                            ref.as_non_null
                            ref.null 93
                            struct.set 139 9
                            ref.null 95
                            local.set 108
                            ref.null 94
                            local.set 107
                            local.get 95
                            ref.as_non_null
                            i32.const 0
                            struct.set 139 6
                            ref.null eq
                            local.set 79
                            ref.null eq
                            local.set 83
                            ref.null 92
                            local.set 100
                            ref.null 95
                            local.set 98
                            ref.null 94
                            local.set 97
                          end
                        end
                      end
                    end
                    local.get 95
                    ref.as_non_null
                    struct.get 139 4
                    local.set 109
                    local.get 109
                    ref.as_non_null
                    array.len
                    local.set 105
                    ref.null 70
                    local.set 101
                    local.get 95
                    ref.as_non_null
                    struct.get 139 6
                    i32.const 0
                    i32.eq
                    if ;; label = @9
                      local.get 95
                      ref.as_non_null
                      struct.get 139 5
                      local.set 100
                      local.get 78
                      local.get 100
                      ref.as_non_null
                      array.len
                      i64.extend_i32_u
                      i64.lt_u
                      if ;; label = @10
                        local.get 78
                        i32.wrap_i64
                        local.set 94
                        local.get 100
                        ref.as_non_null
                        local.get 94
                        array.get 92
                        local.set 101
                      end
                      ref.null 92
                      local.set 100
                    else
                      local.get 105
                      if ;; label = @10
                        local.get 78
                        i32.wrap_i64
                        local.set 103
                        local.get 103
                        local.get 103
                        i32.const 16
                        i32.shr_u
                        i32.xor
                        i32.const 2146121005
                        i32.mul
                        local.set 103
                        local.get 103
                        local.get 103
                        i32.const 15
                        i32.shr_u
                        i32.xor
                        i32.const -2073254261
                        i32.mul
                        local.set 103
                        local.get 103
                        local.get 103
                        i32.const 16
                        i32.shr_u
                        i32.xor
                        local.get 105
                        i32.const 1
                        i32.sub
                        i32.and
                        local.set 103
                        local.get 109
                        ref.as_non_null
                        local.get 103
                        array.get 97
                        local.set 110
                        block ;; label = @11
                          loop ;; label = @12
                            local.get 110
                            ref.is_null
                            br_if 1 (;@11;)
                            local.get 110
                            struct.get 96 0
                            local.set 106
                            local.get 106
                            local.get 78
                            i64.eq
                            if ;; label = @13
                              local.get 110
                              struct.get 96 1
                              local.set 101
                              br 2 (;@11;)
                            end
                            local.get 110
                            struct.get 96 2
                            local.set 110
                            br 0 (;@12;)
                          end
                        end
                        ref.null 96
                        local.set 110
                      end
                    end
                    ref.null 97
                    local.set 109
                    ref.null 139
                    local.set 95
                    local.get 101
                    local.set 89
                    ref.null 70
                    local.set 101
                  else
                    i32.const 140
                    local.set 94
                    local.get 94
                    call $helper::pooled_string_resolve
                    local.set 51
                    i32.const 4
                    local.set 102
                    i64.const 0
                    local.set 78
                    local.get 51
                    ref.as_non_null
                    local.set 79
                    local.get 24
                    local.get 102
                    i32.eq
                    if (result i32) ;; label = @9
                      local.get 24
                      i32.const 3
                      i32.eq
                      if (result i32) ;; label = @10
                        local.get 25
                        local.get 78
                        i64.eq
                        local.get 25
                        f64.reinterpret_i64
                        local.get 25
                        f64.reinterpret_i64
                        f64.ne
                        local.get 78
                        f64.reinterpret_i64
                        local.get 78
                        f64.reinterpret_i64
                        f64.ne
                        i32.and
                        i32.or
                      else
                        local.get 24
                        i32.const 4
                        i32.eq
                        if (result i32) ;; label = @11
                          local.get 26
                          local.get 79
                          ref.eq
                          if (result i32) ;; label = @12
                            i32.const 1
                          else
                            local.get 26
                            ref.cast (ref 131)
                            local.set 52
                            local.get 79
                            ref.cast (ref 131)
                            local.set 47
                            i32.const 0
                            local.set 105
                            local.get 52
                            ref.as_non_null
                            local.get 47
                            ref.as_non_null
                            local.get 105
                            call $helper::string_equality
                            local.set 103
                            local.get 103
                            ref.null 131
                            local.set 47
                            ref.null 131
                            local.set 52
                          end
                        else
                          local.get 24
                          i32.const 10
                          i32.eq
                          if (result i32) ;; label = @12
                            local.get 26
                            ref.cast (ref 133)
                            local.set 55
                            local.get 79
                            ref.cast (ref 133)
                            local.set 56
                            local.get 55
                            ref.as_non_null
                            struct.get 133 0
                            local.set 94
                            local.get 56
                            ref.as_non_null
                            struct.get 133 0
                            local.set 105
                            local.get 55
                            ref.as_non_null
                            struct.get 133 1
                            local.set 58
                            local.get 56
                            ref.as_non_null
                            struct.get 133 1
                            local.set 57
                            local.get 58
                            ref.as_non_null
                            array.len
                            local.set 90
                            local.get 57
                            ref.as_non_null
                            array.len
                            local.set 103
                            local.get 94
                            local.get 105
                            i32.eq
                            local.get 90
                            local.get 103
                            i32.eq
                            i32.and
                            local.set 111
                            local.get 111
                            if ;; label = @13
                              i32.const 0
                              local.set 81
                              block ;; label = @14
                                loop ;; label = @15
                                  local.get 81
                                  local.get 90
                                  i32.ge_u
                                  br_if 1 (;@14;)
                                  local.get 58
                                  ref.as_non_null
                                  local.get 81
                                  array.get 137
                                  local.set 82
                                  local.get 57
                                  ref.as_non_null
                                  local.get 81
                                  array.get 137
                                  local.set 99
                                  local.get 82
                                  local.get 99
                                  i64.eq
                                  local.set 111
                                  local.get 111
                                  i32.eqz
                                  br_if 1 (;@14;)
                                  local.get 81
                                  i32.const 1
                                  i32.add
                                  local.set 81
                                  br 0 (;@15;)
                                end
                              end
                            end
                            local.get 111
                            ref.null 137
                            local.set 57
                            ref.null 137
                            local.set 58
                            ref.null 133
                            local.set 56
                            ref.null 133
                            local.set 55
                          else
                            local.get 24
                            i32.const 0
                            i32.eq
                            local.get 24
                            i32.const 1
                            i32.eq
                            i32.or
                            if (result i32) ;; label = @13
                              i32.const 1
                            else
                              local.get 24
                              i32.const 2
                              i32.eq
                              if (result i32) ;; label = @14
                                local.get 25
                                local.get 78
                                i64.eq
                              else
                                local.get 26
                                local.get 79
                                ref.eq
                              end
                            end
                          end
                        end
                      end
                    else
                      i32.const 0
                    end
                    if ;; label = @9
                      local.get 93
                      ref.as_non_null
                      struct.get 139 2
                      local.set 104
                      local.get 104
                      f64.convert_i64_u
                      i64.reinterpret_f64
                      local.set 104
                      i32.const 3
                      local.set 111
                      local.get 104
                      local.set 104
                      ref.null eq
                      local.set 83
                      local.get 93
                      ref.as_non_null
                      struct.get 139 1
                      local.set 105
                      i32.const 0
                      local.set 90
                      i32.const 0
                      local.set 94
                      i64.const 0
                      local.set 106
                      ref.null eq
                      local.set 112
                      local.get 104
                      local.get 111
                      local.get 83
                      struct.new 62
                      local.set 85
                      global.get 30
                      local.set 84
                      i32.const 4
                      local.get 85
                      ref.as_non_null
                      local.get 84
                      ref.as_non_null
                      local.get 84
                      ref.as_non_null
                      struct.new 70
                      local.set 113
                      ref.null 62
                      local.set 84
                      ref.null 62
                      local.set 85
                      local.get 113
                      ref.as_non_null
                      i32.const 0
                      local.get 105
                      i32.eqz
                      i32.eqz
                      i32.const 4
                      i32.mul
                      i32.or
                      local.get 90
                      i32.eqz
                      i32.eqz
                      i32.const 8
                      i32.mul
                      i32.or
                      local.get 90
                      i32.eqz
                      i32.eqz
                      i32.const 2
                      i32.mul
                      i32.or
                      struct.set 70 0
                      local.get 113
                      ref.as_non_null
                      local.set 101
                      ref.null 70
                      local.set 113
                      ref.null eq
                      local.set 112
                      ref.null eq
                      local.set 83
                      local.get 101
                      ref.as_non_null
                      local.set 89
                      ref.null 70
                      local.set 101
                    end
                    ref.null eq
                    local.set 79
                    ref.null 131
                    local.set 51
                  end
                end
                ref.null 69
                local.set 88
                local.get 89
                ref.is_null
                i32.eqz
                if ;; label = @7
                  local.get 89
                  ref.is_null
                  i32.eqz
                  if (result i32) ;; label = @8
                    local.get 89
                    struct.get 70 0
                    local.set 60
                    local.get 60
                    i32.const 4
                    i32.and
                    i32.eqz
                    i32.eqz
                  else
                    i32.const 0
                  end
                  local.set 81
                  local.get 89
                  ref.is_null
                  i32.eqz
                  if (result i32) ;; label = @8
                    local.get 89
                    struct.get 70 0
                    local.set 90
                    local.get 90
                    i32.const 8
                    i32.and
                    i32.eqz
                    i32.eqz
                  else
                    i32.const 0
                  end
                  local.set 103
                  local.get 89
                  ref.is_null
                  i32.eqz
                  if (result i32) ;; label = @8
                    local.get 89
                    struct.get 70 0
                    local.set 60
                    local.get 60
                    i32.const 2
                    i32.and
                    i32.eqz
                    i32.eqz
                  else
                    i32.const 0
                  end
                  local.set 91
                  local.get 89
                  struct.get 70 1
                  local.set 92
                  local.get 89
                  struct.get 70 2
                  local.set 68
                  local.get 89
                  struct.get 70 3
                  local.set 84
                  local.get 89
                  ref.is_null
                  i32.eqz
                  if (result i32) ;; label = @8
                    local.get 89
                    struct.get 70 0
                    local.set 60
                    local.get 60
                    i32.const 1
                    i32.and
                    i32.eqz
                    i32.eqz
                  else
                    i32.const 0
                  end
                  if ;; label = @8
                    i32.const 1
                    local.get 103
                    i32.eqz
                    i32.eqz
                    i32.const 8
                    i32.mul
                    i32.or
                    local.get 91
                    i32.eqz
                    i32.eqz
                    i32.const 2
                    i32.mul
                    i32.or
                    local.get 92
                    ref.as_non_null
                    local.get 68
                    ref.as_non_null
                    local.get 84
                    ref.as_non_null
                    struct.new 70
                    local.set 87
                  else
                    i32.const 0
                    local.get 81
                    i32.eqz
                    i32.eqz
                    i32.const 4
                    i32.mul
                    i32.or
                    local.get 103
                    i32.eqz
                    i32.eqz
                    i32.const 8
                    i32.mul
                    i32.or
                    local.get 91
                    i32.eqz
                    i32.eqz
                    i32.const 2
                    i32.mul
                    i32.or
                    local.get 92
                    ref.as_non_null
                    local.get 68
                    ref.as_non_null
                    local.get 84
                    ref.as_non_null
                    struct.new 70
                    local.set 87
                  end
                  ref.null 62
                  local.set 84
                  ref.null 62
                  local.set 68
                  ref.null 61
                  local.set 92
                end
                ref.null 70
                local.set 89
                ref.null 139
                local.set 93
              else
                ref.null 269
                local.set 114
                local.get 11
                local.set 69
                ref.null 161
                local.set 70
                block ;; label = @7
                  loop ;; label = @8
                    local.get 69
                    ref.is_null
                    br_if 1 (;@7;)
                    local.get 69
                    struct.get 120 0
                    local.set 70
                    local.get 70
                    ref.is_null
                    i32.eqz
                    br_if 1 (;@7;)
                    local.get 69
                    struct.get 120 3
                    local.set 69
                    br 0 (;@8;)
                  end
                end
                local.get 70
                ref.is_null
                if ;; label = @7
                  global.get 8
                  ref.as_non_null
                  local.set 65
                  local.get 65
                  ref.as_non_null
                  local.set 70
                  ref.null 161
                  local.set 65
                end
                local.get 70
                ref.as_non_null
                local.set 65
                ref.null 161
                local.set 70
                ref.null 120
                local.set 69
                local.get 65
                ref.as_non_null
                local.set 70
                local.get 65
                ref.as_non_null
                struct.get 161 5
                local.set 72
                i32.const 13
                local.set 111
                local.get 72
                ref.as_non_null
                local.get 111
                array.get 163
                local.set 68
                ref.null 163
                local.set 72
                local.get 68
                ref.as_non_null
                struct.get 62 1
                local.set 91
                local.get 68
                ref.as_non_null
                struct.get 62 0
                local.set 82
                local.get 68
                ref.as_non_null
                struct.get 62 2
                local.set 112
                i32.const 0
                local.get 91
                i32.const 6
                i32.eq
                i32.or
                local.get 91
                i32.const 7
                i32.eq
                i32.or
                local.get 91
                i32.const 8
                i32.eq
                i32.or
                local.get 91
                i32.const 9
                i32.eq
                i32.or
                i32.eqz
                if ;; label = @7
                  unreachable
                end
                ref.null 62
                local.set 68
                local.get 112
                ref.cast (ref 107)
                local.set 115
                ref.null eq
                local.set 112
                i32.const 8
                local.set 60
                i64.const 0
                local.set 104
                local.get 115
                ref.as_non_null
                local.set 83
                ref.null 120
                local.set 69
                ref.null 130
                local.set 117
                i32.const 0
                local.set 91
                i64.const 0
                local.set 82
                ref.null eq
                local.set 112
                ref.null 99
                local.set 86
                ref.null 105
                local.set 118
                ref.null 167
                local.set 119
                i32.const 1
                local.set 94
                i64.const 4611686018427387904
                local.set 106
                i32.const 261
                local.set 90
                local.get 90
                call $helper::pooled_string_resolve
                local.set 52
                local.get 60
                local.get 104
                local.get 83
                local.get 52
                ref.as_non_null
                local.get 106
                local.get 94
                call $helper::native_function_allocate
                ref.null 131
                local.set 52
                local.set 88
                ref.func $builtin::Object.getOwnPropertyDescriptor
                local.set 121
                i64.const 81
                i32.const 1
                i32.const 15
                i32.const -1
                i32.const 0
                i32.const 0
                local.get 121
                ref.null 41
                ref.null 42
                ref.null 43
                ref.null 39
                struct.new 106
                ref.null 40
                local.set 121
                local.set 120
                global.get 30
                local.set 85
                ref.null 59
                local.set 122
                local.get 70
                ref.as_non_null
                local.get 69
                local.get 117
                ref.null 107
                local.get 85
                ref.as_non_null
                local.get 86
                local.get 119
                local.get 114
                local.get 118
                ref.null 109
                local.get 122
                struct.new 110
                local.set 123
                ref.null 59
                local.set 122
                i32.const 3749
                local.set 105
                local.get 105
                call $helper::pooled_string_resolve
                local.set 47
                global.get 30
                local.set 68
                local.get 88
                ref.as_non_null
                local.get 120
                ref.as_non_null
                local.get 123
                ref.as_non_null
                local.get 47
                ref.as_non_null
                local.get 68
                ref.as_non_null
                i32.const 1
                i32.const 0
                i32.const 0
                i32.const 0
                i32.const 0
                i32.const 0
                i32.const 0
                i32.const -1
                ref.null 108
                ref.null 108
                struct.new 107
                local.set 124
                local.get 123
                ref.as_non_null
                local.get 124
                ref.as_non_null
                struct.set 110 3
                ref.null 62
                local.set 68
                ref.null 131
                local.set 47
                ref.null 62
                local.set 85
                ref.null 110
                local.set 123
                ref.null 106
                local.set 120
                ref.null 69
                local.set 88
                local.get 124
                ref.as_non_null
                ref.null 107
                local.set 124
                ref.null 167
                local.set 119
                ref.null 105
                local.set 118
                ref.null 99
                local.set 86
                ref.null eq
                local.set 112
                ref.null 130
                local.set 117
                ref.null 120
                local.set 69
                ref.null eq
                local.set 83
                local.set 116
                ref.null 107
                local.set 115
                ref.null 161
                local.set 70
                ref.null 161
                local.set 65
                i32.const 8
                local.set 94
                i64.const 0
                local.set 78
                local.get 116
                ref.as_non_null
                local.set 112
                i32.const 0
                local.set 105
                i64.const 0
                local.set 106
                ref.null eq
                local.set 83
                local.get 49
                local.get 48
                local.get 50
                struct.new 62
                local.set 84
                local.get 25
                local.get 24
                local.get 26
                struct.new 62
                local.set 68
                local.get 84
                ref.as_non_null
                local.get 68
                ref.as_non_null
                array.new_fixed 99 2
                local.set 86
                ref.null 62
                local.set 68
                ref.null 62
                local.set 84
                global.get 8
                ref.as_non_null
                local.set 65
                local.get 94
                local.get 78
                local.get 112
                local.get 105
                local.get 106
                local.get 83
                local.get 86
                ref.as_non_null
                local.get 65
                ref.as_non_null
                local.get 11
                local.get 29
                ref.as_non_null
                call $helper::proxy_call
                local.set 103
                local.set 81
                local.set 79
                local.set 99
                local.set 102
                local.get 65
                ref.as_non_null
                global.set 8
                ref.null 161
                local.set 65
                local.get 81
                i32.const 2
                i32.eq
                if ;; label = @7
                  local.get 102
                  local.set 102
                  local.get 99
                  local.set 99
                  local.get 79
                  local.set 79
                  i32.const 0
                  local.set 81
                  i32.const 0
                  local.set 103
                end
                ref.null 99
                local.set 86
                ref.null eq
                local.set 83
                ref.null eq
                local.set 112
                ref.null 107
                local.set 116
                ref.null 269
                local.set 114
                local.get 81
                i32.const 1
                i32.eq
                if ;; label = @7
                  local.get 102
                  local.set 13
                  local.get 99
                  local.set 14
                  local.get 79
                  local.set 15
                  local.get 81
                  local.set 16
                  local.get 103
                  local.set 17
                  local.get 13
                  local.get 14
                  local.get 15
                  local.get 16
                  local.get 17
                  return
                end
                local.get 102
                i32.const 0
                i32.ne
                if ;; label = @7
                  i32.const 299
                  local.set 136
                  local.get 136
                  call $helper::pooled_string_resolve
                  local.set 45
                  i32.const 4
                  local.set 136
                  i64.const 0
                  local.set 137
                  local.get 45
                  ref.as_non_null
                  local.set 138
                  ref.null 131
                  local.set 45
                  i32.const 0
                  local.set 132
                  i32.const 0
                  local.set 60
                  i64.const 0
                  local.set 104
                  ref.null eq
                  local.set 83
                  local.get 102
                  i32.const 6
                  i32.eq
                  local.get 102
                  i32.const 7
                  i32.eq
                  i32.or
                  local.get 102
                  i32.const 8
                  i32.eq
                  i32.or
                  local.get 102
                  i32.const 9
                  i32.eq
                  i32.or
                  if ;; label = @8
                    local.get 102
                    local.get 99
                    local.get 79
                    call $helper::object_header_projection
                    local.set 88
                    i32.const 0
                    local.set 132
                    local.get 88
                    ref.as_non_null
                    struct.get 69 1
                    local.set 139
                    local.get 139
                    ref.as_non_null
                    ref.test (ref 77)
                    if ;; label = @9
                      local.get 139
                      ref.as_non_null
                      ref.cast (ref 77)
                      local.set 140
                      i32.const 0
                      local.set 132
                      local.get 136
                      i32.const 4
                      i32.eq
                      if ;; label = @10
                        local.get 140
                        ref.as_non_null
                        struct.get 77 0
                        local.set 142
                        local.get 142
                        ref.as_non_null
                        struct.get 80 0
                        local.set 143
                        ref.null 80
                        local.set 142
                        local.get 143
                        ref.as_non_null
                        array.len
                        local.set 144
                        i32.const 0
                        local.set 141
                        block ;; label = @11
                          loop ;; label = @12
                            local.get 141
                            local.get 144
                            i32.ge_u
                            br_if 1 (;@11;)
                            local.get 143
                            ref.as_non_null
                            local.get 141
                            array.get 83
                            local.set 51
                            i32.const 4
                            local.set 145
                            i64.const 0
                            local.set 146
                            local.get 51
                            ref.as_non_null
                            local.set 147
                            local.get 145
                            local.get 136
                            i32.eq
                            if (result i32) ;; label = @13
                              local.get 145
                              i32.const 3
                              i32.eq
                              if (result i32) ;; label = @14
                                local.get 146
                                local.get 137
                                i64.eq
                                local.get 146
                                f64.reinterpret_i64
                                local.get 146
                                f64.reinterpret_i64
                                f64.ne
                                local.get 137
                                f64.reinterpret_i64
                                local.get 137
                                f64.reinterpret_i64
                                f64.ne
                                i32.and
                                i32.or
                              else
                                local.get 145
                                i32.const 4
                                i32.eq
                                if (result i32) ;; label = @15
                                  local.get 147
                                  local.get 138
                                  ref.eq
                                  if (result i32) ;; label = @16
                                    i32.const 1
                                  else
                                    local.get 147
                                    ref.cast (ref 131)
                                    local.set 52
                                    local.get 138
                                    ref.cast (ref 131)
                                    local.set 47
                                    i32.const 0
                                    local.set 148
                                    local.get 52
                                    ref.as_non_null
                                    local.get 47
                                    ref.as_non_null
                                    local.get 148
                                    call $helper::string_equality
                                    local.set 149
                                    local.get 149
                                    ref.null 131
                                    local.set 47
                                    ref.null 131
                                    local.set 52
                                  end
                                else
                                  local.get 145
                                  i32.const 10
                                  i32.eq
                                  if (result i32) ;; label = @16
                                    local.get 147
                                    ref.cast (ref 133)
                                    local.set 56
                                    local.get 138
                                    ref.cast (ref 133)
                                    local.set 55
                                    local.get 56
                                    ref.as_non_null
                                    struct.get 133 0
                                    local.set 149
                                    local.get 55
                                    ref.as_non_null
                                    struct.get 133 0
                                    local.set 148
                                    local.get 56
                                    ref.as_non_null
                                    struct.get 133 1
                                    local.set 58
                                    local.get 55
                                    ref.as_non_null
                                    struct.get 133 1
                                    local.set 57
                                    local.get 58
                                    ref.as_non_null
                                    array.len
                                    local.set 150
                                    local.get 57
                                    ref.as_non_null
                                    array.len
                                    local.set 151
                                    local.get 149
                                    local.get 148
                                    i32.eq
                                    local.get 150
                                    local.get 151
                                    i32.eq
                                    i32.and
                                    local.set 153
                                    local.get 153
                                    if ;; label = @17
                                      i32.const 0
                                      local.set 152
                                      block ;; label = @18
                                        loop ;; label = @19
                                          local.get 152
                                          local.get 150
                                          i32.ge_u
                                          br_if 1 (;@18;)
                                          local.get 58
                                          ref.as_non_null
                                          local.get 152
                                          array.get 137
                                          local.set 154
                                          local.get 57
                                          ref.as_non_null
                                          local.get 152
                                          array.get 137
                                          local.set 155
                                          local.get 154
                                          local.get 155
                                          i64.eq
                                          local.set 153
                                          local.get 153
                                          i32.eqz
                                          br_if 1 (;@18;)
                                          local.get 152
                                          i32.const 1
                                          i32.add
                                          local.set 152
                                          br 0 (;@19;)
                                        end
                                      end
                                    end
                                    local.get 153
                                    ref.null 137
                                    local.set 57
                                    ref.null 137
                                    local.set 58
                                    ref.null 133
                                    local.set 55
                                    ref.null 133
                                    local.set 56
                                  else
                                    local.get 145
                                    i32.const 0
                                    i32.eq
                                    local.get 145
                                    i32.const 1
                                    i32.eq
                                    i32.or
                                    if (result i32) ;; label = @17
                                      i32.const 1
                                    else
                                      local.get 145
                                      i32.const 2
                                      i32.eq
                                      if (result i32) ;; label = @18
                                        local.get 146
                                        local.get 137
                                        i64.eq
                                      else
                                        local.get 147
                                        local.get 138
                                        ref.eq
                                      end
                                    end
                                  end
                                end
                              end
                            else
                              i32.const 0
                            end
                            local.set 132
                            ref.null eq
                            local.set 147
                            ref.null 131
                            local.set 51
                            local.get 132
                            br_if 1 (;@11;)
                            local.get 141
                            i32.const 1
                            i32.add
                            local.set 141
                            br 0 (;@12;)
                          end
                        end
                        ref.null 83
                        local.set 143
                      end
                      local.get 132
                      if ;; label = @10
                        local.get 140
                        ref.as_non_null
                        ref.test (ref 79)
                        if ;; label = @11
                          local.get 140
                          ref.as_non_null
                          ref.cast (ref 79)
                          local.set 156
                          local.get 156
                          ref.as_non_null
                          struct.get 79 0
                          local.set 142
                          local.get 142
                          ref.as_non_null
                          struct.get 80 0
                          local.set 143
                          local.get 141
                          local.get 143
                          ref.as_non_null
                          array.len
                          i32.ge_u
                          local.get 141
                          i32.const 2
                          i32.ge_u
                          i32.or
                          if ;; label = @12
                            unreachable
                          end
                          ref.null 83
                          local.set 143
                          ref.null 80
                          local.set 142
                          local.get 156
                          ref.as_non_null
                          struct.get 79 1
                          local.set 60
                          local.get 60
                          local.get 141
                          i32.const 8
                          i32.mul
                          i32.shr_u
                          i32.const 255
                          i32.and
                          local.set 60
                          local.get 141
                          i32.eqz
                          if ;; label = @12
                            local.get 156
                            ref.as_non_null
                            struct.get 79 2
                            local.set 104
                            local.get 156
                            ref.as_non_null
                            struct.get 79 4
                            local.set 83
                          else
                            local.get 156
                            ref.as_non_null
                            struct.get 79 3
                            local.set 104
                            local.get 156
                            ref.as_non_null
                            struct.get 79 5
                            local.set 83
                          end
                          ref.null 79
                          local.set 156
                        else
                          local.get 140
                          ref.as_non_null
                          ref.cast (ref 78)
                          local.set 157
                          local.get 157
                          ref.as_non_null
                          struct.get 78 1
                          local.set 158
                          local.get 157
                          ref.as_non_null
                          struct.get 78 2
                          local.set 159
                          local.get 157
                          ref.as_non_null
                          struct.get 78 3
                          local.set 160
                          local.get 158
                          ref.as_non_null
                          local.get 141
                          array.get_u 84
                          local.set 60
                          i64.const 0
                          local.set 104
                          local.get 159
                          ref.is_null
                          i32.eqz
                          if ;; label = @12
                            local.get 159
                            ref.as_non_null
                            local.set 161
                            local.get 161
                            ref.as_non_null
                            local.get 141
                            array.get 85
                            local.set 104
                            ref.null 85
                            local.set 161
                          end
                          ref.null eq
                          local.set 83
                          local.get 160
                          ref.is_null
                          i32.eqz
                          if ;; label = @12
                            local.get 160
                            ref.as_non_null
                            local.set 162
                            local.get 162
                            ref.as_non_null
                            local.get 141
                            array.get 86
                            local.set 83
                            ref.null 86
                            local.set 162
                          end
                          ref.null 86
                          local.set 160
                          ref.null 85
                          local.set 159
                          ref.null 84
                          local.set 158
                          ref.null 78
                          local.set 157
                        end
                      end
                      ref.null 77
                      local.set 140
                    else
                      local.get 88
                      ref.as_non_null
                      local.get 136
                      local.get 137
                      local.get 138
                      call $helper::ordinary_property_find
                      local.set 163
                      ref.null 70
                      local.set 113
                      local.get 163
                      ref.is_null
                      i32.eqz
                      if ;; label = @10
                        local.get 163
                        ref.as_non_null
                        local.set 164
                        local.get 164
                        ref.as_non_null
                        struct.get 74 1
                        local.set 113
                        ref.null 74
                        local.set 164
                      end
                      local.get 113
                      ref.is_null
                      i32.eqz
                      if ;; label = @10
                        local.get 113
                        struct.get 70 0
                        local.set 144
                        local.get 144
                        i32.const 1
                        i32.and
                        i32.eqz
                        if ;; label = @11
                          local.get 113
                          struct.get 70 1
                          local.set 92
                          local.get 92
                          ref.as_non_null
                          ref.test (ref 62)
                          if ;; label = @12
                            local.get 92
                            ref.as_non_null
                            ref.cast (ref 62)
                            local.set 84
                            local.get 84
                            ref.as_non_null
                            struct.get 62 1
                            local.set 60
                            local.get 84
                            ref.as_non_null
                            struct.get 62 0
                            local.set 104
                            local.get 84
                            ref.as_non_null
                            struct.get 62 2
                            local.set 83
                            ref.null 62
                            local.set 84
                          else
                            local.get 92
                            ref.as_non_null
                            call $helper::property_value_resolve
                            local.set 68
                            local.get 68
                            ref.as_non_null
                            struct.get 62 1
                            local.set 60
                            local.get 68
                            ref.as_non_null
                            struct.get 62 0
                            local.set 104
                            local.get 68
                            ref.as_non_null
                            struct.get 62 2
                            local.set 83
                            ref.null 62
                            local.set 68
                          end
                          i32.const 1
                          local.set 132
                          ref.null 61
                          local.set 92
                        end
                      end
                      ref.null 70
                      local.set 113
                      ref.null 74
                      local.set 163
                    end
                    ref.null 76
                    local.set 139
                    ref.null 69
                    local.set 88
                  end
                  ref.null eq
                  local.set 138
                  i32.const 645
                  local.set 141
                  local.get 141
                  call $helper::pooled_string_resolve
                  local.set 52
                  i32.const 4
                  local.set 136
                  i64.const 0
                  local.set 137
                  local.get 52
                  ref.as_non_null
                  local.set 138
                  ref.null 131
                  local.set 52
                  i32.const 0
                  local.set 132
                  i32.const 0
                  local.set 94
                  i64.const 0
                  local.set 82
                  ref.null eq
                  local.set 126
                  local.get 102
                  i32.const 6
                  i32.eq
                  local.get 102
                  i32.const 7
                  i32.eq
                  i32.or
                  local.get 102
                  i32.const 8
                  i32.eq
                  i32.or
                  local.get 102
                  i32.const 9
                  i32.eq
                  i32.or
                  if ;; label = @8
                    local.get 102
                    local.get 99
                    local.get 79
                    call $helper::object_header_projection
                    local.set 88
                    i32.const 0
                    local.set 132
                    local.get 88
                    ref.as_non_null
                    struct.get 69 1
                    local.set 139
                    local.get 139
                    ref.as_non_null
                    ref.test (ref 77)
                    if ;; label = @9
                      local.get 139
                      ref.as_non_null
                      ref.cast (ref 77)
                      local.set 140
                      i32.const 0
                      local.set 132
                      local.get 136
                      i32.const 4
                      i32.eq
                      if ;; label = @10
                        local.get 140
                        ref.as_non_null
                        struct.get 77 0
                        local.set 142
                        local.get 142
                        ref.as_non_null
                        struct.get 80 0
                        local.set 143
                        ref.null 80
                        local.set 142
                        local.get 143
                        ref.as_non_null
                        array.len
                        local.set 153
                        i32.const 0
                        local.set 141
                        block ;; label = @11
                          loop ;; label = @12
                            local.get 141
                            local.get 153
                            i32.ge_u
                            br_if 1 (;@11;)
                            local.get 143
                            ref.as_non_null
                            local.get 141
                            array.get 83
                            local.set 52
                            i32.const 4
                            local.set 152
                            i64.const 0
                            local.set 155
                            local.get 52
                            ref.as_non_null
                            local.set 147
                            local.get 152
                            local.get 136
                            i32.eq
                            if (result i32) ;; label = @13
                              local.get 152
                              i32.const 3
                              i32.eq
                              if (result i32) ;; label = @14
                                local.get 155
                                local.get 137
                                i64.eq
                                local.get 155
                                f64.reinterpret_i64
                                local.get 155
                                f64.reinterpret_i64
                                f64.ne
                                local.get 137
                                f64.reinterpret_i64
                                local.get 137
                                f64.reinterpret_i64
                                f64.ne
                                i32.and
                                i32.or
                              else
                                local.get 152
                                i32.const 4
                                i32.eq
                                if (result i32) ;; label = @15
                                  local.get 147
                                  local.get 138
                                  ref.eq
                                  if (result i32) ;; label = @16
                                    i32.const 1
                                  else
                                    local.get 147
                                    ref.cast (ref 131)
                                    local.set 47
                                    local.get 138
                                    ref.cast (ref 131)
                                    local.set 45
                                    i32.const 0
                                    local.set 151
                                    local.get 47
                                    ref.as_non_null
                                    local.get 45
                                    ref.as_non_null
                                    local.get 151
                                    call $helper::string_equality
                                    local.set 150
                                    local.get 150
                                    ref.null 131
                                    local.set 45
                                    ref.null 131
                                    local.set 47
                                  end
                                else
                                  local.get 152
                                  i32.const 10
                                  i32.eq
                                  if (result i32) ;; label = @16
                                    local.get 147
                                    ref.cast (ref 133)
                                    local.set 55
                                    local.get 138
                                    ref.cast (ref 133)
                                    local.set 56
                                    local.get 55
                                    ref.as_non_null
                                    struct.get 133 0
                                    local.set 144
                                    local.get 56
                                    ref.as_non_null
                                    struct.get 133 0
                                    local.set 151
                                    local.get 55
                                    ref.as_non_null
                                    struct.get 133 1
                                    local.set 57
                                    local.get 56
                                    ref.as_non_null
                                    struct.get 133 1
                                    local.set 58
                                    local.get 57
                                    ref.as_non_null
                                    array.len
                                    local.set 150
                                    local.get 58
                                    ref.as_non_null
                                    array.len
                                    local.set 145
                                    local.get 144
                                    local.get 151
                                    i32.eq
                                    local.get 150
                                    local.get 145
                                    i32.eq
                                    i32.and
                                    local.set 149
                                    local.get 149
                                    if ;; label = @17
                                      i32.const 0
                                      local.set 148
                                      block ;; label = @18
                                        loop ;; label = @19
                                          local.get 148
                                          local.get 150
                                          i32.ge_u
                                          br_if 1 (;@18;)
                                          local.get 57
                                          ref.as_non_null
                                          local.get 148
                                          array.get 137
                                          local.set 154
                                          local.get 58
                                          ref.as_non_null
                                          local.get 148
                                          array.get 137
                                          local.set 146
                                          local.get 154
                                          local.get 146
                                          i64.eq
                                          local.set 149
                                          local.get 149
                                          i32.eqz
                                          br_if 1 (;@18;)
                                          local.get 148
                                          i32.const 1
                                          i32.add
                                          local.set 148
                                          br 0 (;@19;)
                                        end
                                      end
                                    end
                                    local.get 149
                                    ref.null 137
                                    local.set 58
                                    ref.null 137
                                    local.set 57
                                    ref.null 133
                                    local.set 56
                                    ref.null 133
                                    local.set 55
                                  else
                                    local.get 152
                                    i32.const 0
                                    i32.eq
                                    local.get 152
                                    i32.const 1
                                    i32.eq
                                    i32.or
                                    if (result i32) ;; label = @17
                                      i32.const 1
                                    else
                                      local.get 152
                                      i32.const 2
                                      i32.eq
                                      if (result i32) ;; label = @18
                                        local.get 155
                                        local.get 137
                                        i64.eq
                                      else
                                        local.get 147
                                        local.get 138
                                        ref.eq
                                      end
                                    end
                                  end
                                end
                              end
                            else
                              i32.const 0
                            end
                            local.set 132
                            ref.null eq
                            local.set 147
                            ref.null 131
                            local.set 52
                            local.get 132
                            br_if 1 (;@11;)
                            local.get 141
                            i32.const 1
                            i32.add
                            local.set 141
                            br 0 (;@12;)
                          end
                        end
                        ref.null 83
                        local.set 143
                      end
                      local.get 132
                      if ;; label = @10
                        local.get 140
                        ref.as_non_null
                        ref.test (ref 79)
                        if ;; label = @11
                          local.get 140
                          ref.as_non_null
                          ref.cast (ref 79)
                          local.set 156
                          local.get 156
                          ref.as_non_null
                          struct.get 79 0
                          local.set 142
                          local.get 142
                          ref.as_non_null
                          struct.get 80 0
                          local.set 143
                          local.get 141
                          local.get 143
                          ref.as_non_null
                          array.len
                          i32.ge_u
                          local.get 141
                          i32.const 2
                          i32.ge_u
                          i32.or
                          if ;; label = @12
                            unreachable
                          end
                          ref.null 83
                          local.set 143
                          ref.null 80
                          local.set 142
                          local.get 156
                          ref.as_non_null
                          struct.get 79 1
                          local.set 94
                          local.get 94
                          local.get 141
                          i32.const 8
                          i32.mul
                          i32.shr_u
                          i32.const 255
                          i32.and
                          local.set 94
                          local.get 141
                          i32.eqz
                          if ;; label = @12
                            local.get 156
                            ref.as_non_null
                            struct.get 79 2
                            local.set 82
                            local.get 156
                            ref.as_non_null
                            struct.get 79 4
                            local.set 126
                          else
                            local.get 156
                            ref.as_non_null
                            struct.get 79 3
                            local.set 82
                            local.get 156
                            ref.as_non_null
                            struct.get 79 5
                            local.set 126
                          end
                          ref.null 79
                          local.set 156
                        else
                          local.get 140
                          ref.as_non_null
                          ref.cast (ref 78)
                          local.set 157
                          local.get 157
                          ref.as_non_null
                          struct.get 78 1
                          local.set 158
                          local.get 157
                          ref.as_non_null
                          struct.get 78 2
                          local.set 161
                          local.get 157
                          ref.as_non_null
                          struct.get 78 3
                          local.set 162
                          local.get 158
                          ref.as_non_null
                          local.get 141
                          array.get_u 84
                          local.set 94
                          i64.const 0
                          local.set 82
                          local.get 161
                          ref.is_null
                          i32.eqz
                          if ;; label = @12
                            local.get 161
                            ref.as_non_null
                            local.set 159
                            local.get 159
                            ref.as_non_null
                            local.get 141
                            array.get 85
                            local.set 82
                            ref.null 85
                            local.set 159
                          end
                          ref.null eq
                          local.set 126
                          local.get 162
                          ref.is_null
                          i32.eqz
                          if ;; label = @12
                            local.get 162
                            ref.as_non_null
                            local.set 160
                            local.get 160
                            ref.as_non_null
                            local.get 141
                            array.get 86
                            local.set 126
                            ref.null 86
                            local.set 160
                          end
                          ref.null 86
                          local.set 162
                          ref.null 85
                          local.set 161
                          ref.null 84
                          local.set 158
                          ref.null 78
                          local.set 157
                        end
                      end
                      ref.null 77
                      local.set 140
                    else
                      local.get 88
                      ref.as_non_null
                      local.get 136
                      local.get 137
                      local.get 138
                      call $helper::ordinary_property_find
                      local.set 163
                      ref.null 70
                      local.set 101
                      local.get 163
                      ref.is_null
                      i32.eqz
                      if ;; label = @10
                        local.get 163
                        ref.as_non_null
                        local.set 164
                        local.get 164
                        ref.as_non_null
                        struct.get 74 1
                        local.set 101
                        ref.null 74
                        local.set 164
                      end
                      local.get 101
                      ref.is_null
                      i32.eqz
                      if ;; label = @10
                        local.get 101
                        struct.get 70 0
                        local.set 141
                        local.get 141
                        i32.const 1
                        i32.and
                        i32.eqz
                        if ;; label = @11
                          local.get 101
                          struct.get 70 1
                          local.set 92
                          local.get 92
                          ref.as_non_null
                          ref.test (ref 62)
                          if ;; label = @12
                            local.get 92
                            ref.as_non_null
                            ref.cast (ref 62)
                            local.set 68
                            local.get 68
                            ref.as_non_null
                            struct.get 62 1
                            local.set 94
                            local.get 68
                            ref.as_non_null
                            struct.get 62 0
                            local.set 82
                            local.get 68
                            ref.as_non_null
                            struct.get 62 2
                            local.set 126
                            ref.null 62
                            local.set 68
                          else
                            local.get 92
                            ref.as_non_null
                            call $helper::property_value_resolve
                            local.set 84
                            local.get 84
                            ref.as_non_null
                            struct.get 62 1
                            local.set 94
                            local.get 84
                            ref.as_non_null
                            struct.get 62 0
                            local.set 82
                            local.get 84
                            ref.as_non_null
                            struct.get 62 2
                            local.set 126
                            ref.null 62
                            local.set 84
                          end
                          i32.const 1
                          local.set 132
                          ref.null 61
                          local.set 92
                        end
                      end
                      ref.null 70
                      local.set 101
                      ref.null 74
                      local.set 163
                    end
                    ref.null 76
                    local.set 139
                    ref.null 69
                    local.set 88
                  end
                  ref.null eq
                  local.set 138
                  i32.const 635
                  local.set 152
                  local.get 152
                  call $helper::pooled_string_resolve
                  local.set 47
                  i32.const 4
                  local.set 136
                  i64.const 0
                  local.set 137
                  local.get 47
                  ref.as_non_null
                  local.set 138
                  ref.null 131
                  local.set 47
                  i32.const 0
                  local.set 132
                  i32.const 0
                  local.set 111
                  i64.const 0
                  local.set 78
                  ref.null eq
                  local.set 112
                  local.get 102
                  i32.const 6
                  i32.eq
                  local.get 102
                  i32.const 7
                  i32.eq
                  i32.or
                  local.get 102
                  i32.const 8
                  i32.eq
                  i32.or
                  local.get 102
                  i32.const 9
                  i32.eq
                  i32.or
                  if ;; label = @8
                    local.get 102
                    local.get 99
                    local.get 79
                    call $helper::object_header_projection
                    local.set 88
                    i32.const 0
                    local.set 132
                    local.get 88
                    ref.as_non_null
                    struct.get 69 1
                    local.set 139
                    local.get 139
                    ref.as_non_null
                    ref.test (ref 77)
                    if ;; label = @9
                      local.get 139
                      ref.as_non_null
                      ref.cast (ref 77)
                      local.set 140
                      i32.const 0
                      local.set 132
                      local.get 136
                      i32.const 4
                      i32.eq
                      if ;; label = @10
                        local.get 140
                        ref.as_non_null
                        struct.get 77 0
                        local.set 142
                        local.get 142
                        ref.as_non_null
                        struct.get 80 0
                        local.set 143
                        ref.null 80
                        local.set 142
                        local.get 143
                        ref.as_non_null
                        array.len
                        local.set 153
                        i32.const 0
                        local.set 152
                        block ;; label = @11
                          loop ;; label = @12
                            local.get 152
                            local.get 153
                            i32.ge_u
                            br_if 1 (;@11;)
                            local.get 143
                            ref.as_non_null
                            local.get 152
                            array.get 83
                            local.set 47
                            i32.const 4
                            local.set 141
                            i64.const 0
                            local.set 155
                            local.get 47
                            ref.as_non_null
                            local.set 147
                            local.get 141
                            local.get 136
                            i32.eq
                            if (result i32) ;; label = @13
                              local.get 141
                              i32.const 3
                              i32.eq
                              if (result i32) ;; label = @14
                                local.get 155
                                local.get 137
                                i64.eq
                                local.get 155
                                f64.reinterpret_i64
                                local.get 155
                                f64.reinterpret_i64
                                f64.ne
                                local.get 137
                                f64.reinterpret_i64
                                local.get 137
                                f64.reinterpret_i64
                                f64.ne
                                i32.and
                                i32.or
                              else
                                local.get 141
                                i32.const 4
                                i32.eq
                                if (result i32) ;; label = @15
                                  local.get 147
                                  local.get 138
                                  ref.eq
                                  if (result i32) ;; label = @16
                                    i32.const 1
                                  else
                                    local.get 147
                                    ref.cast (ref 131)
                                    local.set 52
                                    local.get 138
                                    ref.cast (ref 131)
                                    local.set 45
                                    i32.const 0
                                    local.set 149
                                    local.get 52
                                    ref.as_non_null
                                    local.get 45
                                    ref.as_non_null
                                    local.get 149
                                    call $helper::string_equality
                                    local.set 144
                                    local.get 144
                                    ref.null 131
                                    local.set 45
                                    ref.null 131
                                    local.set 52
                                  end
                                else
                                  local.get 141
                                  i32.const 10
                                  i32.eq
                                  if (result i32) ;; label = @16
                                    local.get 147
                                    ref.cast (ref 133)
                                    local.set 55
                                    local.get 138
                                    ref.cast (ref 133)
                                    local.set 56
                                    local.get 55
                                    ref.as_non_null
                                    struct.get 133 0
                                    local.set 151
                                    local.get 56
                                    ref.as_non_null
                                    struct.get 133 0
                                    local.set 149
                                    local.get 55
                                    ref.as_non_null
                                    struct.get 133 1
                                    local.set 58
                                    local.get 56
                                    ref.as_non_null
                                    struct.get 133 1
                                    local.set 57
                                    local.get 58
                                    ref.as_non_null
                                    array.len
                                    local.set 144
                                    local.get 57
                                    ref.as_non_null
                                    array.len
                                    local.set 150
                                    local.get 151
                                    local.get 149
                                    i32.eq
                                    local.get 144
                                    local.get 150
                                    i32.eq
                                    i32.and
                                    local.set 148
                                    local.get 148
                                    if ;; label = @17
                                      i32.const 0
                                      local.set 145
                                      block ;; label = @18
                                        loop ;; label = @19
                                          local.get 145
                                          local.get 144
                                          i32.ge_u
                                          br_if 1 (;@18;)
                                          local.get 58
                                          ref.as_non_null
                                          local.get 145
                                          array.get 137
                                          local.set 146
                                          local.get 57
                                          ref.as_non_null
                                          local.get 145
                                          array.get 137
                                          local.set 154
                                          local.get 146
                                          local.get 154
                                          i64.eq
                                          local.set 148
                                          local.get 148
                                          i32.eqz
                                          br_if 1 (;@18;)
                                          local.get 145
                                          i32.const 1
                                          i32.add
                                          local.set 145
                                          br 0 (;@19;)
                                        end
                                      end
                                    end
                                    local.get 148
                                    ref.null 137
                                    local.set 57
                                    ref.null 137
                                    local.set 58
                                    ref.null 133
                                    local.set 56
                                    ref.null 133
                                    local.set 55
                                  else
                                    local.get 141
                                    i32.const 0
                                    i32.eq
                                    local.get 141
                                    i32.const 1
                                    i32.eq
                                    i32.or
                                    if (result i32) ;; label = @17
                                      i32.const 1
                                    else
                                      local.get 141
                                      i32.const 2
                                      i32.eq
                                      if (result i32) ;; label = @18
                                        local.get 155
                                        local.get 137
                                        i64.eq
                                      else
                                        local.get 147
                                        local.get 138
                                        ref.eq
                                      end
                                    end
                                  end
                                end
                              end
                            else
                              i32.const 0
                            end
                            local.set 132
                            ref.null eq
                            local.set 147
                            ref.null 131
                            local.set 47
                            local.get 132
                            br_if 1 (;@11;)
                            local.get 152
                            i32.const 1
                            i32.add
                            local.set 152
                            br 0 (;@12;)
                          end
                        end
                        ref.null 83
                        local.set 143
                      end
                      local.get 132
                      if ;; label = @10
                        local.get 140
                        ref.as_non_null
                        ref.test (ref 79)
                        if ;; label = @11
                          local.get 140
                          ref.as_non_null
                          ref.cast (ref 79)
                          local.set 156
                          local.get 156
                          ref.as_non_null
                          struct.get 79 0
                          local.set 142
                          local.get 142
                          ref.as_non_null
                          struct.get 80 0
                          local.set 143
                          local.get 152
                          local.get 143
                          ref.as_non_null
                          array.len
                          i32.ge_u
                          local.get 152
                          i32.const 2
                          i32.ge_u
                          i32.or
                          if ;; label = @12
                            unreachable
                          end
                          ref.null 83
                          local.set 143
                          ref.null 80
                          local.set 142
                          local.get 156
                          ref.as_non_null
                          struct.get 79 1
                          local.set 111
                          local.get 111
                          local.get 152
                          i32.const 8
                          i32.mul
                          i32.shr_u
                          i32.const 255
                          i32.and
                          local.set 111
                          local.get 152
                          i32.eqz
                          if ;; label = @12
                            local.get 156
                            ref.as_non_null
                            struct.get 79 2
                            local.set 78
                            local.get 156
                            ref.as_non_null
                            struct.get 79 4
                            local.set 112
                          else
                            local.get 156
                            ref.as_non_null
                            struct.get 79 3
                            local.set 78
                            local.get 156
                            ref.as_non_null
                            struct.get 79 5
                            local.set 112
                          end
                          ref.null 79
                          local.set 156
                        else
                          local.get 140
                          ref.as_non_null
                          ref.cast (ref 78)
                          local.set 157
                          local.get 157
                          ref.as_non_null
                          struct.get 78 1
                          local.set 158
                          local.get 157
                          ref.as_non_null
                          struct.get 78 2
                          local.set 161
                          local.get 157
                          ref.as_non_null
                          struct.get 78 3
                          local.set 160
                          local.get 158
                          ref.as_non_null
                          local.get 152
                          array.get_u 84
                          local.set 111
                          i64.const 0
                          local.set 78
                          local.get 161
                          ref.is_null
                          i32.eqz
                          if ;; label = @12
                            local.get 161
                            ref.as_non_null
                            local.set 159
                            local.get 159
                            ref.as_non_null
                            local.get 152
                            array.get 85
                            local.set 78
                            ref.null 85
                            local.set 159
                          end
                          ref.null eq
                          local.set 112
                          local.get 160
                          ref.is_null
                          i32.eqz
                          if ;; label = @12
                            local.get 160
                            ref.as_non_null
                            local.set 162
                            local.get 162
                            ref.as_non_null
                            local.get 152
                            array.get 86
                            local.set 112
                            ref.null 86
                            local.set 162
                          end
                          ref.null 86
                          local.set 160
                          ref.null 85
                          local.set 161
                          ref.null 84
                          local.set 158
                          ref.null 78
                          local.set 157
                        end
                      end
                      ref.null 77
                      local.set 140
                    else
                      local.get 88
                      ref.as_non_null
                      local.get 136
                      local.get 137
                      local.get 138
                      call $helper::ordinary_property_find
                      local.set 163
                      ref.null 70
                      local.set 113
                      local.get 163
                      ref.is_null
                      i32.eqz
                      if ;; label = @10
                        local.get 163
                        ref.as_non_null
                        local.set 164
                        local.get 164
                        ref.as_non_null
                        struct.get 74 1
                        local.set 113
                        ref.null 74
                        local.set 164
                      end
                      local.get 113
                      ref.is_null
                      i32.eqz
                      if ;; label = @10
                        local.get 113
                        struct.get 70 0
                        local.set 152
                        local.get 152
                        i32.const 1
                        i32.and
                        i32.eqz
                        if ;; label = @11
                          local.get 113
                          struct.get 70 1
                          local.set 92
                          local.get 92
                          ref.as_non_null
                          ref.test (ref 62)
                          if ;; label = @12
                            local.get 92
                            ref.as_non_null
                            ref.cast (ref 62)
                            local.set 84
                            local.get 84
                            ref.as_non_null
                            struct.get 62 1
                            local.set 111
                            local.get 84
                            ref.as_non_null
                            struct.get 62 0
                            local.set 78
                            local.get 84
                            ref.as_non_null
                            struct.get 62 2
                            local.set 112
                            ref.null 62
                            local.set 84
                          else
                            local.get 92
                            ref.as_non_null
                            call $helper::property_value_resolve
                            local.set 68
                            local.get 68
                            ref.as_non_null
                            struct.get 62 1
                            local.set 111
                            local.get 68
                            ref.as_non_null
                            struct.get 62 0
                            local.set 78
                            local.get 68
                            ref.as_non_null
                            struct.get 62 2
                            local.set 112
                            ref.null 62
                            local.set 68
                          end
                          i32.const 1
                          local.set 132
                          ref.null 61
                          local.set 92
                        end
                      end
                      ref.null 70
                      local.set 113
                      ref.null 74
                      local.set 163
                    end
                    ref.null 76
                    local.set 139
                    ref.null 69
                    local.set 88
                  end
                  local.get 132
                  local.set 131
                  ref.null eq
                  local.set 138
                  i32.const 636
                  local.set 136
                  local.get 136
                  call $helper::pooled_string_resolve
                  local.set 47
                  i32.const 4
                  local.set 141
                  i64.const 0
                  local.set 137
                  local.get 47
                  ref.as_non_null
                  local.set 138
                  ref.null 131
                  local.set 47
                  i32.const 0
                  local.set 132
                  i32.const 0
                  local.set 105
                  i64.const 0
                  local.set 106
                  ref.null eq
                  local.set 125
                  local.get 102
                  i32.const 6
                  i32.eq
                  local.get 102
                  i32.const 7
                  i32.eq
                  i32.or
                  local.get 102
                  i32.const 8
                  i32.eq
                  i32.or
                  local.get 102
                  i32.const 9
                  i32.eq
                  i32.or
                  if ;; label = @8
                    local.get 102
                    local.get 99
                    local.get 79
                    call $helper::object_header_projection
                    local.set 88
                    i32.const 0
                    local.set 132
                    local.get 88
                    ref.as_non_null
                    struct.get 69 1
                    local.set 139
                    local.get 139
                    ref.as_non_null
                    ref.test (ref 77)
                    if ;; label = @9
                      local.get 139
                      ref.as_non_null
                      ref.cast (ref 77)
                      local.set 140
                      i32.const 0
                      local.set 132
                      local.get 141
                      i32.const 4
                      i32.eq
                      if ;; label = @10
                        local.get 140
                        ref.as_non_null
                        struct.get 77 0
                        local.set 142
                        local.get 142
                        ref.as_non_null
                        struct.get 80 0
                        local.set 143
                        ref.null 80
                        local.set 142
                        local.get 143
                        ref.as_non_null
                        array.len
                        local.set 153
                        i32.const 0
                        local.set 136
                        block ;; label = @11
                          loop ;; label = @12
                            local.get 136
                            local.get 153
                            i32.ge_u
                            br_if 1 (;@11;)
                            local.get 143
                            ref.as_non_null
                            local.get 136
                            array.get 83
                            local.set 47
                            i32.const 4
                            local.set 152
                            i64.const 0
                            local.set 155
                            local.get 47
                            ref.as_non_null
                            local.set 147
                            local.get 152
                            local.get 141
                            i32.eq
                            if (result i32) ;; label = @13
                              local.get 152
                              i32.const 3
                              i32.eq
                              if (result i32) ;; label = @14
                                local.get 155
                                local.get 137
                                i64.eq
                                local.get 155
                                f64.reinterpret_i64
                                local.get 155
                                f64.reinterpret_i64
                                f64.ne
                                local.get 137
                                f64.reinterpret_i64
                                local.get 137
                                f64.reinterpret_i64
                                f64.ne
                                i32.and
                                i32.or
                              else
                                local.get 152
                                i32.const 4
                                i32.eq
                                if (result i32) ;; label = @15
                                  local.get 147
                                  local.get 138
                                  ref.eq
                                  if (result i32) ;; label = @16
                                    i32.const 1
                                  else
                                    local.get 147
                                    ref.cast (ref 131)
                                    local.set 52
                                    local.get 138
                                    ref.cast (ref 131)
                                    local.set 45
                                    i32.const 0
                                    local.set 148
                                    local.get 52
                                    ref.as_non_null
                                    local.get 45
                                    ref.as_non_null
                                    local.get 148
                                    call $helper::string_equality
                                    local.set 151
                                    local.get 151
                                    ref.null 131
                                    local.set 45
                                    ref.null 131
                                    local.set 52
                                  end
                                else
                                  local.get 152
                                  i32.const 10
                                  i32.eq
                                  if (result i32) ;; label = @16
                                    local.get 147
                                    ref.cast (ref 133)
                                    local.set 55
                                    local.get 138
                                    ref.cast (ref 133)
                                    local.set 56
                                    local.get 55
                                    ref.as_non_null
                                    struct.get 133 0
                                    local.set 149
                                    local.get 56
                                    ref.as_non_null
                                    struct.get 133 0
                                    local.set 148
                                    local.get 55
                                    ref.as_non_null
                                    struct.get 133 1
                                    local.set 57
                                    local.get 56
                                    ref.as_non_null
                                    struct.get 133 1
                                    local.set 58
                                    local.get 57
                                    ref.as_non_null
                                    array.len
                                    local.set 151
                                    local.get 58
                                    ref.as_non_null
                                    array.len
                                    local.set 144
                                    local.get 149
                                    local.get 148
                                    i32.eq
                                    local.get 151
                                    local.get 144
                                    i32.eq
                                    i32.and
                                    local.set 145
                                    local.get 145
                                    if ;; label = @17
                                      i32.const 0
                                      local.set 150
                                      block ;; label = @18
                                        loop ;; label = @19
                                          local.get 150
                                          local.get 151
                                          i32.ge_u
                                          br_if 1 (;@18;)
                                          local.get 57
                                          ref.as_non_null
                                          local.get 150
                                          array.get 137
                                          local.set 154
                                          local.get 58
                                          ref.as_non_null
                                          local.get 150
                                          array.get 137
                                          local.set 146
                                          local.get 154
                                          local.get 146
                                          i64.eq
                                          local.set 145
                                          local.get 145
                                          i32.eqz
                                          br_if 1 (;@18;)
                                          local.get 150
                                          i32.const 1
                                          i32.add
                                          local.set 150
                                          br 0 (;@19;)
                                        end
                                      end
                                    end
                                    local.get 145
                                    ref.null 137
                                    local.set 58
                                    ref.null 137
                                    local.set 57
                                    ref.null 133
                                    local.set 56
                                    ref.null 133
                                    local.set 55
                                  else
                                    local.get 152
                                    i32.const 0
                                    i32.eq
                                    local.get 152
                                    i32.const 1
                                    i32.eq
                                    i32.or
                                    if (result i32) ;; label = @17
                                      i32.const 1
                                    else
                                      local.get 152
                                      i32.const 2
                                      i32.eq
                                      if (result i32) ;; label = @18
                                        local.get 155
                                        local.get 137
                                        i64.eq
                                      else
                                        local.get 147
                                        local.get 138
                                        ref.eq
                                      end
                                    end
                                  end
                                end
                              end
                            else
                              i32.const 0
                            end
                            local.set 132
                            ref.null eq
                            local.set 147
                            ref.null 131
                            local.set 47
                            local.get 132
                            br_if 1 (;@11;)
                            local.get 136
                            i32.const 1
                            i32.add
                            local.set 136
                            br 0 (;@12;)
                          end
                        end
                        ref.null 83
                        local.set 143
                      end
                      local.get 132
                      if ;; label = @10
                        local.get 140
                        ref.as_non_null
                        ref.test (ref 79)
                        if ;; label = @11
                          local.get 140
                          ref.as_non_null
                          ref.cast (ref 79)
                          local.set 156
                          local.get 156
                          ref.as_non_null
                          struct.get 79 0
                          local.set 142
                          local.get 142
                          ref.as_non_null
                          struct.get 80 0
                          local.set 143
                          local.get 136
                          local.get 143
                          ref.as_non_null
                          array.len
                          i32.ge_u
                          local.get 136
                          i32.const 2
                          i32.ge_u
                          i32.or
                          if ;; label = @12
                            unreachable
                          end
                          ref.null 83
                          local.set 143
                          ref.null 80
                          local.set 142
                          local.get 156
                          ref.as_non_null
                          struct.get 79 1
                          local.set 105
                          local.get 105
                          local.get 136
                          i32.const 8
                          i32.mul
                          i32.shr_u
                          i32.const 255
                          i32.and
                          local.set 105
                          local.get 136
                          i32.eqz
                          if ;; label = @12
                            local.get 156
                            ref.as_non_null
                            struct.get 79 2
                            local.set 106
                            local.get 156
                            ref.as_non_null
                            struct.get 79 4
                            local.set 125
                          else
                            local.get 156
                            ref.as_non_null
                            struct.get 79 3
                            local.set 106
                            local.get 156
                            ref.as_non_null
                            struct.get 79 5
                            local.set 125
                          end
                          ref.null 79
                          local.set 156
                        else
                          local.get 140
                          ref.as_non_null
                          ref.cast (ref 78)
                          local.set 157
                          local.get 157
                          ref.as_non_null
                          struct.get 78 1
                          local.set 158
                          local.get 157
                          ref.as_non_null
                          struct.get 78 2
                          local.set 161
                          local.get 157
                          ref.as_non_null
                          struct.get 78 3
                          local.set 160
                          local.get 158
                          ref.as_non_null
                          local.get 136
                          array.get_u 84
                          local.set 105
                          i64.const 0
                          local.set 106
                          local.get 161
                          ref.is_null
                          i32.eqz
                          if ;; label = @12
                            local.get 161
                            ref.as_non_null
                            local.set 159
                            local.get 159
                            ref.as_non_null
                            local.get 136
                            array.get 85
                            local.set 106
                            ref.null 85
                            local.set 159
                          end
                          ref.null eq
                          local.set 125
                          local.get 160
                          ref.is_null
                          i32.eqz
                          if ;; label = @12
                            local.get 160
                            ref.as_non_null
                            local.set 162
                            local.get 162
                            ref.as_non_null
                            local.get 136
                            array.get 86
                            local.set 125
                            ref.null 86
                            local.set 162
                          end
                          ref.null 86
                          local.set 160
                          ref.null 85
                          local.set 161
                          ref.null 84
                          local.set 158
                          ref.null 78
                          local.set 157
                        end
                      end
                      ref.null 77
                      local.set 140
                    else
                      local.get 88
                      ref.as_non_null
                      local.get 141
                      local.get 137
                      local.get 138
                      call $helper::ordinary_property_find
                      local.set 163
                      ref.null 70
                      local.set 89
                      local.get 163
                      ref.is_null
                      i32.eqz
                      if ;; label = @10
                        local.get 163
                        ref.as_non_null
                        local.set 164
                        local.get 164
                        ref.as_non_null
                        struct.get 74 1
                        local.set 89
                        ref.null 74
                        local.set 164
                      end
                      local.get 89
                      ref.is_null
                      i32.eqz
                      if ;; label = @10
                        local.get 89
                        struct.get 70 0
                        local.set 136
                        local.get 136
                        i32.const 1
                        i32.and
                        i32.eqz
                        if ;; label = @11
                          local.get 89
                          struct.get 70 1
                          local.set 92
                          local.get 92
                          ref.as_non_null
                          ref.test (ref 62)
                          if ;; label = @12
                            local.get 92
                            ref.as_non_null
                            ref.cast (ref 62)
                            local.set 68
                            local.get 68
                            ref.as_non_null
                            struct.get 62 1
                            local.set 105
                            local.get 68
                            ref.as_non_null
                            struct.get 62 0
                            local.set 106
                            local.get 68
                            ref.as_non_null
                            struct.get 62 2
                            local.set 125
                            ref.null 62
                            local.set 68
                          else
                            local.get 92
                            ref.as_non_null
                            call $helper::property_value_resolve
                            local.set 84
                            local.get 84
                            ref.as_non_null
                            struct.get 62 1
                            local.set 105
                            local.get 84
                            ref.as_non_null
                            struct.get 62 0
                            local.set 106
                            local.get 84
                            ref.as_non_null
                            struct.get 62 2
                            local.set 125
                            ref.null 62
                            local.set 84
                          end
                          i32.const 1
                          local.set 132
                          ref.null 61
                          local.set 92
                        end
                      end
                      ref.null 70
                      local.set 89
                      ref.null 74
                      local.set 163
                    end
                    ref.null 76
                    local.set 139
                    ref.null 69
                    local.set 88
                  end
                  ref.null eq
                  local.set 138
                  i32.const 646
                  local.set 141
                  local.get 141
                  call $helper::pooled_string_resolve
                  local.set 47
                  i32.const 4
                  local.set 153
                  i64.const 0
                  local.set 137
                  local.get 47
                  ref.as_non_null
                  local.set 138
                  ref.null 131
                  local.set 47
                  i32.const 0
                  local.set 132
                  i32.const 0
                  local.set 90
                  i64.const 0
                  local.set 127
                  ref.null eq
                  local.set 128
                  local.get 102
                  i32.const 6
                  i32.eq
                  local.get 102
                  i32.const 7
                  i32.eq
                  i32.or
                  local.get 102
                  i32.const 8
                  i32.eq
                  i32.or
                  local.get 102
                  i32.const 9
                  i32.eq
                  i32.or
                  if ;; label = @8
                    local.get 102
                    local.get 99
                    local.get 79
                    call $helper::object_header_projection
                    local.set 88
                    i32.const 0
                    local.set 132
                    local.get 88
                    ref.as_non_null
                    struct.get 69 1
                    local.set 139
                    local.get 139
                    ref.as_non_null
                    ref.test (ref 77)
                    if ;; label = @9
                      local.get 139
                      ref.as_non_null
                      ref.cast (ref 77)
                      local.set 140
                      i32.const 0
                      local.set 132
                      local.get 153
                      i32.const 4
                      i32.eq
                      if ;; label = @10
                        local.get 140
                        ref.as_non_null
                        struct.get 77 0
                        local.set 142
                        local.get 142
                        ref.as_non_null
                        struct.get 80 0
                        local.set 143
                        ref.null 80
                        local.set 142
                        local.get 143
                        ref.as_non_null
                        array.len
                        local.set 136
                        i32.const 0
                        local.set 141
                        block ;; label = @11
                          loop ;; label = @12
                            local.get 141
                            local.get 136
                            i32.ge_u
                            br_if 1 (;@11;)
                            local.get 143
                            ref.as_non_null
                            local.get 141
                            array.get 83
                            local.set 47
                            i32.const 4
                            local.set 152
                            i64.const 0
                            local.set 155
                            local.get 47
                            ref.as_non_null
                            local.set 147
                            local.get 152
                            local.get 153
                            i32.eq
                            if (result i32) ;; label = @13
                              local.get 152
                              i32.const 3
                              i32.eq
                              if (result i32) ;; label = @14
                                local.get 155
                                local.get 137
                                i64.eq
                                local.get 155
                                f64.reinterpret_i64
                                local.get 155
                                f64.reinterpret_i64
                                f64.ne
                                local.get 137
                                f64.reinterpret_i64
                                local.get 137
                                f64.reinterpret_i64
                                f64.ne
                                i32.and
                                i32.or
                              else
                                local.get 152
                                i32.const 4
                                i32.eq
                                if (result i32) ;; label = @15
                                  local.get 147
                                  local.get 138
                                  ref.eq
                                  if (result i32) ;; label = @16
                                    i32.const 1
                                  else
                                    local.get 147
                                    ref.cast (ref 131)
                                    local.set 52
                                    local.get 138
                                    ref.cast (ref 131)
                                    local.set 45
                                    i32.const 0
                                    local.set 145
                                    local.get 52
                                    ref.as_non_null
                                    local.get 45
                                    ref.as_non_null
                                    local.get 145
                                    call $helper::string_equality
                                    local.set 149
                                    local.get 149
                                    ref.null 131
                                    local.set 45
                                    ref.null 131
                                    local.set 52
                                  end
                                else
                                  local.get 152
                                  i32.const 10
                                  i32.eq
                                  if (result i32) ;; label = @16
                                    local.get 147
                                    ref.cast (ref 133)
                                    local.set 55
                                    local.get 138
                                    ref.cast (ref 133)
                                    local.set 56
                                    local.get 55
                                    ref.as_non_null
                                    struct.get 133 0
                                    local.set 148
                                    local.get 56
                                    ref.as_non_null
                                    struct.get 133 0
                                    local.set 145
                                    local.get 55
                                    ref.as_non_null
                                    struct.get 133 1
                                    local.set 58
                                    local.get 56
                                    ref.as_non_null
                                    struct.get 133 1
                                    local.set 57
                                    local.get 58
                                    ref.as_non_null
                                    array.len
                                    local.set 149
                                    local.get 57
                                    ref.as_non_null
                                    array.len
                                    local.set 151
                                    local.get 148
                                    local.get 145
                                    i32.eq
                                    local.get 149
                                    local.get 151
                                    i32.eq
                                    i32.and
                                    local.set 150
                                    local.get 150
                                    if ;; label = @17
                                      i32.const 0
                                      local.set 144
                                      block ;; label = @18
                                        loop ;; label = @19
                                          local.get 144
                                          local.get 149
                                          i32.ge_u
                                          br_if 1 (;@18;)
                                          local.get 58
                                          ref.as_non_null
                                          local.get 144
                                          array.get 137
                                          local.set 146
                                          local.get 57
                                          ref.as_non_null
                                          local.get 144
                                          array.get 137
                                          local.set 154
                                          local.get 146
                                          local.get 154
                                          i64.eq
                                          local.set 150
                                          local.get 150
                                          i32.eqz
                                          br_if 1 (;@18;)
                                          local.get 144
                                          i32.const 1
                                          i32.add
                                          local.set 144
                                          br 0 (;@19;)
                                        end
                                      end
                                    end
                                    local.get 150
                                    ref.null 137
                                    local.set 57
                                    ref.null 137
                                    local.set 58
                                    ref.null 133
                                    local.set 56
                                    ref.null 133
                                    local.set 55
                                  else
                                    local.get 152
                                    i32.const 0
                                    i32.eq
                                    local.get 152
                                    i32.const 1
                                    i32.eq
                                    i32.or
                                    if (result i32) ;; label = @17
                                      i32.const 1
                                    else
                                      local.get 152
                                      i32.const 2
                                      i32.eq
                                      if (result i32) ;; label = @18
                                        local.get 155
                                        local.get 137
                                        i64.eq
                                      else
                                        local.get 147
                                        local.get 138
                                        ref.eq
                                      end
                                    end
                                  end
                                end
                              end
                            else
                              i32.const 0
                            end
                            local.set 132
                            ref.null eq
                            local.set 147
                            ref.null 131
                            local.set 47
                            local.get 132
                            br_if 1 (;@11;)
                            local.get 141
                            i32.const 1
                            i32.add
                            local.set 141
                            br 0 (;@12;)
                          end
                        end
                        ref.null 83
                        local.set 143
                      end
                      local.get 132
                      if ;; label = @10
                        local.get 140
                        ref.as_non_null
                        ref.test (ref 79)
                        if ;; label = @11
                          local.get 140
                          ref.as_non_null
                          ref.cast (ref 79)
                          local.set 156
                          local.get 156
                          ref.as_non_null
                          struct.get 79 0
                          local.set 142
                          local.get 142
                          ref.as_non_null
                          struct.get 80 0
                          local.set 143
                          local.get 141
                          local.get 143
                          ref.as_non_null
                          array.len
                          i32.ge_u
                          local.get 141
                          i32.const 2
                          i32.ge_u
                          i32.or
                          if ;; label = @12
                            unreachable
                          end
                          ref.null 83
                          local.set 143
                          ref.null 80
                          local.set 142
                          local.get 156
                          ref.as_non_null
                          struct.get 79 1
                          local.set 90
                          local.get 90
                          local.get 141
                          i32.const 8
                          i32.mul
                          i32.shr_u
                          i32.const 255
                          i32.and
                          local.set 90
                          local.get 141
                          i32.eqz
                          if ;; label = @12
                            local.get 156
                            ref.as_non_null
                            struct.get 79 2
                            local.set 127
                            local.get 156
                            ref.as_non_null
                            struct.get 79 4
                            local.set 128
                          else
                            local.get 156
                            ref.as_non_null
                            struct.get 79 3
                            local.set 127
                            local.get 156
                            ref.as_non_null
                            struct.get 79 5
                            local.set 128
                          end
                          ref.null 79
                          local.set 156
                        else
                          local.get 140
                          ref.as_non_null
                          ref.cast (ref 78)
                          local.set 157
                          local.get 157
                          ref.as_non_null
                          struct.get 78 1
                          local.set 158
                          local.get 157
                          ref.as_non_null
                          struct.get 78 2
                          local.set 161
                          local.get 157
                          ref.as_non_null
                          struct.get 78 3
                          local.set 162
                          local.get 158
                          ref.as_non_null
                          local.get 141
                          array.get_u 84
                          local.set 90
                          i64.const 0
                          local.set 127
                          local.get 161
                          ref.is_null
                          i32.eqz
                          if ;; label = @12
                            local.get 161
                            ref.as_non_null
                            local.set 159
                            local.get 159
                            ref.as_non_null
                            local.get 141
                            array.get 85
                            local.set 127
                            ref.null 85
                            local.set 159
                          end
                          ref.null eq
                          local.set 128
                          local.get 162
                          ref.is_null
                          i32.eqz
                          if ;; label = @12
                            local.get 162
                            ref.as_non_null
                            local.set 160
                            local.get 160
                            ref.as_non_null
                            local.get 141
                            array.get 86
                            local.set 128
                            ref.null 86
                            local.set 160
                          end
                          ref.null 86
                          local.set 162
                          ref.null 85
                          local.set 161
                          ref.null 84
                          local.set 158
                          ref.null 78
                          local.set 157
                        end
                      end
                      ref.null 77
                      local.set 140
                    else
                      local.get 88
                      ref.as_non_null
                      local.get 153
                      local.get 137
                      local.get 138
                      call $helper::ordinary_property_find
                      local.set 163
                      ref.null 70
                      local.set 113
                      local.get 163
                      ref.is_null
                      i32.eqz
                      if ;; label = @10
                        local.get 163
                        ref.as_non_null
                        local.set 164
                        local.get 164
                        ref.as_non_null
                        struct.get 74 1
                        local.set 113
                        ref.null 74
                        local.set 164
                      end
                      local.get 113
                      ref.is_null
                      i32.eqz
                      if ;; label = @10
                        local.get 113
                        struct.get 70 0
                        local.set 136
                        local.get 136
                        i32.const 1
                        i32.and
                        i32.eqz
                        if ;; label = @11
                          local.get 113
                          struct.get 70 1
                          local.set 92
                          local.get 92
                          ref.as_non_null
                          ref.test (ref 62)
                          if ;; label = @12
                            local.get 92
                            ref.as_non_null
                            ref.cast (ref 62)
                            local.set 84
                            local.get 84
                            ref.as_non_null
                            struct.get 62 1
                            local.set 90
                            local.get 84
                            ref.as_non_null
                            struct.get 62 0
                            local.set 127
                            local.get 84
                            ref.as_non_null
                            struct.get 62 2
                            local.set 128
                            ref.null 62
                            local.set 84
                          else
                            local.get 92
                            ref.as_non_null
                            call $helper::property_value_resolve
                            local.set 68
                            local.get 68
                            ref.as_non_null
                            struct.get 62 1
                            local.set 90
                            local.get 68
                            ref.as_non_null
                            struct.get 62 0
                            local.set 127
                            local.get 68
                            ref.as_non_null
                            struct.get 62 2
                            local.set 128
                            ref.null 62
                            local.set 68
                          end
                          i32.const 1
                          local.set 132
                          ref.null 61
                          local.set 92
                        end
                      end
                      ref.null 70
                      local.set 113
                      ref.null 74
                      local.set 163
                    end
                    ref.null 76
                    local.set 139
                    ref.null 69
                    local.set 88
                  end
                  ref.null eq
                  local.set 138
                  i32.const 647
                  local.set 153
                  local.get 153
                  call $helper::pooled_string_resolve
                  local.set 47
                  i32.const 4
                  local.set 141
                  i64.const 0
                  local.set 137
                  local.get 47
                  ref.as_non_null
                  local.set 138
                  ref.null 131
                  local.set 47
                  i32.const 0
                  local.set 132
                  i32.const 0
                  local.set 91
                  i64.const 0
                  local.set 129
                  ref.null eq
                  local.set 130
                  local.get 102
                  i32.const 6
                  i32.eq
                  local.get 102
                  i32.const 7
                  i32.eq
                  i32.or
                  local.get 102
                  i32.const 8
                  i32.eq
                  i32.or
                  local.get 102
                  i32.const 9
                  i32.eq
                  i32.or
                  if ;; label = @8
                    local.get 102
                    local.get 99
                    local.get 79
                    call $helper::object_header_projection
                    local.set 88
                    i32.const 0
                    local.set 132
                    local.get 88
                    ref.as_non_null
                    struct.get 69 1
                    local.set 139
                    local.get 139
                    ref.as_non_null
                    ref.test (ref 77)
                    if ;; label = @9
                      local.get 139
                      ref.as_non_null
                      ref.cast (ref 77)
                      local.set 140
                      i32.const 0
                      local.set 132
                      local.get 141
                      i32.const 4
                      i32.eq
                      if ;; label = @10
                        local.get 140
                        ref.as_non_null
                        struct.get 77 0
                        local.set 142
                        local.get 142
                        ref.as_non_null
                        struct.get 80 0
                        local.set 143
                        ref.null 80
                        local.set 142
                        local.get 143
                        ref.as_non_null
                        array.len
                        local.set 136
                        i32.const 0
                        local.set 153
                        block ;; label = @11
                          loop ;; label = @12
                            local.get 153
                            local.get 136
                            i32.ge_u
                            br_if 1 (;@11;)
                            local.get 143
                            ref.as_non_null
                            local.get 153
                            array.get 83
                            local.set 47
                            i32.const 4
                            local.set 152
                            i64.const 0
                            local.set 155
                            local.get 47
                            ref.as_non_null
                            local.set 147
                            local.get 152
                            local.get 141
                            i32.eq
                            if (result i32) ;; label = @13
                              local.get 152
                              i32.const 3
                              i32.eq
                              if (result i32) ;; label = @14
                                local.get 155
                                local.get 137
                                i64.eq
                                local.get 155
                                f64.reinterpret_i64
                                local.get 155
                                f64.reinterpret_i64
                                f64.ne
                                local.get 137
                                f64.reinterpret_i64
                                local.get 137
                                f64.reinterpret_i64
                                f64.ne
                                i32.and
                                i32.or
                              else
                                local.get 152
                                i32.const 4
                                i32.eq
                                if (result i32) ;; label = @15
                                  local.get 147
                                  local.get 138
                                  ref.eq
                                  if (result i32) ;; label = @16
                                    i32.const 1
                                  else
                                    local.get 147
                                    ref.cast (ref 131)
                                    local.set 52
                                    local.get 138
                                    ref.cast (ref 131)
                                    local.set 45
                                    i32.const 0
                                    local.set 150
                                    local.get 52
                                    ref.as_non_null
                                    local.get 45
                                    ref.as_non_null
                                    local.get 150
                                    call $helper::string_equality
                                    local.set 148
                                    local.get 148
                                    ref.null 131
                                    local.set 45
                                    ref.null 131
                                    local.set 52
                                  end
                                else
                                  local.get 152
                                  i32.const 10
                                  i32.eq
                                  if (result i32) ;; label = @16
                                    local.get 147
                                    ref.cast (ref 133)
                                    local.set 55
                                    local.get 138
                                    ref.cast (ref 133)
                                    local.set 56
                                    local.get 55
                                    ref.as_non_null
                                    struct.get 133 0
                                    local.set 145
                                    local.get 56
                                    ref.as_non_null
                                    struct.get 133 0
                                    local.set 150
                                    local.get 55
                                    ref.as_non_null
                                    struct.get 133 1
                                    local.set 57
                                    local.get 56
                                    ref.as_non_null
                                    struct.get 133 1
                                    local.set 58
                                    local.get 57
                                    ref.as_non_null
                                    array.len
                                    local.set 148
                                    local.get 58
                                    ref.as_non_null
                                    array.len
                                    local.set 149
                                    local.get 145
                                    local.get 150
                                    i32.eq
                                    local.get 148
                                    local.get 149
                                    i32.eq
                                    i32.and
                                    local.set 144
                                    local.get 144
                                    if ;; label = @17
                                      i32.const 0
                                      local.set 151
                                      block ;; label = @18
                                        loop ;; label = @19
                                          local.get 151
                                          local.get 148
                                          i32.ge_u
                                          br_if 1 (;@18;)
                                          local.get 57
                                          ref.as_non_null
                                          local.get 151
                                          array.get 137
                                          local.set 154
                                          local.get 58
                                          ref.as_non_null
                                          local.get 151
                                          array.get 137
                                          local.set 146
                                          local.get 154
                                          local.get 146
                                          i64.eq
                                          local.set 144
                                          local.get 144
                                          i32.eqz
                                          br_if 1 (;@18;)
                                          local.get 151
                                          i32.const 1
                                          i32.add
                                          local.set 151
                                          br 0 (;@19;)
                                        end
                                      end
                                    end
                                    local.get 144
                                    ref.null 137
                                    local.set 58
                                    ref.null 137
                                    local.set 57
                                    ref.null 133
                                    local.set 56
                                    ref.null 133
                                    local.set 55
                                  else
                                    local.get 152
                                    i32.const 0
                                    i32.eq
                                    local.get 152
                                    i32.const 1
                                    i32.eq
                                    i32.or
                                    if (result i32) ;; label = @17
                                      i32.const 1
                                    else
                                      local.get 152
                                      i32.const 2
                                      i32.eq
                                      if (result i32) ;; label = @18
                                        local.get 155
                                        local.get 137
                                        i64.eq
                                      else
                                        local.get 147
                                        local.get 138
                                        ref.eq
                                      end
                                    end
                                  end
                                end
                              end
                            else
                              i32.const 0
                            end
                            local.set 132
                            ref.null eq
                            local.set 147
                            ref.null 131
                            local.set 47
                            local.get 132
                            br_if 1 (;@11;)
                            local.get 153
                            i32.const 1
                            i32.add
                            local.set 153
                            br 0 (;@12;)
                          end
                        end
                        ref.null 83
                        local.set 143
                      end
                      local.get 132
                      if ;; label = @10
                        local.get 140
                        ref.as_non_null
                        ref.test (ref 79)
                        if ;; label = @11
                          local.get 140
                          ref.as_non_null
                          ref.cast (ref 79)
                          local.set 156
                          local.get 156
                          ref.as_non_null
                          struct.get 79 0
                          local.set 142
                          local.get 142
                          ref.as_non_null
                          struct.get 80 0
                          local.set 143
                          local.get 153
                          local.get 143
                          ref.as_non_null
                          array.len
                          i32.ge_u
                          local.get 153
                          i32.const 2
                          i32.ge_u
                          i32.or
                          if ;; label = @12
                            unreachable
                          end
                          ref.null 83
                          local.set 143
                          ref.null 80
                          local.set 142
                          local.get 156
                          ref.as_non_null
                          struct.get 79 1
                          local.set 91
                          local.get 91
                          local.get 153
                          i32.const 8
                          i32.mul
                          i32.shr_u
                          i32.const 255
                          i32.and
                          local.set 91
                          local.get 153
                          i32.eqz
                          if ;; label = @12
                            local.get 156
                            ref.as_non_null
                            struct.get 79 2
                            local.set 129
                            local.get 156
                            ref.as_non_null
                            struct.get 79 4
                            local.set 130
                          else
                            local.get 156
                            ref.as_non_null
                            struct.get 79 3
                            local.set 129
                            local.get 156
                            ref.as_non_null
                            struct.get 79 5
                            local.set 130
                          end
                          ref.null 79
                          local.set 156
                        else
                          local.get 140
                          ref.as_non_null
                          ref.cast (ref 78)
                          local.set 157
                          local.get 157
                          ref.as_non_null
                          struct.get 78 1
                          local.set 158
                          local.get 157
                          ref.as_non_null
                          struct.get 78 2
                          local.set 161
                          local.get 157
                          ref.as_non_null
                          struct.get 78 3
                          local.set 162
                          local.get 158
                          ref.as_non_null
                          local.get 153
                          array.get_u 84
                          local.set 91
                          i64.const 0
                          local.set 129
                          local.get 161
                          ref.is_null
                          i32.eqz
                          if ;; label = @12
                            local.get 161
                            ref.as_non_null
                            local.set 159
                            local.get 159
                            ref.as_non_null
                            local.get 153
                            array.get 85
                            local.set 129
                            ref.null 85
                            local.set 159
                          end
                          ref.null eq
                          local.set 130
                          local.get 162
                          ref.is_null
                          i32.eqz
                          if ;; label = @12
                            local.get 162
                            ref.as_non_null
                            local.set 160
                            local.get 160
                            ref.as_non_null
                            local.get 153
                            array.get 86
                            local.set 130
                            ref.null 86
                            local.set 160
                          end
                          ref.null 86
                          local.set 162
                          ref.null 85
                          local.set 161
                          ref.null 84
                          local.set 158
                          ref.null 78
                          local.set 157
                        end
                      end
                      ref.null 77
                      local.set 140
                    else
                      local.get 88
                      ref.as_non_null
                      local.get 141
                      local.get 137
                      local.get 138
                      call $helper::ordinary_property_find
                      local.set 163
                      ref.null 70
                      local.set 113
                      local.get 163
                      ref.is_null
                      i32.eqz
                      if ;; label = @10
                        local.get 163
                        ref.as_non_null
                        local.set 164
                        local.get 164
                        ref.as_non_null
                        struct.get 74 1
                        local.set 113
                        ref.null 74
                        local.set 164
                      end
                      local.get 113
                      ref.is_null
                      i32.eqz
                      if ;; label = @10
                        local.get 113
                        struct.get 70 0
                        local.set 136
                        local.get 136
                        i32.const 1
                        i32.and
                        i32.eqz
                        if ;; label = @11
                          local.get 113
                          struct.get 70 1
                          local.set 92
                          local.get 92
                          ref.as_non_null
                          ref.test (ref 62)
                          if ;; label = @12
                            local.get 92
                            ref.as_non_null
                            ref.cast (ref 62)
                            local.set 68
                            local.get 68
                            ref.as_non_null
                            struct.get 62 1
                            local.set 91
                            local.get 68
                            ref.as_non_null
                            struct.get 62 0
                            local.set 129
                            local.get 68
                            ref.as_non_null
                            struct.get 62 2
                            local.set 130
                            ref.null 62
                            local.set 68
                          else
                            local.get 92
                            ref.as_non_null
                            call $helper::property_value_resolve
                            local.set 84
                            local.get 84
                            ref.as_non_null
                            struct.get 62 1
                            local.set 91
                            local.get 84
                            ref.as_non_null
                            struct.get 62 0
                            local.set 129
                            local.get 84
                            ref.as_non_null
                            struct.get 62 2
                            local.set 130
                            ref.null 62
                            local.set 84
                          end
                          i32.const 1
                          local.set 132
                          ref.null 61
                          local.set 92
                        end
                      end
                      ref.null 70
                      local.set 113
                      ref.null 74
                      local.set 163
                    end
                    ref.null 76
                    local.set 139
                    ref.null 69
                    local.set 88
                  end
                  ref.null eq
                  local.set 138
                  local.get 94
                  i32.const 2
                  i32.eq
                  if (result i32) ;; label = @8
                    local.get 82
                    i64.eqz
                    i32.eqz
                  else
                    local.get 94
                    i32.const 4
                    i32.eq
                    if (result i32) ;; label = @9
                      local.get 126
                      ref.cast (ref 131)
                      local.set 47
                      local.get 47
                      ref.as_non_null
                      struct.get 131 0
                      local.set 46
                      local.get 46
                      ref.as_non_null
                      array.len
                      i32.eqz
                      i32.eqz
                      ref.null 132
                      local.set 46
                      ref.null 131
                      local.set 47
                    else
                      local.get 94
                      i32.const 3
                      i32.eq
                      if (result i32) ;; label = @10
                        local.get 82
                        f64.reinterpret_i64
                        f64.const 0x0p+0 (;=0;)
                        f64.eq
                        local.get 82
                        f64.reinterpret_i64
                        local.get 82
                        f64.reinterpret_i64
                        f64.ne
                        i32.or
                        i32.eqz
                      else
                        local.get 94
                        i32.const 10
                        i32.eq
                        if (result i32) ;; label = @11
                          local.get 126
                          ref.cast (ref 133)
                          local.set 56
                          local.get 56
                          ref.as_non_null
                          struct.get 133 1
                          local.set 58
                          local.get 58
                          ref.as_non_null
                          array.len
                          i32.eqz
                          i32.eqz
                          ref.null 137
                          local.set 58
                          ref.null 133
                          local.set 56
                        else
                          local.get 94
                          i32.const 0
                          i32.eq
                          local.get 94
                          i32.const 1
                          i32.eq
                          i32.or
                          if (result i32) ;; label = @12
                            i32.const 0
                          else
                            local.get 126
                            ref.test (ref 107)
                            if (result i32) ;; label = @13
                              local.get 126
                              ref.cast (ref 107)
                              local.set 124
                              local.get 124
                              ref.as_non_null
                              struct.get 107 11
                              local.set 141
                              local.get 141
                              ref.null 107
                              local.set 124
                            else
                              i32.const 0
                            end
                            i32.eqz
                          end
                        end
                      end
                    end
                  end
                  local.set 133
                  local.get 90
                  i32.const 2
                  i32.eq
                  if (result i32) ;; label = @8
                    local.get 127
                    i64.eqz
                    i32.eqz
                  else
                    local.get 90
                    i32.const 4
                    i32.eq
                    if (result i32) ;; label = @9
                      local.get 128
                      ref.cast (ref 131)
                      local.set 52
                      local.get 52
                      ref.as_non_null
                      struct.get 131 0
                      local.set 46
                      local.get 46
                      ref.as_non_null
                      array.len
                      i32.eqz
                      i32.eqz
                      ref.null 132
                      local.set 46
                      ref.null 131
                      local.set 52
                    else
                      local.get 90
                      i32.const 3
                      i32.eq
                      if (result i32) ;; label = @10
                        local.get 127
                        f64.reinterpret_i64
                        f64.const 0x0p+0 (;=0;)
                        f64.eq
                        local.get 127
                        f64.reinterpret_i64
                        local.get 127
                        f64.reinterpret_i64
                        f64.ne
                        i32.or
                        i32.eqz
                      else
                        local.get 90
                        i32.const 10
                        i32.eq
                        if (result i32) ;; label = @11
                          local.get 128
                          ref.cast (ref 133)
                          local.set 56
                          local.get 56
                          ref.as_non_null
                          struct.get 133 1
                          local.set 58
                          local.get 58
                          ref.as_non_null
                          array.len
                          i32.eqz
                          i32.eqz
                          ref.null 137
                          local.set 58
                          ref.null 133
                          local.set 56
                        else
                          local.get 90
                          i32.const 0
                          i32.eq
                          local.get 90
                          i32.const 1
                          i32.eq
                          i32.or
                          if (result i32) ;; label = @12
                            i32.const 0
                          else
                            local.get 128
                            ref.test (ref 107)
                            if (result i32) ;; label = @13
                              local.get 128
                              ref.cast (ref 107)
                              local.set 115
                              local.get 115
                              ref.as_non_null
                              struct.get 107 11
                              local.set 153
                              local.get 153
                              ref.null 107
                              local.set 115
                            else
                              i32.const 0
                            end
                            i32.eqz
                          end
                        end
                      end
                    end
                  end
                  local.set 134
                  local.get 91
                  i32.const 2
                  i32.eq
                  if (result i32) ;; label = @8
                    local.get 129
                    i64.eqz
                    i32.eqz
                  else
                    local.get 91
                    i32.const 4
                    i32.eq
                    if (result i32) ;; label = @9
                      local.get 130
                      ref.cast (ref 131)
                      local.set 52
                      local.get 52
                      ref.as_non_null
                      struct.get 131 0
                      local.set 46
                      local.get 46
                      ref.as_non_null
                      array.len
                      i32.eqz
                      i32.eqz
                      ref.null 132
                      local.set 46
                      ref.null 131
                      local.set 52
                    else
                      local.get 91
                      i32.const 3
                      i32.eq
                      if (result i32) ;; label = @10
                        local.get 129
                        f64.reinterpret_i64
                        f64.const 0x0p+0 (;=0;)
                        f64.eq
                        local.get 129
                        f64.reinterpret_i64
                        local.get 129
                        f64.reinterpret_i64
                        f64.ne
                        i32.or
                        i32.eqz
                      else
                        local.get 91
                        i32.const 10
                        i32.eq
                        if (result i32) ;; label = @11
                          local.get 130
                          ref.cast (ref 133)
                          local.set 56
                          local.get 56
                          ref.as_non_null
                          struct.get 133 1
                          local.set 58
                          local.get 58
                          ref.as_non_null
                          array.len
                          i32.eqz
                          i32.eqz
                          ref.null 137
                          local.set 58
                          ref.null 133
                          local.set 56
                        else
                          local.get 91
                          i32.const 0
                          i32.eq
                          local.get 91
                          i32.const 1
                          i32.eq
                          i32.or
                          if (result i32) ;; label = @12
                            i32.const 0
                          else
                            local.get 130
                            ref.test (ref 107)
                            if (result i32) ;; label = @13
                              local.get 130
                              ref.cast (ref 107)
                              local.set 115
                              local.get 115
                              ref.as_non_null
                              struct.get 107 11
                              local.set 153
                              local.get 153
                              ref.null 107
                              local.set 115
                            else
                              i32.const 0
                            end
                            i32.eqz
                          end
                        end
                      end
                    end
                  end
                  local.set 135
                  local.get 104
                  local.get 60
                  local.get 83
                  struct.new 62
                  local.set 68
                  local.get 78
                  local.get 111
                  local.get 112
                  struct.new 62
                  local.set 85
                  local.get 106
                  local.get 105
                  local.get 125
                  struct.new 62
                  local.set 84
                  local.get 131
                  if ;; label = @8
                    i32.const 1
                    local.get 134
                    i32.eqz
                    i32.eqz
                    i32.const 8
                    i32.mul
                    i32.or
                    local.get 135
                    i32.eqz
                    i32.eqz
                    i32.const 2
                    i32.mul
                    i32.or
                    local.get 68
                    ref.as_non_null
                    local.get 85
                    ref.as_non_null
                    local.get 84
                    ref.as_non_null
                    struct.new 70
                    local.set 87
                  else
                    i32.const 0
                    local.get 133
                    i32.eqz
                    i32.eqz
                    i32.const 4
                    i32.mul
                    i32.or
                    local.get 134
                    i32.eqz
                    i32.eqz
                    i32.const 8
                    i32.mul
                    i32.or
                    local.get 135
                    i32.eqz
                    i32.eqz
                    i32.const 2
                    i32.mul
                    i32.or
                    local.get 68
                    ref.as_non_null
                    local.get 85
                    ref.as_non_null
                    local.get 84
                    ref.as_non_null
                    struct.new 70
                    local.set 87
                  end
                  ref.null 62
                  local.set 84
                  ref.null 62
                  local.set 85
                  ref.null 62
                  local.set 68
                  ref.null eq
                  local.set 130
                  ref.null eq
                  local.set 128
                  ref.null eq
                  local.set 126
                  ref.null eq
                  local.set 125
                  ref.null eq
                  local.set 112
                  ref.null eq
                  local.set 83
                end
                ref.null eq
                local.set 79
              end
            end
            local.get 54
            local.set 30
            local.get 63
            local.set 31
            local.get 71
            local.set 32
            i32.const 0
            local.set 33
            i32.const 0
            local.set 34
            local.get 87
            ref.is_null
            i32.eqz
            local.get 87
            ref.is_null
            i32.eqz
            if (result i32) ;; label = @5
              local.get 87
              struct.get 70 0
              local.set 102
              local.get 102
              i32.const 2
              i32.and
              i32.eqz
              i32.eqz
            else
              i32.const 0
            end
            i32.eqz
            i32.and
            if ;; label = @5
              local.get 87
              ref.is_null
              i32.eqz
              if (result i32) ;; label = @6
                local.get 87
                struct.get 70 0
                local.set 81
                local.get 81
                i32.const 1
                i32.and
                i32.eqz
                i32.eqz
              else
                i32.const 0
              end
              if ;; label = @6
                i32.const 0
                local.set 153
                i64.const 0
                local.set 137
                ref.null eq
                local.set 147
                local.get 87
                ref.is_null
                i32.eqz
                if ;; label = @7
                  local.get 87
                  struct.get 70 2
                  local.set 84
                  local.get 84
                  ref.as_non_null
                  struct.get 62 1
                  local.set 153
                  local.get 84
                  ref.as_non_null
                  struct.get 62 0
                  local.set 137
                  local.get 84
                  ref.as_non_null
                  struct.get 62 2
                  local.set 147
                  ref.null 62
                  local.set 84
                end
                local.get 153
                i32.const 0
                i32.eq
                local.get 54
                i32.const 0
                i32.ne
                i32.and
                if ;; label = @7
                  local.get 11
                  local.set 69
                  ref.null 161
                  local.set 70
                  block ;; label = @8
                    loop ;; label = @9
                      local.get 69
                      ref.is_null
                      br_if 1 (;@8;)
                      local.get 69
                      struct.get 120 0
                      local.set 70
                      local.get 70
                      ref.is_null
                      i32.eqz
                      br_if 1 (;@8;)
                      local.get 69
                      struct.get 120 3
                      local.set 69
                      br 0 (;@9;)
                    end
                  end
                  local.get 70
                  ref.is_null
                  if ;; label = @8
                    global.get 8
                    ref.as_non_null
                    local.set 65
                    local.get 65
                    ref.as_non_null
                    local.set 70
                    ref.null 161
                    local.set 65
                  end
                  local.get 70
                  ref.as_non_null
                  local.set 65
                  ref.null 161
                  local.set 70
                  ref.null 120
                  local.set 69
                  local.get 65
                  ref.as_non_null
                  call $helper::realm_ensure_errors
                  local.get 65
                  ref.as_non_null
                  struct.get 161 5
                  local.set 72
                  i32.const 3
                  local.set 60
                  local.get 72
                  ref.as_non_null
                  local.get 60
                  array.get 163
                  local.set 84
                  ref.null 163
                  local.set 72
                  local.get 84
                  ref.as_non_null
                  struct.get 62 1
                  local.set 103
                  local.get 84
                  ref.as_non_null
                  struct.get 62 0
                  local.set 99
                  local.get 84
                  ref.as_non_null
                  struct.get 62 2
                  local.set 79
                  i32.const 0
                  local.get 103
                  i32.const 6
                  i32.eq
                  i32.or
                  local.get 103
                  i32.const 7
                  i32.eq
                  i32.or
                  local.get 103
                  i32.const 8
                  i32.eq
                  i32.or
                  local.get 103
                  i32.const 9
                  i32.eq
                  i32.or
                  i32.eqz
                  if ;; label = @8
                    unreachable
                  end
                  ref.null 62
                  local.set 84
                  i32.const 2457
                  local.set 111
                  local.get 111
                  call $helper::pooled_string_resolve
                  local.set 52
                  i32.const 5
                  local.get 103
                  local.get 99
                  local.get 79
                  local.get 52
                  ref.as_non_null
                  call $helper::runtime_error_for_throw
                  local.set 73
                  i32.const 6
                  local.set 111
                  i64.const 0
                  local.set 78
                  local.get 73
                  ref.as_non_null
                  local.set 112
                  local.get 111
                  local.set 30
                  local.get 78
                  local.set 31
                  local.get 112
                  local.set 32
                  i32.const 1
                  local.set 33
                  i32.const 0
                  local.set 34
                  ref.null eq
                  local.set 112
                  ref.null 220
                  local.set 73
                  ref.null 131
                  local.set 52
                  ref.null eq
                  local.set 79
                  ref.null 161
                  local.set 65
                end
              else
                local.get 87
                ref.is_null
                i32.eqz
                if (result i32) ;; label = @7
                  local.get 87
                  struct.get 70 0
                  local.set 105
                  local.get 105
                  i32.const 4
                  i32.and
                  i32.eqz
                  i32.eqz
                else
                  i32.const 0
                end
                i32.eqz
                if ;; label = @7
                  i32.const 0
                  local.set 153
                  i64.const 0
                  local.set 137
                  ref.null eq
                  local.set 147
                  local.get 87
                  ref.is_null
                  i32.eqz
                  if ;; label = @8
                    local.get 87
                    struct.get 70 1
                    local.set 92
                    local.get 92
                    ref.as_non_null
                    ref.test (ref 62)
                    if ;; label = @9
                      local.get 92
                      ref.as_non_null
                      ref.cast (ref 62)
                      local.set 84
                      local.get 84
                      ref.as_non_null
                      struct.get 62 1
                      local.set 153
                      local.get 84
                      ref.as_non_null
                      struct.get 62 0
                      local.set 137
                      local.get 84
                      ref.as_non_null
                      struct.get 62 2
                      local.set 147
                      ref.null 62
                      local.set 84
                    else
                      local.get 92
                      ref.as_non_null
                      call $helper::property_value_resolve
                      local.set 85
                      local.get 85
                      ref.as_non_null
                      struct.get 62 1
                      local.set 153
                      local.get 85
                      ref.as_non_null
                      struct.get 62 0
                      local.set 137
                      local.get 85
                      ref.as_non_null
                      struct.get 62 2
                      local.set 147
                      ref.null 62
                      local.set 85
                    end
                    ref.null 61
                    local.set 92
                  end
                  local.get 54
                  local.get 153
                  i32.eq
                  if (result i32) ;; label = @8
                    local.get 54
                    i32.const 3
                    i32.eq
                    if (result i32) ;; label = @9
                      local.get 63
                      local.get 137
                      i64.eq
                      local.get 63
                      f64.reinterpret_i64
                      local.get 63
                      f64.reinterpret_i64
                      f64.ne
                      local.get 137
                      f64.reinterpret_i64
                      local.get 137
                      f64.reinterpret_i64
                      f64.ne
                      i32.and
                      i32.or
                    else
                      local.get 54
                      i32.const 4
                      i32.eq
                      if (result i32) ;; label = @10
                        local.get 71
                        local.get 147
                        ref.eq
                        if (result i32) ;; label = @11
                          i32.const 1
                        else
                          local.get 71
                          ref.cast (ref 131)
                          local.set 45
                          local.get 147
                          ref.cast (ref 131)
                          local.set 51
                          i32.const 0
                          local.set 60
                          local.get 45
                          ref.as_non_null
                          local.get 51
                          ref.as_non_null
                          local.get 60
                          call $helper::string_equality
                          local.set 103
                          local.get 103
                          ref.null 131
                          local.set 51
                          ref.null 131
                          local.set 45
                        end
                      else
                        local.get 54
                        i32.const 10
                        i32.eq
                        if (result i32) ;; label = @11
                          local.get 71
                          ref.cast (ref 133)
                          local.set 56
                          local.get 147
                          ref.cast (ref 133)
                          local.set 55
                          local.get 56
                          ref.as_non_null
                          struct.get 133 0
                          local.set 102
                          local.get 55
                          ref.as_non_null
                          struct.get 133 0
                          local.set 60
                          local.get 56
                          ref.as_non_null
                          struct.get 133 1
                          local.set 58
                          local.get 55
                          ref.as_non_null
                          struct.get 133 1
                          local.set 57
                          local.get 58
                          ref.as_non_null
                          array.len
                          local.set 103
                          local.get 57
                          ref.as_non_null
                          array.len
                          local.set 111
                          local.get 102
                          local.get 60
                          i32.eq
                          local.get 103
                          local.get 111
                          i32.eq
                          i32.and
                          local.set 144
                          local.get 144
                          if ;; label = @12
                            i32.const 0
                            local.set 152
                            block ;; label = @13
                              loop ;; label = @14
                                local.get 152
                                local.get 103
                                i32.ge_u
                                br_if 1 (;@13;)
                                local.get 58
                                ref.as_non_null
                                local.get 152
                                array.get 137
                                local.set 99
                                local.get 57
                                ref.as_non_null
                                local.get 152
                                array.get 137
                                local.set 78
                                local.get 99
                                local.get 78
                                i64.eq
                                local.set 144
                                local.get 144
                                i32.eqz
                                br_if 1 (;@13;)
                                local.get 152
                                i32.const 1
                                i32.add
                                local.set 152
                                br 0 (;@14;)
                              end
                            end
                          end
                          local.get 144
                          ref.null 137
                          local.set 57
                          ref.null 137
                          local.set 58
                          ref.null 133
                          local.set 55
                          ref.null 133
                          local.set 56
                        else
                          local.get 54
                          i32.const 0
                          i32.eq
                          local.get 54
                          i32.const 1
                          i32.eq
                          i32.or
                          if (result i32) ;; label = @12
                            i32.const 1
                          else
                            local.get 54
                            i32.const 2
                            i32.eq
                            if (result i32) ;; label = @13
                              local.get 63
                              local.get 137
                              i64.eq
                            else
                              local.get 71
                              local.get 147
                              ref.eq
                            end
                          end
                        end
                      end
                    end
                  else
                    i32.const 0
                  end
                  i32.eqz
                  if ;; label = @8
                    local.get 11
                    local.set 69
                    ref.null 161
                    local.set 65
                    block ;; label = @9
                      loop ;; label = @10
                        local.get 69
                        ref.is_null
                        br_if 1 (;@9;)
                        local.get 69
                        struct.get 120 0
                        local.set 65
                        local.get 65
                        ref.is_null
                        i32.eqz
                        br_if 1 (;@9;)
                        local.get 69
                        struct.get 120 3
                        local.set 69
                        br 0 (;@10;)
                      end
                    end
                    local.get 65
                    ref.is_null
                    if ;; label = @9
                      global.get 8
                      ref.as_non_null
                      local.set 70
                      local.get 70
                      ref.as_non_null
                      local.set 65
                      ref.null 161
                      local.set 70
                    end
                    local.get 65
                    ref.as_non_null
                    local.set 70
                    ref.null 161
                    local.set 65
                    ref.null 120
                    local.set 69
                    local.get 70
                    ref.as_non_null
                    call $helper::realm_ensure_errors
                    local.get 70
                    ref.as_non_null
                    struct.get 161 5
                    local.set 72
                    i32.const 3
                    local.set 60
                    local.get 72
                    ref.as_non_null
                    local.get 60
                    array.get 163
                    local.set 85
                    ref.null 163
                    local.set 72
                    local.get 85
                    ref.as_non_null
                    struct.get 62 1
                    local.set 102
                    local.get 85
                    ref.as_non_null
                    struct.get 62 0
                    local.set 155
                    local.get 85
                    ref.as_non_null
                    struct.get 62 2
                    local.set 125
                    i32.const 0
                    local.get 102
                    i32.const 6
                    i32.eq
                    i32.or
                    local.get 102
                    i32.const 7
                    i32.eq
                    i32.or
                    local.get 102
                    i32.const 8
                    i32.eq
                    i32.or
                    local.get 102
                    i32.const 9
                    i32.eq
                    i32.or
                    i32.eqz
                    if ;; label = @9
                      unreachable
                    end
                    ref.null 62
                    local.set 85
                    i32.const 2456
                    local.set 94
                    local.get 94
                    call $helper::pooled_string_resolve
                    local.set 45
                    i32.const 5
                    local.get 102
                    local.get 155
                    local.get 125
                    local.get 45
                    ref.as_non_null
                    call $helper::runtime_error_for_throw
                    local.set 73
                    i32.const 6
                    local.set 103
                    i64.const 0
                    local.set 146
                    local.get 73
                    ref.as_non_null
                    local.set 79
                    local.get 103
                    local.set 30
                    local.get 146
                    local.set 31
                    local.get 79
                    local.set 32
                    i32.const 1
                    local.set 33
                    i32.const 0
                    local.set 34
                    ref.null eq
                    local.set 79
                    ref.null 220
                    local.set 73
                    ref.null 131
                    local.set 45
                    ref.null eq
                    local.set 125
                    ref.null 161
                    local.set 70
                  end
                end
              end
            end
            ref.null eq
            local.set 147
            ref.null 70
            local.set 87
          end
          ref.null eq
          local.set 77
          ref.null eq
          local.set 71
          ref.null eq
          local.set 75
        end
        ref.null eq
        local.set 67
        ref.null eq
        local.set 50
        ref.null 112
        local.set 66
      else
        block ;; label = @3
          i32.const 0
          local.set 152
          ref.null 69
          local.set 88
          local.get 37
          ref.test (ref 69)
          if ;; label = @4
            local.get 37
            ref.cast (ref 69)
            local.set 88
          else
            local.get 37
            ref.test (ref 107)
            if ;; label = @5
              local.get 37
              ref.cast (ref 107)
              local.set 115
              local.get 115
              ref.as_non_null
              struct.get 107 0
              local.set 165
              local.get 165
              ref.as_non_null
              struct.get 69 1
              local.set 139
              local.get 139
              ref.as_non_null
              ref.test (ref 77)
              if ;; label = @6
                local.get 165
                ref.as_non_null
                local.set 88
              end
              ref.null 76
              local.set 139
              ref.null 69
              local.set 165
              ref.null 107
              local.set 115
            end
          end
          local.get 88
          ref.is_null
          i32.eqz
          if ;; label = @4
            local.get 88
            ref.as_non_null
            local.set 165
            i32.const 0
            local.set 152
            local.get 165
            ref.as_non_null
            struct.get 69 1
            local.set 139
            local.get 139
            ref.as_non_null
            ref.test (ref 77)
            if ;; label = @5
              local.get 139
              ref.as_non_null
              ref.cast (ref 77)
              local.set 140
              i32.const 0
              local.set 152
              local.get 24
              i32.const 4
              i32.eq
              if ;; label = @6
                local.get 140
                ref.as_non_null
                struct.get 77 0
                local.set 142
                local.get 142
                ref.as_non_null
                struct.get 80 0
                local.set 143
                ref.null 80
                local.set 142
                local.get 143
                ref.as_non_null
                array.len
                local.set 59
                i32.const 0
                local.set 61
                block ;; label = @7
                  loop ;; label = @8
                    local.get 61
                    local.get 59
                    i32.ge_u
                    br_if 1 (;@7;)
                    local.get 143
                    ref.as_non_null
                    local.get 61
                    array.get 83
                    local.set 52
                    i32.const 4
                    local.set 54
                    i64.const 0
                    local.set 63
                    local.get 52
                    ref.as_non_null
                    local.set 67
                    local.get 54
                    local.get 24
                    i32.eq
                    if (result i32) ;; label = @9
                      local.get 54
                      i32.const 3
                      i32.eq
                      if (result i32) ;; label = @10
                        local.get 63
                        local.get 25
                        i64.eq
                        local.get 63
                        f64.reinterpret_i64
                        local.get 63
                        f64.reinterpret_i64
                        f64.ne
                        local.get 25
                        f64.reinterpret_i64
                        local.get 25
                        f64.reinterpret_i64
                        f64.ne
                        i32.and
                        i32.or
                      else
                        local.get 54
                        i32.const 4
                        i32.eq
                        if (result i32) ;; label = @11
                          local.get 67
                          local.get 26
                          ref.eq
                          if (result i32) ;; label = @12
                            i32.const 1
                          else
                            local.get 67
                            ref.cast (ref 131)
                            local.set 47
                            local.get 26
                            ref.cast (ref 131)
                            local.set 51
                            i32.const 0
                            local.set 44
                            local.get 47
                            ref.as_non_null
                            local.get 51
                            ref.as_non_null
                            local.get 44
                            call $helper::string_equality
                            local.set 53
                            local.get 53
                            ref.null 131
                            local.set 51
                            ref.null 131
                            local.set 47
                          end
                        else
                          local.get 54
                          i32.const 10
                          i32.eq
                          if (result i32) ;; label = @12
                            local.get 67
                            ref.cast (ref 133)
                            local.set 55
                            local.get 26
                            ref.cast (ref 133)
                            local.set 56
                            local.get 55
                            ref.as_non_null
                            struct.get 133 0
                            local.set 62
                            local.get 56
                            ref.as_non_null
                            struct.get 133 0
                            local.set 44
                            local.get 55
                            ref.as_non_null
                            struct.get 133 1
                            local.set 57
                            local.get 56
                            ref.as_non_null
                            struct.get 133 1
                            local.set 58
                            local.get 57
                            ref.as_non_null
                            array.len
                            local.set 53
                            local.get 58
                            ref.as_non_null
                            array.len
                            local.set 153
                            local.get 62
                            local.get 44
                            i32.eq
                            local.get 53
                            local.get 153
                            i32.eq
                            i32.and
                            local.set 151
                            local.get 151
                            if ;; label = @13
                              i32.const 0
                              local.set 111
                              block ;; label = @14
                                loop ;; label = @15
                                  local.get 111
                                  local.get 53
                                  i32.ge_u
                                  br_if 1 (;@14;)
                                  local.get 57
                                  ref.as_non_null
                                  local.get 111
                                  array.get 137
                                  local.set 137
                                  local.get 58
                                  ref.as_non_null
                                  local.get 111
                                  array.get 137
                                  local.set 155
                                  local.get 137
                                  local.get 155
                                  i64.eq
                                  local.set 151
                                  local.get 151
                                  i32.eqz
                                  br_if 1 (;@14;)
                                  local.get 111
                                  i32.const 1
                                  i32.add
                                  local.set 111
                                  br 0 (;@15;)
                                end
                              end
                            end
                            local.get 151
                            ref.null 137
                            local.set 58
                            ref.null 137
                            local.set 57
                            ref.null 133
                            local.set 56
                            ref.null 133
                            local.set 55
                          else
                            local.get 54
                            i32.const 0
                            i32.eq
                            local.get 54
                            i32.const 1
                            i32.eq
                            i32.or
                            if (result i32) ;; label = @13
                              i32.const 1
                            else
                              local.get 54
                              i32.const 2
                              i32.eq
                              if (result i32) ;; label = @14
                                local.get 63
                                local.get 25
                                i64.eq
                              else
                                local.get 67
                                local.get 26
                                ref.eq
                              end
                            end
                          end
                        end
                      end
                    else
                      i32.const 0
                    end
                    local.set 152
                    ref.null eq
                    local.set 67
                    ref.null 131
                    local.set 52
                    local.get 152
                    br_if 1 (;@7;)
                    local.get 61
                    i32.const 1
                    i32.add
                    local.set 61
                    br 0 (;@8;)
                  end
                end
                ref.null 83
                local.set 143
              end
              local.get 152
              if ;; label = @6
                local.get 140
                ref.as_non_null
                ref.test (ref 79)
                if ;; label = @7
                  local.get 140
                  ref.as_non_null
                  ref.cast (ref 79)
                  local.set 156
                  local.get 156
                  ref.as_non_null
                  struct.get 79 0
                  local.set 142
                  local.get 142
                  ref.as_non_null
                  struct.get 80 0
                  local.set 143
                  local.get 61
                  local.get 143
                  ref.as_non_null
                  array.len
                  i32.ge_u
                  local.get 61
                  i32.const 2
                  i32.ge_u
                  i32.or
                  if ;; label = @8
                    unreachable
                  end
                  ref.null 83
                  local.set 143
                  ref.null 80
                  local.set 142
                  local.get 156
                  ref.as_non_null
                  struct.get 79 1
                  local.set 60
                  local.get 60
                  local.get 61
                  i32.const 8
                  i32.mul
                  i32.shr_u
                  i32.const 255
                  i32.and
                  local.set 60
                  local.get 61
                  i32.eqz
                  if ;; label = @8
                    local.get 156
                    ref.as_non_null
                    struct.get 79 2
                    local.set 49
                    local.get 156
                    ref.as_non_null
                    struct.get 79 4
                    local.set 83
                  else
                    local.get 156
                    ref.as_non_null
                    struct.get 79 3
                    local.set 49
                    local.get 156
                    ref.as_non_null
                    struct.get 79 5
                    local.set 83
                  end
                  ref.null 79
                  local.set 156
                else
                  local.get 140
                  ref.as_non_null
                  ref.cast (ref 78)
                  local.set 157
                  local.get 157
                  ref.as_non_null
                  struct.get 78 1
                  local.set 158
                  local.get 157
                  ref.as_non_null
                  struct.get 78 2
                  local.set 161
                  local.get 157
                  ref.as_non_null
                  struct.get 78 3
                  local.set 160
                  local.get 158
                  ref.as_non_null
                  local.get 61
                  array.get_u 84
                  local.set 60
                  i64.const 0
                  local.set 49
                  local.get 161
                  ref.is_null
                  i32.eqz
                  if ;; label = @8
                    local.get 161
                    ref.as_non_null
                    local.set 159
                    local.get 159
                    ref.as_non_null
                    local.get 61
                    array.get 85
                    local.set 49
                    ref.null 85
                    local.set 159
                  end
                  ref.null eq
                  local.set 83
                  local.get 160
                  ref.is_null
                  i32.eqz
                  if ;; label = @8
                    local.get 160
                    ref.as_non_null
                    local.set 162
                    local.get 162
                    ref.as_non_null
                    local.get 61
                    array.get 86
                    local.set 83
                    ref.null 86
                    local.set 162
                  end
                  ref.null 86
                  local.set 160
                  ref.null 85
                  local.set 161
                  ref.null 84
                  local.set 158
                  ref.null 78
                  local.set 157
                end
              end
              ref.null 77
              local.set 140
            else
              local.get 165
              ref.as_non_null
              local.get 24
              local.get 25
              local.get 26
              call $helper::ordinary_property_find
              local.set 164
              ref.null 70
              local.set 87
              local.get 164
              ref.is_null
              i32.eqz
              if ;; label = @6
                local.get 164
                ref.as_non_null
                local.set 163
                local.get 163
                ref.as_non_null
                struct.get 74 1
                local.set 87
                ref.null 74
                local.set 163
              end
              local.get 87
              ref.is_null
              i32.eqz
              if ;; label = @6
                local.get 87
                struct.get 70 0
                local.set 61
                local.get 61
                i32.const 1
                i32.and
                i32.eqz
                if ;; label = @7
                  local.get 87
                  struct.get 70 1
                  local.set 92
                  local.get 92
                  ref.as_non_null
                  ref.test (ref 62)
                  if ;; label = @8
                    local.get 92
                    ref.as_non_null
                    ref.cast (ref 62)
                    local.set 85
                    local.get 85
                    ref.as_non_null
                    struct.get 62 1
                    local.set 60
                    local.get 85
                    ref.as_non_null
                    struct.get 62 0
                    local.set 49
                    local.get 85
                    ref.as_non_null
                    struct.get 62 2
                    local.set 83
                    ref.null 62
                    local.set 85
                  else
                    local.get 92
                    ref.as_non_null
                    call $helper::property_value_resolve
                    local.set 84
                    local.get 84
                    ref.as_non_null
                    struct.get 62 1
                    local.set 60
                    local.get 84
                    ref.as_non_null
                    struct.get 62 0
                    local.set 49
                    local.get 84
                    ref.as_non_null
                    struct.get 62 2
                    local.set 83
                    ref.null 62
                    local.set 84
                  end
                  i32.const 1
                  local.set 152
                  ref.null 61
                  local.set 92
                end
              end
              ref.null 70
              local.set 87
              ref.null 74
              local.set 164
            end
            ref.null 76
            local.set 139
            local.get 152
            if ;; label = @5
              local.get 60
              local.set 30
              local.get 49
              local.set 31
              local.get 83
              local.set 32
              i32.const 0
              local.set 33
              i32.const 0
              local.set 34
            end
            ref.null eq
            local.set 83
            ref.null 69
            local.set 165
          end
          ref.null 69
          local.set 88
          local.get 152
          br_if 0 (;@3;)
          i32.const 0
          local.set 59
          local.get 37
          ref.test (ref 139)
          if ;; label = @4
            local.get 37
            ref.cast (ref 139)
            local.set 95
            i32.const 0
            local.set 60
            local.get 24
            i32.const 4
            i32.eq
            if ;; label = @5
              local.get 26
              ref.cast (ref 131)
              local.set 47
              local.get 47
              ref.as_non_null
              struct.get 131 0
              local.set 46
              local.get 46
              ref.as_non_null
              array.len
              i32.const 6
              i32.eq
              if ;; label = @6
                i32.const 140
                local.set 61
                local.get 61
                call $helper::pooled_string_resolve
                local.set 52
                i32.const 4
                local.set 149
                i64.const 0
                local.set 49
                local.get 52
                ref.as_non_null
                local.set 83
                local.get 24
                local.get 149
                i32.eq
                if (result i32) ;; label = @7
                  local.get 24
                  i32.const 3
                  i32.eq
                  if (result i32) ;; label = @8
                    local.get 25
                    local.get 49
                    i64.eq
                    local.get 25
                    f64.reinterpret_i64
                    local.get 25
                    f64.reinterpret_i64
                    f64.ne
                    local.get 49
                    f64.reinterpret_i64
                    local.get 49
                    f64.reinterpret_i64
                    f64.ne
                    i32.and
                    i32.or
                  else
                    local.get 24
                    i32.const 4
                    i32.eq
                    if (result i32) ;; label = @9
                      local.get 26
                      local.get 83
                      ref.eq
                      if (result i32) ;; label = @10
                        i32.const 1
                      else
                        local.get 26
                        ref.cast (ref 131)
                        local.set 51
                        local.get 83
                        ref.cast (ref 131)
                        local.set 45
                        i32.const 0
                        local.set 61
                        local.get 51
                        ref.as_non_null
                        local.get 45
                        ref.as_non_null
                        local.get 61
                        call $helper::string_equality
                        local.set 148
                        local.get 148
                        ref.null 131
                        local.set 45
                        ref.null 131
                        local.set 51
                      end
                    else
                      local.get 24
                      i32.const 10
                      i32.eq
                      if (result i32) ;; label = @10
                        local.get 26
                        ref.cast (ref 133)
                        local.set 55
                        local.get 83
                        ref.cast (ref 133)
                        local.set 56
                        local.get 55
                        ref.as_non_null
                        struct.get 133 0
                        local.set 141
                        local.get 56
                        ref.as_non_null
                        struct.get 133 0
                        local.set 61
                        local.get 55
                        ref.as_non_null
                        struct.get 133 1
                        local.set 58
                        local.get 56
                        ref.as_non_null
                        struct.get 133 1
                        local.set 57
                        local.get 58
                        ref.as_non_null
                        array.len
                        local.set 148
                        local.get 57
                        ref.as_non_null
                        array.len
                        local.set 44
                        local.get 141
                        local.get 61
                        i32.eq
                        local.get 148
                        local.get 44
                        i32.eq
                        i32.and
                        local.set 53
                        local.get 53
                        if ;; label = @11
                          i32.const 0
                          local.set 62
                          block ;; label = @12
                            loop ;; label = @13
                              local.get 62
                              local.get 148
                              i32.ge_u
                              br_if 1 (;@12;)
                              local.get 58
                              ref.as_non_null
                              local.get 62
                              array.get 137
                              local.set 64
                              local.get 57
                              ref.as_non_null
                              local.get 62
                              array.get 137
                              local.set 63
                              local.get 64
                              local.get 63
                              i64.eq
                              local.set 53
                              local.get 53
                              i32.eqz
                              br_if 1 (;@12;)
                              local.get 62
                              i32.const 1
                              i32.add
                              local.set 62
                              br 0 (;@13;)
                            end
                          end
                        end
                        local.get 53
                        ref.null 137
                        local.set 57
                        ref.null 137
                        local.set 58
                        ref.null 133
                        local.set 56
                        ref.null 133
                        local.set 55
                      else
                        local.get 24
                        i32.const 0
                        i32.eq
                        local.get 24
                        i32.const 1
                        i32.eq
                        i32.or
                        if (result i32) ;; label = @11
                          i32.const 1
                        else
                          local.get 24
                          i32.const 2
                          i32.eq
                          if (result i32) ;; label = @12
                            local.get 25
                            local.get 49
                            i64.eq
                          else
                            local.get 26
                            local.get 83
                            ref.eq
                          end
                        end
                      end
                    end
                  end
                else
                  i32.const 0
                end
                local.set 60
                ref.null eq
                local.set 83
                ref.null 131
                local.set 52
              end
              ref.null 132
              local.set 46
              ref.null 131
              local.set 47
            end
            local.get 60
            if ;; label = @5
              local.get 95
              ref.as_non_null
              struct.get 139 2
              local.set 74
              local.get 74
              f64.convert_i64_u
              i64.reinterpret_f64
              local.set 74
              i32.const 3
              local.set 102
              local.get 74
              local.set 74
              ref.null eq
              local.set 125
              local.get 102
              local.set 30
              local.get 74
              local.set 31
              local.get 125
              local.set 32
              i32.const 0
              local.set 33
              i32.const 0
              local.set 34
              i32.const 1
              local.set 59
            else
              ref.null 70
              local.set 87
              i32.const 0
              local.set 151
              local.get 24
              i32.const 4
              i32.eq
              if ;; label = @6
                local.get 26
                ref.cast (ref 131)
                local.set 47
                local.get 47
                ref.as_non_null
                struct.get 131 0
                local.set 46
                local.get 46
                ref.as_non_null
                array.len
                local.set 149
                block ;; label = @7
                  local.get 149
                  i32.eqz
                  local.get 149
                  i32.const 10
                  i32.gt_u
                  i32.or
                  br_if 0 (;@7;)
                  i32.const 0
                  local.set 153
                  local.get 46
                  ref.as_non_null
                  local.get 153
                  array.get_u 132
                  local.set 94
                  local.get 94
                  i32.const 48
                  i32.eq
                  if ;; label = @8
                    i32.const 0
                    local.set 111
                    local.get 149
                    i32.const 1
                    i32.eq
                    local.set 151
                    br 1 (;@7;)
                  end
                  i64.const 0
                  local.set 49
                  loop ;; label = @8
                    local.get 46
                    ref.as_non_null
                    local.get 153
                    array.get_u 132
                    local.set 94
                    local.get 94
                    i32.const 48
                    i32.sub
                    local.set 94
                    local.get 94
                    i32.const 9
                    i32.gt_u
                    br_if 1 (;@7;)
                    local.get 49
                    i64.const 10
                    i64.mul
                    local.get 94
                    i64.extend_i32_u
                    i64.add
                    local.set 49
                    local.get 153
                    i32.const 1
                    i32.add
                    local.set 153
                    local.get 153
                    local.get 149
                    i32.lt_u
                    br_if 0 (;@8;)
                  end
                  local.get 49
                  i64.const 4294967295
                  i64.lt_u
                  if ;; label = @8
                    local.get 49
                    i32.wrap_i64
                    local.set 111
                    i32.const 1
                    local.set 151
                  end
                end
                ref.null 132
                local.set 46
                ref.null 131
                local.set 47
              end
              local.get 151
              if ;; label = @6
                local.get 111
                i64.extend_i32_u
                local.set 154
                i32.const 0
                local.set 141
                local.get 95
                ref.as_non_null
                local.set 93
                local.get 93
                ref.as_non_null
                struct.get 139 6
                i32.const 2
                i32.eq
                local.get 93
                ref.as_non_null
                struct.get 139 6
                i32.const 3
                i32.eq
                i32.or
                if ;; label = @7
                  local.get 93
                  ref.as_non_null
                  struct.get 139 6
                  i32.const 3
                  i32.eq
                  if ;; label = @8
                    local.get 93
                    ref.as_non_null
                    struct.get 139 9
                    ref.as_non_null
                    local.set 96
                    local.get 154
                    local.get 96
                    ref.as_non_null
                    array.len
                    i64.extend_i32_u
                    i64.lt_u
                    if ;; label = @9
                      local.get 154
                      i32.wrap_i64
                      local.set 153
                      local.get 96
                      ref.as_non_null
                      local.get 153
                      array.get 93
                      local.set 84
                      local.get 84
                      ref.is_null
                      i32.eqz
                      if ;; label = @10
                        local.get 84
                        ref.as_non_null
                        local.set 85
                        local.get 85
                        ref.as_non_null
                        struct.get 62 1
                        local.set 102
                        local.get 85
                        ref.as_non_null
                        struct.get 62 0
                        local.set 74
                        local.get 85
                        ref.as_non_null
                        struct.get 62 2
                        local.set 125
                        ref.null 62
                        local.set 85
                        i32.const 1
                        local.set 141
                      end
                      ref.null 62
                      local.set 84
                    end
                    ref.null 93
                    local.set 96
                  else
                    local.get 93
                    ref.as_non_null
                    struct.get 139 7
                    local.set 97
                    local.get 93
                    ref.as_non_null
                    struct.get 139 8
                    local.set 108
                    local.get 154
                    local.get 97
                    ref.as_non_null
                    array.len
                    i64.extend_i32_u
                    i64.lt_u
                    if ;; label = @9
                      local.get 154
                      i32.wrap_i64
                      local.set 94
                      local.get 94
                      i32.const 6
                      i32.shr_u
                      local.set 149
                      i64.const 1
                      local.get 94
                      i64.extend_i32_u
                      i64.shl
                      local.set 49
                      local.get 108
                      ref.as_non_null
                      local.get 149
                      array.get 95
                      local.set 106
                      local.get 106
                      local.get 49
                      i64.and
                      i64.eqz
                      i32.eqz
                      if ;; label = @10
                        local.get 97
                        ref.as_non_null
                        local.get 94
                        array.get 94
                        local.set 106
                        i32.const 3
                        local.set 102
                        local.get 106
                        local.set 74
                        ref.null eq
                        local.set 125
                        i32.const 1
                        local.set 141
                      end
                    end
                    ref.null 95
                    local.set 108
                    ref.null 94
                    local.set 97
                  end
                else
                  local.get 95
                  ref.as_non_null
                  local.set 166
                  local.get 166
                  ref.as_non_null
                  struct.get 139 6
                  i32.const 2
                  i32.eq
                  local.get 166
                  ref.as_non_null
                  struct.get 139 6
                  i32.const 3
                  i32.eq
                  i32.or
                  if ;; label = @8
                    i32.const 0
                    local.set 153
                    local.get 166
                    ref.as_non_null
                    struct.get 139 6
                    i32.const 3
                    i32.eq
                    if ;; label = @9
                      local.get 166
                      ref.as_non_null
                      struct.get 139 9
                      ref.as_non_null
                      local.set 96
                      local.get 154
                      local.get 96
                      ref.as_non_null
                      array.len
                      i64.extend_i32_u
                      i64.lt_u
                      if ;; label = @10
                        local.get 154
                        i32.wrap_i64
                        local.set 150
                        local.get 96
                        ref.as_non_null
                        local.get 150
                        array.get 93
                        local.set 84
                        local.get 84
                        ref.is_null
                        i32.eqz
                        if ;; label = @11
                          i32.const 1
                          local.set 153
                        end
                        ref.null 62
                        local.set 84
                      end
                      ref.null 93
                      local.set 96
                    else
                      local.get 166
                      ref.as_non_null
                      struct.get 139 7
                      local.set 97
                      local.get 166
                      ref.as_non_null
                      struct.get 139 8
                      local.set 108
                      local.get 154
                      local.get 97
                      ref.as_non_null
                      array.len
                      i64.extend_i32_u
                      i64.lt_u
                      if ;; label = @10
                        local.get 154
                        i32.wrap_i64
                        local.set 149
                        local.get 149
                        i32.const 6
                        i32.shr_u
                        local.set 150
                        i64.const 1
                        local.get 149
                        i64.extend_i32_u
                        i64.shl
                        local.set 49
                        local.get 108
                        ref.as_non_null
                        local.get 150
                        array.get 95
                        local.set 106
                        local.get 106
                        local.get 49
                        i64.and
                        i64.eqz
                        i32.eqz
                        if ;; label = @11
                          i32.const 1
                          local.set 153
                        end
                      end
                      ref.null 95
                      local.set 108
                      ref.null 94
                      local.set 97
                    end
                    local.get 153
                    if ;; label = @9
                      local.get 166
                      ref.as_non_null
                      struct.get 139 6
                      i32.const 3
                      i32.eq
                      if ;; label = @10
                        local.get 166
                        ref.as_non_null
                        struct.get 139 9
                        ref.as_non_null
                        local.set 96
                        local.get 96
                        ref.as_non_null
                        array.len
                        local.set 148
                        ref.null 70
                        local.get 148
                        array.new 92
                        local.set 100
                        i32.const 0
                        local.set 149
                        global.get 30
                        local.set 84
                        block ;; label = @11
                          loop ;; label = @12
                            local.get 149
                            local.get 148
                            i32.ge_u
                            br_if 1 (;@11;)
                            local.get 96
                            ref.as_non_null
                            local.get 149
                            array.get 93
                            local.set 85
                            local.get 85
                            ref.is_null
                            i32.eqz
                            if ;; label = @13
                              local.get 85
                              ref.as_non_null
                              local.set 68
                              i32.const 14
                              local.get 68
                              ref.as_non_null
                              local.get 84
                              ref.as_non_null
                              local.get 84
                              ref.as_non_null
                              struct.new 70
                              local.set 101
                              ref.null 62
                              local.set 68
                              local.get 100
                              ref.as_non_null
                              local.get 149
                              local.get 101
                              ref.as_non_null
                              array.set 92
                              ref.null 70
                              local.set 101
                            end
                            ref.null 62
                            local.set 85
                            local.get 149
                            i32.const 1
                            i32.add
                            local.set 149
                            br 0 (;@12;)
                          end
                        end
                        local.get 166
                        ref.as_non_null
                        local.get 100
                        ref.as_non_null
                        struct.set 139 5
                        global.get 28
                        local.set 97
                        global.get 29
                        local.set 108
                        local.get 166
                        ref.as_non_null
                        local.get 97
                        ref.as_non_null
                        struct.set 139 7
                        local.get 166
                        ref.as_non_null
                        local.get 108
                        ref.as_non_null
                        struct.set 139 8
                        local.get 166
                        ref.as_non_null
                        ref.null 93
                        struct.set 139 9
                        ref.null 95
                        local.set 108
                        ref.null 94
                        local.set 97
                        local.get 166
                        ref.as_non_null
                        i32.const 0
                        struct.set 139 6
                        ref.null 62
                        local.set 84
                        ref.null 92
                        local.set 100
                        ref.null 93
                        local.set 96
                      else
                        local.get 166
                        ref.as_non_null
                        struct.get 139 6
                        i32.const 2
                        i32.eq
                        if ;; label = @11
                          local.get 166
                          ref.as_non_null
                          struct.get 139 7
                          local.set 107
                          local.get 166
                          ref.as_non_null
                          struct.get 139 8
                          local.set 98
                          local.get 107
                          ref.as_non_null
                          array.len
                          local.set 150
                          ref.null 70
                          local.get 150
                          array.new 92
                          local.set 100
                          i32.const 0
                          local.set 148
                          i32.const 0
                          local.set 53
                          i64.const 0
                          local.set 63
                          ref.null eq
                          local.set 75
                          block ;; label = @12
                            loop ;; label = @13
                              local.get 148
                              local.get 150
                              i32.ge_u
                              br_if 1 (;@12;)
                              local.get 148
                              i32.const 6
                              i32.shr_u
                              local.set 149
                              i64.const 1
                              local.get 148
                              i64.extend_i32_u
                              i64.shl
                              local.set 49
                              local.get 98
                              ref.as_non_null
                              local.get 149
                              array.get 95
                              local.set 106
                              local.get 106
                              local.get 49
                              i64.and
                              i64.eqz
                              i32.eqz
                              if ;; label = @14
                                local.get 107
                                ref.as_non_null
                                local.get 148
                                array.get 94
                                local.set 106
                                i32.const 3
                                local.set 62
                                local.get 106
                                local.set 76
                                ref.null eq
                                local.set 71
                                local.get 76
                                local.get 62
                                local.get 71
                                struct.new 62
                                local.set 84
                                global.get 30
                                local.set 68
                                i32.const 14
                                local.get 84
                                ref.as_non_null
                                local.get 68
                                ref.as_non_null
                                local.get 68
                                ref.as_non_null
                                struct.new 70
                                local.set 101
                                ref.null 62
                                local.set 68
                                ref.null 62
                                local.set 84
                                local.get 100
                                ref.as_non_null
                                local.get 148
                                local.get 101
                                ref.as_non_null
                                array.set 92
                                ref.null 70
                                local.set 101
                              end
                              local.get 148
                              i32.const 1
                              i32.add
                              local.set 148
                              br 0 (;@13;)
                            end
                          end
                          local.get 166
                          ref.as_non_null
                          local.get 100
                          ref.as_non_null
                          struct.set 139 5
                          global.get 28
                          local.set 97
                          global.get 29
                          local.set 108
                          local.get 166
                          ref.as_non_null
                          local.get 97
                          ref.as_non_null
                          struct.set 139 7
                          local.get 166
                          ref.as_non_null
                          local.get 108
                          ref.as_non_null
                          struct.set 139 8
                          local.get 166
                          ref.as_non_null
                          ref.null 93
                          struct.set 139 9
                          ref.null 95
                          local.set 108
                          ref.null 94
                          local.set 97
                          local.get 166
                          ref.as_non_null
                          i32.const 0
                          struct.set 139 6
                          ref.null eq
                          local.set 75
                          ref.null eq
                          local.set 71
                          ref.null 92
                          local.set 100
                          ref.null 95
                          local.set 98
                          ref.null 94
                          local.set 107
                        end
                      end
                    end
                  end
                  local.get 166
                  ref.as_non_null
                  struct.get 139 4
                  local.set 109
                  local.get 109
                  ref.as_non_null
                  array.len
                  local.set 103
                  ref.null 70
                  local.set 101
                  local.get 166
                  ref.as_non_null
                  struct.get 139 6
                  i32.const 0
                  i32.eq
                  if ;; label = @8
                    local.get 166
                    ref.as_non_null
                    struct.get 139 5
                    local.set 100
                    local.get 154
                    local.get 100
                    ref.as_non_null
                    array.len
                    i64.extend_i32_u
                    i64.lt_u
                    if ;; label = @9
                      local.get 154
                      i32.wrap_i64
                      local.set 153
                      local.get 100
                      ref.as_non_null
                      local.get 153
                      array.get 92
                      local.set 101
                    end
                    ref.null 92
                    local.set 100
                  else
                    local.get 103
                    if ;; label = @9
                      local.get 154
                      i32.wrap_i64
                      local.set 150
                      local.get 150
                      local.get 150
                      i32.const 16
                      i32.shr_u
                      i32.xor
                      i32.const 2146121005
                      i32.mul
                      local.set 150
                      local.get 150
                      local.get 150
                      i32.const 15
                      i32.shr_u
                      i32.xor
                      i32.const -2073254261
                      i32.mul
                      local.set 150
                      local.get 150
                      local.get 150
                      i32.const 16
                      i32.shr_u
                      i32.xor
                      local.get 103
                      i32.const 1
                      i32.sub
                      i32.and
                      local.set 150
                      local.get 109
                      ref.as_non_null
                      local.get 150
                      array.get 97
                      local.set 110
                      block ;; label = @10
                        loop ;; label = @11
                          local.get 110
                          ref.is_null
                          br_if 1 (;@10;)
                          local.get 110
                          struct.get 96 0
                          local.set 155
                          local.get 155
                          local.get 154
                          i64.eq
                          if ;; label = @12
                            local.get 110
                            struct.get 96 1
                            local.set 101
                            br 2 (;@10;)
                          end
                          local.get 110
                          struct.get 96 2
                          local.set 110
                          br 0 (;@11;)
                        end
                      end
                      ref.null 96
                      local.set 110
                    end
                  end
                  ref.null 97
                  local.set 109
                  ref.null 139
                  local.set 166
                  local.get 101
                  ref.is_null
                  i32.eqz
                  if ;; label = @8
                    local.get 101
                    ref.as_non_null
                    local.set 89
                    local.get 89
                    ref.as_non_null
                    struct.get 70 0
                    local.set 153
                    local.get 153
                    i32.const 1
                    i32.and
                    i32.eqz
                    if ;; label = @9
                      local.get 89
                      ref.as_non_null
                      struct.get 70 1
                      local.set 92
                      local.get 92
                      ref.as_non_null
                      ref.test (ref 62)
                      if ;; label = @10
                        local.get 92
                        ref.as_non_null
                        ref.cast (ref 62)
                        local.set 84
                        local.get 84
                        ref.as_non_null
                        struct.get 62 1
                        local.set 102
                        local.get 84
                        ref.as_non_null
                        struct.get 62 0
                        local.set 74
                        local.get 84
                        ref.as_non_null
                        struct.get 62 2
                        local.set 125
                        ref.null 62
                        local.set 84
                      else
                        local.get 92
                        ref.as_non_null
                        call $helper::property_value_resolve
                        local.set 85
                        local.get 85
                        ref.as_non_null
                        struct.get 62 1
                        local.set 102
                        local.get 85
                        ref.as_non_null
                        struct.get 62 0
                        local.set 74
                        local.get 85
                        ref.as_non_null
                        struct.get 62 2
                        local.set 125
                        ref.null 62
                        local.set 85
                      end
                      i32.const 1
                      local.set 141
                      ref.null 61
                      local.set 92
                    end
                    ref.null 70
                    local.set 89
                  end
                  ref.null 70
                  local.set 101
                end
                ref.null 139
                local.set 93
                local.get 141
                if ;; label = @7
                  local.get 102
                  local.set 30
                  local.get 74
                  local.set 31
                  local.get 125
                  local.set 32
                  i32.const 0
                  local.set 33
                  i32.const 0
                  local.set 34
                  i32.const 1
                  local.set 59
                end
              else
                local.get 95
                ref.as_non_null
                struct.get 139 0
                local.set 165
                local.get 165
                ref.as_non_null
                local.get 24
                local.get 25
                local.get 26
                call $helper::ordinary_own_descriptor
                local.set 113
                local.get 113
                local.set 87
                ref.null 70
                local.set 113
                ref.null 69
                local.set 165
              end
              local.get 87
              ref.is_null
              i32.eqz
              if ;; label = @6
                local.get 87
                ref.as_non_null
                local.set 89
                local.get 89
                ref.as_non_null
                struct.get 70 0
                local.set 150
                local.get 150
                i32.const 1
                i32.and
                i32.eqz
                if ;; label = @7
                  local.get 89
                  ref.as_non_null
                  struct.get 70 1
                  local.set 92
                  local.get 92
                  ref.as_non_null
                  ref.test (ref 62)
                  if ;; label = @8
                    local.get 92
                    ref.as_non_null
                    ref.cast (ref 62)
                    local.set 84
                    local.get 84
                    ref.as_non_null
                    struct.get 62 1
                    local.set 102
                    local.get 84
                    ref.as_non_null
                    struct.get 62 0
                    local.set 74
                    local.get 84
                    ref.as_non_null
                    struct.get 62 2
                    local.set 125
                    ref.null 62
                    local.set 84
                  else
                    local.get 92
                    ref.as_non_null
                    call $helper::property_value_resolve
                    local.set 68
                    local.get 68
                    ref.as_non_null
                    struct.get 62 1
                    local.set 102
                    local.get 68
                    ref.as_non_null
                    struct.get 62 0
                    local.set 74
                    local.get 68
                    ref.as_non_null
                    struct.get 62 2
                    local.set 125
                    ref.null 62
                    local.set 68
                  end
                  local.get 102
                  local.set 30
                  local.get 74
                  local.set 31
                  local.get 125
                  local.set 32
                  i32.const 0
                  local.set 33
                  i32.const 0
                  local.set 34
                  i32.const 1
                  local.set 59
                  ref.null 61
                  local.set 92
                end
                ref.null 70
                local.set 89
              end
              ref.null 70
              local.set 87
            end
            ref.null eq
            local.set 125
            ref.null 139
            local.set 95
          end
          local.get 59
          br_if 0 (;@3;)
          ref.null 70
          local.set 113
          local.get 37
          ref.test (ref 69)
          if ;; label = @4
            local.get 37
            ref.cast (ref 69)
            local.set 88
            local.get 88
            ref.as_non_null
            local.get 24
            local.get 25
            local.get 26
            call $helper::ordinary_own_descriptor
            local.set 101
            local.get 101
            ref.is_null
            i32.eqz
            if ;; label = @5
              local.get 101
              ref.is_null
              i32.eqz
              if (result i32) ;; label = @6
                local.get 101
                struct.get 70 0
                local.set 103
                local.get 103
                i32.const 4
                i32.and
                i32.eqz
                i32.eqz
              else
                i32.const 0
              end
              local.set 151
              local.get 101
              ref.is_null
              i32.eqz
              if (result i32) ;; label = @6
                local.get 101
                struct.get 70 0
                local.set 102
                local.get 102
                i32.const 8
                i32.and
                i32.eqz
                i32.eqz
              else
                i32.const 0
              end
              local.set 148
              local.get 101
              ref.is_null
              i32.eqz
              if (result i32) ;; label = @6
                local.get 101
                struct.get 70 0
                local.set 103
                local.get 103
                i32.const 2
                i32.and
                i32.eqz
                i32.eqz
              else
                i32.const 0
              end
              local.set 60
              local.get 101
              struct.get 70 1
              local.set 92
              local.get 101
              struct.get 70 2
              local.set 84
              local.get 101
              struct.get 70 3
              local.set 85
              local.get 101
              ref.is_null
              i32.eqz
              if (result i32) ;; label = @6
                local.get 101
                struct.get 70 0
                local.set 102
                local.get 102
                i32.const 1
                i32.and
                i32.eqz
                i32.eqz
              else
                i32.const 0
              end
              if ;; label = @6
                i32.const 1
                local.get 148
                i32.eqz
                i32.eqz
                i32.const 8
                i32.mul
                i32.or
                local.get 60
                i32.eqz
                i32.eqz
                i32.const 2
                i32.mul
                i32.or
                local.get 92
                ref.as_non_null
                local.get 84
                ref.as_non_null
                local.get 85
                ref.as_non_null
                struct.new 70
                local.set 113
              else
                i32.const 0
                local.get 151
                i32.eqz
                i32.eqz
                i32.const 4
                i32.mul
                i32.or
                local.get 148
                i32.eqz
                i32.eqz
                i32.const 8
                i32.mul
                i32.or
                local.get 60
                i32.eqz
                i32.eqz
                i32.const 2
                i32.mul
                i32.or
                local.get 92
                ref.as_non_null
                local.get 84
                ref.as_non_null
                local.get 85
                ref.as_non_null
                struct.new 70
                local.set 113
              end
              ref.null 62
              local.set 85
              ref.null 62
              local.set 84
              ref.null 61
              local.set 92
            end
            ref.null 70
            local.set 101
            ref.null 69
            local.set 88
          else
            local.get 37
            ref.test (ref 139)
            if ;; label = @5
              local.get 37
              ref.cast (ref 139)
              local.set 95
              local.get 95
              ref.as_non_null
              struct.get 139 0
              local.set 88
              local.get 88
              ref.as_non_null
              local.get 24
              local.get 25
              local.get 26
              call $helper::ordinary_own_descriptor
              local.set 87
              local.get 87
              ref.is_null
              if ;; label = @6
                i32.const 0
                local.set 148
                local.get 24
                i32.const 4
                i32.eq
                if ;; label = @7
                  local.get 26
                  ref.cast (ref 131)
                  local.set 52
                  local.get 52
                  ref.as_non_null
                  struct.get 131 0
                  local.set 46
                  local.get 46
                  ref.as_non_null
                  array.len
                  local.set 60
                  block ;; label = @8
                    local.get 60
                    i32.eqz
                    local.get 60
                    i32.const 10
                    i32.gt_u
                    i32.or
                    br_if 0 (;@8;)
                    i32.const 0
                    local.set 94
                    local.get 46
                    ref.as_non_null
                    local.get 94
                    array.get_u 132
                    local.set 102
                    local.get 102
                    i32.const 48
                    i32.eq
                    if ;; label = @9
                      i32.const 0
                      local.set 151
                      local.get 60
                      i32.const 1
                      i32.eq
                      local.set 148
                      br 1 (;@8;)
                    end
                    i64.const 0
                    local.set 154
                    loop ;; label = @9
                      local.get 46
                      ref.as_non_null
                      local.get 94
                      array.get_u 132
                      local.set 102
                      local.get 102
                      i32.const 48
                      i32.sub
                      local.set 102
                      local.get 102
                      i32.const 9
                      i32.gt_u
                      br_if 1 (;@8;)
                      local.get 154
                      i64.const 10
                      i64.mul
                      local.get 102
                      i64.extend_i32_u
                      i64.add
                      local.set 154
                      local.get 94
                      i32.const 1
                      i32.add
                      local.set 94
                      local.get 94
                      local.get 60
                      i32.lt_u
                      br_if 0 (;@9;)
                    end
                    local.get 154
                    i64.const 4294967295
                    i64.lt_u
                    if ;; label = @9
                      local.get 154
                      i32.wrap_i64
                      local.set 151
                      i32.const 1
                      local.set 148
                    end
                  end
                  ref.null 132
                  local.set 46
                  ref.null 131
                  local.set 52
                end
                local.get 148
                if ;; label = @7
                  local.get 151
                  i64.extend_i32_u
                  local.set 74
                  local.get 95
                  ref.as_non_null
                  local.set 166
                  local.get 166
                  ref.as_non_null
                  struct.get 139 6
                  i32.const 2
                  i32.eq
                  local.get 166
                  ref.as_non_null
                  struct.get 139 6
                  i32.const 3
                  i32.eq
                  i32.or
                  if ;; label = @8
                    i32.const 0
                    local.set 145
                    local.get 166
                    ref.as_non_null
                    struct.get 139 6
                    i32.const 3
                    i32.eq
                    if ;; label = @9
                      local.get 166
                      ref.as_non_null
                      struct.get 139 9
                      ref.as_non_null
                      local.set 96
                      local.get 74
                      local.get 96
                      ref.as_non_null
                      array.len
                      i64.extend_i32_u
                      i64.lt_u
                      if ;; label = @10
                        local.get 74
                        i32.wrap_i64
                        local.set 94
                        local.get 96
                        ref.as_non_null
                        local.get 94
                        array.get 93
                        local.set 85
                        local.get 85
                        ref.is_null
                        i32.eqz
                        if ;; label = @11
                          i32.const 1
                          local.set 145
                        end
                        ref.null 62
                        local.set 85
                      end
                      ref.null 93
                      local.set 96
                    else
                      local.get 166
                      ref.as_non_null
                      struct.get 139 7
                      local.set 107
                      local.get 166
                      ref.as_non_null
                      struct.get 139 8
                      local.set 98
                      local.get 74
                      local.get 107
                      ref.as_non_null
                      array.len
                      i64.extend_i32_u
                      i64.lt_u
                      if ;; label = @10
                        local.get 74
                        i32.wrap_i64
                        local.set 102
                        local.get 102
                        i32.const 6
                        i32.shr_u
                        local.set 94
                        i64.const 1
                        local.get 102
                        i64.extend_i32_u
                        i64.shl
                        local.set 154
                        local.get 98
                        ref.as_non_null
                        local.get 94
                        array.get 95
                        local.set 146
                        local.get 146
                        local.get 154
                        i64.and
                        i64.eqz
                        i32.eqz
                        if ;; label = @11
                          i32.const 1
                          local.set 145
                        end
                      end
                      ref.null 95
                      local.set 98
                      ref.null 94
                      local.set 107
                    end
                    local.get 145
                    if ;; label = @9
                      local.get 166
                      ref.as_non_null
                      struct.get 139 6
                      i32.const 3
                      i32.eq
                      if ;; label = @10
                        local.get 166
                        ref.as_non_null
                        struct.get 139 9
                        ref.as_non_null
                        local.set 96
                        local.get 96
                        ref.as_non_null
                        array.len
                        local.set 153
                        ref.null 70
                        local.get 153
                        array.new 92
                        local.set 100
                        i32.const 0
                        local.set 102
                        global.get 30
                        local.set 85
                        block ;; label = @11
                          loop ;; label = @12
                            local.get 102
                            local.get 153
                            i32.ge_u
                            br_if 1 (;@11;)
                            local.get 96
                            ref.as_non_null
                            local.get 102
                            array.get 93
                            local.set 68
                            local.get 68
                            ref.is_null
                            i32.eqz
                            if ;; label = @13
                              local.get 68
                              ref.as_non_null
                              local.set 84
                              i32.const 14
                              local.get 84
                              ref.as_non_null
                              local.get 85
                              ref.as_non_null
                              local.get 85
                              ref.as_non_null
                              struct.new 70
                              local.set 101
                              ref.null 62
                              local.set 84
                              local.get 100
                              ref.as_non_null
                              local.get 102
                              local.get 101
                              ref.as_non_null
                              array.set 92
                              ref.null 70
                              local.set 101
                            end
                            ref.null 62
                            local.set 68
                            local.get 102
                            i32.const 1
                            i32.add
                            local.set 102
                            br 0 (;@12;)
                          end
                        end
                        local.get 166
                        ref.as_non_null
                        local.get 100
                        ref.as_non_null
                        struct.set 139 5
                        global.get 28
                        local.set 107
                        global.get 29
                        local.set 98
                        local.get 166
                        ref.as_non_null
                        local.get 107
                        ref.as_non_null
                        struct.set 139 7
                        local.get 166
                        ref.as_non_null
                        local.get 98
                        ref.as_non_null
                        struct.set 139 8
                        local.get 166
                        ref.as_non_null
                        ref.null 93
                        struct.set 139 9
                        ref.null 95
                        local.set 98
                        ref.null 94
                        local.set 107
                        local.get 166
                        ref.as_non_null
                        i32.const 0
                        struct.set 139 6
                        ref.null 62
                        local.set 85
                        ref.null 92
                        local.set 100
                        ref.null 93
                        local.set 96
                      else
                        local.get 166
                        ref.as_non_null
                        struct.get 139 6
                        i32.const 2
                        i32.eq
                        if ;; label = @11
                          local.get 166
                          ref.as_non_null
                          struct.get 139 7
                          local.set 97
                          local.get 166
                          ref.as_non_null
                          struct.get 139 8
                          local.set 108
                          local.get 97
                          ref.as_non_null
                          array.len
                          local.set 94
                          ref.null 70
                          local.get 94
                          array.new 92
                          local.set 100
                          i32.const 0
                          local.set 153
                          i32.const 0
                          local.set 149
                          i64.const 0
                          local.set 49
                          ref.null eq
                          local.set 67
                          block ;; label = @12
                            loop ;; label = @13
                              local.get 153
                              local.get 94
                              i32.ge_u
                              br_if 1 (;@12;)
                              local.get 153
                              i32.const 6
                              i32.shr_u
                              local.set 111
                              i64.const 1
                              local.get 153
                              i64.extend_i32_u
                              i64.shl
                              local.set 154
                              local.get 108
                              ref.as_non_null
                              local.get 111
                              array.get 95
                              local.set 146
                              local.get 146
                              local.get 154
                              i64.and
                              i64.eqz
                              i32.eqz
                              if ;; label = @14
                                local.get 97
                                ref.as_non_null
                                local.get 153
                                array.get 94
                                local.set 146
                                i32.const 3
                                local.set 103
                                local.get 146
                                local.set 155
                                ref.null eq
                                local.set 125
                                local.get 155
                                local.get 103
                                local.get 125
                                struct.new 62
                                local.set 68
                                global.get 30
                                local.set 85
                                i32.const 14
                                local.get 68
                                ref.as_non_null
                                local.get 85
                                ref.as_non_null
                                local.get 85
                                ref.as_non_null
                                struct.new 70
                                local.set 101
                                ref.null 62
                                local.set 85
                                ref.null 62
                                local.set 68
                                local.get 100
                                ref.as_non_null
                                local.get 153
                                local.get 101
                                ref.as_non_null
                                array.set 92
                                ref.null 70
                                local.set 101
                              end
                              local.get 153
                              i32.const 1
                              i32.add
                              local.set 153
                              br 0 (;@13;)
                            end
                          end
                          local.get 166
                          ref.as_non_null
                          local.get 100
                          ref.as_non_null
                          struct.set 139 5
                          global.get 28
                          local.set 107
                          global.get 29
                          local.set 98
                          local.get 166
                          ref.as_non_null
                          local.get 107
                          ref.as_non_null
                          struct.set 139 7
                          local.get 166
                          ref.as_non_null
                          local.get 98
                          ref.as_non_null
                          struct.set 139 8
                          local.get 166
                          ref.as_non_null
                          ref.null 93
                          struct.set 139 9
                          ref.null 95
                          local.set 98
                          ref.null 94
                          local.set 107
                          local.get 166
                          ref.as_non_null
                          i32.const 0
                          struct.set 139 6
                          ref.null eq
                          local.set 67
                          ref.null eq
                          local.set 125
                          ref.null 92
                          local.set 100
                          ref.null 95
                          local.set 108
                          ref.null 94
                          local.set 97
                        end
                      end
                    end
                  end
                  local.get 166
                  ref.as_non_null
                  struct.get 139 4
                  local.set 109
                  local.get 109
                  ref.as_non_null
                  array.len
                  local.set 145
                  ref.null 70
                  local.set 101
                  local.get 166
                  ref.as_non_null
                  struct.get 139 6
                  i32.const 0
                  i32.eq
                  if ;; label = @8
                    local.get 166
                    ref.as_non_null
                    struct.get 139 5
                    local.set 100
                    local.get 74
                    local.get 100
                    ref.as_non_null
                    array.len
                    i64.extend_i32_u
                    i64.lt_u
                    if ;; label = @9
                      local.get 74
                      i32.wrap_i64
                      local.set 62
                      local.get 100
                      ref.as_non_null
                      local.get 62
                      array.get 92
                      local.set 101
                    end
                    ref.null 92
                    local.set 100
                  else
                    local.get 145
                    if ;; label = @9
                      local.get 74
                      i32.wrap_i64
                      local.set 94
                      local.get 94
                      local.get 94
                      i32.const 16
                      i32.shr_u
                      i32.xor
                      i32.const 2146121005
                      i32.mul
                      local.set 94
                      local.get 94
                      local.get 94
                      i32.const 15
                      i32.shr_u
                      i32.xor
                      i32.const -2073254261
                      i32.mul
                      local.set 94
                      local.get 94
                      local.get 94
                      i32.const 16
                      i32.shr_u
                      i32.xor
                      local.get 145
                      i32.const 1
                      i32.sub
                      i32.and
                      local.set 94
                      local.get 109
                      ref.as_non_null
                      local.get 94
                      array.get 97
                      local.set 110
                      block ;; label = @10
                        loop ;; label = @11
                          local.get 110
                          ref.is_null
                          br_if 1 (;@10;)
                          local.get 110
                          struct.get 96 0
                          local.set 63
                          local.get 63
                          local.get 74
                          i64.eq
                          if ;; label = @12
                            local.get 110
                            struct.get 96 1
                            local.set 101
                            br 2 (;@10;)
                          end
                          local.get 110
                          struct.get 96 2
                          local.set 110
                          br 0 (;@11;)
                        end
                      end
                      ref.null 96
                      local.set 110
                    end
                  end
                  ref.null 97
                  local.set 109
                  ref.null 139
                  local.set 166
                  local.get 101
                  local.set 87
                  ref.null 70
                  local.set 101
                else
                  i32.const 140
                  local.set 153
                  local.get 153
                  call $helper::pooled_string_resolve
                  local.set 52
                  i32.const 4
                  local.set 62
                  i64.const 0
                  local.set 74
                  local.get 52
                  ref.as_non_null
                  local.set 71
                  local.get 24
                  local.get 62
                  i32.eq
                  if (result i32) ;; label = @8
                    local.get 24
                    i32.const 3
                    i32.eq
                    if (result i32) ;; label = @9
                      local.get 25
                      local.get 74
                      i64.eq
                      local.get 25
                      f64.reinterpret_i64
                      local.get 25
                      f64.reinterpret_i64
                      f64.ne
                      local.get 74
                      f64.reinterpret_i64
                      local.get 74
                      f64.reinterpret_i64
                      f64.ne
                      i32.and
                      i32.or
                    else
                      local.get 24
                      i32.const 4
                      i32.eq
                      if (result i32) ;; label = @10
                        local.get 26
                        local.get 71
                        ref.eq
                        if (result i32) ;; label = @11
                          i32.const 1
                        else
                          local.get 26
                          ref.cast (ref 131)
                          local.set 47
                          local.get 71
                          ref.cast (ref 131)
                          local.set 51
                          i32.const 0
                          local.set 153
                          local.get 47
                          ref.as_non_null
                          local.get 51
                          ref.as_non_null
                          local.get 153
                          call $helper::string_equality
                          local.set 53
                          local.get 53
                          ref.null 131
                          local.set 51
                          ref.null 131
                          local.set 47
                        end
                      else
                        local.get 24
                        i32.const 10
                        i32.eq
                        if (result i32) ;; label = @11
                          local.get 26
                          ref.cast (ref 133)
                          local.set 55
                          local.get 71
                          ref.cast (ref 133)
                          local.set 56
                          local.get 55
                          ref.as_non_null
                          struct.get 133 0
                          local.set 145
                          local.get 56
                          ref.as_non_null
                          struct.get 133 0
                          local.set 153
                          local.get 55
                          ref.as_non_null
                          struct.get 133 1
                          local.set 58
                          local.get 56
                          ref.as_non_null
                          struct.get 133 1
                          local.set 57
                          local.get 58
                          ref.as_non_null
                          array.len
                          local.set 111
                          local.get 57
                          ref.as_non_null
                          array.len
                          local.set 53
                          local.get 145
                          local.get 153
                          i32.eq
                          local.get 111
                          local.get 53
                          i32.eq
                          i32.and
                          local.set 94
                          local.get 94
                          if ;; label = @12
                            i32.const 0
                            local.set 103
                            block ;; label = @13
                              loop ;; label = @14
                                local.get 103
                                local.get 111
                                i32.ge_u
                                br_if 1 (;@13;)
                                local.get 58
                                ref.as_non_null
                                local.get 103
                                array.get 137
                                local.set 63
                                local.get 57
                                ref.as_non_null
                                local.get 103
                                array.get 137
                                local.set 146
                                local.get 63
                                local.get 146
                                i64.eq
                                local.set 94
                                local.get 94
                                i32.eqz
                                br_if 1 (;@13;)
                                local.get 103
                                i32.const 1
                                i32.add
                                local.set 103
                                br 0 (;@14;)
                              end
                            end
                          end
                          local.get 94
                          ref.null 137
                          local.set 57
                          ref.null 137
                          local.set 58
                          ref.null 133
                          local.set 56
                          ref.null 133
                          local.set 55
                        else
                          local.get 24
                          i32.const 0
                          i32.eq
                          local.get 24
                          i32.const 1
                          i32.eq
                          i32.or
                          if (result i32) ;; label = @12
                            i32.const 1
                          else
                            local.get 24
                            i32.const 2
                            i32.eq
                            if (result i32) ;; label = @13
                              local.get 25
                              local.get 74
                              i64.eq
                            else
                              local.get 26
                              local.get 71
                              ref.eq
                            end
                          end
                        end
                      end
                    end
                  else
                    i32.const 0
                  end
                  if ;; label = @8
                    local.get 95
                    ref.as_non_null
                    struct.get 139 2
                    local.set 49
                    local.get 49
                    f64.convert_i64_u
                    i64.reinterpret_f64
                    local.set 49
                    i32.const 3
                    local.set 149
                    local.get 49
                    local.set 49
                    ref.null eq
                    local.set 147
                    local.get 95
                    ref.as_non_null
                    struct.get 139 1
                    local.set 153
                    i32.const 0
                    local.set 53
                    i32.const 0
                    local.set 145
                    i64.const 0
                    local.set 76
                    ref.null eq
                    local.set 83
                    local.get 49
                    local.get 149
                    local.get 147
                    struct.new 62
                    local.set 68
                    global.get 30
                    local.set 84
                    i32.const 4
                    local.get 68
                    ref.as_non_null
                    local.get 84
                    ref.as_non_null
                    local.get 84
                    ref.as_non_null
                    struct.new 70
                    local.set 89
                    ref.null 62
                    local.set 84
                    ref.null 62
                    local.set 68
                    local.get 89
                    ref.as_non_null
                    i32.const 0
                    local.get 153
                    i32.eqz
                    i32.eqz
                    i32.const 4
                    i32.mul
                    i32.or
                    local.get 53
                    i32.eqz
                    i32.eqz
                    i32.const 8
                    i32.mul
                    i32.or
                    local.get 53
                    i32.eqz
                    i32.eqz
                    i32.const 2
                    i32.mul
                    i32.or
                    struct.set 70 0
                    local.get 89
                    ref.as_non_null
                    local.set 101
                    ref.null 70
                    local.set 89
                    ref.null eq
                    local.set 83
                    ref.null eq
                    local.set 147
                    local.get 101
                    ref.as_non_null
                    local.set 87
                    ref.null 70
                    local.set 101
                  end
                  ref.null eq
                  local.set 71
                  ref.null 131
                  local.set 52
                end
              end
              ref.null 69
              local.set 88
              local.get 87
              ref.is_null
              i32.eqz
              if ;; label = @6
                local.get 87
                ref.is_null
                i32.eqz
                if (result i32) ;; label = @7
                  local.get 87
                  struct.get 70 0
                  local.set 148
                  local.get 148
                  i32.const 4
                  i32.and
                  i32.eqz
                  i32.eqz
                else
                  i32.const 0
                end
                local.set 94
                local.get 87
                ref.is_null
                i32.eqz
                if (result i32) ;; label = @7
                  local.get 87
                  struct.get 70 0
                  local.set 111
                  local.get 111
                  i32.const 8
                  i32.and
                  i32.eqz
                  i32.eqz
                else
                  i32.const 0
                end
                local.set 103
                local.get 87
                ref.is_null
                i32.eqz
                if (result i32) ;; label = @7
                  local.get 87
                  struct.get 70 0
                  local.set 148
                  local.get 148
                  i32.const 2
                  i32.and
                  i32.eqz
                  i32.eqz
                else
                  i32.const 0
                end
                local.set 151
                local.get 87
                struct.get 70 1
                local.set 92
                local.get 87
                struct.get 70 2
                local.set 85
                local.get 87
                struct.get 70 3
                local.set 84
                local.get 87
                ref.is_null
                i32.eqz
                if (result i32) ;; label = @7
                  local.get 87
                  struct.get 70 0
                  local.set 111
                  local.get 111
                  i32.const 1
                  i32.and
                  i32.eqz
                  i32.eqz
                else
                  i32.const 0
                end
                if ;; label = @7
                  i32.const 1
                  local.get 103
                  i32.eqz
                  i32.eqz
                  i32.const 8
                  i32.mul
                  i32.or
                  local.get 151
                  i32.eqz
                  i32.eqz
                  i32.const 2
                  i32.mul
                  i32.or
                  local.get 92
                  ref.as_non_null
                  local.get 85
                  ref.as_non_null
                  local.get 84
                  ref.as_non_null
                  struct.new 70
                  local.set 113
                else
                  i32.const 0
                  local.get 94
                  i32.eqz
                  i32.eqz
                  i32.const 4
                  i32.mul
                  i32.or
                  local.get 103
                  i32.eqz
                  i32.eqz
                  i32.const 8
                  i32.mul
                  i32.or
                  local.get 151
                  i32.eqz
                  i32.eqz
                  i32.const 2
                  i32.mul
                  i32.or
                  local.get 92
                  ref.as_non_null
                  local.get 85
                  ref.as_non_null
                  local.get 84
                  ref.as_non_null
                  struct.new 70
                  local.set 113
                end
                ref.null 62
                local.set 84
                ref.null 62
                local.set 85
                ref.null 61
                local.set 92
              end
              ref.null 70
              local.set 87
              ref.null 139
              local.set 95
            else
              ref.null 269
              local.set 114
              local.get 11
              local.set 69
              ref.null 161
              local.set 65
              block ;; label = @6
                loop ;; label = @7
                  local.get 69
                  ref.is_null
                  br_if 1 (;@6;)
                  local.get 69
                  struct.get 120 0
                  local.set 65
                  local.get 65
                  ref.is_null
                  i32.eqz
                  br_if 1 (;@6;)
                  local.get 69
                  struct.get 120 3
                  local.set 69
                  br 0 (;@7;)
                end
              end
              local.get 65
              ref.is_null
              if ;; label = @6
                global.get 8
                ref.as_non_null
                local.set 70
                local.get 70
                ref.as_non_null
                local.set 65
                ref.null 161
                local.set 70
              end
              local.get 65
              ref.as_non_null
              local.set 70
              ref.null 161
              local.set 65
              ref.null 120
              local.set 69
              local.get 70
              ref.as_non_null
              local.set 65
              local.get 70
              ref.as_non_null
              struct.get 161 5
              local.set 72
              i32.const 13
              local.set 149
              local.get 72
              ref.as_non_null
              local.get 149
              array.get 163
              local.set 85
              ref.null 163
              local.set 72
              local.get 85
              ref.as_non_null
              struct.get 62 1
              local.set 151
              local.get 85
              ref.as_non_null
              struct.get 62 0
              local.set 63
              local.get 85
              ref.as_non_null
              struct.get 62 2
              local.set 112
              i32.const 0
              local.get 151
              i32.const 6
              i32.eq
              i32.or
              local.get 151
              i32.const 7
              i32.eq
              i32.or
              local.get 151
              i32.const 8
              i32.eq
              i32.or
              local.get 151
              i32.const 9
              i32.eq
              i32.or
              i32.eqz
              if ;; label = @6
                unreachable
              end
              ref.null 62
              local.set 85
              local.get 112
              ref.cast (ref 107)
              local.set 116
              ref.null eq
              local.set 112
              i32.const 8
              local.set 145
              i64.const 0
              local.set 63
              local.get 116
              ref.as_non_null
              local.set 112
              ref.null 120
              local.set 69
              ref.null 130
              local.set 117
              i32.const 0
              local.set 149
              i64.const 0
              local.set 106
              ref.null eq
              local.set 83
              ref.null 99
              local.set 86
              ref.null 105
              local.set 118
              ref.null 167
              local.set 119
              i32.const 1
              local.set 153
              i64.const 4611686018427387904
              local.set 74
              i32.const 261
              local.set 62
              local.get 62
              call $helper::pooled_string_resolve
              local.set 52
              local.get 145
              local.get 63
              local.get 112
              local.get 52
              ref.as_non_null
              local.get 74
              local.get 153
              call $helper::native_function_allocate
              ref.null 131
              local.set 52
              local.set 165
              ref.func $builtin::Object.getOwnPropertyDescriptor
              local.set 121
              i64.const 81
              i32.const 1
              i32.const 15
              i32.const -1
              i32.const 0
              i32.const 0
              local.get 121
              ref.null 41
              ref.null 42
              ref.null 43
              ref.null 39
              struct.new 106
              ref.null 40
              local.set 121
              local.set 120
              global.get 30
              local.set 85
              ref.null 59
              local.set 122
              local.get 65
              ref.as_non_null
              local.get 69
              local.get 117
              ref.null 107
              local.get 85
              ref.as_non_null
              local.get 86
              local.get 119
              local.get 114
              local.get 118
              ref.null 109
              local.get 122
              struct.new 110
              local.set 123
              ref.null 59
              local.set 122
              i32.const 3749
              local.set 62
              local.get 62
              call $helper::pooled_string_resolve
              local.set 52
              global.get 30
              local.set 68
              local.get 165
              ref.as_non_null
              local.get 120
              ref.as_non_null
              local.get 123
              ref.as_non_null
              local.get 52
              ref.as_non_null
              local.get 68
              ref.as_non_null
              i32.const 1
              i32.const 0
              i32.const 0
              i32.const 0
              i32.const 0
              i32.const 0
              i32.const 0
              i32.const -1
              ref.null 108
              ref.null 108
              struct.new 107
              local.set 115
              local.get 123
              ref.as_non_null
              local.get 115
              ref.as_non_null
              struct.set 110 3
              ref.null 62
              local.set 68
              ref.null 131
              local.set 52
              ref.null 62
              local.set 85
              ref.null 110
              local.set 123
              ref.null 106
              local.set 120
              ref.null 69
              local.set 165
              local.get 115
              ref.as_non_null
              ref.null 107
              local.set 115
              ref.null 167
              local.set 119
              ref.null 105
              local.set 118
              ref.null 99
              local.set 86
              ref.null eq
              local.set 83
              ref.null 130
              local.set 117
              ref.null 120
              local.set 69
              ref.null eq
              local.set 112
              local.set 124
              ref.null 107
              local.set 116
              ref.null 161
              local.set 65
              ref.null 161
              local.set 70
              i32.const 8
              local.set 62
              i64.const 0
              local.set 74
              local.get 124
              ref.as_non_null
              local.set 67
              i32.const 0
              local.set 153
              i64.const 0
              local.set 76
              ref.null eq
              local.set 75
              local.get 36
              local.get 35
              local.get 37
              struct.new 62
              local.set 84
              local.get 25
              local.get 24
              local.get 26
              struct.new 62
              local.set 68
              local.get 84
              ref.as_non_null
              local.get 68
              ref.as_non_null
              array.new_fixed 99 2
              local.set 86
              ref.null 62
              local.set 68
              ref.null 62
              local.set 84
              global.get 8
              ref.as_non_null
              local.set 65
              local.get 62
              local.get 74
              local.get 67
              local.get 153
              local.get 76
              local.get 75
              local.get 86
              ref.as_non_null
              local.get 65
              ref.as_non_null
              local.get 11
              local.get 29
              ref.as_non_null
              call $helper::proxy_call
              local.set 103
              local.set 94
              local.set 71
              local.set 146
              local.set 148
              local.get 65
              ref.as_non_null
              global.set 8
              ref.null 161
              local.set 65
              local.get 94
              i32.const 2
              i32.eq
              if ;; label = @6
                local.get 148
                local.set 148
                local.get 146
                local.set 146
                local.get 71
                local.set 71
                i32.const 0
                local.set 94
                i32.const 0
                local.set 103
              end
              ref.null 99
              local.set 86
              ref.null eq
              local.set 75
              ref.null eq
              local.set 67
              ref.null 107
              local.set 124
              ref.null 269
              local.set 114
              local.get 94
              i32.const 1
              i32.eq
              if ;; label = @6
                local.get 148
                local.set 13
                local.get 146
                local.set 14
                local.get 71
                local.set 15
                local.get 94
                local.set 16
                local.get 103
                local.set 17
                local.get 13
                local.get 14
                local.get 15
                local.get 16
                local.get 17
                return
              end
              local.get 148
              i32.const 0
              i32.ne
              if ;; label = @6
                i32.const 299
                local.set 150
                local.get 150
                call $helper::pooled_string_resolve
                local.set 45
                i32.const 4
                local.set 136
                i64.const 0
                local.set 155
                local.get 45
                ref.as_non_null
                local.set 79
                ref.null 131
                local.set 45
                i32.const 0
                local.set 111
                i32.const 0
                local.set 145
                i64.const 0
                local.set 63
                ref.null eq
                local.set 112
                local.get 148
                i32.const 6
                i32.eq
                local.get 148
                i32.const 7
                i32.eq
                i32.or
                local.get 148
                i32.const 8
                i32.eq
                i32.or
                local.get 148
                i32.const 9
                i32.eq
                i32.or
                if ;; label = @7
                  local.get 148
                  local.get 146
                  local.get 71
                  call $helper::object_header_projection
                  local.set 88
                  i32.const 0
                  local.set 111
                  local.get 88
                  ref.as_non_null
                  struct.get 69 1
                  local.set 139
                  local.get 139
                  ref.as_non_null
                  ref.test (ref 77)
                  if ;; label = @8
                    local.get 139
                    ref.as_non_null
                    ref.cast (ref 77)
                    local.set 140
                    i32.const 0
                    local.set 111
                    local.get 136
                    i32.const 4
                    i32.eq
                    if ;; label = @9
                      local.get 140
                      ref.as_non_null
                      struct.get 77 0
                      local.set 142
                      local.get 142
                      ref.as_non_null
                      struct.get 80 0
                      local.set 143
                      ref.null 80
                      local.set 142
                      local.get 143
                      ref.as_non_null
                      array.len
                      local.set 90
                      i32.const 0
                      local.set 144
                      block ;; label = @10
                        loop ;; label = @11
                          local.get 144
                          local.get 90
                          i32.ge_u
                          br_if 1 (;@10;)
                          local.get 143
                          ref.as_non_null
                          local.get 144
                          array.get 83
                          local.set 45
                          i32.const 4
                          local.set 150
                          i64.const 0
                          local.set 82
                          local.get 45
                          ref.as_non_null
                          local.set 128
                          local.get 150
                          local.get 136
                          i32.eq
                          if (result i32) ;; label = @12
                            local.get 150
                            i32.const 3
                            i32.eq
                            if (result i32) ;; label = @13
                              local.get 82
                              local.get 155
                              i64.eq
                              local.get 82
                              f64.reinterpret_i64
                              local.get 82
                              f64.reinterpret_i64
                              f64.ne
                              local.get 155
                              f64.reinterpret_i64
                              local.get 155
                              f64.reinterpret_i64
                              f64.ne
                              i32.and
                              i32.or
                            else
                              local.get 150
                              i32.const 4
                              i32.eq
                              if (result i32) ;; label = @14
                                local.get 128
                                local.get 79
                                ref.eq
                                if (result i32) ;; label = @15
                                  i32.const 1
                                else
                                  local.get 128
                                  ref.cast (ref 131)
                                  local.set 47
                                  local.get 79
                                  ref.cast (ref 131)
                                  local.set 51
                                  i32.const 0
                                  local.set 131
                                  local.get 47
                                  ref.as_non_null
                                  local.get 51
                                  ref.as_non_null
                                  local.get 131
                                  call $helper::string_equality
                                  local.set 133
                                  local.get 133
                                  ref.null 131
                                  local.set 51
                                  ref.null 131
                                  local.set 47
                                end
                              else
                                local.get 150
                                i32.const 10
                                i32.eq
                                if (result i32) ;; label = @15
                                  local.get 128
                                  ref.cast (ref 133)
                                  local.set 55
                                  local.get 79
                                  ref.cast (ref 133)
                                  local.set 56
                                  local.get 55
                                  ref.as_non_null
                                  struct.get 133 0
                                  local.set 134
                                  local.get 56
                                  ref.as_non_null
                                  struct.get 133 0
                                  local.set 131
                                  local.get 55
                                  ref.as_non_null
                                  struct.get 133 1
                                  local.set 58
                                  local.get 56
                                  ref.as_non_null
                                  struct.get 133 1
                                  local.set 57
                                  local.get 58
                                  ref.as_non_null
                                  array.len
                                  local.set 135
                                  local.get 57
                                  ref.as_non_null
                                  array.len
                                  local.set 61
                                  local.get 134
                                  local.get 131
                                  i32.eq
                                  local.get 135
                                  local.get 61
                                  i32.eq
                                  i32.and
                                  local.set 48
                                  local.get 48
                                  if ;; label = @16
                                    i32.const 0
                                    local.set 81
                                    block ;; label = @17
                                      loop ;; label = @18
                                        local.get 81
                                        local.get 135
                                        i32.ge_u
                                        br_if 1 (;@17;)
                                        local.get 58
                                        ref.as_non_null
                                        local.get 81
                                        array.get 137
                                        local.set 129
                                        local.get 57
                                        ref.as_non_null
                                        local.get 81
                                        array.get 137
                                        local.set 127
                                        local.get 129
                                        local.get 127
                                        i64.eq
                                        local.set 48
                                        local.get 48
                                        i32.eqz
                                        br_if 1 (;@17;)
                                        local.get 81
                                        i32.const 1
                                        i32.add
                                        local.set 81
                                        br 0 (;@18;)
                                      end
                                    end
                                  end
                                  local.get 48
                                  ref.null 137
                                  local.set 57
                                  ref.null 137
                                  local.set 58
                                  ref.null 133
                                  local.set 56
                                  ref.null 133
                                  local.set 55
                                else
                                  local.get 150
                                  i32.const 0
                                  i32.eq
                                  local.get 150
                                  i32.const 1
                                  i32.eq
                                  i32.or
                                  if (result i32) ;; label = @16
                                    i32.const 1
                                  else
                                    local.get 150
                                    i32.const 2
                                    i32.eq
                                    if (result i32) ;; label = @17
                                      local.get 82
                                      local.get 155
                                      i64.eq
                                    else
                                      local.get 128
                                      local.get 79
                                      ref.eq
                                    end
                                  end
                                end
                              end
                            end
                          else
                            i32.const 0
                          end
                          local.set 111
                          ref.null eq
                          local.set 128
                          ref.null 131
                          local.set 45
                          local.get 111
                          br_if 1 (;@10;)
                          local.get 144
                          i32.const 1
                          i32.add
                          local.set 144
                          br 0 (;@11;)
                        end
                      end
                      ref.null 83
                      local.set 143
                    end
                    local.get 111
                    if ;; label = @9
                      local.get 140
                      ref.as_non_null
                      ref.test (ref 79)
                      if ;; label = @10
                        local.get 140
                        ref.as_non_null
                        ref.cast (ref 79)
                        local.set 156
                        local.get 156
                        ref.as_non_null
                        struct.get 79 0
                        local.set 142
                        local.get 142
                        ref.as_non_null
                        struct.get 80 0
                        local.set 143
                        local.get 144
                        local.get 143
                        ref.as_non_null
                        array.len
                        i32.ge_u
                        local.get 144
                        i32.const 2
                        i32.ge_u
                        i32.or
                        if ;; label = @11
                          unreachable
                        end
                        ref.null 83
                        local.set 143
                        ref.null 80
                        local.set 142
                        local.get 156
                        ref.as_non_null
                        struct.get 79 1
                        local.set 145
                        local.get 145
                        local.get 144
                        i32.const 8
                        i32.mul
                        i32.shr_u
                        i32.const 255
                        i32.and
                        local.set 145
                        local.get 144
                        i32.eqz
                        if ;; label = @11
                          local.get 156
                          ref.as_non_null
                          struct.get 79 2
                          local.set 63
                          local.get 156
                          ref.as_non_null
                          struct.get 79 4
                          local.set 112
                        else
                          local.get 156
                          ref.as_non_null
                          struct.get 79 3
                          local.set 63
                          local.get 156
                          ref.as_non_null
                          struct.get 79 5
                          local.set 112
                        end
                        ref.null 79
                        local.set 156
                      else
                        local.get 140
                        ref.as_non_null
                        ref.cast (ref 78)
                        local.set 157
                        local.get 157
                        ref.as_non_null
                        struct.get 78 1
                        local.set 158
                        local.get 157
                        ref.as_non_null
                        struct.get 78 2
                        local.set 161
                        local.get 157
                        ref.as_non_null
                        struct.get 78 3
                        local.set 160
                        local.get 158
                        ref.as_non_null
                        local.get 144
                        array.get_u 84
                        local.set 145
                        i64.const 0
                        local.set 63
                        local.get 161
                        ref.is_null
                        i32.eqz
                        if ;; label = @11
                          local.get 161
                          ref.as_non_null
                          local.set 159
                          local.get 159
                          ref.as_non_null
                          local.get 144
                          array.get 85
                          local.set 63
                          ref.null 85
                          local.set 159
                        end
                        ref.null eq
                        local.set 112
                        local.get 160
                        ref.is_null
                        i32.eqz
                        if ;; label = @11
                          local.get 160
                          ref.as_non_null
                          local.set 162
                          local.get 162
                          ref.as_non_null
                          local.get 144
                          array.get 86
                          local.set 112
                          ref.null 86
                          local.set 162
                        end
                        ref.null 86
                        local.set 160
                        ref.null 85
                        local.set 161
                        ref.null 84
                        local.set 158
                        ref.null 78
                        local.set 157
                      end
                    end
                    ref.null 77
                    local.set 140
                  else
                    local.get 88
                    ref.as_non_null
                    local.get 136
                    local.get 155
                    local.get 79
                    call $helper::ordinary_property_find
                    local.set 164
                    ref.null 70
                    local.set 89
                    local.get 164
                    ref.is_null
                    i32.eqz
                    if ;; label = @9
                      local.get 164
                      ref.as_non_null
                      local.set 163
                      local.get 163
                      ref.as_non_null
                      struct.get 74 1
                      local.set 89
                      ref.null 74
                      local.set 163
                    end
                    local.get 89
                    ref.is_null
                    i32.eqz
                    if ;; label = @9
                      local.get 89
                      struct.get 70 0
                      local.set 150
                      local.get 150
                      i32.const 1
                      i32.and
                      i32.eqz
                      if ;; label = @10
                        local.get 89
                        struct.get 70 1
                        local.set 92
                        local.get 92
                        ref.as_non_null
                        ref.test (ref 62)
                        if ;; label = @11
                          local.get 92
                          ref.as_non_null
                          ref.cast (ref 62)
                          local.set 84
                          local.get 84
                          ref.as_non_null
                          struct.get 62 1
                          local.set 145
                          local.get 84
                          ref.as_non_null
                          struct.get 62 0
                          local.set 63
                          local.get 84
                          ref.as_non_null
                          struct.get 62 2
                          local.set 112
                          ref.null 62
                          local.set 84
                        else
                          local.get 92
                          ref.as_non_null
                          call $helper::property_value_resolve
                          local.set 68
                          local.get 68
                          ref.as_non_null
                          struct.get 62 1
                          local.set 145
                          local.get 68
                          ref.as_non_null
                          struct.get 62 0
                          local.set 63
                          local.get 68
                          ref.as_non_null
                          struct.get 62 2
                          local.set 112
                          ref.null 62
                          local.set 68
                        end
                        i32.const 1
                        local.set 111
                        ref.null 61
                        local.set 92
                      end
                    end
                    ref.null 70
                    local.set 89
                    ref.null 74
                    local.set 164
                  end
                  ref.null 76
                  local.set 139
                  ref.null 69
                  local.set 88
                end
                ref.null eq
                local.set 79
                i32.const 645
                local.set 90
                local.get 90
                call $helper::pooled_string_resolve
                local.set 47
                i32.const 4
                local.set 144
                i64.const 0
                local.set 155
                local.get 47
                ref.as_non_null
                local.set 79
                ref.null 131
                local.set 47
                i32.const 0
                local.set 111
                i32.const 0
                local.set 53
                i64.const 0
                local.set 49
                ref.null eq
                local.set 147
                local.get 148
                i32.const 6
                i32.eq
                local.get 148
                i32.const 7
                i32.eq
                i32.or
                local.get 148
                i32.const 8
                i32.eq
                i32.or
                local.get 148
                i32.const 9
                i32.eq
                i32.or
                if ;; label = @7
                  local.get 148
                  local.get 146
                  local.get 71
                  call $helper::object_header_projection
                  local.set 88
                  i32.const 0
                  local.set 111
                  local.get 88
                  ref.as_non_null
                  struct.get 69 1
                  local.set 139
                  local.get 139
                  ref.as_non_null
                  ref.test (ref 77)
                  if ;; label = @8
                    local.get 139
                    ref.as_non_null
                    ref.cast (ref 77)
                    local.set 140
                    i32.const 0
                    local.set 111
                    local.get 144
                    i32.const 4
                    i32.eq
                    if ;; label = @9
                      local.get 140
                      ref.as_non_null
                      struct.get 77 0
                      local.set 142
                      local.get 142
                      ref.as_non_null
                      struct.get 80 0
                      local.set 143
                      ref.null 80
                      local.set 142
                      local.get 143
                      ref.as_non_null
                      array.len
                      local.set 141
                      i32.const 0
                      local.set 90
                      block ;; label = @10
                        loop ;; label = @11
                          local.get 90
                          local.get 141
                          i32.ge_u
                          br_if 1 (;@10;)
                          local.get 143
                          ref.as_non_null
                          local.get 90
                          array.get 83
                          local.set 47
                          i32.const 4
                          local.set 136
                          i64.const 0
                          local.set 154
                          local.get 47
                          ref.as_non_null
                          local.set 130
                          local.get 136
                          local.get 144
                          i32.eq
                          if (result i32) ;; label = @12
                            local.get 136
                            i32.const 3
                            i32.eq
                            if (result i32) ;; label = @13
                              local.get 154
                              local.get 155
                              i64.eq
                              local.get 154
                              f64.reinterpret_i64
                              local.get 154
                              f64.reinterpret_i64
                              f64.ne
                              local.get 155
                              f64.reinterpret_i64
                              local.get 155
                              f64.reinterpret_i64
                              f64.ne
                              i32.and
                              i32.or
                            else
                              local.get 136
                              i32.const 4
                              i32.eq
                              if (result i32) ;; label = @14
                                local.get 130
                                local.get 79
                                ref.eq
                                if (result i32) ;; label = @15
                                  i32.const 1
                                else
                                  local.get 130
                                  ref.cast (ref 131)
                                  local.set 51
                                  local.get 79
                                  ref.cast (ref 131)
                                  local.set 45
                                  i32.const 0
                                  local.set 44
                                  local.get 51
                                  ref.as_non_null
                                  local.get 45
                                  ref.as_non_null
                                  local.get 44
                                  call $helper::string_equality
                                  local.set 134
                                  local.get 134
                                  ref.null 131
                                  local.set 45
                                  ref.null 131
                                  local.set 51
                                end
                              else
                                local.get 136
                                i32.const 10
                                i32.eq
                                if (result i32) ;; label = @15
                                  local.get 130
                                  ref.cast (ref 133)
                                  local.set 55
                                  local.get 79
                                  ref.cast (ref 133)
                                  local.set 56
                                  local.get 55
                                  ref.as_non_null
                                  struct.get 133 0
                                  local.set 131
                                  local.get 56
                                  ref.as_non_null
                                  struct.get 133 0
                                  local.set 44
                                  local.get 55
                                  ref.as_non_null
                                  struct.get 133 1
                                  local.set 57
                                  local.get 56
                                  ref.as_non_null
                                  struct.get 133 1
                                  local.set 58
                                  local.get 57
                                  ref.as_non_null
                                  array.len
                                  local.set 134
                                  local.get 58
                                  ref.as_non_null
                                  array.len
                                  local.set 135
                                  local.get 131
                                  local.get 44
                                  i32.eq
                                  local.get 134
                                  local.get 135
                                  i32.eq
                                  i32.and
                                  local.set 81
                                  local.get 81
                                  if ;; label = @16
                                    i32.const 0
                                    local.set 61
                                    block ;; label = @17
                                      loop ;; label = @18
                                        local.get 61
                                        local.get 134
                                        i32.ge_u
                                        br_if 1 (;@17;)
                                        local.get 57
                                        ref.as_non_null
                                        local.get 61
                                        array.get 137
                                        local.set 78
                                        local.get 58
                                        ref.as_non_null
                                        local.get 61
                                        array.get 137
                                        local.set 129
                                        local.get 78
                                        local.get 129
                                        i64.eq
                                        local.set 81
                                        local.get 81
                                        i32.eqz
                                        br_if 1 (;@17;)
                                        local.get 61
                                        i32.const 1
                                        i32.add
                                        local.set 61
                                        br 0 (;@18;)
                                      end
                                    end
                                  end
                                  local.get 81
                                  ref.null 137
                                  local.set 58
                                  ref.null 137
                                  local.set 57
                                  ref.null 133
                                  local.set 56
                                  ref.null 133
                                  local.set 55
                                else
                                  local.get 136
                                  i32.const 0
                                  i32.eq
                                  local.get 136
                                  i32.const 1
                                  i32.eq
                                  i32.or
                                  if (result i32) ;; label = @16
                                    i32.const 1
                                  else
                                    local.get 136
                                    i32.const 2
                                    i32.eq
                                    if (result i32) ;; label = @17
                                      local.get 154
                                      local.get 155
                                      i64.eq
                                    else
                                      local.get 130
                                      local.get 79
                                      ref.eq
                                    end
                                  end
                                end
                              end
                            end
                          else
                            i32.const 0
                          end
                          local.set 111
                          ref.null eq
                          local.set 130
                          ref.null 131
                          local.set 47
                          local.get 111
                          br_if 1 (;@10;)
                          local.get 90
                          i32.const 1
                          i32.add
                          local.set 90
                          br 0 (;@11;)
                        end
                      end
                      ref.null 83
                      local.set 143
                    end
                    local.get 111
                    if ;; label = @9
                      local.get 140
                      ref.as_non_null
                      ref.test (ref 79)
                      if ;; label = @10
                        local.get 140
                        ref.as_non_null
                        ref.cast (ref 79)
                        local.set 156
                        local.get 156
                        ref.as_non_null
                        struct.get 79 0
                        local.set 142
                        local.get 142
                        ref.as_non_null
                        struct.get 80 0
                        local.set 143
                        local.get 90
                        local.get 143
                        ref.as_non_null
                        array.len
                        i32.ge_u
                        local.get 90
                        i32.const 2
                        i32.ge_u
                        i32.or
                        if ;; label = @11
                          unreachable
                        end
                        ref.null 83
                        local.set 143
                        ref.null 80
                        local.set 142
                        local.get 156
                        ref.as_non_null
                        struct.get 79 1
                        local.set 53
                        local.get 53
                        local.get 90
                        i32.const 8
                        i32.mul
                        i32.shr_u
                        i32.const 255
                        i32.and
                        local.set 53
                        local.get 90
                        i32.eqz
                        if ;; label = @11
                          local.get 156
                          ref.as_non_null
                          struct.get 79 2
                          local.set 49
                          local.get 156
                          ref.as_non_null
                          struct.get 79 4
                          local.set 147
                        else
                          local.get 156
                          ref.as_non_null
                          struct.get 79 3
                          local.set 49
                          local.get 156
                          ref.as_non_null
                          struct.get 79 5
                          local.set 147
                        end
                        ref.null 79
                        local.set 156
                      else
                        local.get 140
                        ref.as_non_null
                        ref.cast (ref 78)
                        local.set 157
                        local.get 157
                        ref.as_non_null
                        struct.get 78 1
                        local.set 158
                        local.get 157
                        ref.as_non_null
                        struct.get 78 2
                        local.set 161
                        local.get 157
                        ref.as_non_null
                        struct.get 78 3
                        local.set 160
                        local.get 158
                        ref.as_non_null
                        local.get 90
                        array.get_u 84
                        local.set 53
                        i64.const 0
                        local.set 49
                        local.get 161
                        ref.is_null
                        i32.eqz
                        if ;; label = @11
                          local.get 161
                          ref.as_non_null
                          local.set 159
                          local.get 159
                          ref.as_non_null
                          local.get 90
                          array.get 85
                          local.set 49
                          ref.null 85
                          local.set 159
                        end
                        ref.null eq
                        local.set 147
                        local.get 160
                        ref.is_null
                        i32.eqz
                        if ;; label = @11
                          local.get 160
                          ref.as_non_null
                          local.set 162
                          local.get 162
                          ref.as_non_null
                          local.get 90
                          array.get 86
                          local.set 147
                          ref.null 86
                          local.set 162
                        end
                        ref.null 86
                        local.set 160
                        ref.null 85
                        local.set 161
                        ref.null 84
                        local.set 158
                        ref.null 78
                        local.set 157
                      end
                    end
                    ref.null 77
                    local.set 140
                  else
                    local.get 88
                    ref.as_non_null
                    local.get 144
                    local.get 155
                    local.get 79
                    call $helper::ordinary_property_find
                    local.set 163
                    ref.null 70
                    local.set 89
                    local.get 163
                    ref.is_null
                    i32.eqz
                    if ;; label = @9
                      local.get 163
                      ref.as_non_null
                      local.set 164
                      local.get 164
                      ref.as_non_null
                      struct.get 74 1
                      local.set 89
                      ref.null 74
                      local.set 164
                    end
                    local.get 89
                    ref.is_null
                    i32.eqz
                    if ;; label = @9
                      local.get 89
                      struct.get 70 0
                      local.set 90
                      local.get 90
                      i32.const 1
                      i32.and
                      i32.eqz
                      if ;; label = @10
                        local.get 89
                        struct.get 70 1
                        local.set 92
                        local.get 92
                        ref.as_non_null
                        ref.test (ref 62)
                        if ;; label = @11
                          local.get 92
                          ref.as_non_null
                          ref.cast (ref 62)
                          local.set 68
                          local.get 68
                          ref.as_non_null
                          struct.get 62 1
                          local.set 53
                          local.get 68
                          ref.as_non_null
                          struct.get 62 0
                          local.set 49
                          local.get 68
                          ref.as_non_null
                          struct.get 62 2
                          local.set 147
                          ref.null 62
                          local.set 68
                        else
                          local.get 92
                          ref.as_non_null
                          call $helper::property_value_resolve
                          local.set 84
                          local.get 84
                          ref.as_non_null
                          struct.get 62 1
                          local.set 53
                          local.get 84
                          ref.as_non_null
                          struct.get 62 0
                          local.set 49
                          local.get 84
                          ref.as_non_null
                          struct.get 62 2
                          local.set 147
                          ref.null 62
                          local.set 84
                        end
                        i32.const 1
                        local.set 111
                        ref.null 61
                        local.set 92
                      end
                    end
                    ref.null 70
                    local.set 89
                    ref.null 74
                    local.set 163
                  end
                  ref.null 76
                  local.set 139
                  ref.null 69
                  local.set 88
                end
                ref.null eq
                local.set 79
                i32.const 635
                local.set 144
                local.get 144
                call $helper::pooled_string_resolve
                local.set 47
                i32.const 4
                local.set 141
                i64.const 0
                local.set 155
                local.get 47
                ref.as_non_null
                local.set 79
                ref.null 131
                local.set 47
                i32.const 0
                local.set 111
                i32.const 0
                local.set 62
                i64.const 0
                local.set 74
                ref.null eq
                local.set 67
                local.get 148
                i32.const 6
                i32.eq
                local.get 148
                i32.const 7
                i32.eq
                i32.or
                local.get 148
                i32.const 8
                i32.eq
                i32.or
                local.get 148
                i32.const 9
                i32.eq
                i32.or
                if ;; label = @7
                  local.get 148
                  local.get 146
                  local.get 71
                  call $helper::object_header_projection
                  local.set 88
                  i32.const 0
                  local.set 111
                  local.get 88
                  ref.as_non_null
                  struct.get 69 1
                  local.set 139
                  local.get 139
                  ref.as_non_null
                  ref.test (ref 77)
                  if ;; label = @8
                    local.get 139
                    ref.as_non_null
                    ref.cast (ref 77)
                    local.set 140
                    i32.const 0
                    local.set 111
                    local.get 141
                    i32.const 4
                    i32.eq
                    if ;; label = @9
                      local.get 140
                      ref.as_non_null
                      struct.get 77 0
                      local.set 142
                      local.get 142
                      ref.as_non_null
                      struct.get 80 0
                      local.set 143
                      ref.null 80
                      local.set 142
                      local.get 143
                      ref.as_non_null
                      array.len
                      local.set 90
                      i32.const 0
                      local.set 144
                      block ;; label = @10
                        loop ;; label = @11
                          local.get 144
                          local.get 90
                          i32.ge_u
                          br_if 1 (;@10;)
                          local.get 143
                          ref.as_non_null
                          local.get 144
                          array.get 83
                          local.set 47
                          i32.const 4
                          local.set 136
                          i64.const 0
                          local.set 154
                          local.get 47
                          ref.as_non_null
                          local.set 128
                          local.get 136
                          local.get 141
                          i32.eq
                          if (result i32) ;; label = @12
                            local.get 136
                            i32.const 3
                            i32.eq
                            if (result i32) ;; label = @13
                              local.get 154
                              local.get 155
                              i64.eq
                              local.get 154
                              f64.reinterpret_i64
                              local.get 154
                              f64.reinterpret_i64
                              f64.ne
                              local.get 155
                              f64.reinterpret_i64
                              local.get 155
                              f64.reinterpret_i64
                              f64.ne
                              i32.and
                              i32.or
                            else
                              local.get 136
                              i32.const 4
                              i32.eq
                              if (result i32) ;; label = @14
                                local.get 128
                                local.get 79
                                ref.eq
                                if (result i32) ;; label = @15
                                  i32.const 1
                                else
                                  local.get 128
                                  ref.cast (ref 131)
                                  local.set 51
                                  local.get 79
                                  ref.cast (ref 131)
                                  local.set 45
                                  i32.const 0
                                  local.set 48
                                  local.get 51
                                  ref.as_non_null
                                  local.get 45
                                  ref.as_non_null
                                  local.get 48
                                  call $helper::string_equality
                                  local.set 131
                                  local.get 131
                                  ref.null 131
                                  local.set 45
                                  ref.null 131
                                  local.set 51
                                end
                              else
                                local.get 136
                                i32.const 10
                                i32.eq
                                if (result i32) ;; label = @15
                                  local.get 128
                                  ref.cast (ref 133)
                                  local.set 55
                                  local.get 79
                                  ref.cast (ref 133)
                                  local.set 56
                                  local.get 55
                                  ref.as_non_null
                                  struct.get 133 0
                                  local.set 44
                                  local.get 56
                                  ref.as_non_null
                                  struct.get 133 0
                                  local.set 48
                                  local.get 55
                                  ref.as_non_null
                                  struct.get 133 1
                                  local.set 58
                                  local.get 56
                                  ref.as_non_null
                                  struct.get 133 1
                                  local.set 57
                                  local.get 58
                                  ref.as_non_null
                                  array.len
                                  local.set 131
                                  local.get 57
                                  ref.as_non_null
                                  array.len
                                  local.set 134
                                  local.get 44
                                  local.get 48
                                  i32.eq
                                  local.get 131
                                  local.get 134
                                  i32.eq
                                  i32.and
                                  local.set 61
                                  local.get 61
                                  if ;; label = @16
                                    i32.const 0
                                    local.set 135
                                    block ;; label = @17
                                      loop ;; label = @18
                                        local.get 135
                                        local.get 131
                                        i32.ge_u
                                        br_if 1 (;@17;)
                                        local.get 58
                                        ref.as_non_null
                                        local.get 135
                                        array.get 137
                                        local.set 127
                                        local.get 57
                                        ref.as_non_null
                                        local.get 135
                                        array.get 137
                                        local.set 78
                                        local.get 127
                                        local.get 78
                                        i64.eq
                                        local.set 61
                                        local.get 61
                                        i32.eqz
                                        br_if 1 (;@17;)
                                        local.get 135
                                        i32.const 1
                                        i32.add
                                        local.set 135
                                        br 0 (;@18;)
                                      end
                                    end
                                  end
                                  local.get 61
                                  ref.null 137
                                  local.set 57
                                  ref.null 137
                                  local.set 58
                                  ref.null 133
                                  local.set 56
                                  ref.null 133
                                  local.set 55
                                else
                                  local.get 136
                                  i32.const 0
                                  i32.eq
                                  local.get 136
                                  i32.const 1
                                  i32.eq
                                  i32.or
                                  if (result i32) ;; label = @16
                                    i32.const 1
                                  else
                                    local.get 136
                                    i32.const 2
                                    i32.eq
                                    if (result i32) ;; label = @17
                                      local.get 154
                                      local.get 155
                                      i64.eq
                                    else
                                      local.get 128
                                      local.get 79
                                      ref.eq
                                    end
                                  end
                                end
                              end
                            end
                          else
                            i32.const 0
                          end
                          local.set 111
                          ref.null eq
                          local.set 128
                          ref.null 131
                          local.set 47
                          local.get 111
                          br_if 1 (;@10;)
                          local.get 144
                          i32.const 1
                          i32.add
                          local.set 144
                          br 0 (;@11;)
                        end
                      end
                      ref.null 83
                      local.set 143
                    end
                    local.get 111
                    if ;; label = @9
                      local.get 140
                      ref.as_non_null
                      ref.test (ref 79)
                      if ;; label = @10
                        local.get 140
                        ref.as_non_null
                        ref.cast (ref 79)
                        local.set 156
                        local.get 156
                        ref.as_non_null
                        struct.get 79 0
                        local.set 142
                        local.get 142
                        ref.as_non_null
                        struct.get 80 0
                        local.set 143
                        local.get 144
                        local.get 143
                        ref.as_non_null
                        array.len
                        i32.ge_u
                        local.get 144
                        i32.const 2
                        i32.ge_u
                        i32.or
                        if ;; label = @11
                          unreachable
                        end
                        ref.null 83
                        local.set 143
                        ref.null 80
                        local.set 142
                        local.get 156
                        ref.as_non_null
                        struct.get 79 1
                        local.set 62
                        local.get 62
                        local.get 144
                        i32.const 8
                        i32.mul
                        i32.shr_u
                        i32.const 255
                        i32.and
                        local.set 62
                        local.get 144
                        i32.eqz
                        if ;; label = @11
                          local.get 156
                          ref.as_non_null
                          struct.get 79 2
                          local.set 74
                          local.get 156
                          ref.as_non_null
                          struct.get 79 4
                          local.set 67
                        else
                          local.get 156
                          ref.as_non_null
                          struct.get 79 3
                          local.set 74
                          local.get 156
                          ref.as_non_null
                          struct.get 79 5
                          local.set 67
                        end
                        ref.null 79
                        local.set 156
                      else
                        local.get 140
                        ref.as_non_null
                        ref.cast (ref 78)
                        local.set 157
                        local.get 157
                        ref.as_non_null
                        struct.get 78 1
                        local.set 158
                        local.get 157
                        ref.as_non_null
                        struct.get 78 2
                        local.set 161
                        local.get 157
                        ref.as_non_null
                        struct.get 78 3
                        local.set 160
                        local.get 158
                        ref.as_non_null
                        local.get 144
                        array.get_u 84
                        local.set 62
                        i64.const 0
                        local.set 74
                        local.get 161
                        ref.is_null
                        i32.eqz
                        if ;; label = @11
                          local.get 161
                          ref.as_non_null
                          local.set 159
                          local.get 159
                          ref.as_non_null
                          local.get 144
                          array.get 85
                          local.set 74
                          ref.null 85
                          local.set 159
                        end
                        ref.null eq
                        local.set 67
                        local.get 160
                        ref.is_null
                        i32.eqz
                        if ;; label = @11
                          local.get 160
                          ref.as_non_null
                          local.set 162
                          local.get 162
                          ref.as_non_null
                          local.get 144
                          array.get 86
                          local.set 67
                          ref.null 86
                          local.set 162
                        end
                        ref.null 86
                        local.set 160
                        ref.null 85
                        local.set 161
                        ref.null 84
                        local.set 158
                        ref.null 78
                        local.set 157
                      end
                    end
                    ref.null 77
                    local.set 140
                  else
                    local.get 88
                    ref.as_non_null
                    local.get 141
                    local.get 155
                    local.get 79
                    call $helper::ordinary_property_find
                    local.set 163
                    ref.null 70
                    local.set 89
                    local.get 163
                    ref.is_null
                    i32.eqz
                    if ;; label = @9
                      local.get 163
                      ref.as_non_null
                      local.set 164
                      local.get 164
                      ref.as_non_null
                      struct.get 74 1
                      local.set 89
                      ref.null 74
                      local.set 164
                    end
                    local.get 89
                    ref.is_null
                    i32.eqz
                    if ;; label = @9
                      local.get 89
                      struct.get 70 0
                      local.set 90
                      local.get 90
                      i32.const 1
                      i32.and
                      i32.eqz
                      if ;; label = @10
                        local.get 89
                        struct.get 70 1
                        local.set 92
                        local.get 92
                        ref.as_non_null
                        ref.test (ref 62)
                        if ;; label = @11
                          local.get 92
                          ref.as_non_null
                          ref.cast (ref 62)
                          local.set 84
                          local.get 84
                          ref.as_non_null
                          struct.get 62 1
                          local.set 62
                          local.get 84
                          ref.as_non_null
                          struct.get 62 0
                          local.set 74
                          local.get 84
                          ref.as_non_null
                          struct.get 62 2
                          local.set 67
                          ref.null 62
                          local.set 84
                        else
                          local.get 92
                          ref.as_non_null
                          call $helper::property_value_resolve
                          local.set 68
                          local.get 68
                          ref.as_non_null
                          struct.get 62 1
                          local.set 62
                          local.get 68
                          ref.as_non_null
                          struct.get 62 0
                          local.set 74
                          local.get 68
                          ref.as_non_null
                          struct.get 62 2
                          local.set 67
                          ref.null 62
                          local.set 68
                        end
                        i32.const 1
                        local.set 111
                        ref.null 61
                        local.set 92
                      end
                    end
                    ref.null 70
                    local.set 89
                    ref.null 74
                    local.set 163
                  end
                  ref.null 76
                  local.set 139
                  ref.null 69
                  local.set 88
                end
                local.get 111
                local.set 102
                ref.null eq
                local.set 79
                i32.const 636
                local.set 144
                local.get 144
                call $helper::pooled_string_resolve
                local.set 47
                i32.const 4
                local.set 141
                i64.const 0
                local.set 155
                local.get 47
                ref.as_non_null
                local.set 79
                ref.null 131
                local.set 47
                i32.const 0
                local.set 111
                i32.const 0
                local.set 153
                i64.const 0
                local.set 76
                ref.null eq
                local.set 75
                local.get 148
                i32.const 6
                i32.eq
                local.get 148
                i32.const 7
                i32.eq
                i32.or
                local.get 148
                i32.const 8
                i32.eq
                i32.or
                local.get 148
                i32.const 9
                i32.eq
                i32.or
                if ;; label = @7
                  local.get 148
                  local.get 146
                  local.get 71
                  call $helper::object_header_projection
                  local.set 88
                  i32.const 0
                  local.set 111
                  local.get 88
                  ref.as_non_null
                  struct.get 69 1
                  local.set 139
                  local.get 139
                  ref.as_non_null
                  ref.test (ref 77)
                  if ;; label = @8
                    local.get 139
                    ref.as_non_null
                    ref.cast (ref 77)
                    local.set 140
                    i32.const 0
                    local.set 111
                    local.get 141
                    i32.const 4
                    i32.eq
                    if ;; label = @9
                      local.get 140
                      ref.as_non_null
                      struct.get 77 0
                      local.set 142
                      local.get 142
                      ref.as_non_null
                      struct.get 80 0
                      local.set 143
                      ref.null 80
                      local.set 142
                      local.get 143
                      ref.as_non_null
                      array.len
                      local.set 90
                      i32.const 0
                      local.set 144
                      block ;; label = @10
                        loop ;; label = @11
                          local.get 144
                          local.get 90
                          i32.ge_u
                          br_if 1 (;@10;)
                          local.get 143
                          ref.as_non_null
                          local.get 144
                          array.get 83
                          local.set 47
                          i32.const 4
                          local.set 136
                          i64.const 0
                          local.set 154
                          local.get 47
                          ref.as_non_null
                          local.set 130
                          local.get 136
                          local.get 141
                          i32.eq
                          if (result i32) ;; label = @12
                            local.get 136
                            i32.const 3
                            i32.eq
                            if (result i32) ;; label = @13
                              local.get 154
                              local.get 155
                              i64.eq
                              local.get 154
                              f64.reinterpret_i64
                              local.get 154
                              f64.reinterpret_i64
                              f64.ne
                              local.get 155
                              f64.reinterpret_i64
                              local.get 155
                              f64.reinterpret_i64
                              f64.ne
                              i32.and
                              i32.or
                            else
                              local.get 136
                              i32.const 4
                              i32.eq
                              if (result i32) ;; label = @14
                                local.get 130
                                local.get 79
                                ref.eq
                                if (result i32) ;; label = @15
                                  i32.const 1
                                else
                                  local.get 130
                                  ref.cast (ref 131)
                                  local.set 51
                                  local.get 79
                                  ref.cast (ref 131)
                                  local.set 45
                                  i32.const 0
                                  local.set 81
                                  local.get 51
                                  ref.as_non_null
                                  local.get 45
                                  ref.as_non_null
                                  local.get 81
                                  call $helper::string_equality
                                  local.set 44
                                  local.get 44
                                  ref.null 131
                                  local.set 45
                                  ref.null 131
                                  local.set 51
                                end
                              else
                                local.get 136
                                i32.const 10
                                i32.eq
                                if (result i32) ;; label = @15
                                  local.get 130
                                  ref.cast (ref 133)
                                  local.set 55
                                  local.get 79
                                  ref.cast (ref 133)
                                  local.set 56
                                  local.get 55
                                  ref.as_non_null
                                  struct.get 133 0
                                  local.set 48
                                  local.get 56
                                  ref.as_non_null
                                  struct.get 133 0
                                  local.set 81
                                  local.get 55
                                  ref.as_non_null
                                  struct.get 133 1
                                  local.set 57
                                  local.get 56
                                  ref.as_non_null
                                  struct.get 133 1
                                  local.set 58
                                  local.get 57
                                  ref.as_non_null
                                  array.len
                                  local.set 44
                                  local.get 58
                                  ref.as_non_null
                                  array.len
                                  local.set 131
                                  local.get 48
                                  local.get 81
                                  i32.eq
                                  local.get 44
                                  local.get 131
                                  i32.eq
                                  i32.and
                                  local.set 135
                                  local.get 135
                                  if ;; label = @16
                                    i32.const 0
                                    local.set 134
                                    block ;; label = @17
                                      loop ;; label = @18
                                        local.get 134
                                        local.get 44
                                        i32.ge_u
                                        br_if 1 (;@17;)
                                        local.get 57
                                        ref.as_non_null
                                        local.get 134
                                        array.get 137
                                        local.set 129
                                        local.get 58
                                        ref.as_non_null
                                        local.get 134
                                        array.get 137
                                        local.set 127
                                        local.get 129
                                        local.get 127
                                        i64.eq
                                        local.set 135
                                        local.get 135
                                        i32.eqz
                                        br_if 1 (;@17;)
                                        local.get 134
                                        i32.const 1
                                        i32.add
                                        local.set 134
                                        br 0 (;@18;)
                                      end
                                    end
                                  end
                                  local.get 135
                                  ref.null 137
                                  local.set 58
                                  ref.null 137
                                  local.set 57
                                  ref.null 133
                                  local.set 56
                                  ref.null 133
                                  local.set 55
                                else
                                  local.get 136
                                  i32.const 0
                                  i32.eq
                                  local.get 136
                                  i32.const 1
                                  i32.eq
                                  i32.or
                                  if (result i32) ;; label = @16
                                    i32.const 1
                                  else
                                    local.get 136
                                    i32.const 2
                                    i32.eq
                                    if (result i32) ;; label = @17
                                      local.get 154
                                      local.get 155
                                      i64.eq
                                    else
                                      local.get 130
                                      local.get 79
                                      ref.eq
                                    end
                                  end
                                end
                              end
                            end
                          else
                            i32.const 0
                          end
                          local.set 111
                          ref.null eq
                          local.set 130
                          ref.null 131
                          local.set 47
                          local.get 111
                          br_if 1 (;@10;)
                          local.get 144
                          i32.const 1
                          i32.add
                          local.set 144
                          br 0 (;@11;)
                        end
                      end
                      ref.null 83
                      local.set 143
                    end
                    local.get 111
                    if ;; label = @9
                      local.get 140
                      ref.as_non_null
                      ref.test (ref 79)
                      if ;; label = @10
                        local.get 140
                        ref.as_non_null
                        ref.cast (ref 79)
                        local.set 156
                        local.get 156
                        ref.as_non_null
                        struct.get 79 0
                        local.set 142
                        local.get 142
                        ref.as_non_null
                        struct.get 80 0
                        local.set 143
                        local.get 144
                        local.get 143
                        ref.as_non_null
                        array.len
                        i32.ge_u
                        local.get 144
                        i32.const 2
                        i32.ge_u
                        i32.or
                        if ;; label = @11
                          unreachable
                        end
                        ref.null 83
                        local.set 143
                        ref.null 80
                        local.set 142
                        local.get 156
                        ref.as_non_null
                        struct.get 79 1
                        local.set 153
                        local.get 153
                        local.get 144
                        i32.const 8
                        i32.mul
                        i32.shr_u
                        i32.const 255
                        i32.and
                        local.set 153
                        local.get 144
                        i32.eqz
                        if ;; label = @11
                          local.get 156
                          ref.as_non_null
                          struct.get 79 2
                          local.set 76
                          local.get 156
                          ref.as_non_null
                          struct.get 79 4
                          local.set 75
                        else
                          local.get 156
                          ref.as_non_null
                          struct.get 79 3
                          local.set 76
                          local.get 156
                          ref.as_non_null
                          struct.get 79 5
                          local.set 75
                        end
                        ref.null 79
                        local.set 156
                      else
                        local.get 140
                        ref.as_non_null
                        ref.cast (ref 78)
                        local.set 157
                        local.get 157
                        ref.as_non_null
                        struct.get 78 1
                        local.set 158
                        local.get 157
                        ref.as_non_null
                        struct.get 78 2
                        local.set 161
                        local.get 157
                        ref.as_non_null
                        struct.get 78 3
                        local.set 160
                        local.get 158
                        ref.as_non_null
                        local.get 144
                        array.get_u 84
                        local.set 153
                        i64.const 0
                        local.set 76
                        local.get 161
                        ref.is_null
                        i32.eqz
                        if ;; label = @11
                          local.get 161
                          ref.as_non_null
                          local.set 159
                          local.get 159
                          ref.as_non_null
                          local.get 144
                          array.get 85
                          local.set 76
                          ref.null 85
                          local.set 159
                        end
                        ref.null eq
                        local.set 75
                        local.get 160
                        ref.is_null
                        i32.eqz
                        if ;; label = @11
                          local.get 160
                          ref.as_non_null
                          local.set 162
                          local.get 162
                          ref.as_non_null
                          local.get 144
                          array.get 86
                          local.set 75
                          ref.null 86
                          local.set 162
                        end
                        ref.null 86
                        local.set 160
                        ref.null 85
                        local.set 161
                        ref.null 84
                        local.set 158
                        ref.null 78
                        local.set 157
                      end
                    end
                    ref.null 77
                    local.set 140
                  else
                    local.get 88
                    ref.as_non_null
                    local.get 141
                    local.get 155
                    local.get 79
                    call $helper::ordinary_property_find
                    local.set 163
                    ref.null 70
                    local.set 89
                    local.get 163
                    ref.is_null
                    i32.eqz
                    if ;; label = @9
                      local.get 163
                      ref.as_non_null
                      local.set 164
                      local.get 164
                      ref.as_non_null
                      struct.get 74 1
                      local.set 89
                      ref.null 74
                      local.set 164
                    end
                    local.get 89
                    ref.is_null
                    i32.eqz
                    if ;; label = @9
                      local.get 89
                      struct.get 70 0
                      local.set 90
                      local.get 90
                      i32.const 1
                      i32.and
                      i32.eqz
                      if ;; label = @10
                        local.get 89
                        struct.get 70 1
                        local.set 92
                        local.get 92
                        ref.as_non_null
                        ref.test (ref 62)
                        if ;; label = @11
                          local.get 92
                          ref.as_non_null
                          ref.cast (ref 62)
                          local.set 68
                          local.get 68
                          ref.as_non_null
                          struct.get 62 1
                          local.set 153
                          local.get 68
                          ref.as_non_null
                          struct.get 62 0
                          local.set 76
                          local.get 68
                          ref.as_non_null
                          struct.get 62 2
                          local.set 75
                          ref.null 62
                          local.set 68
                        else
                          local.get 92
                          ref.as_non_null
                          call $helper::property_value_resolve
                          local.set 84
                          local.get 84
                          ref.as_non_null
                          struct.get 62 1
                          local.set 153
                          local.get 84
                          ref.as_non_null
                          struct.get 62 0
                          local.set 76
                          local.get 84
                          ref.as_non_null
                          struct.get 62 2
                          local.set 75
                          ref.null 62
                          local.set 84
                        end
                        i32.const 1
                        local.set 111
                        ref.null 61
                        local.set 92
                      end
                    end
                    ref.null 70
                    local.set 89
                    ref.null 74
                    local.set 163
                  end
                  ref.null 76
                  local.set 139
                  ref.null 69
                  local.set 88
                end
                ref.null eq
                local.set 79
                i32.const 646
                local.set 141
                local.get 141
                call $helper::pooled_string_resolve
                local.set 47
                i32.const 4
                local.set 144
                i64.const 0
                local.set 155
                local.get 47
                ref.as_non_null
                local.set 79
                ref.null 131
                local.set 47
                i32.const 0
                local.set 111
                i32.const 0
                local.set 151
                i64.const 0
                local.set 137
                ref.null eq
                local.set 83
                local.get 148
                i32.const 6
                i32.eq
                local.get 148
                i32.const 7
                i32.eq
                i32.or
                local.get 148
                i32.const 8
                i32.eq
                i32.or
                local.get 148
                i32.const 9
                i32.eq
                i32.or
                if ;; label = @7
                  local.get 148
                  local.get 146
                  local.get 71
                  call $helper::object_header_projection
                  local.set 88
                  i32.const 0
                  local.set 111
                  local.get 88
                  ref.as_non_null
                  struct.get 69 1
                  local.set 139
                  local.get 139
                  ref.as_non_null
                  ref.test (ref 77)
                  if ;; label = @8
                    local.get 139
                    ref.as_non_null
                    ref.cast (ref 77)
                    local.set 140
                    i32.const 0
                    local.set 111
                    local.get 144
                    i32.const 4
                    i32.eq
                    if ;; label = @9
                      local.get 140
                      ref.as_non_null
                      struct.get 77 0
                      local.set 142
                      local.get 142
                      ref.as_non_null
                      struct.get 80 0
                      local.set 143
                      ref.null 80
                      local.set 142
                      local.get 143
                      ref.as_non_null
                      array.len
                      local.set 90
                      i32.const 0
                      local.set 141
                      block ;; label = @10
                        loop ;; label = @11
                          local.get 141
                          local.get 90
                          i32.ge_u
                          br_if 1 (;@10;)
                          local.get 143
                          ref.as_non_null
                          local.get 141
                          array.get 83
                          local.set 47
                          i32.const 4
                          local.set 136
                          i64.const 0
                          local.set 154
                          local.get 47
                          ref.as_non_null
                          local.set 128
                          local.get 136
                          local.get 144
                          i32.eq
                          if (result i32) ;; label = @12
                            local.get 136
                            i32.const 3
                            i32.eq
                            if (result i32) ;; label = @13
                              local.get 154
                              local.get 155
                              i64.eq
                              local.get 154
                              f64.reinterpret_i64
                              local.get 154
                              f64.reinterpret_i64
                              f64.ne
                              local.get 155
                              f64.reinterpret_i64
                              local.get 155
                              f64.reinterpret_i64
                              f64.ne
                              i32.and
                              i32.or
                            else
                              local.get 136
                              i32.const 4
                              i32.eq
                              if (result i32) ;; label = @14
                                local.get 128
                                local.get 79
                                ref.eq
                                if (result i32) ;; label = @15
                                  i32.const 1
                                else
                                  local.get 128
                                  ref.cast (ref 131)
                                  local.set 51
                                  local.get 79
                                  ref.cast (ref 131)
                                  local.set 45
                                  i32.const 0
                                  local.set 61
                                  local.get 51
                                  ref.as_non_null
                                  local.get 45
                                  ref.as_non_null
                                  local.get 61
                                  call $helper::string_equality
                                  local.set 48
                                  local.get 48
                                  ref.null 131
                                  local.set 45
                                  ref.null 131
                                  local.set 51
                                end
                              else
                                local.get 136
                                i32.const 10
                                i32.eq
                                if (result i32) ;; label = @15
                                  local.get 128
                                  ref.cast (ref 133)
                                  local.set 55
                                  local.get 79
                                  ref.cast (ref 133)
                                  local.set 56
                                  local.get 55
                                  ref.as_non_null
                                  struct.get 133 0
                                  local.set 81
                                  local.get 56
                                  ref.as_non_null
                                  struct.get 133 0
                                  local.set 61
                                  local.get 55
                                  ref.as_non_null
                                  struct.get 133 1
                                  local.set 58
                                  local.get 56
                                  ref.as_non_null
                                  struct.get 133 1
                                  local.set 57
                                  local.get 58
                                  ref.as_non_null
                                  array.len
                                  local.set 48
                                  local.get 57
                                  ref.as_non_null
                                  array.len
                                  local.set 44
                                  local.get 81
                                  local.get 61
                                  i32.eq
                                  local.get 48
                                  local.get 44
                                  i32.eq
                                  i32.and
                                  local.set 134
                                  local.get 134
                                  if ;; label = @16
                                    i32.const 0
                                    local.set 131
                                    block ;; label = @17
                                      loop ;; label = @18
                                        local.get 131
                                        local.get 48
                                        i32.ge_u
                                        br_if 1 (;@17;)
                                        local.get 58
                                        ref.as_non_null
                                        local.get 131
                                        array.get 137
                                        local.set 78
                                        local.get 57
                                        ref.as_non_null
                                        local.get 131
                                        array.get 137
                                        local.set 129
                                        local.get 78
                                        local.get 129
                                        i64.eq
                                        local.set 134
                                        local.get 134
                                        i32.eqz
                                        br_if 1 (;@17;)
                                        local.get 131
                                        i32.const 1
                                        i32.add
                                        local.set 131
                                        br 0 (;@18;)
                                      end
                                    end
                                  end
                                  local.get 134
                                  ref.null 137
                                  local.set 57
                                  ref.null 137
                                  local.set 58
                                  ref.null 133
                                  local.set 56
                                  ref.null 133
                                  local.set 55
                                else
                                  local.get 136
                                  i32.const 0
                                  i32.eq
                                  local.get 136
                                  i32.const 1
                                  i32.eq
                                  i32.or
                                  if (result i32) ;; label = @16
                                    i32.const 1
                                  else
                                    local.get 136
                                    i32.const 2
                                    i32.eq
                                    if (result i32) ;; label = @17
                                      local.get 154
                                      local.get 155
                                      i64.eq
                                    else
                                      local.get 128
                                      local.get 79
                                      ref.eq
                                    end
                                  end
                                end
                              end
                            end
                          else
                            i32.const 0
                          end
                          local.set 111
                          ref.null eq
                          local.set 128
                          ref.null 131
                          local.set 47
                          local.get 111
                          br_if 1 (;@10;)
                          local.get 141
                          i32.const 1
                          i32.add
                          local.set 141
                          br 0 (;@11;)
                        end
                      end
                      ref.null 83
                      local.set 143
                    end
                    local.get 111
                    if ;; label = @9
                      local.get 140
                      ref.as_non_null
                      ref.test (ref 79)
                      if ;; label = @10
                        local.get 140
                        ref.as_non_null
                        ref.cast (ref 79)
                        local.set 156
                        local.get 156
                        ref.as_non_null
                        struct.get 79 0
                        local.set 142
                        local.get 142
                        ref.as_non_null
                        struct.get 80 0
                        local.set 143
                        local.get 141
                        local.get 143
                        ref.as_non_null
                        array.len
                        i32.ge_u
                        local.get 141
                        i32.const 2
                        i32.ge_u
                        i32.or
                        if ;; label = @11
                          unreachable
                        end
                        ref.null 83
                        local.set 143
                        ref.null 80
                        local.set 142
                        local.get 156
                        ref.as_non_null
                        struct.get 79 1
                        local.set 151
                        local.get 151
                        local.get 141
                        i32.const 8
                        i32.mul
                        i32.shr_u
                        i32.const 255
                        i32.and
                        local.set 151
                        local.get 141
                        i32.eqz
                        if ;; label = @11
                          local.get 156
                          ref.as_non_null
                          struct.get 79 2
                          local.set 137
                          local.get 156
                          ref.as_non_null
                          struct.get 79 4
                          local.set 83
                        else
                          local.get 156
                          ref.as_non_null
                          struct.get 79 3
                          local.set 137
                          local.get 156
                          ref.as_non_null
                          struct.get 79 5
                          local.set 83
                        end
                        ref.null 79
                        local.set 156
                      else
                        local.get 140
                        ref.as_non_null
                        ref.cast (ref 78)
                        local.set 157
                        local.get 157
                        ref.as_non_null
                        struct.get 78 1
                        local.set 158
                        local.get 157
                        ref.as_non_null
                        struct.get 78 2
                        local.set 161
                        local.get 157
                        ref.as_non_null
                        struct.get 78 3
                        local.set 160
                        local.get 158
                        ref.as_non_null
                        local.get 141
                        array.get_u 84
                        local.set 151
                        i64.const 0
                        local.set 137
                        local.get 161
                        ref.is_null
                        i32.eqz
                        if ;; label = @11
                          local.get 161
                          ref.as_non_null
                          local.set 159
                          local.get 159
                          ref.as_non_null
                          local.get 141
                          array.get 85
                          local.set 137
                          ref.null 85
                          local.set 159
                        end
                        ref.null eq
                        local.set 83
                        local.get 160
                        ref.is_null
                        i32.eqz
                        if ;; label = @11
                          local.get 160
                          ref.as_non_null
                          local.set 162
                          local.get 162
                          ref.as_non_null
                          local.get 141
                          array.get 86
                          local.set 83
                          ref.null 86
                          local.set 162
                        end
                        ref.null 86
                        local.set 160
                        ref.null 85
                        local.set 161
                        ref.null 84
                        local.set 158
                        ref.null 78
                        local.set 157
                      end
                    end
                    ref.null 77
                    local.set 140
                  else
                    local.get 88
                    ref.as_non_null
                    local.get 144
                    local.get 155
                    local.get 79
                    call $helper::ordinary_property_find
                    local.set 163
                    ref.null 70
                    local.set 89
                    local.get 163
                    ref.is_null
                    i32.eqz
                    if ;; label = @9
                      local.get 163
                      ref.as_non_null
                      local.set 164
                      local.get 164
                      ref.as_non_null
                      struct.get 74 1
                      local.set 89
                      ref.null 74
                      local.set 164
                    end
                    local.get 89
                    ref.is_null
                    i32.eqz
                    if ;; label = @9
                      local.get 89
                      struct.get 70 0
                      local.set 90
                      local.get 90
                      i32.const 1
                      i32.and
                      i32.eqz
                      if ;; label = @10
                        local.get 89
                        struct.get 70 1
                        local.set 92
                        local.get 92
                        ref.as_non_null
                        ref.test (ref 62)
                        if ;; label = @11
                          local.get 92
                          ref.as_non_null
                          ref.cast (ref 62)
                          local.set 84
                          local.get 84
                          ref.as_non_null
                          struct.get 62 1
                          local.set 151
                          local.get 84
                          ref.as_non_null
                          struct.get 62 0
                          local.set 137
                          local.get 84
                          ref.as_non_null
                          struct.get 62 2
                          local.set 83
                          ref.null 62
                          local.set 84
                        else
                          local.get 92
                          ref.as_non_null
                          call $helper::property_value_resolve
                          local.set 68
                          local.get 68
                          ref.as_non_null
                          struct.get 62 1
                          local.set 151
                          local.get 68
                          ref.as_non_null
                          struct.get 62 0
                          local.set 137
                          local.get 68
                          ref.as_non_null
                          struct.get 62 2
                          local.set 83
                          ref.null 62
                          local.set 68
                        end
                        i32.const 1
                        local.set 111
                        ref.null 61
                        local.set 92
                      end
                    end
                    ref.null 70
                    local.set 89
                    ref.null 74
                    local.set 163
                  end
                  ref.null 76
                  local.set 139
                  ref.null 69
                  local.set 88
                end
                ref.null eq
                local.set 79
                i32.const 647
                local.set 144
                local.get 144
                call $helper::pooled_string_resolve
                local.set 47
                i32.const 4
                local.set 141
                i64.const 0
                local.set 155
                local.get 47
                ref.as_non_null
                local.set 79
                ref.null 131
                local.set 47
                i32.const 0
                local.set 111
                i32.const 0
                local.set 149
                i64.const 0
                local.set 106
                ref.null eq
                local.set 125
                local.get 148
                i32.const 6
                i32.eq
                local.get 148
                i32.const 7
                i32.eq
                i32.or
                local.get 148
                i32.const 8
                i32.eq
                i32.or
                local.get 148
                i32.const 9
                i32.eq
                i32.or
                if ;; label = @7
                  local.get 148
                  local.get 146
                  local.get 71
                  call $helper::object_header_projection
                  local.set 88
                  i32.const 0
                  local.set 111
                  local.get 88
                  ref.as_non_null
                  struct.get 69 1
                  local.set 139
                  local.get 139
                  ref.as_non_null
                  ref.test (ref 77)
                  if ;; label = @8
                    local.get 139
                    ref.as_non_null
                    ref.cast (ref 77)
                    local.set 140
                    i32.const 0
                    local.set 111
                    local.get 141
                    i32.const 4
                    i32.eq
                    if ;; label = @9
                      local.get 140
                      ref.as_non_null
                      struct.get 77 0
                      local.set 142
                      local.get 142
                      ref.as_non_null
                      struct.get 80 0
                      local.set 143
                      ref.null 80
                      local.set 142
                      local.get 143
                      ref.as_non_null
                      array.len
                      local.set 90
                      i32.const 0
                      local.set 144
                      block ;; label = @10
                        loop ;; label = @11
                          local.get 144
                          local.get 90
                          i32.ge_u
                          br_if 1 (;@10;)
                          local.get 143
                          ref.as_non_null
                          local.get 144
                          array.get 83
                          local.set 47
                          i32.const 4
                          local.set 136
                          i64.const 0
                          local.set 154
                          local.get 47
                          ref.as_non_null
                          local.set 130
                          local.get 136
                          local.get 141
                          i32.eq
                          if (result i32) ;; label = @12
                            local.get 136
                            i32.const 3
                            i32.eq
                            if (result i32) ;; label = @13
                              local.get 154
                              local.get 155
                              i64.eq
                              local.get 154
                              f64.reinterpret_i64
                              local.get 154
                              f64.reinterpret_i64
                              f64.ne
                              local.get 155
                              f64.reinterpret_i64
                              local.get 155
                              f64.reinterpret_i64
                              f64.ne
                              i32.and
                              i32.or
                            else
                              local.get 136
                              i32.const 4
                              i32.eq
                              if (result i32) ;; label = @14
                                local.get 130
                                local.get 79
                                ref.eq
                                if (result i32) ;; label = @15
                                  i32.const 1
                                else
                                  local.get 130
                                  ref.cast (ref 131)
                                  local.set 51
                                  local.get 79
                                  ref.cast (ref 131)
                                  local.set 45
                                  i32.const 0
                                  local.set 135
                                  local.get 51
                                  ref.as_non_null
                                  local.get 45
                                  ref.as_non_null
                                  local.get 135
                                  call $helper::string_equality
                                  local.set 81
                                  local.get 81
                                  ref.null 131
                                  local.set 45
                                  ref.null 131
                                  local.set 51
                                end
                              else
                                local.get 136
                                i32.const 10
                                i32.eq
                                if (result i32) ;; label = @15
                                  local.get 130
                                  ref.cast (ref 133)
                                  local.set 55
                                  local.get 79
                                  ref.cast (ref 133)
                                  local.set 56
                                  local.get 55
                                  ref.as_non_null
                                  struct.get 133 0
                                  local.set 61
                                  local.get 56
                                  ref.as_non_null
                                  struct.get 133 0
                                  local.set 135
                                  local.get 55
                                  ref.as_non_null
                                  struct.get 133 1
                                  local.set 57
                                  local.get 56
                                  ref.as_non_null
                                  struct.get 133 1
                                  local.set 58
                                  local.get 57
                                  ref.as_non_null
                                  array.len
                                  local.set 81
                                  local.get 58
                                  ref.as_non_null
                                  array.len
                                  local.set 48
                                  local.get 61
                                  local.get 135
                                  i32.eq
                                  local.get 81
                                  local.get 48
                                  i32.eq
                                  i32.and
                                  local.set 131
                                  local.get 131
                                  if ;; label = @16
                                    i32.const 0
                                    local.set 44
                                    block ;; label = @17
                                      loop ;; label = @18
                                        local.get 44
                                        local.get 81
                                        i32.ge_u
                                        br_if 1 (;@17;)
                                        local.get 57
                                        ref.as_non_null
                                        local.get 44
                                        array.get 137
                                        local.set 127
                                        local.get 58
                                        ref.as_non_null
                                        local.get 44
                                        array.get 137
                                        local.set 78
                                        local.get 127
                                        local.get 78
                                        i64.eq
                                        local.set 131
                                        local.get 131
                                        i32.eqz
                                        br_if 1 (;@17;)
                                        local.get 44
                                        i32.const 1
                                        i32.add
                                        local.set 44
                                        br 0 (;@18;)
                                      end
                                    end
                                  end
                                  local.get 131
                                  ref.null 137
                                  local.set 58
                                  ref.null 137
                                  local.set 57
                                  ref.null 133
                                  local.set 56
                                  ref.null 133
                                  local.set 55
                                else
                                  local.get 136
                                  i32.const 0
                                  i32.eq
                                  local.get 136
                                  i32.const 1
                                  i32.eq
                                  i32.or
                                  if (result i32) ;; label = @16
                                    i32.const 1
                                  else
                                    local.get 136
                                    i32.const 2
                                    i32.eq
                                    if (result i32) ;; label = @17
                                      local.get 154
                                      local.get 155
                                      i64.eq
                                    else
                                      local.get 130
                                      local.get 79
                                      ref.eq
                                    end
                                  end
                                end
                              end
                            end
                          else
                            i32.const 0
                          end
                          local.set 111
                          ref.null eq
                          local.set 130
                          ref.null 131
                          local.set 47
                          local.get 111
                          br_if 1 (;@10;)
                          local.get 144
                          i32.const 1
                          i32.add
                          local.set 144
                          br 0 (;@11;)
                        end
                      end
                      ref.null 83
                      local.set 143
                    end
                    local.get 111
                    if ;; label = @9
                      local.get 140
                      ref.as_non_null
                      ref.test (ref 79)
                      if ;; label = @10
                        local.get 140
                        ref.as_non_null
                        ref.cast (ref 79)
                        local.set 156
                        local.get 156
                        ref.as_non_null
                        struct.get 79 0
                        local.set 142
                        local.get 142
                        ref.as_non_null
                        struct.get 80 0
                        local.set 143
                        local.get 144
                        local.get 143
                        ref.as_non_null
                        array.len
                        i32.ge_u
                        local.get 144
                        i32.const 2
                        i32.ge_u
                        i32.or
                        if ;; label = @11
                          unreachable
                        end
                        ref.null 83
                        local.set 143
                        ref.null 80
                        local.set 142
                        local.get 156
                        ref.as_non_null
                        struct.get 79 1
                        local.set 149
                        local.get 149
                        local.get 144
                        i32.const 8
                        i32.mul
                        i32.shr_u
                        i32.const 255
                        i32.and
                        local.set 149
                        local.get 144
                        i32.eqz
                        if ;; label = @11
                          local.get 156
                          ref.as_non_null
                          struct.get 79 2
                          local.set 106
                          local.get 156
                          ref.as_non_null
                          struct.get 79 4
                          local.set 125
                        else
                          local.get 156
                          ref.as_non_null
                          struct.get 79 3
                          local.set 106
                          local.get 156
                          ref.as_non_null
                          struct.get 79 5
                          local.set 125
                        end
                        ref.null 79
                        local.set 156
                      else
                        local.get 140
                        ref.as_non_null
                        ref.cast (ref 78)
                        local.set 157
                        local.get 157
                        ref.as_non_null
                        struct.get 78 1
                        local.set 158
                        local.get 157
                        ref.as_non_null
                        struct.get 78 2
                        local.set 161
                        local.get 157
                        ref.as_non_null
                        struct.get 78 3
                        local.set 160
                        local.get 158
                        ref.as_non_null
                        local.get 144
                        array.get_u 84
                        local.set 149
                        i64.const 0
                        local.set 106
                        local.get 161
                        ref.is_null
                        i32.eqz
                        if ;; label = @11
                          local.get 161
                          ref.as_non_null
                          local.set 159
                          local.get 159
                          ref.as_non_null
                          local.get 144
                          array.get 85
                          local.set 106
                          ref.null 85
                          local.set 159
                        end
                        ref.null eq
                        local.set 125
                        local.get 160
                        ref.is_null
                        i32.eqz
                        if ;; label = @11
                          local.get 160
                          ref.as_non_null
                          local.set 162
                          local.get 162
                          ref.as_non_null
                          local.get 144
                          array.get 86
                          local.set 125
                          ref.null 86
                          local.set 162
                        end
                        ref.null 86
                        local.set 160
                        ref.null 85
                        local.set 161
                        ref.null 84
                        local.set 158
                        ref.null 78
                        local.set 157
                      end
                    end
                    ref.null 77
                    local.set 140
                  else
                    local.get 88
                    ref.as_non_null
                    local.get 141
                    local.get 155
                    local.get 79
                    call $helper::ordinary_property_find
                    local.set 163
                    ref.null 70
                    local.set 89
                    local.get 163
                    ref.is_null
                    i32.eqz
                    if ;; label = @9
                      local.get 163
                      ref.as_non_null
                      local.set 164
                      local.get 164
                      ref.as_non_null
                      struct.get 74 1
                      local.set 89
                      ref.null 74
                      local.set 164
                    end
                    local.get 89
                    ref.is_null
                    i32.eqz
                    if ;; label = @9
                      local.get 89
                      struct.get 70 0
                      local.set 90
                      local.get 90
                      i32.const 1
                      i32.and
                      i32.eqz
                      if ;; label = @10
                        local.get 89
                        struct.get 70 1
                        local.set 92
                        local.get 92
                        ref.as_non_null
                        ref.test (ref 62)
                        if ;; label = @11
                          local.get 92
                          ref.as_non_null
                          ref.cast (ref 62)
                          local.set 68
                          local.get 68
                          ref.as_non_null
                          struct.get 62 1
                          local.set 149
                          local.get 68
                          ref.as_non_null
                          struct.get 62 0
                          local.set 106
                          local.get 68
                          ref.as_non_null
                          struct.get 62 2
                          local.set 125
                          ref.null 62
                          local.set 68
                        else
                          local.get 92
                          ref.as_non_null
                          call $helper::property_value_resolve
                          local.set 84
                          local.get 84
                          ref.as_non_null
                          struct.get 62 1
                          local.set 149
                          local.get 84
                          ref.as_non_null
                          struct.get 62 0
                          local.set 106
                          local.get 84
                          ref.as_non_null
                          struct.get 62 2
                          local.set 125
                          ref.null 62
                          local.set 84
                        end
                        i32.const 1
                        local.set 111
                        ref.null 61
                        local.set 92
                      end
                    end
                    ref.null 70
                    local.set 89
                    ref.null 74
                    local.set 163
                  end
                  ref.null 76
                  local.set 139
                  ref.null 69
                  local.set 88
                end
                ref.null eq
                local.set 79
                local.get 53
                i32.const 2
                i32.eq
                if (result i32) ;; label = @7
                  local.get 49
                  i64.eqz
                  i32.eqz
                else
                  local.get 53
                  i32.const 4
                  i32.eq
                  if (result i32) ;; label = @8
                    local.get 147
                    ref.cast (ref 131)
                    local.set 47
                    local.get 47
                    ref.as_non_null
                    struct.get 131 0
                    local.set 46
                    local.get 46
                    ref.as_non_null
                    array.len
                    i32.eqz
                    i32.eqz
                    ref.null 132
                    local.set 46
                    ref.null 131
                    local.set 47
                  else
                    local.get 53
                    i32.const 3
                    i32.eq
                    if (result i32) ;; label = @9
                      local.get 49
                      f64.reinterpret_i64
                      f64.const 0x0p+0 (;=0;)
                      f64.eq
                      local.get 49
                      f64.reinterpret_i64
                      local.get 49
                      f64.reinterpret_i64
                      f64.ne
                      i32.or
                      i32.eqz
                    else
                      local.get 53
                      i32.const 10
                      i32.eq
                      if (result i32) ;; label = @10
                        local.get 147
                        ref.cast (ref 133)
                        local.set 56
                        local.get 56
                        ref.as_non_null
                        struct.get 133 1
                        local.set 58
                        local.get 58
                        ref.as_non_null
                        array.len
                        i32.eqz
                        i32.eqz
                        ref.null 137
                        local.set 58
                        ref.null 133
                        local.set 56
                      else
                        local.get 53
                        i32.const 0
                        i32.eq
                        local.get 53
                        i32.const 1
                        i32.eq
                        i32.or
                        if (result i32) ;; label = @11
                          i32.const 0
                        else
                          local.get 147
                          ref.test (ref 107)
                          if (result i32) ;; label = @12
                            local.get 147
                            ref.cast (ref 107)
                            local.set 116
                            local.get 116
                            ref.as_non_null
                            struct.get 107 11
                            local.set 141
                            local.get 141
                            ref.null 107
                            local.set 116
                          else
                            i32.const 0
                          end
                          i32.eqz
                        end
                      end
                    end
                  end
                end
                local.set 60
                local.get 151
                i32.const 2
                i32.eq
                if (result i32) ;; label = @7
                  local.get 137
                  i64.eqz
                  i32.eqz
                else
                  local.get 151
                  i32.const 4
                  i32.eq
                  if (result i32) ;; label = @8
                    local.get 83
                    ref.cast (ref 131)
                    local.set 51
                    local.get 51
                    ref.as_non_null
                    struct.get 131 0
                    local.set 46
                    local.get 46
                    ref.as_non_null
                    array.len
                    i32.eqz
                    i32.eqz
                    ref.null 132
                    local.set 46
                    ref.null 131
                    local.set 51
                  else
                    local.get 151
                    i32.const 3
                    i32.eq
                    if (result i32) ;; label = @9
                      local.get 137
                      f64.reinterpret_i64
                      f64.const 0x0p+0 (;=0;)
                      f64.eq
                      local.get 137
                      f64.reinterpret_i64
                      local.get 137
                      f64.reinterpret_i64
                      f64.ne
                      i32.or
                      i32.eqz
                    else
                      local.get 151
                      i32.const 10
                      i32.eq
                      if (result i32) ;; label = @10
                        local.get 83
                        ref.cast (ref 133)
                        local.set 56
                        local.get 56
                        ref.as_non_null
                        struct.get 133 1
                        local.set 58
                        local.get 58
                        ref.as_non_null
                        array.len
                        i32.eqz
                        i32.eqz
                        ref.null 137
                        local.set 58
                        ref.null 133
                        local.set 56
                      else
                        local.get 151
                        i32.const 0
                        i32.eq
                        local.get 151
                        i32.const 1
                        i32.eq
                        i32.or
                        if (result i32) ;; label = @11
                          i32.const 0
                        else
                          local.get 83
                          ref.test (ref 107)
                          if (result i32) ;; label = @12
                            local.get 83
                            ref.cast (ref 107)
                            local.set 116
                            local.get 116
                            ref.as_non_null
                            struct.get 107 11
                            local.set 144
                            local.get 144
                            ref.null 107
                            local.set 116
                          else
                            i32.const 0
                          end
                          i32.eqz
                        end
                      end
                    end
                  end
                end
                local.set 54
                local.get 149
                i32.const 2
                i32.eq
                if (result i32) ;; label = @7
                  local.get 106
                  i64.eqz
                  i32.eqz
                else
                  local.get 149
                  i32.const 4
                  i32.eq
                  if (result i32) ;; label = @8
                    local.get 125
                    ref.cast (ref 131)
                    local.set 51
                    local.get 51
                    ref.as_non_null
                    struct.get 131 0
                    local.set 46
                    local.get 46
                    ref.as_non_null
                    array.len
                    i32.eqz
                    i32.eqz
                    ref.null 132
                    local.set 46
                    ref.null 131
                    local.set 51
                  else
                    local.get 149
                    i32.const 3
                    i32.eq
                    if (result i32) ;; label = @9
                      local.get 106
                      f64.reinterpret_i64
                      f64.const 0x0p+0 (;=0;)
                      f64.eq
                      local.get 106
                      f64.reinterpret_i64
                      local.get 106
                      f64.reinterpret_i64
                      f64.ne
                      i32.or
                      i32.eqz
                    else
                      local.get 149
                      i32.const 10
                      i32.eq
                      if (result i32) ;; label = @10
                        local.get 125
                        ref.cast (ref 133)
                        local.set 56
                        local.get 56
                        ref.as_non_null
                        struct.get 133 1
                        local.set 58
                        local.get 58
                        ref.as_non_null
                        array.len
                        i32.eqz
                        i32.eqz
                        ref.null 137
                        local.set 58
                        ref.null 133
                        local.set 56
                      else
                        local.get 149
                        i32.const 0
                        i32.eq
                        local.get 149
                        i32.const 1
                        i32.eq
                        i32.or
                        if (result i32) ;; label = @11
                          i32.const 0
                        else
                          local.get 125
                          ref.test (ref 107)
                          if (result i32) ;; label = @12
                            local.get 125
                            ref.cast (ref 107)
                            local.set 116
                            local.get 116
                            ref.as_non_null
                            struct.get 107 11
                            local.set 144
                            local.get 144
                            ref.null 107
                            local.set 116
                          else
                            i32.const 0
                          end
                          i32.eqz
                        end
                      end
                    end
                  end
                end
                local.set 105
                local.get 63
                local.get 145
                local.get 112
                struct.new 62
                local.set 68
                local.get 74
                local.get 62
                local.get 67
                struct.new 62
                local.set 85
                local.get 76
                local.get 153
                local.get 75
                struct.new 62
                local.set 84
                local.get 102
                if ;; label = @7
                  i32.const 1
                  local.get 54
                  i32.eqz
                  i32.eqz
                  i32.const 8
                  i32.mul
                  i32.or
                  local.get 105
                  i32.eqz
                  i32.eqz
                  i32.const 2
                  i32.mul
                  i32.or
                  local.get 68
                  ref.as_non_null
                  local.get 85
                  ref.as_non_null
                  local.get 84
                  ref.as_non_null
                  struct.new 70
                  local.set 113
                else
                  i32.const 0
                  local.get 60
                  i32.eqz
                  i32.eqz
                  i32.const 4
                  i32.mul
                  i32.or
                  local.get 54
                  i32.eqz
                  i32.eqz
                  i32.const 8
                  i32.mul
                  i32.or
                  local.get 105
                  i32.eqz
                  i32.eqz
                  i32.const 2
                  i32.mul
                  i32.or
                  local.get 68
                  ref.as_non_null
                  local.get 85
                  ref.as_non_null
                  local.get 84
                  ref.as_non_null
                  struct.new 70
                  local.set 113
                end
                ref.null 62
                local.set 84
                ref.null 62
                local.set 85
                ref.null 62
                local.set 68
                ref.null eq
                local.set 125
                ref.null eq
                local.set 83
                ref.null eq
                local.set 147
                ref.null eq
                local.set 75
                ref.null eq
                local.set 67
                ref.null eq
                local.set 112
              end
              ref.null eq
              local.set 71
            end
          end
          local.get 113
          ref.is_null
          i32.eqz
          if ;; label = @4
            local.get 113
            ref.is_null
            i32.eqz
            if (result i32) ;; label = @5
              local.get 113
              struct.get 70 0
              local.set 148
              local.get 148
              i32.const 1
              i32.and
              i32.eqz
              i32.eqz
            else
              i32.const 0
            end
            if ;; label = @5
              i32.const 0
              local.set 136
              i64.const 0
              local.set 154
              ref.null eq
              local.set 128
              local.get 113
              ref.is_null
              i32.eqz
              if ;; label = @6
                local.get 113
                struct.get 70 2
                local.set 84
                local.get 84
                ref.as_non_null
                struct.get 62 1
                local.set 136
                local.get 84
                ref.as_non_null
                struct.get 62 0
                local.set 154
                local.get 84
                ref.as_non_null
                struct.get 62 2
                local.set 128
                ref.null 62
                local.set 84
              end
              local.get 136
              i32.const 0
              i32.eq
              if ;; label = @6
                i32.const 0
                local.set 30
                i64.const 0
                local.set 31
                ref.null eq
                local.set 32
                i32.const 0
                local.set 33
                i32.const 0
                local.set 34
              else
                global.get 22
                local.set 86
                i32.const 0
                local.set 94
                i64.const 0
                local.set 146
                ref.null eq
                local.set 71
                global.get 8
                ref.as_non_null
                local.set 70
                local.get 136
                local.get 154
                local.get 128
                local.get 21
                local.get 22
                local.get 23
                local.get 86
                ref.as_non_null
                local.get 70
                ref.as_non_null
                local.get 11
                local.get 29
                ref.as_non_null
                call $helper::proxy_call
                local.set 34
                local.set 33
                local.set 32
                local.set 31
                local.set 30
                local.get 70
                ref.as_non_null
                global.set 8
                ref.null 161
                local.set 70
                local.get 33
                i32.const 2
                i32.eq
                if ;; label = @7
                  local.get 30
                  local.set 30
                  local.get 31
                  local.set 31
                  local.get 32
                  local.set 32
                  i32.const 0
                  local.set 33
                  i32.const 0
                  local.set 34
                end
                ref.null eq
                local.set 71
                ref.null 99
                local.set 86
              end
            else
              i32.const 0
              local.set 136
              i64.const 0
              local.set 154
              ref.null eq
              local.set 128
              local.get 113
              ref.is_null
              i32.eqz
              if ;; label = @6
                local.get 113
                struct.get 70 1
                local.set 92
                local.get 92
                ref.as_non_null
                ref.test (ref 62)
                if ;; label = @7
                  local.get 92
                  ref.as_non_null
                  ref.cast (ref 62)
                  local.set 84
                  local.get 84
                  ref.as_non_null
                  struct.get 62 1
                  local.set 136
                  local.get 84
                  ref.as_non_null
                  struct.get 62 0
                  local.set 154
                  local.get 84
                  ref.as_non_null
                  struct.get 62 2
                  local.set 128
                  ref.null 62
                  local.set 84
                else
                  local.get 92
                  ref.as_non_null
                  call $helper::property_value_resolve
                  local.set 85
                  local.get 85
                  ref.as_non_null
                  struct.get 62 1
                  local.set 136
                  local.get 85
                  ref.as_non_null
                  struct.get 62 0
                  local.set 154
                  local.get 85
                  ref.as_non_null
                  struct.get 62 2
                  local.set 128
                  ref.null 62
                  local.set 85
                end
                ref.null 61
                local.set 92
              end
              local.get 136
              local.set 30
              local.get 154
              local.set 31
              local.get 128
              local.set 32
              i32.const 0
              local.set 33
              i32.const 0
              local.set 34
            end
          else
            i32.const 0
            local.set 103
            local.get 37
            ref.test (ref 145)
            if ;; label = @5
              i32.const 0
              local.set 134
              local.get 24
              i32.const 4
              i32.eq
              if ;; label = @6
                local.get 26
                ref.cast (ref 131)
                local.set 51
                i32.const 11
                local.set 145
                local.get 145
                call $helper::pooled_string_resolve
                local.set 45
                i32.const 0
                local.set 94
                local.get 51
                ref.as_non_null
                local.get 45
                ref.as_non_null
                local.get 94
                call $helper::string_equality
                local.set 145
                local.get 145
                if ;; label = @7
                  i32.const 1
                  local.set 134
                else
                  local.get 51
                  ref.as_non_null
                  call $helper::string_to_number
                  local.set 63
                  local.get 63
                  call $helper::number_to_string
                  local.set 52
                  i32.const 0
                  local.set 94
                  local.get 51
                  ref.as_non_null
                  local.get 52
                  ref.as_non_null
                  local.get 94
                  call $helper::string_equality
                  local.set 62
                  local.get 62
                  local.set 134
                  ref.null 131
                  local.set 52
                end
                ref.null 131
                local.set 45
                ref.null 131
                local.set 51
              end
              local.get 134
              local.set 103
            end
            local.get 103
            if ;; label = @5
              i32.const 0
              local.set 30
              i64.const 0
              local.set 31
              ref.null eq
              local.set 32
              i32.const 0
              local.set 33
              i32.const 0
              local.set 34
            else
              local.get 35
              local.get 36
              local.get 37
              call $helper::object_header_projection
              local.set 165
              local.get 165
              ref.as_non_null
              struct.get 69 0
              local.set 167
              i32.const 1
              local.set 136
              i64.const 0
              local.set 154
              ref.null eq
              local.set 128
              local.get 167
              ref.is_null
              i32.eqz
              if ;; label = @6
                i32.const 6
                local.set 136
                local.get 167
                local.set 128
                local.get 167
                ref.test (ref 107)
                if ;; label = @7
                  i32.const 8
                  local.set 136
                end
                local.get 167
                ref.test (ref 111)
                if ;; label = @7
                  i32.const 8
                  local.set 136
                end
                local.get 167
                ref.test (ref 114)
                if ;; label = @7
                  i32.const 9
                  local.set 136
                end
                local.get 167
                ref.test (ref 139)
                if ;; label = @7
                  i32.const 7
                  local.set 136
                end
              end
              ref.null 60
              local.set 167
              ref.null 69
              local.set 165
              local.get 136
              i32.const 1
              i32.eq
              if ;; label = @6
                i32.const 0
                local.set 30
                i64.const 0
                local.set 31
                ref.null eq
                local.set 32
                i32.const 0
                local.set 33
                i32.const 0
                local.set 34
              else
                local.get 136
                local.get 154
                local.get 128
                local.get 21
                local.get 22
                local.get 23
                local.get 24
                local.get 25
                local.get 26
                local.get 11
                local.get 29
                ref.as_non_null
                call $helper::object_read
                local.set 34
                local.set 33
                local.set 32
                local.set 31
                local.set 30
              end
            end
          end
          ref.null eq
          local.set 128
          ref.null 70
          local.set 113
        end
      end
    end
    ref.null eq
    local.set 40
    ref.null eq
    local.set 37
    local.get 30
    local.get 31
    local.get 32
    local.get 33
    local.get 34
    ref.null eq
    local.set 32
    ref.null 109
    local.set 28
    ref.null 120
    local.set 27
    ref.null eq
    local.set 26
    ref.null eq
    local.set 23
    ref.null eq
    local.set 20
  )
