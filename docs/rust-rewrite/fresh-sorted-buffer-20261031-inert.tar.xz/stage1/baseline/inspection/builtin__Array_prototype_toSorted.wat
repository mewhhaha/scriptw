  (func $builtin::Array.prototype.toSorted (;141;) (type 40) (param (ref 107) i32 i64 eqref i32 i64 eqref i64 (ref null 99) (ref 161) (ref 109)) (result i32 i64 eqref i32 i32)
    (local (ref null 120) (ref null 130) i32 i64 eqref i32 i32 i32 i64 eqref (ref null 107) (ref null 110) (ref null 161) (ref null 109) (ref null 109) (ref null 109) (ref null 99) (ref null 99) i64 i32 i64 eqref (ref null 120) (ref null 130) i32 i64 eqref i32 i64 eqref i32 i64 eqref i32 i64 eqref i32 i64 eqref i32 i32 i64 i64 i64 i32 i32 i32 (ref null 62) (ref null 112) (ref null 161) i64 eqref (ref null 163) i32 (ref null 131) (ref null 220) i64 eqref (ref null 139) (ref null 139) i32 i32 (ref null 161) i32 i64 eqref i32 i64 eqref (ref null 69) (ref null 97) (ref null 92) (ref null 94) (ref null 95) (ref null 39) (ref null 107) (ref null 106) (ref null 94) (ref null 94) (ref null 39) i64 i64 i64 i64 i64 i64 i64 i32 f64 (ref null 62) i32 i64 i32 i64 (ref null 94) (ref null 99) (ref null 93) (ref null 99) (ref null 62) eqref i32 i32 (ref null 131) i32 i32 i32 i32 (ref null 132) (ref null 132) (ref null 99))
    ref.null 120
    local.set 11
    ref.null 130
    local.set 12
    i32.const 0
    local.set 13
    i64.const 0
    local.set 14
    ref.null eq
    local.set 15
    i32.const 0
    local.set 16
    i32.const 0
    local.set 17
    local.get 1
    local.set 18
    local.get 2
    local.set 19
    local.get 3
    local.set 20
    local.get 0
    local.set 21
    local.get 21
    ref.as_non_null
    struct.get 107 2
    local.set 22
    local.get 9
    local.set 23
    local.get 10
    local.set 24
    local.get 24
    ref.as_non_null
    local.set 25
    ref.null 109
    local.set 24
    local.get 22
    ref.as_non_null
    struct.get 110 9
    local.set 24
    local.get 25
    ref.as_non_null
    local.set 26
    local.get 24
    ref.is_null
    i32.eqz
    if ;; label = @1
      local.get 24
      ref.as_non_null
      local.set 26
    end
    ref.null 109
    local.set 24
    ref.null 109
    local.set 25
    local.get 8
    local.set 27
    local.get 27
    ref.is_null
    if ;; label = @1
      local.get 7
      i64.eqz
      i32.eqz
      if ;; label = @2
        unreachable
      end
      array.new_fixed 99 0
      local.set 27
    else
      local.get 27
      array.len
      i64.extend_i32_u
      local.get 7
      i64.ne
      if ;; label = @2
        unreachable
      end
    end
    local.get 27
    ref.as_non_null
    local.set 28
    ref.null 99
    local.set 27
    local.get 28
    ref.as_non_null
    array.len
    i64.extend_i32_u
    local.set 29
    local.get 4
    local.set 30
    local.get 5
    local.set 31
    local.get 6
    local.set 32
    local.get 22
    ref.as_non_null
    struct.get 110 1
    local.set 33
    local.get 22
    ref.as_non_null
    struct.get 110 2
    local.set 34
    local.get 33
    local.set 11
    local.get 34
    local.set 12
    i32.const 0
    local.set 16
    i32.const 0
    local.set 13
    i64.const 0
    local.set 14
    ref.null eq
    local.set 15
    i32.const 0
    local.set 57
    local.get 57
    local.get 28
    ref.as_non_null
    array.len
    i32.lt_u
    if ;; label = @1
      local.get 28
      ref.as_non_null
      local.get 57
      array.get 99
      local.set 58
      local.get 58
      ref.as_non_null
      struct.get 62 1
      local.set 38
      local.get 58
      ref.as_non_null
      struct.get 62 0
      local.set 39
      local.get 58
      ref.as_non_null
      struct.get 62 2
      local.set 40
      ref.null 62
      local.set 58
    else
      i32.const 0
      local.set 38
      i64.const 0
      local.set 39
      ref.null eq
      local.set 40
    end
    local.get 38
    i32.const 0
    i32.ne
    if ;; label = @1
      local.get 40
      ref.test (ref 107)
      local.get 40
      ref.test (ref 111)
      i32.or
      if (result i32) ;; label = @2
        i32.const 1
      else
        local.get 40
        ref.test (ref 112)
        if (result i32) ;; label = @3
          local.get 40
          ref.cast (ref 112)
          local.set 59
          local.get 59
          ref.as_non_null
          struct.get 112 3
          local.set 57
          local.get 57
          i32.const 0
          i32.ne
          ref.null 112
          local.set 59
        else
          i32.const 0
        end
      end
      i32.eqz
      if ;; label = @2
        local.get 22
        ref.as_non_null
        struct.get 110 0
        local.set 60
        local.get 60
        ref.as_non_null
        call $helper::realm_ensure_errors
        local.get 60
        ref.as_non_null
        struct.get 161 5
        local.set 63
        i32.const 3
        local.set 64
        local.get 63
        ref.as_non_null
        local.get 64
        array.get 163
        local.set 58
        ref.null 163
        local.set 63
        local.get 58
        ref.as_non_null
        struct.get 62 1
        local.set 57
        local.get 58
        ref.as_non_null
        struct.get 62 0
        local.set 61
        local.get 58
        ref.as_non_null
        struct.get 62 2
        local.set 62
        i32.const 0
        local.get 57
        i32.const 6
        i32.eq
        i32.or
        local.get 57
        i32.const 7
        i32.eq
        i32.or
        local.get 57
        i32.const 8
        i32.eq
        i32.or
        local.get 57
        i32.const 9
        i32.eq
        i32.or
        i32.eqz
        if ;; label = @3
          unreachable
        end
        ref.null 62
        local.set 58
        i32.const 2981
        local.set 64
        local.get 64
        call $helper::pooled_string_resolve
        local.set 65
        i32.const 5
        local.get 57
        local.get 61
        local.get 62
        local.get 65
        ref.as_non_null
        call $helper::runtime_error_for_throw
        local.set 66
        i32.const 6
        local.set 64
        i64.const 0
        local.set 67
        local.get 66
        ref.as_non_null
        local.set 68
        local.get 64
        local.set 47
        local.get 67
        local.set 48
        local.get 68
        local.set 49
        i32.const 1
        local.set 50
        i32.const 0
        local.set 51
        ref.null eq
        local.set 68
        ref.null 220
        local.set 66
        ref.null 131
        local.set 65
        ref.null eq
        local.set 62
        ref.null 161
        local.set 60
        local.get 47
        local.set 13
        local.get 48
        local.set 14
        local.get 49
        local.set 15
        local.get 50
        local.set 16
        local.get 51
        local.set 17
        local.get 16
        i32.const 1
        i32.eq
        if ;; label = @3
          local.get 13
          local.get 14
          local.get 15
          local.get 16
          local.get 17
          return
        end
      end
    end
    local.get 18
    local.set 35
    local.get 19
    local.set 36
    local.get 20
    local.set 37
    global.get 8
    ref.as_non_null
    local.set 60
    local.get 60
    ref.as_non_null
    local.get 35
    local.get 36
    local.get 37
    call $helper::value_to_object
    local.set 51
    local.set 50
    local.set 49
    local.set 48
    local.set 47
    ref.null 161
    local.set 60
    local.get 47
    local.set 13
    local.get 48
    local.set 14
    local.get 49
    local.set 15
    local.get 50
    local.set 16
    local.get 51
    local.set 17
    local.get 16
    i32.const 1
    i32.eq
    if ;; label = @1
      local.get 13
      local.get 14
      local.get 15
      local.get 16
      local.get 17
      return
    end
    local.get 47
    local.set 35
    local.get 48
    local.set 36
    local.get 49
    local.set 37
    i32.const 140
    local.set 64
    local.get 64
    call $helper::pooled_string_resolve
    local.set 65
    i32.const 4
    local.set 57
    i64.const 0
    local.set 67
    local.get 65
    ref.as_non_null
    local.set 68
    ref.null 131
    local.set 65
    local.get 35
    local.get 36
    local.get 37
    local.get 35
    local.get 36
    local.get 37
    local.get 57
    local.get 67
    local.get 68
    local.get 11
    local.get 26
    ref.as_non_null
    call $helper::object_read
    local.set 51
    local.set 50
    local.set 49
    local.set 48
    local.set 47
    ref.null eq
    local.set 68
    local.get 47
    local.set 13
    local.get 48
    local.set 14
    local.get 49
    local.set 15
    local.get 50
    local.set 16
    local.get 51
    local.set 17
    local.get 16
    i32.const 1
    i32.eq
    if ;; label = @1
      local.get 13
      local.get 14
      local.get 15
      local.get 16
      local.get 17
      return
    end
    local.get 47
    local.set 64
    local.get 48
    local.set 61
    local.get 49
    local.set 62
    local.get 64
    local.get 61
    local.get 62
    local.get 11
    local.get 26
    ref.as_non_null
    call $helper::value_to_number
    local.set 51
    local.set 50
    local.set 49
    local.set 48
    local.set 47
    local.get 50
    i32.const 0
    i32.eq
    if ;; label = @1
      local.get 48
      f64.reinterpret_i64
      local.get 48
      f64.reinterpret_i64
      f64.ne
      local.get 48
      f64.reinterpret_i64
      f64.const 0x0p+0 (;=0;)
      f64.le
      i32.or
      if ;; label = @2
        i64.const 0
        local.set 52
      else
        local.get 48
        f64.reinterpret_i64
        f64.const 0x1.fffffffffffffp+52 (;=9007199254740991;)
        f64.gt
        if ;; label = @3
          i64.const 9007199254740991
          local.set 52
        else
          local.get 48
          f64.reinterpret_i64
          f64.trunc
          i64.trunc_f64_u
          local.set 52
        end
      end
    end
    ref.null eq
    local.set 62
    local.get 47
    local.set 13
    local.get 48
    local.set 14
    local.get 49
    local.set 15
    local.get 50
    local.set 16
    local.get 51
    local.set 17
    local.get 16
    i32.const 1
    i32.eq
    if ;; label = @1
      local.get 13
      local.get 14
      local.get 15
      local.get 16
      local.get 17
      return
    end
    local.get 22
    ref.as_non_null
    struct.get 110 0
    local.set 60
    local.get 60
    ref.as_non_null
    struct.get 161 5
    local.set 63
    i32.const 0
    local.set 64
    local.get 63
    ref.as_non_null
    local.get 64
    array.get 163
    local.set 58
    ref.null 163
    local.set 63
    local.get 58
    ref.as_non_null
    struct.get 62 1
    local.set 57
    local.get 58
    ref.as_non_null
    struct.get 62 0
    local.set 67
    local.get 58
    ref.as_non_null
    struct.get 62 2
    local.set 68
    i32.const 0
    local.get 57
    i32.const 6
    i32.eq
    i32.or
    local.get 57
    i32.const 7
    i32.eq
    i32.or
    local.get 57
    i32.const 8
    i32.eq
    i32.or
    local.get 57
    i32.const 9
    i32.eq
    i32.or
    i32.eqz
    if ;; label = @1
      unreachable
    end
    ref.null 62
    local.set 58
    local.get 68
    ref.cast (ref 139)
    ref.null eq
    local.set 68
    local.set 69
    i32.const 7
    local.set 64
    i64.const 0
    local.set 61
    local.get 69
    ref.as_non_null
    local.set 62
    local.get 52
    i64.const 0
    i64.lt_s
    local.get 52
    i64.const 4294967295
    i64.gt_u
    i32.or
    if ;; label = @1
      local.get 22
      ref.as_non_null
      struct.get 110 0
      local.set 73
      local.get 73
      ref.as_non_null
      call $helper::realm_ensure_errors
      local.get 73
      ref.as_non_null
      struct.get 161 5
      local.set 63
      i32.const 6
      local.set 77
      local.get 63
      ref.as_non_null
      local.get 77
      array.get 163
      local.set 58
      ref.null 163
      local.set 63
      local.get 58
      ref.as_non_null
      struct.get 62 1
      local.set 74
      local.get 58
      ref.as_non_null
      struct.get 62 0
      local.set 75
      local.get 58
      ref.as_non_null
      struct.get 62 2
      local.set 76
      i32.const 0
      local.get 74
      i32.const 6
      i32.eq
      i32.or
      local.get 74
      i32.const 7
      i32.eq
      i32.or
      local.get 74
      i32.const 8
      i32.eq
      i32.or
      local.get 74
      i32.const 9
      i32.eq
      i32.or
      i32.eqz
      if ;; label = @2
        unreachable
      end
      ref.null 62
      local.set 58
      i32.const 2157
      local.set 77
      local.get 77
      call $helper::pooled_string_resolve
      local.set 65
      i32.const 2
      local.get 74
      local.get 75
      local.get 76
      local.get 65
      ref.as_non_null
      call $helper::runtime_error_for_throw
      local.set 66
      i32.const 6
      local.set 77
      i64.const 0
      local.set 78
      local.get 66
      ref.as_non_null
      local.set 79
      local.get 77
      local.set 57
      local.get 78
      local.set 67
      local.get 79
      local.set 68
      i32.const 1
      local.set 71
      i32.const 0
      local.set 72
      ref.null eq
      local.set 79
      ref.null 220
      local.set 66
      ref.null 131
      local.set 65
      ref.null eq
      local.set 76
      ref.null 161
      local.set 73
      local.get 57
      local.set 13
      local.get 67
      local.set 14
      local.get 68
      local.set 15
      local.get 71
      local.set 16
      local.get 72
      local.set 17
      ref.null eq
      local.set 68
      local.get 13
      local.get 14
      local.get 15
      local.get 16
      local.get 17
      return
    end
    i32.const 0
    local.set 77
    local.get 64
    local.get 61
    local.get 62
    local.get 77
    call $helper::ordinary_object_allocate
    local.set 80
    global.get 26
    local.set 81
    global.get 27
    local.set 82
    global.get 28
    local.set 83
    global.get 29
    local.set 84
    local.get 80
    ref.as_non_null
    i32.const 1
    local.get 52
    i64.const 0
    local.get 81
    ref.as_non_null
    local.get 82
    ref.as_non_null
    i32.const 2
    local.get 83
    ref.as_non_null
    local.get 84
    ref.as_non_null
    ref.null 93
    struct.new 139
    ref.null 92
    local.set 82
    ref.null 95
    local.set 84
    ref.null 94
    local.set 83
    ref.null 97
    local.set 81
    ref.null 69
    local.set 80
    local.set 70
    i32.const 7
    local.set 44
    i64.const 0
    local.set 45
    local.get 70
    ref.as_non_null
    local.set 46
    ref.null 139
    local.set 70
    ref.null eq
    local.set 62
    ref.null 139
    local.set 69
    ref.null 161
    local.set 60
    block ;; label = @1
      i32.const 0
      local.set 57
      ref.null 39
      local.set 85
      local.get 38
      i32.const 8
      i32.eq
      local.get 40
      ref.test (ref 107)
      i32.and
      if ;; label = @2
        local.get 40
        ref.cast (ref 107)
        local.set 86
        local.get 86
        ref.as_non_null
        struct.get 107 1
        local.set 87
        local.get 87
        ref.as_non_null
        struct.get 106 1
        local.set 74
        local.get 74
        i32.const 0
        i32.eq
        if ;; label = @3
          local.get 87
          ref.as_non_null
          struct.get 106 10
          local.set 85
        end
        ref.null 106
        local.set 87
        ref.null 107
        local.set 86
      end
      local.get 85
      ref.is_null
      i32.eqz
      if ;; label = @2
        ref.null 94
        local.set 83
        local.get 37
        ref.test (ref 139)
        if ;; label = @3
          local.get 37
          ref.cast (ref 139)
          local.set 69
          local.get 69
          ref.as_non_null
          local.set 70
          block ;; label = @4
            local.get 69
            ref.as_non_null
            struct.get 139 2
            local.get 52
            i64.ne
            br_if 0 (;@4;)
            local.get 70
            ref.as_non_null
            struct.get 139 6
            i32.const 2
            i32.eq
            local.get 70
            ref.as_non_null
            struct.get 139 6
            i32.const 3
            i32.eq
            i32.or
            i32.eqz
            br_if 0 (;@4;)
            local.get 70
            ref.as_non_null
            struct.get 139 6
            i32.const 2
            i32.eq
            i32.eqz
            br_if 0 (;@4;)
            local.get 70
            ref.as_non_null
            struct.get 139 3
            local.get 52
            i64.ne
            br_if 0 (;@4;)
            local.get 70
            ref.as_non_null
            struct.get 139 7
            local.set 88
            local.get 52
            i32.wrap_i64
            local.set 72
            i64.const 0
            local.set 78
            local.get 78
            local.get 72
            array.new 94
            local.set 89
            local.get 89
            ref.as_non_null
            i32.const 0
            local.get 88
            ref.as_non_null
            i32.const 0
            local.get 72
            array.copy 94 94
            local.get 89
            ref.as_non_null
            local.set 83
            ref.null 94
            local.set 89
            ref.null 94
            local.set 88
          end
          ref.null 139
          local.set 70
          ref.null 139
          local.set 69
        end
        local.get 83
        ref.is_null
        i32.eqz
        if ;; label = @3
          local.get 85
          ref.as_non_null
          local.set 90
          local.get 83
          ref.as_non_null
          local.set 89
          local.get 52
          i64.const 1
          i64.gt_u
          if ;; label = @4
            i64.const 0
            local.set 95
            i32.const 3
            local.set 74
            local.get 95
            local.set 96
            ref.null eq
            local.set 79
            i32.const 3
            local.set 77
            local.get 95
            local.set 97
            ref.null eq
            local.set 76
            i32.const 0
            local.set 72
            local.get 89
            ref.as_non_null
            local.get 72
            array.get 94
            local.set 96
            block ;; label = @5
              i32.const -1
              local.set 71
              i64.const 1
              local.set 92
              block ;; label = @6
                loop ;; label = @7
                  local.get 92
                  local.get 52
                  i64.ge_u
                  if ;; label = @8
                    local.get 71
                    i32.const 1
                    i32.eq
                    if ;; label = @9
                      i64.const 0
                      local.set 91
                      local.get 52
                      i64.const 1
                      i64.sub
                      local.set 92
                      block ;; label = @10
                        loop ;; label = @11
                          local.get 91
                          local.get 92
                          i64.ge_u
                          br_if 1 (;@10;)
                          local.get 91
                          i32.wrap_i64
                          local.set 72
                          local.get 89
                          ref.as_non_null
                          local.get 72
                          array.get 94
                          local.set 95
                          local.get 92
                          i32.wrap_i64
                          local.set 72
                          local.get 89
                          ref.as_non_null
                          local.get 72
                          array.get 94
                          local.set 97
                          local.get 89
                          ref.as_non_null
                          local.get 72
                          local.get 95
                          array.set 94
                          local.get 91
                          i32.wrap_i64
                          local.set 72
                          local.get 89
                          ref.as_non_null
                          local.get 72
                          local.get 97
                          array.set 94
                          local.get 91
                          i64.const 1
                          i64.add
                          local.set 91
                          local.get 92
                          i64.const -1
                          i64.add
                          local.set 92
                          br 0 (;@11;)
                        end
                      end
                    end
                    br 3 (;@5;)
                  end
                  local.get 92
                  i32.wrap_i64
                  local.set 72
                  local.get 89
                  ref.as_non_null
                  local.get 72
                  array.get 94
                  local.set 97
                  local.get 96
                  f64.reinterpret_i64
                  local.get 97
                  f64.reinterpret_i64
                  local.get 90
                  call_ref 39
                  local.set 99
                  local.set 98
                  local.get 98
                  if ;; label = @8
                    local.get 99
                    f64.const 0x0p+0 (;=0;)
                    f64.gt
                    local.set 64
                  else
                    local.get 96
                    local.get 74
                    local.get 79
                    struct.new 62
                    local.set 58
                    local.get 97
                    local.get 77
                    local.get 76
                    struct.new 62
                    local.set 100
                    local.get 58
                    ref.as_non_null
                    local.get 100
                    ref.as_non_null
                    array.new_fixed 99 2
                    local.set 27
                    i32.const 0
                    local.set 101
                    i64.const 0
                    local.set 102
                    ref.null eq
                    local.set 62
                    global.get 8
                    ref.as_non_null
                    local.set 60
                    local.get 38
                    local.get 39
                    local.get 40
                    local.get 101
                    local.get 102
                    local.get 62
                    local.get 27
                    ref.as_non_null
                    local.get 60
                    ref.as_non_null
                    local.get 11
                    local.get 26
                    ref.as_non_null
                    call $helper::proxy_call
                    local.set 51
                    local.set 50
                    local.set 49
                    local.set 48
                    local.set 47
                    local.get 60
                    ref.as_non_null
                    global.set 8
                    ref.null 161
                    local.set 60
                    local.get 50
                    i32.const 2
                    i32.eq
                    if ;; label = @9
                      local.get 47
                      local.set 47
                      local.get 48
                      local.set 48
                      local.get 49
                      local.set 49
                      i32.const 0
                      local.set 50
                      i32.const 0
                      local.set 51
                    end
                    local.get 47
                    local.set 13
                    local.get 48
                    local.set 14
                    local.get 49
                    local.set 15
                    local.get 50
                    local.set 16
                    local.get 51
                    local.set 17
                    local.get 16
                    i32.const 1
                    i32.eq
                    if ;; label = @9
                      local.get 13
                      local.get 14
                      local.get 15
                      local.get 16
                      local.get 17
                      return
                    end
                    local.get 47
                    local.set 103
                    local.get 48
                    local.set 104
                    local.get 49
                    local.set 68
                    local.get 103
                    local.get 104
                    local.get 68
                    local.get 11
                    local.get 26
                    ref.as_non_null
                    call $helper::value_to_number
                    local.set 51
                    local.set 50
                    local.set 49
                    local.set 48
                    local.set 47
                    local.get 47
                    local.set 13
                    local.get 48
                    local.set 14
                    local.get 49
                    local.set 15
                    local.get 50
                    local.set 16
                    local.get 51
                    local.set 17
                    local.get 16
                    i32.const 1
                    i32.eq
                    if ;; label = @9
                      local.get 13
                      local.get 14
                      local.get 15
                      local.get 16
                      local.get 17
                      return
                    end
                    local.get 48
                    f64.reinterpret_i64
                    f64.const 0x0p+0 (;=0;)
                    f64.gt
                    local.set 64
                    ref.null eq
                    local.set 68
                    ref.null eq
                    local.set 62
                    ref.null 99
                    local.set 27
                    ref.null 62
                    local.set 100
                    ref.null 62
                    local.set 58
                  end
                  local.get 71
                  i32.const -1
                  i32.eq
                  if ;; label = @8
                    local.get 64
                    local.set 71
                  else
                    local.get 64
                    local.get 71
                    i32.ne
                    br_if 2 (;@6;)
                  end
                  local.get 97
                  local.set 96
                  local.get 92
                  i64.const 1
                  i64.add
                  local.set 92
                  br 0 (;@7;)
                end
              end
              local.get 52
              i32.wrap_i64
              local.set 72
              local.get 95
              local.get 72
              array.new 94
              local.set 88
              local.get 89
              ref.as_non_null
              local.set 105
              i64.const 1
              local.set 61
              block ;; label = @6
                loop ;; label = @7
                  local.get 61
                  local.get 52
                  i64.ge_u
                  br_if 1 (;@6;)
                  i64.const 0
                  local.set 75
                  block ;; label = @8
                    loop ;; label = @9
                      local.get 75
                      local.get 52
                      i64.ge_u
                      br_if 1 (;@8;)
                      local.get 75
                      local.get 61
                      i64.add
                      local.set 78
                      local.get 78
                      local.get 52
                      local.get 78
                      local.get 52
                      i64.lt_u
                      select
                      local.set 78
                      local.get 78
                      local.get 61
                      i64.add
                      local.set 67
                      local.get 67
                      local.get 52
                      local.get 67
                      local.get 52
                      i64.lt_u
                      select
                      local.set 67
                      local.get 75
                      local.set 91
                      local.get 75
                      local.set 94
                      local.get 78
                      local.set 92
                      block ;; label = @10
                        loop ;; label = @11
                          local.get 94
                          local.get 67
                          i64.ge_u
                          br_if 1 (;@10;)
                          local.get 91
                          local.get 78
                          i64.lt_u
                          local.get 92
                          local.get 67
                          i64.lt_u
                          i32.and
                          if ;; label = @12
                            local.get 91
                            i32.wrap_i64
                            local.set 72
                            local.get 89
                            ref.as_non_null
                            local.get 72
                            array.get 94
                            local.set 96
                            local.get 92
                            i32.wrap_i64
                            local.set 72
                            local.get 89
                            ref.as_non_null
                            local.get 72
                            array.get 94
                            local.set 97
                            local.get 96
                            f64.reinterpret_i64
                            local.get 97
                            f64.reinterpret_i64
                            local.get 90
                            call_ref 39
                            local.set 99
                            local.set 98
                            local.get 98
                            if ;; label = @13
                              local.get 99
                              f64.const 0x0p+0 (;=0;)
                              f64.gt
                              local.set 64
                            else
                              local.get 96
                              local.get 74
                              local.get 79
                              struct.new 62
                              local.set 58
                              local.get 97
                              local.get 77
                              local.get 76
                              struct.new 62
                              local.set 100
                              local.get 58
                              ref.as_non_null
                              local.get 100
                              ref.as_non_null
                              array.new_fixed 99 2
                              local.set 27
                              i32.const 0
                              local.set 101
                              i64.const 0
                              local.set 102
                              ref.null eq
                              local.set 62
                              global.get 8
                              ref.as_non_null
                              local.set 60
                              local.get 38
                              local.get 39
                              local.get 40
                              local.get 101
                              local.get 102
                              local.get 62
                              local.get 27
                              ref.as_non_null
                              local.get 60
                              ref.as_non_null
                              local.get 11
                              local.get 26
                              ref.as_non_null
                              call $helper::proxy_call
                              local.set 51
                              local.set 50
                              local.set 49
                              local.set 48
                              local.set 47
                              local.get 60
                              ref.as_non_null
                              global.set 8
                              ref.null 161
                              local.set 60
                              local.get 50
                              i32.const 2
                              i32.eq
                              if ;; label = @14
                                local.get 47
                                local.set 47
                                local.get 48
                                local.set 48
                                local.get 49
                                local.set 49
                                i32.const 0
                                local.set 50
                                i32.const 0
                                local.set 51
                              end
                              local.get 47
                              local.set 13
                              local.get 48
                              local.set 14
                              local.get 49
                              local.set 15
                              local.get 50
                              local.set 16
                              local.get 51
                              local.set 17
                              local.get 16
                              i32.const 1
                              i32.eq
                              if ;; label = @14
                                local.get 13
                                local.get 14
                                local.get 15
                                local.get 16
                                local.get 17
                                return
                              end
                              local.get 47
                              local.set 103
                              local.get 48
                              local.set 104
                              local.get 49
                              local.set 68
                              local.get 103
                              local.get 104
                              local.get 68
                              local.get 11
                              local.get 26
                              ref.as_non_null
                              call $helper::value_to_number
                              local.set 51
                              local.set 50
                              local.set 49
                              local.set 48
                              local.set 47
                              local.get 47
                              local.set 13
                              local.get 48
                              local.set 14
                              local.get 49
                              local.set 15
                              local.get 50
                              local.set 16
                              local.get 51
                              local.set 17
                              local.get 16
                              i32.const 1
                              i32.eq
                              if ;; label = @14
                                local.get 13
                                local.get 14
                                local.get 15
                                local.get 16
                                local.get 17
                                return
                              end
                              local.get 48
                              f64.reinterpret_i64
                              f64.const 0x0p+0 (;=0;)
                              f64.gt
                              local.set 64
                              ref.null eq
                              local.set 68
                              ref.null eq
                              local.set 62
                              ref.null 99
                              local.set 27
                              ref.null 62
                              local.set 100
                              ref.null 62
                              local.set 58
                            end
                            local.get 64
                            if ;; label = @13
                              local.get 92
                              local.set 93
                              local.get 92
                              i64.const 1
                              i64.add
                              local.set 92
                            else
                              local.get 91
                              local.set 93
                              local.get 91
                              i64.const 1
                              i64.add
                              local.set 91
                            end
                          else
                            local.get 91
                            local.get 78
                            i64.lt_u
                            if ;; label = @13
                              local.get 91
                              local.set 93
                              local.get 91
                              i64.const 1
                              i64.add
                              local.set 91
                            else
                              local.get 92
                              local.set 93
                              local.get 92
                              i64.const 1
                              i64.add
                              local.set 92
                            end
                          end
                          local.get 93
                          i32.wrap_i64
                          local.set 72
                          local.get 89
                          ref.as_non_null
                          local.get 72
                          array.get 94
                          local.set 95
                          local.get 94
                          i32.wrap_i64
                          local.set 72
                          local.get 88
                          ref.as_non_null
                          local.get 72
                          local.get 95
                          array.set 94
                          local.get 94
                          i64.const 1
                          i64.add
                          local.set 94
                          br 0 (;@11;)
                        end
                      end
                      local.get 67
                      local.set 75
                      br 0 (;@9;)
                    end
                  end
                  local.get 89
                  ref.as_non_null
                  local.set 105
                  local.get 88
                  ref.as_non_null
                  local.set 89
                  local.get 105
                  ref.as_non_null
                  local.set 88
                  local.get 61
                  i64.const 2
                  i64.mul
                  local.set 61
                  br 0 (;@7;)
                end
              end
              ref.null 94
              local.set 105
              ref.null 94
              local.set 88
            end
            ref.null eq
            local.set 76
            ref.null eq
            local.set 79
          end
          ref.null 39
          local.set 90
          block ;; label = @4
            local.get 46
            ref.cast (ref 139)
            local.set 70
            i64.const 0
            local.set 104
            i32.const 3
            local.set 71
            local.get 104
            local.set 102
            ref.null eq
            local.set 68
            block ;; label = @5
              loop ;; label = @6
                local.get 104
                local.get 52
                i64.ge_u
                br_if 1 (;@5;)
                local.get 104
                i32.wrap_i64
                local.set 64
                local.get 89
                ref.as_non_null
                local.get 64
                array.get 94
                local.set 102
                local.get 70
                ref.as_non_null
                local.get 104
                local.get 71
                local.get 102
                local.get 68
                call $helper::array_indexed_publish_default_data
                local.get 104
                i64.const 1
                i64.add
                local.set 104
                br 0 (;@6;)
              end
            end
            ref.null eq
            local.set 68
            ref.null 139
            local.set 70
          end
          i32.const 1
          local.set 57
          ref.null 94
          local.set 89
        end
        ref.null 94
        local.set 83
      end
      ref.null 39
      local.set 85
      local.get 57
      br_if 0 (;@1;)
      ref.null 99
      local.set 27
      local.get 37
      ref.test (ref 139)
      if ;; label = @2
        local.get 37
        ref.cast (ref 139)
        local.set 69
        local.get 69
        ref.as_non_null
        local.set 70
        block ;; label = @3
          local.get 69
          ref.as_non_null
          struct.get 139 2
          local.get 52
          i64.ne
          br_if 0 (;@3;)
          local.get 70
          ref.as_non_null
          struct.get 139 6
          i32.const 2
          i32.eq
          local.get 70
          ref.as_non_null
          struct.get 139 6
          i32.const 3
          i32.eq
          i32.or
          i32.eqz
          br_if 0 (;@3;)
          local.get 70
          ref.as_non_null
          struct.get 139 3
          local.get 52
          i64.ne
          br_if 0 (;@3;)
          local.get 52
          i32.wrap_i64
          local.set 72
          global.get 30
          local.set 100
          local.get 100
          ref.as_non_null
          local.get 72
          array.new 99
          local.set 106
          ref.null 62
          local.set 100
          i32.const 0
          local.set 103
          local.get 70
          ref.as_non_null
          struct.get 139 6
          i32.const 3
          i32.eq
          if ;; label = @4
            local.get 70
            ref.as_non_null
            struct.get 139 9
            ref.as_non_null
            local.set 107
            block ;; label = @5
              loop ;; label = @6
                local.get 103
                local.get 72
                i32.ge_u
                br_if 1 (;@5;)
                local.get 107
                ref.as_non_null
                local.get 103
                array.get 93
                ref.as_non_null
                local.set 100
                local.get 106
                ref.as_non_null
                local.get 103
                local.get 100
                ref.as_non_null
                array.set 99
                ref.null 62
                local.set 100
                local.get 103
                i32.const 1
                i32.add
                local.set 103
                br 0 (;@6;)
              end
            end
            ref.null 93
            local.set 107
          else
            local.get 70
            ref.as_non_null
            struct.get 139 7
            local.set 89
            block ;; label = @5
              loop ;; label = @6
                local.get 103
                local.get 72
                i32.ge_u
                br_if 1 (;@5;)
                local.get 89
                ref.as_non_null
                local.get 103
                array.get 94
                local.set 75
                i32.const 3
                local.set 64
                local.get 75
                local.set 75
                ref.null eq
                local.set 62
                local.get 75
                local.get 64
                local.get 62
                struct.new 62
                local.set 100
                local.get 106
                ref.as_non_null
                local.get 103
                local.get 100
                ref.as_non_null
                array.set 99
                ref.null 62
                local.set 100
                local.get 103
                i32.const 1
                i32.add
                local.set 103
                br 0 (;@6;)
              end
            end
            ref.null eq
            local.set 62
            ref.null 94
            local.set 89
          end
          local.get 106
          ref.as_non_null
          local.set 27
          ref.null 99
          local.set 106
        end
        ref.null 139
        local.set 70
        ref.null 139
        local.set 69
      end
      local.get 27
      ref.is_null
      if ;; label = @2
        global.get 22
        local.set 106
        i32.const 0
        local.set 71
        i64.const 0
        local.set 53
        i64.const 0
        local.set 54
        block ;; label = @3
          loop ;; label = @4
            local.get 53
            local.get 52
            i64.ge_u
            br_if 1 (;@3;)
            i32.const 1
            local.set 56
            local.get 56
            if ;; label = @5
              local.get 35
              local.get 36
              local.get 37
              local.get 53
              local.get 11
              local.get 26
              ref.as_non_null
              call $helper::indexed_element_read
              local.set 51
              local.set 50
              local.set 49
              local.set 48
              local.set 47
              local.get 47
              local.set 13
              local.get 48
              local.set 14
              local.get 49
              local.set 15
              local.get 50
              local.set 16
              local.get 51
              local.set 17
              local.get 16
              i32.const 1
              i32.eq
              if ;; label = @6
                local.get 13
                local.get 14
                local.get 15
                local.get 16
                local.get 17
                return
              end
              local.get 47
              local.set 41
              local.get 48
              local.set 42
              local.get 49
              local.set 43
              local.get 42
              local.get 41
              local.get 43
              struct.new 62
              local.set 58
              local.get 106
              ref.as_non_null
              local.get 71
              local.get 58
              ref.as_non_null
              call $helper::argument_list_append
              local.set 106
              local.get 71
              i32.const 1
              i32.add
              local.set 71
              ref.null 62
              local.set 58
              local.get 54
              i64.const 1
              i64.add
              local.set 54
            end
            local.get 53
            i64.const 1
            i64.add
            local.set 53
            br 0 (;@4;)
          end
        end
        local.get 106
        ref.as_non_null
        array.len
        local.set 101
        local.get 71
        local.get 101
        i32.ne
        if ;; label = @3
          i32.const 0
          local.set 57
          local.get 106
          ref.as_non_null
          local.get 57
          array.get 99
          local.set 58
          local.get 58
          ref.as_non_null
          local.get 71
          array.new 99
          local.set 108
          local.get 108
          ref.as_non_null
          i32.const 0
          local.get 106
          ref.as_non_null
          i32.const 0
          local.get 71
          array.copy 99 99
          local.get 108
          ref.as_non_null
          local.set 106
          ref.null 99
          local.set 108
          ref.null 62
          local.set 58
        end
        local.get 106
        ref.as_non_null
        local.set 27
        ref.null 99
        local.set 106
      else
        local.get 52
        local.set 54
      end
      local.get 27
      ref.as_non_null
      local.set 108
      ref.null 99
      local.set 27
      local.get 54
      i64.const 1
      i64.gt_u
      if ;; label = @2
        i32.const 0
        local.set 72
        local.get 108
        ref.as_non_null
        local.get 72
        array.get 99
        local.set 58
        local.get 58
        ref.as_non_null
        local.set 100
        local.get 58
        ref.as_non_null
        local.set 109
        block ;; label = @3
          i64.const 1
          local.set 95
          block ;; label = @4
            loop ;; label = @5
              local.get 95
              local.get 54
              i64.ge_u
              br_if 2 (;@3;)
              local.get 95
              i32.wrap_i64
              local.set 72
              local.get 108
              ref.as_non_null
              local.get 72
              array.get 99
              local.set 58
              local.get 58
              ref.as_non_null
              local.set 109
              local.get 100
              ref.as_non_null
              struct.get 62 1
              local.set 101
              local.get 100
              ref.as_non_null
              struct.get 62 0
              local.set 78
              local.get 100
              ref.as_non_null
              struct.get 62 2
              local.set 68
              local.get 109
              ref.as_non_null
              struct.get 62 1
              local.set 57
              local.get 109
              ref.as_non_null
              struct.get 62 0
              local.set 67
              local.get 109
              ref.as_non_null
              struct.get 62 2
              local.set 76
              i32.const 0
              local.set 77
              i64.const 0
              local.set 92
              ref.null eq
              local.set 79
              local.get 101
              i32.const 0
              i32.eq
              if ;; label = @6
                local.get 57
                i32.const 0
                i32.ne
                local.set 103
              else
                local.get 57
                i32.const 0
                i32.eq
                if ;; label = @7
                  i32.const 0
                  local.set 103
                else
                  local.get 38
                  i32.const 0
                  i32.ne
                  if ;; label = @8
                    i32.const 0
                    local.set 111
                    local.get 38
                    i32.const 8
                    i32.eq
                    local.get 40
                    ref.test (ref 107)
                    i32.and
                    local.get 101
                    i32.const 3
                    i32.eq
                    i32.and
                    local.get 57
                    i32.const 3
                    i32.eq
                    i32.and
                    if ;; label = @9
                      local.get 40
                      ref.cast (ref 107)
                      local.set 86
                      local.get 86
                      ref.as_non_null
                      struct.get 107 1
                      local.set 87
                      local.get 87
                      ref.as_non_null
                      struct.get 106 1
                      local.set 112
                      local.get 112
                      i32.const 0
                      i32.eq
                      if ;; label = @10
                        local.get 87
                        ref.as_non_null
                        struct.get 106 10
                        local.set 90
                        local.get 90
                        ref.is_null
                        i32.eqz
                        if ;; label = @11
                          local.get 90
                          ref.as_non_null
                          local.set 85
                          local.get 78
                          f64.reinterpret_i64
                          local.get 67
                          f64.reinterpret_i64
                          local.get 85
                          call_ref 39
                          local.set 99
                          local.set 111
                          ref.null 39
                          local.set 85
                        end
                        ref.null 39
                        local.set 90
                      end
                      ref.null 106
                      local.set 87
                      ref.null 107
                      local.set 86
                    end
                    local.get 111
                    if ;; label = @9
                      local.get 99
                      f64.const 0x0p+0 (;=0;)
                      f64.gt
                      local.set 103
                    else
                      local.get 100
                      ref.as_non_null
                      local.get 109
                      ref.as_non_null
                      array.new_fixed 99 2
                      local.set 106
                      global.get 8
                      ref.as_non_null
                      local.set 73
                      local.get 38
                      local.get 39
                      local.get 40
                      local.get 77
                      local.get 92
                      local.get 79
                      local.get 106
                      ref.as_non_null
                      local.get 73
                      ref.as_non_null
                      local.get 11
                      local.get 26
                      ref.as_non_null
                      call $helper::proxy_call
                      local.set 64
                      local.set 74
                      local.set 62
                      local.set 93
                      local.set 71
                      local.get 73
                      ref.as_non_null
                      global.set 8
                      ref.null 161
                      local.set 73
                      local.get 74
                      i32.const 2
                      i32.eq
                      if ;; label = @10
                        local.get 71
                        local.set 71
                        local.get 93
                        local.set 93
                        local.get 62
                        local.set 62
                        i32.const 0
                        local.set 74
                        i32.const 0
                        local.set 64
                      end
                      ref.null 99
                      local.set 106
                      local.get 71
                      local.set 13
                      local.get 93
                      local.set 14
                      local.get 62
                      local.set 15
                      local.get 74
                      local.set 16
                      local.get 64
                      local.set 17
                      local.get 16
                      i32.const 1
                      i32.eq
                      if ;; label = @10
                        local.get 13
                        local.get 14
                        local.get 15
                        local.get 16
                        local.get 17
                        return
                      end
                      local.get 71
                      local.set 98
                      local.get 93
                      local.set 91
                      local.get 62
                      local.set 110
                      local.get 98
                      local.get 91
                      local.get 110
                      local.get 11
                      local.get 26
                      ref.as_non_null
                      call $helper::value_to_number
                      local.set 51
                      local.set 50
                      local.set 49
                      local.set 48
                      local.set 47
                      local.get 47
                      local.set 13
                      local.get 48
                      local.set 14
                      local.get 49
                      local.set 15
                      local.get 50
                      local.set 16
                      local.get 51
                      local.set 17
                      local.get 16
                      i32.const 1
                      i32.eq
                      if ;; label = @10
                        local.get 13
                        local.get 14
                        local.get 15
                        local.get 16
                        local.get 17
                        return
                      end
                      local.get 48
                      f64.reinterpret_i64
                      f64.const 0x0p+0 (;=0;)
                      f64.gt
                      local.set 103
                    end
                  else
                    local.get 101
                    local.get 78
                    local.get 68
                    local.get 11
                    local.get 26
                    ref.as_non_null
                    call $helper::value_to_string
                    local.set 64
                    local.set 74
                    local.set 62
                    local.set 93
                    local.set 71
                    local.get 71
                    local.set 13
                    local.get 93
                    local.set 14
                    local.get 62
                    local.set 15
                    local.get 74
                    local.set 16
                    local.get 64
                    local.set 17
                    local.get 16
                    i32.const 1
                    i32.eq
                    if ;; label = @9
                      local.get 13
                      local.get 14
                      local.get 15
                      local.get 16
                      local.get 17
                      return
                    end
                    local.get 62
                    ref.cast (ref 131)
                    local.set 65
                    local.get 57
                    local.get 67
                    local.get 76
                    local.get 11
                    local.get 26
                    ref.as_non_null
                    call $helper::value_to_string
                    local.set 64
                    local.set 74
                    local.set 62
                    local.set 93
                    local.set 71
                    local.get 71
                    local.set 13
                    local.get 93
                    local.set 14
                    local.get 62
                    local.set 15
                    local.get 74
                    local.set 16
                    local.get 64
                    local.set 17
                    local.get 16
                    i32.const 1
                    i32.eq
                    if ;; label = @9
                      local.get 13
                      local.get 14
                      local.get 15
                      local.get 16
                      local.get 17
                      return
                    end
                    local.get 62
                    ref.cast (ref 131)
                    local.set 113
                    local.get 65
                    ref.as_non_null
                    struct.get 131 0
                    local.set 118
                    local.get 113
                    ref.as_non_null
                    struct.get 131 0
                    local.set 119
                    local.get 118
                    ref.as_non_null
                    array.len
                    local.set 111
                    local.get 119
                    ref.as_non_null
                    array.len
                    local.set 114
                    i32.const 0
                    local.set 112
                    i32.const 0
                    local.set 117
                    block ;; label = @9
                      loop ;; label = @10
                        local.get 112
                        local.get 111
                        i32.ge_u
                        local.get 112
                        local.get 114
                        i32.ge_u
                        i32.or
                        br_if 1 (;@9;)
                        local.get 118
                        ref.as_non_null
                        local.get 112
                        array.get_u 132
                        local.set 115
                        local.get 119
                        ref.as_non_null
                        local.get 112
                        array.get_u 132
                        local.set 116
                        local.get 115
                        local.get 116
                        i32.ne
                        if ;; label = @11
                          local.get 115
                          local.get 116
                          i32.lt_u
                          if (result i32) ;; label = @12
                            i32.const -1
                          else
                            i32.const 1
                          end
                          local.set 117
                        end
                        local.get 117
                        br_if 1 (;@9;)
                        local.get 112
                        i32.const 1
                        i32.add
                        local.set 112
                        br 0 (;@10;)
                      end
                    end
                    local.get 117
                    i32.eqz
                    if ;; label = @9
                      local.get 111
                      local.get 114
                      i32.lt_u
                      if (result i32) ;; label = @10
                        i32.const -1
                      else
                        local.get 111
                        local.get 114
                        i32.gt_u
                        if (result i32) ;; label = @11
                          i32.const 1
                        else
                          i32.const 0
                        end
                      end
                      local.set 117
                    end
                    local.get 117
                    ref.null 132
                    local.set 119
                    ref.null 132
                    local.set 118
                    i32.const 0
                    i32.gt_s
                    local.set 103
                    ref.null 131
                    local.set 113
                    ref.null 131
                    local.set 65
                  end
                end
              end
              ref.null eq
              local.set 110
              ref.null eq
              local.set 79
              ref.null eq
              local.set 62
              ref.null eq
              local.set 76
              ref.null eq
              local.set 68
              local.get 103
              br_if 1 (;@4;)
              local.get 109
              ref.as_non_null
              local.set 100
              local.get 95
              i64.const 1
              i64.add
              local.set 95
              br 0 (;@5;)
            end
          end
          local.get 54
          i32.wrap_i64
          local.set 72
          local.get 58
          ref.as_non_null
          local.get 72
          array.new 99
          local.set 27
          local.get 108
          ref.as_non_null
          local.set 106
          i64.const 1
          local.set 102
          block ;; label = @4
            loop ;; label = @5
              local.get 102
              local.get 54
              i64.ge_u
              br_if 1 (;@4;)
              i64.const 0
              local.set 61
              block ;; label = @6
                loop ;; label = @7
                  local.get 61
                  local.get 54
                  i64.ge_u
                  br_if 1 (;@6;)
                  local.get 61
                  local.get 102
                  i64.add
                  local.set 104
                  local.get 104
                  local.get 54
                  local.get 104
                  local.get 54
                  i64.lt_u
                  select
                  local.set 104
                  local.get 104
                  local.get 102
                  i64.add
                  local.set 97
                  local.get 97
                  local.get 54
                  local.get 97
                  local.get 54
                  i64.lt_u
                  select
                  local.set 97
                  local.get 61
                  local.set 96
                  local.get 104
                  local.set 95
                  local.get 61
                  local.set 75
                  block ;; label = @8
                    loop ;; label = @9
                      local.get 75
                      local.get 97
                      i64.ge_u
                      br_if 1 (;@8;)
                      local.get 96
                      local.get 104
                      i64.lt_u
                      local.get 95
                      local.get 97
                      i64.lt_u
                      i32.and
                      if ;; label = @10
                        local.get 96
                        i32.wrap_i64
                        local.set 72
                        local.get 108
                        ref.as_non_null
                        local.get 72
                        array.get 99
                        local.set 58
                        local.get 58
                        ref.as_non_null
                        local.set 100
                        local.get 95
                        i32.wrap_i64
                        local.set 72
                        local.get 108
                        ref.as_non_null
                        local.get 72
                        array.get 99
                        local.set 58
                        local.get 58
                        ref.as_non_null
                        local.set 109
                        local.get 100
                        ref.as_non_null
                        struct.get 62 1
                        local.set 101
                        local.get 100
                        ref.as_non_null
                        struct.get 62 0
                        local.set 78
                        local.get 100
                        ref.as_non_null
                        struct.get 62 2
                        local.set 68
                        local.get 109
                        ref.as_non_null
                        struct.get 62 1
                        local.set 57
                        local.get 109
                        ref.as_non_null
                        struct.get 62 0
                        local.set 67
                        local.get 109
                        ref.as_non_null
                        struct.get 62 2
                        local.set 76
                        i32.const 0
                        local.set 74
                        i64.const 0
                        local.set 92
                        ref.null eq
                        local.set 79
                        local.get 101
                        i32.const 0
                        i32.eq
                        if ;; label = @11
                          local.get 57
                          i32.const 0
                          i32.ne
                          local.set 103
                        else
                          local.get 57
                          i32.const 0
                          i32.eq
                          if ;; label = @12
                            i32.const 0
                            local.set 103
                          else
                            local.get 38
                            i32.const 0
                            i32.ne
                            if ;; label = @13
                              i32.const 0
                              local.set 112
                              local.get 38
                              i32.const 8
                              i32.eq
                              local.get 40
                              ref.test (ref 107)
                              i32.and
                              local.get 101
                              i32.const 3
                              i32.eq
                              i32.and
                              local.get 57
                              i32.const 3
                              i32.eq
                              i32.and
                              if ;; label = @14
                                local.get 40
                                ref.cast (ref 107)
                                local.set 86
                                local.get 86
                                ref.as_non_null
                                struct.get 107 1
                                local.set 87
                                local.get 87
                                ref.as_non_null
                                struct.get 106 1
                                local.set 114
                                local.get 114
                                i32.const 0
                                i32.eq
                                if ;; label = @15
                                  local.get 87
                                  ref.as_non_null
                                  struct.get 106 10
                                  local.set 85
                                  local.get 85
                                  ref.is_null
                                  i32.eqz
                                  if ;; label = @16
                                    local.get 85
                                    ref.as_non_null
                                    local.set 90
                                    local.get 78
                                    f64.reinterpret_i64
                                    local.get 67
                                    f64.reinterpret_i64
                                    local.get 90
                                    call_ref 39
                                    local.set 99
                                    local.set 112
                                    ref.null 39
                                    local.set 90
                                  end
                                  ref.null 39
                                  local.set 85
                                end
                                ref.null 106
                                local.set 87
                                ref.null 107
                                local.set 86
                              end
                              local.get 112
                              if ;; label = @14
                                local.get 99
                                f64.const 0x0p+0 (;=0;)
                                f64.gt
                                local.set 103
                              else
                                local.get 100
                                ref.as_non_null
                                local.get 109
                                ref.as_non_null
                                array.new_fixed 99 2
                                local.set 120
                                global.get 8
                                ref.as_non_null
                                local.set 60
                                local.get 38
                                local.get 39
                                local.get 40
                                local.get 74
                                local.get 92
                                local.get 79
                                local.get 120
                                ref.as_non_null
                                local.get 60
                                ref.as_non_null
                                local.get 11
                                local.get 26
                                ref.as_non_null
                                call $helper::proxy_call
                                local.set 77
                                local.set 64
                                local.set 62
                                local.set 93
                                local.set 71
                                local.get 60
                                ref.as_non_null
                                global.set 8
                                ref.null 161
                                local.set 60
                                local.get 64
                                i32.const 2
                                i32.eq
                                if ;; label = @15
                                  local.get 71
                                  local.set 71
                                  local.get 93
                                  local.set 93
                                  local.get 62
                                  local.set 62
                                  i32.const 0
                                  local.set 64
                                  i32.const 0
                                  local.set 77
                                end
                                ref.null 99
                                local.set 120
                                local.get 71
                                local.set 13
                                local.get 93
                                local.set 14
                                local.get 62
                                local.set 15
                                local.get 64
                                local.set 16
                                local.get 77
                                local.set 17
                                local.get 16
                                i32.const 1
                                i32.eq
                                if ;; label = @15
                                  local.get 13
                                  local.get 14
                                  local.get 15
                                  local.get 16
                                  local.get 17
                                  return
                                end
                                local.get 71
                                local.set 98
                                local.get 93
                                local.set 91
                                local.get 62
                                local.set 110
                                local.get 98
                                local.get 91
                                local.get 110
                                local.get 11
                                local.get 26
                                ref.as_non_null
                                call $helper::value_to_number
                                local.set 51
                                local.set 50
                                local.set 49
                                local.set 48
                                local.set 47
                                local.get 47
                                local.set 13
                                local.get 48
                                local.set 14
                                local.get 49
                                local.set 15
                                local.get 50
                                local.set 16
                                local.get 51
                                local.set 17
                                local.get 16
                                i32.const 1
                                i32.eq
                                if ;; label = @15
                                  local.get 13
                                  local.get 14
                                  local.get 15
                                  local.get 16
                                  local.get 17
                                  return
                                end
                                local.get 48
                                f64.reinterpret_i64
                                f64.const 0x0p+0 (;=0;)
                                f64.gt
                                local.set 103
                              end
                            else
                              local.get 101
                              local.get 78
                              local.get 68
                              local.get 11
                              local.get 26
                              ref.as_non_null
                              call $helper::value_to_string
                              local.set 77
                              local.set 64
                              local.set 62
                              local.set 93
                              local.set 71
                              local.get 71
                              local.set 13
                              local.get 93
                              local.set 14
                              local.get 62
                              local.set 15
                              local.get 64
                              local.set 16
                              local.get 77
                              local.set 17
                              local.get 16
                              i32.const 1
                              i32.eq
                              if ;; label = @14
                                local.get 13
                                local.get 14
                                local.get 15
                                local.get 16
                                local.get 17
                                return
                              end
                              local.get 62
                              ref.cast (ref 131)
                              local.set 113
                              local.get 57
                              local.get 67
                              local.get 76
                              local.get 11
                              local.get 26
                              ref.as_non_null
                              call $helper::value_to_string
                              local.set 77
                              local.set 64
                              local.set 62
                              local.set 93
                              local.set 71
                              local.get 71
                              local.set 13
                              local.get 93
                              local.set 14
                              local.get 62
                              local.set 15
                              local.get 64
                              local.set 16
                              local.get 77
                              local.set 17
                              local.get 16
                              i32.const 1
                              i32.eq
                              if ;; label = @14
                                local.get 13
                                local.get 14
                                local.get 15
                                local.get 16
                                local.get 17
                                return
                              end
                              local.get 62
                              ref.cast (ref 131)
                              local.set 65
                              local.get 113
                              ref.as_non_null
                              struct.get 131 0
                              local.set 118
                              local.get 65
                              ref.as_non_null
                              struct.get 131 0
                              local.set 119
                              local.get 118
                              ref.as_non_null
                              array.len
                              local.set 111
                              local.get 119
                              ref.as_non_null
                              array.len
                              local.set 115
                              i32.const 0
                              local.set 116
                              i32.const 0
                              local.set 112
                              block ;; label = @14
                                loop ;; label = @15
                                  local.get 116
                                  local.get 111
                                  i32.ge_u
                                  local.get 116
                                  local.get 115
                                  i32.ge_u
                                  i32.or
                                  br_if 1 (;@14;)
                                  local.get 118
                                  ref.as_non_null
                                  local.get 116
                                  array.get_u 132
                                  local.set 117
                                  local.get 119
                                  ref.as_non_null
                                  local.get 116
                                  array.get_u 132
                                  local.set 114
                                  local.get 117
                                  local.get 114
                                  i32.ne
                                  if ;; label = @16
                                    local.get 117
                                    local.get 114
                                    i32.lt_u
                                    if (result i32) ;; label = @17
                                      i32.const -1
                                    else
                                      i32.const 1
                                    end
                                    local.set 112
                                  end
                                  local.get 112
                                  br_if 1 (;@14;)
                                  local.get 116
                                  i32.const 1
                                  i32.add
                                  local.set 116
                                  br 0 (;@15;)
                                end
                              end
                              local.get 112
                              i32.eqz
                              if ;; label = @14
                                local.get 111
                                local.get 115
                                i32.lt_u
                                if (result i32) ;; label = @15
                                  i32.const -1
                                else
                                  local.get 111
                                  local.get 115
                                  i32.gt_u
                                  if (result i32) ;; label = @16
                                    i32.const 1
                                  else
                                    i32.const 0
                                  end
                                end
                                local.set 112
                              end
                              local.get 112
                              ref.null 132
                              local.set 119
                              ref.null 132
                              local.set 118
                              i32.const 0
                              i32.gt_s
                              local.set 103
                              ref.null 131
                              local.set 65
                              ref.null 131
                              local.set 113
                            end
                          end
                        end
                        ref.null eq
                        local.set 110
                        ref.null eq
                        local.set 79
                        ref.null eq
                        local.set 62
                        ref.null eq
                        local.set 76
                        ref.null eq
                        local.set 68
                        local.get 103
                        if ;; label = @11
                          local.get 95
                          local.set 94
                          local.get 95
                          i64.const 1
                          i64.add
                          local.set 95
                        else
                          local.get 96
                          local.set 94
                          local.get 96
                          i64.const 1
                          i64.add
                          local.set 96
                        end
                      else
                        local.get 96
                        local.get 104
                        i64.lt_u
                        if ;; label = @11
                          local.get 96
                          local.set 94
                          local.get 96
                          i64.const 1
                          i64.add
                          local.set 96
                        else
                          local.get 95
                          local.set 94
                          local.get 95
                          i64.const 1
                          i64.add
                          local.set 95
                        end
                      end
                      local.get 94
                      i32.wrap_i64
                      local.set 72
                      local.get 108
                      ref.as_non_null
                      local.get 72
                      array.get 99
                      local.set 58
                      local.get 75
                      i32.wrap_i64
                      local.set 72
                      local.get 27
                      ref.as_non_null
                      local.get 72
                      local.get 58
                      ref.as_non_null
                      array.set 99
                      local.get 75
                      i64.const 1
                      i64.add
                      local.set 75
                      br 0 (;@9;)
                    end
                  end
                  local.get 97
                  local.set 61
                  br 0 (;@7;)
                end
              end
              local.get 108
              ref.as_non_null
              local.set 106
              local.get 27
              ref.as_non_null
              local.set 108
              local.get 106
              ref.as_non_null
              local.set 27
              local.get 102
              i64.const 2
              i64.mul
              local.set 102
              br 0 (;@5;)
            end
          end
          ref.null 99
          local.set 106
          ref.null 99
          local.set 27
        end
        ref.null 62
        local.set 58
        ref.null 62
        local.set 109
        ref.null 62
        local.set 100
      end
      block ;; label = @2
        local.get 46
        ref.cast (ref 139)
        local.set 69
        i64.const 0
        local.set 53
        block ;; label = @3
          loop ;; label = @4
            local.get 53
            local.get 54
            i64.ge_u
            br_if 1 (;@3;)
            local.get 53
            i32.wrap_i64
            local.set 55
            local.get 55
            local.get 108
            ref.as_non_null
            array.len
            i32.lt_u
            if ;; label = @5
              local.get 108
              ref.as_non_null
              local.get 55
              array.get 99
              local.set 58
              local.get 58
              ref.as_non_null
              struct.get 62 1
              local.set 41
              local.get 58
              ref.as_non_null
              struct.get 62 0
              local.set 42
              local.get 58
              ref.as_non_null
              struct.get 62 2
              local.set 43
              ref.null 62
              local.set 58
            else
              i32.const 0
              local.set 41
              i64.const 0
              local.set 42
              ref.null eq
              local.set 43
            end
            local.get 69
            ref.as_non_null
            local.get 53
            local.get 41
            local.get 42
            local.get 43
            call $helper::array_indexed_publish_default_data
            local.get 53
            i64.const 1
            i64.add
            local.set 53
            br 0 (;@4;)
          end
        end
        ref.null 139
        local.set 69
      end
      ref.null 99
      local.set 108
    end
    local.get 44
    local.set 13
    local.get 45
    local.set 14
    local.get 46
    local.set 15
    i32.const 0
    local.set 16
    i32.const 0
    local.set 17
    ref.null eq
    local.set 49
    ref.null eq
    local.set 46
    ref.null eq
    local.set 43
    ref.null eq
    local.set 40
    ref.null eq
    local.set 37
    local.get 13
    local.get 14
    local.get 15
    local.get 16
    local.get 17
    ref.null 130
    local.set 34
    ref.null 120
    local.set 33
    ref.null 99
    local.set 28
    ref.null eq
    local.set 32
    ref.null eq
    local.set 20
    ref.null 161
    local.set 23
    ref.null 110
    local.set 22
    ref.null 107
    local.set 21
    ref.null 109
    local.set 26
    ref.null 130
    local.set 12
    ref.null 120
    local.set 11
  )
