  (func $helper::array_indexed_publish_default_data (;1008;) (type 293) (param (ref 139) i64 i32 i64 eqref)
    (local (ref null 120) (ref null 130) i32 i64 eqref i32 i32 (ref null 139) i32 i64 eqref (ref null 139) i32 (ref null 94) (ref null 95) i32 i64 i32 (ref null 94) i32 (ref null 95) i64 i64 (ref null 93) i32 i32 eqref (ref null 94) (ref null 95) i32 i32 i64 i64 (ref null 62) (ref null 93) (ref null 62) (ref null 70))
    ref.null 120
    local.set 5
    ref.null 130
    local.set 6
    i32.const 0
    local.set 7
    i64.const 0
    local.set 8
    ref.null eq
    local.set 9
    i32.const 0
    local.set 10
    i32.const 0
    local.set 11
    local.get 0
    local.set 12
    local.get 2
    local.set 13
    local.get 3
    local.set 14
    local.get 4
    local.set 15
    local.get 12
    ref.as_non_null
    local.set 16
    i32.const 0
    local.set 17
    local.get 16
    ref.as_non_null
    struct.get 139 6
    i32.const 2
    i32.eq
    local.get 13
    i32.const 3
    i32.eq
    i32.and
    if ;; label = @1
      local.get 16
      ref.as_non_null
      struct.get 139 7
      local.set 18
      local.get 16
      ref.as_non_null
      struct.get 139 8
      local.set 19
      local.get 18
      ref.as_non_null
      array.len
      local.set 20
      local.get 16
      ref.as_non_null
      struct.get 139 3
      local.set 21
      local.get 1
      local.get 20
      i64.extend_i32_u
      i64.lt_u
      local.get 1
      i64.const 1048576
      i64.lt_u
      local.get 1
      local.get 21
      i64.const 2
      i64.mul
      i64.const 8
      i64.add
      i64.le_u
      i32.and
      i32.or
      if ;; label = @2
        local.get 1
        local.get 20
        i64.extend_i32_u
        i64.ge_u
        if ;; label = @3
          local.get 20
          local.set 22
          local.get 22
          i32.eqz
          if ;; label = @4
            i32.const 4
            local.set 22
          end
          block ;; label = @4
            loop ;; label = @5
              local.get 1
              local.get 22
              i64.extend_i32_u
              i64.lt_u
              br_if 1 (;@4;)
              local.get 22
              i32.const 1
              i32.shl
              local.set 22
              br 0 (;@5;)
            end
          end
          i64.const 0
          local.get 22
          array.new 94
          local.set 23
          local.get 23
          ref.as_non_null
          i32.const 0
          local.get 18
          ref.as_non_null
          i32.const 0
          local.get 20
          array.copy 94 94
          local.get 22
          i32.const 63
          i32.add
          i32.const 6
          i32.shr_u
          local.set 24
          i64.const 0
          local.get 24
          array.new 95
          local.set 25
          local.get 19
          ref.as_non_null
          array.len
          local.set 24
          local.get 25
          ref.as_non_null
          i32.const 0
          local.get 19
          ref.as_non_null
          i32.const 0
          local.get 24
          array.copy 95 95
          local.get 16
          ref.as_non_null
          local.get 23
          ref.as_non_null
          struct.set 139 7
          local.get 16
          ref.as_non_null
          local.get 25
          ref.as_non_null
          struct.set 139 8
          local.get 23
          ref.as_non_null
          local.set 18
          local.get 25
          ref.as_non_null
          local.set 19
          ref.null 95
          local.set 25
          ref.null 94
          local.set 23
        end
        local.get 1
        i32.wrap_i64
        local.set 24
        local.get 24
        i32.const 6
        i32.shr_u
        local.set 22
        i64.const 1
        local.get 24
        i64.extend_i32_u
        i64.shl
        local.set 26
        local.get 19
        ref.as_non_null
        local.get 22
        array.get 95
        local.set 27
        local.get 27
        local.get 26
        i64.and
        i64.eqz
        if ;; label = @3
          local.get 21
          i64.const 1
          i64.add
          local.set 21
          local.get 16
          ref.as_non_null
          local.get 21
          struct.set 139 3
        end
        local.get 18
        ref.as_non_null
        local.get 24
        local.get 14
        array.set 94
        local.get 27
        local.get 26
        i64.or
        local.set 27
        local.get 19
        ref.as_non_null
        local.get 22
        local.get 27
        array.set 95
        i32.const 1
        local.set 17
      end
      ref.null 95
      local.set 19
      ref.null 94
      local.set 18
    end
    local.get 17
    i32.eqz
    if ;; label = @1
      local.get 16
      ref.as_non_null
      struct.get 139 6
      i32.const 2
      i32.eq
      local.get 13
      i32.const 3
      i32.ne
      i32.and
      if ;; label = @2
        local.get 16
        ref.as_non_null
        struct.get 139 7
        local.set 23
        local.get 16
        ref.as_non_null
        struct.get 139 8
        local.set 25
        local.get 23
        ref.as_non_null
        array.len
        local.set 22
        local.get 16
        ref.as_non_null
        struct.get 139 3
        local.set 27
        local.get 1
        local.get 22
        i64.extend_i32_u
        i64.lt_u
        local.get 1
        i64.const 1048576
        i64.lt_u
        local.get 1
        local.get 27
        i64.const 2
        i64.mul
        i64.const 8
        i64.add
        i64.le_u
        i32.and
        i32.or
        if ;; label = @3
          local.get 16
          ref.as_non_null
          struct.get 139 7
          local.set 18
          local.get 16
          ref.as_non_null
          struct.get 139 8
          local.set 19
          local.get 18
          ref.as_non_null
          array.len
          local.set 20
          ref.null 62
          local.get 20
          array.new 93
          local.set 28
          i32.const 0
          local.set 24
          block ;; label = @4
            loop ;; label = @5
              local.get 24
              local.get 20
              i32.ge_u
              br_if 1 (;@4;)
              local.get 24
              i64.extend_i32_u
              local.set 26
              i32.const 0
              local.set 29
              local.get 16
              ref.as_non_null
              struct.get 139 7
              local.set 32
              local.get 16
              ref.as_non_null
              struct.get 139 8
              local.set 33
              local.get 26
              local.get 32
              ref.as_non_null
              array.len
              i64.extend_i32_u
              i64.lt_u
              if ;; label = @6
                local.get 26
                i32.wrap_i64
                local.set 34
                local.get 34
                i32.const 6
                i32.shr_u
                local.set 35
                i64.const 1
                local.get 34
                i64.extend_i32_u
                i64.shl
                local.set 36
                local.get 33
                ref.as_non_null
                local.get 35
                array.get 95
                local.set 37
                local.get 37
                local.get 36
                i64.and
                i64.eqz
                i32.eqz
                if ;; label = @7
                  local.get 32
                  ref.as_non_null
                  local.get 34
                  array.get 94
                  local.set 37
                  i32.const 3
                  local.set 30
                  local.get 37
                  local.set 21
                  ref.null eq
                  local.set 31
                  i32.const 1
                  local.set 29
                end
              end
              ref.null 95
              local.set 33
              ref.null 94
              local.set 32
              local.get 29
              if ;; label = @6
                local.get 21
                local.get 30
                local.get 31
                struct.new 62
                local.set 38
                local.get 28
                ref.as_non_null
                local.get 24
                local.get 38
                ref.as_non_null
                array.set 93
                ref.null 62
                local.set 38
              end
              local.get 24
              i32.const 1
              i32.add
              local.set 24
              br 0 (;@5;)
            end
          end
          global.get 28
          local.set 32
          global.get 29
          local.set 33
          local.get 16
          ref.as_non_null
          local.get 32
          ref.as_non_null
          struct.set 139 7
          local.get 16
          ref.as_non_null
          local.get 33
          ref.as_non_null
          struct.set 139 8
          local.get 16
          ref.as_non_null
          ref.null 93
          struct.set 139 9
          ref.null 95
          local.set 33
          ref.null 94
          local.set 32
          local.get 16
          ref.as_non_null
          local.get 28
          ref.as_non_null
          struct.set 139 9
          local.get 16
          ref.as_non_null
          i32.const 3
          struct.set 139 6
          ref.null eq
          local.set 31
          ref.null 93
          local.set 28
          ref.null 95
          local.set 19
          ref.null 94
          local.set 18
        end
        ref.null 95
        local.set 25
        ref.null 94
        local.set 23
      end
      local.get 16
      ref.as_non_null
      struct.get 139 6
      i32.const 3
      i32.eq
      if ;; label = @2
        local.get 16
        ref.as_non_null
        struct.get 139 9
        ref.as_non_null
        local.set 28
        local.get 28
        ref.as_non_null
        array.len
        local.set 35
        local.get 16
        ref.as_non_null
        struct.get 139 3
        local.set 37
        local.get 1
        local.get 35
        i64.extend_i32_u
        i64.lt_u
        local.get 1
        i64.const 1048576
        i64.lt_u
        local.get 1
        local.get 37
        i64.const 2
        i64.mul
        i64.const 8
        i64.add
        i64.le_u
        i32.and
        i32.or
        if ;; label = @3
          local.get 1
          local.get 35
          i64.extend_i32_u
          i64.ge_u
          if ;; label = @4
            local.get 35
            local.set 22
            local.get 22
            i32.eqz
            if ;; label = @5
              i32.const 4
              local.set 22
            end
            block ;; label = @5
              loop ;; label = @6
                local.get 1
                local.get 22
                i64.extend_i32_u
                i64.lt_u
                br_if 1 (;@5;)
                local.get 22
                i32.const 1
                i32.shl
                local.set 22
                br 0 (;@6;)
              end
            end
            ref.null 62
            local.get 22
            array.new 93
            local.set 39
            local.get 39
            ref.as_non_null
            i32.const 0
            local.get 28
            ref.as_non_null
            i32.const 0
            local.get 35
            array.copy 93 93
            local.get 16
            ref.as_non_null
            local.get 39
            ref.as_non_null
            struct.set 139 9
            local.get 39
            ref.as_non_null
            local.set 28
            ref.null 93
            local.set 39
          end
          local.get 1
          i32.wrap_i64
          local.set 34
          local.get 14
          local.get 13
          local.get 15
          struct.new 62
          local.set 38
          local.get 28
          ref.as_non_null
          local.get 34
          array.get 93
          local.set 40
          local.get 40
          ref.is_null
          if ;; label = @4
            local.get 37
            i64.const 1
            i64.add
            local.set 37
            local.get 16
            ref.as_non_null
            local.get 37
            struct.set 139 3
          end
          local.get 28
          ref.as_non_null
          local.get 34
          local.get 38
          ref.as_non_null
          array.set 93
          i32.const 1
          local.set 17
          ref.null 62
          local.set 40
          ref.null 62
          local.set 38
        end
        ref.null 93
        local.set 28
      end
    end
    ref.null 139
    local.set 16
    local.get 17
    i32.eqz
    if ;; label = @1
      i32.const 0
      local.set 22
      i64.const 0
      local.set 27
      ref.null eq
      local.set 31
      local.get 14
      local.get 13
      local.get 15
      struct.new 62
      local.set 40
      global.get 30
      local.set 38
      i32.const 14
      local.get 40
      ref.as_non_null
      local.get 38
      ref.as_non_null
      local.get 38
      ref.as_non_null
      struct.new 70
      local.set 41
      ref.null 62
      local.set 38
      ref.null 62
      local.set 40
      local.get 12
      ref.as_non_null
      local.set 16
      local.get 16
      ref.as_non_null
      local.get 1
      local.get 41
      ref.as_non_null
      call $helper::array_indexed_publish
      ref.null 139
      local.set 16
      ref.null 70
      local.set 41
      ref.null eq
      local.set 31
    end
    ref.null eq
    local.set 15
    ref.null 139
    local.set 12
  )
