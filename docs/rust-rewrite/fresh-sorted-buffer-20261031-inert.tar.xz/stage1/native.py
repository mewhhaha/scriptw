"""Run the Cargo-selected release binaries serially, retaining raw receipts."""
import argparse
import json
import re
import subprocess
from pathlib import Path
from measure import OUT, ROOT, save, digest
from native_test_protocol import parse_inventory

parser=argparse.ArgumentParser()
parser.add_argument('action',choices=['focused','broad'])
args=parser.parse_args()
artifacts={}
for line in (OUT/'native-build.jsonl').read_text().splitlines():
    row=json.loads(line)
    if row.get('reason')=='compiler-artifact' and row.get('executable') and row['profile']['test']:
        artifacts[row['target']['name']]=row
targets=[
    ('emission','packed_array_storage::real_array_sort_snapshots_packed_values_and_revalidates_after_all_comparisons'),
    ('aot_gc_entries','aot_gc_packed_array_storage::graph_snapshot_fresh_numeric_to_sorted_keeps_exact_capacity_occupancy_and_bits'),
    ('aot_builtins','aot_array_private_buffers::unboxed_numeric_sort_keeps_stable_bits_and_complete_generic_fallbacks'),
]
if args.action=='broad':
    targets=[(name,None) for name in ['scriptw_aot_wasm','scriptw_engine','emission','aot_builtins','aot_gc_entries','scriptw_cli']]
folder=OUT/('native-'+args.action)
folder.mkdir()
receipt=[]
for name,selection in targets:
    row=artifacts[name]
    executable=Path(row['executable'])
    identity=digest(executable)
    argv=[str(executable),'--test-threads=1']
    if selection: argv+=['--exact',selection,'--nocapture']
    listed=subprocess.check_output([str(executable),'--list'],text=True,cwd=ROOT)
    (folder/(name+'.inventory')).write_text(listed)
    tests=parse_inventory(listed)
    assert tests and (selection is None or selection in tests), (name,selection)
    print(name,selection or 'complete default target',flush=True)
    with (folder/(name+'.stdout')).open('w') as stdout,(folder/(name+'.stderr')).open('w') as stderr:
        result=subprocess.run(argv,cwd=ROOT,stdout=stdout,stderr=stderr,timeout=3600)
    text=(folder/(name+'.stdout')).read_text()
    summaries=re.findall(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;.*?(\d+) filtered out;',text)
    assert digest(executable)==identity
    entry=dict(target=name,argv=argv,executable_sha256=identity,producer=row,
        exit_code=result.returncode,summaries=summaries,selected_test=selection)
    receipt.append(entry)
    save(folder/(name+'.receipt.json'),entry)
    assert result.returncode==0 and len(summaries)==1 and int(summaries[0][1])>0, name
save(folder/'receipt.json',receipt)
