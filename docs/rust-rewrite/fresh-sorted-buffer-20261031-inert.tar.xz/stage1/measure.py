"""Local source-bound diagnostic using the existing checked benchmark hosts."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import shutil
import statistics
import subprocess
import sys

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
from benchmark_metrics import digest, measure_process
from limited_verification import kernel_group, require_kernel_budget
from compiler_comparison import ADAPTER

CANONICAL = ROOT / 'crates/scriptw-cli/tests/fixtures/v8_execution_hotpaths'
SAMPLES, WARMUPS = 21, 10


def save(path, value):
    with Path(path).open('x') as stream:
        stream.write(json.dumps(value, indent=2) + '\n')


def load(path):
    return json.loads(Path(path).read_text())


def invoke(stem, argv, *, allow_failure=False):
    print(stem, flush=True)
    raw = OUT / 'raw'
    raw.mkdir(exist_ok=True)
    group = kernel_group()
    fields = ['memory.max', 'memory.swap.max', 'memory.oom.group', 'cpu.max', 'memory.events']
    before = {key: (group / key).read_text() for key in fields}
    env = dict(os.environ, NODE_DISABLE_COMPILE_CACHE='1')
    assert not env.get('NODE_OPTIONS')
    env.pop('NODE_COMPILE_CACHE', None)
    with (raw / (stem + '.stdout')).open('xb') as stdout, (raw / (stem + '.stderr')).open('xb') as stderr:
        result = measure_process(list(map(str, argv)), cwd=ROOT, env=env,
            stdout=stdout, stderr=stderr, timeout=900, time_binary=OUT / 'tools/time')
    after = {key: (group / key).read_text() for key in fields}
    result.update(argv=list(map(str, argv)), resources_before=before, resources_after=after,
        affinity=sorted(os.sched_getaffinity(0)))
    save(raw / (stem + '.command.json'), result)
    assert all(before[key] == after[key] for key in fields if key != 'memory.events'), 'resource policy changed'
    before_events = dict(line.split() for line in before['memory.events'].splitlines())
    after_events = dict(line.split() for line in after['memory.events'].splitlines())
    assert all(before_events[key] == after_events[key] for key in ['oom','oom_kill','oom_group_kill']), 'OOM event; original receipt preserved'
    if not allow_failure:
        assert result['exit_code'] == 0 and not result['timed_out'], stem
    return result


def freeze(label):
    destination = OUT / label
    destination.mkdir()
    products = {}
    for name, source in [('scriptw', ROOT / 'target/release/scriptw'),
        ('runtime_baseline', ROOT / 'target/release/examples/runtime_baseline'),
        ('compiler_precompiled_baseline', ROOT / 'target/release/examples/compiler_precompiled_baseline')]:
        path = destination / name
        shutil.copy2(source, path)
        assert path.stat().st_nlink == 1 and not path.is_symlink()
        products[name] = dict(sha256=digest(path), bytes=path.stat().st_size)
    if label == 'candidate':
        path = destination / 'wasi_baseline'
        shutil.copy2(ROOT / 'target/release/examples/wasi_baseline', path)
        products['wasi_baseline'] = dict(sha256=digest(path), bytes=path.stat().st_size)
    invoke(label + '-identity', [destination / 'compiler_precompiled_baseline', 'identity'])
    identity = load(OUT / 'raw' / (label + '-identity.stdout'))
    assert identity['executable_sha256'] == products['compiler_precompiled_baseline']['sha256']
    save(destination / 'identity.json', identity)
    save(destination / 'products.json', products)
    native = destination / 'runtime-build'
    native.mkdir()
    outputs = list((ROOT / 'target/release/build').glob('scriptw-runtime-image-*/out/scriptw-runtime-portable-native.bin'))
    assert len(outputs) == 1, outputs
    for path in outputs[0].parent.glob('scriptw-runtime*.bin'):
        shutil.copyfile(path, native / path.name)
    patch = subprocess.check_output(['git', 'diff', '--binary'], cwd=ROOT)
    (destination / 'source.patch').write_bytes(patch)
    save(destination / 'source.json', dict(head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
        patch_sha256=hashlib.sha256(patch).hexdigest(), fingerprint=identity['source_fingerprint']))


def sources():
    root = OUT / 'sources'
    root.mkdir()
    plan = load(CANONICAL / 'manifest.json')
    for case in [*plan['execution'], plan['startup']]:
        shutil.copyfile(CANONICAL / case['file'], root / case['file'])
    retained = OUT / 'retained-sources'
    shutil.copytree(root, retained)
    save(retained / 'manifest.json', plan)
    plan['execution'].append(dict(plan['startup'], work='unchanged startup control'))
    for size, generic in [(0,False),(1,False),(65,False),(513,False),(4096,False),(65,True),(513,True)]:
        name = f'to-sorted-{size}-' + ('generic' if generic else 'numeric') + '.js'
        callback = 'function(a,b){comparisons++;return a-b;}' if generic else 'function(a,b){return a-b;}'
        source = '(function(){var s=0,comparisons=0;for(var r=0;r<16;r++){var a=[];' + \
            f'for(var i={size};i>0;i--)a.push(i);var b=a.toSorted({callback});' + \
            's+=b.length;for(var i=0;i<b.length;i++)s+=(i+1)*b[i];}print(s);})();\n'
        (root / name).write_text(source)
        plan['execution'].append(dict(file=name, stdout=str(16*(size+size*(size+1)*(2*size+1)//6))+'\n',
            work=f'diagnostic16x fresh toSorted size{size};generic comparator={generic}'))
    save(root / 'manifest.json', plan)
    save(OUT / 'source-hashes.json', {p.name: digest(p) for p in root.iterdir()})
    expected = OUT / 'expected'
    expected.mkdir()
    for case in plan['execution']:
        (expected / case['file']).write_text(case['stdout'])


def verify_product(label):
    products = load(OUT / label / 'products.json')
    for name, row in products.items():
        assert digest(OUT / label / name) == row['sha256']
    return load(OUT / label / 'identity.json')


def prepare(label):
    identity = verify_product(label)
    host = OUT / label / 'compiler_precompiled_baseline'
    for command, source, directory in [('prepare-scriptw','sources','original'),('prepare-retained','retained-sources','retained')]:
        stem = label + '-' + command
        invoke(stem, [host, command, OUT/source, OUT/label/directory])
        report = load(OUT/'raw'/(stem+'.stdout'))
        assert report['source_fingerprint'] == identity['source_fingerprint']


def summary():
    identities = {label: verify_product(label) for label in ['baseline','candidate']}
    expected = {case['file']: case['stdout'] for case in load(OUT/'sources/manifest.json')['execution']}
    rows = []
    for path in sorted((OUT/'raw').glob('g*-r*-*.stdout')):
        parts = path.name.removesuffix('.stdout').split('-',4)
        group, round_name, label, boundary, name = parts
        report = load(path)
        identity = identities[label]
        assert report['source_fingerprint'] == identity['source_fingerprint']
        if boundary == 'ordinary':
            observations = report['cases'][0]['observations']
            values = [row['execution_ns'] for row in observations if not row['warmup']]
        else:
            observations = report['observations']
            key = 'call_ns' if boundary == 'retained' else 'execution'
            values = [(row[key] if boundary == 'retained' else row['phases_ns'][key]) for row in observations if not row['warmup']]
        assert len(values) == SAMPLES
        assert all(row['stdout'] == expected[name] for row in observations)
        rows.append(dict(group=group, round=round_name, product=label, boundary=boundary,
            file=name, median=statistics.median(values), mean=statistics.mean(values), samples=values, raw=path.name))
    pairs = []
    for boundary, name in sorted({(r['boundary'],r['file']) for r in rows}):
        entry = dict(boundary=boundary,file=name,groups=[])
        for group in ['g0','g1','pooled']:
            products = {}
            for label in ['baseline','candidate']:
                selected = [r for r in rows if r['boundary']==boundary and r['file']==name and r['product']==label and (group=='pooled' or r['group']==group)]
                values = [value for row in selected for value in row['samples']]
                products[label] = dict(count=len(values),median=statistics.median(values),mean=statistics.mean(values))
            entry['groups'].append(dict(group=group,products=products,change_percent={key:100*(products['candidate'][key]/products['baseline'][key]-1) for key in ['median','mean']}))
        pairs.append(entry)
    save(OUT/'analysis.json',dict(rows=rows,comparisons=pairs,samples=SAMPLES,warmups=WARMUPS,
        orders=[['baseline','candidate','candidate','baseline'],['candidate','baseline','baseline','candidate']]))


def run():
    canonical = load(OUT/'retained-sources/manifest.json')['execution']
    cases = load(OUT/'sources/manifest.json')['execution']
    save(OUT/'measurement-plan.json',dict(samples=SAMPLES,warmups=WARMUPS,
        orders=[['baseline','candidate','candidate','baseline'],['candidate','baseline','baseline','candidate']],
        cache_root=os.environ.get('SCRIPTW_CACHE_DIR'),cache_filesystem=subprocess.check_output(['stat','-f','-c','%T',os.environ['SCRIPTW_CACHE_DIR']],text=True).strip(),resource_policy={'memory_bytes':4096*1024*1024,'swap_bytes':0,'affinity':sorted(os.sched_getaffinity(0)),'module_cache_entries':os.environ['SCRIPTW_MODULE_MEMORY_CACHE_ENTRIES'],'module_cache_bytes':os.environ['SCRIPTW_MODULE_MEMORY_CACHE_LIMIT_BYTES']},cases=cases,retained_cases=canonical,gate='Target toSorted median must improve in both balanced groups; reject controls with >=3% median AND mean slowdown in both groups. All samples retained; no significance or universal parity claim.'))
    for group,order in enumerate([['baseline','candidate','candidate','baseline'],['candidate','baseline','baseline','candidate']]):
        for round_index,label in enumerate(order):
            verify_product(label)
            folder=OUT/f'g{group}-r{round_index}-{label}-ordinary-artifacts'
            folder.mkdir()
            for case in (cases if round_index%2==0 else list(reversed(cases))):
                name=case['file']
                for boundary in ['original','ordinary',*(['retained'] if case in canonical else [])]:
                    stem=f'g{group}-r{round_index}-{label}-{boundary}-{name}'
                    if boundary=='ordinary':
                        argv=[OUT/label/'runtime_baseline',OUT/'sources',str(SAMPLES),str(WARMUPS),name,folder]
                    else:
                        suffix='.retained.swpc' if boundary=='retained' else '.swpc'
                        argv=[OUT/label/'compiler_precompiled_baseline','execute-'+('retained' if boundary=='retained' else 'scriptw'),OUT/label/boundary/(name+suffix),case['stdout'],str(SAMPLES),str(WARMUPS)]
                    invoke(stem,argv)
    summary()


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('action',choices=['freeze','sources','prepare','run','summary'])
    parser.add_argument('label',nargs='?')
    args=parser.parse_args()
    require_kernel_budget(4096*1024*1024)
    if args.action=='freeze': freeze(args.label)
    elif args.action=='sources': sources()
    elif args.action=='prepare': prepare(args.label)
    elif args.action=='run': run()
    else: summary()
