  (func $js-numeric::#f1 (;118;) (type 39) (param f64 f64) (result i32 f64)
    global.get 4
    i32.const 128
    i32.lt_u
    if ;; label = @1
      i32.const 1
      local.get 0
      local.get 1
      f64.sub
      return
    end
    i32.const 0
    f64.const 0x0p+0 (;=0;)
  )
