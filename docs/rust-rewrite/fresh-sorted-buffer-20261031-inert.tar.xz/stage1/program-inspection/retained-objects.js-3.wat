  (func $js::workload#f0$exact_helper_context$0 (;117;) (type 40) (param (ref 107) i32 i64 eqref i32 i64 eqref i64 (ref null 99) (ref 161) (ref 109)) (result i32 i64 eqref i32 i32)
    (local (ref null 120) (ref null 130) i32 i64 eqref i32 i32 i32 i64 eqref (ref null 107) (ref null 110) (ref null 161) (ref null 109) (ref null 109) (ref null 109) (ref null 99) (ref null 99) i64 i32 i64 eqref (ref null 120) (ref null 130) i32 i32 i64 eqref i32 i32 (ref null 161) i32 i64 eqref (ref null 163) i32 (ref null 62) (ref null 131) (ref null 220) i64 eqref (ref null 107) (ref null 107) (ref null 69) (ref null 108) (ref null 69) (ref null 108) (ref null 69) (ref null 62) (ref null 108) (ref null 107) (ref null 106) i32 (ref null 62) (ref null 70) (ref null 70) (ref null 74) (ref null 70) (ref null 74) (ref null 62) (ref null 61) (ref null 62) i64 eqref i32 i64 eqref (ref null 114) i32 i64 eqref i32 (ref null 92) (ref null 129) (ref null 129) (ref null 120) i32 i64 eqref i32 i32 i64 eqref i64 i32 i64 eqref i32 i64 eqref (ref null 138) eqref i64 i64 eqref (ref null 120) (ref null 120) (ref null 139) i32 i64 eqref i32 i32 i32 i64 eqref i32 i64 eqref (ref null 97) (ref null 94) (ref null 95) eqref i32 i32 i32 i64 i32 i64 eqref i32 i64 eqref i32 i32 i32 i64 eqref (ref null 82) (ref null 82) (ref null 82) (ref null 81) (ref null 81) (ref null 80) (ref null 131) (ref null 83) (ref null 80) (ref null 76) (ref null 77) (ref null 134) i64 eqref (ref null 69) i64 i64 (ref null 139) (ref null 110) (ref null 161) (ref null 132) i32 i32 i32 i32 eqref (ref null 93) i32 i32 i64 i64 (ref null 87) (ref null 89) i32 i32 (ref null 89) (ref null 89) (ref null 88) (ref null 88) i32 (ref null 87) (ref null 87) (ref null 79) (ref null 80) (ref null 78) (ref null 84) (ref null 85) (ref null 86) (ref null 85) (ref null 86))
    ref.null 120
    local.set 11
    ref.null 130
    local.set 12
    i32.const 0
    local.set 13
    i64.const 0
    local.set 14
    ref.null eq
    local.set 15
    i32.const 0
    local.set 16
    i32.const 0
    local.set 17
    local.get 1
    local.set 18
    local.get 2
    local.set 19
    local.get 3
    local.set 20
    local.get 0
    local.set 21
    local.get 21
    ref.as_non_null
    struct.get 107 2
    local.set 22
    local.get 9
    local.set 23
    local.get 10
    local.set 24
    local.get 24
    ref.as_non_null
    local.set 25
    ref.null 109
    local.set 24
    local.get 22
    ref.as_non_null
    struct.get 110 9
    local.set 24
    local.get 25
    ref.as_non_null
    local.set 26
    local.get 24
    ref.is_null
    i32.eqz
    if ;; label = @1
      local.get 24
      ref.as_non_null
      local.set 26
    end
    ref.null 109
    local.set 24
    ref.null 109
    local.set 25
    local.get 8
    local.set 27
    local.get 27
    ref.is_null
    if ;; label = @1
      local.get 7
      i64.eqz
      i32.eqz
      if ;; label = @2
        unreachable
      end
      array.new_fixed 99 0
      local.set 27
    else
      local.get 27
      array.len
      i64.extend_i32_u
      local.get 7
      i64.ne
      if ;; label = @2
        unreachable
      end
    end
    local.get 27
    ref.as_non_null
    local.set 28
    ref.null 99
    local.set 27
    local.get 28
    ref.as_non_null
    array.len
    i64.extend_i32_u
    local.set 29
    local.get 4
    local.set 30
    local.get 5
    local.set 31
    local.get 6
    local.set 32
    local.get 22
    ref.as_non_null
    struct.get 110 1
    local.set 33
    local.get 22
    ref.as_non_null
    struct.get 110 2
    local.set 34
    local.get 33
    local.set 11
    local.get 34
    local.set 12
    global.get 4
    local.set 35
    local.get 35
    i32.const 128
    i32.ge_u
    if ;; label = @1
      local.get 22
      ref.as_non_null
      struct.get 110 0
      local.set 41
      local.get 41
      ref.as_non_null
      call 100
      local.get 41
      ref.as_non_null
      struct.get 161 5
      local.set 45
      i32.const 6
      local.set 46
      local.get 45
      ref.as_non_null
      local.get 46
      array.get 163
      local.set 47
      ref.null 163
      local.set 45
      local.get 47
      ref.as_non_null
      struct.get 62 1
      local.set 42
      local.get 47
      ref.as_non_null
      struct.get 62 0
      local.set 43
      local.get 47
      ref.as_non_null
      struct.get 62 2
      local.set 44
      i32.const 0
      local.get 42
      i32.const 6
      i32.eq
      i32.or
      local.get 42
      i32.const 7
      i32.eq
      i32.or
      local.get 42
      i32.const 8
      i32.eq
      i32.or
      local.get 42
      i32.const 9
      i32.eq
      i32.or
      i32.eqz
      if ;; label = @2
        unreachable
      end
      ref.null 62
      local.set 47
      i32.const 1783
      local.set 46
      local.get 46
      call 108
      local.set 48
      i32.const 2
      local.get 42
      local.get 43
      local.get 44
      local.get 48
      ref.as_non_null
      call 107
      local.set 49
      i32.const 6
      local.set 46
      i64.const 0
      local.set 50
      local.get 49
      ref.as_non_null
      local.set 51
      local.get 46
      local.set 36
      local.get 50
      local.set 37
      local.get 51
      local.set 38
      i32.const 1
      local.set 39
      i32.const 0
      local.set 40
      ref.null eq
      local.set 51
      ref.null 220
      local.set 49
      ref.null 131
      local.set 48
      ref.null eq
      local.set 44
      ref.null 161
      local.set 41
      i32.const 1
      local.set 39
      local.get 36
      local.get 37
      local.get 38
      local.get 39
      local.get 40
      ref.null eq
      local.set 38
      return
    end
    local.get 35
    i32.const 1
    i32.add
    global.set 4
    local.get 21
    ref.as_non_null
    local.set 52
    global.get 3
    local.set 53
    local.get 52
    ref.as_non_null
    struct.get 107 0
    local.set 54
    local.get 52
    ref.as_non_null
    struct.get 107 13
    local.set 55
    i32.const 120
    local.set 46
    local.get 46
    call 108
    local.set 48
    i32.const 4
    local.set 36
    i64.const 0
    local.set 50
    local.get 48
    ref.as_non_null
    local.set 51
    ref.null 131
    local.set 48
    local.get 54
    ref.as_non_null
    local.set 56
    ref.null 62
    local.set 47
    local.get 55
    ref.is_null
    i32.eqz
    if ;; label = @1
      local.get 55
      ref.as_non_null
      local.set 57
      local.get 57
      ref.as_non_null
      struct.get 108 1
      local.set 47
      ref.null 108
      local.set 57
    end
    local.get 52
    ref.as_non_null
    struct.get 107 14
    local.set 57
    i32.const 119
    local.set 40
    local.get 40
    call 108
    local.set 48
    i32.const 4
    local.set 39
    i64.const 0
    local.set 37
    local.get 48
    ref.as_non_null
    local.set 38
    ref.null 131
    local.set 48
    local.get 54
    ref.as_non_null
    local.set 58
    ref.null 62
    local.set 59
    local.get 57
    ref.is_null
    i32.eqz
    if ;; label = @1
      local.get 57
      ref.as_non_null
      local.set 60
      local.get 60
      ref.as_non_null
      struct.get 108 1
      local.set 59
      ref.null 108
      local.set 60
    end
    ref.null 69
    local.set 54
    i32.const 1
    local.set 40
    i64.const 0
    local.set 43
    ref.null eq
    local.set 44
    local.get 53
    ref.is_null
    i32.eqz
    if ;; label = @1
      local.get 53
      ref.as_non_null
      local.set 61
      local.get 61
      ref.as_non_null
      struct.get 107 5
      local.set 42
      local.get 61
      ref.as_non_null
      struct.get 107 1
      local.set 62
      local.get 62
      ref.as_non_null
      struct.get 106 4
      local.set 46
      local.get 62
      ref.as_non_null
      struct.get 106 1
      local.set 63
      local.get 42
      i32.eqz
      local.get 46
      i32.const 1
      i32.eq
      i32.and
      local.get 63
      i32.const 0
      i32.eq
      i32.and
      ref.null 106
      local.set 62
      if ;; label = @2
        i32.const 8
        local.set 40
        i64.const 0
        local.set 43
        local.get 61
        ref.as_non_null
        local.set 44
      end
      ref.null 107
      local.set 61
    end
    local.get 43
    local.get 40
    local.get 44
    struct.new 62
    local.set 64
    local.get 55
    ref.is_null
    i32.eqz
    if ;; label = @1
      local.get 55
      ref.as_non_null
      local.set 60
      local.get 60
      ref.as_non_null
      struct.get 108 0
      local.set 65
      local.get 65
      ref.is_null
      i32.eqz
      if ;; label = @2
        local.get 65
        ref.as_non_null
        local.set 66
        local.get 56
        ref.as_non_null
        local.get 36
        local.get 50
        local.get 51
        call 93
        local.set 67
        ref.null 70
        local.set 68
        local.get 67
        ref.is_null
        i32.eqz
        if ;; label = @3
          local.get 67
          ref.as_non_null
          local.set 69
          local.get 69
          ref.as_non_null
          struct.get 74 1
          local.set 68
          ref.null 74
          local.set 69
        end
        ref.null 74
        local.set 67
        local.get 60
        ref.as_non_null
        struct.get 108 1
        local.set 70
        local.get 66
        ref.as_non_null
        struct.get 70 1
        local.set 71
        local.get 68
        local.get 65
        ref.eq
        local.get 66
        ref.as_non_null
        struct.get 70 0
        local.set 63
        local.get 63
        i32.const 1
        i32.and
        i32.eqz
        i32.and
        local.get 63
        i32.const 6
        i32.and
        i32.eqz
        i32.eqz
        i32.and
        local.get 71
        ref.as_non_null
        local.get 70
        ref.eq
        i32.and
        ref.null 61
        local.set 71
        if ;; label = @3
          local.get 64
          ref.as_non_null
          local.set 72
          local.get 66
          ref.as_non_null
          local.get 72
          ref.as_non_null
          struct.set 70 1
          local.get 60
          ref.as_non_null
          local.get 72
          ref.as_non_null
          struct.set 108 1
          ref.null 62
          local.set 72
        else
          local.get 60
          ref.as_non_null
          ref.null 70
          struct.set 108 0
          local.get 60
          ref.as_non_null
          ref.null 62
          struct.set 108 1
        end
        ref.null 62
        local.set 70
        ref.null 70
        local.set 68
        ref.null 70
        local.set 66
      end
      ref.null 70
      local.set 65
      ref.null 108
      local.set 60
    end
    ref.null 62
    local.set 64
    ref.null eq
    local.set 44
    local.get 52
    ref.as_non_null
    global.set 3
    ref.null 107
    local.set 52
    block ;; label = @1
      i32.const 0
      local.set 46
      i64.const 0
      local.set 43
      ref.null eq
      local.set 44
      i32.const 0
      local.set 42
      i32.const 8
      local.set 40
      i64.const 0
      local.set 73
      local.get 21
      ref.as_non_null
      local.set 74
      local.get 40
      local.set 46
      local.get 73
      local.set 43
      local.get 74
      local.set 44
      i32.const 1
      local.set 42
      ref.null eq
      local.set 74
      i32.const 0
      local.set 63
      i64.const 0
      local.set 73
      ref.null eq
      local.set 74
      i32.const 0
      local.set 40
      local.get 21
      ref.as_non_null
      local.set 61
      local.get 28
      ref.as_non_null
      local.set 27
      local.get 22
      ref.as_non_null
      struct.get 110 0
      local.set 41
      local.get 41
      ref.as_non_null
      struct.get 161 5
      local.set 45
      i32.const 21
      local.set 82
      local.get 45
      ref.as_non_null
      local.get 82
      array.get 163
      local.set 70
      ref.null 163
      local.set 45
      local.get 70
      ref.as_non_null
      struct.get 62 1
      local.set 79
      local.get 70
      ref.as_non_null
      struct.get 62 0
      local.set 80
      local.get 70
      ref.as_non_null
      struct.get 62 2
      local.set 81
      i32.const 0
      local.get 79
      i32.const 6
      i32.eq
      i32.or
      local.get 79
      i32.const 7
      i32.eq
      i32.or
      local.get 79
      i32.const 8
      i32.eq
      i32.or
      local.get 79
      i32.const 9
      i32.eq
      i32.or
      i32.eqz
      if ;; label = @2
        unreachable
      end
      ref.null 62
      local.set 70
      i32.const 0
      local.set 82
      local.get 79
      local.get 80
      local.get 81
      local.get 82
      call 96
      local.set 54
      local.get 27
      ref.as_non_null
      array.len
      local.set 82
      ref.null 70
      local.get 82
      array.new 92
      local.set 83
      ref.null 129
      local.set 84
      ref.null 124
      local.get 82
      array.new 129
      local.set 85
      local.get 11
      local.set 86
      ref.null 120
      local.set 86
      local.get 85
      ref.as_non_null
      local.set 84
      ref.null 129
      local.set 85
      i32.const 0
      local.set 87
      i64.const 0
      local.set 88
      ref.null eq
      local.set 89
      local.get 88
      local.get 87
      local.get 89
      struct.new 62
      local.set 72
      i32.const 0
      local.set 90
      block ;; label = @2
        loop ;; label = @3
          local.get 90
          local.get 82
          i32.ge_u
          if ;; label = @4
            br 2 (;@2;)
          end
          local.get 27
          ref.as_non_null
          local.get 90
          array.get 99
          local.set 70
          i32.const 14
          local.get 70
          ref.as_non_null
          local.get 72
          ref.as_non_null
          local.get 72
          ref.as_non_null
          struct.new 70
          local.set 66
          local.get 83
          ref.as_non_null
          local.get 90
          local.get 66
          ref.as_non_null
          array.set 92
          ref.null 70
          local.set 66
          ref.null 62
          local.set 70
          local.get 90
          i32.const 1
          i32.add
          local.set 90
          br 0 (;@3;)
        end
      end
      local.get 82
      f64.convert_i32_u
      i64.reinterpret_f64
      local.set 94
      i32.const 3
      local.set 91
      local.get 94
      local.set 92
      ref.null eq
      local.set 93
      i32.const 140
      local.set 95
      local.get 95
      call 108
      local.set 48
      i32.const 4
      local.set 95
      i64.const 0
      local.set 96
      local.get 48
      ref.as_non_null
      local.set 97
      ref.null 131
      local.set 48
      i32.const 0
      local.set 98
      i64.const 0
      local.set 99
      ref.null eq
      local.set 100
      local.get 92
      local.get 91
      local.get 93
      struct.new 62
      local.set 70
      global.get 19
      local.set 64
      i32.const 6
      local.get 70
      ref.as_non_null
      local.get 64
      ref.as_non_null
      local.get 64
      ref.as_non_null
      struct.new 70
      local.set 68
      ref.null 62
      local.set 64
      ref.null 62
      local.set 70
      local.get 54
      ref.as_non_null
      local.get 95
      local.get 96
      local.get 97
      local.get 68
      ref.as_non_null
      call 94
      ref.null 70
      local.set 68
      ref.null eq
      local.set 100
      ref.null eq
      local.set 97
      i32.const 118
      local.set 95
      local.get 95
      call 108
      local.set 48
      i32.const 4
      local.set 98
      i64.const 0
      local.set 96
      local.get 48
      ref.as_non_null
      local.set 97
      ref.null 131
      local.set 48
      i32.const 8
      local.set 91
      i64.const 0
      local.set 92
      local.get 61
      ref.as_non_null
      local.set 93
      i32.const 0
      local.set 95
      i64.const 0
      local.set 99
      ref.null eq
      local.set 100
      local.get 92
      local.get 91
      local.get 93
      struct.new 62
      local.set 64
      global.get 19
      local.set 70
      i32.const 6
      local.get 64
      ref.as_non_null
      local.get 70
      ref.as_non_null
      local.get 70
      ref.as_non_null
      struct.new 70
      local.set 65
      ref.null 62
      local.set 70
      ref.null 62
      local.set 64
      local.get 54
      ref.as_non_null
      local.get 98
      local.get 96
      local.get 97
      local.get 65
      ref.as_non_null
      call 94
      ref.null 70
      local.set 65
      ref.null eq
      local.set 100
      ref.null eq
      local.set 97
      local.get 41
      ref.as_non_null
      struct.get 161 5
      local.set 45
      i32.const 1
      local.set 98
      local.get 45
      ref.as_non_null
      local.get 98
      array.get 163
      local.set 70
      ref.null 163
      local.set 45
      local.get 70
      ref.as_non_null
      struct.get 62 1
      local.set 91
      local.get 70
      ref.as_non_null
      struct.get 62 0
      local.set 92
      local.get 70
      ref.as_non_null
      struct.get 62 2
      local.set 93
      i32.const 0
      local.get 91
      i32.const 6
      i32.eq
      i32.or
      local.get 91
      i32.const 7
      i32.eq
      i32.or
      local.get 91
      i32.const 8
      i32.eq
      i32.or
      local.get 91
      i32.const 9
      i32.eq
      i32.or
      i32.eqz
      if ;; label = @2
        unreachable
      end
      ref.null 62
      local.set 70
      global.get 1
      ref.as_non_null
      i32.const 3
      array.get 135
      local.set 101
      i32.const 5
      local.set 95
      i64.const 0
      local.set 96
      local.get 101
      ref.as_non_null
      local.set 97
      i32.const 0
      local.set 98
      i64.const 0
      local.set 99
      ref.null eq
      local.set 100
      local.get 92
      local.get 91
      local.get 93
      struct.new 62
      local.set 70
      global.get 19
      local.set 64
      i32.const 6
      local.get 70
      ref.as_non_null
      local.get 64
      ref.as_non_null
      local.get 64
      ref.as_non_null
      struct.new 70
      local.set 68
      ref.null 62
      local.set 64
      ref.null 62
      local.set 70
      local.get 54
      ref.as_non_null
      local.get 95
      local.get 96
      local.get 97
      local.get 68
      ref.as_non_null
      call 94
      ref.null 70
      local.set 68
      ref.null eq
      local.set 100
      ref.null eq
      local.set 97
      ref.null 138
      local.set 101
      local.get 54
      ref.as_non_null
      local.get 83
      ref.as_non_null
      local.get 84
      struct.new 114
      ref.null eq
      local.set 93
      ref.null 62
      local.set 72
      ref.null eq
      local.set 89
      ref.null 129
      local.set 84
      ref.null 92
      local.set 83
      ref.null 69
      local.set 54
      ref.null eq
      local.set 81
      ref.null 161
      local.set 41
      ref.null 99
      local.set 27
      ref.null 107
      local.set 61
      local.set 78
      i32.const 9
      local.set 75
      i64.const 0
      local.set 76
      local.get 78
      ref.as_non_null
      local.set 77
      i32.const 9
      local.set 98
      i64.const 0
      local.set 99
      local.get 78
      ref.as_non_null
      local.set 100
      local.get 99
      local.get 98
      local.get 100
      struct.new 62
      local.set 64
      local.get 57
      ref.is_null
      i32.eqz
      if ;; label = @2
        local.get 57
        ref.as_non_null
        local.set 60
        local.get 60
        ref.as_non_null
        struct.get 108 0
        local.set 65
        local.get 65
        ref.is_null
        i32.eqz
        if ;; label = @3
          local.get 65
          ref.as_non_null
          local.set 66
          local.get 58
          ref.as_non_null
          local.get 39
          local.get 37
          local.get 38
          call 93
          local.set 67
          ref.null 70
          local.set 68
          local.get 67
          ref.is_null
          i32.eqz
          if ;; label = @4
            local.get 67
            ref.as_non_null
            local.set 69
            local.get 69
            ref.as_non_null
            struct.get 74 1
            local.set 68
            ref.null 74
            local.set 69
          end
          ref.null 74
          local.set 67
          local.get 60
          ref.as_non_null
          struct.get 108 1
          local.set 70
          local.get 66
          ref.as_non_null
          struct.get 70 1
          local.set 71
          local.get 68
          local.get 65
          ref.eq
          local.get 66
          ref.as_non_null
          struct.get 70 0
          local.set 87
          local.get 87
          i32.const 1
          i32.and
          i32.eqz
          i32.and
          local.get 87
          i32.const 6
          i32.and
          i32.eqz
          i32.eqz
          i32.and
          local.get 71
          ref.as_non_null
          local.get 70
          ref.eq
          i32.and
          ref.null 61
          local.set 71
          if ;; label = @4
            local.get 64
            ref.as_non_null
            local.set 72
            local.get 66
            ref.as_non_null
            local.get 72
            ref.as_non_null
            struct.set 70 1
            local.get 60
            ref.as_non_null
            local.get 72
            ref.as_non_null
            struct.set 108 1
            ref.null 62
            local.set 72
          else
            local.get 60
            ref.as_non_null
            ref.null 70
            struct.set 108 0
            local.get 60
            ref.as_non_null
            ref.null 62
            struct.set 108 1
          end
          ref.null 62
          local.set 70
          ref.null 70
          local.set 68
          ref.null 70
          local.set 66
        end
        ref.null 70
        local.set 65
        ref.null 108
        local.set 60
      end
      ref.null 62
      local.set 64
      ref.null eq
      local.set 100
      ref.null 114
      local.set 78
      local.get 75
      local.set 63
      local.get 76
      local.set 73
      local.get 77
      local.set 74
      i32.const 1
      local.set 40
      ref.null eq
      local.set 77
      i32.const 0
      local.set 16
      i32.const 0
      local.set 79
      i64.const 0
      local.set 88
      ref.null eq
      local.set 81
      i32.const 0
      local.set 79
      i64.const 0
      local.set 88
      ref.null eq
      local.set 81
      i32.const 0
      local.set 75
      i64.const 0
      local.set 76
      ref.null eq
      local.set 77
      i32.const 0
      local.set 75
      i64.const 0
      local.set 76
      ref.null eq
      local.set 77
      i32.const 0
      local.set 98
      i64.const 0
      local.set 99
      ref.null eq
      local.set 100
      i32.const 0
      local.set 98
      i64.const 0
      local.set 99
      ref.null eq
      local.set 100
      i32.const 0
      local.set 95
      i64.const 0
      local.set 80
      ref.null eq
      local.set 97
      i32.const 0
      local.set 95
      i64.const 0
      local.set 80
      ref.null eq
      local.set 97
      i32.const 0
      local.set 13
      i64.const 0
      local.set 14
      ref.null eq
      local.set 15
      local.get 13
      local.set 90
      local.get 14
      local.set 96
      local.get 15
      local.set 93
      i64.const 0
      local.set 103
      local.get 11
      ref.as_non_null
      local.set 86
      local.get 86
      ref.as_non_null
      local.set 106
      ref.null 120
      local.set 107
      block ;; label = @2
        loop ;; label = @3
          local.get 106
          ref.as_non_null
          struct.get 120 3
          local.set 107
          local.get 107
          ref.is_null
          br_if 1 (;@2;)
          local.get 107
          ref.as_non_null
          local.set 106
          br 0 (;@3;)
        end
      end
      ref.null 120
      local.set 107
      ref.null 120
      local.set 86
      local.get 106
      ref.as_non_null
      struct.get 120 0
      ref.as_non_null
      local.set 41
      ref.null 120
      local.set 106
      local.get 41
      ref.as_non_null
      struct.get 161 5
      local.set 45
      i32.const 0
      local.set 112
      local.get 45
      ref.as_non_null
      local.get 112
      array.get 163
      local.set 70
      ref.null 163
      local.set 45
      local.get 70
      ref.as_non_null
      struct.get 62 1
      local.set 109
      local.get 70
      ref.as_non_null
      struct.get 62 0
      local.set 110
      local.get 70
      ref.as_non_null
      struct.get 62 2
      local.set 111
      i32.const 0
      local.get 109
      i32.const 6
      i32.eq
      i32.or
      local.get 109
      i32.const 7
      i32.eq
      i32.or
      local.get 109
      i32.const 8
      i32.eq
      i32.or
      local.get 109
      i32.const 9
      i32.eq
      i32.or
      i32.eqz
      if ;; label = @2
        unreachable
      end
      ref.null 62
      local.set 70
      local.get 111
      ref.cast (ref 139)
      ref.null eq
      local.set 111
      local.set 108
      i32.const 7
      local.set 87
      i64.const 0
      local.set 104
      local.get 108
      ref.as_non_null
      local.set 105
      ref.null 139
      local.set 108
      ref.null 161
      local.set 41
      local.get 103
      i64.const 0
      i64.lt_s
      local.get 103
      i64.const 4294967295
      i64.gt_u
      i32.or
      if ;; label = @2
        local.get 22
        ref.as_non_null
        struct.get 110 0
        local.set 41
        local.get 41
        ref.as_non_null
        call 100
        local.get 41
        ref.as_non_null
        struct.get 161 5
        local.set 45
        i32.const 6
        local.set 117
        local.get 45
        ref.as_non_null
        local.get 117
        array.get 163
        local.set 64
        ref.null 163
        local.set 45
        local.get 64
        ref.as_non_null
        struct.get 62 1
        local.set 114
        local.get 64
        ref.as_non_null
        struct.get 62 0
        local.set 115
        local.get 64
        ref.as_non_null
        struct.get 62 2
        local.set 116
        i32.const 0
        local.get 114
        i32.const 6
        i32.eq
        i32.or
        local.get 114
        i32.const 7
        i32.eq
        i32.or
        local.get 114
        i32.const 8
        i32.eq
        i32.or
        local.get 114
        i32.const 9
        i32.eq
        i32.or
        i32.eqz
        if ;; label = @3
          unreachable
        end
        ref.null 62
        local.set 64
        i32.const 2157
        local.set 117
        local.get 117
        call 108
        local.set 48
        i32.const 2
        local.get 114
        local.get 115
        local.get 116
        local.get 48
        ref.as_non_null
        call 107
        local.set 49
        i32.const 6
        local.set 117
        i64.const 0
        local.set 118
        local.get 49
        ref.as_non_null
        local.set 119
        local.get 117
        local.set 112
        local.get 118
        local.set 110
        local.get 119
        local.set 111
        i32.const 1
        local.set 109
        i32.const 0
        local.set 113
        ref.null eq
        local.set 119
        ref.null 220
        local.set 49
        ref.null 131
        local.set 48
        ref.null eq
        local.set 116
        ref.null 161
        local.set 41
        local.get 112
        local.set 13
        local.get 110
        local.set 14
        local.get 111
        local.set 15
        local.get 109
        local.set 16
        local.get 113
        local.set 17
        ref.null eq
        local.set 111
        br 1 (;@1;)
      end
      i32.const 0
      local.set 112
      local.get 87
      local.get 104
      local.get 105
      local.get 112
      call 96
      local.set 54
      global.get 15
      local.set 120
      global.get 16
      local.set 83
      global.get 17
      local.set 121
      global.get 18
      local.set 122
      local.get 54
      ref.as_non_null
      i32.const 1
      local.get 103
      i64.const 0
      local.get 120
      ref.as_non_null
      local.get 83
      ref.as_non_null
      i32.const 2
      local.get 121
      ref.as_non_null
      local.get 122
      ref.as_non_null
      ref.null 93
      struct.new 139
      ref.null 92
      local.set 83
      ref.null 95
      local.set 122
      ref.null 94
      local.set 121
      ref.null 97
      local.set 120
      ref.null 69
      local.set 54
      local.set 108
      ref.null eq
      local.set 105
      i32.const 7
      local.set 82
      i64.const 0
      local.set 94
      local.get 108
      ref.as_non_null
      local.set 89
      ref.null 139
      local.set 108
      ref.null eq
      local.set 102
      local.get 16
      i32.const 1
      i32.eq
      if ;; label = @2
        br 1 (;@1;)
      end
      local.get 82
      local.set 98
      local.get 94
      local.set 99
      local.get 89
      local.set 100
      ref.null eq
      local.set 89
      local.get 16
      i32.const 1
      i32.eq
      if ;; label = @2
        br 1 (;@1;)
      end
      local.get 16
      i32.const 0
      i32.eq
      if ;; label = @2
        local.get 90
        local.set 13
        local.get 96
        local.set 14
        local.get 93
        local.set 15
      end
      ref.null eq
      local.set 93
      i32.const 0
      local.set 13
      i64.const 0
      local.set 14
      ref.null eq
      local.set 15
      i32.const 0
      local.set 16
      i32.const 0
      local.set 17
      block ;; label = @2
        local.get 13
        local.set 112
        local.get 14
        local.set 103
        local.get 15
        local.set 119
        i32.const 3
        local.set 90
        i64.const 0
        local.set 96
        ref.null eq
        local.set 93
        local.get 16
        i32.const 1
        i32.eq
        if ;; label = @3
          br 2 (;@1;)
        end
        local.get 90
        local.set 75
        local.get 96
        local.set 76
        local.get 93
        local.set 77
        ref.null eq
        local.set 93
        local.get 16
        i32.const 1
        i32.eq
        if ;; label = @3
          br 2 (;@1;)
        end
        local.get 16
        i32.const 0
        i32.eq
        if ;; label = @3
          local.get 112
          local.set 13
          local.get 103
          local.set 14
          local.get 119
          local.set 15
        end
        ref.null eq
        local.set 119
        loop ;; label = @3
          local.get 13
          local.set 82
          local.get 14
          local.set 94
          local.get 15
          local.set 89
          local.get 75
          local.set 112
          local.get 76
          local.set 103
          local.get 77
          local.set 119
          local.get 16
          i32.const 1
          i32.eq
          if ;; label = @4
            br 3 (;@1;)
          end
          i32.const 3
          local.set 90
          i64.const 4665729213955833856
          local.set 96
          ref.null eq
          local.set 93
          local.get 16
          i32.const 1
          i32.eq
          if ;; label = @4
            br 3 (;@1;)
          end
          local.get 112
          i32.const 3
          i32.eq
          local.get 90
          i32.const 3
          i32.eq
          i32.and
          if ;; label = @4
            local.get 103
            f64.reinterpret_i64
            local.get 96
            f64.reinterpret_i64
            f64.lt
            local.set 114
          else
            local.get 22
            ref.as_non_null
            struct.get 110 0
            local.set 41
            local.get 112
            local.get 103
            local.get 119
            local.get 90
            local.get 96
            local.get 93
            local.get 41
            ref.as_non_null
            local.get 11
            local.get 26
            ref.as_non_null
            call 113
            local.set 117
            local.set 87
            local.set 102
            local.set 92
            local.set 91
            ref.null 161
            local.set 41
            ref.null eq
            local.set 93
            ref.null eq
            local.set 119
            local.get 87
            i32.const 1
            i32.eq
            if ;; label = @5
              local.get 91
              local.set 13
              local.get 92
              local.set 14
              local.get 102
              local.set 15
              local.get 87
              local.set 16
              local.get 117
              local.set 17
              br 4 (;@1;)
            end
            local.get 92
            f64.reinterpret_i64
            f64.const 0x0p+0 (;=0;)
            f64.lt
            local.set 114
          end
          ref.null eq
          local.set 102
          ref.null eq
          local.set 93
          ref.null eq
          local.set 119
          local.get 114
          local.get 16
          i32.const 1
          i32.eq
          if ;; label = @4
            br 3 (;@1;)
          end
          local.get 16
          i32.const 0
          i32.eq
          if ;; label = @4
            local.get 82
            local.set 13
            local.get 94
            local.set 14
            local.get 89
            local.set 15
          end
          ref.null eq
          local.set 89
          local.get 16
          i32.const 1
          i32.eq
          if ;; label = @4
            br 3 (;@1;)
          end
          i32.eqz
          br_if 1 (;@2;)
          block ;; label = @4
            local.get 98
            local.set 82
            local.get 99
            local.set 94
            local.get 100
            local.set 89
            local.get 16
            i32.const 1
            i32.eq
            if ;; label = @5
              br 4 (;@1;)
            end
            i32.const 0
            local.set 112
            i64.const 0
            local.set 104
            ref.null eq
            local.set 119
            i32.const 0
            local.set 90
            local.get 82
            local.set 112
            local.get 94
            local.set 104
            local.get 89
            local.set 119
            i32.const 1
            local.set 90
            local.get 90
            i32.eqz
            if ;; label = @5
              local.get 22
              ref.as_non_null
              struct.get 110 0
              local.set 41
              local.get 41
              ref.as_non_null
              local.get 11
              call 112
              local.set 17
              local.set 16
              local.set 15
              local.set 14
              local.set 13
              ref.null 161
              local.set 41
              local.get 13
              local.set 87
              local.get 14
              local.set 103
              local.get 15
              local.set 111
              local.get 16
              i32.const 1
              i32.eq
              if ;; label = @6
                br 5 (;@1;)
              end
              ref.null eq
              local.set 111
            end
            local.get 112
            local.set 117
            local.get 104
            local.set 118
            local.get 119
            local.set 116
            local.get 16
            i32.const 1
            i32.eq
            if ;; label = @5
              br 4 (;@1;)
            end
            i32.const 248
            local.set 87
            local.get 87
            call 108
            local.set 48
            i32.const 4
            local.set 109
            i64.const 0
            local.set 115
            local.get 48
            ref.as_non_null
            local.set 111
            ref.null 131
            local.set 48
            local.get 16
            i32.const 1
            i32.eq
            if ;; label = @5
              br 4 (;@1;)
            end
            i32.const 0
            local.set 87
            i64.const 0
            local.set 103
            ref.null eq
            local.set 123
            i32.const 0
            local.set 124
            i32.const 0
            local.set 125
            block ;; label = @5
              block ;; label = @6
                global.get 2
                ref.as_non_null
                local.set 41
                local.get 41
                ref.as_non_null
                local.get 117
                local.get 118
                local.get 116
                call 97
                local.set 125
                local.set 124
                local.set 123
                local.set 103
                local.set 87
                ref.null 161
                local.set 41
                local.get 124
                i32.const 1
                i32.eq
                if ;; label = @7
                  br 1 (;@6;)
                end
                local.get 87
                local.set 128
                local.get 103
                local.set 129
                local.get 123
                local.set 130
                local.get 109
                local.get 115
                local.get 111
                local.get 11
                local.get 26
                ref.as_non_null
                call 106
                local.set 135
                local.set 134
                local.set 133
                local.set 132
                local.set 131
                local.get 134
                i32.const 1
                i32.eq
                if ;; label = @7
                  local.get 131
                  local.set 87
                  local.get 132
                  local.set 103
                  local.get 133
                  local.set 123
                  local.get 134
                  local.set 124
                  local.get 135
                  local.set 125
                  br 1 (;@6;)
                end
                local.get 131
                local.set 136
                local.get 132
                local.set 137
                local.get 133
                local.set 138
                local.get 128
                local.get 129
                local.get 130
                local.get 117
                local.get 118
                local.get 116
                local.get 136
                local.get 137
                local.get 138
                local.get 11
                local.get 26
                ref.as_non_null
                call 85
                local.set 125
                local.set 124
                local.set 123
                local.set 103
                local.set 87
                local.get 124
                i32.const 1
                i32.eq
                if ;; label = @7
                  br 1 (;@6;)
                end
              end
              ref.null eq
              local.set 133
              ref.null eq
              local.set 138
              ref.null eq
              local.set 130
            end
            local.get 87
            local.set 13
            local.get 103
            local.set 14
            local.get 123
            local.set 15
            local.get 124
            local.set 16
            local.get 125
            local.set 17
            local.get 124
            i32.const 0
            i32.eq
            if ;; label = @5
              local.get 87
              local.set 114
              local.get 103
              local.set 96
              local.get 123
              local.set 93
            end
            ref.null eq
            local.set 123
            ref.null eq
            local.set 111
            ref.null eq
            local.set 116
            local.get 16
            i32.const 1
            i32.eq
            if ;; label = @5
              br 4 (;@1;)
            end
            local.get 16
            i32.const 1
            i32.eq
            if ;; label = @5
              br 4 (;@1;)
            end
            local.get 16
            i32.const 1
            i32.eq
            if ;; label = @5
              br 4 (;@1;)
            end
            local.get 90
            i32.eqz
            if ;; label = @5
              local.get 22
              ref.as_non_null
              struct.get 110 0
              local.set 41
              local.get 41
              ref.as_non_null
              local.get 11
              call 112
              local.set 17
              local.set 16
              local.set 15
              local.set 14
              local.set 13
              ref.null 161
              local.set 41
              local.get 13
              local.set 135
              local.get 14
              local.set 132
              local.get 15
              local.set 133
              local.get 16
              i32.const 1
              i32.eq
              if ;; label = @6
                br 5 (;@1;)
              end
              ref.null eq
              local.set 133
            end
            local.get 112
            local.set 91
            local.get 104
            local.set 92
            local.get 119
            local.set 102
            local.get 16
            i32.const 1
            i32.eq
            if ;; label = @5
              br 4 (;@1;)
            end
            local.get 16
            i32.const 1
            i32.eq
            if ;; label = @5
              br 4 (;@1;)
            end
            i32.const 1
            local.set 135
            local.get 26
            ref.as_non_null
            struct.get 109 11
            local.set 139
            local.get 135
            i32.const 6
            i32.shr_u
            local.set 117
            i32.const 0
            local.set 134
            local.get 139
            ref.is_null
            i32.eqz
            if ;; label = @5
              local.get 139
              array.len
              local.set 134
            end
            local.get 117
            local.get 134
            i32.ge_u
            if ;; label = @5
              local.get 117
              i32.const 1
              i32.add
              local.set 87
              local.get 134
              i32.const 1
              i32.shl
              local.set 131
              local.get 131
              i32.const 8
              i32.lt_u
              if ;; label = @6
                i32.const 8
                local.set 131
              end
              local.get 131
              local.get 87
              i32.lt_u
              if ;; label = @6
                local.get 87
                local.set 131
              end
              ref.null 81
              local.get 131
              array.new 82
              local.set 140
              local.get 134
              if ;; label = @6
                local.get 139
                ref.as_non_null
                local.set 141
                local.get 140
                ref.as_non_null
                i32.const 0
                local.get 141
                ref.as_non_null
                i32.const 0
                local.get 134
                array.copy 82 82
                ref.null 82
                local.set 141
              end
              local.get 26
              ref.as_non_null
              local.get 140
              ref.as_non_null
              struct.set 109 11
              local.get 140
              ref.as_non_null
              local.set 139
              ref.null 82
              local.set 140
            end
            local.get 139
            local.get 117
            array.get 82
            local.set 142
            local.get 142
            ref.is_null
            if ;; label = @5
              i32.const 64
              local.set 131
              ref.null 80
              local.get 131
              array.new 81
              local.set 143
              local.get 139
              local.get 117
              local.get 143
              ref.as_non_null
              array.set 82
              local.get 143
              ref.as_non_null
              local.set 142
              ref.null 81
              local.set 143
            end
            local.get 142
            ref.as_non_null
            local.set 143
            local.get 135
            i32.const 63
            i32.and
            local.set 136
            ref.null 81
            local.set 142
            ref.null 82
            local.set 139
            local.get 143
            ref.as_non_null
            local.get 136
            array.get 81
            local.set 144
            local.get 144
            ref.is_null
            if ;; label = @5
              i32.const 141
              local.set 117
              local.get 117
              call 108
              local.set 48
              i32.const 255
              local.set 134
              local.get 134
              call 108
              local.set 145
              local.get 48
              ref.as_non_null
              local.get 145
              ref.as_non_null
              array.new_fixed 83 2
              local.set 146
              local.get 146
              ref.as_non_null
              i32.const 14
              struct.new 80
              local.set 147
              local.get 143
              ref.as_non_null
              local.get 136
              local.get 147
              ref.as_non_null
              array.set 81
              local.get 147
              ref.as_non_null
              local.set 144
              ref.null 80
              local.set 147
              ref.null 83
              local.set 146
              ref.null 131
              local.set 48
              ref.null 131
              local.set 145
            end
            local.get 144
            ref.as_non_null
            local.set 147
            ref.null 80
            local.set 144
            ref.null 81
            local.set 143
            local.get 11
            ref.as_non_null
            local.set 106
            local.get 106
            ref.as_non_null
            local.set 107
            ref.null 120
            local.set 86
            block ;; label = @5
              loop ;; label = @6
                local.get 107
                ref.as_non_null
                struct.get 120 3
                local.set 86
                local.get 86
                ref.is_null
                br_if 1 (;@5;)
                local.get 86
                ref.as_non_null
                local.set 107
                br 0 (;@6;)
              end
            end
            ref.null 120
            local.set 86
            ref.null 120
            local.set 106
            local.get 107
            ref.as_non_null
            struct.get 120 0
            ref.as_non_null
            local.set 41
            ref.null 120
            local.set 107
            local.get 41
            ref.as_non_null
            struct.get 161 5
            local.set 45
            i32.const 21
            local.set 135
            local.get 45
            ref.as_non_null
            local.get 135
            array.get 163
            local.set 70
            ref.null 163
            local.set 45
            local.get 70
            ref.as_non_null
            struct.get 62 1
            local.set 117
            local.get 70
            ref.as_non_null
            struct.get 62 0
            local.set 115
            local.get 70
            ref.as_non_null
            struct.get 62 2
            local.set 111
            i32.const 0
            local.get 117
            i32.const 6
            i32.eq
            i32.or
            local.get 117
            i32.const 7
            i32.eq
            i32.or
            local.get 117
            i32.const 8
            i32.eq
            i32.or
            local.get 117
            i32.const 9
            i32.eq
            i32.or
            i32.eqz
            if ;; label = @5
              unreachable
            end
            ref.null 62
            local.set 70
            ref.null 161
            local.set 41
            local.get 117
            local.get 115
            local.get 111
            local.get 147
            ref.as_non_null
            call 87
            local.set 54
            local.get 54
            ref.as_non_null
            struct.get 69 1
            local.set 148
            local.get 148
            ref.as_non_null
            ref.cast (ref 77)
            local.set 149
            local.get 26
            ref.as_non_null
            struct.get 109 5
            local.set 150
            i32.const 4
            local.set 125
            local.get 150
            ref.as_non_null
            local.get 125
            array.get 134
            ref.as_non_null
            ref.null 134
            local.set 150
            local.set 48
            i32.const 4
            local.set 134
            i64.const 0
            local.set 103
            local.get 48
            ref.as_non_null
            local.set 138
            ref.null 131
            local.set 48
            local.get 16
            i32.const 1
            i32.eq
            if ;; label = @5
              br 4 (;@1;)
            end
            local.get 75
            local.set 131
            local.get 76
            local.set 137
            local.get 77
            local.set 130
            local.get 16
            i32.const 1
            i32.eq
            if ;; label = @5
              br 4 (;@1;)
            end
            local.get 134
            i32.const 3
            i32.eq
            local.get 131
            i32.const 3
            i32.eq
            i32.and
            if ;; label = @5
              local.get 103
              f64.reinterpret_i64
              local.get 137
              f64.reinterpret_i64
              f64.add
              i64.reinterpret_f64
              local.set 129
              i32.const 3
              local.set 87
              local.get 129
              local.set 129
              ref.null eq
              local.set 123
              local.get 87
              local.set 87
              local.get 129
              local.set 129
              local.get 123
              local.set 123
              i32.const 0
              local.set 124
              i32.const 0
              local.set 126
            else
              local.get 22
              ref.as_non_null
              struct.get 110 0
              local.set 41
              local.get 134
              local.get 103
              local.get 138
              local.get 131
              local.get 137
              local.get 130
              local.get 41
              ref.as_non_null
              local.get 11
              local.get 26
              ref.as_non_null
              call 104
              local.set 126
              local.set 124
              local.set 123
              local.set 129
              local.set 87
              ref.null 161
              local.set 41
            end
            ref.null eq
            local.set 130
            ref.null eq
            local.set 138
            local.get 124
            i32.const 1
            i32.eq
            if ;; label = @5
              local.get 87
              local.set 13
              local.get 129
              local.set 14
              local.get 123
              local.set 15
              local.get 124
              local.set 16
              local.get 126
              local.set 17
              br 4 (;@1;)
            end
            local.get 87
            local.set 136
            local.get 129
            local.set 132
            local.get 123
            local.set 133
            ref.null eq
            local.set 123
            local.get 16
            i32.const 1
            i32.eq
            if ;; label = @5
              br 4 (;@1;)
            end
            local.get 16
            i32.const 1
            i32.eq
            if ;; label = @5
              br 4 (;@1;)
            end
            i32.const 0
            local.set 135
            local.get 149
            ref.as_non_null
            local.get 135
            local.get 136
            local.get 132
            local.get 133
            call 88
            i64.const 4
            local.set 127
            local.get 11
            ref.as_non_null
            local.set 107
            local.get 107
            ref.as_non_null
            local.set 86
            ref.null 120
            local.set 106
            block ;; label = @5
              loop ;; label = @6
                local.get 86
                ref.as_non_null
                struct.get 120 3
                local.set 106
                local.get 106
                ref.is_null
                br_if 1 (;@5;)
                local.get 106
                ref.as_non_null
                local.set 86
                br 0 (;@6;)
              end
            end
            ref.null 120
            local.set 106
            ref.null 120
            local.set 107
            local.get 86
            ref.as_non_null
            struct.get 120 0
            ref.as_non_null
            local.set 41
            ref.null 120
            local.set 86
            local.get 41
            ref.as_non_null
            struct.get 161 5
            local.set 45
            i32.const 0
            local.set 126
            local.get 45
            ref.as_non_null
            local.get 126
            array.get 163
            local.set 64
            ref.null 163
            local.set 45
            local.get 64
            ref.as_non_null
            struct.get 62 1
            local.set 124
            local.get 64
            ref.as_non_null
            struct.get 62 0
            local.set 103
            local.get 64
            ref.as_non_null
            struct.get 62 2
            local.set 138
            i32.const 0
            local.get 124
            i32.const 6
            i32.eq
            i32.or
            local.get 124
            i32.const 7
            i32.eq
            i32.or
            local.get 124
            i32.const 8
            i32.eq
            i32.or
            local.get 124
            i32.const 9
            i32.eq
            i32.or
            i32.eqz
            if ;; label = @5
              unreachable
            end
            ref.null 62
            local.set 64
            local.get 138
            ref.cast (ref 139)
            ref.null eq
            local.set 138
            local.set 108
            i32.const 7
            local.set 128
            i64.const 0
            local.set 129
            local.get 108
            ref.as_non_null
            local.set 123
            ref.null 139
            local.set 108
            ref.null 161
            local.set 41
            local.get 127
            i64.const 0
            i64.lt_s
            local.get 127
            i64.const 4294967295
            i64.gt_u
            i32.or
            if ;; label = @5
              local.get 22
              ref.as_non_null
              struct.get 110 0
              local.set 41
              local.get 41
              ref.as_non_null
              call 100
              local.get 41
              ref.as_non_null
              struct.get 161 5
              local.set 45
              i32.const 6
              local.set 125
              local.get 45
              ref.as_non_null
              local.get 125
              array.get 163
              local.set 72
              ref.null 163
              local.set 45
              local.get 72
              ref.as_non_null
              struct.get 62 1
              local.set 87
              local.get 72
              ref.as_non_null
              struct.get 62 0
              local.set 103
              local.get 72
              ref.as_non_null
              struct.get 62 2
              local.set 138
              i32.const 0
              local.get 87
              i32.const 6
              i32.eq
              i32.or
              local.get 87
              i32.const 7
              i32.eq
              i32.or
              local.get 87
              i32.const 8
              i32.eq
              i32.or
              local.get 87
              i32.const 9
              i32.eq
              i32.or
              i32.eqz
              if ;; label = @6
                unreachable
              end
              ref.null 62
              local.set 72
              i32.const 2157
              local.set 126
              local.get 126
              call 108
              local.set 145
              i32.const 2
              local.get 87
              local.get 103
              local.get 138
              local.get 145
              ref.as_non_null
              call 107
              local.set 49
              i32.const 6
              local.set 126
              i64.const 0
              local.set 151
              local.get 49
              ref.as_non_null
              local.set 152
              local.get 126
              local.set 134
              local.get 151
              local.set 137
              local.get 152
              local.set 130
              i32.const 1
              local.set 131
              i32.const 0
              local.set 124
              ref.null eq
              local.set 152
              ref.null 220
              local.set 49
              ref.null 131
              local.set 145
              ref.null eq
              local.set 138
              ref.null 161
              local.set 41
              local.get 134
              local.set 13
              local.get 137
              local.set 14
              local.get 130
              local.set 15
              local.get 131
              local.set 16
              local.get 124
              local.set 17
              ref.null eq
              local.set 130
              br 4 (;@1;)
            end
            i32.const 0
            local.set 125
            local.get 128
            local.get 129
            local.get 123
            local.get 125
            call 96
            local.set 153
            global.get 15
            local.set 120
            global.get 16
            local.set 83
            global.get 17
            local.set 121
            global.get 18
            local.set 122
            local.get 153
            ref.as_non_null
            i32.const 1
            local.get 127
            i64.const 0
            local.get 120
            ref.as_non_null
            local.get 83
            ref.as_non_null
            i32.const 2
            local.get 121
            ref.as_non_null
            local.get 122
            ref.as_non_null
            ref.null 93
            struct.new 139
            ref.null 92
            local.set 83
            ref.null 95
            local.set 122
            ref.null 94
            local.set 121
            ref.null 97
            local.set 120
            ref.null 69
            local.set 153
            local.set 108
            ref.null eq
            local.set 123
            local.get 75
            local.set 125
            local.get 76
            local.set 127
            local.get 77
            local.set 130
            local.get 16
            i32.const 1
            i32.eq
            if ;; label = @5
              br 4 (;@1;)
            end
            local.get 16
            i32.const 1
            i32.eq
            if ;; label = @5
              br 4 (;@1;)
            end
            local.get 76
            local.set 151
            i64.const 4607182418800017408
            local.set 103
            local.get 151
            f64.reinterpret_i64
            local.get 103
            f64.reinterpret_i64
            f64.add
            i64.reinterpret_f64
            local.set 129
            i32.const 3
            local.set 128
            local.get 129
            local.set 129
            ref.null eq
            local.set 123
            local.get 16
            i32.const 1
            i32.eq
            if ;; label = @5
              br 4 (;@1;)
            end
            local.get 16
            i32.const 1
            i32.eq
            if ;; label = @5
              br 4 (;@1;)
            end
            local.get 76
            local.set 103
            i64.const 4611686018427387904
            local.set 154
            local.get 103
            f64.reinterpret_i64
            local.get 154
            f64.reinterpret_i64
            f64.add
            i64.reinterpret_f64
            local.set 151
            i32.const 3
            local.set 131
            local.get 151
            local.set 151
            ref.null eq
            local.set 152
            local.get 16
            i32.const 1
            i32.eq
            if ;; label = @5
              br 4 (;@1;)
            end
            local.get 16
            i32.const 1
            i32.eq
            if ;; label = @5
              br 4 (;@1;)
            end
            local.get 76
            local.set 154
            i64.const 4613937818241073152
            local.set 155
            local.get 154
            f64.reinterpret_i64
            local.get 155
            f64.reinterpret_i64
            f64.add
            i64.reinterpret_f64
            local.set 103
            i32.const 3
            local.set 134
            local.get 103
            local.set 103
            ref.null eq
            local.set 138
            local.get 16
            i32.const 1
            i32.eq
            if ;; label = @5
              br 4 (;@1;)
            end
            local.get 16
            i32.const 1
            i32.eq
            if ;; label = @5
              br 4 (;@1;)
            end
            local.get 125
            i32.const 3
            i32.eq
            local.get 128
            i32.const 3
            i32.eq
            i32.and
            local.get 131
            i32.const 3
            i32.eq
            i32.and
            local.get 134
            i32.const 3
            i32.eq
            i32.and
            if ;; label = @5
              local.get 127
              local.get 129
              local.get 151
              local.get 103
              array.new_fixed 94 4
              local.set 121
              i64.const 15
              array.new_fixed 95 1
              local.set 122
              local.get 108
              ref.as_non_null
              local.set 156
              local.get 156
              ref.as_non_null
              local.get 121
              ref.as_non_null
              struct.set 139 7
              local.get 156
              ref.as_non_null
              local.get 122
              ref.as_non_null
              struct.set 139 8
              local.get 156
              ref.as_non_null
              i64.const 4
              struct.set 139 3
              ref.null 139
              local.set 156
              ref.null 95
              local.set 122
              ref.null 94
              local.set 121
            else
              i64.const 0
              local.set 137
              local.get 108
              ref.as_non_null
              local.get 137
              local.get 125
              local.get 127
              local.get 130
              call 83
              i64.const 1
              local.set 137
              local.get 108
              ref.as_non_null
              local.get 137
              local.get 128
              local.get 129
              local.get 123
              call 83
              i64.const 2
              local.set 137
              local.get 108
              ref.as_non_null
              local.get 137
              local.get 131
              local.get 151
              local.get 152
              call 83
              i64.const 3
              local.set 137
              local.get 108
              ref.as_non_null
              local.get 137
              local.get 134
              local.get 103
              local.get 138
              call 83
            end
            i32.const 7
            local.set 136
            i64.const 0
            local.set 132
            local.get 108
            ref.as_non_null
            local.set 133
            ref.null 139
            local.set 108
            ref.null eq
            local.set 130
            ref.null eq
            local.set 123
            ref.null eq
            local.set 152
            ref.null eq
            local.set 138
            local.get 16
            i32.const 1
            i32.eq
            if ;; label = @5
              br 4 (;@1;)
            end
            local.get 16
            i32.const 1
            i32.eq
            if ;; label = @5
              br 4 (;@1;)
            end
            i32.const 1
            local.set 135
            local.get 149
            ref.as_non_null
            local.get 135
            local.get 136
            local.get 132
            local.get 133
            call 88
            i32.const 6
            local.set 109
            i64.const 0
            local.set 118
            local.get 54
            ref.as_non_null
            local.set 116
            ref.null eq
            local.set 133
            ref.null 77
            local.set 149
            ref.null 76
            local.set 148
            ref.null 69
            local.set 54
            ref.null eq
            local.set 111
            ref.null 80
            local.set 147
            local.get 16
            i32.const 1
            i32.eq
            if ;; label = @5
              br 4 (;@1;)
            end
            local.get 16
            i32.const 1
            i32.eq
            if ;; label = @5
              br 4 (;@1;)
            end
            i32.const 0
            local.set 124
            local.get 114
            i32.const 8
            i32.eq
            local.get 93
            ref.test (ref 107)
            i32.and
            if ;; label = @5
              local.get 93
              ref.cast (ref 107)
              local.set 52
              local.get 52
              ref.as_non_null
              struct.get 107 1
              local.set 62
              local.get 52
              ref.as_non_null
              struct.get 107 2
              local.set 157
              local.get 157
              ref.as_non_null
              struct.get 110 0
              local.set 41
              local.get 62
              ref.as_non_null
              struct.get 106 1
              local.set 117
              local.get 62
              ref.as_non_null
              struct.get 106 2
              local.set 126
              local.get 117
              i32.const 1
              i32.eq
              local.get 126
              i32.const 96
              i32.eq
              i32.and
              global.get 2
              ref.as_non_null
              local.set 158
              local.get 41
              ref.as_non_null
              local.get 158
              ref.as_non_null
              ref.eq
              i32.and
              if ;; label = @6
                local.get 91
                local.get 92
                local.get 102
                local.get 109
                local.get 118
                local.get 116
                call 84
                local.set 125
                local.set 136
                local.set 111
                local.set 115
                local.set 87
                local.get 136
                i32.const 1
                i32.eq
                if ;; label = @7
                  local.get 87
                  local.set 13
                  local.get 115
                  local.set 14
                  local.get 111
                  local.set 15
                  local.get 136
                  local.set 16
                  local.get 125
                  local.set 17
                  br 6 (;@1;)
                end
                local.get 87
                i32.const 3
                i32.eq
                if ;; label = @7
                  local.get 87
                  local.set 113
                  local.get 115
                  local.set 110
                  local.get 111
                  local.set 105
                  i32.const 1
                  local.set 124
                end
                ref.null eq
                local.set 111
              end
              ref.null 161
              local.set 158
              ref.null 161
              local.set 41
              ref.null 110
              local.set 157
              ref.null 106
              local.set 62
              ref.null 107
              local.set 52
            end
            local.get 124
            i32.eqz
            if ;; label = @5
              local.get 118
              local.get 109
              local.get 116
              struct.new 62
              local.set 72
              local.get 72
              ref.as_non_null
              array.new_fixed 99 1
              local.set 27
              ref.null 62
              local.set 72
              global.get 2
              ref.as_non_null
              local.set 41
              local.get 114
              local.get 96
              local.get 93
              local.get 91
              local.get 92
              local.get 102
              local.get 27
              ref.as_non_null
              local.get 41
              ref.as_non_null
              local.get 11
              local.get 26
              ref.as_non_null
              call 101
              local.set 117
              local.set 128
              local.set 133
              local.set 154
              local.set 135
              local.get 41
              ref.as_non_null
              global.set 2
              ref.null 161
              local.set 41
              local.get 128
              i32.const 2
              i32.eq
              if ;; label = @6
                local.get 135
                local.set 135
                local.get 154
                local.set 154
                local.get 133
                local.set 133
                i32.const 0
                local.set 128
                i32.const 0
                local.set 117
              end
              local.get 128
              i32.const 1
              i32.eq
              if ;; label = @6
                local.get 135
                local.set 13
                local.get 154
                local.set 14
                local.get 133
                local.set 15
                local.get 128
                local.set 16
                local.get 117
                local.set 17
              end
              local.get 16
              i32.const 1
              i32.eq
              if ;; label = @6
                br 5 (;@1;)
              end
              local.get 135
              local.set 113
              local.get 154
              local.set 110
              local.get 133
              local.set 105
              ref.null eq
              local.set 133
              ref.null 99
              local.set 27
            end
            ref.null eq
            local.set 116
            ref.null eq
            local.set 102
            ref.null eq
            local.set 93
            local.get 16
            i32.const 1
            i32.eq
            if ;; label = @5
              br 4 (;@1;)
            end
            ref.null eq
            local.set 119
            ref.null eq
            local.set 89
            local.get 16
            i32.const 1
            i32.eq
            if ;; label = @5
              br 4 (;@1;)
            end
            local.get 16
            i32.const 1
            i32.eq
            if ;; label = @5
              br 4 (;@1;)
            end
            local.get 113
            local.set 13
            local.get 110
            local.set 14
            local.get 105
            local.set 15
            i32.const 0
            local.set 16
            i32.const 0
            local.set 17
            ref.null eq
            local.set 105
          end
          local.get 13
          local.set 126
          local.get 14
          local.set 132
          local.get 15
          local.set 130
          local.get 75
          local.set 82
          local.get 76
          local.set 94
          local.get 77
          local.set 89
          local.get 82
          i32.const 3
          i32.ne
          if ;; label = @4
            i32.const 0
            local.set 114
            i64.const 0
            local.set 155
            ref.null eq
            local.set 93
            i32.const 0
            local.set 91
            i32.const 0
            local.set 90
            local.get 82
            local.get 94
            local.get 89
            local.get 11
            local.get 26
            ref.as_non_null
            call 103
            local.set 90
            local.set 91
            local.set 93
            local.set 155
            local.set 114
            local.get 114
            local.set 13
            local.get 155
            local.set 14
            local.get 93
            local.set 15
            local.get 91
            local.set 16
            local.get 90
            local.set 17
            local.get 16
            i32.const 1
            i32.eq
            if ;; label = @5
              br 4 (;@1;)
            end
            local.get 114
            local.set 82
            local.get 155
            local.set 94
            local.get 93
            local.set 89
            ref.null eq
            local.set 93
          end
          local.get 94
          f64.reinterpret_i64
          f64.const 0x1p+0 (;=1;)
          f64.add
          i64.reinterpret_f64
          local.set 104
          i32.const 3
          local.set 112
          local.get 104
          local.set 104
          ref.null eq
          local.set 119
          local.get 112
          local.set 75
          local.get 104
          local.set 76
          local.get 119
          local.set 77
          local.get 82
          local.set 113
          local.get 94
          local.set 110
          local.get 89
          local.set 105
          ref.null eq
          local.set 119
          ref.null eq
          local.set 89
          local.get 16
          i32.const 1
          i32.eq
          if ;; label = @4
            br 3 (;@1;)
          end
          ref.null eq
          local.set 105
          local.get 16
          i32.const 1
          i32.eq
          if ;; label = @4
            br 3 (;@1;)
          end
          local.get 16
          i32.const 0
          i32.eq
          if ;; label = @4
            local.get 126
            local.set 13
            local.get 132
            local.set 14
            local.get 130
            local.set 15
          end
          ref.null eq
          local.set 130
          br 0 (;@3;)
        end
      end
      local.get 13
      local.set 109
      local.get 14
      local.set 92
      local.get 15
      local.set 102
      i32.const 3
      local.set 126
      i64.const 0
      local.set 132
      ref.null eq
      local.set 130
      local.get 16
      i32.const 1
      i32.eq
      if ;; label = @2
        br 1 (;@1;)
      end
      local.get 126
      local.set 95
      local.get 132
      local.set 80
      local.get 130
      local.set 97
      ref.null eq
      local.set 130
      local.get 16
      i32.const 1
      i32.eq
      if ;; label = @2
        br 1 (;@1;)
      end
      local.get 16
      i32.const 0
      i32.eq
      if ;; label = @2
        local.get 109
        local.set 13
        local.get 92
        local.set 14
        local.get 102
        local.set 15
      end
      ref.null eq
      local.set 102
      i32.const 0
      local.set 13
      i64.const 0
      local.set 14
      ref.null eq
      local.set 15
      i32.const 0
      local.set 16
      i32.const 0
      local.set 17
      block ;; label = @2
        local.get 13
        local.set 113
        local.get 14
        local.set 110
        local.get 15
        local.set 105
        i32.const 3
        local.set 109
        i64.const 0
        local.set 92
        ref.null eq
        local.set 102
        local.get 16
        i32.const 1
        i32.eq
        if ;; label = @3
          br 2 (;@1;)
        end
        local.get 109
        local.set 79
        local.get 92
        local.set 88
        local.get 102
        local.set 81
        ref.null eq
        local.set 102
        local.get 16
        i32.const 1
        i32.eq
        if ;; label = @3
          br 2 (;@1;)
        end
        local.get 16
        i32.const 0
        i32.eq
        if ;; label = @3
          local.get 113
          local.set 13
          local.get 110
          local.set 14
          local.get 105
          local.set 15
        end
        ref.null eq
        local.set 105
        loop ;; label = @3
          local.get 13
          local.set 126
          local.get 14
          local.set 132
          local.get 15
          local.set 130
          local.get 79
          local.set 113
          local.get 88
          local.set 110
          local.get 81
          local.set 105
          local.get 16
          i32.const 1
          i32.eq
          if ;; label = @4
            br 3 (;@1;)
          end
          i32.const 3
          local.set 109
          i64.const 4616189618054758400
          local.set 92
          ref.null eq
          local.set 102
          local.get 16
          i32.const 1
          i32.eq
          if ;; label = @4
            br 3 (;@1;)
          end
          local.get 113
          i32.const 3
          i32.eq
          local.get 109
          i32.const 3
          i32.eq
          i32.and
          if ;; label = @4
            local.get 110
            f64.reinterpret_i64
            local.get 92
            f64.reinterpret_i64
            f64.lt
            local.set 131
          else
            local.get 22
            ref.as_non_null
            struct.get 110 0
            local.set 158
            local.get 113
            local.get 110
            local.get 105
            local.get 109
            local.get 92
            local.get 102
            local.get 158
            ref.as_non_null
            local.get 11
            local.get 26
            ref.as_non_null
            call 113
            local.set 114
            local.set 112
            local.set 89
            local.set 94
            local.set 82
            ref.null 161
            local.set 158
            ref.null eq
            local.set 102
            ref.null eq
            local.set 105
            local.get 112
            i32.const 1
            i32.eq
            if ;; label = @5
              local.get 82
              local.set 13
              local.get 94
              local.set 14
              local.get 89
              local.set 15
              local.get 112
              local.set 16
              local.get 114
              local.set 17
              br 4 (;@1;)
            end
            local.get 94
            f64.reinterpret_i64
            f64.const 0x0p+0 (;=0;)
            f64.lt
            local.set 131
          end
          ref.null eq
          local.set 89
          ref.null eq
          local.set 102
          ref.null eq
          local.set 105
          local.get 131
          local.get 16
          i32.const 1
          i32.eq
          if ;; label = @4
            br 3 (;@1;)
          end
          local.get 16
          i32.const 0
          i32.eq
          if ;; label = @4
            local.get 126
            local.set 13
            local.get 132
            local.set 14
            local.get 130
            local.set 15
          end
          ref.null eq
          local.set 130
          local.get 16
          i32.const 1
          i32.eq
          if ;; label = @4
            br 3 (;@1;)
          end
          i32.eqz
          br_if 1 (;@2;)
          block ;; label = @4
            i32.const 0
            local.set 13
            i64.const 0
            local.set 14
            ref.null eq
            local.set 15
            i32.const 0
            local.set 16
            i32.const 0
            local.set 17
            block ;; label = @5
              local.get 13
              local.set 91
              local.get 14
              local.set 104
              local.get 15
              local.set 119
              i32.const 3
              local.set 126
              i64.const 0
              local.set 132
              ref.null eq
              local.set 130
              local.get 16
              i32.const 1
              i32.eq
              if ;; label = @6
                br 5 (;@1;)
              end
              local.get 126
              local.set 75
              local.get 132
              local.set 76
              local.get 130
              local.set 77
              ref.null eq
              local.set 130
              local.get 16
              i32.const 1
              i32.eq
              if ;; label = @6
                br 5 (;@1;)
              end
              local.get 16
              i32.const 0
              i32.eq
              if ;; label = @6
                local.get 91
                local.set 13
                local.get 104
                local.set 14
                local.get 119
                local.set 15
              end
              ref.null eq
              local.set 119
              loop ;; label = @6
                local.get 13
                local.set 131
                local.get 14
                local.set 110
                local.get 15
                local.set 123
                local.get 75
                local.set 91
                local.get 76
                local.set 104
                local.get 77
                local.set 119
                local.get 16
                i32.const 1
                i32.eq
                if ;; label = @7
                  br 6 (;@1;)
                end
                local.get 98
                local.set 114
                local.get 99
                local.set 94
                local.get 100
                local.set 89
                local.get 16
                i32.const 1
                i32.eq
                if ;; label = @7
                  br 6 (;@1;)
                end
                local.get 114
                i32.const 4
                i32.eq
                if ;; label = @7
                  local.get 89
                  ref.cast (ref 131)
                  local.set 48
                  local.get 48
                  ref.as_non_null
                  struct.get 131 0
                  local.set 159
                  local.get 159
                  ref.as_non_null
                  array.len
                  i64.extend_i32_u
                  local.set 118
                  ref.null 132
                  local.set 159
                  local.get 118
                  f64.convert_i64_u
                  i64.reinterpret_f64
                  local.set 118
                  i32.const 3
                  local.set 126
                  local.get 118
                  local.set 132
                  ref.null eq
                  local.set 105
                  ref.null 131
                  local.set 48
                else
                  local.get 89
                  ref.test (ref 139)
                  if ;; label = @8
                    local.get 89
                    ref.cast (ref 139)
                    local.set 156
                    local.get 156
                    ref.as_non_null
                    struct.get 139 2
                    local.set 137
                    local.get 137
                    f64.convert_i64_u
                    i64.reinterpret_f64
                    local.set 137
                    i32.const 3
                    local.set 126
                    local.get 137
                    local.set 132
                    ref.null eq
                    local.set 105
                    ref.null 139
                    local.set 156
                  else
                    i32.const 140
                    local.set 90
                    local.get 90
                    call 108
                    local.set 145
                    i32.const 4
                    local.set 124
                    i64.const 0
                    local.set 118
                    local.get 145
                    ref.as_non_null
                    local.set 116
                    ref.null 131
                    local.set 145
                    local.get 114
                    local.get 94
                    local.get 89
                    local.get 114
                    local.get 94
                    local.get 89
                    local.get 124
                    local.get 118
                    local.get 116
                    local.get 11
                    local.get 26
                    ref.as_non_null
                    call 105
                    local.set 134
                    local.set 90
                    local.set 130
                    local.set 137
                    local.set 135
                    local.get 90
                    i32.const 1
                    i32.eq
                    if ;; label = @9
                      local.get 135
                      local.set 13
                      local.get 137
                      local.set 14
                      local.get 130
                      local.set 15
                      local.get 90
                      local.set 16
                      local.get 134
                      local.set 17
                    else
                      local.get 135
                      local.set 126
                      local.get 137
                      local.set 132
                      local.get 130
                      local.set 105
                    end
                    ref.null eq
                    local.set 130
                    ref.null eq
                    local.set 116
                    local.get 16
                    i32.const 1
                    i32.eq
                    if ;; label = @9
                      br 8 (;@1;)
                    end
                  end
                end
                ref.null eq
                local.set 89
                local.get 16
                i32.const 1
                i32.eq
                if ;; label = @7
                  br 6 (;@1;)
                end
                local.get 91
                i32.const 3
                i32.eq
                local.get 126
                i32.const 3
                i32.eq
                i32.and
                if ;; label = @7
                  local.get 104
                  f64.reinterpret_i64
                  local.get 132
                  f64.reinterpret_i64
                  f64.lt
                  local.set 112
                else
                  local.get 22
                  ref.as_non_null
                  struct.get 110 0
                  local.set 158
                  local.get 91
                  local.get 104
                  local.get 119
                  local.get 126
                  local.get 132
                  local.get 105
                  local.get 158
                  ref.as_non_null
                  local.get 11
                  local.get 26
                  ref.as_non_null
                  call 113
                  local.set 109
                  local.set 82
                  local.set 102
                  local.set 92
                  local.set 113
                  ref.null 161
                  local.set 158
                  ref.null eq
                  local.set 105
                  ref.null eq
                  local.set 119
                  local.get 82
                  i32.const 1
                  i32.eq
                  if ;; label = @8
                    local.get 113
                    local.set 13
                    local.get 92
                    local.set 14
                    local.get 102
                    local.set 15
                    local.get 82
                    local.set 16
                    local.get 109
                    local.set 17
                    br 7 (;@1;)
                  end
                  local.get 92
                  f64.reinterpret_i64
                  f64.const 0x0p+0 (;=0;)
                  f64.lt
                  local.set 112
                end
                ref.null eq
                local.set 102
                ref.null eq
                local.set 105
                ref.null eq
                local.set 119
                local.get 112
                local.get 16
                i32.const 1
                i32.eq
                if ;; label = @7
                  br 6 (;@1;)
                end
                local.get 16
                i32.const 0
                i32.eq
                if ;; label = @7
                  local.get 131
                  local.set 13
                  local.get 110
                  local.set 14
                  local.get 123
                  local.set 15
                end
                ref.null eq
                local.set 123
                local.get 16
                i32.const 1
                i32.eq
                if ;; label = @7
                  br 6 (;@1;)
                end
                i32.eqz
                br_if 1 (;@5;)
                block ;; label = @7
                  local.get 95
                  local.set 112
                  local.get 80
                  local.set 104
                  local.get 97
                  local.set 119
                  local.get 16
                  i32.const 1
                  i32.eq
                  if ;; label = @8
                    br 7 (;@1;)
                  end
                  local.get 98
                  local.set 135
                  local.get 99
                  local.set 137
                  local.get 100
                  local.set 130
                  local.get 16
                  i32.const 1
                  i32.eq
                  if ;; label = @8
                    br 7 (;@1;)
                  end
                  local.get 75
                  local.set 90
                  local.get 76
                  local.set 127
                  local.get 77
                  local.set 152
                  local.get 16
                  i32.const 1
                  i32.eq
                  if ;; label = @8
                    br 7 (;@1;)
                  end
                  i32.const 0
                  local.set 117
                  i64.const 0
                  local.set 115
                  ref.null eq
                  local.set 111
                  i32.const 0
                  local.set 136
                  i32.const 0
                  local.set 125
                  block ;; label = @8
                    block ;; label = @9
                      global.get 2
                      ref.as_non_null
                      local.set 158
                      local.get 158
                      ref.as_non_null
                      local.get 135
                      local.get 137
                      local.get 130
                      call 97
                      local.set 125
                      local.set 136
                      local.set 111
                      local.set 115
                      local.set 117
                      ref.null 161
                      local.set 158
                      local.get 136
                      i32.const 1
                      i32.eq
                      if ;; label = @10
                        br 1 (;@9;)
                      end
                      local.get 117
                      local.set 134
                      local.get 115
                      local.set 154
                      local.get 111
                      local.set 138
                      i32.const 0
                      local.set 162
                      local.get 90
                      i32.const 3
                      i32.eq
                      if ;; label = @10
                        local.get 138
                        ref.test (ref 139)
                        if ;; label = @11
                          local.get 127
                          f64.reinterpret_i64
                          f64.const 0x0p+0 (;=0;)
                          f64.ge
                          local.get 127
                          f64.reinterpret_i64
                          f64.const 0x1.fffffffep+31 (;=4294967295;)
                          f64.lt
                          i32.and
                          local.get 127
                          f64.reinterpret_i64
                          local.get 127
                          f64.reinterpret_i64
                          f64.trunc
                          f64.eq
                          i32.and
                          if ;; label = @12
                            local.get 127
                            f64.reinterpret_i64
                            i64.trunc_f64_u
                            local.set 129
                            local.get 138
                            ref.cast (ref 139)
                            local.set 156
                            local.get 156
                            ref.as_non_null
                            local.set 108
                            local.get 108
                            ref.as_non_null
                            struct.get 139 6
                            i32.const 2
                            i32.eq
                            local.get 108
                            ref.as_non_null
                            struct.get 139 6
                            i32.const 3
                            i32.eq
                            i32.or
                            if ;; label = @13
                              local.get 108
                              ref.as_non_null
                              struct.get 139 6
                              i32.const 3
                              i32.eq
                              if ;; label = @14
                                local.get 108
                                ref.as_non_null
                                struct.get 139 9
                                ref.as_non_null
                                local.set 165
                                local.get 129
                                local.get 165
                                ref.as_non_null
                                array.len
                                i64.extend_i32_u
                                i64.lt_u
                                if ;; label = @15
                                  local.get 129
                                  i32.wrap_i64
                                  local.set 166
                                  local.get 165
                                  ref.as_non_null
                                  local.get 166
                                  array.get 93
                                  local.set 70
                                  local.get 70
                                  ref.is_null
                                  i32.eqz
                                  if ;; label = @16
                                    local.get 70
                                    ref.as_non_null
                                    local.set 64
                                    local.get 64
                                    ref.as_non_null
                                    struct.get 62 1
                                    local.set 163
                                    local.get 64
                                    ref.as_non_null
                                    struct.get 62 0
                                    local.set 151
                                    local.get 64
                                    ref.as_non_null
                                    struct.get 62 2
                                    local.set 164
                                    ref.null 62
                                    local.set 64
                                    i32.const 1
                                    local.set 162
                                  end
                                  ref.null 62
                                  local.set 70
                                end
                                ref.null 93
                                local.set 165
                              else
                                local.get 108
                                ref.as_non_null
                                struct.get 139 7
                                local.set 121
                                local.get 108
                                ref.as_non_null
                                struct.get 139 8
                                local.set 122
                                local.get 129
                                local.get 121
                                ref.as_non_null
                                array.len
                                i64.extend_i32_u
                                i64.lt_u
                                if ;; label = @15
                                  local.get 129
                                  i32.wrap_i64
                                  local.set 166
                                  local.get 166
                                  i32.const 6
                                  i32.shr_u
                                  local.set 167
                                  i64.const 1
                                  local.get 166
                                  i64.extend_i32_u
                                  i64.shl
                                  local.set 168
                                  local.get 122
                                  ref.as_non_null
                                  local.get 167
                                  array.get 95
                                  local.set 169
                                  local.get 169
                                  local.get 168
                                  i64.and
                                  i64.eqz
                                  i32.eqz
                                  if ;; label = @16
                                    local.get 121
                                    ref.as_non_null
                                    local.get 166
                                    array.get 94
                                    local.set 169
                                    i32.const 3
                                    local.set 163
                                    local.get 169
                                    local.set 151
                                    ref.null eq
                                    local.set 164
                                    i32.const 1
                                    local.set 162
                                  end
                                end
                                ref.null 95
                                local.set 122
                                ref.null 94
                                local.set 121
                              end
                              local.get 162
                              if ;; label = @14
                                local.get 163
                                local.set 117
                                local.get 151
                                local.set 115
                                local.get 164
                                local.set 111
                                i32.const 0
                                local.set 136
                                i32.const 0
                                local.set 125
                              end
                              ref.null eq
                              local.set 164
                            end
                            ref.null 139
                            local.set 108
                            ref.null 139
                            local.set 156
                          end
                        end
                      end
                      local.get 162
                      br_if 0 (;@9;)
                      local.get 90
                      local.get 127
                      local.get 152
                      local.get 11
                      local.get 26
                      ref.as_non_null
                      call 106
                      local.set 161
                      local.set 160
                      local.set 93
                      local.set 155
                      local.set 87
                      local.get 160
                      i32.const 1
                      i32.eq
                      if ;; label = @10
                        local.get 87
                        local.set 117
                        local.get 155
                        local.set 115
                        local.get 93
                        local.set 111
                        local.get 160
                        local.set 136
                        local.get 161
                        local.set 125
                        br 1 (;@9;)
                      end
                      local.get 87
                      local.set 167
                      local.get 155
                      local.set 169
                      local.get 93
                      local.set 164
                      local.get 134
                      local.get 154
                      local.get 138
                      local.get 135
                      local.get 137
                      local.get 130
                      local.get 167
                      local.get 169
                      local.get 164
                      local.get 11
                      local.get 26
                      ref.as_non_null
                      call 85
                      local.set 125
                      local.set 136
                      local.set 111
                      local.set 115
                      local.set 117
                      local.get 136
                      i32.const 1
                      i32.eq
                      if ;; label = @10
                        br 1 (;@9;)
                      end
                    end
                    ref.null eq
                    local.set 93
                    ref.null eq
                    local.set 164
                    ref.null eq
                    local.set 138
                  end
                  local.get 117
                  local.set 13
                  local.get 115
                  local.set 14
                  local.get 111
                  local.set 15
                  local.get 136
                  local.set 16
                  local.get 125
                  local.set 17
                  local.get 136
                  i32.const 0
                  i32.eq
                  if ;; label = @8
                    local.get 117
                    local.set 124
                    local.get 115
                    local.set 118
                    local.get 111
                    local.set 116
                  end
                  ref.null eq
                  local.set 111
                  ref.null eq
                  local.set 152
                  ref.null eq
                  local.set 130
                  local.get 16
                  i32.const 1
                  i32.eq
                  if ;; label = @8
                    br 7 (;@1;)
                  end
                  local.get 16
                  i32.const 1
                  i32.eq
                  if ;; label = @8
                    br 7 (;@1;)
                  end
                  i32.const 255
                  local.set 90
                  local.get 90
                  call 108
                  local.set 145
                  i32.const 4
                  local.set 162
                  i64.const 0
                  local.set 129
                  local.get 145
                  ref.as_non_null
                  local.set 93
                  ref.null 131
                  local.set 145
                  local.get 16
                  i32.const 1
                  i32.eq
                  if ;; label = @8
                    br 7 (;@1;)
                  end
                  i32.const 0
                  local.set 135
                  i64.const 0
                  local.set 127
                  ref.null eq
                  local.set 130
                  i32.const 0
                  local.set 90
                  i32.const 0
                  local.set 117
                  block ;; label = @8
                    block ;; label = @9
                      i32.const 1
                      local.set 128
                      local.get 93
                      ref.cast (ref 131)
                      local.set 48
                      i32.const 4
                      local.set 87
                      i64.const 0
                      local.set 169
                      local.get 48
                      ref.as_non_null
                      local.set 138
                      ref.null 131
                      local.set 48
                      i32.const 0
                      local.set 160
                      ref.null 69
                      local.set 54
                      local.get 116
                      ref.test (ref 69)
                      if ;; label = @10
                        local.get 116
                        ref.cast (ref 69)
                        local.set 54
                      else
                        local.get 116
                        ref.test (ref 107)
                        if ;; label = @11
                          local.get 116
                          ref.cast (ref 107)
                          local.set 52
                          local.get 52
                          ref.as_non_null
                          struct.get 107 0
                          local.set 153
                          local.get 153
                          ref.as_non_null
                          struct.get 69 1
                          local.set 148
                          local.get 148
                          ref.as_non_null
                          ref.test (ref 77)
                          if ;; label = @12
                            local.get 153
                            ref.as_non_null
                            local.set 54
                          end
                          ref.null 76
                          local.set 148
                          ref.null 69
                          local.set 153
                          ref.null 107
                          local.set 52
                        end
                      end
                      local.get 54
                      ref.is_null
                      i32.eqz
                      if ;; label = @10
                        local.get 54
                        ref.as_non_null
                        local.set 153
                        local.get 153
                        ref.as_non_null
                        struct.get 69 1
                        local.set 148
                        local.get 148
                        ref.as_non_null
                        ref.test (ref 77)
                        if ;; label = @11
                          local.get 148
                          ref.as_non_null
                          ref.cast (ref 77)
                          local.set 149
                          local.get 170
                          ref.is_null
                          if ;; label = @12
                            local.get 26
                            ref.as_non_null
                            struct.get 109 12
                            local.set 171
                            local.get 128
                            i32.const 6
                            i32.shr_u
                            local.set 161
                            i32.const 0
                            local.set 163
                            local.get 171
                            ref.is_null
                            i32.eqz
                            if ;; label = @13
                              local.get 171
                              array.len
                              local.set 163
                            end
                            local.get 161
                            local.get 163
                            i32.ge_u
                            if ;; label = @13
                              local.get 161
                              i32.const 1
                              i32.add
                              local.set 173
                              local.get 163
                              i32.const 1
                              i32.shl
                              local.set 172
                              local.get 172
                              i32.const 8
                              i32.lt_u
                              if ;; label = @14
                                i32.const 8
                                local.set 172
                              end
                              local.get 172
                              local.get 173
                              i32.lt_u
                              if ;; label = @14
                                local.get 173
                                local.set 172
                              end
                              ref.null 88
                              local.get 172
                              array.new 89
                              local.set 174
                              local.get 163
                              if ;; label = @14
                                local.get 171
                                ref.as_non_null
                                local.set 175
                                local.get 174
                                ref.as_non_null
                                i32.const 0
                                local.get 175
                                ref.as_non_null
                                i32.const 0
                                local.get 163
                                array.copy 89 89
                                ref.null 89
                                local.set 175
                              end
                              local.get 26
                              ref.as_non_null
                              local.get 174
                              ref.as_non_null
                              struct.set 109 12
                              local.get 174
                              ref.as_non_null
                              local.set 171
                              ref.null 89
                              local.set 174
                            end
                            local.get 171
                            local.get 161
                            array.get 89
                            local.set 176
                            local.get 176
                            ref.is_null
                            if ;; label = @13
                              i32.const 64
                              local.set 172
                              ref.null 87
                              local.get 172
                              array.new 88
                              local.set 177
                              local.get 171
                              local.get 161
                              local.get 177
                              ref.as_non_null
                              array.set 89
                              local.get 177
                              ref.as_non_null
                              local.set 176
                              ref.null 88
                              local.set 177
                            end
                            local.get 176
                            ref.as_non_null
                            local.set 177
                            local.get 128
                            i32.const 63
                            i32.and
                            local.set 178
                            ref.null 88
                            local.set 176
                            ref.null 89
                            local.set 171
                            local.get 177
                            ref.as_non_null
                            local.get 178
                            array.get 88
                            local.set 179
                            local.get 179
                            ref.is_null
                            if ;; label = @13
                              local.get 138
                              ref.cast (ref 131)
                              local.set 48
                              local.get 48
                              ref.as_non_null
                              ref.null 80
                              i32.const 0
                              struct.new 87
                              local.set 180
                              local.get 177
                              ref.as_non_null
                              local.get 178
                              local.get 180
                              ref.as_non_null
                              array.set 88
                              local.get 180
                              ref.as_non_null
                              local.set 179
                              ref.null 87
                              local.set 180
                              ref.null 131
                              local.set 48
                            end
                            local.get 179
                            ref.as_non_null
                            local.set 180
                            ref.null 87
                            local.set 179
                            ref.null 88
                            local.set 177
                            local.get 180
                            ref.as_non_null
                            local.set 170
                            ref.null 87
                            local.set 180
                          end
                          local.get 170
                          ref.as_non_null
                          local.set 179
                          local.get 149
                          ref.as_non_null
                          struct.get 77 0
                          local.set 144
                          local.get 179
                          ref.as_non_null
                          struct.get 87 1
                          local.set 147
                          local.get 179
                          ref.as_non_null
                          struct.get 87 0
                          local.set 145
                          local.get 144
                          ref.as_non_null
                          local.get 147
                          ref.eq
                          local.get 145
                          ref.as_non_null
                          local.get 138
                          ref.eq
                          i32.and
                          if ;; label = @12
                            local.get 179
                            ref.as_non_null
                            struct.get 87 2
                            local.set 178
                            local.get 149
                            ref.as_non_null
                            ref.test (ref 79)
                            if ;; label = @13
                              local.get 149
                              ref.as_non_null
                              ref.cast (ref 79)
                              local.set 181
                              local.get 181
                              ref.as_non_null
                              struct.get 79 0
                              local.set 182
                              local.get 182
                              ref.as_non_null
                              struct.get 80 0
                              local.set 146
                              local.get 178
                              local.get 146
                              ref.as_non_null
                              array.len
                              i32.ge_u
                              local.get 178
                              i32.const 2
                              i32.ge_u
                              i32.or
                              if ;; label = @14
                                unreachable
                              end
                              ref.null 83
                              local.set 146
                              ref.null 80
                              local.set 182
                              local.get 181
                              ref.as_non_null
                              struct.get 79 1
                              local.set 161
                              local.get 161
                              local.get 178
                              i32.const 8
                              i32.mul
                              i32.shr_u
                              i32.const 255
                              i32.and
                              local.set 161
                              local.get 178
                              i32.eqz
                              if ;; label = @14
                                local.get 181
                                ref.as_non_null
                                struct.get 79 2
                                local.set 151
                                local.get 181
                                ref.as_non_null
                                struct.get 79 4
                                local.set 164
                              else
                                local.get 181
                                ref.as_non_null
                                struct.get 79 3
                                local.set 151
                                local.get 181
                                ref.as_non_null
                                struct.get 79 5
                                local.set 164
                              end
                              ref.null 79
                              local.set 181
                            else
                              local.get 149
                              ref.as_non_null
                              ref.cast (ref 78)
                              local.set 183
                              local.get 183
                              ref.as_non_null
                              struct.get 78 1
                              local.set 184
                              local.get 183
                              ref.as_non_null
                              struct.get 78 2
                              local.set 185
                              local.get 183
                              ref.as_non_null
                              struct.get 78 3
                              local.set 186
                              local.get 184
                              ref.as_non_null
                              local.get 178
                              array.get_u 84
                              local.set 161
                              i64.const 0
                              local.set 151
                              local.get 185
                              ref.is_null
                              i32.eqz
                              if ;; label = @14
                                local.get 185
                                ref.as_non_null
                                local.set 187
                                local.get 187
                                ref.as_non_null
                                local.get 178
                                array.get 85
                                local.set 151
                                ref.null 85
                                local.set 187
                              end
                              ref.null eq
                              local.set 164
                              local.get 186
                              ref.is_null
                              i32.eqz
                              if ;; label = @14
                                local.get 186
                                ref.as_non_null
                                local.set 188
                                local.get 188
                                ref.as_non_null
                                local.get 178
                                array.get 86
                                local.set 164
                                ref.null 86
                                local.set 188
                              end
                              ref.null 86
                              local.set 186
                              ref.null 85
                              local.set 185
                              ref.null 84
                              local.set 184
                              ref.null 78
                              local.set 183
                            end
                            local.get 161
                            local.set 135
                            local.get 151
                            local.set 127
                            local.get 164
                            local.set 130
                            i32.const 0
                            local.set 90
                            i32.const 0
                            local.set 117
                            i32.const 1
                            local.set 160
                            ref.null eq
                            local.set 164
                          end
                          ref.null 131
                          local.set 145
                          ref.null 80
                          local.set 147
                          ref.null 80
                          local.set 144
                          ref.null 87
                          local.set 179
                          ref.null 77
                          local.set 149
                        end
                        ref.null 76
                        local.set 148
                        ref.null 69
                        local.set 153
                      end
                      ref.null 69
                      local.set 54
                      local.get 160
                      i32.eqz
                      if ;; label = @10
                        local.get 124
                        local.get 118
                        local.get 116
                        local.get 124
                        local.get 118
                        local.get 116
                        local.get 87
                        local.get 169
                        local.get 138
                        local.get 128
                        local.get 11
                        local.get 26
                        ref.as_non_null
                        call 92
                        local.set 117
                        local.set 90
                        local.set 130
                        local.set 127
                        local.set 135
                      end
                      ref.null eq
                      local.set 138
                    end
                    ref.null eq
                    local.set 152
                    ref.null eq
                    local.set 111
                  end
                  local.get 135
                  local.set 13
                  local.get 127
                  local.set 14
                  local.get 130
                  local.set 15
                  local.get 90
                  local.set 16
                  local.get 117
                  local.set 17
                  local.get 90
                  i32.const 0
                  i32.eq
                  if ;; label = @8
                    local.get 135
                    local.set 91
                    local.get 127
                    local.set 94
                    local.get 130
                    local.set 89
                  end
                  ref.null eq
                  local.set 130
                  ref.null eq
                  local.set 93
                  ref.null eq
                  local.set 116
                  local.get 16
                  i32.const 1
                  i32.eq
                  if ;; label = @8
                    br 7 (;@1;)
                  end
                  local.get 16
                  i32.const 1
                  i32.eq
                  if ;; label = @8
                    br 7 (;@1;)
                  end
                  local.get 79
                  local.set 163
                  local.get 88
                  local.set 155
                  local.get 81
                  local.set 164
                  local.get 16
                  i32.const 1
                  i32.eq
                  if ;; label = @8
                    br 7 (;@1;)
                  end
                  i32.const 0
                  local.set 124
                  i64.const 0
                  local.set 118
                  ref.null eq
                  local.set 116
                  i32.const 0
                  local.set 162
                  i32.const 0
                  local.set 135
                  block ;; label = @8
                    block ;; label = @9
                      global.get 2
                      ref.as_non_null
                      local.set 41
                      local.get 41
                      ref.as_non_null
                      local.get 91
                      local.get 94
                      local.get 89
                      call 97
                      local.set 135
                      local.set 162
                      local.set 116
                      local.set 118
                      local.set 124
                      ref.null 161
                      local.set 41
                      local.get 162
                      i32.const 1
                      i32.eq
                      if ;; label = @10
                        br 1 (;@9;)
                      end
                      local.get 124
                      local.set 90
                      local.get 118
                      local.set 129
                      local.get 116
                      local.set 130
                      i32.const 0
                      local.set 166
                      local.get 163
                      i32.const 3
                      i32.eq
                      if ;; label = @10
                        local.get 130
                        ref.test (ref 139)
                        if ;; label = @11
                          local.get 155
                          f64.reinterpret_i64
                          f64.const 0x0p+0 (;=0;)
                          f64.ge
                          local.get 155
                          f64.reinterpret_i64
                          f64.const 0x1.fffffffep+31 (;=4294967295;)
                          f64.lt
                          i32.and
                          local.get 155
                          f64.reinterpret_i64
                          local.get 155
                          f64.reinterpret_i64
                          f64.trunc
                          f64.eq
                          i32.and
                          if ;; label = @12
                            local.get 155
                            f64.reinterpret_i64
                            i64.trunc_f64_u
                            local.set 168
                            local.get 130
                            ref.cast (ref 139)
                            local.set 108
                            local.get 108
                            ref.as_non_null
                            local.set 156
                            local.get 156
                            ref.as_non_null
                            struct.get 139 6
                            i32.const 2
                            i32.eq
                            local.get 156
                            ref.as_non_null
                            struct.get 139 6
                            i32.const 3
                            i32.eq
                            i32.or
                            if ;; label = @13
                              local.get 156
                              ref.as_non_null
                              struct.get 139 6
                              i32.const 3
                              i32.eq
                              if ;; label = @14
                                local.get 156
                                ref.as_non_null
                                struct.get 139 9
                                ref.as_non_null
                                local.set 165
                                local.get 168
                                local.get 165
                                ref.as_non_null
                                array.len
                                i64.extend_i32_u
                                i64.lt_u
                                if ;; label = @15
                                  local.get 168
                                  i32.wrap_i64
                                  local.set 87
                                  local.get 165
                                  ref.as_non_null
                                  local.get 87
                                  array.get 93
                                  local.set 72
                                  local.get 72
                                  ref.is_null
                                  i32.eqz
                                  if ;; label = @16
                                    local.get 72
                                    ref.as_non_null
                                    local.set 70
                                    local.get 70
                                    ref.as_non_null
                                    struct.get 62 1
                                    local.set 167
                                    local.get 70
                                    ref.as_non_null
                                    struct.get 62 0
                                    local.set 137
                                    local.get 70
                                    ref.as_non_null
                                    struct.get 62 2
                                    local.set 152
                                    ref.null 62
                                    local.set 70
                                    i32.const 1
                                    local.set 166
                                  end
                                  ref.null 62
                                  local.set 72
                                end
                                ref.null 93
                                local.set 165
                              else
                                local.get 156
                                ref.as_non_null
                                struct.get 139 7
                                local.set 121
                                local.get 156
                                ref.as_non_null
                                struct.get 139 8
                                local.set 122
                                local.get 168
                                local.get 121
                                ref.as_non_null
                                array.len
                                i64.extend_i32_u
                                i64.lt_u
                                if ;; label = @15
                                  local.get 168
                                  i32.wrap_i64
                                  local.set 128
                                  local.get 128
                                  i32.const 6
                                  i32.shr_u
                                  local.set 134
                                  i64.const 1
                                  local.get 128
                                  i64.extend_i32_u
                                  i64.shl
                                  local.set 169
                                  local.get 122
                                  ref.as_non_null
                                  local.get 134
                                  array.get 95
                                  local.set 154
                                  local.get 154
                                  local.get 169
                                  i64.and
                                  i64.eqz
                                  i32.eqz
                                  if ;; label = @16
                                    local.get 121
                                    ref.as_non_null
                                    local.get 128
                                    array.get 94
                                    local.set 154
                                    i32.const 3
                                    local.set 167
                                    local.get 154
                                    local.set 137
                                    ref.null eq
                                    local.set 152
                                    i32.const 1
                                    local.set 166
                                  end
                                end
                                ref.null 95
                                local.set 122
                                ref.null 94
                                local.set 121
                              end
                              local.get 166
                              if ;; label = @14
                                local.get 167
                                local.set 124
                                local.get 137
                                local.set 118
                                local.get 152
                                local.set 116
                                i32.const 0
                                local.set 162
                                i32.const 0
                                local.set 135
                              end
                              ref.null eq
                              local.set 152
                            end
                            ref.null 139
                            local.set 156
                            ref.null 139
                            local.set 108
                          end
                        end
                      end
                      local.get 166
                      br_if 0 (;@9;)
                      local.get 163
                      local.get 155
                      local.get 164
                      local.get 11
                      local.get 26
                      ref.as_non_null
                      call 106
                      local.set 125
                      local.set 136
                      local.set 93
                      local.set 115
                      local.set 117
                      local.get 136
                      i32.const 1
                      i32.eq
                      if ;; label = @10
                        local.get 117
                        local.set 124
                        local.get 115
                        local.set 118
                        local.get 93
                        local.set 116
                        local.get 136
                        local.set 162
                        local.get 125
                        local.set 135
                        br 1 (;@9;)
                      end
                      local.get 117
                      local.set 160
                      local.get 115
                      local.set 103
                      local.get 93
                      local.set 138
                      local.get 90
                      local.get 129
                      local.get 130
                      local.get 91
                      local.get 94
                      local.get 89
                      local.get 160
                      local.get 103
                      local.get 138
                      local.get 11
                      local.get 26
                      ref.as_non_null
                      call 85
                      local.set 135
                      local.set 162
                      local.set 116
                      local.set 118
                      local.set 124
                      local.get 162
                      i32.const 1
                      i32.eq
                      if ;; label = @10
                        br 1 (;@9;)
                      end
                    end
                    ref.null eq
                    local.set 93
                    ref.null eq
                    local.set 138
                    ref.null eq
                    local.set 130
                  end
                  local.get 124
                  local.set 13
                  local.get 118
                  local.set 14
                  local.get 116
                  local.set 15
                  local.get 162
                  local.set 16
                  local.get 135
                  local.set 17
                  local.get 162
                  i32.const 0
                  i32.eq
                  if ;; label = @8
                    local.get 124
                    local.set 126
                    local.get 118
                    local.set 132
                    local.get 116
                    local.set 105
                  end
                  ref.null eq
                  local.set 116
                  ref.null eq
                  local.set 164
                  ref.null eq
                  local.set 89
                  local.get 16
                  i32.const 1
                  i32.eq
                  if ;; label = @8
                    br 7 (;@1;)
                  end
                  local.get 16
                  i32.const 1
                  i32.eq
                  if ;; label = @8
                    br 7 (;@1;)
                  end
                  local.get 112
                  i32.const 3
                  i32.eq
                  local.get 126
                  i32.const 3
                  i32.eq
                  i32.and
                  if ;; label = @8
                    local.get 104
                    f64.reinterpret_i64
                    local.get 132
                    f64.reinterpret_i64
                    f64.add
                    i64.reinterpret_f64
                    local.set 92
                    i32.const 3
                    local.set 113
                    local.get 92
                    local.set 92
                    ref.null eq
                    local.set 102
                    local.get 113
                    local.set 113
                    local.get 92
                    local.set 92
                    local.get 102
                    local.set 102
                    i32.const 0
                    local.set 109
                    i32.const 0
                    local.set 82
                  else
                    local.get 22
                    ref.as_non_null
                    struct.get 110 0
                    local.set 158
                    local.get 112
                    local.get 104
                    local.get 119
                    local.get 126
                    local.get 132
                    local.get 105
                    local.get 158
                    ref.as_non_null
                    local.get 11
                    local.get 26
                    ref.as_non_null
                    call 104
                    local.set 82
                    local.set 109
                    local.set 102
                    local.set 92
                    local.set 113
                    ref.null 161
                    local.set 158
                  end
                  ref.null eq
                  local.set 105
                  ref.null eq
                  local.set 119
                  local.get 109
                  i32.const 1
                  i32.eq
                  if ;; label = @8
                    local.get 113
                    local.set 13
                    local.get 92
                    local.set 14
                    local.get 102
                    local.set 15
                    local.get 109
                    local.set 16
                    local.get 82
                    local.set 17
                    br 7 (;@1;)
                  end
                  local.get 113
                  local.set 131
                  local.get 92
                  local.set 110
                  local.get 102
                  local.set 123
                  ref.null eq
                  local.set 102
                  local.get 16
                  i32.const 1
                  i32.eq
                  if ;; label = @8
                    br 7 (;@1;)
                  end
                  local.get 131
                  local.set 95
                  local.get 110
                  local.set 80
                  local.get 123
                  local.set 97
                  local.get 131
                  local.set 114
                  local.get 110
                  local.set 96
                  local.get 123
                  local.set 133
                  ref.null eq
                  local.set 123
                  local.get 16
                  i32.const 1
                  i32.eq
                  if ;; label = @8
                    br 7 (;@1;)
                  end
                  local.get 16
                  i32.const 1
                  i32.eq
                  if ;; label = @8
                    br 7 (;@1;)
                  end
                  local.get 114
                  local.set 13
                  local.get 96
                  local.set 14
                  local.get 133
                  local.set 15
                  i32.const 0
                  local.set 16
                  i32.const 0
                  local.set 17
                  ref.null eq
                  local.set 133
                end
                local.get 13
                local.set 91
                local.get 14
                local.set 168
                local.get 15
                local.set 111
                local.get 75
                local.set 131
                local.get 76
                local.set 110
                local.get 77
                local.set 123
                local.get 131
                i32.const 3
                i32.ne
                if ;; label = @7
                  i32.const 0
                  local.set 109
                  i64.const 0
                  local.set 104
                  ref.null eq
                  local.set 119
                  i32.const 0
                  local.set 126
                  i32.const 0
                  local.set 166
                  local.get 131
                  local.get 110
                  local.get 123
                  local.get 11
                  local.get 26
                  ref.as_non_null
                  call 103
                  local.set 166
                  local.set 126
                  local.set 119
                  local.set 104
                  local.set 109
                  local.get 109
                  local.set 13
                  local.get 104
                  local.set 14
                  local.get 119
                  local.set 15
                  local.get 126
                  local.set 16
                  local.get 166
                  local.set 17
                  local.get 16
                  i32.const 1
                  i32.eq
                  if ;; label = @8
                    br 7 (;@1;)
                  end
                  local.get 109
                  local.set 131
                  local.get 104
                  local.set 110
                  local.get 119
                  local.set 123
                  ref.null eq
                  local.set 119
                end
                local.get 110
                f64.reinterpret_i64
                f64.const 0x1p+0 (;=1;)
                f64.add
                i64.reinterpret_f64
                local.set 92
                i32.const 3
                local.set 113
                local.get 92
                local.set 92
                ref.null eq
                local.set 102
                local.get 113
                local.set 75
                local.get 92
                local.set 76
                local.get 102
                local.set 77
                local.get 131
                local.set 114
                local.get 110
                local.set 96
                local.get 123
                local.set 133
                ref.null eq
                local.set 102
                ref.null eq
                local.set 123
                local.get 16
                i32.const 1
                i32.eq
                if ;; label = @7
                  br 6 (;@1;)
                end
                ref.null eq
                local.set 133
                local.get 16
                i32.const 1
                i32.eq
                if ;; label = @7
                  br 6 (;@1;)
                end
                local.get 16
                i32.const 0
                i32.eq
                if ;; label = @7
                  local.get 91
                  local.set 13
                  local.get 168
                  local.set 14
                  local.get 111
                  local.set 15
                end
                ref.null eq
                local.set 111
                br 0 (;@6;)
              end
            end
          end
          local.get 13
          local.set 173
          local.get 14
          local.set 132
          local.get 15
          local.set 105
          local.get 79
          local.set 114
          local.get 88
          local.set 96
          local.get 81
          local.set 133
          local.get 114
          i32.const 3
          i32.ne
          if ;; label = @4
            i32.const 0
            local.set 113
            i64.const 0
            local.set 92
            ref.null eq
            local.set 102
            i32.const 0
            local.set 109
            i32.const 0
            local.set 126
            local.get 114
            local.get 96
            local.get 133
            local.get 11
            local.get 26
            ref.as_non_null
            call 103
            local.set 126
            local.set 109
            local.set 102
            local.set 92
            local.set 113
            local.get 113
            local.set 13
            local.get 92
            local.set 14
            local.get 102
            local.set 15
            local.get 109
            local.set 16
            local.get 126
            local.set 17
            local.get 16
            i32.const 1
            i32.eq
            if ;; label = @5
              br 4 (;@1;)
            end
            local.get 113
            local.set 114
            local.get 92
            local.set 96
            local.get 102
            local.set 133
            ref.null eq
            local.set 102
          end
          local.get 96
          f64.reinterpret_i64
          f64.const 0x1p+0 (;=1;)
          f64.add
          i64.reinterpret_f64
          local.set 110
          i32.const 3
          local.set 131
          local.get 110
          local.set 110
          ref.null eq
          local.set 123
          local.get 131
          local.set 79
          local.get 110
          local.set 88
          local.get 123
          local.set 81
          local.get 114
          local.set 91
          local.get 96
          local.set 168
          local.get 133
          local.set 111
          ref.null eq
          local.set 123
          ref.null eq
          local.set 133
          local.get 16
          i32.const 1
          i32.eq
          if ;; label = @4
            br 3 (;@1;)
          end
          ref.null eq
          local.set 111
          local.get 16
          i32.const 1
          i32.eq
          if ;; label = @4
            br 3 (;@1;)
          end
          local.get 16
          i32.const 0
          i32.eq
          if ;; label = @4
            local.get 173
            local.set 13
            local.get 132
            local.set 14
            local.get 105
            local.set 15
          end
          ref.null eq
          local.set 105
          br 0 (;@3;)
        end
      end
      i32.const 845
      local.set 131
      local.get 131
      call 108
      local.set 48
      local.get 11
      ref.as_non_null
      local.set 106
      local.get 106
      ref.as_non_null
      local.set 107
      ref.null 120
      local.set 86
      block ;; label = @2
        loop ;; label = @3
          local.get 107
          ref.as_non_null
          struct.get 120 3
          local.set 86
          local.get 86
          ref.is_null
          br_if 1 (;@2;)
          local.get 86
          ref.as_non_null
          local.set 107
          br 0 (;@3;)
        end
      end
      ref.null 120
      local.set 86
      ref.null 120
      local.set 106
      local.get 22
      ref.as_non_null
      struct.get 110 0
      local.set 41
      local.get 48
      ref.as_non_null
      local.get 107
      ref.as_non_null
      local.get 41
      ref.as_non_null
      local.get 11
      local.get 26
      ref.as_non_null
      call 111
      local.set 17
      local.set 16
      local.set 15
      local.set 14
      local.set 13
      ref.null 161
      local.set 41
      ref.null 120
      local.set 107
      ref.null 131
      local.set 48
      local.get 16
      i32.const 1
      i32.eq
      if ;; label = @2
        br 1 (;@1;)
      end
      local.get 13
      local.set 173
      local.get 14
      local.set 132
      local.get 15
      local.set 105
      local.get 16
      i32.const 1
      i32.eq
      if ;; label = @2
        br 1 (;@1;)
      end
      local.get 16
      i32.const 1
      i32.eq
      if ;; label = @2
        br 1 (;@1;)
      end
      i32.const 0
      local.set 91
      i64.const 0
      local.set 168
      ref.null eq
      local.set 111
      local.get 91
      local.set 131
      local.get 168
      local.set 110
      local.get 111
      local.set 123
      i32.const 186
      local.set 163
      local.get 163
      call 108
      local.set 48
      local.get 11
      ref.as_non_null
      local.set 107
      local.get 107
      ref.as_non_null
      local.set 86
      ref.null 120
      local.set 106
      block ;; label = @2
        loop ;; label = @3
          local.get 86
          ref.as_non_null
          struct.get 120 3
          local.set 106
          local.get 106
          ref.is_null
          br_if 1 (;@2;)
          local.get 106
          ref.as_non_null
          local.set 86
          br 0 (;@3;)
        end
      end
      ref.null 120
      local.set 106
      ref.null 120
      local.set 107
      local.get 22
      ref.as_non_null
      struct.get 110 0
      local.set 41
      local.get 48
      ref.as_non_null
      local.get 86
      ref.as_non_null
      local.get 41
      ref.as_non_null
      local.get 11
      local.get 26
      ref.as_non_null
      call 111
      local.set 17
      local.set 16
      local.set 15
      local.set 14
      local.set 13
      ref.null 161
      local.set 41
      ref.null 120
      local.set 86
      ref.null 131
      local.set 48
      local.get 16
      i32.const 1
      i32.eq
      if ;; label = @2
        br 1 (;@1;)
      end
      local.get 13
      local.set 114
      local.get 14
      local.set 92
      local.get 15
      local.set 102
      local.get 16
      i32.const 1
      i32.eq
      if ;; label = @2
        br 1 (;@1;)
      end
      local.get 16
      i32.const 1
      i32.eq
      if ;; label = @2
        br 1 (;@1;)
      end
      i32.const 0
      local.set 126
      i64.const 0
      local.set 94
      ref.null eq
      local.set 89
      local.get 126
      local.set 163
      local.get 94
      local.set 155
      local.get 89
      local.set 164
      local.get 95
      local.set 124
      local.get 80
      local.set 118
      local.get 97
      local.set 116
      local.get 16
      i32.const 1
      i32.eq
      if ;; label = @2
        br 1 (;@1;)
      end
      local.get 16
      i32.const 1
      i32.eq
      if ;; label = @2
        br 1 (;@1;)
      end
      local.get 118
      local.get 124
      local.get 116
      struct.new 62
      local.set 72
      ref.null eq
      local.set 116
      ref.null eq
      local.set 116
      local.get 72
      ref.as_non_null
      array.new_fixed 99 1
      local.set 27
      ref.null 62
      local.set 72
      global.get 2
      ref.as_non_null
      local.set 41
      local.get 114
      local.get 92
      local.get 102
      local.get 163
      local.get 155
      local.get 164
      local.get 27
      ref.as_non_null
      local.get 41
      ref.as_non_null
      local.get 11
      local.get 26
      ref.as_non_null
      call 101
      local.set 172
      local.set 124
      local.set 152
      local.set 151
      local.set 135
      local.get 41
      ref.as_non_null
      global.set 2
      ref.null 161
      local.set 41
      local.get 124
      i32.const 2
      i32.eq
      if ;; label = @2
        local.get 135
        local.set 135
        local.get 151
        local.set 151
        local.get 152
        local.set 152
        i32.const 0
        local.set 124
        i32.const 0
        local.set 172
      end
      local.get 124
      i32.const 1
      i32.eq
      if ;; label = @2
        local.get 135
        local.set 13
        local.get 151
        local.set 14
        local.get 152
        local.set 15
        local.get 124
        local.set 16
        local.get 172
        local.set 17
      end
      local.get 16
      i32.const 1
      i32.eq
      if ;; label = @2
        br 1 (;@1;)
      end
      local.get 135
      local.set 113
      local.get 151
      local.set 96
      local.get 152
      local.set 133
      ref.null eq
      local.set 152
      ref.null 99
      local.set 27
      ref.null eq
      local.set 164
      ref.null eq
      local.set 89
      ref.null eq
      local.set 102
      local.get 16
      i32.const 1
      i32.eq
      if ;; label = @2
        br 1 (;@1;)
      end
      local.get 16
      i32.const 1
      i32.eq
      if ;; label = @2
        br 1 (;@1;)
      end
      local.get 96
      local.get 113
      local.get 133
      struct.new 62
      local.set 72
      ref.null eq
      local.set 133
      ref.null eq
      local.set 133
      local.get 72
      ref.as_non_null
      array.new_fixed 99 1
      local.set 27
      ref.null 62
      local.set 72
      global.get 2
      ref.as_non_null
      local.set 158
      local.get 173
      local.get 132
      local.get 105
      local.get 131
      local.get 110
      local.get 123
      local.get 27
      ref.as_non_null
      local.get 158
      ref.as_non_null
      local.get 11
      local.get 26
      ref.as_non_null
      call 101
      local.set 162
      local.set 90
      local.set 116
      local.set 127
      local.set 114
      local.get 158
      ref.as_non_null
      global.set 2
      ref.null 161
      local.set 158
      local.get 90
      i32.const 2
      i32.eq
      if ;; label = @2
        local.get 114
        local.set 114
        local.get 127
        local.set 127
        local.get 116
        local.set 116
        i32.const 0
        local.set 90
        i32.const 0
        local.set 162
      end
      local.get 90
      i32.const 1
      i32.eq
      if ;; label = @2
        local.get 114
        local.set 13
        local.get 127
        local.set 14
        local.get 116
        local.set 15
        local.get 90
        local.set 16
        local.get 162
        local.set 17
      end
      local.get 16
      i32.const 1
      i32.eq
      if ;; label = @2
        br 1 (;@1;)
      end
      local.get 114
      local.set 166
      local.get 127
      local.set 104
      local.get 116
      local.set 119
      ref.null eq
      local.set 116
      ref.null 99
      local.set 27
      ref.null eq
      local.set 123
      ref.null eq
      local.set 111
      ref.null eq
      local.set 105
      local.get 16
      i32.const 1
      i32.eq
      if ;; label = @2
        br 1 (;@1;)
      end
      local.get 16
      i32.const 1
      i32.eq
      if ;; label = @2
        br 1 (;@1;)
      end
      local.get 166
      local.set 13
      local.get 104
      local.set 14
      local.get 119
      local.set 15
      i32.const 0
      local.set 16
      i32.const 0
      local.set 17
      ref.null eq
      local.set 119
      i32.const 0
      local.set 13
      i64.const 0
      local.set 14
      ref.null eq
      local.set 15
    end
    local.get 57
    ref.is_null
    i32.eqz
    if ;; label = @1
      local.get 57
      ref.as_non_null
      local.set 60
      local.get 60
      ref.as_non_null
      struct.get 108 0
      local.set 66
      local.get 66
      ref.is_null
      i32.eqz
      if ;; label = @2
        local.get 66
        ref.as_non_null
        local.set 68
        local.get 58
        ref.as_non_null
        local.get 39
        local.get 37
        local.get 38
        call 93
        local.set 69
        ref.null 70
        local.set 65
        local.get 69
        ref.is_null
        i32.eqz
        if ;; label = @3
          local.get 69
          ref.as_non_null
          local.set 67
          local.get 67
          ref.as_non_null
          struct.get 74 1
          local.set 65
          ref.null 74
          local.set 67
        end
        ref.null 74
        local.set 69
        local.get 60
        ref.as_non_null
        struct.get 108 1
        local.set 72
        local.get 68
        ref.as_non_null
        struct.get 70 1
        local.set 71
        local.get 65
        local.get 66
        ref.eq
        local.get 68
        ref.as_non_null
        struct.get 70 0
        local.set 173
        local.get 173
        i32.const 1
        i32.and
        i32.eqz
        i32.and
        local.get 173
        i32.const 6
        i32.and
        i32.eqz
        i32.eqz
        i32.and
        local.get 71
        ref.as_non_null
        local.get 72
        ref.eq
        i32.and
        ref.null 61
        local.set 71
        if ;; label = @3
          local.get 59
          ref.as_non_null
          local.set 70
          local.get 68
          ref.as_non_null
          local.get 70
          ref.as_non_null
          struct.set 70 1
          local.get 60
          ref.as_non_null
          local.get 70
          ref.as_non_null
          struct.set 108 1
          ref.null 62
          local.set 70
        else
          local.get 60
          ref.as_non_null
          ref.null 70
          struct.set 108 0
          local.get 60
          ref.as_non_null
          ref.null 62
          struct.set 108 1
        end
        ref.null 62
        local.set 72
        ref.null 70
        local.set 65
        ref.null 70
        local.set 68
      end
      ref.null 70
      local.set 66
      ref.null 108
      local.set 60
    end
    local.get 55
    ref.is_null
    i32.eqz
    if ;; label = @1
      local.get 55
      ref.as_non_null
      local.set 60
      local.get 60
      ref.as_non_null
      struct.get 108 0
      local.set 65
      local.get 65
      ref.is_null
      i32.eqz
      if ;; label = @2
        local.get 65
        ref.as_non_null
        local.set 66
        local.get 56
        ref.as_non_null
        local.get 36
        local.get 50
        local.get 51
        call 93
        local.set 69
        ref.null 70
        local.set 68
        local.get 69
        ref.is_null
        i32.eqz
        if ;; label = @3
          local.get 69
          ref.as_non_null
          local.set 67
          local.get 67
          ref.as_non_null
          struct.get 74 1
          local.set 68
          ref.null 74
          local.set 67
        end
        ref.null 74
        local.set 69
        local.get 60
        ref.as_non_null
        struct.get 108 1
        local.set 72
        local.get 66
        ref.as_non_null
        struct.get 70 1
        local.set 71
        local.get 68
        local.get 65
        ref.eq
        local.get 66
        ref.as_non_null
        struct.get 70 0
        local.set 91
        local.get 91
        i32.const 1
        i32.and
        i32.eqz
        i32.and
        local.get 91
        i32.const 6
        i32.and
        i32.eqz
        i32.eqz
        i32.and
        local.get 71
        ref.as_non_null
        local.get 72
        ref.eq
        i32.and
        ref.null 61
        local.set 71
        if ;; label = @3
          local.get 47
          ref.as_non_null
          local.set 70
          local.get 66
          ref.as_non_null
          local.get 70
          ref.as_non_null
          struct.set 70 1
          local.get 60
          ref.as_non_null
          local.get 70
          ref.as_non_null
          struct.set 108 1
          ref.null 62
          local.set 70
        else
          local.get 60
          ref.as_non_null
          ref.null 70
          struct.set 108 0
          local.get 60
          ref.as_non_null
          ref.null 62
          struct.set 108 1
        end
        ref.null 62
        local.set 72
        ref.null 70
        local.set 68
        ref.null 70
        local.set 66
      end
      ref.null 70
      local.set 65
      ref.null 108
      local.set 60
    end
    local.get 53
    global.set 3
    local.get 35
    global.set 4
    local.get 13
    local.get 14
    local.get 15
    local.get 16
    local.get 17
    ref.null 62
    local.set 59
    ref.null 108
    local.set 57
    ref.null eq
    local.set 38
    ref.null 69
    local.set 58
    ref.null 62
    local.set 47
    ref.null 108
    local.set 55
    ref.null eq
    local.set 51
    ref.null 69
    local.set 56
    ref.null 107
    local.set 53
    i32.const 0
    local.set 35
    ref.null 130
    local.set 34
    ref.null 120
    local.set 33
    ref.null 99
    local.set 28
    ref.null eq
    local.set 32
    ref.null eq
    local.set 20
    ref.null 161
    local.set 23
    ref.null 110
    local.set 22
    ref.null 107
    local.set 21
    ref.null 109
    local.set 26
    ref.null 130
    local.set 12
    ref.null 120
    local.set 11
  )
