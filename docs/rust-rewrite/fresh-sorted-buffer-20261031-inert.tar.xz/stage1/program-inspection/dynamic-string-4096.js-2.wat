  (func $js::workload#f0 (;109;) (type 40) (param (ref 107) i32 i64 eqref i32 i64 eqref i64 (ref null 99) (ref 161) (ref 109)) (result i32 i64 eqref i32 i32)
    (local (ref null 120) (ref null 130) i32 i64 eqref i32 i32 i32 i64 eqref (ref null 107) (ref null 110) (ref null 161) (ref null 109) (ref null 109) (ref null 109) (ref null 99) (ref null 99) i64 i32 i64 eqref (ref null 120) (ref null 130) i32 i32 i64 eqref i32 i32 (ref null 161) i32 i64 eqref (ref null 163) i32 (ref null 62) (ref null 131) (ref null 220) i64 eqref (ref null 107) (ref null 107) (ref null 69) (ref null 108) (ref null 69) (ref null 108) (ref null 69) (ref null 62) (ref null 108) (ref null 107) (ref null 106) i32 (ref null 62) (ref null 70) (ref null 70) (ref null 74) (ref null 70) (ref null 74) (ref null 62) (ref null 61) (ref null 62) i64 eqref i32 i64 eqref (ref null 114) i32 i64 eqref i32 (ref null 92) (ref null 129) (ref null 129) (ref null 120) i32 i64 eqref i32 i32 i64 eqref i64 i32 i64 eqref i32 i64 eqref (ref null 138) (ref null 134) eqref i64 eqref i32 i32 i32 i64 i64 i64 i64 i64 i64 (ref null 132) (ref null 133) (ref null 137) eqref eqref i32 eqref i32 i32 i32 eqref i32 eqref i32 (ref null 131) i64 i64 i32 eqref i32 i32 (ref null 139) i32 i32 (ref null 126) (ref null 120) (ref null 120) (ref null 127) (ref null 126) (ref null 124) (ref null 124) (ref null 124))
    ref.null 120
    local.set 11
    ref.null 130
    local.set 12
    i32.const 0
    local.set 13
    i64.const 0
    local.set 14
    ref.null eq
    local.set 15
    i32.const 0
    local.set 16
    i32.const 0
    local.set 17
    local.get 1
    local.set 18
    local.get 2
    local.set 19
    local.get 3
    local.set 20
    local.get 0
    local.set 21
    local.get 21
    ref.as_non_null
    struct.get 107 2
    local.set 22
    local.get 9
    local.set 23
    local.get 10
    local.set 24
    local.get 24
    ref.as_non_null
    local.set 25
    ref.null 109
    local.set 24
    local.get 22
    ref.as_non_null
    struct.get 110 9
    local.set 24
    local.get 25
    ref.as_non_null
    local.set 26
    local.get 24
    ref.is_null
    i32.eqz
    if ;; label = @1
      local.get 24
      ref.as_non_null
      local.set 26
    end
    ref.null 109
    local.set 24
    ref.null 109
    local.set 25
    local.get 8
    local.set 27
    local.get 27
    ref.is_null
    if ;; label = @1
      local.get 7
      i64.eqz
      i32.eqz
      if ;; label = @2
        unreachable
      end
      array.new_fixed 99 0
      local.set 27
    else
      local.get 27
      array.len
      i64.extend_i32_u
      local.get 7
      i64.ne
      if ;; label = @2
        unreachable
      end
    end
    local.get 27
    ref.as_non_null
    local.set 28
    ref.null 99
    local.set 27
    local.get 28
    ref.as_non_null
    array.len
    i64.extend_i32_u
    local.set 29
    local.get 4
    local.set 30
    local.get 5
    local.set 31
    local.get 6
    local.set 32
    local.get 22
    ref.as_non_null
    struct.get 110 1
    local.set 33
    local.get 22
    ref.as_non_null
    struct.get 110 2
    local.set 34
    local.get 33
    local.set 11
    local.get 34
    local.set 12
    global.get 4
    local.set 35
    local.get 35
    i32.const 128
    i32.ge_u
    if ;; label = @1
      local.get 22
      ref.as_non_null
      struct.get 110 0
      local.set 41
      local.get 41
      ref.as_non_null
      call 94
      local.get 41
      ref.as_non_null
      struct.get 161 5
      local.set 45
      i32.const 6
      local.set 46
      local.get 45
      ref.as_non_null
      local.get 46
      array.get 163
      local.set 47
      ref.null 163
      local.set 45
      local.get 47
      ref.as_non_null
      struct.get 62 1
      local.set 42
      local.get 47
      ref.as_non_null
      struct.get 62 0
      local.set 43
      local.get 47
      ref.as_non_null
      struct.get 62 2
      local.set 44
      i32.const 0
      local.get 42
      i32.const 6
      i32.eq
      i32.or
      local.get 42
      i32.const 7
      i32.eq
      i32.or
      local.get 42
      i32.const 8
      i32.eq
      i32.or
      local.get 42
      i32.const 9
      i32.eq
      i32.or
      i32.eqz
      if ;; label = @2
        unreachable
      end
      ref.null 62
      local.set 47
      i32.const 1783
      local.set 46
      local.get 46
      call 102
      local.set 48
      i32.const 2
      local.get 42
      local.get 43
      local.get 44
      local.get 48
      ref.as_non_null
      call 101
      local.set 49
      i32.const 6
      local.set 46
      i64.const 0
      local.set 50
      local.get 49
      ref.as_non_null
      local.set 51
      local.get 46
      local.set 36
      local.get 50
      local.set 37
      local.get 51
      local.set 38
      i32.const 1
      local.set 39
      i32.const 0
      local.set 40
      ref.null eq
      local.set 51
      ref.null 220
      local.set 49
      ref.null 131
      local.set 48
      ref.null eq
      local.set 44
      ref.null 161
      local.set 41
      i32.const 1
      local.set 39
      local.get 36
      local.get 37
      local.get 38
      local.get 39
      local.get 40
      ref.null eq
      local.set 38
      return
    end
    local.get 35
    i32.const 1
    i32.add
    global.set 4
    local.get 21
    ref.as_non_null
    local.set 52
    global.get 3
    local.set 53
    local.get 52
    ref.as_non_null
    struct.get 107 0
    local.set 54
    local.get 52
    ref.as_non_null
    struct.get 107 13
    local.set 55
    i32.const 120
    local.set 46
    local.get 46
    call 102
    local.set 48
    i32.const 4
    local.set 36
    i64.const 0
    local.set 50
    local.get 48
    ref.as_non_null
    local.set 51
    ref.null 131
    local.set 48
    local.get 54
    ref.as_non_null
    local.set 56
    ref.null 62
    local.set 47
    local.get 55
    ref.is_null
    i32.eqz
    if ;; label = @1
      local.get 55
      ref.as_non_null
      local.set 57
      local.get 57
      ref.as_non_null
      struct.get 108 1
      local.set 47
      ref.null 108
      local.set 57
    end
    local.get 52
    ref.as_non_null
    struct.get 107 14
    local.set 57
    i32.const 119
    local.set 40
    local.get 40
    call 102
    local.set 48
    i32.const 4
    local.set 39
    i64.const 0
    local.set 37
    local.get 48
    ref.as_non_null
    local.set 38
    ref.null 131
    local.set 48
    local.get 54
    ref.as_non_null
    local.set 58
    ref.null 62
    local.set 59
    local.get 57
    ref.is_null
    i32.eqz
    if ;; label = @1
      local.get 57
      ref.as_non_null
      local.set 60
      local.get 60
      ref.as_non_null
      struct.get 108 1
      local.set 59
      ref.null 108
      local.set 60
    end
    ref.null 69
    local.set 54
    i32.const 1
    local.set 40
    i64.const 0
    local.set 43
    ref.null eq
    local.set 44
    local.get 53
    ref.is_null
    i32.eqz
    if ;; label = @1
      local.get 53
      ref.as_non_null
      local.set 61
      local.get 61
      ref.as_non_null
      struct.get 107 5
      local.set 42
      local.get 61
      ref.as_non_null
      struct.get 107 1
      local.set 62
      local.get 62
      ref.as_non_null
      struct.get 106 4
      local.set 46
      local.get 62
      ref.as_non_null
      struct.get 106 1
      local.set 63
      local.get 42
      i32.eqz
      local.get 46
      i32.const 1
      i32.eq
      i32.and
      local.get 63
      i32.const 0
      i32.eq
      i32.and
      ref.null 106
      local.set 62
      if ;; label = @2
        i32.const 8
        local.set 40
        i64.const 0
        local.set 43
        local.get 61
        ref.as_non_null
        local.set 44
      end
      ref.null 107
      local.set 61
    end
    local.get 43
    local.get 40
    local.get 44
    struct.new 62
    local.set 64
    local.get 55
    ref.is_null
    i32.eqz
    if ;; label = @1
      local.get 55
      ref.as_non_null
      local.set 60
      local.get 60
      ref.as_non_null
      struct.get 108 0
      local.set 65
      local.get 65
      ref.is_null
      i32.eqz
      if ;; label = @2
        local.get 65
        ref.as_non_null
        local.set 66
        local.get 56
        ref.as_non_null
        local.get 36
        local.get 50
        local.get 51
        call 88
        local.set 67
        ref.null 70
        local.set 68
        local.get 67
        ref.is_null
        i32.eqz
        if ;; label = @3
          local.get 67
          ref.as_non_null
          local.set 69
          local.get 69
          ref.as_non_null
          struct.get 74 1
          local.set 68
          ref.null 74
          local.set 69
        end
        ref.null 74
        local.set 67
        local.get 60
        ref.as_non_null
        struct.get 108 1
        local.set 70
        local.get 66
        ref.as_non_null
        struct.get 70 1
        local.set 71
        local.get 68
        local.get 65
        ref.eq
        local.get 66
        ref.as_non_null
        struct.get 70 0
        local.set 63
        local.get 63
        i32.const 1
        i32.and
        i32.eqz
        i32.and
        local.get 63
        i32.const 6
        i32.and
        i32.eqz
        i32.eqz
        i32.and
        local.get 71
        ref.as_non_null
        local.get 70
        ref.eq
        i32.and
        ref.null 61
        local.set 71
        if ;; label = @3
          local.get 64
          ref.as_non_null
          local.set 72
          local.get 66
          ref.as_non_null
          local.get 72
          ref.as_non_null
          struct.set 70 1
          local.get 60
          ref.as_non_null
          local.get 72
          ref.as_non_null
          struct.set 108 1
          ref.null 62
          local.set 72
        else
          local.get 60
          ref.as_non_null
          ref.null 70
          struct.set 108 0
          local.get 60
          ref.as_non_null
          ref.null 62
          struct.set 108 1
        end
        ref.null 62
        local.set 70
        ref.null 70
        local.set 68
        ref.null 70
        local.set 66
      end
      ref.null 70
      local.set 65
      ref.null 108
      local.set 60
    end
    ref.null 62
    local.set 64
    ref.null eq
    local.set 44
    local.get 52
    ref.as_non_null
    global.set 3
    ref.null 107
    local.set 52
    block ;; label = @1
      i32.const 0
      local.set 46
      i64.const 0
      local.set 43
      ref.null eq
      local.set 44
      i32.const 0
      local.set 42
      i32.const 8
      local.set 40
      i64.const 0
      local.set 73
      local.get 21
      ref.as_non_null
      local.set 74
      local.get 40
      local.set 46
      local.get 73
      local.set 43
      local.get 74
      local.set 44
      i32.const 1
      local.set 42
      ref.null eq
      local.set 74
      i32.const 0
      local.set 63
      i64.const 0
      local.set 73
      ref.null eq
      local.set 74
      i32.const 0
      local.set 40
      local.get 21
      ref.as_non_null
      local.set 61
      local.get 28
      ref.as_non_null
      local.set 27
      local.get 22
      ref.as_non_null
      struct.get 110 0
      local.set 41
      local.get 41
      ref.as_non_null
      struct.get 161 5
      local.set 45
      i32.const 21
      local.set 82
      local.get 45
      ref.as_non_null
      local.get 82
      array.get 163
      local.set 70
      ref.null 163
      local.set 45
      local.get 70
      ref.as_non_null
      struct.get 62 1
      local.set 79
      local.get 70
      ref.as_non_null
      struct.get 62 0
      local.set 80
      local.get 70
      ref.as_non_null
      struct.get 62 2
      local.set 81
      i32.const 0
      local.get 79
      i32.const 6
      i32.eq
      i32.or
      local.get 79
      i32.const 7
      i32.eq
      i32.or
      local.get 79
      i32.const 8
      i32.eq
      i32.or
      local.get 79
      i32.const 9
      i32.eq
      i32.or
      i32.eqz
      if ;; label = @2
        unreachable
      end
      ref.null 62
      local.set 70
      i32.const 0
      local.set 82
      local.get 79
      local.get 80
      local.get 81
      local.get 82
      call 91
      local.set 54
      local.get 27
      ref.as_non_null
      array.len
      local.set 82
      ref.null 70
      local.get 82
      array.new 92
      local.set 83
      ref.null 129
      local.set 84
      ref.null 124
      local.get 82
      array.new 129
      local.set 85
      local.get 11
      local.set 86
      ref.null 120
      local.set 86
      local.get 85
      ref.as_non_null
      local.set 84
      ref.null 129
      local.set 85
      i32.const 0
      local.set 87
      i64.const 0
      local.set 88
      ref.null eq
      local.set 89
      local.get 88
      local.get 87
      local.get 89
      struct.new 62
      local.set 72
      i32.const 0
      local.set 90
      block ;; label = @2
        loop ;; label = @3
          local.get 90
          local.get 82
          i32.ge_u
          if ;; label = @4
            br 2 (;@2;)
          end
          local.get 27
          ref.as_non_null
          local.get 90
          array.get 99
          local.set 70
          i32.const 14
          local.get 70
          ref.as_non_null
          local.get 72
          ref.as_non_null
          local.get 72
          ref.as_non_null
          struct.new 70
          local.set 66
          local.get 83
          ref.as_non_null
          local.get 90
          local.get 66
          ref.as_non_null
          array.set 92
          ref.null 70
          local.set 66
          ref.null 62
          local.set 70
          local.get 90
          i32.const 1
          i32.add
          local.set 90
          br 0 (;@3;)
        end
      end
      local.get 82
      f64.convert_i32_u
      i64.reinterpret_f64
      local.set 94
      i32.const 3
      local.set 91
      local.get 94
      local.set 92
      ref.null eq
      local.set 93
      i32.const 140
      local.set 95
      local.get 95
      call 102
      local.set 48
      i32.const 4
      local.set 95
      i64.const 0
      local.set 96
      local.get 48
      ref.as_non_null
      local.set 97
      ref.null 131
      local.set 48
      i32.const 0
      local.set 98
      i64.const 0
      local.set 99
      ref.null eq
      local.set 100
      local.get 92
      local.get 91
      local.get 93
      struct.new 62
      local.set 70
      global.get 15
      local.set 64
      i32.const 6
      local.get 70
      ref.as_non_null
      local.get 64
      ref.as_non_null
      local.get 64
      ref.as_non_null
      struct.new 70
      local.set 68
      ref.null 62
      local.set 64
      ref.null 62
      local.set 70
      local.get 54
      ref.as_non_null
      local.get 95
      local.get 96
      local.get 97
      local.get 68
      ref.as_non_null
      call 89
      ref.null 70
      local.set 68
      ref.null eq
      local.set 100
      ref.null eq
      local.set 97
      i32.const 118
      local.set 95
      local.get 95
      call 102
      local.set 48
      i32.const 4
      local.set 98
      i64.const 0
      local.set 96
      local.get 48
      ref.as_non_null
      local.set 97
      ref.null 131
      local.set 48
      i32.const 8
      local.set 91
      i64.const 0
      local.set 92
      local.get 61
      ref.as_non_null
      local.set 93
      i32.const 0
      local.set 95
      i64.const 0
      local.set 99
      ref.null eq
      local.set 100
      local.get 92
      local.get 91
      local.get 93
      struct.new 62
      local.set 64
      global.get 15
      local.set 70
      i32.const 6
      local.get 64
      ref.as_non_null
      local.get 70
      ref.as_non_null
      local.get 70
      ref.as_non_null
      struct.new 70
      local.set 65
      ref.null 62
      local.set 70
      ref.null 62
      local.set 64
      local.get 54
      ref.as_non_null
      local.get 98
      local.get 96
      local.get 97
      local.get 65
      ref.as_non_null
      call 89
      ref.null 70
      local.set 65
      ref.null eq
      local.set 100
      ref.null eq
      local.set 97
      local.get 41
      ref.as_non_null
      struct.get 161 5
      local.set 45
      i32.const 1
      local.set 98
      local.get 45
      ref.as_non_null
      local.get 98
      array.get 163
      local.set 70
      ref.null 163
      local.set 45
      local.get 70
      ref.as_non_null
      struct.get 62 1
      local.set 91
      local.get 70
      ref.as_non_null
      struct.get 62 0
      local.set 92
      local.get 70
      ref.as_non_null
      struct.get 62 2
      local.set 93
      i32.const 0
      local.get 91
      i32.const 6
      i32.eq
      i32.or
      local.get 91
      i32.const 7
      i32.eq
      i32.or
      local.get 91
      i32.const 8
      i32.eq
      i32.or
      local.get 91
      i32.const 9
      i32.eq
      i32.or
      i32.eqz
      if ;; label = @2
        unreachable
      end
      ref.null 62
      local.set 70
      global.get 1
      ref.as_non_null
      i32.const 3
      array.get 135
      local.set 101
      i32.const 5
      local.set 95
      i64.const 0
      local.set 96
      local.get 101
      ref.as_non_null
      local.set 97
      i32.const 0
      local.set 98
      i64.const 0
      local.set 99
      ref.null eq
      local.set 100
      local.get 92
      local.get 91
      local.get 93
      struct.new 62
      local.set 70
      global.get 15
      local.set 64
      i32.const 6
      local.get 70
      ref.as_non_null
      local.get 64
      ref.as_non_null
      local.get 64
      ref.as_non_null
      struct.new 70
      local.set 68
      ref.null 62
      local.set 64
      ref.null 62
      local.set 70
      local.get 54
      ref.as_non_null
      local.get 95
      local.get 96
      local.get 97
      local.get 68
      ref.as_non_null
      call 89
      ref.null 70
      local.set 68
      ref.null eq
      local.set 100
      ref.null eq
      local.set 97
      ref.null 138
      local.set 101
      local.get 54
      ref.as_non_null
      local.get 83
      ref.as_non_null
      local.get 84
      struct.new 114
      ref.null eq
      local.set 93
      ref.null 62
      local.set 72
      ref.null eq
      local.set 89
      ref.null 129
      local.set 84
      ref.null 92
      local.set 83
      ref.null 69
      local.set 54
      ref.null eq
      local.set 81
      ref.null 161
      local.set 41
      ref.null 99
      local.set 27
      ref.null 107
      local.set 61
      local.set 78
      i32.const 9
      local.set 75
      i64.const 0
      local.set 76
      local.get 78
      ref.as_non_null
      local.set 77
      i32.const 9
      local.set 98
      i64.const 0
      local.set 99
      local.get 78
      ref.as_non_null
      local.set 100
      local.get 99
      local.get 98
      local.get 100
      struct.new 62
      local.set 64
      local.get 57
      ref.is_null
      i32.eqz
      if ;; label = @2
        local.get 57
        ref.as_non_null
        local.set 60
        local.get 60
        ref.as_non_null
        struct.get 108 0
        local.set 65
        local.get 65
        ref.is_null
        i32.eqz
        if ;; label = @3
          local.get 65
          ref.as_non_null
          local.set 66
          local.get 58
          ref.as_non_null
          local.get 39
          local.get 37
          local.get 38
          call 88
          local.set 67
          ref.null 70
          local.set 68
          local.get 67
          ref.is_null
          i32.eqz
          if ;; label = @4
            local.get 67
            ref.as_non_null
            local.set 69
            local.get 69
            ref.as_non_null
            struct.get 74 1
            local.set 68
            ref.null 74
            local.set 69
          end
          ref.null 74
          local.set 67
          local.get 60
          ref.as_non_null
          struct.get 108 1
          local.set 70
          local.get 66
          ref.as_non_null
          struct.get 70 1
          local.set 71
          local.get 68
          local.get 65
          ref.eq
          local.get 66
          ref.as_non_null
          struct.get 70 0
          local.set 87
          local.get 87
          i32.const 1
          i32.and
          i32.eqz
          i32.and
          local.get 87
          i32.const 6
          i32.and
          i32.eqz
          i32.eqz
          i32.and
          local.get 71
          ref.as_non_null
          local.get 70
          ref.eq
          i32.and
          ref.null 61
          local.set 71
          if ;; label = @4
            local.get 64
            ref.as_non_null
            local.set 72
            local.get 66
            ref.as_non_null
            local.get 72
            ref.as_non_null
            struct.set 70 1
            local.get 60
            ref.as_non_null
            local.get 72
            ref.as_non_null
            struct.set 108 1
            ref.null 62
            local.set 72
          else
            local.get 60
            ref.as_non_null
            ref.null 70
            struct.set 108 0
            local.get 60
            ref.as_non_null
            ref.null 62
            struct.set 108 1
          end
          ref.null 62
          local.set 70
          ref.null 70
          local.set 68
          ref.null 70
          local.set 66
        end
        ref.null 70
        local.set 65
        ref.null 108
        local.set 60
      end
      ref.null 62
      local.set 64
      ref.null eq
      local.set 100
      ref.null 114
      local.set 78
      local.get 75
      local.set 63
      local.get 76
      local.set 73
      local.get 77
      local.set 74
      i32.const 1
      local.set 40
      ref.null eq
      local.set 77
      i32.const 0
      local.set 16
      i32.const 0
      local.set 79
      i64.const 0
      local.set 88
      ref.null eq
      local.set 81
      i32.const 0
      local.set 79
      i64.const 0
      local.set 88
      ref.null eq
      local.set 81
      i32.const 0
      local.set 75
      i64.const 0
      local.set 76
      ref.null eq
      local.set 77
      i32.const 0
      local.set 75
      i64.const 0
      local.set 76
      ref.null eq
      local.set 77
      i32.const 0
      local.set 98
      i64.const 0
      local.set 99
      ref.null eq
      local.set 100
      i32.const 0
      local.set 98
      i64.const 0
      local.set 99
      ref.null eq
      local.set 100
      i32.const 0
      local.set 95
      i64.const 0
      local.set 80
      ref.null eq
      local.set 97
      i32.const 0
      local.set 95
      i64.const 0
      local.set 80
      ref.null eq
      local.set 97
      i32.const 0
      local.set 13
      i64.const 0
      local.set 14
      ref.null eq
      local.set 15
      local.get 13
      local.set 90
      local.get 14
      local.set 96
      local.get 15
      local.set 93
      local.get 26
      ref.as_non_null
      struct.get 109 5
      local.set 102
      i32.const 2
      local.set 91
      local.get 102
      ref.as_non_null
      local.get 91
      array.get 134
      ref.as_non_null
      ref.null 134
      local.set 102
      local.set 48
      i32.const 4
      local.set 82
      i64.const 0
      local.set 94
      local.get 48
      ref.as_non_null
      local.set 89
      ref.null 131
      local.set 48
      local.get 16
      i32.const 1
      i32.eq
      if ;; label = @2
        br 1 (;@1;)
      end
      local.get 82
      local.set 79
      local.get 94
      local.set 88
      local.get 89
      local.set 81
      ref.null eq
      local.set 89
      local.get 26
      ref.as_non_null
      struct.get 109 5
      local.set 102
      i32.const 3
      local.set 82
      local.get 102
      ref.as_non_null
      local.get 82
      array.get 134
      ref.as_non_null
      ref.null 134
      local.set 102
      local.set 48
      i32.const 4
      local.set 87
      i64.const 0
      local.set 92
      local.get 48
      ref.as_non_null
      local.set 89
      ref.null 131
      local.set 48
      local.get 16
      i32.const 1
      i32.eq
      if ;; label = @2
        br 1 (;@1;)
      end
      local.get 87
      local.set 75
      local.get 92
      local.set 76
      local.get 89
      local.set 77
      ref.null eq
      local.set 89
      i32.const 3
      local.set 91
      i64.const 0
      local.set 94
      ref.null eq
      local.set 89
      local.get 16
      i32.const 1
      i32.eq
      if ;; label = @2
        br 1 (;@1;)
      end
      local.get 91
      local.set 95
      local.get 94
      local.set 80
      local.get 89
      local.set 97
      ref.null eq
      local.set 89
      local.get 16
      i32.const 1
      i32.eq
      if ;; label = @2
        br 1 (;@1;)
      end
      local.get 16
      i32.const 0
      i32.eq
      if ;; label = @2
        local.get 90
        local.set 13
        local.get 96
        local.set 14
        local.get 93
        local.set 15
      end
      ref.null eq
      local.set 93
      i32.const 0
      local.set 13
      i64.const 0
      local.set 14
      ref.null eq
      local.set 15
      i32.const 0
      local.set 16
      i32.const 0
      local.set 17
      block ;; label = @2
        local.get 13
        local.set 87
        local.get 14
        local.set 92
        local.get 15
        local.set 89
        i32.const 3
        local.set 90
        i64.const 0
        local.set 96
        ref.null eq
        local.set 93
        local.get 16
        i32.const 1
        i32.eq
        if ;; label = @3
          br 2 (;@1;)
        end
        local.get 90
        local.set 98
        local.get 96
        local.set 99
        local.get 93
        local.set 100
        ref.null eq
        local.set 93
        local.get 16
        i32.const 1
        i32.eq
        if ;; label = @3
          br 2 (;@1;)
        end
        local.get 16
        i32.const 0
        i32.eq
        if ;; label = @3
          local.get 87
          local.set 13
          local.get 92
          local.set 14
          local.get 89
          local.set 15
        end
        ref.null eq
        local.set 89
        loop ;; label = @3
          local.get 13
          local.set 91
          local.get 14
          local.set 94
          local.get 15
          local.set 93
          local.get 98
          local.set 87
          local.get 99
          local.set 92
          local.get 100
          local.set 89
          local.get 16
          i32.const 1
          i32.eq
          if ;; label = @4
            br 3 (;@1;)
          end
          i32.const 3
          local.set 90
          i64.const 4661225614328463360
          local.set 96
          ref.null eq
          local.set 103
          local.get 16
          i32.const 1
          i32.eq
          if ;; label = @4
            br 3 (;@1;)
          end
          local.get 87
          i32.const 3
          i32.eq
          local.get 90
          i32.const 3
          i32.eq
          i32.and
          if ;; label = @4
            local.get 92
            f64.reinterpret_i64
            local.get 96
            f64.reinterpret_i64
            f64.lt
            local.set 108
          else
            local.get 22
            ref.as_non_null
            struct.get 110 0
            local.set 41
            local.get 87
            local.get 92
            local.get 89
            local.get 90
            local.get 96
            local.get 103
            local.get 41
            ref.as_non_null
            local.get 11
            local.get 26
            ref.as_non_null
            call 106
            local.set 107
            local.set 106
            local.set 105
            local.set 104
            local.set 82
            ref.null 161
            local.set 41
            ref.null eq
            local.set 103
            ref.null eq
            local.set 89
            local.get 106
            i32.const 1
            i32.eq
            if ;; label = @5
              local.get 82
              local.set 13
              local.get 104
              local.set 14
              local.get 105
              local.set 15
              local.get 106
              local.set 16
              local.get 107
              local.set 17
              br 4 (;@1;)
            end
            local.get 104
            f64.reinterpret_i64
            f64.const 0x0p+0 (;=0;)
            f64.lt
            local.set 108
          end
          ref.null eq
          local.set 105
          ref.null eq
          local.set 103
          ref.null eq
          local.set 89
          local.get 108
          local.get 16
          i32.const 1
          i32.eq
          if ;; label = @4
            br 3 (;@1;)
          end
          local.get 16
          i32.const 0
          i32.eq
          if ;; label = @4
            local.get 91
            local.set 13
            local.get 94
            local.set 14
            local.get 93
            local.set 15
          end
          ref.null eq
          local.set 93
          local.get 16
          i32.const 1
          i32.eq
          if ;; label = @4
            br 3 (;@1;)
          end
          i32.eqz
          br_if 1 (;@2;)
          block ;; label = @4
            local.get 99
            local.set 96
            i64.const 4611686018427387904
            local.set 109
            local.get 96
            i64.const -9223372036854775808
            i64.and
            local.set 110
            local.get 96
            i64.const 9223372036854775807
            i64.and
            local.set 111
            local.get 109
            i64.const 9223372036854775807
            i64.and
            local.set 112
            block ;; label = @5
              local.get 112
              i64.eqz
              i32.eqz
              local.get 111
              i64.const 4845873199050653695
              i64.le_u
              i32.and
              local.get 96
              f64.reinterpret_i64
              f64.trunc
              local.get 96
              f64.reinterpret_i64
              f64.eq
              i32.and
              local.get 112
              i64.const 4845873199050653695
              i64.le_u
              i32.and
              local.get 109
              f64.reinterpret_i64
              f64.trunc
              local.get 109
              f64.reinterpret_i64
              f64.eq
              i32.and
              if ;; label = @6
                local.get 96
                f64.reinterpret_i64
                i64.trunc_f64_s
                local.get 109
                f64.reinterpret_i64
                i64.trunc_f64_s
                i64.rem_s
                f64.convert_i64_s
                i64.reinterpret_f64
                local.get 110
                i64.or
                local.set 92
                br 1 (;@5;)
              end
              local.get 111
              i64.const 9218868437227405312
              i64.ge_u
              local.get 112
              i64.const 9218868437227405312
              i64.gt_u
              i32.or
              local.get 112
              i64.eqz
              i32.or
              if ;; label = @6
                i64.const 9221120237041090560
                local.set 92
                br 1 (;@5;)
              end
              local.get 111
              local.get 112
              i64.lt_u
              if ;; label = @6
                local.get 96
                local.set 92
                br 1 (;@5;)
              end
              local.get 111
              local.get 112
              i64.eq
              if ;; label = @6
                local.get 110
                local.set 92
                br 1 (;@5;)
              end
              local.get 111
              i64.const 52
              i64.shr_u
              local.set 113
              local.get 113
              i64.eqz
              if ;; label = @6
                local.get 111
                i64.clz
                i64.const 11
                i64.sub
                local.set 113
                local.get 111
                local.get 113
                i64.shl
                local.set 111
                i64.const 1
                local.get 113
                i64.sub
                local.set 113
              else
                local.get 111
                i64.const 4503599627370495
                i64.and
                i64.const 4503599627370496
                i64.or
                local.set 111
              end
              local.get 112
              i64.const 52
              i64.shr_u
              local.set 114
              local.get 114
              i64.eqz
              if ;; label = @6
                local.get 112
                i64.clz
                i64.const 11
                i64.sub
                local.set 114
                local.get 112
                local.get 114
                i64.shl
                local.set 112
                i64.const 1
                local.get 114
                i64.sub
                local.set 114
              else
                local.get 112
                i64.const 4503599627370495
                i64.and
                i64.const 4503599627370496
                i64.or
                local.set 112
              end
              block ;; label = @6
                loop ;; label = @7
                  local.get 113
                  local.get 114
                  i64.eq
                  br_if 1 (;@6;)
                  local.get 111
                  local.get 112
                  i64.ge_u
                  if ;; label = @8
                    local.get 111
                    local.get 112
                    i64.sub
                    local.set 111
                  end
                  local.get 111
                  i64.const 1
                  i64.shl
                  local.set 111
                  local.get 113
                  i64.const 1
                  i64.sub
                  local.set 113
                  br 0 (;@7;)
                end
              end
              local.get 111
              local.get 112
              i64.ge_u
              if ;; label = @6
                local.get 111
                local.get 112
                i64.sub
                local.set 111
              end
              local.get 111
              i64.eqz
              if ;; label = @6
                local.get 110
                local.set 92
                br 1 (;@5;)
              end
              local.get 111
              i64.clz
              i64.const 11
              i64.sub
              local.set 113
              local.get 111
              local.get 113
              i64.shl
              local.set 111
              local.get 114
              local.get 113
              i64.sub
              local.set 114
              local.get 114
              i64.const 0
              i64.gt_s
              if (result i64) ;; label = @6
                local.get 111
                i64.const 4503599627370495
                i64.and
                local.get 114
                i64.const 52
                i64.shl
                i64.or
              else
                local.get 111
                i64.const 1
                local.get 114
                i64.sub
                i64.shr_u
              end
              local.get 110
              i64.or
              local.set 92
            end
            i32.const 3
            local.set 108
            local.get 92
            local.set 92
            ref.null eq
            local.set 89
            local.get 16
            i32.const 1
            i32.eq
            if ;; label = @5
              br 4 (;@1;)
            end
            local.get 108
            i32.const 2
            i32.eq
            if (result i32) ;; label = @5
              local.get 92
              i64.eqz
              i32.eqz
            else
              local.get 108
              i32.const 4
              i32.eq
              if (result i32) ;; label = @6
                local.get 89
                ref.cast (ref 131)
                local.set 48
                local.get 48
                ref.as_non_null
                struct.get 131 0
                local.set 115
                local.get 115
                ref.as_non_null
                array.len
                i32.eqz
                i32.eqz
                ref.null 132
                local.set 115
                ref.null 131
                local.set 48
              else
                local.get 108
                i32.const 3
                i32.eq
                if (result i32) ;; label = @7
                  local.get 92
                  f64.reinterpret_i64
                  f64.const 0x0p+0 (;=0;)
                  f64.eq
                  local.get 92
                  f64.reinterpret_i64
                  local.get 92
                  f64.reinterpret_i64
                  f64.ne
                  i32.or
                  i32.eqz
                else
                  local.get 108
                  i32.const 10
                  i32.eq
                  if (result i32) ;; label = @8
                    local.get 89
                    ref.cast (ref 133)
                    local.set 116
                    local.get 116
                    ref.as_non_null
                    struct.get 133 1
                    local.set 117
                    local.get 117
                    ref.as_non_null
                    array.len
                    i32.eqz
                    i32.eqz
                    ref.null 137
                    local.set 117
                    ref.null 133
                    local.set 116
                  else
                    local.get 108
                    i32.const 0
                    i32.eq
                    local.get 108
                    i32.const 1
                    i32.eq
                    i32.or
                    if (result i32) ;; label = @9
                      i32.const 0
                    else
                      local.get 89
                      ref.test (ref 107)
                      if (result i32) ;; label = @10
                        local.get 89
                        ref.cast (ref 107)
                        local.set 52
                        local.get 52
                        ref.as_non_null
                        struct.get 107 11
                        local.set 106
                        local.get 106
                        ref.null 107
                        local.set 52
                      else
                        i32.const 0
                      end
                      i32.eqz
                    end
                  end
                end
              end
            end
            ref.null eq
            local.set 89
            if ;; label = @5
              local.get 26
              ref.as_non_null
              struct.get 109 5
              local.set 102
              i32.const 2
              local.set 90
              local.get 102
              ref.as_non_null
              local.get 90
              array.get 134
              ref.as_non_null
              ref.null 134
              local.set 102
              local.set 48
              i32.const 4
              local.set 91
              i64.const 0
              local.set 94
              local.get 48
              ref.as_non_null
              local.set 93
              ref.null 131
              local.set 48
              local.get 16
              i32.const 1
              i32.eq
              if ;; label = @6
                br 5 (;@1;)
              end
            else
              local.get 26
              ref.as_non_null
              struct.get 109 5
              local.set 102
              i32.const 3
              local.set 87
              local.get 102
              ref.as_non_null
              local.get 87
              array.get 134
              ref.as_non_null
              ref.null 134
              local.set 102
              local.set 48
              i32.const 4
              local.set 91
              i64.const 0
              local.set 94
              local.get 48
              ref.as_non_null
              local.set 93
              ref.null 131
              local.set 48
              local.get 16
              i32.const 1
              i32.eq
              if ;; label = @6
                br 5 (;@1;)
              end
            end
            local.get 16
            i32.const 1
            i32.eq
            if ;; label = @5
              br 4 (;@1;)
            end
            local.get 91
            local.set 79
            local.get 94
            local.set 88
            local.get 93
            local.set 81
            local.get 91
            local.set 107
            local.get 94
            local.set 104
            local.get 93
            local.set 105
            ref.null eq
            local.set 93
            local.get 16
            i32.const 1
            i32.eq
            if ;; label = @5
              br 4 (;@1;)
            end
            local.get 16
            i32.const 1
            i32.eq
            if ;; label = @5
              br 4 (;@1;)
            end
            local.get 107
            local.set 13
            local.get 104
            local.set 14
            local.get 105
            local.set 15
            i32.const 0
            local.set 16
            i32.const 0
            local.set 17
            ref.null eq
            local.set 105
            local.get 99
            local.set 96
            i64.const 4611686018427387904
            local.set 114
            local.get 96
            i64.const -9223372036854775808
            i64.and
            local.set 113
            local.get 96
            i64.const 9223372036854775807
            i64.and
            local.set 112
            local.get 114
            i64.const 9223372036854775807
            i64.and
            local.set 111
            block ;; label = @5
              local.get 111
              i64.eqz
              i32.eqz
              local.get 112
              i64.const 4845873199050653695
              i64.le_u
              i32.and
              local.get 96
              f64.reinterpret_i64
              f64.trunc
              local.get 96
              f64.reinterpret_i64
              f64.eq
              i32.and
              local.get 111
              i64.const 4845873199050653695
              i64.le_u
              i32.and
              local.get 114
              f64.reinterpret_i64
              f64.trunc
              local.get 114
              f64.reinterpret_i64
              f64.eq
              i32.and
              if ;; label = @6
                local.get 96
                f64.reinterpret_i64
                i64.trunc_f64_s
                local.get 114
                f64.reinterpret_i64
                i64.trunc_f64_s
                i64.rem_s
                f64.convert_i64_s
                i64.reinterpret_f64
                local.get 113
                i64.or
                local.set 94
                br 1 (;@5;)
              end
              local.get 112
              i64.const 9218868437227405312
              i64.ge_u
              local.get 111
              i64.const 9218868437227405312
              i64.gt_u
              i32.or
              local.get 111
              i64.eqz
              i32.or
              if ;; label = @6
                i64.const 9221120237041090560
                local.set 94
                br 1 (;@5;)
              end
              local.get 112
              local.get 111
              i64.lt_u
              if ;; label = @6
                local.get 96
                local.set 94
                br 1 (;@5;)
              end
              local.get 112
              local.get 111
              i64.eq
              if ;; label = @6
                local.get 113
                local.set 94
                br 1 (;@5;)
              end
              local.get 112
              i64.const 52
              i64.shr_u
              local.set 109
              local.get 109
              i64.eqz
              if ;; label = @6
                local.get 112
                i64.clz
                i64.const 11
                i64.sub
                local.set 109
                local.get 112
                local.get 109
                i64.shl
                local.set 112
                i64.const 1
                local.get 109
                i64.sub
                local.set 109
              else
                local.get 112
                i64.const 4503599627370495
                i64.and
                i64.const 4503599627370496
                i64.or
                local.set 112
              end
              local.get 111
              i64.const 52
              i64.shr_u
              local.set 110
              local.get 110
              i64.eqz
              if ;; label = @6
                local.get 111
                i64.clz
                i64.const 11
                i64.sub
                local.set 110
                local.get 111
                local.get 110
                i64.shl
                local.set 111
                i64.const 1
                local.get 110
                i64.sub
                local.set 110
              else
                local.get 111
                i64.const 4503599627370495
                i64.and
                i64.const 4503599627370496
                i64.or
                local.set 111
              end
              block ;; label = @6
                loop ;; label = @7
                  local.get 109
                  local.get 110
                  i64.eq
                  br_if 1 (;@6;)
                  local.get 112
                  local.get 111
                  i64.ge_u
                  if ;; label = @8
                    local.get 112
                    local.get 111
                    i64.sub
                    local.set 112
                  end
                  local.get 112
                  i64.const 1
                  i64.shl
                  local.set 112
                  local.get 109
                  i64.const 1
                  i64.sub
                  local.set 109
                  br 0 (;@7;)
                end
              end
              local.get 112
              local.get 111
              i64.ge_u
              if ;; label = @6
                local.get 112
                local.get 111
                i64.sub
                local.set 112
              end
              local.get 112
              i64.eqz
              if ;; label = @6
                local.get 113
                local.set 94
                br 1 (;@5;)
              end
              local.get 112
              i64.clz
              i64.const 11
              i64.sub
              local.set 109
              local.get 112
              local.get 109
              i64.shl
              local.set 112
              local.get 110
              local.get 109
              i64.sub
              local.set 110
              local.get 110
              i64.const 0
              i64.gt_s
              if (result i64) ;; label = @6
                local.get 112
                i64.const 4503599627370495
                i64.and
                local.get 110
                i64.const 52
                i64.shl
                i64.or
              else
                local.get 112
                i64.const 1
                local.get 110
                i64.sub
                i64.shr_u
              end
              local.get 113
              i64.or
              local.set 94
            end
            i32.const 3
            local.set 91
            local.get 94
            local.set 94
            ref.null eq
            local.set 93
            local.get 16
            i32.const 1
            i32.eq
            if ;; label = @5
              br 4 (;@1;)
            end
            local.get 91
            i32.const 2
            i32.eq
            if (result i32) ;; label = @5
              local.get 94
              i64.eqz
              i32.eqz
            else
              local.get 91
              i32.const 4
              i32.eq
              if (result i32) ;; label = @6
                local.get 93
                ref.cast (ref 131)
                local.set 48
                local.get 48
                ref.as_non_null
                struct.get 131 0
                local.set 115
                local.get 115
                ref.as_non_null
                array.len
                i32.eqz
                i32.eqz
                ref.null 132
                local.set 115
                ref.null 131
                local.set 48
              else
                local.get 91
                i32.const 3
                i32.eq
                if (result i32) ;; label = @7
                  local.get 94
                  f64.reinterpret_i64
                  f64.const 0x0p+0 (;=0;)
                  f64.eq
                  local.get 94
                  f64.reinterpret_i64
                  local.get 94
                  f64.reinterpret_i64
                  f64.ne
                  i32.or
                  i32.eqz
                else
                  local.get 91
                  i32.const 10
                  i32.eq
                  if (result i32) ;; label = @8
                    local.get 93
                    ref.cast (ref 133)
                    local.set 116
                    local.get 116
                    ref.as_non_null
                    struct.get 133 1
                    local.set 117
                    local.get 117
                    ref.as_non_null
                    array.len
                    i32.eqz
                    i32.eqz
                    ref.null 137
                    local.set 117
                    ref.null 133
                    local.set 116
                  else
                    local.get 91
                    i32.const 0
                    i32.eq
                    local.get 91
                    i32.const 1
                    i32.eq
                    i32.or
                    if (result i32) ;; label = @9
                      i32.const 0
                    else
                      local.get 93
                      ref.test (ref 107)
                      if (result i32) ;; label = @10
                        local.get 93
                        ref.cast (ref 107)
                        local.set 52
                        local.get 52
                        ref.as_non_null
                        struct.get 107 11
                        local.set 87
                        local.get 87
                        ref.null 107
                        local.set 52
                      else
                        i32.const 0
                      end
                      i32.eqz
                    end
                  end
                end
              end
            end
            ref.null eq
            local.set 93
            if ;; label = @5
              local.get 26
              ref.as_non_null
              struct.get 109 5
              local.set 102
              i32.const 3
              local.set 91
              local.get 102
              ref.as_non_null
              local.get 91
              array.get 134
              ref.as_non_null
              ref.null 134
              local.set 102
              local.set 48
              i32.const 4
              local.set 107
              i64.const 0
              local.set 104
              local.get 48
              ref.as_non_null
              local.set 105
              ref.null 131
              local.set 48
              local.get 16
              i32.const 1
              i32.eq
              if ;; label = @6
                br 5 (;@1;)
              end
            else
              local.get 26
              ref.as_non_null
              struct.get 109 5
              local.set 102
              i32.const 2
              local.set 82
              local.get 102
              ref.as_non_null
              local.get 82
              array.get 134
              ref.as_non_null
              ref.null 134
              local.set 102
              local.set 48
              i32.const 4
              local.set 107
              i64.const 0
              local.set 104
              local.get 48
              ref.as_non_null
              local.set 105
              ref.null 131
              local.set 48
              local.get 16
              i32.const 1
              i32.eq
              if ;; label = @6
                br 5 (;@1;)
              end
            end
            local.get 16
            i32.const 1
            i32.eq
            if ;; label = @5
              br 4 (;@1;)
            end
            local.get 107
            local.set 75
            local.get 104
            local.set 76
            local.get 105
            local.set 77
            local.get 107
            local.set 90
            local.get 104
            local.set 92
            local.get 105
            local.set 103
            ref.null eq
            local.set 105
            local.get 16
            i32.const 1
            i32.eq
            if ;; label = @5
              br 4 (;@1;)
            end
            local.get 16
            i32.const 1
            i32.eq
            if ;; label = @5
              br 4 (;@1;)
            end
            local.get 90
            local.set 13
            local.get 92
            local.set 14
            local.get 103
            local.set 15
            i32.const 0
            local.set 16
            i32.const 0
            local.set 17
            ref.null eq
            local.set 103
            local.get 95
            local.set 90
            local.get 80
            local.set 92
            local.get 97
            local.set 103
            i32.const 0
            local.set 82
            i64.const 0
            local.set 96
            ref.null eq
            local.set 89
            i32.const 0
            local.set 87
            local.get 90
            local.set 82
            local.get 92
            local.set 96
            local.get 103
            local.set 89
            i32.const 1
            local.set 87
            local.get 87
            i32.eqz
            if ;; label = @5
              local.get 22
              ref.as_non_null
              struct.get 110 0
              local.set 41
              local.get 41
              ref.as_non_null
              local.get 11
              call 105
              local.set 17
              local.set 16
              local.set 15
              local.set 14
              local.set 13
              ref.null 161
              local.set 41
              local.get 13
              local.set 124
              local.get 14
              local.set 110
              local.get 15
              local.set 125
              local.get 16
              i32.const 1
              i32.eq
              if ;; label = @6
                br 5 (;@1;)
              end
              ref.null eq
              local.set 125
            end
            local.get 82
            local.set 106
            local.get 96
            local.set 113
            local.get 89
            local.set 118
            local.get 16
            i32.const 1
            i32.eq
            if ;; label = @5
              br 4 (;@1;)
            end
            local.get 79
            local.set 124
            local.get 88
            local.set 111
            local.get 81
            local.set 125
            local.get 16
            i32.const 1
            i32.eq
            if ;; label = @5
              br 4 (;@1;)
            end
            local.get 75
            local.set 126
            local.get 76
            local.set 110
            local.get 77
            local.set 127
            local.get 16
            i32.const 1
            i32.eq
            if ;; label = @5
              br 4 (;@1;)
            end
            i32.const 0
            local.set 128
            local.get 124
            i32.const 4
            i32.eq
            local.get 126
            i32.const 4
            i32.eq
            i32.and
            if ;; label = @5
              local.get 125
              ref.cast (ref 131)
              local.set 48
              local.get 127
              ref.cast (ref 131)
              local.set 129
              local.get 48
              ref.as_non_null
              struct.get 131 0
              local.set 115
              local.get 115
              ref.as_non_null
              array.len
              i64.extend_i32_u
              local.set 112
              ref.null 132
              local.set 115
              local.get 129
              ref.as_non_null
              struct.get 131 0
              local.set 115
              local.get 115
              ref.as_non_null
              array.len
              i64.extend_i32_u
              local.set 130
              ref.null 132
              local.set 115
              local.get 112
              local.get 130
              i64.add
              local.set 131
              local.get 131
              i64.const 4294967295
              i64.le_u
              if ;; label = @6
                local.get 131
                f64.convert_i64_u
                i64.reinterpret_f64
                local.set 131
                i32.const 3
                local.set 108
                local.get 131
                local.set 109
                ref.null eq
                local.set 119
                i32.const 1
                local.set 128
              end
              ref.null 131
              local.set 129
              ref.null 131
              local.set 48
            end
            local.get 128
            i32.eqz
            if ;; label = @5
              local.get 124
              i32.const 3
              i32.eq
              local.get 126
              i32.const 3
              i32.eq
              i32.and
              if ;; label = @6
                local.get 111
                f64.reinterpret_i64
                local.get 110
                f64.reinterpret_i64
                f64.add
                i64.reinterpret_f64
                local.set 131
                i32.const 3
                local.set 132
                local.get 131
                local.set 131
                ref.null eq
                local.set 133
                local.get 132
                local.set 132
                local.get 131
                local.set 131
                local.get 133
                local.set 133
                i32.const 0
                local.set 134
                i32.const 0
                local.set 135
              else
                local.get 22
                ref.as_non_null
                struct.get 110 0
                local.set 41
                local.get 124
                local.get 111
                local.get 125
                local.get 126
                local.get 110
                local.get 127
                local.get 41
                ref.as_non_null
                local.get 11
                local.get 26
                ref.as_non_null
                call 99
                local.set 135
                local.set 134
                local.set 133
                local.set 131
                local.set 132
                ref.null 161
                local.set 41
              end
            end
            ref.null eq
            local.set 127
            ref.null eq
            local.set 125
            local.get 128
            i32.eqz
            if ;; label = @5
              local.get 134
              i32.const 1
              i32.eq
              if ;; label = @6
                local.get 132
                local.set 13
                local.get 131
                local.set 14
                local.get 133
                local.set 15
                local.get 134
                local.set 16
                local.get 135
                local.set 17
                br 5 (;@1;)
              end
              local.get 132
              i32.const 4
              i32.eq
              if ;; label = @6
                local.get 133
                ref.cast (ref 131)
                local.set 129
                local.get 129
                ref.as_non_null
                struct.get 131 0
                local.set 115
                local.get 115
                ref.as_non_null
                array.len
                i64.extend_i32_u
                local.set 130
                ref.null 132
                local.set 115
                local.get 130
                f64.convert_i64_u
                i64.reinterpret_f64
                local.set 130
                i32.const 3
                local.set 108
                local.get 130
                local.set 109
                ref.null eq
                local.set 119
                ref.null 131
                local.set 129
              else
                local.get 133
                ref.test (ref 139)
                if ;; label = @7
                  local.get 133
                  ref.cast (ref 139)
                  local.set 136
                  local.get 136
                  ref.as_non_null
                  struct.get 139 2
                  local.set 111
                  local.get 111
                  f64.convert_i64_u
                  i64.reinterpret_f64
                  local.set 111
                  i32.const 3
                  local.set 108
                  local.get 111
                  local.set 109
                  ref.null eq
                  local.set 119
                  ref.null 139
                  local.set 136
                else
                  i32.const 140
                  local.set 126
                  local.get 126
                  call 102
                  local.set 48
                  i32.const 4
                  local.set 124
                  i64.const 0
                  local.set 112
                  local.get 48
                  ref.as_non_null
                  local.set 125
                  ref.null 131
                  local.set 48
                  local.get 132
                  local.get 131
                  local.get 133
                  local.get 132
                  local.get 131
                  local.get 133
                  local.get 124
                  local.get 112
                  local.get 125
                  local.get 11
                  local.get 26
                  ref.as_non_null
                  call 100
                  local.set 138
                  local.set 137
                  local.set 127
                  local.set 130
                  local.set 126
                  local.get 137
                  i32.const 1
                  i32.eq
                  if ;; label = @8
                    local.get 126
                    local.set 13
                    local.get 130
                    local.set 14
                    local.get 127
                    local.set 15
                    local.get 137
                    local.set 16
                    local.get 138
                    local.set 17
                  else
                    local.get 126
                    local.set 108
                    local.get 130
                    local.set 109
                    local.get 127
                    local.set 119
                  end
                  ref.null eq
                  local.set 127
                  ref.null eq
                  local.set 125
                  local.get 16
                  i32.const 1
                  i32.eq
                  if ;; label = @8
                    br 7 (;@1;)
                  end
                end
              end
            end
            ref.null eq
            local.set 133
            local.get 16
            i32.const 1
            i32.eq
            if ;; label = @5
              br 4 (;@1;)
            end
            local.get 106
            i32.const 3
            i32.eq
            local.get 108
            i32.const 3
            i32.eq
            i32.and
            if ;; label = @5
              local.get 113
              f64.reinterpret_i64
              local.get 109
              f64.reinterpret_i64
              f64.add
              i64.reinterpret_f64
              local.set 114
              i32.const 3
              local.set 120
              local.get 114
              local.set 114
              ref.null eq
              local.set 121
              local.get 120
              local.set 120
              local.get 114
              local.set 114
              local.get 121
              local.set 121
              i32.const 0
              local.set 122
              i32.const 0
              local.set 123
            else
              local.get 22
              ref.as_non_null
              struct.get 110 0
              local.set 41
              local.get 106
              local.get 113
              local.get 118
              local.get 108
              local.get 109
              local.get 119
              local.get 41
              ref.as_non_null
              local.get 11
              local.get 26
              ref.as_non_null
              call 99
              local.set 123
              local.set 122
              local.set 121
              local.set 114
              local.set 120
              ref.null 161
              local.set 41
            end
            ref.null eq
            local.set 119
            ref.null eq
            local.set 118
            local.get 122
            i32.const 1
            i32.eq
            if ;; label = @5
              local.get 120
              local.set 13
              local.get 114
              local.set 14
              local.get 121
              local.set 15
              local.get 122
              local.set 16
              local.get 123
              local.set 17
              br 4 (;@1;)
            end
            local.get 120
            local.set 107
            local.get 114
            local.set 104
            local.get 121
            local.set 105
            ref.null eq
            local.set 121
            ref.null eq
            local.set 89
            local.get 107
            local.set 95
            local.get 104
            local.set 80
            local.get 105
            local.set 97
            local.get 107
            local.set 91
            local.get 104
            local.set 94
            local.get 105
            local.set 93
            ref.null eq
            local.set 105
            ref.null eq
            local.set 103
            local.get 16
            i32.const 1
            i32.eq
            if ;; label = @5
              br 4 (;@1;)
            end
            local.get 16
            i32.const 1
            i32.eq
            if ;; label = @5
              br 4 (;@1;)
            end
            local.get 91
            local.set 13
            local.get 94
            local.set 14
            local.get 93
            local.set 15
            i32.const 0
            local.set 16
            i32.const 0
            local.set 17
            ref.null eq
            local.set 93
          end
          local.get 13
          local.set 128
          local.get 14
          local.set 111
          local.get 15
          local.set 127
          local.get 98
          local.set 90
          local.get 99
          local.set 92
          local.get 100
          local.set 103
          local.get 90
          i32.const 3
          i32.ne
          if ;; label = @4
            i32.const 0
            local.set 82
            i64.const 0
            local.set 96
            ref.null eq
            local.set 89
            i32.const 0
            local.set 120
            i32.const 0
            local.set 87
            local.get 90
            local.get 92
            local.get 103
            local.get 11
            local.get 26
            ref.as_non_null
            call 98
            local.set 87
            local.set 120
            local.set 89
            local.set 96
            local.set 82
            local.get 82
            local.set 13
            local.get 96
            local.set 14
            local.get 89
            local.set 15
            local.get 120
            local.set 16
            local.get 87
            local.set 17
            local.get 16
            i32.const 1
            i32.eq
            if ;; label = @5
              br 4 (;@1;)
            end
            local.get 82
            local.set 90
            local.get 96
            local.set 92
            local.get 89
            local.set 103
            ref.null eq
            local.set 89
          end
          local.get 92
          f64.reinterpret_i64
          f64.const 0x1p+0 (;=1;)
          f64.add
          i64.reinterpret_f64
          local.set 104
          i32.const 3
          local.set 107
          local.get 104
          local.set 104
          ref.null eq
          local.set 105
          local.get 107
          local.set 98
          local.get 104
          local.set 99
          local.get 105
          local.set 100
          local.get 90
          local.set 91
          local.get 92
          local.set 94
          local.get 103
          local.set 93
          ref.null eq
          local.set 105
          ref.null eq
          local.set 103
          local.get 16
          i32.const 1
          i32.eq
          if ;; label = @4
            br 3 (;@1;)
          end
          ref.null eq
          local.set 93
          local.get 16
          i32.const 1
          i32.eq
          if ;; label = @4
            br 3 (;@1;)
          end
          local.get 16
          i32.const 0
          i32.eq
          if ;; label = @4
            local.get 128
            local.set 13
            local.get 111
            local.set 14
            local.get 127
            local.set 15
          end
          ref.null eq
          local.set 127
          br 0 (;@3;)
        end
      end
      i32.const 845
      local.set 107
      local.get 107
      call 102
      local.set 48
      ref.null 126
      local.set 139
      ref.null 126
      local.set 139
      local.get 11
      ref.as_non_null
      local.set 86
      local.get 86
      ref.as_non_null
      local.set 140
      ref.null 120
      local.set 141
      block ;; label = @2
        loop ;; label = @3
          local.get 140
          ref.as_non_null
          struct.get 120 3
          local.set 141
          local.get 141
          ref.is_null
          br_if 1 (;@2;)
          local.get 141
          ref.as_non_null
          local.set 140
          br 0 (;@3;)
        end
      end
      ref.null 120
      local.set 141
      ref.null 120
      local.set 86
      ref.null 126
      local.set 139
      local.get 140
      ref.as_non_null
      struct.get 120 1
      local.set 142
      local.get 142
      ref.is_null
      i32.eqz
      if ;; label = @2
        local.get 142
        array.len
        local.set 107
        i32.const 0
        local.set 90
        ref.null 126
        local.set 143
        block ;; label = @3
          loop ;; label = @4
            local.get 90
            local.get 107
            i32.ge_u
            br_if 1 (;@3;)
            local.get 142
            local.get 90
            array.get 127
            local.set 143
            local.get 143
            ref.is_null
            i32.eqz
            if ;; label = @5
              local.get 143
              struct.get 126 3
              if ;; label = @6
                local.get 143
                struct.get 126 0
                local.set 129
                i32.const 0
                local.set 82
                local.get 129
                ref.as_non_null
                local.get 48
                ref.as_non_null
                local.get 82
                call 96
                local.set 137
                local.get 137
                local.set 138
                ref.null 131
                local.set 129
                local.get 138
                if ;; label = @7
                  local.get 143
                  local.set 139
                  br 4 (;@3;)
                end
              end
            end
            local.get 90
            i32.const 1
            i32.add
            local.set 90
            br 0 (;@4;)
          end
        end
        ref.null 126
        local.set 143
      end
      ref.null 127
      local.set 142
      ref.null 120
      local.set 140
      local.get 139
      ref.is_null
      if ;; label = @2
        local.get 11
        ref.as_non_null
        local.set 86
        local.get 86
        ref.as_non_null
        local.set 141
        ref.null 120
        local.set 140
        block ;; label = @3
          loop ;; label = @4
            local.get 141
            ref.as_non_null
            struct.get 120 3
            local.set 140
            local.get 140
            ref.is_null
            br_if 1 (;@3;)
            local.get 140
            ref.as_non_null
            local.set 141
            br 0 (;@4;)
          end
        end
        ref.null 120
        local.set 140
        ref.null 120
        local.set 86
        local.get 141
        ref.as_non_null
        struct.get 120 0
        ref.as_non_null
        local.set 41
        ref.null 120
        local.set 141
        local.get 41
        ref.as_non_null
        struct.get 161 2
        ref.as_non_null
        local.set 64
        local.get 64
        ref.as_non_null
        struct.get 62 1
        local.set 126
        local.get 64
        ref.as_non_null
        struct.get 62 0
        local.set 104
        local.get 64
        ref.as_non_null
        struct.get 62 2
        local.set 105
        ref.null 62
        local.set 64
        ref.null 161
        local.set 41
        i32.const 4
        local.set 90
        i64.const 0
        local.set 92
        local.get 48
        ref.as_non_null
        local.set 103
        local.get 126
        local.get 104
        local.get 105
        local.get 126
        local.get 104
        local.get 105
        local.get 90
        local.get 92
        local.get 103
        local.get 11
        local.get 26
        ref.as_non_null
        call 83
        local.set 17
        local.set 16
        local.set 15
        local.set 14
        local.set 13
        local.get 16
        i32.const 1
        i32.eq
        if ;; label = @3
          br 2 (;@1;)
        end
        local.get 13
        local.set 128
        local.get 14
        local.set 111
        local.get 15
        local.set 127
        ref.null eq
        local.set 103
        ref.null eq
        local.set 105
      else
        local.get 139
        struct.get 126 1
        local.set 144
        local.get 144
        ref.as_non_null
        local.set 145
        local.get 144
        ref.as_non_null
        struct.get 124 4
        local.set 146
        local.get 146
        ref.is_null
        i32.eqz
        if ;; label = @3
          local.get 146
          local.set 145
        end
        local.get 145
        struct.get 124 1
        local.set 107
        local.get 145
        struct.get 124 0
        local.set 72
        local.get 72
        ref.as_non_null
        struct.get 62 1
        local.set 128
        local.get 72
        ref.as_non_null
        struct.get 62 0
        local.set 111
        local.get 72
        ref.as_non_null
        struct.get 62 2
        local.set 127
        ref.null 62
        local.set 72
        ref.null 124
        local.set 146
        ref.null 124
        local.set 145
        local.get 107
        ref.null 124
        local.set 144
        i32.eqz
        if ;; label = @3
          i32.const 0
          local.set 126
          i64.const 0
          local.set 104
          ref.null eq
          local.set 89
          i32.const 0
          local.set 107
          i32.const 0
          local.set 138
          local.get 22
          ref.as_non_null
          struct.get 110 0
          local.set 41
          local.get 41
          ref.as_non_null
          call 94
          local.get 41
          ref.as_non_null
          struct.get 161 5
          local.set 45
          i32.const 7
          local.set 90
          local.get 45
          ref.as_non_null
          local.get 90
          array.get 163
          local.set 70
          ref.null 163
          local.set 45
          local.get 70
          ref.as_non_null
          struct.get 62 1
          local.set 124
          local.get 70
          ref.as_non_null
          struct.get 62 0
          local.set 96
          local.get 70
          ref.as_non_null
          struct.get 62 2
          local.set 105
          i32.const 0
          local.get 124
          i32.const 6
          i32.eq
          i32.or
          local.get 124
          i32.const 7
          i32.eq
          i32.or
          local.get 124
          i32.const 8
          i32.eq
          i32.or
          local.get 124
          i32.const 9
          i32.eq
          i32.or
          i32.eqz
          if ;; label = @4
            unreachable
          end
          ref.null 62
          local.set 70
          i32.const 2956
          local.set 137
          local.get 137
          call 102
          local.set 129
          i32.const 3
          local.get 124
          local.get 96
          local.get 105
          local.get 129
          ref.as_non_null
          call 101
          local.set 49
          i32.const 6
          local.set 137
          i64.const 0
          local.set 92
          local.get 49
          ref.as_non_null
          local.set 103
          local.get 137
          local.set 126
          local.get 92
          local.set 104
          local.get 103
          local.set 89
          i32.const 1
          local.set 107
          i32.const 0
          local.set 138
          ref.null eq
          local.set 103
          ref.null 220
          local.set 49
          ref.null 131
          local.set 129
          ref.null eq
          local.set 105
          ref.null 161
          local.set 41
          local.get 126
          local.set 128
          local.get 104
          local.set 111
          local.get 89
          local.set 127
          local.get 126
          local.set 13
          local.get 104
          local.set 14
          local.get 89
          local.set 15
          local.get 107
          local.set 16
          local.get 138
          local.set 17
          ref.null eq
          local.set 89
          local.get 16
          i32.const 1
          i32.eq
          if ;; label = @4
            br 3 (;@1;)
          end
        end
      end
      ref.null 126
      local.set 139
      ref.null 131
      local.set 48
      local.get 16
      i32.const 1
      i32.eq
      if ;; label = @2
        br 1 (;@1;)
      end
      local.get 16
      i32.const 1
      i32.eq
      if ;; label = @2
        br 1 (;@1;)
      end
      local.get 16
      i32.const 1
      i32.eq
      if ;; label = @2
        br 1 (;@1;)
      end
      i32.const 0
      local.set 91
      i64.const 0
      local.set 94
      ref.null eq
      local.set 93
      local.get 91
      local.set 87
      local.get 94
      local.set 114
      local.get 93
      local.set 125
      local.get 95
      local.set 90
      local.get 80
      local.set 104
      local.get 97
      local.set 89
      local.get 16
      i32.const 1
      i32.eq
      if ;; label = @2
        br 1 (;@1;)
      end
      local.get 16
      i32.const 1
      i32.eq
      if ;; label = @2
        br 1 (;@1;)
      end
      local.get 104
      local.get 90
      local.get 89
      struct.new 62
      local.set 70
      ref.null eq
      local.set 89
      ref.null eq
      local.set 89
      local.get 70
      ref.as_non_null
      array.new_fixed 99 1
      local.set 27
      ref.null 62
      local.set 70
      global.get 2
      ref.as_non_null
      local.set 41
      local.get 128
      local.get 111
      local.get 127
      local.get 87
      local.get 114
      local.get 125
      local.get 27
      ref.as_non_null
      local.get 41
      ref.as_non_null
      local.get 11
      local.get 26
      ref.as_non_null
      call 95
      local.set 90
      local.set 107
      local.set 133
      local.set 130
      local.set 138
      local.get 41
      ref.as_non_null
      global.set 2
      ref.null 161
      local.set 41
      local.get 107
      i32.const 2
      i32.eq
      if ;; label = @2
        local.get 138
        local.set 138
        local.get 130
        local.set 130
        local.get 133
        local.set 133
        i32.const 0
        local.set 107
        i32.const 0
        local.set 90
      end
      local.get 107
      i32.const 1
      i32.eq
      if ;; label = @2
        local.get 138
        local.set 13
        local.get 130
        local.set 14
        local.get 133
        local.set 15
        local.get 107
        local.set 16
        local.get 90
        local.set 17
      end
      local.get 16
      i32.const 1
      i32.eq
      if ;; label = @2
        br 1 (;@1;)
      end
      local.get 138
      local.set 122
      local.get 130
      local.set 110
      local.get 133
      local.set 121
      ref.null eq
      local.set 133
      ref.null 99
      local.set 27
      ref.null eq
      local.set 125
      ref.null eq
      local.set 93
      ref.null eq
      local.set 127
      local.get 16
      i32.const 1
      i32.eq
      if ;; label = @2
        br 1 (;@1;)
      end
      local.get 16
      i32.const 1
      i32.eq
      if ;; label = @2
        br 1 (;@1;)
      end
      local.get 122
      local.set 13
      local.get 110
      local.set 14
      local.get 121
      local.set 15
      i32.const 0
      local.set 16
      i32.const 0
      local.set 17
      ref.null eq
      local.set 121
      i32.const 0
      local.set 13
      i64.const 0
      local.set 14
      ref.null eq
      local.set 15
    end
    local.get 57
    ref.is_null
    i32.eqz
    if ;; label = @1
      local.get 57
      ref.as_non_null
      local.set 60
      local.get 60
      ref.as_non_null
      struct.get 108 0
      local.set 66
      local.get 66
      ref.is_null
      i32.eqz
      if ;; label = @2
        local.get 66
        ref.as_non_null
        local.set 68
        local.get 58
        ref.as_non_null
        local.get 39
        local.get 37
        local.get 38
        call 88
        local.set 69
        ref.null 70
        local.set 65
        local.get 69
        ref.is_null
        i32.eqz
        if ;; label = @3
          local.get 69
          ref.as_non_null
          local.set 67
          local.get 67
          ref.as_non_null
          struct.get 74 1
          local.set 65
          ref.null 74
          local.set 67
        end
        ref.null 74
        local.set 69
        local.get 60
        ref.as_non_null
        struct.get 108 1
        local.set 70
        local.get 68
        ref.as_non_null
        struct.get 70 1
        local.set 71
        local.get 65
        local.get 66
        ref.eq
        local.get 68
        ref.as_non_null
        struct.get 70 0
        local.set 128
        local.get 128
        i32.const 1
        i32.and
        i32.eqz
        i32.and
        local.get 128
        i32.const 6
        i32.and
        i32.eqz
        i32.eqz
        i32.and
        local.get 71
        ref.as_non_null
        local.get 70
        ref.eq
        i32.and
        ref.null 61
        local.set 71
        if ;; label = @3
          local.get 59
          ref.as_non_null
          local.set 64
          local.get 68
          ref.as_non_null
          local.get 64
          ref.as_non_null
          struct.set 70 1
          local.get 60
          ref.as_non_null
          local.get 64
          ref.as_non_null
          struct.set 108 1
          ref.null 62
          local.set 64
        else
          local.get 60
          ref.as_non_null
          ref.null 70
          struct.set 108 0
          local.get 60
          ref.as_non_null
          ref.null 62
          struct.set 108 1
        end
        ref.null 62
        local.set 70
        ref.null 70
        local.set 65
        ref.null 70
        local.set 68
      end
      ref.null 70
      local.set 66
      ref.null 108
      local.set 60
    end
    local.get 55
    ref.is_null
    i32.eqz
    if ;; label = @1
      local.get 55
      ref.as_non_null
      local.set 60
      local.get 60
      ref.as_non_null
      struct.get 108 0
      local.set 65
      local.get 65
      ref.is_null
      i32.eqz
      if ;; label = @2
        local.get 65
        ref.as_non_null
        local.set 66
        local.get 56
        ref.as_non_null
        local.get 36
        local.get 50
        local.get 51
        call 88
        local.set 69
        ref.null 70
        local.set 68
        local.get 69
        ref.is_null
        i32.eqz
        if ;; label = @3
          local.get 69
          ref.as_non_null
          local.set 67
          local.get 67
          ref.as_non_null
          struct.get 74 1
          local.set 68
          ref.null 74
          local.set 67
        end
        ref.null 74
        local.set 69
        local.get 60
        ref.as_non_null
        struct.get 108 1
        local.set 70
        local.get 66
        ref.as_non_null
        struct.get 70 1
        local.set 71
        local.get 68
        local.get 65
        ref.eq
        local.get 66
        ref.as_non_null
        struct.get 70 0
        local.set 91
        local.get 91
        i32.const 1
        i32.and
        i32.eqz
        i32.and
        local.get 91
        i32.const 6
        i32.and
        i32.eqz
        i32.eqz
        i32.and
        local.get 71
        ref.as_non_null
        local.get 70
        ref.eq
        i32.and
        ref.null 61
        local.set 71
        if ;; label = @3
          local.get 47
          ref.as_non_null
          local.set 64
          local.get 66
          ref.as_non_null
          local.get 64
          ref.as_non_null
          struct.set 70 1
          local.get 60
          ref.as_non_null
          local.get 64
          ref.as_non_null
          struct.set 108 1
          ref.null 62
          local.set 64
        else
          local.get 60
          ref.as_non_null
          ref.null 70
          struct.set 108 0
          local.get 60
          ref.as_non_null
          ref.null 62
          struct.set 108 1
        end
        ref.null 62
        local.set 70
        ref.null 70
        local.set 68
        ref.null 70
        local.set 66
      end
      ref.null 70
      local.set 65
      ref.null 108
      local.set 60
    end
    local.get 53
    global.set 3
    local.get 35
    global.set 4
    local.get 13
    local.get 14
    local.get 15
    local.get 16
    local.get 17
    ref.null 62
    local.set 59
    ref.null 108
    local.set 57
    ref.null eq
    local.set 38
    ref.null 69
    local.set 58
    ref.null 62
    local.set 47
    ref.null 108
    local.set 55
    ref.null eq
    local.set 51
    ref.null 69
    local.set 56
    ref.null 107
    local.set 53
    i32.const 0
    local.set 35
    ref.null 130
    local.set 34
    ref.null 120
    local.set 33
    ref.null 99
    local.set 28
    ref.null eq
    local.set 32
    ref.null eq
    local.set 20
    ref.null 161
    local.set 23
    ref.null 110
    local.set 22
    ref.null 107
    local.set 21
    ref.null 109
    local.set 26
    ref.null 130
    local.set 12
    ref.null 120
    local.set 11
  )
