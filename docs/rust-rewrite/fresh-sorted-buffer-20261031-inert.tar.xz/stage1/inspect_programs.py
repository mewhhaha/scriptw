"""Inspect the compiler's actual emitted P modules without executing them."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import subprocess

OUT = Path(__file__).resolve().parent
DEST = OUT / 'program-inspection'
DEST.mkdir(exist_ok=True)
rows = []
for name in ['to-sorted-512.js', 'retained-objects.js', 'numeric-loop-50000.js', 'dynamic-string-4096.js']:
    path = OUT / 'baseline/original' / (name + '.wasm')
    payload = path.read_bytes()
    wat = subprocess.check_output([OUT / 'tools/wasm-tools', 'print', path], text=True)
    functions = []
    for match in re.finditer(r'^  \(func ([^\n]+)', wat, re.M):
        following = re.search(r'^  \(', wat[match.end():], re.M)
        end = match.end() + following.start() if following else len(wat) - 2
        body = wat[match.start():end]
        symbol = match[1].split(' (;')[0]
        calls = Counter(re.findall(r'^\s+(?:return_)?call (.+)$', body, re.M))
        row = dict(symbol=symbol, wat_bytes=len(body.encode()), wat_sha256=hashlib.sha256(body.encode()).hexdigest(),
                   local_declarations=len(re.findall(r'\(local ', body)), direct_call_sites=dict(calls))
        if symbol.startswith(('$js::', '$js-numeric::')):
            filename = name + '-' + str(len(functions)) + '.wat'
            (DEST / filename).write_text(body)
            row['body'] = 'program-inspection/' + filename
        functions.append(row)
    rows.append(dict(source=name, wasm_bytes=len(payload), wasm_sha256=hashlib.sha256(payload).hexdigest(),
                     inline_candidate_wasm_identical=payload == (OUT / 'candidate/original' / (name + '.wasm')).read_bytes(),
                     source_sha256=hashlib.sha256((OUT / 'sources' / name).read_bytes()).hexdigest(),
                     functions=functions))
report = dict(scope='Actual accepted baseline P modules from the original compiler-free cohort; static code observations, not a timing attribution.',
              source_fingerprint=json.loads((OUT / 'baseline/identity.json').read_text())['source_fingerprint'], programs=rows)
(OUT / 'program-emission.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps([dict(source=row['source'], wasm_bytes=row['wasm_bytes'], functions=len(row['functions']), inline_candidate_wasm_identical=row['inline_candidate_wasm_identical']) for row in rows], indent=2))
