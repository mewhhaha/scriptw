(function(){var a=[];for(var i=4096;i>0;i--)a.push(i);var s=0;function compare(a,b){return a-b;}for(var r=0;r<1024;r++){var b=a.toSorted(compare);s+=a[0]+b[0]+b[4095]+b.length;}print(s);})();
