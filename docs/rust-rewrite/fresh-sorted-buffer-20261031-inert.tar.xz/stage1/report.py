"""Retain the two rejected source-bound experiments without publishing scores."""
from pathlib import Path
import json
import platform
import subprocess

ROOT=Path(__file__).resolve().parents[2]
FIRST=ROOT/'target/performance-fresh-sort'
SECOND=ROOT/'target/performance-fresh-sort-outline'


def load(path):
    return json.loads(path.read_text())


def stage(directory,decision,analysis,verification):
    result=load(directory/decision)
    result.update(benchmark=load(directory/analysis),emitted_code=load(directory/'emitted-code.json'),
        verification=verification)
    return result


native=load(FIRST/'native-broad/receipt.json')
stages=[
    stage(FIRST,'stage1-rejected/decision.json','analysis.json',dict(
        source_guards_passed=359,native_default_release_scopes=[dict(target=r['target'],passed=int(r['summaries'][0][1]),
            failed=int(r['summaries'][0][2]),executable_sha256=r['executable_sha256']) for r in native],
        total_native_passed=2604,selected_original_test262=dict(toSorted=42,sort=107,total_passed=149,
            backend='wasm-aot',suite='test262/vendor/test262',threads=1,jobs=1,reuse_case_workers=True,timeout_ms=60000),
        product_graph='No interpreter in the default product dependency graph.')),
    stage(SECOND,'stage2-rejected/decision.json','discriminator-analysis.json',dict(
        source_guards_passed=359,normal_release_build='passed',raw_runtime_wasm_validation='both products passed',
        numeric_513_smoke='normal completion and exact output, 3 samples after 1 warmup',
        semantic_status='Not promoted; failed the predeclared discriminator before another broad native/selected Test262 build. Do not transfer stage1 passes to this ABI 43 product.')),
]
for item in stages:
    # The archive retains every raw observation. Keep the readable report's
    # complete comparison table without duplicating its536/240 raw round rows.
    item['benchmark'].pop('rows')
reference=load(FIRST/'reference-analysis.json')
cpu=next(line.split(':',1)[1].strip() for line in Path('/proc/cpuinfo').read_text().splitlines() if line.startswith('model name'))
report=dict(schema='scriptw-fresh-sorted-buffer-study-v1',date='2026-10-31',decision='both production experiments rejected and reverted',
    accepted_production=dict(source_parent=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
        source_fingerprint=load(FIRST/'baseline/identity.json')['source_fingerprint'],runtime_abi=42,
        behavior='Canonical per-element sorted-result publication remains; no production speedup or helper ABI change was kept.'),
    mechanism='The pure Number toSorted branch owns an independent sorted Number buffer but republishes it one element at a time. Both candidates transfer it into a typed, fresh unpublished Array, padding once to canonical power-of-two capacity and constructing the complete presence bitmap.',
    source_review='Astra at xhigh reviewed architecture and both implementation shapes; independent numerical gate review confirms both rejections.',
    machine=dict(platform=platform.platform(),cpu=cpu,tools=load(FIRST/'build-environment.json'),
        scriptc=reference['tools']['scriptc'],reference_zig=reference['tools']['zig'],wasmtime='vendored47.0.0',
        resource_policy='Local cgroup-v2 at 4096 MiB, swap 0, grouped OOM termination, one CPU; serial Cargo/libtest/compiler pools; 1 retained module / 64 MiB image cache; disk-backed task cache on btrfs.'),
    stages=stages,
    emitted_programs=load(FIRST/'program-emission.json'),
    diagnostic=dict(scope='Unscored single CLI invocation with one reused dense 4096 input and 1024 fresh sorted copies; includes compilation, loading, hashing and decompression.',
        baseline_instructions=3587678393,inline_instructions=2169534386,
        instruction_change_percent=100*(2169534386/3587678393-1),
        baseline_guest_profile=load(FIRST/'profile/baseline-guest-profile.json'),
        interpretation='One diagnostic per product, not a scored speedup. Sampled guest attribution uses its sole R/P perf map; publisher accounted for 30.82 percent of mapped guest samples. Positive mechanism evidence cannot override failed controls.'),
    same_machine_reference=dict(policy=reference['policy'].replace('unchanged sources', 'unchanged workloads, with the established Scriptc print adapter'),tools=reference['tools'],samples=reference['samples'],warmups=reference['warmups'],rounds=reference['rounds'],
        complete_original17_table=reference['summary'],
        limitations='Descriptive local source-bound cohort; not a refresh of published charts or a conformance claim. The inline candidate is rejected. Baseline ordinary RSS varies widely across invocations, including roughly one runtime-image-sized increment in some observations; no memory-saving attribution or RSS-parity claim follows.'),
    retained_work='Semantic and graph-snapshot regression coverage for empty/tiny/power-of-two/partial-word sorted outputs, source independence, descriptors, growth, holes and GC; five separate architecture hypotheses in docs/performance-hills.md.',
    restored_baseline_verification=load(FIRST/'restored-verification.json') if (FIRST/'restored-verification.json').exists() else None,
    limitations=['The original 536-invocation full cohort and 240-invocation outlined discriminator remain separate; all warmups, samples, means, outliers, checksums and source identities are retained.',
        'No causal claim explains non-target regressions. toSorted frame growth cannot directly explain empty joins; code placement, host effects and cache admission remain hypotheses.',
        'No full current-source default/all-feature/optimized native or pinned Test262 release acceptance was completed. Published conformance and benchmark figures retain their earlier source identities.',
        'Whole-workspace formatting already failed in 15 files before the work. Changed Rust files were separately formatted; unrelated files were preserved.'],
    harness_diagnostics=[
        'An ignored diagnostic file named inspect.py shadowed Python stdlib inspect; renamed before product freezing. Original failed receipt retained.',
        'The first profile completed all child commands; its final assertion omitted the CLI normal-outcome suffix. Corrected analysis checked all original outputs without rerunning or discarding them.',
        'Initial candidate source-draft folder collided with the frozen product directory. Drafts moved before freezing; original failure retained.',
        'Initial inert-Wasm selector also matched object_read_proxy; corrected to an exact symbol boundary before obtaining complete results.',
        'All536 measurement commands completed; the original aggregation read the wrong ordinary timing field. Corrected aggregation uses the original execution_ns samples, with no timing rerun or sample exclusion.'],
    evidence=dict(archive='fresh-sorted-buffer-20261031-inert.tar.xz',archive_sha256=None,index='evidence-index.json',
        policy='Only inert regular source, patch, JSON, CSV and text records. Native hosts,serialized native images, emitted Wasm, runtime caches, toolchains, raw perf binaries and full runtime WAT are excluded. Their original digests remain provenance, not native-code admission authority.'))
target=ROOT/'docs/rust-rewrite/fresh-sorted-buffer-20261031.json'
target.write_text(json.dumps(report,indent=2)+'\n')
print(target)
