"""Check the affected modules against the restored production source."""
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
folder = OUT / 'restored-focused'
folder.mkdir(exist_ok=True)
artifacts = {}
for line in (OUT / 'restored-native-build.jsonl').read_text().splitlines():
    row = json.loads(line)
    if row.get('reason') == 'compiler-artifact' and row.get('executable'):
        artifacts[row['target']['name']] = row
receipt = []
for target, selection in [('aot_builtins', 'aot_array_private_buffers::'),
                          ('aot_gc_entries', 'aot_gc_packed_array_storage::')]:
    producer = artifacts[target]
    executable = Path(producer['executable'])
    identity = hashlib.sha256(executable.read_bytes()).hexdigest()
    argv = [str(executable), selection, '--test-threads=1', '--nocapture']
    with (folder / (target + '.stdout')).open('w') as stdout, (folder / (target + '.stderr')).open('w') as stderr:
        result = subprocess.run(argv, cwd=ROOT, stdout=stdout, stderr=stderr, timeout=1800)
    output = (folder / (target + '.stdout')).read_text()
    summaries = re.findall(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;.*?(\d+) filtered out;', output)
    entry = dict(target=target, argv=argv, executable_sha256=identity, producer=producer,
                 exit_code=result.returncode, summaries=summaries)
    receipt.append(entry)
    assert hashlib.sha256(executable.read_bytes()).hexdigest() == identity
    assert result.returncode == 0 and len(summaries) == 1 and int(summaries[0][1]) > 0
    print(target, summaries, flush=True)
report = dict(source_fingerprint=json.loads((OUT / 'baseline/identity.json').read_text())['source_fingerprint'],
              runtime_abi=42, production_sources_restored=True, native_scopes=receipt,
              total_passed=sum(int(r['summaries'][0][1]) for r in receipt))
(OUT / 'restored-verification.json').write_text(json.dumps(report, indent=2) + '\n')
