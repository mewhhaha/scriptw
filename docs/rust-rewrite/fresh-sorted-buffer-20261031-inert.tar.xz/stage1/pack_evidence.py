"""Archive inert records from both rejected products; exclude executable images."""
import hashlib
import io
import json
from pathlib import Path
import stat
import tarfile

ROOT = Path(__file__).resolve().parents[2]
FIRST = ROOT / 'target/performance-fresh-sort'
SECOND = ROOT / 'target/performance-fresh-sort-outline'
TARGET = ROOT / 'docs/rust-rewrite/fresh-sorted-buffer-20261031-inert.tar.xz'
records = {}


def retain(name, path):
    if not stat.S_ISREG(path.lstat().st_mode):
        return
    payload = path.read_bytes()
    assert not payload.startswith((b'\x7fELF', b'\0asm', b'MZ'))
    payload.decode('utf-8')
    assert name not in records
    records[name] = payload


directories = {'sources', 'retained-sources', 'expected', 'raw', 'profile',
               'native-focused', 'native-broad', 'restored-focused', 'program-inspection',
               'test262-sort', 'test262-to-sorted', 'stage1-rejected', 'stage2-rejected'}
extensions = {'.json', '.jsonl', '.log', '.stdout', '.stderr', '.py', '.patch', '.txt', '.csv', '.map', '.js', '.mjs', '.inventory', '.rs', '.md', '.wat'}
for prefix, base in [('stage1', FIRST), ('stage2', SECOND)]:
    for path in sorted(base.iterdir()):
        if path.is_symlink():
            continue
        if path.is_file() and path.suffix in extensions:
            retain(prefix + '/' + path.name, path)
        elif path.name in directories:
            for child in sorted(path.rglob('*')):
                if child.is_file() and child.suffix in extensions:
                    retain(prefix + '/' + str(child.relative_to(base)), child)
    for product in ['baseline', 'candidate']:
        for name in ['identity.json', 'products.json', 'source.json', 'source.patch']:
            retain(f'{prefix}/{product}/{name}', base / product / name)
        for path in sorted((base / product / 'inspection').iterdir()):
            if path.name not in {'runtime.wat', 'runtime.wasm'}:
                retain(f'{prefix}/{product}/inspection/{path.name}', path)
for name in ['provenance.json', 'wasm-tools-provenance.json', 'perf/provenance.json']:
    retain('stage1/tool-provenance/' + name, FIRST / 'tools' / name)
rows = [dict(path=name, bytes=len(payload), sha256=hashlib.sha256(payload).hexdigest())
        for name, payload in sorted(records.items())]
index = dict(schema='scriptw-inert-experiment-evidence-v1', files=rows,
             member_count=len(rows), expanded_bytes=sum(row['bytes'] for row in rows),
             policy='Text-only regular files; no binaries, serialized images, caches, toolchains, raw perf data or full runtime WAT. Paths are relative and extraction requires no execution.')
records['evidence-index.json'] = (json.dumps(index, indent=2) + '\n').encode()
with tarfile.open(TARGET, 'w:xz', preset=6, format=tarfile.PAX_FORMAT) as archive:
    for name, payload in sorted(records.items()):
        member = tarfile.TarInfo(name)
        member.size, member.mode, member.mtime = len(payload), 0o644, 0
        archive.addfile(member, io.BytesIO(payload))
with tarfile.open(TARGET, 'r:xz') as archive:
    members = archive.getmembers()
    assert len(members) == len(records)
    for member in members:
        assert member.isreg() and not member.name.startswith('/') and '..' not in Path(member.name).parts
        assert archive.extractfile(member).read() == records[member.name]
report_path = TARGET.with_name('fresh-sorted-buffer-20261031.json')
report = json.loads(report_path.read_text())
report['evidence'].update(archive_sha256=hashlib.sha256(TARGET.read_bytes()).hexdigest(),
                          archive_bytes=TARGET.stat().st_size, member_count=len(records),
                          expanded_bytes=sum(map(len, records.values())))
report_path.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report['evidence'], indent=2))
