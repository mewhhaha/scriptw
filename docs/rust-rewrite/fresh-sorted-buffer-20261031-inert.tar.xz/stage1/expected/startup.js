scriptw-startup-ok
