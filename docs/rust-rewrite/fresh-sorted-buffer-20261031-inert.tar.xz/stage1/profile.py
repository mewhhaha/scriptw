"""Unscored single-program CPU diagnostic, using the existing perf-map hook."""
import argparse
import os
import re
import shutil
import subprocess
from measure import OUT, ROOT, invoke, save, digest, verify_product

if __name__ == '__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('label',choices=['baseline','candidate'])
    args=parser.parse_args()
    label=args.label
    verify_product(label)
    folder=OUT/'profile'
    folder.mkdir(exist_ok=True)
    source=folder/'reused-input-sort-4096.js'
    text='(function(){var a=[];for(var i=4096;i>0;i--)a.push(i);var s=0;function compare(a,b){return a-b;}for(var r=0;r<1024;r++){var b=a.toSorted(compare);s+=a[0]+b[0]+b[4095]+b.length;}print(s);})();\n'
    if source.exists(): assert source.read_text()==text
    else: source.write_text(text)
    perf=OUT/'tools/perf/usr/bin/perf'
    os.environ['LD_LIBRARY_PATH']=str(OUT/'tools/perf/usr/lib')
    cli=OUT/label/'scriptw'
    invoke('profile-'+label+'-prime',[cli,'--jobs','1','run',source])
    stat=folder/(label+'-stat.csv')
    invoke('profile-'+label+'-stat',[perf,'stat','-x',';','-e','instructions:u,cycles:u,branches:u,branch-misses:u','-o',stat,'--',cli,'--jobs','1','run',source])
    os.environ['SCRIPTW_PERF_MAP_DIR']='/tmp'
    data=folder/(label+'.perf.data')
    invoke('profile-'+label+'-record',[perf,'record','-e','cycles:u','-c','1000000','--clockid','mono','-o',data,'--',cli,'--jobs','1','run',source])
    pids=subprocess.check_output([perf,'script','-i',data,'-F','pid'],text=True)
    ids=set(re.findall(r'\d+',pids))
    assert len(ids)==1,ids
    pid=ids.pop()
    for suffix in ['map','map.identity']:
        shutil.copyfile('/tmp/perf-'+pid+'.'+suffix,folder/(label+'.'+suffix))
    report=subprocess.run([perf,'report','-i',data,'--stdio','--no-children','--sort','symbol','--percent-limit','0.5','-n'],text=True,capture_output=True,check=True)
    (folder/(label+'-report.txt')).write_text(report.stdout)
    (folder/(label+'-report.stderr')).write_text(report.stderr)
    for stage in ['prime','stat','record']:
        actual=(OUT/'raw'/('profile-'+label+'-'+stage+'.stdout')).read_text()
        assert actual == '12583936\nrun outcome: RunOutcome { backend_used: WasmAot, note: "wasm-aot completion: undefined(undefined)" }\n', repr(actual)
    save(folder/(label+'-identity.json'),dict(source_sha256=digest(source),cli_sha256=digest(cli),
        perf_sha256=digest(perf),scope='Unscored original-script single invocation; one unchanged dense4096 input,1024 fresh sorted copies; compilation/loading included in whole-process counters/profile. Existing perf map contains the sole R/P pair; no dynamic source execution. Not an ordinary17 or retained-call score.'))
