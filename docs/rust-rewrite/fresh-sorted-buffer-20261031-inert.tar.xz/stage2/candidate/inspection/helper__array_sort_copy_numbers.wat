  (func $helper::array_sort_copy_numbers (;1138;) (type 423) (param (ref 139) (ref 94) i64)
    (local (ref null 120) (ref null 130) i32 i64 eqref i32 i32 (ref null 139) (ref null 94) i32 i32 (ref null 94) (ref null 94) i32 (ref null 95) i32 i32 i32 i64)
    ref.null 120
    local.set 3
    ref.null 130
    local.set 4
    i32.const 0
    local.set 5
    i64.const 0
    local.set 6
    ref.null eq
    local.set 7
    i32.const 0
    local.set 8
    i32.const 0
    local.set 9
    local.get 0
    local.set 10
    local.get 1
    local.set 11
    local.get 2
    i32.wrap_i64
    local.set 12
    local.get 12
    if ;; label = @1
      i32.const 1
      i32.const 32
      local.get 12
      i32.const 1
      i32.sub
      i32.clz
      i32.sub
      i32.shl
      local.set 13
      local.get 11
      ref.as_non_null
      local.set 14
      local.get 13
      local.get 12
      i32.ne
      if ;; label = @2
        i64.const 0
        local.get 13
        array.new 94
        local.set 15
        local.get 15
        ref.as_non_null
        i32.const 0
        local.get 11
        ref.as_non_null
        i32.const 0
        local.get 12
        array.copy 94 94
        local.get 15
        ref.as_non_null
        local.set 14
        ref.null 94
        local.set 15
      end
      local.get 13
      i32.const 63
      i32.add
      i32.const 6
      i32.shr_u
      local.set 16
      i64.const 0
      local.get 16
      array.new 95
      local.set 17
      local.get 12
      i32.const 6
      i32.shr_u
      local.set 18
      i32.const 0
      local.set 19
      block ;; label = @2
        loop ;; label = @3
          local.get 19
          local.get 18
          i32.ge_u
          br_if 1 (;@2;)
          local.get 17
          ref.as_non_null
          local.get 19
          i64.const -1
          array.set 95
          local.get 19
          i32.const 1
          i32.add
          local.set 19
          br 0 (;@3;)
        end
      end
      local.get 12
      i32.const 63
      i32.and
      local.set 20
      local.get 20
      if ;; label = @2
        i64.const 1
        local.get 20
        i64.extend_i32_u
        i64.shl
        i64.const 1
        i64.sub
        local.set 21
        local.get 17
        ref.as_non_null
        local.get 19
        local.get 21
        array.set 95
      end
      local.get 10
      ref.as_non_null
      local.get 14
      ref.as_non_null
      struct.set 139 7
      local.get 10
      ref.as_non_null
      local.get 17
      ref.as_non_null
      struct.set 139 8
      local.get 10
      ref.as_non_null
      local.get 2
      struct.set 139 3
      ref.null 95
      local.set 17
      ref.null 94
      local.set 14
    end
    ref.null 94
    local.set 11
    ref.null 139
    local.set 10
  )
