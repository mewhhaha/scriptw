"""Inspect only this run's own emitted Wasm and inert native runtime files."""
from pathlib import Path
import hashlib
import json
import re
import struct
import subprocess
from measure import OUT, save, load, verify_product
from benchmark_metrics import digest

WANTED = ['builtin::Array.prototype.toSorted', 'builtin::Array.prototype.sort', 'helper::object_read', 'helper::array_indexed_publish_default_data', 'helper::array_sort_copy_numbers']


def inspect(label):
    identity=verify_product(label)
    directory=OUT/label/'inspection'
    directory.mkdir(exist_ok=True)
    package=OUT/label/'runtime-build/scriptw-runtime-portable-package.bin'
    data=package.read_bytes()
    assert data[:8]==b'SCRWRB01'
    assert hashlib.sha256(data[:-32]).digest()==data[-32:]
    assert data[12:44].hex()==identity['source_fingerprint']
    length=struct.unpack_from('<Q',data,128)[0]
    wasm=data[136:-32]
    assert len(wasm)==length and wasm[:8]==b'\0asm\1\0\0\0'
    raw=directory/'runtime.wasm'
    raw.write_bytes(wasm)
    subprocess.run([OUT/'tools/wasm-tools','validate',raw,'--features','all'],check=True)
    wat=directory/'runtime.wat'
    subprocess.run([OUT/'tools/wasm-tools','print',raw,'-o',wat],check=True)
    text=wat.read_text()
    functions={}
    for wanted in [name for name in WANTED if label == 'candidate' or name != 'helper::array_sort_copy_numbers']:
        # Named definitions have two-space indentation; function-internal forms
        # have deeper indentation. Preserve exact original textual bodies.
        definitions=[match for match in re.finditer(r'^  \(func ([^\n]+)',text,re.M) if re.search(re.escape(wanted) + r'(?=[\"\s])', match[1])]
        assert len(definitions)==1,(wanted,len(definitions))
        start=definitions[0].start()
        following=re.search(r'^  \(',text[definitions[0].end():],re.M)
        assert following is not None
        end=definitions[0].end()+following.start()
        body=text[start:end]
        path=directory/(wanted.replace(':','_').replace('.','_')+'.wat')
        path.write_text(body)
        functions[wanted]=dict(wat_sha256=hashlib.sha256(body.encode()).hexdigest(),wat_bytes=len(body.encode()),
            direct_call_sites=len(re.findall(r'^    +(?:return_)?call ',body,re.M)),
            local_declarations=len(re.findall(r'\(local ',body)),
            raw=str(path.relative_to(OUT)))
    native=OUT/label/'runtime-build/scriptw-runtime-portable-native.bin'
    assert native.read_bytes()[:4]==b'\x7fELF'
    symbols=subprocess.check_output(['nm','-S','--defined-only','--format=posix',native],text=True)
    (directory/'native-symbols.txt').write_text(symbols)
    for wanted in [name for name in WANTED if label == 'candidate' or name != 'helper::array_sort_copy_numbers']:
        matches=[]
        for line in symbols.splitlines():
            match=re.fullmatch(r'(.+) [tT] ([0-9a-f]+) ([0-9a-f]+)',line)
            if match and match[1].endswith('::'+wanted): matches.append(match)
        assert len(matches)==1,(wanted,len(matches))
        match=matches[0]
        address,size=int(match[2],16),int(match[3],16)
        disassembly=subprocess.check_output(['objdump','-d',f'--start-address={address}',f'--stop-address={address+min(size,256)}',native],text=True)
        path=directory/(wanted.replace(':','_').replace('.','_')+'-native-entry.txt')
        path.write_text(disassembly)
        frames=re.findall(r'\bsub\s+\$0x([0-9a-f]+),%rsp',disassembly)
        functions[wanted].update(native_bytes=size,observed_entry_stack_reservation_bytes=int(frames[0],16) if frames else None,native_entry=str(path.relative_to(OUT)))
    return dict(runtime_wasm_sha256=digest(raw),runtime_wasm_bytes=len(wasm),native_sha256=digest(native),native_bytes=native.stat().st_size,functions=functions)


if __name__=='__main__':
    save(OUT/'emitted-code.json',{label:inspect(label) for label in ['baseline','candidate']})
