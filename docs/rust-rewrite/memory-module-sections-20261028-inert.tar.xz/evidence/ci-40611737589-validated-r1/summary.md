CI40611737589: 68/68 scored attempts,17 workload checksums, six actual engine controls and all four v2 ownership/host captures validated.
Exact feature1fd parser/section joins reproduced from raw snapshots. Scored Portable R runtime key matches prior core1721/layout29; no cross-runner native equality is claimed.
CLI example-test raw job output is unavailable; no exact CLI example pass count is claimed.

| Case | R image pages | Text pages | Nontext image pages | Mixed | Boundary | Uncovered | Header overlap | Section-table overlap |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| integer.js | 680 | 461 | 219 | 7 | 7 | 0 | 1 | 1 |
| retained-objects.js | 968 | 557 | 411 | 8 | 8 | 0 | 1 | 1 |

Retained warm after_store_drop at observation16; overlapping counts below must not be summed.

| Case | Nontext R section | Section bytes | Present-page overlaps | Full present pages |
|---|---|---:|---:|---:|
| integer.js | .wasmtime.engine | 1102 | 1 | 0 |
| integer.js | .wasmtime.bti | 1 | 1 | 0 |
| integer.js | .eh_frame | 107316 | 27 | 26 |
| integer.js | .wasmtime.addrmap | 7182758 | 8 | 7 |
| integer.js | .wasmtime.stackmap | 4294388 | 0 | 0 |
| integer.js | .wasmtime.traps | 2112068 | 0 | 0 |
| integer.js | .wasmtime.exceptions | 25544 | 5 | 4 |
| integer.js | .rodata.wasm | 2039616 | 147 | 145 |
| integer.js | .name.wasm | 38327 | 10 | 8 |
| integer.js | .wasmtime.info | 61968 | 16 | 14 |
| integer.js | .symtab | 54072 | 2 | 1 |
| integer.js | .strtab | 111597 | 8 | 7 |
| integer.js | .shstrtab | 187 | 1 | 0 |
| retained-objects.js | .wasmtime.engine | 1102 | 1 | 0 |
| retained-objects.js | .wasmtime.bti | 1 | 1 | 0 |
| retained-objects.js | .eh_frame | 107316 | 27 | 26 |
| retained-objects.js | .wasmtime.addrmap | 7182758 | 10 | 8 |
| retained-objects.js | .wasmtime.stackmap | 4294388 | 191 | 190 |
| retained-objects.js | .wasmtime.traps | 2112068 | 0 | 0 |
| retained-objects.js | .wasmtime.exceptions | 25544 | 5 | 4 |
| retained-objects.js | .rodata.wasm | 2039616 | 147 | 145 |
| retained-objects.js | .name.wasm | 38327 | 10 | 8 |
| retained-objects.js | .wasmtime.info | 61968 | 16 | 14 |
| retained-objects.js | .symtab | 54072 | 2 | 1 |
| retained-objects.js | .strtab | 111597 | 8 | 7 |
| retained-objects.js | .shstrtab | 187 | 1 | 0 |

The measured nontext leaders differ: integer R .rodata.wasm; retained-objects R .wasmtime.stackmap. Inspect required data/GC metadata origins before a matched intervention; section size/presence establishes no saving or live heap ownership and does not authorize dropping stack maps. Warm history contains16 earlier calls; no last-sample causal/bootstrap claim follows. Native payloads were not retained/executed.
