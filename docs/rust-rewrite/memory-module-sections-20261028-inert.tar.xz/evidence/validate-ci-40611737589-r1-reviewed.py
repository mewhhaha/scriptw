"""Inert v2 owned-section admission; no build, workload or native image loading."""
import ast
from datetime import datetime,timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import sys
from types import SimpleNamespace

BASE=Path(__file__).resolve().parent
ROOT=BASE.parents[1]
WORKTREE=ROOT/'target/memory-module-sections-20261028'
SCRIPTS=WORKTREE/'scripts'
SOURCE='45f26184b16ba0841346c537e517112d08aa74ab'
FEATURE='1fd6940fb3db57b999dc535595f5a185870cae69'
FINGERPRINT='38dcec36d31ea52fed69deb88b1fd81fc02ded4b81b3f33859280c1f8df8bec2'
LOCAL_FP='bed084c3e91f79d617b9f29e5802c6fe0bfe8a0b4d3192cc73160aca1b23dbf4'
RUN=40611737589
SCORED=BASE/'github-40611737589-scored/precompiled-evidence/report.json'
DIAGNOSTIC=BASE/'github-40611737589-diagnostic'
OUT=BASE/'ci-40611737589-validated-r1'
PRIOR_ROOT=ROOT/'target/memory-ordered-bootstrap-20261027-evidence'
PRIOR_SCORED=PRIOR_ROOT/'github-40611080497-scored/precompiled-evidence/report.json'
PATTERN=ROOT/'target/memory-module-ownership-20261027-evidence/validate-ci-40594118953.py'
PATTERN_SHA='1455de1eb46d3190cafc4bf33150baa236e648287e1b31df404b55293e88a70b'
sys.path.insert(0,str(ROOT/'scripts'))
import precompiled_comparison as p
from limited_verification import require_kernel_budget,kernel_group
from native_test_protocol import result_summaries
sys.path.insert(0,str(SCRIPTS))
import benchmark_module_images as m
import benchmark_module_sections as sections
spec=importlib.util.spec_from_file_location('section_owned_endpoint_contract',SCRIPTS/'diagnose-precompiled-mappings.py')
d=importlib.util.module_from_spec(spec);spec.loader.exec_module(d)
PHASES=list(d.PHASES)
EXPECTED_CASES=[(runtime,name) for name in ('integer.js','retained-objects.js') for runtime in ('scriptw','scriptc')]
INPUTS={}
args=SimpleNamespace(scored_report=SCORED)


def file_sha(path):
    with Path(path).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()


assert file_sha(PATTERN)==PATTERN_SHA
tree=ast.parse(PATTERN.read_text(),filename=str(PATTERN))
exec(compile(ast.Module(body=[node for node in tree.body if isinstance(node,ast.FunctionDef)],type_ignores=[]),str(PATTERN)+':inert-definitions','exec'),globals())


def metadata(path,cap=64*1024**2):
    path=Path(path);info=path.lstat()
    assert stat.S_ISREG(info.st_mode) and not path.is_symlink() and path.resolve()==path and info.st_size<=cap
    with path.open('rb') as stream:magic=stream.read(8)
    assert not magic.startswith((b'\x7fELF',b'MZ',b'SWRTZ001',b'SCRWRB',b'SCRWEP',b'SCRWWA',b'SCRWNR'))
    INPUTS[str(path)]=dict(bytes=info.st_size,sha256=file_sha(path))
    return INPUTS[str(path)]


def json_input(path,cap=16*1024**2):
    metadata(path,cap);return p._json(Path(path).read_bytes())


def counters(group):
    return {key:(group/key).read_text().strip() for key in ('memory.max','memory.swap.max','memory.oom.group','memory.peak','memory.events')}


def no_oom(before,after,maximum):
    for row in (before,after):
        assert 0<int(row['memory.max'])<=maximum and row['memory.swap.max']=='0' and row['memory.oom.group']=='1'
    events=[dict(line.split() for line in row['memory.events'].splitlines()) for row in (before,after)]
    assert all(events[0][key]==events[1][key]=='0' for key in ('oom','oom_kill','oom_group_kill'))


def root_state():
    assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=ROOT)
    return subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()


def native_controls():
    directory=BASE/'github-40611737589-scored'
    out=directory/'module-sections-native.stdout';err=directory/'module-sections-native.stderr'
    metadata(out,32*1024**2);metadata(err,32*1024**2)
    expected={
        'embedding::benchmark_module_images::sections::tests::malformed_headers_extended_counts_and_table_extents_are_rejected',
        'embedding::benchmark_module_images::sections::tests::name_budget_is_aggregate_even_for_omitted_logical_sections',
        'embedding::benchmark_module_images::sections::tests::names_require_unique_bounded_terminated_utf8_and_in_table_offsets',
        'embedding::benchmark_module_images::sections::tests::relocatable_no_program_headers_yields_only_exact_file_backed_metadata',
        'embedding::benchmark_module_images::sections::tests::section_arithmetic_overlap_nobits_and_text_anchors_fail_closed',
        'embedding::tests::benchmark_module_images::diagnostic_images_match_actual_program_runtime_and_survive_store_drop'}
    text=out.read_text();names=re.findall(r'^test ([^\r\n]+) \.\.\. ok$',text,re.M)
    assert len(names)==len(set(names))==6 and set(names)==expected
    summary=result_summaries(text)
    assert len(summary)==1 and summary[0][:5]==('ok','6','0','0','0')
    return dict(status='validated',passed=6,test_ids=names,summary=summary,
        stdout_sha256=INPUTS[str(out)]['sha256'],stderr_sha256=INPUTS[str(err)]['sha256'])


def section_summary(diagnostic,campaign):
    summaries=[]
    for case in diagnostic['cases']:
        if case['runtime']!='scriptw':continue
        assert case['status']=='validated'
        runtime=next(owner for owner in case['module_attribution']['owners'] if owner['role']=='runtime')
        assert runtime['relation']=='text-inside-image'
        meta=runtime['section_metadata']
        assert meta['schema']=='scriptw-module-sections-v1' and meta['serialized_bytes']==runtime['image']['end']-runtime['image']['start']
        phases=[]
        for phase in runtime['phases']:
            value=phase['sections']
            assert value['image_present_pages']==phase['image_present_pages']
            assert value['nontext_image_present_pages']==phase['image_present_pages']-phase['text_present_pages']
            phases.append(dict(phase=phase['phase'],page_bytes=phase['page_bytes'],image_present_pages=phase['image_present_pages'],
                text_present_pages=phase['text_present_pages'],nontext_image_present_pages=value['nontext_image_present_pages'],
                section_union_present_pages=value['section_union_present_pages'],mixed_section_present_pages=value['mixed_section_present_pages'],
                section_boundary_present_pages=value['section_boundary_present_pages'],uncovered_present_image_pages=value['uncovered_present_image_pages'],
                elf_header_present_page_overlaps=value['elf_header_present_page_overlaps'],section_headers_present_page_overlaps=value['section_headers_present_page_overlaps'],
                nontext_sections=[row for row in value['sections'] if row['name']!='.text']))
        warm=phases[-1]
        ranked=sorted(warm['nontext_sections'],key=lambda row:(row['full_present_pages'],row['present_page_overlaps']),reverse=True)
        summaries.append(dict(file=case['file'],serialized_bytes=meta['serialized_bytes'],serialized_sha256=meta['serialized_sha256'],
            phases=phases,largest_warm_nontext_section_by_whole_present_pages=ranked[0],
            interpretation='after_store_drop is the retained warm endpoint at observation16, after16 earlier calls. Section overlaps share boundary pages; never sum overlap counts or prorate RSS.'))
    assert len(summaries)==2
    return summaries


def main():
    require_kernel_budget(1024**3)
    assert sorted(os.sched_getaffinity(0))==[0] and not OUT.exists()
    root_before=root_state();group=kernel_group();OUT.mkdir()
    report=dict(schema='scriptw-module-sections-ci-validation-v1',complete=False,source_commit=SOURCE,feature_source_commit=FEATURE,
        source_fingerprint=FINGERPRINT,run=RUN,processing_checkout_commit=root_before,started_at=datetime.now(timezone.utc).isoformat(),
        cpu_affinity=[0],before=counters(group),driver_sha256=file_sha(Path(__file__)),reused_validator_sha256=PATTERN_SHA)
    try:
        for module,name in [(m,'benchmark_module_images.py'),(sections,'benchmark_module_sections.py'),(d,'diagnose-precompiled-mappings.py')]:
            path=SCRIPTS/name
            assert Path(module.__file__).resolve()==path
            raw=path.read_bytes()
            assert raw==subprocess.check_output(['git','show',FEATURE+':scripts/'+name],cwd=ROOT)
            assert raw==subprocess.check_output(['git','show',SOURCE+':scripts/'+name],cwd=ROOT)
            metadata(path)
            report.setdefault('validator_sources',{})[name]=dict(source_commit=FEATURE,sha256=file_sha(path))
        assert Path(m.module_sections.__file__).resolve()==SCRIPTS/'benchmark_module_sections.py'
        assert d.module_images is m
        assert (ROOT/'scripts/precompiled_comparison.py').read_bytes()==subprocess.check_output(['git','show',FEATURE+':scripts/precompiled_comparison.py'],cwd=ROOT)
        metadata(ROOT/'scripts/precompiled_comparison.py')
        binding=json_input(BASE/'source-bindings-sections-equivalence.json')
        assert binding['feature_source']==FEATURE and binding['probe_source']==SOURCE
        assert binding['computed_compiler_inputs_equal'] is True and binding['probe_only_branch_guard'] is True
        for revision in (SOURCE,FEATURE):
            for ignored,fp in [(False,FINGERPRINT),(True,LOCAL_FP)]:
                rows=[row for row in binding['rows'] if row['revision']==revision and row['extra_ignored_regress_lock'] is ignored]
                assert len(rows)==1 and rows[0]['source_fingerprint']==fp
        run=json_input(BASE/'github-run-40611737589.json')
        assert run['databaseId']==RUN and run['headSha']==SOURCE and run['status']=='completed' and run['conclusion']=='success'
        assert len(run['jobs'])==1 and run['jobs'][0]['name']=='measure' and run['jobs'][0]['conclusion']=='success'
        for name in ('Verify and build the shared host','Measure both compiler-free consumers','Observe unscored consumer mappings','Retain all raw observations and failures'):
            steps=[step for job in run['jobs'] for step in job['steps'] if step['name']==name]
            assert len(steps)==1 and steps[0]['conclusion']=='success'
        metadata(SCORED,p.MAX_REPORT)
        campaign,table=p.load_report(SCORED)
        assert campaign['source_commit']==SOURCE and campaign['source_fingerprint']==FINGERPRINT
        assert campaign['tools']['consumer']['cargo_producer']['features']==['benchmark-module-images']
        assert len(campaign['attempts'])==68 and len(table)==17 and all(row['status']=='ok' for row in campaign['attempts'])
        for row in campaign['retained_files']:
            value=metadata(SCORED.parent/p.safe_name(row['path']))
            assert value['bytes']==row['bytes'] and value['sha256']==row['sha256']
        report.update(scored_admitted=True,scored_attempts=68,scored_workloads=17,scored_all_attempts_ok=True,scored_table=table,
            native_controls=native_controls(),cli_example_controls=dict(status='raw-job-log-unavailable',exact_pass_count=None,
                ci_build_step_success=True,reason='Downloaded scored/native artifacts retain the six engine controls; no raw CLI example-test job log is present. No CLI example count is inferred.'))
        report['diagnostic']=diagnostic(DIAGNOSTIC,campaign,run)
        assert report['diagnostic']['status']=='validated' and len(report['diagnostic']['cases'])==4
        report['runtime_sections']=section_summary(report['diagnostic'],campaign)
        metadata(PRIOR_SCORED,p.MAX_REPORT)
        prior,prior_table=p.load_report(PRIOR_SCORED)
        assert prior['source_commit']=='1721e1b6daf39924dabee7e85112adc2ebed4c9d' and len(prior_table)==17
        prior_receipt_path=PRIOR_ROOT/'ci-40611080497-validated/report.json'
        assert file_sha(prior_receipt_path)=='8993659b61ac82a5b09a7a07df8f8502318c1855b710a649fb96402b40c255f4'
        prior_receipt=json_input(prior_receipt_path)
        runtime_keys={attempt['image']['runtime_key'] for attempt in campaign['attempts'] if attempt['runtime']=='scriptw'}
        prior_keys={attempt['image']['runtime_key'] for attempt in prior['attempts'] if attempt['runtime']=='scriptw'}
        assert runtime_keys==prior_keys and len(runtime_keys)==1 and None not in runtime_keys
        static=prior_receipt['static']['ci']['variants']['Portable']['package']
        assert static['layout']==29 and static['runtime_key']==next(iter(runtime_keys))
        report['runtime_identity_comparison']=dict(prior_run=40611080497,current_run=RUN,runtime_keys=sorted(runtime_keys),layout=29,
            prior_raw_wasm_sha256=static['wasm_sha256'],prior_raw_wasm_bytes=static['wasm_bytes'],
            interpretation='The admitted scored Portable R content key equals the prior validated layout29 key, which hashes layout+raw R Wasm. This binds unchanged raw runtime identity; it does not assert cross-runner native byte equality.')
        for case in report['diagnostic']['cases']:case.pop('host_function_overlap',None)
        report['next_measurement_targets']=[dict(file=item['file'],section=item['largest_warm_nontext_section_by_whole_present_pages'],
            evidence='Largest nontext section by full present pages in this retained warm R observation.',
            constraint='Inspect required runtime data or GC metadata origins before a matched intervention. Presence does not identify live JS objects or authorize omitting globals/data/GC stack maps.') for item in report['runtime_sections']]
        failure_path=BASE/'ci-40611737589-validated/report.json'
        assert file_sha(failure_path)=='25917f3e69e687791d585b55d0e21a99a949367f01e99e5eabcc4ae66f53219b'
        metadata(failure_path)
        report['prior_processing_failure']=dict(report_sha256=file_sha(failure_path),complete=False,
            reason='The first processor incorrectly asserted that one section would lead both observations. All scored/endpoint/page joins had passed; the per-case leader differs.',
            report_path=str(failure_path),executed_driver_sha256='a0ed175850de59c5c5bf14d258433cbafe6092be808b8abdc06b337ce5806aab')
        assert root_state()==root_before
        after=counters(group);no_oom(report['before'],after,1024**3)
        report.update(complete=True,after=after,finished_at=datetime.now(timezone.utc).isoformat(),
            interpretation='Section evidence is unscored and separate from prior scored cohorts. Warm captures follow16 prior calls. Image/text/section boundaries and host function pages are nonadditive; presence is not execution or causal savings. No parity or goal-completion claim. No native image or workload was read/executed by this processor.')
    except BaseException as error:
        report.update(error=repr(error),error_type=type(error).__name__,after=counters(group),finished_at=datetime.now(timezone.utc).isoformat())
        raise
    finally:
        report['inputs']=INPUTS
        (OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n')
    lines=['CI40611737589: 68/68 scored attempts,17 workload checksums, six actual engine controls and all four v2 ownership/host captures validated.',
        'Exact feature1fd parser/section joins reproduced from raw snapshots. Scored Portable R runtime key matches prior core1721/layout29; no cross-runner native equality is claimed.',
        'CLI example-test raw job output is unavailable; no exact CLI example pass count is claimed.','',
        '| Case | R image pages | Text pages | Nontext image pages | Mixed | Boundary | Uncovered | Header overlap | Section-table overlap |',
        '|---|---:|---:|---:|---:|---:|---:|---:|---:|']
    for case in report['runtime_sections']:
        warm=case['phases'][-1]
        lines.append('| '+case['file']+' | '+' | '.join(str(warm[key]) for key in ('image_present_pages','text_present_pages','nontext_image_present_pages','mixed_section_present_pages','section_boundary_present_pages','uncovered_present_image_pages','elf_header_present_page_overlaps','section_headers_present_page_overlaps'))+' |')
    lines+=['','Retained warm after_store_drop at observation16; overlapping counts below must not be summed.','',
        '| Case | Nontext R section | Section bytes | Present-page overlaps | Full present pages |','|---|---|---:|---:|---:|']
    for case in report['runtime_sections']:
        for row in case['phases'][-1]['nontext_sections']:
            lines.append('| '+case['file']+' | '+row['name']+' | '+str(row['bytes'])+' | '+str(row['present_page_overlaps'])+' | '+str(row['full_present_pages'])+' |')
    lines+=['','The measured nontext leaders differ: integer R .rodata.wasm; retained-objects R .wasmtime.stackmap. Inspect required data/GC metadata origins before a matched intervention; section size/presence establishes no saving or live heap ownership and does not authorize dropping stack maps. Warm history contains16 earlier calls; no last-sample causal/bootstrap claim follows. Native payloads were not retained/executed.']
    (OUT/'summary.md').write_text('\n'.join(lines)+'\n')
    print(json.dumps(dict(complete=True,scored_attempts=68,workloads=17,native_controls=6,diagnostic=report['diagnostic']['status'],output=str(OUT))))


if __name__=='__main__':main()
