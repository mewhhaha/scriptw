"""Write three unscored diagnostic publication files in the isolated worktree."""
from datetime import datetime,timezone
import hashlib
import json
import lzma
import os
from pathlib import Path
import shutil
import stat
import subprocess
import sys
import tarfile

BASE=Path(__file__).resolve().parent
ROOT=BASE.parents[1]
WORKTREE=ROOT/'target/memory-module-sections-20261028'
DEST=WORKTREE/'docs/rust-rewrite'
OUT=BASE/'publication-private-40611737589'
VALIDATED=BASE/'ci-40611737589-validated-r1'
REPORT_SHA='9457518d3888e7e607bade6b0a004b70ba91c325d6e9edf3819f7c8385d23931'
FEATURE='1fd6940fb3db57b999dc535595f5a185870cae69'
SOURCE='45f26184b16ba0841346c537e517112d08aa74ab'
STEM='memory-module-sections-20261028'
MAX_MEMBER,MAX_EXPANDED,MAX_COMPRESSED=64*1024**2,256*1024**2,64*1024**2
sys.path.insert(0,str(ROOT/'scripts'))
from limited_verification import require_kernel_budget,kernel_group


def sha(path):
    with Path(path).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()


def read(path):
    path=Path(path)
    assert not path.is_symlink() and stat.S_ISREG(path.lstat().st_mode) and path.stat().st_size<=MAX_MEMBER
    return json.loads(path.read_text())


def state(directory):
    assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=directory)
    return subprocess.check_output(['git','rev-parse','HEAD'],cwd=directory,text=True).strip()


def budget(group):
    return {key:(group/key).read_text().strip() for key in ('memory.max','memory.swap.max','memory.oom.group','memory.peak','memory.events')}


def no_oom(before,after):
    for row in (before,after):
        assert 0<int(row['memory.max'])<=1024**3 and row['memory.swap.max']=='0' and row['memory.oom.group']=='1'
    events=[dict(line.split() for line in row['memory.events'].splitlines()) for row in (before,after)]
    assert all(events[0][key]==events[1][key]=='0' for key in ('oom','oom_kill','oom_group_kill'))


def main():
    require_kernel_budget(1024**3)
    assert sorted(os.sched_getaffinity(0))==[0] and not OUT.exists()
    root_before,worktree_before=state(ROOT),state(WORKTREE)
    assert worktree_before==SOURCE
    readme_sha=sha(WORKTREE/'README.md')
    paths=[DEST/(STEM+suffix) for suffix in ('.json','.md','-inert.tar.xz')]
    assert not any(path.exists() for path in paths)
    group=kernel_group();OUT.mkdir()
    processing=dict(complete=False,started_at=datetime.now(timezone.utc).isoformat(),cpu_affinity=[0],before=budget(group),
        driver=dict(path=str(Path(__file__).resolve()),sha256=sha(Path(__file__))),root_source=root_before,publication_checkout=worktree_before,
        scope='Three isolated-worktree diagnostic files only; no README, graphs, main, build, native image or workload execution.')
    try:
        assert sha(VALIDATED/'report.json')==REPORT_SHA
        report=read(VALIDATED/'report.json')
        assert report['complete'] is True and report['source_commit']==SOURCE and report['feature_source_commit']==FEATURE
        assert report['scored_attempts']==68 and report['scored_workloads']==17 and report['scored_all_attempts_ok'] is True
        assert report['native_controls']['passed']==6 and report['diagnostic']['status']=='validated'
        no_oom(report['before'],report['after'])
        files={}
        def add(name,path,expected=None):
            path=Path(path)
            assert name not in files and not name.startswith('/') and '..' not in Path(name).parts
            assert not path.is_symlink() and stat.S_ISREG(path.lstat().st_mode) and path.stat().st_size<=MAX_MEMBER
            with path.open('rb') as stream:magic=stream.read(8)
            assert not magic.startswith((b'\x7fELF',b'MZ',b'SWRTZ001',b'SCRWRB',b'SCRWEP',b'SCRWWA',b'SCRWNR'))
            row=dict(bytes=path.stat().st_size,sha256=sha(path),source=path)
            if expected is not None:assert (row['bytes'],row['sha256'])==(expected['bytes'],expected['sha256'])
            files[name]=row
        for name,row in report['inputs'].items():
            path=Path(name)
            alias='evidence/'+path.relative_to(BASE).as_posix() if path.is_relative_to(BASE) else 'reproduce/'+path.relative_to(ROOT).as_posix()
            add(alias,path,row)
        for name in ('ci-40611737589-validated-r1/report.json','ci-40611737589-validated-r1/summary.md',
            'validate-ci-40611737589-reviewed.py','validate-ci-40611737589-r1-reviewed.py',
            'validate-ci-40611737589.stdout','validate-ci-40611737589.stderr',
            'validate-ci-40611737589-r1.stdout','validate-ci-40611737589-r1.stderr','source-bindings-sections.py'):
            alias='evidence/'+name
            if alias not in files:add(alias,BASE/name)
        pattern=ROOT/'target/memory-module-ownership-20261027-evidence/validate-ci-40594118953.py'
        assert sha(pattern)==report['reused_validator_sha256']
        add('reproduce/ownership-validator-pattern.py',pattern)
        add('reproduce/publication-driver.py',Path(__file__).resolve())
        for name in ('limited_verification.py','native_test_protocol.py'):
            add('reproduce/scripts/'+name,ROOT/'scripts'/name)
        # Retain exact source instrumentation, not a native payload.
        for name in ('crates/scriptw-engine/src/embedding/benchmark_module_images.rs',
            'crates/scriptw-engine/src/embedding/benchmark_module_images/sections.rs',
            'crates/scriptw-engine/src/embedding/benchmark_module_images/sections/tests.rs',
            'crates/scriptw-cli/examples/runtime_precompiled/phase_barriers.rs',
            '.github/workflows/precompiled-benchmarks.yaml'):
            raw=subprocess.check_output(['git','show',FEATURE+':'+name],cwd=ROOT)
            retained=OUT/'source'/name;retained.parent.mkdir(parents=True,exist_ok=True)
            with retained.open('xb') as stream:stream.write(raw)
            add('reproduce/feature-source/'+name,retained)
        core=ROOT/'docs/rust-rewrite/memory-ordered-bootstrap-20261028.json'
        reference=dict(file=core.name,sha256=sha(core),
            interpretation='The published matched Core cohort remains the scored reference. No README or graph cohort is replaced by this unscored section diagnostic.')
        raw=read(BASE/'github-40611737589-diagnostic/report.json')
        captures=[]
        for case in raw['cases']:
            owners=case['module_images']['owners']
            validated=next(item for item in report['diagnostic']['cases'] if (item['runtime'],item['file'])==(case['runtime'],case['file']))
            assert case['status']=='captured' and case['observation_index']==16 and validated['status']=='validated'
            captures.append(dict(runtime=case['runtime'],file=case['file'],nonce=case['nonce'],observation_index=16,
                image_sha256=case['image_sha256'],host_executable_sha256=raw['executable_sha256'],
                owners=[dict(role=owner['role'],image=owner['image'],text=owner['text'],sections=owner['sections']) for owner in owners],
                host_phases=validated['host_phases'],host_nonexclusive_function_count=validated['host_overlapping_function_count']))
        expanded=sum(row['bytes'] for row in files.values())
        assert len(files)<=2048 and expanded<=MAX_EXPANDED
        archive=OUT/(STEM+'-inert.tar.xz')
        with archive.open('xb') as target,lzma.LZMAFile(target,'w',filters=[dict(id=lzma.FILTER_LZMA2,preset=1,dict_size=16*1024**2)]) as compressed:
            with tarfile.open(fileobj=compressed,mode='w|') as bundle:
                for name,row in sorted(files.items()):
                    info=tarfile.TarInfo(name);info.size=row['bytes'];info.mode=0o644
                    with row['source'].open('rb') as stream:bundle.addfile(info,stream)
        assert archive.stat().st_size<=MAX_COMPRESSED
        seen,total=set(),0
        with tarfile.open(archive,'r|xz') as bundle:
            for member in bundle:
                assert member.isfile() and member.name in files and member.name not in seen
                row=files[member.name];assert member.size==row['bytes']<=MAX_MEMBER
                total+=member.size;assert total<=MAX_EXPANDED
                with bundle.extractfile(member) as stream:assert hashlib.file_digest(stream,'sha256').hexdigest()==row['sha256']
                seen.add(member.name)
        assert seen==set(files) and total==expanded
        assert sha(VALIDATED/'report.json')==REPORT_SHA and all(sha(row['source'])==row['sha256'] for row in files.values())
        assert state(ROOT)==root_before and state(WORKTREE)==worktree_before and sha(WORKTREE/'README.md')==readme_sha
        after=budget(group);no_oom(processing['before'],after)
        processing.update(complete=True,after=after,finished_at=datetime.now(timezone.utc).isoformat())
        document=dict(schema='scriptw-module-sections-diagnostic-v1',recorded_at=datetime.now(timezone.utc).isoformat(),
            scored=False,excluded_from_scored_cohorts=True,feature_source_commit=FEATURE,measured_source_commit=SOURCE,
            source_fingerprint=report['source_fingerprint'],github_run=40611737589,
            validation=dict(report_sha256=REPORT_SHA,native_controls=report['native_controls'],
                cli_example_controls=report['cli_example_controls'],prior_processing_failure=report['prior_processing_failure'],
                before=report['before'],after=report['after'],validator_sources=report['validator_sources']),
            scored_context=dict(attempts=68,workloads=17,all_checksums_validated=True,new_scores_published=False,existing_reference=reference),
            runtime_identity_comparison=report['runtime_identity_comparison'],captures=captures,runtime_sections=report['runtime_sections'],
            next_measurement_targets=report['next_measurement_targets'],
            archive=dict(file=archive.name,bytes=archive.stat().st_size,sha256=sha(archive),expanded_bytes=expanded,member_count=len(files),
                max_member_bytes=MAX_MEMBER,max_expanded_bytes=MAX_EXPANDED,max_compressed_bytes=MAX_COMPRESSED,
                roundtrip_sha256_verified=True,native_payloads_retained=False,
                members=[dict(path=name,bytes=row['bytes'],sha256=row['sha256']) for name,row in sorted(files.items())]),
            publication_processing=processing,
            interpretation='Unscored section/page attribution only. Section overlaps, image/text views and host function/page counts are nonadditive. Warm observation16 follows16 prior calls. Presence proves neither execution nor causal memory savings; required data/GC metadata cannot be omitted on this evidence. Validator reads retained benchmark fixture text and metadata; it loads no native image and executes no workload. No parity or goal-completion claim. Existing matched Core, V8, README/status and graphs remain unchanged.')
        lines=['# Owned runtime section diagnostic','',
            'This unscored diagnostic comes from CI40611737589, source `'+SOURCE+'`, using feature `'+FEATURE+'`. All 68 scored attempts and 17 workload checksums were admitted as context; the published [matched Core cohort](memory-ordered-bootstrap-20261028.md) remains the scored reference. README, V8/status and graphs are unchanged.','',
            'Six exact engine controls and all four source/nonce/index-bound v2 ownership captures validate. The Portable R layout29 content key matches the prior Core cohort; this does not assert native byte equality across runners. Raw CLI example-test job logs are unavailable, so no exact CLI example count is claimed.','',
            'At the retained warm endpoint (after_store_drop, observation16 after 16 earlier calls):','',
            '| Case | R image pages | Text | Other image pages | Mixed/boundary pages | Uncovered | Header/table overlap |',
            '|---|---:|---:|---:|---:|---:|---:|']
        for case in report['runtime_sections']:
            warm=case['phases'][-1]
            lines.append('| '+case['file']+' | '+str(warm['image_present_pages'])+' | '+str(warm['text_present_pages'])+' | '+str(warm['nontext_image_present_pages'])+' | '+str(warm['mixed_section_present_pages'])+'/'+str(warm['section_boundary_present_pages'])+' | '+str(warm['uncovered_present_image_pages'])+' | '+str(warm['elf_header_present_page_overlaps'])+'/'+str(warm['section_headers_present_page_overlaps'])+' |')
        lines+=['','| Case | Nontext section | Section bytes | Present-page overlaps | Full present pages |','|---|---|---:|---:|---:|']
        for case in report['runtime_sections']:
            for row in case['phases'][-1]['nontext_sections']:
                lines.append('| '+case['file']+' | '+row['name']+' | '+str(row['bytes'])+' | '+str(row['present_page_overlaps'])+' | '+str(row['full_present_pages'])+' |')
        lines+=['','The measured leaders differ: `.rodata.wasm` has 145 full present pages in both cases; `.wasmtime.stackmap` has 190 in retained objects and zero in integer. These identify data and GC-metadata origins to inspect before a matched intervention. They do not justify removing required data or stack maps. Overlap counts share boundary pages and must not be summed or converted into additive RSS.','',
            'The inert archive retains the final validator, raw scored/diagnostic reports and observations, six control streams, exact parsers/source instrumentation, and the first validator’s failed section-leader assertion. That failure and its authentic counters remain incomplete. No native payload is retained. The validator reads fixture text and metadata and executes no workload; no causal saving, parity or project-completion claim follows.']
        json_path=OUT/(STEM+'.json');md_path=OUT/(STEM+'.md')
        json_path.write_text(json.dumps(document,indent=2)+'\n');md_path.write_text('\n'.join(lines)+'\n')
        for source,target in zip((json_path,md_path,archive),paths):
            with source.open('rb') as src,target.open('xb') as dst:shutil.copyfileobj(src,dst,1024**2)
            assert sha(source)==sha(target)
        assert sha(WORKTREE/'README.md')==readme_sha and state(ROOT)==root_before and state(WORKTREE)==worktree_before
        processing['outputs']=[dict(path=str(path),bytes=path.stat().st_size,sha256=sha(path)) for path in paths]
    except BaseException as error:
        processing.update(complete=False,error=repr(error),error_type=type(error).__name__,after=budget(group),finished_at=datetime.now(timezone.utc).isoformat())
        raise
    finally:
        (OUT/'processing.json').write_text(json.dumps(processing,indent=2)+'\n')
    print(json.dumps(dict(complete=True,outputs=processing['outputs'])))


if __name__=='__main__':main()
