Regular inert UTF-8 evidence only. Scripts and observer C are workflow records,
not an archive execution interface. Executables, Wasm/native images, Cargo
objects, caches, tool payloads and symlinks are excluded. Failed attempts and
withdrawn CPU-scope records are preserved. The existing prior archive is never
modified. The final tracked summary and live packaging log/receipt stay external to avoid
a self-hash cycle.
