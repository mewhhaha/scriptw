from datetime import datetime,timezone
import hashlib,json,os,subprocess,sys,time
from pathlib import Path
ROOT=Path('/home/mewhhaha/src/porffor');BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'scripts'))
from limited_verification import require_kernel_budget,kernel_group
require_kernel_budget(4*1024**3);assert len(os.sched_getaffinity(0))==1
group=kernel_group()
def budget():return {k:(group/k).read_text().strip() for k in ['memory.max','memory.swap.max','memory.oom.group','memory.peak','memory.events']}
command=['cargo','check','--locked','--offline','--release','--workspace','--all-targets','--jobs','1','--target-dir',str(ROOT/'target/performance-work-20261024/build'),'--message-format=json']
report=dict(source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),complete=False,command=command,before=budget(),cpu_affinity=sorted(os.sched_getaffinity(0)),started_at=datetime.now(timezone.utc).isoformat())
assert not subprocess.check_output(['git','diff','HEAD','--','crates','vendor','scripts','Cargo.toml','Cargo.lock'],cwd=ROOT)
out=BASE/'cargo-check-root-fixed.jsonl';err=BASE/'cargo-check-root-fixed.stderr'
(BASE/'check-root-fixed.json').write_text(json.dumps(report,indent=2)+'\n');start=time.monotonic()
with out.open('xb') as stdout,err.open('xb') as stderr:r=subprocess.run(command,cwd=ROOT,stdout=stdout,stderr=stderr,timeout=7200)
report.update(exit_code=r.returncode,complete=r.returncode==0,seconds=time.monotonic()-start,after=budget(),stdout_sha256=hashlib.sha256(out.read_bytes()).hexdigest(),stderr_sha256=hashlib.sha256(err.read_bytes()).hexdigest())
(BASE/'check-root-fixed.json').write_text(json.dumps(report,indent=2)+'\n');print('cargo check finished',r.returncode,flush=True)
if r.returncode:print(err.read_text()[-12000:],flush=True)
raise SystemExit(r.returncode)
