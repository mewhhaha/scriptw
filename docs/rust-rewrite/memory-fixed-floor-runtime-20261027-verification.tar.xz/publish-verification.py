"""Publish only completed source-bound evidence; no native binaries/images."""
from datetime import datetime,timezone
import hashlib,json,lzma,re,tarfile,sys
from pathlib import Path,PurePosixPath
BASE=Path(__file__).resolve().parent;ROOT=BASE.parents[1];DEST=ROOT/'docs/rust-rewrite'
sys.path.insert(0,str(ROOT/'scripts'))
import precompiled_comparison as p
STEM='memory-fixed-floor-runtime-20261027'
def read(path):return json.loads(path.read_text())
def sha(path):
 with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
native=read(BASE/'native-root-fixed/report.json');batch=read(BASE/'verification-root-fixed.json');conf=read(BASE/'conformance/report.json');check=read(BASE/'check-root-fixed.json')
source=native['source_commit'];assert all(x['complete'] and x['source_commit']==source for x in [native,batch,conf,check])
assert len(native['scopes'])==18 and native['passed_disjoint_scopes']==sum(s['passed'] for s in native['scopes'])
assert all(s['complete'] and s['passed']==len(s['inventory']) for s in native['scopes'])
assert conf['passed']==conf['total']>0 and all(c['returncode']==0 for c in conf['commands'])
assert all(c['exit_code']==0 for c in batch['commands'])
vendor=(BASE/'vendor-page-policy-root-fixed.stdout').read_text();assert re.findall(r'^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',vendor,re.M)==[('7','0','0','0','112')]
bindings=read(BASE/'source-bindings-computed.json');clean,local=bindings[-2:];assert clean['revision']==local['revision']==source
assert conf['compiler']['identity']['source_fingerprint']==local['source_fingerprint']
measured,rows=p.load_report(BASE/'github-40439597289/precompiled-evidence/report.json');assert measured['source_commit']==source and measured['source_fingerprint']==clean['source_fingerprint']
for record in [native,batch,conf,check]:
 for moment in ['before','after']:
  budget=record[moment];assert budget['memory.max']=='4294967296' and budget['memory.swap.max']=='0' and budget['memory.oom.group']=='1'
 before=dict(line.split() for line in record['before']['memory.events'].splitlines());after=dict(line.split() for line in record['after']['memory.events'].splitlines())
 assert all(before[k]==after[k] for k in ['oom','oom_kill','oom_group_kill'])
lock=ROOT/'vendor/regress-0.10.5/Cargo.lock';provenance=BASE/'provenance';provenance.mkdir(exist_ok=True);(provenance/'ignored-regress-Cargo.lock').write_bytes(lock.read_bytes())
files=[]
for path in sorted(BASE.rglob('*')):
 if not path.is_file():continue
 rel=path.relative_to(BASE).as_posix();parts=PurePosixPath(rel).parts
 if parts[0].startswith('github-') or 'images' in parts or path.name.startswith(('publication.','preview-')):continue
 if path.suffix not in ['.py','.json','.jsonl','.stdout','.stderr','.smaps','.txt','.lock'] and path.name!='executions':continue
 assert not path.is_symlink() and path.stat().st_size<=128*1024**2
 assert '..' not in parts and not PurePosixPath(rel).is_absolute()
 with path.open('rb') as f:assert not f.read(8).startswith((b'\x7fELF',b'MZ',b'SCRWEP01',b'SCRWEP02',b'SCRWWA01'))
 files.append(dict(path=rel,bytes=path.stat().st_size,sha256=sha(path)))
expanded=sum(row['bytes'] for row in files);assert expanded<=2*1024**3
archive=DEST/(STEM+'-verification.tar.xz');assert not archive.exists()
with archive.open('xb') as output,lzma.LZMAFile(output,'w',format=lzma.FORMAT_XZ,filters=[dict(id=lzma.FILTER_LZMA2,preset=1,dict_size=64*1024**2)]) as compressed:
 with tarfile.open(fileobj=compressed,mode='w|',format=tarfile.PAX_FORMAT) as tar:
  for row in files:
   member=tarfile.TarInfo(row['path']);member.size=row['bytes'];member.mode=0o644
   with (BASE/row['path']).open('rb') as stream:tar.addfile(member,stream)
assert archive.stat().st_size<=32*1024**2
record=dict(schema='scriptw-fixed-floor-runtime-memory-verification-v1',recorded_at=datetime.now(timezone.utc).isoformat(),verified_source_commit=source,measured_source_commit=measured['source_commit'],source_bindings=dict(rows=bindings,ignored_extra=dict(path=str(lock.relative_to(ROOT)),bytes=lock.stat().st_size,sha256=sha(lock))),native=native,test262=conf,collector_controls=7,checkpoints=dict(typecheck=check,completed=batch),interpretation='Complete affected native inventories and exact original selected Test262 executions. This is not a full pinned-suite refresh. CI uses clean Git compiler inputs; local verification additionally fingerprints the retained ignored standalone dependency lock. Failed attempts are retained. Native binaries and serialized native images are excluded.',archive=dict(file=archive.name,sha256=sha(archive),bytes=archive.stat().st_size,expanded_bytes=expanded,member_count=len(files),max_expanded_bytes=2*1024**3,max_member_bytes=128*1024**2),retained_files=files)
target=DEST/(STEM+'.json');assert not target.exists();target.write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(dict(native=native['passed_disjoint_scopes'],test262=conf['total'],collector_controls=7,archive=record['archive']),indent=2))
