"""Inspect an owned child stopped at exec, before it executes user instructions."""
import ctypes,hashlib,json,os,signal,struct,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'scripts'))
from limited_verification import require_kernel_budget
require_kernel_budget(4*1024**3);assert len(os.sched_getaffinity(0))==1
folder=BASE/'mapping-diagnostic-current';prior=json.loads((folder/'report.json').read_text());exe=folder/'consumer'
with exe.open('rb') as stream:assert hashlib.file_digest(stream,'sha256').hexdigest()==prior['executable_sha256']
symbols=[]
result=subprocess.run(['nm','-S','--defined-only','--format=posix',str(exe)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=60,check=True)
for line in result.stdout.decode().splitlines():
 parts=line.split()
 if parts[0] in ['SCRIPTW_RUNTIME_PORTABLE_NATIVE','SCRIPTW_RUNTIME_NATIVE']:
  assert len(parts)==4;symbols.append(dict(name=parts[0],value=int(parts[2],16),length=int(parts[3],16)))
assert len(symbols)==2
libc=ctypes.CDLL(None,use_errno=True);libc.ptrace.restype=ctypes.c_long
libc.ptrace.argtypes=[ctypes.c_uint,ctypes.c_int,ctypes.c_void_p,ctypes.c_void_p]
report=dict(scope='inert-exec-source-range-probe-no-JavaScript-or-user-instructions',complete=False,executable_sha256=prior['executable_sha256'],source_commit=prior['source_commit'],symbols=symbols)
child=os.fork()
if child==0:
 if libc.ptrace(0,0,None,None)==-1:os._exit(77)
 os.execv(exe,[str(exe),'identity'])
try:
 waited,status=os.waitpid(child,0);assert waited==child
 report['wait_status']=status
 if not os.WIFSTOPPED(status) or os.WSTOPSIG(status)!=signal.SIGTRAP:
  report['unavailable']='child did not reach the requested exec stop';raise RuntimeError(report['unavailable'])
 prefix=Path(f'/proc/{child}')
 report['mount_namespaces']=dict(parent=os.readlink('/proc/self/ns/mnt'),child=os.readlink(prefix/'ns/mnt'))
 assert report['mount_namespaces']['parent']==report['mount_namespaces']['child']
 maps=(prefix/'maps').read_text();(BASE/'source-probe.maps.txt').write_text(maps)
 with (prefix/'exe').open('rb') as source:
  st=os.fstat(source.fileno());report['executable_file']=dict(device=st.st_dev,major=os.major(st.st_dev),minor=os.minor(st.st_dev),inode=st.st_ino,bytes=st.st_size)
  header=source.read(64);assert header[:6]==b'\x7fELF\x02\x01'
  kind,machine,version,entry,phoff,shoff,flags,ehsize,phentsize,phnum,*_=struct.unpack('<HHIQQQIHHHHHH',header[16:])
  assert kind in [2,3] and phentsize==56 and 0<phnum<1024
  source.seek(phoff);table=source.read(phnum*phentsize);assert len(table)==phnum*phentsize
  headers=[struct.unpack('<IIQQQQQQ',table[i:i+56]) for i in range(0,len(table),56)]
  phdr=[h for h in headers if h[0]==6];assert len(phdr)==1
  auxbytes=(prefix/'auxv').read_bytes();assert len(auxbytes)<=65536 and len(auxbytes)%16==0
  aux={}
  for key,value in struct.iter_unpack('<QQ',auxbytes):
   if key==0:break
   assert key not in aux;aux[key]=value
  assert aux[4]==phentsize and aux[5]==phnum
  bias=aux[3]-phdr[0][3];assert bias>=0
  with (prefix/'mem').open('rb',buffering=0) as memory:loaded=os.pread(memory.fileno(),len(table),aux[3])
  report['kernel_main_headers']=dict(elf_type=kind,machine=machine,phoff=phoff,phentsize=phentsize,phnum=phnum,load_bias=bias,loaded_table_matches_file=loaded==table,entry_matches_file=aux[9]==bias+entry)
  report['ranges']=[]
  for symbol in symbols:
   address=bias+symbol['value'];end=address+symbol['length'];candidates=[]
   for line in maps.splitlines():
    fields=line.split();start,stop=[int(v,16) for v in fields[0].split('-')]
    if start<=address and end<=stop:
     major,minor=[int(v,16) for v in fields[3].split(':')];offset=int(fields[2],16)+address-start
     candidates.append(dict(mapping=line,permissions=fields[1],mapped_major=major,mapped_minor=minor,inode_match=int(fields[4])==st.st_ino,device_match=(major,minor)==(os.major(st.st_dev),os.minor(st.st_dev)),file_offset=offset,within_file=offset+symbol['length']<=st.st_size))
   report['ranges'].append(dict(symbol=symbol['name'],candidates=candidates))
 report['complete']=True
finally:
 try:os.kill(child,signal.SIGKILL)
 except ProcessLookupError:pass
 try:os.waitpid(child,0)
 except ChildProcessError:pass
 (BASE/'source-probe.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
