import hashlib,json,os,subprocess,sys,time
from pathlib import Path
ROOT=Path('/home/mewhhaha/src/porffor/target/memory-fixed-floor-20261027');BASE=Path(__file__).resolve().parent
report=dict(complete=False,base_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),commands=[])
def save():(BASE/'cheap-checks.json').write_text(json.dumps(report,indent=2)+'\n')
plan=[('identities',[sys.executable,'-B','scripts/intl_source_identities.py']),('source-guards',[sys.executable,'-B','scripts/check-source-guards.py','--output',str(BASE/'source-guards')]),('runtime-profile',[sys.executable,'-B','scripts/check-runtime-source-compilation-profile.py']),('retired-js',['bash','scripts/check-no-legacy-js.sh']),('python-framing',[sys.executable,'-B','-m','unittest','scripts.tests.test_precompiled_comparison','scripts.tests.test_tooling_benchmark_boundary','-v']),('diff',['git','diff','--check'])]
for label,args in plan:
 row=dict(label=label,command=args,stdout=label+'.stdout',stderr=label+'.stderr');report['commands'].append(row);save();print(label,'started',flush=True);start=time.monotonic()
 with (BASE/row['stdout']).open('xb') as out,(BASE/row['stderr']).open('xb') as err:r=subprocess.run(args,cwd=ROOT,stdout=out,stderr=err,timeout=600)
 row.update(returncode=r.returncode,seconds=time.monotonic()-start,stdout_sha256=hashlib.sha256((BASE/row['stdout']).read_bytes()).hexdigest(),stderr_sha256=hashlib.sha256((BASE/row['stderr']).read_bytes()).hexdigest());save();print(label,'finished',r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
report['complete']=True;save()
