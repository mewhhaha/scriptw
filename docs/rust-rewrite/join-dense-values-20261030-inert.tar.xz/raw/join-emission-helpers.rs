fn loop_ranges(body: &[Operator<'_>]) -> Vec<std::ops::Range<usize>> {
    let mut frames = Vec::new();
    let mut loops = Vec::new();
    for (position, operator) in body.iter().enumerate() {
        match operator {
            Operator::Loop { .. } => frames.push(Some(position)),
            Operator::Block { .. } | Operator::If { .. } | Operator::TryTable { .. } => {
                frames.push(None);
            }
            Operator::End => {
                if let Some(Some(start)) = frames.pop() {
                    loops.push(start + 1..position);
                }
            }
            _ => {}
        }
    }
    loops
}

#[derive(Default)]
struct ArrayLocalOperands {
    reads: Vec<(usize, u32, Option<u32>)>,
    lengths: Vec<(usize, Option<u32>)>,
}

/// Track only local receiver operands across stack-preserving reference
/// refinement and index conversion. Unknown instructions end the short trace;
/// the complete Wasm validator checks the actual stack and control-flow types.
fn array_local_operands(body: &[Operator<'_>]) -> ArrayLocalOperands {
    let mut stack = Vec::new();
    let mut operands = ArrayLocalOperands::default();
    for (position, operator) in body.iter().enumerate() {
        match operator {
            Operator::LocalGet { local_index } => stack.push(Some(*local_index)),
            Operator::LocalSet { .. } | Operator::Drop => {
                stack.pop();
            }
            Operator::LocalTee { .. }
            | Operator::RefAsNonNull
            | Operator::I32WrapI64
            | Operator::I64ExtendI32U => {}
            Operator::I32Const { .. }
            | Operator::I64Const { .. }
            | Operator::F32Const { .. }
            | Operator::F64Const { .. }
            | Operator::GlobalGet { .. }
            | Operator::RefNull { .. } => stack.push(None),
            Operator::ArrayGet { array_type_index } => {
                stack.pop(); // index
                operands
                    .reads
                    .push((position, *array_type_index, stack.pop().flatten()));
                stack.push(None);
            }
            Operator::ArrayLen => {
                operands.lengths.push((position, stack.pop().flatten()));
                stack.push(None);
            }
            _ => stack.clear(),
        }
    }
    operands
}
