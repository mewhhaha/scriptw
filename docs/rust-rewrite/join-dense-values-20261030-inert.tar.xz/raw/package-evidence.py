"""Freeze source-bound inert evidence, excluding native payloads and caches."""
from pathlib import Path
import hashlib,io,json,lzma,subprocess,tarfile
ROOT=Path('/workspace/scriptw'); WORK=ROOT/'target/performance-module-followup-20261030'
DEST=ROOT/'docs/rust-rewrite/join-dense-values-20261030-inert.tar.xz'
def digest(value):return hashlib.sha256(value).hexdigest()
def load(path):return json.loads(path.read_text())
def dump(value):return (json.dumps(value,indent=2)+'\n').encode()
subprocess.run(['git','diff','--quiet','HEAD','--',':(glob)crates/*/src/**'],cwd=ROOT,check=True)
subprocess.run(['git','diff','--check'],cwd=ROOT,check=True)
receipt=load(WORK/'native/receipt.json')
assert receipt['source_unchanged'] and all(c['state']=='passed' for c in receipt['cases'])
checks=[{'package':c['package'],'target':c['target'],'passed':sum(o['passed'] for o in c['outcomes']),'failed':sum(o['failed'] for o in c['outcomes']),'executable_sha256':c['executable_sha256'],'raw_receipt':'raw/native/receipt.json'} for c in receipt['cases']]
(WORK/'validation.json').write_bytes(dump({'rejected_candidate_native_scopes':checks,'rejected_candidate_total_unique_native_passed':sum(c['passed'] for c in checks),'final_source_validation':load(WORK/'retained-regression-validation.json'),'source_guards_passed':sum(sum(int(r[1]) for r in load(WORK/'source-guards'/t['target']/'receipt.json')['result_summaries']) for t in load(WORK/'source-guards/receipt.json')['targets']),'source_guards_overlap_native':True,'raw_source_guards':'raw/source-guards/receipt.json','formatting':load(WORK/'format-comparison.json'),'product_graph':(WORK/'product-graph.log').read_text()}))
patch=subprocess.check_output(['git','diff','--binary','--','crates','README.md','docs/performance-hills.md','docs/rust-rewrite/current-inventory.md','docs/rust-rewrite/contracts/execution-hotpaths.md'],cwd=ROOT)
for name in ['crates/scriptw-engine/tests/fixtures/array_private_buffers/packed_join_dense_prefix.js']:
 r=subprocess.run(['git','diff','--no-index','--binary','--','/dev/null',name],cwd=ROOT,capture_output=True);assert r.returncode==1;patch+=r.stdout
(WORK/'final-review.patch').write_bytes(patch)
def crate_changes(value):
 blocks=value.split(b'diff --git ')
 return b''.join(b'diff --git '+block for block in blocks[1:] if block.startswith(b'a/crates/'))
def file_patch(value,name):
 return next(b'diff --git '+block for block in value.split(b'diff --git ')[1:] if block.startswith(('a/'+name+' ').encode()))
wrapper='crates/scriptw-engine/tests/aot_builtins/aot_array_private_buffers.rs'
assert file_patch(patch,wrapper)==file_patch((WORK/'compile-inputs.patch').read_bytes(),wrapper)
fixture='crates/scriptw-engine/tests/fixtures/array_private_buffers/packed_join_dense_prefix.js'
assert digest((ROOT/fixture).read_bytes())==load(WORK/'native/source-start.json')['untracked'][fixture]
(WORK/'compiled-code-match.json').write_bytes(dump({'final_production_matches_baseline':True,'retained_test_wrapper_matches_compiled_candidate_test':True,'retained_fixture_matches_compiled_candidate_test':True,'candidate_production_reverted':True}))
for label in ('baseline','candidate'):
 for name,product in load(WORK/label/'products.json').items():assert digest((WORK/label/name).read_bytes())==product['sha256']
allowed={'.json','.jsonl','.log','.txt','.py','.rs','.patch','.stdout','.stderr','.exit','.js','.mjs','.gz'}
folders={'baseline','candidate','baseline-images','candidate-images','native','native-plan','native-configuration-probe','source-guards','test262-baseline','test262-candidate','numeric-fallback-fixture'}
members={}
for path in sorted(WORK.rglob('*')):
 if not path.is_file() or path.is_symlink():continue
 rel=path.relative_to(WORK)
 if len(rel.parts)>1 and rel.parts[0] not in folders:continue
 if path.suffix not in allowed or path.name in {'package.log','evidence-index.json'}:continue
 members['raw/'+rel.as_posix()]=path.read_bytes()
transcripts=[]
for case in receipt['cases']:
 path=ROOT/case['transcript_log'];value=path.read_bytes();assert digest(value)==case['transcript_sha256']
 name='watched/'+path.name;assert name not in members;members[name]=value
 transcripts.append({'original_path':case['transcript_log'],'archive_path':name,'sha256':digest(value)})
fixtures=ROOT/'crates/scriptw-cli/tests/fixtures/v8_execution_hotpaths'
plan=load(fixtures/'manifest.json')
for name in ['manifest.json',plan['startup']['file']]:members['fixtures/'+name]=(fixtures/name).read_bytes()
index={'schema':'scriptw-join-dense-values-inert-evidence-v1','path_mapping':'raw/ is relative to original target/performance-module-followup-20261030; original absolute command paths are preserved as provenance. watched/ maps native transcript paths; earlier module-local evidence retains its own earlier generation of watcher paths.','transcripts':transcripts,'excluded':['native executable files','serialized .swpc images','emitted .wasm files','runtime caches','toolchain'],'members':[{'path':name,'bytes':len(value),'sha256':digest(value)} for name,value in sorted(members.items())]}
index_bytes=dump(index);(WORK/'evidence-index.json').write_bytes(index_bytes);members['evidence-index.json']=index_bytes
with lzma.open(DEST,'wb',preset=6) as compressed:
 with tarfile.open(fileobj=compressed,mode='w|',format=tarfile.PAX_FORMAT) as archive:
  for name,value in sorted(members.items()):
   entry=tarfile.TarInfo(name);entry.size=len(value);entry.mode=0o644;archive.addfile(entry,io.BytesIO(value))
with tarfile.open(DEST,'r:xz') as archive:
 entries=archive.getmembers();assert len(entries)==len(members) and len({e.name for e in entries})==len(entries)
 for entry in entries:
  assert entry.isfile() and not Path(entry.name).is_absolute() and '..' not in Path(entry.name).parts
  assert archive.extractfile(entry).read()==members[entry.name]
print(json.dumps({'archive':str(DEST.relative_to(ROOT)),'sha256':digest(DEST.read_bytes()),'bytes':DEST.stat().st_size,'members':len(members),'expanded_bytes':sum(map(len,members.values()))},indent=2))
