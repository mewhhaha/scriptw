"""Derive a local comparison from exact raw commands, receipts and samples."""
from pathlib import Path
import hashlib,json,sys
ROOT=Path('/workspace/scriptw'); WORK=ROOT/'target/performance-module-followup-20261030'
sys.path.insert(0,str(ROOT/'scripts'))
from precompiled_comparison import image_metadata

def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(v):return json.dumps(v,indent=2)+'\n'
def sections(path):
    value=path.read_bytes();assert value[:8]==b'\0asm\1\0\0\0';i=8;out={}
    while i<len(value):
        tag=value[i];i+=1;n=shift=0
        while True:
            v=value[i];i+=1;n|=(v&127)<<shift;shift+=7
            if v<128:break
        assert i+n<=len(value)
        if tag:out[tag]={'bytes':n,'sha256':hashlib.sha256(value[i:i+n]).hexdigest()}
        i+=n
    return out

analysis=load(WORK/'analysis.json')
identities={label:load(WORK/label/'identity.json') for label in ('baseline','candidate')}
producers={label:{c['file']:c for c in load(WORK/(label+'-images')/'producer.json')['cases']} for label in identities}
artifacts=[];ordinary=[]
for row in analysis['workloads']:
    name=row['file']
    if row['original_17_case_fixture']:
        item={'file':name,'products':{}}
        for label in identities:
            producer=producers[label][name]
            image=WORK/(label+'-images')/producer['image']
            metadata=image_metadata(image.read_bytes(),'scriptw',identities[label]['source_fingerprint'])
            assert metadata['sha256']==producer['image_sha256'] and metadata['program_wasm_sha256']==producer['program_wasm_sha256']
            item['products'][label]={'image':metadata,'source_sha256':producer['original_source_sha256'],'derived_source_sha256':producer['derived_source_sha256'],'preparation_phases_ns':producer['phases_ns']}
        artifacts.append(item)
    records=[]
    for r,label in enumerate(analysis['order']):
        path=WORK/f'round-{r}-ordinary-wasm'/(name+'.wasm')
        case=load(WORK/f'round-{r}-{label}-ordinary-{name}.stdout')['cases'][0]
        assert sha(path)==case['wasm_sha256']
        records.append({'round':r,'product':label,'program_sha256':case['wasm_sha256'],'sections':sections(path),'linked_runtime':case['linked_runtime'],'footprint':case['footprint']})
    first=records[0]['sections']
    ordinary.append({'file':name,'all_code_sections_identical':all(r['sections'].get(10)==first.get(10) for r in records),'different_standard_sections':sorted({int(k) for r in records for k in first.keys()|r['sections'].keys() if first.get(k)!=r['sections'].get(k)}),'rounds':records})
(WORK/'artifact-metadata.json').write_text(dump(artifacts))
(WORK/'ordinary-image-comparison.json').write_text(dump(ordinary))
small=next(r for r in analysis['workloads'] if r['file']=='join-small-1024.js')
acceptance={'small_join_at_least_five_percent_faster_in_both_orders':all(g['change_percent']<=-5 for g in small['retained']['balanced_orders']),'small_join_retained_change_percent_by_order':{g['order']:g['change_percent'] for g in small['retained']['balanced_orders']},'controls_reviewed':True,'disposition':'rejected','candidate_production_reverted':True,'reason':'Small retained-call effects disagree by order; ordinary small joins are slower in both orders. Unchanged empty controls also slow; attribution unresolved, and the acceptance gate fails.'}
(WORK/'acceptance.json').write_text(dump(acceptance))
# The archive includes these derived metadata; packaging is deliberately separate.
if not (WORK/'validation.json').exists():
    print('Artifact metadata and numeric acceptance gate derived; package evidence next.');sys.exit(0)
archive=ROOT/'docs/rust-rewrite/join-dense-values-20261030-inert.tar.xz'
snapshots={label:[load(p) for p in sorted((WORK/('test262-'+label)).glob('*.json'))] for label in identities}
report={
 'schema':'scriptw-dense-packed-join-diagnostic-v1','measured_date_utc':'2026-10-30',
 'rejected_candidate_change':'Validate one dense own PackedValues prefix after separator conversion and root its backing across both primitive-only packed join passes. Other values and non-admitted storage retain ordered generic behavior.',
 'scope':analysis['scope'],'disposition':{'candidate':'rejected and production changes reverted','retained':'Semantic storage-transition/ordered-fallback fixture and its existing Rust assert_modes wrapper; README/queue updates and complete rejection evidence.','final_source_validation':load(WORK/'retained-regression-validation.json')},
 'sources':{'baseline_head':identities['baseline']['source_commit'],'baseline_clean':True,'candidate':'Rejected measured candidate on the same HEAD with compile-inputs.patch. The final review patch retains only regression coverage/docs; production code is restored to baseline. Measurements retain their original pre-commit identities.','compiler_identity_scheme':identities['candidate']['compiler_identity_scheme'],'compiler_source_fingerprints':{label:i['source_fingerprint'] for label,i in identities.items()},'compile_inputs_patch':'raw/compile-inputs.patch','compile_inputs_patch_sha256':sha(WORK/'compile-inputs.patch'),'final_review_patch':'raw/final-review.patch','final_review_patch_sha256':sha(WORK/'final-review.patch'),'final_production_matches_baseline_head':True,'retained_fixture_and_wrapper_match_rejected_candidate_test_inputs':True},
 'review_and_plan':load(WORK/'astra-review-plan.json'),'machine':load(WORK/'machine.json'),
 'shared_retained_configuration':identities['candidate']['shared_configuration'],
 'artifacts':{label:load(WORK/label/'products.json') for label in identities},
 'measurement_resources':load(WORK/'measurement-resources.json'),
 'measurement':analysis,'retained_artifact_metadata':artifacts,
 'ordinary_code_comparison':{'raw':'raw/ordinary-image-comparison.json','all_18_program_code_sections_identical':all(r['all_code_sections_identical'] for r in ordinary),'summary':[{'file':r['file'],'all_code_sections_identical':r['all_code_sections_identical'],'different_standard_sections':r['different_standard_sections']} for r in ordinary]},
 'acceptance_gate':acceptance,
 'verification':load(WORK/'validation.json'),
 'selected_original_test262':{'scope':'Three selected original pinned families on both baseline and candidate; not full-suite or publication.','deadline_ms':60000,'jobs':1,'threads':1,'reuse_case_workers':True,'runs':load(WORK/'test262-summary.json')['runs'],'pinned_revisions':snapshots['candidate'][0]['pinned_revisions'],'baseline_total':sum(s['total'] for s in snapshots['baseline']),'baseline_passed':sum(s['passed'] for s in snapshots['baseline']),'candidate_total':sum(s['total'] for s in snapshots['candidate']),'candidate_passed':sum(s['passed'] for s in snapshots['candidate'])},
 'boundaries':{'retained':'Existing public EmbeddedInstance::call, including worker dispatch, guest execution, output capture and completion; same retained function/Store/Realm after one initialization, natural GC. Output draining/checksum verification and source/native preparation, admission, setup and initialization stay outside the call timer and remain raw evidence.','ordinary':'Existing runtime_baseline default automatic native policy; original scripts, fresh Store/Realm for every observation, warm module/host-import caches. Raw records retain compilation, admission/setup, execution, sampled RSS and GC capacity.','startup':'Whole fresh CLI-process elapsed time after ten checked process warmups in each round; not a cold-cache benchmark.','size':'Inert image_metadata framing checks retain raw P Wasm bytes and serialized native-P bytes separately. Serialized native bytes include metadata/data and are not executable-text bytes; whole-container bytes are distinct.','memory':analysis['memory_scope']},
 'limitations':['No current-source PC-sampling percentage: archived exact-address profiling requires a separate diagnostic feature, which these default-feature hosts do not enable. The historical same-kernel profile supports the hypothesis; fresh timings decide acceptance.','The 2070 native checks and359sourceguards describe the rejected candidate, not final-source native acceptance. Final production matches baseline; the retained fixture passes strict/sloppy through its frozen CLI, and baseline selected Test262 is134/134. The unchanged retained Rust wrapper was compiled/passed with the rejected candidate. Full final-source default/all-feature/optimized acceptance remains open.','Whole-workspace formatting retains the same 18 preexisting affected files; no new affected file.','Prior ordinary sort/join and retained-object regressions remain in their original evidence; this local comparison does not replace published V8/Scriptc cohorts or generated conformance status.'],
 'harness_diagnostics':[{'raw':'raw/native-configuration-probe.log','reason':'The initial driver invocation rejected --idle-builds without its required no-test-incremental/codegen settings before any build/test. Retained it; reran the same selected target union without that unnecessary option.'}],
 'evidence':{'archive':archive.name,'sha256':sha(archive),'bytes':archive.stat().st_size,'index':'evidence-index.json','path_mapping':'raw/ maps to target/performance-module-followup-20261030; watched/ maps the exact native receipt transcript paths. All archive members are inert regular files with byte hashes.','native_payloads_archived':False,'reproduction':'Use recorded HEAD and compile-inputs.patch, existing Cargo producers/profiles, raw/build-baseline.py and build-candidate.py, and existing benchmark hosts. raw/measure.py retains prepare commands; raw/run-measurements.py retains balanced orders, every exact measured argv, checksums and aggregation. Rebuild absent native artifacts. Hashes bind provenance; they do not authorize loading external native payloads.'}
}
(ROOT/'docs/rust-rewrite/join-dense-values-20261030.json').write_text(dump(report))
print('Durable diagnostic summary derived from raw receipts and observations.')
