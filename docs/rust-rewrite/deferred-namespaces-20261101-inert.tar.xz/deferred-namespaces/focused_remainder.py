from pathlib import Path
import json,subprocess,sys,time
root=Path.cwd();out=root/'target/performance-deferred-namespaces';sys.path.insert(0,str(root/'scripts'))
from native_test_protocol import parse_inventory,result_summaries
from benchmark_metrics import digest
artifacts={}
for line in (out/'native-build.jsonl').read_text().splitlines():
 r=json.loads(line)
 if r.get('reason')=='compiler-artifact' and r.get('executable') and r['profile']['test']:artifacts[r['target']['name']]=r
scopes=[('aot_gc_entries','aot_gc_namespace_demand::'),('scriptw_aot_wasm','tests::scalar_regions::dormant_math_imul_recipe_'),('scriptw_aot_wasm','tests::intl_demand_initialization::'),('scriptw_aot_wasm','tests::ordered_bootstrap_allocation::'),('scriptw_aot_wasm','gc_types::type_registration_tests::compact_records::')]
folder=out/'native-focused';folder.mkdir(exist_ok=True);records=json.loads((folder/'receipt.json').read_text());scopes=scopes[2:]
for target,selection in scopes:
 p=artifacts[target];exe=Path(p['executable']);sha=digest(exe);listing=subprocess.check_output([exe,'--list'],text=True);inventory=parse_inventory(listing);selected=[n for n in inventory if selection in n];assert selected,(target,selection)
 stem=target+'-'+selection.replace('::','_').strip('_');(folder/(stem+'.inventory')).write_text(listing);argv=[str(exe),'--test-threads=1',selection,'--nocapture'];start=time.monotonic()
 with (folder/(stem+'.stdout')).open('wb') as stdout,(folder/(stem+'.stderr')).open('wb') as stderr:r=subprocess.run(argv,stdout=stdout,stderr=stderr,timeout=3600)
 summaries=result_summaries((folder/(stem+'.stdout')).read_text());row=dict(target=target,selection=selection,selected_inventory=selected,executable_sha256=sha,producer=p,argv=argv,exit_code=r.returncode,summaries=summaries,elapsed_seconds=time.monotonic()-start);records.append(row);(folder/(stem+'.json')).write_text(json.dumps(row,indent=2)+'\n');(folder/'receipt.json').write_text(json.dumps(records,indent=2)+'\n');print(target,selection,len(selected),r.returncode,summaries,flush=True)
 assert digest(exe)==sha and r.returncode==0 and len(summaries)==1 and int(summaries[0][1])==len(selected) and int(summaries[0][2])==int(summaries[0][3])==0
