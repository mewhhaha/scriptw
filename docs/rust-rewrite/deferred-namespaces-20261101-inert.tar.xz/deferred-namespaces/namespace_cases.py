from pathlib import Path
import json,hashlib,sys
OUT=Path(__file__).resolve().parent;folder=OUT/'namespace-controls';folder.mkdir(exist_ok=True)
cases={
 'unused.js':"print(1 === 1);\n",
 'math-first.js':"var m = Math; print(m === Math && m.abs(-7) === 7 && m.PI > 3);\n",
 'reflect-first.js':"var r = Reflect; print(r === Reflect && r.ownKeys({x:1}).join(',') === 'x');\n",
 'json-first.js':"var j = JSON; print(j === JSON && j.stringify(j.parse('{\"x\":1}')) === '{\"x\":1}');\n",
 'atomics-first.js':"var a = Atomics; print(a === Atomics && a.isLockFree(1) === true);\n",
 'all-first.js':"var r=Reflect,m=Math,j=JSON,a=Atomics; print(r===Reflect && m===Math && j===JSON && a===Atomics && typeof r.ownKeys==='function' && m.abs(-7)===7 && j.stringify({x:1})==='{\"x\":1}' && a.isLockFree(1));\n",
 'descriptors-first.js':"var r=Object.getOwnPropertyDescriptor(globalThis,'Reflect'),m=Object.getOwnPropertyDescriptor(globalThis,'Math'),j=Object.getOwnPropertyDescriptor(globalThis,'JSON'),a=Object.getOwnPropertyDescriptor(globalThis,'Atomics'); print(r.value===Reflect && m.value===Math && j.value===JSON && a.value===Atomics && r.writable && !r.enumerable && r.configurable && m.writable && !m.enumerable && m.configurable && j.writable && !j.enumerable && j.configurable && a.writable && !a.enumerable && a.configurable);\n",
 'zero-imul.js':"(function(){var s=1;for(var i=0;i<0;i++){s=Math.imul(s,2);}print(s===1 && i===0);})();\n",
 'replace-unread.js':"globalThis.Reflect=1;globalThis.Math=2;globalThis.JSON=3;globalThis.Atomics=4;print(Reflect+Math+JSON+Atomics===10);\n",
}
manifest=dict(schema='scriptw-namespace-demand-controls-v1',execution=[dict(file=name,stdout='true\n') for name in cases]);(folder/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for name,text in cases.items():(folder/name).write_text(text)
plan=dict(status='predeclared before measurements',targets=['unused.js','zero-imul.js','replace-unread.js'],controls=[n for n in cases if n not in ['unused.js','zero-imul.js','replace-unread.js']],samples=21,warmups=10,schedule='ABBABAAB / BAABABBA, four independent invocations per product per case per block',gate='All three targets improve both block medians; any forced-first-touch/descriptor control >=3% median AND mean in both blocks vetoes. Retain all samples.',sources_sha256={n:hashlib.sha256(t.encode()).hexdigest() for n,t in cases.items()})
(folder/'study-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
