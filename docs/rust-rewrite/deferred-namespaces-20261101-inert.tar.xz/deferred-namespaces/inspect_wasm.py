"""Capture representative frozen P modules and exact named R helper bodies."""
import hashlib
import json
from pathlib import Path
import struct
import subprocess

ROOT = Path.cwd()
OUT = ROOT / "target/performance-deferred-namespaces"
FOLDER = OUT / "program-inspection"
TOOL = ROOT / "target/performance-fresh-sort/tools/wasm-tools"
RUN = OUT / "runs/20261101T061207Z-candidate-full17"
ANALYSIS = RUN / "analysis.json"
PORTABLE_PACKAGE = OUT / "candidate/runtime-build/scriptw-runtime-portable-package.bin"
MAX_FUNCTION_BYTES = 8 * 1024 * 1024


def sha256_bytes(data):
    return hashlib.sha256(data).hexdigest()


def sha256_file(path):
    return sha256_bytes(Path(path).read_bytes())


def named_function_fragment(runtime_wasm, function_name):
    process = subprocess.Popen(
        [str(TOOL), "print", str(runtime_wasm)],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )
    fragment = []
    byte_count = 0
    started = False
    for line in process.stdout:
        if line.startswith(f"  (func ${function_name} "):
            started = True
        if not started:
            continue
        fragment.append(line)
        byte_count += len(line.encode("utf-8"))
        assert byte_count <= MAX_FUNCTION_BYTES, (function_name, byte_count)
        if line.rstrip() == "  )":
            break
    process.terminate()
    _, stderr = process.communicate(timeout=10)
    assert started and fragment[-1].rstrip() == "  )", (function_name, stderr)
    if process.returncode not in (0, -15, -13):
        raise RuntimeError(f"wasm-tools print failed for {function_name}: {stderr}")
    return "".join(fragment)


def save_fragment(runtime_wasm, name, path_name, scope):
    text = named_function_fragment(runtime_wasm, name)
    path = FOLDER / path_name
    path.write_text(text)
    data = path.read_bytes()
    return dict(
        function=name,
        path=path.name,
        scope=scope,
        line_count=len(text.splitlines()),
        byte_count=len(data),
        sha256=sha256_bytes(data),
    )


def main():
    FOLDER.mkdir(exist_ok=True)
    tool_version = subprocess.check_output([str(TOOL), "--version"], text=True).strip()
    analysis = json.loads(ANALYSIS.read_text())
    products = []
    for case in ["numeric-loop-50000.js", "sort-reverse-512.js", "join-small-1024.js"]:
        row = next(
            row for row in analysis["rows"]
            if row["case"] == case and row["product"] == "candidate"
        )
        scriptw = RUN / "artifacts" / row["raw"] / (case + ".wasm")
        for label, source in [
            ("scriptw", scriptw),
            ("scriptc", OUT / "scriptc-wasm" / (case + ".wasm")),
        ]:
            wat = FOLDER / f"{label}-{case}.wat"
            with wat.open("wb") as stdout:
                subprocess.run([str(TOOL), "print", str(source)], stdout=stdout, check=True)
            products.append(dict(
                product=label,
                case=case,
                source_wasm=str(source.relative_to(OUT)),
                wasm_sha256=sha256_file(source),
                wat=wat.name,
                wat_bytes=wat.stat().st_size,
                wat_sha256=sha256_file(wat),
            ))

    package = PORTABLE_PACKAGE.read_bytes()
    runtime_wasm = package[136:-32]
    assert len(runtime_wasm) == struct.unpack_from("<Q", package, 128)[0]
    runtime_path = FOLDER / "runtime-portable-inspection-input.wasm"
    runtime_path.write_bytes(runtime_wasm)
    runtime_hash = sha256_bytes(runtime_wasm)
    fragments = [
        save_fragment(
            runtime_path,
            "helper::pooled_string_resolve",
            "runtime-pooled-string-resolve.wat-fragment",
            "Exact named function fragment from the frozen Portable R; its module is required to resolve external type/global names.",
        ),
        save_fragment(
            runtime_path,
            "helper::deferred_namespace_resolve",
            "runtime-deferred-namespace-resolve.wat-fragment",
            "Exact named function fragment from the frozen Portable R; its module is required to resolve external type/global names.",
        ),
    ]
    runtime_path.unlink()

    identity = json.loads((OUT / "candidate/identity.json").read_text())
    record = dict(
        source_commit=identity["source_commit"],
        source_fingerprint=identity["source_fingerprint"],
        tool_version=tool_version,
        products=products,
        runtime=dict(
            source="candidate/runtime-build/scriptw-runtime-portable-package.bin",
            package_sha256=sha256_bytes(package),
            package_bytes=len(package),
            wasm_sha256=runtime_hash,
            wasm_bytes=len(runtime_wasm),
            fragments=fragments,
        ),
    )
    (FOLDER / "identity.json").write_text(json.dumps(record, indent=2) + "\n")
    print("prepared six P modules and two exact Portable R helper fragments", flush=True)


if __name__ == "__main__":
    main()
