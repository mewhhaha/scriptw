from pathlib import Path
import json
import run
folder=run.OUT/'namespace-controls'
manifest=json.loads((folder/'manifest.json').read_text())
plan=json.loads((folder/'study-plan.json').read_text())
record=dict(manifest=manifest,manifest_sha256=run.digest(folder/'manifest.json'),files_sha256=plan['sources_sha256'])
load_original=run.load
def load(path):
 if Path(path)==run.OUT/'corpus.json':return record
 return load_original(path)
def check():
 assert run.digest(folder/'manifest.json')==record['manifest_sha256']
 for name,sha in plan['sources_sha256'].items():assert run.digest(folder/name)==sha
 return manifest
run.load=load
run.CORPUS=folder
run.check_corpus=check
run.TARGETS=plan['targets']
run.run_paired('candidate','namespace-controls',21,10)
