"""Read-only raw audit; run under limited_verification after cohorts finish.

Adapted from performance-entry-bootstrap/independent-audit.py.
Baseline ABI42 / candidate ABI43; AA, original17, CP and namespace controls.
Candidate fingerprint and completed run directories are explicit inputs.
No benchmark invocation, build, statistical exclusion, or acceptance override.
"""
import argparse
import collections
import difflib
import hashlib
import json
import math
from pathlib import Path
import statistics
import struct

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
CORPUS = ROOT / 'crates/scriptw-cli/tests/fixtures/v8_execution_hotpaths'
BASELINE_FP = '5b20fafcf08ed06d495ffb4f3a980fcc65e819ebfcc9bf597754ef4c6300ab75'
BASELINE_HOST = '3de9b9fb1a733348c671acfed689e25a527d6a331131f21b0388aa2c15cbe0f7'
BASELINE_COMMIT = '259d4c4a644006acaa1e648616007406658a796d'
BASELINE_ACCEPTED_COMMIT = 'c5586f330d57a8fa70a97836b4d0a8c5cda201d0'
PRIMARY_TARGETS = {'sort-reverse-128.js', 'sort-reverse-512.js', 'sort-sorted-512.js',
    'to-sorted-512.js', 'numeric-loop-10000.js', 'numeric-loop-50000.js',
    'join-empty-1024.js', 'join-singleton-1024.js', 'join-small-1024.js'}
SCHEDULES = {
    'block0': ['baseline', 'candidate', 'candidate', 'baseline',
               'candidate', 'baseline', 'baseline', 'candidate'],
    'block1': ['candidate', 'baseline', 'baseline', 'candidate',
               'baseline', 'candidate', 'candidate', 'baseline'],
}
MEMORY, IMAGE_LIMIT = 4294967296, 67108864
HASHED = {}
P_IDENTITIES = collections.defaultdict(set)
P_CODE = {}
MAX_RSS = 0
MAX_DISCREPANCY = 0.0


def load(path):
    return json.loads(Path(path).read_text())


def digest(data):
    return hashlib.sha256(data).hexdigest()


def file_hash(path):
    path = Path(path).resolve()
    if path not in HASHED:
        with path.open('rb') as stream:
            HASHED[path] = hashlib.file_digest(stream, 'sha256').hexdigest()
    return HASHED[path]


def close(actual, reported):
    global MAX_DISCREPANCY
    assert math.isfinite(actual) and math.isfinite(reported)
    discrepancy = abs(actual - reported)
    MAX_DISCREPANCY = max(MAX_DISCREPANCY, discrepancy)
    assert discrepancy <= 1e-7, (actual, reported, discrepancy)


def uleb(data, position):
    value = shift = 0
    while True:
        byte = data[position]
        position += 1
        value |= (byte & 127) << shift
        if byte < 128:
            return value, position
        shift += 7
        assert shift < 64


def wasm_code(data):
    assert data[:8] == b'\0asm\x01\0\0\0'
    position = 8
    result = (0, 0, 0, b'')
    found = False
    while position < len(data):
        kind = data[position]
        length, position = uleb(data, position + 1)
        end = position + length
        assert end <= len(data)
        if kind == 10:
            assert not found
            found = True
            code = data[position:end]
            count, position = uleb(data, position)
            sizes = []
            for _ in range(count):
                size, position = uleb(data, position)
                sizes.append(size)
                position += size
                assert position <= end
            assert position == end
            result = (count, sum(sizes), max(sizes, default=0), code)
        position = end
    assert position == len(data)
    return result


def corpus():
    record = load(BASE / 'corpus.json')
    assert file_hash(CORPUS / 'manifest.json') == record['manifest_sha256']
    assert load(CORPUS / 'manifest.json') == record['manifest']
    for name, expected in record['files_sha256'].items():
        assert file_hash(CORPUS / name) == expected
    cases = record['manifest']['execution']
    assert len(cases) == 17 and len({row['file'] for row in cases}) == 17
    return record, cases


def namespace_corpus():
    folder = BASE / 'namespace-controls'
    manifest, plan = load(folder / 'manifest.json'), load(folder / 'study-plan.json')
    assert manifest['schema'] == 'scriptw-namespace-demand-controls-v1'
    cases = manifest['execution']
    names = {row['file'] for row in cases}
    assert len(cases) == len(names) == 9
    targets = set(plan['targets'])
    assert targets == {'unused.js', 'zero-imul.js', 'replace-unread.js'}
    assert len(plan['controls']) == 6 and set(plan['controls']) == names - targets
    assert plan['samples'] == 21 and plan['warmups'] == 10
    assert set(plan['sources_sha256']) == names
    for case in cases:
        assert case['stdout'] == 'true\n'
        assert file_hash(folder / case['file']) == plan['sources_sha256'][case['file']]
    return dict(manifest_sha256=file_hash(folder / 'manifest.json'),
        study_plan_sha256=file_hash(folder / 'study-plan.json'),
        wrapper_sha256=file_hash(BASE / 'namespace_control.py'),
        manifest=manifest, plan=plan), cases, targets


def namespace_footprints(cases):
    result = []
    for case in cases:
        name = case['file']
        identities = {label: next(iter(P_IDENTITIES[(name, label)]))
                      for label in ['baseline', 'candidate']}
        result.append(dict(case=name, identities=identities,
            P_bytes_equal=identities['baseline'][1] == identities['candidate'][1],
            exact_code_section_equal=P_CODE[(name, 'baseline')] == P_CODE[(name, 'candidate')]))
    return result


def products():
    result = {}
    for label in ['baseline', 'baseline-aa', 'candidate']:
        directory = BASE / label
        identity = load(directory / 'identity.json')
        hosts = load(directory / 'host-products.json')
        original = load(directory / 'products.json')
        for name, row in hosts.items():
            path = directory / name
            assert path.is_file() and not path.is_symlink() and path.stat().st_nlink == 1
            assert path.stat().st_size == row['bytes']
            assert file_hash(path) == row['sha256'] == original[name]['sha256']
        assert identity['executable_sha256'] == hosts['compiler_precompiled_baseline']['sha256']
        if label != 'candidate':
            assert identity['source_fingerprint'] == BASELINE_FP
            assert identity['source_commit'] == BASELINE_COMMIT
            assert hosts['runtime_baseline']['sha256'] == BASELINE_HOST
        result[label] = dict(identity=identity, hosts=hosts)
    source = load(BASE / 'candidate/source.json')
    assert source['head'] == result['candidate']['identity']['source_commit']
    assert source['fingerprint'] == result['candidate']['identity']['source_fingerprint']
    assert source['patch_sha256'] == file_hash(BASE / 'candidate/source.patch')
    # These hashes bind the build inputs, not the later checkout state.
    built = load(BASE / 'pre-build-sources.json')
    frozen = load(BASE / 'candidate/source-files.json')
    assert all(frozen.get(name) == expected for name, expected in built.items())
    for name in ['crates/scriptw-aot-wasm/src/builtins/bootstrap/namespace_initialization.rs',
                 'crates/scriptw-engine/tests/aot_gc_entries/aot_gc_namespace_demand.rs']:
        assert name in built and name in frozen, 'new source must be a frozen build input'
    return result


def runtimes(product_records):
    delta = load(BASE / 'runtime-profile-delta.json')
    result = {}
    old = ROOT / 'target/performance-entry-bootstrap/candidate/runtime-build'
    new = BASE / 'candidate/runtime-build'
    for label, directory in [('baseline', old), ('candidate', new)]:
        profiles = {}
        for suffix in ['', '-portable']:
            name = f'scriptw-runtime{suffix}-package.bin'
            package = (directory / name).read_bytes()
            assert package[:8] == b'SCRWRB01'
            abi = 43 if label == 'candidate' else 42
            assert struct.unpack_from('<I', package, 8)[0] == abi
            assert package[12:44].hex() == product_records[label]['identity']['source_fingerprint']
            wasm = package[136:-32]
            assert len(wasm) == struct.unpack_from('<Q', package, 128)[0]
            assert digest(package[:-32]) == package[-32:].hex()
            record = delta[name]
            prefix = '' if label == 'candidate' else 'previous_'
            assert record[prefix + 'runtime_abi'] == abi
            assert record[prefix + 'source_fingerprint'] == product_records[label]['identity']['source_fingerprint']
            assert len(wasm) == record[prefix + 'runtime_wasm_bytes']
            assert digest(wasm) == record[prefix + 'runtime_wasm_sha256']
            native_name = f'scriptw-runtime{suffix}-native.bin'
            native = directory / native_name
            native_record = delta[native_name]
            assert native.stat().st_size == native_record[prefix + 'bytes']
            assert file_hash(native) == native_record[prefix + 'sha256']
            profiles[suffix or 'native'] = dict(runtime_key=package[76:108].hex(),
                wasm_sha256=digest(wasm), wasm_bytes=len(wasm),
                native_sha256=file_hash(native), native_bytes=native.stat().st_size, abi=abi)
        result[label] = profiles
    for suffix in ['', '-portable']:
        key = suffix or 'native'
        assert delta[f'scriptw-runtime{suffix}-package.bin']['runtime_wasm_identical'] == (
            result['baseline'][key]['wasm_sha256'] == result['candidate'][key]['wasm_sha256'])
        assert delta[f'scriptw-runtime{suffix}-native.bin']['native_identical'] == (
            result['baseline'][key]['native_sha256'] == result['candidate'][key]['native_sha256'])
    result['baseline-aa'] = result['baseline']
    return result


def native_test_outcomes(row, stdout):
    results = {}
    for line in stdout.read_text().splitlines():
        if not line.startswith('test ') or ' ... ' not in line:
            continue
        name, status = line[5:].rsplit(' ... ', 1)
        name = name.removesuffix(' - should panic')
        if status in ['ok', 'FAILED']:
            assert name not in results
            results[name] = status
    assert set(results) == set(row['selected_inventory'])
    assert len(row['summaries']) == 1
    summary = row['summaries'][0]
    passed = {name for name, status in results.items() if status == 'ok'}
    failed = set(results) - passed
    assert int(summary[1]) == len(passed) and int(summary[2]) == len(failed)
    assert int(summary[3]) == int(summary[4]) == 0
    assert summary[0] == ('FAILED' if failed else 'ok')
    assert row['exit_code'] == (101 if failed else 0)
    return passed, failed


def encoded_test_correction(product_records, corrected_receipt):
    evidence = BASE / 'encoded-witness-correction'
    rebuilt = BASE / 'encoded-test-correction'
    metadata = load(evidence / 'independent-chain.json')
    correction = load(evidence / 'correction.json')
    fingerprint = product_records['candidate']['identity']['source_fingerprint']
    assert fingerprint == metadata['production_source_fingerprint'] == correction['production_source_fingerprint']
    assert fingerprint == '62ff8d84ca4b5d9d3a763739378b029effc2f4c25bf045ffac257bff9a2f0a84'
    assert file_hash(evidence / 'correction.json') == metadata['before_after_metadata_sha256']
    before_manifest = load(BASE / 'pre-build-sources.json')
    frozen_manifest = load(BASE / 'candidate/source-files.json')
    current_after = load(rebuilt / 'current-test-hashes.json')
    expected_paths = {
        'crates/scriptw-aot-wasm/src/tests/scalar_regions.rs',
        'crates/scriptw-aot-wasm/src/tests/intl_demand_initialization.rs',
    }
    assert {row['path'] for row in correction['files']} == expected_paths
    assert set(current_after) == expected_paths
    reconstructed_patch = []
    final_source_hashes = {}
    second = evidence / 'second-scalar-correction'
    second_record = load(second / 'correction.json')
    assert second_record['production_source_fingerprint'] == fingerprint
    for row in correction['files']:
        name = Path(row['path']).name
        before, after = evidence / ('before-' + name), evidence / ('after-' + name)
        assert file_hash(before) == row['before_sha256'] == before_manifest[row['path']] == frozen_manifest[row['path']]
        assert file_hash(rebuilt / ('original-' + name)) == row['before_sha256']
        assert file_hash(after) == row['after_sha256']
        final_hash = row['after_sha256']
        if name == 'scalar_regions.rs':
            before_second, after_second = second / 'before-scalar_regions.rs', second / 'after-scalar_regions.rs'
            assert file_hash(before_second) == row['after_sha256'] == second_record['before_sha256']
            final_hash = file_hash(after_second)
            assert final_hash == second_record['after_sha256']
            second_patch = ''.join(difflib.unified_diff(before_second.read_text().splitlines(True),
                after_second.read_text().splitlines(True), fromfile='a/' + row['path'], tofile='b/' + row['path']))
            assert second_patch == (second / 'test-only.patch').read_text()
            assert file_hash(second / 'test-only.patch') == second_record['patch_sha256']
            assert file_hash(BASE / 'witness-diagnostic/run-function.wat-fragment') == second_record['evidence_wat_sha256']
        assert current_after[row['path']] == file_hash(ROOT / row['path']) == final_hash
        final_source_hashes[row['path']] = final_hash
        reconstructed_patch.extend(difflib.unified_diff(before.read_text().splitlines(True),
            after.read_text().splitlines(True), fromfile='a/' + row['path'], tofile='b/' + row['path']))
    assert ''.join(reconstructed_patch) == (evidence / 'test-only.patch').read_text()
    assert file_hash(evidence / 'test-only.patch') == correction['patch_sha256']
    registry = ROOT / 'crates/scriptw-engine/compiler_fingerprint.rs'
    assert file_hash(registry) == metadata['fingerprint_registry_sha256']
    excluded = registry.read_text().split('const TEST_ONLY_INPUTS:', 1)[1].split('];', 1)[0]
    assert '"' + metadata['test_only_prefix'] + '",' in excluded
    assert all(name.startswith(metadata['test_only_prefix'] + '/') for name in expected_paths)
    for name, expected in metadata['unchanged_other_recorded_crate_inputs'].items():
        assert before_manifest[name] == frozen_manifest[name] == expected
        assert file_hash(ROOT / name) == expected
    original_binary = rebuilt / 'original-backend-tests'
    original_sha = file_hash(original_binary)
    assert original_sha == metadata['original_backend_binary_sha256']
    assert original_sha == load(rebuilt / 'original-source-sha.json')['binary_sha256']
    original = evidence / 'original-focused'
    for name, expected in metadata['original_focused_files_sha256'].items():
        assert file_hash(original / name) == expected


    original_rows = load(original / 'receipt.json')
    assert len(original_rows) == 5
    original_passes, original_failures, selected = set(), set(), set()
    backend_passes, semantic_passes = set(), set()
    for row in original_rows:
        stem = row['target'] + '-' + row['selection'].replace('::', '_').strip('_')
        assert load(original / (stem + '.json')) == row
        passed, failed = native_test_outcomes(row, original / (stem + '.stdout'))
        assert not selected.intersection(row['selected_inventory'])
        selected.update(row['selected_inventory'])
        original_passes.update(passed)
        original_failures.update(failed)
        if row['target'] == 'scriptw_aot_wasm':
            assert row['executable_sha256'] == original_sha
            backend_passes.update(passed)
        else:
            assert row['target'] == 'aot_gc_entries' and not failed
            semantic_passes.update(passed)
    corrected_tests = set(metadata['corrected_tests'])
    assert original_failures == corrected_tests and len(corrected_tests) == 2
    assert len(backend_passes) == 9 and len(semantic_passes) == 6
    assert len(original_passes) == 15 and len(selected) == 17
    assert not original_passes.intersection(corrected_tests)

    attempt = rebuilt / 'attempt1'
    intermediate_rows = load(attempt / 'corrected-receipt.json')
    assert len(intermediate_rows) == 1
    intermediate = intermediate_rows[0]
    intermediate_sha = file_hash(rebuilt / 'attempt1-backend-tests')
    assert intermediate['executable_sha256'] == intermediate_sha != original_sha
    # Original absolute paths are retained in the receipt; its streams moved
    # together into attempt1 before the final corrected run reused those names.
    intermediate_stdout = attempt / Path(intermediate['stdout']).name
    intermediate_stderr = attempt / Path(intermediate['stderr']).name
    passed, failed = native_test_outcomes(intermediate, intermediate_stdout)
    scalar_test = 'tests::scalar_regions::dormant_math_imul_recipe_admits_the_literal_whole_trip_without_resolving_math'
    assert not passed and failed == {scalar_test}
    assert 'guard performs no namespace, property, or pooled-string resolution' in intermediate_stderr.read_text()
    intermediate_build = [json.loads(line) for line in (attempt / 'build.jsonl').read_text().splitlines()]
    assert intermediate_build[-1] == {'reason': 'build-finished', 'success': True}
    assert intermediate['producer'] in intermediate_build
    unqualified = load(rebuilt / 'intl-attempt1.json')
    assert unqualified['executable_sha256'] == intermediate_sha and unqualified['exit_code'] == 0
    assert 'without limited_verification wrapper' in unqualified['scope']
    assert 'excluded from qualifying native coverage' in unqualified['scope']
    assert unqualified['argv'][1:3] == ['--exact', next(name for name in corrected_tests if 'intl_demand' in name)]

    corrected_receipt = corrected_receipt.resolve()
    corrected_rows = load(corrected_receipt)
    assert len(corrected_rows) == 2
    build_rows = [json.loads(line) for line in (rebuilt / 'build.jsonl').read_text().splitlines()]
    assert build_rows[-1] == {'reason': 'build-finished', 'success': True}
    reuse = load(rebuilt / 'production-reuse.json')
    assert reuse['source_fingerprint'] == fingerprint
    assert set(reuse['changed_source_paths']) == expected_paths
    corrected_binary = rebuilt / 'corrected-backend-tests'
    corrected_sha = file_hash(corrected_binary)
    assert corrected_sha not in [original_sha, intermediate_sha]
    corrected_passes = set()
    for row in corrected_rows:
        assert row['target'] == 'scriptw_aot_wasm'
        assert row['executable_sha256'] == corrected_sha
        assert row['producer'] in build_rows and row['producer']['profile']['test'] is True
        assert row['producer']['target']['name'] == 'scriptw_aot_wasm'
        assert len(row['selected_inventory']) == 1
        assert row['argv'][1:3] == ['--exact', row['selected_inventory'][0]]
        passed, failed = native_test_outcomes(row, Path(row['stdout']))
        assert not failed and len(passed) == 1
        assert not corrected_passes.intersection(passed)
        corrected_passes.update(passed)
        file_hash(row['stdout'])
        file_hash(row['stderr'])
    assert corrected_passes == corrected_tests
    assert original_passes | corrected_passes == selected
    reused = load(rebuilt / 'reused-passes.json')
    assert reused['corrected_binary_sha256'] == corrected_sha
    reused_by_name = {name: row['executable_sha256'] for row in reused['scopes'] for name in row['selected_inventory']}
    assert len(reused_by_name) == sum(len(row['selected_inventory']) for row in reused['scopes']) == 11
    assert set(reused_by_name) == backend_passes | corrected_passes
    assert all(reused_by_name[name] == original_sha for name in backend_passes)
    assert all(reused_by_name[name] == corrected_sha for name in corrected_passes)
    assert reused['production_reuse'] == reuse
    wrapper_log = (rebuilt / 'verify.log').read_text()
    assert 'limited-verification: confirmed kernel memory cap 4096 MiB, swap 0, one CPU' in wrapper_log
    return dict(production_source_fingerprint=fingerprint, original_to_first_correction=correction['files'],
        first_to_final_scalar_correction=second_record, final_source_hashes=final_source_hashes,
        patch_sha256=correction['patch_sha256'], fingerprint_registry_sha256=file_hash(registry),
        excluded_prefix=metadata['test_only_prefix'], original_backend_binary_sha256=original_sha,
        corrected_backend_binary_sha256=corrected_sha,
        original_focused_receipt_sha256=file_hash(original / 'receipt.json'),
        corrected_receipt_path=str(corrected_receipt), corrected_receipt_sha256=file_hash(corrected_receipt),
        corrected_build_receipt_sha256=file_hash(rebuilt / 'build.jsonl'),
        production_reuse_receipt_sha256=file_hash(rebuilt / 'production-reuse.json'),
        original_failed_tests=sorted(original_failures),
        retained_original_backend_passes=sorted(backend_passes),
        retained_original_semantic_passes=sorted(semantic_passes),
        corrected_exact_test_passes=sorted(corrected_passes),
        focused_unique_pass_union=17, focused_backend_unique_pass_union=11,
        original_failure_count=2, intermediate_failure_count=1,
        intermediate_failed_test=scalar_test, intermediate_backend_binary_sha256=intermediate_sha,
        intermediate_failure_receipt_sha256=file_hash(attempt / 'corrected-receipt.json'),
        intermediate_build_receipt_sha256=file_hash(attempt / 'build.jsonl'),
        intermediate_stdout_sha256=file_hash(intermediate_stdout),
        intermediate_stderr_sha256=file_hash(intermediate_stderr),
        excluded_uncapped_diagnostic=dict(receipt_sha256=file_hash(rebuilt / 'intl-attempt1.json'),
            stdout_sha256=file_hash(rebuilt / 'intl-attempt1.stdout'),
            stderr_sha256=file_hash(rebuilt / 'intl-attempt1.stderr'),
            counted_as_qualifying_pass=False, scope=unqualified['scope']),
        reused_passes_sha256=file_hash(rebuilt / 'reused-passes.json'),
        capped_corrected_run_log_sha256=file_hash(rebuilt / 'verify.log'),
        scope='Two original failures and the intermediate scalar witness failure are preserved. Both final exact tests passed under the wrapper; the uncapped Intl diagnostic is excluded. Nine original backend and six semantic passes retained; no broader-conformance claim.')



def temporal_test_correction(product_records, focused):
    folder = BASE / 'temporal-test-correction'
    independent = folder / 'independent'
    metadata = load(independent / 'chain.json')
    correction = load(folder / 'correction.json')
    identity = product_records['candidate']['identity']
    assert identity['source_fingerprint'] == metadata['production_source_fingerprint'] == focused['production_source_fingerprint']
    assert identity['source_commit'] == metadata['original_source_commit']
    source_path = metadata['source_path']
    assert source_path == 'crates/scriptw-aot-wasm/src/tests/temporal_demand_initialization.rs'
    assert source_path.startswith(focused['excluded_prefix'] + '/')
    before = folder / 'original-temporal_demand_initialization.rs'
    after = independent / 'corrected-temporal_demand_initialization.rs'
    assert file_hash(before) == metadata['before_sha256'] == correction['original_source_sha256']
    assert file_hash(after) == metadata['after_sha256'] == correction['corrected_source_sha256'] == file_hash(ROOT / source_path)
    committed = before.read_bytes()
    assert hashlib.sha1(b'blob ' + str(len(committed)).encode() + b'\0' + committed).hexdigest() == metadata['original_source_git_blob']
    patch = ''.join(difflib.unified_diff(before.read_text().splitlines(True), after.read_text().splitlines(True),
        fromfile='a/' + source_path, tofile='b/' + source_path))
    assert patch == (independent / 'test-only.patch').read_text()
    assert file_hash(independent / 'test-only.patch') == metadata['patch_sha256']
    for name, expected in metadata['original_files_sha256'].items():
        assert file_hash(folder / name) == expected
    original = load(folder / 'original-scriptw_aot_wasm.json')
    assert original in load(folder / 'original-broad-receipt.json')
    original_sha = file_hash(folder / 'original-backend-tests')
    assert original_sha == correction['original_binary_sha256'] == original['executable_sha256'] == focused['corrected_backend_binary_sha256']
    assert original['target'] == 'scriptw_aot_wasm'
    passed, failed = native_test_outcomes(original, folder / 'original-scriptw_aot_wasm.stdout')
    expected_test = metadata['expected_exact_test']
    assert failed == {expected_test} and len(passed) == 568
    focused_backend = set(focused['retained_original_backend_passes']) | set(focused['corrected_exact_test_passes'])
    assert len(focused_backend) == 11 and not focused_backend.intersection(original['selected_inventory'])
    inventory = {line.removesuffix(': test') for line in (folder / 'original-scriptw_aot_wasm.inventory').read_text().splitlines() if line.endswith(': test')}
    assert len(inventory) == 580 and inventory == set(original['selected_inventory']) | focused_backend
    rows = load(folder / 'corrected-receipt.json')
    assert len(rows) == 1
    row = rows[0]
    corrected_sha = file_hash(folder / 'corrected-backend-tests')
    assert corrected_sha != original_sha and row['executable_sha256'] == corrected_sha
    assert row['target'] == 'scriptw_aot_wasm' and row['selected_inventory'] == [expected_test]
    assert row['argv'][1:3] == ['--exact', expected_test]
    build = [json.loads(line) for line in (folder / 'build.jsonl').read_text().splitlines()]
    assert build[-1] == {'reason': 'build-finished', 'success': True}
    assert row['producer'] in build and row['producer']['profile']['test'] is True
    assert row['producer']['target']['name'] == 'scriptw_aot_wasm'
    corrected_passes, corrected_failures = native_test_outcomes(row, Path(row['stdout']))
    assert corrected_passes == {expected_test} and not corrected_failures
    assert 'limited-verification: confirmed kernel memory cap 4096 MiB, swap 0, one CPU' in (folder / 'verify.log').read_text()
    reuse = load(folder / 'production-reuse.json')
    assert reuse['source_fingerprint'] == identity['source_fingerprint']
    assert set(reuse['changed_source_paths']) == set(focused['final_source_hashes']) | {source_path}
    union = passed | focused_backend | corrected_passes
    assert union == inventory
    return dict(production_source_fingerprint=identity['source_fingerprint'], source_correction=metadata,
        original_failed_tests=sorted(failed), retained_broad_passes=sorted(passed),
        original_backend_binary_sha256=original_sha, corrected_backend_binary_sha256=corrected_sha,
        corrected_exact_test_passes=sorted(corrected_passes),
        corrected_receipt_sha256=file_hash(folder / 'corrected-receipt.json'),
        corrected_build_receipt_sha256=file_hash(folder / 'build.jsonl'),
        capped_corrected_run_log_sha256=file_hash(folder / 'verify.log'),
        corrected_stdout_sha256=file_hash(row['stdout']), corrected_stderr_sha256=file_hash(row['stderr']),
        production_reuse_receipt_sha256=file_hash(folder / 'production-reuse.json'),
        backend_unique_pass_union=len(union), retained_broad_count=568,
        retained_original_focused_count=9, first_corrected_exact_count=2, temporal_corrected_exact_count=1,
        scope='One original Temporal assertion failure is preserved. Backend coverage is the disjoint union of568 retained broad passes,9 original focused passes,2 previously corrected exact passes and1 corrected Temporal exact pass. Other native suites and Test262 are outside this count.')


def resource_check(command):
    global MAX_RSS
    assert command['exit_code'] == 0 and command['timed_out'] is False
    assert command['affinity'] == [0]
    assert 0 < command['peak_rss_bytes'] <= MEMORY
    MAX_RSS = max(MAX_RSS, command['peak_rss_bytes'])
    before, after = command['resources_before'], command['resources_after']
    for snapshot in [before, after]:
        assert snapshot['memory.max'].strip() == str(MEMORY)
        assert snapshot['memory.swap.max'].strip() == '0'
        assert snapshot['memory.oom.group'].strip() == '1'
        events = dict(line.split() for line in snapshot['memory.events'].splitlines())
        assert all(int(value) == 0 for value in events.values()), events
    assert before == after, 'resource policy or memory events changed'


def verify_identity(report, label, records, host):
    expected = records[label]
    identity = expected['identity']
    assert report['source_commit'] == identity['source_commit']
    assert report['source_fingerprint'] == identity['source_fingerprint']
    assert report['executable_sha256'] == expected['hosts'][host]['sha256']


def observations(report, expected_stdout, cp=False):
    obs = report['observations']
    assert len(obs) == 31
    assert [row['warmup'] for row in obs] == [True] * 10 + [False] * 21
    assert all(row['stdout'] == expected_stdout for row in obs)
    timings = [row['phases_ns']['execution'] if cp else row['execution_ns'] for row in obs]
    assert all(type(value) is int and value > 0 for value in timings)
    values = timings[10:]
    return dict(times=values, median=statistics.median(values), mean=statistics.mean(values))


def compare(analysis, groups, cases, aa, cp, targets):
    results, vetoes, targets_failed, any_blocks, repeated_all = [], [], [], [], []
    assert len(analysis['comparisons']) == len(cases)
    indexed = {row['case']: row for row in analysis['comparisons']}
    assert set(indexed) == {row['file'] for row in cases}
    other = 'baseline-aa' if aa else 'candidate'
    for case in cases:
        name = case['file']
        recorded = indexed[name]
        control = cp or name not in targets
        if not cp:
            assert recorded['control'] == control
        blocks = []
        assert [row['block'] for row in recorded['blocks']] == list(SCHEDULES)
        for block in recorded['blocks']:
            block_name = block['block']
            stats = {}
            for product in ['baseline', other]:
                rows = groups[(name, block_name, product)]
                assert len(rows) == 4
                pooled = [value for row in rows for value in row['times']]
                actual = [statistics.median(row['median'] for row in rows),
                          statistics.mean(row['mean'] for row in rows),
                          statistics.median(pooled), statistics.mean(pooled)]
                published = block['products'][product]
                fields = ['block_median_ns', 'block_mean_ns'] if cp else [
                    'block_median_of_invocation_medians_ns', 'block_mean_of_invocation_means_ns',
                    'pooled_sample_median_ns', 'pooled_sample_mean_ns']
                for field, value in zip(fields, actual):
                    close(value, published[field])
                if not cp:
                    assert published['invocation_count'] == 4 and published['sample_count'] == 84
                refs = {row['raw']: row for row in published['invocations']}
                assert set(refs) == {row['raw'] for row in rows}
                for row in rows:
                    close(row['median'], refs[row['raw']]['median_ns'])
                    close(row['mean'], refs[row['raw']]['mean_ns'])
                    assert row['process_elapsed_ns'] == refs[row['raw']]['process_elapsed_ns']
                stats[product] = actual
            changes = [100 * (b / a - 1) for a, b in zip(stats['baseline'], stats[other])]
            fields = ['median_percent', 'mean_percent'] if cp else [
                'block_median_of_invocation_medians_percent', 'block_mean_of_invocation_means_percent',
                'pooled_sample_median_percent', 'pooled_sample_mean_percent']
            for field, value in zip(fields, changes):
                close(value, block['change_percent'][field])
            blocks.append(dict(block=block_name, process_median_percent=changes[0],
                process_mean_percent=changes[1], pooled_median_percent=changes[2],
                pooled_mean_percent=changes[3], absolute_stats_ns=stats))
            if control and changes[0] >= 3 and changes[1] >= 3:
                any_blocks.append((name, block_name))
        repeated = all(row['process_median_percent'] >= 3 and row['process_mean_percent'] >= 3 for row in blocks)
        if repeated:
            repeated_all.append(name)
            if control:
                vetoes.append(name)
        if not aa and not cp and not control and any(row['process_median_percent'] >= 0 for row in blocks):
            targets_failed.append(name)
        results.append(dict(case=name, control=control, blocks=blocks))
    reported_veto = 'vetoed_cases_both_blocks' if cp else 'controls_vetoed_in_both_blocks'
    assert sorted(vetoes) == analysis[reported_veto]
    assert set(any_blocks) == {(row['case'], row['block']) for row in analysis['vetoed_control_blocks']}
    if cp:
        assert sorted({name for name, _ in any_blocks}) == analysis['vetoed_cases_any_block']
    else:
        assert sorted(targets_failed) == analysis['targets_not_improved_both_blocks']
    return dict(comparisons=results, vetoed_controls_both_blocks=sorted(vetoes),
        targets_not_improved_both_blocks=sorted(targets_failed),
        repeated_slowdowns_all_cases=sorted(repeated_all),
        gate_pass=not vetoes and not targets_failed)


def ordinary(root, cases, records, runtime_records, targets, aa=False, corpus_dir=CORPUS):
    root, corpus_dir = root.resolve(), corpus_dir.resolve()
    count = len(cases) * 16
    analysis, plan = load(root / 'analysis.json'), load(root / 'plan.json')
    assert analysis['status'] == 'complete'
    assert plan['samples'] == 21 and plan['warmups'] == 10
    assert plan['cases'] == [row['file'] for row in cases]
    assert {row['block']: row['order'] for row in plan['schedules']} == SCHEDULES
    assert plan['corpus_sha256'] == file_hash(corpus_dir / 'manifest.json')
    policy = plan['resource_policy']
    assert policy['memory_bytes'] == MEMORY and policy['swap_bytes'] == 0 and policy['affinity'] == [0]
    assert int(policy['module_cache_entries']) == 1 and int(policy['module_cache_bytes']) == IMAGE_LIMIT
    assert plan['cache']['limit_bytes'] == 1073741824
    assert file_hash(plan['process_accounting']['supervisor']) == plan['process_accounting']['supervisor_sha256']
    runner = BASE / ('aa-runner.py' if aa else 'run.py')
    assert file_hash(runner) == plan['runner_sha256']
    published_rows = {row['raw']: row for row in analysis['rows']}
    assert len(published_rows) == len(analysis['rows']) == count
    groups, expected_stems = collections.defaultdict(list), set()
    diagnostics = collections.defaultdict(collections.Counter)
    retention_images = collections.defaultdict(set)
    for index, case in enumerate(cases):
        name = case['file']
        for block, schedule in SCHEDULES.items():
            for ordinal, original_label in enumerate(schedule):
                label = 'baseline-aa' if aa and original_label == 'candidate' else original_label
                stem = f'{block}-case{index:02}-{ordinal}-{label}-{name}'
                expected_stems.add(stem)
                row = published_rows[stem]
                assert (row['case'], row['block'], row['round'], row['product']) == (name, block, ordinal, label)
                report = load(root / 'raw' / (stem + '.stdout'))
                command = load(root / 'raw' / (stem + '.command.json'))
                resource_check(command)
                argv = command['argv']
                assert len(argv) == 6 and Path(argv[0]).resolve() == BASE / label / 'runtime_baseline'
                assert Path(argv[1]).resolve() == corpus_dir and argv[2:5] == ['21', '10', name]
                verify_identity(report, label, records, 'runtime_baseline')
                planned = plan['product_identities'][label]
                for key in ['source_commit', 'source_fingerprint']:
                    assert planned[key] == report[key]
                assert planned['executed_host_sha256'] == report['executable_sha256']
                assert report['schema'] == 'scriptw-wasmtime-baseline-v2'
                assert report['requested_native_policy'] is None and report['samples'] == 21 and report['warmups'] == 10
                assert len(report['cases']) == 1
                actual = report['cases'][0]
                assert actual['file'] == name and actual['source_compilation_profile'] == 'portable'
                assert actual['source_sha256'] == file_hash(corpus_dir / name)
                runtime = runtime_records[label]['-portable']
                assert actual['linked_runtime']['wasm_sha256'] == runtime['wasm_sha256']
                assert actual['linked_runtime']['wasm_bytes'] == runtime['wasm_bytes']
                assert actual['linked_runtime']['key'] == runtime['runtime_key']
                artifact = Path(argv[5]) / (name + '.wasm')
                assert artifact.resolve() == root / 'artifacts' / stem / (name + '.wasm')
                data = artifact.read_bytes()
                assert len(data) == actual['wasm_bytes'] and digest(data) == actual['wasm_sha256']
                functions, code_bytes, largest, code = wasm_code(data)
                assert (functions, code_bytes, largest) == tuple(actual['footprint'][key] for key in
                    ['defined_functions', 'code_body_bytes', 'largest_code_body_bytes'])
                identity = (actual['source_sha256'], actual['wasm_sha256'], len(data), code_bytes, largest, digest(code))
                P_IDENTITIES[(name, label)].add(identity)
                P_CODE[(name, label)] = code
                for number, observation in enumerate(actual['observations']):
                    diagnostics[label + ':P_cache'][observation['module_cache']] += 1
                    if label in records:
                        loading, retention = observation['module_loading'], observation['module_retention']
                        for field in ['runtime_ns', 'program_ns']:
                            assert type(loading[field]) is int and loading[field] >= 0
                        embedded = loading['embedded_image_ns']
                        if embedded is not None:
                            assert set(embedded) == {'admission', 'native_backing_preparation',
                                'native_lease_decode_and_digest', 'deserialize'}
                            assert all(type(value) is int and value >= 0 for value in embedded.values())
                        assert loading['runtime_cache'] in ['Hit', 'Miss', 'Bypassed']
                        assert retention['entry_limit'] == 1 and retention['image_byte_limit'] == IMAGE_LIMIT
                        assert type(retention['entries']) is int and 0 <= retention['entries'] <= 1
                        assert type(retention['image_bytes']) is int and 0 <= retention['image_bytes'] <= IMAGE_LIMIT
                        assert (retention['entries'] == 0) == (retention['image_bytes'] == 0)
                        diagnostics[label + ':R_cache'][loading['runtime_cache']] += 1
                        if number >= 10:
                            diagnostics[label + ':measured_R_cache'][loading['runtime_cache']] += 1
                        retention_images[label].add((retention['entries'], retention['image_bytes']))
                stats = observations(actual, case['stdout'])
                assert stats['times'] == row['times_ns']
                close(stats['median'], row['invocation_median_ns'])
                close(stats['mean'], row['invocation_mean_ns'])
                assert row['process_elapsed_ns'] == command['elapsed_ns']
                stats.update(raw=stem, process_elapsed_ns=command['elapsed_ns'])
                groups[(name, block, label)].append(stats)
    assert {path.name.removesuffix('.stdout') for path in (root / 'raw').glob('*.stdout')} == expected_stems
    assert set(published_rows) == expected_stems
    post = load(root / 'post-product-hash.json')
    assert post['status'] == 'verified'
    labels = ['baseline', 'baseline-aa'] if aa else ['baseline', 'candidate']
    expected = {f'{label}/{name}': row['sha256'] for label in labels
                for name, row in records[label]['hosts'].items()}
    assert post['hashes'] == expected
    assert analysis['frozen_product_hash_check']['hashes'] == expected
    assert analysis['frozen_product_hash_check']['preflight'] == 'verified'
    assert analysis['frozen_product_hash_check']['post_run'] == 'verified'
    assert analysis['frozen_product_hash_check']['runner_sha256'] == plan['runner_sha256']
    result = compare(analysis, groups, cases, aa, False, targets)
    result.update(path=str(root), raw_invocations=count, measured_observations=count * 21, warmups=count * 10,
        actual_P_artifacts_hashed=count, diagnostic_counts=dict(diagnostics),
        retention_image_observations={key: sorted(value) for key, value in retention_images.items()},
        hash_audit='Frozen preflight identities, child-reported hosts and complete post-product hashes independently checked',
        analysis_sha256=file_hash(root / 'analysis.json'), plan_sha256=file_hash(root / 'plan.json'))
    return result


def cp_configuration(config):
    assert config['native_compilation_mode'] == 'size-optimized'
    assert config['register_allocation'] == 'backtracking'
    assert config['consumer_compiler_enabled'] is False
    assert config['gc_initial_bytes'] == 16777216 and config['wasmtime_version'] == '47.0.0'
    assert config['collector'] == 'copying'
    assert config['max_wasm_stack_bytes'] == 33554432 and config['worker_stack_bytes'] == 67108864
    assert config['runtime_policy'] == 'scriptw-required-wasmtime-experimental-v1'


def cp_control(root, cases, records, runtime_records, targets):
    root = root.resolve()
    lane = BASE / 'cp-control'
    plan, analysis = load(root / 'plan.json'), load(root / 'analysis.json')
    assert analysis['status'] == 'complete' and plan['samples'] == 21 and plan['warmups'] == 10
    assert plan['cases'] == [row['file'] for row in cases]
    assert {row['block']: row['order'] for row in plan['schedules']} == SCHEDULES
    policy = plan['resource_policy']
    assert policy['memory_bytes'] == MEMORY and policy['swap_bytes'] == 0 and policy['affinity'] == [0]
    assert policy['module_cache_entries'] == 1 and policy['module_cache_bytes'] == IMAGE_LIMIT
    assert plan['prepared_sha256'] == file_hash(lane / 'prepared.json') == analysis['prepared_sha256']
    prepared = load(lane / 'prepared.json')
    assert prepared['status'] == 'complete' and prepared['manifest_sha256'] == file_hash(CORPUS / 'manifest.json')
    groups, stems, images, receipts = collections.defaultdict(list), set(), {}, {}
    producers = {}
    for label in ['baseline', 'candidate']:
        path = lane / 'prepared' / label / 'producer-receipt.json'
        receipt = load(path)
        producers[label] = receipt
        receipts[label] = file_hash(path)
        assert receipts[label] == plan['producer_receipt_hashes'][label]
        assert receipts[label] == prepared['products'][label]['producer_receipt_sha256']
        verify_identity(receipt['producer'], label, records, 'compiler_precompiled_baseline')
        verify_identity(plan['product_identities'][label], label, records, 'compiler_precompiled_baseline')
        verify_identity(analysis['product_identities'][label], label, records, 'compiler_precompiled_baseline')
        resource_check(receipt['producer_command'])
        cp_configuration(receipt['producer_configuration'])
        assert receipt['producer_configuration'] == records[label]['identity']['shared_configuration']
        assert receipt['producer_configuration_sha256'] == digest(json.dumps(
            receipt['producer_configuration'], sort_keys=True, separators=(',', ':')).encode())
        assert receipt['producer']['compiler_enabled'] is True
        assert receipt['producer']['manifest_sha256'] == file_hash(CORPUS / 'manifest.json')
        producer_raw = lane / 'prepare-run/raw' / f'prepare-{label}'
        assert file_hash(str(producer_raw) + '.stdout') == receipt['producer_stdout_sha256']
        assert file_hash(str(producer_raw) + '.stderr') == receipt['producer_stderr_sha256']
        assert load(str(producer_raw) + '.stdout') == receipt['producer']
        assert load(str(producer_raw) + '.command.json') == receipt['producer_command']
        argv = receipt['producer_command']['argv']
        assert len(argv) == 4 and Path(argv[0]).resolve() == BASE / label / 'compiler_precompiled_baseline'
        assert argv[1] == 'prepare-scriptw' and Path(argv[2]).resolve() == CORPUS
        assert Path(argv[3]).resolve() == lane / 'prepared' / label
        produced_cases = {row['file']: row for row in receipt['producer']['cases']}
        assert set(produced_cases) == {row['file'] for row in cases}
        for case in cases:
            assert receipt['source_hashes'][case['file']] == file_hash(CORPUS / case['file'])
            assert produced_cases[case['file']]['stdout'] == case['stdout']
        for name, image in receipt['image_files'].items():
            path = lane / 'prepared' / label / image['path']
            assert path.is_file() and not path.is_symlink() and path.stat().st_nlink == 1
            assert path.stat().st_size == image['bytes'] and file_hash(path) == image['sha256']
            assert image['runtime_key'] == runtime_records[label]['-portable']['runtime_key']
            assert produced_cases[name]['image_sha256'] == image['sha256']
            assert produced_cases[name]['program_wasm_sha256'] == image['program_wasm_sha256']
            images[f'{label}/{name}'] = image['sha256']
    assert images == plan['prepared_image_hashes']
    for index, case in enumerate(cases):
        name = case['file']
        for block, schedule in SCHEDULES.items():
            for ordinal, label in enumerate(schedule):
                stem = f'{block}-case{index:02}-{ordinal}-{label}-{name}'
                stems.add(stem)
                report = load(root / 'raw' / (stem + '.stdout'))
                command = load(root / 'raw' / (stem + '.command.json'))
                resource_check(command)
                verify_identity(report, label, records, 'compiler_precompiled_baseline')
                receipt = producers[label]
                image = receipt['image_files'][name]
                argv = command['argv']
                assert len(argv) == 6 and Path(argv[0]).resolve() == BASE / label / 'compiler_precompiled_baseline'
                assert argv[1] == 'execute-scriptw' and argv[3:] == [case['stdout'], '21', '10']
                assert Path(argv[2]).resolve() == lane / 'prepared' / label / image['path']
                assert report['schema'] == 'scriptw-precompiled-execution-v1'
                assert report['samples'] == 21 and report['warmups'] == 10
                assert report['adapter'] == 'scriptw' and report['compiler_enabled'] is False
                assert report['comparison_cohort'] == 'scriptw-precompiled-comparison-v1'
                assert report['excluded_from_ordinary_cohorts'] is True
                assert report['shared_configuration'] == receipt['producer_configuration']
                for field in ['runtime_key', 'program_wasm_sha256', 'execution_facts_sha256']:
                    assert report[field] == image[field]
                assert report['image_sha256'] == image['sha256']
                assert all(row['matched'] is True for row in report['observations'])
                assert all(row['completion'] == 'normal' and row['stderr'] == '' for row in report['observations'])
                assert [row['index'] for row in report['observations']] == list(range(31))
                stats = observations(report, case['stdout'], cp=True)
                stats.update(raw=stem, process_elapsed_ns=command['elapsed_ns'])
                groups[(name, block, label)].append(stats)
    assert {path.name.removesuffix('.stdout') for path in (root / 'raw').glob('*.stdout')} == stems
    post = load(root / 'post-input-hashes.json')
    assert post['status'] == 'verified' and post['prepared_images'] == images
    assert post['producer_receipts'] == receipts and post['prepared_manifest_sha256'] == plan['prepared_sha256']
    assert post['host_products'] == {f'{label}/{name}': row['sha256'] for label in ['baseline', 'candidate']
                                   for name, row in records[label]['hosts'].items()}
    result = compare(analysis, groups, cases, False, True, targets)
    result.update(path=str(root), raw_invocations=272, measured_observations=5712, warmups=2720,
        compiler_preparations=2, prepared_image_files_hashed=len(images),
        timing_field='observations[].phases_ns.execution',
        runner_sha256=file_hash(lane / 'cp_control.py'),
        fresh_preparation=True,
        scope='Separate hot-R precompiled consumer veto lane; no independent promotion claim',
        analysis_sha256=file_hash(root / 'analysis.json'), plan_sha256=file_hash(root / 'plan.json'))
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--ordinary', required=True, type=Path)
    parser.add_argument('--aa', type=Path)
    parser.add_argument('--cp', required=True, type=Path)
    parser.add_argument('--namespace', required=True, type=Path)
    parser.add_argument('--candidate-fingerprint', required=True)
    parser.add_argument('--corrected-tests-receipt', type=Path,
        default=BASE / 'encoded-test-correction/corrected-receipt.json')
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    assert len(args.candidate_fingerprint) == 64 and all(c in '0123456789abcdef' for c in args.candidate_fingerprint)
    assert not args.output.exists(), 'preserve prior audit output'
    record, cases = corpus()
    study = load(BASE / 'study-plan.json')
    assert study['baseline_commit'] == BASELINE_ACCEPTED_COMMIT
    assert study['baseline_source_fingerprint'] == BASELINE_FP
    assert study['runtime']['previous_abi'] == 42 and study['runtime']['candidate_abi'] == 43
    targets = PRIMARY_TARGETS
    assert len(targets) == 9 and len(set(row['file'] for row in cases) - targets) == 8
    inputs = load(BASE / 'independent-audit-inputs.json')
    for name, expected in inputs['files_sha256'].items():
        assert file_hash(BASE / name) == expected, f'pre-measurement audit input changed: {name}'
    records = products()
    if args.candidate_fingerprint:
        assert records['candidate']['identity']['source_fingerprint'] == args.candidate_fingerprint
    runtime_records = runtimes(records)
    correction = encoded_test_correction(records, args.corrected_tests_receipt)
    temporal_correction = temporal_test_correction(records, correction)
    namespace_record, namespace_cases, namespace_targets = namespace_corpus()
    aa = args.aa or (BASE / load(BASE / 'aa-analysis.json')['analysis']).parent
    cohorts = dict(aa=ordinary(aa, cases, records, runtime_records, targets, aa=True),
        ordinary=ordinary(args.ordinary, cases, records, runtime_records, targets))
    cohorts['cp_control'] = cp_control(args.cp, cases, records, runtime_records, targets)
    cohorts['namespace_controls'] = ordinary(args.namespace, namespace_cases, records, runtime_records,
        namespace_targets, corpus_dir=BASE / 'namespace-controls')
    assert all(len(value) == 1 for value in P_IDENTITIES.values())
    footprints = []
    for case in cases:
        name = case['file']
        identities = {label: next(iter(P_IDENTITIES[(name, label)]))
                      for label in ['baseline', 'baseline-aa', 'candidate']}
        assert identities['baseline'] == identities['baseline-aa'], 'A/A P copies differ'
        footprints.append(dict(case=name, identities=identities,
            P_bytes_equal=identities['baseline'][1] == identities['candidate'][1],
            exact_code_section_equal=P_CODE[(name, 'baseline')] == P_CODE[(name, 'candidate')]))
    assert sum(value['raw_invocations'] for value in cohorts.values()) == 960
    report = dict(status='audited', audit_script_sha256=file_hash(__file__),
        corpus_sha256=record['manifest_sha256'], products=records, runtimes=runtime_records,
        pre_measurement_audit_inputs=inputs,
        baseline_accepted_commit=BASELINE_ACCEPTED_COMMIT,
        excluded_test_source_correction=correction, temporal_test_source_correction=temporal_correction,
        namespace_corpus=namespace_record,
        cohorts=cohorts, P_footprint_fields=['source_sha256', 'wasm_sha256', 'wasm_bytes',
            'code_body_bytes', 'largest_body_bytes', 'code_section_sha256'], P_footprints=footprints,
        namespace_P_footprints=namespace_footprints(namespace_cases),
        total_raw_invocations=sum(value['raw_invocations'] for value in cohorts.values()),
        measured_observations=sum(value['measured_observations'] for value in cohorts.values()),
        warmup_observations=sum(value['warmups'] for value in cohorts.values()),
        maximum_recomputed_statistic_discrepancy=MAX_DISCREPANCY, peak_child_rss_bytes=MAX_RSS,
        hashed_files={str(path): value for path, value in HASHED.items()},
        limitations=[
            'Existing artifacts only; no measurements, tests, conformance or reference replay.',
            'Three original encoded-test failures and one intermediate scalar witness failure are preserved. Three final capped exact passes qualify; the uncapped Intl diagnostic is excluded. Passing scopes are retained with disjoint inventories, not represented as rerun.',
            'All four cohorts have separate boundaries and gates; CP preparation is outside consumer execution timing.',
            'A/A binds its exact aa-runner.py snapshot; candidate and namespace cohorts bind current run.py. Later runner edits changed metadata wording only.',
            'ABI42 becomes ABI43; all seventeen P packages and both R profiles may change. P and code-section equality are descriptive, not required.',
            'Namespace runner inherits an eight-control prose label; its explicit nine-case manifest and three-target/six-control study plan govern this independent calculation.',
            'Runtime cache outcomes and retained-image accounting are not page-fault or GC attribution.',
            'CP native images are byte-hashed; their P Wasm/execution-fact identities are checked against the bound producer receipt, not re-extracted from native code.',
            'Scored units are independent processes; pooled samples remain descriptive.',
        ])
    with args.output.open('x') as stream:
        json.dump(report, stream, indent=2)
        stream.write('\n')
    print(json.dumps(dict(output=str(args.output), raw_invocations=report['total_raw_invocations'],
        gates={key: value['gate_pass'] for key, value in cohorts.items()},
        maximum_statistic_discrepancy=MAX_DISCREPANCY), indent=2))


if __name__ == '__main__':
    main()
