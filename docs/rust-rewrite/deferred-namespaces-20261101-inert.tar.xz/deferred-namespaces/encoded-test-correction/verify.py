from pathlib import Path
import json,subprocess,sys,time
root=Path.cwd();out=root/'target/performance-deferred-namespaces';folder=out/'encoded-test-correction';sys.path.insert(0,str(root/'scripts'))
from benchmark_metrics import digest
from native_test_protocol import parse_inventory,result_summaries
rows=[json.loads(s) for s in (folder/'build.jsonl').read_text().splitlines()];assert rows[-1]=={'reason':'build-finished','success':True}
p=next(r for r in rows if r.get('reason')=='compiler-artifact' and r.get('executable') and r['target']['name']=='scriptw_aot_wasm' and r['profile']['test']);exe=Path(p['executable']);sha=digest(exe);inventory=parse_inventory(subprocess.check_output([exe,'--list'],text=True));records=[]
for name in ['tests::scalar_regions::dormant_math_imul_recipe_admits_the_literal_whole_trip_without_resolving_math','tests::intl_demand_initialization::canonical_runtime_defers_the_complete_intl_graph_and_preserves_its_typed_abi']:
 assert name in inventory;stem=name.rsplit('::',1)[-1];argv=[str(exe),'--exact',name,'--test-threads=1','--nocapture'];start=time.monotonic()
 with (folder/(stem+'.stdout')).open('wb') as stdout,(folder/(stem+'.stderr')).open('wb') as stderr:r=subprocess.run(argv,stdout=stdout,stderr=stderr,timeout=600)
 summaries=result_summaries((folder/(stem+'.stdout')).read_text());record=dict(target='scriptw_aot_wasm',stdout=str(folder/(stem+'.stdout')),stderr=str(folder/(stem+'.stderr')),selected_inventory=[name],executable=str(exe),executable_sha256=sha,producer=p,argv=argv,exit_code=r.returncode,summaries=summaries,elapsed_seconds=time.monotonic()-start);records.append(record);(folder/'corrected-receipt.json').write_text(json.dumps(records,indent=2)+'\n');print(stem,r.returncode,summaries,flush=True)
 assert r.returncode==0 and summaries==[('ok','1','0','0','0',str(len(inventory)-1))]
subprocess.run(['cp','--reflink=auto',str(exe),str(folder/'corrected-backend-tests')],check=True);assert digest(folder/'corrected-backend-tests')==sha
inputs=json.loads((out/'pre-build-sources.json').read_text());changed=[n for n,h in inputs.items() if digest(root/n)!=h];assert set(changed)=={'crates/scriptw-aot-wasm/src/tests/intl_demand_initialization.rs','crates/scriptw-aot-wasm/src/tests/scalar_regions.rs'}
for name,row in json.loads((out/'candidate/products.json').read_text()).items():assert digest(out/'candidate'/name)==row['sha256']
(folder/'production-reuse.json').write_text(json.dumps(dict(status='production inputs and all4 frozen products unchanged',changed_source_paths=changed,excluded_by='compiler_fingerprint.rs TEST_ONLY_INPUTS crates/scriptw-aot-wasm/src/tests',source_fingerprint=json.loads((out/'candidate/identity.json').read_text())['source_fingerprint']),indent=2)+'\n')
