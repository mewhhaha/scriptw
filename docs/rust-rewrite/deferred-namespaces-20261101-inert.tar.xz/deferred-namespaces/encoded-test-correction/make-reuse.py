from pathlib import Path
import json,re,hashlib
out=Path.cwd()/'target/performance-deferred-namespaces';d=out/'encoded-test-correction';old=json.loads((out/'native-focused/receipt.json').read_text());fixed=json.loads((d/'corrected-receipt.json').read_text());assert len(fixed)==2 and all(r['exit_code']==0 and r['summaries'][0][1:4]==['1','0','0'] for r in fixed)
scopes=[];original_sha=hashlib.sha256((d/'original-backend-tests').read_bytes()).hexdigest()
for r in old:
 if r['target']!='scriptw_aot_wasm':continue
 assert r['executable_sha256']==original_sha
 if r['exit_code']==0:passed=r['selected_inventory']
 else:
  stem=r['target']+'-'+r['selection'].replace('::','_').strip('_');stdout=out/'native-focused'/(stem+'.stdout');passed=re.findall(r'^test (\S+) \.\.\. ok$',stdout.read_text(),re.M)
 for name in passed:
  scopes.append(dict(selection=name,selected_inventory=[name],executable_sha256=original_sha,origin='original actual passed test; original aggregate failures retained separately'))
assert len(scopes)==9
for r in fixed:
 assert len(r['selected_inventory'])==1
 scopes.append(dict(selection=r['selected_inventory'][0],selected_inventory=r['selected_inventory'],executable_sha256=r['executable_sha256'],origin='corrected exact test under limited_verification'))
assert len(scopes)==len({r['selection'] for r in scopes})==11
p=dict(corrected_binary_sha256=fixed[0]['executable_sha256'],scopes=scopes,production_reuse=json.loads((d/'production-reuse.json').read_text()));(d/'reused-passes.json').write_text(json.dumps(p,indent=2)+'\n');print('preserved9 unchanged backend passes plus2 corrected exact passes')
