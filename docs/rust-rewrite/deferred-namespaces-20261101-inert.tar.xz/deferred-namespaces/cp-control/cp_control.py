"""Source-bound precompiled hot-R control lane; intentionally run only on approval."""
from pathlib import Path
import argparse
import datetime
import hashlib
import json
import os
import statistics
import subprocess
import sys

OUT = Path(__file__).resolve().parent
COHORT = OUT.parent
ROOT = COHORT.parents[1]
CORPUS = ROOT / "crates/scriptw-cli/tests/fixtures/v8_execution_hotpaths"
SAMPLES, WARMUPS = 21, 10
SCHEDULES = [
    ("block0", ["baseline", "candidate", "candidate", "baseline",
        "candidate", "baseline", "baseline", "candidate"]),
    ("block1", ["candidate", "baseline", "baseline", "candidate",
        "baseline", "candidate", "candidate", "baseline"]),
]
POLICY_FIELDS = ["memory.max", "memory.swap.max", "memory.oom.group", "cpu.max", "memory.events"]
sys.path.insert(0, str(ROOT / "scripts"))
from benchmark_metrics import digest, measure_process
from limited_verification import kernel_group, require_kernel_budget


def load(path):
    return json.loads(Path(path).read_text())


def save_new(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")


def canonical_hash(value):
    data = json.dumps(value, sort_keys=True, separators=(",", ":")).encode()
    return hashlib.sha256(data).hexdigest()


def manifest():
    recorded = load(COHORT / "corpus.json")
    assert digest(CORPUS / "manifest.json") == recorded["manifest_sha256"]
    for name, expected in recorded["files_sha256"].items():
        assert digest(CORPUS / name) == expected, f"canonical fixture changed: {name}"
    return recorded["manifest"]["execution"]


def product_identity(label):
    folder = COHORT / label
    products = load(folder / "host-products.json")
    identity = load(folder / "identity.json")
    for name, row in products.items():
        path = folder / name
        assert path.is_file() and not path.is_symlink() and path.stat().st_nlink == 1
        assert digest(path) == row["sha256"], f"frozen host changed: {path}"
    host = folder / "compiler_precompiled_baseline"
    assert identity["executable_sha256"] == digest(host)
    assert identity["source_fingerprint"]
    return dict(source_commit=identity["source_commit"],
        source_fingerprint=identity["source_fingerprint"],
        executable_sha256=digest(host), identity=identity,
        host_products=products)


def verify_products_unchanged(identities):
    checked = {}
    for label, identity in identities.items():
        folder = COHORT / label
        for name, row in identity["host_products"].items():
            path = folder / name
            assert path.is_file() and not path.is_symlink() and path.stat().st_nlink == 1
            actual = digest(path)
            assert actual == row["sha256"], f"frozen host changed during lane: {path}"
            checked[f"{label}/{name}"] = actual
    return checked


def verify_prepared_images():
    checked = {}
    for label in ("baseline", "candidate"):
        receipt = load(OUT / "prepared" / label / "producer-receipt.json")
        for name, record in receipt["image_files"].items():
            path = OUT / "prepared" / label / record["path"]
            assert path.is_file() and not path.is_symlink() and path.stat().st_nlink == 1
            actual = digest(path)
            assert actual == record["sha256"], f"prepared image changed: {path}"
            checked[f"{label}/{name}"] = actual
    return checked


def validate_configuration(config):
    assert config["native_compilation_mode"] == "size-optimized"
    assert config["register_allocation"] == "backtracking"
    assert config["consumer_compiler_enabled"] is False
    assert config["gc_initial_bytes"] == 16 * 1024 * 1024
    assert config["wasmtime_version"] == "47.0.0"


def resource_snapshot():
    group = kernel_group()
    return {name: (group / name).read_text() for name in POLICY_FIELDS}


def run_process(run_dir, stem, argv, env):
    require_kernel_budget(4 * 1024 * 1024 * 1024)
    assert len(os.sched_getaffinity(0)) == 1, "run under the one-CPU limited-verification policy"
    raw = run_dir / "raw"
    raw.mkdir(parents=True, exist_ok=True)
    before = resource_snapshot()
    with (raw / f"{stem}.stdout").open("xb") as stdout, (raw / f"{stem}.stderr").open("xb") as stderr:
        result = measure_process(list(map(str, argv)), cwd=ROOT, env=env,
            stdout=stdout, stderr=stderr, timeout=900,
            time_binary=COHORT / "tools/time")
    after = resource_snapshot()
    result.update(argv=list(map(str, argv)), affinity=sorted(os.sched_getaffinity(0)),
        resources_before=before, resources_after=after)
    save_new(raw / f"{stem}.command.json", result)
    assert all(before[name] == after[name] for name in POLICY_FIELDS if name != "memory.events")
    old = dict(line.split() for line in before["memory.events"].splitlines())
    new = dict(line.split() for line in after["memory.events"].splitlines())
    assert all(old[key] == new[key] for key in ("oom", "oom_kill", "oom_group_kill"))
    assert result["exit_code"] == 0 and not result["timed_out"], f"failed process: {stem}"
    return result


def common_env():
    env = dict(os.environ)
    if env.get("NODE_OPTIONS"):
        raise ValueError("NODE_OPTIONS must be unset")
    env.pop("NODE_COMPILE_CACHE", None)
    env["NODE_DISABLE_COMPILE_CACHE"] = "1"
    env["SCRIPTW_CACHE_DIR"] = str(COHORT / "cache")
    env["SCRIPTW_CACHE_LIMIT_BYTES"] = str(1024 ** 3)
    env["SCRIPTW_MODULE_MEMORY_CACHE_ENTRIES"] = "1"
    env["SCRIPTW_MODULE_MEMORY_CACHE_LIMIT_BYTES"] = str(64 * 1024 * 1024)
    (COHORT / "cache").mkdir(exist_ok=True)
    return env


def prepare():
    cases = manifest()
    env = common_env()
    receipts = {}
    for label in ("baseline", "candidate"):
        identity = product_identity(label)
        host = COHORT / label / "compiler_precompiled_baseline"
        output = OUT / "prepared" / label
        output.parent.mkdir(parents=True, exist_ok=True)
        assert not output.exists(), "producer owns creation of the new output directory"
        stem = f"prepare-{label}"
        event = run_process(OUT / "prepare-run", stem,
            [host, "prepare-scriptw", CORPUS, output], env)
        report = load(OUT / "prepare-run/raw" / f"{stem}.stdout")
        assert report["source_fingerprint"] == identity["source_fingerprint"]
        assert report["source_commit"] == identity["source_commit"]
        assert report["executable_sha256"] == identity["executable_sha256"]
        assert report["compiler_enabled"] is True
        assert report["manifest_sha256"] == digest(CORPUS / "manifest.json")
        assert report["adapter"] == "scriptw"
        assert report["comparison_cohort"] == "scriptw-precompiled-comparison-v1"
        assert report["excluded_from_ordinary_cohorts"] is True
        validate_configuration(report["shared_configuration"])
        rows = {row["file"]: row for row in report["cases"]}
        assert list(rows) == [case["file"] for case in cases]
        for case in cases:
            row = rows[case["file"]]
            assert row["source_sha256"] == digest(CORPUS / case["file"])
            image = output / row["image"]
            assert image.is_file() and not image.is_symlink() and image.stat().st_nlink == 1
            assert digest(image) == row["image_sha256"]
            assert row["stdout"] == case["stdout"]
            image.chmod(0o444)
        record = dict(status="prepared", product=label, product_identity=identity,
            producer_executable_sha256=identity["executable_sha256"],
            source_hashes={row["file"]: row["source_sha256"] for row in report["cases"]},
            producer_configuration=report["shared_configuration"],
            producer_configuration_sha256=canonical_hash(report["shared_configuration"]),
            producer_stdout_sha256=digest(OUT / "prepare-run/raw" / f"{stem}.stdout"),
            producer_stderr_sha256=digest(OUT / "prepare-run/raw" / f"{stem}.stderr"),
            producer=report, producer_command=event,
            image_files={row["file"]: dict(path=row["image"], sha256=row["image_sha256"],
                bytes=row["image_bytes"], program_wasm_sha256=row["program_wasm_sha256"],
                program_wasm_bytes=row["program_wasm_bytes"], runtime_key=row["runtime_key"],
                execution_facts_sha256=row["execution_facts_sha256"],
                execution_facts_bytes=row["execution_facts_bytes"],
                native_serialized_bytes=row["native_serialized_bytes"])
                for row in report["cases"]})
        save_new(output / "producer-receipt.json", record)
        receipts[label] = dict(source_fingerprint=identity["source_fingerprint"],
            executable_sha256=identity["executable_sha256"],
            producer_receipt_sha256=digest(output / "producer-receipt.json"),
            image_count=len(rows))
    save_new(OUT / "prepared.json", dict(status="complete", manifest_sha256=digest(CORPUS / "manifest.json"),
        products=receipts, configuration=load((OUT / "study-plan.json"))["configuration"]))
    print(OUT / "prepared.json")


def run(resume=None):
    cases = manifest()
    prepared = load(OUT / "prepared.json")
    assert prepared["status"] == "complete"
    prepared_sha256 = digest(OUT / "prepared.json")
    identities = {label: product_identity(label) for label in ("baseline", "candidate")}
    image_hashes = verify_prepared_images()
    producer_receipt_hashes = {}
    for label in identities:
        receipt_path = OUT / "prepared" / label / "producer-receipt.json"
        receipt = load(receipt_path)
        receipt_hash = digest(receipt_path)
        assert prepared["products"][label]["producer_receipt_sha256"] == receipt_hash
        producer_receipt_hashes[label] = receipt_hash
        assert receipt["product_identity"]["source_fingerprint"] == identities[label]["source_fingerprint"]
        assert receipt["product_identity"]["executable_sha256"] == identities[label]["executable_sha256"]
    run_id = datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%dT%H%M%SZ") + "-cp-hot-r"
    run_dir = OUT / "runs" / run_id
    if resume is not None:
        run_dir = resume.resolve()
        assert run_dir.parent == (OUT / "runs").resolve() and run_dir.is_dir()
        run_id = run_dir.name
    else:
        run_dir.mkdir(parents=True, exist_ok=False)
    plan = dict(status="running", run_id=run_id, cases=[case["file"] for case in cases],
        samples=SAMPLES, warmups=WARMUPS, schedules=[dict(block=b, order=o) for b,o in SCHEDULES],
        product_identities=identities, prepared_sha256=prepared_sha256,
        producer_receipt_hashes=producer_receipt_hashes, prepared_image_hashes=image_hashes,
        configuration=load(OUT / "study-plan.json")["configuration"],
        resource_policy=dict(memory_bytes=4 * 1024 ** 3, swap_bytes=0,
            affinity=sorted(os.sched_getaffinity(0)), cgroup=str(kernel_group()),
            module_cache_entries=1, module_cache_bytes=64 * 1024 * 1024),
        accounting=dict(experimental_unit="fresh consumer process; 4 invocations per product/case/block",
            timing="consumer execution observations only; prepare/compiler artifacts excluded",
            retained_owner="each consumer process holds the precompiled P and R modules in the existing EmbeddedRuntime owner while creating fresh Store/Realm instances"))
    if resume is not None:
        original = load(run_dir / "plan.json")
        for key in ["cases", "samples", "warmups", "schedules", "product_identities", "prepared_sha256", "producer_receipt_hashes", "prepared_image_hashes", "configuration"]:
            assert original[key] == plan[key], f"resume input changed: {key}"
    else:
        save_new(run_dir / "plan.json", plan)
    env = common_env()
    rows = []
    for case_index, case in enumerate(cases):
        name = case["file"]
        for block, order in SCHEDULES:
            for round_index, label in enumerate(order):
                product = COHORT / label
                producer = load(OUT / "prepared" / label / "producer-receipt.json")
                image_record = producer["image_files"][name]
                image = OUT / "prepared" / label / image_record["path"]
                stem = f"{block}-case{case_index:02}-{round_index}-{label}-{name}"
                argv = [product / "compiler_precompiled_baseline", "execute-scriptw",
                    image, case["stdout"], str(SAMPLES), str(WARMUPS)]
                receipt_path = run_dir / "raw" / f"{stem}.command.json"
                if resume is not None and receipt_path.exists():
                    event = load(receipt_path)
                    assert event["argv"] == list(map(str, argv)) and event["exit_code"] == 0 and not event["timed_out"]
                    print("reused captured invocation", stem, flush=True)
                else:
                    event = run_process(run_dir, stem, argv, env)
                report = load(run_dir / "raw" / f"{stem}.stdout")
                identity = identities[label]
                assert report["source_fingerprint"] == identity["source_fingerprint"]
                assert report["source_commit"] == identity["source_commit"]
                assert report["executable_sha256"] == identity["executable_sha256"]
                assert report["compiler_enabled"] is False
                assert report["schema"] == "scriptw-precompiled-execution-v1"
                assert report["adapter"] == "scriptw"
                assert report["comparison_cohort"] == "scriptw-precompiled-comparison-v1"
                assert report["excluded_from_ordinary_cohorts"] is True
                expected_config = producer["producer_configuration"]
                validate_configuration(expected_config)
                assert report["shared_configuration"] == expected_config
                assert report["image_sha256"] == image_record["sha256"]
                assert report["program_wasm_sha256"] == image_record["program_wasm_sha256"]
                assert report["execution_facts_sha256"] == image_record["execution_facts_sha256"]
                assert report["runtime_key"] == image_record["runtime_key"]
                observations = report["observations"]
                assert len(observations) == SAMPLES + WARMUPS
                assert [item["warmup"] for item in observations] == [True] * WARMUPS + [False] * SAMPLES
                assert all(item["matched"] and item["stdout"] == case["stdout"] for item in observations)
                times = [item["phases_ns"]["execution"] for item in observations if not item["warmup"]]
                assert all(isinstance(value, int) and value > 0 for value in times)
                rows.append(dict(case=name, block=block, product=label, round=round_index,
                    times_ns=times, invocation_median_ns=statistics.median(times),
                    invocation_mean_ns=statistics.mean(times), raw=stem,
                    process_elapsed_ns=event["elapsed_ns"]))
    post_hosts = verify_products_unchanged(identities)
    post_images = verify_prepared_images()
    assert post_images == image_hashes
    assert digest(OUT / "prepared.json") == prepared_sha256
    post_receipts = {label: digest(OUT / "prepared" / label / "producer-receipt.json")
        for label in identities}
    assert post_receipts == producer_receipt_hashes
    save_new(run_dir / "post-input-hashes.json", dict(status="verified",
        host_products=post_hosts, prepared_images=post_images,
        producer_receipts=post_receipts, prepared_manifest_sha256=prepared_sha256))
    analysis = summarize(rows, cases, run_dir)
    analysis["product_identities"] = identities
    analysis["prepared_sha256"] = digest(OUT / "prepared.json")
    save_new(run_dir / "analysis.json", analysis)
    print(run_dir)


def summarize(rows, cases, run_dir):
    comparisons = []
    vetoes = []
    vetoed_cases_both_blocks = []
    for case in cases:
        name = case["file"]
        blocks = []
        vetoed_blocks_for_case = []
        for block, _ in SCHEDULES:
            stats = {}
            for label in ("baseline", "candidate"):
                selected = [row for row in rows if row["case"] == name and row["block"] == block and row["product"] == label]
                assert len(selected) == 4
                stats[label] = dict(
                    block_median_ns=statistics.median(row["invocation_median_ns"] for row in selected),
                    block_mean_ns=statistics.mean(row["invocation_mean_ns"] for row in selected),
                    invocations=[dict(raw=row["raw"], median_ns=row["invocation_median_ns"],
                        mean_ns=row["invocation_mean_ns"], process_elapsed_ns=row["process_elapsed_ns"])
                        for row in selected])
            change = dict(median_percent=100 * (stats["candidate"]["block_median_ns"] / stats["baseline"]["block_median_ns"] - 1),
                mean_percent=100 * (stats["candidate"]["block_mean_ns"] / stats["baseline"]["block_mean_ns"] - 1))
            if change["median_percent"] >= 3 and change["mean_percent"] >= 3:
                vetoes.append(dict(case=name, block=block, **change))
                vetoed_blocks_for_case.append(block)
            blocks.append(dict(block=block, products=stats, change_percent=change))
        if len(vetoed_blocks_for_case) == 2:
            vetoed_cases_both_blocks.append(name)
        comparisons.append(dict(case=name, blocks=blocks))
    return dict(status="complete", comparisons=comparisons,
        vetoed_control_blocks=vetoes,
        vetoed_cases_both_blocks=sorted(vetoed_cases_both_blocks),
        vetoed_cases_any_block=sorted({row["case"] for row in vetoes}),
        gate="veto promotion if any canonical case has >=3% slowdown in both median and mean in both blocks; neutral or faster results do not independently promote",
        experimental_unit="independent consumer process; block median of four invocation medians and mean of four invocation means",
        raw_directory=str((run_dir / "raw").relative_to(OUT)))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("action", choices=("verify-setup", "prepare", "run"))
    parser.add_argument("--resume-run", type=Path)
    args = parser.parse_args()
    require_kernel_budget(4 * 1024 * 1024 * 1024)
    if os.environ.get("NODE_OPTIONS"):
        parser.error("NODE_OPTIONS must be unset")
    cases = manifest()
    if args.action == "verify-setup":
        products = {label: product_identity(label) for label in ("baseline", "candidate")}
        assert (COHORT / "tools/time").is_file() and os.access(COHORT / "tools/time", os.X_OK)
        print(json.dumps(dict(status="ready", cases=len(cases), products={
            label: dict(source_fingerprint=value["source_fingerprint"],
                executable_sha256=value["executable_sha256"]) for label,value in products.items()},
            affinity=sorted(os.sched_getaffinity(0))), indent=2))
    elif args.action == "prepare":
        prepare()
    else:
        run(args.resume_run)


if __name__ == "__main__":
    main()
