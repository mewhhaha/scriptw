from pathlib import Path
import subprocess,json,time
root=Path.cwd();out=root/'target/performance-deferred-namespaces'
changes=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()
commands=[('rustfmt',['rustfmt','--edition','2021','--config','skip_children=true','--check',*[p for p in changes if p.endswith('.rs')]]),('guards',['python3','-B','scripts/check-source-guards.py']),('native-build',['cargo','test','--release','--locked','-p','scriptw-aot-wasm','-p','scriptw-engine','--lib','--test','structure_language','--test','structure_builtins','--test','intl_temporal','--test','emission','--test','aot_language','--test','aot_gc_entries','--no-run','--message-format=json','--timings']),('product-build',['cargo','build','--release','--locked','-p','scriptw-cli','--bin','scriptw','--example','runtime_baseline','--example','compiler_precompiled_baseline','--example','wasi_baseline','--message-format=json','--timings'])]
records=json.loads((out/'test-api-compile/build-receipt.json').read_text())[:2]
commands=commands[2:]
for label,argv in commands:
 start=time.monotonic();print(label,'started',flush=True)
 with (out/(label+'.stdout')).open('wb') as stdout,(out/(label+'.log')).open('wb') as stderr:
  result=subprocess.run(argv,cwd=root,stdout=stdout,stderr=stderr,timeout=3600)
 row=dict(label=label,argv=argv,exit_code=result.returncode,elapsed_seconds=time.monotonic()-start);records.append(row)
 (out/'build-receipt.json').write_text(json.dumps(records,indent=2)+'\n');print(row,flush=True)
 if result.returncode:raise SystemExit(result.returncode)
 if label=='native-build':(out/'native-build.jsonl').write_bytes((out/'native-build.stdout').read_bytes())
