var m = Math; print(m === Math && m.abs(-7) === 7 && m.PI > 3);
