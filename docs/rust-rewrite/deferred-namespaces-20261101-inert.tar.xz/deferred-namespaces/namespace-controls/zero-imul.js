(function(){var s=1;for(var i=0;i<0;i++){s=Math.imul(s,2);}print(s===1 && i===0);})();
