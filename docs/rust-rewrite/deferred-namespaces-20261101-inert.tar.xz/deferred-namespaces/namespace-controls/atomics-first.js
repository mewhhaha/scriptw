var a = Atomics; print(a === Atomics && a.isLockFree(1) === true);
