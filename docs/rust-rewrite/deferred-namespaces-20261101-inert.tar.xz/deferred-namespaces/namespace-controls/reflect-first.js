var r = Reflect; print(r === Reflect && r.ownKeys({x:1}).join(',') === 'x');
