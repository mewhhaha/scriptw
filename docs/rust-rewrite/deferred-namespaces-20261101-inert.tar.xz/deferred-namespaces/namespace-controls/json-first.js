var j = JSON; print(j === JSON && j.stringify(j.parse('{"x":1}')) === '{"x":1}');
