globalThis.Reflect=1;globalThis.Math=2;globalThis.JSON=3;globalThis.Atomics=4;print(Reflect+Math+JSON+Atomics===10);
