from pathlib import Path
import json,subprocess,sys,hashlib,time
root=Path.cwd();out=root/'target/performance-deferred-namespaces';d=out/'temporal-test-correction';sys.path.insert(0,str(root/'scripts'))
from benchmark_metrics import digest
from native_test_protocol import parse_inventory,result_summaries
rows=[json.loads(l) for l in (d/'build.jsonl').read_text().splitlines()];assert rows[-1]=={'reason':'build-finished','success':True}
p=next(r for r in rows if r.get('reason')=='compiler-artifact' and r.get('executable') and r['profile']['test'] and r['target']['name']=='scriptw_aot_wasm');exe=Path(p['executable']);sha=digest(exe);name='tests::temporal_demand_initialization::canonical_runtime_defers_the_actual_temporal_graph_and_exports_typed_ensure';inventory=parse_inventory(subprocess.check_output([exe,'--list'],text=True));assert name in inventory;argv=[str(exe),'--exact',name,'--test-threads=1','--nocapture'];start=time.monotonic()
with (d/'corrected.stdout').open('wb') as stdout,(d/'corrected.stderr').open('wb') as stderr:r=subprocess.run(argv,stdout=stdout,stderr=stderr,timeout=600)
summaries=result_summaries((d/'corrected.stdout').read_text());record=dict(target='scriptw_aot_wasm',selected_inventory=[name],executable=str(exe),executable_sha256=sha,producer=p,argv=argv,stdout=str(d/'corrected.stdout'),stderr=str(d/'corrected.stderr'),exit_code=r.returncode,summaries=summaries,elapsed_seconds=time.monotonic()-start);(d/'corrected-receipt.json').write_text(json.dumps([record],indent=2)+'\n');print(r.returncode,summaries,flush=True);assert r.returncode==0 and summaries==[('ok','1','0','0','0',str(len(inventory)-1))]
subprocess.run(['cp','--reflink=auto',str(exe),str(d/'corrected-backend-tests')],check=True);assert digest(d/'corrected-backend-tests')==sha
inputs=json.loads((out/'pre-build-sources.json').read_text());changed=[n for n,h in inputs.items() if digest(root/n)!=h];assert set(changed)=={'crates/scriptw-aot-wasm/src/tests/intl_demand_initialization.rs','crates/scriptw-aot-wasm/src/tests/scalar_regions.rs'}
temporal='crates/scriptw-aot-wasm/src/tests/temporal_demand_initialization.rs'
committed=subprocess.check_output(['git','show','c5586f330d57a8fa70a97836b4d0a8c5cda201d0:'+temporal],cwd=root)
assert committed==(d/'original-temporal_demand_initialization.rs').read_bytes()
assert digest(root/temporal)==json.loads((d/'correction.json').read_text())['corrected_source_sha256']
changed.append(temporal)
for key,val in json.loads((out/'candidate/products.json').read_text()).items():assert digest(out/'candidate'/key)==val['sha256']
(d/'production-reuse.json').write_text(json.dumps(dict(status='unchanged production; three excluded test-only corrections',source_fingerprint=json.loads((out/'candidate/identity.json').read_text())['source_fingerprint'],changed_source_paths=changed,excluded_by='compiler_fingerprint.rs TEST_ONLY_INPUTS crates/scriptw-aot-wasm/src/tests'),indent=2)+'\n')
