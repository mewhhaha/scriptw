"""Finalize inert evidence only after all campaigns and independent audits finish.

Run with --finalize --status accepted|rejected under limited_verification.
This helper never runs measurements, tests, builds, reference tools or audits.
"""
import argparse
import collections
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import statistics
import tarfile

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
DOCS = ROOT / "docs/rust-rewrite"
STEM = "deferred-namespaces-20261101"
BASELINE_FP = "5b20fafcf08ed06d495ffb4f3a980fcc65e819ebfcc9bf597754ef4c6300ab75"
CANDIDATE_FP = "62ff8d84ca4b5d9d3a763739378b029effc2f4c25bf045ffac257bff9a2f0a84"
ACCEPTED_BASELINE = "c5586f330d57a8fa70a97836b4d0a8c5cda201d0"
COMPILED_BASELINE = "259d4c4a644006acaa1e648616007406658a796d"
COUNTS = dict(aa=272, ordinary=272, cp_control=272, namespace_controls=144)
TEXT_SUFFIXES = {
    ".json", ".jsonl", ".py", ".log", ".stdout", ".stderr", ".inventory",
    ".rs", ".patch", ".wat", ".wat-fragment", ".script", ".map",
    ".identity", ".js", ".md", ".txt", ".toml", ".lock", ".csv",
}
TEXT_DIRS = {
    "baseline", "baseline-aa", "candidate", "native", "native-focused",
    "encoded-witness-correction", "encoded-test-correction", "temporal-test-correction",
    "first-compile", "test-api-compile", "namespace-controls", "test262-namespaces",
    "runs", "cp-control", "raw", "sources", "retained-sources", "adapted-scriptc",
    "expected", "program-inspection", "product-semantics", "witness-diagnostic",
}
FORBIDDEN_DIRS = {"tools", "toolchain", "node_modules", ".git", "__pycache__", "cache", ".cache"}
MAX_FILE, MAX_TOTAL, MAX_MEMBERS, MAX_ARCHIVE = 64 << 20, 512 << 20, 20000, 128 << 20


def load(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def file_hash(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def native_coverage(audit):
    first = audit["excluded_test_source_correction"]
    temporal = audit["temporal_test_source_correction"]
    backend = set(temporal["retained_broad_passes"]) | set(first["retained_original_backend_passes"])
    backend |= set(first["corrected_exact_test_passes"]) | set(temporal["corrected_exact_test_passes"])
    assert len(backend) == temporal["backend_unique_pass_union"] == 580
    union = {("scriptw_aot_wasm", name) for name in backend}
    for row in load(BASE / "native/receipt.json"):
        if row["target"] == "scriptw_aot_wasm":
            assert row["exit_code"] == 101, "preserve the original failed broad receipt"
            continue
        assert row["exit_code"] == 0 and all(s[0] == "ok" and int(s[2]) == 0 for s in row["summaries"])
        assert sum(int(s[1]) for s in row["summaries"]) == len(row["selected_inventory"])
        union.update((row["target"], name) for name in row["selected_inventory"])
    union.update(("aot_gc_entries", name) for name in first["retained_original_semantic_passes"])
    assert len(union) == 1744
    guards = (BASE / "guards.stdout").read_text(encoding="utf-8")
    totals = re.findall(r"test result: ok\. (\d+) passed; 0 failed; 0 ignored;", guards)
    assert sum(map(int, totals)) == 359
    return dict(native_distinct=len(union), native_by_target=dict(collections.Counter(t for t, _ in union)),
        source_guards=359, source_guard_scope="Source-only subsets; full Cargo targets are counted separately.",
        test_correction_chains=dict(focused_and_intermediate=first, broad_temporal=temporal),
        correction_boundary="Three original encoded failures and one intermediate scalar failure remain preserved. "
            "Three final capped exact passes qualify; the uncapped Intl diagnostic is excluded. "
            "Counts are a union of named retained passes and exact corrections, never a claimed full rerun.")


def references(analysis, audit):
    assert audit["status"] == "audited" and audit["attempts"] == 136
    assert audit["source_fingerprints"] == dict(baseline=BASELINE_FP, candidate=CANDIDATE_FP)
    groups = collections.defaultdict(list)
    seen = set()
    for row in analysis["attempts"]:
        key = (row["file"], row["runtime"], row["round"])
        assert row["status"] == "ok" and key not in seen and len(row["times_ns"]) == 21
        seen.add(key)
        groups[key[:2]].append(row["times_ns"])
    assert len(seen) == 136 and len(groups) == 68 and all(len(v) == 2 for v in groups.values())
    cases = sorted({name for name, _ in groups})
    assert len(cases) == len(analysis["compilation"]) == audit["scriptc_compilations"] == 17
    primary, median_wins, mean_wins = [], dict(v8=[], scriptc=[]), dict(v8=[], scriptc=[])
    for name in cases:
        stats = {runtime: dict(median_ns=statistics.median(statistics.median(v) for v in groups[name, runtime]),
            mean_ns=statistics.mean(statistics.mean(v) for v in groups[name, runtime]))
            for runtime in ["baseline", "candidate", "v8", "scriptc"]}
        for runtime in median_wins:
            if stats["candidate"]["median_ns"] < stats[runtime]["median_ns"]:
                median_wins[runtime].append(name)
            if stats["candidate"]["mean_ns"] < stats[runtime]["mean_ns"]:
                mean_wins[runtime].append(name)
        primary.append(dict(case=name, runtimes=stats))
    assert {k: sorted(v) for k, v in audit["median_wins"].items()} == median_wins
    return dict(scope=analysis["policy"], tools=analysis["tools"], attempts=len(seen),
        measured_observations=len(seen) * 21, warmups=len(seen) * 10,
        scriptc_compilations=len(analysis["compilation"]), median_wins=median_wins, mean_wins=mean_wins,
        experimental_unit="Independent process; median of two process medians and mean of two process means.",
        process_statistics=primary, pooled_statistics_descriptive=analysis["summary"],
        boundary="V8 context creation is outside execution timing; Scriptw Realm/bootstrap/completion remains inside. "
            "Scriptc Store/instantiation is outside, _start/output extraction inside. "
            "Descriptive existing boundaries, not equal end-to-end Realm costs. Endpoint RSS is not peak/live JS memory.")


def conformance(receipt):
    assert receipt["status"] in {"complete", "failed"} and receipt["source_fingerprint"] == CANDIDATE_FP
    assert receipt["cli_sha256"] == load(BASE / "candidate/products.json")["scriptw"]["sha256"]
    assert receipt["source_commit"] == load(BASE / "candidate/identity.json")["source_commit"]
    rows = []
    for scope in receipt["scopes"]:
        assert not scope["timed_out"] and scope["launch_error"] is None and len(scope["snapshots"]) == 1
        snapshot = scope["snapshots"][0]
        assert snapshot["source_fingerprint_matches"] and snapshot["total"] > 0
        rows.append(dict(selection=scope["selection"], scope_pass=scope["scope_pass"], exit_code=scope["exit_code"],
            passed=snapshot["passed"], total=snapshot["total"], pinned_revisions=snapshot["pinned_revisions"],
            completed_test_ids_sha256=snapshot["completed_test_ids_sha256"],
            failures=snapshot["failures"], timeout_test_ids=snapshot["timeout_test_ids"]))
    assert len(rows) == 9 and len({r["selection"] for r in rows}) == 9
    return dict(status=receipt["status"], passed=sum(r["passed"] for r in rows),
        total=sum(r["total"] for r in rows), scopes=rows, full_Test262_or_release_acceptance=False)


def text_members():
    total, selected, excluded = 0, [], []
    for folder, dirs, names in os.walk(BASE, followlinks=False):
        folder = Path(folder)
        kept = []
        for name in sorted(dirs):
            path = folder / name
            if path.is_symlink() or name in FORBIDDEN_DIRS or name.endswith("-cache") or name.startswith("cache-"):
                excluded.append(str(path.relative_to(BASE)))
            elif folder != BASE or name in TEXT_DIRS:
                kept.append(name)
            else:
                excluded.append(str(path.relative_to(BASE)))
        dirs[:] = kept
        for name in sorted(names):
            path = folder / name
            relative = path.relative_to(BASE)
            if path.is_symlink() or not path.is_file() or path.suffix not in TEXT_SUFFIXES:
                excluded.append(str(relative))
                continue
            size = path.stat().st_size
            assert size <= MAX_FILE, f"oversized allowlisted text: {relative}"
            total += size
            assert total <= MAX_TOTAL and len(selected) + 2 < MAX_MEMBERS
            raw = path.read_bytes()
            raw.decode("utf-8")  # Unexpected binary under a text suffix fails closed.
            assert not raw.startswith((b"\0asm", b"\x7fELF", b"SCRWRB01")), f"binary magic in text member: {relative}"
            member = "deferred-namespaces/" + relative.as_posix()
            assert not PurePosixPath(member).is_absolute() and ".." not in PurePosixPath(member).parts
            selected.append((member, raw))
    return selected, excluded


def archive_text(destination):
    selected, excluded = text_members()
    notice = ("Inert UTF-8 evidence only. No binary executables, Wasm modules, native images, toolchains, "
        "caches or symlinks. Scripts are recorded workflow text, not an archive execution interface. "
        "Hashes of producer outputs do not authorize loading native code.\n").encode()
    inventory = dict(members=[dict(path=name, bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
        for name, raw in selected], excluded=excluded,
        limits=dict(file_bytes=MAX_FILE, total_bytes=MAX_TOTAL, members=MAX_MEMBERS, archive_bytes=MAX_ARCHIVE))
    members = [("EVIDENCE.txt", notice), ("EVIDENCE.json", (json.dumps(inventory, indent=2) + "\n").encode())] + selected
    assert len(members) <= MAX_MEMBERS and sum(len(raw) for _, raw in members) <= MAX_TOTAL
    temporary = destination.with_name(destination.name + ".tmp")
    assert not destination.exists() and not temporary.exists(), "preserve previous packages"
    with tarfile.open(temporary, "w:xz", preset=6) as archive:
        for name, raw in members:
            info = tarfile.TarInfo(name)
            info.size, info.mode, info.mtime = len(raw), 0o644, 0
            archive.addfile(info, io.BytesIO(raw))
    assert temporary.stat().st_size <= MAX_ARCHIVE
    with tarfile.open(temporary, "r:xz") as archive:
        actual = archive.getmembers()
        assert [m.name for m in actual] == [name for name, _ in members]
        for member, (_, expected) in zip(actual, members):
            assert member.isfile() and member.mode == 0o644 and not member.issym() and not member.islnk()
            raw = archive.extractfile(member).read()
            raw.decode("utf-8")
            assert raw == expected
    temporary.replace(destination)
    return dict(path=destination.name, sha256=file_hash(destination), bytes=destination.stat().st_size,
        utf8_members=len(members), expanded_utf8_bytes=sum(len(raw) for _, raw in members),
        contains_native_or_wasm_binaries=False, excluded_path_count=len(excluded))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--finalize", action="store_true", required=True)
    parser.add_argument("--status", choices=["accepted", "rejected"], required=True)
    parser.add_argument("--audit", type=Path, default=BASE / "independent-audit.json")
    parser.add_argument("--reference-analysis", type=Path, default=BASE / "reference-analysis.json")
    parser.add_argument("--reference-audit", type=Path, default=BASE / "reference-audit.json")
    args = parser.parse_args()
    audit = load(args.audit)
    assert audit["status"] == "audited" and audit["total_raw_invocations"] == 960
    assert {k: v["raw_invocations"] for k, v in audit["cohorts"].items()} == COUNTS
    assert audit["measured_observations"] == 20160 and audit["warmup_observations"] == 9600
    baseline, candidate = load(BASE / "baseline/identity.json"), load(BASE / "candidate/identity.json")
    assert baseline["source_fingerprint"] == BASELINE_FP and baseline["source_commit"] == COMPILED_BASELINE
    assert candidate["source_fingerprint"] == CANDIDATE_FP
    assert audit["baseline_accepted_commit"] == ACCEPTED_BASELINE
    study, corpus = load(BASE / "study-plan.json"), load(BASE / "corpus.json")
    assert study["baseline_commit"] == ACCEPTED_BASELINE and study["runtime"] == dict(previous_abi=42, candidate_abi=43, expected_P_and_R_changes=True)
    verification = native_coverage(audit)
    verification["full_Test262_or_release_acceptance"] = False
    formatting = load(BASE / "format-classification.json")
    assert formatting["global_exit"] == 1 and len(formatting["preexisting_paths"]) == 15
    assert formatting["changed_path_overlap"] == [] and formatting["changed_exit"] == 0
    verification["formatting"] = formatting
    conformance_receipt = BASE / "test262-namespaces/test262-namespaces-receipt.json"
    if args.status == "accepted":
        verification["pinned_test262"] = conformance(load(conformance_receipt))
        reference = references(load(args.reference_analysis), load(args.reference_audit))
        reference_boundary = "The136 direct-reference processes are separate and are not added to cohort gates."
    else:
        cp = audit["cohorts"]["cp_control"]
        assert not cp["gate_pass"] and "retained-objects.js" in cp["vetoed_controls_both_blocks"]
        assert all(audit["cohorts"][name]["gate_pass"] for name in ["ordinary", "namespace_controls"])
        assert not conformance_receipt.exists() and not args.reference_analysis.exists() and not args.reference_audit.exists()
        reason = "not run: predeclared CP gate vetoed candidate"
        verification["pinned_test262"] = dict(status=reason, scopes_run=0, planned_scopes=9,
            full_Test262_or_release_acceptance=False)
        reference = dict(status=reason, attempts=0, planned_attempts=136)
        reference_boundary = "The planned136 direct-reference processes and nine selected Test262 scopes were not run: predeclared CP gate vetoed candidate."
    profiles = load(BASE / "runtime-profile-delta.json")
    for name, row in profiles.items():
        if "runtime_wasm_bytes" in row:
            assert row["source_fingerprint"] == CANDIDATE_FP and row["previous_source_fingerprint"] == BASELINE_FP
            assert row["runtime_abi"] == 43 and row["previous_runtime_abi"] == 42
            row["runtime_wasm_delta_bytes"] = row["runtime_wasm_bytes"] - row["previous_runtime_wasm_bytes"]
        else:
            row["native_delta_bytes"] = row["bytes"] - row["previous_bytes"]
    if args.status == "accepted":
        assert all(audit["cohorts"][name]["gate_pass"] for name in ["ordinary", "cp_control", "namespace_controls"])
        assert verification["pinned_test262"]["status"] == "complete"
    summary = dict(schema="scriptw-deferred-namespaces-checkpoint-v1", date="2026-11-01", status=args.status,
        baseline_accepted_commit=ACCEPTED_BASELINE, baseline_binary_source_commit=COMPILED_BASELINE,
        source_parent_commit=candidate["source_commit"], baseline_source_fingerprint=BASELINE_FP,
        candidate_source_fingerprint=CANDIDATE_FP, products=load(BASE / "candidate/products.json"),
        candidate_changes=["Reflect/Math/JSON/Atomics are materialized only when their public recipe is observed.",
            "One closed six-kind DeferredNamespace recipe owns defining Realm, kind and cached value. "
            "Intl/Temporal retain canonical ensure owners and public replacement isolation.",
            "RealmInitializeIntrinsics returns void; four bootstrap namespace results are removed. Runtime ABI42 becomes43.",
            "Dormant same-Realm exact Math.imul guards remain pure; cached namespaces check live own method/native identity."],
        runtime_abi=dict(previous=42, candidate=43), runtime_profiles=profiles,
        resource_policy=study["resource_policy"],
        corpus=dict(manifest_sha256=corpus["manifest_sha256"], files_sha256=corpus["files_sha256"]),
        cohorts=audit["cohorts"], audit=dict(total_raw_invocations=960, measured_observations=20160, warmups=9600,
            cohort_counts=COUNTS, maximum_statistical_discrepancy=audit["maximum_recomputed_statistic_discrepancy"],
            P_footprints=audit["P_footprints"], namespace_P_footprints=audit["namespace_P_footprints"]),
        reference=reference, verification=verification,
        limitations=["Full release/Test262 acceptance and overall V8/Scriptc parity remain open.",
            "960 audited process inputs include A/A272, ordinary272, CP272 and namespace144. "
            + reference_boundary,
            "Each process has21 measured samples and10 warmups. Pooled observations are descriptive; no samples are removed.",
            "ABI43 and both R/native profiles changed. No claim that P packages remain byte-identical.",
            "Hot-R CP uses compiler-disabled SizeOptimized/backtracking, unlike ordinary Fast execution; do not subtract lanes for attribution.",
            "Runtime cache/retained-image counts do not identify GC, page-fault, RSS or bootstrap subcosts."] + audit["limitations"])
    if args.status == "rejected":
        summary["production_retained"] = dict(accepted_commit=ACCEPTED_BASELINE,
            source_fingerprint=BASELINE_FP, runtime_abi=42)
        summary["rejection"] = dict(reason="Predeclared hot-R CP control veto; ordinary/first-touch gains do not override it.",
            cases=[row for row in audit["cohorts"]["cp_control"]["comparisons"] if row["case"] == "retained-objects.js"])
    for name in ["product-semantics/cache-proof.json", "product-semantics/receipt.json", "program-inspection/identity.json"]:
        path = BASE / name
        if path.is_file():
            summary.setdefault("additional_receipts", {})[name] = load(path)
    destination = DOCS / (STEM + "-inert.tar.xz")
    summary_path = DOCS / (STEM + ".json")
    assert not summary_path.exists(), "preserve previous summary"
    summary["evidence"] = archive_text(destination)
    summary_path.write_text(json.dumps(summary, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps(summary["evidence"], indent=2))


if __name__ == "__main__":
    main()
