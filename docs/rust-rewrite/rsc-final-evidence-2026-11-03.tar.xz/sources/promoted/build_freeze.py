#!/usr/bin/env python3
"""Build and freeze the current release CLI, then its RSC example, serially."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

ROOT = Path(__file__).resolve().parents[3]
WORK = ROOT / 'target/react-performance-20261103/promoted'
FROZEN = WORK / 'frozen'
PRIOR = ROOT / 'target/rsc-platform-work'
PACKAGE_SUFFIX = '/crates/scriptw-cli#0.1.0'


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def artifact_for(stdout, target_name):
    found = []
    for line in stdout.splitlines():
        if not line.strip():
            continue
        item = json.loads(line)
        if item.get('reason') != 'compiler-artifact':
            continue
        target = item['target']
        package = item.get('package_id', '')
        if package.endswith(PACKAGE_SUFFIX) and target.get('name') == target_name:
            found.append(item)
    require(len(found) == 1, f'expected one {target_name} compiler artifact, got {len(found)}')
    return found[0]


def prior_target(path, target_name):
    artifact = artifact_for(path.read_bytes(), target_name)
    return dict(log=str(path.relative_to(ROOT)), log_sha256=sha(path),
                profile=artifact['profile'], features=artifact['features'])


def build(name, target_name, command, prior_log):
    started = time.monotonic_ns()
    wall_start = datetime.now(timezone.utc).isoformat()
    result = subprocess.run(command, cwd=ROOT, stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE, check=False)
    elapsed = time.monotonic_ns() - started
    out_path = WORK / f'{name}.cargo.jsonl'
    err_path = WORK / f'{name}.stderr'
    out_path.write_bytes(result.stdout)
    err_path.write_bytes(result.stderr)
    require(result.returncode == 0, f'{name} cargo build failed with {result.returncode}')
    artifact = artifact_for(result.stdout, target_name)
    previous = prior_target(prior_log, target_name)
    current_profile_features = dict(profile=artifact['profile'], features=artifact['features'])
    require(current_profile_features == {key: previous[key] for key in ('profile', 'features')},
            f'{target_name} profile/features differ from prior candidate build')

    source_path = Path(artifact['executable'] or artifact['filenames'][0]).resolve(strict=True)
    frozen_path = FROZEN / ('scriptw' if name == 'cli' else 'rsc_baseline')
    shutil.copy2(source_path, frozen_path)
    receipt = dict(artifact)
    receipt['source_executable'] = str(source_path)
    receipt['executable'] = str(frozen_path)
    receipt['frozen_executable_sha256'] = sha(frozen_path)
    (FROZEN / f'{name}-producer.json').write_text(json.dumps(receipt, indent=2) + '\n')
    result = dict(name=name, command=command, started_at=wall_start,
                  finished_at=datetime.now(timezone.utc).isoformat(), elapsed_ns=elapsed,
                  return_code=0, stdout=str(out_path.relative_to(ROOT)),
                  stdout_sha256=sha(out_path), stderr=str(err_path.relative_to(ROOT)),
                  stderr_sha256=sha(err_path), cargo_jsonl=str(out_path.relative_to(ROOT)),
                  cargo_jsonl_sha256=sha(out_path), artifact=receipt,
                  prior_candidate=dict(log=previous['log'], log_sha256=previous['log_sha256'],
                                       profile=previous['profile'], features=previous['features']),
                  profile_features_match=True)
    (FROZEN / f'{name}-build.json').write_text(json.dumps(result, indent=2) + '\n')
    print(f'{name} release build frozen in {elapsed / 1e9:.3f}s', flush=True)
    return result


def main():
    require(not FROZEN.exists(), 'frozen output already exists; refusing overwrite')
    FROZEN.mkdir(parents=True)
    cli = build('cli', 'scriptw',
                ['cargo', 'build', '--locked', '--release', '-p', 'scriptw-cli',
                 '--bin', 'scriptw', '--message-format=json-render-diagnostics'],
                PRIOR / 'candidate-cli-build.stdout')

    identity_started = time.monotonic_ns()
    identity = subprocess.run([str(FROZEN / 'scriptw'), 'compiler-identity'], cwd=ROOT,
                              stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
    identity_elapsed = time.monotonic_ns() - identity_started
    require(identity.returncode == 0 and not identity.stderr,
            'frozen CLI compiler-identity command failed')
    identity_json = json.loads(identity.stdout)
    (FROZEN / 'cli-identity.json').write_text(json.dumps(identity_json, indent=2) + '\n')
    (FROZEN / 'cli-identity.stdout').write_bytes(identity.stdout)
    (FROZEN / 'cli-identity.stderr').write_bytes(identity.stderr)

    example = build('rsc', 'rsc_baseline',
                    ['cargo', 'build', '--locked', '--release', '-p', 'scriptw-cli',
                     '--example', 'rsc_baseline', '--message-format=json-render-diagnostics'],
                    PRIOR / 'candidate-rsc-build.stdout')
    manifest = dict(schema='scriptw-react-performance-build-freeze-v1', status='complete',
                    created_at=datetime.now(timezone.utc).isoformat(),
                    source_revision=subprocess.run(['git', 'rev-parse', 'HEAD'], cwd=ROOT,
                                                   text=True, stdout=subprocess.PIPE,
                                                   check=True).stdout.strip(),
                    cli=cli, cli_identity=dict(path=str((FROZEN / 'cli-identity.json').relative_to(ROOT)),
                                              sha256=sha(FROZEN / 'cli-identity.json'),
                                              elapsed_ns=identity_elapsed),
                    rsc_example=example)
    (FROZEN / 'build-freeze.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print(f'frozen CLI and RSC example under {FROZEN}', flush=True)


if __name__ == '__main__':
    main()
