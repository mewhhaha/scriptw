"""Inspect retained Wasm bytes and compiler body reports; no code execution."""
from pathlib import Path
from collections import defaultdict
import hashlib
import json
import re
import struct

OUT = Path(__file__).resolve().parent
BASE = OUT.parents[2] / 'rsc-wasm-size-20261103'
blob = (OUT / 'program.wasm').read_bytes()
assert blob[:8] == b'\0asm\1\0\0\0'

def uleb(position):
    value = shift = 0
    while True:
        byte = blob[position]
        position += 1
        value |= (byte & 127) << shift
        if byte < 128:
            return value, position
        shift += 7

sections, segments, bodies = [], [], []
position = 8
while position < len(blob):
    start, kind = position, blob[position]
    size, position = uleb(position + 1)
    end = position + size
    row = dict(id=kind, start=start, payload_bytes=size,
               section_header_bytes=position-start, total_bytes=end-start)
    if kind == 0:
        length, cursor = uleb(position)
        row['name'] = blob[cursor:cursor+length].decode()
    if kind == 10:
        count, cursor = uleb(position)
        for ordinal in range(count):
            length, cursor = uleb(cursor)
            bodies.append(dict(ordinal=ordinal, start=cursor, bytes=length))
            cursor += length
        assert cursor == end
    if kind == 11:
        count, cursor = uleb(position)
        for ordinal in range(count):
            flag, cursor = uleb(cursor)
            assert flag == 1
            length, cursor = uleb(cursor)
            segments.append(blob[cursor:cursor+length])
            cursor += length
        assert cursor == end
    sections.append(row)
    position = end
assert 8 + sum(row['total_bytes'] for row in sections) == len(blob)

pattern = re.compile(r'emitted function: index=(\d+) bytes=(\d+) locals=(\d+) kind=(\S+) name=(.+)')
functions = []
for line in (OUT / 'functions.txt').read_text().splitlines():
    index, size, locals_count, kind, name = pattern.fullmatch(line).groups()
    functions.append(dict(index=int(index), bytes=int(size), locals=int(locals_count), kind=kind, name=name))
assert len(functions) == len(bodies)
for row, body in zip(sorted(functions, key=lambda row: row['index']), bodies):
    assert row['bytes'] == body['bytes']
    row.update(body)
categories = defaultdict(lambda: dict(functions=0, body_bytes=0))
for row in functions:
    categories[row['kind']]['functions'] += 1
    categories[row['kind']]['body_bytes'] += row['bytes']

strings = []
for index, offset, units in struct.iter_unpack('<III', segments[2]):
    assert offset % 2 == 0 and offset + units*2 <= len(segments[0])
    text = segments[0][offset:offset+units*2].decode('utf-16-le', 'surrogatepass')
    strings.append(dict(index=index, offset=offset, units=units, text=text))
encoded = b''.join(row['text'].encode('utf-8', 'surrogatepass') for row in sorted(strings, key=lambda row: row['index']))
assert segments[1].startswith(encoded)

baseline = json.loads((BASE / 'attribution.json').read_text())
old_functions = {row['name']: row for row in json.loads((BASE/'functions.json').read_text())}
old_blob = (BASE/'program.wasm').read_bytes()
old_strings = {row['index']: row['text'] for row in json.loads((BASE/'strings.json').read_text())}
old_literal_texts = set(old_strings.values())
new_literal_texts = {row['text'] for row in strings}
literal_ordinal_changes = sum(old_strings.get(row['index']) != row['text'] for row in strings)
assert set(old_functions) == {row['name'] for row in functions}

function_deltas = []
for row in functions:
    old = old_functions.get(row['name'], dict(bytes=0, locals=0, start=0))
    function_deltas.append(dict(name=row['name'], kind=row['kind'], old_bytes=old['bytes'], new_bytes=row['bytes'], delta_bytes=row['bytes']-old['bytes'], old_locals=old['locals'], new_locals=row['locals'], encoded_body_identical=old_blob[old['start']:old['start']+old['bytes']] == blob[row['start']:row['start']+row['bytes']]))
old_sections = {(row['id'], row.get('name')): row for row in baseline['sections']}
section_deltas = []
for row in sections:
    old = old_sections[(row['id'], row.get('name'))]
    section_deltas.append(dict(id=row['id'], name=row.get('name'), old_bytes=old['total_bytes'], new_bytes=row['total_bytes'], delta_bytes=row['total_bytes']-old['total_bytes']))
roles = ['pooled UTF-16', 'metadata including byte-oriented string image', 'literal descriptors', 'compact array recipes']
report = dict(schema='scriptw-rsc-size-comparison-v1',
    measured_inputs=json.loads((OUT/'measured-input.json').read_text()),
    program_bytes=len(blob), program_sha256=hashlib.sha256(blob).hexdigest(),
    baseline_program_sha256=baseline['program_sha256'], baseline_program_bytes=baseline['program_bytes'],
    program_delta_bytes=len(blob)-baseline['program_bytes'], wasm_header_bytes=8,
    sections=sections, section_deltas=section_deltas,
    defined_functions=len(functions), imported_functions=min(row['index'] for row in functions),
    body_bytes=sum(row['bytes'] for row in functions), categories=dict(categories),
    category_deltas={key:dict(old_body_bytes=baseline['categories'][key]['body_bytes'], new_body_bytes=value['body_bytes'], delta_bytes=value['body_bytes']-baseline['categories'][key]['body_bytes']) for key,value in categories.items()},
    data_segments=[dict(index=index, bytes=len(segment), role=roles[index], old_bytes=baseline['data_segments'][index]['bytes'], delta_bytes=len(segment)-baseline['data_segments'][index]['bytes']) for index,segment in enumerate(segments)],
    string_pool=dict(count=len(strings), changed_literal_ordinals=literal_ordinal_changes, all_literal_contents_match_baseline=old_literal_texts == new_literal_texts, removed_literal_contents=len(old_literal_texts-new_literal_texts), added_literal_contents=len(new_literal_texts-old_literal_texts), physical_utf16_bytes=len(segments[0]), logical_utf16_bytes=sum(row['units']*2 for row in strings), utf8_wtf8_bytes=len(encoded), other_metadata_bytes=len(segments[1])-len(encoded)),
    largest_functions=sorted(functions, key=lambda row: row['bytes'], reverse=True)[:15],
    largest_body_increases=sorted(function_deltas,key=lambda row:row['delta_bytes'],reverse=True)[:15],
    unchanged_function_count=sum(row['delta_bytes']==0 for row in function_deltas),
    identical_body_counts={kind:sum(row['encoded_body_identical'] for row in function_deltas if row['kind']==kind) for kind in categories},
    limits='Static encoded-byte accounting, including section headers. Capture stopped before native compilation. Not runtime shares, allocation counts, or causal isolation of individual source changes.')
trial_dir = OUT.parents[1] / 'size'
trial = json.loads((trial_dir/'attribution.json').read_text())
trial_functions = {row['name']: row for row in json.loads((trial_dir/'functions.json').read_text())}
trial_sections = {(row['id'], row.get('name')): row for row in trial['sections']}
trial_deltas = [dict(name=row['name'], kind=row['kind'], old_bytes=trial_functions[row['name']]['bytes'], new_bytes=row['bytes'], delta_bytes=row['bytes']-trial_functions[row['name']]['bytes'], old_locals=trial_functions[row['name']]['locals'], new_locals=row['locals']) for row in functions]
report['first_trial_comparison'] = dict(
    program_sha256=trial['program_sha256'], program_bytes=trial['program_bytes'],
    program_delta_bytes=len(blob)-trial['program_bytes'],
    sections=[dict(id=row['id'], name=row.get('name'), old_bytes=trial_sections[(row['id'],row.get('name'))]['total_bytes'], new_bytes=row['total_bytes'], delta_bytes=row['total_bytes']-trial_sections[(row['id'],row.get('name'))]['total_bytes']) for row in sections],
    categories={key:dict(old_body_bytes=trial['categories'][key]['body_bytes'], new_body_bytes=value['body_bytes'], delta_bytes=value['body_bytes']-trial['categories'][key]['body_bytes']) for key,value in categories.items()},
    largest_body_reductions=sorted(trial_deltas,key=lambda row:row['delta_bytes'])[:15])
report['largest_body_reductions'] = sorted(function_deltas,key=lambda row:row['delta_bytes'])[:15]
(OUT/'first-trial-function-deltas.json').write_text(json.dumps(trial_deltas,indent=2)+'\n')
(OUT/'attribution.json').write_text(json.dumps(report,indent=2)+'\n')
(OUT/'functions.json').write_text(json.dumps(functions,indent=2)+'\n')
(OUT/'function-deltas.json').write_text(json.dumps(function_deltas,indent=2)+'\n')
print(json.dumps({key:report[key] for key in ['program_bytes','program_sha256','program_delta_bytes','section_deltas','category_deltas','data_segments','string_pool','largest_body_increases']},indent=2))
