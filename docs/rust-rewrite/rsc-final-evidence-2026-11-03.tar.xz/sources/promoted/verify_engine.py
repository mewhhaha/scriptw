from pathlib import Path
import hashlib,json,re,subprocess,time
base=Path(__file__).resolve().parent
artifacts={}
for line in (base/'engine-build.stdout').open():
 try:row=json.loads(line)
 except ValueError:continue
 if row.get('reason')=='compiler-artifact' and row.get('executable'):artifacts[row['target']['name']]=row
scopes=[('module-cells','aot_realm_modules','aot_module_captured_cells',12),('codecs','aot_builtins','aot_text_codec',5),('streams','aot_builtins','aot_readable_byte_stream',9),('events','aot_builtins','aot_web_events',5),('tasks','aot_async','aot_host_tasks',6)]
if __import__('sys').argv[1:]==['broad']:
 scopes=[(name,name,None,n) for name,n in [('aot_builtins',589),('aot_async',254),('aot_realm_modules',452)]]
receipt='engine-focus.json'
if __import__('sys').argv[1:]==['broad']:receipt='engine-broad.json'
rows=[]
for label,target,filter_arg,expected in scopes:
 artifact=artifacts[target];binary=Path(artifact['executable']);argv=[str(binary)]
 if filter_arg:argv.append(filter_arg)
 argv.append('--test-threads=1');start=time.monotonic_ns()
 with (base/(label+'.stdout')).open('wb') as out,(base/(label+'.stderr')).open('wb') as err:
  result=subprocess.run(argv,stdout=out,stderr=err,timeout=1800)
 summaries=re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed;', (base/(label+'.stdout')).read_text())
 with binary.open('rb') as f:digest=hashlib.file_digest(f,'sha256').hexdigest()
 row={'label':label,'target':target,'argv':argv,'exit_code':result.returncode,'elapsed_ns':time.monotonic_ns()-start,'summaries':summaries,'executable_sha256':digest}
 rows.append(row);(base/receipt).write_text(json.dumps(rows,indent=2)+'\n')
 print(label,summaries,result.returncode,flush=True)
 assert result.returncode==0 and len(summaries)==1 and summaries[0][0]=='ok' and int(summaries[0][1])==expected and int(summaries[0][2])==0,row
