from pathlib import Path
import hashlib,json,re,subprocess,time
base=Path(__file__).resolve().parent
artifacts={}
for line in (base/'aot-build.stdout').open():
 try:row=json.loads(line)
 except ValueError:continue
 if row.get('reason')=='compiler-artifact' and row.get('executable'):
  artifacts[row['target']['name']]=row
rows=[]
for label,target,filter_arg,minimum in [('cell-encoded','scriptw_aot_wasm','tests::module_cell_reads::',2),('emission','emission',None,42)]:
 artifact=artifacts[target];binary=Path(artifact['executable']);argv=[str(binary)]
 if filter_arg:argv.append(filter_arg)
 argv.append('--test-threads=1');start=time.monotonic_ns()
 with (base/(label+'.stdout')).open('wb') as out,(base/(label+'.stderr')).open('wb') as err:
  result=subprocess.run(argv,stdout=out,stderr=err,timeout=1200)
 summaries=re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed;', (base/(label+'.stdout')).read_text())
 row={'label':label,'argv':argv,'exit_code':result.returncode,'elapsed_ns':time.monotonic_ns()-start,'summaries':summaries,'executable_sha256':hashlib.sha256(binary.read_bytes()).hexdigest()}
 rows.append(row);(base/'aot-verification.json').write_text(json.dumps(rows,indent=2)+'\n')
 print(label,row['summaries'],row['exit_code'],flush=True)
 assert result.returncode==0 and len(summaries)==1 and summaries[0][0]=='ok' and int(summaries[0][1])>=minimum and int(summaries[0][2])==0,row
