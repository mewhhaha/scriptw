#!/usr/bin/env python3
"""Validate and expose a completed Fast campaign aggregate in the chart schema."""
import argparse
from datetime import date
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[2]


def need(condition, message):
    if not condition:
        raise ValueError(message)


def read_object(path, name):
    value = json.loads(path.read_text())
    need(isinstance(value, dict), name + ' must contain a JSON object')
    return value


def validate(aggregate):
    need(aggregate.get('schema') == 'scriptw-rsc-fast-comparison-v1',
         'expected completed Fast comparison aggregate')
    need(re.fullmatch(r'\d{4}-\d{2}-\d{2}', aggregate.get('date', '')) is not None,
         'aggregate date must use YYYY-MM-DD')
    date.fromisoformat(aggregate['date'])
    measurement = aggregate.get('measurement', {})
    need(measurement.get('blocks') == 2 and measurement.get('processes_per_engine') == 8
         and measurement.get('warmups') == 3 and measurement.get('samples') == 7
         and isinstance(measurement.get('clock'), str) and measurement['clock'],
         'campaign cohort differs from public chart requirements')
    inputs = aggregate.get('inputs')
    need(isinstance(inputs, dict) and inputs
         and all(re.fullmatch(r'[0-9a-f]{64}', value or '') for value in inputs.values()),
         'input fingerprint inventory is invalid')
    engines = aggregate.get('engines', {})
    need(set(engines) == {'baseline', 'candidate', 'v8'}, 'engine inventory differs')
    for name, engine in engines.items():
        need(isinstance(engine.get('label'), str) and engine['label'], 'missing engine label: ' + name)
        cases = engine.get('cases', {})
        need(set(cases) == {'rsc-sync', 'rsc-async'}, 'case inventory differs: ' + name)
        for case, values in cases.items():
            need(isinstance(values, list) and len(values) == 8
                 and all(type(value) is int and value > 0 for value in values),
                 f'{name}/{case} must have eight positive process medians')
    for name in ('baseline', 'candidate'):
        phases = engines[name].get('phase_processes')
        need(isinstance(phases, list) and len(phases) == 8,
             'phase inventory must contain eight processes: ' + name)
        for row in phases:
            need(all(type(row.get(key)) is int and row[key] > 0
                     for key in ('front_and_lower', 'wasm_emission', 'native_preparation')),
                 'invalid compiler phase receipt: ' + name)
    need(isinstance(aggregate.get('source_identity'), dict)
         and aggregate['source_identity'], 'source identity is missing')
    need(isinstance(aggregate.get('caveat'), str) and aggregate['caveat'], 'caveat is missing')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--aggregate', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True,
                        help='new report path; existing reports are never overwritten')
    parser.add_argument('--verification-json', type=Path,
                        help='optional verification object added by the campaign owner')
    parser.add_argument('--evidence-archive-json', type=Path,
                        help='optional archive metadata object added after archive creation')
    parser.add_argument('--source-identity-json', type=Path,
                        help='optional source identity fields merged over the campaign aggregate')
    args = parser.parse_args()

    report = read_object(args.aggregate, 'aggregate')
    validate(report)
    report['schema'] = 'scriptw-rsc-current-v1'
    if args.verification_json is not None:
        report['verification'] = read_object(args.verification_json, 'verification metadata')
    if args.evidence_archive_json is not None:
        report['evidence_archive'] = read_object(args.evidence_archive_json, 'archive metadata')
    if args.source_identity_json is not None:
        report['source_identity'].update(read_object(args.source_identity_json, 'source identity metadata'))

    output = args.output if args.output.is_absolute() else ROOT / args.output
    need(not output.exists(), 'refusing to overwrite an existing report')
    output.parent.mkdir(parents=True, exist_ok=True)
    temporary = output.with_suffix(output.suffix + '.tmp')
    need(not temporary.exists(), 'report temporary already exists')
    temporary.write_text(json.dumps(report, indent=2, sort_keys=True, allow_nan=False) + '\n')
    temporary.replace(output)
    print(json.dumps({'path': str(output.relative_to(ROOT)), 'schema': report['schema'],
                      'date': report['date'], 'campaign_sha256': report['measurement']['campaign_sha256']},
                     sort_keys=True))


if __name__ == '__main__':
    main()
