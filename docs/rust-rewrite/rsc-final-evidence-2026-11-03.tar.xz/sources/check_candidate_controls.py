#!/usr/bin/env python3
"""Run the nine exact CLI controls against the frozen current release binary."""
from pathlib import Path
import hashlib
import json
import sys

ROOT = Path(__file__).resolve().parents[2]
WORK = ROOT / 'target/react-performance-20261103'
sys.path.insert(0, str(ROOT / 'scripts'))
from limited_verification import limited_environment, require_kernel_budget
from benchmark_metrics import digest, measure_process
from application_benchmarks import checked_product_stdout, validate_manifest

require_kernel_budget(4 * 1024**3)
base = WORK
fixtures = ROOT / 'target/application-benchmarks-20261102/generated-v2'
binary = WORK / 'frozen/scriptw'
time_binary = ROOT / 'target/performance-worker-cpu/tools/time'
output = base / 'cli-controls'
output.mkdir(exist_ok=False)
manifest = json.loads((fixtures / 'manifest.json').read_text())
support = json.loads((fixtures / 'support.json').read_text())
cases = [{'label': key, 'file': 'capability-' + key + '.js', 'stdout': support['expected'][key]}
         for key in ('rsc-sync', 'rsc-async')]
cases += [{'label': case['file'][:-3], 'file': case['file'], 'stdout': case['stdout']}
          for case in validate_manifest(manifest)]
if len(cases) != 9:
    raise ValueError(f'expected 9 exact CLI controls, found {len(cases)}')

rows = []
for case in cases:
    name = case['label']
    folder = output / name
    folder.mkdir()
    (folder / 'tmp').mkdir()
    (folder / 'cache').mkdir()
    env = limited_environment()
    env.update(TMPDIR=str(folder / 'tmp'), SCRIPTW_CACHE_DIR=str(folder / 'cache'))
    argv = [str(binary), '--jobs', '1', 'run', str(fixtures / case['file'])]
    with (folder / 'stdout').open('xb') as stdout, (folder / 'stderr').open('xb') as stderr:
        resources = measure_process(argv, cwd=ROOT, env=env, stdout=stdout, stderr=stderr,
                                   timeout=60, time_binary=time_binary)
    expected = case['stdout']
    row = dict(label=name, argv=argv, source_sha256=digest(fixtures / case['file']),
               executable_sha256=digest(binary), resources=resources,
               stdout_sha256=digest(folder / 'stdout'), stderr_sha256=digest(folder / 'stderr'),
               expected_sha256=hashlib.sha256(expected.encode()).hexdigest())
    if resources['exit_code'] != 0 or resources['timed_out']:
        raise ValueError(f'failed or timed out control: {name}')
    actual = (folder / 'stdout').read_text()
    row['guest_output_and_backend_outcome_match'] = checked_product_stdout(actual, expected)
    if (folder / 'stderr').read_bytes():
        raise ValueError(f'unexpected stderr for {name}')
    rows.append(row)
    (base / 'cli-controls.json').write_text(json.dumps(rows, indent=2) + '\n')
    print(name, round(resources['elapsed_ns'] / 1e9, 3), 's exact', flush=True)
