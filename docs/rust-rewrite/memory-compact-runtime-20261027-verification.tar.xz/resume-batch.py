from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
ROOT = Path(__file__).resolve().parents[2]
BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'scripts'))
from limited_verification import require_kernel_budget, kernel_group
require_kernel_budget(4 * 1024**3)
SOURCE = 'a68ee71ea'
SOURCE = subprocess.check_output(['git','rev-parse',SOURCE],cwd=ROOT,text=True).strip()
assert len(os.sched_getaffinity(0)) == 1
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip() == SOURCE
assert not subprocess.check_output(['git','diff','--binary','HEAD','--','crates','vendor','scripts','Cargo.toml','Cargo.lock'],cwd=ROOT)
group = kernel_group()
def resources():
 return {key:(group/key).read_text().strip() for key in ('memory.max','memory.swap.max','memory.oom.group','memory.peak','memory.events')}
def digest(path):
 with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
report=dict(source_commit=SOURCE,complete=False,started_at=datetime.now(timezone.utc).isoformat(),cpu_affinity=sorted(os.sched_getaffinity(0)),before=resources(),commands=[])
def save():(BASE/'resumed-batch-report.json').write_text(json.dumps(report,indent=2)+'\n')
plan=[
 ('vendor-reclamation-fixed',['cargo','test','--locked','--offline','--release','--jobs','1','--target-dir',str(ROOT/'target/performance-work-20261024/build'),'--manifest-path','vendor/wasmtime-47.0.0/Cargo.toml','--no-default-features','--features','cache,cranelift,gc,gc-copying,incremental-cache,parallel-compilation,runtime,std,threads','--lib','--message-format=json','--','discard_tests','reclamation_tests::','--test-threads=1']),
 ('native-driver',[sys.executable,'-B',str(BASE/'verify-native.py')]),
 ('cargo-products',['cargo','build','--locked','--offline','--release','--jobs','1','--target-dir',str(ROOT/'target/performance-work-20261024/build'),'-p','scriptw-cli','--bin','scriptw','--example','compiler_precompiled_baseline','--message-format=json']),
 ('test262-driver',[sys.executable,'-B',str(BASE/'test262.py')]),
]
save()
for label,args in plan:
 print(label,'started',flush=True)
 stdout=BASE/(label+('.jsonl' if label=='cargo-products' else '.stdout'))
 stderr=BASE/(label+'.stderr')
 entry=dict(label=label,command=args,stdout=stdout.name,stderr=stderr.name,started_at=datetime.now(timezone.utc).isoformat())
 report['commands'].append(entry);save()
 start=time.monotonic()
 with stdout.open('xb') as out,stderr.open('xb') as err:
  result=subprocess.run(args,cwd=ROOT,stdout=out,stderr=err,timeout=7200)
 entry.update(exit_code=result.returncode,seconds=time.monotonic()-start,stdout_sha256=digest(stdout),stderr_sha256=digest(stderr))
 save()
 print(label,'finished',result.returncode,flush=True)
 if result.returncode:
  print(stderr.read_text()[-10000:],flush=True)
  raise SystemExit(result.returncode)
report.update(complete=True,finished_at=datetime.now(timezone.utc).isoformat(),after=resources())
save();print('batch complete',flush=True)
