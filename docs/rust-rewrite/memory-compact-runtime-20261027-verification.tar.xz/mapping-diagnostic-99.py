"""Sample an unchanged consumer's mappings. Unscored, CPU-interfering diagnostic."""
from datetime import datetime,timezone
import hashlib,json,os,re,shutil,struct,subprocess,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'scripts'))
from limited_verification import require_kernel_budget,kernel_group
require_kernel_budget(4*1024**3);assert len(os.sched_getaffinity(0))==1
OUT=BASE/'mapping-diagnostic-99';OUT.mkdir(exist_ok=False)
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
cargo=[json.loads(x) for x in (ROOT/'target/memory-scriptc-lazy-20261026/cargo-products.jsonl').read_text().splitlines()]
assert cargo[-1]==dict(reason='build-finished',success=True)
rows=[x for x in cargo if x.get('reason')=='compiler-artifact' and x.get('executable') and x['target']['name']=='compiler_precompiled_baseline' and not x['profile']['test']]
assert len(rows)==1
exe=OUT/'consumer';shutil.copy2(rows[0]['executable'],exe);assert sha(exe)==sha(rows[0]['executable']) and exe.stat().st_nlink==1
manifest=json.loads((ROOT/'crates/scriptw-cli/tests/fixtures/v8_execution_hotpaths/manifest.json').read_text())
selected=[x for x in manifest['execution'] if x['file'] in ['integer.js','retained-objects.js']];assert len(selected)==2
fixtures=OUT/'sources';fixtures.mkdir();(fixtures/'manifest.json').write_text(json.dumps({'execution':selected})+'\n')
for row in selected:shutil.copy2(ROOT/'crates/scriptw-cli/tests/fixtures/v8_execution_hotpaths'/row['file'],fixtures/row['file'])
group=kernel_group()
def resources():return {k:(group/k).read_text().strip() for k in ['memory.max','memory.swap.max','memory.oom.group','memory.peak','memory.events']}
report=dict(scope='unscored-native-resident-mapping-diagnostic',timing_interpretation='Parent sampling competes on the same CPU. No timing or RSS sample enters scored cohorts; mapping maxima may miss transients.',complete=False,source_commit='99a4ff2e962b6efa8066a48447f3c077981c59ec',checkout_commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),executable_sha256=sha(exe),cargo_producer=rows[0],before=resources(),commands=[],cases=[])
def save():(OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n')
def run(label,args):
 row=dict(label=label,command=list(map(str,args)),stdout=label+'.stdout',stderr=label+'.stderr');report['commands'].append(row);save()
 with (OUT/row['stdout']).open('xb') as out,(OUT/row['stderr']).open('xb') as err:r=subprocess.run(row['command'],cwd=ROOT,stdout=out,stderr=err,timeout=1800)
 row.update(returncode=r.returncode,stdout_sha256=sha(OUT/row['stdout']),stderr_sha256=sha(OUT/row['stderr']));save();assert r.returncode==0,label
 return json.loads((OUT/row['stdout']).read_text())
identity=run('identity',[exe,'identity']);assert identity['source_commit']==report['source_commit'] and identity['executable_sha256']==report['executable_sha256']
producer=run('prepare',[exe,'prepare-scriptw',fixtures,OUT/'images'])
HEADER=re.compile(r'^([0-9a-f]+)-([0-9a-f]+) ([-rwxps]{4}) ([0-9a-f]+) ([0-9a-f:]+) (\d+)\s*(.*)$')
def aggregate(raw):
 groups={};current=None
 for line in raw.splitlines():
  match=HEADER.fullmatch(line)
  if match:
   key=(match[3],match[7] or '[anonymous]');current=groups.setdefault(key,dict(permissions=key[0],path=key[1],mapped_bytes=0,rss_bytes=0,private_dirty_bytes=0))
   current['mapped_bytes']+=int(match[2],16)-int(match[1],16)
  elif current is not None:
   for prefix,key in [('Rss:','rss_bytes'),('Private_Dirty:','private_dirty_bytes')]:
    if line.startswith(prefix):
     words=line[len(prefix):].split();assert len(words)==2 and words[1]=='kB';current[key]+=int(words[0])*1024
 return sorted(groups.values(),key=lambda x:x['rss_bytes'],reverse=True)
def executable_presence(pid,raw):
 page=os.sysconf('SC_PAGE_SIZE');result=[]
 try:
  with Path(f'/proc/{pid}/pagemap').open('rb') as f:
   for line in raw.splitlines():
    m=HEADER.fullmatch(line)
    if m is None or 'x' not in m[3] or m[7]!=str(exe):continue
    start,end=int(m[1],16),int(m[2],16);count=(end-start)//page
    assert count*8<=16*1024**2
    f.seek((start//page)*8);bits=f.read(count*8);assert len(bits)==count*8
    offset=int(m[4],16)
    present=[offset+i*page for i,(entry,) in enumerate(struct.iter_unpack('<Q',bits)) if entry>>63]
    result.append(dict(path=m[7],permissions=m[3],file_offset=offset,start=start,end=end,page_bytes=page,present_page_file_offsets=present))
 except (FileNotFoundError,PermissionError) as e:
  return dict(status='unavailable',reason=type(e).__name__)
 return dict(status='present-bits-only-no-PFNs',mappings=result)
for case in selected:
 label=case['file'];image=OUT/'images'/(label+'.swpc');prepared=next(x for x in producer['cases'] if x['file']==label);assert sha(image)==prepared['image_sha256']
 folder=OUT/label;folder.mkdir();command=[str(exe),'execute-scriptw',str(image),case['stdout'],'7','10']
 entry=dict(file=label,command=command,image_sha256=sha(image),snapshots=[],complete=False);report['cases'].append(entry);save()
 with (folder/'stdout').open('xb') as out,(folder/'stderr').open('xb') as err:
  child=subprocess.Popen(command,cwd=ROOT,stdout=out,stderr=err);start=time.monotonic();index=0;total_bytes=0
  try:
   while child.poll() is None:
    assert time.monotonic()-start<120,'diagnostic child deadline'
    if index<128:
     try:
      with Path(f'/proc/{child.pid}/smaps').open('rb') as f:raw=f.read(4*1024**2+1)
     except FileNotFoundError:break
     assert len(raw)<=4*1024**2
     if raw:
      total_bytes+=len(raw);assert total_bytes<=512*1024**2
      path=folder/f'{index:03d}.smaps';path.write_bytes(raw);maps=aggregate(raw.decode());rss=sum(x['rss_bytes'] for x in maps)
      entry['snapshots'].append(dict(seconds=time.monotonic()-start,path=str(path.relative_to(OUT)),sha256=sha(path),bytes=len(raw),rss_bytes=rss,largest_mappings=maps[:20],executable_presence=executable_presence(child.pid,raw.decode())))
      index+=1
    time.sleep(.02)
   code=child.wait(timeout=120)
  finally:
   if child.poll() is None:child.kill();child.wait()
 assert code==0,label
 value=json.loads((folder/'stdout').read_text());assert value['compiler_enabled'] is False and value['source_commit']==report['source_commit']
 assert all(x['matched'] and x['completion']=='normal' and x['stdout']==case['stdout'] for x in value['observations'])
 assert entry['snapshots'];entry.update(complete=True,returncode=code,stdout_sha256=sha(folder/'stdout'),stderr_sha256=sha(folder/'stderr'),maximum_sample=max(entry['snapshots'],key=lambda x:x['rss_bytes']));save()
assert sha(exe)==report['executable_sha256']
report.update(complete=True,after=resources(),finished_at=datetime.now(timezone.utc).isoformat());save()
print(json.dumps(dict(complete=True,source_commit=report['source_commit'],cases=[dict(file=x['file'],samples=len(x['snapshots']),sampled_max_rss_bytes=x['maximum_sample']['rss_bytes'],largest_mappings=x['maximum_sample']['largest_mappings'][:8]) for x in report['cases']]),indent=2))
