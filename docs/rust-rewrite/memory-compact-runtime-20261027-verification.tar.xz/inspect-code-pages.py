"""Nonadditive resident executable-page coverage, not proof of execution."""
import bisect,hashlib,json,struct
from pathlib import Path
BASE=Path(__file__).resolve().parent
results=[]
for directory,symbols in [('mapping-diagnostic-99-v2','consumer99-symbols.stdout'),('mapping-diagnostic-current','consumer-current-symbols.stdout')]:
 root=BASE/directory;report=json.loads((root/'report.json').read_text());binary=root/'consumer'
 with binary.open('rb') as f:
  assert hashlib.file_digest(f,'sha256').hexdigest()==report['executable_sha256']
 with binary.open('rb') as f:
  head=struct.unpack('<16sHHIQQQIHHHHHH',f.read(64));assert head[0][:6]==b'\x7fELF\x02\x01'
  phoff,entry_size,count=head[5],head[9],head[10];assert entry_size==56 and count<4096
  f.seek(phoff);segments=[struct.unpack('<IIQQQQQQ',f.read(56)) for _ in range(count)]
 loads=[p for p in segments if p[0]==1 and p[1]&1]
 definitions=[]
 for line in (BASE/symbols).open():
  row=line.rstrip().split(maxsplit=3)
  if len(row)!=4 or row[2] not in ['t','T']:continue
  address,size=int(row[0],16),int(row[1],16)
  if not size:continue
  matches=[p for p in loads if p[3]<=address and address+size<=p[3]+p[5]]
  if len(matches)!=1:continue
  p=matches[0];offset=p[2]+address-p[3]
  name=row[3].lstrip('<').split(' as ',1)[0]
  owner='::'.join(name.split('::')[:3]);definitions.append((offset,size,owner))
 for case in report['cases']:
  snapshot=case['maximum_sample'];presence=snapshot['executable_presence'];assert presence['status']=='present-bits-only-no-PFNs'
  page_sizes={m['page_bytes'] for m in presence['mappings']};assert len(page_sizes)==1;page=page_sizes.pop()
  present=sorted({x for m in presence['mappings'] if 'x' in m['permissions'] for x in m['present_page_file_offsets']})
  covered={}
  for offset,size,owner in definitions:
   first=offset//page*page;end=(offset+size-1)//page*page
   a,b=bisect.bisect_left(present,first),bisect.bisect_right(present,end)
   if a<b:covered.setdefault(owner,set()).update(present[a:b])
  groups=sorted([dict(owner=k,pages=len(v),nonadditive_page_bytes=len(v)*page) for k,v in covered.items()],key=lambda x:x['pages'],reverse=True)
  results.append(dict(source_commit=report['source_commit'],file=case['file'],executable_sha256=report['executable_sha256'],resident_executable_page_bytes=len(present)*page,coverage=groups[:30]))
record=dict(scope='unscored-symbol-page-coverage',interpretation='Namespaces may share pages or alias symbols; byte coverage is nonadditive. Present pages include readahead and do not prove execution. Local sampled maxima are not CI or endpoint scores.',results=results)
(BASE/'code-page-coverage.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
