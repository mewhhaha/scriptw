"""Compare exact Git-tree compiler inputs with captured CI/local identities."""
import hashlib,json,re,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
ROOTS=['Cargo.toml','Cargo.lock','crates/scriptw-front','crates/scriptw-ir','crates/scriptw-aot-wasm','crates/scriptw-runtime','crates/scriptw-runtime-image','crates/scriptw-intl','crates/scriptw-intl-build-data','crates/scriptw-engine/Cargo.toml','crates/scriptw-engine/src','crates/scriptw-engine/build.rs','crates/scriptw-engine/compiler_fingerprint.rs','vendor']
def one(args):return subprocess.check_output(args,cwd=ROOT)
def fingerprint(revision,extra=False):
 source=one(['git','show',revision+':crates/scriptw-engine/compiler_fingerprint.rs']).decode()
 block=source.split('const TEST_ONLY_INPUTS: &[&str] = &[',1)[1].split('];',1)[0]
 excluded=re.findall(r'^\s*"([^"]+)",',block,re.M)
 items=[]
 for raw in one(['git','ls-tree','-r','-z',revision,'--',*ROOTS]).split(b'\0'):
  if not raw:continue
  fields,path=raw.split(b'\t',1);mode,kind,oid=fields.decode().split();path=path.decode()
  if any(path==x or path.startswith(x+'/') for x in excluded):continue
  assert kind=='blob' and mode=='100644',(mode,kind,path)
  items.append((path,oid))
 if extra:items.append(('vendor/regress-0.10.5/Cargo.lock',None))
 digest=hashlib.sha256(b'scriptw-program-cache-compiler-v3');total=0
 child=subprocess.Popen(['git','cat-file','--batch'],cwd=ROOT,stdin=subprocess.PIPE,stdout=subprocess.PIPE)
 try:
  for path,oid in sorted(items,key=lambda x:tuple(x[0].split('/'))):
   if oid is None:data=(ROOT/path).read_bytes()
   else:
    child.stdin.write((oid+'\n').encode());child.stdin.flush();header=child.stdout.readline().split();assert header[:2]==[oid.encode(),b'blob'];length=int(header[2]);data=child.stdout.read(length);assert len(data)==length and child.stdout.read(1)==b'\n'
   label=path.encode();digest.update(len(label).to_bytes(8,'little'));digest.update(label);digest.update(len(data).to_bytes(8,'little'));digest.update(data);total+=len(data)
 finally:child.stdin.close();child.stdout.close();assert child.wait()==0
 return dict(revision=one(['git','rev-parse',revision]).decode().strip(),extra_ignored_regress_lock=extra,source_fingerprint=digest.hexdigest(),files=len(items),bytes=total)
rows=[fingerprint(rev,extra) for rev in ['99a4ff2e9','7e02a8707','a68ee71ea','d0926cf6c'] for extra in [False,True]]
(OUT/'source-bindings-computed.json').write_text(json.dumps(rows,indent=2)+'\n')
ci99=json.loads((ROOT/'target/memory-scriptc-lazy-20261026/github-40411932915/precompiled-evidence/report.json').read_text())
ci7=json.loads((OUT/'github-40422593194/precompiled-evidence/report.json').read_text())
local=json.loads((OUT/'mapping-diagnostic-99/identity.stdout').read_text())
assert rows[0]['source_fingerprint']==ci99['source_fingerprint']
assert rows[1]['source_fingerprint']==local['source_fingerprint']
assert rows[2]['source_fingerprint']==rows[4]['source_fingerprint']==rows[6]['source_fingerprint']==ci7['source_fingerprint']
assert rows[3]['source_fingerprint']==rows[5]['source_fingerprint']==rows[7]['source_fingerprint']
lock=ROOT/'vendor/regress-0.10.5/Cargo.lock'
report=dict(verified=True,scheme='scriptw-program-cache-compiler-v3',inputs=ROOTS,rows=rows,ignored_extra=dict(path=str(lock.relative_to(ROOT)),bytes=lock.stat().st_size,sha256=hashlib.sha256(lock.read_bytes()).hexdigest()),interpretation='Exact clean Git production inputs bind measured7e02 and local a68/d092 checkpoints to the same compiler fingerprint. Local builds conservatively also hash an ignored standalone dependency lock; this identity difference is explicit and is not a scored CI sample.')
(OUT/'source-bindings.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
