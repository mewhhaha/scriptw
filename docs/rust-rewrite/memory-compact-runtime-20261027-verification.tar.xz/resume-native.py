"""Build affected scopes together, then verify exact native inventories serially."""
from datetime import datetime,timezone
import hashlib,json,os,re,shutil,subprocess,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'scripts'))
from limited_verification import require_kernel_budget,kernel_group
from native_test_protocol import parse_inventory,result_summaries
require_kernel_budget(4*1024**3);assert len(os.sched_getaffinity(0))==1
SOURCE=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
OUT=BASE/'native-final';OUT.mkdir(exist_ok=False)
BUILD=ROOT/'target/performance-work-20261024/build'
PLAN=[('scriptw-aot-wasm','scriptw_aot_wasm','lib'),('scriptw-aot-wasm','runtime_link','test'),('scriptw-aot-wasm','structure_builtins','test'),('scriptw-aot-wasm','structure_language','test'),('scriptw-engine','scriptw_engine','lib')]
PLAN += [('scriptw-engine',name,'test') for name in ['aot_builtins','aot_gc_entries','aot_realm_modules','aot_language','aot_async','aot_generators','aot_regexp','aot_intl','aot_temporal','structure']]
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def stamp():return datetime.now(timezone.utc).isoformat()
group=kernel_group()
def budget():return {k:(group/k).read_text().strip() for k in ['memory.max','memory.swap.max','memory.oom.group','memory.peak','memory.events']}
report=dict(source_commit=SOURCE,complete=False,started_at=stamp(),cpu_affinity=sorted(os.sched_getaffinity(0)),before=budget(),commands=[],scopes=[])
def save():(OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n')
def source():
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==SOURCE
 assert not subprocess.check_output(['git','diff','--binary','HEAD','--','crates','vendor','scripts','Cargo.toml','Cargo.lock'],cwd=ROOT)
def run(label,args,cwd=ROOT):
 source();row=dict(label=label,command=list(map(str,args)),cwd=str(cwd),started_at=stamp(),stdout=label+'.stdout',stderr=label+'.stderr')
 report['commands'].append(row);save();print(label,'started',flush=True);start=time.monotonic()
 with (OUT/row['stdout']).open('xb') as out,(OUT/row['stderr']).open('xb') as err:
  child=subprocess.run(row['command'],cwd=cwd,stdout=out,stderr=err,timeout=3600)
 row.update(exit_code=child.returncode,seconds=time.monotonic()-start,stdout_sha256=sha(OUT/row['stdout']),stderr_sha256=sha(OUT/row['stderr']));save()
 assert child.returncode==0,label+' failed; original streams retained'
 return (OUT/row['stdout']).read_text()
previous=BASE/'native-fixed'
old=json.loads((previous/'report.json').read_text());assert old['source_commit']==SOURCE
build=next(x for x in old['commands'] if x['label']=='cargo-native')
assert build['exit_code']==0 and sha(previous/build['stdout'])==build['stdout_sha256'] and sha(previous/build['stderr'])==build['stderr_sha256']
cargo=[json.loads(x) for x in (previous/build['stdout']).read_text().splitlines()]
assert cargo[-1]==dict(reason='build-finished',success=True)
report['build_provenance']=dict(report='native-fixed/report.json',report_sha256=sha(previous/'report.json'),cargo_command=build)
save()
for package,name,kind in PLAN:
 if name=='scriptw_aot_wasm':
  scope=old['scopes'][0];assert scope['target']==name and scope['kind']==kind
  command=next(x for x in old['commands'] if x['label']==package+'-'+name+'-part-000')
  assert command['exit_code']==0
  raw=(previous/command['stdout']).read_text()
  assert sha(previous/command['stdout'])==command['stdout_sha256'] and sha(previous/command['stderr'])==command['stderr_sha256']
  actual=[n.removesuffix(' - should panic') for n in re.findall(r'^test ([^\r\n]+) \.\.\. ok$',raw,re.M)]
  inventory=scope['inventory'];assert len(actual)==len(inventory) and set(actual)==set(inventory)
  assert result_summaries(raw)==[('ok',str(len(inventory)),'0','0','0','0')]
  assert sha(Path(scope['cargo_producer']['executable']))==scope['executable_sha256']
  complete=dict(scope,complete=True,passed=len(inventory),inherited_evidence=dict(report='native-fixed/report.json',report_sha256=sha(previous/'report.json'),command=command,parser_correction='Strip the cosmetic libtest - should panic suffix; all489 cases passed originally. No rerun or altered test result.'))
  report['scopes'].append(complete);save();print(package,name,len(inventory),'existing passes verified',flush=True);continue
 producers=[r for r in cargo if r.get('reason')=='compiler-artifact' and r.get('executable') and r['target']['name']==name and r['target']['kind']==[kind] and r['profile']['test']]
 assert len(producers)==1,(package,name)
 producer=producers[0];original=Path(producer['executable']);folder=OUT/(package+'-'+name);folder.mkdir()
 binary=folder/'tests';shutil.copy2(original,binary);assert sha(binary)==sha(original) and binary.stat().st_nlink==1
 scope=dict(package=package,target=name,kind=kind,executable_sha256=sha(binary),cargo_producer=producer,complete=False)
 report['scopes'].append(scope);save()
 inventory=parse_inventory(run(package+'-'+name+'-inventory',[binary,'--list'],ROOT/'crates'/package));scope['inventory']=inventory;save()
 chunks=[inventory[i:i+8] for i in range(0,len(inventory),8)] if name=='scriptw_engine' else [inventory]
 passed=set()
 for index,chunk in enumerate(chunks):
  label=package+'-'+name+f'-part-{index:03d}'
  # Explicit exact names allow small processes without reducing scope or skipping ignored cases.
  text=run(label,[binary,'--exact','--include-ignored','--test-threads=1',*chunk],ROOT/'crates'/package)
  names=[n.removesuffix(' - should panic') for n in re.findall(r'^test ([^\r\n]+) \.\.\. ok$',text,re.M)]
  assert len(names)==len(chunk) and set(names)==set(chunk) and not passed.intersection(names),(label,names,chunk)
  assert result_summaries(text)==[('ok',str(len(chunk)),'0','0','0',str(len(inventory)-len(chunk)))],label
  passed.update(names);scope['passed']=len(passed);save()
 assert passed==set(inventory) and sha(binary)==scope['executable_sha256']
 scope['complete']=True;save();print(package,name,len(passed),'passed',flush=True)
report.update(complete=True,finished_at=stamp(),after=budget(),passed_disjoint_scopes=sum(x['passed'] for x in report['scopes']));save()
print('complete',report['passed_disjoint_scopes'],'native cases',flush=True)
