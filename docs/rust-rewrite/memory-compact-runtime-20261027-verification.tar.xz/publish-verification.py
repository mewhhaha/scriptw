"""Retain the complete source-bound compact-runtime checkpoint without native code."""
from datetime import datetime,timezone
import hashlib,json,lzma,re,tarfile
from pathlib import Path,PurePosixPath
BASE=Path(__file__).resolve().parent;ROOT=BASE.parents[1];DEST=ROOT/'docs/rust-rewrite'
STEM='memory-compact-runtime-20261027'
def read(p):return json.loads(p.read_text())
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
native=read(BASE/'native-final/report.json');batch=read(BASE/'completed-batch-report.json');conf=read(BASE/'conformance/report.json');bindings=read(BASE/'source-bindings.json')
source='d0926cf6c'
assert all(x['complete'] and x['source_commit'].startswith(source) for x in [native,batch,conf])
assert bindings['verified'] and len(native['scopes'])==15
assert conf['passed']==conf['total']>0 and all(x['returncode']==0 for x in conf['commands'])
assert conf['compiler']['identity']['source_fingerprint']==bindings['rows'][7]['source_fingerprint']
assert all(s['complete'] and s['passed']==len(s['inventory']) for s in native['scopes'])
assert native['passed_disjoint_scopes']==sum(s['passed'] for s in native['scopes'])
assert all(x['exit_code']==0 for x in batch['commands'])
prior=read(BASE/'batch-report-final.json');assert next(x for x in prior['commands'] if x['label']=='cargo-check-fixed')['exit_code']==0
vendor=(BASE/'vendor-reclamation-fixed.stdout').read_text();assert re.findall(r'^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',vendor,re.M)==[('4','0','0','0','112')]
for record in [native,batch,conf]:
 for moment in ['before','after']:
  budget=record[moment];assert budget['memory.max']=='4294967296' and budget['memory.swap.max']=='0' and budget['memory.oom.group']=='1'
 for key in ['oom','oom_kill','oom_group_kill']:
  def count(moment):return dict(line.split() for line in record[moment]['memory.events'].splitlines())[key]
  assert count('before')==count('after')
# Retain the sole ignored non-production dependency lock that explains the local identity.
provenance=BASE/'provenance';provenance.mkdir(exist_ok=True)
lock=ROOT/bindings['ignored_extra']['path'];assert sha(lock)==bindings['ignored_extra']['sha256']
(provenance/'ignored-regress-Cargo.lock').write_bytes(lock.read_bytes())
files=[]
for p in sorted(BASE.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(BASE).as_posix();parts=PurePosixPath(rel).parts
 if parts[0].startswith('github-') or 'images' in parts or p.name in ['publication.stdout','publication.stderr']:continue
 if p.suffix not in ['.py','.json','.jsonl','.stdout','.stderr','.smaps','.txt','.lock','.js'] and p.name!='executions':continue
 assert not p.is_symlink() and p.stat().st_size<=128*1024**2
 assert '..' not in parts and not PurePosixPath(rel).is_absolute()
 with p.open('rb') as f:assert not f.read(8).startswith((b'\x7fELF',b'MZ',b'SCRWEP01',b'SCRWEP02',b'SCRWWA01'))
 files.append(dict(path=rel,bytes=p.stat().st_size,sha256=sha(p)))
expanded=sum(x['bytes'] for x in files);assert expanded<=2*1024**3
archive=DEST/(STEM+'-verification.tar.xz');assert not archive.exists()
with archive.open('xb') as f,lzma.LZMAFile(f,'w',format=lzma.FORMAT_XZ,filters=[dict(id=lzma.FILTER_LZMA2,preset=1,dict_size=64*1024**2)]) as compressed:
 with tarfile.open(fileobj=compressed,mode='w|',format=tarfile.PAX_FORMAT) as tar:
  for row in files:
   info=tarfile.TarInfo(row['path']);info.size=row['bytes'];info.mode=0o644
   with (BASE/row['path']).open('rb') as data:tar.addfile(info,data)
assert archive.stat().st_size<=32*1024**2
record=dict(schema='scriptw-compact-runtime-memory-verification-v1',recorded_at=datetime.now(timezone.utc).isoformat(),verified_source_commit=native['source_commit'],measured_source_commit='7e02a8707b26468868ec939ade9cc10e12cfc3e3',source_bindings=bindings,native=native,test262=conf,collector_controls=4,
 checkpoints=dict(typecheck=prior,completed=batch),
 interpretation='Selected exact source-bound verification, not a full pinned-suite refresh. Measured7e02 and test-only correction commits share exact clean production compiler inputs. Local builds additionally fingerprint the retained ignored standalone regress lock. Mapping diagnostics are unscored; original fork-before-exec maxima are rejected and preserved. All failed attempts remain retained. No executable or native image is archived.',
 archive=dict(file=archive.name,sha256=sha(archive),bytes=archive.stat().st_size,expanded_bytes=expanded,member_count=len(files),max_expanded_bytes=2*1024**3,max_member_bytes=128*1024**2),retained_files=files)
p=DEST/(STEM+'.json');assert not p.exists();p.write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(dict(native=native['passed_disjoint_scopes'],test262=conf['total'],collector_controls=4,archive=record['archive']),indent=2))
