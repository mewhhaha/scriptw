# Exact test-only recovery and final staging

Measured production source stays `source-initial/manifest.json` (`6ea9b49f…`). Products, the24-process RSC cohort,504-process situation matrix,120-process paired retention check, and four integration scopes keep that source/binary identity. Their receipts are never rewritten to the later delivered source.

The first full Engine unit run remains1092 passed/1 failed. The authorized correction adds only `scriptw_host::report_cleanup_exception` to one expected-import list in `src/tests/execution.rs`. This path is explicitly excluded by unchanged `TEST_ONLY_INPUTS`; native compiler inputs do not include it. The original1092 passing test names and the one corrected targeted pass form a disjoint `qualified_union`, not an all-green full-unit rerun. The failed original stdout remains archived.

After the native owner records the real corrected producer and one-test command row, build the qualification receipt without running any test:

```sh
pilot=target/performance-v8-climb-20261104/fiber-only
python3 -B "$pilot/qualify_recovery.py" \
  --measured-source "$pilot/source-initial/manifest.json" \
  --delivered-source "$pilot/source-corrected-2/manifest.json" \
  --failed-broad "$pilot/broad-1/native-verification.json" \
  --integrations "$pilot/broad-integrations-1/native-verification.json" \
  --corrected-cargo-stdout "$pilot/recovery-1/cargo.stdout" \
  --corrected-cargo-stderr "$pilot/recovery-1/cargo.stderr" \
  --corrected-binary "$pilot/recovery-1/frozen/scriptw_engine" \
  --recovered-stdout "$pilot/recovery-1/recovered.stdout" \
  --recovered-stderr "$pilot/recovery-1/recovered.stderr" \
  --recovery-receipt "$pilot/recovery-1/command-receipt.json" \
  --output "$pilot/qualification-1"
```

The helper requires actual exit/argv/timing/source/binary metadata, parses actual logs, validates the sole source literal change, and copies no fabricated green result over a failed receipt. It compares original names/inventory and the exact corrected test. Current qualification retains five fresh Engine scopes and nine historical AOT/emission/structural/IR scopes, preserving653AOT passes/4failures,67emission,637structural and769IR.

Final publisher inputs use the qualification file plus both source roles:

```sh
python3 -B scripts/limited_verification.py -- python3 -B "$pilot/publish.py" \
  --source "$pilot/source-initial/manifest.json" \
  --delivered-source "$pilot/source-corrected-2/manifest.json" \
  --source-equivalence "$pilot/qualification-1/source-equivalence.json" \
  --native-report "$pilot/qualification-1/native-verification.json" \
  --products-receipt "$pilot/products-1/receipt.json" \
  --situations "$pilot/situations-1" --rsc "$pilot/rsc-pilot-1" \
  --source-guards "$pilot/source-guards.stdout" --date 2026-11-05 \
  --extra-text-evidence "$pilot/paired-retention" \
  --extra-text-evidence "$pilot/reuse-046c-1" \
  --extra-text-evidence "$pilot/cli-delivery-1" \
  --extra-text-evidence "$pilot/source-corrected-1" \
  --output "$pilot/publication-1"
```

Append the JSON argv array in `rejected-publication-args.json` for the exact10 minimal rejected decision/source/pilot/paired text files. Optionally append `--rejected-text "$pilot/rejected-text/source-bindings.json"`. If the one-process Speed P diagnostic completes or fails, archive its actual `speed-rsc-probe-1` folder as `--extra-text-evidence`; it stays unscored and outside Fast charts. Use actual smoke/probe directory names if the owner selects another attempt. Do not include any prior allocation/PMU as current flags.

Run `check_publication.py --stage "$pilot/publication-1"` under the limiter before root copies anything. Root alone copies/reviews/renders/pushes. Four unrelated README published blocks and pinned Test262 files stay byte-identical. README should show current Engine counts with the unit recovery footnote and separately dated reused scopes; allocation/PMU and unrefreshed size panels remain recorded baseline. No before/after change narrative is added to README.
