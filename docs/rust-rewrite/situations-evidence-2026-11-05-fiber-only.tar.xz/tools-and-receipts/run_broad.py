"""Run fresh Engine scopes after retention; reuse independently qualified AOT/IR scopes."""
import argparse
from datetime import datetime, timezone
from pathlib import Path
import re
import shutil
import subprocess
import time
from common import ROOT, artifacts, check_source, read, save, sha

STRUCTURAL = ('structure_language', 'modules_realms', 'runtime_link', 'structure_builtins', 'structure_async', 'intl_temporal')
ENGINE = ('aot_language', 'aot_builtins', 'aot_async', 'aot_realm_modules')
SUMMARY = re.compile(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;')


def failures(text):
    if '\nfailures:\n' not in text:
        return set()
    tail = text.rsplit('\nfailures:\n', 1)[1].split('\ntest result:', 1)[0]
    return set(re.findall(r'^    (\S+)\s*$', tail, re.M))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--focused-producer', type=Path, required=True)
    parser.add_argument('--pilot', type=Path, required=True, help='completed aggregate.json')
    parser.add_argument('--pilot-retained', action='store_true', required=True, help='root retained the measured prototype')
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--reuse-proof', type=Path, required=True)
    parser.add_argument('--target', action='append', default=[], help='explicit remaining target subset after a preserved failure')
    args = parser.parse_args()
    source = args.source.resolve(strict=True)
    source_sha = sha(source)
    check_source(source)
    pilot = read(args.pilot)
    assert pilot['source_identity']['candidate_measured_source']['manifest_sha256'] == source_sha
    campaign = ROOT / pilot['measurement']['campaign']
    assert sha(campaign) == pilot['measurement']['campaign_sha256']
    assert read(campaign)['status'] == 'complete'
    focused = read(args.focused_producer)
    assert focused['complete'] and focused['source_manifest_sha256'] == source_sha
    assert focused['phase'] in ('adopt-focused', 'focused-build')
    inherited = {row['artifact']['target']['name']: row for row in focused['artifacts']}
    assert {'scriptw_engine', *ENGINE} <= inherited.keys()
    from qualify_reuse import validate_reuse
    reuse = validate_reuse(read(args.reuse_proof), source_sha)
    known = next(row for row in reuse['original_scopes'] if row['target'] == 'scriptw_aot_wasm')
    output = args.output.resolve()
    assert output.is_relative_to(ROOT / 'target') and not output.exists()
    output.mkdir(parents=True)
    (output / 'frozen').mkdir()
    all_targets = ('scriptw_engine', *ENGINE)
    targets = list(all_targets)
    if args.target:
        assert set(args.target) <= set(all_targets) and len(set(args.target)) == len(args.target)
        targets = [target for target in all_targets if target in args.target]
    report = dict(schema='scriptw-fiber-only-native-v1', complete=False,
        source_manifest_sha256=source_sha, scopes=[], producer_commands=[], artifacts=[], inventories={},
        selected_targets=targets, full_native_target_set_complete=False,
        pilot=dict(path=str(args.pilot.resolve()), sha256=sha(args.pilot), root_retained=True),
        inherited_producer=dict(path=str(args.focused_producer.resolve()), sha256=sha(args.focused_producer)),
        reused_native=reuse['original_scopes'], reuse_proof=dict(path=str(args.reuse_proof.resolve()), sha256=sha(args.reuse_proof)),
        known_preexisting_aot_failures=dict(names=known['failures'], original_scope=known),
        limits='Fresh Engine counts come from actual binary inventories. Focused cases overlap full Engine suites. Qualified AOT/emission/structural/IR scopes remain historical reuse with original source and binary identities; four AOT failures stay failed. Pinned Test262 was not rerun.',
        started_at=datetime.now(timezone.utc).isoformat())

    def persist():
        save(output / 'native-verification.json', report)

    def run(label, argv, target=None, expected=None):
        check_source(source)
        capped = ['python3', '-B', str(ROOT / 'scripts/limited_verification.py'), '--', *map(str, argv)]
        out, err = output / (label + '.stdout'), output / (label + '.stderr')
        print('START', label, flush=True)
        start = time.monotonic_ns()
        timed_out = False
        with out.open('xb') as stdout, err.open('xb') as stderr:
            try:
                child = subprocess.run(capped, cwd=ROOT, stdout=stdout, stderr=stderr, timeout=7200)
                code = child.returncode
            except subprocess.TimeoutExpired:
                timed_out, code = True, None
        row = dict(label=label, argv=list(map(str, argv)), capped_argv=capped, exit_code=code, timed_out=timed_out,
            elapsed_ns=time.monotonic_ns() - start, source_manifest_sha256=source_sha,
            stdout=str(out), stderr=str(err), stdout_sha256=sha(out), stderr_sha256=sha(err))
        if target:
            package = 'scriptw-aot-wasm'
            if target in ENGINE or target == 'scriptw_engine':
                package = 'scriptw-engine'
            row.update(package=package, target=target, executable_sha256=sha(argv[0]))
            report['scopes'].append(row)
            persist()
            summary = SUMMARY.findall(out.read_text())
            assert len(summary) == 1, 'missing/ambiguous test result: ' + target
            state, passed, failed, ignored = summary[0]
            row['outcomes'] = dict(state=state, passed=int(passed), failed=int(failed), ignored=int(ignored))
            persist()
            assert int(passed) + int(failed) == expected and int(ignored) == 0
            assert code == 0 and state == 'ok' and int(failed) == 0
        else:
            report['producer_commands'].append(row)
            persist()
            assert code == 0
        assert not timed_out
        check_source(source)
        print('END', label, code, flush=True)
        return out

    def freeze(artifact, original, authority):
        assert artifact['profile']['test'] is True
        binary = Path(original)
        destination = output / 'frozen' / artifact['target']['name']
        expected = sha(binary)
        shutil.copy2(binary, destination)
        assert sha(destination) == sha(binary) == expected
        row = dict(artifact=artifact, frozen_path=str(destination), executable_sha256=expected,
            source_manifest_sha256=source_sha, authority=authority, bytes=destination.stat().st_size)
        report['artifacts'].append(row)
        persist()
        return destination

    persist()
    binaries = {}
    for target in targets:
        row = inherited[target]
        assert sha(row['frozen_path']) == row['sha256']
        binaries[target] = freeze(row['artifact'], row['frozen_path'], dict(focused_producer_sha256=sha(args.focused_producer)))
    for target in targets:
        binary = binaries[target]
        log = run('inventory-' + target, [binary, '--list', '--format', 'terse'])
        names = [line.removesuffix(': test') for line in log.read_text().splitlines() if line.endswith(': test')]
        assert names and len(set(names)) == len(names)
        report['inventories'][target] = dict(tests=names, count=len(names), executable_sha256=sha(binary))
        persist()
        run(target, [binary, '--test-threads=1'], target=target, expected=len(names))
    report.update(complete=True, full_native_target_set_complete=set(targets) == set(all_targets),
        finished_at=datetime.now(timezone.utc).isoformat())
    persist()
    print('FRESH ENGINE COMPLETE; QUALIFIED AOT/IR REUSE RETAINED', output / 'native-verification.json', flush=True)


if __name__ == '__main__':
    main()
