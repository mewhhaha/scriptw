"""One bounded unscored Speed/Backtracking RSC P diagnostic; no build or retry."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import sys
import time
from common import BASE, ROOT, check_source, read, save, sha

sys.path.insert(0, str(ROOT / 'scripts'))
from benchmark_metrics import measure_process
from limited_verification import kernel_group, limited_environment, require_kernel_budget


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--binary', type=Path, default=BASE / 'products-1/frozen/rsc_baseline')
    parser.add_argument('--reference', type=Path, default=BASE / 'rsc-pilot-1/block-0-0-candidate/report.json')
    parser.add_argument('--time', type=Path, default=ROOT / 'target/performance-worker-cpu/tools/time')
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    require_kernel_budget(4 * 1024**3)
    assert len(os.sched_getaffinity(0)) == 1
    check_source(args.source)
    reference = read(args.reference)
    assert reference['status'] == 'complete' and reference['native_mode'] == 'fast'
    assert sha(args.binary) == reference['executable_sha256']
    producer = read(args.binary.parent / (args.binary.name + '-producer.json'))
    assert producer['source_manifest_sha256'] == sha(args.source) and producer['artifact']['profile']['test'] is False
    source, support = (Path(reference['inputs'][field]) for field in ('source', 'support'))
    assert sha(source) == reference['inputs']['source_sha256'] and sha(support) == reference['inputs']['support_sha256']
    output = args.output.resolve()
    assert output.is_relative_to(ROOT / 'target') and not output.exists()
    output.mkdir(parents=True)
    (output / 'tmp').mkdir()
    report_path = output / 'report.json'
    argv = [str(args.binary.resolve()), str(source), str(support), str(report_path), '7', '3', 'speed']
    before = {name: (kernel_group() / name).read_text().strip() for name in ('memory.max', 'memory.swap.max', 'memory.oom.group', 'cpu.max', 'memory.events')}
    receipt = dict(schema='scriptw-unscored-speed-rsc-probe-v1', status='incomplete', excluded_from_scored_cohorts=True,
        source_manifest_sha256=sha(args.source), argv=argv, reference=dict(path=str(args.reference), sha256=sha(args.reference)),
        inputs={str(path): dict(sha256=sha(path), bytes=path.stat().st_size) for path in (source, support, args.binary, args.time)},
        tooling_sha256=sha(__file__), resources_before=before, warmups=3, samples=7, process_count=1,
        limits='One unscored Speed/Backtracking P process only. R remains the existing optimized runtime. Not part of Fast current charts or balanced comparison; no robust speedup claim.')
    save(output / 'plan.json', receipt)
    environment = limited_environment()
    assert not any(key.startswith('SCRIPTW_RSC_PROFILE_') for key in environment)
    assert not any(environment.get(key) for key in ('LD_PRELOAD', 'LD_AUDIT'))
    environment.update(TMPDIR=str(output / 'tmp'), SCRIPTW_CACHE_DIR=str(output / 'tmp/cache'), SCRIPTW_JOBS='1')
    started = time.monotonic_ns()
    try:
        with (output / 'stdout').open('xb') as out, (output / 'stderr').open('xb') as err:
            receipt['accounting'] = measure_process(argv, cwd=ROOT, env=environment, stdout=out, stderr=err,
                timeout=180, time_binary=args.time)
        assert receipt['accounting']['exit_code'] == 0 and not receipt['accounting']['timed_out']
        raw = read(report_path)
        assert raw == read(output / 'stdout') and not (output / 'stderr').read_bytes()
        assert raw['status'] == 'complete' and raw['native_mode'] == 'speed' and 'profiling' not in raw
        for field in ('executable_sha256', 'source_fingerprint', 'source_commit', 'compiler_identity_scheme', 'toolchain', 'inputs', 'program_wasm_sha256', 'runtime'):
            assert raw[field] == reference[field], field
        expected_configuration = dict(reference['configuration'], cranelift_opt_level='Speed', register_allocation='Backtracking')
        assert raw['configuration'] == expected_configuration
        assert [case['case'] for case in raw['cases']] == ['rsc-sync', 'rsc-async']
        goldens = read(support)['expected']
        for case in raw['cases']:
            expected = goldens[case['case']].removesuffix('\n').encode()
            assert case['warmups'] == 3 and case['samples'] == 7 and len(case['observations']) == 10
            assert case['exact_node_output_checked'] is True
            assert case['expected_json_sha256'] == hashlib.sha256(expected).hexdigest() and case['expected_json_bytes'] == len(expected)
        receipt.update(status='complete', checked_invocations=20, observed_configuration=raw['configuration'], native_mode_scope=raw['native_mode_scope'])
        check_source(args.source)
    except BaseException as error:
        receipt.update(status='failed', error=repr(error))
        raise
    finally:
        receipt['elapsed_ns'] = time.monotonic_ns() - started
        receipt['resources_after'] = {name: (kernel_group() / name).read_text().strip() for name in before}
        receipt['retained_files'] = {path.name: dict(sha256=sha(path), bytes=path.stat().st_size) for path in output.iterdir() if path.is_file()}
        save(output / 'receipt.json', receipt)
    print('ONE UNSCORED SPEED P PROBE COMPLETE', output / 'receipt.json')


if __name__ == '__main__':
    main()
