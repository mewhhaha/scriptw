import json,subprocess,sys,time,shutil,re
from pathlib import Path
b=Path('target/performance-v8-climb-20261104/fiber-only').resolve();sys.path.insert(0,str(b));from common import check_source,sha,save,artifacts
source=b/'source-corrected-2/manifest.json';check_source(source)
out=b/'recovery-1';out.mkdir();rows=[]
def run(label,args,executable=None):
 check_source(source);print('START',label,flush=True);command=['python3','-B','scripts/limited_verification.py','--',*map(str,args)];start=time.monotonic_ns()
 stdout=out/(label+'.stdout');stderr=out/(label+'.stderr')
 with stdout.open('xb') as so,stderr.open('xb') as se:r=subprocess.run(command,stdout=so,stderr=se)
 row=dict(label=label,argv=list(map(str,args)),capped_argv=command,exit_code=r.returncode,timed_out=False,elapsed_ns=time.monotonic_ns()-start,source_manifest_sha256=sha(source),stdout=str(stdout),stderr=str(stderr),stdout_sha256=sha(stdout),stderr_sha256=sha(stderr))
 if executable:row['executable_sha256']=sha(executable)
 rows.append(row);save(out/'commands.json',rows)
 if label=='recovered':save(out/'command-receipt.json',row)
 print('END',label,r.returncode,flush=True);assert r.returncode==0,label;check_source(source);return stdout
run('fmt',['rustfmt','--edition','2021','--check','crates/scriptw-engine/src/tests/execution.rs'])
log=run('cargo',['cargo','--config','build.jobs=1','test','--release','--locked','-p','scriptw-engine','--lib','--no-run','--message-format=json-render-diagnostics'])
selected=[r for r in artifacts(log) if r['target']['name']=='scriptw_engine' and r['profile']['test'] is True];assert len(selected)==1
artifact=selected[0];binary=Path(artifact['executable']);(out/'frozen').mkdir();frozen=out/'frozen/scriptw_engine';shutil.copy2(binary,frozen);assert sha(binary)==sha(frozen)
reference=json.loads((b/'rsc-pilot-1/block-0-0-candidate/report.json').read_text())
envs=[]
for l in log.read_text().splitlines():
 r=json.loads(l)
 if r.get('reason')=='build-script-executed':envs.extend(r.get('env',[]))
fp={value for name,value in envs if name=='SCRIPTW_COMPILER_FINGERPRINT'};assert fp=={reference['source_fingerprint']},fp
save(out/'producer.json',dict(artifact=artifact,sha256=sha(frozen),frozen_path=str(frozen),source_manifest_sha256=sha(source),cargo_stdout_sha256=sha(log),unchanged_production_compiler_fingerprint=reference['source_fingerprint']))
inv=run('corrected-inventory',[frozen,'--list','--format','terse'],frozen);names=[line.removesuffix(': test') for line in inv.read_text().splitlines() if line.endswith(': test')]
old=json.loads((b/'broad-1/native-verification.json').read_text())['inventories']['scriptw_engine']['tests'];assert names==old
name='tests::execution::wasm_backend_characterization_matrix_locks_public_surface_and_outcomes'
result=run('recovered',[frozen,name,'--exact','--test-threads=1'],frozen)
assert re.search(r'test result: ok\. 1 passed; 0 failed; 0 ignored; 0 measured; 1092 filtered out;',result.read_text())
save(out/'receipt.json',dict(complete=True,source_manifest_sha256=sha(source),commands=rows,inventory_count=len(names),unchanged_production_compiler_fingerprint=reference['source_fingerprint'],original_failed_scope=str(b/'broad-1/native-verification.json')))
print('UNIT-ONLY RECOVERY COMPLETE',flush=True)
