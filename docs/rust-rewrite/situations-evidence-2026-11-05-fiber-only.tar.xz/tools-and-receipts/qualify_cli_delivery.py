import json,re,sys
from pathlib import Path
b=Path('target/performance-v8-climb-20261104/fiber-only').resolve();sys.path.insert(0,str(b))
from common import check_source,read,save,sha
source=b/'source-corrected-2/manifest.json';check_source(source)
out=b/'cli-delivery-1';old=read(out/'receipt.json')
assert old['exit_code']==0 and not old['timed_out']
for field in ('stdout','stderr'):assert old[field+'_sha256']==sha(out/field)
binary=Path(old['argv'][0]);assert sha(binary)==old['executable_sha256']
contract=Path('crates/scriptw-cli/tests/product_artifact_execution.rs')
match=re.search(r'const WASM_COMPLETION: &str = (".*");',contract.read_text())
completion=json.loads(match[1]);expected='grug\n'+completion
assert (out/'stdout').read_text()==expected
wrapper='limited-verification: confirmed kernel memory cap 4096 MiB, swap 0, one CPU and serial worker defaults; retained module cache 1 entry / 67108864 image bytes\n'
assert (out/'stderr').read_text()==wrapper
assert sha(old['fixture_path'])==old['fixture_sha256']
check_source(source)
save(out/'qualified-receipt.json',dict(schema='scriptw-fiber-cli-delivery-qualified-transcript-v1',complete=True,original_command_receipt=dict(path=str(out/'receipt.json'),sha256=sha(out/'receipt.json')),command=old,expected_stdout=expected,expected_stderr=wrapper,contract=dict(path=str(contract),sha256=sha(contract)),program_stdout='grug\n',backend='WasmAot',actual_process_rerun=False,limits='Original command succeeded; original ignored-helper assertion failure is retained. Actual transcript is checked against existing CLI completion contract. Wrapper diagnostic is the entire captured stderr.'))
print('CLI DELIVERY ACTUAL TRANSCRIPT QUALIFIED; ORIGINAL ASSERTION FAILURE RETAINED',out/'qualified-receipt.json')
