"""Bind checkpoint046c AOT/structural/IR receipts to unchanged relevant source."""
import argparse
import copy
import hashlib
import json
from pathlib import Path
import shutil
import tomllib
from common import BASE_GIT, ROOT, check_source, git, read, save, sha
from run_broad import STRUCTURAL, SUMMARY, failures

TARGETS = ('scriptw_aot_wasm', 'emission', *STRUCTURAL, 'scriptw_ir_integration')


def unchanged_inputs():
    # All local AOT/front/IR/runtime/Intl dependency source and tests are unchanged.
    changed = git('diff', '--name-only', 'HEAD', '--', 'crates').decode().splitlines()
    untracked = git('ls-files', '--others', '--exclude-standard', '--', 'crates').decode().splitlines()
    for path in (*changed, *untracked):
        assert path.startswith(('crates/scriptw-engine/', 'crates/scriptw-cli/')), 'AOT dependency/test input changed: ' + path
    policies = ('vendor', '.cargo', 'Cargo.toml', 'rust-toolchain', 'rust-toolchain.toml')
    assert not git('diff', '--name-only', 'HEAD', '--', *policies).strip()
    assert not git('ls-files', '--others', '--exclude-standard', '--', *policies).strip()
    old_lock = tomllib.loads(git('show', BASE_GIT + ':Cargo.lock').decode())
    new_lock = tomllib.loads((ROOT / 'Cargo.lock').read_text())
    assert [row for row in old_lock['package'] if row['name'] != 'scriptw-engine'] == [row for row in new_lock['package'] if row['name'] != 'scriptw-engine']
    old_engine = next(row for row in old_lock['package'] if row['name'] == 'scriptw-engine')
    new_engine = next(row for row in new_lock['package'] if row['name'] == 'scriptw-engine')
    assert {key: value for key, value in old_engine.items() if key != 'dependencies'} == {key: value for key, value in new_engine.items() if key != 'dependencies'}
    assert sorted(new_engine['dependencies']) == sorted([*old_engine['dependencies'], 'wasmtime-internal-fiber'])
    return dict(lockfile_sha256=sha(ROOT / 'Cargo.lock'), changed_crates=changed, untracked_crates=untracked, policies=list(policies))


def validate_reuse(proof, source_sha, delivered_source=None):
    assert proof['complete'] and proof['source_manifest_sha256'] == source_sha and proof['base_git'] == BASE_GIT
    assert sha(proof['source_manifest']) == source_sha
    current_source = proof['source_manifest']
    if delivered_source is not None:
        current_source = delivered_source
    check_source(current_source)
    witness = unchanged_inputs()
    assert witness['lockfile_sha256'] == proof['lockfile']['after_sha256']
    public_bytes = git('show', BASE_GIT + ':docs/rust-rewrite/situations-current.json')
    assert hashlib.sha256(public_bytes).hexdigest() == proof['baseline_public_report_sha256']
    original = json.loads(public_bytes)['publication']['coverage']['fresh_native']
    assert {row['target'] for row in proof['original_scopes']} == set(TARGETS)
    assert len(proof['original_scopes']) == len(TARGETS)
    for row in proof['original_scopes']:
        matches = [value for value in original if value['target'] == row['target']
                   and not any(not argument.startswith('-') for argument in value['argv'][1:])]
        assert len(matches) == 1
        for key, value in matches[0].items():
            if key == 'qualified_final_source_manifest_sha256':
                assert row['original_qualified_source_manifest_sha256'] == value
            else:
                assert row[key] == value, ('original reused identity/outcome changed', row['target'], key)
        assert row['qualified_final_source_manifest_sha256'] == source_sha and row['reused_unchanged_inputs'] is True
        for field in ('stdout', 'stderr'):
            retained = row['archived_' + field]
            assert sha(retained['path']) == row[field]['sha256'] == retained['sha256']
            assert Path(retained['path']).stat().st_size == row[field]['bytes'] == retained['bytes']
    return proof


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--preflight-issue', type=Path, action='append', default=[], help='retain an actual failed preflight transcript without counting it passing')
    args = parser.parse_args()
    source = args.source.resolve(strict=True)
    check_source(source)
    source_sha = sha(source)
    witness = unchanged_inputs()
    public_bytes = git('show', BASE_GIT + ':docs/rust-rewrite/situations-current.json')
    public = json.loads(public_bytes)
    coverage = public['publication']['coverage']
    scopes = []
    output = args.output.resolve()
    assert output.is_relative_to(ROOT / 'target') and not output.exists()
    output.mkdir(parents=True)
    (output / 'baseline-situations-current.json').write_bytes(public_bytes)
    for target in TARGETS:
        matches = [row for row in coverage['fresh_native'] if row['target'] == target
                   and not any(not value.startswith('-') for value in row['argv'][1:])]
        assert len(matches) == 1, 'ambiguous/missing complete prior target: ' + target
        row = copy.deepcopy(matches[0])
        for field in ('stdout', 'stderr'):
            original = ROOT / row[field]['path']
            assert sha(original) == row[field]['sha256'] and original.stat().st_size == row[field]['bytes']
            copied = output / (target + '.' + field)
            shutil.copy2(original, copied)
            assert sha(copied) == row[field]['sha256']
            row['archived_' + field] = dict(path=str(copied), sha256=sha(copied), bytes=copied.stat().st_size)
        summaries = SUMMARY.findall((output / (target + '.stdout')).read_text())
        assert len(summaries) == 1
        state, passed, failed, ignored = summaries[0]
        assert row['outcomes'] == dict(state=state, passed=int(passed), failed=int(failed), ignored=int(ignored))
        assert int(ignored) == 0
        if target == 'scriptw_aot_wasm':
            assert int(failed) == 4 and row['exit_code'] == 101
            assert failures((output / (target + '.stdout')).read_text()) == set(row['failures'])
        else:
            assert state == 'ok' and int(failed) == 0 and row['exit_code'] == 0
        row['original_qualified_source_manifest_sha256'] = row.get('qualified_final_source_manifest_sha256', row['source_manifest_sha256'])
        row.update(reused_unchanged_inputs=True, qualified_final_source_manifest_sha256=source_sha,
            qualification='Source/dependency proof in this receipt binds the prior scope to checkpoint046c plus Engine/CLI-only changes. Original scope source and binary identities remain unchanged.')
        scopes.append(row)
    by_target = {row['target']: row['outcomes'] for row in scopes}
    totals = dict(aot_passed=by_target['scriptw_aot_wasm']['passed'], aot_failed=by_target['scriptw_aot_wasm']['failed'],
        aot_total=by_target['scriptw_aot_wasm']['passed'] + by_target['scriptw_aot_wasm']['failed'],
        emission=by_target['emission']['passed'], structural=sum(by_target[name]['passed'] for name in STRUCTURAL),
        ir=by_target['scriptw_ir_integration']['passed'])
    assert totals == dict(aot_passed=653, aot_failed=4, aot_total=657, emission=67, structural=637, ir=769), 'published checkpoint scope differs'
    guard = copy.deepcopy(coverage['source_guards'])
    old_guard = ROOT / guard['path']
    assert sha(old_guard) == guard['sha256'] and old_guard.stat().st_size == guard['bytes']
    shutil.copy2(old_guard, output / 'source-guards.stdout')
    issues = []
    for index, path in enumerate(args.preflight_issue):
        copied = output / f'preflight-issue-{index}{path.suffix}'
        shutil.copy2(path, copied)
        issues.append(dict(original_path=str(path), sha256=sha(path), bytes=path.stat().st_size,
            retained=str(copied), counted_as_passing=False))
    trees = {}
    for package in ('scriptw-aot-wasm', 'scriptw-front', 'scriptw-ir', 'scriptw-runtime', 'scriptw-intl', 'scriptw-intl-build-data'):
        trees[package] = git('rev-parse', BASE_GIT + ':crates/' + package).decode().strip()
    result = dict(schema='scriptw-fiber-only-unchanged-native-inputs-v1', complete=True,
        source_manifest_sha256=source_sha, source_manifest=str(source), base_git=BASE_GIT,
        baseline_public_report_sha256=hashlib.sha256(public_bytes).hexdigest(),
        baseline_measured_source=public['publication']['measured_source'], original_scopes=scopes, totals=totals,
        unchanged_non_engine_cli_crates=True, unchanged_base_git_crate_trees=trees,
        unchanged_policy_scopes=witness['policies'], lockfile=dict(before_sha256=hashlib.sha256(git('show', BASE_GIT + ':Cargo.lock')).hexdigest(),
            after_sha256=sha(ROOT / 'Cargo.lock'), only_semantic_change='Add wasmtime-internal-fiber to scriptw-engine direct dependencies; all other package records identical.'),
        source_guards=dict(original=guard, retained=str(output / 'source-guards.stdout'), reused_passed=coverage['source_guards_passed']),
        retained_preflight_issues=issues,
        toolchain_requirement='Fresh candidate compiler/toolchain metadata must equal checkpoint046c metadata before publication accepts this reuse.',
        limits='Historical tests remain reused, never fresh. Four AOT failures remain failures. This proof does not assert old executable pathnames still contain old bytes. Engine lib/integration/runtime and caller-thread behavior require fresh scopes. Failed preflight metadata guards remain explicit unresolved issues.')
    check_source(source)
    validate_reuse(result, source_sha)
    save(output / 'reuse-proof.json', result)
    print(json.dumps(dict(complete=True, output=str(output / 'reuse-proof.json'), totals=totals), indent=2))


if __name__ == '__main__':
    main()
