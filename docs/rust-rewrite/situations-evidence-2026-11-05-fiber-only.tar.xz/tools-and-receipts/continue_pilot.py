import json,subprocess,time,sys
from pathlib import Path
base=Path('target/performance-v8-climb-20261104/fiber-only')
sys.path.insert(0,str(base));from common import check_source
while Path('/proc/133972').exists(): time.sleep(1)
assert json.loads((base/'test-producer-1/receipt.json').read_text())['complete']
rows=[]
def run(label,args):
 check_source(base/'source-initial/manifest.json')
 print('START',label,flush=True);start=time.monotonic_ns()
 with (base/(label+'.driver.stdout')).open('xb') as out,(base/(label+'.driver.stderr')).open('xb') as err:
  result=subprocess.run(args,stdout=out,stderr=err)
 rows.append(dict(label=label,argv=list(map(str,args)),exit_code=result.returncode,elapsed_ns=time.monotonic_ns()-start))
 (base/'pilot-sequence.json').write_text(json.dumps(rows,indent=2)+'\n')
 print('END',label,result.returncode,flush=True);assert result.returncode==0,label
 check_source(base/'source-initial/manifest.json')
phase=['python3','-B',str(base/'run_phase.py'),'--source',str(base/'source-initial/manifest.json')]
run('focused-1',phase+['--phase','focused','--producer',str(base/'test-producer-1/receipt.json'),'--output',str(base/'focused-1')])
run('products-1',phase+['--phase','products','--output',str(base/'products-1')])
cap=['python3','-B','scripts/limited_verification.py','--','python3','-B']
run('rsc-pilot-1',cap+[str(base/'measure_rsc.py'),'--candidate',str(base/'products-1/frozen/rsc_baseline'),'--candidate-source-snapshot',str(base/'source-initial'),'--focused-receipt',str(base/'focused-1/receipt.json'),'--output',str(base/'rsc-pilot-1')])
run('situations-1',cap+['scripts/benchmark-situations.py','--host',str(base/'products-1/frozen/compiler_precompiled_baseline'),'--producer-log',str(base/'products-1/examples-build.stdout'),'--producer-receipt',str(base/'products-1/frozen/compiler_precompiled_baseline-producer.json'),'--fixtures','target/performance-v8-climb-20261104/packed-readonly/fixtures','--output',str(base/'situations-1'),'--node','/home/jacobt/.local/share/fnm/node-versions/v24.12.0/installation/bin/node','--time','target/performance-worker-cpu/tools/time'])
run('paired-retention',cap+[str(base/'paired_retention.py')])
