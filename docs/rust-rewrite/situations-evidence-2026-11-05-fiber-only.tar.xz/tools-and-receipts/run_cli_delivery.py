import json,subprocess,sys,time
from pathlib import Path
b=Path('target/performance-v8-climb-20261104/fiber-only').resolve();sys.path.insert(0,str(b))
from common import check_source,read,save,sha
source=b/'source-corrected-2/manifest.json';check_source(source)
out=b/'cli-delivery-1';out.mkdir()
binary=b/'products-1/frozen/scriptw';producer=read(b/'products-1/frozen/scriptw-producer.json')
assert producer['source_manifest_sha256']==sha(b/'source-initial/manifest.json')
assert sha(binary)==producer['sha256']
fixture=Path('crates/scriptw-cli/tests/fixtures/hello.js').resolve()
argv=[str(binary),'run',str(fixture)]
capped=['python3','-B','scripts/limited_verification.py','--',*argv]
start=time.monotonic_ns()
with (out/'stdout').open('xb') as so,(out/'stderr').open('xb') as se:
 result=subprocess.run(capped,stdout=so,stderr=se,timeout=120)
row=dict(schema='scriptw-fiber-cli-delivery-smoke-v1',complete=False,argv=argv,capped_argv=capped,exit_code=result.returncode,timed_out=False,elapsed_ns=time.monotonic_ns()-start,executable_sha256=sha(binary),source_manifest_sha256=sha(b/'source-initial/manifest.json'),delivered_source_manifest_sha256=sha(source),producer_path=str(b/'products-1/frozen/scriptw-producer.json'),producer_sha256=sha(b/'products-1/frozen/scriptw-producer.json'),fixture_path=str(fixture),fixture_sha256=sha(fixture),stdout_sha256=sha(out/'stdout'),stderr_sha256=sha(out/'stderr'),expected_stdout='grug\n')
save(out/'receipt.json',row)
assert result.returncode==0
assert (out/'stdout').read_bytes()==b'grug\n'
assert not (out/'stderr').read_bytes()
check_source(source);row['complete']=True;save(out/'receipt.json',row)
print('FROZEN ORDINARY CLI DELIVERY SMOKE PASS',out/'receipt.json')
