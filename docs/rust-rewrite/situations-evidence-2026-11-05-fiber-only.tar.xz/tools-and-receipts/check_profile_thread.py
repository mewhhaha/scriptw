"""Source-only mocked proc controls; never start a child or inspect a real TID."""
import json
from pathlib import Path
from unittest.mock import patch
import profile_thread as selector
from common import BASE, save, sha


class Text:
    def __init__(self, value):
        self.value = value

    def read_text(self):
        return self.value


class Task:
    def __init__(self, tid, syscall):
        self.name = str(tid)
        self.syscall = syscall

    def __truediv__(self, name):
        assert name == 'syscall'
        return Text(self.syscall)


class Tasks:
    def __init__(self, rows):
        self.rows = rows

    def iterdir(self):
        return iter(Task(tid, syscall) for tid, syscall in self.rows)


def main():
    checks = []

    def select(rows, expected_socket='socket:[77]', machine='x86_64'):
        with patch.object(selector, 'Path', return_value=Tasks(rows)), \
             patch.object(selector.os, 'readlink', return_value=expected_socket), \
             patch.object(selector.platform, 'system', return_value='Linux'), \
             patch.object(selector.platform, 'machine', return_value=machine), \
             patch.object(selector.time, 'monotonic', side_effect=[0, 0, 3]), \
             patch.object(selector.time, 'sleep', return_value=None):
            return selector.barrier_caller(100, 9, 77,
                lambda pid, tid: dict(tid=tid, comm='synthetic-caller', starttime_ticks=123))

    result = select([(100, '0 0x4 0 0'), (123, '45 0x9 0 0'), (124, 'running')])
    assert result['tid'] == 123 and result['tid'] != 100
    assert result['barrier_authentication']['socket_inode'] == 77
    checks.append('unique-exact-socket-reader-selected-without-pid-or-name-assumption')
    for name, rows, options in (
        ('wrong-control-descriptor-rejected', [(123, '45 0xa 0 0')], {}),
        ('wrong-socket-inode-rejected', [(123, '45 0x9 0 0')], {'expected_socket': 'socket:[78]'}),
        ('multiple-readers-rejected', [(123, '0 0x9 0 0'), (124, '45 0x9 0 0')], {}),
        ('unrelated-syscall-rejected', [(123, '202 0x9 0 0')], {}),
        ('unsupported-syscall-architecture-rejected', [(123, '0 0x9 0 0')], {'machine': 'aarch64'}),
    ):
        try:
            select(rows, **options)
        except (AssertionError, RuntimeError):
            checks.append(name)
        else:
            raise AssertionError('invalid synthetic thread proof admitted: ' + name)
    receipt = dict(complete=True, source_only=True, synthetic_proc_data=True, child_processes=0,
        live_proc_reads=0, thread_authenticator_sha256=sha(BASE / 'profile_thread.py'), checks=checks,
        limits='Mocked source invariant controls only; actual caller-thread capture and kernel proc access remain unverified until root runs the fresh diagnostic.')
    save(BASE / 'profile-source-checks.json', receipt)
    print(json.dumps(receipt, indent=2))


if __name__ == '__main__':
    main()
