"""Explicit fresh caller-thread PMU campaign; never reuse historical counters."""
import argparse
from pathlib import Path
import subprocess
import time
from common import BASE, ROOT, check_source, read, save, sha


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--binary', type=Path, required=True)
    parser.add_argument('--reference-report', type=Path, required=True, help='fresh ordinary candidate report.json from this RSC campaign')
    parser.add_argument('--node', required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    check_source(args.source)
    identity = read(args.reference_report)
    assert identity['status'] == 'complete' and identity['executable_sha256'] == sha(args.binary)
    producer = read(args.binary.parent / (args.binary.name + '-producer.json'))
    assert producer['source_manifest_sha256'] == sha(args.source) and producer['artifact']['profile']['test'] is False
    output = args.output.resolve()
    assert output.is_relative_to(ROOT / 'target') and not output.exists()
    output.mkdir(parents=True)
    tooling = {name: sha(BASE / name) for name in ('profile_current.py', 'profile_thread.py', 'count_request_pmu.py', 'node_request_profile.v2.cjs')}
    report = dict(schema='scriptw-caller-pmu-campaign-v1', complete=False,
        source_manifest_sha256=sha(args.source), reference_report=dict(path=str(args.reference_report.resolve()), sha256=sha(args.reference_report)),
        tooling=tooling, runs=[], limits='Fresh caller/control-edge counters and V8 main-thread counters only. Old Scriptw execution-worker-only windows have a different boundary and are not a comparable isolated before/after instruction claim.')
    save(output / 'campaign.json', report)
    for repetition in range(3):
        for mode in ('sync', 'async'):
            for engine in ('scriptw', 'node'):
                check_source(args.source)
                assert all(sha(BASE / name) == expected for name, expected in tooling.items())
                name = f'{engine}-{mode}-{repetition}'
                folder = output / name
                argv = ['python3', '-B', str(ROOT / 'scripts/limited_verification.py'), '--', 'python3', '-B',
                    str(BASE / 'count_request_pmu.py'), str(folder), '--engine', engine, '--mode', mode,
                    '--binary', str(args.binary.resolve()), '--node', args.node,
                    '--baseline-json', str(args.reference_report.resolve()), '--samples', '100', '--warmups', '3']
                print('START', name, flush=True)
                start = time.monotonic_ns()
                with (output / (name + '.stdout')).open('xb') as out, (output / (name + '.stderr')).open('xb') as err:
                    child = subprocess.run(argv, cwd=ROOT, stdout=out, stderr=err, timeout=300)
                row = dict(name=name, engine=engine, mode=mode, repetition=repetition, argv=argv,
                    exit_code=child.returncode, elapsed_ns=time.monotonic_ns() - start,
                    receipt=str(folder / 'receipt.json'), output=str(folder))
                report['runs'].append(row)
                save(output / 'campaign.json', report)
                assert child.returncode == 0
                captured = read(folder / 'receipt.json')
                assert captured['status'] == 'captured' and captured['samples'] == 100
                row['receipt_sha256'] = sha(folder / 'receipt.json')
                save(output / 'campaign.json', report)
                print('END', name, flush=True)
    check_source(args.source)
    assert all(sha(BASE / name) == expected for name, expected in tooling.items())
    report['complete'] = True
    save(output / 'campaign.json', report)
    print('FRESH CALLER PMU CAMPAIGN COMPLETE', output / 'campaign.json', flush=True)


if __name__ == '__main__':
    main()
