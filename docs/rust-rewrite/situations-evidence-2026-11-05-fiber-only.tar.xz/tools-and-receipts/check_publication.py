"""Verify a staged or copied publication and checkpoint preservation; read only."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess
import tarfile
from common import BASE_GIT, ROOT, git, read, sha


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--stage', type=Path, required=True)
    parser.add_argument('--canonical', action='store_true', help='verify root copied reports/archive and rendered charts')
    args = parser.parse_args()
    ready = read(args.stage / 'publication-ready.json')
    assert ready['complete'] and ready['canonical_files_written'] is False
    directory = args.stage
    metadata = ready['staged_archive']
    if args.canonical:
        directory = ROOT / 'docs/rust-rewrite'
        metadata = ready['evidence_archive']
    archive_path = ROOT / metadata['file']
    assert sha(archive_path) == metadata['sha256'] and archive_path.stat().st_size == metadata['bytes']
    with tarfile.open(archive_path, 'r:xz') as packed:
        index_bytes = packed.extractfile('INDEX.json').read()
        assert packed.extractfile('INDEX.json.sha256').read().decode().strip() == hashlib.sha256(index_bytes).hexdigest() + '  INDEX.json'
        index = json.loads(index_bytes)
        members = packed.getmembers()
        assert len(members) == len(index['members']) + 2
        assert {member.name for member in members} == {row['path'] for row in index['members']} | {'INDEX.json', 'INDEX.json.sha256'}
        assert all(member.isfile() and member.mode == 0o644 for member in members)
        for row in index['members']:
            value = packed.extractfile(row['path']).read()
            assert hashlib.sha256(value).hexdigest() == row['sha256'] and len(value) == row['bytes']
            assert b'\0' not in value
            value.decode('utf-8', errors='strict')
        for name in ready['reports']:
            public = read(directory / name)
            assert public.pop('evidence_archive') == ready['evidence_archive']
            assert public == json.loads(packed.extractfile('reports/' + name).read())
            if args.canonical:
                assert (directory / name).read_bytes() == (args.stage / name).read_bytes()
        situations = json.loads(packed.extractfile('reports/situations-current.json').read())
        publication = situations['publication']
        if 'delivered_source' in publication:
            measured = publication['measured_source']['manifest_sha256']
            delivered = publication['delivered_source']['manifest_sha256']
            assert measured != delivered
            assert hashlib.sha256(packed.extractfile('source/measured/manifest.json').read()).hexdigest() == measured
            assert hashlib.sha256(packed.extractfile('source/delivered-test-corrected/manifest.json').read()).hexdigest() == delivered
            proof = json.loads(packed.extractfile('verification/test-only-source-equivalence.json').read())
            assert proof['measured_source']['sha256'] == measured and proof['delivered_source']['sha256'] == delivered
            assert proof['changed_files'] == ['crates/scriptw-engine/src/tests/execution.rs']
            assert hashlib.sha256(packed.extractfile('verification/compiler_fingerprint.rs').read()).hexdigest() == proof['compiler_input_exclusion']['implementation_sha256']
            assert hashlib.sha256(packed.extractfile('verification/compiler-build.rs').read()).hexdigest() == proof['compiler_input_exclusion']['build_script_sha256']
            unit = next(row for row in publication['coverage']['fresh_native'] if row['target'] == 'scriptw_engine')
            assert unit['outcomes']['state'] == 'qualified_union'
            original, recovered = unit['original_failed_full_scope'], unit['corrected_filtered_scope']
            assert original['source_manifest_sha256'] == measured and original['outcomes']['failed'] == 1
            assert original['outcomes']['state'] == 'FAILED' and original['exit_code'] == 101
            assert recovered['source_manifest_sha256'] == delivered and recovered['outcomes']['passed'] == 1
            assert recovered['outcomes']['state'] == 'ok' and recovered['exit_code'] == 0
            assert not set(unit['preserved_passed_tests']) & set(unit['recovered_tests'])
            assert unit['outcomes']['passed'] == original['outcomes']['passed'] + recovered['outcomes']['passed']
            assert len(unit['preserved_passed_tests']) == original['outcomes']['passed']
            for row in (original, recovered):
                for field in ('stdout', 'stderr'):
                    value = packed.extractfile(row[field]['archive_path']).read()
                    assert hashlib.sha256(value).hexdigest() == row[field]['sha256']
        binding = json.loads(packed.extractfile('baseline/binding.json').read())
        old_archive = binding['evidence_archive']
        original = git('show', BASE_GIT + ':' + old_archive['file'])
        assert (ROOT / old_archive['file']).read_bytes() == original
        assert hashlib.sha256(original).hexdigest() == old_archive['sha256']
    before = git('show', BASE_GIT + ':README.md')
    after = (ROOT / 'README.md').read_bytes()
    for marker in ('runtime-comparison', 'application-benchmarks', 'scriptw-status', 'scriptw-test-graph'):
        pattern = re.compile(rb'<!-- ' + marker.encode() + rb':start -->.*?<!-- ' + marker.encode() + rb':end -->', re.S)
        assert pattern.search(after).group() == pattern.search(before).group(), marker
    for relative in ('docs/rust-rewrite/test262-current.md', 'docs/rust-rewrite/assets/test262-status.svg'):
        assert (ROOT / relative).read_bytes() == git('show', BASE_GIT + ':' + relative)
    folders = ('docs/rust-rewrite/assets/situations-current', 'docs/rust-rewrite/assets/rsc-current')
    old_paths = set(git('ls-tree', '-r', '--name-only', BASE_GIT, '--', *folders).decode().splitlines())
    expected = {path for path in old_paths if path.endswith('.svg')}
    actual = {path.relative_to(ROOT).as_posix() for folder in folders for path in (ROOT / folder).glob('*.svg')}
    assert len(actual) == 12 and actual == expected
    if args.canonical:
        for name in ('react-allocation-current.json', 'react-attribution-current.json', 'rsc-wasm-size-current.json'):
            if name not in ready['reports'] and not (args.stage / name).exists():
                assert (directory / name).read_bytes() == git('show', BASE_GIT + ':docs/rust-rewrite/' + name), 'historical diagnostic was modified without fresh current evidence'
    print(json.dumps(dict(complete=True, canonical=args.canonical, archive_sha256=metadata['sha256'],
        inert_members=len(index['members']) + 2, reports=ready['reports'], preserved_charts=12,
        preserved_readme_blocks=4, pinned_test262_unchanged=True)))


if __name__ == '__main__':
    main()
