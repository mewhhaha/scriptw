"""Small source/receipt helpers for the unpublished caller-thread fiber pilot."""
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[3]
BASE = Path(__file__).resolve().parent
BASE_GIT = '046c64735af42497b8eea3aa346ff71d81c0b76f'


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def save(path, value):
    path = Path(path)
    temporary = path.with_name(path.name + '.writing')
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')
    temporary.replace(path)


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)


def check_source(manifest):
    manifest = Path(manifest).resolve(strict=True)
    data = read(manifest)
    assert git('rev-parse', 'HEAD').decode().strip() == data['base_git'] == BASE_GIT
    assert git('diff', '--binary', 'HEAD') == (manifest.parent / 'tracked.patch').read_bytes()
    assert sha(manifest.parent / 'tracked.patch') == data['tracked_patch_sha256']
    for relative, expected in data['files'].items():
        assert sha(ROOT / relative) == expected, relative
    untracked = set(git('ls-files', '--others', '--exclude-standard', '-z').decode().split('\0')) - {''}
    assert untracked == set(data['untracked_files']), 'untracked source inventory changed'
    for relative in data['files']:
        assert sha(manifest.parent / 'files' / relative) == data['files'][relative]
    return data


def artifacts(log):
    rows = [json.loads(line) for line in Path(log).read_text().splitlines() if line]
    finished = [row for row in rows if row.get('reason') == 'build-finished']
    assert len(finished) == 1 and finished[0]['success'], 'Cargo producer did not complete'
    return [row for row in rows if row.get('reason') == 'compiler-artifact' and row.get('executable')]
