"""Qualify one authorized test literal and preserve the failed/full + recovered scopes."""
import argparse
import copy
import difflib
import hashlib
import json
from pathlib import Path
import re
from common import ROOT, artifacts, check_source, git, read, save, sha
from run_broad import ENGINE, SUMMARY, failures

TEST_FILE = 'crates/scriptw-engine/src/tests/execution.rs'
TEST_NAME = 'tests::execution::wasm_backend_characterization_matrix_locks_public_surface_and_outcomes'
FINGERPRINT = 'crates/scriptw-engine/compiler_fingerprint.rs'
BUILD_SCRIPT = 'crates/scriptw-engine/build.rs'


def frozen_bytes(manifest, relative):
    data = read(manifest)
    if relative in data['files']:
        path = manifest.parent / 'files' / relative
        assert sha(path) == data['files'][relative]
        return path.read_bytes()
    return git('show', data['base_git'] + ':' + relative)


def string_array(source, name):
    match = re.search(r'const\s+' + name + r'\s*:[^=]+?=\s*&\[(.*?)\];', source, re.S)
    assert match, name
    return re.findall(r'"([^"\n]+)"', re.sub(r'//[^\n]*', '', match[1]))


def equivalence(measured, delivered):
    measured, delivered = Path(measured).resolve(strict=True), Path(delivered).resolve(strict=True)
    old, new = read(measured), check_source(delivered)
    assert old['base_git'] == new['base_git']
    assert set(new['files']) == set(old['files']) | {TEST_FILE}
    assert old['untracked_files'] == new['untracked_files']
    for relative, expected in old['files'].items():
        assert relative != TEST_FILE and new['files'][relative] == expected
        assert sha(measured.parent / 'files' / relative) == sha(delivered.parent / 'files' / relative) == expected
    before = frozen_bytes(measured, TEST_FILE)
    after = frozen_bytes(delivered, TEST_FILE)
    anchor = b'\n            "scriptw_host::reject_runtime_semantics",\n'
    addition = b'            "scriptw_host::report_cleanup_exception",\n'
    assert before.count(anchor) == 1 and after == before.replace(anchor, anchor + addition)
    implementation = frozen_bytes(measured, FINGERPRINT)
    assert implementation == frozen_bytes(delivered, FINGERPRINT) == (ROOT / FINGERPRINT).read_bytes()
    build = frozen_bytes(measured, BUILD_SCRIPT)
    assert build == frozen_bytes(delivered, BUILD_SCRIPT) == (ROOT / BUILD_SCRIPT).read_bytes()
    source = implementation.decode()
    excluded = string_array(source, 'TEST_ONLY_INPUTS')
    compiler_inputs = string_array(source, 'COMPILER_INPUTS')
    native_inputs = string_array(source, 'NATIVE_COMPILER_INPUTS')
    matches = [relative for relative in excluded if Path(TEST_FILE).is_relative_to(relative)]
    assert matches == ['crates/scriptw-engine/src/tests']
    assert any(Path(TEST_FILE).is_relative_to(relative) for relative in compiler_inputs)
    assert not any(Path(TEST_FILE).is_relative_to(relative) for relative in native_inputs)
    assert 'input_files(workspace, COMPILER_INPUTS, TEST_ONLY_INPUTS)' in source
    assert 'input_files(workspace, NATIVE_COMPILER_INPUTS, &[])' in source
    return dict(schema='scriptw-fiber-test-only-source-equivalence-v1', complete=True,
        measured_source=dict(path=str(measured), sha256=sha(measured)),
        delivered_source=dict(path=str(delivered), sha256=sha(delivered)), changed_files=[TEST_FILE],
        test=dict(name=TEST_NAME, path=TEST_FILE, before_sha256=hashlib.sha256(before).hexdigest(), after_sha256=hashlib.sha256(after).hexdigest()),
        patch=''.join(difflib.unified_diff(before.decode().splitlines(keepends=True), after.decode().splitlines(keepends=True), fromfile='a/' + TEST_FILE, tofile='b/' + TEST_FILE)),
        compiler_input_exclusion=dict(implementation=FINGERPRINT, implementation_sha256=hashlib.sha256(implementation).hexdigest(),
            build_script=BUILD_SCRIPT, build_script_sha256=hashlib.sha256(build).hexdigest(), test_only_prefix=matches[0],
            compiler_input_bytes_unchanged=True, native_compiler_input_bytes_unchanged=True),
        limits='Exact single expected-import literal correction only. Measured products, matrix, RSC and integration receipts keep their original source/binary identities. No benchmark or full unit rerun is implied.')


def result_from_logs(stdout, stderr):
    matches = SUMMARY.findall(Path(stdout).read_text())
    assert len(matches) == 1
    state, passed, failed, ignored = matches[0]
    return dict(outcomes=dict(state=state, passed=int(passed), failed=int(failed), ignored=int(ignored)),
        stdout=str(Path(stdout).resolve()), stderr=str(Path(stderr).resolve()),
        stdout_sha256=sha(stdout), stderr_sha256=sha(stderr))


def validate_qualification(report, measured_sha, delivered):
    assert report['complete'] and report['full_native_target_set_complete']
    assert report['schema'] == 'scriptw-fiber-native-qualified-union-v1'
    assert report['source_manifest_sha256'] == measured_sha
    assert report['delivered_source_manifest_sha256'] == sha(delivered)
    source_proof = read(report['source_equivalence']['path'])
    assert sha(report['source_equivalence']['path']) == report['source_equivalence']['sha256']
    assert source_proof == equivalence(source_proof['measured_source']['path'], delivered)
    assert source_proof['measured_source']['sha256'] == measured_sha
    unit = next(row for row in report['scopes'] if row['target'] == 'scriptw_engine')
    assert unit['scope_kind'] == 'qualified_union'
    original, recovered = unit['original_failed_full_scope'], unit['corrected_filtered_scope']
    assert original['source_manifest_sha256'] == measured_sha
    assert original['exit_code'] == 101 and original['outcomes']['failed'] == 1
    assert result_from_logs(original['stdout'], original['stderr'])['outcomes'] == original['outcomes']
    assert failures(Path(original['stdout']).read_text()) == {TEST_NAME}
    passed = re.findall(r'^test (\S+) \.\.\. ok$', Path(original['stdout']).read_text(), re.M)
    assert passed == unit['preserved_passed_tests'] and len(passed) == len(set(passed)) == original['outcomes']['passed']
    assert set(passed) == set(unit['inventory']['tests']) - {TEST_NAME}
    assert unit['inventory']['executable_sha256'] == original['executable_sha256']
    assert recovered['source_manifest_sha256'] == sha(delivered) and recovered['exit_code'] == 0
    assert recovered['outcomes'] == result_from_logs(recovered['stdout'], recovered['stderr'])['outcomes'] == dict(state='ok', passed=1, failed=0, ignored=0)
    assert re.findall(r'^test (\S+) \.\.\. ok$', Path(recovered['stdout']).read_text(), re.M) == [TEST_NAME]
    assert TEST_NAME in recovered['argv'] and '--exact' in recovered['argv']
    actual = read(report['recovery_command_receipt']['path'])
    assert sha(report['recovery_command_receipt']['path']) == report['recovery_command_receipt']['sha256']
    for key in ('argv', 'capped_argv', 'exit_code', 'elapsed_ns', 'source_manifest_sha256', 'executable_sha256'):
        assert recovered[key] == actual[key]
    producer = report['corrected_unit_producer']
    assert producer['source_manifest_sha256'] == sha(delivered) and producer['artifact']['profile']['test'] is True
    assert producer['artifact']['target']['name'] == 'scriptw_engine'
    assert sha(producer['frozen_path']) == producer['executable_sha256'] == recovered['executable_sha256']
    assert sha(producer['stdout']) == producer['stdout_sha256'] and sha(producer['stderr']) == producer['stderr_sha256']
    assert len([row for row in artifacts(producer['stdout']) if row == producer['artifact']]) == 1
    for row in (original, recovered):
        assert sha(row['stdout']) == row['stdout_sha256'] and sha(row['stderr']) == row['stderr_sha256']
    assert unit['outcomes'] == dict(state='qualified_union', passed=len(passed) + 1, failed=0, ignored=0)
    assert unit['recovered_tests'] == [TEST_NAME] and unit['outcomes']['passed'] == unit['inventory']['count']
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--measured-source', type=Path, required=True)
    parser.add_argument('--delivered-source', type=Path, required=True)
    parser.add_argument('--failed-broad', type=Path, required=True)
    parser.add_argument('--integrations', type=Path, required=True)
    parser.add_argument('--corrected-cargo-stdout', type=Path, required=True)
    parser.add_argument('--corrected-cargo-stderr', type=Path, required=True)
    parser.add_argument('--corrected-binary', type=Path, required=True, help='frozen corrected unit binary')
    parser.add_argument('--recovered-stdout', type=Path, required=True)
    parser.add_argument('--recovered-stderr', type=Path, required=True)
    parser.add_argument('--recovery-receipt', type=Path, required=True, help='actual capped command row JSON including exit/source/executable identity')
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    proof = equivalence(args.measured_source, args.delivered_source)
    measured_sha = proof['measured_source']['sha256']
    delivered_sha = proof['delivered_source']['sha256']
    old = read(args.failed_broad)
    assert old['source_manifest_sha256'] == measured_sha
    rows = [row for row in old['scopes'] if row['target'] == 'scriptw_engine']
    assert len(rows) == 1
    failed = copy.deepcopy(rows[0])
    assert result_from_logs(failed['stdout'], failed['stderr'])['outcomes'] == failed['outcomes']
    assert sha(failed['stdout']) == failed['stdout_sha256'] and sha(failed['stderr']) == failed['stderr_sha256']
    assert failed['exit_code'] == 101 and failed['outcomes']['failed'] == 1 and failed['outcomes']['ignored'] == 0
    assert failures(Path(failed['stdout']).read_text()) == {TEST_NAME}
    inventory = old['inventories']['scriptw_engine']
    assert inventory['count'] == len(inventory['tests']) == failed['outcomes']['passed'] + 1
    assert TEST_NAME in inventory['tests']
    passed_names = re.findall(r'^test (\S+) \.\.\. ok$', Path(failed['stdout']).read_text(), re.M)
    assert len(passed_names) == len(set(passed_names)) == failed['outcomes']['passed']
    assert set(passed_names) == set(inventory['tests']) - {TEST_NAME}
    integration = read(args.integrations)
    assert integration['complete'] and integration['source_manifest_sha256'] == measured_sha
    assert {row['target'] for row in integration['scopes']} == set(ENGINE)
    for row in integration['scopes']:
        assert row['exit_code'] == 0 and row['outcomes']['failed'] == row['outcomes']['ignored'] == 0
        assert row['source_manifest_sha256'] == measured_sha
        assert result_from_logs(row['stdout'], row['stderr'])['outcomes'] == row['outcomes']
    candidates = [row for row in artifacts(args.corrected_cargo_stdout) if row['target']['name'] == 'scriptw_engine' and row['profile']['test'] is True]
    assert len(candidates) == 1
    actual_recovery = read(args.recovery_receipt)
    assert actual_recovery['exit_code'] == 0 and not actual_recovery.get('timed_out')
    assert actual_recovery['source_manifest_sha256'] == delivered_sha
    assert actual_recovery['executable_sha256'] == sha(args.corrected_binary)
    assert TEST_NAME in actual_recovery['argv'] and '--exact' in actual_recovery['argv']
    actual_logs = result_from_logs(args.recovered_stdout, args.recovered_stderr)
    for field in ('stdout', 'stderr'):
        assert Path(actual_recovery[field]).resolve() == Path(actual_logs[field])
        assert actual_recovery[field + '_sha256'] == actual_logs[field + '_sha256']
    recovered = dict(actual_recovery, **actual_logs)
    assert recovered['outcomes'] == dict(state='ok', passed=1, failed=0, ignored=0)
    assert re.findall(r'^test (\S+) \.\.\. ok$', args.recovered_stdout.read_text(), re.M) == [TEST_NAME]
    recovered.update(label='engine-unit-corrected-filter', package='scriptw-engine', target='scriptw_engine',
        source_manifest_sha256=delivered_sha, executable_sha256=sha(args.corrected_binary))
    unit = dict(label='engine-unit-preserved-and-recovered', package='scriptw-engine', target='scriptw_engine',
        scope_kind='qualified_union', source_manifest_sha256=measured_sha, delivered_source_manifest_sha256=delivered_sha,
        outcomes=dict(state='qualified_union', passed=len(passed_names) + 1, failed=0, ignored=0),
        original_failed_full_scope=failed, corrected_filtered_scope=recovered,
        preserved_passed_tests=passed_names, recovered_tests=[TEST_NAME], inventory=inventory,
        limits='Original full run remains failed; final coverage is the explicit disjoint union of preserved passes and one corrected targeted pass.')
    output = args.output.resolve()
    assert output.is_relative_to(ROOT / 'target') and not output.exists()
    output.mkdir(parents=True)
    save(output / 'source-equivalence.json', proof)
    (output / 'test-only.patch').write_text(proof['patch'])
    report = copy.deepcopy(integration)
    report.update(schema='scriptw-fiber-native-qualified-union-v1', complete=True, full_native_target_set_complete=True,
        source_manifest_sha256=measured_sha, delivered_source_manifest_sha256=delivered_sha,
        source_equivalence=dict(path=str(output / 'source-equivalence.json'), sha256=sha(output / 'source-equivalence.json')),
        scopes=[unit, *integration['scopes']], inventories=dict(integration['inventories'], scriptw_engine=inventory),
        artifacts=[next(row for row in old['artifacts'] if row['artifact']['target']['name'] == 'scriptw_engine'), *integration['artifacts']],
        original_failed_broad=dict(path=str(args.failed_broad.resolve()), sha256=sha(args.failed_broad)),
        original_integration_broad=dict(path=str(args.integrations.resolve()), sha256=sha(args.integrations)),
        corrected_unit_producer=dict(artifact=candidates[0], frozen_path=str(args.corrected_binary.resolve()),
            executable_sha256=sha(args.corrected_binary), source_manifest_sha256=delivered_sha,
            stdout=str(args.corrected_cargo_stdout.resolve()), stderr=str(args.corrected_cargo_stderr.resolve()),
            stdout_sha256=sha(args.corrected_cargo_stdout), stderr_sha256=sha(args.corrected_cargo_stderr)),
        recovery_command_receipt=dict(path=str(args.recovery_receipt.resolve()), sha256=sha(args.recovery_receipt)),
        limits='Fresh full Engine coverage uses four unchanged measured-source integration scopes and an explicit unit qualified union. Original failed full-unit evidence remains failed. No matrix/RSC/product source identity is rewritten.')
    validate_qualification(report, measured_sha, args.delivered_source)
    save(output / 'native-verification.json', report)
    print('QUALIFIED UNIT UNION; ORIGINAL FAILED RUN RETAINED', output / 'native-verification.json')


if __name__ == '__main__':
    main()
