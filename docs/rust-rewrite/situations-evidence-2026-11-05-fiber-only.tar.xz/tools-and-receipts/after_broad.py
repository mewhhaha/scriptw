import json,os,subprocess,time,sys
from pathlib import Path
from datetime import datetime,timezone
base=Path('target/performance-v8-climb-20261104/fiber-only');sys.path.insert(0,str(base));from common import check_source,sha,save
while Path('/proc/161844').exists(): time.sleep(1)
broad=base/'broad-1/native-verification.json';assert json.loads(broad.read_text())['complete']
source=base/'source-initial/manifest.json';check_source(source)
out=base/'cli-delivery-1';out.mkdir();(out/'cache').mkdir();(out/'tmp').mkdir()
cli=base/'products-1/frozen/scriptw';producer=base/'products-1/frozen/scriptw-producer.json';assert sha(cli)==json.loads(producer.read_text())['sha256']
env=dict(os.environ,SCRIPTW_CACHE_DIR=str((out/'cache').resolve()),TMPDIR=str((out/'tmp').resolve()))
rows=[]
for label,args in [('hello',[str(cli),'--jobs','1','run','crates/scriptw-cli/tests/fixtures/hello.js']),('product-graph',['./scripts/check-no-interpreter-in-product-graph.sh'])]:
 print('START',label,flush=True);start=time.monotonic_ns();argv=['python3','-B','scripts/limited_verification.py','--',*args]
 with (out/(label+'.stdout')).open('xb') as stdout,(out/(label+'.stderr')).open('xb') as stderr:result=subprocess.run(argv,env=env,stdout=stdout,stderr=stderr)
 row=dict(label=label,argv=argv,exit_code=result.returncode,elapsed_ns=time.monotonic_ns()-start,stdout_sha256=sha(out/(label+'.stdout')),stderr_sha256=sha(out/(label+'.stderr')));rows.append(row)
 save(out/'receipt.json',dict(complete=False,source_manifest_sha256=sha(source),cli_sha256=sha(cli),cli_producer_sha256=sha(producer),commands=rows))
 assert result.returncode==0,label
 if label=='hello':assert (out/(label+'.stdout')).read_bytes()==b'grug\n'
 check_source(source);print('END',label,result.returncode,flush=True)
save(out/'receipt.json',dict(complete=True,source_manifest_sha256=sha(source),cli_sha256=sha(cli),cli_producer_sha256=sha(producer),commands=rows,expected_stdout='grug\n',recorded_at=datetime.now(timezone.utc).isoformat()))
proofs={name:dict(path=str(p),sha256=sha(p)) for name,p in {'source':source,'retention':base/'retention-decision.json','broad':broad,'reuse':base/'reuse-046c-2/reuse-proof.json','cli':out/'receipt.json'}.items()}
save(base/'qualification-final.json',dict(complete=True,recorded_at=datetime.now(timezone.utc).isoformat(),proofs=proofs,limits='Fresh Engine scopes and qualified historical AOT/IR reuse remain separate. Four known AOT failures and failed Intl identity audit remain explicit; pinned Test262 not rerun.'))
print('FINAL QUALIFICATION AND CLI DELIVERY COMPLETE',flush=True)
