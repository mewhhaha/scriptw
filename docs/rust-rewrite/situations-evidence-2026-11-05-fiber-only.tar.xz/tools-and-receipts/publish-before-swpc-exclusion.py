"""Stage fresh caller-thread fiber measurements and inert evidence; never write docs."""
import argparse
import copy
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import statistics
import tarfile
import tomllib
from common import BASE, BASE_GIT, ROOT, check_source, git, read, save, sha
from run_broad import ENGINE, STRUCTURAL, SUMMARY, failures
from qualify_reuse import validate_reuse
from qualify_recovery import equivalence, validate_qualification

ARCHIVE_TOOL = ROOT / 'target/react-performance-20261103/archive_final.py'
REPORTS = ('situations-current.json', 'rsc-current.json', 'rsc-wasm-size-current.json',
           'react-attribution-current.json', 'react-allocation-current.json')
EXCLUDED = {'.wasm', '.so', '.a', '.rlib', '.rmeta', '.o', '.exe', '.bin', '.xz', '.zip'}


def encoded(value):
    return (json.dumps(value, indent=2, allow_nan=False) + '\n').encode()


def reference(path):
    path = Path(path).resolve(strict=True)
    return dict(path=str(path.relative_to(ROOT)), sha256=sha(path), bytes=path.stat().st_size)


def text_tree(archive, folder, prefix):
    folder = Path(folder).resolve(strict=True)
    for path in sorted(folder.rglob('*')):
        assert not path.is_symlink(), path
        if not path.is_file():
            continue
        relative = path.relative_to(folder)
        if any(part in ('cache', 'tmp', 'scratch', '__pycache__', 'node_modules') for part in relative.parts):
            continue
        if path.suffix in EXCLUDED or path.name.startswith('perf.data'):
            continue
        with path.open('rb') as stream:
            magic = stream.read(4)
        if magic in (b'\x7fELF', b'\0asm'):
            continue
        data = path.read_bytes()
        member = prefix + '/' + relative.as_posix()
        if path.suffix == '.gz':
            data = gzip.decompress(data)
            member = member[:-3]
        archive.add_bytes(member, data)


def verified_native(path, source_sha, delivered_source=None):
    report = read(path)
    assert report['complete'] and report['full_native_target_set_complete']
    assert report['source_manifest_sha256'] == source_sha
    assert report['pilot']['root_retained'] is True
    qualified_union = report.get('schema') == 'scriptw-fiber-native-qualified-union-v1'
    if qualified_union:
        assert delivered_source is not None
        validate_qualification(report, source_sha, delivered_source)
    expected = {'scriptw_engine', *ENGINE}
    assert {row['target'] for row in report['scopes']} == expected
    assert len(report['scopes']) == len(expected)
    assert sha(report['reuse_proof']['path']) == report['reuse_proof']['sha256']
    reuse = validate_reuse(read(report['reuse_proof']['path']), source_sha, delivered_source)
    assert report['reused_native'] == reuse['original_scopes']
    known = set(report['known_preexisting_aot_failures']['names'])
    assert len(known) == 4
    prior = json.loads(git('show', BASE_GIT + ':docs/rust-rewrite/situations-current.json'))
    original_aot = [row for row in prior['publication']['coverage']['fresh_native'] if row['target'] == 'scriptw_aot_wasm' and row['outcomes']['failed'] == 4]
    assert len(original_aot) == 1 and known == set(original_aot[0]['failures'])
    artifacts = {row['artifact']['target']['name']: row for row in report['artifacts']}
    assert set(artifacts) == expected and len(artifacts) == len(report['artifacts'])
    for row in report['scopes']:
        assert row['source_manifest_sha256'] == source_sha and not row.get('timed_out')
        if row.get('scope_kind') == 'qualified_union':
            assert qualified_union and row['target'] == 'scriptw_engine'
            artifact = artifacts['scriptw_engine']
            original = row['original_failed_full_scope']
            assert artifact['source_manifest_sha256'] == source_sha
            assert sha(artifact['frozen_path']) == artifact['executable_sha256'] == original['executable_sha256']
            continue
        stdout, stderr = Path(row['stdout']), Path(row['stderr'])
        assert sha(stdout) == row['stdout_sha256'] and sha(stderr) == row['stderr_sha256']
        matches = SUMMARY.findall(stdout.read_text())
        assert len(matches) == 1
        state, passed, failed, ignored = matches[0]
        actual = dict(state=state, passed=int(passed), failed=int(failed), ignored=int(ignored))
        assert actual == row['outcomes'] and int(ignored) == 0
        inventory = report['inventories'][row['target']]
        artifact = artifacts[row['target']]
        assert artifact['source_manifest_sha256'] == source_sha and artifact['artifact']['profile']['test'] is True
        assert sha(artifact['frozen_path']) == artifact['executable_sha256'] == row['executable_sha256']
        assert inventory['count'] == len(inventory['tests']) == int(passed) + int(failed)
        assert inventory['count'] > 0 and inventory['executable_sha256'] == row['executable_sha256']
        assert not any(not value.startswith('-') for value in row['argv'][1:]), 'broad scope contains a filter'
        assert state == 'ok' and row['exit_code'] == 0 and int(failed) == 0
    for row in report['producer_commands']:
        assert row['source_manifest_sha256'] == source_sha
        assert row['exit_code'] == 0 and not row.get('timed_out')
        assert sha(row['stdout']) == row['stdout_sha256'] and sha(row['stderr']) == row['stderr_sha256']
    return report


def current_pmu(path, identity, source_sha, date, archive):
    campaign = read(path)
    assert campaign['complete'] and campaign['source_manifest_sha256'] == source_sha
    assert campaign['schema'] == 'scriptw-caller-pmu-campaign-v1'
    assert len(campaign['runs']) == 3 * 2 * 2
    assert {(row['engine'], row['mode'], row['repetition']) for row in campaign['runs']} == {
        (engine, mode, repetition) for engine in ('scriptw', 'node') for mode in ('sync', 'async') for repetition in range(3)}
    reference_report = Path(campaign['reference_report']['path'])
    assert sha(reference_report) == campaign['reference_report']['sha256']
    assert all(read(reference_report)[key] == value for key, value in identity.items())
    rows = []
    for row in campaign['runs']:
        receipt_path = Path(row['receipt'])
        assert row['exit_code'] == 0 and sha(receipt_path) == row['receipt_sha256']
        receipt = read(receipt_path)
        assert receipt['status'] == 'captured' and receipt['host_exit_code'] == 0
        assert receipt['excluded_from_scored_cohorts'] is True and receipt['control_edges_included'] is True
        assert receipt['thread_authenticator_sha256'] == campaign['tooling']['profile_thread.py']
        assert receipt['adapter_sha256'] == campaign['tooling']['count_request_pmu.py']
        assert receipt['baseline_report_sha256'] == sha(reference_report)
        assert receipt['samples'] == len(receipt['windows']) == 100 and receipt['warmups'] == 3
        assert receipt['engine'] == row['engine'] and receipt['mode'] == row['mode']
        observed = read(receipt_path.parent / 'observations.json')
        assert observed['profiling']['excluded_from_scored_cohorts'] is True
        assert observed['cases'][0]['exact_node_output_checked'] is True
        if row['engine'] == 'scriptw':
            assert all(observed[key] == value for key, value in identity.items())
            assert receipt['worker_before']['barrier_authentication']['socket_inode'] > 0
            assert receipt['worker_after']['tid'] == receipt['worker_before']['tid']
        else:
            assert observed['main_thread_pid'] == receipt['pid'] == receipt['worker_before']['tid']
        assert receipt['worker_after']['starttime_ticks'] == receipt['worker_before']['starttime_ticks']
        for window in receipt['windows']:
            assert 0 < window['time_running_ns'] <= window['time_enabled_ns']
            assert window['running_fraction'] == window['time_running_ns'] / window['time_enabled_ns']
        rows.append(dict(engine=row['engine'], mode=row['mode'], repetition=row['repetition'],
            receipt=reference(receipt_path), target_thread=receipt['worker_before'], summary=receipt['summary'],
            per_window_raw_count_medians={event: statistics.median(window['raw_counts'][event] for window in receipt['windows'])
                for event in receipt['summary']['raw_counts']}))
    text_tree(archive, path.parent, 'diagnostics/current-pmu')
    return dict(schema='scriptw-react-attribution-current-v3', date=date, status='complete',
        excluded_from_scored_cohorts=True, candidate_identity=identity,
        pmu=dict(scope='Fresh current Scriptw caller and V8 main-thread windows', processes=rows,
            control_edges_included=True, samples_per_process=100, warmups=3),
        limitations=['Raw/scaled user-only hardware groups and actual enabled/running durations are retained.',
            'Scriptw caller and V8 main own their control barriers; control wakeup/read/write and Promise-return edges remain in counter bounds.',
            'Historical Scriptw worker-only PMU used a different boundary and supplies no isolated before/after instruction claim.',
            'Other threads, including background compiler/GC work and nested reentry workers, are excluded. No scored timing or allocation claim.'])


def compact(report):
    result = copy.deepcopy(report)
    for key in ('rows', 'commands', 'retained_files'):
        result.pop(key, None)
    for case in result['cases']:
        for actor in case['runtimes'].values():
            for process in actor['processes']:
                process.pop('samples_ns', None)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, required=True, help='immutable measured manifest.json; separate corrected test source via --delivered-source')
    parser.add_argument('--delivered-source', type=Path, help='test-corrected source; measured identities stay --source')
    parser.add_argument('--source-equivalence', type=Path, help='qualify_recovery exact test-only exclusion proof')
    parser.add_argument('--native-report', type=Path, required=True)
    parser.add_argument('--products-receipt', type=Path, required=True)
    parser.add_argument('--situations', type=Path, required=True)
    parser.add_argument('--rsc', type=Path, required=True)
    parser.add_argument('--source-guards', type=Path, required=True)
    parser.add_argument('--date', required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--size-report', type=Path)
    parser.add_argument('--pmu-campaign', type=Path, help='fresh completed profile_current.py campaign only')
    parser.add_argument('--profile-receipt', type=Path, action='append', default=[], help='fresh current caller-thread sampling receipt.json')
    parser.add_argument('--extra-text-evidence', type=Path, action='append', default=[])
    parser.add_argument('--rejected-text', type=Path, action='append', default=[], help='explicit rejected receipt/source patch/pilot-summary files only')
    args = parser.parse_args()
    assert re.fullmatch(r'\d{4}-\d{2}-\d{2}', args.date)
    source = args.source.resolve(strict=True)
    source_sha = sha(source)
    delivered = source
    if args.delivered_source:
        delivered = args.delivered_source.resolve(strict=True)

    def check_context():
        if sha(delivered) == source_sha:
            check_source(source)
            return None
        assert args.source_equivalence, 'test-corrected delivery requires explicit source equivalence'
        proof = read(args.source_equivalence)
        assert proof == equivalence(source, delivered)
        return proof

    source_equivalence = check_context()
    delivered_for_reuse = None
    if source_equivalence:
        delivered_for_reuse = delivered
    native = verified_native(args.native_report, source_sha, delivered_for_reuse)
    products = read(args.products_receipt)
    assert products['complete'] and products['phase'] == 'products' and products['source_manifest_sha256'] == source_sha
    product_artifacts = {row['artifact']['target']['name']: row for row in products['artifacts']}
    assert {'scriptw', 'rsc_baseline', 'compiler_precompiled_baseline'} <= product_artifacts.keys()
    for row in product_artifacts.values():
        assert row['artifact']['profile']['test'] is False
        assert row['source_manifest_sha256'] == source_sha and sha(row['frozen_path']) == row['sha256']
        assert sha(row['cargo_stdout']) == row['cargo_stdout_sha256']
    cli_build = [row for row in products['producer_commands'] if row['label'] == 'cli-only-build']
    assert len(cli_build) == 1 and cli_build[0]['exit_code'] == 0
    assert '--example' not in cli_build[0]['argv'] and '--test' not in cli_build[0]['argv']
    guards = SUMMARY.findall(args.source_guards.read_text())
    assert guards and all(row[0] == 'ok' and row[2:] == ('0', '0') for row in guards)
    situations = read(args.situations / 'report.json')
    assert situations['complete'] and situations['status'] == 'complete'
    policy = situations['policy']
    assert len(situations['cases']) == 21 and policy['actors'] == ['scriptw-fast', 'scriptw-speed', 'v8']
    assert policy['warmups'] == 100 and policy['samples'] == 21
    processes = len(situations['cases']) * len(policy['actors']) * policy['blocks'] * policy['processes_per_actor_per_block']
    assert len(situations['rows']) == processes and all(row['status'] == 'ok' for row in situations['rows'])
    assert situations['source_identity']['executable_sha256'] == product_artifacts['compiler_precompiled_baseline']['sha256']
    for case in situations['cases']:
        for actor in policy['actors']:
            runtime = case['runtimes'][actor]
            assert runtime['status'] == 'complete' and len(runtime['processes']) == policy['blocks'] * policy['processes_per_actor_per_block']
            assert all(len(row['samples_ns']) == policy['samples'] for row in runtime['processes'])
        receipts = [row for preparation in situations['preparations'] for row in preparation['cases'] if row['file'] == case['file']]
        assert len(receipts) == 2 and receipts[0]['program_wasm_sha256'] == receipts[1]['program_wasm_sha256']
    for row in situations['retained_files']:
        retained = (args.situations / row['path']).resolve(strict=True)
        assert retained.is_relative_to(args.situations.resolve()) and retained.is_file()
        assert sha(retained) == row['sha256'] and retained.stat().st_size == row['bytes']
    campaign = read(args.rsc / 'campaign.json')
    aggregate = read(args.rsc / 'aggregate.json')
    assert campaign['status'] == 'complete' and len(campaign['processes']) == 24
    assert aggregate['measurement']['campaign_sha256'] == sha(args.rsc / 'campaign.json')
    assert aggregate['measurement']['warmups'] == 3 and aggregate['measurement']['samples'] == 7
    assert aggregate['source_identity']['candidate_measured_source']['manifest_sha256'] == source_sha
    identity = aggregate['engines']['candidate']['identity']
    assert identity['executable_sha256'] == product_artifacts['rsc_baseline']['sha256']
    assert identity['source_fingerprint'] == situations['source_identity']['source_fingerprint']
    balance = {}
    for row in campaign['processes']:
        assert row['status'] == 'complete'
        balance[row['block'], row['engine']] = balance.get((row['block'], row['engine']), 0) + 1
        for field in ('report', 'stdout', 'stderr'):
            assert sha(args.rsc / row[field]) == row[field + '_sha256']
    assert set(balance) == {(b, actor) for b in (0, 1) for actor in ('baseline', 'candidate', 'v8')}
    assert set(balance.values()) == {4}
    baseline = {name: json.loads(git('show', BASE_GIT + ':docs/rust-rewrite/' + name)) for name in REPORTS}
    assert aggregate['engines']['baseline']['identity'] == baseline['rsc-current.json']['engines']['candidate']['identity']
    assert identity['toolchain'] == baseline['rsc-current.json']['engines']['candidate']['identity']['toolchain'], 'IR reuse requires the unchanged toolchain'
    spec = importlib.util.spec_from_file_location('inert_archive', ARCHIVE_TOOL)
    utility = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(utility)
    archive = utility.Archive()
    old_archive = baseline['rsc-current.json']['evidence_archive']
    old_bytes = git('show', BASE_GIT + ':' + old_archive['file'])
    assert hashlib.sha256(old_bytes).hexdigest() == old_archive['sha256'] and len(old_bytes) == old_archive['bytes']
    binding = dict(git=BASE_GIT, evidence_archive=old_archive,
        preservation='Prior full evidence archive remains pinned in checkpoint046c; it is not nested or relabeled current.',
        public_reports={name: dict(path='baseline/reports/' + name, sha256=hashlib.sha256(git('show', BASE_GIT + ':docs/rust-rewrite/' + name)).hexdigest()) for name in REPORTS})
    for name in REPORTS:
        archive.add_bytes('baseline/reports/' + name, git('show', BASE_GIT + ':docs/rust-rewrite/' + name))
    archive.add_bytes('baseline/binding.json', encoded(binding))
    text_tree(archive, source.parent, 'source/measured')
    if source_equivalence:
        text_tree(archive, delivered.parent, 'source/delivered-test-corrected')
        archive.add_file('verification/test-only-source-equivalence.json', args.source_equivalence)
        archive.add_file('verification/compiler_fingerprint.rs', ROOT / 'crates/scriptw-engine/compiler_fingerprint.rs')
        archive.add_file('verification/compiler-build.rs', ROOT / 'crates/scriptw-engine/build.rs')
    text_tree(archive, args.native_report.parent, 'verification/broad')
    text_tree(archive, args.products_receipt.parent, 'verification/products')
    text_tree(archive, args.situations, 'situations')
    text_tree(archive, args.rsc, 'rsc')
    archive.add_file('verification/source-guards.stdout', args.source_guards)
    for path in sorted(BASE.iterdir()):
        if path.is_file() and path.suffix in ('.py', '.json', '.stdout', '.stderr', '.md', '.cjs'):
            archive.add_file('tools-and-receipts/' + path.name, path)
    archive.add_file('tools/inert_archive.py', ARCHIVE_TOOL)
    native_log_roots = [(args.native_report.parent.resolve(), 'verification/broad')]
    if native.get('schema') == 'scriptw-fiber-native-qualified-union-v1':
        for key, prefix in (('original_failed_broad', 'verification/original-unit'), ('original_integration_broad', 'verification/original-integrations')):
            folder = Path(native[key]['path']).parent.resolve()
            assert sha(native[key]['path']) == native[key]['sha256']
            text_tree(archive, folder, prefix)
            native_log_roots.append((folder, prefix))
        recovery_folder = Path(native['corrected_unit_producer']['stdout']).parent.resolve()
        text_tree(archive, recovery_folder, 'verification/recovered-unit')
        native_log_roots.append((recovery_folder, 'verification/recovered-unit'))
    reuse = validate_reuse(read(native['reuse_proof']['path']), source_sha, delivered_for_reuse)
    text_tree(archive, Path(native['reuse_proof']['path']).parent, 'verification/reused')
    coverage = dict(fresh_native=native['scopes'], reused_native=reuse['original_scopes'], reuse_proof=native['reuse_proof'],
        producer_commands=native['producer_commands'], source_guards_passed=sum(int(row[1]) for row in guards),
        source_guards=reference(args.source_guards), cases=len(situations['cases']), actors=len(policy['actors']),
        fresh_execution_processes=processes, checked_invocations=processes * (policy['warmups'] + policy['samples']),
        warmup_invocations=processes * policy['warmups'], measured_invocations=processes * policy['samples'],
        rsc_fresh_processes=len(campaign['processes']), rsc_checked_invocations=len(campaign['processes']) * 2 * 10,
        limits='Fresh Engine lib/integration scopes and current cohorts only. Focused cases overlap full Engine suites. Unchanged AOT/emission/structural/IR scopes are historical reuse with original source/binary identities. Four AOT failures remain failed historical outcomes. Pinned Test262 was not rerun.')
    coverage['fresh_native'] = copy.deepcopy(native['scopes'])
    coverage['producer_commands'] = copy.deepcopy(native['producer_commands'])
    fresh_by_target = {row['target']: row['outcomes'] for row in native['scopes']}
    coverage['fresh_engine_unit_passed'] = fresh_by_target['scriptw_engine']['passed']
    coverage['fresh_engine_integrations'] = dict(total_passed=sum(fresh_by_target[target]['passed'] for target in ENGINE),
        by_target={target: fresh_by_target[target]['passed'] for target in ENGINE})
    coverage['reused_native_totals'] = reuse['totals']
    coverage['retained_preflight_issues'] = reuse['retained_preflight_issues']
    coverage['reuse_proof'] = dict(native['reuse_proof'], archive_path='verification/reused/reuse-proof.json')

    def archive_log_references(row):
        for field in ('stdout', 'stderr'):
            path = Path(row[field]).resolve(strict=True)
            matches = [(folder, prefix) for folder, prefix in native_log_roots if path.is_relative_to(folder)]
            assert len(matches) == 1, 'native log archive root missing/ambiguous'
            folder, prefix = matches[0]
            row[field] = dict(reference(path), archive_path=prefix + '/' + path.relative_to(folder).as_posix())

    for row in (*coverage['fresh_native'], *coverage['producer_commands']):
        if row.get('scope_kind') == 'qualified_union':
            archive_log_references(row['original_failed_full_scope'])
            archive_log_references(row['corrected_filtered_scope'])
            coverage['unit_qualification'] = dict(state='qualified_union', original_passed=row['original_failed_full_scope']['outcomes']['passed'],
                original_failed=row['original_failed_full_scope']['outcomes']['failed'], recovered_passed=row['corrected_filtered_scope']['outcomes']['passed'],
                limits='The original full run remains failed; final unit coverage is preserved passing tests plus the corrected targeted test.')
        else:
            archive_log_references(row)
    measured = dict(path=str(source.parent.relative_to(ROOT)), manifest_sha256=source_sha, manifest=read(source))
    caveats = copy.deepcopy(baseline['situations-current.json']['publication']['caveats'])
    caveats = [value for value in caveats if not value.startswith('Three warmups and seven samples')]
    caveats.append(f"The current situation cohort uses {policy['warmups']} warmups and {policy['samples']} samples per process. V8 retains normal JIT/GC; optimized steady state is not assumed.")
    situations['publication'] = dict(date=args.date, measured_source=measured, coverage=coverage, baseline=binding,
        implementation=['Public embedding execution uses a cached guarded caller-thread fiber; reentry retains a fresh scoped thread and the existing 64 MiB host / 32 MiB Wasm limits.'],
        caveats=caveats)
    if source_equivalence:
        situations['publication']['delivered_source'] = dict(path=str(delivered.parent.relative_to(ROOT)), manifest_sha256=sha(delivered),
            qualification='One authorized test expectation literal only; benchmark/product source remains measured6ea9b.',
            equivalence_archive_path='verification/test-only-source-equivalence.json')
    archive.add_bytes('reports/full-situations-report.json', encoded(situations))
    situations = compact(situations)
    situations['publication']['full_report'] = dict(path='reports/full-situations-report.json', sha256=hashlib.sha256(archive.files['reports/full-situations-report.json']).hexdigest(), bytes=len(archive.files['reports/full-situations-report.json']))
    rsc = copy.deepcopy(aggregate)
    rsc.update(schema='scriptw-rsc-current-v1', date=args.date,
        publication=dict(date=args.date, measured_source=measured, coverage_reference='reports/full-situations-report.json'),
        baseline_diagnostics=dict(scope='Historical reports only; original P/R and original worker-only PMU boundaries retained. No prior allocation/counter/sample values are asserted current.',
            reports={name: binding['public_reports'][name] for name in ('react-allocation-current.json', 'react-attribution-current.json', 'rsc-wasm-size-current.json')},
            identity=baseline['rsc-current.json']['engines']['candidate']['identity']))
    rsc['source_identity']['candidate_measured_source'] = measured
    rsc['source_identity']['broad_qualification_complete'] = True
    rsc['source_identity'].pop('prototype_only', None)
    if source_equivalence:
        rsc['publication']['delivered_source'] = situations['publication']['delivered_source']
    fresh_reports = {}
    if args.pmu_campaign:
        fresh_reports['react-attribution-current.json'] = current_pmu(args.pmu_campaign, identity, source_sha, args.date, archive)
    if args.profile_receipt:
        sampling = []
        for path in args.profile_receipt:
            receipt = read(path)
            assert receipt['status'] == 'captured' and receipt['unscored'] is True
            assert receipt['execution_target'] == 'authenticated-caller-socket' and receipt['control_edges_included'] is True
            assert receipt['executable_sha256'] == identity['executable_sha256']
            assert receipt['worker_before']['barrier_authentication']['socket_inode'] > 0
            assert receipt['worker_after']['tid'] == receipt['worker_before']['tid']
            assert receipt['worker_after']['starttime_ticks'] == receipt['worker_before']['starttime_ticks']
            observed = read(path.parent / 'observations.json')
            assert all(observed[key] == value for key, value in identity.items())
            assert observed['profiling']['excluded_from_scored_cohorts'] is True
            assert observed['cases'][0]['exact_node_output_checked'] is True
            text_tree(archive, path.parent, 'diagnostics/current-sampling/' + path.parent.name)
            sampling.append(reference(path))
        rsc['current_sampling'] = dict(receipts=sampling,
            limits='Fresh current caller-thread user samples include control edges. Frame-pointer chains may be incomplete; historical worker-only samples remain baseline. No scored timing/allocation claim.')
    if args.size_report:
        size = read(args.size_report)
        assert size['schema'] == 'scriptw-rsc-wasm-size-current-v1'
        assert size['program_wasm_sha256'] == identity['program_wasm_sha256'] and size['runtime_wasm_sha256'] == identity['runtime']['wasm_sha256']
        assert size['aggregate']['sha256'] == sha(args.rsc / 'aggregate.json')
        assert size['accounted_program_bytes'] == size['program_wasm_bytes']
        assert size['compiler']['executable_sha256'] == identity['executable_sha256']
        assert size['compiler']['source_fingerprint'] == identity['source_fingerprint']
        archive.add_file('reports/rsc-wasm-size-current.json', args.size_report)
        rsc['static_program_size'] = dict(reference(args.size_report), archive_path='reports/rsc-wasm-size-current.json',
            program_wasm_sha256=size['program_wasm_sha256'], program_wasm_bytes=size['program_wasm_bytes'])
    for path in args.extra_text_evidence:
        path = path.resolve(strict=True)
        assert path.is_relative_to(ROOT / 'target')
        if path.is_dir():
            text_tree(archive, path, 'additional-evidence/' + path.relative_to(ROOT).as_posix())
        else:
            archive.add_file('additional-evidence/' + path.relative_to(ROOT).as_posix(), path)
    for path in args.rejected_text:
        path = path.resolve(strict=True)
        assert path.is_file() and path.is_relative_to(ROOT / 'target') and path.suffix in ('.json', '.patch', '.stdout', '.stderr', '.md')
        archive.add_file('rejected-prototypes/' + path.relative_to(ROOT).as_posix(), path)
    reports = {'situations-current.json': situations, 'rsc-current.json': rsc, **fresh_reports}
    for name, value in reports.items():
        archive.add_bytes('reports/' + name, encoded(value))
    destination = args.output.resolve()
    assert destination.is_relative_to(ROOT / 'target') and not destination.exists()
    destination.mkdir(parents=True)
    metadata = archive.write(destination / ('situations-evidence-' + args.date + '-fiber-only.tar.xz'))
    with tarfile.open(ROOT / metadata['file'], 'r:xz') as packed:
        index_bytes = packed.extractfile('INDEX.json').read()
        assert packed.extractfile('INDEX.json.sha256').read().decode().strip() == hashlib.sha256(index_bytes).hexdigest() + '  INDEX.json'
        index = json.loads(index_bytes)
        for row in index['members']:
            value = packed.extractfile(row['path']).read()
            assert len(value) == row['bytes'] and hashlib.sha256(value).hexdigest() == row['sha256']
        assert len(packed.getmembers()) == len(index['members']) + 2
    public_metadata = dict(metadata, file='docs/rust-rewrite/' + Path(metadata['file']).name)
    assert public_metadata['file'] != old_archive['file'], 'preserve the checkpoint archive path'
    for name, value in reports.items():
        save(destination / name, dict(value, evidence_archive=public_metadata))
    if args.size_report:
        save(destination / 'rsc-wasm-size-current.json', read(args.size_report))
    files_to_publish = [Path(public_metadata['file']).name, *reports]
    if args.size_report:
        files_to_publish.append('rsc-wasm-size-current.json')
    check_context()
    save(destination / 'publication-ready.json', dict(complete=True, source_manifest_sha256=source_sha,
        reports=list(reports), files_to_publish=files_to_publish, evidence_archive=public_metadata, staged_archive=metadata, canonical_files_written=False,
        current_diagnostics='No old allocation, PMU or sampled CPU report is relabeled current. Fresh diagnostics may be archived explicitly as additional evidence.'))
    print('VERIFIED INERT PUBLICATION STAGE READY', destination, flush=True)


if __name__ == '__main__':
    main()
