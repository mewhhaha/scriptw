(function () {
  print(new Intl.NumberFormat('en-US', {
    useGrouping: false,
    minimumFractionDigits: 1,
    maximumFractionDigits: 1
  }).format(12345.6));
})();
