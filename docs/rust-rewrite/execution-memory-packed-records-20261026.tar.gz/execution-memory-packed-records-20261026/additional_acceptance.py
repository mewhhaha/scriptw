"""Close final rustdoc/embedding examples and the exact fresh Test262 inventory."""
import subprocess
from campaign_runtime import own, REPO, require

for name in ['extra_acceptance.py', 'validate_inventory.py']:
    require(subprocess.call(own(name), cwd=REPO) == 0, name + ' failed; retain observations')
