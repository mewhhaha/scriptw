"""Run the complete corrected structural target with fresh source-bound receipts."""
from campaign_runtime import check, cargo_target, inventory, native_result, BASE

scope = dict(package='scriptw-aot-wasm', kind='--test', name='structure_async')
label = 'broad-04-scriptw-aot-wasm-structure_async'
command = cargo_target(scope)
enumeration = check(label + '-inventory', command + ['--', '--list', '--include-ignored'])
names = inventory((BASE / enumeration['log']).read_text())
result = check(label, command + ['--', '--test-threads=1', '--include-ignored'])
assert result['executables'] == enumeration['executables']
native_result(result, names)
print('Complete corrected structure_async:', len(names), 'passed', flush=True)
