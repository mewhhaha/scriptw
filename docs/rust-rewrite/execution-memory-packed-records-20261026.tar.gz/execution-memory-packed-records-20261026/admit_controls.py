"""Validate pure campaign controls and admit exact native/allocation observations."""
import subprocess
import sys
from campaign_runtime import BASE, REPO, check, own, require

check('campaign-controls', [sys.executable, '-B', '-m', 'unittest', 'discover',
                           '-s', str(BASE), '-p', 'test_*.py', '-v'])
for arguments in [
    ['accept_native.py'],
    ['publish_evidence.py', '--section', 'native'],
    ['publish_evidence.py', '--section', 'allocation', '--write-allocation-comparison'],
]:
    require(subprocess.call(own(*arguments), cwd=REPO) == 0,
            'admission failed; preserve observations: ' + ' '.join(arguments))
