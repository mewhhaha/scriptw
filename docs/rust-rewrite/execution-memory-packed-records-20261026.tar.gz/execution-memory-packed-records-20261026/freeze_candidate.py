"""Independently freeze three actual completed Cargo products; no import work."""
from datetime import datetime,timezone
from pathlib import Path
import json
import subprocess
from campaign_runtime import BASE, REPO, actual_source, require_scope, require, read, digest, checked_receipt, own, save_new


def main():
    source=actual_source();require_scope()
    checked_receipt('release-products',own('build_product.py'))
    rows=[json.loads(line) for line in (BASE/'cargo-product.jsonl').read_text().splitlines()]
    require(rows and rows[-1]=={'reason':'build-finished','success':True},'actual Cargo product build is incomplete/failed')
    names={'scriptw','runtime_baseline','runtime_boundaries'}
    products={Path(row['executable']).name:row for row in rows if row.get('reason')=='compiler-artifact'
              and row.get('executable') and Path(row['executable']).name in names}
    require(set(products)==names,'actual default Cargo producer inventory differs')
    output=BASE/'candidate';require(not output.exists() and not (BASE/'frozen-products.json').exists(),'candidate freeze must be new')
    output.mkdir()
    manifest=dict(source_commit=source,frozen_at=datetime.now(timezone.utc).isoformat(),products={})
    for name,row in products.items():
        require(row['profile']['opt_level']=='3' and row['profile']['test'] is False and row['features']==[],
                'candidate was not built using the actual default opt3 product profile')
        original=Path(row['executable']);target=output/name
        subprocess.run(['cp','--reflink=auto',str(original),str(target)],cwd=REPO,check=True)
        require(target.stat().st_nlink==1 and digest(target)==digest(original),'frozen product is not independent/exact')
        manifest['products'][name]=dict(path=str(target),actual_cargo_product=str(original),sha256=digest(target),bytes=target.stat().st_size,cargo_producer=row)
    identity=json.loads(subprocess.check_output([str(output/'scriptw'),'compiler-identity'],cwd=REPO))
    require(identity['source_revision']==dict(kind='git-commit',commit=source)
            and identity['executable_sha256']==manifest['products']['scriptw']['sha256'],'actual frozen CLI source/identity differs')
    save_new(output/'identity.json',identity);save_new(BASE/'frozen-products.json',manifest)
    print('FROZEN ACTUAL DEFAULT RELEASE PRODUCTS',source,flush=True)


if __name__=='__main__':main()
