"""Admit explicit mixed-source coverage; only the corrected target runs fresh."""
from campaign_runtime import own, REPO, actual_source, require_scope, require
import subprocess


def main():
    actual_source(); require_scope()
    require(subprocess.call(own('native_final.py'),cwd=REPO)==0,'fresh native/unchanged-scope coverage did not close')


if __name__=='__main__': main()
