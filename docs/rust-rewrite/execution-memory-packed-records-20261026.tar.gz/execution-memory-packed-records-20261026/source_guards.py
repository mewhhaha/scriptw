"""Observe actual baseline4d1/current source guards; no compiler/native execution.

The ignored baseline snapshot is reconstructed from the exact Git commit. Both
aggregate and isolated terminal source controls retain actual exit codes, raw
logs and complete before/after source-hash manifests. Baseline failure is never
relabelled acceptance or silently waived.
"""
from datetime import datetime,timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tarfile
import time

from campaign_runtime import BASE,REPO,actual_source,require_scope,require,digest,save_new

BASELINE='4d1b41e3221687d1163967bcc0d94155393c906e'
ROOTS=['crates','scripts','docs/rust-rewrite/contracts','README.md','Cargo.toml','Cargo.lock',
       'vendor']
TERMINAL='scripts/check-native-program-templates.py'


def stamp():return datetime.now(timezone.utc).isoformat()


def manifest(root):
    paths=[]
    for name in ROOTS:
        path=root/name
        if path.is_file():paths.append(path)
        elif path.is_dir():paths.extend(x for x in path.rglob('*') if x.is_file() and not x.is_symlink() and '__pycache__' not in x.parts)
    return {str(path.relative_to(root)):dict(bytes=path.stat().st_size,sha256=digest(path)) for path in sorted(set(paths))}


def observe(role,source,root,kind):
    label=f'source-guard-{role}-{kind}';output=BASE/(label+'.log')
    require(not output.exists() and not (BASE/(label+'.json')).exists(), 'source guard observation cannot overwrite an older run')
    before=manifest(root);start=stamp();clock=time.monotonic()
    command=['bash','scripts/check-module-boundaries.sh'] if kind=='aggregate' else [sys.executable,'-B',TERMINAL,'.']
    with output.open('x') as stream:actual=subprocess.run(command,cwd=root,stdout=stream,stderr=subprocess.STDOUT)
    after=manifest(root);require(before==after,'source guard mutated/read unstable source inputs')
    inputs=BASE/(label+'-inputs.json')
    save_new(inputs,dict(schema='scriptw-source-guard-inputs-v1',source_commit=source,root=str(root),files=before,stable_before_after=True))
    prefixes=('check-module-boundaries:','native program templates:')
    diagnostics=[line for line in output.read_text().splitlines() if line.startswith(prefixes) and line!='check-module-boundaries: ok']
    require(actual.returncode in [0,1] and (actual.returncode==0 or diagnostics), 'source guard stopped without an auditable diagnostic')
    row=dict(schema='scriptw-source-guard-observation-v1',role=role,kind=kind,source_commit=source,root=str(root),command=command,
        actual_exit_code=actual.returncode,started_at=start,finished_at=stamp(),seconds=time.monotonic()-clock,
        log=output.name,log_sha256=digest(output),source_inputs=inputs.name,source_inputs_sha256=digest(inputs),
        stable_before_after=True,diagnostics=diagnostics,scope='Source-only guard; no Cargo/rustc/native runtime child.')
    save_new(BASE/(label+'.json'),row);return row


def main():
    source=actual_source();require_scope();snapshot=BASE/'baseline-source-guards'
    require(not snapshot.exists() and not (BASE/'source-tooling.json').exists(),'baseline source/tooling observation must be new')
    snapshot.mkdir()
    process=subprocess.Popen(['git','archive','--format=tar',BASELINE,*ROOTS],cwd=REPO,stdout=subprocess.PIPE)
    with tarfile.open(fileobj=process.stdout,mode='r|') as archive:
        for member in archive:
            relative=Path(member.name)
            require(not relative.is_absolute() and '..' not in relative.parts and (member.isfile() or member.isdir()),'unexpected Git archive member')
            target=snapshot/relative
            if member.isdir():target.mkdir(parents=True,exist_ok=True)
            else:
                target.parent.mkdir(parents=True,exist_ok=True)
                with archive.extractfile(member) as raw,target.open('xb') as out:
                    while chunk:=raw.read(256*1024):out.write(chunk)
    require(process.wait()==0,'actual baseline4d1 Git archive failed')
    rounds={role:{kind:observe(role,commit,root,kind) for kind in ['aggregate','terminal']}
            for role,commit,root in [('baseline',BASELINE,snapshot),('current',source,REPO)]}
    old,new=rounds['baseline'],rounds['current']
    new_diagnostics=sorted(set(new['aggregate']['diagnostics'])-set(old['aggregate']['diagnostics']))
    terminal_new=sorted(set(new['terminal']['diagnostics'])-set(old['terminal']['diagnostics']))
    result=dict(schema='scriptw-memory-admission-source-tooling-v1',complete=True,baseline_source=BASELINE,candidate_source=source,
        observations=rounds,new_aggregate_diagnostics=new_diagnostics,new_terminal_diagnostics=terminal_new,
        full_tooling_passed=all(row['actual_exit_code']==0 for row in new.values()),
        no_new_observed_diagnostics=not new_diagnostics and not terminal_new,
        scope='Actual baseline4d1/current aggregate and independent terminal observations; failures remain counted. '
              'Large source snapshots are excluded from publication. No native/test/performance denominator contribution.')
    save_new(BASE/'source-tooling.json',result)
    require(result['no_new_observed_diagnostics'],'new source-guard diagnostics require investigation; actual observations retained')
    print(json.dumps(dict(observed=True,full_tooling_passed=result['full_tooling_passed'],new_diagnostics=[])),flush=True)


if __name__=='__main__':main()
