"""Build the three actual default release products once; no import work."""
import subprocess
from campaign_runtime import BASE, REPO, actual_source, require_scope, require


def main():
    actual_source(); require_scope()
    out, err = BASE/'cargo-product.jsonl', BASE/'cargo-product.stderr'
    require(not out.exists() and not err.exists(), 'closed/partial Cargo producer evidence cannot be overwritten')
    command=['cargo','build','--locked','--offline','--release','--jobs','1','-p','scriptw-cli','--bin','scriptw',
             '--example','runtime_baseline','--example','runtime_boundaries','--message-format=json']
    with out.open('x') as stdout, err.open('x') as stderr:
        result=subprocess.run(command,cwd=REPO,stdout=stdout,stderr=stderr)
    print(err.read_text()[-3000:],flush=True)
    raise SystemExit(result.returncode)


if __name__=='__main__': main()
