"""Review a pure plan, or explicitly run only the real committed candidate.

Default and --plan-only launch no work. Root must request --run within the
existing one-CPU/4GiB/no-swap/grouped-OOM scope after actual campaign.json exists.
This driver never invents/fills a candidate hash, deletes caches or publishes.
"""
import argparse
import json
import subprocess
from campaign_runtime import BASE,REPO,actual_source,require_scope,check,own,require


def steps():
    return [
        ('source-guards',own('source_guards.py')),
        ('release-products',own('build_product.py')),
        ('freeze-candidate',own('freeze_candidate.py')),
        ('freeze-candidate-allocation-inputs',own('freeze_candidate_link_inputs.py','--freeze')),
        ('allocation-diagnostic-candidate',own('candidate_engine_allocation_diagnostic.py','--run')),
        (None,own('publish_evidence.py','--section','allocation','--write-allocation-comparison')),
        (None,own('build_native.py')),
        (None,own('finish_campaign.py')),
    ]


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run',action='store_true');parser.add_argument('--plan-only',action='store_true')
    args=parser.parse_args();require(not(args.run and args.plan_only),'choose review or explicit execution')
    if not args.run:
        print(json.dumps(dict(execution=False,candidate_authority='actual committed campaign.json + actual candidate/identity.json, never a placeholder',
            stages=[dict(receipt=label,command=command) for label,command in steps()],
            final_gate='read-only full publication admission; no --publish in this driver'),indent=2));return
    source=actual_source();require_scope()
    for label,command in steps():
        if label is not None:check(label,command)
        elif '--write-allocation-comparison' in command and (BASE/'allocation-comparison.json').exists():
            result=subprocess.call([item for item in command if item!='--write-allocation-comparison'],cwd=REPO)
            require(result==0,'existing derived allocation comparison failed read-only admission')
        else:
            result=subprocess.call(command,cwd=REPO);require(result==0,'actual campaign stage failed; retain observations')
    print('COMPLETE ACTUAL CANDIDATE',source,'PUBLICATION REMAINS SEPARATE',flush=True)


if __name__=='__main__':main()
