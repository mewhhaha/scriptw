"""Run the real trust-token doctest and embedding examples, outside native totals."""
from pathlib import Path
from campaign_runtime import BASE,actual_source,require_scope,check,read


def main():
    actual_source();require_scope()
    check('receipt-authority-doctest',['cargo','test','--locked','--offline','--release','--jobs','1','-p','scriptw-aot-wasm','--doc'])
    check('trust-token-doctest',['cargo','test','--locked','--offline','--release','--jobs','1','-p','scriptw-intl-build-data','--doc'])
    check('typed-number-doctest',['cargo','test','--locked','--offline','--release','--jobs','1','-p','scriptw-intl','--doc'])
    check('embedding-examples-build',['cargo','build','--locked','--offline','--release','--jobs','1','-p','scriptw-engine',
        '--example','foreign_modules','--example','retained_embedding'])
    frozen=read(BASE/'frozen-products.json')
    directory=Path(frozen['products']['runtime_baseline']['actual_cargo_product']).parent
    for name in ['foreign_modules','retained_embedding']:check('example-'+name,[str(directory/name)])


if __name__=='__main__':main()
