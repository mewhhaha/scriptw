"""Continue unrun focused diagnostics after a failure; never overwrite or admit acceptance."""
import json,subprocess,sys
from campaign_runtime import BASE,REPO,actual_source,require_scope,read,own,save_new

def main():
    source=actual_source();require_scope();rows=[]
    for item in read(BASE/'focused-plan.json')['checks']:
        path=BASE/(item['label']+'.json')
        if not path.exists():
            command=['cargo','test','--locked','--offline','--release','--jobs','1','-p',item['package'],
                     *item['target'],item['pattern'],'--','--test-threads=1','--include-ignored']
            code=subprocess.call(own('run_check.py',item['label'],*command),cwd=REPO)
            print(item['label'],'actual exit',code,flush=True)
        row=read(path)
        rows.append(dict(label=item['label'],exit_code=row['exit_code'],test_results=row.get('test_results')))
    assert actual_source()==source
    result=dict(source_commit=source,complete=True,acceptance=False,focused=rows,
                scope='Original committed source after first failure; all existing failed receipts retained. Not a successful native checkpoint.')
    save_new(BASE/'continued-focused-diagnostics.json',result)
    print(json.dumps(result),flush=True)
    raise SystemExit(1 if any(r['exit_code'] for r in rows) else 0)
if __name__=='__main__':main()
