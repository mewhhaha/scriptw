"""Development-only whole-batch type check; excluded from native acceptance totals."""
import hashlib,json,os,subprocess,sys,time
from datetime import datetime,timezone
from pathlib import Path
BASE=Path(__file__).resolve().parent
REPO=BASE.parent.parent
sys.path.insert(0,str(REPO/'scripts'))
from limited_verification import require_kernel_budget

def digest(path):
    with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def source():
    roots=['crates','vendor','Cargo.toml','Cargo.lock','scripts','README.md','docs/rust-rewrite/contracts']
    patch=subprocess.check_output(['git','diff','--binary','HEAD','--',*roots],cwd=REPO)
    names=subprocess.check_output(['git','ls-files','--others','--exclude-standard','--',*roots],cwd=REPO,text=True).splitlines()
    return dict(source_base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip(),
                tracked_patch=patch.decode(),tracked_patch_sha256=hashlib.sha256(patch).hexdigest(),
                new_files={n:dict(bytes=(REPO/n).stat().st_size,sha256=digest(REPO/n)) for n in names})
def main():
    label=sys.argv[1];log=BASE/(label+'.log');receipt=BASE/(label+'.json')
    if log.exists() or receipt.exists():raise SystemExit('refusing to overwrite actual development observation')
    require_kernel_budget(4*1024**3)
    assert sorted(os.sched_getaffinity(0))==[0]
    before=source();started=datetime.now(timezone.utc).isoformat();clock=time.monotonic()
    command=['cargo','check','--locked','--offline','--release','--jobs','1','-p','scriptw-aot-wasm',
             '-p','scriptw-engine','-p','scriptw-cli','-p','wasmtime-internal-cranelift','--all-targets']
    with log.open('x') as out:result=subprocess.run(command,cwd=REPO,stdout=out,stderr=subprocess.STDOUT)
    after=source()
    report=dict(schema='scriptw-development-foundation-check-v1',label=label,command=command,
        source_before=before,source_stable=before==after,exit_code=result.returncode,
        started_at=started,finished_at=datetime.now(timezone.utc).isoformat(),seconds=time.monotonic()-clock,
        log=log.name,log_sha256=digest(log),cpu_affinity=sorted(os.sched_getaffinity(0)),
        scope='Dirty development source explicitly recorded; not an accepted committed product, native-test or benchmark receipt.')
    with receipt.open('x') as out:out.write(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:report[k] for k in ['label','source_stable','exit_code','seconds']}),flush=True)
    raise SystemExit(result.returncode if before==after else 2)
if __name__=='__main__':main()
