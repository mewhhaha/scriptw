"""Admit the fresh candidate full inventory before the exact selected replay."""
from campaign_runtime import BASE,actual_source,require_scope,read,check,require,digest,save_new
from campaign_identity import checked_identity
import sys


def main():
    source=actual_source();require_scope();plan=read(BASE/'selected-scopes.json')
    row=check('conformance-inventory-final',[str(BASE/'candidate/scriptw'),'--jobs','1','test262','list-all',
        '--suite-root','test262/vendor/test262'])
    sys.path.insert(0,str(BASE.parent.parent/'scripts'))
    from test262_execution_batches import native_inventory
    path=BASE/row['log'];names=native_inventory(path.read_text())
    require(len(names)==plan['source_inventory_execution_count'] and digest(path)==plan['source_inventory_sha256'],
            'fresh candidate full pinned inventory differs; investigate before replay')
    from campaign import family_selectors, scope_matches
    require([row['selector'] for row in plan['scopes']] == family_selectors(), 'closed selected predicates changed')
    selected=set()
    for scope in plan['scopes']:
        actual=sorted(name for name in names if scope_matches(name,scope['selector']))
        require(actual==scope['execution_ids'] and len(actual)==scope['count'] and not selected.intersection(actual),
                'complete affected selected family differs: '+str(scope['selector']))
        selected.update(actual)
    selected.update(plan['known_failure_controls'])
    require(sorted(selected)==(BASE/'selected.ids').read_text().splitlines()
            and len(selected)==plan['selected_total']==plan['selected_execution_count'],'exact selected union differs')
    report=dict(complete=True,source_head=source,compiler_identity=checked_identity('candidate'),receipt=row['label']+'.json',
        inventory_sha256=digest(path),total=len(names),selected_total=len(selected),selected_ids_sha256=digest(BASE/'selected.ids'),
        scope_plan_sha256=digest(BASE/'selected-scopes.json'))
    output=BASE/'conformance-inventory-validated.json'
    if output.exists():require(read(output)==report,'closed full inventory admission differs')
    else:save_new(output,report)
    print('FRESH FULL INVENTORY AND COMPLETE SELECTED UNION VERIFIED',len(names),len(selected),flush=True)


if __name__=='__main__':main()
