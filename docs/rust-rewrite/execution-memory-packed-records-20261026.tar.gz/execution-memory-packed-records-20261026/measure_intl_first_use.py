#!/usr/bin/env python3
"""Separate Intl first-use diagnostic; no builds, retries or scored-corpus edits.

Run only through the campaign's outer run_check under one CPU and a 4-GiB cap.
All first/warm/measured observations and raw streams are retained unchanged.
"""
from campaign_identity import product_directory
import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

from campaign_identity import (BASE, candidate_source, digest, environment_receipt,
                               frozen_product, ordinary_environment, read, require)

REPO = BASE.parent.parent
FIXTURES = BASE / 'intl-first-use-fixtures'
OUTPUT = BASE / 'intl-first-use-data'
LABEL = 'intl-first-use'
CASE = 'intl-number-first-use.js'
EXPECTED = '12345.6\n'
SAMPLES, WARMUPS = 7, 10
NODE_HARNESS = REPO / 'crates/scriptw-cli/tests/fixtures/v8_baseline/node-runtime.cjs'
SOURCE = """(function () {
  print(new Intl.NumberFormat('en-US', {
    useGrouping: false,
    minimumFractionDigits: 1,
    maximumFractionDigits: 1
  }).format(12345.6));
})();
"""
sys.path.insert(0, str(REPO / 'scripts'))
from limited_verification import require_kernel_budget


def stamp():
    return datetime.now(timezone.utc).isoformat()


def fixture_plan():
    manifest = read(FIXTURES / 'manifest.json')
    require(manifest.get('schema') == 'scriptw-v8-workloads-v1'
            and len(manifest.get('execution', [])) == 1, 'need the separate one-case manifest')
    case = manifest['execution'][0]
    require(case['file'] == CASE and case['stdout'] == EXPECTED
            and (FIXTURES / CASE).read_bytes() == SOURCE.encode(), 'Intl fixture or expected output changed')
    return case


def run():
    require_kernel_budget(4 * 1024**3)
    require(sorted(os.sched_getaffinity(0)) == [0], 'the diagnostic requires CPU0 only')
    case = fixture_plan()
    products = {product: frozen_product(product) for product in ('baseline', 'candidate')}
    node = Path(shutil.which('node') or '/missing-node').resolve()
    require(node.is_file(), 'actual Node executable is required')
    OUTPUT.mkdir(exist_ok=False)
    harness = OUTPUT / 'node-runtime.cjs'
    shutil.copyfile(NODE_HARNESS, harness)
    dependencies = [BASE / name for name in ('campaign_identity.py', 'analyze.py',
                                             'analyze_intl_first_use.py')]
    dependencies.append(REPO / 'scripts/limited_verification.py')
    report = dict(schema='scriptw-intl-first-use-diagnostic-v1', complete=False,
                  label=LABEL, campaign_source=candidate_source(), samples=SAMPLES, warmups=WARMUPS,
                  excluded_from_scored_cohorts=True, fixture=case,
                  fixture_source_sha256=digest(FIXTURES / CASE),
                  fixture_manifest_sha256=digest(FIXTURES / 'manifest.json'),
                  driver_sha256=digest(__file__),
                  dependencies={str(path.relative_to(REPO)): digest(path) for path in dependencies},
                  node=dict(path=str(node), sha256=digest(node)),
                  node_harness=dict(path=harness.name, sha256=digest(harness)),
                  started_at=stamp(), affinity=sorted(os.sched_getaffinity(0)),
                  loadavg_start=list(os.getloadavg()), commands=[], products={},
                  scope='One precompiled source per child; first warmup is the first actual Intl execution in that process. '
                        'Each iteration uses a fresh Store/Realm or V8 context; operation providers/process state may persist. '
                        'Whole-invocation RSS includes admission, native mappings, setup and execution; not an isolated Intl '
                        'allocation count, live JavaScript heap or synchronized cross-engine peak. '
                        'The seven steady observations remain separate from all ten warmups and the 17 scored workloads.')

    def save():
        pending = OUTPUT / 'report.pending'
        pending.write_text(json.dumps(report, indent=2) + '\n')
        pending.replace(OUTPUT / 'report.json')

    def invoke(label, command, binary, environment):
        event = dict(label=label, command=list(map(str, command)), cwd=str(REPO),
                     state='running', started_at=stamp(), stdout_file=label + '.stdout',
                     stderr_file=label + '.stderr')
        report['commands'].append(event)
        save()
        require(digest(binary['path']) == binary['sha256'], 'executed binary changed before launch')
        started = time.monotonic()
        stdout, stderr = OUTPUT / event['stdout_file'], OUTPUT / event['stderr_file']
        try:
            with stdout.open('xb') as out, stderr.open('xb') as err:
                child = subprocess.run(command, cwd=REPO, env=environment, stdout=out,
                                       stderr=err, timeout=900)
            event.update(exit_code=child.returncode, timed_out=False)
        except subprocess.TimeoutExpired:
            event.update(exit_code=None, timed_out=True)
        event.update(state='finished', finished_at=stamp(), wall_seconds=time.monotonic() - started,
                     stdout_sha256=digest(stdout), stderr_sha256=digest(stderr))
        save()
        require(digest(binary['path']) == binary['sha256'], 'executed binary changed during invocation')
        require(event['exit_code'] == 0 and not event['timed_out'], 'child failed: ' + label)
        event['data'] = read(stdout)
        save()
        return label, event['data']

    save()
    try:
        for product in ('baseline', 'candidate'):
            identity, hashes = products[product]
            directory = product_directory(product)
            environment = ordinary_environment()
            environment['SCRIPTW_CACHE_DIR'] = str(OUTPUT / (product + '-execution-cache'))
            order = ['wasmtime', 'v8'] if product == 'baseline' else ['v8', 'wasmtime']
            row = dict(compiler_identity=identity, frozen_product_sha256=hashes,
                       environment=environment_receipt(environment), runtime_order=order,
                       runtimes={}, binaries={
                           'scriptw': dict(path=str(directory / 'scriptw'), sha256=hashes['scriptw']),
                           'wasmtime': dict(path=str(directory / 'runtime_baseline'), sha256=hashes['runtime_baseline']),
                           'v8': report['node']})
            report['products'][product] = row
            save()
            command_label, actual = invoke(product + '-identity',
                [directory / 'scriptw', 'compiler-identity'], row['binaries']['scriptw'], environment)
            row['identity_command'] = command_label
            require(actual == identity, 'actual frozen CLI identity differs')
            for runtime in order:
                if runtime == 'wasmtime':
                    artifacts = OUTPUT / (product + '-wasm')
                    artifacts.mkdir(exist_ok=False)
                    command = [directory / 'runtime_baseline', FIXTURES, '7', '10', CASE, artifacts]
                else:
                    command = [node, harness, FIXTURES, '7', '10', CASE]
                command_label, actual = invoke(product + '-' + runtime, command,
                                               row['binaries'][runtime], environment)
                row['runtimes'][runtime] = command_label
                require(actual['samples'] == SAMPLES and actual['warmups'] == WARMUPS
                        and len(actual['cases']) == 1, 'child denominator differs')
                observed = actual['cases'][0]
                values = observed['observations']
                require(observed['file'] == CASE and observed['source_sha256'] == report['fixture_source_sha256']
                        and len(values) == WARMUPS + SAMPLES
                        and [value['warmup'] for value in values] == [True] * WARMUPS + [False] * SAMPLES
                        and all(value['stdout'] == EXPECTED for value in values), 'actual Intl source/output/order differs')
                if runtime == 'wasmtime':
                    require(actual['schema'] == 'scriptw-wasmtime-baseline-v2'
                            and actual['source_commit'] == identity['source_revision']['commit']
                            and actual['source_fingerprint'] == identity['source_fingerprint']
                            and actual['executable_sha256'] == hashes['runtime_baseline']
                            and actual['requested_native_policy'] is None, 'actual Wasmtime source/bytes/policy differs')
                else:
                    require(actual['schema'] == 'scriptw-v8-baseline-v2', 'Node schema differs')
                require(digest(harness) == report['node_harness']['sha256'], 'actual Node harness changed')
                save()
            require(frozen_product(product) == products[product], 'frozen product changed during diagnostic')
        report.update(complete=True, finished_at=stamp(), loadavg_end=list(os.getloadavg()))
    except BaseException as error:
        report['failure'] = str(error)
        raise
    finally:
        save()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan-only', action='store_true')
    args = parser.parse_args()
    if args.plan_only:
        print(json.dumps(dict(label=LABEL, output=str(OUTPUT), fixture=fixture_plan(),
                              samples=SAMPLES, warmups=WARMUPS, products=['baseline', 'candidate'],
                              excluded_from_scored_cohorts=True), indent=2))
    else:
        run()


if __name__ == '__main__':
    try:
        main()
    except (KeyError, ValueError, OSError, TypeError, subprocess.SubprocessError) as error:
        raise SystemExit('Intl first-use measurement refused: ' + str(error))
