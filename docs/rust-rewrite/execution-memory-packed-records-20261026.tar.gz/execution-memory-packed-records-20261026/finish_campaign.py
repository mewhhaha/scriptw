"""Close native/selected admission before running the eight scored rounds."""
import importlib.util
import subprocess
import sys
from campaign_runtime import BASE,REPO,actual_source,require_scope,require,read,check,own


def run(name,*arguments):
    code=subprocess.call(own(name,*arguments),cwd=REPO)
    require(code==0,'campaign stage failed; preserve the actual observations: '+name)


def main():
    actual_source();require_scope()
    for name in ['accept_native.py','focused_acceptance.py','extra_acceptance.py','validate_inventory.py']:run(name)
    native=read(BASE/'native-coverage.json')
    require(native['complete'] is True and len(native['targets'])==32,'all32 actual native targets must close before replay')
    command=[sys.executable,'-B','scripts/replay-test262-executions.py',str(BASE/'selected.ids'),'--binary',str(BASE/'candidate/scriptw'),
        '--suite-root','test262/vendor/test262','--output-dir',str(BASE/'conformance'),'--workers','1','--reuse-case-workers']
    check('conformance-final',command,expected=1)
    spec=importlib.util.spec_from_file_location('admission_publication',BASE/'publish_evidence.py')
    publication=importlib.util.module_from_spec(spec);spec.loader.exec_module(publication)
    replay=publication.conformance(publication.Evidence())
    require(replay['total']==read(BASE/'selected-scopes.json')['selected_total'] and replay['bug']==4
            and replay['crash']==replay['not_implemented']==replay['timeout']==0,'actual selected conformance differs')
    print('SELECTED CONFORMANCE RECONCILED',replay['passed'],'/',replay['total'],flush=True)
    run('measure_all.py')
    check('intl-first-use',own('measure_intl_first_use.py'))
    run('analyze_intl_first_use.py')
    check('precompiled-example-build',own('build_precompiled.py'))
    check('precompiled-execution',own('measure_precompiled.py','--run'))
    run('analyze_precompiled.py')
    for name in ['analyze.py','analysis_calls.py','analyze_intl_first_use.py','analyze_precompiled.py']:run(name,'--check')
    run('publish_evidence.py')
    print('ALL ACTUAL NATIVE/SELECTED/ALLOCATION AND ORDINARY COHORTS CLOSED; PUBLICATION NOT REQUESTED',flush=True)


if __name__=='__main__':main()
