"""Execute the complete corrected target, then derive mixed-source coverage."""
import hashlib, importlib.util, sys
from campaign_runtime import BASE, actual_source, require_scope, check, read, require, inventory, native_result, save_new
from source_equivalence import admit, OWNER


def main():
    source=actual_source(); require_scope(); admit()
    label='broad-04-scriptw-aot-wasm-structure_async'
    command=['cargo','test','--locked','--offline','--release','--jobs','1','-p','scriptw-aot-wasm','--test','structure_async']
    enumeration=check(label+'-inventory',command+['--','--list','--include-ignored'])
    names=inventory((BASE/enumeration['log']).read_text())
    row=check(label,command+['--','--test-threads=1','--include-ignored'])
    require(row['executables']==enumeration['executables'],'fresh complete native binaries differ')
    native_result(row,names)
    fresh=dict(schema='scriptw-fresh-native-scope-v1',source_commit=source,scope=OWNER,inventory=names,
        inventory_sha256=hashlib.sha256(('\n'.join(names)+'\n').encode()).hexdigest(),
        run_receipt=label+'.json',inventory_receipt=label+'-inventory.json')
    path=BASE/'fresh-native.json'
    if path.exists(): require(read(path)==fresh,'closed fresh native scope differs')
    else: save_new(path,fresh)
    import publish_evidence as publisher
    import native_coverage
    actual=native_coverage.validate(publisher.Evidence(),publisher)
    if native_coverage.COVERAGE.exists():require(read(native_coverage.COVERAGE)==actual,'closed native coverage differs')
    else:save_new(native_coverage.COVERAGE,actual)
    print('MIXED-SOURCE NATIVE COVERAGE',actual['passed'],'checks',actual['source_breakdown'],flush=True)


if __name__=='__main__': main()
