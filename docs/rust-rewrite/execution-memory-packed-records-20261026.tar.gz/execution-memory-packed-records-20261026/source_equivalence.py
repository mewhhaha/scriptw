"""Narrow proof for carrying e36 native evidence across one reviewed test fix.

This grants no runtime/artifact authority. Final products, replay and measurements
retain the ordinary current-source admission. Native execution sources stay exact.
"""
import hashlib
import json
from pathlib import Path
import re
import subprocess

from campaign_identity import BASE, REPO, digest, read, require, checked_identity, candidate_source

REUSED = REPO / 'target/memory-packed-records-verified-20261026'
SOURCE = 'e36a4f029f273d86290e5ce6238bfe721e1eff78'
TREE = 'crates/scriptw-aot-wasm/tests/structure_async/'
MAIN = TREE + 'main.rs'
ASYNC = TREE + 'async_for_in_enumeration_structure.rs'
GENERATOR = TREE + 'generator_for_in_enumeration_structure.rs'
HELPER = TREE + 'host_schema.rs'
CHANGES = {MAIN: 'M', ASYNC: 'M', GENERATOR: 'M', HELPER: 'A'}
PATCH = REUSED / 'for-in-schema-fix.patch'
PATCH_SHA = 'cc4cff53169614779a5590304594fe2676602f5695b9a1c5dfbd404c7713059c'
PROOF = BASE / 'native-source-equivalence.json'
CENSUS_SHA = 'f9c325ee41c4e10f72804ab0f4250e13e3dcc5ae5d627aae010ae4ce2cbc7b66'
OWNER = dict(package='scriptw-aot-wasm', kind='--test', name='structure_async')
ADDED_TEST = 'host_schema::stored_value_shape_uses_host_authority_and_rejects_malformed_controls'


def git(*arguments):
    return subprocess.check_output(['git', *arguments], cwd=REPO)


def blob(source, path):
    return git('show', source + ':' + path)


def apply_reviewed_patch(old, patch):
    """Apply the pinned four-file patch in memory; never touch the checkout/index."""
    lines = patch.decode().splitlines(keepends=True)
    result, index = {}, 0
    while index < len(lines):
        match = re.fullmatch(r'diff --git a/(\S+) b/(\S+)\n', lines[index])
        require(match and match[1] == match[2] and match[1] in CHANGES,
                'reviewed patch has an unexpected path/header')
        path = match[1]; index += 1
        require(path not in result, 'reviewed patch repeats a file')
        while index < len(lines) and not lines[index].startswith('@@ '):
            require(lines[index].startswith(('new file mode ', '--- ', '+++ ', 'index ')),
                    'unsupported reviewed patch header')
            index += 1
        original = old.get(path, b'').decode().splitlines(keepends=True)
        output, cursor = [], 0
        while index < len(lines) and not lines[index].startswith('diff --git '):
            hunk = re.fullmatch(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@[^\n]*\n', lines[index])
            require(hunk is not None, 'unsupported reviewed patch hunk')
            start = max(int(hunk[1]) - 1, 0)
            require(cursor <= start <= len(original), 'reviewed patch old hunk ordering differs')
            output.extend(original[cursor:start]); cursor = start; index += 1
            consumed = emitted = 0
            while index < len(lines) and not lines[index].startswith(('@@ ', 'diff --git ')):
                line = lines[index]; index += 1
                require(line[:1] in [' ', '+', '-'], 'reviewed patch contains unsupported newline/line framing')
                if line[0] in [' ', '-']:
                    require(cursor < len(original) and original[cursor] == line[1:],
                            'reviewed patch context differs from e36')
                    cursor += 1; consumed += 1
                if line[0] in [' ', '+']:
                    output.append(line[1:]); emitted += 1
            require(consumed == int(hunk[2] or 1) and emitted == int(hunk[4] or 1),
                    'reviewed patch hunk dimensions differ')
        output.extend(original[cursor:]); result[path] = ''.join(output).encode()
    require(set(result) == set(CHANGES), 'reviewed patch is not the complete3M+1A change')
    return result


def validate_delta(changes, old, new, reviewed_patch):
    require({row['path']: row['status'] for row in changes} == CHANGES
            and len(changes) == len(CHANGES), 'reuse requires exactly the reviewed3M+1A test files')
    require(all(row['new_mode'] == '100644' and row['old_mode'] ==
                ('000000' if row['status'] == 'A' else '100644') for row in changes),
            'test-only delta changed a file type/mode')
    require(hashlib.sha256(reviewed_patch).hexdigest() == PATCH_SHA,
            'reviewed correction patch changed')
    require(apply_reviewed_patch(old, reviewed_patch) == new,
            'final test bytes differ from the exact reviewed correction')
    line = b'mod host_schema;\n'
    require(new[MAIN].count(line) == 1 and new[MAIN].replace(line, b'', 1) == old[MAIN],
            'structure_async main may only register its new local helper')
    require(all(b'mod ' + Path(path).stem.encode() + b';\n' in old[MAIN]
                for path in [ASYNC, GENERATOR]), 'changed fixtures are not owned by structure_async')


def tree_entries(source):
    return [entry for entry in git('ls-tree', '-r', '-z', '--full-tree', source).split(b'\0') if entry]


def exclusive_ownership(source):
    tokens = [Path(ASYNC).stem, Path(GENERATOR).stem, 'host_schema.rs', 'tests/structure_async/']
    command = ['git', 'grep', '-l', '-F']
    for token in tokens:
        command += ['-e', token]
    result = subprocess.run([*command, source, '--', '*.rs'], cwd=REPO,
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    require(result.returncode in [0, 1], 'cannot inspect Rust module consumers')
    paths = [line.split(':', 1)[1] for line in result.stdout.decode().splitlines()]
    require(paths and all(path.startswith(TREE) for path in paths),
            'a changed integration-test module is referenced outside structure_async')
    return sorted(paths)


def derive(final):
    require(re.fullmatch(r'[0-9a-f]{40}', final) and final != SOURCE,
            'an actual later corrected commit is required')
    require(git('rev-parse', '--verify', final + '^{commit}').decode().strip() == final,
            'final source is not an exact Git commit')
    raw = git('diff', '--raw', '--no-abbrev', '--no-renames', '-z', SOURCE, final)
    words = raw.split(b'\0'); changes = []
    require(words[-1] == b'' and (len(words) - 1) % 2 == 0, 'Git delta framing differs')
    for index in range(0, len(words) - 1, 2):
        mode0, mode1, old_id, new_id, status = words[index].decode().removeprefix(':').split()
        changes.append(dict(path=words[index + 1].decode(), status=status, old_mode=mode0,
                            new_mode=mode1, old_blob=old_id, new_blob=new_id))
    old = {path: blob(SOURCE, path) for path in CHANGES if CHANGES[path] != 'A'}
    new = {path: blob(final, path) for path in CHANGES}
    validate_delta(changes, old, new, PATCH.read_bytes())
    unchanged = []
    for source in [SOURCE, final]:
        entries = [entry for entry in tree_entries(source)
                   if entry.split(b'\t', 1)[1].decode() not in CHANGES]
        unchanged.append(hashlib.sha256(b'\0'.join(entries) + b'\0').hexdigest())
    require(unchanged[0] == unchanged[1], 'nonallowlisted Git tree inputs changed')
    committed_patch = git('diff', '--binary', '--no-ext-diff', '--no-renames', SOURCE, final)
    return dict(schema='scriptw-test-only-native-equivalence-v1', base_source=SOURCE, final_source=final,
                changes=changes, reviewed_patch=dict(path=str(PATCH), sha256=PATCH_SHA),
                committed_patch_sha256=hashlib.sha256(committed_patch).hexdigest(),
                unchanged_git_tree_sha256=unchanged[0],
                exclusive_module_consumers=dict(base=exclusive_ownership(SOURCE), final=exclusive_ownership(final)),
                changed_target=OWNER, compiler_revision_metadata_equal=False,
                scope='Only unchanged native test inputs may reuse e36 execution evidence. Source revisions and executable '
                      'hashes remain actual; this proof grants no product/runtime/replay/measurement admission.')


def admit():
    proof = read(PROOF)
    require(proof == derive(candidate_source()), 'saved test-only source proof differs from the actual final commit')
    old, final = read(REUSED / 'candidate/identity.json'), checked_identity('candidate')
    require(old['executable_sha256'] == read(REUSED / 'frozen-products.json')['products']['scriptw']['sha256'],
            'e36 compiler identity differs from its independent original product freeze')
    validate_compiler_identities(old, final, proof['final_source'])
    return proof


def validate_compiler_identities(old, final, final_source):
    require(old['source_revision'] == dict(kind='git-commit', commit=SOURCE)
            and final['source_revision'] == dict(kind='git-commit', commit=final_source)
            and final_source != SOURCE
            and old['source_fingerprint_scheme'] == final['source_fingerprint_scheme']
            and old['source_fingerprint'] == final['source_fingerprint'],
            'fresh final compiler fingerprint is not the unchanged e36 product implementation')


def census():
    require(digest(REUSED / 'native-diagnostic-census.json') == CENSUS_SHA, 'closed e36 census bytes changed')
    value = read(REUSED / 'native-diagnostic-census.json')
    scopes = read(REUSED / 'native-scopes.json')
    validate_census(value, scopes)
    for row in value['targets']:
        require(digest(REUSED / row['receipt']) == row['receipt_sha256'], 'closed e36 receipt changed')
    return value


def validate_census(value, scopes):
    require(value['schema'] == 'scriptw-native-failure-triage-census-v1'
            and value['source_commit'] == SOURCE and value['complete'] is True
            and value['all_scope_transcripts_complete'] is True and value['acceptance'] is False
            and len(value['targets']) == len(scopes) == 32,
            'the unchanged-source32-target e36 census must close before reuse')
    for scope, row in zip(scopes, value['targets']):
        require(all(row[key] == scope[key] for key in OWNER) and row['source_commit'] == SOURCE
                and row['observed_total_complete'] is True and row['ignored'] == 0
                and row['inventory_count'] == row['passed'] + row['failed'], 'census scope is incomplete')
        if scope == OWNER:
            require(row['failed'] == 4 and row['exit_code'] != 0, 'original changed-target failure scope differs')
        else:
            require(row['failed'] == 0 and row['exit_code'] == 0, 'another scope requires fresh correction/verification')
    require(all(value[key] == sum(row[key] for row in value['targets'])
                for key in ['passed', 'failed', 'ignored']), 'census totals do not reconcile')
