"""Closed, bounded historical audit input; never native or benchmark acceptance."""
import hashlib
import json
from pathlib import Path

from campaign_identity import BASE, REPO, digest, read, require

ORIGIN = REPO / 'target/memory-packed-records-20261026'
ATTEMPT_SOURCE = '8b38b0afde3266ed6b51247aedccaece81a8c77c'
DEVELOPMENT_BASE = '4d1b41e3221687d1163967bcc0d94155393c906e'
MANIFEST = 'prior-attempts/manifest.json'
MAX_FILES, MAX_BYTES, MAX_MEMBER_BYTES = 64, 4 * 1024**2, 1024**2
FOCUSED_LABELS = [
    'focused-compact-record-declarations', 'focused-embedding-compact-records',
    'focused-bootstrap-compact-headers', 'focused-native-compact-metadata-semantics',
    'focused-bounded-compiler-contexts', 'focused-receipt-metadata',
    'focused-bootstrap-undefined', 'focused-precompiled-embedding',
    'focused-strict-portable-package',
]
FAILED_FOCUS = 'focused-bootstrap-compact-headers'
DEVELOPMENT = [
    ('foundation-check-01', DEVELOPMENT_BASE, 101),
    ('foundation-check-02', DEVELOPMENT_BASE, 0),
    ('development-corrected-bootstrap-guard-01', ATTEMPT_SOURCE, 0),
]


def source_snapshot(source):
    """Include untracked-file hashes as well as the tracked patch and Git base."""
    return hashlib.sha256(json.dumps(source, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def specifications():
    """Explicit allowlist; no recursive discovery or historical archive nesting."""
    result = []
    for label in FOCUSED_LABELS:
        result.extend((f'prior-attempts/8b38b0afd/{label}{suffix}', label + suffix, 'focused')
                      for suffix in ['.json', '.log'])
    for name in [
        'continued-focused-diagnostics.json', 'continued-focused-diagnostics-console.log',
        'run-campaign-console.log', 'campaign.json', 'candidate/identity.json',
        'release-products.json', 'release-products.log', 'freeze-candidate.json',
        'freeze-candidate.log', 'frozen-products.json', 'focused-plan.json',
        'continue_focused_diagnostics.py', 'build_product.py', 'freeze_candidate.py', 'run_check.py',
    ]:
        result.append(('prior-attempts/8b38b0afd/' + name, name, 'authority-or-driver'))
    for label, _, _ in DEVELOPMENT:
        result.extend((f'prior-attempts/development/{label}{suffix}', label + suffix, 'development')
                      for suffix in ['.json', '.log'])
    for name in ['foundation_check.py', 'development_command.py']:
        result.append(('prior-attempts/development/' + name, name, 'development-driver'))
    return result


def validate_inventory(manifest):
    require(manifest.get('schema') == 'scriptw-memory-prior-attempts-v1'
            and manifest.get('original_campaign_root') == str(ORIGIN)
            and manifest.get('committed_attempt_source') == ATTEMPT_SOURCE
            and manifest.get('development_base') == DEVELOPMENT_BASE
            and manifest.get('included_in_accepted_totals') is False,
            'historical audit lost its original source/nonacceptance boundary')
    rows = manifest.get('files')
    expected = {path: (origin, role) for path, origin, role in specifications()}
    require(isinstance(rows, list) and len(rows) == len(expected) <= MAX_FILES
            and len({row['path'] for row in rows}) == len(rows)
            and {row['path'] for row in rows} == set(expected),
            'historical files differ from the explicit bounded allowlist')
    for row in rows:
        origin, role = expected[row['path']]
        require(row.get('origin_path') == str(ORIGIN / origin) and row.get('role') == role
                and type(row.get('bytes')) is int and 0 <= row['bytes'] <= MAX_MEMBER_BYTES
                and isinstance(row.get('sha256'), str) and len(row['sha256']) == 64
                and all(char in '0123456789abcdef' for char in row['sha256'])
                and row.get('included_in_accepted_totals') is False,
                'historical member has an invalid origin, identity or acceptance flag')
        context = row.get('source_context', {})
        if role in ['focused', 'authority-or-driver']:
            require(context == dict(kind='committed-attempt', source_commit=ATTEMPT_SOURCE),
                    'historical member lost original8b source context')
        elif role == 'development':
            require(context.get('kind') == 'development-patch'
                    and context.get('source_base') in [DEVELOPMENT_BASE, ATTEMPT_SOURCE]
                    and isinstance(context.get('tracked_patch_sha256'), str)
                    and len(context['tracked_patch_sha256']) == 64
                    and isinstance(context.get('source_snapshot_sha256'), str)
                    and len(context['source_snapshot_sha256']) == 64,
                    'historical development source context is missing')
        else:
            require(context == dict(kind='ignored-driver-snapshot',
                    associated_source_bases=[DEVELOPMENT_BASE, ATTEMPT_SOURCE]),
                    'ignored historical driver must not acquire a Git source identity')
    require(sum(row['bytes'] for row in rows) == manifest.get('total_bytes') <= MAX_BYTES,
            'historical payload exceeds its explicit4MiB budget')
    return rows


def validate_member(row, base=BASE):
    path, origin = Path(base) / row['path'], Path(row['origin_path'])
    require(path.is_file() and not path.is_symlink() and path.stat().st_nlink == 1
            and origin.is_file() and not origin.is_symlink()
            and path.stat().st_size == origin.stat().st_size == row['bytes']
            and digest(path) == digest(origin) == row['sha256'],
            'historical copy/origin differs: ' + row['path'])
    return path


def validate(base=BASE, accepted_source=None):
    base = Path(base)
    require(accepted_source != ATTEMPT_SOURCE, 'failed original source cannot be the fresh accepted candidate')
    require((base / MANIFEST).stat().st_size <= 256 * 1024, 'historical audit manifest exceeds256KiB')
    manifest = read(base / MANIFEST)
    rows = validate_inventory(manifest)
    for row in rows:
        validate_member(row, base)
    original = base / 'prior-attempts/8b38b0afd'
    passed, failed = 0, 0
    actual = []
    for label in FOCUSED_LABELS:
        receipt = read(original / (label + '.json'))
        expected_exit = 101 if label == FAILED_FOCUS else 0
        require(receipt['source_head'] == receipt['source_head_after'] == ATTEMPT_SOURCE
                and receipt['source_patch_sha256'] == hashlib.sha256(b'').hexdigest()
                and receipt['exit_code'] == expected_exit and receipt['label'] == label
                and receipt['log'] == label + '.log'
                and receipt['log_sha256'] == digest(original / receipt['log'])
                and len(receipt['test_results']) == 1,
                'original focused source/exit/transcript differs')
        terminal = receipt['test_results'][0]
        require(terminal[0] == ('FAILED' if expected_exit else 'ok') and terminal[3:5] == ['0', '0'],
                'original focused terminal result differs')
        passed += int(terminal[1]); failed += int(terminal[2])
        actual.append(dict(label=label, exit_code=expected_exit, test_results=receipt['test_results']))
    continued = read(original / 'continued-focused-diagnostics.json')
    require(continued['source_commit'] == ATTEMPT_SOURCE and continued['complete'] is True
            and continued['acceptance'] is False and continued['focused'] == actual
            and passed == 26 and failed == 1,
            'continued diagnostics cannot become a successful native checkpoint')
    identity = read(original / 'candidate/identity.json')
    frozen = read(original / 'frozen-products.json')
    require(identity['source_revision'] == dict(kind='git-commit', commit=ATTEMPT_SOURCE)
            and frozen['source_commit'] == ATTEMPT_SOURCE
            and frozen['products']['scriptw']['sha256'] == identity['executable_sha256']
            and read(original / 'campaign.json')['source_commit'] == ATTEMPT_SOURCE,
            'historical product/freeze identity differs')
    development = []
    for label, source_base, exit_code in DEVELOPMENT:
        receipt = read(base / 'prior-attempts/development' / (label + '.json'))
        source = receipt['source_before']
        log = base / 'prior-attempts/development' / receipt['log']
        require(receipt['schema'] == 'scriptw-development-foundation-check-v1'
                and receipt['label'] == label and receipt['exit_code'] == exit_code
                and receipt['source_stable'] is True and source['source_base'] == source_base
                and hashlib.sha256(source['tracked_patch'].encode()).hexdigest() == source['tracked_patch_sha256']
                and source['tracked_patch_sha256'] != hashlib.sha256(b'').hexdigest()
                and receipt['log'] == label + '.log' and digest(log) == receipt['log_sha256'],
                'development check source/patch/transcript differs')
        for suffix in ['.json', '.log']:
            record = next(row for row in rows if row['path'] ==
                          'prior-attempts/development/' + label + suffix)
            require(record['source_context'] == dict(kind='development-patch',
                    source_base=source_base, tracked_patch_sha256=source['tracked_patch_sha256'],
                    source_snapshot_sha256=source_snapshot(source)),
                    'copied development member has a different patch identity')
        development.append(dict(label=label, source_base=source_base,
            tracked_patch_sha256=source['tracked_patch_sha256'], exit_code=exit_code,
            source_snapshot_sha256=source_snapshot(source), new_file_count=len(source['new_files']),
            included_in_accepted_totals=False))
    return dict(complete=True, manifest=MANIFEST, manifest_sha256=digest(base / MANIFEST),
                historical_source=ATTEMPT_SOURCE, focused_groups=9, historical_passed=passed,
                historical_failed=failed, development=development,
                included_in_accepted_totals=False, accepted_count_contribution=0,
                original_products_copied=False, file_count=len(rows), total_bytes=manifest['total_bytes'],
                explanation='Original8b stopped at an overbroad test assertion: the common compact allocator legitimately '
                    'boxes its object prototype once. The other eight focused groups passed26checks on that source. '
                    'A dirty-source guard correction and the earlier Debug-bound compile fix remain development evidence. '
                    'Fresh corrected source still needs independent products, all native inventories, selected replay '
                    'and measurements. No historical result enters their accepted totals.')
