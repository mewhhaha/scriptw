"""Build and freeze the actual candidate, then collect its allocation diagnostic."""
from campaign_runtime import check, own

for label, name, arguments in [
    ('source-guards', 'source_guards.py', []),
    ('release-products', 'build_product.py', []),
    ('freeze-candidate', 'freeze_candidate.py', []),
    ('freeze-candidate-allocation-inputs', 'freeze_candidate_link_inputs.py', ['--freeze']),
    ('allocation-diagnostic-candidate', 'candidate_engine_allocation_diagnostic.py', ['--run']),
]:
    check(label, own(name, *arguments))
print('Actual candidate products and allocation observations closed', flush=True)
