"""Rederive every source-free diagnostic observation; runs no native process."""
import argparse
import json
from pathlib import Path

from campaign_identity import (BASE, REPO, candidate_source, checked_identity, digest, read,
                               require, validate_environment)
from campaign_runtime import checked_receipt, own
from precompiled_validation import (SAMPLES, WARMUPS, execution, image_framing,
                                    identity, uint)

FIXTURES = REPO / 'crates/scriptw-cli/tests/fixtures/v8_execution_hotpaths'
OUTPUT = BASE / 'precompiled-execution-data'
ANALYSIS = BASE / 'precompiled-execution-analysis.json'


def validate_producer(value, compiler, executable_sha256, manifest, images):
    identity(value, compiler, executable_sha256)
    require(value.get('schema') == 'scriptw-precompiled-producer-v1'
            and value.get('excluded_from_scored_cohorts') is True
            and value.get('manifest_sha256') == digest(FIXTURES / 'manifest.json'),
            'producer schema/manifest differs')
    rows = value.get('cases')
    require(isinstance(rows, list) and len(rows) == len(manifest['execution']) == 17,
            'complete producer17case record required')
    require(read(images / 'producer.json') == value, 'saved producer differs from its actual stdout')
    expected_files, result = {'producer.json'}, []
    for row, case in zip(rows, manifest['execution']):
        image_name = case['file'] + '.swpc'
        expected_files.add(image_name)
        require(Path(case['file']).name == case['file'] and row.get('file') == case['file']
                and row.get('stdout') == case['stdout'] and row.get('image') == image_name
                and row.get('source_sha256') == digest(FIXTURES / case['file'])
                and row.get('source_compilation_profile') == 'portable' and row.get('intl_profile') == 'Minimal',
                'producer case order/source/output/profile differs')
        path = images / image_name
        require(path.is_file() and not path.is_symlink() and path.stat().st_nlink == 1,
                'native image is missing/symlinked/hardlinked')
        frame = image_framing(path.read_bytes(), compiler['source_fingerprint'])
        require(row.get('image_sha256') == digest(path) and row.get('image_bytes') == path.stat().st_size
                and row.get('program_wasm_sha256') == frame['program_sha256']
                and row.get('program_wasm_bytes') == frame['program_bytes']
                and row.get('native_serialized_bytes') == frame['native_serialized_bytes']
                and row.get('runtime_key') == frame['runtime_key'],
                'producer P/native/R hashes, sizes or framing differ')
        phases = row.get('phases_ns')
        require(isinstance(phases, dict) and set(phases) == {'source_compilation', 'native_preparation'}
                and all(uint(item) for item in phases.values()), 'producer phase timings missing')
        result.append(dict(file=image_name, sha256=digest(path), bytes=path.stat().st_size,
                           source_sha256=row['source_sha256'], **frame))
    require({path.name for path in images.iterdir()} == expected_files,
            'native image directory has missing/unexpected producer records')
    return result


def build_report():
    compiler = checked_identity('candidate')
    actual = read(OUTPUT / 'report.json')
    frozen = read(BASE / 'precompiled-product/identity.json')
    require(actual.get('schema') == 'scriptw-precompiled-execution-diagnostic-v1'
            and actual.get('complete') is True and 'failure' not in actual
            and actual.get('campaign_source') == candidate_source()
            and actual.get('compiler_identity') == compiler
            and actual.get('executable') == frozen
            and actual.get('excluded_from_scored_cohorts') is True
            and actual.get('scored_case_count_contribution') == 0 and actual.get('baseline_available') is False
            and actual.get('samples') == SAMPLES and actual.get('warmups') == WARMUPS,
            'complete independent diagnostic policy/source differs')
    validate_environment(actual['environment'])
    require(actual['driver_sha256'] == digest(BASE / 'measure_precompiled.py')
            and actual['validator_sha256'] == digest(BASE / 'precompiled_validation.py')
            and actual['manifest_sha256'] == digest(FIXTURES / 'manifest.json')
            and frozen['source_commit'] == candidate_source() and digest(frozen['path']) == frozen['sha256']
            and Path(frozen['path']).resolve() == BASE / 'precompiled-product/runtime_precompiled',
            'diagnostic source/fixture/frozen executable changed')
    built = checked_receipt('precompiled-example-build', own('build_precompiled.py'))
    outer = checked_receipt('precompiled-execution', own('measure_precompiled.py', '--run'))
    rows = [json.loads(line) for line in (BASE / 'cargo-precompiled.jsonl').read_text().splitlines()]
    require(rows and rows[-1] == dict(reason='build-finished', success=True)
            and frozen['cargo_producer'] in rows and digest(BASE / 'cargo-precompiled.jsonl') == frozen['producer_log_sha256'],
            'diagnostic freeze does not bind actual closed Cargo producer')
    expected_build = ['cargo', 'build', '--locked', '--offline', '--release', '--jobs', '1',
                      '-p', 'scriptw-cli', '--example', 'runtime_precompiled', '--message-format=json']
    require(frozen['command'] == expected_build and frozen['cargo_producer']['profile']['opt_level'] == '3'
            and frozen['cargo_producer']['profile']['test'] is False and frozen['cargo_producer']['features'] == []
            and frozen['cargo_producer']['target']['kind'] == ['example']
            and frozen['cargo_producer']['target']['name'] == 'runtime_precompiled'
            and Path(frozen['cargo_producer']['manifest_path']).resolve() == REPO / 'crates/scriptw-cli/Cargo.toml',
            'diagnostic build/profile/producer changed')
    manifest = read(FIXTURES / 'manifest.json')
    commands = actual.get('commands')
    require(isinstance(commands, list) and len(commands) == 18
            and len(actual.get('cases', [])) == 17, 'complete prepare+17execute child set required')

    def command(event, label, args):
        require(event['label'] == label and event['command'] == [frozen['path'], *args]
                and event['cwd'] == str(REPO) and event['state'] == 'finished'
                and event['exit_code'] == 0 and event['timed_out'] is False
                and event['stdout_file'] == label + '.stdout' and event['stderr_file'] == label + '.stderr',
                'diagnostic child command/exit/state differs')
        stdout, stderr = OUTPUT / event['stdout_file'], OUTPUT / event['stderr_file']
        require(digest(stdout) == event['stdout_sha256'] and digest(stderr) == event['stderr_sha256']
                and stderr.read_bytes() == b'', 'actual child streams changed/contain diagnostics')
        return json.loads(stdout.read_text())

    images = OUTPUT / 'images'
    producer = command(commands[0], 'prepare', ['prepare', str(FIXTURES), str(images)])
    inventory = validate_producer(producer, compiler, frozen['sha256'], manifest, images)
    table = []
    for ordinal, (case, image, saved) in enumerate(zip(manifest['execution'], inventory, actual['cases'])):
        label = f'execute-{ordinal:02d}-' + Path(case['file']).stem
        value = command(commands[ordinal + 1], label,
                        ['execute', str(images / image['file']), case['stdout'], str(SAMPLES), str(WARMUPS)])
        summary = execution(value, compiler, frozen['sha256'], image, case)
        require(saved == dict(file=case['file'], expected_stdout=case['stdout'], image=image,
                              command=label, summary=summary), 'saved summary differs from actual observations')
        table.append(summary)
    return dict(schema='scriptw-precompiled-execution-analysis-v1', complete=True,
                source_commit=candidate_source(), compiler_identity=compiler,
                executable_sha256=frozen['sha256'], report_sha256=digest(OUTPUT / 'report.json'),
                outer_receipt_sha256=digest(BASE / 'precompiled-execution.json'),
                build_receipt_sha256=digest(BASE / 'precompiled-example-build.json'),
                samples=SAMPLES, warmups=WARMUPS, case_count=len(table),
                excluded_from_scored_cohorts=True, scored_case_count_contribution=0,
                compiler_enabled=False, baseline_available=False, table=table,
                interpretation='Candidate-only native image transport built by a separate producer. Consumer compilation is '
                    'disabled and cannot silently compile a Portable fallback. Setup/read/admission and first/steady '
                    'execution remain separate process endpoints, not synchronized peaks or live JS heap bytes. '
                    'The 10 ms native load RSS sampler reports a sampled maximum and may miss shorter transients. '
                    'The example ELF contains its producer/compiler code; compiler-disabled execution is not a separate '
                    'minimal linker build. Ordinary source compilation/warmup cohorts remain unchanged. Native images '
                    'excluded; framing, provenance and complete raw producer/consumer streams permit regeneration.')



def evidence_files():
    files = [OUTPUT / 'report.json', OUTPUT / 'images/producer.json',
             BASE / 'precompiled-product/identity.json', BASE / 'cargo-precompiled.jsonl',
             BASE / 'cargo-precompiled.stderr']
    actual = read(OUTPUT / 'report.json')
    for command in actual['commands']:
        files.extend(OUTPUT / command[key + '_file'] for key in ['stdout', 'stderr'])
    files.extend(FIXTURES / case['file'] for case in read(FIXTURES / 'manifest.json')['execution'])
    files.append(FIXTURES / 'manifest.json')
    files.extend(REPO / 'crates/scriptw-cli/examples' / name for name in [
        'runtime_precompiled.rs', 'runtime_precompiled/produce.rs',
        'runtime_precompiled/consume.rs', 'runtime_precompiled/residency.rs'])
    return files


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check', action='store_true')
    args = parser.parse_args()
    result = build_report()
    if args.check:
        require(read(ANALYSIS) == result, 'saved diagnostic analysis differs')
    else:
        with ANALYSIS.open('x') as out:
            out.write(json.dumps(result, indent=2) + '\n')
    print(json.dumps(dict(validated=True, case_count=result['case_count'], compiler_enabled=False,
                         excluded_from_scored_cohorts=True)))


if __name__ == '__main__':
    main()
