"""Pure controls for source attribution and the narrow native-evidence reuse gate."""
import copy
import unittest

import source_equivalence as bridge
from campaign_identity import read

FINAL = '736f0f1206c581e70048467f7d4423e1efed8bdd'


class NativeSourceBridge(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.proof = read(bridge.PROOF)
        cls.old = {path: bridge.blob(bridge.SOURCE, path)
                   for path in bridge.CHANGES if bridge.CHANGES[path] != 'A'}
        cls.new = {path: bridge.blob(FINAL, path) for path in bridge.CHANGES}
        cls.patch = bridge.PATCH.read_bytes()

    def test_reviewed_delta_is_three_modifications_and_one_exclusive_local_helper(self):
        self.assertEqual(self.proof, bridge.derive(FINAL))
        bridge.validate_delta(self.proof['changes'], self.old, self.new, self.patch)
        self.assertEqual(bridge.apply_reviewed_patch(self.old, self.patch), self.new)
        self.assertFalse(self.proof['compiler_revision_metadata_equal'])

    def test_product_changes_renames_extra_code_and_changed_review_patch_cannot_reuse(self):
        changes = copy.deepcopy(self.proof['changes'])
        for bad in [changes[:-1], changes + [dict(path='crates/scriptw-aot-wasm/src/objects.rs', status='M')],
                    [{**row, 'status': 'M'} if row['status'] == 'A' else row for row in changes],
                    [{**row, 'new_mode': '100755'} if row['path'] == bridge.MAIN else row for row in changes]]:
            with self.assertRaises(ValueError):
                bridge.validate_delta(bad, self.old, self.new, self.patch)
        changed = dict(self.new); changed[bridge.HELPER] += b'// unreviewed code\n'
        with self.assertRaises(ValueError):
            bridge.validate_delta(changes, self.old, changed, self.patch)
        with self.assertRaises(ValueError):
            bridge.validate_delta(changes, self.old, self.new, self.patch + b'\n')

    def test_fingerprint_equivalence_never_relabels_the_actual_source_revision(self):
        old = read(bridge.REUSED / 'candidate/identity.json')
        final = {**old, 'source_revision': dict(kind='git-commit', commit=FINAL)}
        bridge.validate_compiler_identities(old, final, FINAL)
        for changed in [{**final, 'source_revision': old['source_revision']},
                        {**final, 'source_fingerprint': '0' * 64},
                        {**final, 'source_fingerprint_scheme': 'unreviewed'}]:
            with self.assertRaises(ValueError):
                bridge.validate_compiler_identities(old, changed, FINAL)

    def test_partial_failed_other_scope_or_acceptance_census_cannot_supply_reused_success(self):
        census = read(bridge.REUSED / 'native-diagnostic-census.json')
        scopes = read(bridge.REUSED / 'native-scopes.json')
        bridge.validate_census(census, scopes)
        for mutate in [lambda value: value.update(complete=False),
                       lambda value: value.update(acceptance=True),
                       lambda value: value.update(source_commit=FINAL),
                       lambda value: value['targets'].pop(),
                       lambda value: value['targets'][0].update(failed=1),
                       lambda value: value['targets'][4].update(failed=0),
                       lambda value: value['targets'][0].update(ignored=1)]:
            value = copy.deepcopy(census); mutate(value)
            with self.assertRaises(ValueError):
                bridge.validate_census(value, scopes)


if __name__ == '__main__':
    unittest.main()
