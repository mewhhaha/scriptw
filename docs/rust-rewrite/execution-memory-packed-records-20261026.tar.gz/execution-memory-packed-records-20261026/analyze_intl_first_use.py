#!/usr/bin/env python3
"""Pure admission of the separate Intl first-use diagnostic; never run children."""
from campaign_identity import product_directory
import argparse
from datetime import datetime
import hashlib
import json
from pathlib import Path
import shutil
import statistics
import sys

from campaign_identity import (BASE, candidate_source, digest, frozen_product, read,
                               require, validate_environment)
from analyze import resources, uint
from measure_intl_first_use import (CASE, EXPECTED, FIXTURES, LABEL, NODE_HARNESS,
                                   OUTPUT, REPO, SAMPLES, WARMUPS, fixture_plan)

ANALYSIS = BASE / 'intl-first-use-analysis.json'
MEASURE = BASE / 'measure_intl_first_use.py'
LIMIT = 4 * 1024**3


def moment(value):
    result = datetime.fromisoformat(value)
    require(result.utcoffset() is not None, 'diagnostic timestamp has no timezone')
    return result


def owned(name):
    require(isinstance(name, str) and Path(name).name == name, 'diagnostic stream path escapes output')
    path = OUTPUT / name
    require(path.is_file() and not path.is_symlink(), 'missing/symlinked diagnostic stream')
    return path


def summaries(rows):
    fields = sorted({key for row in rows for key, value in row.items() if type(value) is int})
    return {key: dict(values=[row[key] for row in rows],
                      median=statistics.median(row[key] for row in rows),
                      minimum=min(row[key] for row in rows), maximum=max(row[key] for row in rows))
            for key in fields}


def normalized(runtime, observations):
    require(len(observations) == WARMUPS + SAMPLES
            and [row['warmup'] for row in observations] == [True] * WARMUPS + [False] * SAMPLES
            and all(row['stdout'] == EXPECTED and uint(row['execution_ns']) for row in observations),
            'Intl output, warmup order or duration differs')
    rows = []
    policies = set()
    for index, value in enumerate(observations):
        require('row_phases' not in value and 'actual_native_policy' not in value,
                'instrumented/explicit-policy observation entered ordinary Intl diagnostic')
        row = dict(observation_index=index, warmup=value['warmup'], execution_ns=value['execution_ns'])
        memory = value['memory']
        if runtime == 'wasmtime':
            rss = memory['process_rss']
            require(rss['status'] == 'sampled' and rss['scope'] == 'runtime-invocation-process-rss'
                    and all(uint(rss[field]) for field in ('initial_rss_bytes', 'final_rss_bytes',
                                                         'maximum_rss_bytes', 'sample_count'))
                    and rss['sample_count'] >= 2
                    and 0 < max(rss['initial_rss_bytes'], rss['final_rss_bytes']) <= rss['maximum_rss_bytes'] <= LIMIT,
                    'Wasmtime whole-invocation RSS scope/order/cap differs')
            require(memory['gc_capacity_before_bytes'] == 16 * 1024**2
                    and uint(memory['gc_capacity_after_bytes'])
                    and memory['gc_capacity_before_bytes'] <= memory['gc_capacity_after_bytes'] <= LIMIT,
                    'default GC capacity cohort differs')
            require(set(value['phases_ns']) == {'admission', 'engine', 'module', 'store_and_linker',
                                               'host_import_registration', 'instantiate', 'export_lookup', 'total'}
                    and all(uint(timing) for timing in value['phases_ns'].values()), 'phase timing fields differ')
            row.update(rss_before_bytes=rss['initial_rss_bytes'], rss_after_bytes=rss['final_rss_bytes'],
                       maximum_sampled_rss_bytes=rss['maximum_rss_bytes'], rss_sample_count=rss['sample_count'],
                       gc_capacity_before_bytes=memory['gc_capacity_before_bytes'],
                       gc_capacity_after_bytes=memory['gc_capacity_after_bytes'], phases_ns=value['phases_ns'],
                       unavailable=memory['unavailable'])
            policies.add(value['runtime_policy'])
        else:
            require(runtime == 'v8' and memory['scope'] ==
                    'process-wide-endpoints;natural-gc;not-peak-or-live-workload-bytes', 'V8 endpoint scope differs')
            require(all(uint(memory[endpoint][field])
                        for endpoint in ('before_context', 'before', 'after')
                        for field in ('rss', 'heapTotal', 'heapUsed', 'external', 'arrayBuffers'))
                    and all(0 < memory[endpoint]['rss'] <= LIMIT
                            for endpoint in ('before_context', 'before', 'after'))
                    and uint(value['context_ns']), 'V8 endpoint values differ')
            row.update(rss_before_context_bytes=memory['before_context']['rss'],
                       rss_before_bytes=memory['before']['rss'], rss_after_bytes=memory['after']['rss'],
                       context_ns=value['context_ns'], heap_total_before_bytes=memory['before']['heapTotal'],
                       heap_total_after_bytes=memory['after']['heapTotal'],
                       heap_used_before_bytes=memory['before']['heapUsed'],
                       heap_used_after_bytes=memory['after']['heapUsed'])
        row['rss_endpoint_change_bytes'] = row['rss_after_bytes'] - row['rss_before_bytes']
        rows.append(row)
    require(runtime != 'wasmtime' or len(policies) == 1, 'Wasmtime runtime policy changed within diagnostic')
    return dict(first_warmup=rows[0], remaining_warmups=rows[1:WARMUPS],
                steady=dict(observation_indices=list(range(WARMUPS, WARMUPS + SAMPLES)),
                            observations=rows[WARMUPS:], summary=summaries(rows[WARMUPS:])),
                runtime_policy=next(iter(policies)) if policies else None)


def build_report():
    """Rederive first-warmup and seven-observation steady slices from raw bytes."""
    report_path = OUTPUT / 'report.json'
    report = read(report_path)
    require(report.get('schema') == 'scriptw-intl-first-use-diagnostic-v1' and report.get('complete') is True
            and report.get('excluded_from_scored_cohorts') is True and report.get('label') == LABEL,
            'missing/partial/mislabelled separate Intl diagnostic')
    require(report['campaign_source'] == candidate_source() and report['samples'] == SAMPLES
            and report['warmups'] == WARMUPS and report['affinity'] == [0], 'Intl source/sample/CPU cohort differs')
    require(report['fixture'] == fixture_plan() and report['fixture_source_sha256'] == digest(FIXTURES / CASE)
            and report['fixture_manifest_sha256'] == digest(FIXTURES / 'manifest.json')
            and report['driver_sha256'] == digest(MEASURE), 'diagnostic fixture/manifest/driver changed')
    dependencies = [BASE / name for name in ('campaign_identity.py', 'analyze.py', 'analyze_intl_first_use.py')]
    dependencies.append(REPO / 'scripts/limited_verification.py')
    require(report['dependencies'] == {str(path.relative_to(REPO)): digest(path) for path in dependencies},
            'diagnostic admission dependencies changed')
    node = Path(report['node']['path'])
    require(node.is_file() and not node.is_symlink() and digest(node) == report['node']['sha256'], 'actual Node bytes changed')
    harness = owned('node-runtime.cjs')
    require(report['node_harness'] == {'path': harness.name, 'sha256': digest(harness)}
            and digest(harness) == digest(NODE_HARNESS), 'actual Node harness changed')
    receipt_path = BASE / (LABEL + '.json')
    receipt = read(receipt_path)
    resources(receipt, LABEL)
    require(receipt['label'] == LABEL and receipt['source_head'] == candidate_source()
            and receipt['source_patch_sha256'] == hashlib.sha256(b'').hexdigest(), 'outer clean source receipt differs')
    command = receipt['command']
    arguments = command[1:]
    if arguments[:1] == ['-B']:
        arguments = arguments[1:]
    require(len(arguments) == 1
            and Path(shutil.which(command[0]) or command[0]).resolve() == Path(sys.executable).resolve()
            and (REPO / arguments[0]).resolve() == MEASURE.resolve(), 'outer command is not the actual diagnostic driver')
    require(moment(report['started_at']) <= moment(report['finished_at']) <= moment(receipt['date']),
            'diagnostic/outer completion timestamps differ')
    require(list(report['products']) == ['baseline', 'candidate'], 'actual product order differs')
    commands = report['commands']
    labels = [event['label'] for event in commands]
    require(labels == ['baseline-identity', 'baseline-wasmtime', 'baseline-v8',
                       'candidate-identity', 'candidate-v8', 'candidate-wasmtime'], 'actual serial child order differs')
    by_label = {event['label']: event for event in commands}
    previous_end = moment(report['started_at'])
    for event in commands:
        require(event['state'] == 'finished' and event['exit_code'] == 0 and event['timed_out'] is False
                and event['cwd'] == str(REPO) and 0 <= event['wall_seconds'] < 901,
                'diagnostic child failed or changed its invocation boundary')
        require(previous_end <= moment(event['started_at']) <= moment(event['finished_at'])
                <= moment(report['finished_at']), 'diagnostic children overlap or are out of order')
        previous_end = moment(event['finished_at'])
        for stream in ('stdout', 'stderr'):
            path = owned(event[stream + '_file'])
            require(path.name == event['label'] + '.' + stream
                    and digest(path) == event[stream + '_sha256'], 'raw child stream changed')
        require(read(owned(event['stdout_file'])) == event['data'], 'nested diagnostic observations differ from raw stdout')
    products, versions, policies = {}, set(), set()
    for product in ('baseline', 'candidate'):
        row = report['products'][product]
        identity, hashes = frozen_product(product)
        directory = product_directory(product)
        require(row['compiler_identity'] == identity and row['frozen_product_sha256'] == hashes,
                'actual frozen product identities differ')
        validate_environment(row['environment'])
        expected_binaries = {'scriptw': dict(path=str(directory / 'scriptw'), sha256=hashes['scriptw']),
                             'wasmtime': dict(path=str(directory / 'runtime_baseline'), sha256=hashes['runtime_baseline']),
                             'v8': report['node']}
        require(row['binaries'] == expected_binaries, 'actual product/runtime paths or hashes differ')
        identity_label = product + '-identity'
        require(row['identity_command'] == identity_label
                and by_label[identity_label]['command'] == [str(directory / 'scriptw'), 'compiler-identity']
                and by_label[identity_label]['data'] == identity, 'actual CLI identity invocation differs')
        order = ['wasmtime', 'v8'] if product == 'baseline' else ['v8', 'wasmtime']
        require(row['runtime_order'] == list(row['runtimes']) == order, 'runtime order differs')
        products[product] = dict(compiler_identity=identity, frozen_product_sha256=hashes, runtimes={})
        for runtime in order:
            label = product + '-' + runtime
            event = by_label[label]
            require(row['runtimes'][runtime] == label, 'runtime event reference differs')
            artifacts = OUTPUT / (product + '-wasm')
            expected_command = ([str(directory / 'runtime_baseline'), str(FIXTURES), '7', '10', CASE, str(artifacts)]
                                if runtime == 'wasmtime' else [str(node), str(harness), str(FIXTURES), '7', '10', CASE])
            require(event['command'] == expected_command, 'actual runtime command changed')
            data = event['data']
            require(data['samples'] == SAMPLES and data['warmups'] == WARMUPS and len(data['cases']) == 1,
                    'actual child denominator differs')
            case = data['cases'][0]
            require(case['file'] == CASE and case['source_sha256'] == report['fixture_source_sha256'],
                    'actual child source identity differs')
            if runtime == 'wasmtime':
                require(data['schema'] == 'scriptw-wasmtime-baseline-v2'
                        and data['source_commit'] == identity['source_revision']['commit']
                        and data['source_fingerprint'] == identity['source_fingerprint']
                        and data['executable_sha256'] == hashes['runtime_baseline']
                        and data['requested_native_policy'] is None
                        and case['source_compilation_profile'] == 'portable' and case['linked_runtime'] is not None,
                        'actual Wasmtime identity or ordinary linked Portable policy differs')
                wasm = artifacts / (CASE + '.wasm')
                require(wasm.is_file() and not wasm.is_symlink() and wasm.stat().st_size == case['wasm_bytes']
                        and digest(wasm) == case['wasm_sha256'], 'actual emitted P bytes differ')
            else:
                require(data['schema'] == 'scriptw-v8-baseline-v2', 'actual Node schema differs')
                versions.add((data['node'], data['v8']))
            derived = normalized(runtime, case['observations'])
            if runtime == 'wasmtime':
                policies.add(derived['runtime_policy'])
                derived['linked_runtime'] = case['linked_runtime']
                derived['program_wasm'] = dict(bytes=case['wasm_bytes'], sha256=case['wasm_sha256'])
            products[product]['runtimes'][runtime] = derived
    require(len(versions) == len(policies) == 1, 'Node/V8 version or Wasmtime policy changed across products')
    return dict(schema='scriptw-intl-first-use-analysis-v1', complete=True,
                excluded_from_scored_cohorts=True, campaign_source=report['campaign_source'],
                samples=SAMPLES, warmups=WARMUPS, fixture=report['fixture'],
                fixture_source_sha256=report['fixture_source_sha256'],
                fixture_manifest_sha256=report['fixture_manifest_sha256'],
                report_sha256=digest(report_path), receipt_sha256=digest(receipt_path),
                node_v8=list(next(iter(versions))), node_sha256=report['node']['sha256'], products=products,
                scope=report['scope'], loadavg_start=report['loadavg_start'], loadavg_end=report['loadavg_end'],
                notes=['First warmup is observation0 and is never part of the seven-observation steady summary.',
                       'Wasmtime RSS endpoints bracket the whole runtime invocation, including admission/native mapping/setup; '
                       'the first-to-steady difference cannot be attributed exclusively to Intl allocations.',
                       'V8 endpoints bracket its JavaScript execution; engine endpoints are not synchronized live-heap measurements.',
                       'Natural GC, process-retained providers and prior fresh contexts remain visible; no forced GC or peak subtraction.',
                       'GC capacity is reserved capacity. This diagnostic supplies no live JavaScript bytes, allocation counts or isolated provider heap counter.',
                       'One serial session per product/runtime on a shared host; descriptive and outside both 17-case cohorts.'])


def evidence_files():
    """Only retained source, manifests, raw observations and receipts; no ELFs/cache."""
    report = read(OUTPUT / 'report.json')
    receipt = read(BASE / (LABEL + '.json'))
    paths = {Path(__file__).resolve(), MEASURE, BASE / 'campaign.json', BASE / 'campaign_identity.py',
             BASE / 'analyze.py', REPO / 'scripts/limited_verification.py', FIXTURES / 'manifest.json',
             FIXTURES / CASE, OUTPUT / 'report.json', OUTPUT / 'node-runtime.cjs', NODE_HARNESS,
             BASE / (LABEL + '.json'), BASE / receipt['log']}
    paths.update(product_directory(product) / 'identity.json' for product in ('baseline', 'candidate'))
    for event in report['commands']:
        paths.update(owned(event[stream + '_file']) for stream in ('stdout', 'stderr'))
    paths.update(OUTPUT / (product + '-wasm') / (CASE + '.wasm') for product in ('baseline', 'candidate'))
    require(all(path.is_file() and not path.is_symlink() for path in paths), 'diagnostic evidence missing/symlinked')
    return sorted(paths)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=ANALYSIS)
    parser.add_argument('--check', action='store_true')
    args = parser.parse_args()
    actual = build_report()
    if args.check:
        require(read(args.output) == actual, 'saved Intl first-use analysis differs from raw rederivation')
    else:
        with args.output.open('x') as stream:
            stream.write(json.dumps(actual, indent=2) + '\n')
    print(json.dumps(dict(checked=args.check, output=str(args.output), complete=True,
                          excluded_from_scored_cohorts=True)))


if __name__ == '__main__':
    try:
        main()
    except (KeyError, ValueError, OSError, TypeError) as error:
        raise SystemExit('Intl first-use analysis refused: ' + str(error))
