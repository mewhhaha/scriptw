"""Run the actual complete Engine inventory in disjoint bounded fresh batches."""
import re
from pathlib import Path
from campaign_runtime import BASE,actual_source,require_scope,check,read,require,inventory,native_result,progress,save_new


def main():
    source=actual_source();require_scope()
    built=check('engine-batches-build',['cargo','test','--locked','--offline','--release','--jobs','1','-p','scriptw-engine','--lib','--no-run'])
    paths=re.findall(r'Executable unittests src/lib.rs \(([^)]+)\)',(BASE/built['log']).read_text())
    require(len(paths)==1,'actual Engine harness path is absent/ambiguous')
    binary=str(Path(paths[0]).resolve())
    enumerated=check('engine-batches-inventory',[binary,'--list','--include-ignored'])
    names=inventory((BASE/enumerated['log']).read_text())
    chunks=[];current=[]
    for name in names:
        if name.startswith('runtime_profile::') or 'capacity' in name or 'inlining' in name:
            if current:chunks.append(current);current=[]
            chunks.append([name])
        else:
            current.append(name)
            if len(current)==32:chunks.append(current);current=[]
    if current:chunks.append(current)
    manifest=dict(source_head=source,complete=False,inventory=names,batches=[],binary=binary)
    for index,selected in enumerate(chunks):
        label=f'engine-batch-{index:03d}'
        row=check(label,[binary,*selected,'--exact','--test-threads=1','--include-ignored'])
        require(row['executables']==enumerated['executables'],'Engine batch executable differs from its actual enumeration')
        native_result(row,selected,len(names)-len(selected))
        manifest['batches'].append(dict(label=label,inventory=selected));manifest['complete']=index+1==len(chunks)
        progress(BASE/'engine-batches.json',manifest)
        print('Closed actual Engine inventory',sum(len(x['inventory']) for x in manifest['batches']),'/',len(names),flush=True)
    seen=[name for batch in manifest['batches'] for name in batch['inventory']]
    require(sorted(seen)==names and len(seen)==len(set(seen)),'Engine union lost/repeated an exact identity')
    aggregate=dict(label='broad-07-scriptw-engine-lib-batched',source_head=source,source_patch_sha256=built['source_patch_sha256'],
        package='scriptw-engine',kind='--lib',name=None,inventory=names,batch_manifest='engine-batches.json',exit_code=0,
        complete=True,passed=len(names),aggregation='disjoint exact native libtest batch observations; no synthetic single-process transcript')
    path=BASE/'engine-accepted.json'
    if path.exists():require(read(path)==aggregate,'closed Engine aggregate differs')
    else:save_new(path,aggregate)


if __name__=='__main__':main()
