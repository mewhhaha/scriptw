"""Pure negative controls for the new scope and diagnostic admission seams."""
import copy
import hashlib
import json
from pathlib import Path
import unittest
import tempfile

from campaign import (BASE, PREFIXES, PREFIX_COUNTS, SELECTED_TOTAL,
                      family_selectors, scope_matches)
from precompiled_validation import (SAMPLES, WARMUPS, SNAPSHOTS, PROCESS_PHASES,
                                    execution, image_framing)


IDENTITY = dict(source_revision=dict(kind='git-commit', commit='1' * 40),
                source_fingerprint='2' * 64, source_fingerprint_scheme='scriptw-program-cache-compiler-v3')
EXECUTABLE = '3' * 64
IMAGE = dict(sha256='4' * 64, bytes=1234, runtime_key='5' * 64, program_sha256='6' * 64)
CASE = dict(file='test.js', stdout='42\n')


def memory():
    return dict(rss_bytes=4096, pss_bytes=3072, private_dirty_bytes=2048,
                scope='linux-process-smaps-rollup-endpoint-not-peak-or-live-js')


def valid_execution():
    return dict(schema='scriptw-precompiled-execution-v1', compiler_enabled=False,
                excluded_from_scored_cohorts=True, samples=SAMPLES, warmups=WARMUPS,
                source_commit=IDENTITY['source_revision']['commit'],
                source_fingerprint=IDENTITY['source_fingerprint'], executable_sha256=EXECUTABLE,
                compiler_identity_scheme=IDENTITY['source_fingerprint_scheme'],
                image_sha256=IMAGE['sha256'], image_bytes=IMAGE['bytes'], runtime_key=IMAGE['runtime_key'],
                program_wasm_sha256=IMAGE['program_sha256'],
                load_phases_ns=dict(engine=10, image_read_and_envelope_admission=10,
                    native_admission_and_deserialization=10, process_total=1000),
                native_load_process_memory=dict(status='sampled', interval_ns=10_000_000,
                    initial_rss_bytes=1000, final_rss_bytes=1500, maximum_rss_bytes=2000,
                    sample_count=2, elapsed_ns=1,
                    scope='native-P-and-Cargo-R-admission-process-RSS-sampled-maximum-not-peak-or-live-js'),
                process_snapshots={name: memory() for name in SNAPSHOTS},
                observations=[dict(index=i, warmup=i < WARMUPS, stdout=CASE['stdout'], completion='normal',
                    phases_ns=dict(state_linker=1, register=2, instantiate=3, execution=4, total=11),
                    gc_capacity_before_bytes=16 * 1024**2, gc_capacity_after_bytes=16 * 1024**2,
                    process_snapshots={phase: memory() for phase in PROCESS_PHASES})
                    for i in range(WARMUPS + SAMPLES)])


class ScopeAdmission(unittest.TestCase):
    def test_selected_ids_are_the_complete_disjoint_families_and_all_known_controls(self):
        import sys
        sys.path.insert(0, str(BASE.parent.parent / 'scripts'))
        from test262_execution_batches import native_inventory
        plan = json.loads((BASE / 'selected-scopes.json').read_text())
        inventory = native_inventory(Path(plan['source_inventory']['path']).read_text())
        union = set()
        self.assertEqual(len(inventory), 102994)
        self.assertEqual([row['selector'] for row in plan['scopes']], family_selectors())
        for ordinal, row in enumerate(plan['scopes']):
            actual = sorted(name for name in inventory if scope_matches(name, row['selector']))
            self.assertFalse(union.intersection(actual))
            self.assertEqual(actual, row['execution_ids'])
            self.assertEqual(len(actual), (PREFIX_COUNTS + [3551])[ordinal])
            union.update(actual)
        self.assertEqual(len(set(plan['known_failure_controls']) - union), 2)
        union.update(plan['known_failure_controls'])
        self.assertEqual(len(union), SELECTED_TOTAL)
        self.assertEqual(sorted(union), (BASE / 'selected.ids').read_text().splitlines())

    def test_metadata_predicate_includes_only_exact_basenames_outside_prior_families(self):
        selector = family_selectors()[-1]
        for path in ['built-ins/Array/prototype/push/name.js', 'built-ins/ObjectExtra/length.js']:
            self.assertTrue(scope_matches('strict-script:' + path, selector))
        for path in ['built-ins/Object/name.js', 'built-ins/Reflect/length.js',
                     'built-ins/Function/prototype.js', 'language/expressions/name.js',
                     'built-ins/Array/prototype/push/function-name.js', 'built-ins/Array/name.js.backup']:
            self.assertFalse(scope_matches('strict-script:' + path, selector))
        with self.assertRaises(ValueError):
            scope_matches('strict-script:built-ins/Array/name.js', dict(kind='unreviewed'))


class PrecompiledAdmission(unittest.TestCase):
    def test_all_warmups_and_measured_observations_have_independent_checks(self):
        result = execution(valid_execution(), IDENTITY, EXECUTABLE, IMAGE, CASE)
        self.assertEqual(result['observations'], 17)
        self.assertEqual(result['measured_samples'], 7)
        self.assertEqual(result['first_warmup']['index'], 0)
        self.assertEqual(result['measured_medians']['phases_ns']['execution'], 4)

    def test_rejects_truncation_wrong_outputs_errors_policy_and_identity(self):
        mutations = [
            lambda x: x['observations'].pop(),
            lambda x: x['observations'].append(copy.deepcopy(x['observations'][-1])),
            lambda x: x['observations'][0].update(stdout='wrong first warmup'),
            lambda x: x['observations'][10].update(stdout='wrong measured output'),
            lambda x: x['observations'][16].update(completion='throw'),
            lambda x: x['observations'][9].update(warmup=False),
            lambda x: x['observations'][1].update(index=True),
            lambda x: x['observations'][3]['phases_ns'].update(execution=-1),
            lambda x: x['observations'][3]['phases_ns'].update(total=0),
            lambda x: x['observations'][5]['process_snapshots'].pop('after_store_drop'),
            lambda x: x['process_snapshots'].pop('after_transport_drop'),
            lambda x: x['process_snapshots']['after_engine'].update(pss_bytes=999999),
            lambda x: x['process_snapshots']['after_admission'].update(scope='live-js-heap'),
            lambda x: x.pop('native_load_process_memory'),
            lambda x: x['native_load_process_memory'].update(sample_count=1),
            lambda x: x['native_load_process_memory'].update(maximum_rss_bytes=1200),
            lambda x: x['native_load_process_memory'].update(scope='true-peak-rss'),
            lambda x: x['observations'][5].update(gc_capacity_before_bytes=None),
            lambda x: x.update(compiler_enabled=True),
            lambda x: x.update(excluded_from_scored_cohorts=False),
            lambda x: x.update(samples=6),
            lambda x: x.update(warmups=9),
            lambda x: x.update(source_commit='7' * 40),
            lambda x: x.update(executable_sha256='8' * 64),
            lambda x: x.update(runtime_key=None),
            lambda x: x.update(program_wasm_sha256='9' * 64),
        ]
        for index, mutate in enumerate(mutations):
            value = valid_execution(); mutate(value)
            with self.subTest(index=index), self.assertRaises(ValueError):
                execution(value, IDENTITY, EXECUTABLE, IMAGE, CASE)

    def test_native_image_checksum_does_not_replace_source_policy_and_length_binding(self):
        program, native = b'\0asm\x01\0\0\0test', b'not-executed-native-fixture'
        body = (b'SCRWEP01' + bytes.fromhex(IDENTITY['source_fingerprint'])
                + b'\1' + bytes.fromhex(IMAGE['runtime_key']) + b'\0'
                + len(program).to_bytes(8, 'little') + len(native).to_bytes(8, 'little')
                + program + native)
        raw = body + hashlib.sha256(body).digest()
        frame = image_framing(raw, IDENTITY['source_fingerprint'])
        self.assertEqual(frame['program_bytes'], len(program))
        self.assertEqual(frame['native_serialized_bytes'], len(native))
        for offset, value in [(8, 0), (40, 2), (73, 1), (74, 0)]:
            changed = bytearray(body); changed[offset] = value
            changed += hashlib.sha256(changed).digest()
            with self.subTest(offset=offset), self.assertRaises(ValueError):
                image_framing(bytes(changed), IDENTITY['source_fingerprint'])
        for changed in [raw[:-1], raw + b'\0', raw[:-1] + b'\0']:
            with self.assertRaises(ValueError):
                image_framing(changed, IDENTITY['source_fingerprint'])


class HistoricalAudit(unittest.TestCase):
    def test_explicit_history_retains_original_sources_and_zero_accepted_counts(self):
        import prior_attempts
        actual = prior_attempts.validate()
        self.assertEqual(actual['accepted_count_contribution'], 0)
        self.assertIs(actual['included_in_accepted_totals'], False)
        self.assertEqual((actual['historical_passed'], actual['historical_failed']), (26, 1))
        first, second, corrected = actual['development']
        self.assertNotEqual(first['source_snapshot_sha256'], second['source_snapshot_sha256'])
        self.assertEqual(corrected['source_base'], prior_attempts.ATTEMPT_SOURCE)

    def test_history_rejects_incomplete_unlisted_relabelled_and_over_budget_records(self):
        import prior_attempts
        original = json.loads((BASE / prior_attempts.MANIFEST).read_text())
        mutations = [
            lambda x: x['files'].pop(),
            lambda x: x['files'].__setitem__(1, copy.deepcopy(x['files'][0])),
            lambda x: x['files'][0].update(path='../escaped.log'),
            lambda x: x['files'][0].update(origin_path='/tmp/relabelled.log'),
            lambda x: x['files'][0].update(included_in_accepted_totals=True),
            lambda x: x['files'][0]['source_context'].update(source_commit='0' * 40),
            lambda x: x['files'][0].update(bytes=prior_attempts.MAX_MEMBER_BYTES + 1),
            lambda x: x.update(included_in_accepted_totals=True),
            lambda x: x.update(total_bytes=prior_attempts.MAX_BYTES + 1),
        ]
        for index, mutate in enumerate(mutations):
            value = copy.deepcopy(original); mutate(value)
            with self.subTest(index=index), self.assertRaises(ValueError):
                prior_attempts.validate_inventory(value)

    def test_historical_payload_corruption_does_not_match_its_original(self):
        import prior_attempts
        manifest = json.loads((BASE / prior_attempts.MANIFEST).read_text())
        row = manifest['files'][0]
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory); path = root / row['path']
            path.parent.mkdir(parents=True)
            path.write_bytes((BASE / row['path']).read_bytes())
            prior_attempts.validate_member(row, root)
            path.write_bytes(path.read_bytes() + b'corrupt')
            with self.assertRaises(ValueError):
                prior_attempts.validate_member(row, root)


if __name__ == '__main__':
    unittest.main()
