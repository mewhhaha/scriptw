"""Shared bounded execution helpers; importing this module launches nothing."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

from campaign_identity import BASE, BASELINE_SOURCE, REJECTED_ATTEMPT_SOURCE, REJECTED_NATIVE_SOURCE, REPO, digest, read, require

EMPTY = hashlib.sha256(b'').hexdigest()
LIMIT = 4 * 1024**3
SUMMARY = re.compile(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out')


def actual_source():
    campaign = read(BASE / 'campaign.json')
    source = campaign.get('source_commit', '')
    require(re.fullmatch(r'[0-9a-f]{40}', source) and source not in {BASELINE_SOURCE, REJECTED_ATTEMPT_SOURCE, REJECTED_NATIVE_SOURCE}
            and campaign.get('baseline_source') == BASELINE_SOURCE
            and campaign.get('baseline_exact_patch_sha256') == EMPTY,
            'actual committed candidate campaign is not prepared')
    require(subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip() == source,
            'checkout is not the actual admitted candidate source')
    require(subprocess.check_output(['git', 'diff', '--binary', source, '--', 'crates', 'vendor', 'Cargo.toml', 'Cargo.lock'], cwd=REPO) == b''
            and subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard', '--', 'crates', 'vendor', 'Cargo.toml', 'Cargo.lock'], cwd=REPO) == b'',
            'commit the complete coherent product source before native work')
    return source


def require_scope():
    sys.path.insert(0, str(REPO / 'scripts'))
    from limited_verification import require_kernel_budget
    require_kernel_budget(LIMIT)
    require(sorted(os.sched_getaffinity(0)) == [0], 'native execution requires the reviewed one-CPU0 scope')
    expected = dict(CARGO_BUILD_JOBS='1', SCRIPTW_JOBS='1', RUST_TEST_THREADS='1', RAYON_NUM_THREADS='1',
                    SCRIPTW_MODULE_MEMORY_CACHE_ENTRIES='1', SCRIPTW_MODULE_MEMORY_CACHE_LIMIT_BYTES=str(64 * 1024**2))
    require(all(os.environ.get(name) == value for name, value in expected.items()), 'serial workers/bounded module cache environment differs')


def own(name, *arguments):
    return [sys.executable, '-B', str(BASE / name), *map(str, arguments)]


def checked_receipt(label, command, expected=0):
    row = read(BASE / (label + '.json'))
    require(row['label'] == label and row['command'] == command and row['exit_code'] == expected
            and row['source_head'] == actual_source() and row['source_patch_sha256'] == EMPTY
            and row['product_source_roots'] == ['crates', 'vendor', 'Cargo.toml', 'Cargo.lock']
            and row.get('source_head_after') == row['source_head'] and 'source_changed_after_child' not in row
            and row['log'] == label + '.log' and digest(BASE / row['log']) == row['log_sha256'],
            'closed actual receipt differs: ' + label)
    return row


def check(label, command, *, expected=0, reuse=True):
    actual_source(); require_scope()
    command = list(map(str, command))
    if (BASE / (label + '.json')).exists():
        require(reuse, 'refusing to overwrite a completed receipt: ' + label)
        return checked_receipt(label, command, expected)
    require(not (BASE / (label + '.log')).exists(), 'partial observation is retained; use a reviewed new campaign, not overwrite: ' + label)
    actual = subprocess.call(own('run_check.py', label, *command), cwd=REPO)
    require(actual == expected, f'actual exit{actual}, expected{expected}: {label}; retain/investigate the observation')
    return checked_receipt(label, command, expected)


def save_new(path, value):
    with Path(path).open('x') as stream:
        stream.write(json.dumps(value, indent=2) + '\n')


def progress(path, value):
    path = Path(path)
    temporary = path.with_suffix(path.suffix + '.pending')
    require(not temporary.exists(), 'partial progress write is retained: ' + str(temporary))
    with temporary.open('x') as stream:
        stream.write(json.dumps(value, indent=2) + '\n')
    temporary.replace(path)


def inventory(text, *, allow_zero=False):
    names = sorted(re.findall(r'^([^\s]+): test$', text, re.M))
    require(len(names) == len(set(names)) and (names or allow_zero and '0 tests, 0 benchmarks' in text),
            'complete native enumeration is empty/repeated without an explicit zero-case target')
    return names


def native_result(row, names, filtered=0):
    text = (BASE / row['log']).read_text()
    observed = [(name.removesuffix(' - should panic'), state) for name, state in
                re.findall(r'^test (.+) \.\.\. (ok|FAILED|ignored)$', text, re.M)]
    terminal = [('ok', str(len(names)), '0', '0', '0', str(filtered))]
    require(sorted(name for name, _ in observed) == sorted(names) and all(state == 'ok' for _, state in observed)
            and SUMMARY.findall(text) == terminal and row['test_results'] == [list(terminal[0])],
            'native transcript/summary does not reconcile with its exact complete inventory: ' + row['label'])


def cargo_target(scope):
    result = ['cargo', 'test', '--locked', '--offline', '--release', '--jobs', '1', '-p', scope['package'], scope['kind']]
    return result + ([scope['name']] if scope['name'] is not None else [])
