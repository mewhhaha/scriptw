"""Pure actual identities for the ignored runtime-admission memory campaign.

The published259 frozen products remain external authorities. Candidate source
is unresolved until real campaign.json and candidate/identity.json agree.
Importing this module runs no compiler, native test or workload.
"""
import hashlib
import json
import os
from pathlib import Path
import re

BASE = Path(__file__).resolve().parent
REPO = BASE.parent.parent
PRIOR = REPO / 'target/memory-admission-20261025'
BASELINE_DIRECTORY = PRIOR / 'candidate'
BASELINE_DIAGNOSTIC_DIRECTORY = PRIOR / 'candidate-engine-allocation-probe'
ALLOCATION_HELPER = REPO / 'target/memory-fixed-costs-20261025/engine_allocation_diagnostic.rs'
REJECTED_ATTEMPT_SOURCE = '8b38b0afde3266ed6b51247aedccaece81a8c77c'
REJECTED_NATIVE_SOURCE = 'e36a4f029f273d86290e5ce6238bfe721e1eff78'
BASELINE_SOURCE = '25909ef750d487e8ae257cdce909635d64196995'
BASELINE_ARCHIVE_SHA256 = '247e22b3216ab18cac0d5131d77d25b43ce03f070e1ace1dc3b7ae88d31f063c'
BASELINE_FINGERPRINT = '9fe011fe7d00a6dd51ce44d738a000de3af30f259df32b029b608cc3fbf3a497'
BASELINE_PRODUCTS = {
    'scriptw': 'b5b769abf75b917ec587a60165f38e5b3adca14cdfc1a4b1c94cab295dbde120',
    'runtime_baseline': '0091c377b653dd08e00232e7ab707057967f11b5210aacc25f419ff647128175',
    'runtime_boundaries': '4ede4c047fe4e7f2b0dc044f050bd207ead8598cf465c05f6ac3dd210a867259',
}
INSTRUMENTATION = (
    'SCRIPTW_PERF_MAP_DIR', 'SCRIPTW_WASM_TRACE', 'SCRIPTW_WASM_TRACE_DUMP',
    'SCRIPTW_EMIT_SIZE_REPORT', 'SCRIPTW_ROW_PERF_CONTROL', 'SCRIPTW_ROW_PERF_ACK',
    'SCRIPTW_ROW_PERF_REGION', 'SCRIPTW_BOUNDARY_READY_FD', 'SCRIPTW_BOUNDARY_READY_NONCE',
)


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def read(path):
    path = Path(path)
    require(path.is_file() and not path.is_symlink(), 'missing/symlinked actual authority: ' + str(path))
    return json.loads(path.read_text())


def product_directory(product):
    require(product in ['baseline', 'candidate'], 'unknown frozen product')
    return BASELINE_DIRECTORY if product == 'baseline' else BASE / 'candidate'


def baseline_authority():
    reference = read(BASE / 'baseline-reference.json')
    require(reference['schema'] == 'scriptw-memory-admission-baseline-reference-v1'
            and reference['baseline_source'] == BASELINE_SOURCE
            and reference['prior_archive']['sha256'] == BASELINE_ARCHIVE_SHA256, 'baseline reference source/schema changed')
    expected = {'identity': BASELINE_DIRECTORY / 'identity.json', 'frozen_products': PRIOR / 'frozen-products.json',
                'source_checkpoint': REPO / 'docs/rust-rewrite/execution-memory-admission-20261025.json',
                'allocation_report': BASELINE_DIAGNOSTIC_DIRECTORY / 'report.json'}
    for name, path in expected.items():
        require(reference[name]['path'] == str(path) and digest(path) == reference[name]['sha256'],
                'published baseline authority bytes changed: ' + name)
    report = read(expected['source_checkpoint'])
    require(report['complete'] is True and report['source_commit'] == BASELINE_SOURCE
            and report['products']['candidate']['compiler_identity'] == read(expected['identity']),
            'baseline checkpoint does not admit the frozen259 identity')
    return reference


def checked_identity(product):
    identity = read(product_directory(product) / 'identity.json')
    require(identity.get('source_fingerprint_scheme') == 'scriptw-program-cache-compiler-v3'
            and re.fullmatch(r'[0-9a-f]{64}', identity.get('source_fingerprint', ''))
            and re.fullmatch(r'[0-9a-f]{64}', identity.get('executable_sha256', '')),
            product + ': malformed compiler identity')
    revision = identity.get('source_revision', {})
    require(revision.get('kind') == 'git-commit' and re.fullmatch(r'[0-9a-f]{40}', revision.get('commit', '')),
            product + ': no actual committed source')
    if product == 'baseline':
        baseline_authority()
        require(revision['commit'] == BASELINE_SOURCE and identity['source_fingerprint'] == BASELINE_FINGERPRINT
                and identity['executable_sha256'] == BASELINE_PRODUCTS['scriptw'],
                'baseline is not the exact published259 product')
    else:
        require(revision['commit'] not in {BASELINE_SOURCE, REJECTED_ATTEMPT_SOURCE, REJECTED_NATIVE_SOURCE}, 'candidate must not silently reuse the old baseline source')
    return identity


def candidate_source():
    campaign = read(BASE / 'campaign.json')
    source = checked_identity('candidate')['source_revision']['commit']
    require(campaign['source_commit'] == source and campaign['baseline_source'] == BASELINE_SOURCE,
            'candidate source and actual campaign differ')
    return source


def product_source(product):
    source = checked_identity(product)['source_revision']['commit']
    require(source == (BASELINE_SOURCE if product == 'baseline' else candidate_source()),
            'product source and actual authority differ')
    return source


def frozen_product(product):
    identity = checked_identity(product)
    candidate_source()
    reference = baseline_authority() if product == 'baseline' else None
    hashes = {}
    for name in ['scriptw', 'runtime_baseline', 'runtime_boundaries']:
        path = product_directory(product) / name
        require(path.is_file() and not path.is_symlink() and path.stat().st_nlink == 1,
                'missing/symlinked/hardlinked frozen product: ' + str(path))
        hashes[name] = digest(path)
        if product == 'baseline':
            require(hashes[name] == BASELINE_PRODUCTS[name] == reference['products'][name]['sha256']
                    and reference['products'][name]['path'] == str(path), 'independent baseline changed: ' + name)
    require(hashes['scriptw'] == identity['executable_sha256'], 'actual frozen CLI identity differs')
    return identity, hashes


def ordinary_environment(environment=None):
    result = dict(os.environ if environment is None else environment)
    for name in INSTRUMENTATION:
        result.pop(name, None)
    result.pop('NODE_OPTIONS', None)
    result.pop('NODE_COMPILE_CACHE', None)
    result['NODE_DISABLE_COMPILE_CACHE'] = '1'
    result['SCRIPTW_COMPILER_CACHE_IMAGE_HASH'] = 'sha256'
    result.update(CARGO_BUILD_JOBS='1', SCRIPTW_JOBS='1', RUST_TEST_THREADS='1', RAYON_NUM_THREADS='1',
                  SCRIPTW_MODULE_MEMORY_CACHE_ENTRIES='1', SCRIPTW_MODULE_MEMORY_CACHE_LIMIT_BYTES=str(64 * 1024**2))
    return result


def environment_receipt(environment):
    names = [*INSTRUMENTATION, 'NODE_OPTIONS', 'NODE_COMPILE_CACHE', 'NODE_DISABLE_COMPILE_CACHE',
             'SCRIPTW_COMPILER_CACHE_IMAGE_HASH', 'CARGO_BUILD_JOBS', 'SCRIPTW_JOBS', 'RUST_TEST_THREADS',
             'RAYON_NUM_THREADS', 'SCRIPTW_MODULE_MEMORY_CACHE_ENTRIES', 'SCRIPTW_MODULE_MEMORY_CACHE_LIMIT_BYTES']
    return {name: environment.get(name) for name in names}


def validate_environment(environment):
    require(environment == environment_receipt(ordinary_environment({})),
            'ordinary serial/cache policy or disabled instrumentation differs')
