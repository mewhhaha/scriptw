#!/usr/bin/env python3
"""Record ordinary fresh-Store/context execution without instrumentation.

No Cargo build is invoked. Partial rounds and raw child streams are retained.
Only complete seven-sample/ten-warmup rounds can enter the ABBA analysis.
"""
from campaign_identity import product_directory
import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import shutil
import statistics
import subprocess
import sys
import time

from campaign_identity import (
    BASE, candidate_source, digest, environment_receipt, frozen_product,
    ordinary_environment, read, require,
)

REPO = BASE.parent.parent
FIXTURES = REPO / 'crates/scriptw-cli/tests/fixtures/v8_execution_hotpaths'
NODE_HARNESS = REPO / 'crates/scriptw-cli/tests/fixtures/v8_baseline/node-runtime.cjs'
sys.path.insert(0, str(REPO / 'scripts'))
from limited_verification import require_kernel_budget


def stamp():
    return datetime.now(timezone.utc).isoformat()


def manifest_plan():
    plan = read(FIXTURES / 'manifest.json')['execution']
    require(len(plan) == len({row['file'] for row in plan}) == 17, 'exact17 admitted fixtures required')
    require(all(Path(row['file']).name == row['file'] for row in plan), 'fixture basename required')
    return plan


def run(args):
    require_kernel_budget(4 * 1024**3)
    require(len(os.sched_getaffinity(0)) == 1, 'one inherited CPU required')
    require(Path(args.label).name == args.label, 'round label must be a basename')
    plan = manifest_plan()
    if args.cases:
        require(len(set(args.cases)) == len(args.cases) and set(args.cases) <= {row['file'] for row in plan},
                'invalid focused fixture selection')
        plan = [row for row in plan if row['file'] in args.cases]
    identity, product_hashes = frozen_product(args.product)
    product = product_directory(args.product)
    runner = product / 'runtime_baseline'
    node = Path(shutil.which('node') or '/missing-node').resolve()
    require(node.is_file(), 'actual Node executable is required')
    output = BASE / args.label
    output.mkdir(exist_ok=False)
    harness = output / 'node-runtime.cjs'
    shutil.copyfile(NODE_HARNESS, harness)
    environment = ordinary_environment()
    environment['SCRIPTW_CACHE_DIR'] = str(output / 'execution-cache')
    report = dict(schema='scriptw-execution-fresh-round-v1', complete=False,
                  product=args.product, label=args.label, compiler_identity=identity,
                  campaign_source=candidate_source(), frozen_product_sha256=product_hashes,
                  runtime_runner_sha256=product_hashes['runtime_baseline'], samples=7, warmups=10,
                  case_results=[], affinity=sorted(os.sched_getaffinity(0)),
                  started_at=stamp(), loadavg_start=list(os.getloadavg()),
                  boundary='ordinary precompiled source, fresh Store/Realm or V8 context, execution+completion only; '
                           'construction/checksum included; no subtracting empty program',
                  memory='process RSS and GC capacity; not allocation count or live JS bytes',
                  environment=environment_receipt(environment),
                  binaries={'scriptw': dict(path=str(product / 'scriptw'), sha256=product_hashes['scriptw']),
                            'wasmtime': dict(path=str(runner), sha256=product_hashes['runtime_baseline']),
                            'v8': dict(path=str(node), sha256=digest(node))},
                  node_harness=dict(path=harness.name, sha256=digest(harness)),
                  driver_sha256=digest(__file__), manifest_sha256=digest(FIXTURES / 'manifest.json'))

    def save():
        pending = output / 'report.pending'
        pending.write_text(json.dumps(report, indent=2) + '\n')
        pending.replace(output / 'report.json')

    def invoke(command, stdout_path, stderr_path, binary):
        require(digest(binary['path']) == binary['sha256'], 'executed binary changed before launch')
        event = dict(command=list(map(str, command)), started_at=stamp(), state='running',
                     cwd=str(REPO), stdout_file=stdout_path.name, stderr_file=stderr_path.name)
        started = time.monotonic()
        try:
            with stdout_path.open('xb') as stdout, stderr_path.open('xb') as stderr:
                actual = subprocess.run(command, cwd=REPO, stdout=stdout, stderr=stderr,
                                        env=environment, timeout=900)
            event.update(exit_code=actual.returncode, timed_out=False)
        except subprocess.TimeoutExpired:
            event.update(exit_code=None, timed_out=True)
        event.update(wall_seconds=time.monotonic() - started, state='finished', finished_at=stamp(),
                     stdout_sha256=digest(stdout_path), stderr_sha256=digest(stderr_path))
        require(digest(binary['path']) == binary['sha256'], 'executed binary changed during invocation')
        return event

    save()
    try:
        event = invoke([product / 'scriptw', 'compiler-identity'], output / 'identity.stdout',
                       output / 'identity.stderr', report['binaries']['scriptw'])
        report['identity_command'] = event
        save()
        require(event['exit_code'] == 0 and not event['timed_out']
                and read(output / 'identity.stdout') == identity, 'actual CLI identity differs')
        order = ['v8', 'wasmtime'] if args.reverse else ['wasmtime', 'v8']
        for case in plan:
            name = case['file']
            row = dict(file=name, source_sha256=digest(FIXTURES / name),
                       expected_stdout=case['stdout'], runtime_order=order, runtimes={})
            report['case_results'].append(row)
            save()
            for runtime in order:
                if runtime == 'wasmtime':
                    artifacts = output / (name + '-wasm')
                    artifacts.mkdir()
                    command = [runner, FIXTURES, '7', '10', name, artifacts]
                else:
                    command = [node, harness, FIXTURES, '7', '10', name]
                event = invoke(command, output / (name + '-' + runtime + '.stdout'),
                               output / (name + '-' + runtime + '.stderr'), report['binaries'][runtime])
                row['runtimes'][runtime] = event
                save()
                require(event['exit_code'] == 0 and not event['timed_out'], 'workload process failed: ' + name + '/' + runtime)
                data = read(output / event['stdout_file'])
                require(data['samples'] == 7 and data['warmups'] == 10 and len(data['cases']) == 1,
                        'wrong observation denominator')
                child = data['cases'][0]
                observations = child['observations']
                require(child['file'] == name and child['source_sha256'] == row['source_sha256']
                        and len(observations) == 17
                        and [item['warmup'] for item in observations] == [True] * 10 + [False] * 7
                        and all(item['stdout'] == case['stdout'] for item in observations),
                        'actual source, output or observation order differs')
                if runtime == 'wasmtime':
                    require(data['source_commit'] == identity['source_revision']['commit']
                            and data['source_fingerprint'] == identity['source_fingerprint']
                            and data['executable_sha256'] == product_hashes['runtime_baseline']
                            and data['requested_native_policy'] is None, 'actual runner identity/policy differs')
                require(digest(harness) == report['node_harness']['sha256'], 'Node harness changed')
                event['data'] = data
                save()
            print(name, *(runtime + ':' + str(round(statistics.median(
                x['execution_ns'] for x in row['runtimes'][runtime]['data']['cases'][0]['observations']
                if not x['warmup']) / 1e6, 3)) + 'ms' for runtime in order), flush=True)
        report.update(complete=True, finished_at=stamp(), loadavg_end=list(os.getloadavg()))
    except BaseException as error:
        report['failure'] = str(error)
        raise
    finally:
        save()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('product', choices=['baseline', 'candidate'])
    parser.add_argument('label')
    parser.add_argument('--samples', type=int, choices=[7], default=7)
    parser.add_argument('--warmups', type=int, choices=[10], default=10)
    parser.add_argument('--cases', nargs='*')
    parser.add_argument('--reverse', action='store_true')
    parser.add_argument('--plan-only', action='store_true')
    args = parser.parse_args()
    if args.plan_only:
        print(json.dumps(manifest_plan(), indent=2))
    else:
        run(args)


if __name__ == '__main__':
    try:
        main()
    except (KeyError, ValueError, OSError, TypeError, subprocess.SubprocessError) as error:
        raise SystemExit('Fresh measurement refused: ' + str(error))
