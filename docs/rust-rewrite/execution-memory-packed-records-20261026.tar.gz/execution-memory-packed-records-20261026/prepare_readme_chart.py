"""Prepare exact documentation diffs only after final evidence exists; never apply."""
import argparse
import difflib
import hashlib
import json
from pathlib import Path
import statistics
import sys

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
STEM = 'execution-memory-packed-records-20261026'
FINAL = '736f0f1206c581e70048467f7d4423e1efed8bdd'
BASELINE = '25909ef750d487e8ae257cdce909635d64196995'
REUSED = 'e36a4f029f273d86290e5ce6238bfe721e1eff78'


def need(condition, reason):
    if not condition:
        raise ValueError(reason)


def replace_once(text, old, new):
    need(text.count(old) == 1, 'documentation anchor changed: ' + old[:80])
    return text.replace(old, new, 1)


def prepare():
    sys.path.insert(0, str(ROOT / 'scripts'))
    from execution_chart_data import load_chart_data
    report_path = ROOT / f'docs/rust-rewrite/{STEM}.json'
    data = load_chart_data(report_path)
    need(data['source_commit'] == FINAL and data['baseline_commit'] == BASELINE,
         'final/baseline identity differs from the reviewed batch')
    report = json.loads(report_path.read_bytes())
    rows = report['performance']['rss_table']
    cases = report['performance']['balanced_observations']['cases']
    need(len(rows) == len(cases) == 17, 'need every final ordinary workload')
    for row, case in zip(rows, cases):
        need(row['file'] == case['file'], 'ordinary RSS order differs')
        for product, field in [('baseline', 'baseline_rss_bytes'), ('candidate', 'candidate_rss_bytes')]:
            observed = case['pooled'][product]['wasmtime']['memory_observations']['final_rss_bytes']
            need(len(observed['values']) == 14 and row[field] == statistics.median(observed['values']),
                 'ordinary RSS endpoint median differs')
        observed = case['pooled']['candidate']['v8']['memory_observations']['rss_after_execution_bytes']
        need(len(observed['values']) == 14 and row['paired_candidate_v8_rss_bytes'] == statistics.median(observed['values']),
             'paired V8 RSS endpoint median differs')
    memory = {row['file']: row for row in rows}
    reductions = [100 * (1 - row['candidate_rss_bytes'] / row['baseline_rss_bytes']) for row in rows]
    ratios = [row['candidate_rss_bytes'] / row['paired_candidate_v8_rss_bytes'] for row in rows]
    faster = sum(row['candidate_ms'] < row['baseline_ms'] for row in report['performance']['table'])
    slower = sum(row['candidate_ms'] > row['baseline_ms'] for row in report['performance']['table'])
    improved = sum(value > 0 for value in reductions)
    regressed = sum(value < 0 for value in reductions)
    if improved == 17:
        summary = (f'Against `25909ef75` in a paired rerun, all 17 fresh-Realm workloads\n'
                   f'use **{min(reductions):.1f}–{max(reductions):.1f}% less post-execution process RSS**. ')
    else:
        summary = (f'Against `25909ef75` in a paired rerun, post-execution process RSS fell in\n'
                   f'**{improved} of 17 fresh-Realm workloads** and increased in **{regressed}**. ')
    def point(name):
        row = memory[name]
        return (f"**{row['baseline_rss_bytes']/2**20:.2f} → {row['candidate_rss_bytes']/2**20:.2f} MiB** "
                f"(paired V8: **{row['paired_candidate_v8_rss_bytes']/2**20:.2f} MiB**)")
    summary += (f'Integer execution used\n{point("integer.js")}; retained objects used\n'
                f'{point("retained-objects.js")}. Across this corpus, Scriptw uses\n'
                f'**{min(ratios):.2f}–{max(ratios):.2f}× V8 RSS**. RSS includes host/runtime, setup and\n'
                'retained warmup effects; it is not live JavaScript heap usage or peak memory.\n'
                f'Timing improved in **{faster} workloads** and regressed in **{slower}**; the checkpoint\n'
                'retains every workload and separate existing-Realm controls. Shared-host\n'
                'observations do not establish statistical significance or V8 parity.\n\n')
    original = (ROOT / 'README.md').read_text()
    start = original.index('Against the previous compiler in a paired rerun,')
    end = original.index('The runtime separates build-admitted Intl metadata', start)
    proposed = original[:start] + summary + original[end:]
    proposed = replace_once(proposed,
        '[Latest measurements and evidence](docs/rust-rewrite/execution-memory-admission-20261025.md)',
        f'[Latest measurements and evidence](docs/rust-rewrite/{STEM}.md)')
    old_explanation = ('The linked checkpoint retains its measured first-use cost, allocation\n'
        'diagnostics and repeated-call controls. The graph remains\n'
        'bound to the measured compiler and date shown in it; see the\n')
    new_explanation = ('The checkpoint retains first-use, allocation and repeated-call diagnostics.\n'
        'Its separate compiler-disabled precompiled experiment has 17 candidate-only\n'
        'cases, retains loading costs and has no older API baseline; it contributes\n'
        'no samples to the ordinary graph. The graph remains bound to its measured\n'
        'compiler and date; see the\n')
    proposed = replace_once(proposed, old_explanation, new_explanation)
    native, tests = report['native'], report['test262']
    breakdown = native['source_breakdown']
    need(len(breakdown) == 2 and breakdown[0]['source'] == REUSED and breakdown[0]['targets'] == 31
         and breakdown[1]['source'] == FINAL and breakdown[1]['targets'] == 1
         and native['all_scopes_executed_on_final_source'] is False,
         'mixed-source native evidence differs')
    acceptance = (f'The [packed-record memory checkpoint](docs/rust-rewrite/{STEM}.md),\n'
        f"refreshed {report['refresh_date']} at `{FINAL[:9]}`, records **{native['passed']:,} affected native\n"
        f"checks across {native['target_count']} targets**. This combines 31 unchanged targets executed at\n"
        f'`{REUSED[:9]}` with the complete repaired structural target at `{FINAL[:9]}`;\n'
        'the exact test-only source comparison and original execution identities are\n'
        'retained. It is not a fresh full native sweep on the final commit. The final\n'
        f"compiler's selected Test262 replay passed **{tests['passed']:,} / {tests['total']:,} executions**,\n"
        f"with **{tests['bug']} failures, {tests['crash']} crashes, {tests['not_implemented']} unsupported cases and\n"
        f"{tests['timeout']} timeouts**. Verification used one CPU, a 4-GiB memory cap and no swap.\n"
        'Existing source-tooling failures remain recorded; refresh commands and exact\n'
        'inventories are linked. The full pinned Test262 chart is unchanged.\n\n')
    start = proposed.index('The [runtime-admission memory checkpoint]')
    end = proposed.index('<!-- scriptw-test-graph:start -->', start)
    proposed = proposed[:start] + acceptance + proposed[end:]
    marker_start, marker_end = '<!-- scriptw-test-graph:start -->', '<!-- scriptw-test-graph:end -->'
    old_block = original[original.index(marker_start):original.index(marker_end) + len(marker_end)]
    need(proposed[proposed.index(marker_start):proposed.index(marker_end) + len(marker_end)] == old_block,
         'full pinned Test262 graph block changed')
    old_full = original[original.index('**Full verification,'):original.index('The [runtime-admission memory checkpoint]')]
    need(old_full in proposed, 'full pinned verification/history text changed')
    renderer_path = 'scripts/render-execution-performance.py'
    renderer = (ROOT / renderer_path).read_text()
    new_renderer = replace_once(renderer, "REPORT = ROOT / 'docs/rust-rewrite/execution-memory-admission-20261025.json'",
        f"REPORT = ROOT / 'docs/rust-rewrite/{STEM}.json'")
    contract_path = 'docs/rust-rewrite/contracts/performance-history.md'
    contract = (ROOT / contract_path).read_text()
    new_contract = replace_once(contract,
        '[2026-10-26 runtime-admission memory checkpoint](../execution-memory-admission-20261025.md)',
        f"[{report['refresh_date']} packed-record memory checkpoint](../{STEM}.md)")
    outputs = [('README.md', original, proposed, 'README.proposed.md'),
               (renderer_path, renderer, new_renderer, 'render-execution-performance.proposed.py'),
               (contract_path, contract, new_contract, 'performance-history.proposed.md')]
    diff = ''
    for path, old, new, output in outputs:
        with (BASE / output).open('x') as file:
            file.write(new)
        diff += ''.join(difflib.unified_diff(old.splitlines(keepends=True), new.splitlines(keepends=True),
                                            fromfile='a/' + path, tofile='b/' + path))
    with (BASE / 'README-CHART.patch').open('x') as file:
        file.write(diff)
    metrics = dict(source_commit=FINAL, baseline_commit=BASELINE, refresh_date=report['refresh_date'],
        source_report_sha256=hashlib.sha256(report_path.read_bytes()).hexdigest(),
        improved_rss_workloads=improved, regressed_rss_workloads=regressed,
        rss_reductions_percent=reductions, rss_over_paired_v8=ratios,
        faster_workloads=faster, slower_workloads=slower, ordinary_rss_table=rows,
        native_source_breakdown=breakdown, test262=tests['outcomes'],
        preserved_test262_svg_sha256=hashlib.sha256((ROOT / 'docs/rust-rewrite/assets/test262-status.svg').read_bytes()).hexdigest())
    with (BASE / 'README-CHART-metrics.json').open('x') as file:
        file.write(json.dumps(metrics, indent=2) + '\n')
    print(json.dumps(dict(prepared=True, tracked_files_changed=False, source=FINAL)))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--prepare', action='store_true')
    if parser.parse_args().prepare:
        prepare()
    else:
        print(json.dumps(dict(execution=False, tracked_files_changed=False,
            requires='published final checkpoint plus explicit root release before applying any patch',
            expected_source=FINAL, expected_baseline=BASELINE)))


if __name__ == '__main__':
    main()
