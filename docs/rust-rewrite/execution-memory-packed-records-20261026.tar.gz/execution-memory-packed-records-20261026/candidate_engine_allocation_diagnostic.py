#!/usr/bin/env python3
"""Link a separate CountingSystem helper against frozen actual candidate Cargo inputs.

No Cargo build is invoked. The default checks preparation only. --compile links
the helper; --run links then runs scalar/print/retained in separate processes,
twice within each process. Run those modes only inside limited_verification.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import select
import shutil
import signal
import subprocess
import sys
import time

BASE = Path(__file__).resolve().parent
ROOT = BASE.parent.parent
SOURCE = ROOT / 'target/memory-fixed-costs-20261025/engine_allocation_diagnostic.rs'
INPUTS = BASE / 'frozen-candidate-link-inputs.json'
from freeze_candidate_link_inputs import validate_frozen_inputs
sys.path.insert(0, str(ROOT / 'scripts'))
from limited_verification import require_kernel_budget
from process_memory_maps import parse_smaps, read_smaps

PHASES = ['before_engine', 'after_engine', 'after_compilation', 'guest_start_1',
          'guest_body_finished_1', 'after_execution_1', 'after_dropping_profile_1',
          'guest_start_2', 'guest_body_finished_2', 'after_execution_2',
          'after_dropping_profile_2', 'after_dropping_artifact', 'after_dropping_engine']


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def stamp():
    return datetime.now(timezone.utc).isoformat()


def validate_inputs():
    return validate_frozen_inputs()


def run(args):
    inputs, engine = validate_inputs()
    source_commit = inputs['source_commit']
    source_fingerprint = inputs['source_fingerprint']
    if not (args.compile or args.run):
        print(json.dumps({'prepared': True, 'source_commit': source_commit,
                          'source_sha256': digest(SOURCE), 'engine_rlib_sha256': digest(engine),
                          'frozen_link_files': len(inputs['files']), 'native_execution': False}))
        return
    require_kernel_budget(4 * 1024**3)
    require(len(os.sched_getaffinity(0)) == 1, 'diagnostic requires inherited one-CPU affinity')
    output = args.output.resolve()
    require(output.is_relative_to(BASE) and output != BASE, 'output must be new inside ignored campaign')
    output.mkdir(exist_ok=False)
    rustc = Path(shutil.which(os.environ.get('RUSTC', 'rustc')) or '/missing-rustc')
    require(rustc.is_file(), 'rustc is required')
    binary = output / 'engine_allocation_diagnostic'
    report = dict(schema='scriptw-engine-allocation-link-v1', complete=False, started_at=stamp(),
                  source_commit=source_commit, source_fingerprint=source_fingerprint,
                  helper_source=dict(path=str(SOURCE), sha256=digest(SOURCE)),
                  driver=dict(path=str(Path(__file__).resolve()), sha256=digest(__file__)),
                  frozen_inputs=dict(path=str(INPUTS), sha256=digest(INPUTS), **inputs),
                  cpu_affinity=sorted(os.sched_getaffinity(0)), commands=[], cases=[],
                  scope='Distinct helper ELF using pinned public product library APIs and System allocator counters; '
                        'diagnostic phases and RSS are not accepted benchmark scores or allocation ownership claims.',
                  environment_policy='Private fresh disk caches; module cache one entry/64MiB; one compilation worker; '
                                     'no native perf-map hashing, GC changes or allocator trim.')

    def save():
        pending = output / 'report.pending'
        pending.write_text(json.dumps(report, indent=2) + '\n')
        pending.replace(output / 'report.json')

    def invoke(label, command, timeout):
        event = dict(label=label, command=list(map(str, command)), cwd=str(ROOT),
                     started_at=stamp(), state='running', stdout_file=label + '.stdout',
                     stderr_file=label + '.stderr')
        report['commands'].append(event)
        save()
        started = time.monotonic()
        with (output / event['stdout_file']).open('xb') as stdout, (output / event['stderr_file']).open('xb') as stderr:
            try:
                actual = subprocess.run(command, cwd=ROOT, stdout=stdout, stderr=stderr, timeout=timeout)
                event.update(exit_code=actual.returncode, timed_out=False)
            except subprocess.TimeoutExpired:
                event.update(exit_code=None, timed_out=True)
        event.update(state='closed', seconds=time.monotonic() - started, finished_at=stamp(),
                     stdout_sha256=digest(output / event['stdout_file']),
                     stderr_sha256=digest(output / event['stderr_file']))
        save()
        require(event['exit_code'] == 0 and not event['timed_out'], label + ' failed; logs retained')
        return (output / event['stdout_file']).read_text()

    save()
    report['rustc'] = dict(invoker_path=str(rustc), resolved_invoker_path=str(rustc.resolve()),
                           invoker_sha256=digest(rustc), version=invoke('rustc-version', [rustc, '-vV'], 30))
    command = [rustc, '--edition=2021', '--crate-name=scriptw_engine_allocation_diagnostic',
               '--crate-type=bin', '-Copt-level=3', '-Cdebuginfo=0', '-Ccodegen-units=1',
               '-Ldependency=' + str(engine.parent)]
    command += ['-Lnative=' + str(BASE / path) for path in inputs['native_search_paths']]
    command += ['--extern', 'scriptw_engine=' + str(engine), str(SOURCE), '-o', str(binary)]
    invoke('compile', command, 600)
    validate_inputs()
    require(digest(SOURCE) == report['helper_source']['sha256'], 'helper source changed while linking')
    report['binary'] = dict(path=str(binary), sha256=digest(binary), bytes=binary.stat().st_size)
    save()
    if args.run:
        for case in ['scalar', 'print', 'retained']:
            directory = output / case
            directory.mkdir()
            env = dict(os.environ)
            for key in ['SCRIPTW_PERF_MAP_DIR', 'SCRIPTW_WASM_TRACE', 'SCRIPTW_WASM_TRACE_DUMP',
                        'SCRIPTW_EMIT_SIZE_REPORT', 'SCRIPTW_ROW_PERF_CONTROL', 'SCRIPTW_ROW_PERF_ACK',
                        'SCRIPTW_ROW_PERF_REGION', 'SCRIPTW_BOUNDARY_READY_FD', 'SCRIPTW_BOUNDARY_READY_NONCE']:
                env.pop(key, None)
            env.update(SCRIPTW_CACHE_DIR=str(directory / 'cache'), SCRIPTW_MODULE_MEMORY_CACHE_ENTRIES='1',
                       SCRIPTW_MODULE_MEMORY_CACHE_LIMIT_BYTES=str(64 * 1024**2), RAYON_NUM_THREADS='1')
            expected = PHASES if case != 'scalar' else [p for p in PHASES if not p.startswith('guest_')]
            record = dict(case=case, command=[str(binary), case], started_at=stamp(), state='running',
                          environment={key: env[key] for key in ['SCRIPTW_CACHE_DIR', 'SCRIPTW_MODULE_MEMORY_CACHE_ENTRIES',
                                                                 'SCRIPTW_MODULE_MEMORY_CACHE_LIMIT_BYTES', 'RAYON_NUM_THREADS']},
                          snapshots=[])
            report['cases'].append(record)
            save()
            child = None
            started = time.monotonic()
            pending = b''
            result = None
            try:
                with (directory / 'stdout.log').open('xb') as transcript, (directory / 'stderr.log').open('xb') as stderr:
                    child = subprocess.Popen(record['command'], cwd=ROOT, env=env, stdin=subprocess.PIPE,
                                             stdout=subprocess.PIPE, stderr=stderr, start_new_session=True)
                    while True:
                        require(time.monotonic() - started < 240, 'case exceeded 240-second deadline')
                        ready, _, _ = select.select([child.stdout], [], [], .1)
                        if ready:
                            data = os.read(child.stdout.fileno(), 65536)
                            if not data:
                                break
                            transcript.write(data)
                            transcript.flush()
                            pending += data
                            require(len(pending) <= 128 * 1024, 'child protocol line exceeds bounded budget')
                            while b'\n' in pending:
                                line, pending = pending.split(b'\n', 1)
                                if line.startswith(b'SNAP '):
                                    label = line[5:].decode('ascii')
                                    index = len(record['snapshots'])
                                    require(index < len(expected) and label == expected[index], 'unexpected/reordered phase')
                                    raw = read_smaps(child.pid)
                                    path = directory / (f'{index:02}-' + label + '.smaps')
                                    path.write_text(raw)
                                    snapshot = dict(phase=label, pid=child.pid,
                                                    raw=str(path.relative_to(output)), raw_sha256=digest(path),
                                                    **parse_smaps(raw))
                                    record['snapshots'].append(snapshot)
                                    save()
                                    child.stdin.write(b'A')
                                    child.stdin.flush()
                                elif line.startswith(b'RESULT '):
                                    require(result is None, 'duplicate result')
                                    result = json.loads(line[7:])
                                else:
                                    raise ValueError('unexpected child stdout protocol')
                    exit_code = child.wait(timeout=10)
                record.update(exit_code=exit_code, state='closed', finished_at=stamp(), seconds=time.monotonic() - started,
                              stdout_sha256=digest(directory / 'stdout.log'), stderr_sha256=digest(directory / 'stderr.log'))
                save()
                require(exit_code == 0 and not pending and result is not None, 'case failed or omitted final result')
                require(result['schema'] == 'scriptw-engine-requested-allocation-diagnostic-v1'
                        and result['case'] == case and result['compiler_source'] == source_commit
                        and result['source_fingerprint'] == source_fingerprint
                        and result['helper_executable_sha256'] == report['binary']['sha256']
                        and result['invocations'] == 2, 'actual helper/library source identity differs')
                require([row['phase'] for row in result['snapshots']] == expected
                        and [row['phase'] for row in record['snapshots']] == expected,
                        'missing allocation or smaps phases')
                for row in result['snapshots']:
                    require(row['total_successful_request_bytes'] - row['total_released_request_bytes']
                            == row['requested_live_bytes'], 'counter requests and releases do not reconcile')
                    require(row['peak_tracked_requested_live_bytes'] >= row['requested_live_bytes']
                            and row['interval_peak_tracked_requested_live_bytes'] >= row['requested_live_bytes'],
                            'logical high-water is below current live bytes')
                    cache = row['module_cache']
                    require(cache['entry_limit'] == 1 and cache['image_byte_limit'] == 64 * 1024**2
                            and cache['retained_entries'] <= 1 and cache['retained_image_bytes'] <= 64 * 1024**2,
                            'actual cache policy or retention exceeds bound')
                require(result['linked_runtime'] == (case != 'scalar'), 'scalar/runtime control mismatch')
                record['observation'] = result
                require(digest(binary) == report['binary']['sha256'], 'executed helper changed')
                save()
                print(case + ': allocation counters and acknowledged mappings captured', flush=True)
            finally:
                if child is not None and child.poll() is None:
                    os.killpg(child.pid, signal.SIGKILL)
                    child.wait()
    report.update(complete=True, executed=args.run, finished_at=stamp())
    save()
    print(json.dumps(dict(complete=True, executed=args.run, report=str(output / 'report.json'),
                          helper_sha256=report['binary']['sha256'])))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--compile', action='store_true')
    parser.add_argument('--run', action='store_true')
    parser.add_argument('--output', type=Path, default=BASE / 'candidate-engine-allocation-probe')
    try:
        run(parser.parse_args())
    except (ValueError, KeyError, OSError, TypeError, subprocess.SubprocessError) as error:
        print('engine allocation diagnostic: ' + str(error), file=sys.stderr)
        raise SystemExit(1)
