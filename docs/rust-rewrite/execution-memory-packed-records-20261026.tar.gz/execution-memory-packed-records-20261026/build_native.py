"""Compile only the corrected native target; unchanged scopes retain e36 evidence."""
from campaign_runtime import BASE, actual_source, require_scope, check, checked_receipt
from source_equivalence import admit


def main():
    actual_source(); require_scope(); admit()
    command=['cargo','test','--locked','--offline','--release','--jobs','1','-p','scriptw-aot-wasm','--test','structure_async']
    label='broad-04-scriptw-aot-wasm-structure_async-inventory'
    if (BASE/(label+'.json')).exists():
        checked_receipt(label,command+['--','--list','--include-ignored'])
    else:
        check('fresh-build-structure-async',command+['--no-run'])


if __name__=='__main__': main()
