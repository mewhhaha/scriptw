"""Actual mixed-source native evidence, admitted by one exact test-only bridge."""
import hashlib
from pathlib import Path

from campaign_identity import BASE, digest, read, require, candidate_source
from source_equivalence import SOURCE, REUSED, OWNER, ADDED_TEST, PROOF, PATCH, admit, census, git

COVERAGE = BASE / 'native-coverage.json'


class SourceEvidence:
    """Keep execution source independent from the current product's source."""
    def __init__(self, publisher, base, source):
        self.raw = publisher.Evidence(base)
        self.base, self.source = Path(base), source

    def receipt(self, label):
        row, log = self.raw.receipt(label, checkout_source=self.source)
        require(row.get('product_source_roots') == ['crates', 'vendor', 'Cargo.toml', 'Cargo.lock']
                and row.get('source_head_after') == self.source
                and 'source_changed_after_child' not in row,
                'native execution source/vendor boundary changed')
        return row, log

    def add(self, path):
        return self.raw.add(path)


def name_hash(names):
    return hashlib.sha256(('\n'.join(names) + '\n').encode()).hexdigest()


def ordinary_scope(publisher, evidence, scope, index):
    label = f'broad-{index:02d}-{scope["package"]}-{scope["name"] or "lib"}'
    row, log = evidence.receipt(label)
    enumeration, enumlog = evidence.receipt(label + '-inventory')
    command = ['cargo', 'test', '--locked', '--offline', '--release', '--jobs', '1',
               '-p', scope['package'], scope['kind']]
    if scope['name'] is not None:
        command.append(scope['name'])
    require(row['command'] == command + ['--', '--test-threads=1', '--include-ignored']
            and enumeration['command'] == command + ['--', '--list', '--include-ignored'],
            'native run/enumeration command is filtered or has changed policy')
    zero = scope == dict(package='scriptw-intl-build-data', kind='--lib', name=None)
    names = publisher.inventory_names(enumlog, allow_empty=zero)
    publisher.closed_native_log(row, log, names)
    require(row['executables'] and row['executables'] == enumeration['executables'],
            'recorded execution/enumeration binaries differ')
    return dict(**scope, passed=len(names), inventory_sha256=name_hash(names),
                run_receipt=label + '.json', inventory_receipt=label + '-inventory.json',
                executables=row['executables']), names


def validate_focused(publisher, old, scopes, inventories):
    focused = []
    for label, package, target, pattern in publisher.focused_checks():
        row, log = old.receipt(label)
        expected = ['cargo', 'test', '--locked', '--offline', '--release', '--jobs', '1',
                    '-p', package, *target, pattern, '--', '--test-threads=1', '--include-ignored']
        require(row['command'] == expected, 'original focused command differs from the reviewed selector')
        kind = target[0]; name = None if kind == '--lib' else target[1]
        scope = dict(package=package, kind=kind, name=name)
        require(scope != OWNER and scope in scopes, 'a changed target cannot reuse focused observations')
        names = [name for name, status in publisher.observed_names(log) if status == 'ok']
        inventory = inventories[scopes.index(scope)]
        require(names and set(names).issubset(inventory), 'focused names are missing from unchanged complete inventory')
        publisher.closed_native_log(row, log, names, filtered=len(inventory) - len(names))
        focused.append(dict(receipt=label + '.json', passed=len(names), executed_source=SOURCE,
                            origin_base=str(REUSED), mode='reused-unchanged-target',
                            overlaps_complete_targets=True, added_to_total=False))
    require(len(focused) == 9 and sum(row['passed'] for row in focused) == 27,
            'closed e36 focused cohort differs from nine groups/27 overlapping checks')
    return focused


def validate(evidence, publisher):
    proof = admit(); observed = census(); source = candidate_source()
    scopes = read(BASE / 'native-scopes.json')
    require([(s['package'], s['kind'], s['name']) for s in scopes] == publisher.EXPECTED_SCOPES,
            'mixed-source scope inventory changed')
    old = SourceEvidence(publisher, REUSED, SOURCE)
    fresh = SourceEvidence(publisher, BASE, source)
    targets, inventories, qualified = [], [], []
    old_changed = next(row for row in observed['targets'] if all(row[key] == OWNER[key] for key in OWNER))
    old_enum = read(REUSED / old_changed['inventory_receipt'])
    old_enumlog = REUSED / old_enum['log']
    require(digest(REUSED / old_changed['inventory_receipt']) == old_changed['inventory_receipt_sha256']
            and digest(old_enumlog) == old_enum['log_sha256'], 'old failed-target enumeration changed')
    old_changed_names = publisher.inventory_names(old_enumlog.read_text())
    require(name_hash(old_changed_names) == old_changed['inventory_sha256'], 'old changed-target inventory differs')
    for index, (scope, prior) in enumerate(zip(scopes, observed['targets'])):
        context = fresh if scope == OWNER else old
        if scope['package'] == 'scriptw-engine' and scope['kind'] == '--lib':
            aggregate = read(REUSED / 'engine-accepted.json')
            result = publisher.engine_native(context, scope, aggregate, origin=REUSED, source=SOURCE)
            names = aggregate['inventory']
        else:
            result, names = ordinary_scope(publisher, context, scope, index)
        if scope == OWNER:
            require(set(names) == set(old_changed_names) | {ADDED_TEST}
                    and len(names) == len(old_changed_names) + 1,
                    'fresh complete corrected target must include every old case and the new host-schema control')
            recorded = read(BASE / 'fresh-native.json')
            require(recorded == dict(schema='scriptw-fresh-native-scope-v1', source_commit=source,
                    scope=OWNER, inventory=names, inventory_sha256=name_hash(names),
                    run_receipt=result['run_receipt'], inventory_receipt=result['inventory_receipt']),
                    'fresh native scope manifest differs from actual full-target observations')
        else:
            require(len(names) == prior['inventory_count'] == prior['passed']
                    and name_hash(names) == prior['inventory_sha256'], 'unchanged e36 scope differs from closed census')
        result.update(executed_source=context.source, origin_base=str(context.base),
                      mode='fresh-corrected-target' if scope == OWNER else 'reused-unchanged-target')
        targets.append(result); inventories.append(names)
        qualified.extend(f'{scope["package"]}:{scope["kind"]}:{scope["name"] or "lib"}:{name}' for name in names)
    require(len(qualified) == len(set(qualified)), 'native coverage repeats a qualified test identity')
    # Native build proofs retain their actual source. Only the corrected target
    # is compiled as a final-source harness; unrelated suites are never relabelled.
    for package in sorted({scope['package'] for scope in scopes}):
        label = next((name for name in [f'frozen-build-final-{package}', f'frozen-build-{package}']
                      if (REUSED / (name + '.json')).is_file()), None)
        require(label is not None, 'missing original successful native build owner')
        row, _ = old.receipt(label)
        expected = ['cargo', 'test', '--locked', '--offline', '--release', '--jobs', '1', '-p', package, '--no-run']
        for scope in scopes:
            if scope['package'] == package:
                expected.append(scope['kind'])
                if scope['name']:
                    expected.append(scope['name'])
        require(row['command'] == expected, 'original whole-package native build scope changed')
    # A direct Cargo enumeration also builds its complete harness. Root may
    # already have closed enumeration/run before this aggregation stage.
    if (BASE / 'fresh-build-structure-async.json').is_file():
        row, _ = fresh.receipt('fresh-build-structure-async')
        require(row['command'] == ['cargo', 'test', '--locked', '--offline', '--release', '--jobs', '1',
                '-p', 'scriptw-aot-wasm', '--test', 'structure_async', '--no-run'], 'fresh build contains an unrelated target')
    focused = validate_focused(publisher, old, scopes, inventories)
    # Archive original bytes by original path. Repeated references deduplicate
    # through Evidence.add; mutable Cargo test binaries are never reopened.
    for context in [old, fresh]:
        for path in context.raw.paths.values():
            evidence.add(path)
    evidence.resources.extend(fresh.raw.resources)
    for path in [PROOF, PATCH, BASE / 'fresh-native.json', BASE / 'native-scopes.json',
                 REUSED / 'native-diagnostic-census.json', REUSED / 'engine-accepted.json',
                 REUSED / 'candidate/identity.json']:
        evidence.add(path)
    committed_patch = git('diff', '--binary', '--no-ext-diff', '--no-renames', SOURCE, source)
    require(len(committed_patch) <= 64 * 1024
            and hashlib.sha256(committed_patch).hexdigest() == proof['committed_patch_sha256'],
            'exact committed source-proof patch exceeds its64KiB bound or changed identity')
    evidence.add_bytes('native-source-equivalence-committed.patch', committed_patch)
    fresh_targets = [row for row in targets if row['mode'] == 'fresh-corrected-target']
    reused_targets = [row for row in targets if row['mode'] == 'reused-unchanged-target']
    return dict(complete=True, verification='mixed-source-unchanged-input-coverage', final_product_source=source,
                all_scopes_executed_on_final_source=False, target_count=len(targets), passed=len(qualified),
                failed=0, ignored=0, nonempty_target_count=sum(row['passed'] > 0 for row in targets),
                zero_case_targets=[{key: row[key] for key in OWNER} for row in targets if row['passed'] == 0],
                inventory_sha256=name_hash(sorted(qualified)), targets=targets, focused=focused,
                source_equivalence_sha256=digest(PROOF),
                source_breakdown=[dict(source=SOURCE, mode='reused-unchanged-target', targets=len(reused_targets),
                    passed=sum(row['passed'] for row in reused_targets)),
                    dict(source=source, mode='fresh-corrected-target', targets=len(fresh_targets),
                    passed=sum(row['passed'] for row in fresh_targets))],
                reused_resources=dict(source=SOURCE, observations=old.raw.resources,
                    scope='Original accepted e36 execution resource receipts; validated separately from final-source resources.'),
                interpretation='31 successful e36 native scopes retain their actual execution source and exact raw evidence. '
                    'The complete corrected structure_async target executes on final source. Nine e36 focused groups overlap '
                    'complete inventories and add zero counts. Failed/development audit contributes zero; selected successful '
                    'unchanged-scope evidence is counted once under the exact reviewed test-only equivalence proof.')


def e36_audit(evidence):
    value = census()
    names = ['native-diagnostic-census.json', 'native-scopes.json', 'continue_native_diagnostics.py',
             'campaign.json', 'candidate/identity.json', 'frozen-products.json',
             'release-products.json', 'freeze-candidate.json']
    for row in value['targets']:
        if row['failed']:
            failed = read(REUSED / row['receipt'])
            require(failed['log'] == row['log']
                    and digest(REUSED / row['log']) == failed['log_sha256'] == row['log_sha256'],
                    'failed e36 raw log differs from its original receipt/census identity')
            names += [row['receipt'], row['inventory_receipt'], row['log']]
            names.append(read(REUSED / row['inventory_receipt'])['log'])
    rows = []
    for name in sorted(set(names)):
        path = REUSED / name
        require(path.is_file() and not path.is_symlink() and path.stat().st_size <= 1024**2,
                'e36 audit input escaped bounded explicit capture')
        evidence.add(path)
        rows.append(dict(origin_path=str(path), sha256=digest(path), bytes=path.stat().st_size))
    old_history = read(BASE / 'prior-attempts/manifest.json')
    require(len(rows) + len(old_history['files']) <= 64
            and sum(row['bytes'] for row in rows) + old_history['total_bytes'] <= 4 * 1024**2,
            'combined historical audit exceeds64files/4MiB')
    return dict(source_commit=SOURCE, census_complete=True, historical_passed=value['passed'],
                historical_failed=value['failed'], failed_scopes=[row for row in value['targets'] if row['failed']],
                included_in_accepted_totals=False, accepted_count_contribution=0, files=rows,
                interpretation='The original failed census remains an audit record. Independently admitted successful '
                    'unchanged-scope evidence may support mixed-source coverage; no failed execution is accepted or relabelled.')
