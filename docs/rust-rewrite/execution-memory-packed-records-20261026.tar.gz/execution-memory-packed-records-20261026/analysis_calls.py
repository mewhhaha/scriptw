#!/usr/bin/env python3
"""Strict read-only reconciliation of the separate live-Realm call ABBA cohort."""
from __future__ import annotations
from campaign_identity import product_directory

import argparse
from datetime import datetime, timedelta
import hashlib
import json
from pathlib import Path
import statistics

from analyze import (
    BASE, REPO, BASELINE_SOURCE, candidate_source, product_source, validate_environment, frozen_product,
    digest, read, require, resources, percentage, uint, memory_summary,
)
from measure_calls import transformed_cases, HARNESS, FIXTURES
from benchmark_boundaries import validate_cache_identity, validate_child, validate_calls
from boundary_process import validate_ready

ROUNDS = (
    "baseline-calls-round-a-data", "candidate-calls-round-b-data",
    "candidate-calls-round-c-data", "baseline-calls-round-d-data",
)


def owned(directory, name):
    require(isinstance(name, str) and Path(name).name == name and not Path(name).is_absolute(),
            "raw evidence path escapes round directory")
    path = directory / name
    require(path.is_file() and not path.is_symlink(), "raw evidence missing or symlinked: " + str(path))
    return path


def bundle_framing(path, identity, artifact):
    """Check inert Portable framing/P identity; native child owns R admission."""
    raw = path.read_bytes()
    require(len(raw) <= 256 * 1024**2 and len(raw) >= 121 and raw[:8] == b"SCRWPB01" and raw[8] == 0,
            "unexpected Portable bundle framing/profile")
    require(raw[9:41].hex() == identity["source_fingerprint"], "bundle source fingerprint differs")
    plen, rlen = int.from_bytes(raw[41:49], "little"), int.from_bytes(raw[49:57], "little")
    require(89 + plen + rlen + 32 == len(raw) and hashlib.sha256(raw[:-32]).digest() == raw[-32:],
            "bundle length/checksum differs")
    program, package = raw[89:89 + plen], raw[89 + plen:-32]
    require(program[:8] == b"\0asm\x01\0\0\0" and plen == artifact["program_bytes"] and
            hashlib.sha256(program).hexdigest() == artifact["program_sha256"], "bundle actual P identity differs")
    runtime = artifact["linked_runtime"]
    require(runtime is not None and raw[57:89].hex() == runtime["key"] and
            package[:8] == b"SCRWRB01" and runtime["bytes"] <= len(package), "bundle R key/package differs")
    return {"program_bytes": plen, "program_sha256": artifact["program_sha256"],
            "runtime_package_bytes": rlen, "runtime_package_sha256": hashlib.sha256(package).hexdigest(),
            "runtime_wasm_bytes": runtime["bytes"], "runtime_wasm_sha256": runtime["sha256"],
            "runtime_key": runtime["key"], "bundle_bytes": len(raw), "bundle_sha256": hashlib.sha256(raw).hexdigest()}


def one_round(label):
    directory = BASE / label
    report_path = directory / "report.json"
    report = read(report_path)
    product = label.split("-")[0]
    require(report.get("schema") == "scriptw-execution-same-realm-round-v1" and
            report.get("complete") is True and report.get("label") == label and report.get("product") == product,
            label + ": partial/mislabelled same-Realm report")
    require(report.get("samples") == 7 and report.get("guest_warmups") == 10 and report.get("affinity") == [0],
            label + ": call/warmup/CPU denominator differs")
    validate_environment(report["environment"])
    require(report["campaign_source"] == candidate_source()
            and report["driver_sha256"] == digest(BASE / "measure_calls.py"),
            label + ": campaign/measurement source differs")
    require(report["manifest_sha256"] == digest(FIXTURES / "manifest.json"), "ordinary manifest changed")
    for name in HARNESS:
        snapshot = directory / "harness" / name
        require(digest(snapshot) == report["harness_sha256"][name] == digest(REPO / name),
                label + ": boundary harness changed: " + name)
    identity = report["compiler_identity"]
    expected_source = product_source(product)
    require(identity.get("source_revision") == {"kind": "git-commit", "commit": expected_source},
            label + ": actual executed source is not the admitted " + product + " revision")
    require(read(product_directory(product) / "identity.json") == identity, label + ": product identity differs")
    admitted_identity, admitted_hashes = frozen_product(product)
    require(admitted_identity == identity and report["frozen_product_sha256"] == admitted_hashes,
            label + ": frozen product hash inventory differs")
    runner = product_directory(product) / "runtime_boundaries"
    require(digest(runner) == report["runtime_boundaries_sha256"] == report["binaries"]["wasmtime"]["sha256"],
            label + ": actual frozen runtime_boundaries bytes differ")
    for binary in report["binaries"].values():
        require(digest(binary["path"]) == binary["sha256"], label + ": runtime/accounting executable changed")
    receipt_label = label.removesuffix("-data")
    receipt_path = BASE / (receipt_label + ".json")
    receipt = read(receipt_path)
    require(receipt["label"] == receipt_label, label + ": outer receipt differs")
    resources(receipt, label)
    require(receipt.get("source_head") == candidate_source() and receipt.get("source_patch_sha256") == hashlib.sha256(b"").hexdigest(),
            label + ": final campaign launcher must be the actual clean final checkout; baseline compiler identity remains separately admitted")
    commands = report["commands"]
    require(len(commands) == len({c["label"] for c in commands}) == 68, label + ": exact68 prepare/call commands required")
    by_label = {command["label"]: command for command in commands}
    observed_commands = []

    def command_result(expected_label, runtime, expected_command, expected_ready=None):
        observed_commands.append(expected_label)
        command = by_label[expected_label]
        require(command["state"] == "finished" and command["runtime"] == runtime and
                command["command"] == list(map(str, expected_command)) and command["cwd"] == str(REPO),
                expected_label + ": actual command differs")
        require(command["stdout_file"] == expected_label + ".stdout" and command["stderr_file"] == expected_label + ".stderr",
                expected_label + ": raw stream names differ")
        stdout, stderr = owned(directory, command["stdout_file"]), owned(directory, command["stderr_file"])
        require(digest(stdout) == command["stdout_sha256"] and digest(stderr) == command["stderr_sha256"],
                expected_label + ": raw stream hashes differ")
        accounting = command["accounting"]
        require(accounting["exit_code"] == 0 and accounting["timed_out"] is False and
                uint(accounting["elapsed_ns"]) and uint(accounting["peak_rss_bytes"]),
                expected_label + ": child failed or memory accounting missing")
        child = read(stdout)
        if expected_ready is not None:
            validate_ready(accounting, child, expected_ready)
        return child, command

    plan = transformed_cases()
    require([case["file"] for case in report["cases"]] == [case["file"] for case in plan],
            label + ": transformed17-case inventory differs")
    rows, versions, policies = {}, set(), set()
    node = Path(report["binaries"]["v8"]["path"])
    helper = directory / "harness/scripts/boundary_node.cjs"
    for row, fixture in zip(report["cases"], plan):
        name = fixture["file"]
        for field in ["file", "work", "original_source_sha256", "source_sha256", "expected_numeric_text",
                      "expected_stdout", "expected_stdout_sha256"]:
            require(row[field] == fixture[field], label + "/" + name + ": transformed source/oracle identity differs")
        source = owned(directory, row["source_file"])
        expected = owned(directory, row["expected_file"])
        bundle = owned(directory, row["bundle_file"])
        cache = owned(directory, row["cached_data_file"])
        require(source.name == name + "-calls.js" and expected.name == name + "-calls.expected" and
                bundle.name == name + ".swbundle" and cache.name == name + ".v8cache", "call artifact names differ")
        require(source.read_text() == fixture["source"] and digest(source) == fixture["source_sha256"] and
                expected.read_text() == fixture["expected_stdout"] and digest(expected) == fixture["expected_stdout_sha256"],
                label + "/" + name + ": actual transformed source/output bytes differ")
        require(digest(bundle) == row["bundle_sha256"] and bundle.stat().st_size == row["bundle_bytes"] and
                digest(cache) == row["cached_data_sha256"] and cache.stat().st_size == row["cached_data_bytes"],
                label + "/" + name + ": raw bundle/cachedData hashes differ")
        expected_order = ["v8", "wasmtime"] if label in [ROUNDS[1], ROUNDS[3]] else ["wasmtime", "v8"]
        require(row["runtime_order"] == expected_order and
                set(row["runtimes"]) == {"wasmtime", "v8"}, "runtime order/inventory differs")
        prepared = {}
        for runtime in row["runtime_order"]:
            command = [runner, "prepare", source, bundle] if runtime == "wasmtime" else [node, helper, "prepare", source, cache, expected]
            command_label = name + "-prepare-" + runtime
            require(row["runtimes"][runtime]["prepare_command"] == command_label, "prepare reference differs")
            child, _ = command_result(command_label, runtime, command)
            if runtime == "wasmtime":
                require(child["schema"] == "scriptw-portable-boundaries-child-v1" and child["mode"] == "prepare" and
                        child["source_sha256"] == row["source_sha256"] and child["source_bytes"] == source.stat().st_size and
                        child["bundle_sha256"] == row["bundle_sha256"] and child["bundle_bytes"] == row["bundle_bytes"] and
                        child["executable_sha256"] == report["runtime_boundaries_sha256"] and
                        child["source_fingerprint"] == identity["source_fingerprint"] and
                        child["source_commit"] == identity["source_revision"]["commit"], "actual prepared Scriptw source differs")
                require(child["requested_compiler_cache_image_hash"] == "sha256", "cache algorithm cohort differs")
                validate_cache_identity(child["compiler_cache_identity"], "sha256", child["executable_sha256"])
                framing = bundle_framing(bundle, identity, child["artifact"])
            else:
                require(child["schema"] == "scriptw-v8-boundaries-child-v1" and child["mode"] == "prepare" and
                        child["source_sha256"] == row["source_sha256"] and child["source_bytes"] == source.stat().st_size and
                        child["stdout"] == row["expected_stdout"] and child["cached_data_sha256"] == row["cached_data_sha256"] and
                        child["cached_data_bytes"] == row["cached_data_bytes"] and child["exec_argv"] == [],
                        "actual prepared V8 source/output/cache differs")
                versions.add((child["node"], child["v8"]))
            prepared[runtime] = child
        entry = {"file": name, "original_source_sha256": fixture["original_source_sha256"],
                 "source_sha256": fixture["source_sha256"], "expected_numeric_text": fixture["expected_numeric_text"],
                 "expected_stdout_sha256": fixture["expected_stdout_sha256"], "framing": framing}
        for runtime in row["runtime_order"]:
            command = [runner, "calls", bundle, expected, "7"] if runtime == "wasmtime" else [node, helper, "calls", source, cache, expected, "7"]
            command_label = name + "-calls-" + runtime
            require(row["runtimes"][runtime]["calls_command"] == command_label, "calls reference differs")
            child, command_receipt = command_result(command_label, runtime, command, fixture["expected_stdout_sha256"])
            validate_child(child, runtime="scriptw" if runtime == "wasmtime" else "node", mode="calls",
                           expected=fixture["expected_stdout"], source_sha=fixture["source_sha256"],
                           prepared=prepared[runtime], samples=7)
            validate_calls(child["calls"], 7)
            samples = child["calls"]["samples_ns"]
            details = {
                "samples_ns": samples, "median_ns": statistics.median(samples),
                "callbacks": child["calls"]["callbacks"], "call_boundary": child["calls"]["boundary"],
                "command_label": command_label, "accounting": command_receipt["accounting"],
                "artifact": prepared[runtime].get("artifact"),
            }
            if runtime == "wasmtime":
                execution = child["execution"]
                policy = execution["actual_native_policy"]
                require(policy == {"native_mode": "fast", "gc_initial_mib": 16, "register_allocation": "single-pass"},
                        "actual native/GC default cohort differs")
                policies.add((execution["runtime_policy"], json.dumps(policy, sort_keys=True)))
                require(child["module_cache_accounting"]["entry_limit"] == 1 and
                        child["module_cache_accounting"]["image_byte_limit"] == 64 * 1024**2,
                        "actual module retention limits differ")
                details["actual_native_policy"] = policy
                details["whole_invocation_memory"] = {
                    "gc_capacity_before_bytes": execution["gc_capacity_before_bytes"],
                    "gc_capacity_after_bytes": execution["gc_capacity_after_bytes"],
                    "child_lifetime_peak_rss_bytes": command_receipt["accounting"]["peak_rss_bytes"],
                    "scope": "GC capacity before/after the complete program including warmups; RSS is whole child including admission/native compilation. Neither is a per-call live/allocation counter.",
                }
            else:
                details["whole_invocation_memory"] = {
                    "child_lifetime_peak_rss_bytes": command_receipt["accounting"]["peak_rss_bytes"],
                    "scope": "Whole Node child lifetime; no isolated-call live heap/peak/allocation counter.",
                }
            entry[runtime] = details
        rows[name] = entry
    require(observed_commands == [command["label"] for command in commands], "actual prepare/calls command ordering differs")
    require(len(versions) == 1 and len(policies) == 1, "runtime version/native policy changed within round")
    end = datetime.fromisoformat(receipt["date"])
    return {
        "product": product, "compiler_identity": identity,
        "runtime_boundaries_sha256": report["runtime_boundaries_sha256"],
        "node_sha256": report["binaries"]["v8"]["sha256"],
        "ordinary_environment": report["environment"],
        "node_v8": list(next(iter(versions))), "actual_runtime_policy": list(next(iter(policies))),
        "report_sha256": digest(report_path), "receipt_sha256": digest(receipt_path),
        "start": (end - timedelta(seconds=receipt["seconds"])).isoformat(), "end": end.isoformat(),
        "boundary": report["boundary"], "source_transform": report["source_transform"],
        "ambient_load": report["ambient_load"], "loadavg_start": report["loadavg_start"], "loadavg_end": report["loadavg_end"],
    }, rows


def build_report():
    rounds, data = {}, {}
    for label in ROUNDS:
        rounds[label], data[label] = one_round(label)
    a, b, c, d = ROUNDS
    for first, second in [(a, d), (b, c)]:
        for key in ["compiler_identity", "runtime_boundaries_sha256"]:
            require(rounds[first][key] == rounds[second][key], "same-product identity changed across call sessions")
    for first, second in zip(ROUNDS, ROUNDS[1:]):
        require(datetime.fromisoformat(rounds[first]["end"]) <= datetime.fromisoformat(rounds[second]["start"]),
                "call rounds overlap or ABBA order changed")
    require(len({tuple(row["node_v8"]) for row in rounds.values()}) == 1 and
            len({row["node_sha256"] for row in rounds.values()}) == 1 and
            len({tuple(row["actual_runtime_policy"]) for row in rounds.values()}) == 1 and
            len({row["boundary"] for row in rounds.values()}) == 1, "call cohort policy/version/boundary differs")
    cases = []
    for fixture in transformed_cases():
        name = fixture["file"]
        observations = {label: data[label][name] for label in ROUNDS}
        for first, second in [(a, d), (b, c)]:
            require(observations[first]["framing"] == observations[second]["framing"],
                    "same-product Portable P/R bytes changed across sessions")
        pooled = {}
        for product, labels in [("baseline", [a, d]), ("candidate", [b, c])]:
            pooled[product] = {}
            for runtime in ["wasmtime", "v8"]:
                values = [value for label in labels for value in observations[label][runtime]["samples_ns"]]
                pooled[product][runtime] = {
                    "samples_ns": values, "median_ns": statistics.median(values),
                    "session_median_ns": [observations[label][runtime]["median_ns"] for label in labels],
                    "session_memory_observations": memory_summary([
                        observations[label][runtime]["whole_invocation_memory"] for label in labels]),
                }
        pairs = []
        for control, candidate in [(a, b), (d, c)]:
            before, after = observations[control]["wasmtime"]["median_ns"], observations[candidate]["wasmtime"]["median_ns"]
            pairs.append({"baseline_round": control, "candidate_round": candidate,
                          "baseline_median_ns": before, "candidate_median_ns": after,
                          "change_percent": percentage(before, after)})
        cases.append({
            "file": name, "original_source_sha256": fixture["original_source_sha256"],
            "source_sha256": fixture["source_sha256"], "expected_numeric_text": fixture["expected_numeric_text"],
            "expected_stdout_sha256": fixture["expected_stdout_sha256"], "work": fixture["work"],
            "rounds": observations, "pooled": pooled, "adjacent_pairs": pairs,
            "median_change_percent": percentage(pooled["baseline"]["wasmtime"]["median_ns"], pooled["candidate"]["wasmtime"]["median_ns"]),
            "both_adjacent_pairs_improve": all(pair["change_percent"] < 0 for pair in pairs),
            "both_adjacent_pairs_regress": all(pair["change_percent"] > 0 for pair in pairs),
            "scriptw_over_v8": {product: pooled[product]["wasmtime"]["median_ns"] / pooled[product]["v8"]["median_ns"] for product in pooled},
        })
    return {
        "schema": "scriptw-execution-same-realm-comparison-v1", "complete": True,
        "round_order": list(ROUNDS), "rounds": rounds, "case_count": 17,
        "samples_per_session": 7, "guest_warmups": 10, "sessions_per_product": 2,
        "pooled_samples_per_product": 14, "cases": cases,
        "notes": [
            "Separate transformed-source cohort; not interchangeable with ordinary fresh-Realm timings.",
            "Seven callbacks per session after ten guest warmups in one initialized Realm; two fresh sessions per product in ABBA order.",
            "Pooled14-sample medians are descriptive; both session medians, all raw callback timestamps and adjacent changes remain visible.",
            "Spans include one batch call, workload construction/checksum and marker return/entry overhead; setup, warmups, checksum printing and native compilation are outside. No empty subtraction.",
            "Call intervals are elapsed wall time, not isolated CPU time. Whole-child RSS and whole-program GC capacity do not establish per-call peak/live/allocation counts.",
            "Shared host with observed unrelated CPU/desktop activity and retained load averages; not idle-machine repeatability, statistical/causal or V8 parity certification.",
        ],
    }


def evidence_files():
    paths = {Path(__file__).resolve(), BASE / "measure_calls.py", BASE / "campaign_identity.py", BASE / "campaign.json"}
    for label in ROUNDS:
        directory = BASE / label
        report = read(directory / "report.json")
        paths.add(directory / "report.json")
        receipt_label = label.removesuffix("-data")
        receipt = read(BASE / (receipt_label + ".json"))
        paths.update([BASE / (receipt_label + ".json"), BASE / receipt["log"]])
        paths.update(directory / "harness" / name for name in HARNESS)
        for case in report["cases"]:
            paths.update([owned(directory, case["source_file"]), owned(directory, case["expected_file"])])
        for command in report["commands"]:
            paths.update([owned(directory, command["stdout_file"]), owned(directory, command["stderr_file"])])
    require(all(path.is_file() for path in paths), "call evidence inventory incomplete")
    require(not any(path.suffix in [".swbundle", ".v8cache"] for path in paths), "binary cache/bundle excluded from archive")
    return sorted(paths)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=BASE / "analysis_calls.json")
    parser.add_argument("--check-round", choices=ROUNDS)
    parser.add_argument("--check", action="store_true", help="rederive and compare an existing aggregate without writing")
    args = parser.parse_args()
    if args.check_round:
        metadata, rows = one_round(args.check_round)
        print(json.dumps({"validated": args.check_round, "case_count": len(rows), "metadata": metadata}, indent=2))
        return
    report = build_report()
    if args.check:
        require(read(args.output) == report, "saved call aggregate differs from raw rederivation")
    else:
        require(not args.output.exists(), "refusing to overwrite existing call analysis; use --check")
        args.output.write_text(json.dumps(report, indent=2) + "\n")
    for row in report["cases"]:
        before, after = row["pooled"]["baseline"]["wasmtime"]["median_ns"] / 1e6, row["pooled"]["candidate"]["wasmtime"]["median_ns"] / 1e6
        print(f'{row["file"]}: {before:.3f}->{after:.3f}ms ({row["median_change_percent"]:+.1f}%); '
              f'AB {row["adjacent_pairs"][0]["change_percent"]:+.1f}%, DC {row["adjacent_pairs"][1]["change_percent"]:+.1f}%')
    print(f"Wrote separate verified call comparison: {args.output}")


if __name__ == "__main__":
    try:
        main()
    except (KeyError, ValueError, OSError, TypeError) as error:
        raise SystemExit(f"Call comparison refused: {error}")
