#!/usr/bin/env python3
"""Run the eight serial ABBA rounds only after the real candidate is frozen.

--plan-only is pure and does not require an invented candidate identity.
Existing complete or partial receipts are never overwritten or removed.
"""
import argparse
import json
import shutil
import subprocess
import sys

from campaign_identity import BASE, candidate_source, frozen_product, require

REPO = BASE.parent.parent
FRESH = [('baseline', 'baseline-round-a', False), ('candidate', 'candidate-round-b', True),
         ('candidate', 'candidate-round-c', False), ('baseline', 'baseline-round-d', True)]
CALLS = [('baseline', 'baseline-calls-round-a', False), ('candidate', 'candidate-calls-round-b', True),
         ('candidate', 'candidate-calls-round-c', False), ('baseline', 'baseline-calls-round-d', True)]


def plan():
    result = []
    for script, rounds in [('measure.py', FRESH), ('measure_calls.py', CALLS)]:
        for product, label, reverse in rounds:
            command = [sys.executable, '-B', str(BASE / script), product, label + '-data']
            if script == 'measure.py':
                command += ['--samples', '7', '--warmups', '10']
            if reverse:
                command.append('--reverse')
            result.append(dict(product=product, label=label, command=command,
                               outer_command=[sys.executable, '-B', str(BASE / 'run_check.py'), label, *command]))
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan-only', action='store_true')
    args = parser.parse_args()
    work = plan()
    if args.plan_only:
        print(json.dumps(dict(rounds=work, accepted_cases=17, samples=7, warmups=10,
                              candidate_authority='Pending actual candidate/identity.json + campaign.json',
                              observations='Existing failed foundation receipts remain untouched and excluded from accepted round totals.'), indent=2))
        return
    # The raw bundle cohort needs about 3 GiB. This campaign never invokes
    # cache deletion; leave existing files in place and check available space.
    require(shutil.disk_usage(REPO).free >= 5 * 1024**3,
            'need at least 5 GiB free before starting the ordinary benchmark cohorts')
    source = candidate_source()
    for product in ['baseline', 'candidate']:
        frozen_product(product)
    require(subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip() == source,
            'measurement launcher is not the actual final candidate checkout')
    require(not subprocess.check_output(['git', 'diff', '--binary', 'HEAD', '--', 'crates', 'vendor', 'Cargo.toml', 'Cargo.lock'], cwd=REPO),
            'measurement product source must be clean')
    for item in work:
        for path in [BASE / (item['label'] + '.json'), BASE / (item['label'] + '.log'),
                     BASE / (item['label'] + '-data')]:
            require(not path.exists(), 'refusing to overwrite a closed or partial observation: ' + str(path))
    for item in work:
        code = subprocess.call(item['outer_command'], cwd=REPO)
        if code:
            raise SystemExit(code)
    for script in ['analyze.py', 'analysis_calls.py']:
        code = subprocess.call([sys.executable, '-B', str(BASE / script)], cwd=REPO)
        if code:
            raise SystemExit(code)


if __name__ == '__main__':
    try:
        main()
    except (KeyError, ValueError, OSError, TypeError, subprocess.SubprocessError) as error:
        raise SystemExit('ABBA campaign refused: ' + str(error))
