"""Validate nine original e36 focused overlaps; execute no native tests."""
import argparse,json
from campaign_runtime import BASE, read, actual_source, require_scope, require


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--plan-only',action='store_true');args=parser.parse_args()
    if args.plan_only: print(json.dumps(read(BASE/'focused-plan.json'),indent=2));return
    actual_source();require_scope()
    import publish_evidence as publisher
    report=publisher.native(publisher.Evidence())
    require(len(report['focused'])==9 and sum(row['passed'] for row in report['focused'])==27,'original focused evidence differs')
    print('REUSED e36 FOCUSED OVERLAPS 27; ADDED TO NATIVE TOTAL 0',flush=True)


if __name__=='__main__':main()
