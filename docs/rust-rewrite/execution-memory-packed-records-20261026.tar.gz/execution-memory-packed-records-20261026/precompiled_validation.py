"""Pure, closed validation of the independent precompiled execution diagnostic."""
import hashlib
import re
import statistics

from campaign_identity import require

SAMPLES, WARMUPS = 7, 10
SNAPSHOTS = ['startup', 'after_engine', 'after_image_read', 'after_admission', 'after_transport_drop']
PROCESS_PHASES = ['before_store', 'after_instantiate', 'after_execution', 'after_store_drop']
TIME_PHASES = ['state_linker', 'register', 'instantiate', 'execution', 'total']
MEMORY_FIELDS = ['rss_bytes', 'pss_bytes', 'private_dirty_bytes']


def uint(value):
    return type(value) is int and 0 <= value < 2**64


def memory(value):
    require(isinstance(value, dict)
            and value.get('scope') == 'linux-process-smaps-rollup-endpoint-not-peak-or-live-js'
            and all(uint(value.get(key)) for key in MEMORY_FIELDS),
            'missing/invalid actual process memory endpoint')
    require(value['pss_bytes'] <= value['rss_bytes']
            and value['private_dirty_bytes'] <= value['rss_bytes'],
            'memory endpoint relationships are impossible')


def identity(value, expected, executable_sha256):
    require(value.get('source_commit') == expected['source_revision']['commit']
            and value.get('source_fingerprint') == expected['source_fingerprint']
            and value.get('compiler_identity_scheme') == expected['source_fingerprint_scheme']
            and value.get('executable_sha256') == executable_sha256,
            'diagnostic compiler/source/executable identity differs')


def image_framing(raw, source_fingerprint):
    """Checksummed framing is provenance, never permission to deserialize native code."""
    require(122 <= len(raw) <= 256 * 1024**2 and raw[:8] == b'SCRWEP01'
            and raw[8:40].hex() == source_fingerprint
            and hashlib.sha256(raw[:-32]).digest() == raw[-32:],
            'native image framing/source/checksum differs')
    linked, key, mode = raw[40], raw[41:73], raw[73]
    require(linked in [0, 1] and (linked == 1 or key == bytes(32)) and mode == 0,
            'native image runtime key/default native policy differs')
    plen, nlen = int.from_bytes(raw[74:82], 'little'), int.from_bytes(raw[82:90], 'little')
    require(plen > 0 and nlen > 0 and 122 + plen + nlen == len(raw)
            and raw[90:98] == b'\0asm\x01\0\0\0', 'native image P/native lengths differ')
    return dict(program_bytes=plen, program_sha256=hashlib.sha256(raw[90:90+plen]).hexdigest(),
                native_serialized_bytes=nlen, runtime_key=key.hex() if linked else None)


def execution(value, expected_identity, executable_sha256, image, case):
    require(value.get('schema') == 'scriptw-precompiled-execution-v1'
            and value.get('compiler_enabled') is False
            and value.get('excluded_from_scored_cohorts') is True
            and value.get('samples') == SAMPLES and value.get('warmups') == WARMUPS,
            'consumer schema/compiler-enabled/sample policy differs')
    identity(value, expected_identity, executable_sha256)
    require(value.get('image_sha256') == image['sha256']
            and value.get('image_bytes') == image['bytes']
            and value.get('runtime_key') == image['runtime_key']
            and value.get('program_wasm_sha256') == image['program_sha256'], 'consumer native image/R identity differs')
    load = value.get('load_phases_ns')
    require(isinstance(load, dict) and set(load) == {'engine', 'image_read_and_envelope_admission',
            'native_admission_and_deserialization', 'process_total'}
            and all(uint(item) for item in load.values())
            and load['process_total'] >= sum(load[key] for key in load if key != 'process_total'),
            'consumer load elapsed timings are missing or invalid')
    native_load = value.get('native_load_process_memory')
    require(isinstance(native_load, dict) and native_load.get('status') == 'sampled'
            and native_load.get('interval_ns') == 10_000_000
            and native_load.get('scope') == 'native-P-and-Cargo-R-admission-process-RSS-sampled-maximum-not-peak-or-live-js'
            and all(uint(native_load.get(key)) for key in ['initial_rss_bytes', 'final_rss_bytes',
                'maximum_rss_bytes', 'sample_count', 'elapsed_ns'])
            and native_load['sample_count'] >= 2 and native_load['elapsed_ns'] > 0
            and 0 < max(native_load['initial_rss_bytes'], native_load['final_rss_bytes'])
                <= native_load['maximum_rss_bytes'],
            'native-load sampled RSS scope/order/denominator differs')
    endpoints = value.get('process_snapshots')
    require(isinstance(endpoints, dict) and set(endpoints) == set(SNAPSHOTS),
            'consumer startup/admission endpoints are missing')
    for item in endpoints.values():
        memory(item)
    observations = value.get('observations')
    require(isinstance(observations, list) and len(observations) == WARMUPS + SAMPLES,
            'complete warmup/measured observations are required')
    for index, row in enumerate(observations):
        require(type(row.get('index')) is int and row.get('index') == index
                and row.get('warmup') is (index < WARMUPS)
                and row.get('stdout') == case['stdout'] and row.get('completion') == 'normal',
                'consumer order/warmup/output/completion differs')
        phases = row.get('phases_ns')
        require(isinstance(phases, dict) and set(phases) == set(TIME_PHASES)
                and all(uint(phases[key]) for key in TIME_PHASES)
                and phases['total'] >= sum(phases[key] for key in TIME_PHASES if key != 'total'),
                'consumer elapsed phases are invalid/incomplete')
        require(uint(row.get('gc_capacity_before_bytes')) and uint(row.get('gc_capacity_after_bytes')),
                'consumer GC capacity endpoints missing')
        process = row.get('process_snapshots')
        require(isinstance(process, dict) and set(process) == set(PROCESS_PHASES),
                'consumer Store lifecycle process endpoints missing')
        for point in process.values():
            memory(point)
    measured = observations[WARMUPS:]
    return dict(file=case['file'], observations=len(observations), measured_samples=SAMPLES,
                startup=endpoints, load_phases_ns=load, native_load_process_memory=native_load,
                first_warmup=observations[0],
                measured_medians={
                    'phases_ns': {key: statistics.median(row['phases_ns'][key] for row in measured)
                                  for key in TIME_PHASES},
                    'process_snapshots': {
                        phase: {field: statistics.median(row['process_snapshots'][phase][field] for row in measured)
                                for field in MEMORY_FIELDS}
                        for phase in PROCESS_PHASES}},
                scope='Process endpoints include resident host/native code and setup history; not peaks or live JS bytes.')
