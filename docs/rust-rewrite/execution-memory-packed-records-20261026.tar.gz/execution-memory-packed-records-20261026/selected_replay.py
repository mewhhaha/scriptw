"""Run the exact freshly inventoried selected executions without changing deadlines."""
import sys
from campaign_runtime import BASE, check

check('conformance-final', [
    sys.executable, '-B', 'scripts/replay-test262-executions.py', str(BASE / 'selected.ids'),
    '--binary', str(BASE / 'candidate/scriptw'), '--suite-root', 'test262/vendor/test262',
    '--output-dir', str(BASE / 'conformance'), '--workers', '1', '--reuse-case-workers',
], expected=1)
