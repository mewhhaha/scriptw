"""Separate source-free/compiler-disabled diagnostic, never an ordinary score.

Default is plan-only. --run needs the real frozen candidate and resource scope.
Prepare all17images once, then execute each in one separate process with10warmups
and7measured observations. Native images stay excluded from the evidence archive;
actual framing/hashes, producer/consumer streams and regeneration commands remain.
"""
import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import subprocess
import time

from campaign_identity import (BASE, REPO, checked_identity, candidate_source, digest,
                               read, require, ordinary_environment, environment_receipt)
from campaign_runtime import actual_source, require_scope, progress
from precompiled_validation import SAMPLES, WARMUPS, execution, image_framing

FIXTURES = REPO / 'crates/scriptw-cli/tests/fixtures/v8_execution_hotpaths'
OUTPUT = BASE / 'precompiled-execution-data'


def stamp():
    return datetime.now(timezone.utc).isoformat()


def run():
    actual_source(); require_scope()
    compiler = checked_identity('candidate')
    binary = read(BASE / 'precompiled-product/identity.json')
    require(binary['source_commit'] == candidate_source()
            and digest(binary['path']) == binary['sha256'], 'diagnostic frozen product changed')
    manifest = read(FIXTURES / 'manifest.json')
    require(manifest['schema'] == 'scriptw-v8-workloads-v1'
            and len(manifest['execution']) == 17, 'need the exact independent17case manifest')
    OUTPUT.mkdir(exist_ok=False)
    environment = ordinary_environment()
    report = dict(schema='scriptw-precompiled-execution-diagnostic-v1', complete=False,
                  campaign_source=candidate_source(), compiler_identity=compiler,
                  executable=binary, manifest_sha256=digest(FIXTURES / 'manifest.json'),
                  driver_sha256=digest(__file__), validator_sha256=digest(BASE / 'precompiled_validation.py'),
                  samples=SAMPLES, warmups=WARMUPS, started_at=stamp(),
                  environment=environment_receipt(environment), commands=[], cases=[],
                  excluded_from_scored_cohorts=True, scored_case_count_contribution=0,
                  baseline_available=False,
                  scope='One candidate-only source-free native-image consumer per case with its compiler disabled. '
                        'Setup/admission, first warmup and measured execution remain separate; no before/after '
                        'baseline or live JS heap/peak memory inference. Images/ELF/cache contents are excluded '
                        'from archive; exact hashes/framing/commands and original raw streams remain.')

    def save():
        progress(OUTPUT / 'report.json', report)

    def invoke(label, arguments, timeout):
        event = dict(label=label, command=[binary['path'], *arguments], cwd=str(REPO),
                     state='running', started_at=stamp(), stdout_file=label + '.stdout',
                     stderr_file=label + '.stderr')
        report['commands'].append(event); save()
        require(digest(binary['path']) == binary['sha256'], 'consumer/producer ELF changed before invocation')
        start = time.monotonic()
        stdout, stderr = OUTPUT / event['stdout_file'], OUTPUT / event['stderr_file']
        try:
            with stdout.open('xb') as out, stderr.open('xb') as err:
                result = subprocess.run(event['command'], cwd=REPO, env=environment,
                                        stdout=out, stderr=err, timeout=timeout)
            event.update(state='finished', exit_code=result.returncode, timed_out=False)
        except subprocess.TimeoutExpired:
            event.update(state='finished', exit_code=None, timed_out=True)
            raise
        finally:
            event.update(seconds=time.monotonic() - start, finished_at=stamp(),
                         stdout_sha256=digest(stdout), stderr_sha256=digest(stderr))
            save()
        require(event['exit_code'] == 0, 'diagnostic child failed; preserve its actual streams')
        require(stderr.read_bytes() == b'', 'diagnostic child emitted stderr; investigate before publication')
        return json.loads(stdout.read_text())

    try:
        images = OUTPUT / 'images'
        produced = invoke('prepare', ['prepare', str(FIXTURES), str(images)], 3600)
        require(produced['schema'] == 'scriptw-precompiled-producer-v1', 'unexpected native-image producer schema')
        # The producer schema and every per-case provenance record are independently
        # reconciled again by analyze_precompiled before publication.
        from analyze_precompiled import validate_producer
        actual = validate_producer(produced, compiler, binary['sha256'], manifest, images)
        for ordinal, (case, image) in enumerate(zip(manifest['execution'], actual)):
            label = f'execute-{ordinal:02d}-' + Path(case['file']).stem
            value = invoke(label, ['execute', str(images / image['file']), case['stdout'],
                                  str(SAMPLES), str(WARMUPS)], 600)
            derived = execution(value, compiler, binary['sha256'], image, case)
            report['cases'].append(dict(file=case['file'], expected_stdout=case['stdout'],
                                        image=image, command=label, summary=derived))
            save()
        report.update(complete=True, finished_at=stamp())
    except BaseException as error:
        report['failure'] = str(error)
        raise
    finally:
        save()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', action='store_true')
    args = parser.parse_args()
    if args.run:
        run()
    else:
        print(json.dumps(dict(execution=False, candidate_source=None, output=str(OUTPUT),
              producer=['runtime_precompiled', 'prepare', str(FIXTURES), str(OUTPUT / 'images')],
              consumer=['runtime_precompiled', 'execute', 'IMAGE', 'MANIFEST_EXPECTED_STDOUT', '7', '10'],
              case_count=17, separate_processes=17, compiler_enabled=False,
              excluded_from_scored_cohorts=True, scored_case_count_contribution=0), indent=2))


if __name__ == '__main__':
    main()
