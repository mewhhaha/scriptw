"""Build/freeze the separate diagnostic example; ordinary products stay separate."""
import json
from pathlib import Path
import subprocess

from campaign_runtime import (BASE, REPO, actual_source, require_scope, require,
                              save_new, digest)


def main():
    source = actual_source(); require_scope()
    stdout, stderr = BASE / 'cargo-precompiled.jsonl', BASE / 'cargo-precompiled.stderr'
    target = BASE / 'precompiled-product'
    require(not stdout.exists() and not stderr.exists() and not target.exists(),
            'refusing to overwrite a complete or partial precompiled producer')
    command = ['cargo', 'build', '--locked', '--offline', '--release', '--jobs', '1',
               '-p', 'scriptw-cli', '--example', 'runtime_precompiled', '--message-format=json']
    with stdout.open('x') as out, stderr.open('x') as err:
        result = subprocess.run(command, cwd=REPO, stdout=out, stderr=err)
    require(result.returncode == 0, 'precompiled example build failed; retain actual diagnostics')
    rows = [json.loads(line) for line in stdout.read_text().splitlines()]
    require(rows and rows[-1] == dict(reason='build-finished', success=True)
            and sum(row.get('reason') == 'build-finished' for row in rows) == 1,
            'actual Cargo producer is incomplete')
    producers = [row for row in rows if row.get('reason') == 'compiler-artifact'
                 and row.get('executable') and row['target']['name'] == 'runtime_precompiled']
    require(len(producers) == 1, 'actual precompiled example producer must be unique')
    row = producers[0]
    require(row['target']['kind'] == ['example'] and row['features'] == []
            and row['profile']['opt_level'] == '3' and row['profile']['test'] is False
            and Path(row['manifest_path']).resolve() == REPO / 'crates/scriptw-cli/Cargo.toml',
            'precompiled example is not the reviewed release product')
    target.mkdir()
    original, binary = Path(row['executable']), target / 'runtime_precompiled'
    subprocess.run(['cp', '--reflink=auto', str(original), str(binary)], check=True)
    require(binary.is_file() and not binary.is_symlink() and binary.stat().st_nlink == 1
            and digest(binary) == digest(original), 'diagnostic freeze is not independent/exact')
    save_new(target / 'identity.json', dict(source_commit=source, path=str(binary),
             sha256=digest(binary), bytes=binary.stat().st_size, cargo_producer=row,
             producer_log_sha256=digest(stdout), command=command,
             contributes_to_ordinary_product_count=False))
    print('FROZEN SEPARATE PRECOMPILED DIAGNOSTIC', source, flush=True)


if __name__ == '__main__':
    main()
