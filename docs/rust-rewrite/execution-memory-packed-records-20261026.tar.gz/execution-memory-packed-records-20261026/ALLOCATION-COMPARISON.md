# Fixed runtime allocation diagnostic comparison

One distinct standalone helper process per product/case, two invocations, identical source/callbacks; diagnostic requested Rust bytes and acknowledged process residency, not ordinary performance scores.

Each value is MiB (1,048,576 bytes). Every phase pair comes from the actual closed helper reports; this table is separate from ordinary README benchmark scores.

| Case / phase | Requested Rust live before → after | Process RSS before → after | RSS change |
| --- | ---: | ---: | ---: |
| scalar / before_engine | 0.001 → 0.001 | 4.949 → 4.910 | -0.79% |
| scalar / after_engine | 0.001 → 0.001 | 5.141 → 5.039 | -1.98% |
| scalar / after_compilation | 6.359 → 6.359 | 28.488 → 28.195 | -1.03% |
| scalar / after_execution_1 | 6.759 → 6.760 | 35.539 → 35.254 | -0.80% |
| scalar / after_dropping_profile_1 | 6.759 → 6.760 | 35.539 → 35.254 | -0.80% |
| scalar / after_execution_2 | 6.759 → 6.760 | 35.539 → 35.254 | -0.80% |
| scalar / after_dropping_profile_2 | 6.759 → 6.760 | 35.539 → 35.254 | -0.80% |
| scalar / after_dropping_artifact | 5.635 → 5.636 | 34.977 → 34.691 | -0.82% |
| scalar / after_dropping_engine | 5.635 → 5.636 | 34.977 → 34.691 | -0.82% |
| print / before_engine | 0.001 → 0.001 | 4.859 → 5.004 | +2.97% |
| print / after_engine | 0.001 → 0.001 | 5.113 → 5.133 | +0.38% |
| print / after_compilation | 6.720 → 6.720 | 34.367 → 34.008 | -1.05% |
| print / guest_start_1 | 8.850 → 8.091 | 77.492 → 81.207 | +4.79% |
| print / guest_body_finished_1 | 8.850 → 8.091 | 77.992 → 81.957 | +5.08% |
| print / after_execution_1 | 7.994 → 7.234 | 67.105 → 70.816 | +5.53% |
| print / after_dropping_profile_1 | 7.994 → 7.233 | 67.105 → 70.816 | +5.53% |
| print / guest_start_2 | 8.850 → 8.091 | 77.414 → 81.129 | +4.80% |
| print / guest_body_finished_2 | 8.850 → 8.091 | 77.914 → 81.879 | +5.09% |
| print / after_execution_2 | 7.994 → 7.234 | 67.105 → 70.816 | +5.53% |
| print / after_dropping_profile_2 | 7.994 → 7.233 | 67.105 → 70.816 | +5.53% |
| print / after_dropping_artifact | 7.833 → 7.072 | 67.027 → 70.738 | +5.54% |
| print / after_dropping_engine | 7.833 → 7.072 | 67.027 → 70.738 | +5.54% |
| retained / before_engine | 0.001 → 0.001 | 4.957 → 5.004 | +0.95% |
| retained / after_engine | 0.001 → 0.001 | 5.148 → 5.133 | -0.30% |
| retained / after_compilation | 6.720 → 6.720 | 36.156 → 36.109 | -0.13% |
| retained / guest_start_1 | 8.833 → 8.091 | 80.906 → 81.266 | +0.44% |
| retained / guest_body_finished_1 | 8.834 → 8.092 | 98.906 → 99.266 | +0.36% |
| retained / after_execution_1 | 7.977 → 7.234 | 70.520 → 70.875 | +0.50% |
| retained / after_dropping_profile_1 | 7.976 → 7.233 | 70.520 → 70.875 | +0.50% |
| retained / guest_start_2 | 8.833 → 8.091 | 80.855 → 81.215 | +0.44% |
| retained / guest_body_finished_2 | 8.834 → 8.092 | 98.863 → 99.223 | +0.36% |
| retained / after_execution_2 | 7.977 → 7.234 | 70.520 → 70.875 | +0.50% |
| retained / after_dropping_profile_2 | 7.976 → 7.233 | 70.520 → 70.875 | +0.50% |
| retained / after_dropping_artifact | 7.816 → 7.073 | 70.418 → 70.773 | +0.50% |
| retained / after_dropping_engine | 7.816 → 7.072 | 70.418 → 70.773 | +0.50% |

The complete 35 phase pairs retain raw smaps, coherent requested/released/live counters, both invocations, source/rlib/helper hashes and all commands. Baseline source is 25909ef750d487e8ae257cdce909635d64196995; candidate source is 736f0f1206c581e70048467f7d4423e1efed8bdd. The helper source is byte-identical. All reductions remain observational; the counters do not by themselves assign each saved page or allocation to a component.

- Requested Rust GlobalAlloc sizes exclude allocator usable/resident bytes and native allocations bypassing GlobalAlloc.
- Anonymous mappings do not identify live JavaScript or Intl ownership; no exact causal subtraction between counters.
- Private file-backed native mappings change residency/reclaimability; cold-file/page-cache state and shared pages affect RSS/PSS.
- Baseline retains its original actual259 outer receipt; no baseline run is relabelled as the new source.
- Diagnostic module cache is one entry/64MiB; default SDK512MiB retention differs.
- Native perf-map hashing is disabled. RSS/capacity/virtual address space, logical requested peaks and guest live memory remain distinct.
