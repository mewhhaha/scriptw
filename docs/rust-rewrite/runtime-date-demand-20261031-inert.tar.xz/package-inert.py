"""Package completed Date evidence as inert data; never load native products."""
from pathlib import Path
import hashlib,json,stat,tarfile,sys
ROOT=Path('/workspace/scriptw');OUT=Path(__file__).resolve().parent
DEST=ROOT/'docs/rust-rewrite';STEM=sys.argv[1]
def digest(path):
 with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
report=json.loads((OUT/'report-core.json').read_text())
assert report['schema']=='scriptw-date-demand-v1' and report['complete'] is True
assert report['status']==report['decision']['status'] and 'pending' not in report['status'].lower()
assert Path(STEM).name==STEM and STEM
assert not (DEST/(STEM+'-inert.tar.xz')).exists() and not (DEST/(STEM+'.json')).exists()
excluded={'cache','caches','normal-cache','candidate','failed-native','__pycache__'}
members={}
extensions={'.json','.jsonl','.log','.stderr','.stdout','.smaps','.rs','.py','.md','.toml','.lock','.js','.mjs','.cjs','.txt','.wasm','.gz','.patch'}
capture_names={'stdout','stderr','control'}
native_suffixes={'.elf','.exe','.so','.dll','.dylib','.o','.a','.bin','.swpc','.cwasm','.wasmc','.serialized'}
def inert_regular(path):
 info=path.lstat()
 if not stat.S_ISREG(info.st_mode) or info.st_mode&0o111:return False
 if any(suffix.lower() in native_suffixes for suffix in path.suffixes):return False
 with path.open('rb') as stream:head=stream.read(16)
 return not head.startswith((b'\x7fELF',b'MZ',b'SCRWEP',b'SCRWNR'))
for p in OUT.rglob('*'):
 rel=p.relative_to(OUT)
 if any(part in excluded or part.startswith('next-') for part in rel.parts):continue
 if p.suffix not in extensions and p.name not in capture_names:continue
 if not inert_regular(p):continue
 assert p.stat().st_size<=64*1024**2,(rel,p.stat().st_size)
 members[str(rel)]=p
for name in ('identity.json','products.json'):
 path=OUT/'candidate'/name;assert inert_regular(path),path
 members['candidate/'+name]=path
members={name:p for name,p in members.items() if not name.startswith('state') and name!='package-report.log'}
index=[dict(path=name,bytes=p.stat().st_size,sha256=digest(p)) for name,p in sorted(members.items())]
assert len(index)<=10000 and sum(r['bytes'] for r in index)<=2*1024**3
archive=DEST/(STEM+'-inert.tar.xz')
with tarfile.open(archive,'w:xz',preset=6) as tar:
 for item in index:
  p=members[item['path']];info=tarfile.TarInfo(item['path']);info.size=item['bytes'];info.mode=0o644;info.mtime=0
  with p.open('rb') as stream:tar.addfile(info,stream)
expected={r['path']:r for r in index};seen=set();total=0
with tarfile.open(archive,'r|xz') as tar:
 for m in tar:
  assert m.isfile() and m.name in expected and m.name not in seen and 0<=m.size<=64*1024**2
  seen.add(m.name);row=expected[m.name];assert m.size==row['bytes']
  stream=tar.extractfile(m);h=hashlib.sha256();count=0
  while chunk:=stream.read(1024**2):h.update(chunk);count+=len(chunk)
  assert count==m.size and h.hexdigest()==row['sha256'];total+=count
assert seen==set(expected)
report['archive']=dict(file=archive.name,bytes=archive.stat().st_size,sha256=digest(archive),member_count=len(index),expanded_bytes=total,members=index,
 exclusions='Only regular non-executable files are admitted; symlinks, special files, native/serialized suffixes, ELF/PE and Scriptw native-envelope magic, caches and next unimplemented patches are excluded. Raw WebAssembly, .smaps, and regular capture files named stdout/stderr/control are retained as data.')
with (DEST/(STEM+'.json')).open('x') as stream:stream.write(json.dumps(report,indent=2)+'\n')
print(json.dumps(dict(archive_bytes=archive.stat().st_size,members=len(index),expanded_bytes=total),indent=2),flush=True)
