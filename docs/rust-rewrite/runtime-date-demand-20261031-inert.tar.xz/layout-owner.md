Date heap/schema chunk

Owned files and exact before/after hashes are in layout-owner-inputs.json; layout-owner.patch contains only these five tracked paths. gc_types.rs needs no edit because layouts::* is already re-exported. Parent explicitly added ownership of the required one-line enum_i32_codec addition in gc_types/value.rs.

The Date recipe is final under PropertyValue, with one immutable nonnull Realm edge and no id/cache. DATE_STATE is appended after ERROR_STATE, so the existing Error structural owner must stop assuming Error is the last Realm field; that agent has been notified. Date slots48/112 and the159-slot table are unchanged.

The existing encoded compact-record test now owns the sealed sum, exact recipe edge, state width/mutability and nonnull IntrinsicTable contract. A new actual collector-layout test decodes the emitted declarations, preserves concrete reference kinds/nullability and uses Wasmtime47 CopyingTypeLayouts to assert32B recipe and96B Realm, not a source arithmetic estimate. The test has not run yet.

Changed-file rustfmt2021 with skip_children=true and git diff --check passed. No build, native execution, broad suite, ABI edit, snapshot export, stage or commit was performed by this chunk.
