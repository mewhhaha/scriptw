# Deferred Date report assembly

build-report.py and package-inert.py are source-only preparations. Neither main
entrypoint has run. No native product/image was read, hashed or executed.

The assembler requires the frozen V2/V3/V4 input manifests and source snapshots,
the original library receipt and exact continuations, all ten integration
receipts and image-retirement records, and native-integrations-final-summary.json.
It independently checks the 605-case library/embedding union and the 31-case
runtime-link union. Original failures, exact binary identities, test-only reuse
proofs and full transcript origins survive. External watched transcripts are
copied as inert data into native-streams for packaging.

Candidate identity/products/build metadata, the 53-file Test262 run summary,
measurement/balanced-analysis.json and its completed raw cohort are required.
The assembler reuses only the measured driver's pure validation functions to
reconstruct the complete 21-row tmpfs cohort from 504 raw children and the
predeclared eight-row normal-overlay follow-up from 192 raw children, each at all
three boundaries. It compares both complete results exactly with their saved
analyses, preserving separate substrate scopes without pooling. It never calls the driver's
product/image checks, preparation, measurement or native invocation functions.
All per-round/group/pooled samples within each scope, means, medians and original
RSS remain. Follow-up source identities, wrapper hash and before/after overlay
cache policy are checked. Missing normal-follow-up evidence blocks assembly.

The immutable balanced-substrate annotation, unscored same-baseline/same-image
cache-admission comparison (including the rejected zero-warmup attempt), backing
source, actual runtime code-size metadata and all 21 independent Node source
goldens remain explicit. None establishes a Date memory benefit. The complete
initial cohort does not qualify the normal disk-backed memory floor, and the
eight-case follow-up does not qualify the full 17 on that substrate.

separated-substrate-helper-check.json records successful inert reconstruction of
all 696 native children, 21 saved Node reference sources and both diagnostics.
No new timing/native/Node command or native payload read/hash was performed.

decision.json must provide nonempty status, reviewer, basis, limits and next,
using the existing WHOLE decision shape. A pending status is rejected. The
decision is copied verbatim; the assembler does not invent an outcome or a
performance claim. Missing/incomplete coverage or mismatched raw records prevents
report-core.json from being created.

report-preparation-check.json records an inert-only check of eight existing
native scopes. It caught and corrected libtest's " - should panic" execution
label suffix, which is absent from canonical --list inventories. The assembler
and packager have only been syntax-checked; final assembly awaits complete inputs.

After review and completion, root may run:

    python3 -B target/performance-date-demand-20261031/build-report.py
    python3 -B scripts/limited_verification.py --cloud -- python3 -B target/performance-date-demand-20261031/package-inert.py runtime-date-demand-20261031

The existing inert archive policy retains regular raw records, source snapshots,
metadata, Python assembly sources and raw Wasm. It excludes caches, next drafts,
executable files, native/serialized suffixes and native envelope magic. Candidate
identity/products JSON are explicitly included. Both cache and normal-cache
directories are excluded, as are candidate, failed-native and __pycache__.
Failed-image identity/frozen-path metadata remains in the scope's separate
native-image-retirement.json. Code-size metadata and disassembly remain while
ELF/native payload bytes are excluded by suffix, mode and magic. Final archive/report
paths must be new. No final archive or tracked documentation was written here.
