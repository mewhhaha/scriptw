"""One predeclared eight-case follow-up, separate from tmpfs full cohort."""
from pathlib import Path
import ast,hashlib,importlib.util,json,os,subprocess
ROOT=Path('/workspace/scriptw');OUT=Path(__file__).resolve().parent
script=OUT/'measurement/cohort.py';spec=importlib.util.spec_from_file_location('date_measurement',script);c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
normal=(OUT/'normal-cache').resolve();assert normal.is_dir() and Path(os.environ['SCRIPTW_CACHE_DIR']).resolve()==normal

def cache_policy():
 fs=subprocess.check_output(['stat','-f','--format=%T:%t',str(normal)],text=True).strip()
 assert fs=='overlayfs:794c7630',fs
 return dict(path=str(normal),filesystem=fs,environment_cache_root=os.environ['SCRIPTW_CACHE_DIR'])

wanted={'startup.js','date-first-epoch.js','date-repeated-256.js','sort-reverse-512.js','sort-sorted-512.js','join-singleton-1024.js','join-4096.js','folded-string-4096.js'}
plan,all_cases,hashes=c.inputs();cases=[v for v in all_cases if v['file'] in wanted];assert len(cases)==len(wanted)==8
order=c.ORDERS['eight'];prefix='controls-normal';lock=c.checked_lock();before=cache_policy()
for label in ['baseline','candidate']:
 for group in c.source_groups():c.producer(label,group,lock)
c.save(c.OUT/(prefix+'-plan.json'),dict(order=order,samples=c.SAMPLES,warmups_checked=c.WARMUPS,boundaries=c.BOUNDARIES,product_lock_sha256=c.digest(c.OUT/'product-lock.json'),source_hashes=hashes,resources_before=c.resources(),cache_policy_before=before,selected_cases=[v['file'] for v in cases],followup_driver_sha256=c.digest(Path(__file__)),scope='Astra predeclared8case normaloverlayfollowup. Initialfull21tmpfs anonymousfallbackdata retainedseparately; nopooling. Sameownfrozenproducts/freshlocalimages, all3boundaries21measured10checkedwarmups, ABBA+BAAB.'))
for index,label in enumerate(order):
 (c.OUT/f'{prefix}-r{index}-{label}-ordinary-artifacts').mkdir()
 for case in cases if index%2==0 else list(reversed(cases)):
  for boundary in c.BOUNDARIES:
   assert Path(os.environ['SCRIPTW_CACHE_DIR']).resolve()==normal
   tool=lock[label]['products']['runtime_baseline' if boundary=='ordinary' else 'compiler_precompiled_baseline']
   report=c.invoke(f'{prefix}-r{index}-{label}-{boundary}-{case["file"]}',c.arguments(prefix,index,label,boundary,case,lock),tool['sha256'])
   c.observations(report,boundary,case,label,lock)
after=cache_policy();assert after==before
c.save(c.OUT/(prefix+'-complete.json'),dict(status='All8selectedsources matched all3boundaries',order=order,cases=[v['file'] for v in cases],boundaries=c.BOUNDARIES,resources_after=c.resources(),cache_policy_after=after,followup_driver_sha256=c.digest(Path(__file__))))
# Reuse the unchanged measured driver's exact validation/statistics body with an
# explicit selected-case input. Producer validators retain the full original
# inventories; no source/product/image admission or validation is weakened.
namespace=dict(c.__dict__);namespace['inputs']=lambda:(plan,cases,hashes)
def save_analysis(path,value):
 assert Path(path).name==prefix+'-analysis.json'
 value.update(scope='Eight predeclared unchanged sources only; normaldisk-backedoverlaycache; all3boundaries separate; nopoolingwithinitialtmpfscohort, nofull17normalqualification or universalRSSclaim.',cache_policy_before=before,cache_policy_after=after,selected_cases=[v['file'] for v in cases],followup_driver_sha256=c.digest(Path(__file__)))
 c.save(path,value)
namespace['save']=save_analysis
nodes=[n for n in ast.parse(script.read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='analyze'];assert len(nodes)==1
exec(compile(ast.Module(body=nodes,type_ignores=[]),str(script),'exec'),namespace)
namespace['analyze'](prefix,order,lock)
print('COMPLETE normaloverlay8case followup',flush=True)
