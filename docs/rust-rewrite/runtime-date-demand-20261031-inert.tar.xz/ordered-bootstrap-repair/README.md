# Prepared test-only aggregate inventory repair

This patch has not been applied. The source file remains unchanged while the frozen native run finishes.

Base file: `crates/scriptw-aot-wasm/src/tests/ordered_bootstrap_allocation.rs`
Base SHA256: `c73d2d5b75f732da7930f55b6cc3e75742e485439461ff96de15a08ce719ba9a`
Proposed replacement: `ordered_bootstrap_allocation.rs`
Patch: `repair.patch`

`actual_realm_bootstrap_installs_checked_rows_through_one_counted_loop` decodes the actual run spans only from RealmInitializeIntrinsics, RealmEnsureTemporal and RealmEnsureBinaryData. Date's two spans have moved out of its first body to RealmEnsureDate. The aggregate must follow the physical owner to retain its original inventory and attribute exercise.

Source-only count projection, not an encoded-Wasm/native verdict:
- The 37 static IntrinsicMethodPlan declarations contain 379 eligible deferred rows in 38 runs after excluding the closed canonical-function barriers (including RegExp's three canonical symbol methods and the shared Array/TypedArray toString function).
- Binary contributes 58 of those rows in six runs; Date contributes 49 in two runs; core contributes the remaining 272 in 30 runs.
- Temporal's eight constructor plans contribute 17 rows; its fixed prototype plans contribute 82; the ZonedDateTime prototype table adds 20. This is 119 rows in 16 runs.
- The current three-owner aggregate therefore projects to 449 rows in 52 runs. Both `> 400` rows and `>= 40` runs should still pass.
- The current inventory has exactly three Symbol-keyed rows: RegExp @@replace, RegExp @@split and String @@iterator. It has zero nonwritable rows. Date's @@toPrimitive is the fourth Symbol row and sole nonwritable row. Thus the meaningful final `symbols >= 4 && nonwritable >= 1` check is expected to fail until the aggregate follows Date's new owner.
- Adding RealmEnsureDate restores the original 498 rows, 54 runs, four Symbol rows and one nonwritable row. The UTC/GMT direct installation also belongs in the inspected direct-install chain.

The patch adds the actual Date ensure body to both inventories and corrects the diagnostic's obsolete “both initializers” wording. It preserves every existing numerical threshold and typed row/attribute/domain check. The new Date structural owner separately proves that those rows occur only in Date's ensure owner.

Validation performed: rustfmt --edition 2021 --config skip_children=true on the proposed scratch file; git apply --check on the patch. No tracked source edit, native compilation or native execution performed for this preparation. Apply only after the frozen run records the actual failure, rerun the affected owner, and preserve unaffected passing scopes with their original identities.
