"""Inspect frozen own R as inert ELF data outside timed work; never load it."""
from pathlib import Path
import hashlib
import importlib.util
import json
import re
import subprocess

ROOT = Path('/workspace/scriptw')
OUT = Path(__file__).resolve().parent
BASELINE = ROOT / 'target/performance-whole-trip-affine-20261031'
spec = importlib.util.spec_from_file_location(
    'owned_runtime_inspector', ROOT / 'target/performance-memory-parity-20261031/diagnose-pages.py')
inspector = importlib.util.module_from_spec(spec)
spec.loader.exec_module(inspector)

rows = {}
identities = {
    'baseline': ('c0984be5554f5db7849e3af64c472c3a846c7c11cc035663176b078bb5816464', 41),
    'candidate': ('a35adbcb61dbc57b4ee44dd1527019358deb137b11ae559de7d0d4b4a860b480', 42),
}
for label, folder in [('baseline', BASELINE), ('candidate', OUT)]:
    inspector.WORK = folder
    target = OUT / 'code-size-private' / label
    target.mkdir(parents=True, exist_ok=False)
    host, identity, record = inspector.extract_runtime('candidate', target)
    expected_fingerprint, expected_layout = identities[label]
    assert record['source_fingerprint'] == expected_fingerprint
    assert record['runtime_layout'] == expected_layout
    helpers = {}
    for name in ['property_value_resolve', 'realm_initialize_intrinsics', 'realm_ensure_date']:
        matches = [function for function in record['functions']
                   if function['name'].endswith('::helper::' + name)]
        assert len(matches) == (0 if label == 'baseline' and name == 'realm_ensure_date' else 1)
        helpers[name] = matches[0] if matches else None
    resolver = helpers['property_value_resolve']
    image = target / record['inert_native_file']
    length = min(768, resolver['bytes'])
    with image.open('rb') as stream:
        stream.seek(resolver['file_offset'])
        entry = stream.read(length)
    assert len(entry) == length
    command = ['/usr/bin/objdump', '-d', f'--start-address={resolver["value"]}',
               f'--stop-address={resolver["value"] + length}', str(image)]
    capture = subprocess.run(command, text=True, capture_output=True, check=True)
    stack_reservations = re.findall(r'\bsub\s+\$0x([0-9a-f]+),%rsp', capture.stdout)
    stack_allowances = re.findall(r'\badd\s+\$0x([0-9a-f]+),%r10', capture.stdout)
    saved_registers = re.findall(r'\bmov\s+%(rbx|r12|r13|r14|r15),0x[0-9a-f]+\(%rsp\)', capture.stdout)[:5]
    assert stack_reservations and int(stack_reservations[0], 16) == 176
    assert stack_allowances and int(stack_allowances[0], 16) == 192
    assert saved_registers == ['rbx', 'r12', 'r13', 'r14', 'r15']
    entry_path = target / 'resolver-entry-768.txt'
    entry_path.write_text(capture.stdout)
    (target / 'resolver-entry-768.stderr').write_text(capture.stderr)
    rows[label] = dict(
        host=str(host), host_sha256=record['host_sha256'], source_commit=record['source_commit'],
        source_fingerprint=record['source_fingerprint'], runtime_key=record['runtime_key'],
        runtime_layout=record['runtime_layout'], native_sha256=record['native_sha256'],
        native_bytes=record['native_bytes'], runtime_text_bytes=record['text']['bytes'],
        resolver=resolver, helpers=helpers,
        raw_symbols=str((target / 'candidate-runtime-symbols.json').relative_to(OUT)),
        resolver_entry=dict(raw=str(entry_path.relative_to(OUT)),
                            stderr=str((target / 'resolver-entry-768.stderr').relative_to(OUT)),
                            command=command, bytes=length, span_sha256=hashlib.sha256(entry).hexdigest(),
                            observed_stack_reservation_bytes=176, observed_stack_limit_allowance_bytes=192,
                            observed_saved_registers=saved_registers,
                            scope='Static prologue only; reservation excludes pushed RBP/caller return address. No execution, root-initialization, residency or timing attribution.'),
    )
report = dict(
    schema='scriptw-inert-runtime-code-size-v1', scored=False, native_execution=False,
    products=rows,
    changes_bytes={key: rows['candidate'][key] - rows['baseline'][key]
                   for key in ['native_bytes', 'runtime_text_bytes']},
    resolver_change_bytes=rows['candidate']['resolver']['bytes'] - rows['baseline']['resolver']['bytes'],
    helper_changes_bytes={name: (rows['candidate']['helpers'][name]['bytes'] if rows['candidate']['helpers'][name] else 0)
                          - (rows['baseline']['helpers'][name]['bytes'] if rows['baseline']['helpers'][name] else 0)
                          for name in rows['candidate']['helpers']},
    identity_policy='Each frozen own host is hashed against both products.json and identity.json before and after bounded runtime extraction. Packed framing, execution receipt, source fingerprint, decompression length/native SHA, ELF extents and symbols are validated by the existing inert extractor. No archived native image is read.',
    limits='Static own frozen ELF bytes and bounded768B resolver entry disassemblies only. No native payload/module loading or execution, no live profiling, and no executed-code/residency/RSS or causal performance claim. Extracted ELF files and native products remain private and excluded from the archive by suffix/magic/regular-file policy.',
)
(OUT / 'runtime-code-size.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(dict(status='complete', products={label: dict(
    source_fingerprint=row['source_fingerprint'], runtime_layout=row['runtime_layout'],
    native_bytes=row['native_bytes'], runtime_text_bytes=row['runtime_text_bytes'],
    helpers={name: value['bytes'] if value else None for name, value in row['helpers'].items()})
    for label, row in rows.items()}, changes_bytes=report['changes_bytes'],
    helper_changes_bytes=report['helper_changes_bytes']), indent=2), flush=True)
