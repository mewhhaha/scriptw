# Date structural owner

Owned tracked files:
- crates/scriptw-aot-wasm/src/tests/date_demand_initialization.rs (new; four regressions)
- crates/scriptw-aot-wasm/src/tests/error_demand_initialization.rs
- crates/scriptw-aot-wasm/src/tests.rs (Date module registration only)

Date coverage inspects encoded runtime/program Wasm: exported void Realm ABI, nonnull StoredValue table representation, typed DATE_STATE field ordinal, Ready/Dormant control frames and common Realm root, unconditional Building/Ready writes bracketing allocation/publication, two canonical slot writes and ordering, all actual Date installation rows only in ensure, 51 preserved native bodies and declarative roots, global data recipe/publication flags with no eager ensure, real typed resolver branch and canonical return, shared UTC/GMT recipe root/two publications, and both canonical read slots guarded by the same defining Realm ensure.

Error coverage preserves the existing proof and obtains ERROR_STATE's ordinal by encoding a small test-local typed field read, with no production snapshot export. Existing Error decoding helpers are reused by the Date owner.

Cheap validation: rustfmt (provided workspace toolchain) passed for both owned test modules. No Cargo/native test or expensive build run before parent batch freeze. Focused filters: date_demand_initialization and error_demand_initialization under scriptw-aot-wasm --lib.

Added the bounded direct emitter witness for emit_intrinsic_callable(DateConstructor), using the existing crate-visible scratch builder, typed Realm context and a minimal planned Date meta. The encoded body must call EnsureDate exactly once, read canonical DateConstructor and bind FunctionObject, with no other helper call, StructNew, array allocation or RefFunc fallback. No production export or source-owner seam was added. Formatting/diff checks passed; no build/native command run.
