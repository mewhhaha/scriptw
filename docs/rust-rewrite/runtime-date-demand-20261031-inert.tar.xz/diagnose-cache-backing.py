"""Unscored fixed-source admission comparison; execute only own fresh local image."""
from pathlib import Path
import hashlib,json,os,subprocess,sys
ROOT=Path('/workspace/scriptw');OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'scripts'))
from benchmark_metrics import measure_process
host=ROOT/'target/performance-whole-trip-affine-20261031/candidate/compiler_precompiled_baseline'
identity=json.loads((host.parent/'identity.json').read_text());image=OUT/'measurement/images-baseline-original/integer.js.swpc'
normal=OUT/'normal-cache';normal.mkdir(exist_ok=True)
rows=[]
for label,cache in [('tmpfs',Path('/tmp/scriptw-date-demand-20261031-cache')),('normal',normal)]:
 env=dict(os.environ);env['SCRIPTW_CACHE_DIR']=str(cache)
 argv=[str(host),'execute-scriptw',str(image),'730532261\n','3','1'];stem=OUT/('cache-admission-v2-'+label)
 with stem.with_suffix('.stdout').open('xb') as out,stem.with_suffix('.stderr').open('xb') as err:r=measure_process(argv,cwd=ROOT,env=env,stdout=out,stderr=err,timeout=900,time_binary=Path('/workspace/toolchains/system/usr/bin/time'))
 r.update(scored=False,argv=argv,cache_root=str(cache),cache_filesystem=subprocess.check_output(['stat','-f','--format=%T:%t',str(cache)],text=True).strip(),executable_sha256=identity['executable_sha256'])
 stem.with_suffix('.command.json').write_text(json.dumps(r,indent=2)+'\n');assert r['exit_code']==0 and not r['timed_out'];report=json.loads(stem.with_suffix('.stdout').read_text());assert report['source_fingerprint']==identity['source_fingerprint'] and all(o['stdout']=='730532261\n' and o['matched'] for o in report['observations'])
 rows.append(dict(label=label,command=r,process_snapshots=report['process_snapshots'],load_process_memory=report['native_load_process_memory'],first_observation=report['observations'][0]['process_snapshots']))
(OUT/'cache-admission-comparison.json').write_text(json.dumps(dict(scored=False,source_fingerprint=identity['source_fingerprint'],rows=rows,scope='Same frozen c098baseline andsame freshlocalintegerimage; cache pathfilesystem only environmentchange; 3observations1warmup, never timingqualification.'),indent=2)+'\n')
for r in rows:print(r['label'],r['command']['cache_filesystem'],r['first_observation']['after_execution'],flush=True)
