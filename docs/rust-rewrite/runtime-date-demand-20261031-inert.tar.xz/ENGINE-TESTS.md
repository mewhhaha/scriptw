Engine Date demand regression chunk, based on accepted affine HEAD 7c47e3827.
Owned tracked files are the new
`crates/scriptw-engine/tests/aot_gc_entries/aot_gc_date_demand_initialization.rs`
and its registration in `aot_gc_entries/main.rs`. The requested older
`tests/aot_gc_entries.rs` path does not exist in this checkout. Production, ABI,
schema, structural tests and product documentation remain with their owners.

Five new tests use the existing binary-demand harness conventions and the
Test262-authorized native `__scriptwCreateRealm` entry point. No `$262` harness
object is assumed. Behavioral cases run both original and strict modes with a
fixed wall clock of 1234 ms and configured +01:00 system zone.

- `first_date_descriptor_publishes_complete_realm_graph_and_shared_utc_gmt_alias`
  checks metadata-only global membership, first descriptor/data flags, complete
  constructor/prototype cycles, parents, metadata and exact method/key order,
  two foreign Realms, UTC/GMT cache identity across GC and independent mutation.
  Additional unread-alias delete/replace cases verify that the sibling recipe
  survives without depending on prior alias materialization. Expected wall-clock
  reads: zero.
- `unread_date_mutations_and_locked_globals_keep_private_foreign_defaults`
  covers unread delete/assign/data/accessor/attribute-only/seal/freeze, foreign
  bound and Proxy newTarget primitive defaults, substituted accessor counts,
  exact locked SameValue acceptance/rejection, object-valued prototype bypass,
  coercion-before-abrupt-prototype-Get and revoked Proxy completion. Expected
  wall-clock reads: zero.
- `date_first_publication_ignores_inherited_hooks_and_preserves_call_order_and_realm`
  poisons inherited metadata/member setters and public Object/Function parents,
  verifies own publication, argument conversion/prototype Get order across GC,
  default-hint conversion, fixed-clock call/construct/now, foreign brand/coercion
  error prototypes after public TypeError replacement, and captured UTC methods
  after deleting Date. Exactly three intentional wall-clock reads are expected.
- `later_programs_and_retained_calls_keep_foreign_date_demand_and_host_read_boundaries`
  uses three separately evaluated NativeHost programs in a captured foreign Realm:
  the first retains a primitive-prototype newTarget and replaces unread Date,
  the second demands the private graph, and the third uses captured aliases after
  public Date/eval/evalScript changes and GC. A Portable embedding subcase reuses
  the same compiled module in two independent Stores and exercises actual retained
  get/call APIs. A test-local wrapper delegates the real registered
  SystemTimeZoneSnapshot callback using its actual FuncType; it fabricates no GC
  response and changes no production API. Clock/zone counts stay zero through
  descriptor/alias demand and UTC-only use. Date.now and ordinary Date call then
  exercise clock and clock-before-zone behavior, and local-time queries use the
  configured zone. Constructor/method roots survive collection and public mutation.
- `rooted_snapshot_resolves_unread_date_and_preserves_cycle_flags_and_utc_gmt_identity`
  returns a foreign global stripped to one unread Date data property, with an
  attribute-only writable change and replaced caller Date. The actual graph
  property-value resolver must return the complete foreign constructor and
  ordinary prototype cycle, retain descriptor flags and make UTC/GMT point to
  the same defining-Realm function node. Property lookup uses semantic names and
  graph IDs, never physical Realm field positions. No Date instance is returned
  or requested from the snapshot adapter. Expected clock reads: zero.

Exact complete new owner filter:

```sh
python3 -B scripts/limited_verification.py --cloud -- cargo test --locked -p scriptw-engine --test aot_gc_entries aot_gc_date_demand_initialization:: -- --test-threads=1
```

`engine-changes.patch` records the complete reviewable chunk, and
`engine-base-hashes.json` / `engine-draft-receipt.json` record its source identities.
Rustfmt and whitespace checks completed. No build, native/Node execution or test
suite was run; these are five expected test functions, not passing observations.
Parent batch verification must establish actual counts and execution results.
