"""Run exact frozen scopes serially; preserve failed images and seal retirements."""
from pathlib import Path
import gzip,hashlib,json,os,subprocess,sys
ROOT=Path('/workspace/scriptw');OUT=Path(__file__).resolve().parent

def digest(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def save(p,v):
 with p.open('x') as f:json.dump(v,f,indent=2);f.write('\n')
def path(v):
 p=Path(v);return p if p.is_absolute() else ROOT/p

def run_scope(label,target,filt=None):
 out=OUT/label
 argv=['python3','-B','scripts/run_workspace_tests.py','--profile','release','--packages','scriptw-aot-wasm','scriptw-engine','--output',str(out),'--test-processes','1','--no-test-incremental','--idle-builds','--preserve-test-artifacts','--stop-on-build-failure','--only-targets',target]
 if filt:argv.extend(['--native-filter',target+'='+filt])
 print('START',label,target,filt,flush=True)
 with (OUT/(label+'.log')).open('xb') as log:r=subprocess.run(argv,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT)
 receipt=json.loads((out/'receipt.json').read_text())
 assert receipt['source_unchanged']
 cases=receipt['cases'];assert len(cases)==1
 case=cases[0];products={}
 for f in out.glob('*.build.jsonl*'):
  data=gzip.decompress(f.read_bytes()) if f.suffix=='.gz' else f.read_bytes()
  for line in data.splitlines():
   item=json.loads(line)
   if item.get('reason')=='compiler-artifact' and item.get('executable'):
    products[Path(item['executable'])]=item
 records=[];wanted=case.get('executable_sha256');found=False
 for p,item in products.items():
  if not p.exists():continue
  actual=digest(p);selected=actual==wanted
  record=dict(path=str(p),sha256=actual,bytes=p.stat().st_size,selected=selected)
  if selected:
   assert p.stat().st_size==case['executable_bytes'];found=True
   if case['state']=='passed':
    assert case['inventory_matches'] and case['exit_code']==0
    p.unlink();record['action']='retired exact passing image after complete source-bound transcript'
   else:
    dest=OUT/'failed-native'/label/p.name;dest.parent.mkdir(parents=True,exist_ok=True);assert not dest.exists()
    p.rename(dest);assert digest(dest)==actual;record.update(action='frozen failed executable outside Cargo',frozen_path=str(dest))
  else:
   # Complete selector-specific Cargo output, explicitly unselected and never executed here.
   assert item['target']['kind'] in [['lib'],['test'],['example'],['bin']]
   p.unlink();record['action']='retired unselected Cargo output; no execution verdict'
  records.append(record)
 if wanted:assert found
 save(out/'native-image-retirement.json',dict(argv=argv,exit_code=r.returncode,records=records))
 print('END',label,case.get('state'),case.get('outcomes'),flush=True)
 return r.returncode

mode=sys.argv[1]
if mode=='runtime-repair':
 scopes=[('native-date-runtime-link-repair','scriptw-aot-wasm:runtime_link','host_import_function_indices_structure::role_and_authority_census_is_closed_over_product_sources')]
elif mode=='repair':
 scopes=[('native-date-demand-repair','scriptw-aot-wasm:scriptw_aot_wasm','demand_initialization::'),('native-date-ordered-repair','scriptw-aot-wasm:scriptw_aot_wasm','tests::ordered_bootstrap_allocation::actual_realm_bootstrap_installs_checked_rows_through_one_counted_loop')]
else:
 assert mode in ['integrations','continue-integrations','finish-integrations']
 plan=json.loads((OUT/'verification-plan.json').read_text())['native_integrations']
 scopes=[(f'native-date-integration-{i:02d}',t,plan['filters'].get(t)) for i,t in enumerate(plan['targets']) if mode=='integrations' or (mode=='continue-integrations' and i>=2) or (mode=='finish-integrations' and i>=5)]
results=[]
for label,target,filt in scopes:
 result=run_scope(label,target,filt);results.append(dict(label=label,target=target,filter=filt,exit_code=result))
 if result and mode not in ['continue-integrations','finish-integrations']:break
save(OUT/('native-'+mode+'-summary.json'),dict(scopes=results,complete=len(results)==len(scopes),all_passed=all(r['exit_code']==0 for r in results)))
sys.exit(any(r['exit_code'] for r in results))
