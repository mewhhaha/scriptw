#!/usr/bin/env python3
"""Audit isolated Python validators against inert saved WHOLE records only."""
import ast
import argparse
import copy
import hashlib
import json
from pathlib import Path
import statistics

ROOT = Path('/workspace/scriptw')
OUT = Path(__file__).resolve().parent
WHOLE = ROOT / 'target/performance-whole-trip-affine-20261031'
CANONICAL = ROOT / 'crates/scriptw-cli/tests/fixtures/v8_execution_hotpaths'


def load(path):
    return json.loads(path.read_text())


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main(receipt_name):
    # Compile function definitions only. Do not import the cohort's measurement
    # module, resolve/hash native products, call subprocesses or run a JS engine.
    driver = OUT / 'cohort.py'
    tree = ast.parse(driver.read_text())
    selected = {'require', 'check_report_identity', 'retained_wrapper',
                'producer_header', 'observations', 'score', 'statistics_row',
                'image_group'}
    body = [node for node in tree.body
            if isinstance(node, ast.FunctionDef) and node.name in selected]
    assert {node.name for node in body} == selected
    namespace = dict(statistics=statistics,
                     DATE_FILES=['date-first-descriptor.js', 'date-first-epoch.js',
                                 'date-repeated-256.js'], SAMPLES=21, WARMUPS=10)
    exec(compile(ast.Module(body=body, type_ignores=[]), str(driver), 'exec'), namespace)

    plan = load(CANONICAL / 'manifest.json')
    cases = [*plan['execution'], plan['startup']]
    identity = load(WHOLE / 'candidate/identity.json')
    metadata = load(WHOLE / 'candidate/products.json')
    lock = dict(source_hashes={case['file']: digest(CANONICAL / case['file']) for case in cases},
                candidate=dict(identity=identity, products=metadata))
    original = load(WHOLE / 'candidate-original/producer.json')
    retained = load(WHOLE / 'candidate-retained/producer.json')
    records = []
    for group, report, expected, filename in [
        ('original', original, cases, 'candidate-prepare-original.stdout'),
        ('retained-canonical', retained, plan['execution'], 'candidate-prepare-retained.stdout'),
    ]:
        aggregate = load(WHOLE / filename)
        assert aggregate == report
        namespace['producer_header'](report, 'candidate', group, lock, expected,
                                     report['manifest_sha256'])
        records.append(dict(path=str((WHOLE / filename).relative_to(ROOT)),
                            sha256=digest(WHOLE / filename),
                            root_keys=sorted(report), case_keys=sorted(report['cases'][0]),
                            cases=len(report['cases'])))
    namespace['producer'] = lambda label, group, bound: (
        original if group == 'original' else retained)

    # The aggregate can omit redundant policy decoration; every actual per-image
    # receipt must still bind its own exact identity/configuration.
    without_aggregate = copy.deepcopy(retained)
    without_aggregate.pop('shared_configuration', None)
    namespace['producer_header'](without_aggregate, 'candidate', 'retained-canonical',
                                 lock, plan['execution'], retained['manifest_sha256'])
    for case in retained['cases']:
        directory = WHOLE / 'candidate-retained'
        original_source = directory / case['original_source_file']
        derived_source = directory / case['derived_source_file']
        assert digest(original_source) == case['original_source_sha256'] == lock['source_hashes'][case['file']]
        assert derived_source.read_text() == namespace['retained_wrapper'](original_source.read_text())
        assert digest(derived_source) == case['derived_source_sha256']
        sidecar = directory / Path(case['image']).with_suffix('.json')
        assert load(sidecar) == case

    consumer_rows = []
    for case in plan['execution']:
        for boundary in ['original', 'retained', 'ordinary']:
            path = WHOLE / f'confirmation-r0-candidate-{boundary}-{case["file"]}.stdout'
            report = load(path)
            samples = namespace['observations'](report, boundary, case, 'candidate', lock)
            assert len(samples) == 21
            namespace['statistics_row']([namespace['score'](sample, boundary) for sample in samples])
            if boundary == 'original':
                namespace['statistics_row']([
                    sample['process_snapshots']['after_execution']['rss_bytes'] for sample in samples])
            consumer_rows.append(dict(path=str(path.relative_to(ROOT)), sha256=digest(path),
                                      boundary=boundary, file=case['file'], schema=report['schema'],
                                      root_keys=sorted(report),
                                      observation_keys=sorted(samples[0]), measured=len(samples),
                                      checked_warmups=report['warmups']))
    path = WHOLE / 'confirmation-r0-candidate-startup.stdout'
    startup_report = load(path)
    samples = namespace['observations'](startup_report, 'original', plan['startup'], 'candidate', lock)
    namespace['statistics_row']([namespace['score'](sample, 'original') for sample in samples])
    consumer_rows.append(dict(path=str(path.relative_to(ROOT)), sha256=digest(path),
                              boundary='original', file=plan['startup']['file'],
                              schema=startup_report['schema'], root_keys=sorted(startup_report),
                              observation_keys=sorted(samples[0]), measured=21, checked_warmups=10))

    # Check the optional reference's accessed fields using saved Node output.
    node_rows = []
    for case in plan['execution']:
        path = WHOLE / f'confirmation-r0-candidate-v8-{case["file"]}.stdout'
        report = load(path)
        assert report['schema'] == 'scriptw-v8-baseline-v2'
        assert report['samples'] == 21 and report['warmups'] == 10
        assert report['node'] and report['v8'] and len(report['cases']) == 1
        actual = report['cases'][0]
        assert actual['file'] == case['file'] and actual['source_sha256'] == lock['source_hashes'][case['file']]
        assert len(actual['observations']) == 31
        assert all(value['warmup'] is (index < 10) and value['stdout'] == case['stdout']
                   for index, value in enumerate(actual['observations']))
        node_rows.append(dict(path=str(path.relative_to(ROOT)), sha256=digest(path),
                              root_keys=sorted(report), case_keys=sorted(actual)))

    rejected = []
    altered = copy.deepcopy(retained)
    altered['cases'][0]['shared_configuration']['gc_initial_bytes'] += 1
    try:
        namespace['producer_header'](altered, 'candidate', 'retained-canonical',
                                     lock, plan['execution'], retained['manifest_sha256'])
    except ValueError:
        rejected.append('per-image retained configuration differs despite matching aggregate')
    else:
        raise AssertionError('retained per-image mismatch accepted')
    for boundary, mutation in [
        ('original', lambda report: report.update(runtime_key='incorrect-runtime-key')),
        ('retained', lambda report: report.update(initialization_count=2)),
        ('ordinary', lambda report: report['cases'][0].update(source_sha256='incorrect-source')),
    ]:
        case = plan['execution'][0]
        path = WHOLE / f'confirmation-r0-candidate-{boundary}-{case["file"]}.stdout'
        altered = load(path)
        mutation(altered)
        try:
            namespace['observations'](altered, boundary, case, 'candidate', lock)
        except ValueError:
            rejected.append(boundary + ' identity/runtime/lifetime mismatch')
        else:
            raise AssertionError('altered consumer record accepted: ' + boundary)
    receipt = dict(schema='scriptw-date-demand-saved-record-audit-v1',
                   status='passed inert saved-record audit; no native or Node execution',
                   driver_sha256=digest(driver), producer_records=records,
                   retained_exact_wrappers_and_sidecars_checked=17,
                   consumer_records=consumer_rows, saved_node_records=node_rows,
                   optional_retained_aggregate_configuration='accepted only with exact per-image configuration',
                   negative_inert_checks=rejected,
                   new_date_golden_verification='pending; historical records validate schema only',
                   scope='Existing local WHOLE JSON and small source/sidecar files only; no native products/images read or hashed; no fresh preparation.')
    assert Path(receipt_name).name == receipt_name and receipt_name.endswith('.json')
    with (OUT / receipt_name).open('x') as stream:
        stream.write(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(dict(status=receipt['status'], receipt=receipt_name, consumers=len(consumer_rows),
                          saved_node_records=len(node_rows), retained_wrappers=17)))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', default='saved-record-audit.json')
    main(parser.parse_args().output)
