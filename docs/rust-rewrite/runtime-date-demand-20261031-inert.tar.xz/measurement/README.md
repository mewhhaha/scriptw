# Date demand measurement preparation

Source only. No native product, native image, Node process, build or test has
been run for this preparation. The three new expected outputs are derived from
fixed metadata and UTC calendar arithmetic; independent Node and native
verification remain pending. No measured benefit is claimed. The unexecuted repeated control was revised to513 public Date value reads; control-revision-public-date-reads.json records the exact before/after source and unchanged goldens.

cohort.py reuses the established cohort structure, benchmark_metrics.measure_process,
the resource wrapper, and the two existing native measurement examples. It does
not change tracked sources, compiler options, GC/stack limits or native features.
The source inventory and outputs live in sources/manifest.json;
source-hashes.json binds all 22 input files, including the manifest.
golden-derivation.json records the new expected values and their derivation.

The isolated Python validators have also been audited against existing inert
WHOLE records; no native or Node process was started. The current proof is
saved-record-audit-v2.json, bound to the repaired driver hash. It covers 52 saved
native consumer records (all 17 canonical cases at all 3 boundaries plus original
startup), 17 exact retained source wrappers and consumer sidecars, and 17 saved
Node reports. This proves record compatibility; the new Date goldens still await
fresh verification.

## Products and admission

Baseline is the frozen local accepted WHOLE product directory
target/performance-whole-trip-affine-20261031/candidate, source fingerprint
c0984be5554f5db7849e3af64c472c3a846c7c11cc035663176b078bb5816464.
Its embedded source commit is e15843397c217c0e113c50e2164c0d1fa5552112;
DATE's existing baseline-reuse-proof.json binds that production fingerprint to
accepted affine checkpoint 7c47e38274c9645b6701552c87d38362b2bfbcd5.
The expected baseline runtime contract is ABI41.

Candidate must be frozen under target/performance-date-demand-20261031/candidate
by the existing build-candidate.py after the parent's semantic checks. The
future exact candidate fingerprint is a required bind argument. Its expected
runtime contract is ABI42. The ABI labels describe the reviewed source contracts;
the driver does not infer an ABI number from an opaque runtime-key hash.

bind checks actual product bytes, sizes, own identity and metadata, shared
configuration equality, canonical nonsymlink paths and independent file ownership.
It writes an exclusive product lock. Large native product hashing is deferred
until that explicit command. All images are freshly prepared from this directory's
own source copies using each side's own frozen producer. Each matching consumer
admits its own image/runtime key. ABI41 images are never offered to ABI42, or the
reverse. No archived native images are loaded and no products are linked or copied
by this driver.

For retained production, each case and its exact per-image consumer sidecar must
carry the matching schema, source/build identity, configuration, manifest,
source provenance and image/runtime digests. The aggregate producer may omit
redundant shared_configuration decoration; the case/sidecar authority remains
mandatory. The existing WHOLE aggregate currently contains that decoration.

## Cases and actual boundaries

The canonical 17 execution sources, including integer.js, objects.js and
retained-objects.js, and the startup source/expected output are byte-for-byte
copies of the existing hotpath fixtures. They remain the original-source gate.
Three additional controls keep Date work visible when startup work moves:

| Source | Work and golden result |
| --- | --- |
| date-first-descriptor.js | First value observation through Object.getOwnPropertyDescriptor(globalThis,"Date"); complete constructor/prototype metadata, flags and UTC/GMT function identity. Output Date, 7, true:false:true, true, true, on separate lines. No Date instance. |
| date-first-epoch.js | Explicit new Date(0) and numeric Date.UTC(2004,1,29,12,34,56,789); expected time values 0 and 1078058096789, epoch UTC string, and the seven leap-day UTC components. |
| date-repeated-256.js | 256 numeric UTC constructions, seven UTC field reads per instance and final epoch UTC string;513 public Date reads use Date.UTC/new Date on every iteration plus final new Date(0), without a cached constructor alias. Expected component sum 569762. All days are 1..28; no calendar overflow, parsing or local-zone work. |

Every source runs through all three actual boundaries, reported independently:

- **original**: execute-scriptw, compiler-free execution of the fresh original
  image; a new Store/Realm for every checked warmup and measured observation.
  Date sources include actual first value demand in that fresh Realm.
- **ordinary**: unchanged default runtime_baseline invocation; original script,
  current ordinary engine/native policy and a fresh runtime invocation per
  observation. No row-phase observer or explicit policy override.
- **retained**: execute-retained, the existing strict module adapter
  export function run() { ORIGINAL_SOURCE }, one retained Store/Realm/export.
  The first checked warmup pays first Date demand. All 21 measured calls occur
  after 10 checked warmups and exercise Ready state. They are never reported as
  first-use measurements, even for a source with "first" in its filename.

The reusable retained producer requires exactly 17 manifest entries. Preparation
therefore keeps the canonical 17 retained manifest intact and creates a second
17-entry manifest containing the three Date sources, startup and 13 unchanged
canonical fillers. Only the four new entries are measured from that second
manifest; its filler images are preparation-only duplicates. This satisfies the
existing tool contract without modifying its fixed inventory guard.

The repeated control includes one first demand at fresh boundaries plus 256 uses;
it does not isolate the ensure-helper's cost. No timing subtraction across
boundaries is valid. None of the fixed-output controls calls Date.now(), bare
Date(), a no-argument constructor, a parser or a local-zone method.

## Deferred commands

Run these only after the parent has frozen the candidate and finished all other
native jobs. From repository root, use the resource wrapper for each invocation:

    python3 -B scripts/limited_verification.py --cloud -- python3 -B target/performance-date-demand-20261031/measurement/cohort.py bind --candidate-fingerprint EXACT_DATE_FINGERPRINT
    python3 -B scripts/limited_verification.py --cloud -- python3 -B target/performance-date-demand-20261031/measurement/cohort.py prepare baseline
    python3 -B scripts/limited_verification.py --cloud -- python3 -B target/performance-date-demand-20261031/measurement/cohort.py prepare candidate
    python3 -B scripts/limited_verification.py --cloud -- python3 -B target/performance-date-demand-20261031/measurement/cohort.py verify-node reference
    python3 -B scripts/limited_verification.py --cloud -- python3 -B target/performance-date-demand-20261031/measurement/cohort.py measure balanced --order eight

Node verification is optional, separate from native timing, and records exact
Node/V8 and harness/source identities. It is not a conformance or chart refresh.
The combined native order is ABBA then BAAB:
WHOLE, DATE, DATE, WHOLE, DATE, WHOLE, WHOLE, DATE.
Separate uniquely named --order ABBA and --order BAAB groups are also supported.
Every child uses 21 measured observations and 10 checked warmups. Case order
reverses on alternate rounds. Concurrent native jobs invalidate the intended
comparison; this driver supplies no global job scheduler.

Raw stdout, stderr, argv, executable identity, child process RSS/CPU/wall
accounting and before/after cgroup/affinity/cache policy snapshots are retained.
OOM deltas, changing resource policies, different sources/products, incomplete
counts and unexpected output fail the cohort. Receipts and output directories
are created exclusively; failed runs are preserved rather than overwritten.

Analysis retains all measured samples, means, medians, per-round and per-balanced
group results for each boundary; original post-execution RSS samples and process
peaks remain separate. It checks exact labels, source/image provenance,
producer/consumer identities, raw argv, runtime policies, warmup order and resource
receipts before writing a summary. analyze PREFIX --order eight can reconstruct
an analysis only when its output path does not already exist.

These local controls cannot replace the unchanged original gate, semantic
acceptance, default/full suites or the published full-suite/chart identities.
The coordinated bounded Test262 selection is separate under
../next-test262-selection.

The bounded inert-record audit can be repeated under a fresh receipt name:

    python3 -B target/performance-date-demand-20261031/measurement/audit-saved-records.py --output saved-record-audit-review.json

This compiles only selected Python validation function definitions and feeds
existing JSON/source/sidecar files into them. It never imports the measurement
module, calls a native command or reads/hashes native products or images.
