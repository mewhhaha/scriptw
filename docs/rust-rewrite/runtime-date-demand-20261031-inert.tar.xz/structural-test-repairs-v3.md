# Test-only structural repairs after frozen libraries-v2

The original AOT library run recorded 564 passes and seven failures. This owner repaired its malformed Date/Error probes, Date global publisher selection and the ordered aggregate owner inventory; Binary/Intl ordinal repairs belong to the schema agent. No production source changed here.

Three probes previously encoded only a CodeSection. wasmparser rejected their missing FunctionSection before their typed field/callable observations could run. The shared test-only encode_realm_probe now encodes the registered type section and a matching one-function Realm-to-void declaration, followed by the actual body; Wasm validation checks that complete scratch module. Error and Date state readers use it, and Binary/Intl can reuse the same test-local seam. The Date callable probe declares its matching function and actual Runtime-owned helper imports in registry order, then validates before decoding the body. No production schema API or snapshot export was added.

The Date marker check inspected RealmInitializeIntrinsics, which intentionally creates private intrinsics and does not publish globals. The check now inspects the actual host CreateRealm and ShadowRealm constructor bodies, each of which calls the global publisher and must contain exactly one Date recipe, exactly one matching ordinary data publication with flags 1/0/1, and no Date ensure call. Resolver/alias canonical-root assertions remain intact.

The ordered aggregate failed at its Symbol/nonwritable exercise assertion, as predicted from source. Adding RealmEnsureDate to both run-span and direct-install inventories follows the moved physical owner and restores its original Date rows and UTC/GMT direct install. All existing thresholds remain unchanged. The originally prepared patch is retained under ordered-bootstrap-repair/.

The three repaired files are frozen by structural-test-repairs-v3.json and copied under structural-test-repairs-v3/. Formatting and diff checks passed. No native build or test execution was performed by this owner after these repairs; the root owns the exact failed-filter rerun and retains unaffected v2 passing scopes separately.
