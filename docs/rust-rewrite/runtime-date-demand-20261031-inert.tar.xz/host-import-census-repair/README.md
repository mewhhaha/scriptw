# Host import authority census repair

The original runtime_link integration run passed 30 tests and failed the product-source census: HostImportFunctionIndices counted seven occurrences instead of five. Two came from the cfg(test)-owned Date scratch emitter probe (its import and constructor call). RejectRuntimeSemanticsImportFunctionIndex likewise gained two test-only references; none of the 26 optional role types changed.

The repair keeps all existing product role/authority expectations at five. The recursive lexer inventory now skips only src/tests.rs and its src/tests/ subtree. Before permitting either exclusion, the test proves the actual src/lib.rs contains exactly one lexical tests identifier and exactly one direct #[cfg(test)] mod tests; declaration, then verifies that both resolved paths exist. This is an explicit module ownership boundary; other directories and inline test code retain the original census treatment. The retired-role absence checks use the same bounded product scope.

The original lexical tokenizer and all authority construction/storage/projection proofs remain intact. No production source or test-only production export changed. receipt.json enumerates the five production code references for both authority types and all 26 scalar roles and freezes the repaired integration source by digest. The formatted source copy is retained beside it.

Formatting and git diff checks passed. No native build or test ran for this repair; the root owns the exact previously failing filter rerun and preservation of all unrelated passing scopes.
