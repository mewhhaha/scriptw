"""Assemble complete Date evidence from inert records only; never run products."""
from pathlib import Path
import ast
import datetime
import hashlib
import json
import re
import statistics

ROOT = Path('/workspace/scriptw')
OUT = Path(__file__).resolve().parent
PARENT = '7c47e38274c9645b6701552c87d38362b2bfbcd5'
BASELINE = 'c0984be5554f5db7849e3af64c472c3a846c7c11cc035663176b078bb5816464'
ORDER = ['baseline', 'candidate', 'candidate', 'baseline',
         'candidate', 'baseline', 'baseline', 'candidate']
DATE_FILES = ['date-first-descriptor.js', 'date-first-epoch.js', 'date-repeated-256.js']


def require(value, message):
    if not value:
        raise ValueError(message)


def inert(path, limit=16 * 1024**2):
    path = Path(path)
    require(path.is_file() and not path.is_symlink() and path.stat().st_size <= limit,
            'missing, nonregular or oversized inert input: ' + str(path))
    require(path.suffix in {'.json', '.jsonl', '.log', '.stdout', '.stderr', '.gz',
                           '.rs', '.md', '.py', '.patch', '.js', '.mjs', '.cjs', '.txt'},
            'inert metadata/source/log required: ' + str(path))
    return path


def read(name):
    path = Path(name)
    return json.loads(inert(path if path.is_absolute() else OUT / path).read_text())


def digest(path):
    # Native product/image files are never opened; identities come from receipts.
    return hashlib.sha256(inert(path).read_bytes()).hexdigest()


def origin(path, expected_sha256=None, archive=False):
    path = Path(path)
    if not path.is_absolute():
        path = ROOT / path
    require(path.is_relative_to(ROOT), 'raw origin outside workspace')
    actual = digest(path)
    require(expected_sha256 is None or actual == expected_sha256, 'raw origin digest differs: ' + str(path))
    archived = path
    if archive and not path.is_relative_to(OUT):
        archived = OUT / 'native-streams' / path.name
        archived.parent.mkdir(exist_ok=True)
        if archived.exists():
            require(digest(archived) == actual, 'archived raw stream differs')
        else:
            with archived.open('xb') as stream:
                stream.write(path.read_bytes())
    return dict(origin=str(path.relative_to(ROOT)), sha256=actual,
                archive_path=str(archived.relative_to(OUT)) if archived.is_relative_to(OUT) else None)


def native_case(directory, case):
    inventory = origin(case['inventory_log'], case['inventory_sha256'])
    inventory_text = (ROOT / inventory['origin']).read_text()
    names = re.findall(r'^(.+): test$', inventory_text, re.M)
    require(len(names) == len(set(names)) == case['inventoried_tests'] > 0,
            'native inventory differs: ' + directory)
    stream = origin(case['transcript_log'], case['transcript_sha256'], archive=True)
    text = (ROOT / stream['origin']).read_text()
    printed = re.findall(r'^test (.+) \.\.\. (ok|FAILED|ignored)$', text, re.M)
    # libtest annotates #[should_panic] execution labels, while --list emits the
    # canonical Rust test name without that suffix.
    actual = [(name.removesuffix(' - should panic'), status) for name, status in printed]
    require(len(actual) == len(names) and {name for name, _ in actual} == set(names),
            'native transcript does not cover its inventory: ' + directory)
    totals = dict(passed=sum(status == 'ok' for _, status in actual),
                  failed=sum(status == 'FAILED' for _, status in actual),
                  ignored=sum(status == 'ignored' for _, status in actual))
    require(case['outcomes'] == [totals] and totals['ignored'] == 0, 'native outcome differs')
    summaries = re.findall(r'^test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', text, re.M)
    require(summaries == [(str(totals['passed']), str(totals['failed']), '0')],
            'native summary differs')
    failed = totals['failed'] > 0
    require(case['build_exit'] == 0 and case['state'] == ('failed' if failed else 'passed') and
            case['exit_code'] == (101 if failed else 0) and case['inventory_matches'] is (not failed),
            'native completion/inventory state differs')
    for row in case['sealed_build_logs']:
        origin(row['path'], row['gzip_sha256'])
    keys = {(case['package'], case['target'], name): status for name, status in actual}
    return dict(receipt=directory + '/receipt.json', package=case['package'], target=case['target'],
                filter=case.get('native_filter'), outcomes=totals, inventory=inventory,
                failing_tests=[name for name, status in actual if status == 'FAILED'],
                transcript=stream, executable_sha256=case['executable_sha256'],
                executable_bytes=case['executable_bytes'],
                executable_released_by_driver=case['executable_released']), keys


def native_scope(directory, expected_source_map=None, retirement=False):
    receipt = read(directory + '/receipt.json')
    require(receipt['head'] == PARENT and receipt['source_unchanged'] is True and
            receipt['shared_runtime_linker_unchanged'] is True and receipt['profile'] == 'release' and
            receipt['all_features'] is False and receipt['include_ignored'] is False,
            'native source/features changed: ' + directory)
    source = read(directory + '/source-start.json')
    encoded = json.dumps(source, sort_keys=True).encode()
    require(hashlib.sha256(encoded).hexdigest() == receipt['source_map_sha256'], 'native source-map hash differs')
    require(expected_source_map is None or receipt['source_map_sha256'] == expected_source_map,
            'native continuation source differs')
    schedule = receipt['scheduling']
    require(schedule['test_processes'] == schedule['test_threads_per_process'] == schedule['cargo_jobs'] == 1,
            'native concurrency policy differs')
    rows, observed = [], {}
    for case in receipt['cases']:
        row, tests = native_case(directory, case)
        require(not (observed.keys() & tests.keys()), 'duplicate native case within scope')
        rows.append(row)
        observed.update(tests)
    lifecycle = None
    if retirement:
        lifecycle = read(directory + '/native-image-retirement.json')
        require(receipt['preserve_test_artifacts'] is True and
                len(receipt['cases']) == 1, 'incomplete exact-image retirement')
        case = receipt['cases'][0]
        selected = [row for row in lifecycle['records'] if row['selected']]
        require(len(selected) == 1 and selected[0]['sha256'] == case['executable_sha256'] and
                selected[0]['bytes'] == case['executable_bytes'], 'selected-image retirement identity differs')
        if case['state'] == 'failed':
            require(lifecycle['exit_code'] != 0 and
                    selected[0]['action'] == 'frozen failed executable outside Cargo' and
                    Path(selected[0]['frozen_path']).is_relative_to(OUT / 'failed-native'),
                    'failed selected image was not frozen by the native driver')
        else:
            require(lifecycle['exit_code'] == 0 and
                    selected[0]['action'] == 'retired exact passing image after complete source-bound transcript',
                    'passing selected image retirement differs')
    return dict(receipt=directory + '/receipt.json', source_map_sha256=receipt['source_map_sha256'],
                source_start=source, cases=rows, scheduling=schedule, retirement=lifecycle), observed


def source_and_native():
    v2, v3, v4 = read('compiled-inputs-v2.json'), read('compiled-inputs-v3.json'), read('compiled-inputs-v4.json')
    proof = read('test-repair-reuse-proof.json')
    changed = {name for name in v3 if name not in v2 or v3[name] != v2[name]}
    require(set(v2) <= set(v3) and changed == set(proof['changed_only_test_owners']) and
            len(changed) == 5 and proof['production_unchanged'] is True,
            'test-only continuation proof differs')
    for name in changed:
        require(name.startswith('crates/scriptw-aot-wasm/src/tests/'), 'production input changed in continuation')
    final_changes = {name for name in v4 if name not in v3 or v4[name] != v3[name]}
    require(set(v3) <= set(v4) and len(final_changes) == 1 and
            all(name.startswith('crates/scriptw-aot-wasm/tests/runtime_link/') for name in final_changes),
            'runtime-link continuation changed production or more than one test owner')
    for version, manifest in [('v2', v2), ('v3', v3), ('v4', v4)]:
        for name, record in manifest.items():
            path = OUT / ('implementation-' + version) / name
            require(not Path(name).is_absolute() and '..' not in Path(name).parts and
                    path.stat().st_size == record['bytes'] and digest(path) == record['sha256'],
                    'frozen source snapshot differs: ' + name)
    layout_path = 'crates/scriptw-aot-wasm/src/runtime_artifact.rs'
    require(v2[layout_path] == v3[layout_path] and re.search(
        r'const\s+LAYOUT_VERSION\s*:\s*u32\s*=\s*42\s*;',
        (OUT / 'implementation-v3' / layout_path).read_text()), 'ABI42 source assertion absent')
    initial, selected = native_scope('native-date-libraries-v2')
    require(len(initial['cases']) == 2 and len(selected) == 605 and
            sum(status == 'ok' for status in selected.values()) == 598 and
            sum(status == 'FAILED' for status in selected.values()) == 7,
            'initial564 AOT +34 embedding /7 failures differ')
    aot = next(row for row in initial['cases'] if row['package'] == 'scriptw-aot-wasm')
    embedding = next(row for row in initial['cases'] if row['package'] == 'scriptw-engine')
    require(aot['outcomes'] == dict(passed=564, failed=7, ignored=0) and
            embedding['outcomes'] == dict(passed=34, failed=0, ignored=0), 'initial scopes differ')
    repair_summary = read('native-repair-summary.json')
    require(repair_summary['complete'] is True and repair_summary['all_passed'] is True and
            [row['label'] for row in repair_summary['scopes']] ==
            ['native-date-demand-repair', 'native-date-ordered-repair'], 'native continuation incomplete')
    continuations, final, source_map = [], dict(selected), None
    for directory, count in [('native-date-demand-repair', 12), ('native-date-ordered-repair', 1)]:
        scope, tests = native_scope(directory, source_map, retirement=True)
        source_map = scope['source_map_sha256']
        require(len(tests) == count and set(tests) <= set(selected) and set(tests.values()) == {'ok'},
                'continuation is not exact existing passing inventory')
        final.update(tests)
        continuations.append(scope)
    require(len(final) == 605 and set(final.values()) == {'ok'}, 'seven initial failures were not all resolved')
    layout_test = ('scriptw-aot-wasm', 'scriptw_aot_wasm',
                   'gc_types::type_registration_tests::compact_records::date_recipe_and_realm_fit_the_actual_copying_collector_records')
    require(final.get(layout_test) == 'ok', 'actual copying-collector Date layout assertion did not pass')
    layout_source = OUT / 'implementation-v3/crates/scriptw-aot-wasm/src/gc_types/type_registration_tests/compact_records.rs'
    require('assert_eq!(recipe.size, 32);' in layout_source.read_text() and
            'assert_eq!(realm.size, 96);' in layout_source.read_text(),
            'recorded Date allocation sizes differ from the source-bound passing assertion')
    limits = read('native-evidence-limits.json')
    require(limits['original_executable_sha256'] == aot['executable_sha256'] and
            limits['original_executable_bytes'] == aot['executable_bytes'] and
            aot['executable_released_by_driver'] is True, 'initial native evidence limitation differs')
    integration_plan = read('verification-plan.json')['native_integrations']
    integration_summary = read('native-integrations-final-summary.json')
    require(integration_summary['complete'] is True and integration_summary['all_passed'] is True and
            len(integration_summary['scopes']) == len(integration_plan['targets']) == 10,
            'affected native integration coverage incomplete')
    require({row['target'] for row in integration_summary['scopes']} == set(integration_plan['targets']),
            'final integration union does not cover all ten targets')
    claimed_scopes = {row['target']: row for row in integration_summary['scopes']}
    integrations, integration_tests = [], {}
    runtime_repair, runtime_repair_tests = native_scope('native-date-runtime-link-repair', retirement=True)
    require(len(runtime_repair_tests) == 1 and set(runtime_repair_tests.values()) == {'ok'} and
            runtime_repair['cases'][0]['package'] == 'scriptw-aot-wasm' and
            runtime_repair['cases'][0]['target'] == 'runtime_link' and
            runtime_repair['cases'][0]['filter'] == next(iter(runtime_repair_tests))[2],
            'exact runtime-link census continuation incomplete')
    final_map = runtime_repair['source_map_sha256']
    for index, target in enumerate(integration_plan['targets']):
        directory = f'native-date-integration-{index:02d}'
        scope, tests = native_scope(directory, source_map if index < 2 else final_map, retirement=True)
        require(len(scope['cases']) == 1 and
                scope['cases'][0]['package'] + ':' + scope['cases'][0]['target'] == target and
                scope['cases'][0]['filter'] == integration_plan['filters'].get(target) and
                not (integration_tests.keys() & tests.keys()),
                'integration receipt scope differs')
        claimed = claimed_scopes[target]
        require(claimed['receipt'] == directory + '/receipt.json' and
                claimed['filter'] == integration_plan['filters'].get(target) and
                claimed['observed'] == scope['cases'][0]['outcomes'],
                'final integration summary differs from the original receipt')
        if index == 1:
            failed = {key for key, status in tests.items() if status == 'FAILED'}
            require(scope['cases'][0]['outcomes'] == dict(passed=30, failed=1, ignored=0) and
                    failed == set(runtime_repair_tests), 'runtime-link failure/continuation union differs')
            tests.update(runtime_repair_tests)
            scope['continuation'] = runtime_repair
            require(claimed['continuation'] == 'native-date-runtime-link-repair/receipt.json' and
                    claimed['resolved_failures'] == 1, 'runtime-link summary continuation differs')
        require(set(tests.values()) == {'ok'}, 'unresolved integration failure')
        require(claimed['unique_passed'] == len(tests), 'integration summary unique count differs')
        integrations.append(scope)
        integration_tests.update(tests)
    require(integration_summary['unique_passed'] == len(integration_tests) == 707 and
            integration_summary['library_embedding_unique_passed'] == len(final) == 605 and
            integration_summary['total_distinct'] == len(final) + len(integration_tests) == 1312,
            'final native union totals differ from the actual inventories')
    historical = {name: read(name) for name in integration_summary['historical_summaries']}
    return dict(frozen_production_snapshot='compiled-inputs-v2.json', final_test_snapshot='compiled-inputs-v4.json',
                inputs=v4, test_only_reuse_proof=proof,
                runtime_link_test_only_change=sorted(final_changes), initial=initial, continuations=continuations,
                unique_library_embedding_passes=605, initial_passes=598, initial_failures=7,
                continuation_executions=13, continuation_new_inventory_cases=0,
                actual_collector_layout=dict(test=layout_test[2], result='passed', date_recipe_bytes=32,
                                             realm_bytes=96, abi_before=41, abi_after=42),
                original_failed_executable_not_retained=True, native_evidence_limits=limits,
                integrations=integrations, integration_union_proof=integration_summary,
                integration_unique_passes=len(integration_tests),
                total_distinct_native_passes=len(final) + len(integration_tests),
                historical_integration_summaries=historical, cache_relocation=read('cache-relocation.json'),
                integration_scope_note='All ten planned scopes completed; filters remain explicit and are not full-target claims.')


def product_metadata():
    identities = {label: read('baseline-identity.json' if label == 'baseline' else 'candidate/identity.json')
                  for label in ['baseline', 'candidate']}
    products = {label: read('baseline-products.json' if label == 'baseline' else 'candidate/products.json')
                for label in identities}
    require(identities['baseline']['source_fingerprint'] == BASELINE and
            identities['candidate']['source_fingerprint'] != BASELINE and
            identities['candidate']['source_commit'] == PARENT, 'candidate/baseline source differs')
    for label, identity in identities.items():
        require(set(products[label]) == {'scriptw', 'runtime_baseline', 'compiler_precompiled_baseline'} and
                products[label]['compiler_precompiled_baseline']['sha256'] == identity['executable_sha256'] and
                identity['shared_configuration'] == identities['baseline']['shared_configuration'],
                'frozen product metadata differs')
    build, reuse = read('candidate-build.json'), read('baseline-reuse-proof.json')
    require(build['exit_code'] == 0 and build['head'] == PARENT and
            reuse['accepted_commit'] == PARENT and reuse['original_identity'] == identities['baseline'] and
            reuse['baseline_products'] == products['baseline'], 'build or baseline reuse proof differs')
    return dict(identities=identities, products=products, candidate_build=build, accepted_baseline_reuse_proof=reuse)


def test262_evidence(products):
    plan, summary = read('test262-plan.json'), read('test262-candidate-summary.json')
    entries = {row['path']: row for row in plan['files']}
    require(len(entries) == plan['original_count'] == 53 and len(summary['runs']) == 53,
            'original Test262 selection incomplete')
    actual, variants, origins = set(), 0, []
    for row in summary['runs']:
        name = row['scope']
        require(name in entries and name not in actual and row['product'] == 'candidate' and
                row['exit_code'] == 0 and row['total'] == row['passed'] > 0 and
                row['executable_sha256'] == products['products']['candidate']['scriptw']['sha256'],
                'Test262 run incomplete, duplicated or wrong product')
        actual.add(name)
        variants += row['passed']
        path = ROOT / 'test262/vendor/test262/test' / name
        require(path.stat().st_size == entries[name]['bytes'] and digest(path) == entries[name]['sha256'],
                'original Test262 source changed')
        argv = row['argv']
        require(argv[argv.index('run') + 1] == name and
                argv[0] == str(OUT / 'candidate/scriptw') and '--execution-backend' in argv and
                argv[argv.index('--execution-backend') + 1] == 'wasm-aot',
                'Test262 argv differs')
        require(Path(row['raw']).name == row['raw'], 'unsafe Test262 raw path')
        text = inert(OUT / row['raw']).read_text()
        require(re.findall(r'^total: (\d+)$', text, re.M) == [str(row['total'])] and
                re.findall(r'^passed: (\d+)$', text, re.M) == [str(row['passed'])],
                'Test262 raw totals differ')
        origins.append(origin(OUT / row['raw']))
    require(actual == set(entries), 'Test262 original-file coverage differs')
    return dict(original_files=53, actual_passing_variants=variants, plan=plan, summary=summary, raw_origins=origins,
                scope='Four named complete small directories plus explicit subsets; no full Date/calendar/parser/Object/Reflect/Test262 or publication claim.')


def measurement_evidence(products):
    directory = OUT / 'measurement'
    lock = read(directory / 'product-lock.json')
    hashes, plan = read(directory / 'source-hashes.json'), read(directory / 'sources/manifest.json')
    canonical = ROOT / 'crates/scriptw-cli/tests/fixtures/v8_execution_hotpaths'
    canonical_plan = read(canonical / 'manifest.json')
    cases = [*plan['execution'], plan['startup']]
    require(len(cases) == len({case['file'] for case in cases}) == 21 and
            [case['file'] for case in plan['execution'][17:]] == DATE_FILES and lock['source_hashes'] == hashes,
            'measurement21 source inventory differs')
    require(plan['execution'][:17] == canonical_plan['execution'] and
            plan['startup'] == canonical_plan['startup'], 'canonical source gate changed')
    for case in [*canonical_plan['execution'], canonical_plan['startup']]:
        require(digest(directory / 'sources' / case['file']) == digest(canonical / case['file']),
                'canonical source copy changed: ' + case['file'])
    for name, sha in hashes.items():
        require(Path(name).name == name and digest(directory / 'sources' / name) == sha, 'measurement source changed')
    for name, sha in lock['support'].items():
        require(digest(ROOT / name) == sha, 'bound measurement validator/support changed')
    for label in ['baseline', 'candidate']:
        require(lock[label]['identity'] == products['identities'][label] and
                lock[label]['expected_runtime_abi'] == (41 if label == 'baseline' else 42), 'measurement product identity differs')
        for tool in ['compiler_precompiled_baseline', 'runtime_baseline']:
            require(lock[label]['products'][tool]['sha256'] == products['products'][label][tool]['sha256'] and
                    lock[label]['products'][tool]['bytes'] == products['products'][label][tool]['bytes'],
                    'measurement product metadata differs')
    # Reuse the measured driver's exact pure validators; never call its product
    # checks, native-image loader, prepare, invoke, measure or main functions.
    selected = {'require', 'check_report_identity', 'statistics_row', 'retained_wrapper', 'producer_header',
                'image_group', 'image_directory', 'arguments', 'observations', 'score',
                'boundary_scope', 'policy_key', 'analyze'}
    tree = ast.parse((directory / 'cohort.py').read_text())
    definitions = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name in selected]
    require({node.name for node in definitions} == selected, 'measurement pure-validator interface changed')
    captured, producers = {}, {}
    namespace = dict(OUT=directory, ROOT=ROOT, Path=Path, statistics=statistics,
                     DATE_FILES=DATE_FILES, BOUNDARIES=['original', 'retained', 'ordinary'], SAMPLES=21, WARMUPS=10,
                     load=read, digest=digest, inputs=lambda: (plan, cases, hashes),
                     save=lambda path, value: captured.update({Path(path).name: value}))
    exec(compile(ast.Module(body=definitions, type_ignores=[]), str(directory / 'cohort.py'), 'exec'), namespace)
    groups = dict(original=cases, **{'retained-canonical': plan['execution'][:17],
                                   'retained-date': [*plan['execution'][17:], plan['startup'], *plan['execution'][4:17]]})
    for label in ['baseline', 'candidate']:
        for group, expected in groups.items():
            folder = directory / f'images-{label}-{group}'
            report = read(folder / 'producer.json')
            namespace['producer_header'](report, label, group, lock, expected,
                                         digest(directory / ('prepared-' + group) / 'manifest.json'))
            for case in report['cases']:
                if group.startswith('retained-'):
                    require(read(folder / Path(case['image']).with_suffix('.json')) == case,
                            'retained sidecar differs')
                    original, derived = folder / case['original_source_file'], folder / case['derived_source_file']
                    require(digest(original) == case['original_source_sha256'] and
                            digest(derived) == case['derived_source_sha256'] and
                            derived.read_text() == namespace['retained_wrapper'](original.read_text()),
                            'retained exact wrapper/provenance differs')
            producers[label, group] = report
    namespace['producer'] = lambda label, group, bound: producers[label, group]
    namespace['analyze']('balanced', ORDER, lock)
    analysis = read(directory / 'balanced-analysis.json')
    require(captured == {'balanced-analysis.json': analysis}, 'saved analysis differs from strict raw reassembly')
    substrate = read(directory / 'balanced-substrate.json')
    require(substrate['cohort'] == 'balanced' and substrate['filesystem'] == 'tmpfs:1021994' and
            substrate['cache_root'] == '/tmp/scriptw-date-demand-20261031-cache',
            'initial full-cohort substrate annotation differs')
    backing = substrate['runtime_source']
    require(digest(ROOT / backing['path']) == backing['sha256'], 'native backing source differs from diagnosis')
    # Archive the unchanged backing owner as source data, never its native image.
    backing_copy = OUT / 'backing-source/native_backing.rs'
    backing_copy.parent.mkdir(exist_ok=True)
    if backing_copy.exists():
        require(digest(backing_copy) == backing['sha256'], 'backing source copy differs')
    else:
        with backing_copy.open('xb') as stream:
            stream.write((ROOT / backing['path']).read_bytes())

    prefix = 'controls-normal'
    normal_plan = read(directory / (prefix + '-plan.json'))
    completion = read(directory / (prefix + '-complete.json'))
    normal_analysis = read(directory / (prefix + '-analysis.json'))
    wanted = {'startup.js', 'date-first-epoch.js', 'date-repeated-256.js', 'sort-reverse-512.js',
              'sort-sorted-512.js', 'join-singleton-1024.js', 'join-4096.js', 'folded-string-4096.js'}
    selected_cases = [case for case in cases if case['file'] in wanted]
    selected_names = [case['file'] for case in selected_cases]
    wrapper_sha = digest(OUT / 'targeted-normal-controls.py')
    cache = normal_plan['cache_policy_before']
    require(len(selected_cases) == 8 and normal_plan['selected_cases'] == selected_names and
            normal_analysis['selected_cases'] == selected_names and completion['cases'] == selected_names and
            cache == completion['cache_policy_after'] == normal_analysis['cache_policy_before'] ==
            normal_analysis['cache_policy_after'] and
            cache == dict(path=str(OUT / 'normal-cache'), filesystem='overlayfs:794c7630',
                          environment_cache_root=str(OUT / 'normal-cache')) and
            normal_plan['followup_driver_sha256'] == completion['followup_driver_sha256'] ==
            normal_analysis['followup_driver_sha256'] == wrapper_sha,
            'normal follow-up selected sources, wrapper or cache filesystem policy differs')
    namespace['inputs'] = lambda: (plan, selected_cases, hashes)
    normal_captured = {}

    def capture_normal(path, value):
        require(Path(path).name == prefix + '-analysis.json', 'unexpected follow-up analysis output')
        # These are the wrapper's annotation additions; all numeric/statistical
        # fields come from the original pure analyzer over the selected8 inputs.
        value.update(scope='Eight predeclared unchanged sources only; normaldisk-backedoverlaycache; all3boundaries separate; nopoolingwithinitialtmpfscohort, nofull17normalqualification or universalRSSclaim.',
                     cache_policy_before=cache, cache_policy_after=completion['cache_policy_after'],
                     selected_cases=selected_names, followup_driver_sha256=wrapper_sha)
        normal_captured[Path(path).name] = value

    namespace['save'] = capture_normal
    namespace['analyze'](prefix, ORDER, lock)
    require(normal_captured == {prefix + '-analysis.json': normal_analysis},
            'normal follow-up analysis differs from independent selected-case raw reconstruction')
    node = node_evidence(directory, cases, hashes, namespace)
    return dict(directory='measurement', product_lock=lock,
                initial_tmpfs=dict(analysis_file='measurement/balanced-analysis.json',
                                   analysis_sha256=digest(directory / 'balanced-analysis.json'), analysis=analysis,
                                   substrate=substrate, raw_children=504,
                                   scope='Original complete21-case/all3-boundary/eight-round controlled cohort; tmpfs anonymous native-admission fallback; retained intact, not normal disk-backed memory qualification.'),
                normal_overlay_followup=dict(analysis_file='measurement/controls-normal-analysis.json',
                                             analysis_sha256=digest(directory / 'controls-normal-analysis.json'),
                                             plan=normal_plan, completion=completion, analysis=normal_analysis,
                                             raw_children=192, followup_driver_sha256=wrapper_sha,
                                             scope='Exactly eight predeclared sources/all3 boundaries/eight rounds; all samples/groups/means/medians/RSS independently reconstructed; no full17 normal-substrate qualification.'),
                independent_node_reference=node,
                raw_validation='Original pure analyzer reconstructed504+192 native children separately; no product/image reads or timing commands.',
                scope='Two separate substrate scopes with no pooling or boundary subtraction. All slower samples and original RSS remain. Fresh Date first demand and retained Ready calls remain distinct; no memory-benefit claim.')


def node_evidence(directory, cases, hashes, validators):
    reference = read(directory / 'reference-node-verification.json')
    require(reference['status'] == 'Independently verified' and
            reference['cases'] == [case['file'] for case in cases] and reference['source_hashes'] == hashes and
            reference['samples'] == 21 and reference['warmups_checked'] == 10,
            'independent Node reference scope differs')
    harness = ROOT / 'crates/scriptw-cli/tests/fixtures/v8_baseline/node-runtime.cjs'
    require(reference['harness_sha256'] == digest(harness), 'Node reference harness changed')
    raw = []
    for case in cases:
        stem = 'reference-node-' + case['file']
        report, command = read(directory / (stem + '.stdout')), read(directory / (stem + '.command.json'))
        require(command['argv'] == [reference['node'], str(harness), str(directory / 'prepared-original'),
                                    '21', '10', case['file']] and command['exit_code'] == 0 and
                command['timed_out'] is False and command['cwd'] == str(ROOT) and
                command['executable_sha256'] == reference['executable_sha256'] and
                command['resource_policy_unchanged'] is True and
                all(delta == 0 for delta in command['oom_event_delta'].values()) and
                validators['policy_key'](command['resources_before']) ==
                validators['policy_key'](command['resources_after']),
                'Node reference raw command/resources differ')
        require(report['schema'] == 'scriptw-v8-baseline-v2' and report['samples'] == 21 and
                report['warmups'] == 10 and len(report['cases']) == 1 and
                dict(node=report['node'], v8=report['v8']) == reference['versions'],
                'Node reference identity/counts differ')
        actual = report['cases'][0]
        require(actual['file'] == case['file'] and actual['source_sha256'] == hashes[case['file']] and
                len(actual['observations']) == 31 and all(
                    value['warmup'] is (index < 10) and value['stdout'] == case['stdout']
                    for index, value in enumerate(actual['observations'])), 'Node reference outputs differ')
        raw.extend(origin(directory / (stem + suffix)) for suffix in ['.stdout', '.stderr', '.command.json'])
    return dict(verification=reference, raw_origins=raw,
                scope='All21 original source goldens in the existing fresh-context Node/V8 harness; independent output/reference scope, not Scriptw native-cache admission or normal-substrate performance qualification.')


def diagnostic_evidence(products):
    comparison = read('cache-admission-comparison.json')
    require(comparison['scored'] is False and comparison['source_fingerprint'] == BASELINE and
            [row['label'] for row in comparison['rows']] == ['tmpfs', 'normal'], 'admission diagnostic scope differs')
    producer = read('measurement/images-baseline-original/producer.json')
    image = next(row for row in producer['cases'] if row['file'] == 'integer.js')
    identity = products['identities']['baseline']
    host = products['products']['baseline']['compiler_precompiled_baseline']['sha256']
    originals = []
    for row in comparison['rows']:
        label = row['label']
        stem = 'cache-admission-v2-' + label
        command, report = read(stem + '.command.json'), read(stem + '.stdout')
        require(command == row['command'] and command['exit_code'] == 0 and not command['timed_out'] and
                command['scored'] is False and command['executable_sha256'] == host and
                command['argv'][1:] == ['execute-scriptw',
                    str(OUT / 'measurement/images-baseline-original/integer.js.swpc'), '730532261\n', '3', '1'] and
                command['cache_filesystem'] == ('tmpfs:1021994' if label == 'tmpfs' else 'overlayfs:794c7630'),
                'admission diagnostic command differs')
        require(report['schema'] == 'scriptw-precompiled-execution-v1' and report['compiler_enabled'] is False and
                report['source_fingerprint'] == identity['source_fingerprint'] and
                report['source_commit'] == identity['source_commit'] and report['executable_sha256'] == host and
                report['shared_configuration'] == identity['shared_configuration'] and
                all(report[key] == image[key] for key in ['image_sha256', 'program_wasm_sha256', 'runtime_key']) and
                report['samples'] == 3 and report['warmups'] == 1 and len(report['observations']) == 4 and all(
                    value['warmup'] is (index == 0) and value['completion'] == 'normal' and
                    value['matched'] is True and value['stdout'] == '730532261\n' and value['stderr'] == ''
                    for index, value in enumerate(report['observations'])),
                'same-baseline/image admission diagnostic differs')
        require(row['process_snapshots'] == report['process_snapshots'] and
                row['load_process_memory'] == report['native_load_process_memory'] and
                row['first_observation'] == report['observations'][0]['process_snapshots'],
                'admission phase/memory comparison differs from raw endpoints')
        originals.extend(origin(OUT / (stem + suffix)) for suffix in ['.stdout', '.stderr', '.command.json'])
    rejected = read('cache-admission-tmpfs.command.json')
    require(rejected['exit_code'] != 0 and rejected['argv'][-2:] == ['3', '0'] and
            rejected['scored'] is False and (OUT / 'cache-admission-tmpfs.stdout').stat().st_size == 0 and
            'warmups 1..100' in (OUT / 'cache-admission-tmpfs.stderr').read_text(),
            'initial rejected zero-warmup diagnostic differs')
    originals.extend(origin(OUT / ('cache-admission-tmpfs' + suffix))
                     for suffix in ['.stdout', '.stderr', '.command.json'])
    size = read('runtime-code-size.json')
    require(size['schema'] == 'scriptw-inert-runtime-code-size-v1' and
            size['scored'] is False and size['native_execution'] is False, 'code-size evidence scope differs')
    code_origins = []
    require(set(size['products']) == {'baseline', 'candidate'}, 'actual code-size product inventory differs')
    for label, row in size['products'].items():
        symbols = read(row['raw_symbols'])
        artifact = next(case for case in read(f'measurement/images-{label}-original/producer.json')['cases']
                        if case['file'] == 'integer.js')
        require(row['host_sha256'] == products['products'][label]['compiler_precompiled_baseline']['sha256'] and
                row['source_fingerprint'] == products['identities'][label]['source_fingerprint'] and
                row['runtime_key'] == artifact['runtime_key'] and
                row['runtime_layout'] == (41 if label == 'baseline' else 42) and
                all(row[key] == symbols[key] for key in ['host', 'host_sha256', 'source_commit',
                                                       'source_fingerprint', 'runtime_key', 'runtime_layout',
                                                       'native_sha256', 'native_bytes']) and
                row['runtime_text_bytes'] == symbols['text']['bytes'], 'actual code-size product metadata differs')
        for helper, symbol in row['helpers'].items():
            if symbol is not None:
                require(symbol in symbols['functions'] and symbol['name'].endswith('::helper::' + helper),
                        'actual helper size differs from raw symbols')
        require(row['resolver'] == row['helpers']['property_value_resolve'], 'resolver size alias differs')
        code_origins.append(origin(OUT / row['raw_symbols']))
        code_origins.extend(origin(OUT / row['resolver_entry'][key]) for key in ['raw', 'stderr'])
    for key in ['native_bytes', 'runtime_text_bytes']:
        require(size['changes_bytes'][key] == size['products']['candidate'][key] -
                size['products']['baseline'][key], 'actual code-size delta differs')
    for helper, delta in size['helper_changes_bytes'].items():
        values = [size['products'][label]['helpers'][helper] for label in ['baseline', 'candidate']]
        require(delta == (values[1]['bytes'] if values[1] else 0) -
                (values[0]['bytes'] if values[0] else 0), 'actual helper-size delta differs')
    require(size['resolver_change_bytes'] == size['helper_changes_bytes']['property_value_resolve'],
            'resolver delta differs')
    return dict(cache_admission=dict(comparison=comparison, raw_origins=originals,
                                    rejected_zero_warmup_attempt=rejected,
                                    rejected_scope='Argument validation rejected warmups0 before admission; empty stdout and original error preserved.',
                                    scope='Unscored exact same-c098/same-image path comparison; native backing source and recorded before/after phase endpoints explain substrate sensitivity. No Date memory benefit or timing qualification.'),
                actual_code_size=dict(report=size, file='runtime-code-size.json', raw_origins=code_origins,
                                      scope='Actual own-frozen extraction/symbol/prologue metadata checked against inert records only; no ELF/product/image read, loading or execution. Static bytes do not establish executed-code/RSS/causal timing effects.'))


def main():
    # Fail before copying any transcript when required future inputs are missing.
    required = ['decision.json', 'candidate/identity.json', 'candidate/products.json', 'candidate-build.json',
                'compiled-inputs-v4.json', 'native-integrations-final-summary.json', 'test262-candidate-summary.json',
                'measurement/balanced-analysis.json', 'measurement/balanced-complete.json',
                'measurement/balanced-substrate.json', 'measurement/controls-normal-plan.json',
                'measurement/controls-normal-complete.json', 'measurement/controls-normal-analysis.json',
                'measurement/reference-node-verification.json', 'cache-admission-comparison.json',
                'runtime-code-size.json', 'post-build-documentation-proof.json']
    for name in required:
        inert(OUT / name)
    decision = read('decision.json')
    require(all(isinstance(decision.get(key), str) and decision[key].strip()
                for key in ['status', 'reviewer', 'basis', 'next']) and
            isinstance(decision.get('limits'), list) and decision['limits'] and
            all(isinstance(value, str) and value.strip() for value in decision['limits']),
            'explicit completed reviewer decision required')
    require('pending' not in decision['status'].lower(), 'review decision still pending')
    products = product_metadata()
    native = source_and_native()
    suite = test262_evidence(products)
    measurement = measurement_evidence(products)
    diagnostics = diagnostic_evidence(products)
    report = dict(schema='scriptw-date-demand-v1', complete=True,
                  recorded_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  status=decision['status'], decision=decision,
                  source=dict(parent_commit=PARENT, candidate_fingerprint=products['identities']['candidate']['source_fingerprint'],
                              **products, snapshots=['compiled-inputs-v2.json', 'compiled-inputs-v3.json', 'compiled-inputs-v4.json']),
                  change=dict(runtime_abi_before=41, runtime_abi_after=42, default_runtime_policy_changed=False,
                              behavior='Defining-Realm Date demand graph with Dormant/Building/Ready state, shared-undefined dormant slots, deferred global data value and independent public replacement; UTC/GMT aliases and private defining-Realm defaults preserved.',
                              allocation='The source-owned203-record/7312-byte method slice moves from startup to first demand. This gross slice is neither a complete net allocation census nor an RSS claim.',
                              collector_layout=native['actual_collector_layout']),
                  validation=dict(native=native, test262=suite),
                  measurement=measurement, diagnostics=diagnostics,
                  limits=['605 unique native library/embedding checks include the exact test-only continuation; no fresh all571 final-test-source AOT rerun is claimed.',
                          'The original failed AOT executable was retired by the default driver; its binary hash, inventory and complete source-bound transcript survive, not its native payload.',
                          'Affected integration filters, actual Test262 variants and all slower measured samples remain explicit.',
                          'Native identities are read from frozen receipts only; the assembler never reads, hashes or executes native products/images.',
                          'The complete21-case initial cohort used tmpfs-backed verification cache and anonymous native-admission fallback; its504 children remain separate from the192-child/eight-source normal-overlay follow-up. No pooling, full17 normal-substrate qualification or memory-benefit claim.',
                          'Date instance snapshot support, wall-clock/zone costs, full release acceptance and published full-suite/chart identities are unchanged.'])
    documentation = read('post-build-documentation-proof.json')
    require(documentation['all_54_non_markdown_inputs_unchanged'] is True and documentation['production_and_test_inputs_unchanged'] is True, 'post-build changes must remain documentation-only')
    report['post_build_documentation'] = documentation
    with (OUT / 'report-core.json').open('x') as stream:
        stream.write(json.dumps(report, indent=2) + '\n')
    print(json.dumps(dict(output='report-core.json', status=report['status'], native_unique=605,
                          integration_passes=native['integration_unique_passes'],
                          test262_actual_variants=suite['actual_passing_variants'], workload_rows=21), indent=2))


if __name__ == '__main__':
    main()
