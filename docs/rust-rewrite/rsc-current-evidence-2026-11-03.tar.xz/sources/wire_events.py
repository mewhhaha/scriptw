from pathlib import Path
import re,json
R=Path.cwd()

def edit(path,fn):
 p=R/path;s=p.read_text();n=fn(s)
 if n!=s:p.write_text(n)
def insert(path,anchor,text):
 def f(s):
  if text in s:return s
  assert anchor in s,(path,anchor)
  return s.replace(anchor,text+anchor,1)
 edit(path,f)
constructors=['AbortController','AbortSignal','EventTarget','Event','DOMException']
methods={
 'AbortController':[('PrototypeAbort','abort',0)],
 'AbortSignal':[('PrototypeThrowIfAborted','throwIfAborted',0),('Abort','abort',0)],
 'EventTarget':[('PrototypeAddEventListener','addEventListener',2),('PrototypeRemoveEventListener','removeEventListener',2),('PrototypeDispatchEvent','dispatchEvent',1)],
 'Event':[('PrototypePreventDefault','preventDefault',0),('PrototypeStopPropagation','stopPropagation',0),('PrototypeStopImmediatePropagation','stopImmediatePropagation',0)],
 'DOMException':[]}
getters={
 'AbortController':['signal'],
 'AbortSignal':['aborted','reason','onabort'],
 'EventTarget':[],
 'Event':['type','target','currentTarget','defaultPrevented','eventPhase','bubbles','cancelable','composed','isTrusted'],
 'DOMException':['name','message','code']}
rows=[]
for i,c in enumerate(constructors):
 length=0
 if c=='Event':length=1
 rows.append((c+'Constructor',c,length,True,i+57))
 for suffix,name,length in methods[c]:rows.append((c+suffix,name,length,False,None))
 for name in getters[c]:
  suffix=name[0].upper()+name[1:]
  rows.append((c+'Prototype'+suffix+'Getter','get '+name,0,False,None))
 if c=='AbortSignal':rows.append(('AbortSignalPrototypeOnabortSetter','set onabort',1,False,None))
# RSC-facing native events are all observable through normal dynamic property lookup.
p='crates/scriptw-ir/src/builtins/catalog.rs'
text=''
for j,(variant,name,length,constructor,glob) in enumerate(rows):
 lines=['    '+variant+' {',f'        function: FunctionOrdinal({920+j}) => "scriptw:web:{variant}",']
 if glob is not None:lines += [f'        global: GlobalOrdinal({glob}),',f'        global_name: "{name}",']
 lines += [f'        debug: "{variant}",']
 flags='SYNCHRONOUS_USER_CODE'
 if constructor:flags='CONSTRUCTABLE, SYNCHRONOUS_USER_CODE'
 lines += [f'        flags: [{flags}],','        installer: None,',f'        native: "{name}",','    }']
 text+='\n'.join(lines)+'\n'
edit(p,lambda s:s if '    AbortControllerConstructor {' in s else s[:s.rfind('\n}')]+ '\n'+text+s[s.rfind('\n}'):])
# Semantic signatures stay conservative; they never invent concrete native JS fields.
variants='\n            | '.join('StandardBuiltinId::'+r[0] for r in rows)
insert('crates/scriptw-ir/src/lowering/builtin_call_info.rs','            StandardBuiltinId::FunctionConstructor =>',f'            {variants} => Some(unknown_runtime_value_info()),\n')
p='crates/scriptw-ir/src/lowering/builtin_shapes.rs'
anchor='            StandardBuiltinId::ShadowRealmConstructor => ('
insert(p,anchor,f'            {variants} => (ValueKind::Dynamic, KindSet::all_runtime_tags(), None, ValueInfo::undefined()),\n')
# Native arity and implementation ownership.
insert('crates/scriptw-aot-wasm/src/planning.rs','        StandardBuiltinId::ShadowRealmConstructor |', '\n'.join(f'        StandardBuiltinId::{v} => {length},' for v,n,length,c,g in rows)+'\n')
insert('crates/scriptw-aot-wasm/src/builtins/standard.rs','            StandardBuiltinId::ShadowRealmConstructor =>',f'            {variants} => self.emit_web_event_builtin(builtin, function)?,\n')
insert('crates/scriptw-aot-wasm/src/builtins/mod.rs','mod array;','mod web_events;\n')
# Native schemas. Each canonical object starts with its real ordinary header.
layout='''        struct EventTargetObject: JavaScriptObject => EventTargetObjectSchema {
            OBJECT: GcRef<OrdinaryObject>, Immutable, NonNullable;
            HEAD: GcRef<WebEventListener>, Mutable, Nullable;
            TAIL: GcRef<WebEventListener>, Mutable, Nullable;
            ONABORT: GcRef<WebEventListener>, Mutable, Nullable;
        }
        struct AbortControllerObject: JavaScriptObject => AbortControllerObjectSchema {
            OBJECT: GcRef<OrdinaryObject>, Immutable, NonNullable;
            SIGNAL: GcRef<AbortSignalObject>, Immutable, NonNullable;
        }
        struct AbortSignalObject: JavaScriptObject => AbortSignalObjectSchema {
            OBJECT: GcRef<OrdinaryObject>, Immutable, NonNullable;
            TARGET: GcRef<EventTargetObject>, Immutable, NonNullable;
            ABORTED: bool, Mutable, NonNullable;
            REASON: GcRef<StoredValue>, Mutable, NonNullable;
        }
        struct WebEventListener => WebEventListenerSchema {
            TYPE: GcRef<StringValue>, Immutable, NonNullable;
            CALLBACK: GcRef<StoredValue>, Mutable, NonNullable;
            CAPTURE: bool, Immutable, NonNullable;
            ONCE: bool, Immutable, NonNullable;
            PASSIVE: bool, Immutable, NonNullable;
            REMOVED: bool, Mutable, NonNullable;
            SIGNAL: GcRef<AbortSignalObject>, Immutable, Nullable;
            NEXT: GcRef<WebEventListener>, Mutable, Nullable;
        }
        struct WebEventObject: JavaScriptObject => WebEventObjectSchema {
            OBJECT: GcRef<OrdinaryObject>, Immutable, NonNullable;
            TYPE: GcRef<StringValue>, Immutable, NonNullable;
            TARGET: GcRef<StoredValue>, Mutable, NonNullable;
            CURRENT_TARGET: GcRef<StoredValue>, Mutable, NonNullable;
            BUBBLES: bool, Immutable, NonNullable;
            CANCELABLE: bool, Immutable, NonNullable;
            COMPOSED: bool, Immutable, NonNullable;
            DISPATCHING: bool, Mutable, NonNullable;
            CANCELED: bool, Mutable, NonNullable;
            PASSIVE: bool, Mutable, NonNullable;
            STOP_IMMEDIATE: bool, Mutable, NonNullable;
        }
        struct DOMExceptionObject: JavaScriptObject => DOMExceptionObjectSchema {
            OBJECT: GcRef<OrdinaryObject>, Immutable, NonNullable;
            NAME: GcRef<StringValue>, Immutable, NonNullable;
            MESSAGE: GcRef<StringValue>, Immutable, NonNullable;
        }
'''
insert('crates/scriptw-aot-wasm/src/gc_types/layouts.rs','        struct ShadowRealmObject:',layout)
# Reserve canonical constructor/prototype slots. Root reconciles total lengths after parallel integration.
slotrows=[]
for i,c in enumerate(constructors):
 slotrows += [(c+'Constructor',163+2*i),(c+'Prototype',164+2*i)]
insert('crates/scriptw-aot-wasm/src/functions.rs','    ShadowRealmConstructor,',''.join('    '+v+',\n' for v,n in slotrows))
insert('crates/scriptw-aot-wasm/src/functions.rs','            Self::ShadowRealmConstructor => 156,',''.join(f'            Self::{v} => {n},\n' for v,n in slotrows))
edit('crates/scriptw-aot-wasm/src/functions.rs',lambda s:re.sub(r'TABLE_LENGTH: u32 = (\d+)',lambda m:'TABLE_LENGTH: u32 = '+str(max(173,int(m[1]))),s))
insert('crates/scriptw-aot-wasm/src/module.rs','        StandardBuiltinId::ShadowRealmConstructor => {',''.join(f'        StandardBuiltinId::{c}Constructor => Some(crate::functions::NonArrayRealmIntrinsicSlot::{c}Constructor),\n' for c in constructors))
# This method's remaining exhaustive no-slot group gets every nonconstructor entry.
no_slots=[v for v,n,l,c,g in rows if not c]
insert('crates/scriptw-aot-wasm/src/module.rs','        StandardBuiltinId::ShadowRealmPrototypeEvaluate\n',''.join('        StandardBuiltinId::'+v+'\n        | ' for v in no_slots).replace('\n        |         StandardBuiltinId','\n        | StandardBuiltinId').rstrip(' |')+'\n        | ')
# Default prototype authority uses the constructor's own Realm fallback.
p='crates/scriptw-aot-wasm/src/functions/required_resolved_realm_ordinary_prototype.rs'
insert(p,'    ShadowRealm,',''.join('    '+c+',\n' for c in constructors))
insert(p,'            Self::ShadowRealm =>',''.join(f'            Self::{c} => NonArrayRealmIntrinsicSlot::{c}Prototype,\n' for c in constructors))
# Common eager property plans publish methods/accessors in native prototypes.
p='crates/scriptw-aot-wasm/src/intrinsics/property_layouts.rs'
insert(p,'    ShadowRealmConstructor,',''.join('    '+v+',\n' for v,n in slotrows))
insert(p,'        Self::ShadowRealmConstructor,',''.join('        Self::'+v+',\n' for v,n in slotrows))
insert(p,'            Self::ShadowRealmConstructor => Some(',' '.join([])+''.join(f'            Self::{c}Constructor => Some(FunctionIdentity::StandardBuiltin(StandardBuiltinId::{c}Constructor)),\n' for c in constructors))
insert(p,'            Slot::ShadowRealmConstructor\n',''.join('            Slot::'+v+'\n            | ' for v,n in slotrows).replace('            |             Slot::','            | Slot::')+'            | ')
insert(p,'            | Self::ShadowRealmConstructor\n',''.join('            | Self::'+v+'\n' for v,n in slotrows))
insert(p,'            Slot::ShadowRealmConstructor => {',''.join(f'            Slot::{c}Constructor => Some(StandardBuiltinId::{c}Constructor.function_id()),\n' for c in constructors))
insert('crates/scriptw-aot-wasm/src/intrinsics/property_layouts/eager.rs','        Slot::ShadowRealmPrototype => Some',''.join(f'        Slot::{v} => Some(Layout::{v}),\n' for v,n in slotrows))
p='crates/scriptw-aot-wasm/src/intrinsics/property_layouts/eager.rs'
insert(p,'        Layout::ShadowRealmConstructor => {',''.join(f'        Layout::{c}Constructor => Some(IntrinsicPropertyRecipe::ready(Slot::{c}Prototype)?),\n' for c in constructors))
recipes=''
for c in constructors:
 recipes+='        Layout::'+c+'Constructor => {\n'
 if c=='AbortSignal':recipes+='            named_method(plan, "abort", Builtin::AbortSignalAbort);\n'
 recipes+='        }\n'
 recipes+='        Layout::'+c+'Prototype => {\n            plan.constructor(Slot::'+c+'Constructor)?;\n            plan.tag("'+c+'");\n'
 for suffix,name,length in methods[c]:
  if 'Prototype' in suffix:recipes+=f'            named_method(plan, "{name}", Builtin::{c}{suffix});\n'
 for name in getters[c]:
  suffix=name[0].upper()+name[1:]
  if name=='onabort':
   recipes+='            plan.accessor(IntrinsicKey::Name("onabort"), IntrinsicCallableRecipe::method(Builtin::AbortSignalPrototypeOnabortGetter)?, IntrinsicCallableRecipe::method(Builtin::AbortSignalPrototypeOnabortSetter)?);\n'
  else:recipes+=f'            getter(plan, IntrinsicKey::Name("{name}"), Builtin::{c}Prototype{suffix}Getter)?;\n'
 recipes+='        }\n'
insert(p,'        Layout::ShadowRealmPrototype => {',recipes)
# Bootstrap parents: Signal inherits EventTarget; DOMException inherits Error.
p='crates/scriptw-aot-wasm/src/builtins/bootstrap.rs'
insert(p,'            NonArrayRealmIntrinsicSlot::TextEncoderPrototype,',''.join('            NonArrayRealmIntrinsicSlot::'+c+'Prototype,\n' for c in ['AbortController','EventTarget','Event']))
anchor='        let primitive = schema.reserve_value_local(function);'
parents=''
for c,parent in [('AbortSignal','EventTarget'),('DOMException','Error')]:
 parents+=f'        self.emit_load_non_array_realm_intrinsic(realm, NonArrayRealmIntrinsicSlot::{parent}Prototype, &parent, function);\n        self.emit_bootstrap_plain_prototype(&context, NonArrayRealmIntrinsicSlot::{c}Prototype, &parent, function)?;\n'
insert(p,anchor,parents)
insert(p,'            (StandardBuiltinId::TextEncoderConstructor,',''.join(f'            (StandardBuiltinId::{c}Constructor, NonArrayRealmIntrinsicSlot::{c}Prototype),\n' for c in constructors))
# Dedicated native messages are interned through the existing catalog.
insert('crates/scriptw-aot-wasm/src/data/runtime_error_message.rs','    SHADOW_REALM_REQUIRES_NEW =>','''    WEB_EVENT_REQUIRES_NEW => "Web platform constructors require new",
    WEB_EVENT_INVALID_RECEIVER => "Incompatible Web platform receiver",
    WEB_EVENT_ILLEGAL_CONSTRUCTOR => "Illegal constructor",
    WEB_EVENT_REQUIRED_ARGUMENT => "Required Web platform argument is missing",
    WEB_EVENT_INVALID_CALLBACK => "Event listener must be an object or null",
    WEB_EVENT_INVALID_SIGNAL => "Listener signal must be an AbortSignal",
    WEB_EVENT_INVALID_EVENT => "Argument must be an Event",
    WEB_EVENT_DISPATCHING => "Event is already being dispatched",
''')
(R/'target/rsc-platform-work/events-rows.json').write_text(json.dumps(rows))
print('wired',len(rows),'event callables; shared table lengths reconciled after batch')
