#!/usr/bin/env python3
"""Unscored retained Flight sampling; never replace the frozen baseline report.

Run inside limited_verification.py. Reuses the already verified perf binary and
its bounded control/ACK utilities. Each enabled window contains flight() only.
"""
import argparse
import bisect
import collections
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import socket
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "scripts"))
from limited_verification import kernel_group, limited_environment, require_kernel_budget
sys.path.insert(0, str(ROOT / "target/performance-intrinsic-array-reads-v2-20261102"))
from mixed_worker_samples import line, perf_ack, thread_record

BASELINE = ROOT / "target/rsc-platform-work/rsc-baseline-0.json"
PROBE = ROOT / "target/performance-shared-worker-20261101/tools/perf-probe/perf-probe.json"
FIELDS = ["memory.max", "memory.swap.max", "memory.oom.group", "cpu.max", "memory.events"]


def digest(path):
    value = hashlib.sha256()
    with path.open("rb") as stream:
        for data in iter(lambda: stream.read(1024 * 1024), b""):
            value.update(data)
    return value.hexdigest()


def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")


def symbolize(folder):
    groups = collections.defaultdict(set)
    for row in (folder / "perf.map").read_text().splitlines():
        address, length, name = row.split(maxsplit=2)
        groups[(int(address, 16), int(length, 16))].add(name)
    symbols = sorted((at, size, sorted(names)) for (at, size), names in groups.items())
    assert symbols, "actual process perf map has no functions"
    for left, right in zip(symbols, symbols[1:]):
        assert left[0] + left[1] <= right[0], "overlapping native symbol ranges require explicit handling"
    starts = [symbol[0] for symbol in symbols]
    counts = collections.Counter()
    samples = []
    for row in (folder / "samples.txt").read_text().splitlines():
        match = re.fullmatch(r"\s*(\d+)\s+([0-9a-fA-F]+)\s+(.+)", row)
        assert match, ("unexpected perf field ordering", row)
        period, ip, raw = int(match[1]), int(match[2], 16), match[3]
        owner = "<zero IP>"
        if ip:
            owner = "host-or-unresolved:" + raw
            index = bisect.bisect_right(starts, ip) - 1
            if index >= 0:
                address, size, names = symbols[index]
                if ip < address + size:
                    owner = "wasm:" + " | ".join(names)
        counts[owner] += period
        samples.append({"ip": hex(ip), "period": period, "owner": owner, "raw": raw})
    total = sum(counts.values())
    assert total > 0, "no user-cycle samples captured"
    save(folder / "symbols.json", {
        "unscored": True, "samples": len(samples), "period_sum": total,
        "limits": "Sampled user-cycle locations, not wall-time percentages or allocation counts. Host, unresolved and fringe samples retained.",
        "top": [{"owner": owner, "period_sum": count, "sample_share": count / total}
                for owner, count in counts.most_common()],
        "rows": samples,
    })


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("binary", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--mode", choices=["sync", "async"], required=True)
    parser.add_argument("--samples", type=int, default=100)
    parser.add_argument("--warmups", type=int, default=3)
    parser.add_argument("--baseline-json", type=Path, default=BASELINE)
    args = parser.parse_args()
    assert 1 <= args.samples <= 200 and 0 <= args.warmups <= 20
    require_kernel_budget(4 * 1024**3)
    assert len(os.sched_getaffinity(0)) == 1
    baseline_path = args.baseline_json.resolve(strict=True)
    baseline = json.loads(baseline_path.read_text())
    probe = json.loads(PROBE.read_text())
    binary, folder = args.binary.resolve(strict=True), args.output.resolve()
    source, support = (Path(baseline["inputs"][key]) for key in ("source", "support"))
    assert digest(source) == baseline["inputs"]["source_sha256"]
    assert digest(support) == baseline["inputs"]["support_sha256"]
    perf_binary = ROOT / probe["unpacked_executable"]
    assert digest(perf_binary) == probe["unpacked_executable_sha256"]
    folder.mkdir(exist_ok=False)
    (folder / "tmp").mkdir()
    nonce = os.urandom(16).hex()
    env = limited_environment()
    assert not any(key.startswith("SCRIPTW_RSC_PROFILE_") for key in env)
    assert "LD_PRELOAD" not in env and "LD_AUDIT" not in env
    parent, child_socket = socket.socketpair()
    env.update(TMPDIR=str(folder / "tmp"), SCRIPTW_RSC_PROFILE_FD=str(child_socket.fileno()),
               SCRIPTW_RSC_PROFILE_NONCE=nonce, SCRIPTW_RSC_PROFILE_MODE=args.mode)
    perf_env = limited_environment()
    perf_env.update(TMPDIR=str(folder / "tmp"), LD_LIBRARY_PATH=str(ROOT / probe["unpacked_libdir"]))
    argv = [str(binary), str(source), str(support), str(folder / "observations.json"),
            str(args.samples), str(args.warmups)]
    result = {
        "schema": "scriptw-rsc-perf-v1", "status": "incomplete", "unscored": True,
        "argv": argv, "mode": args.mode, "samples": args.samples, "warmups": args.warmups,
        "event": "cycles:u", "period": 250000, "nonce": nonce,
        "executable_sha256": digest(binary), "baseline_report_sha256": digest(baseline_path),
        "source_sha256": digest(source), "support_sha256": digest(support),
        "perf_sha256": digest(perf_binary), "sampler_sha256": digest(Path(__file__)),
        "limits": "Excluded diagnostic. Compile, module initialization, warmups, JSON serialization and output checks are outside sampling windows. No timing, allocation or speedup verdict.",
        "resources_before": {name: (kernel_group() / name).read_text() for name in FIELDS},
        "events": [],
    }
    save(folder / "plan.json", result)
    child = perf = None
    fds = []
    deadline = time.monotonic() + 180
    try:
        with (folder / "host.stdout").open("xb") as stdout, (folder / "host.stderr").open("xb") as stderr, \
             (folder / "perf.stdout").open("xb") as perf_stdout, (folder / "perf.stderr").open("xb") as perf_stderr:
            child = subprocess.Popen(argv, cwd=ROOT, env=env, stdin=subprocess.DEVNULL,
                                     stdout=stdout, stderr=stderr, pass_fds=(child_socket.fileno(),))
            child_socket.close()
            result["pid"] = child.pid
            for index in range(args.warmups, args.warmups + args.samples):
                for phase in ("ready", "done"):
                    timeout = 30
                    if index == args.warmups and phase == "ready":
                        timeout = 60
                    event = line(parent.fileno(), min(timeout, deadline - time.monotonic()))
                    expected = f"SWRSC1 {nonce} {phase} {args.mode} {index}\n"
                    assert event == expected, (event, expected)
                    result["events"].append({"phase": phase, "index": index, "monotonic_ns": time.monotonic_ns()})
                    if perf is None:
                        workers = [thread_record(child.pid, int(path.name))
                                   for path in Path(f"/proc/{child.pid}/task").iterdir()
                                   if (path / "comm").read_text().strip() == "scriptw-execution"[:15]]
                        assert len(workers) == 1, "require actual unique persistent execution worker"
                        worker = workers[0]
                        result["worker_before"] = worker
                        (folder / "maps-before.txt").write_text(Path(f"/proc/{child.pid}/maps").read_text())
                        (folder / "perf-before.map").write_bytes(Path(f"/tmp/perf-{child.pid}.map").read_bytes())
                        ctl_r, ctl_w = os.pipe()
                        ack_r, ack_w = os.pipe()
                        fds += [ctl_r, ctl_w, ack_r, ack_w]
                        perf_argv = [str(perf_binary), "record", "--no-buildid", "-e", result["event"],
                                     "-c", str(result["period"]), "-t", str(worker["tid"]), "--delay=-1",
                                     f"--control=fd:{ctl_r},{ack_w}", "-o", str(folder / "perf.data")]
                        result["perf_argv"] = perf_argv
                        perf = subprocess.Popen(perf_argv, cwd=ROOT, env=perf_env, stdin=subprocess.DEVNULL,
                                                stdout=perf_stdout, stderr=perf_stderr, pass_fds=(ctl_r, ack_w))
                    command = b"disable\n"
                    if phase == "ready":
                        command = b"enable\n"
                    os.write(ctl_w, command)
                    perf_ack(ack_r, result)
                    if phase == "done" and index + 1 == args.warmups + args.samples:
                        result["worker_after"] = thread_record(child.pid, worker["tid"])
                        assert result["worker_after"]["starttime_ticks"] == worker["starttime_ticks"]
                        (folder / "maps-after.txt").write_text(Path(f"/proc/{child.pid}/maps").read_text())
                        (folder / "perf.map").write_bytes(Path(f"/tmp/perf-{child.pid}.map").read_bytes())
                        perf.send_signal(signal.SIGINT)
                        result["perf_exit_code"] = perf.wait(timeout=5)
                        assert result["perf_exit_code"] in (0, -signal.SIGINT)
                    parent.sendall(expected.replace("SWRSC1", "SWACK1", 1).encode())
            result["host_exit_code"] = child.wait(timeout=30)
        assert result["host_exit_code"] == 0
        report = json.loads((folder / "observations.json").read_text())
        assert report["profiling"]["nonce"] == nonce and report["profiling"]["windows"] == args.samples
        assert report["profiling"]["excluded_from_scored_cohorts"] is True
        assert report["program_wasm_sha256"] == baseline["program_wasm_sha256"]
        assert report["runtime"] == baseline["runtime"]
        assert report["configuration"] == baseline["configuration"]
        assert len(report["cases"]) == 1 and report["cases"][0]["exact_node_output_checked"] is True
        assert len(report["cases"][0]["observations"]) == args.samples + args.warmups
        assert report["cases"][0]["case"] == "rsc-" + args.mode
        result["source_fingerprint"] = report["source_fingerprint"]
        argv = [str(perf_binary), "script", "-i", str(folder / "perf.data"), "-F", "ip,period,dso,sym"]
        with (folder / "samples.txt").open("xb") as out, (folder / "samples.stderr").open("xb") as err:
            parsed = subprocess.run(argv, cwd=ROOT, env=perf_env, stdin=subprocess.DEVNULL,
                                    stdout=out, stderr=err, timeout=20)
        assert parsed.returncode == 0
        symbolize(folder)
        result["status"] = "captured"
    except Exception as error:
        result["status"] = "failed"
        result["error"] = repr(error)
        raise
    finally:
        for process in (perf, child):
            if process is not None and process.poll() is None:
                process.kill()
                process.wait(timeout=5)
        parent.close()
        child_socket.close()
        for fd in fds:
            os.close(fd)
        result["resources_after"] = {name: (kernel_group() / name).read_text() for name in FIELDS}
        result["raw_files"] = {path.name: {"sha256": digest(path), "bytes": path.stat().st_size}
                               for path in folder.iterdir() if path.is_file()}
        save(folder / "receipt.json", result)
    print(json.dumps({"status": result["status"], "output": str(folder)}))


if __name__ == "__main__":
    main()
