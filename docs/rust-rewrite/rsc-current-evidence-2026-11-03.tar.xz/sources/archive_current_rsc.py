#!/usr/bin/env python3
"""Package final retained-RSC evidence as an inert UTF-8 tar.xz archive.

Run only after the campaign and all required test/profile checkpoints complete.
The archive contains no executable, cache, native/Wasm payload or perf.data.
"""
from copy import deepcopy
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import subprocess
import tarfile

ROOT = Path(__file__).resolve().parents[2]
WORK = ROOT / 'target/rsc-platform-work'
FIXTURES = ROOT / 'target/application-benchmarks-20261102/generated-v2'
REPORT = ROOT / 'docs/rust-rewrite/rsc-current.json'
DRIVER = ROOT / 'crates/scriptw-cli/tests/fixtures/edge_rendering/react-driver.cjs'
SOURCE_DIR = ROOT / 'crates/scriptw-cli/tests/fixtures/edge_rendering'
ARCHIVE_LIMIT = 5 * 1024**2
FILE_LIMIT = 64 * 1024**2
EXPANDED_LIMIT = 512 * 1024**2


def need(ok, reason):
    if not ok:
        raise RuntimeError(reason)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def json_bytes(value):
    return (json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + '\n').encode()


class Archive:
    def __init__(self):
        self.files = {}

    def add_bytes(self, member, value):
        path = PurePosixPath(member)
        need(path.parts and not path.is_absolute() and '..' not in path.parts
             and str(path) == member and '\\' not in member and ':' not in member,
             'unsafe archive member: ' + member)
        need(member not in ('INDEX.json', 'INDEX.json.sha256') and member not in self.files,
             'duplicate or reserved archive member: ' + member)
        need(len(value) <= FILE_LIMIT, 'archive file exceeds 64 MiB: ' + member)
        value.decode('utf-8', errors='strict')
        need(b'\0' not in value, 'binary/NUL file rejected: ' + member)
        self.files[member] = value

    def add_file(self, member, source):
        source = Path(source)
        info = source.lstat()
        need(source.is_file() and not source.is_symlink(), 'non-regular source rejected: ' + str(source))
        need(info.st_size <= FILE_LIMIT, 'source file exceeds 64 MiB: ' + str(source))
        self.add_bytes(member, source.read_bytes())

    def add_work_file(self, source, member=None):
        source = Path(source)
        self.add_file(member or source.relative_to(ROOT).as_posix(), source)

    def add_campaign(self):
        folder = WORK / 'current-rsc-campaign'
        campaign_path = folder / 'campaign.json'
        campaign = json.loads(campaign_path.read_text())
        need(campaign.get('schema') == 'scriptw-rsc-campaign-v1'
             and campaign.get('status') == 'complete' and len(campaign.get('processes', [])) == 24,
             'require all 24 complete retained-RSC campaign processes')
        self.add_file('campaign/campaign.json', campaign_path)
        for index, row in enumerate(campaign['processes']):
            need(row.get('status') == 'complete', 'incomplete campaign row: ' + str(index))
            process_dir = PurePosixPath(row['stdout']).parent
            for relative in (row['report'], row['stdout'], row['stderr'],
                             (process_dir / 'resources.json').as_posix()):
                source = folder / relative
                self.add_file('campaign/' + relative, source)
        aggregate = json.loads((folder / 'aggregate.json').read_text())
        need(aggregate.get('schema') == 'scriptw-rsc-current-v1', 'missing current RSC aggregate')
        self.add_file('reports/current-rsc-campaign.json', folder / 'aggregate.json')
        self.add_file('reports/current-rsc-campaign-script.py', WORK / 'measure_current_rsc.py')
        return campaign, aggregate

    def add_profile(self, variant, mode):
        suffix = '-candidate-0' if variant == 'candidate' else '-0'
        folder = WORK / ('profile-' + mode + suffix)
        prefix = 'profiles/' + variant + '/' + mode + '/'
        for name in ('plan.json', 'receipt.json', 'observations.json', 'host.stdout', 'host.stderr',
                     'perf.stdout', 'perf.stderr', 'samples.txt', 'samples.stderr',
                     'maps-before.txt', 'maps-after.txt', 'perf-before.map', 'perf.map'):
            self.add_file(prefix + name, folder / name)
        symbols = json.loads((folder / 'symbols.json').read_text())
        need(symbols.get('unscored') is True and isinstance(symbols.get('top'), list),
             'invalid unscored profile summary: ' + mode)
        compact = {key: symbols[key] for key in ('unscored', 'samples', 'period_sum', 'limits')}
        compact['top'] = symbols['top'][:40]
        compact['omitted_owner_rows'] = max(0, len(symbols['top']) - len(compact['top']))
        self.add_bytes(prefix + 'top-symbols.json', json_bytes(compact))

    def add_campaign_outputs(self):
        # Keep the successful final build/checkpoint logs and the earlier focused
        # failure records together. Superseded failures remain historical inputs.
        exact = {
            'source-ready.json', 'focused-native.json', 'candidate-focused-native.json',
            'broad-native.json', 'candidate-controls.json', 'repeatability-processes.json',
            'ordinary-rsc.json', 'rsc-baseline-0.json', 'rsc-baseline-1.json', 'rsc-baseline-2.json',
            'events-rows.json', 'candidate-emission.stdout', 'candidate-emission.stderr',
            'candidate-native-build.stdout', 'candidate-native-build.stderr',
            'candidate-cli-build.stdout', 'candidate-cli-build.stderr',
            'candidate-rsc-build.stdout', 'candidate-rsc-build.stderr',
            'cli-build.stdout', 'cli-build.stderr',
            'candidate-cli-feature-comparison.json', 'candidate-diagnostic.json',
            'rsc-candidate-0.json', 'format-receipt.json', 'format.stdout', 'format.stderr',
            'no-interpreter.stdout', 'no-interpreter.stderr',
            'intl-source-identities.stdout', 'intl-source-identities.stderr',
            'candidate-source-guards.stdout', 'candidate-source-guards.stderr',
            'emission-release.stdout', 'emission-release.stderr',
            'capture-ir-tests.stdout', 'capture-ir-tests.stderr',
            'capture-ir-tests-check.stdout', 'capture-ir-tests-check.stderr',
            'capture-ir-tests-refresh.stdout', 'capture-ir-tests-refresh.stderr',
            'broad-aot_builtins.stdout', 'broad-aot_builtins.stderr',
            'broad-aot_async.stdout', 'broad-aot_async.stderr',
            'broad-aot_realm_modules.stdout', 'broad-aot_realm_modules.stderr',
            'codecs.stdout', 'codecs.stderr', 'events.stdout', 'events.stderr',
            'streams.stdout', 'streams.stderr', 'streams-real.stdout', 'streams-real.stderr',
            'tasks.stdout', 'tasks.stderr', 'embedding-timers.stdout', 'embedding-timers.stderr',
            'events-rechecked.stdout', 'events-rechecked.stderr',
            'task-realm-rechecked.stdout', 'task-realm-rechecked.stderr',
            'candidate-captured-cells.stdout', 'candidate-captured-cells.stderr',
            'candidate-codecs.stdout', 'candidate-codecs.stderr',
            'candidate-events.stdout', 'candidate-events.stderr',
            'candidate-streams.stdout', 'candidate-streams.stderr',
            'candidate-tasks.stdout', 'candidate-tasks.stderr',
            'candidate-embedding-timers.stdout', 'candidate-embedding-timers.stderr',
        }
        required = {
            'source-ready.json', 'focused-native.json', 'candidate-focused-native.json',
            'broad-native.json', 'candidate-controls.json', 'candidate-emission.stdout',
            'candidate-emission.stderr', 'candidate-native-build.stdout',
            'candidate-native-build.stderr', 'candidate-cli-build.stdout',
            'candidate-cli-build.stderr', 'candidate-rsc-build.stdout',
            'candidate-rsc-build.stderr', 'candidate-cli-feature-comparison.json',
            'candidate-diagnostic.json', 'rsc-candidate-0.json', 'format-receipt.json',
            'format.stdout', 'format.stderr', 'no-interpreter.stdout', 'no-interpreter.stderr',
            'intl-source-identities.stdout', 'intl-source-identities.stderr',
        }
        for name in sorted(exact):
            path = WORK / name
            if path.is_file():
                self.add_file('verification/' + name, path)
            elif name in required:
                raise RuntimeError('required current RSC verification evidence missing: ' + name)
        control_report = json.loads((WORK / 'candidate-controls.json').read_text())
        need(isinstance(control_report, list) and len(control_report) == 9
             and all(row.get('guest_output_and_backend_outcome_match') is True for row in control_report),
             'candidate controls must contain nine exact-output passes')
        for name in ('rsc-producer.json', 'cli-producer.json', 'cli-identity.json'):
            path = WORK / 'frozen' / name
            if path.is_file():
                self.add_file('producers/' + name, path)
        candidate_frozen = WORK / 'candidate-frozen'
        if candidate_frozen.is_dir():
            for path in sorted(candidate_frozen.glob('*.json')):
                self.add_file('producers/candidate-' + path.name, path)
        diagnostic = WORK / 'candidate-diagnostic'
        for name in ('stdout', 'stderr'):
            self.add_file('verification/candidate-diagnostic/' + name, diagnostic / name)
        controls = WORK / 'candidate-controls'
        need(controls.is_dir(), 'candidate control raw logs missing')
        control_dirs = [path for path in controls.iterdir() if path.is_dir()]
        need(len(control_dirs) == 9, 'candidate control raw log inventory differs')
        for folder in control_dirs:
            for name in ('stdout', 'stderr'):
                path = folder / name
                self.add_file('candidate-controls/' + path.relative_to(controls).as_posix(), path)

    def add_sources(self):
        # Preserve the exact generated input and golden outputs, plus license
        # texts and executable source needed to understand both reference paths.
        for name in ('rsc.js', 'support.json', 'manifest.json'):
            self.add_file('fixtures/' + name, FIXTURES / name)
        for name in ('react-rsc.entry.js', 'react-driver.cjs'):
            self.add_file('fixtures/' + name, SOURCE_DIR / name)
        self.add_file('sources/rsc_baseline.rs', ROOT / 'crates/scriptw-cli/examples/rsc_baseline.rs')
        self.add_file('sources/react-driver.cjs', DRIVER)
        for name in ('measure_current_rsc.py', 'profile_rsc.py', 'archive_current_rsc.py',
                     'check_candidate_controls.py', 'wire_events.py'):
            self.add_file('sources/' + name, WORK / name)
        for name in ('benchmark_metrics.py', 'limited_verification.py',
                     'check-source-guards.py', 'intl_source_identities.py',
                     'render-application-benchmarks.py', 'application_benchmarks.py',
                     'benchmark_charts.py', 'check-no-interpreter-in-product-graph.sh'):
            self.add_file('sources/scripts/' + name, ROOT / 'scripts' / name)
        self.add_file('sources/mixed_worker_samples.py',
                      ROOT / 'target/performance-intrinsic-array-reads-v2-20261102/mixed_worker_samples.py')
        self.add_file('sources/perf-probe-identity.json',
                      ROOT / 'target/performance-shared-worker-20261101/tools/perf-probe/perf-probe.json')

        packages = ROOT / 'target/application-benchmarks-20261102/tools/node_modules/.pnpm'
        license_paths = {
            'react': packages / 'react@19.3.1/node_modules/react/LICENSE',
            'react-dom': packages / 'react-dom@19.3.1_react@19.3.1/node_modules/react-dom/LICENSE',
            'react-server-dom-webpack': next(packages.glob(
                'react-server-dom-webpack@19.3.1*/node_modules/react-server-dom-webpack/LICENSE')),
        }
        for name, path in license_paths.items():
            self.add_file('licenses/' + name + '-LICENSE', path)

        diff = subprocess.run(['git', 'diff', 'HEAD', '--no-ext-diff', '--no-color', '--', 'crates'],
                              cwd=ROOT, check=True, stdout=subprocess.PIPE).stdout
        self.add_bytes('source/working-tree-crates.patch', diff)
        status = subprocess.run(['git', 'status', '--short', '--', 'crates'], cwd=ROOT,
                                check=True, stdout=subprocess.PIPE).stdout
        self.add_bytes('source/crates-status.txt', status)
        commit = subprocess.run(['git', 'rev-parse', 'HEAD'], cwd=ROOT, check=True,
                                stdout=subprocess.PIPE).stdout.decode().strip()
        untracked = subprocess.run(['git', 'ls-files', '--others', '--exclude-standard', '--', 'crates'],
                                   cwd=ROOT, check=True, stdout=subprocess.PIPE).stdout.decode().splitlines()
        source_rows = []
        for relative in sorted(untracked):
            if not relative.endswith('.rs'):
                continue
            source = ROOT / relative
            member = 'source/untracked/' + relative
            self.add_file(member, source)
            source_rows.append({'path': member, 'bytes': source.stat().st_size,
                                'sha256': sha(source.read_bytes())})
        patch_member = 'source/working-tree-crates.patch'
        source_rows.append({'path': patch_member, 'bytes': len(diff), 'sha256': sha(diff)})
        self.add_file('source/pre-verification-source-ready.json', WORK / 'source-ready.json')
        measured = self.add_measured_source()
        self.add_bytes('source/source-authentication.json', json_bytes({
            'schema': 'scriptw-rsc-source-snapshot-v1', 'git_head': commit,
            'patch_base': 'git diff HEAD -- crates', 'untracked_rust_files': len(source_rows) - 1,
            'files': source_rows,
            'candidate_measured_source': measured,
            'note': 'Patch plus copied untracked Rust sources reconstructs crate working-tree changes over git_head; source-ready.json is the earlier pre-verification inventory.'}))
        return measured

    def add_measured_source(self):
        folder = WORK / 'candidate-measured-source'
        manifest_path = folder / 'manifest.json'
        manifest_bytes = manifest_path.read_bytes()
        manifest = json.loads(manifest_bytes)
        need(isinstance(manifest.get('base_commit'), str)
             and manifest.get('role') == 'Exact candidate working-source reconstruction before final whitespace-only formatting; apply tracked patch then new files to base.',
             'candidate measured-source manifest role differs')
        listed = manifest.get('files')
        need(isinstance(listed, dict) and 'tracked.patch' in listed,
             'candidate measured-source inventory is incomplete')
        actual = {}
        for path in sorted(folder.rglob('*')):
            if path.is_dir():
                need(not path.is_symlink(), 'symlink directory in measured source tree')
                continue
            need(path.is_file() and not path.is_symlink(), 'non-regular measured source member')
            relative = path.relative_to(folder).as_posix()
            if relative != 'manifest.json':
                actual[relative] = path.read_bytes()
                need(sha(actual[relative]) == listed.get(relative),
                     'measured-source manifest hash differs: ' + relative)
            self.add_file('candidate-measured-source/' + relative, path)
        need(set(actual) == set(listed), 'candidate measured-source file inventory differs')
        return {'archive_prefix': 'candidate-measured-source/',
                'manifest_sha256': sha(manifest_bytes), 'base_commit': manifest['base_commit'],
                'role': manifest['role'], 'files': len(listed)}

    def add_core_summaries(self, aggregate):
        for variant in ('baseline', 'candidate'):
            for mode in ('sync', 'async'):
                self.add_profile(variant, mode)

    def write(self, destination):
        expanded = sum(len(value) for value in self.files.values())
        need(len(self.files) <= 20_000 and expanded <= EXPANDED_LIMIT,
             'archive inventory/expanded-size limit exceeded')
        index = {'schema': 'scriptw-inert-evidence-index-v1',
                 'members': [{'path': name, 'bytes': len(value), 'sha256': sha(value)}
                             for name, value in sorted(self.files.items())]}
        index_bytes = json_bytes(index)
        all_files = dict(self.files)
        all_files['INDEX.json'] = index_bytes
        all_files['INDEX.json.sha256'] = (sha(index_bytes) + '  INDEX.json\n').encode()
        temporary = destination.with_suffix(destination.suffix + '.tmp')
        need(not destination.exists() and not temporary.exists(), 'refusing to overwrite evidence archive')
        with tarfile.open(temporary, 'w:xz', preset=6) as archive:
            for name, value in sorted(all_files.items()):
                info = tarfile.TarInfo(name)
                info.size = len(value)
                info.mtime = 0
                info.uid = info.gid = 0
                info.uname = info.gname = ''
                info.mode = 0o644
                archive.addfile(info, io.BytesIO(value))
        os.replace(temporary, destination)
        return dict(file=destination.name, sha256=sha(destination.read_bytes()),
                    bytes=destination.stat().st_size, regular_utf8_members=len(self.files) + 2,
                    expanded_utf8_bytes=expanded + len(index_bytes)
                    + len(all_files['INDEX.json.sha256']))


def main():
    need(REPORT.is_file(), 'current RSC report is not published yet')
    report = json.loads(REPORT.read_text())
    need(report.get('schema') == 'scriptw-rsc-current-v1', 'foreign current report')
    archive = Archive()
    campaign, aggregate = archive.add_campaign()
    allowed_enrichment = {'evidence_archive', 'verification', 'source_identity', 'caveat'}
    report_core = {key: value for key, value in report.items() if key not in allowed_enrichment}
    aggregate_core = {key: value for key, value in aggregate.items() if key not in allowed_enrichment}
    need(report_core == aggregate_core
         and set(report) - set(aggregate) <= allowed_enrichment,
         'published report has an unrecognized difference from validated campaign aggregate')
    measured_source = archive.add_sources()
    archive.add_campaign_outputs()
    archive.add_core_summaries(aggregate)
    source_identity = dict(report.get('source_identity', {}))
    source_identity['candidate_measured_source'] = measured_source
    source_identity['final_worktree_snapshot'] = {
        'archive_prefix': 'source/',
        'git_head': subprocess.run(['git', 'rev-parse', 'HEAD'], cwd=ROOT, check=True,
                                    stdout=subprocess.PIPE).stdout.decode().strip(),
        'role': 'Final working tree after post-measurement edition-2021 rustfmt; candidate measured bytes are preserved separately above.',
    }
    report['source_identity'] = source_identity
    caveat = report.get('caveat', '')
    distinction = (' Candidate timing uses the exact source reconstruction recorded in candidate_measured_source; '
                   'the final worktree snapshot separately records post-measurement edition-2021 rustfmt. '
                   'The fixture-specific timing comparison makes no engine-parity claim.')
    if distinction.strip() not in caveat:
        report['caveat'] = caveat + distinction
    base_report = deepcopy(report)
    base_report.pop('evidence_archive', None)
    archive.add_bytes('reports/rsc-current-base.json', json_bytes(base_report))
    archive.add_bytes('README.txt', (
        'Current React Server Components evidence. The campaign directory retains the 24 checked '
        'baseline/candidate/V8 process reports, resource receipts and raw stdout/stderr. '
        'Fixtures, source snapshots, producer identities, verification logs and unscored baseline/candidate profile '
        'summaries are inert UTF-8. Earlier focused failures are retained as checkpoint history; '
        'the current passing scope is recorded by the candidate-focused and broad summaries. '
        'The Intl source-identity gate remains open at 1/15 passing; its 14 stale identities are outside '
        'the RSC fixture qualification. '
        'Profile windows are diagnostic only. perf.data, executables, caches, Wasm/native payloads '
        'and node_modules are excluded. The archived current report omits its later evidence_archive '
        'field so the archive hash is not self-referential.\n').encode())
    destination = ROOT / 'docs/rust-rewrite' / f"rsc-current-evidence-{report['date']}.tar.xz"
    metadata = archive.write(destination)
    report['evidence_archive'] = metadata
    temporary_report = REPORT.with_suffix(REPORT.suffix + '.tmp')
    need(not temporary_report.exists(), 'report publication temporary already exists')
    temporary_report.write_bytes(json_bytes(report))
    os.replace(temporary_report, REPORT)
    print(json.dumps({'archive': metadata, 'over_5mb': metadata['bytes'] > ARCHIVE_LIMIT,
                      'members': len(archive.files)}, sort_keys=True))


if __name__ == '__main__':
    main()
