from pathlib import Path
import hashlib,json,os,sys
ROOT=Path.cwd()
sys.path.insert(0,str(ROOT/'scripts'))
from limited_verification import limited_environment,require_kernel_budget
from benchmark_metrics import measure_process,digest
from application_benchmarks import checked_product_stdout,validate_manifest
require_kernel_budget(4*1024**3)
base=ROOT/'target/rsc-platform-work'
fixtures=ROOT/'target/application-benchmarks-20261102/generated-v2'
binary=base/'candidate-frozen/scriptw'
output=base/'candidate-controls'
output.mkdir(exist_ok=False)
manifest=json.loads((fixtures/'manifest.json').read_text())
support=json.loads((fixtures/'support.json').read_text())
cases=[{'label':k,'file':'capability-'+k+'.js','stdout':support['expected'][k]} for k in ['rsc-sync','rsc-async']]
cases += [{'label':c['file'][:-3],'file':c['file'],'stdout':c['stdout']} for c in validate_manifest(manifest)]
rows=[]
for case in cases:
 name=case['label'];folder=output/name;folder.mkdir();(folder/'tmp').mkdir();(folder/'cache').mkdir()
 env=limited_environment();env.update(TMPDIR=str(folder/'tmp'),SCRIPTW_CACHE_DIR=str(folder/'cache'))
 argv=[str(binary),'--jobs','1','run',str(fixtures/case['file'])]
 with (folder/'stdout').open('xb') as out,(folder/'stderr').open('xb') as err:
  resources=measure_process(argv,cwd=ROOT,env=env,stdout=out,stderr=err,timeout=60,time_binary=ROOT/'target/performance-worker-cpu/tools/time')
 row=dict(label=name,argv=argv,source_sha256=digest(fixtures/case['file']),executable_sha256=digest(binary),resources=resources,stdout_sha256=digest(folder/'stdout'),stderr_sha256=digest(folder/'stderr'),expected_sha256=hashlib.sha256(case['stdout'].encode()).hexdigest())
 rows.append(row)
 (base/'candidate-controls.json').write_text(json.dumps(rows,indent=2)+'\n')
 assert resources['exit_code']==0 and not resources['timed_out'],row
 row['guest_output_and_backend_outcome_match']=checked_product_stdout((folder/'stdout').read_text(),case['stdout'])
 assert not (folder/'stderr').read_text(),name
 (base/'candidate-controls.json').write_text(json.dumps(rows,indent=2)+'\n')
 print(name,round(resources['elapsed_ns']/1e9,3),'s exact',flush=True)
