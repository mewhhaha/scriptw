"""Verify a staged or copied publication and checkpoint preservation; read only."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess
import tarfile
from common import BASE_GIT, ROOT, git, read, sha


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--stage', type=Path, required=True)
    parser.add_argument('--canonical', action='store_true', help='verify root copied reports/archive and rendered charts')
    args = parser.parse_args()
    ready = read(args.stage / 'publication-ready.json')
    assert ready['complete'] and ready['canonical_files_written'] is False
    directory = args.stage
    metadata = ready['staged_archive']
    if args.canonical:
        directory = ROOT / 'docs/rust-rewrite'
        metadata = ready['evidence_archive']
    archive_path = ROOT / metadata['file']
    assert sha(archive_path) == metadata['sha256'] and archive_path.stat().st_size == metadata['bytes']
    with tarfile.open(archive_path, 'r:xz') as packed:
        index_bytes = packed.extractfile('INDEX.json').read()
        assert packed.extractfile('INDEX.json.sha256').read().decode().strip() == hashlib.sha256(index_bytes).hexdigest() + '  INDEX.json'
        index = json.loads(index_bytes)
        members = packed.getmembers()
        assert len(members) == len(index['members']) + 2
        assert {member.name for member in members} == {row['path'] for row in index['members']} | {'INDEX.json', 'INDEX.json.sha256'}
        assert all(member.isfile() and member.mode == 0o644 for member in members)
        for row in index['members']:
            value = packed.extractfile(row['path']).read()
            assert hashlib.sha256(value).hexdigest() == row['sha256'] and len(value) == row['bytes']
            assert b'\0' not in value
            value.decode('utf-8', errors='strict')
        for name in ready['reports']:
            public = read(directory / name)
            assert public.pop('evidence_archive') == ready['evidence_archive']
            assert public == json.loads(packed.extractfile('reports/' + name).read())
            if args.canonical:
                assert (directory / name).read_bytes() == (args.stage / name).read_bytes()
        situations = json.loads(packed.extractfile('reports/situations-current.json').read())
        publication = situations['publication']
        if 'delivered_source' in publication:
            measured = publication['measured_source']['manifest_sha256']
            delivered = publication['delivered_source']['manifest_sha256']
            before_manifest = packed.extractfile('source/measured/manifest.json').read()
            after_manifest = packed.extractfile('source/delivered-test-corrected/manifest.json').read()
            assert hashlib.sha256(before_manifest).hexdigest() == measured
            assert hashlib.sha256(after_manifest).hexdigest() == delivered and measured != delivered
            proof = json.loads(packed.extractfile('verification/exact-test-source-equivalence.json').read())
            assert proof['measured_source']['sha256'] == measured and proof['delivered_source']['sha256'] == delivered
            expected = ['crates/scriptw-engine/tests/aot_language/aot_numeric_body.rs', 'crates/scriptw-engine/tests/aot_language/aot_strict_arguments_projection.rs']
            assert proof['changed_files'] == expected
            old, new = json.loads(before_manifest), json.loads(after_manifest)
            assert sorted(path for path in old['files'] if old['files'][path] != new['files'][path]) == expected
            for path in expected:
                before = packed.extractfile('source/measured/files/' + path).read()
                after = packed.extractfile('source/delivered-test-corrected/files/' + path).read()
                assert before.count(b'$262.createRealm()') == 1 and after == before.replace(b'$262.createRealm()', b'__scriptwCreateRealm()')
                assert hashlib.sha256(before).hexdigest() == old['files'][path]
                assert hashlib.sha256(after).hexdigest() == new['files'][path]
            assert hashlib.sha256(packed.extractfile('verification/compiler_fingerprint.rs').read()).hexdigest() == proof['compiler_input_exclusion']['implementation_sha256']
            assert hashlib.sha256(packed.extractfile('verification/compiler-build.rs').read()).hexdigest() == proof['compiler_input_exclusion']['build_script_sha256']
            assert next(row for row in publication['coverage']['fresh_native'] if row['target'] == 'aot_language')['source_manifest_sha256'] == delivered
            focus_ref = publication['coverage']['focused_qualification']
            focus_bytes = packed.extractfile(focus_ref['archive_path']).read()
            assert hashlib.sha256(focus_bytes).hexdigest() == focus_ref['sha256']
            focused = json.loads(focus_bytes)
            assert focused['source_manifest_sha256'] == measured and focused['delivered_source_manifest_sha256'] == delivered
            unions = [row for row in focused['scopes'] if row.get('scope_kind') == 'qualified_union']
            assert len(unions) == 2
            for union in unions:
                original, recovered = union['original_failed_scope'], union['corrected_filtered_scope']
                assert original['outcomes']['failed'] == 1 and original['exit_code'] == 101 and original['source_manifest_sha256'] == measured
                assert recovered['outcomes']['passed'] == 1 and recovered['exit_code'] == 0 and recovered['source_manifest_sha256'] == delivered
                assert not set(union['preserved_passed_tests']) & set(union['recovered_tests'])
                assert set(union['inventory']) == set(union['preserved_passed_tests']) | set(union['recovered_tests'])
                assert '--exact' in recovered['argv']
        binding = json.loads(packed.extractfile('baseline/binding.json').read())
        old_archive = binding['evidence_archive']
        original = git('show', BASE_GIT + ':' + old_archive['file'])
        assert (ROOT / old_archive['file']).read_bytes() == original
        assert hashlib.sha256(original).hexdigest() == old_archive['sha256']
    before = git('show', BASE_GIT + ':README.md')
    after = (ROOT / 'README.md').read_bytes()
    for marker in ('runtime-comparison', 'application-benchmarks', 'scriptw-status', 'scriptw-test-graph'):
        pattern = re.compile(rb'<!-- ' + marker.encode() + rb':start -->.*?<!-- ' + marker.encode() + rb':end -->', re.S)
        assert pattern.search(after).group() == pattern.search(before).group(), marker
    for relative in ('docs/rust-rewrite/test262-current.md', 'docs/rust-rewrite/assets/test262-status.svg'):
        assert (ROOT / relative).read_bytes() == git('show', BASE_GIT + ':' + relative)
    folders = ('docs/rust-rewrite/assets/situations-current', 'docs/rust-rewrite/assets/rsc-current')
    old_paths = set(git('ls-tree', '-r', '--name-only', BASE_GIT, '--', *folders).decode().splitlines())
    expected = {path for path in old_paths if path.endswith('.svg')}
    actual = {path.relative_to(ROOT).as_posix() for folder in folders for path in (ROOT / folder).glob('*.svg')}
    assert len(actual) == 12 and actual == expected
    if args.canonical:
        for name in ('react-allocation-current.json', 'react-attribution-current.json', 'rsc-wasm-size-current.json'):
            if name not in ready['reports'] and not (args.stage / name).exists():
                assert (directory / name).read_bytes() == git('show', BASE_GIT + ':docs/rust-rewrite/' + name), 'historical diagnostic was modified without fresh current evidence'
    print(json.dumps(dict(complete=True, canonical=args.canonical, archive_sha256=metadata['sha256'],
        inert_members=len(index['members']) + 2, reports=ready['reports'], preserved_charts=12,
        preserved_readme_blocks=4, pinned_test262_unchanged=True)))


if __name__ == '__main__':
    main()
