Source only. Six Python ASTs and publisher argument/import loading checked. The actual exact-two-expression measured/delivered source boundary also passed a read-only check. No
qualification, native build/test, Node process, measurement or publication run.
No counts asserted. Helpers read the retained base from the active admission.

Only after root retains the measured pilot, with exact-source receipts:

```sh
b=target/performance-v8-climb-20261104/strict-arguments-execution
python3 -B "$b/publication-tools/qualify_reuse.py" --source "$b/source-corrected-1/manifest.json" --delivered-source "$b/source-corrected-2/manifest.json" --source-equivalence "$b/realm-test-correction-1/source-equivalence.json" --output "$b/reuse-ir-1"
python3 -B "$b/publication-tools/run_broad.py" --source "$b/source-corrected-1/manifest.json" --focused-producer "$b/build-2/receipt.json" --pilot "$b/rsc-pilot-1/aggregate.json" --pilot-retained --delivered-source "$b/source-corrected-2/manifest.json" --source-equivalence "$b/realm-test-correction-1/source-equivalence.json" --corrected-producer "$b/realm-recovery-1/receipt.json" --focused-qualified "$b/focused-qualified-1/receipt.json" --reuse-proof "$b/reuse-ir-1/reuse-proof.json" --output "$b/broad-1"
```

The broad driver preserves the measured source1 emission image and delivered source2 language image, caps each child, builds only missing targets, inventories actual
frozen executables, and runs AOT unit/emission/six structural plus Engine unit/four
integrations. Only the IR/front dependency scope is historical reuse. Fresh AOT
must reproduce exactly the four failed test names in the admitted publication.
The whole receipt remains incomplete if any other failure interrupts execution.
`--target` selects a remaining subset; a subset receipt cannot publish as complete.
The explicit two-expression Realm test correction is supported by exact byte and compiler-input checks. Focused qualification calls the existing validator, retains its original failed filters, and preserves the disjoint original passes plus exact recovered tests. Other source corrections or unions need explicit review.

After actual full 21-case situation (504 processes/60,984 checked calls) and RSC
(24 processes/480 checked calls) completion, use:

```sh
python3 -B "$b/publication-tools/publish.py" \
  --source "$b/source-corrected-1/manifest.json" \
  --delivered-source "$b/source-corrected-2/manifest.json" \
  --source-equivalence "$b/realm-test-correction-1/source-equivalence.json" \
  --focused-qualified "$b/focused-qualified-1/receipt.json" \
  --native-report "$b/broad-1/native-verification.json" \
  --products-receipt "$b/build-2/receipt.json" \
  --feature-comparison "$b/product-feature-comparison.json" \
  --paired-retention "$b/paired-arguments/report.json" \
  --paired-situations-report "$b/situations-1/report.json" \
  --node-oracles "$b/node-oracles-1/receipt.json" \
  --situations "$b/situations-full-1" --rsc "$b/rsc-pilot-1" \
  --source-guards "$b/source-guards.stdout" --date 2026-11-05 \
  --extra-text-evidence "$b/imports-correction-1" \
  --extra-text-evidence "$b/source-initial" \
  --extra-text-evidence "$b/build-1" \
  --output "$b/publication-1"
python3 -B "$b/publication-tools/check_publication.py" --stage "$b/publication-1"
```

Paths above are prospective examples; pass the actual completed directories and
exact guard stdout. The three-case report is only the paired-image input; it
cannot substitute for the full 21-case argument. Original Node records are
validated by unchanged fixture bytes, adapters, Node image and logs. Paired
retention requires the actual 80 balanced five-actor process rows and their raw
logs. Add the actual hash-witness controls/cost receipts and pinned stages using
`--extra-text-evidence`; these remain separate inert tooling evidence, never
scored measurements. No census data is relabeled as request evidence. ABI52
ForInSet is outside this batch.

Publisher writes only a fresh target staging directory. Archive basename is
`situations-evidence-2026-11-05-calls.tar.xz`; prior archives remain distinct and
unnested. It refreshes only situations/rsc JSON. No old allocation, PMU or size
JSON is rewritten. Excluded native/Wasm/cache images never enter the UTF-8,
NUL-free indexed archive. Root owns canonical report/archive copies, all twelve
latest chart refreshes, README/docs, final preservation checks, Git and push.
After those copies/rendering, run the same checker with `--canonical`.
