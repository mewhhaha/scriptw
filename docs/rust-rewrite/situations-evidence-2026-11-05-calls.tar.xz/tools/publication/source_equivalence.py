"""Bind the exact authorized two Realm test expressions; never weaken assertions."""
import argparse
import difflib
import hashlib
import importlib.util
import sys
from pathlib import Path
import re
from common import ROOT, check_source, git, read, save, sha

TEST_FILES = ('crates/scriptw-engine/tests/aot_language/aot_numeric_body.rs',
    'crates/scriptw-engine/tests/aot_language/aot_strict_arguments_projection.rs')
FINGERPRINT = 'crates/scriptw-engine/compiler_fingerprint.rs'
BUILD_SCRIPT = 'crates/scriptw-engine/build.rs'


def frozen_bytes(manifest, relative):
    data = read(manifest)
    if relative in data['files']:
        path = manifest.parent / 'files' / relative
        assert sha(path) == data['files'][relative]
        return path.read_bytes()
    return git('show', data['base_git'] + ':' + relative)


def string_array(source, name):
    match = re.search(r'const\s+' + name + r'\s*:[^=]+?=\s*&\[(.*?)\];', source, re.S)
    assert match, name
    return re.findall(r'"([^"\n]+)"', re.sub(r'//[^\n]*', '', match[1]))


def equivalence(measured, delivered):
    measured, delivered = Path(measured).resolve(strict=True), Path(delivered).resolve(strict=True)
    old, new = read(measured), check_source(delivered)
    assert old['base_git'] == new['base_git'] and old['admission_sha256'] == new['admission_sha256']
    assert set(old['files']) == set(new['files'])
    assert old['tracked_files'] == new['tracked_files'] and old['untracked_files'] == new['untracked_files']
    changed = [path for path in old['files'] if old['files'][path] != new['files'][path]]
    assert sorted(changed) == list(TEST_FILES)
    tests, patches = [], []
    for relative in old['files']:
        assert sha(measured.parent / 'files' / relative) == old['files'][relative]
        assert sha(delivered.parent / 'files' / relative) == new['files'][relative]
        if relative not in TEST_FILES:
            assert old['files'][relative] == new['files'][relative]
            continue
        before, after = frozen_bytes(measured, relative), frozen_bytes(delivered, relative)
        assert before.count(b'$262.createRealm()') == 1
        assert after == before.replace(b'$262.createRealm()', b'__scriptwCreateRealm()')
        tests.append(dict(path=relative, before_sha256=sha(measured.parent / 'files' / relative), after_sha256=sha(delivered.parent / 'files' / relative)))
        patches.append(''.join(difflib.unified_diff(before.decode().splitlines(keepends=True), after.decode().splitlines(keepends=True), fromfile='a/' + relative, tofile='b/' + relative)))
    implementation, build = frozen_bytes(measured, FINGERPRINT), frozen_bytes(measured, BUILD_SCRIPT)
    assert implementation == frozen_bytes(delivered, FINGERPRINT) == (ROOT / FINGERPRINT).read_bytes()
    assert build == frozen_bytes(delivered, BUILD_SCRIPT) == (ROOT / BUILD_SCRIPT).read_bytes()
    text = implementation.decode()
    compiler = string_array(text, 'COMPILER_INPUTS')
    native = string_array(text, 'NATIVE_COMPILER_INPUTS')
    for relative in TEST_FILES:
        assert not any(Path(relative).is_relative_to(prefix) for prefix in compiler + native)
    assert 'input_files(workspace, COMPILER_INPUTS, TEST_ONLY_INPUTS)' in text
    assert 'input_files(workspace, NATIVE_COMPILER_INPUTS, &[])' in text
    return dict(schema='scriptw-calls-realm-test-equivalence-v1', complete=True,
        measured_source=dict(path=str(measured), sha256=sha(measured)),
        delivered_source=dict(path=str(delivered), sha256=sha(delivered)), changed_files=list(TEST_FILES), tests=tests,
        patch=''.join(patches), compiler_input_exclusion=dict(implementation=FINGERPRINT,
            implementation_sha256=hashlib.sha256(implementation).hexdigest(), build_script=BUILD_SCRIPT,
            build_script_sha256=hashlib.sha256(build).hexdigest(), test_directory='crates/scriptw-engine/tests',
            outside_compiler_inputs=True, outside_native_compiler_inputs=True),
        limits='Exactly two Realm constructor expressions in new integration tests. All assertions and product bytes remain identical. Original failed receipts remain failed; measured production source and executable identities are not rewritten.')


def check_bound_source(measured, delivered=None, proof_path=None):
    if delivered is None:
        assert proof_path is None
        return check_source(measured)
    proof = equivalence(measured, delivered)
    assert proof_path is not None
    supplied = read(proof_path)
    if supplied['schema'] == 'scriptw-calls-realm-test-equivalence-v1':
        assert supplied == proof
    else:
        assert supplied['schema'] == 'scriptw-realm-test-host-source-equivalence-v1' and supplied['complete']
        assert supplied['measured_source'] == proof['measured_source']
        assert supplied['production_compiler_inputs_unchanged'] is True and supplied['native_compiler_inputs_unchanged'] is True
        assert supplied['compiler_inputs_implementation']['sha256'] == proof['compiler_input_exclusion']['implementation_sha256']
        assert supplied['compiler_build_script']['sha256'] == proof['compiler_input_exclusion']['build_script_sha256']
        expected = {row['path']: (row['before_sha256'], row['after_sha256']) for row in proof['tests']}
        actual = {row['path']: (row['base_sha256'], row['candidate_sha256']) for row in supplied['files']}
        assert len(supplied['files']) == 2 and actual == expected
        assert sha(Path(proof_path).parent / 'correction.patch') == supplied['patch_sha256']
        for row in supplied['files']:
            assert sha(Path(proof_path).parent / 'before' / row['path']) == row['base_sha256']
            assert sha(Path(proof_path).parent / 'candidate' / row['path']) == row['candidate_sha256']
        for diagnostic in supplied['original_diagnostics']:
            assert sha(diagnostic['path']) == diagnostic['sha256']
    return read(delivered)


def validate_focused(path, measured, delivered):
    path = Path(path).resolve(strict=True)
    report = read(path)
    helper = Path(__file__).resolve().parents[1] / 'qualify_focused.py'
    assert sha(helper) == report['tooling_sha256']
    spec = importlib.util.spec_from_file_location('calls_focused_qualification', helper)
    utility = importlib.util.module_from_spec(spec)
    sys.path.append(str(helper.parent))
    try:
        spec.loader.exec_module(utility)
    finally:
        sys.path.pop()
    utility.validate(report, measured)
    assert report['delivered_source_manifest_sha256'] == sha(delivered)
    assert report['source_manifest_sha256'] == sha(measured)
    assert len(report['scopes']) == 4
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--delivered-source', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    result = equivalence(args.source, args.delivered_source)
    output = args.output.resolve()
    assert output.is_relative_to(ROOT / 'target') and not output.exists() and output.parent.is_dir()
    save(output, result)
    print(output)


if __name__ == '__main__':
    main()
