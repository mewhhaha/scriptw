"""Qualify only unchanged IR/front inputs; retain original source/binary/log proof."""
import argparse
import copy
import hashlib
from pathlib import Path
import shutil
from common import BASE_GIT, ROOT, check_source, git, read, save, sha

from source_equivalence import check_bound_source

TARGETS = ('scriptw_ir_integration',)
POLICIES = ('Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml', '.cargo', 'vendor',
    'crates/scriptw-ir', 'crates/scriptw-front', 'crates/scriptw-runtime',
    'crates/scriptw-intl', 'crates/scriptw-intl-build-data')


def unchanged_inputs():
    assert not git('diff', '--name-only', BASE_GIT, '--', *POLICIES).strip(), 'IR/front dependency inputs changed'
    assert not git('ls-files', '--others', '--exclude-standard', '--', *POLICIES).strip(), 'untracked IR/front dependency inputs'
    return dict(unchanged_scopes=list(POLICIES), lockfile_sha256=sha(ROOT / 'Cargo.lock'))


def baseline():
    import json
    raw = git('show', BASE_GIT + ':docs/rust-rewrite/situations-current.json')
    return raw, json.loads(raw)


def validate_reuse(proof, source_sha, delivered_source=None):
    assert proof['complete'] and proof['source_manifest_sha256'] == source_sha and proof['base_git'] == BASE_GIT
    assert sha(proof['source_manifest']) == source_sha
    bound = proof.get('source_equivalence')
    delivered = None
    proof_path = None
    if bound:
        assert sha(bound['path']) == bound['sha256']
        proof_path = bound['path']
        delivered = proof['delivered_source_manifest']
        assert sha(delivered) == proof['delivered_source_manifest_sha256']
    if delivered_source is not None:
        assert Path(delivered_source).resolve() == Path(delivered).resolve()
    check_bound_source(proof['source_manifest'], delivered, proof_path)
    assert proof['unchanged_inputs'] == unchanged_inputs()
    raw, public = baseline()
    assert hashlib.sha256(raw).hexdigest() == proof['baseline_public_report_sha256']
    originals = public['publication']['coverage']['fresh_native'] + public['publication']['coverage'].get('reused_native', [])
    assert [row['target'] for row in proof['original_scopes']] == list(TARGETS)
    for row in proof['original_scopes']:
        prior = [entry for entry in originals if entry['target'] == row['target']]
        assert len(prior) == 1 and row['original_scope'] == prior[0]
        assert row['source_manifest_sha256'] == prior[0]['source_manifest_sha256']
        assert row['executable_sha256'] == prior[0]['executable_sha256']
        assert row['qualified_final_source_manifest_sha256'] == source_sha and row['reused_unchanged_inputs'] is True
        for field in ('stdout', 'stderr'):
            retained = row['archived_' + field]
            assert sha(retained['path']) == retained['sha256'] == prior[0][field]['sha256']
            assert Path(retained['path']).stat().st_size == retained['bytes'] == prior[0][field]['bytes']
    return proof


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--delivered-source', type=Path)
    parser.add_argument('--source-equivalence', type=Path)
    args = parser.parse_args()
    if args.delivered_source:
        args.delivered_source = args.delivered_source.resolve(strict=True)
    if args.source_equivalence:
        args.source_equivalence = args.source_equivalence.resolve(strict=True)
    source = args.source.resolve(strict=True)
    check_bound_source(source, args.delivered_source, args.source_equivalence)
    witness = unchanged_inputs()
    raw, public = baseline()
    output = args.output.resolve()
    assert output.is_relative_to(ROOT / 'target') and not output.exists()
    output.mkdir(parents=True)
    rows = public['publication']['coverage']['fresh_native'] + public['publication']['coverage'].get('reused_native', [])
    scopes = []
    for target in TARGETS:
        matches = [row for row in rows if row['target'] == target]
        assert len(matches) == 1
        original = matches[0]
        assert original['outcomes']['state'] == 'ok' and original['outcomes']['passed'] > 0
        assert original['outcomes']['failed'] == original['outcomes']['ignored'] == 0 and original['exit_code'] == 0
        row = copy.deepcopy(original)
        row['original_scope'] = copy.deepcopy(original)
        for field in ('stdout', 'stderr'):
            retained = original.get('archived_' + field, original[field])
            path = ROOT / retained['path']
            assert sha(path) == original[field]['sha256'] and path.stat().st_size == original[field]['bytes']
            copied = output / (target + '.' + field)
            shutil.copy2(path, copied)
            row['archived_' + field] = dict(path=str(copied), sha256=sha(copied), bytes=copied.stat().st_size)
        row.update(reused_unchanged_inputs=True, qualified_final_source_manifest_sha256=sha(source),
            qualification='Unchanged IR/front dependency inputs only. Original source, executable digest and test outcomes remain historical.')
        scopes.append(row)
    proof = dict(schema='scriptw-calls-ir-reuse-v1', complete=True, base_git=BASE_GIT,
        source_manifest=str(source), source_manifest_sha256=sha(source), unchanged_inputs=witness,
        baseline_public_report_sha256=hashlib.sha256(raw).hexdigest(), original_scopes=scopes,
        totals=dict(ir=sum(row['outcomes']['passed'] for row in scopes)),
        limits='No AOT, emission, structural or Engine reuse. Original executable digest is retained evidence, not a claim its old pathname still contains that image. Candidate toolchain must match the baseline before publication.')
    if args.delivered_source:
        proof.update(delivered_source_manifest=str(args.delivered_source.resolve()), delivered_source_manifest_sha256=sha(args.delivered_source),
            source_equivalence=dict(path=str(args.source_equivalence.resolve()), sha256=sha(args.source_equivalence)))
    validate_reuse(proof, sha(source), args.delivered_source)
    save(output / 'reuse-proof.json', proof)
    print(output / 'reuse-proof.json')


if __name__ == '__main__':
    main()
