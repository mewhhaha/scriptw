"""Stage qualified projection/numeric-body measurements and inert text evidence; never write docs."""
import argparse
import copy
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import tarfile
from common import BASE, BASE_GIT, ROOT, check_source, git, read, save, sha
from run_broad import ENGINE, STRUCTURAL, SUMMARY, failures
from qualify_reuse import validate_reuse
from source_equivalence import check_bound_source, equivalence, validate_focused

ARCHIVE_TOOL = ROOT / 'target/react-performance-20261103/archive_final.py'
REPORTS = ('situations-current.json', 'rsc-current.json', 'rsc-wasm-size-current.json',
           'react-attribution-current.json', 'react-allocation-current.json')
EXCLUDED = {'.swpc', '.wasm', '.so', '.a', '.rlib', '.rmeta', '.o', '.exe', '.bin', '.xz', '.zip'}


def encoded(value):
    return (json.dumps(value, indent=2, allow_nan=False) + '\n').encode()


def reference(path):
    path = Path(path).resolve(strict=True)
    return dict(path=str(path.relative_to(ROOT)), sha256=sha(path), bytes=path.stat().st_size)


def text_tree(archive, folder, prefix):
    folder = Path(folder).resolve(strict=True)
    for path in sorted(folder.rglob('*')):
        assert not path.is_symlink(), path
        if not path.is_file():
            continue
        relative = path.relative_to(folder)
        if any(part in ('cache', 'tmp', 'scratch', '__pycache__', 'node_modules') for part in relative.parts):
            continue
        if path.suffix in EXCLUDED or path.name.startswith('perf.data'):
            continue
        with path.open('rb') as stream:
            magic = stream.read(4)
        if magic in (b'\x7fELF', b'\0asm'):
            continue
        data = path.read_bytes()
        member = prefix + '/' + relative.as_posix()
        if path.suffix == '.gz':
            data = gzip.decompress(data)
            member = member[:-3]
        archive.add_bytes(member, data)


def verified_native(path, source_sha, delivered_source=None):
    report = read(path)
    assert report['complete'] and report['full_native_target_set_complete']
    assert report['source_manifest_sha256'] == source_sha
    assert report['pilot']['root_retained'] is True
    allowed_sources = {source_sha}
    if delivered_source is not None:
        delivered_sha = sha(delivered_source)
        allowed_sources.add(delivered_sha)
        assert report['delivered_source_manifest_sha256'] == delivered_sha
        assert sha(report['source_equivalence']['path']) == report['source_equivalence']['sha256']
        assert sha(report['corrected_producer']['path']) == report['corrected_producer']['sha256']
    expected = {'scriptw_aot_wasm', 'emission', *STRUCTURAL, 'scriptw_engine', *ENGINE}
    assert {row['target'] for row in report['scopes']} == expected
    assert len(report['scopes']) == len(expected)
    assert sha(report['reuse_proof']['path']) == report['reuse_proof']['sha256']
    reuse = validate_reuse(read(report['reuse_proof']['path']), source_sha, delivered_source)
    assert report['reused_native'] == reuse['original_scopes']
    known = set(report['known_preexisting_aot_failures']['names'])
    assert len(known) == 4
    prior = json.loads(git('show', BASE_GIT + ':docs/rust-rewrite/situations-current.json'))
    original_aot = [row for row in prior['publication']['coverage']['fresh_native'] + prior['publication']['coverage'].get('reused_native', []) if row['target'] == 'scriptw_aot_wasm' and row['outcomes']['failed'] == 4]
    assert len(original_aot) == 1 and known == set(original_aot[0]['failures'])
    artifacts = {row['artifact']['target']['name']: row for row in report['artifacts']}
    assert set(artifacts) == expected and len(artifacts) == len(report['artifacts'])
    for row in report['scopes']:
        assert row['source_manifest_sha256'] in allowed_sources and not row.get('timed_out')
        stdout, stderr = Path(row['stdout']), Path(row['stderr'])
        assert sha(stdout) == row['stdout_sha256'] and sha(stderr) == row['stderr_sha256']
        matches = SUMMARY.findall(stdout.read_text())
        assert len(matches) == 1
        state, passed, failed, ignored = matches[0]
        actual = dict(state=state, passed=int(passed), failed=int(failed), ignored=int(ignored))
        assert actual == row['outcomes'] and int(ignored) == 0
        inventory = report['inventories'][row['target']]
        artifact = artifacts[row['target']]
        assert artifact['source_manifest_sha256'] == row['source_manifest_sha256'] and artifact['artifact']['profile']['test'] is True
        assert sha(artifact['frozen_path']) == artifact['executable_sha256'] == row['executable_sha256']
        assert inventory['count'] == len(inventory['tests']) == int(passed) + int(failed)
        assert inventory['count'] > 0 and inventory['executable_sha256'] == row['executable_sha256']
        assert not any(not value.startswith('-') for value in row['argv'][1:]), 'broad scope contains a filter'
        if row['target'] == 'scriptw_aot_wasm':
            assert state == 'FAILED' and row['exit_code'] == 101 and int(failed) == 4
            assert failures(stdout.read_text()) == set(row['failures']) == known
        else:
            assert state == 'ok' and row['exit_code'] == 0 and int(failed) == 0
    for row in report['producer_commands']:
        assert row['source_manifest_sha256'] in allowed_sources
        assert row['exit_code'] == 0 and not row.get('timed_out')
        assert sha(row['stdout']) == row['stdout_sha256'] and sha(row['stderr']) == row['stderr_sha256']
    return report


def compact(report):
    result = copy.deepcopy(report)
    for key in ('rows', 'commands', 'retained_files'):
        result.pop(key, None)
    for case in result['cases']:
        for actor in case['runtimes'].values():
            for process in actor['processes']:
                process.pop('samples_ns', None)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, required=True, help='exact immutable measured manifest.json; imports-only child manifests are accepted by active authority')
    parser.add_argument('--native-report', type=Path, required=True)
    parser.add_argument('--delivered-source', type=Path)
    parser.add_argument('--source-equivalence', type=Path)
    parser.add_argument('--focused-qualified', type=Path, help='actual focused disjoint-union receipt; required with delivered source')
    parser.add_argument('--feature-comparison', type=Path, required=True)
    parser.add_argument('--paired-retention', type=Path, required=True)
    parser.add_argument('--paired-situations-report', type=Path, required=True, help='original candidate three-case report used by paired images')
    parser.add_argument('--node-oracles', type=Path, required=True)
    parser.add_argument('--products-receipt', type=Path, required=True)
    parser.add_argument('--situations', type=Path, required=True)
    parser.add_argument('--rsc', type=Path, required=True)
    parser.add_argument('--source-guards', type=Path, required=True)
    parser.add_argument('--date', required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--extra-text-evidence', type=Path, action='append', default=[])
    parser.add_argument('--rejected-text', type=Path, action='append', default=[], help='explicit rejected receipt/source patch/pilot-summary files only')
    args = parser.parse_args()
    if args.delivered_source:
        args.delivered_source = args.delivered_source.resolve(strict=True)
    if args.source_equivalence:
        args.source_equivalence = args.source_equivalence.resolve(strict=True)
    assert re.fullmatch(r'\d{4}-\d{2}-\d{2}', args.date)
    source = args.source.resolve(strict=True)
    source_sha = sha(source)
    def check_context():
        check_bound_source(source, args.delivered_source, args.source_equivalence)
    check_context()
    native = verified_native(args.native_report, source_sha, args.delivered_source)
    focused_qualification = None
    if args.delivered_source:
        assert args.focused_qualified is not None
        focused_qualification = validate_focused(args.focused_qualified, source, args.delivered_source)
        assert sha(native['focused_qualification']['path']) == native['focused_qualification']['sha256'] == sha(args.focused_qualified)
    products = read(args.products_receipt)
    assert products['complete'] and products['phase'] == 'focused-build' and products['source_manifest_sha256'] == source_sha
    product_artifacts = {row['artifact']['target']['name']: row for row in products['artifacts']}
    assert {'scriptw', 'rsc_baseline', 'compiler_precompiled_baseline'} <= product_artifacts.keys()
    for name, row in product_artifacts.items():
        expected_test = name in ('emission', 'aot_language')
        assert row['artifact']['profile']['test'] is expected_test
        assert row['source_manifest_sha256'] == source_sha and sha(row['frozen_path']) == row['sha256']
        assert sha(row['cargo_stdout']) == row['cargo_stdout_sha256']
    cli_build = [row for row in products['producer_commands'] if row['label'] == 'cli-only-build']
    assert len(cli_build) == 1 and cli_build[0]['exit_code'] == 0
    assert '--example' not in cli_build[0]['argv'] and '--test' not in cli_build[0]['argv']
    features = read(args.feature_comparison)
    assert features['complete'] and features['source_manifest_sha256'] == source_sha
    assert {row['role'] for row in features['roles']} == {'ordinary-examples', 'ordinary-cli'}
    assert all(row['ordinary_multiset_matches'] for row in features['roles'])
    for role in features['roles']:
        for side in ('baseline', 'candidate'):
            assert sha(role[side]['path']) == role[side]['sha256']
    paired = read(args.paired_retention)
    assert paired['complete'] and len(paired['rows']) == 80 and paired['checked_invocations'] == 9680
    assert paired['policy']['warmups'] == 100 and paired['policy']['samples'] == 21
    candidate_pins = [row for row in paired['sources'] if row['name'] == 'candidate']
    assert len(candidate_pins) == 1
    assert candidate_pins[0]['host_sha256'] == product_artifacts['compiler_precompiled_baseline']['sha256']
    candidate_report = args.paired_situations_report.resolve(strict=True)
    assert sha(candidate_report) == candidate_pins[0]['report_sha256']
    paired_inputs = read(candidate_report)
    assert paired_inputs['source_identity']['executable_sha256'] == candidate_pins[0]['host_sha256']
    groups = {}
    for row in paired['rows']:
        assert row['accounting']['exit_code'] == 0 and not row['accounting']['timed_out']
        assert len(row['samples_ns']) == 21 and all(value > 0 for value in row['samples_ns'])
        groups[row['file'], row['actor'], row['block']] = groups.get((row['file'], row['actor'], row['block']), 0) + 1
        stdout = args.paired_retention.parent / row['stdout']
        assert sha(stdout) == row['stdout_sha256']
        stderr = stdout.with_suffix('.stderr')
        assert sha(stderr) == row['stderr_sha256'] and stderr.stat().st_size == 0
    assert set(groups) == {(case, actor, block) for case in ('args-unused.js', 'args-observed.js')
        for actor in ('baseline-fast', 'candidate-fast', 'baseline-speed', 'candidate-speed', 'v8') for block in (0, 1)}
    assert set(groups.values()) == {4}
    oracles = read(args.node_oracles)
    assert oracles['complete'] and len(oracles['rows']) == 6
    fixture_modes = set()
    for row in oracles['rows']:
        fixture = ROOT / row['fixture']
        assert sha(fixture) == row['fixture_sha256'] == read(source)['files'][row['fixture']]
        assert row['exit_code'] == 0 and sha(row['argv'][0]) == row['node_sha256']
        assert sha(row['argv'][2]) == row['adapter_sha256']
        fixture_modes.add((fixture.name, row['mode']))
        for field in ('stdout', 'stderr'):
            log = args.node_oracles.parent / (fixture.name + '.' + row['mode'] + '.' + field)
            assert sha(log) == row[field + '_sha256']
    assert fixture_modes == {(fixture, mode) for fixture in ('strict_arguments_projection.js', 'numeric_body.js')
        for mode in ('Script', 'strictScript', 'Module')}
    guards = SUMMARY.findall(args.source_guards.read_text())
    assert guards and all(row[0] == 'ok' and row[2:] == ('0', '0') for row in guards)
    situations = read(args.situations / 'report.json')
    assert situations['complete'] and situations['status'] == 'complete'
    policy = situations['policy']
    assert len(situations['cases']) == 21 and policy['actors'] == ['scriptw-fast', 'scriptw-speed', 'v8']
    assert policy['warmups'] == 100 and policy['samples'] == 21
    processes = len(situations['cases']) * len(policy['actors']) * policy['blocks'] * policy['processes_per_actor_per_block']
    assert processes == 504
    assert processes * (policy['warmups'] + policy['samples']) == 60984
    assert len(situations['rows']) == processes and all(row['status'] == 'ok' for row in situations['rows'])
    assert situations['source_identity']['executable_sha256'] == product_artifacts['compiler_precompiled_baseline']['sha256']
    for case in situations['cases']:
        for actor in policy['actors']:
            runtime = case['runtimes'][actor]
            assert runtime['status'] == 'complete' and len(runtime['processes']) == policy['blocks'] * policy['processes_per_actor_per_block']
            assert all(len(row['samples_ns']) == policy['samples'] for row in runtime['processes'])
        receipts = [row for preparation in situations['preparations'] for row in preparation['cases'] if row['file'] == case['file']]
        assert len(receipts) == 2 and receipts[0]['program_wasm_sha256'] == receipts[1]['program_wasm_sha256']
    for row in situations['retained_files']:
        retained = (args.situations / row['path']).resolve(strict=True)
        assert retained.is_relative_to(args.situations.resolve()) and retained.is_file()
        assert sha(retained) == row['sha256'] and retained.stat().st_size == row['bytes']
    campaign = read(args.rsc / 'campaign.json')
    aggregate = read(args.rsc / 'aggregate.json')
    assert campaign['status'] == 'complete' and len(campaign['processes']) == 24
    assert aggregate['measurement']['campaign_sha256'] == sha(args.rsc / 'campaign.json')
    assert aggregate['measurement']['warmups'] == 3 and aggregate['measurement']['samples'] == 7
    assert aggregate['source_identity']['candidate_measured_source']['manifest_sha256'] == source_sha
    identity = aggregate['engines']['candidate']['identity']
    assert identity['executable_sha256'] == product_artifacts['rsc_baseline']['sha256']
    if args.source_equivalence:
        supplied_equivalence = read(args.source_equivalence)
        if 'expected_production_compiler_fingerprint' in supplied_equivalence:
            assert identity['source_fingerprint'] == supplied_equivalence['expected_production_compiler_fingerprint']
    assert identity['source_fingerprint'] == situations['source_identity']['source_fingerprint']
    balance = {}
    for row in campaign['processes']:
        assert row['status'] == 'complete'
        balance[row['block'], row['engine']] = balance.get((row['block'], row['engine']), 0) + 1
        for field in ('report', 'stdout', 'stderr'):
            assert sha(args.rsc / row[field]) == row[field + '_sha256']
    assert set(balance) == {(b, actor) for b in (0, 1) for actor in ('baseline', 'candidate', 'v8')}
    assert set(balance.values()) == {4}
    baseline = {name: json.loads(git('show', BASE_GIT + ':docs/rust-rewrite/' + name)) for name in REPORTS}
    assert aggregate['engines']['baseline']['identity'] == baseline['rsc-current.json']['engines']['candidate']['identity']
    assert identity['toolchain'] == baseline['rsc-current.json']['engines']['candidate']['identity']['toolchain'], 'IR reuse requires the unchanged toolchain'
    spec = importlib.util.spec_from_file_location('inert_archive', ARCHIVE_TOOL)
    utility = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(utility)
    archive = utility.Archive()
    old_archive = baseline['rsc-current.json']['evidence_archive']
    old_bytes = git('show', BASE_GIT + ':' + old_archive['file'])
    assert hashlib.sha256(old_bytes).hexdigest() == old_archive['sha256'] and len(old_bytes) == old_archive['bytes']
    binding = dict(git=BASE_GIT, evidence_archive=old_archive,
        preservation='Prior full evidence archive remains pinned at the admitted base; it is not nested or relabeled current.',
        public_reports={name: dict(path='baseline/reports/' + name, sha256=hashlib.sha256(git('show', BASE_GIT + ':docs/rust-rewrite/' + name)).hexdigest()) for name in REPORTS})
    for name in REPORTS:
        archive.add_bytes('baseline/reports/' + name, git('show', BASE_GIT + ':docs/rust-rewrite/' + name))
    archive.add_bytes('baseline/binding.json', encoded(binding))
    text_tree(archive, source.parent, 'source/measured')
    if args.delivered_source:
        text_tree(archive, args.delivered_source.parent, 'source/delivered-test-corrected')
        text_tree(archive, args.source_equivalence.parent, 'verification/test-correction')
        archive.add_bytes('verification/exact-test-source-equivalence.json', encoded(equivalence(source, args.delivered_source)))
        archive.add_file('verification/compiler_fingerprint.rs', ROOT / 'crates/scriptw-engine/compiler_fingerprint.rs')
        archive.add_file('verification/compiler-build.rs', ROOT / 'crates/scriptw-engine/build.rs')
        corrected_path = Path(native['corrected_producer']['path'])
        text_tree(archive, corrected_path.parent, 'verification/corrected-language')
        archive.add_file('verification/focused-qualified.json', args.focused_qualified)
        for index, original in enumerate(focused_qualification['original_receipts']):
            assert sha(original['path']) == original['sha256']
            text_tree(archive, Path(original['path']).parent, 'verification/focused-history/' + str(index))
    text_tree(archive, args.native_report.parent, 'verification/broad')
    text_tree(archive, args.products_receipt.parent, 'verification/products')
    text_tree(archive, args.situations, 'situations')
    text_tree(archive, args.rsc, 'rsc')
    archive.add_file('verification/source-guards.stdout', args.source_guards)
    for path in sorted(BASE.iterdir()):
        if path.is_file() and path.suffix in ('.py', '.json', '.stdout', '.stderr', '.md', '.cjs'):
            archive.add_file('tools-and-receipts/' + path.name, path)
    archive.add_file('tools/inert_archive.py', ARCHIVE_TOOL)
    native_log_roots = [(args.native_report.parent.resolve(), 'verification/broad')]
    reuse = validate_reuse(read(native['reuse_proof']['path']), source_sha, args.delivered_source)
    text_tree(archive, Path(native['reuse_proof']['path']).parent, 'verification/reused')
    coverage = dict(fresh_native=native['scopes'], reused_native=reuse['original_scopes'], reuse_proof=native['reuse_proof'],
        producer_commands=native['producer_commands'], source_guards_passed=sum(int(row[1]) for row in guards),
        source_guards=reference(args.source_guards), cases=len(situations['cases']), actors=len(policy['actors']),
        fresh_execution_processes=processes, checked_invocations=processes * (policy['warmups'] + policy['samples']),
        warmup_invocations=processes * policy['warmups'], measured_invocations=processes * policy['samples'],
        rsc_fresh_processes=len(campaign['processes']), rsc_checked_invocations=len(campaign['processes']) * 2 * 10,
        limits='Fresh AOT unit, emission, structural and Engine scopes; only unchanged IR/front inputs are historical reuse. Four exact prior AOT failures remain failures in the fresh run. Focused cases overlap full scopes. Pinned Test262 was not rerun.')
    coverage['fresh_native'] = copy.deepcopy(native['scopes'])
    if focused_qualification:
        coverage['focused_qualification'] = dict(reference(args.focused_qualified), archive_path='verification/focused-qualified.json',
            limits=focused_qualification['limits'], original_failed_filters_retained=True, full_filters_rerun=False)
    coverage['paired_retention'] = dict(reference(args.paired_retention), archive_path='verification/paired-retention/report.json', fresh_processes=len(paired['rows']), checked_invocations=paired['checked_invocations'])
    coverage['node_oracles'] = dict(reference(args.node_oracles), archive_path='verification/node-oracles/receipt.json', fresh_processes=len(oracles['rows']), qualification='Original pinned Node fixture contexts retained by exact unchanged fixture bytes; no new Node run asserted.')
    coverage['product_feature_comparison'] = dict(reference(args.feature_comparison), archive_path='verification/product-feature-comparison.json')
    coverage['producer_commands'] = copy.deepcopy(native['producer_commands'])
    fresh_by_target = {row['target']: row['outcomes'] for row in native['scopes']}
    coverage['fresh_engine_unit_passed'] = fresh_by_target['scriptw_engine']['passed']
    coverage['fresh_engine_integrations'] = dict(total_passed=sum(fresh_by_target[target]['passed'] for target in ENGINE),
        by_target={target: fresh_by_target[target]['passed'] for target in ENGINE})
    coverage['reused_native_totals'] = reuse['totals']
    coverage['reuse_proof'] = dict(native['reuse_proof'], archive_path='verification/reused/reuse-proof.json')

    def archive_log_references(row):
        for field in ('stdout', 'stderr'):
            path = Path(row[field]).resolve(strict=True)
            matches = [(folder, prefix) for folder, prefix in native_log_roots if path.is_relative_to(folder)]
            assert len(matches) == 1, 'native log archive root missing/ambiguous'
            folder, prefix = matches[0]
            row[field] = dict(reference(path), archive_path=prefix + '/' + path.relative_to(folder).as_posix())

    for row in (*coverage['fresh_native'], *coverage['producer_commands']):
        archive_log_references(row)
    measured = dict(path=str(source.parent.relative_to(ROOT)), manifest_sha256=source_sha, manifest=read(source))
    caveats = copy.deepcopy(baseline['situations-current.json']['publication']['caveats'])
    caveats = [value for value in caveats if not value.startswith('Three warmups and seven samples')]
    caveats.append(f"The current situation cohort uses {policy['warmups']} warmups and {policy['samples']} samples per process. V8 retains normal JIT/GC; optimized steady state is not assumed.")
    situations['publication'] = dict(date=args.date, measured_source=measured, coverage=coverage, baseline=binding,
        implementation=['Strict arguments projections and numeric leaf bodies use the compiled Wasm object model; materialization remains available where observable.'],
        caveats=caveats)
    if args.delivered_source:
        situations['publication']['delivered_source'] = dict(path=str(args.delivered_source.parent.relative_to(ROOT)), manifest_sha256=sha(args.delivered_source),
            qualification='Exactly two new Engine Realm constructor test expressions; product and measured source remain unchanged.',
            equivalence_archive_path='verification/exact-test-source-equivalence.json')
    archive.add_bytes('reports/full-situations-report.json', encoded(situations))
    situations = compact(situations)
    situations['publication']['full_report'] = dict(path='reports/full-situations-report.json', sha256=hashlib.sha256(archive.files['reports/full-situations-report.json']).hexdigest(), bytes=len(archive.files['reports/full-situations-report.json']))
    rsc = copy.deepcopy(aggregate)
    rsc.update(schema='scriptw-rsc-current-v1', date=args.date,
        publication=dict(date=args.date, measured_source=measured, coverage_reference='reports/full-situations-report.json'),
        baseline_diagnostics=dict(scope='Historical reports only; original P/R and original worker-only PMU boundaries retained. No prior allocation/counter/sample values are asserted current.',
            reports={name: binding['public_reports'][name] for name in ('react-allocation-current.json', 'react-attribution-current.json', 'rsc-wasm-size-current.json')},
            identity=baseline['rsc-current.json']['engines']['candidate']['identity']))
    if args.delivered_source:
        rsc['publication']['delivered_source'] = situations['publication']['delivered_source']
    rsc['source_identity']['candidate_measured_source'] = measured
    rsc['source_identity']['broad_qualification_complete'] = True
    rsc['source_identity'].pop('prototype_only', None)
    archive.add_file('verification/product-feature-comparison.json', args.feature_comparison)
    archive.add_file('verification/paired-image-situations-report.json', args.paired_situations_report)
    for label, path in (('paired-retention', args.paired_retention), ('node-oracles', args.node_oracles)):
        text_tree(archive, path.parent, 'verification/' + label)
    text_tree(archive, Path(__file__).parent, 'tools/publication')
    fresh_reports = {}
    for path in args.extra_text_evidence:
        path = path.resolve(strict=True)
        assert path.is_relative_to(ROOT / 'target')
        if path.is_dir():
            text_tree(archive, path, 'additional-evidence/' + path.relative_to(ROOT).as_posix())
        else:
            assert path.suffix not in EXCLUDED, 'excluded evidence suffix'
            archive.add_file('additional-evidence/' + path.relative_to(ROOT).as_posix(), path)
    for path in args.rejected_text:
        path = path.resolve(strict=True)
        assert path.is_file() and path.is_relative_to(ROOT / 'target') and path.suffix in ('.json', '.patch', '.stdout', '.stderr', '.md')
        archive.add_file('rejected-prototypes/' + path.relative_to(ROOT).as_posix(), path)
    reports = {'situations-current.json': situations, 'rsc-current.json': rsc, **fresh_reports}
    for name, value in reports.items():
        archive.add_bytes('reports/' + name, encoded(value))
    destination = args.output.resolve()
    assert destination.is_relative_to(ROOT / 'target') and not destination.exists()
    destination.mkdir(parents=True)
    metadata = archive.write(destination / ('situations-evidence-' + args.date + '-calls.tar.xz'))
    with tarfile.open(ROOT / metadata['file'], 'r:xz') as packed:
        index_bytes = packed.extractfile('INDEX.json').read()
        assert packed.extractfile('INDEX.json.sha256').read().decode().strip() == hashlib.sha256(index_bytes).hexdigest() + '  INDEX.json'
        index = json.loads(index_bytes)
        for row in index['members']:
            value = packed.extractfile(row['path']).read()
            assert len(value) == row['bytes'] and hashlib.sha256(value).hexdigest() == row['sha256']
        assert len(packed.getmembers()) == len(index['members']) + 2
    public_metadata = dict(metadata, file='docs/rust-rewrite/' + Path(metadata['file']).name)
    assert public_metadata['file'] != old_archive['file'], 'preserve the checkpoint archive path'
    for name, value in reports.items():
        save(destination / name, dict(value, evidence_archive=public_metadata))
    files_to_publish = [Path(public_metadata['file']).name, *reports]
    check_context()
    save(destination / 'publication-ready.json', dict(complete=True, source_manifest_sha256=source_sha,
        reports=list(reports), files_to_publish=files_to_publish, evidence_archive=public_metadata, staged_archive=metadata, canonical_files_written=False,
        current_diagnostics='No old allocation, PMU or sampled CPU report is relabeled current. Fresh diagnostics may be archived explicitly as additional evidence.'))
    print('VERIFIED INERT PUBLICATION STAGE READY', destination, flush=True)


if __name__ == '__main__':
    main()
