"""Balanced unchanged arguments frozen-image check; ordinary admission rules, no preparation/build."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import statistics
import sys

ROOT = Path.cwd()
B = Path(__file__).resolve().parent
OUT = B / 'paired-arguments'
from common import read, check_source
context = read(B / 'admission.json')
sys.path.insert(0, str(ROOT / 'scripts'))
from benchmark_metrics import digest, measure_process
from limited_verification import kernel_group, limited_environment, require_kernel_budget

spec = importlib.util.spec_from_file_location('ordinary_situations', ROOT / 'scripts/benchmark-situations.py')
driver = importlib.util.module_from_spec(spec)
spec.loader.exec_module(driver)

check_source(B / 'source-initial/manifest.json')
require_kernel_budget(4 * 1024**3)
assert len(os.sched_getaffinity(0)) == 1
environment = limited_environment()
assert not environment.get('NODE_OPTIONS')
for key, value in environment.items():
    if key.startswith(('SCRIPTW_PRECOMPILED_PHASE_', 'SCRIPTW_ROW_PERF_', 'SCRIPTW_BOUNDARY_READY_')):
        assert not value, key
    if key in ('SCRIPTW_PRECOMPILED_EXECUTION_WINDOWS', 'SCRIPTW_WASM_TRACE', 'SCRIPTW_WASM_TRACE_DUMP',
               'SCRIPTW_PERF_MAP_DIR', 'SCRIPTW_EMIT_SIZE_REPORT'):
        assert not value, key
environment.pop('NODE_COMPILE_CACHE', None)
environment['NODE_DISABLE_COMPILE_CACHE'] = '1'
OUT.mkdir(exist_ok=False)
(OUT / 'logs').mkdir()
reports = {}
pins = []
for name, directory in [('baseline', Path(context['baseline_situations']['path'])), ('candidate', B / 'situations-1')]:
    report = json.loads((directory / 'report.json').read_text())
    if name == 'baseline':
        assert digest(directory / 'report.json') == context['baseline_situations']['report_sha256']
    assert report['complete'] and report['policy']['warmups'] == 100 and report['policy']['samples'] == 21
    host = directory / 'bin/compiler_precompiled_baseline'
    assert digest(host) == report['tools']['host']['sha256']
    inventory = driver.validate_manifest(json.loads((directory / 'sources/manifest.json').read_text()))
    preparations = {}
    for policy in ['fast', 'speed']:
        images = directory / 'images' / ('prepare-' + policy)
        raw = json.loads((images / 'producer.json').read_text())
        preparations[policy] = driver.validate_preparation(raw, inventory, images, directory / 'manifests' / ('prepare-' + policy), report['tools']['host']['identity'], policy)
    reports[name] = (directory, report, preparations)
    pins.append(dict(name=name, report_sha256=digest(directory / 'report.json'), host_sha256=digest(host)))

cases = [case for case in reports['candidate'][1]['workloads'] if case['file'] in ['args-unused.js', 'args-observed.js']]
assert len(cases) == 2
for case in cases:
    assert next(c for c in reports['baseline'][1]['workloads'] if c['file'] == case['file']) == case

actors = ['baseline-fast', 'candidate-fast', 'baseline-speed', 'candidate-speed', 'v8']
rows = []
plan = list(driver.measurement_plan(cases, actors))
prepared = dict(complete=False, policy=dict(warmups=100, samples=21, blocks=2, processes_per_actor_per_block=4,
    ordering='rotated five-actor order, reversed in second block', gc='natural', jit='normal'),
    sources=pins, plan=plan, tooling_sha256=digest(Path(__file__)), rows=rows)
(OUT / 'prepared.json').write_text(json.dumps(prepared, indent=2) + '\n')
for item in plan:
    case = next(c for c in cases if c['file'] == item['file'])
    actor = item['actor']
    native_actor = 'v8'
    cohort = 'candidate'
    if actor != 'v8':
        cohort, policy = actor.split('-', 1)
        native_actor = 'scriptw-' + policy
    directory, report, preparations = reports[cohort]
    source = directory / 'sources' / case['file']
    assert digest(source) == case['source_sha256']
    producer = None
    if actor == 'v8':
        node = Path(report['tools']['node']['path'])
        assert digest(node) == report['tools']['node']['sha256']
        argv = [str(node), '--experimental-vm-modules', '--no-warnings', str(directory / 'tooling' / driver.ADAPTER),
                str(directory / 'sources'), case['file'], '21', '100']
    else:
        producer = next(row for row in preparations[policy] if row['file'] == case['file'])
        argv = [str(directory / 'bin/compiler_precompiled_baseline'), 'execute-retained',
                str(directory / 'images' / ('prepare-' + policy) / producer['image']), case['stdout'], '21', '100']
    label = f"{item['block']}-{item['round']}-{actor}-{case['file']}"
    stdout = OUT / 'logs' / (label + '.stdout')
    stderr = OUT / 'logs' / (label + '.stderr')
    scratch = OUT / 'scratch' / label
    scratch.mkdir(parents=True)
    child_environment = dict(environment, TMPDIR=str(scratch.resolve()), SCRIPTW_CACHE_DIR=str((scratch / 'cache').resolve()))
    with stdout.open('xb') as out, stderr.open('xb') as err:
        accounting = measure_process(argv, cwd=ROOT, env=child_environment, stdout=out, stderr=err,
                                     timeout=60, time_binary=report['tools']['time']['path'])
    assert accounting['exit_code'] == 0 and not accounting['timed_out'], label
    assert not stderr.read_bytes(), label
    raw = json.loads(stdout.read_text())
    samples = driver.validate_execution(raw, case, native_actor, case['source_sha256'], report['tools']['host']['identity'], producer)
    rows.append(dict(item, argv=argv, accounting=accounting, median_ns=statistics.median(samples), samples_ns=samples,
                     stdout=str(stdout.relative_to(OUT)), stdout_sha256=digest(stdout), stderr_sha256=digest(stderr)))
    (OUT / 'report.json').write_text(json.dumps(dict(prepared, rows=rows), indent=2) + '\n')
    print('OK', label, statistics.median(samples), flush=True)
summary = {}
for case in cases:
    summary[case['file']] = {}
    for actor in actors:
        group = [r for r in rows if r['file'] == case['file'] and r['actor'] == actor]
        assert len(group) == 8
        summary[case['file']][actor] = dict(median_ns=statistics.median(r['median_ns'] for r in group),
            block_medians_ns=[statistics.median(r['median_ns'] for r in group if r['block'] == block) for block in [0, 1]])
prepared.update(complete=True, summary=summary, rows=rows, checked_invocations=len(rows) * 121)
(OUT / 'report.json').write_text(json.dumps(prepared, indent=2) + '\n')
check_source(B / 'source-initial/manifest.json')
print(json.dumps(summary, indent=2), flush=True)
