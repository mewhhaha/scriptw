"""Read immutable ELF object symbols; never load or execute the native image."""
import hashlib,json,mmap,struct
from pathlib import Path
from common import BASE as B,ROOT,read,save,sha
NAMES={'SCRIPTW_RUNTIME_MANIFEST','SCRIPTW_RUNTIME_NATIVE','SCRIPTW_RUNTIME_PORTABLE_MANIFEST','SCRIPTW_RUNTIME_PORTABLE_NATIVE'}

def objects(path):
 with path.open('rb') as stream,mmap.mmap(stream.fileno(),0,access=mmap.ACCESS_READ) as data:
  assert data[:6]==b'\x7fELF\x02\x01'
  offset=struct.unpack_from('<Q',data,40)[0];size,count=struct.unpack_from('<HH',data,58);assert size==64
  sections=[struct.unpack_from('<IIQQQQIIQQ',data,offset+i*size) for i in range(count)]
  result={}
  for section in sections:
   if section[1]!=2:continue
   strings=sections[section[6]];names=data[strings[4]:strings[4]+strings[5]]
   assert section[9]==24
   for at in range(section[4],section[4]+section[5],24):
    name,info,other,index,value,length=struct.unpack_from('<IBBHQQ',data,at)
    end=names.find(b'\0',name);assert end>=name
    symbol=names[name:end].decode('utf8')
    if symbol not in NAMES or not length:continue
    assert 0<index<len(sections) and info&15==1 and symbol not in result
    owner=sections[index];start=owner[4]+value-owner[3];assert start>=owner[4] and start+length<=owner[4]+owner[5]
    result[symbol]=bytes(data[start:start+length])
  assert set(result)==NAMES,(str(path),set(result));return result

def manifest(data):
 assert data[:8]==b'SCRWNR01';version,configuration=struct.unpack_from('<II',data,8);assert version==5
 runtime,execution,allocator=struct.unpack_from('<BBB',data,16);target_length=struct.unpack_from('<H',data,19)[0];at=21+target_length
 assert len(data)==at+128
 return dict(version=version,configuration=configuration,runtime_mode=runtime,execution_modes=execution,register_allocation=allocator,target=data[21:at].decode(),source=data[at:at+32].hex(),runtime_key=data[at+32:at+64].hex(),package_digest=data[at+64:at+96].hex(),native_digest=data[at+96:].hex(),manifest_sha256=hashlib.sha256(data).hexdigest())

def main():
 rows=[]
 for cohort,root in [('fiber',B.parent/'fiber-only/products-1/frozen'),('calls',B/'build-2/frozen')]:
  for host in ('compiler_precompiled_baseline','rsc_baseline','scriptw'):
   path=root/host;producer=read(root/(host+'-producer.json'));assert sha(path)==producer['sha256']
   values=objects(path);profiles={}
   for label,prefix in [('host','SCRIPTW_RUNTIME_'),('portable','SCRIPTW_RUNTIME_PORTABLE_')]:
    decoded=manifest(values[prefix+'MANIFEST']);packed=values[prefix+'NATIVE'];assert packed[:8]==b'SWRTZ001'
    decoded.update(packed_bytes=len(packed),packed_sha256=hashlib.sha256(packed).hexdigest(),native_bytes=struct.unpack_from('<Q',packed,8)[0],packed_expected_native_digest=packed[16:48].hex())
    assert decoded['native_digest']==decoded['packed_expected_native_digest']
    profiles[label]=decoded
   rows.append(dict(cohort=cohort,host=host,path=str(path),executable_sha256=producer['sha256'],source_manifest_sha256=producer['source_manifest_sha256'],profiles=profiles))
 comparisons=[]
 for host in ('compiler_precompiled_baseline','rsc_baseline','scriptw'):
  a=next(r for r in rows if r['cohort']=='fiber' and r['host']==host);c=next(r for r in rows if r['cohort']=='calls' and r['host']==host)
  comparisons.append(dict(host=host,profiles={profile:dict(manifest_identical=a['profiles'][profile]['manifest_sha256']==c['profiles'][profile]['manifest_sha256'],packed_native_identical=a['profiles'][profile]['packed_sha256']==c['profiles'][profile]['packed_sha256'],native_digest_identical=a['profiles'][profile]['native_digest']==c['profiles'][profile]['native_digest']) for profile in ('host','portable')}))
 report=dict(schema='scriptw-calls-embedded-r-elf-byte-control-v1',complete=True,rows=rows,comparisons=comparisons,implementation=[dict(path=str(p),sha256=sha(p)) for p in [ROOT/'crates/scriptw-engine/src/embedded_runtime/manifest.rs',ROOT/'crates/scriptw-runtime-image/src/native_storage.rs']],limits='Inert immutable ELF symbol/manifest/storage-header extraction only. Packed-byte equality and embedded native SHA are compared; no image loaded, deserialized, decompressed, rebuilt or executed. No timing attribution follows from equal bytes.')
 save(B/'embedded-r-elf-byte-control.json',report)
 print(json.dumps(dict(comparisons=comparisons,portable_native_digest=rows[-1]['profiles']['portable']['native_digest'],portable_runtime_key=rows[-1]['profiles']['portable']['runtime_key'])))

if __name__=='__main__':main()
