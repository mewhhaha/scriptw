"""Source and receipt authority for the future projection + numeric-body pilot."""
import hashlib
import json
import re
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[3]
BASE = Path(__file__).resolve().parent
def admitted_base():
    context = read(BASE / 'admission.json')
    assert context['complete']
    return context['retained_base_git']


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def save(path, value):
    path = Path(path)
    temporary = path.with_name(path.name + '.writing')
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')
    temporary.replace(path)


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)


def apply_test_delivery(data, actual_files):
    reference = data['test_only_delivery']
    assert sha(reference['path']) == reference['sha256']
    proof = read(reference['path'])
    assert proof['schema'] == 'scriptw-realm-test-host-source-equivalence-v1' and proof['complete']
    measured_ref = proof['measured_source']
    assert sha(measured_ref['path']) == measured_ref['sha256']
    measured = read(measured_ref['path'])
    assert measured['files'] == actual_files
    assert measured['admission_sha256'] == data['admission_sha256'] and measured['base_git'] == data['base_git']
    implementation = proof['compiler_inputs_implementation']
    assert sha(ROOT / implementation['path']) == implementation['sha256']
    build = proof['compiler_build_script']
    assert sha(ROOT / build['path']) == build['sha256']
    source = (ROOT / implementation['path']).read_text()
    assert proof['production_compiler_inputs_unchanged'] and proof['native_compiler_inputs_unchanged']
    expected = {'crates/scriptw-engine/tests/aot_language/aot_strict_arguments_projection.rs',
                'crates/scriptw-engine/tests/aot_language/aot_numeric_body.rs'}
    assert {row['path'] for row in proof['files']} == expected
    assert sha(Path(reference['path']).parent / 'correction.patch') == proof['patch_sha256']
    for row in proof['files']:
        relative = row['path']
        assert actual_files[relative] == row['base_sha256']
        before = Path(reference['path']).parent / 'before' / relative
        after = Path(reference['path']).parent / 'candidate' / relative
        assert sha(before) == row['base_sha256'] and sha(after) == row['candidate_sha256']
        assert before.read_text().count('$262.createRealm()') == 1
        assert after.read_text() == before.read_text().replace('$262.createRealm()', '__scriptwCreateRealm()')
        for name in ('COMPILER_INPUTS', 'NATIVE_COMPILER_INPUTS'):
            body = re.search(r'const\s+' + name + r'\s*:[^=]+?=\s*&\[(.*?)\];', source, re.S)[1]
            inputs = re.findall(r'"([^"\n]+)"', re.sub(r'//[^\n]*', '', body))
            assert not any(Path(relative).is_relative_to(path) for path in inputs)
        actual_files[relative] = row['candidate_sha256']
    return actual_files


def check_source(manifest):
    manifest = Path(manifest).resolve(strict=True)
    data = read(manifest)
    live_path = BASE / 'active-test-delivery.json'
    if live_path.exists():
        live = read(live_path)
        assert live['schema'] == 'scriptw-live-test-only-delivery-v1'
        if sha(manifest) == live['measured']['sha256']:
            assert manifest == Path(live['measured']['path']).resolve()
            delivered = Path(live['delivered']['path']).resolve(strict=True)
            assert sha(delivered) == live['delivered']['sha256']
            delivered_data = check_source(delivered)
            assert delivered_data['test_only_delivery'] == live['equivalence']
            proof = read(live['equivalence']['path'])
            assert proof['measured_source'] == live['measured']
            assert data['admission_sha256'] == sha(BASE / 'admission.json')
            assert sha(manifest.parent / 'tracked.patch') == data['tracked_patch_sha256']
            for relative, expected in data['files'].items():
                assert sha(manifest.parent / 'files' / relative) == expected
            return data
    assert git('rev-parse', 'HEAD').decode().strip() == data['base_git'] == admitted_base()
    assert git('diff', '--binary', 'HEAD') == (manifest.parent / 'tracked.patch').read_bytes()
    assert sha(manifest.parent / 'tracked.patch') == data['tracked_patch_sha256']
    for relative, expected in data['files'].items():
        assert sha(ROOT / relative) == expected, relative
    untracked = set(git('ls-files', '--others', '--exclude-standard', '-z').decode().split('\0')) - {''}
    assert untracked == set(data['untracked_files']), 'untracked source inventory changed'
    for relative in data['files']:
        assert sha(manifest.parent / 'files' / relative) == data['files'][relative]
    admission = read(BASE / 'admission.json')
    assert data['admission_sha256'] == sha(BASE / 'admission.json')
    expected_files = dict(admission['final_file_hashes'])
    if 'source_correction' in data:
        reference = data['source_correction']
        assert sha(reference['path']) == reference['sha256']
        correction = read(reference['path'])
        assert correction['schema'] == 'scriptw-source-import-correction-v1'
        assert correction['admission_sha256'] == data['admission_sha256']
        parent_reference = correction['parent_source_manifest']
        assert sha(parent_reference['path']) == parent_reference['sha256']
        parent = read(parent_reference['path'])
        assert parent['admission_sha256'] == data['admission_sha256']
        assert parent['base_git'] == data['base_git'] and 'source_correction' not in parent
        actual_files = dict(parent['files'])
        assert sha(Path(reference['path']).parent / 'correction.patch') == correction['patch_sha256']
        for row in correction['files']:
            relative = row['path']
            assert expected_files[relative] == actual_files[relative] == row['base_sha256']
            assert sha(Path(reference['path']).parent / 'before' / relative) == row['base_sha256']
            assert sha(Path(reference['path']).parent / 'candidate' / relative) == row['candidate_sha256']
            expected_files[relative] = actual_files[relative] = row['candidate_sha256']
        if 'test_only_delivery' in data:
            actual_files = apply_test_delivery(data, actual_files)
            for row in read(data['test_only_delivery']['path'])['files']:
                expected_files[row['path']] = row['candidate_sha256']
        assert actual_files == data['files'], 'source child changed outside pinned correction'
    for relative, expected in expected_files.items():
        assert data['files'][relative] == expected
    return data


def artifacts(log):
    rows = [json.loads(line) for line in Path(log).read_text().splitlines() if line]
    finished = [row for row in rows if row.get('reason') == 'build-finished']
    assert len(finished) == 1 and finished[0]['success'], 'Cargo producer did not complete'
    return [row for row in rows if row.get('reason') == 'compiler-artifact' and row.get('executable')]
