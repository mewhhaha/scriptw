# Future projection + numeric-body discriminator

Ignored preparation only. Do not run before the retained fiber batch is published and committed cleanly. The candidate's Git base is that new publication commit; each original production owner is separately checked against046c. No classifier, ValueArray, ABI52, allocation-overlay or previous diagnostic identity is imported. Current fiber publication remains independent.

`prepare_context.py` admits the two sealed stages and API correction, validates every source hash and ordered overlap, checks the two unchanged scored JS sources, and pins the new Git-bound fiber timing/host baseline. It refuses046c as the runtime baseline. It does not apply patches. `freeze_source.py` requires every final candidate hash and records exact tracked/untracked source plus admission SHA. All later phases validate that snapshot before/after children. Counts come from positive actual libtest inventories, never predicted totals.

Only after root publishes fiber:

```sh
next=target/performance-v8-climb-20261104/strict-arguments-execution
fiber=target/performance-v8-climb-20261104/fiber-only
python3 -B "$next/prepare_context.py" --published-base "$fiber_commit" \
  --baseline-situations "$fiber/situations-1" \
  --baseline-rsc-raw "$fiber/rsc-pilot-1/block-0-0-candidate/report.json"
```

Root/native owner applies these three frozen patches **in order**, reviewing each check before its apply. `admission.json` contains all exact hashes and final24-file hash map:

```sh
git apply --check target/performance-v8-climb-20261104/strict-arguments-projection-staged/projection.patch
git apply target/performance-v8-climb-20261104/strict-arguments-projection-staged/projection.patch
git apply --check target/performance-v8-climb-20261104/numeric-body-staged/numeric-body.patch
git apply target/performance-v8-climb-20261104/numeric-body-staged/numeric-body.patch
git apply --check target/performance-v8-climb-20261104/numeric-body-api-correction/correction.patch
git apply target/performance-v8-climb-20261104/numeric-body-api-correction/correction.patch
```

Correction SHA `5247d4111d50578b4620fc3309f650f0401c9f7e2b87ae6449406d15f9b6e4be` adds the required `schema` argument to `StoredValue::read_into`. The original numeric and projection stages remain immutable. `admission.json.api_correction` preserves its own manifest, parent patch and before/after file identities. Finish docs, format/source guards and portable JS oracles before the expensive producer. The separate Realm fixture requires Engine's real Test262 host; do not fabricate `$262` in Node. Source controls and copied fixtures are pending execution.

Then freeze once and produce ordinary examples plus only the two initial integration harnesses, followed by a separate CLI-only graph:

```sh
python3 -B "$next/freeze_source.py" --output "$next/source-initial"
python3 -B scripts/limited_verification.py -- python3 -B "$next/run_phase.py" \
  --source "$next/source-initial/manifest.json" --phase focused-build --output "$next/build-1"
python3 -B scripts/limited_verification.py -- python3 -B "$next/run_phase.py" \
  --source "$next/source-initial/manifest.json" --phase focused \
  --producer "$next/build-1/receipt.json" --output "$next/focused-1"
```

The initial producer deliberately does not build AOT private `--lib` tests. It freezes emission/aot_language with `profile.test=true`, ordinary RSC/compiler examples with `profile.test=false`, and the CLI from its separate CLI-only command. Only ordinary example receipts qualify benchmark hosts. The four positive filters are `strict_arguments_projection::`, `numeric_body::`, `aot_strict_arguments_projection::`, and `aot_numeric_body::`. Preserve real failing logs, classify corrections, rerun affected filters and unfinished scopes; do not restart passing scopes without cause.

Initial matched situation preparation/scoring uses the existing ordinary driver and exact retained fiber sources. Include frame-compact as a refusal/control case. Supply the baseline's pinned Node/time executables, as recorded in its report:

```sh
python3 -B scripts/limited_verification.py -- python3 -B scripts/benchmark-situations.py \
  --host "$next/build-1/frozen/compiler_precompiled_baseline" \
  --producer-log "$next/build-1/pilot-build.stdout" \
  --producer-receipt "$next/build-1/frozen/compiler_precompiled_baseline-producer.json" \
  --fixtures "$fiber/situations-1/sources" --output "$next/situations-1" \
  --node "$node_binary" --time "$time_binary" \
  --case args-unused.js --case args-observed.js --case frame-compact.js
python3 -B scripts/limited_verification.py -- python3 -B "$next/paired_arguments.py"
python3 -B scripts/limited_verification.py -- python3 -B "$next/measure_rsc.py" \
  --candidate "$next/build-1/frozen/rsc_baseline" \
  --candidate-source-snapshot "$next/source-initial" \
  --baseline "$fiber/products-1/frozen/rsc_baseline" \
  --baseline-json "$fiber/rsc-pilot-1/block-0-0-candidate/report.json" \
  --focused-receipt "$next/focused-1/receipt.json" \
  --node "$node_binary" --time "$time_binary" --output "$next/rsc-pilot-1"
```

The paired runner reuses exact frozen Fast/Speed images and the ordinary preparation/execution validators, opened output files and per-child scratch/cache. It scores unchanged args-unused/args-observed across oldFast/newFast/oldSpeed/newSpeed/V8, rotated/reversed two-block100/21 ordering. RSC is a separate balanced24-process3/7 control, with no demonstrated admission or gain. Unused and observed paths must remain disjoint: numeric/local-entry versus projection/vector. Require the pending private route proof during qualification if retained; encoded emission controls are initial actual-route evidence. Frame-compact is refused.

Only after a useful balanced pilot and root retention: compile private proof tests once, execute all pending projection/numeric proof controls, full emission/affected Engine suites and necessary broader qualification. No future count or performance claim is asserted by these helpers. Old allocation, PMU and size reports remain baseline and cannot acquire new producer IDs merely because Wasm bytes match.

The optional hash-authority tooling candidate is separate from semantic attribution. It may join the same future freeze only after a capped cost/control experiment and explicit root choice. Scope only the three large tools (host/Node/time): full initial digest+stable stat, per-use dev/inode/size/mtime_ns/ctime_ns/mode witnesses, mandatory full terminal digest/stat in `finally`, including failed children, with report.complete false on any terminal failure. Keep fixture/tooling/image checks unchanged; test replacement, in-place changes and restored mtime. No speed claim comes from the unrelated compact-JSON serializer result, and no hash-witness implementation or cost measurement is supplied here.
