import json,os,re,subprocess,time
from pathlib import Path
from common import BASE as B,ROOT,check_source,read,save,sha

def main():
 measured=B/'source-corrected-1/manifest.json';delivered=B/'source-corrected-2/manifest.json';check_source(measured);check_source(delivered)
 out=B/'cli-smoke-1';out.mkdir();(out/'cache').mkdir()
 binary=B/'build-2/frozen/scriptw';producer=read(binary.parent/'scriptw-producer.json');assert sha(binary)==producer['sha256'] and producer['source_manifest_sha256']==sha(measured)
 fixture=ROOT/'crates/scriptw-cli/tests/fixtures/hello.js';contract=ROOT/'crates/scriptw-cli/tests/product_artifact_execution.rs'
 completion=json.loads(re.search(r'const WASM_COMPLETION: &str = (".*");',contract.read_text())[1]);expected='grug\n'+completion
 argv=[str(binary),'run',str(fixture)];capped=['python3','-B','scripts/limited_verification.py','--',*argv]
 started=time.monotonic_ns()
 with (out/'stdout').open('xb') as so,(out/'stderr').open('xb') as se:
  child=subprocess.run(capped,stdout=so,stderr=se,timeout=120,env=dict(os.environ,SCRIPTW_CACHE_DIR=str(out/'cache')))
 row=dict(schema='scriptw-calls-cli-smoke-v1',complete=False,argv=argv,capped_argv=capped,exit_code=child.returncode,timed_out=False,elapsed_ns=time.monotonic_ns()-started,executable_sha256=sha(binary),measured_source_manifest_sha256=sha(measured),delivered_source_manifest_sha256=sha(delivered),producer_path=str(binary.parent/'scriptw-producer.json'),producer_sha256=sha(binary.parent/'scriptw-producer.json'),fixture=dict(path=str(fixture),sha256=sha(fixture)),completion_contract=dict(path=str(contract),sha256=sha(contract)),stdout_sha256=sha(out/'stdout'),stderr_sha256=sha(out/'stderr'),expected_stdout=expected)
 save(out/'receipt.json',row)
 assert child.returncode==0 and (out/'stdout').read_text()==expected
 assert (out/'stderr').read_text()=='limited-verification: confirmed kernel memory cap 4096 MiB, swap 0, one CPU and serial worker defaults; retained module cache 1 entry / 67108864 image bytes\n'
 check_source(measured);check_source(delivered);row['complete']=True;save(out/'receipt.json',row)
 print('FROZEN ORDINARY CLI DEFAULT WASM-AOT SMOKE PASS',out/'receipt.json')

if __name__=='__main__':main()
