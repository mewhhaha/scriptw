"""Source and receipt authority for the future projection + numeric-body pilot."""
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[3]
BASE = Path(__file__).resolve().parent
def admitted_base():
    context = read(BASE / 'admission.json')
    assert context['complete']
    return context['retained_base_git']


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def save(path, value):
    path = Path(path)
    temporary = path.with_name(path.name + '.writing')
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')
    temporary.replace(path)


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)


def check_source(manifest):
    manifest = Path(manifest).resolve(strict=True)
    data = read(manifest)
    assert git('rev-parse', 'HEAD').decode().strip() == data['base_git'] == admitted_base()
    assert git('diff', '--binary', 'HEAD') == (manifest.parent / 'tracked.patch').read_bytes()
    assert sha(manifest.parent / 'tracked.patch') == data['tracked_patch_sha256']
    for relative, expected in data['files'].items():
        assert sha(ROOT / relative) == expected, relative
    untracked = set(git('ls-files', '--others', '--exclude-standard', '-z').decode().split('\0')) - {''}
    assert untracked == set(data['untracked_files']), 'untracked source inventory changed'
    for relative in data['files']:
        assert sha(manifest.parent / 'files' / relative) == data['files'][relative]
    admission = read(BASE / 'admission.json')
    assert data['admission_sha256'] == sha(BASE / 'admission.json')
    expected_files = dict(admission['final_file_hashes'])
    if 'source_correction' in data:
        reference = data['source_correction']
        assert sha(reference['path']) == reference['sha256']
        correction = read(reference['path'])
        assert correction['schema'] == 'scriptw-source-import-correction-v1'
        assert correction['admission_sha256'] == data['admission_sha256']
        parent_reference = correction['parent_source_manifest']
        assert sha(parent_reference['path']) == parent_reference['sha256']
        parent = read(parent_reference['path'])
        assert parent['admission_sha256'] == data['admission_sha256']
        assert parent['base_git'] == data['base_git'] and 'source_correction' not in parent
        actual_files = dict(parent['files'])
        assert sha(Path(reference['path']).parent / 'correction.patch') == correction['patch_sha256']
        for row in correction['files']:
            relative = row['path']
            assert expected_files[relative] == actual_files[relative] == row['base_sha256']
            assert sha(Path(reference['path']).parent / 'before' / relative) == row['base_sha256']
            assert sha(Path(reference['path']).parent / 'candidate' / relative) == row['candidate_sha256']
            expected_files[relative] = actual_files[relative] = row['candidate_sha256']
        assert actual_files == data['files'], 'source child changed outside pinned correction'
    for relative, expected in expected_files.items():
        assert data['files'][relative] == expected
    return data


def artifacts(log):
    rows = [json.loads(line) for line in Path(log).read_text().splitlines() if line]
    finished = [row for row in rows if row.get('reason') == 'build-finished']
    assert len(finished) == 1 and finished[0]['success'], 'Cargo producer did not complete'
    return [row for row in rows if row.get('reason') == 'compiler-artifact' and row.get('executable')]
