import ast,json,subprocess,sys,time
from pathlib import Path
base=Path('target/performance-v8-climb-20261104/strict-arguments-execution').resolve()
rows=[]
def run(name,argv):
 command=['python3','-B','scripts/limited_verification.py','--',*argv]
 start=time.monotonic_ns()
 with (base/(name+'.stdout')).open('xb') as so,(base/(name+'.stderr')).open('xb') as se:
  result=subprocess.run(command,stdout=so,stderr=se)
 rows.append(dict(label=name,capped_argv=command,exit_code=result.returncode,elapsed_ns=time.monotonic_ns()-start))
 (base/'source-checks.json').write_text(json.dumps(rows,indent=2)+'\n')
 assert result.returncode==0,name
changed=subprocess.check_output(['git','diff','--name-only','-z','HEAD']).decode().split('\0')
new=subprocess.check_output(['git','ls-files','--others','--exclude-standard','-z']).decode().split('\0')
files=sorted({p for p in changed+new if p.endswith('.rs')})
run('rustfmt',['rustfmt','--check','--edition','2021','--config','skip_children=true',*files])
run('owners',['python3','-B','scripts/conformance_owners.py'])
run('source-guards',['python3','-B','scripts/check-source-guards.py'])
ast.parse(Path('scripts/benchmark-situations.py').read_text())
run('whitespace',['git','diff','--check'])
print('CHANGED RUSTFMT, OWNERS, SOURCE GUARDS, PYTHON AST, WHITESPACE PASS')
