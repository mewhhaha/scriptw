"""Inert framed-byte comparison; never creates or admits an executable image."""
import hashlib,json,struct
from pathlib import Path
from common import BASE as B,ROOT,check_source,git,read,save,sha

def digest(data):return hashlib.sha256(data).hexdigest()

def payload(root,row):
 path=root/'images'/('prepare-'+row['shared_configuration']['native_compilation_mode'])/row['image']
 data=path.read_bytes();assert len(data)<=256*1024*1024 and digest(data)==row['image_sha256']
 assert len(data)>=126 and data[:8]==b'SCRWEP03' and digest(data[:-32])==data[-32:].hex()
 p,n,f=struct.unpack_from('<QQI',data,74);assert len(data)==126+p+n+f
 assert n==row['native_serialized_bytes']
 facts=data[94:94+f];program=data[94+f:94+f+p];native=data[94+f+p:-32]
 assert digest(program)==row['program_wasm_sha256']
 return dict(path=str(path),image_sha256=digest(data),compiler_fingerprint=data[8:40].hex(),runtime_key=data[41:73].hex(),facts_sha256=digest(facts),program_sha256=digest(program),native_sha256=digest(native),native_bytes=len(native))

def main():
 source=B/'source-corrected-1/manifest.json';check_source(source);context=read(B/'admission.json')
 old_root=Path(context['baseline_situations']['path']);old=read(old_root/'report.json')
 assert sha(old_root/'report.json')==context['baseline_situations']['report_sha256']
 new_root=B/'situations-full-1';new=read(new_root/'report.json');assert new['complete'] and len(new['rows'])==504
 public_path=source.parent/'baseline/situations-current.json';raw=git('show',context['retained_base_git']+':docs/rust-rewrite/situations-current.json');assert public_path.read_bytes()==raw
 public=json.loads(raw)
 def rows(report):return {(p['actor'],r['file']):r for p in report['preparations'] for r in p['cases']}
 old_rows,new_rows,public_rows=rows(old),rows(new),rows(public)
 assert set(old_rows)==set(new_rows)==set(public_rows) and len(old_rows)==42
 result=[]
 for key in sorted(old_rows):
  baseline,candidate=old_rows[key],new_rows[key]
  assert baseline['program_wasm_sha256']==public_rows[key]['program_wasm_sha256']
  assert baseline['original_source_sha256']==candidate['original_source_sha256']
  a,c=payload(old_root,baseline),payload(new_root,candidate)
  result.append(dict(actor=key[0],file=key[1],program_changed=a['program_sha256']!=c['program_sha256'],native_changed=a['native_sha256']!=c['native_sha256'],runtime_key_changed=a['runtime_key']!=c['runtime_key'],facts_changed=a['facts_sha256']!=c['facts_sha256'],baseline=a,candidate=c))
 changed=sorted({r['file'] for r in result if r['program_changed']});unchanged=sorted({r['file'] for r in result if not r['program_changed']});assert not set(changed)&set(unchanged)
 implementation=ROOT/'crates/scriptw-engine/src/embedding/precompiled/envelope.rs'
 report=dict(schema='scriptw-calls-matrix-static-byte-attribution-v1',complete=True,measured_source_manifest_sha256=sha(source),published_base=context['retained_base_git'],published_report_sha256=digest(raw),baseline_report_sha256=sha(old_root/'report.json'),candidate_report_sha256=sha(new_root/'report.json'),envelope_implementation=dict(path=str(implementation),sha256=sha(implementation)),changed_programs=changed,unchanged_programs=unchanged,unchanged_programs_with_changed_native_payload=sorted({r['file'] for r in result if not r['program_changed'] and r['native_changed']}),rows=result,limits='Inert rawP, checksum, serialized-native-payload and framing-field comparison only. No native admission granted, altered image executed or host timing attribution. Fresh matrix and semantic qualification remain separate.')
 check_source(source);save(B/'matrix-image-byte-attribution.json',report)
 print(json.dumps(dict(changed_programs=changed,unchanged_program_count=len(unchanged),unchanged_programs_with_changed_native_payload=report['unchanged_programs_with_changed_native_payload'])))

if __name__=='__main__':main()
