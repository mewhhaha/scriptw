"""Validate the disjoint focused union; retain original failed filters."""
import argparse,copy,re
from pathlib import Path
from common import BASE as B,check_source,read,save,sha
from run_phase import FOCUS,SUMMARY

def reference(path):return dict(path=str(path),sha256=sha(path))
def actual(row):
 for field in ('stdout','stderr'):assert sha(row[field])==row[field+'_sha256']
 summaries=SUMMARY.findall(Path(row['stdout']).read_text());assert len(summaries)==1
 state,passed,failed,ignored=summaries[0]
 assert row['outcomes']==dict(state=state,passed=int(passed),failed=int(failed),ignored=int(ignored))
 return re.findall(r'^test (\S+) \.\.\. ok$',Path(row['stdout']).read_text(),re.M),re.findall(r'^test (\S+) \.\.\. FAILED$',Path(row['stdout']).read_text(),re.M)

def compute():
 measured=B/'source-corrected-1/manifest.json';delivered=B/'source-corrected-2/manifest.json'
 check_source(measured);check_source(delivered)
 old=read(B/'focused-1/receipt.json');numeric=read(B/'focused-numeric-1/receipt.json');recovery=read(B/'realm-recovery-1/receipt.json')
 assert not old['complete'] and not numeric['complete'] and recovery['complete']
 assert old['source_manifest_sha256']==numeric['source_manifest_sha256']==sha(measured)
 assert recovery['source_manifest_sha256']==sha(delivered)
 proof=read(B/'realm-test-correction-1/source-equivalence.json')
 assert recovery['unchanged_production_compiler_fingerprint']==proof['expected_production_compiler_fingerprint']
 inventory=read(B/'focused-1/inventory-aot_language.json')['tests']
 assert inventory==recovery['inventories']['aot_language']['tests']
 producer=recovery['artifacts'][0];assert producer['artifact']['target']['name']=='aot_language'
 assert sha(producer['frozen_path'])==producer['sha256']
 emission_inventory=read(B/'focused-1/inventory-emission.json')['tests']
 scopes=[]
 for target,pattern in FOCUS:
  originals=old['scopes']+numeric['scopes'];selected=[r for r in originals if r['target']==target and r['argv'][1]==pattern];assert len(selected)==1
  original=copy.deepcopy(selected[0]);passed,failed=actual(original)
  names=[n for n in inventory if pattern in n]
  if target=='emission':names=[n for n in emission_inventory if pattern in n]
  assert names and set(passed)|set(failed)==set(names) and not set(passed)&set(failed)
  assert original['outcomes']['ignored']==0
  if target=='emission':
   assert original['exit_code']==0 and not failed and len(passed)==original['outcomes']['passed']
   scopes.append(original);continue
  assert original['exit_code']==101 and len(failed)==original['outcomes']['failed']==1
  restored=[r for r in recovery['scopes'] if r['argv'][1]==failed[0]];assert len(restored)==1
  restored=copy.deepcopy(restored[0]);recovered,still_failed=actual(restored)
  assert '--exact' in restored['argv'] and restored['exit_code']==0 and not still_failed and recovered==failed
  assert restored['source_manifest_sha256']==sha(delivered)
  assert set(passed).isdisjoint(recovered) and set(passed)|set(recovered)==set(names)
  scopes.append(dict(scope_kind='qualified_union',target=target,filter=pattern,source_manifest_sha256=sha(measured),delivered_source_manifest_sha256=sha(delivered),outcomes=dict(state='qualified_union',passed=len(names),failed=0,ignored=0),original_failed_scope=original,corrected_filtered_scope=restored,preserved_passed_tests=passed,recovered_tests=recovered,inventory=names))
 return dict(schema='scriptw-projection-numeric-focused-qualified-union-v1',phase='focused-qualified-union',complete=True,source_manifest_sha256=sha(measured),delivered_source_manifest_sha256=sha(delivered),source_equivalence=reference(B/'realm-test-correction-1/source-equivalence.json'),original_receipts=[reference(B/p/'receipt.json') for p in ('focused-1','focused-numeric-1','realm-recovery-1')],corrected_producer=reference(B/'realm-recovery-1/receipt.json'),qualified_filters=[list(r) for r in FOCUS],scopes=scopes,tooling_sha256=sha(__file__),limits='Two encoded-route tests and three original Engine passes are preserved; the two originally failing Realm tests passed separately after an exact test-only real-host setup correction. Original filters remain failed; no full-filter rerun is implied.')

def validate(report,manifest):
 assert report==compute()
 assert report['source_manifest_sha256']==sha(manifest)
 return report

if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True);args=parser.parse_args();assert not args.output.exists();args.output.mkdir()
 report=compute();validate(report,B/'source-corrected-1/manifest.json');save(args.output/'receipt.json',report)
 print('FOUR FOCUSED FILTERS QUALIFIED BY EXPLICIT UNION; ORIGINAL FAILURES RETAINED',args.output/'receipt.json')
