"""Freeze exact current source and Git-bound prior publication; never build."""
import argparse
from pathlib import Path
import shutil
from common import admitted_base, ROOT, check_source, git, save, sha


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    BASE_GIT = admitted_base()
    admission = __import__('json').loads((Path(__file__).parent / 'admission.json').read_text())
    for relative, expected in admission['final_file_hashes'].items():
        assert sha(ROOT / relative) == expected, relative
    output = args.output.resolve()
    assert output.is_relative_to(ROOT / 'target') and not output.exists()
    assert git('rev-parse', 'HEAD').decode().strip() == BASE_GIT
    patch = git('diff', '--binary', 'HEAD')
    tracked = set(git('diff', '--name-only', '-z', 'HEAD').decode().split('\0')) - {''}
    untracked = set(git('ls-files', '--others', '--exclude-standard', '-z').decode().split('\0')) - {''}
    assert patch and tracked, 'refuse an empty candidate source snapshot'
    output.mkdir(parents=True)
    (output / 'tracked.patch').write_bytes(patch)
    files = {}
    for relative in sorted(tracked | untracked):
        source = ROOT / relative
        assert source.is_file() and not source.is_symlink(), 'deleted/symlink source needs explicit handling: ' + relative
        data = source.read_bytes()
        data.decode('utf-8', errors='strict')
        assert b'\0' not in data
        destination = output / 'files' / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(data)
        files[relative] = sha(source)
    baseline = output / 'baseline'
    baseline.mkdir()
    reports = {}
    for name in ('rsc-current.json', 'situations-current.json', 'react-allocation-current.json'):
        path = baseline / name
        path.write_bytes(git('show', BASE_GIT + ':docs/rust-rewrite/' + name))
        reports[name] = dict(path=str(path.relative_to(output)), sha256=sha(path))
    save(output / 'manifest.json', dict(schema='scriptw-projection-numeric-pilot-source-v1', base_git=BASE_GIT,
        admission_sha256=sha(Path(__file__).parent / 'admission.json'),
        tracked_patch_sha256=sha(output / 'tracked.patch'), files=files,
        tracked_files=sorted(tracked), untracked_files=sorted(untracked), baseline_public_reports=reports,
        scope='Exact source snapshot; no build/test/benchmark completion is implied.'))
    check_source(output / 'manifest.json')
    print('Frozen manifest:', output / 'manifest.json', sha(output / 'manifest.json'))


if __name__ == '__main__':
    main()
