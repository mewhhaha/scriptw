import difflib,hashlib,json,re,shutil,subprocess
from pathlib import Path
b=Path('target/performance-v8-climb-20261104/strict-arguments-execution').resolve();c=b/'realm-test-correction-1'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,d):Path(p).write_text(json.dumps(d,indent=2)+'\n')
parent=b/'source-corrected-1/manifest.json';m=json.loads(parent.read_text());rows=[];patch=[]
impl=Path('crates/scriptw-engine/compiler_fingerprint.rs');implementation=impl.read_text();build=Path('crates/scriptw-engine/build.rs')
for p in (impl,build):assert p.read_bytes()==subprocess.check_output(['git','show',m['base_git']+':'+str(p)])
def inputs(name):return re.findall(r'"([^"\n]+)"',re.search(r'const\s+'+name+r'\s*:[^=]+?=\s*&\[(.*?)\];',implementation,re.S)[1])
for relative in ['crates/scriptw-engine/tests/aot_language/aot_strict_arguments_projection.rs','crates/scriptw-engine/tests/aot_language/aot_numeric_body.rs']:
 before=c/'before'/relative;after=Path(relative);assert sha(before)==m['files'][relative]
 assert before.read_text().count('$262.createRealm()')==1
 assert after.read_text()==before.read_text().replace('$262.createRealm()','__scriptwCreateRealm()')
 assert not any(Path(relative).is_relative_to(p) for p in inputs('COMPILER_INPUTS')+inputs('NATIVE_COMPILER_INPUTS'))
 dest=c/'candidate'/relative;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(after.read_bytes())
 rows.append(dict(path=relative,base_sha256=sha(before),candidate_sha256=sha(dest)))
 patch.extend(difflib.unified_diff(before.read_text().splitlines(keepends=True),dest.read_text().splitlines(keepends=True),fromfile='a/'+relative,tofile='b/'+relative))
p=c/'correction.patch';p.write_text(''.join(patch))
logs=[json.loads(s) for s in (b/'build-2/pilot-build.stdout').read_text().splitlines() if s]
fp={v for r in logs if r.get('reason')=='build-script-executed' for k,v in r.get('env',[]) if k=='SCRIPTW_COMPILER_FINGERPRINT'};assert len(fp)==1
proof=dict(schema='scriptw-realm-test-host-source-equivalence-v1',complete=True,measured_source=dict(path=str(parent),sha256=sha(parent)),files=rows,patch_sha256=sha(p),original_diagnostics=[dict(path=str(b/d/'receipt.json'),sha256=sha(b/d/'receipt.json')) for d in ['realm-diagnostic-1','realm-diagnostic-2']],production_compiler_inputs_unchanged=True,native_compiler_inputs_unchanged=True,compiler_inputs_implementation=dict(path=str(impl),sha256=sha(impl)),compiler_build_script=dict(path=str(build),sha256=sha(build)),expected_production_compiler_fingerprint=next(iter(fp)),scope='Exactly two Engine integration-test source expressions use the existing real Test262-authorized host entry. Assertions and production source are unchanged; original failures and all measured producer IDs remain preserved.')
save(c/'source-equivalence.json',proof)
out=b/'source-corrected-2';out.mkdir();(out/'tracked.patch').write_bytes(subprocess.check_output(['git','diff','--binary','HEAD']))
new=dict(m);new['tracked_patch_sha256']=sha(out/'tracked.patch');new['files']=dict(m['files'])
for r in rows:new['files'][r['path']]=r['candidate_sha256']
for relative,expected in new['files'].items():
 assert sha(relative)==expected
 dest=out/'files'/relative;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(Path(relative).read_bytes())
shutil.copytree(parent.parent/'baseline',out/'baseline')
new['test_only_delivery']=dict(path=str(c/'source-equivalence.json'),sha256=sha(c/'source-equivalence.json'))
new['scope']='Delivered test-only host-setup child of measured source-corrected-1; production products and measurements keep their original source/binary identities.'
save(out/'manifest.json',new)
save(b/'active-test-delivery.json',dict(schema='scriptw-live-test-only-delivery-v1',measured=dict(path=str(parent),sha256=sha(parent)),delivered=dict(path=str(out/'manifest.json'),sha256=sha(out/'manifest.json')),equivalence=new['test_only_delivery']))
print('TEST-ONLY DELIVERY CHILD PINNED',sha(out/'manifest.json'))
