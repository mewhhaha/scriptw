import hashlib,json,subprocess,time
from pathlib import Path
base=Path('target/performance-v8-climb-20261104/strict-arguments-execution').resolve()
report=json.loads((base.parent/'fiber-only/situations-1/report.json').read_text())
node=Path(report['tools']['node']['path']);node_sha=report['tools']['node']['sha256']
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert digest(node)==node_sha
out=base/'node-oracles-1';out.mkdir();rows=[]
harness=out/'script.cjs'
harness.write_text("const fs=require('node:fs'),vm=require('node:vm');globalThis.print=(value)=>process.stdout.write(String(value)+'\\n');const source=fs.readFileSync(process.argv[2],'utf8');vm.runInThisContext(process.argv[3]+source,{filename:process.argv[2]});\n")
for fixture,expected in [('strict_arguments_projection.js','strict arguments projection ok\n'),('numeric_body.js','numeric body ok\n')]:
 source=Path('crates/scriptw-engine/tests/fixtures')/fixture
 for mode in ('Script','strictScript','Module'):
  assert digest(node)==node_sha
  if mode=='Module':
   adapted=out/(fixture+'.mjs');adapted.write_text("globalThis.print=(value)=>process.stdout.write(String(value)+'\\n');\n"+source.read_text())
   argv=[str(node),'--expose-gc',str(adapted)]
  else:
   adapted=harness
   prefix=''
   if mode=='strictScript':prefix="'use strict';\n"
   argv=[str(node),'--expose-gc',str(harness),str(source.resolve()),prefix]
  label=fixture+'.'+mode;started=time.monotonic_ns()
  with (out/(label+'.stdout')).open('xb') as so,(out/(label+'.stderr')).open('xb') as se:
   child=subprocess.run(argv,stdout=so,stderr=se,timeout=60)
  row=dict(fixture=str(source),fixture_sha256=digest(source),mode=mode,argv=argv,adapter_sha256=digest(adapted),node_sha256=node_sha,exit_code=child.returncode,elapsed_ns=time.monotonic_ns()-started,stdout_sha256=digest(out/(label+'.stdout')),stderr_sha256=digest(out/(label+'.stderr')))
  rows.append(row);(out/'receipt.json').write_text(json.dumps(dict(complete=False,rows=rows),indent=2)+'\n')
  assert child.returncode==0,label
  assert (out/(label+'.stdout')).read_text()==expected,label
  assert not (out/(label+'.stderr')).read_bytes(),label
  assert digest(node)==node_sha
(out/'receipt.json').write_text(json.dumps(dict(complete=True,node_version=report['tools']['node']['version'],rows=rows,scope='Portable fixtures in actual Script, strict Script and Module Node contexts; --expose-gc and print adapter only. No fabricated $262. Separate Realm fixtures require Engine.'),indent=2)+'\n')
print('SIX PINNED NODE PORTABLE ORACLES PASS',out/'receipt.json')
