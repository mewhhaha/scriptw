import hashlib,json,re,subprocess,time
from pathlib import Path
b=Path('target/performance-v8-climb-20261104/strict-arguments-execution').resolve();out=b/'realm-diagnostic-2';out.mkdir();rows=[]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
for case,file in [('projection','crates/scriptw-engine/tests/aot_language/aot_strict_arguments_projection.rs'),('numeric','crates/scriptw-engine/tests/aot_language/aot_numeric_body.rs')]:
 text=Path(file).read_text();sources=re.findall('r#"(.*?)"#',text,re.S);source=sources[-1].replace('$262.createRealm()', '__scriptwCreateRealm()')
 fixture=out/(case+'.js');fixture.write_text('try {\n'+source+'\n} catch (diagnosticError) { print("DIAGNOSTIC "+String(diagnosticError)); throw diagnosticError; }\n')
 for role,binary in [('baseline',b.parent/'fiber-only/products-1/frozen/scriptw'),('candidate',b/'build-2/frozen/scriptw')]:
  argv=[str(binary),'run','--host-surface','test262','--execution-backend','wasm',str(fixture)];label=case+'-'+role;start=time.monotonic_ns()
  with (out/(label+'.stdout')).open('xb') as so,(out/(label+'.stderr')).open('xb') as se:r=subprocess.run(argv,stdout=so,stderr=se,timeout=60)
  rows.append(dict(case=case,role=role,argv=argv,exit_code=r.returncode,elapsed_ns=time.monotonic_ns()-start,binary_sha256=sha(binary),source_sha256=sha(fixture),original_rust_fixture_sha256=sha(file),stdout_sha256=sha(out/(label+'.stdout')),stderr_sha256=sha(out/(label+'.stderr'))))
  (out/'receipt.json').write_text(json.dumps(dict(complete=False,rows=rows),indent=2)+'\n')
(out/'receipt.json').write_text(json.dumps(dict(complete=True,rows=rows,limits='Unscored diagnostic only. Same new Realm fixture with outer exception-print adapter across retained/current ordinary CLI; no compiler source change.'),indent=2)+'\n')
print('FOUR REALM CLI DIAGNOSTICS RECORDED',out)
