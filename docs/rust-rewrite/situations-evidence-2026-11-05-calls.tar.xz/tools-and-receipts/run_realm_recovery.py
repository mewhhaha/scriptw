import json,re,shutil,subprocess,sys,time
from pathlib import Path
b=Path('target/performance-v8-climb-20261104/strict-arguments-execution').resolve();sys.path.insert(0,str(b))
from common import artifacts,check_source,read,save,sha
source=b/'source-corrected-2/manifest.json';check_source(source)
out=b/'realm-recovery-1';out.mkdir();receipt=dict(schema='scriptw-realm-test-recovery-phase-v1',phase='aot-language-test-recovery',complete=False,source_manifest_sha256=sha(source),source_manifest=str(source),measured_source_manifest_sha256=sha(b/'source-corrected-1/manifest.json'),producer_commands=[],artifacts=[],scopes=[],inventories={})
def persist():save(out/'receipt.json',receipt)
def run(label,argv,test=False):
 check_source(source);start=time.monotonic_ns();command=['python3','-B','scripts/limited_verification.py','--',*map(str,argv)]
 print('START',label,flush=True)
 with (out/(label+'.stdout')).open('xb') as so,(out/(label+'.stderr')).open('xb') as se:r=subprocess.run(command,stdout=so,stderr=se,timeout=3600)
 row=dict(label=label,argv=list(map(str,argv)),capped_argv=command,source_manifest_sha256=sha(source),exit_code=r.returncode,timed_out=False,elapsed_ns=time.monotonic_ns()-start,stdout=str(out/(label+'.stdout')),stderr=str(out/(label+'.stderr')),stdout_sha256=sha(out/(label+'.stdout')),stderr_sha256=sha(out/(label+'.stderr')))
 if test:
  row.update(package='scriptw-engine',target='aot_language',executable_sha256=sha(argv[0]))
  m=re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;',Path(row['stdout']).read_text());assert len(m)==1
  state,passed,failed,ignored=m[0];row['outcomes']=dict(state=state,passed=int(passed),failed=int(failed),ignored=int(ignored));receipt['scopes'].append(row)
 else:receipt['producer_commands'].append(row)
 persist();print('END',label,r.returncode,flush=True);assert r.returncode==0,label;check_source(source);return row
persist()
cargo=run('cargo',['cargo','--config','build.jobs=1','build','--release','--locked','-p','scriptw-engine','--test','aot_language','--message-format=json-render-diagnostics'])
selected=[r for r in artifacts(cargo['stdout']) if r['target']['name']=='aot_language' and r['profile']['test'] is True];assert len(selected)==1
artifact=selected[0];binary=Path(artifact['executable']);(out/'frozen').mkdir();frozen=out/'frozen/aot_language';shutil.copy2(binary,frozen);assert sha(binary)==sha(frozen)
producer=dict(artifact=artifact,sha256=sha(frozen),frozen_executable_sha256=sha(frozen),frozen_path=str(frozen),bytes=frozen.stat().st_size,source_manifest_sha256=sha(source),cargo_stdout=cargo['stdout'],cargo_stdout_sha256=cargo['stdout_sha256']);receipt['artifacts'].append(producer);persist()
logs=[json.loads(s) for s in Path(cargo['stdout']).read_text().splitlines() if s]
fp={v for r in logs if r.get('reason')=='build-script-executed' for k,v in r.get('env',[]) if k=='SCRIPTW_COMPILER_FINGERPRINT'}
assert fp=={read(b/'realm-test-correction-1/source-equivalence.json')['expected_production_compiler_fingerprint']},fp
receipt['unchanged_production_compiler_fingerprint']=next(iter(fp));persist()
inv=run('inventory',[frozen,'--list','--format','terse']);names=[s.removesuffix(': test') for s in Path(inv['stdout']).read_text().splitlines() if s.endswith(': test')]
old=read(b/'focused-1/inventory-aot_language.json');assert names==old['tests'];receipt['inventories']['aot_language']=dict(tests=names,count=len(names),executable_sha256=sha(frozen));persist()
for label,name in [('projection-realm','aot_strict_arguments_projection::absent_index_uses_the_defining_realm_object_and_getter_error'),('numeric-realm','aot_numeric_body::numeric_body_miss_uses_actual_callable_realm_and_cell_identity')]:
 row=run(label,[frozen,name,'--exact','--test-threads=1'],test=True)
 assert row['outcomes']==dict(state='ok',passed=1,failed=0,ignored=0)
receipt['complete']=True;persist();print('EXACT TWO REALM TEST RECOVERIES PASS; PRODUCTION PRODUCTS UNCHANGED',out/'receipt.json',flush=True)
