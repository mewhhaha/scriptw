"""Explicit serial verification phases; every heavy child is resource-capped."""
import argparse
from datetime import datetime, timezone
import os
from pathlib import Path
import re
import shutil
import subprocess
import time
from common import BASE, ROOT, artifacts, check_source, read, save, sha

SUMMARY = re.compile(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;')
FOCUS = (
    ('emission', 'strict_arguments_projection::'),
    ('emission', 'numeric_body::'),
    ('aot_language', 'aot_strict_arguments_projection::'),
    ('aot_language', 'aot_numeric_body::'),
)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--phase', choices=('focused-build', 'focused'), required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--producer', type=Path, help='completed focused-build receipt.json')
    parser.add_argument('--filter', action='append', default=[], help='run only matching planned focused filters')
    args = parser.parse_args()
    source = args.source.resolve(strict=True)
    check_source(source)
    output = args.output.resolve()
    assert output.is_relative_to(ROOT / 'target') and not output.exists()
    output.mkdir(parents=True)
    receipt = dict(schema='scriptw-projection-numeric-pilot-phase-v1', complete=False, phase=args.phase,
        source_manifest_sha256=sha(source), source_manifest=str(source), tooling_sha256=sha(__file__),
        scopes=[], producer_commands=[], artifacts=[], started_at=datetime.now(timezone.utc).isoformat(),
        limits='Focused scopes may overlap. No broad suite, Test262 or publication completion is implied.')

    def persist():
        save(output / 'receipt.json', receipt)

    def run(label, argv, test=None, expected=None, timeout=3600):
        check_source(source)
        command = ['python3', '-B', str(ROOT / 'scripts/limited_verification.py'), '--', *map(str, argv)]
        stdout, stderr = output / (label + '.stdout'), output / (label + '.stderr')
        print('START', label, flush=True)
        start = time.monotonic_ns()
        timed_out = False
        with stdout.open('xb') as out, stderr.open('xb') as err:
            try:
                child = subprocess.run(command, cwd=ROOT, stdout=out, stderr=err, timeout=timeout)
                exit_code = child.returncode
            except subprocess.TimeoutExpired:
                timed_out = True
                exit_code = None
        row = dict(label=label, argv=list(map(str, argv)), capped_argv=command,
            source_manifest_sha256=sha(source), exit_code=exit_code, timed_out=timed_out,
            elapsed_ns=time.monotonic_ns() - start, stdout=str(stdout), stderr=str(stderr),
            stdout_sha256=sha(stdout), stderr_sha256=sha(stderr))
        if test:
            row.update(package=test['package_id'], target=test['target']['name'],
                executable_sha256=sha(argv[0]))
            receipt['scopes'].append(row)
            persist()
            summaries = SUMMARY.findall(stdout.read_text())
            assert len(summaries) == 1, 'missing/ambiguous libtest result: ' + label
            state, passed, failed, ignored = summaries[0]
            row['outcomes'] = dict(state=state, passed=int(passed), failed=int(failed), ignored=int(ignored))
            assert int(passed) + int(failed) == expected and int(ignored) == 0
        else:
            receipt['producer_commands'].append(row)
        persist()
        check_source(source)
        print('END', label, exit_code, flush=True)
        assert not timed_out and exit_code == 0, label
        return stdout

    def freeze(log, test, names=None):
        frozen = output / 'frozen'
        frozen.mkdir(exist_ok=True)
        if names is None:
            names = {'emission', 'aot_language'}
        selected = [row for row in artifacts(log) if row['profile']['test'] == test and row['target']['name'] in names]
        for row in selected:
            binary = Path(row['executable'])
            destination = frozen / row['target']['name']
            assert not destination.exists(), 'ambiguous executable target name'
            expected = sha(binary)
            shutil.copy2(binary, destination)
            assert sha(destination) == sha(binary) == expected
            producer = dict(artifact=row, sha256=expected, frozen_executable_sha256=expected,
                frozen_path=str(destination), bytes=destination.stat().st_size,
                source_manifest_sha256=sha(source), cargo_stdout=str(log), cargo_stdout_sha256=sha(log))
            save(frozen / (row['target']['name'] + '-producer.json'), producer)
            receipt['artifacts'].append(producer)
        persist()

    persist()
    cargo = ['cargo', '--config', 'build.jobs=1']
    if args.phase == 'focused-build':
        log = run('pilot-build', cargo + ['build', '--release', '--locked',
            '-p', 'scriptw-cli', '-p', 'scriptw-aot-wasm', '-p', 'scriptw-engine',
            '--test', 'emission', '--test', 'aot_language',
            '--example', 'rsc_baseline', '--example', 'compiler_precompiled_baseline',
            '--message-format=json-render-diagnostics'])
        freeze(log, True, {'emission', 'aot_language'})
        freeze(log, False, {'rsc_baseline', 'compiler_precompiled_baseline'})
        # Preserve the CLI-only production graph as a separate producer.
        cli = run('cli-only-build', cargo + ['build', '--release', '--locked', '-p', 'scriptw-cli',
            '--bin', 'scriptw', '--message-format=json-render-diagnostics'])
        freeze(cli, False, {'scriptw'})
        assert {'emission', 'aot_language', 'rsc_baseline', 'compiler_precompiled_baseline', 'scriptw'} == {row['artifact']['target']['name'] for row in receipt['artifacts']}
    else:
        producer = read(args.producer)
        assert producer['complete'] and producer['phase'] == 'focused-build'
        assert producer['source_manifest_sha256'] == sha(source)
        binaries = {row['artifact']['target']['name']: row for row in producer['artifacts']}
        plan = FOCUS
        if args.filter:
            plan = tuple(row for row in plan if row[1] in args.filter)
            assert {row[1] for row in plan} == set(args.filter), 'unknown focused filter'
        assert plan
        inventories = {}
        for target, pattern in plan:
            binary = binaries[target]
            executable = Path(binary['frozen_path'])
            assert sha(executable) == binary['sha256']
            if target not in inventories:
                log = run('inventory-' + target, [executable, '--list', '--format', 'terse'])
                names = [line.removesuffix(': test') for line in log.read_text().splitlines() if line.endswith(': test')]
                assert names and len(set(names)) == len(names)
                inventories[target] = names
                save(output / ('inventory-' + target + '.json'), dict(executable_sha256=sha(executable),
                    source_manifest_sha256=sha(source), tests=names, count=len(names)))
            selected = [name for name in inventories[target] if pattern in name]
            assert selected, 'focused filter matches no real tests: ' + pattern
            label = target + '-' + (pattern.replace('::', '-').rstrip('-') or 'full')
            run(label, [executable, pattern, '--test-threads=1'], test=binary['artifact'], expected=len(selected))
    receipt.update(complete=True, finished_at=datetime.now(timezone.utc).isoformat())
    persist()
    print('COMPLETED', args.phase, output / 'receipt.json', flush=True)


if __name__ == '__main__':
    main()
