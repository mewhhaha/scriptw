"""Admit Astra's sealed patch only on the published retained fiber checkpoint."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[3]
BASE = Path(__file__).resolve().parent
PRODUCTION_BASE = '046c64735af42497b8eea3aa346ff71d81c0b76f'
STAGE = BASE.parent / 'strict-arguments-projection-staged'
MANIFEST_SHA = '8fe3a4d146846fcf42a7d545756c048b2d73cd23108dad000908222b5fbd8fb7'
NUMERIC_STAGE = BASE.parent / 'numeric-body-staged'
NUMERIC_MANIFEST_SHA = '07f96d827d2ef0942edaaaf8fd53ab9805ed9e6c890937c5ff6021026f053e9e'
CORRECTION_STAGE = BASE.parent / 'numeric-body-api-correction'
CORRECTION_PATCH_SHA = '5247d4111d50578b4620fc3309f650f0401c9f7e2b87ae6449406d15f9b6e4be'
FIBER_SOURCE = '6ea9b49f40c4b168d37ee9fe45dae671d67a94be9f0166a18393eb9f6a9ee767'


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--published-base', required=True, help='new fiber publication commit, not046c')
    parser.add_argument('--baseline-situations', type=Path, required=True)
    parser.add_argument('--baseline-rsc-raw', type=Path, required=True)
    args = parser.parse_args()
    assert not (BASE / 'admission.json').exists(), 'admission already sealed'
    assert not git('status', '--porcelain', '--untracked-files=all').strip(), 'publish/commit retained fiber first'
    retained_base = git('rev-parse', args.published_base + '^{commit}').decode().strip()
    assert retained_base == git('rev-parse', 'HEAD').decode().strip() and retained_base != PRODUCTION_BASE
    assert digest(STAGE / 'manifest.json') == MANIFEST_SHA
    manifest = json.loads((STAGE / 'manifest.json').read_text())
    assert manifest['base_commit'] == PRODUCTION_BASE and manifest['runtime_abi'] == 51
    assert digest(STAGE / manifest['patch']) == manifest['patch_sha256']
    per_file = []
    final_hashes = {}
    for row in manifest['files']:
        relative = Path(row['path'])
        assert not relative.is_absolute() and '..' not in relative.parts
        candidate = STAGE / 'candidate' / relative
        assert digest(candidate) == row['candidate_sha256']
        if row['base_sha256'] is None:
            assert not (ROOT / relative).exists(), 'new-file conflict: ' + str(relative)
        else:
            original = git('show', PRODUCTION_BASE + ':' + relative.as_posix())
            assert hashlib.sha256(original).hexdigest() == row['base_sha256']
            assert digest(ROOT / relative) == row['base_sha256'], 'retained fiber changed this patch owner; rebase explicitly: ' + str(relative)
        per_file.append(row)
        final_hashes[row['path']] = row['candidate_sha256']
    assert digest(NUMERIC_STAGE / 'manifest.json') == NUMERIC_MANIFEST_SHA
    numeric = json.loads((NUMERIC_STAGE / 'manifest.json').read_text())
    assert numeric['base_commit'] == PRODUCTION_BASE and numeric['runtime_abi'] == 51
    assert numeric['base_overlay_dependency']['sha256'] == manifest['patch_sha256']
    assert numeric['base_overlay_dependency']['manifest_sha256'] == MANIFEST_SHA
    assert digest(NUMERIC_STAGE / numeric['patch']) == numeric['patch_sha256']
    numeric_files = []
    for row in numeric['files']:
        relative = Path(row['path'])
        assert not relative.is_absolute() and '..' not in relative.parts
        assert digest(NUMERIC_STAGE / 'candidate' / relative) == row['candidate_sha256']
        if row['path'] in final_hashes:
            assert row['base_sha256'] == final_hashes[row['path']], 'numeric dependency does not match projection output'
        elif row['base_sha256'] is None:
            assert not (ROOT / relative).exists(), 'numeric new-file conflict'
        else:
            original = git('show', PRODUCTION_BASE + ':' + relative.as_posix())
            assert hashlib.sha256(original).hexdigest() == digest(ROOT / relative) == row['base_sha256']
        numeric_files.append(row)
        final_hashes[row['path']] = row['candidate_sha256']
    correction = json.loads((CORRECTION_STAGE / 'manifest.json').read_text())
    assert correction['parent_patch_sha256'] == numeric['patch_sha256']
    assert correction['patch_sha256'] == digest(CORRECTION_STAGE / 'correction.patch') == CORRECTION_PATCH_SHA
    assert final_hashes[correction['path']] == correction['base_sha256']
    assert digest(CORRECTION_STAGE / 'candidate' / correction['path']) == correction['candidate_sha256']
    final_hashes[correction['path']] = correction['candidate_sha256']
    public = {}
    for name in ('rsc-current.json', 'situations-current.json'):
        raw = git('show', retained_base + ':docs/rust-rewrite/' + name)
        public[name] = json.loads(raw)
    assert public['rsc-current.json']['publication']['measured_source']['manifest_sha256'] == FIBER_SOURCE
    assert public['rsc-current.json']['source_identity']['broad_qualification_complete'] is True
    old_rsc = json.loads(args.baseline_rsc_raw.read_text())
    old_situations = json.loads((args.baseline_situations / 'report.json').read_text())
    assert old_rsc['status'] == 'complete' and old_situations['complete'] and old_situations['status'] == 'complete'
    identity = public['rsc-current.json']['engines']['candidate']['identity']
    assert all(old_rsc[key] == value for key, value in identity.items())
    assert old_situations['source_identity'] == public['situations-current.json']['source_identity']
    assert old_situations['policy']['warmups'] == 100 and old_situations['policy']['samples'] == 21
    selected = [row for row in old_situations['workloads'] if row['file'] in ('args-unused.js', 'args-observed.js')]
    assert len(selected) == 2
    for row in selected:
        assert digest(args.baseline_situations / 'sources' / row['file']) == row['source_sha256']
    assert manifest['scored_source']['sha256'] == next(row['source_sha256'] for row in selected if row['file'] == 'args-observed.js')
    numeric_unused = next(row for row in numeric['fixtures'] if row['source'].endswith('/args-unused.js'))
    assert numeric_unused['sha256'] == next(row['source_sha256'] for row in selected if row['file'] == 'args-unused.js')
    context = dict(schema='scriptw-strict-arguments-context-v1', complete=True,
        retained_base_git=retained_base, retained_fiber_source_manifest_sha256=FIBER_SOURCE,
        original_production_base_git=PRODUCTION_BASE, staged_manifest_sha256=MANIFEST_SHA,
        staged_patch=dict(path=str(STAGE / manifest['patch']), sha256=manifest['patch_sha256']),
        per_file_base_and_candidate=per_file,
        numeric_dependency_manifest_sha256=NUMERIC_MANIFEST_SHA, numeric_files=numeric_files,
        ordered_patches=[dict(path=str(STAGE / manifest['patch']), sha256=manifest['patch_sha256']),
                         dict(path=str(NUMERIC_STAGE / numeric['patch']), sha256=numeric['patch_sha256']),
                         dict(path=str(CORRECTION_STAGE / 'correction.patch'), sha256=CORRECTION_PATCH_SHA)],
        final_file_hashes=final_hashes,
        api_correction=dict(manifest_sha256=digest(CORRECTION_STAGE / 'manifest.json'), **correction),
        baseline_situations=dict(path=str(args.baseline_situations.resolve()), report_sha256=digest(args.baseline_situations / 'report.json')),
        baseline_rsc=dict(raw_report=str(args.baseline_rsc_raw.resolve()), raw_report_sha256=digest(args.baseline_rsc_raw), identity=identity),
        limits='Patch not applied; no compiler, native, Node or guest workload executed. Initial discriminator excludes private AOT libtest build. Hash-authority tooling may join this same future freeze only after its separate bounded cost/control check.')
    for name, value in public.items():
        (BASE / ('baseline-' + name)).write_text(json.dumps(value, indent=2) + '\n')
    (BASE / 'admission.json').write_text(json.dumps(context, indent=2) + '\n')
    print('PUBLISHED FIBER BASE AND ORDERED ASTRA PATCHES ADMITTED; NO CANONICAL APPLY', BASE / 'admission.json')


if __name__ == '__main__':
    main()
