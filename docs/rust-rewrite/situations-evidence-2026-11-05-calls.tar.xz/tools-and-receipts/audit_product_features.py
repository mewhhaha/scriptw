import argparse,collections,json,sys
from pathlib import Path
b=Path('target/performance-v8-climb-20261104/strict-arguments-execution').resolve();sys.path.insert(0,str(b))
from common import check_source,save,sha
parser=argparse.ArgumentParser();parser.add_argument('--source',type=Path,required=True);parser.add_argument('--build',type=Path,required=True);args=parser.parse_args()
source=args.source.resolve();check_source(source)
def inventory(path):
 rows=[json.loads(x) for x in path.read_text().splitlines() if x]
 assert [r['success'] for r in rows if r.get('reason')=='build-finished']==[True]
 return collections.Counter(json.dumps(dict(package=r['package_id'],target=r['target'],profile=r['profile'],features=r['features']),sort_keys=True) for r in rows if r.get('reason')=='compiler-artifact')
def decoded(counter):return [dict(json.loads(k),count=v) for k,v in sorted(counter.items())]
proof=dict(schema='scriptw-projection-numeric-product-feature-comparison-v1',complete=False,source_manifest_sha256=sha(source),roles=[])
for role,old,new in [('ordinary-examples','products-1/examples-build.stdout','pilot-build.stdout'),('ordinary-cli','products-1/cli-only-build.stdout','cli-only-build.stdout')]:
 baseline=b.parent/'fiber-only'/old;candidate=args.build.resolve()/new
 a,c=inventory(baseline),inventory(candidate)
 missing,additional=a-c,c-a
 row=dict(role=role,baseline=dict(path=str(baseline),sha256=sha(baseline)),candidate=dict(path=str(candidate),sha256=sha(candidate)),baseline_only=decoded(missing),candidate_only=decoded(additional))
 allowed=[]
 if role=='ordinary-examples':
  for k,v in list(additional.items()):
   r=json.loads(k)
   if r['profile']['test'] is True and r['target']['kind']==['test'] and r['target']['name'] in ('emission','aot_language'):
    allowed.append(dict(r,count=v));del additional[k]
 row['additional_initial_integration_artifacts']=allowed;row['ordinary_multiset_matches']=not missing and not additional
 proof['roles'].append(row)
 save(b/'product-feature-comparison.json',proof)
 assert row['ordinary_multiset_matches'],role
proof.update(complete=True,limits='Ordinary package/target/profile/feature multisets match fiber by producer role; only the two declared initial integration test artifacts may be additional. Source/HEAD/compiler identities remain separate; no isolated causal attribution.')
check_source(source);save(b/'product-feature-comparison.json',proof)
print('ORDINARY EXAMPLES AND SEPARATE CLI CARGO FEATURE MULTISETS MATCH FIBER')
