use scriptw_ir::{lower_module_graph, ModuleGraphSources, ModuleKey, ModuleSourceIr, StatementIr, ResumableRegionProtocolIr};
fn flatten<'a>(statements: &'a [StatementIr], result: &mut Vec<&'a StatementIr>) {
    for statement in statements {
        match statement {
            StatementIr::Block(block) => flatten(&block.statements,result),
            StatementIr::LexicalBlock(items) => flatten(items,result),
            StatementIr::EmptyStatementCompletion(item) => flatten(std::slice::from_ref(item.statement()),result),
            statement => result.push(statement),
        }
    }
}
fn main() {
    for (label, source) in [
        ("sync-combined", "for (var key in {first: 1}) print(key); for (const value of ['last']) print(value);"),
        ("tla-combined", "for (var key in {first: 1}) { await key; } for (const value of ['last']) { await value; }"),
        ("tla-for-in-var", "for (var key in {first:1}) { await key; }"),
        ("tla-for-in-let", "for (let key in {first:1}) { await key; }"),
        ("tla-for-in-const", "for (const key in {first:1}) { await key; }"),
        ("tla-for-in-dynamic", "const object={first:1}; for (var key in object) { await key; }"),
        ("async-function", "async function g(){for(var key in {first:1}){await key;}} g();"),
        ("tla-for-of", "for (const value of ['last']) { await value; }"),
    ] {
        let source=format!("{source}\nexport function* nestedGenerator(view,values){{for(const key in view)yield key;for(const value of values)yield value;}}\nexport async function nestedAsync(view,values){{for(const key in view)await key;for(const value of values)await value;}}");
        let sources=ModuleGraphSources {realm_requests:Default::default(),modules:vec![ModuleSourceIr::new(ModuleKey::from_host("entry.js"),source,"file:///entry.js".into())],entry:0,resolutions:vec![]};
        let program=lower_module_graph(&sources);
        println!("{label}: supported={} diagnostics={:?}",program.is_wasm_supported(),program.diagnostics);
        assert!(program.is_wasm_supported(),"{label}");
        let script=program.script.as_ref().unwrap();
        for (name,expected) in [("nestedGenerator",ResumableRegionProtocolIr::Generator),("nestedAsync",ResumableRegionProtocolIr::Async)] {
            let function=script.functions.iter().find(|function|function.name==name).unwrap();
            let mut statements=Vec::new();flatten(&function.body.statements,&mut statements);let mut loops=Vec::new();
            for statement in statements {
                match statement {
                    StatementIr::AsyncGeneratorForIn(plan)=>{assert_eq!(plan.execution(),expected);loops.push("for-in");},
                    StatementIr::AsyncGeneratorForOf(plan)=>{assert_eq!(plan.execution(),expected);loops.push("for-of");},
                    _=>{}
                }
            }
            assert_eq!(loops,["for-in","for-of"],"{label}:{name}");
        }
        println!("{label}: nested generator/async ForIn/ForOf owners preserved");
    }
}
