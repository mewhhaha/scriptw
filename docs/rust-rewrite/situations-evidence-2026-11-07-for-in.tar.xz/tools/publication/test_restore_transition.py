"""Pure restore-witness checks; never edits the checkout or creates source receipts."""
import hashlib
from pathlib import Path
import unittest

BASE = Path(__file__).resolve().parents[1]
namespace = {'__file__': str(BASE / 'common.py'), '__name__': 'proposed_restore_authority'}
exec(compile((Path(__file__).parent / 'common-source/common.py').read_text(), str(BASE/'common.py'), 'exec'), namespace)
validate = namespace['validate_restoration']


class RestoreWitnessTests(unittest.TestCase):
    def setUp(self):
        self.path = 'crates/scriptw-ir/src/analysis/eval_environment.rs'
        self.base = b'canonical fixture bytes\n'
        self.digest = hashlib.sha256(self.base).hexdigest()
        self.parent = {self.path: hashlib.sha256(b'modified fixture bytes\n').hexdigest()}
        self.witness = dict(base_git='fixture-base', base_sha256=self.digest, parent_sha256=self.parent[self.path])

    def call(self, path=None, parent=None, child=None, base=None, witness=None):
        if path is None: path = self.path
        if parent is None: parent = self.parent
        if child is None: child = {}
        if base is None: base = self.base
        if witness is None: witness = self.witness
        return validate(path, parent, child, 'fixture-base', base, witness)

    def test_explicit_modified_parent_can_restore_to_base(self):
        self.assertEqual(self.call(), self.digest)

    def test_wrong_base_digest_is_rejected(self):
        witness = dict(self.witness, base_sha256='0'*64)
        with self.assertRaises(AssertionError): self.call(witness=witness)

    def test_wrong_ancestor_digest_is_rejected(self):
        witness = dict(self.witness, parent_sha256='0'*64)
        with self.assertRaises(AssertionError): self.call(witness=witness)

    def test_clean_parent_is_not_a_restore(self):
        witness = dict(self.witness, parent_sha256=self.digest)
        with self.assertRaises(AssertionError): self.call(parent={self.path:self.digest}, witness=witness)

    def test_restore_must_be_removed_from_dirty_snapshot(self):
        with self.assertRaises(AssertionError): self.call(child={self.path:self.digest})

    def test_missing_parent_and_base_mismatch_are_rejected(self):
        with self.assertRaises(AssertionError): self.call(parent={})
        with self.assertRaises(AssertionError): self.call(witness=dict(self.witness,base_git='other-base'))

    def test_abi_paths_and_path_escape_are_rejected(self):
        for path in ('crates/scriptw-aot-wasm/src/runtime_artifact.rs',
            'crates/scriptw-aot-wasm/src/runtime_abi.rs',
            'crates/scriptw-aot-wasm/src/gc_types/layouts.rs', '../outside.rs'):
            with self.subTest(path=path):
                with self.assertRaises(AssertionError): self.call(path=path,parent={path:self.parent[self.path]})


if __name__ == '__main__':
    unittest.main()
