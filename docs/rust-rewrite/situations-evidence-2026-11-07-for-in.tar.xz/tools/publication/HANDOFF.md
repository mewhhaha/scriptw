Source-only publication preparation. No native build/execution, measurement,
broad qualification or publication was run by this helper owner. Root owns
canonical writes, retention and shipping; native_recovery owns the native queue.

## Current source and scope

`../source-final-1/manifest.json` is the previous genuine batch, now retained
as historical after the late Module-wrapper bug was found:
SHA-256 `0c506d213c7549f269995a7d29b524283fd214cad8df3972c863abc36146f7cf`.
Its parents remain exact originals:

- Initial Set52: `3fd32c2ba736b4bc37202404d291b379c05ea4fec37da7787637cefb82293c1c`.
- Scalar52 before the Module IR fix: `f40280e14b5b17b18d0711fbb43abc4bf2eea926ca5cfd0902dc0791d0f935c5`.

All share base `e9687a06ed89933d0210bcb897b0387be00f9925`; runtime ABI remains 52.
The upcoming genuine wrapper-owner correction restores the ineffective
`analysis/eval_environment.rs` edit and fixes the existing ForOf cleanup to cover
ForIn. It is a production change; use the actual new admitted manifest (planned
fresh directory `source-final-2`), never relabel the previous products. Old IR scope receipts and old
scalar products/failures remain historical and cannot qualify the final batch.
The only older-scope exception is the explicit single cfg(test) assertion
correction below. It qualifies relevant IR integration/probe inputs, never the
Engine/compiler fingerprint or final product build.

The broad ledger is **15 scopes** (14 fresh plus one qualified original IR
integration scope for the current test-only correction): `scriptw_ir` unit,
`scriptw_ir_integration`, AOT unit, emission, six structural, Engine unit and
four Engine integrations. Counts come from actual inventories and outcomes;
there is no hardcoded expected IR count. The four exact historical AOT failure
names remain counted. No separate front-only result is inferred from old IR.

`run_broad.py --ir-foundation ACTUAL_RECEIPT` accepts the completed mixed-source
`scriptw-ir-foundation-v1` receipt for the current final manifest. The actual
`ir-foundation-final-3/receipt.json` contains 1,630 fresh source3 IR unit passes
and the original 771 source2 integration passes, qualified to source3. It keeps
the old source/binary/log identities and exact Cargo artifact/feature rows.
Both full scopes have filter `''` and are preserved without another test run.
The earlier source2 unit result (1,629 passes, one stale assertion failure) stays
failed in its original receipt; it is not inherited as current unit coverage.

`ir-test-correction-final-3/qualification.json` is complete only after the actual
native owner checked the sole frozen-file delta (996→997 in
`lowering/builtin_catalog/tests.rs`), its cfg(test) owner, both real depfiles and
755 unchanged relevant inputs, configuration/toolchain, ordinary Cargo feature
multisets, current normal IR/integration `fresh:true` records and exact original
RLIB/executable bytes. The public helper rechecks that evidence and accepts the
qualification only for `scriptw_ir_integration`; IR unit and every product must
use the genuinely new source. The normal-library semantic probe keeps its source2
identity under the same relevant-input proof. The completed proof was exercised
read-only against the actual preserved integration artifact and scope; it passes.
Pending/incomplete proofs are rejected. No integration or probe was rerun by the
publication helper owner.

## Source admission

Native recovery already archived initial52/f402 helper bytes, activated the
chained authority, applied the reviewed production/test/doc batch, and froze the
final manifest. Do not reapply `common-followup-chain.patch` to an active file
that already contains it. `common-followup.patch` is the earlier historical
initial-to-scalar authority patch.

For the explicit restore transition, `source-0c506-authority-before-restore/`
already preserves the old common/freezer bytes and hashes. Native recovery also
owns its campaign tool archive. With no active helper/native job, archive current
authority, apply `common-explicit-restore.patch`, then capture the whole approved
source/test batch. Do not reapply that patch once `validate_restoration` is active.

For another explicitly selected correction, archive current active helper bytes
and hash/path maps before mutation, while no campaign/helper process is active.
The existing chained authority supports a new immutable child:

```sh
b=target/performance-v8-climb-20261104/for-in-set-execution
p="$b/publication-tools"
python3 -B "$p/freeze_followup.py" \
  --parent-source "$ACTUAL_PARENT_MANIFEST" \
  --file 'SELECTED_PATH=EXACT_FINAL_SHA256' \
  --file 'ANOTHER_SELECTED_PATH=EXACT_FINAL_SHA256' \
  --restore 'crates/scriptw-ir/src/analysis/eval_environment.rs=440f801d297ba4cc42000b4dca7febf0be3973ed3603dbe23970a1eb93088b1d' \
  --output "$FRESH_SOURCE_DIRECTORY"
```

Repeat `--file` for every changed/new dirty path; do not also list a restored
path as selected. Omit `--restore` when there is no canonical restore. A restore
must name a modified parent file; current bytes must exactly equal `git show`
of the pinned base. Its witness records base Git/base SHA and parent SHA. The
restored path is absent from candidate dirty files, never physically deleted.
The live source check validates all still-effective restored hashes across the
ancestor chain; a later explicit source change can supersede that clean witness.
ABI version/layout paths cannot use this restore transition. Seven pure
restore-witness tests pass without checkout mutation.

Repeat `--file` for every changed/new path. The constructor verifies every
frozen ancestor/admission/patch/file, every explicitly selected final hash and
every unchanged parent file. Deletion/runtime-artifact/ABI changes require a
separate review. An empty or unselected source change is rejected. Existing
source snapshots/admissions are never edited. No source equivalence is inferred.

## Actual final-input commands

Set each variable to the actual completed path. `SOURCE` is `source-final-3/manifest.json`, SHA-256
`49895ea4afe1cd82dd85257f6c46c47d75016366129784c1180445b258c88c99`.
Source-final-1 and its failed scopes remain historical and cannot qualify this batch. Use a complete final five-image
product receipt: emission/language tests, ordinary rsc/compiler examples and a
separately built ordinary CLI. The existing ordinary feature comparison requires
`ordinary-examples` and `ordinary-cli` roles, matching normal feature multisets,
source SHA and hash-bound metadata files. Historical audit receipts remain old.

After the actual width and RSC pilots pass and root retains them:

```sh
python3 scripts/limited_verification.py -- python3 -B "$p/run_broad.py" \
  --source "$SOURCE" --focused-producer "$PRODUCTS_RECEIPT" \
  --ir-foundation "$IR_FOUNDATION_RECEIPT" \
  --pilot "$RSC_DIR/aggregate.json" --width-pilot "$PAIRED_WIDTH_REPORT" \
  --width-baseline-report "$SET52_WIDTH_RAW_REPORT" \
  --pilot-retained --output "$BROAD_OUTPUT"
```

Omit `--ir-foundation` only when the broad driver must itself build and run both
IR scopes. There is no `--reuse-proof` option. The legacy `qualify_reuse.py`
remains historical tooling; its IR/front policy rejects the production IR diff,
and the new publisher does not read or accept its proof.

`--target NAME` can run an explicitly selected remaining scope. A subset receipt
cannot publish as complete. Preserve failures and passing receipts; do not label
omitted scopes passed or count filtered checks as full scopes.

```sh
python3 scripts/limited_verification.py -- python3 -B "$p/publish.py" \
  --source "$SOURCE" --native-report "$NATIVE_REPORT" \
  --products-receipt "$PRODUCTS_RECEIPT" \
  --feature-comparison "$FEATURE_COMPARISON" \
  --paired-retention "$PAIRED_WIDTH_REPORT" \
  --paired-situations-report "$FINAL_WIDTH_RAW_REPORT" \
  --paired-baseline-report "$SET52_WIDTH_RAW_REPORT" \
  --node-oracles "$CURRENT_NODE_ORACLES_RECEIPT" \
  --situations "$FINAL_FULL21_DIR" --rsc "$FINAL_RSC_DIR" \
  --source-guards "$CURRENT_SOURCE_GUARDS_STDOUT" --date 2026-11-07 \
  --extra-text-evidence "$INITIAL52_TOOLING_ARCHIVE" \
  --extra-text-evidence "$F402_TOOLING_ARCHIVE" \
  --extra-text-evidence "$INITIAL52_PAIRED_WIDTH_DIR" \
  --extra-text-evidence "$INITIAL52_RSC_DIR" \
  --extra-text-evidence "$ACTUAL_F402_BUILD_FOCUS_CLI_AUDIT_RECEIPTS" \
  --extra-text-evidence "$ACTUAL_FAILED_MODULE_REPRO_RECEIPTS" \
  --extra-text-evidence "$ACTUAL_FINAL_SOURCE_AUDITS" \
  --output "$PUBLICATION_STAGE"
python3 scripts/limited_verification.py -- \
  python3 -B "$p/check_publication.py" --stage "$PUBLICATION_STAGE"
python3 -B "$p/stage_docs.py" --stage "$PUBLICATION_STAGE" --output "$DOCS_STAGE"
```

Repeat extra-evidence options for actual files/directories; omit unavailable
options. Archive original successes **and failures**, including the f402 eight
passing focused cases, Module failures, CLI and audits, with original identities.
Helper archives must contain the original bytes plus hash/path maps because old
campaign inputs can name an active helper pathname that now contains new bytes.
The publisher does not rehash historical helper paths as though they were current.
It automatically archives every immutable source ancestor in `source/history/`.
The mixed-source IR foundation logs/receipt are archived separately and referenced
by both preserved full scopes. Original source2 integration/probe/failing-unit
logs plus the exact relevant-input proof are archived separately. Coverage keeps
`fresh_native` and `qualified_unchanged_native` distinct; only the latter contains
the original source2 integration with `qualified_final_source_manifest_sha256`. A fresh consolidated receipt should be a new
filename beside the original foundation receipt/logs; original receipts stay
unchanged. No old result is relabeled current.

Use only small ABI51 closure receipts/manifests as extra evidence; never add the
1.82-GB link-closure tree. Binary/native/Wasm/cache images are excluded from the
inert UTF-8 indexed archive. Old allocation/PMU/size JSON and the Nov 5 Calls
archive stay byte-identical and retain their original compiler/P/R identities.

## Measurement and status boundaries

The final scored situation matrix is 21 fresh programs/504 processes/60,984
checked calls if complete. The width control is the actual nine-case/five-actor
plan, currently 360 processes/43,560 calls. Both raw reports and producer
identities remain distinct. Original51→Set52 and Set52→final width controls are
separate. Public RSC compares historical51 with the final source; the original
51→Set52 and final51→final RSC campaigns remain separate archived cohorts. No
third RSC campaign or standalone scalar RSC effect is claimed.

RSC validation requires 24 actual complete balanced process rows and 480 exact
Flight checks, consistent inline count metadata, exact current source/host hashes,
and the historical public51 baseline identity. Fresh full21, width, RSC, products,
features, Node fixtures and source guards must bind their actual sources/images;
none of the planned counts above assert future success.

The archive basename is `situations-evidence-2026-11-07-for-in.tar.xz`. Only current
situations/RSC and `for-in-width-current.json` are refreshed. Staged README/details
show actual fresh IR unit counts and explicitly qualified original integration
counts/source/binary receipts, current
Fast/Speed/V8 width scores, scalar existence/enumerability observation without a
full ordinary descriptor clone, and remaining descriptor work. They state:
“32-row catalog; async adds a resolved Promise, with no I/O.”

Full pinned Test262 remains the old published result. Four known AOT assertions,
eleven formatting files and fourteen stale Intl recipes remain counted/owned;
use fresh final audits before publication. Full workspace CI is not implied.

## Root's canonical work

After retention and stage checks, review/copy staged docs, reports and archive,
then apply `renderer-width.patch` and render the existing current/V8 cards plus
one width card. There are no baseline bars or before/after chart tables.

```sh
git apply "$p/renderer-width.patch"
python3 scripts/limited_verification.py -- \
  python3 -B scripts/render-situation-benchmarks.py \
  --report docs/rust-rewrite/situations-current.json \
  --width-report docs/rust-rewrite/for-in-width-current.json \
  --output-dir docs/rust-rewrite/assets/situations-current \
  --preview-dir "$PUBLICATION_STAGE/chart-previews"
```

Use the established RSC renderer for both RSC cards, inspect all previews and
rerun each renderer with `--check`. Finally run the publication checker with
`--canonical`. It expects fifteen ledger scopes with the qualified integration explicitly
separated from exact-final-source scopes, source history,
the original twelve chart paths plus width, protected README/Test262 blocks and
unchanged historical diagnostic bytes. Canonical docs/renderer edits happen
after source-bound staging; every original measured source remains frozen.
