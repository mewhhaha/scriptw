"""Prepare reviewable README/details/inventory only in a fresh target directory."""
import argparse
from pathlib import Path
import re
import statistics
from common import ROOT, read, save, sha
from run_broad import ALL_TARGETS, ENGINE, IR, STRUCTURAL
from width import WIDTH_CASES


def replace_between(text, start, end, replacement):
    assert text.count(start) == text.count(end) == 1, (start, end)
    left, tail = text.split(start)
    _, right = tail.split(end)
    return left + replacement + end + right


def score(rsc, engine, case):
    return statistics.median(rsc['engines'][engine]['cases'][case]) / 1e6


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--stage', type=Path, required=True, help='actual completed publication stage')
    parser.add_argument('--output', type=Path, required=True, help='fresh target directory; canonical files are never written')
    args = parser.parse_args()
    stage = args.stage.resolve(strict=True)
    ready = read(stage / 'publication-ready.json')
    assert ready['complete'] and ready['canonical_files_written'] is False
    situations = read(stage / 'situations-current.json')
    rsc = read(stage / 'rsc-current.json')
    width = read(stage / 'for-in-width-current.json')
    for report in (situations, rsc, width):
        assert report['evidence_archive'] == ready['evidence_archive']
        assert report['publication']['measured_source']['manifest_sha256'] == ready['source_manifest_sha256']
    date = situations['publication']['date']
    fingerprint = situations['source_identity']['source_fingerprint'][:12]
    coverage = situations['publication']['coverage']
    qualified = coverage.get('qualified_unchanged_native', [])
    native_scopes = coverage['fresh_native'] + qualified
    scopes = {row['target']: row['outcomes'] for row in native_scopes}
    assert set(scopes) == set(ALL_TARGETS) and len(scopes) == 15
    assert scopes['scriptw_aot_wasm']['failed'] == 4 and coverage['reused_native'] == []
    engine = scopes['scriptw_engine']['passed']
    integrations = sum(scopes[target]['passed'] for target in ENGINE)
    structural = sum(scopes[target]['passed'] for target in STRUCTURAL)
    emission = scopes['emission']['passed']
    aot = scopes['scriptw_aot_wasm']['passed']
    guards = coverage['source_guards_passed']
    ir = sum(scopes[target]['passed'] for target in IR)
    assert ir == coverage['fresh_ir_passed'] + coverage.get('qualified_ir_passed', 0)
    calls = coverage['checked_invocations']
    rsc_calls = coverage['rsc_checked_invocations']
    phases = {name: statistics.median(row[name] for row in rsc['engines']['candidate']['phase_processes'])
              for name in ('source_to_wasm', 'native_preparation', 'module_initialization')}
    archive = Path(ready['evidence_archive']['file']).name
    ir_status = (f'{scopes["scriptw_ir"]["passed"]:,} IR unit and '
        f'{scopes["scriptw_ir_integration"]["passed"]:,} IR integration cases pass on this source.\n')
    if qualified:
        ir_status = (f'{scopes["scriptw_ir"]["passed"]:,} IR unit cases pass on this source; '
            f'{scopes["scriptw_ir_integration"]["passed"]:,} IR integration\n'
            'cases retain original source/binary receipts with an unchanged-input proof.\n')
    status = (f'Latest scoped verification (**{date}**, compiler `{fingerprint}`): {engine:,} Engine unit\n'
        f'and {integrations:,} integration cases pass; {emission:,} emission, {structural:,} structural\n'
        f'and {guards:,} source-guard checks pass. AOT units pass {aot:,} cases; four known\n'
        'bootstrap assertions remain failures. ' + ir_status +
        f'All {calls:,} focused calls, {width["checked_invocations"]:,} width-control calls\n'
        f'and {rsc_calls:,} exact RSC checks pass.\n'
        'These scopes do not replace the published full Test262 run. Full workspace CI\n'
        'was not rerun; eleven formatting failures and fourteen stale Intl recipes\n'
        'remain [owned](docs/rust-rewrite/current-inventory.md).\n\n')
    readme = (ROOT / 'README.md').read_text()
    summary = (f'**React 19.3.1 RSC · {date}**, compiler `{fingerprint}`: exact Flight output.\n\n'
        '| Retained request | Scriptw Fast | Node 24 / V8 |\n| --- | ---: | ---: |\n'
        f'| Sync | {score(rsc,"candidate","rsc-sync"):.2f} ms | {score(rsc,"v8","rsc-sync"):.3f} ms |\n'
        f'| Async | {score(rsc,"candidate","rsc-async"):.2f} ms | {score(rsc,"v8","rsc-async"):.3f} ms |\n\n'
        '![Retained RSC requests](docs/rust-rewrite/assets/rsc-current/runtime.svg)\n\n'
        'Eight fresh processes per engine; three checked warmups and seven measured\n'
        'requests per mode. Full Flight serialization and consumption are timed;\n'
        'compilation, initialization and final validation are outside request timing.\n'
        '32-row catalog; async adds a resolved Promise, with no I/O.\n\n'
        f'**Focused performance situations · {date}:** 21 checked programs compare\n'
        'lookup, calls, arguments, properties, type tests, equality and enumeration\n'
        'against V8. A separate fixed-yield width panel checks 8–256 own keys.\n'
        'Eight fresh processes per configuration; 100 checked warmups and 21 samples.\n\n'
        '[Scores, width panel and caveats](docs/rust-rewrite/benchmarks.md#focused-performance-situations) ·\n'
        '[RSC data](docs/rust-rewrite/rsc-current.json) · [Situation data](docs/rust-rewrite/situations-current.json).\n\n')
    readme = replace_between(readme, '**React 19.3.1 RSC ·', '## Current Status', summary)
    readme = replace_between(readme, 'Latest scoped verification', '## Caveats', status)
    details = (ROOT / 'docs/rust-rewrite/benchmarks.md').read_text()
    rsc_head = (f'Measured **{date}**, React **19.3.1**, compiler `{fingerprint}`.\n'
        'Both sync and async Flight outputs match Node exactly.\n'
        '32-row catalog; async adds a resolved Promise, with no I/O.\n\n'
        '| Engine | Sync · ms | Async · ms |\n| --- | ---: | ---: |\n'
        f'| Scriptw Fast | {score(rsc,"candidate","rsc-sync"):.3f} | {score(rsc,"candidate","rsc-async"):.3f} |\n'
        f'| Node 24 / V8 | {score(rsc,"v8","rsc-sync"):.3f} | {score(rsc,"v8","rsc-async"):.3f} |\n\n')
    details = replace_between(details, 'Measured **2026-11-05**, React', '![Retained RSC request timings]', rsc_head)
    cold = (f'Cold Scriptw setup is **{phases["source_to_wasm"]/1e9:.3f} s JavaScript → Wasm**,\n'
        f'**{phases["native_preparation"]/1e9:.3f} s native preparation**, and\n'
        f'**{phases["module_initialization"]/1e6:.3f} ms module initialization**.\n'
        'All setup precedes request timing. The linked size/allocation/PMU diagnostics\n'
        'retain their original earlier build identities; their counts were not refreshed.\n'
        'Child peak RSS includes compilation and process history; it is not live guest heap.\n\n')
    details = replace_between(details, 'Cold Scriptw setup is', '![RSC cold compilation phases]', cold)
    details = details.replace('The RSC program/runtime bytes are unchanged by these admissions;\nV8 parity remains open.',
        'The current RSC source, program and runtime identities are recorded separately;\nV8 parity remains open.')
    details = details.replace('Runtime ABI 51 supplies bounded UTF-8 codecs',
        'Runtime ABI 52 retains private hashed String Set storage for for-in cursors.\nThe runtime supplies bounded UTF-8 codecs')
    details = details.replace('A separate **one-process, unscored** Speed/Backtracking', 'A recorded prior **one-process, unscored** Speed/Backtracking')
    details = details.replace('No fresh allocation census was run for the caller-thread cohort.',
        'No fresh allocation census was run for the current cohort.')
    details = re.sub(r'situations-evidence-2026-11-05-calls\.tar\.xz', archive, details)
    start = 'Measured **2026-11-05**: **21** standalone Module programs'
    end = 'Each value is the median of eight fresh-process medians'
    table = (f'Measured **{date}**: **21** standalone Module programs, compiler `{fingerprint}`.\n'
        'Node and Rust versions retain their exact identities in the report.\n'
        'Each program has its own score; no aggregate combines arbitrary operation counts.\n\n'
        '| Program · retained call | Scriptw Fast · ms | Scriptw Speed · ms | V8 · ms |\n'
        '| --- | ---: | ---: | ---: |\n')
    for case in situations['cases']:
        values = [case['runtimes'][actor]['median_ns'] / 1e6 for actor in ('scriptw-fast','scriptw-speed','v8')]
        table += f'| `{case["file"]}` | ' + ' | '.join(f'{value:.6g}' for value in values) + ' |\n'
    details = replace_between(details, start, end, table + '\n')
    enumeration = ('Sixteen for-in loops visit 64 own enumerable properties, checking 1,024\n'
        'yielded keys and numeric value reads. Private hashed String Set storage removes\n'
        'visited-prefix copying. Live descriptor checks, nonenumerable shadowing,\n'
        'deleted-key prototype behavior, Proxy ordering and suspended cursors retain\n'
        'the compiled Wasm object model. Hash collisions still require exact String equality.\n\n'
        '![For-in enumeration](assets/situations-current/enumeration.svg)\n\n'
        'The separate **unscored width diagnostic** fixes 1,024 yields per call over\n'
        'null-prototype records: counting keys and summing values are separate programs.\n'
        'Preparation uses fixed-length String keys and stays outside timing.\n'
        'Bars and this table show the current compiler and V8; the balanced five-actor\n'
        'control retains both compiler images with their original identities.\n\n'
        '| Own keys | Body | Scriptw Fast · ms | Scriptw Speed · ms | V8 · ms |\n'
        '| ---: | --- | ---: | ---: | ---: |\n')
    if situations['publication']['measured_source']['manifest'].get('followup_admission'):
        enumeration = enumeration.replace('Hash collisions still require exact String equality.',
            'Ordinary scalar reads observe existence and enumerability without a full\n'
            'descriptor clone; other descriptor-query paths retain their own work.\n'
            'Hash collisions still require exact String equality.')
    for name in WIDTH_CASES:
        if name == 'for-in-wide.js':
            continue
        _, _, kind, width_value = name.removesuffix('.js').split('-')
        values = [width['summary'][name][actor]['median_ns']/1e6 for actor in ('candidate-fast','candidate-speed','v8')]
        enumeration += f'| {width_value} | {kind} | ' + ' | '.join(f'{value:.6g}' for value in values) + ' |\n'
    enumeration += ('\n![For-in width](assets/situations-current/enumeration-width.svg)\n\n'
        f'All {len(width["rows"]):,} balanced width processes and {width["checked_invocations"]:,} calls\n'
        'pass exact checks. [Width data and paired image receipts](for-in-width-current.json).\n'
        'This diagnostic does not isolate OwnKeys, hashing, property reads or GC costs.\n\n')
    details = replace_between(details, 'Sixteen for-in loops visit all 64 own enumerable properties',
        '### Public-call control and verification', enumeration)
    verification = ('All **' + f'{coverage["fresh_execution_processes"]:,}' + '** situation processes and **'
        + f'{calls:,}' + '** calls pass exact checks. The balanced RSC campaign adds '
        + f'{coverage["rsc_fresh_processes"]:,} processes and {rsc_calls:,} exact Flight checks.\n'
        + 'The separate width control is documented above. Prior arguments/frame controls\n'
        + 'remain in their original archive; they were not relabeled current.\n\n'
        + status.replace('docs/rust-rewrite/current-inventory.md','current-inventory.md'))
    details = replace_between(details, 'All **504** situation processes', '[Generate/run a hill]', verification)
    # Existing native-size statement belongs to the earlier source; keep it explicitly historical.
    details = details.replace('The 512-site native P image is **5.43 MiB Fast /',
        'The recorded prior 512-site native P image is **5.43 MiB Fast /')
    inventory = (ROOT / 'docs/rust-rewrite/current-inventory.md').read_text()
    inventory = replace_between(inventory, '- Remove quadratic for-in visited-key scans and prefix copying.',
        '- Reduce duplicate descriptor snapshots',
        '- Attribute remaining for-in OwnKeys, descriptor and value-read costs with\n'
        '  fixed-yield width controls after private hashed visited-key storage. Preserve\n'
        '  live descriptors, deleted-key prototype behavior, nonenumerable shadowing,\n'
        '  Proxy ordering and suspended cursors. Owner: AOT enumeration and collections.\n')
    output = args.output.resolve()
    assert output.is_relative_to(ROOT / 'target') and not output.exists()
    output.mkdir(parents=True)
    docs = {'README.md': readme, 'docs/rust-rewrite/benchmarks.md': details,
        'docs/rust-rewrite/current-inventory.md': inventory}
    for relative, text in docs.items():
        destination = output / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_text(text)
    save(output / 'docs-ready.json', dict(complete=True, canonical_files_written=False,
        publication_ready_sha256=sha(stage/'publication-ready.json'),
        files={relative: sha(output/relative) for relative in docs},
        limits='Review staged prose and render the optional width chart. Historical diagnostic identities and pinned Test262 remain unchanged.'))
    print(output)


if __name__ == '__main__':
    main()
