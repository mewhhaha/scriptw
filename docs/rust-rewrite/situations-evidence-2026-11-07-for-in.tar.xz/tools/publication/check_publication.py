"""Verify a staged or copied publication and checkpoint preservation; read only."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess
import tarfile
from common import BASE_GIT, ROOT, git, read, sha
from run_broad import ALL_TARGETS, IR
PRIVATE_LOCAL_FILES = {'cleanup-1.json', 'disk-space-audit-20261107.json'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--stage', type=Path, required=True)
    parser.add_argument('--canonical', action='store_true', help='verify root copied reports/archive and rendered charts')
    args = parser.parse_args()
    ready = read(args.stage / 'publication-ready.json')
    assert ready['complete'] and ready['canonical_files_written'] is False
    directory = args.stage
    metadata = ready['staged_archive']
    if args.canonical:
        directory = ROOT / 'docs/rust-rewrite'
        metadata = ready['evidence_archive']
    archive_path = ROOT / metadata['file']
    assert sha(archive_path) == metadata['sha256'] and archive_path.stat().st_size == metadata['bytes']
    with tarfile.open(archive_path, 'r:xz') as packed:
        index_bytes = packed.extractfile('INDEX.json').read()
        assert packed.extractfile('INDEX.json.sha256').read().decode().strip() == hashlib.sha256(index_bytes).hexdigest() + '  INDEX.json'
        index = json.loads(index_bytes)
        members = packed.getmembers()
        assert not any(Path(row['path']).name in PRIVATE_LOCAL_FILES for row in index['members']), 'private local file in archive index'
        assert len(members) == len(index['members']) + 2
        assert {member.name for member in members} == {row['path'] for row in index['members']} | {'INDEX.json', 'INDEX.json.sha256'}
        assert all(member.isfile() and member.mode == 0o644 for member in members)
        for row in index['members']:
            value = packed.extractfile(row['path']).read()
            assert hashlib.sha256(value).hexdigest() == row['sha256'] and len(value) == row['bytes']
            assert b'\0' not in value
            value.decode('utf-8', errors='strict')
        for name in ready['reports']:
            public = read(directory / name)
            assert public.pop('evidence_archive') == ready['evidence_archive']
            assert public == json.loads(packed.extractfile('reports/' + name).read())
            if args.canonical:
                assert (directory / name).read_bytes() == (args.stage / name).read_bytes()
        situations = json.loads(packed.extractfile('reports/situations-current.json').read())
        publication = situations['publication']
        coverage = publication['coverage']
        qualified = coverage.get('qualified_unchanged_native', [])
        scopes = coverage['fresh_native'] + qualified
        assert len(scopes) == len(ALL_TARGETS) == 15 and {row['target'] for row in scopes} == set(ALL_TARGETS)
        assert coverage['reused_native'] == []
        current_sha = publication['measured_source']['manifest_sha256']
        assert all(row['source_manifest_sha256'] == current_sha for row in coverage['fresh_native'])
        for row in qualified:
            assert row['target'] == 'scriptw_ir_integration' and row['source_manifest_sha256'] != current_sha
            assert row['qualified_final_source_manifest_sha256'] == current_sha
        if qualified:
            reference = coverage['ir_unchanged_input_qualification']
            value = packed.extractfile(reference['archive_path']).read()
            assert hashlib.sha256(value).hexdigest() == reference['sha256']
            proof = json.loads(value)
            assert proof['complete'] and proof['parent_source']['sha256'] == qualified[0]['source_manifest_sha256']
            assert proof['current_source']['sha256'] == current_sha
        assert coverage['fresh_ir_passed'] == sum(row['outcomes']['passed'] for row in coverage['fresh_native'] if row['target'] in IR)
        assert coverage.get('qualified_ir_passed', 0) == sum(row['outcomes']['passed'] for row in qualified if row['target'] in IR)
        for ancestor in publication['source_history']:
            assert hashlib.sha256(packed.extractfile(ancestor['archive_path']).read()).hexdigest() == ancestor['manifest_sha256']
        binding = json.loads(packed.extractfile('baseline/binding.json').read())
        old_archive = binding['evidence_archive']
        original = git('show', BASE_GIT + ':' + old_archive['file'])
        assert (ROOT / old_archive['file']).read_bytes() == original
        assert hashlib.sha256(original).hexdigest() == old_archive['sha256']
    before = git('show', BASE_GIT + ':README.md')
    after = (ROOT / 'README.md').read_bytes()
    for marker in ('runtime-comparison', 'application-benchmarks', 'scriptw-status', 'scriptw-test-graph'):
        pattern = re.compile(rb'<!-- ' + marker.encode() + rb':start -->.*?<!-- ' + marker.encode() + rb':end -->', re.S)
        assert pattern.search(after).group() == pattern.search(before).group(), marker
    for relative in ('docs/rust-rewrite/test262-current.md', 'docs/rust-rewrite/assets/test262-status.svg'):
        assert (ROOT / relative).read_bytes() == git('show', BASE_GIT + ':' + relative)
    folders = ('docs/rust-rewrite/assets/situations-current', 'docs/rust-rewrite/assets/rsc-current')
    old_paths = set(git('ls-tree', '-r', '--name-only', BASE_GIT, '--', *folders).decode().splitlines())
    expected = {path for path in old_paths if path.endswith('.svg')}
    actual = {path.relative_to(ROOT).as_posix() for folder in folders for path in (ROOT / folder).glob('*.svg')}
    if args.canonical:
        expected.add('docs/rust-rewrite/assets/situations-current/enumeration-width.svg')
    assert actual == expected
    if args.canonical:
        for name in ('react-allocation-current.json', 'react-attribution-current.json', 'rsc-wasm-size-current.json'):
            if name not in ready['reports'] and not (args.stage / name).exists():
                assert (directory / name).read_bytes() == git('show', BASE_GIT + ':docs/rust-rewrite/' + name), 'historical diagnostic was modified without fresh current evidence'
    print(json.dumps(dict(complete=True, canonical=args.canonical, archive_sha256=metadata['sha256'],
        inert_members=len(index['members']) + 2, reports=ready['reports'], published_chart_paths=len(expected),
        preserved_readme_blocks=4, pinned_test262_unchanged=True)))


if __name__ == '__main__':
    main()
