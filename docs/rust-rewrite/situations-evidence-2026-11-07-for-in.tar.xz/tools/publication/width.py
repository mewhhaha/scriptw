"""Check the existing balanced width pilot against its actual pinned plan and logs."""
import importlib.util
from pathlib import Path
import statistics
import sys
from common import BASE, ROOT, read, sha

WIDTH_CASES = ['for-in-wide.js']
for width in (8, 32, 64, 256):
    for kind in ('count', 'value'):
        WIDTH_CASES.append(f'for-in-{kind}-{width}.js')
ACTORS = ('baseline-fast', 'candidate-fast', 'baseline-speed', 'candidate-speed', 'v8')


def validate_width(path, source_sha, candidate_report=None, baseline_report=None):
    path = Path(path).resolve(strict=True)
    paired = read(path)
    assert paired['complete']
    policy = paired['policy']
    assert policy['warmups'] == 100 and policy['samples'] == 21
    assert policy['blocks'] == 2 and policy['processes_per_actor_per_block'] == 4
    pins = {pin['name']: pin for pin in paired['sources']}
    assert set(pins) == {'baseline', 'candidate'} and len(paired['sources']) == 2
    reports = {}
    for name, pin in pins.items():
        report_path = Path(pin['report']).resolve(strict=True)
        assert sha(report_path) == pin['report_sha256']
        report = read(report_path)
        assert report['complete'] and report['status'] == 'complete'
        assert [row['file'] for row in report['workloads']] == WIDTH_CASES
        assert report['tools']['host']['identity'] == pin['identity']
        assert report['source_identity']['executable_sha256'] == pin['host_sha256']
        producer_ref = report['tools']['host']['frozen_producer_receipt']
        producer_path = report_path.parent / producer_ref['path']
        assert sha(producer_path) == producer_ref['sha256']
        producer = read(producer_path)
        assert producer['sha256'] == pin['host_sha256']
        if name == 'candidate':
            assert producer['source_manifest_sha256'] == source_sha
            if candidate_report is not None:
                assert report_path == Path(candidate_report).resolve(strict=True)
        else:
            if baseline_report is None:
                assert pin['report_sha256'] == read(BASE / 'trial-admission.json')['baseline_width']['sha256']
            else:
                assert report_path == Path(baseline_report).resolve(strict=True)
        reports[name] = report
    cases = reports['candidate']['workloads']
    assert cases == reports['baseline']['workloads']
    driver_path = ROOT / 'scripts/benchmark-situations.py'
    sys.path.insert(0, str(ROOT / 'scripts'))
    spec = importlib.util.spec_from_file_location('width_situations_validation', driver_path)
    driver = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(driver)
    plan = list(driver.measurement_plan(cases, ACTORS))
    assert paired['plan'] == plan and len(paired['rows']) == len(plan)
    assert paired['checked_invocations'] == len(plan) * (policy['warmups'] + policy['samples'])
    summary = {case['file']: {} for case in cases}
    for expected, row in zip(plan, paired['rows']):
        assert all(row[key] == value for key, value in expected.items())
        assert row['accounting']['exit_code'] == 0 and not row['accounting']['timed_out']
        stdout = (path.parent / row['stdout']).resolve(strict=True)
        assert stdout.is_relative_to(path.parent) and sha(stdout) == row['stdout_sha256']
        stderr = stdout.with_suffix('.stderr')
        assert sha(stderr) == row['stderr_sha256'] and stderr.stat().st_size == 0
        actor, native_actor, cohort, producer = row['actor'], 'v8', 'candidate', None
        if actor != 'v8':
            cohort, native_policy = actor.split('-', 1)
            native_actor = 'scriptw-' + native_policy
            producer = next(item for item in pins[cohort]['preparations'][native_policy] if item['file'] == row['file'])
        case = next(case for case in cases if case['file'] == row['file'])
        samples = driver.validate_execution(read(stdout), case, native_actor, case['source_sha256'],
            reports[cohort]['tools']['host']['identity'], producer)
        assert samples == row['samples_ns'] and row['median_ns'] == statistics.median(samples)
    for case in cases:
        for actor in ACTORS:
            rows = [row for row in paired['rows'] if row['file'] == case['file'] and row['actor'] == actor]
            assert len(rows) == policy['blocks'] * policy['processes_per_actor_per_block']
            summary[case['file']][actor] = dict(median_ns=statistics.median(row['median_ns'] for row in rows),
                block_medians_ns=[statistics.median(row['median_ns'] for row in rows if row['block'] == block) for block in range(policy['blocks'])])
    assert paired['summary'] == summary
    return paired
