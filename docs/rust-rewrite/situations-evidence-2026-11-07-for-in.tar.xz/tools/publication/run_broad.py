"""Run fresh IR, AOT, emission, structural and Engine scopes after pilot retention."""
import argparse
import copy
import collections
import json
from datetime import datetime, timezone
from pathlib import Path
import re
import shutil
import shlex
import subprocess
import time
from common import ROOT, artifacts, check_source, read, save, sha

IR = ('scriptw_ir', 'scriptw_ir_integration')
STRUCTURAL = ('structure_language', 'modules_realms', 'runtime_link', 'structure_builtins', 'structure_async', 'intl_temporal')
ENGINE = ('aot_language', 'aot_builtins', 'aot_async', 'aot_realm_modules')
ALL_TARGETS = (*IR, 'scriptw_aot_wasm', 'emission', *STRUCTURAL, 'scriptw_engine', *ENGINE)
SUMMARY = re.compile(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;')


def failures(text):
    if '\nfailures:\n' not in text:
        return set()
    tail = text.rsplit('\nfailures:\n', 1)[1].split('\ntest result:', 1)[0]
    return set(re.findall(r'^    (\S+)\s*$', tail, re.M))


def validate_ir_qualification(record, final_source_sha):
    """Only the excluded 996→997 IR test assertion can qualify an older integration."""
    target = record.get('target')
    if 'artifact' in record:
        target = record['artifact']['target']['name']
    assert target == 'scriptw_ir_integration', 'only this IR integration scope may retain an older source'
    assert record['qualified_final_source_manifest_sha256'] == final_source_sha
    reference = record['qualification']
    assert sha(reference['path']) == reference['sha256']
    proof = read(reference['path'])
    assert proof['schema'] == 'scriptw-ir-test-only-correction-v1' and proof['complete']
    assert proof['parent_source']['sha256'] == record['source_manifest_sha256']
    assert proof['current_source']['sha256'] == final_source_sha
    for field in ('parent_source', 'current_source', 'original_integration', 'original_probe', 'selected_patch', 'cfg_test_owner'):
        assert sha(proof[field]['path']) == proof[field]['sha256'], field
    before_path, after_path = Path(proof['parent_source']['path']), Path(proof['current_source']['path'])
    before_manifest, after_manifest = read(before_path), read(after_path)
    selected = 'crates/scriptw-ir/src/lowering/builtin_catalog/tests.rs'
    assert proof['selected_path'] == selected
    assert set(before_manifest['files']) == set(after_manifest['files'])
    assert before_manifest['deleted_files'] == after_manifest['deleted_files']
    assert {path for path in before_manifest['files'] if before_manifest['files'][path] != after_manifest['files'][path]} == {selected}
    before = (before_path.parent / 'files' / selected).read_bytes()
    after = (after_path.parent / 'files' / selected).read_bytes()
    import hashlib
    assert hashlib.sha256(before).hexdigest() == proof['before_sha256'] == before_manifest['files'][selected]
    assert hashlib.sha256(after).hexdigest() == proof['after_sha256'] == after_manifest['files'][selected]
    old = b'assert_eq!(function_signature_baseline().len(), 996);'
    new = b'assert_eq!(function_signature_baseline().len(), 997);'
    assert before.count(old) == 1 and after == before.replace(old, new)
    owner = Path(proof['cfg_test_owner']['path']).resolve(strict=True)
    assert owner == ROOT / 'crates/scriptw-ir/src/lowering/builtin_catalog.rs'
    assert '#[cfg(test)]\nmod tests;' in owner.read_text()
    assert not (ROOT / 'crates/scriptw-ir/build.rs').exists()
    assert {item['role'] for item in proof['dependency_inventories']} == {'ordinary-ir', 'ir-integration'}
    for inventory in proof['dependency_inventories']:
        depfile = Path(inventory['archived_depfile'])
        assert sha(depfile) == inventory['sha256']
        actual = sorted({str((ROOT / name).resolve(strict=True)) for name in shlex.split(depfile.read_text().splitlines()[0].split(': ', 1)[1])})
        assert actual == sorted(item['path'] for item in inventory['inputs'])
        assert str(ROOT / selected) not in actual
        for item in inventory['inputs']:
            assert sha(item['path']) == item['sha256']
    for item in proof['configuration_inputs']:
        assert sha(item['path']) == item['sha256']
    rustc = proof['rustc_identity']
    assert sha(rustc['stdout']) == rustc['stdout_sha256']
    stderr = Path(rustc['stdout']).with_name('rustc.stderr')
    assert sha(stderr) == rustc['stderr_sha256']
    cargo = proof['cargo_confirmation']
    assert cargo['ordinary_features_match'] and cargo['normal_ir_fresh'] and cargo['integration_fresh']
    assert cargo['normal_ir_sha256_before'] == cargo['normal_ir_sha256_after']
    assert cargo['integration_sha256_before'] == cargo['integration_sha256_after']
    for field in ('stdout', 'baseline_cargo_stdout'):
        assert sha(cargo[field]['path']) == cargo[field]['sha256']
    def cargo_rows(path):
        rows = [json.loads(line) for line in Path(path).read_text().splitlines() if line]
        assert [item['success'] for item in rows if item.get('reason') == 'build-finished'] == [True]
        return [item for item in rows if item.get('reason') == 'compiler-artifact']
    current_rows = cargo_rows(cargo['stdout']['path'])
    prior_rows = cargo_rows(cargo['baseline_cargo_stdout']['path'])
    def features(rows):
        return collections.Counter(json.dumps(dict(package=item['package_id'], target=item['target'], profile=item['profile'], features=item['features']), sort_keys=True)
            for item in rows if not item['profile']['test'])
    assert features(current_rows) == features(prior_rows)
    for field in ('normal_ir_artifact', 'integration_artifact', 'rebuilt_unit_artifact'):
        assert cargo[field] in current_rows
    assert cargo['normal_ir_artifact']['fresh'] is True and cargo['integration_artifact']['fresh'] is True
    assert cargo['rebuilt_unit_artifact']['fresh'] is False
    current_version = Path(cargo['stdout']['path']).parent / 'rustc-version.stdout'
    assert current_version.read_bytes() == Path(rustc['stdout']).read_bytes()
    original = read(proof['original_integration']['path'])
    assert original['schema'] == 'scriptw-ir-integration-complete-v1' and original['complete'] and original['passed']
    assert original['source_manifest_sha256'] == record['source_manifest_sha256']
    assert cargo['integration_sha256_before'] == original['artifact']['sha256']
    probe = read(proof['original_probe']['path'])
    assert probe['schema'] == 'scriptw-ir-normal-library-probe-v1' and probe['complete']
    assert probe['source_manifest_sha256'] == record['source_manifest_sha256']
    assert cargo['normal_ir_sha256_before'] == probe['ir_rlib_sha256']
    if 'artifact' in record:
        assert record['artifact'] == original['artifact']['artifact']
        assert record.get('sha256', record.get('executable_sha256')) == original['artifact']['sha256']
    else:
        assert all(record[key] == value for key, value in original['scope'].items())
    return proof


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--focused-producer', type=Path, required=True)
    parser.add_argument('--ir-foundation', type=Path, help='completed final-source foundation; preserves original scope identities and any explicit relevant-input qualification')
    parser.add_argument('--pilot', type=Path, required=True, help='completed RSC aggregate.json')
    parser.add_argument('--width-baseline-report', type=Path, help='explicit original raw baseline for a later scalar52 control; default is admitted ABI51')
    parser.add_argument('--width-pilot', type=Path, required=True, help='completed balanced paired-width report.json')
    parser.add_argument('--pilot-retained', action='store_true', required=True, help='root retained the measured prototype')
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--target', action='append', default=[], help='explicit remaining target subset after a preserved failure')
    args = parser.parse_args()
    source = args.source.resolve(strict=True)
    source_sha = sha(source)
    check_source(source)
    pilot = read(args.pilot)
    assert pilot['source_identity']['candidate_measured_source']['manifest_sha256'] == source_sha
    from width import validate_width
    validate_width(args.width_pilot, source_sha=source_sha, baseline_report=args.width_baseline_report)
    campaign = ROOT / pilot['measurement']['campaign']
    assert sha(campaign) == pilot['measurement']['campaign_sha256']
    assert read(campaign)['status'] == 'complete'
    focused = read(args.focused_producer)
    assert focused['complete'] and focused['source_manifest_sha256'] == source_sha
    assert focused['phase'] == 'focused-build'
    inherited = {row['artifact']['target']['name']: row for row in focused['artifacts']}
    foundation = None
    if args.ir_foundation:
        foundation = read(args.ir_foundation)
        assert foundation['schema'] == 'scriptw-ir-foundation-v1' and foundation['complete']
        assert foundation['source_manifest_sha256'] == source_sha
        for row in foundation['artifacts']:
            name = row['artifact']['target']['name']
            assert name in IR and row['artifact']['profile']['test'] is True
            if row['source_manifest_sha256'] != source_sha:
                validate_ir_qualification(row, source_sha)
            assert sha(row['frozen_path']) == row['sha256']
            assert sha(row['cargo_stdout']) == row['cargo_stdout_sha256']
            assert name not in inherited
            inherited[name] = row
        assert all(name in inherited for name in IR)
    current_sha = source_sha
    assert {'emission', 'aot_language'} <= inherited.keys()
    import json
    from common import BASE_GIT, git
    prior = json.loads(git('show', BASE_GIT + ':docs/rust-rewrite/situations-current.json'))['publication']['coverage']
    known_rows = [row for row in prior['fresh_native'] + prior.get('reused_native', []) if row['target'] == 'scriptw_aot_wasm']
    assert len(known_rows) == 1
    known = known_rows[0]
    assert len(known['failures']) == known['outcomes']['failed'] == 4
    output = args.output.resolve()
    assert output.is_relative_to(ROOT / 'target') and not output.exists()
    output.mkdir(parents=True)
    (output / 'frozen').mkdir()
    all_targets = ALL_TARGETS
    targets = list(all_targets)
    if args.target:
        assert set(args.target) <= set(all_targets) and len(set(args.target)) == len(args.target)
        targets = [target for target in all_targets if target in args.target]
    report = dict(schema='scriptw-for-in-native-v3', complete=False,
        source_manifest_sha256=source_sha, scopes=[], producer_commands=[], artifacts=[], inventories={},
        selected_targets=targets, full_native_target_set_complete=False,
        pilot=dict(path=str(args.pilot.resolve()), sha256=sha(args.pilot), root_retained=True),
        width_pilot=dict(path=str(args.width_pilot.resolve()), sha256=sha(args.width_pilot), root_retained=True),
        inherited_producer=dict(path=str(args.focused_producer.resolve()), sha256=sha(args.focused_producer)),
        reused_native=[],
        known_preexisting_aot_failures=dict(names=known['failures'], original_scope=known),
        limits='Fresh Engine counts come from actual binary inventories. Focused cases overlap full Engine suites. IR unit, AOT and Engine binaries bind the final source. Only an explicitly qualified unchanged-input IR integration scope may retain its original source/binary identity. Fresh AOT must retain the exact four prior failure names. Pinned Test262 was not rerun.',
        started_at=datetime.now(timezone.utc).isoformat())

    if args.width_baseline_report:
        report['width_baseline'] = dict(path=str(args.width_baseline_report.resolve()), sha256=sha(args.width_baseline_report))

    if foundation:
        report['ir_foundation'] = dict(path=str(args.ir_foundation.resolve()), sha256=sha(args.ir_foundation))

    def persist():
        save(output / 'native-verification.json', report)

    def run(label, argv, target=None, expected=None):
        check_source(source)
        capped = ['python3', '-B', str(ROOT / 'scripts/limited_verification.py'), '--', *map(str, argv)]
        out, err = output / (label + '.stdout'), output / (label + '.stderr')
        print('START', label, flush=True)
        start = time.monotonic_ns()
        timed_out = False
        with out.open('xb') as stdout, err.open('xb') as stderr:
            try:
                child = subprocess.run(capped, cwd=ROOT, stdout=stdout, stderr=stderr, timeout=7200)
                code = child.returncode
            except subprocess.TimeoutExpired:
                timed_out, code = True, None
        row = dict(label=label, argv=list(map(str, argv)), capped_argv=capped, exit_code=code, timed_out=timed_out,
            elapsed_ns=time.monotonic_ns() - start, source_manifest_sha256=current_sha,
            stdout=str(out), stderr=str(err), stdout_sha256=sha(out), stderr_sha256=sha(err))
        if target:
            package = 'scriptw-aot-wasm'
            if target in ENGINE or target == 'scriptw_engine':
                package = 'scriptw-engine'
            elif target in IR:
                package = 'scriptw-ir'
            row.update(package=package, target=target, executable_sha256=sha(argv[0]))
            report['scopes'].append(row)
            persist()
            summary = SUMMARY.findall(out.read_text())
            assert len(summary) == 1, 'missing/ambiguous test result: ' + target
            state, passed, failed, ignored = summary[0]
            row['outcomes'] = dict(state=state, passed=int(passed), failed=int(failed), ignored=int(ignored))
            persist()
            assert int(passed) + int(failed) == expected and int(ignored) == 0
            if target == 'scriptw_aot_wasm':
                row['failures'] = sorted(failures(out.read_text()))
                persist()
                assert state == 'FAILED' and code == 101 and int(failed) == 4
                assert set(row['failures']) == set(known['failures'])
            else:
                assert code == 0 and state == 'ok' and int(failed) == 0
        else:
            report['producer_commands'].append(row)
            persist()
            assert code == 0
        assert not timed_out
        check_source(source)
        print('END', label, code, flush=True)
        return out

    def freeze(artifact, original, authority, artifact_source_sha):
        assert artifact['profile']['test'] is True
        binary = Path(original)
        destination = output / 'frozen' / artifact['target']['name']
        expected = sha(binary)
        shutil.copy2(binary, destination)
        assert sha(destination) == sha(binary) == expected
        row = dict(artifact=artifact, frozen_path=str(destination), executable_sha256=expected,
            source_manifest_sha256=artifact_source_sha, authority=authority, bytes=destination.stat().st_size)
        report['artifacts'].append(row)
        persist()
        return destination

    persist()
    binaries = {}
    for target in targets:
        if target in inherited:
            row = inherited[target]
            if row['source_manifest_sha256'] != source_sha:
                validate_ir_qualification(row, source_sha)
            assert sha(row['frozen_path']) == row['sha256']
            authority = dict(inherited_producer_sha256=sha(args.focused_producer))
            if target in IR and foundation:
                authority = dict(ir_foundation_sha256=sha(args.ir_foundation))
            binaries[target] = freeze(row['artifact'], row['frozen_path'], authority, row['source_manifest_sha256'])
            if row['source_manifest_sha256'] != source_sha:
                report['artifacts'][-1].update(qualified_final_source_manifest_sha256=source_sha, qualification=copy.deepcopy(row['qualification']))
                persist()
    missing = set(targets) - set(binaries)
    for package, members, library in (
        ('scriptw-ir', ('scriptw_ir_integration',), 'scriptw_ir'),
        ('scriptw-aot-wasm', ('emission', *STRUCTURAL), 'scriptw_aot_wasm'),
        ('scriptw-engine', ENGINE, 'scriptw_engine'),
    ):
        needed = missing & {library, *members}
        if not needed:
            continue
        argv = ['cargo', 'test', '--release', '--locked', '-p', package, '--no-run']
        if library in needed:
            argv.append('--lib')
        for target in members:
            if target in needed:
                argv.extend(['--test', target])
        argv.append('--message-format=json-render-diagnostics')
        log = run('build-' + package, argv)
        found = {}
        for artifact in artifacts(log):
            target = artifact['target']['name']
            if target in needed and artifact['profile']['test'] is True:
                assert target not in found
                found[target] = freeze(artifact, artifact['executable'], dict(cargo_stdout=str(log), cargo_stdout_sha256=sha(log)), current_sha)
        assert set(found) == needed, ('missing/ambiguous fresh artifacts', needed, set(found))
        binaries.update(found)
    adopted = set()
    if foundation:
        for target in IR:
            if target not in targets:
                continue
            matches = [row for row in foundation['scopes'] if row['target'] == target and row['filter'] == '']
            assert len(matches) == 1
            original = matches[0]
            assert original['exit_code'] == 0 and not original.get('timed_out')
            assert all(not value or value.startswith('-') for value in original['argv'][1:])
            assert sha(original['stdout']) == original['stdout_sha256'] and sha(original['stderr']) == original['stderr_sha256']
            result = SUMMARY.findall(Path(original['stdout']).read_text())
            assert len(result) == 1
            state, passed, failed, ignored = result[0]
            outcomes = dict(state=state, passed=int(passed), failed=int(failed), ignored=int(ignored))
            assert outcomes == original['outcomes'] and state == 'ok' and int(failed) == int(ignored) == 0
            inventories = [row for row in foundation['commands']
                if row['argv'][0] == original['argv'][0] and row['argv'][1:] == ['--list', '--format', 'terse']]
            assert inventories, 'missing actual binary inventory for ' + target
            inventory = inventories[0]
            assert inventory['exit_code'] == 0 and sha(inventory['stdout']) == inventory['stdout_sha256']
            assert sha(inventory['stderr']) == inventory['stderr_sha256']
            names = [line.removesuffix(': test') for line in Path(inventory['stdout']).read_text().splitlines() if line.endswith(': test')]
            assert names and len(names) == len(set(names)) == int(passed)
            assert sha(binaries[target]) == original['executable_sha256']
            report['inventories'][target] = dict(tests=names, count=len(names), executable_sha256=original['executable_sha256'],
                original_inventory=copy.deepcopy(inventory))
            original_source_sha = original.get('source_manifest_sha256', foundation['source_manifest_sha256'])
            if original_source_sha != source_sha:
                validate_ir_qualification(original, source_sha)
            report['scopes'].append(dict(copy.deepcopy(original), package='scriptw-ir', source_manifest_sha256=original_source_sha,
                earlier_foundation_scope=dict(receipt=report['ir_foundation'], original_scope=copy.deepcopy(original))))
            adopted.add(target)
            persist()
    for target in targets:
        if target in adopted:
            continue
        binary = binaries[target]
        current_sha = next(row['source_manifest_sha256'] for row in report['artifacts'] if row['artifact']['target']['name'] == target)
        log = run('inventory-' + target, [binary, '--list', '--format', 'terse'])
        names = [line.removesuffix(': test') for line in log.read_text().splitlines() if line.endswith(': test')]
        assert names and len(set(names)) == len(names)
        report['inventories'][target] = dict(tests=names, count=len(names), executable_sha256=sha(binary))
        persist()
        run(target, [binary, '--test-threads=1'], target=target, expected=len(names))
    report.update(complete=True, full_native_target_set_complete=set(targets) == set(all_targets),
        finished_at=datetime.now(timezone.utc).isoformat())
    persist()
    print('FRESH NATIVE COMPLETE; IR CURRENT AND EXACT FOUR AOT FAILURES RETAINED', output / 'native-verification.json', flush=True)


if __name__ == '__main__':
    main()
