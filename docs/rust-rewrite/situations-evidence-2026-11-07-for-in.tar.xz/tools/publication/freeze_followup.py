"""Freeze an explicit selected-hash source followup; preserve every immutable parent."""
import argparse
from pathlib import Path
import re
from common import BASE, BASE_GIT, ROOT, check_source, git, read, save, sha


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--parent-source', type=Path, required=True, help='exact frozen initial52 or previously admitted followup manifest')
    parser.add_argument('--file', action='append', default=[], metavar='PATH=SHA256', help='repeat exact final hashes from the selected staged followup; no deletion support')
    parser.add_argument('--restore', action='append', default=[], metavar='PATH=BASE_SHA256', help='explicitly restore a modified parent file to canonical base Git bytes; no ABI paths or deletions')
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    parent_path = args.parent_source.resolve(strict=True)
    from common import _authority
    assert hasattr(_authority, 'validate_restoration'), 'apply common-explicit-restore.patch first'
    parent = _authority.check_frozen_source(parent_path)
    assert parent['base_git'] == BASE_GIT
    selected = {}
    for value in args.file:
        relative, separator, expected = value.partition('=')
        path = Path(relative)
        assert separator and re.fullmatch('[0-9a-f]{64}', expected)
        assert not path.is_absolute() and '..' not in path.parts and relative == path.as_posix()
        assert relative not in selected and relative not in parent['deleted_files']
        assert parent['files'].get(relative) != expected, 'selected file is unchanged'
        selected[relative] = expected
    assert git('rev-parse', 'HEAD').decode().strip() == BASE_GIT
    restored = {}
    expected_files = dict(parent['files'], **selected)
    for value in args.restore:
        relative, separator, expected = value.partition('=')
        assert separator and re.fullmatch('[0-9a-f]{64}', expected)
        assert relative not in selected and relative not in restored and relative not in parent['deleted_files']
        assert relative in parent['files'], 'restore must name a modified parent file'
        canonical = git('show', BASE_GIT + ':' + relative)
        witness = dict(base_git=BASE_GIT, base_sha256=expected, parent_sha256=parent['files'][relative])
        del expected_files[relative]
        _authority.validate_restoration(relative, parent['files'], expected_files, BASE_GIT, canonical, witness)
        assert (ROOT / relative).is_file() and (ROOT / relative).read_bytes() == canonical, 'current restore bytes differ from Git'
        restored[relative] = witness
    assert selected or restored, 'select at least one changed or restored file'
    tracked = set(git('diff', '--name-only', '-z', 'HEAD').decode().split('\0')) - {''}
    untracked = set(git('ls-files', '--others', '--exclude-standard', '-z').decode().split('\0')) - {''}
    assert tracked | untracked == set(expected_files) | set(parent['deleted_files']), 'unselected changed file'
    for relative, expected in expected_files.items():
        assert sha(ROOT / relative) == expected, relative
    for relative in parent['deleted_files']:
        assert not (ROOT / relative).exists()
    # ABI52 remains the sole selected object model; a binding-cell ABI followup needs separate admission.
    runtime = 'crates/scriptw-aot-wasm/src/runtime_artifact.rs'
    assert (ROOT / runtime).read_bytes() == (parent_path.parent / 'files' / runtime).read_bytes()
    output = args.output.resolve()
    assert output.is_relative_to(ROOT / 'target') and not output.exists()
    output.mkdir(parents=True)
    admission = dict(schema='scriptw-for-in-set-followup-admission-v1', complete=True,
        initial_admission_sha256=parent['admission_sha256'],
        parent_source=dict(path=str(parent_path), sha256=sha(parent_path)), selected_files=selected, restored_files=restored,
        limits='Exact explicitly selected hashes and canonical Git restore witnesses only. No inherited native correctness or timing claim. All prior source/binary/report identities remain historical; a production IR change requires fresh native scope qualification.')
    save(output / 'followup-admission.json', admission)
    (output / 'tracked.patch').write_bytes(git('diff', '--binary', 'HEAD'))
    files = {}
    for relative, expected in expected_files.items():
        source = ROOT / relative
        assert source.is_file() and not source.is_symlink()
        data = source.read_bytes()
        data.decode('utf8')
        assert b'\0' not in data
        destination = output / 'files' / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(data)
        assert sha(destination) == expected
        files[relative] = expected
    reports = {}
    for name in parent['baseline_public_reports']:
        path = output / 'baseline' / name
        path.parent.mkdir(exist_ok=True)
        path.write_bytes(git('show', BASE_GIT + ':docs/rust-rewrite/' + name))
        reports[name] = dict(path=str(path.relative_to(output)), sha256=sha(path))
    manifest = dict(parent, schema='scriptw-for-in-set-followup-source-v1',
        tracked_patch_sha256=sha(output/'tracked.patch'), files=files,
        tracked_files=sorted(tracked), untracked_files=sorted(untracked), baseline_public_reports=reports,
        followup_admission=dict(path=str(output/'followup-admission.json'), sha256=sha(output/'followup-admission.json')),
        scope='Exact selected source followup on ABI52; all parent source snapshots and receipts remain separate. Fresh compilation/verification/measurement required.')
    save(output / 'manifest.json', manifest)
    check_source(output / 'manifest.json')
    print(output / 'manifest.json', sha(output / 'manifest.json'))


if __name__ == '__main__':
    main()
