"""Use the campaign's admitted authority without changing active helpers."""
import importlib.util
from pathlib import Path
_active = Path(__file__).resolve().parents[1] / 'common.py'
_spec = importlib.util.spec_from_file_location('for_in_active_common', _active)
_authority = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_authority)
for _name in ('BASE', 'ROOT', 'artifacts', 'check_source', 'git', 'read', 'save', 'sha'):
    globals()[_name] = getattr(_authority, _name)
BASE_GIT = _authority.admitted_base()
