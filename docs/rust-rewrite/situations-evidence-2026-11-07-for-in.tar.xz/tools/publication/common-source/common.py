"""Exact source authority for the selected ABI52 trial; old ABI51 stays separate."""
import hashlib,json,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]
BASE=Path(__file__).resolve().parent

def sha(path):
 with Path(path).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def read(path):return json.loads(Path(path).read_text())
def save(path,value):
 path=Path(path);temporary=path.with_name(path.name+'.writing');temporary.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n');temporary.replace(path)
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT)
def admitted_base():return read(BASE/'trial-admission.json')['retained_base_git']
def check_inputs():
 admission=read(BASE/'trial-admission.json');assert admission['complete']
 proof=admission['composition'];assert sha(proof['path'])==proof['sha256'];composition=read(proof['path'])
 assert composition['runtime_abi_before']==51 and composition['runtime_abi_after']==52 and not composition['abi53_binding_cell_applied']
 stage=composition['source_manifest'];assert sha(stage['path'])==stage['sha256'];patch=composition['source_patch'];assert sha(patch['path'])==patch['sha256']
 for row in composition['ordered_dependencies']:assert sha(Path(stage['path']).parent/row['path'])==row['sha256']
 width=BASE.parent/'for-in-width-staged/manifest.json';assert sha(width)==composition['width_manifest_sha256']=='921c0307d3afecabca25d6b127288d6f9ad5b0f11352ef0c202b3b584db15261'
 for relative,row in read(width)['files'].items():assert sha(width.parent/relative)==row['sha256']
 return admission

def validate_restoration(relative,parent_files,child_files,base_git,base_bytes,witness):
 name=Path(relative)
 assert not name.is_absolute() and '..' not in name.parts and relative==name.as_posix()
 assert relative not in ('crates/scriptw-aot-wasm/src/runtime_artifact.rs','crates/scriptw-aot-wasm/src/runtime_abi.rs')
 assert not relative.startswith('crates/scriptw-aot-wasm/src/gc_types/'),'ABI paths cannot be restored through this transition'
 assert relative in parent_files and relative not in child_files,'restore requires an explicit modified parent file removed from the dirty snapshot'
 expected=hashlib.sha256(base_bytes).hexdigest()
 assert witness['base_git']==base_git and witness['base_sha256']==expected,'restore differs from canonical Git bytes'
 assert witness['parent_sha256']==parent_files[relative] and witness['parent_sha256']!=expected,'restore parent was already clean or differs from its witness'
 return expected

def _frozen_source(manifest):
 admission=check_inputs()
 def visit(path,ancestors):
  path=Path(path).resolve(strict=True);assert path not in ancestors,'source admission cycle';ancestors=ancestors|{path}
  data=read(path)
  assert data['base_git']==admitted_base() and data['admission_sha256']==sha(BASE/'trial-admission.json') and data['runtime_abi']==52
  assert sha(path.parent/'tracked.patch')==data['tracked_patch_sha256']
  assert set(data['tracked_files'])|set(data['untracked_files'])==set(data['files'])|set(data['deleted_files'])
  assert not set(data['files'])&set(data['deleted_files'])
  for relative,expected in data['files'].items():
   name=Path(relative);assert not name.is_absolute() and '..' not in name.parts
   assert sha(path.parent/'files'/relative)==expected,relative
  if 'followup_admission' in data:
   assert data['schema']=='scriptw-for-in-set-followup-source-v1'
   bound=data['followup_admission'];assert sha(bound['path'])==bound['sha256'];followup=read(bound['path'])
   assert followup['schema']=='scriptw-for-in-set-followup-admission-v1' and followup['complete']
   assert followup['initial_admission_sha256']==data['admission_sha256']
   parent_ref=followup['parent_source'];assert sha(parent_ref['path'])==parent_ref['sha256']
   parent,expected_files,restored_files=visit(parent_ref['path'],ancestors)
   assert parent['base_git']==data['base_git'] and parent['admission_sha256']==data['admission_sha256']
   runtime='crates/scriptw-aot-wasm/src/runtime_artifact.rs';assert data['files'][runtime]==parent['files'][runtime]
   selected=followup['selected_files'];restored=followup.get('restored_files',{});assert selected or restored
   assert not set(selected)&set(restored),'selected and restored paths must be disjoint'
   changed={relative for relative in set(parent['files'])|set(data['files']) if parent['files'].get(relative)!=data['files'].get(relative)}
   assert changed==set(selected)|set(restored),'followup changes differ from explicit selected/restored hashes'
   for relative,witness in restored.items():
    expected=validate_restoration(relative,parent['files'],data['files'],data['base_git'],git('show',data['base_git']+':'+relative),witness)
    assert relative not in data['deleted_files'],'restore cannot be a physical deletion'
    expected_files.pop(relative,None);restored_files[relative]=expected
   for relative,expected in selected.items():assert data['files'][relative]==expected,relative
   assert data['deleted_files']==parent['deleted_files'],'followup deletion requires separate review'
   expected_files.update(selected)
   for relative in selected:restored_files.pop(relative,None)
  else:
   assert data['schema']=='scriptw-for-in-set-trial-source-v1'
   expected_files=dict(admission['final_file_hashes']);restored_files={}
  for relative,expected in expected_files.items():
   if expected is None:assert relative in data['deleted_files']
   else:assert data['files'][relative]==expected,relative
  return data,expected_files,restored_files
 return visit(manifest,set())

def check_frozen_source(manifest):
 return _frozen_source(manifest)[0]

def check_source(manifest):
 manifest=Path(manifest).resolve(strict=True);data,_,restored_files=_frozen_source(manifest)
 assert git('rev-parse','HEAD').decode().strip()==data['base_git']==admitted_base()
 assert git('diff','--binary','HEAD')==(manifest.parent/'tracked.patch').read_bytes()
 assert set(git('ls-files','--others','--exclude-standard','-z').decode().split('\0'))-{''}==set(data['untracked_files'])
 for relative,expected in data['files'].items():assert sha(ROOT/relative)==expected,relative
 for relative in data['deleted_files']:assert not (ROOT/relative).exists()
 for relative,expected in restored_files.items():assert (ROOT/relative).is_file() and sha(ROOT/relative)==expected,relative
 return data

def artifacts(log):
 rows=[json.loads(line) for line in Path(log).read_text().splitlines() if line];finished=[row for row in rows if row.get('reason')=='build-finished']
 assert len(finished)==1 and finished[0]['success'],'Cargo producer did not complete'
 return [row for row in rows if row.get('reason')=='compiler-artifact' and row.get('executable')]
