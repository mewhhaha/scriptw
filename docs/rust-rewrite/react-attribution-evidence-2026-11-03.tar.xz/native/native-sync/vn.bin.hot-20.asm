
/home/jacobt/src/scriptw/target/react-native-attribution-20261103/native-sync/vn.bin:     file format binary


Disassembly of section .data:

00000000001874cd <.data+0x1874cd>:
  1874cd:	4c 8b 84 24 b0 74 0a 	mov    0xa74b0(%rsp),%r8
  1874d4:	00 
  1874d5:	4c 89 84 24 78 6d 0a 	mov    %r8,0xa6d78(%rsp)
  1874dc:	00 
  1874dd:	4c 8b 84 24 b8 74 0a 	mov    0xa74b8(%rsp),%r8
  1874e4:	00 
  1874e5:	4c 89 84 24 80 6d 0a 	mov    %r8,0xa6d80(%rsp)
  1874ec:	00 
  1874ed:	4c 8b 84 24 50 70 0a 	mov    0xa7050(%rsp),%r8
  1874f4:	00 
  1874f5:	4c 89 84 24 88 6d 0a 	mov    %r8,0xa6d88(%rsp)
  1874fc:	00 
  1874fd:	4c 8b 84 24 58 70 0a 	mov    0xa7058(%rsp),%r8
  187504:	00 
  187505:	4c 89 84 24 90 6d 0a 	mov    %r8,0xa6d90(%rsp)
  18750c:	00 
  18750d:	4c 8b 84 24 c0 74 0a 	mov    0xa74c0(%rsp),%r8
  187514:	00 
  187515:	4c 89 84 24 98 6d 0a 	mov    %r8,0xa6d98(%rsp)
  18751c:	00 
  18751d:	4c 8b 84 24 c8 74 0a 	mov    0xa74c8(%rsp),%r8
  187524:	00 
  187525:	4c 89 84 24 a0 6d 0a 	mov    %r8,0xa6da0(%rsp)
  18752c:	00 
  18752d:	4c 8b 84 24 d0 74 0a 	mov    0xa74d0(%rsp),%r8
  187534:	00 
  187535:	4c 89 84 24 a8 6d 0a 	mov    %r8,0xa6da8(%rsp)
  18753c:	00 
  18753d:	4c 8b 84 24 d8 74 0a 	mov    0xa74d8(%rsp),%r8
  187544:	00 
  187545:	4c 89 84 24 b0 6d 0a 	mov    %r8,0xa6db0(%rsp)
  18754c:	00 
  18754d:	4c 8b 84 24 e0 74 0a 	mov    0xa74e0(%rsp),%r8
  187554:	00 
  187555:	4c 89 84 24 b8 6d 0a 	mov    %r8,0xa6db8(%rsp)
  18755c:	00 
  18755d:	4c 8b 84 24 b0 70 0a 	mov    0xa70b0(%rsp),%r8
  187564:	00 
  187565:	4c 89 84 24 c0 6d 0a 	mov    %r8,0xa6dc0(%rsp)
  18756c:	00 
  18756d:	4c 8b 84 24 b8 70 0a 	mov    0xa70b8(%rsp),%r8
  187574:	00 
  187575:	4c 89 84 24 c8 6d 0a 	mov    %r8,0xa6dc8(%rsp)
  18757c:	00 
  18757d:	4c 8b 84 24 e8 74 0a 	mov    0xa74e8(%rsp),%r8
  187584:	00 
  187585:	4c 89 84 24 d0 6d 0a 	mov    %r8,0xa6dd0(%rsp)
  18758c:	00 
  18758d:	4c 8b 84 24 d0 70 0a 	mov    0xa70d0(%rsp),%r8
  187594:	00 
  187595:	4c 89 84 24 d8 6d 0a 	mov    %r8,0xa6dd8(%rsp)
  18759c:	00 
  18759d:	4c 8b 84 24 d8 70 0a 	mov    0xa70d8(%rsp),%r8
  1875a4:	00 
  1875a5:	4c 89 84 24 e0 6d 0a 	mov    %r8,0xa6de0(%rsp)
  1875ac:	00 
  1875ad:	4c 8b 84 24 f0 74 0a 	mov    0xa74f0(%rsp),%r8
  1875b4:	00 
  1875b5:	4c 89 84 24 e8 6d 0a 	mov    %r8,0xa6de8(%rsp)
  1875bc:	00 
  1875bd:	4c 8b 84 24 f8 74 0a 	mov    0xa74f8(%rsp),%r8
  1875c4:	00 
  1875c5:	4c 89 84 24 f0 6d 0a 	mov    %r8,0xa6df0(%rsp)
  1875cc:	00 
  1875cd:	4c 8b 84 24 18 70 0a 	mov    0xa7018(%rsp),%r8
  1875d4:	00 
  1875d5:	4c 89 84 24 f8 6d 0a 	mov    %r8,0xa6df8(%rsp)
  1875dc:	00 
  1875dd:	4c 8b 84 24 00 71 0a 	mov    0xa7100(%rsp),%r8
  1875e4:	00 
  1875e5:	4c 89 84 24 00 6e 0a 	mov    %r8,0xa6e00(%rsp)
  1875ec:	00 
  1875ed:	4c 8b 84 24 08 71 0a 	mov    0xa7108(%rsp),%r8
  1875f4:	00 
  1875f5:	4c 89 84 24 08 6e 0a 	mov    %r8,0xa6e08(%rsp)
  1875fc:	00 
  1875fd:	4c 8b 84 24 00 75 0a 	mov    0xa7500(%rsp),%r8
  187604:	00 
  187605:	4c 89 84 24 10 6e 0a 	mov    %r8,0xa6e10(%rsp)
  18760c:	00 
  18760d:	4c 8b 84 24 08 75 0a 	mov    0xa7508(%rsp),%r8
  187614:	00 
  187615:	4c 89 84 24 18 6e 0a 	mov    %r8,0xa6e18(%rsp)
  18761c:	00 
  18761d:	4c 8b 84 24 10 75 0a 	mov    0xa7510(%rsp),%r8
  187624:	00 
  187625:	4c 89 84 24 20 6e 0a 	mov    %r8,0xa6e20(%rsp)
  18762c:	00 
  18762d:	4c 8b 84 24 18 75 0a 	mov    0xa7518(%rsp),%r8
  187634:	00 
  187635:	4c 89 84 24 28 6e 0a 	mov    %r8,0xa6e28(%rsp)
  18763c:	00 
  18763d:	4c 8b 84 24 50 71 0a 	mov    0xa7150(%rsp),%r8
  187644:	00 
  187645:	4c 89 84 24 30 6e 0a 	mov    %r8,0xa6e30(%rsp)
  18764c:	00 
  18764d:	4c 8b 84 24 58 71 0a 	mov    0xa7158(%rsp),%r8
  187654:	00 
  187655:	4c 89 84 24 38 6e 0a 	mov    %r8,0xa6e38(%rsp)
  18765c:	00 
  18765d:	4c 8b 84 24 20 75 0a 	mov    0xa7520(%rsp),%r8
  187664:	00 
  187665:	4c 89 84 24 40 6e 0a 	mov    %r8,0xa6e40(%rsp)
  18766c:	00 
  18766d:	4c 8b 84 24 70 71 0a 	mov    0xa7170(%rsp),%r8
  187674:	00 
  187675:	4c 89 84 24 48 6e 0a 	mov    %r8,0xa6e48(%rsp)
  18767c:	00 
  18767d:	4c 8b 84 24 78 71 0a 	mov    0xa7178(%rsp),%r8
  187684:	00 
  187685:	4c 89 84 24 50 6e 0a 	mov    %r8,0xa6e50(%rsp)
  18768c:	00 
  18768d:	4c 8b 84 24 28 75 0a 	mov    0xa7528(%rsp),%r8
  187694:	00 
  187695:	4c 89 84 24 58 6e 0a 	mov    %r8,0xa6e58(%rsp)
  18769c:	00 
  18769d:	4c 8b 84 24 30 75 0a 	mov    0xa7530(%rsp),%r8
  1876a4:	00 
  1876a5:	4c 89 84 24 60 6e 0a 	mov    %r8,0xa6e60(%rsp)
  1876ac:	00 
  1876ad:	4c 8b 84 24 38 75 0a 	mov    0xa7538(%rsp),%r8
  1876b4:	00 
  1876b5:	4c 89 84 24 68 6e 0a 	mov    %r8,0xa6e68(%rsp)
  1876bc:	00 
  1876bd:	4c 8b 84 24 b0 71 0a 	mov    0xa71b0(%rsp),%r8
  1876c4:	00 
  1876c5:	4c 89 84 24 70 6e 0a 	mov    %r8,0xa6e70(%rsp)
  1876cc:	00 
