
/home/jacobt/src/scriptw/target/react-native-attribution-20261103/native-sync/ft.bin:     file format binary


Disassembly of section .data:

0000000000044806 <.data+0x44806>:
   44806:	45 85 ca             	test   %r9d,%r10d
   44809:	0f 84 47 70 14 00    	je     0x18b856
   4480f:	48 8b 84 24 50 2f 04 	mov    0x42f50(%rsp),%rax
   44816:	00 
   44817:	4c 8b 9c 24 50 2f 04 	mov    0x42f50(%rsp),%r11
   4481e:	00 
   4481f:	41 85 c3             	test   %eax,%r11d
   44822:	0f 84 30 70 14 00    	je     0x18b858
   44828:	48 8b bc 24 50 2f 04 	mov    0x42f50(%rsp),%rdi
   4482f:	00 
   44830:	44 8b f7             	mov    %edi,%r14d
   44833:	4c 8b a4 24 e0 03 00 	mov    0x3e0(%rsp),%r12
   4483a:	00 
   4483b:	4d 8b 44 24 08       	mov    0x8(%r12),%r8
   44840:	49 8b 70 28          	mov    0x28(%r8),%rsi
   44844:	48 8b 9c 24 e0 03 00 	mov    0x3e0(%rsp),%rbx
   4484b:	00 
   4484c:	4c 8b 6b 08          	mov    0x8(%rbx),%r13
   44850:	49 8b 4d 20          	mov    0x20(%r13),%rcx
   44854:	4a 8d 14 31          	lea    (%rcx,%r14,1),%rdx
   44858:	4d 33 ff             	xor    %r15,%r15
   4485b:	4c 3b f6             	cmp    %rsi,%r14
   4485e:	49 0f 47 d7          	cmova  %r15,%rdx
   44862:	44 8b 4a 18          	mov    0x18(%rdx),%r9d
   44866:	4c 89 8c 24 c8 2f 04 	mov    %r9,0x42fc8(%rsp)
   4486d:	00 
   4486e:	4c 8b 94 24 50 2f 04 	mov    0x42f50(%rsp),%r10
   44875:	00 
   44876:	48 8b 84 24 50 2f 04 	mov    0x42f50(%rsp),%rax
   4487d:	00 
   4487e:	44 85 d0             	test   %r10d,%eax
   44881:	0f 84 d3 6f 14 00    	je     0x18b85a
   44887:	4c 8b 9c 24 50 2f 04 	mov    0x42f50(%rsp),%r11
   4488e:	00 
   4488f:	48 8b bc 24 50 2f 04 	mov    0x42f50(%rsp),%rdi
   44896:	00 
   44897:	44 85 df             	test   %r11d,%edi
   4489a:	0f 84 bc 6f 14 00    	je     0x18b85c
   448a0:	4c 8b a4 24 50 2f 04 	mov    0x42f50(%rsp),%r12
   448a7:	00 
   448a8:	45 8b c4             	mov    %r12d,%r8d
   448ab:	48 8b 9c 24 e0 03 00 	mov    0x3e0(%rsp),%rbx
   448b2:	00 
   448b3:	4c 8b 6b 08          	mov    0x8(%rbx),%r13
   448b7:	49 8b 4d 28          	mov    0x28(%r13),%rcx
   448bb:	48 8b b4 24 e0 03 00 	mov    0x3e0(%rsp),%rsi
   448c2:	00 
   448c3:	4c 8b 76 08          	mov    0x8(%rsi),%r14
   448c7:	4d 8b 7e 20          	mov    0x20(%r14),%r15
   448cb:	4b 8d 14 07          	lea    (%r15,%r8,1),%rdx
   448cf:	4d 33 c9             	xor    %r9,%r9
   448d2:	4c 3b c1             	cmp    %rcx,%r8
   448d5:	49 0f 47 d1          	cmova  %r9,%rdx
   448d9:	44 8b 52 1c          	mov    0x1c(%rdx),%r10d
   448dd:	4c 89 94 24 b0 2f 04 	mov    %r10,0x42fb0(%rsp)
   448e4:	00 
   448e5:	48 8b 84 24 d8 2f 04 	mov    0x42fd8(%rsp),%rax
   448ec:	00 
   448ed:	4c 8b 9c 24 d8 2f 04 	mov    0x42fd8(%rsp),%r11
   448f4:	00 
   448f5:	41 85 c3             	test   %eax,%r11d
   448f8:	0f 84 60 6f 14 00    	je     0x18b85e
   448fe:	48 8b bc 24 d8 2f 04 	mov    0x42fd8(%rsp),%rdi
   44905:	00 
   44906:	4c 8b a4 24 d8 2f 04 	mov    0x42fd8(%rsp),%r12
   4490d:	00 
   4490e:	41 85 fc             	test   %edi,%r12d
   44911:	0f 84 49 6f 14 00    	je     0x18b860
   44917:	48 8b 9c 24 d8 2f 04 	mov    0x42fd8(%rsp),%rbx
   4491e:	00 
   4491f:	44 8b eb             	mov    %ebx,%r13d
   44922:	48 8b b4 24 e0 03 00 	mov    0x3e0(%rsp),%rsi
   44929:	00 
   4492a:	4c 8b 76 08          	mov    0x8(%rsi),%r14
   4492e:	4d 8b 7e 28          	mov    0x28(%r14),%r15
   44932:	48 8b 8c 24 e0 03 00 	mov    0x3e0(%rsp),%rcx
   44939:	00 
   4493a:	4c 8b 41 08          	mov    0x8(%rcx),%r8
   4493e:	4d 8b 48 20          	mov    0x20(%r8),%r9
   44942:	4c 8b 84 24 d8 2f 04 	mov    0x42fd8(%rsp),%r8
   44949:	00 
   4494a:	4b 8d 54 29 10       	lea    0x10(%r9,%r13,1),%rdx
   4494f:	4d 33 d2             	xor    %r10,%r10
   44952:	4d 3b ef             	cmp    %r15,%r13
   44955:	49 0f 47 d2          	cmova  %r10,%rdx
   44959:	8b 02                	mov    (%rdx),%eax
   4495b:	4c 8b 9c 24 68 2f 04 	mov    0x42f68(%rsp),%r11
   44962:	00 
   44963:	44 3b d8             	cmp    %eax,%r11d
   44966:	0f 83 f6 6e 14 00    	jae    0x18b862
   4496c:	bf 01 00 00 00       	mov    $0x1,%edi
   44971:	44 8b e0             	mov    %eax,%r12d
   44974:	49 6b dc 01          	imul   $0x1,%r12,%rbx
   44978:	48 89 de             	mov    %rbx,%rsi
   4497b:	48 c1 ee 20          	shr    $0x20,%rsi
   4497f:	48 85 f6             	test   %rsi,%rsi
   44982:	0f 85 dc 6e 14 00    	jne    0x18b864
   44988:	83 c3 14             	add    $0x14,%ebx
   4498b:	0f 82 d5 6e 14 00    	jb     0x18b866
   44991:	4c 8b b4 24 68 2f 04 	mov    0x42f68(%rsp),%r14
   44998:	00 
   44999:	44 0f af f7          	imul   %edi,%r14d
   4499d:	41 8d 4e 14          	lea    0x14(%r14),%ecx
   449a1:	44 03 c3             	add    %ebx,%r8d
   449a4:	0f 82 be 6e 14 00    	jb     0x18b868
   449aa:	45 8b c8             	mov    %r8d,%r9d
   449ad:	4c 8b bc 24 e0 03 00 	mov    0x3e0(%rsp),%r15
   449b4:	00 
   449b5:	4d 8b 6f 08          	mov    0x8(%r15),%r13
   449b9:	4d 8b 55 28          	mov    0x28(%r13),%r10
   449bd:	48 8b 94 24 e0 03 00 	mov    0x3e0(%rsp),%rdx
   449c4:	00 
   449c5:	4c 8b 5a 08          	mov    0x8(%rdx),%r11
   449c9:	4c 89 c8             	mov    %r9,%rax
   449cc:	49 03 43 20          	add    0x20(%r11),%rax
   449d0:	4d 33 e4             	xor    %r12,%r12
   449d3:	4d 3b ca             	cmp    %r10,%r9
   449d6:	49 0f 47 c4          	cmova  %r12,%rax
   449da:	2b d9                	sub    %ecx,%ebx
   449dc:	48 2b c3             	sub    %rbx,%rax
   449df:	40 0f b6 30          	rex movzbl (%rax),%esi
   449e3:	48 89 b4 24 90 2f 04 	mov    %rsi,0x42f90(%rsp)
   449ea:	00 
   449eb:	48 33 ff             	xor    %rdi,%rdi
   449ee:	48 89 bc 24 d0 2f 04 	mov    %rdi,0x42fd0(%rsp)
   449f5:	00 
   449f6:	4c 8b b4 24 c8 2f 04 	mov    0x42fc8(%rsp),%r14
   449fd:	00 
   449fe:	4c 8b 84 24 c8 2f 04 	mov    0x42fc8(%rsp),%r8
   44a05:	00 
