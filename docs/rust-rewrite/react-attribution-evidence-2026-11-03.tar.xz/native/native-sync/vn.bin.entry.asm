
/home/jacobt/src/scriptw/target/react-native-attribution-20261103/native-sync/vn.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
       0:	55                   	push   %rbp
       1:	48 89 e5             	mov    %rsp,%rbp
       4:	4c 8b 57 08          	mov    0x8(%rdi),%r10
       8:	4d 8b 52 18          	mov    0x18(%r10),%r10
       c:	4c 3b d4             	cmp    %rsp,%r10
       f:	0f 87 2a a7 4d 00    	ja     0x4da73f
      15:	49 81 c2 90 6f 0f 00 	add    $0xf6f90,%r10
      1c:	4c 3b d4             	cmp    %rsp,%r10
      1f:	0f 87 1c a7 4d 00    	ja     0x4da741
      25:	49 89 e3             	mov    %rsp,%r11
      28:	49 81 eb 00 70 0f 00 	sub    $0xf7000,%r11
      2f:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
      36:	c7 04 24 00 00 00 00 	movl   $0x0,(%rsp)
      3d:	4c 3b dc             	cmp    %rsp,%r11
      40:	0f 85 e9 ff ff ff    	jne    0x2f
      46:	48 81 c4 00 70 0f 00 	add    $0xf7000,%rsp
      4d:	48 81 ec 80 6f 0f 00 	sub    $0xf6f80,%rsp
      54:	48 89 9c 24 50 6f 0f 	mov    %rbx,0xf6f50(%rsp)
      5b:	00 
      5c:	4c 89 a4 24 58 6f 0f 	mov    %r12,0xf6f58(%rsp)
      63:	00 
      64:	4c 89 ac 24 60 6f 0f 	mov    %r13,0xf6f60(%rsp)
      6b:	00 
      6c:	4c 89 b4 24 68 6f 0f 	mov    %r14,0xf6f68(%rsp)
      73:	00 
      74:	4c 89 bc 24 70 6f 0f 	mov    %r15,0xf6f70(%rsp)
      7b:	00 
      7c:	4c 89 cb             	mov    %r9,%rbx
      7f:	4c 89 84 24 f8 6a 0f 	mov    %r8,0xf6af8(%rsp)
      86:	00 
      87:	48 89 8c 24 00 6b 0f 	mov    %rcx,0xf6b00(%rsp)
      8e:	00 
      8f:	49 89 d7             	mov    %rdx,%r15
      92:	48 89 bc 24 f0 06 00 	mov    %rdi,0x6f0(%rsp)
      99:	00 
      9a:	4c 8b 55 10          	mov    0x10(%rbp),%r10
      9e:	4c 89 94 24 98 6a 0f 	mov    %r10,0xf6a98(%rsp)
      a5:	00 
      a6:	48 8b 45 18          	mov    0x18(%rbp),%rax
      aa:	48 89 84 24 90 6a 0f 	mov    %rax,0xf6a90(%rsp)
      b1:	00 
      b2:	4c 8b 5d 20          	mov    0x20(%rbp),%r11
      b6:	48 8b 7d 28          	mov    0x28(%rbp),%rdi
      ba:	48 89 bc 24 18 6f 0f 	mov    %rdi,0xf6f18(%rsp)
      c1:	00 
      c2:	4c 8b 75 30          	mov    0x30(%rbp),%r14
      c6:	4c 8b 45 40          	mov    0x40(%rbp),%r8
      ca:	44 89 bc 24 70 06 00 	mov    %r15d,0x670(%rsp)
      d1:	00 
      d2:	89 9c 24 a8 05 00 00 	mov    %ebx,0x5a8(%rsp)
      d9:	44 89 9c 24 d8 02 00 	mov    %r11d,0x2d8(%rsp)
      e0:	00 
      e1:	44 89 b4 24 98 02 00 	mov    %r14d,0x298(%rsp)
      e8:	00 
      e9:	44 89 84 24 80 03 00 	mov    %r8d,0x380(%rsp)
      f0:	00 
      f1:	48 33 f6             	xor    %rsi,%rsi
      f4:	48 89 b4 24 00 4a 0f 	mov    %rsi,0xf4a00(%rsp)
      fb:	00 
      fc:	33 c9                	xor    %ecx,%ecx
      fe:	48 89 8c 24 70 3a 03 	mov    %rcx,0x33a70(%rsp)
     105:	00 
     106:	c7 84 24 e0 01 00 00 	movl   $0x0,0x1e0(%rsp)
     10d:	00 00 00 00 
     111:	45 33 ed             	xor    %r13d,%r13d
     114:	4c 89 ac 24 50 a4 0a 	mov    %r13,0xaa450(%rsp)
     11b:	00 
     11c:	48 33 d2             	xor    %rdx,%rdx
     11f:	48 89 94 24 b0 59 02 	mov    %rdx,0x259b0(%rsp)
     126:	00 
     127:	c7 84 24 20 04 00 00 	movl   $0x0,0x420(%rsp)
     12e:	00 00 00 00 
     132:	c7 84 24 e0 03 00 00 	movl   $0x0,0x3e0(%rsp)
     139:	00 00 00 00 
     13d:	c7 84 24 c0 02 00 00 	movl   $0x0,0x2c0(%rsp)
     144:	00 00 00 00 
     148:	4d 33 e4             	xor    %r12,%r12
     14b:	4c 89 a4 24 d8 5e 0b 	mov    %r12,0xb5ed8(%rsp)
     152:	00 
     153:	c7 84 24 b0 01 00 00 	movl   $0x0,0x1b0(%rsp)
     15a:	00 00 00 00 
     15e:	4d 33 c9             	xor    %r9,%r9
     161:	4c 89 8c 24 58 f6 00 	mov    %r9,0xf658(%rsp)
     168:	00 
     169:	c7 84 24 10 02 00 00 	movl   $0x0,0x210(%rsp)
     170:	00 00 00 00 
     174:	45 33 d2             	xor    %r10d,%r10d
     177:	4c 89 94 24 b0 b4 01 	mov    %r10,0x1b4b0(%rsp)
     17e:	00 
     17f:	48 33 c0             	xor    %rax,%rax
     182:	48 89 84 24 08 43 0f 	mov    %rax,0xf4308(%rsp)
     189:	00 
     18a:	c7 84 24 90 02 00 00 	movl   $0x0,0x290(%rsp)
     191:	00 00 00 00 
     195:	c7 84 24 80 04 00 00 	movl   $0x0,0x480(%rsp)
     19c:	00 00 00 00 
     1a0:	33 ff                	xor    %edi,%edi
     1a2:	48 89 bc 24 30 b2 02 	mov    %rdi,0x2b230(%rsp)
     1a9:	00 
     1aa:	4d 33 ff             	xor    %r15,%r15
     1ad:	4c 89 bc 24 40 db 0e 	mov    %r15,0xedb40(%rsp)
     1b4:	00 
     1b5:	c7 84 24 00 02 00 00 	movl   $0x0,0x200(%rsp)
     1bc:	00 00 00 00 
     1c0:	c7 84 24 c8 02 00 00 	movl   $0x0,0x2c8(%rsp)
     1c7:	00 00 00 00 
     1cb:	c7 84 24 b8 02 00 00 	movl   $0x0,0x2b8(%rsp)
     1d2:	00 00 00 00 
     1d6:	33 db                	xor    %ebx,%ebx
     1d8:	48 89 9c 24 00 dd 09 	mov    %rbx,0x9dd00(%rsp)
     1df:	00 
     1e0:	4d 33 db             	xor    %r11,%r11
     1e3:	4c 89 9c 24 b0 1b 0a 	mov    %r11,0xa1bb0(%rsp)
     1ea:	00 
     1eb:	c7 84 24 c0 06 00 00 	movl   $0x0,0x6c0(%rsp)
     1f2:	00 00 00 00 
     1f6:	c7 84 24 48 02 00 00 	movl   $0x0,0x248(%rsp)
     1fd:	00 00 00  
