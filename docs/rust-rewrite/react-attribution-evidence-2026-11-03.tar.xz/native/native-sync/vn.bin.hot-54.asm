
/home/jacobt/src/scriptw/target/react-native-attribution-20261103/native-sync/vn.bin:     file format binary


Disassembly of section .data:

0000000000421fbc <.data+0x421fbc>:
  421fbc:	48 8b bc 24 b0 30 02 	mov    0x230b0(%rsp),%rdi
  421fc3:	00 
  421fc4:	48 89 bc 24 d8 27 02 	mov    %rdi,0x227d8(%rsp)
  421fcb:	00 
  421fcc:	48 8b bc 24 30 32 02 	mov    0x23230(%rsp),%rdi
  421fd3:	00 
  421fd4:	48 89 bc 24 e0 27 02 	mov    %rdi,0x227e0(%rsp)
  421fdb:	00 
  421fdc:	48 8b bc 24 a8 30 02 	mov    0x230a8(%rsp),%rdi
  421fe3:	00 
  421fe4:	48 89 bc 24 e8 27 02 	mov    %rdi,0x227e8(%rsp)
  421feb:	00 
  421fec:	48 8b bc 24 c0 30 02 	mov    0x230c0(%rsp),%rdi
  421ff3:	00 
  421ff4:	48 89 bc 24 f0 27 02 	mov    %rdi,0x227f0(%rsp)
  421ffb:	00 
  421ffc:	48 8b bc 24 c8 30 02 	mov    0x230c8(%rsp),%rdi
  422003:	00 
  422004:	48 89 bc 24 f8 27 02 	mov    %rdi,0x227f8(%rsp)
  42200b:	00 
  42200c:	48 8b bc 24 d0 30 02 	mov    0x230d0(%rsp),%rdi
  422013:	00 
  422014:	48 89 bc 24 00 28 02 	mov    %rdi,0x22800(%rsp)
  42201b:	00 
  42201c:	48 8b bc 24 d8 30 02 	mov    0x230d8(%rsp),%rdi
  422023:	00 
  422024:	48 89 bc 24 08 28 02 	mov    %rdi,0x22808(%rsp)
  42202b:	00 
  42202c:	48 8b bc 24 e0 30 02 	mov    0x230e0(%rsp),%rdi
  422033:	00 
  422034:	48 89 bc 24 10 28 02 	mov    %rdi,0x22810(%rsp)
  42203b:	00 
  42203c:	48 8b bc 24 e8 30 02 	mov    0x230e8(%rsp),%rdi
  422043:	00 
  422044:	48 89 bc 24 18 28 02 	mov    %rdi,0x22818(%rsp)
  42204b:	00 
  42204c:	48 8b bc 24 f0 30 02 	mov    0x230f0(%rsp),%rdi
  422053:	00 
  422054:	48 89 bc 24 20 28 02 	mov    %rdi,0x22820(%rsp)
  42205b:	00 
  42205c:	48 8b bc 24 f8 30 02 	mov    0x230f8(%rsp),%rdi
  422063:	00 
  422064:	48 89 bc 24 28 28 02 	mov    %rdi,0x22828(%rsp)
  42206b:	00 
  42206c:	48 8b bc 24 00 31 02 	mov    0x23100(%rsp),%rdi
  422073:	00 
  422074:	48 89 bc 24 30 28 02 	mov    %rdi,0x22830(%rsp)
  42207b:	00 
  42207c:	48 8b bc 24 08 31 02 	mov    0x23108(%rsp),%rdi
  422083:	00 
  422084:	48 89 bc 24 38 28 02 	mov    %rdi,0x22838(%rsp)
  42208b:	00 
  42208c:	48 8b bc 24 10 31 02 	mov    0x23110(%rsp),%rdi
  422093:	00 
  422094:	48 89 bc 24 40 28 02 	mov    %rdi,0x22840(%rsp)
  42209b:	00 
  42209c:	48 8b bc 24 18 31 02 	mov    0x23118(%rsp),%rdi
  4220a3:	00 
  4220a4:	48 89 bc 24 48 28 02 	mov    %rdi,0x22848(%rsp)
  4220ab:	00 
  4220ac:	48 8b bc 24 20 31 02 	mov    0x23120(%rsp),%rdi
  4220b3:	00 
  4220b4:	48 89 bc 24 50 28 02 	mov    %rdi,0x22850(%rsp)
  4220bb:	00 
  4220bc:	48 8b bc 24 28 31 02 	mov    0x23128(%rsp),%rdi
  4220c3:	00 
  4220c4:	48 89 bc 24 58 28 02 	mov    %rdi,0x22858(%rsp)
  4220cb:	00 
  4220cc:	48 8b bc 24 30 31 02 	mov    0x23130(%rsp),%rdi
  4220d3:	00 
  4220d4:	48 89 bc 24 60 28 02 	mov    %rdi,0x22860(%rsp)
  4220db:	00 
  4220dc:	48 8b bc 24 38 31 02 	mov    0x23138(%rsp),%rdi
  4220e3:	00 
  4220e4:	48 89 bc 24 68 28 02 	mov    %rdi,0x22868(%rsp)
  4220eb:	00 
  4220ec:	48 8b bc 24 40 31 02 	mov    0x23140(%rsp),%rdi
  4220f3:	00 
  4220f4:	48 89 bc 24 70 28 02 	mov    %rdi,0x22870(%rsp)
  4220fb:	00 
  4220fc:	48 8b bc 24 48 31 02 	mov    0x23148(%rsp),%rdi
  422103:	00 
  422104:	48 89 bc 24 78 28 02 	mov    %rdi,0x22878(%rsp)
  42210b:	00 
  42210c:	48 8b bc 24 50 31 02 	mov    0x23150(%rsp),%rdi
  422113:	00 
  422114:	48 89 bc 24 80 28 02 	mov    %rdi,0x22880(%rsp)
  42211b:	00 
  42211c:	48 8b bc 24 58 31 02 	mov    0x23158(%rsp),%rdi
  422123:	00 
  422124:	48 89 bc 24 88 28 02 	mov    %rdi,0x22888(%rsp)
  42212b:	00 
  42212c:	48 8b bc 24 60 31 02 	mov    0x23160(%rsp),%rdi
  422133:	00 
  422134:	48 89 bc 24 90 28 02 	mov    %rdi,0x22890(%rsp)
  42213b:	00 
  42213c:	48 8b bc 24 68 31 02 	mov    0x23168(%rsp),%rdi
  422143:	00 
  422144:	48 89 bc 24 98 28 02 	mov    %rdi,0x22898(%rsp)
  42214b:	00 
  42214c:	48 8b bc 24 70 31 02 	mov    0x23170(%rsp),%rdi
  422153:	00 
  422154:	48 89 bc 24 a0 28 02 	mov    %rdi,0x228a0(%rsp)
  42215b:	00 
  42215c:	48 8b bc 24 78 31 02 	mov    0x23178(%rsp),%rdi
  422163:	00 
  422164:	48 89 bc 24 a8 28 02 	mov    %rdi,0x228a8(%rsp)
  42216b:	00 
  42216c:	48 8b bc 24 80 31 02 	mov    0x23180(%rsp),%rdi
  422173:	00 
  422174:	48 89 bc 24 b0 28 02 	mov    %rdi,0x228b0(%rsp)
  42217b:	00 
  42217c:	48 8b bc 24 88 31 02 	mov    0x23188(%rsp),%rdi
  422183:	00 
  422184:	48 89 bc 24 b8 28 02 	mov    %rdi,0x228b8(%rsp)
  42218b:	00 
  42218c:	48 8b bc 24 90 31 02 	mov    0x23190(%rsp),%rdi
  422193:	00 
  422194:	48 89 bc 24 c0 28 02 	mov    %rdi,0x228c0(%rsp)
  42219b:	00 
  42219c:	48 8b bc 24 98 31 02 	mov    0x23198(%rsp),%rdi
  4221a3:	00 
  4221a4:	48 89 bc 24 c8 28 02 	mov    %rdi,0x228c8(%rsp)
  4221ab:	00 
  4221ac:	48 8b bc 24 a0 31 02 	mov    0x231a0(%rsp),%rdi
  4221b3:	00 
  4221b4:	48 89 bc 24 d0 28 02 	mov    %rdi,0x228d0(%rsp)
  4221bb:	00 
