
/home/jacobt/src/scriptw/target/react-native-attribution-20261103/native-sync/ft.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
       0:	55                   	push   %rbp
       1:	48 89 e5             	mov    %rsp,%rbp
       4:	4c 8b 57 08          	mov    0x8(%rdi),%r10
       8:	4d 8b 52 18          	mov    0x18(%r10),%r10
       c:	4c 3b d4             	cmp    %rsp,%r10
       f:	0f 87 7b b0 18 00    	ja     0x18b090
      15:	49 81 c2 90 2f 05 00 	add    $0x52f90,%r10
      1c:	4c 3b d4             	cmp    %rsp,%r10
      1f:	0f 87 6d b0 18 00    	ja     0x18b092
      25:	49 89 e3             	mov    %rsp,%r11
      28:	49 81 eb 00 30 05 00 	sub    $0x53000,%r11
      2f:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
      36:	c7 04 24 00 00 00 00 	movl   $0x0,(%rsp)
      3d:	4c 3b dc             	cmp    %rsp,%r11
      40:	0f 85 e9 ff ff ff    	jne    0x2f
      46:	48 81 c4 00 30 05 00 	add    $0x53000,%rsp
      4d:	48 81 ec 80 2f 05 00 	sub    $0x52f80,%rsp
      54:	48 89 9c 24 50 2f 05 	mov    %rbx,0x52f50(%rsp)
      5b:	00 
      5c:	4c 89 a4 24 58 2f 05 	mov    %r12,0x52f58(%rsp)
      63:	00 
      64:	4c 89 ac 24 60 2f 05 	mov    %r13,0x52f60(%rsp)
      6b:	00 
      6c:	4c 89 b4 24 68 2f 05 	mov    %r14,0x52f68(%rsp)
      73:	00 
      74:	4c 89 bc 24 70 2f 05 	mov    %r15,0x52f70(%rsp)
      7b:	00 
      7c:	4d 89 cd             	mov    %r9,%r13
      7f:	4c 89 84 24 f0 2a 05 	mov    %r8,0x52af0(%rsp)
      86:	00 
      87:	48 89 8c 24 f8 2a 05 	mov    %rcx,0x52af8(%rsp)
      8e:	00 
      8f:	49 89 d7             	mov    %rdx,%r15
      92:	48 89 bc 24 e0 03 00 	mov    %rdi,0x3e0(%rsp)
      99:	00 
      9a:	48 8b 45 10          	mov    0x10(%rbp),%rax
      9e:	48 89 84 24 90 2a 05 	mov    %rax,0x52a90(%rsp)
      a5:	00 
      a6:	48 8b 7d 18          	mov    0x18(%rbp),%rdi
      aa:	48 89 bc 24 88 2a 05 	mov    %rdi,0x52a88(%rsp)
      b1:	00 
      b2:	4c 8b 75 20          	mov    0x20(%rbp),%r14
      b6:	48 8b 5d 28          	mov    0x28(%rbp),%rbx
      ba:	48 89 9c 24 10 2f 05 	mov    %rbx,0x52f10(%rsp)
      c1:	00 
      c2:	4c 8b 45 30          	mov    0x30(%rbp),%r8
      c6:	48 8b 75 40          	mov    0x40(%rbp),%rsi
      ca:	44 89 bc 24 70 02 00 	mov    %r15d,0x270(%rsp)
      d1:	00 
      d2:	44 89 6c 24 58       	mov    %r13d,0x58(%rsp)
      d7:	44 89 b4 24 90 00 00 	mov    %r14d,0x90(%rsp)
      de:	00 
      df:	44 89 84 24 d8 00 00 	mov    %r8d,0xd8(%rsp)
      e6:	00 
      e7:	89 b4 24 e0 00 00 00 	mov    %esi,0xe0(%rsp)
      ee:	33 c9                	xor    %ecx,%ecx
      f0:	48 89 8c 24 b0 0f 05 	mov    %rcx,0x50fb0(%rsp)
      f7:	00 
      f8:	4d 33 db             	xor    %r11,%r11
      fb:	4c 89 9c 24 b8 0f 05 	mov    %r11,0x50fb8(%rsp)
     102:	00 
     103:	c7 84 24 c0 00 00 00 	movl   $0x0,0xc0(%rsp)
     10a:	00 00 00 00 
     10e:	33 d2                	xor    %edx,%edx
     110:	48 89 94 24 a0 14 05 	mov    %rdx,0x514a0(%rsp)
     117:	00 
     118:	4d 33 d2             	xor    %r10,%r10
     11b:	4c 89 94 24 a8 14 05 	mov    %r10,0x514a8(%rsp)
     122:	00 
     123:	c7 84 24 d0 02 00 00 	movl   $0x0,0x2d0(%rsp)
     12a:	00 00 00 00 
     12e:	4d 33 c9             	xor    %r9,%r9
     131:	4c 89 8c 24 78 18 05 	mov    %r9,0x51878(%rsp)
     138:	00 
     139:	45 33 e4             	xor    %r12d,%r12d
     13c:	4c 89 a4 24 a0 18 05 	mov    %r12,0x518a0(%rsp)
     143:	00 
     144:	48 33 c0             	xor    %rax,%rax
     147:	48 89 84 24 c8 12 05 	mov    %rax,0x512c8(%rsp)
     14e:	00 
     14f:	33 ff                	xor    %edi,%edi
     151:	48 89 bc 24 48 d4 04 	mov    %rdi,0x4d448(%rsp)
     158:	00 
     159:	c7 84 24 b8 00 00 00 	movl   $0x0,0xb8(%rsp)
     160:	00 00 00 00 
     164:	33 db                	xor    %ebx,%ebx
     166:	48 89 9c 24 d0 0d 05 	mov    %rbx,0x50dd0(%rsp)
     16d:	00 
     16e:	4d 33 ff             	xor    %r15,%r15
     171:	4c 89 bc 24 88 0d 05 	mov    %r15,0x50d88(%rsp)
     178:	00 
     179:	c7 84 24 d8 01 00 00 	movl   $0x0,0x1d8(%rsp)
     180:	00 00 00 00 
     184:	c7 84 24 08 01 00 00 	movl   $0x0,0x108(%rsp)
     18b:	00 00 00 00 
     18f:	c7 84 24 38 02 00 00 	movl   $0x0,0x238(%rsp)
     196:	00 00 00 00 
     19a:	c7 84 24 68 01 00 00 	movl   $0x0,0x168(%rsp)
     1a1:	00 00 00 00 
     1a5:	c7 84 24 78 03 00 00 	movl   $0x0,0x378(%rsp)
     1ac:	00 00 00 00 
     1b0:	c7 84 24 f8 01 00 00 	movl   $0x0,0x1f8(%rsp)
     1b7:	00 00 00 00 
     1bb:	c7 84 24 40 02 00 00 	movl   $0x0,0x240(%rsp)
     1c2:	00 00 00 00 
     1c6:	4d 33 ed             	xor    %r13,%r13
     1c9:	4c 89 ac 24 90 f0 00 	mov    %r13,0xf090(%rsp)
     1d0:	00 
     1d1:	c7 84 24 78 02 00 00 	movl   $0x0,0x278(%rsp)
     1d8:	00 00 00 00 
     1dc:	45 33 f6             	xor    %r14d,%r14d
     1df:	4c 89 b4 24 08 f0 00 	mov    %r14,0xf008(%rsp)
     1e6:	00 
     1e7:	c7 84 24 00 03 00 00 	movl   $0x0,0x300(%rsp)
     1ee:	00 00 00 00 
     1f2:	c7 84 24 30 02 00 00 	movl   $0x0,0x230(%rsp)
     1f9:	00 00 00 00 
     1fd:	c7 84 24     	movl   $0x0,0x348(%rsp)
     204:	    
