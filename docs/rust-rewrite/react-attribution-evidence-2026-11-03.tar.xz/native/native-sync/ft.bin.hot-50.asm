
/home/jacobt/src/scriptw/target/react-native-attribution-20261103/native-sync/ft.bin:     file format binary


Disassembly of section .data:

000000000013761a <.data+0x13761a>:
  13761a:	44 85 da             	test   %r11d,%edx
  13761d:	0f 84 57 65 05 00    	je     0x18db7a
  137623:	48 8b bc 24 38 f3 00 	mov    0xf338(%rsp),%rdi
  13762a:	00 
  13762b:	48 8b 8c 24 38 f3 00 	mov    0xf338(%rsp),%rcx
  137632:	00 
  137633:	85 f9                	test   %edi,%ecx
  137635:	0f 84 41 65 05 00    	je     0x18db7c
  13763b:	4c 8b 8c 24 38 f3 00 	mov    0xf338(%rsp),%r9
  137642:	00 
  137643:	41 8b d9             	mov    %r9d,%ebx
  137646:	48 8b b4 24 e0 03 00 	mov    0x3e0(%rsp),%rsi
  13764d:	00 
  13764e:	4c 8b 46 08          	mov    0x8(%rsi),%r8
  137652:	4d 8b 78 28          	mov    0x28(%r8),%r15
  137656:	4c 8b b4 24 e0 03 00 	mov    0x3e0(%rsp),%r14
  13765d:	00 
  13765e:	49 8b 46 08          	mov    0x8(%r14),%rax
  137662:	4c 8b b4 24 38 f3 00 	mov    0xf338(%rsp),%r14
  137669:	00 
  13766a:	4c 8b 60 20          	mov    0x20(%rax),%r12
  13766e:	4d 8d 6c 1c 10       	lea    0x10(%r12,%rbx,1),%r13
  137673:	4d 33 d2             	xor    %r10,%r10
  137676:	49 3b df             	cmp    %r15,%rbx
  137679:	4d 0f 47 ea          	cmova  %r10,%r13
  13767d:	45 8b 5d 00          	mov    0x0(%r13),%r11d
  137681:	41 81 fb 9a 00 00 00 	cmp    $0x9a,%r11d
  137688:	0f 86 f0 64 05 00    	jbe    0x18db7e
  13768e:	ba 04 00 00 00       	mov    $0x4,%edx
  137693:	41 8b fb             	mov    %r11d,%edi
  137696:	48 6b cf 04          	imul   $0x4,%rdi,%rcx
  13769a:	49 89 c9             	mov    %rcx,%r9
  13769d:	49 c1 e9 20          	shr    $0x20,%r9
  1376a1:	4d 85 c9             	test   %r9,%r9
  1376a4:	0f 85 d6 64 05 00    	jne    0x18db80
  1376aa:	83 c1 14             	add    $0x14,%ecx
  1376ad:	0f 82 cf 64 05 00    	jb     0x18db82
  1376b3:	69 f2 9a 00 00 00    	imul   $0x9a,%edx,%esi
  1376b9:	44 8d 46 14          	lea    0x14(%rsi),%r8d
  1376bd:	44 03 f1             	add    %ecx,%r14d
  1376c0:	0f 82 be 64 05 00    	jb     0x18db84
  1376c6:	41 8b c6             	mov    %r14d,%eax
  1376c9:	4c 8b a4 24 e0 03 00 	mov    0x3e0(%rsp),%r12
  1376d0:	00 
  1376d1:	4d 8b 7c 24 08       	mov    0x8(%r12),%r15
  1376d6:	49 8b 5f 28          	mov    0x28(%r15),%rbx
  1376da:	4c 8b 94 24 e0 03 00 	mov    0x3e0(%rsp),%r10
  1376e1:	00 
  1376e2:	4d 8b 6a 08          	mov    0x8(%r10),%r13
  1376e6:	4d 8b 5d 20          	mov    0x20(%r13),%r11
  1376ea:	49 8d 3c 03          	lea    (%r11,%rax,1),%rdi
  1376ee:	4d 33 c9             	xor    %r9,%r9
  1376f1:	48 3b c3             	cmp    %rbx,%rax
  1376f4:	49 0f 47 f9          	cmova  %r9,%rdi
  1376f8:	41 2b c8             	sub    %r8d,%ecx
  1376fb:	48 2b f9             	sub    %rcx,%rdi
  1376fe:	8b 17                	mov    (%rdi),%edx
  137700:	48 89 94 24 30 f3 00 	mov    %rdx,0xf330(%rsp)
  137707:	00 
  137708:	48 8b b4 24 10 f3 00 	mov    0xf310(%rsp),%rsi
  13770f:	00 
  137710:	4c 8b b4 24 10 f3 00 	mov    0xf310(%rsp),%r14
  137717:	00 
  137718:	41 85 f6             	test   %esi,%r14d
  13771b:	0f 84 65 64 05 00    	je     0x18db86
  137721:	45 33 e4             	xor    %r12d,%r12d
  137724:	4c 89 a4 24 20 f3 00 	mov    %r12,0xf320(%rsp)
  13772b:	00 
  13772c:	45 33 ff             	xor    %r15d,%r15d
  13772f:	4c 89 bc 24 28 f3 00 	mov    %r15,0xf328(%rsp)
  137736:	00 
  137737:	4c 8b 94 24 30 f3 00 	mov    0xf330(%rsp),%r10
  13773e:	00 
  13773f:	4c 8b ac 24 30 f3 00 	mov    0xf330(%rsp),%r13
  137746:	00 
  137747:	45 85 d5             	test   %r10d,%r13d
  13774a:	0f 84 38 64 05 00    	je     0x18db88
  137750:	45 33 db             	xor    %r11d,%r11d
  137753:	4c 89 9c 24 d0 f2 00 	mov    %r11,0xf2d0(%rsp)
  13775a:	00 
  13775b:	48 33 db             	xor    %rbx,%rbx
  13775e:	48 89 9c 24 d8 f2 00 	mov    %rbx,0xf2d8(%rsp)
  137765:	00 
  137766:	c7 84 24 c0 01 00 00 	movl   $0x0,0x1c0(%rsp)
  13776d:	00 00 00 00 
  137771:	b8 05 00 00 00       	mov    $0x5,%eax
  137776:	48 89 84 24 18 f3 00 	mov    %rax,0xf318(%rsp)
  13777d:	00 
  13777e:	44 8b 8c 24 50 02 00 	mov    0x250(%rsp),%r9d
  137785:	00 
  137786:	45 85 c9             	test   %r9d,%r9d
  137789:	0f 84 fb 63 05 00    	je     0x18db8a
  13778f:	44 8b 84 24 50 02 00 	mov    0x250(%rsp),%r8d
  137796:	00 
  137797:	45 85 c0             	test   %r8d,%r8d
  13779a:	0f 84 ec 63 05 00    	je     0x18db8c
  1377a0:	8b 8c 24 50 02 00 00 	mov    0x250(%rsp),%ecx
  1377a7:	8b f9                	mov    %ecx,%edi
  1377a9:	48 8b 94 24 e0 03 00 	mov    0x3e0(%rsp),%rdx
  1377b0:	00 
  1377b1:	48 8b 72 08          	mov    0x8(%rdx),%rsi
  1377b5:	4c 8b 76 28          	mov    0x28(%rsi),%r14
  1377b9:	4c 8b a4 24 e0 03 00 	mov    0x3e0(%rsp),%r12
  1377c0:	00 
  1377c1:	4d 8b 7c 24 08       	mov    0x8(%r12),%r15
  1377c6:	4d 8b 57 20          	mov    0x20(%r15),%r10
  1377ca:	4d 8d 2c 3a          	lea    (%r10,%rdi,1),%r13
  1377ce:	4d 33 db             	xor    %r11,%r11
  1377d1:	49 3b fe             	cmp    %r14,%rdi
  1377d4:	48 8b bc 24 30 f3 00 	mov    0xf330(%rsp),%rdi
  1377db:	00 
  1377dc:	4d 0f 47 eb          	cmova  %r11,%r13
  1377e0:	41 8b 5d 10          	mov    0x10(%r13),%ebx
  1377e4:	48 8b 84 24 10 f3 00 	mov    0xf310(%rsp),%rax
  1377eb:	00 
  1377ec:	4c 8b 8c 24 10 f3 00 	mov    0xf310(%rsp),%r9
  1377f3:	00 
  1377f4:	41 85 c1             	test   %eax,%r9d
  1377f7:	4c 8b 8c 24 28 f3 00 	mov    0xf328(%rsp),%r9
  1377fe:	00 
  1377ff:	0f 84 89 63 05 00    	je     0x18db8e
  137805:	85 db                	test   %ebx,%ebx
  137807:	0f 84 83 63 05 00    	je     0x18db90
  13780d:	44 8b 84 24 48 02 00 	mov    0x248(%rsp),%r8d
  137814:	00 
  137815:	45 85 c0             	test   %r8d,%r8d
  137818:	4c 8b      	mov    0xf320(%rsp),%r8
  13781f:	 
