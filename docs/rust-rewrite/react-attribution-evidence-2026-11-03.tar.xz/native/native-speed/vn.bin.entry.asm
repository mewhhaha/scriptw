
target/react-native-attribution-20261103/native-speed/vn.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
       0:	55                   	push   %rbp
       1:	48 89 e5             	mov    %rsp,%rbp
       4:	4c 8b 57 08          	mov    0x8(%rdi),%r10
       8:	4d 8b 52 18          	mov    0x18(%r10),%r10
       c:	49 81 c2 10 1d 00 00 	add    $0x1d10,%r10
      13:	4c 3b d4             	cmp    %rsp,%r10
      16:	0f 87 45 e5 18 00    	ja     0x18e561
      1c:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
      23:	c7 04 24 00 00 00 00 	movl   $0x0,(%rsp)
      2a:	48 81 c4 00 10 00 00 	add    $0x1000,%rsp
      31:	48 81 ec 00 1d 00 00 	sub    $0x1d00,%rsp
      38:	48 89 9c 24 d0 1c 00 	mov    %rbx,0x1cd0(%rsp)
      3f:	00 
      40:	4c 89 a4 24 d8 1c 00 	mov    %r12,0x1cd8(%rsp)
      47:	00 
      48:	4c 89 ac 24 e0 1c 00 	mov    %r13,0x1ce0(%rsp)
      4f:	00 
      50:	4c 89 b4 24 e8 1c 00 	mov    %r14,0x1ce8(%rsp)
      57:	00 
      58:	4c 89 bc 24 f0 1c 00 	mov    %r15,0x1cf0(%rsp)
      5f:	00 
      60:	49 89 ce             	mov    %rcx,%r14
      63:	48 89 bc 24 e0 06 00 	mov    %rdi,0x6e0(%rsp)
      6a:	00 
      6b:	4c 89 84 24 e8 06 00 	mov    %r8,0x6e8(%rsp)
      72:	00 
      73:	4c 8b 7d 10          	mov    0x10(%rbp),%r15
      77:	4c 8b 45 18          	mov    0x18(%rbp),%r8
      7b:	4d 89 c5             	mov    %r8,%r13
      7e:	4c 8b 55 20          	mov    0x20(%rbp),%r10
      82:	4c 8b 65 28          	mov    0x28(%rbp),%r12
      86:	48 8b 75 30          	mov    0x30(%rbp),%rsi
      8a:	48 8b 4d 40          	mov    0x40(%rbp),%rcx
      8e:	89 94 24 70 06 00 00 	mov    %edx,0x670(%rsp)
      95:	44 89 8c 24 a8 05 00 	mov    %r9d,0x5a8(%rsp)
      9c:	00 
      9d:	44 89 94 24 d8 02 00 	mov    %r10d,0x2d8(%rsp)
      a4:	00 
      a5:	89 b4 24 98 02 00 00 	mov    %esi,0x298(%rsp)
      ac:	89 8c 24 80 03 00 00 	mov    %ecx,0x380(%rsp)
      b3:	c7 84 24 e0 01 00 00 	movl   $0x0,0x1e0(%rsp)
      ba:	00 00 00 00 
      be:	c7 84 24 20 04 00 00 	movl   $0x0,0x420(%rsp)
      c5:	00 00 00 00 
      c9:	c7 84 24 e0 03 00 00 	movl   $0x0,0x3e0(%rsp)
      d0:	00 00 00 00 
      d4:	c7 84 24 c0 02 00 00 	movl   $0x0,0x2c0(%rsp)
      db:	00 00 00 00 
      df:	c7 84 24 b0 01 00 00 	movl   $0x0,0x1b0(%rsp)
      e6:	00 00 00 00 
      ea:	c7 84 24 10 02 00 00 	movl   $0x0,0x210(%rsp)
      f1:	00 00 00 00 
      f5:	c7 84 24 90 02 00 00 	movl   $0x0,0x290(%rsp)
      fc:	00 00 00 00 
