set pagination off
set confirm off
set debuginfod enabled off
attach 1359512
python
exec(compile(open('/home/jacobt/src/scriptw/target/react-native-attribution-20261103/dump_payload.py').read(), "dump_payload.py", "exec"))
end
detach
quit
