
target/react-native-attribution-20261103/native-speed/ft.bin:     file format binary


Disassembly of section .data:

0000000000000000 <.data>:
       0:	55                   	push   %rbp
       1:	48 89 e5             	mov    %rsp,%rbp
       4:	4c 8b 57 08          	mov    0x8(%rdi),%r10
       8:	4d 8b 52 18          	mov    0x18(%r10),%r10
       c:	49 81 c2 40 13 00 00 	add    $0x1340,%r10
      13:	4c 3b d4             	cmp    %rsp,%r10
      16:	0f 87 17 e3 07 00    	ja     0x7e333
      1c:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
      23:	c7 04 24 00 00 00 00 	movl   $0x0,(%rsp)
      2a:	48 81 c4 00 10 00 00 	add    $0x1000,%rsp
      31:	48 81 ec 30 13 00 00 	sub    $0x1330,%rsp
      38:	48 89 9c 24 00 13 00 	mov    %rbx,0x1300(%rsp)
      3f:	00 
      40:	4c 89 a4 24 08 13 00 	mov    %r12,0x1308(%rsp)
      47:	00 
      48:	4c 89 ac 24 10 13 00 	mov    %r13,0x1310(%rsp)
      4f:	00 
      50:	4c 89 b4 24 18 13 00 	mov    %r14,0x1318(%rsp)
      57:	00 
      58:	4c 89 bc 24 20 13 00 	mov    %r15,0x1320(%rsp)
      5f:	00 
      60:	49 89 ce             	mov    %rcx,%r14
      63:	48 89 bc 24 d0 03 00 	mov    %rdi,0x3d0(%rsp)
      6a:	00 
      6b:	4c 89 84 24 d8 03 00 	mov    %r8,0x3d8(%rsp)
      72:	00 
      73:	4c 8b 7d 10          	mov    0x10(%rbp),%r15
      77:	4c 8b 45 18          	mov    0x18(%rbp),%r8
      7b:	4d 89 c5             	mov    %r8,%r13
      7e:	4c 8b 55 20          	mov    0x20(%rbp),%r10
      82:	4c 8b 65 28          	mov    0x28(%rbp),%r12
      86:	48 8b 75 30          	mov    0x30(%rbp),%rsi
      8a:	48 8b 4d 40          	mov    0x40(%rbp),%rcx
      8e:	89 94 24 70 02 00 00 	mov    %edx,0x270(%rsp)
      95:	44 89 4c 24 58       	mov    %r9d,0x58(%rsp)
      9a:	44 89 94 24 90 00 00 	mov    %r10d,0x90(%rsp)
      a1:	00 
      a2:	89 b4 24 d8 00 00 00 	mov    %esi,0xd8(%rsp)
      a9:	89 8c 24 e0 00 00 00 	mov    %ecx,0xe0(%rsp)
      b0:	c7 84 24 c0 00 00 00 	movl   $0x0,0xc0(%rsp)
      b7:	00 00 00 00 
      bb:	c7 84 24 d0 02 00 00 	movl   $0x0,0x2d0(%rsp)
      c2:	00 00 00 00 
      c6:	c7 84 24 b8 00 00 00 	movl   $0x0,0xb8(%rsp)
      cd:	00 00 00 00 
      d1:	c7 84 24 d8 01 00 00 	movl   $0x0,0x1d8(%rsp)
      d8:	00 00 00 00 
      dc:	c7 84 24 08 01 00 00 	movl   $0x0,0x108(%rsp)
      e3:	00 00 00 00 
      e7:	c7 84 24 38 02 00 00 	movl   $0x0,0x238(%rsp)
      ee:	00 00 00 00 
      f2:	c7 84 24 68 01 00 00 	movl   $0x0,0x168(%rsp)
      f9:	00 00 00 00 
      fd:	c7 84 24     	movl   $0x0,0x378(%rsp)
     104:	    
