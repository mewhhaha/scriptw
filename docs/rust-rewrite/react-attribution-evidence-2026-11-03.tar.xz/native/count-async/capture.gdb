set pagination off
set confirm off
set debuginfod enabled off
handle SIGSTOP stop print nopass
attach 1358588
python
exec(compile(open('/home/jacobt/src/scriptw/target/react-native-attribution-20261103/count_payload.py').read(), '/home/jacobt/src/scriptw/target/react-native-attribution-20261103/count_payload.py', "exec"), {"__file__": '/home/jacobt/src/scriptw/target/react-native-attribution-20261103/count_payload.py'})
end
detach
quit
