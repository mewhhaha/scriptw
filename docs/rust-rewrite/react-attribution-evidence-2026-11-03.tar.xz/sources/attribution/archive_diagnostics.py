#!/usr/bin/env python3
"""Package inert RSC PMU and native-attribution diagnostics as UTF-8 evidence."""
import argparse
import hashlib
import json
import mmap
from pathlib import Path
import sys
import tarfile

ROOT = Path(__file__).resolve().parents[2]
PERFORMANCE = ROOT / 'target/react-performance-20261103'
DIAGNOSTICS = PERFORMANCE / 'diagnostics'
NATIVE = ROOT / 'target/react-native-attribution-20261103'
FIXTURES = ROOT / 'target/application-benchmarks-20261102/generated-v2'
CURRENT_REPORT = ROOT / 'docs/rust-rewrite/rsc-current.json'
ORIGINAL_SOURCE = ROOT / 'crates/scriptw-cli/examples/rsc_baseline.rs'
ARCHIVE_LIMIT = 5 * 1024**2

sys.path.insert(0, str(PERFORMANCE))
from archive_final import Archive, json_bytes, need, sha


def add_source(archive, member, path, pins):
    path = Path(path)
    archive.add_file(member, path)
    pins.append(dict(path=member, source=str(path.relative_to(ROOT)), sha256=sha(path.read_bytes())))


def add_text_tree(archive, source, prefix, suffixes):
    source = Path(source)
    need(source.is_dir() and not source.is_symlink(), 'missing diagnostic directory: ' + str(source))
    for path in sorted(source.rglob('*')):
        if path.is_dir():
            need(not path.is_symlink(), 'symlink directory rejected: ' + str(path))
            continue
        need(path.is_file() and not path.is_symlink(), 'non-regular diagnostic file: ' + str(path))
        relative = path.relative_to(source)
        if any(part in {'__pycache__', 'native-capture'} for part in relative.parts):
            continue
        if path.name == 'samples.txt':
            if path.stat().st_size < 64 * 1024**2:
                archive.add_file(member_prefix(prefix, relative), path)
            continue
        if path.name == 'perf.data' or path.suffix.lower() not in suffixes:
            continue
        member = member_prefix(prefix, relative)
        if path.name == 'callchains.json':
            compact, reference = compact_callchains(path)
            compact_member = member.rsplit('/', 1)[0] + '/callchains-summary.json'
            archive.add_bytes(compact_member, json_bytes(compact))
            archive.add_bytes(compact_member.rsplit('/', 1)[0] + '/callchains-source-reference.json',
                              json_bytes(reference))
            continue
        if path.name == 'symbols.json':
            symbols = json.loads(path.read_text())
            need(symbols.get('unscored') is True and isinstance(symbols.get('top'), list),
                 'invalid unscored symbol summary: ' + str(path))
            compact = {key: symbols[key] for key in ('unscored', 'samples', 'period_sum', 'limits')
                       if key in symbols}
            compact['top'] = symbols['top'][:40]
            compact['omitted_owner_rows'] = max(0, len(symbols['top']) - len(compact['top']))
            archive.add_bytes(member, json_bytes(compact))
            continue
        archive.add_file(member, path)


def member_prefix(prefix, relative):
    return prefix.rstrip('/') + '/' + relative.as_posix()


def sha_file(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def scan_json_value(data, start):
    whitespace = b' \t\r\n'
    while data[start:start + 1] in whitespace:
        start += 1
    first = data[start]
    if first not in (ord('{'), ord('[')):
        if first == ord('"'):
            cursor = start + 1
            escaped = False
            while cursor < len(data):
                byte = data[cursor]
                if escaped:
                    escaped = False
                elif byte == ord('\\'):
                    escaped = True
                elif byte == ord('"'):
                    return start, cursor + 1
                cursor += 1
            raise ValueError('unterminated JSON string')
        cursor = start
        while cursor < len(data) and data[cursor] not in b',}] \t\r\n':
            cursor += 1
        return start, cursor

    stack = [first]
    cursor = start + 1
    in_string = False
    escaped = False
    while cursor < len(data):
        byte = data[cursor]
        if in_string:
            if escaped:
                escaped = False
            elif byte == ord('\\'):
                escaped = True
            elif byte == ord('"'):
                in_string = False
        elif byte == ord('"'):
            in_string = True
        elif byte in (ord('{'), ord('[')):
            stack.append(byte)
        elif byte in (ord('}'), ord(']')):
            expected = ord('{') if byte == ord('}') else ord('[')
            if not stack or stack.pop() != expected:
                raise ValueError('mismatched JSON delimiters')
            if not stack:
                return start, cursor + 1
        cursor += 1
    raise ValueError('unterminated JSON object or array')


def compact_callchains(path):
    summaries = {}
    rows = None
    with path.open('rb') as stream:
        with mmap.mmap(stream.fileno(), 0, access=mmap.ACCESS_READ) as data:
            cursor = 0
            while data[cursor:cursor + 1] in b' \t\r\n':
                cursor += 1
            need(data[cursor:cursor + 1] == b'{', 'callchain report must be a JSON object')
            cursor += 1
            while True:
                while data[cursor:cursor + 1] in b' \t\r\n':
                    cursor += 1
                if data[cursor:cursor + 1] == b'}':
                    break
                key_start, key_end = scan_json_value(data, cursor)
                key = json.loads(data[key_start:key_end])
                cursor = key_end
                while data[cursor:cursor + 1] in b' \t\r\n':
                    cursor += 1
                need(data[cursor:cursor + 1] == b':', 'invalid callchain JSON object')
                value_start, value_end = scan_json_value(data, cursor + 1)
                if key == 'rows':
                    rows = (value_start, value_end)
                else:
                    summaries[key] = json.loads(data[value_start:value_end])
                cursor = value_end
                while data[cursor:cursor + 1] in b' \t\r\n':
                    cursor += 1
                if data[cursor:cursor + 1] == b',':
                    cursor += 1
                    continue
                need(data[cursor:cursor + 1] == b'}', 'invalid callchain JSON object ending')
                break
            required = ('own', 'inclusive', 'chain_depth_histogram',
                        'unavailable_ip_or_callchain_samples', 'unavailable_ip_or_callchain_period_sum',
                        'helper_immediate_callers',
                        'top_leaf_to_root_chains')
            need(rows is not None and all(key in summaries for key in required),
                 'callchain summary fields or rows member missing')
            row_start, row_end = rows
            rows_hash = hashlib.sha256()
            for offset in range(row_start, row_end, 1024 * 1024):
                rows_hash.update(data[offset:min(offset + 1024 * 1024, row_end)])
            reference = dict(schema=summaries.get('schema'), source_path=str(path.relative_to(ROOT)),
                             source_sha256=sha_file(path), source_bytes=path.stat().st_size,
                             dropped_member='rows', dropped_member_sha256=rows_hash.hexdigest(),
                             dropped_member_bytes=row_end - row_start)
    need(summaries.get('unscored') is True, 'callchain report must remain marked unscored')
    return summaries, reference


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--report', type=Path, required=True,
                        help='final machine-readable report to preserve')
    parser.add_argument('--output', type=Path, required=True,
                        help='new, unique .tar.xz destination; existing paths are rejected')
    args = parser.parse_args()
    report_path = args.report.resolve(strict=True)
    output = args.output if args.output.is_absolute() else ROOT / args.output
    need(report_path != output.resolve(), 'report and output paths must differ')

    current = json.loads(CURRENT_REPORT.read_text())
    need(current.get('schema') == 'scriptw-rsc-current-v1', 'current RSC report schema differs')
    inputs = current.get('inputs')
    need(isinstance(inputs, dict) and inputs, 'current report has no pinned inputs')

    source_pins = []
    archive = Archive()
    archive.add_file('reports/final-report.json', report_path)
    archive.add_file('reports/current-rsc-report.json', CURRENT_REPORT)

    fixture_sources = {
        'fixtures/rsc.js': FIXTURES / 'rsc.js',
        'fixtures/support.json': FIXTURES / 'support.json',
        'sources/react-driver.cjs': ROOT / 'crates/scriptw-cli/tests/fixtures/edge_rendering/react-driver.cjs',
    }
    for member, path in fixture_sources.items():
        expected = inputs.get(str(path))
        need(isinstance(expected, str) and sha(path.read_bytes()) == expected,
             'pinned RSC input identity differs: ' + str(path))
        add_source(archive, member, path, source_pins)

    # Preserve the original source bytes from the hash-verified current archive.
    evidence = current.get('evidence_archive', {})
    evidence_path = ROOT / evidence.get('file', '')
    need(evidence_path.is_file() and evidence_path.stat().st_size == evidence.get('bytes')
         and sha(evidence_path.read_bytes()) == evidence.get('sha256'),
         'current RSC evidence archive does not match its report identity')
    with tarfile.open(evidence_path, 'r:xz') as old_archive:
        source_member = old_archive.extractfile('sources/rsc_baseline.rs')
        need(source_member is not None, 'current evidence archive lacks original RSC source')
        source_bytes = source_member.read()
    need(source_bytes == ORIGINAL_SOURCE.read_bytes(), 'original RSC source differs from archived source')
    archive.add_bytes('sources/rsc_baseline.rs', source_bytes)
    source_pins.append(dict(path='sources/rsc_baseline.rs', source='current-evidence-archive:sources/rsc_baseline.rs',
                            sha256=sha(source_bytes)))

    archive.add_bytes('reports/current-rsc-evidence-reference.json', json_bytes({
        'report_path': str(CURRENT_REPORT.relative_to(ROOT)),
        'report_sha256': sha(CURRENT_REPORT.read_bytes()),
        'archive_path': str(evidence_path.relative_to(ROOT)),
        'archive_sha256': evidence['sha256'],
        'archive_bytes': evidence['bytes'],
        'original_source_member': 'sources/rsc_baseline.rs',
        'original_source_sha256': sha(source_bytes),
    }))

    for path in sorted(DIAGNOSTICS.iterdir()):
        if path.is_file() and path.suffix.lower() in {'.py', '.cjs'}:
            add_source(archive, 'sources/performance-diagnostics/' + path.name, path, source_pins)
    helper_sources = (
        ROOT / 'target/performance-intrinsic-array-reads-v2-20261102/mixed_worker_samples.py',
        ROOT / 'scripts/limited_verification.py', ROOT / 'scripts/benchmark_metrics.py',
    )
    for path in helper_sources:
        add_source(archive, 'sources/helpers/' + path.name, path, source_pins)

    # All versioned PMU runs, including smoke/calibration and excluded Fast/FP variants.
    for folder in sorted(DIAGNOSTICS.glob('pmu-*')):
        if folder.is_dir():
            add_text_tree(archive, folder, 'pmu/' + folder.name,
                          {'.json', '.txt', '.stdout', '.stderr', '.log'})
    for name in ('pmu-adapter-versions.json', 'pmu-first7-vs100.json'):
        archive.add_file('pmu/' + name, DIAGNOSTICS / name)

    # Preserve failed and successful FP experiments, excluding native payload captures.
    for folder in sorted(DIAGNOSTICS.glob('fp-*')):
        if folder.is_dir():
            add_text_tree(archive, folder, 'fp/' + folder.name,
                          {'.json', '.txt', '.stdout', '.stderr', '.map', '.gdb', '.log'})

    for path in sorted(NATIVE.glob('*.py')):
        add_source(archive, 'sources/native-attribution/' + path.name, path, source_pins)
    for path in sorted(NATIVE.glob('*.json')):
        archive.add_file('native/' + path.name, path)
    add_source(archive, 'sources/prepare_report.py', Path(__file__).with_name('prepare_report.py'), source_pins)
    add_source(archive, 'sources/attribution/archive_diagnostics.py', Path(__file__).resolve(), source_pins)
    for name in ('count-sync', 'count-async', 'native-sync', 'native-speed'):
        folder = NATIVE / name
        if folder.is_dir():
            add_text_tree(archive, folder, 'native/' + name,
                          {'.json', '.asm', '.txt', '.stdout', '.stderr', '.map', '.gdb', '.log'})

    archive.add_bytes('reports/source-code-pins.json', json_bytes({
        'schema': 'scriptw-react-attribution-source-pins-v1',
        'sources': sorted(source_pins, key=lambda row: row['path']),
        'note': 'Only UTF-8 source and diagnostic text is archived. Executables, Wasm, raw perf data, and opaque native payloads are excluded.',
    }))
    archive.add_bytes('README.txt', (
        'Inert React Server Components PMU and native attribution diagnostics. '
        'PMU, FP, request-count, and native-capture records are unscored diagnostics. '
        'The original current RSC input report, checked fixture/support bytes, original source, '
        'and evidence archive SHA reference are included. FP callchain rows are omitted from a '
        'compact summary with the original rows SHA retained; samples.txt is kept when under 64 MiB. '
        'All members are UTF-8 text; executable '
        'bytes, Wasm, raw perf.data, and opaque native payloads are excluded.\n'
    ).encode())

    metadata = archive.write(output)
    metadata['over_5mb'] = metadata['bytes'] > ARCHIVE_LIMIT
    print(json.dumps(metadata, sort_keys=True))


if __name__ == '__main__':
    main()
