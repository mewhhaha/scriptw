"""Count two exact native stack probes during one checked, excluded Flight request."""
import argparse
import json
import os
from pathlib import Path
import signal
import socket
import subprocess
import time

from dump_rsc_native import ROOT, sha, allow_debugger, require_kernel_budget, limited_environment, line


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('output', type=Path)
    parser.add_argument('--mode', choices=['sync', 'async'], default='sync')
    args = parser.parse_args()
    require_kernel_budget(4 * 1024**3)
    assert len(os.sched_getaffinity(0)) == 1
    base = ROOT / 'target/react-performance-20261103/promoted'
    report = json.loads((base / 'candidate-fast-0.json').read_text())
    binary = base / 'frozen/rsc_baseline'
    source = Path(report['inputs']['source'])
    support = Path(report['inputs']['support'])
    assert sha(binary) == report['executable_sha256']
    assert sha(source) == report['inputs']['source_sha256']
    assert sha(support) == report['inputs']['support_sha256']
    out = args.output.resolve()
    out.mkdir(exist_ok=False)
    (out / 'tmp').mkdir()
    parent, child_socket = socket.socketpair()
    control_parent, control_child = socket.socketpair()
    nonce = os.urandom(16).hex()
    env = limited_environment()
    assert not any(k.startswith('SCRIPTW_RSC_PROFILE_') for k in env)
    env.update(TMPDIR=str(out / 'tmp'), SCRIPTW_RSC_PROFILE_FD=str(child_socket.fileno()),
               SCRIPTW_RSC_PROFILE_NONCE=nonce, SCRIPTW_RSC_PROFILE_MODE=args.mode)
    argv = [str(binary), str(source), str(support), str(out / 'observations.json'), '1', '3']
    result = dict(schema='scriptw-rsc-probe-count-receipt-v1', status='incomplete',
                  unscored=True, mode=args.mode, argv=argv,
                  expected_executable_sha256=report['executable_sha256'],
                  expected_program_sha256=report['program_wasm_sha256'],
                  limits='Exactly one Flight after 3 warmups; native setup outside count window. 20s debugger deadline and 30000 breakpoint-event ceiling. Counts are not timings or total heap allocations.')
    (out / 'plan.json').write_text(json.dumps(result, indent=2) + '\n')
    child = probe = None
    started = time.monotonic()
    try:
        with (out / 'host.stdout').open('xb') as stdout, (out / 'host.stderr').open('xb') as stderr, \
             (out / 'gdb.stdout').open('xb') as gout, (out / 'gdb.stderr').open('xb') as gerr:
            child = subprocess.Popen(argv, cwd=ROOT, env=env, stdout=stdout, stderr=stderr,
                                     stdin=subprocess.DEVNULL, pass_fds=(child_socket.fileno(),),
                                     preexec_fn=allow_debugger)
            child_socket.close()
            ready = f'SWRSC1 {nonce} ready {args.mode} 3\n'
            assert line(parent.fileno(), 60) == ready
            payload = Path(__file__).with_name('count_payload.py')
            script = ('set pagination off\nset confirm off\nset debuginfod enabled off\n'
                      'handle SIGSTOP stop print nopass\nattach ' + str(child.pid) + '\npython\n'
                      'exec(compile(open(' + repr(str(payload)) + ').read(), ' + repr(str(payload)) +
                      ', "exec"), {"__file__": ' + repr(str(payload)) + '})\nend\ndetach\nquit\n')
            (out / 'capture.gdb').write_text(script)
            probe = subprocess.Popen(['/usr/bin/timeout', '-k', '3', '20', '/usr/bin/gdb', '-q', '-nx',
                                      '-batch', '-x', str(out / 'capture.gdb')], cwd=ROOT,
                                     env=env | dict(SCRIPTW_COUNT_OUTPUT=str(out),
                                                    SCRIPTW_COUNT_CONTROL_FD=str(control_child.fileno())),
                                     stdout=gout, stderr=gerr, stdin=subprocess.DEVNULL,
                                     pass_fds=(control_child.fileno(),))
            control_child.close()
            assert line(control_parent.fileno(), 10) == 'ARMED\n'
            parent.sendall(ready.replace('SWRSC1', 'SWACK1', 1).encode())
            done = f'SWRSC1 {nonce} done {args.mode} 3\n'
            assert line(parent.fileno(), 20) == done
            (out / 'window-complete.json').write_text(json.dumps(dict(nonce=nonce, event=done)) + '\n')
            os.kill(child.pid, signal.SIGSTOP)
            assert probe.wait(timeout=5) == 0
            assert json.loads((out / 'counts.json').read_text())['status'] == 'counted'
            os.kill(child.pid, signal.SIGCONT)
            parent.sendall(done.replace('SWRSC1', 'SWACK1', 1).encode())
            assert child.wait(timeout=30) == 0
        observed = json.loads((out / 'observations.json').read_text())
        assert observed['program_wasm_sha256'] == report['program_wasm_sha256']
        assert observed['runtime'] == report['runtime']
        assert observed['configuration'] == report['configuration']
        assert observed['profiling']['windows'] == 1
        assert len(observed['cases']) == 1 and observed['cases'][0]['exact_node_output_checked']
        result.update(status='counted', elapsed_seconds=time.monotonic() - started,
                      source_fingerprint=observed['source_fingerprint'],
                      actual_program_sha256=observed['program_wasm_sha256'])
    except Exception as error:
        result.update(status='failed', error=repr(error))
        raise
    finally:
        if probe is not None and probe.poll() is None:
            probe.terminate()
            try:
                probe.wait(timeout=4)
            except subprocess.TimeoutExpired:
                probe.kill()
                probe.wait(timeout=3)
        if child is not None and child.poll() is None:
            child.kill()
            child.wait(timeout=5)
        for sock in [parent, child_socket, control_parent, control_child]:
            sock.close()
        result['files'] = {p.name: dict(bytes=p.stat().st_size, sha256=sha(p))
                           for p in out.iterdir() if p.is_file()}
        (out / 'receipt.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(dict(status=result['status'], output=str(out))))


if __name__ == '__main__':
    main()
