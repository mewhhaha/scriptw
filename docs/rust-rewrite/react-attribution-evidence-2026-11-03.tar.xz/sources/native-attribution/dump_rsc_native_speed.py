"""Speed/Backtracking native snapshot, same frozen binary/P/R and one excluded checked request."""
import argparse, ctypes, hashlib, json, os
from pathlib import Path
import socket, subprocess, sys, time
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'scripts'))
from limited_verification import require_kernel_budget, limited_environment
sys.path.insert(0,str(ROOT/'target/performance-intrinsic-array-reads-v2-20261102'))
from mixed_worker_samples import line

def sha(path):
    digest=hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(1024*1024),b''):digest.update(block)
    return digest.hexdigest()

def allow_debugger():
    # Only this excluded child opts into sibling GDB attachment under Yama.
    libc=ctypes.CDLL(None, use_errno=True)
    if libc.prctl(0x59616d61, ctypes.c_ulong(-1), 0, 0, 0) != 0:
        raise OSError(ctypes.get_errno(), 'PR_SET_PTRACER failed')

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('output',type=Path)
    parser.add_argument('--mode',choices=['sync','async'],default='sync')
    args=parser.parse_args()
    require_kernel_budget(4*1024**3)
    assert len(os.sched_getaffinity(0))==1
    base=ROOT/'target/react-performance-20261103/promoted'
    report=json.loads((base/'candidate-fast-0.json').read_text())
    binary=base/'frozen/rsc_baseline'
    assert sha(binary)==report['executable_sha256']
    source=Path(report['inputs']['source']);support=Path(report['inputs']['support'])
    assert sha(source)==report['inputs']['source_sha256']
    assert sha(support)==report['inputs']['support_sha256']
    out=args.output.resolve();out.mkdir(exist_ok=False);(out/'tmp').mkdir()
    parent,child_socket=socket.socketpair();nonce=os.urandom(16).hex()
    env=limited_environment();assert not any(k.startswith('SCRIPTW_RSC_PROFILE_') for k in env)
    env.update(TMPDIR=str(out/'tmp'),SCRIPTW_RSC_PROFILE_FD=str(child_socket.fileno()),SCRIPTW_RSC_PROFILE_NONCE=nonce,SCRIPTW_RSC_PROFILE_MODE=args.mode)
    argv=[str(binary),str(source),str(support),str(out/'observations.json'),'1','3','speed']
    result=dict(schema='scriptw-rsc-bounded-native-speed-capture-v1',status='incomplete',unscored=True,argv=argv,mode=args.mode,native_mode='speed',expected_executable_sha256=report['executable_sha256'],expected_program_sha256=report['program_wasm_sha256'],limits='No timing claims. Native compilation/setup and 3 warmups precede the ready barrier; GDB snapshot is excluded; one checked render follows. Speed/Backtracking is the only native configuration override. Do not rebase Fast sample offsets onto this image; only static native code/frame comparison is authorized.')
    (out/'plan.json').write_text(json.dumps(result,indent=2)+'\n')
    child=None;started=time.monotonic()
    try:
        with (out/'host.stdout').open('xb') as stdout,(out/'host.stderr').open('xb') as stderr:
            child=subprocess.Popen(argv,cwd=ROOT,env=env,stdout=stdout,stderr=stderr,stdin=subprocess.DEVNULL,pass_fds=(child_socket.fileno(),),preexec_fn=allow_debugger)
            child_socket.close()
            ready=f'SWRSC1 {nonce} ready {args.mode} 3\n'
            assert line(parent.fileno(),60)==ready
            script='set pagination off\nset confirm off\nset debuginfod enabled off\nattach '+str(child.pid)+'\npython\nexec(compile(open('+repr(str(Path(__file__).with_name('dump_payload.py')))+').read(), "dump_payload.py", "exec"))\nend\ndetach\nquit\n'
            (out/'capture.gdb').write_text(script)
            with (out/'gdb.stdout').open('xb') as gout,(out/'gdb.stderr').open('xb') as gerr:
                probe=subprocess.run(['/usr/bin/timeout','-k','3','20','/usr/bin/gdb','-q','-nx','-batch','-x',str(out/'capture.gdb')],cwd=ROOT,env=env|dict(SCRIPTW_DUMP_OUTPUT=str(out)),stdout=gout,stderr=gerr,stdin=subprocess.DEVNULL,timeout=25)
            assert probe.returncode==0,('gdb failed',probe.returncode)
            assert (out/'native.json').exists()
            parent.sendall(ready.replace('SWRSC1','SWACK1',1).encode())
            done=f'SWRSC1 {nonce} done {args.mode} 3\n'
            assert line(parent.fileno(),30)==done
            parent.sendall(done.replace('SWRSC1','SWACK1',1).encode())
            assert child.wait(timeout=30)==0
        observed=json.loads((out/'observations.json').read_text())
        assert observed['program_wasm_sha256']==report['program_wasm_sha256']
        assert observed['runtime']==report['runtime']
        expected_configuration=report['configuration']|dict(cranelift_opt_level='Speed',register_allocation='Backtracking')
        assert observed['configuration']==expected_configuration,(observed['configuration'],expected_configuration)
        assert observed['native_mode']=='speed'
        assert observed['program_wasm_bytes']==report['program_wasm_bytes']
        assert observed['profiling']['windows']==1
        assert len(observed['cases'])==1 and observed['cases'][0]['exact_node_output_checked']
        result.update(status='captured',elapsed_seconds=time.monotonic()-started,source_fingerprint=observed['source_fingerprint'],actual_program_sha256=observed['program_wasm_sha256'])
    except Exception as error:
        result.update(status='failed',error=repr(error));raise
    finally:
        if child is not None and child.poll() is None:child.kill();child.wait(timeout=5)
        parent.close();child_socket.close()
        result['files']={p.name:dict(bytes=p.stat().st_size,sha256=sha(p)) for p in out.iterdir() if p.is_file()}
        (out/'receipt.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(dict(status=result['status'],output=str(out))))
if __name__=='__main__':main()
