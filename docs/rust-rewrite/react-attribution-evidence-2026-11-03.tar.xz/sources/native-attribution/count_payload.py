"""GDB-only exact entries and completed native stack probes in one Flight window."""
import gdb
import hashlib
import json
import os
from pathlib import Path

out = Path(os.environ['SCRIPTW_COUNT_OUTPUT'])
control = int(os.environ['SCRIPTW_COUNT_CONTROL_FD'])
inferior = gdb.selected_inferior()
pid = inferior.pid
reference = Path(__file__).parent / 'native-sync'
expected = json.loads((reference / 'native.json').read_text())
names = {}
perf = Path(f'/tmp/perf-{pid}.map').read_text()
(out / 'perf.map').write_text(perf)
for line in perf.splitlines():
    address, size, name = line.split(maxsplit=2)
    names.setdefault(name, set()).add((int(address, 16), int(size, 16)))

result = dict(schema='scriptw-exact-native-probe-counts-v1', status='armed',
              pid=pid, functions=[], total_breakpoint_events=0,
              limits='Excluded debugger run, not timing. Entry and completed-probe counts only; page touches are repeated stack writes, not unique pages or heap allocations.')
breakpoints = []

class Count(gdb.Breakpoint):
    def __init__(self, address, row, field):
        super().__init__(f'*{address:#x}', internal=True)
        self.row = row
        self.field = field

    def stop(self):
        self.row[self.field] += 1
        result['total_breakpoint_events'] += 1
        if result['total_breakpoint_events'] > 30000:
            result['status'] = 'breakpoint-budget-exceeded'
            return True
        return False

for label, name, pages, frame in [('vn', 'js::vn#f133', 247, 1011584),
                                ('ft', 'js::ft#f123', 83, 339840)]:
    entries = names[name]
    assert len(entries) == 1, (name, entries)
    address, size = next(iter(entries))
    old = next(row for row in expected['functions'] if row['name'] == name)
    assert size == old['bytes'], (name, size, old['bytes'])
    prefix = bytes(inferior.read_memory(address, 0x54))
    old_prefix = (reference / old['file']).read_bytes()[:0x54]
    assert prefix == old_prefix, (name, prefix.hex(), old_prefix.hex())
    assert int.from_bytes(prefix[0x2b:0x2f], 'little') == pages * 4096
    assert int.from_bytes(prefix[0x50:0x54], 'little') == frame
    row = dict(name=name, address=address, native_bytes=size,
               verified_native_prefix_sha256=hashlib.sha256(prefix).hexdigest(),
               entry_offset=0, postprobe_offset=0x4d, stack_frame_bytes=frame,
               page_size=4096, probe_pages_per_completed_entry=pages,
               entry_count=0, completed_probe_count=0)
    result['functions'].append(row)
    breakpoints.extend([Count(address, row, 'entry_count'),
                        Count(address + 0x4d, row, 'completed_probe_count')])

(out / 'counts-armed.json').write_text(json.dumps(result, indent=2) + '\n')
os.write(control, b'ARMED\n')
gdb.execute('continue')
for bp in breakpoints:
    bp.delete()
assert result['status'] == 'armed', result['status']
assert (out / 'window-complete.json').exists(), 'inferior stopped before done barrier'
for row in result['functions']:
    assert row['entry_count'] == row['completed_probe_count'], row
    row['executed_probe_page_writes'] = row['completed_probe_count'] * row['probe_pages_per_completed_entry']
    row['executed_probe_instructions'] = row['completed_probe_count'] * (4 * row['probe_pages_per_completed_entry'] + 3)
result['status'] = 'counted'
(out / 'counts.json').write_text(json.dumps(result, indent=2) + '\n')
print('exact stack probe count complete', flush=True)
