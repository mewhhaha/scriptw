"""Resolve bounded hot call sites against exact encoded R descriptor rows."""
from pathlib import Path
import struct,json,hashlib
base=Path(__file__).parent
build=Path('target/release/build/scriptw-runtime-image-8a4ab4bcb736f6f7/out')
meta=(build/'scriptw-runtime-portable-metadata.bin').read_bytes()
assert meta[:8]==b'SCRWRM02';assert hashlib.sha256(meta[:-32]).digest()==meta[-32:]
start,size=struct.unpack_from('<QQ',meta,117);digest=meta[133:165].hex()
assert digest=='f31e565ee65c6d56d550af54e3671d94acfacfb529f676f46427a9167b907a61'
cursor=229;n=struct.unpack_from('<I',meta,cursor)[0];cursor+=4+n+32
static_len,utf16_len,count=struct.unpack_from('<QQI',meta,cursor)
pkg=(build/'scriptw-runtime-portable-package.bin').read_bytes();raw=pkg[start:start+size]
assert hashlib.sha256(raw).hexdigest()==digest

def leb(blob,pos,signed=False):
 value=shift=0
 while True:
  byte=blob[pos];pos+=1;value|=(byte&127)<<shift;shift+=7
  if byte<128:break
  assert shift<=70
 if signed and byte&64:value-=1<<shift
 return value,pos

def data(blob):
 pos=8;result=[]
 while pos<len(blob):
  kind=blob[pos];length,pos=leb(blob,pos+1);end=pos+length
  if kind==11:
   n,c=leb(blob,pos)
   for _ in range(n):
    flag,c=leb(blob,c);address=None
    if flag==0:
     assert blob[c]==0x41;address,c=leb(blob,c+1,True);assert blob[c]==0x0b;c+=1
    else:assert flag==1
    length,c=leb(blob,c);result.append((address,blob[c:c+length]));c+=length
   assert c==end
  pos=end
 return result
rs=data(raw);utf16=rs[0][1];assert len(utf16)==utf16_len
rows=rs[-1][1][-16*count:]
assert len(rows)==16*count
strings={}
for i in range(count):
 h,offset,units=struct.unpack_from('<QII',rows,i*16)
 text=utf16[offset:offset+units*2];assert offset%2==0 and len(text)==units*2
 check=14695981039346656037
 for (unit,) in struct.iter_unpack('<H',text):check=((check^unit)*1099511628211)&((1<<64)-1)
 assert check==h,(i,offset,units)
 strings[i]=text.decode('utf-16-le','surrogatepass')
p=Path('target/react-performance-20261103/promoted/size/program.wasm').read_bytes()
ps=data(p)
pstrings={i:ps[0][1][offset:offset+length*2].decode('utf-16-le','surrogatepass') for i,offset,length in struct.iter_unpack('<III',ps[2][1])}
r=json.loads((base/'environment-callers.json').read_text())
for row in r['top_source_return_sites']:
 at=row['wasm_call_position'];matches=[]
 for pos in range(max(0,at-160),at):
  if p[pos]!=0x41:continue
  try:
   value,c=leb(p,pos+1,True)
   if p[c]!=0x21:continue
   local,c=leb(p,c+1)
   if p[c]!=0x20:continue
   load,c=leb(p,c+1)
   if load!=local or p[c]!=0x10:continue
   target,c=leb(p,c+1)
   if target!=117 or p[c]!=0x21 or value not in strings:continue
   keylocal,c=leb(p,c+1)
   matches.append(dict(literal_offset=pos,runtime_literal_ordinal=value,text=strings[value],pooled_resolve_import=target,key_local=keylocal))
  except (IndexError,AssertionError):continue
 if len(matches)==1:row['runtime_key']=matches[0]
 else:row['key_candidates']=matches
 if not matches:
  pmatches=[]
  for pos in range(max(0,at-100),at):
   if p[pos]!=0x41:continue
   try:
    value,c=leb(p,pos+1,True)
    if value not in pstrings or p[c]!=0x21:continue
    local,c=leb(p,c+1)
    if p[c]!=0x20:continue
    table,c=leb(p,c+1)
    if p[c:c+2]!=bytes([0xd4,0x20]):continue
    load,c=leb(p,c+2)
    if load!=local or p[c:c+2]!=bytes([0xfb,0x0b]):continue
    typ,c=leb(p,c+2)
    if typ!=150:continue
    pmatches.append(dict(literal_offset=pos,program_literal_ordinal=value,text=pstrings[value],pooled_string_array_type=typ))
   except (IndexError,AssertionError):continue
  if len(pmatches)==1:row['program_key']=pmatches[0]
  else:row['program_key_candidates']=pmatches
r['runtime_pool_evidence']=dict(package=str(build/'scriptw-runtime-portable-package.bin'),raw_wasm_sha256=digest,raw_wasm_bytes=size,string_count=count,descriptor_rows='Last16*count bytes of final R data segment; every UTF16 FNV hash and span checked.',callsite_match='Within160 bytes before exact helper call: i32.const ordinal;local.set k;local.get k;call117;local.set key. Single exact candidate retained; ambiguous/missing remains explicit.')
(base/'environment-callers.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps([dict(name=x['owner'],weight=x['period_sum'],wasm=x['wasm_call_position'],key=x.get('runtime_key',x.get('program_key',x.get('key_candidates')))) for x in r['top_source_return_sites']],indent=2))
