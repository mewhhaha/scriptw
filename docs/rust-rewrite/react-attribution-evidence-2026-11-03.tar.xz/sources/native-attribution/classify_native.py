"""Rebase retained native samples; decode exact Wasmtime 47 instruction maps."""
from pathlib import Path
import argparse,bisect,collections,hashlib,json,struct,subprocess
ROOT=Path(__file__).resolve().parents[2]
BLOCK=128

class AddressMap:
    def __init__(self,path):
        self.raw=path.read_bytes()
        self.entries,self.blocks=struct.unpack_from('<II',self.raw)
        assert self.blocks==(self.entries+BLOCK-1)//BLOCK
        self.index=[struct.unpack_from('<II',self.raw,8+i*8) for i in range(self.blocks)]
        self.starts=[row[0] for row in self.index]
        assert self.starts==sorted(self.starts)
        self.body_start=8+self.blocks*8
        self.cache={}
    def leb(self,pos,signed=False):
        value=shift=0
        while True:
            byte=self.raw[pos];pos+=1;value|=(byte&127)<<shift;shift+=7
            if byte<128:break
            assert shift<=35
        if signed and byte&64:value-=1<<shift
        return value,pos
    def block(self,index):
        if index in self.cache:return self.cache[index]
        pc,offset=self.index[index];cursor=self.body_start+offset;previous=None;rows=[]
        for _ in range(min(BLOCK,self.entries-index*BLOCK)):
            token,cursor=self.leb(cursor);pc+=token>>1;source=None
            if not token&1:
                delta,cursor=self.leb(cursor,previous is not None)
                source=delta if previous is None else previous+delta
                assert 0<=source<2**32
                previous=source
            rows.append((pc,source))
        self.cache[index]=rows
        return rows
    def lookup_entry(self,pc):
        block=bisect.bisect_right(self.starts,pc)-1
        if block<0:return (0,None)
        rows=self.block(block)
        at=bisect.bisect_right([x[0] for x in rows],pc)-1
        assert at>=0
        return rows[at]
    def lookup(self,pc):
        return self.lookup_entry(pc)[1]

def leb(raw,pos):
    value=shift=0
    while True:
        byte=raw[pos];pos+=1;value|=(byte&127)<<shift
        if byte<128:return value,pos
        shift+=7
        assert shift<35

SIMPLE={0x02:'block',0x03:'loop',0x04:'if',0x05:'else',0x0b:'end',0x0c:'br',0x0d:'br_if',0x0e:'br_table',0x0f:'return',0x10:'call',0x11:'call_indirect',0x12:'return_call',0x14:'call_ref',0x1a:'drop',0x20:'local.get',0x21:'local.set',0x22:'local.tee',0x23:'global.get',0x24:'global.set',0x41:'i32.const',0x42:'i64.const',0x43:'f32.const',0x44:'f64.const',0xd0:'ref.null',0xd1:'ref.is_null',0xd2:'ref.func',0xd3:'ref.eq',0xd4:'ref.as_non_null'}
GC={0:'struct.new',1:'struct.new_default',2:'struct.get',3:'struct.get_s',4:'struct.get_u',5:'struct.set',6:'array.new',7:'array.new_default',8:'array.new_fixed',9:'array.new_data',10:'array.new_elem',11:'array.get',12:'array.get_s',13:'array.get_u',14:'array.set',15:'array.len',16:'array.fill',17:'array.copy',18:'array.init_data',19:'array.init_elem',20:'ref.test',21:'ref.test_nullable',22:'ref.cast',23:'ref.cast_nullable',24:'br_on_cast',25:'br_on_cast_fail',26:'any.convert_extern',27:'extern.convert_any',28:'ref.i31',29:'i31.get_s',30:'i31.get_u'}
def operation(raw,pos):
    if pos is None:return 'no-wasm-source',{}
    assert pos<len(raw)
    byte=raw[pos];extra={}
    if byte==0xfb:
        sub,cursor=leb(raw,pos+1);name=GC.get(sub,'gc.'+str(sub))
        if sub<=14:
            extra['type_index'],cursor=leb(raw,cursor)
            if sub in [2,3,4,5]:extra['field_index'],cursor=leb(raw,cursor)
        return name,extra
    name=SIMPLE.get(byte,'opcode.0x'+format(byte,'02x'))
    if byte in [0x10,0x12]:extra['function_index'],_=leb(raw,pos+1)
    return name,extra

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('capture',type=Path);p.add_argument('--disassemble',action='store_true');a=p.parse_args()
    folder=a.capture.resolve();native=json.loads((folder/'native.json').read_text())
    receipt=json.loads((folder/'receipt.json').read_text());assert receipt['status']=='captured'
    base=ROOT/'target/react-performance-20261103/promoted'
    wasm=(base/'size/program.wasm').read_bytes();assert hashlib.sha256(wasm).hexdigest()==receipt['actual_program_sha256']
    bodies={r['name']:r for r in json.loads((base/'size/functions.json').read_text())}
    text=next(r for r in native['sections'] if r['name']=='.text')
    mapping=AddressMap(folder/'wasmtime.addrmap.bin')
    report=dict(schema='scriptw-rsc-native-instruction-attribution-v1',program_sha256=receipt['actual_program_sha256'],native_text_bytes=text['bytes'],address_map_entries=mapping.entries,functions=[],limits=['Samples come from the retained final 100-render profiles; counts are not wall-time shares or allocations.','Each profile is rebased by exact function-relative offsets. Frozen binary, P, runtime, native configuration and native function lengths must match. Departed profile process bytes were not retained, so cross-process native byte identity cannot be checked directly.','Wasm source offsets come from the exact live compiled image address map. no-wasm-source is not synonymous with a JavaScript prologue. No prologue/body boundary is inferred from a fixed percentage.'])
    for fn in native['functions']:
        body=bodies[fn['name']];row=dict(name=fn['name'],wasm_body_bytes=body['bytes'],native_bytes=fn['bytes'],native_per_wasm_byte=fn['bytes']/body['bytes'],native_sha256=fn['sha256'],profiles={})
        native_start=fn['address']-(native['image_base']+text['file_offset'])
        for mode in ['sync','async']:
            prof=base/('profile-'+mode)
            oldperf=[]
            for line in (prof/'perf.map').read_text().splitlines():
                address,size,name=line.split(maxsplit=2)
                if name==fn['name']:oldperf.append((int(address,16),int(size,16)))
            assert len(set(oldperf))==1;old_address,old_size=oldperf[0];assert old_size==fn['bytes']
            obs=json.loads((prof/'observations.json').read_text());assert obs['program_wasm_sha256']==receipt['actual_program_sha256']
            original=json.loads((prof/'symbols.json').read_text())
            counts=collections.Counter();hot=collections.Counter();bins=[0]*64;classified=[]
            for item in original['rows']:
                ip=int(item['ip'],16)
                if not old_address<=ip<old_address+old_size:continue
                relative=ip-old_address;source=mapping.lookup(native_start+relative)
                if source is not None:assert body['start']<=source<body['start']+body['bytes'],(fn['name'],source,body)
                op,extra=operation(wasm,source)
                counts[op]+=1;hot[(source,op,tuple(extra.items()))]+=1
                bins[min(63,relative*64//old_size)]+=1
                classified.append(dict(native_offset=relative,wasm_offset=source,operation=op,**extra))
            data=dict(samples=len(classified),fraction_of_all_profile_samples=len(classified)/original['samples'],native_equal_width_bins=bins,operations=counts.most_common(),hot_wasm_locations=[dict(wasm_offset=k[0],operation=k[1],samples=v,**dict(k[2])) for k,v in hot.most_common(24)])
            row['profiles'][mode]=data
            (folder/(fn['file']+'.'+mode+'.samples.json')).write_text(json.dumps(classified,separators=(',',':'))+'\n')
        if a.disassemble:
            # Native entry plus the four hottest bins; bounded 512-byte excerpts.
            bins=row['profiles']['sync']['native_equal_width_bins'];selected=sorted(range(64),key=lambda i:bins[i],reverse=True)[:4]
            ranges=[('entry',0)]+[('hot-'+str(i),max(0,mapping.lookup_entry(native_start+i*fn['bytes']//64)[0]-native_start)) for i in selected]
            for label,start in ranges:
                cmd=['objdump','-D','-b','binary','-m','i386:x86-64','--start-address='+str(start),'--stop-address='+str(min(start+512,fn['bytes'])),str(folder/fn['file'])]
                result=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=10,check=True)
                assert len(result.stdout)<128*1024
                (folder/(fn['file']+'.'+label+'.asm')).write_bytes(result.stdout)
        report['functions'].append(row)
    (folder/'attribution.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))
if __name__=='__main__':main()
