"""Executed only inside GDB attached to the retained worker at its ready barrier."""
import gdb
import hashlib
import json
import pathlib
import os
import struct

out = pathlib.Path(os.environ['SCRIPTW_DUMP_OUTPUT'])
pid = gdb.selected_inferior().pid
inferior = gdb.selected_inferior()
rows = []
for line in pathlib.Path(f'/proc/{pid}/maps').read_text().splitlines():
    parts = line.split(maxsplit=5)
    start, end = [int(x, 16) for x in parts[0].split('-')]
    rows.append(dict(start=start, end=end, permissions=parts[1], offset=int(parts[2],16), path=parts[5] if len(parts)>5 else ''))
perf = pathlib.Path(f'/tmp/perf-{pid}.map').read_text()
(out/'perf.map').write_text(perf)
(out/'maps.txt').write_text(pathlib.Path(f'/proc/{pid}/maps').read_text())
names = {}
for line in perf.splitlines():
    address, size, name = line.split(maxsplit=2)
    names.setdefault(name, []).append((int(address,16),int(size,16)))
selected = [('vn','js::vn#f133'),('ft','js::ft#f123')]
functions=[]
for label,name in selected:
    entries=set(names[name]); assert len(entries)==1,(name,entries)
    address,size=entries.pop()
    assert 0<size<=8*1024**2,(name,size)
    raw=bytes(inferior.read_memory(address,size))
    filename=label+'.bin'; (out/filename).write_bytes(raw)
    functions.append(dict(name=name,address=address,bytes=size,file=filename,sha256=hashlib.sha256(raw).hexdigest()))
address=functions[0]['address']
code=next(row for row in rows if row['start']<=address<row['end'] and 'x' in row['permissions'])
headers=[row for row in rows if row['end']==code['start'] and row['permissions'].startswith('r--')]
assert len(headers)==1,headers
base=headers[0]['start']
header=bytes(inferior.read_memory(base,64))
assert header[:6]==b'\x7fELF\x02\x01',header[:16].hex()
assert struct.unpack_from('<H',header,18)[0]==62,'require x86_64'
shoff=struct.unpack_from('<Q',header,40)[0]
shsize,count,string_index=struct.unpack_from('<HHH',header,58)
assert shsize==64 and 0<count<100
assert shoff+count*shsize<192*1024**2
raw_headers=bytes(inferior.read_memory(base+shoff,count*shsize))
string_header=raw_headers[string_index*shsize:(string_index+1)*shsize]
string_offset,string_size=struct.unpack_from('<QQ',string_header,24)
assert string_size<1024*1024
strings=bytes(inferior.read_memory(base+string_offset,string_size))
sections=[]
for index in range(count):
    sh=raw_headers[index*shsize:(index+1)*shsize]
    name_offset=struct.unpack_from('<I',sh)[0]
    name=strings[name_offset:].split(b'\0')[0].decode()
    virtual,offset,size=struct.unpack_from('<QQQ',sh,16)
    section=dict(name=name,virtual_address=virtual,file_offset=offset,bytes=size)
    if name in ['.wasmtime.addrmap','.symtab','.strtab']:
        assert size<=32*1024**2,(name,size)
        raw=bytes(inferior.read_memory(base+offset,size))
        filename=name[1:]+'.bin';(out/filename).write_bytes(raw)
        section.update(file=filename,sha256=hashlib.sha256(raw).hexdigest())
    sections.append(section)
assert any(row['name']=='.wasmtime.addrmap' and row['bytes'] for row in sections)
text=next(row for row in sections if row['name']=='.text')
assert base+text['file_offset']==code['start'],(base,text,code)
result=dict(schema='scriptw-rsc-live-native-dump-v1',pid=pid,image_base=base,code_mapping=code,functions=functions,sections=sections,limits='Read-only process memory snapshot at checked ready barrier; no full native image dump. Selected function bytes and address map only.')
(out/'native.json').write_text(json.dumps(result,indent=2)+'\n')
print('bounded P native capture complete',flush=True)
