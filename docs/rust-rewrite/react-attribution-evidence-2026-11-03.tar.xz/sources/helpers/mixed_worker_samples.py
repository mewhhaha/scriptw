"""Three pinned candidate worker windows; diagnostic only, never scored timings."""
import hashlib
import json
import os
from pathlib import Path
import select
import signal
import socket
import subprocess
import sys
import time

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from limited_verification import kernel_group, require_kernel_budget, limited_environment
from mixed_symbolize_samples import prepare_catalog

FROZEN = OUT / "diagnostic"
OLD = ROOT / "target/performance-shared-worker-20261101"
DEST = OUT / "mixed-worker-samples"
PHASES = ["after_transport_drop", "after_instantiate", "after_execution", "after_store_drop"]
FIELDS = ["memory.max", "memory.swap.max", "memory.oom.group", "cpu.max", "memory.events"]


def load(path):
    return json.loads(path.read_text())


def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for part in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(part)
    return h.hexdigest()


def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")


def line(fd, timeout=15):
    result = b""
    deadline = time.monotonic() + timeout
    while not result.endswith(b"\n"):
        remaining = deadline - time.monotonic()
        if remaining <= 0 or not select.select([fd], [], [], remaining)[0]:
            raise RuntimeError("bounded control read timed out")
        byte = os.read(fd, 1)
        if not byte or len(result) >= 256:
            raise RuntimeError("invalid or closed control stream")
        result += byte
    return result.decode("ascii")


def thread_record(pid, tid):
    task = Path(f"/proc/{pid}/task/{tid}")
    stat = (task / "stat").read_text()
    return {"tid": tid, "comm": (task / "comm").read_text().strip(), "stat": stat,
            "starttime_ticks": int(stat[stat.rfind(")") + 2:].split()[19]),
            "status": (task / "status").read_text()}


def perf_ack(fd, result):
    # Some perf builds write the C string terminator after the documented line.
    # The first line reader leaves that terminator before the following ACK.
    raw = line(fd)
    result["events"].append({"kind": "perf_ack_raw", "hex": raw.encode().hex(), "monotonic_ns": time.monotonic_ns()})
    assert raw in ("ack\n", "\0ack\n"), repr(raw)


def run_one(number, plan, identity, image, probe):
    case = plan["case"]
    index = plan["selected_absolute_observation"]
    folder = DEST / f"{number}-{case}-index{index}"
    folder.mkdir()
    before = {name: (kernel_group() / name).read_text() for name in FIELDS}
    parent_socket, child_socket = socket.socketpair()
    nonce = os.urandom(16).hex()
    env = limited_environment()
    for key in env:
        assert not key.startswith("SCRIPTW_PRECOMPILED_PHASE_")
    assert "LD_PRELOAD" not in env and "LD_AUDIT" not in env
    assert "SCRIPTW_PERF_MAP_DIR" not in env
    assert "SCRIPTW_PRECOMPILED_EXECUTION_WINDOWS" not in env
    env.update(SCRIPTW_PRECOMPILED_PHASE_FD=str(child_socket.fileno()),
               SCRIPTW_PRECOMPILED_PHASE_NONCE=nonce, SCRIPTW_PRECOMPILED_PHASE_INDEX=str(index),
               TMPDIR=str(DEST / "tmp"),
               SCRIPTW_CACHE_DIR=str(DEST / "cache"), SCRIPTW_CACHE_LIMIT_BYTES=str(1024**3),
               SCRIPTW_MODULE_MEMORY_CACHE_ENTRIES="1", SCRIPTW_MODULE_MEMORY_CACHE_LIMIT_BYTES=str(64*1024**2))
    argv = [str(FROZEN / "candidate/compiler_precompiled_baseline"), "execute-scriptw",
            str(FROZEN / "prepared-scriptw" / image["image"]), image["stdout"], str(plan["samples"]), str(plan["warmups"])]
    result = {"case": case, "folder": folder.name, "selected_observation": index, "argv": argv, "resources_before": before,
              "phase_environment": {key: value for key, value in env.items() if key.startswith("SCRIPTW_PRECOMPILED_")},
              "tmpdir": env["TMPDIR"],
              "events": [], "status": "incomplete"}
    child = perf = None
    pipe_fds = []
    try:
        with (folder / "host.stdout").open("xb") as stdout, (folder / "host.stderr").open("xb") as stderr, \
             (folder / "perf.stdout").open("xb") as perf_stdout, (folder / "perf.stderr").open("xb") as perf_stderr:
            child = subprocess.Popen(argv, cwd=ROOT, env=env, stdin=subprocess.DEVNULL,
                                     stdout=stdout, stderr=stderr, pass_fds=(child_socket.fileno(),))
            child_socket.close()
            result["pid"] = child.pid
            for sequence, phase in enumerate(PHASES, 1):
                event = line(parent_socket.fileno(), 25)
                expected = f"SWPHASE1 {nonce} {sequence} {phase} {index}\n"
                assert event == expected, (event, expected)
                result["events"].append({"kind": "host_phase", "value": event, "monotonic_ns": time.monotonic_ns()})
                if phase == "after_instantiate":
                    tasks = [thread_record(child.pid, int(path.name)) for path in Path(f"/proc/{child.pid}/task").iterdir()]
                    result["tasks_before"] = tasks
                    (folder / "maps.txt").write_text(Path(f"/proc/{child.pid}/maps").read_text())
                    workers = [task for task in tasks if task["comm"] == "scriptw-execution"[:15]]
                    assert len(workers) == 1, "exactly one actual persistent execution worker required"
                    worker = workers[0]
                    assert worker["tid"] != child.pid
                    ctl_r, ctl_w = os.pipe()
                    ack_r, ack_w = os.pipe()
                    pipe_fds += [ctl_r, ctl_w, ack_r, ack_w]
                    perf_env = limited_environment()
                    perf_env["TMPDIR"] = str(DEST / "tmp")
                    perf_env["LD_LIBRARY_PATH"] = str(ROOT / probe["unpacked_libdir"])
                    perf_argv = [str(ROOT / probe["unpacked_executable"]), "record", "--no-buildid",
                                 "-e", plan["event"], "-c", str(plan["period"]), "-t", str(worker["tid"]),
                                 "--delay=-1", f"--control=fd:{ctl_r},{ack_w}",
                                 "-o", str(folder / "perf.data")]
                    result["perf_argv"] = perf_argv
                    perf = subprocess.Popen(perf_argv, cwd=ROOT, env=perf_env, stdin=subprocess.DEVNULL,
                                            stdout=perf_stdout, stderr=perf_stderr, pass_fds=(ctl_r, ack_w))
                    os.write(ctl_w, b"enable\n")
                    perf_ack(ack_r, result)
                    result["events"].append({"kind": "perf_enabled_ack", "monotonic_ns": time.monotonic_ns()})
                if phase == "after_execution":
                    os.write(ctl_w, b"disable\n")
                    perf_ack(ack_r, result)
                    result["events"].append({"kind": "perf_disabled_ack", "monotonic_ns": time.monotonic_ns()})
                    after_thread = thread_record(child.pid, worker["tid"])
                    assert after_thread["starttime_ticks"] == worker["starttime_ticks"]
                    result["worker_after"] = after_thread
                    (folder / "maps-after.txt").write_text(Path(f"/proc/{child.pid}/maps").read_text())
                    perf.send_signal(signal.SIGINT)
                    result["perf_exit_code"] = perf.wait(timeout=5)
                    assert result["perf_exit_code"] in (0, -signal.SIGINT)
                parent_socket.sendall(expected.replace("SWPHASE1", "SWACK1", 1).encode())
                result["events"].append({"kind": "host_ack", "phase": phase, "monotonic_ns": time.monotonic_ns()})
            result["host_exit_code"] = child.wait(timeout=30)
        assert result["host_exit_code"] == 0
        assert (folder / "host.stderr").read_bytes() == b""
        report = load(folder / "host.stdout")
        assert report["source_fingerprint"] == identity["source_fingerprint"]
        assert report["executable_sha256"] == identity["executable_sha256"]
        assert report["image_sha256"] == image["image_sha256"]
        assert report["program_wasm_sha256"] == plan["program_wasm_sha256"]
        assert report["runtime_key"] == plan["runtime_key"]
        assert report["shared_configuration"] == identity["shared_configuration"]
        assert report["compiler_enabled"] is False and report["excluded_from_scored_cohorts"] is True
        assert report["phase_barriers"]["completed_phases"] == PHASES
        assert report["phase_barriers"]["nonce"] == nonce
        assert report["phase_barriers"]["observation_index"] == index
        assert report["samples"] == plan["samples"] and report["warmups"] == plan["warmups"]
        assert len(report["observations"]) == plan["samples"] + plan["warmups"]
        for observation in report["observations"]:
            assert observation["stdout"] == image["stdout"] and observation["matched"]
            assert observation["execution_thread_cpu"]["status"] == "sampled"
            assert observation["execution_thread_cpu"]["scope"] == "execution-worker-thread"
        result["selected_raw_observation"] = report["observations"][index]
        assert result["selected_raw_observation"]["index"] == index
        assert result["selected_raw_observation"]["warmup"] is False
        script_argv = [str(ROOT / probe["unpacked_executable"]), "script", "-i", str(folder / "perf.data"), "-F", "ip,period,dso,sym"]
        with (folder / "samples.txt").open("xb") as sample_out, (folder / "samples.stderr").open("xb") as sample_err:
            parsed = subprocess.run(script_argv, stdout=sample_out, stderr=sample_err, env=perf_env, timeout=10)
        result["script_exit_code"] = parsed.returncode
        assert parsed.returncode == 0
        result["samples"] = (folder / "samples.txt").read_text()
        result["status"] = "captured"
    except Exception as error:
        result["status"] = "failed"
        result["error"] = repr(error)
    finally:
        for process in (perf, child):
            if process is not None and process.poll() is None:
                process.kill()
                process.wait(timeout=5)
        parent_socket.close()
        child_socket.close()
        for fd in pipe_fds:
            os.close(fd)
        result["resources_after"] = {name: (kernel_group() / name).read_text() for name in FIELDS}
        result["raw_files"] = {path.name: {"sha256": digest(path), "bytes": path.stat().st_size}
                               for path in folder.iterdir() if path.is_file()}
        save(folder / "receipt.json", result)
    print(json.dumps({key: result[key] for key in ("case", "selected_observation", "status")}), flush=True)
    assert result["status"] == "captured", result.get("error")
    return result


def main():
    require_kernel_budget(4 * 1024**3)
    assert len(os.sched_getaffinity(0)) == 1, "worker samples require one CPU"
    plan_path = OUT / "mixed-profile-plan.json"
    plan = load(plan_path)
    assert plan["status"] == "predeclared-unscored"
    assert plan["processes"] == 3 and plan["selected_absolute_observation"] == 10
    assert plan["samples"] == 21 and plan["warmups"] == 10
    assert plan["event"] == "cycles:u" and plan["period"] == 10000
    identity = load(FROZEN / "candidate/identity.json")
    images = load(FROZEN / "images.json")["images"]["scriptw"]
    image = images[plan["case"]]
    probe = load(OLD / "tools/perf-probe/perf-probe.json")
    assert digest(FROZEN / "candidate/identity.json") == plan["candidate_identity_sha256"]
    assert digest(FROZEN / "images.json") == plan["producer_receipt_sha256"]
    assert identity["source_fingerprint"] == plan["source_fingerprint"]
    assert identity["executable_sha256"] == plan["host_sha256"]
    assert digest(FROZEN / "candidate/compiler_precompiled_baseline") == plan["host_sha256"]
    assert digest(OLD / "tools/perf-probe/perf-probe.json") == plan["perf_probe_sha256"]
    assert digest(ROOT / probe["unpacked_executable"]) == plan["perf_executable_sha256"] == probe["unpacked_executable_sha256"]
    assert image["image_sha256"] == plan["image_sha256"]
    assert image["program_wasm_sha256"] == plan["program_wasm_sha256"]
    assert image["runtime_key"] == plan["runtime_key"] and image["stdout"] == plan["stdout"]
    DEST.mkdir(exist_ok=False)
    (DEST / "tmp").mkdir()
    os.environ["TMPDIR"] = str(DEST / "tmp")
    prepare_catalog(plan, image)
    plan.update(plan_source_sha256=digest(plan_path),
                sampler_sha256=digest(Path(__file__)),
                symbolizer_sha256=digest(OUT / "mixed_symbolize_samples.py"),
                native_symbols_sha256=digest(DEST / "native-symbols.json"),
                cpu_affinity=sorted(os.sched_getaffinity(0)))
    save(DEST / "plan.json", plan)
    rows = [run_one(number, plan, identity, image, probe) for number in range(plan["processes"])]
    save(DEST / "receipt.json", {"status": "complete", "unscored": True, "processes": len(rows),
                                "records": rows, "limits": plan["limits"], "scope": plan["scope"]})


if __name__ == "__main__":
    main()
