from pathlib import Path
import collections, hashlib, json, statistics
ROOT=Path(__file__).resolve().parents[2]
BASE=Path(__file__).resolve().parent
DIAG=ROOT/'target/react-performance-20261103/diagnostics'
NATIVE=ROOT/'target/react-native-attribution-20261103'
def read(path):return json.loads(path.read_text())
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def pmu(tag):
    folder=DIAG/tag;r=read(folder/'receipt.json')
    assert r['status']=='captured' and len(r['windows'])==100
    assert min(w['running_fraction'] for w in r['windows'])==1
    rows=r['windows']
    total={event:sum(w['raw_counts'][event] for w in rows) for event in rows[0]['raw_counts']}
    result=dict(archive_prefix='pmu/'+tag+'/',receipt_sha256=sha(folder/'receipt.json'),
        raw_median_counts={event:statistics.median(w['raw_counts'][event] for w in rows) for event in total},
        raw_total_counts=total,instructions_per_cycle=total['instructions:u']/total['cycles:u'],
        branch_miss_fraction=total['branch-misses:u']/total['branches:u'],
        minimum_running_fraction=1.0,requests=100,warmups=3,
        first_seven_median_counts={event:statistics.median(w['raw_counts'][event] for w in rows[:7]) for event in total})
    return result
pmus={tag:pmu('pmu-'+tag) for tag in ('node-sync','node-async','scriptw-sync','scriptw-async','scriptw-speed-sync','scriptw-speed-async','node-empty-calibration')}
fp_folder=DIAG/'fp-sync-v2';fp=read(fp_folder/'callchains.json');reanalysis=read(fp_folder/'reanalysis-v3-receipt.json')
assert reanalysis['status']=='reanalyzed'
eq=env=0;source_callers=collections.Counter()
for row in fp['rows']:
    chain=row['resolved_chain']
    if row['leaf']['owner']!='wasm:helper::string_equality':continue
    eq+=row['period']
    if len(chain)>1 and chain[1]['owner']=='wasm:helper::environment_identifier_resolve':
        env+=row['period']
        caller=next((x['owner'] for x in chain[2:] if x['owner'].startswith('wasm:js::')),'<no JS caller>')
        source_callers[caller]+=row['period']
assert eq>0 and env>0
profiles={}
for mode in ('sync','async'):
    folder=ROOT/'target/react-performance-20261103/promoted'/('profile-'+mode)
    raw=read(folder/'symbols.json');categories=collections.Counter()
    for row in raw['top']:
        name=row['owner'];category='host-or-unresolved'
        if name=='<zero IP>':category='zero-IP'
        elif name.startswith('wasm:js::'):category='compiled-JavaScript-bodies'
        elif name.startswith('wasm:helper::'):category='Wasm-runtime-helpers'
        elif name.startswith('wasm:builtin::'):category='Wasm-builtins'
        elif name.startswith('wasm:'):category='other-Wasm'
        categories[category]+=row['period_sum']
    profiles[mode]=dict(samples=raw['samples'],period_sum=raw['period_sum'],
        categories=[dict(category=k,period_sum=v,sample_share=v/raw['period_sum']) for k,v in categories.items()],
        receipt_sha256=sha(folder/'receipt.json'))
current=read(ROOT/'docs/rust-rewrite/rsc-current.json')
counts={mode:read(NATIVE/('count-'+mode)/'counts.json') for mode in ('sync','async')}
assert all(row['status']=='counted' and all(f['entry_count']==f['completed_probe_count'] for f in row['functions']) for row in counts.values())
identity=current['engines']['candidate']['identity']
report=dict(schema='scriptw-react-attribution-current-v1',date='2026-11-03',
    current_timing_report='rsc-current.json',current_timing_report_sha256=sha(ROOT/'docs/rust-rewrite/rsc-current.json'),
    source_fingerprint=identity['source_fingerprint'],executable_sha256=identity['executable_sha256'],
    program_wasm_sha256=identity['program_wasm_sha256'],runtime=identity['runtime'],
    status='completed diagnostic scope; product/compiler bytes unchanged',
    pmu=dict(policy='100 checked renders after 3 warmups, one fresh process per engine/mode/policy; user-only hardware group; zero multiplexing.',
             runs=pmus,calibration='Node empty-window calibration measures protocol edges only after 3 real warmups. It is not a render. Its counts are not subtracted.',
             limits='Targets Scriptw execution TID versus Node main TID; excludes other/background threads. Node protocol edges are included, Scriptw coordinator edges excluded. Natural JIT/GC across100 requests differs from the published7-request timing cohort; separate-mode processes also differ from its sync-then-async order. No new timing ratio is claimed.'),
    sampled_locations=profiles,
    sync_caller_profile=dict(samples=fp['samples'],period_sum=fp['period_sum'],
        archive_prefix='fp/fp-sync-v2/',reanalysis_receipt_sha256=sha(fp_folder/'reanalysis-v3-receipt.json'),
        own=fp['own'][:40],helper_immediate_callers=fp['helper_immediate_callers'],
        string_equality_leaf_period_sum=eq,
        string_equality_with_environment_resolver_immediate_caller_period_sum=env,
        environment_fraction_of_string_equality_leaf_samples=env/eq,
        environment_fraction_of_all_samples=env/fp['period_sum'],
        environment_source_callers=[dict(owner=k,period_sum=v,fraction_of_all_samples=v/fp['period_sum']) for k,v in source_callers.most_common()],
        limits=fp['limits']),
    exact_stack_probes=counts,
    resolved_global_reference_sites=read(NATIVE/'environment-callers.json'),
    native_configuration_comparison=read(NATIVE/'native-mode-comparison.json'),
    source_interpretation=read(NATIVE/'architecture-findings.json'),
    conclusions=[
       'Instruction volume is the primary observed gap: about159-167M retired instructions per Fast request versus2.5-2.6M Node across100 requests; higher Scriptw aggregate IPC and lower branch-miss rate do not support branch prediction as the main explanation.',
       'Repeated variable-name resolution is a measured hotspot: about92percent of sampled StringEquality leaf weight has EnvironmentIdentifierResolve as the immediate physical caller; most of that work originates in React vn.',
       'Fast code generation creates excessive spill frames and page probes. These are real costs but the two exact probe loops are only about0.22percent of retired instructions and5-6percent of sampled locations, so they cannot explain the entire surplus.',
       'Speed/Backtracking shrinks native frames/code substantially while removing only about5.3percent of retired instructions; backend policy alone leaves the main semantic-work problem.',
       'All22 dominant vn sites resolve global or optional-global constructor names but begin at the current lexical environment. Next work should prove global-start resolution and reuse the existing live global lookup path rather than scanning irrelevant scopes. Total heap and arguments-object allocation counts remain unmeasured.'
    ],
    verification=dict(PMU_actual_outputs_checked=True,native_capture_outputs_checked=True,
       exact_probe_outputs_checked=True,primary_timing_cohort_unchanged=True,
       product_Rust_sources_unchanged=True,new_product_native_builds=0),
    limitations=[
       'No claim that total allocation counts or the entire V8 gap have been causally partitioned.',
       'Instruction-location sample shares are not wall-time or allocation percentages. Inclusive caller weights overlap; leaf own weights do not.',
       'Original flat profiles retain zero/unresolved samples. Frame-pointer chains can truncate or be invalid; empty records retain their full weight with an explicit unavailable owner.',
       'FP run1 failed kernel-callchain admission; user-only run2 completed requests but exposed an empty-record parser issue. Preserved raw data was reanalyzed without rerunning the workload; all original failed receipts remain.',
       'Native Fast/Speed comparison changes optimization and register allocation together, not an allocator-only isolation. Exact native frame byte partition is unmeasured.',
       'No compiler change, full CI or full pinned Test262 rerun in this diagnostic/presentation batch.'
    ])
(BASE/'report-core.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print('Validated PMU, exact probes, native layouts and caller-profile core report')
