"""Reparse completed FP capture only; never run the workload or alter old receipts."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
sys.path.insert(0,str(ROOT/'scripts'))
from limited_verification import require_kernel_budget

def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda:stream.read(1024*1024),b''):
            h.update(chunk)
    return h.hexdigest()

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('capture',type=Path)
    args = parser.parse_args()
    require_kernel_budget(4*1024**3)
    folder = args.capture.resolve(strict=True)
    original = folder/'receipt.json'
    receipt = json.loads(original.read_text())
    assert receipt['status'] == 'failed'
    assert 'Sample header has no leaf' in receipt['error']
    assert receipt['host_exit_code'] == 0 and receipt['perf_exit_code'] in (0,-2)
    assert receipt['samples'] == 100 and receipt['warmups'] == 3
    assert digest(HERE/'profile_rsc_fp.v2.py') == receipt['sampler_sha256']
    assert digest(HERE/'symbolize_fp.v2.py') == receipt['symbolizer_sha256']
    for name,expected in receipt['raw_files'].items():
        assert (folder/name).stat().st_size == expected['bytes'],name
        assert digest(folder/name) == expected['sha256'],name
    observed = json.loads((folder/'observations.json').read_text())
    assert observed['profiling']['windows'] == 100
    assert observed['profiling']['excluded_from_scored_cohorts'] is True
    assert len(observed['cases']) == 1
    case = observed['cases'][0]
    assert case['case'] == 'rsc-'+receipt['mode']
    assert case['exact_node_output_checked'] is True
    assert len(case['observations']) == 103
    assert case['samples'] == 100 and case['warmups'] == 3
    assert sum(not o['warmup'] for o in case['observations']) == 100
    version = HERE/'symbolize_fp.v3.py'
    spec = importlib.util.spec_from_file_location('scriptw_fp_symbolizer_v3',version)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    assert not (folder/'callchains.json').exists(), 'refuse to overwrite existing parsed evidence'
    module.symbolize(folder)
    # Parsing completion is a new receipt; the original failed analysis remains.
    with (folder/'reanalysis-v3-receipt.json').open('x') as stream:
        json.dump({'schema':'scriptw-rsc-fp-reanalysis-v3','status':'reanalyzed','unscored':True,
                   'workload_rerun':False,'original_capture_receipt_sha256':digest(original),
                   'original_capture_status':receipt['status'],'original_analysis_error':receipt['error'],
                   'host_exit_code':receipt['host_exit_code'],'perf_exit_code':receipt['perf_exit_code'],
                   'checked_measured_flight_windows':100,'checked_genuine_flight_warmups':3,
                   'parser_sha256':digest(version),'reanalysis_script_sha256':digest(Path(__file__)),
                   'callchains_json_sha256':digest(folder/'callchains.json'),
                   'limits':'Analysis repair only. Empty period-only samples retained with null IP and explicit unavailable owner; their full sample mass remains in the denominator. Original failed analysis receipt and all recorded raw files unchanged.'},stream,indent=2)
        stream.write('\n')
    print(json.dumps({'status':'reanalyzed','output':str(folder/'callchains.json')}))

if __name__ == '__main__':
    main()
