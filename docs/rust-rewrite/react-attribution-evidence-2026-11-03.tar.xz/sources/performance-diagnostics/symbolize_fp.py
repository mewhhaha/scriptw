"""Resolve retained perf frame-pointer callchains with this process's perf.map."""
import bisect
import collections
import json
from pathlib import Path
import re
import sys

def symbolize(folder):
    folder = Path(folder)
    groups = collections.defaultdict(set)
    for row in (folder/'perf.map').read_text().splitlines():
        address,length,name = row.split(maxsplit=2)
        groups[(int(address,16),int(length,16))].add(name)
    symbols = sorted((address,size,sorted(names)) for (address,size),names in groups.items())
    assert symbols
    assert all(a[0]+a[1] <= b[0] for a,b in zip(symbols,symbols[1:]))
    starts = [symbol[0] for symbol in symbols]
    def resolve(ip, raw, caller=False):
        address = ip
        if caller and ip:
            address -= 1 # callchain return PCs can lie at a symbol boundary
        owner = 'host-or-unresolved:'+raw
        if not ip:
            owner = '<zero IP>'
        index = bisect.bisect_right(starts,address)-1
        if index >= 0:
            start,size,names = symbols[index]
            if start <= address < start+size:
                owner = 'wasm:'+' | '.join(names)
        return {'ip':hex(ip),'owner':owner,'raw':raw}
    samples = []
    current = None
    unexpected = []
    for lineno,row in enumerate((folder/'samples.txt').read_text().splitlines(),1):
        if not row.strip():
            continue
        header = re.fullmatch(r'\s*(\d+)\s+([0-9a-fA-F]+)\s+(.+)',row)
        if header:
            period,ip,raw = int(header[1]),int(header[2],16),header[3]
            current = {'period':period,'leaf':resolve(ip,raw),'frames':[],'line':lineno}
            samples.append(current)
            continue
        period_only = re.fullmatch(r'\s*(\d+)\s*',row)
        if period_only:
            # perf can move all IP/symbol fields into the callchain rows.
            current = {'period':int(period_only[1]),'leaf':None,'frames':[],'line':lineno}
            samples.append(current)
            continue
        frame = re.fullmatch(r'\s*([0-9a-fA-F]+)\s+(.+)',row)
        if frame and current is not None:
            ip,raw = int(frame[1],16),frame[2]
            if current['leaf'] is None:
                current['leaf'] = resolve(ip,raw)
            # perf may repeat the sampled leaf as the first callchain row.
            if not current['frames'] and ip == int(current['leaf']['ip'],16):
                current['frames'].append(resolve(ip,raw))
            else:
                current['frames'].append(resolve(ip,raw,caller=True))
            continue
        unexpected.append({'line':lineno,'raw':row})
    if unexpected:
        (folder/'unparsed-fp-lines.json').write_text(json.dumps(unexpected,indent=2)+'\n')
        raise AssertionError('Unexpected perf FP text format; raw samples preserved, inspect unparsed-fp-lines.json')
    own,inclusive = collections.Counter(),collections.Counter()
    immediate = collections.defaultdict(collections.Counter)
    chains = collections.Counter()
    depth = collections.Counter()
    for sample in samples:
        period = sample['period']
        leaf = sample['leaf']
        assert leaf is not None, ('Sample header has no leaf',sample['line'])
        frames = sample['frames']
        chain = [leaf]
        if frames and frames[0]['ip'] == leaf['ip']:
            frames = frames[1:]
        chain.extend(frames)
        sample['resolved_chain'] = chain
        own[leaf['owner']] += period
        depth[len(chain)] += 1
        chains[tuple(frame['owner'] for frame in chain[:12])] += period
        for owner in set(frame['owner'] for frame in chain):
            inclusive[owner] += period
        # One owner/caller pair per sample prevents recursive duplicate mass.
        pairs = set()
        for index,frame in enumerate(chain):
            owner = frame['owner']
            if owner.startswith('wasm:helper::'):
                caller = '<unwound caller unavailable>'
                if index+1 < len(chain):
                    caller = chain[index+1]['owner']
                pairs.add((owner,caller))
        for owner,caller in pairs:
            immediate[owner][caller] += period
    total = sum(own.values())
    assert total > 0 and any(sample['frames'] for sample in samples), 'No FP callchains parsed'
    table = lambda counts:[{'owner':owner,'period_sum':count,'sample_share':count/total} for owner,count in counts.most_common()]
    result = {'schema':'scriptw-rsc-fp-callchains-v1','unscored':True,'samples':len(samples),'period_sum':total,
              'limits':'User-cycle sample weights, never wall-time shares or exact call counts. Own samples are disjoint; inclusive owners overlap. Frame-pointer chains can truncate or be invalid, and missing callers remain explicit. Caller return PCs resolve at IP-1. No silent cross-process rebasing.',
              'own':table(own),'inclusive':table(inclusive),'chain_depth_histogram':dict(depth),
              'helper_immediate_callers':{owner:table(counts) for owner,counts in sorted(immediate.items())},
              'top_leaf_to_root_chains':[{'owners':list(chain),'period_sum':count,'sample_share':count/total} for chain,count in chains.most_common(100)],
              'rows':samples}
    (folder/'callchains.json').write_text(json.dumps(result,indent=2)+'\n')

if __name__ == '__main__':
    symbolize(Path(sys.argv[1]))
