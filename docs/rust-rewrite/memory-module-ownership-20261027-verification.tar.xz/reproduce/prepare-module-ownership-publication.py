"""Prepare private JSON/Markdown/inert-archive publication candidates, never publish.

Run only after review, under CPU0 <=1 GiB/noSwap/groupedOOM. No compilation,
native payload inspection/execution, network access, README edit or graph edit.
The exact terminal archive-only checkpoint is required before output creation.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import lzma
import os
from pathlib import Path
import stat
import subprocess
import sys
import tarfile
import time

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
SOURCE = 'aacf3283ca1fd0b2dd47e7bd1aea6230bf140a1a'
FEATURE = '06289f6c22d686ffbe69e7165869af0fdfcda813'
MEASURED = 'c79ab683848b6baf32adc528d144ea88a02a0fa0'
RUN = 40594118953
FP = '59bfb33612b5eadff0b32dbb703d876df230655b8e9f1a789a52274a9a63be92'
LOCAL_FP = '05961dd70907c0998e039d1b0f19b05f0d1aba61e1e08f08e0a2ed7f2b929cf9'
STEM = 'memory-module-ownership-20261027'
TERMINAL = BASE / 'archive-only-main-aacf3283'
TERMINAL_SHA = '0753925d6797c6e4586d7c48dee30ae89964e998e99b90119ab205bc1300576d'
VALIDATED = BASE / 'ci-40594118953-validated/report.json'
VALIDATED_SHA = 'e9adacac16834bfc409a827180cf40c73cf951868defabdf04fa3bd0b4d7f678'
CI = BASE / 'github-40594118953'
SCORED = CI / 'precompiled-measurements/precompiled-evidence/report.json'
DIAGNOSTIC = CI / 'precompiled-mapping-diagnostic-unscored'
WORKTREE = ROOT / 'target/memory-module-ownership-20261027'
MAX_MEMBER, MAX_EXPANDED, MAX_COMPRESSED = 64*1024**2, 512*1024**2, 96*1024**2
sys.path.insert(0, str(ROOT / 'scripts'))
from limited_verification import require_kernel_budget, kernel_group


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def regular(path, cap=MAX_MEMBER):
    path = Path(path)
    assert stat.S_ISREG(path.lstat().st_mode) and not path.is_symlink() and path.stat().st_size <= cap
    with path.open('rb') as stream:
        assert not stream.read(8).startswith((b'\x7fELF', b'MZ', b'SWRTZ001', b'SCRWRB', b'SCRWEP', b'SCRWWA'))
    return path


def read(path, cap=MAX_MEMBER):
    return json.loads(regular(path, cap).read_text())


def budget(group):
    return {key:(group/key).read_text().strip() for key in
            ('memory.max', 'memory.swap.max', 'memory.oom.group', 'memory.peak', 'memory.events')}


def no_oom(before, after):
    for sample in (before, after):
        assert sample['memory.swap.max'] == '0' and sample['memory.oom.group'] == '1'
    events = [dict(line.split() for line in sample['memory.events'].splitlines()) for sample in (before, after)]
    assert all(events[0][key] == events[1][key] == '0' for key in ('oom', 'oom_kill', 'oom_group_kill'))


def source():
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == SOURCE
    assert not subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=no'], cwd=ROOT)


def admit():
    assert sha(TERMINAL / 'report.json') == TERMINAL_SHA
    terminal = read(TERMINAL / 'report.json')
    assert terminal['complete'] is True and terminal['source_commit'] == SOURCE
    assert terminal['original_completed_commands'] == 9 and terminal['remaining_completed_commands'] == 14
    assert terminal['inherited_pinned_unique_executions'] == 6307 and terminal['test262_rerun'] is False
    assert terminal['actual_wasm_bytes_unchanged'] is True and terminal['serialized_native_bytes_unchanged'] is False
    assert terminal['native_bytes_unchanged_except_exact_compatibility_stamp'] is True
    assert terminal['default_enabled_native_bytes_identical'] is True
    assert terminal['continuation_driver_provenance']['executed_driver_sha256'] is None
    assert terminal['archive']['native_payloads_retained'] is False
    assert terminal['archive']['roundtrip_hashes_verified'] is True
    assert sha(TERMINAL / terminal['archive']['path']) == terminal['archive']['sha256']
    no_oom(terminal['before'], terminal['after'])
    assert sha(VALIDATED) == VALIDATED_SHA
    validated = read(VALIDATED)
    assert validated['complete'] is True and validated['run'] == RUN
    assert validated['source_commit'] == MEASURED and validated['feature_source_commit'] == FEATURE
    assert validated['source_fingerprint'] == FP and validated['scored_admitted'] is True
    assert validated['scored_all_attempts_ok'] is True
    assert validated['scored_attempts'] == 68 and validated['scored_workloads'] == 17
    assert validated['diagnostic']['status'] == 'validated' and len(validated['diagnostic']['cases']) == 4
    assert validated['diagnostic']['scored'] is False and validated['diagnostic']['scored_admission_affected'] is False
    no_oom(validated['before'], validated['after'])
    for name, row in validated['inputs'].items():
        path = regular(name)
        assert path.stat().st_size == row['bytes'] and sha(path) == row['sha256']
    for name, row in validated['validator_sources'].items():
        path = WORKTREE / 'scripts' / name
        assert row['source_commit'] == FEATURE and sha(path) == row['sha256']
        assert path.read_bytes() == subprocess.check_output(['git', 'show', FEATURE + ':scripts/' + name], cwd=ROOT)
    tool = WORKTREE / 'scripts/precompiled_comparison.py'
    spec = importlib.util.spec_from_file_location('ownership_publication_precompiled_comparison', tool)
    p = importlib.util.module_from_spec(spec); spec.loader.exec_module(p)
    campaign, table = p.load_report(SCORED)
    assert campaign['source_commit'] == MEASURED and campaign['source_fingerprint'] == FP
    assert campaign['tools']['consumer']['cargo_producer']['features'] == ['benchmark-module-images']
    assert len(campaign['attempts']) == 68 and all(row['status'] == 'ok' for row in campaign['attempts'])
    assert len(table) == 17 and table == validated['scored_table']
    run = read(BASE / ('github-run-' + str(RUN) + '.json'))
    assert run['databaseId'] == RUN and run['headSha'] == MEASURED
    assert run['status'] == 'completed' and run['conclusion'] == 'success'
    bindings = read(BASE / 'source-bindings-main-aacf3283-equivalence.json')
    assert bindings['compiler_inputs_equal'] is True
    assert (bindings['main_source'], bindings['feature_source'], bindings['probe_source']) == (SOURCE, FEATURE, MEASURED)
    for revision in (SOURCE, FEATURE, MEASURED):
        for local, fp in ((False, FP), (True, LOCAL_FP)):
            rows = [row for row in bindings['rows'] if row['revision'] == revision and row['extra_ignored_regress_lock'] is local]
            assert len(rows) == 1 and rows[0]['source_fingerprint'] == fp
    previous_path = ROOT / 'docs/rust-rewrite/memory-regexp-backtrack-20261027.json'
    previous = read(previous_path)
    assert previous['verified_source_commit'] == '9001324dc52ce583e7b95a1292f317796d415c01'
    assert previous['unique_selected_executions'] == 6307
    previous_archive = previous_path.parent / previous['archive']['file']
    assert sha(previous_archive) == previous['archive']['sha256']
    return terminal, validated, campaign, table, run, previous_path, previous


def archive(out, terminal, campaign_retained, start):
    """Repack local inert members once; retain each CI/raw stream only once."""
    files = {}
    def add(name, path):
        assert name not in files and not name.startswith('/') and '..' not in Path(name).parts
        path = regular(path)
        files[name] = dict(path=name, source=path, bytes=path.stat().st_size, sha256=sha(path))
    for row in campaign_retained:
        add('ci/scored/' + row['path'], SCORED.parent / row['path'])
    add('ci/scored/report.json', SCORED)
    for path in sorted(DIAGNOSTIC.rglob('*')):
        if path.is_file():
            add('ci/diagnostic/' + path.relative_to(DIAGNOSTIC).as_posix(), path)
    history = ['github-run-40594118953.json', 'github-artifacts-40594118953.json',
        'ci-dispatch-40594118953.json', 'ci-40594118953-validated/summary.md', 'validate-ci-40594118953.py',
        'source-bindings-main-aacf3283.json', 'source-bindings-main-aacf3283.py',
        'source-bindings-main-aacf3283-equivalence.json', 'source-bindings-ci-long-symbol.py',
        'source-bindings-ci-long-symbol-equivalence.json', 'ci-cancellation-40587639394.json',
        'github-run-40587639394-before-cancellation.json', 'github-run-40587639394-cancelled.json',
        'github-run-40588588589.json', 'ci-40588588589-validated/report.json',
        'ci-40588588589-validated/summary.md', 'inspect-host-symbol-names.py',
        'elf-symbol-name-stats.json', 'elf-symbol-name-stats.stderr', 'elf-symbol-name-stats.sandbox-failure.stderr',
        'run-symbol-name-controls.py', 'symbol-name-controls.json', 'symbol-name-controls.stderr',
        'main-aacf3283-journal.stdout', 'main-aacf3283-journal.stderr', 'finish-main-aacf3283-archive.py']
    for name in history:
        add('lineage/' + name, BASE / name)
    add('verification/archive-only-completion.json', TERMINAL / 'report.json')
    add('reproduce/prepare-module-ownership-publication.py', Path(__file__).resolve())
    add('reference/memory-regexp-backtrack-20261027.json', ROOT / 'docs/rust-rewrite/memory-regexp-backtrack-20261027.json')
    for name in ('precompiled_comparison.py', 'benchmark_module_images.py', 'diagnose-precompiled-mappings.py',
                 'limited_verification.py', 'native_test_protocol.py'):
        add('reproduce/scripts/' + name, WORKTREE / 'scripts' / name)
    local = {'verification/' + row['path']:dict(row, path='verification/' + row['path']) for row in terminal['archive']['members']}
    assert not set(files).intersection(local)
    assert len(local) + len(files) <= 4096
    total = sum(row['bytes'] for row in local.values()) + sum(row['bytes'] for row in files.values())
    assert total <= MAX_EXPANDED
    result = out / (STEM + '-verification.tar.xz')
    with result.open('xb') as raw, lzma.LZMAFile(raw, 'w', filters=[dict(id=lzma.FILTER_LZMA2, preset=1, dict_size=16*1024**2)]) as compressed:
        with tarfile.open(fileobj=compressed, mode='w|') as output:
            seen = set()
            with tarfile.open(TERMINAL / terminal['archive']['path'], 'r|xz') as bundle:
                for member in bundle:
                    name = 'verification/' + member.name
                    assert member.isfile() and name in local and name not in seen and member.size == local[name]['bytes'] <= MAX_MEMBER
                    target = tarfile.TarInfo(name); target.size = member.size; target.mode = 0o644
                    with bundle.extractfile(member) as payload:
                        output.addfile(target, payload)
                    seen.add(name)
                    assert time.monotonic()-start <= 1800
            assert seen == set(local)
            for name, row in sorted(files.items()):
                member = tarfile.TarInfo(name); member.size = row['bytes']; member.mode = 0o644
                with row['source'].open('rb') as payload:
                    output.addfile(member, payload)
                assert time.monotonic()-start <= 1800
    assert result.stat().st_size <= MAX_COMPRESSED
    expected = dict(local, **{name:{k:v for k,v in row.items() if k != 'source'} for name,row in files.items()})
    seen, expanded = set(), 0
    with tarfile.open(result, 'r|xz') as bundle:
        for member in bundle:
            assert member.isfile() and member.name in expected and member.name not in seen
            row = expected[member.name]
            assert member.size == row['bytes'] <= MAX_MEMBER
            expanded += member.size
            assert expanded <= MAX_EXPANDED
            with bundle.extractfile(member) as payload:
                assert hashlib.file_digest(payload, 'sha256').hexdigest() == row['sha256']
            seen.add(member.name)
            assert time.monotonic()-start <= 1800
    assert seen == set(expected) and expanded == total
    return dict(file=result.name, sha256=sha(result), bytes=result.stat().st_size, expanded_bytes=expanded,
        member_count=len(expected), max_member_bytes=MAX_MEMBER, max_expanded_bytes=MAX_EXPANDED,
        native_payloads_retained=False, roundtrip_hashes_verified=True,
        retained_files=[expected[name] for name in sorted(expected)])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--expected-source', required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    assert args.expected_source == SOURCE
    require_kernel_budget(1024**3)
    assert sorted(os.sched_getaffinity(0)) == [0]
    source()
    group, start = kernel_group(), time.monotonic()
    before = budget(group)
    terminal, validated, campaign, table, run, previous_path, previous = admit()
    out = args.output.resolve()
    assert out.parent == BASE and not out.exists()
    out.mkdir()
    processing = dict(schema='scriptw-module-ownership-publication-processing-v1', complete=False,
        source_commit=SOURCE, started_at=datetime.now(timezone.utc).isoformat(), cpu_affinity=[0], before=before,
        driver_sha256=sha(Path(__file__)), output_scope='Private candidates only; no repository documentation/graphs changed.')
    try:
        retained = archive(out, terminal, campaign['retained_files'], start)
        diagnostic = {key:value for key,value in validated['diagnostic'].items() if key != 'cases'}
        diagnostic['cases'] = [{key:value for key,value in case.items() if key != 'host_function_overlap'}
                               for case in validated['diagnostic']['cases']]
        old = read(BASE / 'ci-40588588589-validated/report.json')
        document = dict(schema='scriptw-module-ownership-evidence-v1', recorded_at=datetime.now(timezone.utc).isoformat(),
            verified_source_commit=SOURCE, feature_source_commit=FEATURE, measured_source_commit=MEASURED, runtime_layout=28,
            source_bindings=dict(clean_compiler_fingerprint=FP, local_compiler_fingerprint=LOCAL_FP,
                main_feature_measured_equivalence_sha256=sha(BASE/'source-bindings-main-aacf3283-equivalence.json')),
            verification=dict(terminal_checkpoint_sha256=TERMINAL_SHA, original_completed_commands=9, remaining_completed_commands=14,
                python_tests=63, native_scopes=terminal['native_scopes'], original_prefix=terminal['original_prefix'],
                stopped_continuation=terminal['stopped_continuation'], continuation_driver_provenance=terminal['continuation_driver_provenance']),
            runtime_bytes_proof=terminal['runtime_bytes_proof'], runtime_stamp_admission=terminal['runtime_stamp_admission'],
            inherited_conformance=dict(source_commit=previous['verified_source_commit'], unique_selected_executions=6307,
                current_source_test262_rerun=False, checkpoint_file=previous_path.name, checkpoint_sha256=sha(previous_path),
                archive=previous['archive'], predecessor=terminal['predecessor'],
                reason='Host-only source change; identical actual R Wasm and reconstructed old package bytes in both modes. Serialized native differs only in exact source-derived compatibility-stamp bytes; all other bytes, including .text, are identical under the pinned actual-byte proof.'),
            github_run=run, measurement=dict(run=RUN, report_sha256=sha(SCORED), attempts=68, workloads=17,
                all_attempts_ok=True, table=table, interpretation='Current paired compiler-free Scriptw/Scriptc cohort only. V8 figures/status are separate and unchanged.'),
            diagnostic=diagnostic,
            ci_processing=dict(validated_report_sha256=VALIDATED_SHA, validator_sources=validated['validator_sources'],
                started_at=validated['started_at'], finished_at=validated['finished_at'], cpu_affinity=validated['cpu_affinity'],
                before=validated['before'], after=validated['after'], inputs=validated['inputs'],
                derived_report_retained=False, reason='Avoid duplicating 38 MiB of derived nonexclusive function overlap arrays; all raw inputs and validator sources are retained losslessly.'),
            historical_lineage=dict(cancelled_ci=read(BASE/'ci-cancellation-40587639394.json'),
                prior_successful_ci=dict(run=40588588589, source_commit=old['source_commit'],
                    host_metadata_status=old['diagnostic']['host_metadata_status'],
                    host_metadata_reason=old['diagnostic'].get('host_metadata_reason'),
                    current_measurements_reused=False)),
            resource_origins=dict(original_prefix=dict(before=read(BASE/'verify-main-aacf3283/report.json')['before'],
                    after=None, origin='original incomplete prefix; no after counters available'),
                remaining_ladder=dict(before=read(BASE/'verify-main-aacf3283-continuation/report.json')['before'],
                    after=read(BASE/'verify-main-aacf3283-continuation/report.json')['after'], origin='stopped continuation; 14 passed commands, archive failure'),
                archive_only=dict(before=terminal['before'], after=terminal['after'], origin='fresh successful archive-only invocation')),
            archive=retained,
            interpretation='Unscored diagnostic page presence and overlapping host function pages do not establish execution or causal savings. Image/text views overlap and must not be summed. Warm captures follow 16 prior calls; last-sample deltas cannot exclude earlier Realm bootstrap. Transport-drop to warm R present-page growth is only an upper bound on startup contribution. No memory-parity, full-Test262, or completed project-goal claim.')
        lines = ['# Module ownership diagnostic evidence', '',
            'Local feature verification is admitted for `' + SOURCE + '` through nine original commands, 14 remaining commands and a separate successful archive-only checkpoint. The two stopped receipts remain incomplete with their original resource origins and errors.', '',
            'CI [' + str(RUN) + '](' + run['url'] + ') measured `' + MEASURED + '` with feature source `' + FEATURE + '`: 68/68 successful attempts across 17 paired workloads. This separate cohort leaves V8 figures and status unchanged.', '',
            'Default and enabled inventories execute 5/8 and 7/10 CLI example tests; the enabled engine control executes one exact test from its actual 1054-test inventory. Python controls execute 63 tests. The prior 6307 selected JS executions are inherited using exact Wasm/package and native compatibility-stamp-only proofs; no new JS suite run is claimed.', '',
            'Present base pages; image and text views overlap.', '',
            '| Case | Owner | Phase | Image | Text | Union |', '|---|---|---|---:|---:|---:|']
        for case in diagnostic['cases']:
            for owner in case['module_attribution']['owners']:
                for phase in owner['phases']:
                    lines.append('| '+case['runtime']+'/'+case['file']+' | '+owner['role']+' | '+phase['phase']+' | '+str(phase['image_present_pages'])+' | '+str(phase['text_present_pages'])+' | '+str(phase['union_present_pages'])+' |')
        lines += ['', '| Case | Phase | Host RX present pages |', '|---|---|---:|']
        for case in diagnostic['cases']:
            for phase in case['host_phases']:
                lines.append('| '+case['runtime']+'/'+case['file']+' | '+phase['phase']+' | '+str(phase['present_host_rx_pages'])+' |')
        lines += ['', 'Transport drop precedes the run loop. Warm snapshots select observation 16 after 10 warmups and six earlier measured calls. Transport-drop to warm R page growth bounds startup contribution; it does not identify a causal saving. Nonexclusive host function/page overlap is not execution evidence.', '',
            'The original driver review SHA and retained driver SHA differ; the launch did not record the exact loaded SHA. Both sources of provenance remain explicit. Admission relies on pinned reports, command streams, actual inventories and runtime-byte proofs.', '',
            'The inert archive retains local verification streams, source and byte-proof receipts, current scored raw observations, four unscored captures, host metadata/symbol outputs and reproduction scripts. It excludes native payloads. Cancelled CI, the older symbol-name-cap limitation and original local/archive failures remain in the lineage.']
        source()
        after = budget(group); no_oom(before, after)
        processing.update(complete=True, after=after, finished_at=datetime.now(timezone.utc).isoformat(), seconds=time.monotonic()-start)
        document['publication_processing'] = processing
        (out/(STEM+'.json')).write_text(json.dumps(document, indent=2)+'\n')
        (out/(STEM+'.md')).write_text('\n'.join(lines)+'\n')
    except Exception as error:
        processing.update(error=repr(error), error_type=type(error).__name__, after=budget(group),
                          finished_at=datetime.now(timezone.utc).isoformat(), seconds=time.monotonic()-start)
        raise
    finally:
        (out/'processing.json').write_text(json.dumps(processing, indent=2)+'\n')
    print(json.dumps(dict(complete=True, private_output=str(out), archive_sha256=retained['sha256'])))


if __name__ == '__main__':
    main()
