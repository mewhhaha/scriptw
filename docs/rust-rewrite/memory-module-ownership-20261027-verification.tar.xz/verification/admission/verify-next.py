"""Private sequential feature ladder. Prepare now; execute only on final source."""
import argparse,hashlib,json,os,re,shutil,struct,subprocess,sys,time
from pathlib import Path
BASE=Path(__file__).resolve().parent;ROOT=BASE.parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from limited_verification import require_kernel_budget,kernel_group
from native_test_protocol import parse_inventory,result_summaries
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--expected-source',required=True);p.add_argument('--source-bindings',type=Path,required=True);p.add_argument('--output',type=Path,required=True);args=p.parse_args()
SOURCE=args.expected_source;assert re.fullmatch('[0-9a-f]{40}',SOURCE)
OUT=args.output.resolve();assert OUT.is_relative_to(BASE.resolve()) and not OUT.exists()
require_kernel_budget(4*1024**3);assert sorted(os.sched_getaffinity(0))==[0]
assert os.environ['SCRIPTW_MODULE_MEMORY_CACHE_ENTRIES']=='1' and os.environ['SCRIPTW_MODULE_MEMORY_CACHE_LIMIT_BYTES']==str(64*1024**2)
os.environ['CARGO_BUILD_JOBS']='1';os.environ['RUST_TEST_THREADS']='1'
def git(*xs):return subprocess.check_output(['git',*xs],cwd=ROOT)
def source():
 assert git('rev-parse','HEAD').decode().strip()==SOURCE
 assert not git('diff','HEAD','--','crates','vendor','scripts','Cargo.toml','Cargo.lock')
source()
for ancestor in ('9001324dc52ce583e7b95a1292f317796d415c01','a30864ed930b61b30fa51e841d76ebb9b584e383'):
 assert subprocess.run(['git','merge-base','--is-ancestor',ancestor,SOURCE],cwd=ROOT).returncode==0
host_only_crate_paths={
 'crates/scriptw-cli/Cargo.toml',
 'crates/scriptw-cli/examples/compiler_precompiled_baseline/wasi.rs',
 'crates/scriptw-cli/examples/runtime_precompiled/consume.rs',
 'crates/scriptw-cli/examples/runtime_precompiled/phase_barriers.rs',
 'crates/scriptw-engine/Cargo.toml','crates/scriptw-engine/src/embedding.rs',
 'crates/scriptw-engine/src/embedding/benchmark_module_images.rs',
 'crates/scriptw-engine/src/embedding/tests.rs',
 'crates/scriptw-engine/src/embedding/tests/benchmark_module_images.rs',
 'crates/scriptw-engine/src/lib.rs',
}
crate_diff=git('diff','--name-only','9001324dc52ce583e7b95a1292f317796d415c01',SOURCE,'--','crates','vendor','Cargo.toml','Cargo.lock').decode().splitlines()
assert set(crate_diff)<=host_only_crate_paths, 'unexpected compiler/runtime source change requires a new JS verification decision'
bindings=json.loads(args.source_bindings.read_text());local=next(r for r in bindings if r['revision']==SOURCE and r['extra_ignored_regress_lock']);assert len(bindings)==2 and all(r['revision']==SOURCE for r in bindings)
def sha(path):
 with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
# Only a fully completed predecessor authorizes avoiding a duplicate JS suite.
oldbase=ROOT/'target/memory-regexp-backtrack-20261027-evidence/retry-9001324dc'
oldverify=json.loads((oldbase/'verification.json').read_text());oldnative=json.loads((oldbase/'native/report.json').read_text())
oldtailpath=oldbase.parent/'recovery-parent-20261027/continuation.json';oldtail=json.loads(oldtailpath.read_text())
assert oldverify['complete'] is False and 'after' not in oldverify
assert oldtail['complete'] is True and oldtail['unique_selected_executions']==6307 and oldnative['complete'] is True and oldnative['passed_disjoint_scopes']==4889
assert oldverify['source_commit']==oldnative['source_commit']==oldtail['source_commit']=='9001324dc52ce583e7b95a1292f317796d415c01'
assert oldtail['original_verification']['sha256']==sha(oldbase/'verification.json') and oldtail['original_verification']['resource_after_available'] is False
assert oldtail['native_completion']['sha256']==sha(oldbase/'native/report.json')
for command in oldtail['commands']:
 assert command['exit_code']==0
 for channel in ('stdout','stderr'):assert sha(oldtailpath.parent/command[channel])==command[channel+'_sha256']
ids=set()
for name,count in [('conformance',2365),('conformance-regexp-full',3756),('conformance-array-from-async',186)]:
 folder=oldbase/name;r=json.loads((folder/'report.json').read_text());assert r['complete'] is True and r['all_passed'] is True and r['passed']==r['total']==count
 rows=(folder/'executions').read_text().splitlines();assert len(rows)==len(set(rows))==count;ids.update(rows)
assert len(ids)==6307
oldstatic_path=ROOT/'target/memory-regexp-backtrack-20261027-evidence/retry-80b842693/owned-r-static.json';oldstatic=json.loads(oldstatic_path.read_text());assert oldstatic['source_commit']=='80b842693e964634f378d5813f6db684ee7d255b'
OUT.mkdir();group=kernel_group()
def budget():return {k:(group/k).read_text().strip() for k in ['memory.max','memory.swap.max','memory.oom.group','memory.peak','memory.events']}
record=dict(host_only_crate_paths=crate_diff,reviewed_crate_diff_sha256=hashlib.sha256(git('diff','--binary','9001324dc52ce583e7b95a1292f317796d415c01',SOURCE,'--','crates','vendor','Cargo.toml','Cargo.lock')).hexdigest(),source_commit=SOURCE,compiler_fingerprint_equivalence_claim=False,complete=False,cpu_affinity=[0],before=budget(),commands=[],native_scopes=[],source_bindings=dict(path=str(args.source_bindings),sha256=sha(args.source_bindings)),predecessor=dict(verification_sha256=sha(oldbase/'verification.json'),outer_verification_complete=False,outer_verification_resource_after_available=False,continuation_sha256=sha(oldtailpath),native_sha256=sha(oldbase/'native/report.json'),native_cases=4889,pinned_unique_executions=6307),runtime_bytes_proof={},test262_rerun=False)
def save():(OUT/'report.json').write_text(json.dumps(record,indent=2)+'\n')
def run(label,command,timeout=7200):
 source();a=OUT/(label+'.stdout');b=OUT/(label+'.stderr');row=dict(label=label,command=list(map(str,command)),stdout=a.name,stderr=b.name);record['commands'].append(row);save();start=time.monotonic();print(label,'started',flush=True)
 with a.open('xb') as x,b.open('xb') as y:child=subprocess.run(row['command'],cwd=ROOT,stdout=x,stderr=y,timeout=timeout)
 row.update(exit_code=child.returncode,seconds=time.monotonic()-start,stdout_sha256=sha(a),stderr_sha256=sha(b));save()
 assert child.returncode==0,label+' failed; raw streams retained'
 source();return a
BUILD=ROOT/'target/performance-work-20261024/build'
def cargo(*more):return ['cargo',*more,'--locked','--offline','--release','--jobs','1','--target-dir',BUILD]
def jsonrows(log):return [json.loads(x) for x in log.read_text().splitlines()]
def frozen_test(log,name,kind,label):
 rows=[r for r in jsonrows(log) if r.get('reason')=='compiler-artifact' and r.get('executable') and r['target']['name']==name and r['target']['kind']==[kind] and r['profile']['test']];assert len(rows)==1
 row=rows[0];original=Path(row['executable']);binary=OUT/(label+'-tests');shutil.copy2(original,binary);assert sha(binary)==sha(original) and binary.stat().st_nlink==1
 inv=parse_inventory(run(label+'-inventory',[binary,'--list']).read_text());assert inv
 metadata=dict(label=label,binary=binary.name,binary_sha256=sha(binary),cargo_producer=row,inventory=inv);record['native_scopes'].append(metadata);save();return binary,inv,metadata

def runtime_snapshot(log,label):
 producers=[r for r in jsonrows(log) if r.get('reason')=='build-script-executed' and r.get('package_id')=='path+file:///home/mewhhaha/src/porffor/crates/scriptw-runtime-image#0.1.0'];assert len(producers)==1
 directory=Path(producers[0]['out_dir']);result={}
 for mode,prefix in [('Portable','scriptw-runtime-portable'),('NativeHost','scriptw-runtime')]:
  package=directory/(prefix+'-package.bin');raw=package.read_bytes();assert raw[:8]==b'SCRWRB01' and struct.unpack_from('<I',raw,8)[0]==28 and raw[12:44].hex()==local['source_fingerprint']
  assert hashlib.sha256(raw[:-32]).digest()==raw[-32:];wasm=raw[136:-32];assert wasm[:8]==b'\0asm\1\0\0\0'
  native=directory/(prefix+'-native.bin');manifest=directory/(prefix+'-manifest.bin');m=manifest.read_bytes();assert m[:8]==b'SCRWNR01' and struct.unpack_from('<I',m,8)[0]==5
  n=struct.unpack_from('<H',m,19)[0];assert len(m)==21+n+128
  offset=21+n;fp,key,pkg_digest,native_digest=[m[offset+i*32:offset+(i+1)*32].hex() for i in range(4)]
  assert fp==local['source_fingerprint'] and sha(package)==pkg_digest and sha(native)==native_digest
  assert hashlib.sha256(struct.pack('<I',28)+wasm).hexdigest()==key
  before=oldstatic['variants'][mode];old=before['current']
  assert struct.unpack_from('<I',m,12)[0]==old['manifest']['configuration'] and list(m[16:19])==old['manifest']['modes'] and m[21:21+n].decode()==old['manifest']['target']
  reconstructed=bytearray(raw);reconstructed[12:44]=bytes.fromhex(old['package']['source_fingerprint']);reconstructed[-32:]=hashlib.sha256(reconstructed[:-32]).digest()
  # A byte change is a hard stop: the retained JS suite is then insufficient.
  same=hashlib.sha256(wasm).hexdigest()==before['wasm_sha256'] and native_digest==old['native']['sha256'] and hashlib.sha256(reconstructed).hexdigest()==old['package']['sha256']
  if not same:record['requires_full_wasm_verification']=True;save()
  assert same,'actual runtime bytes changed; do not skip fresh JS verification'
  copy=OUT/(label+'-'+mode+'-manifest.bin');copy.write_bytes(m)
  result[mode]=dict(package_path=str(package),package_sha256=pkg_digest,package_bytes=len(raw),wasm_sha256=hashlib.sha256(wasm).hexdigest(),wasm_bytes=len(wasm),native_sha256=native_digest,native_bytes=native.stat().st_size,runtime_key=key,manifest=copy.name,manifest_sha256=sha(copy),target=m[21:21+n].decode(),configuration=struct.unpack_from('<I',m,12)[0],modes=list(m[16:19]),historical_header_reconstruction_sha256=hashlib.sha256(reconstructed).hexdigest())
 record['runtime_bytes_proof'][label]=dict(cargo_producer=producers[0],variants=result,retained80_static_sha256=sha(oldstatic_path));save();return result
save()
# Source checks never regenerate or mutate identities.
run('source-guards',[sys.executable,'-B','scripts/check-source-guards.py','--output',OUT/'source-guards'],600)
for label,command in [('identities',[sys.executable,'-B','scripts/intl_source_identities.py']),('runtime-profile',[sys.executable,'-B','scripts/check-runtime-source-compilation-profile.py']),('immutable-pool',[sys.executable,'-B','scripts/check-immutable-compiler-pool.py']),('retired-js',['bash','scripts/check-no-legacy-js.sh']),('diff',['git','diff','--check'])]:run(label,command,600)
changed=git('diff','--name-only','9001324dc52ce583e7b95a1292f317796d415c01',SOURCE).decode().splitlines();rust=[x for x in changed if x.endswith('.rs')]
if rust:run('rustfmt',['rustfmt','--edition','2021','--config','skip_children=true','--check',*rust],600)
py=run('python63',[sys.executable,'-B','-m','unittest','scripts.tests.test_precompiled_comparison','scripts.tests.test_tooling_benchmark_boundary','scripts.tests.test_precompiled_mapping_diagnostic','scripts.tests.test_benchmark_module_images','-v'],600)
pytext=py.read_text()+(OUT/'python63.stderr').read_text();assert re.findall(r'Ran (\d+) tests?',pytext)==['63'] and re.search(r'^OK$',pytext,re.M)
defaultlog=run('default-workspace-check',cargo('check','--workspace','--all-targets','--no-default-features','--message-format=json'))
defaultbytes=runtime_snapshot(defaultlog,'default')
doclog=run('default-engine-doctests',cargo('test','-p','scriptw-engine','--no-default-features','--doc'))
doctext=doclog.read_text();assert re.search(r'^test .*embedding\.rs - embedding::EmbeddedRuntime .*compile fail \.\.\. ok$',doctext,re.M), 'actual default missing-API doctest must execute'
record['default_api_absence_compile_fail_executed']=True;save()
default_examples=run('default-example-build',cargo('test','-p','scriptw-cli','--no-default-features','--example','runtime_precompiled','--example','compiler_precompiled_baseline','--no-run','--message-format=json'))
default_ids={}
for name in ('runtime_precompiled','compiler_precompiled_baseline'):
 binary,inv,meta=frozen_test(default_examples,name,'example','default-'+name);default_ids[name]=set(inv)
 text=run('default-'+name+'-all',[binary,'--exact','--include-ignored','--test-threads=1',*inv]).read_text();names=re.findall(r'^test ([^\r\n]+) \.\.\. ok$',text,re.M)
 assert len(names)==len(inv) and set(names)==set(inv) and result_summaries(text)==[('ok',str(len(inv)),'0','0','0','0')]
 assert sha(binary)==meta['binary_sha256'];meta['executed']=inv;save()
enabled=run('enabled-controls-build',cargo('test','-p','scriptw-engine','-p','scriptw-cli','--features','benchmark-module-images','--lib','--example','runtime_precompiled','--example','compiler_precompiled_baseline','--no-run','--message-format=json'))
binary,inv,meta=frozen_test(enabled,'scriptw_engine','lib','enabled-engine')
positive='embedding::tests::benchmark_module_images::diagnostic_images_match_actual_program_runtime_and_survive_store_drop';assert positive in inv
text=run('enabled-engine-positive',[binary,'--exact','--include-ignored','--test-threads=1',positive]).read_text();assert result_summaries(text)==[('ok','1','0','0','0',str(len(inv)-1))];assert sha(binary)==meta['binary_sha256'];meta['executed']=[positive];save()
for name in ('runtime_precompiled','compiler_precompiled_baseline'):
 binary,inv,meta=frozen_test(enabled,name,'example','enabled-'+name);assert default_ids[name]<=set(inv)
 text=run('enabled-'+name+'-all',[binary,'--exact','--include-ignored','--test-threads=1',*inv]).read_text();names=re.findall(r'^test ([^\r\n]+) \.\.\. ok$',text,re.M)
 assert len(names)==len(inv) and set(names)==set(inv) and result_summaries(text)==[('ok',str(len(inv)),'0','0','0','0')]
 assert sha(binary)==meta['binary_sha256'];meta['executed']=inv;meta['preserved_default_ids']=len(default_ids[name]);save()
product=run('enabled-shared-host-build',cargo('build','-p','scriptw-cli','--features','benchmark-module-images','--example','compiler_precompiled_baseline','--message-format=json'))
enabledbytes=runtime_snapshot(product,'enabled')
assert all(defaultbytes[m]['wasm_sha256']==enabledbytes[m]['wasm_sha256'] and defaultbytes[m]['native_sha256']==enabledbytes[m]['native_sha256'] for m in defaultbytes)
rows=[r for r in jsonrows(product) if r.get('reason')=='compiler-artifact' and r.get('executable') and r['target']['name']=='compiler_precompiled_baseline' and not r['profile']['test']];assert len(rows)==1
record['shared_host_product']=dict(cargo_producer=rows[0],sha256=sha(Path(rows[0]['executable'])))
require_kernel_budget(4*1024**3);assert sorted(os.sched_getaffinity(0))==[0]
after=budget();beforeevents=dict(x.split() for x in record['before']['memory.events'].splitlines());afterevents=dict(x.split() for x in after['memory.events'].splitlines());assert all(beforeevents[k]==afterevents[k] for k in ('oom','oom_kill','oom_group_kill'))
record.update(complete=True,after=after,actual_wasm_and_native_bytes_unchanged=True,test262_rerun_reason='Host-only feature; exact default/enabled R Wasm and native bytes match retained verified80 source-bound facts. No new JS semantic execution claim.');save()
print('ownership ladder complete; actual inventories retained; no Test262 rerun',flush=True)
