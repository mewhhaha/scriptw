"""Inert actual-byte comparison; never execute or retain native payloads."""
from compression.zstd import ZstdDecompressor, DecompressionParameter
from datetime import datetime, timezone
import hashlib
import json
import mmap
import os
from pathlib import Path
import stat
import struct
import subprocess
import sys

BASE = Path(__file__).resolve().parent
OUT = BASE / 'retry-version-length'
OUT.mkdir(exist_ok=False)
ROOT = BASE.parents[2]
sys.path.insert(0, str(ROOT / 'scripts'))
from limited_verification import require_kernel_budget, kernel_group
SOURCE = 'aacf3283ca1fd0b2dd47e7bd1aea6230bf140a1a'
OLD_SOURCE = '80b842693e964634f378d5813f6db684ee7d255b'
MIB = 1024**2
CURRENT = ROOT / 'target/performance-work-20261024/build/release/build/scriptw-runtime-image-9e3d6309395f2bbb/out'
EXPECTED = dict(
    Portable=('03ef34c81ec0d23c8b83fbbf089f7373f35e5f08a90714048f1dcb7ae54ae1c9',
              '4dac02b8875bdaa6fba2938ed33dfa0142512bc7c515a390efc89bf13b6e1c71', 67307296),
    NativeHost=('f2ce76a9a94f2cbaf868d9094b517e98dbfdce3c78eb80930060e1f33cdf4435',
                'cb39ffe5749d957b0cb2fc4bf72f0fe92ac9ee4b44e07a5199d3729736ddf3ff', 67313648),
)


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def source():
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == SOURCE
    assert not subprocess.check_output(['git', 'diff', '--binary', 'HEAD', '--', 'crates', 'vendor', 'Cargo.toml', 'Cargo.lock'], cwd=ROOT)


def owned(path, maximum):
    value = path.lstat()
    assert stat.S_ISREG(value.st_mode) and value.st_uid == os.getuid() and value.st_size <= maximum
    assert path.resolve() == path
    return value


def elf(raw, *, hashes=True):
    assert len(raw) >= 64 and raw[:7] == b'\x7fELF\x02\x01\x01'
    fields = struct.unpack_from('<16sHHIQQQIHHHHHH', raw)
    _, kind, machine, version, entry, phoff, shoff, flags, ehsize, phsize, phnum, shsize, shnum, shstr = fields
    assert version == 1 and ehsize == 64 and shsize == 64 and 0 < shnum <= 4096 and 0 < shstr < shnum
    assert shoff <= len(raw) and shnum * 64 <= len(raw) - shoff
    sections = []
    for index in range(shnum):
        name, typ, sflags, va, off, size, link, info, align, entsize = struct.unpack_from('<IIQQQQIIQQ', raw, shoff + index * 64)
        assert va <= 2**64-1-size
        if typ != 8:
            assert off <= len(raw) and size <= len(raw)-off
        sections.append(dict(index=index, name_offset=name, type=typ, flags=sflags, vaddr=va,
                             offset=off, bytes=size, link=link, info=info, align=align, entsize=entsize))
    strings = sections[shstr]
    assert strings['type'] == 3
    names = raw[strings['offset']:strings['offset']+strings['bytes']]
    for section in sections:
        start = section['name_offset']
        assert start < len(names)
        end = names.find(b'\0', start, min(len(names), start+2049))
        assert end >= start
        section['name'] = names[start:end].decode('utf-8')
        if hashes and section['type'] != 8:
            section['sha256'] = digest(memoryview(raw)[section['offset']:section['offset']+section['bytes']])
    return dict(kind=kind, machine=machine, flags=flags, sections=sections,
                section_header_offset=shoff, section_header_count=shnum)


def engine(raw, metadata):
    sections = [s for s in metadata['sections'] if s['name'] == '.wasmtime.engine']
    assert len(sections) == 1
    section = sections[0]
    data = memoryview(raw)[section['offset']:section['offset']+section['bytes']]
    assert data[0] == 0 and 0 < data[1] < len(data)-2
    length = data[1]
    version = bytes(data[2:2+length]).decode('ascii')
    assert len(version) == len('scriptw-native-v1-')+64 and version.startswith('scriptw-native-v1-')
    assert all(c in '0123456789abcdef' for c in version[-64:])
    return dict(section_name=section['name'], section_offset=section['offset'], section_bytes=section['bytes'],
                serialization_version=data[0], native_version=version, native_fingerprint=version[-64:],
                version_offset=section['offset']+2, version_bytes=length,
                remaining_engine_metadata_sha256=digest(data[2+length:]))


def masked_digest(raw, offset, count):
    value = hashlib.sha256(memoryview(raw)[:offset])
    value.update(b'\0' * count)
    value.update(memoryview(raw)[offset+count:])
    return value.hexdigest()


def compare(old, new):
    a, b = elf(old), elf(new)
    assert len(old) == len(new)
    ae, be = engine(old, a), engine(new, b)
    diffs = []
    for offset in range(0, len(old), 65536):
        first, second = old[offset:offset+65536], new[offset:offset+65536]
        if first == second:
            continue
        for delta, (x, y) in enumerate(zip(first, second)):
            if x == y:
                continue
            position = offset+delta
            if diffs and diffs[-1]['end'] == position:
                diffs[-1]['end'] += 1
            else:
                assert len(diffs) < 4096, 'too many byte-difference extents for this bounded metadata comparison'
                diffs.append(dict(start=position, end=position+1))
    for extent in diffs:
        extent['sections'] = [s['name'] for s in b['sections'] if s['type'] != 8
                              and s['offset'] <= extent['start'] < extent['end'] <= s['offset']+s['bytes']]
    assert len(a['sections']) == len(b['sections'])
    rows = []
    for first, second in zip(a['sections'], b['sections']):
        assert {k:v for k,v in first.items() if k != 'sha256'} == {k:v for k,v in second.items() if k != 'sha256'}
        rows.append(dict(name=first['name'], flags=first['flags'], offset=first['offset'], bytes=first['bytes'],
                         old_sha256=first.get('sha256'), current_sha256=second.get('sha256'),
                         byte_identical=first.get('sha256') == second.get('sha256')))
    same_location = (ae['version_offset'], ae['version_bytes']) == (be['version_offset'], be['version_bytes'])
    normalized_a = masked_digest(old, ae['version_offset'], ae['version_bytes'])
    normalized_b = masked_digest(new, be['version_offset'], be['version_bytes'])
    within = all(be['version_offset'] <= item['start'] < item['end'] <= be['version_offset']+be['version_bytes'] for item in diffs)
    return dict(old_engine=ae, current_engine=be, sections=rows, changed_byte_extents=diffs,
                changed_bytes=sum(item['end']-item['start'] for item in diffs),
                masked_old_sha256=normalized_a, masked_current_sha256=normalized_b,
                whole_file_identical_except_native_version=same_location and within and normalized_a == normalized_b,
                remaining_engine_metadata_identical=ae['remaining_engine_metadata_sha256'] == be['remaining_engine_metadata_sha256'])


def embedded_native(host, raw, metadata, profile, expected_sha, expected_length):
    name = 'SCRIPTW_RUNTIME_PORTABLE_NATIVE' if profile == 'Portable' else 'SCRIPTW_RUNTIME_NATIVE'
    candidates = []
    for table in metadata['sections']:
        if table['type'] != 2:
            continue
        assert table['entsize'] == 24 and table['bytes'] % 24 == 0 and table['bytes']//24 <= 1_000_000
        assert table['link'] < len(metadata['sections'])
        strings = metadata['sections'][table['link']]
        assert strings['type'] == 3 and strings['bytes'] <= 128*MIB
        begin, end = strings['offset'], strings['offset']+strings['bytes']
        names = set()
        cursor = begin
        needle = b'\0' + name.encode() + b'\0'
        while True:
            found = raw.find(needle, cursor, end)
            if found < 0:
                break
            names.add(found+1-begin)
            cursor = found+1
        for index in range(table['bytes']//24):
            nm, info, other, section_index, va, size = struct.unpack_from('<IBBHQQ', raw, table['offset']+index*24)
            if nm not in names:
                continue
            assert info & 15 == 1 and info >> 4 == 1 and 0 < section_index < len(metadata['sections'])
            section = metadata['sections'][section_index]
            assert section['type'] == 1 and section['flags'] & 2 and not section['flags'] & 4
            assert section['vaddr'] <= va and va+size <= section['vaddr']+section['bytes'] and 48 < size <= 64*MIB
            offset = section['offset']+va-section['vaddr']
            packed = raw[offset:offset+size]
            assert packed[:8] == b'SWRTZ001' and struct.unpack_from('<Q', packed, 8)[0] == expected_length
            assert packed[16:48].hex() == expected_sha
            decoder = ZstdDecompressor(options={DecompressionParameter.window_log_max:23})
            decoded = decoder.decompress(packed[48:], max_length=expected_length+1)
            assert decoder.eof and not decoder.unused_data and len(decoded) == expected_length
            assert digest(decoded) == expected_sha
            candidates.append((decoded, dict(host_path=str(host), symbol=name, symbol_table_section=table['name'],
                                             symbol_section=section['name'], symbol_vaddr=va, file_offset=offset,
                                             packed_bytes=size, packed_sha256=digest(packed), framing_magic='SWRTZ001',
                                             decoded_bytes=expected_length, decoded_sha256=expected_sha,
                                             zstd_window_log_max=23, single_frame_no_trailing_data=True)))
    assert len(candidates) == 1
    return candidates[0]


require_kernel_budget(1024**3)
assert sorted(os.sched_getaffinity(0)) == [0]
source()
assert not (OUT / 'report.json').exists()
group = kernel_group()
def budget():
    return {k:(group/k).read_text().strip() for k in ('memory.max','memory.swap.max','memory.oom.group','memory.peak','memory.events')}
record = dict(schema='scriptw-native-serialization-inert-comparison-v1', complete=False, source_commit=SOURCE,
              started_at=datetime.now(timezone.utc).isoformat(), cpu_affinity=[0], before=budget(), candidates=[], variants={},
              native_payload_executed=False, native_payload_retained=False, product_build_executed=False,
              interpretation='Actual byte comparisons and exact old payload hashes only; equivalence is not inferred from sizes or helper counts. Parent decides verification admission separately.')
def save():
    (OUT/'report.json').write_text(json.dumps(record,indent=2)+'\n')
save()
try:
    old_facts_path = ROOT/'target/memory-regexp-backtrack-20261027-evidence/retry-80b842693/owned-r-static.json'
    old_facts = json.loads(old_facts_path.read_text())
    record['old_static_facts'] = dict(path=str(old_facts_path),sha256=sha(old_facts_path))
    matches = {}
    paths = sorted((ROOT/'target/performance-work-20261024/build').glob('*/build/scriptw-runtime-image-*/out/scriptw-runtime*native.bin'))
    assert len(paths) <= 64
    for path in paths:
        info = owned(path,256*MIB)
        profile = 'Portable' if path.name == 'scriptw-runtime-portable-native.bin' else 'NativeHost'
        old_sha, current_sha, length = EXPECTED[profile]
        row = dict(path=str(path), profile=profile, bytes=info.st_size)
        if info.st_size == length:
            row['sha256'] = sha(path)
            row['matches_verified_old'] = row['sha256'] == old_sha
            if row['matches_verified_old']:
                matches.setdefault(profile,path)
        else:
            row['cannot_match_verified_old_length'] = True
        record['candidates'].append(row)
        save()
    frozen_path = ROOT/'target/memory-regexp-backtrack-20261027-evidence/retry-9001324dc/frozen-native-binaries.json'
    frozen = json.loads(frozen_path.read_text())
    binary = next(row for row in frozen['binaries'] if row['target'] == 'scriptw_engine' and row['package'] == 'scriptw-engine')
    host = Path(binary['path'])
    if len(matches) != 2:
        info = owned(host,512*MIB)
        assert info.st_size == binary['bytes'] and sha(host) == binary['sha256']
        record['frozen_native_binding'] = dict(path=str(frozen_path),sha256=sha(frozen_path),binary=binary)
        for relative in ('crates/scriptw-runtime-image/build/objects.rs','crates/scriptw-runtime-image/src/native_storage.rs'):
            data = subprocess.check_output(['git','show',OLD_SOURCE+':'+relative],cwd=ROOT)
            record.setdefault('old_storage_source_proofs',[]).append(dict(source_commit=OLD_SOURCE,path=relative,sha256=digest(data)))
            if relative.endswith('objects.rs'):
                assert b'SCRIPTW_RUNTIME_NATIVE' in data and b'SCRIPTW_RUNTIME_PORTABLE_NATIVE' in data and b'native.packed' in data
            else:
                assert b'SWRTZ001' in data and b'HEADER_BYTES: usize = 48' in data and b'window_log_max(23)' in data
    for profile,prefix in [('Portable','scriptw-runtime-portable'),('NativeHost','scriptw-runtime')]:
        old_sha,current_sha,length = EXPECTED[profile]
        assert old_facts['variants'][profile]['current']['native']['sha256'] == old_sha
        path = CURRENT/(prefix+'-native.bin')
        owned(path,128*MIB)
        assert path.stat().st_size == length and sha(path) == current_sha
        new = path.read_bytes()
        if profile in matches:
            old_path = matches[profile]
            old = old_path.read_bytes()
            assert digest(old) == old_sha
            origin = dict(kind='surviving-native-file',path=str(old_path),sha256=old_sha)
        else:
            with host.open('rb') as stream,mmap.mmap(stream.fileno(),0,access=mmap.ACCESS_READ) as raw:
                old,origin = embedded_native(host,raw,elf(raw,hashes=False),profile,old_sha,length)
            origin.update(kind='verified-frozen-ELF-owned-static-array',host_sha256=binary['sha256'])
        result = compare(old,new)
        record['variants'][profile] = dict(old_origin=origin,current=dict(path=str(path),sha256=current_sha,bytes=length),comparison=result)
        assert digest(old) == old_sha and sha(path) == current_sha
        del old,new
        save()
    source()
    record['native_identity_source_changes'] = subprocess.check_output(['git','diff','--name-only','9001324dc52ce583e7b95a1292f317796d415c01',SOURCE,'--',
        'Cargo.toml','Cargo.lock','vendor','crates/scriptw-engine/Cargo.toml','crates/scriptw-runtime-image/Cargo.toml'],cwd=ROOT,text=True).splitlines()
    for relative in ('crates/scriptw-engine/src/wasmtime_config.rs','crates/scriptw-engine/compiler_fingerprint.rs','vendor/wasmtime-47.0.0/src/engine/serialization.rs'):
        record.setdefault('current_source_proofs',[]).append(dict(path=relative,sha256=sha(ROOT/relative)))
    record['after'] = budget()
    events = [dict(line.split() for line in record[moment]['memory.events'].splitlines()) for moment in ('before','after')]
    assert all(events[0][key] == events[1][key] for key in ('oom','oom_kill','oom_group_kill'))
    record.update(complete=True,finished_at=datetime.now(timezone.utc).isoformat())
except Exception as error:
    record.update(error=repr(error),error_type=type(error).__name__)
    if 'after' not in record:
        record['after'] = budget()
    raise
finally:
    save()
    print(json.dumps(dict(complete=record['complete'],error=record.get('error'),
                         metadata_only={name:row['comparison']['whole_file_identical_except_native_version'] for name,row in record['variants'].items()})),flush=True)
