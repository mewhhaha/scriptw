"""Bind both observed native-version hashes to their real source input recipe."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import sys

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[2]
OUT = BASE / 'native-identity-provenance.json'
COMPARISON = BASE / 'retry-version-length/report.json'
OLD = '80b842693e964634f378d5813f6db684ee7d255b'
CURRENT = 'aacf3283ca1fd0b2dd47e7bd1aea6230bf140a1a'
sys.path.insert(0, str(ROOT / 'scripts'))
from limited_verification import require_kernel_budget, kernel_group


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


require_kernel_budget(1024**3)
assert sorted(os.sched_getaffinity(0)) == [0]
assert git('rev-parse','HEAD').decode().strip() == CURRENT
assert not OUT.exists()
group = kernel_group()
def budget():
    return {k:(group/k).read_text().strip() for k in ('memory.max','memory.swap.max','memory.oom.group','memory.peak','memory.events')}
record = dict(schema='scriptw-native-version-source-provenance-v1', complete=False, source_commit=CURRENT,
              old_source_commit=OLD, started_at=datetime.now(timezone.utc).isoformat(), cpu_affinity=[0], before=budget(),
              comparison_report_sha256=sha(COMPARISON), original_private_refusal_sha256=sha(BASE/'report.json'),
              original_private_refusal_reason='Inspector incorrectly assumed an 81-byte version. Actual source format is the 18-byte scriptw-native-v1- prefix plus 64 hex digits; corrected fresh comparison retained separately.',
              payload_execution=False, payload_retention=False, product_build=False)
def save():
    OUT.write_text(json.dumps(record,indent=2)+'\n')
save()
try:
    comparison = json.loads(COMPARISON.read_text())
    assert comparison['complete'] and all(row['comparison']['whole_file_identical_except_native_version'] for row in comparison['variants'].values())
    implementation = 'crates/scriptw-engine/compiler_fingerprint.rs'
    owners = []
    for revision in (OLD,CURRENT):
        text = git('show',revision+':'+implementation).decode()
        scheme, = re.findall(r'const NATIVE_FINGERPRINT_SCHEME: &str = "([^"]+)";',text)
        block, = re.findall(r'const NATIVE_COMPILER_INPUTS: &\[&str\] = &\[(.*?)\];',text,re.S)
        roots = re.findall(r'^\s*"([^"]+)",',block,re.M)
        owners.append((scheme,roots))
    assert owners[0] == owners[1] and owners[0][0] == 'scriptw-native-compiler-v1'
    scheme, roots = owners[0]
    inventories = {}
    for revision in (OLD,CURRENT):
        entries = {}
        for row in git('ls-tree','-r','-z',revision,'--',*roots).split(b'\0'):
            if not row:
                continue
            metadata,path = row.split(b'\t',1)
            mode,kind,oid = metadata.decode().split()
            assert kind == 'blob' and mode == '100644'
            entries[path.decode()] = oid
        assert entries and len(entries) <= 32768
        inventories[revision] = entries
    assert inventories[OLD].keys() == inventories[CURRENT].keys()
    assert not git('diff','--binary','HEAD','--',*roots)
    current_files = set()
    def walk(path):
        info = path.lstat()
        if stat.S_ISREG(info.st_mode):
            current_files.add(path.relative_to(ROOT).as_posix())
        else:
            assert stat.S_ISDIR(info.st_mode)
            for child in path.iterdir():
                if child.is_dir() and child.name in ('target','.git'):
                    continue
                walk(child)
    for root in roots:
        walk(ROOT/root)
    extra = current_files-inventories[CURRENT].keys()
    assert not inventories[CURRENT].keys()-current_files
    assert len(extra) <= 16
    record['extra_current_inputs'] = [dict(path=path,bytes=(ROOT/path).stat().st_size,sha256=sha(ROOT/path)) for path in sorted(extra)]
    hashes = {(rev,add):hashlib.sha256(scheme.encode()) for rev in (OLD,CURRENT) for add in (False,True)}
    counts = {(rev,add):[0,0] for rev in (OLD,CURRENT) for add in (False,True)}
    process = subprocess.Popen(['git','cat-file','--batch'],cwd=ROOT,stdin=subprocess.PIPE,stdout=subprocess.PIPE)
    def blob(oid):
        process.stdin.write((oid+'\n').encode());process.stdin.flush()
        got,kind,length = process.stdout.readline().split()
        assert got.decode() == oid and kind == b'blob' and int(length) <= 64*1024**2
        value = process.stdout.read(int(length))
        assert len(value) == int(length) and process.stdout.read(1) == b'\n'
        return value
    try:
        for path in sorted(set(inventories[CURRENT])|extra,key=lambda path:tuple(path.split('/'))):
            label = path.encode()
            if path in extra:
                assert (ROOT/path).stat().st_size <= 64*1024**2
                data = (ROOT/path).read_bytes()
                values = {OLD:data,CURRENT:data}
            else:
                old_oid,new_oid = (inventories[rev][path] for rev in (OLD,CURRENT))
                old_data = blob(old_oid)
                new_data = old_data if old_oid == new_oid else blob(new_oid)
                values = {OLD:old_data,CURRENT:new_data}
            for rev,data in values.items():
                for add in (False,True):
                    if path in extra and not add:
                        continue
                    value = hashes[rev,add]
                    value.update(len(label).to_bytes(8,'little'));value.update(label)
                    value.update(len(data).to_bytes(8,'little'));value.update(data)
                    counts[rev,add][0] += 1;counts[rev,add][1] += len(data)
                    assert counts[rev,add][1] <= 256*1024**2
    finally:
        process.stdin.close();process.stdout.close();assert process.wait() == 0
    record['source_fingerprints'] = [dict(source_commit=rev,includes_current_extra_inputs=add,
                                         native_fingerprint=value.hexdigest(),files=counts[rev,add][0],bytes=counts[rev,add][1])
                                     for (rev,add),value in hashes.items()]
    for mode,row in comparison['variants'].items():
        actual_old = row['comparison']['old_engine']['native_fingerprint']
        actual_new = row['comparison']['current_engine']['native_fingerprint']
        assert actual_old == hashes[OLD,True].hexdigest()
        assert actual_new == hashes[CURRENT,True].hexdigest()
        old_path = Path(row['old_origin']['path']);new_path = Path(row['current']['path'])
        assert sha(old_path) == row['old_origin']['sha256'] and sha(new_path) == row['current']['sha256']
        masked = []
        start = row['comparison']['old_engine']['version_offset']+len('scriptw-native-v1-')
        for path in (old_path,new_path):
            with path.open('rb') as stream:
                prefix = stream.read(start)
                value = hashlib.sha256(prefix);assert len(stream.read(64)) == 64
                value.update(b'\0'*64)
                while chunk := stream.read(1024**2):value.update(chunk)
                masked.append(value.hexdigest())
        assert masked[0] == masked[1]
        record.setdefault('minimal_native_fingerprint_mask',{})[mode] = dict(offset=start,bytes=64,old_sha256=masked[0],current_sha256=masked[1],equal=True)
    record['native_root_changed_paths'] = [path for path in inventories[OLD] if inventories[OLD][path] != inventories[CURRENT][path]]
    assert record['native_root_changed_paths'] == ['crates/scriptw-engine/Cargo.toml']
    patch = git('diff',OLD,CURRENT,'--','crates/scriptw-engine/Cargo.toml')
    record['engine_manifest_patch'] = dict(text=patch.decode(),sha256=hashlib.sha256(patch).hexdigest())
    assert git('rev-parse','HEAD').decode().strip() == CURRENT
    record['after'] = budget()
    events = [dict(line.split() for line in record[m]['memory.events'].splitlines()) for m in ('before','after')]
    assert all(events[0][k] == events[1][k] for k in ('oom','oom_kill','oom_group_kill'))
    record.update(complete=True,finished_at=datetime.now(timezone.utc).isoformat())
except Exception as error:
    record.update(error=repr(error),error_type=type(error).__name__)
    if 'after' not in record:record['after'] = budget()
    raise
finally:
    save()
    print(json.dumps(dict(complete=record['complete'],error=record.get('error'),source_fingerprints=record.get('source_fingerprints'))),flush=True)
