"""Private reviewed continuation; execute only after parent admission.

Reuse unchanged ladder definitions and remaining native-control statements by
AST, without importing/executing the original driver's top-level entry point.
The only changed runtime acceptance is this source-specific, pinned actual-byte
proof: old/new serialized R differs solely in 64 native-compatibility hex bytes.
"""
import argparse
import ast
from datetime import datetime, timezone
import hashlib
import json
import lzma
import os
from pathlib import Path
import re
import shutil
import struct
import subprocess
import sys
import tarfile
import time

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
SOURCE = 'aacf3283ca1fd0b2dd47e7bd1aea6230bf140a1a'
ORIGIN = BASE / 'verify-main-aacf3283'
OUT = BASE / 'verify-main-aacf3283-continuation'
BUILD = ROOT / 'target/performance-work-20261024/build'
ORIGINAL_DRIVER = BASE / 'verify-next.py'
ORIGINAL_DRIVER_SHA = 'ab37b59d424c094525a3f1b96aa5ef7947a4eaf8ae5b88a66cda607dd497c83f'
ORIGINAL_REPORT_SHA = '6d1d8684f4fe5589c8ba08bf197f4cda7b2c736e46cef81ac66ed2c719877746'
JOURNAL = BASE / 'main-aacf3283-journal.stdout'
JOURNAL_SHA = '5af3647e72092f79a6f30107988547c7f4fdb32bcec8f9aba62c5b15dd7c6046'
PROOF_BASE = BASE / 'native-serialization-aacf-20261028'
COMPARISON_PATH = PROOF_BASE / 'retry-version-length/report.json'
COMPARISON_SHA = '58de0e69a5ee8748676861f13eb303e83dc8fa2c9be991cdcbf8d8afb9b416a3'
PROVENANCE_PATH = PROOF_BASE / 'native-identity-provenance.json'
PROVENANCE_SHA = 'ad162d4ac6fb1dd129d9738ea8a504b91f7f7d65aa3d536d86e6c135f1d71746'
INSPECTOR = PROOF_BASE / 'inspect-version-length.py'
INSPECTOR_SHA = 'ec98eb5ff1345a491d310475bff837e9c0552f30a1c90e5c03ca19a79b42de74'
EXPECTED_CURRENT = dict(Portable='4dac02b8875bdaa6fba2938ed33dfa0142512bc7c515a390efc89bf13b6e1c71',
                        NativeHost='cb39ffe5749d957b0cb2fc4bf72f0fe92ac9ee4b44e07a5199d3729736ddf3ff')
sys.path.insert(0, str(ROOT / 'scripts'))
from limited_verification import require_kernel_budget, kernel_group
from native_test_protocol import parse_inventory, result_summaries

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--expected-source', required=True)
parser.add_argument('--source-bindings', type=Path, required=True)
args = parser.parse_args()
assert args.expected_source == SOURCE
assert not OUT.exists(), 'fresh continuation directory required'
require_kernel_budget(4 * 1024**3)
assert sorted(os.sched_getaffinity(0)) == [0]
assert os.environ['SCRIPTW_MODULE_MEMORY_CACHE_ENTRIES'] == '1'
assert os.environ['SCRIPTW_MODULE_MEMORY_CACHE_LIMIT_BYTES'] == str(64 * 1024**2)
os.environ['CARGO_BUILD_JOBS'] = '1'
os.environ['RUST_TEST_THREADS'] = '1'


def file_sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


assert file_sha(ORIGINAL_DRIVER) == ORIGINAL_DRIVER_SHA
original_text = ORIGINAL_DRIVER.read_text()
original_ast = ast.parse(original_text, filename=str(ORIGINAL_DRIVER))
names = {'git', 'source', 'sha', 'save', 'run', 'cargo', 'jsonrows', 'frozen_test'}
definitions = [node for node in original_ast.body if isinstance(node, ast.FunctionDef) and node.name in names]
assert {node.name for node in definitions} == names
exec(compile(ast.Module(body=definitions, type_ignores=[]), str(ORIGINAL_DRIVER), 'exec'), globals())
assert sha(ORIGIN / 'report.json') == ORIGINAL_REPORT_SHA
prefix = json.loads((ORIGIN / 'report.json').read_text())
assert prefix['source_commit'] == SOURCE and prefix['complete'] is False and 'after' not in prefix
assert prefix['requires_full_wasm_verification'] is True and not prefix['runtime_bytes_proof'] and not prefix['native_scopes']
assert prefix['compiler_fingerprint_equivalence_claim'] is False
assert prefix['cpu_affinity'] == [0] and prefix['before']['memory.max'] == '4294967296'
assert prefix['before']['memory.swap.max'] == '0' and prefix['before']['memory.oom.group'] == '1'
assert sha(args.source_bindings) == prefix['source_bindings']['sha256']
assert args.source_bindings.resolve() == Path(prefix['source_bindings']['path'])

# Execute the exact original host-only/source/predecessor/binding admission.
# This excludes parser setup, OUT.mkdir, run calls and the old native-equality
# assertion; none of the original nine prefix commands can run again here.
admission_text = original_text[original_text.index('source()\nfor ancestor'):original_text.index('OUT.mkdir();group=')]
exec(compile(admission_text, str(ORIGINAL_DRIVER) + ':unchanged-admission', 'exec'), globals())
expected_prefix = [
    ('source-guards', [sys.executable, '-B', 'scripts/check-source-guards.py', '--output', str(ORIGIN / 'source-guards')]),
    ('identities', [sys.executable, '-B', 'scripts/intl_source_identities.py']),
    ('runtime-profile', [sys.executable, '-B', 'scripts/check-runtime-source-compilation-profile.py']),
    ('immutable-pool', [sys.executable, '-B', 'scripts/check-immutable-compiler-pool.py']),
    ('retired-js', ['bash', 'scripts/check-no-legacy-js.sh']),
    ('diff', ['git', 'diff', '--check']),
]
rust = [path for path in git('diff', '--name-only', '9001324dc52ce583e7b95a1292f317796d415c01', SOURCE).decode().splitlines() if path.endswith('.rs')]
assert rust
expected_prefix += [('rustfmt', ['rustfmt', '--edition', '2021', '--config', 'skip_children=true', '--check', *rust]),
                   ('python63', [sys.executable, '-B', '-m', 'unittest', 'scripts.tests.test_precompiled_comparison',
                                 'scripts.tests.test_tooling_benchmark_boundary', 'scripts.tests.test_precompiled_mapping_diagnostic',
                                 'scripts.tests.test_benchmark_module_images', '-v']),
                   ('default-workspace-check', list(map(str, cargo('check', '--workspace', '--all-targets', '--no-default-features', '--message-format=json'))))]
assert [(row['label'], row['command']) for row in prefix['commands']] == expected_prefix
for row in prefix['commands']:
    assert row['exit_code'] == 0
    for channel in ('stdout', 'stderr'):
        assert row[channel] == row['label'] + '.' + channel
        assert sha(ORIGIN / row[channel]) == row[channel + '_sha256']
python_text = (ORIGIN / 'python63.stdout').read_text() + (ORIGIN / 'python63.stderr').read_text()
assert re.findall(r'Ran (\d+) tests?', python_text) == ['63'] and re.search(r'^OK$', python_text, re.M)
defaultlog = ORIGIN / 'default-workspace-check.stdout'
checked = jsonrows(defaultlog)
assert checked[-1] == dict(reason='build-finished', success=True)
assert sum(row.get('reason') == 'build-finished' for row in checked) == 1
assert not [row for row in checked if row.get('reason') == 'compiler-message' and row['message']['level'] == 'error']
guard = json.loads((ORIGIN / 'source-guards/receipt.json').read_text())
assert guard['finished'] and guard['passed'] and guard['exit_code'] == 0
for target in guard['targets']:
    item = json.loads((ORIGIN / 'source-guards' / target['receipt']).read_text())
    inventory = item['test_inventory']
    assert item['finished'] and item['passed'] and inventory and len(inventory) == len(set(inventory))
    assert item['result_summaries'] == [['ok', str(len(inventory)), '0', '0', '0', '0']]
assert sha(JOURNAL) == JOURNAL_SHA
assert 'Main process exited, code=exited, status=1/FAILURE' in JOURNAL.read_text()
assert "assert same,'actual runtime bytes changed; do not skip fresh JS verification'" in JOURNAL.read_text()

assert sha(COMPARISON_PATH) == COMPARISON_SHA and sha(PROVENANCE_PATH) == PROVENANCE_SHA
comparison = json.loads(COMPARISON_PATH.read_text())
provenance = json.loads(PROVENANCE_PATH.read_text())
assert comparison['complete'] and comparison['source_commit'] == SOURCE
assert provenance['complete'] and provenance['source_commit'] == SOURCE
assert provenance['comparison_report_sha256'] == COMPARISON_SHA
assert provenance['original_private_refusal_sha256'] == sha(PROOF_BASE / 'report.json')
initial_refusal = json.loads((PROOF_BASE / 'report.json').read_text())
assert initial_refusal['complete'] is False and initial_refusal['error_type'] == 'AssertionError'
assert comparison['old_static_facts']['sha256'] == sha(oldstatic_path)
assert provenance['native_root_changed_paths'] == ['crates/scriptw-engine/Cargo.toml']
assert comparison['native_identity_source_changes'] == provenance['native_root_changed_paths']
assert set(comparison['variants']) == {'Portable', 'NativeHost'}
for row in provenance['extra_current_inputs']:
    assert (ROOT / row['path']).stat().st_size == row['bytes'] and sha(ROOT / row['path']) == row['sha256']
for mode, row in comparison['variants'].items():
    old = oldstatic['variants'][mode]['current']
    proof = row['comparison']
    assert row['old_origin']['sha256'] == old['native']['sha256']
    assert row['current']['sha256'] == EXPECTED_CURRENT[mode]
    assert proof['whole_file_identical_except_native_version'] and proof['remaining_engine_metadata_identical']
    assert proof['masked_old_sha256'] == proof['masked_current_sha256']
    assert proof['old_engine']['version_offset'] == proof['current_engine']['version_offset'] == 66
    assert proof['old_engine']['version_bytes'] == proof['current_engine']['version_bytes'] == 82
    assert proof['changed_bytes'] == 60
    assert all(84 <= extent['start'] < extent['end'] <= 148 and extent['sections'] == ['.wasmtime.engine'] for extent in proof['changed_byte_extents'])
    changed_sections = [section for section in proof['sections'] if not section['byte_identical']]
    assert len(changed_sections) == 1 and changed_sections[0]['name'] == '.wasmtime.engine' and changed_sections[0]['flags'] == 2
    assert all(section['old_sha256'] == section['current_sha256'] for section in proof['sections'] if section['name'] != '.wasmtime.engine')
    minimal = provenance['minimal_native_fingerprint_mask'][mode]
    assert minimal['offset'] == 84 and minimal['bytes'] == 64 and minimal['equal'] and minimal['old_sha256'] == minimal['current_sha256']
    for revision, key in [('80b842693e964634f378d5813f6db684ee7d255b', 'old_engine'), (SOURCE, 'current_engine')]:
        fact = [item for item in provenance['source_fingerprints'] if item['source_commit'] == revision and item['includes_current_extra_inputs']]
        assert len(fact) == 1 and fact[0]['native_fingerprint'] == proof[key]['native_fingerprint']
assert sha(INSPECTOR) == INSPECTOR_SHA
inspection_ast = ast.parse(INSPECTOR.read_text(), filename=str(INSPECTOR))
inspection_names = {'elf', 'engine', 'masked_digest', 'digest'}
inspection_defs = [node for node in inspection_ast.body if isinstance(node, ast.FunctionDef) and node.name in inspection_names]
assert {node.name for node in inspection_defs} == inspection_names
exec(compile(ast.Module(body=inspection_defs, type_ignores=[]), str(INSPECTOR), 'exec'), globals())

OUT.mkdir()
group = kernel_group()
def budget():
    return {key: (group / key).read_text().strip() for key in ('memory.max', 'memory.swap.max', 'memory.oom.group', 'memory.peak', 'memory.events')}
record = dict(source_commit=SOURCE, complete=False, started_at=datetime.now(timezone.utc).isoformat(), cpu_affinity=[0],
              before=budget(), commands=[], native_scopes=[], runtime_bytes_proof={}, test262_rerun=False,
              compiler_fingerprint_equivalence_claim=False, host_only_crate_paths=crate_diff,
              reviewed_crate_diff_sha256=prefix['reviewed_crate_diff_sha256'], source_bindings=prefix['source_bindings'],
              predecessor=prefix['predecessor'],
              original_prefix=dict(report_sha256=ORIGINAL_REPORT_SHA, report_complete=False, resource_after_available=False,
                                   parent_exit_code=1, parent_exit_origin='systemd journal', journal_sha256=JOURNAL_SHA,
                                   completed_commands=9, original_requires_full_wasm_verification=True),
              runtime_stamp_admission=dict(comparison_sha256=COMPARISON_SHA, native_source_provenance_sha256=PROVENANCE_SHA,
                                           exact_native_fingerprint_offset=84, exact_native_fingerprint_bytes=64,
                                           changed_native_bytes=60, all_other_native_bytes_identical=True,
                                           original_inspector_refusal_preserved=True),
              resource_scope='Fresh continuation invocation only: inherited prefix after counters remain unavailable; remaining commands and inert admission/archive processing use this new before/after interval.',
              reused_original_definitions=dict(path=str(ORIGINAL_DRIVER), sha256=ORIGINAL_DRIVER_SHA, definitions=sorted(names)),
              reused_remaining_statements='Unchanged original AST from default-engine-doctests through the final source/resource guards; original terminal success claims replaced with explicit stamp-only equivalence.')


def retain(source_path, relative):
    target = OUT / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    assert not target.exists() and source_path.is_file() and not source_path.is_symlink()
    shutil.copyfile(source_path, target)
    assert sha(source_path) == sha(target)


retain(ORIGIN / 'report.json', 'inherited-prefix/report.json')
retain(ORIGINAL_DRIVER, 'admission/verify-next.py')
retain(JOURNAL, 'inherited-prefix/systemd-journal.stdout')
retain(args.source_bindings, 'admission/source-bindings.json')
for row in prefix['commands']:
    for channel in ('stdout', 'stderr'):
        retain(ORIGIN / row[channel], 'inherited-prefix/' + row[channel])
for path in (ORIGIN / 'source-guards').rglob('*'):
    if path.is_file() and path.suffix in ('.json', '.stdout', '.stderr', '.rs'):
        retain(path, 'inherited-prefix/source-guards/' + path.relative_to(ORIGIN / 'source-guards').as_posix())
for path, name in [(COMPARISON_PATH, 'comparison.json'), (PROVENANCE_PATH, 'native-identity-provenance.json'),
                   (PROOF_BASE / 'report.json', 'original-inspector-refusal.json'), (INSPECTOR, 'successful-inspector.py'),
                   (PROOF_BASE / 'inspect.py', 'original-inspector.py'), (PROOF_BASE / 'native-identity-provenance.py', 'native-identity-provenance.py'),
                   (oldstatic_path, 'verified80-static.json')]:
    retain(path, 'admission/' + name)
for mode in ('Portable', 'NativeHost'):
    fact = oldstatic['variants'][mode]['current']['manifest']
    manifest = oldstatic_path.parent / fact['retained_copy']
    assert sha(manifest) == fact['sha256'] and manifest.stat().st_size <= 4096
    retain(manifest, 'admission/verified80-' + mode + '-manifest.bin')
save()


def stamp_native(native, mode):
    """No generic version-ignore rule: require this exact reviewed full digest."""
    fact = comparison['variants'][mode]
    expected = fact['comparison']
    assert native.stat().st_size == fact['current']['bytes'] <= 128 * 1024**2
    assert sha(native) == EXPECTED_CURRENT[mode], 'unexpected native bytes require new proof or fresh JS verification'
    raw = native.read_bytes()
    assert digest(raw) == EXPECTED_CURRENT[mode]
    metadata = elf(raw)
    actual_engine = engine(raw, metadata)
    assert actual_engine == expected['current_engine']
    assert masked_digest(raw, 66, 82) == expected['masked_old_sha256']
    assert masked_digest(raw, 84, 64) == provenance['minimal_native_fingerprint_mask'][mode]['old_sha256']
    for section, expected_section in zip(metadata['sections'], expected['sections']):
        assert (section['name'], section['flags'], section['offset'], section['bytes'], section.get('sha256')) == (
            expected_section['name'], expected_section['flags'], expected_section['offset'], expected_section['bytes'], expected_section['current_sha256'])
    assert len(metadata['sections']) == len(expected['sections'])
    return dict(kind='exact-pinned-native-compatibility-stamp-only-byte-proof', current_native_sha256=sha(native),
                verified80_native_sha256=fact['old_origin']['sha256'], current_engine=actual_engine,
                comparison_sha256=COMPARISON_SHA, source_provenance_sha256=PROVENANCE_SHA,
                masked_full_file_sha256=expected['masked_old_sha256'], native_code_and_all_other_bytes_identical=True)


def runtime_snapshot(log, label):
    producers = [row for row in jsonrows(log) if row.get('reason') == 'build-script-executed'
                 and row.get('package_id') == 'path+file:///home/mewhhaha/src/porffor/crates/scriptw-runtime-image#0.1.0']
    assert len(producers) == 1
    directory = Path(producers[0]['out_dir'])
    if label == 'default':
        assert directory == Path(comparison['variants']['Portable']['current']['path']).parent
    result = {}
    for mode, prefix_name in [('Portable', 'scriptw-runtime-portable'), ('NativeHost', 'scriptw-runtime')]:
        package = directory / (prefix_name + '-package.bin')
        assert package.stat().st_size <= 128 * 1024**2
        raw = package.read_bytes()
        assert raw[:8] == b'SCRWRB01' and struct.unpack_from('<I', raw, 8)[0] == 28 and raw[12:44].hex() == local['source_fingerprint']
        assert hashlib.sha256(raw[:-32]).digest() == raw[-32:]
        wasm = raw[136:-32]
        assert wasm[:8] == b'\0asm\1\0\0\0'
        native = directory / (prefix_name + '-native.bin')
        manifest = directory / (prefix_name + '-manifest.bin')
        m = manifest.read_bytes()
        assert m[:8] == b'SCRWNR01' and struct.unpack_from('<I', m, 8)[0] == 5
        n = struct.unpack_from('<H', m, 19)[0]
        assert 0 < n <= 256 and len(m) == 21 + n + 128
        offset = 21 + n
        fp, key, pkg_digest, native_digest = [m[offset+i*32:offset+(i+1)*32].hex() for i in range(4)]
        assert fp == local['source_fingerprint'] and sha(package) == pkg_digest and sha(native) == native_digest
        assert hashlib.sha256(struct.pack('<I', 28) + wasm).hexdigest() == key
        before = oldstatic['variants'][mode]
        old = before['current']
        assert struct.unpack_from('<I', m, 12)[0] == old['manifest']['configuration']
        assert list(m[16:19]) == old['manifest']['modes'] and m[21:21+n].decode() == old['manifest']['target']
        reconstructed = bytearray(raw)
        reconstructed[12:44] = bytes.fromhex(old['package']['source_fingerprint'])
        reconstructed[-32:] = hashlib.sha256(reconstructed[:-32]).digest()
        assert hashlib.sha256(wasm).hexdigest() == before['wasm_sha256']
        assert hashlib.sha256(reconstructed).hexdigest() == old['package']['sha256']
        stamp = stamp_native(native, mode)
        copied = OUT / (label + '-' + mode + '-manifest.bin')
        with copied.open('xb') as stream:
            stream.write(m)
        result[mode] = dict(package_path=str(package), package_sha256=pkg_digest, package_bytes=len(raw),
                            wasm_sha256=hashlib.sha256(wasm).hexdigest(), wasm_bytes=len(wasm), native_sha256=native_digest,
                            native_bytes=native.stat().st_size, runtime_key=key, manifest=copied.name, manifest_sha256=sha(copied),
                            target=m[21:21+n].decode(), configuration=struct.unpack_from('<I', m, 12)[0], modes=list(m[16:19]),
                            historical_header_reconstruction_sha256=hashlib.sha256(reconstructed).hexdigest(), native_stamp_admission=stamp)
    record['runtime_bytes_proof'][label] = dict(cargo_producer=producers[0], variants=result,
                                              retained80_static_sha256=sha(oldstatic_path), inherited_build_command=label == 'default')
    save()
    return result


def inert_archive():
    """Retain manifests/metadata/streams only; never archive an ELF or packed R."""
    record['remaining_ladder_completed_before_archive'] = True
    snapshot = OUT / 'remaining-command-receipt.json'
    snapshot.write_text(json.dumps(record, indent=2) + '\n')
    files = []
    excluded = []
    for path in sorted(OUT.rglob('*')):
        if not path.is_file() or path == OUT / 'report.json':
            continue
        assert not path.is_symlink()
        with path.open('rb') as stream:
            magic = stream.read(8)
        relative = path.relative_to(OUT).as_posix()
        if magic.startswith((b'\x7fELF', b'MZ', b'SWRTZ001', b'SCRWRB', b'SCRWEP', b'SCRWWA')):
            excluded.append(relative)
            continue
        assert path.suffix in ('.json', '.stdout', '.stderr', '.py', '.rs', '.bin')
        assert path.stat().st_size <= 32 * 1024**2
        if path.suffix == '.bin':
            assert magic == b'SCRWNR01' and path.stat().st_size <= 4096
        files.append(dict(path=relative, bytes=path.stat().st_size, sha256=sha(path)))
    assert sum(row['bytes'] for row in files) <= 256 * 1024**2
    archive = OUT / 'inert-evidence.tar.xz'
    with archive.open('xb') as stream, lzma.LZMAFile(stream, 'w', filters=[dict(id=lzma.FILTER_LZMA2, preset=1, dict_size=64*1024**2)]) as compressed:
        with tarfile.open(fileobj=compressed, mode='w|') as bundle:
            for row in files:
                member = tarfile.TarInfo(row['path']);member.size = row['bytes'];member.mode = 0o644
                with (OUT / row['path']).open('rb') as payload:
                    bundle.addfile(member, payload)
    assert archive.stat().st_size <= 32 * 1024**2
    expected = {row['path']: row for row in files}
    seen = set()
    with tarfile.open(archive, 'r|xz') as bundle:
        for member in bundle:
            assert member.isfile() and member.name in expected and member.name not in seen
            assert member.size == expected[member.name]['bytes']
            with bundle.extractfile(member) as payload:
                assert hashlib.file_digest(payload, 'sha256').hexdigest() == expected[member.name]['sha256']
            seen.add(member.name)
    assert seen == set(expected)
    expected = {row['path']: row for row in files}
    seen = set()
    expanded = 0
    with tarfile.open(archive, 'r|xz') as bundle:
        for member in bundle:
            assert member.isfile() and member.name in expected and member.name not in seen
            row = expected[member.name]
            assert member.size == row['bytes'] <= 32 * 1024**2
            expanded += member.size
            assert expanded <= 256 * 1024**2
            assert hashlib.file_digest(bundle.extractfile(member), 'sha256').hexdigest() == row['sha256']
            seen.add(member.name)
    assert seen == set(expected) and expanded == sum(row['bytes'] for row in files)
    record['archive'] = dict(path=archive.name, bytes=archive.stat().st_size, sha256=sha(archive), members=files,
                             expanded_bytes=expanded, roundtrip_hashes_verified=True,
                             excluded_native_files=excluded, native_payloads_retained_in_archive=False)


try:
    defaultbytes = runtime_snapshot(defaultlog, 'default')
    # This is the unchanged original remaining ladder, including exact native
    # inventory/summary checks, default absence doctest, enabled positive case,
    # both CLI example sets, enabled product producer and final source/budget
    # guards. No original prefix command is present in this AST segment.
    tail = original_text[original_text.index("doclog=run('default-engine-doctests'"):original_text.index('record.update(complete=True,after=after,actual_wasm_and_native_bytes_unchanged=True')]
    exec(compile(tail, str(ORIGINAL_DRIVER) + ':unchanged-remaining-ladder', 'exec'), globals())
    assert sha(ORIGIN / 'report.json') == ORIGINAL_REPORT_SHA
    inert_archive()
    source()
    final_after = budget()
    events = [dict(line.split() for line in value['memory.events'].splitlines()) for value in (record['before'], final_after)]
    assert all(events[0][key] == events[1][key] for key in ('oom', 'oom_kill', 'oom_group_kill'))
    record.update(complete=True, after=final_after, finished_at=datetime.now(timezone.utc).isoformat(),
                  actual_wasm_bytes_unchanged=True, serialized_native_bytes_unchanged=False,
                  native_bytes_unchanged_except_exact_compatibility_stamp=True,
                  default_enabled_native_bytes_identical=True,
                  test262_rerun_reason='Reuse verified900 6307 executions: host-only source change; exact default/enabled R Wasm and reconstructed package payloads match verified80. Actual full native comparison proves only64 compatibility-version hex positions may differ (60 actual bytes); .text and every other native byte and remaining engine metadata are identical. Both native IDs recompute from source; current and enabled images must match the exact reviewed current native digests. No new JS semantic execution claim.')
except Exception as error:
    record.update(error=repr(error), error_type=type(error).__name__, finished_at=datetime.now(timezone.utc).isoformat())
    if 'after' not in record:
        record['after'] = budget()
    raise
finally:
    save()
    print(json.dumps(dict(complete=record['complete'], source_commit=SOURCE, error=record.get('error'))), flush=True)
