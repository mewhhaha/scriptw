"""Clean-commit inert Python controls with actual scope counters."""
import json
import os
from pathlib import Path
import subprocess
import sys
import unittest

SOURCE = Path('/home/mewhhaha/src/porffor/target/memory-module-ownership-20261027')
sys.path.insert(0, str(SOURCE))
sys.path.insert(0, str(SOURCE/'scripts'))
from limited_verification import kernel_group, require_kernel_budget

require_kernel_budget(128*1024**2)
assert os.sched_getaffinity(0) == {0}
group = kernel_group()
def resources():
    return {name: (group/name).read_text().strip() for name in
            ('memory.max', 'memory.swap.max', 'memory.oom.group', 'memory.current', 'memory.peak', 'memory.events')}
def git(*args):
    return subprocess.check_output(['git', *args], cwd=SOURCE, text=True).strip()
head = git('rev-parse', 'HEAD')
assert head.startswith('06289f6c2')
assert not git('status', '--porcelain')
before = resources()
modules = ['scripts.tests.test_precompiled_comparison', 'scripts.tests.test_tooling_benchmark_boundary',
           'scripts.tests.test_precompiled_mapping_diagnostic', 'scripts.tests.test_benchmark_module_images']
suite = unittest.defaultTestLoader.loadTestsFromNames(modules)
result = unittest.TextTestRunner(verbosity=2).run(suite)
after = resources()
assert git('rev-parse', 'HEAD') == head and not git('status', '--porcelain')
print(json.dumps(dict(schema='private-clean-symbol-name-controls-v1', source=str(SOURCE), head=head,
    clean_source_before_after=True, tests=result.testsRun, failures=len(result.failures), errors=len(result.errors),
    skipped=len(result.skipped), success=result.wasSuccessful(), modules=modules,
    resources=dict(before=before, after=after), cpu_affinity=sorted(os.sched_getaffinity(0))), indent=2))
raise SystemExit(0 if result.wasSuccessful() else 1)
