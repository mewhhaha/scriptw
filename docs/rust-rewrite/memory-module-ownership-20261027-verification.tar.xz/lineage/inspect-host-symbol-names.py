"""Bounded inert ELF symbol-name statistics; never reads or executes text."""
import hashlib
import json
import os
from pathlib import Path
import struct
import sys

ROOT = Path('/home/mewhhaha/src/porffor')
sys.path.insert(0, str(ROOT/'scripts'))
from limited_verification import kernel_group, require_kernel_budget

require_kernel_budget(128 * 1024**2)
assert os.sched_getaffinity(0) == {0}
group = kernel_group()
def resources():
    return {name: (group/name).read_text().strip() for name in
            ('memory.max', 'memory.swap.max', 'memory.oom.group', 'memory.current', 'memory.peak', 'memory.events')}
before_resources = resources()
host = ROOT/'target/performance-work-20261024/build/release/examples/compiler_precompiled_baseline'
before = host.stat()
counts = {'defined_func_ifunc': 0, 'defined_executable_nonzero_func_ifunc': 0}
name_total = {key: 0 for key in counts}
maxima = {key: 0 for key in counts}
bins = {key: {'0-2048': 0, '2049-4096': 0, '4097-8192': 0,
              '8193-16384': 0, '16385-65536': 0, '65537+': 0} for key in counts}
samples = []
read_bytes = 0
def read_extent(stream, offset, size):
    global read_bytes
    assert 0 <= offset <= before.st_size and 0 <= size <= before.st_size-offset
    stream.seek(offset)
    data = stream.read(size)
    assert len(data) == size
    read_bytes += size
    return data
def account(key, length):
    counts[key] += 1
    name_total[key] += length
    maxima[key] = max(maxima[key], length)
    for label, bound in [('0-2048', 2048), ('2049-4096', 4096), ('4097-8192', 8192),
                         ('8193-16384', 16384), ('16385-65536', 65536), ('65537+', 2**64)]:
        if length <= bound:
            bins[key][label] += 1
            break
with host.open('rb') as stream:
    header = struct.unpack('<16sHHIQQQIHHHHHH', read_extent(stream, 0, 64))
    assert header[0][:7] == b'\x7fELF\x02\x01\x01'
    shoff, shsize, shnum, shstr = header[6], header[11], header[12], header[13]
    assert shsize == 64 and 0 < shnum <= 4096 and 0 < shstr < shnum
    raw_sections = read_extent(stream, shoff, shsize*shnum)
    sections = [struct.unpack_from('<IIQQQQIIQQ', raw_sections, n*64) for n in range(shnum)]
    names = sections[shstr]
    assert names[1] == 3 and names[5] <= 32*1024**2
    section_names = read_extent(stream, names[4], names[5])
    section_name_bytes = 0
    for section in sections:
        end = section_names.find(b'\0', section[0])
        assert 0 <= section[0] <= end
        section_name_bytes += end-section[0]
    total_entries = 0
    strtab_bytes = 0
    for table in sections:
        if table[1] != 2:
            continue
        assert table[9] == 24 and table[5] % 24 == 0 and table[6] < len(sections)
        total_entries += table[5]//24
        assert total_entries <= 200000
        strings = sections[table[6]]
        assert strings[1] == 3 and strings[5] <= 32*1024**2
        strtab_bytes += strings[5]
        assert strtab_bytes <= 32*1024**2
        strtab = read_extent(stream, strings[4], strings[5])
        stream.seek(table[4])
        for ordinal in range(table[5]//24):
            raw = stream.read(24)
            assert len(raw) == 24
            read_bytes += 24
            name, info, other, section_index, address, size = struct.unpack('<IBBHQQ', raw)
            if info & 15 not in (2, 10) or section_index == 0:
                continue
            assert 0 <= name < len(strtab)
            end = strtab.find(b'\0', name)
            assert end >= name
            length = end-name
            account('defined_func_ifunc', length)
            executable = section_index < len(sections) and sections[section_index][2] & 4
            if executable and size:
                account('defined_executable_nonzero_func_ifunc', length)
            if length > 2048:
                sample = dict(bytes=length, sha256=hashlib.sha256(memoryview(strtab)[name:end]).hexdigest(),
                              prefix=strtab[name:min(end, name+160)].decode('utf-8', errors='backslashreplace'),
                              executable=bool(executable), nonzero_size=bool(size))
                samples.append(sample)
                samples.sort(key=lambda row: (-row['bytes'], row['sha256']))
                del samples[8:]
after = host.stat()
identity_before = [before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns]
identity_after = [after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns]
assert identity_before == identity_after
print(json.dumps(dict(schema='private-inert-elf-symbol-name-stats-v1', host=str(host),
    file_identity=identity_before, host_sha256=None,
    read_policy='ELF header, section table, section names, symbol tables and linked string tables only; no text/native execution or whole-file hash',
    elf_machine=header[2], file_bytes=before.st_size, total_read_bytes=read_bytes,
    section_count=shnum, symbol_table_entries=total_entries, linked_strtab_bytes=strtab_bytes,
    counts=counts, maximum_name_bytes=maxima, total_name_bytes=name_total,
    parser_name_budget_bytes=section_name_bytes+name_total['defined_executable_nonzero_func_ifunc'],
    name_length_bins=bins, longest_over_2048=samples,
    resources=dict(before=before_resources, after=resources()), cpu_affinity=sorted(os.sched_getaffinity(0))), indent=2))
